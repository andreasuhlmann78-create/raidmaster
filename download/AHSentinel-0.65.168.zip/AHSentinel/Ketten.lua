if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Ketten.lua (Herstellungs-Ketten, S3b/S3-2, Vorgaben des Nutzers 14.11. 14:51, BR-W1)
--   (1) Berufe/Rezepte je Figur: gemerkte Rezepte (Crafting.lua Cr:KnownRecipes, beim Öffnen des Berufsfensters gelesen)
--   (2) Ketten je Figur gespeichert (A.db.chains[Figur]), nach jedem Scan neu gerechnet (Hintergrund-Arbeit), nie beim Öffnen
--   (3) je Kette: Produkt, Weg (verkaufen / entzaubern), Gewinn als Zahl, Einkaufsliste (einkaufbare Zutaten)
--   (4) NUR was Gold bringt: Verlust oder unter dem Mindestgewinn (20 %) fällt heraus und wird nur gezählt (Ursache)
-- Zutaten-Kosten = Preis, zu dem die Menge für eine Serie (SERIES Herstellungen) wirklich kaufbar ist (Preis-Leiter, BR-W1),
-- Händlerware zum Händlerpreis, Zwischenprodukte aus bekannten Rezepten (mehrstufig, Kreise verhindert, Tiefe DEPTH).
-- Produkt = realistischer Wert aus der einen Preisfunktion (A:RealValue, nach Gebühren) bzw. Entzauber-Wert (Cr).
-- FREIGABE (Nutzer 14:09 "alles 3 mal geprüft"): bis zur Freigabe durch den Supervisor NUR im Testbericht
-- ("MARKT-KERN Ketten"), nicht in Tooltip/Markt (Ke.LIVE = false).
-- ============================================================
local A = AHAnalyzerPro
if not (A and A.On) then return end
local Ke = {}
A.Ketten = Ke

Ke.LIVE = false
Ke.SERIES, Ke.DEPTH, Ke.MIN_GAIN, Ke.MAX_RECIPES = 20, 3, 0.20, 400

local function CharKey() return A.Chars and A.Chars:Key() or ((UnitName and UnitName("player")) or "?") end

-- Rezepte dieser Figur: [productID] = { made, reagents = { {id, n}, ... }, name, prof }. Testroutine: Ke.testRecipes
function Ke:Recipes()
    if self.testRecipes then return self.testRecipes end
    local map = {}
    local Cr = A.Crafting
    if not (Cr and Cr.KnownRecipes) then return map end
    local ok, list = pcall(Cr.KnownRecipes, Cr)
    for i, r in ipairs(ok and list or {}) do
        if i > self.MAX_RECIPES then break end
        if r.productID and not map[r.productID] then map[r.productID] = r end
    end
    return map
end

-- Preise (Nahtstellen für die Testroutine: Ke.testPrice = { [id] = { ah = Stückpreis, ladder = {{p,q},...}, vendor = Kaufpreis,
-- sell = Wert nach Gebühren je Stück, de = Entzauber-Wert je Stück } })
function Ke:VendorBuy(id)
    if self.testPrice then local p = self.testPrice[id]; return p and p.vendor end
    local ok, v = pcall(A.GetVendorBuyPrice, A, id)
    return ok and type(v) == "number" and v > 0 and v or nil
end
function Ke:Ladder(id)
    if self.testPrice then local p = self.testPrice[id]; return p and p.ladder end
    local ok, l = pcall(A.OfferLadder, A, id)
    return ok and type(l) == "table" and #l > 0 and l or nil
end
function Ke:AHUnit(id)
    if self.testPrice then local p = self.testPrice[id]; return p and p.ah end
    local ok, v = pcall(A.RealPrice, A, id)
    return ok and type(v) == "number" and v > 0 and v or nil
end
-- Kosten für qty Stück im AH über die Preisleiter (nicht billigstes Einzelstück × Menge, BR-W1). Geschätzte Stufen (3. Feld)
-- nicht unter dem letzten echten Preis. Was die Leiter nicht hergibt: teuerster bekannter Preis. Zurück: Kosten oder nil
function Ke:AHCost(id, qty)
    local unit = self:AHUnit(id)
    local ladder = self:Ladder(id)
    if not ladder then return unit and unit * qty or nil end
    local left, cost, last = qty, 0, unit or 0
    for _, st in ipairs(ladder) do
        if left <= 0 then break end
        local p, q = st[1], st[2] or 0
        if p and q > 0 then
            local take = math.min(left, q)
            cost, left, last = cost + take * p, left - take, math.max(last, p)
        end
    end
    if left > 0 then
        if last <= 0 then return nil end
        cost = cost + left * last
    end
    return cost
end

-- günstigster Weg für qty Stück einer Zutat: Kosten, Weg ("vendor"/"ah"/"craft"), Einkaufsliste {id -> Menge}, Grund (nil)
-- visiting: Kreise verhindern (A aus B, B aus A)
function Ke:ReagentCost(id, qty, recipes, depth, visiting)
    local best, how, buy = nil, nil, nil
    local v = self:VendorBuy(id)
    if v then best, how, buy = v * qty, "vendor", { [id] = qty } end
    local ah = self:AHCost(id, qty)
    if ah and (not best or ah < best) then best, how, buy = ah, "ah", { [id] = qty } end
    local rec = recipes[id]
    if rec and depth < self.DEPTH and not visiting[id] then
        visiting[id] = true
        local crafts = math.ceil(qty / math.max(rec.made or 1, 1))
        local sum, list, ok = 0, {}, true
        for _, re in ipairs(rec.reagents or {}) do
            local c, _, b = self:ReagentCost(re[1], crafts * (re[2] or 1), recipes, depth + 1, visiting)
            if not c then ok = false; break end
            sum = sum + c
            for k, n in pairs(b) do list[k] = (list[k] or 0) + n end
        end
        visiting[id] = nil
        if ok and (not best or sum < best) then best, how, buy = sum, "craft", list end
    elseif rec and visiting[id] then
        self.cycles = (self.cycles or 0) + 1
    end
    if not best then return nil, nil, nil, "Preis fehlt" end
    return best, how, buy
end

-- Wert des Produkts je Stück: bester Weg (verkaufen nach Gebühren / entzaubern), Weg
function Ke:ProductValue(pid, made)
    local sell, de
    if self.testPrice then
        local p = self.testPrice[pid] or {}
        sell, de = p.sell and p.sell * made, p.de and p.de * made
    else
        local ok, rv = pcall(A.RealValue, A, pid, made)
        sell = ok and type(rv) == "number" and rv or nil
        local Cr = A.Crafting
        if Cr and Cr.DisenchantValue then
            local okD, d = pcall(Cr.DisenchantValue, Cr, pid, made)
            de = okD and d or nil
        end
    end
    if de and (not sell or de > sell) then return de, "de" end
    if sell then return sell, "sell" end
    return nil
end

-- eine Kette rechnen (je Herstellung, gemittelt über eine Serie): Tabelle oder nil, Grund
function Ke:Chain(pid, recipes)
    local rec = recipes[pid]
    if not rec then return nil, "kein Rezept" end
    local n = self.SERIES
    local cost, buy = 0, {}
    local visiting = { [pid] = true }
    for _, re in ipairs(rec.reagents or {}) do
        local c, how, b, why = self:ReagentCost(re[1], n * (re[2] or 1), recipes, 1, visiting)
        if not c then return nil, why or "Preis fehlt" end
        cost = cost + c
        for k, q in pairs(b) do buy[k] = (buy[k] or 0) + q end
    end
    local made = rec.made or 1
    local value, way = self:ProductValue(pid, made)
    if not value then return nil, "Produkt ohne Preis" end
    local unitCost = cost / n
    local profit = math.floor(value - unitCost + 0.5)
    local c = { pid = pid, name = rec.name, way = way, cost = math.floor(unitCost + 0.5), value = math.floor(value + 0.5), profit = profit,
                pct = unitCost > 0 and profit / unitCost or nil, buy = buy, series = n }
    if profit <= 0 then return c, "Verlust" end
    if not c.pct or c.pct < self.MIN_GAIN then return c, "unter Mindestgewinn" end
    return c
end

-- alle Ketten dieser Figur rechnen; zurück: Liste (nur Gewinn ≥ Mindestgewinn, absteigend), Ausschluss-Zähler
function Ke:Build()
    local recipes = self:Recipes()
    local list, out = {}, {}
    self.cycles = 0
    for pid in pairs(recipes) do
        if A.Pause then A:Pause() end
        local c, why = self:Chain(pid, recipes)
        if c and not why then list[#list + 1] = c
        else out[why or "?"] = (out[why or "?"] or 0) + 1 end
    end
    if self.cycles > 0 then out["Kreis verhindert"] = self.cycles end
    table.sort(list, function(a, b) return a.profit > b.profit end)
    return list, out
end

function Ke:Store()
    if self.testDB then return self.testDB end
    if not A.db or (A.InTestRoutine and A:InTestRoutine()) then return nil end
    A.db.chains = type(A.db.chains) == "table" and A.db.chains or {}
    return A.db.chains
end
-- nach dem Scan: rechnen und je Figur merken (nur Zahlen und Item-IDs; höchstens 30 Ketten)
function Ke:Refresh()
    local st = self:Store()
    if not st then return end
    local list, out = self:Build()
    local keep = {}
    for i = 1, math.min(30, #list) do
        local c = list[i]
        keep[i] = { pid = c.pid, way = c.way, cost = c.cost, value = c.value, profit = c.profit, pct = c.pct, buy = c.buy, series = c.series }
    end
    st[CharKey()] = { t = time(), list = keep, out = out }
    return keep
end
function Ke:Saved()
    local st = self.testDB or (A.db and A.db.chains)
    return st and st[CharKey()] or nil
end

-- Selbstkontrolle (SK1-l): vorhergesagter Gewinn je Stück beim Herstellen merken; verkauft -> realisiert aus den Buchungen.
-- Stimmig, wenn eine Kette mit Gewinn auch realisiert Gewinn bringt.
function Ke:NotePrediction(pid)
    local st = self:Store()
    local sv = self:Saved()
    if not (st and sv) then return end
    for _, c in ipairs(sv.list or {}) do
        if c.pid == pid then
            st.pred = st.pred or {}
            st.pred[pid] = { t = time(), p = c.profit }
            return true
        end
    end
end
function Ke:Realized(days)
    local st = self.testDB or (A.db and A.db.chains)
    local pred = st and st.pred or {}
    local BK = A.Books
    local db = BK and BK:Data()
    local since = time() - (days or 30) * 86400
    local n, ok, ex = 0, 0, {}
    for _, e in ipairs(db and db.log or {}) do
        local p = e.k == "sale" and e.id and pred[e.id]
        if p and e.st ~= "x" and (e.t or 0) >= math.max(since, p.t) and (e.q or 0) > 0 then
            local real = ((e.rev or 0) - (e.cost or 0)) / e.q
            n = n + 1
            if real > 0 then ok = ok + 1
            elseif #ex < 3 then ex[#ex + 1] = string.format("Item %d: vorhergesagt %+d, realisiert %+d", e.id, p.p, math.floor(real)) end
        end
    end
    return n, ok, ex
end

-- Testbericht "MARKT-KERN Ketten" (bis zur Freigabe nur hier)
function Ke:ReportLines(out, fields)
    local sv = self:Saved()
    if not sv then
        out[#out + 1] = "  MARKT-KERN Ketten (nur Testbericht, Freigabe offen): noch nicht gerechnet (kein Scan oder keine Rezepte gemerkt)"
        return
    end
    local tops = {}
    for i, c in ipairs(sv.list or {}) do
        if i > 8 then break end
        tops[#tops + 1] = string.format("%d %s +%d (%d %%, Kosten %d, Wert %d)", c.pid, c.way == "de" and "entz." or "verk.", c.profit, math.floor((c.pct or 0) * 100 + 0.5), c.cost, c.value)
    end
    local outs = {}
    for k, v in pairs(sv.out or {}) do outs[#outs + 1] = k .. " " .. v end
    table.sort(outs)
    out[#out + 1] = string.format("  MARKT-KERN Ketten (nur Testbericht, Freigabe offen, Serie %d): %d mit Gewinn ≥ %d %% · %s · nicht gezeigt: %s · gerechnet %s",
        self.SERIES, #(sv.list or {}), self.MIN_GAIN * 100, #tops > 0 and table.concat(tops, " | ") or "-", #outs > 0 and table.concat(outs, ", ") or "-",
        sv.t and date("%d.%m. %H:%M", sv.t) or "-")
    local n, ok, ex = self:Realized(30)
    out[#out + 1] = string.format("  SK1-l Ketten vorhergesagt/realisiert: %d Verkäufe · %d mit Gewinn · %d ohne%s", n, ok, n - ok,
        #ex > 0 and (" (" .. table.concat(ex, " | ") .. ")") or "")
    if fields then fields.kern_ketten = string.format("%d/%d/%d", #(sv.list or {}), n, ok) end
end

A:On("SCAN_FINISHED", function()
    if A.Job and not (A.InTestRoutine and A:InTestRoutine()) then A:Job("ketten:refresh", function() Ke:Refresh() end) end
end)
A:On("CRAFT_DONE", function(pid)
    if not (A.InTestRoutine and A:InTestRoutine()) then pcall(Ke.NotePrediction, Ke, pid) end
end)
