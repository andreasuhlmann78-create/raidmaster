if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.7 - Berufe: Gewinn pro Rezept
--
-- Neben dem Berufsfenster (Alchemie, Schmiedekunst, ... und
-- Verzauberkunst) erscheint ein kleines Fenster:
--   * gewähltes Rezept: Materialkosten, Wert des Ergebnisses, Gewinn
--     nach AH-Gebühr
--   * die besten Rezepte nach Gewinn (Klick wählt das Rezept)
--   * Materialien für N-mal herstellen als Einkaufsliste anlegen
-- Preise: Marktwert (Median 14 Tage) aus deinen Scans.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local Cr = {}
A.Crafting = Cr


local function IDFromLink(link)
    return type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil
end

local function SafeCall(fn, ...)
    if not fn then return nil end
    local r = { pcall(fn, ...) }
    if not r[1] then
        if A.ReportOnce then A:ReportOnce(fn, "SafeCall:Berufe", r[2]) end
        return nil
    end
    return unpack(r, 2)
end

-- ------------------------------------------------------------
-- Zwei Arten von Berufsfenstern in Classic:
--   "trade" = Handwerk (TradeSkill-API), "craft" = Verzauberkunst (Craft-API)
-- ------------------------------------------------------------
local API = {
    trade = {
        num = function() return GetNumTradeSkills and SafeCall(GetNumTradeSkills) or 0 end,
        info = function(i)
            local name, kind = SafeCall(GetTradeSkillInfo, i)
            return name, kind
        end,
        link = function(i) return GetTradeSkillItemLink and SafeCall(GetTradeSkillItemLink, i) end,
        made = function(i)
            if not GetTradeSkillNumMade then return 1, 1 end
            local lo, hi = SafeCall(GetTradeSkillNumMade, i)
            return lo or 1, hi or lo or 1
        end,
        numReagents = function(i) return GetTradeSkillNumReagents and SafeCall(GetTradeSkillNumReagents, i) or 0 end,
        reagent = function(i, r)
            local name, _, count, have = SafeCall(GetTradeSkillReagentInfo, i, r)
            local link = GetTradeSkillReagentItemLink and SafeCall(GetTradeSkillReagentItemLink, i, r)
            return name, count, have, link
        end,
        selected = function() return GetTradeSkillSelectionIndex and SafeCall(GetTradeSkillSelectionIndex) end,
        select = function(i)
            if TradeSkillFrame_SetSelection then pcall(TradeSkillFrame_SetSelection, i) end
            if TradeSkillFrame_Update then pcall(TradeSkillFrame_Update) end
        end,
        title = function() return GetTradeSkillLine and SafeCall(GetTradeSkillLine) end,
        frame = function() return type(TradeSkillFrame) == "table" and TradeSkillFrame or nil end,
        -- aktuelle Nummer eines Rezepts (die Liste verschiebt sich durch Filter und zugeklappte Kategorien)
        find = function(r)
            for i = 1, (GetNumTradeSkills and SafeCall(GetNumTradeSkills) or 0) do
                local name, kind = SafeCall(GetTradeSkillInfo, i)
                if name == r.name and kind ~= "header" then return i end
            end
            return nil
        end,
        -- Suchtext und Filter zurücksetzen, alle Kategorien aufklappen (nur Blizzard-Funktionen aufrufen)
        reveal = function()
            if SetTradeSkillItemNameFilter then pcall(SetTradeSkillItemNameFilter, "") end
            if TradeSkillFrameEditBox and TradeSkillFrameEditBox.SetText then pcall(TradeSkillFrameEditBox.SetText, TradeSkillFrameEditBox, "") end
            if SetTradeSkillSubClassFilter then pcall(SetTradeSkillSubClassFilter, 0, 1, 1) end
            if SetTradeSkillInvSlotFilter then pcall(SetTradeSkillInvSlotFilter, 0, 1, 1) end
            if TradeSkillOnlyShowMakeable then pcall(TradeSkillOnlyShowMakeable, false) end
            if ExpandTradeSkillSubClass then pcall(ExpandTradeSkillSubClass, 0) end
        end,
        -- gewähltes Rezept in die Ansicht scrollen
        scrollTo = function(i)
            if TradeSkillListScrollFrame and FauxScrollFrame_SetOffset then
                pcall(FauxScrollFrame_SetOffset, TradeSkillListScrollFrame, math.max(0, i - 2))
                if TradeSkillListScrollFrameScrollBar and TradeSkillListScrollFrameScrollBar.SetValue and TRADE_SKILL_HEIGHT then
                    pcall(TradeSkillListScrollFrameScrollBar.SetValue, TradeSkillListScrollFrameScrollBar, math.max(0, i - 2) * TRADE_SKILL_HEIGHT)
                end
            end
            if TradeSkillFrame_Update then pcall(TradeSkillFrame_Update) end
        end,
    },
    craft = {
        num = function() return GetNumCrafts and SafeCall(GetNumCrafts) or 0 end,
        info = function(i)
            local name, _, kind = SafeCall(GetCraftInfo, i)
            return name, kind
        end,
        link = function(i) return GetCraftItemLink and SafeCall(GetCraftItemLink, i) end,
        made = function(i) return 1, 1 end,
        numReagents = function(i) return GetCraftNumReagents and SafeCall(GetCraftNumReagents, i) or 0 end,
        reagent = function(i, r)
            local name, _, count, have = SafeCall(GetCraftReagentInfo, i, r)
            local link = GetCraftReagentItemLink and SafeCall(GetCraftReagentItemLink, i, r)
            return name, count, have, link
        end,
        selected = function() return GetCraftSelectionIndex and SafeCall(GetCraftSelectionIndex) end,
        select = function(i)
            if CraftFrame_SetSelection then pcall(CraftFrame_SetSelection, i) end
            if CraftFrame_Update then pcall(CraftFrame_Update) end
        end,
        title = function() return GetCraftDisplaySkillLine and SafeCall(GetCraftDisplaySkillLine) end,
        frame = function() return type(CraftFrame) == "table" and CraftFrame or nil end,
        find = function(r)
            for i = 1, (GetNumCrafts and SafeCall(GetNumCrafts) or 0) do
                local name, _, kind = SafeCall(GetCraftInfo, i)
                if name == r.name and kind ~= "header" then return i end
            end
            return nil
        end,
        reveal = function()
            if ExpandCraftSkillLine then pcall(ExpandCraftSkillLine, 0) end
        end,
    },
}

-- ------------------------------------------------------------
-- Moderner Client (WoW Forever, Retail): C_TradeSkillUI statt der alten TradeSkill-Funktionen.
-- Über dieselben Zugriffe wie oben (Nummer i = i-tes gelerntes Rezept), damit der Rest gleich bleibt.
-- ------------------------------------------------------------
local TS = C_TradeSkillUI
local modernIDs, modernDirty, modernProf = {}, true, nil
local schemCache = {}
-- Liste der gelernten Rezepte nur neu lesen, wenn sie sich geändert haben kann (Fenster offen, Liste
-- aktualisiert). Die Schemata (Zutaten) gehören fest zur Rezept-ID: sie werden nur beim Wechsel der
-- Datenquelle bzw. des Berufs neu gelesen - sonst würde jedes Listen-Ereignis alles neu lesen (ruckelt).
function Cr:InvalidateModern(full)
    modernDirty = true
    if full then wipe(schemCache) end
end
local function ModernIDs()
    if not modernDirty then return modernIDs end
    modernDirty = false
    local base = TS and TS.GetBaseProfessionInfo and SafeCall(TS.GetBaseProfessionInfo)
    local prof = type(base) == "table" and (base.professionID or base.professionName) or nil
    if prof ~= modernProf then wipe(schemCache); modernProf = prof end
    modernIDs = {}
    local all = TS and TS.GetAllRecipeIDs and SafeCall(TS.GetAllRecipeIDs) or {}
    for _, id in ipairs(all) do
        local info = TS.GetRecipeInfo and SafeCall(TS.GetRecipeInfo, id)
        if type(info) == "table" and info.learned and not info.isDummyRecipe and not info.isRecraft then
            table.insert(modernIDs, id)
        end
    end
    return modernIDs
end
-- nur lesen (Testroutine T147/T148): i-te gelernte Rezept-ID und Grösse des Zwischenspeichers
function Cr:ModernRecipeID(i) return ModernIDs()[i or 1] end
function Cr:SchematicCacheSize()
    local n = 0
    for _ in pairs(schemCache) do n = n + 1 end
    return n
end
local function Schematic(i)
    local id = ModernIDs()[i]
    if not id then return nil end
    local sc = schemCache[id]
    if sc == nil then
        sc = TS.GetRecipeSchematic and SafeCall(TS.GetRecipeSchematic, id, false) or false
        schemCache[id] = sc
    end
    return sc or nil, id
end
-- nur die Pflicht-Zutaten (keine optionalen / Verfeinerungs-Zutaten)
local function BasicSlots(sc)
    local out = {}
    local basic = Enum and Enum.CraftingReagentType and Enum.CraftingReagentType.Basic
    for _, slot in ipairs(sc and sc.reagentSlotSchematics or {}) do
        local isBasic = (basic and slot.reagentType == basic) or (not basic and slot.required ~= false)
        if isBasic and (slot.quantityRequired or 0) > 0 and slot.reagents and slot.reagents[1] and slot.reagents[1].itemID then
            table.insert(out, slot)
        end
    end
    return out
end
local function CountItem(itemID)
    if C_Item and C_Item.GetItemCount then return SafeCall(C_Item.GetItemCount, itemID) or 0 end
    if GetItemCount then return SafeCall(GetItemCount, itemID) or 0 end
    return 0
end
API.modern = {
    num = function() return #ModernIDs() end,
    info = function(i)
        local id = ModernIDs()[i]
        local info = id and SafeCall(TS.GetRecipeInfo, id)
        if type(info) ~= "table" then return nil end
        return info.name, "optimal"
    end,
    link = function(i)
        local sc = Schematic(i)
        return sc and sc.outputItemID and ("item:" .. sc.outputItemID) or nil
    end,
    made = function(i)
        local sc = Schematic(i)
        if not sc then return 1, 1 end
        return sc.quantityMin or 1, sc.quantityMax or sc.quantityMin or 1
    end,
    numReagents = function(i) return #BasicSlots((Schematic(i))) end,
    reagent = function(i, r)
        local slot = BasicSlots((Schematic(i)))[r]
        if not slot then return nil end
        local itemID = slot.reagents[1].itemID
        return A:GetItemName(itemID), slot.quantityRequired, CountItem(itemID), "item:" .. itemID
    end,
    selected = function()
        -- gerade gewähltes Rezept im Berufsfenster (falls das Fenster es verrät)
        local f = ProfessionsFrame
        local form = f and f.CraftingPage and f.CraftingPage.SchematicForm
        local cur = form and (form.currentRecipeInfo or (form.GetRecipeInfo and SafeCall(form.GetRecipeInfo, form)))
        local rid = type(cur) == "table" and cur.recipeID
        if rid then Cr.lastModernRecipe = rid else rid = Cr.lastModernRecipe end
        if not rid then return nil end
        for i, id in ipairs(ModernIDs()) do if id == rid then return i end end
        return nil
    end,
    -- Auswahl sofort über die Rezeptliste des Berufsfensters (wählt und scrollt im selben Frame);
    -- nur wenn das nicht geht über C_TradeSkillUI.OpenRecipe. Liefert den Weg ("Liste"/"OpenRecipe").
    select = function(i)
        local id = ModernIDs()[i]
        if not id then return nil end
        Cr.lastModernRecipe = id
        local page = ProfessionsFrame and ProfessionsFrame.CraftingPage
        local list = page and page.RecipeList
        local info = TS.GetRecipeInfo and SafeCall(TS.GetRecipeInfo, id)
        if list and list.SelectRecipe and type(info) == "table" then
            if pcall(list.SelectRecipe, list, info, true) then return "Liste" end
        end
        if TS.OpenRecipe and pcall(TS.OpenRecipe, id) then return "OpenRecipe" end
        return nil
    end,
    -- wirklich im Berufsfenster gewähltes Rezept (ohne den gemerkten Rückfall) - für die Erfolgsprüfung
    current = function()
        local page = ProfessionsFrame and ProfessionsFrame.CraftingPage
        local form = page and page.SchematicForm
        if not form then return nil end
        local cur = form.currentRecipeInfo or (form.GetRecipeInfo and SafeCall(form.GetRecipeInfo, form))
        return type(cur) == "table" and cur.recipeID or nil
    end,
    find = function(r)
        local ids = ModernIDs()
        if r.recipeID then for i, id in ipairs(ids) do if id == r.recipeID then return i end end end
        return nil
    end,
    -- Suchtext und Filter des Berufsfensters zurücksetzen (nur über C_TradeSkillUI, keine Blizzard-Rahmen anfassen)
    reveal = function()
        local calls = { { "SetRecipeItemNameFilter", "" }, { "SetOnlyShowMakeableRecipes", false },
            { "SetOnlyShowSkillUpRecipes", false }, { "SetShowLearned", true },     -- "Ungelernte zeigen" bleibt, wie der Spieler es hat
            { "ClearInventorySlotFilter" }, { "ClearRecipeCategoryFilter" }, { "ClearRecipeSourceTypeFilter" } }
        for _, c in ipairs(calls) do
            local fn = TS and TS[c[1]]
            if fn then if c[2] ~= nil then pcall(fn, c[2]) else pcall(fn) end end
        end
    end,
    title = function()
        local info = (TS.GetChildProfessionInfo and SafeCall(TS.GetChildProfessionInfo))
            or (TS.GetBaseProfessionInfo and SafeCall(TS.GetBaseProfessionInfo))
        return type(info) == "table" and (info.professionName or info.parentProfessionName) or nil
    end,
    frame = function()
        if type(ProfessionsFrame) == "table" then return ProfessionsFrame end
        return type(TradeSkillFrame) == "table" and TradeSkillFrame or nil
    end,
}
-- Welche Schnittstelle hat der Client? Alte Funktionen zuerst (Classic Era, TBC, Wrath, Cata, MoP),
-- sonst C_TradeSkillUI (WoW Forever, Retail)
function Cr:TradeKind()
    if A:Global("GetNumTradeSkills") then return "trade" end      -- A:API: ohne Testroutine = GetNumTradeSkills
    local ts = A:Global("C_TradeSkillUI")
    if ts and ts.GetAllRecipeIDs then return "modern" end
    return "trade"
end
Cr.API = API
Cr.kind = nil          -- gerade offenes Berufsfenster: "trade" / "craft" / nil

-- Preis eines Materials/Ergebnisses: Marktwert, sonst aktuelles Angebot
-- Materialien: beim Händler kaufen, wenn das billiger ist (Preis wird beim Händler gelesen)
function Cr:UnitPrice(itemID, isReagent)
    if not itemID then return nil end
    -- realer Wert aus der einen Preisfunktion (eigene Verkäufe -> Sofortpreis -> Median)
    local mv = A:RealPrice(itemID)
    if not mv then
        local pr = A.Seller and A.Seller:GetPriceInfo(itemID)
        mv = pr and pr.lowestOther or nil
    end
    if isReagent then
        local buy = A:GetVendorBuyPrice(itemID)
        if buy and (not mv or buy < mv) then return buy, true end
    end
    return mv
end

-- ------------------------------------------------------------
-- Bester Weg (Anweisung "Entzauber-Urteil" Teil 2, 9. Nov. 13:05)
-- Je Zutat der günstigste Weg: AH kaufen, beim Händler kaufen oder selbst herstellen aus einem Rezept, das der
-- Charakter im offenen Beruf KENNT (z. B. Leinenstoffballen = 2 Leinenstoff). Höchstens 2 Stufen, keine Schleifen.
-- ------------------------------------------------------------
Cr.CRAFT_DEPTH = 2
Cr.SERIES = 20                -- BR-W1: Zutaten-Preis für eine Serie von 20 Herstellungen (Preisleiter)
-- Rezepte des offenen Berufs: [productID] = { made, reagents = { { itemID, Menge }, ... }, name }
-- Nahtstelle für die Testroutine: Cr.testRecipeIndex
-- cachedOnly: nur den gemerkten Stand liefern (oberer Teil des Fensters, ausserhalb der Hintergrund-Arbeit) -
-- das Lesen aller Rezepte läuft nur in der Hintergrund-Arbeit (A:Job, verteilt über mehrere Frames).
function Cr:RecipeIndex(kind, cachedOnly)
    if self.testRecipeIndex then return self.testRecipeIndex end
    kind = kind or self.readKind or self.kind
    if not kind or not API[kind] then return {} end
    local c = self.recipeIndexCache
    if cachedOnly or self.indexCachedOnly then return (c and c.kind == kind) and c.map or {} end
    local api = API[kind]
    local num = api.num() or 0
    if c and c.kind == kind and c.n == num and not self.indexDirty then return c.map end
    local map = {}
    for i = 1, num do
        A:Pause()
        local name, skillType = api.info(i)
        if name and skillType ~= "header" then
            local pid = IDFromLink(api.link(i))
            if pid and not map[pid] then
                local lo, hi = api.made(i)
                local re = {}
                for k = 1, api.numReagents(i) do
                    local _, cnt, _, link = api.reagent(i, k)
                    local id = IDFromLink(link)
                    if id then re[#re + 1] = { id, cnt or 1 } end
                end
                if #re > 0 then map[pid] = { made = ((lo or 1) + (hi or lo or 1)) / 2, reagents = re, name = name } end
            end
        end
    end
    self.recipeIndexCache = { kind = kind, n = num, map = map }
    self.indexDirty = nil
    return map
end

-- BR-W1/BR-LEER1: Ø-Stückpreis für n Stück über die Angebotsliste (A:OfferLadder); was die Liste nicht hergibt, zum teuersten
-- Preis darin. Ohne Liste nil (dann gilt der Stückpreis wie vorher). Rechnet nichts anderes, hält nie an.
function Cr:SeriesUnit(itemID, n, unit)
    local okL, ladder = pcall(A.OfferLadder, A, itemID)
    if not (okL and type(ladder) == "table" and #ladder > 0 and n and n > 0) then return nil end
    local left, cost, last = n, 0, unit or 0
    for _, st in ipairs(ladder) do
        if left <= 0 then break end
        local p, q = st[1], st[2] or 0
        if p and q > 0 then
            local take = math.min(left, q)
            cost, left, last = cost + take * p, left - take, math.max(last, p)
        end
    end
    if left > 0 then cost = cost + left * last end
    return cost / n
end
-- günstigster Stückpreis einer Zutat: unit, how ("ah" / "vendor" / "craft"), Rezept (bei "craft")
function Cr:BestUnit(itemID, depth, visiting)
    if not itemID then return nil end
    local unit, atVendor = self:UnitPrice(itemID, true)
    local how = unit and (atVendor and "vendor" or "ah") or nil
    depth = depth or 0
    if depth < self.CRAFT_DEPTH then
        local rec = self:RecipeIndex()[itemID]
        visiting = visiting or {}
        if rec and not visiting[itemID] then
            visiting[itemID] = true
            local sum, ok = 0, true
            for _, re in ipairs(rec.reagents) do
                local u = self:BestUnit(re[1], depth + 1, visiting)
                if not u then ok = false; break end
                sum = sum + u * re[2]
            end
            visiting[itemID] = nil
            if ok then
                local cu = sum / math.max(rec.made or 1, 1)
                if not unit or cu < unit then return cu, "craft", rec end
            end
        end
    end
    return unit, how
end

-- API-PM3 / RK3: Kosten für need Stück einer Zutat über die Preisleiter (nicht günstigstes Einzelstück × Menge).
-- Händler-Zutaten zum Händlerpreis, selbst hergestellte zum Herstellpreis; AH: Stufen der Angebotsliste aufsteigend,
-- was die Leiter nicht hergibt, zum teuersten bekannten Preis (mindestens Stückpreis). Rückgabe: Kosten, Weg, Stufen.
function Cr:LadderCost(itemID, need)
    local unit, how = self:BestUnit(itemID, 1)
    if not unit then return nil end
    need = math.max(0, need or 0)
    if how ~= "ah" or need <= 0 then return unit * need, how, 0 end
    local okL, ladder = pcall(A.OfferLadder, A, itemID)
    if not (okL and type(ladder) == "table" and #ladder > 0) then return unit * need, how, 0 end
    local left, cost, steps, last = need, 0, 0, unit
    for _, st in ipairs(ladder) do
        if left <= 0 then break end
        local p, q = st[1], st[2] or 0
        if p and q > 0 then
            local take = math.min(left, q)
            cost, left, steps, last = cost + take * p, left - take, steps + 1, p
        end
    end
    if left > 0 then cost = cost + left * math.max(last, unit) end
    return cost, how, steps
end

-- Bedarf einer Zutat in einkaufbare Zutaten auflösen (selbst hergestellte Zwischenprodukte -> ihre Zutaten)
function Cr:ExpandNeed(itemID, qty, out, depth)
    out = out or {}
    local _, how, rec = self:BestUnit(itemID, depth or 0)
    if how == "craft" and rec then
        local crafts = math.ceil(qty / math.max(rec.made or 1, 1))
        for _, re in ipairs(rec.reagents) do self:ExpandNeed(re[1], crafts * re[2], out, (depth or 0) + 1) end
    else
        out[itemID] = (out[itemID] or 0) + qty
    end
    return out
end

-- Entzauberungswert des Ergebnisses (nach Gebühren, für made Stück) oder nil (nicht entzauberbar)
function Cr:DisenchantValue(productID, made)
    local D = A.Disenchant
    if not (D and productID and D.Prior and D:Prior(productID)) then return nil end
    local _, net = D:DealValue(productID)
    if not net then return nil end
    return math.floor(net * (made or 1) + 0.5)
end

-- ein Rezept vollständig lesen und bewerten
function Cr:ReadRecipe(kind, i)
    local api = API[kind]
    self.readKind = kind
    local name, skillType = api.info(i)
    if not name or skillType == "header" then return nil end
    local productID = IDFromLink(api.link(i))
    local lo, hi = api.made(i)
    local made = ((lo or 1) + (hi or lo or 1)) / 2
    local r = { index = i, name = name, productID = productID, made = made, reagents = {}, cost = 0, missing = 0, kind = kind,
                recipeID = kind == "modern" and ModernIDs()[i] or nil }
    for k = 1, api.numReagents(i) do
        local rname, count, have, link = api.reagent(i, k)
        local id = IDFromLink(link)
        local unit, atVendor = self:UnitPrice(id, true)
        -- Werte stimmen, Punkt 9: eigene Materialien kosten, was man beim Verkauf bekäme (realer Wert nach Gebühren);
        -- fehlende kauft man (Sofortpreis); Händlerware = Händlerpreis
        local need = count or 1
        local own = math.min(have or 0, need)
        local cost
        if unit then
            cost = unit * need
            -- BR-W1 (Screenshot 14:54, Wollstoffballen +1s 66c statt ≈ +16c): was man kaufen muss, kostet den Preis, zu dem die
            -- Menge für eine Serie (Cr.SERIES Herstellungen) wirklich kaufbar ist (Preisleiter), nicht das billigste Einzelangebot
            -- BR-LEER1: nur die Angebotsliste lesen (kein Rezept-Index, keine Hintergrund-Pause); ohne Liste bleibt es beim Preis
            if not atVendor and need > own then
                local u2 = self:SeriesUnit(id, need * self.SERIES, unit)
                if u2 and u2 > unit then cost = cost + (u2 - unit) * (need - own) end
            end
            if own > 0 and not atVendor then
                local ownValue = A:RealValue(id, own)
                if ownValue then cost = ownValue + unit * (need - own) end
            end
        end
        -- selbst herstellen günstiger? (bekanntes Rezept, höchstens 2 Stufen)
        local via, rec
        local bu, how, brec = self:BestUnit(id, 0)
        if how == "craft" and bu and (not cost or bu * need < cost) then
            cost, via, rec = bu * need, "craft", brec
        elseif atVendor and unit then
            via = "vendor"
        end
        table.insert(r.reagents, { itemID = id, name = rname or (id and A:GetItemName(id)) or "?", count = need,
                                   have = have or 0, unit = unit, atVendor = atVendor, cost = cost, own = own, via = via, rec = rec })
        if cost then r.cost = r.cost + cost else r.missing = r.missing + 1 end
    end
    local unitValue = productID and self:UnitPrice(productID)
    if unitValue then
        r.value = math.floor(unitValue * made + 0.5)
        -- AH-Gebühr: 5 % beim Verkauf (alle Versionen); Forever dazu das Einzahlungsrisiko (RealValue, Neu-Einstellungen)
        r.net = math.floor(A:NetSale(productID, unitValue, made) + 0.5)
        -- offener Punkt 2: AH-Gebühr getrennt (nur 5 %); erwarteter Einzahlungsverlust und Händler-Untergrenze extra
        r.fee = A:SaleFee(productID, unitValue, made)
        local afterFee = r.net
        -- erwartete Neu-Einstellungen (Punkt 6) und Händlerpreis-Untergrenze aus der einen Preisfunktion
        local rv, _, rinfo, vendorWins = A:RealValue(productID, made)
        if rv then
            r.net = math.floor(rv + 0.5)
            if vendorWins then r.vendorWins = r.net
            elseif afterFee > r.net then r.relist, r.relistRate = afterFee - r.net, rinfo and rinfo.listings end
        end
        -- R1 (Befund Testroutine 0.65.65): Forever hat eine Einzahlung je Auktion (Händlerpreis × 5 % je 2 Std., mind. 1s),
        -- zurück beim Verkauf, verloren bei Ablauf/Abbruch (belegt). Angezeigt mit der Standard-Laufzeit; der erwartete
        -- Verlust steckt schon in r.net (Neu-Einstellungen).
        r.deposit = 0
        if A:IsForever() and A.ListingDeposit then
            local hours = A.DURATION_HOURS[A:StandardDurationStep()] or 2
            local size = A:AuctionSize(productID, made)
            local okD, dep = pcall(A.ListingDeposit, A, productID, made, hours, math.max(1, math.ceil(made / math.max(size, 1))))
            if okD and type(dep) == "number" then r.deposit = dep end
        end
    end
    -- Wert = das Bessere aus Verkaufen (r.net) und Entzaubern (nur wenn entzauberbar)
    r.deNet = self:DisenchantValue(productID, made)
    if r.missing == 0 then
        if r.net then r.sellProfit = r.net - r.cost end
        if r.deNet then r.deProfit = r.deNet - r.cost end
        if r.deProfit and (not r.sellProfit or r.deProfit > r.sellProfit) then
            r.profit, r.best = r.deProfit, "de"
        elseif r.sellProfit then
            r.profit, r.best = r.sellProfit, "sell"
        end
    end
    return r
end

-- GW-S1 (Screenshot 14:35): "Händler zahlt mehr" heisst: mehr als der AH-Verkauf. Ist Entzaubern der beste Weg, widerspricht
-- "mehr" der Zeile "bester Weg: entzaubern" -> dann nur "Händler: x" (Betrag zur Info), sonst wie bisher.
function Cr:VendorNote(r)
    if not (r and r.vendorWins) then return nil end
    if r.best == "de" then return string.format(L["Händler: %s"], A:FormatMoney(r.vendorWins)) end
    return string.format(L["Händler zahlt mehr: %s"], A:FormatMoney(r.vendorWins))
end
-- Herkunft der Materialien für die graue Zeile unter "Materialkosten" (nur wenn nicht alles aus dem AH)
function Cr:OriginText(r)
    local parts = {}
    for _, re in ipairs(r and r.reagents or {}) do
        if re.via == "craft" and re.rec then
            local subs = {}
            for _, x in ipairs(re.rec.reagents) do subs[#subs + 1] = A:GetItemName(x[1]) or ("#" .. x[1]) end
            parts[#parts + 1] = string.format(L["%s aus %s (günstiger)"], re.name, table.concat(subs, ", "))
        elseif re.via == "vendor" then
            parts[#parts + 1] = string.format(L["%s beim Händler"], re.name)
        end
    end
    return table.concat(parts, " · ")
end

function Cr:ReadAll(kind)
    kind = kind or self.kind
    local out = {}
    -- TB138b-1: Berufsart ohne Schnittstelle (z. B. Testart nach der Testroutine entfernt, Fenster zu) -> leer statt Lua-Fehler
    local api = kind and API[kind]
    if not (api and api.num) then return out end
    local okN, num = pcall(api.num)
    for i = 1, (okN and tonumber(num)) or 0 do
        local r = self:ReadRecipe(kind, i)
        if r then table.insert(out, r) end
        A:Pause()
    end
    return out
end

-- die besten Rezepte (mit bekanntem Gewinn)
function Cr:Top(kind, n)
    local list = {}
    for _, r in ipairs(self:ReadAll(kind)) do
        if r.profit then table.insert(list, r) end
    end
    table.sort(list, function(a, b) return a.profit > b.profit end)
    local out = {}
    for k = 1, math.min(n or 10, #list) do out[k] = list[k] end
    return out, #list
end

-- Materialien für "times"-mal herstellen auf eine Einkaufsliste (Name = Beruf)
function Cr:ReagentsToList(kind, index, times)
    local r = self:ReadRecipe(kind, index)
    if not r then return false, L["Kein Rezept gewählt."] end
    times = math.max(1, math.floor(tonumber(times) or 1))
    local listName = API[kind].title() or L["Berufe"]
    if not A.Lists:Exists(listName) then A.Lists:Create(listName) end
    local added = 0
    -- tatsächlich gewählte Zutaten: selbst hergestellte Zwischenprodukte werden in ihre Zutaten aufgelöst
    local need = {}
    for _, re in ipairs(r.reagents) do
        if re.itemID then
            if re.via == "craft" then self:ExpandNeed(re.itemID, re.count * times, need, 0)
            else need[re.itemID] = (need[re.itemID] or 0) + re.count * times end
        end
    end
    local ids = {}
    for id in pairs(need) do ids[#ids + 1] = id end
    table.sort(ids)
    for _, id in ipairs(ids) do
        A.Lists:AddItem(listName, tostring(id), need[id])
        added = added + 1
    end
    if added == 0 then return false, L["Keine Materialien mit bekanntem Item gefunden."] end
    return true, string.format(L["Materialien für %dx %s auf die Liste '%s' gesetzt."], times, r.name, listName), listName
end

-- Nur was fehlt: Bedarf minus Bestand (Taschen, Bank, alle Twinks) auf die Einkaufsliste
function Cr:MissingToList(kind, index, times)
    local r = self:ReadRecipe(kind, index)
    if not r then return false, L["Kein Rezept gewählt."] end
    times = math.max(1, math.floor(tonumber(times) or 1))
    local listName = API[kind].title() or L["Berufe"]
    local added, complete = 0, 0
    for _, re in ipairs(r.reagents) do
        if re.itemID then
            local need = re.count * times
            local have = re.have or 0
            if A.Chars and A.Chars.ItemCounts then
                -- eigene Taschen live (re.have), dazu eigene Bank und alle Twinks
                for _, c in ipairs((A.Chars:ItemCounts(re.itemID))) do
                    if c.me then have = have + (c.bank or 0) else have = have + (c.bags or 0) + (c.bank or 0) end
                end
            end
            local missing = need - have
            if missing > 0 then
                if not A.Lists:Exists(listName) then A.Lists:Create(listName) end
                if re.via == "craft" then
                    -- fehlendes Zwischenprodukt: dessen Zutaten einkaufen (gewählter Weg)
                    for id, q in pairs(self:ExpandNeed(re.itemID, missing, {}, 0)) do A.Lists:AddItem(listName, tostring(id), q) end
                else
                    A.Lists:AddItem(listName, tostring(re.itemID), missing)
                end
                added = added + 1
            else
                complete = complete + 1
            end
        end
    end
    if added == 0 then
        return true, string.format(L["Du hast schon alles für %dx %s (Taschen, Bank und Twinks)."], times, r.name)
    end
    return true, string.format(L["Fehlende Materialien für %dx %s auf die Liste '%s' gesetzt (%d schon vorhanden)."], times, r.name, listName, complete), listName
end

-- ------------------------------------------------------------
-- Fenster neben dem Berufsfenster
-- ------------------------------------------------------------
function Cr:Enabled()
    return not (A.db and A.db.settings.craftPanel == false)
end

-- Schnittstelle für andere Addons (ProfessionSentinel dockt rechts daran an): das sichtbare Gewinn-Fenster am
-- Berufsfenster oder nil. Stabil halten. Hinweis: Nach einem Design-Wechsel wird der Rahmen neu gebaut -
-- deshalb jedes Mal neu abfragen statt den Rahmen dauerhaft zu merken.
-- includeHidden = true: den Rahmen auch verborgen liefern (zum Einhängen in OnShow/OnHide), nil = noch nicht gebaut.
function Cr:GetDockFrame(includeHidden)
    local f = self.panel
    if not f then return nil end
    if includeHidden then return f end
    if f.IsShown and f:IsShown() then return f end
    return nil
end

function Cr:EnsurePanel()
    if self.panel then return self.panel end
    local UI = A.UI
    local C = UI.C
    local f = CreateFrame("Frame", "AHAnalyzerProCraftPanel", UIParent)
    if A.RegisterUI then A.RegisterUI(f, "Gewinn-Fenster") end
    -- Zeile Einstellgebühr nur in WoW Forever; sonst rückt alles darunter 16 Punkte nach oben (keine Leerzeile in Era/TBC)
    local dy = A:IsForever() and 0 or 16
    f:SetSize(300, 510 - dy)
    f:SetFrameStrata("HIGH")
    f:EnableMouse(true)
    UI:Box(f, C.bg, C.frameEdge, UI:IsClassic() and 2 or 1)
    f:Hide()

    f.title = UI:Label(f, "|cff00d1d1AHSentinel|r  " .. L["Gewinn"], "GameFontNormal", C.accent)
    f.title:SetPoint("TOPLEFT", 12, -10)
    f.close = UI:CloseButton(f, function() f:Hide(); Cr.closedByUser = true end)
    f.close:SetPoint("TOPRIGHT", -4, -4)

    f.recipe = UI:Label(f, "", "GameFontNormalSmall", C.text)
    f.recipe:SetPoint("TOPLEFT", 12, -34)
    f.recipe:SetWidth(276)
    if f.recipe.SetWordWrap then f.recipe:SetWordWrap(false) end

    local function row(label, y)
        local l = UI:Label(f, label, "GameFontHighlightSmall", C.textDim)
        l:SetPoint("TOPLEFT", 12, y)
        local v = UI:Label(f, "-", "GameFontHighlightSmall", C.text)
        v:SetPoint("TOPRIGHT", -12, y)
        v:SetJustifyH("RIGHT")
        v:SetWidth(150)
        return v, l
    end
    f.cost = row(L["Materialkosten"], -54)
    -- Herkunft der Materialien (klein, grau; nur wenn nicht alles aus dem AH)
    f.origin = UI:Label(f, "", "GameFontDisableSmall", C.textDim)
    f.origin:SetPoint("TOPLEFT", 12, -67)
    f.origin:SetWidth(276)
    if f.origin.SetWordWrap then f.origin:SetWordWrap(false) end
    f.value = row(L["Wert des Ergebnisses"], -82)
    f.cut, f.cutLabel = row(L["AH-Gebühr (5 %)"], -98)
    -- lange Beschriftung (Forever: "AH-Gebühr 5 % + Einzahlung (zurück bei Verkauf)"): Platz teilen, nichts überlappt
    f.cut:SetWidth(80)
    f.cutLabel:SetWidth(196)
    if f.cutLabel.SetWordWrap then f.cutLabel:SetWordWrap(false) end
    f.deposit, f.depositLabel = row(L["Einstellgebühr"] .. L[" (nicht erstattet)"], -114)
    -- Annahme für die AH-Gebühr sichtbar und umschaltbar (Befund 11:31/11:32): "bei N Stück je Auktion"
    f.sizeBtn = UI:Button(f, "", 190, 16, function()
        local id = Cr.detailProduct
        if not id then return end
        A:CycleAuctionSize(id)
        Cr:RefreshDetail()
        if Cr.RequestRefresh then Cr:RequestRefresh(true, "auctionSize") end
    end)
    f.sizeBtn:SetPoint("TOPLEFT", 10, -112)
    -- Mindest-Einzahlung gemessen (A:MinDeposit, 1c-Hinweis 16:05) statt fest 1s
    f.sizeBtn.tooltip = string.format(L["So viele Stück stellst du je Auktion ein - danach verteilt sich die Mindest-Einzahlung (%s je Auktion).\nGelernt aus deinen letzten Einstellungen, sonst die ganze Menge als eine Auktion (Waren im modernen Auktionshaus). Klick: 1 / 5 / 20 / automatisch."],
        A:FormatMoney(A:MinDeposit()))
    f.profit = row(L["Gewinn"], -132 + dy)
    -- bester Weg (verkaufen / entzaubern) und der andere Weg mit Betrag, klein und grau
    f.way = UI:Label(f, "", "GameFontDisableSmall", C.textDim)
    f.way:SetPoint("TOPRIGHT", -12, -148 + dy)
    f.way:SetJustifyH("RIGHT")
    f.way:SetWidth(276)
    f.other = UI:Label(f, "", "GameFontDisableSmall", C.textDim)
    f.other:SetPoint("TOPRIGHT", -12, -160 + dy)
    f.other:SetJustifyH("RIGHT")
    f.other:SetWidth(276)
    f.note = UI:Label(f, "", "GameFontDisableSmall", C.textDim)
    f.note:SetPoint("TOPLEFT", 12, -176 + dy)
    f.note:SetWidth(276)

    f.times = UI:EditBox(f, 44, 22, "1")
    f.times:SetPoint("TOPLEFT", 12, -196 + dy)
    f.times:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    f.listBtn = UI:Button(f, L["Materialien als Einkaufsliste"], 226, 22, function()
        local idx = API[Cr.kind or "trade"].selected()
        local ok, msg, listName = Cr:ReagentsToList(Cr.kind, idx, tonumber(f.times:GetText()) or 1)
        A:Print(msg)
        if ok and A.UI.ShowLists then A.UI:ShowLists(listName) end
    end)
    f.listBtn:SetPoint("LEFT", f.times, "RIGHT", 6, 0)
    f.listBtn.tooltip = L["Legt die Materialien (x Anzahl links) als Einkaufsliste an.\nDort: Preise prüfen und als Sniper-Ziele kaufen."]
    f.missBtn = UI:Button(f, L["Nur was mir fehlt"], 226, 22, function()
        local idx = API[Cr.kind or "trade"].selected()
        local ok, msg, listName = Cr:MissingToList(Cr.kind, idx, tonumber(f.times:GetText()) or 1)
        A:Print(msg)
        if ok and listName and A.UI.ShowLists then A.UI:ShowLists(listName) end
    end, "primary")
    f.missBtn:SetPoint("TOPLEFT", f.listBtn, "BOTTOMLEFT", 0, -4)
    f.missBtn.tooltip = L["Wie oben, aber nur die fehlende Menge: Bedarf minus das,\nwas du in Taschen, Bank und bei deinen Twinks hast."]

    local th = UI:Label(f, L["Beste Rezepte (Gewinn)"], "GameFontNormalSmall", C.accent)
    th:SetPoint("TOPLEFT", 12, -256 + dy)
    f.top = UI:Table(f, {
        columns = {
            { key = "name", title = L["Rezept"], width = 150 },
            { key = "profit", title = L["Gewinn"], width = 98, align = "RIGHT" },
        },
        rows = 9,
        rowHeight = 20,
        itemTooltip = false,
        noMenu = true,
        idKey = "index",
        cell = function(r, key)
            if key == "name" then return r.name end
            local v = r.profit
            local tag = r.best == "de" and (" |cff999999" .. L["ent."] .. "|r") or (r.best == "sell" and (" |cff999999" .. L["verk."] .. "|r") or "")
            return (v >= 0 and ("|cff33dd55" .. A:FormatMoney(v, true) .. "|r") or ("|cffff5544-" .. A:FormatMoney(-v, true) .. "|r")) .. tag
        end,
        onClick = function(r) Cr:SelectRecipe(r) end,
        emptyText = L["Noch keine Preise.\nErst im Auktionshaus scannen."],
    })
    f.top:SetPoint("TOPLEFT", 10, -272 + dy)
    self.panel = f

    -- Auswahl im Berufsfenster verfolgen
    local last, acc = nil, 0
    f:SetScript("OnUpdate", function(_, dt)
        acc = acc + (dt or 0)
        if acc < 0.3 then return end
        acc = 0
        local idx = Cr.kind and API[Cr.kind].selected()
        if idx ~= last then last = idx; Cr:RefreshDetail() end
    end)
    return f
end

-- Oberer Teil (gewähltes Rezept): billig, sofort
function Cr:RefreshDetail()
    local f = self.panel
    if not f or not f:IsShown() or not self.kind then return end
    -- Forever: 5 % beim Verkauf + erwarteter Verlust der Einzahlung bei Rücklauf (Anweisung "Gebühren klassisch")
    local fv = A:IsForever()
    -- R1: Zeile Einzahlung nur in Forever (andere Versionen: kommt beim Verkauf zurück und steckt nicht im Gewinn)
    f.deposit:SetShown(fv); f.depositLabel:Hide()
    f.deposit:SetWidth(80)
    f.depositLabel:SetText(L["Einstellgebühr"] .. L[" (zurück bei Verkauf)"])
    local pct = math.floor(A:CutPct() * 100 + 0.5)
    if f.sizeBtn then
        f.sizeBtn.tooltip = string.format(L["So viele Stück stellst du je Auktion ein - danach verteilt sich die Mindest-Einzahlung (%s je Auktion).\nGelernt aus deinen letzten Einstellungen, sonst die ganze Menge als eine Auktion (Waren im modernen Auktionshaus). Klick: 1 / 5 / 20 / automatisch."],
            A:FormatMoney(A:MinDeposit()))
    end
    f.cutLabel:SetText(fv and string.format(L["AH-Gebühr %d %% + Einzahlung (zurück bei Verkauf)"], pct) or string.format(L["AH-Gebühr (%d %%)"], pct))
    local api = API[self.kind]
    local idx = api.selected()
    self.indexCachedOnly = true          -- kein Lesen aller Rezepte im oberen Teil (Ruckeln, Punkt G)
    local okR, r = pcall(function() return idx and self:ReadRecipe(self.kind, idx) end)
    self.indexCachedOnly = nil
    if not okR then r = nil end
    if r then
        f.recipe:SetText(r.name .. ((r.made ~= 1) and string.format("  (x%g)", r.made) or ""))
        f.cost:SetText(r.missing > 0 and (A:FormatMoney(r.cost) .. " |cffff5544+?|r") or A:FormatMoney(r.cost))
        f.value:SetText(r.value and A:FormatMoney(r.value) or "-")
        f.cut:SetText(r.value and A:FormatMoney(r.fee or math.max(0, r.value - r.net)) or "-")
        -- Annahme Stück je Auktion (nur Forever, nur stapelbare Ergebnisse)
        self.detailProduct = r.productID
        if fv and r.productID and A:StackSize(r.productID) > 1 then
            local n, src = A:AuctionSize(r.productID)
            local how = src == "own" and L["selbst gewählt"] or (src == "learned" and L["gelernt"] or (src == "whole" and L["eine Auktion"] or L["vorsichtig"]))
            f.sizeBtn:SetText(string.format(L["bei %d Stück je Auktion (%s)"], n, how))
            f.sizeBtn:Show()
        else
            f.sizeBtn:Hide()
            if fv then f.depositLabel:Show() end          -- ohne Umschalter steht links die Beschriftung
        end
        f.deposit:SetText(r.value and A:FormatMoney(r.deposit or 0) or "-")
        f.origin:SetText(self:OriginText(r))
        local function money(v) return v >= 0 and ("+" .. A:FormatMoney(v)) or ("-" .. A:FormatMoney(-v)) end
        if r.profit then
            f.profit:SetText(r.profit >= 0 and ("|cff33dd55" .. A:FormatMoney(r.profit) .. "|r") or ("|cffff5544-" .. A:FormatMoney(-r.profit) .. "|r"))
            -- A6: gleiche Rechnung wie Tooltip (A:RealValue) - "kaum"/Händler besser heisst hier "Händler"
            f.way:SetText(r.best == "de" and L["bester Weg: entzaubern"] or (r.vendorWins and L["bester Weg: Händler"] or L["bester Weg: verkaufen"]))
            if r.best == "de" and r.sellProfit then
                f.other:SetText(string.format(r.vendorWins and L["Händler %s"] or L["verkaufen %s"], money(r.sellProfit)))
            elseif r.best == "sell" and r.deProfit then f.other:SetText(string.format(L["entzaubern %s"], money(r.deProfit)))
            else f.other:SetText("") end
            -- Spieltest S3 prüft die Verkaufs-Rechnung (Wert - Gebühr - Material)
            if A.Spieltest and A.Spieltest.activeUntil then
                local copy = setmetatable({ profit = r.sellProfit }, { __index = r })
                pcall(A.Spieltest.OnCraftDetail, A.Spieltest, copy, f.depositLabel:IsShown())
            end
        else
            f.profit:SetText("-")
            f.way:SetText("")
            f.other:SetText("")
        end
        local notes = {}
        if not r.productID then table.insert(notes, L["Ergebnis ist kein Item (z.B. Verzauberung) - nur Kosten."])
        elseif not r.value then table.insert(notes, L["Für das Ergebnis gibt es noch keinen Preis."]) end
        if r.missing > 0 then table.insert(notes, string.format(L["%d Materialien ohne Preis (z.B. nur beim Händler)."], r.missing)) end
        -- was ausser der AH-Gebühr vom Wert abgeht (bzw. dass der Händler mehr zahlt)
        local vn = self:VendorNote(r)
        if vn then
            table.insert(notes, 1, vn)
        elseif r.relist and r.relist > 0 then
            -- P4: die benutzte Zahl Einstellungen zeigen (gleiche Rechnung wie Tooltip und Protokoll ABSATZ)
            local n = r.relistRate or 1
            table.insert(notes, 1, string.format(L["~%s Einstellungen: erwarteter Einzahlungsverlust −%s"],
                (n == math.floor(n)) and tostring(n) or string.format("%.1f", n), A:FormatMoney(r.relist)))
        end
        f.note:SetText(table.concat(notes, "\n"))
    else
        f.recipe:SetText(L["Kein Rezept gewählt."])
        for _, v in ipairs({ f.cost, f.value, f.cut, f.deposit, f.profit }) do v:SetText("-") end
        f.origin:SetText(""); f.way:SetText(""); f.other:SetText("")
        f.sizeBtn:Hide()
        f.note:SetText("")
    end
    -- Rangliste nur aus dem Zwischenspeicher zeichnen (die Zeilen behalten ihr Rezept, ein Klick geht nicht verloren)
    f.top.selectedID = idx
    f.top:Render()
end

-- Rangliste "Beste Rezepte": nur neu rechnen, wenn sich etwas geändert hat (Liste, Taschen, Preise), verteilt
-- über mehrere Frames (A:Job, höchstens A.FRAME_BUDGET ms pro Frame). Bis dahin bleibt die alte Liste stehen.
-- Nahtstellen für die Testroutine (G2 beim Herstellen: Zeit und Zeitgeber nachspielen)
Cr.Clock = function() return GetTime() end
Cr.After = function(sec, fn) if C_Timer and C_Timer.After then C_Timer.After(sec, fn) end end
Cr.topBuilds = 0
function Cr:Refresh()
    local f = self.panel
    if not f or not f:IsShown() or not self.kind then return end
    self:RefreshDetail()
    if self.topKind ~= self.kind then self.topDirty = true; self.topForce = true end
    if not self.topDirty then return end
    -- Ereignis-Sturm (Protokoll 0.65.16: AUFBAU ×192 durch TRADE_SKILL_LIST_UPDATE): höchstens ein Neuaufbau je
    -- TOP_MIN_GAP Sekunden und nie zwei gleichzeitig; Öffnen und Berufswechsel sofort. Bis dahin bleibt die alte Liste.
    local gap = self:Crafting() and self.CRAFT_GAP or self.TOP_MIN_GAP
    -- Protokoll 10.11. (AUFBAU ×13 durch DATA_CHANGED): Sniper und Sync melden alle paar Sekunden neue Preise - nur
    -- Preise neu: höchstens alle DATA_GAP Sekunden. Öffnen, Berufswechsel, Taschen und Buchhaltung bleiben schnell.
    if self.topReason == "DATA_CHANGED" and self:TopSignatureNoPrice() == self.topSigNoPrice then
        gap = math.max(gap, self.DATA_GAP)
    end
    local wait = self.topBuilding and 0.2
        or (not self.topForce and self.lastTopBuild and (gap - (Cr.Clock() - self.lastTopBuild)))
    if wait and wait > 0 then
        if not self.topLater then
            self.topLater = true
            Cr.After(wait, function() Cr.topLater = nil; Cr:Refresh() end)
        end
        return
    end
    -- Prüfsumme: nur neu rechnen, wenn sich Preise, Rezeptliste oder Buchhaltung wirklich geändert haben
    local sig = self:TopSignature()
    if not self.topForce and self.topReason ~= "auctionSize" and sig == self.topSig then
        self.topDirty = false
        self.topReason = nil
        self.topSkipped = (self.topSkipped or 0) + 1
        return
    end
    self.topSig = sig
    self.topSigNoPrice = self:TopSignatureNoPrice()
    self.topForce = nil
    self.lastTopBuild = Cr.Clock()
    self.topDirty = false
    local kind = self.kind
    local reason = self.topReason or "Öffnen"
    self.topReason = nil
    self.topBuilding = true
    local t0 = debugprofilestop and debugprofilestop() or 0
    A:Job("craft-top", function()
        local top, n = Cr:Top(kind, 9)
        Cr.topBuilds = Cr.topBuilds + 1
        Cr.topBuilding = nil
        A:Fire("CRAFT_TOP_BUILT", reason, (debugprofilestop and debugprofilestop() or 0) - t0, n)
        -- SK1-p (BR-LEER1): Liste leer, obwohl ein Scan jünger als 1 Std. und Rezepte da -> Abweichung
        local scanT = A.db and A.db.lastScanTime or 0
        local okNum, nr = pcall(function() return API[kind] and API[kind].num() or 0 end)
        if A.SelfCheck and time() - scanT < 3600 and okNum and (nr or 0) > 0 then
            pcall(A.SelfCheck.Note, A.SelfCheck, "p", (n or 0) > 0, string.format("Beste Rezepte leer: %d Rezepte, Scan vor %d Min.", nr, math.floor((time() - scanT) / 60)))
        end
        if Cr.kind ~= kind or not Cr.panel then return end
        Cr.topKind = kind
        Cr.panel.top.selectedID = API[kind].selected()
        Cr.panel.top:SetData(top, true)
    end)
end

-- Ereignisse sammeln (Punkt G, Protokoll 13:43-14:19): nur bei sichtbarem Gewinn-Fenster; frühestens REFRESH_DELAY
-- nach dem letzten Ereignis, spätestens nach TOP_MIN_GAP (beim Herstellen CRAFT_GAP) seit dem ersten.
Cr.REFRESH_DELAY = 1.5
Cr.TOP_MIN_GAP = 2           -- Sekunden zwischen zwei Neuaufbauten der Rangliste (ausser beim Öffnen)
Cr.CRAFT_GAP = 10            -- während Herstellen läuft
Cr.CRAFT_HOLD = 4            -- so lange nach einem eigenen Zauber gilt "Herstellen läuft"
function Cr:Crafting() return Cr.Clock() < (self.craftingUntil or 0) end

-- B4 (Befund 20:15): Herstellen verbraucht Material und legt Produkte in die Taschen - die Rangliste rechnet mit
-- eigenen Materialien, darum gehört der Tascheninhalt in die Prüfsumme (sonst nach dem Herstellen nie neu).
-- Ein Ereignis-Sturm ohne Änderung (TRADE_SKILL_LIST_UPDATE) baut weiter nicht neu auf.
function Cr:BagSignature()
    local CC = A:Global("C_Container")
    local nslots = (CC and CC.GetContainerNumSlots) or A:Global("GetContainerNumSlots")
    local info = CC and CC.GetContainerItemInfo
    local legacy = not info and A:Global("GetContainerItemInfo")
    if not nslots then return 0 end
    local sum = 0
    for bag = 0, 4 do
        local ok, n = pcall(nslots, bag)
        for slot = 1, (ok and tonumber(n) or 0) do
            local id, count
            if info then
                local okI, it = pcall(info, bag, slot)
                if okI and type(it) == "table" then id, count = it.itemID, it.stackCount end
            elseif legacy then
                local okI, _, c, _, _, _, _, link = pcall(legacy, bag, slot)
                if okI and type(link) == "string" then id, count = tonumber(link:match("item:(%d+)")), c end
            end
            local G = _G.GoldSentinelGame
            if G and G.AnySecret and G.AnySecret(id, count) then id = nil end      -- geschützte Werte nie rechnen
            if type(id) == "number" then sum = (sum + (id % 9973 + 1) * (tonumber(count) or 1) * (slot + bag * 40)) % 2147483647 end
        end
    end
    return sum
end

Cr.DATA_GAP = 30
-- Prüfsumme ohne Preis-Version: ändert sich nur, wenn Rezeptliste, Buchhaltung, Scan oder Taschen sich ändern
function Cr:TopSignatureNoPrice()
    local api = self.kind and API[self.kind]
    local n = api and (api.num() or 0) or 0
    local led = A.db and A.db.ledger and A.db.ledger.entries
    return table.concat({ tostring(self.kind), n, led and #led or 0, A.db and A.db.lastScanTime or 0, self:BagSignature() }, "|")
end

function Cr:TopSignature()
    local api = self.kind and API[self.kind]
    local n = api and (api.num() or 0) or 0
    local led = A.db and A.db.ledger and A.db.ledger.entries
    return table.concat({ tostring(self.kind), n, A.priceVersion or 0, led and #led or 0,
        A.db and A.db.lastScanTime or 0, self:BagSignature() }, "|")
end

function Cr:RequestRefresh(dataChanged, reason)
    if dataChanged then self.topDirty = true; self.indexDirty = true; self.topReason = reason or self.topReason end
    if not (self.panel and self.panel:IsShown()) then return end        -- unsichtbar: beim Öffnen neu
    local now = Cr.Clock()
    self.pendingSince = self.pendingSince or now
    self.lastEvent = now
    if self.refreshPlanned then return end
    self.refreshPlanned = true
    local function tick()
        local t = Cr.Clock()
        local maxWait = Cr:Crafting() and Cr.CRAFT_GAP or Cr.TOP_MIN_GAP
        if t - (Cr.lastEvent or t) >= Cr.REFRESH_DELAY or t - (Cr.pendingSince or t) >= maxWait then
            Cr.refreshPlanned, Cr.pendingSince = nil, nil
            Cr:Refresh()
        else
            Cr.After(0.25, tick)
        end
    end
    Cr.After(0.25, tick)
end

-- Herstellen erkennen: eigene Zauber bei sichtbarem Gewinn-Fenster (geschützte Werte nie vergleichen)
local castFrame = CreateFrame("Frame")
for _, e in ipairs({ "UNIT_SPELLCAST_START", "UNIT_SPELLCAST_SUCCEEDED", "UNIT_SPELLCAST_CHANNEL_START" }) do
    pcall(castFrame.RegisterEvent, castFrame, e)
end
castFrame:SetScript("OnEvent", function(_, _, unit)
    local G = _G.GoldSentinelGame
    if G and G.AnySecret and G.AnySecret(unit) then return end
    if unit ~= "player" or not (Cr.panel and Cr.panel:IsShown()) then return end
    Cr.craftingUntil = Cr.Clock() + Cr.CRAFT_HOLD
end)

-- Klick auf ein Rezept: im Berufsfenster öffnen. Die Zeile trägt Name und Rezept-ID, die aktuelle Nummer wird beim
-- Klick neu gesucht (Filter und zugeklappte Kategorien verschieben die Liste). Klappt es nicht, werden Suchtext und
-- Filter zurückgesetzt bzw. Kategorien aufgeklappt und es wird noch einmal versucht; sonst eine Meldung im Chat.
function Cr:IsSelected(r)
    local api = API[r.kind]
    if r.kind == "modern" and api.current and ProfessionsFrame then
        return r.recipeID ~= nil and api.current() == r.recipeID
    end
    local idx = api and api.selected()
    if not idx then return false end
    if r.kind == "modern" then return ModernIDs()[idx] == r.recipeID end
    local name, kind = api.info(idx)
    return name == r.name and kind ~= "header"
end

local function Ms() return debugprofilestop and debugprofilestop() or (GetTime() * 1000) end
Cr.SELECT_TIMEOUT = 0.5          -- so lange (s) darf es höchstens dauern, bis das Rezept im Berufsfenster gewählt ist

function Cr:SelectRecipe(r)
    if not (r and r.kind and API[r.kind]) then return false end
    local api = API[r.kind]
    local t0, g0 = Ms(), GetTime()
    local way
    local function try()
        local idx = (api.find and api.find(r)) or (not api.find and r.index) or nil
        if not idx then return false end
        way = api.select(idx) or way or "Liste"
        if api.scrollTo then api.scrollTo(idx) end
        return true
    end
    local function done(ok, how)
        Cr.pendingSelect = nil
        if Cr.selectWatch then Cr.selectWatch:SetScript("OnUpdate", nil) end
        local ms = math.floor(Ms() - t0 + 0.5)
        Cr.lastClick = { name = r.name, recipeID = r.recipeID, way = how or way, ms = ms, ok = ok }
        A:Fire("CRAFT_RECIPE_CLICK", Cr.lastClick)
        if ok then Cr:RefreshDetail()
        else A:Print(string.format(L["Rezept konnte im Berufsfenster nicht geöffnet werden: %s"], tostring(r.name))) end
        return ok
    end
    self.pendingSelect = r
    local before = api.selected()
    -- 1) direkt wählen und sofort prüfen (gleicher Frame)
    try()
    if self:IsSelected(r) then return done(true) end
    -- 2) Suchtext/Filter versteckt das Rezept: zurücksetzen, aufklappen, nochmals - weiterhin im selben Frame
    if api.reveal then
        pcall(api.reveal)
        try()
        if self:IsSelected(r) then return done(true, (way or "Liste") .. "+Filter") end
    end
    -- 3) der Weg über OpenRecipe kann einen Frame brauchen: jeden Frame prüfen, höchstens SELECT_TIMEOUT
    local after = api.selected()
    local w = self.selectWatch or CreateFrame("Frame")
    self.selectWatch = w
    w:SetScript("OnUpdate", function()
        if Cr.pendingSelect ~= r then w:SetScript("OnUpdate", nil); return end
        if Cr:IsSelected(r) then return done(true) end
        local now = api.selected()
        if now ~= before and now ~= after then        -- inzwischen selbst ein anderes Rezept gewählt
            Cr.pendingSelect = nil; w:SetScript("OnUpdate", nil); return
        end
        if GetTime() - g0 > Cr.SELECT_TIMEOUT then return done(false) end
    end)
    return true
end

-- Wie weit ragen sichtbare Teile des Berufsfensters rechts über seinen Rand hinaus? (z. B. die senkrechte
-- Reiterleiste der Berufe in WoW Forever). Liefert den Überstand in Bildschirm-Pixeln (0 = nichts).
-- Gesucht wird in den Kind-Rahmen des Fensters (bis 3 Ebenen tief), die neben dem Fenster liegen.
function Cr:RightOverhang(parent)
    if not (parent and parent.GetRight and parent.GetChildren) then return 0 end
    local okR, pr = pcall(parent.GetRight, parent)
    local okT, pt = pcall(parent.GetTop, parent)
    local okB, pb = pcall(parent.GetBottom, parent)
    if not (okR and pr and okT and pt and okB and pb) then return 0 end
    local ps = parent:GetEffectiveScale()
    local edge, top, bottom = pr * ps, pt * ps, pb * ps
    local best = 0
    local function scan(fr, depth)
        if depth > 3 then return end
        local kids = { pcall(fr.GetChildren, fr) }
        for i = 2, #kids do
            local c = kids[i]
            if type(c) == "table" and c ~= self.panel and c.IsShown and c:IsShown() then
                local ok1, r = pcall(c.GetRight, c)
                local ok2, l = pcall(c.GetLeft, c)
                local ok3, t = pcall(c.GetTop, c)
                local ok4, b = pcall(c.GetBottom, c)
                if ok1 and r and ok2 and l and ok3 and t and ok4 and b then
                    local cs = c:GetEffectiveScale()
                    r, l, t, b = r * cs, l * cs, t * cs, b * cs
                    -- rechts herausragend, neben dem Fenster (gleiche Höhe), nicht riesig (kein Vollbild-Rahmen)
                    if r > edge + 1 and l < edge + 80 and b < top and t > bottom and r - l < 200 then
                        if r - edge > best then best = r - edge end
                    end
                end
                if c.GetChildren then scan(c, depth + 1) end
            end
        end
    end
    pcall(scan, parent, 1)
    return best
end

-- Gewinn-Fenster rechts ans Berufsfenster - neben eine Reiterleiste, nie darüber
function Cr:Dock(f, parent)
    f = f or self.panel
    if not f then return end
    f:ClearAllPoints()
    if not parent then f:SetPoint("CENTER", 300, 0); return end
    local over = self:RightOverhang(parent)
    -- B2 (Befund 20:15, Entscheid 9. Nov. 09:35): nie über das Fenster, auch nicht über seinen unsichtbaren Rand -> x >= 0
    local x = 0
    if over > 0 then x = over / f:GetEffectiveScale() + 4 end
    f:SetPoint("TOPLEFT", parent, "TOPRIGHT", x, -12)
    self.dockOffset = x
end

-- G1 (Entscheid des Nutzers 17:01): solange das Panel von ProfessionSentinel offen ist, kein Gewinn-Fenster -
-- ProfessionSentinel zeigt dieselben Zahlen über AHSentinel.API. Funktion fehlt -> wie bisher.
function Cr:PSPanelShown()
    local PS = A:Global("ProfessionSentinel")
    if type(PS) ~= "table" or type(PS.IsPanelShown) ~= "function" then return false end
    local ok, v = pcall(PS.IsPanelShown)
    local G = _G.GoldSentinelGame
    if G and G.IsSecret and G.IsSecret(v) then return false end
    return ok and v == true
end

-- alle 0,5 s prüfen, solange ein Berufsfenster offen ist: Panel auf -> ausblenden, zu -> wieder einblenden
function Cr:CheckPSPanel()
    if not self.kind then return end
    local hide = self:PSPanelShown()
    if hide and self.panel and self.panel:IsShown() then
        self.panel:Hide()
        self.hiddenForPS = true
    elseif not hide and self.hiddenForPS then
        self.hiddenForPS = nil
        if not self.closedByUser and self:Enabled() then self:Open(self.kind) end
    end
end
local psWatch = CreateFrame("Frame")
Cr.psWatch = psWatch
psWatch.elapsed = 0
psWatch:SetScript("OnUpdate", function(f, dt)
    f.elapsed = f.elapsed + (dt or 0)
    if f.elapsed < 0.5 then return end
    f.elapsed = 0
    if Cr.kind then pcall(Cr.CheckPSPanel, Cr) end
end)

function Cr:Open(kind)
    self.kind = kind
    pcall(self.Remember, self, kind)
    if not self:Enabled() or self.closedByUser then return end
    if self:PSPanelShown() then self.hiddenForPS = true; return end
    local f = self:EnsurePanel()
    local parent = API[kind].frame()
    self:Dock(f, parent)
    f:Show()
    self.topDirty, self.topForce = true, true
    self:Refresh()
    -- die Reiterleiste baut das Spiel teils erst nach dem Öffnen auf: kurz danach noch einmal ausrichten
    if parent and C_Timer and C_Timer.After then
        C_Timer.After(0.3, function()
            if Cr.panel and Cr.panel:IsShown() and Cr.kind == kind then
                Cr:Dock(Cr.panel, API[kind].frame())
                if A.Diag then pcall(A.Diag.CheckOverlap, A.Diag, Cr.panel, "Gewinn-Fenster") end
            end
        end)
    end
end

function Cr:Close(kind)
    if kind and self.kind ~= kind then return end
    self.kind = nil
    self.closedByUser = nil
    self.hiddenForPS = nil
    if self.panel then self.panel:Hide() end
end

-- ------------------------------------------------------------
-- Rezepte merken (für "Heute tun" ohne ProfessionSentinel)
-- Beim Öffnen des Berufsfensters werden die bekannten Rezepte pro Charakter gespeichert:
-- Ergebnis, Menge, Zutaten. Preise kommen später immer frisch aus den Scans.
-- ------------------------------------------------------------
local function RecipeDB()
    if not A.db then return nil end
    A.db.recipes = A.db.recipes or {}
    local key = A.Chars and A.Chars:Key() or ((UnitName and UnitName("player")) or "?")
    A.db.recipes[key] = A.db.recipes[key] or {}
    return A.db.recipes[key]
end

function Cr:Remember(kind)
    kind = kind or self.kind
    if not kind then return 0 end
    -- Testroutine: nie die echten gemerkten Rezepte schreiben (Sandbox, Befund 20:15 A2: recipes.<Charakter>) -
    -- weder für die Test-Berufsliste "ahstest" noch während eines Laufs (Spiel-Ereignisse laufen weiter)
    if kind == "ahstest" or (A.TestRoutine and A.TestRoutine.running and not self.testRemember) then return 0 end
    local db = RecipeDB()
    if not db then return 0 end
    local api = API[kind]
    local title = api.title() or kind
    local list = {}
    for i = 1, api.num() do
        local name, skillType = api.info(i)
        if name and skillType ~= "header" then
            local productID = IDFromLink(api.link(i))
            local lo, hi = api.made(i)
            local rec = { name = name, productID = productID, made = ((lo or 1) + (hi or lo or 1)) / 2, reagents = {} }
            local ok = productID ~= nil
            for k = 1, api.numReagents(i) do
                local _, count, _, link = api.reagent(i, k)
                local id = IDFromLink(link)
                if not id then ok = false; break end
                table.insert(rec.reagents, { id, count or 1 })
            end
            if ok and #rec.reagents > 0 then table.insert(list, rec) end
            if #list >= 500 then break end
        end
    end
    if #list > 0 then db[title] = { t = time(), list = list } end
    return #list
end

-- EK-1 (Screenshot 15:31: Staub aus selbst hergestellten Hosen mit Einstand 0): ein Herstellen wurde nur gebucht, wenn das
-- Rezept im Zwischenspeicher des offenen Berufs stand (RecipeIndex, wird nur für "Beste Rezepte" im Hintergrund gebaut).
-- Fehlte er (Fenster gerade geöffnet, Tafel aus, anderer Beruf), lief kein CRAFT_DONE -> Hose ohne Lager-Posten -> Material
-- aus dem Entzaubern ohne Einstand. Jetzt: 1. Zwischenspeicher, 2. offenes Berufsfenster direkt (nur die Zeile mit dem Namen),
-- 3. gemerkte Rezepte dieser Figur. Zurück: productID, Rezept { made, reagents, name } oder nil
function Cr:RecipeByName(name)
    if not name then return nil end
    for pid, rec in pairs(self:RecipeIndex(nil, true)) do
        if rec.name == name then return pid, rec, "index" end
    end
    if not self.testKnown then
        for _, kind in ipairs({ "trade", "craft" }) do
            local api = API[kind]
            local okN, num = pcall(api.num)
            for i = 1, (okN and tonumber(num)) or 0 do
                local n, skillType = api.info(i)
                if n == name and skillType ~= "header" then
                    local pid = IDFromLink(api.link(i))
                    local lo, hi = api.made(i)
                    local re = {}
                    for k = 1, api.numReagents(i) do
                        local _, cnt, _, link = api.reagent(i, k)
                        local id = IDFromLink(link)
                        if id then re[#re + 1] = { id, cnt or 1 } end
                    end
                    if pid and #re > 0 then return pid, { made = ((lo or 1) + (hi or lo or 1)) / 2, reagents = re, name = n }, "fenster" end
                end
            end
        end
    end
    for _, r in ipairs(self.testKnown or self:KnownRecipes()) do
        if r.name == name and r.productID and r.reagents and #r.reagents > 0 then return r.productID, r, "gemerkt" end
    end
    return nil
end
function Cr:KnownRecipes()
    local db = RecipeDB()
    local out = {}
    for prof, e in pairs(db or {}) do
        for _, r in ipairs(e.list or {}) do
            -- Kopie: die gespeicherten Rezepte (A.db.recipes) bleiben unverändert (Sandbox-Befund 0.65.8)
            local c = {}
            for k, v in pairs(r) do c[k] = v end
            c.prof = prof
            table.insert(out, c)
        end
    end
    return out
end

-- Herstellen, das sich heute lohnt (nur Rezepte, die dieser Charakter kann):
-- Ergebnis verkaufbar (verlässlicher Marktwert, verkauft sich), Erlös nach 5 % AH-Anteil
-- abzüglich Zutaten (Händler, wenn billiger) mindestens 10 % über den Kosten.
function Cr:TodaySuggestions(max)
    local out = {}
    for _, r in ipairs(self:KnownRecipes()) do
        A:Pause()
        local sale = A:GetSalePrice(r.productID)
        local reliable, l = A:IsReliable(r.productID)
        if sale and reliable and (l.perDay or 0) >= 0.5 then
            local cost, ok = 0, true
            local reagents = {}
            for _, re in ipairs(r.reagents) do
                local unit, atVendor = self:UnitPrice(re[1], true)
                if not unit then ok = false; break end
                cost = cost + unit * re[2]
                table.insert(reagents, { itemID = re[1], count = re[2], unit = unit, atVendor = atVendor })
            end
            if ok then
                local net = A:NetSale(r.productID, sale, r.made or 1) - A:ExpectedDepositLoss(r.productID, r.made or 1)
                local profit = math.floor(net - cost)
                if profit > 0 and profit >= cost * 0.10 then
                    local count = math.max(1, math.min(5, math.floor((l.perDay or 1) * (A.MARKET_SHARE or 0.25) + 0.5)))
                    table.insert(out, { recipe = r, productID = r.productID, name = r.name, count = count, profit = profit,
                                        cost = math.floor(cost), reagents = reagents })
                end
            end
        end
    end
    table.sort(out, function(a, b) return a.profit * a.count > b.profit * b.count end)
    local res = {}
    for i = 1, math.min(max or 3, #out) do res[i] = out[i] end
    return res
end

-- Wie viele Stück eines Items hat man (Taschen, Bank, Twinks)?
function Cr:HaveCount(itemID)
    local have = A.Seller and A.Seller:CountInBags(itemID) or 0
    if A.Chars and A.Chars.ItemCounts then
        for _, c in ipairs((A.Chars:ItemCounts(itemID))) do
            if c.me then have = have + (c.bank or 0) else have = have + (c.bags or 0) + (c.bank or 0) end
        end
    end
    return have
end

-- Hat der Charakter einen Herstellungsberuf? (gemerkte Rezepte, sonst Fertigkeitenliste des Spiels)
local CRAFT_SKILLLINES = { [171] = true, [164] = true, [333] = true, [202] = true, [773] = true, [755] = true,
                           [165] = true, [197] = true, [185] = true }
local CRAFT_SPELLS = { 2259, 2018, 7411, 4036, 2108, 3908, 2550, 25229, 45357 }
function Cr:HasCraftProfession()
    local db = RecipeDB()
    if db and next(db) then return true end
    if GetProfessions and GetProfessionInfo then
        local ok, p1, p2, _, _, cook = pcall(GetProfessions)
        if ok then
            for _, idx in ipairs({ p1, p2, cook }) do
                if idx then
                    local line = select(7, GetProfessionInfo(idx))
                    if line and CRAFT_SKILLLINES[line] then return true end
                end
            end
        end
    end
    if GetNumSkillLines and GetSkillLineInfo then
        local names = {}
        for _, id in ipairs(CRAFT_SPELLS) do
            local n = (GetSpellInfo and SafeCall(GetSpellInfo, id)) or (C_Spell and C_Spell.GetSpellName and SafeCall(C_Spell.GetSpellName, id))
            if n then names[n] = true end
        end
        for i = 1, (SafeCall(GetNumSkillLines) or 0) do
            local name, isHeader = SafeCall(GetSkillLineInfo, i)
            if name and not isHeader and names[name] then return true end
        end
    end
    return false
end

local evt = CreateFrame("Frame")
Cr.evt = evt            -- für die Testroutine (Ereignisse mit Testargumenten nachspielen)
for _, e in ipairs({ "TRADE_SKILL_SHOW", "TRADE_SKILL_UPDATE", "TRADE_SKILL_CLOSE", "CRAFT_SHOW", "CRAFT_UPDATE", "CRAFT_CLOSE",
                     "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_DATA_SOURCE_CHANGED" }) do
    pcall(evt.RegisterEvent, evt, e)
end
evt:SetScript("OnEvent", function(_, event)
    if event == "TRADE_SKILL_SHOW" or event == "TRADE_SKILL_LIST_UPDATE" then Cr:InvalidateModern(false)
    elseif event == "TRADE_SKILL_DATA_SOURCE_CHANGED" then Cr:InvalidateModern(true) end
    -- gemerkte Auswahl gilt nur, solange dasselbe Berufsfenster offen ist
    if event == "TRADE_SKILL_CLOSE" or event == "TRADE_SKILL_DATA_SOURCE_CHANGED" then Cr.lastModernRecipe = nil end
    if event == "TRADE_SKILL_SHOW" then Cr:HookRecipeSelection(); Cr:Open(Cr:TradeKind())
    elseif event == "CRAFT_SHOW" then Cr:Open("craft")
    elseif event == "TRADE_SKILL_CLOSE" then Cr:Close(Cr.kind == "modern" and "modern" or "trade")
    elseif event == "CRAFT_CLOSE" then Cr:Close("craft")
    else
        -- neue Rezepte gelernt / Liste geladen: höchstens alle 5 Sekunden neu merken.
        -- Moderner Client: Kommt die Liste kurz nach dem Öffnen noch leer, gilt das nicht als "gemerkt" -
        -- sonst würde erst 5 Sekunden später neu gelesen. Alter Weg (TRADE_SKILL_UPDATE, CRAFT_UPDATE): wie bis 0.65.3.
        if Cr.kind and (not Cr.rememberedAt or GetTime() - Cr.rememberedAt > 5) then
            if Cr.kind == "modern" then
                local ok, n = pcall(Cr.Remember, Cr, Cr.kind)
                if ok and (n or 0) > 0 then Cr.rememberedAt = GetTime() end
            else
                Cr.rememberedAt = GetTime()
                pcall(Cr.Remember, Cr, Cr.kind)
            end
        end
        Cr:RequestRefresh(true, event)
    end
end)

-- Moderner Client: Auswahl im Berufsfenster über das Ereignis der Rezeptliste erfassen (Rückfall für den
-- Zutaten-Knopf, falls das Fenster das gewählte Rezept nicht selbst verrät). Fehlt das Ereignis: nichts gemerkt.
function Cr:OnRecipeSelected(recipeInfo)
    local G = _G.GoldSentinelGame
    if G and G.IsSecret and G.IsSecret(recipeInfo) then return end       -- geschützter Wert: nicht anfassen
    local rid = type(recipeInfo) == "table" and recipeInfo.recipeID or (type(recipeInfo) == "number" and recipeInfo) or nil
    if rid then self.lastModernRecipe = rid end
end
-- Blizzard löst das Ereignis unter dem ausgeschriebenen Namen aus:
--   EventRegistry:TriggerEvent("ProfessionsRecipeListMixin.Event.OnRecipeSelected", recipeInfo, list)
-- (ProfessionsRecipeListMixin.Event.OnRecipeSelected selbst ist nur "OnRecipeSelected" und passt nicht.)
-- EventRegistry nimmt auch noch unbekannte Ereignisse an: Anmelden geht schon beim Laden, bevor Blizzard_Professions
-- geladen ist. Ohne EventRegistry (ältere Clients) passiert nichts. Bei TRADE_SKILL_SHOW zur Sicherheit noch einmal.
Cr.RECIPE_SELECTED_EVENT = "ProfessionsRecipeListMixin.Event.OnRecipeSelected"
function Cr:HookRecipeSelection()
    if self.selectionHooked then return end
    if EventRegistry and EventRegistry.RegisterCallback then
        local ok = pcall(EventRegistry.RegisterCallback, EventRegistry, self.RECIPE_SELECTED_EVENT,
            function(_, recipeInfo) Cr:OnRecipeSelected(recipeInfo) end, Cr)
        if ok then self.selectionHooked = true end
    end
end
Cr:HookRecipeSelection()

A:On("DATA_CHANGED", function() Cr:RequestRefresh(true, "DATA_CHANGED") end)
A:On("THEME_CHANGED", function()
    if Cr.panel then Cr.panel:Hide(); Cr.panel = nil end
    if Cr.kind then Cr:Open(Cr.kind) end
end)
