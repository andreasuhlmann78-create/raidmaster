if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Kern.lua (Rechenkern 0.66, Schritt S1: Lernschicht + ehrliche Prüfung)
-- Bauplan anweisung-rechenkern-066.txt (Prüf-Sitzung 14.11. 09:10, freigegeben):
--   L1 Zählen statt annehmen: je Weg und Zelle (z. B. Verkauf: Warengruppe × Preisstufe) Fälle mit Ergebnis zählen.
--   L2 Wenige Fälle -> Richtung Vorwissen: Schätzung = (Treffer + k × Vorwissen) / (Fälle + k), k = 2.
--   L3 Zufallsbeute: Summe / Summe (hier: y ist schon ein Anteil 0..1, Summe der Treffer / Summe der Fälle).
--   L4 Alter: Fälle älter als 14 Tage zählen halb, älter als 30 Tage nicht mehr (Tages-Töpfe, älter -> gelöscht).
--   L5 Speicher: je Zelle und Tag nur zwei Zahlen (Fälle, Treffer) - keine Einzelfälle.
--   P1 Jeder Fall wird VOR dem Zählen vorhergesagt (nur aus Fällen davor = zeitlich getrennt, ohne den eigenen Fall).
--   P2 Grundlinie daneben ("immer nein"); Anzeige als Zahl erst, wenn neu die Grundlinie schlägt UND Brier < 0,20.
--   P3 Testbericht "MARKT-KERN": Treffer neu / Grundlinie / alt, Brier, n, seit wann.
--   P4 7 Tage unter der Grundlinie -> zurück auf das Vorwissen (Zeile rot im Testbericht).
-- Rechnet nur beim Ergebnis eines Falls (selten); Anzeigen lesen nur die Zähler. Testroutine: nie echte Daten.
-- ============================================================
local A = AHAnalyzerPro
if not (A and A.On) then return end
local K = {}
A.Kern = K

K.PRIOR_K, K.HALF_DAYS, K.MAX_DAYS = 2, 14, 30
K.SHOW_MIN, K.BRIER_MAX, K.P4_DAYS, K.P4_MIN = 30, 0.20, 7, 10
local DAY = 86400

function K:Store()
    if self.testDB then return self.testDB end
    local db = A.db
    if not db then return nil end
    if type(db.kern) ~= "table" then db.kern = { v = 1, c = {}, e = {}, since = time() } end
    db.kern.c, db.kern.e = db.kern.c or {}, db.kern.e or {}
    return db.kern
end
function K.NewDB(t) return { v = 1, c = {}, e = {}, since = t or time() } end
local function Day(t) return A:DayStart(t or time()) end
-- L4: Gewicht eines Tages-Topfs
function K:Weight(day, now)
    local age = (Day(now) - day) / DAY
    if age > self.MAX_DAYS then return 0 end
    if age > self.HALF_DAYS then return 0.5 end
    return 1
end
-- Zähler einer Zelle (gewichtet): Fälle, Treffer
function K:Counts(way, cell, now)
    local st = self:Store()
    local w = st and st.c[way]
    local c = w and w[cell]
    if not c then return 0, 0 end
    local n, y = 0, 0
    for day, v in pairs(c) do
        local g = self:Weight(day, now)
        if g > 0 then n, y = n + g * v[1], y + g * v[2] end
    end
    return n, y
end
-- L2: Schätzung mit Vorwissen
function K:Estimate(way, cell, prior, now)
    local n, y = self:Counts(way, cell, now)
    prior = prior or 0
    return (y + self.PRIOR_K * prior) / (n + self.PRIOR_K), n
end
local function Bump(t, day, a, b)
    local v = t[day]
    if not v then v = { 0, 0 }; t[day] = v end
    v[1], v[2] = v[1] + a, v[2] + b
    return v
end
function K:Add(way, cell, y, t)
    local st = self:Store()
    if not st then return end
    st.c[way] = st.c[way] or {}
    st.c[way][cell] = st.c[way][cell] or {}
    Bump(st.c[way][cell], Day(t), 1, y)
end
-- Ein Fall mit Ergebnis y (0..1). prior = Vorwissen der Zelle, old = alte Vorhersage (falls bekannt), base = Grundlinie.
-- P1: Vorhersage aus den Zählern VOR diesem Fall; Bewertung je Tag (Brier, Treffer neu/Grundlinie/alt).
function K:Case(way, cell, y, prior, t, old, base)
    if A.InTestRoutine and A:InTestRoutine() and not self.testDB then return nil end
    local st = self:Store()
    if not (st and way and cell and y) then return nil end
    t = t or time()
    y = math.max(0, math.min(1, y))
    local p = self:Estimate(way, cell, prior, t)
    base = base or 0
    st.e[way] = st.e[way] or {}
    local d = Day(t)
    local ev = st.e[way][d]
    if not ev then ev = { 0, 0, 0, 0, 0, 0, 0, 0 }; st.e[way][d] = ev end
    -- ev: 1 n · 2 Brier neu · 3 Brier Grundlinie · 4 Treffer neu · 5 Treffer Grundlinie · 6 n alt · 7 Brier alt · 8 Treffer alt
    local sold = y >= 0.5
    ev[1] = ev[1] + 1
    ev[2] = ev[2] + (p - y) ^ 2
    ev[3] = ev[3] + (base - y) ^ 2
    if (p >= 0.5) == sold then ev[4] = ev[4] + 1 end
    if (base >= 0.5) == sold then ev[5] = ev[5] + 1 end
    if old then
        ev[6], ev[7] = ev[6] + 1, ev[7] + (old - y) ^ 2
        if (old >= 0.5) == sold then ev[8] = ev[8] + 1 end
    end
    self:Add(way, cell, y, t)
    st.first = st.first or {}
    st.first[way] = st.first[way] or d
    self:Prune(t)
    return p
end
-- Bewertung einer Art: alle Tage (≤ MAX_DAYS) oder die letzten days Tage
function K:Eval(way, days, now)
    local st = self:Store()
    local r = { n = 0, bN = 0, bB = 0, hN = 0, hB = 0, nO = 0, bO = 0, hO = 0 }
    local evs = st and st.e[way]
    if not evs then return r end
    local from = Day(now) - ((days or self.MAX_DAYS) - 1) * DAY
    for d, ev in pairs(evs) do
        if d >= from then
            r.n, r.bN, r.bB, r.hN, r.hB = r.n + ev[1], r.bN + ev[2], r.bB + ev[3], r.hN + ev[4], r.hB + ev[5]
            r.nO, r.bO, r.hO = r.nO + (ev[6] or 0), r.bO + (ev[7] or 0), r.hO + (ev[8] or 0)
        end
    end
    return r
end
-- P4: in den letzten 7 Tagen unter der Grundlinie (mind. P4_MIN Fälle) -> Rückfall aufs Vorwissen
function K:Fallback(way, now)
    local r = self:Eval(way, self.P4_DAYS, now)
    return r.n >= self.P4_MIN and r.hN < r.hB, r
end
-- P2: Zahl zeigen? (genug Fälle, schlägt die Grundlinie, Brier < 0,20, kein Rückfall)
function K:Show(way, now)
    local r = self:Eval(way, nil, now)
    if r.n < self.SHOW_MIN then return false, r, "lernt noch" end
    if self:Fallback(way, now) then return false, r, "Rückfall (7 Tage unter der Grundlinie)" end
    if r.hN <= r.hB then return false, r, "schlägt die Grundlinie nicht" end
    if r.bN / r.n >= self.BRIER_MAX then return false, r, "Brier zu hoch" end
    return true, r, "zeigen"
end
-- Schätzung für die Anzeige: nur wenn Show; sonst nil (Aufrufer bleibt bei der bisherigen Rechnung / grau)
function K:Value(way, cell, prior, now)
    if self:Fallback(way, now) then return nil, "rueckfall" end
    local ok = self:Show(way, now)
    if not ok then return nil, "lernt" end
    return (self:Estimate(way, cell, prior, now))
end
-- alte Tages-Töpfe löschen (> MAX_DAYS), höchstens einmal je Tag
function K:Prune(now)
    local st = self:Store()
    if not st then return end
    local today = Day(now)
    if st.pruned == today then return end
    st.pruned = today
    local limit = today - self.MAX_DAYS * DAY
    for _, w in pairs(st.c) do
        for cell, days in pairs(w) do
            for d in pairs(days) do if d < limit then days[d] = nil end end
            if next(days) == nil then w[cell] = nil end
        end
    end
    for _, evs in pairs(st.e) do for d in pairs(evs) do if d < limit then evs[d] = nil end end end
end
-- L5: Grösse (Zellen, Tages-Töpfe, geschätzte KB)
function K:Size()
    local st = self:Store()
    local cells, pots = 0, 0
    for _, w in pairs(st and st.c or {}) do for _, days in pairs(w) do cells = cells + 1; for _ in pairs(days) do pots = pots + 1 end end end
    for _, evs in pairs(st and st.e or {}) do for _ in pairs(evs) do pots = pots + 1 end end
    return cells, pots, math.floor(pots * 0.12 + cells * 0.08 + 0.5)
end

-- ------------------------------------------------------------
-- Verkauf (S1: zuerst die Verkaufschance, PR2): Zelle = Warengruppe : Preisstufe; Vorwissen = Quote der Gruppe
-- (eigene Zelle "g:<Gruppe>", selbst mit Vorwissen 0,3). Alte Vorhersage = die beim Einstellen gezeigte Chance (e.p).
-- ------------------------------------------------------------
K.SELL_PRIOR = 0.3
function K:SellCell(g, rel)
    local Fc = A.Forecast
    local cls = Fc and Fc.RelClass and Fc:RelClass(rel or 1) or 3
    return (g or "misc") .. ":" .. cls
end
function K:SellPrior(g, now)
    return (self:Estimate("sell", "g:" .. (g or "misc"), self.SELL_PRIOR, now))
end
function K:OnSellCase(e, y, now)
    if not (e and y) then return nil end
    local g = e.g or "misc"
    local prior = self:SellCellPrior(g, e.rel, now)          -- S2/A2: Tabelle der Preisstufe als Vorwissen
    local p = self:Case("sell", self:SellCell(g, e.rel), y, prior, now, e.p, 0)
    -- Gruppen-Quote ebenfalls zählen (nur Zähler, ohne eigene Bewertung)
    if p ~= nil then self:Add("sell", "g:" .. g, y, now) end
    return p
end
-- Verkaufschance für die Anzeige (nil = noch nicht belegt -> bisherige Rechnung)
function K:SellChance(itemID, rel, now)
    local Fc = A.Forecast
    local g = Fc and Fc.Group and Fc:Group(itemID) or "misc"
    return self:Value("sell", self:SellCell(g, rel), self:SellCellPrior(g, rel, now), now)
end
-- einmalig: abgeschlossene Einstellungen der letzten 30 Tage in Zeitfolge nachtragen (P1 bleibt ehrlich: jeder Fall wird
-- nur aus den davor gezählten vorhergesagt). Läuft als Hintergrund-Aufgabe in Portionen.
function K:Backfill()
    local st = self:Store()
    local Fc = A.Forecast
    if not (st and Fc and Fc.Data) or st.filled then return 0 end
    local f = Fc:Data()
    local cases = {}
    local limit = time() - self.MAX_DAYS * DAY
    for _, s in ipairs(f and f.list or {}) do
        if s:sub(1, 1) == "P" then
            local e = Fc:Decode(s)
            local y = e and Fc:PostOutcome(e)
            if y ~= nil and (e.t or 0) >= limit then cases[#cases + 1] = { e = e, y = y, t = (e.t or 0) + (e.d or 24) * 3600 } end
        end
        if #cases % 200 == 0 then A:Pause() end
    end
    table.sort(cases, function(a, b) return a.t < b.t end)
    for i, c in ipairs(cases) do
        self:OnSellCase(c.e, c.y, c.t)
        if i % 50 == 0 then A:Pause() end
    end
    st.filled = time()
    self:RebuildBuys()
    return #cases
end
-- S2-B4 (Prüfung 13:28): Wege buyk/buye (Summe/Summe, 0.65.157) einmal aus dem Journal neu aufbauen - die Zellen werden
-- dafür geleert und alle abgeschlossenen Käufe der letzten 30 Tage in Zeitfolge gezählt (auch die seit 0.65.157 schon
-- live gezählten: so zählt jeder Kauf genau einmal)
function K:RebuildBuys()
    local st = self:Store()
    local Fc = A.Forecast
    if not (st and Fc and Fc.Data) or st.filledBuy2 then return 0 end
    for _, w in ipairs({ "buyk", "buye", "buyp", "buyr" }) do st.c[w] = nil end
    local f = Fc:Data()
    local limit, list = time() - self.MAX_DAYS * DAY, {}
    for i, s in ipairs(f and f.list or {}) do
        if s:sub(1, 1) == "B" then
            local e = Fc:Decode(s)
            if e and e.r == "c" and (e.t or 0) >= limit then list[#list + 1] = e end
        end
        if i % 200 == 0 then A:Pause() end
    end
    table.sort(list, function(a, b) return (a.t or 0) < (b.t or 0) end)
    for i, e in ipairs(list) do
        self:OnBuyCase(e, e.t)
        if i % 50 == 0 then A:Pause() end
    end
    st.filledBuy2 = time()
    self.buyCapCache = nil
    return #list
end
-- S2: abgeschlossene Käufe der letzten 30 Tage einmalig nachtragen (V2)
function K:BackfillBuys()
    local st = self:Store()
    local Fc = A.Forecast
    if not (st and Fc and Fc.Data) or st.filledBuy then return 0 end
    local f = Fc:Data()
    local limit, n = time() - self.MAX_DAYS * DAY, 0
    for i, s in ipairs(f and f.list or {}) do
        if s:sub(1, 1) == "B" then
            local e = Fc:Decode(s)
            if e and e.r == "c" and (e.t or 0) >= limit then self:OnBuyCase(e, e.t); n = n + 1 end
        end
        if i % 200 == 0 then A:Pause() end
    end
    st.filledBuy = time()
    return n
end
A:On("READY", function()
    if A.InTestRoutine and A:InTestRoutine() then return end
    local st = K:Store()
    if st and st.filled and not st.filledBuy2 and A.Job then
        A:Job("kern:backfill", function() local ok, err = A:PCall(K.RebuildBuys, K); if not ok and A.Diag then pcall(A.Diag.Add, A.Diag, "FEHLER", "kern:rebuild: " .. tostring(err)) end end)
    elseif st and not st.filled and A.Job then
        A:Job("kern:backfill", function() local ok, err = A:PCall(K.Backfill, K); if not ok and A.Diag then pcall(A.Diag.Add, A.Diag, "FEHLER", "kern:backfill: " .. tostring(err)) end end)
    end
end)

-- P3: Testbericht-Zeilen "MARKT-KERN"
local function Pct(x) return x and string.format("%d %%", math.floor(x * 100 + 0.5)) or "-" end
function K:ReportLines(out, fields)
    local st = self:Store()
    local names = { sell = "Verkaufschance" }
    for _, way in ipairs({ "sell" }) do
        local show, r, why = self:Show(way)
        local fb, r7 = self:Fallback(way)
        local first = st and st.first and st.first[way]
        if r.n > 0 then
            out[#out + 1] = string.format("  MARKT-KERN %s: Treffer neu %s / Grundlinie (immer nein) %s / alt %s · Brier neu %.3f / Grundlinie %.3f / alt %s · n %d · seit %s · Anzeige: %s%s",
                names[way], Pct(r.hN / r.n), Pct(r.hB / r.n), r.nO > 0 and Pct(r.hO / r.nO) or "-", r.bN / r.n, r.bB / r.n,
                r.nO > 0 and string.format("%.3f", r.bO / r.nO) or "-", r.n, first and date("%d.%m.", first) or "-",
                show and "Zahl" or ("grau – " .. why), fb and string.format(" |cffff5544· P4 RÜCKFALL: 7 Tage unter der Grundlinie (%d/%d)|r", r7.hN, r7.hB) or "")
        else
            out[#out + 1] = string.format("  MARKT-KERN %s: noch keine Fälle (lernt noch)", names[way])
        end
        if fields then fields["kern_" .. way] = string.format("%d/%d/%d/%s", r.n, r.hN, r.hB, show and "zahl" or "grau") end
    end
    pcall(self.ReportS2, self, out, fields)
    if A.Ketten and A.Ketten.ReportLines then pcall(A.Ketten.ReportLines, A.Ketten, out, fields) end      -- S3b: Ketten nur im Bericht
    local okL, lc = pcall(self.LohntCheck, self, 60)
    if okL and lc then
        local ways = {}
        for k, v in pairs(lc.byWay) do ways[#ways + 1] = k .. " " .. v end
        table.sort(ways)
        out[#out + 1] = string.format("  MARKT-KERN Lohnt bis (S3, ein Wert über alle Wege): %d Items · bester Weg %s · Anzeigen gleich %d / mit anderer Zahl %d%s",
            lc.n, #ways > 0 and table.concat(ways, ", ") or "-", lc.same, lc.other, #lc.ex > 0 and (" (" .. table.concat(lc.ex, " | ") .. ")") or "")
        if fields then fields.kern_lohnt = string.format("%d/%d/%d", lc.n, lc.same, lc.other) end
    end
    local cells, pots, kb = self:Size()
    out[#out + 1] = string.format("  MARKT-KERN Speicher: %d Zellen · %d Tages-Töpfe · ~%d KB (Ziel < 300 KB)", cells, pots, kb)
end

-- ------------------------------------------------------------
-- S2 / A2: Markt-Tabellen von aussen (GoldSentinelMarktTabellen.lua, täglich von der Prüf-Sitzung, im ZIP). Nur
-- Nachschlagen beim Gebrauch, nie rechnen. Fehlt die Tabelle oder ein Teil: alles läuft ohne (Vorwissen wie bisher).
-- ------------------------------------------------------------
function K:Tables()
    if self.tablesOverride ~= nil then return self.tablesOverride or nil end
    local t = _G.GoldSentinelMarktTabellen
    if type(t) ~= "table" or t.v ~= 1 then return nil end
    return t
end
-- Tabelle "verkauf": Quote der Preisstufe (gleiche Grenzen wie Fc.REL_B) einer Warengruppe, mit n
function K:TableSell(g, rel)
    local t = self:Tables()
    local rows = t and type(t.verkauf) == "table" and t.verkauf[g]
    if type(rows) ~= "table" then return nil end
    rel = rel or 1
    for _, r in ipairs(rows) do
        if type(r) == "table" and r.bis and rel <= r.bis then return r.quote, r.n or 0 end
    end
    return nil
end
-- Vorwissen einer Verkaufs-Zelle: Tabelle (Preisstufe) mit ihrem n, sonst die gezählte Gruppen-Quote
function K:SellCellPrior(g, rel, now)
    local gp = self:SellPrior(g, now)
    local q, n = self:TableSell(g, rel)
    if q and n and n > 0 then return (q * n + self.PRIOR_K * gp) / (n + self.PRIOR_K) end
    return gp
end

-- ------------------------------------------------------------
-- S2 / V2: Kaufgrenze lernt je Preisstufe (R3, SN-M). Stufe = Kaufpreis / Wert beim Kauf (Grenzen wie Tabelle "kaufen").
-- Jeder abgeschlossene Kauf (Fc: alle Stück zugeordnet) zählt seinen Gewinn (Erlös / Kaufpreis − 1) in seiner Stufe.
-- Grenze: höchste Stufe, deren Gewinn (eigene Zählung, Vorwissen = Tabelle) mindestens den Mindestgewinn erreicht -
-- nie über 0,9 × Wert. Ohne genug Fälle (< BUY_MIN je Stufe, eigene + Tabelle) bleibt 0,9.
-- ------------------------------------------------------------
K.BUY_BANDS, K.BUY_MIN = { 0.6, 0.7, 0.8, 0.9, 99 }, 10
-- S2-B1/B2 (Prüfung 12:35): Gewinn je Stufe als Summe/Summe (Σ Erlös / Σ Kaufpreis − 1, wie die Tabelle, L3/KF2); die
-- Tabelle ist nur Vorwissen mit Gewicht k = 2 (sie stammt aus denselben Käufen - sonst zählte jeder Fall doppelt);
-- BUY_MIN zählt nur EIGENE Fälle.
function K:BuyBand(share)
    for i, b in ipairs(self.BUY_BANDS) do if share <= b then return i end end
    return #self.BUY_BANDS
end
function K:OnBuyCase(e, now)
    if not (e and e.pr and e.pr > 0 and e.rv and e.rq and e.rq > 0) then return nil end
    local value = e.ev or e.mv
    if not (value and value > 0) then return nil end
    if A.InTestRoutine and A:InTestRoutine() and not self.testDB then return nil end
    local cost, rev = e.pr * e.rq, e.rv
    local band = self:BuyBand(e.pr / value)
    -- Selbstkontrolle (Grundsatz 11:24, P1): Vorhersage der Stufe VOR diesem Fall gegen das Ergebnis
    local pred = self:BuyGain(band, now)
    local real = rev / cost - 1
    if pred then
        self:Add("buyp", "b" .. band, pred, now)
        self:Add("buyr", "b" .. band, real, now)
    end
    self:Add("buyk", "b" .. band, cost, now)
    self:Add("buye", "b" .. band, rev, now)
    self.buyCapCache = nil
    return band, real
end
function K:TableBuy(band)
    local t = self:Tables()
    local rows = t and type(t.kaufen) == "table" and t.kaufen
    local r = type(rows) == "table" and rows[band]
    if type(r) == "table" and r.bis == self.BUY_BANDS[band] then return r.gewinn, r.n or 0 end
    return nil
end
-- geschätzter Gewinn einer Stufe und Zahl der EIGENEN Fälle (gewichtet nach Alter)
function K:BuyGain(band, now)
    local n, sk = self:Counts("buyk", "b" .. band, now)
    local _, se = self:Counts("buye", "b" .. band, now)
    local tg = self:TableBuy(band)
    if n <= 0 then return tg, 0 end
    if tg then
        local avg = sk / n                              -- Vorwissen = k "durchschnittliche" Käufe zum Tabellen-Gewinn
        return (se + self.PRIOR_K * avg * (1 + tg)) / (sk + self.PRIOR_K * avg) - 1, n
    end
    return se / sk - 1, n
end
-- Höchst-Anteil (Kaufpreis / Wert) für einen Mindestgewinn (z. B. 0,2): höchste Stufe, die ihn hält; nie über 0,9
function K:BuyShareCap(minGain, now)
    minGain = minGain or 0.2
    local key = math.floor(minGain * 1000 + 0.5)
    local c = self.buyCapCache
    if c and c[key] and time() - c.t < 300 then return c[key] end
    local cap = 0.9
    for band = 1, #self.BUY_BANDS - 1 do
        local g, n = self:BuyGain(band, now)
        if g and n >= self.BUY_MIN and g < minGain then
            -- S2-B3: hält schon die billigste Stufe den Mindestgewinn nicht -> 0 = kein Kauf
            cap = math.min(cap, band > 1 and self.BUY_BANDS[band - 1] or 0)
            break
        end
    end
    if not (c and time() - c.t < 300) then c = { t = time() }; self.buyCapCache = c end
    c[key] = cap
    return cap
end

-- ------------------------------------------------------------
-- S2 / V3: Welle -> "jetzt verkaufen" (nur Richtung, R4/RK6). Eigene Messung (Waves.lua, ≥ 3 Tage), sonst Tabelle.
-- Zwischenspeicher 10 Min. je Band (kein Rechnen beim Klick).
-- ------------------------------------------------------------
function K:WaveState(itemID, now)
    local W = A.Waves
    if not (W and W.BANDS) then return nil end
    local band
    for _, b in ipairs(W.BANDS) do for _, id in ipairs(b.mats) do if id == itemID then band = b end end end
    if not band then return nil end
    self.waveCache = self.waveCache or {}
    local c = self.waveCache[band.key]
    if c and time() - c.t < 600 then return c.st, band.key, c.src end
    local st, src = nil, nil
    local ok, idx = pcall(W.BandIndex, W, band, now)
    if ok then
        local s, vals = W:StateOf(idx)
        if #vals >= 3 then st, src = s, "eigen" end
    end
    if not st then
        local t = self:Tables()
        local w = t and type(t.wellen) == "table" and t.wellen[band.key]
        if type(w) == "table" and w.zustand then st, src = w.zustand, "tabelle" end
    end
    self.waveCache[band.key] = { t = time(), st = st, src = src }
    return st, band.key, src
end
function K:SellNow(itemID) return self:WaveState(itemID) == "welle" end
-- Testbericht S2: Tabellen, Kaufen je Stufe, Wellen
function K:ReportS2(out, fields)
    local t = self:Tables()
    if t then
        local parts = {}
        for _, k in ipairs({ "wellen", "verkauf", "entzaubern", "kaufen" }) do if type(t[k]) == "table" then parts[#parts + 1] = k end end
        out[#out + 1] = string.format("  MARKT-KERN Tabellen (A2): erstellt %s, Daten bis %s · Teile: %s", date("%d.%m. %H:%M", t.erstellt or 0), date("%d.%m. %H:%M", t.datenBis or 0), table.concat(parts, ", "))
    else
        out[#out + 1] = "  MARKT-KERN Tabellen (A2): keine (läuft ohne)"
    end
    local bands = {}
    for band = 1, #self.BUY_BANDS do
        local g, n = self:BuyGain(band)
        local np, sp = self:Counts("buyp", "b" .. band)
        local _, sr = self:Counts("buyr", "b" .. band)
        bands[#bands + 1] = string.format("≤%s %s (eigen n %.0f%s)", band == #self.BUY_BANDS and "∞" or tostring(self.BUY_BANDS[band]), g and string.format("%+d %%", math.floor(g * 100 + 0.5)) or "-", n,
            np > 0 and string.format(", vorhergesagt %+d %% / realisiert %+d %%", math.floor(sp / np * 100 + 0.5), math.floor(sr / np * 100 + 0.5)) or "")
    end
    out[#out + 1] = string.format("  MARKT-KERN Kaufen je Stufe (V2, Kaufpreis/Wert -> Gewinn): %s · Grenze bei Mindestgewinn 20/25/30 %%: %.2f/%.2f/%.2f × Wert",
        table.concat(bands, " · "), self:BuyShareCap(0.2), self:BuyShareCap(0.25), self:BuyShareCap(0.3))
    local W = A.Waves
    if W and W.BANDS then
        local ws = {}
        for _, b in ipairs(W.BANDS) do
            local st, _, src = self:WaveState(b.mats[1])
            ws[#ws + 1] = string.format("%s %s (%s)", b.key, tostring(st or "-"), tostring(src or "-"))
        end
        out[#out + 1] = "  MARKT-KERN Wellen (V3, \"welle\" -> jetzt verkaufen): " .. table.concat(ws, " · ")
        if fields then fields.kern_wellen = table.concat(ws, " | "):sub(1, 200) end
    end
end

-- ------------------------------------------------------------
-- S3 (RK1/RK2), Schritt a: EIN "Lohnt bis" über alle Wege - bester Ausgang je Stück: Entzaubern (MK:DELimit, mit
-- DE30b-Mindestgewinn und V2-Grenze), Wiederverkauf im AH (A:FlipCheck: Preisleiter, Absatz, 5 %, Einzahlung, gelernte
-- Marge) und Händler (geprüfter Händlerpreis). Ein Zwischenspeicher je Datenstand. Die Anzeigen lesen in diesem Schritt
-- noch ihre bisherige Zahl; der Testbericht vergleicht sie mit diesem Wert (Selbstkontrolle "nie zwei Zahlen") - die
-- Umstellung aller Anzeigen folgt, sobald die Abweichungen erklärt sind.
-- ------------------------------------------------------------
K.lohntCache, K.lohntVer = {}, nil
K.VENDOR_MIN_GAIN = 0.2
function K:LohntBis(itemID)
    if not itemID then return nil end
    local ver = A.DataVersion and A:DataVersion() or 0
    if self.lohntVer ~= ver then self.lohntCache, self.lohntVer = {}, ver end
    local c = self.lohntCache[itemID]
    if c ~= nil then return c or nil end
    local best = { per = nil, way = nil, ways = {} }
    local function offer(way, per, sure)
        if type(per) ~= "number" or per <= 0 then return end
        per = math.floor(per)
        best.ways[way] = per
        if sure and (not best.per or per > best.per) then best.per, best.way = per, way end
    end
    local MK = A.Core
    if MK and MK.DELimit then
        local ok, per, net, sure = pcall(MK.DELimit, MK, itemID)
        if ok and per then offer("de", per, sure) end
    end
    if A.FlipCheck then
        local ok, _, r = pcall(A.FlipCheck, A, itemID, nil)
        if ok and r and r.resale and r.limit then offer("ah", r.limit, true) end
    end
    -- S3-1 (Prüfung 14:10): Kauf zum Händlerpreis bringt 0 - auch hier der Mindestgewinn (Händler-Marge 20 %: v / 1,2)
    local v = A.GetVendorPrice and A:GetVendorPrice(itemID)
    if type(v) == "number" and v > 0 then offer("haendler", math.floor(v / (1 + self.VENDOR_MIN_GAIN)), true) end
    self.lohntCache[itemID] = best.per and best or false
    return best.per and best or nil
end
-- Selbstkontrolle S3: Anzeigen (MK:LimitSources - Tooltip, Markt, Sammelkauf, Sniper, API) gegen den einen Wert
function K:LohntCheck(maxItems)
    local MK = A.Core
    local md = A.db and A.db.marketData
    local out = { n = 0, same = 0, other = 0, byWay = {}, ex = {} }
    if not (MK and MK.LimitSources and md) then return out end
    local ids = {}
    for id in pairs(md) do ids[#ids + 1] = id; if #ids >= (maxItems or 60) * 4 then break end end
    for _, id in ipairs(ids) do
        if out.n >= (maxItems or 60) then break end
        local b = self:LohntBis(id)
        if b then
            out.n = out.n + 1
            out.byWay[b.way] = (out.byWay[b.way] or 0) + 1
            local okS, src = pcall(MK.LimitSources, MK, id)
            local diff = false
            for k, val in pairs(okS and src or {}) do
                if type(val) == "number" and val ~= b.per then
                    diff = true
                    if #out.ex < 3 then out.ex[#out.ex + 1] = string.format("Item %d: ein Wert %d (%s) · %s %d", id, b.per, b.way, k, val) end
                    break
                end
            end
            if diff then out.other = out.other + 1 else out.same = out.same + 1 end
        end
    end
    return out
end
