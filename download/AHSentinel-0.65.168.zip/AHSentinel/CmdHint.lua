if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - CmdHint.lua
-- CH-G (Entscheid des Nutzers 13.11. 23:26): Befehlsliste beim Tippen über die GEMEINSAME Datei
-- GoldSentinelCmdHint.lua (unverändert aus raidmaster/shared). Hier nur die Anbindung: Anmelden mit den Befehlen aus
-- A.COMMANDS und im eigenen Slash-Handler Auswahl übernehmen (Resolve) und zählen (Count).
-- Bedienung wie bisher: Klick wählt, Tab/Shift+Tab, Enter führt aus. Zähler bleiben in A.db.settings.cmdUse.
-- ============================================================
local A = AHAnalyzerPro
local L = A.L

local function Register()
    local CHG = _G.GoldSentinelCmdHint
    if not (CHG and CHG.Register) then return nil end
    return CHG.Register({
        id = "AHSentinel",
        prefixes = { "/ahsentinel", "/ahanalyzer", "/ahs", "/ahp" },
        display = "/ahs",
        commands = A.COMMANDS,
        store = function()
            if not (A.db and A.db.settings) then return nil end
            A.db.settings.cmdUse = A.db.settings.cmdUse or {}
            return A.db.settings.cmdUse
        end,
        enabled = function() return A.db and A.db.settings and A.db.settings.cmdHint ~= false end,
        L = L,
        german = function() return (A.uiLang or (GetLocale and GetLocale())) == "deDE" end,
        dev = function() return A:IsDev() end,
        noMatch = L["Kein Befehl – /ahs hilfe"],
        enterText = L["Enter = %s"],
    })
end

A.CmdHint = Register()
A.CmdHintUI = _G.GoldSentinelCmdHint            -- gemeinsames Fenster (Auswahl, Liste) – nur lesen/bedienen
A:On("READY", function()
    if not A.CmdHint then A.CmdHint = Register() end
    A.CmdHintUI = _G.GoldSentinelCmdHint
end)

-- Zählen bei JEDER Ausführung (getippt oder angeklickt): eigener Handler wird umhüllt (keine Blizzard-Funktion)
do
    local handler = SlashCmdList["AHANALYZERPRO"]
    if handler then
        SlashCmdList["AHANALYZERPRO"] = function(msg, ...)
            local h = A.CmdHint
            if h then
                msg = h:Resolve(msg)                -- frische Auswahl aus der Liste statt des unvollständigen Worts
                pcall(h.Count, h, msg)
            end
            return handler(msg, ...)
        end
    end
end
