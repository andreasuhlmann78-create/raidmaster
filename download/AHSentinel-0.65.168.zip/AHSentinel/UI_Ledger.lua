if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.7 - Tab "Buchhaltung"
--   Zeitraum: Heute / 7 Tage / 30 Tage / Alles
--   Karten:   Einnahmen (nach AH-Anteil), Ausgaben, Gebühren, Gewinn
--   Ansichten:
--     Pro Item  - Erlös, Kosten, Gebühren, Gewinn je Item
--     Verlauf   - alle Buchungen
--     Statistik - Verkaufsquote je Item, Verkäufe nach Uhrzeit und Wochentag
--     Gold      - alle Charaktere, Gold der letzten 30 Tage
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
-- GRUNDSATZ NACHVOLLZIEHBAR (Nutzer 15:18): ein Satz, was die Gruppen-Zahl ist und wie sie entsteht (≤ 20 Wörter)
function UI.HelpDEGroup() return L["Alles Gold aus den Verkäufen der Materialien minus dem Gold, das die entzauberten Teile gekostet haben."] end
local C = UI.C

local KIND_LABEL = { sale = "Verkauf", buy = "Kauf", deposit = "Einstellgebühr", refund = "Erstattung" }
local KIND_COLOR = { sale = "33dd55", buy = "ff9933", deposit = "aaaaaa" }
local WEEKDAYS = { "Mo", "Di", "Mi", "Do", "Fr", "Sa", "So" }

local function Signed(v)
    if not v then return "-" end
    if v < 0 then return "|cffff5544-" .. A:FormatMoney(-v) .. "|r" end
    if v > 0 then return "|cff33dd55" .. A:FormatMoney(v) .. "|r" end
    return A:FormatMoney(0)
end

-- Einfaches Balkendiagramm aus Texturen
local function BarChart(parent, n, width, height)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(width, height)
    UI:Box(f, C.panel, C.border)
    f.title = UI:Label(f, "", "GameFontNormalSmall", C.accent)
    f.title:SetPoint("TOPLEFT", 8, -6)
    f.title:SetWidth(width - 16)
    f.info = UI:Label(f, "", "GameFontDisableSmall", C.textDim)
    f.info:SetPoint("BOTTOMLEFT", 8, 6)
    f.info:SetWidth(width - 16)
    f.bars, f.labels = {}, {}
    local plotW = width - 16
    local bw = plotW / n
    for i = 1, n do
        local b = f:CreateTexture(nil, "ARTWORK")
        b:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.8)
        b:SetWidth(math.max(1, bw - 2))
        b:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 8 + (i - 1) * bw, 34)
        b:SetHeight(1)
        f.bars[i] = b
        local l = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        l:SetPoint("TOP", b, "BOTTOM", 0, -2)
        f.labels[i] = l
    end
    f.plotH = height - 34 - 30
    -- values: Zahlen (oder nil), labels: Text unter den Balken (oder "")
    function f:SetData(values, labels, highlight)
        local maxV = 0
        for i = 1, n do if values[i] and values[i] > maxV then maxV = values[i] end end
        for i = 1, n do
            local v = values[i]
            local h = (v and maxV > 0) and math.max(1, v / maxV * self.plotH) or 1
            self.bars[i]:SetHeight(h)
            local col = (highlight and highlight[i]) and C.green or C.accent
            self.bars[i]:SetColorTexture(col[1], col[2], col[3], v and 0.85 or 0.15)
            self.labels[i]:SetText(labels and labels[i] or "")
        end
    end
    return f
end

local function BuildLedger(parent)
    local p = CreateFrame("Frame", nil, parent)
    local Le = A.Ledger
    p.period = A.db.ledger.period or "7"
    p.view = A.db.ledger.view or "items"

    local head = UI:TabTitle(p, L["Buchhaltung"], "ledger")
    head.line:Hide()          -- rechts daneben sitzen die Zeitraum-Knöpfe

    -- Zeitraum
    p.periodButtons = {}
    local prev
    for _, per in ipairs(Le.PERIODS) do
        local b = UI:Button(p, L[per.label], 80, 22, function()
            p.period = per.key
            A.db.ledger.period = per.key
            p:Refresh()
        end)
        if prev then b:SetPoint("LEFT", prev, "RIGHT", 4, 0) else b:SetPoint("LEFT", head, "RIGHT", 20, 0) end
        b.key = per.key
        table.insert(p.periodButtons, b)
        prev = b
    end

    -- EB7: einziges neues Element - Knopf "Details" öffnet ein eigenes Fenster
    p.detailsBtn = UI:Button(p, L["Details"], 80, 22, function() UI:ShowBooksDetails() end)
    p.detailsBtn:SetPoint("LEFT", prev, "RIGHT", 12, 0)

    -- BP5 (Buchhaltung neu): EIN Endergebnis "Gewinn" (realisiert), darunter klein Verkauft · Eingesetzt · Gebühren.
    -- Alles Weitere (Kasse, Lager, unrealisiert, ausstehend, Abstimmung) nur im Tooltip.
    p.cards = {}
    local cardDefs = {
        { key = "profit", title = L["Gewinn"], icon = "Interface\\Icons\\INV_Misc_Coin_01" },
    }
    for i, d in ipairs(cardDefs) do
        local c = UI:Card(p, 222, 62, d.title, d.icon)
        c:SetPoint("TOPLEFT", (i - 1) * 228, -32)
        c.index = i
        c:EnableMouse(true)
        c:SetScript("OnEnter", function(self)
            UI:AnchorTooltip(self)
            GameTooltip:SetText(L["Gewinn"], 1, 1, 1)
            for _, l in ipairs(p:ProfitTooltip()) do GameTooltip:AddLine(l[1], l[2] or 0.9, l[3] or 0.9, l[4] or 0.9, true) end
            GameTooltip:Show()
        end)
        c:SetScript("OnLeave", function() GameTooltip:Hide() end)
        p.cards[d.key] = c
    end
    -- Tooltip-Zeilen des Gewinns (auch für die Testroutine)
    function p:ProfitTooltip()
        local BK = A.Books
        local out = {}
        if not BK then return out end
        local s = BK:Summary(self.period)
        -- BH-ANZ/EB-NAME: nur verfallene Anzahlungen sind Aufwand, mit dem Wort des Spiels
        out[#out + 1] = { string.format(L["Gewinn = Erlös %s − eingesetzt %s − %s verfallen %s"], A:FormatMoney(s.rev), A:FormatMoney(s.cost), BK:DepositWord(), A:FormatMoney(s.fees)), 1, 0.82, 0 }
        out[#out + 1] = { L["Einkauf ist kein Verlust: Gekauftes liegt mit seinem Kaufpreis im Lager, der Gewinn entsteht beim Verkauf."] }
        out[#out + 1] = { string.format(L["Kasse: Verkäufe %s − Käufe %s − Gebühren %s"], A:FormatMoney(s.rev), A:FormatMoney(s.spent), A:FormatMoney(s.feesRaw or 0)) }
        local cost, market = BK:StockValues()
        out[#out + 1] = { string.format(L["Lager (dieser Charakter): Einstand %s · Marktwert %s · nicht realisiert %s"], A:FormatMoney(cost), A:FormatMoney(market), Signed(market - cost)) }
        if s.pendingN > 0 then out[#out + 1] = { string.format(L["Ausstehend (verkauft, Rechnung fehlt noch): %d · %s"], s.pendingN, A:FormatMoney(s.pending)) } end
        -- BH-AUS: ausstehend länger als 24 Std. ohne Rechnung melden (zählt nicht im Gewinn)
        if (s.pendingOld or 0) > 0 then out[#out + 1] = { string.format(L["Davon älter als 24 Std. ohne Rechnung (nicht im Gewinn): %d · %s"], s.pendingOld, A:FormatMoney(s.pendingOldRev or 0)), 1, 0.6, 0.2 } end
        if s.free > 0 then out[#out + 1] = { string.format(L["%d Stück ohne Einkauf verkauft (Kostenbasis 0)"], s.free), 0.6, 0.6, 0.6 } end
        -- BE2: wo du Geld verlierst (Geschäftsart und Item mit dem grössten Verlust)
        for _, l in ipairs(BK:LossLines(s)) do out[#out + 1] = { l, 1, 0.5, 0.4 } end
        local change, explained, diff = BK:Reconcile(self.period)
        if change then
            local r = BK.lastRecon or {}
            local db0 = BK:Data()
            local sinceRestart = self.period ~= "today" or (db0 and r.from == db0.since)
            -- AB7: gleicher Zeitraum wie die Buchhaltung; "nicht gebucht" nur ab 1 % des Umsatzes
            if r.show then
                out[#out + 1] = { string.format(L["Gold %s: %s · Buchhaltung erklärt: %s · nicht gebucht: %s"], sinceRestart and L["seit Stichtag"] or L["seit Tagesbeginn"],
                    Signed(change), Signed(explained), Signed(diff)), 0.7, 0.85, 1 }
            else
                out[#out + 1] = { string.format(L["Gold %s: %s · Buchhaltung erklärt alles"], sinceRestart and L["seit Stichtag"] or L["seit Tagesbeginn"], Signed(change)), 0.7, 0.85, 1 }
            end
            if (r.pending or 0) > 0 then
                out[#out + 1] = { string.format(L["Ausstehend %s kommt noch mit der Post (darum ist das Gold tiefer als der Gewinn)"], A:FormatMoney(r.pending)), 0.7, 0.85, 1 }
            end
        end
        -- AB8: Plausibilität (Kostenbasis)
        local okP, pl = pcall(BK.Plausibility, BK, self.period)
        for _, w in ipairs(okP and pl or {}) do
            if w[1] == "WARNUNG" then out[#out + 1] = { "! " .. w[2], 1, 0.6, 0.2 } end
        end
        local db = BK:Data()
        if db and db.since then out[#out + 1] = { string.format(L["Buchhaltung seit %s (alte Daten bleiben im Hintergrund)"], date("%d.%m.%Y %H:%M", db.since)), 0.6, 0.6, 0.6 } end
        return out
    end

    -- Ansichten
    p.viewButtons = {}
    local views = { { "items", L["Pro Item"] }, { "log", L["Verlauf"] }, { "stats", L["Statistik"] }, { "gold", L["Gold"] }, { "assets", L["Vermögen"] }, { "guild", L["Gildenbank"] }, { "de", L["Entzaubern"] }, { "biz", L["Rendite"] } }
    prev = nil
    for _, v in ipairs(views) do
        local b = UI:Button(p, v[2], 100, 22, function()
            p.view = v[1]
            A.db.ledger.view = v[1]
            p:Refresh()
        end)
        if prev then b:SetPoint("LEFT", prev, "RIGHT", 4, 0) else b:SetPoint("TOPLEFT", 0, -104) end
        b.view, b.label2 = v[1], v[2]
        p.viewButtons[v[1]] = b
        prev = b
    end
    p.itemsBtn, p.logBtn, p.statsBtn, p.goldBtn = p.viewButtons.items, p.viewButtons.log, p.viewButtons.stats, p.viewButtons.gold
    p.info = UI:Label(p, "", "GameFontDisableSmall", C.textDim)
    p.info:SetPoint("LEFT", prev, "RIGHT", 12, 0)
    p.info:SetPoint("RIGHT", p, "RIGHT", 0, 0)       -- Rest der Zeile (6 Ansichts-Knöpfe davor)
    if p.info.SetWordWrap then p.info:SetWordWrap(true) end

    -- ---------- Pro Item (BP5: Verkauft, Erlös, Eingesetzt, Gewinn, Gewinn %) ----------
    p.itemTable = UI:Table(p, {
        columns = {
            { key = "name", title = L["Item"], width = 220 },
            { key = "sold", title = L["verkauft"], width = 80, align = "RIGHT" },
            { key = "rev", title = L["Erlös"], width = 130, align = "RIGHT" },
            { key = "cost", title = L["Eingesetzt"], width = 130, align = "RIGHT" },
            { key = "profit", title = L["Gewinn"], width = 130, align = "RIGHT" },
            { key = "pct", title = L["Gewinn %"], width = 90, align = "RIGHT" },
        },
        rows = 12, rowHeight = 22, sortKey = "profit", sortAsc = false,
        cell = function(r, key)
            if key == "name" then return r.group and ("|cffffd100" .. r.name .. "|r |cff888888(" .. #r.children .. ")|r") or UI.ItemName(r) end
            if key == "sold" then return tostring(r.sold or 0) end
            if key == "profit" then return Signed(r.profit) end
            if key == "pct" then return r.pct and string.format("%d %%", math.floor(r.pct + 0.5)) or "-" end
            return (r[key] or 0) > 0 and A:FormatMoney(r[key]) or "-"
        end,
        sortValue = function(r, key)
            if key == "name" then return string.lower(UI.ItemName(r)) end
            return r[key] or -1e12
        end,
        onClick = function(r) if r.itemID then UI:OpenChart(r.itemID) end end,
        -- TB138-6 b: Gruppe "Entzaubern …" - die einzelnen Materialien im Tooltip
        -- BH-ANZ-S2: je Gruppe EINE Zahl (Gold rein − Gold raus); Materialien nur mit Menge und Erlös (der Gewinn je Material
        -- ist nur eine Kosten-Verteilung beim Entzaubern und wirkt wie "Material macht Verlust")
        rowTooltip = function(r, tip)
            if not r.group then return end
            tip:AddLine(r.name, 1, 0.82, 0)
            tip:AddDoubleLine(L["Ergebnis (Gold rein − Gold raus)"], Signed(r.profit), 1, 1, 1, 1, 1, 1)
            tip:AddLine(UI.HelpDEGroup(), 0.6, 0.6, 0.6, true)              -- GRUNDSATZ NACHVOLLZIEHBAR (15:18): ein Satz
            if (r.free or 0) ~= 0 then
                tip:AddDoubleLine("  " .. L["davon Stücke ohne Einkauf"], Signed(r.free), 0.7, 0.7, 0.7, 0.7, 0.7, 0.7)
            end
            -- Halten-Verlust (nur Entzauberungen ab 0.65.166 mit gemerktem Preis): getrennt, kein zweiter Gewinn
            if r.hold and r.hold ~= 0 then
                tip:AddDoubleLine("  " .. (r.hold < 0 and L["Preis gefallen seit dem Entzaubern"] or L["Preis gestiegen seit dem Entzaubern"]), Signed(r.hold), 0.7, 0.7, 0.7, 0.7, 0.7, 0.7)
            end
            for _, c in ipairs(r.children or {}) do
                tip:AddDoubleLine(UI.ItemName(c) .. " ×" .. (c.sold or 0), A:FormatMoney(c.rev or 0), 1, 1, 1, 1, 1, 1)
            end
        end,
        emptyText = L["Noch keine Verkäufe seit dem Neustart der Buchhaltung in diesem Zeitraum."],
    })
    p.itemTable:Fill(0, -134, 0, 24)

    -- ---------- Verlauf ----------
    p.logTable = UI:Table(p, {
        columns = {
            { key = "t", title = L["Datum"], width = 110 },
            { key = "kind", title = L["Art"], width = 110 },
            { key = "name", title = L["Item"], width = 210 },
            { key = "qty", title = L["Menge"], width = 60, align = "RIGHT" },
            { key = "net", title = L["Betrag"], width = 130, align = "RIGHT" },
            { key = "player", title = L["Mitspieler"], width = 120 },
            { key = "src", title = L["Quelle"], width = 80 },
        },
        rows = 12, rowHeight = 22, sortKey = "t", sortAsc = false,
        cell = function(e, key)
            if key == "t" then return date("%d.%m. %H:%M", e.t) end
            if key == "kind" then
                local lbl = KIND_LABEL[e.kind] or e.kind      -- R1: Forever hat eine Einzahlung je Auktion (keine "AH-Gebühr")
                return "|cff" .. (KIND_COLOR[e.kind] or "ffffff") .. L[lbl] .. "|r"
            end
            if key == "name" then return e.itemID and A:GetItemName(e.itemID) or e.name or "?" end
            if key == "qty" then return tostring(e.qty or 1) end
            if key == "net" then return Signed(e.net) end
            if key == "player" then return e.player or "" end
            if key == "src" then
                return L[({ mail = "Post", sniper = "Sniper", post = "Verkaufen", buy = "Einkauf" })[e.src] or "-"]
            end
        end,
        sortValue = function(e, key)
            if key == "name" then return string.lower(UI.ItemName(e)) end
            if key == "kind" or key == "player" or key == "src" then return tostring(e[key] or "") end
            return e[key]
        end,
        emptyText = L["Noch keine Buchungen in diesem Zeitraum.\nÖffne deinen Briefkasten - die Rechnungen werden automatisch gelesen."],
    })
    p.logTable:Fill(0, -134, 0, 24)

    -- ---------- Statistik ----------
    p.statsFrame = CreateFrame("Frame", nil, p)
    p.statsFrame:SetPoint("TOPLEFT", 0, -134)
    p.statsFrame:SetSize(930, 300)
    p.statTable = UI:Table(p.statsFrame, {
        columns = {
            { key = "name", title = L["Item"], width = 180 },
            { key = "posted", title = L["eingestellt"], width = 76, align = "RIGHT" },
            { key = "sold", title = L["verkauft"], width = 70, align = "RIGHT" },
            { key = "rate", title = L["Quote"], width = 62, align = "RIGHT",
              tooltip = L["Verkauft / eingestellt (nur Auktionen, die du über das Addon eingestellt hast)"] },
            { key = "avg", title = L["Ø Preis"], width = 100, align = "RIGHT" },
        },
        rows = 12, rowHeight = 22, sortKey = "sold", sortAsc = false,
        cell = function(r, key)
            if key == "name" then return UI.ItemName(r) end
            if key == "rate" then
                if not r.rate then return "|cff666666-|r" end
                local col = (r.rate >= 60 and "33dd55") or (r.rate >= 30 and "ffcc33") or "ff5544"
                return string.format("|cff%s%d%%|r", col, math.floor(r.rate + 0.5))
            end
            if key == "avg" then return A:FormatMoney(r.avg) end
            return r[key] > 0 and tostring(r[key]) or "-"
        end,
        sortValue = function(r, key)
            if key == "name" then return string.lower(UI.ItemName(r)) end
            return r[key]
        end,
        onClick = function(r) if r.itemID then UI:OpenChart(r.itemID) end end,
        emptyText = L["Noch keine Verkäufe in diesem Zeitraum."],
    })
    p.statTable:SetPoint("TOPLEFT", 0, 0)
    p.hourChart = BarChart(p.statsFrame, 24, 395, 150)
    p.hourChart:SetPoint("TOPLEFT", 530, 0)
    p.dayChart = BarChart(p.statsFrame, 7, 395, 140)
    p.dayChart:SetPoint("TOPLEFT", p.hourChart, "BOTTOMLEFT", 0, -4)

    -- ---------- Gold ----------
    p.goldFrame = CreateFrame("Frame", nil, p)
    p.goldFrame:SetPoint("TOPLEFT", 0, -134)
    p.goldFrame:SetSize(930, 300)
    p.charTable = UI:Table(p.goldFrame, {
        columns = {
            { key = "name", title = L["Charakter"], width = 140 },
            { key = "money", title = L["Gold"], width = 130, align = "RIGHT" },
            { key = "items", title = L["Items"], width = 56, align = "RIGHT",
              tooltip = L["Gegenstände in Taschen und Bank (Bank: beim letzten Öffnen der Bank)"] },
            { key = "updated", title = L["zuletzt"], width = 96 },
        },
        rows = 12, rowHeight = 22, idKey = "key", sortKey = "money", sortAsc = false,
        itemTooltip = false, noMenu = true,
        cell = function(c, key)
            if key == "name" then return (c.me and "|cffffd700* |r" or "") .. c.name end
            if key == "money" then return A:FormatMoney(c.money) end
            if key == "items" then return tostring(c.items) end
            if key == "updated" then return A:FormatAgo(c.updated) end
        end,
        sortValue = function(c, key)
            if key == "name" then return string.lower(c.name) end
            return c[key]
        end,
        action = {
            text = "X", width = 26,
            tooltip = L["Charakter aus der Liste entfernen (zweimal klicken)"],
            onClick = function(c)
                if p.confirmChar ~= c.key then
                    p.confirmChar = c.key
                    p.info:SetText(L["Nochmal klicken, um den Charakter zu entfernen."])
                    return
                end
                p.confirmChar = nil
                local _, msg = A.Chars:Remove(c.key)
                p.info:SetText(msg)
                p:Refresh()
            end,
        },
        emptyText = L["Noch keine Charaktere."],
    })
    p.charTable:SetPoint("TOPLEFT", 0, 0)
    p.goldChart = BarChart(p.goldFrame, 30, 410, 294)
    p.goldChart:SetPoint("TOPLEFT", 500, 0)

    -- ---------- Vermögen: Taschen, Bank, Twinks ----------
    p.assetTable = UI:Table(p, {
        columns = {
            { key = "name", title = L["Item"], width = 220 },
            { key = "count", title = L["Menge"], width = 60, align = "RIGHT" },
            { key = "where", title = L["Wo"], width = 190,
              tooltip = L["T = Taschen, B = Bank (dieser Charakter), W = Twinks"] },
            { key = "unit", title = L["Marktwert"], width = 110, align = "RIGHT" },
            { key = "value", title = L["Wert"], width = 120, align = "RIGHT",
              tooltip = L["Menge x Marktwert"] },
            { key = "vendorValue", title = L["Händler"], width = 100, align = "RIGHT",
              tooltip = L["Was ein Händler für alles zusammen zahlt"] },
        },
        rows = 12, rowHeight = 22, sortKey = "value", sortAsc = false,
        cell = function(r, key)
            if key == "name" then return UI.ItemName(r) end
            if key == "count" then return tostring(r.count) end
            if key == "where" then
                local parts = {}
                if r.bags > 0 then table.insert(parts, "T " .. r.bags) end
                if r.bank > 0 then table.insert(parts, "B " .. r.bank) end
                if r.alts > 0 then table.insert(parts, "W " .. r.alts) end
                if (r.guild or 0) > 0 then table.insert(parts, "G " .. r.guild) end
                return table.concat(parts, "  ")
            end
            if key == "unit" then return r.unit and A:FormatMoney(math.floor(r.unit)) or "|cff777777-|r" end
            if key == "value" then return r.value > 0 and A:FormatMoney(r.value) or "|cff777777-|r" end
            if key == "vendorValue" then return r.vendorValue > 0 and A:FormatMoney(r.vendorValue) or "|cff777777-|r" end
        end,
        sortValue = function(r, key)
            if key == "name" then return string.lower(UI.ItemName(r)) end
            if key == "where" then return r.alts end
            return r[key] or 0
        end,
        onClick = function(r) UI:OpenChart(r.itemID) end,
        emptyText = L["Noch keine Daten. Taschen werden beim Einloggen gelesen, die Bank beim Öffnen der Bank."],
    })
    p.assetTable:Fill(0, -134, 0, 24)
    p.assetTable:Hide()

    -- ---------- Entzaubern (Sammelkauf E4) ----------
    p.deTable = UI:Table(p, {
        columns = {
            { key = "day", title = L["Tag"], width = 130 },
            { key = "count", title = L["Teile"], width = 60, align = "RIGHT",
              tooltip = L["Über den Sammelkauf gekauft und entzaubert"] },
            { key = "spent", title = L["ausgegeben"], width = 120, align = "RIGHT" },
            { key = "value", title = L["Wert Materialien"], width = 130, align = "RIGHT",
              tooltip = L["Realer Wert nach AH-Gebühr; schon verkauftes Material zum echten Erlös (eigene Verkäufe der letzten 14 Tage)."] },
            { key = "profit", title = L["Gewinn"], width = 120, align = "RIGHT" },
            { key = "roi", title = L["Rendite"], width = 80, align = "RIGHT" },
            { key = "own", title = L["eigene"], width = 70, align = "RIGHT",
              tooltip = L["Eigene Teile entzaubert (ohne Kauf) - nur Materialwert"] },
        },
        rows = 12, rowHeight = 22, sortKey = "day", sortAsc = false,
        cell = function(r, key)
            if key == "day" then return date("%d.%m.%Y", r.day) end
            if key == "count" then return tostring(r.count) end
            if key == "spent" then return A:FormatMoney(r.spent) end
            if key == "value" then return A:FormatMoney(r.value) end
            if key == "profit" then return Signed(r.profit) end
            if key == "roi" then return r.roi and string.format("%d %%", math.floor(r.roi + 0.5)) or "|cff777777-|r" end
            if key == "own" then return r.own > 0 and string.format("%d (%s)", r.own, A:FormatMoney(r.ownValue)) or "|cff777777-|r" end
        end,
        sortValue = function(r, key) return r[key] or -1e12 end,
        emptyText = L["Noch nichts entzaubert. Kaufen -> Entzaubern lohnt, dann /ahs entzaubern."],
    })
    p.deTable:Fill(0, -134, 0, 24)
    p.deTable:Hide()
    -- H8: Abrechnung je Kauf-Charge (letzte Charge, Maus = alle)
    p.deCharge = CreateFrame("Frame", nil, p)
    p.deCharge:SetPoint("BOTTOMLEFT", 0, 2)
    p.deCharge:SetPoint("BOTTOMRIGHT", 0, 2)
    p.deCharge:SetHeight(18)
    p.deCharge.text = UI:Label(p.deCharge, "", "GameFontHighlightSmall", C.text)
    p.deCharge.text:SetPoint("LEFT", 4, 0)
    p.deCharge.text:SetPoint("RIGHT", -4, 0)
    p.deCharge:EnableMouse(true)
    p.deCharge:SetScript("OnEnter", function(self)
        if not self.lines or #self.lines == 0 then return end
        UI:AnchorTooltip(self)
        GameTooltip:SetText(L["Abrechnung je Kauf-Charge"], 1, 1, 1)
        if self.total then GameTooltip:AddLine(self.total, 1, 0.82, 0, true) end
        for i = #self.lines, math.max(1, #self.lines - 9), -1 do GameTooltip:AddLine(self.lines[i], 0.9, 0.9, 0.9, true) end
        GameTooltip:AddLine(L["Verkauft: Verkäufe der Materialien ab dem Kauftag, älteste Charge zuerst. Lager: Rest zum realistischen Materialpreis nach Gebühr."], 0.6, 0.6, 0.6, true)
        GameTooltip:Show()
    end)
    p.deCharge:SetScript("OnLeave", function() GameTooltip:Hide() end)
    p.deCharge:Hide()

    -- ---------- Rendite je Geschäftsart und Gold pro Stunde (H7, H9) ----------
    local BIZ_NAMES = { flip = L["Flippen"], craft = L["Herstellen"], de = L["Entzaubern"], raw = L["Rohstoffe"], total = L["Gesamt"] }
    p.bizTable = UI:Table(p, {
        columns = {
            { key = "kind", title = L["Geschäftsart"], width = 130 },
            { key = "invested", title = L["eingesetzt"], width = 120, align = "RIGHT",
              tooltip = L["Einkauf bzw. Materialkosten der verkauften Stücke und verlorene Einzahlungen"] },
            { key = "revenue", title = L["erlöst"], width = 120, align = "RIGHT", tooltip = L["Erlös nach AH-Anteil"] },
            { key = "profit", title = L["Gewinn"], width = 120, align = "RIGHT" },
            { key = "roi", title = L["Rendite"], width = 70, align = "RIGHT" },
            { key = "perHour", title = L["Gold/Std."], width = 130, align = "RIGHT",
              tooltip = L["Gewinn je gemessener Stunde. Gezählt wird nur aktive Zeit: Pausen über 2 Min. und AFK zählen nicht, automatische Scans auch nicht."] },
            { key = "seconds", title = L["Zeit"], width = 100, align = "RIGHT" },
        },
        rows = 6, rowHeight = 22, idKey = "kind", sortKey = "order", sortAsc = true,
        itemTooltip = false, noMenu = true,
        cell = function(r, key)
            local Act = A.Activity
            if key == "kind" then return (r.kind == "total" and "|cffffd100" or "") .. (BIZ_NAMES[r.kind] or r.kind) .. (r.kind == "total" and "|r" or "") end
            if key == "invested" then return A:FormatMoney(r.invested) end
            if key == "revenue" then return A:FormatMoney(r.revenue) end
            if key == "profit" then return Signed(r.profit) end
            if key == "roi" then return r.roi and string.format("%d %%", math.floor(r.roi + 0.5)) or "|cff777777-|r" end
            if key == "perHour" then return Act:PerHourText(r) end
            if key == "seconds" then return (r.seconds or 0) > 0 and Act:DurationText(r.seconds) or "|cff777777-|r" end
        end,
        sortValue = function(r, key) if key == "kind" then return r.order end return r[key] or -1e12 end,
        emptyText = L["Noch keine Geschäfte in diesem Zeitraum."],
    })
    p.bizTable:Fill(0, -134, 0, 24)
    p.bizTable:Hide()

    p.hint = UI:Label(p, L["Verkäufe und Käufe kommen aus den Rechnungen im Briefkasten (einfach öffnen), Einstellgebühren aus dem Tab Verkaufen."], "GameFontDisableSmall", C.textDim)
    p.hint:SetPoint("BOTTOMLEFT", 0, 4)
    p.hint:SetWidth(900)

    -- ------------------------------------------------------------
    function p:RefreshStats()
        local st = Le:Stats(self.period)
        self.statTable:SetData(st.items, true)
        local values, labels, hl = {}, {}, {}
        for h = 0, 23 do
            values[h + 1] = st.hours[h].n > 0 and st.hours[h].n or nil
            labels[h + 1] = (h % 3 == 0) and tostring(h) or ""
        end
        for k = 1, math.min(3, #st.best) do hl[st.best[k] + 1] = true end
        self.hourChart:SetData(values, labels, hl)
        self.hourChart.title:SetText(L["Verkäufe nach Uhrzeit"])
        if #st.best > 0 then
            local parts = {}
            for k = 1, math.min(3, #st.best) do table.insert(parts, string.format("%02d-%02d", st.best[k], (st.best[k] + 1) % 24)) end
            self.hourChart.info:SetText(L["Beste Zeit: "] .. table.concat(parts, ", ") .. L[" Uhr"])
        else
            self.hourChart.info:SetText(L["Noch keine Verkäufe in diesem Zeitraum."])
        end
        local dv, dl, bestDay, bestN = {}, {}, nil, 0
        for d = 1, 7 do
            dv[d] = st.weekdays[d].n > 0 and st.weekdays[d].n or nil
            dl[d] = L[WEEKDAYS[d]]
            if st.weekdays[d].n > bestN then bestDay, bestN = d, st.weekdays[d].n end
        end
        self.dayChart:SetData(dv, dl, bestDay and { [bestDay] = true } or nil)
        self.dayChart.title:SetText(L["Verkäufe nach Wochentag"])
        self.dayChart.info:SetText("")
        local posted, sold = 0, 0
        for _, r in ipairs(st.items) do posted = posted + r.posted; sold = sold + r.sold end
        self.info:SetText((posted > 0 and string.format(L["Verkaufsquote gesamt: %d %% (%d von %d)"], math.floor(math.min(100, sold / posted * 100) + 0.5), sold, posted)
            or L["Verkaufsquote: erst Auktionen über den Tab Verkaufen einstellen."]) .. "   |   " .. Le:DeviationText(self.period))
    end

    function p:RefreshGold()
        local chars = A.Chars:GetAll()
        self.charTable:SetData(chars, true)
        local days = A.Chars:DailyTotals(30)
        local values, labels = {}, {}
        for i, d in ipairs(days) do
            values[i] = d.money
            labels[i] = (i % 5 == 0 or i == 30) and date("%d.", d.t) or ""
        end
        self.goldChart:SetData(values, labels)
        self.goldChart.title:SetText(L["Gold aller Charaktere (30 Tage)"])
        local first, last
        for _, d in ipairs(days) do if d.money then first = first or d.money; last = d.money end end
        local change = (first and last) and (last - first) or 0
        self.goldChart.info:SetText(string.format(L["Gesamt: %s   |   30 Tage: %s"], A:FormatMoney(A.Chars:TotalMoney()), Signed(change)))
        if not self.confirmChar then
            self.info:SetText(string.format(L["%d Charaktere - Bank wird beim Öffnen der Bank aktualisiert"], #chars))
        end
    end

    -- Karten auf die ganze Breite verteilen
    function p:LayoutCards()
        local w = self:GetWidth()
        if not w or w < 400 then return end
        local nCards = 0
        for _ in pairs(self.cards) do nCards = nCards + 1 end
        local cw = math.floor((w - 6 * (nCards - 1)) / nCards)
        for _, c in pairs(self.cards) do
            c:SetWidth(cw)
            c:ClearAllPoints()
            c:SetPoint("TOPLEFT", (c.index - 1) * (cw + 6), -32)
        end
    end

    function p:Refresh()
        self:LayoutCards()
        for _, b in ipairs(self.periodButtons) do
            b.label:SetTextColor(unpack(b.key == self.period and C.accent or C.text))
        end
        -- BP5: EIN Endergebnis
        local BK = A.Books
        if BK then pcall(BK.RecordGold, BK) end                  -- BP6: Gold beim Öffnen mitschreiben
        local s = BK and BK:Summary(self.period) or { profit = 0, rev = 0, cost = 0, fees = 0 }
        -- BE1: Rendite neben dem Gewinn; BE3: "davon ohne Einkauf" nur, wenn > 0
        -- BH1307: mehr als 30 % ohne Einkauf -> gross "Gewinn mit Einkauf", klein gelb "dazu ohne Einkauf … – Kostenbasis prüfen"
        local main, roiT, extra = s.profit, BK and BK:RoiText(s) or "", nil
        if BK and BK.HeadParts then main, roiT, extra = BK:HeadParts(s) end
        -- TB138-6/TB138c-1: EIN Gewinn im Kopf (gleich wie im Fenster Details); "ohne Einkauf" nur grau als Herkunft
        local head = Signed(s.profit)
        self.cards.profit.value:SetText(head .. "  |cffcccccc" .. roiT .. "|r")
        local sub = string.format(L["Verkauft %s · Eingesetzt %s · Gebühren %s"], A:FormatMoney(s.rev), A:FormatMoney(s.cost), A:FormatMoney(s.fees))
        if (s.freeRev or 0) > 0 then sub = sub .. " · |cff999999" .. string.format(L["Herkunft unbekannt: %s"], A:FormatMoney(s.freeRev)) .. "|r" end
        self.cards.profit.sub:SetText(sub)
        for key, b in pairs(self.viewButtons) do
            b:SetText(key == self.view and ("> " .. b.label2 .. " <") or b.label2)
            -- Breite an den (übersetzten) Text anpassen: sechs Ansichten in einer Zeile
            local fs = b.label or (b.GetFontString and b:GetFontString())
            local w = fs and fs.GetStringWidth and fs:GetStringWidth()
            if w and w > 0 then b:SetWidth(math.max(64, math.floor(w + 18))) end
        end
        self.itemTable:Hide(); self.logTable:Hide(); self.statsFrame:Hide(); self.goldFrame:Hide(); self.assetTable:Hide(); self.deTable:Hide(); self.bizTable:Hide()
        if self.deCharge then self.deCharge:Hide() end
        self.hint:SetShown(self.view == "items" or self.view == "log")
        if self.view == "items" then
            self.itemTable:Show()
            local rows = BK and BK:ByItem(self.period, true) or {}
            self.itemTable:SetData(rows, true)
            self.info:SetText(string.format(L["%d Items - Klick öffnet den Preisverlauf"], #rows))
        elseif self.view == "log" then
            self.logTable:Show()
            local entries = {}
            for _, e in ipairs(Le:GetEntries(self.period)) do
                local net
                if e.kind == "sale" then net = e.amount - (e.cut or 0) else net = -e.amount end
                table.insert(entries, { t = e.t, kind = e.kind, itemID = e.itemID, name = e.name, qty = e.qty, net = net,
                                        player = e.player, src = e.src })
            end
            self.logTable:SetData(entries, true)
            self.info:SetText(string.format(L["%d Buchungen"], #entries))
        elseif self.view == "stats" then
            self.statsFrame:Show()
            self:RefreshStats()
        elseif self.view == "guild" then
            self.assetTable:Show()
            local K = A.Comfort
            local rows, tot = K:GuildBankValue()
            if not K:GuildBankSupported() then
                self.assetTable.empty:SetText(L["Eine Gildenbank gibt es in dieser WoW-Version nicht (erst ab TBC)."])
            elseif not tot.guild then
                self.assetTable.empty:SetText(L["Du bist in keiner Gilde."])
            else
                self.assetTable.empty:SetText(L["Noch keine Daten. Öffne einmal die Gildenbank - alle Fächer, die du sehen darfst, werden gelesen."])
            end
            self.assetTable:SetData(rows, true)
            if tot.time then
                self.info:SetText(string.format(L["%s: Waren %s (Marktwert) / %s (Händler)   |   Gold %s   |   Stand %s"],
                    tot.guild or "?", A:FormatMoney(tot.market), A:FormatMoney(tot.vendor), A:FormatMoney(tot.gold), A:FormatAgo(tot.time)))
            else
                self.info:SetText("")
            end
        elseif self.view == "biz" then
            self.bizTable:Show()
            local Act = A.Activity
            local rows, total = Act:Report(self.period)
            local list = {}
            for i, k in ipairs(Act.KINDS) do rows[k].order = i; list[#list + 1] = rows[k] end
            total.order = 9; list[#list + 1] = total
            self.bizTable:SetData(list, true)
            local _, today = Act:Report("today")
            self.info:SetText(string.format(L["Dein Stundenlohn heute: %s"], Act:PerHourText(today)))
        elseif self.view == "de" then
            self.deTable:Show()
            local rows, t = Le:DisenchantReport(self.period)
            self.deTable:SetData(rows, true)
            self.info:SetText(string.format(L["Gesamt: %d Teile · ausgegeben %s · Materialien %s · Gewinn %s · Rendite %s · noch offen %d (%s)"],
                t.count, A:FormatMoney(t.spent), A:FormatMoney(t.value), Signed(t.profit),
                t.roi and string.format("%d %%", math.floor(t.roi + 0.5)) or "-", t.open, A:FormatMoney(t.openSpent)))
            local okC, charges = pcall(Le.DisenchantCharges, Le)
            if okC and charges and #charges > 0 then
                local lines = {}
                for i, c in ipairs(charges) do lines[i] = Le:ChargeLine(c) end
                self.deCharge.lines = lines
                self.deCharge.total = Le:ChargeTotalLine(Le:ChargeTotal(charges))
                -- LG3: eine Zeile mit allen Entzauber-Käufen (Kauf, Beute verkauft / im AH / Lager, Ergebnis)
                self.deCharge.text:SetText(#charges > 1 and self.deCharge.total or lines[#lines])
                self.deCharge:Show()
            end
        elseif self.view == "assets" then
            self.assetTable:Show()
            self.assetTable.empty:SetText(L["Noch keine Daten. Taschen werden beim Einloggen gelesen, die Bank beim Öffnen der Bank."])
            local rows, tot = A.Extras:InventoryValue()
            self.assetTable:SetData(rows, true)
            self.info:SetText(string.format(L["Waren: %s (Marktwert) / %s (Händler)   |   Gold: %s   |   Gesamt: %s"],
                A:FormatMoney(tot.market), A:FormatMoney(tot.vendor), A:FormatMoney(tot.gold), A:FormatMoney(tot.market + tot.gold)))
        else
            self.goldFrame:Show()
            self:RefreshGold()
        end
    end

    return p
end

UI:RegisterTab("ledger", "Buchhaltung", 5.5, BuildLedger)

A:On("LEDGER_CHANGED", function()
    if UI.activeTab == "ledger" then UI:RefreshActive() end
end)
A:On("DE_LEARNED", function()
    if UI.activeTab == "ledger" then UI:RefreshActive() end
end)
A:On("CHARS_CHANGED", function()
    local tab = UI:GetTab("ledger")
    if UI.activeTab == "ledger" and tab and tab.panel and tab.panel.view == "gold" then UI:RefreshActive() end
end)

A:On("GUILDBANK_CHANGED", function()
    local tab = UI:GetTab("ledger")
    if tab and tab.panel and tab.panel:IsVisible() and tab.panel.view == "guild" then tab.panel:Refresh() end
end)

-- ------------------------------------------------------------
-- EB7/EB-DET: Fenster "Buchhaltung – Details" (Heute / Woche / Gesamt, Standard Gesamt). Nur Anzeige gebuchter Zahlen,
-- keine Rechenwege (Entscheid OR); Zahlen grün/rot (Entscheid 14.11. 01:15).
-- ------------------------------------------------------------
local DETAIL_PERIODS = { { "today", "Heute" }, { "7", "Woche" }, { "all", "Gesamt" } }
local WAY_NAMES = { de = "Entzaubern", flip = "Flippen", vendor = "Händler", craft = "Herstellen" }
function UI:ShowBooksDetails(key)
    local w = self.booksDetails
    if not w then
        w = self:Dialog("AHSentinelBooksDetails", 440, 450, L["Buchhaltung – Details"])
        w.key = "all"
        w.btns = {}
        local prevB
        for _, per in ipairs(DETAIL_PERIODS) do
            local b = UI:Button(w, L[per[2]], 90, 22, function() UI:ShowBooksDetails(per[1]) end)
            if prevB then b:SetPoint("LEFT", prevB, "RIGHT", 4, 0) else b:SetPoint("TOPLEFT", 14, -36) end
            b.key, b.text = per[1], L[per[2]]
            w.btns[#w.btns + 1] = b
            prevB = b
        end
        w.lines = {}
        for i = 1, 16 do
            local l = UI:Label(w, "", "GameFontHighlight", C.text)
            l:SetPoint("TOPLEFT", 18, -68 - (i - 1) * 22)
            l:SetPoint("RIGHT", w, "RIGHT", -18, 0)
            w.lines[i] = l
        end
        self.booksDetails = w
    end
    w.key = key or w.key or "all"
    for _, b in ipairs(w.btns) do b:SetText(b.key == w.key and ("> " .. b.text .. " <") or b.text) end
    local BK = A.Books
    local ok, d = pcall(BK.Details, BK, w.key)
    local rows = {}
    local function money(v) local c = v >= 0 and "|cff33dd55" or "|cffff5544"; return c .. (v < 0 and "−" or "") .. A:FormatMoney(math.abs(v)) .. "|r" end
    local grey = "|cff888888"
    if ok and d then
        rows[#rows + 1] = L["Handel (Gewinn)"] .. ": " .. money(d.profit)
        rows[#rows + 1] = d.perHour and string.format(L["Handel pro Stunde: %s (bei %.1f Std. Spielzeit)"], money(d.perHour), d.onlineH)
            or (grey .. string.format(L["Handel pro Stunde: lernt noch (%.1f Std. Spielzeit)"], d.onlineH) .. "|r")
        rows[#rows + 1] = L["Eigenbedarf"] .. ": " .. A:FormatMoney(d.own)
        rows[#rows + 1] = L["Spielkosten (Reparatur)"] .. ": " .. A:FormatMoney(d.gameCost or 0)
        if (d.missing or 0) > 0 then rows[#rows + 1] = grey .. L["Fehlbestand (nicht im Gewinn)"] .. ": " .. A:FormatMoney(d.missing) .. "|r" end
        rows[#rows + 1] = string.format(L["%s verfallen"], BK:DepositWord()) .. ": " .. (d.lost > 0 and money(-d.lost) or A:FormatMoney(0))
        rows[#rows + 1] = d.sellRate and string.format(L["Verkaufsquote: %d %% (%d von %d Stück)"], math.floor(d.sellRate * 100 + 0.5), d.sold, d.posted)
            or (grey .. L["Verkaufsquote: lernt noch"] .. "|r")
        rows[#rows + 1] = " "
        rows[#rows + 1] = L["Rendite je Weg"] .. ":"
        for _, x in ipairs(d.ways) do
            local name = L[WAY_NAMES[x.way] or x.way]
            if x.pct then
                rows[#rows + 1] = string.format("   %s: %s%+d %%|r (%d)", name, x.pct >= 0 and "|cff33dd55" or "|cffff5544", math.floor(x.pct + 0.5), x.n)
            else
                rows[#rows + 1] = grey .. string.format("   %s: %s (%d)", name, L["lernt noch"], x.n) .. "|r"
            end
        end
        -- SK1: nur wenn eine Selbstkontrolle rot ist
        local scRed = A.SelfCheck and A.SelfCheck.RedCount and A.SelfCheck:RedCount() or 0
        rows[#rows + 1] = scRed > 0 and ("|cffff9933" .. string.format(L["Buchhaltung prüft sich: %d Abweichung(en) – Details im Testbericht"], scRed) .. "|r") or " "
        if d.gold then
            -- TB138c-3: solange die Abstimmung nicht stimmig ist, nicht rot warnen - grau "wird abgeglichen"
            if d.gold.ok then
                rows[#rows + 1] = string.format(L["Gold-Abstimmung: Gold %s, gebucht %s %s"], money(d.gold.change), money(d.gold.explained), "|cff33dd55✓|r")
            else
                rows[#rows + 1] = grey .. L["Gold-Abstimmung: wird abgeglichen"] .. "|r"
            end
        else
            rows[#rows + 1] = grey .. L["Gold-Abstimmung: lernt noch"] .. "|r"
        end
    end
    for i, l in ipairs(w.lines) do l:SetText(rows[i] or "") end
    w:Show()
    w:Raise()
end

