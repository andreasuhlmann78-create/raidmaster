-- GuildSentinel - Professions.lua
-- Berufe-Verzeichnis: Öffnet jemand ein Berufsfenster, liest GuildSentinel Stufe und alle Rezepte aus
-- und schickt sie an die Gilde. So weiß jeder mit dem Addon, wer was herstellen kann.
-- Zwei Wege, je nach Spielclient (ns.Game.MODERN_PROFESSIONS):
--   * WoW Forever: neues Berufsfenster im Retail-Stil (ProfessionsFrame, C_TradeSkillUI)
--   * Classic Era und TBC: klassisches Fenster (TradeSkillFrame, CraftFrame für Verzauberkunst)
-- Das Datenformat ist auf beiden Wegen gleich (Berufsname = Hauptberuf in der Sprache des Spiels).
-- Mit RaidMaster: RaidMaster liest und verschickt die Berufe (gleiches Format in RaidMasterDB.prof),
-- GuildSentinel zeigt sie nur an. So gehen die Berufe nicht doppelt durch den Gildenkanal.
--
--   G.prof[Name] = { c = Klasse, t = Zeit, p = { [Beruf] = { r = Stufe, m = Max, n = { Rezepte }, i = { Item-IDs } } } }

local ADDON, ns = ...
local L = ns.L
local P = {}
ns.Prof = P
local Game = ns.Game

-- Berufe mit Fenster (Zauber-ID zum Öffnen; der Name kommt aus dem Spiel, also in jeder Sprache richtig)
P.CRAFT_SPELLS = { 2259, 2018, 7411, 4036, 2108, 3908, 2550, 3273, 2656 }  -- Alchemie, Schmieden, Verzauberkunst, Ingenieur, Leder, Schneidern, Kochen, Erste Hilfe, Verhüttung
P.MINING = 2575

-- Zaubername über ns.API (moderner Weg zuerst, siehe API.lua)
local function SpellName(id) return ns.SpellName(id) end

local function Store()
	return ns.G().prof
end

-- alle bekannten Berufe: eigene Daten plus die aus RaidMaster (der neuere Stand gewinnt)
function P:All()
	local gs = Store()
	local rm = ns.RMI:Profs()
	local out = {}
	-- kaputte Einträge (falscher Typ, z. B. nach einem Fehler in alten Daten) überspringen
	for k, v in pairs(gs) do
		if type(k) == "string" and type(v) == "table" and type(v.p) == "table" then out[k] = v end
	end
	if not rm then return out end
	for k, v in pairs(rm) do
		if type(k) == "string" and type(v) == "table" and type(v.p) == "table" and (not out[k] or (v.t or 0) >= (out[k].t or 0)) then
			out[k] = v
		end
	end
	return out
end

function P:Of(name)
	return self:All()[name]
end

local function Mine()
	local s = Store()
	local me = ns.Me()
	s[me] = s[me] or { p = {} }
	s[me].g = nil              -- eigene Angaben ersetzen einen Eintrag aus der Gilden-Berufsliste
	if type(s[me].p) ~= "table" then s[me].p = {} end
	s[me].c = select(2, UnitClass("player"))
	return s[me]
end

------------------------------------------------------------
-- Welcher Weg? Entscheidend ist der Spielclient; die Prüfung der Befehle ist nur ein Sicherheitsnetz
-- (fehlt die Schnittstelle des gewählten Wegs, wird der andere versucht und das einmal im Debug gemeldet)
------------------------------------------------------------
local warned = false
local function UseModern()
	local modernAPI = C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs and C_TradeSkillUI.GetRecipeInfo and true or false
	local classicAPI = (GetTradeSkillLine and GetNumTradeSkills) and true or false
	local modern
	if Game.MODERN_PROFESSIONS then
		modern = modernAPI or not classicAPI      -- nichts da: trotzdem modern versuchen (liefert dann nichts)
	else
		modern = (not classicAPI) and modernAPI
	end
	if modern ~= (Game.MODERN_PROFESSIONS and true or false) and not warned and (ns.debug or (ns.Test and ns.Test:Active())) then
		warned = true
		ns:Print("Berufsfenster: " .. (modern and "modern" or "klassisch") .. " (Sicherheitsnetz, Client erwartet anderes)")
	end
	return modern
end
P.UseModern = UseModern

-- Text für die Diagnose: "modern (Forever)" oder "klassisch"
function P:WindowKind()
	return UseModern() and L["modern (Forever)"] or L["klassisch"]
end

-- fremde Fenster (verlinkter Beruf, Gildenberuf, NPC) nicht einlesen
local function IsOwnTradeSkill()
	if C_TradeSkillUI then
		if C_TradeSkillUI.IsTradeSkillLinked and C_TradeSkillUI.IsTradeSkillLinked() then return false end
		if C_TradeSkillUI.IsTradeSkillGuild and C_TradeSkillUI.IsTradeSkillGuild() then return false end
		if C_TradeSkillUI.IsNPCCrafting and C_TradeSkillUI.IsNPCCrafting() then return false end
	end
	if IsTradeSkillLinked and IsTradeSkillLinked() then return false end
	return true
end

local function IDFromLink(link)
	return type(link) == "string" and tonumber(link:match("item:(%d+)")) or 0
end

-- Forever: Beruf, Stufe, Max – Name vom Basis-Beruf (Hauptberuf), Stufe vom Unterberuf, falls vorhanden
local function ModernProfession()
	local base = C_TradeSkillUI.GetBaseProfessionInfo and C_TradeSkillUI.GetBaseProfessionInfo()
	local child = C_TradeSkillUI.GetChildProfessionInfo and C_TradeSkillUI.GetChildProfessionInfo()
	local name = base and base.professionName
	local rank = (child and child.skillLevel) or (base and base.skillLevel)
	local max = (child and child.maxSkillLevel) or (base and base.maxSkillLevel)
	return name, rank, max
end

-- Forever: Item-ID des Ergebnisses (0 = kein Gegenstand, z. B. Verzauberung)
local function ModernOutputItem(recipeID)
	if C_TradeSkillUI.GetRecipeOutputItemData then
		local ok, data = pcall(C_TradeSkillUI.GetRecipeOutputItemData, recipeID)
		if ok and type(data) == "table" and data.itemID then return data.itemID end
	end
	if C_TradeSkillUI.GetRecipeItemLink then
		local ok, link = pcall(C_TradeSkillUI.GetRecipeItemLink, recipeID)
		if ok and link then return IDFromLink(link) end
	end
	return 0
end

-- Forever: alle gelernten Rezepte (GetAllRecipeIDs liefert alles, Filter im Fenster spielen keine Rolle)
local function ReadModern()
	if not C_TradeSkillUI then return nil, nil, nil, {}, {} end
	local profName, rank, max = ModernProfession()
	local ids, names = {}, {}
	local ok, all = pcall(C_TradeSkillUI.GetAllRecipeIDs)
	if ok and type(all) == "table" then
		for _, recipeID in ipairs(all) do
			local info = C_TradeSkillUI.GetRecipeInfo(recipeID)
			if info and info.learned and info.name then
				names[#names + 1] = info.name
				ids[#ids + 1] = ModernOutputItem(recipeID)
			end
		end
	end
	return profName, rank, max, ids, names
end

-- Stufen aller Berufe aus der Fertigkeitenliste (auch Sammelberufe)
function P:ReadSkillLines()
	local out = {}
	-- Forever: Berufe über GetProfessions / GetProfessionInfo
	if Game.MODERN_PROFESSIONS and GetProfessions and GetProfessionInfo then
		local slots = { GetProfessions() }
		for i = 1, 6 do
			local idx = slots[i]
			if idx then
				local name, _, rank, max = GetProfessionInfo(idx)
				if name then out[name] = { r = rank, m = max } end
			end
		end
		if next(out) then return out end
	end
	-- sonst (Classic, TBC, oder als Sicherheitsnetz): Fertigkeitenliste
	if not GetNumSkillLines then return out end
	local section
	for i = 1, GetNumSkillLines() do
		local name, isHeader, _, rank, _, _, max = GetSkillLineInfo(i)
		if isHeader then
			section = name
		elseif name and (section == TRADE_SKILLS or section == SECONDARY_SKILLS) then
			out[name] = { r = rank, m = max }
		end
	end
	return out
end

-- offenes Berufsfenster lesen ("trade" = Fertigkeitenfenster, "craft" = Verzauberkunst in Classic)
function P:ScanOpen(kind)
	if not ns.guild then return nil end
	if not IsOwnTradeSkill() then return nil end
	local modern = UseModern()
	if ns.RMI:Active() then
		-- RaidMaster liest das Fenster selbst; hier nur merken, welcher Beruf dran war
		local profName
		if modern then profName = C_TradeSkillUI and (ModernProfession())
		else profName = (kind == "craft") and (GetCraftDisplaySkillLine and GetCraftDisplaySkillLine()) or (GetTradeSkillLine and GetTradeSkillLine()) end
		if not profName or profName == "" or profName == "UNKNOWN" then return nil end
		self.scanned = self.scanned or {}
		self.scanned[profName] = true
		C_Timer.After(1, function() ns:Fire("GS_PROF") end)
		local mine = self:Of(ns.Me())
		local v = mine and mine.p and mine.p[profName]
		return profName, v and v.n and #v.n or 0, false
	end
	local profName, rank, max
	local ids, names = {}, {}
	if modern then
		profName, rank, max, ids, names = ReadModern()
	elseif kind == "craft" then
		if not GetCraftDisplaySkillLine then return nil end
		profName, rank, max = GetCraftDisplaySkillLine()
		for i = 1, (GetNumCrafts and GetNumCrafts() or 0) do
			local name, _, ctype = GetCraftInfo(i)
			if name and ctype ~= "header" then
				ids[#ids + 1] = IDFromLink(GetCraftItemLink and GetCraftItemLink(i))
				names[#names + 1] = name
			end
		end
	else
		if not GetTradeSkillLine then return nil end
		profName, rank, max = GetTradeSkillLine()
		-- Filter/zugeklappte Kategorien würden Rezepte verstecken: nur lesen, wenn alles sichtbar ist
		for i = 1, (GetNumTradeSkills and GetNumTradeSkills() or 0) do
			local name, ttype, _, expanded = GetTradeSkillInfo(i)
			if ttype == "header" and expanded == false and ExpandTradeSkillSubClass then
				ExpandTradeSkillSubClass(0)
				break
			end
		end
		for i = 1, (GetNumTradeSkills and GetNumTradeSkills() or 0) do
			local name, ttype = GetTradeSkillInfo(i)
			if name and ttype ~= "header" then
				ids[#ids + 1] = IDFromLink(GetTradeSkillItemLink and GetTradeSkillItemLink(i))
				names[#names + 1] = name
			end
		end
	end
	if not profName or profName == "" or profName == "UNKNOWN" or #names == 0 then return nil end
	local me = Mine()
	local old = me.p[profName]
	-- Rezepte verlernt man nicht: bekannte behalten (falls ein Filter im Fenster welche versteckt)
	local seen = {}
	for _, n in ipairs(names) do seen[n] = true end
	if old and old.n then
		for k, n in ipairs(old.n) do
			if not seen[n] then
				names[#names + 1] = n
				ids[#ids + 1] = old.i and old.i[k] or 0
				seen[n] = true
			end
		end
	end
	local changed = not old or #(old.n or {}) ~= #names or old.r ~= rank
	me.p[profName] = { r = rank, m = max, n = names, i = ids }
	for name, v in pairs(self:ReadSkillLines()) do
		me.p[name] = me.p[name] or {}
		me.p[name].r, me.p[name].m = v.r, v.m
	end
	if changed then
		me.t = ns.Now()
		self:ScheduleSend()
	end
	self.scanned = self.scanned or {}
	self.scanned[profName] = true
	ns:Fire("GS_PROF")
	return profName, #names, changed
end

-- nur Stufen (z. B. Kräuterkunde) ohne Fenster
function P:UpdateLevels()
	if not ns.guild or ns.RMI:Active() then return end
	local me = Mine()
	local changed
	local now = self:ReadSkillLines()
	for name, v in pairs(now) do
		me.p[name] = me.p[name] or {}
		if me.p[name].r ~= v.r then changed = true end
		me.p[name].r, me.p[name].m = v.r, v.m
	end
	-- verlernte Berufe entfernen
	if next(now) then
		for name in pairs(me.p) do
			if not now[name] and not self:IsCraftName(name) then me.p[name] = nil; changed = true end
		end
	end
	if changed then
		me.t = ns.Now()
		self:ScheduleSend()
		ns:Fire("GS_PROF")
	end
end

function P:IsCraftName(name)
	for _, id in ipairs(self.CRAFT_SPELLS) do
		if SpellName(id) == name then return true end
	end
	return false
end

local function AfterScan(kind)
	local name, n = P:ScanOpen(kind)
	if name and P.announce then
		P.announce = nil
		ns:Print(string.format(L["%s eingelesen (%d Rezepte)."], name, n))
	end
end
-- ist das Berufsfenster offen? (Forever: ProfessionsFrame, Classic/TBC: TradeSkillFrame)
local function TradeWindowShown()
	if Game.MODERN_PROFESSIONS and ProfessionsFrame then return ProfessionsFrame:IsShown() and true or false end
	return (TradeSkillFrame and TradeSkillFrame:IsShown()) and true or false
end
P.TradeWindowShown = TradeWindowShown

-- Änderungen sammeln: höchstens ein Lesen pro Sekunde
local function LaterScan()
	if P.tsPending then return end
	P.tsPending = true
	C_Timer.After(1, function() P.tsPending = false; if TradeWindowShown() then AfterScan("trade") end end)
end

ns:On("TRADE_SKILL_SHOW", function() C_Timer.After(0.4, function() AfterScan("trade") end) end)
ns:On("TRADE_SKILL_UPDATE", LaterScan)
if Game.MODERN_PROFESSIONS then
	-- Forever: die Rezeptliste ist bei TRADE_SKILL_SHOW oft noch nicht fertig geladen
	ns:On("TRADE_SKILL_LIST_UPDATE", LaterScan)
	ns:On("TRADE_SKILL_DATA_SOURCE_CHANGED", LaterScan)
else
	ns:On("CRAFT_SHOW", function() C_Timer.After(0.4, function() AfterScan("craft") end) end)
end
ns:On("SKILL_LINES_CHANGED", function()
	if P.slPending then return end
	P.slPending = true
	C_Timer.After(2, function() P.slPending = false; P:UpdateLevels() end)
end)

------------------------------------------------------------
-- Berufe mit Fenster, die ich habe (für den Knopf "Nächsten Beruf öffnen")
------------------------------------------------------------
function P:Openable()
	local list = {}
	local skills = self:ReadSkillLines()
	for _, id in ipairs(self.CRAFT_SPELLS) do
		local name = SpellName(id)
		if name then
			local skill = (id == 2656) and SpellName(self.MINING) or name
			if skills[skill] or skills[name] then list[#list + 1] = name end
		end
	end
	return list
end

-- Forever: Berufsfenster über C_TradeSkillUI öffnen (skillLine steht in GetProfessionInfo an 7. Stelle; Verhüttung
-- gehört zu Bergbau). Nur aus einem Klick des Spielers aufrufen, nie aus einem Timer oder Ereignis: OpenTradeSkill ist
-- in Forever geschützt (sonst "Aktion blockiert"). Seit 0.9.14 ruft GuildSentinel es selbst nicht mehr auf.
function P:OpenModern(name)
	if InCombatLockdown and InCombatLockdown() then return false end
	if not (Game.MODERN_PROFESSIONS and C_TradeSkillUI and C_TradeSkillUI.OpenTradeSkill and GetProfessions and GetProfessionInfo) then return false end
	if TradeWindowShown() then return true end
	local want = (name == SpellName(2656)) and SpellName(self.MINING) or name
	local slots = { GetProfessions() }
	for i = 1, 6 do
		local idx = slots[i]
		if idx then
			local pname, _, _, _, _, _, skillLine = GetProfessionInfo(idx)
			if pname and pname == want and skillLine then
				pcall(ns.Act, "OpenTradeSkill", C_TradeSkillUI.OpenTradeSkill, skillLine)
				return true
			end
		end
	end
	return false
end

-- welchen Beruf der Knopf als Nächstes öffnet (nil = alle durch)
function P:NextToOpen()
	self.scanned = self.scanned or {}
	for _, name in ipairs(self:Openable()) do
		if not self.scanned[name] then return name end
	end
	return nil
end

function P:ReadNext()
	ns:Print(L["Öffne jedes Berufsfenster einmal (oder nutze den Knopf auf der Seite Berufe) – GuildSentinel liest es automatisch."])
	if ns.UI then ns.UI:Open("prof") end
end

------------------------------------------------------------
-- An die Gilde
------------------------------------------------------------
function P:ScheduleSend()
	if self.sendPending then return end
	self.sendPending = true
	C_Timer.After(4, function()
		self.sendPending = false
		self:SendMine()
	end)
end

function P:SendMine(channel, target)
	if ns.RMI:Active() then return end      -- RaidMaster verschickt die Berufe schon
	local me = Store()[ns.Me()]
	if not me or not ns.InGuild() then return end
	ns.Comm:Send("PROF", { n = ns.Me(), c = me.c, t = me.t, p = me.p }, channel or "GUILD", target)
end

-- d.n erlaubt es, beim Abgleich auch die Daten anderer weiterzugeben
function P:Receive(sender, d)
	if type(d.p) ~= "table" then return end
	local who = (type(d.n) == "string" and d.n ~= "") and d.n or sender
	if ns.Same(who, ns.Me()) then return end
	local s = Store()
	local old = s[who]
	local t = tonumber(d.t) or 0
	-- Einträge aus der Gilden-Berufsliste (g) weichen immer den Angaben eines Spielers
	if old and not old.g and (old.t or 0) >= t then return end
	if old and old.g and d.g and (old.t or 0) >= t then return end
	s[who] = { c = d.c, t = t, p = d.p, g = d.g and true or nil }
	ns:Fire("GS_PROF")
end

ns.Comm:Register("PROF", function(sender, d) P:Receive(sender, d) end)

-- eigene Berufe verteilen: einmal am Tag je Gilde (force: sofort, z. B. gerade beigetreten)
function P:SendDaily(force)
	self:UpdateLevels()
	local g = ns.guild
	if g and not ns.RMI:Active() and Store()[ns.Me()] and (force or (g.profSent or 0) < ns.Now() - 86400) then
		g.profSent = ns.Now()
		self:SendMine()
	end
end

-- nach dem Einloggen
ns:Listen("GS_LOGIN", function()
	C_Timer.After(20, function() P:SendDaily() end)
end)

-- neu in einer Gilde (beigetreten, während man online ist): Berufe gleich schicken, nicht erst beim nächsten Login
ns:On("PLAYER_GUILD_UPDATE", function()
	if P.guildWait then return end
	P.guildWait = true
	C_Timer.After(15, function()
		P.guildWait = nil
		local g = ns.guild
		if g and not g.profSent then P:SendDaily(true) end
	end)
end)

------------------------------------------------------------
-- Gilden-Berufsliste des Spiels (GetGuildTradeSkillInfo): Stufen ALLER Mitglieder, auch ohne GuildSentinel.
-- Gibt es nur in manchen Spielversionen; fehlt sie oder ist sie leer, passiert nichts. Rezepte stehen dort nicht –
-- die kommen weiter nur von Spielern mit GuildSentinel (oder RaidMaster), die ihr Berufsfenster geöffnet haben.
-- Solche Einträge haben t = 0 und g = true: echte Daten eines Spielers gehen immer vor.
------------------------------------------------------------
function P:ReadGuildList()
	local A = ns.API
	if not (ns.guild and A.GetNumGuildTradeSkill and A.GetGuildTradeSkillInfo) then return nil end
	local okN, n = pcall(A.GetNumGuildTradeSkill)
	if not okN or type(n) ~= "number" or ns.IsSecret(n) then return nil end
	local s = Store()
	local header, found, people = nil, 0, {}
	for i = 1, n do
		local ok, skillID, _, _, headerName, _, _, _, playerName, _, class, _, _, skill = pcall(A.GetGuildTradeSkillInfo, i)
		if ok then
			if type(headerName) == "string" and headerName ~= "" and not ns.IsSecret(headerName) then
				header = headerName
			elseif header and type(playerName) == "string" and not ns.IsSecret(playerName) then
				local who = ns.Proper(playerName)
				local member = who and (ns.Roster.byName[who] and who or (ns.FindMember(who) or {}).name)
				local r = tonumber(skill)
				if member and r and not ns.IsSecret(skill) then
					local e = s[member]
					if not e then
						e = { t = 0, g = true, c = type(class) == "string" and class or nil, p = {} }
						s[member] = e
					end
					if type(e.p) ~= "table" then e.p = {} end
					local v = e.p[header]
					if type(v) ~= "table" then v = {}; e.p[header] = v end
					-- eigene Angaben des Spielers (mit Rezepten) nicht überschreiben, nur fehlende Stufen ergänzen
					if e.g or not v.r then v.r = r end
					found = found + 1
					people[member] = true
				end
			end
		end
	end
	local np = 0
	for _ in pairs(people) do np = np + 1 end
	if not self.guildListTold and ns.Diag then
		self.guildListTold = true
		ns.Diag("BERUFE", string.format("Gilden-Berufsliste: %d Zeilen, %d Einträge, %d Mitglieder", n, found, np))
	end
	if found > 0 then ns:Fire("GS_PROF") end
	return found, np
end

local function GuildListLater()
	if P.glPending then return end
	P.glPending = true
	C_Timer.After(5, function() P.glPending = false; P:ReadGuildList() end)
end
ns:On("GUILD_TRADESKILL_UPDATE", GuildListLater)
ns:On("GUILD_ROSTER_UPDATE", function()
	-- höchstens alle 5 Minuten (die Gildenliste kommt oft)
	local now = GetTime and GetTime() or 0
	if (P.glLast or -1e9) > now - 300 then return end
	P.glLast = now
	GuildListLater()
end)

------------------------------------------------------------
-- Suchen
------------------------------------------------------------
-- Wer kann das herstellen? -> { { name, prof, recipe, id, rank } }
function P:Find(query)
	query = ns.Trim(query):lower()
	local out = {}
	if query == "" then return out end
	for who, e in pairs(self:All()) do
		if ns.Roster.byName[who] or not next(ns.Roster.byName) then
			for prof, v in pairs(e.p or {}) do
				for k, n in ipairs(v.n or {}) do
					if n:lower():find(query, 1, true) then
						out[#out + 1] = { name = who, prof = prof, recipe = n, id = v.i and v.i[k] or 0, rank = v.r, class = e.c }
					end
				end
			end
		end
	end
	table.sort(out, function(a, b)
		if a.recipe ~= b.recipe then return a.recipe < b.recipe end
		local ao, bo = ns.Roster:OnlineChar(a.name) ~= nil, ns.Roster:OnlineChar(b.name) ~= nil
		if ao ~= bo then return ao end
		return a.name < b.name
	end)
	return out
end

-- Übersicht: Beruf -> { { name, r, m, n = Anzahl Rezepte } } (beste zuerst)
function P:Overview()
	local out = {}
	for who, e in pairs(self:All()) do
		if ns.Roster.byName[who] or not next(ns.Roster.byName) then
			for prof, v in pairs(e.p or {}) do
				out[prof] = out[prof] or {}
				table.insert(out[prof], { name = who, r = v.r or 0, m = v.m or 0, n = #(v.n or {}), class = e.c, t = e.t })
			end
		end
	end
	for _, list in pairs(out) do
		table.sort(list, function(a, b) if a.r == b.r then return a.name < b.name end return a.r > b.r end)
	end
	return out
end

function P:ProfNames()
	local out = {}
	for prof, list in pairs(self:Overview()) do out[#out + 1] = { name = prof, count = #list } end
	table.sort(out, function(a, b) return a.name < b.name end)
	return out
end

-- Link zum Rezept (wenn das Item bekannt ist), sonst [Name]
function P:RecipeLink(id, name)
	if id and id > 0 then
		local _, link = ns.Item(id)
		if link then return link end
	end
	return "[" .. tostring(name) .. "]"
end

function P:AskCraft(r)
	local target = ns.Roster:OnlineChar(r.name) or r.name
	local full = string.format(L["Hallo %s! Könntest du mir %s herstellen? Die Materialien bringe ich mit."], target, "\001")
	local before, after = full:match("^(.-)\001(.*)$")
	ns.OpenWhisper(target, before, self:RecipeLink(r.id, r.recipe), after)
end
