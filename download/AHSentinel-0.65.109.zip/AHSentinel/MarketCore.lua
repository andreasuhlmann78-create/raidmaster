if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - MarketCore.lua (anweisung-markt-reiter, Teil F Stufe 1 "Vertrauen": MA2, MA1, MA3, Ü1–Ü3)
--
-- MA2 Empfehlungs-Protokoll: jede gezeigte Kauf-Empfehlung (Weg, Item, Preis, Vorhersage, Zeit) wird gespeichert und
--     nach Ablauf (24 Std.) mit dem Scan nachgeprüft: Treffer = Preis danach >= Kaufpreis (Kauf war nicht zu teuer),
--     Fehler = |Preis danach - Vorhersage| / Vorhersage. Je Weg: Fälle, Trefferquote, mittlerer Fehler (letzte 50).
--     Speicher klein: Zähler + letzte 200 offene Fälle. Freigabe (Teil D): >= 20 Fälle und >= 60 % -> frei, darunter
--     gesperrt (Protokoll "WEG GESPERRT"), < 20 Fälle -> "lernt noch".
-- MA1 Verkauf vs. Abbruch an den EIGENEN Auktionen (Wahrheit): verschwindet eine eigene Auktion mit langer Restzeit,
--     rät die Erkennung "verkauft", ausser dasselbe Item mit derselben Menge ist neu da ("neu eingestellt"). Die echte
--     Ursache (Verkauf / eigener Abbruch) kommt aus der Buchhaltung bzw. dem Abbrechen -> Fehlerquote.
-- MA3 Händlerpreis: Tabelle gegen das Spiel (A:GetVendorPrice zählt Abweichungen; Händler-Weg nur mit bestätigtem Preis).
-- Ü1 Testbericht-Abschnitt "MARKT-KERN"; Ü2 Grenzwerte; Ü3 Plausibilität.
-- Neue Tabelle db.core (ändert keine anderen Daten). Testroutine: MK.testDB.
-- ============================================================
AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local MK = {}
A.Core = MK

MK.CHECK_AFTER = 24 * 3600
MK.NOTE_GAP = 6 * 3600
MK.MAX_RECS = 200
MK.LAST = 50
MK.FREE_MIN = 20
MK.FREE_PCT = 0.60
MK.WAYS = { "flip", "snipe", "de", "craft", "vendor" }
MK.LONG = 2 * 3600

local function NewDB() return { v = 1, recs = {}, res = {}, err = {}, ma1 = { n = 0, wrong = 0 }, locked = {} } end
MK.NewDB = NewDB
local function Now() return MK.now or time() end
function MK:Store()
    if self.testDB then return self.testDB end
    if not A.db or A:Simulated() then return nil end
    if A.TestRoutine and A.TestRoutine.running then return nil end
    A.db.core = A.db.core or NewDB()
    local d = A.db.core
    d.recs, d.res, d.err, d.ma1, d.locked = d.recs or {}, d.res or {}, d.err or {}, d.ma1 or { n = 0, wrong = 0 }, d.locked or {}
    return d
end
function MK:Data() if self.testDB then return self.testDB end return A.db and A.db.core end

-- ------------------------------------------------------------
-- MA2
-- ------------------------------------------------------------
MK.notedAt = MK.notedAt or {}
function MK:Note(way, itemID, price, pred)
    local db = self:Store()
    if not (db and way and itemID and price and price > 0 and pred and pred > 0) then return false end
    local now = Now()
    local key = way .. ":" .. itemID
    if self.notedAt[key] and now - self.notedAt[key] < self.NOTE_GAP then return false end
    self.notedAt[key] = now
    db.recs[#db.recs + 1] = string.format("%s;%d;%d;%d;%d", way, itemID, now, math.floor(price), math.floor(pred))
    while #db.recs > self.MAX_RECS do table.remove(db.recs, 1) end
    return true
end
local function PriceBetween(itemID, from, to)
    for _, e in ipairs(A:GetHistory(itemID)) do
        if e.t >= from and e.t <= to and (not A.Usable or A.Usable(e)) and e.p and e.p > 0 then return e.p end
        if e.t > to then break end
    end
end
-- MA2-B: Wert "danach" je Weg. flip/snipe: späterer AH-Preis des Items; de: Netto-Materialwert jetzt (Materialpreise
-- nach 24 Std. × Ausbeute, D:DealValue); vendor: vom Spiel bestätigter Händlerpreis (MA3). nil = noch nicht messbar.
function MK:TruthValue(way, id, t)
    if way == "de" then
        local D = A.Disenchant
        if not (D and D.DealValue) then return nil end
        local ok, v, net, complete = pcall(D.DealValue, D, id)
        if ok and v and net and net > 0 and complete then return net end
        return nil
    elseif way == "vendor" then
        if not (A.vendorChecked and A.vendorChecked[id]) then return nil end
        local ok, vp = pcall(A.GetVendorPrice, A, id)
        if ok and vp and vp > 0 then return vp end
        return nil
    end
    return PriceBetween(id, t + self.CHECK_AFTER - 3600, t + self.CHECK_AFTER + 6 * 3600)
end
function MK:Resolve(now)
    local db = self:Store()
    if not db then return 0 end
    now = now or Now()
    local keep, n = {}, 0
    for _, s in ipairs(db.recs) do
        local way, id, t, price, pred = s:match("^(%a+);(%d+);(%d+);(%d+);(%d+)$")
        id, t, price, pred = tonumber(id), tonumber(t), tonumber(price), tonumber(pred)
        local done = false
        if t and now >= t + self.CHECK_AFTER then
            -- MA2-B: je Weg die passende Wahrheit (markt-strategie 8g, Teil C)
            local q = self:TruthValue(way, id, t)
            if q then
                local hit = (way == "vendor") and q > price or (way ~= "vendor" and q >= price)
                local e = math.min(9.99, math.abs(q - pred) / pred)
                local r = (db.res[way] or "") .. (hit and "1" or "0")
                if #r > self.LAST then r = r:sub(-self.LAST) end
                db.res[way] = r
                local el = db.err[way] or {}
                el[#el + 1] = math.floor(e * 1000 + 0.5)
                while #el > self.LAST do table.remove(el, 1) end
                db.err[way] = el
                n, done = n + 1, true
            elseif now >= t + 2 * self.CHECK_AFTER then done = true end
        end
        if not done then keep[#keep + 1] = s end
    end
    db.recs = keep
    for _, w in ipairs(self.WAYS) do self:WayState(w) end
    return n
end
-- Fälle, Quote, mittlerer Fehler (Anteil)
function MK:Quote(way)
    local db = self:Data()
    local r = db and db.res and db.res[way] or ""
    local hit = 0
    for i = 1, #r do if r:sub(i, i) == "1" then hit = hit + 1 end end
    local el, sum = db and db.err and db.err[way] or {}, 0
    for _, v in ipairs(el) do sum = sum + v end
    return #r, #r > 0 and hit / #r or nil, #el > 0 and sum / #el / 1000 or nil
end
-- Teil D: "frei" / "gesperrt" / "lernt" (n von 20)
function MK:WayState(way)
    local n, q = self:Quote(way)
    if n < self.FREE_MIN then return "lernt", n end
    local db = self:Store() or self:Data()
    if q < self.FREE_PCT then
        if db and not db.locked[way] then
            db.locked[way] = true
            if A.Diag and not self.testDB then pcall(A.Diag.Add, A.Diag, "WEG GESPERRT", string.format("%s %d %%", way, math.floor(q * 100 + 0.5))) end
        end
        return "gesperrt", n
    end
    if db then db.locked[way] = nil end
    return "frei", n
end

-- Empfehlungen aus dem Markt-Reiter und dem Sniper notieren (nur gezeigte, je Item und Weg höchstens 1-mal je 6 Std.)
local VIEW_WAY = { flip = "flip", vendor = "vendor", de = "de", gaps = "flip", crowded = "flip" }
function MK:NoteRows(view, rows)
    local way = VIEW_WAY[view]
    if not way then return 0 end
    local n = 0
    for _, r in ipairs(rows or {}) do
        local buy = r.price or r.buy
        local pred = r.upto and (r.net or r.value or r.sell) or (r.sell or r.sellPrice or r.value or r.vendor)
        if r.itemID and buy and pred and not r.implausible and self:Note(way, r.itemID, buy, pred) then n = n + 1 end
    end
    return n
end

-- ------------------------------------------------------------
-- FG: Freigaben (Teil D) in den Markt-Zeilen anwenden. Vorher sind alle Zeilen gemerkt (NoteRows) - auch die eines
-- gesperrten oder lernenden Wegs, sonst käme ein Weg nie zu seinen 20 Fällen bzw. nie wieder frei.
--  gesperrt -> Zeilen ausblenden, Kopf "Weg <x> gesperrt (Treffer y %)"
--  lernt    -> Zeilen grau "lernt noch (n von 20)", keine Kauf-Empfehlung (kein goldenes Signal)
--  Absatz-Ansichten (Flippen, Lücken, Überfüllt) erst mit MA1-Freigabe, sonst grau "lernt noch (n von 30)"
-- Rückgabe: Zeilen, Kopf-Text oder nil
-- ------------------------------------------------------------
local WAY_LABEL = { flip = "Flippen", vendor = "Händler", de = "Entzaubern" }
local SALES_VIEW = { flip = true, gaps = true, crowded = true }
function MK:ApplyRelease(view, rows)
    local way = VIEW_WAY[view]
    if not way then return rows, nil end
    local st, n = self:WayState(way)
    if st == "gesperrt" then
        local _, q = self:Quote(way)
        return {}, string.format(L["Weg %s gesperrt (Treffer %d %%)"], L[WAY_LABEL[way] or way], math.floor((q or 0) * 100 + 0.5))
    end
    local note, head
    if st == "lernt" then
        note = string.format(L["lernt noch (%d von %d)"], n, self.FREE_MIN)
        head = string.format(L["Weg %s lernt noch (%d von %d Fällen) – Zahlen nur geschätzt"], L[WAY_LABEL[way] or way], n, self.FREE_MIN)
    elseif SALES_VIEW[view] then
        local ok, m = self:SalesReleased()
        if not ok then
            note = string.format(L["lernt noch (%d von %d)"], m, 30)
            head = string.format(L["Absatz lernt noch (%d von %d eigenen Fällen) – Zahlen nur geschätzt"], m, 30)
        end
    end
    if note then
        for _, r in ipairs(rows or {}) do
            r.learning, r.recommend, r.safety = true, false, "niedrig"
            r.coreNote = r.coreNote or note
        end
    end
    return rows, head
end

-- MH1310: Freigaben und Ü3 auch in "Heute tun" (Zeilen aus Comfort:TodayActions, Feld kind)
local TODAY_WAY = { flip = "flip", bid = "flip", de = "de", vendor = "vendor" }
function MK:ApplyTodayRelease(rows)
    local out, grey = {}, {}
    local salesOK, m = self:SalesReleased()
    for _, r in ipairs(rows or {}) do
        local way = TODAY_WAY[r.kind or ""]
        local keep, note = true, nil
        if way then
            local st, n = self:WayState(way)
            if st == "gesperrt" then keep = false
            elseif st == "lernt" then note = string.format(L["lernt noch (%d von %d)"], n, self.FREE_MIN)
            elseif way == "flip" and not salesOK then note = string.format(L["lernt noch (%d von %d)"], m, 30) end
            -- Ü3 in Heute: Gewinn > 300 % -> Daten prüfen, keine Empfehlung
            local buy, unit = r.price, r.unitGold
            if keep and buy and buy > 0 and unit then
                local why = self:Implausible(unit / buy * 100)
                if why then note = L["unplausibel"] .. ": " .. why; r.implausible = why end
            end
        end
        if keep then
            if note then
                r.learning, r.recommend, r.safety, r.coreNote = true, false, "niedrig", note
                grey[#grey + 1] = r
            else out[#out + 1] = r end
        end
    end
    for _, r in ipairs(grey) do out[#out + 1] = r end        -- graue Zeilen (keine Empfehlung) nach unten
    return out
end

-- ------------------------------------------------------------
-- MA1 (eigene Auktionen als Wahrheit)
-- ------------------------------------------------------------
MK.ownPrev, MK.guess, MK.truthWait = MK.ownPrev or {}, MK.guess or {}, MK.truthWait or {}
MK.TRUTH_WAIT = 600            -- MA1-B: Wahrheit, die VOR der Vermutung kommt, 10 Min. aufheben
local function Long(o)
    local tl = o.timeLeft
    if type(tl) ~= "number" then return false end
    if tl <= 4 then return tl >= 3 end              -- Blizzard-Stufen 1..4 (3 = 2–12 Std., 4 = > 12 Std.)
    return tl > MK.LONG                             -- Sekunden
end
function MK:OnOwned(list)
    local now, cur, newSig = Now(), {}, {}
    for _, o in ipairs(list or {}) do
        if o.auctionID and not o.sold then
            cur[o.auctionID] = o
            -- MA1-B (b): "neu eingestellt" nur aus auctionIDs, die vorher NICHT da waren
            if not self.ownPrev[o.auctionID] then
                local sig = tostring(o.itemID) .. ":" .. tostring(o.qty)
                newSig[sig] = (newSig[sig] or 0) + 1
            end
        end
    end
    for aid, o in pairs(self.ownPrev) do
        if not cur[aid] and Long(o) and not self.guess[aid] then
            local sig = tostring(o.itemID) .. ":" .. tostring(o.qty)
            local relist = (newSig[sig] or 0) > 0
            if relist then newSig[sig] = newSig[sig] - 1 end            -- eine neue Auktion erklärt nur EINE verschwundene
            self.guess[aid] = { g = relist and "neu" or "verkauft", t = now }
            -- MA1-B (a): Wahrheit kam schon vorher (Abbruch/Verkauf feuern vor der neuen Liste) -> jetzt werten
            local w = self.truthWait[aid]
            if w then self.truthWait[aid] = nil; self:Truth(aid, w.truth) end
        end
    end
    for aid, w in pairs(self.truthWait) do if now - w.t > self.TRUTH_WAIT then self.truthWait[aid] = nil end end
    self.ownPrev = cur
end
function MK:Truth(aid, truth)
    local g = aid and self.guess[aid]
    local db = self:Store()
    if not db then return false end
    if not g then
        -- MA1-B (a): Vermutung fehlt noch -> Wahrheit aufheben, bis die neue Liste die Vermutung bildet
        if aid then self.truthWait[aid] = { truth = truth, t = Now() } end
        return false
    end
    self.guess[aid] = nil
    local right = (g.g == "verkauft" and truth == "verkauft") or (g.g == "neu" and truth == "abgebrochen")
    db.ma1.n = db.ma1.n + 1
    if not right then db.ma1.wrong = db.ma1.wrong + 1 end
    return right
end
function MK:MA1Rate()
    local db = self:Data()
    local m = db and db.ma1
    if not (m and m.n > 0) then return 0, nil end
    return m.n, m.wrong / m.n
end
-- Absatz-Freigabe (Teil D): >= 30 eigene Fälle und Fehlerquote <= 20 %
function MK:SalesReleased()
    local n, r = self:MA1Rate()
    return n >= 30 and r and r <= 0.20 or false, n
end
A:On("OWN_AUCTION_SOLD", function(o) if o and o.auctionID then pcall(MK.Truth, MK, o.auctionID, "verkauft") end end)
A:On("AUCTION_CANCELLED", function(c) if c and c.auctionID then pcall(MK.Truth, MK, c.auctionID, "abgebrochen") end end)

-- ------------------------------------------------------------
-- RK2-A: EINE Rechnung für "Lohnt bis" (Entzaubern). Alle Stellen (Tooltip, Einkauf-Markierung, Warnschutz, Sniper-Ziele,
-- Markt "Entzaubern", Markt-Kaufgrenze, Sammelkauf, API) rufen diese Funktionen auf.
--   Lohnt bis je Stück = Netto-Wert × min( 1 / (1 + Mindestrendite), 1 − Sicherheitsmarge )
--   Sicherheitsmarge (RK5) = gelernte Marge (Ln:Margin "d"); ohne Lernen: 10 % unter 10 echten Entzauberungen, sonst 0.
--   Die strengere Grenze gewinnt; die Mindestrendite gilt damit immer.
-- ------------------------------------------------------------
function MK:MinRoi()
    local DEB = A.DEBuy
    return (DEB and DEB.MinRoi and DEB:MinRoi()) or 20
end
function MK:SafetyMargin(n)
    local Ln = A.Learn
    if Ln and Ln.On and Ln:On() then
        if self.batchMargin and time() - (self.batchT or 0) < 60 then return self.batchMargin end
        local ok, m = pcall(Ln.Margin, Ln, "d")
        return (ok and type(m) == "number") and m or 0
    end
    local D, DEB = A.Disenchant, A.DEBuy
    if (n or 0) < ((D and D.FEW_DATA) or 10) then return (DEB and DEB.SAFETY) or 0.10 end
    return 0
end
-- für Schleifen über viele Items (Markt "Entzaubern"): Marge einmal rechnen
function MK:BeginBatch()
    local Ln = A.Learn
    self.batchMargin, self.batchT = nil, time()
    if Ln and Ln.On and Ln:On() then
        local ok, m = pcall(Ln.Margin, Ln, "d")
        self.batchMargin = (ok and type(m) == "number") and m or 0
    end
end
function MK:EndBatch() self.batchMargin = nil end
function MK:LimitFromNet(net, n)
    if not (net and net > 0) then return nil end
    local r, m = self:MinRoi() / 100, self:SafetyMargin(n)
    if 1 / (1 + r) <= 1 - m then return math.floor(net / (1 + r)) end     -- Mindestrendite ist strenger (wie bisher gerechnet)
    return math.floor(net * (1 - m))
end
-- je Stück: Lohnt bis, Netto-Wert, sicher (vollständig und frisch), Info { stale, complete, basis, n, v }
function MK:DELimit(itemID, nParts)
    local D = A.Disenchant
    if not (D and D.DealValue and itemID) then return nil end
    local ok, v, net, complete, basis, n = pcall(D.DealValue, D, itemID)
    if not (ok and v and net and net > 0) then return nil end
    local okS, stale = pcall(D.StaleMain, D, itemID)
    stale = (okS and stale) and true or false
    if nParts and nParts > 1 and D.BatchNet then
        local okB, bn = pcall(D.BatchNet, D, itemID, nParts)
        if okB and bn and bn < net then net = bn end
    end
    if net <= 0 then return nil end
    return self:LimitFromNet(net, n), net, (complete and not stale) and true or false,
        { stale = stale, complete = complete and true or false, basis = basis, n = n or 0, v = v }
end
-- Betrag für qty Stück (je Stück × qty), Weg, "sicher"/"unsicher", je Stück, Info
function MK:WorthUpTo(itemID, qty, nParts)
    local per, net, sure, info = self:DELimit(itemID, nParts)
    if not per then return nil end
    qty = math.max(1, math.floor(tonumber(qty) or 1))
    return per * qty, "disenchant", sure and "sicher" or "unsicher", per, info
end
-- Selbsttest/Ü3: alle Stellen liefern für dasselbe Item denselben Betrag? Rückgabe: Liste { itemID, werte = {stelle = betrag} }
function MK:LimitSources(itemID)
    local out = {}
    local per, net, sure, info = self:DELimit(itemID)
    if not per then return out end
    out.kern = per
    local TT, D, DEB, API = A.Tooltip, A.Disenchant, A.DEBuy, A.API or (AHSentinel and AHSentinel.API)
    if TT and TT.DisenchantVerdict then local ok, r = pcall(TT.DisenchantVerdict, TT, itemID); if ok and r and r.limit then out.tooltip = r.limit end end
    if sure and D and D.WorthLimit then local ok, l = pcall(D.WorthLimit, D, itemID); if ok and l then out.einkauf = l end end
    if D and D.DealLimit then local ok, l = pcall(D.DealLimit, D, itemID); if ok and l then out.markt = l end end
    if sure and DEB and DEB.Value then local ok, l = pcall(DEB.Value, DEB, itemID, 1); if ok and l then out.sammelkauf = l end end
    local MV = A.MarketView
    if MV and MV.DELimitFor then local ok, l = pcall(MV.DELimitFor, MV, itemID); if ok and l then out.marktgrenze = l end end
    -- RK2-B: angezeigte Markt-Zeile "Entzaubern" (1 Stück), ihre Detailzeile und das Sniper-Entzauberziel
    if sure and MV and MV.DERowLimit then local l = MV:DERowLimit(itemID); if l then out.marktzeile = l end end
    if sure and MV and MV.DEDetailLimit and info.n ~= nil then
        local okP, pv = pcall(D.PlannedValue, D, itemID, 1)
        if okP and pv then local ok, l = pcall(MV.DEDetailLimit, MV, pv, info.n); if ok and l then out.detail = l end end
    end
    local Sn = A.Sniper
    if sure and Sn and Sn.UpdateDETargets then
        local t = { de = true, kind = "item", itemID = itemID, maxPrice = per + 1 }
        local okS = pcall(Sn.UpdateDETargets, Sn, { t }, true)          -- still: keine Chat-Zeile, kein SNIPER_CHANGED
        if okS then out.sniper = t.maxPrice end
    end
    if not info.stale and API and API.WorthUpTo then local ok, l = pcall(API.WorthUpTo, itemID, 1); if ok and l then out.api = l end end
    return out
end
function MK:LimitMismatch(itemID)
    local src = self:LimitSources(itemID)
    if not src.kern then return nil end
    local bad = {}
    for k, v in pairs(src) do if v ~= src.kern then bad[#bad + 1] = k .. "=" .. tostring(v) end end
    if #bad == 0 then return nil end
    table.sort(bad)
    return "Lohnt bis " .. tostring(src.kern) .. " · abweichend: " .. table.concat(bad, ", ")
end

-- ------------------------------------------------------------
-- Ü3 Plausibilität: Rückgabe nil oder Grund
-- ------------------------------------------------------------
function MK:Implausible(profitPct, salesPerHour, offerQty, productOffers)
    if profitPct and profitPct > 300 then return L["Gewinn > 300 % – Daten prüfen"] end
    if salesPerHour and offerQty and offerQty > 0 and salesPerHour > offerQty * 0.25 then return L["Absatz > 25 % des Angebots je Stunde – unplausibel"] end
    if productOffers and productOffers < 5 then return L["dünner Markt (< 5 Angebote)"] end
    return nil
end
-- Ü3 in den Markt-Zeilen: unplausible Vorschläge markieren (Spalte "Stand") und nicht als Empfehlung nachprüfen
function MK:MarkRows(view, rows)
    if not VIEW_WAY[view] then return 0 end
    local n = 0
    for _, r in ipairs(rows or {}) do
        local buy = r.price or r.buy
        local pred = r.upto and (r.net or r.value or r.sell) or (r.sell or r.sellPrice or r.value or r.vendor)
        if r.itemID and buy and buy > 0 and pred then
            local _, qty = A:GetCurrent(r.itemID)
            local pct = (pred - buy) / buy * 100
            local why = self:Implausible(pct, r.salesPerHour, qty, r.productOffers)     -- Produkt-Angebote nur bei Herstellen
            if why then
                r.implausible = why
                r.state = L["unplausibel"] .. ": " .. why
                r.coreNote, r.recommend = r.state, false
                n = n + 1
            end
        end
    end
    return n
end

-- ------------------------------------------------------------
-- Ü1/Ü2: Testbericht-Abschnitt "MARKT-KERN"
-- ------------------------------------------------------------
function MK:Report()
    local out = { "MARKT-KERN (Ü1):" }
    for _, w in ipairs(self.WAYS) do
        local n, q, e = self:Quote(w)
        local st = self:WayState(w)
        out[#out + 1] = string.format("  Weg %s: Fälle %d · Treffer %s · mittlerer Fehler %s · %s%s", w, n, q and string.format("%d %%", math.floor(q * 100 + 0.5)) or "-",
            e and string.format("%d %%", math.floor(e * 100 + 0.5)) or "-", st, (st == "frei" and q and q < 0.70) and " (unter Ziel 70 %)" or "")
        if st == "gesperrt" then out[#out + 1] = string.format("  Ü2 VERFEHLT: Weg %s Trefferquote unter 60 %%", w) end
        if st == "frei" and e and e > 0.15 then out[#out + 1] = string.format("  Ü2 VERFEHLT: Weg %s mittlerer Fehler über 15 %%", w) end
    end
    local n1, r1 = self:MA1Rate()
    out[#out + 1] = string.format("  MA1 eigene Auktionen geprüft %d · Fehlerquote %s%s", n1, r1 and string.format("%d %%", math.floor(r1 * 100 + 0.5)) or "-",
        (r1 and n1 >= 30 and r1 > 0.20) and " · Ü2 VERFEHLT (> 20 %)" or "")
    out[#out + 1] = string.format("  MA3 Händlerpreise vom Spiel bestätigt %d · abweichend von der Tabelle %d", A.vendorCheckedCount or 0, A.vendorDiffCount or 0)
    out[#out + 1] = "  MA4 Stufenbänder: messe noch (kommt mit dem Rechenkern)"
    local last = A.db and A.db.lastScanTime
    out[#out + 1] = string.format("  letzter Vollscan/Scan: %s", last and date("%d.%m. %H:%M", last) or "-")
    local db = self:Data()
    out[#out + 1] = string.format("  offene Empfehlungen %d", db and #(db.recs or {}) or 0)
    return out
end

-- ------------------------------------------------------------
-- TU5 ECHTE DATEN (nur lesen): Grundregeln (TU4) an den eigenen Daten. Ändert nichts, führt nichts aus.
-- "/ahs testroutine echt" (mit Chat-Ergebnis) und still nach jedem Vollscan (Hintergrund, in Portionen).
-- Verletzungen ins Diagnose-Protokoll "GRUNDREGEL VERLETZT" (Item-ID und Zahlen, keine Namen).
-- ------------------------------------------------------------
MK.REAL_MAX_BAD = 50
local function GoodMoney(v) return type(v) == "number" and v == v and v >= 0 and v < math.huge and v == math.floor(v) end
function MK:RealCheckItem(id, bad)
    local Se, D = A.Seller, A.Disenchant
    local function V(txt)
        bad[#bad + 1] = id .. ": " .. txt
        if A.Diag and not self.testDB then pcall(A.Diag.Add, A.Diag, "GRUNDREGEL VERLETZT", "Item " .. id .. " · " .. txt) end
    end
    local p = A:GetCurrent(id)
    if p ~= nil and not GoodMoney(p) then V("Preis " .. tostring(p)) end
    local mv = A:GetMarketValue(id)
    if mv ~= nil and not GoodMoney(mv) then V("Marktwert " .. tostring(mv)) end
    -- RK2: ein "Lohnt bis"
    if D and D.Prior and D:Prior(id) then
        local okM, m = pcall(self.LimitMismatch, self, id)
        if okM and m then V(m) end
    end
    -- Vorschlag nie unter günstigstem fremdem − Unterbietung (ausser eigenes günstigstes, Ausreisser, dünne Leiter mit
    -- gelerntem Normalpreis, Preis von Hand)
    local pr = Se and Se.prices and Se.prices[id]
    if pr and pr.lowestOther and Se:IsPriceFresh(id) and Se:AutoApplyAllowed(id) then
        local okS, v, why = pcall(Se.SuggestRaw, Se, id)
        if okS then
            if not (GoodMoney(v) and v >= 1) then V("Vorschlag " .. tostring(v))
            else
                local u = Se:Undercut(pr.lowestOther, id)
                local own = pr.lowestOwn and pr.lowestOwn <= pr.lowestOther
                local w = tostring(why)
                local exempt = own or w:find(L["Marktwert – einzelnes teures Angebot (Ausreisser)"], 1, true) or
                    (w:find(L["Normalpreis (gelernt) - Konkurrenz liegt über deinem Maximum"], 1, true) and not Se:LadderFull(pr))
                if not exempt and v < u then V(string.format("Vorschlag %d unter günstigstem %d − Unterbietung (%d)", v, pr.lowestOther, u)) end
            end
        end
    end
end
function MK:RealCheck(verbose)
    if self.realRunning or not (A.db and A.db.marketData) then return false end
    self.realRunning = true
    A:Job("core:realcheck", function()
        local n, bad, i = 0, {}, 0
        local ok, err = A:PCall(function()          -- A:PCall: Pausen innerhalb sind erlaubt (pcall bräche beim yield ab)
            for id in pairs(A.db.marketData) do
                i = i + 1
                if i % 20 == 0 then A:Pause() end
                if #bad >= self.REAL_MAX_BAD then break end
                n = n + 1
                self:RealCheckItem(id, bad)
            end
        end)
        -- Sniper: nie über Budget, nie mehr als die Menge, Max-Preis ganzzahlig
        local Sn = A.Sniper
        local db = A.db and A.db.sniper
        for key, t in pairs((db and db.targets) or {}) do
            if t.maxPrice and not GoodMoney(t.maxPrice) then bad[#bad + 1] = tostring(key) .. ": Max-Preis " .. tostring(t.maxPrice) end
            if (t.spent or 0) > (t.budget or 0) and (t.budget or 0) > 0 then bad[#bad + 1] = string.format("%s: ausgegeben %d über Budget %d", tostring(key), t.spent or 0, t.budget or 0) end
            if (t.bought or 0) > (t.qty or 0) and (t.qty or 0) > 0 then bad[#bad + 1] = string.format("%s: gekauft %d über Menge %d", tostring(key), t.bought or 0, t.qty or 0) end
        end
        self.lastReal = { t = time(), n = n, bad = #bad, first = bad[1], err = (not ok) and tostring(err) or nil }
        self.realRunning = nil
        if verbose then
            A:Print(string.format(L["Echte Daten (TU5): %d Items geprüft, %d Verletzungen%s"], n, #bad, bad[1] and (" – " .. bad[1]) or ""))
        end
    end)
    return true
end
A:On("SCAN_FINISHED", function()
    if (A.TestRoutine and A.TestRoutine.running) or A.lastScanKind ~= "Vollscan" then return end
    pcall(MK.RealCheck, MK, false)
end)

-- Nachprüfen nach jedem Scan (klein, ohne Pause nötig: höchstens 200 Fälle)
A:On("SCAN_FINISHED", function()
    if (A.TestRoutine and A.TestRoutine.running) or not MK:Store() then return end
    pcall(MK.Resolve, MK)
end)
