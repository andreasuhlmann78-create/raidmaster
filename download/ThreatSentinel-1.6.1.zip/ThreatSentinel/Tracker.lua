-- ThreatSentinel - Tracker.lua
-- Ersatzwege für WoW Forever: Was das Spiel im Kampf verbirgt, rechnet das Addon aus den
-- eigenen Zaubern (und denen der Gruppe) selbst mit:
--   * Abklingzeiten der eigenen Zauber (ab dem Wirken + bekannte Dauer, lernt die echte Dauer)
--   * Siegel der Wut (Paladin, Forever) und Rechtschaffener Zorn
--   * Rüstung-zerreissen-Stapel auf dem Ziel (eigene Zerreissen)
--   * Kontrollierte Mobs (Verwandlung, Kopfnuss, Fesseln ... aus den Zaubern der Gruppe)
--   * Spott gewirkt / widerstanden (ohne Kampflog: Prüfung über die Bedrohung kurz danach)

local ADDON, ns = ...
local L = ns.L

local K = {}
ns.Track = K
table.insert(ns.modules, K)

K.sunder = {}   -- Mob-Schlüssel -> { n = Stapel, t = Zeit }
K.cc = {}       -- Mob-Schlüssel -> Ende der Kontrolle
K.ccSince = {}  -- Mob-Schlüssel -> Beginn der Kontrolle
K.ccBreak = {}  -- Mob-Schlüssel -> bricht bei Lebensänderung (nicht bei Verwandlung: das Schaf heilt sich)
local POLY = { [118] = true, [12824] = true, [12825] = true, [12826] = true, [28271] = true, [28272] = true }
local polyNames = {}

local SEAL_DURATION = 30
local SUNDER_DURATION = 30

-- Kontrollzauber der Gruppe mit ihrer Höchstdauer (Sekunden)
local CC_DUR = {
	[118] = 50, [12824] = 50, [12825] = 50, [12826] = 50, [28271] = 50, [28272] = 50,  -- Verwandlung
	[6770] = 45, [2070] = 45, [11297] = 45,                                            -- Kopfnuss
	[9484] = 50, [9485] = 50, [10955] = 50,                                            -- Untote fesseln
	[2637] = 40, [18657] = 40, [18658] = 40,                                           -- Winterschlaf
	[2094] = 10,                                                                       -- Blenden
	[6358] = 15,                                                                       -- Verführung
	[710] = 30, [18647] = 30,                                                          -- Verbannen
	[20066] = 6,                                                                       -- Buße
	[1513] = 20, [14326] = 20, [14327] = 20,                                           -- Wildtier ängstigen
	[19386] = 12, [24132] = 12, [24133] = 12,                                          -- Stich des Flügeldrachen
}
local ccByName = {}

function K:Login()
	for id, d in pairs(CC_DUR) do
		local n = ns.SpellName(id)
		if n then ccByName[n] = math.max(ccByName[n] or 0, d) end
	end
	self.rfName = ns.SpellName(25780)
	for id in pairs(POLY) do
		local n = ns.SpellName(id)
		if n then polyNames[n] = true end
	end
end

------------------------------------------------------------
-- Abfragen
------------------------------------------------------------
function K:IsCC(key)
	return key and (self.cc[key] or 0) > GetTime() or false
end

function K:Sunder(key)
	local s = key and self.sunder[key]
	if not s or GetTime() - s.t > SUNDER_DURATION then return 0 end
	return s.n
end

function K:Forget(key)
	if not key then return end
	self.sunder[key] = nil
	self.cc[key] = nil
	self.ccSince[key] = nil
	self.ccBreak[key] = nil
end

------------------------------------------------------------
-- Eigener Spott
------------------------------------------------------------
local function SafeName(unit)
	local n = UnitName(unit)
	if ns.IsSecret(n) then return "?" end
	return n or "?"
end

function K:OnOwnTaunt(spellName)
	local mode = ns.tauntMode
	-- Richturteil ohne Siegel der Wut ist kein Spott
	if mode == "seal" and not (ns:HasSealOfFury() or GetTime() - (ns.sealSeen or 0) < 1
		or (ns.sealUntil or 0) > GetTime()) then return end

	-- Pet-Spott: nur zählen, wenn die Spott-Taste gedrückt wurde (nicht automatisches Knurren)
	local byKey = GetTime() - (ns.Taunt.lastClick or 0) < 1.5
	if mode == "pet" and not byKey then return end

	local plate
	if mode ~= "friendly" then
		if UnitExists("mouseover") and ns.Safe(UnitCanAttack("player", "mouseover"), false) then
			plate = ns:PlateFor("mouseover")
		end
		plate = plate or ns:PlateFor("target")
	end

	local key, guid
	if plate then
		local k, real = ns:MobKey(plate)
		key = k
		if real then guid = k end
	end
	-- Rechtschaffene Verteidigung trifft einen Mitspieler: keinen Mob als übernommen melden.
	-- Pet-Spott (nur Test) nie an die Gruppe melden.
	if mode ~= "pet" then ns.Sync:OnTaunt(guid) end
	if ns.Guide then ns.Guide:Signal("taunt") end

	if ns.Test:IsTesting() then
		ns.Test:Say(string.format(L.TEST_TAUNT_CAST, spellName, plate and SafeName(plate) or "?"))
	end

	-- Widerstand erkennen, wenn das Kampflog fehlt: 0.5 s später muss der Mob auf mir sein
	if plate and not ns.Alerts:CombatLogWorks() and not (mode == "pet" and not ns.isRetail) then
		C_Timer.After(0.5, function()
			if not UnitExists(plate) or ns:MobKey(plate) ~= key then return end
			if ns.Safe(UnitIsDeadOrGhost(plate), true) then return end
			local ok, isTanking = pcall(UnitDetailedThreatSituation, ns:TankUnit(), plate)
			if not ok or ns.IsSecret(isTanking) or isTanking == nil then return end
			ns:Compat("combatlog", "fallback")
			if isTanking == false then
				ns.Alerts:OnResist(SafeName(plate), guid or key, false, "threat")
			end
		end)
	end
end

------------------------------------------------------------
-- Zauber auswerten
------------------------------------------------------------
local function OnPlayerCast(spellID)
	local name = ns.SpellName(spellID)
	if not name or ns.IsSecret(name) then return end
	local now = GetTime()

	-- Abklingzeit mitrechnen und die echte Dauer lernen, sobald sie lesbar ist
	if ns.spellIdByName[name] then
		local base = ns:BaseCooldown(name)
		if base then ns.cdTrack[name] = now + base end
		C_Timer.After(0.3, function()
			local start, dur, ok = ns.ReadCooldown(name)
			if ok and start and dur and dur > 1.6 then
				ns.cdTrack[name] = start + dur
				ns.db.cdLearned[name] = math.floor(dur + 0.5)
			end
		end)
	end

	-- Rechtschaffener Zorn (Paladin-Tankhaltung)
	if spellID == 25780 or name == K.rfName then ns.rfCast = now end

	-- Spott (zuerst prüfen, solange das Siegel noch zählt)
	if ns.tauntSpell and name == ns.tauntSpell then K:OnOwnTaunt(name) end

	-- Siegel der Wut: gesetzt / durch Richturteil verbraucht
	if ns.sealName and name == ns.sealName then ns.sealUntil = now + SEAL_DURATION end
	if ns.tauntMode == "seal" and name == ns.tauntSpell then ns.sealUntil = 0 end

	-- Rüstung zerreissen auf dem Ziel mitzählen
	if ns.sunderName and name == ns.sunderName then
		local plate = ns:PlateFor("target")
		if plate then
			local key = ns:MobKey(plate)
			local s = K.sunder[key]
			if not s or now - s.t > SUNDER_DURATION then s = { n = 0 } end
			s.n = math.min(5, s.n + 1)
			s.t = now
			K.sunder[key] = s
		end
	end
end

local function OnGroupCast(unit, spellID)
	if ns.IsSecret(spellID) then return end
	local name = ns.SpellName(spellID)
	if not name or ns.IsSecret(name) then return end
	local dur = CC_DUR[spellID] or ccByName[name]
	if not dur then return end
	local plate = ns:PlateFor(unit .. "target")
	if not plate then return end
	local key = ns:MobKey(plate)
	K.cc[key] = GetTime() + dur
	K.ccSince[key] = GetTime()
	K.ccBreak[key] = not (POLY[spellID] or polyNames[name])
end

ns:On("UNIT_SPELLCAST_SUCCEEDED", function(_, unit, _, spellID)
	if not ns.db or not unit or ns.IsSecret(unit) then return end
	if unit == "player" then
		if not ns.IsSecret(spellID) then OnPlayerCast(spellID) end
		OnGroupCast(unit, spellID)
	elseif unit:find("^party%d") or unit:find("^raid%d") or unit == "pet" or unit:find("^partypet%d") or unit:find("^raidpet%d") then
		OnGroupCast(unit, spellID)
		-- Spott des eigenen Pets (Live-Test "Pet ist der Tank")
		if unit == "pet" and ns:PetTankActive() and not ns.IsSecret(spellID) then
			local name = ns.SpellName(spellID)
			if name and name == ns.tauntSpell then
				local base = ns:BaseCooldown(name)
				if base then ns.cdTrack[name] = GetTime() + base end
				K:OnOwnTaunt(name)
			end
		end
	end
end)

-- Schaden am Mob bricht die meisten Kontrolleffekte
ns:On("UNIT_HEALTH", function(_, unit)
	if not unit or ns.IsSecret(unit) or not unit:find("^nameplate") then return end
	local key = ns:MobKey(unit)
	if K.cc[key] and K.ccBreak[key] then
		-- kurz nach dem Wirken zählt der Schaden noch nicht (z. B. letzter Schlag davor)
		if (K.ccSince[key] or 0) > GetTime() - 1 then return end
		K.cc[key] = nil
		K.ccSince[key] = nil
		K.ccBreak[key] = nil
	end
end)

ns:On("PLAYER_REGEN_ENABLED", function()
	local now = GetTime()
	for k, s in pairs(K.sunder) do if now - s.t > SUNDER_DURATION then K.sunder[k] = nil end end
	for k, t in pairs(K.cc) do if t < now then K.cc[k] = nil end end
end)
