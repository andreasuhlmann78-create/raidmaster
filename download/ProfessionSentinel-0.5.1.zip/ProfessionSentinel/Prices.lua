local _, ns = ...
local L = ns.L

-- Prices for the gold ranking.
--   Reagents:  sold by a vendor  -> the vendor price (fixed, from the game data)
--              everything else   -> the auction house value (also for farmed material: what you
--                                   could have sold it for)
--   Product:   the higher of auction house value minus the 5 % AH cut and vendor sell value
--              (× items per craft)
-- AH values come from AHSentinel (GoldSentinel), otherwise TSM, otherwise Auctionator.
-- ns.Items[id] = { name, quality, vendorSell, vendorBuyPerPiece (0 = no vendor), farmable }

local P = {}
ns.Prices = P

-- Auction house cut: 5 % of the sale price is kept by the auction house
P.AH_CUT = 0.05

---------------------------------------------------------------------------
-- Auction house value (copper) and which addon delivered it
---------------------------------------------------------------------------
function P.AH(itemID)
    if ns.Sim and ns.Sim.prices then
        local v = ns.Sim.prices[itemID]
        if v then return v, "Test" end
    end
    local A = _G.AHAnalyzerPro
    if A and A.GetMarketValue then
        local ok, v = pcall(A.GetMarketValue, A, itemID)
        if ok and v and v > 0 then return v, "AHSentinel" end
    end
    if _G.TSM_API and TSM_API.GetCustomPriceValue then
        local ok, v = pcall(TSM_API.GetCustomPriceValue, "dbmarket", "i:" .. itemID)
        if ok and v and v > 0 then return v, "TSM" end
    end
    local AU = _G.Auctionator
    if AU and AU.API and AU.API.v1 and AU.API.v1.GetAuctionPriceByItemID then
        local ok, v = pcall(AU.API.v1.GetAuctionPriceByItemID, "ProfessionSentinel", itemID)
        if ok and v and v > 0 then return v, "Auctionator" end
    end
    return nil
end

function P.SourceName()
    if ns.Sim and ns.Sim.prices then return "Test" end
    if _G.AHAnalyzerPro and _G.AHAnalyzerPro.GetMarketValue then return "AHSentinel" end
    if _G.TSM_API and TSM_API.GetCustomPriceValue then return "TSM" end
    local AU = _G.Auctionator
    if AU and AU.API and AU.API.v1 then return "Auctionator" end
    return nil
end

function P.VendorBuy(itemID)
    local d = ns.Items[itemID]
    return d and d[4] and d[4] > 0 and d[4] or nil
end

function P.VendorSell(itemID)
    local d = ns.Items[itemID]
    local v = d and d[3]
    if (not v or v == 0) and GetItemInfo then
        local sell = select(11, GetItemInfo(itemID))
        if sell and sell > 0 then v = sell end
    end
    return v and v > 0 and v or nil
end

function P.IsFarmable(itemID)
    local d = ns.Items[itemID]
    return d and d[5] == 1 or false
end

---------------------------------------------------------------------------
-- Cost of one reagent: (copper per piece, origin "vendor" | "ah" | "farm", known)
---------------------------------------------------------------------------
function P.ReagentUnit(itemID)
    local vb = P.VendorBuy(itemID)
    if vb then return vb, "vendor", true end
    local ah = P.AH(itemID)
    local origin = P.IsFarmable(itemID) and "farm" or "ah"
    if ah then return ah, origin, true end
    return 0, origin, false
end

-- Full calculation for a recipe. Returns a table:
--   cost, value, net (per craft, copper), known (all prices found), parts = { {id, count, unit, origin, known} },
--   origins = { vendor = true, ah = true, farm = true }, valueSource "ah" | "vendor" | nil
function P.Recipe(r)
    local res = { cost = 0, value = 0, known = true, parts = {}, origins = {} }
    for i = 1, #(r.reagents or {}), 2 do
        local id, n = r.reagents[i], r.reagents[i + 1]
        local unit, origin, known = P.ReagentUnit(id)
        res.parts[#res.parts + 1] = { id = id, count = n, unit = unit, origin = origin, known = known }
        res.origins[origin] = true
        res.cost = res.cost + unit * n
        if not known then res.known = false end
    end
    if r.out then
        local count = ((r.outMin or 1) + (r.outMax or r.outMin or 1)) / 2
        local ah = P.AH(r.out)
        local vs = P.VendorSell(r.out)
        -- The auction house keeps 5 % of every sale: compare what actually lands in the mailbox
        local ahGross = ah and ah * count or nil
        local ahNet = ahGross and ahGross * (1 - P.AH_CUT) or nil
        local vend = vs and vs * count or nil
        if ahNet and (not vend or ahNet >= vend) then
            res.value, res.valueSource = ahNet, "ah"
        elseif vend then
            res.value, res.valueSource = vend, "vendor"
        end
        res.valueAH, res.valueAHNet, res.valueVendor = ahGross, ahNet, vend
        res.ahCut = ahGross and (ahGross - ahNet) or nil
    end
    res.net = res.value - res.cost
    return res
end

---------------------------------------------------------------------------
-- Money text: "+10s 80c", "−2s", "1g 5s"
---------------------------------------------------------------------------
function P.Money(copper, signed)
    if not copper then return "?" end
    local neg = copper < 0
    copper = math.floor(math.abs(copper) + 0.5)
    local g, s, c = math.floor(copper / 10000), math.floor((copper % 10000) / 100), copper % 100
    local parts = {}
    if g > 0 then parts[#parts + 1] = "|cffffd100" .. g .. "g|r" end
    if s > 0 then parts[#parts + 1] = "|cffc7c7cf" .. s .. "s|r" end
    if c > 0 or #parts == 0 then parts[#parts + 1] = "|cffc87533" .. c .. "c|r" end
    local txt = table.concat(parts, " ")
    if signed then txt = (neg and "−" or "+") .. txt elseif neg then txt = "−" .. txt end
    return txt
end

-- Plain version without colour codes (for compact hints)
function P.MoneyPlain(copper, signed)
    if not copper then return "?" end
    local neg = copper < 0
    copper = math.floor(math.abs(copper) + 0.5)
    local g, s, c = math.floor(copper / 10000), math.floor((copper % 10000) / 100), copper % 100
    local parts = {}
    if g > 0 then parts[#parts + 1] = g .. "g" end
    if s > 0 then parts[#parts + 1] = s .. "s" end
    if c > 0 or #parts == 0 then parts[#parts + 1] = c .. "c" end
    local txt = table.concat(parts, " ")
    if signed then txt = (neg and "−" or "+") .. txt elseif neg then txt = "−" .. txt end
    return txt
end

P.ORIGIN_COLOR = { ah = "d9a400", vendor = "9a9aa8", farm = "3aa83a" }
