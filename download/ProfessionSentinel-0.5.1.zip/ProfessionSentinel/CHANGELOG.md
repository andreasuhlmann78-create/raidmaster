# ProfessionSentinel – Changelog

## 0.5.1
- Profit calculation deducts the 5 % auction house cut from the sale price – ranking, making gold and net per point use what you actually receive
- If the vendor pays more after the cut, the vendor value counts
- Tooltip shows AH price, AH cut (5 %) and what you receive from the AH

## 0.5.0
- Gold in the ranking: "Levelling" sorted by gold per skill point, new group "Making gold" sorted by net profit per craft – grey recipes included
- Reagent costs: vendor items at the vendor price, everything else at the AH value (also farmed material); product at the higher of AH value and vendor sell value
- AH values from AHSentinel (otherwise TSM or Auctionator); without an AH addon the ranking stays on reagents per skill point
- Rows show where the reagents come from (AH / vendor / farm) and "+10s 80c/pt"; the tooltip breaks down every reagent with price, cost, sell value and net
- Test mode: "test prices" to try the gold ranking without an AH scan

## 0.4.0
- Levelling ranking: every recipe that gives points at your skill – learned and not learned – sorted by reagents per skill point (reagents ÷ chance of a point)
- New "Ranking" tab with the full list, top 10 on top of the "Recipes" tab; recipes you still have to learn are tagged [learn] with their source
- Star on the best learned recipe in Blizzard's recipe list, hint with place and reagents per point on the profession window (click selects it)
- Recipes far above your skill no longer count as orange: missing learn levels are estimated (WoW Forever from the Era level of the same recipe)
- Classic Era: Season of Discovery recipes removed (1267 real Era recipes)

## 0.3.0
- New "Trainers" tab: every trainer of the open profession by rank – Journeyman (to 150), Expert (to 225), Artisan (to 300), specialisations – with zone, coordinates and faction; your next rank is marked
- Vendors and drop mobs in the recipe tooltip now show zone and coordinates
- Click a trainer for a waypoint; right-click a recipe for a waypoint to the nearest vendor (TomTom if installed, otherwise the game's map pin)
- Zone names in the client's language; new WoW Forever zones (Isle of Zephras, Riverlands) supported
- Test mode: trainer and waypoint checks, "test waypoint" button

## 0.2.0
- Detects the game version from the client and adapts: WoW Forever (own recipes and skill levels – many recipes turn grey sooner) and Classic Era (classic profession and enchanting windows)
- Lifeline: a thin line under every recipe (orange → yellow → green → grey) with a marker at your skill and how many crafts it takes until the next colour – in Blizzard's recipe list and in the "All recipes" panel
- Tooltip shows crafts until yellow, green and grey
- Test mode (/ps test): diagnostics, simulated skill, simulated learned state, panel without profession window, self-test (/ps selftest)
- /ps line toggles the lifeline
- Fixed swapped skill levels on a few client recipes (e.g. Charged Scale of Onyxia)

## 0.1.0
- First release for WoW Forever (Interface 16001)
- "All recipes" panel docked to the profession window, grouped like the client's categories
- Learned recipes greyed out, missing recipes in rarity colour
- Tooltips with skill levels, reagents and recipe sources (trainer, vendor, drop, quest)
- Recipe item tooltips show learned / not learned for all your characters
- 2210 recipes, 934 of them new in WoW Forever
