-- BuffSentinel - Recorder.lua
-- Aufnahme-Modus: protokolliert jeden neuen Buff/Proc auf dir mit Spell-ID.
-- Gedacht für WoW Forever: neue Procs per Mausklick als eigenen Proc-Button übernehmen.

local ADDON, BS = ...

local MAX_RECORDS = 100

local function CopySet(src)
    local t = {}
    for k in pairs(src) do t[k] = true end
    return t
end

function BS:RecordAuras()
    local r = self.gdb and self.gdb.recorder
    if not r or not r.enabled then return end
    local prev = self.recPrev or {}
    local cur = {}
    for name, info in pairs(self.playerAuraInfo) do
        cur[name] = true
        if not prev[name] then
            local rec = r.seen[name]
            if not rec then
                rec = { name = name, id = info.id, icon = info.icon, count = 0 }
                r.seen[name] = rec
                tinsert(r.list, 1, name)
                BS.Print(string.format("Neu aufgenommen: |cffffffff%s|r (ID %s)", name, tostring(info.id or "?")))
                while #r.list > MAX_RECORDS do
                    local old = tremove(r.list)
                    r.seen[old] = nil
                end
            end
            rec.count = rec.count + 1
            rec.last = time()
            if self.optionsFrame and self.optionsFrame:IsShown() and self.currentPage == "rec" then
                self:RefreshOptions()
            end
        end
    end
    self.recPrev = cur
end

function BS:SetRecorder(on)
    self.gdb.recorder.enabled = on and true or false
    -- Buffs, die beim Start schon aktiv sind, nicht als "neu" zählen
    self.recPrev = CopySet(self.playerAuraInfo)
    if on then
        BS.Print("Aufnahme gestartet – neue Buffs/Procs werden protokolliert.")
    else
        BS.Print("Aufnahme gestoppt.")
    end
end

function BS:ClearRecorder()
    wipe(self.gdb.recorder.list)
    wipe(self.gdb.recorder.seen)
    self.recPrev = CopySet(self.playerAuraInfo)
end

function BS:HasCustom(auraName)
    for _, c in ipairs(self.db.custom) do
        if c.aura == auraName then return true end
    end
    return false
end

function BS:AddCustomFromRecord(name)
    local rec = self.gdb.recorder.seen[name]
    if not rec or self:HasCustom(name) then return end
    tinsert(self.db.custom, { aura = name, auraId = rec.id, spell = nil })
    BS.Print("Eigener Proc hinzugefügt: " .. name .. " – optional einen Zauber für den Klick eintragen.")
    self:SettingsChanged()
end

function BS:RemoveCustom(index)
    local c = self.db.custom[index]
    if not c then return end
    tremove(self.db.custom, index)
    for _, store in pairs(self.db.specs) do store["custom:" .. c.aura] = nil end
    self:SettingsChanged()
end

function BS:SetCustomSpell(index, spell)
    local c = self.db.custom[index]
    if not c then return end
    spell = spell and strtrim(spell) or ""
    c.spell = (spell ~= "") and spell or nil
    self:SettingsChanged()
end
