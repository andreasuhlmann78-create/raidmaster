-- BuffSentinel - Data/DeathKnight.lua  (ab Wrath; Feldbeschreibung siehe Data/Warrior.lua)

local ADDON, BS = ...
BS.ClassData = BS.ClassData or {}

BS.ClassData.DEATHKNIGHT = {
    specNames       = { "Blut", "Frost", "Unheilig" },
    specNamesModern = { "Blut", "Frost", "Unheilig" },
    icon = "Interface\\Icons\\Spell_Deathknight_ClassIcon",
    entries = {
        ----------------------------------------------------------------
        -- Classic-Familie (Wrath, Titan, Cata)
        ----------------------------------------------------------------
        { key = "horn",       kind = "buff", spell = 57330, min = 3, mode = "combat" },
        { key = "boneshield", kind = "buff", spell = 49222, min = 3, max = 3, specs = { 3 }, mode = "combat" },
        { key = "boneshieldc",kind = "buff", spell = 49222, min = 4, specs = { 1 }, mode = "combat" },

        -- Procs
        { key = "runestrike", kind = "proc", spell = 56815, min = 3, trigger = "avoid", window = 5, reactive = true, specs = { 1 } },
        { key = "rime",       kind = "proc", spell = 49184, procAuras = { 59052 }, min = 3, specs = { 2 },
          talents = { "Rime", "Raureif" }, alert = "HEULENDE BÖE!" },
        { key = "killmachine",kind = "proc", spell = 49143, procAuras = { 51124 }, min = 3, specs = { 2 },
          talents = { "Killing Machine", "Tötungsmaschine" }, alert = "FROSTSTOSS!" },
        { key = "crimson",    kind = "proc", spell = 48721, procAuras = { 81141 }, min = 4, specs = { 1 },
          talents = { "Crimson Scourge", "Purpurrote Geissel" }, alert = "BLUTSIEDEN!" },
        { key = "suddendoom", kind = "proc", spell = 47541, procAuras = { 81340 }, min = 4, specs = { 3 },
          talents = { "Sudden Doom", "Plötzliches Verhängnis" }, alert = "TODESMANTEL!" },

        -- Cooldowns
        { key = "drw",        kind = "cd", spell = 49028, min = 3, specs = { 1 } },
        { key = "vampblood",  kind = "cd", spell = 55233, min = 3, specs = { 1 } },
        { key = "runetap",    kind = "cd", spell = 48982, min = 3, specs = { 1 } },
        { key = "pillar",     kind = "cd", spell = 51271, min = 3, specs = { 2 } },
        { key = "hungering",  kind = "cd", spell = 49203, min = 3, specs = { 2 } },
        { key = "gargoyle",   kind = "cd", spell = 49206, min = 3, specs = { 3 } },
        { key = "darktrans",  kind = "cd", spell = 63560, min = 4, specs = { 3 } },
        { key = "mindfreeze", kind = "cd", spell = 47528, min = 3 },
        { key = "ams",        kind = "cd", spell = 48707, min = 3 },
        { key = "ibf",        kind = "cd", spell = 48792, min = 3 },
        { key = "grip",       kind = "cd", spell = 49576, min = 3 },
        { key = "erw",        kind = "cd", spell = 47568, min = 3 },
        { key = "army",       kind = "cd", spell = 42650, min = 3 },
        { key = "outbreak",   kind = "cd", spell = 77575, min = 4 },

        ----------------------------------------------------------------
        -- Moderne Familie (MoP)
        ----------------------------------------------------------------
        { key = "m_horn",      kind = "buff", v = "modern", max = 5, spell = 57330, mode = "combat" },
        { key = "m_boneshield",kind = "buff", v = "modern", max = 5, spell = 49222, specs = { 1 }, mode = "combat" },

        { key = "m_killmach",  kind = "proc", v = "modern", spell = 49020, procAuras = { 51124 }, specs = { 2 } },
        { key = "m_rime",      kind = "proc", v = "modern", spell = 49184, procAuras = { 59052 }, specs = { 2 } },
        { key = "m_crimson",   kind = "proc", v = "modern", spell = 48721, procAuras = { 81141 }, specs = { 1 } },
        { key = "m_suddendoom",kind = "proc", v = "modern", spell = 47541, procAuras = { 81340 }, specs = { 3 } },
        { key = "m_shadowinf", kind = "proc", v = "modern", spell = 63560, procAuras = { 91342 }, minStacks = 5, specs = { 3 },
          label = "Schatteninfusion", alert = "DUNKLE VERWANDLUNG!" },
        { key = "m_soulreaper",kind = "proc", v = "modern", spell = 114866, targetBelow = 35,
          spellBySpec = { [1] = 114866, [2] = 130735, [3] = 130736 } },

        { key = "m_drw",       kind = "cd", v = "modern", spell = 49028, specs = { 1 } },
        { key = "m_vampblood", kind = "cd", v = "modern", spell = 55233, specs = { 1 } },
        { key = "m_runetap",   kind = "cd", v = "modern", spell = 48982, specs = { 1 } },
        { key = "m_pillar",    kind = "cd", v = "modern", spell = 51271, specs = { 2 } },
        { key = "m_gargoyle",  kind = "cd", v = "modern", spell = 49206, specs = { 3 } },
        { key = "m_darktrans", kind = "cd", v = "modern", spell = 63560, specs = { 3 } },
        { key = "m_mindfreeze",kind = "cd", v = "modern", spell = 47528 },
        { key = "m_ams",       kind = "cd", v = "modern", spell = 48707 },
        { key = "m_ibf",       kind = "cd", v = "modern", spell = 48792 },
        { key = "m_grip",      kind = "cd", v = "modern", spell = 49576 },
        { key = "m_erw",       kind = "cd", v = "modern", spell = 47568 },
        { key = "m_army",      kind = "cd", v = "modern", spell = 42650 },
        { key = "m_outbreak",  kind = "cd", v = "modern", spell = 77575 },
        { key = "m_strangul",  kind = "cd", v = "modern", spell = 47476 },
        { key = "m_remorse",   kind = "cd", v = "modern", spell = 108200 },
        { key = "m_gorefiend", kind = "cd", v = "modern", spell = 108199 },
        { key = "m_blight",    kind = "cd", v = "modern", spell = 115989 },
    },
}
