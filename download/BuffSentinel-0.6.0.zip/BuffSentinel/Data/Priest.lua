-- BuffSentinel - Data/Priest.lua  (Feldbeschreibung siehe Data/Warrior.lua)

local ADDON, BS = ...
BS.ClassData = BS.ClassData or {}

BS.ClassData.PRIEST = {
    specNames       = { "Disziplin", "Heilig", "Schatten" },
    specNamesModern = { "Disziplin", "Heilig", "Schatten" },
    icon = "Interface\\Icons\\Spell_Holy_WordFortitude",
    entries = {
        ----------------------------------------------------------------
        -- Classic-Familie
        ----------------------------------------------------------------
        { key = "fortitude",    kind = "buff", spell = 1243,  group = true, groupSpell = 21562 },
        { key = "divinespirit", kind = "buff", spell = 14752, group = true, groupSpell = 27681, manaOnly = true,
          max = 3, noForever = true },   -- in Forever entfernt, ab Cata weg
        { key = "shadowprot",   kind = "buff", spell = 976,   group = true, groupSpell = 27683, optional = true },
        { key = "innerfire",    kind = "buff", spell = 588 },
        { key = "shadowform",   kind = "buff", spell = 15473, specs = { 3 }, mode = "combat" },
        { key = "vampembrace",  kind = "buff", spell = 15286, min = 3, specs = { 3 }, mode = "combat" },

        -- Procs
        { key = "surgelight",   kind = "proc", spell = 2061, procAuras = { 33151 }, min = 2, specs = { 2 },
          talents = { "Surge of Light", "Woge des Lichts" }, alert = "BLITZHEILUNG!" },
        { key = "serendipity",  kind = "proc", spell = 2060, procAuras = { 63735 }, min = 3, specs = { 2 }, minStacks = 3,
          talents = { "Serendipity", "Glücksfall" }, alert = "GROSSE HEILUNG!" },
        { key = "swdeath",      kind = "proc", spell = 32379, min = 2, targetBelow = 25, specs = { 3 } },

        -- Cooldowns Disziplin
        { key = "innerfocus",   kind = "cd", spell = 14751, specs = { 1 } },
        { key = "powerinfusion",kind = "cd", spell = 10060, specs = { 1 } },
        { key = "painsupp",     kind = "cd", spell = 33206, min = 2, specs = { 1 } },
        { key = "penance",      kind = "cd", spell = 47540, min = 3, specs = { 1 } },
        { key = "penance_f",    kind = "cd", spell = "Penance", specs = { 1 }, forever = true },

        -- Cooldowns Heilig
        { key = "mending",      kind = "cd", spell = 33076, min = 2, specs = { 1, 2 } },
        { key = "mending_f",    kind = "cd", spell = "Prayer of Mending", specs = { 2 }, forever = true },
        { key = "guardspirit",  kind = "cd", spell = 47788, min = 3, specs = { 2 } },
        { key = "coh",          kind = "cd", spell = 34861, min = 2, specs = { 2 } },
        { key = "divhymn",      kind = "cd", spell = 64843, min = 3, specs = { 2 } },

        -- Cooldowns Schatten
        { key = "mindblast",    kind = "cd", spell = 8092,  specs = { 3 } },
        { key = "silence",      kind = "cd", spell = 15487, specs = { 3 } },
        { key = "dispersion",   kind = "cd", spell = 47585, min = 3, specs = { 3 } },

        -- Cooldowns alle
        { key = "shadowfiend",  kind = "cd", spell = 34433, min = 2 },
        { key = "psychicscream",kind = "cd", spell = 8122 },
        { key = "fade",         kind = "cd", spell = 586 },
        { key = "fearward",     kind = "cd", spell = 6346, optional = true },

        ----------------------------------------------------------------
        -- Moderne Familie (MoP, Retail)
        ----------------------------------------------------------------
        { key = "m_fortitude",  kind = "buff", v = "modern", spell = 21562, group = true, retail = true },
        { key = "m_innerfire",  kind = "buff", v = "modern", max = 5, spell = { 588, 73413 }, auras = { 588, 73413 },
          label = "Inneres Feuer / Innerer Wille", alert = "INNERES FEUER!" },
        { key = "m_shadowform", kind = "buff", v = "modern", max = 5, spell = 15473, specs = { 3 }, mode = "combat" },
        { key = "r_shadowform", kind = "buff", v = "modern", min = 12, retail = true, retailOnly = true,
          spell = 232698, specs = { 3 } },

        { key = "m_surgelight", kind = "proc", v = "modern", spell = 2061, procAuras = { 114255 } },
        { key = "m_surgedark",  kind = "proc", v = "modern", spell = 73510, procAuras = { 87160 }, specs = { 3 } },
        { key = "m_divinsight", kind = "proc", v = "modern", spell = 8092, procAuras = { 124430 }, specs = { 3 } },
        { key = "m_serendip",   kind = "proc", v = "modern", spell = 2060, procAuras = { 63735 }, specs = { 2 }, minStacks = 2 },
        { key = "m_swdeath",    kind = "proc", v = "modern", spell = 32379, targetBelow = 20, specs = { 3 } },

        { key = "m_penance",    kind = "cd", v = "modern", spell = 47540, specs = { 1 } },
        { key = "m_painsupp",   kind = "cd", v = "modern", spell = 33206, specs = { 1 } },
        { key = "m_spiritshell",kind = "cd", v = "modern", spell = 109964, specs = { 1 } },
        { key = "m_guardspirit",kind = "cd", v = "modern", spell = 47788, specs = { 2 } },
        { key = "m_chastise",   kind = "cd", v = "modern", spell = 88625, specs = { 2 } },
        { key = "m_coh",        kind = "cd", v = "modern", spell = 34861, specs = { 2 } },
        { key = "m_divhymn",    kind = "cd", v = "modern", spell = 64843, specs = { 2 } },
        { key = "m_mending",    kind = "cd", v = "modern", spell = 33076, specs = { 1, 2 } },
        { key = "m_mindblast",  kind = "cd", v = "modern", spell = 8092,  specs = { 3 } },
        { key = "m_dispersion", kind = "cd", v = "modern", spell = 47585, specs = { 3 } },
        { key = "m_silence",    kind = "cd", v = "modern", spell = 15487, specs = { 3 } },
        { key = "m_pinfusion",  kind = "cd", v = "modern", spell = 10060 },
        { key = "m_shadowfiend",kind = "cd", v = "modern", spell = 34433 },
        { key = "m_mindbender", kind = "cd", v = "modern", spell = 123040 },
        { key = "m_halo",       kind = "cd", v = "modern", spell = 120517 },
        { key = "m_cascade",    kind = "cd", v = "modern", spell = 121135 },
        { key = "m_divstar",    kind = "cd", v = "modern", spell = 110744 },
        { key = "m_scream",     kind = "cd", v = "modern", spell = 8122 },
        { key = "m_fade",       kind = "cd", v = "modern", spell = 586 },
    },
}
