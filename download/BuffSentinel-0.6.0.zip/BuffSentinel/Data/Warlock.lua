-- BuffSentinel - Data/Warlock.lua  (Feldbeschreibung siehe Data/Warrior.lua)

local ADDON, BS = ...
BS.ClassData = BS.ClassData or {}

BS.ClassData.WARLOCK = {
    specNames       = { "Gebrechen", "Dämonologie", "Zerstörung" },
    specNamesModern = { "Gebrechen", "Dämonologie", "Zerstörung" },
    icon = "Interface\\Icons\\Spell_Shadow_RagingScream",
    entries = {
        ----------------------------------------------------------------
        -- Classic-Familie
        ----------------------------------------------------------------
        -- Rüstung: Teufelsrüstung (ab TBC) > Dämonenrüstung > Dämonenhaut; jede zählt
        { key = "armor",      kind = "buff", spell = { 28176, 706, 687 }, auras = { 28176, 706, 687 },
          label = "Rüstung", alert = "RÜSTUNG!" },
        { key = "darkintent", kind = "buff", spell = 80398, min = 4, optional = true },

        -- Procs
        { key = "nightfall",  kind = "proc", spell = 686, procAuras = { 17941 }, specs = { 1 },
          talents = { "Nightfall", "Einbruch der Nacht" }, alert = "SCHATTENBLITZ!" },
        { key = "backlash",   kind = "proc", spell = 686, procAuras = { 34936 }, min = 2, specs = { 3 },
          talents = { "Backlash", "Heimzahlen" }, alert = "SCHATTENBLITZ!" },
        { key = "decimation", kind = "proc", spell = 6353, procAuras = { 63167 }, min = 3, specs = { 2 },
          talents = { "Decimation", "Dezimierung" }, alert = "SEELENFEUER!" },
        { key = "moltencore", kind = "proc", spell = 29722, procAuras = { 71165 }, min = 3, specs = { 2 },
          talents = { "Molten Core", "Geschmolzener Kern" }, alert = "VERBRENNEN!" },
        { key = "shadowburn", kind = "proc", spell = 17877, targetBelow = 20, specs = { 3 }, min = 4 },

        -- Cooldowns
        { key = "deathcoil",  kind = "cd", spell = 6789 },
        { key = "howl",       kind = "cd", spell = 5484 },
        { key = "amplify",    kind = "cd", spell = 18288, specs = { 1 }, max = 2 },
        { key = "haunt",      kind = "cd", spell = 48181, min = 3, specs = { 1 } },
        { key = "feldom",     kind = "cd", spell = 18708, specs = { 2 } },
        { key = "meta",       kind = "cd", spell = 47241, min = 3, specs = { 2 } },
        { key = "conflag",    kind = "cd", spell = 17962, specs = { 3 } },
        { key = "shadowburnc",kind = "cd", spell = 17877, specs = { 3 }, max = 3 },
        { key = "shadowfury", kind = "cd", spell = 30283, min = 2, specs = { 3 } },
        { key = "chaosbolt",  kind = "cd", spell = 50796, min = 3, specs = { 3 } },
        { key = "soulshatter",kind = "cd", spell = 29858, min = 2 },
        { key = "drainhope_f",kind = "cd", spell = "Drain Hope", forever = true, optional = true },

        ----------------------------------------------------------------
        -- Moderne Familie (MoP)
        ----------------------------------------------------------------
        { key = "m_darkintent",kind = "buff", v = "modern", max = 5, spell = 109773, group = true },

        { key = "m_backdraft", kind = "proc", v = "modern", spell = 29722, procAuras = { 117828 }, specs = { 3 } },
        { key = "m_moltencore",kind = "proc", v = "modern", spell = 6353, procAuras = { 122355 }, specs = { 2 } },
        { key = "m_shadowburn",kind = "proc", v = "modern", spell = 17877, targetBelow = 20, specs = { 3 } },
        { key = "m_drainsoul", kind = "proc", v = "modern", spell = 1120, targetBelow = 20, specs = { 1 } },

        { key = "m_dsmisery",  kind = "cd", v = "modern", spell = 113860, specs = { 1 } },
        { key = "m_dsknow",    kind = "cd", v = "modern", spell = 113861, specs = { 2 } },
        { key = "m_dsinstab",  kind = "cd", v = "modern", spell = 113858, specs = { 3 } },
        { key = "m_haunt",     kind = "cd", v = "modern", spell = 48181, specs = { 1 } },
        { key = "m_meta",      kind = "cd", v = "modern", spell = 103958, specs = { 2 } },
        { key = "m_hog",       kind = "cd", v = "modern", spell = 105174, specs = { 2 } },
        { key = "m_conflag",   kind = "cd", v = "modern", spell = 17962, specs = { 3 } },
        { key = "m_chaosbolt", kind = "cd", v = "modern", spell = 116858, specs = { 3 } },
        { key = "m_havoc",     kind = "cd", v = "modern", spell = 80240, specs = { 3 } },
        { key = "m_doomguard", kind = "cd", v = "modern", spell = 18540 },
        { key = "m_unending",  kind = "cd", v = "modern", spell = 104773 },
        { key = "m_coil",      kind = "cd", v = "modern", spell = 6789 },
        { key = "m_shadowfury",kind = "cd", v = "modern", spell = 30283 },
        { key = "m_howl",      kind = "cd", v = "modern", spell = 5484 },
    },
}
