-- BuffSentinel - Data/DemonHunter.lua  (nur Retail)
-- Dämonenjäger haben keine Gruppen- oder Dauerbuffs, und Procs/Cooldowns sind in Retail im Kampf
-- für Addons gesperrt. Der Eintrag sorgt dafür, dass BuffSentinel die Klasse kennt und eigene
-- Einträge aus künftigen Versionen ergänzt werden können.

local ADDON, BS = ...
BS.ClassData = BS.ClassData or {}

BS.ClassData.DEMONHUNTER = {
    specNames       = { "Verwüstung", "Rachsucht", "Verschlinger" },
    specNamesModern = { "Verwüstung", "Rachsucht", "Verschlinger" },
    icon = "Interface\\Icons\\ClassIcon_DemonHunter",
    entries = {},
}
