-- BuffSentinel - Data/Monk.lua  (ab MoP; Feldbeschreibung siehe Data/Warrior.lua)

local ADDON, BS = ...
BS.ClassData = BS.ClassData or {}

BS.ClassData.MONK = {
    specNames       = { "Braumeister", "Nebelwirker", "Windläufer" },
    specNamesModern = { "Braumeister", "Nebelwirker", "Windläufer" },
    icon = "Interface\\Icons\\ClassIcon_Monk",
    entries = {
        -- Buffs (MoP)
        { key = "m_emperor",   kind = "buff", v = "modern", max = 5, spell = 115921, group = true },
        { key = "m_whitetiger",kind = "buff", v = "modern", max = 5, spell = 116781, group = true, specs = { 3 } },

        -- Procs
        { key = "m_cbkick",    kind = "proc", v = "modern", spell = 100784, procAuras = { 116768 }, specs = { 3 },
          label = "Kombobrecher: Blackout-Tritt", alert = "BLACKOUT-TRITT!" },
        { key = "m_cbpalm",    kind = "proc", v = "modern", spell = 100787, procAuras = { 118864 }, specs = { 3 },
          label = "Kombobrecher: Tigerklaue", alert = "TIGERKLAUE!" },
        { key = "m_vitalmists",kind = "proc", v = "modern", spell = 116694, procAuras = { 118674 }, minStacks = 5, specs = { 2 },
          label = "Vitalisierende Nebel", alert = "WOGENDER NEBEL!" },
        { key = "m_touchdeath",kind = "proc", v = "modern", spell = 115080, reactive = true },

        -- Cooldowns
        { key = "m_kegsmash",  kind = "cd", v = "modern", spell = 121253, specs = { 1 } },
        { key = "m_guard",     kind = "cd", v = "modern", spell = 115295, specs = { 1 } },
        { key = "m_oxstatue",  kind = "cd", v = "modern", spell = 115315, specs = { 1 } },
        { key = "m_rsk",       kind = "cd", v = "modern", spell = 107428, specs = { 2, 3 } },
        { key = "m_thunder",   kind = "cd", v = "modern", spell = 116680, specs = { 2 } },
        { key = "m_cocoon",    kind = "cd", v = "modern", spell = 116849, specs = { 2 } },
        { key = "m_revival",   kind = "cd", v = "modern", spell = 115310, specs = { 2 } },
        { key = "m_manatea",   kind = "cd", v = "modern", spell = 115294, specs = { 2 } },
        { key = "m_fof",       kind = "cd", v = "modern", spell = 113656, specs = { 3 } },
        { key = "m_energize",  kind = "cd", v = "modern", spell = 115288, specs = { 3 } },
        { key = "m_tigereye",  kind = "cd", v = "modern", spell = 116740, specs = { 3 } },
        { key = "m_karma",     kind = "cd", v = "modern", spell = 122470, specs = { 3 } },
        { key = "m_fortify",   kind = "cd", v = "modern", spell = 115203 },
        { key = "m_xuen",      kind = "cd", v = "modern", spell = 123904 },
        { key = "m_chiwave",   kind = "cd", v = "modern", spell = 115098 },
        { key = "m_chiburst",  kind = "cd", v = "modern", spell = 123986 },
        { key = "m_legsweep",  kind = "cd", v = "modern", spell = 119381 },
        { key = "m_spear",     kind = "cd", v = "modern", spell = 116705 },
        { key = "m_paralysis", kind = "cd", v = "modern", spell = 115078 },
        { key = "m_dampen",    kind = "cd", v = "modern", spell = 122278 },
        { key = "m_diffuse",   kind = "cd", v = "modern", spell = 122783 },
    },
}
