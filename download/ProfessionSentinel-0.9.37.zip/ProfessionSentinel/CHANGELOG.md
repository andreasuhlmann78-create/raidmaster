# ProfessionSentinel – Changelog

## 0.9.37
UI rework, part B – the rest (review of 0.9.36):
- **Blizzard's profession window (U6):** per recipe row only ONE short sign at the right edge – the crafts to the next colour ("19×") in that colour, in the font of the row; grey: nothing. No grey text and no bar under the name any more. The sign is drawn only where it touches neither the name nor the count ("[38]"); otherwise nothing. Era/TBC (TradeSkillFrame, CraftFrame) and the modern profession window. At the bottom a short line "Best: <recipe>" (bright, cut with "…" only at the width of the window)
- **Details in the tab "Recipes" (U2):** a click on a row shows below the list: materials with origin, bag count and price, net sale, profit per craft with the best way, sales, where the recipe comes from, buttons "Craft" and "Shopping list" (vendor reagents at an open vendor, AH reagents into AHSentinel's sniper). The same numbers as tooltip and gold ranking
- **One number per row (U3):** tab "Recipes" colour dot, name, status (learnable / missing) and the profit with "sell" / "DE"; tab "Skill up" the material per skill point
- **Tab "Skill up" (U4):** on top "Next step: 112 -> 125" with the recipe and the crafts, shortly before it turns yellow (≤ 2 crafts) already the next orange recipe, and where to learn a missing recipe (click: waypoint); the plan without prices prefers orange as well
- **No long chat output (U8):** the recipe alarm writes at most one short line per session; the list is in the tab "Recipes", the number on the tab
- Test cases T239 (T-UI5), T240 (T-UI6 "Best:"), T241 (T-UI9), T242 (area K: sign never over name/count), T243 (T-UI8), T244 (next step / next orange); T67 adjusted

## 0.9.36
UI rework, part B – tooltip variant A (decision of 9 Nov. 17:55, like AHSentinel's tooltip):
- **Without Shift three blocks:** head (name, "place · learned/learnable/missing", skill colour as a dot with the crafts to the next colour, e.g. "green ≈13×"); verdict ("Crafting pays" / "does not pay" / "unsure" with the ONE profit per craft – the same function as the gold ranking and the panel – then Sell / Disenchant with the better way first, Vendor, Skill up as material per point); materials (sum, one line per reagent with origin "AH" / "Vendor" / "from Linen Cloth", price per craft and bag count "2/1")
- **With Shift:** the whole calculation (cost, sale, 5 % share, deposit risk, vendor, disenchanting), skill levels and the chance at the current colour, sources, guild, price source; pressing or releasing Shift redraws the tooltip
- **Gone from the tooltip:** ranking places and explanation texts (they are in the panel) – the Woolen Cape no longer shows three different numbers for the same thing
- **Pattern tooltips:** "Pattern · missing / learnable from …" and the verdict of the crafted item; favour cost, guild and characters with Shift
- Test cases **T236–T238** (T-TT1 without Shift, T-TT2 with Shift, T-TT3 the same profit as the ranking), T75 (T-TT4 pattern), T122/T153/T168 adjusted (sources and favour cost now with Shift)

## 0.9.35
Follow-up of the review of 0.9.33 (9 Nov., 17:30):
- **Vendor price is no AH price:** when AHSentinel.API.Price only knows the vendor's buying price ("vendor"), the next source is asked; the vendor value comes only from VendorSell / VendorBuy (materials were too cheap, profit too high)
- **API.MaterialCost is no longer asked for a reagent** (it is the cost to craft that item): every reagent goes the own cheapest way (AH, vendor, crafted from a known recipe) with the prices of the source – Bolt of Linen Cloth 25c in the AH and 16c crafted -> 16c "from Linen Cloth", 10c in the AH -> AH
- **Disenchanting in the best way only for enchanters who make gold** (also AHSentinel's values and Enchantrix; Retail never) – a tailor gets "sell"
- **Shopping lists buy the materials of a reagent you make yourself:** plan, "Craft today" and the bulk buy put linen cloth on the list, not the bolt; the bolt is shown as "make yourself"
- **"Craft today" by sales:** at most what sells in ~2 days, "hardly sells" and below the minimum profit left out; in the gold ranking below the minimum profit grey; the minimum profit is fetched once per ranking
- **Enchanting service:** your surcharge again (not AHSentinel's minimum profit in the AH)
- Play test S5 compares with AHSentinel's real number (API.NetSale .cut); the tooltip shows "Sale in the AH" only with a real AH price; diagnostic log: highest value per version and last value; area K: the line "Prices: …" not cut off (T235); `tests/run_offline.py --lua51` runs with real Lua 5.1
- Test cases T232–T235, T220/T225/T216 adjusted

## 0.9.34
UI rework, part A – the panel (instruction of the review, 9 Nov. 17:05):
- **Three tabs, one question each:** "Recipes" (what can I make, what exists – also the Merchant's Favor view), "Skill up" (views Plan · Ranking · Trainers), "Gold" (views "Crafting pays" and "Disenchanting" for enchanters). Every old view stays reachable as a view of its tab; the tab remembers its last view
- **Tab "Recipes" grouped by place like in the game:** head, shoulders, chest, waist, legs, hands, feet, cloak, wrists, weapons, shields, jewellery, bags, potions, elixirs, flasks, transmutation, food, cloth and intermediate products, useful items, other – from the product's equip slot or item class (GetItemInfoInstant), never from the recipe name; groups fold open/closed with their numbers, the state is remembered
- **Filters "All · Learned · Learnable · Missing"** with numbers (replace the check box "only missing"); default Learned + Learnable
- **Skill up: orange preferred** – yellow only before orange when it needs less than half the material per point, green likewise against yellow
- **Tab "Gold":** crafting by real profit (best way, amount by sales), what hardly sells or brings no profit in its own closed group, the way to the disenchanting trade and bargains; at the bottom "Prices: …", gold per hour (only from AHSentinel) and "Minimum profit 20 %"
- **`ProfessionSentinel.IsPanelShown()`** for AHSentinel: while the panel is open it hides its profit window
- Test cases **T228–T231** (T-UI2 groups, T-UI3 filters, T-UI4 orange first, T-UI7 IsPanelShown) and T118 (T-UI1 three tabs), T80/T82/T167 adjusted to the tabs
- Part B (profession window marks, short tooltips, details on click, chat hints) follows

## 0.9.33
Values from AHSentinel and other AH addons, GoldSentinel rule book (instruction of the review, 9 Nov., 16:50):
- **One price broker** (new file PriceSource.lua): every value comes from one place, in this order – AHSentinel (`AHSentinel.API` version 1; until it is published its existing functions RealPrice/RealValue/AuctionFee/CutPct/ListingDeposit), then **auxForever** (`AuxForeverAPI.GetLatestPrice`), **Auctionator** (`Auctionator.API.v1`), **Auctioneer** (`Auctioneer:Statistics`, disenchanting values from Enchantrix), TSM (Retail), otherwise own calculation. All names checked in the code of those addons; a missing function leaves the source out and writes "PREISQUELLE <addon>: Funktion nicht gefunden" into the diagnostic log; errors go to the next source. Panel and tooltip show "Prices: AHSentinel" / "auxForever" / … / "own calculation"
- **Fee by the rule book** (measured in the game): 5 % of the sale price when it sells (no 1s minimum any more); the deposit (vendor price × quantity × 5 % per 2 h, Forever minimum measured by AHSentinel, 1s today) comes back on a sale – only the expected loss deposit × (1 − p)/p counts. The share is rounded down: matches all three measured invoices (202 of 4042, 837 of 16744, 313 of 6279). Era/TBC/Retail unchanged
- **Value = cheapest offer of the last scan**, not the median; net sale value with the share and deposit risk off, at least the vendor value – no fee taken twice
- **Cheapest material way:** AH, vendor or crafted from a known recipe (at most 2 levels, no loops) – tooltip "from Linen Cloth"
- **Best way per recipe:** the gold ranking counts the better of selling and disenchanting, marked "sell" / "DE" like AHSentinel
- **Disenchanting value from AHSentinel** (`DisenchantValue`) when available; own value only without it
- **Amount by sales:** "≤N" = what sells in about 2 days (AHSentinel's sales per day); "hardly sells" gets no profit recommendation and goes to the end
- **Minimum profit from AHSentinel** (`MinProfitPct`), otherwise your own; **gold per hour when crafting** shown only when AHSentinel measures it ("Crafting: 1g 20s/h"); subscription to AHSentinel's changes (scan, bookings) – values again, throttled
- Test cases **T220–T227** (T-PS1 to T-PS9; T-PS4 is the new T35), T33/T34/T35/T100/T117/T213/T216 and the old self-test adjusted to the new rules

## 0.9.32
Follow-up of the review (9 Nov., 11:25):
- **Crafting no longer stutters** (play test S7 "3 SLOW", up to 131 ms per crafted item): while you craft, only the counters of the visible rows are brought up to date (skill, "N× to yellow", bags) – no rebuild of the list. A real change (skill point) rebuilds at most once per 2 s, and once more when crafting ends. Such a rebuild is split over several frames (about 10 ms of work per frame) and shown only when complete; a click, tab or search still rebuilds at once. The bargains and drop chances of the "Disenchanting" tab (computed by AHSentinel over its whole scan) are kept for 30 s and no longer computed again for every crafted item. New test case **T219** (area H): 5 crafts -> at most one rebuild per 2 s, every portion under 16 ms
- **Tooltips beside the panel:** tooltips of rows and buttons in the panel (and the "Buy" button, the tabs, the check box) are placed beside the panel – right of it (right of AHSentinel's docked window if it sits there), left of it if there is no room – and no longer cover the close button or other buttons (play test S8 / test case T206). New test case **T218**
- **Same AH fee as AHSentinel:** AHSentinel's real fee function `ForeverAuctionFee` is used (as a method, only in WoW Forever; the old names stay as fallback), and our own calculation rounds like AHSentinel (2010c -> 101c, was 100c). Play test S5 can now give a result. Test cases T35 and T213 use the real name
- **Play test:** a FEHLER stays in the report (a later OK no longer wipes it), an OK is written only once (no log line on every refresh), S2 is checked only when the profession or skill changed. S10 is OK only after both cases (window opened; with the chat input only the link and no window) and becomes FEHLER if our window opens in the chat case. New test case **T217**
- **Amount window at the vendor:** Esc now closes it wherever the focus is; the free room in the bags also counts started stacks of the same item and – for crafting reagents in Retail – the reagent bag (no more "bags full" too early). T215 closes the window through the real MERCHANT_CLOSED event
- Shared file GoldSentinelGame.lua updated to version 3 (comments only); no real player names in examples and tests any more

## 0.9.31
Disenchanting and prices calculated correctly (instruction of the review, 9 Nov., part A):
- **A1 Disenchanting table from Disenchantry** (1.1.2 by x_Raven_x, MIT licence – `LICENSE-Disenchantry.txt` is included): replaces our simplified table without AHSentinel, which added a shard to every green item. Now green item level 5–15: 80/20 without a shard; 21–25 armour 75/15/10; 51–65 weapons 22/75/3; WoW Forever weapons 21–30: Greater Magic Essence; amounts min–max (their middle for the calculation); blue up to item level 80 with Nexus Crystal 0.5 %; epic with amounts
- **A2 Value and profit apart:** "Disenchanting value (Ø)" and "Disenchanting value after fees"; as profit only "Craft & disenchant: profit = disenchanting value after fees − material cost". No window calls the pure value "profit"
- **A3 Safety margin:** under 10 real disenchants of the group (own + shared) the disenchanting value for profit and ranking is 10 % lower; the tooltip shows the margin and "(estimated)"
- **A4 Vendor price:** first what AHSentinel really saw at a vendor (current, exact for WoW Forever), then the data pack
- **A5 Buying price:** reagents bought in the AH are calculated with the cheapest offer of the last scan (AHSentinel `GetCurrent`, while not older than 3 h), otherwise the market value; the tooltip names the source ("AH current" / "market"). Products to sell keep the market value until AHSentinel has one price function (part B)
- Test routine: new test case **T216** (Brown Linen Pants without AHSentinel → 2 materials 80/20; item level 23 armour → 75/15/10; weapon 53 → 22/75/3; Forever weapon 25 → Greater Magic Essence; no label calls the value "profit"; margin under 10 disenchants; observed vendor price before the data pack; reagent to buy with the current price, old scan → market); T178 adjusted to the new order

## 0.9.30
Wish of the user (9 November): **amount window at the vendor**
- **Shift+click on a ware in Blizzard's merchant window** opens a small window of ProfessionSentinel instead of Blizzard's dialog (which only goes up to one stack): icon, name, price per piece (or per bundle), amount field, total price, "Buy" and "Cancel". Pre-filled with what the shopping list misses, otherwise one stack. Enter = buy, Esc = cancel, mouse wheel ±1, Shift+mouse wheel ±1 stack
- "Buy" buys exactly that amount over several purchases – the same function as the shopping list (full stacks, then the rest; bundles rounded up with a hint; limited goods at most what the vendor has, with a hint; not enough gold or full bags: as much as possible and a chat line). Only on click, never automatically; the window docks right of the merchant window and closes with it
- Right click (buy 1) and left click (pick up) stay as they are; with the chat input active Shift+click only inserts the link. No taint: only `hooksecurefunc` on `MerchantItemButton_OnModifiedClick`, Blizzard's dialog is just hidden afterwards. Classic Era the same way
- Option "Amount window at the vendor (Shift+click)", default on, `/ps menge`; listed with the other options on right-clicking the minimap button
- Play test: new check **S10** "Shift+click opens the amount window, Blizzard's dialog closed, chat link still works"
- Test routine: new test case **T215** (window opens and Blizzard's dialog closes; chat input active → only the link; option off; 60 at stack 20 → 20+20+20; bundle of 5, 12 typed → 15 with a hint; limited goods 3, 10 typed → 3 with a hint; gold for 7 → 7; vendor closed → window closed)

## 0.9.29
Wish of the user (9 November): **buy vendor goods in a free amount**
- **Shopping list (tab "Plan"):** with a vendor open, every row with vendor goods (e.g. Empty Vial, Coarse Thread) gets an amount field – pre-filled with what is missing, freely changeable – and a **"Buy"** button. The button's tooltip shows the total price before buying
- On click it buys **exactly that amount**, also over several purchases (full stacks up to the vendor's maximum, then the rest); goods sold in bundles (e.g. 5) are rounded up to whole bundles and the chat says so. Not enough gold, full bags or the vendor runs out: as much as possible and a chat line. Only on click with the vendor open, never automatically; the purchases go through `ns.Act` as before. The diagnostic log notes KAUF (reagent, wanted, bought, price)
- Play test: new check **S9** "bought amount = typed amount (or whole bundles)" – compares the bags shortly after the purchase
- Test routine: new test case **T214** (16 at stack 20 → 1 purchase; 50 → 20+20+10; bundles of 5, 12 typed → 15 with a hint; gold for 7 → 7 and a message; full bags; nothing without an open vendor; S9); T213 adjusted for S9

## 0.9.28
- **New: play test `/ps spieltest an|aus|bericht`** (wish of the user): instead of working through the checklist by hand, ProfessionSentinel checks itself while you play – as soon as you bring about the situation (open the profession window, click recipes, craft, gain a skill point). It never calls a protected function itself and does nothing with the interface in combat. Off by default; once switched on it runs until /reload, at most 2 hours
  - **S1** a click opens the recipe at once (way "Liste", < 0.5 s; result after 5 clicks) · **S2** skill > 0 and the plan starts at the skill · **S3** "N× to yellow" goes down after a skill point · **S4** the panel covers neither the profession window nor AHSentinel's window (also when it appears later) · **S5** the AH fee is the same number as in AHSentinel · **S6** levelling ranking: learned first, sorted by material per point, nothing grey · **S7** crafting 5 items sets off no storm (at most 2 rebuilds/s, nothing over 16 ms) · **S8** the interface check of area K once with the profession window open
  - Each result (OK / ERROR with the measured value and the expectation) goes into the diagnostic log; an ERROR prints one chat line per check. `/ps spieltest bericht` lists OK / ERROR / open with the situation that is still missing and saves a GSTEST1 report (area "S") for the review. No names
- Test routine: new test case **T213** (every check S1–S8 with a passing and a failing situation, one chat line per ERROR, report with OK/ERROR/open)

## 0.9.27
Performance (in the game the panel took up to 44 ms, the best recipe 20 ms, AD.Plan 68 ms; limit 16 ms) and two test-routine findings:
- **Compute once per pass:** one update (AD.Update, UI:Refresh, AD.Plan) evaluated a recipe up to three times (levelling, gold, disenchanting) and asked AHSentinel for the same market values again and again. Now every AH value, recipe price and bag count is computed once per pass; the memo is thrown away when the pass ends, so nothing goes stale
- **Diagnostic log shows the slow part:** besides UI:Refresh it now logs UI:UpdateBest and UI:Refresh/<view> separately (only over 16 ms)
- **T145 memory:** after the run the test routine throws away the derived caches it filled with test data (guild index with 300 members, rankings with "all known", recipe-ID table, its own report copy) before measuring
- **T132 global names:** the children that Blizzard templates name after our own windows (…Bg, …CloseButton, …Inset, …Portrait, …TitleText) count as our own and are no longer reported
- Test routine: new test case **T212** (one update asks every market value and every bag count only once; the pass always ends)

## 0.9.26
Test routine checks the interface in the real client (instruction of 5 Nov., template UICheck.lua):
- **New UICheck.lua** (from the GoldSentinel template, in all four TOCs): the panel, the diagnostic log, the test report, the test mode and the enchanter question register with `ns.RegisterUI`, so the other GoldSentinel addons can check against them as well
- **New area K** (`/ps testroutine k`): **T206** own tooltips cover no buttons, **T207** no overlap with the profession window, AHSentinel's profit window and other GoldSentinel windows, **T208** windows inside the screen, **T209** button labels not cut off – these four only in the real client with the panel open (otherwise skipped with a hint, never counted as OK); **T210** game values plausible: "skill > 0 if the profession is learned" and "the plan starts at the skill" (`ns.Plausible`); **T211** no error loop (same message more than 10×)

## 0.9.25
**Fee rule for WoW Forever (user's statement of 9 November, replaces all earlier ones):** there is only ONE fee – the AH fee = max(5 % of the auction's sale price, 1 silver), per auction (per listed stack, not per piece), paid when listing. There is no separate listing fee.
- Prices.lua: no listing fee from the vendor value any more. Fee per piece = max(5 % × sale price of a full stack, 1s) ÷ stack size; net = AH value − AH fee. With AHSentinel loaded its fee function is used (same number in both addons). Disenchanting materials the same way. Classic Era, TBC and Retail unchanged (5 % cut on the sale)
- Tooltip: one line "AH fee (5 %, at least 1s)" instead of "AH cut" plus "listing fee"; under the net value "incl. AH fee"
- Test routine: T35 now checks the rule (3s 90c → 1s, 2s → 1s, 1g → 5s, a stack of 20 at 1c → 1s once, no own listing fee, AHSentinel's function wins); T33 and the old self-test adjusted

## 0.9.24
Fix from the diagnostic log (0.9.22 in WoW Forever): **event storm at the profession window** – 7450 rebuilds by TRADE_SKILL_LIST_UPDATE, UI:Refresh 101 ms and AD.Update 39 ms each time; this caused the stutter.
- **Cause:** after every TRADE_SKILL_LIST_UPDATE all recipes were scanned and everything was recomputed and redrawn – even with the panel closed. Reading the recipe list can make the game send TRADE_SKILL_LIST_UPDATE again, so the scan fed itself
- **Now:** list events right after our own scan are ignored (1 s); events are collected (one scan per 0.5 s); a full refresh (recompute + rebuild) only happens if profession, skill or learned recipes really changed, or the window opened / a recipe was learned / a skill point came. Otherwise only a visible panel is redrawn from the cache – a hidden panel not at all. Results are cached for up to 30 s (was 5 s). The panel is rebuilt at most every 0.5 s
- **Docking:** the panel also re-docks when AHSentinel's window changes its size (OnSizeChanged), besides OnShow/OnHide and every own refresh
- The tooltip line "incl. listing fee" (step 1 of the list of 9 Nov.) is already in since 0.9.19
- Test routine: new test case **T205** (100 list events without change → no full rebuild, hidden panel not redrawn, events right after the own scan ignored; a skill point still refreshes); T91 and T190 adjusted

## 0.9.23
Fix from the game (WoW Forever, 5 November): with 0.9.20 the profession window still jumped to the recipe very slowly.
- **Selection through the window's own list, like AHSentinel:** a click now selects the recipe with `ProfessionsFrame.CraftingPage.RecipeList:SelectRecipe(recipeInfo, true)` – it jumps there in the same frame. `C_TradeSkillUI.OpenRecipe` (which in WoW Forever jumps there much later) is only the fallback. The diagnostic log shows the way used ("Liste" / "OpenRecipe")
- **Recipe-ID table kept:** it is read again only when the window opens or switches profession, or a recipe was learned – no longer on every TRADE_SKILL_LIST_UPDATE (before, the next click had to read every recipe again)
- Test routine: new test cases **T203** (click selects through the list with scrolling into view, no OpenRecipe; selection reported in the same frame; fallback to OpenRecipe) and **T204** (20 list events → table built at most once; profession switch builds it again)

## 0.9.22
Test routine by the rules that proved themselves in LevelPilot:
- **Honest counting:** a test case that checked nothing is never OK any more – it counts as skipped ("not automated – no check ran"). This was the case for T195 in the modern client. After every run a line **"Not automated: N"** (skipped plus check in client) follows the counts
- **Fixed list "check in the game":** the run stores all cases that only the game can check; `/ps testroutine liste` prints them with instructions and how to confirm (`/ps testroutine ok <ID>`)
- **Every error from the game has its own test case** – checked by the new case **T202** (popup %, docking, skill 0, AHSentinel window appearing late, click without AHSentinel and without waiting, diagnostic log)

## 0.9.21
- **New: diagnostic log `/ps protokoll`** (modelled on LevelPilot): a window with copyable text – version, client, interface, sessions, changed settings, diagnostics (price source, panel open, docked to the profession window or AHSentinel's window, rebuilds) and the entries, newest first: **KLICK** (recipe, spell ID, recipe ID, way, ms, selected yes/no), **AUFBAU** (collected rebuild: trigger event, requests, ms), **LANGSAM** (UI:Refresh, AD.Update, plan over 16 ms), **ÜBERLAPPT** (no free place / panel overlaps AHSentinel's window), **FEHLER** (Lua errors of the addon, the same error only counted). Ring buffer of 200 entries in ProfessionSentinelDB.diag
- On /reload or logout the log is stored as a **GSDIAG1** string in `ProfessionSentinelDB.diagExport` (head line `GSDIAG1|ProfessionSentinel|<version>|<client>|<interface>|<date>`, then the text, at most 24,000 characters), so the RaidMasterUploader can send it like the GSTEST1 reports. Player, realm, guild and character names are replaced by `<Name>`. The test routine never writes into the real log
- Test routine: new test cases **T198** (all five kinds, counting instead of flooding, a panel click is logged), **T199** (ring buffer, test run does not write, damaged log repaired), **T200** (GSDIAG1 head line, size, bait names never in the export, no export during the test routine), **T201** (`/ps protokoll` opens the window)

## 0.9.20
Fix from the game (WoW Forever, 5 November): a click in the panel opened the recipe only if it had been clicked in AHSentinel before; otherwise the window jumped there only after 50 seconds or more.
- **ProfessionSentinel now finds the recipe ID of the open window itself** (no AHSentinel needed): the recipe IDs of the window (GetAllRecipeIDs) are read once into a table name / result item → recipe ID, again whenever the window's list changes. A click takes the window's own ID – by German or English name, else by result item, else the ID the window reports for the spell ID – and opens it right away. It is checked in the same frame whether the window shows it (no timer)
- Test routine: new test case **T197** (the case from the game: no AHSentinel, the window also answers for the spell ID but lists the recipe under its own ID → its ID is opened at once, no timer, confirmed in < 0.5 s; result item when names differ); T196 adjusted

## 0.9.19
Fix from the game (WoW Forever, 5 November):
- **Fixed: a click on a recipe opened nothing since 0.9.18** (and a chat message appeared). Our data keeps the Classic spell ID, but the modern profession window can know the recipe under another recipe ID. The click now finds the recipe ID of the open window: the spell ID if the window knows it under the same name, otherwise the window's recipe with the same German or English name (no dummy or recraft entries), and opens that. The message only comes if the recipe really is not in the window. A left click still triggers exactly once (on press)
- **Tooltip: "incl. listing fee"** under "Net per craft" (and under the disenchanting net) in WoW Forever, so the number can be followed. The calculation itself is unchanged (listing fee at least 1s per auction, never refunded; 5 % cut)
- Test routine: new test case **T196** (spell ID → recipe ID of the window, German and English name, same ID, recipe missing → message; one action per click); T193/T194 adjusted

## 0.9.18
Fix from the game (WoW Forever, 5 November): a click on a recipe in the panel opened it in the profession window only sometimes.
- **Cause: the list was rebuilt while you clicked.** Profession events come in bursts (TRADE_SKILL_LIST_UPDATE many times per second) and each one rebuilt the panel. Now they are collected and the panel is rebuilt at most every 0.4 s
- **Compute once, draw often:** levelling, gold and material rankings are cached and only computed again when profession, skill, recipe/learned data, test mode or price source change (or after 5 s for AH prices). Switching tabs and typing in the search box only draw
- **Left click on press:** rows take the left click when the button goes down, so a rebuild between press and release can no longer swallow it
- **Opening is more robust:** a search text in the profession window is cleared first; in Classic Era also the name filter, and collapsed categories are opened. If the recipe still cannot be opened, a short chat message says so (EN/DE) instead of nothing happening. The list background never takes clicks
- Test routine: new test cases **T192** (20 events in 1 s → at most 3 rebuilds; cache), **T193** (click while a rebuild is planned opens the recipe), **T194** (search text active → right recipe; message on failure), **T195** (collapsed category; background takes no clicks)

## 0.9.17
Wish of the user (5 November):
- **Ranking tab: "Levelling – material per skill point"** instead of "gold per skill point". Learned recipes come first, the ones not learned yet below them (own sub-part "Not learned yet"). Both parts are sorted by the least material per expected skill point – the pure amount of reagents, not their gold value. Intermediate products of the same profession count as their base material (blacksmithing counts in bars). Expected points per craft: orange 1, yellow 0.5, green 0.25; grey recipes are left out. The row no longer shows a gold value there, only how often to craft until the next colour. "Making gold", "Top 10", the star and the level plan are unchanged
- Test routine: new test case **T191** (orange 2 bars and yellow 1 bar both value 2, tie in stable order; not learned recipe with value 1 below all learned ones; grey recipe missing; intermediate product as base material)

## 0.9.16
Fix from the game (WoW Forever, 5 November):
- **AHSentinel's profit window no longer lies on top of the panel:** it often appears later (e.g. when choosing a recipe), after the panel had already docked. With AHSentinel 0.65.11+ the panel now hooks AHSentinel's window once via `AHAnalyzerPro.Crafting:GetDockFrame(true)` (also while hidden) and re-docks whenever it is shown or hidden, on its own Refresh and on TRADE_SKILL_SHOW. Older AHSentinel versions work as before
- Test routine: new test case **T190** (AHSentinel's window appears after the panel → hooked once, docked right of it, no overlap; older AHSentinel versions)

## 0.9.15
Fix from the game (WoW Forever, 5 November):
- **Fixed: skill read as 0 in the modern client** (WoW Forever, Retail): the level plan started at 0 (e.g. cooking 110/150: "from 0 to 75", fishing 114/150: "from 0 to 20") and the lifeline showed almost the same "45× to yellow" everywhere and did not count down. The window's child info can report 0 or a stale value. Now every source of the open profession is read (child and base info of the profession window, the skill line, GetProfessions/GetProfessionInfo) and the highest valid value wins. Skill-up events (CHAT_MSG_SKILL, SKILL_LINES_CHANGED, TRADE_SKILL_LIST_UPDATE) redraw the plan and lifeline with it. If no valid value can be read, the plan says "Skill unknown" instead of planning from 0
- The placeholder of the search box is shorter and stays on one line
- Test routine: new test case **T189** (simulated skill 110 → plan starts at 110; +1 → "N× to yellow" goes down; stale value and fallback; unknown stays unknown)

## 0.9.14
Fixes from the in-game test routine (WoW Forever, 5 November):
- **Fixed: Lua error in the input windows** for surcharge, minimum profit and disenchanting margin (`GameDialog.lua: invalid option in 'format'`). The game runs the popup text through `string.format`, and the "%" in "in %" broke it; every "%" is now passed as "%%". Test case **T63** now also checks that the text survives `string.format`
- **No more overlap at the profession window:** if AHSentinel's profit window is shown, the panel docks to the right of it, otherwise directly right of the profession window as before. Only AHSentinel's interface `AHAnalyzerPro.Crafting:GetDockFrame()` is used; older AHSentinel versions without it are left alone (no frame search). When AHSentinel's window is shown or hidden, the panel re-docks. Near the right screen edge it moves below AHSentinel's window or to the left of the profession window – never on top of another window. Only our own panel is moved
- Test routine: new test cases **T187** (no overlap with and without AHSentinel, screen edge, old AHSentinel versions, errors in the interface) and **T188** (check in the game with AHSentinel)

## 0.9.13
- **New: minimap button** (book icon, like every GoldSentinel addon): left-click opens or closes the panel like `/ps`, right-click lists the options with their state and the command that switches them (ProfessionSentinel has no options window – its options are the `/ps` commands), drag moves it around the minimap; the position is saved per account. `/ps minimap` shows or hides it (shown by default, also listed in `/ps help`). No library needed, works in every game version; damaged saved positions are repaired on load
- Test routine: new test cases **T182–T185** (area B: button there and visible, show/hide with `/ps minimap`, saved angle → position after /reload, simulated drag, repair of damaged values, left-click opens and closes, right-click options, tooltip in English and German) and **T186** (check in the game: visible, drag, tooltip language)
- Test routine: the description of `/ps testroutine api` now says what it does – only entries of the addon's own table `ns.API` are switched, never a Blizzard function

## 0.9.12
Fixes from the review of 0.9.11 ("Korrekturen aus der Nachprüfung 0.9.11"):
- **No Blizzard function is replaced any more, not even in the test routine (taint):** the addon now calls the game API only through its own table `ns.API` (filled when the addon loads; functions of `C_` tables get flat entries such as `ns.API.MerchantGetItemInfo`; missing functions stay empty, so older game versions keep their old ways). The test routine only switches entries of this table. The `[api]` cases only run with `/ps testroutine api` (with a warning before the start), no longer in the normal run
- **One place for actions with consequences:** buying at the vendor, whispering enchanting offers (with `C_ChatInfo.SendChatMessage` as a second way if the global function is missing), crafting and the map pin all go through `ns.Act`; during a test run it only writes them down. New test case **T180** (area I) checks that every action path arrives there and nothing real happens; `tests/check_actions.py` checks the source code
- **T145 memory:** measured after releasing the run's own copies and two full garbage collections, with a longer warm-up; offline the measurement no longer counts LuaJIT's compiled code (the game has no JIT)
- Test routine: the sub-runs of T20 and T110 really only take area F now
- **Realms with a hyphen** (e.g. Retail "Azjol-Nerub"): your own character no longer shows up among "your other characters" in the tooltip (new test case T181)
- "Please /reload" after every test run; the remaining test texts ("GoldSentinelTest/SavedVariables missing", "Run again", "Select all") now come from the locales (EN/DE)
- Protected values (WoW Forever, Retail in combat): learned-recipe event, tooltips, the enchanting customer and the guild list ask `IsSecret` first, before any comparison
- Nothing changes for players in how the addon looks or works

## 0.9.11
- Internal: **one test routine** for the developer (`/ps testroutine`, button "Test everything" in test mode): 179 test cases (T01–T179) in ten areas, results go to the review through the shared `GoldSentinelTest.lua`. `/ps selftest` and `/ps autotest` now run on the same machine. Nothing changes for players
- Lua errors of the addon are now counted locally (at most 50 kinds) and sent with the next test report; nothing is sent anywhere by the addon itself
- Fixes found by the new test cases (older game versions behave exactly as before):
  - modern client: stack size, vendor sell price, disenchant values and shift-click links also work without the old `GetItemInfo`
  - protected values in combat (WoW Forever, Retail): learned-recipe events, tooltips, the customer for enchanting offers and the guild list never use them
  - errors inside AHSentinel no longer break the enchanter tab; damaged saved data (favor costs, plan target, enchanting prices, characters) is repaired on load instead of causing Lua errors
  - buying, whispering, sniper targets and waypoints are refused in combat with a short message

## 0.9.10
Recipe data updated (WoW Forever client 1.60.1.70753, QuestieDB 2026-11-02):
- **New recipe:** Enchant Boots - Speed (Enchanting, skill 280) – formula from a vendor
- **37 recipes with a newly known vendor source**, now with price and required skill: e.g. the Veteran's/Guard's/Protector's chain armor sets (Blacksmithing 80–125), 18 Leatherworking patterns, the Heart of the Mountain formulas (Enchanting 265) and Minor Spellblasting Potion (Alchemy 35)
- Classic Era and Retail: no changes to recipes (data source date only)

## 0.9.9
Fixes from the review of 0.9.8:
- **WoW Forever, reputation:** your reputation is now also read on the modern client (`C_Reputation`) – the reputation line of favor recipes turns green or red again instead of always yellow
- **Merchant's Favor from AHSentinel:** only Merchant's Favor is taken over, no other currency (otherwise price and balance were wrong)
- **Costs not readable?** If the client cannot read favor costs at the vendor, the addon says so once per vendor visit; the diagnosis shows "vendor costs readable: yes/no"
- **Crate calculator:** for green crates (bars, bolts, parts) the cheaper of buying and **crafting yourself** counts; the tooltip shows which one was used
- **New, off by default:** the best crate (gold per favor) at the top of "craft today" – switch it on in the Favor tab or with `/ps kisten`
- Favor cost and reputation now also in the item tooltip (bags, AH)
- Older game versions: buying at the vendor exactly as before again; the new tab layout without gaps only applies to WoW Forever

## 0.9.8
- Internal: **GoldSentinelGame.lua version 2** – wins over early, withdrawn versions in other GoldSentinel addons and stays compatible with them (no Lua errors when several addons bring different versions). Nothing changes for players

## 0.9.7
- **WoW Forever, vendors:** when a supply-camp vendor was only visited with AHSentinel, ProfessionSentinel now also takes over the currency – your Merchant's Favor balance shows up without visiting the vendor yourself. Order of the costs: read at the vendor yourself → read by AHSentinel → guides
- Buying at the vendor and reading the costs no longer depend on old vendor functions missing in the modern client (count, link, purchase); older game versions are unchanged (test in the client)

## 0.9.6
- Internal: the game version now comes from **GoldSentinelGame.lua**, the shared detection of all GoldSentinel addons (the same file as in RaidMaster, GuildSentinel, ThreatSentinel and BuffSentinel). WoW Forever always counts as a modern client there, never as Classic. `/gsgame` shows what was detected in the chat. Nothing else changes for players

## 0.9.5
- **WoW Forever: new "Favor" tab** (Merchant's Favor)
  - **Favor planner:** put favor recipes (click) and goals – Pack Kodo 6000, Minimule 1500, profession certification 1000, tabard 200 – on a wish list; the addon shows your balance and how much is still missing. Learned recipes drop out by themselves
  - **Favor recipes of your profession** with cost, reputation and **who in the guild already knows them** (data from GuildSentinel/RaidMaster)
  - **Crate calculator:** all 30 Waylaid Crates with the cheapest material bundle (AH or vendor prices), the empty crate from the AH and **gold per favor point**. Crates in your bags come first, "ready" means the material is already there. The favor of artisan crates is still estimated
- **WoW Forever: buying at the vendor** (levelling plan, craft today) now uses the vendor functions of the modern client – the old ones no longer exist there (test in the client)
- When AHSentinel reads Merchant's Favor costs at the vendor, ProfessionSentinel uses them if it has none of its own yet
- 0.9.3 and 0.9.4 (shared game-version detection) were withdrawn; it will come later for all GoldSentinel addons together

## 0.9.2
- **WoW Forever: supply-camp recipes cost Merchant's Favor, not gold.** The 310 recipes of "Durotar Supply and Logistics" (Horde, Barrens) and the "Azeroth Commerce Authority" (Alliance, Three Corners) showed a gold price that does not apply in the game. The tooltip now shows the cost in **Merchant's Favor** and the required **reputation** (Alliance players see their faction)
- The values come from public guides (beta). **When you open a supply-camp vendor, the addon reads the real costs** and remembers them – they then win over the guide values. Once you have seen the currency at the vendor, the tooltip also shows how much of it you have
- Recipes that regular vendors sell as well (e.g. Smoked Sagefish) keep their gold price

## 0.9.1
- **WoW Forever: listing fee** – every auction costs at least 1 silver and it is not refunded. It is now taken off the AH proceeds (on top of the 5 % cut): making gold, levelling, craft today, disenchant materials
- Cheap items are therefore often worth more at the vendor – the addon then uses the vendor price (e.g. AH 1s 50c → only 42c left, the vendor pays 71c)
- The tooltip shows the fee as its own line

## 0.9.0
- **Craft today** (top of the "Ranking" tab, `/ps heute`): the most profitable crafts of all your professions – learned recipes, sold in the AH, net after the 5 % cut; at most 5 per recipe and 20 % of your gold per row
- **One click = next step:** buy vendor reagents (vendor open) → buy AH reagents (via AHSentinel) → craft (profession window open) → list in the AH (via AHSentinel)
- API for AHSentinel: the craft suggestions can show up in its "Heute tun" (coming with the next AHSentinel version)

## 0.8.3
- Internal: the developer test-mode window (`/ps test`) now opens on the first try after login. Nothing changes for players

## 0.8.2
- Internal: the developer autotest names the reason when the test-mode window does not open, and only toggles groups that have rows (no more false warnings for empty rankings). Nothing changes for players

## 0.8.1
- Retail: fixed the error "Attempt to register unknown event TRADE_SKILL_UPDATE" while loading – profession events are only registered if the client knows them

## 0.8.0
- **Retail** (12.1.5 Midnight, interface 120105): ProfessionSentinel now runs in regular WoW as well – with about **10,170 recipes of every expansion** straight from the Retail client
- In Retail **every expansion is its own profession with its own skill**, like the profession window (e.g. "Midnight Leatherworking", "Classic Leatherworking") – recipes, lifeline, ranking, levelling plan to the expansion's cap, reputation, recipe alarm and reagent tooltip work there
- Retail has no QuestieDB: no vendor, drop and trainer locations (the Trainers tab is hidden there); vendor goods like threads and dyes come from Classic, new vendor prices are read by AHSentinel when you visit a vendor
- Enchanting in Retail: only "sell enchants" – the disenchant tables do not apply there
- Vendor prices: where the data knows none, ProfessionSentinel uses the price AHSentinel read at the vendor (all game versions)

## 0.7.1
- Internal: automatic in-game test for the developer (opens every tab and button for each profession, catches Lua errors and writes a report). Nothing changes for players

## 0.7.0
- **Levelling plan** (new "Plan" tab): from your skill to 75/150/225/300 – which recipe how often, with a shopping list (missing after bags and bank). One click buys exactly what is missing at the open vendor, another puts the AH reagents into AHSentinel's sniper (market value + 10 %)
- **Reputation recipes:** the tooltip shows which reputation and standing is needed – green if you have it (also new Forever factions like Kirin Tor)
- **Recipe alarm:** when a recipe you or one of your characters misses is in the AH (AHSentinel scan) you get a message with a sound; the Recipes tab lists them on top, click = sniper. On/off: `/ps alarm`
- **Guild** (data from GuildSentinel / RaidMaster): who can craft the recipe (online first), group "Nobody in the guild knows" and the **cooldowns** (transmute, mooncloth, salt shaker)
- **Recipes in your bags:** who still needs them – or nobody (then sell); **reagent tooltip:** how many recipes use an item and which of them you know (raid materials like Lava Core too)
- **Sell enchants:** right-click whispers materials and price to the customer (also with their own materials)
- Levelling: profitable recipes with a low chance no longer win just because many crafts add up – profit counts per craft × chance

## 0.6.5
- Enchanting: at the **first login** a window asks for your goal – **make gold** (default, marked), **sell enchants** or **both**. It stays open until you picked one, and you close it yourself with "Done". Until then make gold applies. Change it later with `/ps ziel` or at the top of the "Enchanter" tab

## 0.6.4
- Enchanting: no question at login any more – the default is **make gold**. Switching to selling enchants or both is optional with `/ps ziel` or at the top of the "Enchanter" tab; once per character a short chat hint explains it

## 0.6.3
- Test mode and self-test (`/ps test`, `/ps selftest`) are now only available to the developer – like in AHSentinel. For everyone else the addon works exactly the same, just without these tools

## 0.6.2
- Enchanter: "Bargains in the AH" only lists items that keep your **minimum margin when disenchanting** – exactly the ones the sniper buys

## 0.6.1
- Only for enchanters with the goal "make gold" or "both": **buy with the sniper** – one click puts the bargains (items cheaper than disenchanted) or the AH reagents of your best "craft & disenchant" recipes into AHSentinel's sniper. Max price and amount are set, you only set the budget
- **Minimum margin when disenchanting** (default 20 %): you pay at most 80 % of what the materials bring after the AH cut
- Disenchanting only lives in the "Enchanter" tab now: "Making gold" in the other professions' ranking counts selling only again
- "Craft & disenchant" now covers the recipes of **all your professions**

## 0.6.0
- Enchanting: characters with enchanting are asked once what for – **make gold**, **sell enchants** or **both**. The enchanting part follows that choice, everything else stays the same. Change it any time with `/ps ziel` or in the new "Enchanter" tab
- **Make gold:** disenchant value of every craftable item (materials minus the 5 % AH cut). "Making gold" takes disenchanting when it brings more (DE); new group **"Craft & disenchant"** – buy reagents, craft, disenchant, sorted by profit
- "Enchanter" tab: **bargains in the AH** that cost less than they bring disenchanted, and the **learned drop chances** compared with the starting values
- Drop chances learn from every disenchant – yours and those of every player with AHSentinel. Starting values for green items: 75 % dust, 20 % essence, 5 % shard (weapons the other way round)
- **Sell enchants:** all your enchants with their material cost (AH or vendor prices) and your **selling price** – you set the surcharge in % and a minimum profit
- Levelling still counts selling only
- Test mode: simulate an enchanter and cycle through the three goals

## 0.5.1
- Profit calculation deducts the 5 % auction house cut from the sale price – ranking, making gold and net per point use what you actually receive
- If the vendor pays more after the cut, the vendor value counts
- Tooltip shows AH price, AH cut (5 %) and what you receive from the AH

## 0.5.0
- Gold in the ranking: "Levelling" sorted by gold per skill point, new group "Making gold" sorted by net profit per craft – grey recipes included
- Reagent costs: vendor items at the vendor price, everything else at the AH value (also farmed material); product at the higher of AH value and vendor sell value
- AH values from AHSentinel (otherwise TSM or Auctionator); without an AH addon the ranking stays on reagents per skill point
- Rows show where the reagents come from (AH / vendor / farm) and "+10s 80c/pt"; the tooltip breaks down every reagent with price, cost, sell value and net
- Test mode: "test prices" to try the gold ranking without an AH scan

## 0.4.0
- Levelling ranking: every recipe that gives points at your skill – learned and not learned – sorted by reagents per skill point (reagents ÷ chance of a point)
- New "Ranking" tab with the full list, top 10 on top of the "Recipes" tab; recipes you still have to learn are tagged [learn] with their source
- Star on the best learned recipe in Blizzard's recipe list, hint with place and reagents per point on the profession window (click selects it)
- Recipes far above your skill no longer count as orange: missing learn levels are estimated (WoW Forever from the Era level of the same recipe)
- Classic Era: Season of Discovery recipes removed (1267 real Era recipes)

## 0.3.0
- New "Trainers" tab: every trainer of the open profession by rank – Journeyman (to 150), Expert (to 225), Artisan (to 300), specialisations – with zone, coordinates and faction; your next rank is marked
- Vendors and drop mobs in the recipe tooltip now show zone and coordinates
- Click a trainer for a waypoint; right-click a recipe for a waypoint to the nearest vendor (TomTom if installed, otherwise the game's map pin)
- Zone names in the client's language; new WoW Forever zones (Isle of Zephras, Riverlands) supported
- Test mode: trainer and waypoint checks, "test waypoint" button

## 0.2.0
- Detects the game version from the client and adapts: WoW Forever (own recipes and skill levels – many recipes turn grey sooner) and Classic Era (classic profession and enchanting windows)
- Lifeline: a thin line under every recipe (orange → yellow → green → grey) with a marker at your skill and how many crafts it takes until the next colour – in Blizzard's recipe list and in the "All recipes" panel
- Tooltip shows crafts until yellow, green and grey
- Test mode (/ps test): diagnostics, simulated skill, simulated learned state, panel without profession window, self-test (/ps selftest)
- /ps line toggles the lifeline
- Fixed swapped skill levels on a few client recipes (e.g. Charged Scale of Onyxia)

## 0.1.0
- First release for WoW Forever (Interface 16001)
- "All recipes" panel docked to the profession window, grouped like the client's categories
- Learned recipes greyed out, missing recipes in rarity colour
- Tooltips with skill levels, reagents and recipe sources (trainer, vendor, drop, quest)
- Recipe item tooltips show learned / not learned for all your characters
- 2210 recipes, 934 of them new in WoW Forever
