-- ThreatSentinel - Mover.lua
-- Anzeigen verschieben und in der Grösse ändern: kleines HUD, Aggrometer, DD-Ansicht.
-- "Verschieben" (Einstellungen > Anzeige oder /ts verschieben) zeigt alle drei
-- mit Beispielinhalt: ziehen = verschieben, Mausrad = Grösse, Rechtsklick = Grösse 100 %.
-- Ausserhalb des Verschiebens sind sie gesperrt und klicken nicht (stören im Kampf nicht).

local ADDON, ns = ...
local L = ns.L

local MV = {}
ns.Mover = MV
table.insert(ns.modules, MV)

local WHITE = "Interface\\Buttons\\WHITE8X8"
local BACKDROP = BackdropTemplateMixin and "BackdropTemplate" or nil
local MIN_SCALE, MAX_SCALE = 0.5, 2.5

MV.ITEMS = {
	hud = { point = "hudPoint", scale = "hudScale", label = "MV_HUD", mod = function() return ns.HUD end },
	meter = { point = "meterPoint", scale = "meterScale", label = "MV_METER", mod = function() return ns.Meter end },
	dd = { point = "ddPoint", scale = "ddScale", label = "MV_DD", mod = function() return ns.DD end },
	dmg = { point = "dmgPoint", scale = "dmgScale", label = "MV_DMG", mod = function() return ns.DmgMeter end },
}
MV.frames = {}

ns.moveMode = false

-- Frames reagieren auf die Maus nur beim Verschieben (oder wenn sie in den Einstellungen entsperrt sind)
function ns:Unlocked()
	return ns.moveMode or (ns.db and not ns.db.hudLocked) or false
end

-- Position speichern (relativ zur Bildschirmmitte, unabhängig von der Grösse wiederherstellbar)
function MV:SavePoint(f, pointKey)
	local p, _, rp, x, y = f:GetPoint()
	if not p then return end
	ns.db[pointKey] = { p, "UIParent", rp, x, y }
end

local function Clamp(v)
	v = math.floor(v * 20 + 0.5) / 20
	return math.max(MIN_SCALE, math.min(MAX_SCALE, v))
end

-- Grösse ändern, ohne dass das Fenster wegspringt: die Mitte bleibt, wo sie ist
function MV:SetScale(which, scale)
	local it = self.ITEMS[which]
	local mod = it and it.mod()
	local f = mod and mod.f
	scale = Clamp(scale)
	if not f then
		ns.db[it.scale] = scale
		return
	end
	if math.abs((ns.db[it.scale] or 1) - scale) < 0.001 and math.abs(f:GetScale() - scale) < 0.001 then return end
	local cx, cy = f:GetCenter()
	local old = f:GetScale()
	ns.db[it.scale] = scale
	if cx and cy then
		local ux, uy = cx * old, cy * old
		f:SetScale(scale)
		f:ClearAllPoints()
		f:SetPoint("CENTER", UIParent, "BOTTOMLEFT", ux / scale, uy / scale)
		self:SavePoint(f, it.point)
	else
		-- noch nie angezeigt: gespeicherte Abstände umrechnen, damit das Fenster nicht springt
		local p = ns.db[it.point]
		if type(p) == "table" and tonumber(p[4]) and tonumber(p[5]) and old > 0 then
			p[4] = p[4] * old / scale
			p[5] = p[5] * old / scale
		end
	end
	if mod.ApplySettings then mod:ApplySettings() end
	self:UpdateLabel(which)
	if ns.Options and ns.Options.RefreshAll and ns.Options.frame and ns.Options.frame:IsShown() then
		ns.Options:RefreshAll()
	end
end

------------------------------------------------------------
-- Rahmen und Beschriftung über jedem Fenster (nur beim Verschieben sichtbar)
------------------------------------------------------------
function MV:Attach(f, which)
	local o = CreateFrame("Frame", nil, f, BACKDROP)
	o:SetAllPoints()
	o:SetFrameLevel(f:GetFrameLevel() + 20)
	if o.SetBackdrop then
		o:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 2 })
		o:SetBackdropColor(0.25, 0.65, 1, 0.18)
		o:SetBackdropBorderColor(0.25, 0.65, 1, 1)
	end
	o.label = o:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	o.label:SetPoint("BOTTOM", o, "TOP", 0, 3)
	o.label:SetTextColor(0.5, 0.85, 1)
	o:Hide()
	f.moveOverlay = o
	self.frames[which] = f

	f:SetScript("OnMouseWheel", function(_, delta)
		if not ns.moveMode then return end
		MV:SetScale(which, (ns.db[MV.ITEMS[which].scale] or 1) + delta * 0.05)
	end)
	f:HookScript("OnMouseUp", function(_, button)
		if ns.moveMode and button == "RightButton" then MV:SetScale(which, 1) end
	end)
end

function MV:UpdateLabel(which)
	local f = self.frames[which]
	if not f or not f.moveOverlay then return end
	local it = self.ITEMS[which]
	f.moveOverlay.label:SetText(string.format(L.MV_LABEL, L[it.label], math.floor((ns.db[it.scale] or 1) * 100 + 0.5)))
end

------------------------------------------------------------
-- Leiste oben: Fertig / Zurücksetzen
------------------------------------------------------------
function MV:BuildBar()
	local b = CreateFrame("Frame", "ThreatSentinelMoveBar", UIParent, BACKDROP)
	b:SetSize(460, 62)
	b:SetPoint("TOP", 0, -120)
	b:SetFrameStrata("FULLSCREEN_DIALOG")
	b:SetClampedToScreen(true)
	b:EnableMouse(true)
	b:SetMovable(true)
	b:RegisterForDrag("LeftButton")
	b:SetScript("OnDragStart", b.StartMoving)
	b:SetScript("OnDragStop", b.StopMovingOrSizing)
	if b.SetBackdrop then
		b:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
		b:SetBackdropColor(0.05, 0.06, 0.08, 0.95)
		b:SetBackdropBorderColor(0.25, 0.65, 1, 0.8)
	end
	local t = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	t:SetPoint("TOP", 0, -8)
	t:SetWidth(440)
	t:SetText(L.MV_HELP)
	local done = CreateFrame("Button", nil, b, "UIPanelButtonTemplate")
	done:SetSize(110, 22)
	done:SetPoint("BOTTOMRIGHT", -10, 8)
	done:SetText(L.MV_DONE)
	done:SetScript("OnClick", function() MV:Stop() end)
	local reset = CreateFrame("Button", nil, b, "UIPanelButtonTemplate")
	reset:SetSize(150, 22)
	reset:SetPoint("BOTTOMLEFT", 10, 8)
	reset:SetText(L.MV_RESET)
	reset:SetScript("OnClick", function()
		for which, it in pairs(MV.ITEMS) do ns.db[it.scale] = 1 end
		ns:ResetPositions()
		for which in pairs(MV.ITEMS) do MV:UpdateLabel(which) end
	end)
	b:Hide()
	self.bar = b
end

function MV:Start()
	if InCombatLockdown() or UnitAffectingCombat("player") then ns:Print(L.NOT_IN_COMBAT) return end
	if not self.bar then self:BuildBar() end
	ns.moveMode = true
	if ns.Options and ns.Options.frame then ns.Options.frame:Hide() end
	if ns.DmgMeter and ns.DmgMeter.f then ns.DmgMeter.f.titleBtn:EnableMouse(false) end
	for which, f in pairs(self.frames) do
		f:EnableMouse(true)
		f:EnableMouseWheel(true)
		f.moveOverlay:Show()
		self:UpdateLabel(which)
	end
	self.bar:Show()
	-- gleich sichtbar machen, nicht erst beim nächsten Durchlauf
	if ns.HUD and ns.HUD.f then ns.HUD:Update(nil, nil) end
	if ns.Meter and ns.Meter.f then pcall(ns.Meter.Tick, ns.Meter) end
	if ns.DD and ns.DD.f then pcall(ns.DD.Tick, ns.DD) end
	if ns.DmgMeter and ns.DmgMeter.f then pcall(ns.DmgMeter.Tick, ns.DmgMeter) end
end

function MV:Stop()
	if not ns.moveMode then return end
	ns.moveMode = false
	for _, f in pairs(self.frames) do
		f:EnableMouseWheel(false)
		f.moveOverlay:Hide()
	end
	if self.bar then self.bar:Hide() end
	ns:ApplySettings()
	if ns.HUD and ns.HUD.f then ns.HUD:Update(nil, nil) end
	if ns.Meter and ns.Meter.f then pcall(ns.Meter.Tick, ns.Meter) end
	if ns.DD and ns.DD.f then pcall(ns.DD.Tick, ns.DD) end
	if ns.DmgMeter and ns.DmgMeter.f then pcall(ns.DmgMeter.Tick, ns.DmgMeter) end
end

function MV:Toggle()
	if ns.moveMode then self:Stop() else self:Start() end
end

-- Kampf beginnt: Verschieben beenden (die Fenster sollen dann wieder durchklickbar sein)
ns:On("PLAYER_REGEN_DISABLED", function() MV:Stop() end)
