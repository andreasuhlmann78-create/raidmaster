-- ThreatSentinel - Specs.lua
-- Skillung (Talente) aller Spieler in Gruppe und Schlachtzug prüfen und daraus die Rolle ableiten:
--   Krieger: Schutz = Tank, sonst DD          Paladin: Heilig = Heiler, Schutz = Tank, Vergeltung = DD
--   Druide: Wiederherstellung = Heiler, Gleichgewicht = DD, Wilder Kampf = Tank in Bärengestalt, sonst DD
--   Priester: Disziplin / Heilig = Heiler, Schatten = DD     Schamane: Wiederherstellung = Heiler, sonst DD
-- Eigene Talente liest das Addon direkt, andere Spieler per Betrachten (Inspect), einer nach dem anderen,
-- nur ausserhalb des Kampfs und in Reichweite. Spieler mit ThreatSentinel melden ihre Rolle selbst (Sync).
-- Retail-artige Clients (Spezialisierungen) nutzen die Rolle der Spezialisierung.

local ADDON, ns = ...
local L = ns.L

local SP = {}
ns.Specs = SP
table.insert(ns.modules, SP)

-- Rolle je Talentbaum (Reihenfolge der Bäume in Classic / TBC)
local TREE_ROLE = {
	WARRIOR = { "DAMAGER", "DAMAGER", "TANK" },
	PALADIN = { "HEALER", "TANK", "DAMAGER" },
	DRUID = { "DAMAGER", "FERAL", "HEALER" },
	PRIEST = { "HEALER", "HEALER", "DAMAGER" },
	SHAMAN = { "DAMAGER", "DAMAGER", "HEALER" },
}
local MIN_POINTS = 10          -- darunter (niedrige Stufe) keine Aussage
local STALE = 15 * 60          -- nach 15 Minuten neu prüfen (Umskillen)
local INSPECT_GAP = 2.5        -- höchstens eine Betrachtung alle 2.5 Sekunden
local INSPECT_TIMEOUT = 4

SP.byName = {}     -- Name -> { role, points = "x/y/z", t, src = "talents" | "spec" }
SP.mine = nil
SP.pending = nil   -- { guid, name, unit, t }
SP.lastInspect = 0
SP.failed = {}     -- Name -> Zeit des letzten Fehlschlags (nicht dauernd wieder versuchen)

local issecret = issecretvalue or function() return false end

------------------------------------------------------------
-- Talente lesen
------------------------------------------------------------
-- Punkte je Baum (isInspect = true: die gerade betrachtete Figur)
local function TreePoints(isInspect)
	local pts, total = {}, 0
	local okTabs, nTabs = pcall(GetNumTalentTabs, isInspect)
	if not okTabs or type(nTabs) ~= "number" or issecret(nTabs) then nTabs = 3 end
	for tab = 1, math.min(nTabs, 3) do
		local sum = 0
		local okN, n = pcall(GetNumTalents, tab, isInspect)
		if okN and type(n) == "number" and not issecret(n) then
			for i = 1, n do
				local ok, _, _, _, _, rank = pcall(GetTalentInfo, tab, i, isInspect)
				if ok and type(rank) == "number" and not issecret(rank) then sum = sum + rank end
			end
		end
		pts[tab] = sum
		total = total + sum
	end
	return pts, total
end

local function RoleFromPoints(class, pts, total)
	if total < MIN_POINTS then return nil end
	local best, bestN = 1, -1
	for tab = 1, 3 do
		if (pts[tab] or 0) > bestN then best, bestN = tab, pts[tab] or 0 end
	end
	local map = TREE_ROLE[class]
	return map and map[best] or "DAMAGER"
end

-- Retail-artig: Rolle aus der Spezialisierung (nil, wenn es keine gibt)
local function SpecRole(unit, isInspect)
	if isInspect then
		if not GetInspectSpecialization or not GetSpecializationRoleByID then return nil end
		local ok, id = pcall(GetInspectSpecialization, unit)
		if not ok or issecret(id) or type(id) ~= "number" or id <= 0 then return nil end
		local ok2, role = pcall(GetSpecializationRoleByID, id)
		if ok2 and not issecret(role) and role and role ~= "NONE" then return role end
		return nil
	end
	if not GetSpecialization or not GetSpecializationInfo then return nil end
	local ok, idx = pcall(GetSpecialization)
	if not ok or issecret(idx) or type(idx) ~= "number" or idx <= 0 then return nil end
	local ok2, _, _, _, _, role = pcall(GetSpecializationInfo, idx)
	if ok2 and not issecret(role) and role and role ~= "NONE" then return role end
	return nil
end

local function Read(unit, class, isInspect)
	local role = SpecRole(unit, isInspect)
	if role then return { role = role, points = "-", t = GetTime(), src = "spec" } end
	if not GetTalentInfo then return nil end
	local pts, total = TreePoints(isInspect)
	role = RoleFromPoints(class, pts, total)
	if not role then return nil end
	return { role = role, points = (pts[1] or 0) .. "/" .. (pts[2] or 0) .. "/" .. (pts[3] or 0), t = GetTime(), src = "talents" }
end

function SP:UpdateMine()
	local e = Read("player", ns.class, false)
	self.mine = e
	if e and ns.playerName then self.byName[ns.playerName] = e end
end

------------------------------------------------------------
-- Rolle abfragen
------------------------------------------------------------
-- Rolle laut Skillung: "TANK", "HEALER", "DAMAGER" oder nil (unbekannt)
-- Wilder Kampf (Druide): Tank in Bärengestalt, sonst DD
function SP:RoleOf(unit)
	local name = ns:FullName(unit)
	if not name or issecret(name) then return nil end
	local e = (UnitIsUnit(unit, "player") and self.mine) or self.byName[name]
	if not e then return nil end
	if e.role == "FERAL" then
		return ns:HasBearForm(unit) and "TANK" or "DAMAGER"
	end
	return e.role
end

function SP:Entry(name)
	return self.byName[name]
end

------------------------------------------------------------
-- Andere Spieler betrachten (einer nach dem anderen)
------------------------------------------------------------
local function InspectBusy()
	if InspectFrame and InspectFrame.IsShown and InspectFrame:IsShown() then return true end
	return false
end

function SP:NextCandidate()
	local now = GetTime()
	for _, u in ipairs(ns.groupUnits or {}) do
		if UnitIsPlayer(u) and not UnitIsUnit(u, "player") and ns.Safe(UnitIsConnected(u), false) then
			local name = ns:FullName(u)
			if name and not issecret(name) then
				local e = self.byName[name]
				local sync = ns.syncRoles[name]
				local fresh = (e and now - e.t < STALE) or (sync and now - sync.t < 90)
				local recentFail = self.failed[name] and now - self.failed[name] < 60
				if not fresh and not recentFail then
					local okC, can = pcall(CanInspect, u, false)
					local okD, near = pcall(CheckInteractDistance, u, 1)
					if okC and ns.Safe(can, false) and okD and ns.Safe(near, false) then return u, name end
				end
			end
		end
	end
end

function SP:Step()
	local db = ns.db
	if not db or not db.enabled or not db.specCheck then return end
	if not IsInGroup() then return end
	local now = GetTime()
	if self.pending then
		if now - self.pending.t > INSPECT_TIMEOUT then
			self.failed[self.pending.name] = now
			self.pending = nil
		else
			return
		end
	end
	if InCombatLockdown() or UnitAffectingCombat("player") or InspectBusy() then return end
	if now - self.lastInspect < INSPECT_GAP then return end
	local u, name = self:NextCandidate()
	if not u then return end
	local guid = UnitGUID(u)
	if not guid or issecret(guid) then return end
	self.lastInspect = now
	self.pending = { guid = guid, name = name, unit = u, class = select(2, UnitClass(u)), t = now }
	local ok = pcall(NotifyInspect, u)
	if not ok then
		self.failed[name] = now
		self.pending = nil
	end
end

ns:On("INSPECT_READY", function(_, guid)
	local p = SP.pending
	if not p or issecret(guid) or guid ~= p.guid then return end
	SP.pending = nil
	-- die Einheit kann sich verschoben haben (Gruppe umgebaut): nur lesen, wenn sie noch passt
	if UnitGUID(p.unit) ~= p.guid then return end
	local e = Read(p.unit, p.class, true)
	if e then
		SP.byName[p.name] = e
		ns:ClearRoleCache()
		if ns.Options and ns.Options.RefreshRoles then ns.Options:RefreshRoles() end
	else
		SP.failed[p.name] = GetTime()
	end
	-- nicht aufräumen, wenn der Spieler selbst gerade das Betrachten-Fenster nutzt
	if ClearInspectPlayer and not InspectBusy() then pcall(ClearInspectPlayer) end
end)

local function MineChanged()
	C_Timer.After(0.5, function()
		SP:UpdateMine()
		ns:ClearRoleCache()
		if ns.Sync then ns.Sync:Hello(true) end
	end)
end
ns:On("PLAYER_TALENT_UPDATE", MineChanged)
ns:On("CHARACTER_POINTS_CHANGED", MineChanged)
ns:On("ACTIVE_TALENT_GROUP_CHANGED", MineChanged)
ns:On("PLAYER_SPECIALIZATION_CHANGED", function(_, unit) if unit == "player" then MineChanged() end end)

function SP:Login()
	self:UpdateMine()
	C_Timer.NewTicker(1, function()
		local ok, err = pcall(SP.Step, SP)
		if not ok then ns:ReportError(err) end
	end)
end

-- Zeile für die Anzeige (Einstellungen > Gruppe)
function SP:ListText(max)
	local lines, n = {}, 0
	for _, u in ipairs(ns.groupUnits or {}) do
		if UnitIsPlayer(u) then
			n = n + 1
			if #lines < max then
				local name = ns:FullName(u) or "?"
				local role = ns:GetRole(u)
				local e = UnitIsUnit(u, "player") and self.mine or self.byName[name]
				local sync = ns.syncRoles[name]
				local src
				if UnitIsUnit(u, "player") then src = e and (e.src == "spec" and L.O_ROLE_SRC_SPEC or string.format(L.O_ROLE_SRC_TALENTS, e.points)) or L.O_ROLE_SRC_GUESS
				elseif sync and GetTime() - sync.t < 90 then src = L.O_ROLE_SRC_SYNC
				elseif e then src = e.src == "spec" and L.O_ROLE_SRC_SPEC or string.format(L.O_ROLE_SRC_TALENTS, e.points)
				else src = L.O_ROLE_SRC_GUESS end
				lines[#lines + 1] = string.format("%s: %s (%s)", name, L[role] or role, src)
			end
		end
	end
	if n > max then lines[#lines + 1] = string.format(L.O_ROLE_MORE, n - max) end
	return #lines > 0 and table.concat(lines, "\n") or L.NONE
end
