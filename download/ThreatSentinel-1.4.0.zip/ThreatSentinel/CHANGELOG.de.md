# ThreatSentinel – Änderungen

## 1.4.0
- Vorbereitet für WoW Forever: Das Spiel kann im Kampf Werte schützen („Secrets“). ThreatSentinel rechnet nie mit geschützten Werten, sondern schaltet auf einen Ersatzweg um, statt Lua-Fehler zu werfen:
  - Aggro: Bedrohungsstatus statt Prozente; Aggrometer und DD-Ansicht lassen die Werte vom Spiel anzeigen
  - Abklingzeiten: vom Addon ab dem eigenen Wirken gemessen (lernt die echte Dauer)
  - Spott widerstanden ohne Kampflog: Prüfung über die Bedrohung direkt nach dem Spott
  - Siegel der Wut, Rechtschaffener Zorn, Rüstung-zerreissen-Stapel und kontrollierte Mobs: aus den eigenen bzw. den Zaubern der Gruppe mitgezählt
  - Mob-Zuordnung ohne GUID: über die Plakette; Tank-Sync: andere Tanks an ihrem Ziel erkannt
  - Notfall-Hinweis: wenn möglich über die Lebensanzeige des Spiels
- Fehler in einem Teil halten nicht mehr das ganze Addon an
- Testzentrale: neue Spalte „WoW-Forever-Schutz“ (grün / gelb / rot je Funktion), „Forever-Sperren simulieren“ zum Ausprobieren aller Ersatzwege auf anderen Clients und „Bericht kopieren“

## 1.3.0
- Gehaltene Plaketten standardmässig mit 35 % Deckkraft und 80 % Grösse (einstellbar). Raidmarkierungen und Zauberbalken bleiben immer voll sichtbar.
- „Spott widerstanden“ nennt jetzt den bereiten Ersatz, z. B. „Spott widerstanden » Spöttischer Schlag!“ (Krieger: Spöttischer Schlag, danach Herausforderungsruf; Druide: Herausforderndes Gebrüll)
- Einmaliger Hinweis beim ersten Betreten einer Instanz, wenn die Spott-Taste noch nicht belegt ist
- Meldung in der Mitte: kleiner, Grösse und Höhe einstellbar, nach Wichtigkeit geordnet (eine wichtige Meldung wird nicht mehr von einer unwichtigeren verdrängt). „Aggro zurück“ standardmässig nur als Aufblitzen der Plakette.
- Neue eigene, kurze Töne – nicht mehr verwechselbar mit DBM/BigWigs oder dem Bereitschaftscheck
- Chat-Meldungen gehen standardmässig nur noch an die anderen Tanks (per Sync). Neu: Gruppe/Raid nur bei Bossen.
- Aggrometer: 100 % heisst jetzt immer „zieht jetzt die Aggro“ (110-%-Nahkampf- / 130-%-Fernkampf-Regel eingerechnet); „Gleich weg!“ statt „Vorsprung 0 %“
- Raidmarkierungen: Totenkopf vor Kreuz in der Lose-Liste, mit Symbol
- Voreinstellungen: Dezent, Standard, Laut
- Tank-Sync: kurzes Kürzel (z. B. „G“ für Grimbar) statt „übernommen von Grimbar“

## 1.2.3
- Paladin-Spott überarbeitet (Erkennung über Spell-IDs statt Namen):
  - TBC: Rechtschaffene Verteidigung wird auf den Mitspieler gewirkt, den der Mob angreift (Mob unter der Maus, sonst Ziel deines Ziels)
  - WoW Forever: Richturteil zählt nur mit aktivem Siegel der Wut als Spott, sonst zeigt die Plakette „Siegel der Wut fehlt“
  - Hand der Abrechnung entfernt (gibt es erst ab Wotlk)
- Diagnose zeigt die Spott-Art des Paladins und ob das Siegel der Wut aktiv ist

## 1.2.2
- Behoben: Das Addon lud in TBC Classic Anniversary 2.5.6 nicht (ein unbekanntes Ereignis brach das Laden ab – /ts und der Minimap-Knopf fehlten). Unbekannte Ereignisse werden jetzt übersprungen.
- Interface 20506 (TBC Classic Anniversary 2.5.6) ergänzt – das Addon gilt nicht mehr als veraltet
- Der Pfeil in „» Name (Rolle)“ wird jetzt richtig angezeigt (das alte Zeichen fehlte in der WoW-Schrift)
- Testzentrale: Vorschau-Plaketten in zwei Reihen, sie überlappen sich nicht mehr
- Testmeldungen bleiben stehen, wenn die Demo beendet wird

## 1.2.1
- Neuer Knopf **Unterstützen** (PayPal) in der Titelleiste des Einstellungsfensters und „Addon unterstützen“ auf der Seite Allgemein. Auch mit `/ts spenden`. Öffnet sich nie von selbst.

## 1.2.0
- Neue **Testzentrale** (Rechtsklick auf den Minimap-Knopf oder `/ts test`): Demo mit Vorschau-Plaketten, Live-Test solo, jede Meldung einzeln, Tank-Sync-Simulation und Diagnose
- Läuft auf Classic Era / Anniversary und TBC Anniversary sowie WoW Forever

## 1.1.0
- Erste Version: lose Mobs leuchten, gehaltene werden ausgeblendet, Spott auf Mauszeiger, Aggrometer, Tank-Sync
