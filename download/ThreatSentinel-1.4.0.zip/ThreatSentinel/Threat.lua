-- ThreatSentinel - Threat.lua
-- Herzstück: wertet für jede Namensplakette aus, wer den Mob hat, und steuert Anzeige und Warnungen.
--
-- Zustände eines Mobs:
--   IDLE       nicht im Kampf mit der Gruppe
--   HELD       du hältst ihn
--   WARN       du hältst ihn, aber ein DD ist nahe dran
--   OTHERTANK  ein anderer Tank hält ihn
--   PETHELD    ein Begleiter hält ihn (gilt als sicher)
--   CC         Mob ist kontrolliert und wird ignoriert
--   LOOSE      Mob greift einen DD oder Heiler an
--
-- WoW Forever kann Werte im Kampf schützen. Dann greifen Ersatzwege (siehe Kommentare),
-- und kein geschützter Wert wird je verglichen oder verrechnet.

local ADDON, ns = ...
local L = ns.L

local T = {}
ns.Threat = T
table.insert(ns.modules, T)

local mobs = {}
ns.mobs = mobs
ns.owners = {}

local active = false
local TICK = 0.25

local ROLE_ORDER = { HEALER = 1, DAMAGER = 2, PET = 3 }

function T:Login()
	for _, plate in ipairs(C_NamePlate.GetNamePlates() or {}) do
		local u = plate.namePlateUnitToken
		if u then mobs[u] = { unit = u } end
	end
	C_Timer.NewTicker(TICK, function() T:Tick() end)
end

------------------------------------------------------------
-- Hinweistext unter einer losen Plakette
------------------------------------------------------------
function T:BuildHint(unit, m)
	local db = ns.db
	m.hint, m.far, m.tauntCD = nil, false, 0
	if m.claimedBy then m.hint = string.format(L.CLAIMED, m.claimedBy) return end
	if m.muted then m.hint = string.format(L.OWNER, m.ownerName or "?") return end

	local spell = ns.tauntSpell
	if spell then
		m.tauntCD = ns.SpellCD(spell)
		-- Rechtschaffene Verteidigung zielt auf den Mitspieler: Reichweite zu ihm prüfen
		local rangeUnit = (ns.tauntMode == "friendly") and (unit .. "target") or unit
		if ns.SpellInRange(spell, rangeUnit) == false then
			m.far = true
			m.hint = L.TOO_FAR
			return
		end
	end
	-- nur wenn der eigene Anteil lesbar ist (sonst kein "Zerreissen reicht")
	if m.myPull and m.myPull >= db.deficitThreshold then
		if ns.class == "WARRIOR" then m.hint = L.DEFICIT_WARRIOR
		elseif ns.class == "DRUID" then m.hint = L.DEFICIT_DRUID
		else m.hint = L.DEFICIT_OTHER end
		return
	end
	if not spell then return end
	if ns.tauntMode == "seal" and not ns:HasSealOfFury() then
		m.hint = L.HINT_NO_SEAL
		return
	end
	if m.tauntCD > 0 then
		local other = ns.Sync:OtherTankReady()
		if other then
			m.hint = string.format(L.OTHER_TANK_READY, other)
		else
			m.hint = string.format(L.TAUNT_CD, math.ceil(m.tauntCD))
		end
	else
		m.hint = L.TAUNT_READY
	end
end

------------------------------------------------------------
-- Kontrolle und Rüstung zerreissen am Mob
------------------------------------------------------------
local function ReadMobAuras(unit, key)
	local cc, sunder, readable = false, 0, true
	for i = 1, 40 do
		local ok, name, count = pcall(ns.Aura, unit, i, "HARMFUL")
		if not ok or ns.IsSecret(name, "auras") then readable = false break end
		if not name then break end
		if ns.ccNames[name] then cc = true end
		if name == ns.sunderName then
			count = ns.Safe(count, 1)
			sunder = (type(count) == "number" and count > 0) and count or 1
		end
	end
	if readable then
		ns:Compat("mobAuras", "ok")
		return cc, sunder
	end
	-- Ersatz: aus den Zaubern der Gruppe und den eigenen Zerreissen mitgezählt
	ns:Compat("mobAuras", "fallback")
	return ns.Track:IsCC(key), ns.Track:Sunder(key)
end

------------------------------------------------------------
-- Wer hat den Mob? Rückgabe: tankUnit, myPull, maxOther, warnByStatus
------------------------------------------------------------
local function ReadThreat(unit)
	local tankUnit, myPull, maxOther, warnByStatus = nil, nil, 0, false
	local any, apiFailed, valuesSecret = false, false, false

	for _, u in ipairs(ns.groupUnits) do
		local ok, isTanking, status, scaled = pcall(UnitDetailedThreatSituation, u, unit)
		if not ok or ns.IsSecret(isTanking) or ns.IsSecret(status) then
			apiFailed = true
			break
		end
		if status then
			any = true
			if isTanking then
				tankUnit = u
				-- Status 2: Tank vorne, aber jemand anderes über 100 %
				if status == 2 then warnByStatus = true end
			end
			if ns.IsSecret(scaled, "threatValues") then
				valuesSecret = true
			elseif scaled then
				if UnitIsUnit(u, "player") then
					-- Anteil bis zum Zurückholen (100 = Aggro springt zu mir; 110/130-%-Regel eingerechnet)
					myPull = scaled
				elseif not isTanking and scaled > maxOther and not ns:IsSafeUnit(u) then
					maxOther = scaled
				end
			end
		end
	end

	if apiFailed then
		-- Ersatz 1: nur der Bedrohungsstatus (UnitThreatSituation)
		tankUnit, any = nil, false
		for _, u in ipairs(ns.groupUnits) do
			local ok, status = pcall(UnitThreatSituation, u, unit)
			if ok and not ns.IsSecret(status) and status then
				any = true
				if status >= 2 then
					tankUnit = u
					if status == 2 then warnByStatus = true end
				end
			end
		end
		ns:Compat("threat", any and "fallback" or "off")
		valuesSecret = true
	else
		if any then ns:Compat("threat", "ok") end
	end

	-- Ersatz 2: das Ziel des Mobs (wenn das Spiel gar keine Bedrohung liefert)
	if not tankUnit and not any and ns.Safe(UnitAffectingCombat(unit), false) then
		local tu = unit .. "target"
		if ns.Safe(UnitExists(tu), false) then
			for _, u in ipairs(ns.groupUnits) do
				if ns:SameUnit(u, tu) then tankUnit = u break end
			end
		end
	end

	if any then ns:Compat("threatValues", valuesSecret and "fallback" or "ok") end
	if valuesSecret then
		myPull, maxOther = nil, 0
	else
		warnByStatus = false
	end
	return tankUnit, myPull, maxOther, warnByStatus
end

------------------------------------------------------------
-- Auswertung eines Mobs
------------------------------------------------------------
function T:Evaluate(unit, m)
	local db = ns.db
	local now = GetTime()
	local prev = m.state
	local key, realGuid = ns:MobKey(unit)
	if key ~= m.key then
		m.key = key
		prev = nil
		m.looseSince = nil
		m.alerted = false
	end
	m.guid = realGuid and key or nil
	m.name = UnitName(unit)                         -- kann geschützt sein, wird nur angezeigt
	local mark = GetRaidTargetIndex and GetRaidTargetIndex(unit) or nil
	m.mark = ns.Safe(mark, nil)
	m.victim, m.victimRole, m.otherTank, m.claimedBy, m.tankOnIt = nil, nil, nil, nil, nil
	m.muted, m.ownerName, m.myPull = false, nil, nil

	local cc, sunder = ReadMobAuras(unit, key)
	m.sunder = sunder

	local state
	local canAttack = ns.Safe(UnitCanAttack("player", unit), true)
	local dead = ns.Safe(UnitIsDeadOrGhost(unit), false)
	if not canAttack or dead then
		state = "IDLE"
	elseif cc and db.ignoreCC then
		state = "CC"
	else
		local tankUnit, myPull, maxOther, warnByStatus = ReadThreat(unit)

		if not tankUnit then
			state = "IDLE"
		elseif UnitIsUnit(tankUnit, "player") then
			state = (maxOther >= db.warnThreshold or warnByStatus) and "WARN" or "HELD"
			ns.owners[key] = { name = ns.playerName, t = now }
		else
			local role = ns:GetRole(tankUnit)
			if role == "TANK" then
				state = "OTHERTANK"
				m.otherTank = ns:FullName(tankUnit)
				ns.owners[key] = { name = m.otherTank, t = now }
			elseif role == "PET" and db.petsSafe then
				state = "PETHELD"
			else
				state = "LOOSE"
				m.victim = UnitName(tankUnit)
				m.victimRole = role
				m.myPull = myPull
			end
		end
	end

	m.state = state

	if state == "LOOSE" then
		if prev ~= "LOOSE" then m.looseSince = now end
		m.claimedBy = ns.Sync:Claim(m.guid) or ns.Sync:ClaimByTarget(unit)
		if not m.claimedBy then m.tankOnIt = ns.Sync:TankTargeting(unit) end
		local owner = ns.owners[key]
		if db.sync and owner and owner.name ~= ns.playerName and ns.Sync:IsTank(owner.name)
			and (now - (m.looseSince or now)) < db.ownerGrace then
			m.muted = true
			m.ownerName = owner.name
		end
		self:BuildHint(unit, m)
		if not m.muted and not m.claimedBy and not m.alerted then
			m.alerted = true
			ns.Alerts:OnLoose(m)
		end
	else
		if prev == "LOOSE" and (state == "HELD" or state == "WARN") then
			ns.Alerts:OnRegain(unit, m)
		end
		m.alerted = false
		m.hint, m.far, m.tauntCD = nil, false, 0
	end
end

-- Reihenfolge der Raidmarkierungen: Totenkopf vor Kreuz vor den übrigen, ohne Markierung zuletzt
local MARK_ORDER = { [8] = 1, [7] = 2, [6] = 3, [5] = 4, [4] = 5, [3] = 6, [2] = 7, [1] = 8 }

local function SortLoose(a, b)
	local ma, mb = MARK_ORDER[a.mark or 0] or 9, MARK_ORDER[b.mark or 0] or 9
	if ma ~= mb then return ma < mb end
	local ra, rb = ROLE_ORDER[a.victimRole] or 9, ROLE_ORDER[b.victimRole] or 9
	if ra ~= rb then return ra < rb end
	return (a.looseSince or 0) < (b.looseSince or 0)
end
T.SortLoose = SortLoose

------------------------------------------------------------
-- Regelmässiger Durchlauf
------------------------------------------------------------
-- Fehler in einem einzelnen Teil sollen nie das ganze Addon anhalten
local function Try(fn, ...)
	local ok, err = pcall(fn, ...)
	if not ok then ns:ReportError(err) end
	return ok
end

function T:Tick()
	if not ns.db then return end
	ns:ClearRoleCache()
	Try(ns.DD.Tick, ns.DD)
	Try(ns.Meter.Tick, ns.Meter)

	local nowActive = ns:IsActive()
	if nowActive ~= active then
		active = nowActive
		if not active then
			for unit, m in pairs(mobs) do
				ns.Plates:Restore(unit)
				m.state = nil
				m.alerted = false
			end
			-- Testmeldungen (Schlüssel "test") stehen lassen
			local c = ns.Alerts.center
			if c and c.key ~= "test" then ns.Alerts:ClearCenter() end
		end
	end
	if not active then
		ns.HUD:Update(nil, nil)
		return
	end

	if ns.testMode then
		Try(ns.Test.Tick, ns.Test, mobs)
		return
	end

	local loose, heldOnMe = {}, 0
	for unit, m in pairs(mobs) do
		if Try(self.Evaluate, self, unit, m) then
			Try(ns.Plates.Update, ns.Plates, unit, m)
			if m.state == "LOOSE" and not m.muted and not m.claimedBy then
				loose[#loose + 1] = m
			elseif m.state == "HELD" or m.state == "WARN" then
				heldOnMe = heldOnMe + 1
			end
		end
	end
	table.sort(loose, SortLoose)
	Try(ns.Alerts.Evaluate, ns.Alerts, loose, heldOnMe)
	Try(ns.HUD.Update, ns.HUD, loose, ns.Alerts.extras)
end

function T:EvalOne(unit)
	if not active or ns.testMode then return end
	local m = mobs[unit]
	if not m then return end
	if Try(self.Evaluate, self, unit, m) then Try(ns.Plates.Update, ns.Plates, unit, m) end
end

------------------------------------------------------------
-- Ereignisse
------------------------------------------------------------
ns:On("NAME_PLATE_UNIT_ADDED", function(_, unit)
	mobs[unit] = { unit = unit }
	T:EvalOne(unit)
end)

ns:On("NAME_PLATE_UNIT_REMOVED", function(_, unit)
	ns.Plates:Restore(unit)
	-- Plakette wird für einen anderen Mob wiederverwendet: ihre Ersatz-Daten vergessen
	ns.Track:Forget("plate:" .. unit)
	ns.owners["plate:" .. unit] = nil
	mobs[unit] = nil
end)

ns:On("UNIT_THREAT_LIST_UPDATE", function(_, unit)
	if unit and not ns.IsSecret(unit) and mobs[unit] then T:EvalOne(unit) end
end)

ns:On("PLAYER_REGEN_ENABLED", function()
	local now = GetTime()
	for k, o in pairs(ns.owners) do
		if now - o.t > 30 then ns.owners[k] = nil end
	end
end)
