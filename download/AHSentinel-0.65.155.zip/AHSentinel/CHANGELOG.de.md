# AHSentinel (früher AH Analyzer Pro) – Änderungen (deutsch)

Diese Datei ist die deutsche Zusammenfassung für Discord. Die ausführliche englische Fassung steht in CHANGELOG.md.

## 0.65.155
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **AHSentinel prüft sich selbst:** Während du normal spielst, vergleicht das Addon im Hintergrund jede Buchung mit dem,
  was wirklich passiert ist: Händler, Post, Auktionshaus und Handel gegen die Gold-Änderung, Lager gegen Taschen/Bank/Post,
  das Verkaufen-Fenster nach jedem Klick, Speicher nach jedem Vollscan und die Gewinn-Anzeigen untereinander. Ergebnis im
  Testbericht (Abschnitt „Selbstkontrolle“) und in /ahs testroutine; im Details-Fenster nur eine Zeile, wenn etwas nicht
  stimmt. Du musst dir kein Gold mehr notieren. Tests T686–T693.

## 0.65.154
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Rechenkern Schritt 2:** Markt-Tabellen (täglich neu gerechnet) liegen jetzt im Addon und dienen als Vorwissen,
  solange die eigenen Zahlen noch fehlen. Die Kaufgrenze lernt je Preisstufe: bringt eine Stufe nicht den Mindestgewinn,
  wird dort gesenkt (nie über 90 % vom Wert). Ist ein Entzauber-Material in einer Welle (Preis fällt), steht beim
  Verkaufen „Welle: jetzt verkaufen“. Tests T683–T685.

## 0.65.153
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Rechenkern lernt mit ehrlicher Prüfung (Schritt 1):** Eine neue Lernschicht zählt jedes Verkaufsergebnis je
  Warengruppe und Preisstufe (wenige Fälle -> Richtung Vorwissen, alte Fälle zählen weniger). Jeder Fall wird vorher
  vorhergesagt und erst danach gezählt – so ist sichtbar, ob die Vorhersage wirklich trifft. Im Testbericht „MARKT-KERN“
  (Treffer, Grundlinie, Brier). Angezeigt wird noch nichts Neues. Tests T681, T682.
- **Abbruch-Grund:** Brichst du eine Auktion ab, zählt „unterboten“ jetzt nach dem günstigsten FREMDEN Angebot der letzten
  Suche (vorher war oft die eigene Auktion die günstigste -> nie „unterboten“). Testbericht: Klasse 80–100 % vor/ab
  0.65.128 getrennt. Test T680.

## 0.65.152
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Entzauber-Materialien je Gruppe:** In der Liste „je Item“ stehen Staub, Essenzen und Splitter eines
  Stufenbands zusammen in einer Zeile („Entzaubern 26–35“), die einzelnen Materialien zeigt der Tooltip. So zählt, ob sich
  das Entzaubern einer Gruppe lohnt – nicht ein einzelnes Material, das gerade in einer Welle gefallen ist. Test T679.
- Testroutine: Absatz-, Entzauber-, Sync- und Vollscan-Tests (T285, T289, T291, T223, T272, T310) laufen im Spiel jetzt
  unabhängig von deinen echten gelernten Daten.

## 0.65.151
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Handel mit Spielern gebucht:** Kaufst oder verkaufst du über das Handelsfenster, steht das jetzt in der Buchhaltung –
  gemessen aus Gold und Taschen (Herkunft bzw. Weg „Spieler“). Geschenke ohne Gold werden nicht als Verkauf gebucht. Test T678.
- **Material-Wellen:** Der Index rechnet nur noch ganze Tage – der angefangene heutige Tag (nur Morgenpreise) verfälscht ihn
  nicht mehr. Test T677.
- „Heute tun“ rechnet in kleineren Portionen (weniger Ruckeln). Testbericht: Kauf-Sicherheit Entzaubern nach den
  Gruppen-Regeln (20/25/30 %, kein Budget).

## 0.65.150
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Gold-Abstimmung als Geldfluss:** Jede Gold-Änderung wird jetzt gemessen und dem Ort zugeordnet (Auktionshaus, Post,
  Händler, Handel mit Spielern, Lehrer, Flugmeister, Beute, Quest, sonst). Abgestimmt wird gemessener Handels-Geldfluss
  gegen gebuchten Geldfluss – Geld ausserhalb des Handels (Quest, Beute, Lehrer, Flug) gilt als erklärt. Der Testbericht
  zeigt die grössten Lücken je Tag mit den Orten. Test T676.

## 0.65.149
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Weniger Ruckeln nach dem Vollscan:** Die Marktwert-Rechnung legt keine Hilfstabellen mehr je Item an. Nach einem Scan
  entsteht dadurch rund zwei Drittel weniger Speicher-Müll (im Test 65 MB -> 18–23 MB), es gibt weniger
  Speicherbereinigungen und der Speicher wächst je Scan kaum noch. Gleiche Werte wie vorher (6000 Items verglichen).
  Test T675.
- **Verkaufen:** Hinweise werden nicht mehr abgeschnitten – es stehen so viele da, wie ganz in 2 Zeilen passen, der Rest im
  Tooltip „(i)“. „Viel zu teuer – verkauft sich bei …“ statt „Preis 120x über Markt“.

## 0.65.148
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Händler gemessen statt angenommen:** Käufe, Verkäufe an den Händler (auch von Hand), Rückkäufe und Reparaturen werden
  aus dem Unterschied von Gold und Taschen gebucht – genau mit dem Betrag, der wirklich bezahlt wurde. Gescheiterte Käufe
  oder Reparaturen werden nicht mehr gebucht. Verkäufe an den Händler stehen jetzt in der Buchhaltung (Weg „Händler“) statt
  später als „fehlt“. Beim Schliessen des Händlers wird geprüft, ob alles aufgeht; ein Rest steht als „Händler unklar“.
  Tests T670–T674.
- **Verkaufen – Klick trifft das gesehene Item:** Wird die Taschen-Liste genau zwischen Zeigen und Klicken neu sortiert,
  wählt der Klick trotzdem das Item, das unter der Maus zu sehen war. Tests T667/T668 laufen jetzt immer (Ersatz-Taschen).

## 0.65.147
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufen – Einstellen-Feld aufgeräumt:** Kein Text überlappt mehr. Jede Zahl steht in ihrer eigenen Zeile:
  neu „Gewinn erwartet“ (grün/rot, grau solange das Addon die Verkaufsquote noch lernt) und „Verkaufschance“ – die Chance
  hängt nicht mehr an der Einstellgebühr.
- „Erlös nach Gebühren“ ist jetzt ehrlich: Verkaufspreis minus AH-Gebühr. Mögliche Rückläufe stecken nur in „Gewinn erwartet“.
- Hinweise stehen in einem festen Bereich über dem Knopf: höchstens 2 Zeilen, der wichtigste zuerst, alle weiteren im
  Tooltip „(i)“. Kürzer: „Händler zahlt mehr: 1c“, „Preis 120x über Markt – verkauft sich bei 25c“. Test T669.

## 0.65.146
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufen – immer der aktuelle AH-Stand:** Jedes gewählte Item wird sofort neu beim Server gesucht (vorne in der
  Warteschlange), auch wenn der letzte Preis erst wenige Minuten alt ist. Bis die Antwort da ist, steht die alte Liste
  grau mit „wird aktualisiert …“; bremst der Server, steht dort, in wie vielen Sekunden er wieder suchen lässt – die
  Suche läuft dann von selbst. Nach Einstellen, Abbrechen oder Kaufen des gewählten Items wird sofort neu gesucht.
- Jeder Klick in der Verkaufen-Liste steht im Protokoll (Item, vorher/nachher gewählt, Fehler, Titel). Test T668.

## 0.65.145
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufen – Item-Wahl:** Ein links gewähltes Item erscheint jetzt immer rechts, auch wenn ein einzelner Schritt
  (Preisvorschlag, Laufzeit, Taschen zählen) scheitert; der Fehler steht im Fehlerprotokoll mit Item und Schritt.
  Test T667.

## 0.65.144
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Lager-Abgleich sicherer:** Ware, die noch im Briefkasten liegen kann (AH-Kauf, Post von einer eigenen Figur,
  zurückgekommene Auktion), wird erst ausgebucht, wenn der Briefkasten danach gesehen wurde – frisch Gekauftes 7 Tage
  gar nicht. Was 0.65.140–0.65.143 vorschnell als „fehlt“ oder „verbraucht“ ausgebucht hat, kommt einmalig zurück ins Lager.
- Fehlbestand und an andere verschickte Ware stehen getrennt vom Eigenbedarf (Details-Fenster, Testbericht). Test T666.

## 0.65.143
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Briefkasten von Hand:** Post wird auch gezählt, wenn du sie selbst oder mit einem anderen Addon abholst –
  Rechnungen, Ablauf-Post (Anzahlung verfallen) und Ware im Briefkasten (zählt im Lager-Abgleich als vorhanden).
- **Verkaufs-Prognose:** Die Chance kommt jetzt aus deiner gezählten Quote je Preisstufe. Beim Abbrechen (auch über
  Blizzards Fenster) wird festgehalten, ob du unterboten warst und um wie viel. Tests T664, T665.
- Lager-Abgleich: Ware, die nirgends mehr liegt (Taschen, Bank, Auktion, Briefkasten), wird sofort ausgebucht.

## 0.65.142
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – ein Gewinn:** Der Kopf zeigt jetzt denselben Gewinn wie das Fenster „Details“ (kein zweiter
  „Gewinn mit Einkauf“ mehr). Ware ohne bekannten Einkauf steht grau als „Herkunft unbekannt“.
- **Details:** Rendite je Weg erst ab 30 Fällen als Zahl (vorher grau „lernt noch“); die Gold-Abstimmung warnt erst
  rot, wenn sie stimmig ist (vorher grau „wird abgeglichen“).

## 0.65.141
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Fehler behoben: „Crafting.lua:515 attempt to index field“ beim Berechnen der Herstellen-Liste.
- Testroutine schreibt beim Aufräumen keine echten Daten mehr (Gold-Stand, Vollscan-Messung).
- Test T659 läuft jetzt auch im Spiel (Sperren durch Briefkasten/Herstellen im Test aus).

## 0.65.140
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Lager-Abgleich korrigiert (wichtig):** Der Abgleich hat Ware in Taschen und Bank als „0 vorhanden“ gesehen. Jetzt
  zählt AHSentinel mit dem gespeicherten Abbild deiner Taschen und Bank (Bank beim letzten Öffnen). Solange die Bank nie
  gesehen wurde, wird nichts ausgebucht. Was 0.65.136–0.65.139 fälschlich als „verbraucht“ ausgebucht hat, kommt einmalig
  zurück ins Lager. Ware, die wirklich fehlt, wird als Abgang gebucht (nicht im Gewinn). Test T663.

## 0.65.139
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Rechenkern (Vorbereitung 0.66):** AHSentinel misst die Marktwellen je Stufenband (Entzauber-Materialien): „in der
  Welle“ (2 Tage stark gefallen), „durch“ (seitwärts) oder offen. Vorerst nur im Testbericht. Test T662.

## 0.65.138
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Spielkosten:** Reparaturen beim Händler werden als Spielkosten gebucht (nicht im Handelsgewinn) und
  erscheinen im Fenster „Details“; die Gold-Abstimmung geht damit besser auf. Reparatur aus der Gildenbank zählt nicht.
  Test T661.

## 0.65.137
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Herstellen:** Beim Herstellen wandern die Kosten der Zutaten (z. B. Fläschchen vom Händler) in das
  hergestellte Produkt – der spätere Verkauf zeigt den echten Gewinn.
- **Verschickte Post:** Ware an eine eigene Figur nimmt den Einkaufspreis mit; Ware an andere Spieler zählt als
  Eigenbedarf. Verschickte oder verbaute Händlerware gilt nicht mehr fälschlich als „verbraucht“. Test T660.

## 0.65.136
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – verbrauchte Händlerware:** Was du beim Händler gekauft und verbraucht hast (Essen, Wasser, Munition,
  Reagenzien), verschwindet aus dem Lager und zählt als Eigenbedarf – kein Phantom-Bestand mehr. Test T659.

## 0.65.135
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Händlerkäufe:** Käufe beim Händler werden jetzt gebucht (Einkauf mit Herkunft „Händler“, Einstand im
  Lager, z. B. für Herstellen). Die Gold-Abstimmung geht damit besser auf. Test T658.

## 0.65.134
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Details – Verkaufsquote je Verkaufskette:** Abbrechen und billiger neu einstellen zählt nicht mehr als „nicht
  verkauft“ – nur Ware, die abläuft und nicht neu eingestellt wird. Test T657.

## 0.65.133
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Knopf „Details“:** öffnet ein eigenes Fenster (Heute / Woche / Gesamt, Standard Gesamt) mit Handel
  (Gewinn), Handel pro Stunde (Gewinn ÷ Spielzeit ohne AFK, ab 2 Std.), Eigenbedarf, verfallene Anzahlung,
  Verkaufsquote, Rendite je Weg (Entzaubern als Summe aller Fälle) und Gold-Abstimmung. Sonst sieht die Buchhaltung
  aus wie bisher. Test T656.

## 0.65.132
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Anzahlung – genauer:** Eine Anzahlung gilt erst als verfallen, wenn die Ablauf-Post kommt oder du die Auktion
  abbrichst – nicht mehr nach fester Zeit. Eine spät gelesene Erstattung (auch nach Tagen) löst sie immer auf.
  Test T654.

## 0.65.131
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Eigenbedarf:** Gekaufte Ware, die du anlegst oder als Tasche einsetzt, ist keine Handelsware mehr:
  Sie verschwindet aus dem Lager und zählt nicht im Handelsgewinn (eigene Ausgabe „Eigenbedarf“, nur im Testbericht).
  Die Buchhaltung sieht aus wie bisher. Test T655.

## 0.65.130
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Anzahlung richtig gebucht:** Die Anzahlung beim Einstellen ist hinterlegt und drückt den Gewinn
  nicht mehr. Kommt sie beim Verkauf zurück, ist das kein Ertrag. Nur eine verfallene Anzahlung (Ablauf/Abbruch) ist
  Aufwand – im Zeitraum des Ablaufs. Bezeichnung wie im Spiel („Anzahlung“ aus dem Verkaufsfenster).
- Testbericht: hinterlegte und verfallene Anzahlungen. Test T654.

## 0.65.129
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Weniger Speicher:** Zwischenspeicher je Item (Marktwert, Absatz, Aufkauf) werden begrenzt und bei Bedarf alle
  10 Minuten geleert. Der Tempo-Test zeigt ihre Grösse. Test T653.

## 0.65.128
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufs-Prognose kennt den Preis:** Die Verkaufschance kommt jetzt aus deinen echten Verkäufen je Preisstufe
  (Preis zum Marktwert) – teurer eingestellt heisst kleinere Chance. Ohne gelernte Fälle bleibt es wie bisher.
- Testbericht: Verkaufsketten (abgelaufen/abgebrochen -> neu eingestellt -> verkauft zählt als ein Fall), mit Anzahl
  Einstellungen und Preis der letzten zur ersten Einstellung. Tests T651, T652.

## 0.65.127
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Phantom-Ware entfernt:** Ware, die nach der Reparatur noch im Lager stand, obwohl sie verkauft war,
  wird einmalig auf die Rechnungen umgebucht (Einkaufspreis dort, nicht im Lager). Neu: Abgleich Lager gegen Taschen,
  Bank und eigene Auktionen – liegt im Lager mehr, steht es im Testbericht (nur gemeldet, nichts still geändert).
- **Gold-Abstimmung** rechnet nur noch über den Zeitraum, für den es Gold-Stände gibt, über alle Figuren; vorher „lernt noch“.
- **Schnäppchen-Reiter** rechnet nicht mehr beim Öffnen, sondern im Hintergrund (sofort der letzte Stand).
- **Sniper/Entzaubern:** Kaufgrenze nie über 0,9 × Wert.
- Testroutine schreibt keine echten Gold-Stände mehr. Tempo-Test: Start-Teile mit Datei:Zeile, Tooltip-Messung mit
  Hinweis auf Speicherbereinigung, Ursache von Vollscan-Lücken, letzte Vollscan-Messung auch nach dem Reload.
- Testbericht: Käufe je Preisstufe, Entzauber-Zerlegung aus Summen. Tests T649, T650.

## 0.65.126
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Leere Listen:** Der Hinweis in einer leeren Liste (z. B. Markt > Entzaubern) steht jetzt innerhalb der Liste und
  bricht auf deren Breite um, statt quer über den Bildschirm zu laufen.
- **Fenster „Testbericht“:** Sehr lange Berichte werden in Teilen gezeigt (Pfeile oben rechts, „Teil x von y“), statt
  dass das Fenster leer/schwarz bleibt.
- **Verkaufs-Prognose ehrlicher:** Selbst abgebrochene Auktionen zählen nicht mehr als „nicht verkauft“ (weder Treffer
  noch Fehler, auch nicht beim Lernen). Beim Abbruch wird festgehalten, ob du unterboten warst. Der Testbericht zeigt
  die Trefferquote alt/neu und den Verkaufsanteil je Preisstufe.
- Test: Liste „Heute“ mit 5000 Items rechnet in kleinen Portionen (T647). Tests T645–T648.

## 0.65.125
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Weniger Ruckeln – Preisverlauf kompakt im Speicher:** Im Spiel hält AHSentinel den Preisverlauf jetzt als eine
  kompakte Zahlenliste je Item statt einer eigenen Tabelle je Preis-Eintrag (zehntausende Lua-Objekte weniger; die
  Speicherbereinigung hat viel weniger zu tun). Gespeichert wird genau wie bisher, alle Werte bleiben gleich.
- **Buchhaltung – Reparatur korrigiert:** Bei Rechnungen, die früher doppelt zu ausstehenden Verkäufen gebucht wurden,
  kommt der Einkaufspreis jetzt auf die Rechnung (die Ware ist verkauft) statt zurück ins Lager. Wer 0.65.124 schon
  gestartet hat, bekommt das einmal nachträglich korrigiert (Sicherung bleibt). Die Reparatur gilt erst als erledigt,
  wenn sie ohne Fehler durchgelaufen ist.
- Tempo-Test zeigt die Tabellen des Preisverlaufs. Tests T643, T644.

## 0.65.124
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Gewinn nur aus bestätigten Verkäufen:** Verkaufte, aber noch nicht per Post bezahlte Auktionen
  („ausstehend“) zählen nicht mehr im Gewinn, sondern stehen getrennt als „unterwegs“. Ausstehende Buchungen, die älter
  als 24 Std. ohne Rechnung sind, werden im Tooltip gemeldet.
- **Rechnungen in grossen Posten:** Eine Rechnung über z. B. 72 Stück bestätigt jetzt mehrere kleine ausstehende
  Buchungen desselben Items (über die Menge summiert) statt einen zweiten Verkauf zu buchen.
- **Einmalige Reparatur:** Ausstehende Buchungen, die eine früher neu gebuchte Rechnung schon enthält, werden als „durch
  Rechnung ersetzt“ markiert (nichts gelöscht, Sicherung bleibt). Kein Doppel mehr zwischen Rechnung und ausstehend.
- Testbericht: Gewinn alt/neu, Anzahl aufgelöster Buchungen, Gold-Abstimmung seit Stichtag. Tests T640–T642.

## 0.65.123
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Gemeinsame Befehlsliste:** Die Liste beim Tippen von `/ahs` kommt jetzt aus der gemeinsamen GoldSentinel-Datei
  (GoldSentinelCmdHint.lua), gleich für alle GoldSentinel-Addons. Bedienung bleibt gleich (Klick wählt, Tab/Shift+Tab,
  Enter führt aus); deine Zähler bleiben erhalten.
- Tempo-Test (`/ahs testroutine tempo`): Speicher von AHSentinel je Bereich (Grösse und Anzahl Tabellen) im Testbericht.
- Tests T638, T639.

## 0.65.122
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzaubern – endgültige Regeln je Materialgruppe:** 20 % Mindestgewinn für Gruppen, die deine Ergebnisse belegen, und
  auch für noch nicht gemessene Gruppen, solange die Entzauber-Tabelle zu deinen Messungen passt (±10 %); 25 % nur,
  wenn die Tabelle abweicht; 30 % für Gruppen, die gemessen schlecht laufen. Kein Budget-Deckel je Gruppe. Im Spiel
  siehst du nur, ob es sich lohnt – die Regeln stehen nur im Testbericht.
- Test T637 angepasst.

## 0.65.121
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzauberwert war viel zu stark korrigiert (wichtig):** Die Materialpreis-Korrektur (×0,57) nahm den Median eines
  Zufallsergebnisses – meist billiger Staub, selten teure Essenz oder Splitter. Im Schnitt stimmte die Vorhersage
  (≈ 0,96). Jetzt rechnet die Korrektur mit Summen (gesamte Beute / gesamte Vorhersage, ab 30 Fällen) – „Lohnt bis“,
  Sniper-Max und Gewinn-Zeile sind wieder realistisch. Auch die gelernte Sicherheitsmarge beim Entzaubern nutzt Summen.
- **Mindestgewinn beim Entzaubern je Materialgruppe:** 20 % für Gruppen, die deine eigenen Ergebnisse belegen
  (≥ 30 Käufe, Gewinn gesamt ≥ 20 %), 25 % für noch nicht belegte Gruppen (und höchstens 20 % des Entzauber-Budgets je
  Gruppe zum Kennenlernen), 30 % nur für Gruppen, die gemessen schlecht laufen. Waffen und Rüstung desselben
  Stufenbands zählen zusammen.
- Testbericht: Gewinn gesamt je Gruppe (Beute / Einsatz) und der geltende Mindestgewinn.
- Tests T589, T637.

## 0.65.120
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Keine Sync-Flut mehr:** AHSentinel füllt die gemeinsame Sende-Warteschlange nie über 10 Nachrichten; der Rest wartet
  in einem eigenen Ausgang und geht nach und nach raus (während der Testroutine wartet er). Das verringert auch das
  Ruckeln nach einem Vollscan.
- **Markt-Reiter öffnet sofort:** „Heute“ rechnet beim Öffnen nicht mehr (vorher über 1 Sekunde), sondern im Hintergrund
  und erscheint, sobald es fertig ist.
- **Schnelleres Einloggen/Reload:** Der kompakte Preisverlauf wird gleich nach dem Laden in kleinen Portionen entpackt
  statt auf einmal; nichts kann verloren gehen (Ausloggen während des Entpackens behält die gepackten Daten).
- Sniper-Test: „keine Treffer“, weil der Markt nichts Passendes hatte, ist jetzt SKIP mit Gründen; die Sync-Warteschlange
  zeigt ihre Zusammensetzung. Tempo-Test: die letzte Vollscan-Messung überlebt einen Reload.
- Tests T634–T636.

## 0.65.119
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzaubern braucht mindestens 30 % Gewinn (bisher 20 %):** Deine eigenen Ergebnisse zeigten zu viele Entzauber-Käufe
  ohne Gewinn. „Lohnt bis“, das Sniper-Max für Entzauber-Ziele, die Markt-Ansicht und der Tooltip rechnen jetzt alle mit
  denselben 30 % (Wert ÷ 1,3). Eine höhere Einstellung gilt weiter; der allgemeine Mindestgewinn beim Verkaufen bleibt.
- Test T633.

## 0.65.118
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Neuer Testteil `/ahs testroutine tempo`:** misst die Tempo-Ziele im Spiel – Tooltip-Rechenzeit, Reiter wechseln,
  Sniper-Reaktion, Kauf per Raste, längstes Bild bei offenem Auktionshaus, Einloggen/Reload und Speicher beim Vollscan –
  und schreibt sie in den Testbericht (Feld „tempo“), bei einem verfehlten Ziel mit der langsamen Stelle.
- Vollscan: Das Diagnose-Protokoll zeigt jetzt, ob langsame Lese-Portionen von der Speicherbereinigung kommen.
- Tests T625–T632.

## 0.65.117
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Budget nach dem Zurücksetzen verdoppelt:** „Zähler zurücksetzen“ setzt das Budget jetzt immer auf den
  eingestellten Betrag zurück (eine Nachfüllung bleibt nicht mehr drin).
- **Ein „bester Weg“ für alle Zahlen:** Gewinn-Zeile, „… bringt mehr“ und „Max über Verkaufswert – jeder Kauf verliert
  ca. …“ kommen jetzt alle aus derselben Rechnung (Verkaufen, Entzaubern, Händler nach Gebühren) – keine widersprüchlichen
  Zahlen mehr.
- Die Rechen-Zeile „Mit … Budget kauft der Sniper höchstens …“ ist aus dem Ziel-Tooltip weg.
- **Sniper und Scrollen:** Der Sniper misst, ob der Server Suchen ohne Tastendruck beantwortet. Wenn nicht, steht oben
  „Zum Suchen und Kaufen scrollen · letzte Suche vor 12 s“, und nach 10 s ohne Scrollen kommt eine leise Erinnerung.
- Testbericht: Zusammensetzung der Sync-Warteschlange je Präfix.
- Tests T621–T624.

## 0.65.116
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **„Lohnt bis“ beim Entzaubern war zu tief:** Die Materialpreis-Korrektur (z. B. ×0,57) wurde zweimal gerechnet – einmal
  im Wert und noch einmal in der gelernten Sicherheitsmarge (beide massen denselben Fehlbetrag deiner eigenen
  Entzauberungen). Die gelernte Marge deckt jetzt nur noch ab, was die Korrektur nicht schon erklärt. „Lohnt bis“ (Sniper-
  Max für Entzauber-Ziele, Kaufgrenzen) ist wieder Wert ÷ (1 + Mindestgewinn), z. B. 10s -> 8s 33c statt 5s 90c.
- Test T620.

## 0.65.115
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Abnahme im Spiel:** `/ahs testroutine sniper` (Auktionshaus offen). Zuerst fragt ein eigenes Fenster, ob EIN
  echter Testkauf von 1 Stück bis 5c erlaubt ist – gekauft wird nur mit deiner Mausrad-Raste bzw. Taste; „Nein“
  überspringt ihn. Danach beobachtet die Testroutine (Kaufen gesperrt) den Sniper 2 Minuten: Treffer bleiben stehen (S1),
  Zähler und Budget nur bestätigte Käufe (S2), Pause sichtbar und „fortsetzen“ wirkt (S3), Bilder/s, längster Frame und
  Sync-Warteschlange (S5) sowie die Reaktionszeit (S6). Das Ergebnis kommt wie die anderen Teile in den Testbericht.
- Tests T613–T619.

## 0.65.114
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper verliert keinen echten Kauf:** Schickt der Server keine Antwort, prüft der Sniper nach 30 s dein Gold (Gold um
  den Preis weniger -> gezählt). Eine späte Bestätigung wird noch gezählt (bis 5 Min.). Im modernen Auktionshaus macht
  eine Fehlermeldung ohne Angebot (z. B. von einer Suche) den Kauf nicht mehr zum Fehlschlag.
- **Live-Tooltip (neu):** Über einem Angebot (Sniper-Liste, Einkauf, Schnäppchen, Zeile im alten Auktionshaus) steht EINE
  Zeile „Gewinn: −44c / Stück“ (rot) bzw. „Gewinn: +2s 61c / Stück“ (grün) – mit dem Preis genau dieses Angebots und dem
  besten Weg nach Gebühren (Verkaufen, Entzaubern, Händler). Sie ersetzt „Entzaubern lohnt …“ und „Lohnt bis …“, alles
  andere bleibt. In den Taschen rechnet sie mit dem Marktwert. „Materialpreise korrigiert ×…“ nur noch mit Shift.
- **Einkauf:** Mit Qualitätsfilter erscheinen Items, deren Daten erst später geladen wurden, ohne neue Suche.
- **Testroutine:** Sync-Nachrichten während des Laufs werden danach angewendet (kein Sandbox-Fehler, nichts geht verloren).
- **Flip-Liste:** Liste und Detail rechnen immer mit demselben Stand (kein „FLIP-WIDERSPRUCH“).
- Diagnose: „LANGSAM“ nennt den längsten Einzelschritt (Datei:Zeile); der Vollscan-Test wartet bis 300 s.
- Tests T602–T612, T597 prüft die hochgeladenen Felder.

## 0.65.113
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper zählte gescheiterte Käufe (wichtig):** Ein gesendeter Einzelkauf zählt – und braucht Budget – erst, wenn der
  Server ihn bestätigt. Gescheiterte oder unbeantwortete Käufe zählen nicht mehr (vorher zeigte ein Ziel nach 3 echten
  Käufen "32/35 gekauft" und suchte nicht mehr). Solange ein Kauf auf die Antwort wartet, steht "(+1 gesendet)" in der
  Zeile. Altes Auktionshaus: jede Antwort des Servers gehört zum ältesten offenen Kauf.
- **Sniper-Pause sichtbar:** Nach 3 gescheiterten Käufen beim gleichen Item zeigen Zielzeile und Statuszeile "pausiert
  bis 19:58 – 3 Käufe gescheitert" (Tooltip mit dem Fehlertext des Servers), dazu der Knopf "jetzt fortsetzen".
- **Sniper-Liste:** 3 Fehlschläge hintereinander leeren die Trefferliste nicht mehr – sie bleibt als veraltet stehen,
  bis neue Ergebnisse da sind.
- **Sniper-Ziel über Verkaufswert:** Beim Anlegen kommt einmal eine deutliche Warnung im Chat (mit Warnton).
- Tests T598–T601.

## 0.65.112
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Gelernter Absatz-Faktor behoben:** seit 0.65.111 stand jeder Gruppenfaktor auf 1,00, weil die Schätzung mit sich
  selbst verglichen wurde. Die unabhängige Schätzung wird wieder getrennt behalten.
- **Lagerwert:** das Lager wird zum erzielbaren Preis bewertet – nie über dem Marktwert (der Wert war durch einen
  einzelnen hohen Wiederverkaufspreis um das 12-Fache gesprungen). Der Testbericht nennt die grössten Lagerposten.
- **Weniger Ruckeln im Vollscan:** die Verfolgung der Auktionen legt keine Zeichenkette und keine Tabelle mehr je
  Auktion an (die Speicherbereinigung verursachte Stocker bis 821 ms).
- **Einkauf:** der Qualitätsfilter blendet jetzt auch Items aus, deren Qualität noch nicht geladen ist (weisse/graue
  Teile rutschten durch).
- **Tooltip:** ein kleiner Gewinn unter dem Mindestgewinn heisst jetzt "Entzaubern: nur +86c (+9 %) – unter dem
  Mindestgewinn 20 %", ohne grünen Haken beim Wert.
- Testbericht: Abschnitt Markt-Kern auch in den hochgeladenen Feldern. Tests T592–T597.

## 0.65.111
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

Sofort-Korrektur verfälschter Zahlen (dein Entscheid):
- **Entzauberwert = erzielbarer Preis:** deine eigenen Entzauberungen haben gemessen, dass die Materialpreise ~43 % zu
  hoch angenommen waren (Beute/Vorhersage 0,60). Der Entzauberwert wird jetzt je Gruppe mit diesem gemessenen Faktor
  korrigiert – für "Lohnt bis", Sniper, Markt, Tooltip und Heute tun. Der Tooltip zeigt "Materialpreise korrigiert ×0,57".
- **Absatz je Tag: gemessen vor geschätzt** überall; eine unplausible Schätzung ohne Messung steht jetzt als unbekannt
  statt als zu hohe Zahl.
- Tests T240 (Einzahlung bei Nicht-Verkauf) und die Sortierprüfung von Heute tun behoben; Tests T589–T591.

## 0.65.110
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

Ruckeln und Zuverlässigkeit:
- **Kompakter Preisverlauf (PD7, dein Entscheid):** Einträge älter als 48 Std. werden kompakt gespeichert – im Spiel ist
  der Preisverlauf genau wie vorher. Sicherung: beim ersten Mal bleiben die alten Einträge zusätzlich erhalten; beim
  nächsten Einloggen wird alles geprüft, erst dann gilt das kompakte Format. Schlägt eine Prüfung fehl, bleiben deine
  Daten wie sie waren und du bekommst eine Meldung. "/ahs pd7" zeigt den Stand, "/ahs pd7 zurück" schaltet es ab,
  solange die Sicherung da ist.
- **Weniger Ruckeln:** Arbeit nach dem Scan (Markt-Kern-Nachprüfung, Rhythmus, Prognose, Material-Protokoll, Prüfung
  echter Daten) läuft in kleinen Portionen im Hintergrund; "Heute tun" teilt seine Abschnitte in Portionen; die
  Scan-Auswertung pausiert je Zeile.
- **Sniper:** jeder gescheiterte Kauf steht mit der Server-Meldung im Protokoll; nach 3 Fehlschlägen hintereinander sucht
  der Sniper frisch, statt eine alte Liste abzuarbeiten. Entzauber-Ziele zeigen grau "lernt noch"/"Weg gesperrt".
- **Verkaufschance:** die angezeigte Prozentzahl wird mit dem tatsächlich Verkauften korrigiert (z. B. 98 % vorhergesagt,
  30 % verkauft -> 30 %) und bis zur Kalibrierung "lernt noch (nicht kalibriert)" markiert.
- **Protokoll:** Fehler der Testroutine werden getrennt gezählt; Fehler-Einträge werden nicht mehr aus dem Protokoll
  verdrängt.
- "/ahs testroutine echt" meldet nur einmal; Tests T231, T253 und T52 hängen nicht mehr von deinen echten Lerndaten ab,
  T52 versucht nie ein Abbrechen.
- Tests T584–T588.

## 0.65.109
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

Behebt falsche Zahlen aus dem grossen Test von 0.65.108:
- **Materialien nach dem Vollscan:** ein echter Preisrutsch (z. B. Levelwelle) wurde als "unbestätigtes Lockangebot"
  gespeichert, die Materialien blieben "geschätzt, unsicher". Ein Vollscan mit mindestens 5 Stück auf der günstigsten
  Stufe gilt jetzt als echter Preis. Das Diagnose-Protokoll nennt nach jedem Scan je Entzauber-Material Quelle, Alter
  und Grund.
- **Tooltip:** kein grünes Häkchen bei "Entzaubern", wenn die Materialpreise unsicher sind (grau "Entzaubern: unsicher").
- **Keine Schein-Flips:** ein Wiederverkaufspreis über dem Marktwert zählt nur bei voller Leiter (≥ 3 Stufen oder
  ≥ 5 Stück) und Absatz von mindestens 1 je Tag – sonst höchstens der Marktwert.
- **Freigaben überall:** "Heute tun" zeigt lernende oder gesperrte Wege nur grau unten ("lernt noch (n von 20)") bzw.
  gar nicht; Gewinn über 300 % steht als "unplausibel". Der Tooltip zeigt "Entzaubern lohnt sich" grau, solange der Weg
  noch lernt.
- **Abbrüche:** AUCTION_CANCELED mit unbekannter/fremder Auktions-ID (z. B. beim gescheiterten Sniper-Kauf) gilt nicht
  mehr als eigener Abbruch; dieselbe ID nur einmal.
- **Buchhaltung:** ist mehr als 30 % des Erlöses ohne Einkauf (Kostenbasis fehlt), zeigt der Kopf gross "Gewinn mit
  Einkauf" und klein gelb "dazu ohne Einkauf … – Kostenbasis prüfen". Der Testbericht listet diese Items mit
  vermuteter Herkunft.
- Tests T580–T583 (T-D1, T-TT1317, T-MH1310, T-BH1307); T223, T248, T431, T432 jetzt unabhängig von deiner echten gelernten Marge.

## 0.65.108
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Markt-Reiter "Entzaubern" rechnet jetzt dasselbe "Lohnt bis"** wie Tooltip, Einkauf, Sammelkauf, Sniper und API
  (Zeile und Detailzeile). Die Option "Mindestgewinn" ist nur noch ein Filter. Sniper-Entzauberziele stehen immer genau
  auf "Lohnt bis" (Chat-Meldung erst ab 5 % Änderung).
- **Markt-Kern misst richtig:**
  - Eigene Auktionen: Abbruch- oder Verkaufsmeldung, die vor der neuen Auktionsliste kommt, geht nicht mehr verloren.
    "Neu eingestellt" wird nur aus wirklich neuen Auktionen geraten (mehrere gleiche Stapel verwirren nicht mehr).
  - Entzauber-Empfehlungen werden am Materialwert nach 24 Std. geprüft, Händler-Empfehlungen am bestätigten
    Händlerpreis (nicht mehr am AH-Preis des Teils).
- **Freigaben (Teil D) im Markt-Reiter:** ein Weg unter 60 % Treffern wird ausgeblendet ("Weg … gesperrt (Treffer
  n %)"); ein Weg mit weniger als 20 Fällen zeigt seine Zeilen grau "lernt noch (n von 20)"; Flippen, Lücken und
  Überfüllt bleiben grau, bis 30 eigene Verkäufe gemessen sind. Gemessen wird im Hintergrund weiter.
- Selbsttest "Plausibilität (Ü3)": keine unplausible Zeile darf als Empfehlung erscheinen.
- Tests T573–T579 (T-MA1b/c, T-MA2c, T-FG1–T-FG3, T-RK2c).

## 0.65.107
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Ein "Lohnt bis" überall (Entzaubern):** Tooltip, Einkauf-Markierung "[Entzaubern lohnt]", Warnschutz,
  Sniper-Entzauberziele, Markt-Reiter "Entzaubern", die Kaufgrenze im Markt, der Sammelkauf und die API rechnen jetzt
  mit EINER Rechnung. Vorher konnten Tooltip und Markt für dasselbe Item zwei verschiedene Grenzen zeigen.
  - Lohnt bis = Netto-Wert × die strengere Grenze aus (1 / (1 + Mindestrendite)) und (1 − gelernte Sicherheitsmarge).
    Ohne Lernen: 10 % Marge unter 10 echten Entzauberungen.
  - Der Sammelkauf zieht die Mindestrendite nicht mehr ein zweites Mal ab (gekauft wird bis "Lohnt bis").
  - Selbsttest: "Ein Lohnt bis je Item" prüft 20 gescannte Items – zwei verschiedene Werte = Fehler.
- **Unplausible Vorschläge** (Gewinn über 300 %) stehen im Markt-Reiter als "unplausibel: …" und zählen nicht als
  Empfehlung.
- **Sniper: Budget aufgebraucht -> Abfrage.** Ist das Budget eines Ziels aufgebraucht und kommt ein kaufbarer Treffer,
  kauft der nächste Kauf-Druck (Taste/Mausrad) nicht, sondern fragt: "Budget von X aufgebraucht (n Stück gekauft).
  Weiter kaufen? Budget um X auffüllen." "Ja" (Enter) füllt um das ursprüngliche Budget auf (höchstens so weit das Gold
  reicht), der nächste Dreh kauft. "Nein" ändert nichts. Die Frage kommt jedes Mal neu, wenn das aufgefüllte Budget
  wieder aufgebraucht ist. Max-Preis und Menge bleiben.
- **Eine Befehlstabelle:** der /ahs-Befehl arbeitet nur noch aus der Befehlsliste – jeder Befehl, den er versteht, steht
  in /ahs hilfe und in der Liste beim Tippen (neu dort: doppelt, resetscan, messreihe, ahdebug, ah).
- **API:** WorthUpTo liefert als 4. Wert die Sicherheit 0–1 (nil = lernt noch) und als 5. Wert den Stückpreis; der 1.
  Wert bleibt die Summe für qty. MaterialCost rechnet über die Preisleiter für die benötigte Menge. Trend-Wörter von
  MarketState in API.md festgehalten.
- **Tests:** "/ahs testroutine echt" prüft die Grundregeln an deinen eigenen Daten (nur lesen: Vorschläge, ein
  "Lohnt bis", Sniper-Budget); läuft auch still nach jedem Vollscan und schreibt Verletzungen ins Diagnose-Protokoll
  ("GRUNDREGEL VERLETZT"). Neue Tests für die Freigaben des Markt-Kerns (59 % gesperrt, 61 % frei, 19 Fälle lernt) und
  für Auktions-Post mit beliebigem Absender.
- Tests T556–T572 (T-RK2a/b, T-Ü3b, T-SB1–T-SB6, T-BL1/5/6, T-API-PM2/PM3, T-TU5, T-TU7, T-BP-1113-1).

## 0.65.106
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Markt-Kern, Stufe 1 "Vertrauen" (Messungen für den neuen Markt-Reiter):**
  - Jede gezeigte Kauf-Empfehlung (Flip, Händler, Entzaubern aus dem Markt-Reiter, Sniper-Treffer) wird gemerkt und
    nach 24 Std. mit dem Scan nachgeprüft: Trefferquote und mittlerer Fehler je Weg. Ein Weg mit mindestens 20 Fällen
    und unter 60 % Treffern wird automatisch gesperrt (Protokoll "WEG GESPERRT"); unter 20 Fällen "lernt noch".
  - Verkauf oder Abbruch: verschwindet eine eigene Auktion mit langer Restzeit, rät die Erkennung "verkauft" oder "neu
    eingestellt"; die echte Ursache (Verkauf / eigener Abbruch) ergibt die Fehlerquote – Grundlage für die Freigabe
    der Absatz-Zahlen.
  - Händlerpreise: wie viele vom Spiel bestätigt wurden und wie viele von der gemerkten Tabelle abwichen.
  - Neuer Testbericht-Abschnitt "MARKT-KERN" mit diesen Zahlen, verfehlte Grenzwerte als "VERFEHLT".
- Tests T550–T555 (T-MA1–T-MA3, T-Ü1–T-Ü3).

## 0.65.105
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Kein zu billiges Einstellen mehr, wenn der Markt um 125–150 % steigt.** Bei voller Preisleiter (≥ 3 Angebote oder
  ≥ 5 Stück) liegt der Vorschlag immer knapp unter dem günstigsten Angebot; der alte gelernte Preis gilt nur noch bei
  einzelnen Ausreissern.
- **Warnschutz (Standard an):** Klick auf "Einstellen" mit einem Preis mehr als 10 % unter dem günstigsten Angebot (volle
  Leiter), mehr als 25 % unter dem Marktwert oder unter Händler-/Einkaufspreis: nichts wird eingestellt – Ton der
  Schlachtzugswarnung, der Knopf blinkt rot, ein Fenster fragt: "Preis anpassen (…)" (Enter) / "Trotzdem einstellen" /
  "Abbrechen" und zeigt, wie viel du verschenken würdest. Serie und Neu einstellen werden genauso gestoppt. Kaufen über
  dem Max-Preis des Ziels, über "Lohnt bis" oder mehr als 25 % über dem Marktwert (ohne Aufkauf) warnt ebenfalls –
  innert 10 s nochmal drücken = trotzdem kaufen. Optionen: Warnschutz an/aus, Ton an/aus. Jede Warnung steht im
  Protokoll (WARNSCHUTZ).
- Tests T542–T549 (T-AB4d, T-WS1–T-WS6).

## 0.65.104
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Befehlsliste beim Tippen von "/ahs": Mausklick wählt einen Befehl aus, Enter führt ihn aus.** Die Liste bleibt nach
  dem Klick offen, das Chatfeld bekommt den Fokus zurück, oben steht "Enter = /ahs …". Drückst du dann Enter mit dem
  getippten Anfang (z. B. "/ahs ent"), läuft der ausgewählte Befehl. Eine Auswahl gilt 10 s; Tab wählt den nächsten
  Eintrag. Das Chatfeld wird weiterhin nie beschrieben (kein Taint).
- Tests T537–T541 (T-CH1–T-CH5).

## 0.65.103
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzauber-Grenzen müssen stimmen:** "[Entzaubern lohnt]" im Einkauf nur, wenn der Preis höchstens "Lohnt bis"
  (Mindestgewinn) ist, mit frischen Materialpreisen – bisher schon, sobald der Wert über dem Preis lag.
- **Sniper-Ziele aus Entzaubern folgen der Grenze:** ändert sich "Lohnt bis" um mehr als 5 % (neue Materialpreise), wird
  der Höchstpreis angepasst und einmal im Chat gemeldet.
- **Referenz-Nachrechnung in der Testroutine:** die Gruppen 26–30, 31–35 und 36–40 werden unabhängig aus den
  Scan-Preisen nachgerechnet (günstigstes − 1c × Chance × Ø Menge) und mit dem Wert verglichen, den das Addon benutzt;
  über 5 % Abweichung = FEHLER mit Material, Quelle und Alter. Eine Berichtszeile je Gruppe.
- **Händlerpreise nach dem Hotfix vom 10.11.:** zuerst der Händlerpreis des Spiels; die gemerkte Tabelle ist nur
  Rückfall und wird nachgeführt, wenn das Spiel etwas anderes sagt. Händler-Flips nur mit vom Spiel bestätigtem Preis.
- **Mindest-Einzahlung 1c (angekündigt für 17.11.):** wird beim Einstellen automatisch gemessen – nichts fest eingebaut.
- **AHSentinel.API:** neu `WorthUpTo(itemID[, qty])` (dasselbe "Lohnt bis" wie im Tooltip) und `MarketState(itemID)`
  (normal / Aufkauf / Flut / dünn / alt) für ProfessionSentinel.
- Tests T530–T536 (T-HP1, T-HP2, API-PM, T-ST1–T-ST3).

## 0.65.102
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Meine Auktionen: Verkaufte verschwinden nach "Aktualisieren"** (und beim Öffnen der Ansicht); neu Verkauftes bleibt
  bis zum nächsten Klick sichtbar. Der Kopf zählt weiter alle Verkauften. Neuer Knopf "Verkaufte: an/aus".
- **Verkaufs-Vorschlag bei einem einzelnen teuren Angebot** (dünne Leiter ≥ 150 % des Marktwerts): Marktwert statt
  knapp unter dem Ausreisser. "Billiger einstellen" erscheint nie, solange die Konkurrenz über dem Marktwert liegt.
- **Händler-Flips:** ein Händlerpreis über dem Doppelten des Marktwerts gilt als falsch (z. B. Eisengranate) – kein
  Händler-Flip damit.
- **Umfassende Tests (TU1–TU4, TU6):** jede Marktlage (normal, Aufkauf, Ausreisser, Flut, dünn, leer, alt,
  fallend/Spitze, falscher Händlerpreis, neu eingestellt) läuft durch Verkaufs-Vorschlag, Leiter-Erkennung, Hinweise,
  Entzauber-Kaufpreis und Händler-Prüfung; Abläufe wie ein Spieler (getippter Preis, drei Sniper-Ziele); Standardwerte
  leerer Felder (Liste im Testbericht); Grundregeln mit 1000 Zufalls-Leitern und Zufallsfolgen in der Buchhaltung. Der
  Testbericht hat je Bereich (TU1–TU7) eine Zeile und "Regressionen: n von m vorhanden". Tests T513–T529.
- **Tests ausserhalb des Spiels (TU9):** `tests/run_offline.sh` im Repository AHAnalyzerPro führt die Testroutine im
  nachgebauten Spiel ohne WoW aus (Lua 5.1).

## 0.65.101
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufs-Vorschlag folgt einem Aufkauf.** Ist die ganze Preisleiter hoch (Aufkauf oder neue Marktlage: günstigstes
  Angebot ≥ 150 % des Marktwerts bei mindestens 3 Angeboten oder 5 Stück), liegt der Vorschlag knapp unter dem
  günstigsten Angebot – nicht mehr beim alten gelernten Preis. Hinweis "Aufkauf – jetzt teuer verkaufen, Preis fällt
  meist bald (2 Std.)" statt "billiger einstellen"; der Ablauf-Zähler gilt dann nicht. "Verkauft sich nur ~N" bleibt
  aus, bis die Absatz-Messung freigegeben ist.
- **Ein getippter Preis bleibt.** Eine fertige Preisprüfung überschreibt einen von Hand eingegebenen Preis nicht mehr;
  Item-Wechsel oder Klick auf "Vorschlag"/"−1" macht ihn wieder automatisch.
- **Sniper behält mehrere Treffer.** Finden zwei Ziele gleichzeitig Treffer, bleiben beide kaufbar (grösster Abstand
  zum Max-Preis zuerst, dann der nächste); abgelaufene fallen raus. Anzeige "N weitere Treffer warten".
- **Sniper-Menge leer:** Ware kauft so viele, wie das Budget reicht ("Menge: bis Budget (N Stück)"), Ausrüstung 1.
  Hinweis, wenn Menge × Max-Preis weit unter dem Budget liegt.
- Tests T509–T512 (T-AB4c-a/b, T-SM1, T-SM2).

## 0.65.100
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Preisverlauf wird verdichtet (kleinere Spielstand-Datei).** 48 Std. in voller Auflösung, danach 1 Wert je Stunde
  bis 7 Tage, danach 1 Wert je Tag bis 60 Tage; Älteres fällt weg. Items ohne neuen Preis seit 30 Tagen behalten nur
  Tageswerte. Ein verdichteter Wert ist der Median der Stunde bzw. des Tages – die Marktwerte bleiben gleich. Läuft
  90 s nach dem Einloggen in kleinen Schritten; der Testbericht zeigt die geschätzte Grösse je Bereich und die letzte
  Verdichtung.
- **Doppel-Reparatur sicher für Waren:** entfernt werden nur zeitlich nahe "ausstehend"-Buchungen, nie abgeschlossene
  Verkäufe (eine Waren-Auktion wird oft Stück für Stück zum gleichen Preis verkauft). Entfernte Buchungen werden in
  einer Nebenliste gesichert, jede Reparatur mit Datum, Version und Anzahl festgehalten (Testbericht).
- **Vollscan-Prüfung sperrt nicht mehr für immer:** die Vergleichszahl verfällt nach 24 Std., und zwei Vollscans
  hintereinander mit ähnlich kleiner Zahl werden angenommen (Markt wirklich kleiner).
- **Alter Einstand nach einem Neustart:** nur ab dem ältesten Eintrag, den das Entzauber-Protokoll noch abdeckt.
- **Aufkauf:** das Testlog nennt beide Preise, wenn eine Kauf-Rechnung den Preis vor dem Aufkauf nimmt.
- Tests: Materialpreise in der Test-Sandbox sind immer frisch (T223/T230/T425 hängen nicht mehr von deinen echten
  Preisen ab); neu T502–T508 (T-VF5f, T-MP2b, T-PD5c, T-PD7a, T-MP1, T-AB8c, T-AB4b).

## 0.65.99
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Ein leerer Vollscan verändert nichts.** Antwortet der Server auf einen Vollscan mit keinen oder viel zu wenigen
  Auktionen (unter 30 % des letzten gültigen), werden keine Markt-, Absatz-, Rhythmus- oder Verfolgungsdaten übernommen:
  "Vollscan ohne Antwort – nichts übernommen." Absatz kommt nur aus zwei gültigen Vollscans.
- **Der Sniper pausiert, während ein Vollscan läuft** (etwa 30–90 s) – der Vollscan hat Vorrang. Die 15-Min.-Sperre
  allein hält den Sniper nicht an. Statuszeile: "wartet: Vollscan läuft".
- **Prognose: ein Fall je Kauf.** Derselbe Kauf konnte mehrfach im Prognose-Journal stehen. Käufe tragen jetzt ihre
  Auktion; wiederholte Meldungen werden nicht nochmals aufgenommen. Bestehende Doppel werden einmal beiseitegelegt
  (nicht gelöscht, in einer Nebenliste), wenn mehr gleiche Fälle da sind als Käufe in der Buchhaltung. Bericht: "Doppel 0".
- Tests T499–T501 (T-PD5a/b, T-PD2); Nachbildungs-Test "Scan mit Waren aktualisiert deren Preiszeit" (T-MP1).

## 0.65.98
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Käufe werden sofort gebucht, auch wenn du schnell hintereinander kaufst.** Bisher kam das Kauf-Ereignis
  manchmal erst, als schon der nächste Kauf lief, und wurde dann erst mit der Rechnung gebucht – Entzaubern dazwischen
  zählte mit Kosten 0. Jetzt merkt sich AHSentinel jeden Kauf mit seiner Auktion und bucht ihn, wenn sein Ereignis
  kommt; nie doppelt.
- **Entzaubern eines Teils ohne bekannte Herkunft** wird als "ohne Einkauf" gekennzeichnet statt still mit 0 gerechnet.
- **Korrektur nach dem Neustart (0.65.97) berichtigt:** Material-Verkäufe, die die Kosten der korrigierten
  Entzauberungen bekommen haben, zählen nicht mehr als "ohne Einkauf" – die Rendite stimmt wieder, die 30-%-Warnung
  verschwindet. Daten, die 0.65.97 schon korrigiert hat, werden beim Einloggen einmal berichtigt. Kosten ohne Ziel
  (Material weitergegeben) stehen im Protokoll.
- **Doppelte "ausstehend"-Verkaufsbuchungen aus 0.65.93/0.65.94** (ohne neue Kennung) werden jetzt gefunden und einmal
  entfernt (Lager zurück); echte gleich grosse Teilverkäufe bleiben.
- Tests T491–T498 (T-AB8c/d, T-AB1b–d, T-VF5e, T-PD1a/b).

## 0.65.97
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Neustart der Buchhaltung behält die Einstandspreise (Eröffnungsbilanz).** Ware, die vor dem Neustart gekauft wurde
  (Taschen, Bank, Post, eigene Auktionen), behält ihren Kaufpreis aus den alten Daten; nur die Gewinn-Zähler beginnen
  bei 0. Ware ohne Kauf (Beute) behält den Wert am Stichtag. Ein Neustart, der die Kostenbasis verloren hat, wird beim
  Einloggen einmal korrigiert: Entzauberungen mit Kosten 0 bekommen den bezahlten Preis, die Kosten wandern auf die
  Materialien (verkaufte in die Verkäufe, der Rest ins Lager). Das Diagnose-Protokoll nennt die Anzahl.
- **Plausibilität:** Warnung im Gewinn-Tooltip, wenn mehr als 30 % des Erlöses "ohne Einkauf" sind oder die Rendite
  beim Entzaubern über 100 % liegt; der Testbericht meldet FEHLER bei Entzauberungen mit Kosten 0 eines gekauften Teils.
- **Gold-Abstimmung ab demselben Zeitpunkt wie die Buchhaltung** (später von Tagesbeginn und Neustart). Ausstehende
  Verkäufe ("kommt noch mit der Post") stehen direkt dabei; "nicht gebucht" erst ab 1 % des Umsatzes.
- **Gewinn % je Item** nur aus Stücken mit Einkauf (wie im Kopf).
- **Einstellen:** kein Lua-Fehler mehr nach erfolgreichem Einstellen. Vor dem Einstellen prüft AHSentinel, ob das Item
  noch am Platz in der Tasche liegt; sonst "Schon eingestellt – nicht mehr in deinen Taschen". Der Knopf bleibt
  gesperrt, bis du ein Item wählst.
- **Meine Auktionen:** statt "?" steht, warum der Preis noch nicht geprüft ist (AH zu, wartet, Sniper sucht, Server
  bremst). Eigene Auktionen werden vor den Materialpreisen im Hintergrund geprüft. Abbrechen wird Schritt für Schritt
  protokolliert (Testlog), die abgebrochene Zeile verschwindet sofort.
- **Aufkauf (z. B. Seelenstaub zum 3-fachen Preis):** nie ein Kauf-Signal; für eigene Ware "Jetzt teuer – verkaufen …
  · Aufkauf – Preis kann schnell fallen".
- **Veraltete Preise:** jedes Material mit ≥ 25 % Anteil am Entzauberwert muss frisch sein, nicht nur das Hauptmaterial.
- Diagnose-Protokoll: Art des letzten Scans bei PREIS-ALT; eingestellter gegen Server-Preis der eigenen Auktion (EIGENE-PREIS).
- Tests T484–T490 (T-AB1, T-AB2, T-AB4, T-AB5, T-AB7, T-AB8a/b).

## 0.65.96
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **AHSentinel sagt dir jetzt, wann kaufen und wann verkaufen – aber nur, wenn es das aus eigenen Messungen weiss.**
  Eine Tooltip-Zeile, nur wenn belegt: "Jetzt günstig – kaufen (−x % unter üblich)", "Fällt – abwarten", "Jetzt teuer –
  verkaufen (+x % über üblich)" oder (eigene Ware / Verkaufen-Reiter) "Jetzt nicht verkaufen – besser um <Zeit> (+x %)".
  Sonst keine Zeile. Dieselbe Zeile steht im Einkauf, im Sniper und im Verkaufen-Reiter (dort nur die Verkaufs-Varianten).
- **Rhythmus für alle Items aus dem Scan:** einmal je Stunde Mindestpreis und Menge jedes Items (Absatz = Menge
  gesunken), kompakt je Tagesstunde und Wochentag (eigener Wochenrhythmus, z. B. Raidtage ab 9.12.). Items ohne Angebot
  seit 14 Tagen fallen raus; auch 5'000 Items bleiben unter 2 MB.
- **Ehrlich:** nur mit frischem Preis (≤ 30 Min.), nie bei Aufkauf oder veralteten Materialpreisen, erst ab 7 Tagen
  Daten und 3 Werten für diese Stunde, und nur bei Abweichung ≥ 10 % ausserhalb der normalen Schwankung. Nie "kaufen"
  in einen Absturz: fällt der Tagespreis seit 2 Tagen, steht "Fällt – abwarten".
- **Jede Zeile wird nachgeprüft** (nach 24 Std. bzw. zur genannten Zeit). Eine Signal-Art unter 60 % Treffer (ab 20
  Fällen) wird ausgeblendet, bis sie wieder besser ist. Die Trefferquoten stehen im Testbericht. Mit Shift bei zu
  wenig Daten: "Rhythmus: noch N Tage messen".
- Tests T477–T483 (T-JK1–T-JK6).

## 0.65.95
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **"Lohnt bis" in jedem Tooltip eines entzauberbaren Items** – auch in Taschen, Bank, Post, Chat-Links, beim Händler
  und in fremden Fenstern (Ausrüstung anderer Spieler, Beute). Für alle Spieler, mit oder ohne Verzauberkunst, auch im
  kurzen Tooltip. In den Taschen direkt über den zwei Wegen (Entzaubern / Verkaufen). Die bestehende Option
  "Entzaub.: an/aus" schaltet den ganzen Entzauber-Teil zusammen ab.
- **Nie mit veralteten Materialpreisen entscheiden.** Hat das Material mit dem grössten Anteil am Entzauberwert keinen
  Preis, der jünger als 6 Std. ist: Tooltip "Lohnt bis: Preise veraltet – erst scannen" (kein Betrag, Urteil
  "unsicher"), Sniper-Entzauberziele kaufen nicht ("Materialpreise veraltet – erst scannen"), Markt "Entzaubern" bietet
  keine Zeile an. Verkaufen-Werte des eigenen Lagers zeigen den alten Preis weiter mit dem Hinweis "alt".
- **Frische Materialpreise am offenen AH:** nach einem Scan und beim Öffnen des AH werden die Entzauber-Materialien
  (bis 15, die häufigsten zuerst), deren Preis älter als 30 Min. ist, einzeln nachgeholt (gedrosselt). Das
  Diagnose-Protokoll notiert Scan-Art, Anzahl Waren im Vollscan und das Preisalter der drei Hauptmaterialien (PREIS-ALT).
- **Aufkauf-Kennzeichen bleibt, bis es widerlegt ist:** ein Material mit Aufkauf behält den Preis vor dem Aufkauf über
  Sitzungen und Tage, bis ein neuerer Scan Menge ≥ 50 % oder Preis ≤ 120 % zeigt.
- **Buchhaltung:** Teilverkäufe derselben Auktion, die 0.65.92 oder älter schon gebucht hat, werden nicht nochmals
  gebucht (bestehende Doppelte einmal beim Einloggen repariert, Lager zurück). Sync: Bestände desselben Charakters,
  auf zwei Rechnern gekauft, werden zusammengezählt (5 + 3 = 8 mit beiden Einständen). Das Paket liest auch die älteren
  Feldnamen, und der Bericht zählt Entzauberungen ohne Verlaufseintrag.
- Tests T467–T476 (T-LB1–T-LB4, T-MP1–T-MP3, T-VF5c/d, T-ZM5).

## 0.65.94
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung: Rendite neben dem Gewinn.** Der Kopf zeigt jetzt "Gewinn X · Rendite Y %" (Gewinn aus gekaufter Ware ÷
  was sie gekostet hat). Ohne Einsatz: "Rendite –".
- **Wo du Geld verlierst** (Tooltip des Gewinns): die Geschäftsart (Entzaubern, Flippen, Herstellen, Händlerware) und
  das Item mit dem grössten realisierten Verlust, mit Betrag – oder "Kein Verlust-Geschäft". Die Art kommt aus der
  Herkunft des Einstandspreises (Kauf im AH = Flippen, aus Entzaubern = Entzaubern); gemischt oder unklar = "unbekannt".
- **Ehrlich bei Ware ohne Einkauf:** Gewinn aus Ware, die du nie gekauft hast (Beute, Farmen, Quests), steht getrennt im
  Kopf ("davon ohne Einkauf: X", nur wenn vorhanden) und zählt nicht in die Rendite.
- Tests T463–T466 (T-BE1–T-BE4).

## 0.65.93
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Behoben: teilweise verkaufte Auktionen lassen sich wieder abbrechen.** Bei Waren behalten die verkauften Teile einer
  Auktion dieselbe Auktions-Nummer wie die aktive Restmenge. Abbrechen (X in der Zeile und "Nächste unterbotene
  abbrechen") nahm einen verkauften Teil und meldete "Diese Auktion ist schon verkauft." Jetzt bricht die Zeile genau
  ihren eigenen Eintrag ab, sonst die aktive Restmenge.
- Buchhaltung: zwei Teilverkäufe derselben Auktion werden beide als "ausstehend" gebucht (nicht mehr übersprungen),
  die aktive Restmenge gilt nicht als verkauft.
- Tests T461–T462 (T-VF5a/b).

## 0.65.92
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Schnell-Vollscan flüssiger.** Die Auswertung nach dem Vollscan rechnet jetzt mit einem Zeitbudget je Bild
  (Standard 4 ms, Option 2/4/6/8 ms neben "Schnell-Vollscan" – kleiner = flüssiger, dauert aber länger). Die Tabellen
  je Item werden zwischen zwei Vollscans wiederverwendet, die Verdichtung erzeugt keinen Müll je Item mehr – viel
  weniger Speicher-Wechsel. Alles, was nach dem Scan neu aufgebaut wird (Marktlisten, Zwischenspeicher), läuft in
  Portionen statt in einem Bild. Der Optionstext weist darauf hin, dass es bis zur nächsten Messung noch ruckeln kann.
- **Messung erweitert:** Bilder/s je Schritt, Anteil der Bilder über 33 ms und AHSentinels eigener Speicher
  vorher/nachher (Testbericht, Abschnitt "Vollscan-Messung"). Neue Prüfungen: kein Schritt mit einem Bild über 16 ms,
  Speicher-Zuwachs höchstens 10 MB.
- "Nächste unterbotene abbrechen" bricht nur Auktionen mit Status "unterboten" ab, nie "liegen"; die Testroutine
  spricht nur ihre eigene Test-Auktion an.
- Marktwerte von 0 oder weniger gibt es nicht mehr (ein Preis 0 wird nicht gespeichert); der Selbsttest nennt die Items.
- Testroutine: der Zeitpunkt "zuletzt geprüft" der Sniper-Ziele gilt nicht mehr als Sandbox-FEHLER.
- Tests T458–T460 (T-VF1–T-VF3).

## 0.65.91
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Daten von zwei Rechnern zusammenführen.** Hast du an zwei Rechnern gespielt, ohne dazwischen abzugleichen, kann
  der GoldSentinel-Uploader AHSentinel die Daten des anderen Rechners übergeben (gespeicherte Variable
  `AHSentinelMerge`). Beim nächsten Einloggen führt AHSentinel sie einmal zusammen und leert das Paket:
  Entzauber-Ergebnisse werden ohne Doppelzählung vereinigt (nur fehlende kommen dazu – nichts geht verloren), Käufe,
  Buchungen und Prognose-Fälle ebenso, der Preisverlauf je Item wird vereinigt, der neuere Vollscan und Charakter-Stand
  gewinnen, und die Einstellungen dieses Rechners bleiben. Chat: "Daten vom anderen Rechner übernommen: …".
- Tests T454–T457 (T-ZM1–T-ZM4).

## 0.65.90
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Signal bei Sniper-Treffer.** Findet der Sniper einen echten Treffer, leuchtet der Bildschirmrand 3 Mal golden auf
  (wie das Glühen bei wenig Leben). Es endet beim Kauf, wenn der Treffer weg ist, beim Schliessen des Auktionshauses
  oder spätestens nach 4 s. Kein Signal bei toten Angeboten, pausierten Items, im Kampf oder bei geschlossenem
  Auktionshaus; höchstens ein Signal alle 3 s. Optionen: "Signal" an/aus und Farbe (Gold, Grün, Blau) neben "Ton bei
  Treffern". Das Leuchten nimmt nie Mausklicks an.
- Tests T450–T453 (T-SG1–T-SG4).

## 0.65.89
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung neu: Gewinn wie bei Profis.** Einkauf ist kein Verlust mehr – was du kaufst, liegt mit seinem
  Kaufpreis im Lager, und der Gewinn entsteht beim Verkauf: Erlös nach 5 % − Kaufpreis genau der verkauften Stücke −
  verlorene Einzahlungen. Der Kopf der Buchhaltung zeigt jetzt EINE Zahl, "Gewinn", für Heute / 7 Tage / 30 Tage /
  Seit Neustart, darunter "Verkauft · Eingesetzt · Gebühren". Alles Weitere steht im Tooltip: Kasse, Lager zum
  Einstandspreis und zum Marktwert, nicht realisierter Gewinn, ausstehende Verkäufe und die Abstimmung mit deinem
  Gold ("nicht gebucht: X").
- **Neustart.** Beim ersten Einloggen mit dieser Version beginnt die Buchhaltung heute. Die alten Daten bleiben im
  Hintergrund (Statistik, Absatz, Prognose nutzen sie weiter), zählen aber nie in der neuen Buchhaltung. Entzauber-,
  Lern-, Prognose- und Vollscan-Daten bleiben unberührt. Was du schon besitzt, bekommt zum Start seinen realistischen
  Wert als Einstandspreis – der Verkauf von altem Bestand ist so weder reiner Gewinn noch Verlust.
  `/ahs buchhaltung neu` beginnt die Buchhaltung erneut (mit Rückfrage).
- **Einstandspreis je Item und Charakter (gleitender Durchschnitt).** Entzaubern verteilt den Preis des Teils nach
  ihrem Wert auf die Materialien; Post an eigene Twinks nimmt den Einstandspreis mit. Items ohne Einkauf (Beute)
  haben Einstandspreis 0.
- **Verkäufe zählen sofort.** Sobald deine eigene Auktion als verkauft erscheint (in Forever ist die Chat-Meldung
  geschützt), wird sie "ausstehend" gebucht; die Rechnung bestätigt sie später – nie doppelt. Der Testbericht misst
  die Verzögerung.
- "Pro Item": Verkauft, Erlös, Eingesetzt, Gewinn, Gewinn %.
- Tests T441–T449 (T-BP1–T-BP9).

## 0.65.88
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Markt "Entzaubern": Kosten und Gewinn über die ganze Preisleiter.** Jede Zeile summiert alle Stufen bis "lohnt
  bis": Menge, Gesamtkosten, Ø-Preis, Gesamtgewinn und Rendite (danach sortiert), z. B. "40x bis 15s 43c (Ø 12s 38c) ·
  Wert 18s 55c · Gewinn 2g 47s (50 %)". Die Menge wird von der günstigsten Stufe aus bis 25 % deines Golds (Option)
  aufgefüllt; der Sniper bekommt genau diese Kosten als Budget und "lohnt bis" als Höchstpreis. Zeile und Fusszeile
  zeigen dieselbe Menge.
- **Wert sinkt mit der eigenen Menge** – eine Funktion für Markt, Sammelkauf und Tooltip: je mehr Teile geplant sind,
  desto tiefer der Materialwert (geplante Kaufmenge, nicht Budget / Preis).
- **Sicherheit höchstens "mittel", wenn das Hauptmaterial frisch gestiegen ist**, dazu "ohne Anstieg: X" in Zeile
  und Detail.
- **Aufkauf erkennen (jemand kauft ein Material weg).** Menge −70 % in 6 Std. und Preis +50 % über dem Marktwert =
  Kennzeichen, bis Menge oder Preis wieder normal sind. Kaufen (Markt, Sammelkauf, "lohnt bis") rechnet dann mit dem
  alten Preis ("Aufkauf bei X – mit altem Preis gerechnet"); Verkaufen bleibt beim aktuellen Preis mit "Preis
  künstlich hoch – eigene Bestände jetzt verkaufen". Der Testbericht listet die Materialien mit Kennzeichen
  (Schwellen werden gemessen).
- **"Stufe ?" behoben**: Zeilen werden neu gezeichnet, sobald die Item-Daten da sind.
- **Einkauf: "~"-Zeilen (aus dem Scan) mit leerem Detail behoben.** Vor der Detailsuche holt eine Scan-Zeile ihren
  echten itemKey über eine Browse-Suche nach dem Namen (Suffix/Itemstufe). Findet auch Browse nichts, verschwindet die
  Zeile sofort ("Keine Angebote mehr – aus der Liste genommen"), auch aus "Entzaubern lohnt", und der Scan bringt sie
  erst mit einem neueren Scan zurück. "~"-Zeilen älter als 30 Min. zählen nicht mehr für den Sammelkauf.
- **Prognose: Verkäufe aus Rechnungen werden wieder zugeordnet.** In Forever kommt die Post schneller als 1 Std.,
  dadurch lag die Verkaufszeit vor der Einstellung und der Fall galt als "nicht verkauft". Teilverkäufe zählen als
  Anteil. Der Testbericht zeigt je Fall, woher das Ergebnis kommt; die Selbstkorrektur lernt nur mit Fällen nach
  dieser Behebung.
- **Entzauber-Prognose zerlegt**: Chance × Menge × Rest (Preis u. a.) je Gruppe im Testbericht.
- Hintergrund-Aufgaben geben vorausschauend ab (ein Frame wird nicht mehr Budget + ein langer Schritt); "Heute tun"
  rechnet in kleineren Portionen.
- Testroutine: das echte Sync-Adressbuch und ein laufender Sniper-Treffer gelten nicht mehr als Sandbox-FEHLER;
  Pfade im Bericht nennen nie Spielernamen. Preis-Tests ersetzen alle Preisquellen. Sammelkauf mit geplanter Menge.
- Tests T425–T440 (T-X3–T-X8, T-MD1–T-MD6, T-SR8a/b).

## 0.65.87
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Behoben: Lua-Fehler bei Verkaufs-Meldungen in WoW Forever.** Geschützte ("secret") Chat- und Ereigniswerte
  werden nie mehr gelesen (Verkaufs-Meldung, Kauf, Post, Einstellen, altes Auktionshaus).
- **"Unterbietung prüfen" friert das Spiel nicht mehr ein.** Nur aktive Auktionen, je Item eine Suche, ohne
  Neuaufbau nach jedem Item: die Liste wird EINMAL am Ende neu gezeichnet. Jeder Schritt wird gemessen; Schritte über
  50 ms stehen als LANGSAM im Protokoll.
- **Vollscan-Messung (für den grossen Test).** Der Schnell-Vollscan misst jetzt jeden Schritt (Warten auf den Server,
  Ereignis, Einlesen, Verdichtung, Verfolgung, Preisverlauf/Neuaufbau), die längste Lücke zwischen zwei Frames (die
  echte Hängezeit), Speicher und Speicherbereinigungen. Der Teil "server" der Testroutine startet einen echten
  Schnell-Vollscan (nur lesen) und meldet ihn im Abschnitt "Vollscan-Messung"; ein Schritt oder eine Lücke über 1 s ist
  ein FEHLER mit Schrittname. Sonst ist am Vollscan nichts geändert.
- **Behoben: ein einzelnes 2c-Angebot drückt keine Materialwerte mehr.** Die Preisleiter wird nur mit dem bereinigten
  Scan-Preis gedeckelt, nie mit dem rohen Minimum; ohne bereinigten Preis gilt der Leiter-Wert als "Markt, unsicher".
- **Behoben: Lagerwert zu hoch, wenn alles verkauft ist.** Eine leere Liste eigener Auktionen (abgefragt, alles
  verkauft) heisst jetzt "nichts im AH"; alte Ablaufzeiten und das Prognose-Journal zählen nur, wenn nie abgefragt.
- **Sniper: tote Angebote werden komplett ausgeblendet.** Ein Angebot, dessen Kauf fehlschlug oder das der Server nach
  "weg" wieder liefert, verschwindet für die Sitzung (je auctionID, höchstens 48 Std.): nicht im Sniper, Einkauf,
  Unterbietung, aktuellen Preis, in der Preisleiter aus Suchen, in "% Markt" oder im Sammelkauf. Waren ohne auctionID:
  nach 2 Fehlschlägen. Die Statuszeile zeigt "1 totes Angebot ausgeblendet (Preis, Grund)", Protokoll
  SNIPER-TOT-AUSGEBLENDET. Nach 3 gescheiterten verschiedenen Angeboten desselben Items pausiert das Item 10 Minuten
  (Protokoll SNIPER-PAUSE). Ein neues Angebot zum gleichen Preis bleibt kaufbar.
- **"Nicht entzauberbar" sperrt nicht mehr die ganze Klasse.** Gelernte Sperren gelten je Item; eine Klasse (z. B.
  Lederrüstung) erst, wenn 3 verschiedene Items gescheitert sind. Solche Items stehen jetzt in "Gesperrt (N)" als
  "nicht entzauberbar (Forever)" mit Freigeben; `/ahs entzaubern freigeben` gibt sie auch frei.
- Testroutine: T410–T424 (T-0, T-UP1–3, T-VM1/2, T-X1, T-X2a/b, T-SR7a–c, T-ME10/11), Abdeckungsliste ergänzt.

## 0.65.86
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper: Tote Angebote bleiben weg.**
  - Ein Angebot, dessen Kauf fehlschlug (z. B. „Es liegt bereits ein höheres Gebot vor“), ist über seine Auktions-ID
    10 Minuten gesperrt. Liefert der Server es noch einmal, bleibt es „weg“ (rot) und wird nicht erneut versucht.
  - Eine neue Auktion zum gleichen Preis bleibt kaufbar.
  - Waren ohne Auktions-ID: Dieselbe Kombination aus Preis und Menge wird 60 s übersprungen.
  - Das Protokoll SNIPER-SUCHE zählt „tot wieder geliefert“.
- Testroutine: T409 (T-SR6).

## 0.65.85
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Fehler behoben (wichtig): keine Schein-Flips mehr.**
  - Der Wiederverkaufspreis nimmt nie mehr den geschätzten Preis des Teils oberhalb der gespeicherten Preisleiter.
    Von dort kamen die „11s 39c“ für eine Kiste, die zu 4s verkauft wird.
  - Ohne aktuelle Preisleiter gibt es keinen Flip-Vorschlag.
  - Die Kaufmenge ist höchstens das, was bis zum Kaufpreis wirklich angeboten wird.
- Eine Flip-Zeile in Heute/Flippen erscheint nur, wenn der Detailbereich mit genau derselben Rechnung „kaufen bis X“
  sagt. Sonst fällt sie weg, das Protokoll schreibt FLIP-WIDERSPRUCH.
- Ein Klick auf eine Zeile in „Heute“ zeigt sie jetzt auch im Detailbereich.
- **Zauberstäbe werden nie zum Entzaubern vorgeschlagen** (in WoW Forever nicht möglich). Scheitert ein Entzaubern mit
  „kann nicht entzaubert werden“, ist das Item (und seine Klasse) ab dann überall ausgeschlossen. Das Protokoll
  schreibt DE-NICHT-MOEGLICH.
- Testroutine: T403–T408 (T-F1–T-F4, T-ME8, T-ME9).

## 0.65.84
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Der Sniper sucht wieder von selbst:**
  - Der Schnell-Vollscan (ReplicateItems) sperrt die Item-Suche des Snipers nicht mehr. Eine laufende Einkaufs-Suche
    oder Preisprüfung sperrt höchstens 20 s.
  - Beim Öffnen des AH (auch nach /reload) startet sofort eine Suche.
  - Statt „Noch nichts gesucht“ zeigt der Sniper seinen Stand: „nächste Suche in 12 s · zuletzt vor 40 s: 5 Treffer“
    oder „wartet: Markt-Scan läuft“. Dazu, wenn nötig, „Vollscan-Sperre noch N Min. (Sniper sucht trotzdem)“.
  - Neues Protokoll SNIPER-SUCHE (Ziel-ID, Angebote, Treffer ≤ Max, gekauft, Sperrgrund; ohne Namen).
- **„Kauf fehlgeschlagen“ nur noch einmal:**
  - Dasselbe Angebot wird nur einmal gemeldet. Weitere Fehlschläge innert 30 s kommen als eine Sammelzeile.
  - Das gescheiterte Angebot gilt als „weg“ und wird nicht erneut versucht. Die nächste Raste kauft das nächste
    passende Angebot; ist keines mehr da, startet eine neue Suche.
- Die Warnung „Max über Verkaufswert“ nutzt denselben Wert wie der Tooltip, bei Entzauber-Items also den
  Entzauberwert.
- Testroutine: T399–T402 (T-SR2–T-SR5).

## 0.65.83
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Neue Markt-Ansicht „Entzaubern“:** Teile, die nach dem Entzaubern mindestens 20 % Gewinn bringen – zum aktuellen
  Markt, nach Gebühren.
  - Jede Zeile zeigt: Item (Stufe), den Preis jetzt und die Menge bis „lohnt bis“, den Wert nach Entzaubern, den
    Gewinn je Stück und in %, dazu die Sicherheit (grün = echte Ergebnisse, grau = Tabelle).
  - Der Knopf „Kaufen“ legt ein Sniper-Ziel an (Max = lohnt bis, Menge, Budget). Gekauft wird nie ohne Klick.
- Filter:
  - Nur Teile, die dein Charakter entzaubern kann (Fertigkeit Verzauberkunst).
  - Mindestgewinn 20 %, in den Optionen einstellbar (10–50 %).
  - Das Markt-Budget gilt (25 % des Golds).
  - Keine Zeile, wenn das wichtigste Material eingebrochen oder überflutet ist. Gelb, wenn der Wert an einem frisch
    gestiegenen Materialpreis hängt.
  - Der Absatz der Materialien gilt nur als Sicherheitsnetz: Erst wenn deine Menge samt Lager mehr als einen Tag
    Absatz ausmacht, wird gekürzt (mit gelbem Hinweis).
- Detail rechts: Materialien mit Chance, Ø-Menge, aktuellem Preis und Hinweis, deine Ergebnisse der Gruppe und „lohnt
  bis“.
- Die Fusszeile zeigt nur den aktuellen Kauf (die gewählte Zeile), keine Summe aller Zeilen.
- Testbericht: Median-Dauer bis Verkauf je Material (aus dem Prognose-Journal).
- Testroutine: T392–T398 (T-ME1–T-ME7).

## 0.65.82
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Preise aus dem aktuellen Markt (dein Entscheid):**
  - Werte kommen nur noch aus der aktuellen Preisleiter und dem Absatz. Es gibt keinen Deckel und kein Mischen mehr
    mit dem Marktwert (Durchschnitt).
  - Der Marktwert ist nur noch eine Warnung: „Preis frisch gestiegen (seit N Std.)“, „Preis eingebrochen (seit N
    Std.)“, „alt (vor N Std.)“, wenn der letzte Scan älter als 2 Std. ist, und „geschätzt“, wenn es gar keinen Scan
    gibt. Die Zahl selbst ändert sich dabei nicht.
  - Mit Shift steht die Quelle dabei, z. B. „Preisleiter, 311 Stück, Absatz ~20/Tag · Marktwert …“.
- **Der Markt rechnet höchstens mit 25 % deines Golds (dein Entscheid):**
  - Das gilt für alle Kaufvorschläge zusammen (Heute, Flippen, Händler). Der beste Gewinn pro Gold kommt zuerst.
    Passt ein Vorschlag nicht mehr ganz, wird er gekürzt, sonst fällt er weg.
  - Die Fusszeile zeigt „Kapitalbedarf X von Y (höchstens 25 %)“.
  - Neue Option „Markt: höchstens % des Golds“ (Standard 25, höchstens 50). Das Tagesbudget je Strategie richtet
    sich danach.
- **Unplausibler Absatz:**
  - Es gilt höchstens 2× die Ø-Menge pro Tag und höchstens 25 % des aktuellen Angebots pro Stunde. Gemessene Werte
    darüber werden nicht verwendet, das Protokoll schreibt ABSATZ-UNPLAUSIBEL.
  - Flip-Texte sagen „geschätzt“ oder „gemessen, N Tage“.
- **Kopf der Buchhaltung:**
  - Die Lager-Kachel zeigt „Lager X (davon im AH Y) − zu Beginn Z“. Der Tooltip rechnet vor: „Kasse + Lager − Lager
    zu Beginn = Ergebnis“.
  - Käufe für Berufe (gekaufte Handwerkswaren, die weg sind) stehen getrennt: „Handel ±A · Berufe −B“.
  - Laufende eigene Auktionen zählen auch aus dem Prognose-Journal, wenn das AH nicht abgefragt wurde.
- Testroutine: T371 (T-AM1), T384–T391 (T-AM3/4, T-K1–3, T-LG6–8).

## 0.65.81
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Fehler behoben (wichtig): Materialpreise beim Entzaubern ehrlich.**
  - Der Materialpreis ist der realistische Verkaufspreis aus Preisleiter und Absatz. Er wird nicht mehr auf den
    Marktwert gedeckelt.
  - Der Tooltip nennt die Quelle: „Scan“ nur bei Werten aus dem Scan, sonst „Markt“ oder „Preis frisch gestiegen (seit
    N Std.)“.
  - Liegen Scan und Marktwert mehr als 50 % auseinander, ist der Preis grau „unsicher“. Mit Shift siehst du beide Werte.
  - Ein frischer Preissprung (unter 24 Std.) zählt höchstens 1,5× den Marktwert. Ab 24 Std. gilt der Leiterpreis, das
    Protokoll schreibt MARKTWERT-CHECK.
  - Lockangebote (1–2 Stück weit unter dem Median) ziehen den Marktwert im Preisverlauf nicht mehr hinunter.
- **Entzauber-Sperrliste mit Weg zurück:**
  - Ein Rechtsklick fragt nach: „Ja / Nur diesmal überspringen / Abbrechen“.
  - Der neue Knopf „Gesperrt (N)“ öffnet eine Liste. Dort gibst du einzelne Items oder alle wieder frei.
  - Das leere Fenster nennt, wie viele Items gesperrt oder übersprungen sind.
  - `/ahs entzaubern freigeben` gibt alle frei.
- Tempo: Die volle Prognose-Auswertung läuft nicht mehr im Tooltip und nicht mehr nach Buchungen. Sie wird im
  Hintergrund in Portionen gerechnet, der Tooltip liest den Zwischenspeicher.
- Vollscan:
  - `/ahs vollscan messen` misst einmal je Sitzung einen kürzeren Abstand (mit Rückfrage).
  - Die Wartemeldung behauptet keine Server-Grenze mehr, sondern sagt „vorsichtshalber, noch nicht gemessen“.
- Die Kauf-Prognose „Wiederverkauf“ rechnet mit dem realistischen Wiederverkaufspreis.
- Sync: Alte Scan-Ankündigungen werden aufgeräumt.
- Veraltete Texte zur Gebühr und unbenutzte Schlüssel entfernt.
- Testroutine:
  - Neu sind T369–T383 (T-HF9–11, H5, T-SK1/2/5, T-SP1–4, Prüfung Hintergrund-Aufgaben unter 16 ms,
    Tooltip-Prüfung mit 3000 Einträgen).
  - Der Entzauber-Bericht hat eine Erklärzeile „gelernt gegen Verlauf“.

## 0.65.80
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Fehler behoben (wichtig): Lager in der Buchhaltung.** „Ergebnis mit Lager“ zeigte −9g 60s und „Lager −8s 22c“,
  obwohl rund 4,7g Ware in den Taschen lag. Jetzt gilt:
  - Der Lagerwert ist nie negativ. Taschen und Bank zählen zum realistischen Verkaufspreis nach Gebühren, mindestens
    zum Händlerpreis. Dazu kommen deine laufenden Auktionen (Angebotspreis × 0,95, die Einzahlung ist schon bezahlt).
  - Der Stand zu Tagesbeginn wird als Stückliste gespeichert und ebenfalls zum heutigen Preis bewertet. Die Kachel
    zeigt so das „Ergebnis, wenn alles zum heutigen Preis verkauft wird“.
  - Die Kachel zeigt „Lager X (davon im AH Y)“. Unter „Pro Item“ gibt es die neue Spalte „im AH“.
- Entzauber-Abrechnung je Charge und gesamt: Kauf, Beute verkauft / im AH / Lager, Gebühren, Ergebnis.
- **Fehler behoben (wichtig): Käufe werden genau einmal gebucht.**
  - Ein Kauf-Ereignis bucht nur den Kauf mit derselben Auktions-ID. Vorher konnte ein verspätetes Ereignis einen
    anderen Kauf erwischen. Jede Auktion wird höchstens einmal gebucht.
  - Kauf-Rechnungen in Forever: Die Menge ist nie 0, der Gesamtbetrag kommt aus der Rechnung.
  - Rechnung und Kaufmeldung werden über Item und Menge zugeordnet, auch wenn der Betrag abweicht. Dann gilt der
    Betrag der Rechnung, und das Protokoll schreibt KAUF-DOPPELT.
  - `/ahs doppelt` zeigt mögliche alte Doppelbuchungen. `/ahs doppelt bereinigen` bereinigt eindeutige Paare mit
    Sicherung, `/ahs doppelt zurück` macht das rückgängig.
- Testroutine: T364–T368 (T-LG1–T-LG5).

## 0.65.79
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Die Testroutine fasst deine Entzauber-Daten nie an.** Tests zum Zurücksetzen und Wiederherstellen laufen jetzt nur
  noch auf Ersatztabellen. Das gilt auch für den Optionstest „Entzaubern zurücksetzen“ und die Sicherung `deBackup`.
- **Der gemessene Absatz aus dem Vollscan war viel zu hoch (10–20×).** Bei Waren (stapelbar) ergab ein Teilkauf eine
  neue Signatur, dann zählte der ganze alte Stapel als „weg“. Jetzt gilt:
  - Waren werden nach Menge je Stückpreis verglichen. Es zählen nur Preisstufen bis Mindestpreis + 2 %, und
    Neueinstellungen zum gleichen Preis werden gegengerechnet.
  - Der Absatz pro Tag wird erst ab 6 Stunden Abdeckung hochgerechnet, vorher heisst es „zu kurz“.
  - Eine Plausibilitätsgrenze (höchstens 2× die Ø-Menge im AH) markiert unplausible Werte und schreibt sie ins
    Protokoll.
  - Raten aus älteren Versionen (zu kurze Paare) werden nicht mehr verwendet.
- Vollscan lesen: Die Uhr wird alle 25 Einträge geprüft, mit 5 ms je Frame (Ziel: längster Frame ≤ 8 ms).
- Testroutine: Die Rangliste (T169) misst nur noch die eigene Aufgabe, andere Aufgaben werden genannt. Die
  Zählkontrolle beim Entzaubern vergleicht nur Einträge ab Beginn der Zählung (kein falscher Alarm mehr).
- Testroutine: T360–T363 (T-W1, T-W2, T-W5).

## 0.65.78
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Fehler behoben (wichtig): Entzauber-Käufe werden realistisch bewertet.** Die Materialpreise nutzen jetzt denselben
  realistischen Wiederverkaufspreis wie die Flips (Preisleiter und Absatz pro Tag), nach AH-Anteil und erwarteten
  Einzahlungsverlusten. Viele gekaufte Teile senken den Preis: Liegt dein Material über dem Absatz von zwei Tagen,
  zählt jede weitere Tagesmenge eine Stufe tiefer. Das gilt für Entzauberwert, „Entzaubern lohnt“, Sammelkauf und
  Entzauber-Schnäppchen.
- Tooltip: Das Urteil zeigt den Gewinn mit Prozent. Mit Shift: „Gewinn nach Verkauf der Materialien: X (Y %)“.
- Buchhaltung -> Entzaubern: Abrechnung je Kauf-Charge, z. B. „Charge 10.11.: bezahlt 5g, verkauft Xg, Lager Yg,
  Gebühren Zg, Ergebnis ±Wg“. Mit der Maus siehst du alle Chargen.
- **Meine Auktionen:** „8 verkauft (4g 42s 77c, erhalten 4g 20s 60c)“. Erhalten = je Auktion Gesamt × 0,95,
  abgerundet. Eine Fusszeile zeigt die Summen der Liste je Status. Mit Shift zeigt der Tooltip am Kopf, wie viel
  heute insgesamt verkauft wurde (aus der Buchhaltung).
- **Sniper:** „Ergebnis ist veraltet – in dieser Suche gekauft: 23 Stück für 2g 30s · verpasst 13 – neue Suche
  nötig.“ Die Zielzeile zeigt „50/100 gekauft · Budget 5g aufgebraucht“ (bzw. „Budget übrig …“) ganz. Ist das
  Budget aufgebraucht, kommt einmal eine Meldung im Chat und eine Kopfzeile. Das Ziel bleibt in der Liste. Der
  Ziel-Tooltip erklärt, wie viele Stück das Budget hergibt.
- Testroutine: T351–T359 (T-HF8, T-MS1–3, T-SN1–3).

## 0.65.77
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Fehler behoben (wichtig): keine Schein-Flips mehr.** „Heute“ schlug z. B. vor: „Kaufe 4x Instabiles Magiepartikel
  bis 45s 97c, wieder einstellen um 2g 3s“. Im AH lagen aber 855 Stück zu 46–50s, die 2g 3s waren ein veralteter
  Angebotspreis. Jetzt gilt überall EIN realistischer Wiederverkaufspreis (Heute, Flippen, Details, Wächter):
  - Es ist der Preis, vor dem weniger Stück warten, als sich in deiner Laufzeit verkaufen. Die Grundlage ist die
    Preisleiter aus dem Vollscan oder der Suche.
  - Höchstens gilt der gelernte Normalpreis und der Marktwert.
  - Ohne Preisleiter liegt er höchstens 15 % über dem aktuellen Mindestpreis.
- Bei Preissturz oder geflutetem Angebot (3× so viel wie üblich) gibt es keinen Flip. Solche Items erscheinen unter
  „Überfüllt“.
- Liste und Details widersprechen sich nie mehr: Eine Kaufzeile gibt es nur, wenn auch die Details „kaufen bis X“
  sagen.
- Der Flip-Gewinn ist ehrlich: nach AH-Anteil und erwarteten Einzahlungsverlusten. Die Menge ist höchstens so gross,
  wie du mit deinem Marktanteil verkaufen kannst.
- Die Markt-Ansichten bleiben nicht mehr leer, solange der Absatz noch nicht gemessen ist. Dann wird mit dem
  geschätzten Absatz gerechnet und die Zeile grau mit „geschätzt“ markiert. Eine leere Ansicht nennt den Grund.
  Beim Wechsel der Ansicht leert sich der Detailbereich bzw. zeigt die erste Zeile.
- **Meine Auktionen:** In der Kopfzeile steht die Gesamtsumme der verkauften Ware (brutto und nach AH-Anteil).
- Testroutine: T344–T350 (T-HF1–T-HF7).

## 0.65.76
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Gesamtprüfung nach allen Stufen:** `/ahs testroutine alles` führt den automatischen Teil aus und danach nacheinander
  die Teile Server, Berufe und Händler. Fehlt ein Fenster, sagt eine Zeile, was zu öffnen ist. Die Routine wartet bis
  2 Minuten und macht dann weiter.
- **Testbericht:**
  - Oben stehen fünf Zeilen Zusammenfassung: OK/Fehler, was im Spiel noch zu tun ist, Prognose-Trefferquote,
    gemessener Absatz für N Items und Speicher.
  - Eine Abdeckungsliste ordnet jedem Auftrag und Testfall seine Prüfungen zu oder sagt, warum er nur im Spiel prüfbar
    ist.
  - Abschnitte mit echten Daten: Entzaubern, Prognose-Güte, Vollscan, Lern-Datenbank, Markt-Reiter und Messreihe.
  - Die Sandbox vergleicht alle echten Tabellen, auch Journal, Lernen und Vollscan.
  - Speichergrössen und Ladezeit stehen im Bericht.
- **Messreihe „Ausrüstung in ganzen Silbern“** (`/ahs messreihe`, nur mit deiner Zustimmung): Mit ein paar billigen
  grauen/weissen Ausrüstungsteilen wird eingestellt:
  - zu 1s 00c, 1s 01c, 1s 50c, 1s 99c, 2s, 10s 50c und 1g 00s 01c
  - einmal mit Gebot
  - dazu eine Ware zu 1s 99c

  Jede Einstellung wird sofort wieder abgebrochen. Jeder Schritt ist ein Klick, höchstens 10 Einstellungen, die
  Kosten werden vorher gezeigt. Das Ergebnis kommt ins Protokoll und in den Testbericht. Die Preisrundung bleibt, bis
  die Messung etwas anderes belegt.
- Preis-Sync: Eine unvollständige Preisliste aus dem Netz hält ein Gildenmitglied mit vollem Scan nicht mehr vom
  Antworten ab.

## 0.65.75
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Neuer Reiter „Markt“ ersetzt „Heute tun“ (Stufe 3):** eine Leiste mit 6 Ansichten:
  - **Heute**: das bisherige „Heute tun“, deine Sachen zuerst, darunter die besten Chancen.
  - **Flippen**: unter deiner Kaufgrenze, sortiert nach Gewinn je Gold und Tag.
  - **Händler**: Sofortkauf unter dem Händlerpreis.
  - **Lücken**: wenig Angebot, stetiger Absatz, Preis steigt. Dein Lager steht oben.
  - **Überfüllt**: nicht einstellen. Viel mehr Angebot als Absatz, mit Tagen bis zum Verkauf und dem
    Einzahlungsrisiko.
  - **Trends**: stabile Bewegungen über 7 und 30 Tage, fallende Leveling-Waren zuerst.

  Jede Ansicht hat eine Erklärzeile, höchstens 20 Zeilen, eine Zahl, die Sicherheit als Farbe und einen Knopf. Der
  Knopf arbeitet wie bisher: Prüfen -> Kaufen -> Einstellen, nie ohne deinen Klick.
- **Details rechts:** Zeile anklicken oder oben ein Item suchen. Du siehst:
  - Preis und Angebot über 14 Tage
  - die Preisleiter
  - deine eigene Geschichte
  - die gelernten Preisgrenzen
  - EINE Empfehlung („kaufen bis X“ / „einstellen für Y“ / „liegen lassen“) mit Begründung
  - Knöpfe für Watchlist, Einkaufsliste, Sniper (mit vorgeschlagener Grenze) und Preisverlauf
- **Markt heute:** Ein Preis-Index typischer Waren steht oben („Markt heute +3 % (7 Tage +8 %)“).
- Die Liste aller Items ist aus der Reiterleiste verschwunden. Die Daten bleiben, alle Ansichten rechnen damit.
  Nachschlagen geht über die Suche.
- `/ahs heute`, der Knopf „Heute tun“ und andere Addons öffnen den Markt auf „Heute“. Das gilt auch für die Zeilen von
  ProfessionSentinel (QuickBuy/QuickSell), die oben stehen. Neue Option: „Markt: Standard-Ansicht“.
- Testroutine: neuer Teil „m“ (Markt) und der Abschnitt „Markt-Reiter“ im Bericht.

## 0.65.74
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Lern-Datenbank (Stufe 2, unsichtbar):** AHSentinel lernt jetzt im Hintergrund aus deinen eigenen Ergebnissen. Es gibt
  nichts Neues zu bedienen, nur bessere Zahlen in dem, was du schon benutzt. Die Option „Lernen“ (an) schaltet alles
  wieder ab.
  - Verkaufschance je Preislage (Preis ÷ Marktwert) und Laufzeit. Abgelaufene und abgebrochene Auktionen zählen als
    „nicht verkauft“ und werden nie weggelassen. Wenige eigene Fälle werden zur Warengruppe gezogen, dann zu den
    geteilten Zahlen aller Spieler (Sync, nur Zähler, keine Namen), dann zu einem Startwert.
  - Preisgrenzen je Item: Der Verkaufen-Reiter schlägt den gelernten Normalpreis vor, wenn niemand mitbietet oder die
    Konkurrenz über deinem Maximum liegt. Das Minimum rechnet Gebühr und erwartete Einzahlungsverluste mit ein.
  - Verkaufen: „Verkauft sich in dieser Laufzeit nur ~N – Rest in der Tasche lassen.“ Meine Auktionen: „teurer möglich“,
    wenn die günstigere Konkurrenz weg ist. Abgebrochen wird nur mit deinem Klick.
  - Sicherer kaufen: Wächter, Sammelkauf, Flips und Entzauber-Schnäppchen nehmen eine Sicherheitsmarge aus dem
    gemessenen Fehler (20 % bis 20 Käufe, danach mindestens 10 %). Dazu kommt ein Tagesbudget je Strategie (10 % deines
    Golds), solange ihre Trefferquote unter 60 % liegt.
  - Heute tun: ein Hinweis, wenn Gekauftes mehr als 25 % an Wert verloren hat („jetzt verkaufen bringt X, warten
    erwartet Y“).
  - Seltene Items: Der eigene Absatz wird mit Croston geschätzt. Der Markt-Absatz nimmt einen gelernten Faktor je Gruppe
    (aus dem Vollscan) statt des festen 20-%-Deckels.
  - Selbstkorrektur jede Woche oder alle 50 neuen Ergebnisse (gedämpft ±30 %, Protokoll „LERNEN“). Den Rhythmus
    (günstige/teure Stunde und Wochentag) gibt es ab 21 Tagen und nur, wenn er stabil ist.
  - Option „Ausprobieren (+5 %)“ (aus): Jede 10. Einstellung schlägt 5 % mehr vor, um die Preisempfindlichkeit zu
    lernen.
- Tooltip (Shift): „Verkaufschance zum Marktwert: 72 % (gelernt aus 23 eigenen Verkäufen)“, dazu der Rhythmus, wenn er
  bekannt ist.
- Testroutine: neuer Teil „l“ (Lernen) mit festen Zahlen. Bericht und GSTEST1 bekommen den Abschnitt „Lern-Datenbank“.

## 0.65.73
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Schnell-Vollscan (neue Option, Standard aus):** Im modernen Auktionshaus (WoW Forever) liest der Scan-Knopf auf
  Wunsch alle Einzelauktionen auf einmal mit ihrer Restzeit (ReplicateItems), statt Seite für Seite zu blättern. Gelesen
  wird in kleinen Portionen, das Spiel bleibt flüssig. Höchstens alle 15 Minuten, sonst läuft der normale Scan.
  `/ahs vollscan` startet ihn einmal. Preise, Marktwert und Verlauf bekommen dieselben Werte wie bisher (Mindestpreis,
  Menge; Lockangebote zählen nicht).
- **Exakte Warteschlange:** „Wie viele sind vor mir?“ zählt jetzt nur die Stück zu deinem Preis oder billiger
  (Preisleiter aus dem Vollscan) statt aller Stück des Items.
- **Echter Markt-Absatz gemessen:** Zwischen zwei Vollscans vergleicht AHSentinel die Auktionen (Menge und
  Sofortkauf, keine Namen). Vorzeitig weg mit langer Restzeit = gekauft oder abgebrochen, weg mit kurzer Restzeit =
  abgelaufen (kein Verkauf). Ab 3 Tagen Daten zeigt der Tooltip (Shift) „~12/Tag (gemessen, 5 Tage)“ statt der alten
  Schätzung, bis dahin „(geschätzt)“. Deine eigenen Auktionen dienen als Gegenprobe (Anteil Abbrüche).
- Era/TBC: unverändert (das alte Auktionshaus hat keinen Vollscan).
- Testroutine: neuer Teil „v“ (Vollscan) mit festen Zahlen. Bericht und GSTEST1 bekommen den Abschnitt „Vollscan“
  (Zeit je Frame, Drosselung, Bedeutung der Restzeit-Stufen, gemessener Absatz).

## 0.65.72
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Prognose-Journal (Stufe 1 „jede Vorhersage nachprüfen“):** Beim Einstellen, Kaufen und Entzaubern merkt sich
  AHSentinel im Hintergrund, was es in diesem Moment vorhergesagt hat (Verkaufschance in der Laufzeit, Stunden bis
  Verkauf, Einstellungen, Netto-Wert; beim Kauf den geplanten Weg, beim Entzaubern den erwarteten Materialwert). Später
  ordnet es das Ergebnis zu: Verkaufsrechnungen (älteste Einstellung zuerst, Teilverkäufe anteilig), abgelaufene und
  abgebrochene Auktionen (zählen als „nicht verkauft“, werden nie weggelassen), Entzauber-Beute und was aus gekauften
  Waren wurde. Ohne Namen, kompakt (höchstens 3000 Einträge, älter als 60 Tage nur noch in einer kleinen
  Zusammenfassung). Buchhaltung, Entzauber-Ergebnisse und Preisverlauf werden nur gelesen, nie geändert.
- **Tooltip (Shift):** ab 20 eigenen Ergebnissen in der Warengruppe: „Prognosen bei dir: X % zutreffend (N …)“.
- **Testroutine:** neuer Teil „p“ (Prognose) mit festen Zahlen (Brier-Score, Zuverlässigkeits-Tabelle, FIFO,
  Teilverkauf, Ablauf, Abbruch, Ringpuffer, Grösse < 300 KB, keine Namen); Bericht und GSTEST1-Export bekommen den
  Abschnitt „Prognose-Güte“ aus deinen echten Daten (nur lesen).
- Messungen: welche Replicate-Funktionen es gibt (nur geprüft, nie aufgerufen), welche Felder die Item-Suche liefert,
  und der Mindestpreis/die Menge je Stunde des Tages für Items, die du handelst oder beobachtest (später ausgewertet).

## 0.65.71
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzauber-Statistik:** Abgelehnte Ergebnisse (Material ausserhalb der Tabelle) zählen als entzaubert, ihre Beute
  zählt mit, sie stehen aber getrennt: „(davon abgelehnt N)“. Fürs Lernen zählen sie nie.
- **Entzauber-Ergebnisse wiederherstellen:** Nach dem Zurücksetzen wird der Knopf in den Optionen zu „Wiederherstellen“
  und holt die letzte Sicherung exakt zurück.
- **Schnellerer Tooltip:** Das Preisdiagramm unter dem Tooltip wird nur neu gezeichnet, wenn sich Item oder Daten
  geändert haben.
- **Testroutine:** Die Tempo-Prüfung des Tooltips zeigt die Zeit je Block; am Ende des Berichts steht in einer Zeile, was
  für die übersprungenen Teile zu tun ist (z. B. „Auktionshaus öffnen, dann /ahs testroutine server“).

## 0.65.70
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Korrektur: Optionen überlagerten sich** (z. B. „Selbsttest“ über „Standard-Laufzeit“): Es gab mehr Optionen, als in
  zwei Spalten à 18 Zeilen passten. Jede Option hat jetzt ihren eigenen Platz (20 je Spalte, bei Bedarf mehr Spalten).
- **Deine Entzauber-Ergebnisse sind geschützt:** „Zurücksetzen“ (Optionen → Entzaubern gelernt) fragt mit der Zahl der
  Ergebnisse nach und legt vorher eine Sicherung an. Die Testroutine prüft, dass die Entzauber-Daten nach dem Lauf
  unverändert sind (Anzahl und Mengen), und meldet jede Abweichung.
- **Entzaubern:** Beute ganz ohne Entzauber-Material (Mob, Kiste, Kürschnern) zählt nie als Entzaubern; die Beute muss
  innerhalb von 5 Sekunden kommen.
- **Testroutine:** neuer Abschnitt „Entzaubern (echte Daten)“ – je Gruppe eigene/geteilte Ergebnisse, Rate je Material
  gegen die Tabelle (Auffälliges markiert), Zählkontrolle des Tages und Plausibilität; auch im GSTEST1-Export. Neue
  Prüfungen für die ganze Kette (Zauber → Beute → gezählt), die Lernrechnung mit festen Zahlen, geteilte Ergebnisse und
  Werte.
- Tooltip: Quelle der Chancen bei der Entzauber-Gruppe „bis 15“ richtig benannt.

## 0.65.69
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Korrektur: Buchhaltung zeigte den Preis als Menge** (z. B. „verkauft 22000“ für EINE Kappe): Bei manchen
  Forever-Rechnungen ist Feld 5 der Preis, nicht die Menge. Es zählt jetzt nur noch als Menge, wenn es plausibel eine ist
  (bei Ausrüstung nie). Gespeicherte Verkäufe werden einmal repariert (mit Sicherung, Protokoll REPARATUR-MENGE).
- **Korrektur: positive Gebühren in der Buchhaltung:** Eine Erstattung beim Verkauf ohne gebuchte Einzahlung (eingestellt
  über Blizzards Fenster, ein anderes Addon oder vor AHSentinel) wird jetzt durch die passende Einzahlung gedeckt – netto
  0, wie im Spiel. Einstellungen über Blizzards Fenster oder andere Addons werden auch gebucht. Alte Daten werden einmal
  repariert.
- **Entzaubern wird auf jedem Weg gezählt:** Neben Klick in der Tasche und AHSentinels Fenster werden jetzt auch Makros
  und andere Addons (/use Tasche Platz) über den Tascheninhalt erkannt. Ergebnisse mit einem Material ausserhalb der
  Tabelle verschwinden nicht mehr still (Protokoll DE-ABGELEHNT); jedes Entzaubern schreibt DE-GEZÄHLT oder DE-VERPASST.
  Statistik: „heute gezählt N · verpasst M“.
- **Tooltip-Materialien:** gelernte Ø-Menge („Ø 1,4“), den Bereich der Tabelle nur mit Shift; eigene und geteilte
  Ergebnisse getrennt genannt.

## 0.65.68
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Korrektur (0.65.66): Mit der Standard-Laufzeit 2 Std. sah fast alles unverkäuflich aus** – die Bewertung zog bis zu
  sechs verlorene Einzahlungen ab, sobald sich etwas nicht in 14 Std. verkauft (z. B. Staub zeigte „Händler“). Der Reiter
  Verkaufen bleibt bei 2 Std.; die Bewertung rechnet mit 24 Std., wenn das dieselbe Einzahlung kostet (Mindesteinzahlung),
  sonst mit der Standard-Laufzeit. Mit Shift zeigt der Tooltip die benutzte Laufzeit.
- **Sofortkauf fehlgeschlagen – klare Meldung:** „Angebot ist weg (vermutlich schon gekauft)“ statt „Angebot weg oder
  nicht genug Gold“; die Meldung des Spiels steht dabei, Gold wird nur genannt, wenn es wirklich fehlt. Ein verschwundenes
  Angebot wird markiert, sein Knopf gesperrt, und es verschwindet aus der Einkaufsliste. Protokoll-Zeile KAUF-FEHLER (ohne
  Namen).
- **Mindestgebot:** +5 % nur, wenn schon jemand geboten hat; ohne Bieter ist das Startgebot das Mindestgebot. Ist kein
  Gebot unter dem Sofortkauf möglich, ist das Gebotsfeld ausgeblendet.
- **Detailsuche findet nichts, obwohl der Scan das Item führt:** AHSentinel versucht es einmal ohne Itemstufe/Suffix;
  bleibt es leer, verschwindet die Zeile aus der Einkaufsliste (Protokoll DETAIL-LEER).
- Schnittstelle für andere Addons: Preisquelle „scan“ nur, wenn der Preis wirklich im letzten Scan war.
- Testroutine: Knopf-Namen mit Text und Lage; veraltete Gebühren-Texte entfernt.

## 0.65.67
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Korrektur: Die Zeile „110 in den Taschen: …“ erschien nicht** (z. B. Seltsamer Staub): Der Tooltip prüfte „stapelbar“
  mit einer Spielfunktion, die es in WoW Forever nicht gibt. Jetzt geht es mit jedem Taschen-Addon. Kann der Gesamtwert
  nicht gerechnet werden, steht „Verkaufen:“ × Menge da, und das Diagnose-Protokoll bekommt eine Zeile GESAMTWERT.
- **Entzauber-Chancen grüner Items in WoW Forever** nach dem Forever-Leitfaden (wow-professions.com): Rüstung 75/20/5,
  Waffen 20/75/5 (Staub/Essenz/Splitter); bis Itemstufe 15 bleibt 80/20 ohne Splitter. Eigene Ergebnisse zählen weiter
  stärker. Andere Spielversionen behalten die Tabelle von warcraft.wiki.gg.
- **Tooltip:** „Materialien (Tabelle + N eigene)“, wenn eigene Entzauber-Ergebnisse eingerechnet sind; mit Shift die
  Quelle der Chancen. Diagnose-Protokoll: eine Zeile DE-CHANCEN je Gruppe und Tag (Tabelle gegen echte Ergebnisse).

## 0.65.66
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Neue Option „Standard-Laufzeit“ (Standard: 2 Std. in WoW Forever):** Jedes neue Item im Reiter Verkaufen steht
  darauf; eine von Hand gewählte Dauer gilt nur für dieses Einstellen. Serie, Neu einstellen und „Heute tun“ nehmen sie
  auch, ebenso alle Rechnungen. „24 Std. kostet gleich viel“ bleibt nur ein Hinweis.
- **Korrektur: „Heute tun“ riet, Waren beim Händler zu verkaufen** (z. B. Leinenstoffballen), weil es 1 Stück je
  Auktion annahm: Im modernen Auktionshaus wird eine Ware als EINE Auktion mit beliebiger Menge eingestellt – die
  Mindesteinzahlung fällt einmal an. Im alten Auktionshaus (Era/TBC) bleiben die Stapel.
- **Absatz bei überfüllten Items:** Auktionen laufen in WoW Forever höchstens 24 Std., also verschwindet fast alles jeden
  Tag, auch ohne Verkauf. Der Markt-Absatz ist jetzt höchstens 20 % der Menge im letzten Scan pro Tag (Annahme, wird im
  Diagnose-Protokoll geprüft). Deine eigene Erfahrung (eingestellt gegen verkauft, ab 3 Einstellungen) geht vor –
  dieselbe Zahl in Tooltip, Gewinn-Fenster und Protokoll.
- **Gewinn-Fenster:** zeigt in WoW Forever die Einzahlung je Auktion (zurück bei Verkauf) und die erwartete Zahl der
  Einstellungen mit dem erwarteten Einzahlungsverlust.
- **„Heute tun“: Klick auf eine Zeile** bewirkt immer etwas Sichtbares – oder zeigt einen Hinweis; Fehler werden nicht
  mehr verschluckt.
- Diagnose-Protokoll: ABSATZ mit Rohwert, Deckel, eigener Quote und Laufzeit; neue Zeile ENTZAUBERWERT (Materialien,
  Chancen, netto).
- Testroutine: Wächter-Einstellung bleibt unberührt (Sandbox), Tooltips im Ergebnisfenster neben dem Fenster, T33 immer
  mit Grund, T52 prüft „unterboten“ und „liegen lassen“ getrennt, T27 nennt den wahren Grund, leere Rahmen anderer Addons
  sind nur ein Hinweis.

## 0.65.65
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Korrektur: Ausrüstung einstellen scheiterte mit „Interner Auktion-Fehler“** (WoW Forever): Der Server nimmt
  Einzelstücke (Ausrüstung) nur in ganzen Silber an. AHSentinel rundet den Preis von Einzelstücken auf ganze Silber ab
  (mindestens 1s) und zeigt ihn im Feld; Unterbieten bei Einzelstücken mit „−1 Silber“. Waren behalten Kupferpreise.
- **Korrektur: Staub und Essenzen „verkauften sich kaum“** (0.65.63): Der Absatz kommt jetzt immer vom Markt; deine
  eigenen Verkäufe erhöhen ihn nur, und was du selbst regelmässig verkaufst, gilt nie als „kaum“.
- **„Heute tun“ stockt nicht mehr:** Die Schleife über die Entzauber-Angebote pausiert jetzt in kleinen Portionen; das
  Diagnose-Protokoll zeigt bei langsamen Hintergrund-Aufgaben die Schritte je Frame.
- **Neu: Befehlsliste beim Tippen:** Tippst du im Chat /ahs, erscheinen über dem Eingabefeld alle Befehle – die
  meistbenutzten oben; Weitertippen filtert, Klick führt aus. AHSentinel schreibt nie ins Chat-Eingabefeld. Abschaltbar
  in den Optionen („Befehlsliste beim Tippen“).

## 0.65.64
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung: „Gewinn“ heisst jetzt „Kasse“** – Einnahmen minus Ausgaben minus Gebühren. Gekaufte Materialien zählen
  als Ausgabe, auch wenn sie noch im Lager liegen (z. B. Stoff, der durch Herstellen und Entzaubern zu Staub wurde).
- **Neue Kachel „Ergebnis mit Lager“:** Kasse plus die Änderung des Lagerwerts im Zeitraum (Taschen, Bank und laufende
  Auktionen dieses Charakters, bewertet wie „Verkaufen:“ im Tooltip). Ein Lagerstand wird beim ersten Einloggen des Tages
  und beim Ausloggen gespeichert, mit den Preisen von damals. Ohne Stand zu Beginn steht „–“.
- **„Pro Item“ hat eine Spalte „im Lager“** (Stück jetzt).
- „1 Verkauf“ / „1 Kauf“ statt „1 Verkäufe“.
- **Tooltip:** Ein Preis, der nicht im letzten Scan war, ist mit „(alt)“ gekennzeichnet; wurde ein Scan-Preis als
  Ausreisser ersetzt, steht der Rechenwert daneben.

## 0.65.63
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufen wird nach Angebot und Absatz bewertet:** Wie viele Stück zu deinem Preis oder billiger im AH liegen (ohne
  Lockangebote und eigene Auktionen) und wie viele pro Tag verkauft werden, ergibt die Wartezeit und die erwarteten
  Einstellungen; jede Einstellung ohne Verkauf kostet in WoW Forever die Einzahlung. Dauert es länger als 7 Tage,
  „verkauft sich kaum“ – Verkaufen ist dann nicht der beste Weg (Händler oder Entzaubern). Eine Zahl überall: Tooltip,
  Gewinn-Fenster, Beste Rezepte, „Heute tun“ und die Schnittstelle. Mit Shift zeigt der Tooltip die Begründung, z. B.
  „150 im AH · ~5/Tag · ~30 Tage · verkauft sich kaum“. Die Absatz-Schätzung (verschwunden = halb verkauft) ist eine
  Annahme und wird im Diagnose-Protokoll geprüft.
- **Korrektur: „Meine Auktionen“ zeigte bei aktiven Waren falsche Preise** (z. B. 0c oder 2c je Stück): Das Spiel meldet
  bei aktiven Waren den Preis je Stück. Preis, Gesamt, der „Wert“ in der Kopfzeile und das Erkennen von Unterbietungen
  stimmen jetzt.
- **Tooltip mit Shift:** Was du besitzt, steht mit eigener Überschrift („Im Besitz:“), mit dem Wert in den Taschen und
  dem Bestand deiner anderen Charaktere.

## 0.65.62
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Item-Tooltip zeigt den Wert von allem in den Taschen:** Bei stapelbaren Items ab 2 Stück steht unter „Verkaufen:“
  eine zweite Zeile mit dem Gesamtwert aller Stapel (z. B. „386 in den Taschen: 2g 0s 72c“), gerechnet wie „Verkaufen:“
  für die ganze Menge (bzw. der Händlerwert, wenn der Händler mehr zahlt). Die Bank zählt nicht mit.
- **Ausrüstung einstellen – Diagnose:** In WoW Forever scheitert das Einstellen von Ausrüstung über AHSentinel mit
  „Interner Auktion-Fehler“, Blizzards Fenster geht. AHSentinel schreibt jetzt ins Diagnose-Protokoll, was Blizzards
  Fenster an den Server schickt und was AHSentinel schickt (nur Typen und Zahlen, keine Namen), damit der Aufruf gleich
  gebaut werden kann.
- **Echte Fehlermeldung beim Einstellen:** Es erscheint die Meldung des Spiels (z. B. „Interner Auktion-Fehler“) statt
  „zu wenig Gold oder Item nicht verfügbar“; Fehlversuche stehen im Diagnose-Protokoll.
- **Verkaufen-Reiter:** Ein leeres Mengenfeld gilt als 1 (es zeigte eine graue 1, stellte aber nicht ein).

## 0.65.61
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Korrektur: „Heute tun“ konnte Vorschläge verlieren und nach dem Einloggen kurz stocken** (Protokoll: 413 ms in einem
  Frame). Hintergrund-Rechnungen konnten in einem geschützten Aufruf nicht pausieren (Lua 5.1): Vorschläge „unter
  Händlerpreis“ und Flips fielen still weg, der Rest lief am Stück. Jetzt wird richtig pausiert und nichts geht verloren.
- **Korrektur: Buchhaltung → „Werte stimmen?“ (Vorhersage gegen Verkauf) war in WoW Forever falsch:** Der echte
  Stückpreis kam aus dem Mengenfeld der Rechnung („echt 1“, +7800 %). Jetzt Gesamt / Menge; bisherige Verkäufe werden
  einmal neu gerechnet.
- **Gewinn-Fenster, „Beste Rezepte“:** Nur neue Preise vom Sniper oder Sync bauen die Liste höchstens alle 30 Sekunden
  neu (vorher beim Snipen alle 2 Sekunden). Öffnen, Berufswechsel, Taschen und Buchhaltung aktualisieren weiter sofort.

## 0.65.60
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Hauptfenster öffnet neben dem Auktionshaus** statt darüber, solange du es nicht selbst verschoben hast (und Platz
  auf dem Bildschirm ist).
- **Schnellere Item-Tooltips:** Die AHSentinel-Zeilen werden je Item einige Sekunden zwischengespeichert (Preisdaten,
  Shift, Einstellungen, Watchlist und Taschen zählen mit); der Shift-Teil wird nur mit gedrückter Shift-Taste gerechnet.
- **Testroutine abbrechen:** `/ahs testroutine stop` (oder `abbrechen`) und der Knopf „Abbrechen“ im Ergebnisfenster
  beenden den Lauf; alle Daten werden wiederhergestellt, im Bericht steht „vom Nutzer abgebrochen“.
- Testroutine: Es werden keine echten Daten mehr verändert (eigene Auktionen, Verkäufer-Eintrag, Buchhaltung,
  Sniper-Tageszähler, Entzauber-Protokoll – jeder Test arbeitet jetzt auf einer eigenen Kopie); Sniper und Wächter
  pausieren während der Server-Suchen und kommen danach auf deine Einstellung zurück; eine Zeitüberschreitung nennt den
  Grund (Anfragen pro Minute, Suche, Sniper, Wächter); der Sniper-Test setzt das Maximum unter das günstigste Angebot;
  die Überlappungsprüfung meldet nur Fenster, die AHSentinel selbst platziert (von dir verschobene Fenster und
  unsichtbare Rahmen anderer Addons sind Hinweise).

## 0.65.59
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Korrektur: Buchhaltung → Rendite (Gold pro Stunde) brach mit einem Lua-Fehler ab** („compare nil with number“): Der
  Tagesbeginn wird jetzt ohne time(tabelle) gerechnet, das im Client für „Alles“ nichts zurückgibt. Gleiche Korrektur für
  die Zeiträume der Buchhaltung, das Gold-Diagramm, die Tageszahlen des Snipers und den Raid-Hinweis.
- **Schneller:** Marktliste und „Heute tun“ stocken bei 5000+ Items nicht mehr kurz – sie werden zwischengespeichert und
  nach einem Scan bzw. einer Datenänderung im Hintergrund in kleinen Portionen neu gerechnet (das Fenster aktualisiert sich).
- **Gewinn-Fenster und Beste Rezepte:** „Beste Rezepte“ baut nach dem Herstellen wieder neu auf (Tascheninhalt zählt als
  Änderung); das Gewinn-Fenster liegt nie über dem Berufsfenster, auch nicht über dessen unsichtbarem Rand.
- **Tooltips der AHSentinel-Fenster** erscheinen neben dem Fenster statt über seinen Knöpfen.
- Verkaufs-Meldung: Die Textvorlage des Spiels steht einmal im Diagnose-Protokoll (ohne Namen).
- Testroutine: Während eines Laufs werden keine echten Daten mehr geändert (Aktivität, gemerkte Rezepte, Stück je
  Auktion); der Sniper-Test wertet nur sein eigenes Ziel und zeigt Preis, Max und Einheit; neue Tests (Angebot 2c bei Max
  1c -> kein Treffer; Tagesbeginn ohne time(tabelle)); veraltete Tests angepasst (Verkaufs-Meldung mit „%1$s“, Sync-Empfang,
  Tooltip-Prüfung je Sprache, eigenes Testfenster bei der Überlappung ausgenommen, API-Ereignisse).

## 0.65.58
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Preis-Sync erreicht Spieler ausserhalb der Gilde (GoldSentinelSync 2, Flüster-Netz):** AHSentinel nutzt jetzt
  Version 2 der gemeinsamen GoldSentinel-Sync-Datei. Neben Gilde und Gruppe erreicht es andere Spieler mit
  GoldSentinel-Addons per Flüstern; diese geben weiter. Bekannte Mitspieler werden nur lokal gemerkt (AHSentinelDB.gsSync,
  nur Namen und Zeiten).
  - **Was ins Netz geht:** nur Preise nach deinem eigenen Scan, gebündelt – die meistgehandelten Items zuerst, höchstens
    20 Nachrichten und höchstens alle 30 Minuten (das Netz schickt höchstens 40 Flüsternachrichten pro Minute).
  - **Nur Gilde/Gruppe:** die ganze Preisliste, Antworten auf Preis-Anfragen, Item-Namen und Entzauber-Ergebnisse.
  - „Nur Gilde“ in den Optionen hält alles in der Gilde (nichts geht ins Netz).
- **GoldSentinelTest 2:** Fehlerberichte an den Entwickler teilen (nur mit Zustimmung, /gstest).
- Diagnose-Protokoll: neue Zeile „NETZ“ (ohne Spielernamen).

## 0.65.57
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Ein Mindestgewinn für alles:** Der automatische Mindestpreis beim Verkaufen und AHSentinel.API.MinProfitPct nehmen
  jetzt deine Einstellung „Mindestrendite“ (wie „Lohnt bis“ im Tooltip, Standard 20 %).
- Für Addon-Autoren: API.Price meldet „scan“ nur, wenn der Wert wirklich aus dem letzten Scan stammt („market“, wenn ein
  Ausreisser durch den Median ersetzt wurde). API.md entspricht dem geklärten Vertrag (MaterialCost = Herstellkosten des
  Produkts, „vendor“ ist kein AH-Preis).
- Texte: Beim Abbrechen ist die Einzahlung weg (auch in WoW Forever); der Tooltip „je Auktion“ im Gewinn-Fenster zeigt die
  gemessene Mindest-Einzahlung statt fest 1s.
- Testroutine: neue Tests für den ganzen Tooltip (mit/ohne Shift, nicht entzauberbar), „echt aus 12 Entzauberungen“, Quelle
  im Materialblock, „Kauf gesendet“ über den echten Bestätigen-Weg, kein Flip-Vorschlag für Items, die sich kaum verkaufen,
  und höchstens 3 Neuaufbauten von „Beste Rezepte“ beim Herstellen.

## 0.65.56
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Testroutine: Sync-Tests nur noch mit Gilden-Nachrichten (nirgends mehr Kanal-Nachrichten im Addon).

## 0.65.55
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Preis-Sync geht wieder (WoW Forever):** Addon-Nachrichten in eigenen Chat-Kanälen kommen in Forever nie an (der
  Server verweigert sie). AHSentinel benutzt seinen Kanal „AHAPSync“ nicht mehr – verlässt ihn einmal (frei werdender
  Kanalplatz) und teilt Preise, Item-Namen und Entzauber-Ergebnisse nur noch über **Gilde und Gruppe/Raid**, in allen
  Spielversionen. Dafür die gemeinsame GoldSentinel-Datei GoldSentinelSync.lua (wie die anderen GoldSentinel-Addons);
  Nachrichten älterer AHSentinel-Versionen werden weiter verstanden.
- Ehrliche Anzeige: „Sync über Gilde: N Mitspieler“ bzw. „niemand mit AHSentinel online“.
- Neu: **/ahs sync test** – fragt Gilde und Gruppe an und zeigt „N Antworten (Gilde a, Gruppe b)“.
- Diagnose-Protokoll: Sync-Weg, gesendet/empfangen/verworfen und verweigerte Kanal-Nachrichten.

## 0.65.54
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper in vollem Tempo:** Solange der Sniper-Modus AN ist und offene Ziele hat, pausiert der Wächter (kein Abwechseln
  mehr). Der Wächter läuft, wenn der Sniper aus ist oder keine Ziele hat; Wächter-Schnäppchen lassen sich weiter kaufen.
- **Ziele nach Ertrag:** Ziele mit Treffern in den letzten 10 Minuten werden öfter gesucht, Ziele ohne Treffer höchstens
  jede dritte Runde. Kein Ziel fällt heraus.
- **Gemessen:** Der Sniper zeigt „Heute: N Treffer · N gekauft · N verpasst · Ø Reaktion X s“, der Tooltip eines Ziels
  Treffer und Kaufquote. Ab 10 Treffern und unter 20 % gekauft: „Hier sind andere schneller – anderes Ziel wählen?“
  (gelbes „!“). Im Diagnose-Protokoll eine SNIPER-Zeile je Minute mit den Zeiten je Schritt (ohne Namen).

## 0.65.53
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper schneller, weiter nach den Regeln:** Jeder Kauf braucht weiterhin einen echten Tastendruck bzw. eine
  Mausrad-Raste – der Sniper reserviert oder kauft nie aus einem Timer (der alte „Sofortkauf“, der ohne Tastendruck
  vorab reserviert hat, ist weg).
  - Einfach weiterscrollen: Jede Raste macht den nächsten Schritt. Rasten, während der Preis geprüft wird, werden still übergangen.
  - Bestätigen ist nur 0,05 s gesperrt (Reservieren weiter 0,3 s).
  - Suchen gleichmässig verteilt (höchstens 90 pro Minute) statt erst alle auf einmal und dann Stillstand.
  - Waren-Treffer gelten nur 3 s als aktuell; ältere werden neu gesucht statt reserviert.
  - Reserviert werden nur Stücke bis zu deinem Max-Preis; liefert der Server weniger, wird genau diese Menge gekauft.
  - Ein anderer AH-Fehler (z. B. von einer Suche) bricht einen laufenden Kauf nicht mehr ab.
- AH-Anteil wie gemessen abgerundet (6279 → 313).

## 0.65.52
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung (WoW Forever): Verkäufe nicht mehr doppelt gebucht.** Nach dem Abholen des Goldes wurde dieselbe
  Verkaufsrechnung noch einmal als neuer Verkauf gelesen (Menge doppelt, Einnahmen −5 %). Der Schlüssel der Rechnung
  enthält das Post-Gold nicht mehr, und eine Rechnung ohne Gold wird nie neu gebucht, wenn sie schon gebucht ist.
  Gesamt = Feld „bid“ der Rechnung (Gegenprobe Gold + AH-Anteil − Einzahlung, solange das Gold noch in der Post ist).
  Vorhandene Doppelbuchungen werden beim Einloggen einmal entfernt („Buchhaltung: N doppelte Verkäufe entfernt“) und
  als Sicherung aufgehoben.
- Diagnose-Protokoll: Die Anzahl Items der Preisdaten stimmt jetzt mit der Statuszeile überein (war nach dem Ausloggen 0).

## 0.65.51
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Gewinn-Fenster und ProfessionSentinel:** Solange das Panel von ProfessionSentinel offen ist, blendet sich das
  Gewinn-Fenster von AHSentinel aus (ProfessionSentinel zeigt dieselben Zahlen über AHSentinel.API) und kommt zurück,
  wenn das Panel schliesst.
- **Sniper-Hinweis „Jetzt kaufen“:** nur noch einmal, höchstens 2 Sekunden, oberhalb der Aktionsleisten statt doppelt in
  der Bildschirmmitte über offenen Fenstern.

## 0.65.50
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Für Addon-Autoren – öffentliche Schnittstelle `AHSentinel.API` (Version 1):** global `AHSentinel.API`, Alias
  `AHAnalyzerPro.API`. Funktionen: `Price`, `NetSale`, `Deposit`, `CutPct`, `MaterialCost`, `DisenchantValue`, `BestWay`,
  `SellSpeed`, `MinProfitPct`, `GoldPerHour`, `LastScan`, `Subscribe` (ruft `fn("scan"/"ledger"/"settings")`, höchstens
  einmal je 2 s). Jede Funktion ist sicher (nie ein Lua-Fehler, `nil` wenn unbekannt), Beträge in Kupfer. Einzelheiten in
  `API.md`. Die alten Funktionen (RealPrice, RealValue, AuctionFee, AHFee, ForeverAuctionFee, GetMarketValue, GetCurrent)
  bleiben.
- Automatischer Mindestpreis beim Verkaufen: Mindestgewinn jetzt 20 % (gleicher Standard wie die Schnittstelle).

## 0.65.49
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung → Rendite:** neue Ansicht mit eingesetzt, erlöst, Gewinn und Rendite je Geschäftsart – Flippen (Kauf
  und Verkauf desselben Items), Herstellen (hergestellte Items gegen Materialkosten), Entzaubern (vorhandene Abrechnung)
  und Rohstoffe (Verkauf ohne Kauf). Ein Verkauf zählt zum Geschäft, aus dem das Item stammt, und zu dessen Tag – nicht
  zum Eingang der Post.
- **Gold pro Stunde** je Geschäftsart und gesamt, dazu „Dein Stundenlohn heute“. Es zählt nur aktive Zeit (nur lokal
  gespeichert): am AH und Briefkasten die Zeit zwischen deinen Handlungen, nach der letzten höchstens 2 Min.; Herstellen und
  Entzaubern vom ersten bis zum letzten einer Serie. Pausen über 2 Min., AFK und automatische Scans/Sniper-/Wächter-Läufe
  zählen nicht. Unter 15 Min. gemessen: „zu wenig Daten“. Verlust steht rot mit Minus.
- **Raid-Hinweis:** ab 25.11. höchstens einmal am Tag beim Öffnen des AH: „Raid-Start 9.12.: Verbrauchsgüter und ihre
  Kräuter jetzt günstig einkaufen/herstellen.“ Nach dem 9.12. aus.

## 0.65.48
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Automatischer Mindestpreis beim Verkaufen:** das Höhere aus Händlerpreis nach AH-Anteil und deinen eigenen Kosten
  je Stück (Einkäufe der letzten 30 Tage, sonst Herstellkosten) + 5 %. Ein von Hand gesetzter Mindestpreis hat Vorrang.
  Liegt die Konkurrenz darunter, schlägt das Addon den Mindestpreis vor, mit gelbem Hinweis „Markt liegt unter deinem
  Mindestpreis – einstellen zum Mindestpreis oder warten“ (und „Preis fällt“, wenn der 24-Std.-Trend unter −10 % liegt).
  Du entscheidest – das Preisfeld bleibt frei.
- **3× in Folge abgelaufen:** Im Reiter Verkaufen ein gelber Hinweis mit billigerem Vorschlag, Händlerpreis und den bisher
  verlorenen Einzahlungen. Automatisch passiert nichts.

## 0.65.47
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Abbrechen nur, wenn es sich lohnt:** Eine unterbotene Auktion wird nur zum Abbrechen vorgeschlagen, wenn neu
  Einstellen mehr bringt als die verlorene Einzahlung plus das Risiko der neuen. Eine 1c-Unterbietung steht jetzt grau
  als „unterboten – liegen lassen“, „Nächste unterbotene abbrechen“ überspringt sie. Der Tooltip der Zeile zeigt die Rechnung.
- **Höchstens 90 Suchen pro Minute (WoW Forever):** Alle Suchen (Sniper, Wächter, Scan, Einkauf, Preis prüfen) teilen
  sich ein Fenster von 60 Sekunden unter der Server-Grenze von 100; der Sniper hat Vorrang.
- **Neutrales Auktionshaus (Beutebucht, Gadgetzan, Ewige Warte): 15 % statt 5 %** beim Verkauf – überall, wo der
  Anteil gerechnet wird. Eine Formel-Einzahlung dort steht als „(unsicher)“, bis sie gemessen ist.
- **Sniper:** Liegt dein Max/Stück über dem Netto-Verkaufswert (letzter Scan minus Anteil und Einzahlungsrisiko),
  zeigt ein gelber Hinweis den erwarteten Verlust je Stück. Gesperrt wird nichts.

## 0.65.46
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Mindest-Einzahlung wird gemessen statt fest (WoW Forever):** Blizzard hat angekündigt, das Minimum je Auktion von
  1s auf 1c zu senken. AHSentinel baut 1s nicht mehr fest ein: Die Einzahlung kommt immer zuerst von Blizzard, die
  Formel ist nur Ersatz, und ihr Minimum wird beim Einstellen gelernt, wenn die Formel unter 1s liegt (Protokoll
  „MINDESTEINZAHLUNG gemessen=…“). Sobald 1c gemessen ist, fällt die Vorbelegung „24 Std. kostet gleich viel“ von selbst weg.
- Gewinn-Fenster: Die Zeile AH-Gebühr rechnet kein 1s-Minimum mehr (nur 5 % beim Verkauf – die Einzahlung kommt zurück).

## 0.65.45
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.45** – Buchhaltung korrigiert, Werte aus dem letzten Scan 🔧

• **Buchhaltung:** In der Forever-Rechnung steht im Feld „Preis“ die **Menge**. 0.65.42–0.65.44 haben Menge und Stückpreis vertauscht (z. B. 91 Stück zu 1s 84c statt 184 zu 91c). Das ist behoben, alte Verkäufe werden **einmal korrigiert** – nichts wird gelöscht.
• **Werte aus dem letzten Scan:** Gerechnet wird mit dem günstigsten Angebot deines letzten Scans – ohne Abzug, ohne Deckel. Nur offensichtliche Ausreisser (z. B. 1 Stück zu 1c) und Items, die im Scan fehlen, nehmen den Markt-Median. Dein eigener Ø-Verkaufspreis ist nur noch Statistik (Shift).
• Materialien im Tooltip zeigen die Quelle („Scan“ / „Markt“).

## 0.65.44
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.44** – Tooltip übersichtlich, Sniper ehrlich ✨

• **Tooltip in drei Blöcken:** **Preis** (mit „Verkauft sich: schnell/langsam/kaum“), **Urteil** („Entzaubern lohnt sich/nicht“, „Lohnt bis“, beide Wege mit Betrag) und **Materialien** mit echten Chancen – immer, auch mit Disenchantry. Alles andere mit **Shift**.
• **Sniper:** „Kauf gesendet“ beim Bestätigen, **„Gekauft“ erst, wenn der Server es bestätigt**. „Preis wird geprüft“ nur einmal. Ist der Preis bestätigt: kurzer Ton, der Kaufen-Knopf blinkt und „Jetzt kaufen: Mausrad“ erscheint.
• **Sammelkauf** zählt erst nach dem erfolgreichen Kauf.
• **Gewinn-Fenster:** „AH-Gebühr“ zeigt nur die 5 %, Neu-Einstellungen bzw. „Händler zahlt mehr“ in einer grauen Zeile.
• Schneller bei grosser Buchhaltung.

## 0.65.43
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.43** – Laufzeit und Verkaufsdauer ⏱️

• **Verkaufen:** Die **Laufzeit ist vorbelegt** – 24 Std., wenn es nicht mehr kostet (z. B. Staub, Stoff, Kräuter), sonst nach deiner Verkaufsdauer. Der Grund steht darunter; du kannst sie wie bisher ändern.
• **Tooltip:** „Verkauft sich: **schnell** (~3 Std.)“, „**langsam** (~2 Tage)“ oder „**kaum** (läuft oft ab)“ – gemessen aus deiner Buchhaltung.
• Was sich bei dir kaum verkauft, wird bei „Heute tun“ nicht mehr vorgeschlagen.

## 0.65.42
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.42** – Gebühren wie im klassischen WoW 🪙

• **Gemessen in Forever:** Beim Einstellen zahlst du eine **Einzahlung** (Händlerpreis × Menge × 5 % je 2 Std., mind. 1s je Auktion). Beim Verkauf gehen **5 %** ab und die **Einzahlung kommt zurück**. Läuft eine Auktion ab, ist die Einzahlung weg – das rechnet AHSentinel jetzt ein.
• **Buchhaltung:** Forever-Rechnungen werden richtig gelesen (Stückpreis, Menge). Alte Verkäufe werden **einmal neu berechnet** – nichts wird gelöscht.
• **Tooltip:** beide Wege mit Betrag, der bessere zuerst: „Entzaubern: 9s 35c“ / „Verkaufen: 8s 99c“.
• **Kein Ruckeln mehr** beim Herstellen („Beste Rezepte“ rechnet seltener und verteilt).

## 0.65.41
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.41** – sehen, ob es sich lohnt 🟢🔴

• **Tooltip:** statt Rechnung ein **farbiges Urteil**: grün „Entzaubern lohnt sich +2s 85c“, rot „Entzaubern lohnt nicht −65c“ oder grau „unsicher“ – darunter **„Lohnt bis 7s 79c“**. Materialien und Rechnung nur mit **Shift**.
• **Gewinn-Fenster:** Materialien über den **günstigsten Weg** (AH, Händler oder selbst herstellen, z. B. Leinenstoffballen aus Leinenstoff). Die Einkaufsliste kauft genau diese Zutaten.
• **Gewinn über den besten Weg:** Verkaufen oder Entzaubern – darunter „bester Weg: …“ und der andere Weg mit Betrag. „Beste Rezepte“ sortiert danach.

## 0.65.40
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.40** – Buchhaltung repariert 🧾

• Verkäufe von **vor 0.65.35** hatten in Forever die Gebühr doppelt abgezogen (z. B. negative Einnahmen „Heute“). Sie werden beim Einloggen **einmal korrigiert** – nichts wird gelöscht. Im Chat: „Buchhaltung: N alte Verkäufe korrigiert“.

## 0.65.39
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.39** – Feinschliff 🧹

• **Kategorien mit drei Ebenen** wie im Blizzard-AH (z. B. Waffen → Einhändig → Äxte).
• **Post an Twinks:** Kategorie per **Menü** wählen statt durch über 50 Einträge zu klicken.
• **Verkaufen:** Preis über dem 100-fachen Marktwert → Rückfrage (Tippfehler? Zahl ohne Zeichen = Gold).
• **Heute tun → unter Händlerpreis:** aus Scan/Suche wird mit **1 Stück** gerechnet – keine zu hohen Gewinne mehr.
• **Entzauber-Ergebnisse teilen:** grosse Statistiken kommen ganz an.
• **Spieltest** übersetzt; S7 zählt nur echtes Herstellen. Testroutine ersetzt keine Blizzard-Funktionen mehr.

## 0.65.38
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.38** – Werte, denen du trauen kannst 🎯

• **Nicht verkaufen kostet:** In Forever kostet jedes Einstellen die Gebühr. Der reale Wert zieht jetzt die erwarteten **Neu-Einstellungen** ab – aus deiner eigenen Verkaufsquote, sonst aus dem Absatz am Markt. Shift im Tooltip zeigt es.
• **Herstellen:** Eigene Materialien zählen mit dem, was du beim Verkauf bekämst; fehlende zum Sofortpreis, Händlerware zum Händlerpreis.
• **Vorhersage gegen Wirklichkeit:** Buchhaltung → Statistik zeigt **„Werte im Schnitt N % zu hoch/tief“** – je Item-Gruppe und gesamt.
• **Halbe Scans** gelten nie als vollständig, fehlende Items gelten nicht als weg.
• **Geteilte Preise** zählen nur, wenn sie zu deinen passen oder ein zweiter Mitspieler sie bestätigt.

## 0.65.37
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.37** – eigenes Entzauber-Fenster ✨

• **Kleines Entzauber-Fenster** (`/ahs entzaubern` oder Kaufen → „Entzaubern lohnt“ → „Entzauber-Fenster“): nächstes Teil mit Symbol, **„noch N“**, Knöpfe **Entzaubern / Überspringen / Statistik**.
• **Zuerst die gekauften Teile** aus dem Sammelkauf, dann die übrigen. Nach einem Sammelkauf öffnet es sich beim Schliessen des AH einmal von selbst.
• **Ein Klick = ein Teil** (sicherer Knopf, im Kampf gesperrt).
• **Schutz:** nie Set-Teile, Quest-Gegenstände oder Teile auf der Sperrliste (Rechtsklick aufs Symbol). Blaue/violette Teile und Teile, die sich deutlich besser verkaufen, erst nach **„Freigeben“**.
• **Statistik:** Entzauberungen heute/gesamt, Materialien und ihr Wert.
• **Buchhaltung → Entzaubern:** je Tag und gesamt: ausgegeben, Wert der Materialien (schon verkauftes zum echten Erlös), **Gewinn** und **Rendite %**. Eigene Teile getrennt, noch nicht entzauberte als „offen“.

## 0.65.36
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.36** – Entzauber-Wächter 🔮

• Ist der **Schnäppchen-Wächter** an, sucht er bei offenem AH jede zweite Runde **Waffen und Rüstung**, die sich zum Entzaubern lohnen (gleiche Grenzen wie „Entzaubern lohnt“).
• Neue Funde meldet er einmal: **„N Teile mit über X % Rendite verfügbar“** – im Chat und auf dem Bildschirm, höchstens einmal pro Minute, nie im Kampf.
• Er **kauft nie selbst** – gekauft wird wie bisher unter Kaufen → „Entzaubern lohnt“. Abschalten mit dem Knopf **„Wächter-Meldung: AN/AUS“**.

## 0.65.35
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **AH-Gebühr im Gewinn-Fenster – eine sichtbare Annahme:** Die Gebühr hängt davon ab, wie viele Stück du je Auktion
  einstellst (mindestens 1s je Auktion). Das Fenster sagt es jetzt: "bei N Stück je Auktion (gelernt / selbst gewählt
  / vorsichtig)". Gelernt aus deinen eigenen Einstellungen (Median der letzten 10); ohne Daten 1 Stück. Klick darauf
  wechselt 1 / 5 / 20 (Stapel) / automatisch, gemerkt je Item. "Beste Rezepte", "Heute tun" und andere Addons rechnen
  mit derselben Annahme. Das Fenster springt nicht mehr zwischen zwei Rechnungen, wenn Item-Daten spät nachladen.
  (Beispiel: 1 Wollstoffballen zu 3s 97c, Material 3s 42c: Gebühr 1s, Verlust 45c; bei 20 je Auktion: 20c, +35c.)
- **Verkaufen: Menge = alles aus den Taschen** (nicht mehr die letzte Menge). Die Zahl änderst du selbst.
- **Buchhaltung (WoW Forever):** Ein Verkauf wird mit dem Gold gebucht, das die Post wirklich bringt – die Gebühr ist
  schon beim Einstellen gebucht, darum werden keine zweite Gebühr und keine Erstattung abgezogen. Die Werte der
  Rechnung gehen ins Diagnose-Protokoll (RECHNUNG). Abbrechen bucht jetzt die gemessene Erstattung. Era/TBC unverändert.
- Spieltest: neue Prüfung S10 – AH-Gebühr von AHSentinel = Blizzards "Einzahlen" bei gleicher Menge.

## 0.65.34
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sammelkauf zum Entzaubern** (Reiter Kaufen → Einkauf): Der Knopf "Entzaubern lohnt" unter den Kategorien zeigt aus
  deiner Suche nur Teile (Rüstung/Waffen), deren Entzauberungswert den Preis um die Mindestrendite übersteigt, mit
  mindestens 10c Gewinn je Teil – nach Gewinn sortiert, mit Spalten Entzauberungswert, Gewinn und Rendite %.
  - Jede Mausrad-Raste über der Liste oder "Nächstes kaufen" kauft das nächste Teil von oben (die erste Raste lädt
    dessen Angebote). Vor jedem Kauf: Angebot noch da und nicht teurer – sonst übersprungen.
  - Grenzen: "höchstens X Gold" (Standard 5g) und "Rendite ab X %" (Standard 20 %). Stopp bei der Grenze, bei vollen
    Taschen oder im Kampf. Unter 10 echten Entzauberungen der Gruppe zählt der Wert 10 % weniger.
  - Statuszeile: "Gekauft N · bezahlt · erwartet +Gewinn". Nur auf deinen Klick/deine Raste, nie automatisch;
    Protokoll KAUF (ohne Namen). Kein Fertigkeits-Filter – in WoW Forever ist ab Verzauberkunst 1 alles entzauberbar.

## 0.65.33
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **AH-Gebühr im Gewinn-Fenster korrigiert:** Die Gebühr pro Stück ging davon aus, dass du immer einen vollen Stapel
  einstellst (z. B. 20 Wollstoffballen), und teilte die Mindestgebühr 1s durch 20 – so zeigte 1 Ballen zu 3s 98c 20c
  statt der echten 1s. Jetzt richtet sich die Gebühr danach, wie viele Stück du dieses Item zuletzt auf einmal
  eingestellt hast; ohne Erfahrung 1 Stück (volle Mindestgebühr 1s).

## 0.65.32
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzauber-Tabelle aus Disenchantry:** Die Tabelle folgt jetzt Disenchantry 1.1.2 (MIT-Lizenz, Copyright (c) 2026
  x_Raven_x; Lizenztext in LICENSE-Disenchantry.txt), Grundlage warcraft.wiki.gg: Itemstufe 5–15 ohne Splitter (80/20),
  21–25 Rüstung 75/15/10, 51–65 Waffen 75/22/3, **WoW Forever: grüne Waffen Itemstufe 21–30 geben Grosse
  Magieessenz**, blaue Items ab Itemstufe 1 und bis 80, epische bis 88. Gruppen nach Itemstufe (wie in der Tabelle),
  nicht nach benötigter Stufe.
- Der Materialblock zeigt jetzt die Mengen aus der Tabelle ("1–2×"), aus echten Entzauberungen den Durchschnitt.
- **Disenchantry geladen:** AHSentinel zeigt keinen zweiten Materialblock.

## 0.65.31
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Ein Preis für alles:** AHSentinel bewertet jedes Item jetzt mit EINER Funktion – Tooltip, Gewinn-Fenster (Ergebnis
  und Materialien), Schnäppchen, Flips, "Heute tun", Entzaubern (Block und Wert), Inventarwert und der Vergleich mit dem
  Händler zeigen für dasselbe Item denselben Wert. Reihenfolge der Quellen: eigene Verkäufe der letzten 14 Tage, dann
  knapp unter dem günstigsten aktuellen Angebot (höchstens der Median), dann der Median 14 Tage. Angebote unter 10 % oder
  über 300 % des Medians zählen nicht. Bei Schnäppchen und Flips gilt das billige Angebot selbst nicht als Wiederverkaufswert.
- **Realer Wert im Tooltip:** neue Zeile "Realer Wert (nach Gebühren)" mit Quelle (eigener Verkauf / AH aktuell / Markt /
  Händler) und "Preis alt" nach 6 Stunden; mit Shift jeder Bestandteil (eigener Verkauf, günstigstes Angebot, Median, Gebühr).
- **Händlerpreis als Untergrenze:** Zahlt ein Händler mehr als das Auktionshaus nach Gebühren, gilt der Händlerpreis.
- Andere Addons (ProfessionSentinel) können dieselben Werte nutzen: `AHAnalyzerPro:RealPrice(itemID)` und
  `AHAnalyzerPro:RealValue(itemID, Menge)`; das alte `GetSalePrice` liefert jetzt denselben Wert.

## 0.65.30
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Preise je Server und Fraktion:** AHSentinel führt jetzt für jeden Server und jedes Auktionshaus eine eigene
  Preisliste – Horde, Allianz und die neutralen Auktionshäuser (Beutebucht, Gadgetzan, Ewige Warte). Eigene Scans und
  geteilte Preise landen nur in der Liste des Auktionshauses, an dem du stehst; Tooltips und Rechnungen nehmen die Liste
  deiner Fraktion (am neutralen Auktionshaus die neutrale).
- **Sync nur vom selben Auktionshaus:** Preis-Nachrichten tragen jetzt eine Kennung von Server und Fraktion; Preise
  einer anderen Fraktion oder eines anderen Servers und alte Nachrichten ohne Kennung werden verworfen. (Bitte
  aktualisieren – ältere Versionen tauschen mit 0.65.30 keine Preise mehr.)
- Deine bisherigen Preise bleiben für Server und Fraktion des aktuellen Charakters. Hast du Charaktere auf mehreren
  Servern oder Fraktionen, weist ein Hinweis darauf hin, dass die alten Preise gemischt sein können – der nächste Scan
  ersetzt sie.

## 0.65.29
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzauberungswert statt "Gewinn":** Die Tooltip-Zeile heisst jetzt "Entzauberungswert ~X (T)" – er hängt nur von
  der Gruppe ab (Qualität, Itemstufe, Rüstung/Waffe) und ist für alle Items dieser Gruppe gleich. Neu darunter:
  "Gewinn beim Kauf: Wert − Kaufpreis" (grün/rot) mit dem Preis der Zeile, auf die du im Addon zeigst (Kaufliste,
  Sniper, Schnäppchen), beim Händler dessen Preis, sonst das günstigste aktuelle Angebot. In der Kaufliste steht
  "[Entzaubern lohnt]" nur, wenn Wert − Preis positiv ist.
- **Materialblock passt zum Wert:** Block und Wert rechnen jetzt mit demselben Preis je Material – eigene Verkäufe der
  letzten 14 Tage, sonst knapp unter dem günstigsten aktuellen Angebot (höchstens der Median), sonst der Median. Die
  Quelle steht dabei ("AH aktuell" / "Markt" / "eigener Verkauf"). Angebote unter 10 % oder über 300 % des Medians
  zählen nicht ("Angebot unsicher") – z. B. 22c für eine Grosse Mystikeressenz.
- **Entzauberungen teilen:** nach 10 neuen oder spätestens 2 Minuten nach der letzten, und beim Ausloggen.

## 0.65.28
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Öffnet mit dem Auktionshaus:** Das AHSentinel-Fenster öffnet sich, wenn du das Auktionshaus öffnest, und schliesst
  sich wieder mit ihm. War es vorher schon offen, bleibt es offen. Einstellung "Mit dem Auktionshaus öffnen und
  schliessen" (ab Werk an). Im Kampf drängt es sich nie auf.
- **Fenster immer im Bildschirm:** Das Hauptfenster bleibt ganz im Bildschirm – höchstens 90 % davon, Position an den
  Rand geklemmt, auch nach Änderung der UI-Skalierung oder Auflösung.
- **Sniper in WoW Forever:** Waren kaufst du mit zwei Rasten – 1. Raste reserviert den Preis, 2. Raste kauft (WoW
  Forever erlaubt die Reservierung nur mit Tastendruck). Die Statuszeile sagt das jetzt ("1. …: Preis reservieren ·
  2. …: kaufen", danach "Reserviert – nochmal … zum Kaufen (10 s)"), auch während der Sniper weitersucht; Hilfe und
  Tooltips angepasst. Die Gesamtzeile unter der Liste verschwindet beim Weitersuchen nicht mehr. Era/TBC unverändert.
- Spieltest: neue Prüfung S9 (Fenster öffnet und schliesst mit dem Auktionshaus).
- Testroutine (Entwickler): Prüfungen, die in diesem Client nicht gehen (kein BugSack, fehlende Item-Daten, kein echtes
  Layout), zählen als übersprungen, nie als OK oder FEHLER.

## 0.65.27
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzauber-Tabelle korrigiert** (Quelle: warcraft.wiki.gg, Classic-Entzaubertabellen): grüne Items bis Itemstufe
  15 geben keinen Splitter – Rüstung 80 % Staub / 20 % Essenz, Waffen 20 % / 80 %. Itemstufe 21–25 jetzt 75/15/10
  (Waffen 15/75/10), Itemstufe 51–65 Waffen 22/75/3; die übrigen Stufen bleiben 75/20/5.
- Materialien, die aus einer Gruppe nicht kommen können (z. B. ein Splitter aus Itemstufe 15), zählen nicht mehr mit –
  weder eigene (falsch erkannte) noch geteilte Ergebnisse.

## 0.65.26
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzaubern im Tooltip, kürzer:**
  - Eine Zeile "Entzaubern: erwarteter Gewinn ~X" (Wert nach Gebühren) mit kleinem Vergleich ("lohnt mehr als
    Verkauf" / "Verkauf bringt mehr") und der Quelle: "(Ø 12)" = aus 12 echten Entzauberungen (ab 10), "(T)" = Tabelle.
  - Darunter ein Block "Entzaubern – Materialien (AHSentinel)": Icon, Name, Dropchance und Wert pro Stück
    (AH-Preis aus dem letzten Scan, sonst Marktwert).
  - Mit gedrückter Shift-Taste erscheint die ganze Rechnung (tatsächlich und geschätzt, je Material, nach Gebühren).
  - Einstellung "Entzauber-Details im Tooltip": kurz / mit Materialien (Standard) / alles.
- **Entzauber-Ergebnisse mit allen AHSentinel-Nutzern teilen:** Jedes Entzaubern auf jedem Charakter wird
  automatisch gezählt (Twinks zählen als eigene) und über den öffentlichen Sync-Kanal geteilt ("nur Gilde" bleibt als
  Einstellung). Schutz: höchstens 6 Nachrichten je Absender und Minute, Materialien müssen zur Gruppe passen, 1–5
  Stück je Entzauberung, keine Sprünge, doppelte Meldungen zählen einmal. Absender werden nur als Kürzel gespeichert,
  nie mit Namen.

## 0.65.25
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Post abholen:** "Post abgeholt" zeigt jetzt das wirklich abgeholte Gold (z. B. 1g 56s 26c) statt 0. Das Spiel
  schreibt das Gold oft erst nach der Briefkasten-Aktualisierung gut; das Addon zählt jetzt den Betrag jeder abgeholten
  Post mit.
- "1 neue Rechnungen" → "1 neue Rechnung".

## 0.65.24
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Spieltest S5** prüft jetzt nur noch, was er soll: das Gewinn-Fenster gegen das Berufsfenster und ProfessionSentinel.
  Vorher zählte er auch das Hauptfenster über dem Auktionshaus, LevelPilot und unsichtbare Anker anderer Addons mit
  und meldete fälschlich FEHLER.

## 0.65.23
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Spieltest:** `/ahs spieltest an` – AHSentinel prüft die Test-Checkliste im Spiel selbst, sobald du die Lage
  herstellst, und meldet nur, was nicht stimmt (eine Chat-Zeile je Prüfung). Er öffnet nie selbst Fenster, kauft,
  stellt ein oder stellt her und tut im Kampf nichts. Aktiv bis /reload oder 2 Stunden.
  - S1 Gebühr im Verkaufen-Reiter · S2 echte Gebühr nach dem Einstellen · S3 Gewinn-Fenster · S4 Entzaubern im
    Tooltip · S5 Gewinn-Fenster überdeckt nichts · S6 Händler-Knopf · S7 Neuaufbau beim Herstellen von 5 Gegenständen
    · S8 keine blockierten Aufrufe.
  - `/ahs spieltest bericht` zeigt OK / FEHLER / offen und was für die offenen noch zu tun ist. Die Ergebnisse gehen
    auch ins Diagnose-Protokoll und in den Testbericht für die Addon-Prüfung (Bereich S). Keine Namen.
- Übrig gebliebene Datei (TestRoutine.lua.orig) aus dem Download entfernt.

## 0.65.22
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzaubern im Tooltip – tatsächlich und geschätzt, klar getrennt:**
  - "Entzaubern tatsächlich (Ø aus N)": nur aus echten Entzauberungen dieser Gruppe (eigene + geteilte): Summe der
    wirklich erhaltenen Materialien × aktueller AH-Preis aus dem letzten Scan ÷ N. Unter 10 Entzauberungen steht
    "(wenig Daten)" dabei, ohne Entzauberung fehlt die Zeile.
  - "Entzaubern geschätzt (Tabelle)": der bisherige Wert (Tabelle verrechnet mit den Ergebnissen).
  - Je Material eine Zeile: Chance (bzw. tatsächliche Häufigkeit "x/N") × Ø-Menge · AH-Preis aus dem letzten Scan (mit
    Alter) · Marktwert = Anteil; darunter "nach Gebühren" (WoW Forever: AH-Gebühr 5 %, mind. 1s pro Auktion).
  - Der Tooltip sagt, mit welchem Wert die Entzauber-Schnäppchen rechnen: ab 10 Entzauberungen mit dem tatsächlichen
    Ø, sonst mit der Schätzung.
  - Neue Einstellung "Entzaubern: je Material" (Standard an).

## 0.65.21
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Gebührenregel WoW Forever:** In Forever gibt es nur EINE Gebühr – die AH-Gebühr = 5 % vom Preis der Auktion,
  mindestens 1 Silber, pro Auktion (pro Stapel), bezahlt beim Einstellen. Eine separate Einstellgebühr gibt es nicht
  mehr. Beispiele: 3s 90c → 1s, 2s → 1s, 1g → 5s, Stapel 20 zu je 1c → einmal 1s.
- Die Zeile "Einstellgebühr (nicht erstattet)" fällt im Gewinn-Fenster und beim Verkaufen weg; es gibt nur noch
  "AH-Gebühr (5 %, mind. 1s)". Überall gleich gerechnet: Gewinn-Fenster, Verkaufen, "Heute tun", Schnäppchen,
  Flips, Entzauber-Werte, Händler-Vergleich, Gewinnrechner.
- Beim Einstellen kommt die wirklich abgezogene Gebühr ins Diagnose-Protokoll (Eintrag EINSTELLEN: Preis, Menge,
  Gebühr), um die Regel im Spiel zu bestätigen. Die Messung der Einstellgebühr aus 0.65.17–0.65.20 ist entfernt. Die
  Warnung, wenn die Gebühr mehr als 10 % vom Preis ausmacht, bleibt.
- Era, TBC und Retail unverändert (5 % beim Verkauf, Einstellgebühr kommt beim Verkauf zurück).

## 0.65.20
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Berufsfenster:** Die Liste „Beste Rezepte“ baut sich beim Herstellen höchstens alle 2 Sekunden neu auf (bisher bis
  zu 190-mal pro Sitzung); Öffnen und Berufswechsel bleiben sofort.
- **Sniper (WoW Forever):** Der Sniper reserviert Waren nicht mehr selbst ohne Tastendruck. WoW Forever hat das
  geblockt (einmal pro Sitzung „Aktion blockiert“). Waren kaufst du mit 2 Rasten: die 1. reserviert, die 2. kauft.
  Blockt WoW das in einem anderen Client, merkt sich das Addon das für diesen Client, auch nach /reload.
- **Post an Twinks:** Eine Regel mit Unterkategorie greift jetzt auch nach /reload am Briefkasten, ohne vorher im
  Auktionshaus gewesen zu sein. Regeln aus 0.65.11–0.65.17 werden wiedergefunden.
- **Einkauf:** Die Kategorie-Liste behält beim Tippen und Suchen ihre Scroll-Position, die gewählte Kategorie bleibt
  sichtbar. Bis das Auktionshaus einmal offen war, zeigen Classic Era, TBC und WoW Forever die klassische Reihenfolge
  (mit Projektil, Köcher, Reagenz).
- **Verkaufs-Meldung:** geht auch, wenn der Spieltext einen nummerierten Platzhalter hat („%1$s“).
- **Berufsfenster:** Ohne Reiterleiste dockt das Gewinn-Fenster direkt neben dem Fenster an (beim alten Fenster nur
  über dessen unsichtbaren Rand), nie über Sichtbarem. Ein Klick auf ein Rezept schaltet „Ungelernte zeigen“ nicht
  mehr ein. In Classic Era und TBC keine Leerzeile mehr, wo in WoW Forever die Einstellgebühr steht.
- **Einstellgebühr:** Die Warnung sagt, wenn die Gebühr beim Verkauf erstattet wird (Classic Era, TBC …). Im Testmodus
  wird nichts gemessen, eine Schätzung des alten Auktionshauses zählt nie als Messung, das Gold wird kurz nach dem
  Einstellen noch einmal geprüft, und die letzten 300 Messungen stehen im Diagnose-Protokoll (nur Zahlen, keine Namen).
  „Heute tun – Herstellen“ zieht die Gebühr für die ganze hergestellte Menge ab.
- Tooltip des Preisfelds zeigt in jeder Sprache g/s/c.
- Testroutine (nur für den Entwickler): neuer Bereich K (Oberfläche im echten Client: Tooltips, überlappende Fenster,
  Bildschirm, Beschriftungen, plausible Werte, Fehlerschleifen, T191–T197) und Tests T198–T202; gemerkte Rezepte,
  Fensterpositionen und Wächter-Daten bleiben während der Routine unverändert.

## 0.65.18
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Händler-Knopf verdeckt nichts mehr:** Der Knopf „Verkaufen: … Items“ sass unter dem Händlerfenster und verdeckte
  den Reiter „Rückkauf“. Er sitzt jetzt oben rechts über dem Händlerfenster, nie bei den Reitern „Händler“ / „Rückkauf“.
- **Nur wenn es etwas zu verkaufen gibt:** Statt „Verkaufen: 0 Items (0)“ ist der Knopf dann ganz weg.
- **Ab Werk aus mit LevelPilot:** Ist LevelPilot geladen und verkauft dort graue Items selbst (Option ab Werk an), bleibt
  der Knopf aus, bis du ihn in den Einstellungen („Knopf beim Händler“) selbst einschaltest. Deine Einstellung gewinnt immer.
- Testroutine (nur für den Entwickler): T186 prüft im Spiel, dass der Knopf keinen Reiter des Händlerfensters verdeckt
  (sonst FEHLER), T187 die Werkseinstellung mit und ohne LevelPilot.

## 0.65.17
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Einstellgebühr wird gemessen:** Bei jedem Einstellen schreibt das Addon Item, Händlerpreis, Menge, Laufzeit, deinen
  Preis (pro Stück und gesamt), die Gebühr laut Spiel und die wirklich abgezogene Gebühr mit, dazu die Verhältnisse
  Gebühr/Preis und Gebühr/Händlerpreis – im Diagnose-Protokoll (`/ahs protokoll`, Eintrag EINSTELLEN) und im
  GSDIAG1-Export, ohne Namen. Nennt das Spiel keine Gebühr, gilt die zuletzt gemessene für dieses Item – nie geschätzt.
- **Warnung Einstellgebühr:** Macht die Gebühr mehr als 10 % vom Preis aus, ist zum Einstellen ein zweiter Klick nötig.
  Die Schwelle ist in den Einstellungen wählbar (aus / 5 / 10 / 20 / 30 %).
- **"Heute tun": unter Händlerpreis:** Angebote, deren Stückpreis unter dem Händlerverkaufspreis liegt (aus dem letzten
  Scan oder deiner aktuellen Suche), stehen als "Unter Händlerpreis: kaufen und beim Händler verkaufen" – Gewinn =
  (Händlerpreis − Kaufpreis) × Menge, ohne AH-Anteil. Erst ab 10 Silber Gewinn je Angebot (einstellbar: alle / 5s /
  10s / 50s / 1g), die besten 10, nach Gewinn sortiert. Items ohne Händlerpreis erscheinen nie, verschwundene Angebote
  werden ausgeblendet. Der Knopf kauft nur auf deinen Klick und sagt dann: beim Händler verkaufen.

## 0.65.16

- **Geschützte Werte:** Rezept-Auswahl und Diagnose-Protokoll übergehen geschützte Werte des Spiels, statt sie anzufassen.
- Testroutine (nur für den Entwickler), nach den bei LevelPilot bewährten Regeln: ehrliche Zählung (was im Client nicht prüfbar ist, zählt als übersprungen, nie als OK; der Bericht nennt „nicht automatisiert: N“ und listet alles, was im Spiel zu prüfen ist), jeder Fehler aus dem Spiel ist ein eigener Testfall (Rezept-Klick ohne vorherigen Klick, die 50 Sekunden), Köderwerte für geschützte Werte, das Test-Protokoll landet in einer Sandbox, Testfall-IDs sind eindeutig.

## 0.65.15

- **Diagnose-Protokoll:** `/ahs protokoll` öffnet ein Fenster mit markierbarem Protokoll – Version, Client, Sitzungen, geänderte Einstellungen, offene Fenster und wo das Gewinn-Fenster angedockt ist, dazu Einträge (neueste zuerst): KLICK (Rezept, Rezept-ID, Weg, Millisekunden, Erfolg), AUFBAU (Liste „Beste Rezepte“, Auslöser, Dauer), LANGSAM (jeder Schritt über 16 ms), ÜBERLAPPT (fremdes Fenster über dem Gewinn-Fenster) und FEHLER (gleiche nur gezählt). Beim Ausloggen wird es zusätzlich als „GSDIAG1“ für die Addon-Prüfung gespeichert. Keine Spieler-, Charakter-, Gilden- oder Realmnamen.

## 0.65.14

- **Berufsfenster (moderner Client):** Ein Klick auf ein Rezept in „Beste Rezepte“ wählt es sofort über die Rezeptliste des Berufsfensters und scrollt es in die Ansicht – im selben Moment, ohne auf einen Timer zu warten. Nur wenn das nicht geht, nimmt das Addon OpenRecipe des Spiels, prüft jeden Frame und meldet im Chat, wenn das Rezept nach 0,5 Sekunden nicht angezeigt wird.

## 0.65.13

- **WoW Forever – Gewinn am Berufsfenster:** Die Einstellgebühr (mindestens 1 Silber pro Auktion, wird nie erstattet) wird jetzt abgezogen und als eigene Zeile gezeigt: Gewinn = Wert × 0,95 − Material − Einstellgebühr (z. B. Kupferne Kettenhose 18c statt 1s 18c – gleich wie ProfessionSentinel). Die Liste „Beste Rezepte“ ist danach sortiert.
- **WoW Forever – Gebots-Schnäppchen** ziehen die Einstellgebühr fürs Weiterverkaufen ebenfalls ab.
- Classic Era, TBC und die anderen Versionen bleiben unverändert (dort kommt die Gebühr beim Verkauf zurück).

## 0.65.12

- **Berufsfenster – Klick auf ein Rezept in „Beste Rezepte“ öffnet es jetzt immer:**
  - Die Liste baut sich nicht mehr bei jedem Spiel-Ereignis neu auf: Ereignisse werden gesammelt, neu aufgebaut wird höchstens alle 0,4 s, nur wenn sich etwas geändert hat, und verteilt über mehrere Frames – ein Klick geht während des Aufbaus nicht mehr verloren.
  - Jede Zeile merkt sich ihr Rezept; beim Klick wird es im Berufsfenster neu gesucht. Verstecken es Suchtext, Filter oder eine zugeklappte Kategorie, werden diese zurückgesetzt und das Rezept trotzdem geöffnet.
  - Klappt es trotzdem nicht, kommt eine kurze Meldung im Chat.

## 0.65.11

- **Einkauf → Kategorien wie im Blizzard-Auktionshaus:** Jede Hauptkategorie hat jetzt ihre Unterkategorien (Waffen → Einhandäxte …, Rüstung → Stoff/Leder …, Verbrauchbares → Tränke …), mit Namen und Reihenfolge aus dem Spiel. Die Unterkategorien klappen unter der gewählten Hauptkategorie auf. Bis das Auktionshaus einmal offen war, nimmt das Addon die Item-Klassen des Spiels.
- **Preisfeld:** zeigt Gold/Silber/Kupfer immer als g/s/c („78c“, „3s 90c“), in jeder Sprache – nie mehr „k“, das wie „tausend“ aussah. Eingaben wie „78“, „78c“, „1s 20c“, „1g“ und das alte „78k“ gehen weiter.
- Für ProfessionSentinel: `AHAnalyzerPro.Crafting:GetDockFrame(true)` liefert das Gewinn-Fenster auch, solange es verborgen ist.

## 0.65.10

- **Berufsfenster (WoW Forever):** Das AHSentinel-Gewinn-Fenster verdeckt die Berufsreiter rechts am Berufsfenster nicht mehr – es dockt jetzt rechts neben der Reiterleiste an. Ohne solche Reiterleiste sitzt es wie bisher.

## 0.65.9

- **Berufsfenster:** neue Schnittstelle `AHAnalyzerPro.Crafting:GetDockFrame()` – liefert das sichtbare AHSentinel-Gewinn-Fenster neben dem Berufsfenster, sonst nil. ProfessionSentinel dockt damit rechts daneben an, statt darüber zu liegen. AHSentinel selbst bleibt direkt rechts am Blizzard-Berufsfenster.

## 0.65.8

- **Beschädigte gespeicherte Daten werden beim Einloggen repariert:** Einzelne kaputte Einträge (Preisverlauf, Charaktere, Sniper-Ziele, Buchhaltung, Einkaufslisten, Rezepte) werden entfernt, statt in einem Reiter oder Tooltip einen Lua-Fehler auszulösen. Gesunde Daten bleiben unverändert.
- Testroutine (nur für den Entwickler): zwei Prüfungen, die immer fehlschlugen, sind behoben (Wächter bei geschlossenem Auktionshaus, `/ahs scan` während der Routine); Optionen und Chat-Befehle laufen jetzt einzeln (kein „script ran too long“); viele weitere Prüfungen (Wächter-Kandidaten, Verkaufs-Meldung, Buchhaltung aus dem Test-Briefkasten, Neu einstellen, Händler, Berufe, Entzaubern, Charaktere, Preis-Sync, Datenübernahme und kaputte Daten, Tempo, geschützte AH-Aufrufe) und mit offenem Auktionshaus simulierter Warenkauf, Sniper-Vorab-Reservierung, Serie einstellen, Unterbieten und Scan in Portionen. Was in einem Client nicht prüfbar ist, steht jetzt als „übersprungen“ mit Grund statt als OK im Bericht.

## 0.65.7
- **Testroutine (nur Entwickler):** viele weitere Prüfungen – jede Option einmal an und aus, jeder Chat-Befehl, alle
  Zusatzfenster, Hauptfenster und Designs, Größe und Position, Einkauf- und Buchhaltungs-Rechnung, Sniper-Ziele und
  -Tasten, Wächter-Einstellungen, Watchlist, Taschen ohne alte Funktionen, Chat-Hilfen, Esc-Fenster im Kampf, Fehler
  in Hintergrund-Aufgaben, Übergang vom alten AH Analyzer Pro.
- Taschen, Postfach-Plätze und Preis-Teilen holen die Client-Funktionen jetzt über eine Stelle, damit die Testroutine
  fehlende Funktionen simulieren kann, ohne Blizzard-Funktionen anzufassen (kein Taint). Im normalen Spiel ändert sich
  nichts.
- Meldung "GoldSentinelTest.lua fehlt" ist jetzt übersetzt.

## 0.65.6

Korrekturen aus der Addon-Prüfung:
- **Scan-Start scheitert dauerhaft (WoW Forever, Retail):** Lehnt der Server den Scan-Start immer wieder ab, wird der Chat nicht mehr geflutet (vorher rund 240 Zeilen in 2 Minuten). Die Fehlermeldung kommt einmal, das Addon versucht es höchstens 3-mal neu (mindestens 2 Sekunden Abstand) und meldet dann einmal, dass der Scan nicht starten konnte. Der Wächter läuft sofort weiter.
- **Wächter:** Verwirft der Server Anfragen, während die kurze Pause eines Scan-Wunschs läuft, pausiert der Wächter jetzt wie gewollt die vollen 15 Minuten (vorher lief er nach 2 Minuten wieder). Bewusst keine Pause nur deshalb, weil ein Scan erlaubt ist: Sonst würde der Wächter bei Spielern, die nie scannen, dauerhaft ruhen.
- **Berufsfenster (moderner Client):** Das im Blizzard-Fenster gewählte Rezept wird jetzt wirklich erkannt (der Ereignisname war falsch) – der Zutaten-Knopf nimmt nie ein älteres Rezept.
- **Post an Twinks (WoW Forever):** Eine Regel nur mit dem eigenen Vornamen („Testa“ für „Testa Beispiel“) plant keine Post mehr an dich selbst.
- **WoW Forever, geschützte Werte:** Preis-Sync, Tooltip, Briefkasten-Fehlermeldungen, blockierte Aktionen und das Entzaubern-Lernen übergehen geschützte Werte („secret values“), statt einen Lua-Fehler zu riskieren.
- Vom Addon abgefangene Fehler werden jetzt auch für die Addon-Prüfung gezählt (GoldSentinelTest.lua); `/ahs debug` zeigt „Fehler seit Login · Berichte offen“. Die Chat-Meldungen bleiben wie bisher. Die Verkaufs-Meldung verschluckt Fehler nicht mehr still.
- Nur für den Entwickler: neue Testroutine `/ahs testroutine` (Bereiche a–j, `server`, `haendler`, `berufe`, `post`, `gildenbank`, `kampf`) mit gespeichertem Bericht. Deine echten Daten werden vorher gesichert und danach wiederhergestellt; Kaufen, Einstellen, Post, Händler und Preis-Sync sind nur simuliert. `/ahs test` und `/ahs test daten` sind Kurzformen.
- Fehlende Übersetzungen für das klassische Auktionshaus ergänzt.

## 0.65.5

Nachbesserungen aus der Addon-Prüfung:
- **Komplett-Scan hat Vorrang (WoW Forever, Retail):** Startest du den Scan, während der Server ausgelastet ist oder noch eine Wächter-Suche läuft, scheitert er nicht mehr – der Wächter pausiert, und der Scan startet von selbst, sobald der Server bereit ist (höchstens 2 Minuten). Ein abgelehnter Scan-Start wird genauso behandelt. Classic Era und TBC bleiben unverändert.
- **Berufsfenster:** In den alten Clients (Classic Era, TBC) werden Rezepte wieder höchstens alle 5 Sekunden gelesen, wie in 0.65.3. Im modernen Client kommt das gewählte Rezept direkt aus der Rezeptliste und wird beim Schließen vergessen – der Zutaten-Knopf nimmt nie ein altes Rezept.

## 0.65.4

Korrekturen aus der Addon-Prüfung:
- **Altes „AH Analyzer Pro“ (bis 0.61) noch installiert:** AHSentinel lädt nicht mehr daneben (beide nutzten dieselbe Tabelle – doppelte Ereignisse und Befehle, mögliche Lua-Fehler). Stattdessen kommt einmal im Chat die Bitte, den alten Ordner `AddOns\AHAnalyzerPro` zu löschen. Deine alten Daten werden vorher für AHSentinel gesichert. Der alte Ordner wird auch nicht mehr vor AHSentinel geladen.
- **Wächter (Classic Era, TBC):** wieder wie in 0.64.2 – keine Pause von bis zu 15 Minuten mehr, wenn der Server „kein Komplett-Scan“ meldet (das kann auch von einem anderen Addon kommen).
- **Wächter (WoW Forever, Retail):** Ist der Komplett-Scan fällig und verwirft der Server Anfragen, pausiert der Wächter, bis der Scan gelaufen ist (höchstens 15 Minuten).
- **Berufsfenster (moderner Client):** Eine direkt nach dem Öffnen noch leere Rezeptliste blockiert das Einlesen nicht mehr 5 Sekunden; der Zutaten-Knopf merkt sich das zuletzt gewählte Rezept; die Rezeptdetails werden nur einmal pro Beruf gelesen (weniger Ruckeln).
- `/ahs debug` zeigt, ob Händler-Kosten in Währung (z. B. Merchant's Favor) in diesem Client lesbar sind.

## 0.65.3

- **Der alte Ordner „AHAnalyzerPro“ ist nicht mehr dabei.** Es gibt nur noch den Ordner AHSentinel. Hast du AHSentinel schon einmal gestartet, sind deine alten Daten bereits übernommen und du kannst den Ordner „AHAnalyzerPro“ unter Interface\AddOns löschen.

## 0.65.2

- **GoldSentinelGame Version 2:** Die gemeinsame Versionserkennung setzt sich jetzt auch gegen frühe Fassungen durch, die andere GoldSentinel-Addons kurz mitgebracht hatten – keine Lua-Fehler, wenn mehrere Addons zusammen geladen sind.
- Händlerpreise: Fehlt im Spiel die Funktion für den Item-Link beim Händler, wird die Item-ID auf anderem Weg gelesen.

## 0.65.1

- **Gemeinsame Versionserkennung:** AHSentinel erkennt die Spielversion jetzt über **GoldSentinelGame** – dieselbe Erkennung, die nach und nach alle GoldSentinel-Addons bekommen. WoW Forever gilt dort immer als moderner Client, nie als Classic.
- Neu: `/gsgame` zeigt im Chat, welche Spielversion erkannt wurde; `/ahs debug` zeigt es ebenfalls.
- Für dich ändert sich sonst nichts.

## 0.65.0

**WoW Forever und Retail (moderner Client) – nichts bleibt mehr still leer:**
- **Berufsfenster:** Rezepte werden jetzt über die moderne Berufe-Schnittstelle (`C_TradeSkillUI`) gelesen, wenn die alte fehlt. Das Gewinn-Fenster neben dem Berufsfenster und die Herstell-Vorschläge in „Heute tun“ funktionieren damit auch dort. Ältere Spielversionen nutzen weiter den alten Weg.
- **Händlerpreise:** werden über `C_MerchantFrame` gelesen, wenn die alte Funktion fehlt. Artikel, die Währung oder Marken kosten (z. B. Merchant's Favor), werden mit ihren genauen Kosten gemerkt.
- **Raid-Vorrat:** Auf WoW Forever gilt die Classic-Vorlage (`/ahs raid`).
- **Wächter und der 15-Minuten-Komplett-Scan:** Lässt der Server nach einer Wächter-Runde den fälligen Komplett-Scan nicht zu, pausiert der Wächter, bis der Scan gelaufen ist.
- **Sniper:** Blockiert WoW den vorab reservierten Warenkauf (ohne Fehlermeldung, nur als Ereignis), schaltet sich „eine Raste kauft“ selbst ab und der Sniper kauft wieder mit zwei Rasten.
- Die Texte zur Einstellgebühr auf WoW Forever (0.64.2) gibt es jetzt in allen Sprachen.

## 0.64.2

- **WoW Forever: Einstellgebühr richtig eingerechnet.** Auf WoW Forever kostet jede Auktion **mindestens 1 Silber**, und die Gebühr gibt es **nie zurück**, auch nicht beim Verkauf. AHSentinel erkennt Forever jetzt selbst und zieht die Gebühr überall **immer** ab statt nur als Risiko bei Rücklauf: Flips, Verkaufsvorschläge in „Heute tun“, Herstellungs-Gewinne, Schnäppchen, Entzauber-Schnäppchen (Material wird im Stapel verkauft, Gebühr anteilig pro Stück), Händler-gegen-AH-Vergleich und Reiter Verkaufen (dort steht „nicht erstattet“).
- Vor allem **günstige Items** betrifft das: Bringt ein Item im AH 1s 50c und beim Händler 71c, bleiben nach 5 % und 1s Gebühr nur 42c – „Heute tun“ schlägt dann **„beim Händler verkaufen“** vor.
- Gebühr pro Stück = max(1 Silber, Gebühr eines vollen Stapels) ÷ Stapelgröße. In den anderen Spielversionen bleibt alles wie bisher (Gebühr wird beim Verkauf erstattet).
- Gewinnrechner: auf Forever ist 1 Silber Einstellgebühr enthalten.

## 0.64.1

- **„Heute tun“ schlägt Herstellen vor – auch ohne ProfessionSentinel:** AHSentinel merkt sich jetzt die Rezepte jedes Charakters, sobald du das Berufsfenster öffnest. „Heute tun“ schlägt dann die 2–3 lohnendsten Rezepte vor, die du **schon kannst** (Ergebnis verkauft sich gut, mindestens 10 % Gewinn nach AH-Anteil). Der Knopf **Zutaten kaufen** legt für jede fehlende Zutat aus dem Auktionshaus eine Kauf-Zeile an (10 % Preisspielraum, gekauft wird nur per Klick); Zutaten vom Händler stehen im Chat. Ist alles da: „Alles da – herstellen“.
- Ist ProfessionSentinel installiert, kommen dessen Vorschläge statt der eigenen (nichts doppelt).
- Wer einen Herstellungsberuf hat, aber ProfessionSentinel nicht, sieht unten in „Heute tun“ einen kleinen Tipp – **Ausblenden** entfernt ihn für immer.

## 0.64.0

**„Heute tun“ – kaufen und einstellen direkt in der Liste:**
- Jede Zeile hat jetzt einen **Knopf mit dem nächsten Schritt**, ohne Sprung in einen anderen Reiter:
  - Kauf-Vorschläge: **Prüfen** sucht das Item im Hintergrund. Danach steht in der Zeile das echte aktuelle Angebot („5× zu je 2g 40s = 12g“), und der Knopf heißt **Kaufen 12g**. Mehrere Einzel-Auktionen: **Kaufen (1/3)**, ein Klick pro Auktion (verlangt WoW). Waren im modernen Auktionshaus: Erst wird der Preis reserviert, dann **Bestätigen**.
  - **Nie teurer und nie mehr als vorgeschlagen**, der Kapitalschutz gilt weiter. Ist das Angebot weg oder teurer, steht „nicht mehr lohnend“ da, und es wird nichts gekauft.
  - Nach dem Kauf: Flips bekommen **Einstellen** (Preisvorschlag mit Preisschutz), Entzauber-Schnäppchen zeigen, wie viele in der Tasche sind, Händler-Schnäppchen sagen „Beim Händler verkaufen“.
  - Ware aus den Taschen: **Prüfen → Einstellen**. Zurückgekommene Auktionen: **Neu einstellen**, ein Klick pro Auktion.
- Ein Klick auf die Zeile selbst wechselt wie bisher in den Reiter.
- **Für andere Addons:** `AHAnalyzerPro.Today:QuickBuy(itemID, Menge, Höchstpreis, Text)` und `:QuickSell(itemID, Menge)` legen oben in „Heute tun“ eine Zeile an – gekauft wird nichts ohne deinen Klick.
- **ProfessionSentinel:** Seine Vorschläge „heute herstellen“ erscheinen in „Heute tun“. Der Knopf führt durch Zutaten kaufen, herstellen und einstellen.
- Die Entzaubern-Texte aus 0.63.0 gibt es jetzt in allen Sprachen.

## 0.63.4

- **Wächter nur noch bei belastbarem Marktwert:** Bisher meldete der Wächter auch „Schnäppchen“ bei 0–10 % vom Marktwert – fast immer, weil der Marktwert selbst falsch war (Mondpreis, seltenes Item, Preissturz). Weil der Wächter per Mausrad kauft, zählt jetzt nur noch ein Marktwert, dem man trauen kann.
- **Testmodus-Protokoll:** Käufe des Wächters stehen als „Sniper-Kauf (Wächter)“ mit Preis drin; Waren-Käufe aus Einkauf und Sniper ebenfalls mit Preis.

## 0.63.3

- **Qualitätsstufen (Retail):** Handwerksmaterial und hergestellte Items gibt es in mehreren Stufen – bisher standen z. B. dreimal „Bismut“ untereinander, ohne Unterschied. Jetzt steht das Stufen-Symbol hinter dem Namen (Einkauf, Markt, Verkaufen, Sniper, Buchhaltung …).
- **Rückmeldung nach Einstellen und Abbrechen:** Statt „Wird eingestellt …“ / „Wird abgebrochen …“ stehen zu bleiben, zeigt das Fenster jetzt „Eingestellt: …“ bzw. „Abgebrochen: …“.
- **Tagesbilanz:** zeigte „+ dein ganzes Gold seit gestern“, wenn das Spiel beim Einloggen kurz 0 Gold gemeldet hatte. Ein solcher 0-Wert zählt nicht mehr.
- **Testmodus-Protokoll:** Kauf von Waren (Retail) steht jetzt mit Preis drin, ein Sniper-Kauf als „Sniper-Kauf“ statt „Sofortkauf“.

## 0.63.2

- **Selbsttest in Retail:** brach mit „script ran too long“ ab (Retail stoppt Skripte, die zu lange am Stück laufen – bei rund 20 000 Items im Scan passiert das). Der Test legt jetzt regelmäßig kurze Pausen ein; der Sprachwechsel-Test prüft eine Sprache pro Bild.
- **Verkaufen bei geschlossenem Auktionshaus:** zeigte in Retail „Keine verkaufbaren Items in den Taschen“, obwohl die Taschen voll waren. Die Prüfung „kann man das einstellen?“ läuft jetzt nur noch bei offenem Auktionshaus.
- **Reagenzientasche (Retail):** Items darin zählen jetzt beim Verkaufen, Post an Twinks und Händler-Verkauf mit.

## 0.63.1

- **Retail (The War Within / Midnight, Interface 12.x): Item-Namen wieder da.** Im modernen Spiel gibt es die alten Funktionen `GetItemInfo`, `GetItemIcon` usw. nicht mehr – AHSentinel nimmt dort jetzt `C_Item`. Vorher stand überall „Item #12345“ statt des Namens (Einkauf, Preisverlauf, Tooltip, Testdaten).
- **Namen werden nachgeladen:** Der Komplett-Scan im modernen Auktionshaus liefert nur Item-IDs. Items, die dein Client noch nicht kennt, lädt AHSentinel jetzt gedrosselt im Hintergrund nach (40 pro Sekunde); die Listen aktualisieren sich von selbst.
- **Selbsttest „Suche nach Namen“** schlug in Retail fehl („'Item #251665' -> nil“). Er nimmt jetzt ein Item, dessen Name schon bekannt ist, und meldet sonst, wie viele Namen noch geladen werden.
- **Testmodus in Retail:** Die fiktiven Auktionen und Briefe brauchen Item-Namen – sie entstehen jetzt auch dort.
- Entzaubern: Zaubername über `C_Spell` (Retail).

## 0.63.0

- **Entzaubern – alle lernen gemeinsam:** Was beim Entzaubern herauskommt, teilt AHSentinel jetzt über den Preis-Sync mit allen Spielern, die das Addon haben (oder nur mit deiner Gilde, wenn du das eingestellt hast). Jeder schickt nur seine eigenen Zahlen, nichts wird doppelt gezählt. So stimmen die Dropchancen viel schneller mit der Wirklichkeit auf WoW Forever überein.
- **Neue Startwerte bei grünen Teilen:** 75 % Staub, 20 % Essenz, 5 % Splitter (Waffen umgekehrt: 75 % Essenz, 20 % Staub). Deine eigenen und die geteilten Ergebnisse passen die Werte danach an.
- Tooltip: „Entzaubern (Ø, 12 eigene, 340 geteilt)“ zeigt, auf wie vielen Entzauberungen der Wert beruht.
- Geteilt wird nur, welches Material wie oft herauskam – Unsinn (fremde Gegenstände, unmögliche Mengen) wird abgelehnt.
- ProfessionSentinel nutzt diese Werte für die Rangliste „Herstellen & Entzaubern“.

## 0.62.4

- **Stapelware zusammengefasst (klassisches Auktionshaus):** Im Einkauf bilden alle Angebote eines stapelbaren Items mit gleichem Stückpreis **eine Zeile mit der Summe** – z. B. 5 Stapel zu 20 stehen als „100“ da, mit Stückpreis und **Gesamtpreis** der Zeile.
- **Mehrere zusammen kaufen:** Zeile anklicken, mit **Shift+Linksklick** weitere Zeilen dazu. Rechts stehen Stückzahl, Anzahl Angebote und der Gesamtpreis deiner Auswahl. „Auswahl kaufen“ fragt einmal mit der Summe nach, danach kauft jeder Klick das nächste Angebot (WoW verlangt einen Klick pro Auktion).
- „Einzelne Angebote anzeigen“ schaltet zur bisherigen Liste zurück (dort auch Bieten). Das moderne Auktionshaus fasst Waren schon selbst nach Preis zusammen – dort gibst du einfach die Menge ein.

## 0.62.3

- **Item-Namen für WoW Forever:** Die eingebauten Namen von WoW Forever haben wieder Vorrang, die in 0.62.1 ergänzten TBC-Namen füllen nur noch Lücken. Rund 2000 Items, die in TBC umbenannt wurden, heißen in den anderen Sprachen wieder wie auf WoW Forever.

## 0.62.2

- **Test- und Entwicklerfunktionen ausgeblendet:** Selbsttest und Testmodus (Knopf „Test“, `/ahs test`, `/ahs testmodus`) gibt es jetzt nur noch für den Entwickler. Für alle anderen sieht das Addon gleich aus und funktioniert gleich, nur ohne diese Werkzeuge.

## 0.62.1

**Realistische Preise – wichtig für den frischen Server, auf dem die Preise jeden Tag fallen:**
- **Marktwert folgt dem Markt schneller:** Neuere Preise zählen stärker (Halbwertszeit 3 Tage) statt eines einfachen Medians über 14 Tage. Mondpreise wie „1666g 99s 98c“ zählen gar nicht mehr.
- **Preissturz wird erkannt:** Liegen die letzten zwei Scans (mind. 6 Std. auseinander) weit unter dem Marktwert, steht im Tooltip „Preis gerade eingebrochen“, und der Marktwert gilt als unsicher. Solche Items werden nicht mehr zum Kaufen, Flippen oder Verkaufen vorgeschlagen.
- **„Heute tun“ rechnet mit dem, was du wirklich bekommst:** höchstens 5 % über dem günstigsten aktuellen Angebot, nie mit dem alten Marktwert. Ist der AH-Preis bis nahe an den Händlerpreis gefallen, kommt der Vorschlag „beim Händler verkaufen“.
- **Gebote** werden nur noch bei sicherem Marktwert und nie auf Mondpreise vorgeschlagen.
- **Gewinn/Tag** bei den Schnäppchen zählt nur einen Teil der Tagesverkäufe (du bist nicht der einzige Verkäufer), höchstens die verfügbare Menge und was 20 % deines Golds kaufen.
- Die Übersicht zeigt keine Preise mit …99s 9xc mehr.

**Fehler behoben:**
- **Esc** schließt wieder den Preisverlauf statt des ganzen Auktionshauses (auch nach einem Sprachwechsel).
- **Testmodus:** Ein Sniper-Kauf per Mausrad steht jetzt im Protokoll und in der Buchhaltung.
- **Briefkasten:** neuer Knopf „Neu einstellen (N)“ für zurückgekommene Auktionen. Bildschirmmeldungen haben im Testmodus „[Test]“. Im Testmodus wird langsamer abgeholt, damit man „Anhalten“ ausprobieren kann. Zurückgekommene Test-Ware wird mitgezählt.
- `/ahs bilanz` zeigt kein „+ dein ganzes Gold seit gestern“ mehr, wenn das Gold von gestern nicht bekannt ist.
- Das Geldfeld zeigt bei jeder Eingabe, was verstanden wurde („= 5s“), nicht nur bei reinen Zahlen.
- Ein Item-Tooltip bleibt nicht mehr über einem neu geöffneten Fenster stehen („Heute tun“, Optionen …).
- Im Selbsttest stehen keine Symbol-Codes mehr in den Details.

**Sprachen:**
- **Rund 10 000 Item-Namen mehr in jeder Sprache**, auch alle Items aus Burning Crusade (Englisch: 25 800 statt 14 800). In einer englischen Oberfläche stehen keine deutschen Namen mehr.
- **Listen zeigen die Namen immer in der eingestellten Sprache** – Suchergebnisse, Sniper-Ziele, Beobachtungsliste, Einkaufslisten, Buchhaltung, Auktionen – auch direkt nach dem Wechsel, ohne neue Suche.
- Der Einkauf behält nach dem Sprachwechsel Kategorie, Suchtext und Filter.
- Optionen: Lange Beschriftungen (Französisch, Spanisch, Russisch) brechen in eine zweite Zeile um, statt abgeschnitten zu werden.
- Filter im Einkauf: kurze Platzhalter („St. ab / bis“, „Lvl min / max“), die sich nicht mehr überlappen.
- Chinesisch: „vereinfacht“ und „traditionell“ sind in der Sprachliste unterscheidbar. Item-Namen ohne chinesischen Namen werden ohne Umlaute geschrieben (ö → oe), weil die chinesische Schrift sie nicht hat.
- Selbsttest: Die Sprachprüfung findet jetzt auch abgeschnittene Beschriftungen und Namen in der falschen Sprache und zählt fehlende Item-Namen pro Sprache.

## 0.62.0

**AH Analyzer Pro heißt jetzt AHSentinel** – passend zur Sentinel-Familie (BuffSentinel, GuildSentinel, ThreatSentinel).

- **Deine Daten werden automatisch übernommen:** In der ZIP sind der neue Ordner `AHSentinel` und ein kleiner Ordner `AHAnalyzerPro`, der beim ersten Start nur deine alten Daten (Preise, Buchhaltung, Listen, Sniper-Ziele, Einstellungen) übergibt. Danach kannst du `AHAnalyzerPro` löschen.
- **Neuer Befehl `/ahs`** (auch `/ahsentinel`); `/ahp` geht weiterhin.
- Sonst bleibt alles gleich.

**Installieren:** beide Ordner aus der ZIP nach `Interface\AddOns` kopieren (den alten Ordner `AHAnalyzerPro` überschreiben), Spiel starten, fertig.

## 0.61.2

- **Eine Sprache für alles:** Item-Namen folgen jetzt der Sprache des Addons (außer du hast eine eigene Sprache für Item-Namen gewählt), und der Tooltip zeigt den Item-Namen in dieser Sprache, wenn sie von der Sprache des Spiels abweicht.
- **Sprachwechsel baut jedes Fenster neu auf:** neben dem Hauptfenster auch „Heute tun“, das Test-Fenster, die Regeln für „Post an Twinks“ und die Leiste am Briefkasten (auch bei offenem Briefkasten).
- **Selbsttest:** neue Prüfung „Sprachwechsel“ – jede Sprache des Addons einmal, danach mehrfach hin und her; Fenster, Reiter, Texte, Item-Namen und Tooltip müssen in der gewählten Sprache erscheinen, danach ist die alte Sprache wieder eingestellt.

## 0.61.1

- **Behoben: „Heute tun“ schlug unrealistische Käufe vor.** Seiten-Scans sehen oft nur einen Teil des Auktionshauses – das sah aus wie riesige Verkäufe. Verkäufe pro Tag werden jetzt nur noch zwischen **vollständigen** Scans geschätzt, jeder Rückgang zählt nur zur Hälfte (der Rest ist abgelaufen oder zurückgezogen), und es wird nie mehr als die Hälfte der üblichen Angebotsmenge angenommen. Auch „seit Scan“ vergleicht nur noch vollständige Scans.
- **Kapitalschutz:** Jeder Vorschlag in „Heute tun“ nutzt höchstens 20 % deines Golds, alle zusammen höchstens die Hälfte; das Fenster zeigt den Kapitalbedarf. Der Selbsttest prüft das.
- **Übersicht:** Anstiege auf ein Vielfaches des Marktwerts und Rückgänge von einem früheren Mondpreis erscheinen nicht mehr.
- **Briefkasten:** Die Knöpfe des Addons sitzen jetzt ordentlich in einer Leiste **neben** dem Briefkasten statt über dessen Rahmen. „Alles abholen“ gibt es nur, wenn WoW kein eigenes „Alle öffnen“ hat (und im Testmodus für die Test-Post), „Anhalten“ nur während des Abholens.
- **Ein Geldfeld statt drei:** „5s“, „1g 20s“, „4s 85k“ oder „1.5“ (= 1g 50s) eintippen; bei einer reinen Zahl steht dabei, wie sie verstanden wird („= 5g“). Kein Silber mehr im Gold-Feld.
- Kleinigkeiten: „Bieten“ ohne gewähltes Angebot sagt das, die Händler-Warnung beim Einstellen kommt nur noch, wenn es um etwas geht (mind. 1 Silber und 10 %), fiktive Auktionen erscheinen im Testmodus sofort, das Fenster „Heute tun“ schließt beim Sprung in den Reiter.

## 0.61.0

**Mehr Gewinn, weniger Schein-Schnäppchen:**

- **„Heute tun“** (Knopf in der Übersicht, `/ahp heute`): die Aktionen, die gerade am meisten Gold bringen, sortiert nach geschätztem Netto-Gewinn – unter Händlerpreis kaufen, Flips, Taschen verkaufen, unterbotene Auktionen, Neu einstellen, Entzauber- und Gebots-Schnäppchen. Ein Klick auf eine Zeile führt direkt in den passenden Reiter.
- **Verkaufbarkeit statt Angebotspreisen:** Aus deinen Scans schätzt das Addon jetzt, wie viel sich von einem Item wirklich pro Tag verkauft und ob man dem Marktwert trauen kann. Selten angebotene Items und **Mondpreise** (z. B. 2499g 99s 99c) erscheinen nicht mehr bei Schnäppchen, Flips und in der Übersicht (Knopf „auch unsichere“ zeigt sie trotzdem). Schnäppchen sind nach **Gewinn pro Tag** sortiert, der Tooltip zeigt „~N/Tag verkauft (geschätzt)“.
- **Netto-Gewinn mit Einstellgebühr:** Im klassischen Auktionshaus wird die Gebühr jetzt aus dem Händlerpreis geschätzt („ca.“) und beim ersten echten Einstellen genau gelernt. Gewinne ziehen die Gebühr ab, die bei Rücklauf verloren geht (nach deiner eigenen Verkaufsquote).

## 0.60.11

- **Briefkasten-Knöpfe antworten immer:** „Post abgeholt: …“ erscheint jetzt auch in der Bildschirmmitte, und ein leerer Briefkasten meldet „Nichts zum Abholen“, statt still zu bleiben.
- **„An Twinks“ ohne Regel** sagt das im Chat, bevor sich das Regel-Fenster öffnet.
- **Testmodus:** Der fiktive Brief „Auktion erfolgreich“ gehört jetzt zur verkauften fiktiven Auktion, und diese verschwindet aus „Meine Auktionen“, sobald der Erlös abgeholt ist – wie im Spiel.

## 0.60.10

- **Testmodus mit fiktiven Auktionen:** „Meine Auktionen“ zeigt im Test drei fiktive Auktionen (eine unterboten, eine günstigste, eine verkauft) und alles, was du im Test einstellst – Abbrechen und Unterbietung prüfen lassen sich so ohne echte Auktion ausprobieren. Der Selbsttest nimmt fürs Abbrechen eine fiktive Auktion, wenn du keine hast.
- **Test-Briefkasten:** Im Testmodus arbeiten die Briefkasten-Knöpfe des Addons mit fiktiver Post (verkauft, gewonnen, abgelaufen, abgebrochen, überboten, ein normaler Brief): automatisch abholen, „Alles“, Rechnungen in der Buchhaltung und „Neu einstellen“ lassen sich ausprobieren – deine echte Post bleibt unberührt.
- **Einkauf:** Beim Wechsel zu einem anderen Item werden Gebotsfeld und gewähltes Angebot zurückgesetzt (kein altes Gebot mehr im Feld). Die Kopfzeile zeigt günstigstes Angebot und Marktwert (Median 14 Tage) getrennt und sagt, wenn noch weitere Angebote geladen werden.
- **Sniper:** Angebote des vorigen Ziels stehen nicht mehr unter dem Namen des neuen.
- **Selbsttest:** Der Sniper-Test „kauft“ (simuliert) den kleinsten Stapel statt eines 2er-Stapels.
- **Preisverlauf:** lässt sich jetzt auch am Titel verschieben.

## 0.60.9

- **Meldung, wenn der Scan fertig ist:** groß in der Bildschirmmitte („AH-Scan fertig: N Items“) und mit Ton (wenn in den Optionen der Ton an ist) – du musst nicht mehr auf den Chat schauen. Ein Scan ohne Ergebnis wird dort ebenfalls gemeldet.

## 0.60.8

- **Behoben: keine Preiszeilen im Tooltip** auf manchen Clients (z. B. TBC Anniversary). Das Addon hängt sich jetzt an alle Wege, über die WoW einen Item-Tooltip füllt, und passt die Größe nach seinen Zeilen an. Der Selbsttest prüft jetzt den echten Taschen-Tooltip.
- **Esc schließt nur das oberste Fenster:** z. B. den Preisverlauf – Addon-Fenster und Auktionshaus bleiben offen (vorher ging mit einem Esc alles zu).
- **Preisverlauf:** Das X liegt nicht mehr auf dem Knopf „Alles“.
- **Testmodus** setzt jetzt auch Favoriten im Einkauf, die Liste zum Neu-Einstellen und die Post-Regeln zurück.
- **Deine eigene Suche geht vor:** Eine laufende Wächter-Runde wird abgebrochen, der Einkauf wartet nicht mehr („Warte auf den Wächter …“).
- Einkauf zeigt nach dem Kauf „Gekauft: …“ statt „Kauf wird ausgeführt …“.
- Übersicht: Preissprünge um das Zehnfache (fast immer Fehldaten) erscheinen nicht mehr als Anstieg oder Rückgang.
- Kleinigkeiten: Sniper-Käufe heißen im Testmodus-Protokoll „Sniper-Kauf“, die Einkaufslisten geben nach dem Löschen die Tastatur frei, „N Einträge“ überlappt nicht mehr, Option heißt kurz „Ablauf-Erinnerung“, Einstellgebühr im klassischen AH „beim Einstellen“ statt „?“, iLvl-Hinweis nur bei vorhandenen Treffern, Mausrad im Berichtsfenster schneller, Titel „Testbericht“.

## 0.60.7

- **Neuer Knopf „Test“** oben im Fenster (und in der Leiste im Auktionshaus): Selbsttest und der neue **Testmodus** in einem Fenster.
- **Testmodus:** Alle Funktionen von Hand mit deinen echten Auktionshaus-Daten ausprobieren – Kaufen, Bieten, Sniper (auch mit dem Mausrad), Einstellen, Abbrechen, Händler-Verkauf, Post abholen und verschicken. Jeder Handel ist **nur simuliert**: Der Befehl an den Server wird abgefangen und die Antwort des Servers nachgespielt – Meldungen, Buchhaltung und Sniper-Zähler verhalten sich wie echt. Beim Beenden sind alle Einstellungen und Daten (Listen, Buchhaltung, Sniper, Wächter, Verkaufen) wieder wie vorher – auch automatisch nach `/reload` oder einem Absturz. Ein Protokoll zeigt jede simulierte Aktion und kommt mit in den kopierten Bericht.
- ⚠️ Nur die Knöpfe des Addons sind simuliert – Blizzards eigene Knöpfe im Auktionshaus kaufen weiterhin echt. Auch: `/ahp testmodus`.

## 0.60.6

- **Selbsttest simuliert echten Handel:** Mit den echten Angeboten aus dem Auktionshaus spielt er jetzt Sofortkauf, Gebot, Sniper-Kauf, Einstellen und Abbrechen genau wie im Ernstfall durch – gleiches Angebot, gleicher Preis, gleicher Befehl. Nur der Befehl an den Server wird abgefangen: Es wird nichts gekauft, eingestellt oder abgebrochen, und am Ende prüft der Test, dass dein Gold unverändert ist. Meldungen im Chat sind dabei mit „[Simulation]“ markiert.
- **Selbsttest:** Der Wächter wird nach seiner Testrunde gleich wieder ausgeschaltet und blockiert die folgenden Server-Suchen nicht mehr.

## 0.60.5

- **Behoben (klassische Clients):** Beim Öffnen des Auktionshauses konnte der Lua-Fehler „attempt to compare number with nil“ kommen (Gebote nach einem Reload).
- **Kopfzeile:** „Sniper: an/aus“ und „Wächter: an/aus“ stimmen jetzt immer, auch nach dem Umschalten.
- **Selbsttest:** Läuft im Hintergrund noch ein Markt-Scan, laufen die Server-Suchen nicht mehr alle in die Zeitüberschreitung – beim Test mit gespeicherten Daten wird der Scan beendet, sonst wird auf ihn gewartet. Ein neuer Scan ist während des Tests gesperrt.
- **Selbsttest:** Danach sind Einstellungen, Wächter und Fenster (Reiter, oder geschlossen) zuverlässig wie vorher. Klappt etwas nicht, steht es im Bericht.
- **Textfenster** („Bericht kopieren“) öffnet sich immer vorne, beginnt oben und scrollt mit dem Mausrad zügig (mit Shift in großen Schritten).

## 0.60.4

- **Selbsttest mit gespeicherten Daten:** neuer Knopf „Mit gespeicherten Daten“ im Selbsttest-Fenster (oder `/ahp test daten`). Er testet mit den Auktionshaus-Daten, die du schon gescannt hast – **kein neuer Scan**. Er läuft sogar bei geschlossenem Auktionshaus, dann werden nur die Suchen beim Server übersprungen.

## 0.60.3

- **Behoben für TBC Anniversary (und andere klassische Clients):** „Meine Auktionen“ wurde nie aktualisiert, und manche Meldungen des Auktionshauses (z. B. „eingestellt“) kamen nicht an. Diese Clients kennen die Ereignis-Namen des neuen Auktionshauses, lösen sie beim klassischen aber nie aus – das Addon nutzt dort jetzt immer seine eigenen. Gefunden mit dem neuen Selbsttest.
- **Selbsttest:** Der kopierte Bericht lässt sich jetzt scrollen, die Ergebnisliste ist breiter – Maus über eine Zeile zeigt den ganzen Text.

## 0.60.2

- **Selbsttest:** Optionen → „Selbsttest“ oder `/ahp test` prüft alle Funktionen mit echten Daten aus deinem Auktionshaus: Markt-Scan (falls nötig), Marktdaten, alle Reiter, alle Auswertungen und echte Suchen beim Server (Einkauf, Preisprüfung, Sniper, Wächter, eigene Auktionen). Während des Tests sind **Kaufen, Bieten, Einstellen und Abbrechen gesperrt**, danach sind Einstellungen und Sniper-Ziele wie vorher. Das Ergebnis erscheint in einem Fenster, lässt sich als Bericht kopieren und wird gespeichert.

## 0.60.1

- **Echter Minikarten-Knopf:** Der Knopf sitzt jetzt wie bei anderen Addons an der Minikarte – mit der Maus **rund um die Minikarte ziehen**, die Position wird gespeichert. Funktioniert mit runden und eckigen Minikarten. Ein-/ausblenden in den Optionen oder mit `/ahp minimap`, `/ahp reset` holt ihn zurück.
- **Neues Icon:** eine goldene **Waage** – am Minikarten-Knopf, oben im Fenster und in der Addon-Liste.

## 0.60.0

**Aufgeräumtes Fenster – 5 Reiter statt 11:**

- **Übersicht · Kaufen · Verkaufen · Markt · Buchhaltung.** Was zusammengehört, steht jetzt als Unterreiter:
  Kaufen = Einkauf, Sniper, Wächter, Schnäppchen · Verkaufen = Einstellen, Meine Auktionen · Markt = Alle Preise, Watchlist.
  Alle Funktionen sind noch da, nichts ist weggefallen.
- **Preisverlauf im eigenen Fenster:** Ein Klick auf ein Item öffnet den Verlauf neben dem Addon – die Liste, aus der du kommst, bleibt genau, wo sie war. Das Fenster lässt sich verschieben und in der Größe ziehen.
- **Sniper und Wächter in der Kopfzeile:** auf einen Blick sehen, ob sie laufen, und mit einem Klick an- oder ausschalten (Rechtsklick öffnet ihren Reiter).
- **Merkt sich, wo du warst:** Das Addon öffnet sich im zuletzt benutzten Reiter, jeder Haupt-Reiter merkt sich seinen Unterreiter.

## 0.59.33

**Komfort-Update – zwölf kleine Dinge, die jeden Tag Klicks sparen:**

- **Stapelgröße und Anzahl Stapel** (klassisches Auktionshaus): z. B. 5 Stapel à 20 – wird pro Item gemerkt, auch für die Serie.
- **Post automatisch abholen:** Beim Öffnen des Briefkastens wird die Auktionspost gleich abgeholt (Shift beim Öffnen = diesmal nicht).
- **Mindestpreis pro Item:** Knopf „Min“ beim Verkaufen – darunter wird nie unterboten, die Serie wartet statt billig zu verkaufen.
- **Nur was mir fehlt:** Am Berufsfenster kommt nur die fehlende Menge auf die Einkaufsliste (Taschen, Bank und Twinks werden gezählt).
- **Alt-Klick auf ein Item** in den Taschen oder im Chat: öffnet den Preisverlauf, bei offenem Auktionshaus den Einkauf.
- **Verkaufschance im Tooltip:** wie viel von dem, was du eingestellt hast, verkauft wurde und wie lange es meist dauert.
- **Erinnerung bei ablaufenden Auktionen** und beim Einloggen, was seit dem letzten Besuch abgelaufen ist.
- **Favoriten im Einkauf:** Suchen speichern und mit einem Klick wieder ausführen.
- **Gold-Ziel** für alle Charaktere zusammen (Optionen oder `/ahp ziel 5000`).
- **Gildenbank-Wert** in der Buchhaltung (ab TBC).
- **Raid-Vorrat:** Einkaufsliste mit Tränken, Fläschchen, Elixieren und Buff-Food für eine Raidwoche (`/ahp raid`).
- **Preis-Sync nur mit der Gilde** als neue Option.

## 0.59.32

- **Keine absurden Gewinne mehr:** Items mit 1000 % Gewinn oder mehr (fast immer Fehldaten) erscheinen nicht mehr bei den Schnäppchen und nicht mehr unter „Größte Preisanstiege“.

## 0.59.31

- **Itemlevel als Suchfilter:** Felder „iLvl ab / bis“ im Einkauf und im Markt – filtern sofort, ohne neue Suche beim Server.

## 0.59.30

- **Schrott beim Händler verkaufen** mit einem Knopf (graue Items und alles, was beim Händler mehr bringt).
- **Vermögen:** Wert von Taschen, Bank und Twinks plus das Gold aller Charaktere.
- **Tagesbilanz beim Einloggen**, jederzeit mit `/ahp bilanz`.
- **Neu einstellen mit einem Klick** für abgelaufene Auktionen.
- **Flip-Empfehlungen**, **Post an Twinks**, **/ahp help** im Chat.
- Einkauf: iLvl für jedes Item · Verkaufen: Angebote erscheinen viel schneller.
