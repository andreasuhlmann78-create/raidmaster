-- BuffSentinel - Messung.lua (BS-M1 Teil A, Auftrag Supervisor 24.11.2026 13:53, Entscheid des Nutzers 13:52)
-- Copyright (C) 2026 GoldSentinel
--
-- Frage: Was lässt sich in WoW Forever zum Reinigen der Mitspieler lesen, obwohl Debuffs im Kampf geschützt sind?
-- Hier wird NUR GEMESSEN. Muster wie ThreatSentinel TS-M1 (Messung.lua).
--
--  1) Automatisch beim normalen Spielen, bei JEDEM Spieler (BS-M1-b, Entscheid des Nutzers 24.11. 14:09: "normale spieler,
--     meine offiziere liefern die daten über den uploader"), abschaltbar (Option "Messdaten sammeln", Standard EIN), NUR LESEN:
--     - Instanz betreten (einmal je Betreten): vorhandene Funktionen, CVars der Blizzard-Gruppenrahmen (nur lesen),
--       vorhandene Blizzard-Rahmen, dazu alle Aura-Quellen ausserhalb des Kampfes (Vergleich).
--     - Kampf (einmal je Kampf, 3 s nach Kampfbeginn): jede Aura-Quelle einzeln (C_UnitAuras.GetAuraDataByIndex mit HARMFUL
--       und HARMFUL|RAID, GetAuraSlots + GetAuraDataBySlot, GetUnitAuras, GetAuraDataByAuraInstanceID, AuraUtil.ForEachAura,
--       UnitDebuff/UnitAura), je für "player" und ein anderes Gruppenmitglied: fehlt / Fehler (gesperrt) / nil / Art jedes Felds
--       (geschützt oder lesbar). Dazu die Blizzard-Gruppenrahmen: wie viele zeigen Debuffs bzw. bannbare Debuffs.
--     - Ereignis UNIT_AURA im Kampf: Anzahl, Art der Aktualisierungs-Info (updateInfo) und der Felder der ersten neuen Aura.
--     Jede Quelle in einem eigenen Bild (C_Timer.After 0), Kosten je Bild gemessen (Ziel ≤ 1 ms). Nichts wird verändert:
--     kein Ziel, kein Zauber, keine CVar, keine Blizzard-Rahmen, nichts gesendet.
--  2) Auf Befehl (/bsen reinigen messen, Entwicklermodus): alles sofort, dazu "Anzeige ohne eigenen Entscheid": einen
--     geschützten Wert (Symbol, Farbe) an eine eigene, nie gezeigte Test-Textur reichen – geht das ohne Fehler? Die Textur wird
--     im selben Bild zurückgesetzt.
--
-- Ablage: BuffSentinelDB.m1 (account-weite SavedVariables, Datei WTF/Account/<Konto>/SavedVariables/BuffSentinel.lua – die
-- liefert der Uploader). Aufbau (ver = 2): head = { v = Addon-Version, b = Client-Build, z = Datum der letzten Messung },
-- runs = Ringpuffer der letzten M1.MAX_RUNS Durchläufe (neueste zuerst; je Durchlauf art, z, v, b, grp, inst, cls, role, tags,
-- maxMs, state, src = { Quelle -> Nummer in dict }), dict = gleiche Ergebnistexte nur einmal, sum = ältere Durchläufe
-- zusammengefasst (Zähler je Quelle und Art), cost = Kosten je Bild. Höchstens M1.MAX_BYTES (geschätzt) – sonst fallen die
-- ältesten Durchläufe in die Zusammenfassung. Keine Namen: nur Arten (geschützt/lesbar/nil/Fehler), Anzahlen, Einheiten-Art
-- (player/party/raid), Klassen-Kürzel, Rolle. Befehle auf Abruf bleiben im Entwicklermodus (/bsen reinigen messen).

local ADDON, BS = ...
local L = BS.L
local API = BS.API

local M1 = {}
BS.M1 = M1
M1.MAX_RUNS = 20          -- gespeicherte Durchläufe, neueste zuerst (BS-M1-b: Ringpuffer 20)
M1.MAX_BYTES = 20000      -- höchstens 20 KB in BuffSentinel.lua (BS-M1-b), geschätzt mit M1.Size
M1.MAX_TEXT = 400         -- ein Ergebnistext höchstens so lang
M1.VERSION = 2
M1.FIGHT_DELAY = 3        -- s nach Kampfbeginn (dann haben Gruppenmitglieder eher Debuffs)
M1.INSTANCE_DELAY = 2     -- s nach dem Betreten der Instanz
M1.COST_LIMIT = 1         -- ms je Bild (Auftrag BS-M1)

-- Namen, die es geben könnte: nur ob vorhanden (type), nie aufgerufen
M1.NAMES = {
    "C_UnitAuras", "C_UnitAuras.GetAuraDataByIndex", "C_UnitAuras.GetAuraDataBySlot", "C_UnitAuras.GetAuraSlots",
    "C_UnitAuras.GetUnitAuras", "C_UnitAuras.GetAuraDataByAuraInstanceID", "C_UnitAuras.GetAuraDispelTypeColor",
    "C_UnitAuras.IsAuraFilteredOutByInstanceID", "AuraUtil", "AuraUtil.ForEachAura", "UnitDebuff", "UnitAura", "UnitBuff",
    "C_Secrets", "C_Secrets.ShouldAurasBeSecret", "issecretvalue", "canaccessvalue", "C_CurveUtil",
    "C_CurveUtil.CreateColorCurve", "DebuffTypeColor", "CompactUnitFrame_UpdateAuras", "CompactUnitFrame_UtilShouldDisplayDebuff",
}
-- CVars der Gruppenrahmen (nur lesen; "fehlt" ist ein Messergebnis)
M1.CVARS = {
    "raidFramesDisplayDebuffs", "raidFramesDisplayOnlyDispellableDebuffs", "raidFramesDisplayIncomingHeals",
    "useCompactPartyFrames", "raidOptionDisplayPets", "raidFramesDisplayClassColor", "showDispelDebuffs",
    "raidFramesDisplayOnlyHealerDispellableDebuffs", "raidFramesDisplayAggroHighlight",
}
-- Blizzard-Rahmen: nur ob vorhanden / gezeigt
M1.FRAMES = { "CompactRaidFrameContainer", "CompactPartyFrame", "CompactRaidFrameManager", "PartyMemberFrame1", "PartyFrame" }
-- Felder einer Aura, deren Art gemessen wird (nie der Wert)
M1.FIELDS = { "name", "icon", "dispelName", "spellId", "auraInstanceID", "isHarmful", "expirationTime" }

------------------------------------------------------------------------
-- Hilfen
------------------------------------------------------------------------
local function Ms()
    if debugprofilestop then return debugprofilestop() end
    return (GetTime and GetTime() or 0) * 1000
end
local function Stamp() return date and date("%d.%m. %H:%M") or "" end

-- Art eines Werts: "nil", "geschützt" oder "lesbar(Typ)" – nie der Wert selbst
function M1.Kind(v)
    if v == nil then return "nil" end
    if BS.IsSecret(v) then return "geschützt" end
    return "lesbar(" .. type(v) .. ")"
end
local Kind = M1.Kind

function M1.Lookup(name)
    local t = _G
    for part in name:gmatch("[^%.]+") do
        if type(t) ~= "table" then return nil end
        t = rawget(t, part)
    end
    return t
end

-- Felder einer Aura-Tabelle als kurze Liste "name=geschützt dispelName=lesbar(string) …"
local function Fields(a)
    if type(a) ~= "table" or BS.IsSecret(a) then return Kind(a) end
    local out = {}
    for _, f in ipairs(M1.FIELDS) do
        local ok, v = pcall(function() return a[f] end)
        out[#out + 1] = f .. "=" .. (ok and Kind(v) or "Fehler")
    end
    return table.concat(out, " ")
end
M1.Fields = Fields

-- Option "Messdaten sammeln" (Profil, Standard EIN; nur false schaltet ab)
function M1.CollectOn()
    local d = BS.db
    return not (type(d) == "table" and type(d.m1) == "table" and d.m1.collect == false)
end

function M1:Allowed()
    if self.force then return true end
    if BS.Selftest and BS.Selftest.running and not self.testAllow then return false end   -- T264: Testroutine ändert keine Livedaten
    if type(BS.gdb) ~= "table" then return false end
    return M1.CollectOn()
end

function M1:Store()
    local g = BS.gdb
    if type(g) ~= "table" then return nil end
    local s = g.m1
    if type(s) ~= "table" or s.ver ~= M1.VERSION then s = { ver = M1.VERSION }; g.m1 = s end   -- 0.9.64 (nur Entwickler) verworfen
    s.runs = type(s.runs) == "table" and s.runs or {}
    s.dict = type(s.dict) == "table" and s.dict or {}
    s.sum = type(s.sum) == "table" and s.sum or {}
    s.head = type(s.head) == "table" and s.head or {}
    s.cost = type(s.cost) == "table" and s.cost or { max = 0, n = 0, over = 0 }
    return s
end

-- grobe Grösse in der SavedVariables-Datei (Schlüssel, Texte, Zahlen, Klammern) – reicht für die 20-KB-Grenze
function M1.Size(v, depth)
    depth = depth or 0
    local t = type(v)
    if t == "string" then return #v + 4 end
    if t == "number" then return 12 end
    if t == "boolean" then return 6 end
    if t ~= "table" or depth > 8 then return 4 end
    local n = 4
    for k, x in pairs(v) do n = n + M1.Size(k, depth + 1) + M1.Size(x, depth + 1) + 4 end
    return n
end

-- Art eines Ergebnistexts für die Zusammenfassung
function M1.Classify(text)
    text = tostring(text or "")
    if text:find("Fehler", 1, true) then return "Fehler" end
    if text:find("geschützt", 1, true) then return "geschützt" end
    if text:find("lesbar", 1, true) then return "lesbar" end
    if text:find("fehlt", 1, true) then return "fehlt" end
    if text:find("nil", 1, true) then return "nil" end
    return "sonst"
end

-- ältesten Durchlauf in die Zusammenfassung schieben
local function Retire(s)
    local r = table.remove(s.runs)
    if not r then return end
    for k, idx in pairs(type(r.src) == "table" and r.src or {}) do
        local sk = s.sum[k] or {}
        s.sum[k] = sk
        local c = M1.Classify(s.dict[idx])
        sk[c] = (sk[c] or 0) + 1
    end
    s.sum._runs = (tonumber(s.sum._runs) or 0) + 1
end

-- Wörterbuch neu aufbauen: nur noch benutzte Texte, Nummern neu vergeben
local function Compact(s)
    local dict, map = {}, {}
    for _, r in ipairs(s.runs) do
        for k, idx in pairs(r.src or {}) do
            local text = s.dict[idx]
            if text then
                if not map[text] then dict[#dict + 1] = text; map[text] = #dict end
                r.src[k] = map[text]
            else
                r.src[k] = nil
            end
        end
    end
    s.dict = dict
end

function M1:Cost(ms)
    local s = self:Store()
    if not s then return end
    local c = s.cost
    c.n = (c.n or 0) + 1
    if ms > (c.max or 0) then c.max = ms end
    if ms > self.COST_LIMIT then c.over = (c.over or 0) + 1 end
end

-- Gruppe ohne Namen: "solo", "party 3", "raid 12"
local function GroupKind()
    local units, inRaid = BS:GetGroupUnits()
    if #units <= 1 then return "solo", units end
    return (inRaid and "raid " or "party ") .. #units, units
end

-- erstes anderes Gruppenmitglied (nicht der Spieler selbst)
local function OtherUnit(units)
    for _, u in ipairs(units or {}) do
        if u ~= "player" and API.UnitExists(u) then
            local isMe = API.UnitIsUnit and API.UnitIsUnit(u, "player")
            if BS.IsSecret(isMe) or not isMe then return u end
        end
    end
end

local function UnitTag(u)
    if not u then return "-" end
    local cls = API.UnitClass and select(2, API.UnitClass(u))
    if BS.IsSecret(cls) or type(cls) ~= "string" then cls = "?" end
    return (u:gsub("%d+$", "")) .. ":" .. cls
end

------------------------------------------------------------------------
-- Quellen (je eine Funktion; Rückgabe: kurzer Text ohne Namen)
------------------------------------------------------------------------
local function Pack(...) return { n = select("#", ...), ... } end
local function CallKind(fn, ...)
    if type(fn) ~= "function" then return "fehlt" end
    local r = Pack(pcall(fn, ...))
    if not r[1] then return "Fehler(gesperrt)" end
    return nil, r
end

M1.SOURCES = {}
local S = M1.SOURCES

S[#S + 1] = { key = "idx", run = function(u, ctx)
    local CU = API.C_UnitAuras
    local bad, r = CallKind(CU and CU.GetAuraDataByIndex, u, 1, "HARMFUL")
    if bad then return bad end
    if type(r[2]) == "table" and not BS.IsSecret(r[2]) and type(r[2].auraInstanceID) == "number" then ctx.iid = ctx.iid or { u, r[2].auraInstanceID } end
    return Fields(r[2])
end }
S[#S + 1] = { key = "idxRAID", run = function(u)
    local CU = API.C_UnitAuras
    local bad, r = CallKind(CU and CU.GetAuraDataByIndex, u, 1, "HARMFUL|RAID")
    if bad then return bad end
    return Fields(r[2])
end }
S[#S + 1] = { key = "slots", run = function(u)
    local CU = API.C_UnitAuras
    local bad, r = CallKind(CU and CU.GetAuraSlots, u, "HARMFUL")
    if bad then return bad end
    local parts = { "n=" .. tostring(math.max(0, r.n - 2)) }      -- Rückgabe: Fortsetzung, Platz 1, Platz 2, …
    local slot = r[3]
    parts[#parts + 1] = "slot1=" .. Kind(slot)
    if type(slot) == "number" and not BS.IsSecret(slot) then
        local bad2, r2 = CallKind(CU.GetAuraDataBySlot, u, slot)
        parts[#parts + 1] = "bySlot " .. (bad2 or Fields(r2[2]))
    end
    return table.concat(parts, " ")
end }
S[#S + 1] = { key = "unitAuras", run = function(u)
    local CU = API.C_UnitAuras
    local bad, r = CallKind(CU and CU.GetUnitAuras, u, "HARMFUL")
    if bad then return bad end
    local t = r[2]
    if type(t) ~= "table" or BS.IsSecret(t) then return Kind(t) end
    return "n=" .. #t .. (t[1] and (" erste " .. Fields(t[1])) or "")
end }
S[#S + 1] = { key = "instanceID", run = function(u, ctx)
    local CU = API.C_UnitAuras
    if not (CU and CU.GetAuraDataByAuraInstanceID) then return "fehlt" end
    local iid = ctx.iid
    if not iid then return "keine ID gelesen" end
    if iid[1] ~= u then return "ID von " .. UnitTag(iid[1]) .. " – hier nicht" end
    local bad, r = CallKind(CU.GetAuraDataByAuraInstanceID, u, iid[2])
    return bad or Fields(r[2])
end }
S[#S + 1] = { key = "forEach", run = function(u)
    local AU = API.AuraUtil
    local fn = AU and AU.ForEachAura
    if type(fn) ~= "function" then return "fehlt" end
    local n, first = 0, nil
    local ok = pcall(fn, u, "HARMFUL", 1, function(a) n = n + 1; first = first or a; return true end, true)
    if not ok then return "Fehler(gesperrt)" end
    return "Aufrufe=" .. n .. (first and (" " .. Fields(first)) or "")
end }
S[#S + 1] = { key = "unitDebuff", run = function(u)
    local fn = API.UnitDebuff
    if type(fn) ~= "function" then
        local ua = API.UnitAura
        if type(ua) ~= "function" then return "fehlt" end
        local bad, r = CallKind(ua, u, 1, "HARMFUL")
        if bad then return "UnitAura " .. bad end
        return "UnitAura name=" .. Kind(r[2]) .. " typ=" .. Kind(r[5])
    end
    local bad, r = CallKind(fn, u, 1)
    if bad then return bad end
    return "name=" .. Kind(r[2]) .. " icon=" .. Kind(r[3]) .. " typ=" .. Kind(r[5]) .. " id=" .. Kind(r[11])
end }

-- Blizzard-Gruppenrahmen: zeigen sie Debuffs bzw. bannbare Debuffs? (nur IsShown lesen)
function M1.BlizzFrames()
    local frames, deb, disp, seen = 0, 0, 0, 0
    local function Visit(f)
        if type(f) ~= "table" or not f.IsShown then return end
        seen = seen + 1
        local okS, shown = pcall(f.IsShown, f)
        if not (okS and shown == true) then return end
        frames = frames + 1
        local hasD, hasP = false, false
        for _, d in ipairs(type(f.debuffFrames) == "table" and f.debuffFrames or {}) do
            local ok, s = pcall(d.IsShown, d)
            if ok and s == true then hasD = true end
        end
        for _, d in ipairs(type(f.dispelDebuffFrames) == "table" and f.dispelDebuffFrames or {}) do
            local ok, s = pcall(d.IsShown, d)
            if ok and s == true then hasP = true end
        end
        if hasD then deb = deb + 1 end
        if hasP then disp = disp + 1 end
    end
    for i = 1, 5 do Visit(_G["CompactPartyFrameMember" .. i]) end
    for i = 1, 40 do Visit(_G["CompactRaidFrame" .. i]) end
    return string.format("Rahmen gefunden %d, gezeigt %d, mit Debuff %d, mit bannbarem Debuff %d", seen, frames, deb, disp)
end

function M1.Names()
    local have, miss = {}, {}
    for _, n in ipairs(M1.NAMES) do
        local v = M1.Lookup(n)
        if v ~= nil then have[#have + 1] = n .. ":" .. type(v) else miss[#miss + 1] = n end
    end
    return "da: " .. (#have > 0 and table.concat(have, ", ") or "-") .. " · fehlt: " .. (#miss > 0 and table.concat(miss, ", ") or "-")
end

function M1.CVars()
    local get = (C_CVar and C_CVar.GetCVar) or GetCVar
    local out = {}
    for _, c in ipairs(M1.CVARS) do
        local ok, v = pcall(get, c)
        out[#out + 1] = c .. "=" .. ((not ok or v == nil) and "fehlt" or (BS.IsSecret(v) and "geschützt" or tostring(v)))
    end
    return table.concat(out, ", ")
end

function M1.FramesExist()
    local out = {}
    for _, n in ipairs(M1.FRAMES) do
        local f = rawget(_G, n)
        local s = "fehlt"
        if type(f) == "table" then
            local ok, v = pcall(f.IsShown, f)
            s = ok and (v and "gezeigt" or "versteckt") or "da"
        end
        out[#out + 1] = n .. ":" .. s
    end
    return table.concat(out, ", ")
end

function M1.State()
    local CS = API.C_Secrets
    local sec = "fehlt"
    if CS and CS.ShouldAurasBeSecret then
        local ok, v = pcall(CS.ShouldAurasBeSecret)
        sec = ok and Kind(v) .. (type(v) == "boolean" and ("=" .. tostring(v)) or "") or "Fehler"
    end
    local c = API.UnitAffectingCombat and API.UnitAffectingCombat("player")
    return "Kampf=" .. (BS.IsSecret(c) and "geschützt" or tostring(c)) .. " Sperre=" .. tostring(InCombatLockdown and InCombatLockdown() or false)
        .. " ShouldAurasBeSecret=" .. sec
end

------------------------------------------------------------------------
-- Durchlauf: jede Quelle in einem eigenen Bild
------------------------------------------------------------------------
function M1:NewRun(art)
    local grp, units = GroupKind()
    local other = OtherUnit(units)
    local role = API.UnitGroupRolesAssigned and API.UnitGroupRolesAssigned("player")
    if BS.IsSecret(role) or type(role) ~= "string" then role = "-" end
    return { art = art, z = Stamp(), v = BS.version, b = M1.Build(), grp = grp, units = { "player", other },
        tags = { UnitTag("player"), UnitTag(other) }, cls = BS.class, role = role, src = {}, ctx = {}, maxMs = 0 }
end

local function Step(self, run, fn)
    local t = Ms()
    local ok, err = pcall(fn)
    local ms = Ms() - t
    if ms > run.maxMs then run.maxMs = ms end
    self:Cost(ms)
    if not ok then run.src["fehler"] = tostring(err):sub(1, 120) end
end

-- Liste der Schritte eines Durchlaufs (Funktionen ohne Argumente)
function M1:Steps(run, full)
    local steps = {}
    steps[#steps + 1] = function() run.state = M1.State() end
    for _, src in ipairs(M1.SOURCES) do
        steps[#steps + 1] = function()
            local parts = {}
            for i, u in ipairs(run.units) do
                if u then parts[#parts + 1] = (i == 1 and "ich " or "andere ") .. src.run(u, run.ctx) end
            end
            run.src[src.key] = table.concat(parts, " | ")
        end
    end
    steps[#steps + 1] = function() run.src.blizzRahmen = M1.BlizzFrames() end
    if full then
        steps[#steps + 1] = function() run.src.namen = M1.Names() end
        steps[#steps + 1] = function() run.src.cvars = M1.CVars() end
        steps[#steps + 1] = function() run.src.rahmen = M1.FramesExist() end
    end
    return steps
end

function M1:Finish(run)
    run.ctx, run.units = nil, nil
    local s = self:Store()
    if not s then return end
    -- Texte ins Wörterbuch (gleiche Ergebnisse jedes Kampfs nur einmal gespeichert)
    local index = {}
    for i, text in ipairs(s.dict) do index[text] = i end
    for k, text in pairs(run.src) do
        text = tostring(text):sub(1, self.MAX_TEXT)
        if not index[text] then s.dict[#s.dict + 1] = text; index[text] = #s.dict end
        run.src[k] = index[text]
    end
    run.maxMs = math.floor((run.maxMs or 0) * 100 + 0.5) / 100
    table.insert(s.runs, 1, run)
    while #s.runs > self.MAX_RUNS do Retire(s) end
    Compact(s)
    while #s.runs > 1 and M1.Size(s) > self.MAX_BYTES do Retire(s); Compact(s) end
    -- ein einzelner Durchlauf allein zu gross (sollte nicht vorkommen: ~16 Quellen × 400 Zeichen): Texte kürzen, sonst nur zählen
    if M1.Size(s) > self.MAX_BYTES then
        for i, text in ipairs(s.dict) do s.dict[i] = text:sub(1, 120) end
        Compact(s)
        if M1.Size(s) > self.MAX_BYTES then Retire(s); Compact(s) end
    end
    s.head.v, s.head.b, s.head.z = BS.version, M1.Build(), run.z
end

function M1.Build()
    local b = GetBuildInfo and select(4, GetBuildInfo())
    if BS.IsSecret(b) then return "?" end
    return tostring(b or "?")
end

-- Schritte nacheinander, je einer pro Bild (C_Timer.After 0); ohne Timer (Nachbau) sofort
function M1:RunSteps(run, steps, done)
    local i = 0
    local T = API.C_Timer
    local function nextStep()
        i = i + 1
        if i > #steps then if done then done(run) end; return end
        Step(self, run, steps[i])
        if T and T.After and not self.sync then T.After(0, nextStep) else nextStep() end
    end
    nextStep()
end

------------------------------------------------------------------------
-- Auslöser
------------------------------------------------------------------------
function M1:OnCombatStart()
    if not self:Allowed() then return end
    self.combatNo = (self.combatNo or 0) + 1
    local no = self.combatNo
    self.aura = { n = 0 }          -- UNIT_AURA-Zählung dieses Kampfs
    local T = API.C_Timer
    if not (T and T.After) then return end
    T.After(self.FIGHT_DELAY, function()
        if no ~= self.combatNo or not (InCombatLockdown() or (API.UnitAffectingCombat and API.UnitAffectingCombat("player"))) then return end
        local run = self:NewRun("kampf")
        self.fight = run
        self:RunSteps(run, self:Steps(run, false))
    end)
end

function M1:OnCombatEnd()
    local run, a = self.fight, self.aura
    self.fight, self.aura = nil, nil
    if not run then return end
    if a then run.src.unitAura = string.format("Ereignisse %d (Gruppe) · Info %s · erste neue Aura %s", a.n, a.info or "-", a.first or "-") end
    self:Finish(run)
end

-- UNIT_AURA im Kampf: nur zählen und EINMAL die Art der Info ansehen (keine Werte)
function M1:OnUnitAura(unit, info)
    local a = self.aura
    if not a or not unit or BS.IsSecret(unit) then return end
    if not (unit == "player" or unit:find("^party") or unit:find("^raid")) then return end
    a.n = a.n + 1
    if a.info then return end
    if info == nil then a.info = "nil"; return end
    if BS.IsSecret(info) or type(info) ~= "table" then a.info = Kind(info); return end
    local ok, full = pcall(function() return info.isFullUpdate end)
    local ok2, added = pcall(function() return info.addedAuras end)
    a.info = "isFullUpdate=" .. (ok and Kind(full) or "Fehler") .. " addedAuras=" .. (ok2 and Kind(added) or "Fehler")
    if ok2 and type(added) == "table" and not BS.IsSecret(added) and added[1] then
        a.first = Fields(added[1])
        local id = type(added[1]) == "table" and not BS.IsSecret(added[1]) and added[1].auraInstanceID
        if self.fight and type(id) == "number" and not BS.IsSecret(id) then self.fight.ctx.iid = self.fight.ctx.iid or { unit, id } end
    end
end

-- Instanz betreten: einmal je Betreten (draussen gewesen -> beim nächsten Betreten wieder)
function M1:OnEnterWorld()
    if not self:Allowed() then return end
    local inInst = API.IsInInstance and API.IsInInstance()
    if not inInst or BS.IsSecret(inInst) then self.lastInst = nil; return end
    local T = API.C_Timer
    if not (T and T.After) then return end
    T.After(self.INSTANCE_DELAY, function()
        local id = GetInstanceInfo and select(8, GetInstanceInfo())
        if BS.IsSecret(id) then id = "?" end
        if self.lastInst == tostring(id) or not self:Store() then return end
        self.lastInst = tostring(id)
        local run = self:NewRun("instanz")
        run.inst = tostring(id)
        self:RunSteps(run, self:Steps(run, true), function(r) self:Finish(r) end)
    end)
end

-- Befehl: alles sofort, dazu die Anzeige ohne eigenen Entscheid (Test-Textur, nie gezeigt)
function M1:Command()
    self.force = true
    local run = self:NewRun("befehl")
    self.sync = true
    self:RunSteps(run, self:Steps(run, true))
    self.sync = nil
    Step(self, run, function() run.src.anzeige = M1.PassThrough(run.units) end)
    self.force = nil
    self:Finish(run)
    for _, l in ipairs(self:Lines(1)) do BS.Print(l) end
    return run
end

-- Geschützte Werte an eine eigene Test-Textur reichen (nie gezeigt, im selben Bild zurückgesetzt)
function M1.PassThrough(units)
    local CU = API.C_UnitAuras
    if not (CU and CU.GetAuraDataByIndex and CreateFrame) then return "fehlt" end
    M1.probe = M1.probe or CreateFrame("Frame")
    M1.probe:Hide()
    M1.tex = M1.tex or M1.probe:CreateTexture(nil, "ARTWORK")
    local out = {}
    for _, u in ipairs(units) do
        if u then
            local ok, a = pcall(CU.GetAuraDataByIndex, u, 1, "HARMFUL")
            if not ok then out[#out + 1] = UnitTag(u) .. " lesen Fehler(gesperrt)"
            elseif type(a) ~= "table" then out[#out + 1] = UnitTag(u) .. " keine Aura"
            else
                local okI, icon = pcall(function() return a.icon end)
                local r1 = okI and pcall(M1.tex.SetTexture, M1.tex, icon)
                local col = "fehlt"
                if CU.GetAuraDispelTypeColor then
                    local okC, c = pcall(CU.GetAuraDispelTypeColor, u, a.auraInstanceID)
                    col = okC and Kind(c) or "Fehler"
                end
                pcall(M1.tex.SetTexture, M1.tex, nil)
                out[#out + 1] = string.format("%s Symbol %s -> SetTexture %s · Farbe %s", UnitTag(u), okI and Kind(icon) or "Fehler",
                    r1 and "ok" or "Fehler", col)
            end
        end
    end
    return table.concat(out, " | ")
end

------------------------------------------------------------------------
-- Ausgabe (Diagnose-Protokoll, Befehl)
------------------------------------------------------------------------
M1.ORDER = { "idx", "idxRAID", "slots", "unitAuras", "instanceID", "forEach", "unitDebuff", "blizzRahmen", "unitAura",
    "anzeige", "namen", "cvars", "rahmen", "fehler" }

function M1:Lines(maxRuns)
    local s = self:Store()
    local out = {}
    if not s then return out end
    local c, h = s.cost, s.head
    out[#out + 1] = string.format("BS-M1 Messung Reinigen (BuffSentinelDB.m1, nur lesen, Option %s): Addon %s · Build %s · zuletzt %s · Durchläufe %d (+%d zusammengefasst) · Kosten je Bild max %.2f ms, über %d ms: %d von %d · Grösse ~%d Byte",
        M1.CollectOn() and "ein" or "aus", tostring(h.v or BS.version), tostring(h.b or M1.Build()), tostring(h.z or "-"), #s.runs,
        tonumber(s.sum._runs) or 0, c.max or 0, self.COST_LIMIT, c.over or 0, c.n or 0, M1.Size(s))
    for i = 1, math.min(#s.runs, maxRuns or 6) do
        local r = s.runs[i]
        out[#out + 1] = string.format("- %s %s v%s b%s · %s · %s/%s · Rolle %s%s · max %.2f ms", tostring(r.art), tostring(r.z), tostring(r.v),
            tostring(r.b), tostring(r.grp), tostring(r.tags and r.tags[1]), tostring(r.tags and r.tags[2]), tostring(r.role),
            r.inst and (" · Instanz " .. r.inst) or "", r.maxMs or 0)
        if r.state then out[#out + 1] = "    Zustand: " .. r.state end
        for _, k in ipairs(M1.ORDER) do
            local v = r.src and r.src[k]
            if type(v) == "number" then v = s.dict[v] end
            if v then out[#out + 1] = "    " .. k .. ": " .. tostring(v) end
        end
    end
    local sum = {}
    for _, k in ipairs(M1.ORDER) do
        local sk = s.sum[k]
        if type(sk) == "table" then
            local parts = {}
            for kind, n in pairs(sk) do parts[#parts + 1] = kind .. " " .. tostring(n) end
            table.sort(parts)
            sum[#sum + 1] = k .. ": " .. table.concat(parts, ", ")
        end
    end
    if #sum > 0 then out[#out + 1] = "  zusammengefasst: " .. table.concat(sum, " · ") end
    return out
end
