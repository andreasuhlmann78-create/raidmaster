-- BuffSentinel - Data/Paladin.lua  (Feldbeschreibung siehe Data/Warrior.lua)

local ADDON, BS = ...
local L = BS.L
BS.ClassData = BS.ClassData or {}

-- Siegel (Classic-Familie): jedes Siegel zählt als vorhanden
local SEALS = { 21084, 20154, 20375, 21082, 20165, 20166, 20164, 31801, 31892, 53736 }

BS.ClassData.PALADIN = {
    specNames       = { L.HOLY, L.PROTECTION, L.RETRIBUTION },
    specNamesModern = { L.HOLY, L.PROTECTION, L.RETRIBUTION },
    icon = "Interface\\Icons\\Spell_Holy_HolyBolt",
    entries = {
        ----------------------------------------------------------------
        -- Classic-Familie
        ----------------------------------------------------------------
        -- Siegel: Schutz/Vergeltung -> Rechtschaffenheit/Befehl, Heilig -> Weisheit/Licht
        { key = "seal",       kind = "buff", spell = { 20154, 21084, 20375 }, noForever = true,
          spellBySpec = { [1] = { 20166, 20165, 20154, 21084 }, [3] = { 20375, 31801, 31892, 20154, 21084 } },
          auras = SEALS, label = L.SEAL, alert = L.ALERT_SEAL, mode = "combat" },
        -- WoW Forever: neues Siegel der Wut (Tank-Siegel mit Absorb und Spott-Richturteil)
        { key = "seal_f",     kind = "buff", forever = true, spell = { 20154, 21084, 20375 },
          spellBySpec = { [1] = { 20166, 20165, 20154, 21084 }, [2] = { "Seal of Fury", 20154, 21084 },
                          [3] = { 20375, 20154, 21084 } },
          auras = { 21084, 20154, 20375, 21082, 20165, 20166, 20164, "Seal of Fury" },
          label = L.SEAL, alert = L.ALERT_SEAL, mode = "combat" },
        { key = "aura",       kind = "buff", spell = { 465, 7294, 19746, 19876 }, auras = { 465, 7294, 19746, 19876, 19888, 19891, 20218, 32223 },
          label = L.AURA, alert = L.ALERT_AURA },
        { key = "rfury",      kind = "buff", spell = 25780, specs = { 2 } },
        { key = "kings",      kind = "buff", spell = 20217, group = true, groupSpell = 25898, optional = true },
        -- Symbol der Offenbarung für Göttliches Eingreifen (Spieldaten bs-n1-rest.md Abschnitt 3: 19752 -> 17033, alle Zweige):
        -- keins dabei -> Hinweis, nur in der Gruppe (dort rettet es einen Versuch)
        { key = "r_divinity", kind = "buff", alertOnly = true, max = 3, iconSpell = 19752, label = L.SUPPLY_DIVINITY,
          alert = L.ALERT_DIVINITY, supply = { low = 1, groupOnly = true, hint = L.SUPPLY_HINT_DIVINITY, ranks = { { 19752, 17033 } } } },
        -- Symbol der Könige für Grosse Segen (BS-N1 Punkt 1, Tabelle reagenzien-gruppenbuffs.md): nur in der Gruppe
        { key = "r_symbol",   kind = "buff", alertOnly = true, max = 3, iconSpell = 25898, label = L.SUPPLY_R_SYMBOL,
          alert = L.ALERT_REAGENT, supply = { low = 20, groupOnly = true, hint = L.SUPPLY_HINT_REAGENT,
          ranks = { { 48933, 21177 }, { 48934, 21177 }, { 48937, 21177 }, { 48938, 21177 }, { 27141, 21177 },
                    { 27143, 21177 }, { 27145, 21177 }, { 27169, 21177 }, { 25782, 21177 }, { 25894, 21177 },
                    { 25898, 21177 }, { 25916, 21177 }, { 25918, 21177 }, { 25890, 21177 }, { 25895, 21177 },
                    { 25899, 21177 }, { 25919, 21177 }, { 25920, 21177 } } } },
        { key = "might",      kind = "buff", spell = 19740, group = true, groupSpell = 25782, optional = true },
        { key = "wisdom",     kind = "buff", spell = 19742, group = true, groupSpell = 25894, manaOnly = true, optional = true },

        -- Procs
        { key = "hammerwrath",kind = "proc", spell = 24275, targetBelow = 20, reactive = true, min = 1 },
        { key = "artofwar",   kind = "proc", spell = 879, procAuras = { 59578 }, min = 3, specs = { 3 },
          talents = { "The Art of War", "Die Kunst des Krieges" }, alert = L.ALERT_EXORCISM },
        { key = "grandcrus",  kind = "proc", spell = 31935, procAuras = { 85416 }, min = 4, specs = { 2 },
          talents = { "Grand Crusader", "Großer Kreuzfahrer" }, alert = L.AVENGER_S_SHIELD },
        { key = "infusion",   kind = "proc", spell = 19750, procAuras = { 54149 }, min = 3, specs = { 1 },
          talents = { "Infusion of Light", "Lichtenergie" }, alert = L.ALERT_FLASH_OF_LIGHT },
        { key = "divpurpose", kind = "proc", spell = 85256, procAuras = { 90174 }, min = 4, specs = { 3 },
          talents = { "Divine Purpose", "Göttliche Bestimmung" }, alert = L.TEMPLAR_S_VERDICT },
        -- WoW Forever: Lichtenergie – Krit von Heiliger Schock/Lichtblitz -> nächstes Heiliges Licht schneller
        { key = "infusion_f", kind = "proc", spell = 635, procAuras = { "Infusion of Light" }, forever = true, specs = { 1 },
          talents = { "Infusion of Light" }, label = L.HOLY_POWER, alert = L.HOLY_LIGHT },

        -- Cooldowns
        { key = "judgement",  kind = "cd", spell = 20271 },
        { key = "crusader",   kind = "cd", spell = 35395, min = 2, specs = { 3 } },
        { key = "dstorm",     kind = "cd", spell = 53385, min = 3, specs = { 3 } },
        { key = "templar",    kind = "cd", spell = 85256, min = 4, specs = { 3 } },
        { key = "holyshock",  kind = "cd", spell = 20473, specs = { 1 } },
        { key = "divfavor",   kind = "cd", spell = 20216, specs = { 1 }, max = 3 },
        { key = "divillum",   kind = "cd", spell = 31842, min = 2, specs = { 1 } },
        { key = "consecrate", kind = "cd", spell = 26573, specs = { 2 } },
        { key = "holyshield", kind = "cd", spell = 20925, specs = { 2 }, max = 3 },
        { key = "avengershld",kind = "cd", spell = 31935, min = 2, specs = { 2 } },
        { key = "hammerright",kind = "cd", spell = 53595, min = 3, specs = { 2 } },
        { key = "ardent",     kind = "cd", spell = 31850, min = 4, specs = { 2 } },
        { key = "avenging",   kind = "cd", spell = 31884, min = 2 },
        { key = "hoj",        kind = "cd", spell = 853 },
        { key = "rebuke",     kind = "cd", spell = 96231, min = 4 },
        { key = "divprot",    kind = "cd", spell = 498 },
        { key = "divshield",  kind = "cd", spell = 642 },
        { key = "layonhands", kind = "cd", spell = 633 },
        -- WoW Forever: neue Fähigkeiten (Talent-Goldmedaillen)
        { key = "holystrike", kind = "cd", spell = "Holy Strike", forever = true },
        { key = "lightsvigil",kind = "cd", spell = "Light's Vigil", forever = true, specs = { 1 } },
        { key = "voicetruth", kind = "cd", spell = "Voice of Truth", forever = true, specs = { 1 } },
        { key = "swiftjudge", kind = "cd", spell = "Swift Judgement", forever = true, specs = { 2 } },
        { key = "bulwark",    kind = "cd", spell = "Templar's Bulwark", forever = true, specs = { 2 } },
        { key = "consecr_f",  kind = "cd", spell = 26573, forever = true, optional = true,
          label = L.CONSECRATION_ALL_SPECS_IN_FOREVER },

        ----------------------------------------------------------------
        -- Moderne Familie (MoP, Retail)
        ----------------------------------------------------------------
        { key = "m_kings",    kind = "buff", v = "modern", spell = 20217, max = 5, group = true },
        { key = "m_might",    kind = "buff", v = "modern", spell = 19740, max = 5, group = true, optional = true },
        { key = "m_rfury",    kind = "buff", v = "modern", spell = 25780, max = 5, specs = { 2 } },
        { key = "m_aura",     kind = "buff", v = "modern", min = 12, retail = true, retailOnly = true,
          spell = { 465, 317920, 32223 }, auras = { 465, 317920, 32223 }, label = L.AURA, alert = L.ALERT_AURA },

        { key = "m_hammerwr", kind = "proc", v = "modern", spell = 24275, targetBelow = 20, reactive = true },
        { key = "m_artofwar", kind = "proc", v = "modern", spell = 879, procAuras = { 59578 }, specs = { 3 } },
        { key = "m_divpurp",  kind = "proc", v = "modern", spell = 85256, procAuras = { 90174 }, specs = { 3 } },
        { key = "m_grandcr",  kind = "proc", v = "modern", spell = 31935, procAuras = { 85416 }, specs = { 2 } },
        { key = "m_infusion", kind = "proc", v = "modern", spell = 82326, procAuras = { 54149 }, specs = { 1 } },

        { key = "m_crusader", kind = "cd", v = "modern", spell = 35395 },
        { key = "m_judgment", kind = "cd", v = "modern", spell = 20271 },
        { key = "m_holyshock",kind = "cd", v = "modern", spell = 20473, specs = { 1 } },
        { key = "m_hotr",     kind = "cd", v = "modern", spell = 53595, specs = { 2 } },
        { key = "m_avshield", kind = "cd", v = "modern", spell = 31935, specs = { 2 } },
        { key = "m_ardent",   kind = "cd", v = "modern", spell = 31850, specs = { 2 } },
        { key = "m_dstorm",   kind = "cd", v = "modern", spell = 53385, specs = { 3 } },
        { key = "m_avenging", kind = "cd", v = "modern", spell = 31884 },
        { key = "m_guardian", kind = "cd", v = "modern", spell = 86659 },
        { key = "m_holyaveng",kind = "cd", v = "modern", spell = 105809 },
        { key = "m_lhammer",  kind = "cd", v = "modern", spell = 114158 },
        { key = "m_execsent", kind = "cd", v = "modern", spell = 114157 },
        { key = "m_divfavor", kind = "cd", v = "modern", spell = 31842, specs = { 1 } },
        { key = "m_divprot",  kind = "cd", v = "modern", spell = 498 },
        { key = "m_divshield",kind = "cd", v = "modern", spell = 642 },
        { key = "m_loh",      kind = "cd", v = "modern", spell = 633 },
        { key = "m_hoj",      kind = "cd", v = "modern", spell = 853 },
        { key = "m_rebuke",   kind = "cd", v = "modern", spell = 96231 },
    },
}
