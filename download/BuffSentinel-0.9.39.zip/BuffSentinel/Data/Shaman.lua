-- BuffSentinel - Data/Shaman.lua  (Feldbeschreibung siehe Data/Warrior.lua)

local ADDON, BS = ...
local L = BS.L
BS.ClassData = BS.ClassData or {}

BS.ClassData.SHAMAN = {
    specNames       = { L.ELEMENTAL, L.ENHANCEMENT, L.RESTORATION },
    specNamesModern = { L.ELEMENTAL, L.ENHANCEMENT, L.RESTORATION },
    icon = "Interface\\Icons\\Spell_Nature_BloodLust",
    entries = {
        ----------------------------------------------------------------
        -- Classic-Familie
        ----------------------------------------------------------------
        { key = "lshield",     kind = "buff", spell = 324, specs = { 1, 2 } },
        -- Fischöl / Glänzende Fischschuppen für Wasserwandeln / Wasseratmung (Spieldaten bs-n1-rest.md Abschnitt 6:
        -- 546 -> 17058, 131 -> 17057, alle Zweige): unter 5 -> Hinweis; optional (Standard aus), auch allein
        { key = "r_fishoil",   kind = "buff", alertOnly = true, max = 3, optional = true, iconSpell = 546, label = L.SUPPLY_FISHOIL,
          alert = L.ALERT_REAGENT, supply = { low = 5, hint = L.SUPPLY_HINT_FISH, ranks = { { 546, 17058 } } } },
        { key = "r_fishscale", kind = "buff", alertOnly = true, max = 3, optional = true, iconSpell = 131, label = L.SUPPLY_FISHSCALE,
          alert = L.ALERT_REAGENT, supply = { low = 5, hint = L.SUPPLY_HINT_FISH, ranks = { { 131, 17057 } } } },
        -- Ankh für Reinkarnation (BS-N1 Punkt 1, Tabelle reagenzien-gruppenbuffs.md): auch allein, Warnung bei 0
        { key = "r_ankh",      kind = "buff", alertOnly = true, max = 3, iconSpell = 20608, label = L.SUPPLY_R_ANKH,
          alert = L.ALERT_ANKH, supply = { low = 1, hint = L.SUPPLY_HINT_ANKH,
          ranks = { { 20608, 17030 }, { 21169, 17030 }, { 27740, 17030 } } } },
        { key = "wshield",     kind = "buff", spell = 24398, min = 2, specs = { 3 } },
        { key = "wshield_f",   kind = "buff", spell = "Water Shield", specs = { 3 }, forever = true },
        -- Waffenverzauberung: Elementar -> Flammenzunge, Verstärkung -> Windzorn, Wiederherstellung -> Lebensbinder/Flammenzunge
        { key = "imbue_mh",    kind = "buff", weapon = "main", spell = { 8232, 8024, 8017 },
          spellBySpec = { [1] = { 8024, 8017 }, [2] = { 8232, 8024, 8017 }, [3] = { 51730, 8024, 8017 } },
          label = L.WEAPON_MAIN_HAND, alert = L.ENCHANT_WEAPON },
        { key = "imbue_oh",    kind = "buff", weapon = "off", spell = { 8024, 8033 }, min = 2, specs = { 2 },
          label = L.WEAPON_OFF_HAND, alert = L.ENCHANT_OFF_HAND },

        -- Procs
        { key = "elemfocus",   kind = "proc", spell = 403, procAuras = { 16246 }, specs = { 1 },
          talents = { "Elemental Focus", "Elementarfokus" }, label = L.CLEARCASTING_ELEMENTAL_FOCUS, alert = L.ALERT_CLEARCASTING },
        { key = "maelstrom",   kind = "proc", spell = 403, procAuras = { 53817 }, min = 3, specs = { 2 }, minStacks = 5,
          talents = { "Maelstrom Weapon", "Waffe des Mahlstroms" }, alert = L.ALERT_LIGHTNING_BOLT },
        { key = "maelstrom_f", kind = "proc", spell = 403, procAuras = { "Maelstrom Weapon", "Waffe des Mahlstroms" },
          forever = true, specs = { 2 }, talents = { "Maelstrom Weapon", "Waffe des Mahlstroms" }, alert = L.ALERT_LIGHTNING_BOLT },
        { key = "lavasurge",   kind = "proc", spell = 51505, procAuras = { 77762 }, min = 4, specs = { 1 },
          talents = { "Lava Surge", "Lavawoge" }, alert = L.ALERT_LAVA_BURST },
        { key = "tidalwaves",  kind = "proc", spell = 331, procAuras = { 53390 }, min = 3, specs = { 3 },
          talents = { "Tidal Waves", "Flutwellen" }, alert = L.HEALING_WAVE },

        -- Cooldowns
        { key = "lavaburst",   kind = "cd", spell = 51505, min = 3, specs = { 1 } },
        { key = "lavaburst_f", kind = "cd", spell = "Lava Burst", specs = { 1 }, forever = true },
        { key = "elemmastery", kind = "cd", spell = 16166, specs = { 1 } },
        { key = "thunderstorm",kind = "cd", spell = 51490, min = 3, specs = { 1 } },
        { key = "stormstrike", kind = "cd", spell = 17364, specs = { 2 } },
        { key = "lavalash",    kind = "cd", spell = 60103, min = 3, specs = { 2 } },
        { key = "shamrage",    kind = "cd", spell = 30823, min = 2, specs = { 2 } },
        { key = "feralspirit", kind = "cd", spell = 51533, min = 3, specs = { 2 } },
        { key = "nswiftness",  kind = "cd", spell = 16188, specs = { 3 } },
        { key = "manatide",    kind = "cd", spell = 16190, specs = { 3 } },
        { key = "riptide",     kind = "cd", spell = 61295, min = 3, specs = { 3 } },
        { key = "earthshock",  kind = "cd", spell = 8042 },
        { key = "flameshock",  kind = "cd", spell = 8050 },
        { key = "windshear",   kind = "cd", spell = 57994, min = 3 },
        { key = "bloodlust",   kind = "cd", spell = { 2825, 32182 }, min = 2 },   -- Kampfrausch (Horde) / Heldentum (Allianz)
        { key = "grounding",   kind = "cd", spell = 8177 },
        -- WoW Forever: neue Fähigkeiten
        { key = "farseer_f",   kind = "cd", spell = "Rage of the Farseer", forever = true, specs = { 2 } },
        { key = "firenova_f",  kind = "cd", spell = "Fire Nova", forever = true, specs = { 1 } },
        { key = "totproj_f",   kind = "cd", spell = "Totemic Projection", forever = true, optional = true },

        ----------------------------------------------------------------
        -- Moderne Familie (MoP)
        ----------------------------------------------------------------
        { key = "m_lshield",   kind = "buff", v = "modern", spell = 324, specs = { 1, 2 }, max = 5 },
        { key = "m_wshield",   kind = "buff", v = "modern", spell = 52127, specs = { 3 }, max = 5 },
        { key = "m_imbue_mh",  kind = "buff", v = "modern", max = 5, weapon = "main", spell = { 8232, 8024 },
          spellBySpec = { [1] = { 8024 }, [2] = { 8232, 8024 }, [3] = { 51730, 8024 } },
          label = L.WEAPON_MAIN_HAND, alert = L.ENCHANT_WEAPON },
        { key = "m_imbue_oh",  kind = "buff", v = "modern", max = 5, weapon = "off", spell = 8024, specs = { 2 },
          label = L.WEAPON_OFF_HAND, alert = L.ENCHANT_OFF_HAND },
        -- Retail
        { key = "r_skyfury",   kind = "buff", v = "modern", min = 12, retail = true, retailOnly = true, spell = 462854, group = true },
        { key = "r_lshield",   kind = "buff", v = "modern", min = 12, retail = true, retailOnly = true, spell = 192106, specs = { 1, 2 } },
        { key = "r_wshield",   kind = "buff", v = "modern", min = 12, retail = true, retailOnly = true, spell = 52127, specs = { 3 } },
        { key = "r_imbue_mh",  kind = "buff", v = "modern", min = 12, retail = true, retailOnly = true, weapon = "main",
          spell = { 33757, 382021, 318038 }, spellBySpec = { [2] = { 33757 }, [3] = { 382021 } },
          specs = { 2, 3 }, label = L.WEAPON_MAIN_HAND, alert = L.ENCHANT_WEAPON },
        { key = "r_imbue_oh",  kind = "buff", v = "modern", min = 12, retail = true, retailOnly = true, weapon = "off",
          spell = 318038, specs = { 2 }, label = L.WEAPON_OFF_HAND, alert = L.ENCHANT_OFF_HAND },

        { key = "m_maelstrom", kind = "proc", v = "modern", spell = 403, procAuras = { 53817 }, specs = { 2 }, minStacks = 5 },
        { key = "m_lavasurge", kind = "proc", v = "modern", spell = 51505, procAuras = { 77762 }, specs = { 1 } },
        { key = "m_tidal",     kind = "proc", v = "modern", spell = 77472, procAuras = { 53390 }, specs = { 3 } },

        { key = "m_lavaburst", kind = "cd", v = "modern", spell = 51505, specs = { 1 } },
        { key = "m_earthquake",kind = "cd", v = "modern", spell = 61882, specs = { 1 } },
        { key = "m_thunder",   kind = "cd", v = "modern", spell = 51490, specs = { 1 } },
        { key = "m_stormstrike",kind= "cd", v = "modern", spell = 17364, specs = { 2 } },
        { key = "m_lavalash",  kind = "cd", v = "modern", spell = 60103, specs = { 2 } },
        { key = "m_feral",     kind = "cd", v = "modern", spell = 51533, specs = { 2 } },
        { key = "m_shamrage",  kind = "cd", v = "modern", spell = 30823, specs = { 2 } },
        { key = "m_riptide",   kind = "cd", v = "modern", spell = 61295, specs = { 3 } },
        { key = "m_hrain",     kind = "cd", v = "modern", spell = 73920, specs = { 3 } },
        { key = "m_slink",     kind = "cd", v = "modern", spell = 98008, specs = { 3 } },
        { key = "m_ascend",    kind = "cd", v = "modern", spell = 114049 },
        { key = "m_unleash",   kind = "cd", v = "modern", spell = 73680 },
        { key = "m_elemmast",  kind = "cd", v = "modern", spell = 16166 },
        { key = "m_fireele",   kind = "cd", v = "modern", spell = 2894 },
        { key = "m_windshear", kind = "cd", v = "modern", spell = 57994 },
        { key = "m_bloodlust", kind = "cd", v = "modern", spell = { 2825, 32182 } },
        { key = "m_swgrace",   kind = "cd", v = "modern", spell = 79206 },
    },
}
