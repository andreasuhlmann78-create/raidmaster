# ThreatSentinel – Changelog

## 2.5.8
- Test centre and options also move away from visible windows of other GoldSentinel addons (e.g. a BuffSentinel bar with content), not only from Blizzard windows; up to four attempts, otherwise the place with the least overlap. Empty anchors still do not count
- Test routine: new case T-K2 (area K, real client only)

## 2.5.7
- Diagnostic log (WoW Forever, mode DISPLAY): once per fight, 3 seconds after the pull, a line "LESBAR-PLAKETTEN" notes for all nameplates whether "you have aggro" and your threat level are readable – not only for your target – and the same for one group member (counts only, no names). This is the groundwork for the tank's aggro warning in WoW Forever
- Test log: failed taunts now note the reason from the game's error message (e.g. "not ready yet", "out of range"); the summary lists the most frequent reasons
- Test assistant: in mode DISPLAY the nameplate, HUD and regain steps are skipped ("n/a") instead of failing – there ThreatSentinel deliberately does not change nameplates
- Sync: "nachgeholt" only counts messages that were really sent (not when sync is off or you left the group after the fight)
- Test routine: new cases T-M1, T-G1, T-W1; T-Q5 extended

## 2.5.6
- Fix (important for the developer language test): after `/ts testroutine sprache` and /reload, ThreatSentinel stopped loading (Lua error when loading, the developer check was called with a dot instead of a colon). The check is now called correctly and protected; if anything goes wrong, the game language is used and loading continues. If you ran the language test with 2.5.4/2.5.5: update and /reload, nothing else is needed
- Sync: without a group nothing is sent and no greeting ("heartbeat") either; counted separately as "ohne Gruppe" instead of "verworfen"
- Diagnostic log: the "LESBAR" line now separates "target of the mob readable" from "holder in the group"
- Test routine: new cases T-L1, T-L2; T77, T-SY2, T-P3 adjusted

## 2.5.5
- DPS view in WoW Forever (mode DISPLAY): shows the aggro warning again. The game hides the percentages but lets you read whether you have aggro and your threat level against your target: "You have aggro!" (red, warning sound once) and "Above the tank - aggro soon!" (orange). Only readable values are used, no own thresholds on protected percentages; if those are protected too, the view stays neutral as before
- Sync in combat (WoW Forever blocks addon messages there): your role/version is now sent once after the fight instead of being dropped (only the latest state). Taunt, resist and crowd-control messages are only valid in the moment and are still dropped ("Kampf, veraltet"). Diagnostic log: "nachgeholt N"
- Test routine: T144 no longer gives a false alarm when the test centre is open; "Simulations reset" compares before/after and names the switch (or "OK (… was already on)"); a note line at the start when test mode, move mode or the test centre is already on; new cases T-Q1 to T-Q5; T169 adjusted

## 2.5.4
- Correction to 2.5.1/2.5.2: the estimate from damage and healing (step 3 of the threat meter order) only works when the game provides damage and healing – in WoW Forever it currently does not (no combat log). There the order uses who has aggro and the threat level when readable, otherwise "Order: tank first"
- Threat meter header: "Order: certain" only when someone from the group really has aggro on the mob or all threat levels are readable; otherwise "Order: tank first"
- Fix (WoW Forever): a /reload during a fight could still switch the threat mode to FULL in that fight; the fight is now also checked directly with the game
- Diagnostic log: the "LESBAR" line is only written in combat with a non-empty list (the empty list before the pull is no longer measured)
- Test log summary: a /reload no longer restarts the evaluation ("META cont=1" stays in the same session); changing an option resets it
- Damaged SavedVariables are repaired on loading: wrong value types are replaced by the default (e.g. a text where a number belongs); damaged top-level entries are discarded
- Sync: no group -> nothing is sent (counted as "kein Weg" in the diagnostic log)
- Test routine: developer language test (`/ts testroutine sprache`, then /reload and `/ts testroutine f`, T128); new cases T-P1b, T-A6b, T-A8, T139b, T122 (on a copy), T-SY2

## 2.5.3
- Fix (WoW Forever): the threat mode no longer jumps to FULL during a fight (seen in a dungeon: DISPLAY -> FULL -> DISPLAY within one fight). A readable value during a fight is only noted; ThreatSentinel switches to FULL only out of combat and only after two fights with readable values and nothing protected. Once protected values are seen in a fight, it stays DISPLAY until the fight ends
- Test centre and options no longer open on top of open Blizzard windows (character window, map, vendor, mailbox …) – they move next to them. Tooltips of the test centre appear next to the window instead of over its buttons
- Interface check: messages now name the exact element (path, label, position); other addons' empty anchor frames (invisible containers) no longer count as covered windows
- Diagnostic log: the "LESBAR" line also notes which unit was checked and whether the mob attacks you (yes/no/protected, no names); the group line counts players and pets separately; sync counters (sent, received, dropped with reason) every 10 minutes – ThreatSentinel syncs only via party/raid, never via a custom channel
- GoldSentinelTest 2: share error reports with the developer (only with consent, /gstest)
- Test routine: new cases T-P1 (no FULL during a fight), T-P3, T-GT1, T-GT2; test scene now replaces the stored detection too (T153 failed in the real client because the stored "secret" overrode the scene)

## 2.5.2
- Shared file `GoldSentinelGame.lua` updated to the official version 3 (comments and examples only, code unchanged)

## 2.5.1
- Threat meter in WoW Forever (mode DISPLAY, protected values): sorted by aggro again – whoever has aggro on top, then the next and so on. ThreatSentinel takes the best available step: 1) who has aggro (target of the mob, otherwise "is tanking") if readable, 2) the threat level 3/2/1/0 if readable, 3) an estimate from damage and healing in this fight with classic factors (warrior tank ×1.3, druid in bear form ×1.3, paladin with Righteous Fury ×1.6, rogue ×0.71, healing ×0.5 split over the enemies), marked with "~" in front of the name. A small second header line shows "Order: certain", "Order: ~ estimated" or "Order: tank first" (nothing readable, no estimate yet). Bars still show the real values, only the order changes. Damped against flicker: at most every 0.5 s, estimates swap only above 10 % difference. Era/TBC (readable values) unchanged
- Diagnostic log: once per fight a line "LESBAR Ziel-des-Mobs=ja/nein · Stufe=ja/nein · isTanking=ja/nein · Schätzung=ja/nein" (what WoW Forever lets ThreatSentinel read; no names)
- Test log summary: evaluated in small steps in the background and only new entries when opened (was up to 45 ms at once, T139)
- Test routine: new cases T-A1 to T-A7 (holder on top, threat levels, estimate with "~", damping, Era/TBC unchanged, protected target of the mob, header not cut off); T167 adjusted to the new order

## 2.5.0
- Test routine: the last 13 skipped cases now run automatically – "not automated: 0". New: AoE taunt, emergency and healer-range hints (T66), taunt resisted with backup and sync (T68), tank under loss of control (T69), taunt key hint (T71), combat-log taunt on Era/TBC (T72), own spells: cooldown, taunt, sunder, seal (T78), group crowd control (T79), resist detection without combat log in WoW Forever (T80), spec and inspect (T82), taunt buttons and key binding (T88), sound and colour picker, popups (T91), minimap button (T92), per-frame updates (T138)
- Internal: timers after own spells, the combat log, loss of control, the taunt key hint and key bindings now also go through `ns.API`; the key hint window goes through the central action function. Normal play: unchanged

## 2.4.9
- New: diagnostic log (taken over from the GoldSentinel template). ThreatSentinel notes what only happens in the real game: errors (the same message in a row is only counted), slow updates (longer than one frame), changes of the threat mode and of the threat detection in WoW Forever, start of combat. `/ts protokoll` or "Show diagnostic log" in the options opens it for copying. On logout / `/reload` it is stored as `GSDIAG1` text in the SavedVariables, so the uploader can send it (option "Send diagnostic log automatically", on by default). No player, character, guild or realm names
- Test routine: new cases T187 (entries, counter instead of a loop, export, no names), T189 (no entries during the test routine), T188 (check in the client)

## 2.4.8
- Test routine: new area K "interface in the real client" (`/ts testroutine k`, button K in the test centre), taken over from the GoldSentinel template (`UICheck.lua`): own tooltips cover no buttons (T180), own windows do not overlap Blizzard windows or windows of other GoldSentinel addons (T181), windows lie fully on screen (T182), button labels are not cut off (T183), displayed game values are plausible (T184: level, class, own name without realm, group complete, threat mode, taunt learned), no error loop with the same message more than 10 times (T185). Only reads, changes nothing; without a real client these cases are skipped, never counted as OK
- All own windows (options, test centre, test assistant, reports, sound picker, move bar) and combat displays (threat meter, DPS view, damage/healing meter, HUD, taunt buttons, minimap button) are registered for this check. Combat displays are not docked to Blizzard windows, so they are only checked for screen, tooltips and labels

## 2.4.7
- Fix (WoW Forever): your own character's name no longer carries the realm. Names on your own realm are now written exactly like the senders of addon messages, so tank sync, roles and owners match reliably (test case T22)
- Internal: addon messages, CVars and addon data (`C_ChatInfo`, `C_CVar`, `C_AddOns` and the old single functions) now also go through `ns.API`; new test case T106 (these functions missing -> no Lua error, sync falls back cleanly)
- Test routine: the deliberate errors of the self-test are still counted, but no longer reported as "errors in game"

## 2.4.6
- Test routine (developer only): new test scene with test units, a test group and test nameplates. It works only through `ns.API` and the test centre's own preview nameplates and never touches Blizzard's nameplates or functions. 24 previously skipped cases now run automatically (seal and taunt, tank detection, group update, threat check candidates, mob states, loose mobs with claims and owners, hint text, regular tick, single evaluation, nameplate events, aggro leader, nameplate lookup, nameplate look per state and per option, reset and flash, alerts, other tanks' messages, sync hello, threat meter order, HUD, health, protected threat in a full run, speed with 10 and 40 mobs, forbidden nameplates)
- Test report: new line "not automated: N" for the cases that are still missing
- Normal play: unchanged

## 2.4.5
- **Important: versions 2.0.0 to 2.4.3 did not load at all** (Lua error in `Core.lua` right at the start, so no module ran). 2.4.4 fixed this – if you are still on 2.0.0–2.4.3, please update now. Everything added since 2.0.0 (group view, damage/healing meter, spec check, WoW Forever detection) only works from 2.4.4 on
- Internal: every Blizzard function ThreatSentinel uses is picked once in the new file `API.lua` (`ns.API`) and called from there. No Blizzard function is replaced; the test routine can now check protected values, missing functions and the combat lock safely through this table
- Test routine: many previously skipped cases now run (cooldowns, range, auras old and modern, mob keys, protected names, missing threat functions, sync combat lock, "unknown" + protected values -> DISPLAY, threat meter order in DISPLAY, nameplate inspection, visibility of meter and DPS view, every option on/off); new checks "no new globals" (T131) and "error count in the diagnosis" (T161)
- Test routine: if anything goes wrong while resetting, the routine always stops cleanly (nothing stays paused, all actions run normally again) and reports the error
- Errors that were caught silently (log, nameplate reset, moving frames, setting CVars, emergency curve) are now also reported to the review (`GoldSentinelTest`), without changing the error count in the game
- Screenshots of the test log go through the central action function (only logged during the test routine)
- The test routine buttons in the test centre are only shown to the developer

## 2.4.4
- Fix: Lua error while loading `Core.lua` ("attempt to call method 'On'"): two combat events were registered before the event function existed. They are now registered after it; behaviour otherwise unchanged
- New test routine for the developer (`/ts testroutine`, `/ts testroutine a`–`j`, `halb`, `letzte`; button "Run all tests" and one button per area in the test centre). Results and caught Lua errors go to the review via the shared file `GoldSentinelTest.lua`. The routine replaces no Blizzard function, runs only out of combat, sends nothing to chat or the group and restores all settings afterwards
- Internal: actions with consequences (chat, addon messages, CVars, key bindings, reload, inspect, sounds) run through one place so the test routine can log them instead of executing them

## 2.4.3
Fixes from the review (WoW Forever):
- First fight after login: as long as it is not yet known whether threat values are readable, ThreatSentinel does not touch nameplates in combat (DISPLAY until there is a result); protected values switch to DISPLAY right away; if a fight returns no data at all, OFF applies to that fight only
- DISPLAY mode: threat meter and DPS view make no own decisions – fixed order (tank, then group), no lead text, neutral bar colour
- Blizzard threat displays also with "display only", and right away when ThreatSentinel is enabled (out of combat); note in the settings that there is no Blizzard setting for nameplate threat colours
- Test centre: button "Simulate client: Forever" (self-test with GoldSentinelGame)

## 2.4.2
Fixes from the review:
- The "threat data is protected" note and turning on Blizzard's threat displays only happen while ThreatSentinel is enabled
- Test centre: the "readable" simulation no longer overrides a real lock; the button then shows "real lock"
- Modern API: unit comparisons (UnitIsUnit) go through a safe check
- Protected-value checks go through GoldSentinelGame everywhere

## 2.4.1
- `GoldSentinelGame.lua` updated to version 2 (wins over early, withdrawn copies in other GoldSentinel addons; no Lua errors when several addons are loaded together)

## 2.4.0
- **Shared version detection of all GoldSentinel addons** (`GoldSentinelGame.lua`, `/gsgame`): WoW Forever and Retail count as modern API everywhere, Classic Era, TBC, Wrath, Cata and MoP Classic as old API. ThreatSentinel uses it for the modern API, names (without realm, protected names are never processed) and protected-value detection; the diagnosis and "Check threat" show the detected game version.
- Combat log only locked on the modern API: **damage and healing meters on TBC Anniversary** now work (wrongly off before), and resisted taunts on TBC are detected directly again.

## 2.2.0
- **WoW Forever: in-game threat detection**. ThreatSentinel no longer assumes that threat values are locked; it checks once per fight (modern API) and picks the matching mode:
  - **FULL** (values readable, and Classic Era / TBC): everything as before
  - **DISPLAY** (values protected in combat): no own decisions – no glowing or fading of nameplates, no threshold sounds; threat meter and DPS view show the protected values as bars; Blizzard's threat displays (percent on the target frame, threat warning) are turned on out of combat. Note once per fight.
  - **OFF** (no threat data): threat displays hidden; tank sync, roles and taunt cooldowns stay
- New: **"Check threat"** (`/ts threat` or the button under General) shows mode, status, percent (or "protected"), the last detected state with date and build, and caught errors
- New setting **Threat mode**: automatic (default) or display only
- Test centre: threat access can be simulated (readable / protected / not available)
- Modern API: the mob-target fallback is gone; no changes to Blizzard nameplates in combat when values are protected; protected names and numbers are never processed; empty aura lists in combat count as "unknown"; tank sync does not send in combat
- Caught errors are reported (modern API) once per session in chat and counted in the diagnosis and in "Check threat"
- DISPLAY mode remembers your own Blizzard settings and restores them in FULL mode (can be turned off)
- Classic Era and TBC: unchanged

## 2.1.0
- **Group members' talents**: ThreatSentinel checks the talents of everyone in the group and raid and derives the role – protection warrior and paladin = tank, feral druid in bear form = tank, holy/discipline priest, holy paladin, restoration druid and shaman = healer, everyone else = DPS. Nameplates, warnings (frog / angel choir), threat meter and damage/healing meter follow it.
  - Your own talents are read directly (also for your own meter: shadow priest gets the damage meter, holy priest the healing meter)
  - Other players are inspected one by one out of combat and in range; players with ThreatSentinel report their role themselves
  - A second tank without the addon is detected reliably (no false alarms for his mobs)
- Settings › Group shows the **detected roles** with their source (ThreatSentinel, talents x/y/z, guessed); the check can be turned off there

## 2.0.0
- **ThreatSentinel for the whole group**: everyone with the addon gets the displays for their role.
  - **Tank**: everything as before
  - **DPS**: threat meter + new **damage meter** (group ranking, fight / total, DPS)
  - **Healer**: threat meter + new **healing meter** (ranking, HPS, without overhealing)
- **Nameplates for DPS and healers**: mobs on the tank stay normal; only danger is highlighted: **aggro soon** (orange, blinking) and **aggro on a player** (red, burning)
- **Warning sound**: the tank hears frog (DPS) or angel choir (healer). Whoever pulls aggro hears their sound and sees "You have aggro – back to the tank!". Everyone else stays quiet. Sounds under Settings › Sounds.
- Tanks without the addon are detected (visible bear form / righteous fury, otherwise whoever holds most mobs)
- New **Group** tab in the settings; meters movable and scalable (`/ts move`)
- Damage and healing meters need the combat log and are therefore only available on Classic / TBC, not on WoW Forever
- Note: non-tanks who had turned off "only active as tank" now get the group view (can be turned off under Group)

## 1.8.1
- New sounds **angel choir** and **frog**. Default now: healer has aggro = angel choir, DPS has aggro = frog. Horn, alarm horn and all other sounds stay selectable; sounds you chose yourself are kept.

## 1.8.0
- **Much stronger effects**:
  - **Aggro soon (orange)**: fully visible, slightly larger, thick border, fast blinking, orange glow and a shock wave on change
  - **Aggro on a player (red)**: bigger, brighter flames (two layers), red pulsing glow, shock wave on change, larger plate (140 %), thicker border
  - New settings under Nameplates › Effects: glow and shock wave on/off, effect strength (50–200 %)
- **Own sound for the healer**: new **alarm horn** (three rising honks) – DPS get the single horn, so you hear who has aggro without looking.
- **Test report on TBC and Classic: visual check only** – only what you see is checked: held plates, health bars, aggro soon (fully visible, orange, blinking, glowing), loose plates (border, colour, pulse, flames, glow), plate size, raid mark and cast bar, flash, HUD, threat meter, DPS view, messages. On WoW Forever the full report with all functional checks stays.

## 1.7.4
- **Aggro on a player**: the nameplate **burns** (animated flames around it) and the border is **red** – for DPS too (previously orange; orange now means "aggro soon"). Flames can be turned off under Nameplates, colours selectable.

## 1.7.3
- When the tank loses aggro to a player (DPS or healer), a **horn** sounds by default. Sounds you chose yourself stay; freely changeable under "Sounds".

## 1.7.2
- **Aggro soon** (early warning): the nameplate is now fully visible with an **orange, fast-blinking border** (can be turned off under Nameplates; colour selectable)
- **Sounds only on aggro loss by default** (to DPS / healer). Regained, resisted, emergency and the DPS view warning are silent by default and can be turned on again under Sounds. Sounds you changed yourself stay as they are.

## 1.7.1
- Test and developer features (test centre, test assistant, test log `/ts log`, dungeon check) are now only visible to the developer (shared detection `GoldSentinelDev.lua` of all GoldSentinel addons, `/gsdev` shows the status). For everyone else the addon stays tidy.

## 1.7.0
- **Freely selectable sounds**: every sound (aggro lost to DPS / healer, early warning, resisted, regained, emergency, DPS view) has a picker with three groups: ThreatSentinel sounds, **sounds** (horn, double horn, foghorn, siren, alarm bell, bell, gong, whistle, drum, double beep, ping) and **WoW sounds** (raid warning, ready check, alarm, boss whisper, whisper, map ping …). Left click chooses and plays, right click only plays.
- **Own sound**: a WoW sound ID (number, e.g. from wowhead.com/sounds) or your own .ogg/.mp3 file in `Interface\AddOns\ThreatSentinel_Sounds` (kept on updates; restart the game once after adding files)
- New: own sound for the **early warning** (yellow border, off by default) and for the DPS view warning (previously the same sound as "aggro lost to DPS")
- **Dungeon check**: when you enter a dungeon as a tank, the test log runs automatically. When you leave the instance, the report appears (aggro losses and regains, nameplates, sounds, alerts, HUD, threat meter, taunts, errors, plus fights in tank stance and who you lost aggro to). Dying and running back as a ghost or /reload do not interrupt the check. If you did not tank, there is no report. Settings under "General" (raids too, screenshots, show last report).
- **Threat meter and DPS view** (own threat) can be moved freely and resized (size and width) – the small HUD too. New button "Move windows / change size" (Display tab) or `/ts move`: drag the windows, mouse wheel changes the size, right click resets to 100 %. Windows stay in place while resizing.
- Test report: the DPS view no longer counts as failed while tanking (it is hidden on purpose); taunts from the action bar count without the taunt key; after /reload the evaluation covers the whole session

## 1.6.1
- Test report: "Loose nameplate highlighted" no longer fails on Classic Era (the border was there; the check also required a visibility value that Classic reports differently). The log now records both `shown` and `visible`.
- Test assistant: the HUD step is checked automatically (test mobs often die before the question can be answered)
- Clearer wording of the aggro-loss line in the report

## 1.6.0
- New **test log** for unattended tests: `/ts log on | off | clear | status | report | shots` or the button in the test centre. Writes machine-readable lines to the SavedVariables (`ThreatSentinelDB.testlog`): session info (client, class, form, pet, all settings) and events – combat, mobs, state changes, threat, the **actual** nameplate state (alpha, scale, border, pulse, flash, hint, raid mark, cast bar), alerts, sounds, HUD, threat meter, DPS view, taunts, resists, crowd control, sync, key hint, errors, blocked actions, test assistant steps. Ring buffer of 5000 entries, only changes are written, protected values appear as SECRET. Off by default; when off it does nothing.
- **In-game test report**: when the test log is turned off (or the test assistant finishes), ThreatSentinel evaluates the log itself and shows a report: aggro losses and regains (with average time), held / loose nameplate appearance and colour, flash on regain, HUD, threat meter, DPS view, messages, sounds, taunt key, errors. `/ts log report` or "Evaluate" in the test centre shows it again; it is also included in the copyable report.
- The test assistant now turns the test log on at the start and off at the end
- Automatic screenshots while the test log is on (loose mob, aggro regained, each new alert type, first threat meter in combat), max. 1 per 2 s (test mobs often live only ~10 s) and 25 per session; `/ts log shots` toggles them

## 1.5.0
- New **test assistant** (`/ts guide` or the button in the test centre): guides you in-game step by step through all features, detects most steps automatically, asks yes/no for what only you can see, keeps its progress over /reload and adds the results to the report
- Live test option "pet is the tank" (hunter / warlock): your pet tanks, you are the DPS who pulls aggro; the taunt key makes the pet cast Growl / Torment
- Classic Era: interface numbers 11509 / 11510 added

## 1.4.5
- Slider input fields select their content when clicked, so typing replaces the value
- Test messages get a dark background while testing, so they are readable on top of the test centre
- The report shows the name of the active form / stance, not just its number
- The "… is enough" setting is labelled per class (warrior: Sunder, others: Threat)

## 1.4.4
- Retail: a Guardian druid only counts as tanking in bear form (not in cat, travel or caster form)
- Binding the taunt key now asks before replacing an existing key binding
- Options of other classes are hidden (e.g. Sunder Armor stacks only for warriors)
- Sliders have -/+ buttons and an input field for exact values
- Test centre: messages appear in front of the window; new button "Play all one after another"; every line in "WoW Forever protection" explains on mouseover how to check it; the report now includes date, specialisation, form, environment (world / dungeon / raid) and group
- Clearer wording: pets and NPC followers count as DPS in the live test

## 1.4.3
- Small HUD and threat meter now sit at the right screen edge by default instead of next to your character, so they no longer cover nameplates. Windows you moved yourself stay where they are.

## 1.4.2
- Fixed: on Retail (and WoW Forever) every login showed "ThreatSentinel has been blocked". The combat log is no longer registered on clients with protected values; resisted taunts are detected via threat instead.
- Blocked actions are now counted and listed in the test centre report
- Demo: preview mobs always appear in the HUD (also with real nameplates nearby); no AoE taunt hint for classes without one
- Test messages ("Show sample") now appear in front of the settings window
- Threat meter: title and lead no longer run into each other
- Switching between demo and live test is now shown on screen

## 1.4.1
- Loads on Retail (Midnight) as a test bed: Retail already has the addon restrictions that WoW Forever takes over. Tank detection there by tank specialisation; taunts for Death Knight, Demon Hunter, Monk and Paladin (Hand of Reckoning) added.

## 1.4.0
- Prepared for WoW Forever: the game can protect values in combat ("secrets"). ThreatSentinel never calculates with protected values and switches to a fallback instead of producing Lua errors:
  - Aggro: threat status instead of percentages; threat meter and DPS view let the game display the values
  - Cooldowns: timed by the addon from your own casts (learns the real duration)
  - Taunt resisted without combat log: checked via threat right after the taunt
  - Seal of Fury, Righteous Fury, Sunder Armor stacks and crowd-controlled mobs: tracked from your own / your group's spells
  - Mob identity without GUID: by nameplate; tank sync: other tanks recognised by their target
  - Emergency hint: shown via the game's own health percent where possible
- Errors in one part no longer stop the rest of the addon
- Test centre: new column "WoW Forever protection" (green / yellow / red per feature), "Simulate Forever restrictions" to try all fallbacks on other clients, and "Copy report"

## 1.3.0
- Held nameplates now default to 35 % opacity and 80 % size (adjustable). Raid markers and cast bars always stay fully visible.
- "Taunt resisted" now names the backup that is ready, e.g. "Taunt resisted » Mocking Blow!" (warrior: Mocking Blow, then Challenging Shout; druid: Challenging Roar)
- One-time hint when you first enter an instance with no taunt key bound
- Message in the middle: smaller, size and height adjustable, ordered by importance (an important message is no longer replaced by a less important one). "Aggro regained" only flashes the nameplate by default.
- New short sounds of its own, so they are not mixed up with DBM/BigWigs or ready checks
- Chat messages now go only to the other tanks by default (via sync). New option: party/raid during boss fights only.
- Threat meter: 100 % now always means "pulls aggro now" (110 % melee / 130 % ranged rule included); "About to pull!" instead of "Lead 0 %"
- Raid markers: skull before cross in the loose list, with icon
- Presets: Subtle, Standard, Loud
- Tank sync: a short initial (e.g. "G" for Grimbar) instead of "taken by Grimbar"

## 1.2.3
- Paladin taunt reworked (detected by spell ID, not by name):
  - TBC: Righteous Defense is cast on the ally the mob is attacking (mouseover mob, otherwise your target's target)
  - WoW Forever: Judgement only counts as a taunt with Seal of Fury active; without it the nameplate shows "Seal of Fury missing"
  - Removed Hand of Reckoning (does not exist before Wrath)
- Diagnostics show the paladin taunt type and whether Seal of Fury is active

## 1.2.2
- Fixed: the addon did not load in TBC Classic Anniversary 2.5.6 (unknown event stopped loading – /ts and the minimap button were missing). Unknown events are now skipped.
- Added interface 20506 (TBC Classic Anniversary 2.5.6), so the addon is no longer marked as out of date
- The arrow in "» Name (Role)" is now shown correctly (the old character was missing from the WoW font)
- Test centre: preview nameplates in two rows, no more overlapping
- Test messages stay visible when the demo is stopped

## 1.2.1
- New **Support** button (PayPal) in the title bar of the settings window and "Support the addon" on the General page. Also `/ts donate`. It never opens by itself.

## 1.2.0
- New **test centre** (right-click the minimap button or `/ts test`): demo with preview nameplates, solo live test, every alert on its own button, simulated tank sync and live diagnostics
- Runs on Classic Era / Anniversary and TBC Anniversary as well as WoW Forever

## 1.1.0
- First release: loose mobs light up, held mobs fade out, taunt on mouseover, threat meter, tank sync
