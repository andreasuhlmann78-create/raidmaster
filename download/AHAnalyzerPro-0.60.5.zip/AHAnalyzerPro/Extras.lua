-- ============================================================
-- AH Analyzer Pro 0.59.30 - Extras
--   * Händler-Verkauf: Schrott und alles, was beim Händler mehr bringt als im AH
--   * Inventarwert: Taschen, Bank und Twinks zu Marktwert und Händlerpreis
--   * Tagesbilanz beim Einloggen
--   * Flip-Empfehlungen: oft angeboten, gerade günstig, Gewinn nach Gebühr
--   * Neu einstellen: abgelaufene/abgebrochene Auktionen aus der Post wieder einstellen
--   * Post an Twinks: Waren nach Regeln an andere Charaktere schicken
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local X = {}
A.Extras = X

local function Now() return GetTime() end
local AH_CUT = 0.95

-- ------------------------------------------------------------
-- Taschen lesen (alle Clients)
-- ------------------------------------------------------------
local function NumSlots(bag)
    if C_Container and C_Container.GetContainerNumSlots then return C_Container.GetContainerNumSlots(bag) or 0 end
    if GetContainerNumSlots then return GetContainerNumSlots(bag) or 0 end
    return 0
end

-- itemID, Anzahl, Qualität, Link, ohne Wert, gebunden, gesperrt
local function SlotInfo(bag, slot)
    if C_Container and C_Container.GetContainerItemInfo then
        local info = C_Container.GetContainerItemInfo(bag, slot)
        if not info then return nil end
        local id = info.itemID or (info.hyperlink and tonumber(info.hyperlink:match("item:(%d+)")))
        return id, info.stackCount or 1, info.quality, info.hyperlink, info.hasNoValue, info.isBound, info.isLocked
    end
    if GetContainerItemInfo then
        local _, count, locked, quality, _, _, link, _, noValue, id = GetContainerItemInfo(bag, slot)
        id = id or (link and tonumber(link:match("item:(%d+)")))
        if not id then return nil end
        return id, count or 1, quality, link, noValue, nil, locked
    end
    return nil
end
X.SlotInfo = SlotInfo

local function UseItem(bag, slot)
    if C_Container and C_Container.UseContainerItem then return pcall(C_Container.UseContainerItem, bag, slot) end
    if UseContainerItem then return pcall(UseContainerItem, bag, slot) end
    return false
end

local function PickupItem(bag, slot)
    if C_Container and C_Container.PickupContainerItem then return pcall(C_Container.PickupContainerItem, bag, slot) end
    if PickupContainerItem then return pcall(PickupContainerItem, bag, slot) end
    return false
end

local function EachBagSlot(fn)
    for bag = 0, (NUM_BAG_SLOTS or 4) do
        for slot = 1, NumSlots(bag) do
            local id, count, quality, link, noValue, bound, locked = SlotInfo(bag, slot)
            if id then fn(bag, slot, id, count, quality, link, noValue, bound, locked) end
        end
    end
end

-- ============================================================
-- 1. Händler-Verkauf
-- ============================================================
-- verkauft wird: graue Items (Schrott) und Items, die beim Händler mehr bringen
-- als im Auktionshaus nach dem AH-Anteil (nur wenn ein Marktwert bekannt ist)
function X:VendorCandidates()
    local list, total, junk, better = {}, 0, 0, 0
    EachBagSlot(function(bag, slot, id, count, quality, link, noValue, bound, locked)
        if locked or noValue then return end
        local vp = A:GetVendorPrice(id)
        if not vp or vp <= 0 then return end
        local reason
        if quality == 0 then
            reason = "junk"
        else
            local mv = A:GetMarketValue(id)
            if mv and mv > 0 and vp > mv * AH_CUT then reason = "vendor" end
        end
        if reason then
            local value = vp * count
            table.insert(list, { bag = bag, slot = slot, itemID = id, count = count, value = value, reason = reason })
            total = total + value
            if reason == "junk" then junk = junk + value else better = better + value end
        end
    end)
    return list, total, junk, better
end

function X:IsAtMerchant()
    return self.atMerchant and (not MerchantFrame or (MerchantFrame.IsShown and MerchantFrame:IsShown())) or false
end

-- ein Klick: alles verkaufen (nacheinander, damit der Server mitkommt)
function X:SellToVendor()
    if not self:IsAtMerchant() then return false, L["Erst einen Händler ansprechen."] end
    if self.selling then return false, L["Verkauf läuft schon ..."] end
    local list, total = self:VendorCandidates()
    if #list == 0 then return false, L["Nichts zu verkaufen: kein Schrott und nichts, was beim Händler mehr bringt."] end
    self.selling = { list = list, pos = 1, sold = 0, value = 0, next = 0 }
    return true, string.format(L["Verkaufe %d Items für %s ..."], #list, A:FormatMoney(total))
end

function X:SellStep()
    local s = self.selling
    if not s then return end
    if not self:IsAtMerchant() then
        self.selling = nil
        A:Print(string.format(L["Händler-Verkauf abgebrochen: %d Items für %s verkauft."], s.sold, A:FormatMoney(s.value)))
        return
    end
    if Now() < s.next then return end
    local e = s.list[s.pos]
    if not e then
        self.selling = nil
        A:Print(string.format(L["|cff33dd55Beim Händler verkauft:|r %d Items für %s."], s.sold, A:FormatMoney(s.value)))
        A:Fire("VENDOR_CHANGED")
        return
    end
    s.pos = s.pos + 1
    -- liegt noch dasselbe Item im Platz?
    local id, count = SlotInfo(e.bag, e.slot)
    if id == e.itemID then
        if UseItem(e.bag, e.slot) then
            s.sold = s.sold + 1
            s.value = s.value + e.value
        end
    end
    s.next = Now() + 0.15
end

-- ============================================================
-- 2. Inventarwert (Taschen, Bank, alle Twinks)
-- ============================================================
function X:InventoryValue()
    local chars = A.db and A.db.chars or {}
    local myKey = A.Chars and select(2, A.Chars:Me())
    if A.Chars and A.Chars.ScanBags then pcall(A.Chars.ScanBags, A.Chars) end
    local byID, rows = {}, {}
    local function add(id, n, where)
        local r = byID[id]
        if not r then
            r = { itemID = id, count = 0, bags = 0, bank = 0, alts = 0 }
            byID[id] = r
            table.insert(rows, r)
        end
        r.count = r.count + n
        r[where] = r[where] + n
    end
    for key, c in pairs(chars) do
        local mine = key == myKey
        for id, n in pairs(c.bags or {}) do add(id, n, mine and "bags" or "alts") end
        for id, n in pairs(c.bank or {}) do add(id, n, mine and "bank" or "alts") end
    end
    local totalMV, totalVendor, out = 0, 0, {}
    for _, r in ipairs(rows) do
        local mv = A:GetMarketValue(r.itemID)
        local vp = A:GetVendorPrice(r.itemID)
        r.unit = mv
        r.value = mv and math.floor(mv * r.count) or 0
        r.vendorValue = vp and vp * r.count or 0
        -- im AH nur Wert, wenn es sich dort lohnt; sonst zählt der Händlerpreis
        r.best = math.max(math.floor(r.value * AH_CUT), r.vendorValue)
        totalMV = totalMV + r.value
        totalVendor = totalVendor + r.vendorValue
        if r.value > 0 or r.vendorValue > 0 then
            r.name = A:GetItemName(r.itemID)
            table.insert(out, r)
        end
    end
    local gold = A.Chars and A.Chars.TotalMoney and A.Chars:TotalMoney() or 0
    return out, { market = totalMV, vendor = totalVendor, gold = gold, chars = A:CountTable(chars) }
end

-- ============================================================
-- 3. Tagesbilanz beim Einloggen
-- ============================================================
function X:SummaryRange(from, to)
    local s = { income = 0, spent = 0, fees = 0, refunds = 0, sales = 0, buys = 0 }
    local entries = A.db and A.db.ledger and A.db.ledger.entries or {}
    for _, e in ipairs(entries) do
        if e.t >= from and e.t < to then
            if e.kind == "sale" then
                s.income = s.income + e.amount - (e.cut or 0)
                s.refunds = s.refunds + (e.refund or 0)
                s.sales = s.sales + 1
            elseif e.kind == "buy" then
                s.spent = s.spent + e.amount
                s.buys = s.buys + 1
            elseif e.kind == "deposit" then
                s.fees = s.fees + e.amount
            end
        end
    end
    s.fees = s.fees - s.refunds
    s.profit = s.income - s.spent - s.fees
    return s
end

local function DayStart(t)
    local d = date("*t", t)
    return time({ year = d.year, month = d.month, day = d.day, hour = 0, min = 0, sec = 0 })
end

local function Signed(v)
    if v >= 0 then return "|cff33dd55+" .. A:FormatMoney(v) .. "|r" end
    return "|cffff5544-" .. A:FormatMoney(-v) .. "|r"
end

function X:DailyText()
    local today = DayStart(time())
    local yesterday = DayStart(today - 43200)
    local y = self:SummaryRange(yesterday, today)
    local w = self:SummaryRange(today - 7 * 86400, time() + 1)
    local parts = {}
    if y.sales + y.buys > 0 then
        table.insert(parts, string.format(L["Gestern: %s (%d Verkäufe, %d Käufe)"], Signed(y.profit), y.sales, y.buys))
    else
        table.insert(parts, L["Gestern: nichts gebucht"])
    end
    table.insert(parts, string.format(L["7 Tage: %s"], Signed(w.profit)))
    if A.Chars and A.Chars.DailyTotals then
        local days = A.Chars:DailyTotals(2)
        local a, b = days[1] and days[1].money, days[#days] and days[#days].money
        local total = A.Chars:TotalMoney()
        if a and b then
            table.insert(parts, string.format(L["Gold: %s (%s seit gestern)"], A:FormatMoney(total), Signed(b - a)))
        else
            table.insert(parts, string.format(L["Gold: %s"], A:FormatMoney(total)))
        end
    end
    local goal = A.Comfort and A.Comfort:GoldGoalText()
    if goal then table.insert(parts, goal) end
    local waiting = self:RepostCount()
    if waiting > 0 then
        table.insert(parts, string.format(L["%d Items zum Neu-Einstellen"], waiting))
    end
    return table.concat(parts, "   |   ")
end

function X:ShowDailySummary(force)
    local s = A.db and A.db.settings
    if not s then return end
    if not force and s.dailySummary == false then return end
    local day = date("%Y-%m-%d")
    if not force and s.lastSummaryDay == day then return end
    s.lastSummaryDay = day
    A:Print(L["|cffffd100Tagesbilanz|r - "] .. self:DailyText())
end

-- ============================================================
-- 4. Flip-Empfehlungen
-- ============================================================
-- Kandidat: aktueller Preis (letzte 6 Std.) mind. threshold % unter dem Marktwert,
-- regelmäßig im Auktionshaus (viele Preise in den letzten 7 Tagen), Gewinn nach AH-Anteil.
-- Rangfolge: Gewinn pro Stück x Umschlag (wie oft das Item angeboten wird)
X.FLIP_FRESH = 6 * 3600
function X:GetFlipDeals(threshold)
    local out = {}
    local now = time()
    for id in pairs(A.db and A.db.marketData or {}) do
        A:Pause()
        local price, qty, t = A:GetCurrent(id)
        local mv = A:GetMarketValue(id)
        if price and mv and mv > 0 and t and now - t <= self.FLIP_FRESH then
            local discount = (mv - price) / mv * 100
            local profit = math.floor(mv * AH_CUT - price)
            if discount >= (threshold or 20) and profit > 0 and not A:IsAbsurdProfit(price, mv) then
                -- Umschlag: Preise der letzten 7 Tage und durchschnittliche Angebotsmenge
                local n7, qsum = 0, 0
                local h = A:GetHistory(id)
                for i = #h, 1, -1 do
                    local e = h[i]
                    if e.t < now - 7 * 86400 then break end
                    if A.Usable(e) then n7 = n7 + 1; qsum = qsum + (e.q or 0) end
                end
                local avgQ = n7 > 0 and qsum / n7 or 0
                if n7 >= 3 then
                    local stars = (n7 >= 10 and avgQ >= 10) and 3 or ((n7 >= 6) and 2 or 1)
                    local sold = A.Ledger and A.Ledger.SoldCount and A.Ledger:SoldCount(id, 30) or 0
                    if sold >= 3 then stars = math.min(3, stars + 1) end
                    table.insert(out, {
                        itemID = id, name = A:GetItemName(id), price = price, ref = mv, discount = discount,
                        profit = profit, quantity = qty, stars = stars, flipDeal = true,
                        score = profit * (0.5 + stars * 0.5),
                    })
                end
            end
        end
    end
    table.sort(out, function(a, b) return a.score > b.score end)
    return out
end

-- ============================================================
-- 5. Neu einstellen: abgelaufene / abgebrochene Auktionen aus der Post
-- ============================================================
local function RepostDB()
    if not A.db then return {} end
    A.db.repost = A.db.repost or {}
    return A.db.repost
end

function X:NoteReturned(itemID, count)
    if not itemID then return end
    local r = RepostDB()
    r[itemID] = (r[itemID] or 0) + (count or 1)
    A:Fire("SELLER_CHANGED")
end

-- Items, die zurückgekommen sind und noch in den Taschen liegen
function X:RepostItems()
    local r = RepostDB()
    local out = {}
    for id in pairs(r) do
        local have = A.Seller and A.Seller:CountInBags(id) or 0
        if have > 0 then out[id] = true else r[id] = nil end
    end
    return out
end

function X:RepostCount()
    local n = 0
    for _ in pairs(self:RepostItems()) do n = n + 1 end
    return n
end

-- ein Klick: Serie starten bzw. nächste Auktion einstellen
function X:RepostStep()
    local Se = A.Seller
    if not Se then return false end
    if Se.batch and Se.batch.repost then return Se:BatchStep() end
    local ids = self:RepostItems()
    if not next(ids) then return false, L["Nichts zum Neu-Einstellen. Abgelaufene oder abgebrochene Auktionen kommen per Post - erst 'AH-Post abholen'."] end
    local ok, msg = Se:StartBatch(ids)
    if ok and Se.batch then Se.batch.repost = true end
    return ok, msg
end

-- ============================================================
-- 6. Post an Twinks
-- ============================================================
local function RulesDB()
    if not A.db then return {} end
    A.db.mailRules = A.db.mailRules or {}
    return A.db.mailRules
end
X.RulesDB = RulesDB

function X:CatByKey(key)
    for _, c in ipairs(A.Buy and A.Buy.CATS or {}) do if c.key == key then return c end end
    return nil
end

-- Kategorien für Regeln (ohne "Alle")
function X:RuleCategories()
    local out = {}
    for _, c in ipairs(A.Buy and A.Buy.CATS or {}) do
        if c.key ~= "all" and c.filters then table.insert(out, c) end
    end
    return out
end

local function ItemClass(id)
    if GetItemInfoInstant then
        local ok, _, _, _, _, _, cl, sc = pcall(GetItemInfoInstant, id)
        if ok and cl then return cl, sc end
    end
    if GetItemInfo then
        local ok, name, _, _, _, _, _, _, _, _, _, _, cl, sc = pcall(GetItemInfo, id)
        if ok and name then return cl, sc end
    end
    return nil
end

local function RuleMatches(rule, id)
    if rule.itemID then return rule.itemID == id end
    local c = rule.cat and X:CatByKey(rule.cat)
    if not (c and c.filters) then return false end
    local cl, sc = ItemClass(id)
    if not cl then return false end
    for _, f in ipairs(c.filters) do
        if cl == f[1] and (f[2] == nil or sc == f[2]) then return true end
    end
    return false
end

local function MyName()
    return UnitName and UnitName("player") or ""
end

-- was würde gerade verschickt? { [Empfänger] = { {bag, slot, itemID, count}, ... } }
function X:MailPlan()
    local plan, order = {}, {}
    local me = string.lower(MyName())
    local used = {}
    for _, rule in ipairs(RulesDB()) do
        local to = rule.to and rule.to:gsub("^%s+", ""):gsub("%s+$", "")
        if to and to ~= "" and string.lower(to) ~= me and string.lower((to:match("^([^%-]+)")) or to) ~= me then
            EachBagSlot(function(bag, slot, id, count, quality, link, noValue, bound, locked)
                local key = bag .. ":" .. slot
                if not used[key] and not bound and not locked and RuleMatches(rule, id) then
                    used[key] = true
                    if not plan[to] then plan[to] = {}; table.insert(order, to) end
                    table.insert(plan[to], { bag = bag, slot = slot, itemID = id, count = count })
                end
            end)
        end
    end
    return plan, order
end

function X:MailPlanCount()
    local plan = self:MailPlan()
    local n = 0
    for _, list in pairs(plan) do n = n + #list end
    return n
end

local function SendTabShown()
    return SendMailFrame and SendMailFrame.IsShown and SendMailFrame:IsShown()
end

-- ein Klick = eine Post (bis zu 12 Stapel) an den ersten Empfänger mit passenden Waren
function X:MailStep()
    if not (MailFrame and MailFrame.IsShown and MailFrame:IsShown()) then return false, L["Erst einen Briefkasten öffnen."] end
    if not (SendMail and ClickSendMailItemButton) then return false, L["Dein Client unterstützt das Verschicken nicht."] end
    if self.mailPending and Now() - self.mailPending < 5 then return false, L["Warte auf die letzte Post ..."] end
    local plan, order = self:MailPlan()
    local to = order[1]
    if not to then return false, L["Nichts zu verschicken (Regeln: Optionen -> Post an Twinks)."] end
    -- zum Reiter "Senden" wechseln
    if not SendTabShown() and MailFrameTab2 and MailFrameTab2.Click then pcall(MailFrameTab2.Click, MailFrameTab2) end
    if ClearSendMail then pcall(ClearSendMail) end
    local max = ATTACHMENTS_MAX_SEND or 12
    local n = 0
    for _, e in ipairs(plan[to]) do
        if n >= max then break end
        n = n + 1
        PickupItem(e.bag, e.slot)
        pcall(ClickSendMailItemButton, n)
    end
    if CursorHasItem and CursorHasItem() and ClearCursor then ClearCursor() end
    local subject = L["AH Analyzer: Waren"]
    if SendMailNameEditBox and SendMailNameEditBox.SetText then SendMailNameEditBox:SetText(to) end
    local ok, err = pcall(SendMail, to, subject, "")
    if not ok then return false, L["Verschicken fehlgeschlagen: "] .. tostring(err) end
    self.mailPending = Now()
    self.lastMail = { to = to, stacks = n }
    return true, string.format(L["Post an %s: %d Stapel ..."], to, n)
end

-- ------------------------------------------------------------
-- Ereignisse und Takt
-- ------------------------------------------------------------
local evt = CreateFrame("Frame")
for _, e in ipairs({ "MERCHANT_SHOW", "MERCHANT_CLOSED", "MAIL_SEND_SUCCESS", "MAIL_FAILED", "MAIL_CLOSED", "BAG_UPDATE" }) do
    pcall(evt.RegisterEvent, evt, e)
end
evt:SetScript("OnEvent", function(_, event)
    if event == "MERCHANT_SHOW" then
        X.atMerchant = true
        A:Fire("VENDOR_CHANGED")
    elseif event == "MERCHANT_CLOSED" then
        X.atMerchant = false
        A:Fire("VENDOR_CHANGED")
    elseif event == "MAIL_SEND_SUCCESS" then
        if X.lastMail then
            A:Print(string.format(L["|cff33dd55Verschickt:|r %d Stapel an %s."], X.lastMail.stacks, X.lastMail.to))
        end
        X.mailPending, X.lastMail = nil, nil
        A:Fire("MAILRULES_CHANGED")
    elseif event == "MAIL_FAILED" or event == "MAIL_CLOSED" then
        X.mailPending = nil
        A:Fire("MAILRULES_CHANGED")
    elseif event == "BAG_UPDATE" then
        if X.atMerchant and not X.selling then A:Fire("VENDOR_CHANGED") end
    end
end)
local acc = 0
evt:SetScript("OnUpdate", function(_, dt)
    acc = acc + (dt or 0)
    if acc < 0.05 then return end
    acc = 0
    if X.selling then X:SellStep() end
end)

A:On("READY", function()
    if C_Timer and C_Timer.After then
        C_Timer.After(8, function() pcall(X.ShowDailySummary, X) end)
    end
end)
