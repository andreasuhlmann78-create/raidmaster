-- AH Analyzer Pro - Item-Namen (esMX), 22709 Items
-- Quelle: siehe Data/QUELLEN.txt. Automatisch erzeugt, nicht von Hand ändern.
AHAnalyzerPro_NameData = AHAnalyzerPro_NameData or {}
AHAnalyzerPro_NameData["esMX"] = [==[

25	Espada corta desgastada
35	Bastón doblado
36	Maza desgastada
37	Hacha desgastada
38	Camisa de recluta
39	Pantalones de recluta
40	Botas de recluta
43	Botas de escudero
44	Pantalones de escudero
45	Camisa de escudero
47	Zapatos de asaltante de caminos
48	Pantalones de asaltante de caminos
49	Camisa de asaltante de caminos
51	Botas de neófito
52	Pantalones de neófito
53	Camisa de neófito
55	Botas de aprendiz
56	Toga de aprendiz
57	Toga de acólito
59	Zapatos de acólito
60	Guerrera a capas
61	Pantalones de cuero enano
79	Calzones de paño enano
80	Zapatos de pelaje suave
85	Jubón de cuero sucio
117	Cecina dura
118	Poción de sanación menor
120	Pantalones de matón
121	Botas de matón
127	Camisa de trampero
129	Botas de trampero bastas
139	Pantalones de camorrista
140	Botas de camorrista
147	Pantalones de trampero bastos
148	Camisa de trampero basta
153	Falda primitiva
154	Cubretorso primitivo
159	Agua de manantial refrescante
182	Cabeza de Garrick
193	Jubón de paño andrajoso
194	Pantalones de paño andrajoso
195	Botas de paño andrajoso
200	Jubón de paño grueso
201	Pantalones de paño grueso
202	Zapatos de paño grueso
203	Guantes de paño grueso
209	Pantalones de cuero sucios
210	Botas de cuero sucias
236	Armadura de cuero curado
237	Pantalones de cuero curado
238	Botas de cuero curado
239	Guantes de cuero curado
285	Jubón de malla de escamas
286	Pantalones de malla de escamas
287	Botas de malla de escamas
414	Pincho de Dalaran
422	Queso enano
537	Escama frenesí mate
555	Plumas de buitre férreas
556	Pico de águila ratonera
647	Destino
710	Brazales de La Milicia Popular
711	Guantes de paño andrajoso
714	Guantes de cuero sucios
718	Guantes de malla de escamas
719	Guantes de cuidador de conejos
720	Guantes de camorrista
723	Hígado de Dentosangre
724	Pastel de hígado de Dentosangre
725	Garra gnoll
727	Espada corta despuntada
728	Receta: estofado de los Páramos de Poniente
729	Carne fibrosa de buitre
730	Ojo de múrloc
731	Morro de dentosangre
732	Okra
733	Estofado de los Páramos de Poniente
735	Medallones de Rolf y Malakai
737	Agua de manantial sagrado
738	Saco de cebada
739	Saco de maíz
740	Saco de centeno
742	Una rama de sicomoro
743	Montón de roble carbonizado
744	Petaca de Cebatruenos
745	Documentos del alguacil McBride
748	Marcador de armaduras de Ventormenta
750	Carne de lobo dura
752	Pañuelo de arpillera roja
753	Espada corta Faucedraco
754	Espada corta de Venganza
755	Vela derretida
756	Pico de túnel
763	Brazales cubiertos de hielo
765	Hojaplata
766	Maza rebordeada
767	Bastón largo bo
768	Hacha de leñador
769	Trozo de carne de jabalí
770	Diente de crocolisco puntiagudo
771	Colmillo de jabalí astillado
772	Vela grande
773	Polvo de oro
774	Malaquita
776	Vendetta
777	Diente de merodeador
778	Pico de excavación de kóbold
779	Concha lustrosa
780	Aletas de múrloc rotas
781	Martillo gnoll de piedra
782	Banda gnoll pintada
783	Pellejo ligero
785	Marregal
787	Caballa de piel escurridiza
789	Martillo de batalla recio
790	Hacha de silvicultor
791	Bastón nudoso de fresno
792	Sandalias tricotadas
793	Guantes tricotados
794	Pantalones tricotados
795	Guerrera tricotada
796	Botas de cuero férreo
797	Guantes de cuero férreo
798	Pantalones de cuero férreo
799	Jubón de cuero férreo
804	Costal azul grande
805	Faltriquera roja pequeña
809	Cuchilla de sangre
810	Martillo del Viento del Norte
811	Hacha del Bosque Profundo
812	Bastón Madera brillante resplandeciente
813	Piñón roto
814	Frasco de aceite
816	Hoja de mano pequeña
818	Ojo de tigre
820	Hoja cercenadora
821	Jubón de cuero Zarparrío
826	Hacha Zarparrío tosca
827	Porra maligna
828	Faltriquera azul pequeña
829	Pañuelo de cuero rojo
832	Cinturón de plata Defias
833	Piedra de vida
835	Red de cuerda grande
837	Armadura de tejido pesado
838	Pantalones de tejido pesado
839	Guantes de tejido pesado
840	Zapatos de tejido pesado
841	Reloj de bolsillo de Cejade
843	Botas de cuero curtido
844	Guantes de cuero curtido
845	Pantalones de cuero curtido
846	Chaleco de cuero curtido
847	Armadura de malla de anillas
848	Pantalones de malla de anillas
849	Botas de malla de anillas
850	Guantes de malla de anillas
851	Alfanje
852	Maza
853	Hachuela
854	Bastón de intendente
856	Bolsa de cuero azul
857	Costal rojo grande
858	Poción de sanación inferior
859	Camisa de paño refinado
860	Botas de hidalgo
862	Anillo rúnico
863	Segadora penumbra
864	Tizona de Caballero
865	Maza plomiza
866	Bastón de monje
867	Guantes de Poderío Sagrado
868	Custodiador candente
869	Tizona deslumbrante
870	Hacha de guerra ígnea
871	Hacha aluvión
872	Cercenarrocas
873	Bastón de Jordan
875	Invocación de caballo marrón
876	Rodela de madera desgastada
878	Hilera del tamaño de un puño
880	Bastón de Horrores
884	Costilla de necrófago
885	Hacha de metal negro
886	Espada corta de metal negro
887	Kilo de carne
888	Guantes de batalla naga
889	Una carta polvorienta sin enviar
890	Bastón de corista retorcido
892	Guantes de lanzamiento gnoll
893	Colmillo de lobo temible
895	Calavera de huargen
896	Colmillo de huargen
897	Brazales de lobo demente
899	Colmillo de telaraña venenosa
901	Deptecated White Stallion Summoning (Mount)
910	Una carta sin entregar
911	Rama de árbol de maderaférrea
913	Espada de ogro enorme
914	Armadura de anillas de ogro grande
915	Pañuelo de seda rojo
916	Una página de diario rota
918	Talega de pellejo descarriado
920	Maza con pinchos maligna
921	Una página de diario borrada
922	Dalle dacio
923	Tizona
924	Gran maza
925	Mayal
926	Hacha de batalla
927	Hacha doble
928	Bastón largo
929	Poción de sanación
932	Alforjas de corcel vil
933	Mochila grande
934	Segadora de Stalvan
935	Espada corta de guardia nocturno
936	Maza de medianoche
937	Bastón negro del Bosque del Ocaso
938	Páginas de diario embarrado
939	Una página de un diario manchada de sangre
940	Togas de Perspicacia
942	Sortija helada
943	Bastón de celador
944	Bastón de mago elemental
945	Espada de las Sombras
948	Espada Naturaleza
954	Pergamino de fuerza
955	Pergamino de intelecto
957	Envío de William
961	Hierba de sanación
962	Pastel de tripa de cerdo
966	Escrito sobre Escudo contra Escarcha
967	Escrito sobre Resguardo contra la Escarcha
968	Escrito sobre Explosión de Fuego
973	Escrito sobre Bola de Fuego II
974	Escrito sobre Armadura de Escarcha II
975	Escrito sobre Cadenas de hielo
976	Escrito sobre Eliminar maldición
980	Escrito sobre Escudo contra Escarcha II
981	Collar de Bernice
983	Fajín de lino rojo
985	Escrito sobre Liberación de Khadgar
986	Escrito sobre Descarga de Escarcha II
989	Escrito sobre Nova de Escarcha
992	Escrito sobre Bola de Fuego III
994	Escrito sobre Armadura de hielo
997	Espada entorpecedora de Fuego
1002	Escrito sobre Invisibilidad inferior
1004	Escrito sobre Cadenas de hielo II
1006	Collera de latón
1008	Espada bien usada
1009	Martillo compacto
1010	Bastón corto nudoso
1011	Hacha afilada
1013	Remache de hierro
1015	Costillar de lobo magro
1017	Kebab de lobo sazonado
1019	Pañuelo de lino rojo
1029	Tablilla de Tótem serpiente
1030	Tablilla de voluntad férrea
1031	Tablilla de Explosión de arrabio
1032	Tablilla de Tótem agitador
1033	Tablilla de Veneno de anulación
1034	Tablilla de fuerza eterna
1035	Tablilla de Llamar a espíritu
1036	Tablilla de Enfermedad de anulación
1037	Tablilla de Descarga de relámpagos II
1038	Tablilla de Restauración II
1041	Cuerno del lobo negro
1048	Tablilla de Escudo de relámpagos II
1049	Tablilla de Purgar
1052	Tablilla de armadura de espíritu II
1053	Tablilla de Explosión de arrabio II
1057	Tablilla de Restauración III
1058	Tablilla de Descarga de relámpagos III
1061	Tablilla de Veneno de anulación II
1063	Tablilla de Enfermedad de anulación II
1072	Luna llena
1074	Punta de pata de araña dura
1075	Colgante Pielsombra
1076	Anillo de renegado Defias
1077	Anillo mágico Defias
1080	Carne de cóndor dura
1081	Carne de araña crujiente
1082	Estofado Crestagrana
1083	Glifo de Azora
1084	Códice de Renovar
1085	Códice de Visión mental
1086	Códice de Fuego interno
1087	Códice de Palabra de las Sombras: dolor
1088	Códice de Renovar II
1089	Códice de Enfermedad de anulación
1090	Códice de Resurrección
1091	Códice de Punición Sagrada II
1092	Códice de Curación inferior II
1093	Códice de Eliminar maldición
1095	Códice de Disipar magia
1096	Códice de Palabra de las Sombras: dolor II
1100	Códice de Punición Sagrada III
1101	Códice de Renovar V
1102	Códice de Curación inferior III
1105	Códice de Renovar VI
1108	Códice de Renovar III
1109	Códice de Dominación
1111	Códice de Dormir
1112	Códice de Palabra Sagrada: entereza II
1113	Pan mágico
1114	Pan de centeno mágico
1116	Anillo de plata pura
1119	Licor embotellado
1121	Patas de lince
1127	Carga cegadora
1129	Colmillo de necrófago
1130	Vial de veneno de araña
1131	Tótem de castigo
1132	Cuerno del lobo gris
1133	Cuerno del lobo invernal
1134	Cuerno del lobo grisáceo
1136	Tratado: Favor divino II
1138	Tratado: Favor divino
1139	Tratado: Limpieza
1141	Tratado: Luz Sagrada II
1144	Tratado: Escudo divino
1146	Tratado: Resurrección
1149	Tratado: Sello de poderío II
1150	Tratado: Purificar
1151	Tratado: Luz Sagrada III
1154	Cinturón de La Milicia Popular
1155	Vara del Insomne
1156	Anillo con una piedra magnífica
1158	Garrote de metal sólido
1159	Lanza larga de intendente de milicia
1161	Espada corta de milicia
1164	Escrito de Sam
1166	Rodela abollada
1167	Tarja pequeña
1168	Escudo Llamacráneos
1169	Escudo de cráneo negro
1171	Toga bien cosida
1172	Antorcha de Grisillo
1173	Botas deterioradas
1175	Un diente de oro
1176	Sales aromáticas
1177	Aceite de Olaf
1178	Cohete explosivo
1179	Leche fría como el hielo
1180	Pergamino de aguante
1181	Pergamino de espíritu
1182	Brazales de tachas de latón
1183	Guardamuñecas elásticos
1187	Collera con pinchos
1189	Anillo de sobrestante
1190	Capa de sobrestante
1191	Bolsa de canicas
1193	Rodela a rayas
1194	Espada bastarda
1195	Pala de minería de kóbold
1196	Tabar
1197	Maza gigante
1198	Mandoble
1199	Piedra de alma cargada
1200	Escudo de madera grande
1201	Escudo romboide mate
1202	Escudo de pared
1203	Égida de Ventormenta
1204	La torre verde
1205	Zumo de melón
1206	Ágata musgosa
1207	Murfestar
1208	Carta de amor de Maybell
1210	Gema de las Sombras
1211	Arnés de guerra gnoll
1212	Gapo gnoll
1213	Brazales afines a los gnoll
1214	Castigador gnoll
1215	Faja de sujeción
1216	Brazales escarchados
1217	Recompensa desconocida
1218	Garrote de guerra gnoll pesado
1219	Machete Crestagrana
1220	Hacha lupina
1221	Escama de vientre de cría
1222	Diente partido
1224	Grimorio Captar demonios
1228	Grimorio Hervor de sangre
1229	Grimorio Crear piedra de alma
1231	Grimorio Descarga de las Sombras II
1232	Grimorio Piel de demonio II
1238	Grimorio Miedo
1239	Grimorio de Succión de maná
1243	Grimorio Descarga de las Sombras III
1244	Grimorio Armadura demoníaca
1245	Grimorio Inmolar II
1246	Grimorio Aliento demoníaco
1250	Grimorio Detectar invisibilidad inferior
1251	Venda de lino
1252	Nota de la abuela Pedregosa
1254	Piedra de fuego inferior
1256	Hoja de alga de cristal
1257	Licor de invisibilidad
1259	JYoo test item
1260	Cabeza de Tharil'zun
1261	Orbe de medianoche
1262	Barril de cerveza Cebatruenos
1263	Rebanasesos
1264	Azotacabezas
1265	Puya de escorpión
1270	Capa tejida con cuidado
1273	Cota de malla de bosque
1274	Lúpulos
1275	Abrigo de anillas de diputado
1276	Rodela endurecida con fuego
1280	Caperuza invisible
1282	Almófar de metal brillante
1283	Nota de Verner
1284	Cajón de herraduras
1287	Colmillo de tarántula gigante
1288	Glándula de veneno grande
1292	Cuchilla de carnicero
1293	El estado de Villa del Lago
1294	La respuesta del General
1296	Maza Roca Negra
1297	Togas del taumaturgo umbrío
1299	Cinturón de la Espiral inferior
1300	Bastón de la Espiral inferior
1302	Guantes de cría negra
1303	Guantes de puente
1304	Guantes de jinete
1306	Guardamuñecas crin de lobo
1307	Planificación de recogida de oro
1309	Caja de herramientas de Olento
1310	Calzas de Smith
1314	Dedos de necrófago
1315	Lei de lirios
1317	Bastón de raíz endurecido
1318	Espetadora de la noche
1319	Anillo de voluntad férrea
1322	Aceite de hígado de pescado
1325	Ramo de narcisos
1326	Pezsol salteado
1327	Nota de Wiley
1328	Libro sobre Fuego Feérico
1332	Libro sobre Veneno de Cura
1334	Libro sobre Rejuvenecimiento II
1339	Libro sobre Raíces enredadoras
1341	Libro sobre Fuego lunar
1349	Cajón de Abercrombie
1351	Brazales de falanges
1352	Mortero de cráneo rajado
1353	Informe de Shaw
1355	Manteo de piel de ciervo
1356	Mención de honor: Bosque de Elwynn
1357	Mapa del tesoro del capitán Sander
1358	Una pista del tesoro de Sander
1359	Guantes con estampado de león
1360	Guantes de anillas de Ventormenta
1361	Otra pista del tesoro de Sander
1362	Pista final del tesoro de Sander
1364	Jubón de cuero harapiento
1366	Pantalones de cuero harapiento
1367	Botas de cuero harapiento
1368	Guantes de cuero harapiento
1369	Cinturón de cuero harapiento
1370	Brazales de cuero harapiento
1372	Capa harapienta
1374	Zapatos deshilachados
1376	Capa deshilachada
1377	Guantes deshilachados
1378	Pantalones deshilachados
1380	Toga deshilachada
1381	Un mensaje misterioso
1382	Maza de roca
1383	Tomahawk de piedra
1384	Hoja mate
1386	Hacha Cardoleño
1387	Diente de necrófago
1388	Bastón retorcido
1389	Marra de minería de kóbold
1391	Bastón místico Zarparrío
1394	Garrote de madera a la deriva
1395	Pantalones de aprendiz
1396	Pantalones de acólito
1399	Vela mágica
1400	Muestra Plumapresto
1401	Hoja de té verde
1402	Azufre
1404	Talismán de la marea
1405	Bastón de escupitajo
1406	Lanza taraceada con perlas
1407	Petición a los Páramos de Poniente de Solomon
1408	Respuesta a Solomon de Mantorrecio
1409	Petición a Villa Oscura de Solomon
1410	Respuesta de Cerranegro a Solomon
1411	Bastón seco
1412	Espada bastarda rudimentaria
1413	Espada débil
1414	Almádena rajada
1415	Marra de carpintero
1416	Hacha herrumbrada
1417	Hacha de batalla golpeada
1418	Cinturón de cuero desgastado
1419	Botas de cuero desgastadas
1420	Brazales de cuero desgastados
1421	Capa de pellejo desgastada
1422	Guantes de cuero desgastados
1423	Pantalones de cuero desgastados
1425	Jubón de cuero desgastado
1427	Zapatos de retales
1429	Capa de retales
1430	Guantes de retales
1431	Pantalones de retales
1433	Armadura de retales
1434	Palo de cera resplandeciente
1436	Calzones de frontera
1438	Escudo de guerrero
1440	Azotador de calavera gnoll
1443	Amuleto de Cainwyn enjoyado
1445	Espaldares Roca Negra
1446	Botas Roca Negra
1447	Anillo de salvadores
1448	Guanteletes Roca Negra
1449	Anillo de mediación menor
1450	Poción de fervor
1451	Botella zumo de zombi
1453	Peine espectral
1454	Hacha del Déspota
1455	Hacha de Campeón Roca Negra
1457	Maza Pielsombra
1458	Gran maza Pielsombra
1459	Arrancabelleras Pielsombra
1460	Espada de dos manos Pielsombra
1461	Hacha de batalla de destripador
1462	Anillo de las Sombras
1464	Garfa de águila ratonera
1465	Aterratigres
1467	Pez luna moteado
1468	Aleta de múrloc
1469	Cimitarra de sincronización
1470	Bolsa de piel de múrloc
1473	Bastón ribera
1475	Glándula de veneno pequeña
1476	Extremidad de araña partida
1477	Pergamino de agilidad II
1478	Pergamino de protección II
1479	Mitones de Salma
1480	Puño de La Milicia Popular
1481	Zarpadura
1482	Colmillo Oscuro
1483	Machacacaras
1484	Báculo de brujería
1485	Horquilla
1486	Chaqueta de corteza de árbol
1487	Pan integral de centeno mágico
1488	Armadura del Vengador
1489	Armadura de embozo luminiscente
1490	Dije guardián
1491	Anillo de Precisión
1493	Cimitarra de merodeador pesada
1495	Zapatos de percal
1497	Capa de percal
1498	Guantes de percal
1499	Pantalones de percal
1501	Guerrera de percal
1502	Cinturón de cuero combado
1503	Botas de cuero combadas
1504	Brazales de cuero combados
1505	Capa combada
1506	Guantes de cuero combados
1507	Pantalones de cuero combados
1509	Jubón de cuero combado
1510	Martillo pesado
1511	Espada de plebeyo
1512	Hacha de batalla rudimentaria
1513	Espada magna vieja
1514	Martillo de guerra herrumbrado
1515	Bastón de madera férrea
1516	Hachuela desgastada
1518	Peine de fantasma
1519	Oreja Sangrapellejo
1520	Sudor trol
1521	Hacha de serrería de ogro
1522	Lanza de rebanacabezas
1523	Garrote de piedra enorme
1524	Colmillo Machacacráneos
1528	Puñado de avena
1529	Jade
1532	Cabeza reducida
1534	Tratado: Luz Sagrada IV
1536	Tratado: Sello de cólera
1537	Faltriquera de la vieja Blanchy
1539	Bastón nudoso de ermitaño
1547	Escudo de la Fe
1554	Escrito sobre Descarga de Escarcha III
1557	Rodela de los mares
1559	Escrito sobre Misiles Arcanos II
1560	Sandalias de Branquiazul
1561	Toga de cosechador
1566	Filo de La Milicia Popular
1567	Escrito sobre Liberación de Khadgar II
1568	Escrito sobre elemental de Agua
1571	Escrito sobre Nova de Escarcha II
1574	Escrito sobre Resguardo contra el Fuego
1588	Tablilla de Explosión de arrabio III
1589	Tablilla de armadura de espíritu III
1591	Tablilla de Escudo de relámpagos III
1596	Hilo de cabello de fantasma
1597	Tablilla de Tormenta de relámpagos
1598	Flor podrida
1602	Hacha hoz
1603	Tablilla de Llamar a espíritu II
1604	Espada cromática
1607	Guardián de almas
1608	Maza Trituracráneos
1613	Bastón cazador de espíritus
1619	Tablilla de Tormenta de relámpagos II
1623	Faltriquera de piel de raptor
1624	Yelmo Machacacráneos
1625	Flamberge exquisita
1630	Electrolinterna rota
1637	Carta para Ello
1639	Hacha rictus
1640	Hacha de guerra monstruosa
1641	Códice de Palabra de las Sombras: dolor III
1645	Zumo de baya lunar
1648	Códice de Sanar IV
1651	Códice de Palabra Sagrada: escudo VI
1652	Caja de comida robusta
1656	Carta traducida
1657	Códice de Resurrección II
1658	Códice de Palabra de las Sombras: dolor IV
1659	Guantes de ingeniería
1664	Vara de fuerza de hechizo
1676	Códice de Dormir II
1677	Jubón de escamas de draco
1678	Chanclos de ogro negros
1679	Bate de korg
1680	Loncheacabezas
1681	Grimorio Entorpecer
1685	Bolsa de pellejo de trol
1686	Bigote de cerdas
1687	Garra retráctil
1688	Cola blanda larga
1696	Garfa de raptor curva
1697	Diente de raptor cortante
1701	Garra de basilisco curva
1702	Espina de basilisco intacta
1703	Columna de basilisco de cristal
1705	Piedra lunar inferior
1706	Fragmentos de hondoazur
1707	Brie de Ventormenta
1708	Néctar dulce
1710	Poción de sanación superior
1711	Pergamino de aguante II
1712	Pergamino de espíritu II
1713	Ankh de vida
1714	Collar de Calisea
1715	Armadura de brigandina pulida
1716	Toga del magi
1717	Guerrera de doble vínculo
1718	Pantalones de pellejo de basilisco
1720	Bastón Leñomaraña
1721	Martillo de guerra vikingo
1722	Almádena Piedra de espinas
1725	Morral grande
1726	Lanza de hueso con punta envenenada
1727	Espada de Descomposición
1728	Tizona llameante de Teebu
1729	Saco de armas de La Guardia Nocturna
1730	Cinturón de malla desgastado
1731	Botas de malla desgastadas
1732	Brazales de malla desgastados
1733	Capa desgastada
1734	Guantes de malla desgastados
1735	Pantalones de malla desgastados
1737	Jubón de malla desgastado
1738	Cinturón de malla con encaje
1739	Botas de malla con encaje
1740	Brazales de malla con encaje
1741	Capa con encaje
1742	Guantes de malla con encaje
1743	Pantalones de malla con encaje
1744	Hombreras de malla con encaje
1745	Jubón de malla con encaje
1746	Cinturón de eslabones
1747	Botas de eslabones
1748	Brazales de eslabones
1749	Capa de eslabones
1750	Guantes de eslabones
1751	Pantalones de eslabones
1752	Hombreras de eslabones
1753	Jubón de eslabones
1754	Cinturón de anillas reforzado
1755	Botas de anillas reforzadas
1756	Brazales de anillas reforzados
1757	Capa de anillas reforzada
1758	Guantes de anillas reforzados
1759	Pantalones de anillas reforzados
1760	Hombreras de anillas reforzadas
1761	Jubón de anillas reforzado
1764	Zapatos de retal
1766	Capa de retal
1767	Guantes de retal
1768	Pantalones de retal
1769	Hombreras de retal
1770	Jubón de retal
1772	Zapatos brocados
1774	Capa brocada
1775	Guantes brocados
1776	Pantalones brocados
1777	Hombreras brocadas
1778	Jubón brocado
1780	Sandalias a punto de cruz
1782	Capa a punto de cruz
1783	Guantes a punto de cruz
1784	Pantalones a punto de cruz
1785	Hombreras a punto de cruz
1786	Jubón a punto de cruz
1787	Cinturón de cuero con remiendos
1788	Botas de cuero con remiendos
1789	Brazales de cuero con remiendos
1790	Capa con remiendos
1791	Guantes de cuero con remiendos
1792	Pantalones de cuero con remiendos
1793	Hombreras de cuero con remiendos
1794	Chaleco de cuero con remiendos
1795	Cinturón de pellejo crudo
1796	Botas de pellejo crudo
1797	Brazales de pellejo crudo
1798	Capa de pellejo crudo
1799	Guantes de pellejo crudo
1800	Pantalones de pellejo crudo
1801	Hombreras de pellejo crudo
1802	Guerrera de pellejo crudo
1803	Cinturón de cuero fuerte
1804	Botas de cuero fuerte
1805	Brazales de cuero fuerte
1806	Capa dura
1807	Guantes de cuero fuerte
1808	Pantalones de cuero fuerte
1809	Hombreras de cuero fuerte
1810	Armadura de cuero fuerte
1811	Mandoble desafilado
1812	Hacha de batalla de mango corto
1813	Lanza larga astillada
1814	Marra maltrecha
1815	Maza ornamentada
1816	Hacha mal equilibrada
1817	Espada corta de serie
1818	Mandoble estándar
1819	Gubia
1820	Gran maza de madera
1821	Espada combada
1822	Cachava de cedro
1823	Cayada de cachiporrazo
1824	Hacha de guerra lustrosa
1825	Cachiporra grande
1826	Gran maza de roca
1827	Cuchilla de carne
1828	Hacha de guerra de piedra
1829	Alfanje corto
1830	Espada bastarda larga
1831	Bastón de guerra de roble
1832	Calzas de la suerte
1835	Cinturón de cuero sucio
1836	Brazales de cuero sucios
1839	Cinturón de cuero férreo
1840	Brazales de cuero férreo
1843	Cinturón de cuero curtido
1844	Brazales de cuero curtido
1845	Cinturón de malla de anillas
1846	Brazales de malla de anillas
1849	Cinturón de cuero curado
1850	Brazales de cuero curado
1851	Agua de limpieza
1852	Brazales de malla de escamas
1853	Cinturón de malla de escamas
1875	Distintivo de Cardortiga
1877	Libro sobre Rejuvenecimiento III
1882	Libro sobre Fuego lunar III
1886	Libro sobre Fuego lunar II
1893	Revancha de minero
1894	Tarjeta del Sindicato Minero
1913	Porra con tachuelas
1917	Daga enjoyada
1922	Suministros para Sven
1923	Cartera de embajador
1925	Estoque Defias
1926	Zapa pesada
1927	Cuchilla de Las Minas de la Muerte
1928	Bastón mágico Defias
1929	Calzas de seda
1930	Capa de albañil
1931	Garra de gnoll enorme
1933	Bastón de Creación
1934	Calzas de albañil
1935	Hoja de asesino
1936	Destornillador goblin
1937	Sierra zumbido
1938	Marra bloque
1939	Odre de ron dulce
1941	Tonel de Merlot
1942	Botella de licor
1943	Leotardos de malla goblin
1944	Guantes para trabajar el hierro
1945	Guantes para trabajar la madera
1946	Espejo de Mary
1951	Alfanje Aguasnegras
1955	Botas de anillas de Faucedraco
1956	Colgante Pielsombra descolorido
1958	Tibia petrificada
1959	Pico de hierro frío
1962	Colgante de Pielsombra resplandeciente
1965	Guantes de lobo blanco
1968	Monóculo de ogro
1970	Bálsamo restablecedor
1971	Escrituras de Cejade
1972	Escrituras de los Páramos de Poniente
1973	Orbe de engaño
1974	Brazales de punzada mental
1975	Espada magna vieja de Pysan
1976	Martillo de escoria
1977	Bolsa con 20 casillas
1978	Guantes de garra de lobo
1979	Muro de los muertos
1980	Sortija del submundo
1981	Chaleco de malla de hielo
1982	Hoja de la noche
1986	Sacatripas
1987	Olla de Krazek arreglada
1988	Guanteletes de brigadier
1990	Gran maza de grava
1991	Pala de energía goblin
1992	Fetiche Pantano fresco
1993	Anillo de mente de ogro
1994	Espetadora Garra de ébano
1996	Sortija vudú
1997	Toga sentida
1998	Bastón de mediación Sangrapellejo
2000	Archeus
2004	Diario de Grelin Barbablanca
2005	La primera leyenda trol
2006	La segunda leyenda trol
2007	La tercera leyenda trol
2008	La cuarta leyenda trol
2011	Sable retorcido
2013	Bastón de hueso de cripta
2014	Espada magna de metal negro
2015	Hacha de guerra de metal negro
2016	Armadura de anillas polvorientas
2017	Brazales de cuero resplandecientes
2018	Tizona esquelética
2020	Hoja colmillo hueco
2021	Escudo de caparazón verde
2024	Espadón
2025	Hacha barbada
2026	Martillo de roca
2027	Cimitarra
2028	Martillo
2029	Cuchilla
2030	Bastón nudoso
2032	Puños de galante
2033	Botas de embajador
2034	Togas de erudito
2035	Espada del Cielo nocturno
2036	Guantes de minería polvorientos
2037	Botas de tunelador
2039	Anillo de las llanuras
2040	Prospector trol
2041	Guerrera de los Páramos de Poniente
2042	Bastón de los Páramos de Poniente
2043	Anillo de espíritus melancólicos
2044	Hacha curva de espíritus melancólicos
2046	Kukri de Branquiazul
2047	Hacha de mano Yunquemar
2048	Martillo Yunquemar
2054	Hacha de mano trogg
2055	Martillo de madera pequeño
2056	El martillo de terciopelo
2057	Espada corta con agujeros Defias
2058	Gran maza de Kazon
2059	Capa de avizor
2064	Garrote trogg
2065	Hoja Comepiedras
2066	Hachuela calavera
2067	Bastón Bocado helado
2069	Jubón de pellejo de oso negro
2070	Queso azul de Darnassus
2072	Cetro de mago enano
2073	Hachuela enana
2074	Hoja corta sólida
2075	Maza de sacerdote
2077	Bastón de mago
2078	Espada corta septentrional
2079	Martillo de guerra de Sargento
2080	Hacha Natocolina
2082	Zurrón de Zumbang
2084	Espada bastarda de acero oscuro
2085	Trozo de carne
2087	Caparazón duro de reptador
2088	Extremidad de reptador largo
2089	Daga para tallar
2091	Polvo mágico
2092	Daga desgastada
2098	Escopeta de doble cañón
2099	Culebrina enana
2100	Bocarda calibrada milimétricamente
2101	Carcaj ligero
2102	Faltriquera de munición pequeña
2105	Camisa de matón
2108	Jubón de cuero Peloescarcha
2109	Jubón de anillas Peloescarcha
2110	Toga ligera de mago
2112	Chaleco de leñador
2113	Nota de Calor
2114	Toga nevada
2117	Zapatos de paño fino
2119	Guantes de paño fino
2120	Pantalones de paño fino
2121	Armadura de paño fino
2122	Cinturón de cuero rajado
2123	Botas de cuero rajado
2124	Brazales de cuero rajado
2125	Guantes de cuero rajado
2126	Pantalones de cuero rajado
2127	Jubón de cuero rajado
2128	Mandoble arañado
2129	Escudo redondo grande
2130	Garrote
2131	Espada corta
2132	Bastón corto
2133	Escudo pequeño
2134	Hacha de mano
2136	Agua purificada mágica
2137	Cuchillo para tallar
2138	Abrecartas afilado
2139	Puntilla
2140	Trinchante
2141	Jubón de cuero hervido
2142	Cinturón de cuero hervido
2143	Botas de cuero hervido
2144	Brazales de cuero hervido
2145	Guantes de cuero hervido
2146	Pantalones de cuero hervido
2148	Cinturón de escama pulida
2149	Botas de escama pulida
2150	Brazales de escama pulida
2151	Guantes de escama pulida
2152	Leotardos de escama pulida
2153	Jubón de escama pulida
2154	La historia de Morgan Ladimor
2156	Botas acolchadas
2158	Guantes acolchados
2159	Pantalones acolchados
2160	Armadura acolchada
2161	Libro sobre la granja de Sven
2162	Anillo de Sarah
2163	Hoja de las Sombras
2164	Destripador
2165	Manta de la vieja Blanchy
2166	Leotardos de supervisor
2167	Guantes de supervisor
2168	Botas de supervisor
2169	Hoja timbre
2172	Cinturón rústico
2173	Cinturón de cuero viejo
2175	Hacha de batalla Pielsombra
2186	Cinturón de modisto
2187	Un fajo de cartas
2188	Una carta para Grelin Barbablanca
2194	Martillo de diamante
2195	Cuchillo Yunquemar
2203	Trituradora de Garravil
2204	Ensartadora de Garravil
2205	Anochecedor
2207	Jambiya
2208	Puñal
2209	Kris
2210	Rodela maltrecha
2211	Escudo grande doblado
2212	Rodela rajada
2213	Escudo grande desgastado
2214	Rodela de madera
2215	Escudo de madera
2216	Rodela simple
2217	Escudo rectangular
2218	Daga de artesano
2219	Escudo redondo pequeño
2220	Caja escudo
2221	Tarja
2222	Escudo pavés
2223	La lista del coleccionista
2224	Daga de milicia
2225	Cuchillo de cocina afilado
2226	Bastón de ogro mago
2227	Hacha de guerra de ogro pesada
2230	Guantes de Mole
2231	Toga inferno
2232	Botas con runas oscuras
2233	Leotardos de tejedora de las Sombras
2234	Armadura de caminante nocturno
2235	Garra de Brack
2236	Colmillo Negro
2237	Pantalones con remiendos
2238	Pantalones de Urchin
2239	El anillo del coleccionista
2240	Manteo basto
2241	Manteo de forajido
2243	Mano de Edward el Extraño
2244	Hoja krol
2245	Yelmo de Narv
2246	Sello de mirmidón
2249	Rodela de milicia
2250	Pasteles de cangrejo oscuro
2251	Pata pegajosa de araña
2252	Suministros goblin variados
2254	Martillo de guerra de cristal de hielo
2256	Garrote esquelético
2257	Bastón Peloescarcha
2258	Espada corta Peloescarcha
2259	Garrote Peloescarcha
2260	Hacha de mano Peloescarcha
2262	Marca de Kern
2263	Fitohoja
2264	Manto de Ladrones
2265	Hacha Rompecantos
2266	Daga Rompecantos
2267	Maza Rompecantos
2268	Espada Rompecantos
2271	Bastón del vidente bendito
2273	Armadura de guerrilla
2274	Guantes de zapador
2276	Botas Caminalodo
2277	Leotardos de nigromante
2278	Cubrehombros de rastreador de bosque
2280	Cachava de Kam
2281	Hacha de sílex Rodentia
2282	Espada corta Rodentia
2283	Cinturón de paño de rata
2284	Capa de paño de rata
2287	Anca de carne
2288	Agua dulce mágica
2289	Pergamino de fuerza II
2290	Pergamino de intelecto II
2291	Kang el Decapitador
2292	Togas de necrología
2295	Colmillo de jabalí grande
2296	Morro de gran Dentosangre
2299	Hacha de guerra ardiente
2300	Jubón de cuero estampado
2302	Botas de cuero cosidas a mano
2303	Pantalones de cuero cosidos a mano
2304	Refuerzo para armadura ligero
2307	Botas de cuero refinado
2308	Capa de cuero refinado
2309	Botas de cuero estampado
2310	Capa de cuero estampado
2311	Chaleco de cuero blanco
2312	Guantes de cuero refinado
2313	Refuerzo para armadura medio
2314	Armadura de cuero fortalecido
2315	Botas de cuero oscuro
2316	Capa de cuero oscuro
2317	Guerrera de cuero oscuro
2318	Cuero ligero
2319	Cuero medio
2320	Hilo burdo
2321	Hilo refinado
2324	Lejía
2325	Tinte negro
2326	Brazales tejidos con hiedra
2327	Brazales de cuero robusto
2361	Martillo desgastado por la batalla
2362	Escudo de madera desgastado
2364	Jubón tejido
2366	Pantalones tejidos
2367	Botas tupidas
2369	Guantes tejidos
2370	Arnés de cuero maltrecho
2371	Cinturón de cuero maltrecho
2372	Pantalones de cuero maltrechos
2373	Botas de cuero maltrechas
2374	Brazales de cuero maltrechos
2375	Guantes de cuero maltrechos
2376	Escudo romboide desgastado
2377	Rodela redonda
2378	Dedo esquelético
2379	Jubón de anillas deslustradas
2380	Cinturón de anillas deslustradas
2381	Leotardos de anillas deslustradas
2382	El corazón del embalsamador
2383	Botas de anillas deslustradas
2384	Brazales de anillas deslustradas
2385	Guantes de anillas deslustradas
2386	Jubón de anillas oxidado
2387	Cinturón de anillas oxidado
2388	Leotardos de anillas oxidados
2389	Botas de anillas oxidadas
2390	Brazales de anillas oxidados
2391	Guantes de anillas oxidados
2392	Armadura de malla ligera
2393	Cinturón de malla ligera
2394	Leotardos de malla ligera
2395	Botas de malla ligera
2396	Brazales de malla ligera
2397	Guantes de malla ligera
2398	Armadura de anillas ligeras
2399	Cinturón de anillas ligeras
2400	Leotardos de anillas ligeras
2401	Botas de anillas ligeras
2402	Brazales de anillas ligeras
2403	Guantes de anillas ligeras
2406	Patrón: botas de cuero refinado
2407	Patrón: chaleco de cuero blanco
2408	Patrón: guantes de cuero refinado
2409	Patrón: guerrera de cuero oscuro
2410	Antorcha humeante
2411	Brida de semental negro
2413	Palomino
2414	Brida de pinto
2415	Semental blanco
2417	Jubón de anillas aumentado
2418	Leotardos de anillas aumentados
2419	Cinturón de anillas aumentado
2420	Botas de anillas aumentadas
2421	Brazales de anillas aumentadas
2422	Guantes de anillas aumentados
2423	Jubón brigandina
2424	Cinturón brigandina
2425	Leotardos brigandina
2426	Botas brigandina
2427	Brazales brigandina
2428	Guantes brigandina
2429	Jubón rojizo
2431	Pantalones rojizos
2432	Botas rojizas
2434	Guantes rojizos
2435	Armadura bordada
2437	Pantalones bordados
2438	Botas bordadas
2440	Guantes bordados
2441	Rodela ensortijada
2442	Tarja reforzada
2443	Rodela de metal
2444	Rodela ornamentada
2445	Escudo de metal grande
2446	Escudo oblongo
2447	Flor de paz
2448	Pavés pesado
2449	Raíz de tierra
2450	Brezospina
2451	Escudo romboide con emblema
2452	Cardopresto
2453	Hierba cardenal
2454	Elixir de fuerza de león
2455	Poción de maná menor
2456	Poción de Rejuvenecimiento menor
2457	Elixir de agilidad menor
2458	Elixir de entereza menor
2459	Poción de presteza
2460	Elixir of Tongues (NYI)
2463	Jubón con tachuelas
2464	Cinturón con tachuelas
2465	Pantalones con tachuelas
2466	Fetiche Machacacráneos
2467	Botas con tachuelas
2468	Brazales con tachuelas
2469	Guantes con tachuelas
2470	Jubón de cuero reforzado
2471	Cinturón de cuero reforzado
2472	Pantalones de cuero reforzado
2473	Botas de cuero reforzado
2474	Brazales de cuero reforzado
2475	Guantes de cuero reforzado
2476	Anca de basilisco fría
2477	Calavera de devastador
2479	Hacha ancha
2480	Garrote grande
2481	Espada de peón
2482	Tomahawk inferior
2483	Hacha ancha férrea
2484	Cuchillo pequeño
2485	Tablero astillado
2486	Maza de piedra grande
2487	Bastón de acólito
2488	Gladius
2489	Espada de dos manos
2490	Tomahawk
2491	Hacha grande
2492	Cayada
2493	Marra de madera
2494	Estilete
2495	Cachava
2496	Espada corta de asaltante
2497	Mandoble oxidado
2498	Tomahawk pequeño
2499	Hacha de doble filo
2500	Martillo ligero
2501	Martillo de guerra de madera
2502	Daga rayada
2503	Bastón corto de adepto
2504	Arco corto desgastado
2505	Arco corto pulido
2506	Arco corvo de madera de cuerno
2507	Arco corvo laminado
2508	Trabuco viejo
2509	Trabuco ornamentado
2510	Trabuco sólido
2511	Bocarda de cazador
2512	Flecha férrea
2514	Depricated Sharp Arrow
2515	Flecha afilada
2516	Perdigón ligero
2519	Perdigón pesado
2520	Espada ancha
2521	Flamberge
2522	Hacha curva
2523	Bullova
2524	Clava
2525	Martillo de guerra
2526	Daga de guardamano
2527	Bastón de batalla
2528	Bracamarte
2529	Montante
2530	Francisca
2531	Gran hacha
2532	Estrella de la mañana
2533	Gran maza de guerra
2534	Rondel
2535	Bastón de guerra
2536	Diente de trogg de piedra
2545	Leotardos de anillas maleables
2546	Faja Peloescarcha real
2547	Guantes de cuidador de jabalíes
2548	Barrica de brebaje de Cebadiz
2549	Bastón de la Sombra
2553	Receta: elixir de agilidad menor
2555	Receta: poción de presteza
2556	Receta: elixir de lenguas
2560	Diario completo de Alterio
2561	Cabeza de Chok'sul
2562	Ramo de begoñas escarlata
2563	Partículas con olor extraño
2564	Garras de espíritu élficas
2565	Vara de Fuego de arrabio
2566	Togas de sacrificio
2567	Hoja de evocador
2568	Jubón de lino marrón
2569	Botas de lino
2570	Capa de lino
2571	Envolturas de parra
2572	Toga de lino roja
2575	Camisa de lino roja
2576	Camisa de lino blanca
2577	Camisa de lino azul
2578	Jubón de lino barbárico
2579	Camisa de lino verde
2580	Manteo de lino reforzado
2581	Venda de lino gruesa
2582	Jubón de lana verde
2583	Botas de lana
2584	Manteo de lana
2585	Toga de lana gris
2586	Toga de maestro de juego
2587	Camisa de lana gris
2589	Paño de lino
2590	Telaraña de araña del bosque
2591	Paño trogg sucio
2592	Paño de lana
2593	Frasco de cerveza leonada de Ventormenta
2594	Cántaro de hidromiel enano
2595	Jarra de bourbon de las Tierras Inhóspitas
2596	Odre de cerveza enana
2598	Patrón: toga de lino rojo
2601	Patrón: toga de lana gris
2604	Tinte rojo
2605	Tinte verde
2606	Veneno de rondador
2607	Cristal Mo'grosh
2608	Ámbar gris de trillanodonte
2609	Coloide desactivador
2610	Mezcla neutralizadora
2611	Sílex rudimentario
2612	Toga lisa
2613	Togas con doble pespunte
2614	Toga de aprendizaje
2615	Toga cromática
2616	Togas de seda fulgurante
2617	Togas ardientes
2618	Togas vestidas de plata
2619	Informe de Grelin
2620	Embozo augural
2621	Capucha de Nigromancia
2622	Ornato tribal de Nimar
2623	Diadema Sagrada
2624	Almete de meditación
2625	Estatuilla de Menethil
2628	Informe de Senir
2629	Llave de caja fuerte de El Intrépido
2632	Daga curva
2633	Pócima de la selva
2634	Extracto de helecho venenoso
2635	Cinturón de anillas sueltas
2636	Ídolo de piedra grabado
2637	Informe del avance de Vetaferro
2639	Carta de Merrin
2640	Equipamiento de minero
2642	Botas de anillas sueltas
2643	Brazales de anillas sueltas
2644	Capa de anillas sueltas
2645	Guantes de anillas sueltas
2646	Pantalones de anillas sueltas
2648	Jubón de anillas sueltas
2649	Cinturón de anillas endeble
2650	Botas de anillas endebles
2651	Brazales de anillas endebles
2652	Capa de anillas endeble
2653	Guantes de anillas endebles
2654	Pantalones de anillas endebles
2656	Jubón de anillas endeble
2657	Bolsa de cuero rojo
2658	Trozo Ados
2659	Trozo Modr
2660	Trozo Golm
2661	Trozo Neru
2662	Carcaj de Ribbly
2663	Bandolera de Ribbly
2664	Colmillo de hilador
2665	Hierbas aromáticas de Ventormenta
2666	Barrica de cerveza del Trueno
2667	Carnes curadas de MacGrann
2668	Diente de trillanodonte
2669	Garra de trillanodonte
2671	Crin de Wendigo
2672	Carne de lobo fibrosa
2673	Carne de coyote
2674	Carne de reptador
2675	Garra de reptador
2676	Cardaluz
2677	Costillas de jabalí
2678	Especias suaves
2679	Carne de lobo carbonizada
2680	Carne de lobo especiada
2681	Carne de jabalí asada
2682	Pinza de cangrejo cocida
2683	Pastel de cangrejo
2684	Filete de coyote
2685	Costillas de cerdo suculentas
2686	Cerveza del Trueno
2687	Costillas de cerdo secas
2688	Nuez de ardilla
2690	Cinturón con pasador
2691	Botas de modisto
2692	Especias picantes
2694	Leotardos de colono
2696	Tonel de tajada
2697	Receta: pastel de hígado de Dentosangre
2698	Receta: pinza de cangrejo cocida
2699	Receta: estofado Crestagrana
2700	Receta: costillas de cerdo suculentas
2701	Receta: kebab de lobo sazonado
2702	Lingote Forjaluz
2712	Cajón de lingotes de Forjaluz
2713	Cabeza del viejo Tiznado
2719	Llave de latón pequeña
2720	Nota con barro
2721	Embozo Sagrado
2722	Cupón de vino
2723	Botella de Dalaran Noir
2724	Solicitud de paño
2725	Las verdes colinas de Tuercespina: Página 1
2728	Las verdes colinas de Tuercespina: Página 4
2730	Las verdes colinas de Tuercespina: Página 6
2732	Las verdes colinas de Tuercespina: Página 8
2734	Las verdes colinas de Tuercespina: Página 10
2735	Las verdes colinas de Tuercespina: Página 11
2738	Las verdes colinas de Tuercespina: Página 14
2740	Las verdes colinas de Tuercespina: Página 16
2742	Las verdes colinas de Tuercespina: Página 18
2744	Las verdes colinas de Tuercespina: Página 20
2745	Las verdes colinas de Tuercespina: Página 21
2748	Las verdes colinas de Tuercespina: Página 24
2749	Las verdes colinas de Tuercespina: Página 25
2750	Las verdes colinas de Tuercespina: Página 26
2751	Las verdes colinas de Tuercespina: Página 27
2754	Espada bastarda deslustrada
2755	Las verdes colinas de Tuercespina
2756	Las verdes colinas de Tuercespina: Capítulo I
2757	Las verdes colinas de Tuercespina: Capítulo II
2758	Las verdes colinas de Tuercespina: Capítulo III
2759	Las verdes colinas de Tuercespina: Capítulo IV
2760	Costurero de Thurman
2763	Cuchillo de pescador
2764	Daga pequeña
2765	Cuchillo de caza
2766	Estilete diestro
2770	Mena de cobre
2771	Mena de estaño
2772	Mena de hierro
2773	Arco corto rajado
2774	Trabuco cubierto de herrumbre
2775	Mena de plata
2776	Mena de oro
2777	Arco corto débil
2778	Trabuco barato
2779	Lágrima de Tilloa
2780	Arco de caza ligero
2781	Trabuco sucio
2782	Arco corvo maltratado
2783	Trabuco de pésima calidad
2784	Zibética
2785	Arco corvo tieso
2786	Trabuco engrasado
2787	Daga trogg
2788	Cerveza Zarpanegra
2794	Un viejo libro de Historia
2795	Libro: Tensiones del hierro
2797	Corazón de Mokk
2798	Mena de Rethban
2799	Colmillo de gorila
2800	Togas de terciopelo negro
2801	Hoja de Hanna
2802	Emblema llameante
2805	Capa de pelaje de yeti
2806	Paquete para Pico Tormenta
2807	Hacha guillotina
2808	Antorcha de Llama
2815	Destripadora con hojas curvas
2816	Cetro del portavoz de la muerte
2817	Guerrera de cuero suave
2818	Calzas de cuero elásticas
2819	Daga cruzada
2820	Cronómetro ingenioso
2821	Pasapurés Mo'grosh
2822	Mondadientes Mo'grosh
2823	Abrelatas Mo'grosh
2824	Huracán
2825	Arco para flechas abrasadoras
2828	Restos de Nissa
2829	Restos de Gregor
2830	Restos de Thurman
2831	Restos de Devlin
2832	Receta del estofado de los Páramos de Poniente de Verna
2833	El libro de hechizos del Exánime
2834	Icor embalsamante
2835	Piedra férrea
2836	Piedra burda
2837	Carta de Thurman
2838	Piedra pesada
2839	Una carta para Yvette
2840	Barra de cobre
2841	Barra de bronce
2842	Barra de plata
2843	Nudillos sucios
2844	Maza de cobre
2845	Hacha de cobre
2846	Calabaza de Tirisfal
2847	Espada corta de cobre
2848	Maza de bronce
2849	Hacha de bronce
2850	Espada corta de bronce
2851	Cinturón de anillas de cobre
2852	Pantalones de anillas de cobre
2853	Brazales de cobre
2854	Brazales rúnicos de cobre
2855	Garra podrida
2856	Pica de hierro
2857	Cinturón rúnico de cobre
2858	Sangre de can oscuro
2859	Escama Anca Vil
2862	Piedra de afilar férrea
2863	Piedra de afilar burda
2864	Coraza rúnica de cobre
2865	Leotardos de bronce férreos
2866	Loriga de bronce férrea
2867	Brazales de bronce férreos
2868	Brazales de bronce estampados
2869	Coraza de bronce bañada en plata
2870	Coraza de plata resplandeciente
2871	Piedra de afilar pesada
2872	Veneno de araña nocturácnida sañosa
2874	Una carta sin enviar
2875	Anillo con la insignia Escarlata
2876	Pelambre de Murciumbrío
2877	Mandoble de combatiente
2878	Hacha de hueso barbada
2879	Vara antípoda
2880	Flujo débil
2881	Diseño: coraza rúnica de cobre
2882	Diseño: sobrehombros de bronce bañados en plata
2883	Diseño: puñal de bronce mortal
2885	Documentos de la Cruzada Escarlata
2886	Costilla de jabalí del risco
2887	Pelambre de lobo estropeada
2888	Costillas de jabalí a la cerveza
2889	Receta: costillas de jabalí a la cerveza
2890	Pelambre de jabalí estropeada
2891	Carta para el arquitecto de la ciudad
2892	Veneno mortal
2893	Veneno mortal II
2894	Malta rapsódica
2895	Dolor espeluznante
2896	Angustia espeluznante
2898	Pechera de montaraz
2899	Collera Wendigo
2900	Rodela de piedra
2901	Pico de minero
2902	Capa de la Fe
2903	Arco de caza de Daryl
2904	Rifle de caza de Daryl
2905	Capa de pelaje de cabra
2906	Leotardos de malla Villa Oscura
2907	Corta árboles enana
2908	Espada espinada
2909	Pañuelo de lana roja
2910	Botas de milicia de oro
2911	Faja de Keller
2912	Garra del Sombramántico
2913	Manto de Gamn de seda
2915	Rompehielo Taran
2916	Escudo de león de oro
2917	Anillo tranquilo
2919	Reliquia de los Antiguos
2920	Reliquia sacra
2921	Reliquia bendita
2922	Reliquia de espíritu
2923	Reliquia de Rectitud
2924	Carne de crocolisco
2925	Piel de crocolisco
2926	Cabeza de Bazil Thredd
2927	Tormento espeluznante
2928	Polvo de Decadencia
2929	Podredumbre de tumba
2930	Esencia de dolor
2932	Viña tormenta
2933	Sello de Wrynn
2934	Restos de cuero estropeado
2939	Lágrima de crocolisco
2940	Pata de oso sangrienta
2941	Corvo de prisión
2942	Nudillos de hierro
2943	Ojo de Paleth
2944	Ojo maldito de Paleth
2946	Daga arrojadiza equilibrada
2947	Cuchillo arrojadizo pequeño
2949	Botas de marinero
2950	Vara carámbano
2951	Anillo de Truenedera
2953	Capa de maestro vigía
2954	Bombachos de guardia nocturno
2955	Sombrero de contramaestre
2956	Informe sobre la hermandad Defias
2957	Jubón de oficial
2958	Pantalones de oficial
2959	Botas de oficial
2960	Guantes de oficial
2961	Jubón de cuero quemado
2962	Calzones de cuero quemado
2963	Botas de cuero quemado
2964	Guantes de cuero quemado
2965	Guerrera de guerrero
2966	Pantalones de guerrero
2967	Botas de guerrero
2968	Guantes de guerrero
2969	Jubón Vinculahechizo
2970	Pantalones Vinculahechizo
2971	Botas Vinculahechizo
2972	Guantes Vinculahechizo
2973	Guerrera de caza
2974	Pantalones de caza
2975	Botas de caza
2976	Guantes de caza
2977	Armadura de veterano
2978	Leotardos de veterano
2979	Botas de veterano
2980	Guantes de veterano
2981	Toga de vidente
2982	Pantalones de vidente
2983	Botas de vidente
2984	Guantes de vidente
2985	Coraza de cuero grabado
2986	Pantalones de cuero grabado
2987	Botas de cuero grabado
2988	Guantes de cuero grabado
2989	Guerrera bruñida
2990	Leotardos bruñidos
2991	Botas bruñidas
2992	Guantes bruñidos
2996	Madeja de paño de lino
2997	Madeja de paño de lana
2998	Una sencilla brújula
2999	Herramientas de Brasacerada
3000	Caparazón de madre de linaje
3002	Cuerno de Justicia de reliquia
3003	Reliquia del Ojo
3004	Reliquia de los Muertos
3005	Reliquia de Verdad
3006	Fragmento de reliquia Sagrada
3008	Capa de pelaje Wendigo
3010	Arena fina
3011	Ornato de plumas
3012	Pergamino de agilidad
3013	Pergamino de protección
3014	Hacha desgastada por la batalla
3016	Libro de hechizos de Gunther
3017	Órdenes de Sevren
3018	Pellejo de Lupos
3019	Toga de noble
3020	Almete duradero
3021	Arco de forestal
3022	Calzones de Branquiazul
3023	Trabuco pesado grande
3024	BKP 2700 "Déspota"
3025	BKP 42 "Ultra"
3026	Arco reforzado
3027	Arco corvo pesado
3028	Arco largo
3029	Depricated Whipwood Arrow
3030	Flecha navaja
3031	Depricated Razor Arrow
3033	Perdigón sólido
3035	Calabaza envenenada
3036	Arco corto pesado
3037	Arco corvo ligero
3039	Arco de fresno corto
3040	Avancarga de cazador
3041	Trabuco "Ojo de mago"
3042	BKP "Gorrión" de bajo calibre
3045	Botas de escamas luminiscentes
3047	Guantes de escamas luminiscentes
3048	Musleras de escamas luminiscentes
3049	Coraza de escamas luminiscentes
3053	Pechera de Humbert
3055	Pechera de cuero de bosque
3056	Pantalones de cuero de bosque
3057	Botas de cuero de bosque
3058	Guantes de cuero de bosque
3065	Botas brillantes
3066	Guantes brillantes
3067	Pantalones brillantes
3069	Toga brillante
3070	Capa insignia
3071	Hachuela de artillero
3072	Toga humeante
3073	Pantalones humeantes
3074	Guantes humeantes
3075	Ojo de Llama
3076	Botas humeantes
3078	Troceacorazones naga
3079	Rifle de Skorn
3080	Vela de señalización
3081	Gema abisal
3082	Calavera de Dargol
3083	Piñón de estabilización
3084	Engranaje giromecánico
3085	Barrica de cerveza negra Brillante
3086	Tonel de cerveza negra Brillante
3087	Jarra de cerveza brillante
3088	Libro sobre Rejuvenecimiento IV
3089	Escrito sobre Fogonazo
3090	Escrito sobre Descarga de Escarcha
3091	Escrito sobre Intelecto Arcano II
3092	Escrito sobre Fogonazo III
3093	Escrito sobre Fogonazo II
3094	Escrito sobre Explosión de Fuego II
3095	Escrito sobre Explosión de Fuego III
3096	Escrito sobre Caída de pluma
3097	Escrito sobre Crear agua II
3098	Escrito sobre Lentitud
3099	Escrito sobre Armadura de hielo II
3100	Escrito sobre Ventisca II
3101	Escrito sobre Nova de Escarcha III
3102	Escrito sobre Intelecto Arcano III
3103	Martillo Crestanevada
3107	Cuchillo arrojadizo cortante
3108	Daga arrojadiza pesada
3110	Oreja de rata de túnel
3111	Hacha arrojadiza rudimentaria
3113	Códice de Palabra Sagrada: escudo
3114	Códice de Palabra de las Sombras: ofuscar
3115	Códice de Renovar IV
3116	Códice de Palabra Sagrada: escudo II
3117	Diario de Hildelve
3118	Códice de Sanación superior
3119	Códice de Palabra Sagrada: escudo V
3120	Códice de Punición Sagrada IV
3121	Códice de Levitar
3122	Códice de Palabra Sagrada: escudo III
3123	Códice de Palabra Sagrada: entereza III
3124	Códice de Fuego interno III
3125	Tablilla de Tótem serpiente II
3126	Tablilla de choque II
3127	Tablilla de choque III
3129	Tablilla de Descarga de relámpagos IV
3130	Tablilla de Restauración IV
3131	Hacha arrojadiza pesada
3132	Tablilla de Explosión de arrabio IV
3133	Tablilla de Tótem de maná
3134	Grimorio Maldición de Mannoroth
3135	Hacha arrojadiza afilada
3137	Hacha arrojadiza mortal
3138	Grimorio Descarga de las Sombras IV
3139	Grimorio Armadura demoníaca II
3140	Grimorio Hervor de sangre II
3141	Grimorio Drenaje de vida
3142	Grimorio Maldición de Sargeras
3143	Grimorio Espíritu ardiente
3144	Grimorio Espíritu ardiente II
3146	Grimorio Espíritu ardiente III
3151	Jubón de brigada de asedio
3152	Guantes de buceo
3153	Capa manchada de aceite
3154	Hacha de Thelsamar
3155	Remedio de Arugal
3156	Grillete de glotón
3157	Grillete de almanegra
3158	Brazales de pellejo quemados
3160	Rodela de placas de hierro
3161	Toga del Vigilante
3162	Costilla con cortes
3163	Calavera ennegrecida
3164	Corazón de huargo descolorido
3165	Poción de Quinn
3166	Cota de malla coracero
3167	Cerda de araña espesa
3168	Escama astillada
3169	Diente de oso astillado
3170	Diente de oso grande
3171	Colmillo de jabalí roto
3172	Intestinos de jabalí
3173	Carne de oso
3174	Icor de araña
3175	Pellejo de dragón estropeado
3176	Garra pequeña
3177	Colmillo diminuto
3179	Muda de piel de dragón rajada
3180	Escama de raptor con motas
3181	Carne parcialmente digerida
3182	Seda de araña
3183	Garra sarnosa
3184	Daga gancho
3185	Bastón acrobático
3186	Espada vikinga
3187	Kris de sacrificio
3188	Mandoble de coral
3189	Talador
3190	Palo para golpear
3191	Hacha de guerra arqueada
3192	Espada bastarda corta
3193	Marra de roble
3194	Malicia negra
3195	Hacha de batalla barbárica
3196	Espada bastarda afilada
3197	Mandoble Cortapiedras
3198	Martillo de paliza
3199	Destripador de batalla
3200	Brazales de cuero quemado
3201	Hacha de guerra bárbara
3202	Brazales de cuero de bosque
3203	Maza triangular densa
3204	Brazales Leñoprofundo
3205	Brazales de cuero grabado
3206	Montante de hidalgo
3207	Brazales de caza
3208	Martillo porrazo
3209	Espada de guerra antigua
3210	Hacha de guerra brutal
3211	Brazales bruñidos
3212	Brazales de escamas luminiscentes
3213	Brazales de veterano
3214	Brazales de guerrero
3216	Toga de invierno cálida
3217	Cinturón de supervisor
3218	Grillete de piroleña
3220	Morcilla
3222	Daga maligna
3223	Cetro Peloescarcha
3224	Brazales forrados con plata
3225	Cuchillo manchado de sangre
3227	Bastón de Nocturno
3228	Esposas forzadas
3229	Fajín de seda de tarántula
3230	Brazales de lobo negro
3231	Espaldares degollador
3233	Saco de pellejo gnoll
3234	Anillo de Deliah
3235	Anillo de Desdén
3236	Icor de Putrepellejo
3237	Muestra de icor
3238	Hallazgos de Johaan
3239	Contrapeso férreo
3240	Contrapeso burdo
3241	Contrapeso pesado
3248	Carta traducida de El Embalsamador
3249	Conjured test Item
3250	Pergamino de Bethor
3251	Poción de Bethor
3252	Informe de Mortacechador
3253	Corazón de oso grisáceo
3254	Sangre de celerácnida
3255	Diario de Berard
3256	Moho de vagador del Lago
3257	Moho de trepador del Lago
3258	Tumor endurecido
3259	Pellejo de murciélago estropeado
3260	Togas de iniciado Escarlata
3261	Capa palmeada
3262	Martillo de madera podrido
3263	Pantalones palmeados
3264	Ala de Murciumbrío
3265	Garra de carroñero
3266	Banda Escarlata
3267	Espada corta de los Renegados
3268	Daga de los Renegados
3269	Gran maza de los Renegados
3270	Jubón de lienzo
3272	Leotardos de piel de zombi
3273	Jubón de malla basta
3274	Botas de lienzo
3275	Guantes de lienzo
3276	Rodela de guardia de la Muerte
3277	Bastón de verdugo
3278	Espada de daño de proc aura
3279	Botas de anillas de batalla
3280	Brazales de anillas de batalla
3281	Guantes de anillas de batalla
3282	Pantalones de anillas de batalla
3283	Guerrera de anillas de batalla
3284	Botas tribales
3285	Brazales tribales
3286	Guantes tribales
3287	Pantalones tribales
3288	Jubón tribal
3289	Botas ancestrales
3290	Guantes ancestrales
3291	Prendas de lana ancestrales
3292	Guerrera ancestral
3293	Cuchilla de muerto
3294	Garrote de muerto
3295	Hoja de muerto
3296	Daga de muerto
3297	Musgovil
3299	Canino fracturado
3300	Pata de conejo
3301	Canino afilado
3302	Botas de agua estancada
3303	Brazales de agua estancada
3304	Guanteletes de agua estancada
3305	Leotardos de agua estancada
3306	Jubón de agua estancada
3307	Botas de paño barbárico
3308	Guantes de paño barbárico
3309	Taparrabos barbárico
3310	Jubón de paño barbárico
3311	Tobilleras de cuero ceremonial
3312	Brazales de cuero ceremonial
3313	Arnés de cuero ceremonial
3314	Guantes de cuero ceremonial
3315	Taparrabos de cuero ceremonial
3316	Cabeza de Alaric
3317	Una cabeza que habla
3318	Restos de Alaric
3319	Sable corto
3320	Fajín Tirahuesos
3321	Botitas de pelaje gris
3322	Capa menuda
3323	Brazales fantasmales
3324	Manto fantasmal
3325	Hacha de batalla Anca Vil
3327	Bastón de oráculo Anca Vil
3328	Toga de tela de araña
3329	Tabla de madera con pinchos
3330	Camisote de Dargol
3331	Manteo de Melrache
3332	Botas de Perrine
3334	Pala de granjero
3335	Escoba de granjero
3336	Taladro de carne
3337	Estandarte de guerra Faucedraco
3339	Yesca enana
3340	Mena de incendicita
3341	Guanteletes de fuerza de ogro
3342	Camisa del capitán Sander
3343	Bolsa de botín del capitán Sander
3344	Fajín del capitán Sander
3345	Sombrero de zahorí de seda
3347	Fardo de pieles de crocolisco
3348	Piel de crocolisco gigante
3349	Bolsa de Shida
3352	Bolsa cubierta de moco
3353	Colgante con runas grabadas
3354	Colgante de Dalaran
3355	Acérita salvaje
3356	Sangrerregia
3357	Vidarraíz
3358	Mostacho de Khadgar
3360	Fémur de Puntos
3363	Cinturón deshilachado
3365	Brazales deshilachados
3369	Musgo de tumba
3370	Cinturón de retales
3371	Vial vacío
3372	Vial emplomado
3373	Brazales de retales
3374	Cinturón de percal
3375	Brazales de percal
3376	Cinturón de retal
3377	Brazales de retal
3378	Cinturón brocado
3379	Brazales brocados
3380	Cinturón a punto de cruz
3381	Brazales a punto de cruz
3382	Poción de sangre de trol débil
3383	Elixir de sabiduría
3384	Poción de resistencia a la magia menor
3385	Poción de maná inferior
3386	Elixir de resistencia al veneno
3387	Poción de invulnerabilidad limitada
3388	Poción de sangre de trol fuerte
3389	Elixir de defensa
3390	Elixir de agilidad inferior
3391	Elixir de fuerza de ogro
3392	Yelmo ensortijado
3393	Receta: poción de resistencia a la magia menor
3394	Receta: Elixir de resistencia al veneno
3395	Receta: poción de invulnerabilidad limitada
3396	Receta: elixir de agilidad inferior
3397	Piel de crocolisco joven
3399	Garfa de buitre
3400	Tizona Lucine
3401	Escama de crocolisco férrea
3402	Parche de pelaje suave
3403	Cuerno de jabalí de marfil
3404	Ala de águila ratonera
3405	Dije de garra del Cuervo
3406	Cañón de pluma negra
3407	Zafiro de cielo
3408	Runa de nidal
3409	Colmillo de sable de la noche
3411	Pluma de lechuza estrígida
3412	Seda de araña Tejemadera
3413	Pico maldito
3414	Cetro con emblema
3415	Bastón del Fraile
3416	Cota de malla de mártir
3417	Mandoble de ónice
3418	Bellota vil
3419	Rosa roja
3420	Rosa negra
3421	Flores silvestres simples
3422	Flores silvestres preciosas
3423	Ramo de rosas blancas
3424	Ramo de rosas negras
3425	Varita tejida
3426	Camisa amarilla chillón
3427	Camisa negra con estilo
3428	Camisa gris común
3429	Cinturón de guardia
3430	Rifle de francotirador
3431	Cuero con huesos
3434	Arena de sueño
3435	Brazales de piel de zombi
3437	Cinturón con broche
3438	Ankh de Resurrección
3439	Botas de piel de zombi
3440	Partehuesos
3442	Fajín de aprendiz
3443	Tomahawk ceremonial
3444	Jubón de vástago
3445	Cuchillo ceremonial
3446	Bastón Leñoscuro
3447	Botas de caminacriptas
3448	Raíz de senggin
3449	Chal místico
3450	Escudo de Faerleia
3451	Brebaje Resplandor nocturno
3452	Vara ceranium
3453	Brazales guateados
3454	Botas de reconocimiento
3455	Espada corta de Mortacechador
3456	Silbato para perros
3457	Calzas estampadas
3458	Guantes de malla basta
3460	Bebida especial de Johaan
3461	Gran toga del Adjudicador
3462	Golpe de garfa
3463	Estrella de plata
3464	Flecha de plumas
3465	Proyectil explosivo
3466	Flujo concentrado
3467	Llave de hierro mate
3468	Descubrimiento de Renferrel
3469	Botas de anillas de cobre
3470	Piedra de pulir férrea
3471	Jubón de anillas de cobre
3472	Guanteletes rúnicos de cobre
3473	Pantalones rúnicos de cobre
3474	Guanteletes de cobre con gemas
3475	Capa de llamas
3476	Lengua de oso gris
3477	Icor de trepador
3478	Piedra de pulir burda
3480	Sobrehombros de bronce férreos
3481	Sobrehombros de bronce bañados en plata
3482	Botas de bronce bañadas en plata
3483	Guanteletes de bronce bañados en plata
3484	Botas de hierro verdes
3485	Guanteletes de hierro verdes
3486	Piedra de pulir pesada
3487	Espada ancha de cobre pesada
3488	Hacha de batalla de cobre
3489	Gran hacha de guerra
3490	Puñal de bronce mortal
3491	Maza de bronce pesada
3492	Martillo de hierro poderoso
3493	Fin de raptor
3495	Elixir de sufrimiento
3496	Sangre de león de montaña
3497	Elixir de dolor
3498	Collar de Taretha
3499	Llave de oro bruñida
3502	Flores Morrobarro
3505	Sello de Alterac
3506	Compuesto Morrobarro
3508	Mezcla Morrobarro
3509	Escama Espinadaga
3510	Ojo de aleta rasgado
3511	Capa de La Milicia Popular
3514	Calavera de Mor'Ladim
3515	Bastón de Ataeric
3516	Cabeza de Lescovar
3517	Barril de cerveza Machacacanillas
3518	Carta descifrada
3520	Barril contaminado
3521	Carta cifrada con ingenio
3522	Coraza negro de elfo de la noche
3523	Pantalones de elfo de la noche sin usar
3524	Botas de elfo de la noche sin usar
3525	Brazales de elfo de la noche sin usar
3526	Guantes negros de elfo de la noche
3527	Coraza de elfo de la noche blanca
3528	Coraza de cuero rojo C03
3529	Yelmo negro de elfos de la noche
3530	Venda de lana
3531	Venda de lana gruesa
3532	Unused Red Leather C03 Pants
3533	Botas de cuero rojo C03
3534	Unused Red Leather C03 Gloves
3535	Brazales de cuero rojo C03
3536	Venda de cazademonios
3537	D02 Coraza de cuero negro
3538	Coraza de cuero gris D02
3539	Unused Black Leather D02 Pants
3540	Unused Gray Leather D02 Pants
3541	D02 Botas de cuero negras
3542	Botas de cuero gris D02
3543	Unused Black Leather D02 Gloves
3544	Unused Gray Leather D02 Gloves
3545	D02 Brazales de cuero negros
3546	Brazales de cuero gris D02
3547	Coraza de cuero blanco D03
3548	Unused White Leather D03 Pants
3549	Unused White Leather D03 Gloves
3550	Cabeza de Targ
3551	Cabeza de Rastrazo
3552	Cabeza de Glommus
3553	Cabeza de Jarra'thol
3554	Corona de Voluntad
3555	Toga de Solomon
3556	Sombrero de mago aterrador
3557	Tabardo de tripas sin usar
3558	Toga de guardia de pantano
3559	Guanteletes de guardia nocturno
3560	Manto de Honor
3561	Poncho resistente
3562	Cinturón de Vindicación
3563	Bombachos de navegante
3564	Envío de hierro
3565	Guantes manchados de cerveza
3566	Armadura Aterraptor
3567	Caña de pescar enana
3569	Toga de vicario
3570	Mano de mortero de huesos
3571	Golpeador trogg
3572	Espada corta de Daryl
3573	Carcaj de caza
3574	Saco de munición de caza
3575	Barra de hierro
3576	Barra de estaño
3577	Barra de oro
3578	Pantalones de cosechador
3581	Cuchillo dentado
3582	Capa antiácido
3583	Cinturón deteriorado
3585	Guerrera de camuflaje
3586	Partetroncos
3587	Cinturón bordado
3588	Brazales bordados
3589	Cinturón de tejido pesado
3590	Brazales de tejido pesado
3591	Cinturón acolchado
3592	Brazales acolchados
3593	Cinturón rojizo
3594	Brazales rojizos
3595	Cinturón de paño andrajoso
3596	Brazales de paño andrajoso
3597	Cinturón de paño grueso
3598	Brazales de paño grueso
3599	Cinturón de paño fino
3600	Brazales de paño fino
3601	Misiva de la Hermandad
3602	Cinturón tricotado
3603	Brazales tricotados
3604	Bandolera de La Guardia Nocturna
3605	Carcaj de La Guardia Nocturna
3606	Cinturón tejido
3607	Brazales tejidos
3608	Diseño: martillo de hierro poderoso
3609	Diseño: jubón de anillas de cobre
3610	Diseño: guanteletes de cobre con gemas
3611	Diseño: botas de hierro verdes
3612	Diseño: guanteletes de hierro verdes
3613	Manos de Valdred
3614	Zarpa de Ululante
3615	Cabeza de Kurzen
3616	Ojo de la mente
3617	Colgante de las Sombras
3618	Cabeza de Engullidor
3619	Tabaquera de Snellig
3620	Restos de Lillith
3621	Cabeza de Ivar
3622	Esencia de Latipesadilla
3623	Cabeza de Thule
3625	Cabeza de Nek'rosh
3626	Cabeza del Barón Vardus
3627	Colmillo de Vagash
3628	Mano de Dextren Ward
3629	Anillo de la familia Mantoniebla
3630	Cabeza de Targorr
3631	Colmillo de Panzallena
3632	Pata de Fangore
3633	Cabeza de Gath'Ilzogg
3634	Cabeza de Grimson
3635	Garra de ojo de cresa
3636	Escama de Viejo Ojosombrío
3637	Cabeza de VanCleef
3638	Garfa de Sarldente
3639	Oreja de Balgaras
3640	Cabeza de Furiahonda
3641	Brazales de oficial
3642	Brazales ancestrales
3643	Brazales Vinculahechizo
3644	Brazales de paño barbárico
3645	Puños de vidente
3647	Brazales brillantes
3648	Rodela de guerrero
3649	Rodela tribal
3650	Escudo de batalla
3651	Escudo de veterano
3652	Rodela de caza
3653	Rodela ceremonial
3654	Escudo de agua estancada
3655	Escudo bruñido
3656	Escudo de escamas luminiscentes
3657	Registro de Trabalomas
3658	Escrito recuperado
3659	Libro de cuero desgastado
3660	Escritos sobre Alterac
3661	Bastón artesanal
3662	Filete de crocolisco
3663	Sopa de aleta de múrloc
3664	Potaje de crocolisco
3665	Tortilla con un sabor curioso
3666	Pastel de araña pegajosa
3667	Carne de crocolisco tierna
3668	Contrato de asesino
3669	Baba gelatinosa
3670	Hueso viscoso grande
3671	Calavera inerte
3672	Cabeza de Nagaz
3673	Flecha partida
3674	Bota descompuesta
3675	Antorcha totalmente quemada
3676	Icor baboso
3678	Receta: filete de crocolisco
3679	Receta: morcilla
3680	Receta: sopa de aleta de múrloc
3681	Receta: potaje de crocolisco
3682	Receta: tortilla con un sabor curioso
3683	Receta: pastel de araña pegajosa
3684	Tiara Perenolde
3685	Huevo de raptor
3688	Óvalo de sangrita
3689	Canica de sangrita
3690	Fragmento de sangrita
3691	Cuña de sangrita
3692	Cráneo humano de Trabalomas
3693	Espada de Humbert
3701	Mención de honor lacrada de Darthalia
3702	Vejiga de bilis de oso
3703	Cerveza de Costasur
3704	Llave de hierro oxidada
3706	Papiro hechizado
3707	Papiro de Nagaz
3708	Vara de Helcular
3710	Vara de Helcular
3711	Cuaderno de investigación de Belamoore
3712	Carne de tortuga
3713	Especias calmantes
3714	Muestra de piedra desgastada
3715	Brazales de vínculo de tierra
3716	Cabeza de múrloc
3717	Saco de cabezas de múrloc
3718	Documentos de planificación
3719	Capa de montañero
3720	Piel de yeti
3721	Informe de Farren
3722	Pellejo conocido
3723	Colmillo conocido
3724	Garra conocida
3725	Cuerno conocido
3726	Chuleta de oso grande
3727	Chuletillas de león picantes
3728	Filete de león sabroso
3729	Sopa de tortuga reconfortante
3730	Carne de oso grande
3731	Carne de león
3732	Cogulla
3733	Cota de malla de guerra orca
3734	Receta: chuleta de oso grande
3735	Receta: chuletillas de león picantes
3736	Receta: filete de león sabroso
3737	Receta: sopa de tortuga reconfortante
3738	Vara de cervecero
3739	Anillo calavera
3740	Espada decapitadora
3741	Botas de pisotón
3742	Arco de saqueo
3743	Rodela de avizor
3744	Colgante de sangrita
3745	Runa de apertura
3747	Fajín de meditación
3748	Manto felino
3749	Capa de gran boticario
3750	Coraza de canalé
3751	Leotardos de mercenario
3752	Jubón de bruto
3753	Faja de pastor
3754	Guantes de pastor
3755	Destripapeces
3758	Cinturón cruzado
3759	Guantes aislantes de sabio
3760	Sortija de Entrañas
3761	Escudo calavera
3762	Cartera de bibliotecario
3763	Rodela lunar
3764	Botas de mantis
3765	Espaldares de salteador
3766	Pluma de grifo
3767	Papiro refinado
3769	Varita rota
3770	Pata de cordero
3771	Pata de marrano salvaje
3772	Agua de manantial mágica
3775	Veneno entorpecedor
3776	Veneno entorpecedor II
3777	Raíz de letargo
3778	Arco compuesto tenso
3779	Hacha de guerra pesada
3780	Mosquete de cañón largo
3781	Mandoble ancho
3782	Garrote de guerra grande
3783	Cimitarra ligera
3784	Báculo de metal
3785	Hacha cortante
3786	Puntilla lustrosa
3787	Garrote de piedra
3788	Reliquia de cristal de alma
3789	Piedra reliquia de Piedad
3790	Papiro de reliquia consagrada
3791	Reliquia de la Luz
3792	Cinturón entrelazado
3793	Botas entrelazadas
3794	Brazales entrelazados
3795	Capa entrelazada
3796	Guantes entrelazados
3797	Pantalones entrelazados
3798	Hombreras entrelazadas
3799	Jubón entrelazado
3800	Cinturón de cuero endurecido
3801	Botas de cuero endurecido
3802	Brazales de cuero endurecido
3803	Capa endurecida
3804	Guantes de cuero endurecido
3805	Pantalones de cuero endurecido
3806	Hombreras de cuero endurecido
3807	Guerrera de cuero endurecido
3808	Cinturón de malla doble
3809	Botas de malla doble
3810	Brazales de malla doble
3811	Capa con doble pespunte
3812	Guantes de malla doble
3813	Pantalones de malla doble
3814	Hombreras de malla doble
3815	Jubón de malla doble
3816	Calentador reflectante
3817	Rodela reforzada
3818	Pálida
3819	Invernalia
3820	Alga estranguladora
3821	Espina de oro
3822	Hoja oscura rúnica
3823	Poción de invisibilidad inferior
3824	Aceite de las Sombras
3825	Elixir de entereza
3826	Poción de sangre de trol poderosa
3827	Poción de maná
3828	Elixir de detección de invisibilidad inferior
3829	Aceite de Escarcha
3830	Receta: elixir de entereza
3831	Receta: Poción de sangre de trol poderosa
3832	Receta: elixir de detección de invisibilidad inferior
3833	Capa de adepto
3834	Calzas de paño robusto
3835	Brazales de hierro verdes
3836	Yelmo de hierro verde
3837	Almófar de escamas doradas
3838	Garra Faucesombría
3839	Colmillo de tigresa prístino
3840	Sobrehombros de hierro verdes
3841	Sobrehombros de escamas doradas
3842	Leotardos de hierro verdes
3843	Leotardos de escamas doradas
3844	Camisote de hierro verde
3845	Loriga de escamas doradas
3846	Botas de acero pulido
3847	Botas de escamas doradas
3848	Cuchillo de bronce grande
3849	Espada corta de hierro endurecido
3850	Hoja serpentina de jade
3851	Gran maza de hierro sólido
3852	Destructora de hierro dorado
3853	Espada ancha de acero lunar
3854	Hoja tigre de Escarcha
3855	Hacha de hierro macizo
3856	Hacha curva de las Sombras
3857	Carbón
3858	Mena de mitril
3859	Barra de acero
3860	Barra de mitril
3861	Barra de acero negro
3862	Tendón de gorila mayor
3863	Pluma de acechador de la selva
3864	Citrino
3866	Diseño: hoja serpentina de jade
3867	Diseño: Destructora de hierro dorado
3868	Diseño: hoja tigre de Escarcha
3869	Diseño: hacha curva de las Sombras
3870	Diseño: sobrehombros de hierro verdes
3871	Diseño: sobrehombros de escamas doradas
3872	Diseño: leotardos de escamas doradas
3873	Diseño: loriga de escamas doradas
3874	Diseño: botas de acero pulido
3875	Diseño: botas de escamas doradas
3876	Colmillo de Bhag'thera
3877	Garfa de Tethis
3879	Garra de Sin'Dall
3880	Cabeza de Bangalash
3882	Pluma de águila ratonera
3889	Sombrero rojizo
3890	Sombrero con tachuelas
3891	Yelmo de anillas aumentado
3892	Sombrero bordado
3893	Gorro de cuero reforzado
3894	Yelmo brigandina
3897	Ojo de Dizzy
3898	Caligrafía de biblioteca
3899	Leyendas de los Gurubashi, Volumen 3
3900	Oporto Pupellyverbos
3901	Colmillo Sangrapellejo
3902	Bastón de Nobles
3904	Cabeza de Gan'zulah
3905	Cabeza de Nezzliok
3906	Trofeo de Balia'mah
3907	Trofeo de Ziata'jai
3908	Trofeo de Zul'Mamwe
3909	Armadura de Ana'thek rota
3910	Pizca de tabaco
3911	Fragmento azul pulsante
3912	Gema de alma
3913	Gema de alma llena
3914	Mochila de oficial
3915	Collar de huesos sangrientos
3916	Collar de hueso partido
3917	Cristal canto azul
3918	Fragmento de cristal canto
3919	Menudillos de Velo de Bruma
3920	Cartas de navegación de los Velasangre
3921	Órdenes de los Velasangre
3922	Pago del Trémulo
3923	Brazales de elemental de Agua
3924	Pata de palo de Maury
3925	Catalejo dorado de Jon-Jon
3926	Anillo enorme de Chucky
3927	Queso cheddar curado bueno
3928	Poción de sanación excelente
3929	Botín de Maury
3930	Llave de Maury
3931	Colmillo de araña envenenado
3932	Cofre de Smotts
3935	Alfanje de Smotts
3936	Cinturón de ganchillo
3937	Botas de ganchillo
3938	Brazales de ganchillo
3939	Capa de ganchillo
3940	Guantes de ganchillo
3941	Pantalones de ganchillo
3942	Hombreras de ganchillo
3943	Jubón de ganchillo
3944	Cinturón de sarga
3945	Botas de sarga
3946	Brazales de sarga
3947	Capa de sarga
3948	Guantes de sarga
3949	Pantalones de sarga
3950	Hombreras de sarga
3951	Jubón de sarga
3952	Cinturón de malla
3953	Botas de malla
3954	Brazales de malla
3955	Capa de malla
3956	Guantes de malla
3957	Pantalones de malla
3958	Manto de malla
3959	Armadura de malla
3960	Bolsa de brazales de elementales de agua
3961	Cinturón de cuero grueso
3962	Botas de cuero grueso
3963	Brazales de cuero grueso
3964	Capa gruesa
3965	Guantes de cuero grueso
3966	Pantalones de cuero grueso
3967	Hombreras de cuero grueso
3968	Guerrera de cuero grueso
3969	Cinturón de cuero liso
3970	Botas de cuero liso
3971	Brazales de cuero liso
3972	Capa lisa
3973	Guantes de cuero liso
3974	Pantalones de cuero liso
3975	Hombreras de cuero liso
3976	Armadura de cuero liso
3977	Cinturón con correas
3978	Botas con correas
3979	Brazales con correas
3980	Capa con correas
3981	Guantes con correas
3982	Pantalones con correas
3983	Hombreras con correas
3984	Armadura con correas
3985	Fajín con monogramas
3986	Pavés protector
3987	Torre deflectora
3988	Escudo de pared de placa
3989	Tarja de bloqueo
3990	Rodela con emblema
3991	Rodela de placas
3992	Cinturón de escamas laminadas
3993	Botas de escamas laminadas
3994	Brazales de escamas laminadas
3995	Capa de escamas laminadas
3996	Guantes de escamas laminadas
3997	Pantalones de escamas laminadas
3998	Hombreras de escamas laminadas
3999	Armadura de escamas laminadas
4000	Cinturón de anillas superpuestas
4001	Botas de anillas superpuestas
4002	Brazales de anillas superpuestas
4003	Capa de anillas superpuestas
4004	Guantes de anillas superpuestas
4005	Pantalones de anillas superpuestas
4006	Hombreras de anillas superpuestas
4007	Armadura de anillas superpuestas
4008	Cinturón de anillas extraordinarias
4009	Botas de anillas extraordinarias
4010	Brazales de anillas extraordinarias
4011	Capa de anillas extraordinarias
4012	Guantes de anillas extraordinarias
4013	Pantalones de anillas extraordinarias
4014	Hombreras de anillas extraordinarias
4015	Armadura de anillas extraordinarias
4016	Mezcla de Zanzil
4017	Espada corta afilada
4018	Mandoble afilado
4019	Hacha de sílex pesada
4020	Hacha de batalla seccionadora
4021	Maza contundente
4022	Gran maza aplastante
4023	Daga puntiaguda refinada
4024	Bastón de guerra pesado
4025	Arco largo equilibrado
4026	Mosquete de centinela
4027	Hoja de Catelyn
4028	Fardo de cañas akiris
4029	Junco akiris
4030	Agua de reliquia Sagrada
4031	Talismán de reliquia sacralizado
4032	Martillo de reliquia radiante
4033	Resplandor del Alba
4034	Piedra de las Mareas
4035	Toga de hilo de plata
4036	Puños de hilo de plata
4037	Pantalones de hilo de plata
4038	Toga Cielo Nocturno
4039	Capucha cielo nocturno
4040	Guantes Cielo Nocturno
4041	Capucha aurora
4042	Guantes aurora
4043	Brazales aurora
4044	Pantalones aurora
4045	Brazales Escapabruma
4046	Pantalones Escapabruma
4047	Botas Escapabruma
4048	Sombrero blasonado
4049	Brazales blasonados
4050	Leotardos blasonados
4051	Botas blasonadas
4052	Gorro de insignia
4053	Piel de crocolisco fluvial
4054	Leotardos de insignia
4055	Botas de insignia
4056	El enigma de Cortello
4057	Coselete de insignia
4058	Coraza con inscripciones
4059	Brazales con inscripciones
4060	Leotardos con inscripciones
4061	Brazales de cuero imperiales
4062	Pantalones de cuero imperiales
4063	Guantes de cuero imperiales
4064	Rodela blasonada
4065	Escudo de combate
4066	Rodela de insignia
4067	Rodela con inscripciones
4068	Escudo de brigadier
4069	Rodela Forjanegra
4070	Blasón de ajustador
4071	Coraza de malla de luz trémula
4072	Guanteletes de malla de luz trémula
4073	Grebas de malla de luz trémula
4074	Armadura de combate de malla
4075	Guanteletes de combate de malla
4076	Botas de combate de malla
4077	Protegecabezas de combate de malla
4078	Almófar de brigadier
4079	Leotardos de brigadier
4080	Capucha Forjanegra
4082	Coraza Forjanegra
4083	Guanteletes Forjanegra
4084	Leotardos Forjanegra
4085	Olla mecánica de Krazek
4086	Rifle cegador
4087	Arco de tiro real
4088	Hoja terrorífica
4089	Trabuco rompebloques
4090	Jarra O' Daño
4091	Creaviudas
4092	Escama de basilisco centelleante
4093	Cola de basilisco grande
4094	Fragmento de tablilla
4095	Deprecate Snare Kit
4096	Pelo de gorila burdo
4097	Diente de gorila astillado
4098	Nota doblada con cuidado
4099	Mechón de pelo de gorila
4100	Nota arrugada
4101	Nota rasgada
4102	Nota rota
4103	Llave de grillete
4104	Piel de crocolisco Quijaforte
4105	Piel de crocolisco mayor
4106	Cristal caído
4107	Guantes de cazador de tigres
4108	Leotardos de cazador de panteras
4109	Botas excelsior
4110	Arco de maestro cazador
4111	Rifle de maestro cazador
4112	Gargantilla del Alto chamán
4113	Manto medicinal
4114	Manteo marea oscura
4115	Rodela Grom'gol
4116	Olmann Sewar
4117	Fajín agostador
4118	Pendiente para la nariz de Poobah
4119	Guerrera de cazador de raptores
4120	Toga de aguas cristalinas
4121	Guantes con gemas
4122	Cetro de corredor de apuestas
4123	Espaldares de metal escarchados
4124	Almete de Armonía
4125	Orbe tranquilo
4126	Cuchilla de guerrilla
4127	Lanzatralla
4128	Pala de plata
4129	Placa de colección
4130	Brújula de Smotts
4131	Cinturón de Corrupción
4132	Braquiales Lanza Negra
4133	Puños Lanza Negra
4134	Bastón místico de Nimboya
4135	Sortija de hueso de sangre
4136	Botas Lanza Negra
4137	Zapatos Lanza Negra
4138	Guerrera Aguasnegras
4139	Sandalias para la selva
4140	Manto de fronda de palmera
4141	Escrito sobre Crear comida
4142	Escrito sobre Polimorfismo: cerdo
4143	Escrito sobre Crear comida II
4144	Escrito sobre Polimorfismo: vaca
4145	Escrito sobre Crear gema de maná
4146	Escrito sobre Polimorfia: oveja
4147	Escrito sobre Crear comida III
4148	Escrito sobre Contrahechizo
4149	Escrito sobre Escudo contra Escarcha III
4150	Escrito sobre Crear agua IV
4151	Escrito sobre Descarga de Escarcha IV
4152	Escrito sobre Crear comida IV
4153	Escrito sobre Misiles Arcanos III
4154	Escrito sobre Lentitud II
4155	Escrito sobre elemental de Agua II
4157	Escrito sobre Atenuar magia
4158	Escrito sobre Liberación de Khadgar III
4159	Escrito sobre Misiles Arcanos
4160	Escrito sobre Invisibilidad
4161	Escrito sobre Bola de Fuego IV
4162	Escrito sobre Traslación II
4164	Tratado: Luz Sagrada V
4165	Tratado: Luz Sagrada VI
4166	Tratado: Sello de protección
4167	Tratado: Sentencia
4168	Tablilla de Tótem enredador
4169	Tablilla de voluntad férrea II
4170	Tablilla de Regreso astral
4171	Tablilla de Tótem agitador III
4172	Tablilla de Atronar II
4173	Tablilla de choque IV
4174	Tablilla de choque V
4175	Tablilla de Escudo de relámpagos IV
4176	Tablilla de fuerza eterna II
4177	Tablilla de resistencia a la Naturaleza
4178	Tablilla de Descarga de relámpagos V
4179	Tablilla de Restauración V
4180	Tablilla de forma etérea II
4181	Tablilla de Tótem agitador IV
4182	Tablilla de voluntad férrea III
4183	Tablilla de Tótem sanador V
4184	Tablilla de Explosión de arrabio V
4185	Tablilla de Regreso astral en grupo
4186	Tablilla de Resistencia al Fuego
4187	Tablilla de Tótem serpiente V
4188	Tablilla de Tótem de Invisibilidad
4189	Tablilla de Cadena de relámpagos
4190	Armadura de plumas
4191	Leotardos con plumas sin usar
4192	Guanteletes con plumas sin usar
4194	Brazales de plumas
4195	Botas de plumas
4196	Manto de plumas
4197	Protectores de Berilo
4198	Grimorio Cauce de almas
4199	Grimorio Cauce de almas II
4200	Grimorio Inmolar III
4201	Grimorio Ojo de Kilrogg
4202	Grimorio Miedo II
4203	Grimorio Pestilencia II
4204	Grimorio Cauce de almas III
4205	Grimorio Inmolar IV
4206	Grimorio Maldición de Sargeras II
4207	Grimorio Maldición de Archimonde
4208	Grimorio Bomba mental
4209	Grimorio Resguardo contra las Sombras
4210	Grimorio Crear sangrita inferior
4211	Grimorio Pestilencia
4212	Grimorio Maldición de Mannoroth III
4213	Grimorio Fatalidad
4214	Grimorio Drenaje de vida III
4215	Grimorio Lluvia de Fuego
4216	Grimorio Resguardo contra lo Sagrado
4217	Grimorio Cauce de almas IV
4218	Grimorio Crear sangrita
4219	Grimorio Espíritu ardiente IV
4220	Grimorio Hervor de sangre III
4221	Grimorio Detectar invisibilidad
4223	Libro sobre Suprimir Magia
4225	Libro sobre Raíces enredadoras III
4226	Libro sobre Cólera VI
4228	Libro sobre Fuego lunar IV
4230	Libro sobre Toque de sanación VI
4231	Pellejo ligero curtido
4232	Pellejo medio
4233	Pellejo medio curtido
4234	Cuero pesado
4235	Pellejo pesado
4236	Pellejo pesado curtido
4237	Cinturón de cuero cosido a mano
4238	Bolsa de lino
4239	Guantes de cuero estampado
4240	Bolsa de lana
4241	Bolsa de lana verde
4242	Pantalones de cuero estampado
4243	Guerrera de cuero refinado
4244	Jubón de cuero de montañero
4245	Talega de seda pequeña
4246	Cinturón de cuero refinado
4247	Guantes de cuero de montañero
4248	Guantes de cuero oscuro
4249	Cinturón de cuero oscuro
4250	Cinturón de montañero
4251	Sobrehombros de montañero
4252	Sobrehombros de cuero oscuro
4253	Guantes de cuero fortalecido
4254	Guantes barbáricos
4255	Armadura de cuero verde
4256	Armadura de guardián
4257	Cinturón de cuero verde
4258	Cinturón de guardián
4259	Brazales de cuero verdes
4260	Brazales de cuero de guardián
4261	Calzas de Solliden
4262	Cinturón de cuero con gemas incrustadas
4263	Escudo de venta estándar
4264	Cinturón barbárico
4265	Refuerzo para armadura pesado
4266	Códice de Fuego interno II
4267	Códice de Palabra de las Sombras: fracaso
4268	Códice de Sanar II
4269	Códice de Rezo de sanación
4270	Códice de Sanar III
4271	Códice de Punición Sagrada V
4272	Códice de Protección contra lo Sagrado
4273	Códice de Sanar
4274	Códice de Escape divino
4275	Códice de Putrefacción mental
4276	Códice de Palabra de las Sombras: fracaso II
4277	Códice de Palabra de las Sombras: ofuscar II
4278	Mena de sangrita inferior
4279	Códice de Palabra de las Sombras: dolor V
4280	Códice de Palabra Sagrada: escudo IV
4281	Códice de Protección contra las Sombras
4282	Códice de Disipar magia II
4283	Códice de Dormir III
4284	Códice de Punición Sagrada VI
4285	Códice de Palabra Sagrada: entereza IV
4286	Códice de Rezo de sanación II
4287	Códice de Enfermedad de anulación II
4288	Códice de Eliminar maldición II
4289	Sal
4290	Cuenco de polvo
4291	Hilo de seda
4292	Patrón: bolsa de lana verde
4293	Patrón: jubón de cuero de montañero
4294	Patrón: cinturón de montañero
4296	Patrón: sobrehombros de cuero oscuro
4297	Patrón: guantes barbáricos
4298	Patrón: cinturón de guardián
4299	Patrón: armadura de guardián
4300	Patrón: brazales de cuero de guardián
4301	Patrón: cinturón barbárico
4302	Daga verde pequeña
4303	Aplastacraneano
4304	Cuero grueso
4305	Madeja de paño de seda
4306	Paño de seda
4307	Guantes de lino gruesos
4308	Brazales de lino verdes
4309	Calzones de lino cosidos a mano
4310	Guantes de lana gruesos
4311	Capa de lana gruesa
4312	Botas de lino de suela suave
4313	Botas de lana roja
4314	Sobrehombros de lana con doble pespunte
4315	Sobrehombros de lana reforzada
4316	Pantalones de lana gruesos
4317	Pantalones Fénix
4318	Guantes de meditación
4319	Guantes de seda azur
4320	Botas de seda de araña
4321	Zapatillas de seda de araña
4322	Capucha de encantador
4323	Caperuza de las Sombras
4324	Jubón de seda azur
4325	Botas del encantador
4326	Capa larga de seda
4327	Capa helada
4328	Cinturón de araña
4329	Cinturón de estrella
4330	Camisa roja con estilo
4331	Guantes Fénix
4332	Camisa amarillo brillante
4333	Camisa de seda oscura
4334	Camisa blanca formal
4335	Camisa de seda morada viva
4336	Camisa de espadachín negra
4337	Seda de araña espesa
4338	Paño de tejido mágico
4339	Madeja de tejido mágico
4340	Tinte gris
4341	Tinte amarillo
4342	Tinte morado
4343	Pantalones de lino marrones
4344	Camisa de lino marrón
4345	Patrón: botas de lana roja
4346	Patrón: capa de lana gruesa
4347	Patrón: sobrehombros de lana reforzada
4348	Patrón: guantes Fénix
4349	Patrón: pantalones Fénix
4350	Patrón: zapatillas de seda de araña
4351	Patrón: caperuza de las Sombras
4352	Patrón: botas del encantador
4353	Patrón: cinturón de araña
4354	Patrón: camisa de seda morada viva
4355	Patrón: capa helada
4356	Patrón: cinturón de estrella
4357	Pólvora férrea
4358	Dinamita férrea
4359	Puñado de tornillos de cobre
4360	Bomba de cobre férrea
4361	Tubo de cobre
4362	Bocarda férrea
4363	Modulador de cobre
4364	Pólvora burda
4365	Dinamita burda
4366	Muñeco-diana
4367	Carga de seforio pequeña
4368	Gafas de tigre volador
4369	Trabuco mortal
4370	Bomba grande de cobre
4371	Tubo de bronce
4372	Bocarda fabricada con amor
4373	Gafas de las Sombras
4374	Bomba de bronce pequeña
4375	Cacharros zumbones de bronce
4376	Deflector de llamas
4377	Pólvora potente
4378	Dinamita potente
4379	Escopeta de chapa de plata
4380	Bomba de bronce grande
4381	Recombobulador menor
4382	Marco de bronce
4383	Rifle de vista lunar
4384	Oveja explosiva
4385	Gafas tintadas de verde
4386	Deflector de hielo
4387	Tornapunta de hierro
4388	Rayo descombobulador
4389	Girocronátomo
4390	Granada de hierro
4391	Juego de segador de la cosecha compacto
4392	Muñeco-diana avanzado
4393	Monóculo de artesano
4394	Bomba de hierro grande
4395	Mina terrestre goblin
4396	Dragonizo mecánico
4397	Aparato de invisibilidad gnómico
4398	Carga de seforio grande
4399	Pila de madera
4400	Surtido pesado
4401	Caja de ardilla mecánica
4402	Glándula de llamas pequeña
4403	Mortero de bronce portátil
4404	Contacto de plata
4405	Mira rudimentaria
4406	Mira estándar
4407	Mira de precisión
4408	Esquema: ardilla mecánica
4409	Esquema: carga de seforio pequeña
4410	Esquema: gafas de las Sombras
4411	Esquema: deflector de llamas
4412	Esquema: rifle de vista lunar
4413	Esquema: rayo descombobulador
4414	Esquema: mortero de bronce portátil
4415	Esquema: monóculo de artesano
4416	Esquema: mina terrestre goblin
4417	Esquema: carga de seforio grande
4419	Pergamino de intelecto III
4421	Pergamino de protección III
4422	Pergamino de aguante III
4424	Pergamino de espíritu III
4425	Pergamino de agilidad III
4426	Pergamino de fuerza III
4428	Pulpa de araña
4429	Órdenes Furiahonda
4430	Dije etéreo
4432	Carta de Sully Balloo
4433	Sobre estropeado por el agua
4434	Calzas de espantapájaros
4435	Mota de Myzrael
4436	Fajín taraceado con joyas
4437	Bastón de canalizador
4438	Brazales de pugilista
4439	Garrote moretón
4440	Sigilo de Strom
4441	Licor de MacKreel
4443	Espaldares macabros
4444	Escudo de coraza negra
4445	Punzón de carne
4446	Hoja veneno negro
4447	Capa de la noche
4448	Coraza de Naraxis
4449	Colmillo de Naraxis
4450	Trozo de sigilo
4453	Sigilo de Thoradin
4454	Garfa de Vultros
4455	Arnés de pellejo de raptor
4456	Cinturón de pellejo de raptor
4457	Ala de águila ratonera a la parrilla
4458	Sigilo de Arathor
4459	Hueso de dragón frágil
4460	Ala rasgada
4461	Pellejo de raptor
4462	Capa de Putrefacción
4463	Collera de cuentas de raptor
4464	Botas de paliza
4465	Guanteletes de puño óseo
4466	Sigilo de Aterratrols
4467	Sigilo de Ignaeus
4468	Trol'kalar enfundada
4469	Vara del Orden
4470	Madera simple
4471	Sílex y yesca
4472	Pergamino de Myzrael
4473	Grilletes tétricos
4474	Arco de madera de cuervo
4476	Toga de caminabestias
4477	Rodela nefaria
4478	Leotardos de escamas iridiscentes
4479	Talismán ardiente
4480	Talismán del trueno
4481	Talismán blasonado
4482	Carpeta sellada
4483	Llave ardiente
4484	Llave blasonada
4485	Llave del trueno
4487	Cartas de navegación de El Capricho
4488	Carta de navegación del Espíritu de Argénteos
4489	Cuaderno de bitácora de El Capricho
4490	Cuaderno de bitácora del Espíritu de Argénteos
4491	Gafas de caza de gemas
4492	Gema élfica
4493	Gemas élficas
4494	Carta lacrada de Cuernomarino
4495	Amuleto de sangrita
4496	Faltriquera marrón pequeña
4497	Bolsa marrón pesada
4498	Cartera de cuero marrón
4499	Saco marrón enorme
4500	Mochila de viajero
4502	Muestra de gema élfica
4503	Colmillo Secacorteza
4504	Capa de guardia enano
4505	Calzas Tierra pantanosa
4506	Distintivo de Stromgarde
4507	Escudo de luchador de fosa
4508	Armadura tintada de sangre
4509	Guantes de lobo marino
4510	Orbe de sangrita contaminada
4511	Martillo de agua negra
4512	Ojo de raptor de las Tierras Altas
4513	Corazón de raptor
4514	Petición de Sara Balloo
4515	Cabeza de Marez
4516	Cabeza de Otto
4517	Cabeza de Falconcrest
4518	Trozo de pergamino roto
4519	Trozo de pergamino arrugado
4520	Trozo de pergamino chamuscado
4521	Granito de Alterac
4522	Faltriquera de medicinas Secacorteza
4524	Monumento a Balloo
4525	Varita de invocación de Trelane
4526	Amuleto de garfa de raptor
4527	Ágata azur
4528	Orbe de Tor'gan
4529	Ágata encantada
4530	Filacteria de Trelane
4531	Orbe de Trelane
4532	Ágata de ascuas de Trelane
4533	Carta lacrada para el archimago Malin
4534	Brazales con cierre de acero
4535	Anillo de recuerdo de Forjaz
4536	Manzana roja lustrosa
4537	Banana Tel'Abim
4538	Sandía Viñarrota
4539	Manzana de Corteza de oro
4540	Mendrugo de pan duro
4541	Pan recién horneado
4542	Pan de maíz húmedo
4543	Gorro de piel de draco blanco
4544	Pan de especias de Mulgore
4545	Brazales de plata radiantes
4546	Llamada del raptor
4547	Irradiador gnómico
4548	Almádena servomecánica
4549	Sortija de fuego marino
4550	Anillo aguafría
4551	Cabeza de Or'Kalar
4552	Trozo de piedra lisa
4553	Trozo de piedra dentado
4554	Piedra pulida lustrosa
4555	Cola escamosa espesa
4556	Fragmento de caparazón moteado
4557	Glándula ígnea
4558	Barrica vacía
4559	CHU's QUEST ITEM
4560	Cimitarra fina
4561	Tomahawk arrancacabelleras
4562	Hacha severa
4563	Garrote reforzado
4564	Garrote con pinchos
4565	Daga simple
4566	Lanza larga robusta
4567	Espada de condotiero
4568	Hacha de bruto
4569	Martillo acérrimo
4570	Gran maza de madera de abedul
4571	Cuchillo de guerra
4575	Bastón medicinal
4576	Arco ligero
4577	Escopeta compacta
4580	Colmillo de dientes de sable
4581	Parche de pelaje refinado
4582	Cola tupida suave
4583	Melena espesa
4584	Pata de trofeo grande
4585	Mandíbula de araña chorreando
4586	Piel de raptor lisa
4587	Plumas de raptor tribal
4588	Calavera de raptor prístino
4589	Pluma elegante larga
4590	Pico amarillo curvo
4591	Ojo de águila
4592	Pargo de lodo boquilargo
4593	Siluro mostacherizo
4594	Bacalao piedrescama
4595	Vino de vid de jungla
4596	Poción de sanación descolorida
4597	Receta: poción de sanación descolorida
4598	Caña de pescar goblin
4599	Filete de jamón curado
4600	Grog de cereza
4601	Pan de plátano tierno
4602	Calabaza de cosecha lunar
4603	Serviola moteada cruda
4604	Champiñón de bosque
4605	Champiñón con motas rojas
4606	Colmenilla esponjosa
4607	Moho de cueva delicado
4608	Trufa negra cruda
4609	Receta: ala de águila ratonera a la parrilla
4610	Urna de piedra grabada
4611	Perla azul
4612	Corazón de draco negro
4613	Caja negra corroída
4614	Colgante de Myzrael
4615	Ataduras de Latigoscuro
4616	Pico de la suerte de Ryedol
4621	Brazal del Embajador Infernus
4622	Nota lacrada para el consejero Belgrum
4623	Poción de escudo de piedra inferior
4624	Receta: poción de escudo de piedra inferior
4625	Flor de fuego
4626	Fragmento de piedra pequeño
4627	Losa de piedra grande
4628	Brazales de vínculo de roca
4629	Cajón de suministros
4630	Chatarra
4631	Tablilla de Ryun'eh
4632	Arcón de bronce ornamentado
4633	Arcón de bronce pesado
4634	Arcón de hierro
4635	Amuleto de Piemartillo
4636	Arcón de hierro fuerte
4637	Arcón de acero
4638	Arcón de acero reforzado
4639	Alga marina encantada
4640	Signo de la Tierra
4641	Mano de Dagun
4643	Manteo de acero rictus
4644	El Corazón Heredado
4645	Cadenas de Hematus
4646	Estrella de Xil'yeh
4647	Compendio de Yagyin
4648	Sigilo del Martillo
4649	Nota de Agarrahueso
4650	Nota de Bel'dugur
4652	Escudo Salbac
4653	Botas con talón de acero
4654	Fósil misterioso
4655	Carne de almeja gigante
4656	Calabaza pequeña
4658	Capa de guerrero
4659	Faja de guerrero
4660	Botas para caminar
4661	Manto brillante
4662	Capa de oficial
4663	Cinturón de oficial
4665	Capa quemada
4666	Cinturón de cuero quemado
4668	Capa de anillas de batalla
4669	Faja de anillas de batalla
4671	Capa ancestral
4672	Cinturón ancestral
4674	Capa tribal
4675	Cinturón tribal
4676	Guanteletes esqueléticos
4677	Capa de veterano
4678	Faja de veterano
4680	Capa de agua estancada
4681	Faja de agua estancada
4683	Capa Vinculahechizo
4684	Cinturón Vinculahechizo
4686	Capa de paño barbárico
4687	Cinturón de paño barbárico
4689	Capa de caza
4690	Cinturón de caza
4692	Capa ceremonial
4693	Cinturón de cuero ceremonial
4694	Espaldares bruñidos
4695	Capa bruñida
4696	Pichel de la lápida de Tidesippe
4697	Faja bruñida
4698	Manto de vidente
4699	Cinturón de vidente
4700	Bufas de cuero grabado
4701	Capa grabada
4702	Pico de prospector
4703	Herramientas rotas
4705	Espaldares de escamas luminiscentes
4706	Capa de escamas luminiscentes
4707	Faja de escamas luminiscentes
4708	Cinturón brillante
4709	Manto de cuero de bosque
4710	Capa de bosque
4711	Capa de luz trémula
4712	Faja de malla de luz trémula
4713	Capa de hilo de plata
4714	Fajín de hilo de plata
4715	Capa blasonada
4716	Capa de combate
4717	Cinturón de combate de malla
4718	Manto Cielo Nocturno
4719	Capa Cielo Nocturno
4720	Fajín Cielo Nocturno
4721	Manto de insignia
4722	Capa de insignia
4723	Pantalones de Humbert
4724	Yelmo de Humbert
4725	Espaldares de brigadier
4726	Capa de brigadier
4727	Faja de brigadier
4728	Sobrehombro de Oposti
4729	Manto aurora
4731	Cubrehombros con inscripciones
4732	Capa con inscripciones
4733	Espaldares Forjanegra
4734	Manto Escapabruma
4735	Capa Escapabruma
4736	Fajín Escapabruma
4737	Bufas de cuero imperiales
4738	Cinturón de cuero imperial
4739	Carne de zancudo de llanura
4740	Pluma de zancudo de llanura
4741	Leotardos de caballería de Stromgarde
4742	Pelambre de puma montés
4743	Fragmento cristalino pulsante
4744	Brazales rúnicos Arcanos
4745	Brazales de jinete de guerra
4746	Toga de orador del Sino
4747	Agua de poza de Ventoro
4748	Agua de poza de Cuerno Rojo
4749	Agua del Pozo Ferocrín
4751	Garfa de Furia del viento
4752	Pluma azur
4753	Pluma de bronce
4755	Jarra de agua
4756	Pelambre de gato estropeada
4757	Cáscaras de huevo rotas
4758	Garra de lobo de pradera
4759	Garfa de zancudo de llanura
4763	Arco corvo Bosque Negro
4765	Espada ancha esmaltada
4766	Hoja feral
4767	Guantes de paño de cobre
4768	Guantes de adepto
4769	Péñola trofeo de aguilón
4770	Cinturón Erizapúas
4771	Capa de la cosecha
4772	Capa cálida
4775	Pico roto
4776	Pluma erizada
4777	Gran maza de maderaférrea
4778	Maza con pinchos pesada
4779	Diente de kodo mate
4780	Trozo de cuerno de kodo
4781	Jubón susurrante
4782	Toga de solsticio
4783	Tótem de Viento de Halcón
4784	Piedra inerte
4785	Cinturón de azufre
4786	Cinturón de hombre sabio
4787	Brea ardiente
4788	Botas de agilidad
4789	Botas de establo
4790	Capa inferno
4791	Agua encantada
4792	Capa espíritu
4793	Capa nemorosa
4794	Brazales de lobo
4795	Brazales de oso
4796	Brazales de búho
4797	Capa ígnea
4798	Capa rúnica gruesa
4799	Capa anticuada
4800	Pantalones de anillas poderosos
4801	Garras de acechador
4802	Garras de puma de las estepas
4803	Diente de alfa de pradera
4804	Corazón de lobo de pradera
4805	Fémur de puma de las estepas
4806	Escama de zancudo de llanura
4807	Molleja de aguilón
4808	Piedra de pozo
4809	Bellota ámbar
4810	Protectores de roca
4813	Collera de cuero pequeña
4814	Colmillo descolorido
4816	Leotardos de Legionario
4817	Mandoble bendito
4818	Espada de verdugo
4819	Sujetapapeles de Saltatuercas
4820	Rodela de guardián
4821	Rodela de oso
4822	Disco de búho
4823	Agua de los Videntes
4824	Hacha borrosa
4825	Hacha callosa
4826	Hacha de maleante
4827	Cinturón zahorí
4828	Cinturón de viento nocturno
4829	Cinturón de soñador
4830	Leotardos de dientes de sable
4831	Pantalones de acecho
4832	Sarong místico
4833	Sobrehombros gloriosos
4834	Documentos de Ventura y Cía.
4835	Sobrehombros de élite
4836	Orbe a prueba de fuego
4837	Fuerza de voluntad
4838	Orbe de Poder
4840	Bayoneta
4841	Cuerno de Arra'chea
4843	Piedra rúnica de amatista
4844	Piedra rúnica de ópalo
4845	Piedra rúnica de diamante
4846	Piñón del n.º 5
4847	Grilletes de vínculo elemental de Lotwil
4848	Hocico de jabaguerrero
4849	Costillar de jabaguerrero
4850	Planes de ataque Erizapúas
4851	Mapa manchado
4852	Bomba cegadora
4854	Capa con marca de demonio
4855	Unused Cloth Shoulder A01 Gray
4856	Unused Cloth Shoulder A02 Yellow
4857	Unused Cloth Shoulder B01 Silver
4858	Unused Cloth Shoulder B02 Black
4859	Medallón del Filo Ardiente
4860	Escama de furia reluciente
4861	Guerrera de plumas impoluta
4862	Cola de escórpido obrero
4863	Herramientas gnómicas
4864	Calavera de Minshina
4865	Pelambre estropeada
4866	Cabeza de Zalazane
4867	Pata de escórpido rota
4869	Garra de Fizzle
4870	Trozos de retal
4871	Collar abrasador
4872	Ojo de escórpido seco
4873	Percebe seco y duro
4874	Raspa limpia
4875	Hueso baboso
4876	Botas de cuero sangrientas
4877	Punta de flecha de piedra
4878	Arco roto manchado de sangre
4879	Cadáver de conejo aplastado
4880	Lanza rota
4881	Sobre viejo
4882	Llave de Benedict
4883	Órdenes del almirante Valiente
4886	Glándula de veneno de Venocola
4887	Ojo de makrura intacto
4888	Mucosidad de reptador
4890	Huevo de colazote
4891	Amuleto de Kron
4892	Pelaje de tigre de Durotar
4893	Colmillo de león de sabana
4894	Riñón de zancudo de llanura
4895	Cuerno de truenagarto
4896	Hígado de kodo
4897	Glándula salivaria de halcón trueno
4898	Glándula relampagueante
4903	Ojo de la Sombra ardiente
4904	Antídoto Venocola
4905	Garra destrozada de Sarkoth
4906	Botas de caminante de lluvia
4907	Guerrera de los bosques
4908	Brazales nómadas
4909	Leotardos de cazador kodo
4910	Guantes de anillas pintados
4911	Rodela de corteza gruesa
4913	Cinturón de anillas pintado
4914	Guantes de cuero desgastados por la batalla
4915	Botas de lana suave
4916	Jubón de lana suave
4917	Leotardos de anillas desgastados por la batalla
4918	Saco de suministros
4919	Cinturón de lana suave
4920	Manteo desgastado por la batalla
4921	Leotardos cubiertos de polvo
4922	Jubón de anillas dentadas
4923	Hachuela primitiva
4924	Garrote primitivo
4925	Hoja de mano primitiva
4926	Barril vacío de Chen
4928	Guardamuñecas Correarenas
4929	Armadura de escórpido ligera
4930	Bolsa de cuero hecha a mano
4931	Arco corto de nogal
4932	Cortaalas de arpía
4933	Capa de luchador avezado
4935	Faja ancha metálica
4936	Botas llenas de barro
4937	Rodela de carga
4938	Bastón de madera manchado
4939	Espada bastarda firme
4940	Mandiletes velados
4941	Pegamento muy pegajoso
4942	Botas de pellejo de tigre
4944	Capa cosida a mano
4945	Calavera con resplandor tenue
4946	Botas de peso ligero
4947	Daga dentada
4948	Maza hiriente
4949	Cuchilla de orco
4951	Cinturón de chivato
4952	Cerveza de Trueno
4953	Brebaje trogg
4954	Cinturón nómada
4957	Bolsa de dinero vieja
4958	Capa estropeada por el sol
4959	Tomahawk arrojadizo
4960	Perdigón cegador
4961	Bastón de vigía de los sueños
4962	Guantes con doble capa
4963	Capa Tronacuerno
4964	Machacagoblins
4965	Hacha de mano Pezuña de Sangre
4966	Cabeza de Mazzranache
4967	Escudo de guerrero tribal
4968	Arnés reforzado
4969	Ataduras reforzadas
4970	Leotardos de kodo sin rematar
4971	Martillo de Skorn
4972	Botas de Abiscorredor
4973	Guardamuñecas de cazador de las llanuras
4974	Cuchillo de lucha compacto
4975	Rodela de vigilante
4976	Falda Rocío de niebla
4977	Espada de Sentencia
4978	Martillo de Ryedol
4979	Brazales de paño de piedra encantados
4980	Guantes de prospector
4981	Faltriquera de cinturón de Agmond
4982	Cinturón de prospector rasgado
4983	Pulverizador de rocas
4984	Cráneo de fatalidad inminente
4986	Piedra de energía con imperfecciones
4987	Espada de capitán enano
4988	Sortija de obsidiana ardiente
4989	Toga de dragón mago
4990	Braciles agostados
4992	Carta de reclutamiento
4995	Carta de reclutamiento firmada
4998	Anillo de sangre
4999	Voluntad de Azora
5000	Sortija de coral
5001	Anillo de corazón
5002	Dije verde resplandeciente
5003	Medallón de fuego estelar de cristal
5004	Marca del Kirin Tor
5005	Colgante de chispa de ascuas
5006	Diario de Khazgorm
5007	Sortija de Espinas
5008	Anillo de mercurio
5009	Anillo de dominación mental
5010	Anillo de oro grabado
5011	Anillo welken
5012	Esporas de hongos
5013	Bulbo fértil
5014	Wrapping Paper (PT)
5015	Wrapped Item (PT)
5016	Calzas de artesano
5017	Nitroglicerina
5018	Pulpa de madera
5019	Nitrato sódico
5020	Llave del botín de Kolkar
5021	Palo explosivo de Gann
5022	Cabeza de Aterrakodos
5023	Cabeza de Verog
5024	Vial escarchado
5025	Cabeza de Hezrul
5026	Alquitrán
5027	Esporas devueltas
5028	Cetro de Lord Sakrasis
5029	Dije del Señor de los nagas
5030	Brazales centauro
5038	Lágrima de las lunas
5040	Cuchillo de cazador de las Sombras
5042	Papel para envolver con lazo rojo
5043	Obsequio con lazo rojo
5044	Obsequio con lazo azul
5045	Calavera obsequio
5046	Regalo cerrado
5047	Papel para envolver de calaveras
5048	Papel para envolver con lazo azul
5049	Lámina de hierro con autocierre
5050	Llave de ignición
5051	Rata de madriguera
5052	Rata de madriguera inconsciente
5054	Churumbele
5055	Cuerno de raptor intacto
5056	Muestra de raíz
5057	Sandía madura
5058	Huevo de silítido
5059	Garra de excavación
5060	Herramientas de ladrón
5061	Plata robada
5062	Cabeza de raptor
5063	Colmillo de Kreenig Gruñucico
5064	Garra de Alabruja
5065	Anillo de teniente arpía
5066	Planta de fisura
5067	Cabeza de Serena
5068	Semillas secas
5069	Varita de fuego
5071	Varita de las Sombras
5072	Calavera de Lok
5073	Calavera de Nak
5074	Calavera de Kuz
5075	Esquirla de sangre
5076	Envío de botas
5077	Lentes telescópicas
5078	Medalla de Theramore
5079	Ojo de basilisco frío
5080	Libro de contabilidad de Gazlowe
5081	Bolsa de pellejo de kodo
5082	Cuero fino de kodo
5083	Patrón: bolsa de pellejo de kodo
5084	Cabeza del barón Longavera
5085	Colmillo de jabaespín erizapúas
5086	Pezuñas de zhebra
5087	Pico de zancudo de llanura
5088	Manual de instrucciones de la consola de control
5089	Llave de la consola
5092	Varita Crines de Acero carbonizada
5093	Puñal Crines de Acero
5094	Escudo de guerra Crines de Acero
5095	Atún blanco arco iris
5096	Garras de merodeador
5097	Esmeralda ojo de gato
5098	Caparazón de quijaforte alterado
5099	Pezuña de Lakota'mani
5100	Pellejo de Echeyakee
5101	Colmillo de Ishamuhale
5102	Punta de cola de Owatanka
5103	Pluma de Washte Pawne
5104	Corazón de Isha Awak
5105	Cartucho explosivo
5107	Camisa de Manoberta
5108	Cuero Hierro Negro
5109	Trapos Rompecantos
5110	Toga de zahorí Dalaran
5111	Manteo de Rathorian
5112	Hoja de ritual
5113	Marca de la Hermandad
5114	Garfa cortada
5115	Hueso de la suerte partido
5116	Pluma de cola larga
5117	Péndola vibrante
5118	Diente plano grande
5119	Pelo suelto refinado
5120	Pelo de cola larga
5121	Escama de kodo sucia
5122	Pelo de kodo grueso
5123	Punta de flecha de acero
5124	Diente de raptor pequeño
5125	Escama cargada
5126	Conocimiento: Disfraz de Defias
5127	Conocimiento: Disfraz de pirata de los Mares del Sur
5128	Muda de piel de lagarto
5129	Conocimiento: Disfraz de enano Hierro Negro
5130	Conocimiento: Disfraz de zahorí de Dalaran
5131	Conocimiento: Disfraz de Rompecantos
5132	Conocimiento: Disfraz de Hermandad
5133	Mollejas húmedas
5134	Garra peluda pequeña
5135	Garra negra fina
5136	Oreja peluda rasgada
5137	Ojo brillante
5138	Cabeza de cosechador
5139	Libro sobre Espinas
5140	Pólvora cegadora
5141	Libro sobre Recrecimiento
5142	Libro sobre Cólera II
5143	Sangre de truenagarto
5145	Libro sobre Toque de sanación II
5147	Libro sobre Raíces enredadoras II
5148	Libro sobre Espinas II
5149	Libro sobre Cólera III
5150	Libro sobre Toque de sanación III
5151	Libro sobre Cólera IV
5152	Libro sobre Toque de sanación IV
5153	Libro sobre Marca de lo Salvaje IV
5154	Libro sobre Espinas III
5155	Libro sobre Marca de lo Salvaje II
5156	Libro sobre Cólera V
5158	Libro sobre Tranquilidad
5160	Libro sobre Toque de sanación V
5163	Libro sobre Marca de lo Salvaje III
5164	Alas de halcón trueno
5165	Pluma de Solescama
5166	Glándula venenosa de Tejemadera
5167	Huevo de Tejemadera
5168	Semilla de Brezomadera
5169	Brote de Brezomadera
5170	Tumor musgoso
5172	Cápsula de la Muerte
5173	Muerteflor
5174	Nota de Neeru
5175	Tótem de tierra
5176	Tótem de fuego
5177	Tótem de agua
5178	Tótem de aire
5179	Corazón musgoso
5180	Collar de Armonía
5181	Manteo de seda vibrante
5182	Hoja escalofrío
5183	Corazón de hidra pulsante
5184	Ampolla de cristal llena
5185	Ampolla de cristal
5186	Vasija parcialmente llena
5187	Martillo de Rhahk'Zor
5188	Vasija llena
5189	Fruta resplandeciente
5190	Fronda fulgurante
5191	Púa cruel
5192	Espada de ladrón
5193	Manteo de la Hermandad
5194	Hacha de Capataz
5195	Guantes con motas de oro
5196	Espetadora de acometida
5197	Rodillo de Cocinitas
5198	Vara para remover de Cocinitas
5199	Pantalones de fundición
5200	Arpón para empalar
5201	Bastón de Piedra Ígnea
5202	Sobrecamisa de corsario
5203	Garra de merodeador de las estepas
5204	Cinturón Sangrepluma
5205	Fronda crecida
5206	Raíz de ciénaga
5207	Varita opaca
5208	Varita humeante
5209	Varita luminiscente
5210	Varita ardiente
5211	Varita Alba
5212	Varita llameante
5213	Varita agostadora
5214	Varita de Manto de la noche
5215	Varita de ascuas
5216	Varita umbría
5217	Corazón máculo
5218	Corazón de Brezomadera Pulcleris
5219	Corteza grabada
5220	Colmillo Tuercepinos
5221	Cabeza de Melenas
5223	Gema de maná vacía
5227	Joya de maná vacía
5229	Sangrita superior vacía
5232	Piedra de alma menor
5233	Piedra de Relu
5234	Fósil de Gargavino
5235	Varita de alquimista
5236	Varita de combustible
5237	Veneno de aturdimiento mental
5238	Varita de madera
5239	Varita de hueso negro
5240	Varita antorcha
5241	Palo de fuego enano
5242	Varita de ceniza
5243	Escupellamas
5244	Varita sacralizada consagrada
5245	Varita de invocador
5246	Vara de excavación
5247	Vara de pena
5248	Varita cegadora
5249	Esquirla ardiente
5250	Varita carbonizada
5251	Ampolla de adivinación
5252	Varita de Descomposición
5253	Encendedor goblin
5254	Bufas bastas
5255	Tomahawk jabaespín
5256	Sonajero de Kovork
5257	Manteo con caperuza oscuro
5263	Gasa de bolsillo
5264	Muestra de cerveza de obsequio
5265	Cerveza aguada
5266	Ojo de Adaegus
5267	Kris Escarlata
5268	Cáscara de silítido rajada
5269	Icor de silítido
5270	Oronja verde
5271	Boleto rudo
5272	Garabatos incomprensibles
5273	Reliquia de Mathystra
5274	Manto rosa
5275	Faja de vínculo
5279	Desollador de arpía
5299	Guantes de la luna
5302	Rodela de cobalto
5306	Bastón de jinete del viento
5309	Mosquete de Soldado
5310	Calzones de lobo marino
5311	Botas con hebillas
5312	Guanteletes ribeteados
5313	Anillo totémico del clan
5314	Manteo de cazador de jabalíes
5315	Guardabrazos de madera
5316	Guerrera de malla de corteza
5317	Guerrera de moho seco
5318	Hacha Zhovur
5319	Espaldares azotadores
5320	Botas de láminas acolchadas
5321	Espada corta elegante
5322	Martillo de demolición
5323	Linterna eterna
5324	Martillo de ingeniero
5325	Escudo de soldadura
5326	Bordón flamígero
5327	Pantalones de manitas grasientos
5328	Cinturón cinchado
5329	Figurilla de gato
5330	Reliquia de copa élfica
5332	Figurilla de gato resplandeciente
5334	Oporto con 99 años de antigüedad
5335	Un costal de monedas
5336	Pendiente grell
5337	Guantes caminante
5338	Sello de piedra lunar antiguo
5339	Reptilia
5340	Cucharón de caldera
5341	Guerrera cubierta de esporas
5342	Ponche de raptor
5343	Capa de posadero
5344	Hacha puntiaguda
5345	Martillo madera de piedra
5346	Arco de batalla de orco
5347	Varita pestilente
5348	Papiro desgastado
5349	Magdalena mágica
5350	Agua mágica
5351	Anillo de cazarrecompensas
5352	Libro: Los Poderes inferiores
5353	Mensaje para Elissa Brisaestelar
5354	Carta para Delgren
5355	Faja de maestro de bestias
5356	Vara para marcar
5357	Escudo del Valle
5359	Manuscrito de Lorgalis
5360	Reliquia de Altonato
5361	Raspa mondadientes
5362	Mordedor
5363	Pañuelo doblado
5364	Lengüetazo de sal seca
5366	Gema de alma resplandeciente
5367	Instrumento de roca primitivo
5368	Monedero vacío
5369	Hueso mordisqueado
5370	Cuchara doblada
5371	Trozo de coral
5373	Talismán de la suerte
5374	Reloj de bolsillo pequeño
5375	Palito para rascarse
5376	Espejo roto
5377	Concha de vieira
5379	Cuchillo de bota
5380	Carta lacrada para Elissa
5381	Carta lacrada para Balthule
5382	Colgante de Anaia
5383	Cabeza de Athrikus Narassin
5385	Pata de reptador
5386	Pelambre de Acechalunas refinada
5387	Capa de Acechalunas encantada
5388	Calavera de Ran Sangradientes
5389	Tótem de fúrbolg corrupto
5390	Mensaje de Fandral
5391	Tierra rara
5392	Daga Cardoleño
5393	Bastón Cardoleño
5394	Guantes de entrenamiento en tiro con arco
5395	Escudo de los bosques
5396	Llave de la Garganta de Fuego
5397	Pólvora de los Defias
5398	Leotardos canope
5399	Botas de rastreo
5400	Sangre de Cobrahn
5401	Sangre de Pythas
5402	Sangre de Anacondra
5403	Sangre de Serpentis
5404	Sobrehombros de serpiente
5405	Capa envuelta
5406	Sangrita menor vacía
5411	Tótem de limpieza Pezuña Invernal
5412	Ojo de trillador
5413	Colmillo de Acechalunas
5414	Cuero cabelludo grisáceo
5415	Tótem de limpieza Tronacuerno
5416	Tótem de limpieza Ferocrín
5419	Brazales ferales
5420	Armadura de alma en pena
5421	Encantamiento Llamarada ígnea
5422	Leotardos zarza
5423	Colmillo de Boahn
5424	Estatuilla antigua
5425	Faja de escamas rúnicas
5426	Beso de serpiente
5427	Reloj de bolsillo rudimentario
5428	Un libro de cocina exótico
5429	Una bonita roca
5430	Adorno intrincado
5431	Petaca vacía
5432	Pipa de nogal
5433	Muñeca harapienta
5435	Peine lustroso
5437	Cabello de Bathran
5439	Carcaj pequeño
5440	Botella de enfermedad
5441	Faltriquera de pólvora pequeña
5442	Cabeza de Arugal
5443	Rodela con placas de oro
5444	Manteo de minero
5445	Anillo de Zoram
5446	Brazal elemental roto
5447	Brazal elemental dañado
5448	Brazal elemental fracturado
5451	Brazal elemental aplastado
5455	Pergamino descifrado
5456	Pergamino de adivinación
5457	Garra de vudú cortada
5458	Cinturón tierraleño
5459	Hacha defensora
5460	Cura de Orendil
5461	Rama de Cenarius
5462	Vara de transformación de Dartol
5463	Gema resplandeciente
5464	Asta de hierro
5465	Pata de araña pequeña
5466	Aguijón de escórpido
5467	Carne de kodo
5468	Carne de frenesí tierna
5469	Carne de zancudo
5470	Cola de truenagarto
5471	Carne de venado
5472	Kebab de araña kaldorei
5473	Sorpresa de escórpido
5474	Carne de kodo asada
5475	Llave de madera
5476	Filete de pez furia
5477	Estofado de zancudo
5478	Estofado de ratas de madriguera
5479	Cola de lagarto crujiente
5480	Venado magro
5481	Cuernos de sátiro
5482	Receta: kebab de araña kaldorei
5483	Receta: sorpresa de escórpido
5484	Receta: carne de kodo asada
5485	Receta: filete de pez furia
5486	Receta: estofado de zancudo
5487	Receta: estofado de ratas de madriguera
5488	Receta: cola de lagarto crujiente
5489	Receta: venado magro
5490	Cabeza de Colafuria
5493	Lágrima de Elune
5494	Puñado de polvo estelar
5498	Perla lustrosa pequeña
5500	Perla iridiscente
5503	Carne de almeja
5504	Carne de almeja ácida
5505	Diario de Teronis
5506	Ojo acechador redondo
5507	Catalejo ornamentado
5508	Piedra lunar caída
5509	Piedra de salud
5510	Piedra de salud superior
5511	Piedra de salud inferior
5512	Piedra de salud menor
5513	Jade de maná
5514	Ágata de maná
5516	Colmillo de trillanodonte
5517	Llave pequeña de bronce
5518	Pequeña llave de hierro
5519	Pomo de hierro
5520	Diario de Velinde
5521	Llave de Velinde
5522	Piedra de hechizo
5523	Percebe pequeño
5524	Almeja gruesa
5525	Almejas hervidas
5526	Sopa de almejas
5527	Almejas picantes a la goblin
5528	Receta: sopa de almejas
5529	Polvo de tumba
5530	Partículas cegadoras
5533	Escrito de Ilkrud Magthrull
5534	Almuerzo de Parker
5535	Compendio de los Caídos
5536	Mitología de los titanes
5537	Cabeza de Sarilus Fuenteviciosa
5538	Alianza de Vorrel
5539	Carta de recomendación
5540	Daga con empuñadura de perla
5541	Martillo iridiscente
5542	Capa con broche de perlas
5543	Diseño: martillo iridiscente
5544	Calavera de Dal Zarpasangrante
5547	Vara reconstruida
5565	Piedra infernal
5566	Asta rota
5567	Gancho de plata
5568	Guijarro liso
5569	Algas
5570	Huevo de Musgondo
5571	Faltriquera negra pequeña
5572	Faltriquera verde pequeña
5573	Bolsa de cuero verde
5574	Bolsa de cuero blanco
5575	Costal verde grande
5576	Costal marrón grande
5577	Diseño: brazales de bronce férreos
5578	Diseño: coraza de bronce bañada en plata
5579	Martillo de guerra de milicia
5580	Martillo de milicia
5581	Bastón de apoyo liso
5582	Savia del Espolón
5583	Escama de dragón hada
5584	Mostacho Crepuscular
5585	Ojo de trotador
5586	Espada Cardoleño
5587	Garrote de raíz de espinas
5588	Toxina de Lydon
5589	Guanteletes cubiertos de musgo
5590	Brazales de cordón
5591	Manteo chispeado
5592	Faja apretada
5593	Rodela de risco
5594	Carta para Jin'Zil
5595	Martillo de matorral
5596	Arco de fresno
5601	Glándula de huevo eclosionado
5602	Tela de araña pegajosa
5603	Zurrón de Zumbang
5604	Varita élfica
5605	Cuchillo de poda
5606	Guantes de jardinería
5608	Capucha viva
5609	Cincho de determinación férrea
5610	Capa de entrañas
5611	Lágrima de dolor
5612	Puños de hiedra
5613	Bastón del Purificador
5614	Golpe de Seraph
5615	Espada de leñador
5616	Desgarrantrañas
5617	Leotardos de vagabundo
5618	Capa de explorador
5619	Ampolla de jade
5620	Vial de sangre inocente
5621	Ampolla de turmalina
5622	Anillo de clero
5623	Ampolla de amatista
5624	Aro de la Orden
5626	Astillacalaveras
5627	Hoja reliquia
5628	Nota de Zamah
5629	Guantes de Puñomartillo
5630	Guantes de paño de viento
5631	Poción de ira
5632	Poción de huida cobarde
5633	Poción de gran ira
5634	Poción de acción libre
5635	Garra afilada
5636	Pluma delicada
5637	Colmillo grande
5638	Niebla tóxica
5639	Ampolla de jade llena
5640	Receta: poción de ira
5641	Receta: poción de huida cobarde
5642	Receta: poción de acción libre
5643	Receta: poción de gran ira
5644	Escrito sobre Crear agua
5645	Ampolla de turmalina llena
5646	Vial de agua bendita
5647	Escrito sobre Traslación
5648	Escrito sobre Armadura de Escarcha III
5649	Escrito sobre Ventisca
5650	Escrito sobre Crear agua III
5654	Toxina instantánea
5655	Brida de yegua zaina
5656	Brida de caballo marrón
5657	Receta: toxina instantánea
5658	Tratado: Sello de poderío
5659	Ascuas humeantes
5660	Tratado: Sello de rectitud
5661	Tratado: Sello de rectitud II
5662	Tratado: Sello de rectitud III
5663	Cuerno del lobo rojo
5664	Metralla corroída
5665	Cuerno del lobo temible
5666	Tratado: Sello de cólera II
5667	Tratado: Sello de sabiduría II
5668	Cuerno del lobo marrón
5669	Restos de diablo de polvo
5670	Tratado: Sello de cólera IV
5671	Tratado: Sello de poderío III
5672	Tratado: Exorcismo
5673	Tratado: Exorcismo II
5674	Tratado: Exorcismo III
5675	Escamas cristalizadas
5676	Tratado: Captar no-muertos
5677	Tratado: Ahuyentar no-muertos
5678	Tratado: Lacre de sacrificio
5679	Tratado: Sello de sabiduría III
5680	Tratado: Sello de protección II
5681	Savia corrosiva
5682	Tratado: Ahuyentar no-muertos II
5683	Tratado: Escudo divino II
5684	Tratado: Sello de salvación
5685	Tratado: Redención
5686	Cabeza de Ordanus
5687	Llave del Guardián
5689	Llave de durmiente
5690	Llave garra
5691	Llave de la carretilla
5692	Detonador a distancia (rojo)
5693	Detonador a distancia (azul)
5694	Explosivos NG-5 (rojo)
5695	Explosivos NG-5 (azul)
5696	Tablilla de choque
5697	Tablilla de Tótem sanador
5698	Tablilla de Escudo de relámpagos
5699	Tablilla de Lobo fantasmal
5700	Tablilla de Tótem sanador II
5701	Tablilla de Tótem avizor
5702	Tablilla de Tótem agitador II
5703	Tablilla de Atronar
5704	Tablilla de Respiración acuática
5705	Tablilla de Tótem sanador III
5706	Tablilla de Tótem serpiente III
5707	Tablilla de Visión lejana
5708	Tablilla de Forma etérea
5709	Tablilla de Caminar sobre el agua
5710	Tablilla de Tótem sanador IV
5711	Tablilla de Lobo fantasmal II
5712	Tablilla de Tótem serpiente IV
5713	Tablilla de Descarga de truenos
5714	Tablilla de Tótem enredador II
5715	Tablilla de Tormenta de relámpagos III
5716	Tablilla de Restauración VI
5717	Cartas de Ventura y Cía.
5718	Planos de ingeniería de Ventura y Cía.
5719	Grimorio Drenaje de vida II
5720	Grimorio Maldición de Mannoroth II
5721	Grimorio Crear piedra de hechizo
5722	Grimorio de Succión de maná II
5723	Grimorio Maldición de Sargeras III
5724	Grimorio Maldición de lenguas
5725	Grimorio Pestilencia III
5726	Grimorio Crear sangrita superior
5727	Grimorio Cauce de maná
5728	Grimorio Lluvia de Fuego II
5729	Grimorio Miedo III
5730	Libro sobre Rejuvenecimiento
5731	Pergamino de mensaje
5732	NG-5
5733	Mena sin identificar
5734	Planos de la Súper Segadora 6000
5735	Sobre lacrado
5736	Brazo mecánico de Gerenzo
5737	Diseños de camaleón: alfa y beta
5738	Talega camaleón
5739	Arnés barbárico
5740	Cohete de fuegos artificiales rojos
5741	Trozo de roca
5742	Daga de gemas
5743	Anillo de piedra prismática
5744	Desollador pálido
5748	Arco largo centauro
5749	Hacha guadaña
5750	Faja de Jefe de Guerra
5751	Capa telaraña
5752	Punta de cola de dracoleón
5753	Corona alborotada
5754	Medallón de jauría de lobos
5755	Placa trituradora de ónice
5756	Hoja tajante
5757	Cayada de madera dura
5758	Arcón de mitril
5759	Arcón de torio
5760	Arcón de eternio
5761	Almádena Yunquemar
5762	Bolsa de lino roja
5763	Bolsa de lana roja
5764	Talega de seda verde
5765	Talega de seda negra
5766	Toga de zahorí inferior
5767	Togas violeta
5768	Entrada a las carreras gnomas
5769	Entrada a las carreras goblin
5770	Togas de Arcana
5771	Patrón: bolsa de lino roja
5772	Patrón: bolsa de lana roja
5773	Patrón: togas de Arcana
5774	Patrón: talega de seda verde
5775	Patrón: talega de seda negra
5776	Bastón de anciano
5777	Hacha de Valiente
5778	Cachava primitiva
5779	Espada bastarda de los Renegados
5780	Cinturón de escamas de múrloc
5781	Coraza de escamas de múrloc
5782	Armadura múrloc gruesa
5783	Brazales de escamas de múrloc
5784	Escama de múrloc babosa
5785	Escama múrloc gruesa
5786	Patrón: cinturón de escamas de múrloc
5787	Patrón: coraza de escamas de múrloc
5788	Patrón: armadura múrloc gruesa
5789	Patrón: brazales de escamas de múrloc
5790	Diario de Soliceja
5791	Diario de Henrig Soliceja
5792	Medallón de Filonavaja
5793	Corazón de Filonavaja
5794	Veneno de escórpido salado
5795	Caparazón de tortuga endurecido
5796	Aleta dorsal taraceada
5797	Lámina de indurio
5798	Piezas de coche cohete
5799	Pedido de piezas de Kravel
5800	Piezas de Kravel
5801	Guano del Horado
5802	Piezas de coches delicadas
5803	Pizca de polvo onírico
5804	Rumores goblin
5805	Corazón de fanatismo
5806	Cerveza de tontos
5807	Informe de cerveza de tontos
5808	Glándula de veneno de Alaorgullo
5809	Glándula de veneno de Nido Alto
5810	Cadáver reciente
5811	Crin de Faucehielo
5812	Togas de Antigüedad
5813	Enseña de Emil
5814	Armadura riachuelo
5815	Piedra glacial
5816	Luz de Elune
5817	Arco Lunaris
5818	Varita de destello lunar
5819	Almófar Llamarada sol
5820	Manto feérico
5821	Botas del acechador oscuro
5822	Guanteletes de seto
5823	Champiñón venenoso
5824	Tablilla de Voluntad
5825	Colgante de Treshala
5826	Esquema de Kravel
5827	Carta de Fizzle Pernolatón
5829	Pico afilado
5830	Cabeza de Kenata
5831	Cabeza de Fardel
5832	Cabeza de Marcel
5833	Mena de indurio
5834	Barril de tabaco de Mok'Morokk
5835	Grog de Mok'Morokk
5836	Caja fuerte de Mok'Morokk
5837	Costilla de Metaleador
5838	Pergamino de piel de kodo
5839	Página de diario
5840	Lengua abrasadora
5841	Corazón abrasador
5842	Muestra bruta de mena
5843	Garra de Grenka
5844	Trozo de Rok'Alim
5845	Costillar de carne
5846	Nota lacrada de Korran
5847	Cabeza de Ancalodo
5848	Hueso hueco de buitre
5849	Cajón de cascos de choque
5850	Nota lacrada de Belgrom
5851	Llave de Cozzle
5852	Planos de regulador de combustible
5853	Caparazón de silítido intacto
5854	Garfa de silítido
5855	Corazón de silítido
5857	Caja con premio gnomo
5858	Caja con premio goblin
5859	Granada de fiesta
5860	Legado de los Aspectos
5861	Comienzos de la amenaza de los no-muertos
5862	Propulsor de seforio
5863	Estatutos de Hermandad
5864	Carnero gris
5865	Propulsor de seforio modificado
5866	Muestra de mena de indurio
5867	Ampolla con grabados
5868	Ampolla con grabados llena
5869	Pezuña hendida
5871	Pezuña grande
5872	Carnero marrón
5873	Carnero blanco
5874	Arnés: carnero negro
5875	Arnés: carnero azul
5876	Tubérculo hojazul
5877	Caparazón de silítido rajado
5878	Tabaco superior
5879	Colgante Crepuscular
5880	Cajón con agujeros
5881	Cabeza de Kelris
5882	Documentos del Capitán
5883	Lengua Fangorroca bífida
5884	Ojo de Niebla Negra sin reventar
5897	Manual de propietario de husmeador
5916	Llave de cámara gnoma
5917	Informe de espía
5918	Cabeza de orco desafiante
5919	Escudo de hierro ennegrecido
5936	Cinturón de piel de animal
5937	Llave de cámara goblin
5938	Pata de reptador prístina
5939	Guantes de costura
5940	Rodela de huesos
5941	Pantalones de escamas de latón
5942	Colgante enjoyado
5943	Brazales falla
5944	Grebas de La Milicia Popular
5945	Diente de Lodomuerto
5946	Nota lacrada para Elling
5947	Certificado Defias
5948	Carta para Jorgen
5949	Tira de papel
5950	Distintivo de Reethe
5951	Toallita húmeda
5952	Bulbo raquídeo corrupto
5956	Martillo de herrero
5957	Jubón de cuero cosido a mano
5958	Pantalones de cuero refinado
5959	Glándula de veneno ácido
5960	Nota lacrada para el vigía Backus
5961	Pantalones de cuero oscuro
5962	Pantalones de guardián
5963	Leotardos barbáricos
5964	Sobrehombros barbáricos
5965	Capa de guardián
5966	Guantes de guardián
5967	Faja de Nobleza
5968	Botas bastas
5969	Capa de regente
5970	Guantes de serpiente
5971	Manteo de plumas
5972	Patrón: pantalones de cuero refinado
5973	Patrón: leotardos barbáricos
5974	Patrón: capa de guardián
5975	Cinturón de rufián
5976	Tabardo de Hermandad
5996	Elixir de respiración acuática
5997	Elixir de defensa menor
5998	Pedido de Pico Tormenta
6016	Muestra de corazón de lobo
6037	Barra de veraplata
6038	Almeja gigante a la brasa
6039	Receta: almeja gigante a la brasa
6040	Brazales de escamas doradas
6041	Cadena de acero
6042	Punta de escudo de hierro
6043	Contrapeso de hierro
6044	Diseño: escudo con punta de hierro
6045	Diseño: contrapeso de hierro
6046	Diseño: cadena de acero
6047	Diseño: almófar de escamas doradas
6048	Poción de Protección contra las Sombras
6049	Poción de Protección contra el Fuego
6050	Poción de Protección contra la Escarcha
6051	Poción de Protección contra lo Sagrado
6052	Poción de Protección contra la Naturaleza
6053	Receta: poción de Protección contra lo Sagrado
6054	Receta: poción de Protección contra las Sombras
6055	Receta: poción de Protección contra el Fuego
6056	Receta: poción de Protección contra la Escarcha
6057	Receta: poción de Protección contra la Naturaleza
6058	Cinturón de cuero ennegrecido
6059	Jubón nómada
6060	Brazales de lienzo
6061	Brazales de piedra gris
6062	Brazales de cordón pesados
6063	Guanteletes de acero frío
6064	Discos de platino en miniatura
6065	Ensayos de Khadgar sobre convergencia dimensional
6066	Cabeza de Khan Dez'hepah
6067	Oreja de centauro
6068	Receta: aceite de las Sombras
6069	Carne secada de forma rudimentaria
6070	Brazales de piel de lobo
6071	Cristal draenetista
6072	Cabeza de Khan Jehn
6073	Cabeza de Khan Shaka
6074	Boquilla de cuerno de guerra
6075	Informe de Vimes
6076	Pantalones estrechos
6077	Trozo de llave Maraudine
6078	Escudo de piquero
6079	Talismán rudimentario
6080	Corazón de pantera de las Sombras
6081	Hongos del Señor del Lodo
6082	Tumor zancaprofunda
6083	Lágrimas rotas
6084	Leotardos de guardia de Ventormenta
6085	Guerrera de lacayo
6086	Suero de la verdad de Faustin
6087	Botarga de los Páramos de Poniente
6089	Brebaje de Zraedus
6091	Cajón de piedras de energía
6092	Botas de cría negra
6093	Triturador orco
6094	Hacha penetrante
6095	Botas deambulantes
6096	Camisa de aprendiz
6097	Camisa de acólito
6098	Toga de neófito
6116	Toga de aprendiz
6117	Camisa de escudero
6118	Pantalones de escudero
6119	Toga de neófito
6120	Camisa de recluta
6121	Pantalones de recluta
6122	Botas de recluta
6123	Toga de novicio
6124	Pantalones de novicio
6125	Arnés de camorrista
6126	Pantalones de trampero
6127	Botas de trampero
6129	Toga de acólito
6130	Camisa de trampero
6131	Pantalones de trampero
6132	Tratado: Sello de sabiduría
6133	Tratado: Sello de furia
6134	Cubretorso primitivo
6135	Falda primitiva
6136	Camisa de matón
6137	Pantalones de matón
6138	Botas de matón
6139	Toga de novicio
6140	Toga de aprendiz
6144	Toga de neófito
6145	Colgante de Clarice
6146	Madera a la deriva desecada
6147	Cinturón viejo de rata
6148	Botas cubiertas de telaraña
6149	Poción de maná superior
6150	Un nudo deshilachado
6166	Mandíbula de coyote
6167	Informe de Neeka
6168	Garra de sacudidor Denteserra
6169	Costillar de Denteserra sin preparar
6170	Componentes de zahorí
6171	Guantes de cuidador de lobos
6172	Provisiones extraviadas
6173	Botas de nieve
6174	Espada aleatoria de Oposti
6175	Artefacto Atal'ai
6176	Escudo oblongo enano
6177	Brazales de hierro forjado
6178	Envío a Nethergarde
6179	Manteo de Soldado
6180	Piel de Eslarc
6181	Fetiche de Hakkar
6182	Antorcha poco iluminada
6183	Antorcha pobre sin encender
6184	Pata de reptador monstruoso
6185	Chal de oso
6186	Cercenadora trogg
6187	Defensor enano
6188	Apisonadoras de barro
6189	Sobrehombros de anillas durables
6190	Fragmento draenetista
6191	Botas Kimbra
6192	Cabeza de Khan Hratha
6193	Fardo de artefactos Atal'ai
6194	Segadora para Barricas
6195	Armadura encerada
6196	Cayada de Noboru
6197	Jubón de pellejo de crocolisco
6198	Guardamuñecas jurásicos
6199	Sortija de viuda negra
6200	Cinturón de guerra de Gameg
6201	Botas ágiles
6202	Guantes sin dedos
6203	Escudo matón
6204	Yelmo de huargo tribal
6205	Pala para escarbar
6206	Punzón
6207	JcJ: diseños de torre de la Horda
6208	JcJ: diseños de torre de la Alianza
6209	JcJ: certificado de mina de la Horda
6210	JcJ: certificado de mina de la Alianza
6211	Receta: elixir de fuerza de ogro
6212	Cabeza de Jammal'an
6214	Gran maza de cobre pesada
6215	Palo de lucha equilibrado
6216	Partículas místicas
6217	Vara de cobre
6218	Vara rúnica de cobre
6219	Llave de tuerca arcoluz
6220	Fragmento de meteorito
6222	Fórmula: imbuir pechera: espíritu menor
6223	Blasón de Villa Oscura
6226	Mandil sangriento
6238	Toga de lino marrón
6239	Jubón de lino rojo
6240	Jubón de lino azul
6241	Toga de lino blanca
6242	Toga de lino azul
6243	Toga de lana verde
6244	ggggfg
6245	Cartera de Karnitol
6246	Garra de Odio Feroz
6247	Cuerno de Odio Feroz
6248	Veneno Scorpashi
6249	Pellejo de kodo envejecido
6250	Cerebro de can manáfago
6251	Ala Abisal
6252	Sangre de guardiavil
6253	Paquete de Zurdibrujo
6256	Caña de pescar
6257	Mollejas de roc
6258	Hígado de Cueracero
6259	Hígado de Groddoc
6260	Tinte azul
6261	Tinte naranja
6262	Diario de Galen
6263	Mono azul
6264	Toga de adepto superior
6265	Fragmento de alma
6266	Jubón de discípulo
6267	Pantalones de discípulo
6268	Guerrera de pionero
6269	Calzas de pionero
6270	Patrón: jubón de lino azul
6271	Patrón: jubón de lino rojo
6272	Patrón: toga de lino azul
6273	Patrón: toga de lana verde
6274	Patrón: mono azul
6275	Patrón: toga de adepto superior
6276	Nota mohosa
6277	Papiro mohoso
6278	Pergamino mohoso
6279	Carta mohosa
6280	Misiva mohosa
6281	Calavera armadósea
6282	Calzas de entierro sacro
6283	El libro de Ur
6284	Runas de Invocación
6285	Grimorio Egalin
6286	Corazones puros
6287	Trozo de tablilla Atal'ai
6288	Tablilla Atal'ai
6289	Pargo de lodo boquilargo crudo
6290	Pececito luminoso
6291	Pececito luminoso crudo
6292	Pargo de lodo de 5 kilos
6293	Sangre de murciélago seca
6294	Pargo de lodo de 6 kilos
6295	Pargo de lodo de 7 kilos
6296	Parche de crin de murciélago
6297	Calavera vieja
6298	Colmillo de murciélago sangriento
6299	Pescado con mala pinta
6300	Trozo de coraza
6301	Calavera de camionero vieja
6302	Ala de insecto delicada
6303	Caballa de piel escurridiza cruda
6304	Página de diario mojada (día 4)
6305	Página de diario mojada (día 87)
6306	Página de diario mojada (día 512)
6307	Mensaje en una botella
6308	Siluro mostacherizo crudo
6309	Siluro de 8 kilos
6310	Siluro de 10 kilos
6311	Siluro de 12 kilos
6312	Corazón de Dalin
6313	Corazón de Comar
6314	Manteo de maestro de lobos
6315	Ballesta de flechas de acero
6316	Delicia de furia del Loch Modan
6317	Furia del Loch Modan crudo
6318	Bastón de Ley de Odo
6319	Faja del Cegato
6320	Blasón de Comandante
6321	Sello familiar de Filargenta
6323	Cetro del barón
6324	Togas de Arugal
6325	Receta: pececito luminoso
6326	Receta: caballa de piel escurridiza
6327	El pacificador
6328	Receta: pargo de lodo boquilargo
6329	Receta: delicia de furia de Loch Modan
6330	Receta: siluro mostacherizo
6331	Hoja aullante
6332	Anillo de perla negra
6333	Daga Azote de Pinchos
6335	Botas grisáceas
6336	Guerrera de infantería
6337	Leotardos de infantería
6338	Vara de plata
6339	Vara rúnica de plata
6340	Pellejo de Fenrus
6341	Lámpara de establo siniestra
6342	Fórmula: encantar pechera: maná menor
6343	Fórmula: imbuir pechera: espíritu
6344	Fórmula: encantar brazales: espíritu menor
6345	Fórmula: imbuir capa: protección
6346	Fórmula: encantar pechera: maná inferior
6347	Fórmula: encantar brazales: fuerza menor
6348	Fórmula: encantar arma: Destripadora de bestias menor
6349	Fórmula: encantar arma de 2M: intelecto inferior
6350	Botas de bronce férreas
6351	Cajón abollado
6352	Cajón estropeado por el agua
6353	Cofre pequeño
6354	Cofre cerrado pequeño
6355	Cofre cerrado robusto
6356	Cofre maltrecho
6357	Cajón sellado
6358	Bocanegra graso
6359	Pargo de fuego
6360	Pez de escamas de acero
6361	Atún blanco arco iris crudo
6362	Bacalao piedrescama crudo
6363	Siluro de 14 kilos
6364	Siluro de 16 kilos
6365	Caña de pescar fuerte
6366	Caña de pescar Leñoscuro
6367	Caña de pescar de hierro grande
6368	Receta: atún blanco arco iris
6369	Receta: bacalao piedrescama
6370	Aceite de bocanegra
6371	Aceite de Fuego
6372	Poción de velocidad de nado
6373	Elixir de poder de Fuego
6374	Partículas encantadas
6375	Fórmula: encantar brazales: espíritu inferior
6376	Fórmula: encantar botas: aguante menor
6377	Fórmula: encantar botas: agilidad menor
6378	Manteo de vidente
6379	Cinturón de cuero grabado
6380	Rodela grabada
6381	Capa brillante
6382	Cinturón de cuero de bosque
6383	Rodela de bosque
6384	Camisa azul con estilo
6385	Camisa verde con estilo
6386	Musleras de malla de luz trémula
6387	Brazales de malla de luz trémula
6388	Espaldares de malla de luz trémula
6389	Almófar de malla de luz trémula
6390	Patrón: camisa azul con estilo
6391	Patrón: camisa verde con estilo
6392	Cinturón de Arugal
6393	Guantes de hilo de plata
6394	Botas de hilo de plata
6395	Amito de hilo de plata
6396	Pechera blasonada
6397	Guantes blasonados
6398	Cinturón blasonado
6399	Sobrehombros blasonados
6400	Escudo de luz trémula
6401	Patrón: camisa de seda oscura
6402	Leotardos de combate de malla
6403	Guardabrazos de combate de malla
6404	Bufas de combate de malla
6405	Calzas Cielo Nocturno
6406	Botas Cielo Nocturno
6407	Muñequeras Cielo Nocturno
6408	Guantes de insignia
6409	Cinturón de insignia
6410	Brazales de insignia
6411	Armadura de brigadier
6412	Botas de brigadier
6413	Brazales de brigadier
6414	Sello de Sylvanas
6415	Toga aurora
6416	Botas aurora
6417	Capa aurora
6418	Fajín aurora
6419	Mitones con inscripciones
6420	Botas con inscripciones
6421	Cinturón con inscripciones
6422	Yelmo con inscripciones
6423	Grebas Forjanegra
6424	Manteo Forjanegra
6425	Faja Forjanegra
6426	Brazales Forjanegra
6427	Toga Escapabruma
6428	Guantes Escapabruma
6429	Sombrero de zahorí escapabruma
6430	Coraza de cuero imperial
6431	Botas de cuero imperiales
6432	Capa imperial
6433	Yelmo de cuero imperial
6435	Gema ardiente imbuida
6436	Gema ardiente
6438	Brazal elemental mate
6439	Brazal de vínculo roto
6440	Látigo cerebral
6441	Cabellera Acechasombras
6442	Cristal del oráculo
6443	Pellejo descarriado
6444	Lengua bífida
6445	Muda de piel frágil
6446	Bolsa de piel de culebra
6447	Escudo de caparazón de tortuga desgastado
6448	Punta de cola
6449	Capa de escamas de lagarto resplandeciente
6450	Venda de seda
6451	Venda de seda gruesa
6452	Contraveneno
6453	Contraveneno fuerte
6454	Manual: contraveneno fuerte
6455	Rueda de carro vieja
6456	Baba ácida
6457	Piezas de ingeniería oxidadas
6458	Pescado cubierto de aceite
6459	Botines indómitos
6460	Garra de Cobrahn
6461	Hombreras taraceadas con babosas
6462	Cajón seguro
6463	Anillo de fantasma profundo
6464	Esencia de lamentos
6465	Toga del Mocasín
6466	Capa de escamas descarriadas
6467	Guantes de escamas descarriadas
6468	Cinturón de escamas descarriadas
6469	Golpe venenoso
6470	Escama descarriada
6471	Escama descarriada perfecta
6472	Víbora hiriente
6473	Armadura del Colmillo
6474	Patrón: capa de escamas descarriadas
6475	Patrón: guantes de escamas descarriadas
6476	Patrón: cinturón de escamas descarriadas
6477	Fajín de pradera
6478	Apisonadoras de ratas
6479	Colgante Malem
6480	Leotardos descarriados escurridizos
6481	Guanteletes de Damire
6482	Botas de caminafuego
6486	Escama chamuscada
6487	Cabeza de familiar vil
6488	Tablilla simple
6489	Papiro deteriorado
6490	Papiro oscuro
6491	Papiro pesado
6492	Papiro tiznado
6493	Papiro andrajoso
6494	Papiro garabateado
6495	Papiro estropeado
6496	Papiro detallado
6497	Papiro simple
6498	Cuero de kodo grabado
6499	Cuero de kodo grabado
6500	Cuero de kodo grabado
6501	Cuero de kodo grabado
6502	Armadura de escamas violeta
6503	Togas de arlequín
6504	Espada de ala
6505	Bastón creciente
6506	Botas de infantería
6507	Brazales de infantería
6508	Capa de infantería
6509	Cinturón de infantería
6510	Guanteletes de infantería
6511	Toga de oficial
6512	Toga de discípulo
6513	Fajín de discípulo
6514	Capa de discípulo
6515	Guantes de discípulo
6516	Pergamino para invocar diablillos
6517	Cinturón de pionero
6518	Botas de pionero
6519	Brazales de pionero
6520	Capa de pionero
6521	Guantes de pionero
6522	Pez descarriado
6523	Arnés con hebillas
6524	Arnés de cuero con tachuelas
6525	Arnés de bruto
6526	Arnés de batalla
6527	Toga ancestral
6528	Toga Vinculahechizo
6529	Adorno lustroso
6530	Reptadores nocturnos
6531	Toga de paño barbárico
6532	Adornos brillantes
6533	Atraepeces acuadinámico
6534	Barras de acero forjado
6535	Tablilla de Vergua
6536	Jubón de sauce
6537	Botas de sauce
6538	Toga de sauce
6539	Cinturón de sauce
6540	Pantalones de sauce
6541	Guantes de sauce
6542	Manteo de sauce
6543	Brazales de sauce
6544	Pergamino de invocación de abisario
6545	Armadura de Soldado
6546	Leotardos de Soldado
6547	Guanteletes de Soldado
6548	Faja de Soldado
6549	Capa de Soldado
6550	Guardamuñecas de Soldado
6551	Botas de Soldado
6552	Guerrera de bardo
6553	Calzas de bardo
6554	Guantes de bardo
6555	Capa de bardo
6556	Brazales de bardo
6557	Botas de bardo
6558	Cinturón de bardo
6559	Rodela de bardo
6560	Escudo de Soldado
6561	Armadura acolchada de vidente
6562	Botas fulgurantes
6563	Brazales fulgurantes
6564	Capa fulgurante
6565	Guantes fulgurantes
6566	Amito fulgurante
6567	Armadura fulgurante
6568	Calzas fulgurantes
6569	Toga fulgurante
6570	Fajín fulgurante
6571	Rodela de exploración
6572	Escudo defensor
6573	Botas defensoras
6574	Brazales defensores
6575	Capa defensora
6576	Faja defensora
6577	Guanteletes defensores
6578	Leotardos defensores
6579	Bufas defensoras
6580	Guerrera del defensor
6581	Cinturón de exploración
6582	Botas de exploración
6583	Brazales de exploración
6584	Guerrera de exploración
6585	Capa de exploración
6586	Guantes de exploración
6587	Calzas de exploración
6588	Bufas de exploración
6589	Sortija viridiana
6590	Botas Forjabatalla
6591	Guardamuñecas Forjabatalla
6592	Armadura Forjabatalla
6593	Capa Forjabatalla
6594	Faja Forjabatalla
6595	Guanteletes Forjabatalla
6596	Musleras Forjabatalla
6597	Guardahombros Forjabatalla
6598	Rodela Derviche
6599	Escudo Forjabatalla
6600	Cinturón Derviche
6601	Botas Derviche
6602	Brazales Derviche
6603	Guerrera Derviche
6604	Manteo Derviche
6605	Guantes Derviche
6607	Leotardos Derviche
6608	Armadura brillante
6609	Paño de sabio
6610	Toga de sabio
6611	Fajín de sabio
6612	Botas de sabio
6613	Brazales de sabio
6614	Capa de sabio
6615	Guantes de sabio
6616	Pantalones de sabio
6617	Manto de sabio
6619	Manual: el camino de la defensa
6620	Papiro elaborado
6621	Manual de Provocación
6622	Espada de fanatismo
6623	Pergamino para invocar a Súcubo
6624	Jarabe de Ken'zigla
6625	Colgante cubierto de tierra
6626	Colgante de Dogran
6627	Coraza de escama mutante
6628	Garras del Cuervo
6629	Manteo esporidio
6630	Rodela de nube de semillas
6631	Raíz viva
6632	Capa de escama Fey
6633	Cercenadora de carnicero
6634	Ungüento de ritual
6635	Sapta de tierra
6636	Sapta de fuego
6637	Sapta de agua
6638	Sapta de aire
6640	Pezuña de acechador vil
6641	Hoja inquietante
6642	Armadura fantasma
6643	Pececito hinchado
6644	Caballa hinchada
6645	Pargo de lodo hinchado
6646	Atún hinchado
6647	Siluro hinchado
6648	Pergamino de Tótem Piel de piedra
6649	Pergamino de Tótem abrasador
6650	Pergamino de Tótem Corriente de sanación
6651	Botella de vino rota
6652	Faltriquera de componentes
6653	Antorcha de la Llama Latente
6654	Antorcha de la Llama eterna
6655	Ascua resplandeciente
6656	Cuarzo en bruto
6657	Delicia de pez descarriado sabrosa
6658	Collar de muestra
6659	Calzas escarabajo
6660	Daga de Julie
6661	Receta: delicia de pez descarriado sabrosa
6662	Elixir de crecimiento gigante
6663	Receta: elixir de crecimiento gigante
6664	Manto vudú
6665	Brazales embrujados
6666	Botas deslizantes
6667	Capa de ingeniero
6668	Botas de dibujante
6669	Sortija sacra
6670	Armadura de pantera
6671	Leotardos de gigante
6672	Esquema: bomba cegadora
6675	Brazales templados
6676	Rodela de agente
6677	Varita de artesano de hechizos
6678	Sortija de Gracia élfica
6679	Perforador de armaduras
6681	Pincho de espinas
6682	Togas del portavoz de la muerte
6684	Vara de mando de husmeador
6685	Manto del portavoz de la muerte
6686	Yelmo con colmillo
6687	Creacadáveres
6688	Ornato Susurravientos
6689	Bastón de espíritu del viento
6690	Leotardos de Ferine
6691	Corvo de Colmillosucio
6692	Espetadora en punta
6693	Garra de Agamaggan
6694	Corazón de Agamaggan
6695	Amuleto de hueso estigio
6696	Arco de acechador nocturno
6697	Manto de ala de murciélago
6698	Piedra de Pierce
6707	Piedra de Lapidis
6708	Piedra de Buenhombre
6709	Jubón resplandor lunar
6710	Patrón: jubón resplandor lunar
6711	Piedra de Kurtz
6712	Cerradura de prácticas
6713	Pantalones rasgados
6714	Dinamita para tontos
6715	Desfibriladores estropeados
6716	Esquema: dinamita para tontos
6717	Mecanismo eléctrico
6718	Electromuelle
6719	Cinturón Natoviento
6720	Ornato de espíritu cazador
6721	Peto de Kor
6722	Esposas bestiales
6723	Medalla de Coraje
6724	Piedra de Backus
6725	Rodela de mármol
6726	Cinturón personalizado de Razzeric
6727	Mandiletes de competición de Razzeric
6728	Piedra de Brownell
6729	Encendedor vigoroso de Fizzle
6730	Cota de malla de Forjaz
6731	Coraza de Forjaz
6732	Guantes de mecánico gnómico
6733	Guanteletes de Forjaz
6734	Diseño: cadena de Forjaz
6735	Diseño: coraza de Forjaz
6736	Diseño: guanteletes de Forjaz
6737	Pantalones de hojas secas
6738	Hacha curva sangrante
6739	Objetivo de Abiscorredor
6740	Fajín azur
6741	Espada de guerra orca
6742	Faja Puño de piedra
6743	Anillo de apoyo
6744	Guantes de Kapelan
6745	Manteo Correpresto
6746	Rodela de basalto
6747	Espaldares Déspota
6748	Anillo de mono
6749	Sortija de tigre
6750	Aro de culebra
6751	Chal de luto
6752	Botas de lancero
6753	Talismán de plumas
6754	Monedero grande
6755	Un pequeño contenedor de gemas
6756	Joyero
6757	Sello de Jaina
6766	Flayed Demon Skin (old2)
6767	Colgante de Tyranis
6773	Cota de malla de maleante Gelkis
6774	Dedo de Uthek
6775	Escrito sobre divinidad
6776	Escrito sobre Valor
6777	Escrito sobre Rectitud
6778	Escrito sobre Justicia
6779	Escrito sobre Nobleza
6780	Fajín lila
6781	Jarra de Bartleby
6782	Distintivo del mariscal Haggard
6783	Llave de Dentomuerto
6784	Manoplas con abrazaderas
6785	Poderes del Vacío
6786	Vestido sencillo
6787	Vestido de lana blanco
6788	Cinturón de cazador Magram
6789	Manta ceremonial de centauro
6790	Anillo de Calma
6791	Botas de demonio
6792	Espaldares sanguinos
6793	Brazales áuricos
6794	Guanteletes Tempesfuego
6795	Camisa de espadachín blanca
6796	Camisa de espadachín roja
6797	Saltaojos
6798	Arcabuz explosivo
6799	Cabeza de Vejrek
6800	Mena umbría
6801	Mandil barroco
6802	Espada de Augurio
6803	Caña profética
6804	Martillo tormenta de viento
6805	Cuerno de Vorlus
6806	Llama danzarina
6807	Estofado de anca de rana
6808	Mena de elunita
6809	Medallón de Elura
6810	Gargantilla de Surena
6811	Lente de pez acuadinámica
6812	Caja de elunita
6826	Escama luminosa
6827	Caja de suministros
6828	Rodela visionaria
6829	Espada de Serenidad
6830	Masticahuesos
6831	Amenaza negra
6832	Capa de Añublo
6833	Camisa de esmoquin blanca
6834	Esmoquin negro
6835	Pantalones de esmoquin negro
6836	Zapatos para vestido
6837	Vestido de boda
6838	Colmillo de araña agostado
6839	Cuerno carbonizado
6840	Cuerno galvanizado
6841	Vial de flogisto
6842	Instrucciones de Furen
6843	Tonel de brebaje
6844	Sangre ardiente
6845	Roca ardiente
6846	Misiva Defias
6847	Misiva Hierro Negro
6848	Coral abrasador
6849	Cáscara asolada
6850	Cabellera Sangrapellejo
6851	Esencia del exilio
6852	Ojo eterno
6866	Símbolo de la vida
6887	Serviola moteada
6888	Huevo a las finas hierbas
6889	Huevo pequeño
6890	Carne de oso ahumada
6891	Receta: huevo a las finas hierbas
6892	Receta: carne de oso ahumada
6893	Llave de taller
6894	Corazón de espirálico
6895	Martillo de herrería de Jordan
6897	Manual: camino del rabioso
6898	Orbe de Soran'ruk
6899	Orbe de brujo 35
6900	Toga de sangre dorada encantada
6901	Manteo de trillador resplandeciente
6902	Braciles de Serra'kis
6903	Pantalones de soñador de mirada
6904	Mordisco de Serra'kis
6905	Hacha arrecife
6906	Puños de algas
6907	Armadura tortuga
6908	Vínculo de Ghamoo-ra
6909	Golpe de la hidra
6910	Pantalones de sanguijuela
6911	Cincho musgoso
6912	Duramen
6913	Núcleo de duramen
6914	Trozo Soran'ruk
6915	Trozo de Soran'ruk grande
6916	Escrito sobre divinidad
6926	Notas de Furen
6927	Oreja de Will el Grande
6928	Gargantilla de sangrita
6929	Papiro de Bath'rah
6930	Vara de mediación
6931	Escrito mohoso
6947	Veneno instantáneo
6948	Piedra de hogar
6949	Veneno instantáneo II
6950	Veneno instantáneo III
6951	Veneno de aturdimiento mental II
6952	Pelaje de oso grueso
6953	Puño de Verigan
6966	Hacha elunita
6967	Espada elunita
6968	Martillo elunita
6969	Daga elunita
6970	Favor de Furen
6971	Almófar endurecido con fuego
6972	Camisote endurecido con fuego
6973	Leotardos endurecidos con fuego
6974	Guanteletes endurecidos con fuego
6975	Hacha espirálica
6976	Martillo de guerra espirálico
6977	Espada espirálica
6978	Hacha umbría
6979	Hacha de Haggard
6980	Daga de Haggard
6981	Daga umbría
6982	Maza umbría
6983	Martillo de Haggard
6984	Espada umbría
6985	Espada de Haggard
6986	Loto carmesí
6987	Escama de pescado
6988	Pergamino para invocar manáfagos
6989	Vial de sangre de odio feroz
6990	Piedra infernal inferior
6991	Carbón humeante
6992	Envío de mena de Jordan
6993	Envío de mena refinada de Jordan
6994	Madera de roble de Piedrablanca
6995	Gema kor corrupta
6996	Apuntes sobre armas de Jordan
6997	Manuscrito andrajoso
6998	Botas Nimbus
6999	Libro del conciliábulo
7000	Faja de duramen
7001	Cetro de lápida
7002	Rodela ártica
7003	Broches de alfazaques
7004	Manteo de prelación
7005	Cuchillo para desollar
7006	Escrito reconstruido
7007	Equipamiento de élite de Backus
7026	Cinturón de lino
7027	Botas de oscuridad
7046	Pantalones de seda azur
7047	Manos de oscuridad
7048	Caperuza de seda azur
7049	Guantes de fe verdadera
7050	Cinta de seda
7051	Jubón terráneo
7052	Cinturón de seda azur
7053	Capa de seda azur
7054	Toga de poder
7055	Cinturón de seda carmesí
7056	Capa de seda carmesí
7057	Sobrehombros de seda verdes
7058	Jubón de seda carmesí
7059	Sobrehombros de seda carmesíes
7060	Sobrehombros azur
7061	Cinturón de seda terránea
7062	Bombachos de seda carmesíes
7063	Toga de seda carmesí
7064	Guantes de seda carmesíes
7065	Armadura de seda verde
7067	Tierra elemental
7068	Fuego elemental
7069	Aire elemental
7070	Agua elemental
7071	Hebilla de hierro
7072	Escama naga
7073	Colmillo roto
7074	Garra astillada
7075	Núcleo de tierra
7076	Esencia de tierra
7077	Corazón de fuego
7078	Esencia de Fuego
7079	Globo de agua
7080	Esencia de agua
7081	Aliento de viento
7082	Esencia de aire
7083	Gema kor purificada
7084	Patrón: sobrehombros de seda carmesíes
7085	Patrón: sobrehombros azur
7086	Patrón: cinturón de seda terránea
7087	Patrón: capa de seda carmesí
7088	Patrón: toga de seda carmesí
7089	Patrón: capa de seda azur
7090	Patrón: armadura de seda verde
7091	Patrón: guantes de fe verdadera
7092	Patrón: manos de oscuridad
7093	Patrón: botas de oscuridad
7094	Rama de madera a la deriva
7095	Botas de ciénaga
7096	Pluma arrancada
7097	Carne de pata
7098	Colmillo astillado
7099	Pinza cortada
7100	Icor pegajoso
7101	Ojo de insecto
7106	Guantes del zodíaco
7107	Cinturón de las Estrellas
7108	Escudo de infantería
7109	Rodela de pionero
7110	Armadura de hilo de plata
7111	Armadura Cielo Nocturno
7112	Armadura Aurora
7113	Armadura Escapabruma
7114	Patrón: guantes de seda azur
7115	Hacha reliquia
7116	Daga reliquia
7117	Martillo reliquia
7118	Espada reliquia
7119	Antena agitada
7120	Bastión de Ruga
7126	Lingote de hierro humeante
7127	Azurita en polvo
7128	Pezuña de sátiro sin rajar
7129	Guanteletes brutales
7130	Yelmo brutal
7131	Tibia de Faucedraco
7132	Musleras brutales
7133	Camisote brutal
7134	Tibia de Faucedraco robusta
7135	Tibia de Faucedraco rota
7146	La llave Escarlata
7148	Desfibriladores goblin
7166	Daga de cobre
7170	Espada aleatoria de Oposti FOO
7187	Botas de VanCleef
7188	Escudo de guardia de Ventormenta
7189	Botas cohete goblin
7190	Botas cohete agostadas
7191	Cableado de fusibles
7192	Esquema: botas cohete goblin
7206	Muestra de agua del Lago Espejo
7207	Frasco de Jennea
7208	Llave de Tazan
7209	Cartera de Tazan
7226	Trastónitor maguitronic
7227	Bocas de dragón de Balnir
7228	Helado de fresa de Tigule
7229	Jubón de expedicionario
7230	Martillo poderoso de acometida
7231	Carta de presentación de Astor
7247	Cofre de arcas de contención
7249	Gema cargada de la falla
7266	Tratado de Ur sobre la magia de las Sombras
7267	Seda prístina de araña
7268	Muestra de agua Xavian
7269	Frasco de Deino
7270	Cabello de la Hermana sonriente
7271	Colmillo de marfil impecable
7272	Zarza electrificada
7273	Palo totémico Secacorteza
7274	Rituales de Poder
7275	Los pergaminos de Agamaggan
7276	Capa de cuero cosida a mano
7277	Brazales de cuero cosidos a mano
7278	Carcaj de cuero ligero
7279	Faltriquera de munición de cuero pequeña
7280	Pantalones de cuero basto
7281	Brazales de cuero ligero
7282	Pantalones de cuero ligero
7283	Capa de cría negra
7284	Guantes de cría roja
7285	Guantes de cuero livianos
7286	Escama de cría negra
7287	Escama de cría roja
7288	Patrón: pantalones de cuero basto
7289	Patrón: capa de cría negra
7290	Patrón: guantes de cría roja
7291	Orbe infernal
7292	Arca de contención llena
7293	Gema de maná de Dalaran
7294	Libro de contabilidad de Andron
7295	Cuaderno de Tazan
7296	Antorcha apagada
7297	Pesadilla de Morbent
7298	Hoja de astucia
7306	Cabeza de Fenwick
7307	Gusano carnívoro
7308	Canto de manifestación
7309	Informe de estado de Dalaran
7326	Hacha de Thun'grim
7327	Daga de Thun'grim
7328	Maza de Thun'grim
7329	Espada de Thun'grim
7330	Rodela de infiltrado
7331	Escudo Falange
7332	Armadura regia
7333	Silbato de sobrestante
7334	Toga de floración
7335	Guerrera de oso pardo
7336	Cota de malla de madera salvaje
7337	La roca
7338	Anillo de ánimo
7339	Anillo con diamante minúsculo
7340	Solitario de diamante impecable
7341	Anillo con cubo de circonio
7342	Sortija de plata de Piffeny
7343	Llave inglesa de Bingles
7344	Antorcha de la llama sagrada
7345	Destornillador de Bingles
7346	Martillo de Bingles
7347	Inversor de piñón de Bingles
7348	Guantes de flechero
7349	Guantes de herborista
7350	Brazales de discípulo
7351	Botas de discípulo
7352	Sobrehombros de cuero terráneo
7353	Armadura acolchada de anciano
7354	Botas de anciano
7355	Brazales de anciano
7356	Capa de anciano
7357	Sombrero de anciano
7358	Guantes de ratero
7359	Guantes terráneos gruesos
7360	Patrón: guantes de cuero oscuro
7361	Patrón: guantes de herborista
7362	Patrón: sobrehombros de cuero terráneo
7363	Patrón: guantes de ratero
7364	Patrón: guantes terráneos gruesos
7365	Dentrituradora goblin
7366	Guantes de anciano
7367	Manto de anciano
7368	Pantalones de anciano
7369	Toga de anciano
7370	Fajín de anciano
7371	Carcaj pesado
7372	Faltriquera para munición de cuero pesado
7373	Leotardos de cuero oscurecido
7374	Armadura de cuero oscurecido
7375	Armadura de cría verde
7376	Cartucho de Bingles
7377	Capa de cuero de Escarcha
7378	Brazales oscurecidos
7386	Brazales de cría verde
7387	Cinturón oscurecido
7388	Llave calavera
7389	Libro de contabilidad de Ventura y Cía.
7390	Botas oscurecidas
7391	Botas prestas
7392	Escama de cría verde
7406	Cordón de infiltrado
7407	Armadura de infiltrado
7408	Sobrehombros de infiltrado
7409	Botas de infiltrado
7410	Brazales de infiltrado
7411	Capa de espía
7412	Guantes de infiltrado
7413	Gorro de infiltrado
7414	Pantalones de infiltrado
7415	Bufas Derviche
7416	Brazales Falange
7417	Botas Falange
7418	Coraza Falange
7419	Capa Falange
7420	Protegecabezas Falange
7421	Guanteletes Falange
7422	Faja Falange
7423	Leotardos Falange
7424	Bufas Falange
7425	Cabeza de Cyrik
7426	Anillo cerúleo
7427	Dije cerúleo
7428	Pellejo de gato de las Sombras
7429	Armadura Crepuscular
7430	Toga Crepuscular
7431	Pantalones Crepusculares
7432	Capucha Crepuscular
7433	Guantes Crepusculares
7434	Botas Crepusculares
7435	Manto Crepuscular
7436	Manteo Crepuscular
7437	Puños Crepusculares
7438	Cinturón Crepuscular
7439	Coraza de centinela
7440	Calzas de centinela
7441	Gorro de centinela
7442	Llave de Gyromast
7443	Guantes de centinela
7444	Botas de centinela
7445	Sobrehombros de centinela
7446	Capa de centinela
7447	Brazales de centinela
7448	Faja de centinela
7449	Patrón: leotardos de cuero oscurecido
7450	Patrón: armadura de cría verde
7451	Patrón: brazales de cría verde
7452	Patrón: botas oscurecidas
7453	Patrón: botas prestas
7454	Coraza de Caballero
7455	Musleras de Caballero
7456	Protegecabezas de Caballero
7457	Guanteletes de Caballero
7458	Botas de Caballero
7459	Espaldares de Caballero
7460	Capa de Caballero
7461	Brazales de Caballero
7462	Faja de Caballero
7463	Rodela de centinela
7464	Glifos de Invocación
7465	Blasón de Caballero
7466	Sortija bermellón
7467	Collar bermellón
7468	Toga regia
7469	Leotardos regios
7470	Sombrero de zahorí regio
7471	Guantes regios
7472	Botas regias
7473	Manto regio
7474	Capa regia
7475	Puños regios
7476	Fajín regio
7477	Guerrera de forestal
7478	Leotardos de forestal
7479	Yelmo de forestal
7480	Guantes de forestal
7481	Botas de forestal
7482	Sobrehombros de forestal
7483	Capa de forestal
7484	Guardamuñecas de forestal
7485	Cordón de forestal
7486	Coraza de capitán
7487	Leotardos de capitán
7488	Aro de capitán
7489	Guanteletes de capitán
7490	Botas de capitán
7491	Guardahombros de capitán
7492	Capa de capitán
7493	Brazales de capitán
7494	Guardarrenes de capitán
7495	Rodela de capitán
7496	Escudo de placas de campo
7497	Sortija de marfil
7498	Parte superior de la llave de Gelkak
7499	Mitad de la llave de Gelkak
7500	Parte inferior de la llave de Gelkak
7506	Mando universal gnómico
7507	Orbe Arcano
7508	Orbe Ley
7509	Toga Tejemaná
7510	Togas de fuego de hechizo inferior
7511	Toga de nudos astral
7512	Toga de encaje abisal
7513	Varita Ira Ardiente
7514	Varita Furia de Hielo
7515	Orbe celestial
7516	Instrucciones de Tabetha
7517	Guerrera delicada
7518	Toga delicada
7519	Pantalones delicados
7520	Celada delicada
7521	Guantes delicados
7522	Botas delicadas
7523	Hombreras delicadas
7524	Manteo delicado
7525	Brazales delicados
7526	Cinturón delicado
7527	Pechera de cabalista
7528	Leotardos de cabalista
7529	Yelmo de cabalista
7530	Guantes de cabalista
7531	Botas de cabalista
7532	Bufas de cabalista
7533	Capa de cabalista
7534	Brazales de cabalista
7535	Cinturón de cabalista
7536	Escudo de pared de Campeón
7537	Escudo gótico
7538	Armadura de Campeón
7539	Leotardos de Campeón
7540	Casco de Campeón
7541	Guanteletes de Campeón
7542	Grebas de Campeón
7543	Espaldares de Campeón
7544	Manteo de Campeón
7545	Brazales de Campeón
7546	Faja de Campeón
7547	Anillo de ónice
7548	Gargantilla de ónice
7549	Abrazo de hada
7550	Honor de guerrero
7551	Dije opalino entrelazado
7552	Percha de halcón
7553	Sortija del Unicornio
7554	Rama de sauce
7555	Estrella regia
7556	Orbe Crepuscular
7557	Vara delicada
7558	Báculo fulgurante
7559	Caña rúnica
7560	Esquema: mando universal gnómico
7561	Esquema: desfibriladores goblin
7566	Espada de la familia de Agamand
7567	Hacha de la familia de Agamand
7568	Daga de la familia de Agamand
7569	Maza de la familia de Agamand
7586	Esperanza de Tharnariun
7587	Instrucciones de Thun'grim
7606	Guanteletes polares
7607	Varita de dientes de sable
7608	Jarra de vidente de gran calidad
7609	Báculo de ámbar de anciano
7610	Esfera aurora
7611	Báculo Escapabruma
7613	Patrón: armadura de cuero verde
7626	Fardo de pelajes
7627	Paquete de Dolanaar
7628	Carta anodina
7629	Carga de Ukor
7646	Cajón de suministros del mesón
7666	Collar destrozado
7667	Ampolla de visión de Talvash
7668	Diario manchado de sangre
7669	Rubí del collar destrozado
7670	Zafiro del collar destrozado
7671	Topacio del collar destrozado
7672	Fuente de alimentación del collar destrozado
7673	Collar de mejoría de Talvash
7674	Envío a Mathias
7675	Calendario de envíos Defias
7676	Té de cardo
7678	Receta: té de cardo
7679	Colmillo de alcaudociélago
7680	Escama de basilisco Dorsaljade
7681	Fragmento de gólem de obsidiana
7682	Atizador de tortura
7683	Nudillos de latón sangrientos
7684	Manto de mago sangriento
7685	Orbe del vidente olvidado
7686	Ojo de Dorsacerado
7687	Puño de Dorsacerado
7688	Caja torácica de Dorsacerado
7689	Amanecer mórbido
7690	Torno de ébano
7691	Embozo embalsamado
7708	Varita necrótica
7709	Leotardos contagiados
7710	Varita de entrenamiento de Loksey
7711	Toga de Doan
7712	Manto de Doan
7713	Vara ilusionaria
7714	Hoja hipnótica
7715	Informe de Onin
7716	Collar destrozado
7717	Devastador
7718	Sobrehombro de Herod
7719	Yelmo de rabioso enfurecido
7720	Sombrero de Melenablanca
7721	Mano de Rectitud
7722	Amuleto Triune
7723	Poderío de Mograine
7724	Guanteletes de divinidad
7726	Égida del Comandante Escarlata
7727	Espaldares de velador
7728	Togas de cautivador
7729	Mosquete Chesterfall
7730	Triturador de cobalto
7731	Dije de fragmento fantasmal
7733	Bastón de Prehistoria
7734	Bolsa de seis demonios
7735	Rosa de Jannok
7736	Garrote de lucha
7737	Diario de Sethir
7738	Guantes siempreverde
7739	Manteo de madera
7740	Medallón de Gni'kiv
7741	El bastón de Tsol
7742	Esquema: aparato de invisibilidad gnómico
7746	Mención de honor de la Liga de Expedicionarios
7747	Protector vil
7748	Rodela piedra de fuerza
7749	Orbe omega
7750	Manto de Tragedia
7751	Botas de Vorrel
7752	Destripador de sueños
7753	Derramasangre
7754	Botas de presagista
7755	Sobrehombros pedernal
7756	Guantes de adiestramiento de perros
7757	Bastón Tejevientos
7758	Chafarote despiadado
7759	Pechera de arconte
7760	Falda de Jefe de Guerra
7761	Espetadora Garra de acero
7766	Odre de agua marrón vacío
7767	Odre de agua azul vacío
7768	Odre de agua rojo vacío
7769	Odre de agua marrón lleno
7770	Odre de agua azul lleno
7771	Odre de agua rojo lleno
7786	Partecabezas
7787	Guardián rutilante
7806	Chupachús
7807	Chocolatina
7808	Onza de chocolate
7809	Vestido de Pascua
7810	Vial de agua pura
7811	Gotas que quedan del agua más pura
7812	Brazales de manifestación corrupta
7813	Fragmento de Agua
7846	Colmillo de coyote del risco
7847	Molleja de águila ratonera
7848	Fragmento de elemental de roca
7866	Vasija de taumaturgia vacía
7867	Vasija de sangre de dragón
7868	Thieven' Kit
7869	Arcón de Lucius
7870	Arcón de vasijas de taumaturgia
7871	Muestra de robo
7872	Útiles de ladrón herrumbrados
7886	Diario sin traducir
7887	Collar y gema recuperados
7888	Collar de mejora de Jarkal
7906	Cuernos de Nez'ra
7907	Certificado de Ratería
7908	Diario de Klaven Mortoalerta
7909	Aguamarina
7910	Rubí estrella
7911	Mena de veraplata
7912	Piedra sólida
7913	Sobrehombros barbáricos de hierro
7914	Coraza barbárica de hierro
7915	Yelmo barbárico de hierro
7916	Botas barbáricas de hierro
7917	Guantes barbáricos de hierro
7918	Sobrehombros de mitril pesado
7919	Guanteletes de mitril pesado
7920	Pantalones de escamas de mitril
7921	Pantalones de mitril pesado
7922	Yelmo de placas de acero
7923	Llave de la torre Defias
7924	Brazales de escamas de mitril
7925	Guantes de escamas de mitril
7926	Pantalones de mitril ornamentado
7927	Guantes de mitril ornamentado
7928	Sobrehombros de mitril ornamentado
7929	Leotardos de guerra orcos
7930	Coraza de mitril pesado
7931	Almófar de mitril
7932	Sobrehombros de escamas de mitril
7933	Botas de mitril pesado
7934	Yelmo de mitril pesado
7935	Coraza de mitril ornamentado
7936	Botas de mitril ornamentado
7937	Yelmo de mitril ornamentado
7938	Guanteletes de veraplata
7939	Coraza de veraplata
7941	Hacha de mitril pesado
7942	Hacha azul relumbrante
7943	Espada de mitril maligna
7944	Estoque de mitril deslumbrante
7945	Maza negra grande
7946	Martillo rúnico de mitril
7947	Chafarote de ébano
7948	Faja de Thero-shan
7949	Leotardos de Thero-shan
7950	Armadura de Thero-shan
7951	Manos de Thero-shan
7952	Botas de Thero-shan
7953	Máscara de Thero-shan
7954	El Despedazador
7955	Mandoble de cobre
7956	Martillo de guerra de bronce
7957	Espada magna de bronce
7958	Hacha de batalla de bronce
7959	Añublo
7960	Campeón de veraplata
7961	Hoja fantasma
7963	Coraza de acero
7964	Piedra de afilar sólida
7965	Contrapeso sólido
7966	Piedra de pulir sólida
7967	Punta de escudo de mitril
7968	Tesoro de los Mares del Sur
7969	Espuelas de mitril
7970	G.E.A.Q.
7971	Perla negra
7972	Icor de no-muerto
7973	Almeja de boca grande
7974	Carne de almeja sabrosa
7975	Diseño: pantalones de mitril pesado
7976	Diseño: punta de escudo de mitril
7977	Diseño: guantes de escamas de mitril
7978	Diseño: sobrehombros barbáricos de hierro
7979	Diseño: coraza barbárica de hierro
7980	Diseño: yelmo barbárico de hierro
7981	Diseño: botas barbáricas de hierro
7982	Diseño: guantes barbáricos de hierro
7983	Diseño: pantalones de mitril ornamentado
7984	Diseño: guantes de mitril ornamentado
7985	Diseño: sobrehombros de mitril ornamentado
7986	Diseño: coraza de mitril ornamentado
7987	Diseño: yelmo de mitril ornamentado
7988	Diseño: botas de mitril ornamentado
7989	Diseño: espuelas de mitril
7990	Diseño: yelmo de mitril pesado
7991	Diseño: sobrehombros de escamas de mitril
7992	Diseño: hacha azul relumbrante
7993	Diseño: estoque de mitril deslumbrante
7994	Diseño: leotardos de guerra orcos
7995	Diseño: brazales de escamas de mitril
7996	Sombrero de pesca desgastado
7997	Máscara de Defias roja
8006	El Cachetero
8007	Citrino de maná
8008	Rubí de maná
8009	Piedra de energía de dentrio
8026	Tesoro de la familia Garrett
8027	Tesoro de Krom Brazorrecio
8028	Diseño: martillo rúnico de mitril
8029	Diseño: hoja de mitril maligna
8030	Diseño: chafarote de ébano
8046	Diario de Kearnen
8047	Seta magenta
8048	Atrapasueños esmeralda
8049	Collar Tuercepinos
8050	Joya de Tallonkai
8051	Pistola de bengalas
8052	Piedra de energía An'Alleum
8053	Fuente de poder obsidiana
8066	Silbato de Fizzule
8067	Proyectil artesanal ligero
8068	Proyectil artesanal pesado
8069	Proyectil artesanal sólido
8070	Vale de recompensa
8071	Palo de fritura
8072	Llave de la torre de Silixiz
8073	Carretilla de mezcla modificada de Zanzil
8074	Cabeza de Gallywix
8075	Pan de masa fermentada mágica
8076	Bollo dulce mágico
8077	Agua mineral mágica
8078	Agua con gas mágica
8079	Agua cristalina mágica
8080	Pechera de placas ligeras
8081	Cinturón de placas ligeras
8082	Botas de placas ligeras
8083	Brazales de placas ligeras
8084	Guantes de placas ligeras
8085	Pantalones de placas ligeras
8086	Hombreras de placas ligeras
8087	Muestra de mezcla alterada de Zanzil
8088	Cinturón de malla de placas
8089	Botas de malla de placas
8090	Brazales de malla de placas
8091	Guantes de malla de placas
8092	Yelmo de malla de placas
8093	Leotardos de malla de placas
8094	Armadura de malla de placas
8095	Aceite de Hinott
8106	Armadura invernal
8107	Botas invernales
8108	Brazales invernales
8109	Capa invernal
8110	Guantes invernales
8111	Manto invernal
8112	Pantalones invernales
8113	Toga invernal
8114	Fajín invernal
8115	Capucha invernal
8116	Cinturón heráldico
8117	Botas heráldicas
8118	Brazales heráldicos
8119	Coraza heráldica
8120	Capa heráldica
8121	Guantes heráldicos
8122	Celada heráldica
8123	Leotardos heráldicos
8124	Bufas heráldicas
8125	Brazales de mirmidón
8126	Coraza de mirmidón
8127	Manteo de mirmidón
8128	Guanteletes de mirmidón
8129	Faja de mirmidón
8130	Grebas de mirmidón
8131	Yelmo de mirmidón
8132	Leotardos de mirmidón
8133	Espaldares de mirmidón
8134	Defensor de mirmidón
8135	Escudo de cromita
8136	Tumor gigantesco
8137	Brazales de cromita
8138	Peto de cromita
8139	Guanteletes de cromita
8140	Faja de cromita
8141	Grebas de cromita
8142	Barbuta de cromita
8143	Quijotes de cromita
8144	Espaldares de cromita
8146	Garra maligna
8147	Llave pequeña de cobre
8148	Llave de plata diminuta
8149	Talismán vudú
8150	Sal de roca
8151	Frasco de mojo
8152	Frasco de gran mojo
8153	Atriplex salvaje
8154	Escama de escórpido
8155	Sacrificio de Sathrah
8156	Guardamuñecas de ajustador
8157	Peto de ajustador
8158	Guanteletes de ajustador
8159	Faja de ajustador
8160	Grebas de ajustador
8161	Visor de ajustador
8162	Quijotes de ajustador
8163	Espaldares de ajustador
8165	Dragontina desgastada
8167	Escama de tortuga
8168	Pluma negro azabache
8169	Pellejo grueso
8170	Cuero basto
8171	Pellejo basto
8172	Pellejo grueso curtido
8173	Refuerzo para armadura grueso
8174	Sombrero de cuero cómodo
8175	Guerrera Nochefugaz
8176	Cinta Nochefugaz
8177	Espada de prácticas
8178	Espada de instrucción
8179	Arco de cadete
8180	Arco de caza
8181	Rifle de caza
8182	Rifle de perdigones
8183	Arco de precisión
8184	Encendedor
8185	Leotardos de escamas de tortuga
8186	Varita funesta
8187	Guantes de escamas de tortuga
8188	Escopeta explosiva
8189	Coraza de escamas de tortuga
8190	Espada Hanzo
8191	Yelmo de escamas de tortuga
8192	Sobrehombros Nochefugaz
8193	Pantalones Nochefugaz
8194	Cascanueces goblin
8195	Capa Nochefugaz
8196	Cimitarra de ébano
8197	Botas Nochefugaz
8198	Brazales de escamas de tortuga
8199	Destructora de campo de batalla
8200	Toga de gran vudú
8201	Máscara de gran vudú
8202	Pantalones de gran vudú
8203	Coraza de escórpido resistente
8204	Guantes de escórpido resistentes
8205	Brazales de escórpido resistentes
8206	Leotardos de escórpido resistentes
8207	Sobrehombros de escórpido resistentes
8208	Yelmo de escórpido resistente
8209	Botas de escórpido resistentes
8210	Sobrehombros de cuero salvaje
8211	Jubón de cuero salvaje
8212	Leotardos de cuero salvaje
8213	Botas de cuero salvaje
8214	Casco de cuero salvaje
8215	Capa de cuero salvaje
8216	Capa de gran vudú
8217	Carcaj rápido
8218	Faltriquera de munición de cuero grueso
8223	Hoja del basilisco
8224	Destripador de silítido
8225	Perforadora corrupta
8226	El Carnicero
8243	Chuchería de Scooby
8244	Esfera draenetista perfecta
8245	Guerrera imperial roja
8246	Botas rojas imperiales
8247	Brazales rojos imperiales
8248	Capa roja imperial
8249	Guantes rojos imperiales
8250	Manto rojo imperial
8251	Pantalones rojos imperiales
8252	Toga imperial roja
8253	Fajín imperial rojo
8254	Aro rojo imperial
8255	Faja de piel de serpiente
8256	Botas de piel de serpiente
8257	Brazales de piel de serpiente
8258	Armadura de piel de serpiente
8259	Capa de piel de serpiente
8260	Guantes de piel de serpiente
8261	Yelmo de piel de serpiente
8262	Leotardos de piel de serpiente
8263	Bufas de piel de serpiente
8264	Guardamuñecas Fuerte ébano
8265	Armadura Fuerte ébano
8266	Capa Fuerte ébano
8267	Guanteletes Fuerte ébano
8268	Faja Fuerte ébano
8269	Botas Fuerte ébano
8270	Casco Fuerte ébano
8271	Leotardos Fuerte ébano
8272	Hombreras Fuerte ébano
8273	Guardamuñecas valerosos
8274	Coselete valeroso
8275	Rodela Fuerte ébano
8276	Guanteletes valerosos
8277	Faja valerosa
8278	Grebas valerosas
8279	Yelmo valeroso
8280	Musleras valerosas
8281	Espaldares valerosos
8282	Escudo valeroso
8283	Armadura Arcana
8284	Botas Arcanas
8285	Braciles Arcanos
8286	Capa Arcana
8287	Guantes Arcanos
8288	Protectores Arcanos
8289	Leotardos Arcanos
8290	Toga Arcana
8291	Fajín Arcano
8292	Sombrero Arcano
8293	Cinturón de viajero
8294	Botas de viajero
8295	Brazales de viajero
8296	Chaleco de viajero
8297	Capa de viajero
8298	Guantes de viajero
8299	Yelmo de viajero
8300	Leotardos de viajero
8301	Bufas de viajero
8302	Brazales de héroe
8303	Coraza de héroe
8304	Manteo de héroe
8305	Guanteletes de héroe
8306	Cinturón de héroe
8307	Botas de héroe
8308	Banda de héroe
8309	Leotardos de héroe
8310	Espaldares de héroe
8311	Avambrazos de placas de alabastro
8312	Coraza de alabastro
8313	Rodela de héroe
8314	Guanteletes de placas de alabastro
8315	Faja de placas de alabastro
8316	Grebas de placas de alabastro
8317	Casco de placas de alabastro
8318	Leotardos de placas de alabastro
8319	Espaldares de placas de alabastro
8320	Escudo de alabastro
8343	Hilo de seda grueso
8344	Hileras de plata
8345	Yelmo cabeza de lobo
8346	Guanteletes del mar
8347	Guanteletes de dragontina
8348	Yelmo de fuego
8349	Coraza de plumas
8350	El anillo 1
8363	Talismán de vudú chamán
8364	Trucha cabeza de mitril
8365	Trucha cabeza de mitril cruda
8366	Trucha hinchada
8367	Coraza de dragontina
8368	Pellejo de lobo grueso
8383	Carta lisa
8384	Patrón: sombrero de cuero cómodo
8385	Patrón: guantes de escamas de tortuga
8386	Patrón: toga de gran vudú
8387	Patrón: máscara de gran vudú
8388	Patrón: capa Nochefugaz
8389	Patrón: pantalones de gran vudú
8390	Patrón: capa de gran vudú
8391	Papada de hiena risitas
8392	Pulmón de jabalí maldito
8393	Pinza de scorpok
8394	Cerebro de basilisco
8395	Patrón: coraza de escórpido resistente
8396	Molleja de buitre
8397	Patrón: brazales de escórpido resistentes
8398	Patrón: guantes de escórpido resistentes
8399	Patrón: botas de escórpido resistentes
8400	Patrón: sobrehombros de escórpido resistentes
8401	Patrón: leotardos de escórpido resistentes
8402	Patrón: Yelmo de escórpido resistente
8403	Patrón: sobrehombros de cuero salvaje
8404	Patrón: jubón de cuero salvaje
8405	Patrón: casco de cuero salvaje
8406	Patrón: botas de cuero salvaje
8407	Patrón: leotardos de cuero salvaje
8408	Patrón: capa de cuero salvaje
8409	Patrón: sobrehombros Nochefugaz
8410	IFRDHR
8411	Cóctel de zumo de pulmón
8412	Polvo de scorpok machacado
8423	Compuesto de córtex cerebral
8424	Chicle de mollejas
8425	Restos de loro
8426	Pluma erizada grande
8427	Cadáver de rata mutilada
8428	Glándula cargada de rocío
8429	Glándula perforada
8430	Glándula de rocío vacía
8431	Bobina de hilo de seda verde pistacho
8432	Agua de Mixilpixil
8443	Adorno de Gahz'rilo
8444	Llave de verdugo
8463	Órdenes del Jefe de Guerra
8483	Faltriquera de agua de Vagayermos
8484	Botiquín de la compañía de aguas de Gadgetzan
8485	Jaula para gatos (bombay)
8486	Jaula para gatos (rex cornualles)
8487	Jaula para gatos (atigrado naranja)
8488	Jaula para gatos (atigrado plateado)
8489	Jaula para gatos (gatito blanco)
8490	Jaula para gatos (siamés)
8491	Jaula para gatos (atigrado negro)
8492	Jaula de loro (papagayo rojo)
8493	Barrica de Weegli
8494	Jaula de loro (papagayo azul)
8495	Jaula de loro (Senegal)
8496	Jaula de loro (Carolina)
8497	Cajón de conejos (Pataneve)
8498	Vástago esmeralda diminuto
8499	Vástago carmesí diminuto
8500	Búho común
8501	Lechuza gavilana
8502	Caja de lotería de bronce
8503	Caja de lotería de bronce pesada
8504	Caja de lotería de hierro
8505	Caja de lotería de hierro pesado
8506	Caja de lotería de mitril
8507	Caja de lotería de mitril pesado
8508	Aleta grande
8523	Equipo de prueba de campo
8524	Fuente de alimentación modelo 4711-FTZ
8525	Orden de compra de Zinge
8526	Tragano violeta
8527	Equipo de prueba de campo sellado
8528	Partículas violeta
8529	Elixir de Tragonublo
8543	Hongos subacuáticos
8544	Venda de tejido mágico
8545	Venda de tejido mágico gruesa
8546	Sales aromáticas potentes
8547	Fórmula: sales aromáticas potentes
8548	Vara divinomática
8563	Mecazancudo rojo
8564	Huevo de hipogrifo
8583	Cuerno de la montura esquelética
8584	Pipeta de muestras abierta
8585	Pipeta de muestras cerrada
8586	Silbato del raptor rojo jaspeado
8587	Trozos de insecto centipaar
8588	Silbato del raptor esmeralda
8589	Silbato viejo de raptor marfil
8590	Silbato viejo de raptor obsidiana
8591	Silbato del raptor turquesa
8592	Silbato del raptor violeta
8593	Equipo de análisis de Patagolpe
8594	Informe del análisis del insecto
8595	Mecazancudo azul
8603	Rocío Cardizal
8623	Localizador de emergencia OOX-17/TN
8624	Bengala roja
8625	Bengala blanca
8626	Bengala azul
8627	Riendas del sable de la noche
8628	Riendas del sable de la noche moteado
8629	Riendas del sable de la noche rayado
8630	Riendas del tigre de bengala
8631	Riendas del sable de hielo rayado
8632	Riendas del sable de hielo moteado
8633	Riendas del leopardo
8643	Huevo extraordinario
8644	Huevo de primera
8645	Huevo normal
8646	Huevo estropeado
8647	Cajón de huevos
8663	Insignia de mitril
8683	Manzana fresca de Clara
8684	Calimocho dulce de las Tierras del Interior
8685	Entrega de calimocho de Dran
8686	Colgante de mitril
8687	Descripción del visitante de Thredd lacrada
8703	Sello de pericia
8704	Localizador de emergencia OOX-09/TI
8705	Localizador de emergencia OOX-22/FE
8707	Escama electrificada de Gahz'rilla
8708	Martillo de pericia
8723	Cabeza del Califa Escorpijón
8724	Secreto de Rin'ji
8743	Libro sobre Marca de lo Salvaje
8744	Libro sobre Cólera
8745	Libro sobre Toque de sanación
8746	Capucha entrelazada
8747	Gorro de cuero endurecido
8748	Almófar de malla doble
8749	Sombrero de ganchillo
8750	Casquete de cuero grueso
8751	Almófar superpuesto
8752	Aro de escamas laminadas
8753	Casco de cuero liso
8754	Casquete de sarga
8755	Casco de placas ligeras
8756	Libro sobre Recrecimiento II
8757	Libro sobre Fuego estelar
8758	Libro sobre Eliminar maldición
8759	Libro sobre Recrecimiento III
8760	Libro sobre Suprimir Veneno
8761	Libro sobre Fuego estelar II
8762	Libro sobre Rejuvenecimiento V
8763	Libro sobre Fuego lunar V
8764	Libro sobre Fuego Feérico II
8765	Libro sobre Recrecimiento IV
8766	Rocío de gloria matinal
8768	Libro sobre Fuego estelar III
8769	Libro sobre Espinas IV
8770	Libro sobre Fuego lunar VI
8771	Libro sobre Rejuvenecimiento VI
8772	Libro sobre Recrecimiento V
8773	Libro sobre Raíces enredadoras V
8774	Libro sobre Toque de sanación VII
8775	Libro sobre Tranquilidad II
8776	Libro sobre Marca de lo Salvaje VI
8777	Libro sobre Fuego lunar IX
8778	Libro sobre Rejuvenecimiento VII
8779	Libro sobre Fuego Feérico III
8780	Libro sobre Fuego estelar V
8781	Libro sobre Recrecimiento VII
8782	Libro sobre Espinas V
8783	Libro sobre Toque de sanación IX
8784	Libro sobre Cólera VII
8785	Libro sobre Rejuvenecimiento IX
8786	Libro sobre Tranquilidad III
8787	Libro sobre Calma de animales
8788	Libro sobre Calma de animales II
8789	Libro sobre Calma de animales III
8790	Libro sobre Fuego Feérico IV
8791	Libro sobre Recrecimiento VIII
8792	Libro sobre Espinas VI
8793	Libro sobre Cólera VIII
8794	Libro sobre Toque de sanación X
8795	Libro sobre Raíces enredadoras VI
8796	Libro sobre Fuego lunar X
8797	Libro sobre Rejuvenecimiento X
8798	Libro sobre Fuego estelar VI
8799	Libro sobre Marca de lo Salvaje VII
8800	Libro sobre Recrecimiento IX
8801	Libro sobre Tranquilidad IV
8802	Escrito sobre Intelecto Arcano
8803	Escrito sobre Bola de Fuego
8804	Escrito sobre Deflagración Arcana
8805	Escrito sobre Detectar magia
8806	Escrito sobre Eliminar maldición inferior
8807	Escrito sobre Amplificar magia
8808	Escrito sobre Escudo de maná
8809	Escrito sobre Sueño
8810	Escrito sobre Sueño II
8811	Escrito sobre Agostar
8812	Escrito sobre Deflagración Arcana II
8813	Escrito sobre Atenuar magia II
8814	Escrito sobre Bola de Fuego V
8815	Escrito sobre Cono de frío
8816	Escrito sobre Descarga de Escarcha V
8818	Escrito sobre Escudo de maná II
8819	Escrito sobre Agostar II
8820	Escrito sobre Resguardo contra el Fuego II
8821	Escrito sobre Amplificar magia II
8822	Escrito sobre Deflagración Arcana III
8823	Escrito sobre Explosión de Fuego IV
8824	Escrito sobre Bola de Fuego VI
8825	Escrito sobre Resguardo contra la Escarcha III
8826	Escrito sobre Misiles Arcanos IV
8827	Elixir de Caminar sobre el agua
8828	Escrito sobre Descarga de Escarcha VI
8829	Escrito sobre Cono de frío II
8830	Escrito sobre Agostar III
8831	Loto cárdeno
8832	Escrito sobre Ventisca III
8833	Escrito sobre Escudo de maná III
8834	Escrito sobre Atenuar magia III
8835	Escrito sobre Bola de Fuego VII
8836	Lágrimas de Arthas
8837	Escrito sobre Deflagración Arcana V
8838	Solea
8839	Carolina
8840	Escrito sobre Crear gema de maná II
8841	Escrito sobre Explosión de Fuego V
8842	Escrito sobre Descarga de Escarcha VII
8843	Escrito sobre Resguardo contra el Fuego III
8844	Escrito sobre Sueño III
8845	Champiñón fantasma
8846	Gromsanguina
8847	Escrito sobre Agostar V
8848	Escrito sobre Fogonazo IV
8849	Escrito sobre Misiles Arcanos V
8850	Escrito sobre Crear agua V
8851	Escrito sobre Bola de Fuego VIII
8852	Escrito sobre Intelecto Arcano IV
8853	Escrito sobre Crear comida V
8854	Escrito sobre Cono de frío III
8855	Escrito sobre Amplificar magia III
8856	Escrito sobre Descarga de Escarcha VIII
8857	Escrito sobre Ventisca IV
8858	Escrito sobre Escudo de maná IV
8859	Escrito sobre Explosión de Fuego VI
8860	Escrito sobre Bola de Fuego IX
8861	Escrito sobre Crear gema de maná III
8862	Escrito sobre Misiles Arcanos VI
8863	Escrito sobre Atenuar magia IV
8864	Escrito sobre Fogonazo V
8865	Escrito sobre Armadura de hielo III
8866	Escrito sobre Cono de frío IV
8867	Escrito sobre Descarga de Escarcha IX
8868	Escrito sobre Crear agua VI
8869	Escrito sobre Resguardo contra el Fuego IV
8870	Escrito sobre Invisibilidad superior
8871	Escrito sobre Crear comida VI
8872	Escrito sobre Ventisca V
8873	Escrito sobre Escudo de maná V
8874	Escrito sobre Agostar VI
8875	Escrito sobre Resguardo contra la Escarcha IV
8876	Escrito sobre Resguardo contra la Escarcha II
8877	Escrito sobre Bola de Fuego X
8878	Escrito sobre Explosión de Fuego VII
8879	Escrito sobre Nova de Escarcha IV
8880	Escrito sobre Deflagración Arcana VI
8881	Escrito sobre Liberación de Khadgar IV
8882	Escrito sobre Amplificar magia IV
8883	Escrito sobre Intelecto Arcano V
8884	Escrito sobre Descarga de Escarcha X
8885	Escrito sobre Misiles Arcanos VII
8886	Escrito sobre Fogonazo VI
8887	Escrito sobre Agostar VII
8888	Escrito sobre Cono de frío V
8889	Escrito sobre Crear gema de maná IV
8890	Escrito sobre Bola de Fuego XI
8891	Escrito sobre Armadura de hielo IV
8892	Escrito sobre Crear agua VII
8893	Escrito sobre Sueño IV
8894	Escrito sobre Atenuar magia V
8895	Escrito sobre Ventisca VI
8896	Escrito sobre Escudo de maná VI
8897	Escrito sobre Resguardo contra el Fuego V
8898	Escrito sobre Deflagración Arcana IV
8899	Escrito sobre Agostar IV
8900	Libro sobre Raíces enredadoras IV
8901	Libro sobre Toque de sanación VIII
8902	Libro sobre Marca de lo Salvaje V
8903	Libro sobre Fuego lunar VII
8904	Libro sobre Fuego lunar VIII
8905	Libro sobre Recrecimiento VI
8906	Libro sobre Rejuvenecimiento VIII
8907	Libro sobre Fuego estelar IV
8909	Tratado: Golpe Sagrado II
8910	Tratado: Imposición de manos
8911	Tratado: Puño de justicia
8912	Tratado: Golpe de cruzado
8913	Tratado: Golpe Sagrado III
8914	Tratado: Golpe de cruzado II
8915	Tratado: Golpe Sagrado IV
8916	Tratado: Puño de justicia II
8917	Tratado: Imposición de manos II
8918	Tratado: Sello de protección III
8919	Tratado: Golpe Sagrado V
8920	Tratado: Golpe de cruzado III
8921	Tratado: Puño de justicia III
8922	Tratado: Golpe Sagrado VI
8923	Esencia de agonía
8924	Polvo de Deterioro
8925	Vial de cristal
8926	Veneno instantáneo IV
8927	Veneno instantáneo V
8928	Veneno instantáneo VI
8929	Tratado: Exorcismo IV
8930	Tratado: Sello de rectitud IV
8931	Tratado: Golpe de cruzado IV
8932	Queso curado de Alterac
8933	Tratado: Luz Sagrada VII
8934	Tratado: Golpe Sagrado VII
8935	Tratado: Sentencia II
8936	Tratado: Sello de cólera III
8937	Tratado: Imposición de manos III
8938	Tratado: Ahuyentar no-muertos III
8939	Tratado: Exorcismo V
8940	Tratado: Puño de justicia IV
8941	Tratado: Luz Sagrada VIII
8942	Tratado: Sello de rectitud V
8943	Tratado: Golpe Sagrado VIII
8944	Tratado: Golpe de cruzado V
8945	Tratado: Sentencia III
8947	Tratado: Exorcismo VI
8948	Boletus edulis seco
8949	Elixir de agilidad
8950	Tarta de cerezas casera
8951	Elixir de defensa superior
8952	Codorniz asada
8953	Plátano frito
8954	Códice de Palabra Sagrada: entereza
8955	Códice de Desvanecerse
8956	Aceite de inmolación
8957	Mero espinoso
8958	Códice de Explosión mental
8959	Mero espinoso crudo
8960	Códice de Curar enfermedad
8961	Códice de Alarido psíquico
8962	Códice de Explosión mental II
8963	Códice de Calma mental
8964	Códice de Sanación relámpago
8965	Códice de Desvanecerse II
8966	Códice de Encadenar no-muerto
8967	Códice de Explosión mental III
8968	Códice de Quemar maná
8969	Códice de Sanación relámpago II
8971	Códice de Alarido psíquico II
8972	Códice de Explosión mental IV
8973	Pellejo de yeti grueso
8974	Códice de Control mental
8975	Códice de Desvanecerse III
8976	Códice de Suprimir enfermedad
8977	Códice de Quemar maná II
8978	Códice de Sanación relámpago III
8980	Códice de Explosión mental V
8981	Códice de Calma mental II
8983	Códice de Sanación relámpago IV
8984	Veneno mortal III
8985	Veneno mortal IV
8986	Códice de Encadenar no-muerto II
8987	Códice de Protección contra lo Sagrado II
8988	Códice de Quemar maná III
8989	Códice de Desvanecerse IV
8990	Códice de Explosión mental VI
8991	Códice de Fuego interno IV
8992	Códice de Alarido psíquico III
8993	Códice de Protección contra las Sombras II
8994	Códice de palabra de las Sombras: dolor VI
8995	Códice de Palabra Sagrada: escudo VII
8996	Códice de Resurrección III
8997	Códice de Control mental II
8998	Códice de Visión mental II
8999	Códice de Sanación relámpago V
9000	Códice de Renovar VII
9001	Códice de Sanación superior II
9002	Códice de Explosión mental VII
9003	Códice de Punición Sagrada VII
9004	Códice de Palabra Sagrada: entereza V
9005	Códice de Quemar maná IV
9006	Códice de Palabra Sagrada: escudo VIII
9007	Códice de Desvanecerse V
9008	Códice de Rezo de sanación III
9009	Códice de Fuego interno V
9010	Códice de Sanación relámpago VI
9011	Códice de palabra de las Sombras: dolor VII
9012	Códice de Renovar VIII
9013	Códice de Sanación superior III
9014	Códice de Calma mental III
9015	Códice de Explosión mental VIII
9016	Códice de Punición Sagrada VIII
9017	Códice de Protección contra lo Sagrado III
9018	Códice de Palabra Sagrada: escudo IX
9019	Códice de Renovar IX
9020	Códice de Alarido psíquico IV
9021	Códice de Quemar maná V
9022	Códice de Sanación relámpago VII
9023	Códice de Protección contra las Sombras III
9024	Códice de Control mental III
9025	Códice de Sanación superior IV
9026	Códice de Resurrección IV
9027	Códice de Explosión mental IX
9028	Códice de Palabra de las Sombras: dolor VIII
9029	Códice de Desvanecerse VI
9030	Poción restauradora
9031	Códice de Encadenar no-muerto III
9032	Códice de Rezo de sanación IV
9033	Códice de Fuego interno VI
9034	Códice de Palabra Sagrada: entereza VI
9035	Códice de Palabra Sagrada: escudo X
9036	Poción de resistencia a la magia
9037	Tablilla de arma de Muerdepiedras
9039	Tablilla de Choque de tierra
9040	Tablilla de Ola de sanación II
9041	Tablilla de Tótem Nexo Terrestre
9043	Tablilla de Tótem Garra de piedra
9044	Tablilla de Choque de tierra II
9046	Tablilla de Tótem Fuerza de la tierra
9047	Tablilla de Choque de llamas
9048	Tablilla de Renacer
9049	Tablilla de Tótem Nova de Fuego
9050	Tablilla de Ola de sanación III
9051	Tablilla de Choque de tierra III
9052	Tablilla de Tótem Piel de piedra II
9053	Tablilla de arma de Muerdepiedras II
9054	Tablilla de Choque de llamas II
9055	Tablilla de Tótem Garra de piedra II
9056	Tablilla de Ola de sanación IV
9057	Tablilla de arma Estigma de Escarcha
9058	Tablilla de Choque de Escarcha
9059	Tablilla de Arma Lengua de Fuego
9060	Cilindro de mitril taraceado
9061	Combustible de cohete goblin
9062	Tablilla de Curar enfermedad
9063	Tablilla de Tótem contraveneno
9064	Tablilla de Arma Lengua de Fuego II
9065	Tablilla de Tótem Nova de Fuego II
9066	Tablilla de Tótem de resistencia a la Escarcha
9067	Tablilla de Tótem Fuerza de la tierra II
9068	Tablilla de Tótem Piel de piedra III
9069	Tablilla de Choque de tierra IV
9070	Tablilla de Ola de sanación V
9071	Tablilla de Tótem fuente de maná
9072	Tablilla de Tótem Lengua de Fuego
9073	Tablilla de arma Viento Furioso
9074	Tablilla de Choque de llamas III
9075	Tablilla de Tótem de resistencia al Fuego
9076	Tablilla de Tótem de magma
9077	Tablilla de Tótem Garra de piedra III
9078	Tablilla de Tótem derribador
9079	Tablilla de Choque de relámpagos
9080	Tablilla de Tótem de resistencia a la Naturaleza
9081	Tablilla de Tótem Corriente de sanación II
9082	Tablilla de arma de Muerdepiedras III
9083	Tablilla de Tótem abrasador III
9084	Tablilla de Tótem Viento Furioso
9085	Tablilla de Tótem Nova de Fuego III
9086	Tablilla de Ola de sanación VI
9087	Tablilla de Purgar II
9088	Ofrenda de Arthas
9089	Tablilla de Choque de Escarcha II
9090	Tablilla de arma Estigma de Escarcha II
9091	Tablilla de Tótem Piel de piedra IV
9092	Tablilla de Tótem avizor
9093	Tablilla de Tótem fuente de maná II
9094	Tablilla de Arma Lengua de Fuego III
9095	Tablilla de Choque de tierra V
9096	Tablilla de Tótem de limpieza de enfermedades
9097	Tablilla de Tótem de magma II
9098	Tablilla de Tótem Fuerza de la tierra III
9099	Tablilla de Tótem Garra de piedra IV
9100	Tablilla de Escudo de relámpagos V
9101	Tablilla de arma Viento Furioso II
9102	Tablilla de Cadena de relámpagos II
9103	Tablilla de Tótem Corriente de sanación III
9104	Tablilla de Tótem abrasador IV
9105	Tablilla de Ola de sanación VII
9123	Tablilla de Descarga de relámpagos VI
9124	Tablilla de Choque de relámpagos II
9125	Tablilla de Tótem Gracia del Aire
9126	Tablilla de Tótem Lengua de Fuego II
9127	Tablilla de Tótem de resistencia al Fuego II
9128	Tablilla de Tótem Nova de Fuego IV
9129	Tablilla de arma de Muerdepiedras IV
9130	Tablilla de Tótem de resistencia a la Naturaleza II
9131	Tablilla de Tótem Piel de piedra V
9132	Tablilla de Explosión de arrabio VI
9133	Tablilla de Sanación en cadena II
9134	Tablilla de Tótem Viento Furioso II
9135	Tablilla de Choque de Escarcha III
9136	Tablilla de Tótem fuente de maná III
9137	Tablilla de Escudo de relámpagos VI
9138	Tablilla de Tótem de magma III
9139	Tablilla de arma Estigma de Escarcha III
9140	Tablilla de Cadena de relámpagos III
9141	Tablilla de Tótem Garra de piedra V
9142	Tablilla de Choque de tierra VI
9143	Tablilla de Ola de sanación VIII
9144	Poción de atriplex salvaje
9145	Tablilla de Descarga de relámpagos VII
9146	Tablilla de Tótem abrasador V
9147	Tablilla de Tótem Corriente de sanación IV
9148	Tablilla de Arma Lengua de Fuego IV
9149	Piedra filosofal
9150	Tablilla de Tótem Fuerza de la tierra IV
9151	Tablilla de Choque de llamas V
9152	Tablilla de Tótem Nova de Fuego V
9153	Planos de la plataforma
9154	Elixir de detección de no-muertos
9155	Elixir Arcano
9156	Tablilla de Explosión de arrabio VII
9157	Tablilla de Sanación en cadena III
9158	Tablilla de Tótem de resistencia a la Escarcha III
9159	Tablilla de Choque de relámpagos III
9160	Tablilla de arma Viento Furioso III
9161	Tablilla de Tótem Piel de piedra VI
9162	Tablilla de Escudo de relámpagos VII
9164	Tablilla de Tótem Gracia del Aire II
9165	Tablilla de Tótem Lengua de Fuego III
9166	Tablilla de Tótem fuente de maná IV
9167	Tablilla de Cadena de relámpagos IV
9168	Tablilla de Ola de sanación IX
9169	Tablilla de Descarga de relámpagos VIII
9170	Tablilla de Tótem de resistencia al Fuego III
9171	Tablilla de Tótem de magma IV
9172	Poción de invisibilidad
9173	Transpondedor goblin
9174	Tablilla de choque de Escarcha IV
9175	Tablilla de arma de Muerdepiedras V
9176	Tablilla de Tótem Garra de piedra VI
9177	Tablilla de choque de tierra VII
9178	Tablilla de Tótem de resistencia a la Naturaleza III
9179	Elixir de intelecto superior
9180	Tablilla de Tótem Viento Furioso III
9181	Tablilla de Tótem Corriente de sanación V
9182	Tablilla de Tótem abrasador VI
9183	Tablilla de Sanación en cadena
9184	Tablilla de Choque de llamas IV
9185	Tablilla de Tótem de resistencia a la Escarcha II
9186	Veneno de aturdimiento mental III
9187	Elixir de agilidad superior
9188	Tablilla de Tótem abrasador II
9189	Campana de Shay
9190	Grimorio Inmolar
9191	Grimorio Maldición de debilidad
9192	Grimorio Corrupción
9193	Grimorio Transfusión de vida
9194	Grimorio Maldición de agonía
9195	Grimorio Drenar alma
9197	Elixir de Visión onírica
9198	Grimorio Cauce de salud
9199	Grimorio Maldición de temeridad
9200	Grimorio Maldición de debilidad II
9201	Grimorio Corrupción II
9202	Grimorio Transfusión de vida II
9203	Grimorio Ritual de invocación
9204	Grimorio Cauce de salud II
9205	Grimorio Maldición de agonía II
9206	Elixir de gigantes
9207	Grimorio Crear sangrita II
9208	Grimorio Drenar alma II
9209	Grimorio Maldición de debilidad III
9210	Tinte fantasmal
9211	Grimorio Maldición de temeridad II
9212	Grimorio Descarga de las Sombras V
9214	Grimorio Inferno
9215	Grimorio Cauce de salud III
9216	Grimorio Corrupción III
9217	Grimorio Transfusión de vida III
9218	Grimorio Esclavizar demonio
9219	Grimorio Llamas infernales
9221	Grimorio Maldición de agonía III
9222	Grimorio Maldición de los Elementos
9223	Grimorio Maldición de debilidad IV
9224	Elixir de matanza de demonios
9225	Grimorio Descarga de las Sombras VI
9226	Grimorio Cauce de salud IV
9227	Grimorio Drenar alma III
9228	Grimorio Crear sangrita III
9229	Grimorio Drenaje de vida IV
9230	Grimorio Maldición de temeridad III
9231	Grimorio Corrupción IV
9233	Elixir de detección de demonios
9234	Tiara de las profundidades
9235	Carta de Pratt
9236	Carta de Jangdor
9237	Cabellera de gnoll Zarpaleña
9238	Caparazón de escarabajo sin rajar
9240	Marra de Zul'Farrak
9241	Marra sacra
9242	Tablilla antigua
9243	Corazón marchito
9244	Envío de Stoley
9245	Botella de Stoley
9246	Cabeza de Barbafuego
9247	Escama naga Crestafuria
9248	Reliquia misteriosa
9249	Llave de capitán
9250	Ruta de navegación
9251	Fragmento superior del mapa
9252	Trozo inferior de mapa
9253	Trozo de mapa del medio
9254	Mapa del tesoro de Cuergo
9255	Esencia Lahassa
9256	Esencia Imbel
9257	Esencia samha
9258	Esencia Byltan
9259	Collar tribal trol
9260	Ron volátil
9261	Mena de plomo
9262	Vitriolo negro
9263	Báculo de Troyas
9264	Elixir de poder de las Sombras
9265	Tesoro escondido de Cuergo
9266	Planes de batalla de Zarpaleña
9275	Llave de Cuergo
9276	Baúl de pirata
9277	Procesador de memoria central de Tecnobot
9278	Esencia artificial
9279	Tarjeta perforada blanca
9280	Tarjeta perforada amarilla
9281	Tarjeta perforada roja
9282	Tarjeta perforada azul
9283	Ampolla de plomo vacía
9284	Ampolla de plomo llena
9285	Avambrazos de placas de campo
9286	Armadura de placas de campo
9287	Guanteletes de placas de campo
9288	Faja de placas de campo
9289	Botas de placas de campo
9290	Casco de placas de campo
9291	Leotardos de placas de campo
9292	Espaldares de placas de campo
9293	Receta: poción de resistencia a la magia
9294	Receta: poción de atriplex salvaje
9295	Receta: poción de invisibilidad
9296	Receta: ofrenda de Arthas
9297	Receta: elixir de visión onírica
9298	Receta: elixir de gigantes
9299	Combinación de la caja fuerte de Termochufe
9300	Receta: elixir de matanza de demonios
9301	Receta: elixir de poder de las Sombras
9302	Receta: tinte fantasmal
9303	Receta: piedra filosofal
9304	Receta: transmutar hierro a oro
9305	Receta: transmutar mitril a veraplata
9306	Báculo de Equinex
9307	Una piedra chispeante
9308	Objeto con mugre incrustada
9309	Entrañas robomecánicas
9311	Papel y sobres para cartas estándar
9312	Fuegos artificiales azules
9313	Fuegos artificiales verdes
9314	Fuegos artificiales con destellos rojos
9315	Fuegos artificiales amarillos y rosas
9316	Tarjeta perforada centelleante
9317	Fuegos artificiales rojos, blancos y azules
9318	Fuegos artificiales rojos
9319	Pica cargada de Nimboya
9320	Cráneo Secacorteza
9321	Botella de veneno
9322	Glándula de veneno intacta
9323	Papiro de Gadrin
9324	Veneno de Shadra
9325	Un pequeño báculo
9326	Anillo con mugre incrustada
9327	Tarjeta de acceso de nivel de seguridad DELTA
9328	Superinstantánea FX
9329	Una nota corta
9330	Instantánea de Gammerita
9331	Feralas: una historia
9332	Vendas con costra
9333	Collar de plata deslustrada
9334	Cerámica rajada
9335	Garrote de obsidiana roto
9336	Colmillo con funda de oro trol
9355	Pendiente de aro
9356	Una pata de palo
9357	Un esqueleto de loro
9358	Un trapo para la cabeza
9359	Farol de los Mares del Sur
9360	Oro de Cuergo
9361	Oro de Cuergo con gusano
9362	Anillo de oro luminoso
9363	Caja envuelta del Destellamatic
9364	Ampolla de plomo pesada
9365	Restos radiactivos de gran potencia
9366	Guanteletes de escamas doradas
9367	Diseño: guanteletes de escamas doradas
9368	Sello de Jer'kai
9369	Ala de duende dardo iridiscente
9370	Pergamino Gordunni
9371	Orbe Gordunni
9372	Sul'thraze la Azotadora
9375	Casco para expertos buscadores de oro
9378	Hacha de minero de Palatiro
9379	Sang'thraze la Deflectora
9380	Jang'thraze la Protectora
9381	Vara terránea
9382	Botas de minero pisoteador
9383	Cuchilla de obsidiana
9384	Chafarote Rutacanto
9385	Defensor arcaico
9386	Enseña de excavador
9387	Botas de Revelosh
9388	Guardabrazos de Revelosh
9389	Bufas de Revelosh
9390	Guantes de Revelosh
9391	El Paleador
9392	Hoja templada
9393	Luz de esperanza
9394	Casco vikingo con cuernos
9395	Guantes de los antiguos
9396	Musleras de la Cripta
9397	Capa de energía
9398	Botas de carrera desgastadas
9399	Flecha de precisión
9400	Arco corto de Baelog
9401	Corvo largo nórdico
9402	Falda Portaterra
9403	Escudo vikingo maltrecho
9404	Escudo polivalente de Olaf
9405	Faja de fuerza gólem
9406	Grillete Viento de la cumbre
9407	Leotardos tejepiedra
9408	Cachiporra de hierro
9409	Brazales de Hierraya
9410	Puños de risco
9411	Espaldares de fragmento de roca
9412	Lanzafuego de Galgann
9413	El machacador de rocas
9414	Leotardos de piel engrasada
9415	Vestimentas tribales de Grimlok
9416	Carga de Grimlok
9417	Trozo arcádico
9418	Destripapiedras
9419	Martillo de Fuego de Galgann
9420	Salacot de aventurero
9421	Piedra de salud sublime
9422	Maestro de rodeos de Forjatiniebla
9423	El martillo neumático
9424	Espada de Ginn-Su
9425	Péndulo de Fatalidad
9426	Arco monolítico
9427	Rompehuesos Rutacanto
9428	Braciles desenterradas
9429	Casco de minero de las profundidades
9430	Bufas de una época remota
9431	Fez papal
9432	Brazales Placacráneos
9433	Brazaletes olvidados
9434	Vestimenta elemental
9435	Guanteletes de hueso reticulado
9436	Talega de Faranell
9437	Muestra de basilisco sin estudiar
9438	Muestra de escórpido aceptable
9439	Muestra de hiena sin estudiar
9440	Muestra de basilisco aceptable
9441	Muestra de hiena aceptable
9442	Muestra de escórpido sin estudiar
9443	Muestra de monstruo utilizada
9444	Microprocesador de Tecnobot
9445	Garras Grubbis
9446	Pata de Electrocutor
9447	Perno de Electrocutor
9448	Trapo grasiento de tanque araña
9449	Moledora manual de muchedumbre
9450	Botas de gnomobot
9451	Agua burbujeante
9452	Hidrocaña
9453	Desfacedor tóxico
9454	Botos ácidos
9455	Puños de emisario
9456	Lanzacristales
9457	Cetro diplomático real
9458	Núcleo central de Termochufe
9459	Brazo izquierdo de Termochufe
9460	Cuerno de Tótem Siniestro
9461	Material cargado
9462	Cajón de cuernos de Tótem Siniestro
9463	Cobalto Gordunni
9465	Maestro excavador 5000
9466	Pala de Orwin
9467	Colmillo de Gahz'rilla
9468	Pluma de Picoafilado
9469	Armadura de escamas de Gahz'rilla
9470	Máscara de mojo malo
9471	Medallón de Nekrum
9472	Llave de Hexx
9473	Piel hudú maldita
9474	Falda hudú maldita
9475	Picador diabólico
9476	Espaldares malos grandes
9477	El gorila del jefe
9478	Sierra
9479	Abrazo del licántropo
9480	Arrancaojos
9481	El minotauro
9482	Vara de médico brujo
9483	Incinerador
9484	Leotardos de choque de hechizo
9485	Vibrofilo
9486	Hacha de batalla de carga superior
9487	Superpistola de alta tecnología
9488	Martillo de poder oscilador
9489	Hielera giromática
9490	Megacortadora Gizmotrón
9491	Guantes de piloto célebre
9492	Reactivador de gigaflujo electromagnético
9507	Cajón cuidadosamente embalado
9508	Mono de mecánico
9509	Leotardos de petróleo
9510	Chapines Cueva Honda
9511	Escalpelo de flebotomista
9512	Manteo de metal negro
9513	Bastón Ley
9514	Bastón Arcano
9515	Guerrera de encaje abisal
9516	Túnica de nudos astral
9517	Báculo celestial
9518	Trituradores de barro
9519	Apisonadoras Piesucios
9520	Cazador silencioso
9521	Machacacráneos
9522	Círculo de Piedras energizado
9523	Temple trol
9527	Vara de tramoyista de hechizos
9528	Corazón oscuro de Edana
9529	Juego de equipo de guerrero interno N25
9530	Cuerno de Garfaodio
9531	Espaldares de pizarra
9532	Juego de equipo de guerrero interno N30
9533	Anillo de fraternidad masona
9534	Sombrero de hermandad de ingeniero
9535	Brazales soldados con fuego
9536	Manto alas de hada
9537	Caja bien envuelta
9538	Anillo de oro de Talvash
9539	Caja de raciones
9540	Caja de hechizos
9541	Caja de regalitos
9542	Carta simple
9543	Runa simple
9544	Memorándum simple
9545	Sigilo simple
9546	Pergamino simple
9547	Nota simple
9548	Carta sacralizada
9550	Runa codificada
9551	Sigilo cifrado
9552	Nota con runas grabadas
9553	Papiro con grabados
9554	Tablilla encriptada
9555	Carta cifrada
9556	Runa sacralizada
9557	Sigilo sacralizado
9558	Memorándum encriptado
9559	Pergamino codificado
9560	Papiro encriptado
9561	Tablilla sacralizada
9562	Tablilla con runas grabadas
9563	Runa consagrada
9564	Tablilla con grabados
9565	Nota con grabados
9566	Runa con grabados
9567	Sigilo con grabados
9568	Papiro con runas grabadas
9569	Pergamino sacralizado
9570	Carta consagrada
9571	Carta glífica
9572	<UNUSED> Glyphic Rune
9573	Memorándum glífico
9574	Pergamino glífico
9575	Tablilla glífica
9576	Carta manchada
9577	Memorándum corrupto
9578	Pergamino corrupto
9579	Papiro corrupto
9580	Sigilo verdeante
9581	Nota verdeante
9587	Saco de pelambre descongelada
9588	Anillo de oro de Nogg
9589	Minerales taraceados
9590	Tronco astillado
9591	Tendón resistente
9592	Trozos metálicos
9593	Muisek de antárbol
9594	Muisek de lechúcico salvaje
9595	Muisek de hipogrifo
9596	Muisek de dragón feérico
9597	Muisek de gigante montés
9598	Togas para dormir
9599	Leotardos de malla de corteza
9600	Pantalones con encaje
9601	Botas forradas
9602	Hoja Leñomaleza
9603	Bastón de raíz de arena
9604	Martillo de mecánico
9605	Manteo de mecánico
9606	Vasija de muisek de antárbol
9607	Bastión de Ventormenta
9608	Herramienta de desarme de Shoni
9609	Mitones llamativos
9618	Vasija de muisek de lechúcico
9619	Vasija de muisek de hipogrifo
9620	Vasija de muisek de dragón feérico
9621	Vasija de muisek de gigante montés
9622	Anillo Nudo de Junco
9623	Togas civinad
9624	Peto de corredor
9625	Leotardos duales reforzados
9626	Carga de enano
9627	Estrella polar de la Liga de Expedicionarios
9628	Faltriquera de hierbas de Neeru
9629	Una cabeza reducida
9630	Botas hechas a mano de Pratt
9631	Guantes hechos a mano de Pratt
9632	Guantes hechos a mano de Jangdor
9633	Botas hechas a mano de Jangdor
9634	Guantes aptos para la carga
9635	Manteo de maestro boticario
9636	Fajín de espadachín
9637	Botas lustrosas
9638	Puños quelónidos
9639	La mano de Antu'sul
9640	Mandiletes de maña
9641	Amuleto sangrevida
9642	Sortija de la Gran Tortuga
9643	Deflector optomático
9644	Temporizador de huevos termostático
9645	Botas de inventor gnómico
9646	Aparato de hundimiento gnómico
9647	Experimento volador fallido
9648	Felpa de tela metálica
9649	Vestimentas de alto rango real
9650	Pechera protectora de honor
9651	Martillo de tormenta de jinete de grifos
9652	Leotardos de Jinete de grifos
9653	Gafas de rapidín
9654	Esquirla de piedra de hito
9655	Aro de semillas
9656	Mandiletes de granito
9657	Cincho seto
9658	Botas del Maharishi
9660	Capa de mirada estelar
9661	Barrera natural
9662	Botas Crestarrápida
9663	Pechera de Jinete del Alba
9664	Guarda de centinela
9665	Guantes Crestala
9666	Faja de Cuerno Fuerte
9678	Azotador múrloc de Tok'Kar
9679	Trituradora múrloc de Tok'Kar
9680	Faca múrloc de Tok'Kar
9681	Patas de rey reptador a la parrilla
9682	Cinturón de cuero de jefe
9683	Fuerza del antárbol
9684	Fuerza del hipogrifo
9685	Voluntad del gigante montés
9686	Espíritu del dragón feérico
9687	Cinturón de forcejeador
9698	Guantes de Perspicacia
9699	Capa de cuartel
9703	Manteo agostado
9704	Guantes de cuatrero
9705	Cordones de Tharg
9706	Disco de Tharg
9718	Hoja de Héroes reforjada
9719	Hoja de Héroes rota
9738	Gema de Cobrah
9739	Gema de Anacondra
9740	Gema de Pythas
9741	Gema de Serpentis
9742	Cordón simple
9743	Botas simples
9744	Braciles simples
9745	Manteo simple
9746	Guantes simples
9747	Calzones simples
9748	Toga simple
9749	Blusa simple
9750	Fajín de cíngaro
9751	Sandalias de cíngaro
9752	Braciles de cíngaro
9753	Rodela de cíngaro
9754	Capa de cíngaro
9755	Guantes de cíngaro
9756	Calzas de cíngaro
9757	Guerrera de cíngaro
9758	Cinturón de cadete
9759	Botas de cadete
9760	Brazales de cadete
9761	Capa de cadete
9762	Guanteletes de cadete
9763	Leotardos de cadete
9764	Escudo de cadete
9765	Jubón de cadete
9766	Fajín de tejido verde
9767	Botas de tejido verde
9768	Brazales de tejido verde
9769	Rama de tejido verde
9770	Capa de tejido verde
9771	Guantes de tejido verde
9772	Leotardos de tejido verde
9773	Toga de tejido verde
9774	Jubón de tejido verde
9775	Cincho de bandido
9776	Botas de bandido
9777	Brazales de bandido
9778	Rodela de bandido
9779	Capa de bandido
9780	Guantes de bandido
9781	Pantalones de bandido
9782	Chaleco de bandido
9783	Pechera de asaltante
9784	Botas de asaltante
9785	Brazales de asaltante
9786	Capa de asaltante
9787	Guanteletes de asaltante
9788	Cinturón de asaltante
9789	Musleras de asaltante
9790	Escudo de asaltante
9791	Guerrera de paño de hiedra
9792	Botas de paño de hiedra
9793	Pulseras de paño de hiedra
9794	Capa de paño de hiedra
9795	Guantes de paño de hiedra
9796	Manto de paño de hiedra
9797	Pantalones de paño de hiedra
9798	Toga de paño de hiedra
9799	Fajín de paño de hiedra
9800	Orbe de hiedra
9801	Cinturón excelente
9802	Botas excelente
9803	Brazales excelente
9804	Rodela excelente
9805	Capa excelente
9806	Guantes excelentes
9807	Sobrehombros excelentes
9808	Leotardos excelentes
9809	Guerrera excelente
9810	Botas reforzadas
9811	Brazales reforzados
9812	Capa reforzada
9813	Guanteletes reforzados
9814	Cinturón reforzado
9815	Leotardos reforzados
9816	Escudo reforzado
9817	Bufas reforzadas
9818	Cota de malla reforzada
9819	Guerrera durable
9820	Botas durables
9821	Brazales durables
9822	Manteo durable
9823	Guantes durables
9824	Sobrehombros durable
9825	Pantalones durables
9826	Toga durable
9827	Cinturón de cuero escamado
9828	Botas de cuero escamado
9829	Brazales de cuero escamado
9830	Escudo escamado
9831	Capa escamada
9832	Guantes de cuero escamado
9833	Leotardos de cuero escamado
9834	Sobrehombros de cuero escamado
9835	Guerrera de cuero escamado
9836	Armadura a rayas
9837	Brazales a rayas
9838	Capa a rayas
9839	Guanteletes a rayas
9840	Faja a rayas
9841	Leotardos a rayas
9842	Espaldares a rayas
9843	Escudo a rayas
9844	Jubón de implorador
9845	Zapatos de implorador
9846	Brazales de implorador
9847	Capa de implorador
9848	Guantes de implorador
9849	Caperuza de implorador
9850	Manto de implorador
9851	Calzones de implorador
9852	Toga de implorador
9853	Cincho de implorador
9854	Chaleco de arquero
9855	Cinturón de arquero
9856	Botas de arquero
9857	Brazales de arquero
9858	Rodela de arquero
9859	Gorro de arquero
9860	Capa de arquero
9861	Guantes de arquero
9862	Calzas de arquero
9863	Hombreras de arquero
9864	Botas de renegado
9865	Brazales de renegado
9866	Coselete de renegado
9867	Capa de renegado
9868	Guanteletes de renegado
9869	Cinturón de renegado
9870	Aro de renegado
9871	Leotardos de renegado
9872	Espaldares de renegado
9873	Escudo de renegado
9874	Mantón hechicero
9875	Fajín hechicero
9876	Zapatillas hechicero
9877	Capa hechicero
9878	Sombrero hechicero
9879	Pulseras hechicero
9880	Guantes hechicero
9881	Manto hechicero
9882	Esfera hechicero
9883	Pantalones hechicero
9884	Toga hechicero
9885	Botas de cazador
9886	Braciles de cazador
9887	Armadura de cazador
9889	Almete de cazador
9890	Manteo de cazador
9891	Cinturón de cazador
9892	Guantes de cazador
9893	Leotardos de cazador
9894	Sobrehombros de cazador
9895	Botas de brigandina
9896	Brazales de brigandina
9897	Coselete de brigandina
9898	Capa de brigandina
9899	Escudo de brigandina
9900	Guanteletes de brigandina
9901	Cinturón de brigandina
9902	Yelmo de brigandina
9903	Leotardos de brigandina
9904	Espaldares de brigandina
9905	Blusa real
9906	Fajín real
9907	Botas reales
9908	Manteo real
9909	Braciles reales
9910	Guantes reales
9911	Calzas reales
9912	Amito real
9913	Toga real
9914	Cetro real
9915	Cinta real
9916	Cinturón de rastreador
9917	Botas de rastreador
9918	Defensor brigada
9919	Capa de rastreador
9920	Guantes de rastreador
9921	Cinta de rastreador
9922	Leotardos de rastreador
9923	Hombreras de rastreador
9924	Guerrera de rastreador
9925	Guardamuñecas de rastreador
9926	Botas brigada
9927	Brazales brigada
9928	Coraza brigada
9929	Capa brigada
9930	Guanteletes brigada
9931	Faja brigada
9932	Aro brigada
9933	Leotardos brigada
9934	Espaldares brigada
9935	Escudo de placas estampadas
9936	Botas de lego
9937	Braciles de lego
9938	Capa de lego
9939	Guantes de lego
9940	Caperuza de lego
9941	Manto de lego
9942	Pantalones de lego
9943	Toga de lego
9944	Cristal de lego
9945	Fajín de lego
9946	Guerrera de lego
9947	Cinturón de cabecilla
9948	Botas de cabecilla
9949	Brazales de cabecilla
9950	Coraza de cabecilla
9951	Capa de cabecilla
9952	Guantes de cabecilla
9953	Ornato de cabecilla
9954	Leotardos de cabecilla
9955	Sobrehombros de cabecilla
9956	Brazales de belicista
9957	Pechera de belicista
9958	Rodela de belicista
9959	Capa de belicista
9960	Guanteletes de belicista
9961	Cinturón de belicista
9962	Grebas de belicista
9963	Aro de belicista
9964	Leotardos de belicista
9965	Espaldares de belicista
9966	Armadura de placas estampadas
9967	Guanteletes de placas estampadas
9968	Faja de placas estampadas
9969	Casco de placas estampadas
9970	Leotardos de placas estampadas
9971	Espaldares de placas estampadas
9972	Brazales de placas estampadas
9973	Botas de placas estampadas
9974	Escudo de Señor Supremo
9978	Detector de gahz'rilo
9998	Jubón de tejido mágico negro
9999	Leotardos de tejido mágico negros
10000	Cuerno de Margol
10001	Toga de tejido mágico negra
10002	Pantalones de tejido de sombra
10003	Guantes de tejido mágico negros
10004	Toga de tejido de sombra
10005	Cuerno gigante de Margol
10007	Jubón de tejido mágico rojo
10008	Máscara de bandido blanca
10009	Pantalones de tejido mágico rojos
10010	Pantalones de paño tormentoso
10011	Guantes de paño tormentoso
10018	Guantes de tejido mágico rojos
10019	Guantes de tejido onírico
10020	Jubón de paño tormentoso
10021	Jubón de tejido onírico
10022	Certificado de autenticidad
10023	Guantes de tejido de sombra
10024	Cinta de tejido mágico negra
10025	Máscara de tejido de sombra
10026	Botas de tejido mágico negras
10027	Sobrehombros de tejido mágico negros
10028	Sobrehombros de tejido de sombra
10029	Sobrehombros de tejido mágico rojos
10030	Sombrero de almirante
10031	Botas de tejido de sombra
10032	Cinta de paño tormentoso
10033	Cinta de tejido mágico roja
10034	Camisa de esmoquin
10035	Pantalones de esmoquin
10036	Chaqueta de esmoquin
10038	Sobrehombros de paño tormentoso
10039	Botas de paño tormentoso
10040	Vestido de boda blanco
10041	Diadema de tejido onírico
10042	Toga de paño cenizo
10043	Ataduras piadosas
10044	Botas de paño cenizo
10045	Pantalones de lino sencillos
10046	Botas de lino sencillas
10047	Falda sencilla
10048	Falda de colores
10049	Hoja de diabolista
10050	Bolsa de tejido mágico
10051	Bolsa de tejido mágico roja
10052	Camisa marcial naranja
10053	Vestido negro sencillo
10054	Camisa de tejido mágico lavanda
10055	Camisa de tejido mágico rosa
10056	Camisa de tejido mágico naranja
10057	Guerrera Tejeocaso
10058	Botas Tejeocaso
10059	Brazales Tejeocaso
10060	Manteo Tejeocaso
10061	Turbante Tejeocaso
10062	Guantes Tejeocaso
10063	Amito Tejeocaso
10064	Pantalones Tejeocaso
10065	Toga Tejeocaso
10066	Fajín Tejeocaso
10067	Guardarrenes rectos
10068	Botas rectas
10069	Brazales rectos
10070	Armadura recta
10071	Capa recta
10072	Guantes rectos
10073	Casco recto
10074	Leotardos rectos
10075	Bufas rectas
10076	Guardabrazos de Lord
10077	Coraza de Lord
10078	Blasón de Lord
10079	Manteo de Lord
10080	Guanteletes de Lord
10081	Faja de Lord
10082	Botas de Lord
10083	Corona de Lord
10084	Musleras de Lord
10085	Espaldares de Lord
10086	Armadura de placas góticas
10087	Guanteletes de placas góticas
10088	Faja de placas góticas
10089	Escarpes góticos
10090	Casco de placas góticas
10091	Leotardos de placas góticas
10092	Bufas de placas góticas
10093	Deflector de aparecido
10094	Avambrazos de placas góticas
10095	Botas de concejal
10096	Puños de concejal
10097	Aro de concejal
10098	Capa de concejal
10099	Guantes de concejal
10100	Sobrehombros de concejal
10101	Pantalones de concejal
10102	Togas de concejal
10103	Fajín de concejal
10104	Guerrera de concejal
10105	Armadura de errante
10106	Botas de errante
10107	Brazales de errante
10108	Capa de errante
10109	Cinturón de errante
10110	Guantes de errante
10111	Sombrero de errante
10112	Leotardos de errante
10113	Sobrehombros de errante
10118	Coraza ornamentada
10119	Grebas ornamentadas
10120	Capa ornamentada
10121	Guanteletes ornamentados
10122	Faja ornamentada
10123	Aro ornamentado
10124	Musleras ornamentadas
10125	Espaldares ornamentados
10126	Brazales ornamentados
10127	Brazales de aparecido
10128	Peto de aparecido
10129	Guanteletes de aparecido
10130	Faja de aparecido
10131	Botas de aparecido
10132	Casco de aparecido
10133	Leotardos de aparecido
10134	Sobrehombros de aparecido
10135	Guerrera de consejero mayor
10136	Brazales de consejero mayor
10137	Botas de consejero mayor
10138	Capa de consejero mayor
10139	Aro de consejero mayor
10140	Guantes de consejero mayor
10141	Pantalones de consejero mayor
10142	Manto de consejero mayor
10143	Toga de consejero mayor
10144	Fajín de consejero mayor
10145	Faja poderosa
10146	Botas poderosas
10147	Braquiales poderosos
10148	Capa poderosa
10149	Guanteletes poderosos
10150	Casco poderoso
10151	Guerrera poderosa
10152	Leotardos poderosos
10153	Bufas poderosas
10154	Faja mercúrica
10155	Grebas mercúricas
10156	Brazales mercúricos
10157	Coraza mercúrica
10158	Guarda mercúrica
10159	Capa mercúrica
10160	Aro mercúrico
10161	Guanteletes mercúricos
10162	Musleras mercúricas
10163	Espaldares mercúricos
10164	Peto de templario
10165	Guanteletes de templario
10166	Faja de templario
10167	Botas de templario
10168	Corona de templario
10169	Quijotes de templario
10170	Espaldares de templario
10171	Brazales de templario
10172	Manto místico
10173	Brazales místicos
10174	Manteo místico
10175	Turbante místico
10176	Guantes místicos
10177	Leotardos místicos
10178	Toga mística
10179	Botas místicas
10180	Cinturón místico
10181	Armadura mística
10182	Coraza de espadachín
10183	Botas de espadachín
10184	Brazales de espadachín
10185	Manteo de espadachín
10186	Guantes de espadachín
10187	Parche de espadachín
10188	Leotardos de espadachín
10189	Hombreras de espadachín
10190	Cinturón de espadachín
10191	Guardabrazos de cruzado
10192	Botas de cruzado
10193	Armadura de cruzado
10194	Capa de cruzado
10195	Escudo de cruzado
10196	Guanteletes de cruzado
10197	Cinturón de cruzado
10198	Yelmo de cruzado
10199	Leotardos de cruzado
10200	Espaldares de cruzado
10201	Grebas de Señor Supremo
10202	Avambrazos de Señor Supremo
10203	Peto de Señor Supremo
10204	Escudo de láminas grueso
10205	Guanteletes de Señor Supremo
10206	Faja de Señor Supremo
10207	Corona de Señor Supremo
10208	Quijotes de Señor Supremo
10209	Bufas de Señor Supremo
10210	Manto elegante
10211	Botas elegantes
10212	Capa elegante
10213	Brazales elegantes
10214	Guantes elegantes
10215	Togas elegantes
10216	Cinturón elegante
10217	Leotardos elegantes
10218	Guerrera elegante
10219	Aro elegante
10220	Guerrera Sombranoche
10221	Faja Sombranoche
10222	Botas Sombranoche
10223	Guardabrazos Sombranoche
10224	Capa Sombranoche
10225	Guantes Sombranoche
10226	Tiara Sombranoche
10227	Leotardos Sombranoche
10228	Bufas Sombranoche
10229	Brazales grabados
10230	Coraza grabada
10231	Manteo grabado
10232	Guanteletes grabados
10233	Faja grabada
10234	Botas grabadas
10235	Yelmo grabado
10236	Leotardos grabados
10237	Espaldares grabados
10238	Botas de láminas pesadas
10239	Avambrazos de láminas pesados
10240	Pechera de láminas pesada
10241	Yelmo de láminas pesado
10242	Guanteletes de láminas pesados
10243	Faja de láminas pesada
10244	Leotardos de láminas pesados
10245	Espaldares de láminas pesados
10246	Jubón de maestro
10247	Botas de maestro
10248	Brazales de maestro
10249	Capa de maestro
10250	Sombrero de maestro
10251	Guantes de maestro
10252	Leotardos de maestro
10253	Manto de maestro
10254	Toga de maestro
10255	Cinturón de maestro
10256	Brazales de aventurero
10257	Botas de aventurero
10258	Manteo de aventurero
10259	Cinturón de aventurero
10260	Guantes de aventurero
10261	Pañuelo de aventurero
10262	Musleras de aventurero
10263	Sobrehombros de aventurero
10264	Guerrera de aventurero
10265	Brazales magistrales
10266	Coraza magistral
10267	Manteo magistral
10268	Guanteletes magistrales
10269	Faja magistral
10270	Botas magistrales
10271	Escudo magistral
10272	Aro magistral
10273	Quijotes magistrales
10274	Espaldares magistrales
10275	Coraza esmeralda
10276	Escarpes esmeralda
10277	Guanteletes Esmeralda
10278	Faja esmeralda
10279	Yelmo esmeralda
10280	Quijotes esmeralda
10281	Espaldares esmeralda
10282	Avambrazos esmeralda
10283	Muestras de corazón de lobo
10285	Seda de las Sombras
10286	Corazón de fiera
10287	Manto de tejido verde
10288	Aro de sabio
10289	Sombrero durable
10290	Tinte rosa
10298	Sortija de Gnomeregan
10299	Amuleto de Gnomeregan
10300	Patrón: jubón de tejido mágico rojo
10301	Patrón: máscara de bandido blanca
10302	Patrón: pantalones de tejido mágico rojos
10303	Patrón: pantalones de paño tormentoso
10304	Patrón: guantes de paño tormentoso
10305	Pergamino de protección IV
10306	Pergamino de espíritu IV
10307	Pergamino de aguante IV
10308	Pergamino de intelecto IV
10309	Pergamino de agilidad IV
10310	Pergamino de fuerza IV
10311	Patrón: camisa marcial naranja
10312	Patrón: guantes de tejido mágico rojos
10313	Patrón: jubón de paño tormentoso
10314	Patrón: camisa de tejido mágico lavanda
10315	Patrón: sobrehombros de tejido mágico rojos
10316	Patrón: falda de colores
10317	Patrón: camisa de tejido mágico rosa
10318	Patrón: sombrero de almirante
10319	Patrón: cinta de paño tormentoso
10320	Patrón: cinta de tejido mágico roja
10321	Patrón: camisa de esmoquin
10322	Patrón: sobrehombros de paño tormentoso
10323	Patrón: pantalones de esmoquin
10324	Patrón: botas de paño tormentoso
10325	Patrón: vestido de boda blanco
10326	Patrón: chaqueta de esmoquin
10327	Cuerno de Echeyakee
10328	Pechera Escarlata
10329	Cinturón Escarlata
10330	Leotardos Escarlata
10331	Guanteletes Escarlata
10332	Botas Escarlata
10333	Guardamuñecas Escarlata
10338	Cadáver reciente de zhebra
10358	Brazales de Duracin
10359	Botas perpetuas
10360	Culebra reina negra
10361	Culebra marrón
10362	Escudo ornamentado
10363	Pared grabada
10364	Escudo de templario
10365	Escudo esmeralda
10366	Guarda de demonio
10367	Escudo Hiperión
10368	Armadura de placas imbuida
10369	Guanteletes de placas imbuidos
10370	Faja de placas imbuida
10371	Grebas de placas imbuidas
10372	Casco de placas imbuido
10373	Leotardos de placas imbuidos
10374	Espaldares de placas imbuidos
10375	Avambrazos de placas imbuidos
10376	Botas de Comandante
10377	Avambrazos de Comandante
10378	Armadura de Comandante
10379	Yelmo de Comandante
10380	Guanteletes de Comandante
10381	Faja de Comandante
10382	Leotardos de Comandante
10383	Espaldares de Comandante
10384	Armadura Hiperión
10385	Grebas Hiperión
10386	Guanteletes Hiperión
10387	Faja Hiperión
10388	Yelmo Hiperión
10389	Quijotes Hiperión
10390	Espaldares Hiperión
10391	Avambrazos Hiperión
10392	Culebra carmesí
10393	Cucaracha
10394	Silbato de perro de la pradera
10398	Gallina mecánica
10399	Armadura ennegrecida Defias
10400	Leotardos ennegrecidos Defias
10401	Guantes ennegrecidos Defias
10402	Botas ennegrecidas Defias
10403	Cinturón ennegrecido Defias
10404	Cinturón durable
10405	Sobrehombros de bandido
10406	Cinta de cuero escamado
10407	Hombreras de asaltante
10408	Yelmo a rayas
10409	Botas a rayas
10410	Leotardos del Colmillo
10411	Escarpines del Colmillo
10412	Cinturón del Colmillo
10413	Guantes del Colmillo
10414	Concha de muestra de Quijaforte
10418	Insignia de mitril de luz trémula
10420	Cráneo del Gélido
10421	Jubón de cobre férreo
10423	Leotardos de bronce bañados en plata
10424	Diseño: Leotardos de bronce bañados en plata
10438	Caja de Félix
10439	Infusión de albaza hirviendo de Durnan
10440	Taza de Nori
10441	Fragmento resplandeciente
10442	Artefacto misterioso
10443	Carta chamuscada
10444	Pistola de bengalas de venta estándar
10445	Material para dibujar
10446	Corazón de Obsidion
10447	Cabeza de Lathoric el Negro
10450	Pluma de hipogrifo sin estropear
10454	Esencia de Eranikus
10455	Esencia encadenada de Eranikus
10456	Un monedero abultado
10457	Caparazón de caracol marino vacío
10458	Rezo a Elune
10459	Cabeza del jefe Cornapunta Mantospina
10460	Sangre Hakkari
10461	Brazales enigmáticos
10462	Cinturón enigmático
10463	Patrón: máscara de tejido de sombra
10464	Bastón de Mando
10465	Huevo de Hakkar
10466	Círculo de Piedras Atal'ai
10467	Cartera de comerciante
10478	Gema de maná de Roland
10479	Cartera comercial de Kovic
10498	Microajustador giromático
10499	Gafas ojo brillante
10500	Gafas de Fuego
10501	Ultragafas ojo de gato
10502	Gafas de poder con hechizos Xtremo
10503	Gafas tintadas de rosa
10504	Lente verde
10505	Pólvora sólida
10506	Casco de inmersión
10507	Dinamita sólida
10508	Trabuco de mitril
10509	Corazón de llama
10510	Rifle de gran calibre de mitril
10511	Aceite gólem
10512	Balas de mitril de gran impacto
10513	Girotiro de mitril
10514	Bomba de fragmentación de mitril
10515	Antorcha de reprensión
10518	Capa paracaídas
10538	Tablilla de Beth'Amara
10539	Tablilla de Jin'yael
10540	Tablilla de Markri
10541	Tablilla de Sael'hai
10542	Casco de minero goblin
10543	Casco de albañil goblin
10544	Gran maza Cardoleño
10545	Gafas gnómicas
10546	Mira mortal
10547	Cuchillo de acampada
10548	Mira de francotirador
10549	Calzas de ranchero
10550	Mitones de lana
10551	Daga bañada en torio
10552	Símbolo de Ragnaros
10553	Jubón de supervisor
10554	Pantalones de supervisor
10556	Círculo de piedra
10558	Núcleo de poder de oro
10559	Tubo de mitril
10560	Activador inestable
10561	Envoltura de mitril
10562	Bomba altamente explosiva
10563	Calco: Runa de Beth'Amara
10564	Calco: Runa de Jin'yael
10565	Calco: Runa de Markri
10566	Calco: Runa de Sael'hai
10567	Lanzapúas
10569	Tesoro oculto del Vuelo Negro
10570	Destripahombres
10571	Garrote de hueso de ébano
10572	Fragmento helado
10573	Atizahuesos
10574	Sudario
10575	Muda de piel de Vuelo Negro
10576	Dragonizo mecánico de mitril
10577	Mortero goblin
10578	Botas Lanzapensamientos
10579	Flecha explosiva
10580	Caja goblin "Bum"
10581	Vestimenta cabeza de la Muerte
10582	Botines de brezo
10583	Arnés contra pinchos
10584	Puños Tempesviento
10585	Radio goblin
10586	La grande
10587	Dispensador de bombas goblin
10588	Casco de cohete goblin
10589	Piedra de juramento del Vuelo de Ysera
10590	Caja negra con agujeros
10592	Elixir de ojo de gato
10593	Trozo draenetista imperfecto
10595	Kum'isha's Junk
10597	Cabeza de Magus Rimtori
10598	Cabeza ensangrentada de Hetaera
10599	Cabeza golpeada de Hetaera
10600	Cabeza amoratada de Hetaera
10601	Esquema: gafas ojo brillante
10602	Esquema: mira mortal
10603	Esquema: ultragafas ojo de gato
10604	Esquema: rifle de gran calibre de mitril
10605	Esquema: gafas de poder con hechizos Xtremo
10606	Esquema: capa paracaídas
10607	Esquema: casco de inmersión
10608	Esquema: mira de francotirador
10609	Esquema: dragonizo mecánico de mitril
10610	Sangre de Hetaera
10620	Mena de torio
10621	Pergamino rúnico
10622	Bandera de Kadrak
10623	Bocado de Invierno
10624	Arco hiriente
10625	Espada de sigilo
10626	Martillo de ira
10627	Cachiporra del perro rictus
10628	Arremetida mortal
10629	Botas de caminaniebla
10630	Halo de cazador de almas
10631	Guanteletes Aguasucia
10632	Brazales de escama de babosa
10633	Leotardos Conchaplata
10634	Círculo del Ojo de la mente
10635	Leotardos de anillas pintados
10636	Guantes nómadas
10637	Guantes de cervecero
10638	Manteo de caída larga
10639	Champiñón jacinto
10640	Icor Tejemadera
10641	Lirio alunado
10642	Antídoto de Iverron
10643	Carta lacrada para Ag'tor
10644	Receta: combustible de cohete goblin
10645	Rayo mortal gnómico
10646	Carga de zapador goblin
10647	Tinta de ingeniero
10648	Papiro en blanco
10649	Fragmento de pesadilla
10650	Melena de jabaespín infestada de peste
10651	Cristal de enfoque Arcano rajado
10652	Voluntad del gigante montés
10653	Botas Traillamarada
10654	Guantes de trenza de yute
10655	Calzones de curruca
10656	Jubón de malla de corteza
10657	Manto Talbar
10658	Galochas del Lodazal
10659	Fragmento de los Pezuña Quebrada
10660	Primera tablilla Mosh'aru
10661	Segunda tablilla Mosh'aru
10662	Huevo de Hakkar relleno
10663	Esencia de Hakkar
10664	Una nota para Magus Rimtori
10678	Nota de Magatha
10679	Nota de Andron
10680	Nota de Jes'rimon
10681	Nota de Xylem
10682	Piedra de juramento de Belnistrasz
10683	Morral de expedicionario
10684	Paracaídas colosal
10686	Égida de batalla
10687	Vial vacío etiquetado como n.º 1
10688	Vial vacío etiquetado como n.º 2
10689	Vial vacío etiquetado como n.º 3
10690	Vial vacío etiquetado como n.º 4
10691	Vial lleno etiquetado como n.º 1
10692	Vial lleno etiquetado como n.º 2
10693	Vial lleno etiquetado como n.º 3
10694	Vial lleno etiquetado como n.º 4
10695	Caja de viales vacíos
10696	Espada Aterravil de azsharita encantada
10697	Daga Aterravil de azsharita encantada
10698	Bastón Aterravil de azsharita encantado
10699	Zarza de Yeh'kinya
10700	Botas encarmine
10701	Botas de Zua'tec
10702	Botas de ogro enigma
10703	Pincho endemoniado
10704	Astilla Uñafría
10705	Braciles de abeto y sauce
10706	Faja de escama nocturna
10707	Grebas de forjador de acero
10708	Orbe de hechizo de calavera
10709	Orbe de piropiedra
10710	Anillo garra de dragón
10711	Collar de sangre de dragón
10712	Elixir de Cuely
10713	Diseño: cilindro de mitril taraceado
10714	Azsharita cristalizada
10715	Mira de Kim'jael
10716	Rayo reductor gnómico
10717	Brújula de Kim'jael
10718	Cachivache de Kim'jael
10719	Alarma móvil
10720	Proyector redomático gnómico
10721	Cinturón de prevención de daño gnómico
10722	Pollo relleno de Kim'jael
10723	Radio gnómica
10724	Botas cohete gnómicas
10725	Gallo de batalla gnómico
10726	Gorro de control mental gnómico
10727	Escopeta dragón goblin
10728	Patrón: camisa de espadachín negra
10738	Envío a Galvan
10739	Anillo de Entereza
10740	Quijotes de Centurión
10741	Casco de Lordrec
10742	Leotardos de Vuelo
10743	Protegecabezas Pirodraco
10744	Hacha del draco ébano
10745	Sobrehombros Kaylari
10746	Avambrazos de acero rúnico
10747	Fajín de maestro
10748	Botas del placer errante
10749	Yelmo de guardia vengador
10750	Puntilla de fuerza de vida
10751	Aro Ráfaga de gemas
10752	Cofre taraceado esmeralda
10753	Amuleto de Grol
10754	Amuleto de Sevine
10755	Amuleto de Allistarj
10757	Resguardo del Rapiñador
10758	X'jalibur
10759	Cuerno de Rapiñador cortado
10760	Puños de puerco
10761	Daga Ira Helada
10762	Togas del Exánime
10763	Barbuta de metal de hielo
10764	Armadura Fríomortal
10765	Dedos de hueso
10766	Rama de podredumbre de peste
10767	Guarda de jabalí indómito
10768	Cinturón de Campeón de jabalí
10769	Ojo resplandeciente de Mordresh
10770	Calavera inerte Mordresh
10771	Fajín de mago de la Muerte
10772	Cuchilla de glotón
10773	Urna Hakkari
10774	Sobrehombros de pellejo
10775	Caparazón de Tuten'kash
10776	Manteo de araña sedosa
10777	Guantes de araña
10778	Collar de Santuario
10779	Sangre de demonio
10780	Marca de Hakkar
10781	Coraza Hakkari
10782	Embozo Hakkari
10783	Bufas Atal'ai
10784	Coraza Atal'ai
10785	Leotardos Atal'ai
10786	Botas Atal'ai
10787	Guantes Atal'ai
10788	Faja Atal'ai
10789	Manual de disciplinas de Ingeniería
10790	Tarjeta de miembro del Club de Ingeniería Gnómica
10791	Tarjeta de miembro del Club de Ingeniería Goblin
10792	Compromiso de secreto perpetuo de Nixx
10793	Compromiso de secreto perpetuo de Sobrechispa
10794	Compromiso de secreto perpetuo de Oglethorpe
10795	Sortija de garra de draco
10796	Piedra draco
10797	Sopla Fuego
10798	Anillo de colmillo de Atal'alarion
10799	Cabeza de pincho
10800	Brazales Aguaoscura
10801	Botas de escamas húmedas
10802	Capa velo alado
10803	Hoja de los desdichados
10804	Puño del condenado
10805	Comedor de muertos
10806	Vestimentas del profeta Atal'ai
10807	Falda del profeta Atal'ai
10808	Guantes del profeta Atal'ai
10818	Pergamino de Yeh'kinya
10819	Pluma de lechúcico salvaje
10820	Cinturón de siembra
10821	Capa de sembrador
10822	Vástago oscuro
10823	Espada del vencedor
10824	Dije Resplandor de Ámbar
10826	Bastón de Conocimiento
10827	Guerrera de perito
10828	Uña funesta
10829	Ojo de dragón
10830	Granada de fragmentación M73
10831	Orbe vil
10832	Manual de rastreador vil
10833	Cuernos de Eranikus
10834	Equipo de rastreador can manáfago
10835	Blasón de Supremacía
10836	Vara de corrosión
10837	Diente de Eranikus
10838	Poderío de Hakkar
10839	Nota cristalizada
10840	Nota cristalizada
10841	Té de espina de oro
10842	Sarong de escamas de viento
10843	Manteo Piel emplumada
10844	Aguja de Hakkar
10845	Abrazo de guerrero
10846	Grebas tirosangre
10847	Llamada del dragón
10858	Diseño: gran maza de hierro sólido
10918	Veneno hiriente
10919	Guantes de boticario
10920	Veneno hiriente II
10921	Veneno hiriente III
10922	Veneno hiriente IV
10938	Esencia mágica inferior
10939	Esencia mágica superior
10940	Polvo extraño
10958	Collar de Hilary
10959	Saco de pellejo de demonio
10978	Fragmento de luz trémula pequeño
10998	Esencia astral inferior
10999	Ferrovil
11000	Llave de Forjatiniebla
11018	Tierra de Un'Goro
11020	Faltriquera de siempreverde
11022	Paquete de semillas Tharlendris
11023	Pollo de Ancona
11024	Semillero de siempreverde
11026	Carcasa de rana de árbol
11027	Caja de rana de bosque
11038	Fórmula: encantar arma de 2M: espíritu inferior
11039	Fórmula: encantar capa: agilidad menor
11040	Mañagrana
11058	Aro de la nariz de Sha'ni
11078	Llave del arca de reliquias
11079	Cabeza cortada de Gor'tesh
11080	Cabeza cortada de Gor'tesh
11081	Fórmula: encantar escudo: protección inferior
11082	Esencia astral superior
11083	Polvo de alma
11084	Fragmento con luz trémula grande
11085	Llave del arca del cliente del mes
11086	Jang'thraze la Protectora
11098	Fórmula: encantar capa: Resistencia a las Sombras inferior
11099	Mena de hierro negro
11101	Fórmula: encantar brazales: fuerza inferior
11102	Huevo sin abrir de duende dardo
11103	Vale para semillas
11104	Brújula grande
11105	Papiro de mapa enrollado
11106	Llave con cabeza de león
11107	Un paquetito
11108	Fotografía descolorida
11109	Comida para pollos especial
11110	Huevo de gallina
11111	Huevo roto de duende dardo
11112	Equipo de investigación
11113	Cajón de comestibles
11114	Hueso de dinosaurio
11115	Llave de caja fuerte secreta
11116	Un diario destrozado
11118	Piedra arcádica
11119	Cosecha de Milly
11120	Martillo de Belgrom
11121	Talwar Aguaoscura
11122	Zanahoria pinchada en un palo
11123	Leotardos de zancalluvia
11124	Yelmo de Exilio
11125	Informe de la vendimia
11126	Tablilla de Kurniya
11127	Mercancías extraviadas
11128	Vara dorada
11129	Esencia de los elementos
11130	Vara rúnica de oro
11131	Muestra de pared de colmena
11132	Vial de raspadura sin usar
11133	Espada de entrenamiento de Linken
11134	Esencia mística inferior
11135	Esencia mística superior
11136	Espada templada de Linken
11137	Polvo de visión
11138	Fragmento resplandeciente pequeño
11139	Fragmento resplandeciente grande
11140	Llave de celda de prisión
11141	Cebo
11142	Churumbele roto
11143	Engranaje
11144	Vara de veraplata
11145	Vara rúnica de veraplata
11146	Churumbele roto y maltrecho
11147	Cubierta del manual del churumbele
11148	Página del manual del churumbele
11149	Manual del churumbele
11150	Fórmula: encantar guantes: minería
11151	Fórmula: encantar guantes: herboristería
11152	Fórmula: encantar guantes: pesca
11162	Espada de excelencia de Linken
11163	Fórmula: encantar brazal: desvío inferior
11164	Fórmula: encantar arma: Destripadora de bestias inferior
11165	Fórmula: encantar arma: mataelementales inferior
11166	Fórmula: encantar guantes: desuello
11167	Fórmula: encantar botas: espíritu inferior
11168	Fórmula: encantar escudo: bloqueo inferior
11169	Libro de Aquor
11171	Hierro vil
11172	Garras de plata
11173	Corazón de Troncoferro
11174	Esencia abisal inferior
11175	Esencia abisal superior
11176	Polvo onírico
11177	Fragmento radiante pequeño
11178	Fragmento radiante grande
11179	Llama dorada
11184	Cristal de poder azul
11185	Cristal de poder verde
11186	Cristal de poder rojo
11187	Brazales de tallo
11188	Cristal de poder amarillo
11189	Togas de los bosques
11190	Guantes de parra
11191	Botas de granjero
11192	Guantes de modisto
11193	Coraza Viento abrasador
11194	Camisote de escama prismática
11195	Peto forjado por la guerra
11196	Medallón de ráfaga mental
11197	Llave de guarda oscuro
11198	Runa de escape
11199	Escudo de ingeniero 1
11200	Escudo de ingeniero 2
11201	Escudo de ingeniero 3
11202	Fórmula: encantar escudo: aguante
11203	Fórmula: encantar guantes: minería avanzada
11204	Fórmula: encantar brazales: espíritu superior
11205	Fórmula: encantar guantes: herboristería avanzada
11206	Fórmula: encantar capa: Agilidad inferior
11207	Fórmula: encantar arma: arma ígnea
11208	Fórmula: encantar arma: matanza de demonios
11222	Cabeza de Krom'zar
11223	Fórmula: encantar brazal: desvío
11224	Fórmula: encantar escudo: Resistencia a la Escarcha
11225	Fórmula: encantar brazales: aguante superior
11226	Fórmula: encantar guantes: equitación
11227	Trozo del estandarte de Krom'zar
11228	Muda de piel de Vuelo demente
11229	Faja de escamas brillantes
11230	Esencia ígnea encerrada
11231	Muda de piel de Vuelo Negro alterada
11242	Raíz del mal
11243	Elixir de Videre
11262	Orbe de Lorica
11263	Varita de fuerza abisal
11265	Gran maza de riscoleño
11266	Fragmento elemental fracturado
11267	Muestra de fragmento elemental
11268	Cabeza de Argelmach
11269	Núcleo de elemental intacto
11270	Compromiso firmado de Nixx
11282	Compromiso firmado de Oglethorpe
11283	Compromiso de secreto perpetuo firmado de Sobrechispa
11284	Balas de precisión
11285	Flecha dentada
11286	Grilletes de torio
11287	Varita mágica inferior
11288	Varita mágica superior
11289	Varita mística inferior
11290	Varita mística superior
11291	Madera de estrella
11302	Fuerza de Uther
11303	Arco corto refinado
11304	Arco largo refinado
11305	Arco corto denso
11306	Arco corvo sólido
11307	Arco largo macizo
11308	Arco corto nemoroso
11309	El corazón de la montaña
11310	Manto de vidente de llamas
11311	Manteo de escamas de ascuas
11312	Receta de Cebatruenos perdida
11313	Cabeza de Ribbly
11315	Brote sangrepétalo
11316	Sangrepétalo
11318	Calima Atal'ai
11319	Controlador descargado
11320	Liquidador de sangrepétalos
11324	Morral de expedicionario
11325	Jarra de cerveza Hierro Negro
11362	Carcaj medio
11363	Faltriquera de pólvora media
11364	Tabardo de Ventormenta
11366	Carta de Helendis Rivacuerno
11367	Petición de Solomon para Bolvar
11368	Decreto de Bolvar
11370	Mena de hierro negro
11371	Barra de hierro negro
11382	Sangre de la montaña
11384	Diente de basilisco partido
11385	Escama de basilisco
11386	Ojo de basilisco fangoso
11387	Corazón de basilisco
11388	Veneno de basilisco
11389	Piel de basilisco fulgurante
11390	Colmillo de murciélago partido
11391	Ala de murciélago con púas
11392	Garra de murciélago cortada
11393	Calavera de murciélago pequeño
11394	Corazón de murciélago
11395	Oreja de murciélago
11402	Pelambre de murciélago impoluta
11403	Colmillo de murciélago grande
11404	Ojo de murciélago maligno
11405	Veta gigante de plata
11406	Cadáver de oso en descomposición
11407	Pelambre de oso rasgada
11408	Mandíbula de oso
11409	Costillar de oso
11410	Garra de oso indómito
11411	Hueso de oso grande
11412	Vial de Nagmara
11413	Vial de Nagmara lleno
11414	Melena grisácea
11415	Bayas variadas
11416	Caja torácica delicada
11417	Ala emplumada
11418	Hueso hueco de ala
11419	Huevo sin abrir misterioso
11420	Utensilio de escritura elegante
11422	Obsequio de renovación de ingeniero goblin
11423	Obsequio de renovación de ingeniero gnomo
11442	Juego de diputado de Ventormenta
11444	Jabalí Tragapenas
11445	Flauta de los antiguos
11446	Una nota arrugada
11462	Cuchillo desechado
11463	Paquete sin entregar
11464	Información perdida del mariscal Windsor
11465	Información perdida del mariscal Windsor
11466	Informe de Raschal
11467	Medallón Roca Negra
11468	Riñonera Hierro Negro
11469	Brazales de Bandasangre
11470	Trascripción de tablilla
11471	Huevo de duende dardo frágil
11472	Costillar de acechador melenargenta
11473	PX83-Enigmatrón
11474	Huevo de duende dardo
11475	Capa manchada de vino
11476	Pelambre de U'cha
11477	Garra blanca de ravasaurio
11478	Pelambre de gorila de Un'Goro
11479	Pelambre de vapuleador de Un'Goro
11480	Pelambre de tronador de Un'Goro
11482	Manual de instrucciones de la torre de cristal
11502	Sobrehombros de piel de conocimiento
11503	Ámbar de sangre
11504	Trozo de trillanodonte muerto
11507	Pelambre de hiena moteada
11508	Zapatillas de maestro de juego
11509	Glándula de feromonas de ravasaurio
11510	Cabeza de Lar'korwi
11511	Antorcha Cenarion
11512	Parche de piel contaminada
11513	Vitriolo corrupto
11514	Trepadora vil
11515	Fragmento de alma corrupto
11516	Bálsamo de planta Cenarion
11522	Tótem de plata de Aquamentas
11562	Cristal de restauración
11563	Fuerza de cristal
11564	Resguardo de cristal
11565	Reducción de cristal
11566	Carga de cristal
11567	Aguja de cristal
11568	Faltriquera de Torwa
11569	Carne de trillanodonte en conserva
11570	Mezcla de feromonas en conserva
11582	Bálsamo vil
11583	Manzana de cactus
11584	Sorpresa de manzana de cactus
11590	Equipo de reparación mecánica
11602	Llave de Tragapenas
11603	Cercenadora desgarravil
11604	Placa Hierro Negro
11605	Sobrehombros Hierro Negro
11606	Malla Hierro Negro
11607	Taladora Hierro Negro
11608	Pulverizador Hierro Negro
11609	Muda de piel de Vuelo Negro alterada
11610	Diseño: pulverizador Hierro Negro
11611	Diseño: Taladora Hierro Negro
11612	Diseño: placa Hierro Negro
11614	Diseño: malla Hierro Negro
11615	Diseño: sobrehombros Hierro Negro
11617	Provisiones de Eridan
11622	Arcanum de Reflexión inferior
11623	Manteo de lanzaduendes
11624	Amito duro
11625	Esfera embrujada
11626	Manteo de velo negro
11627	Grebas de Pie de flota
11628	Arco del maestro de canes
11629	Rifle del maestro de canes
11630	Perdigones de roca
11631	Guarda petravalva
11632	Sobrehombros Escoria térrea
11633	Caparazón colmillo de araña
11634	Guantes de tela de seda
11635	Faca gancho
11642	Arcanum de Constitución inferior
11643	Arcanum de Tenacidad inferior
11644	Arcanum de Temple inferior
11645	Arcanum de Voracidad inferior
11646	Arcanum de Voracidad inferior
11647	Arcanum de Voracidad inferior
11648	Arcanum de Voracidad inferior
11649	Arcanum de Voracidad inferior
11662	Fajín Ban'thok
11665	Puños de vigía ogro
11668	Flauta de Xavaric
11669	Anillo de gran poder
11674	Lazo vil de fuego de jade
11675	Botas Sombra demoníaca
11677	Manteo de podredumbre de tumba
11678	Caparazón de Anub'shiah
11679	Guardabrazos rubicundos
11682	Vial de Eridan
11684	Ferromazo
11685	Sobrehombros de pellejo escindido
11686	Faja de Furia bestial
11702	Desollador de Grisez
11703	Faja muro de piedra
11722	Bufas de posometal
11723	Flameberge equilibrado de Buenacero
11724	Paquete con retraso
11725	Pata de cristal sólido
11726	Cota de malla de Gladiador indómito
11727	Libro de contabilidad de Buenacero
11728	Leotardos de Gladiador indómito
11729	Yelmo de Gladiador indómito
11730	Mandiletes de Gladiador indómito
11731	Grebas de Gladiador indómito
11732	Tratado sobre reflexión
11733	Tratado sobre constitución
11734	Tratado sobre tenacidad
11735	Parche Furia Ardiente
11736	Tratado sobre resistencia
11737	Tratado sobre voracidad
11742	Morral de caminante
11743	Puño de peñasco
11744	Puñosangre
11745	Puños de Falange
11746	Yelmo calavera gólem
11747	Togas de zancudo flamígero
11748	Caduceo pírico
11749	Leotardos de escamas abrasadoras
11750	Báculo de astillas
11751	Esencia ardiente
11752	Sangre negra de los Atormentados
11753	Ojo de Kajal
11754	Diamante negro
11755	Collera de Verek
11764	Braquiales de pellejo de ceniza
11765	Guardamuñecas de piromalla
11766	Puños de tejido flamígero
11767	Guardabrazos de placas de ascuas
11768	Brazales incendiarios
11782	Manto boreal
11783	Faja de acero frío
11784	Hoja de mediador
11785	Baluarte gólem de roca
11786	Piedra de la Tierra
11787	Botas de esquisto
11802	Leotardos de cresta de lava
11803	Fuerza de magma
11804	Cantimplora de Spraggle
11805	Martillo de rubidio
11807	Fajín del Corazón ardiente
11808	Círculo de la llama
11809	Cólera de llamas
11810	Fuerza de voluntad
11811	Corazón humeante de la montaña
11812	Manteo de la Salamandra de Fuego
11813	Fórmula: Corazón humeante de la montaña
11814	Puños de arrabio
11815	Mano de la Justicia
11816	Hacha de batalla de Forjainquina
11817	Espada de Lord General
11818	Llave de la letrina de Limugre
11819	Segundo aliento
11820	Armadura decorada real
11821	Leotardos de conflicto de guerra
11822	Botas omnitiro
11823	Falda luminaria
11824	Sortija ciclópea
11825	Bombita
11826	Humillo
11827	Esquema: Humillo
11828	Esquema: Bombita
11829	Cenizas de Un'Goro
11830	Escama de diemetradón palmeada
11831	Escama de pterrordáctilo palmeada
11832	Ráfaga de conocimiento
11833	Cebo de la reina Gorishi
11834	Alquitrán muy pegajoso
11835	Cerebro de la reina Gorishi
11837	Glándula secretora de olor Gorishi
11839	Monóculo de arquitecto jefe
11840	Camisa de maestro constructor
11841	Bombachos de diseñador sénior
11842	Manto de perito jefe
11843	Vale bancario
11844	Informe de Un'Goro de Morterozugg
11845	Bolsa de cuero hecha a mano
11846	Brebaje especial de Zumbang
11847	Capa maltrecha
11848	Cinturón de lienzo
11849	Brazales de metal oxidados
11850	Manteo corto de murciumbrío
11851	Guerrera de carroñero
11852	Leotardos de trashumante
11853	Botas de senderismo
11854	Destornillador de churumbele
11855	Llave inglesa de Tork
11856	Hoja élfica ceremonial
11857	Vara santificada
11858	Manteo de batalla dura
11859	Orbe Luna de jade
11860	Vara relámpago cargada
11861	Faja de Represalia
11862	Sortija de hueso blanca
11863	Trituradora de hueso blanca
11864	Lanza de hueso blanca
11865	Botas de rencor
11866	Cinturón de castigo de Nagmara
11867	Guanteletes enloquecedores
11868	Sortija de apnea
11869	Sortija de Sha'ni
11870	Orbe de olvido
11871	Bufas de ladino
11872	Grebas de rehuida
11873	Manteo de niebla etérea
11874	Manto de las nubes
11875	Brazales de la Brisa
11876	Guerrera de acechador de las llanuras
11882	Leotardos de escolta
11883	Una riñonera deslucida
11884	Amito luz lunar
11885	Antorcha de Forjatiniebla
11886	Mensaje urgente
11887	Carretilla del Círculo Cenarion
11888	Guantes de investigación de Quintis
11889	Espaldares de cortezaférrea
11902	Espada de maestría de Linken
11903	Jaula para gatos (gatito corrupto)
11904	Espíritu de Aquamentas
11905	Bumerán de Linken
11906	Machacabestias
11907	Destripadora de bestias
11908	Botas de cantera de arqueólogo
11909	Cinturón de herramientas de excavador
11910	Musleras con joyas
11911	Leotardos de copa de árbol
11912	Paquete de contenedores de moco vacíos
11913	Yelmo de Clayridge
11914	Tarro de moco maldito vacío
11915	Frenalloviznas de Shizzle
11916	Bozal de Shizzle
11917	Escamondador de Shizzle
11918	Guantes de gruta
11919	Grebas de placas de risco
11920	Guadaña de ánima
11921	Gigante impasible
11922	Hoja con grabados de sangre
11923	El martillo de Gracia
11924	Togas de la Corona real
11925	Embozo fantasmal
11926	Coraza de mortífero
11927	Quijotes del Guardián eterno
11928	Cetro real de Thaurissan
11929	Leotardos de espectro inquietante
11930	El nuevo manteo del emperador
11931	Vengador Forjaterrible
11932	Báculo de sabiduría orientador
11933	Joya imperial
11934	Sello de emperador
11935	Piedra Magmus
11936	Cinturón de cazador de reliquias
11937	Saco de monedas gordo
11938	Saco de gemas
11939	Pulsera lustrosa
11940	Collar brillante
11941	Documentos falsos
11942	Documentos legales
11943	Escritura del Puente Thandol
11944	Botitas de bebé Hierro Negro
11945	Anillo Hierro Negro
11946	Collar de ópalo de fuego
11947	Tarro lleno de moco maldito
11948	Tarro de moco corrupto vacío
11949	Tarro de moco corrupto lleno
11950	Bayas de flor de viento
11951	Tubérculo de blancoria
11952	Aliento de Dragón nocturno
11953	Tarro de muestras puras vacío
11954	Tarro de muestra pura lleno
11955	Bolsa de contenedores de lodo vacíos
11962	Esposas
11963	Bufas de penitencia
11964	Cayada Golpepresto
11965	Anillo de cuarzo
11966	Saco de monedas pequeño
11967	Sortija de circón
11968	Aro ámbar
11969	Círculo de jacinto
11970	Anillo de espinela
11971	Sortija de amatista
11972	Anillo carneliano
11973	Eslabón de hematites
11974	Anillo de aguamarina
11975	Anillo de topacio
11976	Hueso Sardonyx
11977	Aro serpentino
11978	Eslabón de jaspe
11979	Círculo de peridoto
11980	Anillo ópalo
11981	Sortija de plomo
11982	Sortija viridiana
11983	Anillo de cromo
11984	Anillo de cobalto
11985	Anillo cerúleo
11986	Aro de talio
11987	Círculo iridio
11988	Sortija de telurio
11989	Anillo de vanadio
11990	Anillo de selenio
11991	Anillo de mercurio
11992	Sortija bermellón
11993	Anillo de terracota
11994	Sortija de coral
11995	Sortija de marfil
11996	Anillo de basalto
11997	Círculo de piedra verde
11998	Aro de azabache
11999	Aro de magnetita
12000	Cuchilla de extremidad
12001	Anillo de ónice
12002	Círculo de mármol
12003	Cerveza negra enana
12004	Sortija de obsidiana
12005	Anillo de granito
12006	Anillo de prado
12007	Anillo de pradera
12008	Anillo de sabana
12009	Anillo tundra
12010	Anillo de pantano
12011	Aro de bosque
12012	Anillo de marisma
12013	Anillo del desierto
12014	Anillo ártico
12015	Anillo del pantano
12016	Anillo de la selva
12017	Sortija centelleante
12018	Yelmo de conservador
12019	Dije cerúleo
12020	Gargantilla de talio
12021	Escarpes de escudo de placas
12022	Cadena iridio
12023	Collar de telurio
12024	Dije de vanadio
12025	Cadena de selenio
12026	Colgante de mercurio
12027	Collar bermellón
12028	Collar de basalto
12029	Dije de piedra verde
12030	Cadena de azabache
12031	Collar de magnetita
12032	Gargantilla de ónice
12033	Joyas de familia Thaurissan
12034	Collar de mármol
12035	Colgante de obsidiana
12036	Collar de granito
12037	Carne misteriosa
12038	Sello de Lagrave
12039	Collar tundra
12040	Colgante de bosque
12041	Leotardos Cortaviento
12042	Cadena de Mar'li
12043	Gargantilla del desierto
12044	Colgante ártico
12045	Colgante del pantano
12046	Collar de la selva
12047	Collar espectral
12048	Colgante centelleante
12049	Armadura de acero seccionador
12050	Botas de calima
12051	Guanteletes de latón
12052	Anillo de la Luna
12053	Anillo de roca volcánica
12054	Sortija de demonio
12055	Sortija de polvo de estrellas
12056	Anillo de los cielos
12057	Sortija de dragontina
12058	Anillo de hueso demoníaco
12059	Medallón de conquistador
12060	Nota de Shindrell
12061	Hoja de Juicio
12062	Hoja apta para la lucha
12064	Caperuza de maestro de juego
12065	Resguardo contra los Elementos
12066	Manteo Piel de esquisto
12082	Bufas de pellejo de vermis
12083	Fajín valconiano
12102	Anillo del Aristócrata
12103	Estrella de Mystaria
12104	Guerrera espinapinta
12105	Leotardos de malla de orgullo
12106	Coraza de piel de roca
12107	Leotardos de seda susurradora
12108	Armadura de escamas de basalto
12109	Amito de luna azur
12110	Mantón de lanzalluvias
12111	Guanteletes de placas de lava
12112	Brazales de demonio de cripta
12113	Manteo nacido del Sol
12114	Guantes Ocaso
12115	Agarre de adepto
12122	Basura de Kum'isha
12143	Llave de espinazo de dragón
12144	Ovosciloscopio
12162	Diseño: espada corta de hierro endurecido
12163	Diseño: espada ancha de acero lunar
12164	Diseño: hacha de hierro macizo
12184	Carne de raptor
12185	Sombrero de almirante Velasangre
12190	Poción de letargo sin sueños
12191	Arcón del Amanecer de Plata
12192	Arcón del Halo de bruma
12202	Carne de tigre
12203	Carne de lobo rojo
12204	Carne de kodo pesada
12205	Carne de araña blanca
12206	Carne de cangrejo tierna
12207	Huevo gigante
12208	Carne de lobo tierna
12209	Filete de lobo magro
12210	Raptor asado
12211	Costillas de lobo especiadas
12212	Estofado de la selva
12213	Sorpresa de carroña
12214	Estofado misterioso
12215	Estofado de kodo pesado
12216	Chili de cangrejo especiado
12217	Ají aliento de dragón
12218	Tortilla gigante
12219	Sello de ascensión sin adornar
12220	Brazal elemental intacto
12223	Ala de murciélago carnosa
12224	Ala de murciélago crujiente
12225	Caña de pescar de la familia Blump
12226	Receta: ala de murciélago crujiente
12227	Receta: filete de lobo magro
12228	Receta: raptor asado
12229	Receta: costillas de lobo picantes
12230	Muestra de babosa de Frondavil
12231	Receta: estofado de la selva
12232	Receta: sorpresa de carroña
12233	Receta: estofado misterioso
12234	Muestra de Frondavil corrupta
12235	Muestra de babosa de Un'Goro
12236	Muestra de Un'Goro pura
12237	Trozos de cangrejo de gran calidad
12238	Mero de Costa Oscura
12239	Receta: ají aliento de dragón
12240	Receta: estofado de kodo pesado
12241	Huevo de dragón recogido
12242	Huesos de criatura marina
12243	Garra humeante
12247	Cuchillo de hoja ancha
12248	Puntilla temeraria
12249	Hacha despiadada
12250	Hacha de medianoche
12251	Palo grande
12252	Bastón de Protección
12253	Capa roja luminosa
12254	Capa bien aceitada
12255	Leotardos pálidos
12256	Leotardos de paño cenizo
12257	Cinturón con muchas marcas
12258	Cinturón de pinza de serpiente
12259	Daga de acero destellante
12260	Hoja dorada abrasadora
12261	Diseño: hoja dorada abrasadora
12262	Jaula de cachorro de huargo vacía
12263	Cachorro de huargo enjaulado
12264	Transportador de huargos
12282	Hacha de batalla desgastada
12283	Esencia de cría
12284	Draco-Incarcinatrix 900
12286	Prototipo de ovosciloscopio
12287	Módulo colectrónico
12288	Moco corrupto encerrado
12289	Restos de tortuga marina
12291	Muestra de moco fusionado
12292	Caja con símbolos extraños
12293	Hilo de oro refinado
12295	Leotardos de La Milicia Popular
12296	Chispa de La Milicia Popular
12299	Guantes de red
12300	Orbe de energía dracónica
12301	Llave de jaula de bambú
12302	Riendas del sable de hielo
12303	Riendas del sable de la noche
12323	Sello de ascensión sin forjar
12324	Sello de ascensión forjado
12325	Riendas del leopardo primigenio
12326	Riendas del dientes de sable leonado
12327	Riendas del dientes de sable dorado
12330	Cuerno del lobo rojo
12334	Esquirlas de Machacahielo
12335	Gema de Espina Ahumada
12336	Gema de Cumbrerroca
12337	Gema de Hacha de Sangre
12339	Obsequio de Vaelan
12341	Muestra de fruta Bosque Negro
12342	Muestra de grano Bosque Negro
12343	Muestra de nuez Bosque Negro
12344	Sello de ascensión
12345	Pertenencias de Bijou
12346	Cuenco de purificación vacío
12347	Cuenco de purificación lleno
12349	Muestra del Río Fonroca
12350	Tubo de ensayo vacío
12351	Cuerno del lobo ártico
12352	Broche de Equipasino
12353	Brida de semental blanco
12354	Brida de Palomino
12355	Dije de corrupción
12356	Huevo de dracoleón de Nido Alto
12358	Tablilla de Rocanegra
12359	Barra de torio
12360	Barra de arcanita
12361	Zafiro azul
12363	Cristal Arcano
12364	Esmeralda enorme
12365	Piedra densa
12366	Pelaje de yeti grueso
12367	Cuerno prístino de yeti
12368	Gambito del Alba
12369	Cetro de Vectus
12382	Llave de la ciudad
12383	Pluma Lunadón
12384	Alijo de Mau'ari
12402	Huevo antiguo
12404	Piedra de afilar densa
12405	Armadura de torio
12406	Cinturón de torio
12408	Brazales de torio
12409	Botas de torio
12410	Yelmo de torio
12411	Tercera tablilla Mosh'aru
12412	Cuarta tablilla Mosh'aru
12414	Leotardos de torio
12415	Coraza radiante
12416	Cinturón radiante
12417	Aro radiante
12418	Guantes radiantes
12419	Botas radiantes
12420	Leotardos radiantes
12422	Peto de placas imperiales
12424	Cinturón de placas imperiales
12425	Brazales de placas imperiales
12426	Botas de placas imperiales
12427	Yelmo de placas imperiales
12428	Sobrehombros de placas imperiales
12429	Leotardos de placas imperiales
12430	E'ko de sable de hielo
12431	E'ko Nevada
12432	E'ko Dentoesquirla
12433	E'ko de lechúcico salvaje
12434	E'ko Orvallo
12435	E'ko de los Cardo Nevado
12436	E'ko de los Machacahielo
12437	Caja de Bonacresta
12438	Carta de Tinkee
12440	Magic Knucklebone (DND)
12442	Charm Pouch (DND)
12443	Knucklebone Pouch (DND)
12444	Cuerno de quimera Orvallo
12445	Talega de Felnok
12446	Mosquete Yunquemar
12447	Arco Cardoleño
12448	Rifle de caza ligero
12449	Arco primitivo
12450	Aluvión Juju
12451	Poder Juju
12455	Ascua Juju
12457	Escalofrío Juju
12458	Astucia Juju
12459	Escape Juju
12460	Poderío Juju
12462	Abrazo de la serpiente alada
12463	Cuchillo carnicero de colmillo de draco
12464	Garfas de las Llamas de Sangre
12465	Mantón Ocaso
12466	Cordón de espiral del Alba
12467	Huevo extraño
12468	Varita Chilton
12469	Mutilador
12470	Tobilleras acecharenas
12471	Bastón de Caminadesiertos
12472	Termómetro de Krakle
12522	Guantes voladores de Bingles
12524	Amuleto de plumas azules
12525	Suministros de Jaron
12527	Partecostillas
12528	El mazo del juez
12529	Jaula de Telabrasada
12530	Huevo de araña de la cumbre
12531	Aguja abrasadora
12532	Aguja del Tallapiedras
12533	Pica férrea
12534	Cabeza de Omokk
12535	Regla de Forja Maldita
12542	Vestimentas de pira funeraria
12543	Piedracanto de Forjaz
12544	Resolución de Thrall
12545	Ojo de Orgrimmar
12546	Puños de aristócrata
12547	Mandilete de Mar Alom
12549	Cajasesos
12550	Grilletes rúnicos de gólems
12551	Capa escudo de piedra
12552	Herreruelo Aterrabojas
12553	Botas Caminapresto
12554	Manos del Heraldo exaltado
12555	Grebas Belicutor
12556	Botas de Suma Sacerdotisa
12557	Bufas de acero de ébano
12558	Collar de plumas azules
12562	Importantes documentos de Roca Negra
12563	Orden del señor de la guerra Dientegore
12564	Nota de asesinato
12565	Transportador de gatitos de Winna
12566	Frasquito endurecido
12567	Frasquito lleno
12582	Kris de Zul'Serak
12583	Sierra de fatalidad de Puño Negro
12584	Tizona de Gran mariscal
12585	Medallón de Ventormenta
12586	Glándula de veneno inmadura
12587	Ojo de Rend
12588	Sobrehombros de huesopúa
12589	Fajín pluma de polvo
12590	Daga vil
12592	Hoja negra de Shahram
12602	Deflector draconiano
12603	Guerrera de la noche
12604	Tiara de fuego estelar
12605	Calaverador serpentino
12606	Faja cristalizada
12607	Escamas cromáticas luminosas
12608	Delantal de carnicero
12609	Atadura de visión policromática
12610	Sobrehombros rúnicos de placas
12611	Botas rúnicas de placas
12612	Yelmo de placas rúnicas
12613	Coraza rúnica
12614	Leotardos de placas rúnicas
12615	Guerrera de malla indómita
12616	Botas de malla indómita
12617	Sobrehombros de malla indómita
12618	Coraza de torio encantado
12619	Leotardos de torio encantado
12620	Yelmo de torio encantado
12621	Horqueta de demonio
12622	Carne Dentoesquirla
12623	Carne de Orvallo
12624	Malla Espina Salvaje
12625	Sobrehombros Albar
12626	Puños de funeral
12627	Desplazador temporal
12628	Coraza de demonio forjada
12630	Cabeza de Rend Puño Negro
12631	Guanteletes de placas ígneas
12632	Guanteletes de tormenta
12633	Yelmo almablanca
12634	Faja de cincelador
12635	Papiro simple
12636	Yelmo del gran jefe
12637	Guanteletes de Backus
12638	Reloj de Andorhal
12639	Guanteletes bastión
12640	Yelmo corazón de león
12641	Malla invulnerable
12642	Orbe infernal limpio
12643	Contrapeso denso
12644	Piedra de pulir densa
12645	Punta de escudo de torio
12646	Esmeralda infus
12647	Rubí de Felhas
12648	Espíritu de can manáfago encarcelado
12649	Espíritu infernal encarcelado
12650	Atenuador armonizado
12651	Cuervo negro
12652	Informe de reconocimiento de Bijou
12653	Garfio desgarrador
12654	Tiro maldito
12655	Barra de torio encantado
12662	Runa demoníaca
12663	Rama de roble con inscripciones
12682	Diseño: armadura de torio
12683	Diseño: cinturón de torio
12684	Diseño: brazales de torio
12685	Diseño: cinturón radiante
12687	Diseño: sobrehombros de placas imperiales
12688	Diseño: cinturón de placas imperiales
12689	Diseño: coraza radiante
12690	Diseño: brazales de placas imperiales
12691	Diseño: malla Espina Salvaje
12692	Diseño: punta de escudo de torio
12693	Diseño: botas de torio
12694	Diseño: yelmo de torio
12695	Diseño: guantes radiantes
12696	Diseño: coraza de demonio forjada
12697	Diseño: botas radiantes
12698	Diseño: sobrehombros Albar
12699	Diseño: guanteletes de placas ígneas
12700	Diseño: botas de placas imperiales
12701	Diseño: yelmo de placas imperiales
12702	Diseño: aro radiante
12703	Diseño: guanteletes de tormenta
12704	Diseño: leotardos de torio
12705	Diseño: peto de placas imperiales
12706	Diseño: Sobrehombros rúnicos de placas
12707	Diseño: botas rúnicas de placas
12708	Cajón de suministros de El Cruce
12709	Despellejador de Pip
12710	Trozo resplandeciente de carne de la Bestia
12711	Diseño: yelmo almablanca
12712	Mojo de Warosh
12713	Diseño: leotardos radiantes
12714	Diseño: yelmo de placas rúnicas
12715	Diseño: leotardos de placas imperiales
12716	Diseño: yelmo del gran jefe
12717	Diseño: yelmo corazón de león
12718	Diseño: coraza rúnica
12719	Diseño: leotardos de placas rúnicas
12720	Diseño: guanteletes bastión
12721	Medio talismán de buena suerte
12722	Otro medio talismán de buena suerte
12723	Talismán de buena suerte
12724	Paquete de Janice
12725	Diseño: yelmo de torio encantado
12726	Diseño: leotardos de torio encantado
12727	Diseño: coraza de torio encantado
12728	Diseño: malla invulnerable
12730	Pergamino de Warosh
12731	Pellejo de la Bestia prístino
12732	Pita incendiaria
12733	Carne de sable de hielo sacra
12734	Hilo escarlata encantado
12735	Costuras desgarradas de abominación
12736	Líquido de embalsamar de Murmuhielo
12737	Hierba luminiscente
12738	Llave de la letrina de Dalson
12739	Llave del armario de Dalson
12740	Quinta tablilla Mosh'aru
12741	Sexta tablilla Mosh'aru
12752	Almete del Sabio Escarlata
12753	Piel de Sombra
12756	Leotardos de Arcana
12757	Coraza Sed de Sangre
12762	Secreto de diseños
12763	Fruta de éter de Un'Goro
12764	Espada magna de torio
12765	Nota secreta n.º 1
12766	Nota secreta n.º 2
12768	Nota secreta n.º 3
12769	Talladora de Picomadera
12770	Información de Bijou
12771	Frasco vacío de aguardiente
12772	Martillo de torio taraceado
12773	Hacha de mano de torio ornamentada
12774	Filo del Alba
12775	Hacha de batalla de torio enorme
12776	Martillo de batalla encantado
12777	Estoque llameante
12778	Cofre de documentos
12779	Filo rúnico
12780	Orden del general Drakkisath
12781	Serenidad
12782	Corrupción
12783	Buscacorazones
12784	Segadora de arcanita
12785	Polvo de incendiaria
12790	Campeona de arcanita
12791	Casco de camarero
12792	Martillo volcánico
12793	Guerrera de mixólogo
12794	Martillo de tormenta magistral
12795	Garfa sangrienta
12796	Martillo de los titanes
12797	Guardia de Escarcha
12798	Aniquiladora
12799	Ópalo grande
12800	Diamante de Azeroth
12802	Lanza Negra
12803	Esencia viva
12804	Mojo potente
12805	Orbe de Fuego
12806	Coraza cubierta de runas sin forjar
12807	Estandarte de la Plaga
12808	Esencia de no-muerto
12809	Piedra guardián
12810	Cuero encantado
12811	Orbe recto
12812	Guanteletes de placas sin templar
12813	Frasco de baba misteriosa
12814	Fuego en botella
12815	Antorcha de aviso
12816	Diseño: espada magna de torio
12817	Diseño: Talladora de Picomadera
12818	Diseño: martillo de torio taraceado
12819	Diseño: Hacha de mano de torio ornamentada
12820	Aguardiente Nevada
12821	Diseño: Filo del Alba
12822	Gotita de horror tóxico
12823	Diseño: hacha de batalla de torio enorme
12824	Diseño: martillo de batalla encantado
12825	Diseño: Estoque llameante
12826	Diseño: filo rúnico
12827	Diseño: serenidad
12828	Diseño: martillo volcánico
12829	Cajón de Nevada
12830	Diseño: Corrupción
12831	Diseño: garfa sangrienta
12832	Diseño: Lanza Negra
12833	Diseño: martillo de los titanes
12834	Diseño: Campeona de arcanita
12835	Diseño: Aniquiladora
12836	Diseño: guardia de Escarcha
12837	Diseño: martillo de tormenta magistral
12838	Diseño: Segadora de arcanita
12839	Diseño: Buscacorazones
12840	Piedra de la Plaga del esbirro
12841	Piedra de la Plaga del invasor
12842	Registro escrito de forma rudimentaria
12843	Piedra de la Plaga del corruptor
12844	Muestra de valor de El Alba Argenta
12845	Medallón de fe
12846	Comisión de El Alba Argenta
12847	Pica manchada de alma
12848	Pica manchada de sangre
12849	Saco besado por demonio
12871	Caparazón cromático
12884	Pezuña de Arnak
12885	Muñeca de Pamela
12886	Cabeza de la muñeca de Pamela
12887	Parte izquierda de la muñeca de Pamela
12888	Parte derecha de la muñeca de Pamela
12891	Pico de Jaron
12894	Alianza de Joseph
12895	Coraza del Vuelo Cromático
12896	Primer trozo de reliquia
12897	Segundo trozo de reliquia
12898	Tercer trozo de reliquia
12899	Cuarto trozo de reliquia
12900	Crónicas de Villa Darrow
12903	Musleras del desafiante cromático
12904	Sombrero superespecial suami de Shawn
12905	Manteo de fuego salvaje
12906	Agua de la Poza de la Luna purificada
12907	Agua de la Poza de la Luna corrupta
12922	Cantimplora vacía
12923	Escama de Awbee
12924	Vela de ritual
12925	Piel de serpiente de Arikara
12926	Sortija flamígera
12927	Sobrehombros Golpevero
12928	Yeti mecánico de Umi
12929	Dije Furia de ascuas
12930	Junco maderahelecho
12935	Musleras de maestro de guerra
12936	Ajorcas Belinato
12938	Sangre de héroes
12939	Guardián tribal de Dal'Rend
12940	Carga sagrada de Dal'Rend
12942	Llave de la jaula de pantera
12945	Quijotes del desafiante cromático
12946	Hipercondensador
12947	Anillo de Audacia de Alex
12952	Calavera de Gyth
12953	Almófar ojo de dragón
12954	Tratado de Davil
12955	Escudo de Rutagrana
12956	Cráneo de Horgus
12957	Espada destrozada de Marduk
12958	Receta: transmutar arcanita
12960	Plumas de guerra tribales
12963	Leotardos de maestro del acero
12964	Musleras de Tristam
12965	Leotardos de embozo de espíritus
12966	Guardabrazos de bruma negra
12967	Capa luna de sangre
12968	Manteo de Tejescarcha
12969	Sauce llorón
12970	Placa ceremonial de General
12973	Bala de cañón Escarlata
12974	El Caballero Negro
12975	Hacha de prospector
12976	Hoja Parchierro
12977	Guantes de puño del mago
12978	Cinturón de extiendetormentas
12979	Capa Aterra Fuego
12982	Guardapiés forrados con plata
12983	Garrote Rakzur
12984	Clamacielos
12985	Anillo de Defensa
12987	Calzones Tejeoscuro
12988	Guerrera de vista estelar
12989	Mordisco de gárgola
12990	Filo de cuchilla
12992	Hoja abrasadora
12994	Guanteletes de Thorbia
12996	Sortija de Purificación
12997	Blasón Barbarroja
12998	Manto de mago
12999	Braciles ala de draco
13000	Bastón de Hale Fuegomago
13001	Círculo de doncella
13002	Colgante de Lady Alizabeth
13003	Hacha de batalla de Lord Alexander
13004	Antorcha de Austen
13005	Manta de Amy
13006	Maza de McGowan
13007	Capa de llama de mago
13008	Calzas de valdeviento
13009	Pellejo del rey vacuno
13010	Musleras Cantasueños
13011	Cinturón forrado con plata
13012	Brazales Yorgen
13013	Manto de zahorí anciano
13014	Hacha de Rin'ji
13015	Serathil
13016	Mutiladora
13017	Hacha de batalla de asesino infernal
13018	Cuchilla de verdugo
13019	Arco corto de garra de arpía
13020	Arco de artillero del cielo
13021	Enhebraagujas
13022	Arco largo de ala de grifo
13023	Arco largo de cuerno de águila
13024	Azotador de Beazel
13025	Almádena Muertobosque
13026	Luz del cielo
13027	Cascahuesos
13028	Martillo piedra sangre
13029	Cristal umbrío
13030	Hueso de basilisco
13031	Orbe de Mantoniebla
13032	Espada de Corrupción
13033	Espada de zelote
13034	Estoque Aceroveloz
13035	Cercenaserpientes
13036	Hoja de asesinato
13037	Aguijón Pino de cristal
13038	Vientopresto
13039	Ballesta Atraviesa calaveras
13040	Ballesta certera
13041	Hoja de guardián
13042	Espada del Magistrado
13043	Hoja de los titanes
13044	Destripademonios
13045	Martillo viscoso
13046	Maza de Blanchard
13047	Ramita del Árbol del Mundo
13048	Mazo amenazante
13049	Mandoble de decano
13051	Furia de bruja
13052	Belicista
13053	Portador de fatalidad
13054	Segador implacable
13055	Mascahuesos
13056	Asediador demente
13057	Pico de sangre
13058	Punta de Khoo
13059	Cuervo de piedra
13060	El taladro
13062	Truenedera
13063	Tumbaestrellas
13064	Prendefuegos de Jaina
13065	Varita de Allistarj
13066	Bufas de destripador de vermis
13067	Armadura aliento de hidra
13068	Grebas de obsidiana
13070	Botas de escama de Sapphiron
13071	Puño de Hakoo con placas
13072	Guanteletes de piedra
13073	Yelmo de Jarrathol
13074	Leotardos de fragmentos goblin
13075	Musleras alafunesta
13076	Brazales de destripador gigante
13077	Faja de Uther
13079	Escudo de Thorsen
13080	Garra de viuda
13081	Escudo Calaverance
13082	Rodela de ladera
13083	Blasón de la familia Garrett
13084	Cadena caleidoscópica
13085	Gargantilla horizonte
13086	Riendas del sable de hielo de Cuna del Invierno
13087	Gargantilla Orgullo de Río
13088	Talismán de Gazlowe
13089	Colgante de Skibi
13090	Coraza de los Elegidos
13091	Medallón del gran mariscal Morris
13093	Anillo de ascua encendida
13094	La joya de la reina
13095	Sortija de asalto
13096	Sortija de Hierofante
13097	Anillo de Frente de acero
13098	Sortija tejedaño
13099	Mocasines de la liebre blanca
13100	Botas de Furen
13101	Zapatos Correlobos
13102	Gracia de Cassandra
13103	Hombrera de araña venenosa
13105	Anillo de Sutarn
13106	Pulseras mágicas resplandecientes
13107	Puños de calavera mágica
13108	Manto de Golpe de tigre
13109	Manteo de llama negra
13110	Arnés miedo lobo
13111	Sandalias del Insurgente
13112	Yelmo alado
13113	Ornato Plumaluna
13114	Leotardos Aterratrols
13115	Manto de esquilador de ovejas
13116	Bufas de lo oculto
13117	Fajín de Ogron
13118	Fajín serpentino
13119	Brazales de kodo encantados
13120	Brazales Furiahonda
13121	Ala del vástago
13122	Manteo de fantasma oscuro
13123	Armadura Caminasueños
13124	Botas de escamas de ravasaurio
13125	Botas de anillas élficas
13126	Guanteletes Belillama
13127	Corona de atracador de hielo
13128	Yelmo de gran Bergg
13129	Leotardos Pirocabello
13130	Musleras de Brisaveloz
13131	Manto de Brillavalva
13132	Sobrehombros esqueléticas
13133	Cubrehombros Pirodraco
13134	Cinturón del Gladiador
13135	Guardabrazos señoriales
13136	Lanzaguisantes del pequeño Timmy
13137	Tejehierro
13138	El silenciador
13139	Rompentrañas
13140	Llave roja de sangre
13141	Diente de Gnarr
13142	Faja de Brigam
13143	Marca del Señor de los dragones
13144	Cinturón de serenidad
13145	Cinturón de ogro enigma
13146	Escopeta lanza caparazones
13148	Congeladora
13149	Escrito sobre Invocación de Eldarath Vol. 1
13151	Los estudios místicos de Hor'ank
13152	la historia sin conclusión
13153	Escrito de Mal'cin Vorail
13154	Estudios de Jael'marin de lo Arcano
13155	Calavera resonadora
13156	Cristal místico
13157	Calavera fétida
13158	Palabras del Gran Jefe
13159	Polvo de huesos
13161	Bastón de refugio
13162	Garras de reiver
13163	Guadaña incansable
13164	Corazón de la escama
13166	Sobrehombros embate
13167	Puño de Omokk
13168	Torso del rey chamán
13169	Leotardos de aterracrines
13170	Leotardos de embozo celestial
13171	Mechero de Smokey
13172	Tabaco de calidad de Grimm
13173	Hacha arrojadiza de hoja voladora
13174	Muestra de carne apestada
13175	Arco tirante de Voone
13176	Información sobre la Plaga
13177	Dije de evasión
13178	Círculo rosado
13179	Guardabrazos cuorobronce
13180	Agua bendita de Stratholme
13181	Guantes de piel de demonio
13182	Hoja fase
13183	Escupeveneno
13184	Lúas de lágrimas
13185	Manto de hendevidente
13186	Botella vacía del Campo de Piedramácula
13187	Botella del Llanto de Dalson vacía
13188	Botella vacía de El Tormento
13189	Botella vacía de la Gangrena de Gahrron
13190	Botella rellena del Campo de Piedramácula
13191	Botella del Llanto de Dalson llena
13192	Botella llena de El Tormento
13193	Botella llena de la Gangrena de Gahrron
13194	Llave de la caldera del Campo de Piedramácula
13195	Llave de la caldera del Llanto de Dalson
13196	Llave de la caldera de la Gangrena de Gahrron
13197	Llave de caldera rondada de El Tormento
13198	Machacador
13199	Ataduras Aplastacrestas
13202	Crónicas ampliadas de Villa Darrow
13203	Capa de estela
13204	Maza de Bashguud
13205	Protector Rhombeard
13206	Leotardos de pelo de lobo
13207	Cabeza de Señor de las Sombras Fel'dan
13208	Guardabrazos aullador pálido
13209	Sello del Alba
13210	Escarpines de lobo aterrador
13211	Brazales garraja
13212	Collera de pinchos de Halycon
13213	Ojo de Telabrasada
13216	Corona del Penitente
13217	Sortija del Penitente
13218	Colmillo de la araña de cristal
13223	Faltriquera de mensajero de Stratholme
13243	Defensor Argenta
13244	Guanteletes dorados
13245	Caparazón de Kresh
13246	Vengador Argenta
13247	Baúl del intendente Zigris
13248	Tiro de ráfaga de arcabuz
13249	Cruzado Argenta
13250	Cabeza de Balnazzar
13251	Cabeza de Barón Osahendido
13252	Faja correnubes
13253	Manos de Poder
13254	Guarda astral
13255	Guanteletes de objetivo real
13257	Bufas con runas demoníacas
13258	Guanteletes de pellejo de escoria
13259	Guardapiés de Costillas de Acero
13260	Botas de Bailavientos
13261	Globo de D'sak
13262	Crematoria
13282	Botas de vigía de torre ogro
13283	Anillo de mago
13284	Botas de batalla Dardopresto
13285	La Cercenadora de Roca Negra
13286	Puafilada
13287	Patrón: arnés de pellejo de raptor
13288	Patrón: cinturón de pellejo de raptor
13289	Libertador de Egan
13302	Llave del buzón de la Fila del Mercado
13303	Llave del buzón de la Plaza de los Cruzados
13304	Llave del buzón de la calle del festival
13305	Llave del buzón de la plaza de los Ancianos
13306	Llave del buzón de la Plaza del Rey
13307	Llave del buzón de Ezra Grimm
13308	Esquema: deflector de hielo
13309	Esquema: bocarda fabricada con amor
13310	Esquema: mira de precisión
13311	Esquema: dragonizo mecánico
13313	Sagradas escrituras de los Altonato
13314	Abrazo de Alanna
13317	Silbato del raptor marfil
13320	Acelerador Arcano
13321	Mecazancudo verde
13322	Mecazancudo sin pintar
13323	Mecazancudo morado
13324	Mecazancudo rojo y azul
13325	Mecazancudo verde fosforito
13326	Mecazancudo blanco modelo A
13327	Mecazancudo azul hielo modelo A
13328	Carnero negro
13329	Carnero de escarcha
13330	Bolsa de rábanos de Derek
13331	Caballo esquelético rojo
13332	Caballo esquelético azul
13333	Caballo esquelético marrón
13334	Caballo de guerra esquelético verde
13335	Riendas de destrero de la muerte
13340	Manteo del Barón negro
13342	Pez mascota
13343	Piedra mascota
13344	Guanteletes draconianos
13345	Sello de Osahendido
13346	Togas del Exaltado
13347	Cristal de Zin-Malor
13348	Corte de demonio
13349	Cetro de los Profanos
13350	Insignia de La Guardia Negra
13351	Delantal del forjamartillos Carmesí
13352	Piedra culebra de Vosh'gajin
13353	Libro de los Muertos
13354	Resonador ectoplásmico
13356	Intensificador somático
13357	Agitador óseo
13358	Sobrehombros Lenguavermis
13359	Corona de Tiranía
13360	Ofrenda del magi élfico
13361	Espetadora Forjacráneos
13362	Carta del frente
13363	Proclamación municipal
13364	Anuncio de Ezra Grimm
13365	Aviso de consejo de la ciudad
13366	Juguete ingenioso
13367	Obsequio envuelto
13368	Trizahuesos
13369	Zancos de fuego
13370	Enfocador vítreo
13371	Llama paternal
13372	Cachava del explotador
13373	Sortija de Carne
13374	Manto de ladrón de almas
13375	Blasón de reprensión
13376	Capa de tribunal real
13377	Balas de cañón en miniatura
13378	Blusa ruiseñor
13379	Flautín de la llama flameante
13380	Obús portátil de Willey
13381	Botas de maestro cañonero
13382	Mensajero bola de cañón
13383	Prendas de lana de juglar saltarín
13384	Faja arco iris
13385	Escrito sobre Conocimiento
13386	Manteo de archivista
13387	Faja de previsión
13388	Guerrera de jefe de correos
13389	Calzas de jefe de correos
13390	Banda de jefe de correos
13391	Botines de jefe de correos
13392	Sello de jefe de correos
13393	Embate de Gassol
13394	Abrazo frío de Skul
13395	Garras de Skul
13396	Toque espantoso de Skul
13397	Manteo de gárgola piel de piedra
13398	Botas del Aullador
13399	Garfas de gárgola trituradas
13400	Avambrazos del Sádico
13401	La mano cruel de Timmy
13402	Galochas de Timmy
13403	Lazo de Grimagore
13404	Máscara del Imperdonable
13405	Espaldares Penumbría dolido
13408	Quebrador de almas
13409	Brazales lágrima
13422	Anguila escama pétrea
13423	Aceite de escama pétrea
13442	Poción de ira poderosa
13443	Poción de maná excelente
13444	Poción de maná sublime
13445	Elixir de defensa excelente
13446	Poción de sanación sublime
13447	Elixir de los sabios
13448	Las escrituras de Castel Darrow
13450	Las escrituras de Costasur
13451	Las escrituras de Molino Tarren
13452	Elixir de la mangosta
13453	Elixir de fuerza bruta
13454	Elixir Arcano superior
13455	Poción de escudo de piedra superior
13456	Poción de Protección contra la Escarcha superior
13457	Poción de Protección contra el Fuego superior
13458	Poción de Protección contra la Naturaleza superior
13459	Poción de Protección contra las Sombras superior
13460	Poción de Protección contra lo Sagrado superior
13461	Poción de Protección contra lo Arcano superior
13462	Poción de purificación
13463	Hojasueño
13464	Sansam dorado
13465	Salviargenta de montaña
13466	Flor de plaga
13467	Setelo
13468	Loto negro
13469	Cabeza de Weldon Barov
13470	Cabeza de Alexi Barov
13471	Las escrituras de Rémol
13473	Talismán de buena suerte de piedra mácula
13474	Escopeta del granjero Dalson
13475	Alianza de la familia Dalson
13476	Receta: poción de ira poderosa
13477	Receta: poción de maná excelente
13478	Receta: elixir de defensa excelente
13479	Receta: elixir de los sabios
13480	Receta: poción de sanación sublime
13481	Receta: elixir de fuerza bruta
13482	Receta: transmutar aire en fuego
13483	Receta: transmutar fuego a tierra
13484	Receta: transmutar tierra a agua
13485	Receta: transmutar agua a aire
13486	Receta: transmutar no-muerto a agua
13487	Receta: transmutar agua a no-muerto
13488	Receta: transmutar vida a tierra
13489	Receta: transmutar tierra a vida
13490	Receta: poción de escudo de piedra superior
13491	Receta: elixir de la mangosta
13492	Receta: poción de purificación
13493	Receta: elixir Arcano superior
13494	Receta: poción de Protección contra el Fuego superior
13495	Receta: poción de Protección contra la Escarcha superior
13496	Receta: poción de Protección contra la Naturaleza superior
13497	Receta: poción de Protección contra lo Arcano superior
13498	Leotardos artesanales de maestro herrero
13499	Receta: poción de Protección contra las Sombras superior
13500	Receta: poción de Protección contra lo Sagrado superior
13501	Receta: poción de maná sublime
13502	Faja artesanal de maestro herrero
13503	Piedra de alquimista
13505	Hojarruna del Barón Osahendido
13506	Frasco de petrificación
13507	Informe de Vigiarrisco Cuernolargo
13508	Ojo de Arachnida
13509	Agarre de previsión
13510	Frasco de los titanes
13511	Frasco de sabiduría destilada
13512	Frasco de poder supremo
13513	Frasco de resistencia cromática
13514	Lamento de alma en pena
13515	Descargas de relámpagos de Ramstein
13517	Receta: Piedra de alquimista
13518	Receta: Frasco de petrificación
13519	Receta: frasco de los titanes
13520	Receta: frasco de sabiduría destilada
13521	Receta: frasco de poder supremo
13522	Receta: frasco de resistencia cromática
13523	Sangre inocente
13524	Cráneo de las Sombras ardientes
13525	Dedos de Presotenebra
13526	Faja marcada por las llamas
13527	Grebas de Corredor de lava
13528	Brazales del vacío Crepusculares
13529	Coraza de Nerub'enkan
13530	Zapatillas para correr Gota colmillo
13531	Leotardos de acechador de la cripta
13532	Garras de Giraoscuro
13533	Espaldares grabados con ácido
13534	Dedo de alma en pena
13535	Sobrevesta de fantasma tactofrío
13536	Cuerno de Despertar
13537	Brazales pellejofrío
13538	Espaldares de Gritaviento
13539	Toque de alma en pena
13542	Caja de demonio
13544	Esencia espectral
13545	Marisco
13546	Panzasangre
13562	Restos de Trey Forjaluz
13582	Correa Zerguezno
13583	Collera de panda
13584	Piedra de diablo
13585	Libro de los Recuerdos
13602	Piedra de hechizo superior
13603	Piedra de hechizo sublime
13624	Libro de Memorias del Alma
13626	Cabeza humana de Ras Murmuhielo
13699	Piedra de fuego
13700	Piedra de fuego superior
13701	Piedra de fuego sublime
13702	Apocalíseas
13703	Hueso de kodo
13704	Llave esqueleto
13724	Galleta enriquecida con maná
13725	Bolsa de los horrores de Krastinov
13752	Libro de Memorias del Alma
13754	Vigorpez lustroso crudo
13755	Calamar de invierno
13756	Lubina cruda
13757	Anguila relámpago
13758	Branquirrojo crudo
13759	Pargo nocturno crudo
13760	Salmón escama de sol crudo
13761	Huevos congelados
13810	Fruta del sol bendita
13811	Collar del Alba
13812	Anillo del Alba
13813	Zumo de fruta del sol bendita
13815	Una runa
13816	Tizona refinada
13817	Espada magna estrecha
13818	Hacha dentada
13819	Hacha de guerra equilibrada
13820	Maza de peso
13821	Gran maza enorme
13822	Daga con pinchos
13823	Bastón de guerra recio
13824	Arco largo corvo
13825	Mosquete primordial
13842	Mañana de otoño/invierno
13843	Tarde de otoño/invierno
13844	Tarde noche de otoño/invierno
13845	Noche de otoño/invierno
13846	Mañana de primavera/verano
13847	Mediodía de primavera/verano
13848	Tarde de primavera/verano
13849	Noche de primavera/verano
13850	Munición de Estruendo
13851	Costillas de lobo picantes
13852	Orden del Gran Cruzado
13853	Trozo de carne de gusano carroñero
13856	Cinturón de paño rúnico
13857	Guerrera de paño rúnico
13858	Toga de paño rúnico
13860	Capa de paño rúnico
13863	Guantes de paño rúnico
13864	Botas de paño rúnico
13865	Pantalones de paño rúnico
13866	Cinta de paño rúnico
13867	Sobrehombros de paño rúnico
13868	Toga de tejido de Escarcha
13869	Guerrera de tejido de Escarcha
13870	Guantes de tejido de Escarcha
13871	Pantalones de tejido de Escarcha
13872	Fardo de madera
13873	Llave de la Sala de visión
13874	Cajón pesado
13875	Cofre reforzado con hierro cerrado
13876	Mero de 20 kilos
13877	Mero de 23 kilos
13878	Mero de 26 kilos
13879	Mero de 27 kilos
13880	Mero de 24 kilos
13881	Branquirrojo hinchado
13882	Branquirrojo de 21 kilos
13883	Branquirrojo de 22 kilos
13884	Branquirrojo de 24 kilos
13885	Branquirrojo de 17 kilos
13886	Branquirrojo de 18 kilos
13887	Branquirrojo de 25 kilos
13888	Langosta pinza oscura
13889	Salmón escama blanca crudo
13890	Pez coraza de placas
13891	Salmón hinchado
13892	Kombobulador kodo
13893	Vigorpez crudo grande
13895	Dangui formal
13896	Hanbok de boda verde oscuro
13897	Hanbok tradicional blanco
13898	Dangui real
13899	Hanbok tradicional rojo
13900	Hanbok de boda verde
13901	Salmón de 7 kilos
13902	Salmón de 9 kilos
13903	Salmón de 12 kilos
13904	Salmón de 13 kilos
13905	Salmón de 15 kilos
13906	Salmón de 16 kilos
13907	Langosta de 3 kilos
13908	Langosta de 4 kilos
13909	Langosta de 6 kilos
13910	Langosta de 7 kilos
13911	Langosta de 10 kilos
13912	Langosta de 11 kilos
13913	Langosta de 12 kilos
13914	Vigorpez de 35 kilos
13915	Vigorpez de 42 kilos
13916	Vigorpez de 46 kilos
13917	Vigorpez de 51 kilos
13918	Cofre cerrado reforzado
13920	Escama de dragón sana
13926	Perla de oro
13927	Vigorpez lustroso cocido
13928	Calamar a la parrilla
13929	Lubina ahumada picante
13930	Filete de branquirrojo
13931	Sopa de pargo nocturno
13932	Salmón Solescama pochado
13933	Estofado de langosta
13934	Filete de vigorpez
13935	Salmón al horno
13937	Carga de rector
13938	Pluma amarrahuesos
13939	Receta: serviola moteada
13940	Receta: vigorpez lustroso cocido
13941	Receta: filete de branquirrojo
13942	Receta: calamar a la parrilla
13943	Receta: lubina ahumada picante
13944	Coraza de lápida
13945	Receta: sopa de pargo nocturno
13946	Receta: salmón escama de sol pochado
13947	Receta: estofado de langosta
13948	Receta: filete de vigorpez
13949	Receta: salmón al horno
13950	Cinta de detención
13951	Avambrazos de acerovigor
13952	Rebanadora de hoja de hielo
13953	Colmillo silencioso
13954	Escarpines verdeantes
13955	Sobrehombros con forma de piedra
13956	Agarre de Andros
13957	Rebanadoras de gárgolas
13958	Grilletes Vermiothalak
13959	Limitador de circunferencia de Omokk
13960	Corazón del Maligno
13961	Bozal de Halycon
13962	Ceñidor de Vosh'gajin
13963	Mandiletes de maña de Voone
13964	Espada de bruja
13965	Amplitud de Puño Negro
13966	Marca de Tiranía
13967	Grebas Atracavientos
13968	Ojo de la bestia
13969	Ajorcas de guardia amenazante
13982	Hoja de guerra de Castel Darrow
13983	Hacha de guerra de lápida
13984	Pico Darrow
13986	Corona de Castel Darrow
14002	Guarda fuerte de Villa Darrow
14022	Llamador de campesino Barov
14023	Llamador de campesino Barov
14024	Garfa de miedo
14025	Cinturón de místico
14042	Jubón de paño cenizo
14043	Guantes de paño cenizo
14044	Capa de paño cenizo
14045	Pantalones de paño cenizo
14046	Bolsa de paño rúnico
14047	Paño rúnico
14048	Madeja de paño rúnico
14062	Montura de kodo
14083	Bastión de Tyrande
14086	Botas perladas
14087	Puños perlados
14088	Capa perlada
14089	Guantes perlados
14090	Calzones perlados
14091	Toga perlada
14093	Cordón perlado
14094	Sobrevesta perlada
14095	Braciles nativos
14096	Jubón nativo
14097	Pantalones nativos
14098	Capa nativa
14099	Fajín nativo
14100	Toga de paño brillante
14101	Guantes de paño brillante
14102	Manijas nativas
14103	Capa de paño brillante
14104	Pantalones de paño brillante
14106	Toga de tela vil
14107	Pantalones de tela vil
14108	Botas de tela vil
14109	Toga nativa
14110	Botas nativas
14111	Caperuza de tela vil
14112	Sobrehombros de tela vil
14113	Fajín aborigen
14114	Borceguíes aborígenes
14115	Braciles aborígenes
14116	Manteo aborigen
14117	Guantes aborígenes
14119	Taparrabos aborigen
14120	Toga aborigen
14121	Jubón aborigen
14122	Braciles de ritual
14123	Manteo de ritual
14124	Guantes de ritual
14125	Leotardos de ritual
14126	Amito de ritual
14127	Embozo de ritual
14128	Toga de tejido zahorí
14129	Sandalias de ritual
14130	Turbante de tejido zahorí
14131	Cinturón de ritual
14132	Leotardos de tejido zahorí
14133	Guerrera de ritual
14134	Capa de Fuego
14136	Toga de Noche invernal
14137	Leotardos de tela lunar
14138	Jubón de tela lunar
14139	Sobrehombros de tela lunar
14140	Aro de tela lunar
14141	Jubón de tejido fantasmal
14142	Guantes de tejido fantasmal
14143	Cinturón de tejido fantasmal
14144	Pantalones de tejido fantasmal
14145	Hoja mácula maldita
14146	Guantes de maestría en hechizos
14147	Brazales de morador de cuevas
14148	Puños cristalinos
14149	Manteo subterráneo
14150	Toga de Evocación
14151	Hoja de canto
14152	Toga del archimago
14153	Toga del Vacío
14154	Vestimentas de fe verdadera
14155	Bolsa de tela lunar
14156	Bolsa sin fondo
14157	Manto pagano
14158	Jubón pagano
14159	Botas paganas
14160	Braciles paganos
14161	Manteo pagano
14162	Mitones paganos
14163	Almillas paganas
14164	Cinturón pagano
14165	Calzones paganos
14166	Brazales de bucanero
14167	Manteo de bucanero
14168	Guantes de bucanero
14169	Hombreras aborígenes
14170	Manto de bucanero
14171	Pantalones de bucanero
14172	Togas de bucanero
14173	Cordón de bucanero
14174	Botas de bucanero
14175	Jubón de bucanero
14176	Botas de vigía
14177	Puños de vigía
14178	Almete de vigía
14179	Manteo de vigía
14180	Chaleco de vigía
14181	Manijas de vigía
14182	Manto de vigía
14183	Leotardos de vigía
14184	Togas de vigía
14185	Cincho de vigía
14186	Manto Clamalluvias
14187	Puños Clamalluvias
14188	Capa Clamalluvias
14189	Almete Clamalluvias
14190	Jubón Clamalluvias
14191	Mitones Clamalluvias
14192	Togas Clamalluvias
14193	Pantalones Clamalluvias
14194	Cordón Clamalluvias
14195	Botas Clamalluvias
14196	Sandalias Piel de Cardo
14197	Braciles Piel de Cardo
14198	Capa Piel de Cardo
14199	Guantes Piel de Cardo
14200	Almete Piel de Cardo
14201	Manto Piel de Cardo
14202	Chaleco Piel de Cardo
14203	Pantalones Piel de Cardo
14204	Toga Piel de Cardo
14205	Cinturón Piel de Cardo
14206	Pulseras vitales
14207	Leotardos vitales
14208	Cinta vital
14209	Fajín vital
14210	Manteo vital
14211	Manijas vitales
14212	Sobrehombros vitales
14213	Vestiduras vitales
14214	Botas vitales
14215	Guerrera vital
14216	Chaleco de geomántico
14217	Cordón de geomántico
14218	Botas de geomántico
14219	Capa de geomántico
14220	Almete de geomántico
14221	Brazales de geomántico
14222	Guantes de geomántico
14223	Bufas de geomántico
14224	Calzas de geomántico
14225	Sobrevesta de geomántico
14226	Pulseras de seda de ascuas
14227	Seda de araña Tejehierro
14228	Nimbo de seda de ascuas
14229	Capa de seda de ascuas
14230	Guerrera de seda de ascuas
14231	Mitones de seda de ascuas
14232	Manto de seda de ascuas
14233	Leotardos de seda de ascuas
14234	Togas de seda de ascuas
14235	Cordón de seda de ascuas
14236	Botas de seda de ascuas
14237	Armadura Niebla Negra
14238	Botas Niebla Negra
14239	Manteo Niebla Negra
14240	Braciles Niebla Negra
14241	Manoplas Niebla Negra
14242	Pantalones Niebla Negra
14243	Manto Niebla Negra
14244	Sobrevesta Niebla Negra
14245	Faja Niebla Negra
14246	Sombrero de zahorí Niebla Negra
14247	Manto lunar
14248	Ataduras lunares
14249	Jubón lunar
14250	Zapatillas lunares
14251	Capa lunar
14252	Nimbo lunar
14253	Manijas lunares
14254	Vestimenta lunar
14255	Cinturón lunar
14256	Tela vil
14257	Leotardos lunares
14258	Cordón de tejido de sangre
14259	Botas de tejido de sangre
14260	Brazales de tejido de sangre
14261	Capa de tejido de sangre
14262	Mitones de tejido de sangre
14263	Máscara de tejido de sangre
14264	Pantalones de tejido de sangre
14265	Sobrevesta de tejido de sangre
14266	Protectores de tejido de sangre
14267	Chaleco de tejido de sangre
14268	Puños de Gaia
14269	Zapatillas de Gaia
14270	Capa de Gaia
14271	Aro de Gaia
14272	Manijas de Gaia
14273	Amito de Gaia
14274	Leotardos de Gaia
14275	Vestimenta de Gaia
14276	Cinturón de Gaia
14277	Guerrera de Gaia
14278	Manto opulento
14279	Brazales opulentos
14280	Manteo opulento
14281	Corona opulenta
14282	Guantes opulentos
14283	Leotardos opulentos
14284	Togas opulentas
14285	Botas opulentas
14286	Cinturón opulento
14287	Guerrera opulenta
14288	Armadura arácnida
14289	Faja arácnida
14290	Escarpines arácnidos
14291	Pulseras arácnidas
14292	Manteo arácnido
14293	Aro arácnido
14294	Guantes arácnidos
14295	Musleras arácnidas
14296	Espaldares arácnidos
14297	Togas arácnidas
14298	Bufas de Tirahuesos
14299	Botas de Tirahuesos
14300	Manteo de Tirahuesos
14301	Ataduras de Tirahuesos
14302	Guantes de Tirahuesos
14303	Embozo de Tirahuesos
14304	Cinturón de Tirahuesos
14305	Sarong de Tirahuesos
14306	Jubón de Tirahuesos
14307	Corona de Tirahuesos
14308	Guerrera celestial
14309	Cinturón celestial
14310	Zapatillas celestiales
14311	Ataduras celestiales
14312	Corona celestial
14313	Manteo celestial
14314	Manijas celestiales
14315	Falda celestial
14316	Espaldares celestiales
14317	Togas de seda celestiales
14318	Guerrera rutilante
14319	Botas rutilantes
14320	Pulseras rutilantes
14321	Capa rutilante
14322	Aro rutilante
14323	Guanteletes rutilantes
14324	Sarong rutilante
14325	Cubrehombros rutilantes
14326	Togas rutilantes
14327	Cinturón rutilante
14328	Coselete eterno
14329	Botas eternas
14330	Ataduras eternas
14331	Capa eterna
14332	Corona eterna
14333	Guantes eternos
14334	Sarong eterno
14335	Bufas eternas
14336	Sobrevesta eterna
14337	Cordón eterno
14338	Tubo de agua vacío
14339	Tubo de agua de la Poza de la Luna
14340	Togas de exánime heladas
14341	Hilo rúnico
14342	Tela lunar
14343	Fragmento luminoso pequeño
14344	Fragmento luminoso grande
14364	Zapatillas de místico
14365	Manteo de místico
14366	Pulseras de místico
14367	Guantes de místico
14368	Hombreras de místico
14369	Atadura de místico
14370	Prendas de lana de místico
14371	Toga de místico
14372	Armadura sanguina
14373	Cinturón sanguino
14374	Sandalias sanguinas
14375	Puños sanguinos
14376	Manteo sanguino
14377	Manijas sanguinas
14378	Manto sanguino
14379	Calzas sanguinas
14380	Toga sanguina
14381	Cartera de Tótem Siniestro
14382	Pechera Durabilidad
14383	Brazales Durabilidad
14384	Botas Durabilidad
14385	Capa Durabilidad
14386	Sombrero Durabilidad
14387	Guantes Durabilidad
14388	Leotardos Durabilidad
14389	Hombreras Durabilidad
14390	Cinturón de durabilidad
14391	Espada Durabilidad
14392	Bastón Durabilidad
14393	Escudo Durabilidad
14394	Arco Durabilidad
14395	Hechizos de las Sombras
14396	Encantamientos desde el infierno
14397	Manto resistente
14398	Guerrera resistente
14399	Botas resistentes
14400	Manteo resistente
14401	Almete resistente
14402	Braciles resistentes
14403	Lúas resistentes
14404	Leotardos resistentes
14405	Toga resistente
14406	Cordón resistente
14407	Jubón de paño de piedra
14408	Botas de paño de piedra
14409	Manteo de paño de piedra
14410	Aro de paño de piedra
14411	Guantes de paño de piedra
14412	Cubrehombros de paño de piedra
14413	Toga de paño de piedra
14414	Cinturón de paño de piedra
14415	Calzones de paño de piedra
14416	Ataduras de paño de piedra
14417	Guerrera Sedarena
14418	Botas Sedarena
14419	Brazales Sedarena
14420	Manteo Sedarena
14421	Aro Sedarena
14422	Guantes Sedarena
14423	Hombreras Sedarena
14424	Ataduras Sedarena
14425	Sobrevesta Sedarena
14426	Faja Sedarena
14427	Sobrevesta Cazavientos
14428	Escarpines Cazavientos
14429	Puños Cazavientos
14430	Capa Cazavientos
14431	Manoplas Cazavientos
14432	Amito Cazavientos
14433	Cazavientos Prendas de lana
14434	Togas Cazavientos
14435	Cincho Cazavientos
14436	Nimbo Cazavientos
14437	Jubón de embozo de veneno
14438	Botas de embozo de veneno
14439	Guardabrazos de embozo de veneno
14440	Manteo de embozo de veneno
14441	Máscara de embozo de veneno
14442	Mitones de embozo de veneno
14443	Manto de embozo de veneno
14444	Leotardos de embozo de veneno
14445	Togas de seda de embozo de veneno
14446	Cinturón de embozo de veneno
14447	Escarpines de Altonato
14448	Pulseras de Altonato
14449	Corona de Altonato
14450	Capa de Altonato
14451	Guantes de Altonato
14452	Espaldares de Altonato
14453	Togas de Altonato
14454	Cordón de Altonato
14455	Armadura de Altonato acolchada
14456	Jubón elunarita
14457	Puños elunaritas
14458	Botas elunaritas
14459	Capa elunarita
14460	Diadema elunarita
14461	Lúas elunaritas
14462	Sarong elunarita
14463	Bufas elunaritas
14464	Togas de seda elunaritas
14465	Cinturón elunarita
14466	Patrón: guerrera de tejido de Escarcha
14467	Patrón: toga de tejido de Escarcha
14468	Patrón: bolsa de paño rúnico
14469	Patrón: toga de paño rúnico
14470	Patrón: guerrera de paño rúnico
14471	Patrón: jubón de paño cenizo
14472	Patrón: capa de paño rúnico
14473	Patrón: cinturón de tejido fantasmal
14474	Patrón: guantes de tejido de Escarcha
14476	Patrón: guantes de paño cenizo
14477	Patrón: guantes de tejido fantasmal
14478	Patrón: toga de paño brillante
14479	Patrón: guantes de paño brillante
14480	Patrón: jubón de tejido fantasmal
14481	Patrón: guantes de paño rúnico
14482	Patrón: capa de paño cenizo
14483	Patrón: pantalones de tela vil
14484	Patrón: capa de paño brillante
14485	Patrón: leotardos de tejido zahorí
14486	Patrón: capa de Fuego
14487	Martillo hielahuesos
14488	Patrón: botas de paño rúnico
14489	Patrón: pantalones de tejido de Escarcha
14490	Patrón: pantalones de paño cenizo
14491	Patrón: pantalones de paño rúnico
14492	Patrón: botas de tela vil
14493	Patrón: toga de Noche invernal
14494	Patrón: pantalones de paño brillante
14495	Patrón: pantalones de tejido fantasmal
14496	Patrón: caperuza de tela vil
14497	Patrón: leotardos de tela lunar
14498	Patrón: cinta de paño rúnico
14499	Patrón: bolsa de tela lunar
14500	Patrón: toga de tejido zahorí
14501	Patrón: jubón de tela lunar
14502	Faja Mordedura de Escarcha
14503	Agarre de la Muerte
14504	Patrón: sobrehombros de paño rúnico
14505	Patrón: turbante de tejido zahorí
14506	Patrón: toga de tela vil
14507	Patrón: sobrehombros de tela lunar
14508	Patrón: sobrehombros de tela vil
14509	Patrón: aro de tela lunar
14510	Patrón: bolsa sin fondo
14511	Patrón: guantes de maestría en hechizos
14512	Patrón: vestimentas de fe verdadera
14513	Patrón: toga del archimago
14514	Patrón: toga del Vacío
14522	Leotardos de La Vorágine
14523	Pico de demonio
14525	Guanteletes de huesos apretados
14526	Patrón: tela lunar
14528	Rodela armadósea
14529	Venda de paño rúnico
14530	Venda de paño rúnico gruesa
14531	Bastón de Calamiedo
14536	Camisote con huesos
14537	Grebas de luz de cadáver
14538	Manto Caminamuerte
14539	Yelmo de hueso
14540	Corazón de Taragaman el Hambriento
14541	Espada de la familia Barovia
14542	Cajón de Kravel
14543	Guantes sombra oscura
14544	Insignia de Teniente
14545	Leotardos de fantasma
14546	Cuerno de kodo de Roon
14547	Mano de Iruxos
14548	Bufas reales
14549	Botas de evasión
14550	Guardabrazos aterraespadas
14551	Manoplas del Maestro de filos
14552	Espaldares de mazmorras
14553	Fajín de piedad
14554	Quijotes guardanubes
14555	Navaja solar de Alcor
14557	El cuerno de león de Ventormenta
14558	Colgante de Lady Maye
14559	Fajín de prospector
14560	Botas de prospector
14561	Puños de prospector
14562	Pechera de prospector
14563	Capa de prospector
14564	Mitones de prospector
14565	Prendas de lana de prospector
14566	Hombreras de prospector
14567	Cinturón Erizacorteza
14568	Botas Erizacorteza
14569	Ataduras Erizacorteza
14570	Blusa Erizacorteza
14571	Manteo Erizacorteza
14572	Guantes Erizacorteza
14573	Amito Erizacorteza
14574	Calzones Erizacorteza
14576	Empuñadura de ébano de Marduk
14577	Pantalones Humo de calavera
14578	Cordón Dokebi
14579	Botas Dokebi
14580	Brazales Dokebi
14581	Coselete Dokebi
14582	Manteo Dokebi
14583	Guantes Dokebi
14584	Sombrero Dokebi
14585	Leotardos Dokebi
14587	Manto Dokebi
14588	Cordón de ojo de halcón
14589	Botas de ojo de halcón
14590	Brazales de ojo de halcón
14591	Gorro de ojo de halcón
14592	Guerrera de ojo de halcón
14593	Capa de ojo de halcón
14594	Guantes de ojo de halcón
14595	Calzones de ojo de halcón
14596	Cubrehombros de ojo de halcón
14598	Pretina de celador
14599	Escarpines de celador
14600	Braciles de celador
14601	Sobrevesta de celador
14602	Capa de celador
14603	Manto de celador
14604	Sombrero de zahorí de celador
14605	Prendas de lana de celador
14606	Guantes de celador
14607	Rodela de ojo de halcón
14608	Rodela Dokebi
14610	Escarabeo de Araj
14611	Camisote Mallasangre
14612	Musleras Mallasangre
14613	Martillo de Taelan
14614	Cinturón Mallasangre
14615	Guanteletes Mallasangre
14616	Botas Mallasangre
14617	Camisa de matasanos
14619	Trozos esqueléticos
14620	Faja de hueso de muerto
14621	Escarpes de hueso de muerto
14622	Guanteletes de hueso de muerto
14623	Musleras de hueso de muerto
14624	Peto de hueso de muerto
14625	Símbolo de Honor perdido
14626	Toga necrópila
14627	Patrón: camisa amarillo brillante
14628	Trozos esqueléticos imbuidos
14629	Puños necrópilos
14630	Patrón: capucha de encantador
14631	Botas necrópilas
14632	Leotardos necrópilos
14633	Manto necrópilo
14634	Receta: aceite de Escarcha
14635	Patrón: cinturón de cuero con gemas incrustadas
14636	Cinturón de cadáver
14637	Armadura de cadáver
14638	Leotardos de cadáver
14639	Esquema: recombobulador menor
14640	Guantes de cadáver
14641	Botos de cadáver
14644	Molde para llave esqueleto
14645	Llave esqueleto sin terminar
14646	Vale de regalo de Villanorte
14647	Vale de regalo de Valle de Crestanevada
14648	Vale de regalo de Cañada Umbría
14649	Vale de regalo de Valle de los Retos
14650	Vale de regalo de Campamento Narache
14651	Vale de regalo de Camposanto
14652	Fajín Scorpashi
14653	Zapatillas Scorpashi
14654	Braciles Scorpashi
14655	Coraza Scorpashi
14656	Manteo Scorpashi
14657	Guantes Scorpashi
14658	Capacete Scorpashi
14659	Leotardos Scorpashi
14660	Hombreras Scorpashi
14661	Cordón de vigilante
14662	Pezuñas de vigilante
14663	Ataduras de vigilante
14664	Armadura de vigilante
14665	Capa de vigilante
14666	Guantes de vigilante
14667	Corona de vigilante
14668	Prendas de lana de vigilante
14669	Manto de vigilante
14670	Armadura de Señor Orgulloso
14671	Botas de Señor Orgulloso
14672	Braciles de Señor Orgulloso
14673	Manteo de Señor Orgulloso
14674	Faja de Señor Orgulloso
14675	Guantes de Señor Orgulloso
14676	Halo de Señor Orgulloso
14677	Pantalones de Señor Orgulloso
14678	Espaldares de Señor Orgulloso
14679	Del amor y la familia
14680	Jubón de indómito
14681	Botas de indómito
14682	Guardabrazos de indómito
14683	Capa de indómito
14684	Cinturón de indómito
14685	Guanteletes de indómito
14686	Ornato de indómito
14687	Leotardos de indómito
14688	Cubrehombros de indómito
14722	Tobilleras de pintura de guerra
14723	Ataduras de pintura de guerra
14724	Capa de pintura de guerra
14725	Pretina de pintura de guerra
14726	Guantes de pintura de guerra
14727	Musleras de pintura de guerra
14728	Hombreras de pintura de guerra
14729	Escudo de pintura de guerra
14730	Pechera de pintura de guerra
14742	Botas descomunales
14743	Braciles descomunales
14744	Coselete descomunal
14745	Capa descomunal
14746	Cinturón descomunal
14747	Guanteletes descomunales
14748	Leotardos descomunales
14749	Bufas descomunales
14750	Puños de destripador
14751	Sobrevesta de destripador
14752	Manteo de destripador
14753	Capacete de destripador
14754	Guantes de destripador
14755	Fajín de destripador
14756	Zapatillas de destripador
14757	Pantalones de destripador
14758	Hombreras de destripador
14759	Brazales duraderos
14760	Coraza duradera
14761	Cinturón duradero
14762	Botas duraderas
14763	Manteo duradero
14764	Guanteletes duraderos
14765	Aro duradero
14766	Calzones duraderos
14767	Espaldares duraderos
14768	Armadura de devastador
14769	Sandalias de devastador
14770	Guardabrazos de devastador
14771	Capa de devastador
14772	Manijas de devastador
14773	Cordón de devastador
14774	Corona de devastador
14775	Prendas de lana de devastador
14776	Manto de devastador
14777	Escudo de devastador
14778	Ataduras de kan
14779	Pechera de kan
14780	Rodela de kan
14781	Capa de kan
14782	Guantes de kan
14783	Cinturón de kan
14784	Grebas de kan
14785	Casco de kan
14786	Musleras de kan
14787	Manto de kan
14788	Guardabrazos protectores
14789	Coraza protectora
14790	Rodela protectora
14791	Manteo protector
14792	Guanteletes protectores
14793	Pretina protectora
14794	Guardatobillos
14795	Yelmo protector
14796	Musleras protectoras
14797	Hombreras protectoras
14798	Coraza Ansia de Sangre
14799	Botas Ansia de Sangre
14800	Rodela Ansia de Sangre
14801	Manteo Ansia de Sangre
14802	Guanteletes Ansia de Sangre
14803	Cinturón Ansia de Sangre
14804	Yelmo Ansia de Sangre
14805	Calzones Ansia de Sangre
14806	Cubrehombros Ansia de Sangre
14807	Pulseras Ansia de Sangre
14808	Cinturón Golpe de Guerra
14809	Escarpes Golpe de Guerra
14810	Braquiales Golpe de Guerra
14811	Coselete Golpe de Guerra
14812	Rodela Golpe de Guerra
14813	Manteo Golpe de Guerra
14814	Casco Golpe de Guerra
14815	Guanteletes Golpe de Guerra
14816	Musleras Golpe de Guerra
14817	Hombreras Golpe de Guerra
14821	Coraza simbólica
14825	Blasón simbólico
14826	Guanteletes simbólicos
14827	Cinturón simbólico
14828	Grebas simbólicas
14829	Quijotes simbólicos
14830	Espaldares simbólicos
14831	Corona simbólica
14832	Avambrazos simbólicos
14833	Guanteletes de tirano
14834	Guardabrazos de tirano
14835	Pechera de tirano
14838	Cinturón de tirano
14839	Grebas de tirano
14840	Quijotes de tirano
14841	Cubrehombros de tirano
14842	Escudo de tirano
14843	Yelmo de tirano
14844	Coselete de Solescama
14846	Guanteletes de Solescama
14847	Cinturón de Solescama
14848	Escarpes de Solescama
14849	Casco de Solescama
14850	Quijotes de Solescama
14851	Bufas de Solescama
14852	Escudo de Solescama
14853	Guardamuñecas de Solescama
14854	Coraza soldado de caballería
14855	Guanteletes soldado de caballería
14856	Faja soldado de caballería
14857	Escarpes soldado de caballería
14858	Ornato soldado de caballería
14859	Quijotes soldado de caballería
14860	Espaldares soldado de caballería
14861	Avambrazos soldado de caballería
14862	Coraza de Líder de guerra
14863	Guanteletes de Líder de guerra
14864	Cinturón de Líder de guerra
14865	Grebas de Líder de guerra
14866	Corona de Líder de guerra
14867	Leotardos de Líder de guerra
14868	Sobrehombros de Líder de guerra
14869	Brazales de Líder de guerra
14872	Obsequio de Tirion
14894	Raíz de lirio
14895	Sobrevesta Piedra de sal
14896	Escarpes Piedra de sal
14897	Guanteletes Piedra de sal
14898	Faja Piedra de sal
14899	Yelmo Piedra de sal
14900	Quijotes Piedra de sal
14901	Hombreras Piedra de sal
14902	Escudo Piedra de sal
14903	Braquiales Piedra de sal
14904	Coraza tosca
14905	Guanteletes toscos
14906	Cinturón tosco
14907	Casco tosco
14908	Musleras toscas
14909	Sobrehombros toscos
14910	Guardabrazos tosco
14911	Botas toscas
14912	Escudo tosco
14913	Grebas de jade
14914	Brazales de jade
14915	Coraza de jade
14916	Deflector de jade
14917	Guanteletes de jade
14918	Cinturón de jade
14919	Aro de jade
14920	Quijotes de jade
14921	Cubrehombros de jade
14922	Escarpes magnánimos
14923	Guardabrazos magnánimos
14924	Coraza magnánima
14925	Yelmo magnánimo
14926	Guanteletes magnánimos
14927	Cinturón magnánimo
14928	Musleras magnánimas
14929	Hombreras magnánimas
14930	Escudo magnánimo
14931	Armadura heroica
14932	Grebas heroicas
14933	Guanteletes heroicos
14934	Faja heroica
14935	Capacete heroico
14936	Quijotes heroicos
14937	Espaldares heroicos
14938	Brazales heroicos
14939	Coselete de batallador
14940	Escarpes de batallador
14941	Braquiales de batallador
14942	Guanteletes de batallador
14943	Cinturón de batallador
14944	Corona de batallador
14945	Musleras de batallador
14946	Bufas de batallador
14947	Escudo de batallador
14948	Pechera forjada con sangre
14949	Guanteletes forjados con sangre
14950	Cinturón forjado con sangre
14951	Escarpes forjados con sangre
14952	Casco forjado con sangre
14953	Quijotes forjados con sangre
14954	Escudo forjado con sangre
14955	Hombreras forjadas con sangre
14956	Ataduras forjadas con sangre
14957	Escarpes de Gran Jefe
14958	Armadura de Gran Jefe
14959	Guanteletes de Gran Jefe
14960	Cinturón de Gran Jefe
14961	Corona de Gran Jefe
14962	Musleras de Gran Jefe
14963	Espaldares de Gran Jefe
14964	Escudo de Gran Jefe
14965	Ataduras de Gran Jefe
14966	Coraza gloriosa
14967	Guanteletes gloriosos
14968	Cinturón glorioso
14969	Ornato glorioso
14970	Quijotes gloriosos
14971	Hombreras gloriosas
14972	Escarpes gloriosos
14973	Escudo glorioso
14974	Ataduras gloriosas
14975	Arnés exaltado
14976	Guanteletes exaltados
14977	Faja exaltada
14978	Escarpes exaltados
14979	Casco exaltado
14980	Quijotes exaltados
14981	Cubrehombros exaltados
14982	Escudo exaltado
14983	Braquiales exaltados
15002	Pica de Nimboya
15003	Cinturón primigenio
15004	Botas primigenias
15005	Braciles primigenios
15006	Rodela primigenia
15007	Manteo primigenio
15008	Mitones primigenios
15009	Leotardos primigenios
15010	Sobrevesta primigenia
15011	Cordón lupino
15012	Zapatillas lupinas
15013	Puños lupinos
15014	Rodela lupina
15015	Capa lupina
15016	Manijas lupinas
15017	Leotardos lupinos
15018	Jubón lupino
15019	Manto lupino
15042	Tarro de termitas vacío
15043	Termitas de las Tierras de la Peste
15044	Barrica de termitas de las Tierras de la Peste
15045	Coraza de dragontina verde
15046	Leotardos de dragontina verde
15047	Coraza de dragontina roja
15048	Coraza de dragontina azul
15049	Sobrehombros de dragontina azul
15050	Coraza de dragontina negra
15051	Sobrehombros de dragontina negra
15052	Leotardos de dragontina negra
15053	Coraza volcánica
15054	Leotardos volcánicos
15055	Sobrehombros volcánicos
15056	Armadura de embozo de tormenta
15057	Pantalones de embozo de tormenta
15058	Sobrehombros de embozo de tormenta
15059	Coraza viva
15060	Leotardos vivos
15061	Sobrehombros vivos
15062	Leotardos de demosaurio
15063	Guanteletes de demosaurio
15064	Arnés de oso de guerra
15065	Prendas de lana de oso de guerra
15066	Coraza plumahierro
15067	Sobrehombros plumahierro
15068	Guerrera de sable de hielo
15069	Leotardos de sable de hielo
15070	Guantes de sable de hielo
15071	Botas de sable de hielo
15072	Leotardos quiméricos
15073	Botas quiméricas
15074	Guantes quiméricos
15075	Jubón quimérico
15076	Jubón de escórpido pesado
15077	Brazales de escórpido pesados
15078	Guantelete de escórpido pesado
15079	Leotardos de escórpido pesados
15080	Yelmo de escórpido pesado
15081	Sobrehombros de escórpido pesados
15082	Cinturón de escórpido pesado
15083	Guanteletes de cuero maligno
15084	Brazales de cuero maligno
15085	Armadura de cuero maligno
15086	Cinta de cuero maligno
15087	Pantalones de cuero maligno
15088	Cinturón de cuero maligno
15090	Armadura de cuero rúnico
15091	Guanteletes de cuero rúnico
15092	Brazales de cuero rúnico
15093	Cinturón de cuero rúnico
15094	Cinta de cuero rúnico
15095	Pantalones de cuero rúnico
15096	Sobrehombros de cuero rúnico
15102	Muestra examinada de Un'Goro
15103	Muestra examinada corrupta
15104	Botas portaalas
15105	Bastón de Noh'Orahil
15106	Bastón de Dar'Orahil
15107	Orbe de Noh'Orahil
15108	Orbe de Dar'Orahil
15109	Bastón de Soran'ruk
15110	Cinturón rígido
15111	Mocasines rígidos
15112	Pulseras rígidas
15113	Rodela rígida
15114	Manteo rígido
15115	Guantes rígidos
15116	Sobrehombros rígidos
15117	Leotardos rígidos
15118	Guerrera rígida
15119	Pantalones de Altonato
15120	Faja robusta
15121	Botas robustas
15122	Brazales robustos
15123	Rodela robusta
15124	Capa robusta
15125	Guantes robustos
15126	Leotardos robustos
15127	Sobrehombros robustos
15128	Guerrera robusta
15129	Yelmo robusto
15130	Jubón de degollador
15131	Botas de degollador
15132	Guardabrazos de degollador
15133	Rodela de degollador
15134	Sombrero de degollador
15135	Manteo de degollador
15136	Cinturón de degollador
15137	Mitones de degollador
15138	Capa de escamas de Onyxia
15139	Pantalones de degollador
15140	Manto de degollador
15141	Coraza de escamas de Onyxia
15142	Botas Pie fantasmal
15143	Ataduras Pie fantasmal
15144	Harapos Pie fantasmal
15145	Rodela Pie fantasmal
15146	Gorro Pie fantasmal
15147	Capa Pie fantasmal
15148	Cinturón Pie fantasmal
15149	Guantes Pie fantasmal
15150	Refuerzo Pie fantasmal
15151	Musleras Pie fantasmal
15152	Botas nocturnas
15153	Capa nocturna
15154	Fajín nocturno
15155	Guantes nocturnos
15156	Sombrero nocturno
15157	Leotardos nocturnos
15158	Hombreras nocturnas
15159	Guerrera nocturna
15160	Braciles nocturnas
15161	Cinturón imponente
15162	Botas imponentes
15163	Brazales imponentes
15164	Jubón imponente
15165	Manteo imponente
15166	Guantes imponentes
15167	Pañuelo imponente
15168	Pantalones imponentes
15169	Sobrehombros imponentes
15170	Armadura pujante
15171	Botas pujantes
15172	Braciles pujantes
15173	Manteo pujante
15174	Guantes pujantes
15175	Casco pujante
15176	Pantalones pujantes
15177	Sobrehombros pujantes
15178	Cinturón pujante
15179	Armadura acolchada pretoriana
15180	Faja de pretoriano
15181	Botas de pretoriano
15182	Braciles pretorianas
15183	Capa de pretoriano
15184	Guantes de pretoriano
15185	Almófar de pretoriano
15186	Leotardos de pretoriano
15187	Espaldares pretorianos
15188	Guardabrazos grandiosos
15189	Botas grandiosas
15190	Capa grandiosa
15191	Cinturón grandioso
15192	Guanteletes grandiosos
15193	Corona grandiosa
15194	Musleras grandiosas
15195	Coraza grandiosa
15196	Tabardo de Soldado
15197	Tabardo de explorador
15198	Colores de Caballero
15199	Heraldo de Guardia de piedra
15200	Insignia de Capataz primero
15202	Leotardos de protector salvaje
15203	Musleras de tormenta de entrañas
15204	Varita de piedra lunar
15205	Rifle con vista de búho
15206	Bordón de fuego de jade
15207	Escudo de acero
15208	Polvo de luna Cenarion
15209	Fardo de reliquias
15210	Espada corta de asaltante
15211	Espada corta de militante
15212	Espada ancha de luchador
15213	Hoja de mercenario
15214	Tizón de nobles
15215	Bracamarte furioso
15216	Runaespada
15217	Espada de viuda
15218	Espada de cristal
15219	Hoja dimensional
15220	Sable de Belivil
15221	Espada de guerra Sagrada
15222	Garrote con púas
15223	Estrella dentada
15224	Machacabatallas
15225	Martillo de secuoya
15226	Garrote gigante
15227	Cachiporra con punta de diamante
15228	Meteorito mortal
15229	Martillo Ventobendito
15230	Cuchilla de peña
15231	Hachuela seccionadora
15232	Cuchilla para picar
15233	Hacha indómita
15234	Guadaña superior
15235	Filo curvo
15236	Cuchilla de la Luna
15237	Cosechacadáveres
15238	Hacha de Señor de la Guerra
15239	Espetadora de piedra mácula
15240	Garra de demonio
15241	Cuchillo de batalla
15242	Estilete punzante
15243	Kris mortal
15244	Hoja de navaja
15245	Daga vorpal
15246	Hoja de demonio
15247	Daga de golpe de sangre
15248	Mandoble reluciente
15249	Montante pulido
15250	Flamberge de luz trémula
15251	Espada Golpecabeza
15252	Espada con colmillo
15253	Hoja decapitadora
15254	Espadón oscuro
15255	Flamberge de galante
15256	Espada de masacre
15257	Hoja espinilla
15258	Hoja de guerra divina
15259	Martillo de batalla pesado
15260	Martillo de piedra
15261	Rama de secuoya
15262	Gran maza superior
15263	Marra real
15264	Partedorsales
15265	Castigador
15266	Destructor fiero
15267	Martillo tosco
15268	Hacha de dos filos
15269	Hacha de batalla maciza
15270	Hacha de Guerra gigante
15271	Gran hacha colosal
15272	Hacha cuchilla
15273	Golpeamuerte
15274	Bastón largo de adivino
15275	Bastón de taumaturgo
15276	Bastón largo de mago
15277	Kodo gris
15278	Bastón de solsticio
15279	Varita de marfil
15280	Mano de zahorí
15281	Vara Resplandor astral
15282	Dedo de dragón
15283	Varita lunar
15284	Arco de batalla largo
15285	Arco largo de arquero
15286	Arco largo de madera roja
15287	Arco de cruzado
15288	Arco tiroespina
15289	Arco Arcogolpe
15290	Kodo marrón
15291	Taladro de arpía
15292	Kodo verde
15293	Kodo azulado
15294	Arco de asedio
15295	Arco de fuego de pinchos
15296	Arco de ojo de halcón
15297	Brazales de oso pardo
15298	Rodela de oso pardo
15299	Manteo de oso pardo
15300	Guantes de oso pardo
15301	Zapatillas de oso pardo
15302	Cinturón de oso pardo
15303	Pantalones de oso pardo
15304	Chaleco de oso pardo
15305	Botas ferales
15306	Ataduras ferales
15307	Rodela feral
15308	Cordón feral
15309	Capa feral
15310	Guantes ferales
15311	Arnés feral
15312	Leotardos ferales
15313	Hombreras ferales
15314	Montón de reliquias
15322	Pistola de ánima lisa
15323	Pistola de percusión
15324	Rifle quemado
15325	Arcabuz certero
15326	Hacha arrojadiza reluciente
15327	Daga arrojadiza maligna
15328	Llave de Joseph
15329	Cinturón de retador
15330	Botas de retador
15331	Braciles de retador
15332	Rodela de retador
15333	Capa de retador
15334	Guantes de retador
15335	Espada corta de acero brezo
15336	Leotardos de retador
15337	Sobrevesta de retador
15338	Manto de retador
15339	Gorro de abrecaminos
15340	Capa de abrecaminos
15341	Escarpines de abrecaminos
15342	Guarda de abrecaminos
15343	Guantes de abrecaminos
15344	Pantalones de abrecaminos
15345	Hombreras de abrecaminos
15346	Jubón de abrecaminos
15347	Cinturón de abrecaminos
15348	Brazales de abrecaminos
15349	Cinturón de rebanacabezas
15350	Zapatillas de rebanacabezas
15351	Braciles de rebanacabezas
15352	Rodela de rebanacabezas
15353	Gorro de rebanacabezas
15354	Capa de rebanacabezas
15355	Mitones de rebanacabezas
15356	Armadura de rebanacabezas
15357	Bufas de rebanacabezas
15358	Prendas de lana de rebanacabezas
15359	Jubón de timador
15360	Ataduras de timador
15361	Fajín de timador
15362	Botas de timador
15363	Ornato de timador
15364	Capa de timador
15365	Manijas de timador
15366	Leotardos de timador
15367	Protector de timador
15368	Espaldares de timador
15369	Cinturón de Caballero Lobo
15370	Botas de Caballero Lobo
15371	Capa de Caballero Lobo
15372	Guantes de Caballero Lobo
15373	Tiara de Caballero Lobo
15374	Leotardos de Caballero Lobo
15375	Hombreras de Caballero Lobo
15376	Armadura acolchada de Caballero Lobo
15377	Braciles de Caballero Lobo
15378	Cinturón Garrafuria
15379	Botas Garrafuria
15380	Brazales Garrafuria
15381	Coselete Garrafuria
15382	Capa Garrafuria
15383	Guantes Garrafuria
15384	Yelmo Garrafuria
15385	Leotardos Garrafuria
15386	Hombreras Garrafuria
15387	Pulseras de fuego de jade
15388	Cinturón de fuego de jade
15389	Escarpes de fuego de jade
15390	Coselete de fuego de jade
15391	Gorro de fuego de jade
15392	Capa de fuego de jade
15393	Guantes de fuego de jade
15394	Pantalones de fuego de jade
15395	Cubrehombros de fuego de jade
15396	Daga de madera curva
15397	Bastón de roble
15398	Botas de Peinarenas
15399	Cinturón de algas secas
15400	Brazales de concha de almeja
15401	Guantes de gota de pozo
15402	Guanteletes de Noosegrip
15403	Brazales Cresta
15404	Faja arrecife
15405	Guantes de criba
15406	Botas crustáceo
15407	Pellejo basto curtido
15408	Escama de escórpido gruesa
15409	Sal de roca refinada
15410	Escama de Onyxia
15411	Marca de Vadín
15412	Dragontina verde
15413	Coraza de adamantio ornamentado
15414	Dragontina roja
15415	Dragontina azul
15416	Dragontina negra
15417	Cuero de demosaurio
15418	Martillo de guerra de platino fulgurante
15419	Cuero de oso de guerra
15420	Plumahierro
15421	Embozo del Exilio
15422	Cuero de sable de hielo
15423	Cuero quimérico
15424	Hacha de Orgrimmar
15425	Brazales incomparables
15426	Botas incomparables
15427	Capa incomparable
15428	Cinturón incomparable
15429	Guantes incomparables
15430	Cinta incomparable
15431	Leotardos incomparables
15432	Sobrehombros incomparables
15433	Armadura incomparable
15434	Fajín supremo
15435	Botas supremas
15436	Brazales supremos
15437	Manteo supremo
15438	Guantes supremos
15439	Corona suprema
15440	Leotardos supremos
15441	Sobrehombros supremos
15442	Coraza suprema
15443	Kris de Orgrimmar
15444	Bastón de Orgrimmar
15445	Martillo de Orgrimmar
15446	Juego de diputado de Ventormenta
15447	Putrefacción viva
15448	Putrefacción coagulada
15449	Calzas espantosas
15450	Leotardos de cenagal
15451	Leotardos gárgola
15452	Brazales de cuentas emplumadas
15453	Brazales de sabana
15454	Mortero y majadero
15455	Togas guardapolvo
15456	Leotardos de paso ligero
15457	Sobrehombros del desierto
15458	Botas tundra
15459	Guardamuñecas tañidos rictus
15461	Botas con tacón ligero
15462	Brazales de marga
15463	Guantes de zancudo pálido
15464	Martillo de tosco
15465	Varita de picadura
15466	Escudo tintineante
15467	Anillo de la Liga de los Inventores
15468	Mantón Son del Viento
15469	Cincho Son del Viento
15470	Leotardos de guardia de las llanuras
15471	Armadura pellejomúsculo
15472	Cinturón de cargador
15473	Botas de cargador
15474	Ataduras de cargador
15475	Capa de cargador
15476	Manijas de cargador
15477	Pantalones de cargador
15478	Escudo de cargador
15479	Armadura de cargador
15480	Restos de faja
15481	Restos de grebas
15482	Restos de braciles
15483	Restos de manteo
15484	Restos de lúas
15485	Restos de pantalones
15486	Restos de escudo
15487	Restos de guerrera
15488	Sobrevesta salpicada de sangre
15489	Escarpes salpicados de sangre
15490	Capa salpicada de sangre
15491	Guantes salpicados de sangre
15492	Fajín salpicado de sangre
15493	Taparrabos salpicado de sangre
15494	Escudo salpicado de sangre
15495	Braciles salpicados de sangre
15496	Hombreras salpicadas de sangre
15497	Cordón de avanzado
15498	Zapatillas de avanzado
15499	Puños de avanzado
15500	Coselete de avanzado
15501	Capa de avanzado
15502	Guantes de avanzado
15503	Musleras de avanzado
15504	Escudo de avanzado
15505	Espaldares de avanzado
15506	Tobilleras de bruto
15507	Brazales de bruto
15508	Manteo de bruto
15509	Manijas de bruto
15510	Cinturón de bruto
15511	Musleras de bruto
15512	Escudo de bruto
15513	Espaldares de bruto
15514	Pechera de bruto
15515	Cinturón de anillas con pinchos
15516	Zapatillas de anillas con pinchos
15517	Braciles de anillas con pinchos
15518	Coraza de anillas con pinchos
15519	Capa de anillas con pinchos
15520	Guanteletes de anillas con pinchos
15521	Leotardos de anillas con pinchos
15522	Escudo de anillas con pinchos
15523	Hombreras de anillas con pinchos
15524	Sobrevesta de avizor
15525	Zapatillas de avizor
15526	Manteo de avizor
15527	Guantes de avizor
15528	Fajín de avizor
15529	Leotardos de avizor
15530	Escudo de avizor
15531	Guardahombros de avizor
15532	Braquiales de avizor
15533	Ornato de avizor
15534	Botas de anillas malignas
15535	Brazales de anillas malignos
15536	Pechera de anillas maligna
15537	Capa de anillas maligna
15538	Guanteletes de anillas malignos
15539	Pretina de anillas maligna
15540	Casco de anillas maligno
15541	Musleras de anillas malignas
15542	Hombreras de anillas malignas
15543	Escudo de anillas maligno
15544	Escarpes de escamas gruesas
15545	Pulseras de escamas gruesas
15546	Coraza de escamas gruesas
15547	Capa de escamas gruesas
15548	Guanteletes de escamas gruesas
15549	Cinturón de escama gruesa
15550	Corona de escamas gruesas
15551	Musleras de escamas gruesas
15552	Escudo de escamas gruesas
15553	Hombreras de escamas gruesas
15554	Faja de saqueador
15555	Botas de saqueador
15556	Brazales de saqueador
15557	Coselete de saqueador
15558	Corona de saqueador
15559	Capa de saqueador
15560	Guantes de saqueador
15561	Leotardos de saqueador
15562	Espaldares de saqueador
15563	Escudo de saqueador
15564	Refuerzo para armadura basto
15565	Botas de maleante
15566	Brazales de maleante
15567	Guerrera de maleante
15568	Capa de maleante
15569	Blasón de maleante
15570	Guanteletes de maleante
15571	Cinturón de maleante
15572	Aro de maleante
15573	Leotardos de maleante
15574	Hombreras de maleante
15575	Cinturón de Brillavalva
15576	Escarpes de Brillavalva
15577	Brazales de Brillavalva
15578	Coraza de Brillavalva
15579	Capa de Brillavalva
15580	Felpa de Brillavalva
15581	Guanteletes de Brillavalva
15582	Musleras de Brillavalva
15583	Hombreras de Brillavalva
15584	Escudo de Brillavalva
15585	Mandiletes Pardoc
15586	Flor de rápido crecimiento
15587	Faja Colaro
15588	Cinturón con brazales de acero
15589	Apisonadoras de determinación férrea
15590	Pulseras de determinación férrea
15591	Coraza de determinación férrea
15592	Rodela de determinación férrea
15593	Nimbo de determinación férrea
15594	Capa de determinación férrea
15595	Guantes de determinación férrea
15596	Quijotes de determinación férrea
15597	Sobrehombros de determinación férrea
15598	Faja de determinación férrea
15599	Grebas antiguas
15600	Avambrazos antiguos
15601	Pechera antigua
15602	Corona antigua
15603	Capa antigua
15604	Defensor antiguo
15605	Guanteletes antiguos
15606	Cinturón antiguo
15607	Musleras antiguas
15608	Espaldares antiguos
15609	Armadura de vínculo de huesos
15610	Brazales de vínculo de huesos
15611	Manteo de vínculo de huesos
15612	Guanteletes de vínculo de huesos
15613	Cinturón de vínculo de huesos
15614	Escarpes de vínculo de huesos
15615	Casco de vínculo de huesos
15616	Quijotes de vínculo de huesos
15617	Cubrehombros de vínculo de huesos
15618	Escudo de pared de vínculo de huesos
15619	Cinturón de malla de grifo
15620	Pulseras de malla de grifo
15621	Rodela de malla de grifo
15622	Coraza de malla de grifo
15623	Corona de malla de grifo
15624	Capa de grifo
15625	Guanteletes de malla de grifo
15626	Grebas de malla de grifo
15627	Musleras de malla de grifo
15628	Espaldares de malla de grifo
15629	Brazales formidables
15630	Escarpes formidables
15631	Pechera formidable
15632	Manteo formidable
15633	Blasón formidable
15634	Aro formidable
15635	Guanteletes formidables
15636	Cinturón formidable
15637	Musleras formidables
15638	Hombreras formidables
15639	Brazales de pielférrea
15640	Coraza de pielférrea
15641	Cinturón de pielférrea
15642	Grebas de pielférrea
15643	Capa de pielférrea
15644	Guanteletes de pielférrea
15645	Casco de pielférrea
15646	Musleras de pielférrea
15647	Espaldares de pielférrea
15648	Escudo de pielférrea
15649	Brazales despiadados
15650	Sobrevesta despiadada
15651	Corona despiadada
15652	Capa despiadada
15653	Guanteletes despiadados
15654	Cinturón despiadado
15655	Musleras despiadadas
15656	Cubrehombros despiadados
15657	Escudo despiadado
15658	Escarpes impenetrables
15659	Ataduras impenetrables
15660	Coraza impenetrable
15661	Capa impenetrable
15662	Guanteletes impenetrables
15663	Cinturón impenetrable
15664	Casco impenetrable
15665	Musleras impenetrables
15666	Espaldares impenetrables
15667	Muro impenetrable
15668	Brazales magníficos
15669	Coraza magnífica
15670	Casco magnífico
15671	Capa magnífica
15672	Guanteletes magníficos
15673	Cinturón magnífico
15674	Grebas magníficas
15675	Guardia magnífico
15676	Leotardos magníficos
15677	Sobrehombros magníficos
15678	Escarpes triunfantes
15679	Brazales triunfantes
15680	Pechera triunfante
15681	Capa triunfante
15682	Guanteletes triunfantes
15683	Faja triunfante
15684	Capacete triunfante
15685	Quijotes triunfantes
15686	Hombreras triunfantes
15687	Escudo triunfante
15688	Judías mágicas
15689	Anillo de comerciante
15690	Collar de huesos de kodo
15691	Pistolero Shottie
15692	Marcador de kodos
15693	Sobrehombros grandiosos
15694	Grebas despiadadas
15695	Escudo circular con tachuelas
15696	Escrito estropeado
15697	Botas de cuatrero kodo
15698	Bufas de riña
15699	Paquete con envoltorio marrón pequeño
15702	Anillo de químico
15703	Guardapolvo de químico
15704	Medalla insignia de cazador
15705	Espada Crestamarea
15706	Hoja de rastreador de caza
15707	Fajín Barnaleño
15708	Guantes de cuero de añublo
15709	Faja de Forjaengranaje
15710	Polvo de luna Cenarion
15722	Cantimplora de Spraggle
15723	Té con azúcar
15724	Patrón: brazales de escórpido gruesos
15725	Patrón: guanteletes de cuero maligno
15726	Patrón: coraza de dragontina verde
15727	Patrón: jubón de escórpido grueso
15728	Patrón: brazales de cuero maligno
15729	Patrón: guantes quiméricos
15730	Patrón: coraza de dragontina roja
15731	Patrón: guanteletes de cuero rúnico
15732	Patrón: leotardos volcánicos
15733	Patrón: leotardos de dragontina verde
15734	Patrón: sobrehombros vivos
15735	Patrón: sobrehombros plumahierro
15736	Compuesto especial de Smokey
15737	Patrón: botas quiméricas
15738	Patrón: guanteletes de escórpido gruesos
15739	Patrón: brazales de cuero rúnico
15740	Patrón: botas de sable de hielo
15741	Patrón: pantalones de embozo de tormenta
15742	Patrón: arnés de oso de guerra
15743	Patrón: cinturón de escórpido grueso
15744	Patrón: cinta de cuero maligno
15745	Patrón: cinturón de cuero rúnico
15746	Patrón: leotardos quiméricos
15747	Patrón: leotardos de sable de hielo
15748	Patrón: leotardos de escórpido gruesos
15749	Patrón: coraza volcánica
15750	Cetro de Luz
15751	Patrón: coraza de dragontina azul
15752	Patrón: leotardos vivos
15753	Patrón: armadura de embozo de tormenta
15754	Patrón: prendas de lana de oso de guerra
15755	Patrón: jubón quimérico
15756	Patrón: cinta de cuero rúnico
15757	Patrón: pantalones de cuero maligno
15758	Patrón: guanteletes de demosaurio
15759	Patrón: coraza de dragontina negra
15760	Patrón: coraza plumahierro
15761	Patrón: guantes de sable de hielo
15762	Patrón: yelmo de escórpido grueso
15763	Patrón: sobrehombros de dragontina azul
15764	Patrón: sobrehombros de embozo de tormenta
15765	Patrón: pantalones de cuero rúnico
15766	Gema de la serpiente
15767	Llave de Hameya
15768	Patrón: cinturón de cuero maligno
15769	Patrón: capa de escamas de Onyxia
15770	Patrón: sobrehombros de dragontina negra
15771	Patrón: coraza viva
15772	Patrón: leotardos de demosaurio
15773	Patrón: armadura de cuero maligno
15774	Patrón: sobrehombros de escórpido gruesos
15775	Patrón: sobrehombros volcánicos
15776	Patrón: armadura de cuero rúnico
15777	Patrón: sobrehombros de cuero rúnico
15778	Yeti mecánico
15779	Patrón: guerrera de sable de hielo
15780	Patrón: coraza de escamas de Onyxia
15781	Patrón: leotardos de dragontina negra
15782	Hoja de acechabestias
15783	Daga cazabestias
15784	Manto de brisa de cristal
15785	Cabeza de Zaeldarr
15786	Chaleco Pulso helecho
15787	Camisote a rayas de sauce
15788	Informe de Vista Eterna
15789	Capa río profundo
15790	Estudios sobre la Comunicación con los Espíritus
15791	Fajín turquesa
15792	Bufas de madera surcada
15793	Un hueso roído
15794	Taparrabos rasgado ogro
15795	Guanteletes de bruma esmeralda
15796	Brazales de espuma marina
15797	Avambrazos fulgentes
15798	Diente de ogro astillado
15799	Medalla de honor heroico
15800	Espada corta de intrépido
15801	Espada corta valerosa
15802	Botas de tela lunar
15803	Libro de los Ancestros
15804	Mantón color guinda
15805	Rosa de Penelope
15806	Canción de Mirah
15807	Ballesta ligera
15808	Ballesta ligera refinada
15809	Ballesta pesada
15810	Lanza corta
15811	Lanza pesada
15812	Amito orquídea
15813	Cinturón de oro
15814	Destripador de Hameya
15815	Capa de Hameya
15822	Bufas sombradermas
15823	Guanteletes de ladrillo de acero
15824	Togas de Astoria
15825	Chaleco de calador
15826	Bálsamo animal curativo
15827	Coraza de Luna de jade
15842	Muestrario de Cima Calígine vacía
15843	Muestrario de Cima Calígine lleno
15844	Muestra vacía de Salto de Fonroca
15845	Muestrario del Salto de Fonroca lleno
15846	Salero
15847	Registro de Quel'Thalas
15848	Cajón de imanes fantasmales
15849	Ectoplasma
15850	Parche de pelaje de Alaocaso
15851	Hongo lunar
15852	Cuerno de kodo
15853	Segadora de viento
15854	Esquirla danzante
15855	Anillo de Protección
15856	Dije arcoluz
15857	Sucesor aterramagos
15858	Guantes viento libre
15859	Faja de poste marino
15860	Guardabrazos golpeguiño
15861	Botines Piepresto
15862	Cuchilla de carga
15863	Cetro solemne
15864	Brazales de cóndor
15865	Rodela garrancla
15866	Bolsa de remedio polvo de velo
15867	Talismán prismático
15868	Orden del Gran Cruzado
15869	Llave esqueleto de plata
15870	Llave esqueleto dorada
15871	Llave esqueleto de veraplata
15872	Llave esqueleto de arcanita
15873	Copa interminable de John Andrajoso
15874	Almeja blanda
15875	Manzana podrida
15876	Cofre de Nathanos
15877	Adorno de altar
15878	Llave de plata Masatormento
15879	Garra de Señor Supremo Ror
15880	Cabeza de Ramstein el Empachador
15881	Llave de oro de Masatormento
15882	Medio colgante de Resistencia acuática
15883	Medio colgante de Agilidad acuática
15884	Libro de entradas de Augustus
15885	Colgante del León Marino
15886	Filacteria de Timolain
15887	Guarda heroica
15890	Escudo soldado de caballería
15891	Escudo descomunal
15892	Escudo de destripador
15893	Rodela de prospector
15894	Rodela Erizacorteza
15895	Rodela quemada
15902	Una bolsa de sorpresas
15903	Garra para diestros
15904	Hojas para diestros
15905	Nudillos de latón para diestros
15906	Nudillos de latón para zurdos
15907	Garra para la mano izquierda
15908	Fusta de doma
15909	Hojas para zurdos
15911	Fusta de doma
15912	Orbe de bucanero
15913	Fusta de doma
15914	Fusta de doma
15915	Fusta de doma
15916	Fusta de doma
15917	Fusta de doma
15918	Esfera de implorador
15919	Fusta de doma
15920	Fusta de doma
15921	Fusta de doma
15922	Fusta de doma
15923	Fusta de doma
15924	Carne de almeja blanda
15925	Báculo de oficial
15926	Orbe Vinculahechizo
15927	Esfera brillante
15928	Vara de hilo de plata
15929	Orbe Cielo Nocturno
15930	Cetro imperial rojo
15931	Estrella Arcana
15932	Jarra de discípulo
15933	Rama simple
15934	Báculo de sabio
15935	Vara durable
15936	Rama Tejeocaso
15937	Esfera invernal
15938	Orbe místico
15939	Cetro de concejal
15940	Cetro elegante
15941	Centro de consejero mayor
15942	Vara de maestro
15943	Escudo imbuido
15944	Orbe ancestral
15945	Báculo rúnico
15946	Esfera de místico
15947	Estrella sanguina
15962	Vara de sátiro
15963	Rama de paño de piedra
15964	Estrella Sedarena
15965	Orbe Cazavientos
15966	Orbe de embozo de veneno
15967	Estrella de Altonato
15968	Esfera elunarita
15969	Orbe perlado
15970	Rama nativa
15971	Vara aborigen
15972	Jarra de ritual
15973	Estrella de vigía
15974	Vara pagana
15975	Cetro Clamalluvias
15976	Rama Piel de Cardo
15977	Orbe vital
15978	Vara de geomántico
15979	Báculo de seda de ascuas
15980	Orbe Niebla Negra
15981	Esfera lunar
15982	Vara de tejido de sangre
15983	Cetro de Gaia
15984	Cetro opulento
15985	Rama arácnida
15986	Estrella de Tirahuesos
15987	Orbe astral
15988	Orbe rutilante
15989	Vara eterna
15990	Escudo duradero
15991	Escudo de Líder de guerra
15992	Pólvora densa
15993	Granada de torio
15994	Trasto de torio
15995	Rifle de torio
15996	Sapo mecánico casi vivo
15997	Proyectiles de torio
15998	Nota de Lewis
15999	Gafas de poder con hechizos Xtremo Plus
16000	Tubo de torio
16001	Insignia IV:7 (Fredo)
16002	Insignia IV:7 (Turyen)
16003	Insignia IV:7 (Rutger)
16004	Rifle Hierro Negro
16005	Bomba Hierro Negro
16006	Conversor de arcanita delicado
16007	Rifle de arcanita impecable
16008	Gafas de maestro ingeniero
16009	Modulador de amplificación de voz
16022	Dragonizo de arcanita
16023	Muñeco-diana magistral
16026	PVP Plate Helm Alliance
16027	PVP Plate Breastplate Alliance
16028	PVP Plate Legplates Alliance
16029	PVP Plate Gauntlets Alliance
16030	PVP Plate Boots Alliance
16031	PVP Plate Shoulder Alliance
16033	PVP Plate Wrist Alliance
16034	PVP Plate Cloak Alliance
16035	PVP Cloth Helm Horde
16036	PVP Cloth Robe Horde
16037	PVP Cloth Legs Horde
16038	PVP Cloth Shoulder Horde
16039	Filosón Ta'Kierthan
16040	Bomba Arcana
16041	Esquema: granada de torio
16042	Esquema: trasto de torio
16043	Esquema: rifle de torio
16044	Esquema: sapo mecánico casi vivo
16045	Esquema: gafas de poder con hechizos Xtremo Plus
16046	Esquema: muñeco-diana magistral
16047	Esquema: tubo de torio
16048	Esquema: rifle Hierro Negro
16049	Esquema: bomba Hierro Negro
16050	Esquema: conversor de arcanita delicado
16051	Esquema: proyectiles de torio
16052	Esquema: modulador de amplificación de voz
16053	Esquema: gafas de maestro ingeniero
16054	Esquema: dragonizo de arcanita
16055	Esquema: bomba Arcana
16056	Esquema: rifle de arcanita impecable
16057	Morral de expedicionario
16058	Sello de Vadín
16059	Camisa marrón común
16060	Camisa blanca común
16072	Libro de cocina para expertos
16073	Libro de cocina de artesano
16082	Pesca de artesano: El truco de los señuelos
16083	Pesca para expertos: La lubina y tú
16084	Primeros auxilios para expertos: Entre vendas
16085	Artesano de primeros auxilios: Cúrate tú mismo
16110	Receta: tortilla gigante
16111	Receta: chili de cangrejo especiado
16112	Manual: venda de seda gruesa
16113	Manual: venda de tejido mágico
16114	Porra de supervisor
16115	Cajón de Osric
16166	Sopa de judías
16167	Obsequio versicolor
16168	Melocotón del cielo
16169	Pastel de arroz salvaje
16170	Mandú al vapor
16171	Shinsollo
16189	Dorso de la carta de Maggran
16190	Restos de desgarradora Furia Sangrienta
16191	Espejo ornamentado
16192	Colmillo de Besseleth
16202	Esencia eterna inferior
16203	Esencia eterna superior
16204	Polvo de ilusión
16205	Semilla de Gaia
16206	Vara de arcanita
16207	Vara rúnica de arcanita
16208	Semillas de Gaia encantadas
16209	Orden de Podrig
16210	Cajón de Gordok
16214	Fórmula: encantar brazales: Intelecto superior
16215	Fórmula: encantar botas: aguante superior
16216	Fórmula: encantar capa: resistencia superior
16217	Fórmula: encantar escudo: aguante superior
16218	Fórmula: encantar brazales: espíritu excelente
16219	Fórmula: encantar guantes: agilidad superior
16220	Fórmula: encantar botas: espíritu
16221	Fórmula: encantar pechera: salud sublime
16222	Fórmula: encantar escudo: espíritu excelente
16223	Fórmula: encantar arma: escalofrío gélido
16224	Fórmula: encantar capa: defensa excelente
16242	Fórmula: encantar pechera: maná sublime
16243	Fórmula: vara rúnica de arcanita
16244	Fórmula: encantar guantes: fuerza superior
16245	Fórmula: encantar botas: agilidad superior
16246	Fórmula: encantar brazales: fuerza excelente
16247	Fórmula: encantar arma de 2M: impacto excelente
16248	Fórmula: encantar arma: profano
16249	Fórmula: encantar arma de 2M: intelecto sublime
16250	Fórmula: encantar arma: golpes excelentes
16251	Fórmula: encantar brazales: aguante excelente
16252	Fórmula: encantar arma: cruzado
16253	Fórmula: encantar pechera: estadísticas superiores
16254	Fórmula: encantar arma: robo de vida
16255	Fórmula: encantar arma de 2M: espíritu sublime
16262	Colección de Nessa
16263	Respuesta de Laird
16282	Fardo de pellejos
16283	Artículos de cuero de Ahanu
16302	Grimorio Descarga de Fuego (Rango 2)
16303	Pata de Ursangous
16304	Cabeza de Shadumbra
16305	Garfa de Garrafilada
16306	Carne de Zargh
16307	Carta de Gryshka
16308	Palanqueta de Crestanorte
16309	Amuleto Pirodraco
16310	Lista de Brock
16311	Picos honorarios
16312	Incendritas
16313	Cofre de Félix
16314	Cubo de tornillos de Félix
16315	Manteo de Alférez
16316	Grimorio Descarga de Fuego (Rango 3)
16317	Grimorio Descarga de Fuego (Rango 4)
16318	Grimorio Descarga de Fuego (Rango 5)
16319	Grimorio Descarga de Fuego (Rango 6)
16320	Grimorio Descarga de Fuego (Rango 7)
16321	Grimorio Pacto de sangre (Rango 1)
16322	Grimorio Pacto de sangre (Rango 2)
16323	Grimorio Pacto de sangre (Rango 3)
16324	Grimorio Pacto de sangre (Rango 4)
16325	Grimorio Pacto de sangre (Rango 5)
16326	Grimorio Escudo de Fuego (Rango 1)
16327	Grimorio Escudo de Fuego (Rango 2)
16328	Grimorio Escudo de Fuego (Rango 3)
16329	Grimorio Escudo de Fuego (Rango 4)
16330	Grimorio Escudo de Fuego (Rango 5)
16331	Grimorio Cambio de fase
16332	Pico de Thazz'ril
16333	Restos de Samuel
16335	Insignia de Capataz primero
16336	Manteo de Alférez
16337	Manteo de Alférez
16338	Corcel de Teniente caballero
16339	Corcel de Comandante
16341	Capa de Sargento
16342	Manteo de Sargento
16343	Montura de Guardia de sangre
16344	Montura de teniente general
16345	Hoja de Gran Señor de la Guerra
16346	Grimorio Tormento (Rango 2)
16347	Grimorio Tormento (Rango 3)
16348	Grimorio Tormento (Rango 4)
16349	Grimorio Tormento (Rango 5)
16350	Grimorio Tormento (Rango 6)
16351	Grimorio Sacrificio (Rango 1)
16352	Grimorio Sacrificio (Rango 2)
16353	Grimorio Sacrificio (Rango 3)
16354	Grimorio Sacrificio (Rango 4)
16355	Grimorio Sacrificio (Rango 5)
16356	Grimorio Sacrificio (Rango 6)
16357	Grimorio Consumir Sombras (Rango 1)
16358	Grimorio Consumir Sombras (Rango 2)
16359	Grimorio Consumir Sombras (Rango 3)
16360	Grimorio Consumir Sombras (Rango 4)
16361	Grimorio Consumir Sombras (Rango 5)
16362	Grimorio Consumir Sombras (Rango 6)
16363	Grimorio Sufrimiento (Rango 1)
16364	Grimorio Sufrimiento (Rango 2)
16365	Grimorio Sufrimiento (Rango 3)
16366	Grimorio Sufrimiento (Rango 4)
16367	Fajín de seda de Capitán caballero
16368	Grimorio Latigazo doloroso (Rango 2)
16369	Botas de seda de Teniente caballero
16370	Puños de seda de Capitán caballero
16371	Grimorio Latigazo doloroso (Rango 3)
16372	Grimorio Latigazo doloroso (Rango 4)
16373	Grimorio Latigazo doloroso (Rango 5)
16374	Grimorio Latigazo doloroso (Rango 6)
16375	Grimorio Beso calmante (Rango 1)
16376	Grimorio Beso calmante (Rango 2)
16377	Grimorio Beso calmante (Rango 3)
16378	Grimorio Beso calmante (Rango 4)
16379	Grimorio Seducción
16380	Grimorio Invisibilidad inferior
16381	Grimorio Devorar magia (Rango 2)
16382	Grimorio Devorar magia (Rango 3)
16383	Grimorio Devorar magia (Rango 4)
16384	Grimorio Sangre mácula (Rango 1)
16385	Grimorio Sangre mácula (Rango 2)
16386	Grimorio Sangre mácula (Rango 3)
16387	Grimorio Sangre mácula (Rango 4)
16388	Grimorio Bloqueo de hechizo (Rango 1)
16389	Grimorio Bloqueo de hechizo (Rango 2)
16390	Grimorio Paranoia
16391	Guantes de seda de Teniente caballero
16392	Botas de cuero de Teniente caballero
16393	Borceguíes de pellejo de dragón de Teniente caballero
16394	Brazales de cuero de Capitán caballero
16395	Braquiales de pellejo de dragón de Capitán caballero
16396	Guanteletes de cuero de Teniente caballero
16397	Guantes de pellejo de dragón de Teniente caballero
16398	Cinturón de cuero de Capitán caballero
16399	Faja de pellejo de dragón de Capitán caballero
16400	Faja de anillas de Capitán caballero
16401	Botas de anillas de Teniente caballero
16402	Guardamuñecas de anillas de Capitán caballero
16403	Guanteletes de anillas de Teniente caballero
16404	Guardamuñecas de placas de Capitán caballero
16405	Botas de placas de Teniente caballero
16406	Guanteletes de placas de Teniente caballero
16407	Faja de placas de Capitán caballero
16408	Globo de agua contaminada
16409	Escarpes de láminas de Teniente caballero
16410	Guanteletes de láminas de Teniente caballero
16411	Cincho de láminas de Capitán caballero
16412	Braquiales de láminas de Capitán caballero
16413	Vestimenta de seda de Capitán caballero
16414	Leotardos de seda de Capitán caballero
16415	Bufas de seda de Teniente coronel
16416	Corona de Teniente coronel
16417	Armadura de cuero de Capitán caballero
16418	Velo de cuero de Teniente coronel
16419	Musleras de cuero de Capitán caballero
16420	Bufas de cuero de Teniente coronel
16421	Guerrera de pellejo de dragón de Capitán caballero
16422	Leotardos de pellejo de dragón de Capitán caballero
16423	Cubrehombros de pellejo de dragón de Teniente coronel
16424	Embozo de pellejo de dragón de Teniente coronel
16425	Camisote de anillas de Capitán caballero
16426	Leotardos de anillas de Capitán caballero
16427	Espaldares de anillas de Teniente coronel
16428	Casco de anillas de Teniente coronel
16429	Yelmo de placas de Teniente coronel
16430	Coselete de placas de Capitán caballero
16431	Leotardos de placas de Capitán caballero
16432	Espaldares de placas de Teniente coronel
16433	Coraza de láminas de Capitán caballero
16434	Protegecabezas de láminas de Teniente coronel
16435	Leotardos de láminas de Capitán caballero
16436	Sobrehombros de láminas de Teniente coronel
16437	Borceguíes de seda de Mariscal
16438	Brazales de seda de Mariscal
16439	Fajín de seda de Mariscal
16440	Guantes de seda de Mariscal
16441	Nimbo de Mariscal de campo
16442	Leotardos de seda de Mariscal
16443	Vestimentas de seda de Mariscal de campo
16444	Bufas de seda de Mariscal de campo
16445	Brazales de pellejo de dragón de Mariscal
16446	Guardapiés de cuero de Mariscal
16447	Guardarrenes de pellejo de dragón de Mariscal
16448	Guanteletes de pellejo de dragón de Mariscal
16449	Bufas de pellejo de dragón de Mariscal de campo
16450	Musleras de pellejo de dragón de Mariscal
16451	Casco de pellejo de dragón de Mariscal de campo
16452	Coraza de pellejo de dragón de Mariscal de campo
16453	Pechera de cuero de Mariscal de campo
16454	Lúas de cuero de Mariscal
16455	Máscara de cuero de Mariscal de campo
16456	Leotardos de cuero de Mariscal
16457	Cubrehombros de cuero de Mariscal de campo
16458	Cincho de cuero de Mariscal
16459	Botas de pellejo de dragón de Mariscal
16460	Braquiales de cuero de Mariscal
16461	Brazales de anillas de Mariscal
16462	Botas de anillas de Mariscal
16463	Mandiletes de anillas de Mariscal
16464	Faja de anillas de Mariscal
16465	Yelmo de anillas de Mariscal de campo
16466	Coraza de anillas de Mariscal de campo
16467	Musleras de anillas de Mariscal
16468	Bufas de anillas de Mariscal de campo
16469	Guardabrazos de láminas de Mariscal
16470	Cinturón de láminas de Mariscal
16471	Guantes de láminas de Mariscal
16472	Botas de láminas de Mariscal
16473	Peto de láminas de Mariscal de campo
16474	Visera de láminas de Mariscal de campo
16475	Quijotes de láminas de Mariscal
16476	Espaldares de láminas de Mariscal de campo
16477	Armadura de placas de Mariscal de campo
16478	Yelmo de placas de Mariscal de campo
16479	Musleras de placas de Mariscal
16480	Guardahombros de placas de Mariscal de campo
16481	Brazales de placas de Mariscal
16482	Faja de placas de Mariscal
16483	Botas de placas de Mariscal
16484	Guanteletes de placas de Mariscal
16485	Borceguíes de seda de Guardia de sangre
16486	Puños de seda de Gran capataz
16487	Guantes de seda de Guardia de sangre
16488	Cinturón de seda de Legionario
16489	Caperuza de seda de Campeón
16490	Pantalones de seda de Legionario
16491	Togas de seda de Legionario
16492	Hombreras de seda de Campeón
16493	Guardabrazos de pellejo de dragón de Legionario
16494	Botas de pellejo de dragón de Guardia de sangre
16495	Pretina de pellejo de dragón de Legionario
16496	Guanteletes de pellejo de dragón de Guardia de sangre
16497	Guardabrazos de cuero de Gran capataz
16498	Botines de cuero de Guardia de sangre
16499	Abrazaderas de cuero de Guardia de sangre
16500	Faja de cuero de Legionario
16501	Bufas de pellejo de dragón de Campeón
16502	Calzas de pellejo de dragón de Legionario
16503	Yelmo de pellejo de dragón de Campeón
16504	Coraza de pellejo de dragón de Legionario
16505	Camisote de cuero de Legionario
16506	Protegecabezas de cuero de Campeón
16507	Manto de cuero de Campeón
16508	Leotardos de cuero de Legionario
16509	Botas de placas de Guardia de sangre
16510	Guantes de placas de Guardia de sangre
16511	Cincho de placas de Legionario
16512	Brazales de placas del Legionario
16513	Armadura de placas de Legionario
16514	Protegecabezas de placas de Campeón
16515	Musleras de placas de Legionario
16516	Espaldares de placas de Campeón
16517	Brazales de anillas de Legionario
16518	Botos de malla de Guardia de sangre
16519	Mandiletes de malla de Guardia de sangre
16520	Cincho de malla de Legionario
16521	Yelmo de malla de Campeón
16522	Pechera de malla de Legionario
16523	Leotardos de malla de Legionario
16524	Sobrehombros de malla de Campeón
16525	Coraza de anillas de Legionario
16526	Protegecabezas de anillas de Campeón
16527	Leotardos de anillas de Legionario
16528	Espaldares de anillas de Campeón
16529	Faja de anillas de Legionario
16530	Guanteletes de anillas de Guardia de sangre
16531	Botas de anillas de Guardia de sangre
16532	Guardamuñecas de malla de Gran capataz
16533	Capucha de seda de Señor de la Guerra
16534	Calzas de seda de General
16535	Vestimenta de seda de Señor de la Guerra
16536	Amito de seda de Señor de la Guerra
16537	Fajín de seda de General
16538	Puños de seda de General
16539	Botas de seda de General
16540	Manoplas de seda de General
16541	Armadura de placas de Señor de la Guerra
16542	Celada de placas de Señor de la Guerra
16543	Leotardos de placas de General
16544	Sobrehombros de placas de Señor de la Guerra
16545	Botas de placas de General
16546	Guardabrazos de placas de General
16547	Faja de placas de General
16548	Guanteletes de placas de General
16549	Camisote de pellejo de dragón de Señor de la Guerra
16550	Casco de pellejo de dragón de Señor de la Guerra
16551	Cubrehombros de pellejo de dragón de Señor de la Guerra
16552	Leotardos de pellejo de dragón de General
16553	Brazales de pellejo de dragón de General
16554	Botas de pellejo de dragón de General
16555	Guantes de pellejo de dragón de General
16556	Cinturón de pellejo de dragón de General
16557	Faja de cuero de General
16558	Botines de cuero de General
16559	Braquiales de cuero de General
16560	Mitones de cuero de General
16561	Yelmo de cuero de Señor de la Guerra
16562	Bufas de cuero de Señor de la Guerra
16563	Coraza de cuero de Señor de la Guerra
16564	Musleras de cuero de General
16565	Pechera de anillas de Señor de la Guerra
16566	Casco de anillas de Señor de la Guerra
16567	Musleras de anillas de General
16568	Sobrehombros de anillas de Señor de la Guerra
16569	Escarpes de anillas de General
16570	Guardamuñecas de anillas de General
16571	Guantes de anillas de General
16572	Faja de anillas de General
16573	Botas de malla de General
16574	Guanteletes de malla de General
16575	Pretina de malla de General
16576	Brazales de malla de General
16577	Armadura de malla de Señor de la Guerra
16578	Yelmo de Señor de la Guerra
16579	Leotardos de malla de General
16580	Bufas de malla de Señor de la Guerra
16581	Cristal de resonita
16583	Figurilla demoníaca
16602	Talismán trol
16603	Cristal de resonita encantado
16604	Togas lunares de Elune
16605	Togas de la luz de Fraile
16606	Togas de maleficio Juju
16607	Togas de sacrificio de acólito
16608	Cinturón acuario
16622	Lanzaespinas
16623	Medallón opalino
16642	Manual de instrucciones de trituradora: Capítulo 1
16643	Manual de instrucciones de trituradora: Capítulo 2
16644	Manual de instrucciones de trituradora: Capítulo 3
16645	Manual de instrucciones de trituradora: Página 1
16646	Manual de instrucciones de trituradora: Página 2
16647	Manual de instrucciones de trituradora: Página 3
16648	Manual de instrucciones de trituradora: Página 4
16649	Manual de instrucciones de trituradora: Página 5
16650	Manual de instrucciones de trituradora: Página 6
16651	Manual de instrucciones de trituradora: Página 7
16652	Manual de instrucciones de trituradora: Página 8
16653	Manual de instrucciones de trituradora: Página 9
16654	Manual de instrucciones de trituradora: Página 10
16655	Manual de instrucciones de trituradora: Página 11
16656	Manual de instrucciones de trituradora: Página 12
16658	Capa de cazador salvaje
16659	Cinturón de equilibrista
16660	Escudo lodo acumulado
16661	Manteo de sauce suave
16662	Fragmento del Ojo del Dragón
16663	Sangre de dragón Negro Campeón
16664	Brazales ornamentados
16665	Escrito sobre Disparo tranquilizante
16666	Jubón de elementos
16667	Almófar de elementos
16668	Falda de elementos
16669	Espaldares de elementos
16670	Botas de elementos
16671	Ataduras de elementos
16672	Guanteletes de elementos
16673	Cordón de elementos
16674	Guerrera de acechabestias
16675	Botas de acechabestias
16676	Guantes de acechabestias
16677	Almete de acechabestias
16678	Pantalones de acechabestias
16679	Manto de acechabestias
16680	Cinturón de acechabestias
16681	Ataduras de acechabestias
16682	Botas de magister
16683	Ataduras de magister
16684	Guantes de magister
16685	Cinturón de magister
16686	Corona de magister
16687	Leotardos de magister
16688	Togas de magister
16689	Manto de magister
16690	Toga de devoto
16691	Sandalias de devoto
16692	Guantes de devoto
16693	Corona de devoto
16694	Saya de devoto
16695	Manto de devoto
16696	Cinturón de devoto
16697	Brazales de devoto
16698	Máscara calígine
16699	Leotardos calígine
16700	Toga calígine
16701	Manto calígine
16702	Cinturón calígine
16703	Brazales calígine
16704	Sandalias calígine
16705	Brazaletes calígine
16706	Jubón Corazón Salvaje
16707	Almete arte sombrío
16708	Bufas arte sombrío
16709	Pantalones arte sombrío
16710	Brazales arte sombrío
16711	Botas arte sombrío
16712	Guantes arte sombrío
16713	Cinturón arte sombrío
16714	Brazales Corazón Salvaje
16715	Botas Corazón Salvaje
16716	Cinturón Corazón Salvaje
16717	Guantes Corazón Salvaje
16718	Bufas Corazón Salvaje
16719	Falda Corazón Salvaje
16720	Capucha Corazón Salvaje
16721	Guerrera arte sombrío
16722	Brazales Forjaluz
16723	Cinturón Forjaluz
16724	Guanteletes Forjaluz
16725	Botas Forjaluz
16726	Coraza Forjaluz
16727	Yelmo Forjaluz
16728	Quijotes Forjaluz
16729	Bufas Forjaluz
16730	Coraza de valor
16731	Yelmo de valor
16732	Quijotes de valor
16733	Bufas de valor
16734	Botas de valor
16735	Brazales de valor
16736	Cinturón de valor
16737	Guanteletes de valor
16738	Guantes de semilla marchita
16739	Manto de Madera Basta
16740	Guantes de manejo de trituradora
16741	Manijas de aceite
16742	Espadas dentadas Grito de Guerra
16743	Cuerda
16744	Aceite Grito de Guerra
16745	Envío de hachas de los Grito de Guerra
16746	Informe Grito de Guerra
16747	Candado roto
16748	Forro acolchado
16762	Núcleo de las profundidades
16763	Novedades de corredor Grito de Guerra
16764	Novedades de explorador Grito de Guerra
16765	Novedades de escolta Grito de Guerra
16766	Sopa de almejas de Minahonda
16767	Receta: sopa de almejas de Minahonda
16768	Faltriquera de medicinas fúrbolg
16769	Tótem de medicina fúrbolg
16782	Globo de agua extraño
16783	Fardo de informes
16784	Zafiro de Aku'Mai
16786	Ojo de dragauro negro
16787	Amuleto de Subversión Dracónica
16788	Timón del capitán Masatormento
16789	Caña del timón del capitán Masatormento
16790	Nota mojada
16791	Puños corrientes de seda
16792	Garrote gigante
16793	Sobrehombros Arcometal
16794	Guardamuñecas para empuñaduras de acero
16795	Corona arcanista
16796	Leotardos arcanistas
16797	Manto arcanista
16798	Togas arcanistas
16799	Ataduras arcanistas
16800	Botas arcanistas
16801	Guantes arcanistas
16802	Cinturón de arcanista
16803	Zapatillas corazón vil
16804	Brazales corazón vil
16805	Guantes corazón vil
16806	Cinturón corazón vil
16807	Hombreras corazón vil
16808	Cuernos corazón vil
16809	Togas corazón vil
16810	Pantalones corazón vil
16811	Botas de profecía
16812	Guantes de profecía
16813	Aro de profecía
16814	Pantalones de profecía
16815	Togas de profecía
16816	Manto de profecía
16817	Faja de profecía
16818	Cinturón viento abisal
16819	Avambrazos de profecía
16820	Pechera de Destripador Nocturno
16821	Casquete de Destripador Nocturno
16822	Pantalones de Destripador Nocturno
16823	Hombreras de Destripador Nocturno
16824	Botas de Destripador Nocturno
16825	Pulseras de Destripador Nocturno
16826	Guantes de Destripador Nocturno
16827	Cinturón de Destripador Nocturno
16828	Cinturón Cenarion
16829	Botas Cenarion
16830	Brazales Cenarion
16831	Guantes Cenarion
16832	Bufas Colmillo de Sangre
16833	Vestimentas Cenarion
16834	Yelmo Cenarion
16835	Leotardos Cenarion
16836	Bufas Cenarion
16837	Botas Furia terrenal
16838	Cinturón Furia terrenal
16839	Guanteletes Furia terrenal
16840	Brazales Furia terrenal
16841	Vestimentas Furia terrenal
16842	Casco Furia terrenal
16843	Musleras Furia terrenal
16844	Cubrehombros Furia terrenal
16845	Coraza de acechagigantes
16846	Casco de acechagigantes
16847	Leotardos de acechagigantes
16848	Cubrehombros de acechagigantes
16849	Botas de acechagigantes
16850	Brazales de acechagigantes
16851	Cinturón de acechagigantes
16852	Guantes de acechagigantes
16853	Coselete de Justiciero
16854	Yelmo de Justiciero
16855	Quijotes de Justiciero
16856	Bufas de Justiciero
16857	Brazales de Justiciero
16858	Cinturón de Justiciero
16859	Botas de Justiciero
16860	Guanteletes de Justiciero
16861	Brazales de poderío
16862	Escarpes de poderío
16863	Guanteletes de poderío
16864	Cinturón de poderío
16865	Coraza de poderío
16866	Yelmo de poderío
16867	Quijotes de poderío
16868	Espaldares de poderío
16869	El cráneo de arúspice
16870	El cráneo de Somnus
16871	El cráneo de Chronalis
16872	El cráneo de Axtroz
16873	Guantes de pelaje trenzado
16882	Caja de trastos maltrecha
16883	Caja de trastos desgastada
16884	Caja de trastos robusta
16885	Caja de trastos pesada
16886	Sable de forajido
16887	Dedo de bruja
16888	Amuleto Pirodraco apagado
16889	Bastón de apoyo pulido
16890	Alfanje de metal de pizarra
16891	Espada corta de arcilla
16892	Piedra de alma inferior
16893	Piedra de alma
16894	Vara de cristal claro
16895	Piedra de alma superior
16896	Piedra de alma sublime
16897	Coselete de Tempestira
16898	Botas de Tempestira
16899	Manoplas de Tempestira
16900	Casquete de Tempestira
16901	Musleras de Tempestira
16902	Espaldares de Tempestira
16903	Cinturón de Tempestira
16904	Brazales de Tempestira
16905	Pechera Colmillo de Sangre
16906	Botas Colmillo de Sangre
16907	Guantes Colmillo de Sangre
16908	Caperuza Colmillo de Sangre
16909	Pantalones Colmillo de Sangre
16910	Cinturón Colmillo de Sangre
16911	Brazales Colmillo de Sangre
16912	Botas viento abisal
16913	Guantes viento abisal
16914	Corona viento abisal
16915	Pantalones viento abisal
16916	Togas viento abisal
16917	Manto viento abisal
16918	Ataduras viento abisal
16919	Botas de Trascendencia
16920	Manoplas de Trascendencia
16921	Halo de Trascendencia
16922	Leotardos de trascendencia
16923	Togas de trascendencia
16924	Espaldares de trascendencia
16925	Cinturón de Trascendencia
16926	Ataduras de Trascendencia
16927	Botas de la Némesis
16928	Guantes de la Némesis
16929	Capacete de la Némesis
16930	Leotardos de la Némesis
16931	Togas de la Némesis
16932	Bufas de la Némesis
16933	Cinturón de la Némesis
16934	Brazales de la Némesis
16935	Brazales de acechadragón
16936	Cinturón de acechadragón
16937	Bufas de acechadragón
16938	Musleras de acechadragón
16939	Yelmo de acechadragón
16940	Guanteletes de acechadragón
16941	Grebas de acechadragón
16942	Coraza de acechadragón
16943	Brazales de diez tormentas
16944	Cinturón de diez tormentas
16945	Cubrehombros de diez tormentas
16946	Quijotes de diez tormentas
16947	Casco de diez tormentas
16948	Guanteletes de diez tormentas
16949	Grebas de diez tormentas
16950	Coraza de diez tormentas
16951	Ataduras de sentencia
16952	Cinturón de sentencia
16953	Bufas de sentencia
16954	Quijotes de sentencia
16955	Corona de sentencia
16956	Guanteletes de sentencia
16957	Escarpes de sentencia
16958	Coraza de sentencia
16959	Pulseras de Cólera
16960	Pretina de Cólera
16961	Espaldares de Cólera
16962	Quijotes de Cólera
16963	Yelmo de Cólera
16964	Guanteletes de Cólera
16965	Escarpes de Cólera
16966	Coraza de Cólera
16967	Ahi de Feralas
16968	Artillero Sar'theris
16969	Latipinia azul de La Costa Salvaje
16970	Mahi mahi Juncobruma
16971	Sorpresa de almejate
16972	Estandarte de Karang
16973	Vial de agua funesta
16974	Vial de agua vacío
16975	Fajín Grito de Guerra
16976	Tótem de Murgut
16977	Botas Grito de Guerra
16978	Guanteletes Grito de Guerra
16979	Guantes Bengala del Núcleo
16980	Manto Bengala del Núcleo
16981	Brazales de barba de búho
16982	Botas de can del Núcleo
16983	Yelmo de arrabio
16984	Botas de dragontina negra
16985	Botas del Hijo del Viento
16986	Guantes Cumbre de Arena
16987	Cinturón de estridador
16988	Sobrehombros de anillas ígneas
16989	Faja de anillas ígneas
16990	Capa de duendecillo
16991	Venda de selección
16992	Lanzaexplosivos de Smokey
16993	Pistola de fuego de Smokey
16994	Guantes Alaocaso
16995	Manto Alaocaso
16996	Arco de madera gore
16997	Habitante de Tempestira
16998	Protector sacro
16999	Sello real de Alexis
17000	Sortija de la Aparición
17001	Círculo elemental
17002	Escupeicor
17003	Martillo Calapetra
17004	Guía de Sara
17005	Guerrera de guardia grosero
17006	Musleras de cobalto
17007	Guanteletes de creapiedras
17008	Pergamino pequeño
17009	Cabeza del embajador Malcin
17010	Núcleo ígneo
17011	Núcleo de lava
17012	Cuero del Núcleo
17013	Leotardos Hierro Negro
17014	Brazales Hierro Negro
17015	Espetadora Hierro Negro
17016	Destructora Hierro Negro
17017	Patrón: manto Bengala del Núcleo
17018	Patrón: guantes Bengala del Núcleo
17019	Polvo Arcano
17020	Partículas Arcanas
17021	Frutos silvestres
17022	Patrón: botas de can del Núcleo
17023	Patrón: yelmo de arrabio
17024	Raíz salvaje
17025	Patrón: botas de dragontina negra
17026	Raíz de espina salvaje
17027	Vela con aroma
17028	Vela Sagrada
17029	Vela sacra
17030	Ankh
17031	Runa de teletransporte
17032	Runa de portales
17033	Símbolo de divinidad
17034	Semillas de arce
17035	Semilla Tuercespina
17036	Semilla de fresno
17037	Semillas de carpinus
17038	Semilla de maderaférrea
17039	Partecalaveras
17042	Escupeuñas
17043	Toga de zelote
17044	Voluntad del Mártir
17045	Sangre del Mártir
17046	Hoja de entrañas
17047	Amito luminiscente
17048	Ron Rumsey
17049	Diseño: faja de anillas ígneas
17050	Togas imperiales de Chan
17051	Diseño: brazales Hierro Negro
17052	Diseño: leotardos Hierro Negro
17053	Diseño: sobrehombros de anillas ígneas
17054	Piedad de Joonho
17055	Machacachanguk
17056	Pluma ligera
17057	Escamas de pez lustrosas
17058	Aceite de pescado
17059	Diseño: espetadora Hierro Negro
17060	Diseño: destructora Hierro Negro
17061	Sombra de Juno
17062	Receta: trucha cabeza de mitril
17063	Sortija de Accuria
17064	Fragmento de la Escama
17065	Medallón del poderío férreo
17066	Disco de horadador
17067	Grimorio Piedra angular antigua
17068	Libramorte
17069	Marca de asediador
17070	Colmillo de los Místicos
17071	Destripadora
17072	Lanzador tiroexplosión
17073	Sacudetierra
17074	Tenebrosa
17075	Vis'kag el Flebotomista
17076	Filo del espetahuesos
17077	Aplastador carmesí
17078	Mantón de Sapphiron
17082	Fragmento de la Llama
17102	Embozo de la niebla envolvente
17103	Hoja mágica de cantoazur
17104	Segadora espinal
17105	Martillo de piedra de aura
17106	Defensor de Malistar
17107	Manteo de sangre de dragón
17108	Marca de Desvío
17109	Gargantilla de Iluminación
17110	Sello del archimago
17111	Medallón Furia abrasadora
17112	Demoledor empíreo
17113	Guardián del Sello Ámbar
17114	Trozo de filacteria de Araj
17115	Muestra de ardilla
17116	Muestra de ardilla
17117	Flauta cazarratas
17118	Envase de carne misteriosa
17119	Kebab de rata del subterráneo
17124	Emblema de la Hermandad
17125	Sello de Ravenholdt
17126	Carta elegante
17142	Fragmento del Rapiñador
17182	Sulfuras, Mano de Ragnaros
17183	Rodela abollada
17184	Escudo pequeño
17185	Rodela redonda
17186	Tarja pequeña
17187	Rodela a rayas
17188	Rodela ensortijada
17189	Rodela de metal
17190	Rodela ornamentada
17191	Cetro de Celebras
17192	Tarja reforzada
17193	Martillo de Sulfuron
17194	Especias festivas
17195	Muérdago falso
17196	Licor de fiestas
17197	Galleta de jengibre
17198	Ponche de huevo
17199	Ponche de huevo estropeado
17200	Receta: galleta de jengibre
17201	Receta: ponche de huevo
17202	Bola de nieve
17203	Lingote de sulfuron
17204	Ojo de Sulfuras
17222	Salchicha de araña
17223	Tronadora
17224	Mira de visión
17242	Llave del cofre de Salem
17262	Llave de James
17302	Obsequio festivo con lazo azul
17303	Papel para envolver con lazo azul
17304	Papel para envolver con lazos verdes
17305	Obsequio festivo con lazo verde
17306	Sangre de Soldado Pico Tormenta
17307	Papel de envolver con lazos morados
17308	Obsequio festivo con lazo morado
17309	Brazales discordantes
17310	Aspecto de Neptulon
17322	Ojo del Brasadivino
17323	Señal de Mulverick
17324	Señal de Guse
17325	Señal de Jeztor
17326	Carne de Soldado Pico Tormenta
17327	Carne de Teniente Pico Tormenta
17328	Carne de Comandante Pico Tormenta
17329	Mano de Lucifron
17330	Mano de Sulfuron
17331	Mano de Gehennas
17332	Mano de Shazzrah
17333	Quintaesencia de agua
17344	Caña de caramelo
17345	Baba de silítido
17346	Objeto silítido taraceado
17347	Controlador de miembros de la Hermandad (MURP)
17348	Jarabe de sanación sublime
17349	Jarabe de sanación excelente
17351	Jarabe de maná sublime
17352	Jarabe de maná excelente
17353	Órdenes de asalto Pico Tormenta
17354	El ojo que todo lo ve del maestro Ryson
17355	Carta de Rabine
17362	Señal de Ryson
17363	Señal de Ryson
17364	Mira de visión
17384	Unidad trituradora portátil de Zinfizzlex
17402	Cerveza del Padre Invierno
17403	Licor burbujeante de Bonvapor
17404	Cuenco de chocolate caliente
17405	Té de jardín verde
17406	Rueda de queso de vacaciones
17407	Pastel de carne casero de Graccu
17408	Ternera picante
17409	Trozo de cristal taraceado
17410	Unidad trituradora portátil de Zinfizzlex
17411	Sierra de vapor
17413	Códice: Rezo de Entereza
17414	Códice: Rezo de entereza II
17422	Trocitos de armadura
17423	Cristal de tormenta
17442	Órdenes de asalto Lobo Gélido
17502	Medalla de Soldado Lobo Gélido
17503	Medalla de Teniente Lobo Gélido
17504	Medalla de Comandante Lobo Gélido
17505	Señal de Ichman
17506	Señal de Vipore
17507	Señal de Slidore
17508	Rodela piedra de fuerza
17522	Suministros de Ferrohondo
17523	Mantón de Smokey
17542	Suministros de Dentefrío
17562	Botas de tejido de tinieblas de Teniente caballero
17563	Brazales de tejido de tinieblas de Capitán caballero
17564	Guantes de tejido de tinieblas de Teniente caballero
17565	Cinturón de tejido de tinieblas de Capitán caballero
17566	Protegecabezas de Teniente coronel
17567	Leotardos de tejido de tinieblas de Capitán caballero
17568	Toga de tejido de tinieblas de Capitán caballero
17569	Manto de tejido de tinieblas de Teniente coronel
17570	Caperuza de tejido de tinieblas de Campeón
17571	Leotardos de tejido de tinieblas de Legionario
17572	Toga de tejido de tinieblas de Legionario
17573	Sobrehombros de tejido de tinieblas de Campeón
17574	Cinturón de tejido de tinieblas de Legionario
17575	Brazales de tejido de tinieblas de Legionario
17576	Botas de tejido de tinieblas de Guardia de sangre
17577	Guantes de tejido de tinieblas de Guardia de sangre
17578	Corona de Mariscal de campo
17579	Leotardos de tejido de tinieblas de Mariscal
17580	Sobrehombros de tejido de tinieblas de Mariscal de campo
17581	Toga de tejido de tinieblas de Mariscal de campo
17582	Puños de tejido de tinieblas de Mariscal
17583	Botas de tejido de tinieblas de Mariscal
17584	Guantes de tejido de tinieblas de Mariscal
17585	Fajín de tejido de tinieblas de Mariscal
17586	Botas de tejido de tinieblas de General
17587	Brazales de tejido de tinieblas de General
17588	Guantes de tejido de tinieblas de General
17589	Cinturón de tejido de tinieblas de General
17590	Manto de tejido de tinieblas de Señor de la Guerra
17591	Caperuza de tejido de tinieblas de Señor de la Guerra
17592	Toga de tejido de tinieblas de Señor de la Guerra
17593	Pantalones de tejido de tinieblas de General
17594	Botas de satén de Teniente caballero
17595	Puños de satén de Capitán caballero
17596	Guantes de satén de Teniente caballero
17597	Cordón de satén de Capitán caballero
17598	Diadema de Teniente coronel
17599	Leotardos de satén de Capitán caballero
17600	Togas de satén de Capitán caballero
17601	Amito de satén de Teniente coronel
17602	Ornato de Mariscal de campo
17603	Pantalones de satén de Mariscal
17604	Manto de satén de Mariscal de campo
17605	Vestimentas de satén de Mariscal de campo
17606	Brazales de satén de Mariscal
17607	Botas de satén de Mariscal
17608	Guantes de satén de Mariscal
17609	Fajín de satén de Mariscal
17610	Capucha de satén de Campeón
17611	Calzas de satén de Legionario
17612	Vestimentas de satén de Legionario
17613	Hombreras de satén de Campeón
17614	Fajín de satén de Legionario
17615	Puños de satén de Legionario
17616	Botas de satén de Guardia de sangre
17617	Guantes de satén de Guardia de sangre
17618	Botas de satén de General
17619	Brazales de satén de General
17620	Guantes de satén de General
17621	Cincho de satén de General
17622	Manto de satén de Señor de la Guerra
17623	Capucha de satén de Señor de la Guerra
17624	Togas de satén de Señor de la Guerra
17625	Leotardos de satén de General
17626	Bozal Lobo Gélido
17642	Pellejo de carnero de Alterac
17643	Pellejo Lobo Gélido
17662	Dulces robados
17682	Libro: Don de lo Salvaje
17683	Libro: Don de lo Salvaje II
17684	Tallas de cristal terádrico
17685	Muestra de Pastos de Bosquehumeante
17686	Arco de maestro cazador
17687	Rifle de maestro cazador
17688	Botas de la selva
17689	Collera de entrenamiento Pico Tormenta
17690	Insignia Lobo Gélido Rango 1
17691	Insignia Pico Tormenta Rango 1
17692	Anillo de cuerno
17693	Vial cerúleo cubierto
17694	Sortija del Puño
17695	Manto de castaño
17696	Vial cerúleo lleno
17702	Vara de Celebras
17703	Diamante de Celebras
17704	Filo del invierno
17705	Zumbaespada
17706	Diseño: Filo del invierno
17707	Fragmento de gemas
17708	Elixir de poder de Escarcha
17709	Receta: elixir de poder de Escarcha
17710	Puntilla de calcinita
17711	Leotardos de Crestarroca elemental
17712	Disfraz completo del Festival de Invierno
17713	Anillo de piedra negra
17714	Brazales de la Princesa de piedra
17715	Ojo de Theradras
17716	Señor de las nieves 9000
17717	Rifle megatiro
17718	Rodela hipertécnica de Gizlock
17719	Espada focal de inventor
17720	Esquema: Señor de las nieves 9000
17721	Guantes del Padre Invierno
17722	Patrón: guantes del Padre Invierno
17723	Camisa festiva verde
17724	Patrón: camisa festiva verde
17725	Fórmula: encantar arma: poderío del invierno
17726	Obsequio especial de Pastos de Bosquehumeante
17727	Caja con obsequio de Pastos de Bosquehumeante
17728	Botas de escama de cocodrilo albino
17730	Hacha Bocaimán
17731	Pergamino de Celebras
17732	Manto de Escamapodrida
17733	Puño de piedra
17734	Yelmo de la montaña
17735	El festín del Festival de Invierno
17736	Guanteletes de agarre de roca
17737	Piedra nube
17738	Garra de Celebras
17739	Mantón de guardia de la arboleda
17740	Ornato de veritas
17741	Abrazo de la Naturaleza
17742	Armadura de embozo fungal
17743	Vara de resurgimiento
17744	Corazón de Noxxion
17745	Lanzaponzoña
17746	Grilletes de Noxxion
17747	Raíz de latisable
17748	Botas de viña pútrida
17749	Bufas de fitopiel
17750	Faja de clororrejilla
17751	Leotardos de pelabrusels
17752	Látigo de sátiro
17753	Objetivo del vigilante verdeante
17754	Leotardos de timador infernal
17755	Fajín de crin de sátiro
17756	Trozo de fragmento oscuro
17757	Amuleto de los espíritus
17758	Amuleto de Unidad
17759	Marca de Resolución
17760	Semilla de vida
17761	Gema del primer Kahn
17762	Gema del segundo Kahn
17763	Gema del tercer Kahn
17764	Gema del cuarto Kahn
17765	Gema del quinto Kahn
17766	Cetro de la princesa Theradras
17767	Celada brotasangre
17768	Aro de Semillaleña
17769	Bufas de arbusto
17770	Guanteletes ramazarza
17771	Barra de elementium
17772	Colgante de fragmento oscuro entusiasta
17773	Colgante de fragmento de sombras prodigioso
17774	Marca del elegido
17775	Togas de sagacidad
17776	Yelmo de argollas de duende
17777	Cota de malla incansable
17778	Faja de arbusto
17779	Espaldares de mole de piedra
17780	Hoja de oscuridad eterna
17781	Las instrucciones del Paria
17782	Fragmento de dije de vínculo
17783	Trozo de dije de vínculo
17822	Mapas Lobo Gélido
17823	Planes de batalla Pico Tormenta
17849	Estandarte Pico Tormenta
17850	Estandarte Lobo Gélido
17900	Insignia Pico Tormenta Rango 2
17901	Insignia Pico Tormenta Rango 3
17902	Insignia Pico Tormenta Rango 4
17903	Insignia Pico Tormenta Rango 5
17904	Insignia Pico Tormenta Rango 6
17905	Insignia Lobo Gélido Rango 2
17906	Insignia Lobo Gélido Rango 3
17907	Insignia Lobo Gélido Rango 4
17908	Insignia Lobo Gélido Rango 5
17909	Insignia Lobo Gélido Rango 6
17922	Armadura de pellejo de león
17943	Puño de piedra
17962	Saco de gemas azules
17963	Saco de gemas verde
17964	Saco de gemas gris
17965	Saco de gemas amarillo
17966	Mochila de pellejo de Onyxia
17967	Escama de Onyxia refinada
17968	Escama de Onyxia cargada
17969	Saco de gemas rojo
17982	Núcleo de Ragnaros
18022	Sello real de Alexis
18023	Colgante de rubí de sangre
18042	Espada con punta de torio
18043	Botas de minero de carbón
18044	Pichel de Hurley
18045	Chuleta de lobo tierno
18046	Receta: chuleta de lobo tierno
18047	Botos de llamas
18048	Martillo de maestro forjador
18082	Vara de irritación de Zum'rah
18083	Mandiletes jumanza
18102	Botas de jinete de dragón
18103	Sortija de Reflexión
18104	Faja Ola feral
18142	Cabeza decapitada de elfo de la noche
18143	Mechón de pelo de gnomo
18144	Astilla de hueso humano
18145	Pezuña tauren
18146	Mojo de trol Lanza Negra
18147	Corazón de los Renegados
18148	Cráneo de Korrak
18149	Runa de regreso
18150	Runa de regreso
18151	Ampolla de amatista llena
18152	Ampolla de amatista
18153	Gema Moro'gan roja
18154	Papel y sobres para cartas de Blizzard
18155	Gema Moro'gan azul
18156	Gema moro'gan verde
18157	Gema Moro'gan negra
18158	Gema Moro'gan de oro
18159	Gema Moro'gan blanca
18160	Receta: té de cardo
18168	Disco reactivo a la fuerza
18169	Manto del Alba flamígero
18170	Manto del Alba de Escarcha
18171	Manto del Alba Arcano
18172	Manto del Alba de Naturaleza
18173	Manto del alba de las Sombras
18182	Manto del Alba cromático
18202	Garra izquierda de Eskhandar
18203	Garra derecha de Eskhandar
18204	Pelambre de Eskhandar
18205	Collar de Eskhandar
18206	Espinazo de enano
18207	Diente orco
18208	Mantón de Oración
18209	Bujía energizada
18222	Vid espinosa
18223	Pétalo dentado
18224	Raíz de azotador
18225	Zapatos de carrera desgastados
18226	Un pacto sellado
18227	Pacificador sin sustancia
18228	Foto autografiada de Tigule
18229	Guía de pesca extrema de Nat Pagle
18230	Botón G.A.N.O. roto
18231	Camiseta sin mangas
18232	Robot de reparación de campo 74A
18233	Pañuelo manchado de lágrimas
18234	Documento de Importaciones Bocarda
18235	Esquema: robot de reparación de campo 74A
18236	Muñeco masticado de Gordok
18237	Mandíbula de mastín
18238	Guantes sombradermos
18239	Patrón: guantes sombradermos
18240	Tanino de ogro
18241	Brida de corcel de guerra negro
18242	Riendas del tigre de guerra negro
18243	Zancudo de batalla negro
18244	Carnero de guerra negro
18245	Cuerno de lobo de guerra negro
18246	Silbato del raptor de guerra negro
18247	Kodo de guerra negro
18248	Caballo de guerra esquelético rojo
18249	Llave creciente
18250	Llave de los grilletes de Gordok
18251	Refuerzo para armadura del Núcleo
18252	Patrón: refuerzo para armadura del Núcleo
18253	Poción de rejuvenecimiento sublime
18254	Sorpresa de tubérculo runtún
18255	Tubérculo runtún
18256	Vial imbuido
18257	Receta: poción de rejuvenecimiento sublime
18258	Disfraz de ogro Gordok
18259	Fórmula: encantar arma: poder de hechizos
18260	Fórmula: encantar arma: poder de sanación
18261	Libro de Conjuros
18262	Piedra de afilar elemental
18263	Brazaletes Bengala del Núcleo
18264	Diseño: piedra de afilar elemental
18265	Patrón: brazaletes Bengala del Núcleo
18266	Llave de patio de Gordok
18267	Receta: sorpresa de tubérculo runtún
18268	Llave de puerta interior de Gordok
18269	Grog verde de Gordok
18282	Rifle de tirador del Núcleo
18283	Acurascopio 247x128 de Biznicks
18284	Cerveza negra de Kreeg
18285	Fragmento de maná cristalizado
18286	Trozo de maná condensado
18287	Siempreturbio
18288	Aguardiente de melaza
18289	Collar de espino con púas
18290	Esquema: Acurascopio 247x128 de Biznicks
18291	Esquema: disco reactivo de fuerza
18292	Esquema: rifle de tirador del Núcleo
18294	Elixir de respiración acuática superior
18295	Botas de fase
18296	Braciles de tirador
18297	Semilla de espinácula
18298	Leotardos irrefrenables
18299	Esencia de Hidromilecio
18300	Néctar de Hyjal
18301	Varita de Lethtendris
18302	Sortija de Vigor
18303	Rodela liviana
18304	Malla raíz verde
18305	Musleras arrecife
18306	Guantes de Niebla enigmática
18307	Botas de corriente
18308	Sombrero ingenioso
18309	Guantes de Restauración
18310	Machete endemoniado
18311	Vara de mediación Quel'dorei
18312	Peto energizado
18313	Yelmo de Conciencia
18314	Anillo de Astucia demoníaca
18315	Anillo de Potencia demoníaca
18316	Adorno de obsidiana
18317	Dije de tempestad
18318	Grebas clementes
18319	Yelmo ferviente
18320	Bufas de corazón de demonio
18321	Vara energética
18322	Botas del canalón
18323	Arco de sátiro
18324	Cortaolas
18325	Almete pellejo vil
18326	Guanteletes navaja
18327	Cordón de parral
18328	Capa Maderaoscura
18329	Arcanum de rapidez
18330	Arcanum de enfoque
18331	Arcanum de protección
18332	Tratado sobre rapidez
18333	Tratado sobre enfoque
18334	Tratado sobre protección
18335	Diamante negro prístino
18336	Guante del Poderío de Gordok
18337	Brazales órficos
18338	Varita de Potencia arcana
18339	Capa de Eidolon
18340	Dije de Eidolon
18341	Fajín Quel'dorei
18342	Guarda Quel'dorei
18343	Sortija petrificada
18344	Guanteletes cortezapiedra
18345	Anillo murmurante
18346	Calzas sin hilos
18347	Hacha bien equilibrada
18348	Quel'Serrar
18349	Guanteletes de Precisión
18350	Capa amplificadora
18351	Brazales sellados mágicamente
18352	Escudo de corteza petrificada
18353	Bastón de piedra floreada
18354	Collera de Pimgib
18355	Collera de Ferra
18356	Garona: Un Estudio sobre el Sigilo y la Traición
18357	Códice de Defensa
18358	El libro de cocina del arcanista
18359	La Luz y cómo alterarla
18360	Sombras acechadoras
18361	La mejor raza de cazadores
18362	Sagrada Bologna: lo que la Luz nunca te dirá
18363	El choque de Escarcha y tú
18364	El Sueño Esmeralda
18365	Una copia bien leída de "Pesca arriesgada con Nat Pagle".
18366	Manoplas de Gordok
18367	Guanteletes de Gordok
18368	Guantes de Gordok
18369	Manijas de Gordok
18370	Talismán de vigilancia
18371	Dije de lectura mental
18372	Hoja de la Luna nueva
18373	Peto de Tranquilidad
18374	Sobrehombros marcado por las llamas
18375	Brazales del Eclipse
18376	Maza gastada
18377	Guantes rápidos
18378	Leotardos Lunargenta
18379	Grebas odiosas
18380	Quijotes reforzados tétricos
18381	Colgante de ojo malvado
18382	Capa oscilante
18383	Guanteletes imbuidos de fuerza
18384	Bufas con grabados de bilis
18385	Toga de Noche perpetua
18386	Calzas de Padre
18387	Guantes Chispa brillante
18388	Machacapiedras
18389	Capa del Cosmos
18390	Leotardos Mohomaraña
18391	Cordón Acecha ojos
18392	Daga de distracción
18393	Brazal Alabeo
18394	Guardamuñecas de grito de demonio
18395	Anillo de llama esmeralda
18396	Tallador de mentes
18397	Colgante de mago anciano
18398	Aro de la marea
18399	Brisa del mar
18400	Anillo de Piedra viva
18401	Compendio de matar dragones de Nostro
18402	Anillo de cristal resplandeciente
18403	Sello de matadragones
18404	Colgante de diente de Onyxia
18405	Cinturón del archimago
18406	Dije de sangre de Onyxia
18407	Guantes de tela vil
18408	Guantes inferno
18409	Guantes de tela lunar
18410	Espada de esprínter
18411	Botas de soltura
18412	Trozo del Núcleo
18413	Capa de amparo
18414	Patrón: cinturón del archimago
18415	Patrón: guantes de tela vil
18416	Patrón: guantes inferno
18417	Patrón: guantes de tela lunar
18418	Patrón: capa de amparo
18420	Aplastahuesos
18421	Yelmo provinciano
18422	Cabeza de Onyxia
18423	Cabeza de Onyxia
18424	Botas de juncia
18425	Jarra de Kreeg
18426	Membrana de Lethtendris
18427	Capa de Sargento
18428	Insignia de Capataz primero
18429	Brazales de placas de Gran capataz
18430	Brazales de placas de Gran capataz
18432	Guardamuñecas de malla de Gran capataz
18434	Guardabrazos de pellejo de dragón de Gran capataz
18435	Guardabrazos de cuero de Gran capataz
18436	Guardabrazos de pellejo de dragón de Gran capataz
18437	Puños de seda de Gran capataz
18438	Marca de Sargento
18440	Manteo de Sargento
18441	Manteo de Sargento
18442	Insignia de Sargento primero
18443	Insignia de Sargento primero
18444	Insignia de Sargento primero
18445	Guardamuñecas de placas de Alférez
18447	Guardamuñecas de placas de Alférez
18448	Guardabrazos de anillas de Alférez
18449	Guardabrazos de anillas de Alférez
18450	Toga de Combustión
18451	Cinturón de pellejo de hiena
18452	Braquiales de cuero de Alférez
18453	Braquiales de cuero de Alférez
18454	Braquiales de pellejo de dragón de Alférez
18455	Braquiales de pellejo de dragón de Alférez
18456	Puños de seda de Alférez
18457	Puños de seda de Alférez
18458	Guardabrazos modestos
18459	Guardamuñecas de galante
18460	Culebrina poco sofisticada
18461	Capa de Sargento
18462	Puño de hueso dentado
18463	Cuchillo de bolsillo de ogro
18464	Pendiente para la nariz de Gordok
18465	Sello real de Eldre'Thalas
18466	Sello real de Eldre'Thalas
18467	Sello real de Eldre'Thalas
18468	Sello real de Eldre'Thalas
18469	Sello real de Eldre'Thalas
18470	Sello real de Eldre'Thalas
18471	Sello real de Eldre'Thalas
18472	Sello real de Eldre'Thalas
18473	Sello real de Eldre'Thalas
18475	Cinturón mágico curioso
18476	Botas manchadas de barro
18477	Leotardos peludos
18478	Chaleco de pellejo de hiena
18479	Yelmo de escórpido carroñero
18480	Yelmo de placas escarabajo
18481	Maza Aplastacalaveras
18482	Lanzamondadientes de ogro
18483	Varita de mediación de maná
18484	Hoja de Cho'Rush
18485	Escudo de observador
18486	Toga de tela lunar
18487	Patrón: toga de tela lunar
18488	Hoja antigua caliente
18489	Hoja antigua sin templar
18490	Caperuza de Perspicacia
18491	Hilador de conocimiento
18492	Espada antigua tratada
18493	Bufas de hierro grandes
18494	Sobrehombros de vigía de cubil
18495	Capa de reducto
18496	Capa de heliotropo
18497	Guardamuñecas sublimes
18498	Podadora
18499	Escudo barrera
18500	Anillo élfico deslustrado
18501	Fragmento de gangrevid
18502	Guja monstruosa
18503	Peto de Kromcrush
18504	Faja de perspicacia
18505	Cinturón de asaltante
18506	Botas de mangosta
18507	Botas de la Luna llena
18508	Brazales de Vuelo presto
18509	Capa cromática
18510	Capa de fiera
18511	Capa ondeante
18512	Ácido de larva
18513	Una hoja élfica desafilada
18514	Patrón: faja de perspicacia
18515	Patrón: botas de mangosta
18516	Patrón: brazales de Vuelo presto
18517	Patrón: capa cromática
18518	Patrón: capa de fiera
18519	Patrón: capa ondeante
18520	Hoja atroz
18521	Botas de metal mugrientas
18522	Sortija del Rey ogro
18523	Piedra con resplandor brillante
18524	Leotardos de Destrucción
18525	Brazales de Prosperidad
18526	Corona del Rey ogro
18527	Guanteletes armoniosos
18528	Bufas de ciclón
18529	Faja de placas elementales
18530	Camisote forjado de ogro
18531	Gran maza implacable
18532	Toga de oleada de mente
18533	Brazales de poder de Gordok
18534	Vara de los magi ogros
18535	Escudo de Milli
18536	Lexicón de Milli
18537	Magnetita de contraataque
18538	Aterrantárboles
18539	Relicario de Pureza
18540	Relicario de Pureza sellado
18541	Manteo enjundioso
18542	Tifón
18543	Anillo de Entropía
18544	Guanteletes de pellejo maldito
18545	Leotardos de Supremacía arcana
18546	Jaula de cabeza infernal
18547	Faja de hielo sin derretir
18562	Mena de elementium
18563	Ataduras del Hijo del Viento
18564	Ataduras del Hijo del Viento
18567	Flujo elemental
18582	Las hojas gemelas de Azzinoth
18583	Guja de guerra de Azzinoth (derecha)
18584	Guja de guerra de Azzinoth (izquierda)
18585	Sortija de Lealtad
18586	Círculo de Árbol Solitario
18587	Desfibriladores goblin XL
18588	Dinamita para tontos II
18590	Sangre de bestia enfurecida
18591	Caja de sangre
18592	Diseño: martillo de Sulfuron
18594	Carga de seforio potente
18595	Ópalo de sangre
18597	Silbato de huérfano orco
18598	Silbato de huérfano humano
18600	Escrito sobre Luminosidad Arcana
18601	Prisión de cristal resplandeciente
18602	Escrito sobre Sacrificio
18603	Sangre de sátiro
18604	Lágrimas de los Hederine
18605	Guardia apocalíptico encarcelado
18606	Confalón de batalla de la Alianza
18607	Confalón de batalla de la Horda
18608	Oración
18609	Anatema
18610	Machete cortante
18611	Leotardos Tuercepinos
18612	Botas de anillas sangrientas
18622	Esencia vil impecable (Jaedenar)
18623	Esencia vil impecable (Portal oscuro)
18624	Esencia vil impecable (Azshara)
18625	Núcleo infernal de Kroshius
18626	Fuego vil
18627	Gong de Dethmoora
18628	Contrato de la Hermandad del Torio
18629	Magnetita negra
18630	Llama del día del Juicio Final
18631	Transformador de veraplata
18632	Caramelo de los disturbios de Arroyo de la Luna
18633	Piruleta de Styleen
18634	Reflector de hielo girohielo
18635	Barrita de nueces de Bellara
18636	Desfibriladores XL estropeados
18637	Recombobulador sublime
18638	Reflector de llamas hiperradiante
18639	Reflector de las Sombras ultradeslumbrante
18640	Roca de diversión
18641	Dinamita densa
18642	Autógrafo de Jaina
18643	Marca de la pezuña de Cairne
18645	Roboalarma gnómico
18646	El Ojo de divinidad
18647	Esquema: fuegos artificiales rojos
18648	Esquema: fuegos artificiales verdes
18649	Esquema: fuegos artificiales azules
18650	Esquema: dinamita para tontos II
18651	Esquema: transformador de veraplata
18652	Esquema: reflector de hielo girohielo
18653	Esquema: desfibriladores goblin XL
18654	Esquema: roboalarma gnómico
18655	Esquema: recombobulador sublime
18656	Esquema: carga de seforio potente
18657	Esquema: reflector de llamas hiperradiante
18658	Esquema: reflector de las Sombras ultradeslumbrante
18659	Astilla de Nordrassil
18660	Amplificador de mundo
18661	Esquema: amplificador de mundo
18662	Bola de cuero pesado
18663	Tarro de J'eevee
18664	Un tratado sobre rangos militares
18665	El Ojo de la Sombra
18670	Glifos xorothianos
18671	Cetro del barón Charr
18672	Elemental de ascuas
18673	Pellejo pedregoso de Avalanchion
18674	Sortija de piedra endurecida
18675	Rangos militares de la Horda y la Alianza
18676	Fajín del Atracavientos
18677	Capa Céfiro
18678	Collar helado de Tempestria
18679	Anillo gélido
18680	Arco de hueso antiguo
18681	Chal de entierro
18682	Leotardos de piel de necrófago
18683	Martillo de la Víspera
18684	Anillo opalescente oscuro
18686	Sobrehombros de gólem de huesos
18687	Polvo estelar xorothiano
18688	Diablillo en un tarro
18689	Capa fantasmal
18690	Leotardos de placas de ánima
18691	Colgante de consejero oscuro
18692	Escarpes de caballero de la Muerte
18693	Manijas escalofrío
18694	Grebas de malla enigmáticas
18695	Escrito vinculado
18696	Escudo rúnico con un intrincado adorno
18697	Zapatillas de piedrafría
18698	Caperuza de cuero andrajoso
18699	Bufas de tumba heladas
18700	Brazales maléficos
18701	Sortija de estimulación
18702	Cinturón de la Ordenación
18703	Hoja petrificada vieja
18704	Tendón de dragón Azul maduro
18705	Tendón de dragón Negro maduro
18706	Maestro de arena
18707	Báculo con grabados de runas antiguas
18708	Corteza petrificada
18709	Guardamuñecas de arena
18710	Brazales de arena
18711	Braciles de arena
18712	Avambrazos de arena
18713	Rhok'delar, arco largo de los Guardianes ancianos
18714	Carcaj antiguo cosido con tendón
18715	Lok'delar, báculo de los Guardianes ancianos
18716	Botas cubiertas de ceniza
18717	Martillo del Gran Cruzado
18718	Yelmo del Gran Cruzado
18719	El corazón del traidor
18720	Embozo de Nathrezim
18721	Faja de bombardeo
18722	Mandiletes de la Muerte
18723	Collar de anillas animado
18724	Tendón de dragón Negro encantado
18725	Pacificador
18726	Puños de magistrado
18727	Sombrero de fieltro carmesí
18728	Reliquia de Anastari
18729	Arco chirrido
18730	Manijas con encaje enigmáticas
18731	Patrón: bola de cuero pesado
18734	Capa de luna pálida
18735	Borceguíes de Maleki
18736	Leotardos de can de peste
18737	Hachuela rebanadora de huesos
18738	Ballesta de caparazón espinoso
18739	Musleras de placas de quitina
18740	Fajín Thuzadin
18741	Brazal de Morlune
18742	Guardahombros de la milicia de Stratholme
18743	Manteo lujoso
18744	Guantes de pelaje de murcipeste
18745	Leotardos de paño sacro
18746	Cristal de adivinación
18747	Prueba de propiedades de objeto
18749	Alma perdida de cargador
18752	Incensario de exorcismo
18753	Gualdrapa de arcanita
18754	Brazales viles endurecidos
18755	Palo de fuego xorothiano
18756	Protector del Guardia del Terror
18757	Manto diabólico
18758	Espada de espectro
18759	Hacha maliciosa
18760	Sortija nigromántica
18761	Toque de olvido
18762	Fragmento de la Llama verde
18766	Riendas del sable de hielo presto
18767	Riendas del sable de la niebla presto
18768	Riendas del sable del alba presto
18769	Malla de placas de torio encantado
18770	Malla de placas de torio encantado
18771	Malla de placas de torio encantado
18772	Mecazancudo verde presto
18773	Mecazancudo blanco presto
18774	Mecazancudo amarillo presto
18775	Alimento para caballos enriquecido con maná
18776	Palomino presto
18777	Corcel marrón presto
18778	Corcel blanco presto
18779	Mitad inferior de Forja de armaduras avanzada: Volumen I
18780	Mitad superior de Forja de armaduras avanzada: Volumen I
18781	Mitad inferior de Forja de armaduras avanzada: Volumen II
18782	Mitad superior de Forja de armaduras avanzada: Volumen II
18783	Mitad inferior de Forja de armaduras avanzada: Volumen III
18784	Mitad superior de Forja de armaduras avanzada: Volumen III
18785	Carnero blanco presto
18786	Carnero marrón presto
18787	Carnero gris presto
18788	Raptor azul presto
18789	Raptor oliva presto
18790	Raptor naranja presto
18791	Caballo de guerra esquelético morado
18792	Gualdrapa de arcanita bendita
18793	Gran kodo blanco
18794	Gran kodo marrón
18795	Gran kodo gris
18796	Cuerno de lobo marrón presto
18797	Cuerno del lobo gris presto
18798	Cuerno del lobo grisáceo presto
18799	Alma redimida de cargador
18802	Poción enigmática
18803	Draga de lava hipertérmicamente aislada
18804	Cartera de Lord Grisillo
18805	Diente de can del Núcleo
18806	Grebas forjadas del Núcleo
18807	Yelmo de Poder latente
18808	Guantes de la Llama hipnótica
18809	Fajín de los Secretos susurrados
18810	Bufas de crecimiento salvaje
18811	Capa a prueba de fuego
18812	Guardamuñecas de Auténtico Vuelo
18813	Anillo de Vínculo
18814	Gargantilla del Señor del Fuego
18815	Esencia de la llama pura
18816	Hoja de Perdición
18817	Corona de Destrucción
18818	Instrucciones de Mor'zul
18819	Incensario de exorcismo de Rohan
18820	Dije de poder efímero
18821	Anillo de golpe rápido
18822	Hoja afilada de obsidiana
18823	Guantes viejos de cuero del Núcleo
18824	Botas templadas de magma
18825	Égida de Gran Mariscal
18826	Escudo muro de Gran Señor de la Guerra
18827	Hacha de mano de Gran mariscal
18828	Cuchilla de Gran Señor de la Guerra
18829	Bufas del interior de la tierra
18830	Taladora de Gran mariscal
18831	Hacha de batalla de Gran Señor de la Guerra
18832	Hoja de brutalidad
18833	Disparo certero de Gran mariscal
18834	Insignia de la Horda
18835	Arco corvo de Gran Señor de la Guerra
18836	Ballesta de repetición de Gran mariscal
18837	Ballesta de Gran Señor de la Guerra
18838	Puntilla de Gran mariscal
18839	Poción de sanación de combate
18840	Navaja de Gran Señor de la Guerra
18841	Poción de maná de combate
18842	Bastón de dominancia
18843	Hoja de mano derecha de Gran mariscal
18844	Garra derecha de Gran Señor de la Guerra
18845	Insignia de la Horda
18846	Insignia de la Horda
18847	Hoja de mano izquierda de Gran mariscal
18848	Garra izquierda de Gran Señor de la Guerra
18849	Insignia de la Horda
18850	Insignia de la Horda
18851	Insignia de la Horda
18852	Insignia de la Horda
18853	Insignia de la Horda
18854	Insignia de la Alianza
18855	Culebrina de Gran mariscal
18856	Insignia de la Alianza
18857	Insignia de la Alianza
18858	Insignia de la Alianza
18859	Insignia de la Alianza
18860	Barrecaminos de Gran Señor de la Guerra
18861	Quijotes de Despiertallamas
18862	Insignia de la Alianza
18863	Insignia de la Alianza
18864	Insignia de la Alianza
18865	Castigadora de Gran mariscal
18866	Cachiporra de Gran Señor de la Guerra
18867	Martillo de batalla de Gran mariscal
18868	Pulverizador de Gran Señor de la Guerra
18869	Guja de Gran mariscal
18870	Yelmo del Dador de vida
18871	Pica de jabalíes de Gran Señor de la Guerra
18872	Leotardos de tormenta de maná
18873	Báculo de Gran mariscal
18874	Bastón de guerra de Gran Señor de la Guerra
18875	Pantalones de escamas de salamandra
18876	Mandoble de Gran mariscal
18877	Espada magna de Gran Señor de la Guerra
18878	Daga de hechicero
18879	Anillo pesado de Hierro Negro
18880	Cabeza de Atracoscuro
18902	Riendas del sable de la tempestad presto
18904	Ultra-reductor de Zorbin
18922	Diseños secretos: flujo ígneo
18942	Flujo ígneo
18943	Almohada Hierro Negro
18944	Escama de incendosaurio
18945	Residuo de hierro negro
18946	Cabeza del sobrestante Maltorius
18947	Pellejo de yeti Cicatriz de Rabia
18948	Brazales barbáricos
18949	Patrón: brazales barbáricos
18950	Almohada de la ayudante de cámara Pilaprieta
18951	Pilar de aterrizaje de Evonice
18952	Cabeza de Simone
18953	Cabeza de Klinfran
18954	Cabeza de Solenor
18955	Cabeza de Artorius
18956	Residuo de miniaturización
18957	Hoja Leñomaleza
18958	Núcleo de elemental de agua
18959	Tobera de herrería
18960	Catalejo de oteador
18961	Caparazón Zukk'ash
18962	Glándulas de latigador con aguijón
18963	Huevo de tortuga (albino)
18964	Huevo de tortuga (leñobeza)
18965	Huevo de tortuga (alconil)
18966	Huevo de tortuga (cuerospalda)
18967	Huevo de tortuga (oliva)
18969	Pellejo de yeti prístino
18972	Pellejo de yeti perfecto
18984	Desgarrador dimensional: Vista Eterna
18986	Transportador ultraseguro: Gadgetzan
18987	Orden de Puño Negro
19002	Cabeza de Nefarian
19003	Cabeza de Nefarian
19004	Piedra de salud menor
19005	Piedra de salud menor
19006	Piedra de salud inferior
19007	Piedra de salud inferior
19008	Piedra de salud
19009	Piedra de salud
19010	Piedra de salud superior
19011	Piedra de salud superior
19012	Piedra de salud sublime
19013	Piedra de salud sublime
19016	Vasija de renacer
19017	Esencia del Señor del Fuego
19018	Hoja besada por el viento durmiente
19019	Trueno Furioso, espada bendita del Hijo del Viento
19020	Informe del campamento Mojache Zukk'ash
19022	Pescador extremo de Nat Pagle FC-5000
19023	Cebo más preciado de Katoom
19024	Gran maestro de arena
19025	Péndola de Señor del Cielo
19026	Fuegos artificiales serpenteantes
19027	Esquema: fuegos artificiales serpenteantes
19028	Vestido elegante
19029	Cuerno del aullador Lobo Gélido
19030	Carnero de batalla Pico Tormenta
19031	Tabardo de batalla Lobo Gélido
19032	Tabardo de batalla Pico Tormenta
19033	Herramientas perdidas de Esco
19034	Almuerzo de Lard
19035	Cesta de merienda especial de Lard
19036	Mensaje final a Martillo Salvaje
19037	Bufas de pico esmeralda
19038	Anillo de Sutileza
19039	Sombrero resistente al agua de Zorbin
19040	Megacercenadora de Zorbin
19041	Guerrera hecha a mano de Pratt
19042	Guerrera hecha a mano de Jangdor
19043	Cinturón Fauces de Madera pesado
19044	Poderío de los Fauces de Madera
19045	Confalón de batalla Pico Tormenta
19046	Confalón de batalla Lobo Gélido
19047	Sabiduría de los Fauces de Madera
19048	Botas Fauces de Madera pesadas
19049	Guantes de cuero Fauces de Madera
19050	Manto de los Fauces de Madera
19051	Faja del Alba
19052	Botines del Alba
19054	Red Dragon Orb
19055	Green Dragon Orb
19056	Botas Argenta
19057	Guantes del Alba
19058	Manto del Alba dorado
19059	Sobrehombros Argenta
19060	Ración enriquecida de la Garganta Grito de Guerra
19061	Ración de hierro de la Garganta Grito de Guerra
19062	Ración de campo de la Garganta Grito de Guerra
19064	Llave de grillete
19065	Círculo Esmeralda
19066	Venda de paño rúnico de la Garganta Grito de Guerra
19067	Venda de tejido mágico de la Garganta Grito de Guerra
19068	Venda de seda de la Garganta Grito de Guerra
19069	Calavera del cazador Malkhor
19070	Huesos del cazador Malkhor
19071	Vasija de sangre corrupta
19083	Capa de Legionario Lobo Gélido
19084	Capa de Soldado Pico Tormenta
19085	Capa de consejero Lobo Gélido
19086	Capa de sabio Pico Tormenta
19087	Cinturón de placas Lobo Gélido
19088	Cinturón de malla Lobo Gélido
19089	Cinturón de cuero Lobo Gélido
19090	Cinturón de paño Lobo Gélido
19091	Faja de placas Pico Tormenta
19092	Faja de malla Pico Tormenta
19093	Faja de cuero Pico Tormenta
19094	Faja de paño Pico Tormenta
19095	Colgante de Legionario Lobo Gélido
19096	Colgante de consejero Lobo Gélido
19097	Colgante de Soldado Pico Tormenta
19098	Colgante de sabio Pico Tormenta
19099	Hoja glacial
19100	Daga electrificada
19101	Bastón de tormenta de nieve
19102	Bastón resonante
19103	Mordisquielo
19104	Martillo Golpe de tormenta
19105	Ornato de runas de escarcha
19106	Lanza con púas de hielo
19107	Buscasangre
19108	Varita de Frío cortante
19109	Anillo raíces profundas
19110	Hoja forjada en frío
19111	Cubrehombros de Hacha Invernal
19112	Avambrazos de acero congelados
19113	Brazales de pellejo de yeti
19114	Arco de tierra alta
19115	Frasco de mojo del bosque
19116	Manijas hojaverde
19117	Quijotes de placas de madera lacadas
19118	Aliento de la Naturaleza
19119	Guantes de pellejo de lechubestia
19120	Runa del capitán de la guardia
19121	Capa del bosque profundo
19123	Manijas siempre cálidas
19124	Leotardos de placas de escoria
19125	Faja de malla chamuscada
19126	Guanteletes de placas de escoria
19127	Guerrera de cuero carbonizada
19128	Jubón de malla chamuscado
19129	Toga Resplandor eterno
19130	Mordedura de frío
19131	Botas Cieganieve
19132	Corona adornada con cristales
19133	Leotardos vil imbuidos
19134	Cinturón de piel de guardia apocalíptico
19135	Brazal de luz negra
19136	Cordón de ignición de maná
19137	Faja de acometida
19138	Sortija de Sulfuras
19139	Sobrehombros de guardia de fuego
19140	Sortija de cauterización
19141	Lufa
19142	Grimorio rúnico de Fuego
19143	Guanteletes de guardia de llamas
19144	Escarpes del Caminante sobre llamas
19145	Toga de poder volátil
19146	Guardamuñecas de Estabilidad
19147	Anillo de poder con hechizos
19148	Yelmo Hierro Negro
19149	Cinturón de lava
19150	Botiquín básico de centinela
19151	Botiquín normal de centinela
19152	Botiquín avanzado de centinela
19153	Botiquín avanzado de escolta
19154	Botiquín básico de escolta
19155	Botiquín normal de escolta
19156	Toga Bengala del Núcleo
19157	Guanteletes cromáticos
19159	Collar de hiedra trenzada
19160	Tabardo de ganador de concurso
19162	Cinturón de can del Núcleo
19163	Cinturón de arrabio
19164	Guanteletes Hierro Negro
19165	Leotardos Bengala del Núcleo
19166	Amnistía negra
19167	Furianegra
19168	Guardanegra
19169	Ocaso
19170	Mano de ébano
19182	Vale de la Feria de la Luna Negra
19183	Arena de reloj de arena
19202	Diseño: cinturón Fauces de Madera pesado
19203	Diseño: faja del Alba
19204	Diseño: botas Fauces de Madera pesadas
19205	Diseño: guantes del Alba
19206	Diseño: yelmo Hierro Negro
19207	Diseño: guanteletes Hierro Negro
19208	Diseño: Amnistía negra
19209	Diseño: Furianegra
19210	Diseño: Mano de ébano
19211	Diseño: Guardanegra
19212	Diseño: Ocaso
19213	Dije de mérito Ala de Plata
19215	Patrón: sabiduría de los Fauces de Madera
19216	Patrón: botas Argenta
19217	Patrón: sobrehombros Argenta
19218	Patrón: manto de los Fauces de Madera
19219	Patrón: toga Bengala del Núcleo
19220	Patrón: leotardos Bengala del Núcleo
19221	Gran reserva de la Luna Negra
19222	Cerveza barata
19223	Perrito de la Luna Negra
19224	Alitas súper picantes
19225	Chocolatina frita
19227	As de Bestias
19228	Baraja de Bestias
19229	Fortuna de Sayge n.º 1
19230	Dos de Bestias
19231	Tres de Bestias
19232	Cuatro de Bestias
19233	Cinco de Bestias
19234	Seis de Bestias
19235	Siete de Bestias
19236	Ocho de Bestias
19237	Fortuna de Sayge n.º 19
19238	Fortuna de Sayge n.º 3
19239	Fortuna de Sayge n.º 4
19240	Fortuna de Sayge n.º 5
19241	Fortuna de Sayge n.º 6
19242	Fortuna de Sayge n.º 7
19243	Fortuna de Sayge n.º 8
19244	Fortuna de Sayge n.º 9
19245	Fortuna de Sayge n.º 10
19246	Fortuna de Sayge n.º 11
19247	Fortuna de Sayge n.º 12
19248	Fortuna de Sayge n.º 13
19249	Fortuna de Sayge n.º 14
19250	Fortuna de Sayge n.º 15
19251	Fortuna de Sayge n.º 16
19252	Fortuna de Sayge n.º 18
19253	Fortuna de Sayge n.º 17
19254	Fortuna de Sayge n.º 21
19255	Fortuna de Sayge n.º 22
19256	Fortuna de Sayge n.º 2
19257	Baraja de Señores de la Guerra
19258	As de Señores de la Guerra
19259	Dos de Señores de la Guerra
19260	Tres de Señores de la Guerra
19261	Cuatro de Señores de la Guerra
19262	Cinco de Señores de la Guerra
19263	Seis de Señores de la Guerra
19264	Siete de Señores de la Guerra
19265	Ocho de Señores de la Guerra
19266	Fortuna de Sayge n.º 20
19267	Baraja de Elementales
19268	As de Elementales
19269	Dos de Elementales
19270	Tres de Elementales
19271	Cuatro de Elementales
19272	Cinco de Elementales
19273	Seis de Elementales
19274	Siete de Elementales
19275	Ocho de Elementales
19276	As de Portales
19277	Baraja de Portales
19278	Dos de Portales
19279	Tres de Portales
19280	Cuatro de Portales
19281	Cinco de Portales
19282	Seis de Portales
19283	Siete de Portales
19284	Ocho de Portales
19287	Naipe de la Luna Negra: Heroísmo
19288	Naipe de la Luna Negra: Dragón Azul
19289	Naipe de la Luna Negra: La Vorágine
19290	Naipe de la Luna Negra: El Vacío Abisal
19291	Caja de almacenamiento de la Luna Negra
19292	Añojo del mes pasado
19293	Añojo del año pasado
19295	Flor de la Luna Negra
19296	Lote superior de la Luna Negra
19297	Lote inferior de la Luna Negra
19298	Lote menor de la Luna Negra
19299	Bebida de feria con burbujas
19300	Agua de Cuna del Invierno embotellada
19301	Galleta de maná de Alterac
19302	Anillo de la Luna Negra
19303	Collar de la Luna Negra
19304	Cecina de ternera picante
19305	Pie de kodo en vinagre
19306	Rana crujiente
19307	Venda de paño rúnico gruesa de Alterac
19308	Escrito sobre Dominación Arcana
19309	Escrito sobre Fuerza de las Sombras
19310	Escrito del Señor del Hielo
19311	Escrito sobre Arcana ígnea
19312	Leu del Vivificador
19315	Toque de Therazane
19316	Flecha con hielo
19317	Bala con hielo
19318	Agua de manantial de Alterac embotellada
19319	Carcaj de pellejo de arpía
19320	Bandolera de piel de gnoll
19321	El objeto inamovible
19322	Marca de Honor Grito de Guerra
19323	La fuerza imparable
19324	El Lobotomizador
19325	Sortija de Don Julio
19326	Patrón: poderío de los Fauces de Madera
19327	Patrón: guantes de cuero Fauces de Madera
19328	Patrón: botines del Alba
19329	Patrón: manto del Alba dorado
19330	Patrón: cinturón de lava
19331	Patrón: guanteletes cromáticos
19332	Patrón: cinturón de can del Núcleo
19333	Patrón: cinturón de arrabio
19334	La espada indomable
19335	Machacapúas
19336	Gema Arcana imbuida
19337	El libro negro
19338	Vale de entrada gratuita
19339	Gema de Estímulo mental
19340	Runa de metamorfosis
19341	Gema dadora de vida
19342	Tótem venenoso
19343	Pergaminos de Luz cegadora
19344	Cristal de alineación natural
19345	Égida de preservación
19346	Hoja colmillo dragón
19347	Garra de Chromaggus
19348	Protector de dragontina roja
19349	Baluarte reforzado de elementium
19350	Apuntacorazones
19351	Maladath, Hoja rúnica del Vuelo Negro
19352	Espada templada cromáticamente
19353	Cuchilla de garfa de draco
19354	Vengador dracónico
19355	Bastón de enfoque de Alasombra
19356	Bastón de la Llama de las Sombras
19357	Heraldo de tragedia
19358	Gran maza dracónica
19360	Lok'amir il Romathis
19361	Ashjre'thul, Ballesta de paliza
19362	Filo de la Fatalidad
19363	Crul'shorukh, Filo del Caos
19364	Ashkandi, Espada magna de la Hermandad
19365	Garra del draco negro
19366	Orbe de maestro matadragones
19367	Toque de dragón
19368	Culebrina aliento de dragón
19369	Guantes de Evolución rápida
19370	Manto del Conciliábulo Alanegra
19371	Colgante del Dragón Caído
19372	Yelmo de ira infinita
19373	Espaldares de linaje negro
19374	Brazales de Precisión arcana
19375	Mish'undare, Aro del Despelleja Almas
19376	Anillo de juicio de Archimtiros
19377	Dije de connivencia de Prestor
19378	Capa del Señor del linaje
19379	Lágrima de Neltharion
19380	Eslabón de Therazane
19381	Botas de la Llama de las Sombras
19382	Sortija de elementium puro
19383	Medallón de maestro matadragones
19384	Anillo de maestro matadragones
19385	Leotardos potenciados
19386	Capa tejida con elementium
19387	Botas cromáticas
19388	Garra de Angelista
19389	Hombreras de pellejo de dragón tirante
19390	Guantes de pellejo de dragón tirante
19391	Geta fulgurante
19392	Faja del cruzado caído
19393	Guardarrenes enlazados de primalista
19394	Espaldares de garfa de draco
19395	Gema rejuvenecedora
19396	Cinturón de pellejo de dragón tirante
19397	Anillo de Roca Negra
19398	Capa de Faucefogo
19399	Toga de ceniza negra
19400	Agarre de Faucefogo
19401	Musleras enlazadas de primalista
19402	Musleras del cruzado caído
19403	Sortija de Concentración forzada
19405	Baluarte bendito de Malfurion
19406	Dije de colmillo de draco
19407	Guantes de llamas de ébano
19422	Fortuna de la Feria de la Luna Negra
19423	Fortuna de Sayge n.º 23
19424	Fortuna de Sayge n.º 24
19425	Arcón misterioso
19426	Orbe de la Luna Negra
19430	Embozo de pensamiento puro
19431	Escarabajo trabador de Styleen
19432	Círculo de fuerza aplicada
19433	Leotardos de tejido de ascuas
19434	Sortija del Dominio oscuro
19435	Recolector de esencia
19436	Capa de Poderío dracónico
19437	Botas de pensamiento puro
19438	Botas de Ventisca de Ringo
19439	Chaleco de las Sombras entrelazado
19440	Contraveneno potente
19441	Glándula de veneno enorme
19442	Fórmula: contraveneno potente
19443	Fortuna de Sayge n.º 25
19444	Fórmula: encantar arma: fuerza
19445	Fórmula: encantar arma: agilidad
19446	Fórmula: encantar brazales: regeneración de maná
19447	Fórmula: encantar brazal: sanación
19448	Fórmula: encantar arma: espíritu poderoso
19449	Fórmula: encantar arma: intelecto poderoso
19450	Una casita de Jubling
19451	Fortuna de Sayge n.º 26
19452	Fortuna de Sayge n.º 27
19453	Fortuna de Sayge n.º 28
19454	Fortuna de Sayge n.º 29
19462	Huevo sin abrir de Jubling
19482	Pelambre de conejo L'Artesano
19483	Pelar la cebolla
19484	La alcachofa Lobo Gélido
19491	Amuleto de la Luna Negra
19505	Tabardo de batalla Grito de Guerra
19506	Tabardo de batalla Ala de Plata
19507	Chal de inquisidor
19508	Brazales de cuero marcado
19509	Botas de malla polvorientas
19510	Sortija de Legionario
19511	Sortija de Legionario
19512	Sortija de Legionario
19513	Sortija de Legionario
19514	Sortija de protector
19515	Sortija de protector
19516	Sortija de protector
19517	Sortija de protector
19518	Anillo de consejero
19519	Anillo de consejero
19520	Anillo de consejero
19521	Anillo de consejero
19522	Anillo del Tradicionalista
19523	Anillo del Tradicionalista
19524	Anillo del Tradicionalista
19525	Anillo del Tradicionalista
19526	Capa de curador de batalla
19527	Capa de curador de batalla
19528	Capa de curador de batalla
19529	Capa de curador de batalla
19530	Manteo de custodio
19531	Manteo de custodio
19532	Manteo de custodio
19533	Manteo de custodio
19534	Medallón de explorador
19535	Medallón de explorador
19536	Medallón de explorador
19537	Medallón de explorador
19538	Medallón de centinela
19539	Medallón de centinela
19540	Medallón de centinela
19541	Medallón de centinela
19542	Hoja de explorador
19543	Hoja de explorador
19544	Hoja de explorador
19545	Hoja de explorador
19546	Hoja de centinela
19547	Hoja de centinela
19548	Hoja de centinela
19549	Hoja de centinela
19550	Espada de Legionario
19551	Espada de Legionario
19552	Espada de Legionario
19553	Espada de Legionario
19554	Espada de protector
19555	Espada de protector
19556	Espada de protector
19557	Espada de protector
19558	Arco de escolta
19559	Arco de escolta
19560	Arco de escolta
19561	Arco de escolta
19562	Arco de avanzado
19563	Arco de avanzado
19564	Arco de avanzado
19565	Arco de avanzado
19566	Bastón nudoso de consejero
19567	Bastón nudoso de consejero
19568	Bastón nudoso de consejero
19569	Bastón nudoso de consejero
19570	Bastón del Tradicionalista
19571	Bastón del Tradicionalista
19572	Bastón del Tradicionalista
19573	Bastón del Tradicionalista
19574	Fuerza de Mugamba
19575	Fuerza de Mugamba
19576	Fuerza de Mugamba
19577	Ira de Mugamba
19578	Brazales de rabioso
19579	Enseña de pagano
19580	Brazales de rabioso
19581	Brazales de rabioso
19582	Guardamuñecas de soplaviento
19583	Guardamuñecas de soplaviento
19584	Guardamuñecas de soplaviento
19585	Enseña de pagano
19586	Enseña de pagano
19587	Brazales de acechador del bosque
19588	Enseña de héroe
19589	Brazales de acechador del bosque
19590	Brazales de acechador del bosque
19591	El Ojo de Zuldazar
19592	El Ojo de Zuldazar
19593	El Ojo de Zuldazar
19594	El Ojo que todo lo ve de Zuldazar
19595	Ataduras de muñeca de la Dríade
19596	Ataduras de muñeca de la Dríade
19597	Ataduras de muñeca de la Dríade
19598	Guijarro de Kajaro
19599	Guijarro de Kajaro
19600	Guijarro de Kajaro
19601	Joya de Kajaro
19602	Mancha de Kezan
19603	Mancha de Kezan
19604	Mancha de Kezan
19605	Mancha imparable de Kezan
19606	Visión de Voodress
19607	Visión de Voodress
19608	Visión de Voodress
19609	Visión inmaculada de Voodress
19610	Alga de los Mares del Sur encantada
19611	Alga de los Mares del Sur encantada
19612	Alga de los Mares del Sur encantada
19613	Alga de los Mares del Sur encantada prístina
19614	Dije Zandalar de las Sombras
19615	Dije Zandalar de las Sombras
19616	Dije Zandalar de las Sombras
19617	Dije Zandalar de maestría de las Sombras
19618	Zarcillo de La Vorágine
19619	Zarcillo de La Vorágine
19620	Zarcillo de La Vorágine
19621	Cólera de La Vorágine
19642	iCoke Prize Voucher
19682	Jubón vid de sangre
19683	Leotardos vid de sangre
19684	Botas vid de sangre
19685	Chaleco de piel de murciélago primigenio
19686	Guantes de piel de murciélago primigenio
19687	Brazales de piel de murciélago primigenio
19688	Coraza de tigre de sangre
19689	Sobrehombros de tigre de sangre
19690	Coraza de alma de sangre
19691	Sobrehombros de alma de sangre
19692	Guanteletes de alma de sangre
19693	Coraza almanegra
19694	Leotardos almanegra
19695	Sobrehombros almanegra
19696	Pan de la cosecha
19697	Recompensa de la cosecha
19698	Moneda Zulian
19699	Moneda Razzashi
19700	Moneda Hakkari
19701	Moneda Gurubashi
19702	Moneda Vilrama
19703	Moneda Secacorteza
19704	Moneda Furiarena
19705	Moneda Machacacráneos
19706	Moneda Sangrapellejo
19707	Presea Hakkari roja
19708	Presea Hakkari azul
19709	Presea Hakkari amarilla
19710	Presea Hakkari naranja
19711	Presea Hakkari verde
19712	Presea Hakkari morada
19713	Presea Hakkari de bronce
19714	Presea Hakkari de plata
19715	Presea Hakkari de oro
19716	Ataduras Hakkari primigenias
19717	Cabestrillo Hakkari primigenio
19718	Puntal Hakkari primigenio
19719	Faja Hakkari primigenia
19720	Fajín Hakkari primigenio
19721	Chal Hakkari primigenio
19722	Tabardo Hakkari primigenio
19723	Casaca Hakkari primigenia
19724	Égida Hakkari primigenia
19725	Cajón de recursos de Arathi
19726	Vid de sangre
19727	Guadaña de sangre
19764	Patrón: jubón vid de sangre
19765	Patrón: leotardos vid de sangre
19766	Patrón: botas vid de sangre
19767	Cuero de murciélago primigenio
19768	Cuero de tigre primigenio
19769	Patrón: chaleco de piel de murciélago primigenio
19770	Patrón: guantes de piel de murciélago primigenio
19771	Patrón: brazales de piel de murciélago primigenio
19772	Patrón: coraza de tigre de sangre
19773	Patrón: sobrehombros de tigre de sangre
19774	Almarita
19775	Bolsa azur sellada
19776	Diseño: coraza de alma de sangre
19777	Diseño: sobrehombros de alma de sangre
19778	Diseño: guanteletes de alma de sangre
19779	Diseño: coraza almanegra
19780	Diseño: leotardos almanegra
19781	Diseño: sobrehombros almanegra
19782	Presencia de poderío
19783	Sigilo de Sincretista
19784	Abrazo de la Muerte
19785	Llamada del falcón
19786	Abrazo del vigilante de Vodouisant
19787	Presencia de Vista
19788	Maleficio hudú
19789	Aura profética
19790	Caricia del animista
19802	Corazón de Hakkar
19803	Corredor a rayas azules de Brownell
19804	Pez demonio pálido
19805	Pez ángel de Keefer
19806	Pez reina de Dezian
19807	Pezrico moteado
19808	Potenpez Pielroca
19812	Runa del Alba
19813	Muñeco de vudú agujereado
19814	Muñeco de vudú agujereado
19815	Muñeco de vudú agujereado
19816	Muñeco de vudú agujereado
19817	Muñeco de vudú agujereado
19818	Muñeco de vudú agujereado
19819	Muñeco de vudú agujereado
19820	Muñeco de vudú agujereado
19821	Muñeco de vudú agujereado
19822	Coraza de vindicador Zandalar
19823	Cinturón de vindicador Zandalar
19824	Guardabrazos de vindicador Zandalar
19825	Coraza de librepensador Zandalar
19826	Cinturón de librepensador Zandalar
19827	Guardabrazos de librepensador Zandalar
19828	Camisote de augur Zandalar
19829	Cinturón de augur Zandalar
19830	Brazales de augur Zandalar
19831	Manto de depredador Zandalar
19832	Cinturón de depredador Zandalar
19833	Brazales de depredador Zandalar
19834	Guerrera de sinconcierto Zandalar
19835	Manto de sinconcierto Zandalar
19836	Brazales de sinconcierto Zandalar
19838	Guerrera de haruspex Zandalar
19839	Cinturón de haruspex Zandalar
19840	Brazales de haruspex Zandalar
19841	Manto de confesor Zandalar
19842	Ataduras de confesor Zandalar
19843	Brazaletes de confesor Zandalar
19845	Manto de ilusionista Zandalar
19846	Brazaletes de ilusionista Zandalar
19848	Brazaletes de endemoniado Zandalar
19849	Manto de endemoniado Zandalar
19850	Tributo a Uther
19851	Tributo a Grom
19852	Destripahombres Hakkari antiguo
19853	Destructora de enanos Gurubashi
19854	Zin'rokh, Destructora de Mundos
19855	Quijotes empapados de sangre
19856	El Ojo de Hakkar
19857	Capa de Consumo
19858	Muestra de honor Zandalar
19859	Colmillo del ignoto
19861	Toque del Caos
19862	Égida del Dios de la Sangre
19863	Sello de primalista
19864	Llamasangre
19865	Hoja de guerra de los Hakkari
19866	Hoja de guerra de los Hakkari
19867	Defensor del Señor de la Sangre
19869	Mandiletes empapados de sangre
19870	Capa loa Hakkari
19871	Dije de protección
19872	Raptor Razzashi presto
19873	Sortija carmesí de Señor Supremo
19874	Alabarda de golpeo
19875	Almófar manchado de sangre
19876	Collar de corruptor de alma
19877	Leotardos de animista
19878	Espaldares empapados de sangre
19880	Colección de cabezas Gurubashi
19881	Cabeza de canalizador
19882	La cabeza de aojador
19883	Cordón sacro
19884	Sentencia de Jin'do
19885	Ojo maligno de Jin'do
19886	El casquete de aojador
19887	Quijotes manchados de sangre
19888	Abrazo de Señor Supremo
19889	Leotardos empapados de sangre
19890	Brujo de Jin'do
19891	Bolsa de mal agüero de Jin'do
19892	Botas de animista
19893	Sello de Zanzil
19894	Guanteletes empapados de sangre
19895	Falda tintada de sangre
19896	Agarre de Thekal
19897	Botas de traidor
19898	Sello de Jin
19899	Musleras de ritual
19900	Hacha de piedra Zulian
19901	Cercenadora Zulian
19902	Tigre Zulian presto
19903	Colmillo de Venoxis
19904	Camisote rúnico manchado de sangre
19905	Sortija de Zanzil
19906	Escarpines empapados de sangre
19907	Capa de pellejo de tigre Zulian
19908	Cetro de Acometida
19909	Voluntad de Arlokk
19910	Agarre de Arlokk
19911	Corazón de hierbal
19912	Sortija de ónice de Señor Supremo
19913	Grebas empapadas de sangre
19914	Saco de pellejo de pantera
19915	Defensor Zulian
19918	Triturador de Jeklik
19919	Grebas manchadas de sangre
19920	Sortija de primalista
19921	Rebanadora Zulian
19922	Palo hudú de Arlokk
19923	Dije ópalo de Jeklik
19925	Sortija de Jin
19927	Toque de Mar'li
19928	Bufas de animista
19929	Guantes tintados de sangre
19930	Ojo de Mar'li
19931	Locura de mojo Gurubashi
19933	Sangre de escórpido resplandeciente
19934	Garra de escórpido grande
19935	Glándula de veneno vacía
19936	Caparazón de escórpido seco
19937	Garra de escórpido pequeña
19938	Pata de escórpido pesada
19939	Sangre de Gri'lek
19940	Diente de Renataki
19941	Melena de Wushoolay
19942	Hilo de sueño de Hazza'rah
19943	Mojo macizo
19944	Ejecutor de peces de Nat Pagle
19945	Parche para ojo de escamas de lagarto
19946	Arpón de Tigule
19947	Carrete roto de Nat Pagle
19948	Distintivo de héroe Zandalar
19949	Medallón de héroe Zandalar
19950	Talismán de héroe Zandalar
19951	Talismán de poderío de Gri'lek
19952	Talismán de valor de Gri'lek
19953	Talismán de bestias de Renataki
19954	Talismán de artimañas de Renataki
19955	Talismán de naturaleza de Wushoolay
19956	Talismán de espíritus de Wushoolay
19957	Talismán de destrucción de Hazza'rah
19958	Talismán de sanación de Hazza'rah
19959	Talismán de magia de Hazza'rah
19960	Miel cristalizada
19961	Molinillo de Gri'lek
19962	Punzón de Gri'lek
19963	Horquilla de Locura
19964	Conducto de alma de Renataki
19965	Atizador de Wushoolay
19967	Entorpecedor
19968	Castigador ígneo
19969	Botas de pescador extremo de Nat Pagle
19970	Caña de pescar de arcanita
19971	Sedal de eternio de alta calidad
19972	Sombrero de pesca de la suerte
19973	Cinta métrica de Nat
19974	Cebo de Fangoapestoso
19975	Fangoapestoso Zulian
19978	¡Torneo de pesca!
19979	Anzuelo de Maestro pescador
19982	Mantón de Murciumbrío
19984	Máscara de ébano
19986	Parche de pirata
19989	Escrito sobre Sombras devoradoras
19990	Cuentas de rezo benditas
19991	Ojo de demosaurio
19992	Diente de demosaurio
19993	Arco de caza hudú
19994	Fruta de la cosecha
19995	Jabalí de la cosecha
19996	Pez de la cosecha
19997	Néctar de la cosecha
19998	Lente vid de sangre
19999	Gafas vid de sangre
20000	Esquema: gafas vid de sangre
20001	Esquema: lente vid de sangre
20002	Poción de letargo sin sueños superior
20003	Garras de demosaurio
20004	Poción de sangre de trol sublime
20005	Garras de demosaurio
20006	Círculo de Esperanza
20007	Poción de sangre de mago
20008	Poción de acción viva
20009	¡Por la Luz!
20010	El Grito Infernal de la Horda
20011	Receta: Poción de sangre de mago
20012	Receta: Letargo sin sueños superior
20013	Receta: poción de acción viva
20014	Receta: Poción de sangre de trol sublime
20015	Plumas de raptor viejo
20016	Calavera trofeo de raptor
20017	Cornamenta perfecta de trotador
20018	Pellejo de pardo Zarpira
20019	Diente de Morphaz
20020	Fardo de bienes
20021	Pendiente pirata de oro
20022	Llave azur
20023	Trozo codificado
20024	Conducto de bilis putrefacto
20025	Sangre de Morphaz
20026	Carne en descomposición
20027	Glándula de trotador sano
20028	Polvo relumbrante
20029	Coral encantado
20030	Roca mascota
20031	Mango de esencia
20032	Togas de ritual sueltas
20033	Toga de endemoniado Zandalar
20034	Toga de ilusionista Zandalar
20035	Punta glacial
20036	Rubí de fuego
20037	Colgante de cristal Arcano
20038	Aguijón de Mandokir
20039	Botas Hierro Negro
20040	Diseño: botas Hierro Negro
20041	Faja de placas de montañés
20042	Faja de láminas de montañés
20043	Faja de anillas de montañés
20044	Faja de malla de montañés
20045	Faja de cuero de montañés
20046	Faja de pellejo de lagarto de montañés
20047	Faja de paño de montañés
20048	Grebas de placas de montañés
20049	Grebas de láminas de montañés
20050	Grebas de anillas de montañés
20051	Grebas de malla de montañés
20052	Botas de cuero de montañés
20053	Botas de pellejo de lagarto de montañés
20054	Botas de paño de montañés
20055	Espaldares de anillas de montañés
20056	Espaldares de malla de montañés
20057	Bufas de placas de montañés
20058	Bufas de láminas de montañés
20059	Sobrehombros de cuero de montañés
20060	Sobrehombros de pellejo de lagarto de montañés
20061	Cubrehombros de montañés
20062	Ración enriquecida de la Cuenca de Arathi
20063	Ración de campo de la Cuenca de Arathi
20064	Ración de hierro de la Cuenca de Arathi
20065	Venda de tejido mágico de la Cuenca de Arathi
20066	Venda de paño rúnico de la Cuenca de Arathi
20067	Venda de seda de la Cuenca de Arathi
20068	Capa de guardia de la Muerte
20069	Bastón Cortezaférrea
20070	Garra sabia
20071	Dije de Arathor
20072	Dije de Rapiñador
20073	Capa de guardia de honor
20074	Estofado de crocolisco pesado
20075	Receta: estofado de crocolisco pesado
20076	Sello Zandalar de mojo
20077	Sello Zandalar de poderío
20078	Sello Zandalar de serenidad
20079	Espíritu de Zanza
20080	Brillo de Zanza
20081	Presteza de Zanza
20082	Báculo de aflicción
20083	Lanza de caza
20084	Red de caza
20085	Fragmento arcano
20086	Cuchillo arrojadizo de acero crepuscular
20087	Escamas de descarnador marino
20088	Faja de anillas de montañés
20089	Faja de anillas de montañés
20090	Faja de anillas de montañés
20091	Grebas de anillas de montañés
20092	Grebas de anillas de montañés
20093	Grebas de anillas de montañés
20094	Botas de paño de montañés
20095	Botas de paño de montañés
20096	Botas de paño de montañés
20097	Faja de paño de montañés
20098	Faja de paño de montañés
20099	Faja de paño de montañés
20100	Botas de pellejo de lagarto de montañés
20101	Botas de pellejo de lagarto de montañés
20102	Botas de pellejo de lagarto de montañés
20103	Faja de pellejo de lagarto de montañés
20104	Faja de pellejo de lagarto de montañés
20105	Faja de pellejo de lagarto de montañés
20106	Faja de láminas de montañés
20107	Faja de láminas de montañés
20108	Faja de láminas de montañés
20109	Grebas de láminas de montañés
20110	Grebas de láminas de montañés
20111	Grebas de láminas de montañés
20112	Botas de cuero de montañés
20113	Botas de cuero de montañés
20114	Botas de cuero de montañés
20115	Faja de cuero de montañés
20116	Faja de cuero de montañés
20117	Faja de cuero de montañés
20118	Faja de malla de montañés
20119	Faja de malla de montañés
20120	Faja de malla de montañés
20121	Grebas de malla de montañés
20122	Grebas de malla de montañés
20123	Grebas de malla de montañés
20124	Faja de placas de montañés
20125	Faja de placas de montañés
20126	Faja de placas de montañés
20127	Grebas de placas de montañés
20128	Grebas de placas de montañés
20129	Grebas de placas de montañés
20130	Frasco de diamante
20131	Tabardo de batalla de los Rapiñadores
20132	Tabardo de batalla de Arathor
20134	Yelmo furia del cielo
20150	Faja de anillas de Rapiñador
20151	Faja de anillas de Rapiñador
20152	Faja de anillas de Rapiñador
20153	Faja de anillas de Rapiñador
20154	Grebas de anillas de Rapiñador
20155	Grebas de anillas de Rapiñador
20156	Grebas de anillas de Rapiñador
20157	Grebas de anillas de Rapiñador
20158	Espaldares de anillas de Rapiñador
20159	Botas de paño de Rapiñador
20160	Botas de paño de Rapiñador
20161	Botas de paño de Rapiñador
20162	Botas de paño de Rapiñador
20163	Faja de paño de Rapiñador
20164	Faja de paño de Rapiñador
20165	Faja de paño de Rapiñador
20166	Faja de paño de Rapiñador
20167	Botas de pellejo de lagarto de Rapiñador
20168	Botas de pellejo de lagarto de Rapiñador
20169	Botas de pellejo de lagarto de Rapiñador
20170	Botas de pellejo de lagarto de Rapiñador
20171	Faja de pellejo de lagarto de Rapiñador
20172	Faja de pellejo de lagarto de Rapiñador
20173	Faja de pellejo de lagarto de Rapiñador
20174	Faja de pellejo de lagarto de Rapiñador
20175	Sobrehombros de pellejo de lagarto de Rapiñador
20176	Cubrehombros de Rapiñador
20177	Faja de láminas de Rapiñador
20178	Faja de láminas de Rapiñador
20179	Faja de láminas de Rapiñador
20180	Faja de láminas de Rapiñador
20181	Grebas de láminas de Rapiñador
20182	Grebas de láminas de Rapiñador
20183	Grebas de láminas de Rapiñador
20184	Bufas de láminas de Rapiñador
20185	Grebas de láminas de Rapiñador
20186	Botas de cuero de Rapiñador
20187	Botas de cuero de Rapiñador
20188	Botas de cuero de Rapiñador
20189	Botas de cuero de Rapiñador
20190	Faja de cuero de Rapiñador
20191	Faja de cuero de Rapiñador
20192	Faja de cuero de Rapiñador
20193	Faja de cuero de Rapiñador
20194	Sobrehombros de cuero de Rapiñador
20195	Faja de malla de Rapiñador
20196	Faja de malla de Rapiñador
20197	Faja de malla de Rapiñador
20198	Faja de malla de Rapiñador
20199	Grebas de malla de Rapiñador
20200	Grebas de malla de Rapiñador
20201	Grebas de malla de Rapiñador
20202	Grebas de malla de Rapiñador
20203	Espaldares de malla de Rapiñador
20204	Faja de placas de Rapiñador
20205	Faja de placas de Rapiñador
20206	Faja de placas de Rapiñador
20207	Faja de placas de Rapiñador
20208	Grebas de placas de Rapiñador
20209	Grebas de placas de Rapiñador
20210	Grebas de placas de Rapiñador
20211	Grebas de placas de Rapiñador
20212	Bufas de placas de Rapiñador
20213	Cinturón de Cabezas encogidas
20214	Colmillo mental
20215	Cinturón de Cabezas secas
20216	Cinturón de Cabezas conservadas
20217	Cinturón de cabezas diminutas
20218	Capa Hakkari descolorida
20219	Manteo Hakkari andrajoso
20220	Bastón Cortezaférrea
20221	Corcel fabuloso
20222	Ración enriquecida de Rapiñador
20223	Ración de campo de Rapiñador
20224	Ración de hierro de Rapiñador
20225	Ración enriquecida de montañés
20226	Ración de campo de montañés
20227	Ración de hierro de montañés
20228	Botiquín avanzado de Rapiñador
20229	Botiquín básico de Rapiñador
20230	Botiquín normal de Rapiñador
20231	Botiquín avanzado de Arathor
20232	Venda de tejido mágico de Rapiñador
20233	Botiquín básico de Arathor
20234	Venda de paño rúnico de Rapiñador
20235	Venda de seda de Rapiñador
20236	Botiquín normal de Arathor
20237	Venda de tejido mágico de montañés
20243	Venda de paño rúnico de montañés
20244	Venda de seda de montañés
20253	Patrón: arnés de oso de guerra
20254	Patrón: prendas de lana de oso de guerra
20255	Botas Caminasusurro
20256	Lazo de Sacrificio de la Garganta Grito de Guerra
20257	Guanteletes de furia marina
20258	Bastón Ceremonial Zulian
20259	Guantes de pellejo de pantera de las Sombras
20260	Leotardos de furia marina
20261	Cinturón de pellejo de pantera de las Sombras
20262	Botas de furia marina
20263	Yelmo Gurubashi
20264	Guanteletes de pacificador
20265	Botas de pacificador
20266	Leotardos de pacificador
20295	Leotardos de dragontina azul
20296	Guanteletes de dragontina verde
20310	Piel de demonio despellejada
20337	Cabeza de gnomo en un palo
20367	Equipo de caza
20368	Arco anodino de Serenidad
20369	Puños azurita
20371	Huevo múrloc azul
20373	Aguijón de escórpido Latipiedra
20374	Aguijón de tenazario Latipiedra
20375	Aguijón de despellejador Latipiedra
20376	Colmillo de arácnido de arena
20377	Colmillo de acecharrocas
20378	Fragmentos de tablilla Crepuscular
20379	Cartera de Noggle
20380	Coraza de escamas oníricas
20381	Escama onírica
20382	Patrón: coraza de escamas oníricas
20383	Cabeza del Señor de linaje Capazote
20384	Trozo de caparazón de silítido
20385	Pinza de Pinzamorten
20387	Traca de bombas fétidas de Renegados
20388	Chupachús
20389	Trigo de caramelo
20390	Chocolatina
20391	Máscara de gnomo endeble
20392	Máscara de gnoma endeble
20393	Bolsa de premios
20394	Lexicón Crepuscular: Capítulo 1
20395	Lexicón Crepuscular: Capítulo 2
20396	Lexicón Crepuscular: Capítulo 3
20397	Varita sacralizada: Pirata
20398	Varita sacralizada: Ninja
20399	Varita sacralizada: Gnomo paria
20400	Bolsa de calabazas
20401	Tablilla Crepuscular restaurada
20402	Agente de Nozdormu
20403	Poder de Nozdormu
20404	Texto Crepuscular codificado
20405	Trascripción de tablilla decodificada
20406	Manto de cultor Crepuscular
20407	Toga de cultor Crepuscular
20408	Capucha de cultor Crepuscular
20409	Varita sacralizada: Fantasma
20410	Varita sacralizada: Murciélago
20411	Varita sacralizada: Esqueleto
20413	Varita sacralizada: Aleatorio
20414	Varita sacralizada: Fuego fatuo
20415	La guerra del Mar de Dunas
20416	Blasón de señalización: fuego
20418	Blasón de señalización: trueno
20419	Blasón de señalización: piedra
20420	Blasón de señalización: agua
20422	Medallón de estatus de cultor Crepuscular
20423	Garra de escórpido arenoso
20424	Carne de gusano de arena
20425	Bastón nudoso de consejero
20426	Anillo de consejero
20427	Capa de curador de batalla
20428	Manteo de custodio
20429	Sortija de Legionario
20430	Espada de Legionario
20431	Anillo del Tradicionalista
20432	Sello de señalización: fuego
20433	Sello de señalización: trueno
20434	Bastón del Tradicionalista
20435	Sello de señalización: piedra
20436	Sello de señalización: agua
20437	Arco de escolta
20438	Arco de avanzado
20439	Sortija de protector
20440	Espada de protector
20441	Hoja de explorador
20442	Medallón de explorador
20443	Hoja de centinela
20444	Medallón de centinela
20447	Cetro de señalización: fuego
20448	Cetro de señalización: trueno
20449	Cetro de señalización: piedra
20450	Cetro de señalización: agua
20451	Anillo de nobleza de cultor Crepuscular
20452	Albóndigas del desierto ahumadas
20453	Estuche de trascripción de geólogo
20454	Calco de Colmen'Zora
20455	Calco de Colmen'Ashi
20456	Calco de Colmen'Regal
20457	Cerebro silítido de Colmen'Ashi
20458	Cerebro silítido de Colmen'Zora
20459	Cerebro silítido de Colmen'Regal
20460	Carta perdida de Brann Barbabronce
20461	Carta perdida de Brann Barbabronce
20462	Medallón de Halloween
20463	Prisma de cristal con inscripciones
20464	Glifos de Llamamiento
20465	Mecanismo de liberación de cristal
20466	Sello de Vyral
20467	Página de receta rota
20469	Recortes de El creyente verdadero descifrados
20475	Gema de alma
20476	Brazales acecharenas
20477	Guanteletes acecharenas
20478	Coraza acecharenas
20479	Coraza escupefuego
20480	Guanteletes escupefuego
20481	Brazales escupefuego
20485	Sello del duque
20487	Lok'delar, báculo de los Guardianes ancianos DEP
20488	Rhok'delar, arco de los Guardianes ancianos DEP
20489	Corona del Consejo
20490	Menta de Forjaz
20491	Menta de Entrañas
20492	Turrón de Ventormenta
20493	Almendrados de Orgrimmar
20494	Gominola de Gnomeregan
20495	Gominola Lanza Negra
20496	Mazapán de Darnassus
20497	Mazapanes de Cima del Trueno
20498	Quitina de silítido
20499	Quitina de escórpido rota
20500	Caparazón de silítido ligero
20501	Caparazón de silítido pesado
20502	Escudo Cortezaférrea
20503	Espíritu de agua enamorado
20504	Hoja forjada con luz
20505	Sello caballeresco
20506	Patrón: brazales escupefuego
20507	Patrón: guanteletes escupefuego
20508	Patrón: coraza escupefuego
20509	Patrón: brazales acecharenas
20510	Patrón: guanteletes acecharenas
20511	Patrón: coraza acecharenas
20512	Orbe santificado
20513	Blasón abisal
20514	Sello abisal
20515	Cetro abisal
20516	Manzana de Halloween
20517	Sobrehombros Acero afilado
20518	Pergamino: crear blasón de señalización
20519	Sombrero de pirata de los Mares del Sur
20520	Runa oscura
20521	Visor de furia
20522	Bastón feral
20524	Leotardos Pielsombra
20525	Sigilo terráneo
20526	Pergamino: crear blasón de señalización
20527	Pergamino: crear blasón de señalización
20528	Pergamino: crear blasón de señalización
20530	Togas de Servidumbre
20531	Pergamino: crear sello de señalización
20532	Pergamino: crear sello de señalización
20533	Pergamino: crear sello de señalización
20534	Fragmento Abisal
20535	Pergamino: crear sello de señalización
20536	Cosechador de almas
20537	Botas rúnicas estigias
20538	Leotardos rúnicos estigios
20539	Cinturón rúnico estigio
20540	Pergamino: crear cetro de señalización
20541	Texto descifrado Crepuscular
20542	Pergamino: crear cetro de señalización
20543	Pergamino: crear cetro de señalización
20544	Pergamino: crear cetro de señalización
20545	Texto descifrado Crepuscular
20546	Patrón: leotardos rúnicos estigios
20547	Patrón: botas rúnicas estigias
20548	Patrón: cinturón rúnico estigio
20549	Guanteletes runaoscura
20550	Coraza runaoscura
20551	Yelmo runaoscura
20552	Texto descifrado Crepuscular
20553	Diseño: guanteletes runaoscura
20554	Diseño: coraza runaoscura
20555	Diseño: yelmo runaoscura
20556	Bastón salvaje
20557	Golosinas de calabaza de Halloween
20558	Marca de Honor de la Garganta Grito de Guerra
20559	Marca de Honor de la Cuenca de Arathi
20560	Marca de Honor del Valle de Alterac
20561	Máscara de enano endeble
20562	Máscara de enana endeble
20563	Máscara de elfa de la noche endeble
20564	Máscara de elfo de la noche endeble
20565	Máscara de humana endeble
20566	Máscara de humano endeble
20567	Máscara de trol hembra endeble
20568	Máscara de trol macho endeble
20569	Máscara de orco hembra endeble
20570	Máscara de orco endeble
20571	Máscara de tauren hembra endeble
20572	Máscara de tauren macho endeble
20573	Máscara de no-muerto endeble
20574	Máscara de no-muerta endeble
20575	Guerrera de cría negra
20576	Patrón: guerrera de cría negra
20577	Hoja pesadilla
20578	Colmillo dragón esmeralda
20579	Capa de piel de dragón Verde
20580	Martillo de Furia bestial
20581	Bastón de Crecimiento desenfrenado
20582	Piedra de trance
20583	Máscara de enana robusta
20584	Máscara de gnomo hembra robusta
20585	Máscara de mujer robusta
20586	Máscara de elfa de la noche robusta
20587	Máscara de orco hembra robusta
20588	Máscara de tauren hembra robusta
20589	Máscara de trol hembra robusta
20590	Máscara de no-muerta robusta
20591	Máscara de enano robusta
20592	Máscara de gnomo robusta
20593	Máscara de hombre robusta
20594	Máscara de elfo de la noche robusta
20595	Máscara de orco robusta
20596	Máscara de tauren robusta
20597	Máscara de trol robusta
20598	Máscara de no-muerto robusta
20599	Ballesta de maderaférrea pulida
20600	Sello de Malfurion
20601	Saco de botín
20602	Cofre de residuos
20603	Bolsa de botín
20604	Limpiador de bomba fétida
20605	Huevos podridos
20606	Pluma vudú ámbar
20607	Pluma vudú azul
20608	Pluma vudú verde
20609	Plumas vudú
20610	Ojo de araña tirosangre
20611	Garra negra gruesa
20612	Piedra de la Plaga inerte
20613	Madera putrefacta
20614	Esencia de veneno de sangre
20615	Brazaletes de espuelas de dragón
20616	Guardamuñecas de hueso de dragón
20617	Antiguos leotardos corroídos
20618	Guantes de Poder ilusorio
20619	Grebas con inscripciones de ácido
20620	Piedra de poderío sagrada
20621	Botas de la Llanura eterna
20622	Collar de corazón de dragón
20623	Aro de Sueños Inquietos
20624	Anillo del Inerte
20625	Cinturón de la Ciénaga oscura
20626	Braciles de corteza negra
20627	Pantalones de corazón oscuro
20628	Almete Crecimiento descarriado
20629	Guardapiés malignos
20630	Guanteletes de la Luz brillante
20631	Zapatillas de mendigo
20632	Sortija de lágrima mental
20633	Bufas de cuero artificial
20634	Botas de miedo
20635	Vestimentas decoradas con jade
20636	Cristal de hibernación
20637	Espaldares con inscripciones de ácido
20638	Leotardos de la Mente demente
20639	Quijotes con extrañas inscripciones
20640	Cubo de cabezas de los Mares del Sur
20641	Botas de mojo de los Mares del Sur
20642	Guerrera de noble anticuada
20643	Gorro de reservista de Entrañas
20644	Objeto envuelto en pesadillas
20645	Susurro de la Naturaleza
20646	Marca de Correarenas
20647	Daga de cristal negro
20648	Martillo forjado en frío
20649	Colgante prisma de sol
20650	Guanteletes del viento del desierto
20651	Huevo múrloc naranja
20652	Zapatillas de paño abisal
20653	Guanteletes de placas abisales
20654	Bastón de guerra amatista
20655	Manijas de paño abisal
20656	Escarpes de malla abisal
20657	Estilete con punta de cristal
20658	Botas de cuero abisal
20659	Manoplas de malla abisal
20660	Guja Cortapiedras
20661	Guantes de cuero abisal
20662	Grebas de placas abisales
20663	Arco tiro profundo
20664	Fajín de paño abisal
20665	Leotardos de cuero abisal
20666	Martillo de guerra de acero endurecido
20667	Cinturón de cuero abisal
20668	Musleras de malla abisal
20669	Mandoble Rocanegra
20670	Agarre de malla abisal
20671	Quijotes de placas abisales
20672	Varita de cristal chispeante
20673	Faja de placas abisales
20674	Pantalones de paño abisal
20675	Creador de almas
20676	Texto descifrado Crepuscular
20677	Texto descifrado Crepuscular
20678	Texto descifrado Crepuscular
20679	Texto descifrado Crepuscular
20680	Espaldares de malla abisal
20681	Brazales de cuero abisal
20682	Sortija de enfoque elemental
20683	Cubrehombros de placas abisales
20684	Guardabrazos de cuero abisal
20685	Collar rompeolas
20686	Amito de paño abisal
20687	Avambrazos de placas abisales
20688	Guarda terránea
20689	Sobrehombros de cuero abisal
20690	Braciles de paño abisal
20691	Manteo Cortaviento
20692	Sortija multicolor
20693	Capa pesada
20694	Orbe negro resplandeciente
20695	Cuentas de guerra abisales
20696	Gran maza de cristal con pinchos
20697	Manteo tejido cristalino
20698	Hoja elemental armonizada
20699	Quijotes de reservista Cenarion
20700	Quijotes de reservista Cenarion
20701	Musleras de reservista Cenarion
20702	Musleras de reservista Cenarion
20703	Leotardos de reservista Cenarion
20704	Leotardos de reservista Cenarion
20705	Pantalones de reservista Cenarion
20706	Pantalones de reservista Cenarion
20707	Pantalones de reservista Cenarion
20708	Valija bien sellada
20709	Ron Rumsey blanco
20710	Grebas taraceadas con cristal
20711	Grebas con líneas de cristal
20712	Guanteletes de transitayermos
20713	Guanteletes de Acechadesiertos
20714	Botas Tormenta de Arena
20715	Botas de Acechadunas
20716	Guantes de piel de gusano de arena
20717	Guantes flor del desierto
20720	Hoja susurro oscuro
20721	Sortija del cultor
20722	Lanzababosa de cristal
20723	Pico de confianza de Brann
20724	Bastón del Bosque Negro corrupto
20725	Cristal nexo
20726	Fórmula: encantar guantes: amenaza
20727	Fórmula: encantar guantes: Poder de las Sombras
20728	Fórmula: encantar guantes: Poder de Escarcha
20729	Fórmula: encantar guantes: Poder de Fuego
20730	Fórmula: encantar guantes: poder de sanación
20731	Fórmula: encantar guantes: agilidad excelente
20732	Fórmula: encantar capa: Resistencia al Fuego superior
20733	Fórmula: encantar capa: resistencia a la Naturaleza superior
20734	Fórmula: encantar capa: sigilo
20735	Fórmula: encantar capa: sutileza
20736	Fórmula: encantar capa: esquivar
20737	Piedra nuclearia chamuscada
20741	Tótem de ritual Muertobosque
20742	Tótem de ritual Nevada
20744	Aceite de zahorí menor
20745	Aceite de maná menor
20746	Aceite de zahorí inferior
20747	Aceite de maná inferior
20748	Aceite de maná luminoso
20749	Aceite de zahorí luminoso
20750	Aceite de zahorí
20752	Fórmula: aceite de maná menor
20753	Fórmula: aceite de zahorí inferior
20754	Fórmula: aceite de maná inferior
20755	Fórmula: aceite de zahorí
20756	Fórmula: aceite de zahorí luminoso
20757	Fórmula: aceite de maná luminoso
20758	Fórmula: aceite de zahorí menor
20761	Receta: transmutar fuego elemental
20763	Arma rota
20766	Bolsa babosa
20767	Bolsa cubierta de suciedad
20768	Bolsa de mocos
20769	Moquillo desagradable
20770	Icor verde burbujeante
20800	Distintivo de logística Cenarion
20801	Distintivo de táctica Cenarion
20802	Distintivo de combate Cenarion
20803	Órdenes de batalla Crepusculares
20805	Seguimiento del encargo de logística
20806	Informe de tareas logísticas X
20807	Informe de tareas logísticas I
20808	Encargo de combate
20809	Encargo de táctica
20810	Documentación de instrucción de campo firmada
20814	Daga arrojadiza del maestro
20834	Catalejo XT ornamentado
20844	Veneno mortal V
20858	Escarabajo de piedra
20859	Escarabajo de oro
20860	Escarabajo de plata
20861	Escarabajo de bronce
20862	Escarabajo de cristal
20863	Escarabajo de terracota
20864	Escarabajo de hueso
20865	Escarabajo de marfil
20866	Ídolo azur
20867	Ídolo de ónice
20868	Ídolo luminiscente
20869	Ídolo de ámbar
20870	Ídolo de jaspe
20871	Ídolo de obsidiana
20872	Ídolo bermellón
20873	Ídolo de alabastro
20874	Ídolo del Sol
20875	Ídolo de la Noche
20876	Ídolo de Muerte
20877	Ídolo del sabio
20878	Ídolo de Renacer
20879	Ídolo de la Vida
20881	Ídolo de la Disputa
20882	Ídolo de la guerra
20883	Joya qiraji con inscripciones
20884	Anillo qiraji magistral
20885	Mantón qiraji marcial
20886	Puño con pinchos qiraji
20887	Joya qiraji grabada
20888	Anillo ceremonial qiraji
20889	Mantón qiraji regio
20890	Empuñadura qiraji ornamentada
20908	Fuegos artificiales del Festival de Nian
20926	Aro de Vek'nilash
20927	Pellejo intacto de Ouro
20928	Ataduras de mando qiraji
20929	Caparazón del dios antiguo
20930	Diadema de Vek'lor
20931	Piel del Gran gusano de arena
20932	Ataduras de dominancia qiraji
20933	Coraza del dios antiguo
20936	Joya qiraji bendita
20937	Joya qiraji encerrada
20939	Informe de tareas logísticas II
20940	Informe de tareas logísticas III
20941	Informe de tareas de combate XII
20942	Informe de tareas de combate III
20943	Instrucciones de la misión táctica X
20944	Instrucciones de la misión táctica IX
20945	Instrucciones de la misión táctica II
20946	Instrucciones de la misión táctica III
20947	Instrucciones de la misión táctica IV
20948	Instrucciones de la misión táctica V
20949	Libro de contabilidad mágico
20951	Gafas de visión de Narain
21023	Fabulosas chuletillas de quimerok de Dirge
21024	Solomillo de quimerok
21025	Receta: fabulosas chuletillas de quimerok de Dirge
21027	Cadáver de Lakmaeran
21028	Pollo de 500 kilos
21029	Carta de rescate
21030	Tarta de kimchi de Darnassus
21031	Kimchi de repollo
21032	Carta de amor de Meridith
21033	Rábano kimchi
21037	Mapa rudimentario
21038	Bola de nieve prieta
21039	Turbante de Narain
21040	Toga de Narain
21041	Bolsa de oro
21042	Equipo especial de Narain
21043	Sobre misterioso
21071	Sabiola cruda
21072	Sabiola ahumada
21099	Receta: sabiola ahumada
21100	Moneda de linaje
21103	Dracónico para torpes
21104	Dracónico para torpes
21105	Dracónico para torpes
21106	Dracónico para torpes
21107	Dracónico para torpes
21108	Dracónico para torpes
21109	Dracónico para torpes
21110	Dracónico para torpes
21111	Dracónico para torpes: volumen II
21112	Encuadernación de libro mágico
21113	Valija hermética
21114	Ron Rumsey dorado
21115	Dije de Rapiñador
21116	Dije de Rapiñador
21117	Dije de Arathor
21118	Dije de Arathor
21119	Dije de Arathor
21120	Dije de Rapiñador
21126	Aguijón de la Muerte
21128	Bastón de los Profetas qiraji
21130	Diario de Weavil
21131	Seguimiento del encargo de combate
21132	Encargo de logística
21133	Seguimiento del encargo táctico
21134	Filo oscuro de la locura
21135	Hacha arrojadiza de asesino
21136	Boya de arcanita
21137	Fragmento de cetro azul
21138	Fragmento de cetro rojo
21139	Fragmento de cetro verde
21140	Papel y sobres para cartas de subasta
21141	Fragmento de cetro rojo destruido
21142	De la mesa de Lord Victor Nefarius
21143	Documentación de instrucción de campo sin firmar
21144	Antorcha para invocar demonios
21145	Esencia de Xandivious
21146	Fragmento de Corrupción de Pesadilla
21147	Fragmento de Corrupción de Pesadilla
21148	Fragmento de Corrupción de Pesadilla
21149	Fragmento de Corrupción de Pesadilla
21150	Valija reforzada con hierro
21151	Ron Rumsey etiqueta negra
21152	La corrupción de Pesadilla
21153	Sabiola cruda superior
21154	Vestido de fiesta
21155	Ofrenda de paz de los Fauces de Madera
21156	Bolsa escarabajo
21157	Vestido de fiesta verde
21158	Informe de exploración de Colmen'Zora
21159	Órdenes de Explorador de Colmen'Zora
21160	Informe de exploración de Colmen'Regal
21161	Informe de exploración de Colmen'Ashi
21162	Bocanegra graso hinchado
21163	Pargo de fuego hinchado
21164	Bacalao piedrescama hinchado
21165	Instrucciones de la misión táctica VI
21166	Instrucciones de la misión táctica VII
21167	Instrucciones de la misión táctica VIII
21168	Cría de tiburón
21171	Jarra festiva llena
21173	Jarra festiva vacía
21174	Jarra festiva vacía
21175	El cetro del Mar de Dunas
21176	Cristal resonador negro qiraji
21177	Símbolo de Reyes
21178	Guantes de Poder de la tierra
21179	Sortija de Cólera de tierra
21180	Golpe de tierra
21181	Gracia de la Tierra
21182	Sortija de poder terráneo
21183	Jubón Poder terrenal
21184	Brazales de roca profunda
21185	Orbe Calmaterra
21186	Brazales de Furia de roca
21187	Capa de tejido de tierra
21188	Puño de Cenarius
21189	Poderío de Cenarius
21190	Cólera de Cenarius
21191	Presente envuelto con cuidado
21193	Saco de El'saco
21194	Saco grande de El'saco
21195	Sactástico de El'saco
21196	Sello del Vuelo Bronce
21197	Sello del Vuelo Bronce
21198	Sello del Vuelo Bronce
21199	Sello del Vuelo Bronce
21200	Sello del Vuelo Bronce
21201	Sello del Vuelo Bronce
21202	Sello del Vuelo Bronce
21203	Sello del Vuelo Bronce
21204	Sello del Vuelo Bronce
21205	Sello del Vuelo Bronce
21206	Sello del Vuelo Bronce
21207	Sello del Vuelo Bronce
21208	Sello del Vuelo Bronce
21209	Sello del Vuelo Bronce
21210	Sello del Vuelo Bronce
21211	Faltriquera de polvo de reno
21212	Acebo fresco
21213	Acebo en conserva
21214	Escrito sobre Descarga de Escarcha XI
21215	Pastel de macedonia y carne de Graccu
21216	Obsequio megaespecial de Pastos de Bosquehumeante
21217	Delicia de sabiola
21218	Cristal resonador qiraji azul
21219	Receta: delicia de sabiola
21220	Cabeza de Osirio el Sinmarcas
21221	Ojo de C'Thun
21222	Quitina blindada
21223	Piedra negra
21224	Trozo de armadura antigua
21225	Coraza pesada de silítido
21226	Piedra rúnica
21227	Cráneo de héroe antiguo
21228	Valija reforzada con mitril
21229	Insignia de Señor qiraji
21230	Artefacto qiraji antiguo
21232	Armamentos imperiales qiraji
21235	Asado del Festival de Invierno
21236	Pan del Festival de Invierno
21237	Atavío imperial qiraji
21240	Dulce de Festival de Invierno
21241	Ponche de huevo del Festival de Invierno
21242	Hacha de guerra qiraji bendita
21243	Vigorpez hinchado
21244	Pugio qiraji bendito
21245	Instrucciones de la misión táctica I
21246	Informe de tareas de combate I
21247	Informe de tareas de combate II
21248	Informe de tareas de combate IV
21249	Informe de tareas de combate V
21250	Informe de tareas de combate VI
21251	Informe de tareas de combate VII
21252	Informe de tareas de combate VIII
21253	Informe de tareas de combate IX
21254	Galleta de Festival de Invierno
21255	Informe de tareas de combate X
21256	Informe de tareas de combate XI
21257	Informe de tareas logísticas IV
21258	Informe de tareas logísticas IV
21259	Informe de tareas logísticas V
21260	Informe de tareas logísticas VI
21261	Informe de tareas logísticas VI
21262	Informe de tareas logísticas VIII
21263	Informe de tareas logísticas VII
21264	Informe de tareas logísticas VII
21265	Informe de tareas logísticas IX
21266	Encargo de logística
21267	Cáliz de brindis
21268	Martillo de guerra qiraji bendito
21269	Baluarte qiraji bendito
21270	Obsequio ligeramente agitado
21271	Obsequio ligeramente agitado
21272	Mosquete qiraji bendito
21273	Bastón de acólito qiraji bendito
21275	Bastón de augur qiraji bendito
21277	Yeti mecánico tranquilo
21278	Guantes de embozo de tormenta
21279	Escrito sobre Bola de Fuego XII
21280	Escrito sobre Misiles Arcanos VIII
21281	Grimorio Descarga de las Sombras X
21282	Grimorio Inmolar VIII
21283	Grimorio Corrupción VII
21284	Códice de Sanación superior V
21285	Códice de Renovar X
21287	Códice de Rezo de sanación V
21288	Tratado: Bendición de sabiduría VI
21289	Tratado: Bendición de poderío VII
21290	Tratado: Luz Sagrada IX
21291	Tablilla de Ola de sanación X
21292	Tablilla de Tótem Fuerza de la tierra V
21293	Tablilla de Tótem Gracia del Aire III
21294	Libro sobre Toque de sanación XI
21295	Libro sobre Fuego estelar VII
21296	Libro sobre Rejuvenecimiento XI
21297	Manual de Golpe heroico IX
21298	Manual de Grito de batalla VII
21299	Manual de Revancha VI
21300	Vademécum de Puñalada IX
21301	Caja de ayudante verde
21302	Vademécum de Veneno mortal V
21303	Vademécum de Amago V
21304	Guía: Multidisparo V
21305	Caja de ayudante roja
21306	Guía: Picadura de serpiente IX
21307	Guía: Aspecto del halcón VII
21308	Campanita alegre
21309	Equipo de muñeco de nieve
21310	Presente con envoltorio alegre
21311	Jubón del Guardián de la Tierra
21312	Cinturón del vigía del cubil
21313	Bolsa pequeña de El'saco
21314	Cartas y notas de Metzen
21315	Cartera de Bosquehumeante
21316	Leotardos de ursa
21317	Yelmo del abrecaminos
21318	Guantes del Guardián de la Tierra
21319	Guantes del Abrecaminos
21320	Jubón del vigía del cubil
21321	Cristal resonador qiraji rojo
21322	Abrazo de ursa
21323	Cristal resonador qiraji verde
21324	Cristal resonador qiraji amarillo
21325	Grinch mecánico
21326	Defensor de los Fauces de Madera
21327	Presente que hace tic-tac
21328	Varita de felicidad del recreo
21329	Corona de conquistador
21330	Bufas de conquistador
21331	Coraza de conquistador
21332	Musleras de conquistador
21333	Grebas de conquistador
21334	Togas de clamacondenas
21335	Manto de clamacondenas
21336	Calzas de clamacondenas
21337	Aro de clamacondenas
21338	Borceguíes de clamacondenas
21340	Faltriquera de almas
21341	Bolsa de tela vil
21342	Bolsa de tela vil del Núcleo
21343	Togas Enigma
21344	Botas enigma
21345	Hombreras enigma
21346	Leotardos enigma
21347	Aro enigma
21348	Tiara del Oráculo
21349	Borceguíes del Oráculo
21350	Manto del Oráculo
21351	Vestimentas del Oráculo
21352	Calzas del Oráculo
21353	Yelmo génesis
21354	Hombreras génesis
21355	Botas génesis
21356	Calzas génesis
21357	Jubón génesis
21358	Patrón: faltriquera de almas
21359	Botas de mortífero
21360	Yelmo de mortífero
21361	Bufas de mortífero
21362	Leotardos de mortífero
21363	Obsequio festivo
21364	Jubón de mortífero
21365	Guardapiés de asediador
21366	Diadema de asediador
21367	Espaldares de asediador
21368	Leotardos de asediador
21369	Patrón: bolsa de tela vil
21370	Camisote de asediador
21371	Patrón: bolsa de tela vil del Núcleo
21372	Diadema de clamatormentas
21373	Guardapiés de clamatormentas
21374	Camisote de clamatormentas
21375	Leotardos de clamatormentas
21376	Espaldares de clamatormentas
21377	Pluma de penacho de Muertobosque
21378	Informe de tareas logísticas I
21379	Informe de tareas logísticas II
21380	Informe de tareas logísticas III
21381	Informe de tareas logísticas IX
21382	Informe de tareas logísticas V
21383	Cuentas de Espíritu Nevada
21384	Informe de tareas logísticas VIII
21385	Informe de tareas logísticas X
21386	Seguimiento del encargo de logística
21387	Corona del Vengador
21388	Grebas del Vengador
21389	Coraza del Vengador
21390	Musleras del Vengador
21391	Espaldares del Vengador
21392	Hoz de fuerza implacable
21393	Sello de fuerza implacable
21394	Mantón de fuerza implacable
21395	Hoja de Justicia eterna
21396	Anillo de Justicia eterna
21397	Manteo de Justicia eterna
21398	Martillo de la tormenta inminente
21399	Anillo de la tormenta inminente
21400	Capa de la tormenta inminente
21401	Guadaña de la senda oculta
21402	Sello de la senda oculta
21403	Capa de la senda oculta
21404	Daga de las sombras ocultas
21405	Sortija de las sombras ocultas
21406	Capa de las sombras ocultas
21407	Maza de vida inagotable
21408	Sortija de vida inagotable
21409	Capa de vida inagotable
21410	Mazo de sabiduría infinita
21411	Anillo de sabiduría infinita
21412	Embozo de sabiduría infinita
21413	Hoja de secretos oscuros
21414	Sortija de secretos oscuros
21415	Mantón de secretos oscuros
21416	Kris de los nombres prohibidos
21417	Anillo de los nombres prohibidos
21418	Embozo de los nombres prohibidos
21436	Sello de mención de honor de la Alianza
21438	Sello de mención de honor de la Horda
21452	Bastón de las Ruinas
21453	Manto de los Horusath
21454	Sobrehombros de piedra rúnica
21455	Yelmo Viento del Sur
21456	Capa Tormenta de Arena
21457	Brazales de brutalidad
21458	Guanteletes de Nueva Vida
21459	Ballesta de Fatalidad inminente
21460	Yelmo de Dominación
21461	Leotardos de la ventisca negra
21462	Guantes de Sabiduría oscura
21463	Brazal de Osirio
21464	Grilletes del Sinmarcas
21466	Aguijón de Ayamiss
21467	Coselete de silítido grueso
21468	Manto de Maz'Nadir
21469	Guanteletes de Viento del Sur
21470	Capa del Salvador
21471	Garfa de Concentración de furia
21472	Turbante viento polvoriento
21473	Ojo de Moam
21474	Guardahombros de quitina
21475	Quijotes del Destructor
21476	Leotardos escamados de obsidiana
21477	Anillo de Furia
21478	Arco de tendón tenso
21479	Guanteletes del Inamovible
21480	Guanteletes de silítido escamados
21481	Botas del Protector del desierto
21482	Botas de las Arenas ígneas
21483	Anillo de los Vientos del desierto
21484	Yelmo de Recrecimiento
21485	Trozo de la calavera de Buru
21486	Guantes del Enjambre
21487	Guanteletes escamados babosos
21488	Fetiche de pinchos de quitina
21489	Botas de arenas movedizas
21490	Chanclos para babosas
21491	Brazales escamados del Glotón
21492	Destripahombres de los qiraji
21493	Botas de la Soldado de Caballería
21494	Garra Viento del Sur
21495	Quijotes del comando qiraji
21496	Brazales de Orden qiraji
21497	Botas del General qiraji
21498	Daga qiraji de sacrificios
21499	Vestimentas del Mar de Dunas
21500	Cinturón de la Inquisición
21501	Guantes de pellejo de silítido fortalecido
21502	Guardamuñecas de atracador de arena
21503	Cinturón del Atracador de arena
21504	Talismán del Mar de Dunas
21505	Gargantilla del Mar de Dunas
21506	Colgante del Mar de Dunas
21507	Amuleto del Mar de Dunas
21508	Marca de Cenarius
21509	Suministros del esfuerzo de guerra de Ahn'Qiraj
21510	Suministros del esfuerzo de guerra de Ahn'Qiraj
21511	Suministros del esfuerzo de guerra de Ahn'Qiraj
21512	Suministros del esfuerzo de guerra de Ahn'Qiraj
21513	Suministros del esfuerzo de guerra de Ahn'Qiraj
21514	Informe de tareas logísticas XI
21515	Marca de Remulos
21517	Turbante de poderío psíquico gnómico
21519	Muérdago
21520	Legado de Cresta Cuervo
21521	Espada rúnica de los rojos
21522	Pena de Cantosombrío
21523	Colmillo de Korialstrasz
21524	Sombrero de invierno rojo
21525	Sombrero de invierno verde
21526	Sortija de Prolavades heladas
21527	Togas Aguaoscura
21528	Bolsa de botín colosal
21529	Amuleto de Escudo de las Sombras
21530	Leotardos incrustados de ónice
21531	Collar de dientes de draco
21532	Botas de esclavo
21533	Coraza del Coloso de Zora
21534	Coraza del Coloso de Ashi
21535	Coraza del Coloso de Regal
21536	Piedra elunarita
21537	Albóndigas festivas
21538	Vestido de fiesta rosa
21539	Vestido de fiesta morado
21540	Farol de Elune
21541	Traje pantalón de fiesta negro
21542	Traje de fiesta
21543	Traje pantalón de fiesta verde azulado
21544	Traje pantalón de fiesta azul
21545	Provisiones de Bosquehumeante
21546	Elixir de poder de Fuego superior
21547	Receta: elixir de poder de Fuego superior
21548	Patrón: guantes de embozo de tormenta
21552	Serviola a rayas
21557	Cohete rojo pequeño
21558	Cohete azul pequeño
21559	Cohete verde pequeño
21560	Cohete morado pequeño
21561	Cohete blanco pequeño
21562	Cohete amarillo pequeño
21563	Sortija de Don Rodrigo
21565	Runa de perfección
21566	Runa de perfección
21567	Runa de deber
21568	Runa de deber
21569	Lanzador de fuegos artificiales
21570	Lanzatracas
21571	Traca de cohetes azules
21574	Traca de cohetes verdes
21575	Traca de cohetes morados
21576	Traca de cohetes rojos
21577	Traca de cohetes blancos
21578	Traca de cohetes amarillos
21579	Tentáculo derrotado de C'Thun
21581	Guanteletes de Aniquilación
21582	Garra del dios antiguo
21583	Capa de Claridad
21584	Brazales de Juicio eterno
21585	Guanteletes de Tormenta oscura
21586	Cinturón de Agonía interminable
21587	Guardamuñecas de Castigo
21588	Guardamuñecas de Furia elemental
21589	Cohete azul grande
21590	Cohete verde grande
21591	Cohete morado grande
21592	Cohete rojo grande
21593	Cohete blanco grande
21594	Brazales del Hijo caído
21595	Cohete amarillo grande
21596	Anillo del destripadioses
21597	Cetro real de Vek'lor
21598	Cinturón qiraji real
21599	Guantes de Devastación de Vek'lor
21600	Botas de epifanía
21601	Anillo del Emperador Vek'lor
21602	Brazales qiraji de ejecución
21603	Varita de Nobleza qiraji
21604	Pulseras de redención real
21605	Guantes del Templo oculto
21606	Cinturón del emperador caído
21607	Garra del emperador caído
21608	Amuleto de Vek'nilash
21609	Cinturón regenerador de Vek'nilash
21610	Bloqueador de escamas de gusano
21611	Brazales de escarbador
21612	Apisonadoras de escamas de gusano
21613	Botas de pellejo de gusano
21614	Protector de pellejo de gusano
21615	Sombrero perdido de Don Rigoberto
21616	Aguijón de Huhuran
21617	Guanteletes de pellejo de avispa
21618	Guardamuñecas de colmena Rapiñador
21619	Guantes del Mesías
21620	Anillo del mártir
21621	Capa de la Colmena dorada
21622	Fémur de silítido afilado
21623	Guanteletes de Campeón recto
21624	Guanteletes de Kalimdor
21625	Broche escarabajo
21626	Leotardos cubiertos de baba
21627	Capa de los Secretos ocultos
21635	Púa del atracador de arena
21639	Espaldares del Inflexible
21640	Paquete de fuegos artificiales del Festival Lunar
21645	Botas de tunelador de colmena
21647	Fetiche del Atracador de arena
21648	Botas recompuestas
21650	Destripador qiraji antiguo
21651	Leotardos escamados de atracador de arena
21652	Coselete caparazón de silítido
21663	Togas del Santo guardián
21664	Gargantilla de púas
21665	Manto de la Revancha Horrenda
21666	Poderío de Sartura
21667	Quijotes de Luz llameantes
21668	Leotardos escamados de furia qiraji
21669	Yelmo parra reptadora
21670	Distintivo del Guardaenjambres
21671	Togas del Guardia de batalla
21672	Guantes de aplicación
21673	Garra de silítido
21674	Guanteletes de determinación férrea
21675	Cinturón de pellejo qiraji grueso
21676	Leotardos del Enjambre ulceroso
21677	Anillo de Furia qiraji
21678	Collar de Pureza
21679	Revancha de Kalimdor
21680	Jubón de Ejecución presto
21681	Anillo de los Devorados
21682	Guanteletes cubiertos de bilis
21683	Manto de la Cruzada del Desierto
21684	Manto de la Furia del Desierto
21685	Escarabajo petrificado
21686	Manto de Poder frénico
21687	Anillo de oscuridad de Ukko
21688	Botas del Héroe caído
21689	Guantes de Ebru
21690	Talismán de Angelista
21691	Guanteletes de moco
21692	Faja de tríada
21693	Apariencia del Devorador
21694	Manto ternario
21695	Toque de Angelista
21696	Togas del Triunvirato
21697	Manteo de la Trinidad
21698	Leotardos de Inmersión
21699	Sobrehombros de bombardeo
21700	Colgante del guardián qiraji
21701	Capa de Odio concentrado
21702	Amuleto de Guarda del mal
21703	Martillo de Ji'zhi
21704	Botas de la Profecía cumplida
21705	Botas del Profeta caído
21706	Botas de la voluntad inquebrantable
21707	Anillo de enjambre de pensamientos
21708	Guardamuñecas escamados de alfazaques
21709	Anillo del Dios caído
21710	Capa del Dios caído
21711	Invitación al Festival Lunar
21712	Amuleto del Dios caído
21713	Vela de Elune
21714	Traca de cohetes azules grandes
21715	Martillo pulido con arena
21716	Traca de cohetes verdes grandes
21717	Traca de cohetes morados grandes
21718	Traca de cohetes rojos grandes
21719	Traca de cohetes blancos grandes
21720	Traca de cohetes amarillos grandes
21721	Resplandor lunar
21722	Patrón: vestido de fiesta
21723	Patrón: traje de fiesta
21724	Esquema: cohete azul pequeño
21725	Esquema: cohete verde pequeño
21726	Esquema: cohete rojo pequeño
21727	Esquema: cohete azul grande
21728	Esquema: cohete verde grande
21729	Esquema: cohete rojo grande
21730	Esquema: traca de cohetes azules
21731	Esquema: traca de cohetes verdes
21732	Esquema: traca de cohetes rojos
21733	Esquema: traca de cohetes azules grandes
21734	Esquema: traca de cohetes verdes grandes
21735	Esquema: traca de cohetes rojos grandes
21736	Riendas de grifo de montar
21737	Esquema: lanzatracas
21738	Esquema: lanzador de fuegos artificiales
21740	Recetas de cohetes pequeños
21741	Recetas de tracas de cohetes
21742	Recetas de cohetes grandes
21743	Recetas de tracas de cohetes grandes
21744	Traca de cohetes de la suerte
21745	Piedra lunar de anciano
21746	Sobre rojo de la suerte
21747	Petardo festivo
21749	Informe de tareas de combate I
21750	Informe de tareas de combate II
21751	Instrucciones de la misión táctica III
21761	Llave del arca del Escarabajo
21762	Llave del arca del Escarabajo superior
21800	Lanzacoraza de silítido
21801	Antena de tonificación
21802	El kris perdido de Zedd
21803	Yelmo del Vengador Sagrado
21804	Almófar de Furia elemental
21805	Espaldares de obsidiana pulidos
21806	Mazo de Autoridad qiraji
21809	Furia del Enjambre olvidado
21810	Botines de nómada errante
21812	Caja de bombones
21813	Bolsa de caramelos
21814	Coraza de Aniquilación
21815	Prueba de amor
21816	Corazón de caramelo
21817	Corazón de caramelo
21818	Corazón de caramelo
21819	Corazón de caramelo
21820	Corazón de caramelo
21821	Corazón de caramelo
21822	Corazón de caramelo
21823	Corazón de caramelo
21829	Botella de perfume
21830	Envoltorio vacío
21831	Obsequio con envoltorio
21833	Botella de colonia
21836	Anillo de caos de Ritssyn
21837	Martillo de guerra Anubisath
21838	Atuendo de Ascensión Real
21839	Cetro del falso profeta
21856	Neretzek, la Sedienta de Sangre
21888	Guantes del Inmortal
21889	Guantes de la Profecía redimida
21890	Guantes del Profeta caído
21891	Fragmento de la estrella caída
21920	Carta arrugada
21921	Nota escrita con pluma con cuidado
21925	Carta inmaculada
21926	Nota ligeramente arrugada
21928	Muestra de sangre de Cuna del Invierno
21935	Ectoplasma estable
21936	Ectoplasma congelado
21937	Ectoplasma agostado
21938	Núcleo de arrabio
21939	Vara elemental vil
21946	Destilador ectoplásmico
21960	Talla de madera
21975	Juramento de Adoración: Ventormenta
21979	Ofrenda de adoración: Darnassus
21980	Ofrenda de adoración: Forjaz
21981	Ofrenda de adoración: Ventormenta
21982	Abalorios de guerra de ogro
21983	Estandarte de Provocación incompleto
21984	Parte izquierda del amuleto de Lord Valthalak
21985	Contenedor de sangre sellado
21986	Estandarte de provocación
21987	Incendicita de Lord Incendius
21988	Ascua del Brasadivino
21989	Rescoldo de las brasas
21994	Cinturón de heroísmo
21995	Botas de heroísmo
21996	Brazales de heroísmo
21997	Coraza de heroísmo
21998	Guanteletes de heroísmo
21999	Yelmo de heroísmo
22000	Quijotes de heroísmo
22001	Bufas de heroísmo
22002	Cinturón Mantoscuro
22003	Botas Mantoscuro
22004	Brazales Mantoscuro
22005	Almete Mantoscuro
22006	Guantes Mantoscuro
22007	Pantalones Mantoscuro
22008	Bufas Mantoscuro
22009	Guerrera Mantoscuro
22010	Cinturón de maestro de bestias
22011	Ataduras de maestro de bestias
22013	Almete de maestro de bestias
22014	Blandón sacralizado
22015	Guantes de maestro de bestias
22016	Manto de maestro de bestias
22017	Pantalones de maestro de bestias
22046	Parte derecha del amuleto Lord Valthalak
22047	Parte superior del amuleto de Lord Valthalak
22048	Amuleto de Lord Valthalak
22049	Blandón de señalización
22050	Blandón de señalización
22051	Blandón de señalización
22052	Blandón de señalización
22056	Blandón de señalización
22057	Blandón de Invocación
22058	Papel y sobres para cartas de San Valentín
22059	Tarjeta de San Valentín
22060	Guerrera de maestro de bestias
22061	Botas de maestro de bestias
22062	Cinturón de hechicero
22063	Ataduras de hechicero
22064	Botas de hechicero
22065	Corona de hechicero
22066	Guantes de hechicero
22067	Leotardos de hechicero
22068	Manto de hechicero
22069	Togas de hechicero
22070	Cinturón Brumamorta
22071	Brazales Brumamorta
22072	Leotardos Brumamorta
22073	Manto Brumamorta
22074	Máscara Brumamorta
22075	Toga Brumamorta
22076	Sandalias Brumamorta
22077	Brazaletes Brumamorta
22078	Cinturón del virtuoso
22079	Brazales del virtuoso
22080	Corona del virtuoso
22081	Guantes del virtuoso
22082	Manto del virtuoso
22083	Toga del virtuoso
22084	Zapatos del virtuoso
22085	Saya del virtuoso
22086	Cinturón Forjaalma
22087	Botas Forjaalma
22088	Brazales Forjaalma
22089	Coraza Forjaalma
22090	Guanteletes Forjaalma
22091	Yelmo Forjaalma
22092	Quijotes Forjaalma
22093	Bufas Forjaalma
22094	Alga de sangre
22095	Ataduras de los Cinco Truenos
22096	Botas de los Cinco Truenos
22097	Almófar de los Cinco Truenos
22098	Cordón de los Cinco Truenos
22099	Guanteletes de los Cinco truenos
22100	Falda de los Cinco Truenos
22101	Espaldares de los Cinco Truenos
22102	Jubón de los Cinco Truenos
22106	Cinturón cuoroferal
22107	Botas cuoroferal
22108	Brazales cuoroferal
22109	Capucha cuoroferal
22110	Guantes cuoroferal
22111	Falda cuoroferal
22112	Bufas cuoroferal
22113	Jubón cuoroferal
22114	Huevo múrloc rosa
22115	Detector de fantasmas extradimensional
22117	Juramento de Lealtad: Ventormenta
22119	Juramento de Lealtad: Forjaz
22120	Juramento de Lealtad: Darnassus
22121	Juramento de Lealtad: Entrañas
22122	Juramento de Lealtad: Cima del Trueno
22123	Juramento de Lealtad: Orgrimmar
22130	Símbolo de Amor
22131	Colección de obsequios de Ventormenta
22132	Colección de obsequios de Forjaz
22133	Colección de obsequios de Darnassus
22134	Colección de obsequios de Entrañas
22135	Colección de obsequios de Cima del Trueno
22136	Colección de obsequios de Orgrimmar
22137	Cartera de Ysida
22138	Brazal Roca Negra
22139	Guardapelo de Ysida
22140	Tarjeta de centinela
22141	Tarjeta de guardia de Forjaz
22142	Tarjeta de bruto
22143	Tarjeta de guardia de Ventormenta
22144	Tarjeta de vigía de la Cima
22145	Tarjeta mohosa de guardián
22149	Cuentas de mojo de ogro
22150	Cuentas de Poderío de ogro
22151	Agua bendita de Anthion
22152	Faltriquera de Anthion
22154	Juramento de Adoración: Forjaz
22155	Juramento de Adoración: Darnassus
22156	Juramento de Adoración: Orgrimmar
22157	Juramento de Adoración: Entrañas
22158	Juramento de Adoración: Cima del Trueno
22159	Juramento de Amistad: Darnassus
22160	Juramento de Amistad: Forjaz
22161	Juramento de Amistad: Orgrimmar
22162	Juramento de Amistad: Cima del Trueno
22163	Juramento de Amistad: Entrañas
22164	Ofrenda de adoración: Orgrimmar
22165	Ofrenda de adoración: Cima del Trueno
22166	Ofrenda de adoración: Entrañas
22167	Ofrenda de amistad: Darnassus
22168	Ofrenda de amistad: Forjaz
22169	Ofrenda de amistad: Orgrimmar
22170	Ofrenda de amistad: Ventormenta
22171	Ofrenda de amistad: Cima del Trueno
22172	Ofrenda de amistad: Entrañas
22173	Cerveza casera enana
22174	Poema romántico
22175	Tarta recién horneada
22176	Pan casero
22177	Flores recién cogidas
22178	Juramento de Amistad: Ventormenta
22191	Guerrera de malla de obsidiana
22192	Elixir de esquivez de alga de sangre
22193	Elixir de resistencia de alga de sangre
22194	Garra negra del Destructor
22195	Cinturón de obsidiana ligero
22196	Coraza gruesa de obsidiana
22197	Cinturón de obsidiana pesado
22198	Escudo dentado de obsidiana
22200	Flecha con astil de plata
22201	Relicario de Pureza
22202	Fragmento de obsidiana pequeño
22203	Fragmento de obsidiana grande
22204	Guardamuñecas de Renombre
22205	Ataduras de acero negro
22206	Ramo de rosas rojas
22207	Fajín del Gran cazador
22208	Martillo de piedra de lava
22209	Diseño: cinturón de obsidiana pesado
22212	Espaldares a medida gólem
22214	Diseño: cinturón de obsidiana ligero
22216	Glándula de veneno de Venoxis
22217	Glándula de veneno de Kurinnaxx
22218	Puñado de pétalos de rosa
22219	Diseño: escudo dentado de obsidiana
22220	Diseño: Garra negra del Destructor
22221	Diseño: guerrera de malla de obsidiana
22222	Diseño: coraza gruesa de obsidiana
22223	Protector de cabeza de supervisor
22224	Esencia de espectro bufón
22225	Capucha de piel de dragón
22226	Restos druidas
22227	Reliquia de Aldea Brisaestelar
22228	Espada luminosa de zelote
22229	Cenizas de alma del Desterrado
22230	Pellejo Morromiedo
22231	Botas de precisión de Kayser
22232	Faja de tirador
22233	Baúl de Zigris
22234	Manto de Esperanza Perdida
22235	Flecha con astil de veraplata
22236	Delicia de leche
22237	Deseo oscuro
22238	Crema de frutos cremosa
22239	Dulce sorpresa
22240	Grebas de Desesperación fulminante
22241	Espaldares de depositario oscuro
22242	Correa de Verek
22243	Faltriquera de almas pequeña
22244	Caja de almas
22245	Calzado taraceado con hollín
22246	Faltriquera de tejido mágico encantada
22247	Botas de curador de fe
22248	Bolsa de paño rúnico encantada
22249	Bolsa de encantamiento grande
22250	Faltriquera de hierbas
22251	Bolsa de hierbas Cenarion
22252	Cartera de Cenarius
22253	Escrito de los Perdidos
22254	Varita de Luz eterna
22255	Sortija forjada de magma
22256	Manijas para moldear maná
22257	Sortija de coágulo de sangre
22258	Poción de amor
22259	Pulsera de Amistad no depositada
22260	Pulsera de la amistad
22261	Loco de amor
22262	Colección de obsequios de la Alianza
22263	Colección de obsequios de la Horda
22264	Carta escrita con cuidado
22265	Carta escrita con amor
22266	Erupción de espinas
22267	Turbante de tejido de hechizos
22268	Emblema dracónico imbuido
22269	Capa de merodeador de las Sombras
22270	Botas de atrincheramiento
22271	Leotardos de Magia frenética
22272	Abrazo del bosque
22273	Caperuza Sombra Lunar
22274	Pelambre grisácea
22275	Botas Musgo de Fuego
22276	Vestido rojo precioso
22277	Traje de noche rojo
22278	Vestido azul precioso
22279	Vestido negro precioso
22280	Vestido morado precioso
22281	Traje de noche azul
22282	Traje de noche morado
22283	Saco de pan casero
22284	Fardo de tarjetas
22285	Colección de juramentos de Ventormenta
22286	Colección de juramentos de Forjaz
22287	Caja de tarjetas
22288	Caja de cerveza casera
22289	Montón de tarjetas
22290	Colección de juramentos de Darnassus
22291	Caja de talla de madera
22292	Caja de tartas recientes
22293	Paquete de tarjetas
22294	Colección de juramentos de Orgrimmar
22295	Cartera de tarjetas
22296	Cesta de flores
22297	Colección de juramentos de Cima del Trueno
22298	Libro de Poemas románticos
22299	Fajo de tarjetas
22300	Colección de juramentos de Entrañas
22301	Toga de tejido de hierro
22302	Capucha de tejido de hierro
22303	Pantalones de tejido de hierro
22304	Guantes de tejido de hierro
22305	Manto de tejido de hierro
22306	Cinturón de tejido de hierro
22307	Patrón: faltriquera de tejido mágico encantada
22308	Patrón: bolsa de paño rúnico encantada
22309	Patrón: bolsa de encantamiento grande
22310	Patrón: bolsa de hierbas Cenarion
22311	Botas de tejido de hierro
22312	Patrón: cartera de Cenarius
22313	Brazales de tejido de hierro
22314	Arpón de cazador
22315	Martillo de Revitalización
22317	Nudillos de latón de Zurdito
22318	Arco largo de Malgen
22319	Escrito sobre Derecho divino
22320	Víveres de calidad de Mux
22321	Corazón de Vermisthalak
22322	El rompe mandíbulas
22324	Kimchi de invierno
22325	Cinturón del Timador
22326	Sortija de amalgama
22327	Amuleto de los redimidos
22328	Quijotes de Vigilancia
22329	Cetro de Enfoque interminable
22330	Embozo de Maestría Arcana
22331	Sortija del Héroe férreo
22332	Hoja de Nigromancia
22333	Martillo de Poderío divino
22334	Sortija de alivio
22335	Bastón de mando de Lord Valthalak
22336	Égida draconiana de la Legión
22337	Embozo de Dominación
22338	Ceniza volcánica
22339	Sortija rúnica de hechicería
22340	Colgante de Celeridad
22342	Leotardos de Tormento
22343	Manoplas de ferocidad
22344	Blandón de Invocación: manual
22345	Tótem de Renacer
22347	Ballesta de repetición de recarga de Fahrad
22348	Prima de Condemulus
22349	Coraza profanada
22350	Guerrera profanada
22351	Toga profanada
22352	Quijotes profanados
22353	Casco profanado
22354	Espaldares profanados
22355	Brazales profanados
22356	Guardarrenes profanados
22357	Guanteletes profanados
22358	Escarpes profanados
22359	Musleras profanadas
22360	Celada profanada
22361	Bufas profanadas
22362	Guardamuñecas profanados
22363	Faja profanada
22364	Manoplas profanadas
22365	Botas profanadas
22366	Leotardos profanados
22367	Aro profanado
22368	Hombreras profanadas
22369	Ataduras profanadas
22370	Cinturón profanado
22371	Guantes profanados
22372	Botines profanados
22373	Restos de cuero
22374	Restos de malla
22375	Restos de coraza
22376	Restos de ropa
22377	El atizador Truenedera
22378	Cercenadora Ravenholdt
22379	Chafarote de Shivsprocket
22380	Martillo de cultivo de Simone
22381	Muestra de veneno de Silithus
22382	Contenedor de veneno sellado
22383	Hoja sabia
22384	Persuasor
22385	Leotardos titánicos
22386	Head of Instructor Razuvious DEP
22387	Corazón de Anub'Rekhan
22388	Diseño: leotardos titánicos
22389	Diseño: hoja sabia
22390	Diseño: persuasor
22392	Fórmula: encantar arma de 2M: agilidad
22393	Códice: Rezo de Protección contra las Sombras
22394	Bastón de Metanoia
22395	Tótem de Ira
22396	Tótem de Vida
22397	Ídolo de ferocidad
22398	Ídolo de Rejuvenecimiento
22399	Ídolo de Salud
22400	Tratado sobre verdad
22401	Tratado sobre esperanza
22402	Tratado sobre gracia
22403	Collar de caparazones nacarados
22404	Rascaespalda de Willey
22405	Manto de la Cruzada Escarlata
22406	Redención
22407	Yelmo de la Luna nueva
22408	Varita de mojo maligno de Ritssyn
22409	Guerrera de la media luna
22410	Guanteletes de ardid
22411	Yelmo del Verdugo
22412	Manto Thuzadin
22416	Coraza acorator
22417	Quijotes acorator
22418	Casco acorator
22419	Espaldares acorator
22420	Escarpes acorator
22421	Guanteletes acorator
22422	Guardarrenes acorator
22423	Brazales acorator
22424	Guardamuñecas de redención
22425	Guerrera de redención
22426	Manoplas de redención
22427	Musleras de redención
22428	Celada de redención
22429	Bufas de redención
22430	Botas de redención
22431	Faja de redención
22432	Púa de demosaurio
22433	Sortija de dominación de Don Mauricio
22434	Champiñón de sangre
22435	Aguijón Gorishi
22436	Guerrera de acechacriptas
22437	Musleras de acechacriptas
22438	Celada de acechacriptas
22439	Bufas de acechacriptas
22440	Botas de acechacriptas
22441	Manoplas de acechacriptas
22442	Faja de acechacriptas
22443	Guardamuñecas de acechacriptas
22444	Vid pútrida
22458	Báculo Sombra Lunar
22464	Guerrera Rompeterra
22465	Musleras Rompeterra
22466	Celada Rompeterra
22467	Bufas Rompeterra
22468	Botas Rompeterra
22469	Manoplas Rompeterra
22470	Faja Rompeterra
22471	Guardamuñecas Rompeterra
22472	Botas de ferocidad
22476	Coraza Segahuesos
22477	Quijotes Segahuesos
22478	Casco Segahuesos
22479	Espaldares Segahuesos
22480	Escarpes Segahuesos
22481	Guanteletes Segahuesos
22482	Guardarrenes Segahuesos
22483	Brazales Segahuesos
22484	Runa necrótica
22488	Guerrera Caminasueños
22489	Musleras Caminasueños
22490	Celada Caminasueños
22491	Bufas Caminasueños
22492	Botas Caminasueños
22493	Manoplas Caminasueños
22494	Faja Caminasueños
22495	Guardamuñecas Caminasueños
22496	Toga de Fuego de Escarcha
22497	Leotardos de Fuego de Escarcha
22498	Aro de Fuego de Escarcha
22499	Hombreras de Fuego de Escarcha
22500	Botines de Fuego de Escarcha
22501	Guantes de Fuego de Escarcha
22502	Cinturón de Fuego de Escarcha
22503	Ataduras de Fuego de Escarcha
22504	Toga corazón de peste
22505	Leotardos corazón de peste
22506	Aro corazón de peste
22507	Hombreras corazón de peste
22508	Botines corazón de peste
22509	Guantes corazón de peste
22510	Cinturón corazón de peste
22511	Ataduras corazón de peste
22512	Toga de fe
22513	Leotardos de fe
22514	Aro de fe
22515	Hombreras de fe
22516	Sandalias de fe
22517	Guantes de fe
22518	Cinturón de fe
22519	Ataduras de fe
22520	La filacteria de Kel'Thuzad
22523	Insignia de El Alba
22524	Insignia de la Cruzada
22525	Trozos de maligno de cripta
22526	Trozos de huesos
22527	Núcleo de elementos
22528	Fragmentos de hierro negro
22529	Hojas salvajes
22568	Libranza de artesano lacrada
22589	Atiesh, gran báculo del Guardián
22593	Libranza de salvoconducto
22595	Anuncio del llamamiento a las armas
22600	Libranza del artesano: contrapeso denso
22601	Libranza del artesano: peto de placas imperiales
22602	Libranza del artesano: martillo volcánico
22603	Libranza del artesano: hacha de batalla de torio enorme
22604	Libranza del artesano: aro radiante
22605	Libranza del artesano: cinta de cuero maligno
22606	Libranza del artesano: refuerzo para armadura basto
22607	Libranza del artesano: cinturón de cuero maligno
22608	Libranza del artesano: pantalones de cuero rúnico
22609	Libranza del artesano: pantalones de paño brillante
22610	Libranza del artesano: botas de paño rúnico
22611	Libranza del artesano: bolsa de paño rúnico
22612	Libranza del artesano: toga de paño rúnico
22613	Libranza del artesano: carga de zapador goblin
22614	Libranza del artesano: granada de torio
22615	Libranza del artesano: gallo de batalla gnómico
22616	Libranza del artesano: tubo de torio
22617	Libranza del artesano: poción de maná sublime
22618	Libranza del artesano: poción de sanación sublime
22619	Libranza del artesano: poción de Protección contra la Escarcha superior
22620	Libranza del artesano: poción de Protección contra lo Arcano superior
22621	Libranza del artesano: frasco de petrificación
22622	Libranza del artesano: anguila escama pétrea
22623	Libranza del artesano: pez coraza de placas
22624	Libranza del artesano: anguila relámpago
22625	Libranza del artesano: salmón al horno
22626	Libranza del artesano: sorpresa de tubérculo runtún
22630	Atiesh, gran báculo del Guardián
22631	Atiesh, gran báculo del Guardián
22632	Atiesh, gran báculo del Guardián
22635	Guardia salvaje
22636	Guardiahielo
22637	Ídolo Hakkari primigenio
22638	Guardasombras
22648	Informe sobre Colmen'Ashi
22649	Informe Colmen'Regal
22650	Informe sobre Colmen'Zora
22651	Musleras de placas de escolta
22652	Jubón glacial
22654	Guantes glaciales
22655	Muñequeras glaciales
22656	El Purificador
22657	Amuleto del Alba
22658	Capa glacial
22659	Medallón del Alba
22660	Abrazo de Gaia
22661	Guerrera polar
22662	Guantes polares
22663	Brazales polares
22664	Coraza de escamas heladas
22665	Brazales de escamas heladas
22666	Guanteletes de escamas heladas
22667	Brazales de esperanza
22668	Brazales de subterfugio
22669	Coraza Deliriohelado
22670	Guanteletes Deliriohelado
22671	Brazales Deliriohelado
22672	Musleras de placas de centinela
22673	Leotardos de anillas de escolta
22676	Leotardos de malla de escolta
22678	Dije de Ascendiente
22679	Bolsa de suministros
22680	Sortija de resolución
22681	Sortija de piedad
22682	Runa congelada
22683	Patrón: Abrazo de Gaia
22684	Patrón: guantes glaciales
22685	Patrón: capa glacial
22686	Patrón: jubón glacial
22687	Patrón: muñequeras glaciales
22688	Último recurso de Verimonde
22689	Yelmo de cuero santificado
22690	Leotardos del Cazador de peste
22691	Crematoria corrupta
22692	Patrón: guerrera polar
22694	Patrón: guantes polares
22695	Patrón: brazales polares
22696	Patrón: coraza de escamas heladas
22697	Patrón: guanteletes de escamas heladas
22698	Patrón: brazales de escamas heladas
22699	Leotardos Deliriohelado
22700	Leotardos glaciales
22701	Leotardos polares
22702	Leotardos de escamas heladas
22703	Diseño: coraza Deliriohelado
22704	Diseño: guanteletes Deliriohelado
22705	Diseño: brazales Deliriohelado
22707	Garra helada de Ramaladni
22708	Destino de Ramaladni
22711	Capa de los adoradores Hakkari
22712	Poderío de la Tribu
22713	Cetro Zulian de Ritos
22714	Guanteletes de sacrificio
22715	Guantes del Atormentado
22716	Cinturón de poder sin explotar
22718	Máscara empapada de sangre
22719	Vademécum de Omarion
22720	Ornato Zulian
22721	Sortija de Servidumbre
22722	Sello de rabioso Gurubashi
22723	Una carta del Guardián de los Pergaminos
22725	Sortija de Cenarius
22726	Astilla de Atiesh
22727	Armazón de Atiesh
22728	Mando de tonque de vapor
22729	Esquema: mando de tonque de vapor
22730	Cordón cinturón Acecha ojos
22731	Capa de los Devorados
22732	Marca de C'Thun
22733	Cabeza del báculo Atiesh
22734	Base de Atiesh
22736	Andonisus, Segador de almas
22737	Atiesh, gran báculo del Guardián
22739	Escrito sobre Polimorfia: tortuga
22740	Pantalones de cuero de escolta
22741	Pantalones de pellejo de lagarto de escolta
22742	Camisa Velasangre
22743	Fajín Velasangre
22744	Botas Velasangre
22745	Pantalones Velasangre
22746	Uniforme de bucanero
22747	Leotardos de seda de escolta
22748	Leotardos de anillas de centinela
22749	Pantalones de cuero de centinela
22750	Pantalones de pellejo de lagarto
22752	Leotardos de seda de centinela
22753	Musleras de láminas de centinela
22754	Quintaesencia eterna
22756	Jubón nemoroso
22757	Corona nemorosa
22758	Sobrehombros nemorosos
22759	Yelmo zarzal
22760	Botas zarzal
22761	Cinturón zarzal
22762	Coraza parraférrea
22763	Guantes parraférrea
22764	Cinturón parraférrea
22765	Carta enmohecida
22766	Diseño: coraza parraférrea
22767	Diseño: guantes parraférrea
22768	Diseño: cinturón parraférrea
22769	Patrón: cinturón zarzal
22770	Patrón: botas zarzal
22771	Patrón: yelmo zarzal
22772	Patrón: sobrehombros nemorosos
22773	Patrón: corona nemorosa
22774	Patrón: jubón nemoroso
22780	Huevo de múrloc blanco
22781	Collera de oso polar
22798	Poderío de Menethil
22799	Buscador de almas
22800	Bastón de azufre
22801	Aguja Crepuscular
22802	Caída del rey
22803	Bruma de medianoche
22804	Colmillo de Maexxna
22806	Remordimiento de viuda
22807	Espada de ánima
22808	El castigador
22809	Gran maza del cruzado redimido
22810	Inyector tóxico
22811	Hilo de alma
22812	Esclavizador nerubiano
22813	Mandoble de Poderío profano
22815	División
22816	Hachuela de hueso partido
22818	El portador de peste
22819	Escudo de Condena
22820	Varita de Fortunas
22821	Dedo condena
22822	iCoke Prize Voucher
22843	Grebas de anillas de Guardia de sangre
22852	Botines de pellejo de dragón de Guardia de sangre
22855	Botos de tejido de tinieblas de Guardia de sangre
22856	Botos de cuero de Guardia de sangre
22857	Grebas de malla de Guardia de sangre
22858	Grebas de placas de Guardia de sangre
22859	Botos de satén de Guardia de sangre
22860	Botos de seda de Guardia de sangre
22862	Abrazaderas de anillas de Guardia de sangre
22863	Mandiletes de pellejo de dragón de Guardia de sangre
22864	Mandiletes de cuero de Guardia de sangre
22865	Manijas de tejido de tinieblas de Guardia de sangre
22867	Abrazaderas de malla de Guardia de sangre
22868	Guanteletes de placas de Guardia de sangre
22869	Manijas de satén de Guardia de sangre
22870	Manijas de seda de Guardia de sangre
22872	Camisote de placas de Legionario
22873	Leotardos de placas de Legionario
22874	Camisote de anillas de Legionario
22875	Musleras de anillas de Legionario
22876	Camisote de malla de Legionario
22877	Pechera de pellejo de dragón de Legionario
22878	Leotardos de pellejo de dragón de Legionario
22879	Pechera de cuero de Legionario
22880	Musleras de cuero de Legionario
22881	Musleras de tejido de tinieblas de Legionario
22882	Musleras de satén de Legionario
22883	Musleras de seda de Legionario
22884	Guerrera de tejido de tinieblas de Legionario
22885	Guerrera de satén de Legionario
22886	Guerrera de seda de Legionario
22887	Musleras de malla de Legionario
22890	Escrito sobre Resguardo contra la Escarcha V
22891	Grimorio Resguardo contra las Sombras IV
22892	Piedra necrótica oscura
22895	Rollito de canela mágico
22897	Escrito sobre Crear comida VII
22930	Un sobre manchado de sangre
22932	Una carta rota
22935	Toque de Escarcha
22936	Guardamuñecas de Venganza
22937	Gema de Nerubis
22938	Capa de seda de demonio de cripta
22939	Sortija de Plegarias sin respuesta
22940	Espaldares Deliriohelado
22941	Hombreras polares
22942	El abrazo de la viuda
22943	Colgante de piedra malicia
22944	Una misiva arrugada
22945	Una nota con tono de agobio
22946	Una página hecha jirones
22947	Colgante de Nombres Olvidados
22948	Un documento manchado
22949	Cristal necrótico rajado
22950	Cristal necrótico tenue
22954	Beso de la araña
22960	Capa de Sutura
22961	Sortija de reanimación
22967	Bufas de escamas heladas
22968	Manto glacial
22970	Un sobre manchado de sangre
22972	Una nota con tono de agobio
22973	Una misiva arrugada
22974	Una página hecha jirones
22975	Un documento manchado
22977	Una carta rota
22981	Collera perdida de Gluth
22983	Manto cubierto de Escarcha
22988	El fin de los sueños
22994	Compendio de Mano de Poder
22999	Tabardo de El Alba Argenta
23000	Caja torácica de abominación con placas
23001	Ojo de Disminución
23002	Carcasa de tortuga
23004	Ídolo de Longevidad
23005	Tótem de agua corriente
23006	Tratado sobre luz
23007	Collera de cochinillo
23008	Informe de investigación lacrado
23009	Varita de la Muerte susurrante
23010	Informe de investigación lacrado
23011	Informe de investigación lacrado
23012	Informe de investigación lacrado
23013	Informe de investigación lacrado
23014	Iblis, Hoja del serafín caído
23015	Jaula de ratas
23016	Informe de investigación lacrado
23017	Velo de eclipse
23018	Sello del Defensor caído
23019	Casco Deliriohelado
23020	Casco polar
23021	Las ataduras del cosechador de almas
23022	Pago de cascarrabias
23023	Collar de sádico
23024	Documentación de instrucción de campo lista
23025	Sello del condenado
23027	Calor de Perdón
23028	Sortija de granizo
23029	Corazón gélido de Noth
23030	Capa de la Plaga
23031	Sortija de lo Inevitable
23032	Ornato glacial
23033	Almófar de escamas heladas
23034	Nax PH Crit Plate Shoulders
23035	Sombrero de preceptor
23036	Collar de Necropsia
23037	Anillo de fervor espiritual
23038	Sortija de fuerzas antinaturales
23039	El Ojo de Nerub
23040	Glifo de Desvío
23041	Blasón de destripador
23042	Reflejo de Loatheb
23043	La cara de la Muerte
23044	Presagista de la Fatalidad
23045	Embozo de Dominio
23046	La esencia contenida de Sapphiron
23047	Ojo de los muertos
23048	Ojo derecho de Sapphiron
23049	Ojo izquierdo de Sapphiron
23050	Capa de la Necrópolis
23053	Dije iracundo de Tempestira
23054	Gressil, Alba de la Ruina
23055	Palabra de deshielo
23056	Martillo de El Vacío Abisal
23057	Gema de Inocentes atrapados
23058	Collar de mediación de vida
23059	Anillo de acorator
23060	Anillo Segahuesos
23061	Anillo de fe
23062	Anillo de Fuego de Escarcha
23063	Anillo corazón de peste
23064	Anillo del Caminasueños
23065	Anillo del Apocalíptico
23066	Anillo de redención
23067	Anillo de acechacriptas
23068	Quijotes de Matanza
23069	Atuendo de necrocaballero
23070	Leotardos de polaridad
23071	Leotardos de Apocalipsis
23072	Puños del Inflexible
23073	Botas de desplazamiento
23075	Acuerdo con la Muerte
23078	Guanteletes de matanza de no-muertos
23081	Manijas de matanza de no-muertos
23082	Manoplas de matanza de no-muerto
23083	Llama presa
23084	Guantes de eliminación de no-muertos
23085	Toga de eliminación de no-muertos
23087	Coraza de matanza de no-muertos
23088	Coselete de matanza de no-muertos
23089	Guerrera de matanza de no-muertos
23090	Brazales de matanza de no-muertos
23091	Brazales de eliminación de no-muertos
23092	Guardamuñecas de matanza de no-muertos
23093	Cubremuñecas de matanza de no-muertos
23122	Piedra de afilar consagrada
23123	Aceite de zahorí bendito
23124	Bastón de Balzaphon
23125	Cadenas del Exánime
23126	Pretina de Balzaphon
23127	Capa de Revanchion
23128	La garra de las Sombras
23129	Brazales de alivio
23132	Hoja de Lord Bosque Negro
23139	Rodela de Lord Bosque Negro
23156	Muslo de Bosque Negro
23160	Pan de la amistad
23161	Limonada fresca
23162	Una bolsa muy grande
23163	Performer's Wand
23164	Bubbly Beverage
23168	Daga focal de Desdén
23169	Gargantilla helada de Desdén
23170	La garra helada
23171	El hacha de extirpación
23172	Refreshing Red Apple
23173	Leotardos de piel de abominación
23175	Tasty Summer Treat
23176	Fizzy Energy Drink
23177	Dedo de Lady Falther'ess
23178	Manto de Lady Falther'ess
23179	Llama de Orgrimmar
23180	Llama de Cima del Trueno
23181	Llama de Entrañas
23182	Llama de Ventormenta
23183	Llama de Forjaz
23184	Llama de Darnassus
23192	Tabardo de la Cruzada Escarlata
23193	Riendas de corcel esquelético
23194	Marca del Alba inferior
23195	Marca del Alba
23196	Marca del Alba superior
23197	Ídolo de la Luna
23198	Ídolo de Brutalidad
23199	Tótem de la Tormenta
23200	Tótem de apoyo
23201	Tratado sobre divinidad
23203	Tratado sobre fervor
23206	Marca del Campeón
23207	Marca del Campeón
23211	Esmorc tostado
23215	Bolsa de ingredientes esmorc
23219	Faja del Mentor
23220	Toga tejida con cristal
23221	Servobrazo mal colocado
23224	Summer Gift Package
23226	Guerrera de piel de necrófago
23227	iCoke Gift Box Voucher
23237	Anillo de la llama eterna
23238	Rodela estigia
23242	Garra de vermis de escarcha
23243	Sobrehombros de placas de Campeón
23244	Yelmo de placas de Campeón
23246	Brebaje festivo ígneo
23247	Flores ardientes
23250	Concha centelleante
23251	Yelmo de anillas de Campeón
23252	Sobrehombros de anillas de Campeón
23253	Protegecabezas de pellejo de dragón de Campeón
23254	Sobrehombros de pellejo de dragón de Campeón
23255	Capucha de tejido de tinieblas de Campeón
23256	Bufas de tejido de tinieblas de Campeón
23257	Yelmo de cuero de Campeón
23258	Sobrehombros de cuero de Campeón
23259	Protegecabezas de malla de Campeón
23260	Espaldares de malla de Campeón
23261	Caperuza de satén de Campeón
23262	Manto de satén de Campeón
23263	Capucha de seda de Campeón
23264	Manto de seda de Campeón
23272	Coraza de láminas de Capitán caballero
23273	Leotardos de láminas de Capitán caballero
23274	Guanteletes de láminas de Teniente caballero
23275	Escarpes de láminas de Teniente caballero
23276	Protegecabezas de láminas de Teniente coronel
23277	Sobrehombros de láminas de Teniente coronel
23278	Grebas de anillas de Teniente caballero
23279	Abrazaderas de anillas de Teniente caballero
23280	Mandiletes de pellejo de dragón de Teniente caballero
23281	Botines de pellejo de dragón de Teniente caballero
23282	Manijas de tejido de tinieblas de Teniente caballero
23283	Botos de tejido de tinieblas de Teniente caballero
23284	Mandiletes de cuero de Teniente caballero
23285	Botos de cuero de Teniente caballero
23286	Guanteletes de placas de Teniente caballero
23287	Grebas de placas de Teniente caballero
23288	Manijas de satén de Teniente caballero
23289	Botos de satén de Teniente caballero
23290	Manijas de seda de Teniente caballero
23291	Botos de seda de Teniente caballero
23292	Camisote de anillas de Capitán caballero
23293	Musleras de anillas de Capitán caballero
23294	Pechera de pellejo de dragón de Capitán caballero
23295	Leotardos de pellejo de dragón de Capitán caballero
23296	Musleras de tejido de tinieblas de Capitán caballero
23297	Guerrera de tejido de tinieblas de Capitán caballero
23298	Pechera de cuero de Capitán caballero
23299	Musleras de cuero de Capitán caballero
23300	Camisote de placas de Capitán caballero
23301	Leotardos de placas de Capitán caballero
23302	Musleras de satén de Capitán caballero
23303	Guerrera de satén de Capitán caballero
23304	Musleras de seda de Capitán caballero
23305	Guerrera de seda de Capitán caballero
23306	Yelmo de anillas de Teniente coronel
23307	Sobrehombros de anillas de Teniente coronel
23308	Protegecabezas de pellejo de dragón de Teniente coronel
23309	Sobrehombros de pellejo de dragón de Teniente coronel
23310	Capucha de tejido de tinieblas de Teniente coronel
23311	Bufas de tejido de tinieblas de Teniente coronel
23312	Yelmo de cuero de Teniente coronel
23313	Sobrehombros de cuero de Teniente coronel
23314	Yelmo de placas de teniente coronel
23315	Sobrehombros de placas de Teniente coronel
23316	Caperuza de satén de Teniente coronel
23317	Manto de satén de Teniente coronel
23318	Capucha de seda de Teniente coronel
23319	Manto de seda de Teniente coronel
23320	Tablilla de Choque de llamas VI
23323	Corona del Festival del Fuego
23324	Manto del Festival del Fuego
23326	Salchicha de solsticio de verano
23327	Pan tostado
23360	Cabeza de Instructor Razuvious
23379	Brazales de ceniza
23435	Tarta de bayas de saúco
23451	Hoja de mago de Gran mariscal
23452	Escrito sobre poder del Gran Mariscal
23453	Escrito sobre restauración del Gran Mariscal
23454	Martillo de guerra de Gran Mariscal
23455	Demoledor de Gran mariscal
23456	Hoja presta de Gran Mariscal
23464	Maza de batalla de Gran Señor de la Guerra
23465	Destructora de Gran Señor de la Guerra
23466	Hoja de hechizo de Gran Señor de la Guerra
23467	Hoja rauda de Gran Señor de la Guerra
23468	Escrito sobre destrucción del Gran Señor de la Guerra
23469	Escrito sobre Alivio del Gran Señor de la Guerra
23545	Poder de la Plaga
23547	Temple de la Plaga
23548	Poderío de la Plaga
23549	Entereza de la Plaga
23557	Larva del Gran Gusano
23558	La coraza del perforador
23570	Jom Gabbar
23577	El frío voraz
23578	Dieta MacSalsafloja
23579	El clásico MacSalsafloja
23663	Faja de la furia elemental
23664	Espaldares de la furia elemental
23665	Leotardos de la furia elemental
23666	Cinturón del Gran Cruzado
23667	Bufas del Gran Cruzado
23668	Leotardos del Gran Cruzado
23683	Pastilla para la garganta Copo de cristal
23684	Venda de cristal imbuido
23689	Manual: Venda de cristal imbuido
23690	Receta: Pastilla para la garganta Copo de cristal
23705	Tabardo de las llamas
23709	Tabardo de Escarcha
23710	Tabardo de Upperdeck n.º 3
23712	Cachorro de tigre blanco
23713	Prole de hipogrifo
23714	Fuegos artificiales morados perpetuos
23715	Cóctel de zumo de pulmón perpetuo
23716	Ídolo de ogro tallado
23718	Polvo de scorpok machacado permanente
23719	Compuesto de córtex cerebral permanente
23720	Tortuga de montar
23721	Chicle permanente de mollejas
23722	IFRDHR permanente
23794	Brillo permanente de Zanza
23795	Espíritu permanente de Zanza
23796	Presteza permanente de Zanza
24071	Daga insulsa
24101	Libro de Mordedura feroz V
24102	Manual de Eviscerar IX
24222	El Apuñalador de Sombrapiés
24231	Rapé burdo
24232	Nudo gastado
24281	Hueso tallado de marfil
24282	Diario de un pícaro
24283	Un arma solariega
122270	Ficha de WoW
122284	Ficha de WoW
172070	Botiquín de atención al cliente
180089	Collera de panda
184937	Desplazador de cronobeneficios
184938	Desplazador de cronobeneficios supercargado
189419	Fire Resist Plate Gear
189420	Fire Resist Plate Gear
189421	Fire Resist Leather Gear
189426	Raid Consumables
189427	More Raid Consumables
190179	Corazón de Avelina
190180	Corazón de Isaac
190181	Corazón de los amantes
190186	Figurilla de madera
190187	Bufanda desgastada
190232	Bufanda desgastada
190307	Antorcha apagada
190308	Antorcha ardiente
190309	Figurilla de madera
191204	Piedra de muerte inferior
191249	Piedra de muerte superior
191267	Runa de teletransporte: Antecámara
191268	Orbe de corrupción
191272	Vara de Nigromancia
191280	Cúmulo de esporas fúngicas
191288	Runa de teletransporte: Guarida de vermis de escarcha
191292	Daga ritual
191312	Filacteria infalible
191313	Máscara de muerte
191414	Artefacto esquelético
191458	Filacteria destrozada
191459	Runa de fortuna
191477	Palenque esquelético
191480	Corcel esquelético
191481	Tabardo de maestría
191550	Libro de piedras de muerte: Máscara de muerte
191605	Libro de piedras de muerte: Runa de teletransporte I
191606	Libro de piedras de muerte: Orbe de corrupción
191607	Libro de piedras de muerte: Artefacto esquelético
191608	Libro de piedras de muerte: Vara de Nigromancia
191609	Libro de piedras de muerte: Cúmulo de esporas fúngicas
191610	Libro de piedras de muerte: Daga ritual
191611	Libro de piedras de muerte: Filacteria infalible
191612	Libro de piedras de muerte: Runa de teletransporte II
191613	Libro de piedras de muerte: Runa de fortuna
191614	Libro de piedras de muerte: Palenque esquelético
191656	Esencia de la muerte
191660	Descargas de relámpagos de Thaddius
191661	Colmillo de araña monstruoso
191664	Libro de piedras de muerte: Descargas de relámpagos de Thaddius
191666	Libro de piedras de muerte: Colmillo de araña monstruoso
202251	Bolsa de golosinas para mascotas
202254	Brazales de reorientación
202256	Pistola ornamentada de corsario
202641	Cuaderno cubierto de barro
203723	Nota de Navajín
203726	Runa de Navajín
203745	Notas de hechizo: Lanza de hielo
203746	Notas de hechizo: Llama viva
203747	Notas de hechizo: Dedos de escarcha
203748	Notas de hechizo: Incendio
203749	Notas de hechizo: Esclarecimiento
203750	Mapa del tesoro de Elwynn
203751	Notas de hechizo: ALZO EN HIELAD
203752	Notas de hechizo: MALVA VALI
203753	Notas de hechizo: DASCAC HEDED SEOR
203754	Archimago Antonidas: La autobiografía completa
203755	Diario de investigación del archimago Theocritus
203756	Nota de aprendiz de Azora: página 1
203784	Trozo superior derecho de mapa
203785	Trozo superior izquierdo de mapa
203786	Trozo inferior derecho de mapa
203787	Trozo inferior izquierdo de mapa
203960	Nota de aprendiz de Azora: página 2
203961	Nota de aprendiz de Azora: página 3
203962	Nota de aprendiz de Azora: página 4
203990	Runa de Mutilación
203991	Runa de Desenfunde rápido
203992	Runa de Artimaña
203993	Runa de Masacre
203994	Runa de Brebaje letal
204174	Runa de Precisión
204270	Núcleo de las profundidades
204441	Runa de Frenesí sangriento
204476	Cabeza de kóbold cortada
204477	Cabeza de múrloc cortada
204478	Cabeza de gnoll cortada
204688	Primer fragmento de runa de cazador de monstruos
204689	Segundo fragmento de runa de cazador de monstruos
204690	Tercer fragmento de runa de cazador de monstruos
204703	Runa de Devastar
204716	Runa de Asalto frenético
204795	Runa de Golpesombra
204804	Brazaletes de Hydraxis
204806	Runa de Ataque de la victoria
204807	Espada de las profundidades
204809	Runa de Rayo furioso
204864	Nota de aprendiz de Azora
204905	Escrito ominoso
204906	Sangre de gnoll
204907	Mandíbula de lobo
204912	Runa de Gracia
205019	Fragmento de alma contaminado
205020	Fragmento de alma pura
205022	Runa de Succión de alma
205181	Artefacto sin identificar
205182	Artefacto sin energía
205183	Artefacto alimentado con energía vil
205184	Nota de acólito
205215	Runa de Tácticas
205218	Tratado sobre descubrimiento
205228	Runa de Descarga de caos
205230	Runa de Posesión
205364	Morral de acólito
205420	Tratado sobre sentencia
205683	Runa de Reprimenda
205685	Runa de Égida
205863	Tratado corrupto
205864	Nota chamuscada
205897	Runa de Luz divina
205905	Recuerdo de un campeón devoto
205932	Profecía de la muerte de un rey
205940	Recuerdo de un propósito oscuro
205942	Epifanía quimérica
205943	Profecía de una ciudadela profanada
205944	Epifanía recíproca
205945	Recuerdo de un salvador encerrado
205946	Recuerdo de la traición de un líder
205947	Profecía de una ciudadela profanada
205948	Epifanía anodina
205949	Epifanía múltiple
205950	Epifanía tenebrosa
205951	Recuerdo de un acólito atribulado
205952	Recuerdo de un mundo devastado
205953	Profecía de juramento roto
205961	Carne de ave de Mulgore
205979	Runa de Flanqueo
205995	Almizcle de perro de la pradera
206032	Runa de Cuchillada
206155	Runa de Puntería
206157	Carga minera de seforio
206159	Disfraz de Ventura y Cía.
206168	Runa de Quimera
206169	Runa de Disparo explosivo
206170	Cono de viento furioso
206175	Bálsamo de pino
206176	Mortero y majadero
206177	Mantequilla de piñones
206264	Runa de Inspiración
206344	Conjunto de cuchillos
206345	Trozos de pescado
206376	Ícono de baluarte
206381	Ícono diádico
206382	Ícono de tempestad
206383	Ícono lítico
206384	Ícono astral
206385	Ícono clástico
206386	Ícono galvánico
206387	Ícono kajárico
206388	Ícono sulfúrico
206389	Ícono de azufre
206390	Ícono ictíneo
206391	Ícono de Syzygic
206466	Corona de la pradera
206469	Flor de la pradera
206954	Ídolo de cólera osuna
206963	Runa de Potencial natural
206966	Bulbo de herbasátiro
206970	Runa de Vida
206975	Llave del depósito de artefactos
206985	Eco del alfa
206989	Runa del Sol
206992	Runa de Testarazo
206994	Cabeza de jabaespín cortada
206995	Cabeza de arpía cortada
207062	Cabeza de centauro cortada
207098	Nota de Ba'so
207106	Trozo inferior izquierdo de mapa
207107	Trozo inferior derecho de mapa
207108	Trozo superior izquierdo de mapa
207109	Trozo superior derecho de mapa
207110	Mapa del tesoro de Durotar
207590	Carne de cerdo de Durotar
207631	Feromona de víboris
207731	Escrito ominoso
207732	Pata de makrura
207733	Cráneo kultirano
207972	Las enseñanzas de Ta'zo
207973	Hueso de mandíbula de sabueso
207974	Escrito ominoso
207975	Cabeza de murciélago cortada
208005	Llave de cofre de reliquias de Agamand
208007	Llave de alijo de naufragio
208034	Mapa del tesoro de Tirisfal
208035	Trozo superior derecho de mapa
208036	Trozo superior izquierdo de mapa
208037	Trozo inferior derecho de mapa
208038	Trozo inferior izquierdo de mapa
208085	Sello de teniente escarlata
208086	Memorándum Escarlata falsificado
208139	Escrito ominoso
208140	Sangre de wendigo
208158	Corazón de trogg prístino
208159	Cabeza de trol cortada
208160	Pata de wendigo cortada
208180	Almizcle de conejo
208183	Notas de boticario
208185	El manual de la metafísica del boticario
208192	Carne de cerdo de Dun Morogh
208196	Sortija moa'kin
208205	Nota de Ratanegra
208213	Trozo superior derecho de mapa
208215	Trozo superior izquierdo de mapa
208218	Trozo inferior derecho de mapa
208219	Trozo inferior izquierdo de mapa
208220	Mapa del tesoro de Dun Morogh
208222	Vindicadora del viejo guardia
208223	Morral de acólito
208224	Nota de acólito
208414	Ídolo lunar
208425	Vestigio arcaico brillante
208484	Luz solar
208601	Trozo superior derecho de mapa
208602	Trozo superior izquierdo de mapa
208603	Trozo inferior derecho de mapa
208604	Trozo inferior izquierdo de mapa
208605	Mapa del tesoro de Teldrassil
208607	Almizcle de ciervo
208608	Carne de ave de Teldrassil
208609	Flor del prado
208610	Cabeza de búho cortada
208611	Cabeza de tigre cortada
208612	Cabeza de araña cortada
208682	Huevo de quijaforte abandonado
208687	Runa de Lacerar
208689	Ídolo feroz
208701	Runa de Maestría de bestias
208739	Estandarte de guerra de la Horda
208741	Runa de Ira infinita
208743	Alma de codicia
208744	Runa de Descargas de las Sombras
208749	Llave de alijo tuercepinos
208750	Runa de Mediación
208753	Notas de hechizo: Regeneración
208754	Notas de hechizo: RANGE CERNEIO
208758	Runa terránea
208760	Corona del prado
208764	Runa de la Mente
208765	Mano servicial
208766	Mano servicial
208767	Runa de Alivio
208768	Caja de fósforos de bucanero
208771	Runa de Danza de hojas
208772	Runa de Sablazo
208773	Arpón de pesca
208777	Runa del Francotirador
208778	Runa de Golpe rápido
208799	Notas de hechizo: Bomba viva
208800	Baxtan: Tratado de magias destructivas
208823	Moneda de ofrenda
208828	Recuerdo de un juramento roto
208833	Pastel malévolo
208838	Arcón de Hierro Negro
208843	Tótem de batalla
208847	Geoda con forma de cráneo
208848	Geoda con forma de cráneo partida
208849	Tratado sobre bendiciones
208851	Tratado sobre justicia
208853	Notas de hechizo: Congelación cerebral
208854	Notas de hechizo masticadas
208855	Carnada de atún blanco arco iris
208860	Rumi de Gnomeregan: Obras completas
209027	Bocados de cangrejo
209028	Notas de hechizo: OVMA BIVAB
209029	Mensaje de Emily
209030	Llave de alijo con equipamiento
209031	Sobre discreto
209041	Semillas de calabaza mágica
209042	Harina de hueso de pescado
209043	Muestra de tierra fértil
209045	Alma del mar
209047	Arpón nudoso
209056	Piezas de repuesto de segador
209057	Prototipo de motor
209058	Núcleo elemental
209059	Anca de dentosangre
209418	Armadura tortuga adamantina
209420	Azotebranquias
209421	Cordón de Aquanis
209422	Gargantilla de marea alta
209423	Bufanda ondeante
209424	Barrera de placas de caparazón
209432	Cincho de Ghamoo-ra
209436	Diente roto de Serra'kis
209523	Manteo de trillador fulgurante
209524	Ataduras de Serra'kis
209525	Talwar aguaoscura afilado
209527	Guanteletes de batalla naga
209534	Arbalesta azshari
209559	Cachava de sabio del crepúsculo
209560	Martillo de sentencia recta
209561	Vara del insomne ancestral
209562	Golpe mortal de la hidra
209563	Desgarracorazones naga
209564	Tridente de guardián
209565	Sortija de lugares profundos
209566	Leotardos de los fieles
209567	Hacha de arrecife de corales
209568	Guanteletes de algas
209569	Botas altas de pellejo de múrloc
209570	Tomo de conocimiento de la caverna
209571	Luz mortecina
209572	Cueros hervidos negros
209573	Aguja colérica
209574	Doctrina descartada de la Mano de Plata
209575	Ícono de madera a la deriva tallada
209576	Champiñón expandementes
209577	Puño de lo salvaje
209578	Bandas de cuero resplandecientes
209579	Trueno aplastante
209580	Racha de viento
209581	Escarpes de la Mano de Plata
209590	Globo de agua rajado
209608	Llave esqueleto del capitán
209611	Insignia de la Alianza
209612	Insignia de la Alianza
209613	Insignia de la Alianza
209614	Insignia de la Alianza
209615	Insignia de la Alianza
209616	Insignia de la Alianza
209617	Insignia de la Alianza
209618	Insignia de la Alianza
209619	Insignia de la Horda
209620	Insignia de la Horda
209621	Insignia de la Horda
209622	Insignia de la Horda
209623	Insignia de la Horda
209624	Insignia de la Horda
209625	Insignia de la Horda
209626	Insignia de la Horda
209667	Leotardos de soñador de mirada
209668	Sello del señor crepuscular
209669	Zapatos de invocador crepuscular
209670	Pisapieles
209671	Togas de invocador crepuscular
209672	Guantes sin dedos negros
209673	Amuleto de fetiche brillante
209674	Encendedora de fénix
209675	Guerrera hiloalmeja
209676	Guardahombros de profundidades aplastantes
209677	Aro de corrientes prestas
209678	Manto del asesino de trilladores
209679	Hombreras de novato azshari
209680	Bufanda impermeable
209681	Huevo de múrloc negro
209682	Capucha robusta
209683	Chal de invocador crepuscular
209684	Pantalones de robaalmas
209685	Cincho musgoso ancestral
209686	Collar de hueso dentado
209687	Loriga de pellejo de hidra
209688	Trabuco de Bael Modan
209689	Botas de pesca de caparazón de cangrejo
209690	Almófar sombriescamas
209691	Cuchillo de bota vampírico
209692	Espaldares de centinela
209693	Perla Brazanegra perfecta
209694	Daga ritual brazanegra
209748	Orbe de Althalaxx
209778	Sal de invocador
209779	Mota de Mannoroth
209800	Fragmentos de orbe
209816	Fetiche de travesuras
209817	Broche de abisario
209818	Media luna tocada por el sol
209819	Varita de adiestración de dracoleones
209820	Gargantilla de sudario negra
209821	Anillo de visión sombría
209822	Fuerza de propósito
209823	Sello de bestias
209824	Hombreras fulgurantes
209825	Gargantilla de gotas
209828	Espaldares bajo cero
209830	Arbalesta pielférrea
209836	Orbe de Althalaxx
209838	Cristal hipnótico
209840	Varita de magia silvestre nudosa
209841	Esencia de magia salvaje
209843	Almanaque de Nar'thalas, vol. 74
209844	El compendio de Dalaran, vol. 23
209845	Hechizos y encantamientos
209846	Secretos de los soñadores
209847	Manual de sistemas arcánicos
209848	Pergaminos Goaz
209849	Crímenes contra la anatomía
209850	Runa de los Reyes hechiceros
209851	Furia de la tierra
209852	Runa de Matar
209872	Yelmo de matadragones
209873	Escudo de matadragones
209874	Lanza de matadragones
210015	Runa de Arremetida enfurecida
210026	Símbolo del tercer búho
210043	Símbolo del segundo búho
210044	Símbolo del primer búho
210045	Sombrahoja
210053	Pata de lobo temible
210055	Huesos de humano de Trabalomas
210056	Tintura de muerte andante
210080	Ofrenda vudú
210137	Runa de Crecimiento salvaje
210138	Artillería Hierro Negro
210146	Turbocargador de trituradora
210147	Unidad de autorreciclaje de trituradora
210177	Ataeric: Tratado de curiosidades arcanas
210178	Esquema: Unidad de autorreciclaje de trituradora
210179	Notas de hechizo: ILMEGAI SARRBES
210183	Cuerno de Xelthos
210186	Carga destructora
210187	Pedido de Ventura y Cía.
210188	Pedido desgarrado
210195	Ídolo desequilibrado
210209	Llave gemela
210210	Certificado de fundador de Industrias Defensivas Grizzwerks
210212	Media llave de hermano
210213	Media llave de hermana
210229	Runa de Mutilación
210250	Anillo de oro con inscripción
210251	Anillo de plata con inscripción
210252	Runa de Puyazo
210253	Tótem de podredumbre
210322	Runa de Veneno
210323	Combinación de caja fuerte
210329	Mapa del tesoro de Trabalomas
210330	Información valiosa
210410	Cebo de mordedor de agua fresca
210499	Champiñón de pantano
210500	Runa de las Estrellas
210534	Ídolo de las fieras
210568	Filacteria decrépita
210569	Runa de Flagelación
210573	Runa de Ira acuciante
210589	Eco de los ancestros
210596	Runa de Golpes de cobra
210653	Runa de Guardamano
210654	Notas de hechizo: Retroceder el tiempo
210655	Notas de hechizo: MERLONECTEOR PERDIETE
210665	Mota de ira torrencial
210667	Mota de ira infernal
210668	Mota de ira sísmica
210696	Azote de podredumbre
210708	Elixir de remordimientos fusionados
210709	Receta: Elixir de remordimientos fusionados
210712	Elixir de conocimiento
210713	Alma torturada
210724	Bastón de Hirzek
210741	Moledora automática de muchedumbre
210746	Runa de Escudo de tierra
210763	Rama de Altek
210765	Orbe de Des
210771	Suministros faltantes: Barras de cobre
210772	Cargamento de suministros: Barras de cobre
210773	Manto de la Segunda Guerra
210779	Diseño: Manto de la Segunda Guerra
210781	Ataduras de fénix
210794	Coraza de plata cambiante
210795	Botas de seda de araña extrabidimensionales
210811	Runa de Furia primordial
210817	Runa de Supervivencia
210818	Runa de Lobo solitario
210820	Runa de Sacrificio
210822	Epifanía armoniosa
210823	Runa de Especialización en doble empuñadura
210824	Runa del Pacto
210825	Runa del Belisario
210953	Ojo de Bhossca
210955	Uniforme de iniciado Escarlata
210963	Llave del arúspice
210966	Sangre de la Legión
210967	Mensaje confidencial
210968	Llave de relicario
210979	Runa de Paso de las sombras
210980	Runa de Metamorfosis
211205	Runa de Matacobras
211247	Patrón: ataduras de fénix
211263	Coselete de sentencia
211269	Ilustración primitiva
211301	Runa de Exponer debilidad
211315	Suministros faltantes: Cuero ligero
211316	Suministros faltantes: Flor de paz
211317	Suministros faltantes: Hojaplata
211318	Suministros faltantes: Pociones de sanación menores
211319	Suministros faltantes: Espadas cortas de cobre
211320	Suministros faltantes: Pantalones rúnicos de cobre
211321	Suministros faltantes: Varitas mágicas inferiores
211322	Suministros faltantes: Aceite de zahorí menor
211323	Suministros faltantes: Bombas de cobre férreas
211324	Suministros faltantes: Bocardas férreas
211325	Suministros faltantes: Cinturones de cuero cosidos a mano
211326	Suministros faltantes: Jubón de cuero estampado
211327	Suministros faltantes: Pantalones de lino marrones
211328	Suministros faltantes: Togas de lino marrones
211329	Suministros faltantes: Huevos a las finas hierbas
211330	Suministros faltantes: Carne de lobo especiada
211331	Suministros faltantes: Pececito luminoso
211332	Suministros faltantes: Vendas de lino gruesas
211365	Cargamento de suministros
211367	Cargamento de suministros
211368	Cargamento de suministros
211382	Bolsa de cartero pequeña
211384	Bolsa de cartero resistente
211385	Runa de Propagación serpentina
211386	Notas de hechizos: Oleada Arcana
211387	Runa de Luz de conocimiento
211390	Runa de Heridas superficiales
211391	Runa de Lluvia de sanación
211392	Runa de Aflicción eterna
211393	Runa de Furia enfilada
211419	Montón de escamas cambiantes
211420	Dije de escamas cambiantes
211421	La caja
211422	Fragmento del Vacío
211423	Guantes de cuero tocados por el Vacío
211427	Recipiente de alma
211443	Hoja de ira
211444	Capa de invocador
211445	Arco recurvo bárbaro
211447	Cargamento de armas
211448	Contrato de compra firmado
211449	Perla del Vacío de vengador
211450	Perla del Vacío de invocador
211451	Perla del Vacío de acólito
211452	Perla Brazanegra perfecta
211454	Globo de agua extraño
211455	Guantes sin dedos hábiles
211456	Daga de sacrificio voluntario
211457	Faja de defensor del crepúsculo
211458	Escrito de amparo contra las Sombras
211460	Rodela ártica ancestral
211461	Cetro de lápida grabada
211462	Anillo de apoyo eterno
211463	Broches de alfazaque estridente
211464	Manteo de prelación usado
211465	Botas Nimbus de perspicacia
211466	Faja de duramen del amable
211467	Sortija del puño de hierro
211468	Manto de castaño raído
211471	Llave Fonroca
211472	Tratado sobre destierro
211476	Runa de Estela de fuego
211477	Runa de Incineración
211482	Ofrenda Rompelanzas
211487	Explosivos para demoliciones
211488	Runa de Vengador
211490	Profecía de las mil luces
211491	Bolsa de piel de múrloc sin fondo
211492	Cartera de Kelris
211498	Sable de la noche de las centinelas de aprendiz
211499	Lobo escolta de aprendiz
211500	Cinta de tela resiliente
211501	Coselete de poder
211502	Guanteletes de cuero tocados por el Vacío
211504	Anillas de vengador crepuscular
211505	Yelmo de vengador crepuscular
211506	Botas de vengador crepuscular
211507	Capucha de elementalista crepuscular
211508	Escarpines de elementalista crepuscular
211509	Toga de elementalista crepuscular
211510	Capucha de destripador crepuscular
211511	Escarpines de destripador crepuscular
211512	Guerrera de destripador crepuscular
211514	Notas de hechizo: Regeneración en masa
211527	Bolsa de dormir acogedora
211528	Perspicacia oscura
211530	Profecía de una ciudad cautivada
211531	Profecía de los siete visitantes
211534	Perspicacia primigenia
211691	Notas de hechizo: Explosión Arcana
211777	Manuscrito naga
211779	Talismán de comprensión
211780	Pergamino: KWYJIBO
211784	Pergamino: WUBBA WUBBA
211785	Pergamino: CWAL
211786	Scroll: CHAP BALK WELLES
211787	Pergamino: MENOS MARCA CUALQUIERA
211789	Capucha de Artemisa
211799	Saco de bienes robados
211800	Pergamino de reintegración
211809	Manual de comprensión
211813	Talismán de centinela Ala de Plata
211814	Marca de escolta Grito de Guerra
211815	Himno de batalla Ala de Plata
211816	Tambor de batalla Grito de Guerra
211818	Globo de agua extraño
211819	Suministros faltantes: Barras de bronce
211820	Suministros faltantes: Barras de plata
211821	Suministros faltantes: Cuero medio
211822	Suministros faltantes: Hierba cardenal
211823	Suministros faltantes: Cardopresto
211824	Suministros faltantes: Pociones de maná inferiores
211825	Suministros faltantes: Botas de bronce férreas
211826	Suministros faltantes: Llaves esqueleto de plata
211827	Suministros faltantes: Varas rúnicas de plata
211828	Suministros faltantes: Aceite de maná menor
211829	Suministros faltantes: Bombas de bronce pequeñas
211830	Suministros faltantes: Catalejos ornamentados
211831	Suministros faltantes: Capas de cuero oscuro
211832	Suministros faltantes: Sobrehombros de montañero
211833	Suministros faltantes: Camisas de lana gris
211834	Suministros faltantes: Capa con broche de perlas
211835	Suministros faltantes: Sabiola ahumada
211836	Suministros faltantes: Carne de oso ahumada
211837	Suministros faltantes: Almejas picantes a la goblin
211838	Suministros faltantes: Vendas de lana gruesas
211839	Cargamento de suministros
211840	Cargamento de suministros
211841	Cargamento de suministros
211842	Gorro de pensar raído de Rakkamar
211843	Máscara de desdén
211845	Piedra de afilar Brazanegra
211846	Diseño: Piedra de afilar Brazanegra
211848	Aceite de maná Brazanegra
211849	Fórmula: Aceite de maná Brazanegra
211852	Manijas de agua contaminada
211853	Pergamino: VOCE WELL
211854	Pergamino: OMIT KESA
211855	Pergamino: STHENIC LUNATE
211856	Almófar de malla resiliente
211857	Máscara de cuero resiliente
211933	Suministros faltantes: Piedra férrea
211934	Suministros faltantes: Pociones de sanación
211935	Suministros faltantes: Elixir de poder de Fuego
211940	Guardián tribal de Ecks'av
211941	Yari de viajero del viento
211944	Karma de Tojara
211953	Pergamino de recuperación arcana I
211954	Pergamino de precisión arcana I
211955	Pergamino de protección arcana: Fuego I
211956	Pergamino de protección arcana: Escarcha I
211957	Pergamino de poder arcano I
212160	Desplazador de cronobeneficios
212225	Recipiente de alma inagotable
212230	Esquema: Recipiente de alma
212548	Runa de Eclipse
212549	Runa de Trampero
212551	Runa de la Guerra
212552	Epifanía psicosófica
212559	Runa de la Hoja envenenada
212560	Runa de Despertar ancestral
212561	Runa de Oscuridad ardiente
212562	Runa de Ira curativa
212568	Trofeo de cabeza de lobo
212580	Bastón del Tradicionalista
212581	Arco de avanzado
212582	Espada de protector
212583	Hoja de centinela
212584	Bastón nudoso de consejero
212585	Arco de escolta
212586	Espada de Legionario
212587	Hoja de explorador
212588	Guantes de proveedor
212589	Botines de mensajero
212590	Correa de seguridad
212748	Nota raída
212994	Ataduras de trotatormentas
212996	Ataduras de clamarelámpagos
212997	Ataduras de clamamareas
213074	Runa de Revitalización
213086	Runa de la Tormenta
213087	Capa de Sargento
213088	Capa de Sargento
213090	Runa de Sinergia
213093	Runa de Poder
213094	Runa de Nova de fuego
213096	Runa de Señuelos
213098	Runa de Invocación
213100	Runa de Conocimiento prohibido
213101	Runa de Llamas de las sombras
213102	Runa de Perversidad
213103	Runa de Oleada de sangre
213104	Runa de Precisión brutal
213105	Shawarmagedón
213109	Runa de Ira concentrada
213110	Runa del Comandante
213111	Runa de Intervención
213112	Notas de hechizo: Tromba de misiles
213117	Runa de Rabia
213118	Runa del Rey de la selva
213119	Runa de Instinto
213120	Runa del Soñador
213121	Acebo en conserva
213122	Runa de Disparo firme
213123	Runa de Exposición
213124	Runa de Combate cuerpo a cuerpo
213125	Runa de Vigorización
213126	Runa del Desguazador
213127	Notas de hechizo: DEROEB OFNACRÍORA
213128	Runa de Piedad
213129	Runa de Abrazo de la Luz
213130	Runa de Infusiones
213131	Runa de Escudos sacros
213132	Runa de Custodio
213136	Runa de Sutileza
213137	Runa de Atacante
213138	Runa de Pata izquierda
213139	Runa de Asesino
213140	Profecía de la senda acelerada
213141	Runa de Esperanza
213142	Profecía de maldad aprisionada
213143	Epifanía apócrifa
213144	Epifanía luminosa
213165	Los basiliscos y el infundado miedo a la petrificación
213168	Moneda de sangre de cobre
213169	Moneda de sangre de plata
213170	Moneda de sangre de oro
213278	Manoplas de maestro de golpes
213279	Capacete reflectivo
213280	Visor de Tirador
213281	Reactivador de hiperflujo electromagnético
213282	Equipo de innovación hipercargado
213283	Equipo de conflagración hipercargado
213284	Equipo de devastación hipercargado
213285	Ataduras manchadas con aceite de Lev
213286	Aguja de Electrocutor
213287	Hexatuerca de Electrocutor
213288	Guanteletes grasosos de Grubbis
213289	Hidrobastón
213290	Botas ácidas
213291	Desfacedor tóxico II
213292	Gigacortadora Gizmotrón
213293	Superpistola de alta tecnología Mk. VII
213294	Escarpes Cueva Honda
213295	Vibrofilo ultrasónico
213296	Loncheacabezas supercargada
213297	Martillo explosivo oscilante
213298	Mono de mecánico
213299	Pantalones de petróleo
213300	Guantes del mejor piloto
213301	Manto sintético
213302	Manto del negociador astuto
213303	Bufas de pararrayos
213304	Espaldares de matatroggs
213305	Hombreras de aleación mecanizada
213306	Cobertura de ingenuidad
213307	Mantón de desmantelamiento
213308	Prototipo de capa paracaídas
213309	Capa de invención
213310	Camisa resplandeciente hiperconductiva
213311	Toga hiperconductiva
213312	Mandil aislado
213313	Coselete aislado
213314	Malla de anillas electromántica
213315	Camisa de anillas electromántica
213316	Coraza P.E.L.I.G.R.O.
213317	Estabilizadores de puntería experimentales
213318	Brazaletes Hierro Negro ornamentados
213319	Guantes de maquinista
213320	Dedos de Precisión arcana
213321	Cinturón de Brebaje volátil
213322	Pretina de embuste
213323	Cordón de del interior de la tierra
213324	Correa electromagnética
213325	Faja de visión nocturna
213326	Faja de recuperación
213327	Cinturón del rabioso trogg
213328	Bombachos hiperconductivos
213329	Falda hiperconductiva
213330	Quijotes P.E.L.I.G.R.O.
213331	Leotardos aislados
213332	Musleras aisladas
213333	Botarga electromántica
213334	Chaquetón electromántico
213335	Botas P.E.L.I.G.R.O.
213336	Botos hiperconductivos
213337	Sandalias hiperconductivas
213338	Botas de aislamiento electromántico
213339	Escarpes de aislamiento electromántico
213340	Botas de operadores de gnomobots
213341	Botas de trabajo aisladas
213342	Galochas aisladas
213343	Insignia de justicia
213344	Torque de oficial de paz de Gnomeregan
213345	Colgante de pistón
213346	Colgante de regreso a casa
213347	Cámara de combustión miniaturizada
213348	Experimento giromático 420b
213349	Botella de píldoras de gniodino
213350	Núcleo endurecido de Perdal
213351	Escudo pavés irradiado
213352	Gracia del reparador de equipo
213353	Bastón desfibrilador
213354	Bastón del genio malvado
213355	Aguijón de Falco
213356	Desintegrador personalizado de Termochufe
213369	Cuero con resplandor tenue
213370	Restos de cuero irradiado
213371	Cajón de solución de gniodino maculada
213372	Gniodino aislante
213373	Chatarra reflectiva
213376	Placas de veraplata de bajo fondo
213378	Microfilamento inestable
213379	Arcanofilamento hiperconductivo
213381	Pila de engranajes deslustrados
213383	Engranajes de veraplata pulidos
213390	Murotuerca de veraplata giratorio
213407	Hierba gatera
213408	Macroajustador giromático
213409	Arcanotrituradora de Mekkatorque
213410	Dagartilugio destellante
213411	Chispero inextinguible de Fulguizzle
213412	Escudo de seguridad dieléctrico
213413	Hombreras muy acolchadas
213414	Fajín de ensalmador de mecas
213415	Cubremuñecas de manitas
213416	Cuchilla cohete de Termochufe
213417	Almófar de filamento de veraplata
213418	Arandelas soldadas de veraplata
213419	Manual de reparación 9-60
213421	Nota incinerada
213426	Pararrayos de ogro
213427	Reciclaje con mugre incrustada
213442	Garra de maestro de engranajes
213443	Presente que hace "tic, tac"
213452	Runa sagrada inerte
213513	Tratado sobre salvación
213526	Anca híbrida
213527	Mezcla de especias de contrabandista
213528	Brebaje fresco
213529	Toxina viscosa
213542	El Necro-Gnomicón
213543	Pergamino: QUÉONDA
213544	Pergamino: EZFOO KATASI
213545	Pergamino: TOPSE ALTOMIAGU
213546	Pergamino: CUCAMONGA
213547	Pergamino: QÉUSAPEDA
213548	Pergamino de Pasaje liminal
213549	Pergamino de Pesca arcana
213550	Pergamino de Polimorfia: Melón extraño
213551	Pergamino de Desplazamiento controlado
213552	Lágrima de Theradras
213553	Lágrima de Theradras
213554	Vial de agua cristalina
213558	Bálsamo elemental
213559	Palanca de cambios de mecazancudo
213560	Silenciador de mecazancudos
213563	Guía de campo
213564	Pergamino de evocación menor
213565	Kit inicial para entomología
213583	Tallado de azufre
213594	Ídolo del molesto
213599	Visión angustiante
213632	Notas parciales de hechizo
213633	Notas parciales de hechizo
213634	Notas parciales de hechizo
213641	Caja de reciclaje de Gnomeregan
213701	Pluma de arpía fuerte
213709	Colmillo de serpiente nubosa
213735	Procesador de N.Ú.C.L.E.O. G-7 prístino
213736	Procesador de N.Ú.C.L.E.O. G-7 corroído
213737	Ofrenda al espíritu de viento
214435	Llave de jaula de pumas
215111	Monóculo de arcanfilamento gneurovinculado
215114	Almófar de escamas brillantes hiperconductivo
215115	Envoltura dorada hiperconductiva
215129	Fórmula: Encantar arma: Desguarnecer
215138	Fórmula: encantar pechera: Reprentizador
215141	Sigilo encantado: Innovación
215149	Patrón: Monóculo de arcanofilamento gneurovinculado
215152	Patrón: Capucha gneurovinculada con resplandor
215153	Esquema: Murotuerca de veraplata giratorio
215155	Diseño: Yelmo anulainterferencias templado
215156	Esquema: Envoltura dorada hiperconductiva
215162	Poción de rejuvenecimiento levemente irradiada
215163	Receta: Poción de rejuvenecimiento levemente irradiada
215166	Capucha gneurovinculada con resplandor
215257	Pergamino de comprensión
215365	Manto de invocador
215366	Cordón de invocador
215367	Patrón: Cuero con resplandor tenue
215368	Patrón: Arcanofilamento hiperconductivo
215369	Patrón: cordón de invocador
215370	Patrón: manto de invocador
215371	Talismán de Jani
215373	Martillo de entrenamiento de la Mano de Plata
215374	Espada ancestral
215375	Bastón de la estratega
215376	Maza de cruzado
215377	Toga irradiada
215378	Botas irradiadas
215379	Calzas irradiadas
215380	Faja para levantar peso asistida eléctricamente
215381	Caperuza de canalizador gneuroconductiva
215382	Caperuza de escamas resistente a la radiación
215383	Diseño: Cajasesos de veraplata reflectiva
215384	Diseño: Placas de veraplata de bajo fondo
215385	Suministros faltantes: Barras de oro
215386	Suministros faltantes: Barras de mitril
215387	Suministros faltantes: Pellejo pesado
215388	Suministros faltantes: Cuero grueso
215389	Suministros faltantes: Pálida
215390	Suministros faltantes: Mostacho de Khadgar
215391	Suministros faltantes: Invernalia
215392	Suministros faltantes: Lotos cárdenos
215393	Suministros faltantes: Pociones de sanación superior
215394	Suministros faltantes: Pociones de escudo de piedra inferior
215395	Suministros faltantes: Elíxires de agilidad
215396	Suministros faltantes: Elíxires de defensa superior
215397	Suministros faltantes: Hachas de hierro macizo
215398	Suministros faltantes: Brazales de hierro verdes
215399	Suministros faltantes: Guanteletes de mitril pesado
215400	Suministros faltantes: Piedras de pulir sólidas
215401	Suministros faltantes: Juegos de segador de la cosecha compactos
215402	Suministros faltantes: Bombas de hierro grandes
215403	Suministros faltantes: Miras mortales
215404	Suministros faltantes: Trabucos de mitril
215405	Suministros faltantes: Botas cohete gnómicas
215406	Suministros faltantes: Morteros goblin
215407	Suministros faltantes: Sobrehombros barbáricos
215408	Suministros faltantes: Guantes de guardián
215409	Suministros faltantes: Brazales de escamas de tortuga
215410	Suministros faltantes: Cinturones oscurecidos
215411	Suministros faltantes: Capas de cuero de Escarcha
215412	Suministros faltantes: Guantes sombradermos
215413	Suministros faltantes: Camisas blancas formales
215414	Suministros faltantes: Bombachos de seda carmesíes
215415	Suministros faltantes: Camisas de seda morada viva
215416	Suministros faltantes: Máscaras de bandido blancas
215417	Suministros faltantes: Sopa de tortuga reconfortante
215418	Suministros faltantes: Salchichas de araña
215419	Suministros faltantes: Vendas de seda gruesas
215420	Suministros faltantes: Bacalao piedrescama
215421	Suministros faltantes: Aceite de Fuego
215422	Patrón: almófar de escamas brillantes hiperconductivo
215423	Patrón: caperuza de canalizador gneuroconductiva
215424	Patrón: caperuza de escamas resistente a la radiación
215425	Eco del pantano
215426	Eco del cementerio
215427	Eco de Arathi
215428	Eco de Theramore
215429	Esquema: engranajes de veraplata pulidos
215430	Residuos radioactivos de Gnomeregan
215431	Esquema: bomba de radiación de alto rendimiento
215432	Esquema: bomba de radiación para tontos
215433	Receta: gniodino aislante
215435	Tratado sobre oración
215436	Tótem de llama vigorizante
215437	Transfigurador trogg 3000
215441	Martillo roto
215443	Fragmento de orbe destrozado
215444	Monstruo - Maza - Tuberías rotas
215449	Encogemundos
215450	Proyecto de tabardo (Aidan)
215456	Mensaje calcinado
215458	Mensaje cerrado
215459	Mensaje cerrado
215460	Mensaje cerrado
215461	Pollo de ataque domesticado
215468	Órdenes del Gran Cruzado
215683	Geomancia: De rocas y verdades
215815	Magia defensiva I
215816	Una red de mentiras: Toda la verdad sobre los mitos y las leyendas
215817	Los demonios y tú
215820	Momias: Una guía de los no-muertos más espantosos
215822	¡RwlRwlRwlRwl!
215824	Guía de cuidado de mascotas demoníacas para el ludita común
216484	Botas de batalla impactojorfadas
216485	Coraza impactoforjada
216486	Quijotes impactoforjados
216490	ídolo de la cólera
216491	Cargamento de leña de Tuercespina
216492	Silbato del raptor sanguino jaspeado
216494	Tuercemundos extravagante de Aragriar
216495	Trituradora sanguina
216496	Trituracráneos sanguina
216497	Desangrado
216498	Grimorio sanguino encantado
216499	Trituradora sangrecorteza
216500	Talismán arbóreo con juramento de sangre
216501	Barrera tormenta de sangre
216502	Tótem de guerra tormenta de sangre
216503	Joya tormenta de sangre
216504	Sable luz de sangre eclipsado
216505	Radiancia de cruzado luz de sangre
216506	Filo de vengador luz de sangre
216507	Sello de sangre umbrío
216508	Sortija espiral de sangre infernal
216509	Esencia de pacto infernal
216510	Círculo de sangre resonante
216511	Sello de sangrefuego
216512	Aro de venas heladas
216513	Talismán de tigre sangriento
216514	Carcaj sanguino
216515	Faltriquera de munición sanguina
216516	Arco lazo sangriento
216517	Santuario sanguino
216518	Sello de alianza de sangre
216519	Sortija sombra sanguina
216520	Cuchilla cosechasangre
216521	Aporreadores rápidos sanguinos
216522	Estilete salpicado de sangre
216523	Llave de jaula oxidada
216570	Riendas del dientes de sable dorado
216606	Runa de Maestría en dos manos
216607	Ofrenda de luz sanguínea
216608	Reflectores de rayos radiantes
216610	Órdenes del Gran Cruzado
216615	Faro de tormenta de sangre ancestral
216616	Llave de jaula de la base
216617	Uniforme de luchador de Kurzen
216618	Recompensa de la capitana Aransas
216619	Vianda de estudiante
216620	Capa de podrisangre
216621	Mantón empapado de sangre
216622	Capa coagulada
216623	Manteo de hemostasis
216633	Tornapunta de veraplata hidráulica
216634	Fusible GG12-082
216635	Núcleo del vacío gastado
216636	Núcleo del vacío cargado
216637	Una pila de piezas aleatorias
216645	Mota de oscuridad
216646	Cajón misterioso de Ziri
216661	Anillo con mugre incrustada
216662	Anillo de oro luminoso
216673	Anillo de oro luminoso de Talvash
216674	Anillo de oro luminoso de Nogg
216675	Togas civinad prístinas
216676	Peto de corredor veloz
216678	Leotardos triples reforzados
216679	Herramienta de desmantelamiento de Shoni
216680	Manoplas llamativas
216698	Braquiales de pellejo de dragón de Alférez
216699	Guardabrazos de anillas de Alférez
216700	Braquiales de cuero de Alférez
216701	Guardamuñecas de placas de Alférez
216702	Puños de seda de Alférez
216703	Guardamuñecas de malla de Gran capataz
216704	Guardabrazos de pellejo de dragón de Gran capataz
216705	Brazales de placas de Gran capataz
216706	Guardabrazos de cuero de Gran capataz
216707	Puños de seda de Gran capataz
216738	Manual de Redirigir
216740	Tomo de Intelecto expandido
216744	Pergamino de Entereza aumentada
216745	Pergamino de Maligno de las Sombras
216746	Vademécum de Grito de orden
216747	Grimorio de Cosecha de almas
216748	Grimorio de Portal de invocación
216764	Panfleto de Salvajismo dominante
216767	Panfleto de Revivir
216769	Revelación de Proyección totémica
216770	Tratado sobre Aspecto de la víbora
216771	Panfleto de Restauración mejorada
216879	Pergamino trol misterioso
216880	Pergamino trol descifrado
216884	Hoja sedienta de sangre
216914	Mención deslustrada
216918	Botas corazón vil
216919	Fajín corazón vil
216920	Ataduras corazón vil
216921	Mandiletes corazón vil
216922	Corona corazón vil
216923	Leotardos corazón vil
216924	Abrazo corazón vil
216925	Manto corazón vil
216938	Insignia de la Alianza superior
216939	Insignia de la Horda superior
216941	Sigilo de Ariden
216945	Reliquia de Dalaran curiosa
216946	Reliquia de Dalaran resplandeciente
216947	Reliquia de Dalaran zumbante
216948	Reliquia de Dalaran vieja
216949	Reliquia de Dalaran pesada
216950	Reliquia de Dalaran espeluznante
216951	Reliquia de Dalaran resbaladiza
216956	Carta rota
216971	Cartera de monedas de sangre de cobre
216972	Cartera de monedas de sangre de plata
217005	Manteo de mecánico
217006	Martillo de mecánico
217007	Botas sin poder
217008	Pechera sin poder
217009	Piernas sin poder
217014	Bolsa de suministros
217017	¡Torneo de pesca!
217161	Notas de hechizo: PARGESCO RÍA DROFIDE
217244	Patrón: toga de seda carmesí
217245	Toga de seda carmesí
217246	Jubón de tejido mágico negro
217247	Leotardos de tejido mágico negros
217248	Cinturón de seda terránea
217249	Patrón: cinturón de seda terránea
217250	Sobrehombros de seda carmesíes
217251	Patrón: sobrehombros de seda carmesíes
217252	Capa larga de seda
217253	Botas del encantador
217254	Patrón: botas del encantador
217255	Cinturón de seda carmesí
217256	Jubón terráneo
217257	Capucha de encantador
217258	Patrón: capucha de encantador
217259	Máscara de gran vudú
217260	Patrón: máscara de gran vudú
217261	Toga de gran vudú
217262	Patrón: toga de gran vudú
217263	Brazales de cuero de guardián
217264	Patrón: brazales de cuero de guardián
217265	Cinturón de guardián
217266	Patrón: cinturón de guardián
217267	Pantalones de guardián
217268	Coraza de escamas de tortuga
217270	Guantes de escamas de tortuga
217271	Patrón: guantes de escamas de tortuga
217273	Guanteletes de escamas doradas
217274	Diseño: guanteletes de escamas doradas
217275	Botas de escamas doradas
217276	Diseño: botas de escamas doradas
217277	Loriga de escamas doradas
217278	Diseño: loriga de escamas doradas
217279	Almófar de escamas doradas
217280	Diseño: almófar de escamas doradas
217281	Espada ancha de acero lunar
217282	Diseño: espada ancha de acero lunar
217283	Sobrehombros de escamas doradas
217284	Diseño: sobrehombros de escamas doradas
217285	Leotardos de escamas doradas
217286	Diseño: leotardos de escamas doradas
217287	Varita mística superior
217288	Togas del Exánime
217289	Armadura Fríomortal
217290	Ojo resplandeciente de Mordresh
217291	Calavera inerte Mordresh
217292	Fajín de mago de la Muerte
217293	Manteo de araña sedosa
217294	Embozo embalsamado
217295	Varita necrótica
217296	Dije de fragmento fantasmal
217297	Toga de Doan
217298	Manto de Doan
217299	Vara ilusionaria
217300	Sombrero de Melenablanca
217301	Amuleto Triune
217302	Poderío de Mograine
217303	Leotardos tejepiedra
217304	Guantes de Revelosh
217305	Guardabrazos de Revelosh
217306	Botas de Revelosh
217307	Bufas de Revelosh
217308	Sigilo encantado: Innovación
217314	Rifle de vista lunar
217315	Arco de precisión
217337	Cargamento de suministros
217338	Cargamento de suministros
217339	Cargamento de suministros
217345	Veneno sebáceo
217346	Veneno entumecedor
217347	Veneno atrófico
217350	Notas de ingeniería de Termochufe
217351	Notas de ingeniería de Termochufe
217398	Elixir arcano inferior
217399	Receta: elixir arcano inferior
217495	Pergamino de Crioexplosión
217496	Pergamino de la hoja
217497	Espada de Narpas
217609	Talismán de Kazdor
217693	Poción de invisibilidad
217704	Cachiporra de hierro
217717	Emblema hueco
217718	Emblema de magia de sangre
217719	Esencia de magia de sangre
217720	Ofrenda de carne
217721	Ofrenda de hueso
217727	Resguardo de los muertos
217736	Runa del Conventículo
217737	Talismán modificado
219021	Paquete de mensajería pesado
219022	Anillo de transportista
219023	Anillo de empleado
219024	Anillo de mensajero
219135	Colgante de curiosidad
219136	Colgante de tenacidad
219137	Colgante de iniciativa
219147	Runa de Gracia
219223	Furia del maestro del acero
219326	Semilla de renovación
219343	Capucha de ratero
219345	Lazo infernal
219399	Musgo de pesadilla
219401	Mena de hierro fría
219402	Dragontina de toque onírico
219404	Umbriguadaña
219405	Texto de ogro mago
219406	Huevo de dragón verde sin eclosionar
219414	Cáscaras de huevo rotas
219444	Raíz onírica
219445	Polvo de oro de tontos
219446	Dragontina de infusión onírica
219447	Huevo de dragón tocado por el Sueño
219448	Máquina de los sueños
219449	Profecía de Azshara
219454	Loto estelar
219486	Mena de platastral
219487	Astrocaparazón
219488	Huevo de dragón astroungido
219490	Reliquia elunar
219491	Perla onírica
219514	Lunarraíz
219515	Piedra lunar grande
219517	Escama de dragón lunar
219518	Diatriba de arpía
219519	Notas del protector demente
219520	Huevo de dragón de resplandor lunar
219526	Informe de misión: Bosque del Ocaso
219759	Informe de campo de Carla
219770	Informe de campo de Vernon
219771	Informe de campo de Thandros
219772	Informe de campo de Fallia
219773	Informe de misión: Vallefresno
219774	Informe de misión: Tierras del Interior
219775	Informe de misión: Feralas
219776	Informe de inteligencia: Túmulo de Vul'Gol
219778	Informe de inteligencia: El Vergel Pútrido
219803	Informe de inteligencia: Hacienda Yorgen
219918	Misiva sangrienta
219924	Informe de inteligencia: Canción del Bosque
219925	Informe de inteligencia: Satyrnaar
219926	Informe de inteligencia: Aserradero Grito de Guerra
219927	Esquirla esmeralda
219928	Informe de inteligencia: Agol'watha
219929	Misiva sangrienta
219930	Misiva sangrienta
219935	Hoja de Kajind
219937	Informe de inteligencia: Shaol'watha
219938	Informe de inteligencia: Roca Oculta
219957	Informe de inteligencia: Oneiros
219958	Informe de inteligencia: Los Dos Colosos
219959	Informe de inteligencia: Ruinas de Viento Azabache
219962	Incursiones de pesadilla: Misión I del Bosque del Ocaso
219963	Autorización de designación: Misión I de Bosque del Ocaso
219965	Autorización de designación: Misión II de Bosque del Ocaso
219966	Incursiones de pesadilla: Misión II del Bosque del Ocaso
219967	Incursiones de pesadilla: Misión III del Bosque del Ocaso
219968	Incursiones de pesadilla: Misión IV del Bosque del Ocaso
219969	Incursiones de pesadilla: Misión V del Bosque del Ocaso
219970	Incursiones de pesadilla: Misión VI del Bosque del Ocaso
219971	Incursiones de pesadilla: Misión VII del Bosque del Ocaso
219972	Incursiones de pesadilla: Misión VIII del Bosque del Ocaso
219973	Incursiones de pesadilla: Misión IX del Bosque del Ocaso
219974	Incursiones de pesadilla: Misión X del Bosque del Ocaso
219975	Incursiones de pesadilla: Misión XI del Bosque del Ocaso
219976	Incursiones de pesadilla: Misión XII del Bosque del Ocaso
219977	Incursiones de pesadilla: Misión XIII del Bosque del Ocaso
219978	Incursiones de pesadilla: Misión XIV del Bosque del Ocaso
219979	Incursiones de pesadilla: Misión XV del Bosque del Ocaso
219980	Incursiones de pesadilla: Misión XVI del Bosque del Ocaso
219981	Incursiones de pesadilla: Misión XVII del Bosque del Ocaso
219982	Incursiones de pesadilla: Misión XVIII del Bosque del Ocaso
219983	Autorización de designación: Misión III de Bosque del Ocaso
219984	Autorización de designación: Misión IV de Bosque del Ocaso
219985	Autorización de designación: Misión V de Bosque del Ocaso
219986	Autorización de designación: Misión VI de Bosque del Ocaso
219987	Autorización de designación: Misión VII de Bosque del Ocaso
219988	Autorización de designación: Misión VIII de Bosque del Ocaso
219989	Autorización de designación: Misión IX de Bosque del Ocaso
219990	Autorización de designación: Misión X de Bosque del Ocaso
219991	Autorización de designación: Misión XI de Bosque del Ocaso
219992	Autorización de designación: Misión XII de Bosque del Ocaso
219993	Autorización de designación: Misión XIII de Bosque del Ocaso
219994	Autorización de designación: Misión XIV de Bosque del Ocaso
219995	Autorización de designación: Misión XV de Bosque del Ocaso
219996	Autorización de designación: Misión XVI de Bosque del Ocaso
219997	Autorización de designación: Misión XVII de Bosque del Ocaso
219998	Autorización de designación: Misión XVIII de Bosque del Ocaso
219999	Incursiones de pesadilla: Misión I de Vallefresno
220000	Incursiones de pesadilla: Misión II de Vallefresno
220001	Incursiones de pesadilla: Misión III de Vallefresno
220002	Incursiones de pesadilla: Misión IV de Vallefresno
220003	Incursiones de pesadilla: Misión V de Vallefresno
220004	Incursiones de pesadilla: Misión VI de Vallefresno
220005	Incursiones de pesadilla: Misión VII de Vallefresno
220006	Incursiones de pesadilla: Misión VIII de Vallefresno
220007	Incursiones de pesadilla: Misión IX de Vallefresno
220008	Incursiones de pesadilla: Misión X de Vallefresno
220009	Incursiones de pesadilla: Misión XI de Vallefresno
220010	Incursiones de pesadilla: Misión XII de Vallefresno
220011	Incursiones de pesadilla: Misión XIII de Vallefresno
220012	Incursiones de pesadilla: Misión XIV de Vallefresno
220013	Incursiones de pesadilla: Misión XV de Vallefresno
220014	Incursiones de pesadilla: Misión XVI de Vallefresno
220015	Incursiones de pesadilla: Misión XVII de Vallefresno
220016	Incursiones de pesadilla: Misión XVIII de Vallefresno
220017	Incursiones de pesadilla: Misión I de las Tierras del Interior
220018	Incursiones de pesadilla: Misión II de las Tierras del Interior
220019	Incursiones de pesadilla: Misión III de las Tierras del Interior
220020	Incursiones de pesadilla: Misión IV de las Tierras del Interior
220021	Incursiones de pesadilla: Misión V de las Tierras del Interior
220022	Incursiones de pesadilla: Misión VI de las Tierras del Interior
220023	Incursiones de pesadilla: Misión VII de las Tierras del Interior
220024	Incursiones de pesadilla: Misión VIII de las Tierras del Interior
220025	Incursiones de pesadilla: Misión IX de las Tierras del Interior
220026	Incursiones de pesadilla: Misión X de las Tierras del Interior
220027	Incursiones de pesadilla: Misión XI de las Tierras del Interior
220028	Incursiones de pesadilla: Misión XII de las Tierras del Interior
220029	Incursiones de pesadilla: Misión XIII de las Tierras del Interior
220030	Incursiones de pesadilla: Misión XIV de las Tierras del Interior
220031	Incursiones de pesadilla: Misión XV de las Tierras del Interior
220032	Incursiones de pesadilla: Misión XVI de las Tierras del Interior
220033	Incursiones de pesadilla: Misión XVII de las Tierras del Interior
220034	Incursiones de pesadilla: Misión XVIII de las Tierras del Interior
220035	Incursiones de pesadilla: Misión I de Feralas
220036	Incursiones de pesadilla: Misión II de Feralas
220037	Incursiones de pesadilla: Misión III de Feralas
220038	Incursiones de pesadilla: Misión IV de Feralas
220039	Incursiones de pesadilla: Misión V de Feralas
220040	Incursiones de pesadilla: Misión VI de Feralas
220041	Incursiones de pesadilla: Misión VII de Feralas
220042	Incursiones de pesadilla: Misión VIII de Feralas
220043	Incursiones de pesadilla: Misión IX de Feralas
220044	Incursiones de pesadilla: Misión X de Feralas
220045	Incursiones de pesadilla: Misión XI de Feralas
220046	Incursiones de pesadilla: Misión XII de Feralas
220047	Incursiones de pesadilla: Misión XIII de Feralas
220048	Incursiones de pesadilla: Misión de Feralas XIV
220049	Incursiones de pesadilla: Misión de Feralas XV
220050	Incursiones de pesadilla: Misión de Feralas XVI
220051	Incursiones de pesadilla: Misión de Feralas XVII
220052	Incursiones de pesadilla: Misión de Feralas XVIII
220053	Autorización de designación: Misión I de Vallefresno
220054	Autorización de designación: Misión II de Vallefresno
220055	Autorización de designación: Misión III de Vallefresno
220056	Autorización de designación: Misión IV de Vallefresno
220057	Autorización de designación: Misión V de Vallefresno
220058	Autorización de designación: Misión VI de Vallefresno
220059	Autorización de designación: Misión VII de Vallefresno
220060	Autorización de designación: Misión VIII de Vallefresno
220061	Autorización de designación: Misión IX de Vallefresno
220062	Autorización de designación: Misión X de Vallefresno
220063	Autorización de designación: Misión XI de Vallefresno
220064	Autorización de designación: Misión XII de Vallefresno
220065	Autorización de designación: Misión XIII de Vallefresno
220066	Autorización de designación: Misión XIV de Vallefresno
220067	Autorización de designación: Misión XV de Vallefresno
220068	Autorización de designación: Misión XVI de Vallefresno
220069	Autorización de designación: Misión XVII de Vallefresno
220070	Autorización de designación: Misión XVIII de Vallefresno
220071	Autorización de designación: Misión I de las Tierras del Interior
220072	Autorización de designación: Misión II de las Tierras del Interior
220073	Autorización de designación: Misión III de las Tierras del Interior
220074	Autorización de designación: Misión IV de las Tierras del Interior
220075	Autorización de designación: Misión V de las Tierras del Interior
220076	Autorización de designación: Misión VI de las Tierras del Interior
220077	Autorización de designación: Misión VII de las Tierras del Interior
220078	Autorización de designación: Misión VIII de las Tierras del Interior
220079	Autorización de designación: Misión IX de las Tierras del Interior
220080	Autorización de designación: Misión X de las Tierras del Interior
220081	Autorización de designación: Misión XI de las Tierras del Interior
220082	Autorización de designación: Misión XII de las Tierras del Interior
220083	Autorización de designación: Misión XIII de las Tierras del Interior
220084	Autorización de designación: Misión XIV de las Tierras del Interior
220085	Autorización de designación: Misión XV de las Tierras del Interior
220086	Autorización de designación: Misión XVI de las Tierras del Interior
220087	Autorización de designación: Misión XVII de las Tierras del Interior
220088	Autorización de designación: Misión XVIII de las Tierras del Interior
220089	Autorización de designación: Misión I de Feralas
220090	Autorización de designación: Misión II de Feralas
220091	Autorización de designación: Misión III de Feralas
220092	Autorización de designación: Misión IV de Feralas
220093	Autorización de designación: Misión V de Feralas
220094	Autorización de designación: Misión VI de Feralas
220095	Autorización de designación: Misión VII de Feralas
220096	Autorización de designación: Misión VIII de Feralas
220097	Autorización de designación: Misión IX de Feralas
220098	Autorización de designación: Misión X de Feralas
220099	Autorización de designación: Misión XI de Feralas
220100	Autorización de designación: Misión XII de Feralas
220101	Autorización de designación: Misión XIII de Feralas
220102	Autorización de designación: Misión XIV de Feralas
220103	Autorización de designación: Misión XV de Feralas
220104	Autorización de designación: Misión XVI de Feralas
220105	Autorización de designación: Misión XVII de Feralas
220106	Autorización de designación: Misión XVIII de Feralas
220164	Runa del Gladiador
220165	Runa de Cólera
220166	Núcleo infernal ardiente
220167	Polvo de sepultura resplandeciente
220168	Cerveza fundida de triple filtrado
220169	Símbolo de fe
220173	Parasomnia
220213	Sangrevida vil
220214	Eslabón infernal
220216	Lazo infernal
220217	Runa del Voraz
220345	Hechicería sanguina
220346	Leyendas de los maresabios
220347	Lo liminal y lo arcano
220348	Etiqueta para el día a día
220349	Diseño trabajado en piedra
220350	Travesías venenosas
220351	Sapta de aire de Murky
220352	Mente metálica
220353	Códice del conjurador
220360	Runa de Floración
220375	Fragmento de aire
220379	Notas de chamán rasgadas
220446	Tesoro sobrenatural
220510	Esencia elemental
220511	Gran yelmo de la pesadilla
220512	Casco de acero aúreo inmaculado
220514	Visor de plumas verdeante
220515	Casco esmeralda encantado
220516	Visor olvidado de Gasher
220518	Sombrero polvoriento de Ba'ham
220519	Ornato emplumado vudú
220521	Ornato de ritualista hakkari
220522	Corona atrapadora de almas
220523	Rostro de los exiliados
220525	Fragmento de aire resplandeciente
220526	Procesador de N.Ú.C.L.E.O. G-7 cubierto de fango
220527	Manto de rabioso Atal'ai
220528	Sobrehombros de cazador Atal'ai
220529	Bufas de fanatismo
220530	Voluntad del guerrero Atal'ai
220531	Flor púrpura ondulante
220532	Bufas Atal'ai reforzadas
220533	Coraza Atal'ai reforjada
220534	Abrazo eterno de la serpiente alada
220535	Prendas de profeta Atal'ai
220536	Muñequeras de auxiliador Atal'ai
220537	Brazales aguaoscura de soñador
220538	Brazales de escama de babosa malditos
220539	Brazales de guerra de sacrificio
220540	Manoplas cargadas de corrupción
220541	Puños de placas libres de enfermedades
220542	Guanteletes aguasucia contaminados
220543	Guantes de malla de escamas esmeralda
220544	Garfas de pirosangre
220545	Guantes de combatiente hediondos
220546	Manos de los atormentados
220547	Guantes del profeta Atal'ai caído
220548	Guantes de aojador Atal'ai
220549	Correa de espiral del Alba
220550	Pretina de despojador de templos
220551	Fajín del Sueño Esmeralda de devoto
220552	Guardarrenes de dolor
220553	Cinturón del adorador Renegado
220554	Sortija de colmillo de Atal'alarion
220555	Faja de escamas de serpiente Atal'ai
220556	Falda del profeta Atal'ai caído
220557	Sarong de escamas de viento maldito
220558	Leotardos de asesino Atal'ai
220559	Leotardos de escamas de draco revitalizadas
220560	Quijotes de caparazón plateado
220561	Chanclos de trol tenaz
220562	Grebas de batalla de Tirosangre
220563	Botas del chamán de sangre atal'ai
220564	Botas de escamas húmedas restauradas
220565	Botas de caminaniebla etéreas
220566	Zarpa abrasadora
220567	Cabeza de pincho ensangrentada
220568	Hacha pistola de explorador de templo
220569	Martillo de ira abrasador
220570	Manto de pesadillas
220571	Arco largo punzante
220572	Repetidor rápido de Rinzo
220573	Arco de caza de acechador nefasto
220574	Diente de Eranikus afilado
220575	Devorador de los Condenados
220576	Hacha del ejecutor atal'ai
220577	Poderío del loa de la sangre
220578	Puño de los Renegados
220579	Palo de mojo de médico brujo
220580	Locura del avatar
220581	Machacaserpientes
220582	Grito de dragón
220583	Hoja de los desdichados vil
220584	Hoja de aliento de llamas
220585	Uña funesta degradada
220586	Arrogancia, la Marcabandidos
220587	Daga del sueño de sacrificio
220588	Garra de colmillo de cobra
220589	Golpeador de serpiente
220590	Aguja de adoración Hakkari
220591	Vara restauradora de Mijan
220594	Guadaña del sueño
220595	Bastón de foco de pesadilla
220596	Vara adivinatoria antigua
220597	Piedra draco de emisario del sueño
220598	Piedra draco emisario de pesadilla
220599	Piedra draco de profeta de sangre
220600	Emblema de preeminencia
220601	Protector de médica bruja Hakkari
220602	Medio caparazón de tortuga de alcantarilla
220603	Vara de corrosión irreversible
220604	Trofeo de pesadilla
220605	Tratado sobre sacrilegio
220606	Ídolo del sueño
220607	Tótem de linaje atormentado
220608	Mantón de piel emplumada
220609	Mantón del ocaso
220610	Runa de Maña mental
220611	Manteo de maleficio de Hukku
220612	Runa de Maremotos
220613	Runa de Trueno ensordecedor
220614	Runa de Choque estático
220615	Capa de piel de pantera
220616	Runa de Sobrecarga
220617	Runa de Pandemia
220618	Runa de Aura de inmolación
220619	Ceremonia de sangre atal'ai
220620	Calavera de serpiente alada
220621	Cristal de resonancia de pesadilla
220622	Ojo de dragón perfectamente preservado
220623	Guardapelo perdido de Jin'do
220624	Talismán de valor manchado de sangre
220625	Resiliencia de los exiliados
220626	Sortija de garra de draco de rabioso
220627	Sortija de garra de draco de acechador
220628	Sortija de garra de draco de emisario
220629	Sortija de garra de draco de profeta de sangre
220630	Sortija de garra de draco de gigante
220632	Medallón de ritual de sangre atal'ai
220633	Insignia de ritual de sangre atal'ai
220634	Talismán de ritual de sangre atal'ai
220635	Roca encantada de Atal'alarion
220636	Ícono de sangre atal'ai
220637	Ficha de ritual atal'ai
220638	Palo de maleficios poco ortodoxo
220639	Inanimator de Lledra
220642	Armadura de placas de mártir expulsado
220643	Musleras de placas de mártir expulsado
220648	Botas de placas de mártir expulsado
220649	Herencia de Merithra
220650	Peto de profeta obsesionado
220651	Musleras de profeta obsesionado
220652	Botas ornamentadas de profeta obsesionado
220653	Peto de rabioso quejumbroso
220654	Quijotes de rabioso quejumbroso
220656	Botas de batalla de rabioso quejumbroso
220657	Camisote de rabioso desterrado
220658	Quijotes de rabioso desterrado
220659	Grebas de anillas de rabioso desterrado
220660	Camisa de anillas de devoto marginado
220661	Musleras de devoto marginado
220662	Botas de escamas de devoto marginado
220663	Leotardos de tejespíritus corrupto
220664	Escarpes de tejespíritus corrupto
220665	Coraza de tejespíritus corrupto
220666	Malla de anillas de cazador aterrador
220667	Botarga de cazador aterrador
220668	Grebas de cazador aterrador
220669	Chaleco de profeta exiliado
220670	Zapatillas de profeta exiliado
220671	Pantalones de cuero de profeta exiliado
220672	Arnés de adorador perdido
220673	Leotardos de adorador perdido
220674	Espada sigilosa estropeada
220675	Botines de adorador perdido
220676	Guerrera corrupta con sangre
220677	Botas corruptas con sangre
220678	Pantalones corruptos con sangre
220679	Leotardos de profeta malévolo
220680	Jubón de profeta malévolo
220681	Sandalias de profeta malévolo
220682	Runa del Desbocado
220683	Jubón de profeta benévolo
220684	Leotardos de profeta benévolo
220685	Sandalias de profeta benévolo
220686	Azote del cabecilla
220687	Runa del Raptor
220688	Manto de pesadillas inerte
220689	Avambrazos potenciados por el Vacío
220738	Hombreras de pavor
220739	Espaldares torvos
220740	Guardahombros aterrorizadores
220741	Espaldares de anillas vociferantes
220742	Bufas chillonas
220743	Guardahombros de anillas cacófonos
220744	Manto de anillas gemebundo
220745	Membrana de neurosis oscura
220747	Manto de paranoia
220748	Hombreras de obsesión
220749	Manto de demencia
220750	Espaldares de mente fracturada
220751	Hombreras del trastornado
220754	Runa de la Tormenta de viento
220775	Ticket de intercambio de ingeniería
220778	Pantalones de Guardia de sangre coagulada
220779	Guerrera de Guardia de sangre coagulada
220780	Botas de Guardia de sangre coagulada
220781	Leotardos de profeta de pesadilla
220783	Vestimentas de profeta de pesadilla
220784	Sandalias de profeta de pesadilla
220791	Runa del Felino selvático
220792	Pergamino de reparación espacial
220794	Camisote de placas de Caballero
220795	Espaldares de placas de Teniente caballero
220796	Espaldares de placas de Guardia de sangre
220797	Leotardos de placas de Caballero
220798	Leotardos de placas de Guardia de piedra
220799	Grebas de placas de Alférez
220800	Grebas de placas de Gran capataz
220801	Armadura de placas de Guardia de piedra
220803	Yelmo de placas de Guardia de sangre
220804	Yelmo de placas de Teniente caballero
220806	Guanteletes de placas de Alférez
220807	Guanteletes de placas de Gran capataz
220808	Espaldares imbuidos de Teniente caballero
220809	Leotardos imbuidos de Caballero
220810	Yelmo imbuido de Teniente caballero
220811	Grebas imbuidas de Alférez
220812	Guanteletes imbuidos de Alférez
220813	Armadura imbuida de Caballero
220814	Botas de láminas de Alférez
220815	Peto de láminas de Caballero
220816	Quijotes de láminas de Caballero
220817	Guanteletes de láminas de Alférez
220818	Espaldares de láminas de Teniente caballero
220819	Yelmo de láminas de Teniente caballero
220820	Yelmo de malla de Guardia de sangre
220821	Yelmo de anillas de Guardia de sangre
220822	Yelmo de anillas de Teniente caballero
220823	Cubrehombros de malla de Guardia de sangre
220824	Cubrehombros de anillas de Guardia de sangre
220825	Cubrehombros de anillas de Teniente caballero
220826	Armadura de malla de Guardia de piedra
220827	Armadura de anillas de Guardia de piedra
220828	Armadura de anillas de Caballero
220829	Guanteletes de anillas de Alférez
220830	Guanteletes de anillas de Gran capataz
220831	Guanteletes de malla de Gran capataz
220832	Quijotes de anillas de Caballero
220833	Quijotes de anillas de Guardia de piedra
220834	Quijotes de malla de Guardia de piedra
220835	Escarpes de malla de Gran capataz
220836	Escarpes de anillas de Gran capataz
220837	Escarpes de anillas de Alférez
220838	Pechera con inscripciones de Guardia de piedra
220839	Quijotes con inscripciones de Guardia de piedra
220840	Escarpes con inscripciones de Gran capataz
220841	Hombreras con inscripciones de Guardia de sangre
220842	Escutelaria con inscripciones de Guardia de sangre
220843	Guanteletes con inscripciones de Gran capataz
220844	Coraza pulsante de Guardia de piedra
220845	Guanteletes pulsantes de Gran capataz
220846	Grebas pulsantes de Gran capataz
220847	Quijotes pulsantes de Guardia de piedra
220848	Yelmo pulsante de Guardia de sangre
220849	Sobrehombros pulsantes de Guardia de sangre
220850	Cinta de cuero de Teniente caballero
220851	Cinta de cuero de Guardia de sangre
220852	Sobrehombros de cuero de Teniente caballero
220853	Sobrehombros de cuero de Guardia de sangre
220854	Armadura de cuero de Caballero
220855	Armadura de cuero de Guardia de piedra
220856	Guanteletes de cuero de Alférez
220857	Guanteletes de cuero de Gran capataz
220858	Pantalones de cuero de Caballero
220859	Pantalones de cuero de Guardia de piedra
220860	Botas de cuero de Alférez
220861	Botas de cuero de Gran capataz
220862	Botas de cuero arrugadas de Alférez
220863	Botas de cuero arrugadas de Gran capataz
220864	Leotardos de cuero arrugados de Caballero
220865	Leotardos de cuero arrugados de Guardia de piedra
220866	Guanteletes de cuero arrugados de Alférez
220867	Guanteletes de cuero arrugados de Gran capataz
220868	Guerrera de cuero arrugada de Caballero
220869	Guerrera de cuero arrugada de Guardia de piedra
220870	Bufas de cuero arrugado de Teniente caballero
220871	Bufas de cuero arrugado de Guardia de sangre
220872	Yelmo de cuero arrugado de Teniente caballero
220873	Yelmo de cuero arrugado de Guardia de sangre
220874	Yelmo de cuero restaurado de Teniente caballero
220875	Yelmo de cuero restaurado de Guardia de sangre
220876	Bufas de cuero restauradas de Teniente caballero
220877	Bufas de cuero restauradas de Guardia de sangre
220878	Chaleco de cuero restaurado de Caballero
220879	Chaleco de cuero restaurado de Guardia de piedra
220880	Guantes de cuero restaurados de Alférez
220881	Guantes de cuero restaurados de Gran capataz
220882	Leotardos de cuero restaurados de Caballero
220883	Leotardos de cuero restaurados de Guardia de piedra
220884	Botas de cuero restauradas de Alférez
220885	Botas de cuero restauradas de Gran capataz
220886	Jubón de tejido de tinieblas de Caballero
220887	Manto de tejido de tinieblas de Teniente caballero
220888	Leotardos de tejido de tinieblas de Caballero
220889	Sombrero de tejido de tinieblas de Teniente caballero
220890	Guantes de tejido de tinieblas de Alférez
220891	Botas de tejido de tinieblas de Alférez
220892	Armadura de satén de Caballero
220893	Leotardos de satén de Caballero
220894	Hombreras de satén de Teniente caballero
220895	Botas de satén de Alférez
220896	Casquete de satén de Teniente caballero
220897	Guantes de satén de Alférez
220898	Guantes de satén de Gran capataz
220899	Casquete de satén de Guardia de sangre
220900	Botas de satén de Gran capataz
220901	Hombreras de satén de Guardia de sangre
220902	Leotardos de satén de Guardia de piedra
220903	Armadura de satén de Guardia de piedra
220904	Jubón de tejido de tinieblas de Guardia de piedra
220905	Manto de tejido de tinieblas de Guardia de sangre
220906	Leotardos de tejido de tinieblas de Guardia de piedra
220907	Sombrero de tejido de tinieblas de Guardia de sangre
220908	Guantes de tejido de tinieblas de Gran capataz
220909	Botas de tejido de tinieblas de Gran capataz
220912	Martillo de geodas
220913	Runa de Demolición
220914	Martillo de geodas roto
220915	Ídolo del arrastrapiés colérico
220916	Cuerno de Estegodón Silenciatruenos
220917	Caja de tinte escarlata
220918	Suministros faltantes: Sopa de almejas de Minahonda
220919	Suministros faltantes: Sopa de pargo nocturno
220920	Suministros faltantes: Chuletas de lobo tiernas
220921	Suministros faltantes: Vendas de tejido mágico gruesas
220922	Suministros faltantes: Solea
220923	Suministros faltantes: Hojasueño
220924	Suministros faltantes: Barras de veraplata
220925	Suministros faltantes: Barras de torio
220926	Suministros faltantes: Cuero basto
220927	Suministros faltantes: Pellejo grueso
220928	Suministros faltantes: Barras de torio encantado
220929	Suministros faltantes: Pociones de maná excelentes
220930	Suministros faltantes: Pociones de sanación sublime
220931	Suministros faltantes: Bombas altamente explosivas
220932	Suministros faltantes: Granadas de torio
220933	Suministros faltantes: Rifles de torio
220934	Suministros faltantes: Almófares de mitril
220935	Suministros faltantes: Cinturones de torio
220936	Suministros faltantes: Guanteletes de veraplata
220937	Suministros faltantes: Refuerzos para armadura bastos
220938	Suministros faltantes: Brazales de cuero maligno
220939	Suministros faltantes: Brazales de cuero rúnico
220940	Suministros faltantes: Cintas de tejido mágico negra
220941	Suministros faltantes: Cinturones de paño rúnico
220942	Suministros faltantes: Camisas de esmoquin
220964	Avambrazos potenciados por el Vacío descargados
220965	Gran hacha de Horrocrusto
221008	Cargamento de suministros
221009	Cargamento de suministros
221010	Cargamento de suministros
221017	Registro de Keldara
221018	Botiquín de campo
221019	Muestra de herbasátiro
221020	Runa de la Diosa lunar
221021	Semilla de pesadilla
221024	Frasco de pesadillas perpetuas
221025	Avambrazos de invocador potenciados por el Vacío
221026	Avambrazos de destripador potenciados por el Vacío
221027	Avambrazos de protector potenciados por el Vacío
221028	Sigilo encantado: sueños vivos
221030	Mojo atal'ai de magia prohibida
221191	Piedra onírica
221192	Diario de sueños
221193	Anillo de esmeralda
221196	Mojo atal'ai de guerra
221199	Tintura de herbasátiro
221256	Brazo derecho del Desintegrador
221257	Brazo izquierdo del Desintegrador
221258	Pie derecho del Desintegrador
221259	Pie izquierdo del Desintegrador
221260	Cabeza del Desintegrador
221261	Jarabe de susurro salvaje
221262	Ofrenda salvaje
221267	Runa de los Sanguinarios
221271	As de Naturaleza
221272	Baraja de Naturaleza
221273	Dos de Naturaleza
221274	Tres de Naturaleza
221275	Cuatro de Naturaleza
221276	Cinco de Naturaleza
221277	Seis de Naturaleza
221278	Siete de Naturaleza
221279	Ocho de Naturaleza
221280	Baraja de Plagas
221281	As de Plagas
221282	Dos de Plagas
221283	Tres de Plagas
221284	Cuatro de Plagas
221285	Cinco de Plagas
221286	Seis de Plagas
221287	Siete de Plagas
221288	Ocho de Plagas
221289	Baraja de Dunas
221290	As de Dunas
221291	Dos de Dunas
221292	Tres de Dunas
221293	Cuatro de Dunas
221294	Cinco de Dunas
221295	Seis de Dunas
221296	Siete de Dunas
221297	Ocho de Dunas
221298	As de Pesadillas
221299	Baraja de Pesadillas
221300	Dos de Pesadillas
221301	Tres de Pesadillas
221302	Cuatro de Pesadillas
221303	Cinco de Pesadillas
221304	Seis de Pesadillas
221305	Siete de Pesadillas
221306	Ocho de Pesadillas
221307	Naipe de la Luna Negra: Descomposición
221308	Naipe de la Luna Negra: Sobrecrecimiento
221309	Naipe de la Luna Negra: Tormenta de arena
221310	Naipe de la Luna Negra: Tormento
221311	Mojo atal'ai de vida
221312	Frasco de mojo atal'ai
221313	Frasco de mojo de pesadilla
221314	Cartel de SE BUSCA
221315	Generador de arcoíris
221316	Uniforme exclusivo de Premo
221317	Leycrist de Feralas
221318	Leycrist de Azshara
221319	Leycrist de Roca Negra
221320	Leycrist de las Tierras del Interior
221321	Sello atal'ai de poderío
221322	Sello atal'ai de mojo
221323	Sello atal'ai de serenidad
221324	Llave Forjatiniebla frágil
221325	Carga explosiva para tontos
221326	Corazón de venado sagrado
221327	Esquema: Rayo reductor gnómico
221328	Esquema: Gafas gnómicas
221329	Esquema: Proyector redomático gnómico
221330	Esquema: Cinturón de prevención de daño gnómico
221331	Esquema: Botas cohete gnómicas
221332	Esquema: Gallo de batalla gnómico
221333	Esquema: Gorro de control mental gnómico
221334	Esquema: Rayo mortal gnómico
221335	Esquema: Casco de albañil goblin
221336	Esquema: Casco de minero goblin
221337	Esquema: Mortero goblin
221338	Esquema: Carga de zapador goblin
221339	Esquema: Botas cohete goblin
221340	Esquema: Dispensador de bombas goblin
221341	Esquema: El Grande
221342	Esquema: Escopeta dragón goblin
221343	Esquema: Casco cohete goblin
221344	Libro de hechizos personal
221345	Sangre corrupta de Eranikus
221346	Omóplato del avatar caído
221347	Sapta de fuego turbia
221348	Sapta de agua turbia
221349	Sapta de tierra turbia
221350	Notas de chamán chamuscadas
221351	Notas de chamán empapadas
221352	Notas de chamán borroneadas
221353	Fragmento de fuego
221354	Fragmento de agua
221355	Fragmento de tierra
221356	Fragmento de fuego resplandeciente
221357	Fragmento de agua resplandeciente
221358	Fragmento de tierra resplandeciente
221359	Pluma de lechubestia prístina
221360	Papiro farraki
221361	Resina de Zukk'ash
221362	Paño para limpiar armas
221363	Omóplato del avatar caído
221364	Moneda de masacre de cobre
221365	Moneda de masacre de plata
221366	Moneda de masacre de oro
221367	Cartera de monedas de masacre de cobre
221368	Cartera de monedas de masacre de plata
221369	Succión de pesadilla
221370	Medallón precioso
221371	Monedero de secuestrador
221372	Monedero destrozado
221374	Angustia del Sueño
221376	Yelmo del Sueño Esmeralda
221377	Quijotes del Sueño Esmeralda
221378	Guanteletes del Sueño Esmeralda
221379	Escarpes del Sueño Esmeralda
221380	Coraza del Sueño Esmeralda
221381	Espaldares del Sueño Esmeralda
221382	Placa de batalla taraceada esmeralda
221383	Manoplas taraceadas esmeralda
221384	Casco taraceado esmeralda
221385	Quijotes taraceados esmeralda
221386	Bufas taraceadas esmeralda
221387	Botas de placas taraceadas esmeralda
221388	Leotardos de malla de escamas esmeralda
221389	Guanteletes de malla de escamas esmeralda
221390	Coraza de malla de escamas esmeralda
221391	Casco de malla de escamas esmeralda
221392	Sobrehombros de malla de escamas esmeralda
221393	Botas de malla de escamas esmeralda
221394	Botas cargadas de esmeraldas
221395	Coraza cargada de esmeraldas
221396	Guanteletes cargados de esmeraldas
221397	Casco cargado de esmeraldas
221398	Leotardos cargados de esmeraldas
221399	Sobrehombros cargados de esmeraldas
221400	Sobrehombros de anillas esmeralda
221401	Leotardos de anillas esmeralda
221402	Casco de anillas esmeralda
221403	Guanteletes de anillas esmeralda
221404	Coraza de anillas esmeralda
221405	Botas de anillas esmeralda
221406	Jubón de cuero esmeralda
221407	Guantes de cuero esmeralda
221408	Yelmo de cuero esmeralda
221409	Escarpes de cuero esmeralda
221410	Pantalones de cuero esmeralda
221411	Sobrehombros de cuero esmeralda
221412	Guantes de guardián de los sueños esmeralda
221413	Yelmo de guardián de los sueños esmeralda
221414	Pantalones de guardián de los sueños esmeralda
221415	Botas de guardián de los sueños esmeralda
221416	Sobrehombros de guardián de los sueños esmeralda
221417	Pechera de guardián de los sueños esmeralda
221418	Rugido de Agamaggan
221419	Jubón de vigía esmeralda
221420	Botas de vigía esmeralda
221421	Guantes de vigía esmeralda
221422	Yelmo de vigía esmeralda
221423	Leotardos de vigía esmeralda
221424	Sobrehombros de vigía esmeralda
221425	Diadema encantada esmeralda
221426	Botas encantadas esmeralda
221427	Guantes encantados esmeralda
221428	Runa de Juego sucio
221429	Pantalones encantados esmeralda
221430	Togas encantadas esmeralda
221431	Sobrehombros encantados esmeralda
221432	Manto tejido esmeralda
221433	Runa de Enfoque
221434	Togas tejidas esmeralda
221435	Pantalones tejidos esmeralda
221436	Guantes tejidos esmeralda
221437	Diadema tejida esmeralda
221438	Botas tejidas esmeralda
221439	Armadura del letargo esmeralda
221440	Rugido del Sueño
221441	Celador del Sueño
221442	Rugido del guardián
221443	Rugido de la arboleda
221444	Durian de jungla
221445	Runa de Fuego enfocado
221446	Martillo de ritualista
221447	Grimorio de ritualista de la luna de sangre
221448	Talismán de la Arboleda Corrupta
221450	Arco de luchador de fosa gurubashi
221451	Ballesta de sed de sangre
221452	Sortija arcana de concentración sanguina
221453	Sortija de sangre hirviente
221454	Sortija de sangre glacial
221455	Reverencia de luz de sangre
221456	Sable sanguino eclipsado
221457	Tratado sobre destrucción dracónica
221458	Sortija de victoria sombría
221459	Sello de los sacrificados
221460	Apuñaladora gurubashi
221461	Runa de Carnicería
221462	Espada de velocidad sangrienta
221463	Muñeco de vudú ancestral
221464	Tótem de precisión ígnea
221465	Aplastatoria corrupta
221466	Aro de sangre ardiente
221467	Ojo de la luna de sangre
221468	Muro de susurros
221469	Lanza con púas de rebanacabezas
221470	Esmeralda onírica
221471	Cofre de los Celadores Esmeralda
221473	Runa de Velador
221474	Esencia encadenada de Eranikus
221475	Esencia de Eranikus
221480	Notas de hechizo: Armadura de arrabio
221481	Epifanía nihilista
221482	Runa de Aflicción
221483	Runa de Quemar
221484	Palo de maleficios de médico brujo
221487	Notas de hechizo: Resguardo avanzado
221488	Runa de Epifanía
221489	Runa de Venganza
221490	Runa de Mareas Vivas
221491	Bolsa Diente Oscuro
221497	Llave vieja
221498	Caja de comida robusta
221499	Runa del Guardia vil
221510	Runa del Caballero
221511	Runa del Protector
221512	Runa de Prontitud
221513	Runa de Potencia
221514	Runa de Poder de fuego
221515	Runa de Detonación
221516	Runa de Energía primigenia
221517	Runa de Masacre
221518	Susurro
221519	Orbe Mannoroc
221544	Huevo de cuervo tormentoso
221545	Notas de brujo descifradas
221547	Notas de brujo en clave
221549	Códice de vagayermos
221780	Cetro de la princesa Theradras
221781	Yelmo de guardia vengador
221782	Yelmo de Exilio
221783	Bufas de Justiciero
221785	Vestimentas Cenarion
221971	Cuerno de jurasueños
221972	Fuego de diablillo oniripira
221973	Colmillo de cazasueños
221974	Collar Tótem Siniestro
221975	Bastón de Zarpaleña roto
221976	Bastón de naturaleza enfermiza
221978	Alma de expedicionario
221979	Profecía del invierno glauco
221980	Profecía del caos desatado
221981	Profecía de la tribu perdida
222952	Frasco de sueños inquietos
222962	Sabiduría de Hyjal
223073	Cubrehombros de malla de Teniente caballero
223074	Quijotes de malla de Caballero
223075	Yelmo de malla de Teniente caballero
223076	Guanteletes de malla de Alférez
223077	Escarpes de malla de Alférez
223078	Armadura de malla de Caballero
223147	Notas de hechizo: Descarga de fuego fardo
223148	Tesoro sobrenatural
223149	Tesoro sobrenatural
223150	Tesoro sobrenatural
223151	Tesoro sobrenatural
223160	Arbusto de negociación
223161	Cajón de suministros vacío
223162	Escarcela de mensajero práctica
223163	Fórmula: Pergamino de reparación espacial
223164	Capucha de curiosidad
223167	Gorro de iniciativa
223168	Fragmento de núcleo del mundo
223169	Gorro de tenacidad
223171	Pergamino de geomancia
223172	Cadena de tenacidad
223173	Cordón de geomántico
223174	Botas de geomántico
223175	Capa de geomántico
223177	Almete de geomántico
223178	Brazales de geomántico
223180	Guantes de geomántico
223181	Bufas de geomántico
223182	Calzas de geomántico
223183	Sobrevesta de geomántico
223186	Expedidor de suministros
223192	Cordón del Indomable
223193	Corona del Tejesueños
223194	Sortija de lo salvaje
223195	Amplitud de la bestia
223196	Grebas del destripadioses
223197	Defensor de lo salvaje
223198	Modas Karkun
223214	Zila Gular
223215	Orah Raka
223216	Rakkan Archim
223217	Rakkas Lek
223218	Tor Kieldaz
223219	Braciles de paño vil
223221	Braciles de cuero vil
223222	Braciles de malla vil
223237	Hombreras de paño vil
223238	Hombreras de cuero vil
223239	Sobrehombros de malla vil
223240	Capucha de paño vil
223241	Sombrero de cuero vil
223242	Almófar de malla vil
223248	Piernas de paño vil
223249	Piernas de cuero vil
223250	Piernas de malla vil
223251	Piernas de placas viles
223256	Togas de paño vil
223261	Peto de cuero vil
223262	Peto de malla vil
223263	Peto de placas viles
223283	Mención manchada de sangre
223288	Runa del Martillo
223323	Camisa
223324	Leotardos de zancalluvia
223325	Coraza Hakkari
223326	Embozo Hakkari
223327	Marca de Hakkar
223328	Aro Ráfaga de gemas
223329	Puntilla de fuerza de vida
223330	Ojo pulsante
223331	Ojo pulsante
223332	Ojo vibrante
223333	Ojo siniestro
223334	Ojo resplandeciente
223335	Ojo supurante
223336	Ojo perforador
223337	Ojo ardiente
223518	Puntilla de calcinita
223519	Ojo de Theradras
223520	Espada focal de inventor
223521	Manto de Escamapodrida
223522	Yelmo de la montaña
223523	Piedra nube
223524	Puño de piedra
223525	Ornato de veritas
223526	Sul'thraze la Azotadora
223527	Colmillo de Gahz'rilla
223528	Armadura de escamas de Gahz'rilla
223529	Piel hudú maldita
223530	Falda hudú maldita
223531	Espaldares malos grandes
223532	Amuleto sangrevida
223533	Bastón de Caminadesiertos
223534	Mandiletes jumanza
223535	Vestimentas tribales de Grimlok
223536	Carga de Grimlok
223537	Brazales Placacráneos
223538	Báculo de astillas
223539	Esfera embrujada
223540	Arco del maestro de canes
223541	Fragmento de gemas
223542	Rifle megatiro
223543	Botas de viña pútrida
223544	Bufas de posometal
223545	Rodela hipertécnica de Gizlock
223648	Flecha Onírica
223912	Poción de purificación
223913	Poción de sanación sublime
223914	Poción de sanación superior
223962	Tobilleras acecharenas
223963	Abrazo del licántropo
223964	Hoja de oscuridad eterna
223980	Leotardos de escamas abrasadoras
223981	Togas de zancudo flamígero
223982	Rifle del maestro de canes
223983	Hoja de mediador
223984	Guantes de tela de seda
223985	Sortija ciclópea
223986	Manteo de podredumbre de tumba
223987	Sobrehombros de pellejo escindido
224004	Anillo de esmeralda
224005	Anillo de esmeralda
224006	Anillo de esmeralda
224122	Comesueños
224279	Terrestris
224280	Soberanía, Defensor de los Vuelos
224281	Gla'sir
224282	Rae'lar
224409	Golpeador de serpiente
224806	Ajustador del portal de la Legión
224836	Tesoro sobrenatural
224848	Tesoro sobrenatural
224849	Tesoro sobrenatural
224850	Tesoro sobrenatural
224851	Tesoro sobrenatural
224893	Ajustador de portales sobrecargado
224912	Ajustador de ajustador de portales
225675	Núcleo obsidiano tiznado
225676	Núcleo obsidiano fundido
225686	Runa de Exterminación
225687	Runa de Armadura infernal
225688	Runa de Marca del caos
225689	Notas de hechizo: Tromba Arcana
225690	Notas de hechizo: Orbe congelado
225691	Notas de hechizo: Recalentamiento
225740	Runa de Compostura
225838	Ícono voltaico
225893	Fin de época
225914	Runa del Espíritu vinculado
225929	Fragmento de alma apestado
225938	Notas de hechizo rotas
225939	Notas de hechizo rotas
225940	Notas de hechizo rotas
225941	Notas de hechizo rotas
225942	Carne de jabalí contaminada
225943	Pedazo de carne rancio
225954	Notas de hechizo chamuscadas
225955	Runa de Ingenio
226122	Cuerno de Dalton
226201	Espada del escudero Cuthbert
226207	Eco de Anastari
226208	Eco de Barthilas
226209	Eco de Dathrohan
226210	Eco de Maleki
226211	Eco de Nerub'enkan
226212	Eco de Ramstein
226213	Eco de Osahendido
226214	Eco de Willey
226252	Runa de la Guerrilla
226374	Veneno oculto I
226394	Manual de Veneno atrófico
226395	Manual de Veneno entumecedor
226396	Manual de Veneno oculto
226397	Manual de Veneno sebáceo
226401	Tratado sobre Corazón del león
226402	Revelación de Ira del chamán
226403	Vademécum de Gancho
226404	Real de Minahonda deslustrado
226405	Cajón de suministros de Minahonda dañado
226406	Runa de Especialización en espadas
226407	Runa de Especialización en hachas
226408	Runa de Especialización en mazas
226409	Runa de Especialización en dagas
226410	Runa de Especialización en armas a distancia
226411	Runa de Especialización en armas de puño
226412	Runa de Especialización en armas de asta
226413	Runa de Especialización en lo Arcano
226414	Runa de Especialización en Fuego
226415	Runa de Especialización en Escarcha
226416	Runa de Especialización en Naturaleza
226417	Runa de Especialización en las Sombras
226418	Runa de Especialización Sagrada
226419	Runa de Especialización en combate Feral
226420	Busto esculpido con delicadeza
226421	PLACEHOLDER_ASHBRINGER_QUESTITEM_01
226440	Cinturón de Destripador Nocturno
226441	Guantes de Destripador Nocturno
226442	Pulseras de Destripador Nocturno
226443	Botas de Destripador Nocturno
226444	Hombreras de Destripador Nocturno
226445	Pantalones de Destripador Nocturno
226446	Casquete de Destripador Nocturno
226447	Pechera de Destripador Nocturno
226472	Frasco de sombras de Stratholme
226473	Loriga de Destripador Nocturno
226474	Guardarrenes de Destripador Nocturno
226475	Manoplas de Destripador Nocturno
226476	Brazales de Destripador Nocturno
226477	Tabi de Destripador Nocturno
226478	Espaldares de Destripador Nocturno
226479	Musleras de Destripador Nocturno
226480	Capucha de Destripador Nocturno
226484	Brazales de poderío
226485	Cinturón de poderío
226486	Guanteletes de poderío
226487	Escarpes de poderío
226488	Yelmo de poderío
226489	Coraza de poderío
226490	Quijotes de poderío
226491	Hombreras de poderío
226492	Espaldares de poderío
226493	Leotardos de poderío
226494	Camisote de poderío
226495	Fauces de poderío
226496	Botines de poderío
226497	Manos de poderío
226498	Fajín de poderío
226499	Guardabrazos de poderío
226500	Amuleto pirodraco astillado
226523	Cuerno de Dalton
226526	Artilugio destrozado
226527	Cubrehombros de acechagigantes
226528	Guantes de acechagigantes
226529	Cinturón de acechagigantes
226530	Brazales de acechagigantes
226531	Botas de acechagigantes
226532	Leotardos de acechagigantes
226533	Casco de acechagigantes
226534	Coraza de acechagigantes
226535	Malla de anillas de acechagigantes
226536	Apariencia de acechagigantes
226537	Leotardos de anillas de acechagigantes
226538	Escarpes de acechagigantes
226540	Manoplas de acechagigantes
226541	Guardamuñecas de acechagigantes
226542	Faja de acechagigantes
226543	Espaldares de acechagigantes
226545	Cuerno de Dalton
226546	Sonar de desierto
226547	Pantalones corazón vil
226548	Togas corazón vil
226549	Cuernos corazón vil
226550	Hombreras corazón vil
226551	Cinturón corazón vil
226552	Guantes corazón vil
226553	Brazales corazón vil
226554	Zapatillas corazón vil
226555	Cinturón de arcanista
226556	Guantes arcanistas
226557	Botas arcanistas
226558	Ataduras arcanistas
226559	Togas arcanistas
226560	Manto arcanista
226561	Leotardos arcanistas
226562	Corona arcanista
226563	Prendas arcanistas
226564	Ornato arcanista
226565	Pantalones arcanistas
226566	Sobrehombros arcanistas
226567	Cubremuñecas arcanistas
226568	Sandalias arcanistas
226569	Manoplas arcanistas
226570	Cordón arcanista
226571	Botas de profecía
226572	Guantes de profecía
226573	Diadema de profecía
226574	Pantalones de profecía
226575	Togas de profecía
226576	Manto de profecía
226577	Faja de profecía
226578	Avambrazos de profecía
226579	Cubremuñecas de profecía
226580	Cinturón de profecía
226581	Hombreras de profecía
226582	Prendas de profecía
226583	Leotardos de profecía
226584	Corona de profecía
226585	Manos de profecía
226586	Sandalias de profecía
226587	Runa de Acorazamiento
226588	Bufas de Justiciero
226589	Brazales de Justiciero
226590	Yelmo de Justiciero
226591	Guanteletes de Justiciero
226592	Cinturón de Justiciero
226593	Botas de Justiciero
226594	Quijotes de Justiciero
226595	Coselete de Justiciero
226596	Brazales de guerra de Justiciero
226597	Faja de Justiciero
226598	Leotardos de Justiciero
226599	Corona de Justiciero
226600	Mandiletes de Justiciero
226601	Botas de batalla de Justiciero
226602	Coraza de Justiciero
226603	Avambrazos de Justiciero
226604	Cinturón de batalla de Justiciero
226605	Espaldares de Justiciero
226606	Musleras de Justiciero
226607	Protegecabezas de Justiciero
226608	Manoplas de Justiciero
226609	Escarpes de Justiciero
226610	Peto de Justiciero
226611	Cubrehombros Furia terrenal
226612	Casco Furia terrenal
226613	Botas Furia terrenal
226614	Musleras Furia terrenal
226615	Guanteletes Furia terrenal
226616	Cinturón Furia terrenal
226617	Vestimentas Furia terrenal
226618	Brazales Furia terrenal
226619	Cota guarnecida Furia terrenal
226620	Botos Furia terrenal
226621	Manos Furia terrenal
226622	Visor Furia terrenal
226623	Leotardos Furia terrenal
226624	Manto Furia terrenal
226625	Cordón Furia terrenal
226626	Braciles Furia terrenal
226627	Malla de escamas Furia terrenal
226628	Escarpes Furia terrenal
226629	Manoplas Furia terrenal
226630	Gran yelmo Furia terrenal
226631	Leotardos escamados Furia terrenal
226632	Espaldares Furia terrenal
226633	Guardarrenes Furia terrenal
226634	Guardamuñecas Furia terrenal
226635	Malla de anillas Furia terrenal
226636	Botas de batalla Furia terrenal
226637	Mandiletes Furia terrenal
226638	Celada Furia terrenal
226639	Leotardos de malla Furia terrenal
226640	Bufas Furia terrenal
226641	Faja Furia terrenal
226642	Ataduras Furia terrenal
226644	Bufas Cenarion
226645	Botas Cenarion
226646	Leotardos Cenarion
226647	Yelmo Cenarion
226648	Guantes Cenarion
226649	Brazales Cenarion
226650	Cinturón Cenarion
226651	Pantalones Cenarion
226652	Sandalias Cenarion
226653	Manto Cenarion
226654	Guanteletes Cenarion
226655	Muñequeras Cenarion
226656	Abrazo Cenarion
226657	Cordón Cenarion
226658	Astas Cenarion
226659	Cuernos Cenarion
226660	Faja Cenarion
226661	Guerrera Cenarion
226662	Braciles Cenarion
226663	Botines Cenarion
226664	Puños Cenarion
226665	Sobrehombros Cenarion
226666	Calzas Cenarion
226667	Guardarrenes Cenarion
226668	Guardamuñecas Cenarion
226669	Mandiletes Cenarion
226670	Corona Cenarion
226671	Musleras Cenarion
226673	Botos Cenarion
226674	Espaldares Cenarion
226675	Armadura Cenarion
226678	Premonición y Visión de combate
226679	Perspectivas de errante atemporal
226680	Runa del Primer guerrero
226694	Runa de Especialización en defensa
226698	Amoplador vertical exterior compuesto
226699	Rendijas de níquel con inserciones latonadas
226700	Guerrera arte sombrío
226701	Cinturón arte sombrío
226702	Guantes arte sombrío
226703	Botas arte sombrío
226704	Brazales arte sombrío
226705	Pantalones arte sombrío
226706	Bufas arte sombrío
226707	Almete arte sombrío
226708	Capucha Corazón Salvaje
226709	Falda Corazón Salvaje
226710	Bufas Corazón Salvaje
226711	Guantes Corazón Salvaje
226712	Cinturón Corazón Salvaje
226713	Botas Corazón Salvaje
226714	Brazales Corazón Salvaje
226715	Jubón Corazón Salvaje
226716	Manto de acechabestias
226717	Ataduras de acechabestias
226718	Cinturón de acechabestias
226719	Pantalones de acechabestias
226720	Almete de acechabestias
226721	Guantes de acechabestias
226722	Botas de acechabestias
226723	Guerrera de acechabestias
226724	Cinturón de magister
226725	Ataduras de magister
226726	Manto de magister
226727	Leotardos de magister
226728	Corona de magister
226729	Togas de magister
226730	Botas de magister
226731	Guantes de magister
226732	Cinturón Forjaluz
226733	Yelmo Forjaluz
226734	Coraza Forjaluz
226735	Bufas Forjaluz
226736	Quijotes Forjaluz
226737	Guanteletes Forjaluz
226738	Botas Forjaluz
226739	Brazales Forjaluz
226740	Guantes de devoto
226741	Manto de devoto
226742	Brazales de devoto
226743	Sandalias de devoto
226744	Cinturón de devoto
226745	Toga de devoto
226746	Corona de devoto
226747	Saya de devoto
226748	Guanteletes de elementos
226749	Jubón de elementos
226750	Falda de elementos
226751	Ataduras de elementos
226752	Botas de elementos
226753	Espaldares de elementos
226754	Cordón de elementos
226755	Almófar de elementos
226756	Manto calígine
226757	Toga calígine
226758	Brazaletes calígine
226759	Brazales calígine
226760	Leotardos calígine
226761	Cinturón calígine
226762	Máscara calígine
226763	Sandalias calígine
226764	Botas de valor
226765	Cinturón de valor
226766	Brazales de valor
226767	Quijotes de valor
226768	Bufas de valor
226769	Yelmo de valor
226770	Coraza de valor
226771	Guanteletes de valor
226772	Fajín cuoroferal
226773	Capucha cuoroferal
226774	Galochas cuoroferal
226775	Brazaletes cuoroferal
226776	Jubón cuoroferal
226777	Manos cuoroferal
226778	Bufas cuoroferal
226779	Falda cuoroferal
226780	Cordón cuoroferal
226781	Sandalias cuoroferal
226782	Ataduras cuoroferal
226783	Abrazo cuoroferal
226784	Guanteletes cuoroferal
226785	Manto cuoroferal
226786	Ornato cuoroferal
226787	Pantalones cuoroferal
226788	Braciles cuoroferal
226789	Faja cuoroferal
226790	Cubrehombros cuoroferal
226791	Calzas cuoroferal
226792	Almete cuoroferal
226793	Puños cuoroferal
226794	Botos cuoroferal
226795	Guerrera cuoroferal
226796	Guardamuñecas cuoroferal
226797	Guardarrenes cuoroferal
226798	Espaldares cuoroferal
226799	Musleras cuoroferal
226801	Visera cuoroferal
226802	Empuñaduras cuoroferal
226803	Botines cuoroferal
226804	Armadura cuoroferal
226815	Muñequeras cuoroferal
226816	Cintura cuoroferal
226817	Sobrehombros cuoroferal
226818	Piernas cuoroferal
226819	Yelmo cuoroferal
226820	Guantes cuoroferal
226821	Botas cuoroferal
226822	Pecho cuoroferal
226825	Guerrera Mantoscuro
226826	Bufas Mantoscuro
226827	Pantalones Mantoscuro
226828	Empuñaduras Mantoscuro
226829	Almete Mantoscuro
226830	Brazales Mantoscuro
226831	Escarpines Mantoscuro
226832	Cinturón Mantoscuro
226835	Guardamuñecas Mantoscuro
226836	Guardarrenes Mantoscuro
226837	Espaldares Mantoscuro
226838	Musleras Mantoscuro
226840	Manoplas Mantoscuro
226841	Visera Mantoscuro
226842	Botines Mantoscuro
226843	Armadura Mantoscuro
226845	Muñequeras Mantoscuro
226846	Cintura Mantoscuro
226847	Sobrehombros Mantoscuro
226848	Piernas Mantoscuro
226849	Yelmo Mantoscuro
226850	Guantes Mantoscuro
226851	Botas Mantoscuro
226852	Pecho Mantoscuro
226856	Acelerante de flotabilidad guiada
226857	Botas de batalla de heroísmo
226858	Bufas de heroísmo
226859	Quijotes de heroísmo
226860	Corona de heroísmo
226861	Guanteletes de heroísmo
226862	Coraza de heroísmo
226863	Brazales de heroísmo
226864	Cinturón de heroísmo
226865	Guardamuñecas de heroísmo
226866	Guardarrenes de heroísmo
226867	Espaldares de heroísmo
226868	Musleras de heroísmo
226869	Visera de heroísmo
226870	Manoplas de heroísmo
226871	Escarpes de heroísmo
226872	Coselete de heroísmo
226873	Muñequeras de heroísmo
226874	Cintura de heroísmo
226875	Sobrehombros de heroísmo
226876	Piernas de heroísmo
226877	Yelmo de heroísmo
226878	Guantes de heroísmo
226879	Botas de heroísmo
226880	Pecho de heroísmo
226881	Botines de maestro de bestias
226882	Pantalones de maestro de bestias
226883	Guanteletes de maestro de bestias
226884	Manto de maestro de bestias
226885	Ataduras de maestro de bestias
226886	Guerrera de maestro de bestias
226887	Almete de maestro de bestias
226888	Cinturón de maestro de bestias
226889	Brazales de maestro de bestias
226890	Ajustador de maestro de bestias
226891	Espaldares de maestro de bestias
226892	Leotardos de maestro de bestias
226893	Almófar de maestro de bestias
226894	Puños de maestro de bestias
226895	Grebas de maestro de bestias
226896	Cadena de maestro de bestias
226897	Muñequeras de maestro de bestias
226898	Cintura de maestro de bestias
226899	Sobrehombros de maestro de bestias
226900	Piernas de maestro de bestias
226901	Yelmo de maestro de bestias
226902	Guantes de maestro de bestias
226903	Botas de maestro de bestias
226904	Pecho de maestro de bestias
226905	Cinturón Brumamorta
226906	Toga Brumamorta
226907	Brazales Brumamorta
226908	Sandalias Brumamorta
226909	Máscara Brumamorta
226910	Leotardos Brumamorta
226911	Sobrevestes Brumamorta
226912	Manto Brumamorta
226913	Ataduras Brumamorta
226914	Cordón Brumamorta
226915	Cubrehombros Brumamorta
226916	Pantalones Brumamorta
226917	Caperuza Brumamorta
226918	Agarres Brumamorta
226919	Botines Brumamorta
226920	Abrazo de Brumamorta
226921	Muñequeras Brumamorta
226922	Cintura Brumamorta
226923	Sobrehombros Brumamorta
226924	Piernas Brumamorta
226925	Yelmo Brumamorta
226926	Guantes Brumamorta
226927	Botas Brumamorta
226928	Pecho Brumamorta
226929	Ataduras de hechicero
226930	Guanteletes de hechicero
226931	Sandalias de hechicero
226932	Togas de hechicero
226933	Leotardos de hechicero
226934	Cinturón de hechicero
226935	Corona de hechicero
226936	Manto de hechicero
226937	Muñequeras del hechicero
226938	Cintura de hechicero
226939	Sobrehombros de hechicero
226940	Piernas de hechicero
226941	Yelmo de hechicero
226942	Guantes de hechicero
226943	Botas de hechicero
226944	Pecho de hechicero
226945	Toga del virtuoso
226946	Falda del virtuoso
226947	Corona del virtuoso
226948	Cinturón del virtuoso
226949	Brazales del virtuoso
226950	Mitones del virtuoso
226951	Manto del virtuoso
226952	Sandalias del virtuoso
226953	Sobrevestes del virtuoso
226954	Cordón del virtuoso
226955	Cubrehombros del virtuoso
226956	Leotardos del virtuoso
226957	Capucha del virtuoso
226958	Manos del virtuoso
226959	Zapatillas del virtuoso
226960	Vestido del virtuoso
226961	Muñequeras del virtuoso
226962	Cintura del virtuoso
226963	Sobrehombros del virtuoso
226964	Piernas del virtuoso
226965	Yelmo del virtuoso
226966	Guantes del virtuoso
226967	Botas del virtuoso
226968	Pecho del virtuoso
226969	Bufas Forjaalma
226970	Brazales Forjaalma
226971	Cinturón Forjaalma
226972	Quijotes Forjaalma
226973	Coraza Forjaalma
226974	Botas de guerra Forjaalma
226975	Guanteletes Forjaalma
226976	Gran yelmo Forjaalma
226977	Ataduras Forjaalma
226978	Cordón Forjaalma
226979	Cubrehombros Forjaalma
226980	Leotardos Forjaalma
226981	Corona Forjaalma
226982	Puños Forjaalma
226983	Botines Forjaalma
226984	Abrazo Forjaalma
226985	Guardamuñecas Forjaalma
226986	Guardarrenes Forjaalma
226987	Espaldares Forjaalma
226988	Musleras Forjaalma
226989	Visera Forjaalma
226990	Manoplas Forjaalma
226991	Escarpes Forjaalma
226992	Coseletes Forjaalma
226993	Muñequeras Forjaalma
226994	Cintura Forjaalma
226995	Sobrehombros Forjaalma
226996	Piernas Forjaalma
226997	Yelmo Forjaalma
226998	Guantes Forjaalma
226999	Botas Forjaalma
227000	Pecho Forjaalma
227001	Ataduras de los Cinco Truenos
227002	Almófar de los Cinco Truenos
227003	Espaldares de los Cinco Truenos
227004	Jubón de los Cinco Truenos
227005	Falda de los Cinco Truenos
227006	Guanteletes de los Cinco Truenos
227007	Zapatillas de los Cinco Truenos
227008	Cordón de los Cinco Truenos
227009	Brazales de los Cinco Truenos
227010	Fajín de los Cinco Truenos
227011	Manto de los Cinco Truenos
227012	Leotardos de los Cinco Truenos
227013	Corona de los Cinco Truenos
227014	Agarre de los Cinco Truenos
227015	Grebas de los Cinco Truenos
227016	Guerrera de los Cinco Truenos
227017	Braciles de los Cinco Truenos
227018	Faja de los Cinco Truenos
227019	Bufas de los Cinco Truenos
227020	Quijotes de los Cinco Truenos
227021	Cara de los Cinco Truenos
227022	Puños de los Cinco Truenos
227023	Botines de los Cinco Truenos
227024	Cadena de los Cinco Truenos
227025	Guardamuñecas de los Cinco Truenos
227026	Guardarrenes de los Cinco Truenos
227027	Guardahombros de los Cinco Truenos
227028	Musleras de los Cinco Truenos
227029	Celada de los Cinco Truenos
227030	Guardamanos de los Cinco Truenos
227031	Escarpes de los Cinco Truenos
227032	Coselete de los Cinco Truenos
227033	Muñequeras de los Cinco Truenos
227034	Cintura de los Cinco Truenos
227035	Sobrehombros de los Cinco Truenos
227036	Piernas de los Cinco Truenos
227037	Yelmo de los Cinco Truenos
227038	Guantes de los Cinco Truenos
227039	Botas de los Cinco Truenos
227040	Pecho de los Cinco Truenos
227041	Escalpelo sombrío de plaga
227042	Sobrehombros de placas de Campeón
227043	Yelmo de placas de Campeón
227044	Yelmo de placas de Teniente coronel
227045	Sobrehombros de placas de Teniente coronel
227046	Camisote de placas de Capitán caballero
227047	Leotardos de placas de Capitán caballero
227048	Leotardos de placas de Legionario
227049	Camisote de placas de Legionario
227050	Guanteletes de placas de Guardia de sangre
227051	Grebas de placas de Guardia de sangre
227052	Grebas de placas de Teniente caballero
227053	Guanteletes de placas de Teniente caballero
227054	Sobrehombros de cuero de Teniente coronel
227055	Yelmo de cuero de Teniente coronel
227056	Sobrehombros de cuero de Campeón
227057	Yelmo de cuero de Campeón
227058	Pechera de cuero de Capitán caballero
227059	Musleras de cuero de Legionario
227060	Pechera de cuero de Legionario
227061	Musleras de cuero de Capitán caballero
227062	Botos de cuero de Guardia de sangre
227063	Mandiletes de cuero de Guardia de sangre
227064	Botos de cuero de Teniente caballero
227065	Mandiletes de cuero de Teniente caballero
227066	Yelmo de anillas de Teniente coronel
227067	Yelmo de anillas de Campeón
227068	Sobrehombros de anillas de Teniente coronel
227069	Sobrehombros de anillas de Campeón
227070	Camisote de anillas de Capitán caballero
227071	Camisote de anillas de Legionario
227072	Musleras de anillas de Capitán caballero
227073	Musleras de anillas de Legionario
227074	Grebas de anillas de Guardia de sangre
227075	Abrazaderas de anillas de Guardia de sangre
227076	Grebas de anillas de Teniente caballero
227077	Abrazaderas de anillas de Teniente caballero
227078	Espaldares de anillas de Campeón
227079	Quijotes de anillas de Legionario
227080	Gran yelmo de anillas de Campeón
227081	Mandiletes de anillas de Guardia de sangre
227082	Escarpes de anillas de Guardia de sangre
227083	Armadura de anillas de Legionario
227084	Espaldares de anillas de Teniente coronel
227085	Quijotes de anillas de Capitán caballero
227086	Gran yelmo de anillas de Teniente coronel
227087	Mandiletes de anillas de Teniente caballero
227088	Escarpes de anillas de Teniente caballero
227089	Armadura de anillas de Capitán caballero
227090	Capucha de tejido de tinieblas de Campeón
227091	Bufas de tejido de tinieblas de Teniente coronel
227092	Bufas de tejido de tinieblas de Campeón
227093	Capucha de tejido de tinieblas de Teniente coronel
227094	Guerrera de tejido de tinieblas de Legionario
227095	Musleras de tejido de tinieblas de Capitán caballero
227096	Guerrera de tejido de tinieblas de Capitán caballero
227097	Musleras de tejido de tinieblas de Legionario
227098	Botos de tejido de tinieblas de Guardia de sangre
227099	Manijas de tejido de tinieblas de Guardia de sangre
227100	Manijas de tejido de tinieblas de Teniente caballero
227101	Botos de tejido de tinieblas de Teniente caballero
227102	Manto de seda de Teniente coronel
227103	Capucha de seda de Teniente coronel
227104	Manto de seda de Campeón
227105	Capucha de seda de Campeón
227106	Guerrera de seda de Legionario
227107	Musleras de seda de Legionario
227108	Guerrera de seda de Capitán caballero
227109	Musleras de seda de Capitán caballero
227110	Botos de seda de Guardia de sangre
227111	Manijas de seda de Guardia de sangre
227112	Botos de seda de Teniente caballero
227113	Manijas de seda de Teniente caballero
227114	Guanteletes de seda de Teniente caballero
227115	Guanteletes de seda de Guardia de sangre
227116	Guantes de seda de Teniente caballero
227117	Guantes de seda de Guardia de sangre
227118	Caperuza de satén de Campeón
227119	Manto de satén de Teniente coronel
227120	Manto de satén de Campeón
227121	Caperuza de satén de Teniente coronel
227122	Guerrera de satén de Capitán caballero
227123	Musleras de satén de Legionario
227124	Guerrera de satén de Legionario
227125	Musleras de satén de Capitán caballero
227126	Manijas de satén de Guardia de sangre
227127	Botos de satén de Guardia de sangre
227128	Manijas de satén de Teniente caballero
227129	Botos de satén de Teniente caballero
227130	Cubrehombros de satén de Campeón
227131	Leotardos de satén de Legionario
227132	Corona de satén de Campeón
227133	Mandiletes de satén de Guardia de sangre
227134	Botines de satén de Guardia de sangre
227135	Toga de satén de Legionario
227136	Cubrehombros de satén de Teniente coronel
227137	Leotardos de satén de Capitán caballero
227138	Corona de satén de Teniente coronel
227139	Mandiletes de satén de Teniente caballero
227140	Botines de satén de Teniente caballero
227141	Toga de satén de Capitán caballero
227142	Coraza de láminas de Capitán caballero
227143	Leotardos de láminas de Capitán caballero
227144	Protegecabezas de láminas de Teniente coronel
227145	Sobrehombros de láminas de Teniente coronel
227146	Escarpes de láminas de Teniente caballero
227147	Guanteletes de láminas de Teniente caballero
227148	Espaldares de láminas de Teniente coronel
227149	Casco de láminas de Teniente coronel
227150	Musleras de láminas de Capitán caballero
227151	Peto de láminas de Capitán caballero
227152	Guantes de láminas de Teniente caballero
227153	Grebas de láminas de Teniente caballero
227154	Espaldares de malla de Campeón
227155	Protegecabezas de malla de Campeón
227156	Musleras de malla de Legionario
227157	Camisote de malla de Legionario
227158	Grebas de malla de Guardia de sangre
227159	Abrazaderas de malla de Guardia de sangre
227160	Bufas de malla de Campeón
227161	Leotardos de malla de Legionario
227162	Yelmo de malla de Campeón
227163	Guanteletes de malla de Guardia de sangre
227164	Escarpes de malla de Guardia de sangre
227165	Coraza de malla de Legionario
227166	Cubrehombros de malla de Campeón
227167	Pantalones de malla de Legionario
227168	Escutelaria de malla de Campeón
227169	Guantes de malla de Guardia de sangre
227170	Botas de malla de Guardia de sangre
227171	Coselete de malla de Legionario
227172	Sobrehombros de pellejo de dragón de Teniente coronel
227173	Protegecabezas de pellejo de dragón de Teniente coronel
227174	Protegecabezas de pellejo de dragón de Campeón
227175	Sobrehombros de pellejo de dragón de Campeón
227176	Pechera de pellejo de dragón de Capitán caballero
227177	Leotardos de pellejo de dragón de Legionario
227178	Leotardos de pellejo de dragón de Capitán caballero
227179	Pechera de pellejo de dragón de Legionario
227180	Mandiletes de pellejo de dragón de Guardia de sangre
227181	Botines de pellejo de dragón de Guardia de sangre
227182	Botines de pellejo de dragón de Teniente caballero
227183	Mandiletes de pellejo de dragón de Teniente caballero
227184	Bufas de pellejo de dragón de Campeón
227185	Pantalones de pellejo de dragón de Legionario
227186	Yelmo de pellejo de dragón de Campeón
227187	Guantes de pellejo de dragón de Guardia de sangre
227188	Botas de pellejo de dragón de Guardia de sangre
227189	Armadura de pellejo de dragón de Legionario
227190	Bufas de pellejo de dragón de Teniente coronel
227191	Pantalones de pellejo de dragón de Capitán caballero
227192	Yelmo de pellejo de dragón de Teniente coronel
227193	Guantes de pellejo de dragón de Teniente caballero
227194	Botas de pellejo de dragón de Teniente caballero
227195	Armadura de pellejo de dragón de Capitán caballero
227196	Guerrera de pellejo de dragón de Capitán caballero
227197	Grebas de pellejo de dragón de Teniente caballero
227198	Guanteletes de pellejo de dragón de Teniente caballero
227199	Ornato de pellejo de dragón de Teniente coronel
227200	Musleras de pellejo de dragón de Capitán caballero
227201	Espaldares de pellejo de dragón de Teniente coronel
227202	Guerrera de pellejo de dragón de Legionario
227203	Grebas de pellejo de dragón de Guardia de sangre
227204	Guanteletes de pellejo de dragón de Guardia de sangre
227205	Ornato de pellejo de dragón de Campeón
227206	Musleras de pellejo de dragón de Legionario
227207	Espaldares de pellejo de dragón de Campeón
227279	Aro de magíster
227280	Artesanía de las sombras
227282	Anillo de niebla temida
227284	Banda de la bestia
227285	Flujo de dinámica estructural
227286	Ron Rumsey tibio con crema
227337	Conjunto de cinturón y guantes felinos
227338	Conjunto de cinturón y guantes astrales
227339	Conjunto de guantes y cinturón de guardián
227340	Conjunto de guantes y cinturón de ensalmador
227341	Conjunto de guantes y cinturón de perseguidor
227342	Conjunto de guantes y cinturón de merodeador
227343	Conjunto de guantes y cinturón de clemente
227344	Conjunto de cinturón y guantes radiantes
227345	Conjunto de cinturón y guantes de voluntad divina
227346	Conjunto de guantes y cinturón del alba
227347	Conjunto de cinturón y guantes crepusculares
227348	Conjunto de guantes y cinturón de entusiasmo
227349	Conjunto de guantes y cinturón de batalla
227350	Conjunto de guantes y cinturón de alivio
227351	Conjunto de guantes y cinturón de erupción
227352	Conjunto de guantes y cinturón de impacto
227353	Conjunto de guantes y cinturón de resolución
227354	Conjunto de guantes y cinturón corruptos
227355	Conjunto de guantes y cinturón malignos
227356	Conjunto de guantes y cinturón inamovibles
227357	Conjunto de guantes y cinturón imparables
227359	Conjunto de botas, piernas y sobrehombros felinos
227360	Conjunto de botas, piernas y hombros astrales
227361	Conjunto de botas, piernas y sobrehombros de guardián
227365	Conjunto de botas, piernas y sobrehombros de ensalmador
227366	Conjunto de botas, piernas y sobrehombros de perseguidor
227367	Conjunto de botas, piernas y sobrehombros de merodeador
227368	Conjunto de botas, piernas y hombros clementes
227369	Conjunto de botas, piernas y hombros radiantes
227370	Conjunto de botas, piernas y hombros de voluntad divina
227371	Conjunto de botas, piernas y hombros del alba
227372	Conjunto de botas, piernas y hombros crepusculares
227373	Conjunto de botas, piernas y sobrehombros de entusiasmo
227374	Conjunto de botas, piernas y sobrehombros de batalla
227375	Conjunto de botas, piernas y sobrehombros de alivio
227376	Conjunto de botas, piernas y sobrehombros de erupción
227377	Conjunto de botas, piernas y sobrehombros de impacto
227378	Conjunto de botas, piernas y sobrehombros de resolución
227379	Conjunto de botas, piernas y sobrehombros corruptos
227380	Conjunto de botas, piernas y hombros malignos
227381	Conjunto de botas, piernas y sobrehombros inamovibles
227382	Conjunto de botas, piernas y sobrehombros imparables
227383	Conjunto de yelmo y pechera felinos
227384	Conjunto de yelmo y pechera astrales
227385	Conjunto de yelmo y pechera de guardián
227387	Conjunto de yelmo y pechera de ensalmador
227388	Conjunto de yelmo y pechera de perseguidor
227389	Conjunto de yelmo y pechera de merodeador
227390	Conjunto de yelmo y pechera clementes
227391	Conjunto de yelmo y pechera radiantes
227392	Conjunto de yelmo y pechera de voluntad divina
227393	Conjunto de yelmo y pechera del alba
227394	Conjunto de yelmo y pechera crepusculares
227395	Conjunto de yelmo y pechera de entusiasmo
227396	Conjunto de yelmo y pechera de batalla
227397	Conjunto de yelmo y pechera de alivio
227398	Conjunto de yelmo y pechera de erupción
227399	Conjunto de yelmo y pechera de impacto
227400	Conjunto de yelmo y pechera de resolución
227401	Conjunto de yelmo y pechera corruptos
227402	Conjunto de yelmo y pechera malignos
227403	Conjunto de yelmo y pechera inamovibles
227404	Conjunto de yelmo y pechera imparables
227444	Ídolo de la cazadora
227451	Sigilo de envío
227454	Aro de la marea
227455	Brisa del océano
227456	Runa de la Tempestad carmesí
227530	Cinturón incandescente
227531	Ataduras incandescentes
227532	Capucha incandescente
227533	Guantes incandescentes
227534	Leotardos incandescentes
227535	Toga incandescente
227536	Botas incandescentes
227537	Hombreras incandescentes
227549	Trozo de papiro
227552	Papiro desgarrado
227658	Nota de Sombra Jurada
227683	Sulfuras, Mano de Ragnaros
227684	Martillo de Sulfuron
227685	Escalpelo sombrío modificado
227686	Martillo de guerra ornamentado
227687	Diente de oro favorito de Lorthas
227688	Aullavísceras
227689	Armadura de placas parcialmente digerida
227690	Piedra rúnica necrótica
227691	Hoja de Hanna
227724	Mención manchada de sangre
227727	Diseño: martillo de Sulfuron
227728	Ojo de Sulfuras
227730	Contrato de la Hermandad del Torio
227743	Núcleo de poder obsidiano
227745	Reliquia familiar
227746	Runa del Árbol del Mundo
227747	Registros familiares
227748	Diario de un superviviente
227749	Runa de la Estrella fugaz
227750	Ataduras escamadas fundidas
227751	Cinturón escamado fundido
227752	Sobrehombros escamados fundidos
227754	Leotardos escamados fundidos
227755	Yelmo escamado fundido
227756	Guantes escamados fundidos
227757	Botas escamadas fundidas
227758	Pechera escamada fundida
227759	Guantes de núcleo agostado
227760	Ataduras de núcleo agostado
227761	Cinturón de núcleo agostado
227762	Sobrehombros de núcleo agostado
227763	Leotardos de núcleo agostado
227764	Yelmo de núcleo agostado
227765	Botas de núcleo agostado
227766	Pechera de núcleo agostado
227767	Cúmulo de fuegopiedra
227768	Jugo de sueños
227796	Pergamino darnassiano misterioso
227797	Pergamino darnassiano descifrado
227801	Ascua de las Tierras de Fuego
227802	Monstruo: antorcha
227803	Arnés de oso de guerra temible
227804	Prendas de lana de oso de guerra temible
227805	Ferocidad de los Fauces de Madera
227807	Cinturón Fauces de Madera denso
227808	Manto de los Fauces de Madera basto
227809	Aporreadores Fauces de Madera con tachuelas
227810	Botas Fauces de Madera densas
227811	Defensor de los Fauces de Madera
227812	Faltriquera de medicinas fúrbolg
227813	Agua bendita potable de Stratholme
227814	Faja del Alba radiante
227815	Botines del Alba finos
227816	Botas de élite Argenta
227817	Guantes del Alba radiantes
227818	Manto del Alba resplandeciente
227819	Manto del Alba flamígero bendecido
227820	Brazales Hierro Negro templados
227821	Yelmo de arrabio besollama
227822	Botas de can del Núcleo gruesas
227823	Guantes Bengala del Núcleo finos
227824	Yelmo Hierro Negro templado
227825	Destructora Hierro Negro fundida
227826	Atracadora de llamas Hierro Negro
227827	Faja de anillas fundidas
227828	Cinturón de lava
227829	Botas de dragontina negra endurecida
227830	Manto Bengala del Núcleo fino
227831	Toga Bengala del Núcleo fina
227832	Amnistía negra templada
227833	Guja de furia obsidiana
227834	Sobrehombros de anillas fundidas
227835	Guanteletes Hierro Negro templados
227836	Leotardos Hierro Negro templados
227837	Cinturón de can del Núcleo grueso
227838	Guanteletes cromáticos brillantes
227839	Leotardos Bengala del Núcleo finos
227840	Guardanegra implacable
227841	Botas Hierro Negro templadas
227842	Puño de ébano
227843	Ocaso descuartizador
227844	Bolsa de paño rúnico reforzada con cuero
227845	Segadora de arcanita refinada
227847	Leotardos de núcleo demoníaco
227848	Guanteletes de núcleo demoníaco
227849	Rifle de tirador certero de núcleo ígneo
227850	Hoja sabia del archimago
227851	Coraza de dragontina negra endurecida
227852	Leotardos de dragontina negra endurecida
227853	Sobrehombros de dragontina negra endurecida
227854	Capa ondeante de maestro de oficios
227857	Profanación
227858	Martillo de los dioses salvajes
227859	Sobrehombros Albar resplandecientes
227860	Jubón de tela lunar incandescente
227861	Toga de tela lunar incandescente
227862	Botas de tela lunar incandescente
227863	Diadema de tela lunar incandescente
227864	Leotardos de tela lunar incandescentes
227865	Guanteletes de placas ígneas de la técnica oculta
227866	Sobrehombros volcánicos magistrales
227867	Leotardos volcánicos magistrales
227868	Coraza volcánica magistral
227869	Capa cromática luminosa
227870	Guanteletes de tempestad
227871	Placa Hierro Negro templada
227872	Cresta de guerra del gran jefe
227873	Sobrehombros de dragontina azul filosa
227874	Leotardos de dragontina azul filosa
227875	Coraza de dragontina azul filosa
227876	Malla invencible
227877	Leotardos de dragontina verde viva
227878	Guanteletes de dragontina verde viva
227879	Coraza de dragontina verde viva
227880	Martillo de batalla con encantamiento delicado
227881	Tranquilidad
227882	Faja de perspicacia arcana
227883	Avambrazos de Vuelo presto
227884	Buscacorazones mortal
227885	Guanteletes de mayor aferramiento
227886	Martillo de tormenta magistral de jinete celestial
227887	Guardia de Escarcha endurecido
227888	Sobrehombros de élite Argenta
227895	Patrón: manto del Alba dorado
227896	Patrón: botas Argenta
227897	Patrón: sobrehombros Argenta
227898	Patrón: coraza de dragontina azul filosa
227899	Patrón: sobrehombros de dragontina azul filosa
227900	Patrón: leotardos de dragontina verde viva
227901	Diseño: placa Hierro Negro templada
227902	Patrón: coraza de dragontina negra endurecida
227903	Patrón: leotardos de dragontina negra endurecida
227904	Patrón: sobrehombros de dragontina negra endurecida
227905	Diseño: martillo de tormenta magistral de jinete celestial
227906	Patrón: coraza volcánica magistral
227907	Patrón: sobrehombros volcánicos magistrales
227908	Patrón: leotardos volcánicos magistrales
227909	Diseño: guanteletes de placas ígneas de la técnica oculta
227910	Patrón: capa cromática luminosa
227911	Cabeza de Rend Puño Negro
227912	Divinidad aplicada
227914	Glándula pineal de lechubestia
227915	Dominio del duque
227921	Runa de Cuchillos
227922	Runa del Espadachín
227923	Botines de agua
227924	Frasco inusual
227925	Faro de Hydraxis
227926	Coronación de Hydraxis
227927	Juramento del mar
227928	Llave de caja de herramientas
227930	Llave de caja fuerte
227931	Fardo oculto
227932	Palanqueta oxidada
227934	Cólera de llamas
227935	Martillo de señor feudal caído
227936	Anillo de diplomático
227937	Caja enigmática
227938	Fragmento de Luz
227939	Fragmento de Luz
227940	Espada de Lord General
227941	Guadaña de ánima
227947	Espaldares a medida gólem
227948	Hacha de batalla de Forjainquina
227952	Cota de malla de Gladiador indómito
227955	Yelmo de Gladiador indómito
227956	Coraza de mortífero
227957	Grebas de Gladiador indómito
227958	Embozo fantasmal
227959	Quijotes del Guardián eterno
227960	Gigante impasible
227961	Mandiletes de Gladiador indómito
227962	Erupción de espinas
227963	Hoja con grabados de sangre
227964	Falda luminaria
227965	Botas omnitiro
227967	Segundo aliento
227970	Manteo de la Salamandra de Fuego
227971	Puños de arrabio
227972	Ráfaga de conocimiento
227973	Círculo de la llama
227974	Martillo de piedra de lava
227978	Piedra Magmus
227980	Togas de la Corona real
227981	Vengador Forjaterrible
227982	Báculo de sabiduría orientador
227983	Sello Hierro Negro
227984	Cetro real de Thaurissan
227985	El nuevo manteo del emperador
227986	Guardamuñecas de Renombre
227987	Fajín del Gran cazador
227988	Joya imperial
227990	Mano de la Injusticia
227991	Ferromazo
227992	Escarpes de caballero de la muerte
227993	Empuñadura de ébano de Marduk
227994	Bastón de Calamiedo
227996	Arco de hueso antiguo
227997	Espada de la familia Barovia
227998	Botas Mallasangre
227999	Escarpes de hueso de muerto
228000	Peto de hueso de muerto
228001	Sobrehombros con forma de piedra
228002	Faja de hueso de muerto
228003	Musleras Mallasangre
228004	Grebas Atracavientos
228005	Agarre de Andros
228006	Guanteletes de hueso de muerto
228007	Rebanadoras de gárgolas
228008	Musleras de hueso de muerto
228009	Botas necrópilas
228010	Manto necrópilo
228011	Puños necrópilos
228012	Camisote Mallasangre
228013	Toga necrópila
228014	Cinturón Mallasangre
228015	Garfa de miedo
228016	Anillo opalescente oscuro
228017	Pantalones Humo de calavera
228018	Leotardos necrópilos
228019	Corazón del Maligno
228020	Guanteletes Mallasangre
228021	Espada de bruja
228022	Carga de rector
228023	Abrazo de Alanna
228024	Colmillo silencioso
228025	Coraza de lápida
228026	Espada de Bosque Negro
228027	Rebanadora de hoja de hielo
228028	Hoja de Nigromancia
228029	Hacha de guerra de lápida
228030	Hacha maliciosa
228031	Guantes sombra oscura
228032	Yelmo de hueso
228033	Martillo de Poderío divino
228034	Manijas escalofrío
228036	Agarre de la Muerte
228037	Rodela armadósea
228038	Pantalones de tejido de hierro
228039	Escrito vinculado
228040	Leotardos de fantasma
228041	Leotardos de placas de ánima
228042	Cinta de detención
228044	Leotardos de La Vorágine
228045	Sortija nigromántica
228046	Sortija de dominación de Don Mauricio
228047	Sortija de amalgama
228050	Arco de sátiro
228051	Vara de mediación Quel'dorei
228052	Cortaolas
228053	Yelmo ferviente
228054	Dije de tempestad
228055	Peto energizado
228056	Machete endemoniado
228057	Anillo de Potencia demoníaca
228058	Bufas de hierro grandes
228059	Sobrehombros de vigía de cubil
228060	Capa de heliotropo
228061	Guantes Chispa brillante
228062	Caperuza de Perspicacia
228063	Brazal Alabeo
228064	Escudo de observador
228065	Bufas de ciclón
228066	Guantes de tejido de hierro
228067	Colgante de mago anciano
228068	Cinturón de asaltante
228069	Quijotes reforzados tétricos
228070	Camisote forjado de ogro
228074	Manos de la tentación
228075	Lanza del destino
228076	Anillo de fuego ardiente
228077	Rama onírica
228078	Cáliz maldito
228079	Mantón de hojas
228080	Aro de resina
228081	Semilla venenosa germinada
228082	Hacha Grito de Guerra
228083	Corazón de árbol crepuscular
228084	Extintor miniaturizado
228085	Sortija de la Legión con cambio de fase
228086	Hoja trituradora modificada
228087	Moebius de plata supercargada
228088	Placa identificatoria de operador de trituradora
228089	Acechalunas tallado en madera
228090	Daga ritual de Cenarion
228091	Botas espinosas
228092	Manto druídico
228093	Corazón oscuro de la penumbra
228094	Hoja del Señor del Terror
228100	Mantón del Señor del Fuego
228101	Pellejo del behemoth
228102	Mantón de mayordomo
228103	Grebas de nathrezim
228104	Togas de Elune
228105	Núcleo de llama eterna
228106	Escudo de vida y muerte
228107	Arco largo de cazadora caída
228108	Sombra de Aullavísceras
228109	Musleras de sacrificio
228111	Máscara del destripadioses
228112	Toga de pesadilla
228113	Abrazo frío
228114	Diseño: segadora de arcanita refinada
228117	Diseño: campeona de arcanita refinada
228118	Diseño: guanteletes de mayor aferramiento
228119	Patrón: guanteletes de núcleo demoníaco
228120	Patrón: leotardos de núcleo demoníaco
228121	Patrón: bolsa de paño rúnico reforzada con cuero
228122	El Núcleo de Magma
228123	Epifanía jubilosa
228124	Epifanía onírica
228125	Campeona de arcanita refinada
228126	Epifanía aperitiva
228127	Guardamuñecas de inestabilidad
228128	Martillo del Yunquenegro
228129	Cráneo de llama de las sombras
228130	Resguardo altruista
228131	Resguardo altruista
228132	Papas no-muertas
228133	¿Magma o lava?
228134	Norte de Kalimdor: Una guía exhaustiva
228135	Un estudio de la Luz
228136	¡Ka-bum!
228137	Corazón de Golemagg
228138	El caballero y la dama
228139	Puño de los jurafuegos
228140	La Plaga: ¿Amenaza de no-muertos o incomprendidos?
228141	Nigromancia básica
228142	Tierra y fuego
228143	Espada de llama de las sombras
228144	Nota extraña
228145	Garra derecha de Magmadar
228146	Garra izquierda de Magmadar
228147	Cuerno de Magmadar
228160	Infundidora de fe
228162	Engaño
228163	Broche de la madre del linaje
228165	Jabalina de matadragones
228166	Llave de la ciudad
228168	Mueleengranajes goblin
228169	La Ajustadora de Actitud
228170	Remo improvisado de los Mares del Sur
228171	Portamonedas de Kezan
228172	Resguardo de ilusión Diente Oscuro
228173	Tratado sobre los consagrados
228174	Tratado sobre los devotos
228175	Tratado sobre prontitud sagrada
228176	Tótem de trueno
228177	Tótem de fuego embravecido
228178	Tótem de vitalidad terránea
228179	Tótem de las llanuras
228180	Ídolo del enjambre
228181	Ídolo de desangramiento (felino)
228182	Ídolo de desangramiento (oso)
228183	Ídolo de la arboleda
228184	Cuerda para la ropa goblin
228185	Botella rota de Goblino Noir
228186	Alianza abandonada
228187	Vara del Mar del Sur
228188	Horquilla de Prestor
228189	Ofrenda de Gob
228190	Conocimiento de los Fauces de Madera
228191	Mineral fundido resplandeciente
228214	Monstruo: maza 2M, Fuerza imparable
228222	Vademécum de Valor de Azeroth
228227	Scroll of Overwhelming Power
228229	Hoja afilada de obsidiana
228230	Martillo de los titanes refinado
228239	Toga de poder volátil
228240	Quijotes de Despiertallamas
228242	Anillo pesado de Hierro Negro
228243	Anillo de poder con hechizos
228244	Leotardos de tormenta de maná
228245	Pantalones de escamas de salamandra
228246	Guardamuñecas de Estabilidad
228247	Gargantilla de Iluminación
228248	Sacudetierra
228249	Medallón del poderío férreo
228250	Diseño: guanteletes de mayor aferramiento
228251	Patrón: guanteletes de dragontina verde viva
228252	Marca de asediador
228253	Escarpes del Caminante sobre llamas
228254	Botas templadas de magma
228255	Dije de poder efímero
228256	Cordón de ignición de maná
228257	Guantes viejos de cuero del Núcleo
228258	Bufas del interior de la tierra
228259	Grimorio rúnico de Fuego
228260	Guanteletes de guardia de llamas
228261	Anillo de golpe rápido
228262	Aplastador carmesí
228263	Daga de hechicero
228264	Martillo de piedra de aura
228265	Hoja de brutalidad
228266	Disco de horadador
228267	Destripadora
228268	Sello del archimago
228269	Hoja mágica de cantoazur
228270	Lanzador tiroexplosión
228271	Bastón de dominancia
228272	Tenebrosa
228273	Tronadora
228274	Sortija de cauterización
228275	Grebas forjadas del Núcleo
228276	Patrón: capa ondeante de maestro de oficios
228277	Diente de can del Núcleo
228278	Draga de lava hipertérmicamente aislada
228279	Sobrehombros de guardia de fuego
228280	Capa a prueba de fuego
228281	Guantes de la Llama hipnótica
228282	Fajín de los Secretos susurrados
228283	Bufas de crecimiento salvaje
228284	Guardamuñecas de Auténtico Vuelo
228285	Yelmo del Dador de vida
228286	Sortija de Accuria
228287	Sortija de Sulfuras
228288	Filo del espetahuesos
228289	Gargantilla del Señor del Fuego
228290	Embozo de la niebla envolvente
228291	Corona de Destrucción
228292	Manteo de sangre de dragón
228293	Esencia de la llama pura
228294	Defensor de Malistar
228295	Faja de acometida
228296	Hoja de Perdición
228297	Fragmento de la Llama
228298	Fragmento de la Escama
228299	Segadora espinal
228301	Patrón: avambrazos de Vuelo presto
228303	Patrón: toga de tela lunar incandescente
228304	Esquema: rifle de tirador certero de núcleo ígneo
228305	Diseño: martillo de los titanes refinado
228306	Diseño: profanación
228307	Diseño: buscacorazones mortal
228308	Diseño: tranquilidad
228309	Patrón: coraza de dragontina verde viva
228310	Diseño: guarda de Escarcha endurecida
228311	Diseño: martillo de batalla con encantamiento delicado
228312	Diseño: malla invencible
228313	Diseño: guanteletes de tempestad
228314	Diseño: cresta de guerra del gran jefe
228315	Diseño: hoja sabia del archimago
228316	Patrón: jubón de tela lunar incandescente
228317	Patrón: diadema de tela lunar incandescente
228318	Patrón: leotardos de tela lunar incandescente
228319	Patrón: faja de perspicacia arcana
228323	Moneda de matanza de cobre
228324	Moneda de matanza de oro
228325	Moneda de matanza de plata
228326	Cartera de monedas de matanza de cobre
228327	Cartera de monedas de matanza de plata
228332	Lok'delar, báculo de los Guardianes ancianos
228334	Rhok'delar, arco largo de los Guardianes ancianos
228335	Oración
228336	Anatema
228340	Faja de hielo sin derretir
228345	Leotardos de Supremacía arcana
228347	Tifón
228349	Garra izquierda de Eskhandar
228350	Garra derecha de Eskhandar
228351	Guanteletes de pellejo maldito
228352	Leotardos vil imbuidos
228353	Jaula de cabeza infernal
228354	Medallón Furia abrasadora
228355	Cinturón de piel de guardia apocalíptico
228356	Guardián del Sello Ámbar
228357	Brazal de luz negra
228359	Anillo de Entropía
228360	Pelambre de Eskhandar
228381	Mordedura de frío
228382	Colmillo de los Místicos
228383	Manteo enjundioso
228384	Botas Cieganieve
228385	Corona adornada con cristales
228389	Mantón de Oración
228397	Demoledor empíreo
228410	Hoja terrorífica del Destructor
228432	Silbato de la bestia
228459	Hoja afilada de obsidiana
228460	Segadora espinal
228461	Filo del espetahuesos
228462	Martillo de piedra de aura
228463	Sacudetierra
228464	Sello real de Eldre'Thalas
228465	Sello real de Eldre'Thalas
228466	Sello real de Eldre'Thalas
228467	Sello real de Eldre'Thalas
228468	Leotardos Mohomaraña
228469	Anillo élfico deslustrado
228470	Leotardos Lunargenta
228471	Machacapiedras
228472	Daga de distracción
228473	Gran maza implacable
228474	Toga de oleada de mente
228475	Manto diabólico
228476	Cinturón del archimago bordado
228477	Patrón: cinturón del archimago bordado
228478	Hoja atroz
228479	Leotardos de Destrucción
228480	Corona del Rey ogro
228484	Vara de los magi ogros
228486	Aterrantárboles
228498	Hoja terrorífica del Destructor
228500	Máscara del Imperdonable
228501	Blusa ruiseñor
228502	Flautín de la llama flameante
228503	Prendas de lana de juglar saltarín
228504	Faja arco iris
228505	Capa de tribunal real
228506	Hoja de brutalidad
228508	Martillo del Yunquenegro
228511	Hoja de Perdición
228513	Avambrazos del Sádico
228514	Galochas de Timmy
228515	Lazo de Grimagore
228516	Pacificador
228517	Hoja mágica de cantoazur
228518	Puños de magistrado
228519	Marca de asediador
228520	Manto de ladrón de almas
228521	Manijas con encaje enigmáticas
228522	Obús portátil de Willey
228523	Mensajero bola de cañón
228524	Sello de jefe de correos
228525	Guerrera de jefe de correos
228527	Calzas de jefe de correos
228528	Banda de jefe de correos
228529	Botines de jefe de correos
228530	Musleras de placas de quitina
228531	Fajín Thuzadin
228532	Brazal de Morlune
228533	Collar de caparazones nacarados
228534	Leotardos de can de peste
228535	Hachuela rebanadora de huesos
228536	Estrella de Mystaria
228537	Guanteletes draconianos
228538	Sello de Osahendido
228539	Libro de los Muertos
228540	Corona de Tiranía
228541	Ofrenda del magi élfico
228542	Espetadora Forjacráneos
228543	Hojarruna del Barón Osahendido
228544	Martillo del Gran Cruzado
228545	Yelmo del Gran Cruzado
228546	Embozo de Nathrezim
228547	Toga de tejido de hierro
228548	Cetro de Enfoque interminable
228551	Guerrera de la media luna
228552	Guanteletes de ardid
228553	Yelmo del Verdugo
228554	Guantes de piel de demonio
228555	Hoja fase
228556	Delantal de carnicero
228557	Botas de batalla Dardopresto
228558	Puños de funeral
228559	Cuervo negro
228561	Guanteletes de objetivo real
228562	Bufas con runas demoníacas
228563	Globo de D'sak
228564	Botas de vigía de torre ogro
228565	Anillo de mago
228566	Tiara de fuego estelar
228567	Faja de cincelador
228568	Guanteletes de Backus
228570	Puño de Omokk
228571	Torso del rey chamán
228572	Guardabrazos cuorobronce
228573	Escupeveneno
228574	Dije de evasión
228575	Brazales garraja
228576	Ojo de Telabrasada
228577	Guanteletes dorados
228578	Fajín pluma de polvo
228579	Faja cristalizada
228583	Sobrehombros Golpevero
228584	Dije Furia de ascuas
228585	Marca del Señor de los dragones
228586	Congeladora
228587	Bastón de refugio
228588	Garras de reiver
228589	Corazón de la escama
228590	Manto de hendevidente
228591	Protector Rhombeard
228592	Colmillo de la araña de cristal
228593	Botas de Bailavientos
228594	Botas de precisión de Kayser
228595	Faja de tirador
228596	Cinturón de tejido de hierro
228597	Botas de tejido de hierro
228598	Brazales de tejido de hierro
228599	Corazón de Vermisthalak
228600	El rompe mandíbulas
228601	Guadaña incansable
228602	Botos de llamas
228603	Sierra de fatalidad de Puño Negro
228604	Ojo de Rend
228605	Sobrehombros de huesopúa
228606	Hoja negra de Shahram
228607	Monstruo: espada 2M, básica
228615	Tesoro sobrenatural
228650	Musleras de maestro de guerra
228651	Ajorcas Belinato
228652	Guardián tribal de Dal'Rend
228653	Carga sagrada de Dal'Rend
228659	Báculo con grabados de runas antiguas
228660	Leotardos de maestro del acero
228661	Musleras de Tristam
228662	Guardabrazos de bruma negra
228663	Capa luna de sangre
228664	Manteo de Tejescarcha
228666	Sauce llorón
228667	Sortija tejedaño
228669	Diente de Gnarr
228670	Faja de Brigam
228672	Faja artesanal de maestro herrero
228675	Sortija de Reflexión
228676	Faja Ola feral
228677	Turbante de tejido de hechizos
228678	Emblema dracónico imbuido
228679	Quel'Serrar
228680	Compendio de matar dragones de Nostro
228681	Capucha de tejido de hierro
228682	Bastón de mando de Lord Valthalak
228683	Sortija rúnica de hechicería
228684	Colgante de Celeridad
228685	Colgante de diente de Onyxia
228686	Dije de sangre de Onyxia
228687	Sello de matadragones
228688	Cabeza de Onyxia
228689	Cabeza de Onyxia
228690	La Luz y cómo alterarla
228691	Garona: Un Estudio sobre el Sigilo y la Traición
228692	Códice de Defensa
228693	El libro de cocina del arcanista
228695	Una hoja élfica desafilada
228696	Hoja antigua caliente
228697	Espada antigua tratada
228699	Anillo de Astucia demoníaca
228700	Manto de tejido de hierro
228701	Diente de can del Núcleo
228702	Disco de horadador
228703	Zapatillas de piedrafría
228704	Caperuza de cuero andrajoso
228722	Mano de la Justicia
228746	Mecazancudo verde fosforito
228747	Riendas del dientes de sable dorado
228748	Silbato del raptor sanguino jaspeado
228749	Astilla de Nordrassil
228757	Daga vil
228759	Collar de Eskhandar
228797	Grimorio de Armadura vil
228912	Llave del depósito de artefactos
228922	Bastón de dominancia
228924	Botas Hierro Negro templadas
228925	Botas Hierro Negro templadas
228926	Botas Hierro Negro templadas
228927	Botas Hierro Negro templadas
228928	Botas Hierro Negro templadas
228929	Botas Hierro Negro templadas
228955	Grimorio Piedra angular antigua
228978	Sigilo encantado: aguas fluidas
228979	Sigilo encantado: aguas fluidas
228980	Recubrimiento de escudo conductor
228981	Fórmula: Recubrimiento de escudo conductor
228982	Fórmula: encantar escudo - Ley de la naturaleza
228992	Mochila de pellejo de Onyxia
228993	Patrón: bolsa sin fondo
228994	Bolsa sin fondo
229008	Fórmula: encantar capa: Resistencia al Fuego superior
229009	Fórmula: encantar capa: resistencia a la Naturaleza superior
229055	Seda aranasi deshilachada
229056	Trozo de piedra pómez
229057	Mercancías incautadas
229352	Hallazgos de inteligencia
229362	Llave de almacén
229372	Destripadora
229373	Infundidora de fe
229374	Puño de los jurafuegos
229376	Daga de hechicero
229377	Garra izquierda de Magmadar
229378	Garra derecha de Magmadar
229379	Garra derecha de Eskhandar
229380	Tenebrosa
229381	Tronadora
229382	Draga de lava hipertérmicamente aislada
229415	Suministros de supervivencia
229416	Pelaje cálido
229749	Faro de Verdad
229806	Faro de Verdad
229894	Esmeralda onírica
229897	Pergamino: crear sello de señalización
229906	Escama de bronce deslustrada
229909	Bastón del orden
229910	Guadaña del caos
229911	Comesueños de Caius
229964	Pezuña del Señor demoníaco
229965	El ojo de Az'olgothal
229966	Torque de la Mano de Plata
229971	Bastón de inferno
229972	Bastón de helada blanca
230002	Rematadora letal
230018	Fragmentos de orbe de Mannoroc
230224	Trueno Furioso, espada bendita del Hijo del Viento
230237	Gema Arcana imbuida
230238	El libro negro
230239	Guantes de Evolución rápida
230240	Manto del Conciliábulo Alanegra
230241	Machacapúas
230242	La espada indomable
230243	Gema de Estímulo mental
230244	Sigilo de cambiaformas
230245	Colgante del Dragón Caído
230246	Yelmo de ira infinita
230247	Hoja colmillo dragón
230248	Protector de dragontina roja
230249	Gema dadora de vida
230250	Tótem venenoso
230251	Espaldares de linaje negro
230252	Brazales de Precisión arcana
230253	Apuntacorazones
230254	Maladath, Hoja rúnica del Vuelo Negro
230255	Cinturón de pellejo de dragón tirante
230256	Espaldares de garfa de draco
230257	Anillo de Roca Negra
230269	Gema rejuvenecedora
230270	Bastón de enfoque de Alasombra
230271	Cuchilla de garfa de draco
230272	Pergaminos de Luz cegadora
230273	Cristal de alineación natural
230274	Toga de ceniza negra
230275	Agarre de Faucefogo
230276	Garra del draco negro
230277	Capa de Faucefogo
230278	Musleras del cruzado caído
230279	Musleras enlazadas de primalista
230280	Égida de preservación
230281	Sortija de Concentración forzada
230282	Dije de colmillo de draco
230723	Guantes de llamas de ébano
230725	Baluarte bendito de Malfurion
230726	Culebrina aliento de dragón
230733	Embozo de pensamiento puro
230734	Círculo de fuerza aplicada
230735	Leotardos de tejido de ascuas
230736	Escarabajo trabador de Styleen
230737	Toque de dragón
230738	Heraldo de tragedia
230739	Garra de Angelista
230740	Hombreras de pellejo de dragón tirante
230741	Botas cromáticas
230742	Guantes de pellejo de dragón tirante
230743	Geta fulgurante
230744	Capa tejida con elementium
230745	Faja del cruzado caído
230746	Leotardos potenciados
230747	Espada templada cromáticamente
230751	Obi de ninja
230794	Garra de Chromaggus
230800	Guardarrenes enlazados de primalista
230801	Ashjre'thul, Ballesta de paliza
230802	Baluarte reforzado de elementium
230804	Capa del Señor del linaje
230805	Botas de la Llama de las Sombras
230806	Eslabón de Therazane
230808	Anillo de juicio de Archimtiros
230810	Lágrima de Neltharion
230811	Sortija de elementium puro
230812	Mish'undare, Aro del Despelleja Almas
230813	Bastón de la Llama de las Sombras
230818	Ashkandi, Espada magna de la Hermandad
230837	Crul'shorukh, Filo del Caos
230838	Lok'amir il Romathis
230839	Anillo de maestro matadragones
230840	Medallón de maestro matadragones
230841	Orbe de maestro matadragones
230842	Capa de Poderío dracónico
230843	Botas de pensamiento puro
230844	Gran maza dracónica
230845	Filo de la Fatalidad
230846	Sortija del Dominio oscuro
230847	Recolector de esencia
230848	Chaleco de las Sombras entrelazado
230849	Botas de Ventisca de Ringo
230854	Sortija de Servidumbre
230855	Sello de rabioso Gurubashi
230856	Cinturón de poder sin explotar
230857	Máscara empapada de sangre
230858	Capa de los adoradores Hakkari
230859	Guantes del Atormentado
230860	Poderío de la Tribu
230861	Guanteletes de sacrificio
230862	Ornato Zulian
230863	Cetro Zulian de Ritos
230864	Camisote rúnico manchado de sangre
230865	Colmillo de Venoxis
230866	Escarpines empapados de sangre
230867	Sortija de Zanzil
230868	Hacha de piedra Zulian
230903	Pergamino: Esencia de fuego
230904	Pergamino: CIAENES ED UFOGE
230908	Esencia de fuego imbuida
230909	Esencia de fuego agotada
230911	Triturador de Jeklik
230912	Bufas de animista
230913	Dije ópalo de Jeklik
230914	Botas de pacificador
230915	Sortija de primalista
230916	Botas de furia marina
230917	Togas de ritual sueltas
230918	Toque de Mar'li
230919	Grebas manchadas de sangre
230920	Ojo de Mar'li
230921	Sortija de Jin
230922	Dije de protección
230923	Botas de traidor
230925	Agarre de Thekal
230926	Leotardos de pacificador
230927	Musleras de ritual
230928	Leotardos de furia marina
230929	Sello de Jin
230930	Cercenadora Zulian
230934	Agarre de Arlokk
230939	Voluntad de Arlokk
230941	Palo hudú de Arlokk
230942	Grebas empapadas de sangre
230943	Sortija de ónice de Señor Supremo
230944	Saco de pellejo de pantera
230946	Pergamino: AIEESNC ED SACEARCH
230947	Pergamino: Esencia de escarcha
230948	Esencia de escarcha imbuida
230949	Esencia de escarcha agotada
230984	Bastón del orden incompleto
230989	Defensor del Señor de la Sangre
230991	Alabarda de golpeo
230992	Hoja de guerra de los Hakkari
230993	Aguijón de Mandokir
230994	Leotardos de animista
230995	Mandiletes empapados de sangre
230996	Espaldares empapados de sangre
230997	Falda tintada de sangre
230998	Capa loa Hakkari
230999	Sortija carmesí de Señor Supremo
231000	Sello de primalista
231001	Sello de Zanzil
231002	Brujo de Jin'do
231003	Ojo maligno de Jin'do
231004	Sentencia de Jin'do
231005	Bolsa de mal agüero de Jin'do
231006	Botas de animista
231007	Almófar manchado de sangre
231008	Quijotes manchados de sangre
231009	Leotardos empapados de sangre
231010	Guanteletes empapados de sangre
231011	Guantes tintados de sangre
231012	Abrazo de Señor Supremo
231013	El casquete de aojador
231014	Parche para ojo de escamas de lagarto
231015	Máscara de sarga
231016	Ejecutor de pescado de Nat Pagle
231023	Guardamuñecas de Cólera
231024	Guardarrenes de Cólera
231025	Espaldares de Cólera
231026	Musleras de Cólera
231027	Visera de Cólera
231028	Manoplas de Cólera
231029	Escarpes de Cólera
231030	Coselete de Cólera
231031	Brazales de Cólera
231032	Cinturón de Cólera
231033	Sobrehombros de Cólera
231034	Quijotes de Cólera
231035	Yelmo de Cólera
231036	Guanteletes de Cólera
231037	Grebas de Cólera
231038	Coraza de Cólera
231039	Bufas Colmillo de Sangre
231040	Pechera Colmillo de Sangre
231041	Botas Colmillo de Sangre
231042	Guantes Colmillo de Sangre
231043	Caperuza Colmillo de Sangre
231044	Pantalones Colmillo de Sangre
231045	Cinturón Colmillo de Sangre
231046	Brazales Colmillo de Sangre
231047	Hombreras Colmillo de Sangre
231048	Coselete Colmillo de Sangre
231049	Escarpines Colmillo de Sangre
231050	Manoplas Colmillo de Sangre
231051	Capucha Colmillo de Sangre
231052	Musleras Colmillo de Sangre
231053	Guardarrenes Colmillo de Sangre
231054	Guardamuñecas Colmillo de Sangre
231055	Brazales de acechadragón
231056	Cinturón de acechadragón
231057	Bufas de acechadragón
231058	Musleras de acechadragón
231059	Yelmo de acechadragón
231060	Guanteletes de acechadragón
231061	Grebas de acechadragón
231062	Coraza de acechadragón
231063	Avambrazos de acechadragón
231065	Faja de acechadragón
231066	Espaldares de acechadragón
231067	Pantalones de acechadragón
231068	Escutelaria de acechadragón
231069	Mandiletes de acechadragón
231070	Escarpes de acechadragón
231071	Armadura de acechadragón
231072	Botas de la Némesis
231073	Guantes de la Némesis
231074	Capacete de la Némesis
231075	Leotardos de la Némesis
231076	Togas de la Némesis
231077	Bufas de la Némesis
231078	Cinturón de la Némesis
231079	Brazales de la Némesis
231090	Botines de la Némesis
231091	Manoplas de la Némesis
231092	Capucha de la Némesis
231093	Pantalones de la Némesis
231095	Atuendo de la Némesis
231096	Hombreras de la Némesis
231097	Cordón de la Némesis
231098	Sobrevestes de la Némesis
231100	Cinturón viento abisal
231101	Botas viento abisal
231102	Guantes viento abisal
231103	Corona viento abisal
231104	Pantalones viento abisal
231105	Togas viento abisal
231106	Manto viento abisal
231107	Ataduras viento abisal
231108	Fajín viento abisal
231109	Zapatillas viento abisal
231110	Mitones viento abisal
231111	Máscara viento abisal
231112	Leotardos viento abisal
231113	Vestimentas viento abisal
231114	Sobrehombros viento abisal
231115	Sobrevestes viento abisal
231155	Botas de trascendencia
231156	Manoplas de trascendencia
231157	Halo de trascendencia
231158	Leotardos de trascendencia
231159	Togas de trascendencia
231160	Espaldares de trascendencia
231161	Cinturón de trascendencia
231162	Ataduras de trascendencia
231165	Botines de trascendencia
231166	Guantes de trascendencia
231167	Corona de trascendencia
231168	Pantalones de trascendencia
231169	Atuendo de trascendencia
231170	Manto de trascendencia
231171	Cordón de trascendencia
231172	Brazales de trascendencia
231174	Ataduras de sentencia
231175	Cinturón de sentencia
231176	Bufas de sentencia
231177	Quijotes de sentencia
231178	Corona de sentencia
231179	Guanteletes de sentencia
231180	Escarpes de sentencia
231181	Coraza de sentencia
231182	Avambrazos de sentencia
231183	Guardarrenes de sentencia
231184	Espaldares de sentencia
231185	Musleras de sentencia
231186	Gran yelmo de sentencia
231187	Coselete de sentencia
231188	Manoplas de sentencia
231189	Grebas de sentencia
231190	Brazales de sentencia
231191	Faja de sentencia
231192	Manto de sentencia
231193	Saya de placas de sentencia
231194	Yelmo de sentencia
231195	Guantes de sentencia
231196	Botines de sentencia
231197	Loriga de sentencia
231198	Guanteletes de diez tormentas
231199	Brazales de diez tormentas
231200	Cinturón de diez tormentas
231201	Cubrehombros de diez tormentas
231202	Quijotes de diez tormentas
231203	Casco de diez tormentas
231204	Grebas de diez tormentas
231205	Coraza de diez tormentas
231206	Manoplas de diez tormentas
231207	Guardamuñecas de diez tormentas
231208	Guardarrenes de diez tormentas
231209	Espaldares de diez tormentas
231210	Musleras de diez tormentas
231211	Visera de diez tormentas
231212	Escarpes de diez tormentas
231213	Coselete de diez tormentas
231214	Guantes de diez tormentas
231215	Ataduras de diez tormentas
231216	Cordón de diez tormentas
231217	Manto de diez tormentas
231218	Falda de diez tormentas
231219	Ornato de diez tormentas
231220	Botas de diez tormentas
231221	Abrazo de diez tormentas
231222	Mandiletes de diez tormentas
231223	Avambrazos de diez tormentas
231224	Faja de diez tormentas
231225	Bufas de diez tormentas
231226	Leotardos de diez tormentas
231227	Corona de diez tormentas
231228	Botines de diez tormentas
231229	Armadura de diez tormentas
231230	Coselete de Tempestira
231231	Botas de Tempestira
231232	Manoplas de Tempestira
231233	Casquete de Tempestira
231234	Musleras de Tempestira
231235	Espaldares de Tempestira
231236	Cinturón de Tempestira
231237	Brazales de Tempestira
231238	Armadura de Tempestira
231239	Botines de Tempestira
231240	Guanteletes de Tempestira
231241	Ornato de Tempestira
231242	Leotardos de Tempestira
231243	Bufas de Tempestira
231244	Guardarrenes de Tempestira
231245	Guardamuñecas de Tempestira
231246	Cueros de Tempestira
231247	Sandalias de Tempestira
231248	Mitones de Tempestira
231249	Cornamenta de Tempestira
231250	Falda de Tempestira
231251	Manto de Tempestira
231252	Cordón de Tempestira
231253	Ataduras de Tempestira
231254	Jubón de Tempestira
231255	Apisonadoras de Tempestira
231256	Mandiletes de Tempestira
231257	Capucha de Tempestira
231258	Calzas de Tempestira
231259	Hombreras de Tempestira
231260	Fajín de Tempestira
231261	Sobrevestes de Tempestira
231271	Carrete roto de Nat Pagle
231272	Arpón de Tigule
231273	Punzón de Gri'lek
231274	Molinillo de Gri'lek
231275	Castigador de furia abrasadora
231276	Entorpecedor
231277	Horquilla de Locura
231278	Arco de caza hudú
231279	Atizador de Wushoolay
231280	Talismán de naturaleza de Wushoolay
231281	Talismán de espíritus de Wushoolay
231282	Talismán de magia gélida de Hazza'rah
231283	Talismán de protección de Hazza'rah
231284	Talismán de destrucción de Hazza'rah
231285	Talismán de valor de Gri'lek
231286	Talismán de poderío de Gri'lek
231287	Talismán de artimañas de Renataki
231288	Talismán de devastación de Renataki
231289	Égida del Dios de la Sangre
231293	Destripahombres Hakkari antiguo
231296	Llamasangre
231298	Pergamino de reparación espacial menor
231299	Quijotes empapados de sangre
231300	Capa de Consumo
231301	Colmillo del ignoto
231302	Destructora de enanos Gurubashi
231303	Guanteletes de pacificador
231304	Pergamino: CEPRRAAIÓN LAESAPCI NOREM
231305	Guanteletes de furia marina
231306	Collar de corruptor de alma
231307	El Ojo de Hakkar
231308	Toque del Caos
231309	Hoja de guerra de los Hakkari
231315	Zin'rokh, Destructora de Mundos
231316	Algas de los Mares del Sur encantadas prístinas
231317	Guerrera de haruspex Zandalar
231318	Cinturón de haruspex Zandalar
231319	Brazales de haruspex Zandalar
231320	Cólera de La Vorágine
231321	Manto de depredador Zandalar
231322	Cinturón de depredador Zandalar
231323	Brazales de depredador Zandalar
231324	Joya de Kajaro
231325	Manto de ilusionista Zandalar
231326	Brazaletes de ilusionista Zandalar
231327	Toga de ilusionista Zandalar
231328	Enseña de héroe
231329	Coraza de librepensador Zandalar
231330	Cinturón de librepensador Zandalar
231331	Guardabrazos de librepensador Zandalar
231332	El Ojo que todo lo ve de Zuldazar
231333	Manto de confesor Zandalar
231334	Ataduras de confesor Zandalar
231335	Brazaletes de confesor Zandalar
231336	Dije Zandalar de maestría de las Sombras
231337	Guerrera de sinconcierto Zandalar
231338	Manto de sinconcierto Zandalar
231339	Brazales de sinconcierto Zandalar
231340	Visión inmaculada de Voodress
231341	Camisote de augur Zandalar
231342	Cinturón de augur Zandalar
231343	Brazales de augur Zandalar
231346	Mancha imparable de Kezan
231347	Brazaletes de endemoniado Zandalar
231348	Toga de endemoniado Zandalar
231349	Manto de endemoniado Zandalar
231350	Ira de Mugamba
231351	Guardabrazos de vindicador Zandalar
231352	Cinturón de vindicador Zandalar
231353	Coraza de vindicador Zandalar
231354	Caricia de animista
231355	Equilibrio de animista
231357	Furia de animista
231358	Rugido de animista
231359	Llamada del falcón
231361	Sello de sincretista
231362	Sigilo de sincretista
231363	Blasón de sincretista
231364	Emblema de sincretista
231366	Aura profética
231367	Maldición profética
231368	Abrazo de la muerte
231370	Avance de la muerte
231371	Abrazo de Vodouisant
231372	Sudario de Vodouisant
231373	Encanto de Vodouisant
231375	Vigilancia de Vodouisant
231376	Maleficio hudú
231377	Maldición hudú
231378	Disco dorado resplandeciente
231379	Presencia de poderío
231381	Presencia de valor
231382	Vasija de renacer
231383	Presencia de vista
231384	Furia del halcón
231385	Simulacro del Alma de Dragón
231386	Dragontina negra impecable
231387	Tormentira, Hoja corta santificada del buscaráfagas
231452	Sangre del Iluminado
231460	Rompeplanos de Azgaloth
231466	Códice de brujo Alanegra
231509	Tomo de Cassandra
231512	Ídolo Hakkari primigenio
231513	Sangre de Gri'lek
231514	Diente de Renataki
231515	Melena de Wushoolay
231516	Hilo de sueño de Hazza'rah
231517	Muñeco de vudú agujereado
231518	Muñeco de vudú agujereado
231519	Muñeco de vudú agujereado
231520	Muñeco de vudú agujereado
231521	Muñeco de vudú agujereado
231522	Muñeco de vudú agujereado
231523	Muñeco de vudú agujereado
231524	Muñeco de vudú agujereado
231525	Muñeco de vudú agujereado
231530	Armadura de placas de Señor de la Guerra
231531	Botas de placas de General
231532	Guanteletes de placas de General
231533	Leotardos de placas de General
231534	Sobrehombros de placas de Señor de la Guerra
231535	Celada de placas de Señor de la Guerra
231536	Armadura de placas de Mariscal de campo
231537	Guardahombros de placas de Mariscal de campo
231538	Yelmo de placas de Mariscal de campo
231539	Botas de placas de Mariscal
231540	Musleras de placas de Mariscal
231541	Guanteletes de placas de Mariscal
231543	Pechera de cuero de Mariscal de campo
231544	Lúas de cuero de Mariscal
231545	Máscara de cuero de Mariscal de campo
231546	Guardapiés de cuero de Mariscal
231547	Cubrehombros de cuero de Mariscal de campo
231548	Leotardos de cuero de Mariscal
231549	Coraza de cuero de Señor de la Guerra
231551	Bufas de cuero de Señor de la Guerra
231552	Botines de cuero de General
231553	Yelmo de cuero de Señor de la Guerra
231554	Musleras de cuero de General
231555	Mitones de cuero de General
231557	Espaldares de anillas de Mariscal de campo
231558	Quijotes de anillas de Mariscal
231560	Mandiletes de anillas de Mariscal
231561	Escarpes de anillas de Mariscal
231562	Gran yelmo de anillas de Mariscal de campo
231563	Armadura de anillas de Mariscal de campo
231564	Escarpes de anillas de General
231565	Espaldares de anillas de Señor de la Guerra
231566	Armadura de anillas de Señor de la Guerra
231567	Quijotes de anillas de General
231568	Gran yelmo de anillas de Señor de la Guerra
231569	Mandiletes de anillas de General
231570	Grebas de anillas de General
231571	Yelmo de anillas de Señor de la Guerra
231572	Sobrehombros de anillas de Señor de la Guerra
231573	Camisote de anillas de Señor de la Guerra
231574	Musleras de anillas de General
231575	Abrazaderas de anillas de General
231576	Sobrehombros de anillas de Mariscal de campo
231577	Musleras de anillas de Mariscal
231578	Abrazaderas de anillas de Mariscal
231579	Grebas de anillas de Mariscal
231580	Yelmo de anillas de Mariscal de campo
231581	Camisote de anillas de Mariscal de campo
231582	Toga de tejido de tinieblas de Mariscal de campo
231583	Sobrehombros de tejido de tinieblas de Mariscal de campo
231584	Corona de Mariscal de campo
231585	Botas de tejido de tinieblas de Mariscal
231586	Guantes de tejido de tinieblas de Mariscal
231587	Leotardos de tejido de tinieblas de Mariscal
231588	Pantalones de tejido de tinieblas de General
231589	Guantes de tejido de tinieblas de General
231590	Caperuza de tejido de tinieblas de Señor de la Guerra
231591	Toga de tejido de tinieblas de Señor de la Guerra
231592	Manto de tejido de tinieblas de Señor de la Guerra
231593	Botas de tejido de tinieblas de General
231594	Amito de seda de Señor de la Guerra
231595	Calzas de seda de General
231596	Vestimenta de seda de Señor de la Guerra
231597	Botas de seda de General
231598	Guantes de seda de General
231599	Guanteletes de seda de General
231600	Manijas de seda de General
231601	Capucha de seda de Señor de la Guerra
231602	Bufas de seda de Mariscal de campo
231603	Vestimentas de seda de Mariscal de campo
231604	Nimbo de Mariscal de campo
231605	Leotardos de seda de Mariscal
231606	Borceguíes de seda de Mariscal
231607	Guantes de seda de Mariscal
231608	Guanteletes de seda de Mariscal
231609	Manijas de seda de Mariscal
231610	Botines de satén de General
231611	Cubrehombros de satén de Señor de la Guerra
231612	Togas de satén de Señor de la Guerra
231613	Mandiletes de satén de General
231614	Leotardos de satén de General
231615	Corona de satén de Señor de la Guerra
231616	Corona de satén de Mariscal de campo
231617	Mandiletes de satén de Mariscal
231618	Toga de satén de Mariscal de campo
231619	Leotardos de satén de Mariscal
231620	Botines de satén de Mariscal
231621	Cubrehombros de satén de Mariscal de campo
231622	Caperuza de satén de Mariscal de campo
231623	Manijas de satén de Mariscal
231624	Guerrera de satén de Mariscal de campo
231626	Musleras de satén de Mariscal
231627	Botos de satén de Mariscal
231628	Manto de satén de Mariscal de campo
231630	Botos de satén de General
231631	Manto de satén de Señor de la Guerra
231632	Guerrera de satén de Señor de la Guerra
231633	Manijas de satén de General
231634	Musleras de satén de General
231635	Capucha de satén de Señor de la Guerra
231639	Musleras de láminas de Mariscal
231640	Casco de láminas de Mariscal de campo
231641	Peto de láminas de Mariscal de campo
231642	Bolsa de hierbas de celador
231643	Guantes de láminas de Mariscal
231644	Bolsa de encantamiento de celador
231645	Espaldares de láminas de Mariscal de campo
231646	Grebas de láminas de Mariscal
231647	Leotardos de láminas de Mariscal
231648	Protegecabezas de láminas de Mariscal de campo
231649	Coraza de láminas de Mariscal de campo
231650	Guanteletes de láminas de Mariscal
231651	Sobrehombros de láminas de Mariscal de campo
231652	Escarpes de láminas de Mariscal
231653	Camisote de malla de Señor de la Guerra
231654	Espaldares de malla de Señor de la Guerra
231655	Abrazaderas de malla de General
231656	Grebas de malla de General
231657	Protegecabezas de malla de Señor de la Guerra
231658	Musleras de malla de General
231659	Bufas de malla de Señor de la Guerra
231660	Guanteletes de malla de General
231661	Escarpes de malla de General
231662	Coraza de malla de Señor de la Guerra
231663	Yelmo de malla de Señor de la Guerra
231664	Leotardos de malla de General
231665	Cubrehombros de malla de Señor de la Guerra
231666	Guantes de malla de General
231667	Botas de malla de General
231668	Coselete de malla de Señor de la Guerra
231669	Escutelaria de malla de Señor de la Guerra
231670	Pantalones de malla de General
231671	Grebas de pellejo de dragón de General
231672	Espaldares de pellejo de dragón de Señor de la Guerra
231673	Musleras de pellejo de dragón de General
231674	Guerrera de pellejo de dragón de Señor de la Guerra
231675	Ornato de pellejo de dragón de Señor de la Guerra
231676	Guanteletes de pellejo de dragón de General
231677	Guantes de pellejo de dragón de General
231678	Yelmo de pellejo de dragón de Señor de la Guerra
231679	Armadura de pellejo de dragón de Señor de la Guerra
231680	Pantalones de pellejo de dragón de General
231681	Bufas de pellejo de dragón de Señor de la Guerra
231682	Botas de pellejo de dragón de General
231683	Botines de pellejo de dragón de General
231684	Sobrehombros de pellejo de dragón de Señor de la Guerra
231685	Leotardos de pellejo de dragón de General
231686	Pechera de pellejo de dragón de Señor de la Guerra
231687	Protegecabezas de pellejo de dragón de Señor de la Guerra
231688	Mandiletes de pellejo de dragón de General
231689	Protegecabezas de pellejo de dragón de Mariscal de campo
231690	Pechera de pellejo de dragón de Mariscal de campo
231691	Leotardos de pellejo de dragón de Mariscal
231692	Botines de pellejo de dragón de Mariscal
231693	Sobrehombros de pellejo de dragón de Mariscal de campo
231694	Mandiletes de pellejo de dragón de Mariscal
231695	Yelmo de pellejo de dragón de Mariscal de campo
231696	Armadura de pellejo de dragón de Mariscal de campo
231697	Pantalones de pellejo de dragón de Mariscal
231698	Botas de pellejo de dragón de Mariscal
231699	Bufas de pellejo de dragón de Mariscal de campo
231700	Guantes de pellejo de dragón de Mariscal
231701	Ornato de pellejo de dragón de Mariscal de campo
231702	Guerrera de pellejo de dragón de Mariscal de campo
231703	Musleras de pellejo de dragón de Mariscal
231704	Grebas de pellejo de dragón de Mariscal
231705	Espaldares de pellejo de dragón de Mariscal de campo
231706	Guanteletes de pellejo de dragón de Mariscal
231707	Ataduras draconianas
231708	Cinturón draconiano
231709	Hombreras draconianas
231710	Leotardos draconianos
231711	Caperuza draconiana
231712	Guantes draconianos
231713	Botas draconianas
231714	Toga draconiana
231715	Ataduras primitivas
231716	Cinturón primitivo
231717	Hombreras primitivas
231718	Leotardos primitivos
231719	Yelmo primitivo
231720	Guantes primitivos
231721	Botas primitivas
231722	Guadaña del caos agotada
231723	Cofre primitivo
231724	Ataduras antiguas
231725	Cinturón antiguo
231726	Hombreras antiguas
231727	Leotardos antiguos
231728	Yelmo antiguo
231729	Guantes antiguos
231730	Botas antiguas
231731	Cofre antiguo
231732	Suministros sospechosos
231752	S03 - Monster - Sword, 2H Alliance
231753	Consuelo de Muro Celeste
231754	Cernícalo
231755	Peregrino
231777	Extremidad de qiraji cristalizada
231778	Agua de manantial de montaña
231779	Cólera de Wray
231780	Escrito sobre Crear agua VIII
231781	Alma de trueno
231782	Corona del sucesor
231783	Mantón del Señor del viento
231784	Celda de relámpago
231785	Ecos de la traición
231789	Sigilo del Vigilante
231792	Alma de travesuras
231793	Guadaña del caos agotada (travesuras)
231794	Guadaña del caos agotada (Vacío)
231795	Guadaña del caos agotada (encantamiento)
231796	Guadaña del caos agotada (devoración)
231797	Alma del Vacío
231798	Alma de encantamiento
231799	Alma de devoración
231800	Alma de Des'Altek
231803	Dije de connivencia de Prestor
231806	Flecha abrasadora
231807	Disparo ardoroso
231811	Tratado sobre asombro
231814	Corazón cromático
231815	Desgarrauda
231817	Cortavientos
231823	Guja de Geddon
231828	Runa de Especialización de meditación
231829	Runa de Especialización de sanación
231836	Pergamino resplandeciente de reparación espacial
231837	Tallado de las sombras
231841	Sangre del Iluminado
231842	Báculo de Nandieb
231843	Primer trozo de sigilo
231844	Segundo trozo de sigilo
231845	Tercer trozo de sigilo
231846	Punzón de Gri'lek
231847	Molinillo de Gri'lek
231848	Ejecutor de peces de Nat Pagle
231849	Arpón de Tigule
231850	Voluntad de Arlokk
231851	Agarre de Arlokk
231852	Destructora de enanos Gurubashi
231853	Hoja de guerra de los Hakkari
231854	Zin'rokh, Destructora de Mundos
231855	Colmillo del ignoto
231856	Destripahombres Hakkari antiguo
231857	Toque del Caos
231858	Llamasangre
231859	Brujo de Jin'do
231860	Sentencia de Jin'do
231861	Triturador de Jeklik
231862	Castigador de furia abrasadora
231863	Entorpecedor
231864	Horquilla de Locura
231865	Cetro Zulian de Ritos
231866	Toque de Mar'li
231867	Defensor del Señor de la Sangre
231868	Aguijón de Mandokir
231869	Hoja de guerra de los Hakkari
231870	Alabarda de golpeo
231871	Atizador de Wushoolay
231872	Arco de caza hudú
231873	Hacha de piedra Zulian
231874	Colmillo de Venoxis
231875	Agarre de Thekal
231876	Cercenadora Zulian
231882	Recibo de aparato de supresión
231885	Agonía de Escarcha
231890	Terrestris
231891	Tratado del falcón
231901	Faro de Verdad
231902	Amuleto de Ada
231903	Retazo de tela rasgada
231904	Cuerno deslustrado
231909	Luz estelar cristalizada
231910	Corazón de Azgaloth
231911	Sello de general de la Legión
231912	Hoja del foso
231913	Ojo del observador
231995	Escoria de elementium endurecido
231996	Goblificador suprcargado
232018	Hoja besada por el viento durmiente
232079	Ataduras de Tempestira
232080	Cordón de Tempestira
232081	Manto de Tempestira
232082	Falda de Tempestira
232083	Cornamenta de Tempestira
232084	Mitones de Tempestira
232085	Sandalias de Tempestira
232086	Cueros de Tempestira
232087	Brazales de Tempestira
232088	Cinturón de Tempestira
232089	Espaldares de Tempestira
232090	Musleras de Tempestira
232091	Casquete de Tempestira
232092	Manoplas de Tempestira
232093	Botas de Tempestira
232094	Coselete de Tempestira
232095	Sobrevestes de Tempestira
232096	Fajín de Tempestira
232097	Hombreras de Tempestira
232098	Calzas de Tempestira
232099	Capucha de Tempestira
232100	Mandiletes de Tempestira
232101	Apisonadoras de Tempestira
232102	Jubón de Tempestira
232103	Guardamuñecas de Tempestira
232104	Guardarrenes de Tempestira
232105	Bufas de Tempestira
232106	Leotardos de Tempestira
232107	Ornato de Tempestira
232108	Guanteletes de Tempestira
232109	Botines de Tempestira
232110	Armadura de Tempestira
232111	Avambrazos de acechadragón
232112	Faja de acechadragón
232113	Espaldares de acechadragón
232114	Pantalones de acechadragón
232115	Escutelaria de acechadragón
232116	Mandiletes de acechadragón
232117	Escarpes de acechadragón
232118	Armadura de acechadragón
232119	Brazales de acechadragón
232120	Cinturón de acechadragón
232121	Bufas de acechadragón
232122	Musleras de acechadragón
232123	Yelmo de acechadragón
232124	Guanteletes de acechadragón
232125	Grebas de acechadragón
232126	Coraza de acechadragón
232127	Ataduras viento abisal
232128	Cinturón viento abisal
232129	Manto viento abisal
232130	Pantalones viento abisal
232131	Corona viento abisal
232132	Guantes viento abisal
232133	Botas viento abisal
232134	Togas viento abisal
232135	Sobrevestes viento abisal
232136	Fajín viento abisal
232137	Sobrehombros viento abisal
232138	Leotardos viento abisal
232139	Máscara viento abisal
232140	Mitones viento abisal
232141	Zapatillas viento abisal
232142	Vestimentas viento abisal
232143	Ataduras de sentencia
232144	Cinturón de sentencia
232145	Bufas de sentencia
232146	Quijotes de sentencia
232147	Corona de sentencia
232148	Guanteletes de sentencia
232149	Escarpes de sentencia
232150	Coraza de sentencia
232151	Brazales de sentencia
232152	Faja de sentencia
232153	Manto de sentencia
232154	Saya de placas de sentencia
232155	Yelmo de sentencia
232156	Guantes de sentencia
232157	Botines de sentencia
232158	Loriga de sentencia
232159	Avambrazos de sentencia
232160	Guardarrenes de sentencia
232161	Espaldares de sentencia
232162	Musleras de sentencia
232163	Gran yelmo de sentencia
232164	Manoplas de sentencia
232165	Grebas de sentencia
232166	Coselete de sentencia
232167	Brazales de trascendencia
232168	Cordón de trascendencia
232169	Manto de trascendencia
232170	Pantalones de trascendencia
232171	Corona de trascendencia
232172	Guantes de trascendencia
232173	Botines de trascendencia
232174	Atuendo de trascendencia
232175	Ataduras de trascendencia
232176	Cinturón de trascendencia
232177	Espaldares de trascendencia
232178	Leotardos de trascendencia
232179	Halo de trascendencia
232180	Manoplas de trascendencia
232181	Botas de trascendencia
232182	Togas de trascendencia
232183	Brazales Colmillo de Sangre
232184	Cinturón Colmillo de Sangre
232185	Bufas Colmillo de Sangre
232186	Pantalones Colmillo de Sangre
232187	Caperuza Colmillo de Sangre
232188	Guantes Colmillo de Sangre
232189	Botas Colmillo de Sangre
232190	Pechera Colmillo de Sangre
232191	Guardamuñecas Colmillo de Sangre
232192	Guardarrenes Colmillo de Sangre
232193	Hombreras Colmillo de Sangre
232194	Musleras Colmillo de Sangre
232195	Capucha Colmillo de Sangre
232196	Manoplas Colmillo de Sangre
232197	Escarpines Colmillo de Sangre
232198	Coselete Colmillo de Sangre
232199	Ataduras de diez tormentas
232200	Cordón de diez tormentas
232201	Manto de diez tormentas
232202	Falda de diez tormentas
232203	Ornato de diez tormentas
232204	Guantes de diez tormentas
232205	Botas de diez tormentas
232206	Abrazo de diez tormentas
232207	Brazales de diez tormentas
232208	Cinturón de diez tormentas
232209	Cubrehombros de diez tormentas
232210	Quijotes de diez tormentas
232211	Casco de diez tormentas
232212	Guanteletes de diez tormentas
232213	Grebas de diez tormentas
232214	Coraza de diez tormentas
232215	Avambrazos de diez tormentas
232216	Faja de diez tormentas
232217	Bufas de diez tormentas
232218	Leotardos de diez tormentas
232219	Corona de diez tormentas
232220	Mandiletes de diez tormentas
232221	Botines de diez tormentas
232222	Armadura de diez tormentas
232223	Guardamuñecas de diez tormentas
232224	Guardarrenes de diez tormentas
232225	Espaldares de diez tormentas
232226	Musleras de diez tormentas
232227	Visera de diez tormentas
232228	Manoplas de diez tormentas
232229	Escarpes de diez tormentas
232230	Coselete de diez tormentas
232231	Brazales de la Némesis
232232	Cinturón de la Némesis
232233	Bufas de la Némesis
232234	Leotardos de la Némesis
232235	Capacete de la Némesis
232236	Guantes de la Némesis
232237	Botas de la Némesis
232238	Togas de la Némesis
232239	Sobrevestes de la Némesis
232240	Cordón de la Némesis
232241	Hombreras de la Némesis
232242	Pantalones de la Némesis
232243	Capucha de la Némesis
232244	Manoplas de la Némesis
232245	Botines de la Némesis
232246	Atuendo de la Némesis
232247	Brazales de Cólera
232248	Cinturón de Cólera
232249	Sobrehombros de Cólera
232250	Quijotes de Cólera
232251	Yelmo de Cólera
232252	Guanteletes de Cólera
232253	Grebas de Cólera
232254	Coraza de Cólera
232255	Guardamuñecas de Cólera
232256	Guardarrenes de Cólera
232257	Espaldares de Cólera
232258	Musleras de Cólera
232259	Visera de Cólera
232260	Manoplas de Cólera
232261	Escarpes de Cólera
232262	Coselete de Cólera
232299	Defensor Zulian
232309	Conducto de alma de Renataki
232310	Conducto de alma de Renataki
232311	Capa de pellejo de tigre Zulian
232312	Sangre del Iluminado
232324	Silbato de aves
232344	Vick's VIP Pass
232357	Vengador dracónico
232358	Relicario vacío
232373	Ojo de Sulfuras refinado
232389	Tratado sobre abundancia
232390	Ídolo de enfoque celestial
232391	Ídolo de enfoque felino
232392	Tótem de trueno implacable
232409	Tótem de los elementos
232414	Sable dracodente
232416	Tótem de flujo astral
232419	Tótem de corrientes conductoras
232420	Tratado sobre cólera
232421	Tratado sobre revancha
232423	Ídolo de nutrición
232424	Ídolo de crueldad
232433	Venda de paño rúnico denso
232434	Manual: Venda de paño rúnico denso
232436	Sopa de pinza oscura
232437	Receta: Sopa de pinza oscura
232438	Branquirrojo ahumado
232443	Receta: Branquirrojo ahumado
232454	Emblema de los dioses salvajes
232455	Emblema de deshonor
232456	Emblema de El Ojo Violeta
232457	Emblema de núcleo de mundo
232458	Runa de Santuario mejorado
232459	Runa de Explosión de humo
232460	Runa de Desplazamiento
232461	Runa de Desesperación
232462	Runa de Poder purificador
232549	Informe de tareas logísticas VI
232550	Ashkandi, Espada magna de la Hermandad
232551	Gran maza dracónica
232552	Lok'amir il Romathis
232555	Crul'shorukh, Filo del Caos
232556	Bastón de la Llama de las Sombras
232557	Garra de Chromaggus
232558	Espada templada cromáticamente
232559	Heraldo de tragedia
232561	Garra del draco negro
232562	Cuchilla de garfa de draco
232563	Bastón de enfoque de Alasombra
232564	Maladath, Hoja rúnica del Vuelo Negro
232565	Hoja colmillo dragón
232566	La espada indomable
232567	Machacapúas
232576	Vengador dracónico
232577	Filo de la Fatalidad
232606	Ashjre'thul, Ballesta de paliza
232607	Apuntacorazones
232608	Culebrina aliento de dragón
232610	Fórmula: lustre trol magnífico
232611	Lustre trol magnífico
232652	Zila Amanemodas
233197	Manual de entrenamiento Argenta
233198	Cuerno del Alba
233200	Semilla cantaflor
233201	Globo fulgurante
233206	Yunque de sobrestante
233208	Bola 8 mágica "defectuosa"
233209	Caldero de aguardiente
233211	Caracola espiritual
233213	Magnetita antigua
233215	Trampa de arena explosiva
233216	Rayo congelamático
233217	Incienso de tunelador
233226	Antigua cuerda zandalariana
233250	Rama antigua
233351	Cristal resonador qiraji verde claro
233352	Cristal resonador qiraji azul oscuro
233353	Cristal resonador qiraji celeste
233356	Cristal resonador qiraji naranja
233357	Cristal resonador qiraji crepuscular
233358	Tanque silítido domado
233362	Coraza del dios antiguo
233363	Caparazón del dios antiguo
233364	Piel del dios antiguo
233365	Vísceras intactas
233367	Peritoneo intacto
233368	Entrañas intactas
233369	Ataduras de dominancia qiraji
233370	Ataduras de mando qiraji
233371	Ataduras de soberanía qiraji
233372	Grebas de conquistador
233373	Coraza de conquistador
233374	Musleras de conquistador
233375	Corona de conquistador
233376	Bufas de conquistador
233377	Borceguíes de clamacondenas
233378	Calzas de clamacondenas
233379	Manto clamacondenas
233380	Togas de clamacondenas
233381	Aro de clamacondenas
233382	Leotardos de clamatormentas
233383	Espaldares de clamatormentas
233384	Guardapiés de clamatormentas
233385	Diadema de clamatormentas
233386	Camisote de clamatormentas
233387	Bufas de mortífero
233388	Yelmo de mortífero
233389	Jubón de mortífero
233390	Leotardos de mortífero
233391	Botas de mortífero
233392	Borceguíes del Oráculo
233393	Tiara del Oráculo
233394	Manto del Oráculo
233395	Vestimentas del Oráculo
233396	Calzas del Oráculo
233397	Coraza del Vengador
233398	Corona del Vengador
233399	Grebas del Vengador
233400	Musleras del Vengador
233401	Espaldares del Vengador
233402	Togas Enigma
233403	Hombreras enigma
233404	Aro enigma
233405	Botas enigma
233406	Leotardos enigma
233407	Guardapiés de asediador
233408	Leotardos de asediador
233409	Espaldares de asediador
233410	Diadema de asediador
233411	Camisote de asediador
233412	Yelmo génesis
233413	Hombreras génesis
233414	Botas génesis
233415	Jubón génesis
233416	Calzas génesis
233417	Maza de vida inagotable
233418	Capa de vida inagotable
233419	Sortija de vida inagotable
233420	Capa de la senda oculta
233421	Guadaña de la senda oculta
233422	Sello de la senda oculta
233423	Hoja de secretos oscuros
233424	Mantón de secretos oscuros
233425	Sortija de secretos oscuros
233426	Hoja de justicia eterna
233427	Manteo de justicia eterna
233428	Anillo de justicia eterna
233429	Mazo de sabiduría infinita
233430	Embozo de sabiduría infinita
233431	Anillo de sabiduría infinita
233432	Capa de las sombras ocultas
233433	Daga de las sombras ocultas
233434	Sortija de las sombras ocultas
233435	Martillo de la tormenta inminente
233436	Capa de la tormenta inminente
233437	Anillo de la tormenta inminente
233438	Embozo de los nombres prohibidos
233439	Kris de los nombres prohibidos
233440	Anillo de los nombres prohibidos
233441	Mantón de fuerza implacable
233442	Hoz de fuerza implacable
233443	Sello de fuerza implacable
233490	Adalid de obsidiana
233491	Atracadora de obsidiana
233492	Placa de batalla filoespina
233496	Sobrehombros de bombardeo
233502	Amuleto de Guarda del mal
233503	Colgante del guardián qiraji
233504	Capa de Odio concentrado
233505	Leotardos de Inmersión
233506	Guardamuñecas escamados de alfazaques
233507	Anillo de enjambre de pensamientos
233509	Bastón de los Profetas qiraji
233514	Botas de la voluntad inquebrantable
233515	Martillo de Ji'zhi
233516	Coraza de Aniquilación
233517	Botas de la Profecía cumplida
233518	Botas del Profeta caído
233519	Manteo de la Trinidad
233520	Togas del Triunvirato
233521	Manto ternario
233522	Apariencia del Devorador
233523	Faja de tríada
233524	Toque de Angelista
233559	Guantes de Ebru
233560	Guanteletes de moco
233561	Botas del Héroe caído
233562	Talismán de Angelista
233563	Manto de Poder frénico
233564	Guanteletes cubiertos de bilis
233565	Anillo de oscuridad de Ukko
233566	Manto de la Furia del Desierto
233567	Manto de la Cruzada del Desierto
233568	Jubón de Ejecución presto
233569	Anillo de los Devorados
233570	Escarabajo petrificado
233571	Varita de Nobleza qiraji
233572	Collar de Pureza
233573	Botas recompuestas
233574	Leotardos del Enjambre ulceroso
233575	Togas del Guardia de batalla
233576	Garra de silítido
233577	Cinturón de pellejo qiraji grueso
233578	Yelmo parra reptadora
233579	Guantes de aplicación
233580	Distintivo del Guardaenjambres
233581	Poderío de Sartura
233582	Guanteletes de determinación férrea
233583	Quijotes de Luz llameantes
233584	Leotardos escamados de furia qiraji
233585	Destripador qiraji antiguo
233586	Mandíbula del Atracador de arena
233587	Gargantilla de púas
233588	Capa de los Secretos ocultos
233589	Fetiche del Atracador de arena
233590	Botas de tunelador de colmena
233591	Coselete caparazón de silítido
233592	Manto de la Revancha Horrenda
233593	Espaldares del Inflexible
233594	Togas del Santo guardián
233595	Leotardos escamados de atracador de arena
233596	Tratado sobre purificación
233597	Tótem de Vida
233598	Leotardos cubiertos de baba
233599	Fémur de silítido afilado
233600	Anillo de Furia qiraji
233601	Broche escarabajo
233602	Ídolo de Salud
233603	Guanteletes de Campeón recto
233604	Guanteletes de Kalimdor
233605	Aguijón de Huhuran
233606	Capa de la Colmena dorada
233607	Guantes del Mesías
233608	Guanteletes de pellejo de avispa
233609	Anillo del mártir
233610	Guardamuñecas de colmena Rapiñador
233611	Botas de epifanía
233612	Brazales qiraji de ejecución
233613	Guantes de Devastación de Vek'lor
233614	Cinturón qiraji real
233615	Anillo del Emperador Vek'lor
233616	Cetro real de Vek'lor
233617	Pulseras de redención real
233618	Guantes del Templo oculto
233619	Cinturón regenerador de Vek'nilash
233620	Amuleto de Vek'nilash
233621	Revancha de Kalimdor
233622	Garra del emperador caído
233623	Cinturón del emperador caído
233624	Sombrero perdido de Don Rigoberto
233625	Brazales de escarbador
233626	Larva del Gran Gusano
233627	Jom Gabbar
233628	La coraza del perforador
233629	Bloqueador de escamas de gusano
233630	Capa de los Devorados
233631	Guanteletes de Tormenta oscura
233632	Garra del dios antiguo
233633	Cordón cinturón Acecha ojos
233634	Aguijón de la Muerte
233635	Cinturón de Agonía interminable
233636	Cetro del falso profeta
233637	Guanteletes de Aniquilación
233638	Anillo del destripadioses
233639	Tentáculo derrotado de C'Thun
233640	Filo oscuro de la locura
233641	Capa de Claridad
233642	Marca de C'Thun
233643	Martillo de guerra Anubisath
233644	Atuendo de Ascensión Real
233645	Guantes del Inmortal
233646	Guantes de la Profecía redimida
233647	Neretzek, la Sedienta de Sangre
233648	Anillo de caos de Ritssyn
233649	Fragmento de la estrella caída
233651	Loriga de conquistador
233652	Escarpes de conquistador
233653	Yelmo de conquistador
233654	Escarcelas de conquistador
233658	Espaldares de conquistador
233659	Coselete de mortífero
233660	Botines de mortífero
233661	Visor de mortífero
233662	Pantalones de mortífero
233663	Espaldares de mortífero
233664	Cota guarnecida de asediador
233665	Botines de asediador
233666	Visor de asediador
233667	Quijotes de anillas de asediador
233668	Bufas de asediador
233669	Protegecabezas de clamacondenas
233670	Atuendo de clamacondenas
233671	Hombreras de clamacondenas
233672	Pantalones de clamacondenas
233673	Botines de clamacondenas
233674	Pantalones enigma
233675	Zapatillas enigma
233676	Diadema enigma
233677	Manto enigma
233678	Atuendo enigma
233679	Leotardos del Oráculo
233680	Togas del Oráculo
233681	Hombreras del Oráculo
233682	Corona del Oráculo
233683	Zapatillas del Oráculo
233684	Manto del Vengador
233685	Pantalones de placas del Vengador
233686	Botines del Vengador
233687	Yelmo del Vengador
233688	Loriga del Vengador
233689	Bufas del Vengador
233690	Escarcelas del Vengador
233691	Escarpes del Vengador
233692	Gran yelmo del Vengador
233693	Coselete del Vengador
233694	Coselete de clamatormentas
233695	Visera de clamatormentas
233696	Escarpes de clamatormentas
233697	Bufas de clamatormentas
233698	Quijotes de clamatormentas
233699	Coraza de clamatormentas
233700	Corona de clamatormentas
233701	Botines de clamatormentas
233702	Manto de clamatormentas
233703	Leotardos de anillas de clamatormentas
233704	Abrazo de clamatormentas
233705	Ornato de clamatormentas
233706	Grebas de clamatormentas
233707	Cubrehombros de clamatormentas
233708	Leotardos de malla de clamatormentas
233709	Capucha génesis
233710	Pantalones de cuero génesis
233711	Armadura génesis
233712	Apisonadoras génesis
233713	Bufas génesis
233714	Leotardos génesis
233715	Cueros génesis
233716	Botines génesis
233717	Manto génesis
233718	Ornato génesis
233719	Calzones génesis
233720	Coselete génesis
233721	Grebas génesis
233722	Espaldares génesis
233723	Máscara génesis
233724	Faja de placas aguerrida
233725	Faja de placas aguerrida
233726	Guardabrazos de placas aguerridos
233727	Guardabrazos de placas aguerridos
233728	Insignia cubierta de sangre
233729	Gargantilla cubierta de sangre
233730	Talismán cubierto de sangre
233731	Amuleto cubierto de sangre
233732	Collar cubierto de sangre
233733	Anillo cubierto de sangre
233734	Círculo cubierto de sangre
233735	Aro cubierto de sangre
233736	Sortija cubierta de sangre
233737	Capa cubierta de sangre
233738	Manteo cubierto de sangre
233739	Mantón cubierto de sangre
233740	Embozo cubierto de sangre
233741	Cinturón de láminas aguerrido
233742	Guardabrazos de láminas aguerridos
233743	Muñequeras de láminas aguerridas
233744	Cordón de láminas aguerrido
233745	Pretina de malla aguerrida
233746	Cordón de malla aguerrido
233747	Cinturón de malla aguerrido
233748	Brazales de malla aguerridos
233749	Guardamuñecas de malla aguerridos
233750	Avambrazos de malla aguerridos
233751	Faja de anillas aguerrida
233752	Faja de anillas aguerrida
233753	Cinturón de anillas aguerrido
233754	Cinturón de anillas aguerrido
233755	Guardamuñecas de anillas aguerridos
233756	Guardamuñecas de anillas aguerridos
233757	Brazales de anillas aguerridos
233758	Brazales de anillas aguerridos
233759	Brazales de pellejo de dragón aguerridos
233760	Brazales de pellejo de dragón aguerridos
233761	Cinturón de pellejo de dragón aguerrido
233762	Cinturón de pellejo de dragón aguerrido
233763	Guardarrenes de pellejo de dragón aguerrido
233764	Guardarrenes de pellejo de dragón aguerrido
233765	Cordón de pellejo de dragón aguerrido
233766	Cordón de pellejo de dragón aguerrido
233767	Muñequeras de pellejo de dragón aguerridas
233768	Muñequeras de pellejo de dragón aguerridas
233769	Bandas de pellejo de dragón aguerridas
233770	Bandas de pellejo de dragón aguerridas
233771	Faja de cuero aguerrida
233772	Faja de cuero aguerrida
233773	Braquiales de cuero aguerridos
233774	Braquiales de cuero aguerridos
233775	Puños de seda aguerridos
233776	Puños de seda aguerridos
233777	Fajín de seda aguerrido
233778	Fajín de seda aguerrido
233779	Brazales de satén aguerridos
233780	Brazales de satén aguerridos
233781	Muñequeras de satén aguerridas
233782	Muñequeras de satén aguerridas
233783	Fajín de satén aguerrido
233784	Fajín de satén aguerrido
233785	Cincha de satén aguerrida
233786	Cincha de satén aguerrida
233787	Puños de tejido de tinieblas aguerridos
233788	Puños de tejido de tinieblas aguerridos
233789	Cinturón de tejido de tinieblas aguerrido
233790	Cinturón de tejido de tinieblas aguerrido
233791	Moneda de cobre cubierta de sangre
233793	Hombreras de placas filoespina
233795	Jaula de cabeza filoespina
233796	Destructora de obsidiana
233797	Martillo de tormenta de obsidiana
233798	Hoja sabia de obsidiana
233801	Defensora de obsidiana
233802	Refuerzo para armadura de quitina resplandeciente
233803	Refuerzo para armadura de quitina afilada
233804	Hombreras zarzafilo
233808	Capucha zarzafilo
233813	Cueros zarzafilo
233826	Capucha vampírica
233833	Chal vampírico
233837	Toga vampírica
233956	Bufanda de seda qiraji
233958	Manteo de seda qiraji
233959	Capa de seda qiraji
233960	Mantón de seda qiraji
233962	Frasco de locura
233964	Frasco de conocimiento antiguo
233965	Frasco de los dioses antiguos
233966	Frasco de pena implacable
233967	Elixir del tejón mielero
233968	Elixir del señor de la magia
233969	Elixir de los Ladoférreo
233977	Elixir de prontitud
233984	Megabomba arcana
233985	El fumigador
233986	Bomba de obsidiana
233987	Generador BU3N 4-0ND4
233988	Disco reactivo a la fuerza mejorado
233990	Piedra de velocidad
233991	Lágrima de la Soñadora
233992	Magnetita de represalia
233993	Cronómetro encantado
233994	Broche con rubí incrustado
233995	Pergamino: cólera del enjambre
233996	Repelente encantado
233997	Fórmula: encantar pechera: Estadísticas de vida
233998	Fórmula: encantar guantes: Poder Sagrado
233999	Fórmula: encantar guantes: Poder Arcano
234000	Tomo de rezo encantado
234001	Tótem encantado
234002	Champiñón encantado
234003	Barra de torio de infusión obsidiana
234004	Piedra de pulir de obsidiana
234005	Pólvora densa de obsidiana
234006	Quitina de silítido monstruosa
234007	Quitina de silítido con púas
234008	Seda qiraji
234009	Madeja de seda qiraji
234010	Bilis de gusano de arena antiguo
234011	Veneno de acechador qiraji
234012	Cardo de colmena
234016	Sello del Vuelo Bronce
234017	Sello del Vuelo Bronce
234018	Sello del Vuelo Bronce
234019	Sello del Vuelo Bronce
234020	Sello del Vuelo Bronce
234021	Sello del Vuelo Bronce
234022	Sello del Vuelo Bronce
234023	Sello del Vuelo Bronce
234024	Sello del Vuelo Bronce
234025	Sello del Vuelo Bronce
234026	Sello del Vuelo Bronce
234027	Sello del Vuelo Bronce
234028	Sello del Vuelo Bronce
234029	Sello del Vuelo Bronce
234030	Sello del Vuelo Bronce
234031	Sello del Vuelo Bronce
234032	Sello del Vuelo Bronce
234033	Sello del Vuelo Bronce
234034	Sello del Vuelo Bronce
234035	Sello del Vuelo Bronce
234061	Daga qiraji de sacrificios
234062	Vestimentas del Mar de Dunas
234063	Cinturón del Atracador de arena
234064	Cinturón de la Inquisición
234065	Guardamuñecas de atracador de arena
234066	Guantes de pellejo de silítido fortalecido
234067	Destripahombres de los qiraji
234068	Botas de la Soldado de Caballería
234069	Botas del General qiraji
234070	Brazales de Orden qiraji
234071	Quijotes del comando qiraji
234072	Garra Viento del Sur
234073	Turbante viento polvoriento
234075	Guanteletes del Inamovible
234076	Garfa de Concentración de furia
234077	Coselete de silítido grueso
234078	Guardahombros de quitina
234079	Capa del Salvador
234080	Ojo de Moam
234081	Guanteletes de Viento del Sur
234082	Manto de Maz'Nadir
234083	Anillo de Furia
234084	Yelmo Viento del Sur
234085	Diseño: Garra negra del Destructor
234086	Garra negra del Destructor
234087	Leotardos escamados de obsidiana
234088	Quijotes del Destructor
234089	Trozo de la calavera de Buru
234090	Guantes del Enjambre
234091	Guanteletes escamados babosos
234092	Fetiche de pinchos de quitina
234093	Botas de arenas movedizas
234094	Brazales escamados del Glotón
234095	Chanclos para babosas
234096	Arco de tendón tenso
234097	Aguijón de Ayamiss
234098	Botas del Protector del desierto
234099	Botas de las Arenas ígneas
234100	Yelmo de Recrecimiento
234101	Anillo de los Vientos del desierto
234102	Guanteletes de silítido escamados
234103	Brazales de brutalidad
234104	Ballesta de Fatalidad inminente
234105	Guanteletes de Nueva Vida
234106	Guantes de Sabiduría oscura
234107	Yelmo de Dominación
234108	Leotardos de la ventisca negra
234109	Manto de los Horusath
234110	Brazal de Osirio
234111	Sobrehombros de piedra rúnica
234112	Martillo pulido con arena
234113	Capa Tormenta de Arena
234114	Grilletes del Sinmarcas
234115	Bastón de las Ruinas
234116	Furia del Enjambre olvidado
234117	Botines de nómada errante
234118	Mazo de Autoridad qiraji
234119	Antena de tonificación
234120	Yelmo del Vengador Sagrado
234121	Lanzacoraza de silítido
234122	El kris perdido de Zedd
234123	Almófar de Furia elemental
234124	Vademécum de Veneno oculto II
234129	Leotardos incrustados de ónice
234130	Amuleto de Escudo de las Sombras
234132	Collar de dientes de draco
234133	Botas de esclavo
234134	Turbante de poderío psíquico gnómico
234135	Sortija de Prolavades heladas
234136	Togas Aguaoscura
234137	Colmillo de Korialstrasz
234138	Pena de Cantosombrío
234139	Legado de Cresta Cuervo
234141	Espada rúnica de los rojos
234142	Elixir sin fondo de Tragonublo
234143	Globo de engaño
234144	Incensario del falso profeta
234145	Presea Hakkari cubierta de sangre
234146	Grebas con inscripciones de ácido
234147	Antiguos leotardos corroídos
234148	Guardamuñecas de hueso de dragón
234149	Brazaletes de espuelas de dragón
234150	Guantes de Poder ilusorio
234151	Capa de piel de dragón verde
234152	Martillo de Furia bestial
234153	Bastón de Crecimiento desenfrenado
234154	Piedra de trance
234155	Sello de Malfurion
234156	Botas de la Llanura eterna
234157	Aro de Sueños Inquietos
234158	Collar de corazón de dragón
234159	Ballesta de maderaférrea pulida
234160	Anillo del Inerte
234161	Cinturón de la Ciénaga oscura
234162	Braciles de corteza negra
234163	Pantalones de corazón oscuro
234164	Almete Crecimiento descarriado
234165	Guanteletes de la Luz brillante
234166	Guardapiés malignos
234167	Botas de miedo
234168	Zapatillas de mendigo
234169	Sortija de lágrima mental
234170	Hoja pesadilla
234171	Bufas de cuero artificial
234172	Colmillo dragón esmeralda
234173	Leotardos de la Mente demente
234174	Espaldares con inscripciones de ácido
234175	Cristal de hibernación
234176	Naipe de la Luna Negra: Heroísmo
234177	Naipe de la Luna Negra: Dragón Azul
234178	Naipe de la Luna Negra: La Vorágine
234179	Naipe de la Luna Negra: El Vacío Abisal
234180	Bengala temporal
234181	Diario de cultor Crepuscular
234198	Sello del Vuelo Bronce
234199	Sello del Vuelo Bronce
234200	Sello del Vuelo Bronce
234201	Sello del Vuelo Bronce
234202	Sello del Vuelo Bronce
234220	Diseño: jaula de cabeza filoespina
234221	Diseño: hombreras de placas filoespina
234222	Diseño: placa de batalla filoespina
234223	Diseño: atracadora de obsidiana
234224	Diseño: adalid de obsidiana
234225	Diseño: destructora de obsidiana
234226	Diseño: martillo de tormenta de obsidiana
234227	Diseño: hoja sabia de obsidiana
234228	Diseño: defensora de obsidiana
234235	Patrón: refuerzo para armadura de quitina resplandeciente
234236	Patrón: refuerzo para armadura de quitina afilada
234237	Patrón: capucha zarzafilo
234238	Patrón: hombreras zarzafilo
234239	Patrón: cueros zarzafilo
234240	Patrón: capucha vampírica
234241	Patrón: chal vampírico
234242	Patrón: toga vampírica
234244	Patrón: bufanda de seda qiraji
234249	Patrón: manteo de seda qiraji
234250	Patrón: capa de seda qiraji
234251	Patrón: mantón de seda qiraji
234252	Receta: frasco de pena implacable
234253	Receta: frasco de conocimiento antiguo
234255	Receta: frasco de los dioses antiguos
234256	Receta: frasco de locura
234257	Receta: elixir del tejón mielero
234258	Receta: elixir del señor de la magia
234259	Receta: elixir de los Ladoférreo
234260	Receta: elixir de prontitud
234261	Esquema: megabomba arcana
234262	Esquema: el fumigador
234263	Esquema: bomba de obsidiana
234264	Esquema: generador BU3N 4-0ND4
234265	Esquema: disco reactivo a la fuerza mejorado
234266	Fórmula: piedra de velocidad
234267	Fórmula: lágrima de la Soñadora
234268	Fórmula: magnetita de represalia
234269	Fórmula: cronómetro encantado
234270	Fórmula: broche con rubí incrustado
234271	Fórmula: pergamino: cólera del enjambre
234272	Fórmula: repelente encantado
234275	Fórmula: tomo de rezo encantado
234276	Fórmula: tótem encantado
234277	Fórmula: champiñón encantado
234278	Manual: barra de torio fundida con infusión de obsidiana
234279	Diseño: piedra de pulir de obsidiana
234280	Esquema: pólvora densa de obsidiana
234288	Cinturón parraférrea
234289	Diseño: cinturón parraférrea
234290	Guantes parraférrea
234291	Diseño: guantes parraférrea
234292	Coraza parraférrea
234293	Diseño: coraza parraférrea
234294	Brazales acecharenas
234295	Patrón: brazales acecharenas
234296	Guanteletes acecharenas
234297	Patrón: guanteletes acecharenas
234298	Coraza acecharenas
234299	Patrón: coraza acecharenas
234300	Brazales escupefuego
234301	Patrón: brazales escupefuego
234302	Guanteletes escupefuego
234303	Patrón: guanteletes escupefuego
234304	Coraza escupefuego
234305	Patrón: coraza escupefuego
234306	Cinturón zarzal
234307	Patrón: cinturón zarzal
234308	Botas zarzal
234309	Patrón: botas zarzal
234310	Yelmo zarzal
234311	Patrón: yelmo zarzal
234312	Sobrehombros nemorosos
234314	Patrón: sobrehombros nemorosos
234315	Corona nemorosa
234316	Patrón: corona nemorosa
234317	Jubón nemoroso
234318	Patrón: jubón nemoroso
234319	Cinturón de obsidiana pesado
234320	Diseño: cinturón de obsidiana pesado
234321	Cinturón de obsidiana ligero
234322	Diseño: cinturón de obsidiana ligero
234324	Coraza de escamas oníricas
234325	Patrón: coraza de escamas oníricas
234428	Buscacorazones de obsidiana
234429	Diseño: buscacorazones de obsidiana
234434	Escopeta de obsidiana
234435	Esquema: escopeta de obsidiana
234436	Sello del Vuelo Bronce
234437	Sello del Vuelo Bronce
234438	Sello del Vuelo Bronce
234439	Sello del Vuelo Bronce
234440	Sello del Vuelo Bronce
234444	Veneno oculto II
234445	Patrón: madeja de seda qiraji
234447	Vara de transformación de Burbujas
234458	Diseño: escudo dentado de obsidiana
234459	Escudo dentado de obsidiana
234460	Guerrera de malla de obsidiana
234461	Diseño: guerrera de malla de obsidiana
234462	Golpe de tierra
234463	Cólera de Cenarius
234464	Vara de burbujas de Burbujas
234465	Riendas del tigre espectral presto
234467	Vara de dragones de Burbujas
234468	Ídolo de poder osuno
234469	Ídolo de ferocidad felina
234474	Ídolo de ira sideral
234475	Tratado sobre el exorcista
234476	Tratado sobre santidad
234477	Tratado sobre rectitud
234478	Tótem de los golpes estruendosos
234479	Tótem de magma fluido
234480	Tótem de trueno piroclástico
234481	Patrón: falda de escamas oníricas
234482	Falda de escamas oníricas
234483	Patrón: brazales de escamas oníricas
234484	Brazales de escamas oníricas
234485	Mitones de escamas oníricas
234486	Patrón: mitones de escamas oníricas
234487	Visor de escamas oníricas
234488	Diseño: visor de escamas oníricas
234542	Espada magna de Gran Señor de la Guerra
234543	Hacha de batalla de Gran Señor de la Guerra
234545	Pulverizador de Gran Señor de la Guerra
234546	Destructora de Gran Señor de la Guerra
234547	Pica de jabalíes de Gran Señor de la Guerra
234548	Atizador de jabalíes de Gran Señor de la Guerra
234549	Bastón de guerra de Gran Señor de la Guerra
234550	Hoja de hechizo de Gran Señor de la Guerra
234551	Maza de batalla de Gran Señor de la Guerra
234552	Hoja de Gran Señor de la Guerra
234553	Hoja rauda de Gran Señor de la Guerra
234554	Cuchilla de Gran Señor de la Guerra
234555	Cachiporra de Gran Señor de la Guerra
234556	Navaja de Gran Señor de la Guerra
234557	Garra derecha de Gran Señor de la Guerra
234558	Garra izquierda de Gran Señor de la Guerra
234559	Arco corvo de Gran Señor de la Guerra
234560	Ballesta de Gran Señor de la Guerra
234561	Barrecaminos de Gran Señor de la Guerra
234562	Escudo muro de Gran Señor de la Guerra
234563	Escrito sobre destrucción de Gran Señor de la Guerra
234564	Escrito sobre alivio de Gran Señor de la Guerra
234565	Mandoble de Gran mariscal
234566	Taladora de Gran mariscal
234567	Martillo de batalla de Gran mariscal
234568	Demoledor de Gran mariscal
234569	Guja de Gran mariscal
234570	Arma de asta de Gran mariscal
234571	Báculo de Gran mariscal
234574	Hoja de mago de Gran mariscal
234576	Martillo de guerra de Gran mariscal
234578	Tizona de Gran mariscal
234579	Hoja presta de Gran mariscal
234580	Hacha de mano de Gran mariscal
234581	Castigadora de Gran mariscal
234582	Puntilla de Gran mariscal
234583	Hoja de mano derecha de Gran mariscal
234584	Hoja de mano izquierda de Gran mariscal
234585	Disparo certero de Gran mariscal
234586	Ballesta de repetición de Gran mariscal
234587	Culebrina de Gran mariscal
234588	Égida de Gran mariscal
234589	Escrito sobre poder de Gran mariscal
234590	Escrito sobre restauración de Gran mariscal
234614	Emblema tocado por el Vacío
234650	Destripador qiraji antiguo
234747	Puño de Cenarius
234748	Brazales de roca profunda
234749	Orbe Calmaterra
234760	Brazales de Furia de roca
234761	Poderío de Cenarius
234779	Gracia de la Tierra
234780	Sortija de poder terráneo
234782	Jubón Poder terrenal
234785	Guantes de Poder de la tierra
234786	Sortija de Cólera de tierra
234788	Capa de tejido de tierra
234792	Cercenadora Ravenholdt
234793	Chafarote de Shivsprocket
234797	El atizador Truenedera
234798	Prima de Condemulus
234799	Ballesta de repetición de recarga de Fahrad
234800	Martillo de cultivo de Simone
234801	Amuleto del Dios caído
234802	Capa del Dios caído
234803	Anillo del Dios caído
234804	Hacha de guerra qiraji bendita
234805	Mosquete qiraji bendito
234806	Pugio qiraji bendito
234807	Baluarte qiraji bendito
234808	Bastón de acólito qiraji bendito
234809	Bastón de augur qiraji bendito
234810	Martillo de guerra qiraji bendito
234811	Talismán del Mar de Dunas
234812	Amuleto del Mar de Dunas
234813	Gargantilla del Mar de Dunas
234814	Colgante del Mar de Dunas
234960	Riendas del tigre cubierto de sangre
234961	Silbato del raptor cubierto de sangre
234962	Vestimentas decoradas con jade
234963	Quijotes con extrañas inscripciones
234964	Sello del Vuelo Bronce
234965	Sello del Vuelo Bronce
234966	Sello del Vuelo Bronce
234967	Sello del Vuelo Bronce
234968	Sello del Vuelo Bronce
234974	Bastón de los Profetas qiraji
234975	Martillo de Ji'zhi
234976	Varita de Nobleza qiraji
234977	Garra de silítido
234978	Mandíbula del Atracador de arena
234979	Fémur de silítido afilado
234980	Aguijón de Huhuran
234981	Revancha de Kalimdor
234983	Larva del Gran Gusano
234984	Aguijón de la Muerte
234985	Filo oscuro de la locura
234986	Martillo de guerra Anubisath
234987	Neretzek, la Sedienta de Sangre
234989	Daga qiraji de sacrificios
234990	Destripahombres de los qiraji
234991	Arco de tendón tenso
234992	Aguijón de Ayamiss
234993	Ballesta de Fatalidad inminente
234994	Martillo pulido con arena
234995	Bastón de las Ruinas
234996	Mazo de Autoridad qiraji
234997	Lanzacoraza de silítido
234998	El kris perdido de Zedd
234999	Martillo de guerra qiraji bendito
235000	Bastón de augur qiraji bendito
235001	Bastón de acólito qiraji bendito
235002	Pugio qiraji bendito
235003	Hacha de guerra qiraji bendita
235004	Mosquete qiraji bendito
235005	Hoz de fuerza implacable
235006	Daga de las sombras ocultas
235007	Guadaña de la senda oculta
235008	Kris de los nombres prohibidos
235009	Martillo de la tormenta inminente
235010	Mazo de sabiduría infinita
235011	Hoja de justicia eterna
235012	Maza de vida inagotable
235013	Hoja de secretos oscuros
235014	Cetro del falso profeta
235039	Diseño: coraza gruesa de obsidiana
235040	Coraza gruesa de obsidiana
235045	Atavío imperial qiraji
235046	Armamentos imperiales qiraji
235047	Guantes del Profeta caído
235048	Cabeza de Osirio el Sinmarcas
235049	Objeto envuelto en pesadillas
235133	Fórmula: tratado sobre rectitud
235134	Fórmula: tratado sobre el exorcista
235135	Fórmula: tratado sobre santidad
235136	Fórmula: tótem de trueno piroclástico
235137	Fórmula: tótem de los golpes estruendosos
235138	Fórmula: tótem de magma fluido
235139	Fórmula: ídolo de ira sideral
235140	Fórmula: ídolo de ferocidad felina
235141	Fórmula: ídolo de poder osuno
235142	Moneda de plata cubierta de sangre
235143	Moneda de oro cubierta de sangre
235144	Cartera de monedas de cobre cubiertas de sangre
235145	Cartera de monedas de plata cubiertas de sangre
235275	Baraja de Portales
235276	Baraja de Elementales
235277	Baraja de Señores de la Guerra
235278	Baraja de Bestias
235282	Antena de tonificación
235473	Barricada de Gran mariscal
235474	Barricada de Gran Señor de la Guerra
235476	Rebanadora de Gran Señor de la Guerra
235477	Partehuesos de Gran Señor de la Guerra
235478	Chafarote de Gran Señor de la Guerra
235479	Chafarote de Gran mariscal
235480	Partehuesos de Gran mariscal
235481	Rebanadora de Gran mariscal
235497	Jarabe de las arenas
235511	Cristal resonador qiraji amarillo impecable
235512	Cristal resonador qiraji verde impecable
235513	Cristal resonador qiraji azul impecable
235514	Cristal resonador qiraji rojo impecable
235517	Antorcha
235526	Fórmula: encantar brazales: poder de hechizos
235528	Fórmula: encantar brazales: agilidad
235529	Mira de obsidiana
235530	Esquema: mira de obsidiana
235597	Notas de hechizo: Congelación profunda
235598	Notas de hechizo: Venas heladas
235599	Notas de hechizo: Anomalía temporal
235600	Runa de Tormenta divina
235601	Runa de Fanatismo
235602	Runa de Martillo del honrado
235603	Runa de Venganza recta
235604	Runa de Escudo de rectitud
235605	Runa de Choque y terror
235785	"Llave" de jaula de Paso de la Muerte
235786	Curiosidad de Karazhan
235787	Rama de maderaférrea antigua
235788	Fuego fatuo entusiasta
235789	Llama de la vida
235790	Marca de fuego encantada
235825	Jarabe de las arenas
235852	Cartera violeta
235867	Trozo de papiro
235868	Baluarte de ira
235869	La capucha del maestro
235870	Yelmo de anillas ruidosas
235871	Yelmo de la muerte ceñido
235872	Braciles de acechador
235873	Esposas de la cripta
235874	Manijas de cultista
235875	Guantes de cavatumbas
235876	Manoplas de pecador
235877	Guanteletes de fanático
235878	Cinturón maléfico
235879	Anillas ágiles
235880	Suelas indigentes
235881	Botines aterradores
235882	Pasos traqueteantes
235883	Escarpín de explorapozos
235884	Sello espectral
235885	Anillo espantoso
235886	Broche de Kaigy
235887	Gargantilla de Barian
235888	Garrote aporreador
235889	Cayado de sirviente
235890	Aguja de tejesombras
235891	Vieja confiable
235892	Columna de jinete oscuro
235893	Grimorio vinculasombras
235894	Óbito del orador del sino
236002	Lista de componentes
236005	Coraza acorator
236006	Quijotes acorator
236007	Casco acorator
236008	Espaldares acorator
236009	Escarpes acorator
236010	Guanteletes acorator
236011	Guardarrenes acorator
236012	Brazales acorator
236013	Anillo del acorator
236014	Loriga acorator
236015	Escarcelas acorator
236016	Cuernos acorator
236017	Sobrehombros acorator
236018	Grebas acorator
236019	Mandiletes acorator
236020	Cinturón acorator
236021	Muñequeras acorator
236022	Sortija del acorator
236023	Coraza Segahuesos
236024	Quijotes Segahuesos
236025	Casco Segahuesos
236026	Espaldares Segahuesos
236027	Escarpes Segahuesos
236028	Guanteletes Segahuesos
236029	Guardarrenes Segahuesos
236030	Brazales Segahuesos
236031	Anillo Segahuesos
236032	Cinturón Segahuesos
236033	Botines Segahuesos
236034	Sortija Segahuesos
236035	Manto Segahuesos
236036	Leotardos Segahuesos
236037	Máscara Segahuesos
236038	Mandiletes Segahuesos
236039	Coselete Segahuesos
236040	Guardamuñecas Segahuesos
236041	Anillo de acechacriptas
236042	Guardamuñecas de acechacriptas
236043	Guerrera de acechacriptas
236044	Bufas de acechacriptas
236045	Musleras de acechacriptas
236046	Celada de acechacriptas
236047	Manoplas de acechacriptas
236048	Faja de acechacriptas
236049	Botas de acechacriptas
236050	Avambrazos de acechacriptas
236051	Cinturón de acechacriptas
236052	Espaldares de acechacriptas
236053	Leotardos de acechacriptas
236054	Visor de acechacriptas
236055	Guanteletes de acechacriptas
236056	Sortija de acechacriptas
236057	Grebas de acechacriptas
236058	Coraza de acechacriptas
236059	Botines corazón de peste
236060	Leotardos corazón de peste
236061	Ataduras corazón de peste
236062	Toga corazón de peste
236063	Guantes corazón de peste
236064	Aro corazón de peste
236065	Hombreras corazón de peste
236066	Cinturón corazón de peste
236067	Anillo corazón de peste
236068	Guardamuñecas corazón de peste
236069	Guardarrenes corazón de peste
236070	Manto corazón de peste
236071	Pantalones corazón de peste
236072	Corona corazón de peste
236073	Manoplas corazón de peste
236074	Aro corazón de peste
236075	Botas corazón de peste
236076	Atuendo corazón de peste
236077	Ataduras de Fuego de Escarcha
236078	Cinturón de Fuego de Escarcha
236079	Leotardos de Fuego de Escarcha
236080	Botines de Fuego de Escarcha
236081	Toga de Fuego de Escarcha
236082	Guantes de Fuego de Escarcha
236083	Aro de Fuego de Escarcha
236084	Hombreras de Fuego de Escarcha
236085	Anillo de Fuego de Escarcha
236087	Cubremuñecas de Fuego de Escarcha
236088	Guardarrenes de Fuego de Escarcha
236089	Manto de Fuego de Escarcha
236090	Pantalones de Fuego de Escarcha
236091	Caperuza de Fuego de Escarcha
236092	Mitones de Fuego de Escarcha
236093	Sortija de Fuego de Escarcha
236094	Botas de Fuego de Escarcha
236095	Atuendo de Fuego de Escarcha
236097	Toga de fe
236098	Cinturón de fe
236099	Sandalias de fe
236100	Ataduras de fe
236101	Leotardos de fe
236102	Hombreras de fe
236103	Diadema de fe
236104	Guantes de fe
236105	Anillo de fe
236106	Muñequeras de fe
236107	Faja de fe
236108	Manto de fe
236109	Pantalones de fe
236110	Corona de fe
236111	Manos de fe
236112	Sortija de fe
236113	Botas de fe
236114	Atuendo de fe
236115	Guerrera de redención
236116	Anillo de redención
236117	Celada de redención
236118	Manoplas de redención
236119	Guardamuñecas de redención
236120	Faja de redención
236121	Musleras de redención
236122	Bufas de redención
236123	Botas de redención
236124	Avambrazos de redención
236125	Cinturón de redención
236126	Hombreras de placas de redención
236127	Leotardos de redención
236128	Yelmo de redención
236129	Guantes de redención
236130	Sortija de redención
236131	Grebas de redención
236132	Coraza de redención
236133	Brazales de redención
236134	Guardarrenes de redención
236135	Espaldares de redención
236136	Quijotes de redención
236137	Corona de redención
236138	Guanteletes de redención
236139	Aro de redención
236140	Escarpes de redención
236141	Coselete de redención
236142	Manoplas Rompeterra
236143	Musleras Rompeterra
236144	Celada Rompeterra
236145	Bufas Rompeterra
236146	Botas Rompeterra
236147	Guerrera Rompeterra
236148	Faja Rompeterra
236149	Guardamuñecas Rompeterra
236150	Anillo del Trizaterrador
236151	Ataduras Rompeterra
236152	Cordón Rompeterra
236153	Manto Rompeterra
236154	Falda Rompeterra
236155	Corona Rompeterra
236156	Mitones Rompeterra
236157	Sortija del Trizaterrador
236158	Grebas Rompeterra
236159	Abrazo Rompeterra
236160	Brazales Rompeterra
236162	Guardarrenes Rompeterra
236163	Espaldares Rompeterra
236164	Quijotes Rompeterra
236165	Visera Rompeterra
236166	Guantes Rompeterra
236167	Aro del Trizaterrador
236168	Escarpes Rompeterra
236169	Coselete Rompeterra
236170	Avambrazos Rompeterra
236171	Cinturón Rompeterra
236172	Cubrehombros Rompeterra
236173	Leotardos Rompeterra
236174	Casco Rompeterra
236175	Mandiletes Rompeterra
236176	Sello del Trizaterrador
236177	Botines Rompeterra
236179	Armadura Rompeterra
236182	Celada Caminasueños
236183	Guardamuñecas Caminasueños
236184	Manoplas Caminasueños
236185	Botas Caminasueños
236186	Guerrera Caminasueños
236187	Faja Caminasueños
236188	Musleras Caminasueños
236189	Bufas Caminasueños
236190	Anillo del Caminasueños
236192	Ataduras Caminasueños
236193	Cordón Caminasueños
236194	Manto Caminasueños
236195	Falda Caminasueños
236196	Caperuza Caminasueños
236197	Mitones Caminasueños
236198	Sortija del Caminasueños
236199	Sandalias Caminasueños
236200	Cueros Caminasueños
236201	Brazales Caminasueños
236202	Guardarrenes Caminasueños
236203	Espaldares Caminasueños
236204	Leotardos Caminasueños
236205	Ornato Caminasueños
236206	Guanteletes Caminasueños
236207	Aro del Caminasueños
236208	Escarpes Caminasueños
236209	Armadura Caminasueños
236210	Sobrevestes Caminasueños
236211	Fajín Caminasueños
236212	Hombreras Caminasueños
236213	Calzas Caminasueños
236214	Capucha Caminasueños
236215	Mandiletes Caminasueños
236216	Sello del Caminasueños
236217	Apisonadoras Caminasueños
236218	Jubón Caminasueños
236219	Presagista de la Fatalidad
236220	Atuendo de necrocaballero
236221	Servobrazo mal colocado
236222	Guerrera de piel de necrófago
236223	Anillo de la llama eterna
236224	Rodela estigia
236225	Faja de la furia elemental
236226	Espaldares de la furia elemental
236227	Cinturón del Gran Cruzado
236228	Bufas del Gran Cruzado
236229	Leotardos del Gran Cruzado
236230	Leotardos de la furia elemental
236231	Coraza profanada
236232	Guardarrenes profanados
236233	Guanteletes profanados
236234	Escarpes profanados
236235	Brazales profanados
236236	Casco profanado
236237	Espaldares profanados
236238	Quijotes profanados
236239	Botines profanados
236240	Hombreras profanadas
236241	Diadema profanada
236242	Toga profanada
236243	Guantes profanados
236244	Cinturón profanado
236245	Ataduras profanadas
236246	Leotardos profanados
236247	Guardamuñecas profanados
236248	Botas profanadas
236249	Celada profanada
236250	Manoplas profanadas
236251	Guerrera profanada
236252	Faja profanada
236253	Musleras profanadas
236254	Bufas profanadas
236255	Guardamuñecas de Venganza
236256	Toque de Escarcha
236257	Gema de Nerubis
236258	Capa de seda de demonio de cripta
236259	Sortija de Plegarias sin respuesta
236260	Espaldares Deliriohelado
236261	Colgante de piedra malicia
236262	Hombreras polares
236263	Remordimiento de viuda
236264	El abrazo de la viuda
236265	Espada de ánima
236266	Colgante de Nombres Olvidados
236267	Toga tejida con cristal
236268	Beso de la araña
236269	Colmillo de Maexxna
236270	Hachuela de hueso partido
236271	Tratado sobre luz
236272	Capa de la Plaga
236273	Sortija de lo Inevitable
236274	Sortija de granizo
236275	Corazón gélido de Noth
236276	Tótem de agua corriente
236277	Collar de Necropsia
236278	Ornato glacial
236279	Sombrero de preceptor
236280	Quijotes de Matanza
236281	Almófar de escamas heladas
236282	Reflejo de Loatheb
236283	Anillo de fervor espiritual
236284	Bastón de azufre
236285	El Ojo de Nerub
236286	Sortija de fuerzas antinaturales
236287	División
236288	El portador de peste
236289	Capa de Sutura
236290	Varita de Fortunas
236291	Sortija de reanimación
236292	Bruma de medianoche
236293	Inyector tóxico
236294	Bufas de escamas heladas
236295	Manto glacial
236296	Acuerdo con la Muerte
236297	El fin de los sueños
236298	Manto cubierto de Escarcha
236299	Mandoble de Poderío profano
236300	Collera perdida de Gluth
236301	Compendio de Mano de Poder
236302	Ojo de Disminución
236303	Leotardos de polaridad
236304	Caja torácica de abominación con placas
236305	Aguja Crepuscular
236306	El castigador
236307	Velo de eclipse
236308	Ídolo de Longevidad
236309	Faja del Mentor
236310	Varita de la Muerte susurrante
236311	Sello del Defensor caído
236312	Iblis, Hoja del serafín caído
236313	Las ataduras del cosechador de almas
236314	Botas de desplazamiento
236315	Casco polar
236316	Collar de sádico
236317	Vis'era, la Sacatripas
236318	Sello del condenado
236319	Leotardos de Apocalipsis
236320	Calor de Perdón
236321	Gran maza del cruzado redimido
236322	Hilo de alma
236323	Temple de la Plaga
236324	Poder de la Plaga
236325	Entereza de la Plaga
236326	Poderío de la Plaga
236327	Capa de la Necrópolis
236328	Ojo izquierdo de Sapphiron
236329	Ojo de los muertos
236330	Ojo derecho de Sapphiron
236331	La esencia contenida de Sapphiron
236333	Embozo de Dominio
236334	Blasón de destripador
236335	Puños del Inflexible
236336	La cara de la Muerte
236337	Glifo de Desvío
236338	Garra de vermis de escarcha
236339	Gressil, Alba de la Ruina
236340	Poderío de Menethil
236341	El frío voraz
236342	Dije iracundo de Tempestira
236343	Caída del rey
236344	Esclavizador nerubiano
236345	Gema de Inocentes atrapados
236346	Buscador de almas
236347	Escudo de Condena
236348	Martillo de El Vacío Abisal
236349	Dedo condena
236350	La filacteria de Kel'Thuzad
236351	Marca del campeón
236352	Marca del campeón
236354	Sello del Alba de aspirante
236355	Sello del Alba de iniciado
236356	Sello del Alba de escudero
236357	Sello del Alba de caballero
236358	Sello del Alba de templario
236360	Sello del Alba de campeón
236361	Sello del Alba de vanguardia
236362	Sello del Alba de cruzado
236363	Sello del Alba de comandante
236364	Sello del Alba de alto señor
236374	Sello del Alba de comandante
236375	Sello del Alba de alto señor
236376	Sello del Alba de cruzado
236378	Sello del Alba de vanguardia
236379	Sello del Alba de campeón
236380	Sello del Alba de templario
236382	Sello del Alba de caballero
236383	Sello del Alba de escudero
236384	Sello del Alba de iniciado
236385	Sello del Alba de aspirante
236386	Sello del Alba de alto señor
236388	Sello del Alba de comandante
236389	Sello del Alba de cruzado
236390	Sello del Alba de vanguardia
236391	Sello del Alba de campeón
236392	Sello del Alba de templario
236393	Sello del Alba de caballero
236394	Sello del Alba de escudero
236395	Sello del Alba de iniciado
236396	Sello del Alba de aspirante
236397	Restos de valor
236398	Atiesh, gran báculo del Guardián
236399	Atiesh, gran báculo del Guardián
236400	Atiesh, gran báculo del Guardián
236401	Atiesh, gran báculo del Guardián
236414	Cajón de suministros de Minahonda dañado
236417	Alma del táctico
236418	Alma del veterano de guerra
236419	Alma del augur de batalla
236420	Alma del buscasangre
236421	Alma del titán
236422	Alma del destructor
236423	Alma del lazomortal
236424	Alma del sanguinista
236425	Alma del bloqueador prístino
236426	Alma del salvaje
236427	Alma de animosidad
236428	Alma del deflector
236429	Alma de revancha
236430	Alma del incesante
236431	Alma del portatruenos
236432	Alma del centinela
236433	Alma del zurdo
236434	Alma del gladiador
236435	Alma de la réplica
236436	Alma del evasivo
236437	Alma del toxicólogo
236438	Alma del verdugo
236439	Alma del oportunista
236440	Alma del carnicero
236441	Alma del fantasma
236442	Alma del ladronzuelo
236443	Alma del amante de la adrenalina
236444	Alma del experto en puyazos
236445	Alma del acechador
236446	Alma del eficiente
236447	Alma del malabarista de cuchillos
236448	Alma del maestro de las sombras
236449	Alma del equilibrista
236450	Alma del camorrista fogueado
236451	Alma del cinturón negro
236452	Alma del esgrimista
236453	Alma del espadachín
236454	Alma del sanguinario
236455	Alma del transfusionista
236456	Alma del refinamiento
236457	Alma del exterminador
236458	Alma del putrefaccionista
236459	Alma del malévolo
236460	Alma del sombramante
236461	Alma del heraldo del caos
236462	Alma del incendiario
236463	Alma del pastor infernal
236464	Alma del señor demoníaco
236465	Alma del exorcista demoníaco
236466	Alma del adolorido
236467	Alma del ánima flamígera
236468	Alma del devoracarnes
236469	Alma del abisal
236470	Alma del natovacío
236471	Alma de la hoja umbría
236472	Alma del ritualista
236473	Alma del propagador de dolor
236474	Alma del líder del engaño
236475	Alma del buscapresas
236476	Alma del tirador certero
236477	Alma del asaltante agresivo
236478	Alma del alternador
236479	Alma del toxinólogo
236480	Alma del cazarrecompensas
236481	Alma del as del gatillo
236482	Alma del protector de bestias
236483	Alma del maestro de canes
236484	Alma del domador alfa
236485	Alma del montero
236487	Alma del retaliador
236488	Alma de ecos
236489	Alma del azotador letal
236490	Alma del cinético
236491	Alma del estratega
236492	Alma del golpeador mortal
236493	Alma del sanador súbito
236494	Alma del refinamiento
236495	Alma del oficiante
236496	Alma del fiel
236497	Alma de serendipia
236498	Alma del resonante
236499	Alma del devoto
236500	Alma del arzobispo
236501	Alma del penitente
236502	Alma del guardián del alma
236503	Alma del errante crepuscular
236504	Alma del rompementes
236505	Alma del mortífero
236506	Alma de la fuente espiritual
236507	Alma del zelote
236508	Alma del profanador implacable
236509	Alma del desdeñoso
236510	Alma del pesteador
236511	Alma del reverberante
236512	Alma del cronosanador
236513	Alma del anhelo temporal
236514	Alma del precognoscente
236515	Alma del arcanista
236516	Alma del cuidador eterno
236517	Alma del conjurante
236518	Alma del resguardador
236519	Alma del abrazo invernal
236520	Alma del criomante
236521	Alma del evocador
236522	Alma del elementalista
236523	Alma del armero mágico
236524	Alma del reavivador
236525	Alma de la convergencia ardiente
236526	Alma de la llamarada perpetua
236527	Alma del pirómano
236528	Alma del encendedor
236529	Alma de la antorcha
236530	Alma del bloqueador prístino
236531	Alma del guardián de luz
236532	Alma del defensor radiante
236533	Alma del portaescudos
236534	Alma del bastión
236535	Alma del expiador
236536	Alma del acorazado
236537	Alma del guardián
236538	Alma del pacificador
236539	Alma del refinamiento
236540	Alma del ejemplar
236541	Alma del inquisidor
236542	Alma de soberanía
236543	Alma del investido
236544	Alma del vindicador
236545	Alma del altruista
236546	Alma del árbitro
236547	Alma del portador de sellos
236548	Alma del justicar
236549	Alma del juez
236550	Alma del ascendiente
236551	Alma del desquite
236552	Alma del excomulgador
236553	Alma del iluminado
236554	Alma del exilio
236555	Alma del templario
236556	Alma del viajero del viento
236557	Alma del amo del escudo
236558	Alma del protector totémico
236559	Alma del aplacachoques
236560	Alma del baluarte espiritual
236561	Alma del empuñavorágine
236562	Alma del zancalavas
236563	Alma del alfa verdadero
236564	Alma del guardián de tótems
236565	Alma de los ancestros
236566	Alma del tejespíritus
236567	Alma del zancaaguas
236568	Alma del velatormentas
236569	Alma del vidente elemental
236570	Alma del vitalista
236571	Alma del sanador espiritual
236572	Alma del refinamiento
236573	Alma del jefe
236574	Alma de carga furiosa
236575	Alma del rompetormentas
236576	Alma de la tempestad
236577	Alma del destructor sísmico
236578	Alma del clamallamas
236579	Alma del volcán
236580	Alma de la llama furibunda
236581	Alma del maestro elemental
236582	Alma del tribal
236583	Alma del guía espiritual
236584	Alma del ancestro
236585	Alma de los elementos
236586	Alma del sabio de lava
236587	Alma del guardián ancestral
236588	Alma del corrupto
236589	Alma de pata suave
236590	Alma del feroz
236591	Alma del cambiaformas
236592	Alma del territorial
236593	Alma de la bestia
236594	Alma del lacerador
236595	Alma del furioso
236596	Alma del destrozador
236597	Alma del estimulador
236598	Alma de la fuente de nutrición
236599	Alma del sosiego
236600	Alma del caminasueños
236601	Alma del cuidador de arboleda
236602	Alma del sabio emplumado
236603	Alma del vidente benevolente
236604	Alma del tejevidas
236605	Alma del iluminador
236606	Alma de instintos depredadores
236607	Alma del destripador
236608	Alma de la zarpa
236609	Alma de la manada imponente
236610	Alma del barbárico
236611	Alma del frenético
236612	Alma del desangrador
236613	Alma del guardián de espinas
236614	Alma del lunático
236615	Alma del llamaestrellas
236616	Alma de la noche
236617	Alma de los protectores
236618	Alma del colérico
236619	Alma de gracia salvaje
236620	Alma del ascendiente astral
236621	Alma del llamacometas
236622	Alma del bosque
236623	Alma de pericia animal
236642	Manijas de ensalmador
236643	Guantes de vigía de la noche
236644	Manoplas de doliente
236645	Guanteletes de esgrimidor de la Luz
236656	Runa congelada
236657	Rama podrida de Burbujas
236658	Espina de trofeo de Burbujas
236660	Colmillo trol de Burbujas
236661	Caja torácica de Ribaldy de Burbujas
236662	Riendas de Guerra
236663	Riendas de Conquista
236664	Riendas de Muerte
236665	Riendas de Hambre
236690	Capa glacial
236692	Guantes glaciales
236693	Muñequeras glaciales
236694	Jubón glacial
236695	Coraza Deliriohelado
236696	Brazales Deliriohelado
236697	Guanteletes Deliriohelado
236698	Brazales de escamas heladas
236699	Coraza de escamas heladas
236700	Guanteletes de escamas heladas
236701	Brazales polares
236702	Guerrera polar
236703	Guantes polares
236704	Muñequeras escarchadas
236705	Guantes escarchados
236706	Jubón escarchado
236707	Guerrera de matanza de no-muertos
236708	Coraza de matanza de no-muertos
236709	Coselete de matanza de no-muertos
236710	Guardamuñecas de matanza de no-muertos
236711	Cubremuñecas de matanza de no-muertos
236712	Brazales de matanza de no-muertos
236713	Manijas de matanza de no-muertos
236714	Guanteletes de matanza de no-muertos
236715	Manoplas de matanza de no-muertos
236716	Brazales de eliminación de no-muertos
236717	Guantes de eliminación de no-muertos
236718	Toga de eliminación de no-muertos
236719	Brazales de purificación de no-muertos
236720	Guantes de purificación de no-muertos
236721	Toga de purificación de no-muertos
236722	Brazales de resguardo de no-muertos
236723	Guantes de resguardo de no-muertos
236724	Toga de resguardo de no-muertos
236725	Cubremuñecas de eliminación de no-muertos
236726	Manijas de eliminación de no-muertos
236727	Guerrera de eliminación de no-muertos
236728	Cubremuñecas de purificación de no-muertos
236729	Manijas de purificación de no-muertos
236730	Guerrera de purificación de no-muertos
236731	Cubremuñecas de resguardo de no-muertos
236732	Manijas de resguardo de no-muertos
236733	Guerrera de resguardo de no-muertos
236734	Guardamuñecas de eliminación de no-muertos
236735	Manoplas de eliminación de no-muertos
236736	Coselete de eliminación de no-muertos
236737	Guardamuñecas de resguardo de no-muertos
236738	Manoplas de resguardo de no-muertos
236739	Coselete de resguardo de no-muertos
236740	Guardamuñecas de purificación de no-muertos
236741	Manoplas de purificación de no-muertos
236742	Coselete de purificación de no-muertos
236743	Brazales de purificación de no-muertos
236744	Guanteletes de purificación de no-muertos
236745	Coraza de purificación de no-muertos
236746	Brazales de resguardo de no-muertos
236747	Guanteletes de resguardo de no-muertos
236748	Coraza de resguardo de no-muertos
236750	Corazón de fatalidad
236782	Collar de Sairuh
236786	Corazón de fatalidad
236864	Carcaj de escarcha de alma
236869	Faltriquera de munición de escarcha de alma
236871	Sensores de censura espeluznantes
236872	Esquema: sensores de censura espeluznantes
236878	Reliquia misteriosa
236879	Reliquia misteriosa
236880	Reliquia misteriosa
237011	Llave de compuerta
237020	Insignia Escarlata
237023	Arbusto falso
237024	Boleto de la ópera
237037	Tarjeta de miembro del Club Alcurnia
237041	Tomo de llamarada encantada
237143	Órdenes de la comandante
237163	Cráneo de héroe antiguo
237261	Arena fina
237263	Bolsa de suministros
237275	Casco Deliriohelado
237277	Leotardos escarchados
237278	El Purificador
237279	Amuleto del Alba
237280	Medallón del Alba
237281	Brazales de esperanza
237282	Brazales de subterfugio
237283	Dije de Ascendiente
237284	Bolsa de suministros
237285	Sortija de resolución
237286	Sortija de piedad
237287	Último recurso de Verimonde
237288	Yelmo de cuero santificado
237289	Leotardos del Cazador de peste
237290	Leotardos Deliriohelado
237291	Leotardos glaciales
237292	Leotardos polares
237293	Leotardos de escamas heladas
237294	Garra helada de Ramaladni
237302	Tabardo de El Enclave Escarlata
237381	Anillo profanado
237386	Cajón de suministros de Minahonda asolado por la guerra
237504	Cargamento de suministros
237512	Espada de inquisición
237577	Tótem de Poderío profano
237773	Palabra de deshielo
237810	Piedra de afilar consagrada equilibrada
237814	Musleras de láminas de centinela
237815	Leotardos de seda de centinela
237817	Pantalones de pellejo de lagarto
237818	Pantalones de cuero de centinela
237819	Leotardos de anillas de centinela
237820	Leotardos de seda de escolta
237821	Pantalones de pellejo de lagarto de escolta
237822	Pantalones de cuero de escolta
237823	Leotardos de malla de escolta
237824	Leotardos de anillas de escolta
237825	Musleras de placas de centinela
237826	Musleras de placas de escolta
238234	Aceite de zahorí bendito
238241	Piedra de afilar consagrada
238264	Caperuza de augur Escarlata
238265	Manto de augur Escarlata
238266	Vestimentas de augur Escarlata
238267	Puños de augur Escarlata
238268	Mitones de augur Escarlata
238269	Correa de augur Escarlata
238270	Leotardos de augur Escarlata
238271	Suelas de augur Escarlata
238272	Pañuelo de Infiltrado Escarlata
238273	Hombreras de Infiltrado Escarlata
238274	Jubón de Infiltrado Escarlata
238275	Brazales de Infiltrado Escarlata
238276	Guantes de Infiltrado Escarlata
238277	Cinturón de Infiltrado Escarlata
238278	Calzas de Infiltrado Escarlata
238279	Zapatos de Infiltrado Escarlata
238280	Almófar de montero Escarlata
238281	Espaldares de montero Escarlata
238282	Anillas de montero Escarlata
238283	Guardamuñecas de montero Escarlata
238284	Manoplas de montero Escarlata
238285	Cinto de montero Escarlata
238286	Musleras de montero Escarlata
238287	Botas de montero Escarlata
238288	Yelmo de soldado Escarlata
238289	Bufas de soldado Escarlata
238290	Peto de soldado Escarlata
238291	Protectores de soldado Escarlata
238292	Mandiletes de soldado Escarlata
238293	Guardarrenes de soldado Escarlata
238294	Quijotes de soldado Escarlata
238295	Apisonadoras de soldado Escarlata
238298	Patrón: Caperuza de augur Escarlata
238299	Patrón: Manto de augur Escarlata
238300	Patrón: Vestimentas de augur Escarlata
238301	Patrón: Puños de augur Escarlata
238302	Patrón: Mitones de augur Escarlata
238303	Patrón: Correa de augur Escarlata
238304	Patrón: Leotardos de augur Escarlata
238305	Patrón: Suelas de augur Escarlata
238306	Patrón: Pañuelo de Infiltrado Escarlata
238307	Patrón: Hombreras de Infiltrado Escarlata
238308	Patrón: Jubón de Infiltrado Escarlata
238309	Patrón: Brazales de Infiltrado Escarlata
238310	Patrón: Guantes de Infiltrado Escarlata
238311	Patrón: Cinturón de Infiltrado Escarlata
238312	Patrón: Calzas de Infiltrado Escarlata
238313	Patrón: Zapatos de Infiltrado Escarlata
238314	Patrón: Almófar de montero Escarlata
238315	Patrón: Espaldares de montero Escarlata
238316	Patrón: Anillas de montero Escarlata
238317	Patrón: Guardamuñecas de montero Escarlata
238318	Patrón: Manoplas de montero Escarlata
238319	Patrón: Cinto de montero Escarlata
238320	Patrón: Musleras de montero Escarlata
238321	Patrón: Botas de montero Escarlata
238322	Diseño: Yelmo de soldado Escarlata
238323	Diseño: Bufas de soldado Escarlata
238324	Diseño: Peto de soldado Escarlata
238325	Diseño: Protectores de soldado Escarlata
238326	Diseño: Mandiletes de soldado Escarlata
238327	Diseño: Guardarrenes de soldado Escarlata
238328	Diseño: Quijotes de soldado Escarlata
238329	Diseño: Apisonadoras de soldado Escarlata
238348	El hacha de extirpación
238349	Leotardos de piel de abominación
238350	Daga focal de Desdén
238351	La garra helada
238352	Gargantilla helada de Desdén
238353	Manto de Lady Falther'ess
238354	Dedo de Lady Falther'ess
238355	Cadenas del Exánime
238356	Pretina de Balzaphon
238357	Bastón de Balzaphon
238358	Muslo de Bosque Negro
238360	Rodela de Lord Bosque Negro
238361	Hoja de Lord Bosque Negro
238362	Brazales de alivio
238363	La garra de las Sombras
238364	Capa de Revanchion
238637	Filete de merodeador
238638	Filete de lomo
238639	Omelette madrugador
238641	Festín de motaletas
238642	Gran banquete de langostas
238645	Receta: Filete de merodeador
238646	Receta: Filete de lomo
238647	Receta: Omelette madrugador
238649	Receta: Festín de motaletas
238650	Receta: Gran banquete de langostas
238681	Bolsa polvorienta
238687	Maza de embate
238734	Caja de artilugios: Teletransporte
238735	Caja de artilugios: Nitropropulsores
238736	Caja de artilugios: Desplazamiento magnético
238737	Caja de artilugios
238781	Transportador semiseguro: Nuevo Avalon
238782	Esquema: Caja de artilugios
238783	Esquema: Caja de artilugios: Teletransporte
238784	Esquema: Caja de artilugios: Nitropropulsores
238785	Esquema: Caja de artilugios: Desplazamiento magnético
238786	Esquema: Artilugio: Teletransporte
238787	Esquema: Artilugio: Nitropropulsores
238788	Esquema: Artilugio: Desplazamiento magnético
238789	Esquema: Transportador semiseguro: Nuevo Avalon
238794	Sobras poco apetitosas
238811	Manzana jugosa
238830	Catalejo de manzanas
238831	Cuerda de manzanas
238899	Surtido de peces
238925	Carcaj escarlata
238926	Faltriquera de munición escarlata
238927	Patrón: Carcaj escarlata
238928	Patrón: Faltriquera de munición escarlata
238935	Carne ligeramente putrefacta
238945	Caladroca
238960	Cajón del intendente
238961	Caladbolg
238985	Cajón pesado
239010	Empuñadura de la Crematoria
239011	Fragmento de luz cristalizada
239012	Astilla de luz cristalizada
239013	Hacha cristalina
239016	Sales sagradas
239017	Especias exquisitas
239021	Libro de cocina de Carrie
239060	Voluntad de la montaña
239092	Sello postal peculiarmente en prosa
239097	Llave de la catedral
239117	Cáliz de cruzado
239119	Flecha sagrada
239147	Morral de cruzado
239148	Bolsa tejida en alba carmesí
239149	Patrón: Morral de cruzado
239150	Patrón: Bolsa tejida en alba carmesí
239159	S03 - Scarlet Enclave - Captains Shield
239196	Hoja forjada con luz arruinada
239197	Hoja reforjada de la Crematoria
239215	Emblema carbonizado
239216	Hierro templeluz
239218	Notas de Tallapiedras
239219	Emblema de la Crematoria
239222	Esquema: Arbusto falso
239223	Casa de utilería
239225	Pluma elegante
239246	Lista de compras de Fundefusibles
239248	Caja de trastos Escarlata
239292	Notas de Forjador
239301	Crematoria corrupta
239302	Cinturón de uniforme Escarlata
239316	Churumbele de triangulación
239512	Muñequeras de rompeluz
239513	Cinturón de rompeluz
239514	Mandiletes de rompeluz
239515	Grebas de rompeluz
239516	Sobrehombros de rompeluz
239517	Gran yelmo de rompeluz
239518	Escarcelas de rompeluz
239519	Loriga de rompeluz
239520	Brazales de rompeluz
239521	Guardarrenes de rompeluz
239522	Guanteletes de rompeluz
239523	Escarpes de rompeluz
239524	Espaldares de rompeluz
239525	Yelmo de rompeluz
239526	Quijotes de rompeluz
239527	Coraza de rompeluz
239529	Coraza de acechaalba
239530	Grebas de achechaalba
239531	Guanteletes de acechaalba
239532	Visor de acechaalba
239533	Leotardos de acechaalba
239534	Espaldares de acechaalba
239535	Cinturón acechaalba
239536	Avambrazos de acechaalba
239537	Botas de acechaalba
239538	Faja de acechaalba
239539	Manoplas de acechaalba
239540	Celada de acechaalba
239541	Musleras de acechaalba
239542	Bufas de acechaalba
239543	Guerrera de acechaalba
239544	Guardamuñecas de acechaalba
239547	Guardamuñecas de ánima crepuscular
239548	Coselete de ánima crepuscular
239549	Mandiletes de ánima crepuscular
239550	Máscara de ánima crepuscular
239551	Leotardos de ánima crepuscular
239552	Manto de ánima crepuscular
239553	Botines de ánima crepuscular
239554	Cinturón de ánima crepuscular
239555	Brazales de ánima crepuscular
239556	Guardarrenes de ánima crepuscular
239557	Guanteletes de ánima crepuscular
239558	Escarpes de ánima crepuscular
239559	Espaldares de ánima crepuscular
239560	Yelmo de ánima crepuscular
239561	Quijotes de ánima crepuscular
239562	Coraza de ánima crepuscular
239565	Atuendo de revelación
239572	Botas de revelación
239574	Manos de revelación
239575	Corona de revelación
239577	Pantalones de revelación
239581	Manto de revelación
239582	Faja de revelación
239583	Muñequeras de revelación
239584	Guantes de revelación
239585	Diadema de revelación
239586	Hombreras de revelación
239587	Leotardos de revelación
239588	Ataduras de revelación
239589	Sandalias de revelación
239590	Cinturón de revelación
239591	Toga de revelación
239694	Pacto de luz
239695	Corcel Escarlata
239696	Empuñadura de la Crematoria
239698	Tela tejida en alba
239706	Escarpes consagrados
239707	Casco consagrado
239708	Espaldares consagrados
239709	Quijotes consagrados
239710	Sandalias consagradas
239712	Hombreras consagradas
239714	Aro consagrado
239715	Toga consagrada
239716	Guantes consagrados
239718	Cinturón consagrado
239719	Ataduras consagradas
239721	Leotardos consagrados
239722	Guardamuñecas consagradas
239726	Botas consagradas
239729	Celada consagrada
239730	Manoplas consagradas
239731	Guerrera consagrada
239756	Faja consagrada
239757	Musleras consagradas
239758	Bufas consagradas
239759	Brazales consagrados
239760	Guardarrenes consagrado
239761	Coraza consagrada
239762	Guanteletes consagrados
239764	Filohoja carmesí
240018	Manual de artilugios de Fundefusibles
240020	Musleras de inquisición
240021	Bufas de inquisición
240022	Botas de inquisición
240023	Avambrazos de inquisición
240024	Cinturón de inquisición
240025	Hombreras de inquisición
240026	Leotardos de inquisición
240027	Casco de inquisición
240028	Guantes de inquisición
240029	Grebas de inquisición
240030	Coraza de inquisición
240031	Brazales de inquisición
240032	Guardarrenes de inquisición
240033	Espaldares de inquisición
240034	Quijotes de inquisición
240035	Corona de inquisición
240036	Guanteletes de inquisición
240037	Escarpes de inquisición
240038	Coselete de inquisición
240039	Guerrera de inquisición
240040	Celada de inquisición
240041	Manoplas de inquisición
240042	Guardamuñecas de inquisición
240043	Faja de inquisición
240044	Cubremuñecas de hojafuego
240045	Guardarrenes de hojafuego
240046	Manto de hojafuego
240047	Pantalones de hojafuego
240048	Caperuza de hojafuego
240049	Mitones de hojafuego
240050	Botas de hojafuego
240051	Atuendo de hojafuego
240052	Ataduras de hojafuego
240053	Cinturón de hojafuego
240054	Hombreras de hojafuego
240055	Leotardos de hojafuego
240056	Aro de hojafuego
240057	Guantes de hojafuego
240058	Sandalias de hojafuego
240059	Toga de hojafuego
240060	Brazaletes de oteador
240061	Fajín de oteador
240062	Hombreras de oteador
240063	Calzas de oteador
240064	Capucha de oteador
240065	Mandiletes de oteador
240066	Apisonadoras de oteador
240067	Jubón de oteador
240068	Ataduras de oteador
240069	Cordón de oteador
240070	Manto de oteador
240071	Falda de oteador
240072	Caperuza de oteador
240073	Mitones de oteador
240074	Sandalias de oteador
240075	Cueros de oteador
240076	Brazales de oteador
240077	Guardarrenes de oteador
240078	Espaldares de oteador
240079	Leotardos de oteador
240080	Ornato de oteador
240081	Guanteletes de oteador
240082	Escarpes de oteador
240083	Armadura de oteador
240084	Guardamuñecas de oteador
240085	Faja de oteador
240086	Bufas de oteador
240087	Musleras de oteador
240088	Celada de oteador
240089	Manoplas de oteador
240090	Botas de oteador
240091	Guerrera de oteador
240092	Guerrera de aplastaalmas
240093	Botas de aplastaalmas
240095	Manoplas de aplastaalmas
240096	Celada de aplastaalmas
240097	Musleras de aplastaalmas
240098	Bufas de aplastaalmas
240099	Faja de aplastaalmas
240100	Guardamuñecas de aplastaalmas
240101	Coselete de aplastaalmas
240102	Escarpes de aplastaalmas
240103	Guantes de aplastaalmas
240104	Visera de aplastaalmas
240105	Quijotes de aplastaalmas
240106	Espaldares de aplastaalmas
240107	Guardarrenes de aplastaalmas
240108	Brazales de aplastaalmas
240109	Abrazo de aplastaalmas
240110	Grebas de aplastaalmas
240122	Mitones de aplastaalmas
240123	Corona de aplastaalmas
240124	Falda de aplastaalmas
240125	Manto de aplastaalmas
240126	Cordón de aplastaalmas
240127	Ataduras de aplastaalmas
240128	Armadura de aplastaalmas
240129	Botines de aplastaalmas
240130	Mandiletes de aplastaalmas
240131	Casco de aplastaalmas
240132	Bastón de prueba
240134	Leotardos de aplastaalmas
240135	Cubrehombros de aplastaalmas
240136	Cinturón de aplastaalmas
240137	Avambrazos de aplastaalmas
240138	Toga herética
240139	Sandalias heréticas
240140	Guantes heréticos
240141	Capucha herética
240142	Leotardos heréticos
240143	Hombreras heréticas
240144	Cinturón herético
240145	Ataduras heréticas
240146	Atuendo herético
240147	Manoplas heréticas
240148	Caperuza herética
240149	Pantalones heréticos
240150	Manto herético
240151	Guardarrenes herético
240152	Guardamuñecas heréticos
240153	Botas heréticas
240174	Solistra, Colmillo del alba
240195	Espada invisible
240832	Glándula nivifaciente
240835	Cajón de suministros de Claro de la Luna
240836	Silbato de Thisalee
240837	Hilos del destino
240839	Thal'kituun, el huésped invisible
240841	Guarda de la alta comandante
240842	Putrefaccionista Escarlata
240843	Pistola de salida
240844	Atizador de Putress
240845	Imán prototipo
240846	Chatarra magnética
240848	Detrito de Nordrassil
240849	Bastón del claro
240850	Martillo puñoluz
240851	Regicidio
240852	Cuchilla carmesí
240853	Caída de la reina
240854	Clemencia
240919	Devastalabrys
240920	Leogan
240921	Aplastatoria escarlata
240922	Engaño
240923	Duplicidad
240924	Arma de asta de la bestia
240925	Experimento-K48UM
240936	Crematoria inerte
240945	Porción del pastel de manzana de Carrie
240997	Espuela de Fratley
240998	Hoja soporífera
241001	La caída de Tyr
241002	Restos del rojo
241003	Espejismo, Vara de ilusión
241004	Enigma
241006	Aguja de sacrificio
241008	Condenación
241011	Gran bastón de lealtad
241012	Varita de reanimación
241015	Égida del Bastión Escarlata
241017	Locura de demonio
241018	Corazón nathrezim
241020	Diario completo de Putress
241021	La Luz
241022	Capa de Albar
241023	Mantón del cruel
241024	Manteo de Comandante Escarlata
241025	Bandera del almirante roto
241026	Chal de cardenal
241027	Guarda de celador escudado
241028	Aro nathrezim
241029	Sortija de Baelin
241030	Anillo de fraternidad de Mason
241031	Promesa de Barthalomew
241032	Anillo de resurrección
241034	Corazón de Luz
241037	Experimento abandonado
241038	Didyeridú de sir Dornel
241039	Infusión de almas
241068	Confalón de Stiltz
241069	Cadena de estrangulamiento
241070	Esperanza de Herod
241071	Talismán del ladronzuelo escarlata
241072	Vial de pus
241073	Toque de la Luz
241074	Casco de la cruzada roja
241075	Yelmo de destructor iracundo
241076	Capucha del pacto
241077	Sombrero de cardenal
241078	Embozo del embalsamado
241079	Peso del mundo
241080	Espaldar de Herod
241081	Crematoria corrupta
241082	Crematoria
241083	S03 - Scarlet Enclave - Sword 2h Raid
241084	S03 - Scarlet Enclave - Herod's Sword - Normal
241085	S03 - Scarlet Enclave - Sword 1h
241086	Escudo pavés escarlata
241087	Bastón escarlata
241088	Bastón escarlata
241089	Daga escarlata
241090	Gran hacha escarlata
241091	Maza escarlata
241092	Filo escarlata
241120	S03 - Scarlet Enclave - Herod's Sword - Molten
241121	Daga renacida
241122	Cuchillo renacido
241123	Daga renacida
241124	Cuchillo renacido
241128	Pila de portransportadores
241152	Sobrehombros forjados por el alba
241153	Manto de Doan
241154	Manto de piel de oso
241156	Togas contaminadas
241157	Peto Escarlata
241158	Cadenas del abandonado
241159	Atuendo de monasterio
241160	Malla de anillas desgastada por el alba
241161	Coraza de templario
241162	Cuero bendecido por el sol
241163	Brazales Llamarada sol
241164	Cuero Argenta desechado
241165	Sobrevestes de penitente
241166	Bracibles sinalba
241167	Grilletes de prisionero
241168	Mandiletes Llamarada sol
241169	Prototipo de nitropropulsores
241170	Protectores del enclave
241171	Guantes de almas de difuntos
241172	Guanteletes vinculados de Caldoran
241173	Cinta de alto zahorí
241174	Faja del campeón renacido
241175	Cinturón de herramientas de torturador
241176	Deceso de Diesalven
241177	Falda del arcanista Escarlata
241178	Placas de dolor fiel
241179	Leotardos de la catástrofe
241180	Leotardos de escamas ligeras
241181	Leotardos de anillas desgastados por el alba
241182	Musleras de placas de templario
241183	Caminacenizas
241184	Sandalias de salvador
241185	Botas de entrenamiento de osos
241186	Botas de malla Escarlata pulidas
241187	Botas de guerra carmesí
241190	Silbato de aves
241191	Fórmula: encantar arma: gran cruzado
241195	Fórmula: encantar arma 2M: gran arcanista
241201	Fórmula: encantar arma: gran hechicero
241212	Cañón cacareador
241241	Doblón de la suerte
241613	Ya no se usa
241629	Bala de cañón Escarlata
241649	Guanteletes de la Guardia de Trabalomas
241650	Poción de sanación sublime descolorida
241651	Receta: poción de sanación sublime descolorida
241652	Corazón de bestia descolorido
241653	Hoja caliente
241654	Crematoria inerte
241655	Poción de sanación maltratada
241656	Poción de sanación maltratada
241657	Espada templada
242018	Corazón sangrante de las Tierras de la Peste
242224	Cesta de corazones
242256	Cartera de bombas incendiarias
242257	Muestra alquímica misteriosa
242258	Notas de investigación
242266	Los mil y un resguardos
242267	De arcanista a archimago
242268	Si le das un encantamiento a un cruzado
242269	Brillantez del gran hechicero
242270	Brillantez del gran arcanista
242271	Brillantez del gran cruzado
242310	Mano de la justicia renacida
242311	Amuleto de Leonid
242312	Sello de la familia Barthalomew
242313	Diario de los venerados
242314	Cenicilla del cruzado caído
242315	Cenizas de arrogancia
242316	Polvo de los insolentes
242317	Libro de oraciones profanado
242319	Nuevas muestras de plaga
242320	Nuevas muestras de plaga
242361	Fórmula: encantar arma 2M: gran inquisidor
242362	Brillantez del gran inquisidor
242363	¡Quién, cómo, dónde, cuándo y muere! Las cinco claves de una buena inquisición
242364	Tendón de dragón luminoso maduro
242365	Ala de Balnazzar
242366	Destino ineludible
242367	Ala y cuerda
242425	Página de diario arrancada - Página 1
242426	Página de diario arrancada - Página 2
242427	Diario de Putress
242428	Página de diario arrancada - Página 3
242429	Diario de Putress
242430	Página de diario arrancada - Página 4
242431	Página de diario arrancada - Página 5
242432	Diario de Putress
242433	Página de diario arrancada - Página 6
242434	Diario de Putress
242435	Diario de Putress
242436	Diario de Putress
242465	Fragmento de cáliz roto
242793	Cañón portátil
243010	Crematoria corrupta
243064	Bastón largo
243065	Varita rota
243177	Juguete ingenioso
243198	Mira de precisión para aves de corral
243229	Piedra de hogar del Alba
243230	Hoja forjada con luz arruinada
243345	Bastón largo
244353	Mira de precisión para aves de corral
244460	Caladbolg
245675	Llave de puerta interior de Gordok
246055	Mandiletes de inquisición
246056	Ajorcas de inquisición
246057	Apisonadoras de inquisición
246058	Pantalones de placas de inquisición
246059	Cordón de inquisición
246060	Loriga de inquisición
246061	Cubrehombros de inquisición
246062	Visera de inquisición
]==]
