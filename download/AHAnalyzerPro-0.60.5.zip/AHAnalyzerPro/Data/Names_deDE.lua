-- AH Analyzer Pro - Item-Namen (deDE), 22670 Items
-- Quelle: siehe Data/QUELLEN.txt. Automatisch erzeugt, nicht von Hand ändern.
AHAnalyzerPro_NameData = AHAnalyzerPro_NameData or {}
AHAnalyzerPro_NameData["deDE"] = [==[

25	Abgenutztes Kurzschwert
35	Gebogener Stab
36	Abgenutzter Streitkolben
37	Abgenutzte Axt
38	Rekrutenhemd
39	Rekrutenhose
40	Rekrutenstiefel
43	Knappenstiefel
44	Knappenhose
45	Knappenhemd
47	Straßenräuberschuhe
48	Straßenräuberhose
49	Straßenräuberhemd
51	Neophytenstiefel
52	Neophytenhose
53	Neophytenhemd
55	Lehrlingsstiefel
56	Lehrlingsrobe
57	Akolythenrobe
59	Akolythenschuhe
60	Mehrlagige Tunika
61	Zwergische Lederhose
79	Zwergische Stoffkniehose
80	Weiche fellgefütterte Schuhe
85	Schmutzige Lederweste
117	Zähes Stockfleisch
118	Schwacher Heiltrank
120	Straßenräuberhose
121	Straßenräuberstiefel
127	Fallenstellerhemd
129	Unverwüstliche Fallenstellerstiefel
139	Muskelprotzhose
140	Muskelprotzstiefel
147	Unverwüstliche Fallenstellerhose
148	Unverwüstliches Fallenstellerhemd
153	Primitiver Kilt
154	Primitiver Mantel
159	Erfrischendes Quellwasser
182	Garricks Kopf
193	Zerlumpte Stoffweste
194	Zerlumpte Stoffhose
195	Zerlumpte Stoffstiefel
200	Dicke Stoffweste
201	Dicke Stoffhose
202	Dicke Stoffschuhe
203	Dicke Stoffhandschuhe
209	Schmutzige Lederhose
210	Schmutzige Lederstiefel
236	Geschmeidige Lederrüstung
237	Geschmeidige Lederhose
238	Geschmeidige Lederstiefel
239	Geschmeidige Lederhandschuhe
285	Schuppenpanzerweste
286	Schuppenpanzerhose
287	Schuppenpanzerstiefel
414	Pikanter Dalarankäse
422	Zwergenmild
537	Glanzlose Frenzyschuppe
555	Raue Geierfedern
556	Bussardschnabel
647	Schicksal
710	Armschienen der Volksmiliz
711	Zerlumpte Stoffhandschuhe
714	Schmutzige Lederhandschuhe
718	Schuppenpanzerhandschuhe
719	Handschuhe des Hasenjägers
720	Muskelprotzhandschuhe
723	Geiferzahnleber
724	Pastete aus Geiferzahnleber
725	Gnolltatze
727	Schartiges Kurzschwert
728	Rezept: Westfall-Eintopf
729	Sehniges Geierfleisch
730	Murlocauge
731	Geiferzahnschnauze
732	Okraschote
733	Westfall-Eintopf
735	Medaillons von Rolf und Malakai
737	Wasser der Heiligen Quelle
738	Sack Gerste
739	Sack Korn
740	Sack Roggen
742	Ast eines Bergahorns
743	Verkohltes Eichenbündel
744	Donnerbräus Stiefelflachmann
745	Marshal McBrides Dokumente
748	Rüstungsgutschein der Armee von Stormwind
750	Zähes Wolfsfleisch
752	Rotes Sackleinenkopftuch
753	Kurzschwert der Dragonmaw
754	Kurzschwert der Rache
755	Geschmolzene Kerze
756	Tunnelhacke
763	Eisbedeckte Armschienen
765	Silberblatt
766	Gebördelter Streitkolben
767	Langer Bo-Stab
768	Holzfälleraxt
769	Brocken Eberfleisch
770	Spitzer Krokiliskenzahn
771	Gesplitterter Eberhauer
772	Große Kerze
773	Goldstaub
774	Malachit
776	Blutrache
777	Streunerzähne
778	Ausgrabungshacke eines Kobolds
779	Glänzende Seemuschelschale
780	Zerrissene Murlocflosse
781	Steingnollhammer
782	Bemalte Gnollarmbinde
783	Leichter Balg
785	Maguskönigskraut
787	Glitschhautmakrele
789	Plumper Kampfhammer
790	Waldmannsaxt
791	Knorriger Eschenstab
792	Gestrickte Sandalen
793	Gestrickte Handschuhe
794	Gestrickte Hose
795	Gestrickte Tunika
796	Raue Lederstiefel
797	Raue Lederhandschuhe
798	Raue Lederhose
799	Raue Lederweste
804	Großer blauer Sack
805	Kleiner roter Beutel
809	Blutklinge
810	Hammer des Nordwindes
811	Axt des Tiefwaldes
812	Glimmender Reinholzstab
813	Zerbrochenes Zahnrad
814	Fläschchen Öl
816	Kleine Handklinge
818	Tigerauge
820	Schneideklinge
821	Lederweste der Flusspfoten
826	Derbe Axt der Flusspfoten
827	Heimtückischer Totschläger
828	Kleiner blauer Beutel
829	Rotes Lederkopftuch
832	Silberner Gürtel der Defias
833	Lebensstein
835	Großes Seilnetz
837	Schwere Stoffrüstung
838	Schwere Stoffhose
839	Schwere Stoffhandschuhe
840	Schwere Stoffschuhe
841	Furlbrows Taschenuhr
843	Gegerbte Lederstiefel
844	Gegerbte Lederhandschuhe
845	Gegerbte Lederhose
846	Gegerbtes Lederwams
847	Kettenpanzerrüstung
848	Kettenpanzerhose
849	Kettenpanzerstiefel
850	Kettenpanzerhandschuhe
851	Entersäbel
852	Streitkolben
853	Kriegsbeil
854	Hirtenstab
856	Blaue Ledertasche
857	Großer roter Sack
858	Geringer Heiltrank
859	Feines Stoffhemd
860	Chevaliers-Stiefel
862	Runenverzierter Ring
863	Düsterschneide
864	Ritterliches Langschwert
865	Bleistreitkolben
866	Mönchsstab
867	Handschuhe der Heiligen Macht
868	Inbrünstiger Hüter
869	Funkelndes Langschwert
870	Feurige Kriegsaxt
871	Wirbelwindaxt
872	Steinschneider
873	Stab des Jordan
875	Beschwörung des braunen Pferdes
876	Abgenutzter Holz-Rundschild
878	Faustgroße Spinndrüse
880	Stab des Schreckens
884	Ghulrippe
885	Schwarze Metallaxt
886	Schwarzes Metallkurzschwert
887	Pfund Fleisch
888	Nagakampfhandschuhe
889	Ein verstaubter, nie abgeschickter Brief
890	Stab des verrückten Sängers
892	Gnollzauberhandschuhe
893	Terrorwolf-Fangzahn
895	Worgschädel
896	Worgfangzahn
897	Irrwolfarmschienen
899	Giftweberzahn
901	Deptecated White Stallion Summoning (Mount)
910	Ein niemals zugestellter Brief
911	Eisenholzzweig
913	Gewaltiges Ogerschwert
914	Große Ogerkettenrüstung
915	Rotes Seidenkopftuch
916	Eine zerrissene Tagebuchseite
918	Deviathautpack
920	Heimtückischer Stachelstreitkolben
921	Eine verblasste Tagebuchseite
922	Dakische Sichel
923	Langschwert
924	Schlägel
925	Dreschflegel
926	Streitaxt
927	Doppelaxt
928	Langstab
929	Heiltrank
932	Satteltaschen für ein Teufelsross
933	Großer Rucksack
934	Stalvans Schneide
935	Kurzschwert der Nachtwache
936	Mitternachtsstreitkolben
937	Schwarzer Dämmerwaldstab
938	Schlammverschmierte Tagebuchseiten
939	Eine blutbefleckte Tagebuchseite
940	Roben der Einsicht
942	Band der Eiseskälte
943	Stab des Aufsehers
944	Stab des Elementarmagiers
945	Schattenschwert
948	Naturschwert
954	Rolle der Stärke
955	Rolle der Intelligenz
957	Williams Lieferung
961	Heilkraut
962	Schweinebauch-Pastete
966	Foliant des Frostschilds
967	Foliant des Frostzauberschutzes
968	Foliant des Feuerschlages
973	Foliant des Feuerballs II
974	Foliant der Frostrüstung II
975	Foliant der Eisketten
976	Foliant der Fluchaufhebung
980	Foliant des Frostschilds II
981	Bernices Halskette
983	Rote Leinenschärpe
985	Foliant von Khadgars Öffnung
986	Foliant des Frostblitzes II
989	Foliant der Frostnova
992	Foliant des Feuerballs III
994	Foliant der Eisrüstung
997	Feuerschwert des Verkrüppelns
1002	Foliant der geringen Unsichtbarkeit
1004	Foliant der Eisketten II
1006	Messinghalsband
1008	Eingeschliffenes Schwert
1009	Kompakter Hammer
1010	Knorriger Kurzstab
1011	Scharfe Axt
1013	Eisenniete
1015	Magere Wolfflanke
1017	Gewürzter Wolfskebab
1019	Rotes Leinenkopftuch
1029	Schrifttafel des Schlangentotems
1030	Schrifttafel des Unerschütterlichen Willens
1031	Schrifttafel des Schmelzschlages
1032	Schrifttafel des Aufstachelnden Totems
1033	Schrifttafel der Giftneutralisierung
1034	Schrifttafel der Unsterblichen Stärke
1035	Schrifttafel des Geist rufens
1036	Schrifttafel der Krankheit-Neutralisierung
1037	Schrifttafel des Blitzschlags II
1038	Schrifttafel der Wiederherstellung II
1041	Horn des schwarzen Wolfs
1048	Schrifttafel des Blitzschlagschildes II
1049	Schrifttafel der Reinigung
1052	Schrifttafel der Geistrüstung II
1053	Schrifttafel des Schmelzschlages II
1057	Schrifttafel der Wiederherstellung III
1058	Schrifttafel des Blitzschlags III
1061	Schrifttafel der Gift-Neutralisierung II
1063	Schrifttafel der Krankheit-Neutralisierung II
1072	Volle Flasche Fusel
1074	Harte Spinnenbeinspitze
1075	Schattenfellanhänger
1076	Renegatenring der Defias
1077	Magierring der Defias
1080	Zähes Kondorfleisch
1081	Knuspriges Spinnenfleisch
1082	Rotkammgulasch
1083	Glyphe von Azora
1084	Kodex der Erneuerung
1085	Kodex der Gedankensicht
1086	Kodex des Inneren Feuers
1087	Kodex des Schattenwortes: Schmerz
1088	Kodex der Erneuerung II
1089	Kodex der Krankheitsneutralisierung
1090	Kodex der Auferstehung
1091	Kodex des Heiligen Schmetterns II
1092	Kodex der Geringen Heilung II
1093	Kodex der Fluchaufhebung
1095	Kodex der Magiebannung
1096	Kodex des Schattenwortes: Schmerz II
1100	Kodex des Heiligen Schmetterns III
1101	Kodex der Erneuerung V
1102	Kodex der Geringen Heilung III
1105	Kodex der Erneuerung VI
1108	Kodex der Erneuerung III
1109	Kodex der Beherrschung
1111	Kodex des Schlafs
1112	Kodex des Heiligen Wortes: Seelenstärke II
1113	Herbeigezaubertes Brot
1114	Herbeigezaubertes Roggenbrot
1116	Ring aus reinem Silber
1119	Schnaps in Flaschen
1121	Füße des Luchses
1127	Blitzstrahlbündel
1129	Ghulfangzahn
1130	Phiole mit Spinnengift
1131	Totem des Gegenschlages
1132	Horn des Waldwolfs
1133	Horn des Winterwolfs
1134	Horn des grauen Wolfs
1136	Buchband: Göttliche Gunst II
1138	Buchband: Göttliche Gunst
1139	Buchband: Reinigung des Glaubens
1141	Buchband: Heiliges Licht II
1144	Buchband: Gottesschild
1146	Buchband: Auferstehung
1149	Buchband: Siegel der Macht II
1150	Buchband: Läutern
1151	Buchband: Heiliges Licht III
1154	Gürtel der Volksmiliz
1155	Rute des Schlafwandlers
1156	Reich mit Juwelen besetzter Ring
1158	Robuste Metallkeule
1159	Milizsstecken
1161	Milizkurzschwert
1164	Sams Foliant
1166	Zerbeulter Rundschild
1167	Kleine Tartsche
1168	Schädelflammenschild
1169	Schwarzschädel-Schild
1171	Gut vernähte Robe
1172	Graysons Fackel
1173	Wettergegerbte Stiefel
1175	Ein Goldzahn
1176	Riechsalz
1177	Oil of Olaf
1178	Explosive Rakete
1179	Eiskalte Milch
1180	Rolle der Ausdauer
1181	Rolle der Willenskraft
1182	Messingbeschlagene Armschienen
1183	Elastischer Handgelenksschutz
1187	Stachelhalsband
1189	Vorarbeiterring
1190	Vorarbeiter-Umhang
1191	Tasche mit Murmeln
1193	Bebänderter Rundschild
1194	Bastardschwert
1195	Bergbauschaufel eines Kobolds
1196	Tabar
1197	Riesiger Streitkolben
1198	Claymore
1199	Aufgeladener Seelenstein
1200	Großer Holzschild
1201	Glanzloser Langschild
1202	Wallschild
1203	Aegis von Stormwind
1204	Der grüne Turm
1205	Melonensaft
1206	Moosachat
1207	Zackenstreitkolben
1208	Maybells Liebesbrief
1210	Schattenedelstein
1211	Gnollkriegsharnisch
1212	Gnollspeichel
1213	Gnollarmschienen
1214	Gnollprügel
1215	Stützgurt
1216	Frost-Armschienen
1217	Unbekannte Belohnung
1218	Schwere Gnollkriegskeule
1219	Rotkammmachete
1220	Werwolfaxt
1221	Welpenbauchschuppe
1222	Zerbrochener Zahn
1224	Zauberfoliant des Dämonenspürsinns
1228	Zauberfoliant des Siedebluts
1229	Zauberfoliant der Seelenstein-Herstellung
1231	Zauberfoliant des Schattenblitzes II
1232	Zauberfoliant der Dämonenhaut II
1238	Zauberfoliant der Furcht
1239	Zauberfoliant des Manawegsaugens
1243	Zauberfoliant des Schattenblitzes III
1244	Zauberfoliant der Dämonenrüstung
1245	Zauberfoliant des Feuerbrandes II
1246	Zauberfoliant des Dämonenatems
1250	Zauberfoliant der Entdeckung geringer Unsichtbarkeit
1251	Leinenverband
1252	Oma Stonefields Nachricht
1254	Geringer Feuerstein
1256	Kristalltangwedel
1257	Unsichtbarkeitsschnaps
1259	JYoo test item
1260	Tharil'zuns Kopf
1261	Mitternachtskugel
1262	Fässchen Donnerbräu
1263	Hirnhacker
1264	Kopfberster
1265	Skorpionstachel
1270	Fein gewebter Umhang
1273	Waldkettenpanzer
1274	Hopfen
1275	Kettenmantel des Deputys
1276	Feuergehärteter Rundschild
1280	Kapuzenmantel
1282	Glanzmetallhelmkappe
1283	Verners Notiz
1284	Kiste mit Hufeisen
1287	Riesentarantel-Fangzahn
1288	Großer Giftbeutel
1292	Schlächterbeil
1293	Die Situation von Seenhain
1294	Die Antwort des Generals
1296	Blackrockstreitkolben
1297	Roben des Schattenzauberers
1299	Geringer Gürtel der Spitze
1300	Geringer Stab der Spitze
1302	Schwarzwelpenhandschuhe
1303	Brückenarbeiter-Handschuhe
1304	Reithandschuhe
1306	Handgelenksschutz der Wolfsmähne
1307	Goldabholplan
1309	Oslows Werkzeugkasten
1310	Hose des Schmieds
1314	Ghulfinger
1315	Lilienkranz
1317	Gehärteter Wurzelstab
1318	Nachthäscher
1319	Ring des eisernen Willens
1322	Lebertran
1325	Narzissenstrauß
1326	Sautierter Sonnenfisch
1327	Wileys Nachricht
1328	Buch des Feenfeuers
1332	Buch der Vergiftungsheilung
1334	Buch der Verjüngung II
1339	Buch der Wucherwurzeln
1341	Buch des Mondfeuers
1349	Calvinius' Kiste
1351	Fingerknochenarmschienen
1352	Trümmerschädelmörser
1353	Shaws Bericht
1355	Hirschledercape
1356	Belobigung - Wald von Elwynn
1357	Käpt'n Sanders Schatzkarte
1358	Ein Hinweis auf Käpt'n Sanders Schatz
1359	Mit Löwen bedruckte Handschuhe
1360	Stormwindkettenpanzerhandschuhe
1361	Ein weiterer Hinweis auf Käpt'n Sanders Schatz
1362	Letzter Hinweis auf Käpt'n Sanders Schatz
1364	Struppige Lederweste
1366	Struppige Lederhose
1367	Struppige Lederstiefel
1368	Struppige Lederhandschuhe
1369	Struppiger Ledergürtel
1370	Struppige Lederarmschienen
1372	Struppiger Umhang
1374	Ausgefranste Schuhe
1376	Ausgefranster Umhang
1377	Ausgefranste Handschuhe
1378	Ausgefranste Hose
1380	Ausgefranste Robe
1381	Eine mysteriöse Nachricht
1382	Steinstreitkolben
1383	Steintomahawk
1384	Glanzlose Klinge
1386	Distelholzaxt
1387	Ghulfangzahn
1388	Verbogener Stab
1389	Bergbauschlaghammer eines Kobolds
1391	Mystikerstab der Flusspfoten
1394	Treibholzkeule
1395	Lehrlingshose
1396	Akolythenhose
1399	Magische Kerze
1400	Flinkfedermarke
1401	Grünteeblatt
1402	Schwefel
1404	Gezeitenglücksbringer
1405	Gischtspeichelstab
1406	Perlenbesetzter Speer
1407	Solomons Hilfegesuch an Westfall
1408	Stoutmantles Antwort an Solomon
1409	Solomons Hilfegesuch an Dunkelhain
1410	Ebonlockes Antwort an Solomon
1411	Verwitterter Stab
1412	Kunstloses Bastardschwert
1413	Schwächliches Schwert
1414	Gesprungener Vorschlaghammer
1415	Zimmermanns Schlaghammer
1416	Rostiges Kriegsbeil
1417	Gehämmerte Streitaxt
1418	Abgenutzter Ledergürtel
1419	Abgenutzte Lederstiefel
1420	Abgenutzte Lederarmschienen
1421	Abgenutzter Balgumhang
1422	Abgenutzte Lederhandschuhe
1423	Abgenutzte Lederhose
1425	Abgenutzte Lederweste
1427	Flickwerkschuhe
1429	Flickwerkumhang
1430	Flickwerkhandschuhe
1431	Flickwerkhose
1433	Flickwerkrüstung
1434	Glimmender Wachsstecken
1436	Grenzer-Kniehosen
1438	Kriegerschild
1440	Gnollschädelberster
1443	Juwelenbesetztes Amulett von Cainwyn
1445	Blackrockschulterstücke
1446	Blackrockstiefel
1447	Ring der Retter
1448	Blackrockstulpen
1449	Schwacher Kanalisierungsring
1450	Trank der Inbrunst
1451	Flasche mit Zombiesaft
1453	Spektraler Kamm
1454	Axt des Vollstreckers
1455	Blackrockheldenaxt
1457	Schattenfellstreitkolben
1458	Schattenfellschlägel
1459	Schattenfellskalpschneide
1460	Schattenfellzweihandschwert
1461	Streitaxt des Töters
1462	Ring des Schattens
1464	Bussardkralle
1465	Tigerbann
1467	Gefleckter Sonnenfisch
1468	Murlocflosse
1469	Krummsäbel von Atun
1470	Tasche aus Murlochaut
1473	Flussuferstab
1475	Kleiner Giftbeutel
1476	Abgeknicktes Spinnengliedmaß
1477	Rolle der Beweglichkeit II
1478	Rolle des Schutzes II
1479	Salmas Topfhandschuhe
1480	Faust der Volksmiliz
1481	Grimmklaue
1482	Klinge von Shadowfang
1483	Gesichtzerkracher
1484	Hexenstock
1485	Heugabel
1486	Baumrindenjacke
1487	Herbeigezauberter Pumpernickel
1488	Rächerrüstung
1489	Düsternishüllenrüstung
1490	Wächtertalisman
1491	Ring der Präzision
1493	Schwerer Marodeurskrummsäbel
1495	Kattunschuhe
1497	Kattunumhang
1498	Kattunhandschuhe
1499	Kattunhose
1501	Kattuntunika
1502	Verformter Ledergürtel
1503	Verformte Lederstiefel
1504	Verformte Lederarmschienen
1505	Verformter Umhang
1506	Verformte Lederhandschuhe
1507	Verformte Lederhose
1509	Verformte Lederweste
1510	Schwerer Hammer
1511	Schwert der Bürgerlichen
1512	Kunstlose Streitaxt
1513	Altes Großschwert
1514	Rostiger Kriegshammer
1515	Rauer Holzstab
1516	Abgenutztes Kriegsbeil
1518	Geisterhaarkamm
1519	Ohr der Bloodscalp
1520	Trollschweiß
1521	Schwerfällige Ogeraxt
1522	Kopfjägerspeer
1523	Gewaltige Steinkeule
1524	Hauer der Skullsplitter
1528	Hand voll Hafer
1529	Jade
1532	Schrumpfkopf
1534	Buchband: Heiliges Licht IV
1536	Buchband: Siegel des Zorns
1537	Graumähnes Futtersack
1539	Knorriger Einsiedlerstab
1547	Schild des Glaubens
1554	Foliant des Frostblitzes III
1557	Rundschild der Meere
1559	Foliant der arkanen Geschosse II
1560	Sandalen der Blaukiemen
1561	Robe des Erntearbeiters
1566	Schneide der Volksmiliz
1567	Foliant von Khadgars Öffnung II
1568	Foliant der Wasserelementare
1571	Foliant der Frostnova II
1574	Foliant des Feuerzauberschutzes
1588	Schrifttafel des Schmelzschlages III
1589	Schrifttafel der Geistrüstung III
1591	Schrifttafel des Blitzschlagschildes III
1596	Geisterhaarfaden
1597	Schrifttafel des Gewittersturms
1598	Faulblüte
1602	Sichelaxt
1603	Schrifttafel des Geist rufens II
1604	Chromatisches Schwert
1607	Seelenbewahrer
1608	Schädelberstender Streitkolben
1613	Geisterjägerstab
1619	Schrifttafel des Gewittersturms II
1623	Raptorenhautbeutel
1624	Helm der Skullsplitter
1625	Exquisiter Flamberg
1630	Zerbrochene Elektrolaterne
1637	Brief an Ello
1639	Grinseraxt
1640	Monströse Kriegsaxt
1641	Kodex des Schattenwortes: Schmerz III
1645	Mondbeerensaft
1648	Kodex der Heilung IV
1651	Kodex des Heiligen Wortes: Schild VI
1652	Stabile Vesperdose
1656	Übersetzter Brief
1657	Kodex der Auferstehung II
1658	Kodex des Schattenwortes: Schmerz IV
1659	Ingenieurs-Handschuhe
1664	Zaubermachtrute
1676	Kodex des Schlafs II
1677	Drachenschuppenweste
1678	Schwarze Ogerkicker
1679	Eisenprügel
1680	Kopffäller
1681	Zauberfoliant des Verkrüppelns
1685	Trollbalgtasche
1686	Gesträubtes Schnurrbarthaar
1687	Einziehbare Klaue
1688	Langer weicher Schwanz
1696	Geschwungene Raptorkralle
1697	Beißender Raptorzahn
1701	Geschwungene Basiliskenklaue
1702	Intaktes Basiliskenrückgrat
1703	Kristallenes Basiliskenrückgrat
1705	Geringer Mondstein
1706	Azuredeep-Splitter
1707	Brie aus Stormwind
1708	Süßer Nektar
1710	Großer Heiltrank
1711	Rolle der Ausdauer II
1712	Rolle der Willenskraft II
1713	Ankh des Lebens
1714	Caliseas Halskette
1715	Polierte Jazeraintrüstung
1716	Robe der Weisen
1717	Doppelverbundtunika
1718	Basilisken-Balg-Hose
1720	Wirrholzstab
1721	Wikingerkriegshammer
1722	Dornsteinvorschlaghammer
1725	Große Reisetasche
1726	Knochenspeer mit Giftspitze
1727	Schwert des Verfalls
1728	Teebus Langschwert der Loderflammen
1729	Rupfensack der Nachtwache
1730	Abgenutzter Panzergürtel
1731	Abgenutzte Panzerstiefel
1732	Abgenutzte Panzerarmschienen
1733	Abgenutzter Umhang
1734	Abgenutzte Panzerhandschuhe
1735	Abgenutzte Panzerhose
1737	Abgenutzte Panzerweste
1738	Geschnürter Panzergürtel
1739	Geschnürte Panzerstiefel
1740	Geschnürte Panzerarmschienen
1741	Geschnürter Umhang
1742	Geschnürte Panzerhandschuhe
1743	Geschnürte Panzerhose
1744	Geschnürte Panzerschulterpolster
1745	Geschnürte Panzerweste
1746	Gekettelter Gürtel
1747	Gekettelte Stiefel
1748	Gekettelte Armschienen
1749	Gekettelter Umhang
1750	Gekettelte Handschuhe
1751	Gekettelte Hose
1752	Gekettelte Schulterpolster
1753	Gekettelte Weste
1754	Verstärkter Kettengürtel
1755	Verstärkte Kettenstiefel
1756	Verstärkte Kettenarmschienen
1757	Verstärkter Kettenumhang
1758	Verstärkte Kettenhandschuhe
1759	Verstärkte Kettenhose
1760	Verstärkte Kettenschulterpolster
1761	Verstärkte Kettenweste
1764	Segeltuchschuhe
1766	Segeltuchumhang
1767	Segeltuchhandschuhe
1768	Segeltuchhose
1769	Segeltuchschulterpolster
1770	Segeltuchweste
1772	Brokatschuhe
1774	Brokatumhang
1775	Brokathandschuhe
1776	Brokathose
1777	Brokatschulterpolster
1778	Brokatweste
1780	Kreuznahtsandalen
1782	Kreuznahtumhang
1783	Kreuznahthandschuhe
1784	Kreuznahthose
1785	Kreuznahtschulterpolster
1786	Kreuznahtweste
1787	Geflickter Ledergürtel
1788	Geflickte Lederstiefel
1789	Geflickte Lederarmschienen
1790	Geflickter Umhang
1791	Geflickte Lederhandschuhe
1792	Geflickte Lederhose
1793	Geflickte Lederschulterpolster
1794	Geflicktes Lederwams
1795	Rohledergürtel
1796	Rohlederstiefel
1797	Rohlederarmschienen
1798	Rohlederumhang
1799	Rohlederhandschuhe
1800	Rohlederhose
1801	Rohlederschulterpolster
1802	Rohledertunika
1803	Fester Ledergürtel
1804	Feste Lederstiefel
1805	Feste Lederarmschienen
1806	Fester Umhang
1807	Feste Lederhandschuhe
1808	Feste Lederhose
1809	Feste Lederschulterpolster
1810	Feste Lederrüstung
1811	Stumpfes Claymore
1812	Kurzstielige Streitaxt
1813	Gesplitterter Bauernstecken
1814	Ramponierter Schlaghammer
1815	Ornamentstreitkolben
1816	Unausgewuchtete Axt
1817	Stämmiges Kurzschwert
1818	Standard-Claymore
1819	Stechhacke
1820	Hölzerner Schlägel
1821	Verformte Klinge
1822	Zedernholz-Wanderstecken
1823	Schlägerknüppel
1824	Glänzende Kriegsaxt
1825	Unförmiger Knüttel
1826	Steinschlägel
1827	Fleischerbeil
1828	Steinkriegsaxt
1829	Kurzer Entersäbel
1830	Langes Bastardschwert
1831	Eichener Kriegsstab
1832	Glücks-Beinkleider
1835	Schmutziger Ledergürtel
1836	Schmutzige Lederarmschienen
1839	Rauer Ledergürtel
1840	Raue Lederarmschienen
1843	Gegerbter Ledergürtel
1844	Gegerbte Lederarmschienen
1845	Kettenpanzergürtel
1846	Kettenpanzerarmschienen
1849	Geschmeidiger Ledergürtel
1850	Geschmeidige Lederarmschienen
1851	Säuberndes Wasser
1852	Schuppenpanzerarmschienen
1853	Schuppenpanzergürtel
1875	Thistlenettles Abzeichen
1877	Buch der Verjüngung III
1882	Buch des Mondfeuers III
1886	Buch des Mondfeuers II
1893	Rächer des Minenarbeiters
1894	Gewerkschaftsausweis eines Minenarbeiters
1913	Beschlagener Totschläger
1917	Juwelenbesetzter Dolch
1922	Vorräte für Sven
1923	Ranzen des Botschafters
1925	Rapier der Defias
1926	Beschwerter Prügel
1927	Todesminen-Spaltbeil
1928	Magierstab der Defias
1929	Seidendurchwirkte Beinkleider
1930	Steinmetz-Umhang
1931	Gewaltige Gnollklaue
1933	Stab der Herbeizauberei
1934	Steinmetz-Beinkleider
1935	Assassinenklinge
1936	Goblin-Schraubendreher
1937	Kreissäge
1938	Blockschlaghammer
1939	Schlauch mit süßem Rum
1941	Fässlein mit Merlot
1942	Flasche mit Fusel
1943	Goblin-Panzergamaschen
1944	Metallarbeit-Handschuhe
1945	Holzarbeit-Handschuhe
1946	Marys Handspiegel
1951	Schwarzmeerentersäbel
1955	Kettenstiefel der Dragonmaw
1956	Verblasster Schattenfellanhänger
1958	Versteinerter Schienbeinknochen
1959	Kalteisenhacke
1962	Leuchtender Schattenfellanhänger
1965	Weiße Wolfsfellhandschuhe
1968	Ogermonokel
1970	Wiederherstellender Balsam
1971	Furlbrows Urkunde
1972	Westfall-Urkunde
1973	Täuschungskugel
1974	Geiststoß-Armschienen
1975	Pysans altes Großschwert
1976	Schlackenhammer
1978	Wolfklauen-Handschuhe
1979	Mauer der Toten
1980	Unterweltband
1981	Eispanzerwams
1982	Nachtklinge
1986	Darmfetzer
1987	Krazeks reparierter Topf
1988	Oberbrigadierstulpen
1990	Ballastschlägel
1991	Goblin-Superschaufler
1992	Schlammfröstelfetisch
1993	Ogergeistring
1994	Schwarzkrallenreißer
1996	Voodooband
1997	Gebügelte Filzrobe
1998	Kanalisierungsstab der Bloodscalp
2000	Archeus
2004	Grelin Whitebeards Tagebuch
2005	Die erste Troll-Legende
2006	Die zweite Troll-Legende
2007	Die dritte Troll-Legende
2008	Die vierte Troll-Legende
2011	Verdrehter Säbel
2013	Gruftknochenstab
2014	Schwarzmetallgroßschwert
2015	Schwarzmetallkriegsaxt
2016	Verstaubte Kettenrüstung
2017	Leuchtende Lederarmschienen
2018	Skelettlangschwert
2020	Hohlzahnklinge
2021	Grüner Knochenpanzer-Schild
2024	Espandon
2025	Hakenaxt
2026	Steinhammer
2027	Krummsäbel
2028	Hammer
2029	Spaltbeil
2030	Knorriger Stab
2032	Gallan-Manschetten
2033	Botschafter-Stiefel
2034	Gelehrtenroben
2035	Schwert des Nachthimmels
2036	Verstaubte Bergbau-Handschuhe
2037	Stiefel des Tunnelgräbers
2039	Flachlandring
2040	Trollbeschützer
2041	Tunika von Westfall
2042	Stab von Westfall
2043	Ring der unglückseligen Geister
2044	Sichel der unglückseligen Geister
2046	Kukri der Blaukiemen
2047	Anvilmar-Handaxt
2048	Anvilmar-Hammer
2054	Trogg-Handaxt
2055	Kleiner Holzhammer
2056	Der Samthammer
2057	Eingedelltes Kurzschwert der Defias
2058	Kazons Schlägel
2059	Wachpostenumhang
2064	Trogg-Keule
2065	Klinge der Felsenkiefer
2066	Schädelkriegsbeil
2067	Frostbiss-Stab
2069	Schwarzbärenbalgweste
2070	Darnassischer Blauschimmelkäse
2072	Zwergischer Magierstab
2073	Zwergisches Kriegsbeil
2074	Robuste Kurzklinge
2075	Priesterstreitkolben
2077	Magicusstab
2078	Nordisches Kurzschwert
2079	Sergeants Kriegshammer
2080	Hügelkämpferaxt
2082	Wizbangs Rupfensack
2084	Dunkelstahlbastardschwert
2085	Fleischbrocken
2087	Harter Kriecherknochenpanzer
2088	Langes Kriechergliedmaß
2089	Kunstvoll geschnitzter Dolch
2091	Magischer Staub
2092	Abgenutzter Dolch
2098	Doppelläufige Schrotflinte
2099	Zwergische Handkanone
2100	Präzise kalibriertes Schießeisen
2101	Leichter Köcher
2102	Kleiner Munitionsbeutel
2105	Rohlingshemd
2108	Lederweste der Frostmane
2109	Kettenweste der Frostmane
2110	Leichte Magierschmied-Robe
2112	Holzfällerwams
2113	Calors Notiz
2114	Schneebedeckte Robe
2117	Dünne Stoffschuhe
2119	Dünne Stoffhandschuhe
2120	Dünne Stoffhose
2121	Dünne Stoffrüstung
2122	Gesprungener Ledergürtel
2123	Gesprungene Lederstiefel
2124	Gesprungene Lederarmschienen
2125	Gesprungene Lederhandschuhe
2126	Gesprungene Lederhose
2127	Gesprungene Lederweste
2128	Zerkratztes Claymore
2129	Großer runder Schild
2130	Keule
2131	Kurzschwert
2132	Kurzstab
2133	Kleiner Schild
2134	Handaxt
2136	Herbeigezaubertes geläutertes Wasser
2137	Schnippelmesser
2138	Geschärfter Brieföffner
2139	Langdolch
2140	Schnitzmesser
2141	Weichlederweste
2142	Weichledergürtel
2143	Weichlederstiefel
2144	Weichlederarmschienen
2145	Weichlederhandschuhe
2146	Weichlederhose
2148	Polierter Schuppengürtel
2149	Polierte Schuppenstiefel
2150	Polierte Schuppenarmschienen
2151	Polierte Schuppenhandschuhe
2152	Polierte Schuppengamaschen
2153	Polierte Schuppenweste
2154	Die Geschichte von Morgan Ladimore
2156	Gefütterte Stiefel
2158	Gefütterte Handschuhe
2159	Gefütterte Hose
2160	Gefütterte Rüstung
2161	Buch von Svens Hof
2162	Sarahs Ring
2163	Schattenklinge
2164	Darmreißer
2165	Graumähnes Decke
2166	Großknecht-Gamaschen
2167	Großknecht-Handschuhe
2168	Großknecht-Stiefel
2169	Sauserklinge
2172	Rustikaler Gürtel
2173	Alter Ledergürtel
2175	Schattenfellstreitaxt
2186	Ausstatter-Gürtel
2187	Ein Stapel Briefe
2188	Ein Brief für Grelin Whitebeard
2194	Diamanthammer
2195	Anvilmar-Messer
2203	Geiferkralles Hackbeil
2204	Geiferkralles Bratspieß
2205	Dämmerbringer
2207	Jambiya
2208	Poignard
2209	Kris
2210	Ramponierter Rundschild
2211	Gebogener großer Schild
2212	Gesprungener Rundschild
2213	Abgenutzter großer Schild
2214	Holz-Rundschild
2215	Holzschild
2216	Einfacher Rundschild
2217	Rechteckiger Schild
2218	Handwerkerdolch
2219	Kleiner runder Schild
2220	Kastenschild
2221	Tartschenschild
2222	Turmschild
2223	Der Zeitplan des Sammlers
2224	Milizdolch
2225	Scharfes Küchenmesser
2226	Ogermagierstab
2227	Schwere Ogerkriegsaxt
2230	Handschuhe der Muskelkraft
2231	Infernorobe
2232	Dunkelläuferstiefel
2233	Schattenwirkergamaschen
2234	Nachtwandlerrüstung
2235	Brackenklaue
2236	Schwarzfang
2237	Geflickte Hose
2238	Straßenjungen-Hose
2239	Der Ring des Sammlers
2240	Unverwüstliches Cape
2241	Desperado-Cape
2243	Hand von Edgar dem Seltsamen
2244	Krolklinge
2245	Helm von Narv
2246	Myrmidonensignet
2249	Miliz-Rundschild
2250	Schwärzliche Krebsküchlein
2251	Klebriges Spinnenbein
2252	Verschiedene Goblin-Vorräte
2254	Eisscheibenkriegshammer
2256	Skelettkeule
2257	Stab der Frostmane
2258	Kurzschwert der Frostmane
2259	Keule der Frostmane
2260	Handaxt der Frostmane
2262	Mal des Kern
2263	Phytoklinge
2264	Mantel der Diebe
2265	Splittersteinaxt
2266	Splittersteindolch
2267	Splittersteinstreitkolben
2268	Splittersteinklinge
2271	Stab des gesegneten Sehers
2273	Guerillarüstung
2274	Pionierhandschuhe
2276	Sumpfwandlerstiefel
2277	Totenbeschwörer-Gamaschen
2278	Schulterklappen des Fährtenlesers
2280	Kams Wanderstecken
2281	Rodentia-Feuersteinaxt
2282	Rodentia-Kurzschwert
2283	Rattenstoffgürtel
2284	Rattenstoffumhang
2287	Fleischschenkel
2288	Herbeigezaubertes frisches Wasser
2289	Rolle der Stärke II
2290	Rolle der Intelligenz II
2291	Kang der Köpfer
2292	Nekrologie-Roben
2295	Großer Eberhauer
2296	Große Geiferzahnschnauze
2299	Brennende Kriegsaxt
2300	Geprägte Lederweste
2302	Handgenähte Lederstiefel
2303	Handgenähte Lederhose
2304	Leichtes Rüstungsset
2307	Feine Lederstiefel
2308	Feiner Lederumhang
2309	Geprägte Lederstiefel
2310	Geprägter Lederumhang
2311	Weißes Lederwams
2312	Feine Lederhandschuhe
2313	Mittleres Rüstungsset
2314	Gekräftigte Lederrüstung
2315	Dunkle Lederstiefel
2316	Dunkler Lederumhang
2317	Dunkle Ledertunika
2318	Leichtes Leder
2319	Mittleres Leder
2320	Grober Faden
2321	Feiner Faden
2324	Bleiche
2325	Schwarzer Farbstoff
2326	Efeuband-Armschienen
2327	Stabile Lederarmschienen
2361	Kampferprobter Hammer
2362	Abgenutzter Holzschild
2364	Gewebte Weste
2366	Gewebte Hose
2367	Gewebte Stiefel
2369	Gewebte Handschuhe
2370	Ramponierter Lederharnisch
2371	Ramponierter Ledergürtel
2372	Ramponierte Lederhose
2373	Ramponierte Lederstiefel
2374	Ramponierte Lederarmschienen
2375	Ramponierte Lederhandschuhe
2376	Abgenutzter Langschild
2377	Runder Rundschild
2378	Skelettfinger
2379	Befleckte Kettenweste
2380	Befleckter Kettengürtel
2381	Befleckte Kettengamaschen
2382	Das Herz des Einbalsamierers
2383	Befleckte Kettenstiefel
2384	Befleckte Kettenarmschienen
2385	Befleckte Kettenhandschuhe
2386	Verrostete Kettenweste
2387	Verrosteter Kettengürtel
2388	Verrostete Kettengamaschen
2389	Verrostete Kettenstiefel
2390	Verrostete Kettenarmschienen
2391	Verrostete Kettenhandschuhe
2392	Leichte Panzerrüstung
2393	Leichter Panzergürtel
2394	Leichte Panzergamaschen
2395	Leichte Panzerstiefel
2396	Leichte Panzerarmschienen
2397	Leichte Panzerhandschuhe
2398	Leichte Kettenrüstung
2399	Leichter Kettengürtel
2400	Leichte Kettengamaschen
2401	Leichte Kettenstiefel
2402	Leichte Kettenarmschienen
2403	Leichte Kettenhandschuhe
2406	Muster: Feine Lederstiefel
2407	Muster: Weißes Lederwams
2408	Muster: Feine Lederhandschuhe
2409	Muster: Dunkle Ledertunika
2410	Rauchende Fackel
2411	Rappenzaumzeug
2413	Palomino
2414	Schecke
2415	Schimmel
2417	Aufgebesserte Kettenweste
2418	Aufgebesserte Kettengamaschen
2419	Aufgebesserter Kettengürtel
2420	Aufgebesserte Kettenstiefel
2421	Aufgebesserte Kettenarmschienen
2422	Aufgebesserte Kettenhandschuhe
2423	Brigantinenweste
2424	Brigantinengürtel
2425	Brigantinengamaschen
2426	Brigantinenstiefel
2427	Brigantinenarmschienen
2428	Brigantinenhandschuhe
2429	Rotbraune Weste
2431	Rotbraune Hose
2432	Rotbraune Stiefel
2434	Rotbraune Handschuhe
2435	Bestickte Rüstung
2437	Bestickte Hose
2438	Bestickte Stiefel
2440	Bestickte Handschuhe
2441	Beringter Rundschild
2442	Verstärkte Tartsche
2443	Metallrundschild
2444	Verschnörkelter Rundschild
2445	Großer Metallschild
2446	Viereckschild
2447	Friedensblume
2448	Schwere Pavese
2449	Erdwurzel
2450	Wilddornrose
2451	Wappenlangschild
2452	Flitzdistel
2453	Beulengras
2454	Elixier der Löwenstärke
2455	Schwacher Manatrank
2456	Schwacher Verjüngungstrank
2457	Elixier der schwachen Beweglichkeit
2458	Elixier der schwachen Seelenstärke
2459	Hurtigkeitstrank
2460	Elixir of Tongues (NYI)
2463	Beschlagenes Doublet
2464	Beschlagener Gürtel
2465	Beschlagene Hose
2466	Fetisch der Skullsplitter
2467	Beschlagene Stiefel
2468	Beschlagene Armschienen
2469	Beschlagene Handschuhe
2470	Verstärkte Lederweste
2471	Verstärkter Ledergürtel
2472	Verstärkte Lederhose
2473	Verstärkte Lederstiefel
2474	Verstärkte Lederarmschienen
2475	Verstärkte Lederhandschuhe
2476	Gekühlter Basiliskenschenkel
2477	Verheererschädel
2479	Breitaxt
2480	Große Keule
2481	Peonschwert
2482	Minderwertiger Tomahawk
2483	Raue Breitaxt
2484	Kleines Messer
2485	Splitterbrett
2486	Großer Steinkolben
2487	Akolythenstab
2488	Gladius
2489	Zweihandschwert
2490	Tomahawk
2491	Große Axt
2492	Knüppel
2493	Hölzerner Schlaghammer
2494	Stilett
2495	Wanderstecken
2496	Räuberkurzschwert
2497	Verrostetes Claymore
2498	Kleiner Tomahawk
2499	Doppelklingenaxt
2500	Leichter Hammer
2501	Hölzerner Kriegshammer
2502	Zerkratzter Dolch
2503	Adepten-Kurzstab
2504	Abgenutzter Kurzbogen
2505	Polierter Kurzbogen
2506	Hornholz-Doppelbogen
2507	Laminierter Doppelbogen
2508	Alte Donnerbüchse
2509	Verschnörkelte Donnerbüchse
2510	Robuste Donnerbüchse
2511	Jägerschießeisen
2512	Rauer Pfeil
2514	Ausgedienter scharfer Pfeil
2515	Scharfer Pfeil
2516	Leichtes Geschoss
2519	Schweres Geschoss
2520	Breitschwert
2521	Flamberg
2522	Sichelaxt
2523	Bullova
2524	Schlagstock
2525	Kriegshammer
2526	Parierdolch
2527	Kampfstab
2528	Krummschwert
2529	Bidenhänder
2530	Franziska
2531	Großaxt
2532	Morgenstern
2533	Kriegsschlägel
2534	Rondel
2535	Kriegsstab
2536	Trogg-Steinzahn
2545	Formbare Kettengamaschen
2546	Königlicher Gurt der Frostmane
2547	Handschuhe des Eberjägers
2548	Fass mit Gerstenbräu
2549	Stab des Schemen
2553	Rezept: Elixier der schwachen Beweglichkeit
2555	Rezept: Hurtigkeitstrank
2556	Rezept: Elixier der Sprachen
2560	Jitters vollendetes Tagebuch
2561	Chok'suls Kopf
2562	Scharlachroter Begonienstrauß
2563	Sonderbar riechendes Pulver
2564	Elfengeistklauen
2565	Rute des flüssigen Feuers
2566	Opferungsroben
2567	Klinge des Beschwörers
2568	Braune Leinenweste
2569	Leinenstiefel
2570	Leinenumhang
2571	Fußlappen
2572	Rote Leinenrobe
2575	Rotes Leinenhemd
2576	Weißes Leinenhemd
2577	Blaues Leinenhemd
2578	Barbarische Leinenweste
2579	Grünes Leinenhemd
2580	Verstärktes Leinencape
2581	Schwerer Leinenverband
2582	Grüne Wollweste
2583	Wollstiefel
2584	Wollcape
2585	Graue Wollrobe
2586	Game Master-Robe
2587	Graues Wollhemd
2589	Leinenstoff
2590	Waldspinnennetz
2591	Schmutziger Trogg-Stoff
2592	Wollstoff
2593	Fläschchen Stormwinder Goldtropfen
2594	Krug Zwergenhonigmet
2595	Henkelkrug Ödlandbourbon
2596	Schlauch mit zwergischem Starkbier
2598	Muster: Rote Leinenrobe
2601	Muster: Graue Wollrobe
2604	Roter Farbstoff
2605	Grüner Farbstoff
2606	Lauerergift
2607	Kristall der Mo'grosh
2608	Dreschadonambra
2609	Entschärfungspaste
2610	Entschärfungsmixtur
2611	Kunstloser Feuerstein
2612	Schlichte Robe
2613	Doppelt genähte Roben
2614	Robe der Lehrlingszeit
2615	Chromatische Robe
2616	Schimmernde Seidenroben
2617	Brennende Roben
2618	Silberne Ausgehroben
2619	Grelins Bericht
2620	Weissagungstuch
2621	Kutte der Totenbeschwörung
2622	Nimars Stammeskopfputz
2623	Heiliges Diadem
2624	Denkkappe
2625	Menethil-Statuette
2628	Senirs Bericht
2629	Geldkassettenschlüssel der INTREPID
2632	Geschwungener Dolch
2633	Dschungelarznei
2634	Giftfarnextrakt
2635	Lockerer Kettengürtel
2636	Verzierter Steingötze
2637	Ironbands Fortschrittsbericht
2639	Merrins Brief
2640	Minenarbeiterausstattung
2642	Lockere Kettenstiefel
2643	Lockere Kettenarmschienen
2644	Lockerer Kettenumhang
2645	Lockere Kettenhandschuhe
2646	Lockere Kettenhose
2648	Lockere Kettenweste
2649	Sehr leichter Kettengürtel
2650	Sehr leichte Kettenstiefel
2651	Sehr leichte Kettenarmschienen
2652	Sehr leichter Kettenumhang
2653	Sehr leichte Kettenhandschuhe
2654	Sehr leichte Kettenhose
2656	Sehr leichte Kettenweste
2657	Rote Ledertasche
2658	Ados-Fragment
2659	Modr-Fragment
2660	Golm-Fragment
2661	Neru-Fragment
2662	Ribblys Köcher
2663	Ribblys Schultergürtel
2664	Spinner-Fangzahn
2665	Würzkräuter aus Stormwind
2666	Fass mit Donnerbier
2667	MacGranns Trockenfleisch
2668	Dreschadonzahn
2669	Dreschadonklaue
2671	Wendigomähne
2672	Sehniges Wolfsfleisch
2673	Kojotenfleisch
2674	Kriecherfleisch
2675	Kriecherklaue
2676	Schimmerkraut
2677	Eberrippchen
2678	Milde Gewürze
2679	Verkohltes Wolfsfleisch
2680	Gewürztes Wolfsfleisch
2681	Geröstetes Eberfleisch
2682	Gekochte Krebsschere
2683	Krebsküchlein
2684	Kojotensteak
2685	Saftige Schweinerippchen
2686	Donnerbier
2687	Trockene Schweinerippchen
2688	Eichhörnchennuss
2690	Anhäng-Gürtel
2691	Ausstatter-Stiefel
2692	Scharfe Gewürze
2694	Siedler-Gamaschen
2696	Fässlein mit Immerschimmer
2697	Rezept: Pastete aus Geiferzahnleber
2698	Rezept: Gekochte Krebsschere
2699	Rezept: Rotkammgulasch
2700	Rezept: Saftige Schweinerippchen
2701	Rezept: Gewürzter Wolfskebab
2702	Lichtschmiedeblock
2712	Kiste mit Lichtschmiedeblöcken
2713	Old Sootys Kopf
2719	Kleiner Messingschlüssel
2720	Schlammverschmierte Notiz
2721	Heiliges Tuch
2722	Wein-Gutschein
2723	Flasche Dalaran Noir
2724	Stoff-Anforderung
2725	Die Grünen Hügel des Schlingendorntals - Seite 1
2728	Die Grünen Hügel des Schlingendorntals - Seite 4
2730	Die Grünen Hügel des Schlingendorntals - Seite 6
2732	Die Grünen Hügel des Schlingendorntals - Seite 8
2734	Die Grünen Hügel des Schlingendorntals - Seite 10
2735	Die Grünen Hügel des Schlingendorntals - Seite 11
2738	Die Grünen Hügel des Schlingendorntals - Seite 14
2740	Die Grünen Hügel des Schlingendorntals - Seite 16
2742	Die Grünen Hügel des Schlingendorntals - Seite 18
2744	Die Grünen Hügel des Schlingendorntals - Seite 20
2745	Die Grünen Hügel des Schlingendorntals - Seite 21
2748	Die Grünen Hügel des Schlingendorntals - Seite 24
2749	Die Grünen Hügel des Schlingendorntals - Seite 25
2750	Die Grünen Hügel des Schlingendorntals - Seite 26
2751	Die Grünen Hügel des Schlingendorntals - Seite 27
2754	Beflecktes Bastardschwert
2755	Die Grünen Hügel des Schlingendorntals
2756	Die Grünen Hügel des Schlingendorntals - Kapitel I
2757	Die Grünen Hügel des Schlingendorntals - Kapitel II
2758	Die Grünen Hügel des Schlingendorntals - Kapitel III
2759	Die Grünen Hügel des Schlingendorntals - Kapitel IV
2760	Thurmans Nähkästchen
2763	Anglermesser
2764	Kleiner Dolch
2765	Jagdmesser
2766	Flinkes Stilett
2770	Kupfererz
2771	Zinnerz
2772	Eisenerz
2773	Gesprungener Kurzbogen
2774	Rostbedeckte Donnerbüchse
2775	Silbererz
2776	Golderz
2777	Schwächlicher Kurzbogen
2778	Billige Donnerbüchse
2779	Tilloaträne
2780	Leichter Jagdbogen
2781	Schmutzige Donnerbüchse
2782	Verschlissener Doppelbogen
2783	Schäbige Donnerbüchse
2784	Bisamwurzel
2785	Steifer Doppelbogen
2786	Geölte Donnerbüchse
2787	Trogg-Dolch
2788	Blackclaw-Starkbier
2794	Ein altes Geschichtsbuch
2795	Buch: Belastbarkeit von Eisen
2797	Herz von Mokk
2798	Rethbanerz
2799	Gorillafangzahn
2800	Schwarze Samtroben
2801	Klinge von Hanna
2802	Loderflammenemblem
2805	Yetifell-Umhang
2806	Päckchen für Stormpike
2807	Guillotinenaxt
2808	Flammenfackel
2815	Bogenklingenreißer
2816	Todessprecherszepter
2817	Weiche Ledertunika
2818	Gedehnte Lederbeinkleider
2819	Kreuzdolch
2820	Schicke Stoppuhr
2821	Zerstampfer der Mo'grosh
2822	Zahnstocher der Mo'grosh
2823	Büchsenöffner der Mo'grosh
2824	Hurrikan
2825	Bogen der Sengpfeile
2828	Nissas sterbliche Überreste
2829	Gregors sterbliche Überreste
2830	Thurmans sterbliche Überreste
2831	Devlins sterbliche Überreste
2832	Vernas Rezept für Westfall-Eintopf
2833	Das Zauberbuch des Lichs
2834	Einbalsamierungssekret
2835	Rauer Stein
2836	Grober Stein
2837	Thurmans Brief
2838	Schwerer Stein
2839	Ein Brief an Yvette
2840	Kupferbarren
2841	Bronzebarren
2842	Silberbarren
2843	Schmutzige Knöchelknochen
2844	Kupferstreitkolben
2845	Kupferaxt
2846	Tirisfalkürbis
2847	Kupferkurzschwert
2848	Bronzener Streitkolben
2849	Bronzene Axt
2850	Bronzenes Kurzschwert
2851	Kupferner Kettengürtel
2852	Kupferne Kettenhose
2853	Kupferarmschienen
2854	Runenverzierte Kupferarmschienen
2855	Eitrige Klaue
2856	Eisenspitze
2857	Runenverzierter Kupfergürtel
2858	Schattenhundblut
2859	Finsterflossenschuppe
2862	Rauer Wetzstein
2863	Grober Wetzstein
2864	Runenverzierte Kupferbrustplatte
2865	Raue bronzene Gamaschen
2866	Rauer bronzener Kürass
2867	Raue bronzene Armschienen
2868	Gemusterte bronzene Armschienen
2869	Bronzene Brustplatte mit Versilberung
2870	Leuchtende silberne Brustplatte
2871	Schwerer Wetzstein
2872	Heimtückisches Nachtweberspinnengift
2874	Ein nie abgeschickter Brief
2875	Scharlachroter Insignienring
2876	Nachtsaugerpelz
2877	Mitstreiter-Claymore
2878	Hakenknochenaxt
2879	Antipoden-Rute
2880	Schwacher Fluxus
2881	Pläne: Runenverzierte Kupferbrustplatte
2882	Pläne: Bronzene Schultern mit Versilberung
2883	Pläne: Tödlicher Bronzepoignard
2885	Dokumente des Scharlachroten Kreuzzugs
2886	Klippeneberrippchen
2887	Verdorbener Wolfspelz
2888	Eberrippchen in Biersauce
2889	Rezept: Eberrippchen in Biersauce
2890	Verdorbener Eberpelz
2891	Brief an den Stadtarchitekten
2892	Tödliches Gift
2893	Tödliches Gift II
2894	Rhapsody-Malzbier
2895	Schleichender Schmerz
2896	Schleichende Seelenpein
2898	Gebirgsjägerbrustharnisch
2899	Wendigohalsband
2900	Stein-Rundschild
2901	Spitzhacke
2902	Glaubens-Umhang
2903	Daryls Jagdbogen
2904	Daryls Jagdgewehr
2905	Ziegenfell-Umhang
2906	Panzergamaschen von Dunkelhain
2907	Zwergischer Baumhacker
2908	Dornenklinge
2909	Rotes Wollkopftuch
2910	Goldene Milizstiefel
2911	Kellers Gurt
2912	Klaue des Schattenbeschwörers
2913	Seidenmantel von Gamn
2915	Taraneisbrecher
2916	Goldlöwenschild
2917	Gelassenheitsring
2919	Relikt der Urtume
2920	Heiliges Relikt
2921	Gesegnetes Relikt
2922	Geistrelikt
2923	Relikt der Rechtschaffenheit
2924	Krokiliskenfleisch
2925	Krokiliskenhaut
2926	Kopf von Bazil Thredd
2927	Schleichende Qual
2928	Staub des Verfalls
2929	Grabmalfäulnis
2930	Essenz des Schmerzes
2932	Qualranke
2933	Siegel von Wrynn
2934	Verdorbene Lederfetzen
2939	Krokiliskenträne
2940	Blutige Bärentatze
2941	Knastschenkel
2942	Eisenschlagring
2943	Auge von Paleth
2944	Verfluchtes Auge von Paleth
2946	Ausbalancierter Wurfdolch
2947	Kleines Wurfmesser
2949	Matrosen-Stiefel
2950	Rute des Eiszapfens
2951	Ring des Waldlandes
2953	Umhang des Wachhauptmanns
2954	Nachtwachen-Pantalons
2955	Hut des Ersten Maats
2956	Bericht über die Bruderschaft der Defias
2957	Gesellenweste
2958	Gesellenhose
2959	Gesellenstiefel
2960	Gesellenhandschuhe
2961	Brandlederweste
2962	Brandlederbundhosen
2963	Brandlederstiefel
2964	Brandlederhandschuhe
2965	Kriegertunika
2966	Kriegerhose
2967	Kriegerstiefel
2968	Kriegerhandschuhe
2969	Zauberbinder-Weste
2970	Zauberbinder-Hose
2971	Zauberbinder-Stiefel
2972	Zauberbinder-Handschuhe
2973	Jagdtunika
2974	Jagdhose
2975	Jagdstiefel
2976	Jagdhandschuhe
2977	Veteranen-Rüstung
2978	Veteranen-Gamaschen
2979	Veteranen-Stiefel
2980	Veteranen-Handschuhe
2981	Seherrobe
2982	Seherhose
2983	Seherstiefel
2984	Seherhandschuhe
2985	Gravierte Lederbrustplatte
2986	Gravierte Lederhose
2987	Gravierte Lederstiefel
2988	Gravierte Lederhandschuhe
2989	Brünierte Tunika
2990	Brünierte Gamaschen
2991	Brünierte Stiefel
2992	Brünierte Handschuhe
2996	Leinenstoffballen
2997	Wollstoffballen
2998	Ein einfacher Kompass
2999	Steelgrills Werkzeuge
3000	Brutmutter-Knochenpanzer
3002	Relikt-Horn der Gerechtigkeit
3003	Relikt des Auges
3004	Relikt der Toten
3005	Relikt der Wahrheit
3006	Heiliger Reliktsplitter
3008	Wendigofellumhang
3010	Feiner Sand
3011	Gefiederter Kopfputz
3012	Rolle der Beweglichkeit
3013	Rolle des Schutzes
3014	Kampferprobte Axt
3016	Gunthers Zauberbuch
3017	Sevrens Befehle
3018	Balg von Lupos
3019	Adligenrobe
3020	Ausdauernde Kappe
3021	Waldläuferbogen
3022	Bundhose der Blaukiemen
3023	Großkalibrige Donnerbüchse
3024	BKP 2700 "Vollstrecker"
3025	BKP 42 "Ultra"
3026	Verstärkter Bogen
3027	Schwerer Doppelbogen
3028	Langbogen
3029	Ausgedienter Peitschenholzpfeil
3030	Schneidenpfeil
3031	Ausgedienter Schneidenpfeil
3033	Robustes Geschoss
3035	Getränkter Kürbis
3036	Schwerer Kurzbogen
3037	Peitschenholzdoppelbogen
3039	Kurzer Aschenbogen
3040	Vorderlader des Jägers
3041	Donnerbüchse "Magierauge"
3042	BKP "Spatz" Kleinkaliber
3045	Züngelnde Schuppenstiefel
3047	Züngelnde Schuppenhandschuhe
3048	Züngelnde Schuppenbeinschützer
3049	Züngelnde Schuppenbrustplatte
3053	Humberts Brustharnisch
3055	Waldlederbrustharnisch
3056	Waldlederhose
3057	Waldlederstiefel
3058	Waldlederhandschuhe
3065	Helle Stiefel
3066	Helle Handschuhe
3067	Helle Hose
3069	Helle Robe
3070	Fähnrich-Umhang
3071	Schlagkriegsbeil
3072	Glimmende Robe
3073	Glimmende Hose
3074	Glimmende Handschuhe
3075	Flammenauge
3076	Glimmende Stiefel
3078	Nagaherzbohrer
3079	Skorns Gewehr
3080	Kerze des Heranlockens
3081	Netheredelstein
3082	Dargols Schädel
3083	Restabilisationszahnrad
3084	Gyromechanische Getriebeteile
3085	Fass mit Schimmerstarkbier
3086	Fässlein mit Schimmerstarkbier
3087	Becher mit Schimmerstarkbier
3088	Buch der Verjüngung IV
3089	Foliant des Flammenstoßes
3090	Foliant des Frostblitzes
3091	Foliant der arkanen Intelligenz II
3092	Foliant des Flammenstoßes III
3093	Foliant des Flammenstoßes II
3094	Foliant des Feuerschlages II
3095	Foliant des Feuerschlages III
3096	Foliant des Federfalls
3097	Foliant des Wasser-Herbeizauberns II
3098	Foliant der Verlangsamung
3099	Foliant der Eisrüstung II
3100	Foliant des Blizzards II
3101	Foliant der Frostnova III
3102	Foliant der arkanen Intelligenz III
3103	Coldridge-Hammer
3107	Beißendes Wurfmesser
3108	Schwerer Wurfdolch
3110	Tunnelrattenohr
3111	Kunstlose Wurfaxt
3113	Kodex des Heiligen Wortes: Schild
3114	Kodex des Schattenwortes: Verwirrung
3115	Kodex der Erneuerung IV
3116	Kodex des Heiligen Wortes: Schild II
3117	Hildelves Tagebuch
3118	Kodex der Großen Heilung
3119	Kodex des Heiligen Wortes: Schild V
3120	Kodex des Heiligen Schmetterns IV
3121	Kodex des Levitierens
3122	Kodex des Heiligen Wortes: Schild III
3123	Kodex des Heiligen Wortes: Seelenstärke III
3124	Kodex des Inneren Feuers III
3125	Schrifttafel des Schlangentotems II
3126	Schrifttafel des Schocks II
3127	Schrifttafel des Schocks III
3129	Schrifttafel des Blitzschlags IV
3130	Schrifttafel der Wiederherstellung IV
3131	Beschwerte Wurfaxt
3132	Schrifttafel des Schmelzschlages IV
3133	Schrifttafel des Manatotems
3134	Zauberfoliant des Fluchs von Mannoroth
3135	Scharfe Wurfaxt
3137	Tödliche Wurfaxt
3138	Zauberfoliant des Schattenblitzes IV
3139	Zauberfoliant der Dämonenrüstung II
3140	Zauberfoliant des Siedebluts II
3141	Zauberfoliant des Lebensaugers
3142	Zauberfoliant des Fluchs von Sargeras
3143	Zauberfoliant des brennenden Geistes
3144	Zauberfoliant des brennenden Geistes II
3146	Zauberfoliant des brennenden Geistes III
3151	Belagerungsbrigadenweste
3152	Fahr-Handschuhe
3153	Ölbefleckter Umhang
3154	Thelsamaraxt
3155	Arznei des Arugal
3156	Nimmersattfessel
3157	Dunkelseelenfessel
3158	Brandbalg-Armschienen
3160	Eisenplattenrundschild
3161	Robe des Bewahrers
3162	Schartige Rippe
3163	Geschwärzter Schädel
3164	Verfärbtes Worgherz
3165	Quinns Trank
3166	Eisenherzkettenhemd
3167	Dickes Spinnenhaar
3168	Gesplitterte Schuppe
3169	Gesplitterter Bärenzahn
3170	Großer Bärenzahn
3171	Zerbrochener Eberhauer
3172	Ebergedärme
3173	Bärenfleisch
3174	Spinnensekret
3175	Verdorbener Drachenbalg
3176	Kleine Klaue
3177	Winziger Fangzahn
3179	Rissige Drachenhaut
3180	Gesprenkelte Raptorschuppe
3181	Teilweise verdautes Fleisch
3182	Spinnenseide
3183	Räudige Klaue
3184	Hakendolch
3185	Akrobatenstab
3186	Wikingerschwert
3187	Opferkris
3188	Korallen-Claymore
3189	Holzfällerbeil
3190	Haustecken
3191	Gekrümmte Kriegsaxt
3192	Kurzes Bastardschwert
3193	Eichenschlaghammer
3194	Schwarze Bosheit
3195	Barbarische Streitaxt
3196	Kantiges Bastardschwert
3197	Steinfräser-Claymore
3198	Beulenhammer
3199	Kampfschlächter
3200	Brandleder-Armschienen
3201	Barbarische Kriegsaxt
3202	Waldleder-Armschienen
3203	Handfester Dreiecksstreitkolben
3204	Tiefholzarmschienen
3205	Gravierte Lederarmschienen
3206	Chevalier-Zweihänder
3207	Jagdarmschienen
3208	Zinkenhammer
3209	Altes Kriegsschwert
3210	Brutale Kriegsaxt
3211	Brünierte Armschienen
3212	Züngelnde Schuppenarmschienen
3213	Veteranen-Armschienen
3214	Kriegerarmschienen
3216	Warme Winterrobe
3217	Großknecht-Gürtel
3218	Pyrewood-Fessel
3220	Blutwurst
3222	Heimtückischer Dolch
3223	Szepter der Frostmane
3224	Silbergefütterte Armschienen
3225	Blutbeflecktes Messer
3227	Stab der Nachtheuler
3228	Aufgebrochene Handschellen
3229	Tarantel-Seidenschärpe
3230	Schwarzwolf-Armschienen
3231	Halsabschneider-Schulterstücke
3233	Gnollbalgsack
3234	Deliahs Ring
3235	Ring der Verachtung
3236	Moderfellsekret
3237	Sekretprobe
3238	Johaans Funde
3239	Rauer Gewichtsstein
3240	Grober Gewichtsstein
3241	Schwerer Gewichtsstein
3248	Übersetzter Brief des Einbalsamierers
3249	Conjured test Item
3250	Bethors Rolle
3251	Bethors Trank
3252	Todespirscherbericht
3253	Herz eines ergrauten Bären
3254	Huschendes Blut
3255	Berards Tagebuch
3256	Seeschleichermoos
3257	Seekrabblermoos
3258	Verhärteter Tumor
3259	Verdorbener Fledermausbalg
3260	Scharlachrote Initianden-Robe
3261	Eingesponnener Umhang
3262	Eitriger Holzhammer
3263	Eingesponnene Hose
3264	Nachtsaugerflügel
3265	Aasfressertatze
3266	Scharlachrote Armbinde
3267	Kurzschwert der Verlassenen
3268	Dolch der Verlassenen
3269	Schlägel der Verlassenen
3270	Flachsweste
3272	Zombiehaut-Gamaschen
3273	Unverwüstliche Panzerweste
3274	Flachsstiefel
3275	Flachshandschuhe
3276	Todeswachen-Rundschild
3277	Stab des Exekutors
3278	Aura Proc Schaden Schwert
3279	Kampfkettenstiefel
3280	Kampfkettenarmschienen
3281	Kampfkettenhandschuhe
3282	Kampfkettenhose
3283	Kampfkettentunika
3284	Stammesstiefel
3285	Stammesarmschienen
3286	Stammeshandschuhe
3287	Stammeshose
3288	Stammesweste
3289	Vorfahren-Stiefel
3290	Vorfahren-Handschuhe
3291	Vorfahren-Wollwäsche
3292	Vorfahren-Tunika
3293	Totmannsspaltbeil
3294	Totmannskeule
3295	Totmannsklinge
3296	Totmannsdolch
3297	Teufelsmoos
3299	Gerissener Eckzahn
3300	Hasenpfote
3301	Scharfer Eckzahn
3302	Brackwasserstiefel
3303	Brackwasserarmschienen
3304	Brackwasserstulpen
3305	Brackwassergamaschen
3306	Brackwasserweste
3307	Barbarische Stoffstiefel
3308	Barbarische Stoffhandschuhe
3309	Barbarischer Lendenschurz
3310	Barbarische Stoffweste
3311	Zeremonieller Lederknöchelschutz
3312	Zeremonielle Lederarmschienen
3313	Zeremonieller Lederharnisch
3314	Zeremonielle Lederhandschuhe
3315	Zeremonieller Lederlendenschurz
3316	Alarics Kopf
3317	Ein sprechender Kopf
3318	Alarics sterbliche Überreste
3319	Kurzer Säbel
3320	Knochenwerferschärpe
3321	Graue Fellstiefeletten
3322	Hauchdünner Umhang
3323	Geisterhafte Armschienen
3324	Geisterhafter Mantel
3325	Streitaxt der Finsterflossen
3327	Orakelstab der Finsterflossen
3328	Spinnennetzrobe
3329	Stachelholzbohle
3330	Dargols Halsberge
3331	Melraches Cape
3332	Perrines Stiefel
3334	Bauernschaufel
3335	Bauernbesen
3336	Fleischbohrer
3337	Kriegsflagge der Dragonmaw
3339	Zwergenzunder
3340	Pyrophorerz
3341	Stulpen der Ogerstärke
3342	Käpt'n Sanders Hemd
3343	Käpt'n Sanders Beutetasche
3344	Käpt'n Sanders Schärpe
3345	Hexerseidenhut
3347	Bündel Krokiliskenhäute
3348	Riesige Krokiliskenhaut
3349	Sidas Tasche
3352	Brühschlammbedeckte Tasche
3353	Mit Runen beschrifteter Anhänger
3354	Anhänger aus Dalaran
3355	Wildstahlblume
3356	Königsblut
3357	Lebenswurz
3358	Khadgars Schnurrbart
3360	Oberschenkelknochen von Kleiner
3363	Ausgefranster Gürtel
3365	Ausgefranste Armschienen
3369	Grabmoos
3370	Flickwerkgürtel
3371	Leere Phiole
3372	Verbleite Phiole
3373	Flickwerkarmschienen
3374	Kattungürtel
3375	Kattunarmschienen
3376	Segeltuchgürtel
3377	Segeltucharmschienen
3378	Brokatgürtel
3379	Brokatarmschienen
3380	Kreuznahtgürtel
3381	Kreuznahtarmschienen
3382	Schwacher Trollbluttrank
3383	Elixier der Weisheit
3384	Schwacher Magiewiderstandstrank
3385	Geringer Manatrank
3386	Elixier des Giftwiderstands
3387	Begrenzter Unverwundbarkeitstrank
3388	Starker Trollbluttrank
3389	Elixier der Verteidigung
3390	Elixier der geringen Beweglichkeit
3391	Elixier der Ogerstärke
3392	Ringhelm
3393	Rezept: Schwacher Magiewiderstandstrank
3394	Rezept: Elixier des Giftwiderstands
3395	Rezept: Begrenzter Unverwundbarkeitstrank
3396	Rezept: Elixier der geringen Beweglichkeit
3397	Haut eines jungen Krokilisken
3399	Geierkralle
3400	Lucinen-Langschwert
3401	Raue Krokiliskenschuppe
3402	Weicher Fellflicken
3403	Elfenbeineberhauer
3404	Bussardflügel
3405	Rabenkrallentalisman
3406	Schwarzer Federkiel
3407	Saphir des Himmels
3408	Rune des Nistens
3409	Nachtsäbler-Fangzahn
3411	Strigideulenfeder
3412	Waldweberspinnenseide
3413	Verdammnisstachel
3414	Wappenszepter
3415	Stab des Fraters
3416	Märtyrerkette
3417	Onyx-Claymore
3418	Teufelszapfen
3419	Rote Rose
3420	Schwarze Rose
3421	Einfache Wildblumen
3422	Schöne Wildblumen
3423	Weißer Rosenstrauß
3424	Schwarzer Rosenstrauß
3425	Gewebter Zauberstab
3426	Knallgelbes Hemd
3427	Modisches schwarzes Hemd
3428	Gewöhnliches graues Hemd
3429	Gardisten-Gürtel
3430	Heckenschützen-Gewehr
3431	Knochenbeschlagenes Leder
3434	Schlummersand
3435	Zombiehaut-Armschienen
3437	Schnallengürtel
3438	Ankh der Auferstehung
3439	Zombiehaut-Stiefel
3440	Knochenknacker
3442	Lehrlingsschärpe
3443	Zeremonieller Tomahawk
3444	Tillers Weste
3445	Zeremonielles Messer
3446	Dunkelholzstab
3447	Gruftwandler-Stiefel
3448	Sengginwurzel
3449	Mystikerschal
3450	Faerleias Schild
3451	Nachtschimmergebräu
3452	Ceraniumrute
3453	Gesteppte Armschienen
3454	Aufklärer-Stiefel
3455	Todespirscherkurzschwert
3456	Hundepfeife
3457	Bedruckte Beinkleider
3458	Unverwüstliche Panzerhandschuhe
3460	Johaans Spezialgetränk
3461	Hohe Robe des Schiedsrichters
3462	Krallenschlag
3463	Silberstern
3464	Gefiederter Pfeil
3465	Explosivgeschoss
3466	Starker Fluxus
3467	Glanzloser Eisenschlüssel
3468	Renferrels Funde
3469	Kupferne Kettenstiefel
3470	Rauer Schleifstein
3471	Kupferne Kettenweste
3472	Runenverzierte Kupferstulpen
3473	Runenverzierte Kupferhose
3474	Edelsteinbesetzte Kupferstulpen
3475	Flammen-Umhang
3476	Graubärenzunge
3477	Krabblersekret
3478	Grober Schleifstein
3480	Raue bronzene Schultern
3481	Bronzene Schultern mit Versilberung
3482	Bronzene Stiefel mit Versilberung
3483	Bronzene Stulpen mit Versilberung
3484	Grüne Eisenstiefel
3485	Grüne Eisenstulpen
3486	Schwerer Schleifstein
3487	Schweres Kupferbreitschwert
3488	Kupferstreitaxt
3489	Dicke Kriegsaxt
3490	Tödlicher Bronzepoignard
3491	Schwerer bronzener Streitkolben
3492	Mächtiger Eisenhammer
3493	Raptor-Ex
3495	Elixier des Leidens
3496	Berglöwenblut
3497	Elixier der Schmerzen
3498	Tarethas Halskette
3499	Polierter goldener Schlüssel
3502	Morastschnauzenkappen
3505	Alteracsiegelring
3506	Morastschnauzengemisch
3508	Morastschnauzenmixtur
3509	Säbelflossenschuppe
3510	Fetzenflossenauge
3511	Volksmiliz-Umhang
3514	Mor'Ladims Schädel
3515	Ataerics Stab
3516	Lescovars Kopf
3517	Fässchen Shindigger-Starkbier
3518	Entschlüsselter Brief
3520	Besudeltes Fässchen
3521	Geschickt verschlüsselter Brief
3522	Schwarze Nachtelfen-Brustplatte
3523	Ungenutzte schwarze Nachtelfen-Hose
3524	Ungenutzte schwarze Nachtelfen-Stiefel
3525	Ungenutzte schwarze Nachtelfen-Armschienen
3526	Schwarze Nachtelfen-Handschuhe
3527	Weiße Nachtelfen-Brustplatte
3528	Rote Leder-C03-Brustplatte
3529	Schwarzer Nachtelfen-Helm
3530	Wollverband
3531	Schwerer Wollverband
3532	Unused Red Leather C03 Pants
3533	Rote Leder-C03-Stiefel
3534	Unused Red Leather C03 Gloves
3535	Rote Leder-C03-Armschienen
3536	Dämonenjägeraugenbinde
3537	Schwarze Leder-D02-Brustplatte
3538	Graue Leder-D02-Brustplatte
3539	Unused Black Leather D02 Pants
3540	Unused Gray Leather D02 Pants
3541	Schwarze Leder-D02-Stiefel
3542	Graue Leder-D02-Stiefel
3543	Unused Black Leather D02 Gloves
3544	Unused Gray Leather D02 Gloves
3545	Schwarze Leder-D02-Armschienen
3546	Graue Leder-D02-Armschienen
3547	Weiße Leder-D03-Brustplatte
3548	Unused White Leather D03 Pants
3549	Unused White Leather D03 Gloves
3550	Targs Kopf
3551	Muckrakes Kopf
3552	Glommus' Kopf
3553	Mug'Thols Kopf
3554	Krone des Willens
3555	Robe von Solomon
3556	Schreckensmagierhut
3557	Ungenutztes Wams von Chow
3558	Fen-Bewahrerrobe
3559	Nachtwache-Stulpen
3560	Mantel der Ehre
3561	Widerstandsfähiger Poncho
3562	Gürtel der Rechtfertigung
3563	Seefahrerpantalons
3564	Eisenlieferung
3565	Bierbefleckte Handschuhe
3566	Raptorbannrüstung
3567	Zwergische Angelrute
3569	Vikarsrobe
3570	Knochenmahlerstößel
3571	Trogg-Prügler
3572	Daryls Kurzschwert
3573	Jagdköcher
3574	Jagdmunitionssack
3575	Eisenbarren
3576	Zinnbarren
3577	Goldbarren
3578	Hose des Erntearbeiters
3581	Sägemesser
3582	Säurefester Umhang
3583	Verwitterter Gürtel
3585	Tarntunika
3586	Baumspalter
3587	Bestickter Gürtel
3588	Bestickte Armschienen
3589	Schwerer Stoffgürtel
3590	Schwere Stoffarmschienen
3591	Gefütterter Gürtel
3592	Gefütterte Armschienen
3593	Rotbrauner Gürtel
3594	Rotbraune Armschienen
3595	Zerlumpter Stoffgürtel
3596	Zerlumpte Stoffarmschienen
3597	Dicker Stoffgürtel
3598	Dicke Stoffarmschienen
3599	Dünner Stoffgürtel
3600	Dünne Stoffarmschienen
3601	Schreiben des Syndikats
3602	Gestrickter Gürtel
3603	Gestrickte Armschienen
3604	Schultergürtel der Nachtwache
3605	Köcher der Nachtwache
3606	Gewebter Gürtel
3607	Gewebte Armschienen
3608	Pläne: Mächtiger Eisenhammer
3609	Pläne: Kupferne Kettenweste
3610	Pläne: Edelsteinbesetzte Kupferstulpen
3611	Pläne: Grüne Eisenstiefel
3612	Pläne: Grüne Eisenstulpen
3613	Valdreds Hände
3614	Jaulers Tatze
3615	Kurzens Kopf
3616	Gedankenauge
3617	Schattenanhänger
3618	Gobblers Kopf
3619	Snelligs Schnupftabakdose
3620	Lilliths sterbliche Überreste
3621	Ivars Kopf
3622	Nachtseeles Essenz
3623	Thules Kopf
3625	Nek'roshs Kopf
3626	Kopf von Baron Vardus
3627	Fangzahn von Vagash
3628	Hand von Dextren Ward
3629	Ring der Familie Mistmantle
3630	Targorrs Kopf
3631	Stopfwansts Hauer
3632	Fangors Tatze
3633	Garth'Ilzoggs Kopf
3634	Grimsons Kopf
3635	Madenauges Tatze
3636	Schuppe von Old Murk-Eye
3637	Van Cleefs Kopf
3638	Sarlatans Kralle
3639	Balgaras' Ohr
3640	Deepfurys Kopf
3641	Gesellenarmschienen
3642	Vorfahren-Armschienen
3643	Zauberbinder-Armschienen
3644	Barbarische Stoffarmschienen
3645	Sehermanschetten
3647	Helle Armschienen
3648	Kriegerrundschild
3649	Stammesrundschild
3650	Kampfschild
3651	Veteranenschild
3652	Jagdrundschild
3653	Zeremonieller Rundschild
3654	Brackwasserschild
3655	Brünierter Schild
3656	Züngelnder Schuppenschild
3657	Stadtverzeichnis von Hillsbrad
3658	Zurückgeholter Foliant
3659	Abgenutztes Lederbuch
3660	Folianten von Alterac
3661	Handgefertigter Stab
3662	Krokiliskensteak
3663	Murlocflossensuppe
3664	Krokiliskengumbo
3665	Seltsam schmeckendes Omelett
3666	Klebriger Spinnenkuchen
3667	Zartes Krokiliskenfleisch
3668	Auftragsmördervertrag
3669	Gelatineartige Schmiere
3670	Großer schleimiger Knochen
3671	Lebloser Schädel
3672	Nagaz' Kopf
3673	Zerbrochener Pfeil
3674	Verrotteter Stiefel
3675	Abgebrannte Fackel
3676	Schleimiges Sekret
3678	Rezept: Krokiliskensteak
3679	Rezept: Blutwurst
3680	Rezept: Murlocflossensuppe
3681	Rezept: Krokiliskengumbo
3682	Rezept: Seltsam schmeckendes Omelett
3683	Rezept: Klebriger Spinnenkuchen
3684	Perenolde-Tiara
3685	Raptorei
3688	Blutsteinoval
3689	Blutsteinmarmor
3690	Blutsteinsplitter
3691	Blutsteinkeil
3692	Menschlicher Schädel aus Hillsbrad
3693	Humberts Schwert
3701	Darthalias versiegelte Belobigung
3702	Bärengallenblase
3703	Southshore-Starkbier
3704	Verrosteter Eisenschlüssel
3706	Verhextes Pergament
3707	Nagaz-Pergament
3708	Helculars Rute
3710	Rute von Helcular
3711	Belamoores Forschungstagebuch
3712	Schildkrötenfleisch
3713	Feine Gewürze
3714	Abgenutzte Steinmarke
3715	Armschienen der Erdbindung
3716	Kopf eines Murloc
3717	Sack mit Murlocköpfen
3718	Furchteinflößende Pläne
3719	Umhang des Hügelwächters
3720	Yetifell
3721	Farrens Bericht
3722	Familiarbalg
3723	Familiarfangzahn
3724	Familiarklaue
3725	Familiarhorn
3726	Großes Bärensteak
3727	Scharfe Löwenkoteletts
3728	Schmackhaftes Löwensteak
3729	Milde Schildkrötensuppe
3730	Großbärenfleisch
3731	Löwenfleisch
3732	Kapuzenkutte
3733	Orc-Kriegskette
3734	Rezept: Großes Bärensteak
3735	Rezept: Scharfe Löwenkoteletts
3736	Rezept: Schmackhaftes Löwensteak
3737	Rezept: Milde Schildkrötensuppe
3738	Rute des Brauens
3739	Schädelring
3740	Köpferschwert
3741	Stampfer-Stiefel
3742	Plünderbogen
3743	Wachpostenrundschild
3744	Blutsteinanhänger
3745	Rune des Öffnens
3747	Meditative Schärpe
3748	Felinen-Mantel
3749	Hochapotheker-Umhang
3750	Rippenbrustplatte
3751	Söldnergamaschen
3752	Grunzerweste
3753	Schafhirten-Gurt
3754	Schafhirten-Handschuhe
3755	Fischausnehmer
3758	Kreuzfahrer-Gürtel
3759	Isolierte Weisenhandschuhe
3760	Band von Undercity
3761	Totenschädelschild
3762	Bibliothekarsranzen
3763	Lunarrundschild
3764	Mantis-Stiefel
3765	Briganten-Schulterstücke
3766	Greifenfederkiel
3767	Feines Pergament
3769	Zerbrochener Zauberstab
3770	Hammelkoteletts
3771	Wildschweinschenkel
3772	Herbeigezaubertes Quellwasser
3775	Verkrüppelndes Gift
3776	Verkrüppelndes Gift II
3777	Lethargiewurzel
3778	Gespannter Kompaktbogen
3779	Kräftige Kriegsaxt
3780	Langläufige Muskete
3781	Breites Claymore
3782	Große Kriegskeule
3783	Leichter Krummsäbel
3784	Metallstock
3785	Beißende Axt
3786	Glänzender Langdolch
3787	Steinkeule
3788	Seelenkristallrelikt
3789	Reliktstein der Frömmigkeit
3790	Geweihtes Reliktpergament
3791	Relikt des Lichts
3792	Geflochtener Gürtel
3793	Geflochtene Stiefel
3794	Geflochtene Armschienen
3795	Geflochtener Umhang
3796	Geflochtene Handschuhe
3797	Geflochtene Hose
3798	Geflochtene Schulterpolster
3799	Geflochtene Weste
3800	Gehärteter Ledergürtel
3801	Gehärtete Lederstiefel
3802	Gehärtete Lederarmschienen
3803	Gehärteter Umhang
3804	Gehärtete Lederhandschuhe
3805	Gehärtete Lederhose
3806	Gehärtete Lederschulterpolster
3807	Gehärtete Ledertunika
3808	Doppelpanzergürtel
3809	Doppelpanzerstiefel
3810	Doppelpanzerarmschienen
3811	Doppelt genähter Umhang
3812	Doppelpanzerhandschuhe
3813	Doppelpanzerhose
3814	Doppelpanzerschulterpolster
3815	Doppelpanzerweste
3816	Reflektierender Langschild
3817	Verstärkter Rundschild
3818	Blassblatt
3819	Winterbiss
3820	Würgetang
3821	Golddorn
3822	Runenverzierte Dunkelklinge
3823	Geringer Unsichtbarkeitstrank
3824	Schattenöl
3825	Elixier der Seelenstärke
3826	Mächtiger Trollbluttrank
3827	Manatrank
3828	Elixier der Entd. geringer Unsichtbarkeit
3829	Frostöl
3830	Rezept: Elixier der Seelenstärke
3831	Rezept: Mächtiger Trollbluttrank
3832	Rezept: Elixier der Entdeckung geringer Unsichtbarkeit
3833	Adepten-Umhang
3834	Feste Stoffbeinkleider
3835	Grüne Eisenarmschienen
3836	Grüner Eisenhelm
3837	Goldene Schuppenhelmkappe
3838	Schattentatzenklaue
3839	Makelloser Tigerinnen-Fangzahn
3840	Grüne Eisenschultern
3841	Goldene Schuppenschultern
3842	Grüne Eisengamaschen
3843	Goldene Schuppengamaschen
3844	Grüne Eisenhalsberge
3845	Goldener Schuppenkürass
3846	Polierte Stahlstiefel
3847	Goldene Schuppenstiefel
3848	Großes bronzenes Messer
3849	Gehärtetes Eisenkurzschwert
3850	Jadeschlangenklinge
3851	Robuster Eisenschlägel
3852	Goldener Eisenzerstörer
3853	Mondstahlbreitschwert
3854	Frosttigerklinge
3855	Massive Eisenaxt
3856	Schattensichelaxt
3857	Kohle
3858	Mithrilerz
3859	Stahlbarren
3860	Mithrilbarren
3861	Schwarzstahlbarren
3862	Sehne eines alten Gorillas
3863	Dschungelpirscherfeder
3864	Citrin
3866	Pläne: Jadeschlangenklinge
3867	Pläne: Goldener Eisenzerstörer
3868	Pläne: Frosttigerklinge
3869	Pläne: Schattensichelaxt
3870	Pläne: Grüne Eisenschultern
3871	Pläne: Goldene Schuppenschultern
3872	Pläne: Goldene Schuppengamaschen
3873	Pläne: Goldener Schuppenkürass
3874	Pläne: Polierte Stahlstiefel
3875	Pläne: Goldene Schuppenstiefel
3876	Fangzahn von Bhag'thera
3877	Kralle von Tethis
3879	Tatze von Sin'Dall
3880	Bangalashs Kopf
3882	Bussardfeder
3889	Rotbrauner Hut
3890	Beschlagener Hut
3891	Aufgebesserter Kettenhelm
3892	Bestickter Hut
3893	Verstärkte Lederkappe
3894	Brigantinenhelm
3897	Dizzys Auge
3898	Bibliotheksschein
3899	Legenden der Gurubashi, Band 3
3900	Pupellyverbos-Portwein
3901	Hauer der Bloodscalp
3902	Stab der Adligen
3904	Gan'zulahs Kopf
3905	Nezzlioks Kopf
3906	Balia'mah-Trophäe
3907	Ziata'jai-Trophäe
3908	Zul'Mamwe-Trophäe
3909	Zerbrochene Rüstung von Ana'thek
3910	Schnupftabak
3911	Pulsierender blauer Splitter
3912	Seelenedelstein
3913	Gefüllter Seelenedelstein
3914	Gesellenrucksack
3915	Blutige Knochenhalskette
3916	Spaltknochenhalskette
3917	Singender blauer Kristall
3918	Singender Kristallsplitter
3919	Nebeltalinnereien
3920	Blutsegelkarten
3921	Blutsegelbefehle
3922	Zitterhands Bezahlung
3923	Armschienen eines Wasserelementars
3924	Maurys Klumpfuß
3925	Jon-Jons goldenes Handfernrohr
3926	Chuckys gewaltiger Ring
3927	Feiner alter Cheddar
3928	Überragender Heiltrank
3929	Maurys Beute
3930	Maurys Schlüssel
3931	Vergifteter Spinnenfangzahn
3932	Smotts' Truhe
3935	Smotts' Entersäbel
3936	Häkelgürtel
3937	Häkelstiefel
3938	Häkelarmschienen
3939	Häkelumhang
3940	Häkelhandschuhe
3941	Häkelhose
3942	Häkelschulterpolster
3943	Häkelweste
3944	Köpergürtel
3945	Köperstiefel
3946	Köperarmschienen
3947	Köperumhang
3948	Köperhandschuhe
3949	Köperhose
3950	Köperschulterpolster
3951	Köperweste
3952	Maschengürtel
3953	Maschenstiefel
3954	Maschenarmschienen
3955	Maschenumhang
3956	Maschenhandschuhe
3957	Maschenhose
3958	Maschenmantel
3959	Maschenrüstung
3960	Tasche mit Armschienen von Wasserelementaren
3961	Dicker Ledergürtel
3962	Dicke Lederstiefel
3963	Dicke Lederarmschienen
3964	Dicker Umhang
3965	Dicke Lederhandschuhe
3966	Dicke Lederhose
3967	Dicke Lederschulterpolster
3968	Dicke Ledertunika
3969	Glatter Ledergürtel
3970	Glatte Lederstiefel
3971	Glatte Lederarmschienen
3972	Glatter Umhang
3973	Glatte Lederhandschuhe
3974	Glatte Lederhose
3975	Glatte Lederschulterpolster
3976	Glatte Lederrüstung
3977	Riemengürtel
3978	Riemenstiefel
3979	Riemenarmschienen
3980	Riemenumhang
3981	Riemenhandschuhe
3982	Riemenhose
3983	Riemenschulterpolster
3984	Riemenrüstung
3985	Schärpe mit Monogramm
3986	Schutzpavese
3987	Abwehrturm
3988	Plattenwallschild
3989	Blocktartsche
3990	Wappen-Rundschild
3991	Plattenrundschild
3992	Laminierter Schuppengürtel
3993	Laminierte Schuppenstiefel
3994	Laminierte Schuppenarmschienen
3995	Laminierter Schuppenumhang
3996	Laminierte Schuppenhandschuhe
3997	Laminierte Schuppenhose
3998	Laminierte Schuppenschulterstücke
3999	Laminierte Schuppenrüstung
4000	Doppelverbundkettengürtel
4001	Doppelverbundkettenstiefel
4002	Doppelverbundkettenarmschienen
4003	Doppelverbundkettenumhang
4004	Doppelverbundkettenhandschuhe
4005	Doppelverbundkettenhose
4006	Doppelverbundkettenschulterpolster
4007	Doppelverbundkettenrüstung
4008	Sterling-Kettengürtel
4009	Sterling-Kettenstiefel
4010	Sterling-Kettenarmschienen
4011	Sterling-Kettenumhang
4012	Sterling-Kettenhandschuhe
4013	Sterling-Kettenhose
4014	Sterling-Kettenschulterpolster
4015	Sterling-Kettenrüstung
4016	Zanzils Mixtur
4017	Scharfes Kurzschwert
4018	Gewetztes Claymore
4019	Schwere Feuersteinaxt
4020	Absplitternde Streitaxt
4021	Stumpfer Streitkolben
4022	Schmetterschlägel
4023	Feiner Spitzdolch
4024	Schwerer Kriegsstab
4025	Ausbalancierter Langbogen
4026	Schildwachenmuskete
4027	Catelyns Klinge
4028	Bündel Akirisschilfrohr
4029	Akirisschilfrohr
4030	Heiliges Reliktwasser
4031	Geheiligter Reliktglücksbringer
4032	Strahlender Relikthammer
4033	Dämmerungsleuchten
4034	Stein der Gezeiten
4035	Silberfadenrobe
4036	Silberfadenmanschetten
4037	Silberfadenhose
4038	Nachthauchrobe
4039	Nachthauchkutte
4040	Nachthauchhandschuhe
4041	Aurorakutte
4042	Aurorahandschuhe
4043	Auroraarmschienen
4044	Aurorahose
4045	Blaunebelarmschienen
4046	Blaunebelhosen
4047	Blaunebelstiefel
4048	Geschmückter Hut
4049	Geschmückte Armschienen
4050	Geschmückte Gamaschen
4051	Geschmückte Stiefel
4052	Insignien-Kappe
4053	Große Flusskrokiliskenhaut
4054	Insignien-Gamaschen
4055	Insignien-Stiefel
4056	Cortellos Rätsel
4057	Insignienbrustschutz
4058	Glyphenverzierte Brustplatte
4059	Glyphenverzierte Armschienen
4060	Glyphenverzierte Gamaschen
4061	Imperiale Lederarmschienen
4062	Imperiale Lederhose
4063	Imperiale Lederhandschuhe
4064	Geschmückter Rundschild
4065	Gefechtsschild
4066	Insignien-Rundschild
4067	Glyphenverzierter Rundschild
4068	Oberbrigadierschild
4069	Schwarzschmiederundschild
4070	Tjoster-Wappen
4071	Gleißende Panzerbrustplatte
4072	Gleißende Panzerhandschuhe
4073	Gleißende Panzerschienbeinschützer
4074	Gepanzerte Gefechtsrüstung
4075	Gepanzerte Gefechtshandschuhe
4076	Gepanzerte Gefechtsstiefel
4077	Gepanzerter Gefechtskopfschutz
4078	Oberbrigadierhelmkappe
4079	Oberbrigadiergamaschen
4080	Schwarzschmiedekutte
4082	Schwarzschmiedebrustplatte
4083	Schwarzschmiedestulpen
4084	Schwarzschmiedegamaschen
4085	Krazeks Spezialtopf
4086	Blitzgewehr
4087	Volltrefferbogen
4088	Schreckensklinge
4089	Abprall-Donnerbüchse
4090	Becher des Schmerzes
4091	Witwenmacher
4092	Prismabasiliskenschuppe
4093	Großer Basiliskenschwanz
4094	Schrifttafelsplitter
4095	Ausgedientes Schlingenfallenset
4096	Grobes Gorillahaar
4097	Gesplitterter Gorillazahn
4098	Sorgfältig gefaltete Notiz
4099	Büschel Gorillahaare
4100	Zusammengeknüllte Notiz
4101	Zerfetzte Notiz
4102	Zerrissene Notiz
4103	Fesselschlüssel
4104	Schnappkieferkrokiliskenhaut
4105	Haut eines alten Krokilisken
4106	Gerommelter Kristall
4107	Tigerjäger-Handschuhe
4108	Pantherjäger-Gamaschen
4109	Exzelsiorstiefel
4110	Meisterjägerbogen
4111	Meisterjägergewehr
4112	Halsschmuck des Hochschamanen
4113	Medizindecke
4114	Cape der dunklen Wogen
4115	Rundschild von Grom'gol
4116	Sewar des alten Mannes
4117	Versengerschärpe
4118	Poobahs Nasenring
4119	Raptorjägertunika
4120	Robe des Kristallwassers
4121	Edelsteinbesetzte Handschuhe
4122	Buchmacherszepter
4123	Frostmetallschulterstücke
4124	Kappe der Harmonie
4125	Gelassenheitskugel
4126	Guerillaspaltbeil
4127	Schrapnellblaster
4128	Silberspaten
4129	Sammelplatte
4130	Smotts' Kompass
4131	Gürtel der Verderbnis
4132	Armsplinte der Darkspear
4133	Manschetten der Darkspear
4134	Nimboyas mystischer Stab
4135	Blutknochenband
4136	Stiefel der Darkspear
4137	Schuhe der Darkspear
4138	Schwarzmeertunika
4139	Dschungelwandler-Sandalen
4140	Palmwedel-Mantel
4141	Foliant des Essen-Herbeizauberns
4142	Foliant der Verwandlung: Schwein
4143	Foliant des Essen-Herbeizauberns II
4144	Foliant der Verwandlung: Kuh
4145	Foliant des Manaedelstein-Herbeizauberns II
4146	Foliant der Verwandlung: Schaf
4147	Foliant des Essen-Herbeizauberns III
4148	Foliant des Gegenzaubers
4149	Foliant des Frostschilds III
4150	Foliant des Wasser-Herbeizauberns IV
4151	Foliant des Frostblitzes IV
4152	Foliant des Essen-Herbeizauberns IV
4153	Foliant der arkanen Geschosse III
4154	Foliant der Verlangsamung II
4155	Foliant der Wasserelementare II
4157	Foliant des Magiedämpfens
4158	Foliant von Khadgars Öffnung III
4159	Foliant der arkanen Geschosse
4160	Foliant der Unsichtbarkeit
4161	Foliant des Feuerballs IV
4162	Foliant des Blinzelns II
4164	Buchband: Heiliges Licht V
4165	Buchband: Heiliges Licht VI
4166	Buchband: Siegel des Schutzes
4167	Buchband: Richturteil
4168	Schrifttafel des Einschnüren-Totems
4169	Schrifttafel des Unerschütterlichen Willens II
4170	Schrifttafel des Astralen Rückrufs
4171	Schrifttafel des Aufstachelnden Totems III
4172	Schrifttafel des Donnerknalls II
4173	Schrifttafel des Schocks IV
4174	Schrifttafel des Schocks V
4175	Schrifttafel des Blitzschlagschildes IV
4176	Schrifttafel der Unsterblichen Stärke II
4177	Schrifttafel des Naturwiderstands
4178	Schrifttafel des Blitzschlags V
4179	Schrifttafel der Wiederherstellung V
4180	Schrifttafel der Astralgestalt II
4181	Schrifttafel des Aufstachelnden Totems IV
4182	Schrifttafel des Unerschütterlichen Willens III
4183	Schrifttafel des Totems der Heilung V
4184	Schrifttafel des Schmelzschlages V
4185	Schrifttafel des Gruppen-Astralrückrufs
4186	Schrifttafel des Feuerwiderstands
4187	Schrifttafel des Schlangentotems V
4188	Schrifttafel des Totems der Unsichtbarkeit
4189	Schrifttafel des Kettenblitzschlages
4190	Gefiederte Rüstung
4191	Ungenutzte gefiederte Gamaschen
4192	Ungenutzte gefiederte Stulpen
4194	Gefiederte Armschienen
4195	Gefiederte Stiefel
4196	Gefiederter Mantel
4197	Beryllpolster
4198	Zauberfoliant des Seelentrichters
4199	Zauberfoliant des Seelentrichters II
4200	Zauberfoliant des Feuerbrandes III
4201	Zauberfoliant des Auges von Kilrogg
4202	Zauberfoliant der Furcht II
4203	Zauberfoliant der Pestilenz II
4204	Zauberfoliant des Seelentrichters III
4205	Zauberfoliant des Feuerbrandes IV
4206	Zauberfoliant des Fluchs von Sargeras II
4207	Zauberfoliant des Fluchs von Archimonde
4208	Zauberfoliant der Gedankenbombe
4209	Zauberfoliant des Schattenzauberschutzes
4210	Zauberfoliant der geringen Blutsteinherstellung
4211	Zauberfoliant der Pestilenz
4212	Zauberfoliant des Fluchs von Mannoroth III
4213	Zauberfoliant der Verdammnis
4214	Zauberfoliant des Lebensaugers III
4215	Zauberfoliant des Feuerregens
4216	Zauberfoliant des heiligen Zauberschutzes
4217	Zauberfoliant des Seelentrichters IV
4218	Zauberfoliant der Blutsteinherstellung
4219	Zauberfoliant des brennenden Geistes IV
4220	Zauberfoliant des Siedebluts III
4221	Zauberfoliant der Entdeckung von Unsichtbarkeit
4223	Buch des Magie Aufhebens
4225	Buch der Wucherwurzeln III
4226	Buch des Zorns VI
4228	Buch des Mondfeuers IV
4230	Buch der heilenden Berührung VI
4231	Geschmeidiger leichter Balg
4232	Mittlerer Balg
4233	Geschmeidiger mittlerer Balg
4234	Schweres Leder
4235	Schwerer Balg
4236	Geschmeidiger schwerer Balg
4237	Handgenähter Ledergürtel
4238	Leinentasche
4239	Geprägte Lederhandschuhe
4240	Wolltasche
4241	Grüne Wolltasche
4242	Geprägte Lederhose
4243	Feine Ledertunika
4244	Lederweste des Hügelwächters
4245	Kleines Seidenpack
4246	Feiner Ledergürtel
4247	Lederhandschuhe des Hügelwächters
4248	Dunkle Lederhandschuhe
4249	Dunkler Ledergürtel
4250	Gürtel des Hügelwächters
4251	Schultern des Hügelwächters
4252	Dunkle Lederschultern
4253	Gekräftigte Lederhandschuhe
4254	Barbarische Handschuhe
4255	Grüne Lederrüstung
4256	Wächterrüstung
4257	Grüner Ledergürtel
4258	Wächtergürtel
4259	Grüne Lederarmschienen
4260	Wächterlederarmschienen
4261	Sollidens Beinkleider
4262	Edelsteinbesetzter Ledergürtel
4263	Standardausrüstungsschild
4264	Barbarischer Gürtel
4265	Schweres Rüstungsset
4266	Kodex des Inneren Feuers II
4267	Kodex des Schattenwortes: Ungeschick
4268	Kodex der Heilung III
4269	Kodex des Gebets der Heilung
4270	Kodex der Heilung III
4271	Kodex des Heiligen Schmetterns V
4272	Kodex des Heiligen Schutzes
4273	Kodex der Heilung
4274	Kodex der Göttlichen Flucht
4275	Kodex des Gedankenverfalls
4276	Kodex des Schattenwortes: Ungeschick II
4277	Kodex des Schattenwortes: Verwirrung II
4278	Geringes Blutsteinerz
4279	Kodex des Schattenwortes: Schmerz V
4280	Kodex des Heiligen Wortes: Schild IV
4281	Kodex des Schattenschutzes
4282	Kodex der Magiebannung II
4283	Kodex des Schlafs III
4284	Kodex des Heiligen Schmetterns VI
4285	Kodex des Heiligen Wortes: Seelenstärke IV
4286	Kodex des Gebets der Heilung II
4287	Kodex der Krankheit-Neutralisierung II
4288	Kodex der Fluchaufhebung II
4289	Salz
4290	Staubschale
4291	Seidenfaden
4292	Muster: Grüne Wolltasche
4293	Muster: Lederweste des Hügelwächters
4294	Muster: Gürtel des Hügelwächters
4296	Muster: Dunkle Lederschultern
4297	Muster: Barbarische Handschuhe
4298	Muster: Wächtergürtel
4299	Muster: Wächterrüstung
4300	Muster: Wächterlederarmschienen
4301	Muster: Barbarischer Gürtel
4302	Kleiner grüner Dolch
4303	Hirnschalenprügler
4304	Dickes Leder
4305	Seidenstoffballen
4306	Seidenstoff
4307	Schwere Leinenhandschuhe
4308	Grüne Leinenarmschienen
4309	Handgenähte Leinenkniehosen
4310	Schwere Wollhandschuhe
4311	Schwerer Wollumhang
4312	Leinenschuhe mit weichen Sohlen
4313	Rote Wollstiefel
4314	Doppeltgenähte Wollschultern
4315	Verstärkte Wollschultern
4316	Schwere Wollhose
4317	Phönixhose
4318	Handschuhe der Meditation
4319	Azurblaue Seidenhandschuhe
4320	Spinnenseidenstiefel
4321	Spinnenseidenslipper
4322	Verzaubererkutte
4323	Schattenkapuze
4324	Azurblaue Seidenweste
4325	Stiefel des Verzauberers
4326	Langer Seidenumhang
4327	Eisiger Umhang
4328	Spinnengürtel
4329	Sternengürtel
4330	Modisches rotes Hemd
4331	Phönixhandschuhe
4332	Hellgelbes Hemd
4333	Dunkles Seidenhemd
4334	Formelles weißes Hemd
4335	Dunkellilanes Seidenhemd
4336	Schwarzes Schwadroneurshemd
4337	Dicke Spinnenseide
4338	Magiestoff
4339	Magiestoffballen
4340	Grauer Farbstoff
4341	Gelber Farbstoff
4342	Lila Farbstoff
4343	Braune Leinenhose
4344	Braunes Leinenhemd
4345	Muster: Rote Wollstiefel
4346	Muster: Schwerer Wollumhang
4347	Muster: Verstärkte Wollschultern
4348	Muster: Phönixhandschuhe
4349	Muster: Phönixhose
4350	Muster: Spinnenseidenslipper
4351	Muster: Schattenkapuze
4352	Muster: Stiefel des Verzauberers
4353	Muster: Spinnengürtel
4354	Muster: Dunkellilanes Seidenhemd
4355	Muster: Eisiger Umhang
4356	Muster: Sternengürtel
4357	Raues Sprengpulver
4358	Raues Dynamit
4359	Eine Hand voll Kupferbolzen
4360	Raue Kupferbombe
4361	Kupferrohr
4362	Raues Schießeisen
4363	Kupfermodulator
4364	Grobes Sprengpulver
4365	Grobes Dynamit
4366	Zielattrappe
4367	Kleine Zephyriumladung
4368	Fliegerbrille
4369	Tödliche Donnerbüchse
4370	Große Kupferbombe
4371	Bronzeröhre
4372	Liebevoll hergestelltes Schießeisen
4373	Schattenschutzbrille
4374	Kleine Bronzebombe
4375	Surrendes bronzenes Dingsda
4376	Flammendeflektor
4377	Schweres Sprengpulver
4378	Schweres Dynamit
4379	Versilberte Schrotflinte
4380	Große Bronzebombe
4381	Schwacher Rekombobulator
4382	Bronzegerüst
4383	Mondsichtgewehr
4384	Explodierendes Schaf
4385	Schutzbrille mit grünen Gläsern
4386	Eisdeflektor
4387	Eisenstrebe
4388	Diskombobulatorstrahl
4389	Gyrochronatom
4390	Eisengranate
4391	Kompaktes Ernteschnitterset
4392	Hochentwickelte Zielattrappe
4393	Handwerkermonokel
4394	Große Eisenbombe
4395	Goblin-Landmine
4396	Mechanischer Drachling
4397	Gnomisches Verbergungsgerät
4398	Große Zephyriumladung
4399	Holzgriff
4400	Schwerer Griff
4401	Kasten mit mechanischem Eichhörnchen
4402	Kleiner Flammenbeutel
4403	Tragbarer bronzener Mörser
4404	Silberkontakt
4405	Kunstloses Zielfernrohr
4406	Standardzielfernrohr
4407	Genaues Zielfernrohr
4408	Bauplan: Mechanisches Eichhörnchen
4409	Bauplan: Kleine Zephyriumladung
4410	Bauplan: Schattenschutzbrille
4411	Bauplan: Flammendeflektor
4412	Bauplan: Mondsichtgewehr
4413	Bauplan: Diskombobulatorstrahl
4414	Bauplan: Tragbarer bronzener Mörser
4415	Bauplan: Handwerkermonokel
4416	Bauplan: Goblin-Landmine
4417	Bauplan: Große Zephyriumladung
4419	Rolle der Intelligenz III
4421	Rolle des Schutzes III
4422	Rolle der Ausdauer III
4424	Rolle der Willenskraft III
4425	Rolle der Beweglichkeit III
4426	Rolle der Stärke III
4428	Spinnentaster
4429	Deepfurys Befehle
4430	Astraler Talisman
4432	Sully Balloos Brief
4433	Durchnässter Umschlag
4434	Vogelscheuchen-Beinkleider
4435	Korn von Myzrael
4436	Juwelenüberkrustete Schärpe
4437	Stab des Kanalisierers
4438	Faustkämpfer-Armschienen
4439	Haudraufkeule
4440	Siegelzeichen von Strom
4441	MacKreels Fusel
4443	Düstere Schulterstücke
4444	Schwarzer Hüllenschild
4445	Fleischschnitzer
4446	Schwarzgiftklinge
4447	Nacht-Umhang
4448	Hülle von Naraxis
4449	Naraxis' Fangzahn
4450	Siegelzeichenfragment
4453	Siegelzeichen des Thoradin
4454	Kralle von Vultros
4455	Raptorbalgharnisch
4456	Raptorbalggürtel
4457	Gegrillter Bussardflügel
4458	Siegelzeichen von Arathor
4459	Spröder Großdrachenknochen
4460	Zerfetztes Flügelnetz
4461	Raptorbalg
4462	Fäulnis-Umhang
4463	Perlenraptorhalsband
4464	Züchtigungs-Stiefel
4465	Knochenfaust-Handschuhe
4466	Siegelzeichen von Trollbane
4467	Siegelzeichen von Ignaeus
4468	Weggesteckter Trol'kalar
4469	Rute der Ordnung
4470	Einfaches Holz
4471	Feuerstein und Zunder
4472	Rolle von Myzrael
4473	Geisterhafte Fesseln
4474	Rabenholzbogen
4476	Bestienwandler-Robe
4477	Schändlicher Rundschild
4478	Schillernde Schuppengamaschen
4479	Brennender Glücksbringer
4480	Donnernder Glücksbringer
4481	Schäumender Glücksbringer
4482	Versiegelter Ordner
4483	Brennender Schlüssel
4484	Wappenschlüssel
4485	Donnernder Schlüssel
4487	Karten der TOLLEN MINNA
4488	Karten der SILBERGEIST
4489	Logbuch der TOLLEN MINNA
4490	Logbuch der SILBERGEIST
4491	Edelsteinjagdschutzbrille
4492	Elfen-Edelstein
4493	Elfen-Edelsteine
4494	Seehorns versiegelter Brief
4495	Blutsteinamulett
4496	Kleiner brauner Beutel
4497	Schwere braune Tasche
4498	Brauner Lederranzen
4499	Gewaltiger brauner Sack
4500	Reiserucksack
4502	Elfen-Edelsteinmuster
4503	Hauer der Witherbark
4504	Zwergenwachen-Umhang
4505	Sumpflandbeinkleider
4506	Abzeichen von Stromgarde
4507	Grubenkämpferschild
4508	Blutverschmierte Rüstung
4509	Seewolf-Handschuhe
4510	Beschmutzte Blutsteinkugel
4511	Schwarzmeerhammer
4512	Hochlandraptorauge
4513	Raptorherz
4514	Sara Balloos Hilfegesuch
4515	Marez' Kopf
4516	Ottos Kopf
4517	Falkensteins Kopf
4518	Zerrissenes Rollenfragment
4519	Zerknülltes Rollenfragment
4520	Angesengtes Rollenfragment
4521	Alteracgranit
4522	Medizinbeutel der Witherbark
4524	Balloos Gedenkstein
4525	Trelanes Zauberstab der Herbeirufung
4526	Raptorkrallen-Amulett
4527	Azurblauer Achat
4528	Tor'gans Kugel
4529	Verzauberter Achat
4530	Trelanes Phylakterium
4531	Trelanes Kugel
4532	Trelanes Glutachat
4533	Versiegelter Brief an Erzmagier Malin
4534	Stahlschnallenarmschienen
4535	Gedenkring von Ironforge
4536	Glänzender roter Apfel
4537	Tel'Abim-Banane
4538	Schnappranken-Wassermelone
4539	Goldrindenapfel
4540	Zäher Brocken Brot
4541	Frisch gebackenes Brot
4542	Saftiges Maisbrot
4543	Weiße Drachenhautkappe
4544	Gewürzbrot aus Mulgore
4545	Strahlende Silber-Armschienen
4546	Ruf des Raptors
4547	Gnomen-Schrumpfer
4548	Servomechanischer Vorschlaghammer
4549	Seefeuerband
4550	Kaltwasserring
4551	Or'Kalars Kopf
4552	Glattes Steinbruchstück
4553	Gezacktes Steinstück
4554	Glänzender polierter Stein
4555	Dicker geschuppter Schwanz
4556	Getupftes Muschelschalenfragment
4557	Feurige Drüse
4558	Leeres Fass
4559	CHU's QUEST ITEM
4560	Feiner Krummsäbel
4561	Skalpiertomahawk
4562	Abspalteraxt
4563	Hinterwäldlerkeule
4564	Stachelkeule
4565	Einfacher Dolch
4566	Stabiler Bauernstecken
4567	Söldnerschwert
4568	Grunzeraxt
4569	Zuverlässiger Hammer
4570	Birkenholzschlägel
4571	Kriegsmesser
4575	Medizinstab
4576	Leichter Bogen
4577	Kompakte Schrotflinte
4580	Säblerfangzahn
4581	Feiner Fellflicken
4582	Weicher buschiger Schweif
4583	Dicke fellige Mähne
4584	Große Trophäentatze
4585	Tropfender Spinnenunterkiefer
4586	Glatte Raptorenhaut
4587	Stammesraptorfedern
4588	Makelloser Raptorschädel
4589	Lange elegante Feder
4590	Geschwungener gelber Schnabel
4591	Adlerauge
4592	Langzahniger Matschschnapper
4593	Stoppelfühlerwels
4594	Steinschuppenkabeljau
4595	Dschungelrankenwein
4596	Verfärbter Heiltrank
4597	Rezept: Verfärbter Heiltrank
4598	Goblin-Angelrute
4599	Räucherschinkensteak
4600	Kirschgrog
4601	Weiches Bananenbrot
4602	Monderntekürbis
4603	Roher Tüpfelgelbschwanz
4604	Waldpilzkappe
4605	Rotgetupfter Pilz
4606	Schwammerl
4607	Köstlicher Höhlenschimmel
4608	Roher schwarzer Trüffel
4609	Rezept: Gegrillter Bussardflügel
4610	Verzierte Steinurne
4611	Blaue Perle
4612	Schwarzdrachenherz
4613	Zerfressener Flugschreiber
4614	Anhänger von Myzrael
4615	Schattenbringers Bindungen
4616	Ryedols Glückshacke
4621	Botschafter Infernus' Armschienen
4622	Versiegelte Notiz an Berater Belgrum
4623	Geringer Steinschildtrank
4624	Rezept: Geringer Steinschildtrank
4625	Feuerblüte
4626	Kleiner Steinsplitter
4627	Große Steinplatte
4628	Armschienen der Steinbindung
4629	Vorratskiste
4630	Metallschrott
4631	Schrifttafel von Ryun'eh
4632	Verschnörkelte bronzene Schließkassette
4633	Schwere bronzene Schließkassette
4634	Eisenschließkassette
4635	Hammertoes Amulett
4636	Starke Eisenschließkassette
4637	Stahlschließkassette
4638	Verstärkte Stahlschließkassette
4639	Verzauberter Seetang
4640	Zeichen der Erde
4641	Hand von Dagun
4643	Grimmstahlcape
4644	Das Herz des Vermächtnisses
4645	Ketten von Hematus
4646	Stern von Xil'yeh
4647	Yagyins Zusammenstellung
4648	Siegelzeichen des Hammers
4649	Bonegrips Notiz
4650	Bel'dugurs Notiz
4652	Salbacschild
4653	Eisenfersenstiefel
4654	Geheimnisvolles Fossil
4655	Riesenmuschelfleisch
4656	Kleiner Kürbis
4658	Kriegerumhang
4659	Kriegergurt
4660	Wander-Stiefel
4661	Heller Mantel
4662	Gesellenumhang
4663	Gesellengürtel
4665	Verbrannter Umhang
4666	Brandledergürtel
4668	Kampfkettenumhang
4669	Kampfkettengurt
4671	Vorfahren-Umhang
4672	Vorfahren-Gürtel
4674	Stammesumhang
4675	Stammesgürtel
4676	Skelettstulpen
4677	Veteranen-Mantel
4678	Veteranen-Gurt
4680	Brackwasserumhang
4681	Brackwassergurt
4683	Zauberbinder-Umhang
4684	Zauberbinder-Gürtel
4686	Barbarischer Stoffumhang
4687	Barbarischer Stoffgürtel
4689	Jagdumhang
4690	Jagdgürtel
4692	Zeremonieller Umhang
4693	Zeremonieller Ledergürtel
4694	Brünierte Schulterstücke
4695	Brünierter Umhang
4696	Lapidis Tidesippe-Humpen
4697	Brünierter Gurt
4698	Sehermantel
4699	Sehergürtel
4700	Gravierte Lederschiftung
4701	Gravierter Umhang
4702	Ausgrabungsleiterhacke
4703	Zerbrochene Werkzeuge
4705	Züngelnde Schuppenschulterstücke
4706	Züngelnder Schuppenumhang
4707	Züngelnder Schuppengurt
4708	Heller Gürtel
4709	Waldledermantel
4710	Waldumhang
4711	Gleißender Umhang
4712	Gleißender Panzergurt
4713	Silberfadenumhang
4714	Silberfadenschärpe
4715	Geschmückter Umhang
4716	Gefechtsumhang
4717	Gepanzerter Gefechtsgürtel
4718	Nachthauchmantel
4719	Nachthauchumhang
4720	Nachthauchschärpe
4721	Insignien-Mantel
4722	Insignien-Umhang
4723	Humberts Hose
4724	Humberts Helm
4725	Oberbrigadierschulterstücke
4726	Oberbrigadierumhang
4727	Oberbrigadiergurt
4728	Twains Schulter
4729	Auroramantel
4731	Glyphenverzierte Schulterklappen
4732	Glyphenverzierter Umhang
4733	Schwarzschmiedeschulterstücke
4734	Blaunebelmantel
4735	Blaunebelumhang
4736	Blaunebelschärpe
4737	Imperiale Lederschiftung
4738	Imperialer Ledergürtel
4739	Ebenenschreiter-Fleisch
4740	Ebenenschreiter-Feder
4741	Kavalleriegamaschen von Stromgarde
4742	Bergpumapelz
4743	Pulsierender Kristallinsplitter
4744	Arkane runenverzierte Armschienen
4745	Kriegsreiter-Armschienen
4746	Verdammnisverkünder-Robe
4747	Wasser des Brunnens von Stormbull
4748	Wasser des Brunnens von Redhorn
4749	Wasser des Brunnens von Wildmane
4751	Windfurienkralle
4752	Azurblaue Feder
4753	Bronzene Feder
4755	Wasserkanne
4756	Verdorbener Katzenpelz
4757	Gesprungene Eierschalen
4758	Präriewolftatze
4759	Ebenenschreiterkralle
4763	Schwarzholzdoppelbogen
4765	Emailliertes Breitschwert
4766	Wildklinge
4767	Kupferstoffhandschuhe
4768	Adepten-Handschuhe
4769	Trophäen-Sturzfliegerkiel
4770	Gürtel der Borstennacken
4771	Ernte-Umhang
4772	Warmer Umhang
4775	Gesprungener Schnabel
4776	Gesträubte Feder
4777	Eisenholzschlägel
4778	Schwerer Stachelkolben
4779	Glanzloser Kodozahn
4780	Kodohornfragment
4781	Flüsternde Weste
4782	Sonnenwend-Robe
4783	Totem von Hawkwind
4784	Lebloser Stein
4785	Schwefelgürtel
4786	Weisengürtel
4787	Brennendes Pech
4788	Bewegliche Stiefel
4789	Standfeste Stiefel
4790	Inferno-Umhang
4791	Verzaubertes Wasser
4792	Umhang des Willens
4793	Sylvanumhang
4794	Wolf-Armschienen
4795	Bären-Armschienen
4796	Eulenarmschienen
4797	Feuriger Umhang
4798	Schwerer runenverzierter Umhang
4799	Antiquierter Umhang
4800	Mächtige Kettenhose
4801	Pirscherklauen
4802	Pumaklauen
4803	Präriealphazahn
4804	Herz eines Präriewolfs
4805	Knochen eines Flachlandpumas
4806	Schuppe eines Ebenenschreiters
4807	Muskelmagen eines Sturzfliegers
4808	Quellstein
4809	Bernsteinkorn
4810	Felspolster
4813	Kleiner Lederkragen
4814	Verfärbter Fangzahn
4816	Legionärs-Gamaschen
4817	Gesegnetes Claymore
4818	Henkerschwert
4819	Fizsprockets Klemmbrett
4820	Wächterrundschild
4821	Bären-Rundschild
4822	Eulenscheibe
4823	Wasser der Seher
4824	Verschwommene Axt
4825	Gefühllose Axt
4826	Marodeursaxt
4827	Hexer-Gürtel
4828	Nachtwind-Gürtel
4829	Träumer-Gürtel
4830	Säbel-Gamaschen
4831	Pirsch-Hose
4832	Mystikersarong
4833	Glorreiche Schultern
4834	Dokumente der Venture Co.
4835	Eliteschultern
4836	Feuerfeste Kugel
4837	Stärke des Willens
4838	Kugel der Macht
4840	Langes Bajonett
4841	Horn von Arra'chea
4843	Amethystrunenstein
4844	Opalrunenstein
4845	Diamantrunenstein
4846	Zahnrad Nr. 5
4847	Lotwils Fesseln der Elementarbindung
4848	Kampfeberschnauze
4849	Kampfeberflanke
4850	Angriffspläne der Borstennacken
4851	Schmutzbefleckte Karte
4852	Blitzstrahlbombe
4854	Dämonennarben-Umhang
4855	Unused Cloth Shoulder A01 Gray
4856	Unused Cloth Shoulder A02 Yellow
4857	Unused Cloth Shoulder B01 Silver
4858	Unused Cloth Shoulder B02 Black
4859	Medaillon der Burning Blade
4860	Glitzernde Frenzyschuppe
4861	Schicke gefiederte Tunika
4862	Skorpidarbeiterschwanz
4863	Gnomen-Werkzeuge
4864	Minshinas Schädel
4865	Verdorbener Pelz
4866	Zalazanes Kopf
4867	Gebrochenes Skorpidbein
4869	Fizzles Klaue
4870	Segeltuchreste
4871	Senghalsband
4872	Trockenes Skorpidauge
4873	Trockener gehärteter Rankenfuß
4874	Abgenagte Gräten
4875	Schleimiger Knochen
4876	Blutiger Lederstiefel
4877	Steinpfeilspitze
4878	Zerbrochener blutbefleckter Bogen
4879	Zerquetschtes Hasengerippe
4880	Zerbrochener Speer
4881	Vergilbter Umschlag
4882	Benedicts Schlüssel
4883	Admiral Proudmoores Befehle
4886	Giftbeutel eines Siechstachelskorpiden
4887	Intaktes Makruraauge
4888	Kriechersekret
4890	Schwanzpeitscher-Ei
4891	Krons Amulett
4892	Durotar-Tigerfell
4893	Savannenlöwenhauer
4894	Ebenenschreiter-Niere
4895	Donnerechsen-Horn
4896	Kodoleber
4897	Donnerfalken-Speicheldrüse
4898	Blitzschlag-Drüse
4903	Auge des brennenden Schatten
4904	Siechstachelgegengift
4905	Sarkoths zerstückelte Klaue
4906	Regenwandler-Stiefel
4907	Waldland-Tunika
4908	Nomadenarmschienen
4909	Kodojäger-Gamaschen
4910	Bemalte Kettenhandschuhe
4911	Dickrindenrundschild
4913	Bemalter Kettengürtel
4914	Kampferprobte Lederhandschuhe
4915	Weiche Wollstiefel
4916	Weiche Wollweste
4917	Kampferprobte Kettengamaschen
4918	Sack Vorräte
4919	Weicher Wollgürtel
4920	Kampferprobtes Cape
4921	Staubbedeckte Gamaschen
4922	Gezackte Kettenweste
4923	Primitives Kriegsbeil
4924	Primitive Keule
4925	Primitive Handklinge
4926	Chens leeres Fässchen
4928	Sandläuferhandgelenksschützer
4929	Leichte Skorpidrüstung
4930	Handgefertigte Ledertasche
4931	Hickory-Kurzbogen
4932	Harpyienflügelstutzer
4933	Erfahrener Kämpfer-Umhang
4935	Breiter Metallgurt
4936	Schmutzstarrende Stiefel
4937	Angriffs-Rundschild
4938	Verunstalteter Holzstab
4939	Standhaftes Bastardschwert
4940	Verhüllter Handschutz
4941	Echt klebriger Leim
4942	Tigerbalg-Stiefel
4944	Handgenähter Umhang
4945	Schwach leuchtender Schädel
4946	Leichtgewichtige Stiefel
4947	Gezackter Dolch
4948	Stechender Streitkolben
4949	Orc-Spaltbeil
4951	Quietschers Gürtel
4952	Stormstout
4953	Trogggebräu
4954	Nomadengürtel
4957	Alte Geldtasche
4958	Sonnengebleichter Umhang
4959	Wurftomahawk
4960	Blitzkügelchen
4961	Traumbeobachter-Stab
4962	Doppellagige Handschuhe
4963	Thunderhorn-Umhang
4964	Goblin-Zerkracher
4965	Bloodhoof-Handaxt
4966	Mazzranaches Kopf
4967	Stammeskriegerschild
4968	Gebundener Harnisch
4969	Verstärkte Bindungen
4970	Grobgehauene Kodogamaschen
4971	Skorns Hammer
4972	Stiefel des Klippenläufers
4973	Handgelenksschützer des Ebenenjägers
4974	Kompaktes Streitmesser
4975	Wachsamkeits-Rundschild
4976	Nebelhauchkilt
4977	Schwert von Hammerfall
4978	Ryedols Hammer
4979	Verzauberte Steinstoffarmschienen
4980	Ausgrabungsleiter-Handschuhe
4981	Agmonds Gürtelbeutel
4982	Zerfetzter Ausgrabungsleiter-Gürtel
4983	Felspulverisierer
4984	Schädel der drohenden Verdammnis
4986	Fehlerhafter Kraftstein
4987	Schwert des Zwergenkapitäns
4988	Brennendes Obsidianband
4989	Magierdrachenschwarm-Robe
4990	Versengte Bänder
4992	Anwerbungsbrief
4995	Unterschriebener Anwerbungsbrief
4998	Blutring
4999	Azoras Testament
5000	Korallenband
5001	Herzring
5002	Leuchtender grüner Talisman
5003	Kristallsternenfeuer-Medaillon
5004	Mal der Kirin Tor
5005	Glutfunken-Anhänger
5006	Khazgorms Tagebuch
5007	Band der Dornen
5008	Quecksilberring
5009	Geistbeugerspirale
5010	Gravierter Goldring
5011	Welkenring
5012	Pilzsporen
5013	Fruchtbare Knolle
5014	Wrapping Paper (PT)
5015	Wrapped Item (PT)
5016	Fachmann-Beinkleider
5017	Nitroglyzerin
5018	Holzbrei
5019	Natriumnitrat
5020	Beuteschlüssel der Kolkar
5021	Dynamitstange von Gann
5022	Kodobanns Kopf
5023	Verogs Kopf
5024	Frostphiole
5025	Hezruls Kopf
5026	Feuerteer
5027	Eingesammelte Sporen
5028	Lord Sakrasis' Szepter
5029	Talisman des Nagalords
5030	Zentaurenarmschienen
5038	Träne der Monde
5040	Schattenjägermesser
5042	Geschenkpapier mit rotem Band
5043	Geschenk mit rotem Band
5044	Geschenk mit blauem Band
5045	Schädelgeschenk
5046	Verschlossenes Geschenk
5047	Schädelgeschenkpapier
5048	Geschenkpapier mit blauem Band
5049	Selbstverschließendes Eisenpapier
5050	Zündschlüssel
5051	Grubenratte
5052	Bewusstlose Grubenratte
5054	Samophlang
5055	Intaktes Raptorhorn
5056	Wurzelprobe
5057	Reife Wassermelone
5058	Silithidenei
5059	Gräberklaue
5060	Diebeswerkzeug
5061	Gestohlenes Silber
5062	Raptorkopf
5063	Kreenig Grantelschnauzes Hauer
5064	Kralle der Hexenschwingen
5065	Harpyienoffiziersring
5066	Felsspaltenpflanze
5067	Serenas Kopf
5068	Getrocknete Samenkörner
5069	Feuerzauberstab
5071	Schattenzauberstab
5072	Loks Schädel
5073	Naks Schädel
5074	Kuz' Schädel
5075	Blutsplitter
5076	Stiefellieferung
5077	Teleskoplinse
5078	Medaille von Theramore
5079	Kaltes Basiliskenauge
5080	Gazlowes Geschäftsbuch
5081	Kodobalgtasche
5082	Dünnes Kodoleder
5083	Muster: Kodobalgtasche
5084	Baron Küstenschippers Kopf
5085	Stacheleberhauer der Borstennacken
5086	Zhevra-Hufe
5087	Ebenenschreiter-Schnabel
5088	Steuerkonsolen-Bedienungsanleitung
5089	Konsolenschlüssel
5092	Verkohlter Grimmhauerzauberstab
5093	Grimmhauerrückenstecher
5094	Grimmhauerkriegsschild
5095	Regenbogenflossenthunfisch
5096	Streunerklauen
5097	Katzenaugensmaragd
5098	Veränderte Schnappkieferschale
5099	Huf von Lakota'mani
5100	Echeyakees Balg
5101	Ishamuhales Fangzahn
5102	Owatankas Schwanzstachel
5103	Washte Pawnes Feder
5104	Herz von Isha Awak
5105	Explosive Schale
5107	Deckmatrosenhemd
5108	Dunkeleisenleder
5109	Splittersteinlumpen
5110	Hexerrobe von Dalaran
5111	Rathorians Cape
5112	Ritualklinge
5113	Mal des Syndikats
5114	Abgespaltene Kralle
5115	Zerbrochenes Gabelbein
5116	Lange Schwanzfeder
5117	Farbenprächtiger Federbusch
5118	Großer flacher Zahn
5119	Feines loses Haar
5120	Langes Schweifhaar
5121	Schmutzige Kodoschuppe
5122	Dickes Kodohaar
5123	Stählerne Pfeilspitze
5124	Kleiner Raptorzahn
5125	Aufgeladene Schuppe
5126	Wissen: Defiasverkleidung
5127	Wissen: Südmeerpiratenverkleidung
5128	Abgeworfene Echsenhaut
5129	Wissen: Dunkeleisenzwerg-Verkleidung
5130	Wissen: Verkleidung als Hexer von Dalaran
5131	Wissen: Splittersteintroggverkleidung
5132	Wissen: Syndikatsverkleidung
5133	Undichter Muskelmagen
5134	Kleine pelzige Tatze
5135	Dünne schwarze Klaue
5136	Zerrissenes pelziges Ohr
5137	Heller Augapfel
5138	Ernterkopf
5139	Buch der Dornen
5140	Blitzstrahlpulver
5141	Buch des Nachwachsens
5142	Buch des Zorns II
5143	Donnerechsenblut
5145	Buch der heilenden Berührung II
5147	Buch der Wucherwurzeln II
5148	Buch der Dornen II
5149	Buch des Zorns III
5150	Buch der heilenden Berührung III
5151	Buch des Zorns IV
5152	Buch der heilenden Berührung IV
5153	Buch des Mals der Wildnis IV
5154	Buch der Dornen III
5155	Buch des Mals der Wildnis II
5156	Buch des Zorns V
5158	Buch der Gelassenheit
5160	Buch der heilenden Berührung V
5163	Buch des Mals der Wildnis III
5164	Donnerfalkenflügel
5165	Bluthornfeder
5166	Waldwebergiftbeutel
5167	Waldweberei
5168	Bäumlingssamenkorn
5169	Bäumlingsspross
5170	Moosartiger Tumor
5172	Todeskapsel
5173	Todeskraut
5174	Notiz von Neeru
5175	Erdtotem
5176	Feuertotem
5177	Wassertotem
5178	Lufttotem
5179	Moosumschlungenes Herz
5180	Halskette der Harmonie
5181	Vibrierendes Seidencape
5182	Zitterklinge
5183	Pulsierendes Hydra-Herz
5184	Gefüllte Kristallphiole
5185	Kristallphiole
5186	Teilweise gefülltes Gefäß
5187	Rhahk'Zors Hammer
5188	Gefülltes Gefäß
5189	Leuchtende Frucht
5190	Schimmernder Wedel
5191	Grausamer Widerhaken
5192	Diebesklinge
5193	Cape der Bruderschaft
5194	Zuchtmeisteraxt
5195	Goldgesprenkelte Handschuhe
5196	Smites Häscher
5197	Cookies Fleischklopfer
5198	Cookies Rührerrute
5199	Verhüttungs-Hose
5200	Durchdringharpune
5201	Glutsteinstab
5202	Korsarenüberhemd
5203	Flachlandstreunerklauen
5204	Blutfedergürtel
5205	Sprießender Wedel
5206	Boglingwurzel
5207	Undurchsichtiger Zauberstab
5208	Glimmender Zauberstab
5209	Düsterniszauberstab
5210	Brennender Zauberstab
5211	Dämmerungszauberstab
5212	Loderflammenzauberstab
5213	Zauberstab des Versengens
5214	Zauberstab der Abendzeit
5215	Glutzauberstab
5216	Umbralzauberstab
5217	Besudeltes Herz
5218	Gesäubertes Bäumlingsherz
5219	Gravierte Rinde
5220	Knarzklauenfangzahn
5221	Melenas Kopf
5223	Leerer Manaedelstein
5227	Leeres Manajuwel
5229	Leerer großer Blutstein
5232	Schwacher Seelenstein
5233	Stein von Relu
5234	Flagonguts Fossil
5235	Alchimistenzauberstab
5236	Brennbarer Zauberstab
5237	Gedankenbenebelndes Gift
5238	Pechholzzauberstab
5239	Schwarzknochenzauberstab
5240	Zauberstab des Fackelscheins
5241	Zwergischer Flammenstecken
5242	Glutstecken
5243	Feuerrülpser
5244	Geweihter Zauberstab
5245	Zauberstab des Beschwörers
5246	Ausgrabungsrute
5247	Rute des Kummers
5248	Blitzzauberstab
5249	Brennender Span
5250	Verkohlter Zauberstab
5251	Wahrsagephiole
5252	Zauberstab des Verfalls
5253	Goblin-Anzünder
5254	Unverwüstliche Schiftung
5255	Stachelebertomahawk
5256	Kovorks Rassel
5257	Dunkles Kapuzencape
5263	Fussel
5264	Freibiermarke
5265	Verwässertes Bier
5266	Auge von Adaegus
5267	Scharlachroter Kris
5268	Gesprungene Silithidenschale
5269	Silithidensekret
5270	Todeskappe
5271	Schorfstängling
5272	Irrsinniges Gekritzel
5273	Mathystra-Relikt
5274	Rosen-Mantel
5275	Bindegurt
5279	Harpyienkürschner
5299	Handschuhe des Mondes
5302	Kobaltblauer Rundschild
5306	Windreiterstab
5309	Freibeutermuskete
5310	Seebären-Kniehosen
5311	Schnallenstiefel
5312	Nietenstulpen
5313	Totemikerklanring
5314	Eberjägercape
5315	Waldhainarmschützer
5316	Rindenhüllentunika
5317	Trockenmoostunika
5318	Zhovur-Axt
5319	Hieb-Schulterstücke
5320	Gefütterte Lamellenstiefel
5321	Elegantes Kurzschwert
5322	Demolierhammer
5323	Immerscheinlaterne
5324	Ingenieurhammer
5325	Schweißerschild
5326	Leuchtfeuerbaton
5327	Schmierige Tüftlerhose
5328	Sattelgurt-Gürtel
5329	Katzenstatuette
5330	Elfen-Kelchrelikt
5332	Leuchtende Katzenstatuette
5335	Ein Sack Münzen
5336	Grell-Ohrring
5337	Wanderer-Handschuhe
5338	Altes Mondstein-Siegel
5339	Schlangenflaum
5340	Kesselrührer
5341	Sporenbedeckte Tunika
5342	Raptorpunsch
5343	Barkeeper-Umhang
5344	Spitze Axt
5345	Steinholzhammer
5346	Orc-Kampfbogen
5347	Zauberstab der Pestilenz
5348	Abgenutztes Pergament
5349	Herbeigezauberter Muffin
5350	Herbeigezaubertes Wasser
5351	Kopfgeldjägerring
5352	Buch: Die Macht in der Tiefe
5353	Nachricht für Elissa Starbreeze
5354	Brief an Delgren
5355	Bestienmeistergurt
5356	Brandzeichenrute
5357	Schutzschild des Tales
5359	Lorgalis-Manuskript
5360	Hochgeborenenrelikt
5361	Grätenzahnstocher
5362	Kauspielzeug
5363	Gefaltetes Taschentuch
5364	Trockener Salzleckstein
5366	Leuchtender Seelenedelstein
5367	Primitives Steinwerkzeug
5368	Leere Börse
5369	Abgenagter Knochen
5370	Gebogener Löffel
5371	Korallenstück
5373	Glücksbringer
5374	Kleine Taschenuhr
5375	Rückenkratzer
5376	Zerbrochener Spiegel
5377	Kammmuschelschale
5379	Stiefelmesser
5380	Versiegelter Brief an Elissa
5381	Versiegelter Brief an Balthule
5382	Anayas Anhänger
5383	Athrikus Narassins Kopf
5385	Kriecherbein
5386	Feiner Mondpirscherpelz
5387	Verzauberter Mondpirscher-Umhang
5388	Ran Blutreißers Schädel
5389	Verderbtes Totem der Furbolgs
5390	Fandrals Nachricht
5391	Rare Erde
5392	Distelholzdolch
5393	Distelholzstab
5394	Ausbildungshandschuhe zum Bogenschießen
5395	Waldlandschild
5396	Schlüssel zur sengenden Schlucht
5397	Schießpulver der Defias
5398	Baldachin-Gamaschen
5399	Fährtenleserstiefel
5400	Blut von Kobrahn
5401	Blut von Pythas
5402	Blut von Anacondra
5403	Blut von Serpentis
5404	Schlangen-Schultern
5405	Drapierter Umhang
5406	Leerer schwacher Blutstein
5411	Säuberungstotem von Winterhoof
5412	Drescherauge
5413	Mondpirscher-Fangzahn
5414	Ergrauter Skalp
5415	Säuberungstotem von Thunderhorn
5416	Säuberungstotem von Wildmane
5419	Wild-Armschienen
5420	Bansheerüstung
5421	Feuerverzauberung
5422	Dornenkrautgamaschen
5423	Boahns Giftzahn
5424	Antike Statuette
5425	Runenschuppengurt
5426	Schlangenkuss
5427	Kunstlose Taschenuhr
5428	Ein exotisches Kochbuch
5429	Ein hübscher Stein
5430	Kompliziertes Schmuckstück
5431	Leerer Flachmann
5432	Hickory-Pfeife
5433	Lumpenpuppe
5435	Glänzender Dingelhopper
5437	Bathranshaar
5439	Kleiner Köcher
5440	Krankheitsflasche
5441	Kleiner Geschossbeutel
5442	Arugals Kopf
5443	Vergoldeter Rundschild
5444	Minenarbeitercape
5445	Ring von Zoram
5446	Zerbrochene Elementararmschiene
5447	Beschädigte Elementararmschiene
5448	Gerissene Elementararmschiene
5451	Zerschmetterte Elementararmschiene
5455	Gefundene Rolle
5456	Rolle der Bestimmung
5457	Abgespaltene Voodooklaue
5458	Schmutzholz-Gürtel
5459	Verteidigeraxt
5460	Orendils Heilung
5461	Zweig des Cenarius
5462	Dartols Rute der Transformation
5463	Leuchtender Edelstein
5464	Eisenschaft
5465	Kleines Spinnenbein
5466	Skorpidstachel
5467	Kodofleisch
5468	Weiches Frenzyfleisch
5469	Schreiterfleisch
5470	Donnerechsenschwanz
5471	Hirschfleisch
5472	Kaldorei-Spinnenkebab
5473	Skorpid Surprise
5474	Geröstetes Kodofleisch
5475	Holzschlüssel
5476	Frenzyfilet
5477	Schreitereintopf
5478	Grubenratteneintopf
5479	Knuspriger Donnerechsenschwanz
5480	Mageres Wildbret
5481	Satyrhörner
5482	Rezept: Kaldorei-Spinnenkebab
5483	Rezept: Skorpid Surprise
5484	Rezept: Geröstetes Kodofleisch
5485	Rezept: Frenzyfilet
5486	Rezept: Schreitereintopf
5487	Rezept: Grubenratteneintopf
5488	Rezept: Knuspriger Donnerechsenschwanz
5489	Rezept: Mageres Wildbret
5490	Kopf einer Rächerflosse
5493	Elunes Träne
5494	Hand voll Sternenstaub
5498	Kleine irisierende Perle
5500	Schillernde Perle
5503	Muschelfleisch
5504	Würziges Muschelfleisch
5505	Teronis' Tagebuch
5506	Knopfaugenstängel
5507	Verschnörkeltes Handfernrohr
5508	Gefallener Mondstein
5509	Gesundheitsstein
5510	Großer Gesundheitsstein
5511	Geringer Gesundheitsstein
5512	Schwacher Gesundheitsstein
5513	Manajadestein
5514	Manaachat
5516	Dreschadonfangzahn
5517	Winziger Bronzeschlüssel
5518	Winziger Eisenschlüssel
5519	Eisenschwertknauf
5520	Velindes Tagebuch
5521	Velindes Schlüssel
5522	Zauberstein
5523	Kleine rankenfüßige Muschel
5524	Dickschalige Muschel
5525	Gekochte Muscheln
5526	Muschelsuppe
5527	Scharfe Muscheln nach Goblin-Art
5528	Rezept: Muschelsuppe
5529	Grabmalstaub
5530	Blendungspulver
5533	Ilkrud Magthrulls Foliant
5534	Parkers Mittagessen
5535	Kompendium der Gefallenen
5536	Mythologie der Titanen
5537	Sarilus Foulbornes Kopf
5538	Vorrels Ehering
5539	Vorstellungsschreiben
5540	Perlengriffdolch
5541	Schillernder Hammer
5542	Perlenschnallenumhang
5543	Pläne: Schillernder Hammer
5544	Dal Blutklaues Schädel
5547	Rekonstruierte Rute
5565	Höllenstein
5566	Zerbrochenes Geweih
5567	Silberhaken
5568	Glatter Kiesel
5569	Seetang
5570	Kluftmoosei
5571	Kleiner schwarzer Beutel
5572	Kleiner grüner Beutel
5573	Grüne Ledertasche
5574	Weiße Ledertasche
5575	Großer grüner Sack
5576	Großer brauner Sack
5577	Pläne: Raue bronzene Armschienen
5578	Pläne: Bronzene Brustplatte mit Versilberung
5579	Miliz-Kriegshammer
5580	Milizhammer
5581	Glatter Wanderstab
5582	Steinkrallen-Saft
5583	Siechdrachenschuppe
5584	Schnurrhaar eines Mondlichtläufers
5585	Rennerauge
5586	Distelholzklinge
5587	Dornwurzkeule
5588	Lydons Toxin
5589	Moosbedeckte Stulpen
5590	Kordel-Armschienen
5591	Regenfleckiges Cape
5592	Fessel-Gurt
5593	Klippen-Rundschild
5594	Brief an Jin'Zil
5595	Dickichthammer
5596	Eschenholzbogen
5601	Ausgebrüteter Eierbeutel
5602	Klebriges Spinnennetz
5603	Wizbangs Rupfensack
5604	Elfenzauberstab
5605	Stutzmesser
5606	Garten-Handschuhe
5608	Lebendige Kutte
5609	Unerschütterlicher Sattelgurt
5610	Klippenwindumhang
5611	Träne des Kummers
5612	Efeu-Manschetten
5613	Stab des Läuterers
5614	Seraphs Schlag
5615	Waldmannschwert
5616	Bauchbrecher
5617	Vagabunden-Gamaschen
5618	Späherumhang
5619	Jadephiole
5620	Phiole mit unschuldigem Blut
5621	Turmalinphiole
5622	Klerikerring
5623	Amethystphiole
5624	Reif des Ordens
5626	Schädelsplitter
5627	Reliktklinge
5628	Zamahs Notiz
5629	Hammerfaust-Handschuhe
5630	Windfilzhandschuhe
5631	Wuttrank
5632	Trank der feigen Flucht
5633	Großer Wuttrank
5634	Trank der freien Aktion
5635	Scharfe Klaue
5636	Zierliche Feder
5637	Großer Fangzahn
5638	Toxinvernebler
5639	Gefüllte Jadephiole
5640	Rezept: Wuttrank
5641	Rezept: Trank der feigen Flucht
5642	Rezept: Trank der freien Aktion
5643	Rezept: Großer Wuttrank
5644	Foliant des Wasser-Herbeizauberns
5645	Gefüllte Turmalinphiole
5646	Phiole mit gesegnetem Wasser
5647	Foliant des Blinzelns
5648	Foliant der Frostrüstung III
5649	Foliant des Blizzards
5650	Foliant des Wasser-Herbeizauberns III
5654	Sofort wirkendes Toxin
5655	Kastanienbraune Stute
5656	Braunes Pferd
5657	Rezept: Sofort wirkendes Toxin
5658	Buchband: Siegel der Macht
5659	Glimmende Holzscheite
5660	Buchband: Siegel der Rechtschaffenheit
5661	Buchband: Siegel der Rechtschaffenheit II
5662	Buchband: Siegel der Rechtschaffenheit III
5663	Horn des roten Wolfs
5664	Zerfressenes Schrapnell
5665	Horn des Terrorwolfs
5666	Buchband: Siegel des Zorns II
5667	Buchband: Siegel der Weisheit II
5668	Horn des braunen Wolfs
5669	Staubteufeltrümmer
5670	Buchband: Siegel des Zorns IV
5671	Buchband: Siegel der Macht III
5672	Buchband: Exorzismus
5673	Buchband: Exorzismus II
5674	Buchband: Exorzismus III
5675	Kristallisierte Schuppen
5676	Buchband: Untote Spüren
5677	Buchband: Untote vertreiben
5678	Buchband: Siegel der Aufopferung
5679	Buchband: Siegel der Weisheit III
5680	Buchband: Siegel des Schutzes II
5681	Ätzblutsaft
5682	Buchband: Untote vertreiben II
5683	Buchband: Gottesschild II
5684	Buchband: Siegel der Rettung
5685	Buchband: Erlösung
5686	Ordanus' Kopf
5687	Torhüterschlüssel
5689	Schläfer-Schlüssel
5690	Klauen-Schlüssel
5691	Grabhügel-Schlüssel
5692	Fernzünder (Rot)
5693	Fernzünder (Blau)
5694	NG-5-Sprengstoff (Rot)
5695	NG-5-Sprengstoff (Blau)
5696	Schrifttafel des Schocks
5697	Schrifttafel des Totems der Heilung
5698	Schrifttafel des Blitzschlagschildes
5699	Schrifttafel des Geisterwolfs
5700	Schrifttafel des Totems der Heilung II
5701	Schrifttafel des Wachtotems
5702	Schrifttafel des Aufstachelnden Totems II
5703	Schrifttafel des Donnerknalls
5704	Schrifttafel der Wasseratmung
5705	Schrifttafel des Totems der Heilung III
5706	Schrifttafel des Schlangentotems II
5707	Schrifttafel der Fernsicht
5708	Schrifttafel der Astralgestalt
5709	Schrifttafel des Wasserwandelns
5710	Schrifttafel des Totems der Heilung IV
5711	Schrifttafel des Geisterwolfs II
5712	Schrifttafel des Schlangentotems IV
5713	Schrifttafel des Donnerblitzes
5714	Schrifttafel des Einschnür-Totems II
5715	Schrifttafel des Gewittersturms III
5716	Schrifttafel der Wiederherstellung VI
5717	Briefe der Venture Co.
5718	Konstruktionspläne der Venture Co.
5719	Zauberfoliant des Lebensaugers II
5720	Zauberfoliant des Fluchs von Mannoroth II
5721	Zauberfoliant der Zauberstein-Herstellung
5722	Zauberfoliant des Manawegsaugens II
5723	Zauberfoliant des Fluchs von Sargeras III
5724	Zauberfoliant des Fluchs der Sprachen
5725	Zauberfoliant der Pestilenz III
5726	Zauberfoliant der großen Blutsteinherstellung
5727	Zauberfoliant des Manatrichters
5728	Zauberfoliant des Feuerregens II
5729	Zauberfoliant der Furcht III
5730	Buch der Verjüngung
5731	Rolle der Nachrichtenübermittlung
5732	NG-5
5733	Nicht identifiziertes Erz
5734	Superschnitter-6000-Blaupause
5735	Versiegelter Umschlag
5736	Gerenzos mechanischer Arm
5737	Geheimdienstpläne: Alpha & Beta
5738	Geheimdienstpack
5739	Barbarischer Harnisch
5740	Rote Feuerwerksrakete
5741	Steinbruchstück
5742	Edelsteindolch
5743	Prismensteinring
5744	Bleicher Kürschner
5748	Zentaurenlangbogen
5749	Sensenaxt
5750	Kriegshäuptlingsgurt
5751	Netzschwingenumhang
5752	Flügeldrachen-Schwanzstachel
5753	Gesträubter Kranz
5754	Wolfsrudel-Medaillon
5755	Onyxverzierter Schredderplattenpanzer
5756	Silberklinge
5757	Hartholzknüppel
5758	Mithrilschließkassette
5759	Thoriumschließkassette
5760	Eterniumschließkassette
5761	Anvilmar-Vorschlaghammer
5762	Rote Leinentasche
5763	Rote Wolltasche
5764	Grünes Seidenpack
5765	Schwarzes Seidenpack
5766	Geringe Hexerrobe
5767	Violette Roben
5768	Gnom-Rennticket
5769	Goblin-Rennticket
5770	Roben von Arcana
5771	Muster: Rote Leinentasche
5772	Muster: Rote Wolltasche
5773	Muster: Roben von Arcana
5774	Muster: Grünes Seidenpack
5775	Muster: Schwarzes Seidenpack
5776	Ältestenkrückstock
5777	Kriegerheldenaxt
5778	Primitiver Wanderstecken
5779	Bastardschwert der Verlassenen
5780	Murlocschuppengürtel
5781	Murlocschuppenbrustplatte
5782	Dicke Murlocrüstung
5783	Murlocschuppenarmschienen
5784	Schleimige Murlocschuppe
5785	Dicke Murlocschuppe
5786	Muster: Murlocschuppengürtel
5787	Muster: Murlocschuppenbrustplatte
5788	Muster: Dicke Murlocrüstung
5789	Muster: Murlocschuppenarmschienen
5790	Lonebrows Tagebuch
5791	Henrik Lonebrows Tagebuch
5792	Razorflanks Medaillon
5793	Razorflanks Herz
5794	Salziges Skorpidgift
5795	Gehärteter Schildkrötenpanzer
5796	Verkrustete Schwanzflosse
5797	Induriumspäne
5798	Raketenwagenteile
5799	Kravels Teilebestellung
5800	Kravels Teile
5801	Kral-Guano
5802	Empfindliche Autoteile
5803	Körnchen Traumstaub
5804	Goblin-Gerüchte
5805	Herz des Eifers
5806	Fools Starkbier
5807	Fools Starkbier-Bericht
5808	Prachtschwingengiftbeutel
5809	Steilhanggiftbeutel
5810	Frisches Gerippe
5811	Frostrachens Mähne
5812	Roben der Antike
5813	Emils Marke
5814	Wildbachrüstung
5815	Gletscherstein
5816	Licht von Elune
5817	Lunaris-Bogen
5818	Mondstrahlzauberstab
5819	Sonnenfeuer-Helmkappe
5820	Feen-Mantel
5821	Dunkelpirscher-Stiefel
5822	Heckensamenstulpen
5823	Giftpilz
5824	Schrifttafel des Willens
5825	Treshalas Anhänger
5826	Kravels Plan
5827	Fizzle Brassbolts' Brief
5829	Rasiermesserscharfer Schnabel
5830	Kenatas Kopf
5831	Fardels Kopf
5832	Marcels Kopf
5833	Induriumerz
5834	Mok'Morokks Schnupftabak
5835	Mok'Morokks Grog
5836	Mok'Morokks Geldkassette
5837	Stahlbiss' Rippe
5838	Kodohaut-Rolle
5839	Tagebuchseite
5840	Sengende Zunge
5841	Sengendes Herz
5842	Unbearbeitete Erzprobe
5843	Grenkas Klaue
5844	Fragmente von Rok'Alim
5845	Lendenstück
5846	Korrans versiegelte Notiz
5847	Schlammflossenkopf
5848	Hohler Geierknochen
5849	Kiste mit Sturzhelmen
5850	Belgroms versiegelte Notiz
5851	Cozzles Schlüssel
5852	Treibstoffreglerblaupausen
5853	Intakter Silithidenknochenpanzer
5854	Silithidenkralle
5855	Silithidenherz
5857	Gnomen-Preiskasten
5858	Goblin-Preiskasten
5859	Partygranate
5860	Vermächtnis der Aspekte
5861	Anfänge der Bedrohung durch die Untoten
5862	Zephyriumnachbrenner
5863	Gildensatzung
5864	Grauer Widder
5865	Modifizierter Zephyriumnachbrenner
5866	Induriumerz-Probe
5867	Geätzte Phiole
5868	Gefüllte geätzte Phiole
5869	Gespaltener Huf
5871	Großer Huf
5872	Brauner Widder
5873	Weißer Widder
5874	Harnisch: Schwarzer Widder
5875	Harnisch: Blauer Widder
5876	Blaulaubknolle
5877	Gesprungener Silithidenknochenpanzer
5878	Superschnupftabak
5879	Twilightanhänger
5880	Kiste mit Löchern
5881	Kelris Kopf
5882	Captain-Dokumente
5883	Gespaltene Schlammpanzerzunge
5884	Unzerplatztes Graunebelauge
5897	Schnüffelnasenbesitzeranleitung
5916	Gnomen-Kameraschlüssel
5917	Spionbericht
5918	Kopf des aufsässigen Orcs
5919	Geschwärzter Eisenschild
5936	Tierhaut-Gürtel
5937	Goblin-Kameraschlüssel
5938	Makelloses Kriecherbein
5939	Näh-Handschuhe
5940	Knochenrundschild
5941	Messingschuppenhose
5942	Juwelenbesetzter Anhänger
5943	Riss-Armschienen
5944	Schienbeinschützer der Volksmiliz
5945	Schlammwühlers Zahn
5946	Versiegelte Notiz an Elling
5947	Liste der Defias
5948	Brief an Jorgen
5949	Papierfetzen
5950	Reethes Abzeichen
5951	Feuchtes Handtuch
5952	Verderbter Hirnstamm
5956	Schmiedehammer
5957	Handgenähte Lederweste
5958	Feine Lederhose
5959	Säuregiftbeutel
5960	Versiegelte Notiz an Behüter Backus
5961	Dunkle Lederhose
5962	Wächterhose
5963	Barbarische Gamaschen
5964	Barbarische Schultern
5965	Wächterumhang
5966	Wächterhandschuhe
5967	Gurt des Adels
5968	Unverwüstliche Stiefel
5969	Regentenumhang
5970	Schlangen-Handschuhe
5971	Gefiedertes Cape
5972	Muster: Feine Lederhose
5973	Muster: Barbarische Gamaschen
5974	Muster: Wächterumhang
5975	Grobian-Gürtel
5976	Gildenwappenrock
5996	Elixier der Wasseratmung
5997	Elixier der schwachen Verteidigung
5998	Stormpikes Anforderung
6016	Wolfherzprobe
6037	Echtsilberbarren
6038	Riesenmuschelrisotto
6039	Rezept: Riesenmuschelrisotto
6040	Goldene Schuppenarmschienen
6041	Stahlwaffenkette
6042	Eisenschildstachel
6043	Eisengegengewicht
6044	Pläne: Eisenschildstachel
6045	Pläne: Eisengegengewicht
6046	Pläne: Stahlwaffenkette
6047	Pläne: Goldene Schuppenhelmkappe
6048	Schattenschutztrank
6049	Feuerschutztrank
6050	Frostschutztrank
6051	Heiligschutztrank
6052	Naturschutztrank
6053	Rezept: Heiligschutztrank
6054	Rezept: Schattenschutztrank
6055	Rezept: Feuerschutztrank
6056	Rezept: Frostschutztrank
6057	Rezept: Naturschutztrank
6058	Geschwärzter Ledergürtel
6059	Nomadenweste
6060	Flachs-Armschienen
6061	Graustein-Armschienen
6062	Schwere Kordel-Armschienen
6063	Kaltstahlstulpen
6064	Miniaturplatinscheiben
6065	Khadgars Abhandlungen über dimensionale Konvergenz
6066	Khan Dez'hepahs Kopf
6067	Zentaurenohr
6068	Rezept: Schattenöl
6069	Primitiv getrocknetes Fleisch
6070	Wolfhaut-Armschienen
6071	Draenethystkristall
6072	Khan Jehns Kopf
6073	Khan Shakas Kopf
6074	Kriegshornmundstück
6075	Mumms Bericht
6076	Schmale Hose
6077	Schlüsselfragment der Maraudine
6078	Pikenmannschild
6079	Kunstloser Glücksbringer
6080	Schattenpantherherz
6081	Morastlordfungus
6082	Tiefschreitertumor
6083	Zerbrochene Tränen
6084	Gamaschen der Wache von Stormwind
6085	Fußsoldatentunika
6086	Faustins Wahrheitsserum
6087	Westfall-Galoschen
6089	Zraedus' Bräu
6091	Kiste mit Kraftsteinen
6092	Schwarzwelpenstiefel
6093	Orc-Zermalmer
6094	Durchstechende Axt
6095	Wanderungs-Stiefel
6096	Lehrlingshemd
6097	Akolythenhemd
6098	Neophytenrobe
6116	Lehrlingsrobe
6117	Knappenhemd
6118	Knappenhose
6119	Neophytenrobe
6120	Rekrutenhemd
6121	Rekrutenhose
6122	Rekrutenstiefel
6123	Novizenrobe
6124	Novizenhose
6125	Muskelprotzharnisch
6126	Fallensteller-Hose
6127	Fallensteller-Stiefel
6129	Akolythenrobe
6130	Fallenstellerhemd
6131	Fallenstellerhose
6132	Buchband: Siegel der Weisheit
6133	Buchband: Siegel des Furors
6134	Primitiver Mantel
6135	Primitiver Kilt
6136	Rohlingshemd
6137	Rohlings-Hose
6138	Rohlings-Stiefel
6139	Novizenrobe
6140	Lehrlingsrobe
6144	Neophytenrobe
6145	Clarice' Anhänger
6146	Sonnengetrocknetes Treibholz
6147	Rattiger alter Gürtel
6148	Gespinstbedeckte Stiefel
6149	Großer Manatrank
6150	Ein ausgefranster Knoten
6166	Kojotenkieferknochen
6167	Neekas Bericht
6168	Sägezahnschnapperklaue
6169	Unverarbeitete Sägezahnflanke
6170	Hexer-Reagenzien
6171	Handschuhe des Wolfsjägers
6172	Verlorene Vorräte
6173	Schneestiefel
6174	Twain-Zufallschwert
6175	Artefakt der Atal'ai
6176	Zwergisches Viereckschild
6177	Schmiedeeiserne Armschienen
6178	Lieferung nach Nethergarde
6179	Freibeuter-Cape
6180	Slarks Haut
6181	Fetisch von Hakkar
6182	Trübe Fackel
6183	Nicht angezündete schlechte Fackel
6184	Monströses Kriecherbein
6185	Bärenschal
6186	Trogg-Schnitzler
6187	Zwergischer Verteidiger
6188	Matschstampfer
6189	Haltbare Kettenschultern
6190	Draenethystsplitter
6191	Kimbra-Stiefel
6192	Khan Hrathas Kopf
6193	Artefaktbündel der Atal'ai
6194	Walzenschnitter
6195	Gewachste Rüstung
6196	Noborus Knüppel
6197	Weste aus Lochkrokiliskenhaut
6198	Jurahandgelenksschützer
6199	Band der schwarzen Witwe
6200	Garnegs Kriegsgürtel
6201	Wendige Stiefel
6202	Fingerlose Handschuhe
6203	Rohlingschild
6204	Stammesworghelm
6205	Grabschaufel
6206	Felsenkratzer
6207	SGS - Horde Turmpläne
6208	SGS - Allianz Turmpläne
6209	SGS - Horde Minenbesitzurkunde
6210	SGS - Allianz Minenbesitzurkunde
6211	Rezept: Elixier der Ogerstärke
6212	Jammal'ans Kopf
6214	Schwerer Kupferschlägel
6215	Ausbalancierter Kampfstecken
6216	Mystisches Pulver
6217	Kupferrute
6218	Runenverzierte Kupferrute
6219	Bogenlichtschraubenschlüssel
6220	Meteorsplitter
6222	Formel: Brust magieerfüllen - Schwacher Wille
6223	Wappen von Dunkelhain
6226	Blutige Schürze
6238	Braune Leinenrobe
6239	Rote Leinenweste
6240	Blaue Leinenweste
6241	Weiße Leinenrobe
6242	Blaue Leinenrobe
6243	Grüne Wollrobe
6244	ggggfg
6245	Karnitols Ranzen
6246	Zornsäerklaue
6247	Zornsäerhorn
6248	Skorpashigift
6249	Gealterter Kodobalg
6250	Teufelshundgehirn
6251	Netherflügel
6252	Verdammniswächterblut
6253	Leftwitchs Paket
6256	Angel
6257	Muskelmagen eines Roc
6258	Eisenfellleber
6259	Groddoc-Leber
6260	Blauer Farbstoff
6261	Oranger Farbstoff
6262	Galens Tagebuch
6263	Blauer Overall
6264	Große Adeptenrobe
6265	Seelensplitter
6266	Jüngerweste
6267	Jüngerhose
6268	Pioniertunika
6269	Pionierbeinkleider
6270	Muster: Blaue Leinenweste
6271	Muster: Rote Leinenweste
6272	Muster: Blaue Leinenrobe
6273	Muster: Grüne Wollrobe
6274	Muster: Blauer Overall
6275	Muster: Große Adeptenrobe
6276	Modrige Notiz
6277	Modriges Pergament
6278	Modrige Rolle
6279	Modriger Brief
6280	Modriges Schreiben
6281	Schädel eines klappernden Skeletts
6282	Heilige Begräbnis-Beinkleider
6283	Das Buch von Ur
6284	Runen der Beschwörung
6285	Egalins Zauberfoliant
6286	Reine Herzen
6287	Schrifttafelfragment der Atal'ai
6288	Schrifttafel der Atal'ai
6289	Roher Langzahniger Matschschnapper
6290	Glänzender Kleinfisch
6291	Roher glänzender Kleinfisch
6293	Getrocknetes Fledermausblut
6296	Büschel Fledermaushaar
6297	Alter Schädel
6298	Blutiger Fledermaus-Fangzahn
6299	Krank aussehender Fisch
6300	Hüllenfragment
6301	Old Teamsters Schädel
6302	Zierlicher Insektenflügel
6303	Rohe Glitschhautmakrele
6304	Feuchte Tagebuchseite (Tag 4)
6305	Feuchte Tagebuchseite (Tag 87)
6306	Feuchte Tagebuchseite (Tag 512)
6307	Flaschenpost
6308	Roher Stoppelfühlerwels
6312	Dalins Herz
6313	Comars Herz
6314	Wolfmeister Cape
6315	Stahlpfeilarmbrust
6316	Lochfrenzy Supreme
6317	Roher Lochfrenzy
6318	Odos Leystab
6319	Gurt des Blindsehers
6320	Wappen des Kommandanten
6321	Silverlaines Familiensiegel
6323	Szepter des Barons
6324	Robe von Arugal
6325	Rezept: Glänzender Kleinfisch
6326	Rezept: Glitschhautmakrele
6327	Der Befrieder
6328	Rezept: Langzahniger Matschschnapper
6329	Rezept: Lochfrenzy Supreme
6330	Rezept: Stoppelfühlerwels
6331	Heulende Klinge
6332	Schwarzer Perlenring
6333	Stachelpeitschendolch
6335	Ergraute Stiefel
6336	Infanterietunika
6337	Infanteriegamaschen
6338	Silberrute
6339	Runenverzierte Silberrute
6340	Fenrus' Balg
6341	Unheimliche Stalllaterne
6342	Formel: Brust - Schwaches Mana
6343	Formel: Brust magieerfüllen - Willenskraft
6344	Formel: Armschiene - Schwache Willenskraft
6345	Formel: Umhang magieerfüllen - Schutz
6346	Formel: Brust - Geringes Mana
6347	Formel: Armschiene - Schwache Stärke
6348	Formel: Waffe - Schwacher Wildtiertöter
6349	Formel: Zweihandwaffe - Geringe Intelligenz
6350	Raue bronzene Stiefel
6351	Zerbeulte Kiste
6352	Durchnässte Kiste
6353	Kleine Truhe
6354	Kleine verschlossene Truhe
6355	Stabile verschlossene Truhe
6356	Ramponierte Truhe
6357	Versiegelte Kiste
6358	Öliges Schwarzmaul
6359	Feuerflossenschnapper
6360	Stahlschuppenknautscher
6361	Roher Regenbogenflossenthunfisch
6362	Roher Steinschuppenkabeljau
6365	Starke Angel
6366	Darkwood-Angel
6367	Große Eisenangel
6368	Rezept: Regenbogenflossenthunfisch
6369	Rezept: Steinschuppenkabeljau
6370	Schwarzmaulöl
6371	Feueröl
6372	Schwimmtempotrank
6373	Elixier der Feuermacht
6374	Verzaubertes Pulver
6375	Formel: Armschiene - Geringe Willenskraft
6376	Formel: Stiefel - Schwache Ausdauer
6377	Formel: Stiefel - Schwache Beweglichkeit
6378	Sehercape
6379	Gravierter Ledergürtel
6380	Gravierter Rundschild
6381	Heller Umhang
6382	Waldleder-Gürtel
6383	Wald-Rundschild
6384	Modisches blaues Hemd
6385	Modisches grünes Hemd
6386	Gleißende Panzerbeinschützer
6387	Gleißende Panzerarmschienen
6388	Gleißende Panzerschulterstücke
6389	Gleißende Panzerhelmkappe
6390	Muster: Modisches blaues Hemd
6391	Muster: Modisches grünes Hemd
6392	Gürtel von Arugal
6393	Silberfadenhandschuhe
6394	Silberfadenstiefel
6395	Silberfadenamicia
6396	Geschmückter Brustharnisch
6397	Geschmückte Handschuhe
6398	Geschmückter Gürtel
6399	Geschmückte Schultern
6400	Gleißender Schild
6401	Muster: Dunkles Seidenhemd
6402	Gepanzerte Gefechtsgamaschen
6403	Gepanzerte Gefechtsarmschützer
6404	Gepanzerte Gefechtsschiftung
6405	Nachthauchbeinkleider
6406	Nachthauchstiefel
6407	Nachthauchgelenkbänder
6408	Insignien-Handschuhe
6409	Insignien-Gürtel
6410	Insignien-Armschienen
6411	Oberbrigadierrüstung
6412	Oberbrigadierstiefel
6413	Oberbrigadierarmschienen
6414	Siegel von Sylvanas
6415	Aurorarobe
6416	Aurorastiefel
6417	Auroraumhang
6418	Auroraschärpe
6419	Glyphenverzierte Fäustlinge
6420	Glyphenverzierte Stiefel
6421	Glyphenverzierter Gürtel
6422	Glyphenverzierter Helm
6423	Schwarzschmiedeschienbeinschützer
6424	Schwarzschmiedecape
6425	Schwarzschmiedegurt
6426	Schwarzschmiedearmschienen
6427	Blaunebelrobe
6428	Blaunebelhandschuhe
6429	Blaunebelhexerhut
6430	Imperiale Lederbrustplatte
6431	Imperiale Lederstiefel
6432	Imperialer Umhang
6433	Imperialer Lederhelm
6435	Erfüllter brennender Edelstein
6436	Brennender Edelstein
6438	Glanzlose Elementararmschiene
6439	Zerbrochene Bindungsarmschiene
6440	Hirnpeitsche
6441	Schattenpirscherskalp
6442	Orakelkristall
6443	Deviatbalg
6444	Gespaltene Zunge
6445	Abgestreifte Schlangenhaut
6446	Natternhauttasche
6447	Abgenutzter Schildkrötenpanzer-Schild
6448	Schwanzstachel
6449	Leuchtender Echsenschuppenumhang
6450	Seidenverband
6451	Schwerer Seidenverband
6452	Gegengift
6453	Starkes Gegengift
6454	Handbuch: Starkes Gegengift
6455	Altes Wagenrad
6456	Säurehaltiger Schleim
6457	Verrostete Ingenieurskunstbauteile
6458	Ölbedeckter Fisch
6459	Wilde Treter
6460	Kobrahns Griff
6461	Schleimüberzogene Polster
6462	Gesicherte Kiste
6463	Deepfathom-Ring
6464	Klageessenz
6465	Robe der Mokassin
6466	Deviatschuppenumhang
6467	Deviatschuppenhandschuhe
6468	Deviatschuppengürtel
6469	Giftschlag
6470	Deviatschuppe
6471	Perfekte Deviatschuppe
6472	Stechviper
6473	Rüstung des Giftzahns
6474	Muster: Deviatschuppenumhang
6475	Muster: Deviatschuppenhandschuhe
6476	Muster: Deviatschuppengürtel
6477	Graslandschärpe
6478	Rattenstampfer
6479	Malem-Anhänger
6480	Clevere Deviatgamaschen
6481	Moorlandstulpen
6482	Feuerwandler-Stiefel
6486	Angesengte Schuppe
6487	Kopf eines schändlichen Familiars
6488	Einfache Schrifttafel
6489	Wettergegerbtes Pergament
6490	Dunkles Pergament
6491	Schweres Pergament
6492	Rußiges Pergament
6493	Zerlumptes Pergament
6494	Bekritzeltes Pergament
6495	Verwittertes Pergament
6496	Detailliertes Pergament
6497	Einfaches Pergament
6498	Graviertes Kodoleder
6499	Graviertes Kodoleder
6500	Graviertes Kodoleder
6501	Graviertes Kodoleder
6502	Violette Schuppenrüstung
6503	Harlekin-Roben
6504	Flügelklinge
6505	Mondsichelstab
6506	Infanteriestiefel
6507	Infanteriearmschienen
6508	Infanterieumhang
6509	Infanteriegürtel
6510	Infanteriestulpen
6511	Gesellenrobe
6512	Jüngerrobe
6513	Jüngerschärpe
6514	Jüngerumhang
6515	Jüngerhandschuhe
6516	Wichtelbeschwörungsrolle
6517	Pioniergürtel
6518	Pionierstiefel
6519	Pionierarmschienen
6520	Pionierumhang
6521	Pionierhandschuhe
6522	Deviatfisch
6523	Schnallenharnisch
6524	Beschlagener Lederharnisch
6525	Grunzerharnisch
6526	Kampfharnisch
6527	Vorfahren-Robe
6528	Zauberbinder-Robe
6529	Glänzendes Schmuckstück
6530	Nachtkriecher
6531	Barbarische Stoffrobe
6532	Helle Schmuckstücke
6533	Aquadynamischer Fischanlocker
6534	Schmiedestahlbarren
6535	Schrifttafel der Verga
6536	Weidenweste
6537	Weidenstiefel
6538	Weidenrobe
6539	Weidengürtel
6540	Weidenhose
6541	Weidenhandschuhe
6542	Weidencape
6543	Weidenarmschienen
6544	Leerwandler-Beschwörungs-Rolle
6545	Soldatenrüstung
6546	Soldatengamaschen
6547	Soldatenstulpen
6548	Soldatengurt
6549	Soldatenumhang
6550	Soldatenhandgelenksschutz
6551	Soldatenstiefel
6552	Bardentunika
6553	Bardenhose
6554	Bardenhandschuhe
6555	Bardenumhang
6556	Bardenarmschienen
6557	Bardenstiefel
6558	Bardengürtel
6559	Bardenrundschild
6560	Soldatenschild
6561	Gefütterte Seherrüstung
6562	Schimmernde Stiefel
6563	Schimmernde Armschienen
6564	Schimmernder Umhang
6565	Schimmernde Handschuhe
6566	Schimmernde Amicia
6567	Schimmernde Rüstung
6568	Schimmernde Beinkleider
6569	Schimmernde Robe
6570	Schimmernde Schärpe
6571	Späherrundschild
6572	Verteidigerschild
6573	Verteidigerstiefel
6574	Verteidigerarmschienen
6575	Verteidigerumhang
6576	Verteidigergurt
6577	Verteidigerstulpen
6578	Verteidigergamaschen
6579	Verteidigerschiftung
6580	Verteidigertunika
6581	Spähergürtel
6582	Späherstiefel
6583	Späherarmschienen
6584	Spähertunika
6585	Späherumhang
6586	Späherhandschuhe
6587	Späherhose
6588	Späherschiftung
6589	Viridium-Band
6590	Schlachtschmiedestiefel
6591	Schlachtschmiedehandgelenksschutz
6592	Schlachtschmiederüstung
6593	Schlachtschmiedeumhang
6594	Schlachtschmiedegurt
6595	Schlachtschmiedestulpen
6596	Schlachtschmiedebeinschützer
6597	Schlachtschmiedeschulterschutz
6598	Derwischrundschild
6599	Schlachtschmiedeschild
6600	Derwischgürtel
6601	Derwischstiefel
6602	Derwischarmschienen
6603	Derwischtunika
6604	Derwischcape
6605	Derwischhandschuhe
6607	Derwischgamaschen
6608	Helle Rüstung
6609	Weisenstoff
6610	Weisenrobe
6611	Weisenschärpe
6612	Weisenstiefel
6613	Weisenarmschienen
6614	Weisenumhang
6615	Weisenhandschuhe
6616	Weisenhose
6617	Weisenmantel
6619	Handbuch: Der Weg der Verteidigung
6620	Ausführliches Pergament
6621	Handbuch des Spotts
6622	Schwert des Eifers
6623	Sukkubusbeschwörungsrolle
6624	Ken'ziglas Trunk
6625	Schmutzverkrusteter Anhänger
6626	Dograns Anhänger
6627	Mutantenschuppenbrustplatte
6628	Rabenklauen
6629	Sporen-Cape
6630	Samenwolken-Rundschild
6631	Lebendige Wurzel
6632	Siechschuppenumhang
6633	Schlächterschnitzler
6634	Ritualsalbe
6635	Erdsapta
6636	Feuersapta
6637	Wassersapta
6638	Luftsapta
6640	Teufelspirscherhuf
6641	Spukklinge
6642	Phantom-Rüstung
6643	Aufgedunsener Kleinfisch
6644	Aufgedunsene Makrele
6645	Aufgedunsener Matschschnapper
6646	Aufgedunsener Thunfisch
6647	Aufgedunsener Wels
6648	Steinhaut-Totem-Rolle
6649	Rolle des Totems der Verbrennung
6650	Totem des heilenden Flusses Rolle
6651	Zerbrochene Weinflasche
6652	Reagenzienbeutel
6653	Fackel der schlafenden Flamme
6654	Fackel der ewigen Flamme
6655	Leuchtendes Holzscheit
6656	Rohquarz
6657	Pikantes Deviat-Supreme
6658	Beispielhalsband
6659	Skarabäusbeinkleider
6660	Julies Dolch
6661	Rezept: Pikantes Deviat-Supreme
6662	Elixier des Riesenwuchses
6663	Rezept: Elixier des Riesenwuchses
6664	Voodoomantel
6665	Verhexte Armschienen
6666	Bagger-Stiefel
6667	Ingenieurs-Umhang
6668	Zeichner-Stiefel
6669	Heiliges Band
6670	Panther-Rüstung
6671	Kampfschiff-Gamaschen
6672	Bauplan: Blitzstrahlbombe
6675	Ausgehärtete Armschienen
6676	Konstabler-Rundschild
6677	Zauberstab des Zauberkundigen
6678	Band der elfischen Anmut
6679	Rüstungsstecher
6681	Dornenstachel
6682	Todessprecher-Roben
6684	Schnüffelnasenleitstecken
6685	Todessprecher-Mantel
6686	Hauerhelm
6687	Leichenmacher
6688	Whisperwindkopfputz
6689	Windgeiststab
6690	Ferinen-Gamaschen
6691	Keilerhauer
6692	Gezinkter Häscher
6693	Agammagans Umklammerung
6694	Herz von Agammagan
6695	Stygisches Knochenamulett
6696	Nachtpirscherbogen
6697	Fledermausflügel-Mantel
6698	Stein des Durchstechens
6707	Stein von Lapidis
6708	Stein von Goodman
6709	Mondscheinweste
6710	Muster: Mondscheinweste
6711	Stein von Kurtz
6712	Übungsschloss
6713	Zerfetzte Hose
6714	EZ-Thro-Dynamit
6715	Defekte Überbrückungskabel
6716	Bauplan: EZ-Thro-Dynamit
6717	Klemm-Muffen
6718	Elektropeller
6719	Windgetragener Gürtel
6720	Geistjägerkopfputz
6721	Brustplatte von Kor
6722	Bestienhandfesseln
6723	Medaille des Mutes
6724	Stein von Backus
6725	Marmorierter Rundschild
6726	Razzerics maßgefertigter Sicherheitsgurt
6727	Razzerics Rennhandschutz
6728	Stein von Brownell
6729	Fizzles Zippy-Anzünder
6730	Ironforgekette
6731	Ironforgebrustplatte
6732	Gnomen-Mechanikerhandschuhe
6733	Ironforgestulpen
6734	Pläne: Ironforgekette
6735	Pläne: Ironforgebrustplatte
6736	Pläne: Ironforgestulpen
6737	Trockenlaub-Hose
6738	Blutende Mondsichel
6739	Cliffrunners Ziel
6740	Azurblaue Schärpe
6741	Orc-Kriegsschwert
6742	Steinfaustgurt
6743	Erhaltender Ring
6744	Handschuhe des Kapelan
6745	Flinkläufer-Cape
6746	Basalt-Rundschild
6747	Vollstrecker-Schulterstücke
6748	Affenring
6749	Tigerband
6750	Natternreifen
6751	Trauerschal
6752	Lanzer-Stiefel
6753	Federglücksbringer
6754	Große Geldtasche
6755	Ein kleiner Behälter mit Edelsteinen
6756	Schmuckkästchen
6757	Jainas Siegelring
6766	Flayed Demon Skin (old2)
6767	Tyranis' Anhänger
6773	Marodeurskette der Gelkis
6774	Utheks Finger
6775	Foliant der Offenbarung
6776	Foliant der Ehre
6777	Foliant der Rechtschaffenheit
6778	Foliant der Gerechtigkeit
6779	Foliant des Adels
6780	Fliederfarbene Schärpe
6781	Bartlebys Becher
6782	Marshal Haggards Abzeichen
6783	Stumpfzahns Schlüssel
6784	Geschiente Handschützer
6785	Macht der Leere
6786	Einfaches Kleid
6787	Weißes Wollkleid
6788	Jägergürtel der Magram
6789	Zeremonielle Zentaurendecke
6790	Ring der Beruhigung
6791	Hellion-Stiefel
6792	Blutbadschulterstücke
6793	Aurum-Armschienen
6794	Sturmfeuerstulpen
6795	Weißes Schwadroneurshemd
6796	Rotes Schwadroneurshemd
6797	Augenschüreisen
6798	Schmetter-Schießprügel
6799	Vejreks Kopf
6800	Umbralerz
6801	Barocke Schürze
6802	Schwert des Omens
6803	Prophetenkrückstock
6804	Windsturmhammer
6805	Horn von Vorlus
6806	Tanzende Flamme
6807	Froschschenkeleintopf
6808	Eluniterz
6809	Eluras Medaillon
6810	Surenas Halsschmuck
6811	Aquadynamische Fischlinse
6812	Kiste mit Elunit
6826	Blitzende Schuppe
6827	Kasten mit Vorräten
6828	Visionärs-Rundschild
6829	Schwert der Beschaulichkeit
6830	Knochenbeißer
6831	Schwarze Bedrohung
6832	Verseuchungs-Umhang
6833	Weißes Smokinghemd
6834	Schwarzer Smoking
6835	Schwarze Smokinghose
6836	Ausgehschuhe
6837	Hochzeitskleid
6838	Versengter Spinnenfangzahn
6839	Verkohltes Horn
6840	Galvanisiertes Horn
6841	Phiole mit Phlogiston
6842	Furens Anleitung
6843	Fässlein mit Gerstenbräu
6844	Brennendes Blut
6845	Brennender Fels
6846	Schrift der Defias
6847	Dunkeleisenmanuskript
6848	Sengkoralle
6849	Sonnenverbrannte Schale
6850	Skalp der Bloodscalp
6851	Essenz der Verbannung
6852	Ewiges Auge
6866	Symbol des Lebens
6887	Tüpfelgelbschwanz
6888	Kräutergebackenes Ei
6889	Kleines Ei
6890	Geräuchertes Bärenfleisch
6891	Rezept: Kräutergebackenes Ei
6892	Rezept: Geräuchertes Bärenfleisch
6893	Werkstattschlüssel
6894	Wirbelherz
6895	Jordans Schmiedehammer
6897	Handbuch: Weg des Berserkers
6898	Kugel von Soran'ruk
6899	Hexenmeisterkugel 35
6900	Verzauberte Goldblutrobe
6901	Leuchtendes Dreschercape
6902	Bänder von Serra'kis
6903	Gazeträumer-Hose
6904	Biss von Serra'kis
6905	Riffaxt
6906	Algenfäuste
6907	Schildkrötenrüstung
6908	Ghamoo-ras Bindung
6909	Schlag der Hydra
6910	Egel-Hose
6911	Moos-Sattelgurt
6912	Herzholz
6913	Herzholzkern
6914	Soran'ruk-Fragment
6915	Großes Soran'ruk-Fragment
6916	Foliant der Offenbarung
6926	Furens Notizen
6927	Big Wills Ohr
6928	Blutsteinhalsschmuck
6929	Bath'rahs Pergament
6930	Rute des Kanalisierens
6931	Schimmliger Foliant
6947	Sofort wirkendes Gift
6948	Ruhestein
6949	Sofort wirkendes Gift II
6950	Sofort wirkendes Gift III
6951	Gedankenbenebelndes Gift II
6952	Dickes Bärenfell
6953	Verigans Faust
6966	Elunitaxt
6967	Elunitschwert
6968	Elunithammer
6969	Elunitdolch
6970	Furens Gunst
6971	Feuergehärtete Helmkappe
6972	Feuergehärtete Halsberge
6973	Feuergehärtete Gamaschen
6974	Feuergehärtete Stulpen
6975	Wirbelaxt
6976	Wirbelkriegshammer
6977	Wirbelschwert
6978	Umbralaxt
6979	Haggards Axt
6980	Haggards Dolch
6981	Umbraldolch
6982	Umbralstreitkolben
6983	Haggards Hammer
6984	Umbralschwert
6985	Haggards Schwert
6986	Purpurroter Lotus
6987	Fischschuppe
6988	Teufelsjägerbeschwörungsrolle
6989	Phiole mit Zornsäerblut
6990	Geringer Höllenstein
6991	Glimmende Kohle
6992	Jordans Erzlieferung
6993	Jordans aufbereitete Erzlieferung
6994	Weißsteineichenholz
6995	Verderbter Kor-Edelstein
6996	Jordans Waffennotizen
6997	Zerlumptes Manuskript
6998	Nimbus-Stiefel
6999	Foliant der Kabale
7000	Herzholzgurt
7001	Grabsteinszepter
7002	Arktischer Rundschild
7003	Käferschnallen
7004	Prälaturen-Cape
7005	Kürschnermesser
7006	Rekonstruierter Foliant
7007	Backus' fette Beute
7026	Leinengürtel
7027	Stiefel der Dunkelheit
7046	Azurblaue Seidenhose
7047	Hände der Dunkelheit
7048	Azurblaue Seidenkapuze
7049	Handschuhe des wahren Glaubens
7050	Seidenes Stirnband
7051	Irdene Weste
7052	Azurblauer Seidengürtel
7053	Azurblauer Seidenumhang
7054	Robe der Macht
7055	Purpurroter Seidengürtel
7056	Purpurroter Seidenumhang
7057	Grüne Seidenschultern
7058	Purpurrote Seidenweste
7059	Purpurrote Seidenschultern
7060	Azurblaue Schultern
7061	Irdener Seidengürtel
7062	Purpurrote Seidenpantalons
7063	Purpurrote Seidenrobe
7064	Purpurrote Seidenhandschuhe
7065	Grüne Seidenrüstung
7067	Elementarerde
7068	Elementarfeuer
7069	Elementarluft
7070	Elementarwasser
7071	Eiserne Gürtelschnalle
7072	Nagaschuppe
7073	Zerbrochener Fangzahn
7074	Gesplitterte Klaue
7075	Erdenkern
7076	Essenz der Erde
7077	Herz des Feuers
7078	Essenz des Feuers
7079	Kugel des Wassers
7080	Essenz des Wassers
7081	Odem des Windes
7082	Essenz der Luft
7083	Geläuterter Kor-Edelstein
7084	Muster: Purpurrote Seidenschultern
7085	Muster: Azurblaue Schultern
7086	Muster: Irdener Seidengürtel
7087	Muster: Purpurroter Seidenumhang
7088	Muster: Purpurrote Seidenrobe
7089	Muster: Azurblauer Seidenumhang
7090	Muster: Grüne Seidenrüstung
7091	Muster: Handschuhe des wahren Glaubens
7092	Muster: Hände der Dunkelheit
7093	Muster: Stiefel der Dunkelheit
7094	Treibholzast
7095	Sumpfstiefel
7096	Ausgezupfte Feder
7097	Beinfleisch
7098	Abgesplitterter Hauer
7099	Abgespaltene Zange
7100	Klebriges Sekret
7101	Käferauge
7106	Tierkreishandschuhe
7107	Gürtel der Sterne
7108	Infanterieschild
7109	Pionierrundschild
7110	Silberfadenrüstung
7111	Nachthauchrüstung
7112	Aurorarüstung
7113	Blaunebelrüstung
7114	Muster: Azurblaue Seidenhandschuhe
7115	Erbstückaxt
7116	Erbstückdolch
7117	Erbstückhammer
7118	Erbstückschwert
7119	Zuckender Fühler
7120	Rugas Bollwerk
7126	Rauchiger Eisenblock
7127	Pulverisierter Azurit
7128	Ungespaltener Satyrhuf
7129	Brutale Stulpen
7130	Brutaler Helm
7131	Schienbeinknochen eines Dragonmaw
7132	Brutale Beinschützer
7133	Brutale Halsberge
7134	Stabiler Schienbeinknochen eines Dragonmaw
7135	Zerbrochener Schienbeinknochen eines Dragonmaw
7146	Der scharlachrote Schlüssel
7148	Goblin-Überbrückungskabel
7166	Kupferdolch
7170	Twain Random Sword FOO
7187	Van Cleefs Stiefel
7188	Schild der Wache von Stormwind
7189	Goblin-Raketenstiefel
7190	Versengte Raketenstiefel
7191	Verschmorte Verkabelung
7192	Bauplan: Goblin-Raketenstiefel
7206	Spiegelsee-Wasserprobe
7207	Jenneas Fläschchen
7208	Tazans Schlüssel
7209	Tazans Ranzen
7226	Magitastischer Gizmonitor
7227	Balnirlöwenmäulchen
7228	Skippis Eiscreme
7229	Forscher-Weste
7230	Smites mächtiger Hammer
7231	Astors Vorstellungsschreiben
7247	Truhe mit Verwahrungskästen
7249	Aufgeladener Rissedelstein
7266	Urs Abhandlung über Schattenmagie
7267	Makellose Spinnenseide
7268	Wasserprobe von Xavian
7269	Deinos Fläschchen
7270	Haar der lachenden Schwester
7271	Fehlerloser Elfenbeinhauer
7272	Vom Blitz aufgeladener Dornbusch
7273	Totemstecken der Witherbark
7274	Rituale der Macht
7275	Die Agammagan-Rollen
7276	Handgenähter Lederumhang
7277	Handgenähte Armschienen
7278	Leichter Lederköcher
7279	Kleiner Ledermunitionsbeutel
7280	Unverwüstliche Lederhose
7281	Leichte Lederarmschienen
7282	Leichte Lederhose
7283	Schwarzwelpenumhang
7284	Rotwelpenhandschuhe
7285	Behände Lederhandschuhe
7286	Schwarzwelpenschuppe
7287	Rotwelpenschuppe
7288	Muster: Unverwüstliche Lederhose
7289	Muster: Schwarzwelpenumhang
7290	Muster: Rotwelpenhandschuhe
7291	Höllenkugel
7292	Gefüllte Verwahrungskästen
7293	Manaedelstein aus Dalaran
7294	Androns Geschäftsbuch
7295	Tazans Logbuch
7296	Gelöschte Fackel
7297	Morbents Bann
7298	Klinge der Geschicklichkeit
7306	Fenwicks Kopf
7307	Fleischfressender Wurm
7308	Inkantation der Manifestation
7309	Statusbericht von Dalaran
7326	Thun'grims Axt
7327	Thun'grims Dolch
7328	Thun'grims Streitkolben
7329	Thun'grims Schwert
7330	Spitzelrundschild
7331	Phalanxschild
7332	Königliche Rüstung
7333	Vorarbeiterpfeife
7334	Aufblühende Robe
7335	Grizzly-Tunika
7336	Wildwaldkette
7337	Der Felsen
7338	Stimmungsring
7339	Winzigkleiner Diamantring
7340	Fehlerloser Diamantsolitär
7341	Eckiger Zirkonring
7342	Silbernes Piffenyband
7343	Bingles Schraubenschlüssel
7344	Fackel der heiligen Flamme
7345	Bingles Schraubendreher
7346	Bingles Hammer
7347	Bingles Zahnradumkehrer
7348	Pfeilmacher-Handschuhe
7349	Kräuterkundigenhandschuhe
7350	Jüngerarmschienen
7351	Jüngerstiefel
7352	Irdene Lederschultern
7353	Gefütterte Ältestenrüstung
7354	Ältestenstiefel
7355	Ältestenarmschienen
7356	Ältestenumhang
7357	Ältestenhut
7358	Plündererhandschuhe
7359	Schwere irdene Handschuhe
7360	Muster: Dunkle Lederhandschuhe
7361	Muster: Kräuterkundigenhandschuhe
7362	Muster: Irdene Lederschultern
7363	Muster: Plündererhandschuhe
7364	Muster: Schwere irdene Handschuhe
7365	Gnoam-Sprecklesprocket
7366	Ältestenhandschuhe
7367	Ältestenmantel
7368	Ältestenhose
7369	Ältestenrobe
7370	Ältestenschärpe
7371	Schwerer Köcher
7372	Schwerer Ledermunitionsbeutel
7373	Schwärzliche Ledergamaschen
7374	Schwärzliche Lederrüstung
7375	Grünwelpenrüstung
7376	Bingles Superspreng
7377	Frostlederumhang
7378	Schwärzliche Armschienen
7386	Grünwelpen-Armschienen
7387	Schwärzlicher Gürtel
7388	Schädelschlüssel
7389	Geschäftsbuch der der Venture Co.
7390	Schwärzliche Stiefel
7391	Hurtige Stiefel
7392	Grünwelpenschuppe
7406	Spitzelkordel
7407	Spitzelrüstung
7408	Spitzelschultern
7409	Spitzelstiefel
7410	Spitzelarmschienen
7411	Spitzelumhang
7412	Spitzelhandschuhe
7413	Spitzelkappe
7414	Spitzelhose
7415	Derwischschiftung
7416	Phalanx-Armschienen
7417	Phalanx-Stiefel
7418	Phalanx-Brustplatte
7419	Phalanx-Umhang
7420	Phalanxkopfschutz
7421	Phalanx-Handschuhe
7422	Phalanx-Gurt
7423	Phalanx-Gamaschen
7424	Phalanx-Schiftung
7425	Cyriks Kopf
7426	Himmelblauer Ring
7427	Himmelblauer Talisman
7428	Schattenkatzenbalg
7429	Twilightrüstung
7430	Twilightrobe
7431	Twilighthose
7432	Twilightkutte
7433	Twilighthandschuhe
7434	Twilightstiefel
7435	Twilightmantel
7436	Twilightcape
7437	Twilightmanschetten
7438	Twilightgürtel
7439	Schildwachen-Brustplatte
7440	Schildwachen-Beinkleider
7441	Schildwachenkappe
7442	Gyromasts Schlüssel
7443	Schildwachenhandschuhe
7444	Schildwachenstiefel
7445	Schildwachenschultern
7446	Schildwachenumhang
7447	Schildwachenarmschienen
7448	Schildwachengurt
7449	Muster: Schwärzliche Ledergamaschen
7450	Muster: Grünwelpenrüstung
7451	Muster: Grünwelpen-Armschienen
7452	Muster: Schwärzliche Stiefel
7453	Muster: Hurtige Stiefel
7454	Ritterbrustplatte
7455	Ritterbeinschützer
7456	Ritterkopfschutz
7457	Ritterstulpen
7458	Ritterstiefel
7459	Ritterschulterstücke
7460	Ritterumhang
7461	Ritterarmschienen
7462	Rittergurt
7463	Schildwachenrundschild
7464	Glyphe der Beschwörung
7465	Ritterwappen
7466	Zinnoberband
7467	Zinnoberhalskette
7468	Königliche Robe
7469	Königliche Gamaschen
7470	Königlicher Hexerhut
7471	Königliche Handschuhe
7472	Königliche Stiefel
7473	Königlicher Mantel
7474	Königlicher Umhang
7475	Königliche Manschetten
7476	Königliche Schärpe
7477	Waldläufertunika
7478	Waldläufergamaschen
7479	Waldläuferhelm
7480	Waldläuferhandschuhe
7481	Waldläuferstiefel
7482	Waldläuferschultern
7483	Waldläuferumhang
7484	Waldläuferhandgelenksschutz
7485	Waldläuferkordel
7486	Hauptmanns-Brustplatte
7487	Hauptmanns-Gamaschen
7488	Hauptmanns-Reif
7489	Hauptmanns-Stulpen
7490	Captain-Stiefel
7491	Hauptmannschulterschutz
7492	Hauptmanns-Umhang
7493	Hauptmanns-Armschienen
7494	Kapitäns Taillenschutz
7495	Hauptmanns-Rundschild
7496	Feldplattenschild
7497	Elfenbeinband
7498	Spitze von Gelkaks Schlüssel
7499	Mitte von Gelkaks Schlüssel
7500	Unterteil von Gelkaks Schlüssel
7506	Gnomen-Universalfernbedienung
7507	Arkane Kugel
7508	Leykugel
7509	Managewirkte Robe
7510	Roben des geringen Zauberfeuers
7511	Astralknotenrobe
7512	Netherspitzenrobe
7513	Zauberstab des Wutfeuers
7514	Zauberstab des Eisfurors
7515	Himmlische Kugel
7516	Tabethas Anleitung
7517	Hauchzarte Tunika
7518	Hauchzarte Robe
7519	Hauchzarte Hose
7520	Hauchzartes Kopfstück
7521	Hauchzarte Handschuhe
7522	Hauchzarte Stiefel
7523	Hauchzarte Schulterpolster
7524	Hauchzartes Cape
7525	Hauchzarte Armschienen
7526	Hauchzarter Gürtel
7527	Kabalisten-Brustharnisch
7528	Kabalisten-Gamaschen
7529	Kabalisten-Helm
7530	Kabalisten-Handschuhe
7531	Kabalisten-Stiefel
7532	Kabalisten-Schiftung
7533	Kabalisten-Umhang
7534	Kabalisten-Armschienen
7535	Kabalisten-Gürtel
7536	Championwallschild
7537	Gotischer Schild
7538	Championrüstung
7539	Championgamaschen
7540	Championhelm
7541	Championstulpen
7542	Championschienbeinschützer
7543	Championschulterstücke
7544	Championcape
7545	Championarmschienen
7546	Championgurt
7547	Onyxring
7548	Onyxhalsschmuck
7549	Feenumarmung
7550	Kriegerehre
7551	Verschlungener opaliner Talisman
7552	Falkenhaken
7553	Band des Einhorns
7554	Weidenzweig
7555	Königlicher Stern
7556	Twilightkugel
7557	Hauchzarte Rute
7558	Schimmernder Stock
7559	Runenverzierter Krückstock
7560	Bauplan: Gnomen-Universalfernbedienung
7561	Bauplan: Goblin-Überbrückungskabel
7566	Schwert der Familie Agamand
7567	Axt der Familie Agamand
7568	Dolch der Familie Agamand
7569	Streitkolben der Familie Agamand
7586	Tharnariuns Hoffnung
7587	Thun'grims Anleitung
7606	Polarstulpen
7607	Düsterer Zauberstab
7608	Feiner Seherbierkrug
7609	Ältestenbernsteinstock
7610	Aurorasphäre
7611	Blaunebelstock
7613	Muster: Grüne Lederrüstung
7626	Bündel Felle
7627	Dolanaar-Lieferung
7628	Unscheinbarer Brief
7629	Ukors Bürde
7646	Kiste mit Gasthausvorräten
7666	Zerrissene Halskette
7667	Talvashs Wahrsagephiole
7668	Blutbeflecktes Tagebuch
7669	Zerrissene Halskette-Rubin
7670	Zerrissene Halskette-Saphir
7671	Zerrissene Halskette-Topas
7672	Zerrissene Halskette-Kraftquelle
7673	Talvashs verstärkende Halskette
7674	Lieferung für Mathias
7675	Lieferzeitplan der Defias
7676	Disteltee
7678	Rezept: Disteltee
7679	Würgerfledermaus-Fangzahn
7680	Jaderückenbasiliskenschuppe
7681	Obsidiangolemsplitter
7682	Quälerschüreisen
7683	Blutiger Messingschlagring
7684	Blutmagier-Mantel
7685	Kugel des vergessenen Sehers
7686	Eisenrückenauge
7687	Eisenrückenfaust
7688	Eisenrückenbrustkorb
7689	Morbide Dämmerung
7690	Ebenholzvisor
7691	Einbalsamiertes Tuch
7708	Nekrotischer Zauberstab
7709	Verseuchte Gamaschen
7710	Lokseys Ausbildungsstecken
7711	Robe von Doan
7712	Mantel von Doan
7713	Illusionäre Rute
7714	Hypnoseklinge
7715	Onins Bericht
7716	Zerrissene Halskette
7717	Verheerer
7718	Herods Schulter
7719	Helm des tobenden Berserkers
7720	Whitemanes Zylinder
7721	Hand der Rechtschaffenheit
7722	Triunen-Amulett
7723	Mograines Macht
7724	Stulpen der Offenbarung
7726	Aegis des Scharlachroten Kommandanten
7727	Wachmann-Schulterstücke
7728	Täuscher-Roben
7729	Chesterfall-Muskete
7730	Kobaltzermalmer
7731	Geistsplitter-Talisman
7733	Stab der Prähistorie
7734	Sechsdämonentasche
7735	Jannoks Rose
7736	Gefechtskeule
7737	Sethirs Tagebuch
7738	Immergrünhandschuhe
7739	Waldhaincape
7740	Gni'kiv-Medaillon
7741	Der Schaft von Tsol
7742	Bauplan: Gnomisches Verbergungsgerät
7746	Forscherliga-Empfehlung
7747	Grässlicher Beschützer
7748	Zwingstein-Rundschild
7749	Omegakugel
7750	Mantel des Jammers
7751	Vorrels Stiefel
7752	Traumtöter
7753	Blutvergießer
7754	Herold-Stiefel
7755	Flintstein-Schultern
7756	Handschuhe zur Hundeausbildung
7757	Windwirkerstab
7758	Ruchloses Messer
7759	Archon-Brustharnisch
7760	Kriegshäuptling-Kilt
7761	Stahlklauenhäscher
7766	Leerer brauner Wasserschlauch
7767	Leerer blauer Wasserschlauch
7768	Leerer roter Wasserschlauch
7769	Voller brauner Wasserschlauch
7770	Voller blauer Wasserschlauch
7771	Voller roter Wasserschlauch
7786	Kopfspalter
7787	Prächtiger Wächter
7806	Lutscher
7807	Schokoriegel
7808	Schokoladentafel
7809	Osterkleid
7810	Phiole mit reinstem Wasser
7811	Verbleibende Tropfen reinsten Wassers
7812	Verderbte Manifestations-Armschienen
7813	Wassersplitter
7846	Klippenkojotenfangzahn
7847	Bussardmuskelmagen
7848	Felselementarsplitter
7866	Leeres Thaumaturgiegefäß
7867	Gefäß mit Großdrachenblut
7868	Thieven' Kit
7869	Lucius' Schließkassette
7870	Thaumaturgieschließkassette
7871	Marke der Diebeskunst
7872	Rostige Diebeswerkzeuge
7886	Nicht übersetztes Tagebuch
7887	Halsketten- und Edelsteinbergung
7888	Jarkals intensivierende Halskette
7906	Hörner von Nez'ra
7907	Zertifikat der Diebeskunst
7908	Klaven Mortwakes Tagebuch
7909	Aquamarin
7910	Sternrubin
7911	Echtsilbererz
7912	Robuster Stein
7913	Barbarische Eisenschultern
7914	Barbarische Eisenbrustplatte
7915	Barbarischer Eisenhelm
7916	Barbarische Eisenstiefel
7917	Barbarische Eisenhandschuhe
7918	Schwere Mithrilschulter
7919	Schwere Mithrilstulpen
7920	Mithrilschuppenhose
7921	Schwere Mithrilhose
7922	Stahlplattenhelm
7923	Turmschlüssel der Defias
7924	Mithrilschuppenarmschienen
7925	Mithrilschuppenhandschuhe
7926	Verschnörkelte Mithrilhose
7927	Verschnörkelte Mithrilhandschuhe
7928	Verschnörkelte Mithrilschulter
7929	Orc-Kriegsgamaschen
7930	Schwere Mithrilbrustplatte
7931	Mithrilhelmkappe
7932	Mithrilschuppenschultern
7933	Schwere Mithrilstiefel
7934	Schwerer Mithrilhelm
7935	Verschnörkelte Mithrilbrustplatte
7936	Verschnörkelte Mithrilstiefel
7937	Verschnörkelter Mithrilhelm
7938	Echtsilberstulpen
7939	Echtsilberbrustplatte
7941	Schwere Mithrilaxt
7942	Blaue glitzernde Axt
7943	Tückische Mithrilklinge
7944	Funkelndes Mithrilrapier
7945	Großer schwarzer Streitkolben
7946	Runenverzierter Mithrilhammer
7947	Ebenholzmesser
7948	Gurt von Thero-shan
7949	Gamaschen von Thero-shan
7950	Rüstung von Thero-shan
7951	Hände von Thero-shan
7952	Stiefel von Thero-shan
7953	Maske von Thero-shan
7954	Der Zertrümmerer
7955	Kupferclaymore
7956	Bronzener Kriegshammer
7957	Bronzenes Großschwert
7958	Bronzene Streitaxt
7959	Verseuchung
7960	Echtsilberchampion
7961	Phantomklinge
7963	Stahlbrustplatte
7964	Robuster Wetzstein
7965	Robuster Gewichtsstein
7966	Robuster Schleifstein
7967	Mithrilschildstachel
7968	Schatz der Südmeerfreibeuter
7969	Mithrilsporen
7970	R.C.V.K.
7971	Schwarze Perle
7972	Sekret des Untodes
7973	Großmaulmuschel
7974	Scharfes Muschelfleisch
7975	Pläne: Schwere Mithrilhose
7976	Pläne: Mithrilschildstachel
7977	Pläne: Mithrilschuppenhandschuhe
7978	Pläne: Barbarische Eisenschultern
7979	Pläne: Barbarische Eisenbrustplatte
7980	Pläne: Barbarischer Eisenhelm
7981	Pläne: Barbarische Eisenstiefel
7982	Pläne: Barbarische Eisenhandschuhe
7983	Pläne: Verschnörkelte Mithrilhose
7984	Pläne: Verschnörkelte Mithrilhandschuhe
7985	Pläne: Verschnörkelte Mithrilschulter
7986	Pläne: Verschnörkelte Mithrilbrustplatte
7987	Pläne: Verschnörkelter Mithrilhelm
7988	Pläne: Verschnörkelte Mithrilstiefel
7989	Pläne: Mithrilsporen
7990	Pläne: Schwerer Mithrilhelm
7991	Pläne: Mithrilschuppenschultern
7992	Pläne: Blaue glitzernde Axt
7993	Pläne: Funkelndes Mithrilrapier
7994	Pläne: Orc-Kriegsgamaschen
7995	Pläne: Mithrilschuppenarmschienen
7996	Alter abgewetzter Angelhut
7997	Rote Maske der Defias
8006	Der Ziggler
8007	Manacitrin
8008	Manarubin
8009	Dentrium-Kraftstein
8026	Familienschatz der Garretts
8027	Krom Stoutarms Schatz
8028	Pläne: Runenverzierter Mithrilhammer
8029	Pläne: Tückische Mithrilklinge
8030	Pläne: Ebenholzmesser
8046	Kearnens Tagebuch
8047	Magenta Funguskappe
8048	Smaragdgrüner Traumfänger
8049	Halskette der Knarzklauen
8050	Tallonkais Juwel
8051	Leuchtfeuerwaffe
8052	An'Alleum-Kraftstein
8053	Obsidiankraftquelle
8066	Fizzules Pfeife
8067	Gefertigtes leichtes Geschoss
8068	Gefertigtes schweres Geschoss
8069	Gefertigtes robustes Geschoss
8070	Belohnungsgutschein
8071	Schmorstecken
8072	Silixiz' Turmschlüssel
8073	Behälter mit Zanzils veränderter Mixtur
8074	Gallywixs Kopf
8075	Herbeigezauberter Sauerteig
8076	Herbeigezaubertes Milchbrötchen
8077	Herbeigezaubertes Mineralwasser
8078	Herbeigezaubertes Sprudelwasser
8079	Herbeigezaubertes Kristallwasser
8080	Leichter Plattenbrustharnisch
8081	Leichter Plattengürtel
8082	Leichte Plattenstiefel
8083	Leichte Plattenarmschienen
8084	Leichte Plattenhandschuhe
8085	Leichte Plattenhose
8086	Leichte Plattenschulterpolster
8087	Probe von Zanzils veränderter Mixtur
8088	Plattenpanzergürtel
8089	Plattenpanzerstiefel
8090	Plattenpanzerarmschienen
8091	Plattenpanzerhandschuhe
8092	Plattenpanzerhelm
8093	Plattenpanzergamaschen
8094	Plattenpanzerrüstung
8095	Hinotts Öl
8106	Rüstung des Winterschlafs
8107	Stiefel des Winterschlafs
8108	Armschienen des Winterschlafs
8109	Umhang des Winterschlafs
8110	Handschuhe des Winterschlafs
8111	Mantel des Winterschlafs
8112	Hose des Winterschlafs
8113	Robe des Winterschlafs
8114	Schärpe des Winterschlafs
8115	Kutte des Winterschlafs
8116	Heraldischer Gürtel
8117	Heraldische Stiefel
8118	Heraldische Armschienen
8119	Heraldische Brustplatte
8120	Heraldischer Umhang
8121	Heraldische Handschuhe
8122	Heraldisches Kopfstück
8123	Heraldische Gamaschen
8124	Heroldische Schiftung
8125	Myrmidonenarmschienen
8126	Myrmidonenbrustplatte
8127	Myrmidonencape
8128	Myrmidonenstulpen
8129	Myrmidonengurt
8130	Myrmidonenschienbeinschützer
8131	Myrmidonenhelm
8132	Myrmidonengamaschen
8133	Myrmidonenschulterstücke
8134	Myrmidonenverteidiger
8135	Chromitschild
8136	Riesengroßer Tumor
8137	Chromitarmschienen
8138	Chromitbrustplatte
8139	Chromitstulpen
8140	Chromitgurt
8141	Chromitschienbeinschützer
8142	Chromitbarbute
8143	Chromitbeinplatten
8144	Chromitschulterstücke
8146	Tückische Klaue
8147	Winziger Kupferschlüssel
8148	Winziger Silberschlüssel
8149	Voodooglücksbringer
8150	Tiefsteinsalz
8151	Fläschchen Mojo
8152	Fläschchen großes Mojo
8153	Wildranke
8154	Skorpidschuppe
8155	Sathrahs Opferung
8156	Tjoster-Handgelenksschutz
8157	Tjoster-Brustplatte
8158	Tjoster-Stulpen
8159	Tjoster-Gurt
8160	Tjoster-Schienbeinschützer
8161	Tjoster-Visier
8162	Tjoster-Beinplatten
8163	Tjoster-Schulterstücke
8165	Abgenutzte Drachenschuppe
8167	Schildkrötenschuppe
8168	Pechschwarze Feder
8169	Dicker Balg
8170	Unverwüstliches Leder
8171	Unverwüstlicher Balg
8172	Geschmeidiger dicker Balg
8173	Dickes Rüstungsset
8174	Bequemer Lederhut
8175	Tunika des Nachtschleichers
8176	Stirnband des Nachtschleichers
8177	Übungsschwert
8178	Ausbildungsschwert
8179	Kadettenbogen
8180	Jagdbogen
8181	Jagdgewehr
8182	Schrotgewehr
8183	Präzisionsbogen
8184	Feuerteufel
8185	Schildkrötenschuppengamaschen
8186	Zauberstab des Terrors
8187	Schildkrötenschuppenhandschuhe
8188	Explosive Schrotflinte
8189	Schildkrötenschuppenbrustplatte
8190	Hanzo-Schwert
8191	Schildkrötenschuppenhelm
8192	Schultern des Nachtschleichers
8193	Hose des Nachtschleichers
8194	Goblin-Nussknacker
8195	Umhang des Nachtschleichers
8196	Ebenholzkrummsäbel
8197	Stiefel des Nachtschleichers
8198	Schildkrötenschuppenarmschienen
8199	Schlachtfeld-Zerstörer
8200	Große Voodoorobe
8201	Große Voodoomaske
8202	Große Voodoohose
8203	Feste Skorpidbrustplatte
8204	Feste Skorpidhandschuhe
8205	Feste Skorpidarmschienen
8206	Feste Skorpidgamaschen
8207	Feste Skorpidschulterstücke
8208	Fester Skorpidhelm
8209	Feste Skorpidstiefel
8210	Wildlederschultern
8211	Wildlederweste
8212	Wildledergamaschen
8213	Wildlederstiefel
8214	Wildlederhelm
8215	Wildlederumhang
8216	Großer Voodooumhang
8217	Schnellziehköcher
8218	Dicker Ledermunitionsbeutel
8223	Klinge des Basilisken
8224	Silithidenzerfetzer
8225	Besudelter Durchstecher
8226	Der Schlächter
8243	Scooby-Leckerei
8244	Fehlerlose Draenethystsphäre
8245	Imperiale rote Tunika
8246	Imperiale rote Stiefel
8247	Imperiale rote Armschienen
8248	Imperialer roter Umhang
8249	Imperiale rote Handschuhe
8250	Imperialer roter Mantel
8251	Imperiale rote Hose
8252	Imperiale rote Robe
8253	Imperiale rote Schärpe
8254	Imperialer roter Reif
8255	Schlangenhaut-Gurt
8256	Schlangenhaut-Stiefel
8257	Schlangenhaut-Armschienen
8258	Schlangenhaut-Rüstung
8259	Schlangenhaut-Umhang
8260	Schlangenhaut-Handschuhe
8261	Schlangenhaut-Helm
8262	Schlangenhaut-Gamaschen
8263	Schlangenhaut-Schiftung
8264	Ebenhölzerner Handgelenksschutz
8265	Ebenholzrüstung
8266	Ebenholzumhang
8267	Ebenholzstulpen
8268	Ebenholzgurt
8269	Ebenholzstiefel
8270	Ebenholzhelm
8271	Ebenholzgamaschen
8272	Ebenholzschulterpolster
8273	Wackerer Handgelenksschutz
8274	Wackerer Brustschutz
8275	Ebenholzrundschild
8276	Wackere Stulpen
8277	Wackerer Gurt
8278	Wackere Schienbeinschützer
8279	Wackerer Helm
8280	Wackere Beinschützer
8281	Wackere Schulterstücke
8282	Wackerer Schild
8283	Arkane Rüstung
8284	Arkane Stiefel
8285	Arkane Bänder
8286	Arkaner Umhang
8287	Arkane Handschuhe
8288	Arkane Polster
8289	Arkane Gamaschen
8290	Arkane Robe
8291	Arkane Schärpe
8292	Arkane Bedeckung
8293	Gürtel des Reisenden
8294	Stiefel des Reisenden
8295	Armschienen des Reisenden
8296	Wams des Reisenden
8297	Umhang des Reisenden
8298	Handschuhe des Reisenden
8299	Helm des Reisenden
8300	Gamaschen des Reisenden
8301	Schiftung des Reisenden
8302	Helden-Armschienen
8303	Helden-Brustplatte
8304	Helden-Cape
8305	Helden-Stulpen
8306	Helden-Gürtel
8307	Helden-Stiefel
8308	Helden-Band
8309	Helden-Gamaschen
8310	Helden-Schulterstücke
8311	Alabasterplattenunterarmschienen
8312	Alabasterbrustplatte
8313	Helden-Rundschild
8314	Alabasterplattenstulpen
8315	Alabasterplattengurt
8316	Alabasterplattenschienbeinschützer
8317	Alabasterplattenhelm
8318	Alabasterplattengamaschen
8319	Alabasterplattenschiftung
8320	Alabasterschild
8343	Schwerer Seidenfaden
8344	Silbrige Spinndrüsen
8345	Wolfskopfhelm
8346	Stulpen des Meeres
8347	Drachenschuppenstulpen
8348	Helm des Feuers
8349	Gefiederte Brustplatte
8350	Der Eine Ring
8363	Voodooglücksbringer des Schamanen
8364	Mithrilkopfforelle
8365	Rohe Mithrilkopfforelle
8366	Aufgedunsene Forelle
8367	Drachenschuppenbrustplatte
8368	Dicker Wolfsbalg
8383	Schlichter Brief
8384	Muster: Bequemer Lederhut
8385	Muster: Schildkrötenschuppenhandschuhe
8386	Muster: Große Voodoorobe
8387	Muster: Große Voodoomaske
8388	Muster: Umhang des Nachtschleichers
8389	Muster: Große Voodoohose
8390	Muster: Großer Voodooumhang
8391	Kicherfangunterkiefer
8392	Feuerverbrannte Eberlunge
8393	Skorpokzange
8394	Basiliskengehirn
8395	Muster: Feste Skorpidbrustplatte
8396	Geiermuskelmagen
8397	Muster: Feste Skorpidarmschienen
8398	Muster: Feste Skorpidhandschuhe
8399	Muster: Feste Skorpidstiefel
8400	Muster: Feste Skorpidschulterstücke
8401	Muster: Feste Skorpidgamaschen
8402	Muster: Fester Skorpidhelm
8403	Muster: Wildlederschultern
8404	Muster: Wildlederweste
8405	Muster: Wildlederhelm
8406	Muster: Wildlederstiefel
8407	Muster: Wildledergamaschen
8408	Muster: Wildlederumhang
8409	Muster: Schultern des Nachtschleichers
8410	R.O.I.D.S.
8411	Lungensaft-Cocktail
8412	Gemahlene Skorpokinhaltsstoffprobe
8423	Zerebralkortexverbund
8424	Muskelmagen-Kaugummi
8425	Papageienmist
8426	Große gesträubte Feder
8427	Verstümmeltes Rattengerippe
8428	Gefüllte Taudrüse
8429	Durchstochene Taudrüse
8430	Leere Taudrüse
8431	Spule des Lichts Chartreuse Seidenfaden
8432	Eau de Mixilpixil
8443	Gahz'ridian-Ornament
8444	Henkerschlüssel
8463	Kriegshäuptlingsbefehle
8483	Wasserbeutel eines Wüstenläufers
8484	Gadgetzan Water Co.-Care-Paket
8485	Katzentransportkorb (Bombay)
8486	Katzentransportkorb (Cornish Rex)
8487	Katzentransportkorb (Orangene Tigerkatze)
8488	Katzentransportkorb (Silberne Tigerkatze)
8489	Katzentransportkorb (Weißes Kätzchen)
8490	Katzentransportkorb (Siamkatze)
8491	Katzentransportkorb (Schwarze Tigerkatze)
8492	Papageienkäfig (Grünflügel-Ara)
8493	Weeglis Fass
8494	Papageienkäfig (Hyazinth-Ara)
8495	Papageienkäfig (Senegal)
8496	Papageienkäfig (Nymphensittich)
8497	Hasenkäfig (Schneehase)
8498	Winziger smaragdgrüner Welpling
8499	Winziger purpurroter Welpling
8500	Große Ohreule
8501	Falkeneule
8502	Bronzene Lotteriekiste
8503	Schwere bronzene Lotteriekiste
8504	Eisenlotteriekiste
8505	Schwere Eisenlotteriekiste
8506	Mithrillotteriekiste
8507	Schwere Mithrillotteriekiste
8508	Große Flosse
8523	Feldtestset
8524	Kraftquelle, Modell 4711-FTZ
8525	Zinges Bestellung
8526	Violetter Tragan
8527	Versiegeltes Feldtestset
8528	Violettes Pulver
8529	Noggenfogger-Elixier
8543	Unterwasserpilz-Kappe
8544	Magiestoffverband
8545	Schwerer Magiestoffverband
8546	Mächtiges Riechsalz
8547	Formel: Mächtiges Riechsalz
8548	Wünschel-mato-Rute
8563	Roter Roboschreiter
8564	Hippogryphen-Ei
8583	Horn des Skelettreittiers
8584	Unangezapfter Wünschelrutenapparat
8585	Angezapfter Wünschelrutenapparat
8586	Pfeife des scheckigen roten Raptors
8587	Centipaarinsektenteile
8588	Pfeife des smaragdfarbenen Raptors
8589	Alte Pfeife des elfenbeinfarbenen Raptors
8590	Alte Pfeife des obsidianschwarzen Raptors
8591	Pfeife des türkisfarbenen Raptors
8592	Pfeife des violetten Raptors
8593	Scrimshanks Feldmesser-Ausstattung
8594	Insekten-Analysebericht
8595	Blauer Roboschreiter
8603	Disteltau
8623	OOX-17/TN-Notsignalgeber
8624	Roter Funkler
8625	Weißer Funkler
8626	Blauer Funkler
8627	Zügel des Nachtsäblers
8628	Zügel des gefleckten Nachtsäblers
8629	Zügel des gestreiften Nachtsäblers
8630	Zügel des bengalischen Tigers
8631	Zügel des gestreiften Frostsäblers
8632	Zügel des gefleckten Frostsäblers
8633	Zügel des Leoparden
8643	Außergewöhnliches Ei
8644	Gutes Ei
8645	Gewöhnliches Ei
8646	Schlechtes Ei
8647	Eierkiste
8663	Mithrilinsignien
8683	Claras frischer Apfel
8684	Hinterland-Honigwelle
8685	Drans Welle-Lieferung
8686	Mithrilanhänger
8687	Versiegelte Beschreibung von Thredds Besucher
8703	Signet der Expertise
8704	OOX-09/HL-Notsignalgeber
8705	OOX-22/FE-Notsignalgeber
8707	Gahz'rillas elektrisierte Schuppe
8708	Hammer der Expertise
8723	Kalif Skorpidstichs Kopf
8724	Rin'jis Geheimnis
8743	Buch des Mals der Wildnis
8744	Buch des Zorns
8745	Buch der heilenden Berührung
8746	Geflochtene Kutte
8747	Gehärteter Lederhelm
8748	Doppelpanzerhelmkappe
8749	Häkelhut
8750	Dicker Lederhut
8751	Doppelverbundhelmkappe
8752	Laminierter Schuppenreif
8753	Glatter Lederhelm
8754	Köperbedeckung
8755	Leichter Plattenhelm
8756	Buch des Nachwachsens II
8757	Buch des Sternenfeuers
8758	Buch der Fluchaufhebung
8759	Buch des Nachwachsens III
8760	Buch der Vergiftungsaufhebung
8761	Buch des Sternenfeuers II
8762	Buch der Verjüngung V
8763	Buch des Mondfeuers V
8764	Buch des Feenfeuers II
8765	Buch des Nachwachsens IV
8766	Trichterwindentau
8768	Buch des Sternenfeuers III
8769	Buch der Dornen IV
8770	Buch des Mondfeuers VI
8771	Buch der Verjüngung VI
8772	Buch des Nachwachsens V
8773	Buch der Wucherwurzeln V
8774	Buch der heilenden Berührung VII
8775	Buch der Gelassenheit II
8776	Buch des Mals der Wildnis VI
8777	Buch des Mondfeuers IX
8778	Buch der Verjüngung VII
8779	Buch des Feenfeuers III
8780	Buch des Sternenfeuers V
8781	Buch des Nachwachsens VII
8782	Buch der Dornen V
8783	Buch der heilenden Berührung IX
8784	Buch des Zorns VII
8785	Buch der Verjüngung IX
8786	Buch der Gelassenheit III
8787	Buch der Tierbesänftigung
8788	Buch der Tierbesänftigung II
8789	Buch der Tierbesänftigung III
8790	Buch des Feenfeuers IV
8791	Buch des Nachwachsens VIII
8792	Buch der Dornen VI
8793	Buch des Zorns VIII
8794	Buch der heilenden Berührung X
8795	Buch der Wucherwurzeln VI
8796	Buch des Mondfeuers X
8797	Buch der Verjüngung X
8798	Buch des Sternenfeuers VI
8799	Buch des Mals der Wildnis VII
8800	Buch des Nachwachsens IX
8801	Buch der Gelassenheit IV
8802	Foliant der arkanen Intelligenz
8803	Foliant des Feuerballs
8804	Foliant der arkanen Explosion
8805	Foliant des Magieentdeckens
8806	Foliant der geringen Fluchaufhebung
8807	Foliant des Magieverstärkens
8808	Foliant des Manaschilds
8809	Foliant des Schlafes
8810	Foliant des Schlafes II
8811	Foliant der Versengung
8812	Foliant der arkanen Explosion II
8813	Foliant des Magiedämpfens II
8814	Foliant des Feuerballs V
8815	Foliant des Kältekegels
8816	Foliant des Frostblitzes V
8818	Foliant des Manaschilds II
8819	Foliant der Versengung II
8820	Foliant des Feuerzauberschutzes II
8821	Foliant des Magieverstärkens II
8822	Foliant der arkanen Explosion III
8823	Foliant des Feuerschlages IV
8824	Foliant des Feuerballs VI
8825	Foliant des Frostzauberschutzes III
8826	Foliant der arkanen Geschosse IV
8827	Elixier des Wasserwandelns
8828	Foliant des Frostblitzes VI
8829	Foliant des Kältekegels II
8830	Foliant der Versengung III
8831	Lila Lotus
8832	Foliant des Blizzards III
8833	Foliant des Manaschilds III
8834	Foliant des Magiedämpfens III
8835	Foliant des Feuerballs VII
8836	Arthas' Tränen
8837	Foliant der arkanen Explosion V
8838	Sonnengras
8839	Blindkraut
8840	Foliant des Manaedelstein-Herbeizauberns II
8841	Foliant des Feuerschlages V
8842	Foliant des Frostblitzes VII
8843	Foliant des Feuerzauberschutzes III
8844	Foliant des Schlafes III
8845	Geisterpilz
8846	Gromsblut
8847	Foliant der Versengung V
8848	Foliant des Flammenstoßes IV
8849	Foliant der arkanen Geschosse V
8850	Foliant des Wasser-Herbeizauberns V
8851	Foliant des Feuerballs VIII
8852	Foliant der arkanen Intelligenz IV
8853	Foliant des Essen-Herbeizauberns V
8854	Foliant des Kältekegels III
8855	Foliant des Magieverstärkens III
8856	Foliant des Frostblitzes VIII
8857	Foliant des Blizzards IV
8858	Foliant des Manaschilds IV
8859	Foliant des Feuerschlages VI
8860	Foliant des Feuerballs IX
8861	Foliant des Manaedelstein-Herbeizauberns III
8862	Foliant der arkanen Geschosse VI
8863	Foliant des Magiedämpfens IV
8864	Foliant des Flammenstoßes V
8865	Foliant der Eisrüstung III
8866	Foliant des Kältekegels IV
8867	Foliant des Frostblitzes IX
8868	Foliant des Wasser-Herbeizauberns VI
8869	Foliant des Feuerzauberschutzes IV
8870	Foliant der großen Unsichtbarkeit
8871	Foliant des Essen-Herbeizauberns VI
8872	Foliant des Blizzards V
8873	Foliant des Manaschilds V
8874	Foliant der Versengung VI
8875	Foliant des Frostzauberschutzes IV
8876	Foliant des Frostzauberschutzes II
8877	Foliant des Feuerballs X
8878	Foliant des Feuerschlages VII
8879	Foliant der Frostnova IV
8880	Foliant der arkanen Explosion VI
8881	Foliant von Khadgars Öffnung IV
8882	Foliant des Magieverstärkens IV
8883	Foliant der arkanen Intelligenz V
8884	Foliant des Frostblitzes X
8885	Foliant der arkanen Geschosse VII
8886	Foliant des Flammenstoßes VI
8887	Foliant der Versengung VII
8888	Foliant des Kältekegels V
8889	Foliant des Manaedelstein-Herbeizauberns IV
8890	Foliant des Feuerballs XI
8891	Foliant der Eisrüstung IV
8892	Foliant des Wasser-Herbeizauberns VII
8893	Foliant des Schlafes IV
8894	Foliant des Magiedämpfens V
8895	Foliant des Blizzards VI
8896	Foliant des Manaschilds VI
8897	Foliant des Feuerzauberschutzes V
8898	Foliant der arkanen Explosion IV
8899	Foliant der Versengung IV
8900	Buch der Wucherwurzeln IV
8901	Buch der heilenden Berührung VIII
8902	Buch des Mals der Wildnis V
8903	Buch des Mondfeuers VII
8904	Buch des Mondfeuers VIII
8905	Buch des Nachwachsens VI
8906	Buch der Verjüngung VIII
8907	Buch des Sternenfeuers IV
8909	Buchband: Heiliger Stoß II
8910	Buchband: Handauflegung
8911	Buchband: Faust der Gerechtigkeit
8912	Buchband: Kreuzfahrerstoß
8913	Buchband: Heiliger Stoß III
8914	Buchband: Kreuzfahrerstoß II
8915	Buchband: Heiliger Stoß IV
8916	Buchband: Faust der Gerechtigkeit II
8917	Buchband: Handauflegung II
8918	Buchband: Siegel des Schutzes III
8919	Buchband: Heiliger Stoß V
8920	Buchband: Kreuzfahrerstoß III
8921	Buchband: Faust der Gerechtigkeit III
8922	Buchband: Heiliger Stoß VI
8923	Essenz der Pein
8924	Staub der Verschlechterung
8925	Kristallphiole
8926	Sofort wirkendes Gift IV
8927	Sofort wirkendes Gift V
8928	Sofort wirkendes Gift VI
8929	Buchband: Exorzismus IV
8930	Buchband: Siegel der Rechtschaffenheit IV
8931	Buchband: Kreuzfahrerstoß IV
8932	Alteraclochkäse
8933	Buchband: Heiliges Licht VII
8934	Buchband: Heiliger Stoß VII
8935	Buchband: Richturteil II
8936	Buchband: Siegel des Zorns III
8937	Buchband: Handauflegung III
8938	Buchband: Untote vertreiben III
8939	Buchband: Exorzismus V
8940	Buchband: Faust der Gerechtigkeit IV
8941	Buchband: Heiliges Licht VIII
8942	Buchband: Siegel der Rechtschaffenheit V
8943	Buchband: Heiliger Stoß VIII
8944	Buchband: Kreuzfahrerstoß V
8945	Buchband: Richturteil III
8947	Buchband: Exorzismus VI
8948	Getrockneter Königsboletus
8949	Elixier der Beweglichkeit
8950	Hausgemachter Kirschkuchen
8951	Elixier der großen Verteidigung
8952	Geröstete Wachtel
8953	Frittierte Kochbanane
8954	Kodex des Heiligen Wortes: Seelenstärke
8955	Kodex des Verblassens
8956	Öl des Feuerbrandes
8957	Rückenflossenheilbutt
8958	Kodex des Gedankenschlages
8959	Roher Rückenflossenheilbutt
8960	Kodex der Krankheitsheilung
8961	Kodex des Psychischen Schreis
8962	Kodex des Gedankenschlages II
8963	Kodex der Gedankenbesänftigung
8964	Kodex der Blitzheilung
8965	Kodex des Verblassens II
8966	Kodex der Untotenfesselung
8967	Kodex des Gedankenschlages III
8968	Kodex des Manabrands
8969	Kodex der Blitzheilung II
8971	Kodex des Psychischen Schreis II
8972	Kodex des Gedankenschlages IV
8973	Dicker Yetibalg
8974	Kodex der Gedankenkontrolle
8975	Kodex des Verblassens III
8976	Kodex der Krankheitsaufhebung
8977	Kodex des Manabrands II
8978	Kodex der Blitzheilung III
8980	Kodex des Gedankenschlages V
8981	Kodex der Gedankenbesänftigung II
8983	Kodex der Blitzheilung IV
8984	Tödliches Gift III
8985	Tödliches Gift IV
8986	Kodex der Untotenfesselung II
8987	Kodex des Heiligen Schutzes II
8988	Kodex des Manabrands III
8989	Kodex des Verblassens IV
8990	Kodex des Gedankenschlages VI
8991	Kodex des Inneren Feuers IV
8992	Kodex des Psychischen Schreis III
8993	Kodex des Schattenschutzes II
8994	Kodex des Schattenwortes: Schmerz VI
8995	Kodex des Heiligen Wortes: Schild VII
8996	Kodex der Auferstehung III
8997	Kodex der Gedankenkontrolle II
8998	Kodex der Gedankensicht II
8999	Kodex der Blitzheilung V
9000	Kodex der Erneuerung VII
9001	Kodex der großen Heilung II
9002	Kodex des Gedankenschlages VII
9003	Kodex des Heiligen Schmetterns VII
9004	Kodex des Heiligen Wortes: Seelenstärke V
9005	Kodex des Manabrands IV
9006	Kodex des Heiligen Wortes: Schild VIII
9007	Kodex des Verblassens V
9008	Kodex des Gebets der Heilung III
9009	Kodex des Inneren Feuers V
9010	Kodex der Blitzheilung VI
9011	Kodex des Schattenwortes: Schmerz VII
9012	Kodex der Erneuerung VIII
9013	Kodex der großen Heilung III
9014	Kodex der Gedankenbesänftigung III
9015	Kodex des Gedankenschlages VIII
9016	Kodex des Heiligen Schmetterns VIII
9017	Kodex des Heiligen Schutzes III
9018	Kodex des Heiligen Wortes: Schild IX
9019	Kodex der Erneuerung IX
9020	Kodex des Psychischen Schreis IV
9021	Kodex des Manabrands V
9022	Kodex der Blitzheilung VII
9023	Kodex des Schattenschutzes III
9024	Kodex der Gedankenkontrolle III
9025	Kodex der großen Heilung IV
9026	Kodex der Auferstehung IV
9027	Kodex des Gedankenschlages IX
9028	Kodex des Schattenwortes: Schmerz VIII
9029	Kodex des Verblassens VI
9030	Regenerationstrank
9031	Kodex der Untotenfesselung III
9032	Kodex des Gebets der Heilung IV
9033	Kodex des Inneren Feuers VI
9034	Kodex des Heiligen Wortes: Seelenstärke VI
9035	Kodex des Heiligen Wortes: Schild X
9036	Magiewiderstandstrank
9037	Schrifttafel der Waffe des Felsbeißers
9039	Schrifttafel des Erdschocks
9040	Schrifttafel der Welle der Heilung II
9041	Schrifttafel des Totems der Erdbindung
9043	Schrifttafel des Totems der Steinklaue
9044	Schrifttafel des Erdschocks II
9046	Schrifttafel des Totems der Erdstärke
9047	Schrifttafel des Flammenschocks
9048	Schrifttafel der Wiedergeburt
9049	Schrifttafel des Totems der Feuernova
9050	Schrifttafel der Welle der Heilung III
9051	Schrifttafel des Erdschocks III
9052	Schrifttafel des Totems der Steinhaut II
9053	Schrifttafel der Waffe des Felsbeißers II
9054	Schrifttafel des Flammenschocks II
9055	Schrifttafel des Totems der Steinklaue II
9056	Schrifttafel der Welle der Heilung IV
9057	Schrifttafel der Frostbrandwaffe
9058	Schrifttafel des Frostschocks
9059	Schrifttafel der Flammenzungenwaffe
9060	Veredelter Mithrilzylinder
9061	Goblin-Raketentreibstoff
9062	Schrifttafel der Krankheitsheilung
9063	Schrifttafel des Totems der Giftreinigung
9064	Schrifttafel der Flammenzungenwaffe II
9065	Schrifttafel des Totems der Feuernova II
9066	Schrifttafel des Totems des Frostwiderstands
9067	Schrifttafel des Totems der Erdstärke II
9068	Schrifttafel des Totems der Steinhaut III
9069	Schrifttafel des Erdschocks IV
9070	Schrifttafel der Welle der Heilung V
9071	Schrifttafel des Manaborn-Totems
9072	Schrifttafel des Totems der Flammenzunge
9073	Schrifttafel der Windzornwaffe
9074	Schrifttafel des Flammenschocks III
9075	Schrifttafel des Totems des Feuerwiderstands
9076	Schrifttafel des Magma Totems
9077	Schrifttafel des Totems der Steinklaue III
9078	Schrifttafel des Totems der Erdung
9079	Schrifttafel des Blitzschlagschocks
9080	Schrifttafel des Naturwiderstand Totems
9081	Schrifttafel des Totems des heilenden Flusses II
9082	Schrifttafel der Waffe des Felsbeißers III
9083	Schrifttafel des Totems der Verbrennung III
9084	Schrifttafel des Windzorn-Totems
9085	Schrifttafel des Totems der Feuernova III
9086	Schrifttafel der Welle der Heilung VI
9087	Schrifttafel der Reinigung II
9088	Arthas' Gabe
9089	Schrifttafel des Frostschocks II
9090	Schrifttafel der Frostbrandwaffe II
9091	Schrifttafel des Totems der Steinhaut IV
9092	Schrifttafel des Totems des Wachens
9093	Schrifttafel des Manaborn-Totems II
9094	Schrifttafel der Flammenzungenwaffe III
9095	Schrifttafel des Erdschocks V
9096	Schrifttafel des Totems der Krankheitsreinigung
9097	Schrifttafel des Magma Totems II
9098	Schrifttafel des Totems der Erdstärke III
9099	Schrifttafel des Totems der Steinklaue IV
9100	Schrifttafel des Blitzschlagschildes V
9101	Schrifttafel der Windzornwaffe II
9102	Schrifttafel des Kettenblitzschlages II
9103	Schrifttafel des Totems des heilenden Flusses III
9104	Schrifttafel des Totems der Verbrennung IV
9105	Schrifttafel der Welle der Heilung VII
9123	Schrifttafel des Blitzschlags VI
9124	Schrifttafel des Blitzschlagschocks II
9125	Schrifttafel des Totems der luftgleichen Anmut
9126	Schrifttafel des Totems der Flammenzunge II
9127	Schrifttafel des Totems des Feuerwiderstands II
9128	Schrifttafel des Totems der Feuernova IV
9129	Schrifttafel der Waffe des Felsbeißers IV
9130	Schrifttafel des Naturwiderstand Totems II
9131	Schrifttafel des Totems der Steinhaut V
9132	Schrifttafel des Schmelzschlages VI
9133	Schrifttafel der Kettenheilung II
9134	Schrifttafel des Windzorn-Totems II
9135	Schrifttafel des Frostschocks III
9136	Schrifttafel des Manaborn-Totems III
9137	Schrifttafel des Blitzschlagschildes VI
9138	Schrifttafel des Magma Totems III
9139	Schrifttafel der Frostbrandwaffe III
9140	Schrifttafel des Kettenblitzschlages III
9141	Schrifttafel des Totems der Steinklaue VI
9142	Schrifttafel des Erdschocks VI
9143	Schrifttafel der Welle der Heilung VIII
9144	Wildrankentrank
9145	Schrifttafel des Blitzschlags VII
9146	Schrifttafel des Totems der Verbrennung V
9147	Schrifttafel des Totems des heilenden Flusses IV
9148	Schrifttafel der Flammenzungenwaffe IV
9149	Stein der Weisen
9150	Schrifttafel des Totems der Erdstärke IV
9151	Schrifttafel des Flammenschocks V
9152	Schrifttafel des Totems der Feuernova V
9153	Maschinenblaupausen
9154	Elixier der Untotenentdeckung
9155	Arkanes Elixier
9156	Schrifttafel des Schmelzschlages VII
9157	Schrifttafel der Kettenheilung III
9158	Schrifttafel des Totems des Frostwiderstands
9159	Schrifttafel des Blitzschlagschocks III
9160	Schrifttafel der Windzornwaffe III
9161	Schrifttafel des Totems der Steinhaut VI
9162	Schrifttafel des Blitzschlagschildes VII
9164	Schrifttafel des Totems der luftgleichen Anmut
9165	Schrifttafel des Totems der Flammenzunge III
9166	Schrifttafel des Manaborn-Totems IV
9167	Schrifttafel des Kettenblitzschlages IV
9168	Schrifttafel der Welle der Heilung IX
9169	Schrifttafel des Blitzschlags VIII
9170	Schrifttafel des Totems des Feuerwiderstands III
9171	Schrifttafel des Magma Totems IV
9172	Unsichtbarkeitstrank
9173	Goblin-Transponder
9174	Schrifttafel des Frostschocks IV
9175	Schrifttafel der Waffe des Felsbeißers V
9176	Schrifttafel des Totems der Steinklaue VI
9177	Schrifttafel des Erdschocks VII
9178	Schrifttafel des Naturwiderstand Totems III
9179	Elixier der großen Intelligenz
9180	Schrifttafel des Windzorn-Totems III
9181	Schrifttafel des Totems des heilenden Flusses V
9182	Schrifttafel des Totems der Verbrennung VI
9183	Schrifttafel der Kettenheilung
9184	Schrifttafel des Flammenschocks IV
9185	Schrifttafel des Totems des Frostwiderstands
9186	Gedankenbenebelndes Gift III
9187	Elixier der großen Beweglichkeit
9188	Schrifttafel des Totems der Verbrennung II
9189	Shays Glocke
9190	Zauberfoliant des Feuerbrandes
9191	Zauberfoliant des Fluchs der Schwäche
9192	Zauberfoliant der Verderbnis
9193	Zauberfoliant des Aderlasses
9194	Zauberfoliant des Fluchs der Pein
9195	Zauberfoliant des Seelenabziehens
9197	Elixier der Traumvision
9198	Zauberfoliant der Lebenslinie
9199	Zauberfoliant des Fluchs der Tollkühnheit
9200	Zauberfoliant des Fluchs der Schwäche II
9201	Zauberfoliant der Verderbnis II
9202	Zauberfoliant des Aderlasses II
9203	Zauberfoliant des Rituals der Beschwörung
9204	Zauberfoliant der Lebenslinie II
9205	Zauberfoliant des Fluchs der Pein II
9206	Elixier der Riesen
9207	Zauberfoliant der Blutsteinherstellung II
9208	Zauberfoliant des Seelenabziehens II
9209	Zauberfoliant des Fluchs der Schwäche III
9210	Geisterfarbstoff
9211	Zauberfoliant des Fluchs der Tollkühnheit II
9212	Zauberfoliant des Schattenblitzes V
9214	Zauberfoliant des Infernos
9215	Zauberfoliant der Lebenslinie III
9216	Zauberfoliant der Verderbnis III
9217	Zauberfoliant des Aderlasses III
9218	Zauberfoliant des Dämonensklaven
9219	Zauberfoliant des Höllenfeuers
9221	Zauberfoliant des Fluchs der Pein III
9222	Zauberfoliant des Fluchs der Elemente
9223	Zauberfoliant des Fluchs der Schwäche IV
9224	Elixier des Dämonentötens
9225	Zauberfoliant des Schattenblitzes VI
9226	Zauberfoliant der Lebenslinie IV
9227	Zauberfoliant des Seelenabziehens III
9228	Zauberfoliant der Blutsteinherstellung III
9229	Zauberfoliant des Lebensaugers IV
9230	Zauberfoliant des Fluchs der Tollkühnheit III
9231	Zauberfoliant der Verderbnis IV
9233	Elixier der Dämonenentdeckung
9234	Tiara der Tiefen
9235	Pratts Brief
9236	Jangdors Brief
9237	Mähne eines Waldpfotengnolls
9238	Unbeschädigte Skarabäusschale
9240	Schlaghammer von Zul'Farrak
9241	Hochheiliger Schlaghammer
9242	Uralte Schrifttafel
9243	Eingetrocknetes Herz
9244	Stoleys Lieferung
9245	Stoleys Flasche
9246	Feuerbarts Kopf
9247	Nagaschuppe der Hasskämme
9248	Geheimnisvolles Relikt
9249	Captain-Schlüssel
9250	Schiffzeitplan
9251	Oberes Kartenfragment
9252	Unteres Kartenfragment
9253	Mittleres Kartenfragment
9254	Cuergos Schatzkarte
9255	Lahassa-Essenz
9256	Imbel-Essenz
9257	Samha-Essenz
9258	Byltan-Essenz
9259	Troll-Stammeshalskette
9260	Flüchtiger Rum
9261	Bleierz
9262	Schwarzes Vitriol
9263	Troyas' Stock
9264	Elixier der Schattenmacht
9265	Cuergos versteckter Schatz
9266	Schlachtpläne der Waldpfoten
9275	Cuergos Schlüssel
9276	Piraten-Schließkiste
9277	Techbots Speicherkern
9278	Grundlegendes Artifix
9279	Weiße Lochkarte
9280	Gelbe Lochkarte
9281	Rote Lochkarte
9282	Blaue Lochkarte
9283	Leere bleierne Sammelphiole
9284	Volle bleierne Sammelphiole
9285	Feldplattenunterarmschienen
9286	Feldplattenrüstung
9287	Feldplattenstulpen
9288	Feldplattengurt
9289	Feldplattenstiefel
9290	Feldplattenhelm
9291	Feldplattengamaschen
9292	Feldplattenschulterstücke
9293	Rezept: Magiewiderstandstrank
9294	Rezept: Wildrankentrank
9295	Rezept: Unsichtbarkeitstrank
9296	Rezept: Arthas' Gabe
9297	Rezept: Elixier der Traumvision
9298	Rezept: Elixier der Riesen
9299	Thermapluggs Safekombination
9300	Rezept: Elixier des Dämonentötens
9301	Rezept: Elixier der Schattenmacht
9302	Rezept: Geisterfarbstoff
9303	Rezept: Stein der Weisen
9304	Rezept: Eisen in Gold transmutieren
9305	Rezept: Mithril in Echtsilber transmutieren
9306	Stock von Equinex
9307	Ein funkelnder Stein
9308	Schmutzverkrustetes Objekt
9309	Robomechanische Gedärme
9311	Schreibwaren
9312	Blaues Feuerwerk
9313	Grünes Feuerwerk
9314	Feuerwerk mit roten Streifen
9315	Feuerwerk mit gelben Rosen
9316	Prismalochkarte
9317	Rotes, weißes und blaues Feuerwerk
9318	Rotes Feuerwerk
9319	Nimboyas geladene Pike
9320	Schädel der Witherbark
9321	Giftflasche
9322	Unbeschädigter Giftbeutel
9323	Gadrins Pergament
9324	Shadras Gift
9325	Ein kleiner Stock
9326	Schmutzverkrusteter Ring
9327	DELTA-Daten-Sicherheitszugangskarte
9328	Superschnapper FX
9329	Eine kurze Notiz
9330	Schnappschuss von Gammerita
9331	Feralas: Ein historischer Abriss
9332	Verkrustete Verbände
9333	Befleckte silberne Halskette
9334	Gesprungene Töpferwaren
9335	Zerbrochene Obsidiankeule
9336	Goldüberkronter Troll-Hauer
9355	Kreolen-Ohrring
9356	Ein Holzbein
9357	Ein Papageienskelett
9358	Ein Kopftuch
9359	Lampe der Südmeerfreibeuter
9360	Cuergos Gold
9361	Cuergos Gold mit Wurm
9362	Blitzender Goldring
9363	Funkelmatverpackter Kasten
9364	Schwere bleierne Sammelphiole
9365	Hochwirksame radioaktive Ablagerung
9366	Goldene Schuppenstulpen
9367	Pläne: Goldene Schuppenstulpen
9368	Jer'kais Siegelring
9369	Schillernder Grimmlingflitzerflügel
9370	Gordunnischriftrolle
9371	Gordunnikugel
9372	Sul'thraze der Peitscher
9375	Expertenhelm des Goldminenarbeiters
9378	Schaufelphlansches Bergbauaxt
9379	Sang'thraze der Schmetterer
9380	Jang'thraze der Beschützer
9381	Irdene Rute
9382	Stürmende Minenarbeiterstiefel
9383	Obsidianspaltbeil
9384	Steingruftmesser
9385	Archaischer Verteidiger
9386	Ausgräber-Marke
9387	Reveloshs Stiefel
9388	Reveloshs Armschützer
9389	Reveloshs Schiftung
9390	Reveloshs Handschuhe
9391	Der Schaufler
9392	Ausgeglühte Klinge
9393	Strahl der Hoffnung
9394	Gehörnter Wikingerhelm
9395	Handschuhe der Vergangenheit
9396	Beinschützer des Gewölbes
9397	Energie-Umhang
9398	Abgenutzte Laufstiefel
9399	Präzisionspfeil
9400	Baelogs Kurzbogen
9401	Nordischer Langschenkel
9402	Erdgeborener Kilt
9403	Ramponierter Wikingerschild
9404	Olafs Allzweck-Schild
9405	Gurt der Golemstärke
9406	Spirewind-Fußfessel
9407	Gamaschen des Steinwebers
9408	Eisenbeschlagener Knüttel
9409	Ironayas Armschienen
9410	Klippenfäuste
9411	Felssplitter-Schulterstücke
9412	Galganns Feuerblaster
9413	Der Felstrommler
9414	Öltuchgamaschen
9415	Grimloks Stammestracht
9416	Grimloks Attacke
9417	Archaedischer Splitter
9418	Steintöter
9419	Galganns Feuerhammer
9420	Abenteurerrundbandhelm
9421	Erheblicher Gesundheitsstein
9422	Buschmeister der Schattenschmiede
9423	Der Vorschlaghammer
9424	Ginn-su-Schwert
9425	Pendel der Verdammnis
9426	Monolith-Bogen
9427	Steingruftknochenbrecher
9428	Ausgegrabene Bänder
9429	Minenarbeiterhut der Tiefen
9430	Schiftung eines Verlorenen Zeitalters
9431	Päpstlicher Fez
9432	Schädelplattenarmschienen
9433	Vergessene Wickeltücher
9434	Elementargewandung
9435	Genetzte Knochenstulpen
9436	Faranells Paket
9437	Ungetestete Basilisken-Probe
9438	Akzeptable Skorpidprobe
9439	Ungetestete Hyänenprobe
9440	Akzeptable Basilisken-Probe
9441	Akzeptable Hyänenprobe
9442	Ungetestete Skorpidprobe
9443	Benutzte Monsterprobe
9444	Techbot-CPU-Hülle
9445	Grubbis' Pfoten
9446	Elektrokutionatorbein
9447	Elektrokutionator-Gewindemutter
9448	Spinnenpanzeröllappen
9449	Handlicher Meuteverprügler
9450	Gnombot-Betriebs-Stiefel
9451	Blubberwasser
9452	Hydrokrückstock
9453	Toxinvergelter
9454	Säurengänger
9455	Abgesandten-Manschetten
9456	Glasschießprügel
9457	Königliches Diplomatenszepter
9458	Thermapluggs Zentralkern
9459	Thermapluggs linker Arm
9460	Grimmtotemhorn
9461	Aufgeladenes Zahnrad
9462	Kiste mit Grimmtotemhörnern
9463	Gordunnikobalt
9465	Grubenmeister 5000
9466	Orwins Schaufel
9467	Fangzahn von Gahz'rilla
9468	Scharfschnabels Feder
9469	Gahz'rillaschuppenrüstung
9470	Maske des schlechten Mojo
9471	Nekrums Medaillon
9472	Hexxs Schlüssel
9473	Verwunschene Hoodoohaut
9474	Verwunschener Hoodookilt
9475	Diabolisches Schlitzmesser
9476	Große böse Schulterstücke
9477	Der Vollstrecker des Häuptlings
9478	Fetzsäge
9479	Umarmung des Lykan
9480	Augenquetscher
9481	Der Minotaurus
9482	Hexendoktorkrückstock
9483	Lodernder Verbrenner
9484	Zauberschock-Gamaschen
9485	Vibroklinge
9486	Superaufgeladene Streitaxt
9487	Hightech-Superschusswaffe
9488	Oszillierender Servohammer
9489	Gyromatischer Eismacher
9490	Gizmotronisches Megahackbeil
9491	Draufgängerpiloten-Handschuhe
9492	Elektromagnetischer Gigaflux-Reaktivator
9507	Eine sorgfältig gepackte Kiste
9508	Robobauer-Overall
9509	Petroleumpfützen-Gamaschen
9510	Stampfer der Tiefentroggs
9511	Aderlassskalpell
9512	Schwarzmetallcape
9513	Leystab
9514	Arkaner Stab
9515	Netherspitzentunika
9516	Astralknotenbluse
9517	Himmlischer Stock
9518	Muds Zermalmer
9519	Durtfeet-Stampfer
9520	Schweigsamer Jäger
9521	Schädelspalter
9522	Energiegeladener Steinkreis
9523	Trollaushärter
9527	Zauberformerrute
9528	Edanas dunkles Herz
9529	Internes Kriegerausstattungsset L25
9530	Horn von Hasskralle
9531	Edelsteinschiefer-Schulterstücke
9532	Internes Kriegerausstattungsset L30
9533	Masons Bruderschaftsring
9534	Ingenieursgildenkopfstück
9535	Feuergeschmiedete Armschienen
9536	Feenflügel-Mantel
9537	Sauber verpackter Kasten
9538	Talvashs Goldring
9539	Kasten mit Rationen
9540	Kasten mit Zaubern
9541	Kasten mit Kram
9542	Einfacher Brief
9543	Einfache Rune
9544	Einfaches Memorandum
9545	Einfaches Siegelzeichen
9546	Einfache Rolle
9547	Einfache Notiz
9548	Geheiligter Brief
9550	Verschlüsselte Rune
9551	Verschlüsseltes Siegelzeichen
9552	Mit Runen beschriftete Notiz
9553	Geätztes Pergament
9554	Verschlüsselte Schrifttafel
9555	Verschlüsselter Brief
9556	Geheiligte Rune
9557	Geheiligtes Siegelzeichen
9558	Verschlüsseltes Memorandum
9559	Verschlüsselte Rolle
9560	Verschlüsseltes Pergament
9561	Geheiligte Schrifttafel
9562	Mit Runen beschriftete Schrifttafel
9563	Geweihte Rune
9564	Geätzte Schrifttafel
9565	Geätzte Notiz
9566	Geätzte Rune
9567	Geätztes Siegelzeichen
9568	Mit Runen beschriftetes Pergament
9569	Geheiligte Rolle
9570	Geweihter Brief
9571	Glyphen-Brief
9572	<UNUSED> Glyphic Rune
9573	Glyphen-Memorandum
9574	Glyphen-Rolle
9575	Glyphen-Schrifttafel
9576	Besudelter Brief
9577	Besudeltes Memorandum
9578	Besudelte Rolle
9579	Besudeltes Pergament
9580	Tiefgrünes Siegelzeichen
9581	Tiefgrüne Notiz
9587	Taupelzsack
9588	Noggs Goldring
9589	Verkrustete Mineralien
9590	Abgesplitterter Baumstamm
9591	Widerstandsfähige Sehne
9592	Metallische Fragmente
9593	Muisek von Treants
9594	Muisek von Wildekins
9595	Muisek von Hippogryphen
9596	Muisek von Feendrachen
9597	Muisek von Bergriesen
9598	Schlaf-Roben
9599	Rindenpanzergamaschen
9600	Spitzenhose
9601	Gepolsterte Stiefel
9602	Buschklinge
9603	Schneidwurzelstab
9604	Mechanikerrohrhammer
9605	Schlosser-Cape
9606	Muisekgefäß für Treants
9607	Bastion von Stormwind
9608	Shonis Entwaffnungs-Werkzeug
9609	Fäustlinge der Entschlossenheit
9618	Muisekgefäß für Wildekins
9619	Muisekgefäß für Hippogryphen
9620	Muisekgefäß für Feendrachen
9621	Muisekgefäß für Bergriesen
9622	Schilfknotenring
9623	Civinad-Roben
9624	Stolperläufer-Latzhose
9625	Zweifach verstärkte Gamaschen
9626	Zwergenstürmer
9627	Forscherliga-Erzaderstern
9628	Neerus Kräuterbeutel
9629	Ein Schrumpfkopf
9630	Pratts handgefertigte Stiefel
9631	Pratts handgefertigte Handschuhe
9632	Jangdors handgefertigte Handschuhe
9633	Jangdors handgefertigte Stiefel
9634	Geschickte Abrichtungs-Handschuhe
9635	Apothekermeistercape
9636	Schwadroneursschärpe
9637	Schienbeintreter-Stiefel
9638	Chelonische Manschetten
9639	Die Hand von Antu'sul
9640	Zwingenhandschutz
9641	Lebensblut-Amulett
9642	Band der Großen Schildkröte
9643	Optomatischer Deflektor
9644	Thermotastische Eieruhr
9645	Gnomische Erfinder-Stiefel
9646	Gnomisches Wasser-Absenkungsgerät
9647	Fehlgeschlagenes Flugexperiment
9648	Maschendrahthandtuch
9649	Königliche Hochmaltracht
9650	Ehrenwache-Brustharnisch
9651	Greifenreiter-Sturmhammer
9652	Greifenreiter-Gamaschen
9653	Schutzbrille des rasenden Rennfahrers
9654	Cairnstone-Span
9655	Saatzeitreifen
9656	Granithandschutz
9657	Rankenhecken-Sattelgurt
9658	Stiefel der Maharishi
9660	Sternenschauer-Umhang
9661	Erdschnallenbarriere
9662	Rushridge-Stiefel
9663	Sonnenaufgangsreiter-Brustharnisch
9664	Schildwachenschutz
9665	Flügelwappen-Handschuhe
9666	Starkhorn-Gurt
9678	Tok'Kars Murlocberster
9679	Tok'Kars Murlochackbeil
9680	Tok'Kars Murlocentbeiner
9681	Gegrillte Königskriecherbeine
9682	Lederner Gürtel des Küchenchefs
9683	Kraft des Treant
9684	Gewalt des Hippogryphen
9685	Wille des Bergriesen
9686	Geist des Feendrachen
9687	Greifer-Gürtel
9698	Handschuhe der Einsicht
9699	Garnisons-Umhang
9703	Versengtes Cape
9704	Handschuhe des Viehdiebs
9705	Thargs Schnürsenkel
9706	Thargs Scheibe
9718	Neugeschmiedete Klinge der Helden
9719	Zerbrochene Klinge der Helden
9738	Edelstein von Kobrahn
9739	Edelstein von Anacondra
9740	Edelstein von Pythas
9741	Edelstein von Serpentis
9742	Einfache Kordel
9743	Einfache Schuhe
9744	Einfache Bänder
9745	Einfaches Cape
9746	Einfache Handschuhe
9747	Einfache Kniehosen
9748	Einfache Robe
9749	Einfache Bluse
9750	Reiseschärpe
9751	Reisesandalen
9752	Reisebänder
9753	Reiserundschild
9754	Reiseumhang
9755	Reisehandschuhe
9756	Reisebeinkleider
9757	Reisetunika
9758	Kadettengürtel
9759	Kadettenstiefel
9760	Kadettenarmschienen
9761	Kadettenumhang
9762	Kadettenstulpen
9763	Kadettengamaschen
9764	Kadettenschild
9765	Kadettenweste
9766	Grünzwirnschärpe
9767	Grünzwirnsandalen
9768	Grünzwirnarmschienen
9769	Grünzwirnzweig
9770	Grünzwirnumhang
9771	Grünzwirnhandschuhe
9772	Grünzwirngamaschen
9773	Grünzwirnrobe
9774	Grünzwirnweste
9775	Banditen-Sattelgurt
9776	Banditen-Stiefel
9777	Banditen-Armschienen
9778	Banditen-Rundschild
9779	Banditen-Umhang
9780	Banditen-Handschuhe
9781	Banditen-Hose
9782	Banditen-Wams
9783	Räuber-Brustharnisch
9784	Räuber-Stiefel
9785	Räuber-Armschienen
9786	Räuber-Umhang
9787	Räuber-Stulpen
9788	Räuber-Gürtel
9789	Räuber-Beinschützer
9790	Räuber-Schild
9791	Efeustofftunika
9792	Efeustoffstiefel
9793	Efeustoffarmreifen
9794	Efeustoffumhang
9795	Efeustoffhandschuhe
9796	Efeustoffmantel
9797	Efeustoffhose
9798	Efeustoffrobe
9799	Efeustoffschärpe
9800	Efeu-Kugel
9801	Überragender Gürtel
9802	Überragende Stiefel
9803	Überragende Armschienen
9804	Überragender Rundschild
9805	Überragender Umhang
9806	Überragende Handschuhe
9807	Überragende Schultern
9808	Überragende Gamaschen
9809	Überragende Tunika
9810	Befestigte Stiefel
9811	Befestigte Armschienen
9812	Befestigter Umhang
9813	Befestigte Stulpen
9814	Befestigter Gürtel
9815	Befestigte Gamaschen
9816	Befestigter Schild
9817	Befestigte Schiftung
9818	Befestigte Kette
9819	Haltbare Tunika
9820	Haltbare Stiefel
9821	Haltbare Armschienen
9822	Haltbares Cape
9823	Haltbare Handschuhe
9824	Haltbare Schultern
9825	Haltbare Hose
9826	Haltbare Robe
9827	Lederschuppengürtel
9828	Lederschuppenstiefel
9829	Lederschuppenarmschienen
9830	Schuppiger Schild
9831	Schuppenumhang
9832	Lederschuppenhandschuhe
9833	Lederschuppengamaschen
9834	Lederschuppenschultern
9835	Lederschuppentunika
9836	Bebänderte Rüstung
9837	Bebänderte Armschienen
9838	Bebänderter Umhang
9839	Bebänderte Stulpen
9840	Bebänderter Gurt
9841	Bebänderte Gamaschen
9842	Bebänderte Schulterstücke
9843	Bebänderter Schild
9844	Herbeizauberer-Weste
9845	Herbeizauberer-Schuhe
9846	Herbeizauberer-Armschienen
9847	Herbeizauberer-Umhang
9848	Herbeizauberer-Handschuhe
9849	Herbeizauberer-Kapuze
9850	Herbeizauberer-Mantel
9851	Herbeizauberer-Bundhosen
9852	Herbeizauberer-Robe
9853	Herbeizauberer-Sattelgurt
9854	Bogenschützen-Wams
9855	Bogenschützen-Gürtel
9856	Bogenschützen-Stiefel
9857	Bogenschützen-Armschienen
9858	Bogenschützen-Rundschild
9859	Bogenschützen-Kappe
9860	Bogenschützen-Umhang
9861	Bogenschützen-Handschuhe
9862	Bogenschützen-Beinkleider
9863	Bogenschützen-Schulterpolster
9864	Renegaten-Stiefel
9865	Renegaten-Armschienen
9866	Renegaten-Brustschutz
9867	Renegaten-Umhang
9868	Renegaten-Stulpen
9869	Renegaten-Gürtel
9870	Renegaten-Reif
9871	Renegaten-Gamaschen
9872	Renegaten-Schulterstücke
9873	Renegaten-Schild
9874	Zauberhexertuch
9875	Zauberhexerschärpe
9876	Zauberhexerschuhe
9877	Zauberhexerumhang
9878	Zauberhexerhut
9879	Zauberhexerarmreifen
9880	Zauberhexerhandschuhe
9881	Zauberhexermantel
9882	Zauberhexersphäre
9883	Zauberhexerhose
9884	Zauberhexerrobe
9885	Jägersmann-Stiefel
9886	Jägersmann-Bänder
9887	Jägersmann-Rüstung
9889	Jägersmann-Kappe
9890	Jägersmann-Cape
9891	Jägersmann-Gürtel
9892	Jägersmann-Handschuhe
9893	Jägersmann-Gamaschen
9894	Jägersmann-Schultern
9895	Jazeraintstiefel
9896	Jazeraintarmschienen
9897	Jazeraintbrustschutz
9898	Jazeraintumhang
9899	Jazeraintschild
9900	Jazeraintstulpen
9901	Jazeraintgürtel
9902	Jazerainthelm
9903	Jazeraintgamaschen
9904	Jazeraintschulterstücke
9905	Königliche Bluse
9906	Königliche Schärpe
9907	Königliche Stiefel
9908	Königliches Cape
9909	Königliche Bänder
9910	Königliche Handschuhe
9911	Königliche Beinkleider
9912	Königliche Amicia
9913	Königliches Abendkleid
9914	Königliches Szepter
9915	Königliches Stirnband
9916	Fährtenlesergürtel
9917	Fährtenleserstiefel
9918	Brigadeverteidiger
9919	Fährtenleserumhang
9920	Fährtenleserhandschuhe
9921	Fährtenleserstirnband
9922	Fährtenlesergamaschen
9923	Fährtenleserschulterpolster
9924	Fährtenlesertunika
9925	Fährtenleserhandgelenksschutz
9926	Brigadestiefel
9927	Brigadearmschienen
9928	Brigadebrustplatte
9929	Brigadeumhang
9930	Brigadestulpen
9931	Brigadegurt
9932	Brigadereif
9933	Brigadegamaschen
9934	Brigadeschulterstücke
9935	Geprägter Plattenschild
9936	Abschwörerstiefel
9937	Abschwörerbänder
9938	Abschwörerumhang
9939	Abschwörerhandschuhe
9940	Abschwörerkapuze
9941	Abschwörermantel
9942	Abschwörerhose
9943	Abschwörerrobe
9944	Abschwörerkristall
9945	Abschwörerschärpe
9946	Abschwörertunika
9947	Häuptlingsgürtel
9948	Häuptlingsstiefel
9949	Häuptlingsarmschienen
9950	Häuptlingsbrustplatte
9951	Häuptlingsumhang
9952	Häuptlingshandschuhe
9953	Häuptlingskopfputz
9954	Häuptlingsgamaschen
9955	Häuptlingsschultern
9956	Kriegstreiberarmschienen
9957	Kriegstreiberbrustharnisch
9958	Kriegstreiberrundschild
9959	Kriegstreiberumhang
9960	Kriegstreiberstulpen
9961	Kriegstreibergürtel
9962	Kriegstreiberschienbeinschützer
9963	Kriegstreiberreif
9964	Kriegstreibergamaschen
9965	Kriegstreiberschulterstücke
9966	Geprägte Plattenrüstung
9967	Geprägte Plattenstulpen
9968	Geprägter Plattengurt
9969	Geprägter Plattenhelm
9970	Geprägte Plattengamaschen
9971	Geprägte Plattenschulterstücke
9972	Geprägte Plattenarmschienen
9973	Geprägte Plattenstiefel
9974	Oberherrenschild
9978	Gahz'ridian-Detektor
9998	Schwarze Magiestoffweste
9999	Schwarze Magiestoffgamaschen
10000	Margols Horn
10001	Schwarze Magiestoffrobe
10002	Schattenzwirnhose
10003	Schwarze Magiestoffhandschuhe
10004	Schattenzwirnrobe
10005	Margols gigantisches Horn
10007	Rote Magiestoffweste
10008	Weiße Banditenmaske
10009	Rote Magiestoffhose
10010	Sturmstoffhose
10011	Sturmstoffhandschuhe
10018	Rote Magiestoffhandschuhe
10019	Traumzwirnhandschuhe
10020	Sturmstoffweste
10021	Traumzwirnweste
10022	Besitznachweis
10023	Schattenzwirnhandschuhe
10024	Schwarzes Magiestoffstirnband
10025	Schattenzwirnmaske
10026	Schwarze Magiestoffstiefel
10027	Schwarze Magiestoffschultern
10028	Schattenzwirnschultern
10029	Rote Magiestoffschultern
10030	Admiralshut
10031	Schattenzwirnstiefel
10032	Sturmstoffstirnband
10033	Rotes Magiestoffstirnband
10034	Smokinghemd
10035	Smokinghose
10036	Smokingjacke
10038	Sturmstoffschultern
10039	Sturmstoffstiefel
10040	Weißes Hochzeitskleid
10041	Traumzwirnreif
10042	Aschenstoffrobe
10043	Fromme Beinwickel
10044	Aschenstoffstiefel
10045	Einfache Leinenhose
10046	Einfache Leinenstiefel
10047	Einfacher Kilt
10048	Bunter Kilt
10049	Diabolisten-Klinge
10050	Magiestofftasche
10051	Rote Magiestofftasche
10052	Oranges Kampfhemd
10053	Einfaches schwarzes Kleid
10054	Lavendelfarbenes Magiestoffhemd
10055	Rosa Magiestoffhemd
10056	Oranges Magiestoffhemd
10057	Dämmergewirkte Tunika
10058	Dämmergewirkte Sandalen
10059	Dämmergewirkte Armschienen
10060	Dämmergewirktes Cape
10061	Dämmergewirkter Turban
10062	Dämmergewirkte Handschuhe
10063	Dämmergewirkte Amicia
10064	Dämmergewirkte Hose
10065	Dämmergewirkte Robe
10066	Dämmergewirkte Schärpe
10067	Rechtschaffener Taillenschutz
10068	Rechtschaffene Stiefel
10069	Rechtschaffene Armschienen
10070	Rechtschaffene Rüstung
10071	Rechtschaffener Umhang
10072	Rechtschaffene Handschuhe
10073	Rechtschaffener Helm
10074	Rechtschaffene Gamaschen
10075	Rechtschaffene Schiftung
10076	Adelsarmschützer
10077	Adelsbrustplatte
10078	Lordwappen
10079	Adelscape
10080	Adelsstulpen
10081	Adelsgürtel
10082	Adelsstiefel
10083	Adelskrone
10084	Adelsbeinschützer
10085	Adelsschulterstücke
10086	Gotische Plattenrüstung
10087	Gotische Plattenstulpen
10088	Gotischer Plattengurt
10089	Gotische Sabatons
10090	Gotischer Plattenhelm
10091	Gotische Plattengamaschen
10092	Gotische Plattenschiftung
10093	Klagegeistdeflektor
10094	Gotische Plattenunterarmschienen
10095	Ratsherrenstiefel
10096	Ratsherrenmanschetten
10097	Ratsherrenreif
10098	Ratsherrenumhang
10099	Ratsherrenhandschuhe
10100	Ratsherrenschultern
10101	Ratsherrenhose
10102	Ratsherrenroben
10103	Ratsherrenschärpe
10104	Ratsherrentunika
10105	Wandererrüstung
10106	Wandererstiefel
10107	Wandererarmschienen
10108	Wandererumhang
10109	Wanderergürtel
10110	Wandererhandschuhe
10111	Wandererhut
10112	Wanderergamaschen
10113	Wandererschultern
10118	Verschnörkelte Brustplatte
10119	Verschnörkelte Schienbeinschützer
10120	Verschnörkelter Umhang
10121	Verschnörkelte Stulpen
10122	Verschnörkelter Gurt
10123	Verschnörkelter Reif
10124	Verschnörkelte Beinschützer
10125	Verschnörkelte Schulterstücke
10126	Verschnörkelte Armschienen
10127	Klagegeistarmschienen
10128	Klagegeistbrustplatte
10129	Klagegeiststulpen
10130	Klagegeistgurt
10131	Klagegeiststiefel
10132	Klagegeisthelm
10133	Klagegeistgamaschen
10134	Klagegeistschultern
10135	Oberratsherrentunika
10136	Oberratsherrenarmschienen
10137	Oberratsherrenstiefel
10138	Oberberaterumhang
10139	Oberratsherrenreif
10140	Oberratsherrenhandschuhe
10141	Oberratsherrenhose
10142	Oberratsherrenmantel
10143	Oberratsherrenrobe
10144	Oberratsherrenschärpe
10145	Mächtiger Gurt
10146	Mächtige Stiefel
10147	Mächtige Armsplinte
10148	Mächtiger Umhang
10149	Mächtige Stulpen
10150	Mächtiger Helm
10151	Mächtige Tunika
10152	Mächtige Gamaschen
10153	Mächtige Schiftung
10154	Quecksilbriger Gurt
10155	Quecksilbrige Schienbeinschützer
10156	Quecksilbrige Armschienen
10157	Quecksilbrige Brustplatte
10158	Quecksilbriger Schutz
10159	Quecksilbriger Umhang
10160	Quecksilbriger Reif
10161	Quecksilbrige Stulpen
10162	Quecksilbrige Beinschützer
10163	Quecksilbrige Schulterstücke
10164	Templer-Brustplatte
10165	Templer-Stulpen
10166	Templer-Gurt
10167	Templer-Stiefel
10168	Templer-Krone
10169	Templer-Beinplatten
10170	Templer-Schulterstücke
10171	Templer-Armschienen
10172	Mystischer Mantel
10173	Mystische Armschienen
10174	Mystisches Cape
10175	Mystisches Kopfband
10176	Mystische Handschuhe
10177	Mystische Gamaschen
10178	Mystische Robe
10179	Mystische Stiefel
10180	Mystischer Gürtel
10181	Mystische Rüstung
10182	Schwadroneursbrustplatte
10183	Schwadroneursstiefel
10184	Schwadroneursarmschienen
10185	Schwadroneurscape
10186	Schwadroneurshandschuhe
10187	Schwadroneursaugenklappe
10188	Schwadroneursgamaschen
10189	Schwadroneursschulterpolster
10190	Schwadroneursgürtel
10191	Kreuzfahrer-Armschützer
10192	Kreuzfahrer-Stiefel
10193	Kreuzfahrer-Rüstung
10194	Kreuzfahrer-Umhang
10195	Kreuzfahrer-Schild
10196	Kreuzfahrer-Stulpen
10197	Kreuzfahrer-Gürtel
10198	Kreuzfahrer-Helm
10199	Kreuzfahrer-Gamaschen
10200	Kreuzfahrer-Schulterstücke
10201	Oberherrenschienbeinschützer
10202	Oberherrenunterarmschienen
10203	Oberherrenbrustplatte
10204	Schwerer Lamellenschild
10205	Oberherrenstulpen
10206	Oberherrengurt
10207	Oberherrenkrone
10208	Oberherrenbeinplatten
10209	Oberherrenschiftung
10210	Eleganter Mantel
10211	Elegante Stiefel
10212	Eleganter Umhang
10213	Elegante Armschienen
10214	Elegante Handschuhe
10215	Elegante Roben
10216	Eleganter Gürtel
10217	Elegante Gamaschen
10218	Elegante Tunika
10219	Eleganter Reif
10220	Nachtschattentunika
10221	Nachtschattengurt
10222	Nachtschattenstiefel
10223	Nachtschattenarmschützer
10224	Nachtschattenumhang
10225	Nachtschattenhandschuhe
10226	Nachtschattenhelm
10227	Nachtschattengamaschen
10228	Nachtschattenschiftung
10229	Gravierte Armschienen
10230	Gravierte Brustplatte
10231	Graviertes Cape
10232	Gravierte Stulpen
10233	Gravierter Gurt
10234	Gravierte Stiefel
10235	Gravierter Helm
10236	Gravierte Gamaschen
10237	Gravierte Schulterstücke
10238	Schwere Lamellenstiefel
10239	Schwere Lamellenunterarmschienen
10240	Schwerer Lamellenbrustharnisch
10241	Schwerer Lamellenhelm
10242	Schwere Lamellenstulpen
10243	Schwerer Lamellengurt
10244	Schwere Lamellengamaschen
10245	Schwere Lamellenschulterstücke
10246	Meisterweste
10247	Meisterstiefel
10248	Meisterarmschienen
10249	Meisterumhang
10250	Meisterhut
10251	Meisterhandschuhe
10252	Meistergamaschen
10253	Meistermantel
10254	Meisterrobe
10255	Meistergürtel
10256	Abenteurerarmschienen
10257	Abenteurerstiefel
10258	Abenteurercape
10259	Abenteurergürtel
10260	Abenteurerhandschuhe
10261	Abenteurerkopftuch
10262	Abenteurerbeinschützer
10263	Abenteurerschultern
10264	Abenteurertunika
10265	Meisterliche Armschienen
10266	Meisterliche Brustplatte
10267	Meisterliches Cape
10268	Meisterliche Stulpen
10269	Meisterlicher Gurt
10270	Meisterliche Stiefel
10271	Meisterlicher Schild
10272	Meisterlicher Reif
10273	Meisterliche Beinplatten
10274	Meisterliche Schulterstücke
10275	Smaragdbrustplatte
10276	Smaragdsabatons
10277	Smaragdstulpen
10278	Smaragdgurt
10279	Smaragdhelm
10280	Smaragdbeinplatten
10281	Smaragdschulterstücke
10282	Smaragdunterarmschienen
10283	Wolfherz-Proben
10285	Schattenseide
10286	Herz der Wildnis
10287	Grünzwirnmantel
10288	Weisenreif
10289	Haltbarer Hut
10290	Rosa Farbstoff
10298	Gnomeregan-Band
10299	Gnomeregan-Amulett
10300	Muster: Rote Magiestoffweste
10301	Muster: Weiße Banditenmaske
10302	Muster: Rote Magiestoffhose
10303	Muster: Sturmstoffhose
10304	Muster: Sturmstoffhandschuhe
10305	Rolle des Schutzes IV
10306	Rolle der Willenskraft IV
10307	Rolle der Ausdauer IV
10308	Rolle der Intelligenz IV
10309	Rolle der Beweglichkeit IV
10310	Rolle der Stärke IV
10311	Muster: Oranges Kampfhemd
10312	Muster: Rote Magiestoffhandschuhe
10313	Muster: Sturmstoffweste
10314	Muster: Lavendelfarbenes Magiestoffhemd
10315	Muster: Rote Magiestoffschultern
10316	Muster: Bunter Kilt
10317	Muster: Rosa Magiestoffhemd
10318	Muster: Admiralshut
10319	Muster: Sturmstoffstirnband
10320	Muster: Rotes Magiestoffstirnband
10321	Muster: Smokinghemd
10322	Muster: Sturmstoffschultern
10323	Muster: Smokinghose
10324	Muster: Sturmstoffstiefel
10325	Muster: Weißes Hochzeitskleid
10326	Muster: Smokingjacke
10327	Horn von Echeyakee
10328	Scharlachroter Brustharnisch
10329	Scharlachroter Gürtel
10330	Scharlachrote Gamaschen
10331	Scharlachrote Stulpen
10332	Scharlachrote Stiefel
10333	Scharlachroter Handgelenksschutz
10338	Frischer Zhevra-Kadaver
10358	Duracin-Armschienen
10359	Ewige Stiefel
10360	Schwarze Königsnatter
10361	Braune Natter
10362	Verschnörkelter Schild
10363	Gravierte Wand
10364	Templer-Schild
10365	Smaragdschild
10366	Dämonenwache
10367	Hyperionschild
10368	Magieerfüllte Plattenrüstung
10369	Magieerfüllte Plattenstulpen
10370	Magieerfüllter Plattengurt
10371	Magieerfüllte Plattenschienbeinschützer
10372	Magieerfüllter Plattenhelm
10373	Magieerfüllte Plattengamaschen
10374	Magieerfüllte Plattenschulterstücke
10375	Magieerfüllte Plattenunterarmschienen
10376	Kommandanten-Stiefel
10377	Kommandanten-Unterarmschienen
10378	Kommandanten-Rüstung
10379	Kommandanten-Helm
10380	Kommandanten-Stulpen
10381	Kommandanten-Gurt
10382	Kommandanten-Gamaschen
10383	Kommandanten-Schulterstücke
10384	Hyperionrüstung
10385	Hyperionschienbeinschützer
10386	Hyperionstulpen
10387	Hyperiongurt
10388	Hyperionhelm
10389	Hyperionbeinplatten
10390	Hyperionschulterstücke
10391	Hyperionunterarmschienen
10392	Purpurrote Natter
10393	Kakerlake
10394	Präriehundepfeife
10398	Mechanisches Huhn
10399	Geschwärzte Rüstung der Defias
10400	Geschwärzte Gamaschen der Defias
10401	Geschwärzte Handschuhe der Defias
10402	Geschwärzte Stiefel der Defias
10403	Geschwärzter Gürtel der Defias
10404	Haltbarer Gürtel
10405	Banditen-Schultern
10406	Lederschuppenstirnband
10407	Räuber-Schulterpolster
10408	Bebänderter Helm
10409	Bebänderte Stiefel
10410	Gamaschen des Giftzahns
10411	Fußpolster des Giftzahns
10412	Gürtel des Giftzahns
10413	Handschuhe des Giftzahns
10414	Schnappkieferschalen-Probe
10418	Gleißende Mithrilinsignien
10420	Schädel des Kältebringers
10421	Raue Kupferweste
10423	Bronzene Gamaschen mit Versilberung
10424	Pläne: Bronzene Gamaschen mit Versilberung
10438	Felix' Kasten
10439	Durnans kochend heißes Morgengebräu
10440	Noris Becher
10441	Leuchtender Splitter
10442	Geheimnisvolles Artefakt
10443	Angesengter Brief
10444	Standardausrüstung Leuchtfeuerwaffe
10445	Zeichenset
10446	Herz von Obsidion
10447	Kopf von Lathoric dem Schwarzem
10450	Unbeschädigte Hippogryphenfeder
10454	Essenz des Eranikus
10455	Angekettete Essenz des Eranikus
10456	Ein mit Münzen prall gefüllter Geldbeutel
10457	Leere Seeschneckenschale
10458	Gebet an Elune
10459	Häuptling Spitzhauer Dornenmantels Kopf
10460	Hakkariblut
10461	Schattenhafte Armschienen
10462	Schattenhafter Gürtel
10463	Muster: Schattenzwirnmaske
10464	Stab des Befehls
10465	Ei von Hakkar
10466	Steinkreis der Atal'ai
10467	Händlerranzen
10478	Ronalds Manaedelstein
10479	Kovics Handelsranzen
10498	Gyromatischer Mikroregler
10499	Hellaugenschutzbrille
10500	Feuerschutzbrille
10501	Katzenaugen-Ultraschutzbrille
10502	Zaubermachtschutzbrille Xtrem
10503	Rosarote Schutzbrille
10504	Grüne Linse
10505	Robustes Sprengpulver
10506	Tiefentaucherhelm
10507	Robustes Dynamit
10508	Mithrildonnerbüchse
10509	Herz der Flamme
10510	Schwerkalibriges Mithrilgewehr
10511	Golemöl
10512	Stark einschlagende Mithrilpatronen
10513	Gyro-Mithrilgeschoss
10514	Mithrilschrapnellbombe
10515	Fackel der Vergeltung
10518	Fallschirm-Umhang
10538	Schrifttafel von Beth'Amara
10539	Schrifttafel von Jin'yael
10540	Schrifttafel von Markri
10541	Schrifttafel von Sael'hai
10542	Goblin-Bergbauhelm
10543	Goblinscher Schutzhelm
10544	Distelholzschlägel
10545	Gnomen-Schutzbrille
10546	Tödliches Zielfernrohr
10547	Campingmesser
10548	Heckenschützen-Zielfernrohr
10549	Rancher-Beinkleider
10550	Wollfäustlinge
10551	Thoriumbeschichteter Dolch
10552	Symbol von Ragnaros
10553	Großknecht-Weste
10554	Großknecht-Hose
10556	Steinkreis
10558	Goldkraftkern
10559	Mithrilrohr
10560	Instabiler Auslöser
10561	Mithrilgehäuse
10562	Hochexplosive Bombe
10563	Abpausbild: Rune von Beth'Amara
10564	Abpausbild: Rune von Jin'yael
10565	Abpausbild: Rune von Markri
10566	Abpausbild: Rune von Sael'hai
10567	Stachelschießer
10569	Hort des schwarzen Drachenschwarms
10570	Menschentöter
10571	Ebenholzknochenkeule
10572	Eissplitter
10573	Knochenschlitzer
10574	Leichentuch
10575	Abgestreifte Haut des schwarzen Drachenschwarms
10576	Mechanischer Mithrildrachling
10577	Goblin-Mörser
10578	Gedankenzauber-Stiefel
10579	Explosiver Pfeil
10580	Goblin-"Bumm"-Kasten
10581	Totenkopftracht
10582	Briar-Treter
10583	Leichtkielharnisch
10584	Fäuste des unbändigen Sturms
10585	Goblin-Radio
10586	Der Große
10587	Goblin-Bombenspender
10588	Goblin-Raketenhelm
10589	Schwurstein von Yseras Drachenschwarm
10590	Zerdellter Flugschreiber
10592	Katzenaugenelixier
10593	Unvollständiges Draenethystfragment
10595	Kum'isha's Junk
10597	Kopf von Magus Rimtori
10598	Blutiger Hetärenkopf
10599	Geschlagener Hetärenkopf
10600	Verwundeter Hetärenkopf
10601	Bauplan: Hellaugenschutzbrille
10602	Bauplan: Tödliches Zielfernrohr
10603	Bauplan: Katzenaugen-Ultraschutzbrille
10604	Bauplan: Schwerkalibriges Mithrilgewehr
10605	Bauplan: Zaubermachtschutzbrille Xtrem
10606	Bauplan: Fallschirm-Umhang
10607	Bauplan: Tiefentaucherhelm
10608	Bauplan: Heckenschützen-Zielfernrohr
10609	Bauplan: Mechanischer Mithrildrachling
10610	Hetärenblut
10620	Thoriumerz
10621	Runenverzierte Rolle
10622	Kadraks Flagge
10623	Winterbiss
10624	Stechbogen
10625	Klinge der Verstohlenheit
10626	Wuthammer
10627	Knüttel des Grinsenden Hundes
10628	Todesstoß
10629	Stiefel des Nebelläufers
10630	Seelenfängerheiligenschein
10631	Dumpfwasserstulpen
10632	Schleimschuppenarmschienen
10633	Silberschalen-Gamaschen
10634	Gedankenaugenreif
10635	Bemalte Kettengamaschen
10636	Nomadenhandschuhe
10637	Brauer-Handschuhe
10638	Langes Schleppen-Cape
10639	Hyazinth-Pilz
10640	Waldwebersekret
10641	Mondblütenlilie
10642	Iverrons Gegengift
10643	Versiegelter Brief an Ag'tor
10644	Rezept: Goblin-Raketentreibstoff
10645	Gnomentodesstrahl
10646	Goblinsche Pioniersprengladung
10647	Ingenieurstinte
10648	Leeres Pergament
10649	Alptraumsplitter
10650	Seuchenbefallene Stachelebermähne
10651	Gesprungener arkaner Fokussierkristall
10652	Wille des Bergriesen
10653	Wegbereiter-Stiefel
10654	Jutezopf-Handschuhe
10655	Seggenried-Kniehosen
10656	Rindenpanzerweste
10657	Talbar-Mantel
10658	Morastgaloschen
10659	Splitter der Spalthufe
10660	Erste Mosh'aru-Schrifttafel
10661	Zweite Mosh'aru-Schrifttafel
10662	Gefülltes Ei von Hakkar
10663	Essenz von Hakkar
10664	Eine Notiz an Magus Rimtori
10678	Magathas Notiz
10679	Androns Notiz
10680	Jes'rimons Notiz
10681	Xylems Notiz
10682	Belnistraszs Schwurstein
10683	Forscherknappsack
10684	Kolossaler Fallschirm
10686	Aegis des Kampfes
10687	Leere Phiole markiert mit Nr. 1
10688	Leere Phiole markiert mit Nr. 2
10689	Leere Phiole markiert mit Nr. 3
10690	Leere Phiole markiert mit Nr. 4
10691	Gefüllte Phiole markiert mit Nr. 1
10692	Gefüllte Phiole markiert mit Nr. 2
10693	Gefüllte Phiole markiert mit Nr. 3
10694	Gefüllte Phiole markiert mit Nr. 4
10695	Kasten mit leeren Phiolen
10696	Verzaubertes Azsharit-Teufelsbannschwert
10697	Verzauberter Azsharit-Teufelsbanndolch
10698	Verzauberter Azsharit-Teufelsbannstab
10699	Yeh'kinyas Dornbusch
10700	Encarmine-Stiefel
10701	Stiefel von Zua'tec
10702	Riesige Ogerstiefel
10703	Satansmesser
10704	Fröstelnagel-Splinter
10705	Fichtenweidengelenkbänder
10706	Nachtschuppengurt
10707	Schienbeinschützer des Stahlschmieds
10708	Schädelzauberkugel
10709	Pyrosteinkugel
10710	Drachenklauenring
10711	Drachenblut-Halskette
10712	Cuelys Elixier
10713	Pläne: Veredelter Mithrilzylinder
10714	Kristallisierter Azsharit
10715	Kim'jaels Zielfernrohr
10716	Gnomen-Schrumpfstrahl
10717	Kim'jaels Kompass
10718	Kim'jaels Wizzlegoober
10719	Mobiler Alarm
10720	Gnomen-Net-o-Matik-Projektor
10721	Gnomen-Unglücksverhinderungsgürtel
10722	Kim'jaels gefülltes Huhn
10723	Gnomen-Amateurradio
10724	Gnomen-Raketenstiefel
10725	Gnomen-Kampfhuhn
10726	Gnomen-Gedankenkontrollkappe
10727	Goblinscher Drachenwerfer
10728	Muster: Schwarzes Schwadroneurshemd
10738	Lieferung an Galvan
10739	Ring der Seelenstärke
10740	Zenturio-Beinplatten
10741	Lordrec-Helm
10742	Drachenschwarm-Gamaschen
10743	Drachenfeuerkopfschutz
10744	Axt des Ebenholzdrachen
10745	Kaylari-Schultern
10746	Runenstahlunterarmschienen
10747	Lehrerschärpe
10748	Wanderlust-Stiefel
10749	Avenwach-Helm
10750	Langdolch der Lebenskraft
10751	Edelsteinbesetzter Reif
10752	Smaragdbesetzte Truhe
10753	Amulett von Grol
10754	Amulett von Sevine
10755	Amulett von Allistarj
10757	Zauberschutz der Entweihten
10758	X'caliboar
10759	Abgetrenntes Horn des Entweihers
10760	Schweinefäuste
10761	Kaltwutdolch
10762	Roben des Lich
10763	Eismetallbarbute
10764	Todesfrösteln-Rüstung
10765	Knochenfinger
10766	Seuchenfäulniszweiglein
10767	Wächter des Wildebers
10768	Eberheldengürtel
10769	Glühendes Auge von Mordresh
10770	Mordreshs lebloser Schädel
10771	Todesmagierschärpe
10772	Nimmersatts Spaltbeil
10773	Urne der Hakkari
10774	Fleischbalg-Schultern
10775	Knochenpanzer von Tuten'kash
10776	Seidenes Spinnencape
10777	Arachnidenhandschuhe
10778	Halskette des Heiligtums
10779	Dämonenblut
10780	Mal von Hakkar
10781	Hakkaribrustplatte
10782	Hakkarituch
10783	Atal'aiische Schiftung
10784	Atal'aiische Brustplatte
10785	Atal'aiische Gamaschen
10786	Atal'aiische Stiefel
10787	Atal'aiische Handschuhe
10788	Atal'aiischer Gurt
10789	Handbuch der Ingenieurskunst-Disziplinen
10790	Gnomen-Ingenieur-Mitgliedskarte
10791	Goblin-Ingenieur-Mitgliedskarte
10792	Nixx' Schwur der Geheimhaltung
10793	Oversparks Schwur der Geheimhaltung
10794	Oglethorpes Schwur der Geheimhaltung
10795	Drachenklauenband
10796	Drachenstein
10797	Feuerspucker
10798	Atal'alarions Hauerring
10799	Kopfstachel
10800	Dunkelwasserarmschienen
10801	Schlängelschuppenstiefel
10802	Flügelschleier-Umhang
10803	Klinge des Elenden
10804	Fäuste der Verdammten
10805	Fresser der Toten
10806	Prophetentracht der Atal'ai
10807	Prophetenkilt der Atal'ai
10808	Prophetenhandschuhe der Atal'ai
10818	Yeh'kinyas Rolle
10819	Wildekinfeder
10820	Jacksaat-Gürtel
10821	Säer-Umhang
10822	Dunkelwelpling
10823	Bezwingerschwert
10824	Bernsteinglut-Talisman
10826	Stab der Lehre
10827	Feldmesser-Tunika
10828	Terrornagel
10829	Großdrachenauge
10830	M73 Schrapnellgranate
10831	Teufelskugel
10832	Handbuch für Teufelsfährtenleser
10833	Hörner des Eranikus
10834	Teufelshundfährtenleserset
10835	Wappen der Vorherrschaft
10836	Rute der Korrosion
10837	Zahn des Eranikus
10838	Macht von Hakkar
10839	Kristallisierte Notiz
10840	Kristallisierte Notiz
10841	Golddorntee
10842	Windschuppensarong
10843	Federhautcape
10844	Spitze von Hakkar
10845	Kriegerumarmung
10846	Blutunterlaufene Schienbeinschützer
10847	Großdrachenruf
10858	Pläne: Robuster Eisenschlägel
10918	Wundgift
10919	Apotheker-Handschuhe
10920	Wundgift II
10921	Wundgift III
10922	Wundgift IV
10938	Geringe Magieessenz
10939	Große Magieessenz
10940	Seltsamer Staub
10958	Hilarys Halskette
10959	Dämonenbalgsack
10978	Kleiner gleißender Splitter
10998	Geringe Astralessenz
10999	Ironfel
11000	Schlüssel zur Schattenschmiede
11018	Un'Goro-Erde
11020	Immergrünbeutel
11022	Paket mit Tharlendrissamenkörnern
11023	Ancona-Huhn
11024	Immergrünkrautgehäuse
11026	Baumfrosch-Kasten
11027	Waldfrosch-Kasten
11038	Formel: Zweihandwaffe - Geringe Willenskraft
11039	Formel: Umhang - Schwache Beweglichkeit
11040	Morgenkorn
11058	Sha'nis Nasenring
11078	Reliktkastenschlüssel
11079	Gor'teshs abgehackter Kopf
11080	Gor'teshs abgehackter Kopf
11081	Formel: Schild - Geringer Schutz
11082	Große Astralessenz
11083	Seelenstaub
11084	Großer gleißender Splitter
11085	'Kunde des Monats'-Kastenschlüssel
11086	Jang'thraze der Beschützer
11098	Formel: Umhang - Geringer Schattenwiderstand
11099	Dunkeleisenerz
11101	Formel: Armschiene - Geringe Stärke
11102	Unausgebrütetes Grimmlingflitzerei
11103	Samenkorngutschein
11104	Großer Kompass
11105	Welliges Kartenpergament
11106	Löwenkopfschlüssel
11107	Ein kleines Pack
11108	Verblasste Fotografie
11109	Spezial-Hühnerfutter
11110	Hühner-Ei
11111	Zerbrochenes Grimmlingflitzerei
11112	Forscherausrüstung
11113	Kiste mit Lebensmitteln
11114	Dinosaurierknochen
11115	Geheimsafe-Schlüssel
11116	Ein zerfleddertes Tagebuch
11118	Archaedischer Stein
11119	Millys Ernte
11120	Belgroms Hammer
11121	Dunkelwassertalwar
11122	Karotte am Stiel
11123	Regenschreiter-Gamaschen
11124	Helm des Banns
11125	Traubenliste
11126	Schrifttafel von Kurniya
11127	Aufgestöberte Waren
11128	Goldrute
11129	Essenz der Elemente
11130	Runenverzierte Goldrute
11131	Schwarmbauwandprobe
11132	Unbenutzte Kratzphiole
11133	Linkens Ausbildungsschwert
11134	Geringe Mystikeressenz
11135	Große Mystikeressenz
11136	Linkens ausgehärtetes Schwert
11137	Visionenstaub
11138	Kleiner leuchtender Splitter
11139	Großer leuchtender Splitter
11140	Gefängniszellenschlüssel
11141	Köder
11142	Zerbrochenes Samophlang
11143	Nugget-Patrone
11144	Echtsilberrute
11145	Runenverzierte Echtsilberrute
11146	Zerbrochenes und ramponiertes Samophlang
11147	Samophlang-Handbuchumschlag
11148	Samophlang-Handbuchseite
11149	Samophlang-Handbuch
11150	Formel: Handschuhe - Bergbau
11151	Formel: Handschuhe - Kräuterkunde
11152	Formel: Handschuhe - Angeln
11162	Linkens überragendes Schwert
11163	Formel: Armschiene - Geringe Abwehr
11164	Formel: Waffe - Geringer Wildtiertöter
11165	Formel: Waffe - Geringer Elementartöter
11166	Formel: Handschuhe - Kürschnerei
11167	Formel: Stiefel - Geringe Willenskraft
11168	Formel: Schild - Geringes Blocken
11169	Buch von Aquor
11171	Teufelseisen
11172	Silbrige Klauen
11173	Eisenstammherz
11174	Geringe Netheressenz
11175	Große Netheressenz
11176	Traumstaub
11177	Kleiner strahlender Splitter
11178	Großer strahlender Splitter
11179	Goldene Flamme
11184	Blauer Machtkristall
11185	Grüner Machtkristall
11186	Roter Machtkristall
11187	Stammblatt-Armschienen
11188	Gelber Machtkristall
11189	Waldland-Roben
11190	Ranken-Handschuhe
11191	Bauern-Stiefel
11192	Ausstatter-Handschuhe
11193	Lohenwindbrustplatte
11194	Prismaschuppenhalsberge
11195	Kriegsgeschmiedete Brustplatte
11196	Gedankenexplosion-Medaillon
11197	Dunkelbewahrer-Schlüssel
11198	Rune der Flucht
11199	Ingenieur-Schild 1
11200	Ingenieur-Schild 2
11201	Ingenieur-Schild 3
11202	Formel: Schild - Ausdauer
11203	Formel: Handschuhe - Hochentwickelter Bergbau
11204	Formel: Armschiene - Große Willenskraft
11205	Formel: Handschuhe - Hochentwickelte Kräuterkunde
11206	Formel: Umhang - Geringe Beweglichkeit
11207	Formel: Waffe - Feurige Waffe
11208	Formel: Waffe - Dämonentöten
11222	Krom'zars Kopf
11223	Formel: Armschiene - Abwehr
11224	Formel: Schild - Frostwiderstand
11225	Formel: Armschiene - Große Ausdauer
11226	Formel: Handschuhe - Reitfertigkeit
11227	Teil von Krom'zars Flagge
11228	Abgestreifte Haut des rasenden Drachenschwarms
11229	Hellschuppengurt
11230	Eingeschlossene feurige Essenz
11231	Veränderte Haut des schwarzen Drachenschwarms
11242	Evowurzel
11243	Videre-Elixier
11262	Kugel von Lorica
11263	Zauberstab der Netherkraft
11265	Klippenholzschlägel
11266	Gerissener Elementarsplitter
11267	Elementarsplitterprobe
11268	Argelmachs Kopf
11269	Intakter Elementarkern
11270	Nixx' unterschriebener Schwur
11282	Oglethorpes unterschriebener Schwur
11283	Oversparks unterschriebener Schwur
11284	Genaue Patronen
11285	Gezackter Pfeil
11286	Thoriumfesseln
11287	Geringer Magiezauberstab
11288	Großer Magiezauberstab
11289	Geringer Mystikerzauberstab
11290	Großer Mystikerzauberstab
11291	Sternenholz
11302	Uthers Kraft
11303	Feiner Kurzbogen
11304	Feiner Langbogen
11305	Handfester Kurzbogen
11306	Stabiler Doppelbogen
11307	Massiver Langbogen
11308	Sylvankurzbogen
11309	Das Herz des Berges
11310	Flammensehermantel
11311	Glutschuppencape
11312	Verlorenes Donnerbräurezept
11313	Ribblys Kopf
11315	Blutblütensprössling
11316	Blutblüte
11318	Dunst der Atal'ai
11319	Ungeladener Schrumpfer
11320	Blutblütenschrumpfer
11324	Forscherknappsack
11325	Dunkeleisenbierbecher
11362	Mittlerer Köcher
11363	Mittlerer Geschossbeutel
11364	Wams von Stormwind
11366	Helendis Riverhorns Brief
11367	Solomons Hilfegesuch an Bolvar
11368	Bolvars Erlass
11370	Dunkeleisenerz
11371	Dunkeleisenbarren
11382	Blut des Berges
11384	Zerbrochene Basiliskenzähne
11385	Basiliskenschuppe
11386	Matschiges Basiliskenauge
11387	Basiliskenherz
11388	Basiliskengift
11389	Schimmernde Basiliskenhaut
11390	Zerbrochener Fledermaus-Fangzahn
11391	Stachelfledermausflügel
11392	Abgespaltene Fledermausklaue
11393	Kleiner Fledermausschädel
11394	Fledermausherz
11395	Fledermausohr
11402	Schicker Fledermauspelz
11403	Großer Fledermausfangzahn
11404	Böses Fledermausauge
11405	Riesensilbervene
11406	Faulendes Bärengerippe
11407	Zerrissener Bärenpelz
11408	Bärenkiefer
11409	Bärenflanke
11410	Klaue eines wilden Bären
11411	Großer Bärenknochen
11412	Nagmaras Phiole
11413	Nagmaras gefüllte Phiole
11414	Ergraute Mähne
11415	Gemischte Beeren
11416	Zierlicher Brustkorb
11417	Gefiederter Flügel
11418	Hohler Flügelknochen
11419	Mysteriöses unausgebrütetes Ei
11420	Elegantes Schreibwerkzeug
11422	Erneuerungsgeschenk des Goblin-Ingenieurs
11423	Erneuerungsgeschenk des Gnomen-Ingenieurs
11442	Stellvertreterset aus Stormwind
11444	Fleisch aus dem 'Grimmigen Säufer'
11445	Flöte der Urtume
11446	Eine zusammengeknüllte Notiz
11462	Weggeworfenes Messer
11463	Niemals zugestelltes Paket
11464	Marshal Windsors verlorene Informationen
11465	Marshal Windsors verlorene Informationen
11466	Raschals Bericht
11467	Medaillon der Blackrock
11468	Dunkeleisengürteltasche
11469	Blutbandarmschienen
11470	Schrifttafel-Abschrift
11471	Empfindliches Grimmlingflitzerei
11472	Silbermähnenpirscherflanke
11473	PX83-Enigmatron
11474	Grimmlingflitzerei
11475	Weinbefleckter Umhang
11476	U'chas Pelz
11477	Weiße Ravasaurusklaue
11478	Un'Goro-Gorillapelz
11479	Un'Goro-Stampferpelz
11480	Un'Goro-Donnererpelz
11482	Handbuch für Kristallpylonen
11502	Schultern der Gelehrsamkeit
11503	Blutharz
11504	Teil eines Dreschadongerippes
11507	Gefleckter Hyänenpelz
11508	Game Master-Slipper
11509	Ravasaurus-Pheromondrüse
11510	Lar'korwis Kopf
11511	Cenarisches Leuchtfeuer
11512	Besudelter Hautfetzen
11513	Besudeltes Vitriol
11514	Teufelsunhold
11515	Verderbter Seelensplitter
11516	Cenarische Pflanzensalbe
11522	Silbertotem von Aquementas
11562	Kristallflicker
11563	Kristallkraft
11564	Kristallbarriere
11565	Kristallschwächer
11566	Kristallsprengladung
11567	Kristallspitze
11568	Torwas Beutel
11569	Bewahrtes Dreschadonfleisch
11570	Bewahrte Pheromon-Mixtur
11582	Teufelssalbe
11583	Kaktusapfel
11584	Kaktusapfel Surprise
11590	Mechanisches Reparierset
11602	Schlüssel des 'Grimmigen Säufers'
11603	Schändlicher Zerschnitzler
11604	Dunkeleisenplatte
11605	Dunkeleisenschultern
11606	Dunkeleisenpanzer
11607	Dunkeleisenzerreißer
11608	Dunkeleisenpulverisierer
11609	Veränderte Haut des schwarzen Drachenschwarms
11610	Pläne: Dunkeleisenpulverisierer
11611	Pläne: Dunkeleisenzerreißer
11612	Pläne: Dunkeleisenplatte
11614	Pläne: Dunkeleisenpanzer
11615	Pläne: Dunkeleisenschultern
11617	Eridans Tasche
11622	Geringes Arkanum des Nachsinnens
11623	Cape des Geisterzaubers
11624	Kentische Amicia
11625	Umzauberte Sphäre
11626	Trauerschleiercape
11627	Schienbeinschützer des Flinkfußes
11628	Hundemeisterbogen
11629	Hundemeisterflinte
11630	Felssplitterkügelchen
11631	Steinpanzerwache
11632	Schultern der verbrannten Erde
11633	Spinnenfangzahnknochenpanzer
11634	Seidengespinsthandschuhe
11635	Hakenklaue
11642	Geringes Arkanum der Konstitution
11643	Geringes Arkanum der Hartnäckigkeit
11644	Geringes Arkanum der Widerstandsfähigkeit
11645	Geringes Arkanum der Gier
11646	Geringes Arkanum der Gier
11647	Geringes Arkanum der Gier
11648	Geringes Arkanum der Gier
11649	Geringes Arkanum der Gier
11662	Ban'thokschärpe
11665	Ogerseherfäuste
11668	Flöte des Xavaric
11669	Nagelring
11674	Jadefeuerteufelsbinder
11675	Stiefel der Schattengeister
11677	Modergrabcape
11678	Knochenpanzer von Anub'shiah
11679	Rosige Armschützer
11682	Eridans Phiole
11684	Ironfoe
11685	Splitterfellschultern
11686	Gurt des bestialischen Furors
11702	Grizzles Kürschner
11703	Steinkrempengurt
11722	Rußgeschwärzte Metallschiftung
11723	Goodsteels ausbalancierter Flamberg
11724	Überfälliges Päckchen
11725	Robuster Kristallbeinschaft
11726	Wilde Gladiatorenkette
11727	Goodsteel-Geschäftsbuch
11728	Wilde Gladiatorengamaschen
11729	Wilder Gladiatorenhelm
11730	Wilder Gladiatorenhandschutz
11731	Wilde Gladiatorenschienbeinschützer
11732	Buchband des Nachsinnens
11733	Buchband der Konstitution
11734	Buchband der Hartnäckigkeit
11735	Ragefury-Augenklappe
11736	Buchband der Widerstandsfähigkeit
11737	Buchband der Gier
11742	Wandererknappsack
11743	Steinfaust
11744	Blutfaust
11745	Fäuste der Phalanx
11746	Golemschädel-Helm
11747	Flammenschreiter-Roben
11748	Pyrischer Merkurstab
11749	Sengschuppengamaschen
11750	Entzünderstock
11751	Brennende Essenz
11752	Schwarzes Blut der Gequälten
11753	Auge von Kajal
11754	Schwarzer Diamant
11755	Vereks Halsband
11764	Aschenarmsplinte
11765	Feuerpanzerhandgelenksschutz
11766	Brandzwirnmanschetten
11767	Glutplattenarmschützer
11768	Aufwieglerische Armschienen
11782	Borealis-Mantel
11783	Fröstelstahlgurt
11784	Vermittlerklinge
11785	Steingolem-Bollwerk
11786	Stein der Erde
11787	Schieferplattenstiefel
11802	Lavakranzgamaschen
11803	Magmagewalt
11804	Spraggles Feldflasche
11805	Rubidiumhammer
11807	Schärpe des brennenden Herzens
11808	Reif der Flamme
11809	Flammenzorn
11810	Macht des Willens
11811	Rauchendes Herz des Berges
11812	Cape des Feuersalamanders
11813	Formel: Rauchendes Herz des Berges
11814	Geschmolzene Fäuste
11815	Hand der Gerechtigkeit
11816	Zornesschmieds Streitaxt
11817	Schwert des Lordgenerals
11818	Schlüssel für Grimesilt-Nebengebäude
11819	Zweiter Wind
11820	Königlich dekorierte Rüstung
11821	Kriegszwist-Gamaschen
11822	Alleszauber-Stiefel
11823	Lumineszierender Kilt
11824	Zyklopisches Band
11825	Winzige wandelnde Bombe
11826	Lil' Smoky
11827	Bauplan: Lil' Smoky
11828	Bauplan: Winzige wandelnde Bombe
11829	Un'Goro-Asche
11830	Eingesponnene Dimetrodonschuppe
11831	Eingesponnene Pterrordaxschuppe
11832	Explosion des Wissens
11833	Köder für die Gorishischwarmkönigin
11834	Superklebriger Teer
11835	Gehirn der Gorishischwarmkönigin
11837	Gorishiduftdrüse
11839	Chefarchitektenmonokel
11840	Meistererbauerhemd
11841	Pantalons des leitenden Designers
11842	Mantel des leitenden Feldmessers
11843	Bankgutschein
11844	Pestlezuggs Un'Goro-Bericht
11845	Handgefertigte Ledertasche
11846	Wizbangs Spezialbräu
11847	Ramponierter Umhang
11848	Flachs-Gürtel
11849	Rostmetallarmschienen
11850	Kurzes Nachtsaugercape
11851	Aasfresser-Tunika
11852	Streifer-Gamaschen
11853	Stromer-Stiefel
11854	Samophlang-Schraubendreher
11855	Drehmomentschlüssel
11856	Zeremonielle Elfenklinge
11857	Scheinheilige Rute
11858	Kampfgehärtetes Cape
11859	Jademondkugel
11860	Aufgeladene Blitzschlagrute
11861	Gurt des Vergeltungsakts
11862	Weißknochenband
11863	Weißknochenschredder
11864	Weißknochenspeer
11865	Groll-Stiefel
11866	Nagmaras Peitschen-Gürtel
11867	Unerträgliche Stulpen
11868	Würgeband
11869	Sha'nis Ring
11870	Vergessenheitskugel
11871	Sagenumwobene Schiftung
11872	Scheuende Schienbeinschützer
11873	Astralnebelcape
11874	Mantel des Wolkengestöbers
11875	Armschienen des Wolkenhauchs
11876	Ebenenpirschertunika
11882	Vorhut-Gamaschen
11883	Eine schmuddelige Gürteltasche
11884	Mondbeschienene Amicia
11885	Schattenschmiedefackel
11886	Dringende Nachricht
11887	Behälter des Zirkels des Cenarius
11888	Quintis' Forschungs-Handschuhe
11889	Borkeneisenschulterstücke
11902	Linkens Meisterschwert
11903	Katzentransportkorb (Verderbtes Kätzchen)
11904	Geist von Aquementas
11905	Linkens Bumerang
11906	Wildtierzerhacker
11907	Wildtiertöter
11908	Steinbruchstiefel des Archäologen
11909	Ausgräberwerkzeug-Gürtel
11910	Geschmückte Beinschützer
11911	Baumkronen-Gamaschen
11912	Gebinde mit leeren Brühschlammerbehältern
11913	Vulkanhelm
11914	Leerer verfluchter Brühschlammerkrug
11915	Shizzles Nieselblocker
11916	Shizzles Maulkorb
11917	Shizzles Mündungswischlappen
11918	Höhlensteinhandschuhe
11919	Cragplate-Schienbeinschützer
11920	Gespenstersense
11921	Unempfindlicher Riese
11922	Blutgeätzte Klinge
11923	Der Hammer der Anmut
11924	Roben der königlichen Krone
11925	Geistertuch
11926	Brustplatte des Totschlägers
11927	Beinplatten des ewigen Wächters
11928	Thaurissans königliches Szepter
11929	Spukende Schreckgespenst-Gamaschen
11930	Des Kaisers neuer Umhang
11931	Dreadforge-Vergelter
11932	Führungsstock der Weisheit
11933	Imperiales Juwel
11934	Imperatorsiegel
11935	Magmusstein
11936	Reliktjäger-Gürtel
11937	Praller Sack Münzen
11938	Sack Edelsteine
11939	Glänzender Armreif
11940	Funkelnde Halskette
11941	Falsche Dokumente
11942	Rechtsdokumente
11943	Besitzurkunde über den Thandol-Übergang
11944	Dunkeleisenkinderstiefel
11945	Dunkeleisenring
11946	Feueropalhalskette
11947	Gefüllter verfluchter Brühschlammerkrug
11948	Leerer besudelter Brühschlammerkrug
11949	Gefüllter besudelter Brühschlammerkrug
11950	Windblütenbeeren
11951	Peitscherwurzelknollen
11952	Nachtdrachenodem
11953	Leerer reiner Probenkrug
11954	Gefüllter reiner Probenkrug
11955	Tasche mit leeren Brühschlammerbehältern
11962	Handfessel-Manschetten
11963	Bußwerk-Schiftung
11964	Hurtigschlagknüppel
11965	Quarzring
11966	Kleiner Sack Münzen
11967	Zirkonband
11968	Bernsteinreifen
11969	Hyazinth-Reif
11970	Spinellring
11971	Amethystband
11972	Karneolschleife
11973	Hämatitverbindung
11974	Aquamarinring
11975	Topasring
11976	Sardonyxschlagring
11977	Serpentinschleife
11978	Jaspisverbindung
11979	Peridotreif
11980	Opalring
11981	Bleiband
11982	Viridiumband
11983	Chromring
11984	Kobaltring
11985	Himmelblauer Ring
11986	Thalliumreifen
11987	Iridiumreif
11988	Tellurband
11989	Vanadiumschleife
11990	Selenitschleife
11991	Quecksilberring
11992	Zinnoberband
11993	Tonring
11994	Korallenband
11995	Elfenbeinband
11996	Basaltring
11997	Grünsteinreif
11998	Jettschleife
11999	Leitsteinreifen
12000	Gliedmaßenspaltbeil
12001	Onyxring
12002	Marmorreif
12003	Dunkles zwergisches Lagerbier
12004	Obsidianband
12005	Granitring
12006	Wiesenring
12007	Präriering
12008	Savannenring
12009	Tundraring
12010	Moorring
12011	Waldreifen
12012	Marschring
12013	Wüstenring
12014	Arktischer Ring
12015	Sumpfring
12016	Dschungelring
12017	Prismaband
12018	Konservator-Helm
12019	Himmelblauer Talisman
12020	Thalliumhalsschmuck
12021	Schildplattensabatons
12022	Iridiumkette
12023	Tellurhalskette
12024	Vanadiumtalisman
12025	Selenitkette
12026	Quecksilberanhänger
12027	Zinnoberhalskette
12028	Basalt-Halskette
12029	Grünsteintalisman
12030	Jettkette
12031	Leitsteinhalskette
12032	Onyxhalsschmuck
12033	Juwelen der Familie Thaurissan
12034	Marmorhalskette
12035	Obsidiananhänger
12036	Granithalskette
12037	Eigenartiges Fleisch
12038	Lagraves Siegel
12039	Tundrahalskette
12040	Waldanhänger
12041	Scherwindgamaschen
12042	Marschkette
12043	Wüstenhalsschmuck
12044	Arktischer Anhänger
12045	Sumpfanhänger
12046	Dschungelhalskette
12047	Spektralhalskette
12048	Prismaanhänger
12049	Stahlschienenrüstung
12050	Hazecover-Stiefel
12051	Mutige Stulpen
12052	Ring des Mondes
12053	Vulkangesteinring
12054	Dämonenband
12055	Sternenstaubband
12056	Ring der Himmel
12057	Drachenschuppenband
12058	Dämonischer Knochenring
12059	Medaillon des Eroberers
12060	Shindrells Notiz
12061	Klinge der Abrechnung
12062	Geschickte Kampfklinge
12064	Game Master-Kapuze
12065	Barriere der Elemente
12066	Schieferhautcape
12082	Wyrmbalg-Schiftung
12083	Valconische Schärpe
12102	Ring des Aristokraten
12103	Stern von Mystaria
12104	Kraftrankentunika
12105	Panzergamaschen des Löwenmutes
12106	Felshautbrustplatte
12107	Flüsterseide-Gamaschen
12108	Basaltschuppenrüstung
12109	Azurblaue Mondamicia
12110	Regenzauberertuch
12111	Lavaplattenstulpen
12112	Gruftdämonen-Armschienen
12113	Sonnentuchcape
12114	Nachtlauerhandschuhe
12115	Wackere Umklammerung
12122	Kum'ishas Plunder
12143	Großdrachenrückgratschlüssel
12144	Eiszilloskop
12162	Pläne: Gehärtetes Eisenkurzschwert
12163	Pläne: Mondstahlbreitschwert
12164	Pläne: Massive Eisenaxt
12184	Raptorfleisch
12185	Blutsegeladmiralshut
12190	Trank des traumlosen Schlafs
12191	Schließkassette der SILBERMORGEN
12192	Schließkassette der NEBELSCHLEIER
12202	Tigerfleisch
12203	Rotes Wolfsfleisch
12204	Schweres Kodofleisch
12205	Weißes Spinnenfleisch
12206	Zartes Krebsfleisch
12207	Riesenei
12208	Zartes Wolfsfleisch
12209	Mageres Wolfsteak
12210	Gerösteter Raptor
12211	Gewürzte Wolfrippchen
12212	Dschungeleintopf
12213	Aas Surprise
12214	Eigenartiger Eintopf
12215	Schwerer Kodoeintopf
12216	Gewürzter Chilikrebs
12217	Drachenodemchili
12218	Monsteromelett
12219	Unverziertes Siegel des Aufstiegs
12220	Intakte Elementararmschiene
12223	Fleischiger Fledermausflügel
12224	Knuspriger Fledermausflügel
12225	Angel der Familie Blump
12226	Rezept: Knuspriger Fledermausflügel
12227	Rezept: Mageres Wolfsteak
12228	Rezept: Gerösteter Raptor
12229	Rezept: Scharfe Wolfrippchen
12230	Teufelswaldschleimprobe
12231	Rezept: Dschungeleintopf
12232	Rezept: Aas Surprise
12233	Rezept: Eigenartiger Eintopf
12234	Verderbte Teufelswaldprobe
12235	Un'Goro-Brühschleimer-Probe
12236	Reine Un'Goro-Probe
12237	Feine Krebsbrocken
12238	Dunkelküstenbarsch
12239	Rezept: Drachenodemchili
12240	Rezept: Schwerer Kodoeintopf
12241	Eingesammeltes Großdrachen-Ei
12242	Meereskreaturknochen
12243	Glimmende Klaue
12247	Breitklingenmesser
12248	Langdolch der Tollkühnheit
12249	Gnadenlose Axt
12250	Mitternachtsaxt
12251	Großer Stecken
12252	Stab des Schutzes
12253	Blitzendroter Umhang
12254	Gut eingeölter Umhang
12255	Bleiche Gamaschen
12256	Aschenstoffgamaschen
12257	Schwerer gekerbter Gürtel
12258	Schlangenschnallengürtel
12259	Glitzernder Stahldolch
12260	Sengende Goldklinge
12261	Pläne: Sengende Goldklinge
12262	Leerer Worgwelpenkäfig
12263	Gefangener Worgwelpe
12264	Worgtransportkorb
12282	Abgenutzte Streitaxt
12283	Brutlingessenz
12284	Draco-Incarcinatrix 900
12286	Eiszilloskop-Prototyp
12287	Kollektronisches Modul
12288	Eingeschlossener verderbter Brühschlammer
12289	Meeresschildkrötenüberreste
12291	Verschmolzene Brühschlammerprobe
12292	Seltsam markierter Kasten
12293	Feiner Goldfaden
12295	Gamaschen der Volksmiliz
12296	Funke der Volksmiliz
12299	Vernetzte Handschuhe
12300	Kugel der drachischen Energie
12301	Bambuskäfigschlüssel
12302	Zügel des Frostsäblers
12303	Zügel des Nachtsäblers
12323	Ungeschmiedetes Siegel des Aufstiegs
12324	Geschmiedetes Siegel des Aufstiegs
12325	Zügel des Urzeitleoparden
12326	Zügel der gelbbraunen Säblerkatze
12327	Zügel der goldenen Säblerkatze
12330	Horn des roten Wolfs
12334	Frosthagelsplitter
12335	Edelstein der Gluthauer
12336	Edelstein der Felsspitzoger
12337	Edelstein der Blutäxte
12339	Vaelans Gabe
12341	Obstprobe der Schwarzfelle
12342	Getreideprobe der Schwarzfelle
12343	Nussprobe der Schwarzfelle
12344	Siegel des Aufstiegs
12345	Bijous Habseligkeiten
12346	Leere Säuberungsschale
12347	Gefüllte Säuberungsschale
12349	Cliffspring-Probe
12350	Leere Probenröhre
12351	Horn des arktischen Wolfs
12352	Doomriggers Schnalle
12353	Schimmelzaumzeug
12354	Palominozaumzeug
12355	Talisman der Verderbnis
12356	Ei eines Steilhangflügeldrachen
12358	Darkstone-Schrifttafel
12359	Thoriumbarren
12360	Arkanitbarren
12361	Blauer Saphir
12363	Arkankristall
12364	Gewaltiger Smaragd
12365	Verdichteter Stein
12366	Dickes Yetifell
12367	Makelloses Yetihorn
12368	Dämmerungstrickfalle
12369	Szepter von Vectus
12382	Schlüssel zur Stadt
12383	Mondbestrahlte Feder
12384	Behälter von Mau'ari
12402	Uraltes Ei
12404	Verdichteter Wetzstein
12405	Thoriumrüstung
12406	Thoriumgürtel
12408	Thoriumarmschienen
12409	Thoriumstiefel
12410	Thoriumhelm
12411	Dritte Mosh'aru-Schrifttafel
12412	Vierte Mosh'aru-Schrifttafel
12414	Thoriumgamaschen
12415	Strahlende Brustplatte
12416	Strahlender Gürtel
12417	Strahlender Reif
12418	Strahlende Handschuhe
12419	Strahlende Stiefel
12420	Strahlende Gamaschen
12422	Imperiale Plattenrüstung
12424	Imperialer Plattengürtel
12425	Imperiale Plattenarmschienen
12426	Imperiale Plattenstiefel
12427	Imperialer Plattenhelm
12428	Imperiale Plattenschultern
12429	Imperiale Plattengamaschen
12430	E'ko eines Frostsäblers
12431	E'ko der Winterfelle
12432	E'ko eines Splitterzahns
12433	E'ko eines Wildekins
12434	E'ko einer Eiswindschimäre
12435	E'ko eines Eisdistelyetis
12436	E'ko der Frosthagelriesen
12437	Ridgewells Kiste
12438	Tinkees Brief
12440	Magic Knucklebone (DND)
12442	Charm Pouch (DND)
12443	Knucklebone Pouch (DND)
12444	Unbeschädigtes Horn einer Eiswindschimäre
12445	Felnoks Paket
12446	Anvilmar-Muskete
12447	Distelholzbogen
12448	Leichtes Jagdgewehr
12449	Primitiver Bogen
12450	Hagel des Juju
12451	Kraft des Juju
12455	Glut des Juju
12457	Kälte des Juju
12458	Arglist des Juju
12459	Flucht des Juju
12460	Macht des Juju
12462	Umarmung der Windnatter
12463	Drachenfang-Schlächter
12464	Blutfeuerkrallen
12465	Nachtlauertuch
12466	Kordel der Morgenröte
12467	Fremdartiges Ei
12468	Chiltons Zauberstab
12469	Verstümmler
12470	Sandpirscherknöchelschutz
12471	Wüstenläuferkrückstock
12472	Krakles Thermometer
12522	Bingles Flieger-Handschuhe
12524	Blaugefiedertes Amulett
12525	Jarons Laden
12527	Rippenspalter
12528	Der Hammer des Richters
12529	Glimmernetztransportkorb
12530	Spitzenspinnenei
12531	Sengnadel
12532	Spitze des Steinformers
12533	Beschlagene Pike
12534	Omokks Kopf
12535	Schicksalsträchtige Gradklinge
12542	Begräbnisfeuertracht
12543	Liedstein von Ironforge
12544	Thralls Entschlossenheit
12545	Auge von Orgrimmar
12546	Aristokratische Manschetten
12547	Mar Aloms Griff
12548	Magnis Wille
12549	Gehirnkäfig
12550	Runenverzierte Golemfesseln
12551	Steinschildumhang
12552	Wickeltuch des Schattenbanns
12553	Hurtigwandler-Stiefel
12554	Hände des erhabenen Herolds
12555	Schienbeinschützer der Kampfraserei
12556	Stiefel der Hohepriesterin
12557	Ebenstahlschiftung
12558	Blaugefiederte Halskette
12562	Wichtige Blackrockdokumente
12563	Befehl des Kriegsherren Goretooth
12564	Auftragsmordnotiz
12565	Winnas Kätzchentransportkorb
12566	Gehärtetes Fläschlein
12567	Gefülltes Fläschlein
12582	Keris von Zul'Serak
12583	Blackhand-Verdammnissäge
12584	Langschwert des Großmarschalls
12585	Medaillon von Stormwind
12586	Unreifer Giftbeutel
12587	Auge von Rend
12588	Knochenstachelschulter
12589	Staubfederschärpe
12590	Teufelsstoß
12592	Schwarzklinge von Shahram
12602	Drakonischer Deflektor
12603	Schattenhauchtunika
12604	Tiara des Sternenfeuers
12605	Serpentinschädler
12606	Kristallisierter Gurt
12607	Glänzende chromatische Schuppe
12608	Metzgerschürze
12609	Polychromatisches Visions-Wickeltuch
12610	Runenverzierte Plattenschultern
12611	Runenverzierte Plattenstiefel
12612	Runenverzierter Plattenhelm
12613	Runenverzierte Brustplatte
12614	Runenverzierte Plattengamaschen
12615	Wilde Panzertunika
12616	Wilde Panzerstiefel
12617	Wilde Panzerschultern
12618	Verzauberte Thoriumbrustplatte
12619	Verzauberte Thoriumgamaschen
12620	Verzauberter Thoriumhelm
12621	Dämonengabel
12622	Splitterzahnfleisch
12623	Fleisch einer Eiswindschimäre
12624	Wilddornpanzerung
12625	Schultern der Morgenröte
12626	Begräbnis-Manschetten
12627	Temporalversetzer
12628	Dämonengeschmiedete Brustplatte
12630	Rend Blackhands Kopf
12631	Feurige Plattenstulpen
12632	Sturmstulpen
12633	Helm der weißen Seele
12634	Beitelmalgurt
12635	Einfaches Pergament
12636	Helm des großen Häuptlings
12637	Backusarische Stulpen
12638	Andorhal-Uhr
12639	Festungsstulpen
12640	Löwenherzhelm
12641	Unverwundbarer Panzer
12642	Gesäuberte Höllenkugel
12643	Verdichteter Gewichtsstein
12644	Verdichteter Schleifstein
12645	Thoriumschildstachel
12646	Infus-Smaragd
12647	Felhas-Rubin
12648	Eingekerkerter Teufelshundgeist
12649	Eingekerkerter Höllenbestiengeist
12650	Eingestellter Dämpfer
12651	Schwarzkrähe
12652	Bijous Aufklärungsbericht
12653	Zerfetzhaken
12654	Verdammnisgeschoss
12655	Verzauberter Thoriumbarren
12662	Dämonische Rune
12663	Glyphenverzierter Eichenast
12682	Pläne: Thoriumrüstung
12683	Pläne: Thoriumgürtel
12684	Pläne: Thoriumarmschienen
12685	Pläne: Strahlender Gürtel
12687	Pläne: Imperiale Plattenschultern
12688	Pläne: Imperialer Plattengürtel
12689	Pläne: Strahlende Brustplatte
12690	Pläne: Imperiale Plattenarmschienen
12691	Pläne: Wilddornpanzerung
12692	Pläne: Thoriumschildstachel
12693	Pläne: Thoriumstiefel
12694	Pläne: Thoriumhelm
12695	Pläne: Strahlende Handschuhe
12696	Pläne: Dämonengeschmiedete Brustplatte
12697	Pläne: Strahlende Stiefel
12698	Pläne: Schultern der Morgenröte
12699	Pläne: Feurige Plattenstulpen
12700	Pläne: Imperiale Plattenstiefel
12701	Pläne: Imperialer Plattenhelm
12702	Pläne: Strahlender Reif
12703	Pläne: Sturmstulpen
12704	Pläne: Thoriumgamaschen
12705	Pläne: Imperiale Plattenrüstung
12706	Pläne: Runenverzierte Plattenschultern
12707	Pläne: Runenverzierte Plattenstiefel
12708	Crossroads Vorratskisten
12709	Pips Kürschner
12710	Leuchtendes Fleisch der Bestie
12711	Pläne: Helm der weißen Seele
12712	Waroshs Mojo
12713	Pläne: Strahlende Gamaschen
12714	Pläne: Runenverzierter Plattenhelm
12715	Pläne: Imperiale Plattengamaschen
12716	Pläne: Helm des großen Häuptlings
12717	Pläne: Löwenherzhelm
12718	Pläne: Runenverzierte Brustplatte
12719	Pläne: Runenverzierte Plattengamaschen
12720	Pläne: Festungsstulpen
12721	Glücksbringer-Hälfte
12722	Andere Glücksbringerhälfte
12723	Glücksbringer
12724	Janices Paket
12725	Pläne: Verzauberter Thoriumhelm
12726	Pläne: Verzauberte Thoriumgamaschen
12727	Pläne: Verzauberte Thoriumbrustplatte
12728	Pläne: Unverwundbarer Panzer
12730	Waroshs Rolle
12731	Makelloser Balg der Bestie
12732	Brandpulveragave
12733	Hochheiliges Frostsäblerfleisch
12734	Verzauberter scharlachroter Faden
12735	Ausgefranste Monstrositätenstickerei
12736	Frostraunens Balsamierungsflüssigkeit
12737	Düsterkraut
12738	Dalsons Plumpskloschlüssel
12739	Dalsons Schrankschlüssel
12740	Fünfte Mosh'aru-Schrifttafel
12741	Sechste Mosh'aru-Schrifttafel
12752	Kappe des scharlachroten Wissenden
12753	Schattenhaut
12756	Gamaschen von Arcana
12757	Brustplatte des Blutdurstes
12762	Geheimhaltung der Pläne
12763	Un'Goro-Ätherfrucht
12764	Thoriumgroßschwert
12765	Geheimnotiz Nr.1
12766	Geheimnotiz Nr.2
12768	Geheimnotiz Nr.3
12769	Kahlholzhacke
12770	Bijous Informationen
12771	Leeres Feuerwasserfläschchen
12772	Veredelter Thoriumhammer
12773	Verschnörkelte Thoriumhandaxt
12774	Dämmerungsschneide
12775	Gewaltige Thoriumstreitaxt
12776	Verzauberter Kampfhammer
12777	Loderflammenrapier
12778	Dokumenten-Truhe
12779	Runenschneide
12780	General Drakkisaths Befehl
12781	Beschaulichkeit
12782	Verderbnis
12783	Herzsucher
12784	Arkanitschnitter
12785	Brandpulver
12790	Arkanitchampion
12791	Barkeepers Pulle
12792	Vulkanischer Hammer
12793	Mixologen-Tunika
12794	Meisterlicher Sturmhammer
12795	Blutkralle
12796	Hammer der Titanen
12797	Frostwache
12798	Vernichter
12799	Großer Opal
12800	Azerothianischer Diamant
12802	Dunkelspeer
12803	Essenz des Lebens
12804	Mächtiges Mojo
12805	Feuerkugel
12806	Ungeschmiedete runenbedeckte Brustplatte
12807	Banner der Geißel
12808	Essenz des Untodes
12809	Wächterstein
12810	Verzaubertes Leder
12811	Rechtschaffene Kugel
12812	Ungebrannte Plattenstulpen
12813	Fläschchen mit geheimnisvollem Glibber
12814	Flaschenflamme
12815	Signalfackel
12816	Pläne: Thoriumgroßschwert
12817	Pläne: Kahlholzhacke
12818	Pläne: Veredelter Thoriumhammer
12819	Pläne: Verschnörkelte Thoriumhandaxt
12820	Feuerwasser der Winterfelle
12821	Pläne: Dämmerungsschneide
12822	Toxinschrecken-Tröpfchen
12823	Pläne: Gewaltige Thoriumstreitaxt
12824	Pläne: Verzauberter Kampfhammer
12825	Pläne: Loderflammenrapier
12826	Pläne: Runenschneide
12827	Pläne: Beschaulichkeit
12828	Pläne: Vulkanischer Hammer
12829	Kiste der Winterfelle
12830	Pläne: Verderbnis
12831	Pläne: Blutkralle
12832	Pläne: Dunkelspeer
12833	Pläne: Hammer der Titanen
12834	Pläne: Arkanitchampion
12835	Pläne: Vernichter
12836	Pläne: Frostwache
12837	Pläne: Meisterlicher Sturmhammer
12838	Pläne: Arkanitschnitter
12839	Pläne: Herzsucher
12840	Geißelstein des Dieners
12841	Geißelstein des Eindringlings
12842	Kunstlos geschriebenes Log
12843	Geißelstein des Verderbers
12844	Ehrenmarke der Argentumdämmerung
12845	Medaillon des Glaubens
12846	Anstecknadel der Argentumdämmerung
12847	Seelenbefleckte Pike
12848	Blutbefleckte Pike
12849	Dämonengeküsster Sack
12871	Chromatischer Knochenpanzer
12884	Arnaks Huf
12885	Pamelas Puppe
12886	Pamelas Puppenkopf
12887	Pamelas Puppe, linke Seite
12888	Pamelas Puppe, rechte Seite
12891	Jarons Hacke
12894	Josephs Ehering
12895	Brustplatte des chromatischen Drachenschwarms
12896	Erstes Reliktfragment
12897	Zweites Reliktfragment
12898	Drittes Reliktfragment
12899	Viertes Reliktfragment
12900	Annalen von Darrowshire
12903	Beinschützer des chromatischen Widersetzers
12904	Shawns Supersonder-Swamihut
12905	Lauffeuercape
12906	Geläutertes Mondbrunnenwasser
12907	Verderbtes Mondbrunnenwasser
12922	Leere Feldflasche
12923	Awbees Schuppe
12924	Ritualkerze
12925	Arikaras Schlangenhaut
12926	Flammenband
12927	Schultern der Treffsicherheit
12928	Umis mechanischer Yeti
12929	Talisman des glühenden Zorns
12930	Briarwood-Rohr
12935	Kriegsmeisterbeinschützer
12936	Armstützen des Schlachtgetauften
12938	Blut von Helden
12939	Dal'Rends Stammeswächter
12940	Dal'Rends hochheilige Attacke
12942	Pantherkäfigschlüssel
12945	Beinplatten des chromatischen Widersetzers
12946	Hyperkondensator-Dingsda
12947	Alex' Ring der Kühnheit
12952	Gyths Schädel
12953	Drachenaugenhelmkappe
12954	Davils Buchband
12955	Redpaths Schild
12956	Schädel von Horgus
12957	Zertrümmertes Schwert von Marduk
12958	Rezept: Arkanit transmutieren
12960	Stammeskriegsfedern
12963	Klingenmeistergamaschen
12964	Tristam-Beinschützer
12965	Geistertuchgamaschen
12966	Armschützer des schwarzen Nebels
12967	Blutmondumhang
12968	Winterzwirncape
12969	Sickernde Weide
12970	Zeremonielle Platte des Generals
12973	Scharlachrote Kanonenkugel
12974	Der schwarze Ritter
12975	Ausgrabungsleiter-Axt
12976	Verzahnte Klinge
12977	Handschuhe der Magiekraft
12978	Gürtel des Sturmbringers
12979	Flammenfluchumhang
12982	Silberverbundfußschützer
12983	Rakzurkeule
12984	Himmelrufer
12985	Ring der Verteidigung
12987	Dunkelgewirkte Bundhosen
12988	Sternensuchertunika
12989	Gargoylebiss
12990	Messers Schneide
12992	Sengklinge
12994	Thorbias' Stulpen
12996	Band der Läuterung
12997	Redbeards Wappen
12998	Magicusmantel
12999	Drachenschwingenbänder
13000	Stab von Hale Magefire
13001	Jungfernreif
13002	Fürstin Alizabeths Anhänger
13003	Lord Alexanders Streitaxt
13004	Fackel von Austen
13005	Amys Decke
13006	Masse von McGowan
13007	Magieflammenumhang
13008	Beinkleider der Talwinde
13009	Balg des Kuhkönigs
13010	Beinschützer des Traumsängers
13011	Silbergefütterter Gürtel
13012	Yorgens Armschienen
13013	Hexerältestenmantel
13014	Axt von Rin'ji
13015	Serathil
13016	Killerschredder
13017	Streitaxt des Höllenschlächters
13018	Henkerspaltbeil
13019	Harpyienklauenkurzbogen
13020	Bogen des Himmelsstürmers
13021	Einfädler
13022	Greifenflügellangbogen
13023	Echtsilber beschlagener Langbogen
13024	Beazels Berster
13025	Vorschlaghammer der Totenwaldfelle
13026	Himmelslicht
13027	Knochenknacker
13028	Blutfelshammer
13029	Umbralkristall
13030	Basiliskknochen
13031	Kugel von Mistmantle
13032	Schwert der Verderbnis
13033	Zelotenklinge
13034	Schnellstahlrapier
13035	Schlangenschnitzler
13036	Auftragsmordklinge
13037	Kristallfichtenstecher
13038	Windhauch
13039	Schädelspalterarmbrust
13040	Herzsuchende Armbrust
13041	Wächterklinge
13042	Schwert des Magistraten
13043	Klinge der Titanen
13044	Dämonentöter
13045	Zäher Hammer
13046	Blanchards Schädelbrecher
13047	Zweig des Weltbaums
13048	Drohender Hammer
13049	Claymore des Dekanats
13051	Hexenfuror
13052	Kriegstreiber
13053	Verhängnisbringer
13054	Gevatter Tod
13055	Knochenmalmer
13056	Rasender Schläger
13057	Blutpike
13058	Khoospitze
13059	Steinrabe
13060	Der Nadler
13062	Donnerholz
13063	Sternenregner
13064	Jainas Feuerteufel
13065	Zauberstab von Allistarj
13066	Wyrmtöterschiftung
13067	Hydralickrüstung
13068	Obsidianschienbeinschützer
13070	Saphirons Schuppenstiefel
13071	Plattenfaust von Hakoo
13072	Stulpen des steinernen Griffs
13073	Mugthols Helm
13074	Golemsplitter-Gamaschen
13075	Beinschützer der Düsterschwinge
13076	Riesentöterarmschienen
13077	Gurt von Uther
13079	Schild von Thorsen
13080	Witwenklammer
13081	Schild der leeren Augen
13082	Berghang-Rundschild
13083	Familienwappen der Garretts
13084	Kaleidoskopkette
13085	Halsschmuck des Horizonts
13086	Zügel des Winterspringfrostsäblers
13087	Halsschmuck des Flussgeists
13088	Gazlowes Glücksbringer
13089	Skibis Anhänger
13090	Brustplatte der Auserwählten
13091	Medaillon von Großmarschall Morris
13093	Rotglutring
13094	Das Juwel der Königin
13095	Angriffsband
13096	Hierophanten-Band
13097	Ring der Donnerbraue
13098	Schmerzenswirkerband
13099	Mokassins des Weißen Hasen
13100	Furens Stiefel
13101	Schuhe des Wolfsläufers
13102	Cassandras Anmut
13103	Polster der Giftspinne
13105	Sutarns Ring
13106	Leuchtende magische Armreifen
13107	Schädelmanschetten des Magus
13108	Tigerfellmantel
13109	Cape der schwarzen Flamme
13110	Schreckenswolfharnisch
13111	Sandalen des Aufrührers
13112	Geflügelter Helm
13113	Feathermoonkopfputz
13114	Gamaschen des Trollfluchs
13115	Schafsledermantel
13116	Schiftung der Ungesehenen
13117	Ogrons Schärpe
13118	Serpentinschärpe
13119	Verzauberte Kodoarmschienen
13120	Armschienen des tiefen Zorns
13121	Flügel des Welplings
13122	Dunkles Phantom-Cape
13123	Traumwandler-Rüstung
13124	Ravasaurusschuppenstiefel
13125	Elfenkettenstiefel
13126	Kriegsrufer-Stulpen
13127	Frosthäscherkrone
13128	Helm des Steilgipfels
13129	Feuermähnengamaschen
13130	Windläufer-Beinschützer
13131	Spiegelpanzermantel
13132	Skelettschultern
13133	Schulterklappen des Drachenfeuers
13134	Gürtel des Gladiators
13135	Fürstliche Armschützer
13136	Lil Timmys Blasrohr
13137	Eisenwirker
13138	Der Verstummer
13139	Bauchripper
13140	Blutroter Schlüssel
13141	Zahn des Gnarr
13142	Brigam-Gurt
13143	Mal des Drachenlords
13144	Beschaulichkeits-Gürtel
13145	Riesiger Ogergürtel
13146	Kugelspeiende Schrotflinte
13148	Kaltpike
13149	Eldarathischer Foliant des Beschwörens Bd. 1
13151	Die Mystikerstudien von Hor'ank
13152	Die Geschichte ohne Ende
13153	Foliant von Mal'cin Vorail
13154	Jael'marins Studien des Arkanen
13155	Widerhallender Schädel
13156	Mystikerkristall
13157	Stinkender Schädel
13158	Worte des Oberhäuptlings
13159	Knochenstaub
13161	Stab von Trindelhafen
13162	Reiverklauen
13163	Unerbittliche Sense
13164	Herz der Schuppe
13166	Schultern des heftigen Schlags
13167	Omokks Faust
13168	Platte des Schamanenkönigs
13169	Flechtmähnengamaschen
13170	Himmelstuchgamaschen
13171	Smokeys Feuerzeug
13172	Grimms Toller Tabak
13173	Flightblade-Wurfaxt
13174	Verseuchte Fleischprobe
13175	Voones Zitterbogen
13176	Geißeldaten
13177	Talisman des Entrinnens
13178	Rosenweinreif
13179	Glutbandarmschützer
13180	Heiliges Wasser von Stratholme
13181	Dämonenhauthandschuhe
13182	Phasenklinge
13183	Giftspucker
13184	Kristallnietenhandschutz
13185	Mantel des blinden Sehers
13186	Leere Flasche: Teufelssteinfeld
13187	Leere Flasche: Dalsons Tränenfeld
13188	Leere Flasche: Das trostlose Feld
13189	Leere Flasche: Gahrrons Trauerfeld
13190	Gefüllte Flasche: Teufelssteinfeld
13191	Gefüllte Flasche: Dalsons Tränenfeld
13192	Gefüllte Flasche: Das trostlose Feld
13193	Gefüllte Flasche: Gahrrons Trauerfeld
13194	Kesselschlüssel: Teufelssteinfeld
13195	Kesselschlüssel: Dalsons Tränenfeld
13196	Kesselschlüssel: Gahrrons Trauerfeld
13197	Kesselschlüssel: Das trostlose Feld
13198	Hurd-Zerkracher
13199	Crushridge-Bindungen
13202	Erweiterte Annalen von Darrowshire
13203	Armswake-Umhang
13204	Draufhauer
13205	Rhombeardbeschützer
13206	Wolfsfellgamaschen
13207	Schattenlord Fel'dans Kopf
13208	Armschützer des kahlen Heulers
13209	Siegel der Dämmerung
13210	Polster des Schreckenwolfs
13211	Wolfsklauenarmschienen
13212	Halycons Stachelhalsband
13213	Glimmernetz' Auge
13216	Krone des reuigen Sünders
13217	Band des reuigen Sünders
13218	Fangzahn der Kristallspinne
13223	Stratholme, Kurierbeutel
13243	Argentumverteidiger
13244	Güldene Stulpen
13245	Kreshs Rücken
13246	Argentumrächer
13247	Rüstmeister Zigris' Schließkiste
13248	Explosionsschuss-Arkebuse
13249	Argentumkreuzfahrer
13250	Kopf von Balnazzar
13251	Kopf von Baron Rivendare
13252	Wolkenläufer-Gurt
13253	Hände der Macht
13254	Astralwache
13255	Stulpen des Bogenmeisters
13257	Dämonische runenverzierte Schiftung
13258	Aschenlederstulpen
13259	Stahlbeschlagene Fußschützer
13260	Windtänzer-Stiefel
13261	Kugel von D'sak
13262	Aschenbringer
13282	Ogerseherturmstiefel
13283	Magusring
13284	Kampfstiefel der Pfeilschnelle
13285	Der Schwarzfelsschlitzer
13286	Rüstspalter
13287	Muster: Raptorbalgharnisch
13288	Muster: Raptorbalggürtel
13289	Egans Blaster
13302	Marktgasse, Briefkastenschlüssel
13303	Kreuzzüglerplatz, Briefkastenschlüssel
13304	Feststraße, Briefkastenschlüssel
13305	Ältestenplatz, Briefkastenschlüssel
13306	Königsplatz, Briefkastenschlüssel
13307	Ezra Grimms Briefkastenschlüssel
13308	Bauplan: Eisdeflektor
13309	Bauplan: Liebevoll hergestelltes Schießeisen
13310	Bauplan: Genaues Zielfernrohr
13311	Bauplan: Mechanischer Drachling
13313	Hochheilige Schriften der Hochgeborenen
13314	Alannas Umarmung
13317	Pfeife des elfenbeinfarbenen Raptors
13320	Arkanbeschleuniger
13321	Grüner Roboschreiter
13322	Unlackierter Roboschreiter
13323	Lila Roboschreiter
13324	Rotblauer Roboschreiter
13325	Leuchtend grüner Roboschreiter
13326	Weißer Roboschreiter Mod. A
13327	Eisblauer Roboschreiter Mod. A
13328	Schwarzer Widder
13329	Frostwidder
13330	Dereks Radieschentasche
13331	Rotes Skelettpferd
13332	Blaues Skelettpferd
13333	Braunes Skelettpferd
13334	Grünes Skelettschlachtross
13335	Zügel des Todesstreitrosses
13340	Cape des schwarzen Barons
13342	Streichelfisch, Tier
13343	Streichelstein, Tier
13344	Dracorianische Stulpen
13345	Siegel von Rivendare
13346	Roben des Erhabenen
13347	Kristall von Zin-Malor
13348	Dämonenschneide
13349	Szepter des Unheiligen
13350	Insignien der schwarzen Wache
13351	Purpurrote Hammerschmiedschürze
13352	Vosh'gajins Schlangenstein
13353	Buch der Toten
13354	Ektoplasmaresonator
13356	Somatischer Verstärker
13357	Knöcherner Aufstachler
13358	Schulterstücke der Wyrmzunge
13359	Krone der Tyrannei
13360	Gabe der Elfen-Magier
13361	Häscher der Schädelesse
13362	Brief von der Front
13363	Gemeinde-Proklamation
13364	Ezra Grimms Werbung
13365	Stadtversammlungsnotiz
13366	Geniales Spielzeug
13367	Eingepacktes Geschenk
13368	Knochenkratzer
13369	Feuerschreiter
13370	Glasartiger Fokussierer
13371	Vater Flamme
13372	Krückstock des Sklaventreibers
13373	Band des Fleisches
13374	Seelendieb-Mantel
13375	Wappen der Vergeltung
13376	Königlicher Tribunal-Umhang
13377	Miniaturkanonenkugeln
13378	Singvogelbluse
13379	Pikkolo des Flammenfeuers
13380	Willeys tragbare Haubitze
13381	Meisterkanonier-Stiefel
13382	Kanonenkugelläufer
13383	Wollwäsche des tänzelnden Spielmanns
13384	Regenbogen-Gurt
13385	Foliant des Wissens
13386	Archivar-Cape
13387	Voraussichts-Gurt
13388	Tunika des Postmeisters
13389	Beinkleider des Postmeisters
13390	Band des Postmeisters
13391	Treter des Postmeisters
13392	Siegel des Postmeisters
13393	Malowns Zerschmetterer
13394	Skuls kalte Umarmung
13395	Skuls Fingerknochenklauen
13396	Skuls garstige Berührung
13397	Steinhautgargoylecape
13398	Stiefel des Schrillers
13399	Gargoyleschredderkrallen
13400	Unterarmschienen des Sadisten
13401	Die grausame Hand von Timmy
13402	Timmys Galoschen
13403	Grimgore-Schlinge
13404	Maske des Unverziehenen
13405	Schulterstücke der Nachtheuler
13408	Seelenbrecher
13409	Tränensteinarmschienen
13422	Steinschuppenaal
13423	Steinschuppenöl
13442	Mächtiger Wuttrank
13443	Überragender Manatrank
13444	Erheblicher Manatrank
13445	Elixier der überragenden Verteidigung
13446	Erheblicher Heiltrank
13447	Elixier der Weisen
13448	Die Besitzurkunde für Caer Darrow
13450	Die Besitzurkunde für Southshore
13451	Die Besitzurkunde für Tarrens Mühle
13452	Elixier des Mungos
13453	Elixier der rohen Gewalt
13454	Großes Arkanelixier
13455	Großer Steinschildtrank
13456	Großer Frostschutztrank
13457	Großer Feuerschutztrank
13458	Großer Naturschutztrank
13459	Großer Schattenschutztrank
13460	Großer Heiligschutztrank
13461	Großer Arkanschutztrank
13462	Läuterungstrank
13463	Traumblatt
13464	Goldener Sansam
13465	Bergsilberweisling
13466	Pestblüte
13467	Eiskappe
13468	Schwarzer Lotus
13469	Kopf von Weldon Barov
13470	Kopf von Alexi Barov
13471	Die Besitzurkunde für Brill
13473	Glücksbringer der Teufelssteins
13474	Bauer Dalsons Schrotflinte
13475	Ehering der Familie Dalson
13476	Rezept: Mächtiger Wuttrank
13477	Rezept: Überragender Manatrank
13478	Rezept: Elixier der überragenden Verteidigung
13479	Rezept: Elixier der Weisen
13480	Rezept: Erheblicher Heiltrank
13481	Rezept: Elixier der rohen Gewalt
13482	Rezept: Luft zu Feuer transmutieren
13483	Rezept: Feuer zu Erde transmutieren
13484	Rezept: Erde zu Wasser transmutieren
13485	Rezept: Wasser zu Luft transmutieren
13486	Rezept: Untod zu Wasser transmutieren
13487	Rezept: Wasser zu Untod transmutieren
13488	Rezept: Leben in Erde transmutieren
13489	Rezept: Erde in Leben transmutieren
13490	Rezept: Großer Steinschildtrank
13491	Rezept: Elixier des Mungos
13492	Rezept: Läuterungstrank
13493	Rezept: Großes Arkanelixier
13494	Rezept: Großer Feuerschutztrank
13495	Rezept: Großer Frostschutztrank
13496	Rezept: Großer Naturschutztrank
13497	Rezept: Großer Arkanschutztrank
13498	Handgefertigte Meisterschmiedgamaschen
13499	Rezept: Großer Schattenschutztrank
13500	Rezept: Großer Heiligschutztrank
13501	Rezept: Erheblicher Manatrank
13502	Handgefertigter Meisterschmiedgurt
13503	Alchimistenstein
13505	Runenklinge von Baron Rivendare
13506	Fläschchen der Versteinerung
13507	Klippenbehüter Longhorns Bericht
13508	Auge von Arachnida
13509	Klammer der Voraussicht
13510	Fläschchen der Titanen
13511	Fläschchen mit destillierter Weisheit
13512	Fläschchen mit oberster Macht
13513	Fläschchen mit chromatischem Widerstand
13514	Wehklage der Banshee
13515	Ramsteins Blitzschlag
13517	Rezept: Alchimistenstein
13518	Rezept: Fläschchen der Versteinerung
13519	Rezept: Fläschchen der Titanen
13520	Rezept: Fläschchen mit destillierter Weisheit
13521	Rezept: Fläschchen mit oberster Macht
13522	Rezept: Fläschchen mit chromatischem Widerstand
13523	Das Blut Unschuldiger
13524	Schädel des brennenden Schatten
13525	Dunkel-Bindungsfinger
13526	Flammenvernarbter Gurt
13527	Lavawandler-Schienbeinschützer
13528	Twilightarmschienen der Leere
13529	Hülle von Nerub'enkan
13530	Fangdrip-Läufer
13531	Gruftpirschergamaschen
13532	Dunkelgewobene Klauen
13533	Säuregeätzte Schulterstücke
13534	Bansheefinger
13535	Coldtouch-Phantomwickeltücher
13536	Horn der Erweckung
13537	Armschienen der eisigen Kälte
13538	Schulterstücke des Windkreischers
13539	Bansheeberührung
13542	Dämonenkasten
13544	Spektrale Essenz
13545	Schalentier
13546	Blutbauchfisch
13562	Überreste von Trey Lightforge
13582	Zerglinglasso
13583	Pandahalsband
13584	Diablostein
13585	Andenken der Erinnerung
13602	Großer Zauberstein
13603	Erheblicher Zauberstein
13624	Seelengebund. Andenken
13626	Menschlicher Kopf von Ras Frostraunen
13699	Feuerstein
13700	Großer Feuerstein
13701	Erheblicher Feuerstein
13702	Verdammniskraut
13703	Kodoknochen
13704	Skelettschlüssel
13724	Angereicherter Manakeks
13725	Krastinovs Tasche der Schrecken
13752	Seelengebund. Andenken
13754	Roher glänzender Machtfisch
13755	Winterkalmar
13756	Roher Sommerbarsch
13757	Zitteraal
13758	Roher Rotkiemen
13759	Roher Nachtflossenschnapper
13760	Roher Sonnenschuppenlachs
13761	Gefrorene Eier
13810	Gesegnete Sonnenfrucht
13811	Halskette der Dämmerung
13812	Ring der Dämmerung
13813	Gesegneter Sonnenfruchtsaft
13815	Beliebige Rune
13816	Feines Langschwert
13817	Schmales Großschwert
13818	Gezackte Axt
13819	Ausbalancierte Kriegsaxt
13820	Schlagkolben
13821	Unförmiger Schlägel
13822	Stacheldolch
13823	Plumper Kriegsstab
13824	Doppellangbogen
13825	Scharfe Muskete
13842	Herbst/Winter-Morgen
13843	Herbst/Winter-Nachmittag
13844	Herbst/Winter-Abend
13845	Herbst/Winter-Nacht
13846	Frühling/Sommer-Morgen
13847	Frühling/Sommer-Nachmittag
13848	Frühling/Sommer-Abend
13849	Frühling/Sommer-Nacht
13850	Rumbleshots Munition
13851	Scharfe Wolfrippchen
13852	Befehl des obersten Kreuzzüglers
13853	Scheibe Aaswurmfleisch
13856	Runenstoffgürtel
13857	Runenstofftunika
13858	Runenstoffrobe
13860	Runenstoffumhang
13863	Runenstoffhandschuhe
13864	Runenstoffstiefel
13865	Runenstoffhose
13866	Runenstoffstirnband
13867	Runenstoffschultern
13868	Winterzwirnrobe
13869	Winterzwirntunika
13870	Winterzwirnhandschuhe
13871	Winterzwirnhose
13872	Kleinholzbündel
13873	Schlüssel zum Vorführraum
13874	Schwere Kiste
13875	Mit Eisenbeschlägen verschlossene Truhe
13881	Aufgedunsener Rotkiemen
13888	Dunkelklauenhummer
13889	Roher Weißschuppenlachs
13890	Panzerfisch
13891	Aufgedunsener Lachs
13892	Kodokombobulator
13893	Großer roher Machtfisch
13895	Formeller Dangui
13896	Dunkelgrüner Hochzeitshanbok
13897	Weißer traditioneller Hanbok
13898	Königlicher Dangui
13899	Roter traditioneller Hanbok
13900	Grüner Hochzeitshanbok
13918	Verstärkte verschlossene Truhe
13920	Gesunde Großdrachenschuppe
13926	Goldene Perle
13927	Gekochter glänzender Machtfisch
13928	Gegrillter Kalmar
13929	Scharfer geräucherter Barsch
13930	Rotkiemenfilet
13931	Nachtflossensuppe
13932	Gedünsteter Sonnenschuppenlachs
13933	Hummereintopf
13934	Machtfischsteak
13935	Gebackener Lachs
13937	Attacke des Direktors
13938	Gräuelknochengriffel
13939	Rezept: Tüpfelgelbschwanz
13940	Rezept: Gekochter glänzender Machtfisch
13941	Rezept: Rotkiemenfilet
13942	Rezept: Gegrillter Kalmar
13943	Rezept: Scharfer geräucherter Barsch
13944	Grabsteinbrustplatte
13945	Rezept: Nachtflossensuppe
13946	Rezept: Gedünsteter Sonnenschuppenlachs
13947	Rezept: Hummereintopf
13948	Rezept: Machtfischsteak
13949	Rezept: Gebackener Lachs
13950	Festschnürungs-Gurt
13951	Unterarmschienen der stählernen Schlagkraft
13952	Eisklingenaxt
13953	Stiller Fangzahn
13954	Tiefgrüne Fußpolster
13955	Steingestalt-Schultern
13956	Klammer von Andros
13957	Gargoyleschlitzer
13958	Wyrmthalaks Fesseln
13959	Omokks Umfangbändiger
13960	Herz der Satanskreatur
13961	Halycons Maulkorb
13962	Vosh'gajins Strang
13963	Voones Zwingenhandschutz
13964	Hexenklinge
13965	Blackhands Breite
13966	Mal der Tyrannei
13967	Schienbeinschützer Windhäscher
13968	Auge der Bestie
13969	Armstützen der Lichtwacht
13982	Kriegsklinge von Caer Darrow
13983	Grabsteinkriegsaxt
13984	Froststachel
13986	Krone von Caer Darrow
14002	Starkwache von Darrowshire
14022	Barov-Arbeiterrufer
14023	Barov-Arbeiterrufer
14024	Schreckenskralle
14025	Mystikergürtel
14042	Aschenstoffweste
14043	Aschenstoffhandschuhe
14044	Aschenstoffumhang
14045	Aschenstoffhose
14046	Runenstofftasche
14047	Runenstoff
14048	Runenstoffballen
14062	Kodoreittier
14083	Tyrandes Stab
14086	Perlensandalen
14087	Perlenmanschetten
14088	Perlenumhang
14089	Perlenhandschuhe
14090	Perlenkniehosen
14091	Perlenrobe
14093	Perlenkordel
14094	Perlenwickeltücher
14095	Eingeborenenbänder
14096	Eingeborenenweste
14097	Eingeborenenhose
14098	Eingeborenenumhang
14099	Eingeborenenschärpe
14100	Hellstoffrobe
14101	Hellstoffhandschuhe
14102	Eingeborenenhandlappen
14103	Hellstoffumhang
14104	Hellstoffhose
14106	Teufelsstoffrobe
14107	Teufelsstoffhose
14108	Teufelsstoffstiefel
14109	Eingeborenenrobe
14110	Eingeborenensandalen
14111	Teufelsstoffkapuze
14112	Teufelsstoffschultern
14113	Ureinwohnerschärpe
14114	Ureinwohnerfußlappen
14115	Ureinwohnerbänder
14116	Ureinwohnercape
14117	Ureinwohnerhandschuhe
14119	Ureinwohnerlendenschurz
14120	Ureinwohnerrobe
14121	Ureinwohnerweste
14122	Rituelle Bänder
14123	Rituelles Cape
14124	Rituelle Handschuhe
14125	Ritual-Gamaschen
14126	Rituelle Amicia
14127	Ritualtuch
14128	Hexerzwirnrobe
14129	Ritual-Sandalen
14130	Hexerzwirnturban
14131	Ritueller Gürtel
14132	Hexerzwirngamaschen
14133	Ritual-Tunika
14134	Umhang des Feuers
14136	Robe der Winternacht
14137	Mondstoffgamaschen
14138	Mondstoffweste
14139	Mondstoffschultern
14140	Mondstoffreif
14141	Geisterzwirnweste
14142	Geisterzwirnhandschuhe
14143	Geisterzwirngürtel
14144	Geisterzwirnhose
14145	Verfluchte Teufelsklinge
14146	Handschuhe der Zauberbeherrschung
14147	Höhlenbewohner-Armschienen
14148	Kristallene Manschetten
14149	Unterirdisches Cape
14150	Robe der Hervorrufung
14151	Singende Klinge
14152	Robe des Erzmagiers
14153	Robe der Leere
14154	Trachten des wahren Glaubens
14155	Mondstofftasche
14156	Bodenlose Tasche
14157	Heiden-Mantel
14158	Heiden-Weste
14159	Heiden-Schuhe
14160	Heiden-Bänder
14161	Heiden-Cape
14162	Heiden-Fäustlinge
14163	Heiden-Wickeltücher
14164	Heiden-Gürtel
14165	Heidenknie-Hosen
14166	Bukanier-Armschienen
14167	Bukanier-Cape
14168	Bukanier-Handschuhe
14169	Ureinwohnerschulterpolster
14170	Bukanier-Mantel
14171	Bukanier-Hose
14172	Bukanier-Roben
14173	Bukanier-Kordel
14174	Bukanier-Stiefel
14175	Bukanier-Weste
14176	Hüterstiefel
14177	Hütermanschetten
14178	Hüterkappe
14179	Hüterscape
14180	Hüterwams
14181	Hüterhandlappen
14182	Hütermantel
14183	Hütergamaschen
14184	Hüterroben
14185	Hütersattelgurt
14186	Regenmachermantel
14187	Regenmachermanschetten
14188	Regenmacherumhang
14189	Regenmacherkappe
14190	Regenmacherweste
14191	Regenmacherfäustlinge
14192	Regenmacherrobe
14193	Regenmacherhose
14194	Regenmacherkordel
14195	Regenmacherstiefel
14196	Distelfellsandalen
14197	Distelfellbänder
14198	Distelfellumhang
14199	Distelfellhandschuhe
14200	Distelfellkappe
14201	Distelfellmantel
14202	Distelfellwams
14203	Distelfellhose
14204	Distelfellrobe
14205	Distelfellgürtel
14206	Vitale Armreifen
14207	Vitale Gamaschen
14208	Vitales Stirnband
14209	Vitale Schärpe
14210	Vitales Cape
14211	Vitale Handlappen
14212	Vitale Schultern
14213	Vitale Gewandung
14214	Vitale Stiefel
14215	Vitale Tunika
14216	Geomantenwams
14217	Geomantenkordel
14218	Geomantenstiefel
14219	Geomantenumhang
14220	Geomantenkappe
14221	Geomantenarmschienen
14222	Geomantenhandschuhe
14223	Geomantenschiftung
14224	Geomantenbeinkleider
14225	Geomantenwickeltücher
14226	Glutseidenarmreifen
14227	Eisenweberseide
14228	Glutseidenkronenreif
14229	Glutseidenumhang
14230	Glutseidentunika
14231	Glutseidenfäustlinge
14232	Glutseidenmantel
14233	Glutseidengamaschen
14234	Glutseidenroben
14235	Glutseidenkordel
14236	Glutseidenstiefel
14237	Graunebelrüstung
14238	Graunebelstiefel
14239	Graunebelcape
14240	Graunebelbänder
14241	Graunebelhandschützer
14242	Graunebelhose
14243	Graunebelmantel
14244	Graunebelwickeltücher
14245	Graunebelgurt
14246	Graunebelhexerhut
14247	Lunarmantel
14248	Lunarbindungen
14249	Lunarweste
14250	Lunarschuhe
14251	Lunarumhang
14252	Lunarkronenreif
14253	Lunarhandlappen
14254	Lunargewandung
14255	Lunargürtel
14256	Teufelsstoff
14257	Lunargamaschen
14258	Blutgewebte Kordel
14259	Blutgewebte Stiefel
14260	Blutgewebte Armschienen
14261	Blutgewebter Umhang
14262	Blutgewebte Fäustlinge
14263	Blutgewebte Maske
14264	Blutgewebte Hose
14265	Blutgewebte Wickeltücher
14266	Blutgewebte Polster
14267	Blutgewebtes Wams
14268	Gaeas Manschetten
14269	Gaeas Schuhe
14270	Gaeas Umhang
14271	Gaeas Reif
14272	Gaeas Handlappen
14273	Gaeas Amicia
14274	Gaeas Gamaschen
14275	Gaeas Gewandung
14276	Gaeas Gürtel
14277	Gaeas Tunika
14278	Opulenter Mantel
14279	Opulente Armschienen
14280	Opulentes Cape
14281	Opulente Krone
14282	Opulente Handschuhe
14283	Opulente Gamaschen
14284	Opulente Roben
14285	Opulente Stiefel
14286	Opulenter Gürtel
14287	Opulente Tunika
14288	Arachnidenrüstung
14289	Arachnidengurt
14290	Arachnidenfußpolster
14291	Arachnidenarmreifen
14292	Arachnidencape
14293	Arachnidenreif
14294	Arachnidenhandschuhe
14295	Arachnidenbeinschützer
14296	Arachnidenschulterstücke
14297	Arachnidenroben
14298	Knochenwerfers Schiftung
14299	Knochenwerfers Stiefel
14300	Knochenwerfers Cape
14301	Knochenwerfers Bindungen
14302	Knochenwerfers Handschuhe
14303	Knochenwerfers Tuch
14304	Knochenwerfers Gürtel
14305	Knochenwerfers Sarong
14306	Knochenwerfers Weste
14307	Knochenwerfers Krone
14308	Himmlische Tunika
14309	Himmlischer Gürtel
14310	Himmlische Schuhe
14311	Himmlische Bindungen
14312	Himmlische Krone
14313	Himmlisches Cape
14314	Himmlische Handlappen
14315	Himmlischer Kilt
14316	Himmlische Schulterstücke
14317	Himmlische Seidenroben
14318	Prächtige Tunika
14319	Prächtige Stiefel
14320	Prächtige Armreifen
14321	Prächtiger Umhang
14322	Prächtiger Reif
14323	Prächtige Stulpen
14324	Prächtiger Sarong
14325	Prächtige Schulterklappen
14326	Prächtige Roben
14327	Prächtiger Gürtel
14328	Ewiger Brustschutz
14329	Ewige Stiefel
14330	Ewige Bindungen
14331	Ewiger Umhang
14332	Ewige Krone
14333	Ewige Handschuhe
14334	Ewiger Sarong
14335	Ewige Schiftung
14336	Ewige Wickeltücher
14337	Ewige Kordel
14338	Leere Wasserröhre
14339	Mondbrunnenwasserröhre
14340	Lichroben der Eiskälte
14341	Runenfaden
14342	Mondstoff
14343	Kleiner glänzender Splitter
14344	Großer glänzender Splitter
14364	Mystikerschuhe
14365	Mystikercape
14366	Mystikerarmreifen
14367	Mystikerhandschuhe
14368	Mystikerschulterpolster
14369	Mystikerwickeltuch
14370	Mystikerwollwäsche
14371	Mystikerrobe
14372	Blutbadrüstung
14373	Blutbadgürtel
14374	Blutbadsandalen
14375	Blutbadmanschetten
14376	Blutbadcape
14377	Blutbadhandlappen
14378	Blutbadmantel
14379	Blutbadbeinkleider
14380	Blutbadrobe
14381	Grimmtotemranzen
14382	Haltbarkeitsbrustharnisch
14383	Haltbarkeitsarmschienen
14384	Haltbarkeitsstiefel
14385	Haltbarkeitsumhang
14386	Haltbarkeitshut
14387	Haltbarkeitshandschuhe
14388	Haltbarkeitsgamaschen
14389	Haltbarkeitsschulterpolster
14390	Haltbarkeitsgürtel
14391	Haltbarkeitsschwert
14392	Haltbarkeitsstab
14393	Haltbarkeitsschild
14394	Haltbarkeitsbogen
14395	Schattenzauber
14396	Zauberformeln aus dem Nether
14397	Widerstandsfähiger Mantel
14398	Widerstandsfähige Tunika
14399	Widerstandsfähige Stiefel
14400	Widerstandsfähiges Cape
14401	Widerstandsfähige Kappe
14402	Widerstandsfähige Bänder
14403	Widerstandsfähiger Handschutz
14404	Widerstandsfähige Gamaschen
14405	Widerstandsfähige Robe
14406	Widerstandsfähige Kordel
14407	Steinstoffweste
14408	Steinstoffstiefel
14409	Steinstoffcape
14410	Steinstoffreif
14411	Steinstoffhandschuhe
14412	Steinstoffschulterklappen
14413	Steinstoffrobe
14414	Steinstoffgürtel
14415	Steinstoffkniehosen
14416	Steinstoffbindungen
14417	Seidensandtunika
14418	Seidensandstiefel
14419	Seidensandarmschienen
14420	Seidensandcape
14421	Seidensandreif
14422	Seidensandhandschuhe
14423	Seidensandschulterpolster
14424	Seidensandbeinwickel
14425	Seidensandwickeltücher
14426	Seidensandgurt
14427	Wickeltücher des Windhetzers
14428	Fußpolster des Windhetzers
14429	Manschetten des Windhetzers
14430	Umhang des Windhetzers
14431	Handschützer des Windhetzers
14432	Amicia des Windhetzers
14433	Wollwäsche des Windhetzers
14434	Roben des Windhetzers
14435	Sattelgurt des Windhetzers
14436	Kronenreif des Windhetzers
14437	Giftschleierweste
14438	Giftschleierstiefel
14439	Giftschleierarmschützer
14440	Giftschleiercape
14441	Giftschleiermaske
14442	Giftschleierfäustlinge
14443	Giftschleiermantel
14444	Giftschleiergamaschen
14445	Giftschleierseidenroben
14446	Giftschleiergürtel
14447	Hochgeborenenfußpolster
14448	Hochgeborenenarmreifen
14449	Hochgeborenenkrone
14450	Hochgeborenenumhang
14451	Hochgeborenenhandschuhe
14452	Hochgeborenenschulterstücke
14453	Hochgeborenenroben
14454	Hochgeborenenkordel
14455	Gefütterte Hochgeborenenrüstung
14456	Elunarische Weste
14457	Elunarische Manschetten
14458	Elunarische Stiefel
14459	Elunarischer Umhang
14460	Elunarisches Diadem
14461	Elunarischer Handschutz
14462	Elunarischer Sarong
14463	Elunarische Schiftung
14464	Elunarische Seidenroben
14465	Elunarischer Gürtel
14466	Muster: Winterzwirntunika
14467	Muster: Winterzwirnrobe
14468	Muster: Runenstofftasche
14469	Muster: Runenstoffrobe
14470	Muster: Runenstofftunika
14471	Muster: Aschenstoffweste
14472	Muster: Runenstoffumhang
14473	Muster: Geisterzwirngürtel
14474	Muster: Winterzwirnhandschuhe
14476	Muster: Aschenstoffhandschuhe
14477	Muster: Geisterzwirnhandschuhe
14478	Muster: Hellstoffrobe
14479	Muster: Hellstoffhandschuhe
14480	Muster: Geisterzwirnweste
14481	Muster: Runenstoffhandschuhe
14482	Muster: Aschenstoffumhang
14483	Muster: Teufelsstoffhose
14484	Muster: Hellstoffumhang
14485	Muster: Hexerzwirngamaschen
14486	Muster: Umhang des Feuers
14487	Knochenfrosthammer
14488	Muster: Runenstoffstiefel
14489	Muster: Winterzwirnhose
14490	Muster: Aschenstoffhose
14491	Muster: Runenstoffhose
14492	Muster: Teufelsstoffstiefel
14493	Muster: Robe der Winternacht
14494	Muster: Hellstoffhose
14495	Muster: Geisterzwirnhose
14496	Muster: Teufelsstoffkapuze
14497	Muster: Mondstoffgamaschen
14498	Muster: Runenstoffstirnband
14499	Muster: Mondstofftasche
14500	Muster: Hexerzwirnrobe
14501	Muster: Mondstoffweste
14502	Frostbiss-Gurt
14503	Todesklammer
14504	Muster: Runenstoffschultern
14505	Muster: Hexerzwirnturban
14506	Muster: Teufelsstoffrobe
14507	Muster: Mondstoffschultern
14508	Muster: Teufelsstoffschultern
14509	Muster: Mondstoffreif
14510	Muster: Bodenlose Tasche
14511	Muster: Handschuhe der Zauberbeherrschung
14512	Muster: Trachten des wahren Glaubens
14513	Muster: Robe des Erzmagiers
14514	Muster: Robe der Leere
14522	Mahlstrom-Gamaschen
14523	Dämonenhacke
14525	Knochengriffstulpen
14526	Muster: Mondstoff
14528	Schädelknochenschild
14529	Runenstoffverband
14530	Schwerer Runenstoffverband
14531	Gräuelschaft
14536	Knochenbundhalsberge
14537	Schienbeinschützer des Leichenglanzes
14538	Todeswandler-Mantel
14539	Knochenringhelm
14540	Herz von Taragaman dem Hungerleider
14541	Schwert der Familie Barov
14542	Kravels Kiste
14543	Handschuhe der dunklen Schatten
14544	Insignien des Lieutenants
14545	Geistergamaschen
14546	Roons Kodohorn
14547	Hand von Iruxos
14548	Königliche Kappen-Schiftung
14549	Stiefel der Vermeidung
14550	Klingenbann-Armschützer
14551	Handschützer des Klingenmeisters
14552	Palisadenschulterstücke
14553	Schärpe der Gnade
14554	Beinplatten des Wolkenbehüters
14555	Alcors Sonnenschneide
14557	Das Löwenhorn von Stormwind
14558	Fürstin Mayes Anhänger
14559	Schärpe des Ausgrabungsleiters
14560	Stiefel des Ausgrabungsleiters
14561	Manschetten des Ausgrabungsleiters
14562	Brustharnisch des Ausgrabungsleiters
14563	Ausgrabungsleiter-Umhang
14564	Fäustlinge des Ausgrabungsleiters
14565	Wollwäsche des Ausgrabungsleiters
14566	Polster des Ausgrabungsleiters
14567	Borstenledergürtel
14568	Borstenlederstiefel
14569	Borstenlederbindungen
14570	Borstenlederbrustschutz
14571	Borstenledercape
14572	Borstenlederhandschuhe
14573	Borstenlederamicia
14574	Borstenlederkniehosen
14576	Ebenholzheft von Marduk
14577	Schädelstaubhose
14578	Dokebi-Kordel
14579	Dokebi-Stiefel
14580	Dokebi-Armschienen
14581	Dokebi-Brustschutz
14582	Dokebi-Cape
14583	Dokebi-Handschuhe
14584	Dokebi-Hut
14585	Dokebi-Gamaschen
14587	Dokebi-Mantel
14588	Falkenauges Kordel
14589	Falkenauges Schuhe
14590	Falkenauges Armschienen
14591	Falkenauges Helm
14592	Falkenauges Tunika
14593	Falkenauges Umhang
14594	Falkenauges Handschuhe
14595	Falkenauges Bundhosen
14596	Falkenauges Schulterklappen
14598	Aufsehergürtelbund
14599	Aufseherfußpolster
14600	Aufsehergelenkbänder
14601	Aufseherwickeltücher
14602	Aufseherumhang
14603	Aufsehermantel
14604	Aufseherhexerhut
14605	Aufseherwollwäsche
14606	Aufseherhandschuhe
14607	Falkenauges Rundschild
14608	Dokebi-Rundschild
14610	Arajs Skarabäus
14611	Blutpanzerhalsberge
14612	Blutpanzerbeinschützer
14613	Taelans Hammer
14614	Blutpanzergürtel
14615	Blutpanzerstulpen
14616	Blutpanzerstiefel
14617	Sägeknochens Hemd
14619	Skelettfragmente
14620	Gurt des Totenwächters
14621	Sabatons des Totenwächters
14622	Stulpen des Totenwächters
14623	Beinschützer des Totenwächters
14624	Brustplatte des Totenwächters
14625	Symbol der verlorenen Ehre
14626	Robe des Totenbeschwörers
14627	Muster: Hellgelbes Hemd
14628	Magieerfüllte Skelettfragmente
14629	Manschetten des Totenbeschwörers
14630	Muster: Verzaubererkutte
14631	Stiefel des Totenbeschwörers
14632	Gamaschen des Totenbeschwörers
14633	Mantel des Totenbeschwörers
14634	Rezept: Frostöl
14635	Muster: Edelsteinbesetzter Ledergürtel
14636	Leichenhafter Gürtel
14637	Leichenhafte Rüstung
14638	Leichenhafte Gamaschen
14639	Bauplan: Schwacher Rekombobulator
14640	Leichenhafte Handschuhe
14641	Leichenhafte Gänger
14644	Skelettschlüsselform
14645	Unvollendeter Skelettschlüssel
14646	Nordhaingeschenkgutschein
14647	Coldridgetal-Geschenkgutschein
14648	Shadowglen-Geschenkgutschein
14649	'Tal der Prüfungen'-Geschenkgutschein
14650	Camp Narache-Geschenkgutschein
14651	Deathknell-Geschenkgutschein
14652	Skorpashischärpe
14653	Skorpashischuhe
14654	Skorpashigelenkbänder
14655	Skorpashibrustplatte
14656	Skorpashicape
14657	Skorpashihandschuhe
14658	Skorpashischädelkappe
14659	Skorpashigamaschen
14660	Skorpashischulterpolster
14661	Bewahrer-Kordel
14662	Bewahrer-Hufe
14663	Bewahrer-Bindungen
14664	Bewahrer-Rüstung
14665	Bewahrer-Umhang
14666	Bewahrer-Handschuhe
14667	Bewahrer-Kranz
14668	Bewahrer-Wollwäsche
14669	Bewahrer-Mantel
14670	Rudellord-Rüstung
14671	Rudellord-Stiefel
14672	Rudellord-Bänder
14673	Rudellord-Cape
14674	Rudellord-Gurt
14675	Rudellord-Handschuhe
14676	Rudellord-Heiligenschein
14677	Rudellord-Hose
14678	Rudellord-Schulterstücke
14679	Von Liebe und Familie
14680	Unbeugsame Weste
14681	Unbeugsame Stiefel
14682	Unbeugsame Armschützer
14683	Unbeugsamer Umhang
14684	Unbeugsamer Gürtel
14685	Unbeugsame Stulpen
14686	Unbeugsamer Kopfputz
14687	Unbeugsame Gamaschen
14688	Unbeugsame Schulterklappen
14722	Kriegsbemalungsknöchelwickel
14723	Kriegsbemalungsbindungen
14724	Kriegsbemalungsumhang
14725	Kriegsbemalungsgürtelbund
14726	Kriegsbemalungshandschuhe
14727	Kriegsbemalungsbeinschützer
14728	Kriegsbemalungsschulterpolster
14729	Kriegsbemalungsschild
14730	Kriegsbemalungsbrustharnisch
14742	Titanische Stiefel
14743	Titanische Bänder
14744	Titanischer Brustschutz
14745	Titanischer Umhang
14746	Titanischer Gürtel
14747	Titanische Stulpen
14748	Titanische Gamaschen
14749	Titanische Schiftung
14750	Tötermanschetten
14751	Töterübermantel
14752	Tötercape
14753	Töterschädelkappe
14754	Töterhandschuhe
14755	Töterschärpe
14756	Töterschuhe
14757	Töterhose
14758	Töterschulterpolster
14759	Ausdauernde Armschienen
14760	Ausdauernde Brustplatte
14761	Ausdauernder Gürtel
14762	Ausdauernde Stiefel
14763	Ausdauerndes Cape
14764	Ausdauernde Stulpen
14765	Ausdauernder Reif
14766	Ausdauernde Bundhosen
14767	Ausdauernde Schulterstücke
14768	Verheererrüstung
14769	Verheerersandalen
14770	Verheererarmschützer
14771	Verheererumhang
14772	Verheererhandlappen
14773	Verheererkordel
14774	Verheererkrone
14775	Verheererwollwäsche
14776	Verheerermantel
14777	Verheererschild
14778	Khans Binden
14779	Khans Brustharnisch
14780	Khans Rundschild
14781	Khans Umhang
14782	Khans Handschuhe
14783	Khans Gürtel
14784	Khans Schienbeinschützer
14785	Khans Helm
14786	Khans Beinschützer
14787	Khans Mantel
14788	Beschützerarmschützer
14789	Beschützerbrustplatte
14790	Beschützerrundschild
14791	Beschützercape
14792	Beschützerstulpen
14793	Beschützergürtelbund
14794	Beschützerknöchelschutz
14795	Beschützerhelm
14796	Beschützerbeinschützer
14797	Beschützerpolster
14798	Kampfrauschbrustplatte
14799	Kampfrauschstiefel
14800	Kampfrauschrundschild
14801	Kampfrauschcape
14802	Kampfrauschstulpen
14803	Kampfrauschgürtel
14804	Kampfrauschhelm
14805	Kampfrauschkniehosen
14806	Kampfrauschschulterklappen
14807	Kampfrauscharmreifen
14808	Kriegsschlaggürtel
14809	Kriegsschlagsabatons
14810	Kriegsschlagarmsplinte
14811	Kriegsschlagbrustschutz
14812	Kriegsschlagrundschild
14813	Kriegsschlagcape
14814	Kriegsschlaghelm
14815	Kriegsschlagstulpen
14816	Kriegsschlagbeinschützer
14817	Kriegsschlagschulterpolster
14821	Symbolbrustplatte
14825	Symbolwappen
14826	Symbolstulpen
14827	Symbolgürtel
14828	Symbolschienbeinschützer
14829	Symbolbeinplatten
14830	Symbolschulterstücke
14831	Symbolkrone
14832	Symbolunterarmschienen
14833	Stulpen des Tyrannen
14834	Armschützer des Tyrannen
14835	Brustharnisch des Tyrannen
14838	Gürtel des Tyrannen
14839	Schienbeinschützer des Tyrannen
14840	Beinplatten des Tyrannen
14841	Schulterklappen des Tyrannen
14842	Schild des Tyrannen
14843	Helm des Tyrannen
14844	Sonnenschuppenbrustschutz
14846	Sonnenschuppenstulpen
14847	Sonnenschuppengürtel
14848	Sonnenschuppensabatons
14849	Sonnenschuppenhelm
14850	Sonnenschuppenbeinplatten
14851	Sonnenschuppenschiftung
14852	Sonnenschuppenschild
14853	Sonnenschuppenhandgelenksschutz
14854	Brustplatte des Vorposten
14855	Stulpen des Vorposten
14856	Gurt des Vorposten
14857	Sabatons des Vorposten
14858	Kopfputz des Vorposten
14859	Beinplatten des Vorposten
14860	Schulterstücke des Vorposten
14861	Unterarmschienen des Vorposten
14862	Kriegsanführer-Brustplatte
14863	Kriegsanführer-Stulpen
14864	Kriegsanführer-Gürtel
14865	Kriegsanführer-Schienbeinschützer
14866	Kriegsanführer-Krone
14867	Kriegsanführer-Gamaschen
14868	Kriegsanführer-Schultern
14869	Kriegsanführer-Armschienen
14872	Tirions Geschenk
14894	Lilienwurzel
14895	Salzsteinübermantel
14896	Salzsteinsabatons
14897	Salzsteinstulpen
14898	Salzsteingurt
14899	Salzsteinhelm
14900	Salzsteinbeinplatten
14901	Salzsteinschulterpolster
14902	Salzsteinschild
14903	Salzsteinarmsplinte
14904	Derbe Brustplatte
14905	Derbe Stulpen
14906	Derber Gürtel
14907	Derber Helm
14908	Derbe Beinschützer
14909	Derbe Schultern
14910	Derbe Armschützer
14911	Derbe Stiefel
14912	Derber Schild
14913	Jadeschienbeinschützer
14914	Jadearmschienen
14915	Jadebrustplatte
14916	Jadedeflektor
14917	Jadestulpen
14918	Jadegürtel
14919	Jadereif
14920	Jadebeinplatten
14921	Jadeschulterklappen
14922	Festliche Sabatons
14923	Festliche Armschützer
14924	Festliche Brustplatte
14925	Festlicher Helm
14926	Festliche Stulpen
14927	Festlicher Gürtel
14928	Festliche Beinschützer
14929	Festliche Schulterpolster
14930	Festlicher Schild
14931	Heldenhafte Rüstung
14932	Heldenhafte Schienbeinschützer
14933	Heldenhafte Stulpen
14934	Heldenhafter Gurt
14935	Heldenhafte Schädelkappe
14936	Heldenhafte Beinplatten
14937	Heldenhafte Schulterstücke
14938	Heldenhafte Armschienen
14939	Kriegshetzerbrustschutz
14940	Kriegshetzersabatons
14941	Kriegshetzerarmsplinte
14942	Kriegshetzerstulpen
14943	Kriegshetzergürtel
14944	Kriegshetzerkrone
14945	Kriegshetzerbeinschützer
14946	Kriegshetzerschiftung
14947	Kriegshetzerschild
14948	Blutgeschmiedeter Brustharnisch
14949	Blutgeschmiedete Stulpen
14950	Blutgeschmiedeter Gürtel
14951	Blutgeschmiedete Sabatons
14952	Blutgeschmiedeter Helm
14953	Blutgeschmiedete Beinplatten
14954	Blutgeschmiedeter Schild
14955	Blutgeschmiedete Schulterpolster
14956	Blutgeschmiedete Bindungen
14957	Oberhäuptling-Sabatons
14958	Oberhäuptling-Rüstung
14959	Oberhäuptling-Stulpen
14960	Oberhäuptling-Gürtel
14961	Oberhäuptling-Krone
14962	Oberhäuptling-Beinschützer
14963	Oberhäuptling-Schulterstücke
14964	Oberhäuptling-Schild
14965	Oberhäuptling-Bindungen
14966	Glorreiche Brustplatte
14967	Glorreiche Stulpen
14968	Glorreicher Gürtel
14969	Glorreicher Kopfputz
14970	Glorreiche Beinplatten
14971	Glorreiche Schulterpolster
14972	Glorreiche Sabatons
14973	Glorreicher Schild
14974	Glorreiche Bindungen
14975	Erhabener Harnisch
14976	Erhabene Stulpen
14977	Erhabener Gurt
14978	Erhabene Sabatons
14979	Erhabener Helm
14980	Erhabene Beinplatten
14981	Erhabene Schulterklappen
14982	Erhabener Schild
14983	Erhabene Armsplinte
15002	Nimboyas Pike
15003	Urzeitlicher Gürtel
15004	Urzeitliche Stiefel
15005	Urzeitliche Bänder
15006	Urzeitlicher Rundschild
15007	Urzeitliches Cape
15008	Urzeitliche Fäustlinge
15009	Urzeitliche Gamaschen
15010	Urzeitliche Wickeltücher
15011	Werwolf-Kordel
15012	Werwolf-Schuhe
15013	Werwolf-Manschetten
15014	Werwolf-Rundschild
15015	Werwolf-Umhang
15016	Werwolf-Handlappen
15017	Werwolf-Gamaschen
15018	Werwolf-Weste
15019	Werwolf-Mantel
15042	Leerer Termitenkrug
15043	Pestland-Termiten
15044	Fass mit Pestland-Termiten
15045	Grüne Drachenschuppenbrustplatte
15046	Grüne Drachenschuppengamaschen
15047	Rote Drachenschuppenbrustplatte
15048	Blaue Drachenschuppenbrustplatte
15049	Blaue Drachenschuppenschultern
15050	Schwarze Drachenschuppenbrustplatte
15051	Schwarze Drachenschuppenschultern
15052	Schwarze Drachenschuppengamaschen
15053	Vulkanische Brustplatte
15054	Vulkanische Gamaschen
15055	Vulkanische Schultern
15056	Sturmschleierrüstung
15057	Sturmschleierhose
15058	Sturmschleierschultern
15059	Lebendige Brustplatte
15060	Lebendige Gamaschen
15061	Lebendige Schultern
15062	Teufelssauriergamaschen
15063	Teufelssaurierstulpen
15064	Kriegsbärenharnisch
15065	Kriegsbärenwollwäsche
15066	Eisenfederbrustplatte
15067	Eisenfederschultern
15068	Frostsäblertunika
15069	Frostsäblergamaschen
15070	Frostsäblerhandschuhe
15071	Frostsäblerstiefel
15072	Schimärengamaschen
15073	Schimärenstiefel
15074	Schimärenhandschuhe
15075	Schimärenweste
15076	Schwere Skorpidweste
15077	Schwere Skorpidarmschienen
15078	Schwere Skorpidstulpen
15079	Schwere Skorpidgamaschen
15080	Schwerer Skorpidhelm
15081	Schwere Skorpidschultern
15082	Schwerer Skorpidgürtel
15083	Tückische Lederstulpen
15084	Tückische Lederarmschienen
15085	Tückische Lederrüstung
15086	Tückisches Lederstirnband
15087	Tückische Lederhose
15088	Tückischer Ledergürtel
15090	Runenverzierte Lederrüstung
15091	Runenverzierte Lederstulpen
15092	Runenverzierte Lederarmschienen
15093	Runenverzierter Ledergürtel
15094	Runenverziertes Lederstirnband
15095	Runenverzierte Lederhose
15096	Runenverzierte Lederschultern
15102	Geprüfte Un'Goro-Probe
15103	Verderbte geprüfte Probe
15104	Schwingenstiefel
15105	Stab von Noh'Orahil
15106	Stab von Dar'Orahil
15107	Kugel von Noh'Orahil
15108	Kugel von Dar'Orahil
15109	Stab von Soran'ruk
15110	Starrer Gürtel
15111	Starre Mokassins
15112	Starre Armreifen
15113	Starrer Rundschild
15114	Starres Cape
15115	Starre Handschuhe
15116	Starre Schultern
15117	Starre Gamaschen
15118	Starre Tunika
15119	Hochgeborenenhose
15120	Robuster Gurt
15121	Robuste Stiefel
15122	Robuste Armschienen
15123	Robuster Rundschild
15124	Robuster Umhang
15125	Robuste Handschuhe
15126	Robuste Gamaschen
15127	Robuste Schultern
15128	Robuste Tunika
15129	Robuster Helm
15130	Halsabschneider-Weste
15131	Halsabschneider-Stiefel
15132	Halsabschneider-Armschützer
15133	Halsabschneider-Rundschild
15134	Halsabschneider-Hut
15135	Halsabschneider-Cape
15136	Halsabschneider-Gürtel
15137	Halsabschneider-Fäustlinge
15138	Onyxiaschuppenumhang
15139	Halsabschneider-Hose
15140	Halsabschneider-Mantel
15141	Onyxiaschuppenbrustplatte
15142	Geistwandlerstiefel
15143	Geistwandlerbindungen
15144	Geistwandlerlumpen
15145	Geistwandlerrundschild
15146	Geistwandlerkrone
15147	Geistwandlerumhang
15148	Geistwandlergürtel
15149	Geistwandlerhandschuhe
15150	Geistwandlerpolster
15151	Geistwandlerbeinschützer
15152	Nächtliche Schuhe
15153	Nächtlicher Umhang
15154	Nächtliche Schärpe
15155	Nächtliche Handschuhe
15156	Nächtliche Kappe
15157	Nächtliche Gamaschen
15158	Nächtliche Schulterpolster
15159	Nächtliche Tunika
15160	Nächtliche Gelenkbänder
15161	Imposanter Gürtel
15162	Imposante Stiefel
15163	Imposante Armschienen
15164	Imposante Weste
15165	Imposantes Cape
15166	Imposante Handschuhe
15167	Imposantes Kopftuch
15168	Imposante Hose
15169	Imposante Schultern
15170	Potente Rüstung
15171	Potente Stiefel
15172	Potente Bänder
15173	Potentes Cape
15174	Potente Handschuhe
15175	Potenter Helm
15176	Potente Hose
15177	Potente Schultern
15178	Potenter Gürtel
15179	Gefütterte Prätorianer-Rüstung
15180	Prätorianer-Gurt
15181	Prätorianer-Stiefel
15182	Prätorianer-Gelenkbänder
15183	Prätorianer-Umhang
15184	Prätorianer-Handschuhe
15185	Prätorianer-Helmkappe
15186	Prätorianer-Gamaschen
15187	Prätorianer-Schulterstücke
15188	Großartige Armschützer
15189	Großartige Stiefel
15190	Großartiger Umhang
15191	Großartiger Gürtel
15192	Großartige Stulpen
15193	Großartige Krone
15194	Großartige Beinschützer
15195	Großartige Brustplatte
15196	Wams des Gefreiten
15197	Wams des Spähers
15198	Ritterfarben
15199	Herold des Steingardisten
15200	Abzeichen des Schlachtrufers
15202	Wildhüter-Gamaschen
15203	Sturmstoßbeinschützer
15204	Mondsteinzauberstab
15205	Eulensicht-Gewehr
15206	Jadefingerbaton
15207	Stahlkappenschild
15208	Mondstaub des Cenarius
15209	Reliktbündel
15210	Räuberkurzschwert
15211	Militantes Kurzschwert
15212	Kämpferbreitschwert
15213	Söldnerklinge
15214	Adelsmarke
15215	Wutschäumendes Krummschwert
15216	Runenschwert
15217	Witwenklinge
15218	Kristallschwert
15219	Dimensionsklinge
15220	Kriegsfellsäbel
15221	Heiliges Kriegsschwert
15222	Stachelige Keule
15223	Gezackter Stern
15224	Kampfzerkracher
15225	Mammutbaumhammer
15226	Riesenkeule
15227	Diamantspitzenknüttel
15228	Todesmeteor
15229	Segenswindhammer
15230	Kammspaltbeil
15231	Spaltendes Kriegsbeil
15232	Hackspaltbeil
15233	Wilde Axt
15234	Große Sense
15235	Sichelschneide
15236	Mondspaltbeil
15237	Leichenspalter
15238	Kriegsherrenaxt
15239	Teufelssteinhäscher
15240	Dämonenklaue
15241	Kampfmesser
15242	Gewetztes Stilett
15243	Tödlicher Kris
15244	Klingenschneide
15245	Vorpal-Dolch
15246	Dämonenklinge
15247	Blutdolch
15248	Gleißendes Claymore
15249	Polierter Bidenhänder
15250	Gleißender Flamberg
15251	Treffsicheres Schwert
15252	Hauerschwert
15253	Köpfklinge
15254	Dunkler Espandon
15255	Ritterlicher Flamberg
15256	Massakerschwert
15257	Schienbeinklinge
15258	Göttliche Kriegsklinge
15259	Kräftiger Kampfhammer
15260	Steinhammer
15261	Mammutbaumzweig
15262	Großer Schlägel
15263	Königlicher Schlaghammer
15264	Kreuzbrecher
15265	Peinbringer
15266	Wilder Raufer
15267	Schlägerstreitkolben
15268	Doppelklingen-Axt
15269	Massive Streitaxt
15270	Gigantische Kriegsaxt
15271	Kolossale Großaxt
15272	Schneidenaxt
15273	Todesschläger
15274	Rutengänger-Langstab
15275	Thaumaturgiestab
15276	Maguslangstab
15277	Grauer Kodo
15278	Sonnenwendstab
15279	Elfenbeinzauberstab
15280	Hexerhand
15281	Leuchtstern-Rute
15282	Großdrachen-Finger
15283	Lunarzauberstab
15284	Langer Kampfbogen
15285	Bogenschützen-Langbogen
15286	Rotholz-Langbogen
15287	Kreuzfahrer-Bogen
15288	Blasthorn-Bogen
15289	Archstrike-Bogen
15290	Brauner Kodo
15291	Harpyienstachler
15292	Grüner Kodo
15293	Graublauer Kodo
15294	Belagerungsbogen
15295	Feuerfederbogen
15296	Falkenauges Bogen
15297	Grizzly-Armschienen
15298	Grizzly-Rundschild
15299	Grizzly-Cape
15300	Grizzly-Handschuhe
15301	Grizzly-Schuhe
15302	Grizzly-Gürtel
15303	Grizzly-Hose
15304	Grizzly-Wams
15305	Wild-Schuhe
15306	Wild-Bindungen
15307	Wild-Rundschild
15308	Wild-Kordel
15309	Wild-Umhang
15310	Wild-Handschuhe
15311	Wildharnisch
15312	Wild-Gamaschen
15313	Wild-Schulterpolster
15314	Bündel Relikte
15322	Glattlauf-Schusswaffe
15323	Zündschrotflinte
15324	Burnside-Gewehr
15325	Scharfschützen-Arkebuse
15326	Gleißende Wurfaxt
15327	Tückischer Wurfdolch
15328	Josephs Schlüssel
15329	Zänkergürtel
15330	Zänkerstiefel
15331	Zänkergelenkbänder
15332	Zänkerrundschild
15333	Zänkerumhang
15334	Zänkerhandschuhe
15335	Zackenstahlkurzschwert
15336	Zänkergamaschen
15337	Zänkerwickeltücher
15338	Zänkermantel
15339	Pfadfinderhut
15340	Pfadfinderumhang
15341	Pfadfinderfußpolster
15342	Pfadfinderschutz
15343	Pfadfinderhandschuhe
15344	Pfadfinderhose
15345	Pfadfinderschulterpolster
15346	Pfadfinderweste
15347	Pfadfindergürtel
15348	Pfadfinderarmschienen
15349	Kopfjägergürtel
15350	Kopfjägerschuhe
15351	Kopfjägerbänder
15352	Kopfjägerrundschild
15353	Kopfjägerkopfputz
15354	Kopfjägerumhang
15355	Kopfjägerfäustlinge
15356	Kopfjägerrüstung
15357	Kopfjägerschiftung
15358	Kopfjägerwollwäsche
15359	Schwindlerweste
15360	Schwindlerbindungen
15361	Schwindlerschärpe
15362	Schwindlerstiefel
15363	Schwindlerkopfputz
15364	Schwindlerumhang
15365	Schwindlerhandlappen
15366	Schwindlergamaschen
15367	Schwindlerbeschützer
15368	Schwindlerschulterstücke
15369	Wolfreitergürtel
15370	Wolfreiterstiefel
15371	Wolfreiterumhang
15372	Wolfreiterhandschuhe
15373	Wolfreiterkopfbedeckung
15374	Wolfreitergamaschen
15375	Wolfreiterschulterpolster
15376	Gefütterte Wolfreiterrüstung
15377	Wolfreitergelenkbänder
15378	Zornprankengürtel
15379	Zornprankenstiefel
15380	Zornprankenarmschienen
15381	Zornprankenbrustschutz
15382	Zornprankenumhang
15383	Zornprankenhandschuhe
15384	Zornprankenhelm
15385	Zornprankengamaschen
15386	Zornprankenschultern
15387	Jadefeuerarmreifen
15388	Jadefeuergürtel
15389	Jadefeuersabatons
15390	Jadefeuerbrustschutz
15391	Jadefeuerkappe
15392	Jadefeuerumhang
15393	Jadefeuerhandschuhe
15394	Jadefeuerhose
15395	Jadefeuerschulterklappen
15396	Krummholzdolch
15397	Eichendrosselstab
15398	Sandcomber-Stiefel
15399	Dryweed-Gürtel
15400	Doppelgreifarmschienen
15401	Welldrip-Handschuhe
15402	Noosegrip-Stulpen
15403	Salzgegerbte Armschienen
15404	Breakwater-Gurt
15405	Schäl-Handschuhe
15406	Krustentier-Stiefel
15407	Geschmeidiger unverwüstlicher Balg
15408	Schwere Skorpidschuppe
15409	Raffiniertes Tiefsteinsalz
15410	Schuppe von Onyxia
15411	Mal von Fordring
15412	Grüne Drachenschuppe
15413	Verschnörkelte Adamantbrustplatte
15414	Rote Drachenschuppe
15415	Blaue Drachenschuppe
15416	Schwarze Drachenschuppe
15417	Teufelssaurierleder
15418	Schimmernder Platinkriegshammer
15419	Kriegsbärenleder
15420	Eisenfeder
15421	Tuch der Verbannung
15422	Frostsäblerleder
15423	Schimärenleder
15424	Axt von Orgrimmar
15425	Unvergleichliche Armschienen
15426	Unvergleichliche Stiefel
15427	Unvergleichlicher Umhang
15428	Unvergleichlicher Gürtel
15429	Unvergleichl. Handschuhe
15430	Unvergleichliches Stirnband
15431	Unvergleichliche Gamaschen
15432	Unvergleichliche Schultern
15433	Unvergleichliche Rüstung
15434	Oberste Schärpe
15435	Oberste Schuhe
15436	Oberste Armschienen
15437	Oberstes Cape
15438	Oberste Handschuhe
15439	Oberste Krone
15440	Oberste Gamaschen
15441	Oberste Schultern
15442	Oberste Brustplatte
15443	Kris von Orgrimmar
15444	Stab von Orgrimmar
15445	Hammer von Orgrimmar
15446	Deputyset aus Stormwind
15447	Lebendige Fäulnis
15448	Geronnene Fäulnis
15449	Garstige Beinkleider
15450	Gamaschen des Sumpfgräbers
15451	Gargoylegamaschen
15452	Federleichte Armschienen
15453	Savannenarmschienen
15454	Mörser und Stößel
15455	Dustfall-Roben
15456	Gamaschen des leichten Schritts
15457	Wüsten-Schultern
15458	Tundra-Stiefel
15459	Handgelenksschutz des dunklen Tributs
15461	Leichtfußstiefel
15462	Lehmfarbene Armschienen
15463	Bleichschreiter-Handschuhe
15464	Schlägerhammer
15465	Giftstachelzauberstab
15466	Klink-Schild
15467	Erfinderliga-Ring
15468	Windsongtuch
15469	Windsongsattelgurt
15470	Gamaschen des Ebenenwächters
15471	Rüstung der inneren Kraft
15472	Stürmergürtel
15473	Stürmerstiefel
15474	Stürmerbindungen
15475	Stürmerumhang
15476	Stürmerhandlappen
15477	Stürmerhose
15478	Stürmerschild
15479	Stürmerrüstung
15480	Gebrauchter Gurt
15481	Gebrauchter Schienbeinschützer
15482	Gebrauchte Bänder
15483	Gebrauchter Umhang
15484	Gebrauchter Handschutz
15485	Gebrauchte Hose
15486	Gebrauchter Schild
15487	Gebrauchte Tunika
15488	Blutbespritzter Übermantel
15489	Blutbespritzte Sabatons
15490	Blutbespritzter Mantel
15491	Blutbespritzte Handschuhe
15492	Blutbespritzte Schärpe
15493	Blutbespritzter Lendenschurz
15494	Blutbespritzter Schild
15495	Blutbespritzte Gelenkbänder
15496	Blutbespritzte Schulterpolster
15497	Kundschafter-Kordel
15498	Kundschafter-Schuhe
15499	Kundschafter-Manschetten
15500	Kundschafter-Brustschutz
15501	Kundschafter-Umhang
15502	Kundschafter-Handschuhe
15503	Kundschafter-Beinschützer
15504	Kundschafter-Schild
15505	Kundschafter-Schulterstücke
15506	Grunzerknöchelwickel
15507	Grunzerarmschienen
15508	Grunzercape
15509	Grunzerhandlappen
15510	Grunzergürtel
15511	Grunzerbeinschützer
15512	Grunzerschild
15513	Grunzerschulterstücke
15514	Grunzerbrustharnisch
15515	Stachelkettengürtel
15516	Stachelkettenschuhe
15517	Stachelkettengelenkbänder
15518	Stachelkettenbrustplatte
15519	Stachelkettenumhang
15520	Stachelkettenstulpen
15521	Stachelkettengamaschen
15522	Stachelkettenschild
15523	Stachelkettenschulterpolster
15524	Wachpostenübermantel
15525	Wachpostenschuhe
15526	Wachpostencape
15527	Wachpostenhandschuhe
15528	Wachpostenschärpe
15529	Wachpostengamaschen
15530	Wachpostenschild
15531	Wachpostenschulterschutz
15532	Wachpostenarmsplinte
15533	Wachpostenkopfputz
15534	Tückische Kettenstiefel
15535	Tückische Kettenarmschienen
15536	Tückischer Kettenbrustharnisch
15537	Tückischer Kettenumhang
15538	Tückische Kettenstulpen
15539	Tückischer Kettengürtelbund
15540	Tückischer Kettenhelm
15541	Tückische Kettenbeinschützer
15542	Tückische Kettenschulterpolster
15543	Tückischer Kettenschild
15544	Dickschuppensabatons
15545	Dickschuppenarmreifen
15546	Dickschuppenbrustplatte
15547	Dickschuppenumhang
15548	Dickschuppenstulpen
15549	Dickschuppengürtel
15550	Dickschuppenkrone
15551	Dickschuppenbeinschützer
15552	Dickschuppenschild
15553	Dickschuppenschulterpolster
15554	Plünderergurt
15555	Plündererstiefel
15556	Plündererarmschienen
15557	Plündererbrustschutz
15558	Plündererkrone
15559	Plündererumhang
15560	Plündererhandschuhe
15561	Plünderergamaschen
15562	Plündererschulterstücke
15563	Plündererschild
15564	Unverwüstliches Rüstungsset
15565	Marodeursstiefel
15566	Marodeursarmschienen
15567	Marodeurstunika
15568	Marodeursumhang
15569	Marodeurswappen
15570	Marodeursstulpen
15571	Marodeursgürtel
15572	Marodeursreif
15573	Marodeursgamaschen
15574	Marodeursschulterpolster
15575	Spiegelpanzergürtel
15576	Spiegelpanzersabatons
15577	Spiegelpanzerarmschienen
15578	Spiegelpanzerbrustplatte
15579	Spiegelpanzerumhang
15580	Spiegelpanzerkopfband
15581	Spiegelpanzerstulpen
15582	Spiegelpanzerbeinschützer
15583	Spiegelpanzerschulterpolster
15584	Spiegelpanzerschild
15585	Pardochandschutz
15586	Schnell wachsende Blume
15587	Ringtail-Gurt
15588	Bracesteel-Gürtel
15589	Beständige Stampfer
15590	Beständige Armschienen
15591	Beständige Brustplatte
15592	Beständiger Rundschild
15593	Beständiger Kronenreif
15594	Beständiger Umhang
15595	Beständige Handschuhe
15596	Beständige Beinplatten
15597	Beständige Schultern
15598	Beständiger Gurt
15599	Uralte Schienbeinschützer
15600	Uralte Unterarmschienen
15601	Uralter Brustharnisch
15602	Uralte Krone
15603	Uralter Umhang
15604	Uralter Verteidiger
15605	Uralte Stulpen
15606	Uralter Gürtel
15607	Uralte Beinschützer
15608	Uralte Schulterstücke
15609	Knochenverbundrüstung
15610	Knochenverbundarmschienen
15611	Knochenverbundcape
15612	Knochenverbundstulpen
15613	Knochenverbundgürtel
15614	Knochenverbundsabatons
15615	Knochenverbundhelm
15616	Knochenverbundbeinplatten
15617	Knochenverbundschulterklappen
15618	Knochenverbundwallschild
15619	Greifenpanzergürtel
15620	Greifenpanzerarmschienen
15621	Greifenpanzerrundschild
15622	Greifenpanzerbrustplatte
15623	Greifenpanzerkrone
15624	Greifen-Umhang
15625	Greifenpanzerstulpen
15626	Greifenpanzerschienbeinschützer
15627	Greifenpanzerbeinschützer
15628	Greifenpanzerschulterstücke
15629	Formidable Armschienen
15630	Formidable Sabatons
15631	Formidabler Brustharnisch
15632	Formidables Cape
15633	Formidables Wappen
15634	Formidabler Reif
15635	Formidable Stulpen
15636	Formidabler Gürtel
15637	Formidable Beinschützer
15638	Formidable Schulterpolster
15639	Eisenhautarmschienen
15640	Eisenhautbrustplatte
15641	Eisenhautgürtel
15642	Eisenhautschienbeinschützer
15643	Eisenhautumhang
15644	Eisenhautstulpen
15645	Eisenhauthelm
15646	Eisenhautbeinschützer
15647	Eisenhautschulterstücke
15648	Eisenhautschild
15649	Gnadenlose Armschienen
15650	Gnadenloser Übermantel
15651	Gnadenlose Krone
15652	Gnadenloser Umhang
15653	Gnadenlose Stulpen
15654	Gnadenloser Gürtel
15655	Gnadenlose Beinschützer
15656	Gnadenlose Schulterklappen
15657	Gnadenloser Schild
15658	Undurchdringliche Sabatons
15659	Undurchdringliche Bindungen
15660	Undurchdringliche Brustplatte
15661	Undurchdringlicher Umhang
15662	Undurchdringliche Stulpen
15663	Undurchdringlicher Gürtel
15664	Undurchdringlicher Helm
15665	Undurchdringliche Beinschützer
15666	Undurchdringliche Schulterstücke
15667	Undurchdringliche Wand
15668	Wunderbare Armschienen
15669	Wunderbare Brustplatte
15670	Wunderbarer Helm
15671	Wunderbarer Umhang
15672	Wunderbare Stulpen
15673	Wunderbarer Gürtel
15674	Wunderbare Schienbeinschützer
15675	Wunderbarer Schutz
15676	Wunderbare Gamaschen
15677	Wunderbare Schultern
15678	Triumphale Sabatons
15679	Triumphale Armschienen
15680	Triumphaler Brustharnisch
15681	Triumphaler Umhang
15682	Triumphale Stulpen
15683	Triumphaler Gurt
15684	Triumphale Schädelkappe
15685	Triumphale Beinplatten
15686	Triumphale Schulterpolster
15687	Triumphaler Schild
15688	Magische Bohnen
15689	Ring des Händlers
15690	Kodoknochenhalskette
15691	Minischrotflinte
15692	Kodobränder
15693	Großartige Schultern
15694	Gnadenlose Schienbeinschützer
15695	Beschlagener Ringschild
15696	Verdorbener Foliant
15697	Stiefel eines Kodoviehdiebs
15698	Zänkerschiftung
15699	Kleines, braun eingepacktes Päckchen
15702	Ring des Chemikers
15703	Kittel des Chemikers
15704	Jägerinsignien-Medaille
15705	Klinge des Gezeitenwappens
15706	Fährtenleserjagdklinge
15707	Brandholzschärpe
15708	Verseuchte Lederhandschuhe
15709	Gearforge-Gurt
15710	Lunarstaub des Cenarius
15722	Spraggles Feldflasche
15723	Tee mit Zucker
15724	Muster: Schwere Skorpidarmschienen
15725	Muster: Tückische Lederstulpen
15726	Muster: Grüne Drachenschuppenbrustplatte
15727	Muster: Schwere Skorpidweste
15728	Muster: Tückische Lederarmschienen
15729	Muster: Schimärenhandschuhe
15730	Muster: Rote Drachenschuppenbrustplatte
15731	Muster: Runenverzierte Lederstulpen
15732	Muster: Vulkanische Gamaschen
15733	Muster: Grüne Drachenschuppengamaschen
15734	Muster: Lebendige Schultern
15735	Muster: Eisenfederschultern
15736	Smokeys Spezialpräparat
15737	Muster: Schimärenstiefel
15738	Muster: Schwere Skorpidstulpen
15739	Muster: Runenverzierte Lederarmschienen
15740	Muster: Frostsäblerstiefel
15741	Muster: Sturmschleierhose
15742	Muster: Kriegsbärenharnisch
15743	Muster: Schwerer Skorpidgürtel
15744	Muster: Tückisches Lederstirnband
15745	Muster: Runenverzierter Ledergürtel
15746	Muster: Schimärengamaschen
15747	Muster: Frostsäblergamaschen
15748	Muster: Schwere Skorpidgamaschen
15749	Muster: Vulkanische Brustplatte
15750	Szepter des Lichts
15751	Muster: Blaue Drachenschuppenbrustplatte
15752	Muster: Lebendige Gamaschen
15753	Muster: Sturmschleierrüstung
15754	Muster: Kriegsbärenwollwäsche
15755	Muster: Schimärenweste
15756	Muster: Runenverziertes Lederstirnband
15757	Muster: Tückische Lederhose
15758	Muster: Teufelssaurierstulpen
15759	Muster: Schwarze Drachenschuppenbrustplatte
15760	Muster: Eisenfederbrustplatte
15761	Muster: Frostsäblerhandschuhe
15762	Muster: Schwerer Skorpidhelm
15763	Muster: Blaue Drachenschuppenschultern
15764	Muster: Sturmschleierschultern
15765	Muster: Runenverzierte Lederhose
15766	Edelstein der Schlange
15767	Hameyas Schlüssel
15768	Muster: Tückischer Ledergürtel
15769	Muster: Onyxiaschuppenumhang
15770	Muster: Schwarze Drachenschuppenschultern
15771	Muster: Lebendige Brustplatte
15772	Muster: Teufelssauriergamaschen
15773	Muster: Tückische Lederrüstung
15774	Muster: Schwere Skorpidschultern
15775	Muster: Vulkanische Schultern
15776	Muster: Runenverzierte Lederrüstung
15777	Muster: Runenverzierte Lederschultern
15778	Mechanischer Yeti
15779	Muster: Frostsäblertunika
15780	Muster: Onyxiaschuppenbrustplatte
15781	Muster: Schwarze Drachenschuppengamaschen
15782	Bestienjägerklinge
15783	Bestienjägerdolch
15784	Kristallbrisenmantel
15785	Zaeldarrs Kopf
15786	Farnpuls-Wams
15787	Weidenbandhalsberge
15788	Everlook-Bericht
15789	Tiefenfluss-Umhang
15790	Studien über das Geistsprechen
15791	Türkise Schärpe
15792	Pflugholz-Schiftung
15793	Ein abgeknabberter Knochen
15794	Zerfetzter Ogerlendenschurz
15795	Smaragdnebelstulpen
15796	Gischt-Armschienen
15797	Leuchtende Armplatten
15798	Gesplitterter Ogerzahn
15799	Heldenhafte Belobigungs-Medaille
15800	Beherztes Kurzschwert
15801	Tapferes Kurzschwert
15802	Mondstoffstiefel
15803	Buch der Uralten
15804	Kirschfarbenes Tuch
15805	Penelopes Rose
15806	Mirahs Lied
15807	Leichte Armbrust
15808	Feine leichte Armbrust
15809	Schwere Armbrust
15810	Kurzer Speer
15811	Schwerer Speer
15812	Orchideenamicia
15813	Goldverbund-Gürtel
15814	Hameyas Töter
15815	Hameyas Umhang
15822	Schattenhautschiftung
15823	Bricksteel-Stulpen
15824	Astoria-Roben
15825	Fallenstellerwams
15826	Heilende Tiersalbe
15827	Jadeschuppenbrustplatte
15842	Leere Glutnebelgipfelprobe
15843	Gefüllte Glutnebelgipfelprobe
15844	Leere Cliffspring Falls-Probe
15845	Gefüllte Cliffspring Falls-Probe
15846	Salzstreuer
15847	Quel'Thalas-Registratur
15848	Kiste mit Geistermagneten
15849	Geisterplasma
15850	Fellflicken von Dämmerschwinge
15851	Lunarfungus
15852	Kodohorn
15853	Windschnitter
15854	Tanzender Span
15855	Ring des Schutzes
15856	Erzlicht-Talisman
15857	Magierbann-Spross
15858	Freiwindhandschuhe
15859	Seeposten-Gurt
15860	Armschützer des flinken Schlags
15861	Swiftfoot-Treter
15862	Blitzspaltbeil
15863	Grabszepter
15864	Kondor-Armschienen
15865	Ankerpfahl-Rundschild
15866	Schleierstaub-Medizinbeutel
15867	Prisma-Talisman
15868	Befehl des obersten Kreuzzüglers
15869	Silberdietrich
15870	Golddietrich
15871	Echtsilberdietrich
15872	Arkanitdietrich
15873	Der immervolle Becher des struppigen John
15874	Weichschalige Muschel
15875	Verfaulter Apfel
15876	Nathanos' Truhe
15877	Schrein-Schmuckstück
15878	Rackmores silberner Schlüssel
15879	Klaue von Oberanführer Ror
15880	Kopf von Ramstein dem Verschlinger
15881	Rackmores goldener Schlüssel
15882	Halber Anhänger der Wasser-Belastbarkeit
15883	Halber Anhänger der Wasser-Beweglichkeit
15884	Augustus' Rezeptbuch
15885	Anhänger des Seelöwen
15886	Timolains Phylakterium
15887	Heldenhafter Schutz
15890	Schild des Vorposten
15891	Titanischer Schild
15892	Töterschild
15893	Rundschild des Ausgrabungsleiters
15894	Borstenlederrundschild
15895	Brand-Rundschild
15902	Ein Krabbelsack
15903	Rechtshändige Klaue
15904	Rechtshändige Klingen
15905	Rechtshändiger Messingschlagring
15906	Linkshändiger Messingschlagring
15907	Linkshändige Klaue
15908	Zähmerrute
15909	Linkshändige Klingen
15911	Zähmerrute
15912	Bukanier-Kugel
15913	Zähmerrute
15914	Zähmerrute
15915	Zähmerrute
15916	Zähmerrute
15917	Zähmerrute
15918	Herbeizauberer-Sphäre
15919	Zähmerrute
15920	Zähmerrute
15921	Zähmerrute
15922	Zähmerrute
15923	Zähmerrute
15924	Weichschaliges Muschelfleisch
15925	Gesellenstock
15926	Zauberbinder-Kugel
15927	Helle Sphäre
15928	Silberfadenrute
15929	Nachthauchkugel
15930	Imperiales rotes Szepter
15931	Arkaner Stern
15932	Jüngerbierkrug
15933	Einfacher Zweig
15934	Weisenstock
15935	Haltbare Rute
15936	Dämmergewirkter Zweig
15937	Sphäre des Winterschlafs
15938	Mystische Kugel
15939	Ratsherrenszepter
15940	Elegantes Szepter
15941	Oberratsherrenszepter
15942	Meisterrute
15943	Magieerfüllter Schild
15944	Vorfahren-Kugel
15945	Runenverzierter Stock
15946	Mystikersphäre
15947	Blutbadstern
15962	Rute des Satyrs
15963	Steinstoffzweig
15964	Seidensandstern
15965	Kugel des Windhetzers
15966	Giftschleierkugel
15967	Hochgeborenenstern
15968	Elunarische Sphäre
15969	Perlenkugel
15970	Eingeborenenzweig
15971	Ureinwohnerrute
15972	Ritual-Bierkrug
15973	Behüter-Stern
15974	Heiden-Rute
15975	Regenmacherszepter
15976	Distelfellzweig
15977	Vitale Kugel
15978	Geomantenrute
15979	Glutseidenstock
15980	Graunebelkugel
15981	Lunarsphäre
15982	Blutgewebte Rute
15983	Gaeas Szepter
15984	Opulentes Szepter
15985	Arachnidenzweig
15986	Knochenwerfers Stern
15987	Astralkugel
15988	Prächtige Kugel
15989	Ewige Rute
15990	Ausdauernder Schild
15991	Kriegsanführer-Schild
15992	Dichtes Sprengpulver
15993	Thoriumgranate
15994	Thoriumapparat
15995	Thoriumgewehr
15996	Lebensechte mechanische Kröte
15997	Thoriumpatronen
15998	Lewis' Notiz
15999	Zaubermachtschutzbrille Xtrem Plus
16000	Thoriumröhre
16001	SI:7-Insignie (Fredo)
16002	SI:7-Insignie (Turyen)
16003	SI:7-Insignie (Rutger)
16004	Dunkeleisengewehr
16005	Dunkeleisenbombe
16006	Empfindlicher Arkanitwandler
16007	Fehlerloses Arkanitgewehr
16008	Schutzbrille des Meisteringenieurs
16009	Modularer Stimmenverstärker
16022	Arkanitdrachling
16023	Meisterliche Zielattrappe
16026	PVP Plate Helm Alliance
16027	PVP Plate Breastplate Alliance
16028	PVP Plate Legplates Alliance
16029	PVP Plate Gauntlets Alliance
16030	PVP Plate Boots Alliance
16031	PVP Plate Shoulder Alliance
16033	PVP Plate Wrist Alliance
16034	PVP Plate Cloak Alliance
16035	PVP Cloth Helm Horde
16036	PVP Cloth Robe Horde
16037	PVP Cloth Legs Horde
16038	PVP Cloth Shoulder Horde
16039	Ta'Kierthan Arkanklinge
16040	Arkane Bombe
16041	Bauplan: Thoriumgranate
16042	Bauplan: Thoriumapparat
16043	Bauplan: Thoriumgewehr
16044	Bauplan: Lebensechte mechanische Kröte
16045	Bauplan: Zaubermachtschutzbrille Xtrem Plus
16046	Bauplan: Meisterliche Zielattrappe
16047	Bauplan: Thoriumröhre
16048	Bauplan: Dunkeleisengewehr
16049	Bauplan: Dunkeleisenbombe
16050	Bauplan: Empfindlicher Arkanitwandler
16051	Bauplan: Thoriumpatronen
16052	Bauplan: Modularer Stimmenverstärker
16053	Bauplan: Schutzbrille des Meisteringenieurs
16054	Bauplan: Arkanitdrachling
16055	Bauplan: Arkane Bombe
16056	Bauplan: Fehlerloses Arkanitgewehr
16057	Forscher-Knappsack
16058	Fordrings Siegel
16059	Gewöhnliches braunes Hemd
16060	Gewöhnliches weißes Hemd
16072	Expertenkochbuch
16073	Fachmannkochbuch
16082	Fachmännisches Angeln - Kunst des Köderns
16083	Expertenangeln - Der Barsch und du
16084	Erste Hilfe für Experten - Verbinden, aber richtig
16085	Fachmann-Erste-Hilfe - Heilt Euch selbst
16110	Rezept: Monsteromelett
16111	Rezept: Gewürzter Chilikrebs
16112	Handbuch: Schwerer Seidenverband
16113	Handbuch: Magiestoffverband
16114	Großknecht-Totschläger
16115	Osrics Kiste
16166	Bohnensuppe
16167	Versifarben-Leckerei
16168	Himmlischer Pfirsich
16169	Wilder Reiskuchen
16170	Gedünsteter Mandu
16171	Shinsollo
16189	Maggrans Reservebrief
16190	Überreste der Blutfurienzerfetzerin
16191	Verschnörkelter Spiegel
16192	Besseleths Fangzahn
16202	Geringe ewige Essenz
16203	Große ewige Essenz
16204	Illusionsstaub
16205	Gaeas Samenkorn
16206	Arkanitrute
16207	Runenverzierte Arkanitrute
16208	Verzauberte Gaeasamenkörner
16209	Podrigs Befehl
16210	Gordons Kiste
16214	Formel: Armschiene - Große Intelligenz
16215	Formel: Stiefel - Große Ausdauer
16216	Formel: Umhang - Großer Widerstand
16217	Formel: Schild - Große Ausdauer
16218	Formel: Armschiene - Überragende Willenskraft
16219	Formel: Handschuhe - Große Beweglichkeit
16220	Formel: Stiefel - Willenskraft
16221	Formel: Brust - Erhebliche Gesundheit
16222	Formel: Schild - Erhebliche Willenskraft
16223	Formel: Waffe - Eisiger Hauch
16224	Formel: Umhang - Überragende Verteidigung
16242	Formel: Brust - Erhebliches Mana
16243	Formel: Runenverzierte Arkanitrute
16244	Formel: Handschuhe - Große Stärke
16245	Formel: Stiefel - Große Beweglichkeit
16246	Formel: Armschiene - Überragende Stärke
16247	Formel: Zweihandwaffe - Überragender Einschlag
16248	Formel: Waffe - Unheilig
16249	Formel: Zweihandwaffe - Erhebliche Intelligenz
16250	Formel: Waffe - Überragendes Schlagen
16251	Formel: Armschiene - Überragende Ausdauer
16252	Formel: Waffe - Kreuzfahrer
16253	Formel: Brust - Große Werte
16254	Formel: Waffe - Lebensdiebstahl
16255	Formel: Zweihandwaffe - Erhebliche Willenskraft
16262	Nessas Sammlung
16263	Lairds Antwort
16282	Bündel mit Bälgen
16283	Ahanus Lederwaren
16302	Zauberfoliant des Feuerblitzes (Rang 2)
16303	Ursangus' Tatze
16304	Schattumbras Kopf
16305	Klaue von Scharfkralle
16306	Fleischerei Zargh
16307	Gryshkas Brief
16308	Northridge-Brechstange
16309	Drachenfeueramulett
16310	Brocks Liste
16311	Ehren-Hacken
16312	Pyrophore
16313	Felix' Truhe
16314	Felix' Bolzeneimer
16315	Cape des Sergeant Majors
16316	Zauberfoliant des Feuerblitzes (Rang 3)
16317	Zauberfoliant des Feuerblitzes (Rang 4)
16318	Zauberfoliant des Feuerblitzes (Rang 5)
16319	Zauberfoliant des Feuerblitzes (Rang 6)
16320	Zauberfoliant des Feuerblitzes (Rang 7)
16321	Zauberfoliant des Blutpakts (Rang 1)
16322	Zauberfoliant des Blutpakts (Rang 2)
16323	Zauberfoliant des Blutpakts (Rang 3)
16324	Zauberfoliant des Blutpakts (Rang 4)
16325	Zauberfoliant des Blutpakts (Rang 5)
16326	Zauberfoliant des Feuerschilds (Rang 1)
16327	Zauberfoliant des Feuerschilds (Rang 2)
16328	Zauberfoliant des Feuerschilds (Rang 3)
16329	Zauberfoliant des Feuerschilds (Rang 4)
16330	Zauberfoliant des Feuerschilds (Rang 5)
16331	Zauberfoliant der Phasenverschiebung
16332	Thazz'rils Hacke
16333	Samuels sterbliche Überreste
16335	Abzeichen des Schlachtrufers
16336	Cape des Sergeant Majors
16337	Cape des Sergeant Majors
16338	Ross des Hauptmanns
16339	Ross des Kommandanten
16341	Umhang des Waffenträgers
16342	Cape des Landsknechts
16343	Reittier des Blutgardisten
16344	Reittier des Sturmreiters
16345	Schwert des Obersten Kriegsfürsten
16346	Zauberfoliant der Qual (Rang 2)
16347	Zauberfoliant der Qual (Rang 3)
16348	Zauberfoliant der Qual (Rang 4)
16349	Zauberfoliant der Qual (Rang 5)
16350	Zauberfoliant der Qual (Rang 6)
16351	Zauberfoliant der Opferung (Rang 1)
16352	Zauberfoliant der Opferung (Rang 2)
16353	Zauberfoliant der Opferung (Rang 3)
16354	Zauberfoliant der Opferung (Rang 4)
16355	Zauberfoliant der Opferung (Rang 5)
16356	Zauberfoliant der Opferung (Rang 6)
16357	Zauberfoliant des Schattenverzehrens (Rang 1)
16358	Zauberfoliant des Schattenverzehrens (Rang 2)
16359	Zauberfoliant des Schattenverzehrens (Rang 3)
16360	Zauberfoliant des Schattenverzehrens (Rang 4)
16361	Zauberfoliant des Schattenverzehrens (Rang 5)
16362	Zauberfoliant des Schattenverzehrens (Rang 6)
16363	Zauberfoliant des Leidens (Rang 1)
16364	Zauberfoliant des Leidens (Rang 2)
16365	Zauberfoliant des Leidens (Rang 3)
16366	Zauberfoliant des Leidens (Rang 4)
16367	Seidene Schärpe des Kürassiers
16368	Zauberfoliant der Schmerzenspeitsche (Rang 2)
16369	Seidene Stiefel des Hauptmanns
16370	Seidene Manschetten des Kürassiers
16371	Zauberfoliant der Schmerzenspeitsche (Rang 3)
16372	Zauberfoliant der Schmerzenspeitsche (Rang 4)
16373	Zauberfoliant der Schmerzenspeitsche (Rang 5)
16374	Zauberfoliant der Schmerzenspeitsche (Rang 6)
16375	Zauberfoliant des besänftigenden Kusses (Rang 1)
16376	Zauberfoliant des besänftigenden Kusses (Rang 2)
16377	Zauberfoliant des besänftigenden Kusses (Rang 3)
16378	Zauberfoliant des besänftigenden Kusses (Rang 4)
16379	Zauberfoliant der Verführung
16380	Zauberfoliant der geringen Unsichtbarkeit
16381	Zauberfoliant des Magieverschlingens (Rang 2)
16382	Zauberfoliant des Magieverschlingens (Rang 3)
16383	Zauberfoliant des Magieverschlingens (Rang 4)
16384	Zauberfoliant des besudelten Blutes (Rang 1)
16385	Zauberfoliant des besudelten Blutes (Rang 2)
16386	Zauberfoliant des besudelten Blutes (Rang 3)
16387	Zauberfoliant des besudelten Blutes (Rang 4)
16388	Zauberfoliant der Zaubersperre (Rang 1)
16389	Zauberfoliant der Zaubersperre (Rang 2)
16390	Zauberfoliant der Paranoia
16391	Seidene Handschuhe des Hauptmanns
16392	Lederstiefel des Hauptmanns
16393	Drachenlederfußlappen des Hauptmanns
16394	Lederarmschienen des Kürassiers
16395	Drachenleder-Armsplinte des Kürassiers
16396	Lederstulpen des Hauptmanns
16397	Drachenlederhandschuhe des Hauptmanns
16398	Leder-Gürtel des Kürassiers
16399	Drachenleder-Gurt des Kürassiers
16400	Kettengurt des Kürassiers
16401	Kettenstiefel des Hauptmanns
16402	Kettenarmschützer des Kürassiers
16403	Kettenstulpen des Hauptmanns
16404	Platten-Handgelenkschutz des Kürassiers
16405	Plattenstiefel des Hauptmanns
16406	Plattenstulpen des Hauptmanns
16407	Plattengurt des Kürassiers
16408	Beschmutzte Wasserkugel
16409	Lamellensabatons des Hauptmanns
16410	Lamellenstulpen des Hauptmanns
16411	Lamellen-Sattelgurt des Kürassiers
16412	Lamellen-Armsplinte des Kürassiers
16413	Seidene Gewandung des Kürassiers
16414	Seidene Beinlinge des Kürassiers
16415	Seidene Schiftung des Feldkommandanten
16416	Krone des Feldkommandanten
16417	Lederrüstung des Kürassiers
16418	Lederschleier des Feldkommandanten
16419	Lederbeinschützer des Kürassiers
16420	Lederschiftung des Feldkommandanten
16421	Drachenledertunika des Kürassiers
16422	Drachenledergamaschen des Kürassiers
16423	Drachenlederschulterklappen des Feldkommandanten
16424	Drachenledertuch des Feldkommandanten
16425	Kettentorso des Kürassiers
16426	Kettenbeinlinge des Kürassiers
16427	Kettenschulterstücke des Feldkommandanten
16428	Kettenhelm des Feldkommandanten
16429	Plattenhelm des Feldkommandanten
16430	Plattenbrustschutz des Kürassiers
16431	Plattengamaschen des Kürassiers
16432	Plattenschulterstücke des Feldkommandanten
16433	Lamellenbrustplatte des Kürassiers
16434	Lamellenkopfschutz des Feldkommandanten
16435	Lamellengamaschen des Kürassiers
16436	Lamellenschultern des Feldkommandanten
16437	Seidene Fußlappen des Marschalls
16438	Seidene Armschienen des Marschalls
16439	Seidene Schärpe des Marschalls
16440	Seidene Handschuhe des Marschalls
16441	Kronenreif des Feldmarschalls
16442	Seidene Gamaschen des Marschalls
16443	Seidene Tracht des Feldmarschalls
16444	Seidene Schiftung des Feldmarschalls
16445	Drachenleder-Armschienen des Marschalls
16446	Lederne Fußschützer des Marschalls
16447	Drachenleder-Taillenschutz des Marschalls
16448	Drachenlederstulpen des Marschalls
16449	Drachenlederschiftung des Feldmarschalls
16450	Drachenlederbeinschützer des Marschalls
16451	Drachenlederhelm des Feldmarschalls
16452	Drachenlederbrustplatte des Feldmarschalls
16453	Lederner Brustharnisch des Feldmarschalls
16454	Lederner Handschutz des Marschalls
16455	Lederne Maske des Feldmarschalls
16456	Lederne Gamaschen des Marschalls
16457	Lederne Schulterklappen des Feldmarschalls
16458	Lederner Sattelgurt des Marschalls
16459	Drachenlederstiefel des Marschalls
16460	Lederarmsplinte des Marschalls
16461	Kettenarmschienen des Marschalls
16462	Kettenstiefel des Marschalls
16463	Kettenhandschutz des Marschalls
16464	Kettengurt des Marschalls
16465	Kettenhelm des Feldmarschalls
16466	Kettenbrustplatte des Feldmarschalls
16467	Kettenbeinschützer des Marschalls
16468	Kettenschiftung des Feldmarschalls
16469	Lamellen-Armschützer des Marschalls
16470	Lamellen-Gürtel des Marschalls
16471	Lamellenhandschuhe des Marschalls
16472	Lamellenstiefel des Marschalls
16473	Lamellenbrustharnisch des Feldmarschalls
16474	Lamellengesichtsschutz des Feldmarschalls
16475	Lamellenbeinplatten des Marschalls
16476	Lamellenschulterstücke des Feldmarschalls
16477	Plattenrüstung des Feldmarschalls
16478	Plattenhelm des Feldmarschalls
16479	Plattenbeinschützer des Marschalls
16480	Plattenschulterschutz des Feldmarschalls
16481	Plattenarmschienen des Marschalls
16482	Plattengurt des Marschalls
16483	Plattenstiefel des Marschalls
16484	Plattenstulpen des Marschalls
16485	Seidene Fußlappen des Blutgardisten
16486	Seidenmanschetten des Rottenmeisters
16487	Seidene Handschuhe des Blutgardisten
16488	Seidener Gürtel des Zornbringers
16489	Seidene Kapuze des Feldherren
16490	Seidene Hose des Zornbringers
16491	Seidene Robe des Zornbringers
16492	Seidene Schulterpolster des Feldherren
16493	Drachenleder-Armschützer des Zornbringers
16494	Drachenlederstiefel des Blutgardisten
16495	Drachenleder-Gürtelbund des Zornbringers
16496	Drachenlederstulpen des Blutgardisten
16497	Lederarmschützer des Rottenmeisters
16498	Ledertreter des Blutgardisten
16499	Lederklemmen des Blutgardisten
16500	Ledergurt des Zornbringers
16501	Drachenlederschiftung des Feldherren
16502	Drachenlederbeinkleider des Zornbringers
16503	Drachenlederhelm des Feldherren
16504	Drachenlederbrustplatte des Zornbringers
16505	Lederhalsberge des Zornbringers
16506	Lederkopfschutz des Feldherren
16507	Ledermantel des Feldherren
16508	Ledergamaschen des Zornbringers
16509	Plattenstiefel des Blutgardisten
16510	Plattenhandschuhe des Blutgardisten
16511	Platten-Sattelgurt des Zornbringers
16512	Plattenarmschienen des Zornbringers
16513	Plattenrüstung des Zornbringers
16514	Plattenkopfschutz des Feldherren
16515	Plattenbeinschützer des Zornbringers
16516	Plattenschulterstücke des Feldherren
16517	Kettenarmschienen des Zornbringers
16518	Panzerlaufschuhe des Blutgardisten
16519	Panzerhandschutz des Blutgardisten
16520	Panzer-Sattelgurt des Zornbringers
16521	Panzerhelm des Feldherren
16522	Panzerbrustharnisch des Zornbringers
16523	Panzergamaschen des Zornbringers
16524	Panzerschultern des Feldherren
16525	Kettenbrustplatte des Zornbringers
16526	Kettenkopfschutz des Feldherren
16527	Kettenbeinlinge des Zornbringers
16528	Kettenschulterstücke des Feldherren
16529	Kettengurt des Zornbringers
16530	Kettenstulpen des Blutgardisten
16531	Kettenstiefel des Blutgardisten
16532	Panzerhandgelenksschutz des Rottenmeisters
16533	Seidene Kutte des Kriegsfürsten
16534	Seidene Beinkleider des Kriegsherren
16535	Seidene Gewandung des Kriegsfürsten
16536	Seidene Amicia des Kriegsfürsten
16537	Seidene Schärpe des Kriegsherrn
16538	Seidene Manschetten des Kriegsherrn
16539	Seidene Stiefel des Kriegsherren
16540	Seidene Handschützer des Kriegsherren
16541	Plattenrüstung des Kriegsfürsten
16542	Plattenkopfstück des Kriegsfürsten
16543	Plattengamaschen des Kriegsfürsten
16544	Plattenschultern des Kriegsfürsten
16545	Plattenstiefel des Kriegsherren
16546	Platten-Armschützer des Kriegsherrn
16547	Plattengurt des Kriegsherrn
16548	Plattenstulpen des Kriegsherren
16549	Drachenlederhalsberge des Kriegsfürsten
16550	Drachenlederhelm des Kriegsfürsten
16551	Drachenlederschulterklappen des Kriegsfürsten
16552	Drachenledergamaschen des Kriegsherren
16553	Drachenleder-Armschienen des Kriegsherrn
16554	Drachenlederstiefel des Kriegsherren
16555	Drachenlederhandschuhe des Kriegsherren
16556	Drachenleder-Gürtel des Kriegsherrn
16557	Ledener Gurt des Kriegsherrn
16558	Ledertreter des Kriegsherren
16559	Lederarmsplinte des Kriegsherrn
16560	Lederfäustlinge des Kriegsherren
16561	Lederhelm des Kriegsfürsten
16562	Lederschiftung des Kriegsfürsten
16563	Lederbrustplatte des Kriegsfürsten
16564	Lederbeinschützer des Kriegsherren
16565	Kettenbrustharnisch des Kriegsfürsten
16566	Kettenhelm des Kriegsfürsten
16567	Kettenbeinschützer des Kriegsherren
16568	Kettenschultern des Kriegsfürsten
16569	Kettensabatons des Kriegsherrn
16570	Ketten-Handgelenkschutz des Kriegsherrn
16571	Kettenhandschuhe des Kriegsherren
16572	Kettengurt des Kriegsherrn
16573	Panzerstiefel des Kriegsherren
16574	Panzerstulpen des Kriegsherren
16575	Panzer-Gürtelbund des Kriegsherrn
16576	Panzer-Armschienen des Kriegsherrn
16577	Panzerrüstung des Kriegsfürsten
16578	Panzerhelm des Kriegsfürsten
16579	Panzergamaschen des Kriegsherren
16580	Panzerschiftung des Kriegsfürsten
16581	Resonitkristall
16583	Dämonenstatuette
16602	Troll-Glücksbringer
16603	Verzauberter Resonitkristall
16604	Mondroben von Elune
16605	Fraterroben des Lichts
16606	Jujuverhexungsroben
16607	Opferroben des Akolythen
16608	Wassermann-Gürtel
16622	Dornenwerfer
16623	Opal-Medaillon
16642	Schredderanleitung - Kapitel 1
16643	Schredderanleitung - Kapitel 2
16644	Schredderanleitung - Kapitel 3
16645	Schredderanleitung - Seite 1
16646	Schredderanleitung - Seite 2
16647	Schredderanleitung - Seite 3
16648	Schredderanleitung - Seite 4
16649	Schredderanleitung - Seite 5
16650	Schredderanleitung - Seite 6
16651	Schredderanleitung - Seite 7
16652	Schredderanleitung - Seite 8
16653	Schredderanleitung - Seite 9
16654	Schredderanleitung - Seite 10
16655	Schredderanleitung - Seite 11
16656	Schredderanleitung - Seite 12
16658	Wildjäger-Umhang
16659	Deftkin-Gürtel
16660	Schild des Moornebels
16661	Weiches Weidencape
16662	Fragment des Großdrachen-Auges
16663	Blut des schwarzen Großdrachenhelden
16664	Verschnörkelte Armschienen
16665	Foliant des einlullenden Schusses
16666	Weste der Elemente
16667	Helmkappe der Elemente
16668	Kilt der Elemente
16669	Schulterstücke der Elemente
16670	Stiefel der Elemente
16671	Bindungen der Elemente
16672	Stulpen der Elemente
16673	Kordel der Elemente
16674	Bestienjägertunika
16675	Bestienjägerstiefel
16676	Bestienjägerhandschuhe
16677	Bestienjägerkappe
16678	Bestienjägerhose
16679	Bestienjägermantel
16680	Bestienjägergürtel
16681	Bestienjägerbindungen
16682	Stiefel des Magisters
16683	Bindungen des Magisters
16684	Handschuhe des Magisters
16685	Gürtel des Magisters
16686	Krone des Magisters
16687	Gamaschen des Magisters
16688	Roben des Magisters
16689	Mantel des Magisters
16690	Robe des Gläubigen
16691	Sandalen des Gläubigen
16692	Handschuhe des Gläubigen
16693	Krone des Gläubigen
16694	Rock des Gläubigen
16695	Mantel des Gläubigen
16696	Gürtel des Gläubigen
16697	Armschienen des Gläubigen
16698	Maske der Furcht
16699	Gamaschen der Furcht
16700	Robe der Furcht
16701	Mantel der Furcht
16702	Gürtel der Furcht
16703	Armschienen der Furcht
16704	Sandalen der Furcht
16705	Wickeltücher der Furcht
16706	Weste des Wildherzens
16707	Kappe der Schattenkunst
16708	Schiftung der Schattenkunst
16709	Hose der Schattenkunst
16710	Armschienen der Schattenkunst
16711	Stiefel der Schattenkunst
16712	Handschuhe der Schattenkunst
16713	Gürtel der Schattenkunst
16714	Armschienen des Wildherzens
16715	Stiefel des Wildherzens
16716	Gürtel des Wildherzens
16717	Handschuhe des Wildherzens
16718	Schiftung des Wildherzens
16719	Kilt des Wildherzens
16720	Kutte des Wildherzens
16721	Tunika der Schattenkunst
16722	Armschienen des Lichts
16723	Gürtel des Lichts
16724	Stulpen des Lichts
16725	Stiefel des Lichts
16726	Brustplatte des Lichts
16727	Helm des Lichts
16728	Beinplatten des Lichts
16729	Schiftung des Lichts
16730	Brustplatte der Ehre
16731	Helm der Ehre
16732	Beinplatten der Ehre
16733	Schiftung der Ehre
16734	Stiefel der Ehre
16735	Armschienen der Ehre
16736	Gürtel der Ehre
16737	Stulpen der Ehre
16738	Witherseed-Handschuhe
16739	Rugwood-Mantel
16740	Schredderbedienungshandschuhe
16741	Ölige Handlappen
16742	Warsongsägeblätter
16743	Holzfällerseil
16744	Warsongöl
16745	Warsongaxtlieferung
16746	Warsongbericht
16747	Zerbrochenes Schloss
16748	Gefüttertes Futter
16762	Fathomkern
16763	Warsongläufer-Update
16764	Warsongspäher-Update
16765	Warsongvorhut-Update
16766	Undermine-Muschelsuppe
16767	Rezept: Undermine-Muschelsuppe
16768	Medizinbeutel der Furbolgs
16769	Medizintotem der Furbolgs
16782	Seltsame Wasserkugel
16783	Gebündelte Berichte
16784	Saphir von Aku'Mai
16785	Rexxars Testament
16786	Schwarzes Drachenbrutauge
16787	Amulett der drachischen Subversion
16788	Käpt'n Rackmores Steuerruder
16789	Käpt'n Rackmores Pinne
16790	Feuchte Notiz
16791	Seidenbandmanschetten
16792	Riesenkeule
16793	Rundgeschliffene Metallschiftung
16794	Handgelenksschutz des eisernen Griffs
16795	Krone des Arkanisten
16796	Gamaschen des Arkanisten
16797	Mantel des Arkanisten
16798	Roben des Arkanisten
16799	Bindungen des Arkanisten
16800	Stiefel des Arkanisten
16801	Handschuhe des Arkanisten
16802	Gürtel des Arkanisten
16803	Teufelsherzschuhe
16804	Teufelsherzarmschienen
16805	Teufelsherzhandschuhe
16806	Teufelsherzgürtel
16807	Teufelsherzschulterpolster
16808	Teufelsherzhörner
16809	Teufelsherzroben
16810	Teufelsherzhose
16811	Stiefel der Prophezeiung
16812	Handschuhe der Prophezeiung
16813	Reif der Prophezeiung
16814	Hose der Prophezeiung
16815	Roben der Prophezeiung
16816	Mantel der Prophezeiung
16817	Gurt der Prophezeiung
16818	Gürtel des Netherwinds
16819	Unterarmschienen der Prophezeiung
16820	Brustharnisch des Nachtmeuchlers
16821	Kopfschutz des Nachtmeuchlers
16822	Hose des Nachtmeuchlers
16823	Schulterklappen des Nachtmeuchlers
16824	Stiefel des Nachtmeuchlers
16825	Armreifen des Nachtmeuchlers
16826	Handschuhe des Nachtmeuchlers
16827	Gürtel des Nachtmeuchlers
16828	Gürtel des Cenarius
16829	Stiefel des Cenarius
16830	Armschienen des Cenarius
16831	Handschuhe des Cenarius
16832	Blutfangschiftung
16833	Gewand des Cenarius
16834	Helm des Cenarius
16835	Gamaschen des Cenarius
16836	Schiftung des Cenarius
16837	Stiefel der Erdenwut
16838	Gürtel der Erdenwut
16839	Stulpen der Erdenwut
16840	Armschienen der Erdenwut
16841	Gewand der Erdenwut
16842	Helm der Erdenwut
16843	Beinschützer der Erdenwut
16844	Schulterklappen der Erdenwut
16845	Brustplatte des Riesenjägers
16846	Helm des Riesenjägers
16847	Gamaschen des Riesenjägers
16848	Schulterklappen des Riesenjägers
16849	Stiefel des Riesenjägers
16850	Armschienen des Riesenjägers
16851	Gürtel des Riesenjägers
16852	Handschuhe des Riesenjägers
16853	Brustschutz der Gerechtigkeit
16854	Helm der Gerechtigkeit
16855	Beinplatten der Gerechtigkeit
16856	Schiftung der Gerechtigkeit
16857	Armschienen der Gerechtigkeit
16858	Gürtel der Gerechtigkeit
16859	Stiefel der Gerechtigkeit
16860	Stulpen der Gerechtigkeit
16861	Armschienen der Macht
16862	Sabatons der Macht
16863	Stulpen der Macht
16864	Gürtel der Macht
16865	Brustplatte der Macht
16866	Helm der Macht
16867	Beinplatten der Macht
16868	Schulterstücke der Macht
16869	Der Schädel des Wahrsagers
16870	Der Schädel des Somnus
16871	Der Schädel des Chronalis
16872	Der Schädel des Axtroz
16873	Geschnürte Fellhandschuhe
16882	Ramponierte Plunderkiste
16883	Abgenutzte Plunderkiste
16884	Stabile Plunderkiste
16885	Schwere Plunderkiste
16886	Gesetzlosensäbel
16887	Hexenfinger
16888	Glanzloses Drachenfeueramulett
16889	Polierter Wanderstab
16890	Schichtmetallentersäbel
16891	Tonsteinkurzschwert
16892	Geringer Seelenstein
16893	Seelenstein
16894	Klare Kristallrute
16895	Großer Seelenstein
16896	Erheblicher Seelenstein
16897	Brustschutz des Stormrage
16898	Stiefel des Stormrage
16899	Handschützer des Stormrage
16900	Bedeckung des Stormrage
16901	Beinschützer des Stormrage
16902	Schulterstücke des Stormrage
16903	Gürtel des Stormrage
16904	Armschienen des Stormrage
16905	Blutfangbrustharnisch
16906	Blutfangstiefel
16907	Blutfanghandschuhe
16908	Blutfangkapuze
16909	Blutfanghose
16910	Blutfanggürtel
16911	Blutfangarmschienen
16912	Stiefel des Netherwinds
16913	Handschuhe des Netherwinds
16914	Krone des Netherwinds
16915	Hose des Netherwinds
16916	Roben des Netherwinds
16917	Mantel des Netherwinds
16918	Bindungen des Netherwinds
16919	Stiefel der Erhabenheit
16920	Handschützer der Erhabenheit
16921	Heiligenschein der Erhabenheit
16922	Gamaschen der Erhabenheit
16923	Roben der Erhabenheit
16924	Schulterstücke der Erhabenheit
16925	Gürtel der Erhabenheit
16926	Bindungen der Erhabenheit
16927	Stiefel der Nemesis
16928	Handschuhe der Nemesis
16929	Schädelkappe der Nemesis
16930	Gamaschen der Nemesis
16931	Roben der Nemesis
16932	Schiftung der Nemesis
16933	Gürtel der Nemesis
16934	Armschienen der Nemesis
16935	Armschienen des Drachenjägers
16936	Gürtel des Drachenjägers
16937	Schiftung des Drachenjägers
16938	Beinschützer des Drachenjägers
16939	Helm des Drachenjägers
16940	Stulpen des Drachenjägers
16941	Schienbeinschützer des Drachenjägers
16942	Brustplatte des Drachenjägers
16943	Armschienen der zehn Stürme
16944	Gürtel der zehn Stürme
16945	Schulterklappen der zehn Stürme
16946	Beinplatten der zehn Stürme
16947	Helm der zehn Stürme
16948	Stulpen der zehn Stürme
16949	Schienbeinschützer der zehn Stürme
16950	Brustplatte der zehn Stürme
16951	Bindungen des Richturteils
16952	Gürtel des Richturteils
16953	Schiftung des Richturteils
16954	Beinplatten des Richturteils
16955	Krone des Richturteils
16956	Stulpen des Richturteils
16957	Sabatons des Richturteils
16958	Brustplatte des Richturteils
16959	Armreifen des Zorns
16960	Gürtelbund des Zorns
16961	Schulterstücke des Zorns
16962	Beinplatten des Zorns
16963	Helm des Zorns
16964	Stulpen des Zorns
16965	Sabatons des Zorns
16966	Brustplatte des Zorns
16967	Feralas Ahi
16968	Sar'theris-Barsch
16969	Blauwimpel von der ungezähmten Küste
16970	Nebelschilf-Mahi-Mahi
16971	Muschelette Surprise
16972	Karangs Banner
16973	Phiole mit Düsterwasser
16974	Leere Wasserphiole
16975	Warsongschärpe
16976	Murguts Totem
16977	Warsongstiefel
16978	Warsongstulpen
16979	Flimmerkernhandschuhe
16980	Flimmerkernmantel
16981	Eulenbarts Armschienen
16982	Kernhundstiefel
16983	Schmelzhelm
16984	Schwarze Drachenschuppenstiefel
16985	Windsucher-Stiefel
16986	Sandspitzen-Handschuhe
16987	Kreischergürtel
16988	Feurige Kettenschultern
16989	Feuriger Kettengurt
16990	Grimmlingumhang
16991	Triagenverband
16992	Smokeys Sprengstoff-Schleuder
16993	Smokeys Feuerspucker
16994	Dämmerschwingenhandschuhe
16995	Dämmerschwingenmantel
16996	Gorewood-Bogen
16997	Sturmwüter
16998	Hochheiliger Beschützer
16999	Königliches Siegel von Alexis
17000	Band des Gespenstes
17001	Elementarkreis
17002	Giftspeier
17003	Schädelsteinhammer
17004	Sarahs Wegweiser
17005	Landgardentunika
17006	Kobaltblaue Beinschützer
17007	Steinreißerstulpen
17008	Kleine Rolle
17009	Kopf von Botschafter Malcin
17010	Feuerkern
17011	Lavakern
17012	Kernleder
17013	Dunkeleisengamaschen
17014	Dunkeleisenarmschienen
17015	Dunkeleisenhäscher
17016	Dunkeleisenzerstörer
17017	Muster: Flimmerkernmantel
17018	Muster: Flimmerkernhandschuhe
17019	Arkaner Staub
17020	Arkanes Pulver
17021	Wilde Beeren
17022	Muster: Kernhundstiefel
17023	Muster: Schmelzhelm
17024	Wilde Wurzel
17025	Muster: Schwarze Drachenschuppenstiefel
17026	Wilder Dornwurz
17027	Duftkerze
17028	Heilige Kerze
17029	Hochheilige Kerze
17030	Ankh
17031	Rune der Teleportation
17032	Rune der Portale
17033	Symbol der Offenbarung
17034	Ahornsamenkorn
17035	Schlingendornsamenkorn
17036	Eschenholzsamenkorn
17037	Hainbuchensamenkorn
17038	Eisenholzsamenkorn
17039	Schädelbrecher
17042	Nagelspeier
17043	Zelotenrobe
17044	Wille des Märtyrers
17045	Blut des Märtyrers
17046	Klinge des Ausweidens
17047	Flimmernde Amicia
17048	Rumsey-Rum
17049	Pläne: Feuriger Kettengurt
17050	Chans imperiale Roben
17051	Pläne: Dunkeleisenarmschienen
17052	Pläne: Dunkeleisengamaschen
17053	Pläne: Feurige Kettenschultern
17054	Joonhos Gnade
17055	Changuk-Zerkracher
17056	Leichte Feder
17057	Glänzende Fischschuppen
17058	Fischöl
17059	Pläne: Dunkeleisenhäscher
17060	Pläne: Dunkeleisenzerstörer
17061	Junos Schatten
17062	Rezept: Mithrilkopfforelle
17063	Band von Accuria
17064	Splitter der Schuppe
17065	Medaillon der beständigen Macht
17066	Drillbohrer-Scheibe
17067	Zauberfoliant des uralten Grundsteins
17068	Todesbringer
17069	Schläger-Mal
17070	Fangzahn der Mystiker
17071	Räuderipper
17072	Blasterwerfer
17073	Erderschütterer
17074	Schattenschlag
17075	Vis'kag der Blutvergießer
17076	Knochenhäschers Schneide
17077	Purpurroter Schocker
17078	Saphirontuch
17082	Splitter der Flamme
17102	Umhang der verhüllten Nebel
17103	Magierklinge des Azurlieds
17104	Rückgratschnitter
17105	Aurastein-Hammer
17106	Malistar-Verteidiger
17107	Drachenblut-Cape
17108	Mal der Abwehr
17109	Halsschmuck der Erleuchtung
17110	Siegel des Erzmagiers
17111	Medaillon des lodernden Zorns
17112	Verwüster des Lichthimmels
17113	Bewahrer des Bernsteinsiegels
17114	Arajs Phylakterium-Splitter
17115	Eichhörnchen-Marke
17116	Eichhörnchen-Marke
17117	Rattenfänger-Flöte
17118	Karton mit eigenartigem Fleisch
17119	Untergrundratten-Kebab
17124	Emblem des Syndikats
17125	Siegel von Ravenholdt
17126	Eleganter Brief
17142	Splitter der Entweihten
17182	Sulfuras, Hand von Ragnaros
17183	Zerbeulter Rundschild
17184	Kleiner Schild
17185	Runder Rundschild
17186	Kleine Tartsche
17187	Bebänderter Rundschild
17188	Beringter Rundschild
17189	Metallrundschild
17190	Verschnörkelter Rundschild
17191	Szepter von Celebras
17192	Verstärkte Tartsche
17193	Sulfuronhammer
17194	Festtagsgewürze
17195	Unechter Mistelzweig
17196	Festtagsgeister
17197	Lebkuchen
17198	Eierflip
17199	Verdorbener Eierflip
17200	Rezept: Lebkuchen
17201	Rezept: Eierflip
17202	Schneeball
17203	Sulfuronblock
17204	Auge von Sulfuras
17222	Spinnenwurst
17223	Donnerschlag
17224	Wahrsage-Zielfernrohr
17242	Schlüssel zu Salems Truhe
17262	James' Schlüssel
17302	Festtagsgeschenk mit blauem Band
17303	Geschenkpapier mit blauem Band
17304	Geschenkpapier mit grünem Band
17305	Festtagsgeschenk mit grünem Band
17306	Blut eines Stormpike-Soldaten
17307	Geschenkpapier mit lila Band
17308	Festtagsgeschenk mit lila Band
17309	Disharmonische Armschienen
17310	Aspekt von Neptulon
17322	Auge des Glutsehers
17323	Mulvericks Signal
17324	Guses Signal
17325	Jeztors Signal
17326	Fleisch eines Stormpike-Soldaten
17327	Fleisch eines Stormpike-Lieutenants
17328	Fleisch eines Stormpike-Kommandanten
17329	Hand von Lucifron
17330	Hand von Sulfuron
17331	Hand von Gehennas
17332	Hand von Shazzrah
17333	Wässrige Quintessenz
17344	Bonbonstange
17345	Silithidenglibber
17346	Verkrustetes Silithidenobjekt
17347	Menschenfährtenleser des Syndikats (MURP)
17348	Erhebliches Heilgebräu
17349	Überragendes Heilgebräu
17351	Erhebliches Managebräu
17352	Überragendes Managebräu
17353	Stormpike-Angriffsbefehle
17354	Meister Rysons allsehendes Auge
17355	Rabines Brief
17362	Rysons Signal
17363	Rysons Signal
17364	Wahrsage-Zielfernrohr
17384	Zinfizzlexs tragbare Schreddereinheit
17402	Altvater Winters Bier
17403	Steamwheedle-Prickelschnaps
17404	Bohnengebräu
17405	Grüner Gartentee
17406	Festtagskäserad
17407	Graccus hausgemachte Fleischpastete
17408	Brachländer Würstchen
17409	Verkrustetes Kristallfragment
17410	Zinfizzlexs tragbare Schreddereinheit
17411	Dampfsäge
17413	Kodex: Gebet der Seelenstärke
17414	Kodex: Gebet der Seelenstärke II
17422	Rüstungsfetzen
17423	Sturmkristall
17442	Angriffsbefehle der Frostwolf
17502	Frostwolf Medaille des Soldaten
17503	Frostwolf Medaille des Lieutenants
17504	Frostwolf Medaille des Kommandanten
17505	Ichmans Signal
17506	Vipores Signal
17507	Slidores Signal
17508	Zwingstein-Rundschild
17522	Irondeep-Vorräte
17523	Smokeys Tuch
17542	Coldtooth-Vorräte
17562	Schreckenszwirnstiefel des Hauptmanns
17563	Schreckensgewirkte Armschienen des Kürassiers
17564	Schreckenszwirnhandschuhe des Hauptmanns
17565	Schreckensgewirkter Gürtel des Kürassiers
17566	Kopfschutz des Feldkommandanten
17567	Schreckenszwirnbeinlinge des Kürassiers
17568	Schreckenszwirnrobe des Kürassiers
17569	Schreckenszwirnmantel des Feldkommandanten
17570	Schreckenszwirnkapuze des Feldherren
17571	Schreckenszwirngamaschen des Zornbringers
17572	Schreckenszwirnrobe des Zornbringers
17573	Schreckenszwirnschultern des Feldherren
17574	Schreckensgewirkter Gürtel des Zornbringers
17575	Schreckensgewirkte Armschienen des Zornbringers
17576	Schreckenszwirnstiefel des Blutgardisten
17577	Schreckenszwirnhandschuhe des Blutgardisten
17578	Koronale des Feldmarschalls
17579	Schreckenszwirngamaschen des Marschalls
17580	Schreckenszwirnschultern des Feldmarschalls
17581	Schreckenszwirnrobe des Feldmarschalls
17582	Schreckensgewirkte Manschetten des Marschalls
17583	Schreckenszwirnstiefel des Marschalls
17584	Schreckenszwirnhandschuhe des Marschalls
17585	Schreckensgewirkte Schärpe des Marschalls
17586	Schreckenszwirnstiefel des Kriegsherren
17587	Schreckensgewirkte Armschienen des Kriegsherrn
17588	Schreckenszwirnhandschuhe des Kriegsherren
17589	Schreckensgewirkter Gürtel des Kriegsherrn
17590	Schreckenszwirnmantel des Kriegsfürsten
17591	Schreckenszwirnkapuze des Kriegsfürsten
17592	Schreckenszwirnrobe des Kriegsfürsten
17593	Schreckenszwirnhose des Kriegsherren
17594	Satinstiefel des Hauptmanns
17595	Satin-Manschetten des Kürassiers
17596	Satinhandschuhe des Hauptmanns
17597	Satin-Kordel des Kürassiers
17598	Diadem des Feldkommandanten
17599	Satingamaschen des Kürassiers
17600	Satinroben des Kürassiers
17601	Satinamicia des Feldkommandanten
17602	Kopfputz des Feldmarschalls
17603	Satinhose des Marschalls
17604	Satinmantel des Feldmarschalls
17605	Satintracht des Feldmarschalls
17606	Satin-Armschienen des Marschalls
17607	Satinsandalen des Marschalls
17608	Satinhandschuhe des Marschalls
17609	Satin-Schärpe des Marschalls
17610	Satinkutte des Feldherren
17611	Satinbeinkleider des Zornbringers
17612	Satintracht des Zornbringers
17613	Satinschulterpolster des Feldherren
17614	Satin-Schärpe des Zornbringers
17615	Satin-Manschetten des Zornbringers
17616	Satinstiefel des Blutgardisten
17617	Satinhandschuhe des Blutgardisten
17618	Satinstiefel des Kriegsherren
17619	Satin-Armschienen des Kriegsherrn
17620	Satinhandschuhe des Kriegsherren
17621	Satin-Sattelgurt des Kriegsherrn
17622	Satinmantel des Kriegsfürsten
17623	Satinkutte des Kriegsfürsten
17624	Satinroben des Kriegsfürsten
17625	Satingamaschen des Kriegsherren
17626	Frostwolfmaulkorb
17642	Alteracwidderbalg
17643	Frostwolfbalg
17662	Gestohlene Leckereien
17682	Buch: Gabe der Wildnis
17683	Buch: Gabe der Wildnis II
17684	Theradrische Kristallschnitzerei
17685	Kokelwälder Probierpaket
17686	Meisterjägerbogen
17687	Meisterjäger-Gewehr
17688	Dschungel-Stiefel
17689	Stormpike-Zähmungshalsband
17690	Abzeichen der Frostwolf Rang 1
17691	Abzeichen der Stormpike Rang 1
17692	Hornring
17693	Beschichtete himmelblaue Phiole
17694	Band der Faust
17695	Kastanienbrauner Mantel
17696	Gefüllte himmelblaue Phiole
17702	Celebriangriff
17703	Celebriandiamant
17704	Schneide des Winters
17705	Hauklinge
17706	Pläne: Schneide des Winters
17707	Edelsteinsplitter-Herz
17708	Elixier der Frostmacht
17709	Rezept: Elixier der Frostmacht
17710	Charissteindolch
17711	Elementarfelsgamaschen
17712	Winterhauch-Verkleidungsset
17713	Schwarzsteinring
17714	Armschienen der Steinprinzessin
17715	Auge von Theradras
17716	Schneemeister 9000
17717	Megaschuss-Gewehr
17718	Gizlocks supertechnischer Rundschild
17719	Fokusschwert des Erfinders
17720	Bauplan: Schneemeister 9000
17721	Handschuhe des Altvaters
17722	Muster: Handschuhe des Altvaters
17723	Grünes Festtagshemd
17724	Muster: Grünes Festtagshemd
17725	Formel: Waffe - Wintermacht
17726	Kokelwälder Spezialgeschenk
17727	Kokelwälder Geschenkpackung
17728	Albinokrokschuppenstiefel
17730	Gatorbiss-Axt
17731	Rolle von Celebras
17732	Faulschnappers Mantel
17733	Steinfaust
17734	Helm des Berges
17735	Das Winterhauchfest
17736	Felsengriffstulpen
17737	Wolkenstein
17738	Klaue von Celebras
17739	Hainhütertuch
17740	Sterndeuterkopfputz
17741	Umarmung der Natur
17742	Fungustuchrüstung
17743	Rute der Wiederauferstehung
17744	Herz von Noxxion
17745	Giftiger Schütze
17746	Noxxions Fesseln
17747	Schlingwurzel
17748	Vinerot-Sandalen
17749	Phytohaut-Schiftung
17750	Chloromesh-Gurt
17751	Gaiagamaschen
17752	Peitsche des Satyrs
17753	Ziel des tiefgrünen Bewahrers
17754	Höllische Schwindlergamaschen
17755	Satyrmähnenschärpe
17756	Schattensplitter
17757	Amulett der Geister
17758	Amulett der Vereinigung
17759	Mal der Resolution
17760	Samenkorn des Lebens
17761	Edelstein des ersten Khans
17762	Edelstein des zweiten Khans
17763	Edelstein des dritten Khans
17764	Edelstein des vierten Khans
17765	Edelstein des fünften Khans
17766	Prinzessin Theradras' Szepter
17767	Blütenprachtkopfstück
17768	Ring der Waldsaat
17769	Weisenblattschiftung
17770	Astkrallenstulpen
17771	Elementiumbarren
17772	Schattensplitteranhänger des Eifers
17773	Vorwarnender Schattensplitteranhänger
17774	Mal der Auserwählten
17775	Scharfsinn-Roben
17776	Rüstringhelm
17777	Unerbittliche Kette
17778	Weisenblattgurt
17779	Schulterstücke des Steinkolosses
17780	Klinge der ewigen Dunkelheit
17781	Die Anleitung des Pariahs
17782	Splitter des Talismans des Bindens
17783	Fragment des Talismans des Bindens
17822	Frostwolfkarten
17823	Stormpike-Schlachtpläne
17849	Banner der Stormpike
17850	Banner der Frostwolf
17900	Abzeichen der Stormpike Rang 2
17901	Abzeichen der Stormpike Rang 3
17902	Abzeichen der Stormpike Rang 4
17903	Abzeichen der Stormpike Rang 5
17904	Abzeichen der Stormpike Rang 6
17905	Abzeichen der Frostwolf Rang 2
17906	Abzeichen der Frostwolf Rang 3
17907	Abzeichen der Frostwolf Rang 4
17908	Abzeichen der Frostwolf Rang 5
17909	Abzeichen der Frostwolf Rang 6
17922	Löwenfellrüstung
17943	Steinfaust
17962	Blauer Sack voller Edelsteine
17963	Grüner Sack voller Edelsteine
17964	Grauer Sack voller Edelsteine
17965	Gelber Sack voller Edelsteine
17966	Rucksack aus Onyxias Haut
17967	Aufbereitete Schuppe von Onyxia
17968	Aufgeladene Schuppe von Onyxia
17969	Roter Sack voller Edelsteine
17982	Ragnaros Kern
18022	Königliches Siegel von Alexis
18023	Blutrubin Anhänger
18042	Thoriumpfeile
18043	Kohlebergarbeiter Stiefel
18044	Hurleys Humpen
18045	Zartes Wolfsteak
18046	Rezept: Zartes Wolfsteak
18047	Flammenläufer
18048	Meisterschmiedhammer
18082	Zum'rahs Hexerstab
18083	Jumanza Handschutz
18102	Drachenreiterstiefel
18103	Band des Nachsinnens
18104	Gurt der brennenden Wut
18142	Abgeschlagener Nachtelfenkopf
18143	Ein Büschel Gnomhaar
18144	Menschliche Knochensplitter
18145	Taurenhuf
18146	Trollmojo der Darkspear
18147	Herz eines Verlassenen
18148	Korraks Schädel
18149	Rune des Rückrufs
18150	Rune des Rückrufs
18151	Gefüllte Amethystphiole
18152	Amethystphiole
18153	Roter Moro'gai  Edelstein
18154	Blizzard Briefpapier
18155	Blauer Moro'gai  Edelstein
18156	Grüner Moro'gai  Edelstein
18157	Schwarzer Moro'gai  Edelstein
18158	Goldener Moro'gai  Edelstein
18159	Weißer Moro'gai  Edelstein
18160	Rezept: Disteltee
18168	Machtreaktive Scheibe
18169	Flammenmantel der Dämmerung
18170	Frostmantel der Dämmerung
18171	Arkaner Mantel der Dämmerung
18172	Naturmantel der Dämmerung
18173	Schattenmantel der Dämmerung
18182	Chromatischer Mantel der Dämmerung
18202	Eskhandars linke Klaue
18203	Eskhandars rechte Klaue
18204	Eskhandars Pelz
18205	Eskhandars Halsband
18206	Zwergenrückgrat
18207	Orczahn
18208	Tuch der Segnung
18209	Energiegeladene Zündkerze
18222	Dornenranke
18223	Gezackte Blüte
18224	Wildschlagwurzel
18225	Abgetragene Laufschuhe
18226	Ein besiegelter Vertrag
18227	Abgekauter Schnuller
18228	Autogramm von Skippi
18229	Nat Pagles Handbuch für Extrem-Angler
18230	Zerbrochener I.W.I.N. Knopf
18231	Ärmelloses T-Shirt
18232	Feldreparaturbot-74A
18233	Verweintes Taschentuch
18234	Dokument von Schießeisen-Importe
18235	Bauplan: Feldreparaturbot-74A
18236	Gordoks Beißring
18237	Doggenkiefer
18238	Schattenhauthandschuhe
18239	Muster: Schattenhauthandschuhe
18240	Ogergerbemittel
18241	Schwarzes Schlachtrosszaumzeug
18242	Zügel des schwarzen Kriegstigers
18243	Schwarzer Schlachtenschreiter
18244	Schwarzer Kriegswidder
18245	Horn des schwarzen Kriegswolfs
18246	Pfeife des schwarzen Kriegsraptors
18247	Schwarzer Kriegskodo
18248	Rotes Skelettschlachtross
18249	Mondsichelschlüssel
18250	Gordokfesselschlüssel
18251	Kernrüstungsset
18252	Muster: Kernrüstungsset
18253	Erheblicher Verjüngungstrank
18254	Runn Tum Knolle Surprise
18255	Runn Tum Knolle
18256	Magieerfüllte Phiole
18257	Rezept: Erheblicher Verjüngungstrank
18258	Ogeranzug der Gordok
18259	Formel: Waffe - Zauberkraft
18260	Formel: Waffe - Heilkraft
18261	Buch der Zauberformeln
18262	Elementarwetzstein
18263	Flimmerkernwickeltücher
18264	Pläne: Elementarwetzstein
18265	Muster: Flimmerkernwickeltücher
18266	Schlüssel für die Gordokhoftür
18267	Rezept: Runn Tum Knolle Surprise
18268	Schlüssel für die Gordokinnentür
18269	Grüner Gordokgrog
18282	Kernscharfschützengewehr
18283	Biznicks 247x128 treffsicheres Zielfernrohr
18284	Kreegs Hauweg-Starkbier
18285	Kristallisierter Manasplitter
18286	Verdichtetes Manafragment
18287	Lichteraus
18288	Molasses Feuerwasser
18289	Stachelige Dornenhalskette
18290	Bauplan: Biznicks 247x128 treffsicheres Zielfernrohr
18291	Bauplan: Machtreaktive Scheibe
18292	Bauplan: Kernscharfschützengewehr
18294	Elixier der verbesserten Wasseratmung
18295	Phasenstiefel
18296	Schützenbänder
18297	Dornlingsamen
18298	Ungezügelte Beinlinge
18299	Hydrobrutessenz
18300	Hyjal Nektar
18301	Lethtendris Zauberstab
18302	Band der Lebenskraft
18303	Behänder Rundschild
18304	Grünwurzel-Panzerung
18305	Wellenbrecher-Beinschützer
18306	Handschuhe der Nebelschatten
18307	Springflut-Schuhe
18308	Schlauer Hut
18309	Handschuhe der Wiederherstellung
18310	Satanische Machete
18311	Quel'doraikanalisierungsrute
18312	Energiegeladene Brustplatte
18313	Helm des Bewusstseins
18314	Ring der dämonischen List
18315	Ring der dämonischen Kraft
18316	Obsidianschmuckstück
18317	Sturmtalisman
18318	Gnädige Schienbeinschützer
18319	Inbrünstiger Helm
18320	Dämonenherzschiftung
18321	Energetische Rute
18322	Wasserschwallstiefel
18323	Satyrbogen
18324	Wellenschnitzler
18325	Teufelshaut-Kappe
18326	Schneidenstulpen
18327	Peitschenrankenschnur
18328	Schattenlaubmantel
18329	Arkanum der Schnelligkeit
18330	Arkanum des Fokus
18331	Arkanum des Schutzes
18332	Buchband der Schnelligkeit
18333	Buchband des Fokus
18334	Buchband des Schutzes
18335	Makelloser schwarzer Diamant
18336	Stulpen der Gordokmacht
18337	Orphische Armschienen
18338	Zauberstab der Arkanen Kraft
18339	Eidolonumhang
18340	Eidolontalisman
18341	Quel'doraischärpe
18342	Quel'doraischutz
18343	Versteinertes Band
18344	Steinrindenstulpen
18345	Murmelnder Ring
18346	Fadenscheinige Hose
18347	Gut ausbalancierte Axt
18348	Quel'Serrar
18349	Stulpen der Zielgenauigkeit
18350	Verstärkender Umhang
18351	Magisch versiegelte Armschienen
18352	Versteinerter Rindenschild
18353	Steinblumenstab
18354	Pimgibs Halsband
18355	Ferras Halsband
18356	Garona: Eine Studie über Heimlichkeit und Verrat
18357	Kodex der Verteidigung
18358	Das Arkanistenkochbuch
18359	Vom Licht und wie man es schwingt
18360	Schatten einspannen
18361	Das größte Volk von Jägern
18362	Heiliger Fleischklops: Was das Licht Dir nicht erzählt
18363	Frostschock und Du
18364	Der Smaragdgrüne Traum
18365	Eine zerlesene Ausgabe von "Nat Pagles Extremangeln"
18366	Gordoks Handschützer
18367	Gordoks Stulpen
18368	Gordoks Handschuhe
18369	Gordoks Handlappen
18370	Wachsamkeitsglücksbringer
18371	Talisman des Gedankenzapfens
18372	Klinge des Neumonds
18373	Brustplatte der Gelassenheit
18374	Flammengezeichnete Schultern
18375	Armschienen der Sonnenfinsternis
18376	Kampferprobter Streitkolben
18377	Schnellziehhandschuhe
18378	Silbermondbeinlinge
18379	Abscheuliche Schienbeinschützer
18380	Unheimliche Verstärkte Beinplatten
18381	Anhänger des Bösen Blicks
18382	Fluktuierender Umhang
18383	Machterfüllte Stulpen
18384	Gallengetränkte Schiftung
18385	Robe der Immerwährenden Nacht
18386	Hose des Paters
18387	Hellfunkenhandschuhe
18388	Steinzertrümmerer
18389	Umhang des Kosmos
18390	Wirrmoosbeinlinge
18391	Augenstielkordel
18392	Ablenkender Dolch
18393	Wucherborkenbindungen
18394	Handgelenksschützer des dämonischen Heulens
18395	Smaragdflammenring
18396	Gedankenschnitzer
18397	Ältestenmagus-Anhänger
18398	Gezeitenschleife
18399	Meeresbrise
18400	Ring des lebenden Steins
18401	Nostros Kompendium des Drachentötens
18402	Leuchtender Kristallring
18403	Drachentötersignet
18404	Zahn Onyxias
18405	Gürtel des Erzmagiers
18406	Talisman mit Onyxiablut
18407	Teufelsstoffhandschuhe
18408	Infernohandschuhe
18409	Mondstoffhandschuhe
18410	Sprinterschwert
18411	Flotte Stiefel
18412	Kernfragment
18413	Schutzumhang der Verteidigung
18414	Muster: Gürtel des Erzmagiers
18415	Muster: Teufelsstoffhandschuhe
18416	Muster: Infernohandschuhe
18417	Muster: Mondstoffhandschuhe
18418	Muster: Schutzumhang der Verteidigung
18420	Knochenzermalmer
18421	Hinterwaldhelm
18422	Onyxias Kopf
18423	Onyxias Kopf
18424	Seggenstiefel
18425	Kreeg's Becher
18426	Lethtendris' Netz
18427	Umhang des Waffenträgers
18428	Insignien des Schlachtrufers
18429	Plattenarmschienen des Rottenmeisters
18430	Plattenarmschienen des Rottenmeisters
18432	Panzerhandgelenksschutz des Rottenmeisters
18434	Drachenlederarmschützer des Rottenmeisters
18435	Lederarmschützer des Rottenmeisters
18436	Drachenlederarmschützer des Rottenmeisters
18437	Seidenmanschetten des Rottenmeisters
18438	Marke des Landsknechts
18440	Cape des Landsknechts
18441	Cape des Landsknechts
18442	Abzeichen des Feldwebels
18443	Abzeichen des Feldwebels
18444	Abzeichen des Feldwebels
18445	Plattenhandgelenksschutz des Fähnrichs
18447	Plattenhandgelenksschutz des Fähnrichs
18448	Kettenarmschützer des Fähnrichs
18449	Kettenarmschützer des Fähnrichs
18450	Robe der Verbrennung
18451	Hyänenhautgürtel
18452	Lederarmsplinte des Fähnrichs
18453	Lederarmsplinte des Fähnrichs
18454	Drachenlederarmsplinte des Fähnrichs
18455	Drachenlederarmsplinte des Fähnrichs
18456	Seidenmanschetten des Fähnrichs
18457	Seidenmanschetten des Fähnrichs
18458	Bescheidene Armschützer
18459	Kavaliershandgelenksschützer
18460	Unausgereifte Handkanone
18461	Umhang des Waffenträgers
18462	Gezackte Knochenfaust
18463	Ogertaschenmesser
18464	Nasenring der Gordok
18465	Königliches Siegel von Eldre'Thalas
18466	Königliches Siegel von Eldre'Thalas
18467	Königliches Siegel von Eldre'Thalas
18468	Königliches Siegel von Eldre'Thalas
18469	Königliches Siegel von Eldre'Thalas
18470	Königliches Siegel von Eldre'Thalas
18471	Königliches Siegel von Eldre'Thalas
18472	Königliches Siegel von Eldre'Thalas
18473	Königliches Siegel von Eldre'Thalas
18475	Seltsam magischer Gürtel
18476	Matschfleckige Stiefel
18477	Zottige Beinlinge
18478	Hyänenhautwams
18479	Aasskorpidhelm
18480	Skarabäusplattenhelm
18481	Schädelknacker-Streitkolben
18482	Ogerzahnstocherschießer
18483	Zauberstab der Manakanalisierung
18484	Cho'Rushs Klinge
18485	Schild des Beobachters
18486	Mondstoffrobe
18487	Muster: Mondstoffrobe
18488	Erhitzte Uralte Klinge
18489	Unbefeuerte Uralte Klinge
18490	Erkenntnisreiche Kapuze
18491	Lehrenspinner
18492	Behandelte Uralte Klinge
18493	Unförmige Eisenschiftung
18494	Baubehüters Schultern
18495	Verschanzmantel
18496	Heliotropenumhang
18497	Sublime Handgelenksschützer
18498	Heckenschneider
18499	Barrierenschild
18500	Angelaufener Elfenring
18501	Teufelsrankensplitter
18502	Monströse Gleve
18503	Kromcrushs Brustplatte
18504	Gurt der Einsicht
18505	Straßenräubergürtel
18506	Mungostiefel
18507	Stiefel des Vollmonds
18508	Armschienen der schnellen Flucht
18509	Chromatischer Umhang
18510	Balg der Wildnis
18511	Veränderlicher Umhang
18512	Larvensäure
18513	Eine stumpfe und glanzlose Elfenklinge
18514	Muster: Gurt der Einsicht
18515	Muster: Mungostiefel
18516	Muster: Armschienen der schnellen Flucht
18517	Muster: Chromatischer Umhang
18518	Muster: Balg der Wildnis
18519	Muster: Veränderlicher Umhang
18520	Barbarische Klinge
18521	Schmierige Metallstiefel
18522	Band des Ogerkönigs
18523	Hellleuchtender Stein
18524	Beinlinge der Zerstörung
18525	Armschienen des Wohlstands
18526	Krone des Ogerkönigs
18527	Harmonische Stulpen
18528	Zyklonschiftung
18529	Elementarer Plattengurt
18530	Ogergeschmiedete Halsberge
18531	Unerschütterlicher Schlägel
18532	Gedankenschwallrobe
18533	Gordoks Armschienen der Macht
18534	Rute des Ogermagiers
18535	Millis Schild
18536	Millis Lexikon
18537	Gegenangriffsleitstein
18538	Verderben der Treants
18539	Reliquiar der Reinheit
18540	Versiegeltes Reliquiar der Reinheit
18541	Schlagfertiges Cape
18542	Taifun
18543	Ring der Entropie
18544	Verdammnisstulpen
18545	Beinlinge der Arkanen Überlegenheit
18546	Infernalischer Hirnkasten
18547	Nieschmelzender Eisgurt
18562	Elementiumerz
18563	Fesseln des Windsuchers
18564	Fesseln des Windsuchers
18567	Elementarfluxus
18582	Die Zwillingsklingen von Azzinoth
18583	Kriegsgleve von Azzinoth (rechts)
18584	Kriegsgleve von Azzinoth (links)
18585	Ring der Treue
18586	Lonetrees Ring
18587	Goblin-Überbrückungskabel XL
18588	EZ-Thro-Dynamit II
18590	Blut tobender Bestien
18591	Behälter mit Blut
18592	Pläne: Sulfuronhammer
18594	Mächtige Zephyriumladung
18595	Blutopal
18597	Pfeife des orcischen Waisenkindes
18598	Pfeife des menschlichen Waisenkindes
18600	Foliant der arkanen Brillanz
18601	Leuchtendes Kristallgefängnis
18602	Foliant der Opferung
18603	Satyrblut
18604	Träne der Hederine
18605	Eingekerkerte Verdammniswache
18606	Schlachtstandarte der Allianz
18607	Schlachtstandarte der Horde
18608	Segnung
18609	Bannfluch
18610	Beißende Machete
18611	Gamaschen der Knarzklauen
18612	Blutige Kettenstiefel
18622	Reine Teufelsessenz (Jaedenar)
18623	Reine Teufelsessenz (Dunkles Portal)
18624	Reine Teufelsessenz (Azshara)
18625	Kroshius' Höllenbestienkern
18626	Teufelsfeuer
18627	Gong von Dethmoora
18628	Vertrag der Thoriumbruderschaft
18629	Schwarzer Leitstein
18630	Aufflackern des Jüngsten Gerichts
18631	Echtsilberumwandler
18632	Moonbrook Tumult-Toffee
18633	Styleens Sauerlolly
18634	Gyrofrosteisreflektor
18635	Bellaras Nussriegel
18636	Defekte Überbrückungskabel XL
18637	Großer Rekombobulator
18638	Hyperstrahlender Flammenreflektor
18639	Ultrablendender Schattenreflektor
18640	Lustiger Spaßstein
18641	Dichtes Dynamit
18642	Jainas Autogramm
18643	Cairnes Hufabdruck
18645	Gnomsicher Alarm-O-Bot
18646	Das Auge der Offenbarung
18647	Bauplan: Rotes Feuerwerk
18648	Bauplan: Grünes Feuerwerk
18649	Bauplan: Blaues Feuerwerk
18650	Bauplan: EZ-Thro-Dynamit II
18651	Bauplan: Echtsilberumwandler
18652	Bauplan: Gyrofrosteisreflektor
18653	Bauplan: Goblin-Überbrückungskabel XL
18654	Bauplan: Gnomischer Alarm-O-Bot
18655	Bauplan: Großer Rekombobulator
18656	Bauplan: Mächtige Zephyriumladung
18657	Bauplan: Hyperstrahlender Flammenreflektor
18658	Bauplan: Ultrablendender Schattenreflektor
18659	Splitter von Nordrassil
18660	Weltvergrößerer
18661	Bauplan: Weltvergrößerer
18662	Schwerer Lederball
18663	J'eevees Glas
18664	Eine Abhandlung über die militärischen Ränge
18665	Das Auge der Schatten
18670	Xorothianische Glyphen
18671	Baron Glutarrs Szepter
18672	Elementare Glut
18673	Lavinius' steiniger Balg
18674	Verhärtetes Steinband
18675	Militärische Ränge der Horde & Allianz
18676	Schärpe des Windhäschers
18677	Zephyrumhang
18678	Tempestrias gefrorene Halskette
18679	Kühler Ring
18680	Antiker Knochenbogen
18681	Begräbnisschal
18682	Ghulhaut-Beinlinge
18683	Hammer der Vesper
18684	Leicht opalschimmernder Ring
18686	Knochige Golemschultern
18687	Xorothianischer Sternenstaub
18688	Wichtel im Glas
18689	Illusionsumhang
18690	Geisterplattenbeinlinge
18691	Halskette des dunklen Beraters
18692	Todesrittersabatons
18693	Fröstelnde Handlappen
18694	Schattenhafte Panzerschienbeinschützer
18695	Verzauberter Foliant
18696	Umständlich runenverziertes Schild
18697	Kaltsteinschuhe
18698	Zerlumpte Lederkapuze
18699	Schiftung des eisigen Grabes
18700	Bösartige Armschienen
18701	Stimulierendes Band
18702	Gürtel der Gerufenen
18703	Uraltes versteinertes Blatt
18704	Sehne eines ausgewachsenen blauen Drachen
18705	Sehne eines ausgewachsenen schwarzen Drachen
18706	Meister der Arena
18707	Antiker runenverzierter Stab
18708	Versteinerte Rinde
18709	Arenahandgelenksschutz
18710	Arenaarmschienen
18711	Arenaarmbänder
18712	Arenaunterarmschienen
18713	Rhok'delar, Langbogen der uralten Bewahrer
18714	Uraltes in Sehnen eingewickeltes Laminablatt
18715	Lok'delar, Stab der uralten Bewahrer
18716	Aschebedeckte Stiefel
18717	Hammer des obersten Kreuzzüglers
18718	Helm des obersten Kreuzzüglers
18719	Das Herz des Verräters
18720	Schleier der Nathrezim
18721	Sperrfeuer-Gürtel
18722	Todesgriffe
18723	Animiertes Kettenhalsband
18724	Verzauberte Schwarzdrachensehne
18725	Friedensstifter
18726	Handschellen des Magistrats
18727	Purpurroter Filzhut
18728	Anastari Erbstück
18729	Kreischender Bogen
18730	Schattenhafte geschnürte Handlappen
18731	Muster: Schwerer Lederball
18734	Fahler Mondumhang
18735	Malekis Fußlappen
18736	Seuchenhundbeinlinge
18737	Knochenzersplitterndes Kriegsbeil
18738	Panzerrückgratarmbrust
18739	Chitinplattenbeinschützer
18740	Thuzadinschärpe
18741	Morlunes Armschienen
18742	Schulterschutz der Stratholmemiliz
18743	Anmutiger Umhang
18744	Seuchenfledermaus-Pelzhandschuhe
18745	Heilige Stoffhosen
18746	Orakel der Anrufung
18749	Verlorene Seele des Streitrosses
18752	Weihrauchschwenker
18753	Arkanitpferdegeschirr
18754	Teufelsgehärtete Armschienen
18755	Xorothianischer Feuerstab
18756	Beschützer der Schreckenswache
18757	Diabolischer Mantel
18758	Geisterklinge
18759	Bösartige Streitaxt
18760	Nekromantisches Band
18761	Berührung der Vergessenheit
18762	Splitter der grünen Flamme
18766	Zügel des schnellen Frostsäblers
18767	Zügel des schnellen Schattensäblers
18768	Zügel des schnellen Dämmerungssäblers
18769	Verzauberter Thoriumplattenpanzer
18770	Verzauberter Thoriumplattenpanzer
18771	Verzauberter Thoriumplattenpanzer
18772	Schneller grüner Roboschreiter
18773	Schneller weißer Roboschreiter
18774	Schneller gelber Roboschreiter
18775	Mit Mana angereichtertes Pferdefutter
18776	Schnelles Palomino
18777	Schneller Brauner
18778	Schnelles weißes Ross
18779	Untere Hälfte von 'Hochentwickelte Rüstungsschmiedekunst: Band 1'
18780	Obere Hälfte von 'Hochentwickelte Rüstungsschmiedekunst: Band 1'
18781	Untere Hälfte von 'Hochentwickelte Rüstungsschmiedekunst: Band 2'
18782	Obere Hälfte von 'Hochentwickelte Rüstungsschmiedekunst: Band 2'
18783	Untere Hälfte von 'Hochentwickelte Rüstungsschmiedekunst: Band 3'
18784	Obere Hälfte von 'Hochentwickelte Rüstungsschmiedekunst: Band 3'
18785	Schneller weißer Widder
18786	Schneller brauner Widder
18787	Schneller grauer Widder
18788	Schneller blauer Raptor
18789	Schneller olivfarbener Raptor
18790	Schneller orangener Raptor
18791	Purpurnes Skelettschlachtross
18792	Gesegnetes Arkanitpferdegeschirr
18793	Großer weißer Kodo
18794	Großer brauner Kodo
18795	Großer grauer Kodo
18796	Horn des schnellen braunen Wolfs
18797	Horn des schnellen Waldwolfs
18798	Horn des schnellen Grauwolfs
18799	Erlöste Seele des Streitrosses
18802	Schattenhafter Trank
18803	Überwärmter Isolierlavagreifer
18804	Lord Graysons Ranzen
18805	Kernhundzahn
18806	Im Kern geschmiedete Schienbeinschützer
18807	Helm der latenten Macht
18808	Handschuhe der hypnotischen Flamme
18809	Schärpe der geflüsterten Geheimnisse
18810	Wilde Wachstums-Schiftung
18811	Feuerfester Umhang
18812	Handgelenksschutz des wahren Flugs
18813	Ring der Bindung
18814	Halsschmuck des Feuerlords
18815	Essenz der reinen Flamme
18816	Klinge des Verderbens
18817	Krone der Zerstörung
18818	Mor'zuls Anweisungen
18819	Rohans Weihrauchschwenker
18820	Talisman der ephemeren Macht
18821	Ring des rasanten Schlags
18822	Scharfkantige Obsidianklinge
18823	Alte Kernlederhandschuhe
18824	Magmagehärtete Stiefel
18825	Aegis des Großmarschalls
18826	Schildwall des Obersten Kriegsfürsten
18827	Handaxt des Großmarschalls
18828	Spaltbeil des Obersten Kriegsfürsten
18829	Tiefenerde - Schiftung
18830	Zerreißer des Großmarschalls
18831	Streitaxt des Obersten Kriegsfürsten
18832	Unbarmherzige Klinge
18833	Bullseye des Großmarschalls
18834	Insignien der Horde
18835	Doppelbogen des Obersten Kriegsfürsten
18836	Repetierarmbrust des Großmarschalls
18837	Armbrust des Obersten Kriegsfürsten
18838	Langdolch des Großmarschalls
18839	Gefechtsheiltrank
18840	Schneide des Obersten Kriegsfürsten
18841	Gefechtsmanatrank
18842	Stab der Dominanz
18843	Rechte Handklinge des Großmarschalls
18844	Rechte Klaue des Obersten Kriegsfürsten
18845	Insignien der Horde
18846	Insignien der Horde
18847	Linke Handklinge des Großmarschalls
18848	Linke Klaue des Obersten Kriegsfürsten
18849	Insignien der Horde
18850	Insignien der Horde
18851	Insignien der Horde
18852	Insignien der Horde
18853	Insignien der Horde
18854	Insignien der Allianz
18855	Handkanone des Großmarschalls
18856	Insignien der Allianz
18857	Insignien der Allianz
18858	Insignien der Allianz
18859	Insignien der Allianz
18860	Der Straßenfeger des Obersten Kriegsfürsten
18861	Feuerschuppenbeinplatten
18862	Insignien der Allianz
18863	Insignien der Allianz
18864	Insignien der Allianz
18865	Prügler des Großmarschalls
18866	Knüttel des Obersten Kriegsfürsten
18867	Schlachthammer des Großmarschalls
18868	Pulverisierer des Obersten Kriegsfürsten
18869	Gleve des Großmarschalls
18870	Helm des Lebensspenders
18871	Schweinestecher des Obersten Kriegsfürsten
18872	Gamaschen des Manasturms
18873	Stab des Großmarschalls
18874	Kriegsstab des Obersten Kriegsfürsten
18875	Salamanderschuppengamaschen
18876	Claymore des Großmarschalls
18877	Großschwert des Obersten Kriegsfürsten
18878	Zauberdolch
18879	Schwerer Dunkeleisenring
18880	Schattensichels Kopf
18902	Zügel des schnellen Sturmsäblers
18904	Zorbins Ultra-Schrumpfer
18922	Geheimpläne: Feuriger Fluxus
18942	Feuriger Fluxus
18943	Dunkeleisenkissen
18944	Incendosaurierschuppe
18945	Dunkeleisenrückstände
18946	Kopf des Aufsehers Maltorius
18947	Wutschrammyetibalg
18948	Barbarische Armschienen
18949	Muster: Barbarische Armschienen
18950	Kissen von Zimmermädchen Kissenquetscher
18951	Evonices Landekissen
18952	Simones Kopf
18953	Klinfrans Kopf
18954	Solenors Kopf
18955	Artorius' Kopf
18956	Schrumpf-Überreste
18957	Buschklinge
18958	Wasserelementarkerne
18959	Schmiedewindform
18960	Ausguck-Handfernrohr
18961	Zukk'ashknochenpanzer
18962	Zornstachels Drüsen
18963	Schildkrötenei (Albino)
18964	Schildkrötenei (Flachkopf)
18965	Schildkrötenei (Falkenschnabel)
18966	Schildkrötenei (Lederrücken)
18967	Schildkrötenei (Oliv)
18969	Makelloser Yetibalg
18972	Perfekter Yetibalg
18984	Dimensionszerfetzer - Everlook
18986	Extrem sicherer Transporter: Gadgetzan
18987	Blackhands Befehl
19002	Kopf von Nefarian
19003	Kopf von Nefarian
19004	Schwacher Gesundheitsstein
19005	Schwacher Gesundheitsstein
19006	Geringer Gesundheitsstein
19007	Geringer Gesundheitsstein
19008	Gesundheitsstein
19009	Gesundheitsstein
19010	Großer Gesundheitsstein
19011	Großer Gesundheitsstein
19012	Erheblicher Gesundheitsstein
19013	Erheblicher Gesundheitsstein
19016	Gefäß der Wiedergeburt
19017	Essenz des Feuerfürsten
19018	Schlummernde vom Wind berührte Klinge
19019	Donnerzorn, Gesegnete Klinge des Windsuchers
19020	Bericht über die Zukk'ash
19022	Nat Pagles Extremangler FC-5000
19023	Katooms bester Köder
19024	Großmeister der Arena
19025	Himmelsfürsten-Federbusch
19026	Schlangenexplosionsfeuerwerk
19027	Bauplan: Schlangenexplosionsfeuerwerk
19028	Elegantes Kleid
19029	Horn des Frostwolfheulers
19030	Streitwidder der Stormpike
19031	Wappenrock der Frostwolf
19032	Wappenrock der Stormpike
19033	Slagtrees verlorene Werkzeuge
19034	Lards Brotzeit
19035	Lards besonderer Picknickkorb
19036	Letzte Botschaft an die Wildhammer
19037	Smaragdgipfelstulpen
19038	Ring des Feingefühls
19039	Zorbins wasserfester Hut
19040	Zorbins Mega-Schnitzler
19041	Pratts handgefertigte Tunika
19042	Jangdors handgefertigte Tunika
19043	Schwerer Gürtel der Holzschlundfeste
19044	Macht der Holzschlundfeste
19045	Schlachtstandarte der Stormpike
19046	Schlachtstandarte der Frostwolf
19047	Weisheit der Holzschlundfeste
19048	Schwere Stiefel der Holzschlundfeste
19049	Kampfhandschuhe der Holzschlundfeste
19050	Mantel der Holzschlundfeste
19051	Gurt der Dämmerung
19052	Stiefel der Dämmerung
19054	Red Dragon Orb
19055	Green Dragon Orb
19056	Argentumstiefel
19057	Handschuhe der Dämmerung
19058	Goldener Mantel der Dämmerung
19059	Argentumschultern
19060	Angereicherte Ration der Warsongschlucht
19061	Eiserne Ration der Warsongschlucht
19062	Feldration der Warsongschlucht
19064	Fesselschlüssel
19065	Smaragdkreis
19066	Runenstoffverband der Warsongschlucht
19067	Magiestoffverband der Warsongschlucht
19068	Seidenverband der Warsongschlucht
19069	Malkors Schädel
19070	Malkors Knochen
19071	Gefäß mit besudelten Blut
19083	Legionärsumhang der Frostwolf
19084	Umhang des Stormpike-Soldaten
19085	Mentorenumhang der Frostwolf
19086	Umhang des Stormpike-Weisen
19087	Plattengürtel der Frostwolf
19088	Panzergürtel der Frostwolf
19089	Ledergürtel der Frostwolf
19090	Stoffgürtel der Frostwolf
19091	Plattengurt der Stormpike
19092	Panzergurt der Stormpike
19093	Ledergurt der Stormpike
19094	Stoffgurt der Stormpike
19095	Legionärsanhänger der Frostwolf
19096	Mentorenanhänger der Frostwolf
19097	Anhänger des Stormpike-Soldaten
19098	Anhänger des Stormpike-Weisen
19099	Gletscherklinge
19100	Aufgeladener Dolch
19101	Blendstab
19102	Knisterstab
19103	Frostschneide
19104	Sturmschlaghammer
19105	Frostrunenverzierter Kopfputz
19106	Eisstachelspeer
19107	Blutsucher
19108	Zauberstab der beißenden Kälte
19109	Wurzelring
19110	Kaltgeschmiedete Klinge
19111	Winteraxschulterklappen
19112	Eisüberzogene Stahlunterarmschienen
19113	Yetibalg-Armschienen
19114	Hochlandbogen
19115	Fläschchen mit Waldmojo
19116	Grünblatthandlappen
19117	Versiegelte Holzplattenbeinschienen
19118	Zauberstab des Naturodems
19119	Eulenbestienbalg-Handschuhe
19120	Rune des Wachbefehlshabers
19121	Umhang des tiefen Waldlands
19123	Immerwarme Handlappen
19124	Gußplattengamaschen
19125	Versengter Panzergurt
19126	Gußplattenstulpen
19127	Verkohlte Ledertunika
19128	Versengte Panzerweste
19129	Ewig glühende Robe
19130	Stab des Kälteeinbruchs
19131	Schneeblindschuhe
19132	Kristallverzierte Krone
19133	Teufelserfüllte Gamaschen
19134	Zerschundener Verdammniswachengürtel
19135	Schwarzflammenarmschienen
19136	Mana entfachende Kordel
19137	Gurt des Ansturms
19138	Band von Sulfuras
19139	Brandwachenschultern
19140	Band der Ausbrennung
19141	Luffaschwamm
19142	Feuerrunenverzierter Zauberfoliant
19143	Flammenwächterstulpen
19144	Sabatons des Flammenwandlers
19145	Robe der flüchtigen Macht
19146	Handgelenksschutz der Stabilität
19147	Ring der Zauberkraft
19148	Dunkeleisenhelm
19149	Lavagürtel
19150	Basisüberlebenspaket der Schildwache
19151	Standardüberlebenspaket der Schildwache
19152	Verbessertes Überlebenspaket der Schildwache
19153	Verbessertes Überlebenspaket der Vorhut
19154	Basisüberlebenspaket der Vorhut
19155	Standardüberlebenspaket der Vorhut
19156	Flimmerkernrobe
19157	Chromatische Stulpen
19159	Gewobene Efeuhalskette
19160	Wappenrock des Wettkampfsiegers
19162	Kernhundgürtel
19163	Geschmolzener Gürtel
19164	Dunkeleisenstulpen
19165	Flimmerkerngamaschen
19166	Schwarze Amnestie
19167	Schattenzorn
19168	Finsterer Streiter
19169	Nachtlauer
19170	Ebenholzhand
19182	Gewinnlos des Dunkelmond-Jahrmarkts
19183	Stundenglassand
19202	Pläne: Schwerer Gürtel der Holzschlundfeste
19203	Pläne: Gurt der Dämmerung
19204	Pläne: Schwere Stiefel der Holzschlundfeste
19205	Pläne: Handschuhe der Dämmerung
19206	Pläne: Dunkeleisenhelm
19207	Pläne: Dunkeleisenstulpen
19208	Pläne: Schwarze Amnestie
19209	Pläne: Schattenzorn
19210	Pläne: Ebenholzhand
19211	Pläne: Finsterer Streiter
19212	Pläne: Nachtlauer
19213	Verdienstabzeichen der Silverwing
19215	Muster: Weisheit der Holzschlundfeste
19216	Muster: Argentumstiefel
19217	Muster: Argentumschultern
19218	Muster: Mantel der Holzschlundfeste
19219	Muster: Flimmerkernrobe
19220	Muster: Flimmerkerngamaschen
19221	Dunkelmond-Spezialmischung
19222	Billiges Bier
19223	Dunkelmond-Zipferl
19224	Würzige Hähnchenschlegel
19225	Frittierter Schokoriegel
19227	Bestien Ass
19228	Bestienkartenset
19229	Sayges Horoskop Nr. 1
19230	Bestien 2
19231	Bestien 3
19232	Bestien 4
19233	Bestien 5
19234	Bestien 6
19235	Bestien 7
19236	Bestien 8
19237	Sayges Horoskop Nr. 19
19238	Sayges Horoskop Nr. 3
19239	Sayges Horoskop Nr. 4
19240	Sayges Horoskop Nr. 5
19241	Sayges Horoskop Nr. 6
19242	Sayges Horoskop Nr. 7
19243	Sayges Horoskop Nr. 8
19244	Sayges Horoskop Nr. 9
19245	Sayges Horoskop Nr. 10
19246	Sayges Horoskop Nr. 10
19247	Sayges Horoskop Nr. 12
19248	Sayges Horoskop Nr. 13
19249	Sayges Horoskop Nr. 14
19250	Sayges Horoskop Nr. 15
19251	Sayges Horoskop Nr. 16
19252	Sayges Horoskop Nr. 18
19253	Sayges Horoskop Nr. 17
19254	Sayges Horoskop Nr. 21
19255	Sayges Horoskop Nr. 22
19256	Sayges Horoskop Nr. 2
19257	Kriegsfürstenkartenset
19258	Kriegsfürst Ass
19259	Kriegsfürst 2
19260	Kriegsfürst 3
19261	Kriegsfürst 4
19262	Kriegsfürst 5
19263	Kriegsfürst 6
19264	Kriegsfürst 7
19265	Kriegsfürst 8
19266	Sayges Horoskop Nr. 20
19267	Elementarkartenset
19268	Elementar Ass
19269	Elementar 2
19270	Elementar 3
19271	Elementar 4
19272	Elementar 5
19273	Elementar 6
19274	Elementar 7
19275	Elementar 8
19276	Portal Ass
19277	Portalkartenset
19278	Portal 2
19279	Portal 3
19280	Portal 4
19281	Portal 5
19282	Portal 6
19283	Portal 7
19284	Portal 8
19287	Dunkelmond-Karte: Heldentum
19288	Dunkelmond-Karte: Blauer Drache
19289	Dunkelmond-Karte: Maelstrom
19290	Dunkelmond-Karte: Wirbelnder Nether
19291	Dunkelmond-Lagerbehälter
19292	Hammel des letzten Monats
19293	Hammel des letzten Jahres
19295	Dunkelmond-Blume
19296	Großer Dunkelmond-Preis
19297	Geringer Dunkelmond-Preis
19298	Kleiner Dunkelmond-Preis
19299	Prickelndes Marktgetränk
19300	Winterspring-Flaschenwasser
19301	Alterac Manakeks
19302	Dunkelmond-Ring
19303	Dunkelmond-Halskette
19304	Gewürztes Rinderstockfleisch
19305	Gepökelter Kodofuß
19306	Knusperfrosch
19307	Alterac Schwerer Runenstoffverband
19308	Foliant der arkanen Beherrschung
19309	Foliant der Schattengewalt
19310	Foliant des Eislords
19311	Foliant der feurigen Arkane
19312	Kranz des Lebensspenders
19315	Therazanes Berührung
19316	Eisgewirkter Pfeil
19317	Eisgewirkte Kugel
19318	Abgefülltes Alteracquellwasser
19319	Köcher aus Harpienhaut
19320	Schultergürtel aus Gnollhaut
19321	Das unbewegliche Objekt
19322	Ehrenabzeichen der Warsong
19323	Die unaufhaltbare Macht
19324	Der Geistesbrecher
19325	Don Julios Band
19326	Muster: Macht der Holzschlundfeste
19327	Muster: Kampfhandschuhe der Holzschlundfeste
19328	Muster: Stiefel der Dämmerung
19329	Muster: Goldener Mantel der Dämmerung
19330	Muster: Lavagürtel
19331	Muster: Chromatische Stulpen
19332	Muster: Kernhundgürtel
19333	Muster: Geschmolzener Gürtel
19334	Die ungezähmte Klinge
19335	Wirbelsäulenbrecher
19336	Edelstein der arkanen Kraft
19337	Das schwarze Buch
19338	Gratisticket-Geschenkgutschein
19339	Edelstein des Gedankensprungs
19340	Rune der Metamorphose
19341	Lebensspendender Edelstein
19342	Gifttotem
19343	Rollen des Blendenden Lichts
19344	Kristall der Naturverbundenheit
19345	Aegis der Bewahrung
19346	Drachenzahnklinge
19347	Klaue von Chromaggus
19348	Roter Drachenschuppenbeschützer
19349	Elementiumverstärktes Bollwerk
19350	Herzensbrecher
19351	Maladath, Runenverzierte Klinge des schwarzen Drachenschwarms
19352	Chromatisch gehärtetes Schwert
19353	Drachenkrallenbeil
19354	Drachischer Rächer
19355	Fokussierstab der Schattenschwingen
19356	Stab der Schattenflamme
19357	Herold des Leidens
19358	Drachischer Schlägel
19360	Lok'amir il Romathis
19361	Ashjre'thul, Armbrust der Pein
19362	Schneide der Verdammnis
19363	Crul'shorukh, Schneide des Chaos
19364	Ashkandi, Großschwert der Bruderschaft
19365	Klaue des Schwarzen Drachen
19366	Kugel des Meisterdrachentöters
19367	Berührung des Drachen
19368	Drachenodemhandkanone
19369	Handschuhe der rapiden Evolution
19370	Mantel der Pechschwingenkabale
19371	Anhänger des gefallenen Drachen
19372	Helm der unendlichen Rage
19373	Schultern der Schwarzen Brut
19374	Armschienen der arkanen Präzision
19375	Mish'undare, Reif des Gedankenschinders
19376	Archimtiros' Ring der Abrechnung
19377	Prestors Talisman der Verschwörung
19378	Umhang des Brutlords
19379	Neltharions Träne
19380	Therazanes Zusammenhalt
19381	Stiefel der Schattenflamme
19382	Band aus reinem Elementium
19383	Medallion des Meisterdrachentöters
19384	Ring des Meisterdrachentöters
19385	Energieerfüllte Gamaschen
19386	Elementiumdurchwirkter Umhang
19387	Chromatische Stiefel
19388	Angelistas Gespür
19389	Gehärtete Drachenlederschulterpolster
19390	Gehärtete Drachenlederhandschuhe
19391	Schimmerndes Geta
19392	Gurt des gefallenen Kreuzfahrers
19393	Gekettelter Taillenschutz des Primalisten
19394	Drachenkrallenschulterstücke
19395	Edelstein der Verjüngung
19396	Gehärteter Drachenledergürtel
19397	Ring des Blackrock
19398	Feuerschwingens Umhang
19399	Schwarzaschenrobe
19400	Feuerschwingens Griff
19401	Gekettelter Beinschützer des Primalisten
19402	Beinschützer des gefallenen Kreuzfahrers
19403	Band der erzwungenen Konzentration
19405	Malfurions gesegnetes Bollwerk
19406	Drachenfangzahn-Talisman
19407	Ebenholzfarbene Flammenhandschuhe
19422	Horoskop des Dunkelmond-Jahrmarkts
19423	Sayges Horoskop Nr. 23
19424	Sayges Horoskop Nr. 24
19425	Mysteriöse Schließkassette
19426	Kugel des Dunkelmonds
19430	Schleier des reinen Gedankens
19431	Styleens verhinderter Skarabäus
19432	Kreis der angewandten Macht
19433	Sandzwirngamaschen
19434	Band der dunklen Herrschaft
19435	Essenzsammler
19436	Umhang der drachischen Macht
19437	Stiefel des reinen Gedankens
19438	Ringos Blizzardstiefel
19439	Geflochtener Schattenwams
19440	Mächtiges Gegengift
19441	Riesiger Giftbeutel
19442	Formel: Mächtiges Gegengift
19443	Sayges Horoskop Nr. 25
19444	Formel: Waffe - Stärke
19445	Formel: Waffe - Beweglichkeit
19446	Formel: Armschiene - Manaregeneration
19447	Formel: Armschiene - Heilung
19448	Formel: Waffe - Mächtige Willenskraft
19449	Formel: Waffe - Mächtige Intelligenz
19450	Das kleine Zuhause eines Jublings
19451	Sayges Horoskop Nr. 26
19452	Sayges Horoskop Nr. 27
19453	Sayges Horoskop Nr. 28
19454	Sayges Horoskop Nr. 29
19462	Unausgebrütetes Jubling-Ei
19482	LeCraft-Kaninchenfell
19483	Schrittweise zum Sieg
19484	Frostwölfe abserviert
19491	Amulett des Dunkelmonds
19505	Wappenrock der Warsong
19506	Wappenrock der Silverwing
19507	Schal des Hochinquisitors
19508	Gebrandmarkte Lederarmschienen
19509	Verstaubte Panzerstiefel
19510	Band des Legionärs
19511	Band des Legionärs
19512	Band des Legionärs
19513	Band des Legionärs
19514	Band des Beschützers
19515	Band des Beschützers
19516	Band des Beschützers
19517	Band des Beschützers
19518	Ring des Beraters
19519	Ring des Beraters
19520	Ring des Beraters
19521	Ring des Beraters
19522	Ring des Wissenshüters
19523	Ring des Wissenshüters
19524	Ring des Wissenshüters
19525	Ring des Wissenshüters
19526	Umhang des Feldheilers
19527	Umhang des Feldheilers
19528	Umhang des Feldheilers
19529	Umhang des Feldheilers
19530	Cape des Verwalters
19531	Cape des Verwalters
19532	Cape des Verwalters
19533	Cape des Verwalters
19534	Medaillon des Spähers
19535	Medaillon des Spähers
19536	Medaillon des Spähers
19537	Medaillon des Spähers
19538	Medallion der Schildwache
19539	Medallion der Schildwache
19540	Medallion der Schildwache
19541	Medallion der Schildwache
19542	Klinge des Spähers
19543	Klinge des Spähers
19544	Klinge des Spähers
19545	Klinge des Spähers
19546	Klinge der Schildwache
19547	Klinge der Schildwache
19548	Klinge der Schildwache
19549	Klinge der Schildwache
19550	Schwert des Legionärs
19551	Schwert des Legionärs
19552	Schwert des Legionärs
19553	Schwert des Legionärs
19554	Schwert des Beschützers
19555	Schwert des Beschützers
19556	Schwert des Beschützers
19557	Schwert des Beschützers
19558	Bogen der Vorhut
19559	Bogen der Vorhut
19560	Bogen der Vorhut
19561	Bogen der Vorhut
19562	Bogen des Kundschafters
19563	Bogen des Kundschafters
19564	Bogen des Kundschafters
19565	Bogen des Kundschafters
19566	Knorriger Stab des Beraters
19567	Knorriger Stab des Beraters
19568	Knorriger Stab des Beraters
19569	Knorriger Stab des Beraters
19570	Stab des Wissenshüters
19571	Stab des Wissenshüters
19572	Stab des Wissenshüters
19573	Stab des Wissenshüters
19574	Stärke von Mugamba
19575	Stärke von Mugamba
19576	Stärke von Mugamba
19577	Wut Mugambas
19578	Berserkerarmschienen
19579	Emblem des Ungläubigen
19580	Berserkerarmschienen
19581	Berserkerarmschienen
19582	Handgelenksschutz des Windsprechers
19583	Handgelenksschutz des Windsprechers
19584	Handgelenksschutz des Windsprechers
19585	Emblem des Ungläubigen
19586	Emblem des Ungläubigen
19587	Armschienen des Waldpirschers
19588	Emblem des Helden
19589	Armschienen des Waldpirschers
19590	Armschienen des Waldpirschers
19591	Das Auge von Zuldazar
19592	Das Auge von Zuldazar
19593	Das Auge von Zuldazar
19594	Das allsehende Auge von Zuldazar
19595	Handgelenksschoner des Dryaden
19596	Handgelenksschoner des Dryaden
19597	Handgelenksschoner des Dryaden
19598	Stein des Kajaro
19599	Stein des Kajaro
19600	Stein des Kajaro
19601	Juwel von Kajaro
19602	Kezans Schmach
19603	Kezans Schmach
19604	Kezans Schmach
19605	Kezans unaufhaltsame Schmach
19606	Vision von Voodress
19607	Vision von Voodress
19608	Vision von Voodress
19609	Unversehrte Vision von Voodress
19610	Verzauberter Südmeertang
19611	Verzauberter Südmeertang
19612	Verzauberter Südmeertang
19613	Reiner verzauberter Südmeertang
19614	Zandalarianischer Schattentalisman
19615	Zandalarianischer Schattentalisman
19616	Zandalarianischer Schattentalisman
19617	Zandalarianischer Schattentalisman der Beherrschung
19618	Maelstroms Ranke
19619	Maelstroms Ranke
19620	Maelstroms Ranke
19621	Maelstroms Zorn
19642	iCoke Prize Voucher
19682	Blutrebenweste
19683	Blutrebengamaschen
19684	Blutrebenstiefel
19685	Urzeitliches Fledermaushautwams
19686	Urzeitliche Fledermaushauthandschuhe
19687	Urzeitliche Fledermaushautarmschienen
19688	Bluttigerbrustplatte
19689	Bluttigerschultern
19690	Blutseelenbrustplatte
19691	Blutseelenschultern
19692	Blutseelenstulpen
19693	Dunkelseelenbrustplatte
19694	Dunkelseelengamaschen
19695	Dunkelseelenschultern
19696	Erntedankbrot
19697	Erntegabe
19698	Zulianische Münze
19699	Münze der Razzashi
19700	Münze der Hakkari
19701	Münze der Gurubashi
19702	Münze der Vilebranch
19703	Münze der Witherbark
19704	Münze der Sandfury
19705	Münze der Skullsplitter
19706	Münze der Bloodscalp
19707	Rotes Schmuckstück der Hakkari
19708	Blaues Schmuckstück der Hakkari
19709	Gelbes Schmuckstück der Hakkari
19710	Orangefarbenes Schmuckstück der Hakkari
19711	Grünes Schmuckstück der Hakkari
19712	Lilanes Schmuckstück der Hakkari
19713	Bronzefarbenes Schmuckstück der Hakkari
19714	Silbernes Schmuckstück der Hakkari
19715	Goldenes Schmuckstück der Hakkari
19716	Urzeitliche Hakkaribindungen
19717	Urzeitliche Hakkariarmsplinte
19718	Urzeitliche Hakkaristütze
19719	Urzeitlicher Hakkarigurt
19720	Urzeitliche Hakkarischärpe
19721	Urzeitlicher Hakkarischal
19722	Urzeitlicher Hakkariwappenrock
19723	Urzeitlicher Hakkarikosak
19724	Urzeitliche Aegis der Hakkari
19725	Arathivorratskiste
19726	Blutrebe
19727	Blutsense
19764	Muster: Blutrebenweste
19765	Muster: Blutrebengamaschen
19766	Muster: Blutrebenstiefel
19767	Urzeitliches Fledermausleder
19768	Urzeitliches Tigerleder
19769	Muster: Urzeitliches Fledermaushautwams
19770	Muster: Urzeitliche Fledermaushauthandschuhe
19771	Muster: Urzeitliche Fledermaushautarmschienen
19772	Muster: Bluttigerbrustplatte
19773	Muster: Bluttigerschultern
19774	Soldarit
19775	Versiegelte azurblaue Tasche
19776	Muster: Blutseelenbrustplatte
19777	Muster: Blutseelenschultern
19778	Muster: Blutseelenstulpen
19779	Muster: Dunkelseelenbrustplatte
19780	Muster: Dunkelseelengamaschen
19781	Muster: Dunkelseelenschultern
19782	Präsenz der Macht
19783	Siegelzeichen des Synkretisten
19784	Umarmung des Todes
19785	Ruf des Falken
19786	Vodouisants wachsame Umarmung
19787	Allgegenwärtige Sicht
19788	Verhexung des Hoodoo
19789	Prophetische Aura
19790	Liebkosung des Animisten
19802	Herz von Hakkar
19803	Brownells blaugestreifter Flitzerfisch
19804	Blasser Geisterfisch
19805	Keefers Engelfisch
19806	Dezianischer Königinnenfisch
19807	Gesprenkelter Leckerfisch
19808	Felsnischenstarkfisch
19812	Rune der Dämmerung
19813	Durchstochene Voodoopuppe
19814	Durchstochene Voodoopuppe
19815	Durchstochene Voodoopuppe
19816	Durchstochene Voodoopuppe
19817	Durchstochene Voodoopuppe
19818	Durchstochene Voodoopuppe
19819	Durchstochene Voodoopuppe
19820	Durchstochene Voodoopuppe
19821	Durchstochene Voodoopuppe
19822	Zandalarianische Brustplatte des Vollstreckers
19823	Zandalarianischer Gürtel des Vollstreckers
19824	Zandalarianische Armschützer des Vollstreckers
19825	Zandalarianische Brustplatte des Freidenkers
19826	Zandalarianischer Gürtel des Freidenkers
19827	Zandalarianische Armschützer des Freidenkers
19828	Zandalarianische Halsberge des Weissagers
19829	Zandalarianischer Gürtel des Weissagers
19830	Zandalarianischer Armschienen des Weissagers
19831	Zandalarianischer Mantel des Raubtiers
19832	Zandalarianischer Gürtel des Raubtiers
19833	Zandalarianische Armschienen des Raubtiers
19834	Zandalarianische Tunika des Wildfangs
19835	Zandalarianischer Mantel des Wildfangs
19836	Zandalarianische Armschienen des Wildfangs
19838	Zandalarianische Haruspextunika
19839	Zandalarianischer Haruspexgürtel
19840	Zandalarianische Haruspexarmschienen
19841	Zandalarianischer Mantel des Glaubenshüters
19842	Zandalarianische Bindungen des Glaubenshüters
19843	Zandalarianische Handlappen des Glaubenshüters
19845	Zandalarianischer Mantel des Illusionisten
19846	Zandalarianische Handlappen des Illusionisten
19848	Zandalarianische Handlappen des Besessenen
19849	Zandalarianischer Mantel des Besessenen
19850	Uthers Tribut
19851	Groms Tribut
19852	Uralter Menschentöter der Hakkari
19853	Zwergenzerstörer der Gurubashi
19854	Zin'rokh der Weltenzerstörer
19855	Blutgetränkte Beinplatten
19856	Das Auge von Hakkar
19857	Umhang der Verzehrung
19858	Zandalarianische Ehrenmünze
19859	Fangzahn des Gesichtslosen
19861	Berührung des Chaos
19862	Aegis des Blutgotts
19863	Siegel des Primalisten
19864	Blutrufer
19865	Kriegsklinge der Hakkari
19866	Kriegsklinge der Hakkari
19867	Verteidiger des Blutfürsten
19869	Blutdurchnässter Handschutz
19870	Göttlicher Hakkariumhang
19871	Talisman des Schutzes
19872	Schneller Razzashiraptor
19873	Purpurrotes Band des Oberherren
19874	Hellebarde der Pein
19875	Blutbefleckte Helmkappe
19876	Halskette des Seelenverderbers
19877	Gamaschen des Animisten
19878	Blutgetränkte Schulterstücke
19880	Schädelsammlung der Gurubashi
19881	Kopf des Kanalisierers
19882	Kopf des Verhexers
19883	Heilige Kordel
19884	Jin'dos Richturteil
19885	Jin'dos Auge des Bösen
19886	Bedeckung des Verhexers
19887	Blutbefleckte Beinplatten
19888	Umarmung des Oberherren
19889	Blutdurchnässte Gamaschen
19890	Jin'dos Verhexer
19891	Jin'dos Beutel der Verdammnis
19892	Stiefel des Animisten
19893	Zanzils Siegel
19894	Blutgetränkte Stulpen
19895	Blutverschmierter Kilt
19896	Thekals Griff
19897	Stiefel des Verräters
19898	Siegel von Jin
19899	Rituelle Beinschützer
19900	Zulianische Steinaxt
19901	Zulianischer Schnitzler
19902	Schneller zulianischer Tiger
19903	Fangzahn von Venoxis
19904	Blutbefleckte runenverzierte Halsberge
19905	Zanzils Band
19906	Blutdurchnässte Fußpolster
19907	Zulianischer Tigerbalgumhang
19908	Szepter der Pein
19909	Wille Arlokks
19910	Arlokks Griff
19911	Peitschenkrautherz
19912	Onyxband des Oberherren
19913	Blutgetränkte Schienbeinschützer
19914	Pantherbalgsack
19915	Zulianischer Verteidiger
19918	Jekliks Zermalmer
19919	Blutbefleckte Schienbeinschützer
19920	Band des Primalisten
19921	Zulianischer Zerhacker
19922	Arlokks Hoodoostecken
19923	Jekliks opaliner Talisman
19925	Jins Band
19927	Mar'lis Berührung
19928	Schiftung des Animisten
19929	Blutverschmierte Handschuhe
19930	Mar'lis Auge
19931	Mojowahnsinn der Gurubashi
19933	Leuchtendes Skorpidblut
19934	Große Skorpidklaue
19935	Leerer Giftbeutel
19936	Getrockneter Skorpidknochenpanzer
19937	Kleine Skorpidklaue
19938	Schweres Skorpidbein
19939	Gri'leks Blut
19940	Renatakis Zahn
19941	Wushoolays Mähne
19942	Hazza'rahs Traumfaden
19943	Gewaltig viel Mojo
19944	Nat Pagles Fischterminator
19945	Echsenschuppenaugenklappe
19946	Skippis Harpune
19947	Nat Pagles kaputte Spule
19948	Zandalarianisches Heldenabzeichen
19949	Zandalarianisches Heldenmedallion
19950	Zandalarianisches Heldenamulett
19951	Gri'leks Amulett der Macht
19952	Gri'leks Amulett der Ehre
19953	Renatakis Amulett der Bestien
19954	Renatakis Amulett der Gaunerei
19955	Wushoolays Amulett der Natur
19956	Wushoolays Amulett der Geister
19957	Hazza'rahs Amulett der Zerstörung
19958	Hazza'rahs Amulett der Heilung
19959	Hazza'rahs Amulett der Magie
19960	Kristallisierter Honig
19961	Grileks Schleifer
19962	Grileks Schnitzer
19963	Heugabel des Wahnsinns
19964	Renatakis Seelenkanal
19965	Wushoolays Schüreisen
19967	Gedankenvernichter
19968	Feuriger Heimzahler
19969	Nat Pagles Extremanglerstiefel
19970	Arkanitangel
19971	Extremgetestete Eterniumangelschnur
19972	Glücksangelhut
19973	Nats Maßband
19974	Matschstinkerköder
19975	Zulianischer Matschstinker
19978	Angelwettbewerb!
19979	Angelhaken des Anglermeisters
19982	Nachtsaugertuch
19984	Ebenholzmaske
19986	Piraten-Augenklappe
19989	Foliant der verschlingenden Schatten
19990	Gesegnete Gebetsperlen
19991	Auge eines Teufelssauriers
19992	Zahn eines Teufelssauriers
19993	Hoodoojagdbogen
19994	Erntedankobst
19995	Erntedankeber
19996	Erntedankfisch
19997	Erntedanknektar
19998	Blutrebenlinse
19999	Blutrebenschutzbrille
20000	Bauplan: Blutrebenschutzbrille
20001	Bauplan: Blutrebenlinse
20002	Großer Trank des traumlosen Schlafs
20003	Klauen eines Teufelssauriers
20004	Erheblicher Trollbluttrank
20005	Klauen eines Teufelssauriers
20006	Reif der Hoffnung
20007	Magierbluttrank
20008	Trank der lebhaften Aktion
20009	Für das Licht!
20010	Hellscream, Held der Horde
20011	Rezept: Magierbluttrank
20012	Rezept: Großer Trank des traumlosen Schlafs
20013	Rezept: Trank der lebhaften Aktion
20014	Rezept: Erheblicher Trollbluttrank
20015	Federn eines alten Raptors
20016	Raptorschädeltrophäe
20017	Perfektes Rennergeweih
20018	Wutklauengrizzlyfell
20019	Morphaz' Zahn
20020	Bündel voller Waren
20021	Goldener Piratenohrring
20022	Azurblauer Schlüssel
20023	Verschlüsseltes Fragment
20024	Eitriger Gallengang
20025	Morphaz' Blut
20026	Verrottendes Fleisch
20027	Gesunde Rennerdrüse
20028	Glitzernder Staub
20029	Verzauberte Koralle
20030	Tierfelsen
20031	Essenzmango
20032	Fließende Ritualroben
20033	Zandalarianische Robe des Besessenen
20034	Zandalarianische Robe des Illusionisten
20035	Gletscherstachel
20036	Feuerrubin
20037	Arkankristallanhänger
20038	Mandokirs Stachel
20039	Dunkeleisenstiefel
20040	Pläne: Dunkeleisenstiefel
20041	Plattengurt des Highlanders
20042	Lamellengurt des Highlanders
20043	Kettengurt des Highlanders
20044	Panzergurt des Highlanders
20045	Ledergurt des Highlanders
20046	Echsenledergurt des Highlanders
20047	Stoffgurt des Highlanders
20048	Plattenschienbeinschützer des Highlanders
20049	Lamellenschienbeinschützer des Highlanders
20050	Kettenschienbeinschützer des Highlanders
20051	Panzerschienbeinschützer des Highlanders
20052	Lederstiefel des Highlanders
20053	Echsenlederstiefel des Highlanders
20054	Stoffstiefel des Highlanders
20055	Kettenschulterstücke des Highlanders
20056	Panzerschulterstücke des Highlanders
20057	Plattenschiftung des Highlanders
20058	Lamellenschiftung des Highlanders
20059	Lederschultern des Highlanders
20060	Echsenlederschultern des Highlanders
20061	Schulterklappen des Highlanders
20062	Angereicherte Ration des Arathibeckens
20063	Feldration des Arathibeckens
20064	Eiserne Ration des Arathibeckens
20065	Magiestoffverband des Arathibeckens
20066	Runenstoffverband des Arathibeckens
20067	Seidenverband des Arathibeckes
20068	Todeswachen-Umhang
20069	Eisenborkenstab
20070	Klaue der Weisheit
20071	Talisman von Arathor
20072	Talisman der Entweihten
20073	Umhang der Ehrenwache
20074	Schwerer Krokiliskeneintopf
20075	Rezept: Schwerer Krokiliskeneintopf
20076	Zandalarianisches Siegel des Mojo
20077	Zandalarianisches Siegel der Macht
20078	Zandalarianisches Siegel der inneren Ruhe
20079	Zanzas Geist
20080	Zanzas Glanz
20081	Zanzas Schnelligkeit
20082	Stab des Leidens
20083	Jagdspeer
20084	Jagdnetz
20085	Arkaner Splitter
20086	Düsterstahlwurfmesser
20087	Wellenhauerschuppen
20088	Kettengurt des Highlanders
20089	Kettengurt des Highlanders
20090	Kettengurt des Highlanders
20091	Kettenschienbeinschützer des Highlanders
20092	Kettenschienbeinschützer des Highlanders
20093	Kettenschienbeinschützer des Highlanders
20094	Stoffstiefel des Highlanders
20095	Stoffstiefel des Highlanders
20096	Stoffstiefel des Highlanders
20097	Stoffgurt des Highlanders
20098	Stoffgurt des Highlanders
20099	Stoffgurt des Highlanders
20100	Echsenlederstiefel des Highlanders
20101	Echsenlederstiefel des Highlanders
20102	Echsenlederstiefel des Highlanders
20103	Echsenledergurt des Highlanders
20104	Echsenledergurt des Highlanders
20105	Echsenledergurt des Highlanders
20106	Lamellengurt des Highlanders
20107	Lamellengurt des Highlanders
20108	Lamellengurt des Highlanders
20109	Lamellenschienbeinschützer des Highlanders
20110	Lamellenschienbeinschützer des Highlanders
20111	Lamellenschienbeinschützer des Highlanders
20112	Lederstiefel des Highlanders
20113	Lederstiefel des Highlanders
20114	Lederstiefel des Highlanders
20115	Ledergurt des Highlanders
20116	Ledergurt des Highlanders
20117	Ledergurt des Highlanders
20118	Panzergurt des Highlanders
20119	Panzergurt des Highlanders
20120	Panzergurt des Highlanders
20121	Panzerschienbeinschützer des Highlanders
20122	Panzerschienbeinschützer des Highlanders
20123	Panzerschienbeinschützer des Highlanders
20124	Plattengurt des Highlanders
20125	Plattengurt des Highlanders
20126	Plattengurt des Highlanders
20127	Plattenschienbeinschützer des Highlanders
20128	Plattenschienbeinschützer des Highlanders
20129	Plattenschienbeinschützer des Highlanders
20130	Diamantenfläschchen
20131	Wappenrock der Entweihten
20132	Wappenrock der Arathor
20134	Helm des Himmelszorns
20150	Kettengurt der Entweihten
20151	Kettengurt der Entweihten
20152	Kettengurt der Entweihten
20153	Kettengurt der Entweihten
20154	Kettenschienbeinschützer der Entweihten
20155	Kettenschienbeinschützer der Entweihten
20156	Kettenschienbeinschützer der Entweihten
20157	Kettenschienbeinschützer der Entweihten
20158	Kettenschulterstücke der Entweihten
20159	Stoffstiefel der Entweihten
20160	Stoffstiefel der Entweihten
20161	Stoffstiefel der Entweihten
20162	Stoffstiefel der Entweihten
20163	Stoffgurt der Entweihten
20164	Stoffgurt der Entweihten
20165	Stoffgurt der Entweihten
20166	Stoffgurt der Entweihten
20167	Drachenlederstiefel der Entweihten
20168	Drachenlederstiefel der Entweihten
20169	Drachenlederstiefel der Entweihten
20170	Drachenlederstiefel der Entweihten
20171	Drachenledergurt der Entweihten
20172	Drachenledergurt der Entweihten
20173	Drachenledergurt der Entweihten
20174	Drachenledergurt der Entweihten
20175	Drachenlederschultern der Entweihten
20176	Schulterklappen der Entweihten
20177	Lamellengurt der Entweihten
20178	Lamellengurt der Entweihten
20179	Lamellengurt der Entweihten
20180	Lamellengurt der Entweihten
20181	Lamellenschienbeinschützer der Entweihten
20182	Lamellenschienbeinschützer der Entweihten
20183	Lamellenschienbeinschützer der Entweihten
20184	Lamellenschiftung der Entweihten
20185	Lamellenschienbeinschützer der Entweihten
20186	Lederstiefel der Entweihten
20187	Lederstiefel der Entweihten
20188	Lederstiefel der Entweihten
20189	Lederstiefel der Entweihten
20190	Ledergurt der Entweihten
20191	Ledergurt der Entweihten
20192	Ledergurt der Entweihten
20193	Ledergurt der Entweihten
20194	Lederschultern der Entweihten
20195	Panzergurt der Entweihten
20196	Panzergurt der Entweihten
20197	Panzergurt der Entweihten
20198	Panzergurt der Entweihten
20199	Panzerschienbeinschützer der Entweihten
20200	Panzerschienbeinschützer der Entweihten
20201	Panzerschienbeinschützer der Entweihten
20202	Panzerschienbeinschützer der Entweihten
20203	Panzerschulterstücke der Entweihten
20204	Plattengurt der Entweihten
20205	Plattengurt der Entweihten
20206	Plattengurt der Entweihten
20207	Plattengurt der Entweihten
20208	Plattenschienbeinschützer der Entweihten
20209	Plattenschienbeinschützer der Entweihten
20210	Plattenschienbeinschützer der Entweihten
20211	Plattenschienbeinschützer der Entweihten
20212	Plattenschiftung der Entweihten
20213	Gürtel mit Schrumpfköpfen
20214	Gedankenreißer
20215	Gürtel mit Schrumpelköpfen
20216	Gürtel mit konservierten Köpfen
20217	Gürtel mit winzigen Köpfen
20218	Ausgeblichener Hakkariumhang
20219	Zerlumptes Hakkaricape
20220	Eisenborkenstab
20221	Erdichtetes Ross
20222	Angereicherte Ration der Entweihten
20223	Feldration der Entweihten
20224	Eiserne Ration der Entweihten
20225	Angereicherte Ration des Highlanders
20226	Feldration des Highlanders
20227	Eiserne Ration des Highlanders
20228	Verbessertes Überlebenspaket der Entweihten
20229	Basisüberlebenspaket der Entweihten
20230	Standardüberlebenspaket der Entweihten
20231	Verbessertes Überlebenspaket von Arathor
20232	Magiestoffverband der Entweihten
20233	Basisüberlebenspaket von Arathor
20234	Runenstoffverband der Entweihten
20235	Seidenverband der Entweihten
20236	Standardüberlebenspaket von Arathor
20237	Magiestoffverband des Highlanders
20243	Runenstoffverband des Highlanders
20244	Seidenverband des Highlanders
20253	Muster: Kriegsbärenharnisch
20254	Muster: Kriegsbärenwollwäsche
20255	Leisetreter
20256	Aufopferungsabzeichen der Warsongschlucht
20257	Meeresfurienstulpen
20258	Zulianischer Zeremonienstab
20259	Handschuhe aus Schattenpantherbalg
20260	Meeresfuriengamaschen
20261	Gürtel aus Schattenpantherbalg
20262	Meeresfurienstiefel
20263	Helm der Gurubashi
20264	Stulpen des Friedensbewahrers
20265	Stiefel des Friedensbewahrers
20266	Gamaschen des Friedensbewahrers
20295	Blaue Drachenschuppengamaschen
20296	Grüne Drachenschuppenstulpen
20310	Geschundene Dämonenhaut
20337	Gnomenkopf am Spieß
20367	Jagdausstattung
20368	Sanfter Bogen der Beständigkeit
20369	Azuritfäuste
20371	Blaues Murlocei
20373	Steinpanzerskorpidstachel
20374	Steinpanzerzangenstachel
20375	Steinpanzerschinderstachel
20376	Sandhuschergiftzahn
20377	Felspirschergiftzahn
20378	Schrifttafelfragment der Twilight
20379	Noggles Ranzen
20380	Traumschuppenbrustplatte
20381	Traumschuppe
20382	Muster: Traumschuppenbrustplatte
20383	Kopf des Brutwächters Dreschbringer
20384	Silithidenknochenpanzerfragment
20385	Totenstachels Zange
20387	Stinkbomben der Verlassenen
20388	Lutscher
20389	Zuckerpops
20390	Schokoriegel
20391	Leichte männliche Gnomenmaske
20392	Leichte weibliche Gnomenmaske
20393	Schlotterbeutel
20394	Lexikon der Twilight - Kapitel 1
20395	Lexikon der Twilight - Kapitel 2
20396	Lexikon der Twilight - Kapitel 3
20397	Stab der Verwandlung - Pirat
20398	Stab der Verwandlung - Ninja
20399	Stab der Verwandlung - Lepragnom
20400	Kürbistasche
20401	Wiederhergestellte Schrifttafel der Twilight
20402	Agent Nozdormus
20403	Vertreter Nozdormus
20404	Verschlüsselter Text der Twilight
20405	Entschlüsselte Abschrift der Schrifttafel
20406	Twilightkultistenmantel
20407	Twilightkultistenrobe
20408	Twilightkultistenkutte
20409	Stab der Verwandlung - Geist
20410	Stab der Verwandlung - Fledermaus
20411	Stab der Verwandlung - Skelett
20413	Stab der Verwandlung - zufällig
20414	Stab der Verwandlung - Irrwisch
20415	Der Krieg der Sandstürme
20416	Wappen der Anrufung: Feuer
20418	Wappen der Anrufung: Donner
20419	Wappen der Anrufung: Stein
20420	Wappen der Anrufung: Wasser
20422	Standesmedaillon eines Twilightkultisten
20423	Sandige Skorpidklaue
20424	Sandwurmfleisch
20425	Knorriger Stab des Beraters
20426	Ring des Beraters
20427	Umhang des Feldheilers
20428	Cape des Verwalters
20429	Band des Legionärs
20430	Schwert des Legionärs
20431	Ring des Wissenshüters
20432	Siegel der Anrufung: Feuer
20433	Siegel der Anrufung: Donner
20434	Stab des Wissenshüters
20435	Siegel der Anrufung: Stein
20436	Siegel der Anrufung: Wasser
20437	Bogen der Vorhut
20438	Bogen des Kundschafters
20439	Band des Beschützers
20440	Schwert des Beschützers
20441	Klinge des Spähers
20442	Medaillon des Spähers
20443	Klinge der Schildwache
20444	Medaillon der Schildwache
20447	Szepter der Anrufung: Feuer
20448	Szepter der Anrufung: Donner
20449	Szepter der Anrufung: Stein
20450	Szepter der Anrufung: Wasser
20451	Herrschaftsring eines Twilightkultisten
20452	Geräucherte Wüstenknödel
20453	Abschriftenset für Geologen
20454	Abpausbild des Zoraschwarms
20455	Abpausbild des Ashischwarms
20456	Abpausbild des Regalschwarms
20457	Silithidengehirn des Ashischwarms
20458	Silithidengehirn des Zoraschwarms
20459	Silithidengehirn des Regalschwarms
20460	Brann Bronzebeards verlorener Brief
20461	Brann Bronzebeards verlorener Brief
20462	Medaillon der Schlotternächte
20463	Glyphenverziertes Kristallprisma
20464	Glyphen der Anrufung
20465	Kristallentriegelungsmechanismus
20466	Vyrals Siegelring
20467	Ausgerissene Rezeptseite
20469	Entschlüsselte Ausschnitte des "Wahren Glaubens"
20475	Seelenedelstein
20476	Sandpirscherarmschienen
20477	Sandpirscherstulpen
20478	Sandpirscherbrustplatte
20479	Feuerspuckerbrustplatte
20480	Feuerspuckerstulpen
20481	Feuerspuckerarmschienen
20485	Dukes Siegel
20487	Lok'delar, Stab der uralten Bewahrer DEP
20488	Rhok'delar, Langbogen der uralten Bewahrer DEP
20489	Ratskrone
20490	Pfefferminzbonbon aus Ironforge
20491	Pfefferminzbonbon aus Undercity
20492	Nugat aus Stormwind
20493	Nugat aus Orgrimmar
20494	Kaugummikugel aus Gnomeregan
20495	Kaugummikugel der Darkspear
20496	Marzipan aus Darnassus
20497	Marzipan aus Thunder Bluff
20498	Silithidenchitin
20499	Zerbrochenes Silithidenchitin
20500	Leichter Silithidenknochenpanzer
20501	Schwerer Silithidenknochenpanzer
20502	Eisenborkenschild
20503	Entzückter Wassergeist
20504	Lichtgeschmiedete Klinge
20505	Siegelring der Ritterlichkeit
20506	Muster: Feuerspuckerarmschienen
20507	Muster: Feuerspuckerstulpen
20508	Muster: Feuerspuckerbrustplatte
20509	Muster: Sandpirscherarmschienen
20510	Muster: Sandpirscherstulpen
20511	Muster: Sandpirscherbrustplatte
20512	Geweihte Kugel
20513	Abyssisches Wappen
20514	Abyssisches Siegel
20515	Abyssisches Szepter
20516	Knalliger Apfel
20517	Klingenstahlschultern
20518	Rolle: Wappen der Anrufung herstellen
20519	Südmeerpiratenhut
20520	Dunkelrune
20521	Visier des Zorns
20522	Stab der Wildnis
20524	Schattenfellgamaschen
20525	Irdenes Siegel
20526	Rolle: Wappen der Anrufung herstellen
20527	Rolle: Wappen der Anrufung herstellen
20528	Rolle: Wappen der Anrufung herstellen
20530	Roben der Knechtschaft
20531	Rolle: Siegel der Anrufung herstellen
20532	Rolle: Siegel der Anrufung herstellen
20533	Rolle: Siegel der Anrufung herstellen
20534	Abysssplitter
20535	Rolle: Siegel der Anrufung herstellen
20536	Seelenernter
20537	Runenverzierte stygische Stiefel
20538	Runenverzierte stygische Gamaschen
20539	Runenverzierter stygischer Gürtel
20540	Rolle: Szepter der Anrufung herstellen
20541	Entschlüsselter Text der Twilight
20542	Rolle: Szepter der Anrufung herstellen
20543	Rolle: Szepter der Anrufung herstellen
20544	Rolle: Szepter der Anrufung herstellen
20545	Entschlüsselter Text der Twilight
20546	Muster: Runenverzierte stygische Gamaschen
20547	Muster: Runenverzierte stygische Stiefel
20548	Muster: Runenverzierter stygischer Gürtel
20549	Dunkelrunenstulpen
20550	Dunkelrunenbrustplatte
20551	Dunkelrunenhelm
20552	Entschlüsselter Text der Twilight
20553	Pläne: Dunkelrunenstulpen
20554	Pläne: Dunkelrunenbrustplatte
20555	Pläne: Dunkelrunenhelm
20556	Wildstab
20557	Kürbisdrops der Schlotternächte
20558	Ehrenabzeichen der Warsongschlucht
20559	Ehrenabzeichen des Arathibeckens
20560	Ehrenabzeichen des Alteractals
20561	Leichte männliche Zwergenmaske
20562	Leichte weibliche Zwergenmaske
20563	Leichte weibliche Nachtelfenmaske
20564	Leichte männliche Nachtelfenmaske
20565	Leichte weibliche Menschenmaske
20566	Leichte männliche Menschenmaske
20567	Leichte weibliche Trollmaske
20568	Leichte männliche Trollmaske
20569	Leichte weibliche Orcmaske
20570	Leichte männliche Orcmaske
20571	Leichte weibliche Taurenmaske
20572	Leichte männliche Taurenmaske
20573	Leichte männliche Untotenmaske
20574	Leichte weibliche Untotenmaske
20575	Schwarzwelpentunika
20576	Muster: Schwarzwelpentunika
20577	Alptraumklinge
20578	Smaragdgrüner Drachenfangzahn
20579	Grüner Drachenhautumhang
20580	Hammer des Wildtierzorns
20581	Stab des rasanten Wachstums
20582	Trancestein
20583	Schwere weibliche Zwergenmaske
20584	Schwere weibliche Gnomenmaske
20585	Schwere weibliche Menschenmaske
20586	Schwere weibliche Nachtelfenmaske
20587	Schwere weibliche Orcmaske
20588	Schwere weibliche Taurenmaske
20589	Schwere weibliche Trollmaske
20590	Schwere weibliche Untotenmaske
20591	Schwere männliche Zwergenmaske
20592	Schwere männliche Gnomenmaske
20593	Schwere männliche Menschenmaske
20594	Schwere männliche Nachtelfenmaske
20595	Schwere männliche Orcmaske
20596	Schwere männliche Taurenmaske
20597	Schwere männliche Trollmaske
20598	Schwere männliche Untotenmaske
20599	Polierte Eisenholzarmbrust
20600	Malfurions Siegelring
20601	Beutesack
20602	Beutetruhe
20603	Beutetasche
20604	Stinkbombenreiniger
20605	Faule Eier
20606	Gelbe Voodoofeder
20607	Blaue Voodoofeder
20608	Grüne Voodoofeder
20609	Voodoofedern
20610	Blutunterlaufenes Spinnenauge
20611	Dicke schwarze Klaue
20612	Gereinigter Geißelstein
20613	Faules Holz
20614	Blutgiftessenz
20615	Drachenspitzwickeltücher
20616	Drachenknochenhandgelenksschutz
20617	Uralte zerfressene Gamaschen
20618	Handschuhe der irrsinnigen Macht
20619	Säurebeschriebene Schienbeinschützer
20620	Heiliger Stein der Macht
20621	Stiefel des endlosen Moors
20622	Drachenherzhalskette
20623	Reif der ruhelosen Träume
20624	Ring der Untoten
20625	Gürtel der dunklen Sümpfe
20626	Schwarzrindengelenkbänder
20627	Hose des dunklen Herzens
20628	Deviatwachstumskappe
20629	Heimtückische Fußschützer
20630	Stulpen des scheinenden Lichts
20631	Schuhe des Bettlers
20632	Geistertränenband
20633	Unnatürliche Lederschiftung
20634	Stiefel des Schreckens
20635	Jadeveredelte Trachten
20636	Hibernationskristall
20637	Säurebeschriebene Schulterstücke
20638	Gamaschen des verwirrten Geists
20639	Merkwürdig glyphenverzierte Beinplatten
20640	Südmeertopfhelm
20641	Südmeermojostiefel
20642	Antiquierte Adligentunika
20643	Reservistenkappe Undercitys
20644	In Alpträume gehüllter Gegenstand
20645	Flüstern der Natur
20646	Sandschreitermal
20647	Schwarzer Kristalldolch
20648	Kaltgeschmiedeter Hammer
20649	Sonnenprismaanhänger
20650	Wüstenwindstulpen
20651	Orangenes Murlocei
20652	Abyssische Stoffschuhe
20653	Abyssische Plattenstulpen
20654	Amethystkriegsstab
20655	Abyssische Stoffhandlappen
20656	Abyssische Panzersabatons
20657	Kristallstilett
20658	Abyssische Lederstiefel
20659	Abyssische Panzerhandschützer
20660	Steinschneidende Gleve
20661	Abyssische Lederhandschuhe
20662	Abyssische Plattenschienbeinschützer
20663	Durchschlagskräftiger Bogen
20664	Abyssische Stoffschärpe
20665	Abyssische Ledergamaschen
20666	Gehärteter Stahlkriegshammer
20667	Abyssischer Ledergürtel
20668	Abyssische Panzerbeinschützer
20669	Claymore von Darkstone
20670	Abyssische Panzerklammer
20671	Abyssische Plattenbeinschienen
20672	Sprühender Kristallzauberstab
20673	Abyssischer Plattengurt
20674	Abyssische Stoffhose
20675	Seelensammler
20676	Entschlüsselter Text der Twilight
20677	Entschlüsselter Text der Twilight
20678	Entschlüsselter Text der Twilight
20679	Entschlüsselter Text der Twilight
20680	Abyssische Panzerschulterstücke
20681	Abyssische Lederarmschienen
20682	Elementares Fokusband
20683	Abyssische Plattenschulterklappen
20684	Abyssische Panzerarmschützer
20685	Wellenfronthalskette
20686	Abyssische Stoffamicia
20687	Abyssische Plattenunterarmschienen
20688	Irdende Wache
20689	Abyssische Lederschultern
20690	Abyssische Stoffgelenkbänder
20691	Scherwindcape
20692	Mehrfarbiges Band
20693	Beschwerter Umhang
20694	Glühende schwarze Kugel
20695	Abyssische Kriegsperlen
20696	Kristallstachelschlägel
20697	Kristallgewirktes Cape
20698	Elementarabgestimmte Klinge
20699	Cenarische Reservistenbeinplatten
20700	Cenarische Reservistenbeinplatten
20701	Cenarische Reservistenbeinschützer
20702	Cenarische Reservistenbeinschützer
20703	Cenarische Reservistengamaschen
20704	Cenarische Reservistengamaschen
20705	Cenarische Reservistenhose
20706	Cenarische Reservistenhose
20707	Cenarische Reservistenhose
20708	Gut versiegeltes Gehäuse
20709	Rumsey-Rum Light
20710	Kristallverkrustete Schienbeinschützer
20711	Kristallüberzogene Schienbeinschützer
20712	Ödniswandlerstulpen
20713	Wüstenpirscherstulpen
20714	Sandsturmstiefel
20715	Dünenpirscherstiefel
20716	Sandwurmhauthandschuhe
20717	Wüstenblumenhandschuhe
20720	Klinge des dunklen Geflüsters
20721	Band des Kultisten
20722	Kristallprojektilwerfer
20723	Branns zuverlässige Hacke
20724	Verderbter Schwarzholzstab
20725	Nexuskristall
20726	Formel: Handschuhe - Bedrohung
20727	Formel: Handschuhe - Schattenmacht
20728	Formel: Handschuhe - Frostmacht
20729	Formel: Handschuhe - Feuermacht
20730	Formel: Handschuhe - Heilkraft
20731	Formel: Handschuhe - Überragende Beweglichkeit
20732	Formel: Umhang - Großer Feuerwiderstand
20733	Formel: Umhang - Großer Naturwiderstand
20734	Formel: Umhang - Verstohlenheit
20735	Formel: Umhang - Feingefühl
20736	Formel: Umhang - Ausweichen
20737	Sengender Kernstein
20741	Ritualtotem der Totenwaldfelle
20742	Ritualtotem der Winterfelle
20744	Schwaches Zauberöl
20745	Schwaches Manaöl
20746	Geringes Zauberöl
20747	Geringes Manaöl
20748	Hervorragendes Manaöl
20749	Hervorragendes Zauberöl
20750	Zauberöl
20752	Formel: Schwaches Manaöl
20753	Formel: Geringes Zauberöl
20754	Formel: Geringes Manaöl
20755	Formel: Zauberöl
20756	Formel: Hervorragendes Zauberöl
20757	Formel: Hervorragendes Manaöl
20758	Formel: Schwaches Zauberöl
20761	Rezept: Elementarfeuer transmutieren
20763	Beschädigte Waffe
20766	Schleimbeutel
20767	Schaumbedeckter Beutel
20768	Schlammiger Beutel
20769	Ekelhafter Schlammling
20770	Blubberndes grünes Sekret
20800	Cenarisches Versorgungsabzeichen
20801	Cenarisches Strategieabzeichen
20802	Cenarisches Gefechtsabzeichen
20803	Schlachtordnungen der Twilight
20805	Nachfolgender Logistikauftrag
20806	Logistikeinsatz X
20807	Logistikeinsatz I
20808	Kampfauftrag
20809	Taktischer Auftrag
20810	Unterzeichnete Felddienstpapiere
20814	Meisters Wurfdolch
20834	Verschnörkeltes Handfernrohr XT
20844	Tödliches Gift V
20858	Steinskarabäus
20859	Goldskarabäus
20860	Silberskarabäus
20861	Bronzeskarabäus
20862	Kristallskarabäus
20863	Tonskarabäus
20864	Knochenskarabäus
20865	Elfenbeinskarabäus
20866	Azurgötze
20867	Onyxgötze
20868	Züngelnder Götze
20869	Bernsteingötze
20870	Jaspisgötze
20871	Obsidiangötze
20872	Zinnobergötze
20873	Alabastergötze
20874	Götze der Sonne
20875	Götze der Nacht
20876	Götze des Todes
20877	Götze der Weisen
20878	Götze der Wiedergeburt
20879	Götze des Lebens
20881	Götze des Kampfes
20882	Götze des Krieges
20883	Glyphenverziertes Juwel der Qiraji
20884	Gebieterring der Qiraji
20885	Kampftuch der Qiraji
20886	Stachelgriff der Qiraji
20887	Graviertes Juwel der Qiraji
20888	Zeremonienring der Qiraji
20889	Hoheitstuch der Qiraji
20890	Verschnörkelter Griff der Qiraji
20908	Feuerwerk des Nianfests
20926	Vek'nilashs Reif
20927	Ouros intakte Haut
20928	Befehlsbindungen der Qiraji
20929	Knochenpanzer des alten Gottes
20930	Vek'lors Diadem
20931	Haut des großen Sandwurms
20932	Dominanzbindungen der Qiraji
20933	Hülle des alten Gottes
20936	Gesegnetes Juwel der Qiraji
20937	Eingeschlossenes Juwel der Qiraji
20939	Logistikeinsatz II
20940	Logistikeinsatz III
20941	Kampfeinsatz XII
20942	Kampfeinsatz III
20943	Taktischer Einsatz X
20944	Taktischer Einsatz IX
20945	Taktischer Einsatz II
20946	Taktischer Einsatz III
20947	Taktischer Einsatz IV
20948	Taktischer Einsatz V
20949	Magisches Buch
20951	Narains Wahrsagebrille
21023	Dirges abgefahrene Chimaerokkoteletts
21024	Chimaeroklenden
21025	Rezept: Dirges abgefahrene Chimaerokkoteletts
21027	Lakmaerans Kadaver
21029	Lösegeldforderung
21030	Darnassischer Kimchikuchen
21031	Weißkohlkimchi
21032	Meridiths Liebesbrief
21033	Rettichkimchi
21037	Primitive Karte
21038	Festgeformter Schneeball
21039	Narains Turban
21040	Narains Robe
21041	Tasche voller Gold
21042	Narains Spezialset
21043	Geheimnisvoller Umschlag
21071	Roher Weisenfisch
21072	Geräucherter Weisenfisch
21099	Rezept: Geräucherter Weisenfisch
21100	Münze der Urahnen
21103	Drachisch für Dummies
21104	Drachisch für Dummies
21105	Drachisch für Dummies
21106	Drachisch für Dummies
21107	Drachisch für Dummies
21108	Drachisch für Dummies
21109	Drachisch für Dummies
21110	Drachisch für Dummies
21111	Drachisch für Dummies: Band 2
21112	Magischer Bucheinband
21113	Wasserdichter Koffer
21114	Dunkler Rumsey-Rum
21115	Talisman der Entweihten
21116	Talisman der Entweihten
21117	Talisman von Arathor
21118	Talisman von Arathor
21119	Talisman von Arathor
21120	Talisman der Entweihten
21126	Stich des Todes
21128	Stab der Qirajipropheten
21130	Tagebuch von Weavil
21131	Nachfolgender Kampfauftrag
21132	Logistikauftrag
21133	Nachfolgender Taktischer Auftrag
21134	Dunkle Schneide des Irrsinns
21135	Assassinenwurfaxt
21136	Arkanitboje
21137	Blauer Szeptersplitter
21138	Roter Szeptersplitter
21139	Grüner Szeptersplitter
21140	Auktionspapiere
21141	Zerstörter roter Szeptersplitter
21142	Vom Schreibtisch des Lord Victor Nefarius
21143	Nicht unterzeichnete Felddienstpapiere
21144	Fackel zur Dämonenbeschwörung
21145	Essenz von Xandivious
21146	Verderbnisfragment des Alptraums
21147	Verderbnisfragment des Alptraums
21148	Verderbnisfragment des Alptraums
21149	Verderbnisfragment des Alptraums
21150	Eisenbeschlagener Koffer
21151	Schwarzer Rumsey Rum
21152	Die Verderbnis des Alptraums
21153	Roher großer Weisenfisch
21154	Festtagskleid
21155	Friedensangebot der Holzschlundfeste
21156	Skarabäustasche
21157	Grünes Festtagskleid
21158	Späherbericht des Zoraschwarms
21159	Späherbefehle des Zoraschwarms
21160	Späherbericht des Regalschwarms
21161	Späherbericht des Ashischwarms
21162	Aufgedunsener öliger Schwarzmaulfisch
21163	Aufgedunsener Feuerflossenschnapper
21164	Aufgedunsener Steinschuppenkabeljau
21165	Taktischer Einsatz VI
21166	Taktischer Einsatz VII
21167	Taktischer Einsatz VIII
21168	Babyhai
21171	Voller Festtagskrug
21173	Leerer Festtagskrug
21174	Leerer Festtagskrug
21175	Das Szepter der Sandstürme
21176	Schwarzer Qirajiresonanzkristall
21177	Symbol der Könige
21178	Handschuhe der Erdstärke
21179	Band des Erdzorns
21180	Erdschlag
21181	Erdanmut
21182	Band der Erdmacht
21183	Erdmachtweste
21184	Tiefsteinarmschienen
21185	Kugel der Erdruhe
21186	Felszornarmschienen
21187	Erdgewebeumhang
21188	Faust des Cenarius
21189	Macht des Cenarius
21190	Zorn des Cenarius
21191	Sorgfältig verpacktes Geschenk
21193	D'Saks Sack
21194	D'Saks großer Sack
21195	D'Saks Sacktastisch
21196	Siegelring des bronzenen Drachenschwarms
21197	Siegelring des bronzenen Drachenschwarms
21198	Siegelring des bronzenen Drachenschwarms
21199	Siegelring des bronzenen Drachenschwarms
21200	Siegelring des bronzenen Drachenschwarms
21201	Siegelring des bronzenen Drachenschwarms
21202	Siegelring des bronzenen Drachenschwarms
21203	Siegelring des bronzenen Drachenschwarms
21204	Siegelring des bronzenen Drachenschwarms
21205	Siegelring des bronzenen Drachenschwarms
21206	Siegelring des bronzenen Drachenschwarms
21207	Siegelring des bronzenen Drachenschwarms
21208	Siegelring des bronzenen Drachenschwarms
21209	Siegelring des bronzenen Drachenschwarms
21210	Siegelring des bronzenen Drachenschwarms
21211	Beutel mit Rentierstaub
21212	Frischer Tannenzweig
21213	Konservierter Tannenzweig
21214	Foliant des Frostblitzes XI
21215	Graccus hausgemachte Früchtepastete
21216	Kokelwälder Extraspezialgeschenk
21217	Weisenfisch Supreme
21218	Blauer Qirajiresonanzkristall
21219	Rezept: Weisenfisch Supreme
21220	Kopf von Ossirian dem Narbenlosen
21221	Auge von C'Thun
21222	Gepanzertes Chitin
21223	Schwarzer Stein
21224	Uraltes Rüstungsfragment
21225	Schwere Silithidenhülle
21226	Runenverzierter Stein
21227	Schädel eines uralten Helden
21228	Mithrilbeschlagener Koffer
21229	Insignien des Qirajilords
21230	Uraltes Qirajiartefakt
21232	Imperiale Qirajiwaffe
21235	Winterhauchbraten
21236	Winterhauchlaib
21237	Imperiale Qirajiinsignie
21240	Winterhauchbonbon
21241	Winterhaucheierflip
21242	Gesegnete Qirajikriegsaxt
21243	Aufgedunsener Machtfisch
21244	Gesegneter Qirajipugio
21245	Taktischer Einsatz I
21246	Kampfeinsatz I
21247	Kampfeinsatz II
21248	Kampfeinsatz IV
21249	Kampfeinsatz V
21250	Kampfeinsatz VI
21251	Kampfeinsatz VII
21252	Kampfeinsatz VIII
21253	Kampfeinsatz IX
21254	Winterhauchplätzchen
21255	Kampfeinsatz X
21256	Kampfeinsatz XI
21257	Logistikeinsatz IV
21258	Logistikeinsatz IV
21259	Logistikeinsatz V
21260	Logistikeinsatz VI
21261	Logistikeinsatz VI
21262	Logistikeinsatz VIII
21263	Logistikeinsatz VII
21264	Logistikeinsatz VII
21265	Logistikeinsatz IX
21266	Logistikauftrag
21267	Trinkbecher
21268	Gesegneter Qirajikriegshammer
21269	Gesegneter Qirajischild
21270	Leicht geschütteltes Geschenk
21271	Leicht geschütteltes Geschenk
21272	Gesegnete Qirajimuskete
21273	Gesegneter Akolythenstab der Qiraji
21275	Gesegneter Weissagungsstab der Qiraji
21277	Ruhiger mechanischer Yeti
21278	Sturmschleierhandschuhe
21279	Foliant des Feuerballs XII
21280	Foliant der arkanen Geschosse VIII
21281	Zauberfoliant des Schattenblitzes X
21282	Zauberfoliant des Feuerbrandes VIII
21283	Zauberfoliant der Verderbnis VII
21284	Kodex der großen Heilung V
21285	Kodex der Erneuerung X
21287	Kodex des Gebets der Heilung V
21288	Buchband: Segen der Weisheit VI
21289	Buchband: Segen der Macht VII
21290	Buchband: Heiliges Licht IX
21291	Schrifttafel der Welle der Heilung X
21292	Schrifttafel des Totems der Erdstärke V
21293	Schrifttafel des Totems der luftgleichen Anmut III
21294	Buch der heilenden Berührung XI
21295	Buch des Sternenfeuers VII
21296	Buch der Verjüngung XI
21297	Handbuch des heldenhaften Stoßes IX
21298	Handbuch des Schlachtrufs VII
21299	Handbuch der Rache VI
21300	Leitfaden des Meuchelns IX
21301	Grüne Helferbox
21302	Leitfaden des tödlichen Gifts V
21303	Leitfaden der Finte V
21304	Lehrbuch: Mehrfachschuss V
21305	Rote Helferbox
21306	Lehrbuch: Schlangenbiss IX
21307	Lehrbuch: Aspekt des Falken VII
21308	Bimmelglöckchen
21309	Schneemannset
21310	Fröhlich verpacktes Geschenk
21311	Weste des Erdenwächters
21312	Gürtel des Höhlenbehüters
21313	D'Saks kleine Tasche
21314	Metzens Briefe und Hinweise
21315	Kokelwälder Ranzen
21316	Gamaschen des Ursa
21317	Helm des Pfadfinders
21318	Handschuhe des Erdenwächters
21319	Handschuhe des Pfadfinders
21320	Weste des Höhlenbehüters
21321	Roter Qirajiresonanzkristall
21322	Ursas Umarmung
21323	Grüner Qirajiresonanzkristall
21324	Gelber Qirajiresonanzkristall
21325	Mechanischer Griesgram
21326	Verteidiger der Holzschlundfeste
21327	Tickendes Geschenk
21328	Zauberstab der Festtagsfreude
21329	Krone des Eroberers
21330	Schiftung des Eroberers
21331	Brustplatte des Eroberers
21332	Beinschützer des Eroberers
21333	Schienbeinschützer des Eroberers
21334	Roben des Verdammnisrufers
21335	Mantel des Verdammnisrufers
21336	Beinkleider des Verdammnisrufers
21337	Reif des Verdammnisrufers
21338	Fußlappen des Verdammnisrufers
21340	Seelenbeutel
21341	Teufelsstofftasche
21342	Kernteufelsstofftasche
21343	Roben des Mysteriums
21344	Stiefel des Mysteriums
21345	Schulterpolster des Mysteriums
21346	Gamaschen des Mysteriums
21347	Reif des Mysteriums
21348	Tiara des Orakels
21349	Fußlappen des Orakels
21350	Mantel des Orakels
21351	Tunika des Orakels
21352	Beinkleider des Orakels
21353	Helm der Genesis
21354	Schulterpolster der Genesis
21355	Stiefel der Genesis
21356	Beinkleider der Genesis
21357	Weste der Genesis
21358	Muster: Seelenbeutel
21359	Stiefel des Todesboten
21360	Helm des Todesboten
21361	Schiftung des Todesboten
21362	Gamaschen des Todesboten
21363	Festtagsgeschenk
21364	Weste des Todesboten
21365	Fußschützer des Hetzers
21366	Diadem des Hetzers
21367	Schulterstücke des Hetzers
21368	Gamaschen des Hetzers
21369	Muster: Teufelsstofftasche
21370	Halsberge des Hetzers
21371	Muster: Kernteufelsstofftasche
21372	Diadem des Sturmrufers
21373	Fußschützer des Sturmrufers
21374	Halsberge des Sturmrufers
21375	Gamaschen des Sturmrufers
21376	Schulterstücke des Sturmrufers
21377	Kopfputzfeder der Totenwaldfelle
21378	Logistikeinsatz I
21379	Logistikeinsatz II
21380	Logistikeinsatz III
21381	Logistikeinsatz IX
21382	Logistikeinsatz V
21383	Geisterperlen der Winterfelle
21384	Logistikeinsatz VIII
21385	Logistikeinsatz X
21386	Nachfolgender Logistikauftrag
21387	Krone des Rächers
21388	Schienbeinschützer des Rächers
21389	Brustplatte des Rächers
21390	Beinschützer des Rächers
21391	Schulterstücke des Rächers
21392	Sichel der unnachgiebigen Stärke
21393	Siegel der unnachgiebigen Stärke
21394	Tuch der unnachgiebigen Stärke
21395	Klinge der ewigen Gerechtigkeit
21396	Ring der ewigen Gerechtigkeit
21397	Cape der ewigen Gerechtigkeit
21398	Hammer der aufziehenden Stürme
21399	Ring der aufziehenden Stürme
21400	Umhang der aufziehenden Stürme
21401	Sense des unsichtbaren Pfads
21402	Siegel des unsichtbaren Pfads
21403	Umhang des unsichtbaren Pfads
21404	Dolch der Schattenschleier
21405	Band der Schattenschleier
21406	Umhang der Schattenschleier
21407	Streitkolben des endlosen Lebens
21408	Band des endlosen Lebens
21409	Umhang des endlosen Lebens
21410	Hammer der unendlichen Weisheit
21411	Ring der unendlichen Weisheit
21412	Schleier der unendlichen Weisheit
21413	Klinge der behüteten Geheimnisse
21414	Band der behüteten Geheimnisse
21415	Tuch der behüteten Geheimnisse
21416	Kris der ungesagten Namen
21417	Ring der ungesagten Namen
21418	Schleier der ungesagten Namen
21436	Belobigungsabzeichen der Allianz
21438	Belobigungsabzeichen der Horde
21452	Stab der Ruinen
21453	Mantel von Horusath
21454	Schultern mit runenverzierten Steinen
21455	Helm des Südwinds
21456	Sandsturmumhang
21457	Armschienen der Unbarmherzigkeit
21458	Stulpen des neuen Lebens
21459	Armbrust der bevorstehenden Verdammnis
21460	Helm der Herrschaft
21461	Gamaschen des schwarzen Sturms
21462	Handschuhe der düsteren Weisheit
21463	Ossirians Bindung
21464	Fesseln des Narbenlosen
21466	Stachel von Ayamiss
21467	Dicker Silithidenbrustschutz
21468	Mantel von Maz'Nadir
21469	Stulpen des Südwinds
21470	Umhang des Retters
21471	Kralle der gewaltigen Konzentration
21472	Turban der staubigen Winde
21473	Auge von Moam
21474	Chitinschulterschutz
21475	Beinplatten des Zerstörers
21476	Obsidianschuppengamaschen
21477	Ring des Zorns
21478	Bogen der straffen Sehne
21479	Stulpen des Unbeweglichen
21480	Stulpen aus Silithidenschuppen
21481	Stiefel des Wüstenbeschützers
21482	Stiefel der feurigen Sande
21483	Ring der Wüstenwinde
21484	Helm des Nachwachsens
21485	Burus Schädelfragment
21486	Handschuhe des Schwarms
21487	Schleimige Schuppenstulpen
21488	Chitinstachelfetisch
21489	Treibsandwandler
21490	Schleimkicker
21491	Schuppenarmschienen des Verschlingers
21492	Menschentöter der Qiraji
21493	Stiefel des Vorposten
21494	Südwinds Griff
21495	Beinplatten des Qirajikommandos
21496	Armschienen des Qirajikommandos
21497	Stiefel des Qirajigenerals
21498	Opferdolch der Qiraji
21499	Gewänder der Sandstürme
21500	Gürtel der Inquisition
21501	Handschuhe aus gekräftigter Silithidenhaut
21502	Handgelenksschutz des Sandhäschers
21503	Gürtel des Sandhäschers
21504	Glücksbringer der Sandstürme
21505	Halsschmuck der Sandstürme
21506	Anhänger der Sandstürme
21507	Amulett der Sandstürme
21508	Mal des Cenarius
21509	Kriegsmaterial für Ahn'Qiraj
21510	Kriegsmaterial für Ahn'Qiraj
21511	Kriegsmaterial für Ahn'Qiraj
21512	Kriegsmaterial für Ahn'Qiraj
21513	Kriegsmaterial für Ahn'Qiraj
21514	Logistikeinsatz XI
21515	Mal von Remulos
21517	Turban der gnomischen Superpsychokräfte
21519	Mistelzweig
21520	Ravencrests Vermächtnis
21521	Runenschwert des Roten
21522	Shadowsongs Kummer
21523	Fangzahn von Korialstrasz
21524	Rote Wintermütze
21525	Grüne Wintermütze
21526	Band der eisigen Tiefen
21527	Dunkelwasserroben
21528	Riesige Beutetasche
21529	Amulett der Schattenabwehr
21530	Gamaschen mit Onyxeinbettung
21531	Drachenzahnhalskette
21532	Zwangsarbeiterstiefel
21533	Fragment vom Koloss des Zoraschwarms
21534	Fragment vom Koloss des Ashischwarms
21535	Fragment vom Koloss des Regalschwarms
21536	Elunes Stein
21537	Festtagsklöße
21538	Rosa Festtagskleid
21539	Lila Festtagskleid
21540	Elunes Laterne
21541	Festlicher schwarzer Hosenanzug
21542	Festtagsanzug
21543	Festlicher mintgrüner Hosenanzug
21544	Festlicher blauer Hosenanzug
21545	Vorräte der Kokelwälder
21546	Elixier der großen Feuermacht
21547	Rezept: Elixier der großen Feuermacht
21548	Muster: Sturmschleierhandschuhe
21552	Streifengelbschwanz
21557	Kleine rote Rakete
21558	Kleine blaue Rakete
21559	Kleine grüne Rakete
21560	Kleine lila Rakete
21561	Kleine weiße Rakete
21562	Kleine gelbe Rakete
21563	Don Rodrigos Band
21565	Rune der Perfektion
21566	Rune der Perfektion
21567	Rune der Pflicht
21568	Rune der Pflicht
21569	Zünder für Feuerwerk
21570	Zünder für Raketenbündel
21571	Blaues Raketenbündel
21574	Grünes Raketenbündel
21575	Lila Raketenbündel
21576	Rotes Raketenbündel
21577	Weißes Raketenbündel
21578	Gelbes Raketenbündel
21579	Bezwungene Tentakel von C'Thun
21581	Stulpen der Vernichtung
21582	Griff des alten Gottes
21583	Umhang der Klarsicht
21584	Armschienen der endgültigen Abrechnung
21585	Stulpen der dunklen Stürme
21586	Gürtel der endlosen Pein
21587	Handgelenksschutz der Züchtigung
21588	Handgelenksschutz des Elementarfurors
21589	Große blaue Rakete
21590	Große grüne Rakete
21591	Große lila Rakete
21592	Große rote Rakete
21593	Große weiße Rakete
21594	Armschienen des gefallenen Sohns
21595	Große gelbe Rakete
21596	Ring des Göttertöters
21597	Königliches Szepter von Vek'lor
21598	Königlicher Qirajigürtel
21599	Vek'lors Handschuhe der Verwüstung
21600	Stiefel der göttlichen Erscheinung
21601	Ring des Imperators Vek'lor
21602	Vollstreckungsarmschienen der Qiraji
21603	Zauberstab des Qirajiadels
21604	Armreifen der königlichen Erlösung
21605	Handschuhe des verborgenen Tempels
21606	Gürtel des gefallenen Imperators
21607	Griff des gefallenen Imperators
21608	Amulett von Vek'nilash
21609	Vek'nilashs Gürtel der Regeneration
21610	Wurmschuppenblocker
21611	Armschienen des Wühlers
21612	Wurmschuppenstampfer
21613	Wurmhautstiefel
21614	Wurmhautbeschützer
21615	Don Rigobertos verlorener Hut
21616	Huhurans Stachel
21617	Wespenhautstulpen
21618	Handgelenksschutz des Schwarmbauentweihers
21619	Handschuhe des Messias
21620	Ring des Märtyrers
21621	Umhang des goldenen Schwarms
21622	Geschärfter Silithidenknochen
21623	Stulpen des rechtschaffenen Champions
21624	Stulpen von Kalimdor
21625	Skarabäusbrosche
21626	Schleimbeschichtete Gamaschen
21627	Umhang der ungelüfteten Geheimnisse
21635	Widerhaken des Sandhäschers
21639	Schulterstücke des Unerbittlichen
21640	Feuerwerkspaket des Mondfests
21645	Stiefel des Schwarmbaugräbers
21647	Fetisch des Sandhäschers
21648	Zusammengesetzte Stiefel
21650	Uralter Qirajizerfetzer
21651	Schuppengamaschen des Sandhäschers
21652	Brustschutz aus Silithidenknochenpanzer
21663	Roben des Schutzheiligen
21664	Stachelhalsschmuck
21665	Mantel der boshaften Rache
21666	Sarturas Macht
21667	Beinplatten des flammenden Lichts
21668	Schuppengamaschen des Qirajizorns
21669	Kriecherrankenhelm
21670	Abzeichen der Schwarmwache
21671	Roben der Schlachtwache
21672	Handschuhe der Vollstreckung
21673	Silithidenklaue
21674	Stulpen der festen Entschlossenheit
21675	Dicker Qirajihautgürtel
21676	Gamaschen des faulenden Schwarms
21677	Ring des Qirajizorns
21678	Halskette der Reinheit
21679	Kalimdors Rache
21680	Weste der zügigen Vollstreckung
21681	Ring des Verschlungenen
21682	Gallenbespritzte Stulpen
21683	Mantel des Wüstenfeldzugs
21684	Mantel des Wüstenzorns
21685	Versteinerter Skarabäus
21686	Mantel der inneren Kraft
21687	Ukkos Ring der Dunkelheit
21688	Stiefel des gefallenen Helden
21689	Handschuhe von Ebru
21690	Angelistas Glücksbringer
21691	Brühschlammige Stulpen
21692	Triadengurt
21693	Erscheinung des Verschlingers
21694	Dreistoffmantel
21695	Angelistas Berührung
21696	Roben des Dreigestirns
21697	Cape der Dreifaltigkeit
21698	Gamaschen der bodenlosen Tiefe
21699	Sperrfeuerschultern
21700	Anhänger des Qirajiwächters
21701	Umhang des geballten Hasses
21702	Amulett des faulen Zauberschutzes
21703	Hammer von Ji'zhi
21704	Stiefel der widerrufenen Prophezeiung
21705	Stiefel des gefallenen Propheten
21706	Stiefel des standhaften Willens
21707	Ring des wirren Gedankens
21708	Handgelenksschutz aus Käferschuppen
21709	Ring des gefallenen Gottes
21710	Umhang des gefallenen Gottes
21711	Mondfesteinladung
21712	Amulett des gefallenen Gottes
21713	Elunes Kerze
21714	Großes blaues Raketenbündel
21715	Sandpolierter Hammer
21716	Großes grünes Raketenbündel
21717	Großes lila Raketenbündel
21718	Großes rotes Raketenbündel
21719	Großes weißes Raketenbündel
21720	Großes gelbes Raketenbündel
21721	Mondschein
21722	Muster: Festtagskleid
21723	Muster: Festtagsanzug
21724	Bauplan: Kleine blaue Rakete
21725	Bauplan: Kleine grüne Rakete
21726	Bauplan: Kleine rote Rakete
21727	Bauplan: Große blaue Rakete
21728	Bauplan: Große grüne Rakete
21729	Bauplan: Große rote Rakete
21730	Bauplan: Blaues Raketenbündel
21731	Bauplan: Grünes Raketenbündel
21732	Bauplan: Rotes Raketenbündel
21733	Bauplan: Großes blaues Raketenbündel
21734	Bauplan: Großes grünes Raketenbündel
21735	Bauplan: Großes rotes Raketenbündel
21736	Reitgreifenzügel
21737	Bauplan: Zünder für Raketenbündel
21738	Bauplan: Zünder für Feuerwerk
21739	Mondfesteinladung
21740	Rezepte für kleine Raketen
21741	Rezepte für Raketenbündel
21742	Rezepte für große Raketen
21743	Rezepte für große Raketenbündel
21744	Glücksraketenbündel
21745	Mondstein der Urahnen
21746	Roter Glücksumschlag
21747	Festtagsknallfrosch
21749	Kampfeinsatz I
21750	Kampfeinsatz II
21751	Taktischer Einsatz III
21761	Schlüssel für einen Skarabäuskasten
21762	Schlüssel für einen großen Skarabäuskasten
21800	Silithidhülsenzünder
21801	Fühler der Kräftigung
21802	Der verlorene Kris von Zedd
21803	Helm des heiligen Rächers
21804	Helmkappe des Elementarfurors
21805	Polierte Obsidianschulterstücke
21806	Hammer der Qirajigewalt
21809	Zorn des vergessenen Schwarms
21810	Treter des wandernden Nomaden
21812	Schokoladenschachtel
21813	Bonbontüte
21814	Brustplatte der Vernichtung
21815	Zeichen der Liebe
21816	Zuckerherz
21817	Zuckerherz
21818	Zuckerherz
21819	Zuckerherz
21820	Zuckerherz
21821	Zuckerherz
21822	Zuckerherz
21823	Zuckerherz
21829	Parfümflakon
21830	Leere Pralinenhülle
21831	Eingepacktes Geschenk
21833	Duftwasserflakon
21836	Ritssyns Ring des Chaos
21837	Kriegshammer des Anubisath
21838	Gewand des königlichen Aufstiegs
21839	Szepter des falschen Propheten
21856	Neretzek der Bluttrinker
21888	Handschuhe des Unsterblichen
21889	Handschuhe der widerrufenen Prophezeiung
21890	Handschuhe des gefallenen Propheten
21891	Splitter des gefallenen Sterns
21920	Zerknitterter Brief
21921	Sorgfältig verfasste Notiz
21925	Makelloser Brief
21926	Leicht zerknitterte Notiz
21928	Blutprobe aus Winterspring
21935	Stabiles Ektoplasma
21936	Gefrorenes Ektoplasma
21937	Versengtes Ektoplasma
21938	Magmakern
21939	Teufelselementarer Brennstab
21946	Ektoplasmadestillierer
21960	Handgefertigte Schnitzerei
21975	Pfand der Verehrung: Stormwind
21979	Geschenk der Verehrung: Darnassus
21980	Geschenk der Verehrung: Ironforge
21981	Geschenk der Verehrung: Stormwind
21982	Ogerkriegsperlen
21983	Unvervollständigtes Banner der Provokation
21984	Linkes Stück von Lord Valthalaks Amulett
21985	Versiegelter Blutbehälter
21986	Banner der Provokation
21987	Incendius' Pyrophor
21988	Glutsehers Glut
21989	Asche des Fürsten
21994	Gürtel des Heldentums
21995	Stiefel des Heldentums
21996	Armschienen des Heldentums
21997	Brustplatte des Heldentums
21998	Stulpen des Heldentums
21999	Helm des Heldentums
22000	Beinplatten des Heldentums
22001	Schiftung des Heldentums
22002	Gürtel der Finsternis
22003	Stiefel der Finsternis
22004	Armschienen der Finsternis
22005	Kappe der Finsternis
22006	Handschuhe der Finsternis
22007	Hose der Finsternis
22008	Schiftung der Finsternis
22009	Tunika der Finsternis
22010	Gürtel der Tierherrschaft
22011	Bindungen der Tierherrschaft
22013	Kappe der Tierherrschaft
22014	Geheiligtes Räuchergefäß
22015	Handschuhe der Tierherrschaft
22016	Mantel der Tierherrschaft
22017	Hose der Tierherrschaft
22046	Rechtes Stück von Lord Valthalaks Amulett
22047	Obere Stück von Lord Valthalaks Amulett
22048	Lord Valthalaks Amulett
22049	Räuchergefäß der Beschwörung
22050	Räuchergefäß der Beschwörung
22051	Räuchergefäß der Beschwörung
22052	Räuchergefäß der Beschwörung
22056	Räuchergefäß der Beschwörung
22057	Räuchergefäß der Anrufung
22058	Valentinsbriefpapier
22059	Valentinsgrußkarte
22060	Tunika der Tierherrschaft
22061	Stiefel der Tierherrschaft
22062	Gürtel der Zauberkünste
22063	Bindungen der Zauberkünste
22064	Stiefel der Zauberkünste
22065	Krone der Zauberkünste
22066	Handschuhe der Zauberkünste
22067	Gamaschen der Zauberkünste
22068	Mantel der Zauberkünste
22069	Roben der Zauberkünste
22070	Gürtel des Todesnebels
22071	Armschienen des Todesnebels
22072	Gamaschen des Todesnebels
22073	Mantel des Todesnebels
22074	Maske des Todesnebels
22075	Robe des Todesnebels
22076	Sandalen des Todesnebels
22077	Wickeltücher des Todesnebels
22078	Gürtel des Tugendhaften
22079	Armschienen des Tugendhaften
22080	Krone des Tugendhaften
22081	Handschuhe des Tugendhaften
22082	Mantel des Tugendhaften
22083	Robe des Tugendhaften
22084	Sandalen des Tugendhaften
22085	Rock des Tugendhaften
22086	Gürtel der Seelenschmiede
22087	Stiefel der Seelenschmiede
22088	Armschienen der Seelenschmiede
22089	Brustplatte der Seelenschmiede
22090	Stulpen der Seelenschmiede
22091	Helm der Seelenschmiede
22092	Beinplatten der Seelenschmiede
22093	Schiftung der Seelenschmiede
22094	Bluttang
22095	Bindungen der fünf Donner
22096	Stiefel der fünf Donner
22097	Helmkappe der fünf Donner
22098	Kordel der fünf Donner
22099	Stulpen der fünf Donner
22100	Kilt der fünf Donner
22101	Schulterstücke der fünf Donner
22102	Weste der fünf Donner
22106	Gürtel des ungezähmten Herzens
22107	Stiefel des ungezähmten Herzens
22108	Armschienen des ungezähmten Herzens
22109	Kutte des ungezähmten Herzens
22110	Handschuhe des ungezähmten Herzens
22111	Kilt des ungezähmten Herzens
22112	Schiftung des ungezähmten Herzens
22113	Weste des ungezähmten Herzens
22114	Rosa Murlocei
22115	Extradimensionaler Geisterdetektor
22117	Pfand der Treue: Stormwind
22119	Pfand der Treue: Ironforge
22120	Pfand der Treue: Darnassus
22121	Pfand der Treue: Undercity
22122	Pfand der Treue: Thunder Bluff
22123	Pfand der Treue: Orgrimmar
22130	Symbol der Liebe
22131	Geschenkesammlung von Stormwind
22132	Geschenkesammlung von Ironforge
22133	Geschenkesammlung von Darnassus
22134	Geschenkesammlung von Undercity
22135	Geschenkesammlung von Thunder Bluff
22136	Geschenkesammlung von Orgrimmar
22137	Ysidas Ranzen
22138	Blackrockarmschienen
22139	Ysidas Medaillon
22140	Karte der Schildwache
22141	Karte der Wache von Ironforge
22142	Karte des Grunzers
22143	Karte der Wache von Stormwind
22144	Karte des Behüters von Thunder Bluff
22145	Modrige Karte des Wächters
22149	Perlen des Ogermojo
22150	Perlen der Ogermacht
22151	Anthions heiliges Wasser
22152	Anthions Beutel
22154	Pfand der Verehrung: Ironforge
22155	Pfand der Verehrung: Darnassus
22156	Pfand der Verehrung: Orgrimmar
22157	Pfand der Verehrung: Undercity
22158	Pfand der Verehrung: Thunder Bluff
22159	Pfand der Freundschaft: Darnassus
22160	Pfand der Freundschaft: Ironforge
22161	Pfand der Freundschaft: Orgrimmar
22162	Pfand der Freundschaft: Thunder Bluff
22163	Pfand der Freundschaft: Undercity
22164	Geschenk der Verehrung: Orgrimmar
22165	Geschenk der Verehrung: Thunder Bluff
22166	Geschenk der Verehrung: Undercity
22167	Geschenk der Freundschaft: Darnassus
22168	Geschenk der Freundschaft: Ironforge
22169	Geschenk der Freundschaft: Orgrimmar
22170	Geschenk der Freundschaft: Stormwind
22171	Geschenk der Freundschaft: Thunder Bluff
22172	Geschenk der Freundschaft: Undercity
22173	Hausgemachtes Zwergenbier
22174	Romantisches Gedicht
22175	Frisch gebackener Kuchen
22176	Hausgemachtes Brot
22177	Frisch gepflückte Blumen
22178	Pfand der Freundschaft: Stormwind
22191	Obsidianpanzertunika
22192	Bluttangelixier des Ausweichens
22193	Bluttangelixier des Widerstands
22194	Dunkler Griff des Zerstörers
22195	Leichter Obsidiangürtel
22196	Dicke Obsidianbrustplatte
22197	Schwerer Obsidiangürtel
22198	Gezackter Obsidianschild
22200	Silberschaftpfeil
22201	Reliquiar der Reinheit
22202	Kleiner Obsidiansplitter
22203	Großer Obsidiansplitter
22204	Handgelenksschutz des Ruhms
22205	Schwarzstahlbindungen
22206	Roter Rosenstrauß
22207	Schärpe der großen Jagd
22208	Hammer aus Lavagestein
22209	Pläne: Schwerer Obsidiangürtel
22212	Schulterstücke der Golempanzerung
22214	Pläne: Leichter Obsidiangürtel
22216	Venoxis' Giftbeutel
22217	Kurinnaxx' Giftbeutel
22218	Handvoll Rosenblüten
22219	Pläne: Gezackter Obsidianschild
22220	Pläne: Dunkler Griff des Zerstörers
22221	Pläne: Obsidianpanzertunika
22222	Pläne: Dicke Obsidianbrustplatte
22223	Kopfschutz des Großknechts
22224	Essenz eines spöttischen Geisterwesens
22225	Drachenhautkutte
22226	Druidenüberreste
22227	Relikt von Starbreeze
22228	Gleißendes Schwert des Zeloten
22229	Seelenasche der Verbannten
22230	Furchtschlundleder
22231	Kaysers Stiefel der Präzision
22232	Schützengurt
22233	Zigris' Schließkiste
22234	Mantel der verlorenen Hoffnung
22235	Echtsilberschaftpfeil
22236	Buttermilchküsschen
22237	Dunkle Versuchung
22238	Beerens Echte
22239	Süße Träume
22240	Schienbeinschützer der schwindenden Verzweiflung
22241	Schulterstücke des dunklen Wächters
22242	Vereks Leine
22243	Kleiner Seelenbeutel
22244	Seelenkasten
22245	Rußgeschwärzte Stiefel
22246	Verzauberter Magiestoffbeutel
22247	Stiefel der heilenden Psalme
22248	Verzauberte Runenstofftasche
22249	Große Verzauberertasche
22250	Kräuterbeutel
22251	Cenarische Kräutertasche
22252	Cenarischer Ranzen
22253	Foliant der Verlorenen
22254	Zauberstab des ewigen Lichts
22255	Magmageschmiedetes Band
22256	Handlappen des Manaformers
22257	Band aus geronnenem Blut
22258	Liebestrank
22259	Nicht vergebenes Freundschaftsband
22260	Freundschaftsband
22261	Liebesschwindler
22262	Geschenkesammlung der Allianz
22263	Geschenkesammlung der Horde
22264	Sorgfältig verfasster Brief
22265	Liebevoll verfasster Brief
22266	Flammendorn
22267	Spruchwirkerturban
22268	Emblem der drachischen Macht
22269	Schattenschleicherumhang
22270	Schanzstiefel
22271	Gamaschen der wallenden Magie
22272	Umarmung des Waldes
22273	Mondschattenkapuze
22274	Ergrauter Pelz
22275	Feuermoosstiefel
22276	Reizendes rotes Kleid
22277	Roter Abendanzug
22278	Reizendes blaues Kleid
22279	Reizendes schwarzes Kleid
22280	Reizendes lila Kleid
22281	Blauer Abendanzug
22282	Lila Abendanzug
22283	Brotsack mit hausgemachtem Brot
22284	Kartenbündel
22285	Pfandsammlung von Stormwind
22286	Pfandsammlung von Ironforge
22287	Kartenpaket
22288	Kiste hausgemachtes Bier
22289	Kartenstapel
22290	Pfandsammlung von Darnassus
22291	Schachtel voller Holzschnitzereien
22292	Schachtel voller frischer Kuchen
22293	Kartenpack
22294	Pfandsammlung von Orgrimmar
22295	Kartensammlung
22296	Blumenkorb
22297	Pfandsammlung von Thunder Bluff
22298	Romantische Gedichtesammlung
22299	Kartenstoß
22300	Pfandsammlung von Undercity
22301	Eisengewebte Robe
22302	Eisengewebte Kutte
22303	Eisengewebte Hose
22304	Eisengewebte Handschuhe
22305	Eisengewebter Mantel
22306	Eisengewebter Gürtel
22307	Muster: Verzauberter Magiestoffbeutel
22308	Muster: Verzauberte Runenstofftasche
22309	Muster: Große Verzauberertasche
22310	Muster: Cenarische Kräutertasche
22311	Eisengewebte Stiefel
22312	Muster: Cenarischer Ranzen
22313	Eisengewebte Armschienen
22314	Harpune des Jägersmanns
22315	Hammer der Wiederbelebung
22317	Leftys Messingschlagring
22318	Malgens Langbogen
22319	Foliant des göttlichen Rechts
22320	Mux' Qualitätswaren
22321	Herz von Wyrmthalak
22322	Der Kieferknacker
22324	Winterkimchi
22325	Gürtel des Schwindlers
22326	Amalgams Band
22327	Amulett des Erlösten
22328	Beinplatten der Wachsamkeit
22329	Szepter der grenzenlosen Konzentration
22330	Tuch der arkanen Meisterschaft
22331	Band des standhaften Helden
22332	Klinge der Totenbeschwörung
22333	Hammer der göttlichen Macht
22334	Heilungsband
22335	Lord Valthalaks Befehlsstab
22336	Drakonische Aegis der Legion
22337	Tuch der Herrschaft
22338	Vulkanasche
22339	Runenband der Zauberei
22340	Anhänger der Schnelligkeit
22342	Gamaschen der Qual
22343	Handschützer der Wildheit
22344	Handbuch: Räuchergefäß der Anrufung
22345	Totem der Wiedergeburt
22347	Fahrads selbstladende Repetierarmbrust
22348	Schicksalsbringer
22349	Entweihte Brustplatte
22350	Entweihte Tunika
22351	Entweihte Robe
22352	Entweihte Beinplatten
22353	Entweihter Helm
22354	Entweihte Schulterstücke
22355	Entweihte Armschienen
22356	Entweihter Taillenschutz
22357	Entweihte Stulpen
22358	Entweihte Sabatons
22359	Entweihte Beinschützer
22360	Entweihtes Kopfstück
22361	Entweihte Schiftung
22362	Entweihter Handgelenksschutz
22363	Entweihter Gurt
22364	Entweihte Handschützer
22365	Entweihte Stiefel
22366	Entweihte Gamaschen
22367	Entweihter Reif
22368	Entweihte Schulterpolster
22369	Entweihte Bindungen
22370	Entweihter Gürtel
22371	Entweihte Handschuhe
22372	Entweihte Sandalen
22373	Kampfzerschlissenes Lederstück
22374	Kampfzerschlissenes Kettenstück
22375	Kampfzerschlissenes Plattenstück
22376	Kampfzerschlissenes Stoffstück
22377	Donnerholzschüreisen
22378	Ravenholdtschnitzler
22379	Shivsprokets Messer
22380	Simones Hammer der Kultivierung
22381	Giftprobe aus Silithus
22382	Versiegelter Giftbehälter
22383	Weisenklinge
22384	Willensbrecher
22385	Gamaschen der Titanen
22386	Head of Instructor Razuvious DEP
22387	Herz von Anub'Rekhan
22388	Pläne: Gamaschen der Titanen
22389	Pläne: Weisenklinge
22390	Pläne: Willensbrecher
22392	Formel: Zweihandwaffe - Beweglichkeit
22393	Kodex: Gebet des Schattenschutzes
22394	Stab der Metanoia
22395	Totem des Zorns
22396	Totem des Lebens
22397	Götze der Wildheit
22398	Götze der Verjüngung
22399	Götze der Gesundheit
22400	Buchband der Wahrheit
22401	Buchband der Hoffnung
22402	Buchband der Anmut
22403	Perlmuttmuschelhalskette
22404	Willeys Rückenkratzer
22405	Mantel des Scharlachroten Kreuzzugs
22406	Erlöser
22407	Helm des Neumonds
22408	Ritssyns Zauberstab des schlechten Mojo
22409	Tunika des Sichelmonds
22410	Stulpen des Geschicks
22411	Helm des Henkers
22412	Thuzadinmantel
22416	Brustplatte des Schreckenspanzers
22417	Beinplatten des Schreckenspanzers
22418	Helm des Schreckenspanzers
22419	Schulterstücke des Schreckenspanzers
22420	Sabatons des Schreckenspanzers
22421	Stulpen des Schreckenspanzers
22422	Taillenschutz des Schreckenspanzers
22423	Armschienen des Schreckenspanzers
22424	Handgelenksschutz der Erlösung
22425	Tunika der Erlösung
22426	Handschützer der Erlösung
22427	Beinschützer der Erlösung
22428	Kopfstück der Erlösung
22429	Schiftung der Erlösung
22430	Stiefel der Erlösung
22431	Gurt der Erlösung
22432	Teufelssaurierhaken
22433	Don Mauricio's Band der Herrschaft
22434	Blutkappenpilz
22435	Gorishistachel
22436	Tunika des Gruftpirschers
22437	Beinschützer des Gruftpirschers
22438	Kopfstück des Gruftpirschers
22439	Schiftung des Gruftpirschers
22440	Stiefel des Gruftpirschers
22441	Handschützer des Gruftpirschers
22442	Gurt des Gruftpirschers
22443	Handgelenksschutz des Gruftpirschers
22444	Fäulnisranke
22458	Mondschattenstock
22464	Tunika des Erdspalters
22465	Beinschützer des Erdspalters
22466	Kopfstück des Erdspalters
22467	Schiftung des Erdspalters
22468	Stiefel des Erdspalters
22469	Handschützer des Erdspalters
22470	Gurt des Erdspalters
22471	Handgelenksschutz des Erdspalters
22472	Stiefel der Wildheit
22476	Brustplatte der Knochensense
22477	Beinplatten der Knochensense
22478	Helm der Knochensense
22479	Schulterstücke der Knochensense
22480	Sabatons der Knochensense
22481	Stulpen der Knochensense
22482	Taillenschutz der Knochensense
22483	Armschienen der Knochensense
22484	Nekrotische Rune
22488	Tunika des Traumwandlers
22489	Beinschützer des Traumwandlers
22490	Kopfstück des Traumwandlers
22491	Schiftung des Traumwandlers
22492	Stiefel des Traumwandlers
22493	Handschützer des Traumwandlers
22494	Gurt des Traumwandlers
22495	Handgelenksschutz des Traumwandlers
22496	Frostfeuerrobe
22497	Frostfeuergamaschen
22498	Frostfeuerreif
22499	Frostfeuerschulterpolster
22500	Frostfeuersandalen
22501	Frostfeuerhandschuhe
22502	Frostfeuergürtel
22503	Frostfeuerbindungen
22504	Robe des verseuchten Herzens
22505	Gamaschen des verseuchten Herzens
22506	Reif des verseuchten Herzens
22507	Schulterpolster des verseuchten Herzens
22508	Sandalen des verseuchten Herzens
22509	Handschuhe des verseuchten Herzens
22510	Gürtel des verseuchten Herzens
22511	Bindungen des verseuchten Herzens
22512	Robe des Glaubens
22513	Gamaschen des Glaubens
22514	Reif des Glaubens
22515	Schulterpolster des Glaubens
22516	Sandalen des Glaubens
22517	Handschuhe des Glaubens
22518	Gürtel des Glaubens
22519	Bindungen des Glaubens
22520	Kel'Thuzads Phylakterium
22523	Insignie der Dämmerung
22524	Insignie des Kreuzzugs
22525	Teile einer Gruftsatanskreatur
22526	Knochenfragmente
22527	Kern der Elemente
22528	Dunkeleisenfragmente
22529	Wildwedel
22568	Versiegelte Handwerksverfügung
22589	Atiesh, Hohestab des Wächters
22593	Verfügung des freien Geleits
22595	Ruf zu den Waffen
22600	Handwerksverfügung - Verdichteter Gewichtsstein
22601	Handwerksverfügung - Imperiale Plattenrüstung
22602	Handwerksverfügung - Vulkanischer Hammer
22603	Handwerksverfügung - Gewaltige Thoriumstreitaxt
22604	Handwerksverfügung - Strahlender Reif
22605	Handwerksverfügung - Tückisches Lederstirnband
22606	Handwerksverfügung - Unverwüstliches Rüstungsset
22607	Handwerksverfügung - Tückischer Ledergürtel
22608	Handwerksverfügung - Runenverzierte Lederhose
22609	Handwerksverfügung - Hellstoffhose
22610	Handwerksverfügung - Runenstoffstiefel
22611	Handwerksverfügung - Runenstofftasche
22612	Handwerksverfügung - Runenstoffrobe
22613	Handwerksverfügung - Goblinsche Pioniersprengladung
22614	Handwerksverfügung - Thoriumgranate
22615	Handwerksverfügung - Gnomen-Kampfhuhn
22616	Handwerksverfügung - Thoriumröhre
22617	Handwerksverfügung - Erheblicher Manatrank
22618	Handwerksverfügung - Erheblicher Heiltrank
22619	Handwerksverfügung - Großer Frostschutztrank
22620	Handwerksverfügung - Großer Arkanschutztrank
22621	Handwerksverfügung - Fläschchen der Versteinerung
22622	Handwerksverfügung - Steinschuppenaal
22623	Handwerksverfügung - Panzerfisch
22624	Handwerksverfügung - Zitteraal
22625	Handwerksverfügung - Gebackener Lachs
22626	Handwerksverfügung - Runn Tum Knolle Surprise
22630	Atiesh, Hohestab des Wächters
22631	Atiesh, Hohestab des Wächters
22632	Atiesh, Hohestab des Wächters
22635	Greuelwächter
22636	Eiswächter
22637	Urzeitlicher Hakkarigötze
22638	Schattenwächter
22648	Ashischwarmprotokoll
22649	Regalschwarmprotokoll
22650	Zoraschwarmprotokoll
22651	Plattenbeinschützer der Vorhut
22652	Gletscherweste
22654	Gletscherhandschuhe
22655	Gletscherhandschutz
22656	Der Läuterer
22657	Amulett der Dämmerung
22658	Gletscherumhang
22659	Medaillon der Dämmerung
22660	Gaeas Umarmung
22661	Polartunika
22662	Polarhandschuhe
22663	Polararmschienen
22664	Eisschuppenbrustplatte
22665	Eisschuppenarmschienen
22666	Eisschuppenstulpen
22667	Armschienen der Hoffnung
22668	Armschienen der Täuschung
22669	Eisfluchbrustplatte
22670	Eisfluchstulpen
22671	Eisflucharmschienen
22672	Plattenbeinschützer der Schildwache
22673	Kettengamaschen der Vorhut
22676	Panzergamaschen der Vorhut
22678	Talisman der Überlegenheit
22679	Vorratstasche
22680	Band der Resolution
22681	Band der Frömmigkeit
22682	Gefrorene Rune
22683	Muster: Gaeas Umarmung
22684	Muster: Gletscherhandschuhe
22685	Muster: Gletscherumhang
22686	Muster: Gletscherweste
22687	Muster: Gletscherhandschutz
22688	Verimondes letzter Ausweg
22689	Geweihter Lederhelm
22690	Gamaschen des Seuchenjägers
22691	Verderbter Aschenbringer
22692	Muster: Polartunika
22694	Muster: Polarhandschuhe
22695	Muster: Polararmschienen
22696	Muster: Eisschuppenbrustplatte
22697	Muster: Eisschuppenstulpen
22698	Muster: Eisschuppenarmschienen
22699	Eisfluchgamaschen
22700	Gletschergamaschen
22701	Polargamaschen
22702	Eisschuppengamaschen
22703	Muster: Eisfluchbrustplatte
22704	Muster: Eisfluchstulpen
22705	Muster: Eisflucharmschienen
22707	Ramaladnis eisiger Griff
22708	Ramaladnis Schicksal
22711	Umhang der Hakkarianbeter
22712	Macht der Stämme
22713	Zulianisches Szepter der Riten
22714	Opferungsstulpen
22715	Handschuhe der Gequälten
22716	Gürtel der unversehrten Kraft
22718	Blutdurchnässte Maske
22719	Omarions Leitfaden
22720	Zulianischer Kopfputz
22721	Band der Knechtschaft
22722	Siegel des Gurubashiberserkers
22723	Brief vom Bewahrer der Schriften
22725	Band des Cenarius
22726	Bruchstück von Atiesh
22727	Grundstab von Atiesh
22728	Dampfpanzersteuerung
22729	Bauplan: Dampfpanzersteuerung
22730	Augenstrangkordel
22731	Umhang des Verschlungenen
22732	Mal von C'Thun
22733	Stabkopf von Atiesh
22734	Stabfuß von Atiesh
22736	Andosius, Der Seelenschlächter
22737	Atiesh, Hohestab des Wächters
22739	Foliant der Verwandlung: Schildkröte
22740	Lederhose der Vorhut
22741	Echsenlederhose der Vorhut
22742	Blutsegelhemd
22743	Blutsegelschärpe
22744	Blutsegelstiefel
22745	Blutsegelhose
22746	Uniform der Bukaniere
22747	Seidene Gamaschen der Vorhut
22748	Kettengamaschen der Schildwache
22749	Lederhose der Schildwache
22750	Echsenlederhose der Schildwache
22752	Seidene Gamaschen der Schildwache
22753	Lamellenbeinschützer der Schildwache
22754	Ewige Quintessenz
22756	Sylvanweste
22757	Sylvankrone
22758	Sylvanschultern
22759	Dornenholzhelm
22760	Dornenholzstiefel
22761	Dornenholzgürtel
22762	Eisenrankenbrustplatte
22763	Eisenrankenhandschuhe
22764	Eisenrankengürtel
22765	Schimmeliger Brief
22766	Pläne: Eisenrankenbrustplatte
22767	Pläne: Eisenrankenhandschuhe
22768	Pläne: Eisenrankengürtel
22769	Muster: Dornenholzgürtel
22770	Muster: Dornenholzstiefel
22771	Muster: Dornenholzhelm
22772	Muster: Sylvanschultern
22773	Muster: Sylvankrone
22774	Muster: Sylvanweste
22780	Weißes Murlocei
22781	Eisbärenhalsband
22798	Macht von Menethil
22799	Seelensucher
22800	Schwefelstab
22801	Spitze des Zwiespalts
22802	Königsmörder
22803	Mitternachtsnebel
22804	Maexxnas Fangzahn
22806	Reue der Witwe
22807	Gespensterklinge
22808	Der Bestrafer
22809	Keule des erlösten Kreuzzüglers
22810	Toxindüse
22811	Seelenstrang
22812	Nerubischer Sklavenjäger
22813	Claymore der unheiligen Kraft
22815	Wundspalter
22816	Knochenspalterbeil
22818	Der Seuchenbringer
22819	Schild der Geißelung
22820	Zauberstab der Heimsuchung
22821	Schicksalszeig
22822	iCoke Prize Voucher
22843	Kettenschienbeinschützer des Blutgardisten
22852	Drachenledertreter des Blutgardisten
22855	Schreckenszwirnlaufschuhe des Blutgardisten
22856	Lederlaufschuhe des Blutgardisten
22857	Panzerschienbeinschützer des Blutgardisten
22858	Plattenschienbeinschützer des Blutgardisten
22859	Satinlaufschuhe des Blutgardisten
22860	Seidenlaufschuhe des Blutgardisten
22862	Kettenklemmen des Blutgardisten
22863	Drachenlederhandschutz des Blutgardisten
22864	Lederhandschutz des Blutgardisten
22865	Schreckenszwirnhandlappen des Blutgardisten
22867	Panzerklemmen des Blutgardisten
22868	Plattenstulpen des Blutgardisten
22869	Satinhandlappen des Blutgardisten
22870	Seidenhandlappen des Blutgardisten
22872	Plattenhalsberge des Zornbringers
22873	Plattengamaschen des Zornbringers
22874	Kettenhalsberge des Zornbringers
22875	Kettenbeinschützer des Zornbringers
22876	Panzerhalsberge des Zornbringers
22877	Drachenlederbrustharnisch des Zornbringers
22878	Drachenledergamaschen des Zornbringers
22879	Lederbrustharnisch des Zornbringers
22880	Lederbeinschützer des Zornbringers
22881	Schreckenszwirnbeinschützer des Zornbringers
22882	Satinbeinschützer des Zornbringers
22883	Seidenbeinschützer des Zornbringers
22884	Schreckenszwirntunika des Zornbringers
22885	Satintunika des Zornbringers
22886	Seidentunika des Zornbringers
22887	Panzerbeinschützer des Zornbringers
22890	Foliant des Frostzauberschutzes V
22891	Zauberfoliant des Schattenzauberschutzes IV
22892	Dunkler nekrotischer Stein
22895	Herbeigezauberte Zimtschnecke
22897	Foliant des Essen-Herbeizauberns VII
22930	Blutbefleckter Umschlag
22932	Zerfledderter Brief
22935	Berührung des Frosts
22936	Handgelenksschutz der Rache
22937	Edelstein von Nerubis
22938	Seidenumhang der Gruftsatanskreatur
22939	Band der unerhörten Gebete
22940	Eisfluchschulterstücke
22941	Polarschulterpolster
22942	Umarmung der Witwe
22943	Heimtückischer Steinanhänger
22944	Zerknittertes Schreiben
22945	Verblichene Notiz
22946	Zerfranste Seite
22947	Anhänger der vergessenen Namen
22948	Verschmiertes Dokument
22949	Gesprungener nekrotischer Kristall
22950	Schwacher nekrotischer Kristall
22954	Kuss der Spinne
22960	Umhang der Wundnaht
22961	Band des neuen Lebens
22967	Eisschuppenschiftung
22968	Gletschermantel
22970	Blutbefleckter Umschlag
22972	Verblichene Notiz
22973	Zerknittertes Schreiben
22974	Zerfranste Seite
22975	Verschmiertes Dokument
22977	Zerfledderter Brief
22981	Gluths verschollenes Halsband
22983	Reifbedeckter Mantel
22988	Das Ende aller Träume
22994	Faulige Hand der Macht
22999	Wappenrock der Argentumdämmerung
23000	Gepanzerter Monstrositätenbrustkorb
23001	Auge des Schwunds
23002	Schildkrötenkiste
23004	Götze der Langlebigkeit
23005	Totem des Wasserlaufs
23006	Buchband des Lichts
23007	Schweinehalsband
23008	Versiegelter Untersuchungsbericht
23009	Zauberstab des flüsternden Todes
23010	Versiegelter Untersuchungsbericht
23011	Versiegelter Untersuchungsbericht
23012	Versiegelter Untersuchungsbericht
23013	Versiegelter Untersuchungsbericht
23014	Iblis, Klinge des gefallenen Engels
23015	Rattenkäfig
23016	Versiegelter Untersuchungsbericht
23017	Schleier der Finsternis
23018	Siegel des gefallenen Verteidigers
23019	Eisfluchhelm
23020	Polarhelm
23021	Bindungen des Seelenjägers
23022	Griesgrams Bestechungsgeld
23023	Sadistenhalsband
23024	Vorbereitete Felddienstpapiere
23025	Siegel der Verdammten
23027	Güte der Vergebung
23028	Hagelschauerband
23029	Noths kaltes Herz
23030	Umhang der Geißel
23031	Band des Unvermeidlichen
23032	Gletscherkopfputz
23033	Eisschuppenhelmkappe
23034	Nax PH Crit Plate Shoulders
23035	Hut des Mentors
23036	Halskette der Leichenschau
23037	Ring des Seeleneifers
23038	Band der unnatürlichen Kräfte
23039	Das Auge Nerubs
23040	Glyphe der Abwehr
23041	Wappen des Schlächters
23042	Loathebs Abglanz
23043	Das Gesicht des Todes
23044	Verdammnisbote
23045	Schleier der Herrschaft
23046	Die gebundene Essenz Saphirons
23047	Auge des Todes
23048	Saphirons rechtes Auge
23049	Saphirons linkes Auge
23050	Umhang der Nekropole
23053	Stormrages Talisman des Zorns
23054	Gressil, Vorbote des Untergangs
23055	Wort des Tauens
23056	Hammer des wirbelnden Nethers
23057	Edelstein der gefangenen Unschuld
23058	Halskette des Lebensstroms
23059	Ring des Schreckenspanzers
23060	Ring der Knochensense
23061	Ring des Glaubens
23062	Frostfeuerring
23063	Ring des verseuchten Herzens
23064	Ring des Traumwandlers
23065	Ring des Erdspalters
23066	Ring der Erlösung
23067	Ring des Gruftpirschers
23068	Beinplatten des Blutbads
23069	Gewand des Nekroritters
23070	Gamaschen des Widerspruchs
23071	Gamaschen der Apokalypse
23072	Fäuste des Unerbitterlichen
23073	Stiefel der Verrückung
23075	Todeshandel
23078	Stulpen des Untotenschlachtens
23081	Handlappen des Untotenschlachtens
23082	Handschützer des Untotenschlachtens
23083	Eingefangene Flamme
23084	Handschuhe der Untotenbekämpfung
23085	Robe der Untotenbekämpfung
23087	Brustplatte des Untotenschlachtens
23088	Brustschutz des Untotenschlachtens
23089	Tunika des Untotenschlachtens
23090	Armschienen des Untotenschlachtens
23091	Armschienen der Untotenbekämpfung
23092	Handgelenksschutz des Untotenschlachtens
23093	Gelenkbänder des Untotenschlachtens
23122	Geweihter Wetzstein
23123	Gesegnetes Zauberöl
23124	Stab von Balzaphon
23125	Fesseln des Lichs
23126	Gürtelbund von Balzaphon
23127	Revanchions Umhang
23128	Griff des Schattens
23129	Heilungsarmschienen
23132	Lord Blackwoods Klinge
23139	Lord Blackwoods Rundschild
23156	Blackwoods Oberschenkelknochen
23160	Freundschaftsbrot
23161	Frisch gepresste Limonade
23162	Ein sehr großer Beutel
23163	Performer's Wand
23164	Bubbly Beverage
23168	Fokusdolch des Verächters
23169	Eisiger Halsschmuck des Verächters
23170	Der eisige Griff
23171	Die Axt des Zerspaltens
23172	Refreshing Red Apple
23173	Gamaschen aus Monstrositätenhaut
23175	Tasty Summer Treat
23176	Fizzy Energy Drink
23177	Finger von Lady Falther'ess
23178	Mantel von Lady Falther'ess
23179	Flamme von Orgrimmar
23180	Flamme von Thunder Bluff
23181	Flamme von Undercity
23182	Flamme von Stormwind
23183	Flamme von Ironforge
23184	Flamme von Darnassus
23192	Wams des Scharlachroten Kreuzzugs
23193	Skelettrosszügel
23194	Kleines Mal der Dämmerung
23195	Mal der Dämmerung
23196	Großes Mal der Dämmerung
23197	Götze des Mondes
23198	Götze der Unmenschlichkeit
23199	Totem des Sturms
23200	Totem der Erhaltung
23201	Buchband der Offenbarung
23203	Buchband der Inbrunst
23206	Mal des Helden
23207	Mal des Helden
23211	Getoastetes Smorc
23215	Tasche mit Smorczutaten
23219	Gurt des Mentors
23220	Kristallgewebte Robe
23221	Verlegter Servoarm
23224	Summer Gift Package
23226	Ghulhauttunika
23227	iCoke Gift Box Voucher
23237	Ring der ewigen Flamme
23238	Stygischer Rundschild
23242	Klaue des Frostwyrms
23243	Plattenschultern des Feldherren
23244	Plattenhelm des Feldherren
23246	Feuriges Festgebräu
23247	Brandblüte
23250	Prismatische Muschel
23251	Kettenhelm des Feldherren
23252	Kettenschultern des Feldherren
23253	Drachenlederkopfschutz des Feldherren
23254	Drachenlederschultern des Feldherren
23255	Schreckenszwirnkutte des Feldherren
23256	Schreckenszwirnschiftung des Feldherren
23257	Lederhelm des Feldherren
23258	Lederschultern des Feldherren
23259	Panzerkopfschutz des Feldherren
23260	Panzerschulterstücke des Feldherren
23261	Satinkapuze des Feldherren
23262	Satinmantel des Feldherren
23263	Seidenkutte des Feldherren
23264	Seidenmantel des Feldherren
23272	Lamellenbrustplatte des Kürassiers
23273	Lamellengamaschen des Kürassiers
23274	Lamellenstulpen des Hauptmanns
23275	Lamellensabatons des Hauptmanns
23276	Lamellenkopfschutz des Feldkommandanten
23277	Lamellenschultern des Feldkommandanten
23278	Kettenschienbeinschützer des Hauptmanns
23279	Kettenklemmen des Hauptmanns
23280	Drachenlederhandschutz des Hauptmanns
23281	Drachenledertreter des Hauptmanns
23282	Schreckenszwirnhandlappen des Hauptmanns
23283	Schreckenszwirnlaufschuhe des Hauptmanns
23284	Lederhandschutz des Hauptmanns
23285	Lederlaufschuhe des Hauptmanns
23286	Plattenstulpen des Hauptmanns
23287	Plattenschienbeinschützer des Hauptmanns
23288	Satinhandlappen des Hauptmanns
23289	Satinlaufschuhe des Hauptmanns
23290	Seidenhandlappen des Hauptmanns
23291	Seidenlaufschuhe des Hauptmanns
23292	Kettentorso des Kürassiers
23293	Kettenbeinschützer des Kürassiers
23294	Drachenlederbrustharnisch des Kürassiers
23295	Drachenledergamaschen des Kürassiers
23296	Schreckenszwirnbeinschützer des Kürassiers
23297	Schreckenszwirntunika des Kürassiers
23298	Lederner Brustharnisch des Kürassiers
23299	Lederbeinschützer des Kürassiers
23300	Plattenhalsberge des Kürassiers
23301	Plattengamaschen des Kürassiers
23302	Satinbeinschützer des Kürassiers
23303	Satintunika des Kürassiers
23304	Seidenbeinschützer des Kürassiers
23305	Seidentunika des Kürassiers
23306	Kettenhelm des Feldkommandanten
23307	Kettenschultern des Feldkommandanten
23308	Drachenlederkopfschutz des Feldkommandanten
23309	Drachenlederschultern des Feldkommandanten
23310	Schreckenszwirnkutte des Feldkommandanten
23311	Schreckenszwirnschiftung des Feldkommandanten
23312	Lederhelm des Feldkommandanten
23313	Lederschultern des Feldkommandanten
23314	Plattenhelm des Feldkommandanten
23315	Plattenschultern des Feldkommandanten
23316	Satinkapuze des Feldkommandanten
23317	Satinmantel des Feldkommandanten
23318	Seidenkutte des Feldkommandanten
23319	Seidenmantel des Feldkommandanten
23320	Schrifttafel des Flammenschocks VI
23323	Krone des Feuerfests
23324	Mantel des Feuerfests
23326	Sonnenwendwürstchen
23327	Feuergeröstetes Brötchen
23360	Kopf von Instrukteur Razuvious
23379	Aschenarmschienen
23435	Holunderbeerenkuchen
23451	Magierklinge des Großmarschalls
23452	Machtfoliant des Großmarschalls
23453	Wiederherstellungsfoliant des Großmarschalls
23454	Kriegshammer des Großmarschalls
23455	Verwüster des Großmarschalls
23456	Schnellklinge des Großmarschalls
23464	Streitkolben des Obersten Kriegsfürsten
23465	Zerstörer des Obersten Kriegsfürsten
23466	Zauberklinge des Obersten Kriegsfürsten
23467	Schnellklinge des Obersten Kriegsfürsten
23468	Zerstörungsfoliant des Obersten Kriegsfürsten
23469	Heilungsfoliant des Obersten Kriegsfürsten
23545	Stärke der Geißel
23547	Unverwüstlichkeit der Geißel
23548	Macht der Geißel
23549	Standhaftigkeit der Geißel
23557	Larve des großen Wurms
23558	Panzer des Wühlers
23570	Jom Gabbar
23577	Die zehrende Kälte
23578	Aschebäschas Spezialrezept
23579	Aschebäschas Familienrezept
23663	Gurt des Elementarfurors
23664	Schulterstücke des Elementarfurors
23665	Gamaschen des Elementarfurors
23666	Gürtel des obersten Kreuzzüglers
23667	Schiftung des obersten Kreuzzüglers
23668	Gamaschen des obersten Kreuzzüglers
23683	Kristallflockendrops
23684	Kristalldurchdrungener Verband
23689	Handbuch: Kristalldurchdrungener Verband
23690	Rezept: Kristallflockendrops
23705	Wappenrock der Flamme
23709	Wappenrock des Frosts
23710	Wappenroch #3 von Upperdeck
23712	Weißes Tigerbaby
23713	Hippogryphenjunges
23714	Dauerhaftes lila Feuerwerk
23715	Ewiger Lungensaftcocktail
23716	Geschnitzter Ogergötze
23718	Ewige gemahlene Skorpokprobe
23719	Ewiger Zerebralkortexverbund
23720	Reitschildkröte
23721	Ewiges Muskelmagenkaugummi
23722	Ewige R.O.I.D.S.
23794	Zanzas ewiger Glanz
23795	Zanzas ewiger Geist
23796	Zanzas ewige Schnelligkeit
24071	Schmuckloser Dolch
24101	Buch des wilden Bisses V
24102	Handbuch des Ausweidens IX
24222	Dolch des schleichenden Todes
24231	Grober Schnupftabak
24232	Schäbiger Knoten
24281	Geschnitzter Elfenbeinknochen
24282	Tagebuch eines Schurken
24283	Altmodisches Gewehr
122270	WoW-Marke
122284	WoW-Marke
172070	Kundendienstpaket
180089	Pandahalsband
184937	Chronostärkungsversetzer
184938	Überladener Chronostärkungsversetzer
189419	Fire Resist Plate Gear
189420	Fire Resist Plate Gear
189421	Fire Resist Leather Gear
189426	Raid Consumables
189427	More Raid Consumables
190179	Avelinas Herz
190180	Isaacs Herz
190181	Herz der Liebenden
190186	Holzstatuette
190187	Abgetragener Schal
190232	Abgetragener Schal
190307	Nicht angezündete Fackel
190308	Brennende Fackel
190309	Holzstatuette
191204	Geringer Todesstein
191249	Großer Todesstein
191267	Rune der Teleportation: Vorkammer
191268	Kugel der Verderbnis
191272	Rute der Totenbeschwörung
191280	Pilzsporenansammlung
191288	Rune der Teleportation: Hort des Frostwyrms
191292	Ritualdolch
191312	Vorsorgephylakterium
191313	Maske des Todes
191414	Skelettartefakt
191458	Zerschmettertes Phylakterium
191459	Rune des Glücks
191477	Skelettanbindepfosten
191480	Skelettross
191481	Wappenrock der Meisterschaft
191550	Buch der Todessteine: Maske des Todes
191605	Buch der Todessteine: Rune der Teleportation I
191606	Buch der Todessteine: Kugel der Verderbnis
191607	Buch der Todessteine: Skelettartefakt
191608	Buch der Todessteine: Rute der Totenbeschwörung
191609	Buch der Todessteine: Pilzsporenansammlung
191610	Buch der Todessteine: Ritualdolch
191611	Buch der Todessteine: Vorsorgephylakterium
191612	Buch der Todessteine: Rune der Teleportation II
191613	Buch der Todessteine: Rune des Glücks
191614	Buch der Todessteine: Skelettanbindepfosten
191656	Essenz des Todes
191660	Thaddius' Blitzbolzen
191661	Monströser Spinnenfangzahn
191664	Buch der Todessteine: Thaddius' Blitzbolzen
191666	Buch der Todessteine: Monströser Spinnenfangzahn
202251	Tüte mit Leckerlis
202254	Armschienen der Umlenkung
202256	Verzierte Pistole des Freibeuters
202641	Schlammbedecktes Notizbuch.
203723	Schnittis Notiz
203726	Schnittis Rune
203745	Zaubernotizen: Eislanze
203746	Zaubernotizen: Lebende Flamme
203747	Zaubernotizen: Eisige Finger
203748	Zaubernotizen: Feuerfontäne
203749	Zaubernotizen: Erleuchtung
203750	Schatzkarte von Elwynn
203751	Zaubernotizen: NSZEIELA
203752	Zaubernotizen: DEELFANE LMEBM
203753	Zaubernotizen: ENEGSG IERIFI
203754	Erzmagier Antonidas: Die ungekürzte Autobiografie
203755	Forschungsaufzeichnungen von Erzmagier Theocritus
203756	Notizen eines Lehrlings aus Azora: Seite 1
203784	Rechtes oberes Kartenteil
203785	Linkes oberes Kartenteil
203786	Rechtes unteres Kartenteil
203787	Linkes unteres Kartenteil
203960	Notizen eines Lehrlings aus Azora: Seite 2
203961	Notizen eines Lehrlings aus Azora: Seite 3
203962	Notizen eines Lehrlings aus Azora: Seite 4
203990	Rune der Verstümmelung
203991	Rune des Pistolenhelden
203992	Rune der Täuschung
203993	Rune des Abschlachtens
203994	Rune der tödlichen Mischung
204174	Rune der Präzision
204270	Tiefenkern
204441	Rune der Blutraserei
204476	Abgetrennter Koboldkopf
204477	Abgetrennter Murlockopf
204478	Abgetrennter Gnollkopf
204688	Erstes Runenbruchstück des Monsterjägers
204689	Zweites Runenbruchstück des Monsterjägers
204690	Drittes Runenbruchstück des Monsterjägers
204703	Rune der Verwüstung
204716	Rune des rasenden Angriffs
204795	Rune des Schattenschlags
204804	Hydraxianische Reifen
204806	Rune des Siegesrauschs
204807	Tiefenklinge
204809	Rune des wütenden Donners
204864	Notizen eines Lehrlings aus Azora
204905	Ominöser Foliant
204906	Gnollblut
204907	Wolfskieferknochen
204912	Rune der Anmut
205019	Besudelter Seelensplitter
205020	Reiner Seelensplitter
205022	Rune des Seelenentzugs
205181	Nicht identifiziertes Artefakt
205182	Machtloses Artefakt
205183	Teufelsverstärktes Artefakt
205184	Notiz eines Akolythen
205215	Rune der Taktiken
205218	Buchband der Entdeckung
205228	Rune des Chaosblitzes
205230	Rune der Heimsuchung
205364	Knappsack des Akolythen
205420	Buchband des Richturteils
205683	Rune der Zurechtweisung
205685	Rune der Aegis
205863	Verderbter Buchband
205864	Verkohlte Notiz
205897	Rune des göttlichen Lichts
205905	Erinnerung an einen ergebenen Champion
205932	Prophezeiung des Tods eines Königs
205940	Erinnerung an einen dunklen Zweck
205942	Chimärische Offenbarung
205943	Prophezeiung einer entweihten Zitadelle
205944	Gegenseitige Offenbarung
205945	Erinnerung an einen eingekerkerten Retter
205946	Erinnerung an den Verrat eines Anführers
205947	Prophezeiung einer entweihten Zitadelle
205948	Wohltuende Offenbarung
205949	Vielfache Offenbarung
205950	Finstere Offenbarung
205951	Erinnerung an einen besorgten Akolythen
205952	Erinnerung an eine zerschmetterte Welt
205953	Prophezeiung eines gebrochenen Schwurs
205961	Vogelfleisch aus Mulgore
205979	Rune des Flankierens
205995	Präriehundmoschus
206032	Rune des Zerlegens
206155	Rune der Treffsicherheit
206157	Zephyriumbergbauladung
206159	Verkleidung der Venture Co.
206168	Rune der Chimäre
206169	Rune des Explosivschusses
206170	Windzornzapfen
206175	Piniensalbe
206176	Mörser und Stößel
206177	Pinienkernbutter
206264	Rune der Inspiration
206344	Messersatz
206345	Fischstücke
206376	Bollwerksymbol
206381	Dyadisches Symbol
206382	Orkansymbol
206383	Lithisches Symbol
206384	Astralsymbol
206385	Klastisches Symbol
206386	Galvanisches Symbol
206387	Kajarisches Symbol
206388	Schwefliges Symbol
206389	Schwefelsymbol
206390	Ichthyosymbol
206391	Syzygiensymbol
206466	Präriekrone
206469	Prärieblume
206954	Götze der Bärenwut
206963	Rune des Naturpotenzials
206966	Satyrkrautknolle
206970	Rune des Lebens
206975	Artefaktlagertruhenschlüssel
206985	Echo des Alphas
206989	Rune der Sonne
206992	Rune des Schädelstoßes
206994	Abgetrennter Stacheleberkopf
206995	Abgetrennter Harpyienkopf
207062	Abgetrennter Zentaurenkopf
207098	Notiz von Ba'so
207106	Linkes unteres Kartenteil
207107	Rechte unteres Kartenteil
207108	Linkes oberes Kartenteil
207109	Rechtes oberes Kartenteil
207110	Schatzkarte von Durotar
207590	Schweinefleisch aus Durotar
207631	Otterpheromone
207731	Ominöser Foliant
207732	Makrurabein
207733	Schädel eines Kul Tiraners
207972	Die Lehren von Ta'zo
207973	Hundekieferknochen
207974	Ominöser Foliant
207975	Abgetrennter Fledermauskopf
208005	Reliktkastenschlüssel von Agamand
208007	Schiffswracktruhenschlüssel
208034	Schatzkarte von Tirisfal
208035	Rechtes oberes Kartenteil
208036	Linkes oberes Kartenteil
208037	Rechte unteres Kartenteil
208038	Linkes unteres Kartenteil
208085	Signet des Scharlachroten Leutnants
208086	Gefälschtes scharlachrotes Memorandum
208139	Ominöser Foliant
208140	Wendigoblut
208158	Makelloses Troggherz
208159	Abgetrennter Trollkopf
208160	Abgetrennte Wendigopfote
208180	Kaninchenmoschus
208183	Apothekernotizen
208185	Metaphysische Fibel des Apothekers
208192	Schweinefleisch aus Dun Morogh
208196	Moa'kin-Band
208205	Schwarzrattes Notiz
208213	Rechtes oberes Kartenteil
208215	Linkes oberes Kartenteil
208218	Rechte unteres Kartenteil
208219	Linkes unteres Kartenteil
208220	Schatzkarte von Dun Morogh
208222	Vergelter der alten Wache
208223	Knappsack des Akolythen
208224	Notiz eines Akolythen
208414	Mondgötze
208425	Glänzende archaische Überreste
208484	Sonnenlicht
208601	Rechtes oberes Kartenteil
208602	Linkes oberes Kartenteil
208603	Rechte unteres Kartenteil
208604	Linkes unteres Kartenteil
208605	Schatzkarte von Teldrassil
208607	Rehmoschus
208608	Vogelfleisch von Teldrassil
208609	Lichtungsblume
208610	Abgetrennter Eulenkopf
208611	Abgetrennter Tigerkopf
208612	Abgetrennter Spinnenkopf
208682	Verlassenes Schnappkieferei
208687	Rune des Aufschlitzens
208689	Wilder Götze
208701	Rune des Meisters der Tiere
208739	Kriegsbanner der Horde
208741	Rune der endlosen Wut
208743	Seele der Gier
208744	Rune der Schattenblitze
208749	Kistenschlüssel der Knarzklauen
208750	Rune des Kanalisierens
208753	Zaubernotizen: Regeneration
208754	Zaubernotizen: TENGIRONEERA
208758	Irdene Rune
208760	Lichtungskrone
208764	Rune der Gedanken
208765	Helfende Hand
208766	Helfende Hand
208767	Rune der Besserung
208768	Streichholzkästchen des Bukaniers
208771	Rune des Klingentanzes
208772	Rune des Säbelschlitzers
208773	Fischfangharpune
208777	Rune des Scharfschützen
208778	Rune des rasanten Schlags
208799	Zaubernotizen: Lebende Bombe
208800	Baxtan: Über zerstörerische Magie
208823	Opfermünze
208828	Erinnerung an einen gebrochenen Schwur
208833	Böswilliger Kuchen
208838	Dunkeleisenschließkassette
208843	Kampftotem
208847	Schädelförmige Geode
208848	Aufgebrochene schädelförmige Geode
208849	Segensbuchband
208851	Gerechtigkeitsbuchband
208853	Zaubernotizen: Hirnfrost
208854	Zerkaute Zaubernotizen
208855	Köder aus Regenbogenflossenthunfisch
208860	Rumi von Gnomeregan: Die gesammelten Werke
209027	Krabbenleckerli
209028	Zaubernotizen: BEMBENE DELBO
209029	Nachricht von Emily
209030	Ausrüstungslagerschlüssel
209031	Diskreter Umschlag
209041	Magischer Kürbissamen
209042	Fischiges Knochenmehl
209043	Fruchtbare Erdprobe
209045	Seele der See
209047	Knorrige Harpune
209056	Schnitterersatzteile
209057	Prototypenmotor
209058	Elementarkern
209059	Geiferzahnkeule
209418	Adamantinschildkrötenrüstung
209420	Kiemenbann
209421	Kordel von Aquanis
209422	Hochwasserhalsreif
209423	Fließender Schal
209424	Panzerplattenbarriere
209432	Ghamoo-ras Hüftgurt
209436	Gesplitterter Biss von Serra'kis
209523	Schimmerndes Dreschercape
209524	Bindungen von Serra'kis
209525	Geschliffener Dunkelwassertalwar
209527	Nagakampfstulpen
209534	Azshariarmbrust
209559	Wanderstecken des Zwielichtpropheten
209560	Hammer des rechtschaffenen Richturteils
209561	Rute des uralten Schlafwandlers
209562	Todbringender Stoß der Hydra
209563	Nagaherzzerfetzer
209564	Wächterdreizack
209565	Band der tiefen Orte
209566	Gamaschen des Gläubigen
209567	Korallenriffaxt
209568	Algenstulpen
209569	Murlocbalgkniestiefel
209570	Foliant der Höhlenlehren
209571	Totenlicht
209572	Schwarzgekochtes Leder
209573	Zornige Spitze
209574	Weggeworfene Grundsätze der Silbernen Hand
209575	Ikone aus geschnitztem Treibholz
209576	Bewusstseinserweiternder Pilz
209577	Faust der Wildnis
209578	Leuchtende Lederbänder
209579	Grollender Donner
209580	Wütender Wind
209581	Sabatons der Silbernen Hand
209590	Gesprungene Wasserkugel
209608	Dietrich des Kapitäns
209611	Insigne der Allianz
209612	Insigne der Allianz
209613	Insigne der Allianz
209614	Insigne der Allianz
209615	Insigne der Allianz
209616	Insigne der Allianz
209617	Insigne der Allianz
209618	Insigne der Allianz
209619	Insigne der Horde
209620	Insigne der Horde
209621	Insigne der Horde
209622	Insigne der Horde
209623	Insigne der Horde
209624	Insigne der Horde
209625	Insigne der Horde
209626	Insigne der Horde
209667	Gazeträumergamaschen
209668	Siegel des Twilight-Lords
209669	Schuhe des Twilight-Herbeirufers
209670	Hautwandler
209671	Roben des Twilight-Herbeirufers
209672	Schwarze fingerlose Handschuhe
209673	Leuchtendes Fetischamulett
209674	Phönixzündung
209675	Tunika des Muschelwebens
209676	Schulterschutz der erdrückenden Tiefen
209677	Schleife der schnellen Strömung
209678	Mantelung des Drescherschlächters
209679	Schulterpolster des Azsharinovizen
209680	Wasserfester Schal
209681	Schwarzes Murlocei
209682	Robust Kapuze
209683	Schal des Twilight-Herbeirufers
209684	Seelenegelhose
209685	Uralter Moossattelgurt
209686	Gezackte Knochenhalskette
209687	Hydrabalgkürass
209688	Donnerbüchse aus Bael Modan
209689	Krabbenpanzerwatstiefel
209690	Schattenschuppenkappe
209691	Vampirisches Stiefelmesser
209692	Schildwachenschulterstücke
209693	Perfekte Perle der Tiefschwarzen Grotte
209694	Blackfathom-Ritualdolch
209748	Kugel von Althalaxx
209778	Beschwörersalz
209779	Partikel von Mannoroth
209800	Kugelfragmente
209816	Fetisch des Schabernacks
209817	Leerwandlerbrosche
209818	Sonnenberührte Sichel
209819	Zauberstab des Flügeldrachenzähmers
209820	Halsreif des schwarzen Schleiers
209821	Ring der Schattensicht
209822	Stärke der Absicht
209823	Signet der Bestien
209824	Schimmernde Schulterpolster
209825	Tropfenhalsreif
209828	Eingefrorene Schulterstücke
209830	Eisenhautarmbrust
209836	Kugel von Althalaxx
209838	Hypnotischer Kristall
209840	Knorriger Zauberstab der wilden Magie
209841	Wilde Magieessenz
209843	Almanach von Nar'thalas, Bd. 74
209844	Die Dalaranauswahl, Bd. 23
209845	Betörungen und Verzauberungen
209846	Geheimnisse der Träumer
209847	Handbuch arkanischer Systeme
209848	Goaz' Schriftrollen
209849	Verbrechen gegen die Anatomie
209850	Runen der Zaubererkönige
209851	Zorn des Landes
209852	Rune des Tötungsbefehls
209872	Helm des Drachentöters
209873	Schild des Drachentöters
209874	Lanze des Drachentöters
210015	Rune des wütenden Schlags
210026	Symbol der dritten Eule
210043	Symbol der zweiten Eule
210044	Symbol der ersten Eule
210045	Schattenblatt
210053	Terrorwolftatze
210055	Menschliche Knochen von Hillsbrad
210056	Tinktur des Wachtods
210080	Voodoo-Opfergabe
210137	Rune des Wildwuchses
210138	Verordnung der Dunkeleisenzwerge
210146	Schredderturbolader
210147	Automatische Bergungseinheit Schredder
210177	Ataeric: Arkane Merkwürdigkeiten
210178	Bauplan: Automatische Bergungseinheit Schredder
210179	Zaubernotizen: SCEAGHSLSVESO
210183	Horn von Xelthos
210186	Sprengladung
210187	Arbeitsauftrag der Venture Co.
210188	Zerfetzter Arbeitsauftrag
210195	Unausgewuchteter Götze
210209	Zwillingsschlüssel
210210	Gründerzertifikat von Grizzwerks Verteidigungsvertrieb
210212	Bruders Halbschlüssel
210213	Schwesters Halbschlüssel
210229	Rune der Verstümmelung
210250	Gravierter Goldring
210251	Gravierter Silberring
210252	Rune der Klinge
210253	Verfalltotem
210322	Rune des Toxins
210323	Tresorkombination
210329	Hillsbradschatzkarte
210330	Heißer Tipp
210410	Süßwasserschnapperköder
210499	Moorcheln
210500	Rune der Sterne
210534	Götze der Wildnis
210568	Schwächelndes Phylakterium
210569	Rune der Geißelung
210573	Rune der verzehrenden Wut
210589	Echo der Urahnen
210596	Rune der Kobrastöße
210653	Rune des Parierdolchs
210654	Zaubernotizen: Zeit zurückdrehen
210655	Zaubernotizen: ZÜDE RHENZUCKITER
210665	Partikel strömender Wut
210667	Partikel teuflischer Wut
210668	Partikel seismischer Wut
210696	Moderbann
210708	Elixier der verschmolzenen Reue
210709	Rezept: Elixier der verschmolzenen Reue
210712	Elixier der Einsicht
210713	Gequälte Seele
210724	Hirzeks Stab
210741	Automatischer Meuteverprügler
210746	Rune des Erdschilds
210763	Alteks Zweig
210765	Kugel von Des
210771	Abgefangene Vorräte: Kupferbarren
210772	Versorgungslieferung: Kupferbarren
210773	Mantel des Zweiten Krieges
210779	Pläne: Mantel des Zweiten Krieges
210781	Phönixbindungen
210794	Veränderliche silberne Brustplatte
210795	Extraplanare Spinnenseidenstiefel
210811	Rune des urzeitlichen Zorns
210817	Rune des Überlebens
210818	Rune des einsamen Wolfs
210820	Rune der Opferung
210822	Harmonische Offenbarung
210823	Rune der Beidhändigkeitsspezialisierung
210824	Rune des Pakts
210825	Rune des Kriegshetzers
210953	Auge von Bhossca
210955	Uniform eines scharlachroten Initianden
210963	Seherschlüssel
210966	Blut der Legion
210967	Vertrauliche Nachricht
210968	Reliquiarschlüssel
210979	Rune des Schattenschritts
210980	Rune der Metamorphose
211205	Rune des Kobraschlächters
211247	Muster: Phönixbindungen
211263	Brustschutz des Richturteils
211269	Einfache Zeichnung
211301	Rune der aufgedeckten Schwäche
211315	Abgefangene Vorräte: Leichtes Leder
211316	Abgefangene Vorräte: Friedensblumen
211317	Abgefangene Vorräte: Silberblatt
211318	Abgefangene Vorräte: Schwache Heiltränke
211319	Abgefangene Vorräte: Kupferkurzschwerter
211320	Abgefangene Vorräte: Runenverzierte Kupferhosen
211321	Abgefangene Vorräte: Geringe Magiezauberstäbe
211322	Abgefangene Vorräte: Schwaches Zauberöl
211323	Abgefangene Vorräte: Raue Kupferbomben
211324	Abgefangene Vorräte: Raue Schießeisen
211325	Abgefangene Vorräte: Handgenähte Ledergürtel
211326	Abgefangene Vorräte: Geprägte Lederweste
211327	Abgefangene Vorräte: Braune Leinenhosen
211328	Abgefangene Vorräte: Braune Leinenroben
211329	Abgefangene Vorräte: Kräutergebackene Eier
211330	Abgefangene Vorräte: Gewürztes Wolfsfleisch
211331	Abgefangene Vorräte: Glänzender Kleinfisch
211332	Abgefangene Vorräte: Schwerer Leinenverband
211365	Versorgungslieferung
211367	Versorgungslieferung
211368	Versorgungslieferung
211382	Kleiner Kurierbeutel
211384	Robuste Kuriertasche
211385	Rune der Schlangenspur
211386	Zaubernotizen: Arkane Woge
211387	Rune des lockenden Lichts
211390	Rune des Reizens
211391	Rune des heilenden Regens
211392	Rune der immerwährenden Gebrechen
211393	Rune des zielstrebigen Furors
211419	Handvoll veränderlicher Schuppen
211420	Veränderlicher Schuppentalisman
211421	Die Kiste
211422	Splitter der Leere
211423	Leerenberührte Lederhandschuhe
211427	Seelengefäß
211443	Klinge des Zorns
211444	Beschwörerumhang
211445	Barbarischer Doppelbogen
211447	Waffenlieferung
211448	Unterschriebener Beschaffungsvertrag
211449	Leerenperle des Rächers
211450	Leerenperle des Herbeirufers
211451	Leerenperle des Akolythen
211452	Perfekte Blackfathom-Perle
211454	Seltsame Wasserkugel
211455	Glatte fingerlose Handschuhe
211456	Dolch des willigen Opfers
211457	Gurt des Zwielichtbeschützers
211458	Foliant des Schattenzauberschutzes
211460	Uralter arktischer Rundschild
211461	Graviertes Grabsteinszepter
211462	Ewig erhaltender Ring
211463	Zirpende Käferschnallen
211464	Abgenutztes Prälaturencape
211465	Nimbusstiefel der Einsicht
211466	Herzholzgurt des Pflegers
211467	Band der Eisenfaust
211468	Zerfetzter kastanienbrauner Mantel
211471	Cliffspring-Schlüssel
211472	Buchband der Verbannung
211476	Rune des Feuersees
211477	Rune des Verbrennens
211482	Opfergabe der Shatterspear
211487	Sprengladungen
211488	Rune des Rächers
211490	Prophezeiung der tausend Lichter
211491	Bodenlose Tasche aus Murlochaut
211492	Kelris' Beutel
211498	Nachtsäbler des Schildwachenrekruten
211499	Vorhutwolf des Rekruten
211500	Zähes Stirnband
211501	Brustschutz der Macht
211502	Leerenberührte Lederstulpen
211504	Kettenpanzer des Twilight-Rächers
211505	Helm des Twilight-Rächers
211506	Stiefel des Twilight-Rächers
211507	Gugel des Twilight-Elementaristen
211508	Fußpolster des Twilight-Elementaristen
211509	Robe des Twilight-Elementaristen
211510	Gugel des Twilight-Schlächters
211511	Fußpolster des Twilight-Schlächters
211512	Tunika des Twilight-Schlächters
211514	Zaubernotizen: Massenregeneration
211527	Gemütlicher Schlafsack
211528	Dunkle Einsicht
211530	Prophezeiung der ergriffenen Stadt
211531	Prophezeiung der sieben Besucher
211534	Ursprüngliche Eingebung
211691	Zaubernotizen: Arkanschlag
211777	Nagamanuskript
211779	Verständnisamulett
211780	Schriftrolle: KWYJIBO
211784	Schriftrolle: WUBBA WUBBA
211785	Schriftrolle: CWAL
211786	Schriftrolle: CHAP BALK WELLES
211787	Schriftrolle: UNTERPING SONSTWEM
211789	Artemisgugel
211799	Sack voller gestohlener Waren
211800	Schriftrolle der Reintegration
211809	Verständnisfibel
211813	Amulett der Schildwache der Silverwing
211814	Abzeichen der Warsongvorhut
211815	Schlachthymne der Silverwing
211816	Warsongkampftrommel
211818	Seltsame Wasserkugel
211819	Abgefangene Vorräte: Bronzebarren
211820	Abgefangene Vorräte: Silberbarren
211821	Abgefangene Vorräte: Mittleres Leder
211822	Abgefangene Vorräte: Beulengras
211823	Abgefangene Vorräte: Flitzdistel
211824	Abgefangene Vorräte: Geringe Manatränke
211825	Abgefangene Vorräte: Raue bronzene Stiefel
211826	Abgefangene Vorräte: Silberdietriche
211827	Abgefangene Vorräte: Runenverzierte Silberruten
211828	Abgefangene Vorräte: Schwaches Manaöl
211829	Abgefangene Vorräte: Kleine Bronzebomben
211830	Abgefangene Vorräte: Verschnörkelte Handfernrohre
211831	Abgefangene Vorräte: Dunkle Lederumhänge
211832	Abgefangene Vorräte: Schultern des Hügelwächters
211833	Abgefangene Vorräte: Graue Wollhemden
211834	Abgefangene Vorräte: Perlenschnallenumhänge
211835	Abgefangene Vorräte: Geräucherter Weisenfisch
211836	Abgefangene Vorräte: Geräuchertes Bärenfleisch
211837	Abgefangene Vorräte: Scharfe Muscheln nach Goblinart
211838	Abgefangene Vorräte: Schwere Wollverbände
211839	Versorgungslieferung
211840	Versorgungslieferung
211841	Versorgungslieferung
211842	Rakkamars zerfledderte Denkkappe
211843	Maske der Verachtung
211845	Blackfathom-Wetzstein
211846	Pläne: Blackfathom-Wetzstein
211848	Blackfathom-Manaöl
211849	Formel: Blackfathom-Manaöl
211852	Handlappen des besudelten Wassers
211853	Schriftrolle: VOCE WELL
211854	Schriftrolle: OMIT KESA
211855	Schriftrolle: STHENIC LUNATE
211856	Zähe Kettenhaube
211857	Zähe Ledermaske
211933	Abgefangene Vorräte: Rauer Stein
211934	Abgefangene Vorräte: Heiltränke
211935	Abgefangene Vorräte: Elixier der Feuermacht
211940	Ecks'avs Stammeswächter
211941	Yari des Windläufers
211944	Tojaras Karma
211953	Schriftrolle der arkanen Erholung I
211954	Schriftrolle der arkanen Präzision I
211955	Schriftrolle des Arkanschutzes - Feuer I
211956	Schriftrolle des Arkanschutzes - Frost I
211957	Schriftrolle der arkanen Macht I
212160	Chronostärkungsversetzer
212225	Endloses Seelengefäß
212230	Bauplan: Seelengefäß
212548	Rune der Finsternis
212549	Rune des Fallenstellers
212551	Rune der Kriegskunst
212552	Psychosophische Offenbarung
212559	Rune der vergifteten Klinge
212560	Rune des Erwachens der Ahnen
212561	Rune der brennenden Dunkelheit
212562	Rune des heilenden Zorns
212568	Wolfskopftrophäe
212580	Stab des Wissenshüters
212581	Bogen des Kundschafters
212582	Schwert des Beschützers
212583	Klinge der Schildwache
212584	Knorriger Stab des Beraters
212585	Bogen der Vorhut
212586	Schwert des Legionärs
212587	Klinge des Spähers
212588	Handschuhe des Versorgers
212589	Treter des Kuriers
212590	Tragegurt
212748	Zerfledderte Notiz
212994	Bindungen des Sturmjägers
212996	Bindungen des Blitzrufers
212997	Bindungen des Gezeitenrufers
213074	Rune der Pflege
213086	Rune des Stroms
213087	Umhang des Waffenträgers
213088	Umhang des Waffenträgers
213090	Rune der Synergie
213093	Rune der Kraft
213094	Rune der Feuernova
213096	Rune der Täuschung
213098	Rune der Anrufung
213100	Rune des verbotenen Wissens
213101	Rune der Schattenflammen
213102	Rune der Tücke
213103	Rune der Blutwoge
213104	Rune der unbarmherzigen Präzision
213105	Schawarmageddon
213109	Rune der fokussierten Wut
213110	Rune des Kommandanten
213111	Rune des Einschreitens
213112	Zaubernotizen: Geschosssalve
213117	Rune des Berserkers
213118	Rune des Königs des Dschungels
213119	Rune des Instinkts
213120	Rune des Träumers
213121	Konservierter Tannenzweig
213122	Rune des zuverlässigen Schusses
213123	Rune des Aufdeckens
213124	Rune des Nahkampfs
213125	Rune der Kräftigung
213126	Rune des Streiters
213127	Zaubernotizen: BLAUBERZORFSTITZ
213128	Rune der Frömmigkeit
213129	Rune der Umarmung des Lichts
213130	Rune der Infusion
213131	Rune des geheiligten Schildes
213132	Rune des Behüters
213136	Rune des hinterhältigen Angriffs
213137	Rune des Auflauernden
213138	Rune des Rechtsauslegers
213139	Rune des Assassinen
213140	Prophezeiung des beschleunigten Pfads
213141	Rune der Hoffnung
213142	Prophezeiung der gefangenen Bösartigkeit
213143	Apokryphische Offenbarung
213144	Leuchtende Offenbarung
213165	Basilisken: Muss man Angst vor der Versteinerung haben?
213168	Kupferblutmünze
213169	Silberblutmünze
213170	Goldblutmünze
213278	Handschützer des Pömpfmeisters
213279	Reflektierende Schädelkappe
213280	Schützensuchervisier
213281	Elektromagnetischer Hyperflux-Reaktivator
213282	Hochaufgeladene Ausrüstung der Innovation
213283	Hochaufgeladene Ausrüstung der Feuersbrunst
213284	Hochaufgeladene Ausrüstung der Verwüstung
213285	Levs ölverschmierte Bindungen
213286	Elektrokutor-Nadel
213287	Elektrokutor-Sechskantmutter
213288	Grubbis schmierige Stulpen
213289	Hydrostab
213290	Säurewatstiefel
213291	Toxinvergelter II
213292	Gizmotronisches Gigahackbeil
213293	Hightech-Superschusswaffe V7
213294	Sabatons der Tiefentroggs
213295	Ultraschallvibroklinge
213296	Überladener Kopffäller
213297	Oszillierender Sprenghammer
213298	Overall des Robobauers
213299	Petroleumpfützenhose
213300	Kämpferasshandschuhe
213301	Synthetischer Mantel
213302	Mantel des raffinierten Verhandlers
213303	Blitzableiterschiftung
213304	Troggtöterschulterstücke
213305	Schulterplatten aus bearbeiteter Legierung
213306	Bedeckung des Einfallsreichtums
213307	Tuch des Zerlegens
213308	Fallschirmumhang-Prototyp
213309	Umhang des Erfindungsreichtums
213310	Hyperleitendes Schimmerhemd
213311	Hyperleitende Robe
213312	Isolierte Schürze
213313	Isolierter Brustschutz
213314	Elektromantischer Kettenpanzer
213315	Elektromantisches Kettenhemd
213316	Schutzbrustplatte
213317	Experimentelle Zielstabilisatoren
213318	Verzierte Dunkeleisenreifen
213319	Maschinistenhandschuhe
213320	Fingerhandschuhe der arkanen Präzision
213321	Gürtel der hochentzündlichen Mischung
213322	Gürtelbund der Betrügereien
213323	Kordel der tiefen Erde
213324	Elektromagnetischer Hüftgürtel
213325	Nachtsichtgurt
213326	Gurt der Wiedergewinnung
213327	Gürtel des Trogg-Berserkers
213328	Hyperleitende Pantalons
213329	Hyperleitender Rock
213330	Schutzbeinplatten
213331	Isolierte Gamaschen
213332	Isolierte Beinschützer
213333	Elektromantische Beinlinge
213334	Elektromantischer Gambeson
213335	Schutzstiefel
213336	Hyperleitende Laufschuhe
213337	Hyperleitende Sandalen
213338	Elektromantische Erdungsstiefel
213339	Elektromantische Erdungssabatons
213340	Gnombot-Bedienerstiefel
213341	Isolierte Arbeitsstiefel
213342	Isolierte Galoschen
213343	Justizabzeichen
213344	Halsreif des Gesetzeshüters von Gnomeregan
213345	Kolbenanhänger
213346	Anhänger der Heimkehr
213347	Mini-Einäscherungskammer
213348	Gyromatisches Experiment 420b
213349	Gniodin-Pillenfläschchen
213350	Wirdals gehärteter Kern
213351	Bestrahlter Turmschild
213352	Gunst des Getriebemechanikers
213353	Defibrilationsstab
213354	Stab des bösen Genies
213355	Falcos Stachel
213356	Thermapluggs maßgefertigter Blaster
213369	Schwach leuchtendes Leder
213370	Bestrahlte Lederfetzen
213371	Kiste mit besudelter Gniodin-Lösung
213372	Isolierendes Gniodin
213373	Reflektierender Metallschrott
213376	Echtsilberplatten mit geringer Grundstrahlung
213378	Instabiler Mikrofaden
213379	Hyperleitender Arkanfaden
213381	Haufen aus stumpfen Zahnrädern
213383	Polierte Echtsilberzahnräder
213390	Wirbelnder Echtsilberzahnradschild
213391	UNBENUTZTE elektrifizierte Mithrilstulpen
213407	Katzenminze
213408	Gyromatischer Makroregler
213409	Mekkatorques Arkanoschredder
213410	Gleißende Dingsdaklinge
213411	Izzleflicks unlöschbarer Anzünder
213412	Dielektrischer Sicherheitsschild
213413	Großzügig gefütterte Schulterpolster
213414	Schärpe des Mechheilers
213415	Handgelenkwickel des Tüftlers
213416	Thermapluggs Raketenspaltbeil
213417	Echtsilberfadenkappe
213418	Geschweißte Echtsilberlocken
213421	Angesengte Notiz
213426	Ogerblitzschlagrute
213427	Schmutzverkrustetes Bergungsgut
213442	Klaue des Zahnradmeisters
213443	Tickendes Geschenk
213452	Inaktive heilige Rune
213513	Buchband der Erlösung
213526	Hybride Keule
213527	Gewürzmischung des Schmugglers
213528	Mildes Gebräu
213529	Viskoses Gift
213542	Das Nekro-Gnomikon
213543	Schriftrolle: UPDOG
213544	Schriftrolle: TOPAZ YORAK
213545	Schriftrolle: ZAEHLEZ STARKDEUTIEN
213546	Schriftrolle: SCHUBIDU
213547	Schriftrolle: WELCH SCHWESTER
213548	Schriftrolle des Schwellenübergangs
213549	Schriftrolle des arkanen Angelns
213550	Schriftrolle der Verwandlung: Seltsame Melone
213551	Schriftrolle der kontrollierten Verzerrung
213552	Träne von Theradras
213553	Träne von Theradras
213554	Phiole mit Kristallwasser
213558	Elementarsalbe
213559	Roboschreiterkuppler
213560	Roboschreiterdämpfer
213563	Leitfaden
213564	Schriftrolle der geringeren Hervorrufung
213565	Einsteigerpaket für Entomologen
213583	Schwefelschnitzerei
213594	Götze der Zwischenrufe
213599	Beunruhigende Vision
213632	Unvollständige Zaubernotizen
213633	Unvollständige Zaubernotizen
213634	Unvollständige Zaubernotizen
213641	Kiste mit Bergungsgut aus Gnomeregan
213701	Kräftige Harpyienfeder
213709	Wolkenschlangenreißzahn
213735	Makelloser G-7-K.E.R.N.-Prozessor
213736	Korrodierter G-7-K.E.R.N.-Prozessor
213737	Opfergabe für den Windgeist
214435	Schlüssel zum Pumakäfig
215111	Gneuro-verkettetes Arkanfaden-Monokel
215114	Leuchtende hyperleitende Schuppenkappe
215115	Hyperleitendes Goldnetz
215129	Formel: Waffe - Zerlegen
215138	Formel: Brust - Vergelter
215141	Verzaubertes Siegel: Innovation
215149	Muster: Gneuro-verkettetes Arkanfaden-Monokel
215152	Muster: Leuchtende Gneuro-verkettete Gugel
215153	Bauplan: Wirbelnder Echtsilberzahnradschild
215155	Pläne: Gehärteter Interferenzen-negierender Helm
215156	Bauplan: Hyperleitendes Goldnetz
215162	Leicht bestrahlter Verjüngungstrank
215163	Rezept: Leicht bestrahlter Verjüngungstrank
215166	Leuchtende Gneuro-verkettete Gugel
215257	Schriftrolle des Verständnis
215365	Mantel des Herbeirufers
215366	Kordel des Herbeirufers
215367	Muster: Schwach leuchtendes Leder
215368	Muster: Hyperleitender Arkanfaden
215369	Muster: Kordel des Herbeirufers
215370	Muster: Mantel des Herbeirufers
215371	Janis Amulett
215373	Übungshammer der Silbernen Hand
215374	Schwert der Ahnen
215375	Stab es Taktikers
215376	Streitkolben des Kreuzfahrers
215377	Bestrahlte Robe
215378	Bestrahlte Stiefel
215379	Bestrahlte Beinkleider
215380	Servo-unterstützter Hebegürtel
215381	Gneuro-leitende Kapuze des Kanalisierers
215382	Strahlungsresistente Schuppenkapuze
215383	Pläne: Reflektierender Echtsilbergehirnkäfig
215384	Pläne: Echtsilberplatten mit geringer Grundstrahlung
215385	Abgefangene Vorräte: Goldbarren
215386	Abgefangene Vorräte: Mithrilbarren
215387	Abgefangene Vorräte: Schwere Bälge
215388	Abgefangene Vorräte: Dickes Leder
215389	Abgefangene Vorräte: Blassblatt
215390	Abgefangene Vorräte: Khadgars Schnurrbart
215391	Abgefangene Vorräte: Winterbiss
215392	Abgefangene Vorräte: Lila Lotus
215393	Abgefangene Vorräte: Große Heiltränke
215394	Abgefangene Vorräte: Geringe Steinschildtränke
215395	Abgefangene Vorräte: Elixiere der Beweglichkeit
215396	Abgefangene Vorräte: Elixiere der großen Verteidigung
215397	Abgefangene Vorräte: Massive Eisenäxte
215398	Abgefangene Vorräte: Grüne Eisenarmschienen
215399	Abgefangene Vorräte: Schwere Mithrilstulpen
215400	Abgefangene Vorräte: Robuste Schleifsteine
215401	Abgefangene Vorräte: Kompakte Ernteschnittersets
215402	Abgefangene Vorräte: Große Eisenbomben
215403	Abgefangene Vorräte: Tödliche Zielfernrohre
215404	Abgefangene Vorräte: Mithrildonnerbüchsen
215405	Abgefangene Vorräte: Gnomenraketenstiefel
215406	Abgefangene Vorräte: Goblinmörser
215407	Abgefangene Vorräte: Barbarische Schultern
215408	Abgefangene Vorräte: Wächterhandschuhe
215409	Abgefangene Vorräte: Schildkrötenschuppenarmschienen
215410	Abgefangene Vorräte: Schwärzliche Gürtel
215411	Abgefangene Vorräte: Frostlederumhänge
215412	Abgefangene Vorräte: Schattenhauthandschuhe
215413	Abgefangene Vorräte: Formelle weiße Hemden
215414	Abgefangene Vorräte: Purpurrote Seidenpantalons
215415	Abgefangene Vorräte: Dunkellila Seidenhemden
215416	Abgefangene Vorräte: Weiße Banditenmasken
215417	Abgefangene Vorräte: Milde Schildkrötensuppe
215418	Abgefangene Vorräte: Spinnenwürste
215419	Abgefangene Vorräte: Schwere Seidenverbände
215420	Abgefangene Vorräte: Steinschuppenkabeljau
215421	Abgefangene Vorräte: Feueröl
215422	Muster: Leuchtende hyperleitende Schuppenkappe
215423	Muster: Gneuro-leitende Kapuze des Kanalisierers
215424	Muster: Strahlungsresistente Schuppenkapuze
215425	Echo des Sumpfes
215426	Echo des Friedhofs
215427	Echo von Arathi
215428	Echo von Theramore
215429	Bauplan: Polierte Echtsilberzahnräder
215430	Ablagerung von Gnomeregan
215431	Bauplan: Hoch wirksame Strahlungsbombe
215432	Bauplan: EZ-Thro-Strahlungsbombe
215433	Rezept: Isolierendes Gniodin
215434	UNBENUTZT
215435	Buchband der Segnung
215436	Totem der kräftigenden Flamme
215437	Troggwandler 3000
215441	Kaputter Hammer
215443	Zerschmettertes Kugelfragment
215449	Weltschrumpfer
215450	Wappenrockprojekt (Aidan)
215456	Angesengte Nachricht
215458	Beigefügte Nachricht
215459	Beigefügte Nachricht
215460	Beigefügte Nachricht
215461	Gezähmtes Angriffshuhn
215468	Befehle des Obersten Kreuzzüglers
215683	Geomantie: Der steinige Weg zur Wahrheit
215815	Das Einmaleins der Verteidigungsmagie
215816	Ein Netz aus Lügen: Die Entzauberung von Mythen und Legenden
215817	Dämonen und Ihr
215820	Mumien: Ein Ratgeber zu unappetitlichen Untoten
215822	RwlRwlRwlRwl!
215824	Anleitung zur Pflege eines dämonischen Begleiters für Anfänger
216484	Schockgeschmiedete Kampfstiefel
216485	Schockgeschmiedete Brustplatte
216486	Schockgeschmiedete Beinplatten
216490	Götze des Zorns
216491	Lieferung Schlingendornholz
216492	Pfeife des scheckigen Blutraptors
216494	Aragriars launenhafter Weltenkrümmer
216495	Blutknacker
216496	Blutschädelknacker
216497	Exsanguinar
216498	Zauberfoliant des verzauberten Blutes
216499	Blutrindenknacker
216500	Blutgebundener Haintalisman
216501	Blutsturmbarriere
216502	Blutsturmkriegstotem
216503	Blutsturmjuwel
216504	Verfinstertes Blutlichtschwert
216505	Strahlen des Blutlichtkreuzfahrers
216506	Klinge des Blutlichträchers
216507	Umbralblutsiegel
216508	Höllisches Blutwickelband
216509	Höllenpaktessenz
216510	Blutresonanzring
216511	Funkenblutsiegel
216512	Band der kalten Venen
216513	Tigerbluttalisman
216514	Blutköcher
216515	Blutmunitionsbeutel
216516	Blutstrangbogen
216517	Blutrefugium
216518	Blutpaktsiegel
216519	Blutschattenband
216520	Klinge der Bluternte
216521	Flinke Blutschläger
216522	Blutbeschmiertes Stilett
216523	Rostiger Käfigschlüssel
216570	Zügel der goldenen Säblerkatze
216606	Rune der Zweihandmeisterschaft
216607	Blutlichtopfergabe
216608	Strahlende Strahlenreflektoren
216610	Befehle des obersten Kreuzzüglers
216615	Leuchtfeuer des Blutsturms der Ahnen
216616	Lagerkäfigschlüssel
216617	Kurzens Kämpferuniform
216618	Kapitänin Aransas' Belohnung
216619	Studentenfutter
216620	Blutfäulnisumhang
216621	Blutdurchnässtes Tuch
216622	Geronnener Umhang
216623	Cape der Hämostase
216633	Hydraulische Echtsilberstrebe
216634	GG12-082-Sicherungseinsatz
216635	Erschöpfter Leerenkern
216636	Aufgeladener Leerenkern
216637	Ein Haufen gemischter Teile
216645	Partikel der Dunkelheit
216646	Ziris Überraschungskiste
216661	Schmutzverkrusteter Ring
216662	Blitzender Goldring
216673	Talvashs blitzender Goldring
216674	Noggs blitzender Goldring
216675	Makellose Civinad-Roben
216676	Behände Latzhose des Stolperläufers
216678	Dreifach verstärkte Gamaschen
216679	Shonis Zerlegungswerkzeug
216680	Fäustlinge der Entschlossenheit
216698	Drachenlederarmsplinte des Fähnrichs
216699	Kettenarmschützer des Fähnrichs
216700	Lederarmsplinte des Fähnrichs
216701	Plattenhandgelenksschützer des Fähnrichs
216702	Seidenmanschetten des Fähnrichs
216703	Panzerhandgelenksschützer des Rottenmeisters
216704	Drachenlederarmschützer des Rottenmeisters
216705	Plattenarmschienen des Rottenmeisters
216706	Lederarmschützer des Rottenmeisters
216707	Seidenmanschetten des Rottenmeisters
216738	Handbuch des Umleitens
216740	Foliant der erweiterten Intelligenz
216744	Schriftrolle der erhöhten Seelenstärke
216745	Schriftrolle des Schattengeistes
216746	Handbuch des Befehlsrufs
216747	Zauberfoliant der Seelenernte
216748	Zauberfoliant des Portals der Beschwörung
216764	Handzettel der tiefen Wildnis
216767	Handzettel der Wiederbelebung
216768	Bekenntnis der verbesserten Segen
216769	Offenbarung der totemischen Projektion
216770	Abhandlung zum Aspekt der Viper
216771	Handzettel der verbesserten Wiederherstellung
216879	Mysteriöse Trollschriftrolle
216880	Entzifferte Trollschriftrolle
216884	Blutdurstklinge
216914	Befleckte Belobigung
216918	Teufelsherzstiefel
216919	Teufelsherzschärpe
216920	Teufelsherzbindungen
216921	Teufelsherzhandschutz
216922	Teufelsherzkrone
216923	Teufelsherzgamaschen
216924	Teufelsherzumarmung
216925	Teufelsherzmantel
216938	Großes Insigne der Allianz
216939	Großes Insigne der Horde
216941	Aridens Siegel
216945	Eigentümliches Relikt aus Dalaran
216946	Funkelndes Relikt aus Dalaran
216947	Surrendes Relikt aus Dalaran
216948	Merkwürdiges Relikt aus Dalaran
216949	Schweres Relikt aus Dalaran
216950	Gruseliges Relikt aus Dalaran
216951	Glitschiges Relikt aus Dalaran
216956	Zerrissener Brief
216971	Säckchen mit Kupferblutmünzen
216972	Säckchen mit Silberblutmünzen
217005	Schlossercape
217006	Mechanikerrohrhammer
217007	Energieentleerte Stiefel
217008	Energieentleertes Brustteil
217009	Energieentleerte Beinkleider
217014	Vorratstasche
217017	Angelwettbewerb!
217161	Zaubernotizen: TORFFRISTZBEULE
217244	Muster: Purpurrote Seidenrobe
217245	Purpurrote Seidenrobe
217246	Schwarze Magiestoffweste
217247	Schwarze Magiestoffgamaschen
217248	Irdener Seidengürtel
217249	Muster: Irdener Seidengürtel
217250	Purpurrote Seidenschultern
217251	Muster: Purpurrote Seidenschultern
217252	Langer Seidenumhang
217253	Stiefel des Verzauberers
217254	Muster: Stiefel des Verzauberers
217255	Purpurroter Seidengürtel
217256	Irdene Weste
217257	Verzauberergugel
217258	Muster: Verzauberergugel
217259	Große Voodoomaske
217260	Muster: Große Voodoomaske
217261	Große Voodoorobe
217262	Muster: Große Voodoorobe
217263	Wächterlederarmschienen
217264	Muster: Wächterlederarmschienen
217265	Wächtergürtel
217266	Muster: Wächtergürtel
217267	Wächterhose
217268	Schildkrötenschuppenbrustplatte
217270	Schildkrötenschuppenhandschuhe
217271	Muster: Schildkrötenschuppenhandschuhe
217273	Goldene Schuppenstulpen
217274	Pläne: Goldene Schuppenstulpen
217275	Goldene Schuppenstiefel
217276	Pläne: Goldene Schuppenstiefel
217277	Goldener Schuppenkürass
217278	Pläne: Goldener Schuppenkürass
217279	Goldene Schuppenhelmkappe
217280	Pläne: Goldene Schuppenhelmkappe
217281	Mondstahlbreitschwert
217282	Pläne: Mondstahlbreitschwert
217283	Goldene Schuppenschultern
217284	Pläne: Goldene Schuppenschultern
217285	Goldene Schuppengamaschen
217286	Pläne: Goldene Schuppengamaschen
217287	Großer Mystikerzauberstab
217288	Roben des Lich
217289	Rüstung des Todesfröstelns
217290	Glühendes Auge von Mordresh
217291	Mordreshs lebloser Schädel
217292	Todesmagierschärpe
217293	Seidenes Spinnencape
217294	Einbalsamiertes Tuch
217295	Nekrotischer Zauberstab
217296	Geistsplittertalisman
217297	Robe von Doan
217298	Mantel von Doan
217299	Illusionäre Rute
217300	Weißsträhnes Kappe
217301	Triunen-Amulett
217302	Mograines Macht
217303	Gamaschen des Steinwebers
217304	Reveloshs Handschuhe
217305	Reveloshs Armschützer
217306	Reveloshs Stiefel
217307	Reveloshs Schiftung
217308	Verzaubertes Siegel: Innovation
217314	Mondsichtgewehr
217315	Präzisionsbogen
217337	Versorgungslieferung
217338	Versorgungslieferung
217339	Versorgungslieferung
217345	Zähes Gift
217346	Betäubendes Gift
217347	Atrophisches Gift
217350	Thermapluggs Ingenieursnotizen
217351	Thermapluggs Ingenieursnotizen
217398	Geringes Arkanelixier
217399	Rezept: Geringes Arkanelixier
217495	Schriftrolle des Kryoschlags
217496	Schriftrolle der Klinge
217497	Narpasschwert
217609	Talisman von Kazdor
217693	Unsichtbarkeitstrank
217704	Eisenbeschlagener Knüttel
217717	Leeres Emblem
217718	Emblem der Blutmagie
217719	Blutmagieessenz
217720	Opfergabe des Fleisches
217721	Opfergabe der Knochen
217727	Schutz der Toten
217736	Rune des Zirkels
217737	Angepasster Talisman
219021	Große Kuriertasche
219022	Ring des Trägers
219023	Ring des Amtmanns
219024	Ring des Boten
219135	Anhänger der Neugier
219136	Anhänger der Hartnäckigkeit
219137	Anhänger der Initiative
219147	Rune der Anmut
219223	Zorn des Klingenmeisters
219326	Saat der Erneuerung
219343	Diebesgugel
219345	Höllenlasso
219399	Alptraummoos
219401	Kalteisenerz
219402	Traumberührte Drachenschuppe
219404	Schattensichel
219405	Ogermagiertext
219406	Ungeschlüpftes grünes Drachenei
219414	Zerbrochene Eierschalen
219444	Traumwurzel
219445	Katzengoldstaub
219446	Traumerfüllte Drachenschuppe
219447	Traumberührtes Drachenei
219448	Traummotor
219449	Azsharische Prophezeiung
219454	Sternenlotus
219486	Sternensilbererz
219487	Sternenmuschel
219488	Sternenberührtes Drachenei
219490	Elunarisches Relikt
219491	Traumperle
219514	Mondwurzel
219515	Großer Mondstein
219517	Monddrachenschuppe
219518	Harpyienschrift
219519	Notizen des wahnsinnigen Bewahrers
219520	Mondscheindrachenei
219526	Einsatzanweisung: Dämmerwald
219759	Charlas Feldbericht
219770	Gemerons Feldbericht
219771	Thandros' Feldbericht
219772	Fallias Feldbericht
219773	Einsatzanweisung: Ashenvale
219774	Einsatzanweisung: Hinterland
219775	Einsatzanweisung: Feralas
219776	Geheimdienstbericht: Ogerhort Vul'Gol
219778	Geheimdienstbericht: Verlassener Obstgarten
219803	Geheimdienstbericht: Yorgens Bauernhof
219918	Blutiges Schreiben
219924	Geheimdienstbericht: Forest Song
219925	Geheimdienstbericht: Satyrnaar
219926	Geheimdienstbericht: Holzfällerlager der Warsong
219927	Smaragdsplitter
219928	Geheimdienstbericht: Agol'watha
219929	Blutiges Schreiben
219930	Blutiges Schreiben
219935	Kajinds Klinge
219937	Geheimdienstbericht: Shaol'watha
219938	Geheimdienstbericht: Skulk Rock
219957	Geheimdienstbericht: Oneiros
219958	Geheimdienstbericht: Zwillingskolosse
219959	Geheimdienstbericht: Ruinen von Rabenwind
219962	Alptraumeinfälle: Dämmerwaldmission I
219963	Ernennungsbefugnis: Dämmerwaldmission I
219965	Ernennungsbefugnis: Dämmerwaldmission II
219966	Alptraumeinfälle: Dämmerwaldmission II
219967	Alptraumeinfälle: Dämmerwaldmission III
219968	Alptraumeinfälle: Dämmerwaldmission IV
219969	Alptraumeinfälle: Dämmerwaldmission V
219970	Alptraumeinfälle: Dämmerwaldmission VI
219971	Alptraumeinfälle: Dämmerwaldmission VII
219972	Alptraumeinfälle: Dämmerwaldmission VIII
219973	Alptraumeinfälle: Dämmerwaldmission IX
219974	Alptraumeinfälle: Dämmerwaldmission X
219975	Alptraumeinfälle: Dämmerwaldmission XI
219976	Alptraumeinfälle: Dämmerwaldmission XII
219977	Alptraumeinfälle: Dämmerwaldmission XIII
219978	Alptraumeinfälle: Dämmerwaldmission XIV
219979	Alptraumeinfälle: Dämmerwaldmission XV
219980	Alptraumeinfälle: Dämmerwaldmission XVI
219981	Alptraumeinfälle: Dämmerwaldmission XVII
219982	Alptraumeinfälle: Dämmerwaldmission XVIII
219983	Ernennungsbefugnis: Dämmerwaldmission III
219984	Ernennungsbefugnis: Dämmerwaldmission IV
219985	Ernennungsbefugnis: Dämmerwaldmission V
219986	Ernennungsbefugnis: Dämmerwaldmission VI
219987	Ernennungsbefugnis: Dämmerwaldmission VII
219988	Ernennungsbefugnis: Dämmerwaldmission VIII
219989	Ernennungsbefugnis: Dämmerwaldmission IX
219990	Ernennungsbefugnis: Dämmerwaldmission X
219991	Ernennungsbefugnis: Dämmerwaldmission XI
219992	Ernennungsbefugnis: Dämmerwaldmission XII
219993	Ernennungsbefugnis: Dämmerwaldmission XIII
219994	Ernennungsbefugnis: Dämmerwaldmission XIV
219995	Ernennungsbefugnis: Dämmerwaldmission XV
219996	Ernennungsbefugnis: Dämmerwaldmission XVI
219997	Ernennungsbefugnis: Dämmerwaldmission XVII
219998	Ernennungsbefugnis: Dämmerwaldmission XVIII
219999	Alptraumeinfälle: Ashenvale-Mission I
220000	Alptraumeinfälle: Ashenvale-Mission II
220001	Alptraumeinfälle: Ashenvale-Mission III
220002	Alptraumeinfälle: Ashenvale-Mission IV
220003	Alptraumeinfälle: Ashenvale-Mission V
220004	Alptraumeinfälle: Ashenvale-Mission VI
220005	Alptraumeinfälle: Ashenvale-Mission VII
220006	Alptraumeinfälle: Ashenvale-Mission VIII
220007	Alptraumeinfälle: Ashenvale-Mission IX
220008	Alptraumeinfälle: Ashenvale-Mission X
220009	Alptraumeinfälle: Ashenvale-Mission XI
220010	Alptraumeinfälle: Ashenvale-Mission XII
220011	Alptraumeinfälle: Ashenvale-Mission XIII
220012	Alptraumeinfälle: Ashenvale-Mission XIV
220013	Alptraumeinfälle: Ashenvale-Mission XV
220014	Alptraumeinfälle: Ashenvale-Mission XVI
220015	Alptraumeinfälle: Ashenvale-Mission XVII
220016	Alptraumeinfälle: Ashenvale-Mission XVIII
220017	Alptraumeinfälle: Hinterlandmission I
220018	Alptraumeinfälle: Hinterlandmission II
220019	Alptraumeinfälle: Hinterlandmission III
220020	Alptraumeinfälle: Hinterlandmission IV
220021	Alptraumeinfälle: Hinterlandmission V
220022	Alptraumeinfälle: Hinterlandmission VI
220023	Alptraumeinfälle: Hinterlandmission VII
220024	Alptraumeinfälle: Hinterlandmission VIII
220025	Alptraumeinfälle: Hinterlandmission IX
220026	Alptraumeinfälle: Hinterlandmission X
220027	Alptraumeinfälle: Hinterlandmission XI
220028	Alptraumeinfälle: Hinterlandmission XII
220029	Alptraumeinfälle: Hinterlandmission XIII
220030	Alptraumeinfälle: Hinterlandmission XIV
220031	Alptraumeinfälle: Hinterlandmission XV
220032	Alptraumeinfälle: Hinterlandmission XVI
220033	Alptraumeinfälle: Hinterlandmission XVII
220034	Alptraumeinfälle: Hinterlandmission XVIII
220035	Alptraumeinfälle: Feralasmission I
220036	Alptraumeinfälle: Feralasmission II
220037	Alptraumeinfälle: Feralasmission III
220038	Alptraumeinfälle: Feralasmission IV
220039	Alptraumeinfälle: Feralasmission V
220040	Alptraumeinfälle: Feralasmission VI
220041	Alptraumeinfälle: Feralasmission VII
220042	Alptraumeinfälle: Feralasmission VIII
220043	Alptraumeinfälle: Feralasmission IX
220044	Alptraumeinfälle: Feralasmission X
220045	Alptraumeinfälle: Feralasmission XI
220046	Alptraumeinfälle: Feralasmission XII
220047	Alptraumeinfälle: Feralasmission XIII
220048	Alptraumeinfälle: Feralasmission XIV
220049	Alptraumeinfälle: Feralasmission XV
220050	Alptraumeinfälle: Feralasmission XVI
220051	Alptraumeinfälle: Feralasmission XVII
220052	Alptraumeinfälle: Feralasmission XVIII
220053	Ernennungsbefugnis: Ashenvale-Mission I
220054	Ernennungsbefugnis: Ashenvale-Mission II
220055	Ernennungsbefugnis: Ashenvale-Mission III
220056	Ernennungsbefugnis: Ashenvale-Mission IV
220057	Ernennungsbefugnis: Ashenvale-Mission V
220058	Ernennungsbefugnis: Ashenvale-Mission VI
220059	Ernennungsbefugnis: Ashenvale-Mission VII
220060	Ernennungsbefugnis: Ashenvale-Mission VIII
220061	Ernennungsbefugnis: Ashenvale-Mission IX
220062	Ernennungsbefugnis: Ashenvale-Mission X
220063	Ernennungsbefugnis: Ashenvale-Mission XI
220064	Ernennungsbefugnis: Ashenvale-Mission XII
220065	Ernennungsbefugnis: Ashenvale-Mission XIII
220066	Ernennungsbefugnis: Ashenvale-Mission XIV
220067	Ernennungsbefugnis: Ashenvale-Mission XV
220068	Ernennungsbefugnis: Ashenvale-Mission XVI
220069	Ernennungsbefugnis: Ashenvale-Mission XVII
220070	Ernennungsbefugnis: Ashenvale-Mission XVIII
220071	Ernennungsbefugnis: Hinterlandmission I
220072	Ernennungsbefugnis: Hinterlandmission II
220073	Ernennungsbefugnis: Hinterlandmission III
220074	Ernennungsbefugnis: Hinterlandmission IV
220075	Ernennungsbefugnis: Hinterlandmission V
220076	Ernennungsbefugnis: Hinterlandmission VI
220077	Ernennungsbefugnis: Hinterlandmission VII
220078	Ernennungsbefugnis: Hinterlandmission VIII
220079	Ernennungsbefugnis: Hinterlandmission IX
220080	Ernennungsbefugnis: Hinterlandmission X
220081	Ernennungsbefugnis: Hinterlandmission XI
220082	Ernennungsbefugnis: Hinterlandmission XII
220083	Ernennungsbefugnis: Hinterlandmission XIII
220084	Ernennungsbefugnis: Hinterlandmission XIV
220085	Ernennungsbefugnis: Hinterlandmission XV
220086	Ernennungsbefugnis: Hinterlandmission XVI
220087	Ernennungsbefugnis: Hinterlandmission XVII
220088	Ernennungsbefugnis: Hinterlandmission XVIII
220089	Ernennungsbefugnis: Feralasmission I
220090	Ernennungsbefugnis: Feralasmission II
220091	Ernennungsbefugnis: Feralasmission III
220092	Ernennungsbefugnis: Feralasmission IV
220093	Ernennungsbefugnis: Feralasmission V
220094	Ernennungsbefugnis: Feralasmission VI
220095	Ernennungsbefugnis: Feralasmission VII
220096	Ernennungsbefugnis: Feralasmission VIII
220097	Ernennungsbefugnis: Feralasmission IX
220098	Ernennungsbefugnis: Feralasmission X
220099	Ernennungsbefugnis: Feralasmission XI
220100	Ernennungsbefugnis: Feralasmission XII
220101	Ernennungsbefugnis: Feralasmission XIII
220102	Ernennungsbefugnis: Feralasmission XIV
220103	Ernennungsbefugnis: Feralasmission XV
220104	Ernennungsbefugnis: Feralasmission XVI
220105	Ernennungsbefugnis: Feralasmission XVII
220106	Ernennungsbefugnis: Feralasmission XVIII
220164	Rune des Gladiators
220165	Rune des Zorns
220166	Feuriger Höllenbestienkern
220167	Schimmernder Grabstaub
220168	Dreifach gebrautes Schmelzlagerbier
220169	Symbol des Glaubens
220173	Parasomnie
220213	Teuflisches Lebensblut
220214	Höllischer Kettenverbund
220216	Höllenlasso
220217	Rune des Gefräßigen
220345	Blutige Zauberei
220346	Legenden der Gezeitenweisen
220347	Die Schwelle und das Arkane
220348	Alltägliche Etikette
220349	Steinwerkentwürfe
220350	Giftige Reisen
220351	Düsteres Luftsapta
220352	Möglichkeiten des Metalls
220353	Beschwörerkodex
220360	Rune des Erblühens
220375	Fragment der Luft
220379	Zerrissene Notizen des Schamanen
220446	Überirdischer Schatz
220510	Elementaressenz
220511	Großhelm des Alptraums
220512	Makelloser Goldstahlhelm
220514	Visier der tiefgrünen Federn
220515	Verzauberter Smaragdhelm
220516	Schlitzers vergessenes Visier
220518	Ba'hams verstaubter Hut
220519	Voodoogefiederter Kopfputz
220521	Ritualistenkopfputz der Hakkari
220522	Seelenfängerkrone
220523	Antlitz des Exilierten
220525	Leuchtendes Fragment der Luft
220526	Schlickbedeckter G-7-K.E.R.N.-Prozessor
220527	Berserkermantel der Atal'ai
220528	Jägerschulterstücke der Atal'ai
220529	Schiftung des Fanatismus
220530	Wille des Kriegers der Atal'ai
220531	Wogende violette Blume
220532	Neugeschmiedete atal'aiische Schiftung
220533	Neugeschmiedete atal'aiische Brustplatte
220534	Ewige Umarmung der Windnatter
220535	Prophetentracht der Atal'ai
220536	Medizinmannhandschutz der Atal'ai
220537	Dunkelwasserarmschienen des Träumers
220538	Verfluchte Schleimschuppenarmschienen
220539	Kriegsbänder der Aufopferung
220540	Verderbnisbeladene Handschützer
220541	Seuchengeplagte Plattenfäuste
220542	Verschmutzte Dumpfwasserstulpen
220543	Smaragdschuppenpanzerhandschuhe
220544	Blutfackelkrallen
220545	Handschuhe des übelriechenden Kämpfers
220546	Handschuhe des Gequälten
220547	Handschuhe des gefallenen Propheten der Atal'ai
220548	Verhexerhandschuhe der Atal'ai
220549	Gurt der Morgenröte
220550	Taillenbund des Tempelplünderers
220551	Anbeterschärpe des Smaragdgrünen Traums
220552	Taillenschutz des Schmerzes
220553	Gürtel des vergessenen Anbeters
220554	Atal'alarions Hauerband
220555	Schlangenschuppengürtel der Atal'ai
220556	Kilt des gefallenen Propheten der Atal'ai
220557	Verfluchter Windschuppensarong
220558	Assassinengamaschen der Atal'ai
220559	Revitalisierte Drachenschuppengamaschen
220560	Silberschalenbeinplatten
220561	Hartnäckige Trollkicker
220562	Blutunterlaufene Kampfschienbeinschützer
220563	Blutschamanenstiefel der Atal'ai
220564	Wiederhergestellte Schlängelschuppenstiefel
220565	Stiefel des astralen Nebelläufers
220566	Glimmerklaue
220567	Blutiger Kopfstachel
220568	Gewehraxt des Tempelforschers
220569	Brandheißer Wuthammer
220570	Mantel der Alpträume
220571	Stechlangbogen
220572	Rinzos rapide Repetierarmbrust
220573	Schreckenspirscherjagdbogen
220574	Geschärfter Zahn des Eranikus
220575	Fresser der Verdammten
220576	Henkeraxt der Atal'ai
220577	Macht des Blutloas
220578	Fäuste der Verlassenen
220579	Mojostock des Hexendoktors
220580	Wahnsinn des Avatars
220581	Schlangenklopfer
220582	Drachenschrei
220583	Widerwärtige Klinge des Elenden
220584	Flammenatemklinge
220585	Zersetzer Terrornagel
220586	Hybris, der Banditenbränder
220587	Opfertraumdolch
220588	Kobragiftzahnklaue
220589	Schlangenschläger
220590	Spitze der Hakkarianbetung
220591	Mijans Regenerationsrute
220594	Sense des Traums
220595	Alptraumfokusstab
220596	Uralte Wünschelrute
220597	Drachenstein des Traumvorboten
220598	Drachenstein des Alptraumvorboten
220599	Drachenstein des Blutpropheten
220600	Wappen der Überlegenheit
220601	Schutz des Hakkarihexendoktors
220602	Kanalisationskrötenhalbschale
220603	Rute der irreversiblen Korrosion
220604	Alptraumtrophäe
220605	Buchband des Sakrilegs
220606	Götze des Traums
220607	Totem der gequälten Ahnen
220608	Federhauttuch
220609	Tuch der Dämmerung
220610	Rune der geistigen Gewandtheit
220611	Hukkus Hexerumhang
220612	Rune der Flutwellen
220613	Rune des rollenden Donners
220614	Rune des statischen Schocks
220615	Pantherfellumhang
220616	Rune der Überladung
220617	Rune der Pandemie
220618	Rune der Feuerbrandaura
220619	Blutzeremonie der Atal'ai
220620	Schädel der Windnatter
220621	Alptraumresonanzkristall
220622	Perfekt erhaltenes Drachenauge
220623	Jin'dos verlorenes Medaillon
220624	Blutverschmiertes Amulett der Ehre
220625	Abhärtung des Exilierten
220626	Drachenklauenband des Berserkers
220627	Drachenklauenband des Pirschers
220628	Drachenklauenband des Vorboten
220629	Drachenklauenband des Blutpropheten
220630	Drachenklauenband des Molochs
220632	Blutritualmedaillon der Atal'ai
220633	Blutritualabzeichen der Atal'ai
220634	Blutritualamulett der Atal'ai
220635	Atal'alarions verzauberter Fels
220636	Blutsymbol der Atal'ai
220637	Ritualzeichen der Atal'ai
220638	Unorthodoxer Hexerstecken
220639	Lledras Lebloser
220642	Plattenrüstung des verbannten Märtyrers
220643	Plattenbeinschützer des verbannten Märtyrers
220648	Plattenstiefel des verbannten Märtyrers
220649	Merithras Erbe
220650	Brustplatte des besessenen Propheten
220651	Beinschützer des besessenen Propheten
220652	Verschnörkelte Stiefel des besessenen Propheten
220653	Brustplatte des klagenden Berserkers
220654	Beinplatten des klagenden Berserkers
220656	Kampfstiefel des klagenden Berserkers
220657	Halsberge des geächteten Berserkers
220658	Beinplatten des geächteten Berserkers
220659	Kettenschienbeinschützer des geächteten Berserkers
220660	Kettenhemd des gemiedenen Verehrers
220661	Beinschützer des gemiedenen Verehrers
220662	Schuppenstiefel des gemiedenen Verehrers
220663	Gamaschen des verderbten Geisterwebers
220664	Sabatons des verderbten Geisterwebers
220665	Brustplatte des verderbten Geisterwebers
220666	Kettenpanzer des Schreckenjägers
220667	Beinlinge des Schreckenjägers
220668	Schienbeinschützer des Schreckenjägers
220669	Wams des verbannten Propheten
220670	Pantoffeln des verbannten Propheten
220671	Lederhose des verbannten Propheten
220672	Harnisch des verlorenen Anbeters
220673	Gamaschen des verlorenen Anbeters
220674	Minderwertige Klinge der Verstohlenheit
220675	Treter des verlorenen Anbeters
220676	Blutverderbte Tunika
220677	Blutverderbte Stiefel
220678	Blutverderbte Hose
220679	Gamaschen des böswilligen Propheten
220680	Weste des böswilligen Propheten
220681	Sandalen des böswilligen Propheten
220682	Rune des Ungebändigten
220683	Weste des wohlwollenden Propheten
220684	Gamaschen des wohlwollenden Propheten
220685	Sandalen des wohlwollenden Propheten
220686	Häuptlingsbann
220687	Rune des Raptors
220688	Träger Mantel der Alpträume
220689	Leerenaufgeladene Unterarmschienen
220738	Schulterplatten des Schreckens
220739	Elendige Schulterstücke
220740	Schulterschützer des Furchtschürers
220741	Schreiende Kettenschulterstücke
220742	Kreischende Schiftung
220743	Kakofonische Kettenschulterschützer
220744	Wehklagender Kettenmantel
220745	Membran der dunklen Neurose
220747	Paranoiamantel
220748	Schulterpolster der Besessenheit
220749	Mantel des Wahnsinns
220750	Schulterstücke des zerrütteten Geists
220751	Schulterpolster der Verwirrten
220754	Rune der Windhose
220775	Gutscheintausch für Ingenieure
220778	Geronnene Hose des Blutgardisten
220779	Geronnene Tunika des Blutgardisten
220780	Geronnene Stiefel des Blutgardisten
220781	Gamaschen des Alptraumpropheten
220783	Gewänder des Alptraumpropheten
220784	Sandalen des Alptraumpropheten
220791	Rune der Dschungelkatze
220792	Schriftrolle der räumlichen Heilung
220794	Plattenhalsberge des Leutnants
220795	Plattenschulterstücke des Hauptmanns
220796	Plattenschulterstücke des Blutgardisten
220797	Plattengamaschen des Leutnants
220798	Plattengamaschen des Steingardisten
220799	Plattenschienbeinschützer des Fähnrichs
220800	Plattenschienbeinschützer des Rottenmeisters
220801	Plattenrüstung des Steingardisten
220803	Plattenhelm des Blutgardisten
220804	Plattenhelm des Hauptmanns
220806	Plattenstulpen des Fähnrichs
220807	Plattenstulpen des Rottenmeisters
220808	Verzauberte Schulterstücke des Hauptmanns
220809	Verzauberte Gamaschen des Leutnants
220810	Verzauberter Helm des Hauptmanns
220811	Magieerfüllte Schienbeinschützer des Fähnrichs
220812	Magieerfüllte Stulpen des Fähnrichs
220813	Magieerfüllte Rüstung des Leutnants
220814	Lamellenstiefel des Fähnrichs
220815	Lamellenbrustplatte des Leutnants
220816	Lamellenbeinplatten des Leutnants
220817	Lamellenstulpen des Fähnrichs
220818	Lamellenschulterstücke des Hauptmanns
220819	Lamellenhelm des Hauptmanns
220820	Panzerhelm des Blutgardisten
220821	Kettenhelm des Blutgardisten
220822	Kettenhelm des Hauptmanns
220823	Panzerschulterklappen des Blutgardisten
220824	Kettenschulterklappen des Blutgardisten
220825	Kettenschulterklappen des Hauptmanns
220826	Panzerrüstung des Steingardisten
220827	Kettenrüstung des Steingardisten
220828	Kettenrüstung des Leutnants
220829	Kettenstulpen des Fähnrichs
220830	Kettenstulpen des Rottenmeisters
220831	Panzerstulpen des Rottenmeisters
220832	Kettenbeinplatten des Leutnants
220833	Kettenbeinplatten des Steingardisten
220834	Panzerbeinplatten des Steingardisten
220835	Panzersabatons des Rottenmeisters
220836	Kettensabatons des Rottenmeisters
220837	Kettensabatons des Fähnrichs
220838	Gravierter Brustharnisch des Steingardisten
220839	Gravierte Beinplatten des Steingardisten
220840	Gravierte Sabatons des Rottenmeisters
220841	Gravierte Schulterpolster des Blutgardisten
220842	Gravierte Schädelkappe des Blutgardisten
220843	Gravierte Stulpen des Rottenmeisters
220844	Pulsierende Brustplatte des Steingardisten
220845	Pulsierende Stulpen des Rottenmeisters
220846	Pulsierende Schienbeinschützer des Rottenmeisters
220847	Pulsierende Beinplatten des Steingardisten
220848	Pulsierender Helm des Blutgardisten
220849	Pulsierende Schultern des Blutgardisten
220850	Lederstirnband des Hauptmanns
220851	Lederstirnband des Blutgardisten
220852	Lederschultern des Hauptmanns
220853	Lederschultern des Blutgardisten
220854	Lederrüstung des Leutnants
220855	Lederrüstung des Steingardisten
220856	Lederstulpen des Fähnrichs
220857	Lederstulpen des Rottenmeisters
220858	Lederhose des Leutnants
220859	Lederhose des Steingardisten
220860	Lederstiefel des Fähnrichs
220861	Lederstiefel des Rottenmeisters
220862	Knisternde Lederstiefel des Fähnrichs
220863	Knisternde Lederstiefel des Rottenmeisters
220864	Knisternde Ledergamaschen des Leutnants
220865	Knisternde Ledergamaschen des Steingardisten
220866	Knisternde Lederstulpen des Fähnrichs
220867	Knisternde Lederstulpen des Rottenmeisters
220868	Knisternde Ledertunika des Leutnants
220869	Knisternde Ledertunika des Steingardisten
220870	Knisternde Lederschiftung des Hauptmanns
220871	Knisternde Lederschiftung des Blutgardisten
220872	Knisternder Lederhelm des Hauptmanns
220873	Knisternder Lederhelm des Blutgardisten
220874	Wiederhergestellter Lederhelm des Hauptmanns
220875	Wiederhergestellter Lederhelm des Blutgardisten
220876	Wiederhergestellte Lederschiftung des Hauptmanns
220877	Wiederhergestellte Lederschiftung des Blutgardisten
220878	Wiederhergestellter Lederwams des Leutnants
220879	Wiederhergestellter Lederwams des Steingardisten
220880	Wiederhergestellte Lederhandschuhe des Fähnrichs
220881	Wiederhergestellte Lederhandschuhe des Rottenmeisters
220882	Wiederhergestellte Ledergamaschen des Leutnants
220883	Wiederhergestellte Ledergamaschen des Steingardisten
220884	Wiederhergestellte Lederstiefel des Fähnrichs
220885	Wiederhergestellte Lederstiefel des Rottenmeisters
220886	Schreckenszwirnweste des Leutnants
220887	Schreckenszwirnmantel des Hauptmanns
220888	Schreckenszwirngamaschen des Leutnants
220889	Schreckenszwirnhut des Hauptmanns
220890	Schreckenszwirnhandschuhe des Fähnrichs
220891	Schreckenszwirnstiefel des Fähnrichs
220892	Satinrüstung des Leutnants
220893	Satingamaschen des Leutnants
220894	Satinpolster des Hauptmanns
220895	Satinstiefel des Fähnrichs
220896	Satinbedeckung des Hauptmanns
220897	Satinhandschuhe des Fähnrichs
220898	Satinhandschuhe des Rottenmeisters
220899	Satinbedeckung des Blutgardisten
220900	Satinstiefel des Rottenmeisters
220901	Satinpolster des Blutgardisten
220902	Satingamaschen des Steingardisten
220903	Satinrüstung des Steingardisten
220904	Schreckenszwirnweste des Steingardisten
220905	Schreckenszwirnmantel des Blutgardisten
220906	Schreckenszwirngamaschen des Steingardisten
220907	Schreckenszwirnhut des Blutgardisten
220908	Schreckenszwirnhandschuhe des Rottenmeisters
220909	Schreckenszwirnstiefel des Rottenmeisters
220912	Geodenhammer
220913	Rune der Sprengung
220914	Kaputter Geodenhammer
220915	Götze des erzürnten Schlurfers
220916	Horn eines Donnerstampferstegodons
220917	Kiste mit scharlachrotem Farbstoff
220918	Muschelsuppe Undermine-Muschelsuppe
220919	Abgefangene Vorräte: Nachtflossensuppe
220920	Abgefangene Vorräte: Zarte Wolfsteaks
220921	Abgefangene Vorräte: Schwere Magiestoffverbände
220922	Abgefangene Vorräte: Sonnengras
220923	Abgefangene Vorräte: Traumblatt
220924	Abgefangene Vorräte: Echtsilberbarren
220925	Abgefangene Vorräte: Thoriumbarren
220926	Abgefangene Vorräte: Unverwüstliches Leder
220927	Abgefangene Vorräte: Dicke Bälge
220928	Abgefangene Vorräte: Verzauberte Thoriumbarren
220929	Abgefangene Vorräte: Überragende Manatränke
220930	Abgefangene Vorräte: Erhebliche Heiltränke
220931	Abgefangene Vorräte: Hochexplosive Bomben
220932	Abgefangene Vorräte: Thoriumgranaten
220933	Abgefangene Vorräte: Thoriumgewehre
220934	Abgefangene Vorräte: Mithrilhelmkappen
220935	Abgefangene Vorräte: Thoriumgürtel
220936	Abgefangene Vorräte: Echtsilberstulpen
220937	Abgefangene Vorräte: Unverwüstliche Rüstungssets
220938	Abgefangene Vorräte: Tückische Lederarmschienen
220939	Abgefangene Vorräte: Runenverzierte Lederarmschienen
220940	Abgefangene Vorräte: Schwarze Magiestoffstirnbänder
220941	Abgefangene Vorräte: Runenstoffgürtel
220942	Abgefangene Vorräte: Smokinghemden
220964	Entladene leerenaufgeladene Unterarmschienen
220965	Bannschuppengroßaxt
221008	Versorgungslieferung
221009	Versorgungslieferung
221010	Versorgungslieferung
221017	Keldaras Aufzeichnungen
221018	Feldsanitäterset
221019	Satyrkrautprobe
221020	Rune der Mondgöttin
221021	Alptraumsaat
221024	Fläschchen der unvergänglichen Alpträume
221025	Leerenaufgeladene Unterarmschienen des Herbeirufers
221026	Leerenaufgeladene Unterarmschienen des Rächers
221027	Leerenaufgeladene Unterarmschienen des Beschützers
221028	Verzaubertes Siegel: Lebendige Träume
221030	Atal'aimojo der verbotenen Magie
221191	Traumstein
221192	Traumtagebuch
221193	Smaragdring
221196	Atal'aimojo des Krieges
221199	Satyrkrauttinktur
221256	Rechter Arm des Vernichters
221257	Linker Arm des Vernichters
221258	Rechter Fuß des Vernichters
221259	Linker Fuß des Vernichters
221260	Kopf des Vernichters
221261	Wildgeflüstergebräu
221262	Wilde Opfergabe
221267	Rune des Blutdurstigen
221271	Wildnis-Ass
221272	Wildniskartenset
221273	Wildnis-Zwei
221274	Wildnis-Drei
221275	Wildnis-Vier
221276	Wildnis-Fünf
221277	Wildnis-Sechs
221278	Wildnis-Sieben
221279	Wildnis-Acht
221280	Seuchenkartenset
221281	Seuchen-Ass
221282	Seuchen-Zwei
221283	Seuchen-Drei
221284	Seuchen-Vier
221285	Seuchen-Fünf
221286	Seuchen-Sechs
221287	Seuchen-Sieben
221288	Seuchen-Acht
221289	Dünenkartenset
221290	Dünen-Ass
221291	Dünen-Zwei
221292	Dünen-Drei
221293	Dünen-Vier
221294	Dünen-Fünf
221295	Dünen-Sechs
221296	Dünen-Sieben
221297	Dünen-Acht
221298	Alptraum-Ass
221299	Alptraumkartenset
221300	Alptraum-Zwei
221301	Alptraum-Drei
221302	Alptraum-Vier
221303	Alptraum-Fünf
221304	Alptraum-Sechs
221305	Alptraum-Sieben
221306	Alptraum-Acht
221307	Dunkelmond-Karte: Verfall
221308	Dunkelmond-Karte: Wildes Wachstum
221309	Dunkelmond-Karte: Sandsturm
221310	Dunkelmond-Karte: Qual
221311	Atal'aimojo des Lebens
221312	Fläschchen mit Atal'aimojo
221313	Fläschchen des alptraumhaften Mojo
221314	Steckbrief
221315	Regenbogengenerator
221316	Premos haltungswahrende Uniform
221317	Feralas-Leykristall
221318	Azshara-Leykristall
221319	Blackrock-Leykristall
221320	Hinterland-Leykristall
221321	Atal'aisiegel der Macht
221322	Atal'aisiegel des Mojo
221323	Atal'aisiegel der inneren Ruhe
221324	Spröder Schlüssel zur Schattenschmiede
221325	Leichtplodier-Sprengsatz
221326	Heiliges Hirschherz
221327	Bauplan: Gnomenschrumpfstrahl
221328	Bauplan: Gnomenschutzbrille
221329	Bauplan: Gnomen-Net-o-Matik-Projektor
221330	Bauplan: Gnomenunglücksverhinderungsgürtel
221331	Bauplan: Gnomenraketenstiefel
221332	Bauplan: Gnomenkampfhuhn
221333	Bauplan: Gnomische Gedankenkontrollkappe
221334	Bauplan: Gnomentodesstrahl
221335	Bauplan: Goblinschutzhelm
221336	Bauplan: Goblinbergbauhelm
221337	Bauplan: Goblinmörser
221338	Bauplan: Goblinpioniersprengladung
221339	Bauplan: Goblinraketenstiefel
221340	Bauplan: Goblinbombenspender
221341	Bauplan: Die Große
221342	Bauplan: Goblindrachengewehr
221343	Bauplan: Goblinraketenhelm
221344	Persönliches Zauberbuch
221345	Verderbtes Blut des Eranikus
221346	Schulterblatt des gefallenen Avatars
221347	Düsteres Feuersapta
221348	Düsteres Wassersapta
221349	Düsteres Erdsapta
221350	Verkohlte Notizen des Schamanen
221351	Durchnässte Notizen des Schamanen
221352	Verschmierte Notizen des Schamanen
221353	Feuerfragment
221354	Wasserfragment
221355	Erdfragment
221356	Leuchtendes Feuerfragment
221357	Leuchtendes Wasserfragment
221358	Leuchtendes Luftfragment
221359	Makelloser Eulenbestienfederkiel
221360	Papyrus der Farraki
221361	Harz der Zukk'ash
221362	Waffenreinigungstuch
221363	Schulterblatt des gefallenen Avatars
221364	Kupfermassakermünze
221365	Silbermassakermünze
221366	Goldmassakermünze
221367	Säckchen mit Kupfermassakermünzen
221368	Säckchen mit Silbermassakermünzen
221369	Alptraumsog
221370	Wertvolles Medaillon
221371	Münzbeutel des Entführers
221372	Zerfetzter Münzbeutel
221374	Qual des Traums
221376	Helm des Smaragdgrünen Traums
221377	Beinplatten des Smaragdgrünen Traums
221378	Stulpen des Smaragdgrünen Traums
221379	Sabatons des Smaragdgrünen Traums
221380	Brustplatte des Smaragdgrünen Traums
221381	Schulterstücke des Smaragdgrünen Traums
221382	Smaragdbesetzte Kampfplatte
221383	Smaragdbesetzte Handschützer
221384	Smaragdbesetzter Helm
221385	Smaragdbesetzte Beinplatten
221386	Smaragdbesetzte Schiftung
221387	Smaragdbesetzte Plattenstiefel
221388	Smaragdschuppenrüstungsgamaschen
221389	Smaragdschuppenrüstungshandschuhe
221390	Smaragdschuppenrüstungsbrustplatte
221391	Smaragdschuppenrüstungshelm
221392	Smaragdschuppenrüstungsschulterstücke
221393	Smaragdschuppenrüstungsstiefel
221394	Smaragdbeladene Stiefel
221395	Smaragdbeladene Brustplatte
221396	Smaragdbeladene Stulpen
221397	Smaragdbeladener Helm
221398	Smaragdbeladene Gamaschen
221399	Smaragdbeladene Schulterstücke
221400	Smaragdkettenschulterstücke
221401	Smaragdkettengamaschen
221402	Smaragdkettenhelm
221403	Smaragdkettenstulpen
221404	Smaragdkettenbrustplatte
221405	Smaragdkettenstiefel
221406	Smaragdlederweste
221407	Smaragdlederhandschuhe
221408	Smaragdlederhelm
221409	Smaragdledersabatons
221410	Smaragdlederhose
221411	Smaragdlederschulterstücke
221412	Handschuhe des Smaragdtraumhüters
221413	Helm des Smaragdtraumhüters
221414	Hose des Smaragdtraumhüters
221415	Stiefel des Smaragdtraumhüters
221416	Schulterstücke des Smaragdtraumhüters
221417	Brustschutz des Smaragdtraumhüters
221418	Agamaggans Gebrüll
221419	Weste des Smaragdwächters
221420	Stiefel des Smaragdwächters
221421	Handschuhe des Smaragdwächters
221422	Helm des Smaragdwächters
221423	Gamaschen des Smaragdwächters
221424	Schulterstücke des Smaragdwächters
221425	Smaragdverzauberter Reif
221426	Smaragdverzauberte Stiefel
221427	Smaragdverzauberte Handschuhe
221428	Rune des falschen Spiels
221429	Smaragdverzauberte Hose
221430	Smaragdverzauberte Robe
221431	Smaragdverzauberte Schulterstücke
221432	Smaragdgewebter Mantel
221433	Rune des Fokus
221434	Smaragdgewebte Robe
221435	Smaragdgewebte Hose
221436	Smaragdgewebte Handschuhe
221437	Smaragdgewebter Reif
221438	Smaragdgewebte Stiefel
221439	Rüstung des Smaragdschlummers
221440	Gebrüll des Traums
221441	Wächter des Traums
221442	Gebrüll des Wächters
221443	Gebrüll des Hains
221444	Dschungeldurian
221445	Rune des fokussierten Feuers
221446	Hammer des Ritualisten
221447	Zauberfoliant des Blutmondritualisten
221448	Talisman des verderbten Hains
221450	Grubenkämpferbogen der Gurubashi
221451	Armbrust des Blutdursts
221452	Blutfokussiertes Arkanband
221453	Band des kochenden Blutes
221454	Gletscherblutband
221455	Blutlichtverehrung
221456	Verfinsterter Blutsäbel
221457	Buchband der drakonischen Zerstörung
221458	Schattenband des Sieges
221459	Siegel der Geopferten
221460	Meuchler der Gurubashi
221461	Rune des Massakers
221462	Blutiges Schwert der Geschwindigkeit
221463	Voodoopuppe der Ahnen
221464	Totem der feurigen Präzision
221465	Verderbter Schadensbringer
221466	Schleife des brennenden Bluts
221467	Auge des Blutmonds
221468	Mauer des Flüsterns
221469	Stachelspeer des Kopfjägers
221470	Traumsmaragd
221471	Truhe des Smaragdwärters
221473	Rune des Wachmanns
221474	Gebundene Essenz des Eranikus
221475	Essenz des Eranikus
221480	Zaubernotizen: Geschmolzene Rüstung
221481	Nihilistische Offenbarung
221482	Rune des Gebrechens
221483	Rune des Brands
221484	Hexerstecken des Hexendoktors
221487	Zaubernotizen: Fortgeschrittener Schutzzauber
221488	Resolute Offenbarung
221489	Rune der Rache
221490	Rune der Springflut
221491	Schattenzahntasche
221497	Alter Schlüssel
221498	Stabile Vesperdose
221499	Rune der Teufelswache
221510	Rune des Ritters
221511	Rune des Beschützers
221512	Rune des Eifers
221513	Rune der Kraft
221514	Rune der Feuerkraft
221515	Rune der Detonation
221516	Rune der urtümlichen Energie
221517	Rune des Blutvergießens
221518	Flüstern
221519	Kugel der Mannoroc
221544	Sturmkrähenei
221545	Entschlüsselte Hexenmeisternotizen
221547	Verschlüsselte Hexenmeisternotizen
221549	Chiffre der Wüstenläufer
221780	Prinzessin Theradras' Szepter
221781	Avenwachthelm
221782	Helm des Banns
221783	Schiftung der Gerechtigkeit
221785	Gewand des Cenarius
221971	Traumschwurhorn
221972	Traumloderfeuer
221973	Traumjägerreißzahn
221974	Halskette der Grimmtotem
221975	Zerbrochener Stab der Waldpfoten
221976	Verseuchter Naturstab
221978	Seele des Forschers
221979	Prophezeiung des tiefgrünen Winters
221980	Prophezeiung des erwachten Chaos
221981	Prophezeiung des verlorenen Stammes
222952	Fläschchen der ruhelosen Träume
222962	Weisheit des Hyjal
223073	Panzerschulterklappen des Hauptmanns
223074	Panzerbeinplatten des Leutnants
223075	Panzerhelm des Hauptmanns
223076	Panzerstulpen des Fähnrichs
223077	Panzersabatons des Fähnrichs
223078	Panzerrüstung des Leutnants
223147	Zaubernotizen: Qualfeuerblitz
223148	Überirdischer Schatz
223149	Überirdischer Schatz
223150	Überirdischer Schatz
223151	Überirdischer Schatz
223160	Günstiges Gestrüpp
223161	Leere Vorratskiste
223162	Handlicher Kuriertornister
223163	Formel: Schriftrolle der räumlichen Heilung
223164	Gugel der Neugierde
223167	Kappe der Initiative
223168	Weltenkernfragment
223169	Kappe der Hartnäckigkeit
223171	Schriftrolle der Geomantie
223172	Kette der Hartnäckigkeit
223173	Geomantenkordel
223174	Geomantenstiefel
223175	Geomantenumhang
223177	Geomantenkappe
223178	Geomantenarmschienen
223180	Geomantenhandschuhe
223181	Geomantenschiftung
223182	Geomantenbeinkleider
223183	Geomantenwickeltücher
223186	Vorratsdisponent
223192	Kordel des Ungezähmten
223193	Krone des Traumwebers
223194	Band der Wildnis
223195	Umarmung der Bestie
223196	Schienbeinschützer des Göttertöters
223197	Verteidiger der Wildnis
223198	Modas Karkun
223214	Zila Gular
223215	Orah Raka
223216	Rakkan Archim
223217	Rakkas Lek
223218	Tor Kieldaz
223219	Teufelsstoffgelenkbänder
223221	Teufelsledergelenkbänder
223222	Teufelspanzergelenkbänder
223237	Teufelsstoffschulterpolster
223238	Teufelslederschulterpolster
223239	Teufelspanzerschultern
223240	Teufelsstoffkapuze
223241	Teufelslederhut
223242	Teufelspanzerhaube
223248	Teufelsstoffbeinlinge
223249	Teufelslederbeinlinge
223250	Teufelspanzerbeinlinge
223251	Teufelsplattenbeinlinge
223256	Teufelsstoffroben
223261	Teufelslederbrustschutz
223262	Teufelspanzerbrustschutz
223263	Teufelsplattenbrustschutz
223283	Blutbeschmierte Belobigung
223288	Rune des Hammers
223323	Hemd
223324	Regenschreitergamaschen
223325	Hakkaribrustplatte
223326	Hakkarituch
223327	Mal von Hakkar
223328	Edelsteinbesetzter Reif
223329	Langdolch der Lebenskraft
223330	Pulsierendes Auge
223331	Pulsierendes Auge
223332	Vibrierendes Auge
223333	Unheilvolles Auge
223334	Leuchtendes Auge
223335	Triefendes Auge
223336	Stechendes Auge
223337	Brennendes Auge
223518	Charissteindolch
223519	Auge von Theradras
223520	Fokusschwert des Erfinders
223521	Faulschnappers Mantel
223522	Helm des Berges
223523	Wolkenstein
223524	Steinfaust
223525	Sterndeuterkopfputz
223526	Sul'thraze der Peitscher
223527	Fangzahn von Gahz'rilla
223528	Gahz'rillaschuppenrüstung
223529	Verwunschene Hoodoohaut
223530	Verwunschener Hoodookilt
223531	Große böse Schulterstücke
223532	Lebensblutamulett
223533	Stock des Wüstenläufers
223534	Jumanza Handschutz
223535	Grimloks Stammestracht
223536	Grimloks Attacke
223537	Schädelplattenarmschienen
223538	Entzünderstock
223539	Umzauberte Sphäre
223540	Hundemeisterbogen
223541	Edelsteinsplitterherz
223542	Megaschussgewehr
223543	Weinrankensandalen
223544	Rußgeschwärzte Metallschiftung
223545	Gizlocks supertechnischer Rundschild
223648	Traumerfüllter Pfeil
223912	Läuterungstrank
223913	Erheblicher Heiltrank
223914	Großer Heiltrank
223962	Sandpirscherknöchelschutz
223963	Umarmung des Lykan
223964	Klinge der ewigen Dunkelheit
223980	Sengschuppengamaschen
223981	Flammenschreiterroben
223982	Hundemeisterflinte
223983	Vermittlerklinge
223984	Seidengespinsthandschuhe
223985	Zyklopisches Band
223986	Modergrabcape
223987	Splitterfellschultern
224004	Smaragdring
224005	Smaragdring
224006	Smaragdring
224122	Traumfresser
224279	Terrestris
224280	Suzerain, Verteidiger der Drachenschwärme
224281	Gla'sir
224282	Rae'lar
224409	Schlangenschläger
224806	Portalempfänger der Legion
224836	Überirdischer Schatz
224848	Überirdischer Schatz
224849	Überirdischer Schatz
224850	Überirdischer Schatz
224851	Überirdischer Schatz
224893	Überladener Portalempfänger
224912	Portalempfängerempfänger
225675	Rußbedeckter Obsidiankern
225676	Geschmolzener Obsidiankern
225686	Rune der Dezimierung
225687	Rune der höllischen Rüstung
225688	Rune des Mals des Chaos
225689	Zaubernotizen: Arkanbeschuss
225690	Zaubernotizen: Gefrorene Kugel
225691	Zaubernotizen: Überhitzen
225740	Rune der Beherrschung
225838	Voltaische Ikone
225893	Epochenende
225914	Rune des gebundenen Geistes
225929	Verseuchter Seelensplitter
225938	Zerrissene Zaubernotizen
225939	Zerrissene Zaubernotizen
225940	Zerrissene Zaubernotizen
225941	Zerrissene Zaubernotizen
225942	Besudeltes Eberfleisch
225943	Ranziger Fleischbrocken
225954	Verkohlte Zaubernotizen
225955	Rune des Einfallsreichen
226122	Daltons Horn
226201	Klinge von Knappe Cuthbert
226207	Echo von Anastari
226208	Echo von Barthilas
226209	Echo von Dathrohan
226210	Echo von Maleki
226211	Echo von Nerub'enkan
226212	Echo von Ramstein
226213	Echo von Rivendare
226214	Echo von Willey
226252	Rune des Guerrillas
226374	Okkultes Gift I
226394	Handbuch für atrophisches Gift
226395	Handbuch für betäubendes Gift
226396	Handbuch für okkultes Gift
226397	Handbuch für zähes Gifts
226401	Abhandlung über das Löwenherz
226402	Offenbarung der schamanistischer Wut
226403	Handbuch des Fleischhakens
226404	Angelaufener Real aus Undermine
226405	Beschädigte Vorratskiste aus Undermine
226406	Rune der Schwert-Spezialisierung
226407	Rune der Axt-Spezialisierung
226408	Rune der Streitkolben-Spezialisierung
226409	Rune der Dolch-Spezialisierung
226410	Rune der Distanzwaffen-Spezialisierung
226411	Rune der Faustwaffen-Spezialisierung
226412	Rune der Stangenwaffen-Spezialisierung
226413	Rune der Arkan-Spezialisierungen
226414	Rune der Feuer-Spezialisierung
226415	Rune der Frost-Spezialisierung
226416	Rune der Natur-Spezialisierung
226417	Rune der Schatten-Spezialisierung
226418	Rune der Heiligspezialisierung
226419	Rune der Wildkampf-Spezialisierung
226420	Fein verarbeitete Büste
226421	PLACEHOLDER_ASHBRINGER_QUESTITEM_01
226440	Gürtel des Nachtmeuchlers
226441	Handschuhe des Nachtmeuchlers
226442	Armreife des Nachtmeuchlers
226443	Stiefel des Nachtmeuchlers
226444	Schulterklappen des Nachtmeuchlers
226445	Hose des Nachtmeuchlers
226446	Kopfschutz des Nachtmeuchlers
226447	Brustharnisch des Nachtmeuchlers
226472	Schattenglas von Stratholme
226473	Kürass des Nachtmeuchlers
226474	Taillenschutz des Nachmeuchlers
226475	Handschützer des Nachmeuchlers
226476	Armschienen des Nachtmeuchlers
226477	Tabi des Nachtmeuchlers
226478	Schulterstücke des Nachtmeuchlers
226479	Beinschützer des Nachmeuchlers
226480	Kapuze des Nachtmeuchlers
226484	Armschienen der Macht
226485	Gürtel der Macht
226486	Stulpen der Macht
226487	Sabatons der Macht
226488	Helm der Macht
226489	Brustplatte der Macht
226490	Beinplatten der Macht
226491	Schulterplatten der Macht
226492	Schulterstücke der Macht
226493	Gamaschen der Macht
226494	Halsberge der Macht
226495	Kiefer der Macht
226496	Treter der Macht
226497	Hände der Macht
226498	Schärpe der Macht
226499	Armschützer der Macht
226500	Gesplittertes Drachenfeueramulett
226523	Daltons Horn
226526	Kaputtes Dingsbums
226527	Schulterklappen des Riesenjägers
226528	Handschuhe des Riesenjägers
226529	Gürtel des Riesenjägers
226530	Armschienen des Riesenjägers
226531	Stiefel des Riesenjägers
226532	Gamaschen des Riesenjägers
226533	Helm des Riesenjägers
226534	Brustplatte des Riesenjägers
226535	Kettenrüstung des Riesenjägers
226536	Haube des Riesenjägers
226537	Kettengamaschen des Riesenjägers
226538	Sabatons des Riesenjägers
226540	Handschützer des Riesenjägers
226541	Handgelenksschützer des Riesenjägers
226542	Gurt des Riesenjägers
226543	Schulterstücke des Riesenjägers
226545	Daltons Horn
226546	Wüstensonar
226547	Teufelsherzhose
226548	Teufelsherzroben
226549	Teufelsherzhörner
226550	Teufelsherzschulterpolster
226551	Teufelsherzgürtel
226552	Teufelsherzhandschuhe
226553	Teufelsherzarmschienen
226554	Teufelsherzschuhe
226555	Gürtel des Arkanisten
226556	Handschuhe des Arkanisten
226557	Stiefel des Arkanisten
226558	Bindungen des Arkanisten
226559	Roben des Arkanisten
226560	Mantel des Arkanisten
226561	Gamaschen des Arkanisten
226562	Krone des Arkanisten
226563	Kleider des Arkanisten
226564	Kopfputz des Arkanisten
226565	Hose des Arkanisten
226566	Schulterteile des Arkanisten
226567	Gelenkbänder des Arkanisten
226568	Sandalen des Arkanisten
226569	Handschützer des Arkanisten
226570	Kordel des Arkanisten
226571	Stiefel der Prophezeiung
226572	Handschuhe der Prophezeiung
226573	Reif der Prophezeiung
226574	Hose der Prophezeiung
226575	Roben der Prophezeiung
226576	Mantel der Prophezeiung
226577	Gurt der Prophezeiung
226578	Unterarmschienen der Prophezeiung
226579	Gelenkbänder der Prophezeiung
226580	Gürtel der Prophezeiung
226581	Schulterpolster der Prophezeiung
226582	Kleider der Prophezeiung
226583	Gamaschen der Prophezeiung
226584	Krone der Prophezeiung
226585	Hände der Prophezeiung
226586	Sandalen der Prophezeiung
226587	Rune des Beschusses
226588	Schiftung der Gerechtigkeit
226589	Armschienen der Gerechtigkeit
226590	Helm der Gerechtigkeit
226591	Stulpen der Gerechtigkeit
226592	Gürtel der Gerechtigkeit
226593	Stiefel der Gerechtigkeit
226594	Beinplatten der Gerechtigkeit
226595	Brustschutz der Gerechtigkeit
226596	Kriegsbänder der Gerechtigkeit
226597	Gurt der Gerechtigkeit
226598	Gamaschen der Gerechtigkeit
226599	Krone der Gerechtigkeit
226600	Handschutz der Gerechtigkeit
226601	Kampfstiefel der Gerechtigkeit
226602	Brustplatte der Gerechtigkeit
226603	Unterarmschienen der Gerechtigkeit
226604	Kampfgurt der Gerechtigkeit
226605	Schulterstücke der Gerechtigkeit
226606	Beinschützer der Gerechtigkeit
226607	Kopfschutz der Gerechtigkeit
226608	Handschützer der Gerechtigkeit
226609	Sabatons der Gerechtigkeit
226610	Brustplatte der Gerechtigkeit
226611	Schulterklappen der Erdenwut
226612	Helm der Erdenwut
226613	Stiefel der Erdenwut
226614	Beinschützer der Erdenwut
226615	Stulpen der Erdenwut
226616	Gürtel der Erdenwut
226617	Gewand der Erdenwut
226618	Armschienen der Erdenwut
226619	Ringpanzer der Erdenwut
226620	Laufschuhe der Erdenwut
226621	Hände der Erdenwut
226622	Visier der Erdenwut
226623	Gamaschen der Erdenwut
226624	Mantel der Erdenwut
226625	Kordel der Erdenwut
226626	Gelenkbänder der Erdenwut
226627	Schuppenrüstung der Erdenwut
226628	Sabatons der Erdenwut
226629	Handschützer der Erdenwut
226630	Großhelm der Erdenwut
226631	Schuppengamaschen der Erdenwut
226632	Schulterstücke der Erdenwut
226633	Taillenschutz der Erdenwut
226634	Handgelenksschützer der Erdenwut
226635	Kettenrüstung der Erdenwut
226636	Kampfstiefel der Erdenwut
226637	Handschutz der Erdenwut
226638	Kopfteil der Erdenwut
226639	Kettengamaschen der Erdenwut
226640	Schiftung der Erdenwut
226641	Gurt der Erdenwut
226642	Bindungen der Erdenwut
226644	Schiftung des Cenarius
226645	Stiefel des Cenarius
226646	Gamaschen des Cenarius
226647	Helm des Cenarius
226648	Handschuhe des Cenarius
226649	Armschienen des Cenarius
226650	Gürtel des Cenarius
226651	Hose des Cenarius
226652	Sandalen des Cenarius
226653	Mantel des Cenarius
226654	Stulpen des Cenarius
226655	Handgelenkteile des Cenarius
226656	Umarmung des Cenarius
226657	Kordel des Cenarius
226658	Geweih des Cenarius
226659	Hörner des Cenarius
226660	Gurt des Cenarius
226661	Tunika des Cenarius
226662	Bänder des Cenarius
226663	Treter des Cenarius
226664	Fäuste des Cenarius
226665	Schulterteile des Cenarius
226666	Beinkleider des Cenarius
226667	Taillenschutz des Cenarius
226668	Handgelenksschützer des Cenarius
226669	Handschutz des Cenarius
226670	Krone des Cenarius
226671	Beinschützer des Cenarius
226673	Laufschuhe des Cenarius
226674	Schulterstücke des Cenarius
226675	Rüstung des Cenarius
226678	Vorahnung und Voraussicht im Kampf
226679	Erkenntnisse des Zeitlosen Wanderers
226680	Rune des ersten Kriegers
226694	Rune der Verteidigungs-Spezialisierung
226698	Vertikal zusammengesetzter Flickcontainer
226699	Messingbeschlagener Falschmalschflansch
226700	Tunika der Schattenkunst
226701	Gürtel der Schattenkunst
226702	Handschuhe der Schattenkunst
226703	Stiefel der Schattenkunst
226704	Armschienen der Schattenkunst
226705	Hose der Schattenkunst
226706	Schiftung der Schattenkunst
226707	Kappe der Schattenkunst
226708	Gugel des Wildherzens
226709	Kilt des Wildherzens
226710	Schiftung des Wildherzens
226711	Handschuhe des Wildherzens
226712	Gürtel des Wildherzens
226713	Stiefel des Wildherzens
226714	Armschienen des Wildherzens
226715	Weste des Wildherzens
226716	Bestienjägermantel
226717	Bestienjägerbindungen
226718	Bestienjägergürtel
226719	Bestienjägerhose
226720	Bestienjägerkappe
226721	Bestienjägerhandschuhe
226722	Bestienjägerstiefel
226723	Bestienjägertunika
226724	Gürtel des Magisters
226725	Bindungen des Magisters
226726	Mantel des Magisters
226727	Gamaschen des Magisters
226728	Krone des Magisters
226729	Roben des Magisters
226730	Stiefel des Magisters
226731	Handschuhe des Magisters
226732	Gürtel des Lichts
226733	Helm des Lichts
226734	Brustplatte des Lichts
226735	Schiftung des Lichts
226736	Beinplatten des Lichts
226737	Stulpen des Lichts
226738	Stiefel des Lichts
226739	Armschienen des Lichts
226740	Handschuhe des Gläubigen
226741	Mantel des Gläubigen
226742	Armschienen des Gläubigen
226743	Sandalen des Gläubigen
226744	Gürtel des Gläubigen
226745	Robe des Gläubigen
226746	Krone des Gläubigen
226747	Rock des Gläubigen
226748	Stulpen der Elemente
226749	Weste der Elemente
226750	Kilt der Elemente
226751	Bindungen der Elemente
226752	Stiefel der Elemente
226753	Schulterstücke der Elemente
226754	Kordel der Elemente
226755	Helmkappe der Elemente
226756	Mantel der Furcht
226757	Robe der Furcht
226758	Wickeltücher der Furcht
226759	Armschienen der Furcht
226760	Gamaschen der Furcht
226761	Gürtel der Furcht
226762	Maske der Furcht
226763	Sandalen der Furcht
226764	Stiefel der Ehre
226765	Gürtel der Ehre
226766	Armschienen der Ehre
226767	Beinplatten der Ehre
226768	Schiftung der Ehre
226769	Helm der Ehre
226770	Brustplatte der Ehre
226771	Stulpen der Ehre
226772	Schärpe des ungezähmten Herzens
226773	Gugel des ungezähmten Herzens
226774	Galoschen des ungezähmten Herzens
226775	Wickeltücher des ungezähmten Herzens
226776	Weste des ungezähmten Herzens
226777	Hände des ungezähmten Herzens
226778	Schiftung des ungezähmten Herzens
226779	Kilt des ungezähmten Herzens
226780	Kordel des ungezähmten Herzens
226781	Sandalen des ungezähmten Herzens
226782	Bindungen des ungezähmten Herzens
226783	Umarmung des ungezähmten Herzens
226784	Stulpen des ungezähmten Herzens
226785	Mantel des ungezähmten Herzens
226786	Kopfputz des ungezähmten Herzens
226787	Hose des ungezähmten Herzens
226788	Bänder des ungezähmten Herzens
226789	Gurt des ungezähmten Herzens
226790	Schulterklappen des ungezähmten Herzens
226791	Beinkleider des ungezähmten Herzens
226792	Kappe des ungezähmten Herzens
226793	Fäuste des ungezähmten Herzens
226794	Laufschuhe des ungezähmten Herzens
226795	Tunika des ungezähmten Herzens
226796	Handgelenksschützer des ungezähmten Herzens
226797	Taillenschutz des ungezähmten Herzens
226798	Schulterstücke des ungezähmten Herzens
226799	Beinschützer des ungezähmten Herzens
226801	Gesichtsschutz des ungezähmten Herzens
226802	Handschutz des ungezähmten Herzens
226803	Treter des ungezähmten Herzens
226804	Rüstung des ungezähmten Herzens
226815	Handgelenkteile des ungezähmten Herzens
226816	Hüftschutz des ungezähmten Herzens
226817	Schulterteile des ungezähmten Herzens
226818	Beinteile des ungezähmten Herzens
226819	Helm des ungezähmten Herzens
226820	Handschuhe des ungezähmten Herzens
226821	Stiefel des ungezähmten Herzens
226822	Brustteil des ungezähmten Herzens
226825	Tunika der Finsternis
226826	Schiftung der Finsternis
226827	Hose der Finsternis
226828	Handschutz der Finsternis
226829	Kappe der Finsternis
226830	Armschienen der Finsternis
226831	Fußpolster der Finsternis
226832	Gürtel der Finsternis
226835	Handgelenksschützer der Finsternis
226836	Taillenschutz der Finsternis
226837	Schulterstücke der Finsternis
226838	Beinschützer der Finsternis
226840	Handschützer der Finsternis
226841	Gesichtsschutz der Finsternis
226842	Treter der Finsternis
226843	Rüstung der Finsternis
226845	Handgelenkteile der Finsternis
226846	Hüftschutz der Finsternis
226847	Schulterteile der Finsternis
226848	Beinteile der Finsternis
226849	Helm der Finsternis
226850	Handschuhe der Finsternis
226851	Stiefel der Finsternis
226852	Brustteil der Finsternis
226856	Gelenkter Auftriebbeschleuniger
226857	Kampfstiefel des Heldentums
226858	Schiftung des Heldentums
226859	Beinplatten des Heldentums
226860	Krone des Heldentums
226861	Stulpen des Heldentums
226862	Brustplatte des Heldentums
226863	Armschienen des Heldentums
226864	Gürtel des Heldentums
226865	Handgelenksschützer des Heldentums
226866	Hüftschutz des Heldentums
226867	Schulterstücke des Heldentums
226868	Beinschützer des Heldentums
226869	Gesichtsschutz des Heldentums
226870	Handschützer des Heldentums
226871	Sabatons des Heldentums
226872	Brustschutz des Heldentums
226873	Handgelenke des Heldentums
226874	Hüfte des Heldentums
226875	Schultern des Heldentums
226876	Beine des Heldentums
226877	Helm des Heldentums
226878	Handschuhe des Heldentums
226879	Stiefel des Heldentums
226880	Brust des Heldentums
226881	Treter der Tierherrschaft
226882	Hosen der Tierherrschaft
226883	Stulpen der Tierherrschaft
226884	Mantel der Tierherrschaft
226885	Bindungen der Tierherrschaft
226886	Tunika der Tierherrschaft
226887	Kappe der Tierherrschaft
226888	Gürtel der Tierherrschaft
226889	Armschienen der Tierherrschaft
226890	Hüfttuch der Tierherrschaft
226891	Schulterstücke der Tierherrschaft
226892	Gamaschen der Tierherrschaft
226893	Helmkappe der Tierherrschaft
226894	Fäuste der Tierherrschaft
226895	Schienbeinschützer der Tierherrschaft
226896	Kette der Tierherrschaft
226897	Handgelenke der Tierherrschaft
226898	Hüfte der Tierherrschaft
226899	Schultern der Tierherrschaft
226900	Beine der Tierherrschaft
226901	Helm der Tierherrschaft
226902	Handschuhe der Tierherrschaft
226903	Stiefel der Tierherrschaft
226904	Brust der Tierherrschaft
226905	Gürtel des Todesnebels
226906	Robe des Todesnebels
226907	Armschienen des Todesnebels
226908	Sandalen des Todesnebels
226909	Maske des Todesnebels
226910	Gamaschen des Todesnebels
226911	Wickeltücher des Todesnebels
226912	Mantel des Todesnebels
226913	Bindungen des Todesnebels
226914	Kordel des Todesnebels
226915	Schulterklappen des Todesnebels
226916	Hosen des Todesnebels
226917	Kapuze des Todesnebels
226918	Griff des Todesnebels
226919	Treter des Todesnebels
226920	Umarmung des Todesnebels
226921	Handgelenke des Todesnebels
226922	Hüfte des Todesnebels
226923	Schultern des Todesnebels
226924	Beine des Todesnebels
226925	Helm des Todesnebels
226926	Handschuhe des Todesnebels
226927	Stiefel des Todesnebels
226928	Brust des Todesnebels
226929	Bindungen der Zauberkünste
226930	Stulpen der Zauberkünste
226931	Sandalen der Zauberkünste
226932	Roben der Zauberkünste
226933	Gamaschen der Zauberkünste
226934	Gürtel der Zauberkünste
226935	Krone der Zauberkünste
226936	Mantel der Zauberkünste
226937	Handgelenke der Zauberkünste
226938	Hüfte der Zauberkünste
226939	Schultern der Zauberkünste
226940	Beine der Zauberkünste
226941	Helm der Zauberkünste
226942	Handschuhe der Zauberkünste
226943	Stiefel der Zauberkünste
226944	Brust der Zauberkünste
226945	Robe des Tugendhaften
226946	Rock des Tugendhaften
226947	Krone des Tugendhaften
226948	Gürtel des Tugendhaften
226949	Armschienen des Tugendhaften
226950	Fäustlinge des Tugendhaften
226951	Mantel des Tugendhaften
226952	Sandalen des Tugendhaften
226953	Wickel des Tugendhaften
226954	Kordel des Tugendhaften
226955	Schulterklappen des Tugendhaften
226956	Gamaschen des Tugendhaften
226957	Gugel des Tugendhaften
226958	Hände des Tugendhaften
226959	Pantoffeln des Tugendhaften
226960	Gewand des Tugendhaften
226961	Handgelenke des Tugendhaften
226962	Hüfte des Tugendhaften
226963	Schultern des Tugendhaften
226964	Beine des Tugendhaften
226965	Helm des Tugendhaften
226966	Handschuhe des Tugendhaften
226967	Stiefel des Tugendhaften
226968	Brust des Tugendhaften
226969	Schiftung der Seelenschmiede
226970	Armschienen der Seelenschmiede
226971	Gürtel der Seelenschmiede
226972	Beinplatten der Seelenschmiede
226973	Brustplatte der Seelenschmiede
226974	Kriegsstiefel der Seelenschmiede
226975	Stulpen der Seelenschmiede
226976	Großhelm der Seelenschmiede
226977	Bindungen der Seelenschmiede
226978	Kordel der Seelenschmiede
226979	Schulterklappen der Seelenschmiede
226980	Gamaschen der Seelenschmiede
226981	Krone der Seelenschmiede
226982	Fäuste der Seelenschmiede
226983	Treter der Seelenschmiede
226984	Umarmung der Seelenschmiede
226985	Handgelenksschützer der Seelenschmiede
226986	Hüftschutz der Seelenschmiede
226987	Schulterstücke der Seelenschmiede
226988	Beinschützer der Seelenschmiede
226989	Gesichtsschutz der Seelenschmiede
226990	Handschützer der Seelenschmiede
226991	Sabatons der Seelenschmiede
226992	Brustschützer der Seelenschmiede
226993	Handgelenke der Seelenschmiede
226994	Hüfte der Seelenschmiede
226995	Schultern der Seelenschmiede
226996	Beine der Seelenschmiede
226997	Helm der Seelenschmiede
226998	Handschuhe der Seelenschmiede
226999	Stiefel der Seelenschmiede
227000	Brust der Seelenschmiede
227001	Bindungen der fünf Donner
227002	Helmkappe der fünf Donner
227003	Schulterstücke der fünf Donner
227004	Weste der fünf Donner
227005	Kilt der fünf Donner
227006	Stulpen der fünf Donner
227007	Pantoffeln der fünf Donner
227008	Kordel der fünf Donner
227009	Armschienen der fünf Donner
227010	Schärpe der fünf Donner
227011	Mantel der fünf Donner
227012	Gamaschen der fünf Donner
227013	Krone der fünf Donner
227014	Griff der fünf Donner
227015	Schienbeinschützer der fünf Donner
227016	Tunika der fünf Donner
227017	Bänder der fünf Donner
227018	Gurt der fünf Donner
227019	Schiftung der fünf Donner
227020	Beinplatten der fünf Donner
227021	Gesicht der fünf Donner
227022	Fäuste der fünf Donner
227023	Treter der fünf Donner
227024	Kette der fünf Donner
227025	Handgelenkschutz der fünf Donner
227026	Hüftschutz der fünf Donner
227027	Schulterschutz der fünf Donner
227028	Beinschutz der fünf Donner
227029	Kopfteil der fünf Donner
227030	Handschutz der fünf Donner
227031	Sabatons der fünf Donner
227032	Brustschutz der fünf Donner
227033	Handgelenke der fünf Donner
227034	Hüfte der fünf Donner
227035	Schultern der fünf Donner
227036	Beine der fünf Donner
227037	Helm der fünf Donner
227038	Handschuhe der fünf Donner
227039	Stiefel der fünf Donner
227040	Brust der fünf Donner
227041	Schattenskalpel der Geißel
227042	Plattenschultern des Feldherren
227043	Plattenhelm des Feldherren
227044	Plattenhelm des Feldkommandanten
227045	Plattenschultern des Feldkommandanten
227046	Plattenhalsberge des Kürassiers
227047	Plattengamaschen des Kürassiers
227048	Plattengamaschen des Zornbringers
227049	Plattenhalsberge des Zornbringers
227050	Plattenstulpen des Blutgardisten
227051	Plattenschienbeinschützer des Blutgardisten
227052	Plattenschienbeinschützer des Hauptmanns
227053	Plattenstulpen des Hauptmanns
227054	Lederschultern des Feldkommandanten
227055	Lederhelm des Feldkommandanten
227056	Lederschultern des Feldherren
227057	Lederhelm des Feldherren
227058	Lederner Brustharnisch des Kürassiers
227059	Lederbeinschützer des Zornbringers
227060	Lederbrustharnisch des Zornbringers
227061	Lederbeinschützer des Kürassiers
227062	Lederlaufschuhe des Blutgardisten
227063	Lederhandschutz des Blutgardisten
227064	Lederlaufschuhe des Hauptmanns
227065	Lederhandschutz des Hauptmanns
227066	Kettenhelm des Feldkommandanten
227067	Kettenhelm des Feldherren
227068	Kettenschultern des Feldkommandanten
227069	Kettenschultern des Feldherren
227070	Kettentorso des Kürassiers
227071	Kettenhalsberge des Zornbringers
227072	Kettenbeinschützer des Kürassiers
227073	Kettenbeinschützer des Zornbringers
227074	Kettenschienbeinschützer des Blutgardisten
227075	Kettenklemmen des Blutgardisten
227076	Kettenschienbeinschützer des Hauptmanns
227077	Kettenklemmen des Hauptmanns
227078	Kettenschulterstücke des Feldherren
227079	Kettenbeinplatten des Zornbringers
227080	Kettengroßhelm des Feldherren
227081	Kettenhandschutz des Blutgardisten
227082	Kettensabatons des Blutgardisten
227083	Kettenrüstung des Zornbringers
227084	Kettenschulterstücke des Feldkommandanten
227085	Kettenbeinplatten des Kürassiers
227086	Kettengroßhelm des Feldkommandanten
227087	Kettenhandschutz des Hauptmanns
227088	Kettensabatons des Hauptmanns
227089	Kettenrüstung des Kürassiers
227090	Schreckenszwirngugel des Feldherren
227091	Schreckenszwirnschiftung des Feldkommandanten
227092	Schreckenszwirnschiftung des Feldherren
227093	Schreckenszwirngugel des Feldkommandanten
227094	Schreckenszwirntunika des Zornbringers
227095	Schreckenszwirnbeinschützer des Kürassiers
227096	Schreckenszwirntunika des Kürassiers
227097	Schreckenszwirnbeinschützer des Zornbringers
227098	Schreckenszwirnlaufschuhe des Blutgardisten
227099	Schreckenszwirnhandlappen des Blutgardisten
227100	Schreckenszwirnhandlappen des Hauptmanns
227101	Schreckenszwirnlaufschuhe des Hauptmanns
227102	Seidenmantel des Feldkommandanten
227103	Seidengugel des Feldkommandanten
227104	Seidenmantel des Feldherren
227105	Seidengugel des Feldherren
227106	Seidentunika des Zornbringers
227107	Seidenbeinschützer des Zornbringers
227108	Seidentunika des Kürassiers
227109	Seidenbeinschützer des Kürassiers
227110	Seidenlaufschuhe des Blutgardisten
227111	Seidenhandlappen des Blutgardisten
227112	Seidenlaufschuhe des Hauptmanns
227113	Seidenhandlappen des Hauptmanns
227114	Seudebstulpen des Hauptmanns
227115	Seidenstulpen des Blutgardisten
227116	Seidene Handschuhe des Hauptmanns
227117	Seidene Handschuhe des Blutgardisten
227118	Satinkapuze des Feldherren
227119	Satinmantel des Feldkommandanten
227120	Satinmantel des Feldherren
227121	Satinkapuze des Feldkommandanten
227122	Satintunika des Kürassiers
227123	Satinbeinschützer des Zornbringers
227124	Satintunika des Zornbringers
227125	Satinbeinschützer des Kürassiers
227126	Satinhandlappen des Blutgardisten
227127	Satinlaufschuhe des Blutgardisten
227128	Satinhandlappen des Hauptmanns
227129	Satinlaufschuhe des Hauptmanns
227130	Satinschulterklappen des Feldherren
227131	Satingamaschen des Zornbringers
227132	Satinkrone des Feldherren
227133	Satinhandschutz des Blutgardisten
227134	Satintreter des Blutgardisten
227135	Satinrobe des Zornbringers
227136	Satinschulterklappen des Feldkommandanten
227137	Satingamaschen des Kürassiers
227138	Satinkrone des Feldkommandanten
227139	Satinhandschutz des Hauptmanns
227140	Satintreter des Hauptmanns
227141	Satinrobe des Kürassiers
227142	Lamellenbrustplatte des Kürassiers
227143	Lamellengamaschen des Kürassiers
227144	Lamellenkopfschutz des Feldkommandanten
227145	Lamellenschultern des Feldkommandanten
227146	Lamellensabatons des Hauptmanns
227147	Lamellenstulpen des Hauptmanns
227148	Lamellenschulterstücke des Feldkommandanten
227149	Lamellenhelm des Feldkommandanten
227150	Lamellenbeinschützer des Kürassiers
227151	Lamellenbrustplatte des Kürassiers
227152	Lamellenhandschuhe des Hauptmanns
227153	Lamellenschienbeinschützer des Hauptmanns
227154	Panzerschulterstücke des Feldherren
227155	Panzerkopfschutz des Feldherren
227156	Panzerbeinschützer des Zornbringers
227157	Panzerhalsberge des Zornbringers
227158	Panzerschienbeinschützer des Blutgardisten
227159	Panzerklemmen des Blutgardisten
227160	Panzerschulterstücke des Feldherren
227161	Panzergamaschen des Zornbringers
227162	Panzerhelm des Feldherren
227163	Panzerstulpen des Blutgardisten
227164	Panzersabatons des Blutgardisten
227165	Panzerbrustplatte des Zornbringers
227166	Panzerschulterklappen des Feldherren
227167	Panzerhose des Zornbringers
227168	Panzerschädelkappe des Feldherren
227169	Panzerhandschuhe des Blutgardisten
227170	Panzerstiefel des Blutgardisten
227171	Panzerbrustschutz des Zornbringers
227172	Drachenlederschultern des Feldkommandanten
227173	Drachenlederkopfschutz des Feldkommandanten
227174	Drachenlederkopfschutz des Feldherren
227175	Drachenlederschultern des Feldherren
227176	Drachenlederbrustharnisch des Kürassiers
227177	Drachenledergamaschen des Zornbringers
227178	Drachenledergamaschen des Kürassiers
227179	Drachenlederbrustharnisch des Zornbringers
227180	Drachenlederhandschutz des Blutgardisten
227181	Drachenledertreter des Blutgardisten
227182	Drachenledertreter des Hauptmanns
227183	Drachenlederhandschutz des Hauptmanns
227184	Drachenlederschiftung des Feldherren
227185	Drachenlederhosen des Zornbringers
227186	Drachenlederhelm des Feldherren
227187	Drachenlederhandschuhe des Blutgardisten
227188	Drachenlederstiefel des Blutgardisten
227189	Drachenlederrüstung des Zornbringers
227190	Drachenlederschiftung des Feldkommandanten
227191	Drachenlederhosen des Kürassiers
227192	Drachenlederhelm des Feldkommandanten
227193	Drachenlederhandschuhe des Hauptmanns
227194	Drachenlederstiefel des Hauptmanns
227195	Drachenlederrüstung des Kürassiers
227196	Drachenledertunika des Kürassiers
227197	Drachenlederschienbeinschützer des Hauptmanns
227198	Drachenlederstulpen des Hauptmanns
227199	Drachenlederkopfbedeckung des Feldkommandanten
227200	Drachenlederbeinschützer des Kürassiers
227201	Drachenlederschulterstücke des Feldkommandanten
227202	Drachenledertunika des Zornbringers
227203	Drachenlederschienbeinschützer des Blutgardisten
227204	Drachenlederstulpen des Blutgardisten
227205	Drachenlederkopfbedeckung des Feldherren
227206	Drachenlederbeinschützer des Zornbringers
227207	Drachenlederschulterstücke des Feldherren
227279	Ring des Magisters
227280	Kunst der Schatten
227282	Ring der schrecklichen Nebel
227284	Band der Bestie
227285	Strukturelle Flussdynamiken
227286	Warmer Rumsey Rum mit Sahne
227337	Set: Handschuhe und Gürtel der Katze
227338	Set: Handschuhe und Gürtel des Astralen
227339	Set: Handschuhe und Gürtel des Wächters
227340	Set: Handschuhe und Gürtel des Heilers
227341	Set: Handschuhe und Gürtel des Verfolgers
227342	Set: Handschuhe und Gürtel des Pirschers
227343	Set: Handschuhe und Gürtel der Gnade
227344	Set: Handschuhe und Gürtel der Strahlen
227345	Set: Handschuhe und Gürtel des göttlichen Willens
227346	Set: Handschuhe und Gürtel der Dämmerung
227347	Set: Handschuhe und Gürtel des Zwielichts
227348	Set: Handschuhe und Gürtel des Rauschs
227349	Set: Handschuhe und Gürtel der Schlacht
227350	Set: Handschuhe und Gürtel der Linderung
227351	Set: Handschuhe und Gürtel der Eruption
227352	Set: Handschuhe und Gürtel des Einschlags
227353	Set: Handschuhe und Gürtel der Entschlossenheit
227354	Set: Handschuhe und Gürtel der Verderbnis
227355	Set: Handschuhe und Gürtel der Boshaftigkeit
227356	Set: Handschuhe und Gürtel der Unnachgiebigkeit
227357	Set: Handschuhe und Gürtel der Unaufhaltsamkeit
227359	Set: Stiefel, Beine und Schultern der Katze
227360	Set: Stiefel, Beine und Schultern des Astralen
227361	Set: Stiefel, Beine und Schultern des Wächters
227365	Set: Stiefel, Beine und Schultern des Heilers
227366	Set: Stiefel, Beine und Schultern des Verfolgers
227367	Set: Stiefel, Beine und Schultern des Pirschers
227368	Set: Stiefel, Beine und Schultern der Gnade
227369	Set: Stiefel, Beine und Schultern der Strahlen
227370	Set: Stiefel, Beine und Schultern des göttlichen Willens
227371	Set: Stiefel, Beine und Schultern des Morgengrauens
227372	Set: Stiefel, Beine und Schultern des Zwielichts
227373	Set: Stiefel, Beine und Schultern des Rauschs
227374	Set: Stiefel, Beine und Schultern der Schlacht
227375	Set: Stiefel, Beine und Schultern der Linderung
227376	Set: Stiefel, Beine und Schultern der Eruption
227377	Set: Stiefel, Beine und Schultern des Einschlags
227378	Set: Stiefel, Beine und Schultern der Entschlossenheit
227379	Set: Stiefel, Beine und Schultern der Verderbnis
227380	Set: Stiefel, Beine und Schultern der Boshaftigkeit
227381	Set: Stiefel, Beine und Schultern der Unnachgiebigkeit
227382	Set: Stiefel, Beine und Schultern der Unaufhaltsamkeit
227383	Set: Helm und Brustteil der Katze
227384	Set: Helm und Brustteil des Astralen
227385	Set: Helm und Brustteil des Wächters
227387	Set: Helm und Brustteil des Heilers
227388	Set: Helm und Brustteil des Verfolgers
227389	Set: Helm und Brustteil des Pirschers
227390	Set: Helm und Brustteil der Gnade
227391	Set: Helm und Brustteil der Strahlen
227392	Set: Helm und Brustteil des göttlichen Willens
227393	Set: Helm und Brustteil des Morgengrauens
227394	Set: Helm und Brustteil des Zwielichts
227395	Set: Helm und Brustteil des Rauschs
227396	Set: Helm und Brustteil der Schlacht
227397	Set: Helm und Brustteil der Linderung
227398	Set: Helm und Brustteil der Eruption
227399	Set: Helm und Brustteil des Einschlags
227400	Set: Helm und Brustteil der Entschlossenheit
227401	Set: Helm und Brustteil der Verderbnis
227402	Set: Helm und Brustteil der Boshaftigkeit
227403	Set: Helm und Brustteil der Unnachgiebigkeit
227404	Set: Helm und Brustteil der Unaufhaltsamkeit
227444	Götze der Jägerin
227451	Sendesiegel
227454	Gezeitenschleife
227455	Meeresbrise
227456	Rune des blutroten Sturms
227530	Gleißender Gürtel
227531	Gleißende Bindungen
227532	Gleißende Kapuze
227533	Gleißende Handschuhe
227534	Gleißende Gamaschen
227535	Gleißende Robe
227536	Gleißende Stiefel
227537	Gleißende Schulterpolster
227549	Pergamentfetzen
227552	Zerrissenes Pergament
227658	Notiz der Schattenanbeter
227683	Sulfuras, Hand von Ragnaros
227684	Sulfuronhammer
227685	Modifiziertes Schattenskalpell
227686	Verzierter Kriegshammer
227687	Orthas Lieblingsgoldzahn
227688	Blutschrei
227689	Halbverdaute Plattenrüstung
227690	Nekrotischer Runenstein
227691	Klinge von Hanna
227724	Blutbeschmierte Belobigung
227727	Pläne: Sulfuronhammer
227728	Auge von Sulfuras
227730	Vertrag der Thoriumbruderschaft
227743	Obsidiankraftquelle
227745	Familienerbstück
227746	Rune des Weltenbaums
227747	Familienchronik
227748	Tagebuch des Überlebenden
227749	Rune der Sternschnuppe
227750	Geschmolzene Schuppenbindungen
227751	Geschmolzener Schuppengürtel
227752	Geschmolzene Schuppenschulterpolster
227754	Geschmolzene Schuppengamaschen
227755	Geschmolzener Schuppenhelm
227756	Geschmolzene Schuppenhandschuhe
227757	Geschmolzene Schuppenstiefel
227758	Geschmolzene Schuppenbrust
227759	Versengte Kernhandschuhe
227760	Versengte Kernbindungen
227761	Versengter Kerngürtel
227762	Versengte Kernschulterpolster
227763	Versengte Kerngamaschen
227764	Versengter Kernhelm
227765	Versengte Kernstiefel
227766	Versengte Kernbrust
227767	Flammensteinhaufen
227768	Traumsaft
227796	Mysteriöse darnassische Schriftrolle
227797	Entzifferte darnassische Schriftrolle
227801	Feuerlandglut
227803	Grässlicher Kriegsbärenharnisch
227804	Grässliche Kriegsbärenwollwäsche
227805	Wildheit der Holzschlundfeste
227807	Dichter Gürtel der Holzschlundfeste
227808	Rauer Mantel der Holzschlundfeste
227809	Beschlagene Kampfhandschuhe der Holzschlundfeste
227810	Dichte Stiefel der Holzschlundfeste
227811	Verteidiger der Holzschlundfeste
227812	Medizinbeutel der Furbolgs
227813	Trinkbares Weihwasser von Stratholme
227814	Strahlender Gurt der Dämmerung
227815	Feine Stiefel der Dämmerung
227816	Argentumelitestiefel
227817	Strahlende Handschuhe der Dämmerung
227818	Leuchtender Mantel der Dämmerung
227819	Gesegneter Flammenmantel der Dämmerung
227820	Getemperte Dunkeleisenarmschienen
227821	Flammengeküsster geschmolzener Helm
227822	Dicke Kernhundstiefel
227823	Feine Flimmerkernhandschuhe
227824	Getemperter Dunkeleisenhelm
227825	Geschmolzener Dunkeleisenzerstörer
227826	Dunkeleisenflammenhäscher
227827	Geschmolzener Kettengurt
227828	Gürtel des Lavawandlers
227829	Gehärtete schwarze Drachenschuppenstiefel
227830	Feiner Flimmerkernmantel
227831	Feine Flimmerkernrobe
227832	Getemperte schwarze Amnestie
227833	Gleve des Obisidianzorns
227834	Geschmolzene Kettenschultern
227835	Getemperte Dunkeleisenstulpen
227836	Getemperte Dunkeleisengamaschen
227837	Dicker Kernhundgürtel
227838	Leuchtende chromatische Stulpen
227839	Feine Flimmerkerngamaschen
227840	Unerbittlicher finsterer Streiter
227841	Getemperte Dunkeleisenstiefel
227842	Ebenholzfaust
227843	Plündernde Nachtlauer
227844	Lederverstärkte Runenstofftasche
227845	Veredelter Arkanitschnitter
227847	Teufelskerngamaschen
227848	Teufelskernstulpen
227849	Feuerkern-Scharfschützengewehr
227850	Weisenklinge des Erzmagiers
227851	Gehärtete schwarze Drachenschuppenbrustplatte
227852	Gehärtete schwarze Drachenschuppengamaschen
227853	Gehärtete schwarze Drachenschuppenschultern
227854	Meisterlich gefertigter unbeständiger Umhang
227857	Entweihung
227858	Hammer der wilden Götter
227859	Schimmernde Schultern der Morgenröte
227860	Gleißende Mondstoffweste
227861	Gleißende Mondstoffrobe
227862	Gleißende Mondstoffstiefel
227863	Gleißender Mondstoffreif
227864	Gleißende Mondstoffgamaschen
227865	Feurige Plattenstulpen der verborgenen Technik
227866	Meisterhafte vulkanische Schultern
227867	Meisterhafte vulkanische Gamaschen
227868	Meisterhafte vulkanische Brustplatte
227869	Glänzender chromatischer Umhang
227870	Sturmstulpen
227871	Getemperte Dunkeleisenplatte
227872	Kriegswappen des großen Häuptlings
227873	Geschliffene blaue Drachenschuppenschultern
227874	Geschliffene blaue Drachenschuppengamaschen
227875	Geschliffene blaue Drachenschuppenbrustplatte
227876	Unverwundbarer Panzer
227877	Lebende grüne Drachenschuppengamaschen
227878	Lebende grüne Drachenschuppenstulpen
227879	Lebende grüne Drachenschuppenbrustplatte
227880	Sorgsam verzauberter Kampfhammer
227881	Gelassenheit
227882	Gurt der arkanen Einsicht
227883	Unterarmschienen der schnellen Flucht
227884	Tödlicher Herzsucher
227885	Festerungsstulpen
227886	Meisterlicher Sturmhammer des Himmelsreiters
227887	Gehärtete Frostwache
227888	Argentumeliteschultern
227895	Muster: Goldener Mantel der Dämmerung
227896	Muster: Argentumstiefel
227897	Muster: Argentumschultern
227898	Muster: Geschliffene blaue Drachenschuppenbrustplatte
227899	Muster: Geschliffene blaue Drachenschuppenschultern
227900	Muster: Lebende grüne Drachenschuppengamaschen
227901	Pläne: Getemperte Dunkeleisenplatte
227902	Muster: Gehärtete schwarze Drachenschuppenbrustplatte
227903	Muster: Gehärtete schwarze Drachenschuppengamaschen
227904	Muster: Gehärtete schwarze Drachenschuppenschultern
227905	Pläne: Meisterlicher Sturmhammer des Himmelsreiters
227906	Muster: Meisterhafte vulkanische Brustplatte
227907	Muster: Meisterhafte vulkanische Schultern
227908	Muster: Meisterhafte vulkanische Gamaschen
227909	Pläne: Feurige Plattenstulpen der verborgenen Technik
227910	Muster: Glänzender chromatischer Umhang
227911	Rend Schwarzfausts Kopf
227912	Angewandte Göttlichkeit
227914	Zirbeldrüse der Eulenbestie
227915	Reich des Herzogs
227921	Rune der Messer
227922	Rune des Schwadroneurs
227923	Wassertreter
227924	Ungewöhnliches Fläschchen
227925	Leuchtfeuer von Hydraxis
227926	Hydraxianische Krönung
227927	Schwur der See
227928	Werkzeugkastenschlüssel
227930	Tresorschlüssel
227931	Verstecktes Bündel
227932	Rostige Brechstange
227934	Flammenzorn
227935	Hammer des gefallenen Thans
227936	Diplomatenring
227937	Rätselkiste
227938	Scherbe des Lichts
227939	Scherbe des Lichts
227940	Schwert des Lordgenerals
227941	Gespenstersense
227947	Schulterstücke der Golempanzerung
227948	Zornesschmieds Streitaxt
227952	Wilde Gladiatorenkette
227955	Wilder Gladiatorenhelm
227956	Todesbotenbrustplatte
227957	Wilde Gladiatorenschienbeinschützer
227958	Geistertuch
227959	Beinplatten des ewigen Wächters
227960	Unempfindlicher Riese
227961	Wilder Gladiatorenhandschutz
227962	Flammendorn
227963	Blutgeätzte Klinge
227964	Lumineszierender Kilt
227965	Zauberverstärkende Stiefel
227967	Zweiter Wind
227970	Cape des Feuersalamanders
227971	Geschmolzene Fäuste
227972	Explosion des Wissens
227973	Reif der Flamme
227974	Hammer aus Lavagestein
227978	Magmusstein
227980	Roben der königlichen Krone
227981	Vergelter der Schicksalsschmiede
227982	Führungsstock der Weisheit
227983	Dunkeleisensiegel
227984	Thaurissans königliches Szepter
227985	Des Kaisers neuer Umhang
227986	Handgelenksschützer des Ruhms
227987	Schärpe der großen Jagd
227988	Imperiales Juwel
227990	Hand der Ungerechtigkeit
227991	Eisenfeind
227992	Todesrittersabatons
227993	Ebenholzheft von Marduk
227994	Gräuelschaft
227996	Uralter Knochenbogen
227997	Schwert der Familie Barov
227998	Blutpanzerstiefel
227999	Sabatons des Totenwächters
228000	Brustplatte des Totenwächters
228001	Steingestaltschultern
228002	Gurt des Totenwächters
228003	Blutpanzerbeinschützer
228004	Schienbeinschützer des Windhäschers
228005	Klammer von Andros
228006	Stulpen des Totenwächters
228007	Gargoyleschlitzer
228008	Beinschützer des Totenwächters
228009	Stiefel des Totenbeschwörers
228010	Mantel des Totenbeschwörers
228011	Manschetten des Totenbeschwörers
228012	Blutpanzerhalsberge
228013	Robe des Totenbeschwörers
228014	Blutpanzergürtel
228015	Schreckenskralle
228016	Leicht opalschimmernder Ring
228017	Schädelstaubhose
228018	Gamaschen des Totenbeschwörers
228019	Herz des Scheusals
228020	Blutpanzerstulpen
228021	Hexenklinge
228022	Attacke des Direktors
228023	Alannas Umarmung
228024	Stiller Fangzahn
228025	Grabsteinbrustplatte
228026	Klinge der Schwarzfelle
228027	Eisklingenaxt
228028	Klinge der Totenbeschwörung
228029	Grabsteinkriegsaxt
228030	Bösartige Streitaxt
228031	Handschuhe der dunklen Schatten
228032	Knochenringhelm
228033	Hammer der göttlichen Macht
228034	Fröstelnde Handlappen
228036	Todesklammer
228037	Schädelknochenschild
228038	Eisengewebte Hose
228039	Verzauberter Foliant
228040	Geistergamaschen
228041	Geisterplattenbeinlinge
228042	Festschnürungsgurt
228044	Mahlstromgamaschen
228045	Nekromantisches Band
228046	Don Mauricios Band der Herrschaft
228047	Amalgams Band
228050	Satyrbogen
228051	Kanalisierungsrute der Quel'dorai
228052	Wellenschnitzler
228053	Inbrünstiger Helm
228054	Sturmtalisman
228055	Energiegeladene Brustplatte
228056	Satanische Machete
228057	Ring der dämonischen Kraft
228058	Unförmige Eisenschiftung
228059	Baubehüters Schultern
228060	Heliotropenumhang
228061	Hellfunkenhandschuhe
228062	Erkenntnisreiche Kapuze
228063	Wucherborkenbindungen
228064	Schild des Beobachters
228065	Zyklonschiftung
228066	Eisengewebte Handschuhe
228067	Anhänger des Ältestenmagus
228068	Straßenräubergürtel
228069	Unheimliche Verstärkte Beinplatten
228070	Ogergeschmiedete Halsberge
228074	Hände der Verführung
228075	Speer des Schicksals
228076	Brennender Feuerring
228077	Traumzweig
228078	Verwünschter Kelch
228079	Blätterumhang
228080	Harzring
228081	Keimende Giftsaat
228082	Kriegshymnenaxt
228083	Sanft leuchtendes Baumherz
228084	Miniaturfeuerlöscher
228085	Phasenverschobenes Legionsband
228086	Umfunktionierte Schredderklinge
228087	Supergeladener Silbermöbius
228088	Schredderbedienermarke
228089	Holzgeschnitzter Mondpirscher
228090	Cenarischer Ritualdolch
228091	Dornenstiefel
228092	Druidenmantel
228093	Dunkles Herz der Dunkelheit
228094	Klinge des Schreckenslords
228100	Tuch des Feuerlords
228101	Pelz des Ungetüms
228102	Majordomus' Tuch
228103	Nathrezims Schienbeinschützer
228104	Roben von Elune
228105	Ewigbrennender Flammenkern
228106	Schild von Leben und Tod
228107	Langbogen der gefallenen Jägerin
228108	Schatten von Blutschrei
228109	Beinschützer der Aufopferung
228111	Maske des Göttertöters
228112	Alptraumgewand
228113	Kalte Umarmung
228114	Pläne: Veredelter Arkanitschnitter
228117	Pläne: Veredelter Arkanitchampion
228118	Pläne: Festerungsstulpen
228119	Muster: Teufelskernstulpen
228120	Muster: Teufelskerngamaschen
228121	Muster: Lederverstärkte Runenstofftasche
228122	Der Geschmolzene Kern
228123	Frohlockende Offenbarung
228124	Traumartige Offenbarung
228125	Veredelter Arkanitchampion
228126	Eröffnende Offenbarung
228127	Handgelenksschützer der Instabilität
228128	Hammer des schwarzen Amboss
228129	Schattenflammenschädel
228130	Altruistenschutz
228131	Altruistenschutz
228132	Untote Kartoffeln
228133	Magma oder Lava?
228134	Nordkalimdor - ein umfassender Reiseführer
228135	Eine Studie des Lichts
228136	Krabumm!
228137	Herz von Golemagg
228138	Der Ritter und die Dame
228139	Fäuste der Feueranbeter
228140	Die Geißel: Untote Plage oder bloß missverstanden?
228141	Einführung in die Nekromantie
228142	Erde und Feuer
228143	Schattenflammenschwert
228144	Seltsame Notiz
228145	Magmadars rechte Klaue
228146	Magmadars linke Klaue
228147	Magmadars Horn
228160	Glaubensbringer
228162	Verrat
228163	Brosche der Brutmutter
228165	Wurfspeer des Drachentöters
228166	Schlüssel zur Stadt
228168	Goblinischer Getriebeschleifer
228169	Der Haltungsanpasser
228170	Provisorisches Ruder für die südlichen Meere
228171	Kezanische Geldbörse
228172	Schattenzahnillusionsschutz
228173	Buchband der Geweihten
228174	Buchband der Ergebenen
228175	Buchband des heiligen Eifers
228176	Totem des Donners
228177	Totem des wütenden Feuers
228178	Totem der irdenen Vitalität
228179	Totem der Ebenen
228180	Götze des Schwarms
228181	Götze der Schächtung (Katze)
228182	Götze der Schächtung (Bär)
228183	Götze des Hains
228184	Goblinwäscheleine
228185	Zerbrochene Flasche Goblino Noir
228186	Zurückgelassener Trauring
228187	Stock der südlichen Meere
228188	Prestors Haarnadel
228189	Gabe des Klumpen
228190	Wissen der Holzschlundfeste
228191	Schimmerndes geschmolzenes Mineral
228222	Handbuch der Ehre von Azeroth
228227	Scroll of Overwhelming Power
228229	Scharfkantige Obsidianklinge
228230	Veredelter Hammer der Titanen
228239	Robe der flüchtigen Macht
228240	Feuerschuppenbeinplatten
228242	Schwerer Dunkeleisenring
228243	Ring der Zaubermacht
228244	Gamaschen des Manasturms
228245	Salamanderschuppengamaschen
228246	Handgelenksschützer der Stabilität
228247	Halsreif der Erleuchtung
228248	Erderschütterer
228249	Medaillon der beständigen Macht
228250	Pläne: Festerungsstulpen
228251	Muster: Lebende grüne Drachenschuppenstulpen
228252	Mal des Schlägers
228253	Sabatons des Flammenwandlers
228254	Magmagehärtete Stiefel
228255	Talisman der ephemeren Macht
228256	Mana entfachende Kordel
228257	Alte Kernlederhandschuhe
228258	Tiefenerdschiftung
228259	Feuerrunenverzierter Zauberfoliant
228260	Flammenwächterstulpen
228261	Ring des rasanten Schlags
228262	Purpurroter Schocker
228263	Zauberdolch
228264	Aurasteinhammer
228265	Unbarmherzige Klinge
228266	Drillbohrerscheibe
228267	Räuderipper
228268	Siegel des Erzmagiers
228269	Magierklinge des Azurlieds
228270	Blasterwerfer
228271	Stab der Dominanz
228272	Schattenschlag
228273	Donnerschlag
228274	Band der Ausbrennung
228275	Im Kern geschmiedete Schienbeinschützer
228276	Muster: Meisterlich gefertigter unbeständiger Umhang
228277	Kernhundzahn
228278	Überwärmter Isolierlavagreifer
228279	Brandwachenschultern
228280	Feuerfester Umhang
228281	Handschuhe der hypnotischen Flamme
228282	Schärpe der geflüsterten Geheimnisse
228283	Schiftung des wilden Wachstums
228284	Handgelenksschützer des wahren Flugs
228285	Helm des Lebensspenders
228286	Band von Accuria
228287	Band von Sulfuras
228288	Knochenhäschers Schneide
228289	Kropfband des Feuerlords
228290	Umhang der verhüllten Nebel
228291	Krone der Zerstörung
228292	Drachenblutcape
228293	Essenz der reinen Flamme
228294	Malistars Verteidiger
228295	Gurt des Ansturms
228296	Klinge des Verderbens
228297	Splitter der Flamme
228298	Splitter der Schuppe
228299	Rückgratschnitter
228301	Muster: Unterarmschienen der schnellen Flucht
228303	Muster: Gleißende Mondstoffrobe
228304	Bauplan: Feuerkern-Scharfschützengewehr
228305	Pläne: Veredelter Hammer der Titanen
228306	Pläne: Entweihung
228307	Pläne: Tödlicher Herzsucher
228308	Pläne: Gelassenheit
228309	Muster: Lebende grüne Drachenschuppenbrustplatte
228310	Pläne: Gehärtete Frostwache
228311	Pläne: Sorgsam verzauberter Kampfhammer
228312	Pläne: Unverwundbarer Panzer
228313	Pläne: Sturmstulpen
228314	Pläne: Kriegswappen des großen Häuptlings
228315	Pläne: Weisenklinge des Erzmagiers
228316	Muster: Gleißende Mondstoffweste
228317	Muster: Gleißender Mondstoffreif
228318	Muster: Gleißende Mondstoffgamaschen
228319	Muster: Gurt der arkanen Einsicht
228323	Kupferschlachtmünze
228324	Goldschlachtmünze
228325	Silberschlachtmünze
228326	Säckchen mit Kupferschlachtmünzen
228327	Säckchen mit Silberschlachtmünzen
228332	Lok'delar, Stab der uralten Bewahrer
228334	Rhok'delar, Langbogen der uralten Bewahrer
228335	Segnung
228336	Bannfluch
228340	Nieschmelzender Eisgurt
228345	Beinlinge der arkanen Überlegenheit
228347	Taifun
228349	Eskhandars linke Klaue
228350	Eskhandars rechte Klaue
228351	Verdammnisstulpen
228352	Teufelserfüllte Gamaschen
228353	Infernalischer Hirnkasten
228354	Medaillon des lodernden Zorns
228355	Zerschundener Verdammniswachengürtel
228356	Bewahrer des Bernsteinsiegels
228357	Schwarzflammenarmschienen
228359	Ring der Entropie
228360	Eskhandars Pelz
228381	Kälteeinbruch
228382	Fangzahn der Mystiker
228383	Schlagfertiges Cape
228384	Schneeblindschuhe
228385	Kristallverzierte Krone
228389	Tuch der Segnung
228397	Verwüster des Lichthimmels
228410	Schreckensklinge des Zerstörers
228432	Pfeife des Tieres
228459	Scharfkantige Obsidianklinge
228460	Rückgratschnitter
228461	Knochenhäschers Schneide
228462	Aurasteinhammer
228463	Erderschütterer
228464	Königliches Siegel von Eldre'Thalas
228465	Königliches Siegel von Eldre'Thalas
228466	Königliches Siegel von Eldre'Thalas
228467	Königliches Siegel von Eldre'Thalas
228468	Wirrmoosbeinlinge
228469	Angelaufener Elfenring
228470	Silbermondbeinlinge
228471	Steinzertrümmerer
228472	Ablenkender Dolch
228473	Unerschütterlicher Schlägel
228474	Gedankenschwallrobe
228475	Diabolischer Mantel
228476	Bestickter Gürtel des Erzmagiers
228477	Muster: Bestickter Gürtel des Erzmagiers
228478	Barbarische Klinge
228479	Beinlinge der Zerstörung
228480	Krone des Ogerkönigs
228484	Rute des Ogermagiers
228486	Verderben der Treants
228498	Schreckensklinge des Zerstörers
228500	Maske des Unverziehenen
228501	Singvogelbluse
228502	Pikkolo des Flammenfeuers
228503	Wollwäsche des tänzelnden Spielmanns
228504	Regenbogengurt
228505	Königlicher Tribunalumhang
228506	Unbarmherzige Klinge
228508	Hammer des schwarzen Amboss
228511	Klinge des Verderbens
228513	Unterarmschienen des Sadisten
228514	Timmys Galoschen
228515	Grimmblutschlinge
228516	Friedensstifter
228517	Magierklinge des Azurlieds
228518	Handschellen des Magistrats
228519	Mal des Schlägers
228520	Mantel des Seelendiebs
228521	Schattenhafte geschnürte Handlappen
228522	Willeys tragbare Haubitze
228523	Kanonenkugelläufer
228524	Siegel des Postmeisters
228525	Tunika des Postmeisters
228527	Beinkleider des Postmeisters
228528	Band des Postmeisters
228529	Treter des Postmeisters
228530	Chitinplattenbeinschützer
228531	Thuzadinschärpe
228532	Morlunes Armschienen
228533	Perlmuttmuschelhalskette
228534	Seuchenhundbeinlinge
228535	Knochenzersplitterndes Kriegsbeil
228536	Stern von Mystaria
228537	Dracorianische Stulpen
228538	Siegel von Totenschwur
228539	Buch der Toten
228540	Krone der Tyrannei
228541	Gabe der Elfenmagier
228542	Häscher der Schädelesse
228543	Runenklinge von Baron Totenschwur
228544	Hammer des obersten Kreuzzüglers
228545	Helm des obersten Kreuzzüglers
228546	Schleier der Nathrezim
228547	Eisengewebte Robe
228548	Szepter der grenzenlosen Konzentration
228551	Tunika des Sichelmonds
228552	Stulpen des Geschicks
228553	Helm des Henkers
228554	Dämonenhauthandschuhe
228555	Phasenklinge
228556	Metzgerschürze
228557	Kampfstiefel der Pfeilschnelle
228558	Begräbnismanschetten
228559	Schwarzkrähe
228561	Stulpen des Bogenmeisters
228562	Dämonische runenverzierte Schiftung
228563	Kugel von D'sak
228564	Ogerseherturmstiefel
228565	Magusring
228566	Tiara des Sternenfeuers
228567	Beitelmalgurt
228568	Backusarische Stulpen
228570	Omokks Faust
228571	Platte des Schamanenkönigs
228572	Glutbandarmschützer
228573	Giftspucker
228574	Talisman des Entrinnens
228575	Wolfsklauenarmschienen
228576	Glimmernetz' Auge
228577	Güldene Stulpen
228578	Staubfederschärpe
228579	Kristallisierter Gurt
228583	Schultern der Treffsicherheit
228584	Talisman des glühenden Zorns
228585	Mal des Drachenlords
228586	Kaltpike
228587	Stab von Trindelhafen
228588	Reiverklauen
228589	Herz der Schuppe
228590	Mantel des blinden Sehers
228591	Rhombusbeschützer
228592	Fangzahn der Kristallspinne
228593	Stiefel des Windtänzers
228594	Kaysers Stiefel der Präzision
228595	Schützengurt
228596	Eisengewebter Gürtel
228597	Eisengewebte Stiefel
228598	Eisengewebte Armschienen
228599	Herz von Wyrmthalak
228600	Der Kieferknacker
228601	Unerbittliche Sense
228602	Flammenläufer
228603	Schwarzfausts Verdammnissäge
228604	Auge von Rend
228605	Knochenstachelschulter
228606	Schwarzklinge von Shahram
228615	Überirdischer Schatz
228650	Kriegsmeisterbeinschützer
228651	Armstützen des Schlachtgetauften
228652	Dal'Rends Stammeswächter
228653	Dal'Rends hochheilige Attacke
228659	Antiker runenverzierter Stab
228660	Klingenmeistergamaschen
228661	Tristambeinschützer
228662	Armschützer des schwarzen Nebels
228663	Blutmondumhang
228664	Winterzwirncape
228666	Sickernde Weide
228667	Schmerzenswirkerband
228669	Zahn des Gnarr
228670	Brigamgurt
228672	Handgefertigter Meisterschmiedgurt
228675	Band des Nachsinnens
228676	Gurt der brennenden Wut
228677	Spruchwirkerturban
228678	Emblem der drachischen Macht
228679	Quel'Serrar
228680	Nostros Kompendium des Drachentötens
228681	Eisengewebte Gugel
228682	Lord Valthalaks Befehlsstab
228683	Runenband der Zauberei
228684	Anhänger der Schnelligkeit
228685	Zahn Onyxias
228686	Talisman mit Onyxiablut
228687	Drachentötersignet
228688	Onyxias Kopf
228689	Onyxias Kopf
228690	Vom Licht und wie man es schwingt
228691	Garona: Eine Studie über Heimlichkeit und Verrat
228692	Kodex der Verteidigung
228693	Das Arkanistenkochbuch
228695	Eine stumpfe und glanzlose Elfenklinge
228696	Erhitzte uralte Klinge
228697	Behandelte uralte Klinge
228699	Ring der dämonischen List
228700	Eisengewebter Mantel
228701	Kernhundzahn
228702	Drillbohrerscheibe
228703	Froststeinschuhe
228704	Zerlumpte Lederkapuze
228722	Hand der Gerechtigkeit
228746	Leuchtend grüner Roboschreiter
228747	Zügel der goldenen Säblerkatze
228748	Pfeife des scheckigen Blutraptors
228749	Splitter von Nordrassil
228757	Teufelsstoß
228759	Eskhandars Halsband
228797	Zauberfoliant der Teufelsrüstung
228912	Artefaktlagertruhenschlüssel
228922	Stab der Dominanz
228924	Getemperte Dunkeleisenstiefel
228925	Getemperte Dunkeleisenstiefel
228926	Getemperte Dunkeleisenstiefel
228927	Getemperte Dunkeleisenstiefel
228928	Getemperte Dunkeleisenstiefel
228929	Getemperte Dunkeleisenstiefel
228955	Zauberfoliant des uralten Grundsteins
228978	Verzaubertes Siegel: Fließendes Wasser
228979	Verzaubertes Siegel: Fließendes Wasser
228980	Leitende Schildbeschichtung
228981	Formel: Leitende Schildbeschichtung
228982	Formel: Schild - Naturgesetz
228992	Rucksack aus Onyxias Haut
228993	Muster: Bodenlose Tasche
228994	Bodenlose Tasche
229008	Formel: Umhang - Großer Feuerwiderstand
229009	Formel: Umhang - Großer Naturwiderstand
229055	Ausgefranste Aranasiseide
229056	Bimssteinbrocken
229057	Beschlagnahmte Güter
229352	Informationserkenntnisse
229362	Lagerhausschlüssel
229372	Räuderipper
229373	Glaubensbringer
229374	Fäuste der Feueranbeter
229376	Zauberdolch
229377	Magmadars linke Klaue
229378	Magmadars rechte Klaue
229379	Eskhandars rechte Klaue
229380	Schattenschlag
229381	Donnerschlag
229382	Überwärmter Isolierlavagreifer
229415	Überlebensvorräte
229416	Warmes Fell
229749	Wahrheitsbringer
229806	Wahrheitsbringer
229894	Traumsmaragd
229897	Rolle: Siegel der Anrufung herstellen
229906	Trübe Bronzeschuppe
229909	Stab der Ordnung
229910	Sense des Chaos
229911	Caius' Traumfresser
229964	Huf eines Dämonenlords
229965	Das Auge von Az'olgothal
229966	Halsreif der Silbernen Hand
229971	Stab des Infernos
229972	Stab des Raureifs
230002	Tödlicher Vollender
230018	Kugelfragmente der Mannoroc
230224	Donnerzorn, gesegnete Klinge des Windsuchers
230237	Edelstein der arkanen Kraft
230238	Das schwarze Buch
230239	Handschuhe der rapiden Evolution
230240	Mantel der Pechschwingenkabale
230241	Wirbelsäulenbrecher
230242	Die ungezähmte Klinge
230243	Edelstein des Gedankensprungs
230244	Siegel des Gestaltwandlers
230245	Anhänger des gefallenen Drachen
230246	Helm der unendlichen Rage
230247	Drachenzahnklinge
230248	Roter Drachenschuppenbeschützer
230249	Lebensspendender Edelstein
230250	Gifttotem
230251	Schultern der schwarzen Brut
230252	Armschienen der arkanen Präzision
230253	Herzensbrecher
230254	Maladath, runenverzierte Klinge des schwarzen Drachenschwarms
230255	Gehärteter Drachenledergürtel
230256	Drachenkrallenschulterstücke
230257	Ring des Blackrock
230269	Edelstein der Verjüngung
230270	Fokussierstab der Schattenschwingen
230271	Drachenkrallenbeil
230272	Rollen des blendenden Lichts
230273	Kristall der Naturverbundenheit
230274	Schwarzaschenrobe
230275	Feuerschwingens Griff
230276	Klaue des Schwarzdrachen
230277	Feuerschwingens Umhang
230278	Beinschützer des gefallenen Kreuzfahrers
230279	Gekettelte Beinschützer des Primalisten
230280	Aegis der Bewahrung
230281	Band der erzwungenen Konzentration
230282	Drachenzahntalisman
230723	Ebenholzfarbene Flammenhandschuhe
230725	Malfurions gesegnetes Bollwerk
230726	Drachenodemhandkanone
230733	Schleier des reinen Gedankens
230734	Kreis der angewandten Macht
230735	Sandzwirngamaschen
230736	Styleens verhindernder Skarabäus
230737	Berührung des Drachen
230738	Herold des Leidens
230739	Angelistas Gespür
230740	Gehärtete Drachenlederschulterpolster
230741	Chromatische Stiefel
230742	Gehärtete Drachenlederhandschuhe
230743	Schimmernde Getas
230744	Elementiumdurchwirkter Umhang
230745	Gurt des gefallenen Kreuzfahrers
230746	Energieerfüllte Gamaschen
230747	Chromatisch gehärtetes Schwert
230751	Ninjaobi
230794	Klaue von Chromaggus
230800	Gekettelter Taillenschutz des Primalisten
230801	Ashjre'thul, Armbrust der Pein
230802	Elementiumverstärktes Bollwerk
230804	Umhang des Brutlords
230805	Stiefel der Schattenflamme
230806	Therazanes Zusammenhalt
230808	Archimtiros' Ring der Abrechnung
230810	Neltharions Träne
230811	Band aus reinem Elementium
230812	Mish'undare, Reif des Gedankenschinders
230813	Stab der Schattenflamme
230818	Ashkandi, Großschwert der Bruderschaft
230837	Crul'shorukh, Schneide des Chaos
230838	Lok'amir il Romathis
230839	Ring des Meisterdrachentöters
230840	Medaillon des Meisterdrachentöters
230841	Kugel des Meisterdrachentöters
230842	Umhang der drakonischen Macht
230843	Stiefel des reinen Gedankens
230844	Drachischer Schlägel
230845	Schneide der Verdammnis
230846	Band der dunklen Herrschaft
230847	Essenzsammler
230848	Geflochtener Schattenwams
230849	Ringos Blizzardstiefel
230854	Band der Knechtschaft
230855	Siegel des Gurubashiberserkers
230856	Gürtel der unversehrten Kraft
230857	Blutdurchnässte Maske
230858	Umhang der Hakkarianbeter
230859	Handschuhe der Gequälten
230860	Macht der Stämme
230861	Opferstulpen
230862	Zulianischer Kopfputz
230863	Zulianisches Szepter der Riten
230864	Blutbefleckte runenverzierte Halsberge
230865	Fangzahn von Venoxis
230866	Blutdurchnässte Fußpolster
230867	Zanzils Band
230868	Zulianische Steinaxt
230903	Schriftrolle: Essenz des Feuers
230904	Schriftrolle: SENZES SED RUESEF
230908	Erfüllte Essenz des Feuers
230909	Erschöpfte Essenz des Feuers
230911	Jekliks Zermalmer
230912	Schiftung des Animisten
230913	Jekliks opaliner Talisman
230914	Stiefel des Friedensbewahrers
230915	Band des Primalisten
230916	Meeresfurienstiefel
230917	Fließende Ritualroben
230918	Mar'lis Berührung
230919	Blutbefleckte Schienbeinschützer
230920	Mar'lis Auge
230921	Jins Band
230922	Talisman des Schutzes
230923	Stiefel des Verräters
230925	Thekals Griff
230926	Gamaschen des Friedensbewahrers
230927	Rituelle Beinschützer
230928	Meeresfuriengamaschen
230929	Siegel von Jin
230930	Zulianischer Schnitzler
230934	Arlokks Griff
230939	Wille Arlokks
230941	Arlokks Hoodoostecken
230942	Blutgetränkte Schienbeinschützer
230943	Onyxband des Oberherren
230944	Pantherbalgsack
230946	Schriftrolle: SENZES SED SEROFTS
230947	Schriftrolle: Essenz des Frostes
230948	Erfüllte Essenz des Frostes
230949	Erschöpfte Essenz des Frostes
230984	Unvollständiger Stab der Ordnung
230989	Verteidiger des Blutfürsten
230991	Hellebarde der Pein
230992	Kriegsklinge der Hakkari
230993	Mandokirs Stachel
230994	Gamaschen des Animisten
230995	Blutdurchnässter Handschutz
230996	Blutgetränkte Schulterstücke
230997	Blutverschmierter Kilt
230998	Loaumhang der Hakkari
230999	Purpurrotes Band des Oberherren
231000	Siegel des Primalisten
231001	Zanzils Siegel
231002	Jin'dos Verhexer
231003	Jin'dos Auge des Bösen
231004	Jin'dos Richturteil
231005	Jin'dos Beutel der Verdammnis
231006	Stiefel des Animisten
231007	Blutbefleckte Helmkappe
231008	Blutbefleckte Beinplatten
231009	Blutdurchnässte Gamaschen
231010	Blutgetränkte Stulpen
231011	Blutverschmierte Handschuhe
231012	Umarmung des Oberherren
231013	Bedeckung des Verhexers
231014	Echsenschuppenaugenklappe
231015	Twillmaske
231016	Nat Pagles Fischterminator
231023	Handgelenksschützer des Zorns
231024	Taillenschutz des Zorns
231025	Schulterstücke des Zorns
231026	Beinschützer des Zorns
231027	Gesichtsschutz des Zorns
231028	Handschützer des Zorns
231029	Sabatons des Zorns
231030	Brustschutz des Zorns
231031	Armschienen des Zorns
231032	Gürtel des Zorns
231033	Schultern des Zorns
231034	Beinplatten des Zorns
231035	Helm des Zorns
231036	Stulpen des Zorns
231037	Schienbeinschützer des Zorns
231038	Brustplatte des Zorns
231039	Blutfangschiftung
231040	Blutfangbrustharnisch
231041	Blutfangstiefel
231042	Blutfanghandschuhe
231043	Blutfangkapuze
231044	Blutfanghose
231045	Blutfanggürtel
231046	Blutfangarmschienen
231047	Blutfangschulterpolster
231048	Blutfangbrustschutz
231049	Blutfangfußpolster
231050	Blutfanghandschützer
231051	Blutfanggugel
231052	Blutfangbeinschützer
231053	Blutfangtaillenschutz
231054	Blutfanghandgelenksschützer
231055	Armschienen des Drachenjägers
231056	Gürtel des Drachenjägers
231057	Schiftung des Drachenjägers
231058	Beinschützer des Drachenjägers
231059	Helm des Drachenjägers
231060	Stulpen des Drachenjägers
231061	Schienbeinschützer des Drachenjägers
231062	Brustplatte des Drachenjägers
231063	Unterarmschienen des Drachenjägers
231065	Gurt des Drachenjägers
231066	Schulterstücke des Drachenjägers
231067	Hose des Drachenjägers
231068	Schädelkappe des Drachenjägers
231069	Handschutz des Drachenjägers
231070	Sabatons des Drachenjägers
231071	Rüstung des Drachenjägers
231072	Stiefel der Nemesis
231073	Handschuhe der Nemesis
231074	Schädelkappe der Nemesis
231075	Gamaschen der Nemesis
231076	Roben der Nemesis
231077	Schiftung der Nemesis
231078	Gürtel der Nemesis
231079	Armschienen der Nemesis
231090	Treter der Nemesis
231091	Handschützer der Nemesis
231092	Gugel der Nemesis
231093	Hosen der Nemesis
231095	Kluft der Nemesis
231096	Schulterpolster der Nemesis
231097	Kordel der Nemesis
231098	Wickel der Nemesis
231100	Gürtel des Netherwinds
231101	Stiefel des Netherwinds
231102	Handschuhe des Netherwinds
231103	Krone des Netherwinds
231104	Hose des Netherwinds
231105	Roben des Netherwinds
231106	Mantel des Netherwinds
231107	Bindungen des Netherwinds
231108	Schärpe des Netherwinds
231109	Pantoffeln des Netherwinds
231110	Fäustlinge des Netherwinds
231111	Maske des Netherwinds
231112	Gamaschen des Netherwinds
231113	Gewänder des Netherwinds
231114	Schultern des Netherwinds
231115	Wickel des Netherwinds
231155	Stiefel der Erhabenheit
231156	Handschützer der Erhabenheit
231157	Heiligenschein der Erhabenheit
231158	Gamaschen der Erhabenheit
231159	Roben der Erhabenheit
231160	Schulterstücke der Erhabenheit
231161	Gürtel der Erhabenheit
231162	Bindungen der Erhabenheit
231165	Treter der Erhabenheit
231166	Handschuhe der Erhabenheit
231167	Krone der Erhabenheit
231168	Hose der Erhabenheit
231169	Kluft der Erhabenheit
231170	Mantel der Erhabenheit
231171	Kordel der Erhabenheit
231172	Armschienen der Erhabenheit
231174	Bindungen des Richturteils
231175	Gürtel des Richturteils
231176	Schiftung des Richturteils
231177	Beinplatten des Richturteils
231178	Krone des Richturteils
231179	Stulpen des Richturteils
231180	Sabatons des Richturteils
231181	Brustplatte des Richturteils
231182	Unterarmschienen des Richturteils
231183	Taillenschutz des Richturteils
231184	Schulterstücke des Richturteils
231185	Beinschützer des Richturteils
231186	Großhelm des Richturteils
231187	Brustschutz des Richturteils
231188	Handschützer des Richturteils
231189	Schienbeinschützer des Richturteils
231190	Armschienen des Richturteils
231191	Gurt des Richturteils
231192	Mantel des Richturteils
231193	Plattenrock des Richturteils
231194	Helm des Richturteils
231195	Handschuhe des Richturteils
231196	Treter des Richturteils
231197	Kürass des Richturteils
231198	Stulpen der zehn Stürme
231199	Armschienen der zehn Stürme
231200	Gürtel der zehn Stürme
231201	Schulterklappen der zehn Stürme
231202	Beinplatten der zehn Stürme
231203	Helm der zehn Stürme
231204	Schienbeinschützer der zehn Stürme
231205	Brustplatte der zehn Stürme
231206	Handschützer der zehn Stürme
231207	Handgelenksschützer der zehn Stürme
231208	Taillenschutz der zehn Stürme
231209	Schulterklappen der zehn Stürme
231210	Beinschützer der zehn Stürme
231211	Gesichtsschutz der zehn Stürme
231212	Sabatons der zehn Stürme
231213	Brustschutz der zehn Stürme
231214	Handschuhe der zehn Stürme
231215	Bindungen der zehn Stürme
231216	Kordel der zehn Stürme
231217	Mantel der zehn Stürme
231218	Rock der zehn Stürme
231219	Kopfputz der zehn Stürme
231220	Stiefel der zehn Stürme
231221	Umarmung der zehn Stürme
231222	Handschutz der zehn Stürme
231223	Unterarmschienen der zehn Stürme
231224	Gurt der zehn Stürme
231225	Schiftung der zehn Stürme
231226	Gamaschen der zehn Stürme
231227	Krone der zehn Stürme
231228	Treter der zehn Stürme
231229	Rüstung der zehn Stürme
231230	Brustschutz des Stormrage
231231	Stiefel des Stormrage
231232	Handschützer des Stormrage
231233	Bedeckung des Stormrage
231234	Beinschützer des Stormrage
231235	Schulterstücke des Stormrage
231236	Gürtel des Stormrage
231237	Armschienen des Stormrage
231238	Rüstung des Stormrage
231239	Treter des Stormrage
231240	Stulpen des Stormrage
231241	Kopfputz des Stormrage
231242	Gamaschen des Stormrage
231243	Schiftung des Stormrage
231244	Taillenschutz des Stormrage
231245	Handgelenksschützer des Stormrage
231246	Leder des Stormrage
231247	Sandalen des Stormrage
231248	Fäustlinge des Stormrage
231249	Geweih des Stormrage
231250	Rock des Stormrage
231251	Mantel des Stormrage
231252	Kordel des Stormrage
231253	Bindungen des Stormrage
231254	Weste des Stormrage
231255	Stampfer des Stormrage
231256	Handschutz des Stormrage
231257	Gugel des Stormrage
231258	Hose des Stormrage
231259	Schulterpolster des Stormrage
231260	Schärpe des Stormrage
231261	Wickel des Stormrage
231271	Nat Pagles kaputte Spule
231272	Tigules Harpune
231273	Gri'leks Schnitzer
231274	Gri'leks Schleifer
231275	Heimzahler des lodernden Zorns
231276	Gedankenvernichter
231277	Heugabel des Wahnsinns
231278	Hoodoojagdbogen
231279	Wushoolays Schüreisen
231280	Wushoolays Amulett der Natur
231281	Wushoolays Amulett der Geister
231282	Hazza'rahs Amulett der frostigen Magie
231283	Hazza'rahs Amulett des Schutzes
231284	Hazza'rahs Amulett der Zerstörung
231285	Gri'leks Amulett der Ehre
231286	Gri'leks Amulett der Macht
231287	Renatakis Amulett der Gaunerei
231288	Renatakis Amulett des Wütens
231289	Aegis des Blutgottes
231293	Uralter Menschentöter der Hakkari
231296	Blutrufer
231298	Schriftrolle der geringen räumlichen Heilung
231299	Blutgetränkte Beinplatten
231300	Umhang der Verzehrung
231301	Fangzahn des Gesichtslosen
231302	Zwergenzerstörer der Gurubashi
231303	Stulpen des Friedensbewahrers
231304	Schriftrolle: NERGEIG MURÄCHILE GELIHUN
231305	Meeresfurienstulpen
231306	Halskette des Seelenverderbers
231307	Das Auge von Hakkar
231308	Berührung des Chaos
231309	Kriegsklinge der Hakkari
231315	Zin'rokh der Weltenzerstörer
231316	Reiner verzauberter Südmeertang
231317	Haruspex' Zandalaritunika
231318	Haruspex' Zandalarigürtel
231319	Haruspex' Zandalariarmschienen
231320	Mahlstroms Zorn
231321	Mantel des Zandalariraubtiers
231322	Gürtel des Zandalariraubtiers
231323	Armschienen des Zandalariraubtiers
231324	Juwel von Kajaro
231325	Mantel des Zandalari-Illusionisten
231326	Handlappen des Zandalari-Illusionisten
231327	Robe des Zandalari-Illusionisten
231328	Emblem des Helden
231329	Brustplatte des Zandalarifreidenkers
231330	Gürtel des Zandalarifreidenkers
231331	Armschützer des Zandalarifreidenkers
231332	Das allsehende Auge von Zuldazar
231333	Mantel des Zandalariglaubenshüters
231334	Bindungen des Zandalariglaubenshüters
231335	Handlappen des Zandalariglaubenshüters
231336	Zandalarischattentalisman der Beherrschung
231337	Tunika des Zandalariwildfangs
231338	Mantel des Zandalariwildfangs
231339	Armschienen des Zandalariwildfangs
231340	Unversehrte Vision von Voodress
231341	Halsberge des Zandalariweissagers
231342	Gürtel des Zandalariweissagers
231343	Armschienen des Zandalariweissagers
231346	Kezans unaufhaltsame Schmach
231347	Handlappen des Zandalaribesessenen
231348	Robe des besessenen Zandalari
231349	Mantel des Zandalaribesessenen
231350	Wut Mugambas
231351	Armschützer des Zandalarivollstreckers
231352	Gürtel des Zandalarivollstreckers
231353	Brustplatte des Zandalarivollstreckers
231354	Liebkosung des Animisten
231355	Gleichgewicht des Animisten
231357	Jähzorn des Animisten
231358	Brüllen des Animisten
231359	Ruf des Falken
231361	Siegel des Synkretisten
231362	Siegelzeichen des Synkretisten
231363	Wappen des Synkretisten
231364	Emblem des Synkretisten
231366	Prophetische Aura
231367	Prophetischer Fluch
231368	Umarmung des Todes
231370	Vorstoß des Todes
231371	Vodouisants Umarmung
231372	Vodouisants Schleier
231373	Vodouisants Amulett
231375	Vodouisants Wachsamkeit
231376	Verhexung des Hoodoo
231377	Fluch des Hoodoo
231378	Schimmernde goldene Scheibe
231379	Präsenz der Macht
231381	Präsenz der Tapferkeit
231382	Gefäß der Wiedergeburt
231383	Allgegenwärtige Sicht
231384	Furor des Falken
231385	Simulakrum der Drachenseele
231386	Makellose schwarze Drachenschuppe
231387	Sturmzorn, geheiligte Kurzklinge des Windsuchers
231452	Blut des Lichtbringers
231460	Ebenenbrecher von Azgaloth
231466	Kodex des Pechschwingenhexenmeisters
231509	Cassandras Foliant
231512	Urzeitlicher Hakkarigötze
231513	Gri'leks Blut
231514	Renatakis Zahn
231515	Wushoolays Mähne
231516	Hazza'rahs Traumfaden
231517	Durchstochene Voodoopuppe
231518	Durchstochene Voodoopuppe
231519	Durchstochene Voodoopuppe
231520	Durchstochene Voodoopuppe
231521	Durchstochene Voodoopuppe
231522	Durchstochene Voodoopuppe
231523	Durchstochene Voodoopuppe
231524	Durchstochene Voodoopuppe
231525	Durchstochene Voodoopuppe
231530	Plattenrüstung des Kriegsfürsten
231531	Plattenstiefel des Kriegsherrn
231532	Plattenstulpen des Kriegsherrn
231533	Plattengamaschen des Kriegsherrn
231534	Plattenschultern des Kriegsfürsten
231535	Plattenkopfstück des Kriegsfürsten
231536	Plattenrüstung des Feldmarschalls
231537	Plattenschulterschutz des Feldmarschalls
231538	Plattenhelm des Feldmarschalls
231539	Plattenstiefel des Marschalls
231540	Plattenbeinschützer des Marschalls
231541	Plattenstulpen des Marschalls
231543	Lederner Brustharnisch des Feldmarschalls
231544	Lederner Handschutz des Marschalls
231545	Lederne Maske des Feldmarschalls
231546	Lederne Fußschützer des Marschalls
231547	Lederne Schulterklappen des Feldmarschalls
231548	Lederne Gamaschen des Marschalls
231549	Lederbrustplatte des Kriegsfürsten
231551	Lederschiftung des Kriegsfürsten
231552	Ledertreter des Kriegsherrn
231553	Lederhelm des Kriegsfürsten
231554	Lederbeinschützer des Kriegsherrn
231555	Lederfäustlinge des Kriegsherrn
231557	Kettenschulterstücke des Feldmarschalls
231558	Kettenbeinplatten des Marschalls
231560	Kettenhandschutz des Marschalls
231561	Kettensabatons des Marschalls
231562	Kettengroßhelm des Feldmarschalls
231563	Kettenrüstung des Großmarschalls
231564	Kettensabatons des Kriegsherrn
231565	Kettenschulterstücke des Kriegsfürsten
231566	Kettenrüstung des Kriegsfürsten
231567	Kettenbeinplatten des Kriegsherrn
231568	Kettengroßhelm des Kriegsfürsten
231569	Kettenhandschutz des Kriegsherrn
231570	Kettenbeinschienbeinschützer des Kriegsherrn
231571	Kettenhelm des Kriegsfürsten
231572	Kettenschultern des Kriegsfürsten
231573	Kettenhalsberge des Kriegsfürsten
231574	Kettenbeinschützer des Kriegsherrn
231575	Kettenklemmen des Kriegsherrn
231576	Kettenschultern des Feldmarschalls
231577	Kettenbeinschützer des Marschalls
231578	Kettenklemmen des Marschalls
231579	Kettenschienbeinschützer des Marschalls
231580	Kettenhelm des Feldmarschalls
231581	Kettenhalsberge des Feldmarschalls
231582	Schreckenszwirnrobe des Feldmarschalls
231583	Schreckenszwirnschultern des Feldmarschalls
231584	Koronale des Feldmarschalls
231585	Schreckenszwirnstiefel des Marschalls
231586	Schreckenszwirnhandschuhe des Marschalls
231587	Schreckenszwirngamaschen des Marschalls
231588	Schreckenszwirnhose des Kriegsherrn
231589	Schreckenszwirnhandschuhe des Kriegsherrn
231590	Schreckenszwirnkapuze des Kriegsfürsten
231591	Schreckenszwirnrobe des Kriegsfürsten
231592	Schreckenszwirnmantel des Kriegsfürsten
231593	Schreckenszwirnstiefel des Kriegsherrn
231594	Seidene Amicia des Kriegsfürsten
231595	Seidene Beinkleider des Kriegsherrn
231596	Seidene Gewandung des Kriegsfürsten
231597	Seidene Stiefel des Kriegsherrn
231598	Seidene Handschuhe des Kriegsherrn
231599	Seidene Stulpen des Kriegsherrn
231600	Seidene Handlappen des Kriegsherrn
231601	Seidene Gugel des Kriegsfürsten
231602	Seidene Schiftung des Feldmarschalls
231603	Seidene Tracht des Feldmarschalls
231604	Kronenreif des Feldmarschalls
231605	Seidene Gamaschen des Marschalls
231606	Seidene Fußlappen des Marschalls
231607	Seidene Handschuhe des Marschalls
231608	Seidene Stulpen des Marschalls
231609	Seidene Handlappen des Marschalls
231610	Satintreter des Kriegsherrn
231611	Satinschulterklappen des Kriegsfürsten
231612	Satinroben des Kriegsfürsten
231613	Satinhandschutz des Kriegsherrn
231614	Satingamaschen des Kriegsherrn
231615	Satinkrone des Kriegsfürsten
231616	Satinkrone des Feldmarschalls
231617	Satinhandschutz des Marschalls
231618	Satinroben des Feldmarschalls
231619	Satingamaschen des Marschalls
231620	Satintreter des Marschalls
231621	Satinschulterklappen des Feldmarschalls
231622	Satinkapuze des Feldmarschalls
231623	Satinhandlappen des Marschalls
231624	Satintunika des Feldmarschalls
231626	Satinbeinschützer des Marschalls
231627	Satinlaufschuhe des Marschalls
231628	Satinmantel des Feldmarschalls
231630	Satinlaufschuhe des Kriegsherrn
231631	Satinmantel des Kriegsfürsten
231632	Satintunika des Kriegsfürsten
231633	Satinhandlappen des Kriegsherrn
231634	Satinbeinschützer des Kriegsherrn
231635	Satinkapuze des Kriegsfürsten
231639	Lamellenbeinschützer des Marschalls
231640	Lamellenhelm des Feldmarschalls
231641	Lamellenbrustharnisch des Feldmarschalls
231642	Kräutertasche des Aufsehers
231643	Lamellenhandschuhe des Marschalls
231644	Verzauberertasche des Aufsehers
231645	Lamellenschulterstücke des Feldmarschalls
231646	Lamellenschienbeinschützer des Marschalls
231647	Lamellengamaschen des Marschalls
231648	Lamellenkopfschutz des Feldmarschalls
231649	Lamellenbrustplatte des Feldmarschalls
231650	Lamellenstulpen des Großmarschalls
231651	Lamellenschultern des Feldmarschalls
231652	Lamellensabatons des Marschalls
231653	Panzerhalsberge des Kriegsfürsten
231654	Panzerschulterstücke des Kriegsfürsten
231655	Panzerklemmen des Kriegsherrn
231656	Panzerschienbeinschützer des Kriegsherrn
231657	Panzerkopfschutz des Kriegsfürsten
231658	Panzerbeinschützer des Kriegsherrn
231659	Panzerschiftung des Kriegsfürsten
231660	Panzerstulpen des Kriegsherrn
231661	Panzersabatons des Kriegsherrn
231662	Panzerbrustplatte des Kriegsfürsten
231663	Panzerhelm des Kriegsfürsten
231664	Panzergamaschen des Kriegsherrn
231665	Panzerschulterklappen des Kriegsfürsten
231666	Panzerhandschuhe des Kriegsherrn
231667	Panzerstiefel des Kriegsherrn
231668	Panzerbrustharnisch des Kriegsfürsten
231669	Panzerschädelkappe des Kriegsfürsten
231670	Panzerhose des Kriegsherrn
231671	Drachenlederschienbeinschützer des Kriegsherrn
231672	Drachenlederschulterstücke des Kriegsfürsten
231673	Drachenlederbeinschützer des Kriegsherrn
231674	Drachenledertunika des Kriegsfürsten
231675	Drachenlederkopfputz des Kriegsfürsten
231676	Drachenlederstulpen des Kriegsherrn
231677	Drachenlederhandschuhe des Kriegsherrn
231678	Drachenlederhelm des Kriegsfürsten
231679	Drachenlederrüstung des Kriegsfürsten
231680	Drachenlederhose des Kriegsherrn
231681	Drachenlederschiftung des Kriegsfürsten
231682	Drachenlederstiefel des Kriegsherrn
231683	Drachenledertreter des Kriegsherrn
231684	Drachenlederschultern des Kriegsfürsten
231685	Drachenledergamaschen des Kriegsherrn
231686	Drachenlederbrustharnisch des Kriegsfürsten
231687	Drachenlederkopfschutz des Kriegsfürsten
231688	Drachenlederhandschutz des Kriegsherrn
231689	Drachenlederkopfschutz des Feldmarschalls
231690	Drachenlederbrustharnisch des Feldmarschalls
231691	Drachenledergamaschen des Marschalls
231692	Drachenledertreter des Marschalls
231693	Drachenlederschultern des Feldmarschalls
231694	Drachenlederhandschutz des Marschalls
231695	Drachenlederhelm des Feldmarschalls
231696	Drachenlederrüstung des Feldmarschalls
231697	Drachenlederhose des Marschalls
231698	Drachenlederstiefel des Marschalls
231699	Drachenlederschiftung des Feldmarschalls
231700	Drachenlederhandschuhe des Marschalls
231701	Drachenlederkopfputz des Feldmarschalls
231702	Drachenledertunika des Feldmarschalls
231703	Drachenlederbeinschützer des Marschalls
231704	Drachenlederschienbeinschützer des Marschalls
231705	Drachenlederschulterstücke des Feldmarschalls
231706	Drachenlederstulpen des Marschalls
231707	Drakonische Bindungen
231708	Drakonischer Gürtel
231709	Drakonische Schulterpolster
231710	Drakonische Gamaschen
231711	Drakonische Kapuze
231712	Drakonische Handschuhe
231713	Drakonische Stiefel
231714	Drakonische Robe
231715	Urtümliche Bindungen
231716	Urtümliche Gürtel
231717	Urtümliche Schulterpolster
231718	Urtümliche Gamaschen
231719	Urtümlicher Helm
231720	Urtümliche Handschuhe
231721	Urtümliche Stiefel
231722	Erschöpfte Sense des Chaos
231723	Urtümliches Brustteil
231724	Uralte Bindungen
231725	Uralter Gürtel
231726	Uralte Schulterpolster
231727	Uralte Gamaschen
231728	Uralter Helm
231729	Uralte Handschuhe
231730	Uralte Stiefel
231731	Uralte Truhe
231732	Verdächtige Vorräte
231752	S03 - Monster - Schwert, 2H Allianz
231753	Trost des Himmelswalls
231754	Turmfalke
231755	Wanderfalke
231777	Kristallisierte Qirajiextremität
231778	Bergquellwasser
231779	Zorn des Wray
231780	Foliant des Wasserherbeizauberns VIII
231781	Seele des Donners
231782	Krone des Nachfolgers
231783	Tuch des Windlords
231784	Blitzzelle
231785	Echos des Verrats
231789	Siegelzeichen des Bewahrers
231792	Seele des Unheils
231793	Erschöpfte Sense des Chaos (Unheil)
231794	Erschöpfte Sense des Chaos (Leere)
231795	Erschöpfte Sense des Chaos (Betörung)
231796	Erschöpfte Sense des Chaos (Verzehren)
231797	Seele der Leere
231798	Seele der Betörung
231799	Seele des Verzehrens
231800	Seele von Des'Altek
231803	Prestors Talisman der Verschwörung
231806	Sengpfeil
231807	Sengender Schuss
231811	Buchband der Ehrfurcht
231814	Chromatisches Herz
231815	Blitzreißer
231817	Windtreffer
231823	Geddons Gleve
231828	Rune der Meditationsspezialisierung
231829	Rune der Heilungsspezialisierung
231836	Leuchtende Schriftrolle der räumlichen Heilung
231837	Schattenschnitzerei
231841	Blut des Lichtbringers
231842	Nandiebs Stab
231843	Erstes Siegelzeichenfragment
231844	Zweites Siegelzeichenfragment
231845	Drittes Siegelzeichenfragment
231846	Gri'leks Schnitzer
231847	Gri'leks Schleifer
231848	Nat Pagles Fischterminator
231849	Tigules Harpune
231850	Wille Arlokks
231851	Arlokks Griff
231852	Zwergenzerstörer der Gurubashi
231853	Kriegsklinge der Hakkari
231854	Zin'rokh der Weltenzerstörer
231855	Fangzahn des Gesichtslosen
231856	Uralter Menschentöter der Hakkari
231857	Berührung des Chaos
231858	Blutrufer
231859	Jin'dos Verhexer
231860	Jin'dos Richturteil
231861	Jekliks Zermalmer
231862	Heimzahler des lodernden Zorns
231863	Gedankenvernichter
231864	Heugabel des Wahnsinns
231865	Zulianisches Szepter der Riten
231866	Mar'lis Berührung
231867	Verteidiger des Blutfürsten
231868	Mandokirs Stachel
231869	Kriegsklinge der Hakkari
231870	Hellebarde der Pein
231871	Wushoolays Schüreisen
231872	Hoodoojagdbogen
231873	Zulianische Steinaxt
231874	Fangzahn von Venoxis
231875	Thekals Griff
231876	Zulianischer Schnitzler
231882	Unterdrückungsmaschinenbeleg
231885	Frostgram
231890	Terrestris
231891	Abhandlung über den Gerfalken
231901	Wahrheitsbringer
231902	Adas Amulett
231903	Stofffetzen
231904	Beflecktes Horn
231909	Kristallisiertes Sternenlicht
231910	Herz von Azgaloth
231911	Siegel des Legionsgenerals
231912	Klinge der Grube
231913	Auge des Beobachters
231995	Gehärtete Elementiumschlacke
231996	Überladener Gobmogrifizierer
232018	Schlummernde vom Wind berührte Klinge
232079	Bindungen des Stormrage
232080	Kordel des Stormrage
232081	Mantel des Stormrage
232082	Rock des Stormrage
232083	Geweih des Stormrage
232084	Fäustlinge des Stormrage
232085	Sandalen des Stormrage
232086	Leder des Stormrage
232087	Armschienen des Stormrage
232088	Gürtel des Stormrage
232089	Schulterstücke des Stormrage
232090	Beinschützer des Stormrage
232091	Bedeckung des Stormrage
232092	Handschützer des Stormrage
232093	Stiefel des Stormrage
232094	Brustschutz des Stormrage
232095	Wickel des Stormrage
232096	Schärpe des Stormrage
232097	Schulterpolster des Stormrage
232098	Hose des Stormrage
232099	Gugel des Stormrage
232100	Handschutz des Stormrage
232101	Stampfer des Stormrage
232102	Weste des Stormrage
232103	Handgelenksschützer des Stormrage
232104	Taillenschutz des Stormrage
232105	Schiftung des Stormrage
232106	Gamaschen des Stormrage
232107	Kopfputz des Stormrage
232108	Stulpen des Stormrage
232109	Treter des Stormrage
232110	Rüstung des Stormrage
232111	Unterarmschienen des Drachenjägers
232112	Gurt des Drachenjägers
232113	Schulterstücke des Drachenjägers
232114	Hose des Drachenjägers
232115	Schädelkappe des Drachenjägers
232116	Handschutz des Drachenjägers
232117	Sabatons des Drachenjägers
232118	Rüstung des Drachenjägers
232119	Armschienen des Drachenjägers
232120	Gürtel des Drachenjägers
232121	Schiftung des Drachenjägers
232122	Beinschützer des Drachenjägers
232123	Helm des Drachenjägers
232124	Stulpen des Drachenjägers
232125	Schienbeinschützer des Drachenjägers
232126	Brustplatte des Drachenjägers
232127	Bindungen des Netherwinds
232128	Gürtel des Netherwinds
232129	Mantel des Netherwinds
232130	Hose des Netherwinds
232131	Krone des Netherwinds
232132	Handschuhe des Netherwinds
232133	Stiefel des Netherwinds
232134	Roben des Netherwinds
232135	Wickel des Netherwinds
232136	Schärpe des Netherwinds
232137	Schultern des Netherwinds
232138	Gamaschen des Netherwinds
232139	Maske des Netherwinds
232140	Fäustlinge des Netherwinds
232141	Pantoffeln des Netherwinds
232142	Gewänder des Netherwinds
232143	Bindungen des Richturteils
232144	Gürtel des Richturteils
232145	Schiftung des Richturteils
232146	Beinplatten des Richturteils
232147	Krone des Richturteils
232148	Stulpen des Richturteils
232149	Sabatons des Richturteils
232150	Brustplatte des Richturteils
232151	Armschienen des Richturteils
232152	Gurt des Richturteils
232153	Mantel des Richturteils
232154	Plattenrock des Richturteils
232155	Helm des Richturteils
232156	Handschuhe des Richturteils
232157	Treter des Richturteils
232158	Kürass des Richturteils
232159	Unterarmschienen des Richturteils
232160	Taillenschutz des Richturteils
232161	Schulterstücke des Richturteils
232162	Beinschützer des Richturteils
232163	Großhelm des Richturteils
232164	Handschützer des Richturteils
232165	Schienbeinschützer des Richturteils
232166	Brustschutz des Richturteils
232167	Armschienen der Erhabenheit
232168	Kordel der Erhabenheit
232169	Mantel der Erhabenheit
232170	Hose der Erhabenheit
232171	Krone der Erhabenheit
232172	Handschuhe der Erhabenheit
232173	Treter der Erhabenheit
232174	Kluft der Erhabenheit
232175	Bindungen der Erhabenheit
232176	Gürtel der Erhabenheit
232177	Schulterstücke der Erhabenheit
232178	Gamaschen der Erhabenheit
232179	Heiligenschein der Erhabenheit
232180	Handschützer der Erhabenheit
232181	Stiefel der Erhabenheit
232182	Roben der Erhabenheit
232183	Blutfangarmschienen
232184	Blutfanggürtel
232185	Blutfangschiftung
232186	Blutfanghose
232187	Blutfangkapuze
232188	Blutfanghandschuhe
232189	Blutfangstiefel
232190	Blutfangbrustharnisch
232191	Blutfanghandgelenksschützer
232192	Blutfangtaillenschutz
232193	Blutfangschulterpolster
232194	Blutfangbeinschützer
232195	Blutfanggugel
232196	Blutfanghandschützer
232197	Blutfangfußpolster
232198	Blutfangbrustschutz
232199	Bindungen der zehn Stürme
232200	Kordel der zehn Stürme
232201	Mantel der zehn Stürme
232202	Rock der zehn Stürme
232203	Kopfputz der zehn Stürme
232204	Handschuhe der zehn Stürme
232205	Stiefel der zehn Stürme
232206	Umarmung der zehn Stürme
232207	Armschienen der zehn Stürme
232208	Gürtel der zehn Stürme
232209	Schulterklappen der zehn Stürme
232210	Beinplatten der zehn Stürme
232211	Helm der zehn Stürme
232212	Stulpen der zehn Stürme
232213	Schienbeinschützer der zehn Stürme
232214	Brustplatte der zehn Stürme
232215	Unterarmschienen der zehn Stürme
232216	Gurt der zehn Stürme
232217	Schiftung der zehn Stürme
232218	Gamaschen der zehn Stürme
232219	Krone der zehn Stürme
232220	Handschutz der zehn Stürme
232221	Treter der zehn Stürme
232222	Rüstung der zehn Stürme
232223	Handgelenksschützer der zehn Stürme
232224	Taillenschutz der zehn Stürme
232225	Schulterklappen der zehn Stürme
232226	Beinschützer der zehn Stürme
232227	Gesichtsschutz der zehn Stürme
232228	Handschützer der zehn Stürme
232229	Sabatons der zehn Stürme
232230	Brustschutz der zehn Stürme
232231	Armschienen der Nemesis
232232	Gürtel der Nemesis
232233	Schiftung der Nemesis
232234	Gamaschen der Nemesis
232235	Schädelkappe der Nemesis
232236	Handschuhe der Nemesis
232237	Stiefel der Nemesis
232238	Roben der Nemesis
232239	Wickel der Nemesis
232240	Kordel der Nemesis
232241	Schulterpolster der Nemesis
232242	Hosen der Nemesis
232243	Gugel der Nemesis
232244	Handschützer der Nemesis
232245	Treter der Nemesis
232246	Kluft der Nemesis
232247	Armschienen des Zorns
232248	Gürtel des Zorns
232249	Schultern des Zorns
232250	Beinplatten des Zorns
232251	Helm des Zorns
232252	Stulpen des Zorns
232253	Schienbeinschützer des Zorns
232254	Brustplatte des Zorns
232255	Handgelenksschützer des Zorns
232256	Taillenschutz des Zorns
232257	Schulterstücke des Zorns
232258	Beinschützer des Zorns
232259	Gesichtsschutz des Zorns
232260	Handschützer des Zorns
232261	Sabatons des Zorns
232262	Brustschutz des Zorns
232299	Zulianischer Verteidiger
232309	Renatakis Seelenkanal
232310	Renatakis Seelenkanal
232311	Zulianischer Tigerbalgumhang
232312	Blut des Lichtbringers
232324	Vogelpfeife
232344	Vick's VIP Pass
232357	Drachischer Rächer
232358	Leerer Reliquienschrein
232373	Veredeltes Auge von Sulfuras
232389	Buchband der Fülle
232390	Götze des himmlischen Fokus
232391	Götze des Katzenfokus
232392	Totem des unaufhörlichen Donners
232409	Totem der Elemente
232414	Drachenhauerklinge
232416	Totem des Astralflusses
232419	Totem der leitenden Ströme
232420	Buchband des Zorns
232421	Buchband des Rächens
232423	Götze der Pflege
232424	Götze der Grausamkeit
232433	Dichter Runenstoffverband
232434	Handbuch: Dichter Runenstoffverband
232436	Dunkelklauensuppe
232437	Rezept: Dunkelklauensuppe
232438	Geräucherte Rotkieme
232443	Rezept: Geräucherte Rotkieme
232454	Emblem der wilden Götter
232455	Emblem der Ehrlosigkeit
232456	Emblem des Violetten Auges
232457	Emblem des Weltenkerns
232458	Rune des verbesserten Refugiums
232459	Rune der Pyrolyse
232460	Rune der Verzerrung
232461	Rune der Verzweiflung
232462	Rune der reinigenden Macht
232549	Logistikeinsatz VI
232550	Ashkandi, Großschwert der Bruderschaft
232551	Drachischer Schlägel
232552	Lok'amir il Romathis
232555	Crul'shorukh, Schneide des Chaos
232556	Stab der Schattenflamme
232557	Klaue von Chromaggus
232558	Chromatisch gehärtetes Schwert
232559	Herold des Leidens
232561	Klaue des Schwarzdrachen
232562	Drachenkrallenbeil
232563	Fokussierstab der Schattenschwingen
232564	Maladath, runenverzierte Klinge des schwarzen Drachenschwarms
232565	Drachenzahnklinge
232566	Die ungezähmte Klinge
232567	Wirbelsäulenbrecher
232576	Drachischer Rächer
232577	Schneide der Verdammnis
232606	Ashjre'thul, Armbrust der Pein
232607	Herzensbrecher
232608	Drachenodemhandkanone
232610	Formel: Prächtiger Trollschein
232611	Prächtiger Trollschein
232652	Zila Amanemodas
233197	Trainingshandbuch der Argentumdämmerung
233198	Horn der Dämmerung
233200	Liedblumensaat
233201	Schimmernde Kugel
233206	Amboss des Vorarbeiters
233208	"Defekte" Wahrsagerkugel
233209	Feuerwasserkessel
233211	Geistschnecke
233213	Uralter Leitstein
233215	Explosive Sandfalle
233216	Frostomatikstrahl
233217	Räucherwerk des Tunnelgräbers
233226	Uraltes Zandalariseil
233250	Uralter Zweig
233351	Hellgrüner Qirajiresonanzkristall
233352	Dunkelblauer Qirajiresonanzkristall
233353	Hellblauer Qirajiresonanzkristall
233356	Orangener Qirajiresonanzkristall
233357	Zwielichtqirajiresonanzkristall
233358	Gezähmte Silithidendrohne
233362	Hülle des alten Gottes
233363	Knochenpanzer des alten Gottes
233364	Haut des alten Gottes
233365	Intakte Eingeweide
233367	Intaktes Bauchfell
233368	Intakte Innereien
233369	Dominanzbindungen der Qiraji
233370	Befehlsbindungen der Qiraji
233371	Herrschaftsbindungen der Qiraji
233372	Schienbeinschützer des Eroberers
233373	Brustplatte des Eroberers
233374	Beinschützer des Eroberers
233375	Krone des Eroberers
233376	Schiftung des Eroberers
233377	Fußlappen des Verdammnisrufers
233378	Beinkleider des Verdammnisrufers
233379	Mantel des Verdammnisrufers
233380	Roben des Verdammnisrufers
233381	Reif des Verdammnisrufers
233382	Gamaschen des Sturmrufers
233383	Schulterstücke des Sturmrufers
233384	Fußschützer des Sturmrufers
233385	Diadem des Sturmrufers
233386	Halsberge des Sturmrufers
233387	Schiftung des Todesboten
233388	Helm des Todesboten
233389	Weste des Todesboten
233390	Gamaschen des Todesboten
233391	Stiefel des Todesboten
233392	Fußlappen des Orakels
233393	Tiara des Orakels
233394	Mantel des Orakels
233395	Gewänder des Orakels
233396	Beinkleider des Orakels
233397	Brustplatte des Rächers
233398	Krone des Rächers
233399	Schienbeinschützer des Rächers
233400	Beinschützer des Rächers
233401	Schulterstücke des Rächers
233402	Roben des Mysteriums
233403	Schulterpolster des Mysteriums
233404	Reif des Mysteriums
233405	Stiefel des Mysteriums
233406	Gamaschen des Mysteriums
233407	Fußschützer des Hetzers
233408	Gamaschen des Hetzers
233409	Schulterstücke des Hetzers
233410	Diadem des Hetzers
233411	Halsberge des Hetzers
233412	Helm der Genesis
233413	Schulterpolster der Genesis
233414	Stiefel der Genesis
233415	Weste der Genesis
233416	Beinkleider der Genesis
233417	Streitkolben des endlosen Lebens
233418	Umhang des endlosen Lebens
233419	Band des endlosen Lebens
233420	Umhang des unsichtbaren Pfads
233421	Sense des unsichtbaren Pfads
233422	Siegel des unsichtbaren Pfads
233423	Klinge der behüteten Geheimnisse
233424	Tuch der behüteten Geheimnisse
233425	Band der behüteten Geheimnisse
233426	Klinge der ewigen Gerechtigkeit
233427	Cape der ewigen Gerechtigkeit
233428	Ring der ewigen Gerechtigkeit
233429	Hammer der unendlichen Weisheit
233430	Schleier der unendlichen Weisheit
233431	Ring der unendlichen Weisheit
233432	Umhang der Schattenschleier
233433	Dolch der Schattenschleier
233434	Band der Schattenschleier
233435	Hammer der aufziehenden Stürme
233436	Umhang der aufziehenden Stürme
233437	Ring der aufziehenden Stürme
233438	Schleier der ungesagten Namen
233439	Kris der ungesagten Namen
233440	Ring der ungesagten Namen
233441	Tuch der unnachgiebigen Stärke
233442	Sichel der unnachgiebigen Stärke
233443	Siegel der unnachgiebigen Stärke
233490	Obsidianchampion
233491	Obsidianhäscher
233492	Klingenstachelkampfplatte
233496	Sperrfeuerschultern
233502	Amulett des faulen Zauberschutzes
233503	Anhänger des Qirajiwächters
233504	Umhang des geballten Hasses
233505	Gamaschen der bodenlosen Tiefe
233506	Handgelenksschutz aus Käferschuppen
233507	Ring des wirren Gedankens
233509	Stab der Qirajipropheten
233514	Stiefel des standhaften Willens
233515	Hammer von Ji'zhi
233516	Brustplatte der Vernichtung
233517	Stiefel der widerrufenen Prophezeiung
233518	Stiefel des gefallenen Propheten
233519	Cape der Dreifaltigkeit
233520	Roben des Dreigestirns
233521	Dreistoffmantel
233522	Erscheinung des Verschlingers
233523	Triadengurt
233524	Angelistas Berührung
233559	Handschuhe von Ebru
233560	Brühschlammige Stulpen
233561	Stiefel des gefallenen Helden
233562	Angelistas Glücksbringer
233563	Mantel der inneren Kraft
233564	Gallenbespritzte Stulpen
233565	Ukkos Ring der Dunkelheit
233566	Mantel des Wüstenzorns
233567	Mantel des Wüstenfeldzugs
233568	Weste der zügigen Vollstreckung
233569	Ring des Verschlungenen
233570	Versteinerter Skarabäus
233571	Zauberstab des Qirajiadels
233572	Halskette der Reinheit
233573	Zusammengesetzte Stiefel
233574	Gamaschen des faulenden Schwarms
233575	Roben der Schlachtwache
233576	Silithidenklaue
233577	Dicker Qirajihautgürtel
233578	Kriecherrankenhelm
233579	Handschuhe der Vollstreckung
233580	Abzeichen der Schwarmwache
233581	Sarturas Macht
233582	Stulpen der festen Entschlossenheit
233583	Beinplatten des flammenden Lichts
233584	Schuppengamaschen des Qirajizorns
233585	Uralter Qirajizerfetzer
233586	Kiefer des Sandhäschers
233587	Stachelhalsschmuck
233588	Umhang der ungelüfteten Geheimnisse
233589	Fetisch des Sandhäschers
233590	Stiefel des Schwarmbaugräbers
233591	Brustschutz aus Silithidenknochenpanzer
233592	Mantel der boshaften Rache
233593	Schulterstücke des Unerbittlichen
233594	Roben des Schutzheiligen
233595	Schuppengamaschen des Sandhäschers
233596	Buchband der Läuterung
233597	Totem des Lebens
233598	Schleimbeschichtete Gamaschen
233599	Geschärfter Silithidenknochen
233600	Ring des Qirajizorns
233601	Skarabäusbrosche
233602	Götze der Gesundheit
233603	Stulpen des rechtschaffenen Champions
233604	Stulpen von Kalimdor
233605	Huhurans Stachel
233606	Umhang des goldenen Schwarms
233607	Handschuhe des Messias
233608	Wespenhautstulpen
233609	Ring des Märtyrers
233610	Handgelenksschutz des Schwarmbauentweihers
233611	Stiefel der göttlichen Erscheinung
233612	Vollstreckungsarmschienen der Qiraji
233613	Vek'lors Handschuhe der Verwüstung
233614	Königlicher Qirajigürtel
233615	Ring des Imperators Vek'lor
233616	Königliches Szepter von Vek'lor
233617	Armreifen der königlichen Erlösung
233618	Handschuhe des verborgenen Tempels
233619	Vek'nilashs Gürtel der Regeneration
233620	Amulett von Vek'nilash
233621	Kalimdors Rache
233622	Griff des gefallenen Imperators
233623	Gürtel des gefallenen Imperators
233624	Don Rigobertos verlorener Hut
233625	Armschienen des Wühlers
233626	Larve des großen Wurms
233627	Jom Gabbar
233628	Panzer des Wühlers
233629	Wurmschuppenblocker
233630	Umhang des Verschlungenen
233631	Stulpen der dunklen Stürme
233632	Griff des alten Gottes
233633	Augenstrangkordel
233634	Stich des Todes
233635	Gürtel der endlosen Pein
233636	Szepter des falschen Propheten
233637	Stulpen der Vernichtung
233638	Ring des Göttertöters
233639	Bezwungene Tentakel von C'Thun
233640	Dunkle Schneide des Irrsinns
233641	Umhang der Klarsicht
233642	Mal von C'Thun
233643	Kriegshammer des Anubisath
233644	Gewand des königlichen Aufstiegs
233645	Handschuhe des Unsterblichen
233646	Handschuhe der widerrufenen Prophezeiung
233647	Neretzek der Bluttrinker
233648	Ritssyns Ring des Chaos
233649	Splitter des gefallenen Sterns
233651	Kürass des Eroberers
233652	Sabatons des Eroberers
233653	Helm des Eroberers
233654	Tassetten des Eroberers
233658	Schulterstücke des Eroberers
233659	Brustschutz des Todesboten
233660	Treter des Todesboten
233661	Visier des Todesboten
233662	Hose des Todesboten
233663	Schulterstücke des Todesboten
233664	Ringpanzer des Hetzers
233665	Treter des Hetzers
233666	Visier des Hetzers
233667	Kettenbeinplatten des Hetzers
233668	Schiftung des Hetzers
233669	Kopfschutz des Verdammnisrufers
233670	Gewand des Verdammnisrufers
233671	Schulterpolster des Verdammnisrufers
233672	Hose des Verdammnisrufers
233673	Treter des Verdammnisrufers
233674	Hose des Mysteriums
233675	Pantoffeln des Mysteriums
233676	Diadem des Mysteriums
233677	Mantel des Mysteriums
233678	Gewand des Mysteriums
233679	Gamaschen des Orakels
233680	Robe des Orakels
233681	Schulterpolster des Orakels
233682	Krone des Orakels
233683	Pantoffeln des Orakels
233684	Mantel des Rächers
233685	Plattenhosen des Rächers
233686	Treter des Rächers
233687	Helm des Rächers
233688	Kürass des Rächers
233689	Schiftung des Rächers
233690	Tassetten des Rächers
233691	Sabatons des Rächers
233692	Großhelm des Rächers
233693	Brustschutz des Rächers
233694	Brustschutz des Sturmrufers
233695	Gesichtsschutz des Sturmrufers
233696	Sabatons des Sturmrufers
233697	Schiftung des Sturmrufers
233698	Beinplatten des Sturmrufers
233699	Brustplatte des Sturmrufers
233700	Krone des Sturmrufers
233701	Treter des Sturmrufers
233702	Mantel des Sturmrufers
233703	Kettengamaschen des Sturmrufers
233704	Umarmung des Sturmrufers
233705	Kopfputz des Sternenrufers
233706	Schienbeinschützer des Sturmrufers
233707	Schulterklappen des Sturmrufers
233708	Panzergamaschen des Sturmrufers
233709	Gugel der Genesis
233710	Lederhose der Genesis
233711	Rüstung der Genesis
233712	Stampfer der Genesis
233713	Schiftung der Genesis
233714	Gamaschen der Genesis
233715	Lederwams der Genesis
233716	Treter der Genesis
233717	Mantel der Genesis
233718	Kopfputz der Genesis
233719	Bundhose der Genesis
233720	Brustschutz der Genesis
233721	Schienbeinschützer der Genesis
233722	Schulterstücke der Genesis
233723	Maske der Genesis
233724	Kampfgestählter Plattengurt
233725	Kampfgestählter Plattengurt
233726	Kampfgestählte Plattenarmschützer
233727	Kampfgestählte Plattenarmschützer
233728	Blutbedecktes Insigne
233729	Blutbedeckter Halsreif
233730	Blutbedeckter Talisman
233731	Blutbedecktes Amulett
233732	Blutbedeckte Halskette
233733	Blutbedeckter Ring
233734	Blutbedeckter Reif
233735	Blutbedeckte Schleife
233736	Blutbedecktes Band
233737	Blutbedeckter Mantel
233738	Blutbedeckter Umhang
233739	Blutbedecktes Tuch
233740	Blutbedeckter Schleier
233741	Kampfgestählter Lamellengürtel
233742	Kampfgestählte Lamellenarmschützer
233743	Kampfgestählte Lamellenmanschetten
233744	Kampfgestählte Lamellenkordel
233745	Kampfgestählter Panzergürtelbund
233746	Kampfgestählte Panzerkordel
233747	Kampfgestählter Panzergürtel
233748	Kampfgestählte Panzerarmschienen
233749	Kampfgestählte Panzerhandgelenksschützer
233750	Kampfgestählte Panzerunterarmschienen
233751	Kampfgestählter Kettengurt
233752	Kampfgestählter Kettengurt
233753	Kampfgestählter Kettengürtel
233754	Kampfgestählter Kettengürtel
233755	Kampfgestählte Kettenhandgelenksschützer
233756	Kampfgestählte Kettenhandgelenksschützer
233757	Kampfgestählte Kettenarmschienen
233758	Kampfgestählte Kettenarmschienen
233759	Kampfgestählte Drachenlederarmschienen
233760	Kampfgestählte Drachenlederarmschienen
233761	Kampfgestählter Drachenledergürtel
233762	Kampfgestählter Drachenledergürtel
233763	Kampfgestählter Drachenledertaillenschutz
233764	Kampfgestählter Drachenledertaillenschutz
233765	Kampfgestählte Drachenlederkordel
233766	Kampfgestählte Drachenlederkordel
233767	Kampfgestählte Drachenledermanschetten
233768	Kampfgestählte Drachenledermanschetten
233769	Kampfgestählte Drachenlederarmbänder
233770	Kampfgestählte Drachenlederarmbänder
233771	Kampfgestählter Ledergürtel
233772	Kampfgestählter Ledergürtel
233773	Kampfgestählte Lederarmsplinte
233774	Kampfgestählte Lederarmsplinte
233775	Kampfgestählte Seidenmanschetten
233776	Kampfgestählte Seidenmanschetten
233777	Kampfgestählte Seidenschärpe
233778	Kampfgestählte Seidenschärpe
233779	Kampfgestählte Satinarmschienen
233780	Kampfgestählte Satinarmschienen
233781	Kampfgestählte Satinmanschetten
233782	Kampfgestählte Satinmanschetten
233783	Kampfgestählte Satinschärpe
233784	Kampfgestählte Satinschärpe
233785	Kampfgestählter Satinhüftgurt
233786	Kampfgestählter Satinhüftgurt
233787	Kampfgestählte Schreckenszwirnmanschetten
233788	Kampfgestählte Schreckenszwirnmanschetten
233789	Kampfgestählter Schreckenszwirngürtel
233790	Kampfgestählter Schreckenszwirngürtel
233791	Blutbedeckte Kupfermünze
233793	Klingenstachelschulterplatten
233795	Klingenstachelhirnkasten
233796	Obsidianzerstörer
233797	Obsidiansturmhammer
233798	Obsidianweisenklinge
233801	Obsidianverteidiger
233802	Leuchtendes Chitinrüstungsset
233803	Geschliffenes Chitinrüstungsset
233804	Messerdornenschulterpolster
233808	Messerdornengugel
233813	Messerdornenlederwams
233826	Vampirgugel
233833	Vampirschal
233837	Vampirrobe
233956	Qirajiseidenschal
233958	Qirajiseidencape
233959	Qirajiseidenumhang
233960	Qirajiseidentuch
233962	Fläschchen des Wahnsinns
233964	Fläschchen des uralten Wissens
233965	Fläschchen der Alten Götter
233966	Fläschchen des unnachgiebigen Kummers
233967	Elixier des Honigdachses
233968	Elixier des Magierlords
233969	Elixier der Eisenflanken
233977	Elixier des Eifers
233984	Arkane Megabombe
233985	Der Ausräucherer
233986	Obsidianbombe
233987	Generator für 6u73 5chw1n6un63n
233988	Gestimmte machtreaktive Scheibe
233990	Geschwindigkeitsstein
233991	Träne des Träumers
233992	Leitstein der Vergeltung
233993	Verzauberte Stoppuhr
233994	Rubinbesetzte Brosche
233995	Schriftrolle: Zorn des Schwarms
233996	Verzaubertes Abwehrmittel
233997	Formel: Brust - Lebendige Werte
233998	Formel: Handschuhe - Heilige Kraft
233999	Formel: Handschuhe - Arkane Macht
234000	Verzauberter Gebetsband
234001	Verzaubertes Totem
234002	Verzauberter Pilz
234003	Obsidianangereicherter Thoriumbarren
234004	Obsidianschleifstein
234005	Obsidiansprengpulver
234006	Monströses Silithidenchitin
234007	Stachelbesetztes Silithidenchitin
234008	Qirajiseide
234009	Qirajiseidenballen
234010	Uralte Sandwurmgalle
234011	Qirajipirschergift
234012	Schwarmdistel
234016	Siegelring des bronzenen Drachenschwarms
234017	Siegelring des bronzenen Drachenschwarms
234018	Siegelring des bronzenen Drachenschwarms
234019	Siegelring des bronzenen Drachenschwarms
234020	Siegelring des bronzenen Drachenschwarms
234021	Siegelring des bronzenen Drachenschwarms
234022	Siegelring des bronzenen Drachenschwarms
234023	Siegelring des bronzenen Drachenschwarms
234024	Siegelring des bronzenen Drachenschwarms
234025	Siegelring des bronzenen Drachenschwarms
234026	Siegelring des bronzenen Drachenschwarms
234027	Siegelring des bronzenen Drachenschwarms
234028	Siegelring des bronzenen Drachenschwarms
234029	Siegelring des bronzenen Drachenschwarms
234030	Siegelring des bronzenen Drachenschwarms
234031	Siegelring des bronzenen Drachenschwarms
234032	Siegelring des bronzenen Drachenschwarms
234033	Siegelring des bronzenen Drachenschwarms
234034	Siegelring des bronzenen Drachenschwarms
234035	Siegelring des bronzenen Drachenschwarms
234061	Opferdolch der Qiraji
234062	Gewänder der Sandstürme
234063	Gürtel des Sandhäschers
234064	Gürtel der Inquisition
234065	Handgelenksschutz des Sandhäschers
234066	Handschuhe aus gekräftigter Silithidenhaut
234067	Menschentöter der Qiraji
234068	Stiefel des Vorpostens
234069	Stiefel des Qirajigenerals
234070	Armschienen des Qirajikommandos
234071	Beinplatten des Qirajikommandos
234072	Südwinds Griff
234073	Turban der staubigen Winde
234075	Stulpen des Unbeweglichen
234076	Kralle der gewaltigen Konzentration
234077	Dicker Silithidenbrustschutz
234078	Chitinschulterschutz
234079	Umhang des Retters
234080	Auge von Moam
234081	Stulpen des Südwinds
234082	Mantel von Maz'Nadir
234083	Ring des Zorns
234084	Helm des Südwinds
234085	Pläne: Dunkler Griff des Zerstörers
234086	Dunkler Griff des Zerstörers
234087	Obsidianschuppengamaschen
234088	Beinplatten des Zerstörers
234089	Burus Schädelfragment
234090	Handschuhe des Schwarms
234091	Schleimige Schuppenstulpen
234092	Chitinstachelfetisch
234093	Treibsandwandler
234094	Schuppenarmschienen des Verschlingers
234095	Schleimkicker
234096	Bogen der straffen Sehne
234097	Stachel von Ayamiss
234098	Stiefel des Wüstenbeschützers
234099	Stiefel der feurigen Sande
234100	Helm des Nachwachsens
234101	Ring der Wüstenwinde
234102	Stulpen aus Silithidenschuppen
234103	Armschienen der Unbarmherzigkeit
234104	Armbrust der bevorstehenden Verdammnis
234105	Stulpen des neuen Lebens
234106	Handschuhe der düsteren Weisheit
234107	Helm der Herrschaft
234108	Gamaschen des schwarzen Sturms
234109	Mantel von Horusath
234110	Ossirians Bindung
234111	Schultern mit runenverzierten Steinen
234112	Sandpolierter Hammer
234113	Sandsturmumhang
234114	Fesseln des Narbenlosen
234115	Stab der Ruinen
234116	Zorn des vergessenen Schwarms
234117	Treter des wandernden Nomaden
234118	Hammer der Qirajigewalt
234119	Fühler der Kräftigung
234120	Helm des heiligen Rächers
234121	Silithidhülsenzünder
234122	Der verlorene Kris von Zedd
234123	Helmkappe des Elementarfurors
234124	Leitfaden des okkulten Gifts II
234129	Gamaschen mit Onyxeinbettung
234130	Amulett der Schattenabwehr
234132	Drachenzahnhalskette
234133	Zwangsarbeiterstiefel
234134	Turban der gnomischen Superpsychokräfte
234135	Band der eisigen Tiefen
234136	Dunkelwasserroben
234137	Fangzahn von Korialstrasz
234138	Shadowsongs Kummer
234139	Ravencrests Vermächtnis
234141	Runenschwert des Roten
234142	Unerschöpfliches Noggenfogger-Elixier
234143	Kugel des Täuschens
234144	Weihrauchschwenker des falschen Propheten
234145	Blutbedecktes Schmuckstück der Hakkari
234146	Säurebeschriebene Schienbeinschützer
234147	Uralte zerfressene Gamaschen
234148	Drachenknochenhandgelenksschutz
234149	Drachenspitzwickeltücher
234150	Handschuhe der irrsinnigen Macht
234151	Grüner Drachenhautumhang
234152	Hammer des Wildtierzorns
234153	Stab des rasanten Wachstums
234154	Trancestein
234155	Malfurions Siegelring
234156	Stiefel des endlosen Moors
234157	Reif der ruhelosen Träume
234158	Drachenherzhalskette
234159	Polierte Eisenholzarmbrust
234160	Ring der Untoten
234161	Gürtel der dunklen Sümpfe
234162	Schwarzrindengelenkbänder
234163	Hose des dunklen Herzens
234164	Deviatwachstumskappe
234165	Stulpen des scheinenden Lichts
234166	Heimtückische Fußschützer
234167	Stiefel des Schreckens
234168	Schuhe des Bettlers
234169	Geistertränenband
234170	Alptraumklinge
234171	Unnatürliche Lederschiftung
234172	Smaragdgrüner Drachenfangzahn
234173	Gamaschen des verwirrten Geists
234174	Säurebeschriebene Schulterstücke
234175	Hibernationskristall
234176	Dunkelmond-Karte: Heldentum
234177	Dunkelmond-Karte: Blauer Drache
234178	Dunkelmond-Karte: Maelstrom
234179	Dunkelmond-Karte: Wirbelnder Nether
234180	Temporales Leuchtfeuer
234181	Tagebuch eines Twilightkultisten
234198	Siegelring des bronzenen Drachenschwarms
234199	Siegelring des bronzenen Drachenschwarms
234200	Siegelring des bronzenen Drachenschwarms
234201	Siegelring des bronzenen Drachenschwarms
234202	Siegelring des bronzenen Drachenschwarms
234220	Pläne: Klingenstachelhirnkasten
234221	Pläne: Klingenstachelschulterplatten
234222	Pläne: Klingenstachelkampfplatte
234223	Pläne: Obsidianhäscher
234224	Pläne: Obsidianchampion
234225	Pläne: Obsidianzerstörer
234226	Pläne: Obsidiansturmhammer
234227	Pläne: Obsidianweisenklinge
234228	Pläne: Obsidianverteidiger
234235	Muster: Leuchtendes Chitinrüstungsset
234236	Muster: Geschliffenes Chitinrüstungsset
234237	Muster: Messerdornengugel
234238	Muster: Messerdornenschulterpolster
234239	Muster: Messerdornenlederwams
234240	Muster: Vampirgugel
234241	Muster: Vampirschal
234242	Muster: Vampirrobe
234244	Muster: Qirajiseidenschal
234249	Muster: Qirajiseidencape
234250	Muster: Qirajiseidenumhang
234251	Muster: Qirajiseidentuch
234252	Rezept: Fläschchen des unnachgiebigen Kummers
234253	Rezept: Fläschchen des uralten Wissens
234255	Rezept: Fläschchen der Alten Götter
234256	Rezept: Fläschchen des Wahnsinns
234257	Rezept: Elixier des Honigdachses
234258	Rezept: Elixier des Magierlords
234259	Rezept: Elixier der Eisenflanken
234260	Rezept: Elixier des Eifers
234261	Bauplan: Arkane Megabombe
234262	Bauplan: Der Ausräucherer
234263	Bauplan: Obsidianbombe
234264	Bauplan: Generator für 6u73 5chw1n6un63n
234265	Bauplan: Gestimmte machtreaktive Scheibe
234266	Formel: Geschwindigkeitsstein
234267	Formel: Träne des Träumers
234268	Formel: Leitstein der Vergeltung
234269	Formel: Verzauberte Stoppuhr
234270	Formel: Rubinbesetzte Brosche
234271	Formel: Schriftrolle: Zorn des Schwarms
234272	Formel: Verzaubertes Abwehrmittel
234275	Formel: Verzauberter Gebetsband
234276	Formel: Verzaubertes Totem
234277	Formel: Verzauberter Pilz
234278	Handbuch: Obsidianangereicherten Thoriumbarren verhütten
234279	Pläne: Obsidianschleifstein
234280	Bauplan: Obsidiansprengpulver
234288	Eisenrankengürtel
234289	Pläne: Eisenrankengürtel
234290	Eisenrankenhandschuhe
234291	Pläne: Eisenrankenhandschuhe
234292	Eisenrankenbrustplatte
234293	Pläne: Eisenrankenbrustplatte
234294	Sandpirscherarmschienen
234295	Muster: Sandpirscherarmschienen
234296	Sandpirscherstulpen
234297	Muster: Sandpirscherstulpen
234298	Sandpirscherbrustplatte
234299	Muster: Sandpirscherbrustplatte
234300	Feuerspuckerarmschienen
234301	Muster: Feuerspuckerarmschienen
234302	Feuerspuckerstulpen
234303	Muster: Feuerspuckerstulpen
234304	Feuerspuckerbrustplatte
234305	Muster: Feuerspuckerbrustplatte
234306	Dornenholzgürtel
234307	Muster: Dornenholzgürtel
234308	Dornenholzstiefel
234309	Muster: Dornenholzstiefel
234310	Dornenholzhelm
234311	Muster: Dornenholzhelm
234312	Sylvanschultern
234314	Muster: Sylvanschultern
234315	Sylvankrone
234316	Muster: Sylvankrone
234317	Sylvanweste
234318	Muster: Sylvanweste
234319	Schwerer Obsidiangürtel
234320	Pläne: Schwerer Obsidiangürtel
234321	Leichter Obsidiangürtel
234322	Pläne: Leichter Obsidiangürtel
234324	Traumschuppenbrustplatte
234325	Muster: Traumschuppenbrustplatte
234428	Obsidianherzsucher
234429	Pläne: Obsidianherzsucher
234434	Obsidianschrotflinte
234435	Bauplan: Obsidianschrotflinte
234436	Siegelring des bronzenen Drachenschwarms
234437	Siegelring des bronzenen Drachenschwarms
234438	Siegelring des bronzenen Drachenschwarms
234439	Siegelring des bronzenen Drachenschwarms
234440	Siegelring des bronzenen Drachenschwarms
234444	Okkultes Gift II
234445	Muster: Qirajiseidenballen
234447	Blubbis Rute der Transformation
234458	Pläne: Gezackter Obsidianschild
234459	Gezackter Obsidianschild
234460	Obsidianpanzertunika
234461	Pläne: Obsidianpanzertunika
234462	Erdschlag
234463	Zorn des Cenarius
234464	Blubbis Rute der Blasen
234465	Zügel des schnellen Spektraltigers
234467	Blubbis Rute der Drachen
234468	Götze der Bärenwut
234469	Götze der Katzenwildheit
234474	Götze des siderischen Zorns
234475	Buchband des Exorzisten
234476	Buchband der Heiligkeit
234477	Buchband der Rechtschaffenheit
234478	Totem der donnernden Schläge
234479	Totem des fließenden Magmas
234480	Totem des pyroklastischen Donners
234481	Muster: Traumschuppenkilt
234482	Traumschuppenkilt
234483	Muster: Traumschuppenarmschienen
234484	Traumschuppenarmschienen
234485	Traumschuppenfäustlinge
234486	Muster: Traumschuppenfäustlinge
234487	Traumschuppenvisier
234488	Pläne: Traumschuppenvisier
234542	Großschwert des Obersten Kriegsfürsten
234543	Streitaxt des Obersten Kriegsfürsten
234545	Pulverisierer des Obersten Kriegsfürsten
234546	Zerstörer des Obersten Kriegsfürsten
234547	Schweinestecher des Obersten Kriegsfürsten
234548	Schweinepiekser des Obersten Kriegsfürsten
234549	Kriegsstab des Obersten Kriegsfürsten
234550	Zauberklinge des Obersten Kriegsfürsten
234551	Streitkolben des Obersten Kriegsfürsten
234552	Schwert des Obersten Kriegsfürsten
234553	Schnellklinge des Obersten Kriegsfürsten
234554	Spaltbeil des Obersten Kriegsfürsten
234555	Knüttel des Obersten Kriegsfürsten
234556	Schneide des Obersten Kriegsfürsten
234557	Rechte Klaue des Obersten Kriegsfürsten
234558	Linke Klaue des Obersten Kriegsfürsten
234559	Doppelbogen des Obersten Kriegsfürsten
234560	Armbrust des Obersten Kriegsfürsten
234561	Der Straßenfeger des Obersten Kriegsfürsten
234562	Schildwall des Obersten Kriegsfürsten
234563	Zerstörungsfoliant des Obersten Kriegsfürsten
234564	Heilungsfoliant des Obersten Kriegsfürsten
234565	Claymore des Großmarschalls
234566	Zerreißer des Großmarschalls
234567	Schlachthammer des Großmarschalls
234568	Verwüster des Großmarschalls
234569	Gleve des Großmarschalls
234570	Stangenwaffe des Großmarschalls
234571	Stab des Großmarschalls
234574	Magierklinge des Großmarschalls
234576	Kriegshammer des Großmarschalls
234578	Langschwert des Großmarschalls
234579	Schnellklinge des Großmarschalls
234580	Handaxt des Großmarschalls
234581	Prügler des Großmarschalls
234582	Langdolch des Großmarschalls
234583	Rechte Handklinge des Großmarschalls
234584	Linke Handklinge des Großmarschalls
234585	Bullseye des Großmarschalls
234586	Repetierarmbrust des Großmarschalls
234587	Handkanone des Großmarschalls
234588	Aegis des Großmarschalls
234589	Machtfoliant des Großmarschalls
234590	Wiederherstellungsfoliant des Großmarschalls
234614	Leerenberührtes Emblem
234650	Uralter Qirajizerfetzer
234747	Faust des Cenarius
234748	Tiefsteinarmschienen
234749	Kugel der Erdruhe
234760	Felszornarmschienen
234761	Macht des Cenarius
234779	Erdanmut
234780	Band der Erdmacht
234782	Erdmachtweste
234785	Handschuhe der Erdstärke
234786	Band des Erdzorns
234788	Erdgewebeumhang
234792	Ravenholdtschnitzler
234793	Shivsprokets Messer
234797	Donnerholzschüreisen
234798	Schicksalsbringer
234799	Fahrads selbstladende Repetierarmbrust
234800	Simones Hammer der Kultivierung
234801	Amulett des gefallenen Gottes
234802	Umhang des gefallenen Gottes
234803	Ring des gefallenen Gottes
234804	Gesegnete Qirajikriegsaxt
234805	Gesegnete Qirajimuskete
234806	Gesegneter Qirajipugio
234807	Gesegneter Qirajischild
234808	Gesegneter Akolythenstab der Qiraji
234809	Gesegneter Weissagungsstab der Qiraji
234810	Gesegneter Qirajikriegshammer
234811	Glücksbringer der Sandstürme
234812	Amulett der Sandstürme
234813	Halsschmuck der Sandstürme
234814	Anhänger der Sandstürme
234960	Zügel des blutverkrusteten Tigers
234961	Pfeife des blutverkrusteten Raptors
234962	Jadeveredelte Trachten
234963	Merkwürdig glyphenverzierte Beinplatten
234964	Siegelring des bronzenen Drachenschwarms
234965	Siegelring des bronzenen Drachenschwarms
234966	Siegelring des bronzenen Drachenschwarms
234967	Siegelring des bronzenen Drachenschwarms
234968	Siegelring des bronzenen Drachenschwarms
234974	Stab der Qirajipropheten
234975	Hammer von Ji'zhi
234976	Zauberstab des Qirajiadels
234977	Silithidenklaue
234978	Kiefer des Sandhäschers
234979	Geschärfter Silithidenknochen
234980	Huhurans Stachel
234981	Kalimdors Rache
234983	Larve des großen Wurms
234984	Stich des Todes
234985	Dunkle Schneide des Irrsinns
234986	Kriegshammer des Anubisath
234987	Neretzek der Bluttrinker
234989	Opferdolch der Qiraji
234990	Menschentöter der Qiraji
234991	Bogen der straffen Sehne
234992	Stachel von Ayamiss
234993	Armbrust der bevorstehenden Verdammnis
234994	Sandpolierter Hammer
234995	Stab der Ruinen
234996	Hammer der Qirajigewalt
234997	Silithidhülsenzünder
234998	Der verlorene Kris von Zedd
234999	Gesegneter Qirajikriegshammer
235000	Gesegneter Weissagungsstab der Qiraji
235001	Gesegneter Akolythenstab der Qiraji
235002	Gesegneter Qirajipugio
235003	Gesegnete Qirajikriegsaxt
235004	Gesegnete Qirajimuskete
235005	Sichel der unnachgiebigen Stärke
235006	Dolch der Schattenschleier
235007	Sense des unsichtbaren Pfads
235008	Kris der ungesagten Namen
235009	Hammer der aufziehenden Stürme
235010	Hammer der unendlichen Weisheit
235011	Klinge der ewigen Gerechtigkeit
235012	Streitkolben des endlosen Lebens
235013	Klinge der behüteten Geheimnisse
235014	Szepter des falschen Propheten
235039	Pläne: Dicke Obsidianbrustplatte
235040	Dicke Obsidianbrustplatte
235045	Imperiale Qirajiinsignien
235046	Imperiale Qirajiwaffe
235047	Handschuhe des gefallenen Propheten
235048	Kopf von Ossirian dem Narbenlosen
235049	In Alpträume gehüllter Gegenstand
235133	Formel: Buchband der Rechtschaffenheit
235134	Formel: Buchband des Exorzisten
235135	Formel: Buchband der Heiligkeit
235136	Formel: Totem des pyroklastischen Donners
235137	Formel: Totem der donnernden Schläge
235138	Formel: Totem des fließenden Magmas
235139	Formel: Götze des siderischen Zorns
235140	Formel: Götze der Katzenwildheit
235141	Formel: Götze der Bärenwut
235142	Blutbedeckte Silbermünze
235143	Blutbedeckte Goldmünze
235144	Beutel mit blutbedeckten Kupfermünzen
235145	Beutel mit blutbedeckten Silbermünzen
235275	Portalkartenset
235276	Elementarkartenset
235277	Kriegsfürstenkartenset
235278	Bestienkartenset
235282	Fühler der Kräftigung
235473	Barrikade des Großmarschalls
235474	Barrikade des Obersten Kriegsfürsten
235476	Hackbeil des Obersten Kriegsfürsten
235477	Knochenknacker des Obersten Kriegsfürsten
235478	Klinge des Obersten Kriegsfürsten
235479	Klinge des Großmarschalls
235480	Knochenknacker des Großmarschalls
235481	Hackbeil des Großmarschalls
235497	Trunk der Sande
235511	Makelloser gelber Qirajiresonanzkristall
235512	Makelloser grüner Qirajiresonanzkristall
235513	Makelloser blauer Qirajiresonanzkristall
235514	Makelloser roter Qirajiresonanzkristall
235517	Fackel
235526	Formel: Armschiene - Zaubermacht
235528	Formel: Armschiene - Beweglichkeit
235529	Obsidianzielfernrohr
235530	Bauplan: Obsidianzielfernrohr
235597	Zaubernotizen: Tieffrieren
235598	Zaubernotizen: Eisige Adern
235599	Zaubernotizen: Zeitanomalie
235600	Rune des göttlichen Sturms
235601	Rune des Fanatismus
235602	Rune des Hammers der Rechtschaffenen
235603	Rune der rechtschaffenen Vergeltung
235604	Rune des Schilds der Rechtschaffenheit
235605	Rune der schockierenden Ehrfurcht
235785	"Schlüssel" für Totenwindkäfig
235786	Karazhankuriosität
235787	Uralter Eisenholzzweig
235788	Enthusiastischer Irrwisch
235789	Flamme des Lebens
235790	Verzauberter Feuerbrand
235825	Trunk der Sande
235852	Violettes Säckchen
235867	Pergamentfetzen
235868	Bollwerk des Zorns
235869	Gugel des Meisters
235870	Kettenrasselnhelm
235871	Klammernder Todeshelm
235872	Pirscherbänder
235873	Wächter der Gruft
235874	Kultistenhandwickel
235875	Handschuhe des Grabschauflers
235876	Handschützer des Sünders
235877	Fanatikerstulpen
235878	Unheilvoller Gürtel
235879	Gelenkige Ketten
235880	Bettelsohlen
235881	Schreckliche Treter
235882	Klappernde Schritte
235883	Stolperer des Brunnentauchers
235884	Spektralsignet
235885	Schauriger Ring
235886	Kaigys Klammer
235887	Barians Halsband
235888	Prügelstecken
235889	Stecken des Bediensteten
235890	Schattenwebernadel
235891	Die gute Alte
235892	Rückgrat des Dunkelreiters
235893	Schattengebundenes Grimoire
235894	Niedergang des Verdammnisverkünders
236002	Komponentenliste
236005	Brustplatte des Schreckenspanzers
236006	Beinplatten des Schreckenspanzers
236007	Helm des Schreckenspanzers
236008	Schulterstücke des Schreckenspanzers
236009	Sabatons des Schreckenspanzers
236010	Stulpen des Schreckenspanzers
236011	Taillenschutz des Schreckenspanzers
236012	Armschienen des Schreckenspanzers
236013	Ring des Schreckenspanzers
236014	Kürass des Schreckenspanzers
236015	Tassetten des Schreckenspanzers
236016	Hörner des Schreckenspanzers
236017	Schultern des Schreckenspanzers
236018	Beinschützer des Schreckenspanzers
236019	Handschutz des Schreckenspanzers
236020	Gürtel des Schreckenspanzers
236021	Handgelenke des Schreckenspanzers
236022	Band des Schreckenspanzers
236023	Brustplatte der Knochensense
236024	Beinplatten der Knochensense
236025	Helm der Knochensense
236026	Schulterstücke der Knochensense
236027	Sabatons der Knochensense
236028	Stulpen der Knochensense
236029	Taillenschutz der Knochensense
236030	Armschienen der Knochensense
236031	Ring der Knochensense
236032	Gürtel der Knochensense
236033	Treter der Knochensense
236034	Band der Knochensense
236035	Mantel der Knochensense
236036	Gamaschen der Knochensense
236037	Maske der Knochensense
236038	Handschutz der Knochensense
236039	Brustschutz der Knochensense
236040	Handgelenksschutz der Knochensense
236041	Ring des Gruftpirschers
236042	Handgelenksschutz des Gruftpirschers
236043	Tunika des Gruftpirschers
236044	Schiftung des Gruftpirschers
236045	Beinschützer des Gruftpirschers
236046	Kopfstück des Gruftpirschers
236047	Handschützer des Gruftpirschers
236048	Gurt des Gruftpirschers
236049	Stiefel des Gruftpirschers
236050	Unterarmschienen des Gruftpirschers
236051	Gürtel des Gruftpirschers
236052	Schulterstücke des Gruftpirschers
236053	Gamaschen des Gruftpirschers
236054	Visier des Gruftpirschers
236055	Stulpen des Gruftpirschers
236056	Band des Gruftpirschers
236057	Gamaschen des Gruftpirschers
236058	Brustplatte des Gruftpirschers
236059	Sandalen des verseuchten Herzens
236060	Gamaschen des verseuchten Herzens
236061	Bindungen des verseuchten Herzens
236062	Robe des verseuchten Herzens
236063	Handschuhe des verseuchten Herzens
236064	Reif des verseuchten Herzens
236065	Schulterpolster des verseuchten Herzens
236066	Gürtel des verseuchten Herzens
236067	Ring des verseuchten Herzens
236068	Handgelenksschutz des verseuchten Herzens
236069	Taillenschutz des verseuchten Herzens
236070	Mantel des verseuchten Herzens
236071	Hosen des verseuchten Herzens
236072	Krone des verseuchten Herzens
236073	Handschützer des verseuchten Herzens
236074	Schleife des verseuchten Herzens
236075	Stiefel des verseuchten Herzens
236076	Gewand des verseuchten Herzens
236077	Frostfeuerbindungen
236078	Frostfeuergürtel
236079	Frostfeuergamaschen
236080	Frostfeuersandalen
236081	Frostfeuerrobe
236082	Frostfeuerhandschuhe
236083	Frostfeuerreif
236084	Frostfeuerschulterpolster
236085	Frostfeuerring
236087	Frostfeuergelenkbänder
236088	Frostfeuertaillenschutz
236089	Frostfeuermantel
236090	Frostfeuerhosen
236091	Frostfeuerkapuze
236092	Frostfeuerfäustlinge
236093	Frostfeuerband
236094	Frostfeuerstiefel
236095	Frostfeuergewand
236097	Robe des Glaubens
236098	Gürtel des Glaubens
236099	Sandalen des Glaubens
236100	Bindungen des Glaubens
236101	Gamaschen des Glaubens
236102	Schulterpolster des Glaubens
236103	Reif des Glaubens
236104	Handschuhe des Glaubens
236105	Ring des Glaubens
236106	Handgelenke des Glaubens
236107	Gurt des Glaubens
236108	Mantelung des Glaubens
236109	Hose des Glaubens
236110	Reif des Glaubens
236111	Hände des Glaubens
236112	Band des Glaubens
236113	Stiefel des Glaubens
236114	Gewand des Glaubens
236115	Tunika der Erlösung
236116	Ring der Erlösung
236117	Kopfstück der Erlösung
236118	Handschützer der Erlösung
236119	Handgelenksschutz der Erlösung
236120	Gurt der Erlösung
236121	Beinschützer der Erlösung
236122	Schiftung der Erlösung
236123	Stiefel der Erlösung
236124	Unterarmschienen der Erlösung
236125	Gürtel der Erlösung
236126	Schulterplatten der Erlösung
236127	Gamaschen der Erlösung
236128	Helmkappe der Erlösung
236129	Handschuhe der Erlösung
236130	Band der Erlösung
236131	Schienbeinschützer der Erlösung
236132	Brustplatte der Erlösung
236133	Armschienen der Erlösung
236134	Taillenschutz der Erlösung
236135	Schulterstücke der Erlösung
236136	Beinplatten der Erlösung
236137	Krone der Erlösung
236138	Stulpen der Erlösung
236139	Schleife der Erlösung
236140	Sabatons der Erlösung
236141	Brustschutz der Erlösung
236142	Handschützer des Erdspalters
236143	Beinschützer des Erdspalters
236144	Kopfstück des Erdspalters
236145	Schiftung des Erdspalters
236146	Stiefel des Erdspalters
236147	Tunika des Erdspalters
236148	Gurt des Erdspalters
236149	Handgelenksschutz des Erdspalters
236150	Ring des Erdspalters
236151	Bindungen des Erdspalters
236152	Kordel des Erdspalters
236153	Mantel des Erdspalters
236154	Kilt des Erdspalters
236155	Krone des Erdspalters
236156	Fäustlinge des Erdspalters
236157	Band des Erdspalters
236158	Beinschützer des Erdspalters
236159	Umklammerung des Erdspalters
236160	Armschienen des Erdspalters
236162	Taillenschutz des Erdspalters
236163	Schulterstücke des Erdspalters
236164	Beinplatten des Erdspalters
236165	Gesichtsschutz des Erdspalters
236166	Handschuhe des Erdspalters
236167	Schleife des Erdspalters
236168	Sabatons des Erdspalters
236169	Brustschutz des Erdspalters
236170	Unterarmschienen des Erdspalters
236171	Gürtel des Erdspalters
236172	Schulterklappen des Erdspalters
236173	Gamaschen des Erdspalters
236174	Helmkappe des Erdspalters
236175	Handschutz des Erdspalters
236176	Siegel des Erdspalters
236177	Treter des Erdspalters
236179	Rüstung des Erdspalters
236182	Kopfstück des Traumwandlers
236183	Handgelenksschutz des Traumwandlers
236184	Handschützer des Traumwandlers
236185	Stiefel des Traumwandlers
236186	Tunika des Traumwandlers
236187	Gurt des Traumwandlers
236188	Beinschützer des Traumwandlers
236189	Schiftung des Traumwandlers
236190	Ring des Traumwandlers
236192	Bindungen des Traumwandlers
236193	Kordel des Traumwandlers
236194	Mantelung des Traumwandlers
236195	Kilt des Traumwandlers
236196	Kapuze des Traumwandlers
236197	Fäustlinge des Traumwandlers
236198	Band des Traumwandlers
236199	Sandalen des Traumwandlers
236200	Lederrüstung des Traumwandlers
236201	Armschienen des Traumwandlers
236202	Taillenschutz des Traumwandlers
236203	Schulterstücke des Traumwandlers
236204	Gamaschen des Traumwandlers
236205	Kopfputz des Traumwandlers
236206	Stulpen des Traumwandlers
236207	Schleife des Traumwandlers
236208	Sabatons des Traumwandlers
236209	Rüstung des Traumwandler
236210	Wickel des Traumwandlers
236211	Schärpe des Traumwandlers
236212	Schulterpolster des Traumwandlers
236213	Beinkleider des Traumwandlers
236214	Gugel des Traumwandlers
236215	Handschutz des Traumwandlers
236216	Signet des Traumwandlers
236217	Stampfer des Traumwandlers
236218	Weste des Traumwandlers
236219	Verdammnisbote
236220	Gewand des Nekroritters
236221	Verlegter Servoarm
236222	Ghulhauttunika
236223	Ring der ewigen Flamme
236224	Stygischer Rundschild
236225	Gurt des Elementarfurors
236226	Schulterstücke des Elementarfurors
236227	Gürtel des obersten Kreuzzüglers
236228	Schiftung des obersten Kreuzzüglers
236229	Gamaschen des obersten Kreuzzüglers
236230	Gamaschen des Elementarfurors
236231	Entweihte Brustplatte
236232	Entweihter Taillenschutz
236233	Entweihte Stulpen
236234	Entweihte Sabatons
236235	Entweihte Armschienen
236236	Entweihter Helm
236237	Entweihte Schulterstücke
236238	Entweihte Beinplatten
236239	Entweihte Sandalen
236240	Entweihte Schulterpolster
236241	Entweihter Reif
236242	Entweihte Robe
236243	Entweihte Handschuhe
236244	Entweihter Gürtel
236245	Entweihte Bindungen
236246	Entweihte Gamaschen
236247	Entweihter Handgelenksschutz
236248	Entweihte Stiefel
236249	Entweihtes Kopfstück
236250	Entweihte Handschützer
236251	Entweihte Tunika
236252	Entweihter Gurt
236253	Entweihte Beinschützer
236254	Entweihte Schiftung
236255	Handgelenksschutz der Rache
236256	Berührung des Frosts
236257	Edelstein von Nerubis
236258	Seidenumhang der Gruftsatanskreatur
236259	Band der unerhörten Gebete
236260	Eisfluchschulterstücke
236261	Heimtückischer Steinanhänger
236262	Polarschulterpolster
236263	Reue der Witwe
236264	Umarmung der Witwe
236265	Gespensterklinge
236266	Anhänger der vergessenen Namen
236267	Kristallgewebte Robe
236268	Kuss der Spinne
236269	Maexxnas Fangzahn
236270	Knochenspalterbeil
236271	Buchband des Lichts
236272	Umhang der Geißel
236273	Band des Unvermeidlichen
236274	Hagelschauerband
236275	Noths kaltes Herz
236276	Totem des Wasserlaufs
236277	Halskette der Leichenschau
236278	Gletscherkopfputz
236279	Hut des Mentors
236280	Beinplatten des Blutbads
236281	Eisschuppenhelmkappe
236282	Loathebs Abglanz
236283	Ring des Seeleneifers
236284	Schwefelstab
236285	Das Auge Nerubs
236286	Band der unnatürlichen Kräfte
236287	Wundspalter
236288	Der Seuchenbringer
236289	Umhang der Wundnaht
236290	Zauberstab der Heimsuchung
236291	Band des neuen Lebens
236292	Mitternachtsnebel
236293	Toxindüse
236294	Eisschuppenschiftung
236295	Gletschermantel
236296	Todeshandel
236297	Das Ende aller Träume
236298	Reifbedeckter Mantel
236299	Claymore der unheiligen Kraft
236300	Gluths verschollenes Halsband
236301	Faulige Hand der Macht
236302	Auge des Schwunds
236303	Gamaschen des Widerspruchs
236304	Gepanzerter Monstrositätenbrustkorb
236305	Spitze des Zwiespalts
236306	Der Bestrafer
236307	Schleier der Finsternis
236308	Götze der Langlebigkeit
236309	Gurt des Mentors
236310	Zauberstab des flüsternden Todes
236311	Siegel des gefallenen Verteidigers
236312	Iblis, Klinge des gefallenen Engels
236313	Bindungen des Seelenjägers
236314	Stiefel der Verrückung
236315	Polarhelm
236316	Sadistenhalsband
236317	Vis'era der Entweider
236318	Siegel der Verdammten
236319	Gamaschen der Apokalypse
236320	Güte der Vergebung
236321	Keule des erlösten Kreuzzüglers
236322	Seelenstrang
236323	Unverwüstlichkeit der Geißel
236324	Stärke der Geißel
236325	Standhaftigkeit der Geißel
236326	Macht der Geißel
236327	Umhang der Nekropole
236328	Saphirons linkes Auge
236329	Auge des Todes
236330	Saphirons rechtes Auge
236331	Die gebundene Essenz Saphirons
236333	Schleier der Herrschaft
236334	Wappen des Schlächters
236335	Fäuste des Unerbitterlichen
236336	Das Gesicht des Todes
236337	Glyphe der Abwehr
236338	Klaue des Frostwyrms
236339	Gressil, Vorbote des Untergangs
236340	Macht von Menethil
236341	Die zehrende Kälte
236342	Stormrages Talisman des Zorns
236343	Königsmörder
236344	Nerubischer Sklavenjäger
236345	Edelstein der gefangenen Unschuld
236346	Seelensucher
236347	Schild der Geißelung
236348	Hammer des wirbelnden Nethers
236349	Schicksalszeig
236350	Kel'Thuzads Phylakterium
236351	Mal des Helden
236352	Mal des Helden
236354	Aspirantensiegel der Dämmerung
236355	Initiandensiegel der Dämmerung
236356	Knappensiegel der Dämmerung
236357	Rittersiegel der Dämmerung
236358	Templersiegel der Dämmerung
236360	Championsiegel der Dämmerung
236361	Vorhutsiegel der Dämmerung
236362	Kreuzfahrersiegel der Dämmerung
236363	Kommandantensiegel der Dämmerung
236364	Hochlordsiegel der Dämmerung
236374	Kommandantensiegel der Dämmerung
236375	Hochlordsiegel der Dämmerung
236376	Kreuzfahrersiegel der Dämmerung
236378	Vorhutsiegel der Dämmerung
236379	Championsiegel der Dämmerung
236380	Templersiegel der Dämmerung
236382	Rittersiegel der Dämmerung
236383	Knappensiegel der Dämmerung
236384	Initiandensiegel der Dämmerung
236385	Aspirantensiegel der Dämmerung
236386	Hochlordsiegel der Dämmerung
236388	Kommandantensiegel der Dämmerung
236389	Kreuzfahrersiegel der Dämmerung
236390	Vorhutsiegel der Dämmerung
236391	Championsiegel der Dämmerung
236392	Templersiegel der Dämmerung
236393	Rittersiegel der Dämmerung
236394	Knappensiegel der Dämmerung
236395	Initiandensiegel der Dämmerung
236396	Aspirantensiegel der Dämmerung
236397	Überreste der Tapferkeit
236398	Atiesh, Hohestab des Wächters
236399	Atiesh, Hohestab des Wächters
236400	Atiesh, Hohestab des Wächters
236401	Atiesh, Hohestab des Wächters
236414	Beschädigte Vorratskiste aus Undermine
236417	Seele des Taktikers
236418	Seele des Kriegsveteranen
236419	Seele des Kampfvoraussehers
236420	Seele des Blutsuchers
236421	Seele des Titanischen
236422	Seele des Zerstörers
236423	Seele des Todesgebundenen
236424	Seele des Bluters
236425	Seele des makellosen Blockers
236426	Seele des Wilden
236427	Seele der Feindseligkeit
236428	Seele des Parierenden
236429	Seele des Rächers
236430	Seele des Unermüdlichen
236431	Seele des Donnerbringers
236432	Seele der Schildwache
236433	Seele des Rechtsauslegers
236434	Seele des Gladiators
236435	Seele des Nachbebens
236436	Seele des Vermeidenden
236437	Seele des Toxikologen
236438	Seele des Scharfrichters
236439	Seele des Opportunisten
236440	Seele des Schlächters
236441	Seele des Phantoms
236442	Seele des Halunken
236443	Seele des Abenteuerlustigen
236444	Seele des Messerkenners
236445	Seele des Pirschers
236446	Seele des Effizienten
236447	Seele des Messerjongleurs
236448	Seele des Schattenmeisters
236449	Seele des Akrobaten
236450	Seele des protzigen Prüglers
236451	Seele des schwarzen Gurts
236452	Seele des Fechters
236453	Seele des Säbelrasslers
236454	Seele des Blutrünstigen
236455	Seele des Transfusionisten
236456	Seele des Verfeinerten
236457	Seele des Dezimierers
236458	Seele des Fäulnisbringers
236459	Seele des Böswilligen
236460	Seele des Schattenbeschwörers
236461	Seele des Chaosherolds
236462	Seele des Brandstifters
236463	Seele des infernalen Schäfers
236464	Seele des Dämonenfürsten
236465	Seele des dämonischen Exorzisten
236466	Seelen des Leidenden
236467	Seele des Flammengespensts
236468	Seele des Fleischverzehrers
236469	Seele des Abyssals
236470	Seele des Leerengeborenen
236471	Seele der Umbralklinge
236472	Seele des Ritualisten
236473	Seele des Schmerzverbreiters
236474	Seele des Irreführers
236475	Seele des Beutesuchers
236476	Seele des Scharfschützen
236477	Seele des Gefahrenplünderers
236478	Seele des Wechslers
236479	Seele des Toxinologen
236480	Seele des Kopfgeldjägers
236481	Seele des Trickschützen
236482	Seele des Tierpflegers
236483	Seele des Hundemeisters
236484	Seele des Alphazähmers
236485	Seele des Waidmanns
236487	Seele des Vergelters
236488	Seele des Widerhalls
236489	Seele des tödlichen Peitschers
236490	Seele des Kinetikers
236491	Seele des Strategen
236492	Seele des Totschlägers
236493	Seele des beschleunigten Heilers
236494	Seele des Verfeinerten
236495	Seele der Zelebranten
236496	Seele des Treuen
236497	Seele des Glücklichen
236498	Seele des Resonanten
236499	Seele des Verehrers
236500	Seele des Erzbischofs
236501	Seele des Bußfertigen
236502	Seele des Seelenwächters
236503	Seele des Zwielichtwandlers
236504	Seele des Gedankenstörers
236505	Seele des Todesboten
236506	Seele des Willensquells
236507	Seele des Zeloten
236508	Seele des unnachgiebigen Schänders
236509	Seele des Verächters
236510	Seele des Seuchenbringers
236511	Seele des Nachhallenden
236512	Seele des Chronoheilers
236513	Seele des Temporalverlangens
236514	Seele des Präkognitiven
236515	Seele des Arkanisten
236516	Seele des ewigen Hüters
236517	Seele des Zauberbinders
236518	Seele des Schutzformers
236519	Seele der Klauen des Winters
236520	Seele des Kryomanten
236521	Seele des Rufers
236522	Seele des Elementaristen
236523	Seele des magischen Rüstungsschmieds
236524	Seele des Zündlers
236525	Seele der feurigen Konvergenz
236526	Seele der immerwährenden Flamme
236527	Seele des Pyromanen
236528	Seele des Entzünders
236529	Seele des Facklers
236530	Seele des makellosen Blockers
236531	Seele des Lichthüters
236532	Seele des strahlenden Verteidigers
236533	Seele des Schildträgers
236534	Seele der Bastion
236535	Seele des Abrechners
236536	Seele des Gepanzerten
236537	Seele des Behüters
236538	Seele des Friedensbewahrers
236539	Seele des Verfeinerten
236540	Seele des Exemplars
236541	Seele des Inquisitors
236542	Seele des Überlegenen
236543	Seele des Dominus
236544	Seele des Verteidigers
236545	Seele des Altruisten
236546	Seele des Richters
236547	Seele des Siegelträgers
236548	Seele des Vollstreckers
236549	Seele des Judikators
236550	Seele des Aszendenten
236551	Seele des Maßreglers
236552	Seele des Exkommunikators
236553	Seele des Lichtbringers
236554	Seele des Verbannten
236555	Seele des Templers
236556	Seele des Windläufers
236557	Seele des Schildmeisters
236558	Seele des Totembeschützers
236559	Seele des Schockabsorbers
236560	Seele des spirituellen Bollwerks
236561	Seele des Mahlstrombringers
236562	Seele des Lavawandlers
236563	Seele des wahren Alphas
236564	Seele des Totemhüters
236565	Seele der Ahnen
236566	Seele des Geisterwebers
236567	Seele des Wasserwandlers
236568	Seele des Sturmpflegers
236569	Seele des Elementarsehers
236570	Seele des Vitalisten
236571	Seele des Geisterheilers
236572	Seele des Verfeinerten
236573	Seele des Häuptlings
236574	Seele des Zorngeladenen
236575	Seele des Sturmbrechers
236576	Seele des Orkans
236577	Seele des seismischen Schmetterers
236578	Seele des Flammenbringers
236579	Seele des Vulkans
236580	Seele der tobenden Flamme
236581	Seele des Elementarmeisters
236582	Seele des Stammesangehörigen
236583	Seele des Geisterführers
236584	Seele des Ältesten
236585	Seele der Elemente
236586	Seele des Lavaweisen
236587	Seele des Ahnenwächters
236588	Seele des Verderbten
236589	Seele der sanften Pfote
236590	Seele des Wilden
236591	Seele des Wandlers
236592	Seele des Territorialen
236593	Seele der Bestie
236594	Seele des Aufschlitzers
236595	Seele des Rasenden
236596	Seele des Zerfleischers
236597	Seele des Anregers
236598	Seele des Nährers
236599	Seele des Gelassenen
236600	Seele des Traumwandlers
236601	Seele des Hainhüters
236602	Seele des gefiederten Weisen
236603	Seele des gütigen Sehers
236604	Seele des Lebenswebers
236605	Seele des Erleuchters
236606	Seele der räuberischen Instinkte
236607	Seele des Zerfetzers
236608	Seele der Klaue
236609	Seele des Stolzes
236610	Seele des Barbarischen
236611	Seele des Fieberhaften
236612	Seele des Ausbluters
236613	Seele des Dornenhüters
236614	Seele des Irren
236615	Seele des Sternrufers
236616	Seele der Nacht
236617	Seele der Bewahrer
236618	Seele des Wutentbrannten
236619	Seele des Anmutigen
236620	Seele des astralen Aszendenten
236621	Seele des Kometenrufers
236622	Seele des Waldes
236623	Seele der animalischen Expertise
236642	Heilerhandlappen
236643	Handschuhe des Nachtwächters
236644	Handschützer des Trauernden
236645	Handschuhe des Lichtwirkers
236656	Gefrorene Rune
236657	Blubbis modernder Ast
236658	Blubbis Rückgrattrophäe
236660	Blubbis Trollhauer
236661	Blubbis Brustkorb der Obszönität
236662	Zügel des Krieges
236663	Zügel der Eroberung
236664	Zügel des Todes
236665	Zügel der Hungersnot
236690	Gletscherumhang
236692	Gletscherhandschuhe
236693	Gletscherhandschutz
236694	Gletscherweste
236695	Eisfluchbrustplatte
236696	Eisflucharmschienen
236697	Eisfluchstulpen
236698	Eisschuppenarmschienen
236699	Eisschuppenbrustplatte
236700	Eisschuppenstulpen
236701	Polararmschienen
236702	Polartunika
236703	Polarhandschuhe
236704	Frostige Handgelenke
236705	Frostige Handschuhe
236706	Frostige Weste
236707	Tunika des Untotenschlachtens
236708	Brustplatte des Untotenschlachtens
236709	Brustschutz des Untotenschlachtens
236710	Handgelenksschutz des Untotenschlachtens
236711	Gelenkbänder des Untotenschlachtens
236712	Armschienen des Untotenschlachtens
236713	Handlappen des Untotenschlachtens
236714	Stulpen des Untotenschlachtens
236715	Handschützer des Untotenschlachtens
236716	Armschienen der Untotenbekämpfung
236717	Handschuhe der Untotenbekämpfung
236718	Robe der Untotenbekämpfung
236719	Armschienen der Untotenläuterung
236720	Handschuhe der Untotenläuterung
236721	Robe der Untotenläuterung
236722	Armschienen des Untotenschutzes
236723	Handschuhe des Untotenschutzes
236724	Robe des Untotenschutzes
236725	Gelenkbänder der Untotenbekämpfung
236726	Handlappen der Untotenbekämpfung
236727	Tunika der Untotenbekämpfung
236728	Gelenkbänder der Untotenläuterung
236729	Handlappen der Untotenläuterung
236730	Tunika der Untotenläuterung
236731	Gelenkbänder des Untotenschutzes
236732	Handlappen des Untotenschutzes
236733	Tunika des Untotenschutzes
236734	Handgelenksschutz der Untotenbekämpfung
236735	Handschützer der Untotenbekämpfung
236736	Brustschutz der Untotenbekämpfung
236737	Handgelenksschutz des Untotenschutzes
236738	Handschützer des Untotenschutzes
236739	Brustschutz des Untotenschutzes
236740	Handgelenksschutz der Untotenläuterung
236741	Handschützer der Untotenläuterung
236742	Brustschutz der Untotenläuterung
236743	Armschienen der Untotenläuterung
236744	Stulpen der Untotenläuterung
236745	Brustplatte der Untotenläuterung
236746	Armschienen des Untotenschutzes
236747	Stulpen des Untotenschutzes
236748	Brustplatte des Untotenschutzes
236750	Herz der Verdammnis
236782	Sairuhs Halsband
236786	Herz der Verdammnis
236864	Seelenfrostköcher
236869	Seelenfrostmunitionsbeutel
236871	Gruselige Zensorensensoren
236872	Bauplan: Gruselige Zensorensensoren
236878	Geheimnisvolles Relikt
236879	Geheimnisvolles Relikt
236880	Geheimnisvolles Relikt
237011	Fallgatterschlüssel
237020	Scharlachrotes Insigne
237023	Aufstellbäumchen
237024	Opernticket
237037	Mitgliedsausweis des Gourmetclubs
237041	Foliant der Zauberflamme
237143	Befehle von der Kommandantin
237163	Schädel eines uralten Helden
237261	Feiner Sand
237263	Vorratstasche
237275	Eisfluchhelm
237277	Frostige Gamaschen
237278	Der Läuterer
237279	Amulett der Dämmerung
237280	Medaillon der Dämmerung
237281	Armschienen der Hoffnung
237282	Armschienen der Täuschung
237283	Talisman der Überlegenheit
237284	Vorratstasche
237285	Band der Resolution
237286	Band der Frömmigkeit
237287	Verimondes letzter Ausweg
237288	Geweihter Lederhelm
237289	Gamaschen des Seuchenjägers
237290	Eisfluchgamaschen
237291	Gletschergamaschen
237292	Polargamaschen
237293	Eisschuppengamaschen
237294	Ramaladnis eisiger Griff
237302	Wams der Scharlachroten Enklave
237381	Entweihter Ring
237386	Kampfzerschlissene Vorratskiste aus Undermine
237504	Versorgungslieferung
237512	Klinge der Inquisition
237577	Totem der unheiligen Kraft
237773	Wort des Tauens
237810	Beschwerter geweihter Wetzstein
237814	Lamellenbeinschützer der Schildwache
237815	Seidene Gamaschen der Schildwache
237817	Echsenlederhose der Schildwache
237818	Lederhose der Schildwache
237819	Kettengamaschen der Schildwache
237820	Seidene Gamaschen der Vorhut
237821	Echsenlederhose der Vorhut
237822	Lederhose der Vorhut
237823	Panzergamaschen der Vorhut
237824	Kettengamaschen der Vorhut
237825	Plattenbeinschützer der Schildwache
237826	Plattenbeinschützer der Vorhut
238234	Gesegnetes Zauberöl
238241	Geweihter Wetzstein
238264	Kapuze des scharlachroten Auguren
238265	Mantel des scharlachroten Auguren
238266	Gewand des scharlachroten Auguren
238267	Manschetten des scharlachroten Auguren
238268	Fäustlinge des scharlachroten Auguren
238269	Riemen des scharlachroten Auguren
238270	Gamaschen des scharlachroten Auguren
238271	Sohlen des scharlachroten Auguren
238272	Bandana des scharlachroten Spitzels
238273	Schulterschützer des scharlachroten Spitzels
238274	Weste des scharlachroten Spitzels
238275	Armschienen des scharlachroten Spitzels
238276	Handschuhe des scharlachroten Spitzels
238277	Gürtel des scharlachroten Spitzels
238278	Beinkleider des scharlachroten Spitzels
238279	Schuhe des scharlachroten Spitzels
238280	Kappe des scharlachroten Jägers
238281	Schulterstücke des scharlachroten Jägers
238282	Kette des scharlachroten Jägers
238283	Handgelenksschützer des scharlachroten Jägers
238284	Handschützer des scharlachroten Jägers
238285	Schnalle des scharlachroten Jägers
238286	Beinschützer des scharlachroten Jägers
238287	Stiefel des scharlachroten Jägers
238288	Helm des scharlachroten Soldaten
238289	Schiftung des scharlachroten Soldaten
238290	Brustplatte des scharlachroten Soldaten
238291	Schützer des scharlachroten Soldaten
238292	Handschutz des scharlachroten Soldaten
238293	Taillenschutz des scharlachroten Soldaten
238294	Beinplatten des scharlachroten Soldaten
238295	Stampfer des scharlachroten Soldaten
238298	Muster: Kapuze des scharlachroten Auguren
238299	Muster: Mantel des scharlachroten Auguren
238300	Muster: Gewand des scharlachroten Auguren
238301	Muster: Manschetten des scharlachroten Auguren
238302	Muster: Fäustlinge des scharlachroten Auguren
238303	Muster: Riemen des scharlachroten Auguren
238304	Muster: Gamaschen des scharlachroten Auguren
238305	Muster: Sohlen des scharlachroten Auguren
238306	Muster: Bandana des scharlachroten Spitzels
238307	Muster: Schulterschützer des scharlachroten Spitzels
238308	Muster: Weste des scharlachroten Spitzels
238309	Muster: Armschienen des scharlachroten Spitzels
238310	Muster: Handschuhe des scharlachroten Spitzels
238311	Muster: Gürtel des scharlachroten Spitzels
238312	Muster: Beinkleider des scharlachroten Spitzels
238313	Muster: Schuhe des scharlachroten Spitzels
238314	Muster: Kappe des scharlachroten Jägers
238315	Muster: Schulterstücke des scharlachroten Jägers
238316	Muster: Kette des scharlachroten Jägers
238317	Muster: Handgelenksschützer des scharlachroten Jägers
238318	Muster: Handschützer des scharlachroten Jägers
238319	Muster: Schnalle des scharlachroten Jägers
238320	Muster: Beinschützer des scharlachroten Jägers
238321	Muster: Stiefel des scharlachroten Jägers
238322	Pläne: Helm des scharlachroten Soldaten
238323	Pläne: Schiftung des scharlachroten Soldaten
238324	Pläne: Brustplatte des scharlachroten Soldaten
238325	Pläne: Schützer des scharlachroten Soldaten
238326	Pläne: Handschützer des scharlachroten Soldaten
238327	Pläne: Taillenschutz des scharlachroten Soldaten
238328	Pläne: Beinplatten des scharlachroten Soldaten
238329	Pläne: Stampfer des scharlachroten Soldaten
238348	Die Axt des Zerspaltens
238349	Gamaschen aus Monstrositätenhaut
238350	Fokusdolch des Verächters
238351	Der eisige Griff
238352	Eisiger Halsschmuck des Verächters
238353	Mantel von Lady Falther'ess
238354	Finger von Lady Falther'ess
238355	Fesseln des Lichs
238356	Gürtelbund von Balzaphon
238357	Stab von Balzaphon
238358	Schwarzstahls Oberschenkelknochen
238360	Fürst Schwarzstahls Rundschild
238361	Fürst Schwarzstahls Klinge
238362	Armschienen der Heilung
238363	Griff des Schattens
238364	Revanchions Umhang
238637	Pirschersteak
238638	Filet aus der Flanke
238639	Morgengrauenomelett
238641	Fleckfinnenfestmahl
238642	Großes Hummerbankett
238645	Rezept: Pirschersteak
238646	Rezept: Filet aus der Flanke
238647	Rezept: Morgengrauenomelett
238649	Rezept: Fleckfinnenfestmahl
238650	Rezept: Großes Hummerbankett
238681	Staubiger Beutel
238687	Keule des Ansturms
238734	Tüftelkiste: Teleportation
238735	Tüftelkiste: Nitrobooster
238736	Tüftelkiste: Magnetversetzung
238737	Tüftelkiste
238781	Halbwegs sicherer Transporter: Neu-Avalon
238782	Bauplan: Tüftelkiste
238783	Bauplan: Tüftelkiste: Teleportation
238784	Bauplan: Tüftelkiste: Nitrobooster
238785	Bauplan: Tüftelkiste: Magnetversetzung
238786	Bauplan: Tüftelei: Teleportation
238787	Bauplan: Tüftelei: Nitrobooster
238788	Bauplan: Tüftelei: Magnetversetzung
238789	Bauplan: Halbwegs sicherer Transporter: Neu-Avalon
238794	Widerwärtige Essensreste
238811	Saftiger Apfel
238830	Apfelfernrohr
238831	Apfelseil
238899	Erlesener Fisch
238925	Scharlachroter Köcher
238926	Scharlachroter Munitionsbeutel
238927	Muster: Scharlachroter Köcher
238928	Muster: Scharlachroter Munitionsbeutel
238935	Sanft gequältes Fleisch
238945	Caladbrocken
238960	Rüstmeisterkiste
238961	Caladschneide
238985	Schwere Kiste
239010	Griff des Aschenbringers
239011	Splitter kristallisierten Lichts
239012	Span kristallisierten Lichts
239013	Kristalline Axt
239016	Weihsalz
239017	Erlesene Gewürze
239021	Carries Kochbuch
239060	Wille des Berges
239092	Bescheuert beschrifteter Brief
239097	Schlüssel zur Kathedrale
239117	Kelch des des Kreuzzüglers
239119	Heiliger Pfeil
239147	Kreuzzüglerknappsack
239148	Blutrote Morgengespinsttasche
239149	Muster: Kreuzzüglerknappsack
239150	Muster: Blutrote Morgengespinsttasche
239159	S03 - Scharlachrote Enklave - Schild des Hauptmanns
239196	Verdorbene lichtgeschmiedete Klinge
239197	Neugeschmiedete Klinge des Aschenbringers
239215	Verkohltes Emblem
239216	Lichtgeschmiedetes Eisen
239218	Notizen der Steinformer
239219	Emblem des Aschenbringers
239222	Bauplan: Aufstellbäumchen
239223	Hausrequisite
239225	Stilvoller Federkiel
239246	Zischluntes Einkaufsliste
239248	Scharlachrote Plunderkiste
239292	Forgewrights Notizen
239301	Verderbter Aschenbringer
239302	Gürtel der scharlachroten Uniform
239316	Triangulationssamophlang
239512	Handgelenke des Lichtbrechers
239513	Gürtel des Lichtbrechers
239514	Handschutz des Lichtbrechers
239515	Schienbeinschützer des Lichtbrechers
239516	Schultern des Lichtbrechers
239517	Großhelm des Lichtbrechers
239518	Tassetten des Lichtbrechers
239519	Kürass des Lichtbrechers
239520	Armschienen des Lichtbrechers
239521	Taillenschutz des Lichtbrechers
239522	Stulpen des Lichtbrechers
239523	Sabatons des Lichtbrechers
239524	Schulterstücke des Lichtbrechers
239525	Helm des Lichtbrechers
239526	Beinplatten des Lichtbrechers
239527	Brustplatte des Lichtbrechers
239529	Brustplatte des Dämmerpirschers
239530	Schienbeinschützer des Dämmerpirschers
239531	Stulpen des Dämmerpirschers
239532	Visier des Dämmerpirschers
239533	Gamaschen des Dämmerpirschers
239534	Schulterstücke des Dämmerpirschers
239535	Gürtel des Dämmerpirschers
239536	Unterarmschienen des Dämmerpirschers
239537	Stiefel des Dämmerpirschers
239538	Gurt des Dämmerpirschers
239539	Handschützer des Dämmerpirschers
239540	Kopfteil des Dämmerpirschers
239541	Beinschützer des Dämmerpirschers
239542	Schiftung des Dämmerpirschers
239543	Tunika des Dämmerpirschers
239544	Handgelenksschützer des Dämmerpirschers
239547	Handgelenksschützer des Dämmergeistes
239548	Brustschutz des Dämmergeistes
239549	Handschützer des Dämmergeistes
239550	Maske des Dämmergeistes
239551	Gamaschen des Dämmergeistes
239552	Mantel des Dämmergeistes
239553	Treter des Dämmergeistes
239554	Gürtel des Dämmergeistes
239555	Armschienen des Dämmergeistes
239556	Taillenschutz des Dämmergeistes
239557	Stulpen des Dämmergeistes
239558	Sabatons des Dämmergeistes
239559	Schulterstücke des Dämmergeistes
239560	Helm des Dämmergeistes
239561	Beinplatten des Dämmergeistes
239562	Brustplatte des Dämmergeistes
239565	Gewand der Offenbarung
239572	Stiefel der Offenbarung
239574	Hände der Offenbarung
239575	Krone der Offenbarung
239577	Hosen der Offenbarung
239581	Mantel der Offenbarung
239582	Gurt der Offenbarung
239583	Handgelenke der Offenbarung
239584	Handschuhe der Offenbarung
239585	Reif der Offenbarung
239586	Schulterpolster der Offenbarung
239587	Gamaschen der Offenbarung
239588	Bindungen der Offenbarung
239589	Sandalen der Offenbarung
239590	Gürtel der Offenbarung
239591	Robe der Offenbarung
239694	Schwur des Lichts
239695	Scharlachrotes Ross
239696	Griff des Aschenbringers
239698	Morgengespinststoff
239706	Geweihte Sabatons
239707	Geweihter Helm
239708	Geweihte Schulterstücke
239709	Geweihte Beinplatten
239710	Geweihte Sandalen
239712	Geweihte Schulterpolster
239714	Geweihter Reif
239715	Geweihte Robe
239716	Geweihte Handschuhe
239718	Geweihter Gürtel
239719	Geweihte Bindungen
239721	Geweihte Gamaschen
239722	Geweihter Handgelenksschutz
239726	Geweihte Stiefel
239729	Geweihtes Kopfstück
239730	Geweihte Handschützer
239731	Geweihte Tunika
239756	Geweihter Gurt
239757	Geweihte Beinschützer
239758	Geweihte Schiftung
239759	Geweihte Armschienen
239760	Geweihter Taillenschutz
239761	Geweihte Brustplatte
239762	Geweihte Stulpen
239764	Purpurrotes Messerblatt
240018	Zischluntes Tüftelhandbuch
240020	Beinschützer der Inquisition
240021	Schiftung der Inquisition
240022	Stiefel der Inquisition
240023	Unterarmschienen der Inquisition
240024	Gürtel der Inquisition
240025	Schulterplatten der Inquisition
240026	Gamaschen der Inquisition
240027	Helm der Inquisition
240028	Handschuhe der Inquisition
240029	Schienbeinschützer der Inquisition
240030	Brustplatte der Inquisition
240031	Armschienen der Inquisition
240032	Taillenschutz der Inquisition
240033	Schulterstücke der Inquisition
240034	Beinplatten der Inquisition
240035	Krone der Inquisition
240036	Stulpen der Inquisition
240037	Sabatons der Inquisition
240038	Brustschutz der Inquisition
240039	Tunika der Inquisition
240040	Kopfstück der Inquisition
240041	Handschützer der Inquisition
240042	Handgelenksschutz der Inquisition
240043	Gurt der Inquisition
240044	Feuerlaubhandgelenkwickel
240045	Feuerlaubtaillenschutz
240046	Feuerlaubmantel
240047	Feuerlaubhose
240048	Feuerlaubkapuze
240049	Feuerlaubfäustlinge
240050	Feuerlaubstiefel
240051	Feuerlaubgewand
240052	Feuerlaubbindungen
240053	Feuerlaubgürtel
240054	Feuerlaubschulterpolster
240055	Feuerlaubgamaschen
240056	Feuerlaubreif
240057	Feuerlaubhandschuhe
240058	Feuerlaubsandalen
240059	Feuerlaubrobe
240060	Wickel des Wegbehüters
240061	Schärpe des Wegbehüters
240062	Schulterpolster des Wegbehüters
240063	Beinkleider des Wegbehüters
240064	Gugel des Wegbehüters
240065	Handschutz des Wegbehüters
240066	Stampfer des Wegbehüters
240067	Weste des Wegbehüters
240068	Bindungen des Wegbehüters
240069	Kordel des Wegbehüters
240070	Mantel des Wegbehüters
240071	Kilt des Wegbehüters
240072	Kapuze des Wegbehüters
240073	Fäustlinge des Wegbehüters
240074	Sandalen des Wegbehüters
240075	Leder des Wegbehüters
240076	Armschienen des Wegbehüters
240077	Taillenschutz des Wegbehüters
240078	Schulterstücke des Wegbehüters
240079	Gamaschen des Wegbehüters
240080	Kopfputz des Wegbehüters
240081	Stulpen des Wegbehüters
240082	Sabatons des Wegbehüters
240083	Rüstung des Wegbehüters
240084	Handgelenksschützer des Wegbehüters
240085	Gurt des Wegbehüters
240086	Schiftung des Wegbehüters
240087	Beinschützer des Wegbehüters
240088	Kopfteil des Wegbehüters
240089	Handschützer des Wegbehüters
240090	Stiefel des Wegbehüters
240091	Tunika des Wegbehüters
240092	Tunika des Seelenbrechers
240093	Stiefel des Seelenbrechers
240095	Handschützer des Seelenbrechers
240096	Kopfstück des Seelenbrechers
240097	Beinschützer des Seelenbrechers
240098	Schiftung des Seelenbrechers
240099	Gurt des Seelenbrechers
240100	Handgelenksschützer des Seelenbrechers
240101	Brustschutz des Seelenbrechers
240102	Sabatons des Seelenbrechers
240103	Handschuhe des Seelenbrechers
240104	Gesichtsschutz des Seelenbrechers
240105	Beinplatten des Seelenbrechers
240106	Schulterstücke des Seelenbrechers
240107	Hüftschutz des Seelenbrechers
240108	Armschienen des Seelenbrechers
240109	Torsoschutz des Seelenbrechers
240110	Beinschützer des Seelenbrechers
240122	Fäustlinge des Seelenbrechers
240123	Krone des Seelenbrechers
240124	Kilt des Seelenbrechers
240125	Mantel des Seelenbrechers
240126	Kordel des Seelenbrechers
240127	Bindungen des Seelenbrechers
240128	Rüstung des Seelenbrechers
240129	Treter des Seelenbrechers
240130	Handschutz des Seelenbrechers
240131	Helm des Seelenbrechers
240134	Gamaschen des Seelenbrechers
240135	Schulterklappen des Seelenbrechers
240136	Gürtel des Seelenbrechers
240137	Unterarmschienen des Seelenbrechers
240138	Robe des Häretikers
240139	Sandalen des Häretikers
240140	Handschuhe des Häretikers
240141	Gugel des Häretikers
240142	Gamaschen des Häretikers
240143	Schulterpolster des Häretikers
240144	Gürtel des Häretikers
240145	Bindungen des Häretikers
240146	Kluft des Häretikers
240147	Handschützer des Häretikers
240148	Kapuze des Häretikers
240149	Hosen des Häretikers
240150	Mantel des Häretikers
240151	Taillenschutz des Häretikers
240152	Handgelenksschützer des Häretikers
240153	Stiefel des Häretikers
240174	Solistra, Fänge des ersten Lichts
240195	Unsichtbares Schwert
240217	Monstergegenstand - Stab_2H_Juewelenbesetzt_A_02 - Rot
240832	Schneespeidrüse
240835	Kiste mit Moongladevorräten
240836	Thisalees Pfeife
240837	Schicksalsfäden
240839	Thal'kituun, der ungesehene Gast
240841	Wache der Hochkommandantin
240842	Scharlachroter Seuchenbringer
240843	Starterpistole
240844	Putress' Stecken
240845	Prototypmagnet
240846	Magnetischer Schrott
240848	Überreste von Nordrassil
240849	Stab der Lichtung
240850	Lichtfausthammer
240851	Königsmord
240852	Purpurrotes Spaltbeil
240853	Königinnensturz
240854	Gnade
240919	Wiederheerer
240920	Leogan
240921	Scharlachroter Schadensbringer
240922	Täuschung
240923	Doppelzunge
240924	Stangenaxt der Bestie
240925	Experiment 800M
240936	Inaktiver Aschenbringer
240945	Stück von Carries Apfelkuchen
240997	Fratleys Sporn
240998	Einschläfernde Klinge
241001	Tyrs Fall
241002	Überreste der Roten
241003	Trugbild, Rute der Illusionen
241004	Verwirrung
241006	Spitze der Opferung
241008	Geißelung
241011	Großstab der Treue
241012	Zauberstab der Reanimation
241015	Aegis der Scharlachroten Bastion
241017	Torheit des Dämonen
241018	Nathrezimherz
241020	Putress' vervollständigtes Tagebuch
241021	Das Licht
241022	Umhang des Morgenbringers
241023	Tuch der Heimtücke
241024	Umhang des scharlachroten Kommandanten
241025	Flagge des gebrochenen Admirals
241026	Schal des Kardinals
241027	Wache des Schildwächters
241028	Nathrezimschleife
241029	Baelins Band
241030	Masons Bruderschaftsring
241031	Bartholomäus' Versprechen
241032	Ring der Auferstehung
241034	Lichtherz
241037	Verworfenes Experiment
241038	Sir Dornels Didgeridoo
241039	Infusion der Seelen
241068	Stiltz' Standarte
241069	Würgekette
241070	Herods Hoffnung
241071	Talisman des scharlachroten Halunken
241072	Phiole mit Eiter
241073	Berührung des Lichts
241074	Helm des roten Kreuzzugs
241075	Helm des tobenden Zerstörers
241076	Gugel des Pakts
241077	Hut des Kardinals
241078	Balsamierungstuch
241079	Last der Welt
241080	Herods Schulterstücke
241081	Verderbter Aschenbringer
241082	Aschenbringer
241083	S03 - Scharlachrote Enklave - Schwert 2h Schlachtzug B
241084	S03 - Scharlachrote Enklave - Herods Schwert - Normal
241085	S03 - Scharlachrote Enklave - Schwert 1h
241086	Scharlachroter Turmschild
241087	Scharlachroter Stab
241088	Scharlachroter Stab
241089	Scharlachroter Dolch
241090	Scharlachrote Großaxt
241091	Scharlachroter Streitkolben
241092	Scharlachrote Klinge
241120	S03 - Scharlachrote Enklave - Herods Schwert - Geschmolzen
241121	Neugeborener Dolch
241122	Neugeborenes Messer
241123	Neugeborener Dolch
241124	Neugeborenes Messer
241128	Portiporterhaufen
241152	Dämmerungsgefertigte Schultern
241153	Doans Mantel
241154	Bärenhautmantel
241156	Verseuchte Roben
241157	Scharlachrote Brustplatte
241158	Ketten der Verlassenen
241159	Klostergewand
241160	Dämmerungsverschlissene Kettenrüstung
241161	Brustplatte des Templers
241162	Sonnengesegnete Lederrüstung
241163	Sonnenflammenarmschienen
241164	Verworfene Argentumslederstücke
241165	Wickel der Buße
241166	Dämmerungsgezogene Bänder
241167	Gefangenenfesseln
241168	Sonnenflammenhandschutz
241169	Nitroboosterprototypen
241170	Schützer der Enklave
241171	Handschuhe der verabschiedeten Seelen
241172	Caldorans verschlossene Stulpen
241173	Wickel des Hochzauberers
241174	Gurt des neugeborenen Champions
241175	Werkzeuggurt des Folterers
241176	Diesalvens Ende
241177	Kilt des scharlachroten Arkanisten
241178	Schmerzensplatte der Tapferkeit
241179	Gamaschen der Katastrophe
241180	Lichtschuppengamaschen
241181	Dämmerungsverschlissene Kettengamaschen
241182	Plattenbeinschützer des Templers
241183	Ascheschreiter
241184	Sandalen des Erlösers
241185	Bärentrainingsstiefel
241186	Polierte scharlachrote Kettenstiefel
241187	Blutrote Kriegsstiefel
241190	Vogelpfeife
241191	Formel: Waffe - Oberster Kreuzzügler
241195	Formel: Zweihandwaffe - Oberster Arkanist
241201	Formel: Waffe - Oberster Zauberer
241212	Kikerikanone
241241	Glücksdublone
241613	Nicht mehr verwendet
241629	Scharlachrote Kanonenkugel
241649	Stulpen der Hillsbradwache
241650	Erheblicher verfärbter Heiltrank
241651	Rezept: Erheblicher verfärbter Heiltrank
241652	Verfärbtes Tierherz
241653	Erhitzte Klinge
241654	Inaktiver Aschenbringer
241655	Beschädigter Heiltrank
241656	Beschädigter Heiltrank
241657	Gehärtete Klinge
242018	Blutendes Pestlandherz
242224	Korb mit Herzen
242256	Säckchen mit Brandbomben
242257	Geheimnisvolle alchemische Probe
242258	Forschungsnotizen
242266	Welt der Schutzkraft
242267	Vom Arkanist zum Erzmagier
242268	Verzaubert einen Kreuzfahrer
242269	Brillanz des Obersten Zauberers
242270	Brillanz des Obersten Arkanisten
242271	Brillanz des Obersten Kreuzfahrers
242310	Hand der wiedergeborenen Gerechtigkeit
242311	Leonids Amulett
242312	Siegel der Familie Barthalomew
242313	Tagebuch des Geachteten
242314	Glut des gefallenen Kreuzzugs
242315	Asche der Arroganz
242316	Staub der Widerspenstigen
242317	Entweihtes Gebetsbuch
242319	Neue Seuchenproben
242320	Neue Seuchenproben
242361	Formel: Zweihandwaffe verzaubern - Oberster Inquisitor
242362	Brillanz des Obersten Inquisitors
242363	Wer, was, wo, wann, tot! 5 Schlüssel für eine gute Inquisition
242364	Sehne eines ausgewachsenen Lichtdrachen
242365	Schwinge von Balnazzar
242366	Unentrinnbares Schicksal
242367	Schwinge und Faden
242425	Zerfledderte Tagebuchseite - Seite 1
242426	Zerfledderte Tagebuchseite - Seite 2
242427	Putress' Tagebuch
242428	Zerfledderte Tagebuchseite - Seite 3
242429	Putress' Tagebuch
242430	Zerfledderte Tagebuchseite - Seite 4
242431	Zerfledderte Tagebuchseite - Seite 5
242432	Putress' Tagebuch
242433	Zerfledderte Tagebuchseite - Seite 6
242434	Putress' Tagebuch
242435	Putress' Tagebuch
242436	Putress' Tagebuch
242465	Fragment des angerempelten Kelchs
242793	Tragbare Kanone
243010	Verderbter Aschenbringer
243064	Langstab
243065	Zerbrochener Zauberstab
243177	Geniales Spielzeug
243198	Geflügelgenauigkeitszielfernrohr
243229	Ruhestein der Argentumdämmerung
243230	Verdorbene lichtgeschmiedete Klinge
243345	Langstab
244353	Geflügelgenauigkeitszielfernrohr
244460	Caladschneide
245675	Schlüssel für die Gordokinnentür
246055	Handschutz der Inquisition
246056	Armschienen der Inquisition
246057	Stampfer der Inquisition
246058	Plattenbeinschützer der Inquisition
246059	Kordel der Inquisition
246060	Kürass der Inquisition
246061	Schulterklappen der Inquisition
246062	Gesichtsschutz der Inquisition
]==]
