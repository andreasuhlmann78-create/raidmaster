-- AH Analyzer Pro - Item-Namen (esES), 22713 Items
-- Quelle: siehe Data/QUELLEN.txt. Automatisch erzeugt, nicht von Hand ändern.
AHAnalyzerPro_NameData = AHAnalyzerPro_NameData or {}
AHAnalyzerPro_NameData["esES"] = [==[

25	Espada corta desgastada
35	Bastón doblado
36	Maza desgastada
37	Hacha desgastada
38	Camisa de recluta
39	Pantalones de recluta
40	Botas de recluta
43	Botas de escudero
44	Pantalones de escudero
45	Camisa de escudero
47	Zapatos de asaltante de caminos
48	Pantalones de asaltante de caminos
49	Camisa de asaltante de caminos
51	Botas de neófito
52	Pantalones de neófito
53	Camisa de neófito
55	Botas de aprendiz
56	Toga de aprendiz
57	Toga de acólito
59	Zapatos de acólito
60	Túnica a capas
61	Pantalones de cuero enano
79	Calzones de paño enano
80	Zapatos de pelaje suave
85	Jubón de cuero sucio
117	Cecina dura
118	Poción de curación menor
120	Pantalones de matón
121	Botas de matón
127	Camisa de trampero
129	Botas de trampero bastas
139	Pantalones de camorrista
140	Botas de camorrista
147	Pantalones de trampero bastos
148	Camisa de trampero basta
153	Falda escocesa primitiva
154	Manto primitivo
159	Agua de manantial refrescante
182	Cabeza de Garrick
193	Jubón de paño andrajoso
194	Pantalones de paño andrajoso
195	Botas de paño andrajoso
200	Jubón de paño grueso
201	Pantalones de paño grueso
202	Zapatos de paño grueso
203	Guantes de paño grueso
209	Pantalones de cuero sucios
210	Botas de cuero sucias
236	Armadura de cuero curado
237	Pantalones de cuero curado
238	Botas de cuero curado
239	Guantes de cuero curado
285	Jubón de malla de escamas
286	Pantalones de malla de escamas
287	Botas de malla de escamas
414	Pincho Dalaran
422	Cerveza enana
537	Escama frenesí mate
555	Plumas de buitre bastas
556	Pico de águila ratonera
647	Destino
710	Brazales de las Milicias del pueblo
711	Guantes de paño andrajoso
714	Guantes de cuero sucios
718	Guantes de malla de escamas
719	Guantes de cuidador de conejos
720	Guantes de camorrista
723	Hígado de Dentosangre
724	Pastel de hígado de Dentosangre
725	Garra gnoll
727	Espada corta despuntada
728	Receta: estofado de Páramos de Poniente
729	Carne fibrosa de buitre
730	Ojo de múrloc
731	Morro de dentrosangre
732	Okra
733	Estofado de Páramos de Poniente
735	Medallones de Rolf y Malakai
737	Agua de manantial sagrado
738	Saco de cebada
739	Saco de maíz
740	Saco de centeno
742	Una rama de sicomoro
743	Montón de roble carbonizado
744	Petaca de Cebatruenos
745	Documentos del alguacil McBride
748	Marcador de armaduras de Ventormenta
750	Carne de lobo dura
752	Arpillera roja
753	Espada corta Faucedraco
754	Espada corta de Venganza
755	Vela derretida
756	Pico de túnel
763	Brazales cubiertos de hielo
765	Hojaplata
766	Maza rebordeada
767	Bastón largo bo
768	Hacha de leñador
769	Trozo de carne de jabalí
770	Diente de crocolisco puntiagudo
771	Colmillo de jabalí astillado
772	Vela grande
773	Polvo de oro
774	Malaquita
776	Vendetta
777	Diente de merodeador
778	Pico de excavación de kobold
779	Concha lustrosa
780	Aletas de múrloc rotas
781	Martillo gnoll de piedra
782	Banda gnoll pintada
783	Pellejo ligero
785	Marregal
787	Caballa suave
789	Martillo de batalla recio
790	Hacha de silvicultor
791	Bastón nudoso de ceniza
792	Sandalias tricotadas
793	Guantes tricotados
794	Pantalones tricotados
795	Túnica tricotada
796	Botas de cuero basto
797	Guantes de cuero basto
798	Pantalones de cuero basto
799	Jubón de cuero basto
804	Costal azul grande
805	Faltriquera roja pequeña
809	Navaja de sangre
810	Martillo del Viento del Norte
811	Hacha del Bosque Profundo
812	Bastón Madera brillante resplandeciente
813	Diente roto
814	Botella de aceite
816	Hoja de mano pequeña
818	Ojo de tigre
820	Hoja rebanadora
821	Jubón de cuero Zarparrío
826	Hacha Zarparrío tosca
827	Porra maligna
828	Faltriquera azul pequeña
829	Pañuelo de cuero rojo
832	Cinturón de plata Defias
833	Piedra de vida
835	Red de cuerda grande
837	Armadura de tejido pesado
838	Pantalones de tejido pesado
839	Guantes de tejido pesado
840	Zapatos de tejido pesado
841	Reloj de bolsillo de Cejade
843	Botas de cuero curtido
844	Guantes de cuero curtido
845	Pantalones de cuero curtido
846	Chaleco de cuero curtido
847	Armadura de malla de anillas
848	Pantalones de malla de anillas
849	Botas de malla de anillas
850	Guantes de malla de anillas
851	Alfanje
852	Maza
853	Hachuela
854	Bastón de intendente
856	Bolsa de cuero azul
857	Costal rojo grande
858	Poción de Curación inferior
859	Camisa de paño refinado
860	Botas de hidalgo
862	Anillo con runas
863	Segadora penumbra
864	Espada larga de caballero
865	Maza plomiza
866	Bastón de monje
867	Guantes de Poderío Sagrado
868	Custodiador candente
869	Espada larga deslumbrante
870	Hacha de guerra ígnea
871	Hacha ráfaga
872	Rebanarrocas
873	Bastón de Jordan
875	Invocación de caballo marrón
876	Rodela de madera desgastada
878	Espireneta tamaño de puño
880	Bastón de Horrores
884	Costilla de necrófago
885	Hacha de metal negro
886	Espada corta de metal negro
887	Kilo de carne
888	Guantes de batalla Naga
889	Una carta polvorienta sin enviar
890	Bastón de Corista retorcido
892	Guantes de lanzamiento gnoll
893	Colmillo de lobo feroz
895	Calavera de ferocanis
896	Colmillo de ferocanis
897	Brazales Lobo demente
899	Colmillo de telaraña venenosa
901	Deptecated White Stallion Summoning (Mount)
910	Una carta sin entregar
911	Rama de árbol Maderaférrea
913	Espada de ogro enorme
914	Armadura de anillas de ogro grande
915	Pañuelo de seda rojo
916	Una página de diario rota
918	Talega de pellejo desviado
920	Maza con pinchos maligna
921	Una página de diario borrada
922	Guadaña dacia
923	Espada larga
924	Gran maza
925	Mayal
926	Hacha de batalla
927	Hacha doble
928	Bastón largo
929	Poción de curación
932	Alforjas de corcel inferi
933	Mochila grande
934	Segadora de Stalvan
935	Espada corta de guardia nocturno
936	Maza de medianoche
937	Bastón negro del Bosque del Ocaso
938	Páginas de diario embarrado
939	Una página de un diario manchada de sangre
940	Togas de Perspicacia
942	Sortija helada
943	Bastón de alcaide
944	Bastón de mago elemental
945	Espada de las Sombras
948	Espada Naturaleza
954	Pergamino de Fuerza
955	Pergamino de Intelecto
957	Envío de William
961	Hierba curativa
962	Pastel de tripa de cerdo
966	Escrito sobre Escudo de Escarcha
967	Escrito sobre Custodia de Escarcha
968	Escrito sobre Explosión de Fuego
973	Escrito sobre Bola de Fuego 2
974	Escrito sobre Armadura de Escarcha 2
975	Escrito sobre Cadenas de hielo
976	Escrito sobre Deshacer maldición
980	Escrito sobre Escudo de Escarcha 2
981	Collar de Bernice
983	Fajín de lino rojo
985	Escrito sobre Liberación de Khadgar
986	Escrito sobre Descarga de Escarcha 2
989	Escrito sobre Nova de Escarcha
992	Escrito sobre Bola de Fuego 3
994	Escrito sobre Armadura de hielo
997	Espada de inutilización de Fuego
1002	Escrito sobre Invisibilidad inferior
1004	Escrito sobre Cadenas de hielo 2
1006	Collar de latón
1008	Espada bien usada
1009	Martillo compacto
1010	Bastón nudoso corto
1011	Hacha afilada
1013	Remache de hierro
1015	Costillar de lobo magro
1017	Kebab de lobo salpimentado
1019	Pañuelo de lino rojo
1029	Tablilla de tótem serpiente
1030	Tablilla de voluntad férrea
1031	Tablilla de Explosión de arrabio
1032	Tablilla de tótem agitador
1033	Tablilla de Veneno de anulación
1034	Tablilla de fuerza eterna
1035	Tablilla de Llamar a espíritu
1036	Tablilla de Enfermedad de anulación
1037	Tablilla de Descarga de relámpagos 2
1038	Tablilla de Restauración 2
1041	Cuerno del lobo negro
1048	Tablilla de Escudo de relámpagos 2
1049	Tablilla de Purgar
1052	Tablilla de armadura de espíritu 2
1053	Tablilla de Explosión de arrabio 2
1057	Tablilla de Restauración 3
1058	Tablilla de Descarga de relámpagos 3
1061	Tablilla de Veneno de anulación 2
1063	Tablilla de Enfermedad de anulación 2
1072	Luna llena
1074	Punta de pata de araña dura
1075	Colgante Pellejo Negro
1076	Anillo de renegado Defias
1077	Anillo mágico Defias
1080	Carne de cóndor dura
1081	Carne de araña crujiente
1082	Estofado Crestagrana
1083	Glifo de Azora
1084	Códice de Renovar
1085	Códice de Visión mental
1086	Códice de Fuego interno
1087	Códice de Palabra de las Sombras: Dolor
1088	Códice de Renovar 2
1089	Códice de Enfermedad de anulación
1090	Códice de Resurrección
1091	Códice de Acometida Sagrada 2
1092	Códice de Curación inferior 2
1093	Códice de Deshacer maldición
1095	Códice de Disipar magia
1096	Códice de Palabra de las Sombras: Dolor 2
1100	Códice de Acometida Sagrada 3
1101	Códice de Renovar 6
1102	Códice de Curación inferior 3
1105	Códice de Renovar 7
1108	Códice de Renovar 3
1109	Códice de Dominación
1111	Códice de Dormir
1112	Códice de Palabra Sagrada: entereza 2
1113	Pan mágico
1114	Centeno mágico
1116	Anillo de plata pura
1119	Espíritus embotellados
1121	Pies de Lynx
1127	Carga cegadora
1129	Colmillo de necrófago
1130	Vial de veneno de araña
1131	Tótem de Inflicción
1132	Cuerno del lobo maderero
1133	Cuerno del lobo de invierno
1134	Cuerno del lobo gris
1136	Tratado: Favor divino 2
1138	Tratado: Favor divino
1139	Tratado: Purgación
1141	Tratado: Luz sagrada 2
1144	Tratado: Escudo divino
1146	Tratado: Resurrección
1149	Tratado: Lacre de poderío 2
1150	Tratado: Purificar
1151	Tratado: Luz sagrada 3
1154	Cinturón de las Milicias del pueblo
1155	Vara del Insomne
1156	Anillo con una piedra magnífica
1158	Garrote de metal sólido
1159	Bastón de intendente de milicia
1161	Espada corta de milicia
1164	Escrito de Sam
1166	Rodela dentada
1167	Tarja pequeña
1168	Escudo Llamacráneos
1169	Escudo de cráneo negro
1171	Toga bien cosida
1172	Antorcha de Grayson
1173	Botas deterioradas
1175	Un diente de oro
1176	Sales aromáticas
1177	Aceite de Olaf
1178	Cohete explosivo
1179	Leche fría como el hielo
1180	Pergamino de Aguante
1181	Pergamino de Espíritu
1182	Brazales de tachas de latón
1183	Muñequeras elásticas
1187	Collar con pinchos
1189	Anillo de sobrestante
1190	Capa de sobrestante
1191	Bolsa de canicas
1193	Rodela a rayas
1194	Espada de bastardo
1195	Pala de minería de kobold
1196	Tabardo
1197	Maza gigante
1198	Espada claymore
1199	Piedra de alma cargada
1200	Escudo de madera grande
1201	Escudo calentador mate
1202	Escudo de pared
1203	Égida de Ventormenta
1204	La torre verde
1205	Zumo de melón
1206	Ágata musgosa
1207	Murfestar
1208	Carta de amor de Maybell
1210	Gema de las Sombras
1211	Arnés de guerra gnoll
1212	Gapo gnoll
1213	Brazales afines a los gnoll
1214	Castigador gnoll
1215	Faja de sujeción
1216	Brazales escarchados
1217	Recompensa desconocida
1218	Garrote de guerra gnoll pesado
1219	Machete Crestagrana
1220	Hacha lupina
1221	Escama de vientre de cría
1222	Diente partido
1224	Grimorio de Demonios de los sentidos
1228	Grimorio de Sangre hervida
1229	Grimorio de Crear Petrosangre de lama
1231	Grimorio de descarga de las Sombras II
1232	Grimorio de Piel demoníaca II
1238	Grimorio de Miedo
1239	Grimorio de Maná de sifón
1243	Grimorio de descarga de las Sombras III
1244	Grimorio de Armadura demoníaca
1245	Grimorio de Inmolar II
1246	Grimorio de Aliento del demonio
1250	Grimorio de Detectar invisibilidad inferior
1251	Venda de lino
1252	Nota de la abuela Pedregosa
1254	Pirorroca inferior
1256	Hoja de kelp de cristal
1257	Licor de invisibilidad
1259	JYoo test item
1260	Cabeza de Tharil'zun
1261	Orbe de medianoche
1262	Barril de Cebatruenos
1263	Rebanasesos
1264	Azota cabezas
1265	Aguijón de escorpión
1270	Capa tejida con cuidado
1273	Cadena de bosque
1274	Lúpulos
1275	Abrigo de anillas de diputado
1276	Rodela endurecida con fuego
1280	Capa invisible
1282	Almófar de metal brillante
1283	Nota de Verner
1284	Cajón de herraduras
1287	Comillo de tarántula gigante
1288	Glándula de veneno grande
1292	Cuchilla de carnicero
1293	El estado de Villa del Lago
1294	La respuesta del General
1296	Maza Roca Negra
1297	Togas del Nigromante
1299	Cinturón de la Espiral inferior
1300	Bastón de la Espiral inferior
1302	Guantes de cría negra
1303	Guantes de puente
1304	Guantes de jinete
1306	Muñequeras crin de lobo
1307	Planificación de recogida de oro
1309	Caja de herramientas de Oslow
1310	Pantalones de Smith
1314	Dedos de necrófago
1315	Leu de Lilies
1317	Bastón de raíz endurecido
1318	Night atracador
1319	Anillo de Voluntad de hierro
1322	Aceite de hígado de pescado
1325	Ramo de narcisos
1326	Pezsol salteado
1327	Nota de Wiley
1328	Libro sobre Fuego Feérico
1332	Libro sobre Veneno de Cura
1334	Libro sobre Rejuvenecimiento 2
1339	Libro sobre raíces enredaderas
1341	Libro sobre Fuegolunar
1349	Cajón de Abercrombie
1351	Brazales de falanges
1352	Mortero de cráneo rajado
1353	Informe de Shaw
1355	Manteo de piel de ciervo
1356	Mención de honor: Bosque de Elwynn
1357	Mapa del tesoro del capitán Sander
1358	Una pista para el tesoro de Sander
1359	Guantes con impronta de león
1360	Guantes de anillas de Ventormenta
1361	Otra pista para el tesoro de Sander
1362	Pista final del tesoro de Sander
1364	Jubón de cuero harapiento
1366	Pantalones de cuero harapiento
1367	Botas de cuero harapiento
1368	Guantes de cuero harapiento
1369	Cinturón de cuero harapiento
1370	Brazales de cuero harapiento
1372	Capa harapienta
1374	Zapatos deshilachados
1376	Capa deshilachada
1377	Guantes deshilachados
1378	Pantalones deshilachados
1380	Toga deshilachada
1381	Un mensaje misterioso
1382	Maza de roca
1383	Tomahawk de piedra
1384	Hoja mate
1386	Hacha Cardoleño
1387	Diente de necrófago
1388	Bastón retorcido
1389	Marra de minería de kobold
1391	Bastón místico Zarparrío
1394	Garrote de madera a la deriva
1395	Pantalones de aprendiz
1396	Pantalones de acólito
1399	Vela mágica
1400	Muestra Plumaveloz
1401	Hoja de té verde
1402	Azufre
1404	Talismán de la marea
1405	Bastón de escupitajo
1406	Lanza taraceada con perlas
1407	Petición a Páramos de Poniente de Solomon
1408	Respuesta a Solomon de Mantorrecio
1409	Petición a Villa Oscura de Solomon
1410	Respuesta de Ebonlocke a Salomón
1411	Bastón seco
1412	Espada bastarda rudimentaria
1413	Espada débil
1414	Trineo rajado
1415	Marra de carpintero
1416	Hacha herrumbrada
1417	Hacha de batalla golpeada
1418	Cinturón de cuero desgastado
1419	Botas de cuero desgastadas
1420	Brazales de cuero desgastados
1421	Capa de pellejo desgastada
1422	Guantes de cuero desgastados
1423	Pantalones de cuero desgastados
1425	Jubón de cuero desgastado
1427	Zapatos de retales
1429	Capa de retales
1430	Guantes de retales
1431	Pantalones de retales
1433	Armadura de retales
1434	Palo de cera resplandeciente
1436	Calzones de frontera
1438	Escudo de guerrero
1440	Azotador de calavera gnoll
1443	Amuleto de Cainwyn enjoyado
1445	Espaldares Roca Negra
1446	Botas Roca Negra
1447	Anillo de salvadores
1448	Guanteletes Roca Negra
1449	Anillo de mediación menor
1450	Poción de fervor
1451	Botella zumo de zombi
1453	Peine espectral
1454	Hacha del Déspota
1455	Hacha de campeón Roca Negra
1457	Maza Pellejo Negro
1458	Gran maza Pellejo Negro
1459	Arrancabelleras Pellejo Negro
1460	Espada de dos manos Pellejo Negro
1461	Hacha de batalla de destripador
1462	Anillo de las Sombras
1464	Talón de águila ratonera
1465	Aterratigres
1467	Pez luna moteado
1468	Aleta de múrloc
1469	Cimitarra de Sincronización
1470	Bolsa de piel de múrloc
1473	Bastón ribera
1475	Glándula de veneno pequeña
1476	Miembro de araña partido
1477	Pergamino de Agilidad II
1478	Pergamino de Protección II
1479	Manoplas de Salma
1480	Puño de la Milicia del pueblo
1481	Garra macabra
1482	Colmillo oscuro
1483	Machacacaras
1484	Bastón de brujería
1485	Horquilla
1486	Chaqueta ladrido de árbol
1487	Pan integral de centeno mágico
1488	Armadura del Vengador
1489	Armadura luminiscente
1490	Talismán guardián
1491	Anillo de Precisión
1493	Cimitarra pesada de merodeador
1495	Zapatos percal
1497	Capa percal
1498	Guantes percal
1499	Pantalones percal
1501	Túnica percal
1502	Cinturón de cuero combado
1503	Botas de cuero combadas
1504	Brazales de cuero combados
1505	Capa combada
1506	Guantes de cuero combados
1507	Pantalones de cuero combados
1509	Jubón de cuero combado
1510	Martillo pesado
1511	Espada de plebeyo
1512	Hacha de batalla rudimentaria
1513	Espada magna vieja
1514	Martillo de guerra herrumbrado
1515	Bastón de madera basta
1516	Hachuela desgastada
1518	Peine de fantasma
1519	Oreja Sangrapellejo
1520	Sudor trol
1521	Hacha de serrería de ogro
1522	Lanza de cazador de cabezas
1523	Garrote de piedra enorme
1524	Colmillo Machacacráneos
1528	Un puñado de copos
1529	Jade
1532	Cabeza reducida
1534	Tratado: Luz sagrada 4
1536	Tratado: Lacre de cólera
1537	Faltriquera del viejo Blanchy
1539	Bastón nudoso de ermitaño
1547	Escudo de la Fe
1554	Escrito sobre Descarga de Escarcha 3
1557	Rodela de los Mares
1559	Escrito sobre Misiles Arcanos 2
1560	Sandalias branquiazules
1561	Toga de cosechador
1566	Filo de las Milicias del pueblo
1567	Escrito sobre Liberación de Khadgar 2
1568	Escrito sobre elemental de Agua
1571	Escrito sobre Nova de Escarcha 2
1574	Escrito sobre Custodia de Fuego
1588	Tablilla de Explosión de arrabio 3
1589	Tablilla de armadura de espíritu 3
1591	Tablilla de Escudo de relámpagos 3
1596	Hilo de cabello de fantasma
1597	Tablilla de Tormenta de relámpagos
1598	Flor podrida
1602	Hacha hoz
1603	Tablilla de Llamar a espíritu 2
1604	Espada cromática
1607	Guardián de almas
1608	Maza Trituracráneos
1613	Bastón cazador de espíritus
1619	Tablilla de Tormenta de relámpagos 2
1623	Faltriquera de piel de raptor
1624	Yelmo Machacacráneos
1625	Flamberge exquisita
1630	Electro-linterna rota
1637	Carta para Ello
1639	Hacha rictus
1640	Hacha de guerra monstruosa
1641	Códice de Palabra de las Sombras: Dolor 3
1645	Zumo de baya lunar
1648	Códice de Curación 4
1651	Códice de Palabra Sagrada: escudo 7
1652	Caja de comida robusta
1656	Carta traducida
1657	Códice de Resurrección 2
1658	Códice de Palabra de las Sombras: Dolor 4
1659	Guantes de ingeniería
1664	Vara de Potencia de hechizo
1676	Códice de Dormir 2
1677	Jubón de escamas de draco
1678	Chanclos de ogro negros
1679	Ala de korg
1680	Lonchea cabezas
1681	Grimorio de Tullido
1685	Bolsa de pellejo de trol
1686	Bigote de cerdas
1687	Garra retráctil
1688	Cola blanda larga
1696	Talón de raptor curvo
1697	Diente de raptor cortante
1701	Garra de basilisco curva
1702	Espina de basilisco intacta
1703	Espina de basilisco de cristal
1705	Piedra lunar inferior
1706	Fragmentos de hondoazur
1707	Brie de Ventormenta
1708	Néctar dulce
1710	Poción de curación superior
1711	Pergamino de Aguante II
1712	Pergamino de Espíritu II
1713	Ankh de vida
1714	Collar de Calisea
1715	Armadura Jazeraint pulida
1716	Toga del Magi
1717	Túnica de doble vínculo
1718	Pantalones de pellejo de basilisco
1720	Bastón Leñomaraña
1721	Martillo de guerra vikingo
1722	Almádena Piedra de espinas
1725	Morral grande
1726	Lanza de hueso con la punta envenenada
1727	Espada de Descomposición
1728	Espada llameante de Teebu
1729	Saco de armas de la Guardia Nocturna
1730	Cinturón de malla desgastado
1731	Botas de malla desgastadas
1732	Brazales de malla desgastados
1733	Capa desgastada
1734	Guantes de malla desgastados
1735	Pantalones de malla desgastados
1737	Jubón de malla desgastado
1738	Cinturón de malla con encaje
1739	Botas de malla con encaje
1740	Brazales de malla con encaje
1741	Capa con encaje
1742	Guantes de malla con encaje
1743	Pantalones de malla con encaje
1744	Hombreras de malla con encaje
1745	Jubón de malla con encaje
1746	Cinturón de eslabones
1747	Botas de eslabones
1748	Brazales de eslabones
1749	Capa de eslabones
1750	Guantes de eslabones
1751	Pantalones de eslabones
1752	Hombreras de eslabones
1753	Jubón de eslabones
1754	Cinturón de anillas reforzado
1755	Botas de anillas reforzadas
1756	Brazales de anillas reforzados
1757	Capa de anillas reforzada
1758	Guantes de anillas reforzados
1759	Pantalones de anillas reforzados
1760	Hombreras de anillas reforzadas
1761	Jubón de anillas reforzado
1764	Zapatos de retal
1766	Capa de retal
1767	Guantes de retal
1768	Pantalones de retal
1769	Hombreras de retal
1770	Jubón de retal
1772	Zapatos brocados
1774	Capa brocada
1775	Guantes brocados
1776	Pantalones brocados
1777	Hombreras brocadas
1778	Jubón brocado
1780	Sandalias a punto de cruz
1782	Capa a punto de cruz
1783	Guantes a punto de cruz
1784	Pantalones a punto de cruz
1785	Hombreras a punto de cruz
1786	Jubón a punto de cruz
1787	Cinturón de cuero con remiendos
1788	Botas de cuero con remiendos
1789	Brazales de cuero con remiendos
1790	Capa con remiendos
1791	Guantes de cuero con remiendos
1792	Pantalones de cuero con remiendos
1793	Hombreras de cuero con remiendos
1794	Chaleco de cuero con remiendos
1795	Cinturón de pellejo crudo
1796	Botas de pellejo crudo
1797	Brazales de pellejo crudo
1798	Capa de pellejo crudo
1799	Guantes de pellejo crudo
1800	Pantalones de pellejo crudo
1801	Hombreras de pellejo crudo
1802	Túnica de pellejo crudo
1803	Cinturón de cuero fuerte
1804	Botas de cuero fuerte
1805	Brazales de cuero fuerte
1806	Capa dura
1807	Guantes de cuero fuerte
1808	Pantalones de cuero fuerte
1809	Hombreras de cuero fuerte
1810	Armadura de cuero fuerte
1811	Espada claymore desafilada
1812	Hacha de batalla de mango corto
1813	Bastón astillado
1814	Marra maltrecha
1815	Maza ornamentada
1816	Hacha mal equilibrada
1817	Espada corta de serie
1818	Espada claymore estándar
1819	Gubia
1820	Gran maza de madera
1821	Espada combada
1822	Bastón de cedro para caminar
1823	Cayada de cachiporrazo
1824	Hacha de guerra lustrosa
1825	Cachiporra grande
1826	Gran maza de roca
1827	Cuchilla de carne
1828	Hacha de guerra de piedra
1829	Alfanje corto
1830	Espada de bastardo larga
1831	Bastón de guerra de roble
1832	Pantalones de la suerte
1835	Cinturón de cuero sucio
1836	Brazales de cuero sucios
1839	Cinturón de cuero basto
1840	Brazales de cuero basto
1843	Cinturón de cuero curtido
1844	Brazales de cuero curtido
1845	Cinturón de malla de anillas
1846	Brazales de malla de anillas
1849	Cinturón de cuero curado
1850	Brazales de cuero curado
1851	Agua purgadora
1852	Brazales de malla de escamas
1853	Cinturón de malla de escamas
1875	Tarjeta de Ortigacardo
1877	Libro sobre Rejuvenecimiento 3
1882	Libro sobre Fuegolunar 3
1886	Libro sobre Fuegolunar 2
1893	Revancha de minero
1894	Tarjeta de sindicato de minero
1913	Porra con tachuelas
1917	Daga enjoyada
1922	Suministros para Sven
1923	Cartera de embajador
1925	Estoque Defias
1926	Savia pesada
1927	Cuchilla de Las Minas de la Muerte
1928	Bastón mágico Defias
1929	Pantalones de seda
1930	Capa de albañil
1931	Garra de gnoll enorme
1933	Bastón de Creación
1934	Pantalones de albañil
1935	Hoja de asesino
1936	Destornillador goblin
1937	Sierra zumbido
1938	Marra bloque
1939	Nata de ron dulce
1941	Tonel de vino dulce
1942	Botella de licor de luna
1943	Leotardos de malla goblin
1944	Guantes para trabajar el hierro
1945	Guantes para trabajar la madera
1946	Prismáticos de Mary
1951	Alfanje Aguasnegras
1955	Botas de anillas de Faucedraco
1956	Colgante Pellejo Negro descolorido
1958	Tibia petrificada
1959	Pico de hierro frío
1962	Colgante de Pellejo Negro resplandeciente
1965	Guantes de lobo blanco
1968	Monóculo de ogro
1970	Bálsamo restablecedor
1971	Escritura de Cejade
1972	Escritura de Páramos de Poniente
1973	Orbe de engaño
1974	Brazales de punzada mental
1975	Vieja espada magna de Pysan
1976	Martillo de escoria
1977	Bolsa con 20 casillas
1978	Guantes de garra de lobo
1979	Muro de las obras
1980	Sortija del submundo
1981	Chaleco de malla de hielo
1982	Hoja de la noche
1986	Sacatripas
1987	Vasija arreglada de Krazek
1988	Guanteletes de jefe de brigada
1990	Gran maza de grava
1991	Pala de energía goblin
1992	Fetiche Pantano fresco
1993	Anillo de mente de ogro
1994	Atracador Garra de ébano
1996	Sortija vudú
1997	Toga sentida
1998	Bastón de mediación Sangrapellejo
2000	Archeus
2004	Diario de Grelin Barbablanca
2005	La primera leyenda trol
2006	La segunda leyenda trol
2007	La tercera leyenda trol
2008	La cuarta leyenda trol
2011	Sable retorcido
2013	Bastón de hueso de cripta
2014	Gran espada de metal negro
2015	Hacha de guerra de metal negro
2016	Armadura de anillas polvorientas
2017	Brazales de cuero resplandecientes
2018	Espada larga esquelética
2020	Hoja colmillo hueco
2021	Escudo de caparazón verde
2024	Mandoble
2025	Hacha barbada
2026	Martillo de roca
2027	Cimitarra
2028	Martillo
2029	Cuchilla
2030	Bastón nudoso
2032	Puños de galante
2033	Botas de embajador
2034	Togas de erudito
2035	Espada del Cielo nocturno
2036	Guantes de minería polvorientos
2037	Botas de tunelador
2039	Anillo de las llanuras
2040	Prospector trol
2041	Túnica de Páramos de Poniente
2042	Bastón de Páramos de Poniente
2043	Anillo de espíritus desapacibles
2044	Creciente de los Espíritus desolados
2046	Kukri branquiazul
2047	Hacha de mano Yunquemar
2048	Martillo Yunquemar
2054	Hacha de mano trogg
2055	Martillo de madera pequeño
2056	El martillo de terciopelo
2057	Espada corta con agujeros Defias
2058	Gran maza de Kazon
2059	Capa de avizor
2064	Garrote trogg
2065	Hoja Comepiedras
2066	Hachuela calavera
2067	Bastón Bocado helado
2069	Jubón de pellejo de oso negro
2070	Queso azul de Darnassus
2072	Cetro de mago enano
2073	Hachuela enana
2074	Hoja corta sólida
2075	Maza de sacerdote
2077	Bastón de mago
2078	Espada corta septentrional
2079	Martillo de guerra de sargento
2080	Hacha Natocolina
2082	Zurrón de Zumbang
2084	Espada bastarda de acero oscuro
2085	Trozo de carne
2087	Caparazón duro de reptador
2088	Miembro de reptador largo
2089	Daga para tallar
2091	Polvo mágico
2092	Daga desgastada
2098	Escopeta de doble cañón
2099	Cañón de mano enano
2100	Trabuco calibrado milimétricamente
2101	Carcaj ligero
2102	Faltriquera de munición pequeña
2105	Camisa de matón
2108	Jubón de cuero Peloescarcha
2109	Jubón de anillas Peloescarcha
2110	Toga ligera de mago
2112	Chaleco de leñador
2113	Nota de Calor
2114	Toga nevada
2117	Zapatos de paño fino
2119	Guantes de paño fino
2120	Pantalones de paño fino
2121	Armadura de paño fino
2122	Cinturón de cuero rajado
2123	Botas de cuero rajado
2124	Brazales de cuero rajado
2125	Guantes de cuero rajado
2126	Pantalones de cuero rajado
2127	Jubón de cuero rajado
2128	Espada claymore arañada
2129	Escudo redondo grande
2130	Garrote
2131	Espada corta
2132	Bastón corto
2133	Escudo pequeño
2134	Hacha de mano
2136	Agua purificada mágica
2137	Cuchillo para tallar
2138	Abrecartas afilado
2139	Daga dirk
2140	Cuchillo de excavar
2141	Jubón de cuero cuirboulli
2142	Cinturón de cuero cuirboulli
2143	Botas de cuero cuirboulli
2144	Brazales de cuero cuirboulli
2145	Guantes de cuero cuirboulli
2146	Pantalones de cuero cuirboulli
2148	Cinturón de escama pulida
2149	Botas de escama pulida
2150	Brazales de escama pulida
2151	Guantes de escama pulida
2152	Leotardos de escama pulida
2153	Jubón de escama pulida
2154	La historia de Morgan Ladimor
2156	Botas acolchadas
2158	Guantes acolchados
2159	Pantalones acolchados
2160	Armadura acolchada
2161	Libro sobre la granja de Sven
2162	Anillo de Sarah
2163	Hoja de las Sombras
2164	Destripador
2165	Manta del viejo Blanchy
2166	Leotardos de supervisor
2167	Guantes de supervisor
2168	Botas de supervisor
2169	Hoja timbre
2172	Cinturón rústico
2173	Cinturón de cuero viejo
2175	Hacha de batalla Pellejo Negro
2186	Cinturón de modisto
2187	Una baraja de cartas
2188	Un carta para Grelin Barbablanca
2194	Martillo de diamante
2195	Cuchillo Yunquemar
2203	Trituradora de Garravil
2204	Ensartadora de Garravil
2205	Anochecedor
2207	Jambiya
2208	Puñal
2209	Puñal hindú
2210	Rodela maltrecha
2211	Escudo grande doblado
2212	Rodela rajada
2213	Escudo grande desgastado
2214	Rodela de madera
2215	Escudo de madera
2216	Rodela simple
2217	Escudo rectangular
2218	Daga de artesano
2219	Escudo redondo pequeño
2220	Caja escudo
2221	Tarja
2222	Escudo de torre
2223	La lista del coleccionista
2224	Daga de milicia
2225	Cuchillo de cocina afilado
2226	Bastón de mago ogro
2227	Hacha de guerra de ogro pesada
2230	Guantes de Brawn
2231	Toga inferno
2232	Botas con runas oscuras
2233	Leotardos de tejedora de las Sombras
2234	Armadura de caminante nocturno
2235	Garra de Brack
2236	Comillo negro
2237	Pantalones con remiendos
2238	Pantalones de Urchin
2239	El anillo del coleccionista
2240	Manteo basto
2241	Manteo de forajido
2243	Mano de Edward el Extraño
2244	Hoja krol
2245	Yelmo de Narv
2246	Sello de mirmidón
2249	Rodela de milicia
2250	Croquetas de cangrejo
2251	Pata de araña babosa
2252	Provisiones goblin variadas
2254	Martillo de guerra de cristal de hielo
2256	Garrote esquelético
2257	Bastón Peloescarcha
2258	Espada corta Peloescarcha
2259	Garrote Peloescarcha
2260	Hacha de mano Peloescarcha
2262	Marca de Kern
2263	Fitohoja
2264	Manto de Ladrones
2265	Hacha Rompecantos
2266	Daga Rompecantos
2267	Maza Rompecantos
2268	Espada Rompecantos
2271	Bastón del Profeta bendito
2273	Armadura de guerrilla
2274	Guantes de zapador
2276	Botas Camina pantanos
2277	Leotardos de necromántico
2278	Insignias de rastreador de bosque
2280	Bastón de Kam
2281	Hacha de sílex Rodentia
2282	Espada corta Rodentia
2283	Cinturón de paño de rata
2284	Capa de paño de rata
2287	Anca de carne
2288	Agua fresca mágica
2289	Pergamino de Fuerza II
2290	Pergamino de Intelecto II
2291	Kang el Decapitador
2292	Togas de necrología
2295	Colmillo de jabalí grande
2296	Morro de gran Dentosangre
2299	Hacha de guerra ardiente
2300	Jubón de cuero en relieve
2302	Botas de cuero cosidas a mano
2303	Pantalones de cuero cosidos a mano
2304	Complemento para armadura ligera
2307	Botas de cuero refinado
2308	Capa de cuero refinado
2309	Botas de cuero en relieve
2310	Capa de cuero en relieve
2311	Chaleco de cuero blanco
2312	Guantes de cuero refinado
2313	Juego de armadura medio
2314	Armadura de cuero fortalecido
2315	Botas de cuero oscuro
2316	Capa de cuero oscuro
2317	Túnica de cuero oscuro
2318	Cuero ligero
2319	Cuero medio
2320	Hilo burdo
2321	Hilo refinado
2324	Lejía
2325	Tinte negro
2326	Brazales tejidos con hiedra
2327	Brazales de cuero robusto
2361	Martillo ajado por la batalla
2362	Escudo de madera desgastado
2364	Jubón tejido
2366	Pantalones tejidos
2367	Botas tupidas
2369	Guantes tejidos
2370	Arnés de cuero maltrecho
2371	Cinturón de cuero maltrecho
2372	Pantalones de cuero maltrechos
2373	Botas de cuero maltrechas
2374	Brazales de cuero maltrechos
2375	Guantes de cuero maltrechos
2376	Escudo calentador desgastado
2377	Rodela redonda
2378	Dedo esquelético
2379	Jubón de anillas deslustradas
2380	Cinturón de anillas deslustradas
2381	Leotardos de anillas deslustradas
2382	El corazón del embalsamador
2383	Botas de anillas deslustradas
2384	Brazales de anillas deslustradas
2385	Guantes de anillas deslustradas
2386	Jubón de anillas oxidado
2387	Cinturón de anillas oxidado
2388	Leotardos de anillas oxidados
2389	Botas de anillas oxidadas
2390	Brazales de anillas oxidadas
2391	Guantes de anillas oxidados
2392	Armadura de malla ligera
2393	Cinturón de malla ligera
2394	Leotardos de malla ligera
2395	Botas de malla ligera
2396	Brazales de malla ligera
2397	Guantes de malla ligera
2398	Armadura de anillas ligeras
2399	Cinturón de anillas ligeras
2400	Leotardos de anillas ligeras
2401	Botas de anillas ligeras
2402	Brazales de anillas ligeras
2403	Guantes de anillas ligeras
2406	Patrón: botas de cuero refinado
2407	Patrón: chaleco de cuero blanco
2408	Patrón: guantes de cuero refinado
2409	Patrón: túnica de cuero oscuro
2410	Antorcha humeante
2411	Brida de semental negro
2413	Palomino
2414	Pinto Bridle
2415	Semental blanco
2417	Jubón de anillas aumentado
2418	Leotardos de anillas aumentados
2419	Cinturón de anillas aumentado
2420	Botas de anillas aumentadas
2421	Brazales de anillas aumentadas
2422	Guantes de anillas aumentados
2423	Jubón brigandina
2424	Cinturón brigandina
2425	Leotardos brigandina
2426	Botas brigandina
2427	Brazales brigandina
2428	Guantes brigandina
2429	Jubón rojizo
2431	Pantalones rojizos
2432	Botas rojizas
2434	Guantes rojizos
2435	Armadura bordada
2437	Pantalones bordados
2438	Botas bordadas
2440	Guantes bordados
2441	Rodela ensortijada
2442	Tarja reforzada
2443	Rodela de metal
2444	Rodela ornamentada
2445	Escudo de metal grande
2446	Escudo flor de cardo
2447	Flor de paz
2448	Pavés pesado
2449	Raíz terrenal
2450	Briarthorn
2451	Escudo calentador con emblema
2452	Cardoveloz
2453	Hierba cardenal
2454	Elixir de fuerza de león
2455	Poción de maná menor
2456	Poción de Rejuvenecimiento menor
2457	Elixir de agilidad menor
2458	Elixir de entereza menor
2459	Poción de velocidad
2460	Elixir of Tongues (NYI)
2463	Jubón con tachuelas
2464	Cinturón con tachuelas
2465	Pantalones con tachuelas
2466	Fetiche Machacacráneos
2467	Botas con tachuelas
2468	Brazales con tachuelas
2469	Guantes con tachuelas
2470	Jubón de cuero reforzado
2471	Cinturón de cuero reforzado
2472	Pantalones de cuero reforzado
2473	Botas de cuero reforzado
2474	Brazales de cuero reforzado
2475	Guantes de cuero reforzado
2476	Anca de basilisco fría
2477	Calavera de devastador
2479	Hacha ancha
2480	Garrote grande
2481	Espada de peón
2482	Tomahawk inferior
2483	Hacha ancha basta
2484	Cuchillo pequeño
2485	Tablero astillado
2486	Maza de piedra grande
2487	Bastón de acólito
2488	Gladius
2489	Espada de dos manos
2490	Tomahawk
2491	Segur
2492	Cayada
2493	Marra de madera
2494	Estilete
2495	Palo para caminar
2496	Espada corta de asaltante
2497	Espada claymore oxidada
2498	Tomahawk pequeño
2499	Hacha de doble filo
2500	Martillo ligero
2501	Martillo de guerra de madera
2502	Daga rayada
2503	Bastón corto de adepto
2504	Arco corto desgastado
2505	Arco corto pulido
2506	Arco corvo de madera de cuerno
2507	Arco corvo laminado
2508	Trabuco viejo
2509	Trabuco ornamentado
2510	Trabuco sólido
2511	Trabuco de cazador
2512	Flecha basta
2514	Depricated Sharp Arrow
2515	Flecha afilada
2516	Tiro ligero
2519	Tiro pesado
2520	Sable
2521	Flamberge
2522	Hacha creciente
2523	Bullova
2524	Tranca
2525	Martillo de guerra
2526	Patoso mayor
2527	Bastón de batalla
2528	Bracamarte
2529	Montante
2530	Francisca
2531	Gran hacha
2532	Estrella de la mañana
2533	Gran maza de guerra
2534	Rondel
2535	Bastón de guerra
2536	Diente de piedra trogg
2545	Leotardos de anillas maleables
2546	Faja Peloescarcha real
2547	Guantes de cuidador de jabalíes
2548	Barril de brebaje de Cebadiz
2549	Bastón de la Sombra
2553	Receta: elixir de agilidad menor
2555	Receta: poción de velocidad
2556	Receta: elixir de lenguas
2560	Diario completo de Gato
2561	Cabeza de Chok'sul
2562	Ramo de begoñas escarlata
2563	Partículas con olor extraño
2564	Garras de espíritu élficas
2565	Vara de Fuego de arrabio
2566	Togas de sacrificio
2567	Hoja de evocador
2568	Jubón de lino marrón
2569	Botas de lino
2570	Capa de lino
2571	Envoltorio de parra
2572	Toga de lino roja
2575	Camisa de lino roja
2576	Camisa de lino blanco
2577	Camisa de lino azul
2578	Jubón de lino barbárico
2579	Camisa de lino verde
2580	Manteo de lino reforzado
2581	Venda de lino pesado
2582	Jubón de lana verde
2583	Botas de lana
2584	Manteo de lana
2585	Toga de lana gris
2586	Toga de Maestro de Juego
2587	Camisa de lana gris
2589	Paño de lino
2590	Telaraña de araña del bosque
2591	Paño trogg sucio
2592	Paño de lana
2593	Frasco de leonado de Ventormenta
2594	Cántaro de hidromiel enana
2595	Jarra de bourbon de las Tierras Inhóspitas
2596	Nata de cerveza enana
2598	Patrón: toga de lino rojo
2601	Patrón: toga de lana gris
2604	Tinte rojo
2605	Tinte verde
2606	Veneno de rondador
2607	Cristal Mo'grosh
2608	Ámbar gris de trillanodonte
2609	Coloide desactivador
2610	Mezcla desactivadora
2611	Sílex rudimentario
2612	Toga lisa
2613	Togas con doble pespunte
2614	Toga de Aprendiz
2615	Toga cromática
2616	Togas de seda fulgurante
2617	Togas ardientes
2618	Togas vestidas de plata
2619	Informe de Grelin
2620	Sudario augural
2621	Capucha de necromancia
2622	Penacho tribal de Nimar
2623	Diadema sagrada
2624	Cofia de meditación
2625	Estatuilla de Menethil
2628	Informe de Senir
2629	Llave de caja fuerte de intrépido
2632	Daga curva
2633	Remedio de la selva
2634	Extracto de helecho venenoso
2635	Cinturón de anillas sueltas
2636	Ídolo de piedra grabado
2637	Informe del avance de Vetaferro
2639	Carta de Merrin
2640	Equipamiento de minero
2642	Botas de anillas sueltas
2643	Brazales de anillas sueltas
2644	Capa de anillas sueltas
2645	Guantes de anillas sueltas
2646	Pantalones de anillas sueltas
2648	Jubón de anillas sueltas
2649	Cinturón de anillas endeble
2650	Botas de anillas endebles
2651	Brazales de anillas endebles
2652	Capa de anillas endeble
2653	Guantes de anillas endebles
2654	Pantalones de anillas endebles
2656	Jubón de anillas endeble
2657	Bolsa de cuero rojo
2658	Fragmento Ados
2659	Fragmento Modr
2660	Fragmento gólem
2661	Fragmento Neru
2662	Carcaj de Ribbly
2663	Bandolera de Ribbly
2664	Colmillo de hilador
2665	Hierbas aromáticas de Ventormenta
2666	Barril de cerveza del Trueno
2667	Carnes curadas de MacGrann
2668	Diente de trillanodonte
2669	Garra de trillanodonte
2671	Crin de Wendigo
2672	Carne fibrosa de lobo
2673	Carne de coyote
2674	Carne de reptador
2675	Garra de reptador
2676	Cardaluz
2677	Costillas de jabalí
2678	Especias suaves
2679	Carne de lobo carbonizada
2680	Carne de lobo especiada
2681	Carne de jabalí asado
2682	Pinza de cangrejo cocida
2683	Pastel de cangrejo
2684	Filete de coyote
2685	Costillas de cerdo suculentas
2686	Cerveza del Trueno
2687	Costillas de cerdo secas
2688	Nuez de ardilla
2690	Cinturón con pasador
2691	Botas de modisto
2692	Especias picantes
2694	Leotardos de colono
2696	Tonel de tajada
2697	Receta: tarta de hígado de Dentosangre
2698	Receta: pinza de cangrejo cocida
2699	Receta: estofado Crestagrana
2700	Receta: costillas de cerdo suculentas
2701	Receta: kebab de lobo salpimentado
2702	Lingote Forjaluz
2712	Cajón de lingotes de Forjaluz
2713	Cabeza del viejo Sooty
2719	Llave de latón pequeña
2720	Nota con barro
2721	Sudario sagrado
2722	Cupón de vino
2723	Botella de Dalaran Noir
2724	Solicitud de paño
2725	Las verdes colinas de Tuercespina: Página 1
2728	Las verdes colinas de Tuercespina: Página 4
2730	Las verdes colinas de Tuercespina: Página 6
2732	Las verdes colinas de Tuercespina: Página 8
2734	Las verdes colinas de Tuercespina: Página 10
2735	Las verdes colinas de Tuercespina: Página 11
2738	Las verdes colinas de Tuercespina: Página 14
2740	Las verdes colinas de Tuercespina: Página 16
2742	Las verdes colinas de Tuercespina: Página 18
2744	Las verdes colinas de Tuercespina: Página 20
2745	Las verdes colinas de Tuercespina: Página 21
2748	Las verdes colinas de Tuercespina: Página 24
2749	Las verdes colinas de Tuercespina: Página 25
2750	Las verdes colinas de Tuercespina: Página 26
2751	Las verdes colinas de Tuercespina: Página 27
2754	Espada bastarda deslustrada
2755	Las verdes colinas de Tuercespina
2756	Las verdes colinas de Tuercespina: Capítulo I
2757	Las verdes colinas de Tuercespina: Capítulo II
2758	Las verdes colinas de Tuercespina: Capítulo III
2759	Las verdes colinas de Tuercespina: Capítulo IV
2760	Equipo de costura de Thurman
2763	Cuchillo de pescador
2764	Daga pequeña
2765	Cuchillo de caza
2766	Estilete diestro
2770	Mineral de cobre
2771	Mineral de estaño
2772	Hierro
2773	Arco corto rajado
2774	Trabuco cubierto de herrumbre
2775	Mineral de plata
2776	Mineral de oro
2777	Arco corto débil
2778	Trabuco barato
2779	Lágrima de Tilloa
2780	Arco de caza ligero
2781	Trabuco sucio
2782	Arco corvo maltratado
2783	Trabuco de pésima calidad
2784	Zibética
2785	Arco corvo tieso
2786	Trabuco engrasado
2787	Daga trogg
2788	Cerveza Zarpanegra
2794	Un viejo libro de historia
2795	Libro: Tensiones del hierro
2797	Corazón de Mokk
2798	Mineral de Rethban
2799	Colmillo de gorila
2800	Togas de terciopelo negro
2801	Hoja de Hanna
2802	Emblema llameante
2805	Capa de piel de yeti
2806	Paquete para Pico Tormenta
2807	Hacha guillotina
2808	Antorcha de Llama
2815	Destripadora con hojas curvas
2816	Cetro de médium
2817	Túnica de cuero suave
2818	Pantalones de cuero elásticos
2819	Daga cruzada
2820	Cronómetro ingenioso
2821	Pasapurés Mo'grosh
2822	Mondadientes Mo'grosh
2823	Abrelatas Mo'grosh
2824	Huracán
2825	Arco para flechas abrasadoras
2828	Restos de Nissa
2829	Restos de Gregor
2830	Restos de Thurman
2831	Restos de Devlin
2832	Receta del estofado de Páramos de Poniente de Verna
2833	El libro de hechizos del Exánime
2834	Icor embalsamante
2835	Piedra basta
2836	Piedra burda
2837	Carta de Thurman
2838	Piedra pesada
2839	Un carta para Yvette
2840	Lingote de cobre
2841	Lingote de bronce
2842	Lingote de plata
2843	Nudillos sucios
2844	Maza de cobre
2845	Hacha de cobre
2846	Calabaza de Tirisfal
2847	Espada corta de cobre
2848	Maza de bronce
2849	Hacha de bronce
2850	Espada corta de bronce
2851	Cinturón de anillas de cobre
2852	Pantalones de anillas de cobre
2853	Brazales de cobre
2854	Brazales de cobre con runas
2855	Garra podrida
2856	Pico de hierro
2857	Cinturón de cobre con runas
2858	Sangre de can oscuro
2859	Escama Anca Vil
2862	Piedra de afilar basta
2863	Piedra de afilar burda
2864	Peto de cobre con runas
2865	Leotardos de bronce basto
2866	Coraza de bronce basto
2867	Brazales de bronce basto
2868	Brazales de patrón de bronce
2869	Peto de bronce plateado
2870	Peto de plata lustrosa
2871	Piedra de afilar pesada
2872	Veneno de nocturácnida sanguinaria
2874	Una carta sin enviar
2875	Anillo con la insignia Escarlata
2876	Pelambre Murciumbrío
2877	Espada claymore de combatiente
2878	Hacha de hueso barbada
2879	Vara antípoda
2880	Flujo débil
2881	Diseño: peto de cobre con runas
2882	Diseño: hombreras de bronce plateado
2883	Diseño: puñal de bronce mortal
2885	Documentos de la Cruzada Escarlata
2886	Costilla de jabalí del risco
2887	Pelambre de lobo estropeada
2888	Costillas de jabalí a la cerveza
2889	Receta: costillas de jabalí a la cerveza
2890	Pelambre de jabalí estropeada
2891	Carta para el arquitecto de la ciudad
2892	Veneno mortal
2893	Veneno mortal 2
2894	Malta rapsódica
2895	Dolor creciente
2896	Angustia creciente
2898	Coraza de montaraz
2899	Collar Wendigo
2900	Rodela de piedra
2901	Pico de minero
2902	Capa de la Fe
2903	Arco de caza de Daryl
2904	Rifle de caza de Daryl
2905	Capa de pelaje de cabra
2906	Leotardos de malla Villa Oscura
2907	Corta árboles enana
2908	Espada espinada
2909	Pañuelo de lana roja
2910	Botas de milicia de oro
2911	Faja de Keller
2912	Garra de Sombramáncico
2913	Manto de Gamn de seda
2915	Rompehielo Taran
2916	Escudo de león de oro
2917	Anillo tranquilo
2919	Reliquia de los Antiguos
2920	Reliquia sacra
2921	Reliquia bendita
2922	Reliquia de espíritu
2923	Reliquia de Rectitud
2924	Carne de crocolisco
2925	Piel de crocolisco
2926	Cabeza de Bazil Thredd
2927	Tormento creciente
2928	Polvo de Decadencia
2929	Podredumbre de tumba
2930	Esencia de dolor
2932	Viña tormenta
2933	Lacre de Wrynn
2934	Restos de cuero estropeado
2939	Lágrima de crocolisco
2940	Pata de oso sangriento
2941	Carne de prisión
2942	Nudillos de hierro
2943	Ojo de Paleth
2944	Ojo maldito de Paleth
2946	Daga arrojadiza equilibrada
2947	Cuchillo arrojadizo pequeño
2949	Botas de marinero
2950	Vara carámbano
2951	Anillo de Truenedera
2953	Capa de maestro vigía
2954	Pantalones de guardia nocturno
2955	Sombrero de primer colega
2956	Informe sobre la hermandad Defias
2957	Jubón de oficial
2958	Pantalones de oficial
2959	Botas de oficial
2960	Guantes de oficial
2961	Jubón de cuero quemado
2962	Calzones de cuero quemado
2963	Botas de cuero quemado
2964	Guantes de cuero quemado
2965	Túnica de guerrero
2966	Pantalones de guerrero
2967	Botas de guerrero
2968	Guantes de guerrero
2969	Jubón Vinculahechizo
2970	Pantalones Vinculahechizo
2971	Botas Vinculahechizo
2972	Guantes Vinculahechizo
2973	Túnica de caza
2974	Pantalones de caza
2975	Botas de caza
2976	Guantes de caza
2977	Armadura de veterano
2978	Leotardos de veterano
2979	Botas de veterano
2980	Guantes de veterano
2981	Toga de profeta
2982	Pantalones de profeta
2983	Botas de profeta
2984	Guantes de profeta
2985	Peto de cuero grabado
2986	Pantalones de cuero grabado
2987	Botas de cuero grabado
2988	Guantes de cuero grabado
2989	Túnica bruñida
2990	Leotardos bruñidos
2991	Botas bruñidas
2992	Guantes bruñidos
2996	Descarga de paño de lino
2997	Descarga de paño de lana
2998	Una sencilla brújula
2999	Herramientas de Brasacerada
3000	Caparazón de madre de camada
3002	Cuerno de Justicia de reliquia
3003	Reliquia del Ojo
3004	Reliquia de los Muertos
3005	Reliquia de Verdad
3006	Fragmento de reliquia sagrada
3008	Capa de pelaje Wendigo
3010	Arena fina
3011	Penacho de plumas
3012	Pergamino de Agilidad
3013	Pergamino de Protección
3014	Hacha ajada por la batalla
3016	Libro de hechizos de Gunther
3017	Pedido de Sevren
3018	Pellejo de Lupos
3019	Toga de noble
3020	Almete duradero
3021	Arco de especialista
3022	Calzones branquiazules
3023	Trabuco pesado grande
3024	BKP 2700 "Déspota"
3025	BKP 42 "Ultra"
3026	Arco reforzado
3027	Arco corvo pesado
3028	Arco largo
3029	Depricated Whipwood Arrow
3030	Flecha cuchilla
3031	Depricated Razor Arrow
3033	Perdigón sólido
3035	Calabaza atada
3036	Arco corto pesado
3037	Arco corvo ligero
3039	Arco de ceniza corto
3040	Bozal de cazador
3041	Trabuco "Ojo de mago"
3042	BKP "Gorrión" de bajo calibre
3045	Botas de escamas luminiscentes
3047	Guantes de escamas luminiscentes
3048	Musleras de escamas luminiscentes
3049	Peto de escamas luminiscentes
3053	Coraza de Humbert
3055	Coraza de cuero de bosque
3056	Pantalones de cuero de bosque
3057	Botas de cuero de bosque
3058	Guantes de cuero de bosque
3065	Botas brillantes
3066	Guantes brillantes
3067	Pantalones brillantes
3069	Toga brillante
3070	Capa insignia
3071	Hachuela de artillero
3072	Toga humeante
3073	Pantalones humeantes
3074	Guantes humeantes
3075	Ojo de Llama
3076	Botas humeantes
3078	Troceacorazones Naga
3079	Rifle de Skorn
3080	Vela de Señalización
3081	Gema abisal
3082	Calavera de Dargol
3083	Leva estabilizadora
3084	Engranaje giromecánico
3085	Barril de cerveza negra Brillante
3086	Tonel de cerveza negra Brillante
3087	Jarra de cerveza brillante
3088	Libro sobre Rejuvenecimiento 4
3089	Escrito sobre Fogonazo
3090	Escrito sobre Descarga de Escarcha
3091	Escrito sobre Intelecto Arcano 2
3092	Escrito sobre Fogonazo 3
3093	Escrito sobre Fogonazo 2
3094	Escrito sobre Explosión de Fuego 2
3095	Escrito sobre Explosión de Fuego 3
3096	Escrito sobre Caída de pluma
3097	Escrito sobre Conjurar agua 2
3098	Escrito sobre Lentitud
3099	Escrito sobre Armadura de hielo 2
3100	Escrito sobre Ventisca II
3101	Escrito sobre Nova de Escarcha 3
3102	Escrito sobre Intelecto Arcano 3
3103	Martillo Crestanevada
3107	Cuchillo arrojadizo cortante
3108	Daga arrojadiza pesada
3110	Oreja de rata de túnel
3111	Hacha arrojadiza rudimentaria
3113	Códice de Palabra Sagrada: escudo
3114	Códice de Palabra de las Sombras: Confusión
3115	Códice de Renovar 4
3116	Códice de Palabra Sagrada: escudo 2
3117	Diario de Hildelve
3118	Códice de Curación superior
3119	Códice de Palabra Sagrada: escudo 6
3120	Códice de Acometida Sagrada 4
3121	Códice de Levitar
3122	Códice de Palabra Sagrada: escudo 3
3123	Códice de Palabra Sagrada: entereza 3
3124	Códice de Fuego interno 3
3125	Tablilla de tótem serpiente
3126	Tablilla de choque 2
3127	Tablilla de choque 3
3129	Tablilla de Descarga de relámpagos 4
3130	Tablilla de Restauración 4
3131	Hacha arrojadiza pesada
3132	Tablilla de Explosión de arrabio 4
3133	Tablilla de tótem de maná
3134	Grimorio de Maldición de Mannoroth
3135	Hacha arrojadiza afilada
3137	Hacha arrojadiza mortal
3138	Grimorio de descarga de las Sombras IV
3139	Grimorio de Armadura demoníaca II
3140	Grimorio de Sangre hervida II
3141	Grimorio de Drenaje de vida
3142	Grimorio de Maldición de Sargeras
3143	Grimorio de Espíritu ardiente
3144	Grimorio de Espíritu ardiente II
3146	Grimorio de Espíritu ardiente III
3151	Jubón de brigada de asedio
3152	Guantes de buceo
3153	Capa manchada de aceite
3154	Hacha de Thelsamar
3155	Remedio de Arugal
3156	Grillete de glotón
3157	Grillete Almanegra
3158	Brazales de pellejo quemados
3160	Rodela de placas de hierro
3161	Toga del Vigilante
3162	Costilla con cortes
3163	Calavera ennegrecida
3164	Corazón de lupo descolorido
3165	Poción de Quinn
3166	Cadena coracero
3167	Cerda de araña espesa
3168	Escama astillada
3169	Diente de oso astillado
3170	Diente de oso grande
3171	Colmillo de jabalí roto
3172	Intestinos de jabalí
3173	Carne de oso
3174	Icor de araña
3175	Pellejo de dragón estropeado
3176	Garra pequeña
3177	Colmillo diminuto
3179	Muda de piel de dragón rajada
3180	Escama de raptor con motas
3181	Carne parcialmente digerida
3182	Seda de araña
3183	Garra sarnosa
3184	Daga gancho
3185	Bastón acrobático
3186	Espada vikinga
3187	Puñal hindú de sacrificio
3188	Espada claymore de coral
3189	Cortamadera
3190	Palo para golpear
3191	Hacha de guerra arqueada
3192	Espada bastarda corta
3193	Marra de roble
3194	Malicia negra
3195	Hacha de batalla barbárica
3196	Espada afilada bastarda
3197	Espada claymore Cortapiedras
3198	Martillo de paliza
3199	Destripador de batalla
3200	Brazales de cuero quemado
3201	Hacha de guerra bárbara
3202	Brazales de cuero de bosque
3203	Maza triangular densa
3204	Brazales Leñoprofundo
3205	Brazales de cuero grabado
3206	Montante de hidalgo
3207	Brazales de caza
3208	Martillo porrazo
3209	Espada de guerra antigua
3210	Hacha de guerra brutal
3211	Brazales bruñidos
3212	Brazales de escamas luminiscentes
3213	Brazales de veterano
3214	Brazales de guerrero
3216	Toga de invierno cálida
3217	Cinturón de supervisor
3218	Grillete de piromadera
3220	Morcilla
3222	Daga maligna
3223	Cetro Peloescarcha
3224	Brazales forrados con plata
3225	Cuchillo manchado de sangre
3227	Bastón nocturno
3228	Esposas forzadas
3229	Fajín de seda de tarántula
3230	Brazales de lobo negro
3231	Espaldares degollador
3233	Saco de pellejo gnoll
3234	Anillo de Deliah
3235	Anillo de Desdén
3236	Icor de pellejo podrido
3237	Muestra de icor
3238	Descubrimientos de Johaan
3239	Piedrafuerte basta
3240	Piedrafuerte burda
3241	Piedrafuerte pesada
3248	Carta traducida de El Embalsamador
3249	Conjured test Item
3250	Pergamino de Bethor
3251	Poción de Bethor
3252	Informe de Mortacechador
3253	Corazón de grisoso
3254	Sangre de celerácnida
3255	Diario de Berard
3256	Moho de Vigilante del Lago
3257	Moho de Trepador del Lago
3258	Tumor endurecido
3259	Pellejo de murciélago estropeado
3260	Togas de iniciado Escarlata
3261	Capa de telaraña
3262	Martillo de madera podrido
3263	Pantalones de telaraña
3264	Ala de Murciumbrío
3265	Garra de carroñero
3266	Banda Escarlata
3267	Espada corta de los Renegados
3268	Daga de los Renegados
3269	Gran maza de los Renegados
3270	Jubón de lienzo
3272	Leotardos de piel de zombi
3273	Jubón de malla basta
3274	Botas de lienzo
3275	Guantes de lienzo
3276	Rodela de Guardia de la Muerte
3277	Bastón de verdugo
3278	Espada de daño de proc aura
3279	Botas de anillas de batalla
3280	Brazales de anillas de batalla
3281	Guantes de anillas de batalla
3282	Pantalones de anillas de batalla
3283	Túnica de anillas de batalla
3284	Botas tribales
3285	Brazales tribales
3286	Guantes tribales
3287	Pantalones tribales
3288	Jubón tribal
3289	Botas ancestrales
3290	Guantes ancestrales
3291	Prendas de lana ancestrales
3292	Túnica ancestral
3293	Cuchilla de muerto
3294	Garrote de muerto
3295	Hoja de muerto
3296	Daga de muerto
3297	Musgovil
3299	Canino fracturado
3300	Pata de conejo
3301	Canino afilado
3302	Botas de agua estancada
3303	Brazales de agua estancada
3304	Guanteletes de agua estancada
3305	Leotardos de agua estancada
3306	Jubón de agua estancada
3307	Botas de paño barbárico
3308	Guantes de paño barbárico
3309	Taparrabos barbárico
3310	Jubón de paño barbárico
3311	Tobilleras de cuero ceremonial
3312	Brazales de cuero ceremonial
3313	Arnés de cuero ceremonial
3314	Guantes de cuero ceremonial
3315	Taparrabos de cuero ceremonial
3316	Cabeza de Alaric
3317	Una cabeza que habla
3318	Restos de Alaric
3319	Sable corto
3320	Fajín Tirahuesos
3321	Botitas de pelaje gris
3322	Capa menuda
3323	Brazales fantasmales
3324	Manto fantasmal
3325	Hacha de batalla Anca Vil
3327	Bastón de oráculo Anca Vil
3328	Toga de tela de araña
3329	Tabla de madera con pinchos
3330	Camisote de Dargol
3331	Manteo de Melrache
3332	Botas de Perrine
3334	Pala de granjero
3335	Escoba de granjero
3336	Taladro de carne
3337	Estandarte de guerra Faucedraco
3339	Yesca enana
3340	Mineral incendicita
3341	Guanteletes de Fuerza de ogro
3342	Camisa del capitán Sander
3343	Bolsa de botín del capitán Sander
3344	Fajín del capitán Sander
3345	Sombrero zahorí de seda
3347	Fardo de pieles de crocolisco
3348	Piel de crocolisco gigante
3349	Bolsa de Shida
3352	Bolsa cubierta de moco
3353	Colgante con runas grabadas
3354	Colgante Dalaran
3355	Acérita salvaje
3356	Sangrerregia
3357	Vidarraíz
3358	Mostacho de Khadgar
3360	Fémur de Puntos
3363	Cinturón deshilachado
3365	Brazales deshilachados
3369	Moho de tumba
3370	Cinturón de retales
3371	Vial vacío
3372	Vial con plomo
3373	Brazales de retales
3374	Cinturón percal
3375	Brazales percal
3376	Cinturón de retal
3377	Brazales de retal
3378	Cinturón brocado
3379	Brazales brocados
3380	Cinturón a punto de cruz
3381	Brazales a punto de cruz
3382	Poción de sangre trol débil
3383	Elixir de sabiduría
3384	Poción de resistencia a la magia menor
3385	Poción de maná inferior
3386	Elixir de resistencia al envenenamiento
3387	Poción de invulnerabilidad limitada
3388	Poción de sangre trol fuerte
3389	Elixir de defensa
3390	Elixir de agilidad inferior
3391	Elixir de fuerza de ogro
3392	Yelmo ensortijado
3393	Receta: poción de resistencia a la magia menor
3394	Receta: elixir de resistencia al envenenamiento
3395	Receta: poción de invulnerabilidad limitada
3396	Receta: elixir de agilidad inferior
3397	Piel de crocolisco joven
3399	Talón de buitre
3400	Espada larga Lucine
3401	Escama de crocolisco basta
3402	Parche de pelaje suave
3403	Cuerno de jabalí de marfil
3404	Ala de águila ratonera
3405	Talismán de garra de cuervo
3406	Cañón de pluma negra
3407	Zafiro de cielo
3408	Runa de Nidal
3409	Colmillo de Sable de Hielo
3411	Pluma de lechuza estrígida
3412	Seda de araña Tejemadera
3413	Pico maldito
3414	Cetro con emblema
3415	Bastón del Fraile
3416	Cadena de mártir
3417	Espada claymore de ónice
3418	Cono inferi
3419	Rosa roja
3420	Rosa negra
3421	Flores silvestres simples
3422	Flores silvestres preciosas
3423	Ramo de rosas blancas
3424	Ramo de rosas negras
3425	Varita tejida
3426	Camisa amarilla chillón
3427	Camisa negra con estilo
3428	Camisa gris común
3429	Cinturón de guardia
3430	Rifle de francotirador
3431	Cuero con huesos
3434	Arena de sueño
3435	Brazales de piel de zombi
3437	Cinturón con broche
3438	Ankh de Resurrección
3439	Botas de piel de zombi
3440	Partehuesos
3442	Fajín de aprendiz
3443	Tomahawk ceremonial
3444	Jubón de vástago
3445	Cuchillo ceremonial
3446	Bastón Leñoscuro
3447	Botas de caminacriptas
3448	Raíz de senggin
3449	Chal místico
3450	Escudo de Faerleia
3451	Brebaje Resplandor nocturno
3452	Vara ceranium
3453	Brazales guateados
3454	Botas de reconocimiento
3455	Espada corta de Mortacechador
3456	Silbato para perros
3457	Pantalones estampados
3458	Guantes de malla basta
3460	Bebida especial de Johaan
3461	Gran toga del Adjudicador
3462	Golpe de talón
3463	Estrella de plata
3464	Flecha de plumas
3465	Bala explosiva
3466	Flujo fuerte
3467	Llave de hierro mate
3468	Descubrimiento de Renferrel
3469	Botas de anillas de cobre
3470	Piedra de pulir basta
3471	Jubón de anillas de cobre
3472	Guanteletes de cobre con runas
3473	Pantalones de cobre con runas
3474	Guanteletes de cobre con gemas
3475	Capa de Llamas
3476	Lengua de oso gris
3477	Icor reptador
3478	Piedra de pulir burda
3480	Hombreras de bronce basto
3481	Hombreras de bronce plateado
3482	Botas de bronce plateado
3483	Guanteletes de bronce plateado
3484	Botas de hierro verde
3485	Guanteletes de hierro verde
3486	Piedra de pulir pesada
3487	Sable de cobre pesado
3488	Hacha de batalla de cobre
3489	Hacha de guerra espesa
3490	Puñal de bronce mortal
3491	Maza de bronce pesada
3492	Martillo de hierro poderoso
3493	Fin de raptor
3495	Elixir de sufrimiento
3496	Sangre de león montés
3497	Elixir de dolor
3498	Collar de Taretha
3499	Llave de oro bruñida
3502	Flores de Morrobarro
3505	Sello de Alterac
3506	Compuesto Morrobarro
3508	Mezcla Morrobarro
3509	Escama Dagaespinazo
3510	Ojo de aleta rasgado
3511	Capa de las Milicias del pueblo
3514	Calavera de Mor'Ladim
3515	Bastón de Ataeric
3516	Cabeza de Lescovar
3517	Barril de cerveza Machacacanillas
3518	Carta descifrada
3520	Barril contaminado
3521	Carta codificada con ingenio
3522	Peto negro de elfo de la noche
3523	Pantalones de elfo de la noche sin usar
3524	Botas de elfo de la noche sin usar
3525	Brazales de elfo de la noche sin usar
3526	Guantes negros de elfo de la noche
3527	Peto de elfo de la noche blanco
3528	Peto de cuero rojo C03
3529	Yelmo negro de elfos de la noche
3530	Venda de lana
3531	Venda de lana pesada
3532	Unused Red Leather C03 Pants
3533	Botas de cuero rojo C03
3534	Unused Red Leather C03 Gloves
3535	Brazales de cuero rojo C03
3536	Venda de cazador de demonios
3537	D02 Peto de cuero negro
3538	Peto de cuero gris D02
3539	Unused Black Leather D02 Pants
3540	Unused Gray Leather D02 Pants
3541	D02 Botas de cuero negras
3542	Botas de cuero gris D02
3543	Unused Black Leather D02 Gloves
3544	Unused Gray Leather D02 Gloves
3545	D02 Brazales de cuero negros
3546	Brazales de cuero gris D02
3547	Peto de cuero blanco D03
3548	Unused White Leather D03 Pants
3549	Unused White Leather D03 Gloves
3550	Cabeza de Targ
3551	Cabeza de Muckrake
3552	Cabeza de Glommus
3553	Cabeza de Jarra'thol
3554	Corona de Voluntad
3555	Toga de Solomon
3556	Sombrero de mago terrorífico
3557	Tabardo de tripas sin usar
3558	Toga de guardia de pantano
3559	Guanteletes de guardia nocturno
3560	Manto de Honor
3561	Poncho resistente
3562	Cinturón de Confirmación
3563	Bombachos de farero
3564	Envío de hierro
3565	Guantes manchados de cerveza
3566	Armadura Aterraptor
3567	Caña de pescar enana
3569	Toga de vicario
3570	Mano de mortero de huesos
3571	Golpeador trogg
3572	Espada corta de Daryl
3573	Carcaj de caza
3574	Saco me munición de caza
3575	Lingote de hierro
3576	Lingote de estaño
3577	Lingote de oro
3578	Pantalones de cosechador
3581	Cuchillo dentado
3582	Capa antiácido
3583	Cinturón deteriorado
3585	Túnica de camuflaje
3586	Partetroncos
3587	Cinturón bordado
3588	Brazales bordados
3589	Cinturón de tejido pesado
3590	Brazales de tejido pesado
3591	Cinturón acolchado
3592	Brazales acolchados
3593	cinturón rojizo
3594	Brazales rojizos
3595	Cinturón de paño andrajoso
3596	Brazales de paño andrajoso
3597	Cinturón de paño grueso
3598	Brazales de paño grueso
3599	Cinturón de paño fino
3600	Brazales de paño fino
3601	Misiva de la Hermandad
3602	Cinturón tricotado
3603	Brazales tricotados
3604	Bandolera de la Guardia Nocturna
3605	Carcaj de la Guardia Nocturna
3606	Cinturón tejido
3607	Brazales tejidos
3608	Diseño: martillo de hierro poderoso
3609	Diseño: jubón de anillas de cobre
3610	Diseño: guanteletes de cobre con gemas
3611	Diseño: botas de hierro verde
3612	Diseño: guanteletes de hierro verde
3613	Manos de Valdred
3614	Pata de Yowler
3615	Cabeza de Kurzen
3616	Ojo de la mente
3617	Colgante de Sombras
3618	Cabeza de Engullidor
3619	Tabaquera de Snellig
3620	Restos de Lillith
3621	Cabeza de Ivar
3622	Esencia de Latipesadilla
3623	Cabeza de Thule
3625	Cabeza de Nek'rosh
3626	Cabeza de Barón Vardus
3627	Colmillo de Vagash
3628	Mano de Dextren Tutor
3629	Anillo de la familia Mantoniebla
3630	Cabeza de Targorr
3631	Colmillo de Panzallena
3632	Pata de Fangore
3633	Cabeza de Gath'Ilzogg
3634	Cabeza de Grimson
3635	Garra de ojo de gusano
3636	Escama de Viejo Ojosombrío
3637	Cabeza de VanCleef
3638	Espolón de Sarltooth
3639	Oreja de Balgaras
3640	Cabeza de Furiahonda
3641	Brazales de oficial
3642	Brazales ancestrales
3643	Brazales Vinculahechizo
3644	Brazales de paño barbárico
3645	Puños de profeta
3647	Brazales brillantes
3648	Rodela de guerrero
3649	Rodela tribal
3650	Escudo de batalla
3651	Escudo de veterano
3652	Rodela de caza
3653	Rodela ceremonial
3654	Escudo de agua estancada
3655	Escudo bruñido
3656	Escudo de escamas luminiscentes
3657	Registro civil de Trabalomas
3658	Escrito recuperado
3659	Libro de cuero desgastado
3660	Escritos sobre Alterac
3661	Bastón artesanal
3662	Chuleta de crocolisco
3663	Sopa de aleta de múrloc
3664	Potaje de crocolisco
3665	Tortilla con un sabor curioso
3666	Pastel de araña babosa
3667	Carne de crocolisco tierna
3668	Contrato de asesino
3669	Goo gelatinoso
3670	Hueso viscoso grande
3671	Calavera inerte
3672	Cabeza de Nagaz
3673	Flecha partida
3674	Bota descompuesta
3675	Antorcha totalmente quemada
3676	Icor baboso
3678	Receta: chuleta de crocolisco
3679	Receta: morcilla
3680	Receta: sopa de aleta de múrloc
3681	Receta: potaje de crocolisco
3682	Receta: tortilla con un sabor curioso
3683	Receta: pastel de araña pegajosa
3684	Tiara Perenolde
3685	Huevo de raptor
3688	Óvalo de Petrosangre
3689	Canica de Petrosangre
3690	Fragmento de Petrosangre
3691	Cuña de Petrosangre
3692	Calavera humana de Trabalomas
3693	Espada de Humbert
3701	Mención de honor lacrada de Darthalia
3702	Vejiga de bilis de oso
3703	Cerveza Costasur
3704	Llave de hierro oxidada
3706	Pergamino hechizado
3707	Pliego de Nagaz
3708	Vara de Helcular
3710	Vara de Helcular
3711	Cuaderno de investigación de Belamoore
3712	Carne de tortuga
3713	Especias calmantes
3714	Muestra de piedra desgastada
3715	Brazales de Vínculo de Tierra
3716	Cabeza de múrloc
3717	Saco de cabezas de múrloc
3718	Planes de premonición
3719	Capa de montañero
3720	Piel de yeti
3721	Informe de Farren
3722	Pellejo conocido
3723	Colmillo conocido
3724	Garra conocida
3725	Cuerno conocido
3726	Chuleta de oso grande
3727	Chuletas de león picantes
3728	Filete de león sabroso
3729	Sopa de tortuga reconfortante
3730	Carne de oso grande
3731	Carne de león
3732	Capucha amplia
3733	Cadena de guerra orca
3734	Receta: chuleta de oso grande
3735	Receta: chuletas de león picantes
3736	Receta: filete de león sabroso
3737	Receta: sopa de tortuga reconfortante
3738	Vara de cervecero
3739	Anillo calavera
3740	Espada decapitadora
3741	Botas de pisotón
3742	Arco de saqueo
3743	Rodela de avizor
3744	Colgante de Petrosangre
3745	Runa de Apertura
3747	Fajín de meditación
3748	Manto felino
3749	Capa de gran boticario
3750	Peto en canalé
3751	Leotardos de mercenario
3752	Jubón de bruto
3753	Faja de pastor
3754	Guantes de pastor
3755	Entrañas de pescado
3758	Cinturón cruzado
3759	Guantes aislantes de sabio
3760	Sortija de Entrañas
3761	Escudo calavera
3762	Cartera de bibliotecario
3763	Rodela lunar
3764	Botas de mantis
3765	Espaldares de Brigand
3766	Pluma de grifo
3767	Pliego refinado
3769	Varita rota
3770	Pata de cordero
3771	Pata de cero salvaje
3772	Agua de manantial mágica
3775	Veneno atroz
3776	Veneno atroz 2
3777	Raíz de letargo
3778	Arco compuesto tenso
3779	Hacha de guerra pesada
3780	Mosquete de cañón largo
3781	Espada claymore ancha
3782	Garrote de guerra grande
3783	Cimitarra ligera
3784	Bastón de metal
3785	Hacha cortante
3786	Daga dirk lustroso
3787	Garrote de piedra
3788	Reliquia de cristal de alma
3789	Piedra reliquia de Piedad
3790	Pliego de reliquia consagrada
3791	Reliquia de la Luz
3792	Cinturón entrelazado
3793	Botas entrelazadas
3794	Brazales entrelazados
3795	Capa entrelazada
3796	Guantes entrelazados
3797	Pantalones entrelazados
3798	Hombreras entrelazadas
3799	Jubón entrelazado
3800	Cinturón de cuero endurecido
3801	Botas de cuero endurecido
3802	Brazales de cuero endurecido
3803	Capa endurecida
3804	Guantes de cuero endurecido
3805	Pantalones de cuero endurecido
3806	Hombreras de cuero endurecido
3807	Túnica de cuero endurecido
3808	Cinturón de malla doble
3809	Botas de malla doble
3810	Brazales de malla doble
3811	Capa con doble pespunte
3812	Guantes de malla doble
3813	Pantalones de malla doble
3814	Hombreras de malla doble
3815	Jubón de malla doble
3816	Calentador reflectante
3817	Rodela reforzada
3818	Pálida
3819	Ivernalia
3820	Alga estranguladora
3821	Espina de oro
3822	Hoja oscura rúnica
3823	Poción de invisibilidad inferior
3824	Aceite de las Sombras
3825	Elixir de entereza
3826	Poción de sangre de trol poderosa
3827	Poción de maná
3828	Elixir de detección de invisibilidad inferior
3829	Aceite escarchado
3830	Receta: elixir de entereza
3831	Receta: poción de sangre de trol poderosa
3832	Receta: elixir de detección de invisibilidad inferior
3833	Capa de adepto
3834	Pantalones de paño robusto
3835	Brazales de hierro verde
3836	Yelmo de hierro verde
3837	Almófar de escamas de oro
3838	Garra Faucesombrías
3839	Colmillo de tigre prístino
3840	Hombreras de hierro verde
3841	Hombreras de escamas de oro
3842	Leotardos de hierro verde
3843	Leotardos de escamas de oro
3844	Camisote de hierro verde
3845	Coraza de escamas de oro
3846	Botas de acero pulido
3847	Botas de escamas de oro
3848	Cuchillo de bronce grande
3849	Espada corta de hierro endurecido
3850	Alfanje de jade
3851	Gran maza de hierro sólido
3852	Destructor de hierro dorado
3853	Sable de acero lunar
3854	Hoja tigre de Escarcha
3855	Hacha de hierro macizo
3856	Hacha creciente de las Sombras
3857	Carbón
3858	Mineral de mitril
3859	Lingote de acero
3860	Lingote de mitril
3861	Lingote de acero negro
3862	Tendón de gorila mayor
3863	Pluma de acechador de la selva
3864	Citrino
3866	Diseño: alfanje de jade
3867	Diseño: destructor de hierro dorado
3868	Diseño: hoja tigre de Escarcha
3869	Diseño: hacha creciente de las Sombras
3870	Diseño: hombreras de hierro verde
3871	Diseño: hombreras de escamas de oro
3872	Diseño: leotardos de escamas de oro
3873	Diseño: coraza de escamas de oro
3874	Diseño: botas de acero pulido
3875	Diseño: botas de escamas de oro
3876	Colmillo de Bhag'thera
3877	Talón de Tethis
3879	Garra de Sin'Dall
3880	Cabeza de Bangalash
3882	Pluma de águila ratonera
3889	Sombrero rojizo
3890	Sombrero con tachuelas
3891	Yelmo de anillas aumentado
3892	Sombrero bordado
3893	Cofia de cuero reforzado
3894	Yelmo brigandina
3897	Ojo de Dizzy
3898	Caligrafía de biblioteca
3899	Leyendas de los Gurubashi, Volumen 3
3900	Oporto Pupellyverbos
3901	Colmillo Sangrapellejo
3902	Bastón de Nobles
3904	Cabeza de Gan'zulah
3905	Cabeza de Nezzliok
3906	Trofeo de Balia'mah
3907	Trofeo Ziata'jai
3908	Trofeo Zul'Mamwe
3909	Armadura de Ana'thek rota
3910	Barril de tabaco
3911	Fragmento azul pulsante
3912	Gema de alma
3913	Gema de almas llena
3914	Mochila de oficial
3915	Collar de huesos sangrientos
3916	Collar de hueso partido
3917	Cristal canto azul
3918	Fragmento de cristal canto
3919	Tripas de Velo de Bruma
3920	Cartas Velasangre
3921	Pedido Velasangre
3922	Pago de Shaky
3923	Brazales elementales de Agua
3924	Pie deforme de Maury
3925	Telescopio dorado de Jon-Jon
3926	Anillo enorme de Chucky
3927	Queso cheddar curado bueno
3928	Poción de curación excelente
3929	Botín de Maury
3930	Llave de Maury
3931	Colmillo de araña envenenado
3932	Cofre de Smotts
3935	Alfanje de Smotts
3936	Cinturón de ganchillo
3937	Botas de ganchillo
3938	Brazales de ganchillo
3939	Capa de ganchillo
3940	Guantes de ganchillo
3941	Pantalones de ganchillo
3942	Hombreras de ganchillo
3943	Jubón de ganchillo
3944	Cinturón sarga
3945	Botas sarga
3946	Brazales sarga
3947	Capa sarga
3948	Guantes sarga
3949	Pantalones sarga
3950	Hombreras sarga
3951	Jubón sarga
3952	Cinturón de malla
3953	Botas de malla
3954	Brazales de malla
3955	Capa de malla
3956	Guantes de malla
3957	Pantalones de malla
3958	Manto de malla
3959	Armadura de malla
3960	Bolsa de brazales de elementales de agua
3961	Cinturón de cuero grueso
3962	Botas de cuero grueso
3963	Brazales de cuero grueso
3964	Capa gruesa
3965	Guantes de cuero grueso
3966	Pantalones de cuero grueso
3967	Hombreras de cuero grueso
3968	Túnica de cuero grueso
3969	Cinturón de cuero liso
3970	Botas de cuero liso
3971	Brazales de cuero liso
3972	Capa lisa
3973	Guantes de cuero liso
3974	Pantalones de cuero liso
3975	Hombreras de cuero liso
3976	Armadura de cuero liso
3977	Cinturón con correas
3978	Botas con correas
3979	Brazales con correas
3980	Capa con correas
3981	Guantes con correas
3982	Pantalones con correas
3983	Hombreras con correas
3984	Armadura con correas
3985	Fajín con monogramas
3986	Pavés protector
3987	Torre desviada
3988	Escudo de pared de placa
3989	Tarja de bloqueo
3990	Rodela con emblema
3991	Rodela de placas
3992	Cinturón de escamas laminadas
3993	Botas de escamas laminadas
3994	Brazales de escamas laminadas
3995	Capa de escamas laminadas
3996	Guantes de escamas laminadas
3997	Pantalones de escamas laminadas
3998	Hombreras de escamas laminadas
3999	Armadura de escamas laminadas
4000	Cinturón de anillas superpuestas
4001	Botas de anillas superpuestas
4002	Brazales de anillas superpuestas
4003	Capa de anillas superpuestas
4004	Guantes de anillas superpuestas
4005	Pantalones de anillas superpuestas
4006	Hombreras de anillas superpuestas
4007	Armadura de anillas superpuestas
4008	Cinturón de anillas extraordinarias
4009	Botas de anillas extraordinarias
4010	Brazales de anillas extraordinarias
4011	Capa de anillas extraordinarias
4012	Guantes de anillas extraordinarias
4013	Pantalones de anillas extraordinarias
4014	Hombreras de anillas extraordinarias
4015	Armadura de anillas extraordinarias
4016	Mezcla de Zanzil
4017	Espada corta afilada
4018	Espada claymore afilada
4019	Hacha de sílex pesada
4020	Hacha de batalla seccionadora
4021	Maza contundente
4022	Gran maza aplastante
4023	Daga puntiaguda refinada
4024	Bastón de guerra pesado
4025	Arco largo equilibrado
4026	Mosquete de centinela
4027	Hoja de Catelyn
4028	Fardo de cañas akiris
4029	Junco akiris
4030	Agua de reliquia sagrada
4031	Talismán de reliquia Sagrado
4032	Martillo de reliquia radiante
4033	Resplandor del Alba
4034	Piedra de las Mareas
4035	Toga de hilo de plata
4036	Puños de hilo de plata
4037	Pantalones de hilo de plata
4038	Toga Cielo Nocturno
4039	Capucha Cielo Nocturno
4040	Guantes Cielo Nocturno
4041	Capucha aurora
4042	Guantes aurora
4043	Brazales aurora
4044	Pantalones aurora
4045	Brazales Escapabruma
4046	Pantalones Escapabruma
4047	Botas Escapabruma
4048	Sombrero blasonado
4049	Brazales blasonados
4050	Leotardos blasonados
4051	Botas blasonadas
4052	Almete de insignia
4053	Piel de crocolisco de río grande
4054	Leotardos de insignia
4055	Botas de insignia
4056	Criba de Cortello
4057	Coraza de insignia
4058	Peto con inscripciones
4059	Brazales con inscripciones
4060	Leotardos con inscripciones
4061	Brazales de cuero imperial
4062	Pantalones de cuero imperial
4063	Guantes de cuero imperial
4064	Rodela blasonada
4065	Escudo de combate
4066	Rodela de insignia
4067	Rodela con inscripciones
4068	Escudo de jefe de brigada
4069	Rodela Forjanegra
4070	Emblema de ajustador
4071	Peto de malla de luz trémula
4072	Guanteletes de malla de luz trémula
4073	Grebas de malla de luz trémula
4074	Armadura de combate de malla
4075	Guanteletes de combate de malla
4076	Botas de combate de malla
4077	Protector de cabeza de combate de mallas
4078	Almófar de jefe de brigada
4079	Leotardos de jefe de brigada
4080	Capucha Forjanegra
4082	Peto Forjanegra
4083	Guanteletes Forjanegra
4084	Leotardos Forjanegra
4085	Vasija de barro de Krazek
4086	Rifle cegador
4087	Arco de tiro real
4088	Hoja terrorífica
4089	Trabuco rompebloques
4090	Jarra O' Hurt
4091	Creaviudas
4092	Escama de basilisco prismática
4093	Cola de basilisco grande
4094	Fragmento de tablilla
4095	Deprecate Snare Kit
4096	Pelo de gorila burdo
4097	Diente de gorila astillado
4098	Nota doblada con cuidado
4099	Mechón de pelo de gorila
4100	Nota arrugada
4101	Nota rasgada
4102	Nota rota
4103	Llave de grillete
4104	Piel de crocolisco Quijaforte
4105	Piel de crocolisco viejo
4106	Cristal caído
4107	Guantes de cazador de tigre
4108	Leotardos de cazador de panteras
4109	Borceguíes
4110	Arco de maestro cazador
4111	Rifle de maestro cazador
4112	Gargantilla del Alto chamán
4113	Manta medicinal
4114	Manteo marea oscura
4115	Rodela Grom'gol
4116	Olmann Sewar
4117	Fajín agostador
4118	Aro de Pooh-Bah
4119	Túnica de cazador de raptor
4120	Toga de Aguas cristalinas
4121	Guantes con gemas
4122	Cetro de corredor de apuestas
4123	Espaldares de metal escarchados
4124	Almete de Armonía
4125	Orbe tranquilo
4126	Cuchilla de guerrilla
4127	Lanzatralla
4128	Pala de plata
4129	Colección de placas
4130	Brújula de Smotts
4131	Cinturón de Corrupción
4132	Braquiales Lanza Negra
4133	Puños Lanza Negra
4134	Bastón místico de Nimboya
4135	Sortija de hueso de sangre
4136	Botas Lanza Negra
4137	Zapatos Lanza Negra
4138	Túnica Aguasnegras
4139	Sandalias para la selva
4140	Manto de fronda de palmera
4141	Escrito sobre Conjurar comida
4142	Escrito sobre Polimorfismo: cerdo
4143	Escrito sobre Conjurar comida 2
4144	Escrito sobre Polimorfismo: vaca
4145	Escrito sobre Conjurar gema de maná
4146	Escrito sobre Polimorfismo: oveja
4147	Escrito sobre Conjurar comida 3
4148	Escrito sobre Contrahechizo
4149	Escrito sobre Escudo de Escarcha 3
4150	Escrito sobre Conjurar agua 4
4151	Escrito sobre Descarga de Escarcha 4
4152	Escrito sobre Conjurar comida 4
4153	Escrito sobre Misiles Arcanos 3
4154	Escrito sobre Lentitud 2
4155	Escrito sobre elemental de Agua 2
4157	Escrito sobre Empapar magia
4158	Escrito sobre Liberación de Khadgar 3
4159	Escrito sobre Misiles Arcanos
4160	Escrito sobre Invisibilidad
4161	Escrito sobre Bola de Fuego 4
4162	Escrito sobre Traslación 2
4164	Tratado: Luz sagrada 6
4165	Tratado: Luz sagrada 7
4166	Tratado: Lacre de protección
4167	Tratado: Sentencia
4168	Tablilla de tótem para Atrapar
4169	Tablilla de voluntad férrea 2
4170	Tablilla de Viaje astral
4171	Tablilla de tótem agitador 3
4172	Tablilla de Trueno 2
4173	Tablilla de choque 4
4174	Tablilla de choque 5
4175	Tablilla de Escudo de relámpagos 4
4176	Tablilla de fuerza eterna 2
4177	Tablilla de Resistencia a Naturaleza
4178	Tablilla de Descarga de relámpagos 5
4179	Tablilla de Restauración 5
4180	Tablilla de Forma etérea 2
4181	Tablilla de tótem agitador 4
4182	Tablilla de voluntad férrea 3
4183	Tablilla de tótem curativo 5
4184	Tablilla de Explosión de arrabio 5
4185	Tablilla de Viaje astral en grupo
4186	Tablilla de Resistencia al Fuego
4187	Tablilla de tótem serpiente
4188	Tablilla de tótem de invisibilidad
4189	Tablilla de Cadena de relámpagos
4190	Armadura de plumas
4191	Leotardos con plumas sin usar
4192	Guanteletes con plumas sin usar
4194	Brazales de plumas
4195	Botas de plumas
4196	Manto de plumas
4197	Protectores de berilio
4198	Grimorio de Embudo de almas
4199	Grimorio de Embudo de almas II
4200	Grimorio de Inmolar III
4201	Grimorio de Ojo de Kilrogg
4202	Grimorio de Miedo II
4203	Grimorio de Pestilencia II
4204	Grimorio de Embudo de almas III
4205	Grimorio de Inmolar IV
4206	Grimorio de Maldición de Sargeras II
4207	Grimorio de Maldición de Archimonde
4208	Grimorio de Bomba mental
4209	Grimorio de Pupilo de las Sombras
4210	Grimorio de Crear Petrosangre inferior
4211	Grimorio de Pestilencia
4212	Grimorio de Maldición de Mannoroth III
4213	Grimorio de Maldición
4214	Grimorio de Drenaje de vida III
4215	Grimorio de Lluvia de Fuego
4216	Grimorio de Pupilo Sagrado
4217	Grimorio de Embudo de almas IV
4218	Grimorio de Crear Petrosangre
4219	Grimorio de Espíritu ardiente IV
4220	Grimorio de Sangre hervida III
4221	Grimorio de Detectar invisibilidad
4223	Libro sobre Suprimir Magia
4225	Libro sobre raíces enredaderas 3
4226	Libro sobre Cólera 6
4228	Libro sobre Fuegolunar 4
4230	Libro sobre Toque curativo 6
4231	Pellejo ligero curado
4232	Pellejo fino
4233	Pellejo medio curado
4234	Cuero pesado
4235	Pellejo pesado
4236	Pellejo pesado curado
4237	Cinturón de cuero cosido a mano
4238	Bolsa de lino
4239	Guantes de cuero en relieve
4240	Bolsa de lana
4241	Bolsa de lana verde
4242	Pantalones de cuero en relieve
4243	Túnica de cuero refinado
4244	Jubón de cuero de montañero
4245	Talega de seda pequeña
4246	Cinturón de cuero refinado
4247	Guantes de cuero de montañero
4248	Guantes de cuero oscuro
4249	Cinturón de cuero oscuro
4250	Cinturón de montañero
4251	Hombreras de montañero
4252	Hombreras de cuero oscuro
4253	Guantes de cuero fortalecido
4254	Guantes barbáricos
4255	Armadura de cuero verde
4256	Armadura de guardián
4257	Cinturón de cuero verde
4258	Cinturón de guardián
4259	Brazales de cuero verde
4260	Brazales de cuero de guardián
4261	Pantalones de Solliden
4262	Cinturón de cuero con gemas incrustadas
4263	Escudo de venta estándar
4264	Cinturón barbárico
4265	Complemento pesado para armadura
4266	Códice de Fuego interno 2
4267	Códice de Palabra de las Sombras: Torpeza
4268	Códice de Curación 2
4269	Códice de Rezo de curación
4270	Códice de Curación 3
4271	Códice de Acometida Sagrada 5
4272	Códice de Protección Sagrada
4273	Códice de Curación
4274	Códice de Escape divino
4275	Códice de Putrefacción mental
4276	Códice de Palabra de las Sombras: Torpeza 2
4277	Códice de Palabra de las Sombras: Confusión 2
4278	Mineral de Petrosangre inferior
4279	Códice de Palabra de las Sombras: Dolor 5
4280	Códice de Palabra Sagrada: escudo 4
4281	Códice de Protección de las Sombras
4282	Códice de Disipar magia 2
4283	Códice de Dormir 3
4284	Códice de Acometida Sagrada 6
4285	Códice de Palabra Sagrada: entereza 4
4286	Códice de Rezo de curación 2
4287	Códice de Enfermedad de anulación 2
4288	Códice de Deshacer maldición 2
4289	Sal
4290	Bol de polvo
4291	Hilo de seda
4292	Patrón: bolsa de lana verde
4293	Patrón: jubón de cuero de montañero
4294	Patrón: cinturón de montañero
4296	Patrón: hombreras de cuero oscuro
4297	Patrón: guantes barbáricos
4298	Patrón: cinturón de guardián
4299	Patrón: armadura de guardián
4300	Patrón: brazales de cuero de guardián
4301	Patrón: cinturón barbárico
4302	Daga verde pequeña
4303	Aplastacráneos
4304	Cuero grueso
4305	Descarga de paño de seda
4306	Paño de seda
4307	Guantes de lino pesado
4308	Brazales de lino verde
4309	Calzones de lino cosidos a mano
4310	Guantes de lana pesada
4311	Capa de lana pesada
4312	Botas de lino de suela suave
4313	Botas de lana roja
4314	Hombreras de lana con doble pespunte
4315	Hombreras de lana reforzada
4316	Pantalones de lana pesada
4317	Pantalones Fénix
4318	Guantes de Meditación
4319	Guantes de seda azur
4320	Botas de seda de araña
4321	Zapatillas de seda de araña
4322	Capucha de encantador
4323	Caperuza de las Sombras
4324	Jubón de seda azur
4325	Botas del Encantador
4326	Capa de seda larga
4327	Capa helada
4328	Cinturón de araña
4329	Cinturón de estrella
4330	Camisa roja con estilo
4331	Guantes Fénix
4332	Camisa amarillo brillante
4333	Camisa de seda oscura
4334	Camisa blanca formal
4335	Camisa de seda morada viva
4336	Camisa negra de aventurero
4337	Seda de araña espesa
4338	Tela de paño mágico
4339	Descarga de paño mágico
4340	Tinte gris
4341	Tinte amarillo
4342	Tinte morado
4343	Pantalones de lino marrón
4344	Camisa de lino marrón
4345	Patrón: botas de lana roja
4346	Patrón: capa de lana pesada
4347	Patrón: hombreras de lana reforzada
4348	Patrón: guantes Fénix
4349	Patrón: pantalones Fénix
4350	Patrón: zapatillas de seda de araña
4351	Patrón: caperuza de las Sombras
4352	Patrón: botas del Encantador
4353	Patrón: cinturón de araña
4354	Patrón: camisa de seda morada viva
4355	Patrón: capa helada
4356	Patrón: cinturón de estrella
4357	Pólvora basta
4358	Dinamita basta
4359	Un puñado de tornillos de cobre
4360	Bomba de cobre basto
4361	Tubo de cobre
4362	Trabuco basto
4363	Modulador de cobre
4364	Pólvora burda
4365	Dinamita burda
4366	Muñeco-diana
4367	Carga de seforio pequeña
4368	Gafas de tigre volador
4369	Trabuco mortal
4370	Bomba de cobre grande
4371	Tubo de bronce
4372	Trabuco fabricado con amor
4373	Gafas de las Sombras
4374	Bomba de bronce pequeña
4375	Cacharros zumbones de bronce
4376	Deflector de llamas
4377	Pólvora pesada
4378	Dinamita pesada
4379	Escopeta de chapa de plata
4380	Bomba de bronce grande
4381	Recombobulador menor
4382	Marco de bronce
4383	Rifle de vista lunar
4384	Oveja explosiva
4385	Gafas tintadas de verde
4386	Deflector de hielo
4387	Tornapunta de hierro
4388	Rayo descombobulador
4389	Girocronátomo
4390	Granada de hierro
4391	Juego de segador de la cosecha compacto
4392	Muñeco-diana avanzado
4393	Monóculo de artesano
4394	Bomba de hierro grande
4395	Mina terrestre goblin
4396	Dragonizo mecánico
4397	Aparato de invisibilidad gnómico
4398	Carga de seforio grande
4399	Pila de madera
4400	Surtido pesado
4401	Caja de ardillas mecánica
4402	Glándula de llamas pequeña
4403	Mortero de bronce portátil
4404	Contacto de plata
4405	Mira rudimentaria
4406	Mira estándar
4407	Mira de precisión
4408	Esquema: ardilla mecánica
4409	Esquema: carga de seforio pequeña
4410	Esquema: gafas de las Sombras
4411	Esquema: deflector de llamas
4412	Esquema: rifle de vista lunar
4413	Esquema: rayo descombolulador
4414	Esquema: mortero de bronce portátil
4415	Esquema: monóculo de artesano
4416	Esquema: mina terrestre goblin
4417	Esquema: carga de seforio grande
4419	Pergamino de Intelecto III
4421	Pergamino de Protección III
4422	Pergamino de Aguante III
4424	Pergamino de Espíritu III
4425	Pergamino de Agilidad III
4426	Pergamino de Fuerza III
4428	Pulpa de araña
4429	Pedido Furiahonda
4430	Talismán etéreo
4432	Carta de Sully Balloo
4433	Sobre estropeado por el agua
4434	Pantalones de espantapájaros
4435	Mota de Myzrael
4436	Fajín taraceado con joyas
4437	Bastón de canalizador
4438	Brazales de pugilista
4439	Garrote moretón
4440	Sigilo de Strom
4441	Licor de luna de MacKreel
4443	Espaldares macabros
4444	Escudo de cáscara negra
4445	Punzón de carne
4446	Hoja veneno negro
4447	Capa de la noche
4448	Colmillo de Naraxis
4449	Colmillo de Narain
4450	Fragmento de sigilo
4453	Sigilo de Thoradin
4454	Talón de Vultros
4455	Arnés de pellejo de raptor
4456	Cinturón de pellejo de raptor
4457	Ala de águila ratonera a la parrilla
4458	Sigilo de Arathor
4459	Hueso de dragón frágil
4460	Ala rasgada
4461	Pellejo de raptor
4462	Capa de Putrefacción
4463	Collar de raptor perlado
4464	Botas de paliza
4465	Guanteletes nudillóseo
4466	Sigilo de Aterratrols
4467	Sigilo de Ignaeus
4468	Trol'kalar enfundado
4469	Vara de Orden
4470	Madera simple
4471	Sílex y Yesca
4472	Pergamino de Myzrael
4473	Grilletes de Eldritch
4474	Arco de madera de cuervo
4476	Toga de caminabestias
4477	Rodela nefaria
4478	Leotardos de escamas iridiscentes
4479	Talismán ardiente
4480	Talismán del trueno
4481	Talismán blasonado
4482	Carpeta sellada
4483	Llave ardiente
4484	Llave emblemática
4485	Llave del trueno
4487	Cartas de navegación de la doncella
4488	Espíritu de las carta de navegación de Argénteos
4489	Cuaderno de bitácora de la doncella
4490	Espíritu del cuaderno de bitácora de Argénteos
4491	Gafas de gema de caza
4492	Gema élfica
4493	Gemas élficas
4494	Carta lacrada de Cuernomarino
4495	Amuleto de Petrosangre
4496	Faltriquera marrón pequeña
4497	Bolsa marrón pesada
4498	Cartera de cuero marrón
4499	Saco marrón enorme
4500	Mochila de trampero
4502	Muestra de gema élfica
4503	Colmillo Secacorteza
4504	Capa de guarda enano
4505	Pantalones Tierra pantanosa
4506	Insignia de Stromgarde
4507	Escudo de luchador de fosa
4508	Armadura tintada de sangre
4509	Guantes de lobo marino
4510	Orbe de Petrosangre contaminado
4511	Martillo de agua negra
4512	Ojo de raptor de tierra alta
4513	Corazón de raptor
4514	Petición de Sara Balloo
4515	Cabeza de Marez
4516	Cabeza de Otto
4517	Cabeza de Cresta de Halcón
4518	Fragmento de pergamino roto
4519	Fragmento de pergamino arrugado
4520	Fragmento de pergamino torrado
4521	Granito de Alterac
4522	Faltriquera de medicinas secacorteza
4524	Monumento a Balloo
4525	Varita de invocación de Trelane
4526	Amuleto de espolón de raptor
4527	Ágata azur
4528	Orbe de Tor'gan
4529	Ágata encantada
4530	Filacteria de Trelane
4531	Orbe de Trelane
4532	Ágata de brasa de Trelane
4533	Carta lacrada para el archimago Malin
4534	Brazales con cierre de acero
4535	Anillo de recuerdo de Forjaz
4536	Manzana roja lustrosa
4537	Banana Tel'Abim
4538	Sandía Vidrota
4539	Manzana de Corteza de oro
4540	Mendrugo de pan duro
4541	Pan recién horneado
4542	Pan de maíz húmedo
4543	Almete de piel de draco blanca
4544	Pan con especias de Mulgore
4545	Brazales de plata radiantes
4546	Llamada del raptor
4547	Irradiador gnómico
4548	Almádena servomecánica
4549	Sortija de fuego marino
4550	Anillo aguafría
4551	Cabeza de Or'Kalar
4552	Trozo de piedra lisa
4553	Trozo de piedra dentado
4554	Piedra pulida lustrosa
4555	Cola escamada espesa
4556	Fragmento de concha moteada
4557	Glándula ígnea
4558	Barril vacío
4559	CHU's QUEST ITEM
4560	Cimitarra fina
4561	Tomahawk arrancabelleras
4562	Hacha severa
4563	Garrote de Billy
4564	Garrote con pinchos
4565	Daga simple
4566	Bastón de guerra robusto
4567	Espada merc
4568	Hacha de bruto
4569	Martillo acérrimo
4570	Gran maza de madera de abedul
4571	Cuchillo de guerra
4575	Bastón medicinal
4576	Arco ligero
4577	Escopeta compacta
4580	Colmillo de dientes de sable
4581	Parche de pelaje refinado
4582	Cola tupida suave
4583	Melena espesa
4584	Pata de trofeo grande
4585	Mandíbula de araña chorreando
4586	Piel de raptor lisa
4587	Plumas de raptor tribales
4588	Calavera de raptor prístino
4589	Pluma elegante larga
4590	Pico amarillo curvo
4591	Ojo de águila
4592	Pargo de lodo boquilargo
4593	Siluro mostacherizo
4594	Bacalao Piedrescama
4595	Vino de vid de la selva
4596	Poción curativa descolorida
4597	Receta: poción curativa descolorida
4598	Caña de pescar goblin
4599	Filete de jamón curado
4600	Grog de cereza
4601	Pan de plátano tierno
4602	Calabaza de cosecha lunar
4603	Serviola moteada cruda
4604	Champiñón de bosque
4605	Champiñón con motas rojas
4606	Colmenilla esponjosa
4607	Moho de cueva delicado
4608	Trufa negra cruda
4609	Receta: ala de águila ratonera a la parrilla
4610	Urna de piedra grabada
4611	Perla azul
4612	Corazón de draco negro
4613	Caja negra corroída
4614	Colgante de Myzrael
4615	Ataduras de cinchoscura
4616	Pico de la suerte de Ryedol
4621	Brazal del Embajador Infernus
4622	Nota lacrada para el consejero Belgrum
4623	Poción de escudo de piedra inferior
4624	Receta: poción de escudo de piedra inferior
4625	Flor de Fuego
4626	Fragmento de piedra pequeño
4627	Losa de piedra grande
4628	Brazales de Brazal de roca
4629	Cajón de suministro
4630	Viruta de metal
4631	Tablilla de Ryun'eh
4632	Arcón de bronce ornamentado
4633	Arcón de bronce pesado
4634	Arcón de hierro
4635	Amuleto de Piemartillo
4636	Arcón de hierro fuerte
4637	Arcón de acero
4638	Arcón de acero reforzado
4639	Kelp marino encantado
4640	Signo de la Tierra
4641	Mano de Dagun
4643	Manteo de acero rictus
4644	El corazón del legado
4645	Cadenas de Hematus
4646	Estrella de Xil'yeh
4647	Compendio de Yagyin
4648	Sigilo del Martillo
4649	Nota de Agarrahueso
4650	Nota de Bel'dugur
4652	Escudo Salbac
4653	Botas con talón de acero
4654	Fósil misterioso
4655	Carne de almeja gigante
4656	Calabaza pequeña
4658	Capa de guerrero
4659	Faja de guerrero
4660	Botas para caminar
4661	Manto brillante
4662	Capa de oficial
4663	Cinturón de oficial
4665	Capa quemada
4666	Cinturón de cuero quemado
4668	Capa de anillas de batalla
4669	Faja de anillas de batalla
4671	Capa ancestral
4672	Cinturón ancestral
4674	Capa tribal
4675	Cinturón tribal
4676	Guanteletes esqueléticos
4677	Capa de veterano
4678	Faja de veterano
4680	Capa de agua estancada
4681	Faja de agua estancada
4683	Capa Vinculahechizo
4684	Cinturón Vinculahechizo
4686	Capa de paño barbárico
4687	Cinturón de paño barbárico
4689	Capa de caza
4690	Cinturón de caza
4692	Capa ceremonial
4693	Cinturón de cuero ceremonial
4694	Espaldares bruñidos
4695	Capa bruñida
4696	Pichel de la lápida de Tidesippe
4697	Faja bruñida
4698	Manto de profeta
4699	Cinturón de profeta
4700	Bufas de cuero grabado
4701	Capa grabada
4702	Pico de prospector
4703	Herramientas rotas
4705	Espaldares de escamas luminiscentes
4706	Capa de escamas luminiscentes
4707	Faja de escamas luminiscentes
4708	Cinturón brillante
4709	Manto de cuero de bosque
4710	Capa de bosque
4711	Capa de luz trémula
4712	Faja de malla de luz trémula
4713	Capa de hilo de plata
4714	Fajín de hilo de plata
4715	Capa blasonada
4716	Capa de combate
4717	Cinturón de combate de malla
4718	Manto Cielo Nocturno
4719	Capa Cielo Nocturno
4720	Fajín Cielo Nocturno
4721	Manto de insignia
4722	Capa de insignia
4723	Pantalones de Humbert
4724	Yelmo de Humbert
4725	Espaldares de jefe de brigada
4726	Capa de jefe de brigada
4727	Faja de jefe de brigada
4728	Hombro de Oposti
4729	Manto aurora
4731	Insignias con inscripciones
4732	Capa con inscripciones
4733	Espaldar Forjanegra
4734	Manto Escapabruma
4735	Capa Escapabruma
4736	Fajín Escapabruma
4737	Bufas de cuero imperial
4738	Cinturón de cuero imperial
4739	Carne de zancudo de llanura
4740	Pluma de zancudo de llanura
4741	Leotardos de caballería de Stromgarde
4742	Pelambre de puma de las montañas
4743	Fragmento cristalino pulsante
4744	Brazaletes rúnicos Arcanos
4745	Brazales de jinete de guerra
4746	Toga de cuentacondenas
4747	Poza de Ventoro
4748	Poza de agua de Cuerno Rojo
4749	Agua de poza Brabacrín
4751	Talón de Furia del viento
4752	Pluma azur
4753	Pluma de bronce
4755	Jarra de agua
4756	Pelambre de gato estropeada
4757	Cáscaras de huevo rotas
4758	Garra de lobo de pradera
4759	Garra de zancudo de llanura
4763	Arco corvo Bosque Negro
4765	Espada esmaltada
4766	Hoja feral
4767	Guantes de paño de cobre
4768	Guantes de adepto
4769	Péñola trofeo de aguilón
4770	Cinturón Lomopelo
4771	Capa de la cosecha
4772	Capa cálida
4775	Pico roto
4776	Pluma erizada
4777	Gran maza Maderaférrea
4778	Maza con pinchos pesada
4779	Diente de kodo mate
4780	Fragmento de cuerno de kodo
4781	Jubón susurrador
4782	Toga de solsticio
4783	Tótem de Vientaguilar
4784	Piedra inerte
4785	Cinturón de azufre
4786	Cinturón de hombre sabio
4787	Brea ardiente
4788	Botas de agilidad
4789	Botas de establo
4790	Capa inferno
4791	Agua encantada
4792	Capa espíritu
4793	Capa nemorosa
4794	Brazales de lobo
4795	Brazales de oso
4796	Brazales de búho
4797	Capa ígnea
4798	Capa rúnica pesada
4799	Capa anticuada
4800	Pantalones de anillas poderosos
4801	Garras de acechador
4802	Puma de las estepas garras
4803	Colmillo alfa de pradera
4804	Corazón de lobo de pradera
4805	Fémur de puma de las estepas
4806	Escama de zancudo de llanura
4807	Molleja de aguilón
4808	Piedra de pozo
4809	Bellota ámbar
4810	Protectores de roca
4813	Collar de cuero pequeño
4814	Colmillo descolorido
4816	Leotardos de legionario
4817	Espada claymore bendita
4818	Espada de verdugo
4819	Sujetapapeles de Fizsprocket
4820	Rodela de guardián
4821	Rodela de oso
4822	Disco de búho
4823	Agua de los Profetas
4824	Hacha borrosa
4825	Hacha callosa
4826	Hacha de maleante
4827	Cinturón zahorí
4828	Cinturón de viento nocturno
4829	Cinturón de soñador
4830	Leotardos de dientes de sable
4831	Pantalones de acecho
4832	Pareo místico
4833	Hombreras gloriosas
4834	Documentos de Ventura y Cía.
4835	Hombreras de élite
4836	Orbe a prueba de fuego
4837	Fuerza de Voluntad
4838	Orbe de Poder
4840	Bayoneta
4841	Cuerno de Arra'chea
4843	Runa ámbar
4844	Piedra rúnica ópalo
4845	Piedra rúnica de diamante
4846	Diente núm. 5
4847	Grilletes de vínculo elemental de Lotwil
4848	Hocico de jabaguerrero
4849	Costillar de jabaguerrero
4850	Planes de ataque Lomopelo
4851	Mapa manchado
4852	Bomba cegadora
4854	Capa con marca de demonio
4855	Unused Cloth Shoulder A01 Gray
4856	Unused Cloth Shoulder A02 Yellow
4857	Unused Cloth Shoulder B01 Silver
4858	Unused Cloth Shoulder B02 Black
4859	Medallón de hoja ardiente
4860	Escama de furia brillante
4861	Túnica de plumas impoluta
4862	Cola de escórpido obrero
4863	Herramientas gnómicas
4864	Calavera de Minshina
4865	Pelambre estropeada
4866	Cabeza de Zalazane
4867	Pata de escórpido rota
4869	Garra de Fizzle
4870	Retales de retal
4871	Collar abrasador
4872	Ojo de escórpido seco
4873	Percebe seco y duro
4874	Raspa limpia
4875	Hueso baboso
4876	Botas de cuero sangrientas
4877	Punta de flecha de piedra
4878	Arco roto manchado de sangre
4879	Cadáver de conejo aplastado
4880	Lanza rota
4881	Sobre viejo
4882	Llave de Benedicto
4883	Pedido del almirante Valiente
4886	Glándula de veneno de Venocola
4887	Ojo de makrura intacto
4888	Mucosidad de reptador
4890	Huevo de Colazote
4891	Amuleto de Kron
4892	Pelaje de tigre de Durotar
4893	Colmillo de león de sabana
4894	Riñón de zancudo de llanura
4895	Cuerno de truenagarto
4896	Hígado de kodo
4897	Glándula salivaria de halcón trueno
4898	Glándula relampagueante
4903	Ojo de la Sombra ardiente
4904	Antídoto Venocola
4905	Garra destrozada de Sarkoth
4906	Botas de caminante de lluvia
4907	Túnica de Tierraleña
4908	Brazales nómadas
4909	Leotardos de cazador kodo
4910	Guantes de anillas pintados
4911	Rodela de corteza gruesa
4913	Cinturón de anillas pintado
4914	Guantes de cuero ajados por la batalla
4915	Botas de lana suave
4916	Jubón de lana suave
4917	Leotardos de anillas ajados por la batalla
4918	Saco de suministros
4919	Cinturón de lana suave
4920	Manteo ajado por la batalla
4921	Leotardos cubiertos de polvo
4922	Jubón de anillas dentadas
4923	Hachuela primitiva
4924	Garrote primitivo
4925	Hoja de mano primitiva
4926	Barril vacío de Chen
4928	Muñequeras Correarenas
4929	Armadura de escórpido ligero
4930	Bolsa de cuero hecha a mano
4931	Arco corto de nogal
4932	Máquina para cortar alas de arpía
4933	Capa de luchador salpimentado
4935	Faja ancha metálica
4936	Botas llenas de barro
4937	Rodela de carga
4938	Bastón de madera manchado
4939	Espada bastarda firme
4940	Mandiletes velados
4941	Pegamento muy pegajoso
4942	Botas de pellejo de tigre
4944	Capa cosida a mano
4945	Calavera con resplandor tenue
4946	Botas de peso ligero
4947	Daga dentada
4948	Maza hiriente
4949	Cuchilla de orco
4951	Cinturón de chivato
4952	Brebaje del trueno
4953	Brebaje trogg
4954	Cinturón nómada
4957	Bolsa de dinero vieja
4958	Capa estropeada por el sol
4959	Tomahawk arrojadizo
4960	Perdigón cegador
4961	Bastón Vigilasueños
4962	Guantes con doble capa
4963	Capa Tronacuerno
4964	Machacagoblins
4965	Hacha de mano Pezuña de Sangre
4966	Cabeza de Mazzranache
4967	Escudo de guerrero tribal
4968	Arnés atado
4969	Ataduras reforzadas
4970	Leotardos de kodo basto
4971	Martillo de Skorn
4972	Botas de Abiscorredor
4973	Muñequeras de cazador de las llanuras
4974	Cuchillo de lucha compacto
4975	Rodela de vigilante
4976	Falda escocesa Rocío de niebla
4977	Espada de Sentencia
4978	Martillo de Ryedol
4979	Brazales de paño de piedra
4980	Guantes de prospector
4981	Faltriquera de cinturón de Agmond
4982	Cinturón de prospector rasgado
4983	Pulverizador de rocas
4984	Cráneo de Muerte inminente
4986	Piedra de energía imperfecta
4987	Espada de capitán enano
4988	Sortija obsidiana ardiente
4989	Toga de dragón mago
4990	Sortijas abrasadas
4992	Carta de alistamiento
4995	Carta de reclutamiento firmada
4998	Anillo de sangre
4999	Voluntad de Azora
5000	Sortija de coral
5001	Anillo de corazón
5002	Talismán verde resplandeciente
5003	Medallón estrellafuego de cristal
5004	Marca de Kirin Tor
5005	Colgante de chispa de ascuas
5006	Diario de Khazgorm
5007	Sortija de Espinas
5008	Anillo de mercurio
5009	Anillo de dominación mental
5010	Anillo de oro grabado
5011	Anillo welken
5012	Esporas fungales
5013	Bulbo fértil
5014	Wrapping Paper (PT)
5015	Wrapped Item (PT)
5016	Pantalones de artesano
5017	Nitroglicerina
5018	Pulpa de madera
5019	Nitrato sódico
5020	Llave del botín de Kolkar
5021	Palo explosivo de Gann
5022	Cabeza de Aterrakodos
5023	Cabeza de Verog
5024	Vial escarchado
5025	Cabeza de Hezrul
5026	Alquitrán
5027	Esporas devueltas
5028	Cetro de Lord Sakrasis
5029	Talismán del Señor de los Naga
5030	Brazales centauro
5038	Lágrima de las lunas
5040	Cuchillo de cazador de las Sombras
5042	Papel para envolver con lazo rojo
5043	Obsequio con lazo rojo
5044	Obsequio con lazo azul
5045	Calavera obsequio
5046	Regalo cerrado
5047	Papel de envolver de calaveras
5048	Papel para envolver con lazo azul
5049	Lámina de hierro con autocierre
5050	Llave de ignición
5051	Rata de excavación
5052	Rata cavadora inconsciente
5054	Churumbele
5055	Cuerno de raptor intacto
5056	Muestra de raíz
5057	Sandía madura
5058	Huevo de silítido
5059	Garra de excavación
5060	Herramientas de ladrón
5061	Plata robada
5062	Cabeza de raptor
5063	Cuerno de Gruñucico kreenig
5064	Talón ala de bruja
5065	Anillo de teniente arpía
5066	Planta de fisura
5067	Cabeza de Serena
5068	Semillas secas
5069	Varita de fuego
5071	Varita de las Sombras
5072	Calavera de Lok
5073	Calavera de Nak
5074	Calavera de Kuz
5075	Fragmento de sangre
5076	Envío de botas
5077	Lentes telescópicas
5078	Medalla de Theramore
5079	Ojo de basilisco frío
5080	Libro de contabilidad de Gazlowe
5081	Bolsa de pellejo de kodo
5082	Cuero fino de kodo
5083	Patrón: bolsa de pellejo de kodo
5084	Cabeza del barón Longavera
5085	Colmillo de jabaespín Lomopelo
5086	Pezuñas de astacebra
5087	Pico de zancudo de llanura
5088	Manual de instrucciones de la consola de control
5089	Llave de la consola
5092	Varita Crines de Acero carbonizada
5093	Puñal Crines de Acero
5094	Escudo de guerra Crines de Acero
5095	Atún blanco arco iris
5096	Garras de merodeador
5097	Esmeralda ojo de gato
5098	Caparazón de quijaforte alterado
5099	Pezuña de Lakota'mani
5100	Pellejo de Echeyakee
5101	Colmillo de Ishamuhale
5102	Punta de cola de Owatanka
5103	Pluma de Washte Pawne
5104	Corazón de Isha Awak
5105	Concha explosiva
5107	Camisa de marinero de cubierta
5108	Cuero Hierro Negro
5109	Trapos Rompecantos
5110	Toga de zahorí Dalaran
5111	Manteo de Rathorian
5112	Hoja de ritual
5113	Marca de la Hermandad
5114	Espolón cortado
5115	Hueso de la suerte partido
5116	Pluma de cola larga
5117	Pluma vibrante
5118	Diente plano grande
5119	Pelo suelto refinado
5120	Pelo de cola larga
5121	Escama de kodo sucia
5122	Pelo de kodo grueso
5123	Punta de flecha de acero
5124	Diente de raptor pequeño
5125	Escama cargada
5126	Conocimiento: Disfraz de Defias
5127	Conocimiento: Disfraz de pirata de los Mares del Sur
5128	Muda de piel de lagarto
5129	Conocimiento: Disfraz de enano Hierro Negro
5130	Conocimiento: Disfraz del zahorí Dalaran
5131	Conocimiento: Disfraz de Rompecantos
5132	Conocimiento: Disfraz de Hermandad
5133	Mollejas húmedas
5134	Garra peluda pequeña
5135	Garra fina negra
5136	Oreja peluda rasgada
5137	Ojo brillante
5138	Cabeza de cosechador
5139	Libro sobre Espinas
5140	Partículas cegadoras
5141	Libro sobre Recrecimiento
5142	Libro sobre Cólera 2
5143	Sangre de truenagarto
5145	Libro sobre Toque curativo 2
5147	Libro sobre raíces enredaderas 2
5148	Libro sobre Espinas 2
5149	Libro sobre Cólera 3
5150	Libro sobre Toque curativo 3
5151	Libro sobre Cólera 4
5152	Libro sobre Toque curativo 4
5153	Libro sobre Marca de los salvajes 4
5154	Libro sobre Espinas 3
5155	Libro sobre Marca de los salvajes 2
5156	Libro sobre Cólera 5
5158	Libro sobre Tranquilidad
5160	Libro sobre Toque curativo 5
5163	Libro sobre Marca de los salvajes 3
5164	Alas de halcón trueno
5165	Pluma de solescama
5166	Glándula venenosa de Tejemadera
5167	Huevo de Tejemadera
5168	Semilla de Brezomadera
5169	Brote de Brezomadera
5170	Tumor musgoso
5172	Cápsula de la Muerte
5173	Muerteflor
5174	Nota de Neeru
5175	Tótem de tierra
5176	Tótem de Fuego
5177	Tótem de agua
5178	Tótem de aire
5179	Corazón musgoso
5180	Collar de Armonía
5181	Manteo de seda vibrante
5182	Hoja escalofrío
5183	Corazón de hidra pulsante
5184	Ampolla de cristal llena
5185	Ampolla de cristal
5186	Vasija parcialmente llena
5187	Martillo de Rhahk'Zor
5188	Vasija llena
5189	Fruta resplandeciente
5190	Fronda fulgurante
5191	Púa cruel
5192	Espada de ladrón
5193	Manteo de la Hermandad
5194	Hacha de capataz
5195	Guantes con motas de oro
5196	Atracador de acometida
5197	Ablandador de galletas
5198	Vara para remover galletas
5199	Pantalones de fundición
5200	Arpón para empalar
5201	Bastón de piedra de ascuas
5202	Sobrecamisa de corsario
5203	Garra de merodeador de las estepas
5204	Cinturón Sangrepluma
5205	Fronda crecida
5206	Raíz de ciénaga
5207	Varita opaca
5208	Varita humeante
5209	Varita luminiscente
5210	Varita ardiente
5211	Varita Alba
5212	Varita llameante
5213	Varita agostadora
5214	Varita de Manto de la noche
5215	Varita de ascuas
5216	Varita umbría
5217	Corazón máculo
5218	Corazón Cuaderna purgado
5219	Corteza grabada
5220	Colmillo Tuercepinos
5221	Cabeza de Melenas
5223	Gema de maná vacía
5227	Joya de maná vacía
5229	Petrosangre superior vacía
5232	Piedra de alma menor
5233	Piedra de Relu
5234	Fósil de Gargavino
5235	Varita de alquimista
5236	Varita de combustible
5237	Veneno de aturdimiento mental
5238	Varita de madera
5239	Varita de hueso negro
5240	Varita antorcha
5241	Palo de fuego enano
5242	Varita de ceniza
5243	Eructo flamígero
5244	Varita sagrada consagrada
5245	Varita de invocador
5246	Vara de excavación
5247	Vara de Pena
5248	Varita cegadora
5249	Plata ardiente
5250	Varita carbonizada
5251	Ampolla de adivinación
5252	Varita de Descomposición
5253	Encendedor goblin
5254	Bufas bastas
5255	Tomahawk jabaespín
5256	Sonajero de Kovork
5257	Manteo con caperuza oscuro
5263	Gasa de bolsillo
5264	Muestra de cerveza de obsequio
5265	Cerveza aguada
5266	Ojo de Adaegus
5267	Puñal hindú Escarlata
5268	Cáscara de silítido rajada
5269	Icor de silítido
5270	Almete de la Muerte
5271	Níscalo
5272	Garabatos incomprensibles
5273	Reliquia de Mathystra
5274	Manto rosa
5275	Faja de vínculo
5279	Desollador de arpía
5299	Guantes de la Luna
5302	Rodela de cobalto
5306	Bastón de jinete del viento
5309	Mosquete de soldado
5310	Calzones de lobo marino
5311	Botas con hebillas
5312	Guanteletes ribeteados
5313	Anillo tótem del clan
5314	Manteo de cazador de jabalíes
5315	Guardabrazos de madera
5316	Túnica de malla de corteza
5317	Túnica de moho seco
5318	Hacha Zhovur
5319	Espaldares azotadores
5320	Botas de láminas acolchadas
5321	Espada corta elegante
5322	Martillo de demolición
5323	Linterna eterna
5324	Martillo de ingeniero
5325	Escudo de soldadura
5326	Bastón flamígero
5327	Pantalones de Manitas grasiento
5328	Cinturón cinchado
5329	Figura de gato
5330	Reliquia de copa élfica
5332	Figurita de gato resplandeciente
5334	Puerto con 99 años de antigüedad
5335	Un costal de monedas
5336	Pendiente grell
5337	Guantes caminante
5338	Lacre de piedra lunar antiguo
5339	Reptilia
5340	Cucharón de caldero
5341	Túnica cubierta de esporas
5342	Ponche de raptor
5343	Capa de posadero
5344	Hacha puntiaguda
5345	Martillo madera de piedra
5346	Arco de batalla de orco
5347	Varita pestilente
5348	Pliego desgastado
5349	Magdalena mágica
5350	Agua mágica
5351	Anillo de caza recompensas
5352	Libro: Los Poderes inferiores
5353	Mensaje para Elissa Brisaestelar
5354	Carta para Delgren
5355	Faja de maestro de bestias
5356	Vara para marcar
5357	Amuleto del Valle
5359	Manuscrito de Lorgalis
5360	Reliquia de Altonato
5361	Raspa mondadientes
5362	Mordedor
5363	Pañuelo doblado
5364	Lengüetazo de sal seca
5366	Gema de alma resplandeciente
5367	Instrumento de roca primitivo
5368	Monedero vacío
5369	Hueso roído
5370	Cuchara doblada
5371	Trozo de coral
5373	Talismán de la suerte
5374	Reloj de bolsillo pequeño
5375	Palito para rascarse
5376	Espejo roto
5377	Concha de vieira
5379	Cuchillo de bota
5380	Carta lacrada para Elissa
5381	Carta lacrada para Balthule
5382	Colgante de Anaia
5383	Cabeza de Athrikus Narassin
5385	Pata de reptador
5386	Pelambre de Acechalunas refinado
5387	Capa de Acechalunas encantada
5388	Calavera de Ran Sangradientes
5389	Tótem de fúrbolg corrupto
5390	Mensaje de Fandral
5391	Tierra rara
5392	Daga Cardoleño
5393	Bastón Cardoleño
5394	Guantes de instrucción en tiro con arco
5395	Escudo de Tierraleña
5396	Llave de la Garganta de Fuego
5397	Pólvora Defias
5398	Leotardos canope
5399	Botas de rastreo
5400	Sangre de Cobrahn
5401	Sangre de Pythas
5402	Sangre de Anacondra
5403	Sangre de Serpentis
5404	Hombreras de serpiente
5405	Capa envuelta
5406	Petrosangre menor vacía
5411	Tótem de limpieza Pezuña Invernal
5412	Ojo de trillador
5413	Colmillo de Acechalunas
5414	Cuero cabelludo canoso
5415	Tótem purificador Tronacuerno
5416	Tótem de limpieza Bravacrín
5419	Brazales ferales
5420	Armadura de alma en pena
5421	Hechizo Llamarada ígnea
5422	Leotardos zarza
5423	Colmillo de Boahn
5424	Estatuilla antigua
5425	Faja de escamas rúnicas
5426	Beso de serpiente
5427	Reloj de bolsillo rudimentario
5428	Un libro de cocina exótico
5429	Una bonita roca
5430	Adorno intrincado
5431	Petaca vacía
5432	Pipa de nogal
5433	Muñeca harapienta
5435	Peine lustroso
5437	Pelo de Bathran
5439	Carcaj pequeño
5440	Botella de enfermedad
5441	Faltriquera de pólvora pequeña
5442	Cabeza de Arugal
5443	Rodela con placas de oro
5444	Manteo de minero
5445	Anillo de Zoram
5446	Brazal elemental roto
5447	Brazal elemental dañado
5448	Brazal elemental fracturado
5451	Brazal elemental aplastado
5455	Pergamino divino
5456	Pergamino de adivinación
5457	Garra de vudú cortada
5458	Cinturón tierraleño
5459	Hacha de defensor
5460	Cura de Orendil
5461	Rama de Cenario
5462	Vara de transformación de Dartol
5463	Gema resplandeciente
5464	Asta de hierro
5465	Pata de araña pequeña
5466	Aguijón de escórpido
5467	Carne de kodo
5468	Carne de frenesí tierna
5469	Carne de zancudo
5470	Cola de truenagarto
5471	Carne de ciervo
5472	Kebab de araña Kaldorei
5473	Sorpresa de escórpido
5474	Carne de kodo asado
5475	Llave de madera
5476	Filete de furia
5477	Estofado de zancudo
5478	Estofado de ratas de excavación
5479	Cola de lagarto crujiente
5480	Venado magro
5481	Cuernos de sátiro
5482	Receta: kebab de araña Kaldorei
5483	Receta: sorpresa de escórpido
5484	Receta: carne de kodo asado
5485	Receta: filete de furia
5486	Receta: estofado de zancudo
5487	Receta: estofado de ratas de excavación
5488	Receta: cola de lagarto crujiente
5489	Receta: venado magro
5490	Cabeza Colafuria
5493	Lágrima de Elune
5494	Un puñado de polvo estelar
5498	Perla lustrosa pequeña
5500	Perla iridiscente
5503	Carne de almeja
5504	Carne de almeja ácida
5505	Diario de Teronis
5506	Acechador de ojos redondos
5507	Telescopio ornamentado
5508	Piedra lunar caída
5509	Piedra de salud
5510	Piedra superior de salud
5511	Piedra de salud inferior
5512	Piedra de salud menor
5513	Jade de maná
5514	Ágata de maná
5516	Colmillo de trillanodonte
5517	Llave de bronce diminuta
5518	Llave de hierro diminuta
5519	Pomo de hierro
5520	Diario de Velinde
5521	Llave de Velinde
5522	Piedra de hechizos
5523	Percebe pequeño
5524	Almeja de concha espesa
5525	Almejas hervidas
5526	Sopa de almejas
5527	Conchas envilecidas goblin
5528	Receta: sopa de almejas
5529	Polvo de tumba
5530	Partículas cegadoras
5533	Escrito de Ilkrud Magthrull
5534	Almuerzo de Parker
5535	Compendio de los Caídos
5536	Mitología de los titanes
5537	Cabeza de Sarilus Foulborne
5538	Alianza de Vorrel
5539	Carta de recomendación
5540	Daga de perlas
5541	Martillo iridiscente
5542	Capa con broche de perlas
5543	Diseño: martillo iridiscente
5544	Calavera de Dal Zarpasangrante
5547	Vara reconstruida
5565	Piedra infernal
5566	Asta rota
5567	Gancho de plata
5568	Guijarro liso
5569	Algas
5570	Huevo Musgondo
5571	Faltriquera negra pequeña
5572	Faltriquera verde pequeña
5573	Bolsa de cuero verde
5574	Bolsa de cuero blanco
5575	Costal verde grande
5576	Costal marrón grande
5577	Diseño: brazales de bronce basto
5578	Diseño: peto de bronce plateado
5579	Martillo de guerra de milicia
5580	Martillo de milicia
5581	Bastón de apoyo liso
5582	Salvia de Espolón
5583	Escama de dragón Fey
5584	Mostacho del Crepúsculo
5585	Ojo de corcel
5586	Espada Cardoleño
5587	Garrote de raíz de espinas
5588	Toxina de Lydon
5589	Guanteletes cubiertos de musgo
5590	Brazales de cordón
5591	Manteo chispeado
5592	Faja apretada
5593	Rodela de risco
5594	Carta para Jin'Zil
5595	Martillo de matorral
5596	Arco bosqueceniza
5601	Glándula de huevo eclosionado
5602	Tela de araña pegajosa
5603	Zurrón de Zumbang
5604	Varita élfica
5605	Cuchillo de poda
5606	Guantes de jardinería
5608	Capucha viva
5609	Cincho de determinación férrea
5610	Capa de entrañas
5611	Lágrima de dolor
5612	Puños de hiedra
5613	Bastón del Purificador
5614	Golpe de Seraph
5615	Espada de Leñantro
5616	Desgarrantrañas
5617	Leotardos de vagabundo
5618	Capa de explorador
5619	Ampolla de jade
5620	Vial de sangre inocente
5621	Ampolla de turmalina
5622	Anillo de clero
5623	Ampolla de amatista
5624	Aro de la Orden
5626	Astillacalaveras
5627	Hoja reliquia
5628	Nota de Zamah
5629	Guantes de Puñomartillo
5630	Guantes de paño de viento
5631	Poción de ira
5632	Poción de vuelo cobarde
5633	Gran poción de ira
5634	Poción de acción libre
5635	Garra afilada
5636	Pluma delicada
5637	Colmillo grande
5638	Niebla tóxica
5639	Ampolla de jade llena
5640	Receta: poción de ira
5641	Receta: poción de vuelo cobarde
5642	Receta: poción de acción libre
5643	Receta: gran poción de ira
5644	Escrito sobre Conjurar agua
5645	Ampolla de turmalina llena
5646	Vial de agua bendita
5647	Escrito sobre Traslación
5648	Escrito sobre Armadura de Escarcha 3
5649	Escrito sobre Ventisca
5650	Escrito sobre Conjurar agua 3
5654	Toxina instantánea
5655	Brida de yegua castaña
5656	Brida de caballo marrón
5657	Receta: toxina instantánea
5658	Tratado: Lacre de poderío
5659	Ascuas humeantes
5660	Tratado: Lacre de rectitud
5661	Tratado: Lacre de rectitud 2
5662	Tratado: Lacre de rectitud 3
5663	Cuerno del lobo rojo
5664	Lanzatralla corroída
5665	Cuerno del lobo feroz
5666	Tratado: Lacre de cólera 2
5667	Tratado: Lacre de sabiduría 2
5668	Cuerno del lobo marrón
5669	Restos de polvo de diablo
5670	Tratado: Lacre de cólera 4
5671	Tratado: Lacre de poderío 3
5672	Tratado: Exorcismo
5673	Tratado: Exorcismo 2
5674	Tratado: Exorcismo 3
5675	Escamas cristalizadas
5676	Tratado: Captar a no-muertos
5677	Tratado: Ahuyentar a no-muertos
5678	Tratado: Lacre de sacrificio
5679	Tratado: Lacre de sabiduría 3
5680	Tratado: Lacre de protección 2
5681	Savia corrosiva
5682	Tratado: Ahuyentar a no-muertos 2
5683	Tratado: Escudo divino 2
5684	Tratado: Lacre de salvación
5685	Tratado: Redención
5686	Cabeza de Ordanus
5687	Llave del Guardián
5689	Llave de durmiente
5690	Llave garra
5691	Llave de la carretilla
5692	Detonador a distancia (rojo)
5693	Detonador a distancia (azul)
5694	Explosivos NG-5 (rojo)
5695	Explosivos NG-5 (azul)
5696	Tablilla de choque
5697	Tablilla de tótem curativo
5698	Tablilla de Escudo de relámpagos
5699	Tablilla de Lobo fantasmal
5700	Tablilla de tótem curativo 2
5701	Tablilla de tótem de Argos
5702	Tablilla de tótem agitador 2
5703	Tablilla de Trueno
5704	Tablilla de Respiración acuática
5705	Tablilla de tótem curativo 3
5706	Tablilla de tótem serpiente
5707	Tablilla de Visión lejana
5708	Tablilla de Forma etérea
5709	Tablilla de Caminar sobre el agua
5710	Tablilla de tótem curativo 4
5711	Tablilla de Lobo fantasmal 2
5712	Tablilla de tótem serpiente
5713	Tablilla de Descarga de truenos
5714	Tablilla de tótem para Atrapar 2
5715	Tablilla de Tormenta de relámpagos 3
5716	Tablilla de Restauración 6
5717	Cartas de Ventura y Cía.
5718	Diseños de ingeniería de Ventura y Cía.
5719	Grimorio de Drenaje de vida II
5720	Grimorio de Maldición de Mannoroth II
5721	Grimorio de Crear Petrosangre de hechizos
5722	Grimorio de Maná de sifón II
5723	Grimorio de Maldición de Sargeras III
5724	Grimorio de Maldición de Lenguas
5725	Grimorio de Pestilencia III
5726	Grimorio de Crear Petrosangre superior
5727	Grimorio de Embudo de maná
5728	Grimorio de Lluvia de Fuego II
5729	Grimorio de Miedo III
5730	Libro sobre Rejuvenecimiento
5731	Pergamino de Mensaje
5732	NG-5
5733	Mineral sin identificar
5734	Planos de la Súper Segadora 6000
5735	Sobre lacrado
5736	Brazo mecánico de Gerenzo
5737	Diseños de camaleón: alfa y beta
5738	Talega camaleón
5739	Arnés barbárico
5740	Cohete rojo
5741	Trozo de roca
5742	Daga de gemas
5743	Anillo de piedra prismática
5744	Desollador pálido
5748	Arco largo centauro
5749	Hacha guadaña
5750	Faja de Jefe de Guerra
5751	Capa telaraña
5752	Punto de cola de dracoleón
5753	Corona alborotada
5754	Medallón de jauría de lobos
5755	Trituradora de placas de ónice
5756	Hoja de plata
5757	Cayada de madera dura
5758	Arcón de mitril
5759	Arcón de torio
5760	Arcón eternium
5761	Trineo Yunquemar
5762	Bolsa de lino roja
5763	Bolsa de lana roja
5764	Talega de seda verde
5765	Talega de seda negra
5766	Toga de zahorí inferior
5767	Togas violeta
5768	Entrada a las carreras gnomas
5769	Entrada a las carreras goblin
5770	Togas de Arcana
5771	Patrón: bolsa de lino rojo
5772	Patrón: bolsa de lana roja
5773	Patrón: togas de Arcana
5774	Patrón: talega de seda verde
5775	Patrón: talega de seda negra
5776	Bastón de anciano
5777	Hacha de Valentía
5778	Bastón de apoyo primitivo
5779	Espada bastarda de los Renegados
5780	Cinturón de escama de múrloc
5781	Peto de escama de múrloc
5782	Armadura múrloc gruesa
5783	Brazales de escama de múrloc
5784	Escama de múrloc babosa
5785	Escama múrloc gruesa
5786	Patrón: cinturón de escama de múrloc
5787	Patrón: peto de escama de múrloc
5788	Patrón: armadura múrloc gruesa
5789	Patrón: brazales de escama de múrloc
5790	Diario de Soliceja
5791	Diario de Henrig Soliceja
5792	Medallón de Filonavaja
5793	Corazón de Filonavaja
5794	Veneno de escórpido salado
5795	Caparazón de tortuga endurecido
5796	Aleta dorsal taraceada
5797	Lámina de indurio
5798	Partes de coche cohete
5799	Encargo de piezas de Kravel
5800	Piezas de Kravel
5801	Kraul Guano
5802	Piezas de coches delicadas
5803	Pizca de polvo onírico
5804	Rumores goblin
5805	Corazón de Zeal
5806	Cerveza de tontos
5807	Informe de cerveza de tontos
5808	Glándula de veneno de Alaorgullo
5809	Glándula de veneno de Pico Alto
5810	Cadáver fresco
5811	Crin de Faucehielo
5812	Togas de Antigüedad
5813	Prenda de Emil
5814	Armadura riachuelo
5815	Piedra glacial
5816	Luz de Elune
5817	Arco Lunaris
5818	Varita de destello lunar
5819	Almófar Llamarada sol
5820	Manto feérico
5821	Botas Acechador negro
5822	Guanteletes de seto
5823	Champiñón venenoso
5824	Tablilla de Voluntad
5825	Colgante de Treshala
5826	Esquema de Kravel
5827	Carta de Fizzle Pernolatón
5829	Pico afilado
5830	Cabeza de Kenata
5831	Cabeza de Fardel
5832	Cabeza de Marcel
5833	Mineral indurio
5834	Barril de tabaco de Mok'Morokk
5835	Grog de Mok'Morokk
5836	Caja fuerte de Mok'Morokk
5837	Costilla de Metaleador
5838	Pergamino de piel de kodo
5839	Página de diario
5840	Lengua abrasadora
5841	Corazón abrasador
5842	Muestra de mineral bruta
5843	Garra de Grenka
5844	Fragmentos de Rok'Alim
5845	Costillar de carne
5846	Nota lacrada de Korran
5847	Cabeza de Ancalodo
5848	Hueso hueco de buitre
5849	Cajón de cascos de choque
5850	Nota lacrada de Belgrom
5851	Llave de Cozzle
5852	Planos de regulador de combustible
5853	Caparazón de silítido intacto
5854	Espolón de silítido
5855	Corazón de silítido
5857	Caja con premio gnomo
5858	Caja con premio goblin
5859	Granada de fiesta
5860	Legado de los Aspectos
5861	Comienzos de la amenaza de los no-muertos
5862	Propulsor de seforio
5863	Estatutos de Hermandad
5864	Carnero gris
5865	Propulsor de seforio modificado
5866	Muestra de mineral indurio
5867	Vial grabado
5868	Ampolla grabada llena
5869	Pezuña Partida
5871	Pezuña grande
5872	Carnero marrón
5873	Carnero blanco
5874	Arnés: carnero negro
5875	Arnés: carnero azul
5876	Tubérculo hojazul
5877	Caparazón de silítido rajado
5878	Tabaco superior
5879	Colgante del Crepúsculo
5880	Cajón con agujeros
5881	Cabeza de Kelris
5882	Documentos de capitán
5883	Lengua Fangorroca bípeda
5884	Ojo Niebla Negra sin reventar
5897	Manual de propietario del Husmeador
5916	Llave de cámara gnoma
5917	Informe de espía
5918	Cabeza de orco desafiante
5919	Escudo de hierro ennegrecido
5936	Cinturón de piel de animal
5937	Llave de cámara goblin
5938	Pata de reptador prístina
5939	Guantes de costura
5940	Rodela de huesos
5941	Pantalones de escamas de latón
5942	Colgante enjoyado
5943	Brazales falla
5944	Grebas de las Milicias del pueblo
5945	Diente de Lodomuerto
5946	Nota lacrada para Elling
5947	Certificado Defias
5948	Carta para Jorgen
5949	Tira de papel
5950	Tarjeta de Reethe
5951	Toallita húmeda
5952	Bulbo raquídeo corrupto
5956	Martillo de herrero
5957	Jubón de cuero cosido a mano
5958	Pantalones de cuero refinado
5959	Glándula de veneno ácido
5960	Nota lacrada para el guardia Backus
5961	Pantalones de cuero oscuro
5962	Pantalones guardián
5963	Leotardos barbáricos
5964	Hombreras barbáricas
5965	Capa de guardián
5966	Guantes de guardián
5967	Faja de Nobleza
5968	Botas bastas
5969	Capa de regente
5970	Guantes de serpiente
5971	Manteo de plumas
5972	Patrón: pantalones de cuero refinado
5973	Patrón: leotardos barbáricos
5974	Patrón: capa de guardián
5975	Cinturón de rufián
5976	Tabardo de Hermandad
5996	Elixir de respiración acuática
5997	Elixir de defensa menor
5998	Petición de Pico Tormenta
6016	Muestra de corazón de lobo
6037	Lingote de veraplata
6038	Almeja gigante chamuscada
6039	Receta: almeja gigante chamuscada
6040	Brazales de escamas de oro
6041	Cadena de acero
6042	Escudo con punta de hierro
6043	Contrapeso de hierro
6044	Diseño: escudo con punta de hierro
6045	Diseño: contrapeso de hierro
6046	Diseño: cadena de acero
6047	Diseño: almófar de escamas de oro
6048	Poción de protección de las Sombras
6049	Poción de protección de Fuego
6050	Poción de protección de Escarcha
6051	Poción de protección Sagrada
6052	Poción de protección de Naturaleza
6053	Receta: poción de protección Sagrada
6054	Receta: poción de protección de las Sombras
6055	Receta: poción de protección de Fuego
6056	Receta: poción de Protección de Escarcha
6057	Receta: poción de protección de Naturaleza
6058	Cinturón de cuero ennegrecido
6059	Jubón nómada
6060	Brazales de lienzo
6061	Brazales de piedra gris
6062	Brazales de cordón pesado
6063	Guanteletes de acero frío
6064	Discos de platino en miniatura
6065	Ensayos sobre convergencia dimensional de Khadgar
6066	Cabeza de kan Dez'hepah
6067	Oreja centauro
6068	Receta: aceite de las Sombras
6069	Carne secada de forma rudimentaria
6070	Brazales de piel de lobo
6071	Cristal draenetista
6072	Cabeza de kan Jehn
6073	Cabeza de kan Shaka
6074	Boquilla de cuerno de guerra
6075	Informe de Vime
6076	Pantalones estrechos
6077	Fragmento de llave Maraudine
6078	Escudo de hombre pico
6079	Talismán rudimentario
6080	Corazón de pantera de las Sombras
6081	Hongos de lodazal
6082	Tumor de zancudo de las profundidades
6083	Lágrimas rotas
6084	Leotardos de guardia de Ventormenta
6085	Túnica de lacayo
6086	Suero de la verdad de Faustin
6087	Albarca de Páramos de Poniente
6089	Brebaje de Zraedus
6091	Cajón de piedras de energía
6092	Botas de cría negra
6093	Triturador orco
6094	Hacha atravesadora
6095	Botas deambulantes
6096	Camisa de aprendiz
6097	Camisa de acólito
6098	Toga de neófito
6116	Toga de aprendiz
6117	Camisa de escudero
6118	Pantalones de escudero
6119	Toga de neófito
6120	Camisa de recluta
6121	Pantalones de recluta
6122	Botas de recluta
6123	Toga de novicio
6124	Pantalones de novicio
6125	Arnés de camorrista
6126	Pantalones de trampero
6127	Botas de trampero
6129	Toga de acólito
6130	Camisa de trampero
6131	Pantalones de trampero
6132	Tratado: Lacre de sabiduría
6133	Tratado: Lacre de furia
6134	Manto primitivo
6135	Falda escocesa primitiva
6136	Camisa de matón
6137	Pantalones de matón
6138	Botas de matón
6139	Toga de novicio
6140	Toga de aprendiz
6144	Toga de neófito
6145	Colgante de Clarice
6146	Madera a la deriva desecada
6147	Cinturón viejo de rata
6148	Botas cubiertas de telaraña
6149	Poción de maná superior
6150	Un nudo deshilachado
6166	Mandíbula de coyote
6167	Informe de Neeka
6168	Garra de pargos denteserra
6169	Costillar de Denteserra sin preparar
6170	Componentes de zahorí
6171	Guantes de cuidador de lobos
6172	Provisiones extraviadas
6173	Botas de nieve
6174	Espada aleatoria de Oposti
6175	Artefacto Atal'ai
6176	Escudo cometa enano
6177	Brazales de hierro forjado
6178	Envío a Nethergarde
6179	Manteo de soldado
6180	Piel de eslark
6181	Fetiche de Hakkar
6182	Antorcha poco iluminada
6183	Antorcha pobre sin encender
6184	Pata de reptador monstruoso
6185	Chal de oso
6186	Rebanadora trogg
6187	Defensor enano
6188	Vapuleador de barro
6189	Hombreras de anillas durables
6190	Fragmento draenetista
6191	Botas Kimbra
6192	Cabeza de kan Hratha
6193	Fardo de artefactos de Atal'ai
6194	Segadora para barriles
6195	Armadura encerada
6196	Cayada de Noboru
6197	Jubón de pellejo de crocolisco
6198	Muñequeras jurásicas
6199	Sortija de viuda negra
6200	Cinturón de guerra de Gameg
6201	Botas ágiles
6202	Guantes sin dedos
6203	Escudo matón
6204	Yelmo de lupo tribal
6205	Pala para escarbar
6206	Punzón
6207	JcJ: diseños de torre de la Horda
6208	JcJ: diseños de torre de la Alianza
6209	JcJ: certificado de mina de la Horda
6210	JcJ: certificado de mina de la Alianza
6211	Receta: elixir de fuerza de ogro
6212	Cabeza de Jammal'an
6214	Gran maza de cobre pesada
6215	Palo de lucha equilibrado
6216	Partículas místicas
6217	Vara de cobre
6218	Vara de cobre con runas
6219	Llave inglesa Arcoluz
6220	Fragmento de meteorito
6222	Fórmula: imbuir pechera: espíritu menor
6223	Emblema de Villa Oscura
6226	Mandil sangriento
6238	Toga de lino marrón
6239	Jubón de lino rojo
6240	Jubón de lino azul
6241	Toga de lino blanco
6242	Toga de lino azul
6243	Toga de lana verde
6244	ggggfg
6245	Cartera de Karnitol
6246	Garra de Odio Feroz
6247	Cuerno de Odio Feroz
6248	Veneno Scorpashi
6249	Pellejo de kodo mayor
6250	Cerebro de can manáfago
6251	Ala abisal
6252	Sangre de Guardiavil
6253	Paquete de Zurdibrujo
6256	Caña de pescar
6257	Mollejas de Roc
6258	Hígado de Cueracero
6259	Hígado Groddoc
6260	Tinte azul
6261	Tinte naranja
6262	Diario de Galen
6263	Mono azul
6264	Toga de fiel superior
6265	Fragmento de alma
6266	Jubón de discípulo
6267	Pantalones de discípulo
6268	Túnica de pionero
6269	Pantalones de pionero
6270	Patrón: jubón de lino azul
6271	Patrón: jubón de lino rojo
6272	Patrón: toga de lino azul
6273	Patrón: toga de lana verde
6274	Patrón: mono azul
6275	Patrón: toga de fiel superior
6276	Nota mohosa
6277	Pliego mohoso
6278	Rollo mohoso
6279	Carta mohosa
6280	Misiva mohosa
6281	Calavera armadósea
6282	Pantalones de entierro sacro
6283	El libro de Ur
6284	Runas de Invocación
6285	Grimorio de Egalin
6286	Corazones puros
6287	Fragmento de tablilla Atal'ai
6288	Tablilla Atal'ai
6289	Pargo de loco boquilargo crudo
6290	Pececito luminoso
6291	Pececito luminoso crudo
6292	Pargo de lodo de 5 kilos
6293	Sangre de murciélago seca
6294	Pargo de lodo de 6 kilos
6295	Pargo de lodo de 7 kilos
6296	Parche de crin de murciélago
6297	Calavera vieja
6298	Colmillo de murciélago sangriento
6299	Pescado con mala pinta
6300	Fragmento de colmillo
6301	Calavera de camionero vieja
6302	Ala de insecto delicada
6303	Caballa suave cruda
6304	Página de diario mojada (día 4)
6305	Página de diario mojada (día 87)
6306	Página de diario mojada (día 512)
6307	Mensaje en una botella
6308	Siluro mostacherizo crudo
6309	Siluro de 8 kilos
6310	Siluro de 10 kilos
6311	Siluro de 12 kilos
6312	Corazón de Dalin
6313	Corazón de Comar
6314	Manteo de maestro de lobos
6315	Ballesta de flechas de acero
6316	Delicia de furia de Loch Modan
6317	Frenesí del lago crudo
6318	Bastón de Ley de Odo
6319	Faja del Cegato
6320	Emblema de comandante
6321	Lacre familiar de Filargenta
6323	Cetro del barón
6324	Togas de Arugal
6325	Receta: pececito luminoso
6326	Receta: caballa suave
6327	El pacificador
6328	Receta: pargo de lodo boquilargo
6329	Receta: delicia de furia de Loch Modan
6330	Receta: siluro mostacherizo
6331	Hoja aullante
6332	Anillo de perla negra
6333	Daga Azote de Pinchos
6335	Botas pardas
6336	Túnica de infantería
6337	Leotardos de infantería
6338	Vara de plata
6339	Vara de plata con runas
6340	Pellejo de Fenrus
6341	Lámpara de establo siniestra
6342	Fórmula: encantar pechera: maná menor
6343	Fórmula: imbuir pechera: espíritu
6344	Fórmula: encantar brazal: espíritu menor
6345	Fórmula: imbuir capa: protección
6346	Fórmula: encantar pechera: maná inferior
6347	Fórmula: encantar brazal: fuerza menor
6348	Fórmula: encantar arma: bestiacida menor
6349	Fórmula: encantar arma de 2M: intelecto inferior
6350	Botas de bronce basto
6351	Cajón dentado
6352	Cajón estropeado por el agua
6353	Cofre pequeño
6354	Cofre cerrado pequeño
6355	Cofre cerrado robusto
6356	Cofre maltrecho
6357	Cajón sellado
6358	Bocanegra graso
6359	Pargo de Fuego
6360	Triturador escama de acero
6361	Atún blanco arco iris crudo
6362	Bacalao Piedrescama crudo
6363	Siluro de 14 kilos
6364	Siluro de 16 kilos
6365	Caña de pescar fuerte
6366	Caña de pescar Leñoscuro
6367	Caña de pescar de hierro grande
6368	Receta: atún blanco arco iris
6369	Receta: bacalao Piedrescama
6370	Aceite bocanegra
6371	Aceite de fuego
6372	Poción de velocidad de nado
6373	Elixir de poder de Fuego
6374	Partículas encantadas
6375	Fórmula: encantar brazal: espíritu inferior
6376	Fórmula: encantar botas: aguante menor
6377	Fórmula: encantar botas: agilidad menor
6378	Manteo de profeta
6379	Cinturón de cuero grabado
6380	Rodela grabada
6381	Capa brillante
6382	Cinturón de cuero de bosque
6383	Rodela de bosque
6384	Camisa azul con estilo
6385	Camisa verde con estilo
6386	Musleras de malla de luz trémula
6387	Brazales de malla de luz trémula
6388	Espaldares de malla de luz trémula
6389	Almófar de malla de luz trémula
6390	Patrón: camisa azul con estilo
6391	Patrón: camisa verde con estilo
6392	Cinturón de Arugal
6393	Guantes de hilo de plata
6394	Botas de hilo de plata
6395	Hombrera de hilo de plata
6396	Coraza blasonada
6397	Guantes blasonados
6398	Cinturón blasonado
6399	Hombreras blasonadas
6400	Escudo de luz trémula
6401	Patrón: camisa de seda oscura
6402	Leotardos de combate de malla
6403	Guardabrazos de combate de malla
6404	Bufas de combate de malla
6405	Pantalones Cielo Nocturno
6406	Botas Cielo Nocturno
6407	Muñequeras Cielo Nocturno
6408	Guates de insignia
6409	Cinturón de insignia
6410	Brazales de insignia
6411	Armadura de jefe de brigada
6412	Botas de jefe de brigada
6413	Brazales de jefe de brigada
6414	Lacre de Sylvanas
6415	Toga aurora
6416	Botas aurora
6417	Capas aurora
6418	Fajín aurora
6419	Mitones con inscripciones
6420	Botas con inscripciones
6421	Cinturón con inscripciones
6422	Yelmo con inscripciones
6423	Grebas Forjanegra
6424	Manteo Forjanegra
6425	Faja Forjanegra
6426	Brazales Forjanegra
6427	Toga Escapabruma
6428	Guantes Escapabruma
6429	Sombrero de zahorí escapabruma
6430	Peto de cuero imperial
6431	Botas de cuero imperial
6432	Capa imperial
6433	Yelmo de cuero imperial
6435	Gema ardiente imbuida
6436	Gema ardiente
6438	Brazal elemental mate
6439	Brazal de vínculo roto
6440	Látigo cerebral
6441	Cabellera Acechasombras
6442	Cristal del oráculo
6443	Pellejo descarriado
6444	Lengua bípeda
6445	Muda de piel frágil
6446	Bolsa de piel de serpiente
6447	Escudo de caparazón de tortuga desgastado
6448	Punta de cola
6449	Capa de escamas de lagarto resplandeciente
6450	Venda de seda
6451	Venda de seda pesada
6452	Antídoto
6453	Antídoto fuerte
6454	Manual: antídoto fuerte
6455	Rueda de carro vieja
6456	Babosa ácida
6457	Piezas de ingeniería oxidadas
6458	Pescado cubierto de aceite
6459	Botines indómitos
6460	Garra de Cobrahn
6461	Hombreras con babosas taraceadas
6462	Cajón seguro
6463	Anillo de fantasma profundo
6464	Esencia de lamentos
6465	Toga del Mocasín
6466	Capa de escamas desviadas
6467	Guantes de escamas desviadas
6468	Cinturón de escamas desviadas
6469	Golpe venenoso
6470	Escama desviada
6471	Escama desviada perfecta
6472	Víbora hiriente
6473	Armadura del Colmillo
6474	Patrón: capa de escamas desviadas
6475	Patrón: guantes de escamas desviadas
6476	Patrón: cinturón de escamas desviadas
6477	Fajín de pradera
6478	Vapuleadores de ratas
6479	Colgante Malem
6480	Leotardos desviados escurridizos
6481	Guanteletes de Damire
6482	Botas de caminante de fuego
6486	Escama chamuscada
6487	Cabeza vil familiar
6488	Tablilla simple
6489	Pliego deteriorado
6490	Pliego oscuro
6491	Pliego pesado
6492	Pergamino con hollín
6493	Pliego andrajoso
6494	Pergamino garabateado
6495	Pliego estropeado
6496	Pliego detallado
6497	Pergamino simple
6498	Cuero de kodo grabado
6499	Cuero de kodo grabado
6500	Cuero de kodo grabado
6501	Cuero de kodo grabado
6502	Armadura de escamas violeta
6503	Togas de arlequín
6504	Espada de ala
6505	Bastón creciente
6506	Botas de infantería
6507	Brazales de infantería
6508	Capa de infantería
6509	Cinturón de infantería
6510	Guanteletes de infantería
6511	Toga de oficial
6512	Toga de discípulo
6513	Fajín de discípulo
6514	Capa de discípulo
6515	Guantes de discípulo
6516	Pergamino para invocar diablillos
6517	Cinturón de pionero
6518	Botas de pionero
6519	Brazales de pionero
6520	Capa de pionero
6521	Guantes de pionero
6522	Pez descarriado
6523	Arnés con hebillas
6524	Arnés de cuero con tachuelas
6525	Arnés de bruto
6526	Arnés de batalla
6527	Toga ancestral
6528	Toga Vinculahechizo
6529	Adorno lustroso
6530	Reptadores nocturnos
6531	Toga de paño barbárico
6532	Adornos brillante
6533	Atractor de peces acuadinámico
6534	Lingotes de acero forjado
6535	Tablilla de Verga
6536	Jubón de sauce
6537	Botas de sauce
6538	Toga de sauce
6539	Cinturón de sauce
6540	Pantalones de sauce
6541	Guantes de sauce
6542	Manteo de sauce
6543	Brazales de sauce
6544	Pergamino de invocación de abisario
6545	Armadura de soldado
6546	Leotardos de soldado
6547	Guanteletes de soldado
6548	Faja de soldado
6549	Capa de soldado
6550	Muñequeras de soldado
6551	Botas de soldado
6552	Túnica de bardo
6553	Pantalones de bardo
6554	Guantes de bardo
6555	Capa de bardo
6556	Brazales de bardo
6557	Botas de bardo
6558	Cinturón de bardo
6559	Rodela de bardo
6560	Escudo de soldado
6561	Armadura acolchada de profeta
6562	Botas fulgurantes
6563	Brazales fulgurantes
6564	Capa fulgurante
6565	Guantes fulgurantes
6566	Hombrera fulgurante
6567	Armadura fulgurante
6568	Pantalones fulgurantes
6569	Toga fulgurante
6570	Fajín fulgurante
6571	Rodela de exploración
6572	Escudo de defensor
6573	Botas de defensor
6574	Brazales de defensor
6575	Capa de defensor
6576	Faja de defensor
6577	Guanteletes de defensor
6578	Leotardos de defensor
6579	Bufas de defensor
6580	Túnica de defensor
6581	Cinturón de exploración
6582	Botas de exploración
6583	Brazales de exploración
6584	Túnica de exploración
6585	Capa de exploración
6586	Guantes de exploración
6587	Pantalones de exploración
6588	Bufas de exploración
6589	Sortija viridiana
6590	Botas Forjabatalla
6591	Muñequeras Forjabatalla
6592	Armadura Forjabatalla
6593	Capa Forjabatalla
6594	Faja Forjabatalla
6595	Guanteletes Forjabatalla
6596	Musleras Forjabatalla
6597	Hombreras Forjabatalla
6598	Rodela Derviche
6599	Escudo Forjabatalla
6600	Cinturón Derviche
6601	Botas Derviche
6602	Brazales Derviche
6603	Túnica Derviche
6604	Manteo Derviche
6605	Guantes Derviche
6607	Leotardos Derviche
6608	Armadura brillante
6609	Paño de sabio
6610	Toga de sabio
6611	Fajín de sabio
6612	Botas de sabio
6613	Brazales de sabio
6614	Capa de sabio
6615	Guantes de sabio
6616	Pantalones de sabio
6617	Manto de sabio
6619	Manual: el camino de la defensa
6620	Pliego elaborado
6621	Manual de Mofa
6622	Espada de Zeal
6623	Pergamino para invocar a Súcubo
6624	Cerveza de Ken'zigla
6625	Colgante cubierto de tierra
6626	Colgante de Dogran
6627	Peto de escama mutante
6628	Garra de cuervo
6629	Manteo esporidio
6630	Rodela de nube de semillas
6631	Raíz viva
6632	Capa de escama Fey
6633	Rebanadora de carnicero
6634	Ungüento de ritual
6635	Sapta de tierra
6636	Sapta de fuego
6637	Sapta de agua
6638	Sapta de aire
6640	Capucha de acechador vil
6641	Hoja inquietante
6642	Armadura fantasma
6643	Pececito hinchado
6644	Caballa hinchada
6645	Pargo de lodo hinchado
6646	Atún hinchado
6647	Siluro hinchado
6648	Pergamino de tótem Piel de piedra
6649	Pergamino de tótem abrasador
6650	Pergamino de tótem de corriente purificadora
6651	Botella de vino rota
6652	Faltriquera de componentes
6653	Antorcha de la Llama durmiente
6654	Antorcha de la Llama eterna
6655	Ascua resplandeciente
6656	Cuarzo en bruto
6657	Delicia desviada sabrosa
6658	Collar de muestra
6659	Pantalones escarabajo
6660	Daga de Julie
6661	Receta: delicia desviada sabrosa
6662	Elixir de crecimiento gigante
6663	Receta: elixir de crecimiento gigante
6664	Manto vudú
6665	Brazales embrujados
6666	Botas dragado
6667	Capa de ingeniero
6668	Botas de dibujante
6669	Sortija sacra
6670	Armadura de pantera
6671	Leotardos de Jugernauta
6672	Esquema: bomba cegadora
6675	Brazales templados
6676	Rodela de agente
6677	Varita de artesano de hechizos
6678	Sortija de Gracia élfica
6679	Perforador de armaduras
6681	Pincho de espinas
6682	Togas de médium
6684	Vara de mando de Husmeador
6685	Manto de médium
6686	Casco con comillo
6687	Crea cadáveres
6688	Penacho Susurravientos
6689	Bastón de espíritu del viento
6690	Leotardos de Ferine
6691	Carne de Colmillosucio
6692	Atracador en punta
6693	Garra de Agamaggan
6694	Corazón de Agamaggan
6695	Amuleto de hueso estigio
6696	Arco de acechador nocturno
6697	Manto ala de murciélago
6698	Piedra de Pierce
6707	Piedra de Lapidis
6708	Piedra de Goodman
6709	Jubón Resplandor lunar
6710	Patrón: jubón Resplandor lunar
6711	Piedra de Kurtz
6712	Cerradura de prácticas
6713	Pantalones rasgados
6714	Dinamita EZ-Thro
6715	Pinzas de batería estropeadas
6716	Esquema: dinamita EZ-Thro
6717	Mecanismo eléctrico
6718	Electromuelle
6719	Cinturón Portavientos
6720	Penacho de cazador de espíritus
6721	Peto de Kor
6722	Esposas bestiales
6723	Medalla de Coraje
6724	Piedra de Backus
6725	Rodela de mármol
6726	Cinturón personalizado de Razzeric
6727	Mandiletes de competición de Razzeric
6728	Piedra de Brownell
6729	Mechero de gasolina de Fizzle
6730	Cadena de Forjaz
6731	Peto de Forjaz
6732	Guantes de mecánico gnómico
6733	Guanteletes de Forjaz
6734	Diseño: cadena de Forjaz
6735	Diseño: peto de Forjaz
6736	Diseño: guanteletes de Forjaz
6737	Pantalones de hojas secas
6738	Creciente sangrante
6739	Objetivo de Abiscorredor
6740	Fajín azur
6741	Espada de guerra orca
6742	Faja Puño de piedra
6743	Anillo de sustención
6744	Guantes de Kapelan
6745	Manteo Correveloz
6746	Rodela de basalto
6747	Espaldares Déspota
6748	Anillo de mono
6749	Sortija de tigre
6750	Aro de serpiente
6751	Chal de luto
6752	Botas de lancero
6753	Talismán de plumas
6754	Monedero grande
6755	Un pequeño contenedor de gemas
6756	Joyero
6757	Sello de Jaina
6766	Flayed Demon Skin (old2)
6767	Colgante de Tyranis
6773	Cadena de maleante Gelkis
6774	Dedo de Uthek
6775	Escrito sobre Divinidad
6776	Escrito sobre Valor
6777	Escrito sobre Rectitud
6778	Escrito sobre Justicia
6779	Escrito sobre Nobleza
6780	Fajín lila
6781	Jarra de Bartleby
6782	Placa del alguacil Haggard
6783	Llave de diente de muerto
6784	Manoplas con abrazaderas
6785	Poderes del vacío
6786	Vestido simple
6787	Vestido de lana blanco
6788	Cinturón de cazador Magram
6789	Manta ceremonial centaura
6790	Anillo de Calma
6791	Botas de demonio
6792	Espaldares sanguinos
6793	Brazales áuricos
6794	Guanteletes Tempesfuego
6795	Camisa blanca de aventurero
6796	Camisa de aventurero roja
6797	Salta ojos
6798	Arcabuz explosivo
6799	Cabeza de Vejrek
6800	Mineral umbrío
6801	Mandil barroco
6802	Espada de Augurio
6803	Caña profética
6804	Martillo tormenta de viento
6805	Cuerno de Vorlus
6806	Llama de danza
6807	Estofado de anca de rana
6808	Mineral de elunita
6809	Medallón de Elura
6810	Gargantilla de Surena
6811	Lentes de peces acuadinámicas
6812	Caja de elunita
6826	Escama luminosa
6827	Caja de suministros
6828	Rodela visionaria
6829	Espada de Serenidad
6830	Mascahuesos
6831	Amenaza negra
6832	Capa de Apestado
6833	Camisa de esmoquin blanca
6834	Esmoquin negro
6835	Pantalones de esmoquin negro
6836	Zapatos para vestido
6837	Vestido de boda
6838	Colmillo de araña abrasado
6839	Cuerno carbonizado
6840	Cuerno galvanizado
6841	Vial de flogisto
6842	Instrucciones de Furen
6843	Tonel de brebaje
6844	Sangre ardiente
6845	Roca ardiente
6846	Pergamino Defias
6847	Guión Hierro Negro
6848	Coral abrasador
6849	Cáscara asolada
6850	Cabellera Sangrapellejo
6851	Esencia del exilio
6852	Ojo eterno
6866	Símbolo de Vida
6887	Serviola moteada
6888	Huevo cocido con hierbas
6889	Huevo pequeño
6890	Carne de oso ahumado
6891	Receta: huevo cocido con hierbas
6892	Receta: carne de oso ahumado
6893	Llave de taller
6894	Corazón espirálico
6895	Martillo de herrería de Jordan
6897	Manual: camino del rabioso
6898	Orbe de Soran'ruk
6899	Orbe de brujo 35
6900	Toga de sangre dorada encantada
6901	Manteo de trillador resplandeciente
6902	Sortijas de Serra'kis
6903	Pantalones de soñador de mirada
6904	Mordisco de Serra'kis
6905	Hacha arrecife
6906	Puños de algae
6907	Armadura tortuga
6908	Vínculo de Ghamoo-ra
6909	Golpe de la hidra
6910	Pantalones de sanguijuela
6911	Cincho musgoso
6912	Duramen
6913	Núcleo de duramen
6914	Fragmento Soran'ruk
6915	Fragmento de Soran'ruk grande
6916	Escrito sobre Divinidad
6926	Notas de Furen
6927	Oreja de Will grande
6928	Gargantilla de Petrosangre
6929	Pliego de Bath'rah
6930	Vara de Mediación
6931	Escrito mohoso
6947	Veneno instantáneo
6948	Piedra de hogar
6949	Veneno instantáneo 2
6950	Veneno instantáneo 3
6951	Veneno de aturdimiento mental II
6952	Pelaje de oso grueso
6953	Puño de Verigan
6966	Hacha elunita
6967	Espada elunita
6968	Martillo elunita
6969	Daga elunita
6970	Favor de Furen
6971	Almófar endurecido con fuego
6972	Camisote endurecido con fuego
6973	Leotardos endurecidos con fuego
6974	Guanteletes endurecidos con fuego
6975	Hacha espirálica
6976	Martillo de guerra espirálico
6977	Espada espirálica
6978	Hacha umbría
6979	Hacha de Haggard
6980	Daga de Haggard
6981	Daga umbría
6982	Maza umbría
6983	Martillo de Haggard
6984	Espada umbría
6985	Espada de Haggard
6986	Loto carmesí
6987	Escama de pescado
6988	Pergamino para invocar manáfagos
6989	Vial de sangre de odio feroz
6990	Piedra infernal inferior
6991	Carbón humeante
6992	Envío de mineral de Jordan
6993	Envío de mineral refinado de Jordan
6994	Madera de roble de Piedrablanca
6995	Gema kor corrupta
6996	Apuntes sobre armas de Jordan
6997	Manuscrito andrajoso
6998	Botas Nimbus
6999	Escrito del Conciliábulo
7000	Faja de duramen
7001	Cetro de lápida
7002	Rodela ártica
7003	Broches de escarabajos
7004	Manteo de prelación
7005	Cuchillo para desollar
7006	Escrito reconstruido
7007	Equipamiento de élite de Backus
7026	Cinturón de lino
7027	Botas de oscuridad
7046	Pantalones de seda azur
7047	Manos de Oscuridad
7048	Caperuza de seda azur
7049	Guantes de fe verdadera
7050	Cinta de seda
7051	Jubón terráneo
7052	Cinturón de seda azur
7053	Capa de seda azur
7054	Toga de Poder
7055	Cinturón de seda carmesí
7056	Capa de seda carmesí
7057	Hombreras de seda verde
7058	Jubón de seda carmesí
7059	Hombreras de seda carmesí
7060	Hombreras azur
7061	Cinturón de seda terránea
7062	Pantalones bombacho de seda carmesí
7063	Toga de seda carmesí
7064	Guantes de seda carmesí
7065	Armadura de seda verde
7067	Elemental de tierra
7068	Elemental de Fuego
7069	Elemental de aire
7070	Elemental de agua
7071	Hebilla de hierro
7072	Escama Naga
7073	Colmillo roto
7074	Garra astillada
7075	Núcleo de tierra
7076	Esencia de tierra
7077	Corazón de fuego
7078	Esencia de Fuego
7079	Globo de agua
7080	Esencia de agua
7081	Aliento del Viento
7082	Esencia de aire
7083	Gema kor purificada
7084	Patrón: hombreras de seda carmesí
7085	Patrón: hombreras azur
7086	Patrón: cinturón de seda terránea
7087	Patrón: capa de seda carmesí
7088	Patrón: toga de seda carmesí
7089	Patrón: capa de seda azur
7090	Patrón: armadura de seda verde
7091	Patrón: guantes de fe verdadera
7092	Patrón: manos de Oscuridad
7093	Patrón: botas de oscuridad
7094	Rama de madera a la deriva
7095	Botas de ciénaga
7096	Pluma arrancada
7097	Carne de pata
7098	Colmillo astillado
7099	Pinza cortada
7100	Icor pegajoso
7101	Ojo de insecto
7106	Guantes zodíaco
7107	Cinturón de las Estrellas
7108	Escudo de infantería
7109	Rodela de pionero
7110	Armadura de hilo de plata
7111	Armadura Cielo Nocturno
7112	Armadura Aurora
7113	Armadura Escapabruma
7114	Patrón: guantes de seda azur
7115	Hacha reliquia
7116	Daga reliquia
7117	Martillo reliquia
7118	Espada reliquia
7119	Antena retorcida
7120	Bastión de Ruga
7126	Lingote de hierro humeante
7127	Azurita en polvo
7128	Capucha de sátiro sin rajar
7129	Guanteletes brutales
7130	Yelmo brutal
7131	Tibia de Faucedraco
7132	Musleras brutales
7133	Camisote brutal
7134	Tibia de Faucedraco robusta
7135	Tibia de Faucedraco rota
7146	La llave Escarlata
7148	Pinzas de batería goblin
7166	Daga de cobre
7170	Espada aleatoria de Oposti FOO
7187	Botas de VanCleef
7188	Escudo de guardia de Ventormenta
7189	Botas cohete goblin
7190	Botas cohete abrasadas
7191	Cableado fusionado
7192	Esquema: botas cohete goblin
7206	Muestra de agua del Lago Espejo
7207	Frasco de Jennea
7208	Llave de Tazan
7209	Cartera de Tazan
7226	Trastónitor maguitronic
7227	Bocas de dragón de Balnir
7228	Helado de frambuesa de Tigule.
7229	Jubón de expedicionario
7230	Martillo poderoso de acometida
7231	Carta de presentación de Astor
7247	Cofre de arcas de contención
7249	Gema cargada de la falla
7266	Tratado de Ur sobre la magia de las Sombras
7267	Seda de araña prístina
7268	Muestra de agua Xavian
7269	Frasco de Deino
7270	Cabello de la Hermana sonriente
7271	Colmillo de marfil impecable
7272	Zarza electrificada
7273	Palo de tótem Secacorteza
7274	Rituales de Poder
7275	Los pergaminos de Agamaggan
7276	Capa de cuero cosida a mano
7277	Brazales de cuero cosidos a mano
7278	Carcaj de cuero ligero
7279	Faltriquera de munición de cuero pequeña
7280	Pantalones de cuero basto
7281	Brazales de cuero ligero
7282	Pantalones de cuero ligero
7283	Capa de cría negra
7284	Guantes de cachorro rojo
7285	Guantes de cuero livianos
7286	Escama de cría negra
7287	Escama de cachorro rojo
7288	Patrón: pantalones de cuero basto
7289	Patrón: capa de cría negra
7290	Patrón: guantes de cría de dragón roja
7291	Orbe infernal
7292	Arca de contención llena
7293	Gema de maná Dalaran
7294	Libro de contabilidad de Andron
7295	Cuaderno de Tazan
7296	Antorcha apagada
7297	Perdición de Morbent
7298	Hoja de Astucia
7306	Cabeza de Fenwick
7307	Gusano carnívoro
7308	Canto de Manifestación
7309	Informe de estado Dalaran
7326	Hacha de Thun'grim
7327	Daga de Thun'grim
7328	Maza de Thun'grim
7329	Espada de Thun'grim
7330	Rodela de infiltrador
7331	Escudo Falange
7332	Armadura majestuosa
7333	Silbato de sobrestante
7334	Toga de floración
7335	Túnica grisezna
7336	Cadena de madera salvaje
7337	La roca
7338	Anillo de ánimo
7339	Anillo de diamantes minúscula
7340	Solitario de diamante impecable
7341	Anillo con cubo de zirconio
7342	Sortija de plata de Piffeny
7343	Llave inglesa de Bingles
7344	Antorcha de Llama sagrada
7345	Destornillador de Bingles
7346	Martillo de Bingles
7347	Inversor de piñón de Bingles
7348	Guantes de flechero
7349	Guantes de herborista
7350	Brazales de discípulo
7351	Botas de discípulo
7352	Hombreras de cuero terráneo
7353	Armadura acolchada de anciano
7354	Botas de anciano
7355	Brazales de anciano
7356	Capa de anciano
7357	Sombrero de anciano
7358	Guantes de ratero
7359	Guantes terráneos pesados
7360	Patrón: guantes de cuero oscuro
7361	Patrón: guantes de herborista
7362	Patrón: hombreras de cuero terráneo
7363	Patrón: guantes de ratero
7364	Patrón: guantes terráneos pesados
7365	Dentrituradora goblin
7366	Guantes de anciano
7367	Manto de anciano
7368	Pantalones de anciano
7369	Toga de anciano
7370	Fajín de anciano
7371	Carcaj pesado
7372	Faltriquera de munición de cuero pesado
7373	Leotardos de cuero oscurecido
7374	Armadura de cuero oscurecido
7375	Armadura de cría verde
7376	Cartucho de Bingles
7377	Capa de cuero escarchada
7378	Brazales oscurecidos
7386	Brazales de cría verde
7387	Cinturón oscurecido
7388	Llave calavera
7389	Libro de contabilidad de Ventura y Cía.
7390	Botas oscurecidas
7391	Botas veloces
7392	Escama de cría verde
7406	Cordón de infiltrador
7407	Armadura de infiltrador
7408	Hombreras de infiltrador
7409	Botas de infiltrador
7410	Brazales de infiltrador
7411	Capa de infiltrador
7412	Guantes de infiltrador
7413	Almete de infiltrador
7414	Pantalones de infiltrador
7415	Bufas Derviche
7416	Brazales Falange
7417	Botas Falange
7418	Peto Falange
7419	Capa Falange
7420	Protegecabezas Falange
7421	Guanteletes Falange
7422	Faja Falange
7423	Leotardos Falange
7424	Bufas Falange
7425	Cabeza de Cyrik
7426	Anillo cerúleo
7427	Talismán cerúleo
7428	Pellejo de gato de las Sombras
7429	Armadura del Crepúsculo
7430	Toga del Crepúsculo
7431	Pantalones del Crepúsculo
7432	Capucha del Crepúsculo
7433	Guantes del Crepúsculo
7434	Botas del Crepúsculo
7435	Manto del Crepúsculo
7436	Manteo del Crepúsculo
7437	Puños del Crepúsculo
7438	Cinturón del Crepúsculo
7439	Peto de centinela
7440	Pantalones de centinela
7441	Cofia de centinela
7442	Llave de Gyromast
7443	Guantes de centinela
7444	Botas de centinela
7445	Hombreras de centinela
7446	Capa de centinela
7447	Brazales de centinela
7448	Faja de centinela
7449	Patrón: leotardos de cuero oscurecido
7450	Patrón: armadura de cría verde
7451	Patrón: brazales de cría verde
7452	Patrón: botas oscurecidas
7453	Patrón: botas veloces
7454	Peto de caballero
7455	Musleras de caballero
7456	Protegecabezas de caballero
7457	Guanteletes de caballero
7458	Botas de caballero
7459	Espaldares de caballero
7460	Capa de caballero
7461	Brazales de caballero
7462	Faja de caballero
7463	Rodela de centinela
7464	Glifos de Invocación
7465	Emblema de caballero
7466	Sortija bermellón
7467	Collar bermellón
7468	Toga majestuosa
7469	Leotardos majestuosos
7470	Sombrero de zahorí majestuoso
7471	Guantes majestuosos
7472	Botas majestuosas
7473	Manto majestuoso
7474	Capa majestuosa
7475	Puños majestuosos
7476	Fajín majestuoso
7477	Túnica de especialista
7478	Leotardos de especialista
7479	Yelmo de especialista
7480	Guantes de especialista
7481	Botas de especialista
7482	Hombreras de especialista
7483	Capa de especialista
7484	Muñequeras de especialista
7485	Cordón de especialista
7486	Peto de capitán
7487	Leotardos de capitán
7488	Aro de capitán
7489	Guanteletes de capitán
7490	Botas de capitán
7491	Hombreras de capitán
7492	Capa de capitán
7493	Brazales de capitán
7494	Guardarrenes de capitán
7495	Rodela de capitán
7496	Escudo de placas de campo
7497	Sortija de marfil
7498	Parte superior de la llave de Gelkak
7499	Mitad de la llave de Gelkak
7500	Parte inferior de la llave de Gelkak
7506	Mando universal gnómico
7507	Orbe Arcano
7508	Orbe Ley
7509	Toga Tejemaná
7510	Togas inferiores del fuegohechizo
7511	Toga de nudos astral
7512	Toga abisal
7513	Varita Ira Ardiente
7514	Varita Furia de Hielo
7515	Orbe celestial
7516	Instrucciones de Tabetha
7517	Túnica delicada
7518	Toga delicada
7519	Pantalones delicados
7520	Celada delicada
7521	Guantes delicados
7522	Botas delicadas
7523	Hombreras delicadas
7524	Manteo delicado
7525	Brazales delicados
7526	Cinturón delicado
7527	Coraza de cabalista
7528	Leotardos de cabalista
7529	Yelmo de cabalista
7530	Guantes de cabalista
7531	Botas de cabalista
7532	Bufas de cabalista
7533	Capa de cabalista
7534	Brazales de cabalista
7535	Cinturón de cabalista
7536	Escudo de pared de campeón
7537	Escudo gótico
7538	Armadura de campeón
7539	Leotardos de campeón
7540	Casco de campeón
7541	Guanteletes de campeón
7542	Grebas de campeón
7543	Espaldares de campeón
7544	Manteo de campeón
7545	Brazales de campeón
7546	Faja de campeón
7547	Anillo de ónice
7548	Gargantilla de ónice
7549	Abrazo de hada
7550	Honor de guerrero
7551	Talismán opalino entrelazado
7552	Percha de halcón
7553	Sortija del Unicornio
7554	Rama de sauce
7555	Estrella majestuosa
7556	Orbe del Crepúsculo
7557	Vara delicada
7558	Bastón fulgurante
7559	Caña rúnica
7560	Esquema: mando universal gnómico
7561	Esquema: pinzas de batería goblin
7566	Espada de la familia de Agamand
7567	Hacha de la familia de Agamand
7568	Daga de la familia de Agamand
7569	Maza de la familia de Agamand
7586	Esperanza de Tharnariun
7587	Instrucciones de Thun'grim
7606	Guanteletes polares
7607	Varita de dientes de sable
7608	Jarra de profeta de gran calidad
7609	Bastón ámbar de anciano
7610	Esfera aurora
7611	Bastón Escapabruma
7613	Patrón: armadura de cuero verde
7626	Fardo de pieles
7627	Entrega de Dolanaar
7628	Carta anodina
7629	Carga de Ukor
7646	Cajón de suministros del mesón
7666	Collar destrozado
7667	Ampolla de visión de Talvash
7668	Diario manchado de sangre
7669	Rubí del collar destrozado
7670	Zafiro del collar destrozado
7671	Topacio del collar destrozado
7672	Fuente de poder del collar destrozado
7673	Collar de mejoría de Talvash
7674	Envío a Mathias
7675	Calendario de envíos Defias
7676	Té de cardo
7678	Receta: té de cardo
7679	Colmillo de murciélago verdugo
7680	Escama de basilisco espina de jade
7681	Fragmento de gólem obsidiana
7682	Atizador de tortura
7683	Nudillos de latón sangrientos
7684	Manto de mago de sangre
7685	Orbe del profeta olvidado
7686	Ojo de Dorsacerado
7687	Puño de Dorsacerado
7688	Caja torácica de Dorsacerado
7689	Amanecer mórbido
7690	Torno de ébano
7691	Sudario embalsamado
7708	Varita necrótica
7709	Leotardos infestados
7710	Varita de entrenamiento de Loksey
7711	Toga de Doan
7712	Manto de Doan
7713	Vara ilusionaria
7714	Hoja hipnótica
7715	Informe de Onin
7716	Collar destrozado
7717	Devastador
7718	Hombro de Herod
7719	Yelmo de rabioso enfurecido
7720	Sombrero de Melenablanca
7721	Mano de Rectitud
7722	Amuleto Triune
7723	Poderío de Mograine
7724	Guanteletes de Divinidad
7726	Égida del Comandante Escarlata
7727	Espaldares de vigilante
7728	Togas de cautivador
7729	Mosquete Chesterfall
7730	Triturador de cobalto
7731	Talismán de fragmento fantasmal
7733	Bastón de Prehistoria
7734	Seis de bolsa de demonio
7735	Rosa de Jannok
7736	Garrote de lucha
7737	Diario de Sethir
7738	Guantes siempre verde
7739	Manteo de madera
7740	Medallón Gni'kiv
7741	El bastón de Tsol
7742	Esquema: aparato de invisibilidad gnómico
7746	Mención de honor de la Liga de Expedicionarios
7747	Protector vil
7748	Rodela Piedra de potencia
7749	Orbe omega
7750	Manto de Tragedia
7751	Botas de Vorrel
7752	Destripador de sueños
7753	Derramasangre
7754	Botas de presagista
7755	Hombreras pedernal
7756	Guantes adiestramiento de perros
7757	Bastón Tejevientos
7758	Shiv despiadado
7759	Coraza archon
7760	Falda escocesa de Jefe de Guerra
7761	Atracador Garra de acero
7766	Bota marrón vacía
7767	Bota azul vacía
7768	Bota roja vacía
7769	Bota marrón llena
7770	Bota azul llena
7771	Bota roja llena
7786	Partecabezas
7787	Guardián resplendente
7806	Caramelo
7807	Chocolatina
7808	Onza de chocolate
7809	Vestido de Pascua
7810	Vial de agua pura
7811	Gotas que quedan del agua más pura
7812	Brazales de manifestaciones corruptas
7813	Fragmento de Agua
7846	Colmillo de coyote de risco
7847	Molleja de águila ratonera
7848	Fragmento de roca elemental
7866	Vasija de taumaturgia vacía
7867	Vasija de sangre de dragón
7868	Thieven' Kit
7869	Arcón de Lucius
7870	Arcón de vasijas de taumaturgia
7871	Muestra de robo
7872	Útiles de ladrón herrumbrados
7886	Diario sin traducir
7887	Collar y gema indómitos
7888	Collar de mejora de Jarkal
7906	Cuernos de Nez'ra
7907	Certificado de Ratería
7908	Diario de Klaven Mortwake
7909	Aguamarina
7910	Rubí estrella
7911	Veraplata
7912	Piedra sólida
7913	Hombreras de hierro barbárico
7914	Peto de hierro barbárico
7915	Yelmo de hierro barbárico
7916	Botas de hierro barbárico
7917	Guantes de hierro barbárico
7918	Hombrera de mitril pesado
7919	Guanteletes de mitril pesado
7920	Pantalones de escamas de mitril
7921	Pantalones de mitril pesado
7922	Yelmo de placas de acero
7923	Llave de la torre Defias
7924	Brazales de escamas de mitril
7925	Guantes de escamas de mitril
7926	Pantalones de mitril ornamentado
7927	Guantes de mitril ornamentado
7928	Hombrera de mitril ornamentado
7929	Leotardos de guerra orcos
7930	Peto de mitril pesado
7931	Almófar de mitril
7932	Hombreras de escamas de mitril
7933	Botas de mitril pesado
7934	Yelmo de mitril pesado
7935	Peto de mitril ornamentado
7936	Botas de mitril ornamentadas
7937	Yelmo de mitril ornamentado
7938	Guanteletes de veraplata
7939	Peto de veraplata
7941	Hacha de mitril pesado
7942	Hacha azul relumbrante
7943	Espada de mitril maligna
7944	Estoque de mitril deslumbrante
7945	Maza negra grande
7946	Martillo de mitril con runas
7947	Shiv de ébano
7948	Faja de Thero-shan
7949	Leotardos de Thero-shan
7950	Armadura de Thero-shan
7951	Manos de Thero-shan
7952	Botas de Thero-shan
7953	Máscara de Thero-shan
7954	El asolador
7955	Espada claymore de cobre
7956	Martillo de guerra de bronce
7957	Espada magna de bronce
7958	Hacha de batalla de bronce
7959	Plaga
7960	Campeón de veraplata
7961	Hoja fantasma
7963	Peto de acero
7964	Piedra de afilar sólida
7965	Piedrafuerte sólida
7966	Piedra de pulir sólida
7967	Punta de escudo de mitril
7968	Tesoro de los Mares del Sur
7969	Aguijones de mitril
7970	G.E.A.Q.
7971	Perla negra
7972	Icor de no-muerto
7973	Almeja de boca grande
7974	Carne de almeja sabrosa
7975	Diseño: pantalones de mitril pesado
7976	Diseño: escudo con punta de mitril
7977	Diseño: guantes de escamas de mitril
7978	Diseño: hombreras de hierro barbárico
7979	Diseño: peto de hierro barbárico
7980	Diseño: yelmo de hierro barbárico
7981	Diseño: botas de hierro barbárico
7982	Diseño: guantes de hierro barbárico
7983	Diseño: pantalones de mitril ornamentado
7984	Diseño: guantes de mitril ornamentado
7985	Diseño: hombro de mitril ornamentado
7986	Diseño: peto de mitril ornamentado
7987	Diseño: yelmo de mitril ornamentado
7988	Diseño: botas de mitril ornamentado
7989	Diseño: aguijones de mitril
7990	Diseño: yelmo de mitril pesado
7991	Diseño: hombreras de escamas de mitril
7992	Diseño: hacha azul relumbrante
7993	Diseño: estoque de mitril deslumbrante
7994	Diseño: leotardos de guerra orcos
7995	Diseño: brazales de escamas de mitril
7996	Sombrero de pesca desgastado
7997	Máscara de Defias roja
8006	El cachetero
8007	Citrina de maná
8008	Rubí de maná
8009	Piedra de energía de dentrio
8026	Tesoro de la familia Garrett
8027	Tesoro de Krom Brazorrecio
8028	Diseño: martillo de mitril con runas
8029	Diseño: hoja de mitril maligna
8030	Diseño: shiv de ébano
8046	Diario de Kearnen
8047	Seta magenta
8048	Cazasueños Esmeralda
8049	Collar Tuercepinos
8050	Joya de Tallonkai
8051	Pistola de bengalas
8052	Piedra de energía An'Alleum
8053	Fuente de poder obsidiano
8066	Silbato de Fizzule
8067	Proyectil artesanal ligero
8068	Proyectil artesanal pesado
8069	Proyectil artesanal sólido
8070	Vale de recompensa
8071	Palo de fritura
8072	Llave de la torre de Silixiz
8073	Carretilla de mezcla modificada de Zanzil
8074	Cabeza de Gallywix
8075	Masa fermentada mágica
8076	Rollito dulce mágico
8077	Agua mineral mágica
8078	Agua con gas mágica
8079	Agua cristalina mágica
8080	Coraza de placas ligeras
8081	Cinturón de placas ligeras
8082	Botas de placas ligeras
8083	Brazales de placas ligeras
8084	Guantes de placas ligeras
8085	Pantalones de placas ligeras
8086	Hombreras de placas ligeras
8087	Muestra de mezcla alterada de Zanzil
8088	Cinturón de malla de placas
8089	Botas de malla de placas
8090	Brazales de malla de placas
8091	Guantes de malla de placas
8092	Yelmo de malla de placas
8093	Leotardos de malla de placas
8094	Armadura de malla de placas
8095	Aceite de Hinott
8106	Armadura invernal
8107	Botas invernales
8108	Brazales invernales
8109	Capa invernales
8110	Guantes invernales
8111	Manto invernal
8112	Pantalones invernales
8113	Toga invernal
8114	Fajín invernal
8115	Capucha invernal
8116	Cinturón heráldico
8117	Botas heráldicas
8118	Brazales heráldicos
8119	Peto heráldico
8120	Capa heráldica
8121	Guantes heráldicos
8122	Celada heráldica
8123	Leotardos heráldicos
8124	Bufas heráldicas
8125	Brazales de mirmidón
8126	Peto de mirmidón
8127	Manteo de mirmidón
8128	Guanteletes de mirmidón
8129	Faja de mirmidón
8130	Grebas de mirmidón
8131	Yelmo de mirmidón
8132	Leotardos de mirmidón
8133	Espaldares de mirmidón
8134	Defensor de mirmidón
8135	Escudo de cromita
8136	Tumor gigantesco
8137	Brazales de cromita
8138	Peto de cromita
8139	Guanteletes de cromita
8140	Faja de cromita
8141	Grebas de cromita
8142	Barbuta de cromita
8143	Quijotes de cromita
8144	Espaldares de cromita
8146	Garra maligna
8147	Llave de bronce diminuta
8148	Llave de hierro diminuta
8149	Talismán vudú
8150	Sal de roca
8151	Frasco de mojo
8152	Frasco de gran mojo
8153	Atriplex salvaje
8154	Escama de escórpido
8155	Sacrificio de Sathrah
8156	Muñequeras de ajustador
8157	Peto de ajustador
8158	Guanteletes de ajustador
8159	Faja de ajustador
8160	Grebas de ajustador
8161	Visor de ajustador
8162	Quijotes de ajustador
8163	Espaldares de ajustador
8165	Escamas de dragón desgastadas
8167	Escama de tortuga
8168	Pluma negro azabache
8169	Pellejo grueso
8170	Cuero basto
8171	Pellejo basto
8172	Pellejo grueso curado
8173	Complemento grueso para armadura
8174	Sombrero de cuero cómodo
8175	Túnica Nochefugaz
8176	Cinta Nochefugaz
8177	Espada de prácticas
8178	Espada de instrucción
8179	Arco de cadete
8180	Arco de caza
8181	Rifle de caza
8182	Rifle de perdigones
8183	Arco de precisión
8184	Encendedor
8185	Leotardos de escamas de tortuga
8186	Varita funesta
8187	Guantes de escamas de tortuga
8188	Escopeta explosiva
8189	Peto de escamas de tortuga
8190	Espada Hanzo
8191	Yelmo de escamas de tortuga
8192	Hombreras Nochefugaz
8193	Pantalones Nochefugaz
8194	Cascanueces goblin
8195	Capa Nochefugaz
8196	Cimitarra de ébano
8197	Botas Nochefugaz
8198	Brazales de escamas de tortuga
8199	Destructor de campo de batalla
8200	Toga de gran vudú
8201	Máscara de gran vudú
8202	Pantalones de gran vudú
8203	Peto escórpido resistente
8204	Guantes escórpidos resistentes
8205	Brazales escórpidos resistentes
8206	Leotardos escórpidos resistentes
8207	Hombreras escórpidos resistentes
8208	Yelmo escórpido resistente
8209	Botas escórpidas resistentes
8210	Hombreras de cuero salvaje
8211	Jubón de cuero salvaje
8212	Leotardos de cuero salvaje
8213	Botas de cuero salvaje
8214	Casco de cuero salvaje
8215	Capa de cuero salvaje
8216	Capa de gran vudú
8217	Carcaj rápido
8218	Faltriquera de munición de cuero grueso
8223	Hoja del basilisco
8224	Destripador de silítido
8225	Perforadora corrupta
8226	El carnicero
8243	Chuchería de Scooby
8244	Esfera draenetista impecable
8245	Túnica imperial roja
8246	Botas rojas imperiales
8247	Brazales rojos imperiales
8248	Capa roja imperial
8249	Guantes rojos imperiales
8250	Manto rojo imperial
8251	Pantalones rojos imperiales
8252	Toga imperial roja
8253	Fajín imperial rojo
8254	Aro rojo imperial
8255	Faja de piel de serpiente
8256	Botas de piel de serpiente
8257	Brazales de piel de serpiente
8258	Armadura de piel de serpiente
8259	Capa de piel de serpiente
8260	Guantes de piel de serpiente
8261	Yelmo de piel de serpiente
8262	Leotardos de piel de serpiente
8263	Bufas de piel de serpiente
8264	Muñequeras Fuerte ébano
8265	Armadura Fuerte ébano
8266	Capa Fuerte ébano
8267	Guanteletes Fuerte ébano
8268	Faja Fuerte ébano
8269	Botas Fuerte ébano
8270	Casco Fuerte ébano
8271	Leotardos Fuerte ébano
8272	Hombreras Fuerte ébano
8273	Muñequeras de valeroso
8274	Coraza de valeroso
8275	Rodela Fuerte ébano
8276	Guanteletes de valeroso
8277	Faja de valeroso
8278	Grebas valeroso
8279	Yelmo de valeroso
8280	Musleras de valeroso
8281	Espaldares de valeroso
8282	Escudo de valeroso
8283	Armadura Arcana
8284	Botas Arcanas
8285	Sortijas Arcanas
8286	Capa Arcana
8287	Guantes Arcanos
8288	Protectores Arcanos
8289	Leotardos Arcanos
8290	Toga Arcana
8291	Fajín Arcano
8292	Manta Arcana
8293	Cinturón de viajero
8294	Botas de viajero
8295	Brazales de viajero
8296	Chaleco de viajero
8297	Capa de viajero
8298	Guantes de viajero
8299	Yelmo de viajero
8300	Leotardos de viajero
8301	Bufas de viajero
8302	Brazales de héroe
8303	Peto de héroe
8304	Manteo de héroe
8305	Guanteletes de héroe
8306	Cinturón de héroe
8307	Botas de héroe
8308	Sortija de héroe
8309	Leotardos de héroe
8310	Espaldares de héroe
8311	Protegebrazos de placas de alabastro
8312	Peto de alabastro
8313	Rodela de héroe
8314	Guanteletes de placas de alabastro
8315	Faja de placas de alabastro
8316	Grebas de placas de alabastro
8317	Alabastro casco de placas
8318	Leotardos de placas de alabastro
8319	Espaldares de placas de alabastro
8320	Escudo de alabastro
8343	Hilo de seda pesada
8344	Espineretas de plata
8345	Yelmo cabeza de lobo
8346	Guanteletes del Mar
8347	Guanteletes de escamas de dragón
8348	Yelmo de Fuego
8349	Peto de plumas
8350	El anillo 1
8363	Talismán de vudú chamán
8364	Trucha de cabeza de mitril
8365	Trucha cabeza de mitril cruda
8366	Trucha hinchada
8367	Peto de escamas de dragón
8368	Pellejo de lobo grueso
8383	Carta lisa
8384	Patrón: sombrero de cuero cómodo
8385	Patrón: guantes de escamas de tortuga
8386	Patrón: toga de gran vudú
8387	Patrón: máscara de gran vudú
8388	Patrón: capa Nochefugaz
8389	Patrón: pantalones de gran vudú
8390	Patrón: capa de gran vudú
8391	Papada de hiena risitas
8392	Pulmón aplastado de jabalí
8393	Pinza de scorpok
8394	Cerebro de basilisco
8395	Patrón: peto escórpido resistente
8396	Molleja de buitre
8397	Patrón: brazales escórpidos resistentes
8398	Patrón: guantes escórpidos resistentes
8399	Patrón: botas escórpidas resistentes
8400	Patrón: hombreras escórpidos resistentes
8401	Patrón: leotardos escórpidos resistentes
8402	Patrón: yelmo escórpido resistente
8403	Patrón: hombreras de cuero salvaje
8404	Patrón: jubón de cuero salvaje
8405	Patrón: casco de cuero salvaje
8406	Patrón: botas de cuero salvaje
8407	Patrón: leotardos de cuero salvaje
8408	Patrón: capa de cuero salvaje
8409	Patrón: hombreras Nochefugaz
8410	R.O.I.D.S.
8411	Cóctel de zumo de pulmón
8412	Polvo de scorpok
8423	Compuesto de córtex cerebral
8424	Chicle de mollejas
8425	Restos de loro
8426	Pluma erizada grande
8427	Cadáver de rata mutilada
8428	Glándula cargada de rocío
8429	Glándula perforada
8430	Glándula de rocío vacía
8431	Bobina de hilo de seda chartreuse
8432	Agua de Mixilpixil
8443	Adorno de Gahz'rilo
8444	Llave de verdugo
8463	Pedido del Jefe de Guerra
8483	Faltriquera de agua de Deambulador
8484	Paquete de curación de la compañía de aguas de Gadgetzan
8485	Jaula para gatos (bombay)
8486	Jaula para gatos (rex cornualles)
8487	Jaula para gatos (atigrado naranja)
8488	Jaula para gatos (atigrado plateado)
8489	Jaula para gatos (gatito blanco)
8490	Jaula para gatos (siamés)
8491	Jaula para gatos (atigrado negro)
8492	Jaula de loro (guacamayo de ala verde)
8493	Barril de Weegli
8494	Jaula de loro (guacamayo jacinto)
8495	Jaula de loro (senegal)
8496	Jaula de loro (cockatiel)
8497	Cajón de conejos (pata de nieve)
8498	Dracochorro esmeralda diminuto
8499	Dracochorro carmesí diminuto
8500	Gran búho cornudo
8501	Lechuza gavilana
8502	Caja de lotería de bronce
8503	Caja de lotería de bronce pesada
8504	Caja de sorteo de hierro
8505	Caja de lotería de hierro pesado
8506	Caja de lotería de mitril
8507	Caja de lotería de mitril pesado
8508	Aleta grande
8523	Equipo de prueba de campo
8524	Fuente de poder modelo 4711-FTZ
8525	Orden de compra de Zinge
8526	Tragano violeta
8527	Equipo de prueba de campo sellado
8528	Partículas violeta
8529	Elixir de Tragonublo
8543	Hongos subacuáticos
8544	Venda de paño mágico
8545	Venda de paño mágico pesado
8546	Sales aromáticas potentes
8547	Fórmula: sales aromáticas potentes
8548	Vara Divinomática
8563	Mecazancudo rojo
8564	Huevo de hipogrifo
8583	Cuerno de la montura esquelética
8584	Pipeta de muestras abierta
8585	Pipeta de muestras cerrada
8586	Silbato del raptor rojo moteado
8587	Trozos de insecto centipaar
8588	Silbato del raptor esmeralda
8589	Silbato de marfil de raptor viejo
8590	Silbato de raptor obsidiano viejo
8591	Silbato del raptor turquesa
8592	Silbato del raptor violeta
8593	Equipo de análisis de Patagolpe
8594	Informe de análisis de insecto
8595	Mecazancudo azul
8603	Rocío cardizal
8623	Localizador de emergencia OOX-17/TN
8624	Bengala roja
8625	Bengala blanca
8626	Bengala azul
8627	Riendas del sable de la noche
8628	Riendas del sable de la noche moteado
8629	Riendas del sable de la noche a rayas
8630	Riendas del tigre bengala
8631	Riendas del sable de hielo a rayas
8632	Riendas del sable de hielo moteado
8633	Riendas del leopardo
8643	Huevo extraordinario
8644	Huevo bueno
8645	Huevo normal
8646	Huevo estropeado
8647	Cajón de huevos
8663	Insignia de mitril
8683	Manzana fresca de Clara
8684	Calimocho dulce de las Tierras del Interior
8685	Entrega de calimocho de Dran
8686	Colgante de mitril
8687	Descripción del visitante de Thredd lacrada
8703	Sello de Experiencia
8704	Localizador de emergencia OOX-09/HL
8705	Localizador de emergencia OOX-22/FE
8707	Escama electrificada de Gahz'rilla
8708	Martillo de Pericia
8723	Cabeza del Califa Escorpijón
8724	Secreto de Rin'ji
8743	Libro sobre Marca de los salvajes
8744	Libro sobre Cólera
8745	Libro sobre Toque curativo
8746	Capucha entrelazada
8747	Yelmo de cuero endurecido
8748	Almófar de malla doble
8749	Sombrero de ganchillo
8750	Sombrero de cuero grueso
8751	Almófar superpuesto
8752	Aro de escamas laminadas
8753	Casco de cuero liso
8754	Abrigo sarga
8755	Casco de placas ligeras
8756	Libro sobre Recrecimiento 2
8757	Libro sobre Estrella de mar
8758	Libro sobre Deshacer maldición
8759	Libro sobre Recrecimiento 3
8760	Libro sobre Suprimir Veneno
8761	Libro sobre Estrella de mar 2
8762	Libro sobre Rejuvenecimiento 6
8763	Libro sobre Fuegolunar 6
8764	Libro sobre Fuego Feérico 2
8765	Libro sobre Recrecimiento 4
8766	Rocío de gloria matinal
8768	Libro sobre Estrella de mar 3
8769	Libro sobre Espinas 4
8770	Libro sobre Fuegolunar 7
8771	Libro sobre Rejuvenecimiento 7
8772	Libro sobre Recrecimiento 6
8773	Libro sobre raíces enredaderas 5
8774	Libro sobre Toque curativo 7
8775	Libro sobre Tranquilidad 2
8776	Libro sobre Marca de los salvajes 6
8777	Libro sobre Fuegolunar 5
8778	Libro sobre Rejuvenecimiento 8
8779	Libro sobre Fuego Feérico 3
8780	Libro sobre Estrella de mar 5
8781	Libro sobre Recrecimiento 8
8782	Libro sobre Espinas 5
8783	Libro sobre Toque curativo 9
8784	Libro sobre Cólera 7
8785	Libro sobre Rejuvenecimiento 5
8786	Libro sobre Tranquilidad 3
8787	Libro sobre Calma de animales
8788	Libro sobre Calma de animales 2
8789	Libro sobre Calma de animales 3
8790	Libro sobre Fuego Feérico 4
8791	Libro sobre Recrecimiento 9
8792	Libro sobre Espinas 6
8793	Libro sobre Cólera 8
8794	Libro sobre Toque curativo 10
8795	Libro sobre raíces enredaderas 6
8796	Libro sobre Fuegolunar 10
8797	Libro sobre Rejuvenecimiento 10
8798	Libro sobre Estrella de mar 6
8799	Libro sobre Marca de los salvajes 7
8800	Libro sobre Recrecimiento 5
8801	Libro sobre Tranquilidad 4
8802	Escrito sobre Intelecto Arcano
8803	Escrito sobre Bola de Fuego
8804	Escrito sobre Deflagración Arcana
8805	Escrito sobre Detectar magia
8806	Escrito sobre Deshacer maldición inferior
8807	Escrito sobre Amplificar magia
8808	Escrito sobre Escudo de maná
8809	Escrito sobre Sueño
8810	Escrito sobre Sueño 2
8811	Escrito sobre Chamuscar
8812	Escrito sobre Deflagración Arcana 2
8813	Escrito sobre Empapar magia 2
8814	Escrito sobre Bola de Fuego 6
8815	Escrito sobre Cono de frío
8816	Escrito sobre Descarga de Escarcha 6
8818	Escrito sobre Escudo de maná 2
8819	Escrito sobre Chamuscar 2
8820	Escrito sobre Custodia de Fuego 2
8821	Escrito sobre Amplificar magia 2
8822	Escrito sobre Deflagración Arcana 3
8823	Escrito sobre Explosión de Fuego 4
8824	Escrito sobre Bola de Fuego 7
8825	Escrito sobre Custodia de Escarcha 3
8826	Escrito sobre Misiles Arcanos 4
8827	Elixir de caminar sobre las aguas
8828	Escrito sobre Descarga de Escarcha 7
8829	Escrito sobre Cono de frío 2
8830	Escrito sobre Chamuscar 3
8831	Loto morado
8832	Escrito sobre Ventisca III
8833	Escrito sobre Escudo de maná 3
8834	Escrito sobre Empapar magia 3
8835	Escrito sobre Bola de Fuego 8
8836	Lágrimas de Arthas
8837	Escrito sobre Deflagración Arcana 5
8838	Solea
8839	Carolina
8840	Escrito sobre Conjurar gema de maná 2
8841	Escrito sobre Explosión de Fuego 5
8842	Escrito sobre Descarga de Escarcha 8
8843	Escrito sobre Custodia de Fuego 3
8844	Escrito sobre Sueño 3
8845	Champiñón fantasma
8846	Gromsanguina
8847	Escrito sobre Chamuscar 5
8848	Escrito sobre Fogonazo 4
8849	Escrito sobre Misiles Arcanos 5
8850	Escrito sobre Conjurar agua 5
8851	Escrito sobre Bola de Fuego 9
8852	Escrito sobre Intelecto Arcano 4
8853	Escrito sobre Conjurar comida 5
8854	Escrito sobre Cono de frío 3
8855	Escrito sobre Amplificar magia 3
8856	Escrito sobre Descarga de Escarcha 9
8857	Escrito sobre Ventisca IV
8858	Escrito sobre Escudo de maná 4
8859	Escrito sobre Explosión de Fuego 6
8860	Escrito sobre Bola de Fuego 5
8861	Escrito sobre Conjurar gema de maná 3
8862	Escrito sobre Misiles Arcanos 6
8863	Escrito sobre Empapar magia 4
8864	Escrito sobre Fogonazo 5
8865	Escrito sobre Armadura de hielo 3
8866	Escrito sobre Cono de frío 4
8867	Escrito sobre Descarga de Escarcha 5
8868	Escrito sobre Conjurar agua 6
8869	Escrito sobre Custodia de Fuego 4
8870	Escrito sobre Invisibilidad superior
8871	Escrito sobre Conjurar comida 6
8872	Escrito sobre Ventisca V
8873	Escrito sobre Escudo de maná 5
8874	Escrito sobre Chamuscar 6
8875	Escrito sobre Custodia de Escarcha 4
8876	Escrito sobre Custodia de Escarcha 2
8877	Escrito sobre Bola de Fuego 10
8878	Escrito sobre Explosión de Fuego 7
8879	Escrito sobre Nova de Escarcha 4
8880	Escrito sobre Deflagración Arcana 6
8881	Escrito sobre Liberación de Khadgar 4
8882	Escrito sobre Amplificar magia 4
8883	Escrito sobre Intelecto Arcano 5
8884	Escrito sobre Descarga de Escarcha 10
8885	Escrito sobre Misiles Arcanos 7
8886	Escrito sobre Fogonazo 6
8887	Escrito sobre Chamuscar 7
8888	Escrito sobre Cono de frío 5
8889	Escrito sobre Conjurar gema de maná 4
8890	Escrito sobre Bola de Fuego 11
8891	Escrito sobre Armadura de hielo 4
8892	Escrito sobre Conjurar agua 7
8893	Escrito sobre Sueño 4
8894	Escrito sobre Empapar magia 5
8895	Escrito sobre Ventisca VI
8896	Escrito sobre Escudo de maná 6
8897	Escrito sobre Custodia de Fuego 5
8898	Escrito sobre Deflagración Arcana 4
8899	Escrito sobre Chamuscar 4
8900	Libro sobre raíces enredaderas 4
8901	Libro sobre Toque curativo 8
8902	Libro sobre Marca de los salvajes 5
8903	Libro sobre Fuegolunar 8
8904	Libro sobre Fuegolunar 9
8905	Libro sobre Recrecimiento 7
8906	Libro sobre Rejuvenecimiento 9
8907	Libro sobre Estrella de mar 4
8909	Tratado: Golpe Sagrado 2
8910	Tratado: Imposición de manos
8911	Tratado: Puño de justicia
8912	Tratado: Golpe de cruzado
8913	Tratado: Golpe Sagrado 3
8914	Tratado: Golpe de cruzado 2
8915	Tratado: Golpe Sagrado 4
8916	Tratado: Puño de justicia 2
8917	Tratado: Imposición de manos 2
8918	Tratado: Lacre de protección 3
8919	Tratado: Golpe Sagrado 5
8920	Tratado: Golpe de cruzado 3
8921	Tratado: Puño de justicia 3
8922	Tratado: Golpe Sagrado 6
8923	Esencia de agonía
8924	Polvo de Deterioro
8925	Vial de cristal
8926	Veneno instantáneo 4
8927	Veneno instantáneo 5
8928	Veneno instantáneo 6
8929	Tratado: Exorcismo 4
8930	Tratado: Lacre de rectitud 4
8931	Tratado: Golpe de cruzado 4
8932	Queso suizo de Alterac
8933	Tratado: Luz sagrada 8
8934	Tratado: Golpe Sagrado 7
8935	Tratado: Sentencia 2
8936	Tratado: Lacre de cólera 3
8937	Tratado: Imposición de manos 3
8938	Tratado: Ahuyentar a no-muertos 3
8939	Tratado: Exorcismo 5
8940	Tratado: Puño de justicia 4
8941	Tratado: Luz sagrada 9
8942	Tratado: Lacre de rectitud 5
8943	Tratado: Golpe Sagrado 8
8944	Tratado: Golpe de cruzado 5
8945	Tratado: Sentencia 3
8947	Tratado: Exorcismo 6
8948	Bolete de rey seco
8949	Elixir de agilidad
8950	Tarta de cerezas casera
8951	Elixir de defensa superior
8952	Codorniz asada
8953	Plátano frito
8954	Códice de Palabra Sagrada: entereza
8955	Códice de Desvanecer
8956	Aceite de inmolación
8957	Mero espinoso
8958	Códice de Explosión mental
8959	Mero espinoso crudo
8960	Códice de Curar enfermedad
8961	Códice de Alarido psíquico
8962	Códice de Explosión mental 2
8963	Códice de Calma mental
8964	Códice de Destello curativo
8965	Códice de Desvanecer 2
8966	Códice de Encadenar no-muerto
8967	Códice de Explosión mental 3
8968	Códice de Quemar maná
8969	Códice de Destello curativo 2
8971	Códice de Alarido psíquico 2
8972	Códice de Explosión mental 4
8973	Pellejo de yeti grueso
8974	Códice de Control mental
8975	Códice de Desvanecer 3
8976	Códice de Suprimir enfermedad
8977	Códice de Quemar maná 2
8978	Códice de Destello curativo 3
8980	Códice de Explosión mental 6
8981	Códice de Calma mental 2
8983	Códice de Destello curativo 4
8984	Veneno mortal 3
8985	Veneno mortal 4
8986	Códice de Encadenar no-muerto 2
8987	Códice de Protección Sagrada 2
8988	Códice de Quemar maná 3
8989	Códice de Desvanecer 4
8990	Códice de Explosión mental 7
8991	Códice de Fuego interno 4
8992	Códice de Alarido psíquico 3
8993	Códice de Protección de las Sombras 2
8994	Códice de Palabra de las Sombras: Dolor 6
8995	Códice de Palabra Sagrada: escudo 8
8996	Códice de Resurrección 3
8997	Códice de Control mental 2
8998	Códice de Visión mental 2
8999	Códice de Destello curativo 5
9000	Códice de Renovar 8
9001	Códice de Curación superior 2
9002	Códice de Explosión mental 8
9003	Códice de Acometida Sagrada 7
9004	Códice de Palabra Sagrada: entereza 5
9005	Códice de Quemar maná 4
9006	Códice de Palabra Sagrada: escudo 9
9007	Códice de Desvanecer 5
9008	Códice de Rezo de curación 3
9009	Códice de Fuego interno 5
9010	Códice de Destello curativo 6
9011	Códice de Palabra de las Sombras: Dolor 7
9012	Códice de Renovar 9
9013	Códice de Curación superior 3
9014	Códice de Calma mental 3
9015	Códice de Explosión mental 9
9016	Códice de Acometida Sagrada 8
9017	Códice de Protección Sagrada 3
9018	Códice de Palabra Sagrada: escudo 5
9019	Códice de Renovar 5
9020	Códice de Alarido psíquico 4
9021	Códice de Quemar maná 5
9022	Códice de Destello curativo 7
9023	Códice de Protección de las Sombras 3
9024	Códice de Control mental 3
9025	Códice de Curación superior 4
9026	Códice de Resurrección 4
9027	Códice de Explosión mental 5
9028	Códice de Palabra de las Sombras: Dolor 8
9029	Códice de Desvanecer 6
9030	Poción reconstituyente
9031	Códice de Encadenar no-muerto 3
9032	Códice de Rezo de curación 4
9033	Códice de Fuego interno 6
9034	Códice de Palabra Sagrada: entereza 6
9035	Códice de Palabra Sagrada: escudo 10
9036	Poción de resistencia a la magia
9037	Tablilla de arma de Muerdepiedras
9039	Tablilla de Choque de tierra
9040	Tablilla de Ola curativa 2
9041	Tablilla de Tótem Nexo Terrestre
9043	Tablilla de tótem Garrapetra
9044	Tablilla de Choque de tierra 2
9046	Tablilla de tótem Fuerza terrenal
9047	Tablilla de Choque de llamas
9048	Tablilla de Renacimiento
9049	Tablilla de tótem Nova de Fuego
9050	Tablilla de Ola curativa 3
9051	Tablilla de Choque de tierra 3
9052	Tablilla de tótem Piel de piedra 2
9053	Tablilla de arma de Muerdepiedras 2
9054	Tablilla de Choque de llamas 2
9055	Tablilla de tótem Garrapetra 2
9056	Tablilla de Ola curativa 4
9057	Tablilla de arma Estigma de Escarcha
9058	Tablilla de Choque de Escarcha
9059	Tablilla de arma lengua de Fuego
9060	Cilindro de mitril taraceado
9061	Combustible de cohete goblin
9062	Tablilla de Curar enfermedad
9063	Tablilla de tótem antídoto
9064	Tablilla de arma lengua de Fuego 2
9065	Tablilla de tótem Nova de Fuego 2
9066	Tablilla de tótem de resistencia a la Escarcha
9067	Tablilla de tótem Fuerza terrenal 2
9068	Tablilla de tótem Piel de piedra 3
9069	Tablilla de Choque de tierra 4
9070	Tablilla de Ola curativa 6
9071	Tablilla de tótem fuente de maná
9072	Tablilla de tótem lengua de Fuego
9073	Tablilla de arma Viento Furioso
9074	Tablilla de Choque de llamas 3
9075	Tablilla de tótem de resistencia al Fuego
9076	Tablilla de tótem de magma
9077	Tablilla de tótem Garrapetra 3
9078	Tablilla de tótem derribador
9079	Tablilla de Choque de relámpagos
9080	Tablilla de tótem de Resistencia a Naturaleza
9081	Tablilla de tótem de corriente purificadora 2
9082	Tablilla de arma de Muerdepiedras 3
9083	Tablilla de tótem abrasador 3
9084	Tablilla de tótem Viento Furioso
9085	Tablilla de tótem Nova de Fuego 3
9086	Tablilla de Ola curativa 7
9087	Tablilla de Purgar 2
9088	Ofrenda de Arthas
9089	Tablilla de Choque de Escarcha 2
9090	Tablilla de arma Estigma de Escarcha 2
9091	Tablilla de tótem Piel de piedra 4
9092	Tablilla de tótem avizor
9093	Tablilla de tótem fuente de maná 2
9094	Tablilla de arma lengua de Fuego 3
9095	Tablilla de Choque de tierra 5
9096	Tablilla de tótem purgador de enfermedades
9097	Tablilla de tótem de magma 2
9098	Tablilla de tótem Fuerza terrenal 3
9099	Tablilla de tótem Garrapetra 4
9100	Tablilla de Escudo de relámpagos 5
9101	Tablilla de arma Viento Furioso 2
9102	Tablilla de Cadena de relámpagos 2
9103	Tablilla de tótem de corriente purificadora 3
9104	Tablilla de tótem abrasador 4
9105	Tablilla de Ola curativa 8
9123	Tablilla de Descarga de relámpagos 6
9124	Tablilla de Choque de relámpagos 2
9125	Tablilla de tótem gracia del aire
9126	Tablilla de tótem lengua de Fuego 2
9127	Tablilla de tótem de resistencia al Fuego 2
9128	Tablilla de tótem Nova de Fuego 4
9129	Tablilla de arma de Muerdepiedras 4
9130	Tablilla de tótem de Resistencia a Naturaleza 2
9131	Tablilla de tótem Piel de piedra 5
9132	Tablilla de Explosión de arrabio 6
9133	Tablilla de Curación en cadena 2
9134	Tablilla de tótem Viento Furioso 2
9135	Tablilla de Choque de Escarcha 3
9136	Tablilla de tótem fuente de maná 3
9137	Tablilla de Escudo de relámpagos 6
9138	Tablilla de tótem de magma 3
9139	Tablilla de arma Estigma de Escarcha 3
9140	Tablilla de Cadena de relámpagos 3
9141	Tablilla de tótem Garrapetra 5
9142	Tablilla de Choque de tierra 6
9143	Tablilla de Ola curativa 9
9144	Poción de atriplex salvaje
9145	Tablilla de Descarga de relámpagos 7
9146	Tablilla de tótem abrasador 5
9147	Tablilla de tótem de corriente purificadora 4
9148	Tablilla de arma lengua de Fuego 4
9149	Piedra de filósofo
9150	Tablilla de tótem Fuerza terrenal 4
9151	Tablilla de Choque de llamas 5
9152	Tablilla de tótem Nova de Fuego 5
9153	Planos de torre
9154	Elixir de detección de no-muertos
9155	Elixir Arcano
9156	Tablilla de Explosión de arrabio 7
9157	Tablilla de Curación en cadena 3
9158	Tablilla de tótem de resistencia a la Escarcha 3
9159	Tablilla de Choque de relámpagos 3
9160	Tablilla de arma Viento Furioso 3
9161	Tablilla de tótem Piel de piedra 6
9162	Tablilla de Escudo de relámpagos 7
9164	Tablilla de tótem gracia del aire 2
9165	Tablilla de tótem lengua de Fuego 3
9166	Tablilla de tótem fuente de maná 4
9167	Tablilla de Cadena de relámpagos 4
9168	Tablilla de Ola curativa 5
9169	Tablilla de Descarga de relámpagos 8
9170	Tablilla de tótem de resistencia al Fuego 3
9171	Tablilla de tótem de magma 4
9172	Poción de invisibilidad
9173	Transpondedor goblin
9174	Tablilla de Choque de Escarcha 4
9175	Tablilla de arma de Muerdepiedras 5
9176	Tablilla de tótem Garrapetra 6
9177	Tablilla de Choque de tierra 7
9178	Tablilla de tótem de Resistencia a Naturaleza 3
9179	Elixir de intelecto superior
9180	Tablilla de tótem Viento Furioso 3
9181	Tablilla de tótem de corriente purificadora 5
9182	Tablilla de tótem abrasador 6
9183	Tablilla de Curación en cadena
9184	Tablilla de Choque de llamas 4
9185	Tablilla de tótem de resistencia a la Escarcha 2
9186	Veneno de aturdimiento mental III
9187	Elixir de agilidad superior
9188	Tablilla de tótem abrasador 2
9189	Campana de Shay
9190	Grimorio de Inmolar
9191	Grimorio de Maldición de Debilidad
9192	Grimorio de Corrupción
9193	Grimorio de Llave de vida
9194	Grimorio de Maldición de Agonía
9195	Grimorio de Drenar maná
9197	Elixir de visión de ensueño
9198	Grimorio de Embudo de salud
9199	Grimorio de Maldición de Temeridad
9200	Grimorio de Maldición de Debilidad II
9201	Grimorio de Corrupción II
9202	Grimorio de Llave de vida II
9203	Grimorio de Ritual de invocación
9204	Grimorio de Embudo de salud II
9205	Grimorio de Maldición de Agonía II
9206	Elixir de gigantes
9207	Grimorio de Crear Petrosangre II
9208	Grimorio de Drenar maná II
9209	Grimorio de Maldición de Debilidad III
9210	Tinte de fantasma
9211	Grimorio de Maldición de Temeridad II
9212	Grimorio de descarga de las Sombras V
9214	Grimorio de Inferno
9215	Grimorio de Embudo de salud III
9216	Grimorio de Corrupción III
9217	Grimorio de Llave de vida III
9218	Grimorio de Esclavizar demonio
9219	Grimorio de Piroinferno
9221	Grimorio de Maldición de Agonía III
9222	Grimorio de Maldición de los Elementos
9223	Grimorio de Maldición de Debilidad IV
9224	Elixir de matanza de demonios
9225	Grimorio de descarga de las Sombras VI
9226	Grimorio de Embudo de salud IV
9227	Grimorio de Drenar maná III
9228	Grimorio de Crear Petrosangre III
9229	Grimorio de Drenaje de vida IV
9230	Grimorio de Maldición de Temeridad III
9231	Grimorio de Corrupción IV
9233	Elixir de detección demoníaca
9234	Tiara de las profundidades
9235	Carta de Pratt
9236	Carta de Jangdor
9237	Crin de gnoll Zarpaleña
9238	Caparazón de escarabajo sin rajar
9240	Marra de Zul'Farrak
9241	Marra sacra
9242	Tablilla antigua
9243	Corazón marchito
9244	Envío de Stoley
9245	Botella de Stoley
9246	Cabeza de Barbafuego
9247	Escama naga Crestafuria
9248	Reliquia misteriosa
9249	Llave de capitán
9250	Planificación de envíos
9251	Fragmento superior del mapa
9252	Fragmento inferior de mapa
9253	Fragmento de mapa del medio
9254	Mapa del tesoro de Cuergo
9255	Esencia Lahassa
9256	Esencia Imbel
9257	Esencia samha
9258	Esencia Byltan
9259	Collar tribal trol
9260	Ron volátil
9261	Plomo
9262	Vitriolo negro
9263	Bastón de Troya
9264	Elixir de poder de las Sombras
9265	Tesoro escondido de Cuergo
9266	Planes de batalla de Zarpaleña
9275	Llave de Cuergo
9276	Baúl de pirata
9277	Memoria de Tecnobot
9278	Esencia artificial
9279	Tarjeta perforada blanca
9280	Tarjeta perforada amarilla
9281	Tarjeta perforada roja
9282	Tarjeta perforada azul
9283	Ampolla de plomo vacía
9284	Ampolla de plomo llena
9285	Protegebrazos de placas de campo
9286	Armaduras de placas de campo
9287	Guanteletes de placas de campo
9288	Faja de placas de campo
9289	Botas de placas de campo
9290	Casco de placas de campo
9291	Leotardos de placas de campo
9292	Espaldares de placas de campo
9293	Receta: poción de resistencia a la magia
9294	Receta: poción de atriplex salvaje
9295	Receta: poción de invisibilidad
9296	Receta: obsequio de Arthas
9297	Receta: elixir de visión de ensueño
9298	Receta: elixir de gigantes
9299	Combinación de la caja fuerte de Termochufe
9300	Receta: elixir de matanza de demonios
9301	Receta: elixir de poder de las Sombras
9302	Receta: tinte fantasmal
9303	Receta: piedra de filósofo
9304	Receta: transmutar hierro a oro
9305	Receta: transmutar mitril a veraplata
9306	Bastón de Equinex
9307	Una piedra centelleante
9308	Objeto con mugre incrustada
9309	Entrañas robomecánicas
9311	Papel y sobres para cartas estándar
9312	Fuego artificial azul
9313	Fuego artificial verde
9314	Fuego artificial de rayos rojos
9315	Fuego artificial amarillo y rosa
9316	Tarjeta perforada prismática
9317	Fuego artificial azul, blanco y rojo
9318	Fuego artificial rojo
9319	Pico cargado de Nimboya
9320	Cráneo Secacorteza
9321	Botella de veneno
9322	Glándula de veneno no dañada
9323	Pliego de Gadrin
9324	Veneno de Shadra
9325	Un pequeño bastón
9326	Anillo con mugre incrustada
9327	Tarjeta de acceso de nivel de seguridad DELTA
9328	Superinstántanea FX
9329	Una corta nota
9330	Instantánea de Gammerita
9331	Feralas: una historia
9332	Vendas con costra
9333	Collar de plata deslustrada
9334	Cerámica rajada
9335	Garrote obsidiano roto
9336	Colmillo con funda de oro trol
9355	Pendiente de aro
9356	Una pierna de madera
9357	Un esqueleto de loro
9358	Un trapo para la cabeza
9359	Farol del Mar del Sur
9360	Oro de Cuergo
9361	Oro de Cuergo con gusano
9362	Anillo de oro luminoso
9363	Caja envuelta de la Destellamatic
9364	Ampolla de plomo pesada
9365	Restos radiactivos de gran potencia
9366	Guanteletes de escamas de oro
9367	Diseño: guanteletes de escamas de oro
9368	Sello de Jer'kai
9369	Ala de duende dardo iridiscente
9370	Pergamino Gordunni
9371	Orbe Gordunni
9372	Sul'thraze el Azotador
9375	Casco para expertos buscadores de oro
9378	Hacha de minero de Shovelphlange
9379	Sang'thraze el Deflector
9380	Jang'thraze el Protector
9381	Vara terránea
9382	Botas de minero pisoteador
9383	Cuchilla obsidiano
9384	Shiv Rutacanto
9385	Defensor arcaico
9386	Prenda de excavador
9387	Botas Revelosh
9388	Guardabrazos Revelosh
9389	Bufas Revelosh
9390	Guantes Revelosh
9391	El pato
9392	Hoja templada
9393	Antorcha de Esperanza
9394	Casco vikingo con cuernos
9395	Guantes de los antiguos
9396	Musleras de la Cripta
9397	Capa de energía
9398	Botas de carrera desgastadas
9399	Flecha de precisión
9400	Arco corto de Baelog
9401	Sable nórdico
9402	Falda escocesa Portaterra
9403	Escudo vikingo maltrecho
9404	Escudo polivalente de Olaf
9405	Faja de Fuerza gólem
9406	Grillete Viento de la cumbre
9407	Leotardos tejepiedra
9408	Cachiporra de hierro
9409	Brazales de Hierraya
9410	Puños de risco
9411	Espaldares de fragmento de roca
9412	Lanzafuego de Galgann
9413	El machacador de rocas
9414	Leotardos de piel engrasada
9415	Vestimentas tribales de Grimlok
9416	Carga de Grimlok
9417	Fragmento arcádico
9418	Destripapiedras
9419	Martillo de Fuego de Galgann
9420	Casco de médula de filibustero
9421	Piedra de salud sublime
9422	Maestro de rodeos de Sombratiniebla
9423	El martillo neumático
9424	Espada de ginn-su
9425	Péndulo de Condena
9426	Arco monolítico
9427	Rompehuesos Rutacanto
9428	Sortijas sin tierra
9429	Casco de minero de las profundidades
9430	Bufas de una época remota
9431	Fez papal
9432	Brazales Placacráneos
9433	Brazaletes olvidados
9434	Vestimenta elemental
9435	Guanteletes de hueso reticulado
9436	Talega de Faranell
9437	Muestra de basilisco sin estudiar
9438	Muestra de escórpido aceptable
9439	Muestra de hiena sin estudiar
9440	Muestra de basilisco aceptable
9441	Muestra de hiena aceptable
9442	Muestar de escórpido sin estudiar
9443	Muestra de monstruo utilizada
9444	Microprocesador de Tecnobot
9445	Garras Grubbis
9446	Pata de Electrocutor
9447	Perno de Electrocutor
9448	Trapo grasiento de tanque araña
9449	Manual de Muchedumbre de Puñetazos
9450	Botas de gnomobot
9451	Agua burbujeante
9452	Hidrocaña
9453	Vengador tóxico
9454	Botos ácidos
9455	Puños de emisario
9456	Pistola de cristal
9457	Cetro diplomático real
9458	Núcleo central de Termochufe
9459	Brazo izquierdo de Termochufe
9460	Cuerno de Tótem Siniestro
9461	Material cargado
9462	Cajón de cuernos Tótem Siniestro
9463	Cobalto Gordunni
9465	Maestro excavador 5000
9466	Pala de Orwin
9467	Colmillo de Gahz'rilla
9468	Pluma de Picoafilado
9469	Armadura de escamas de Gahz'rilla
9470	Máscara de mojo malo
9471	Medallón de Nekrum
9472	Llave de Hexx
9473	Piel gafada
9474	Falda escocesa gafada
9475	Picador diabólico
9476	Espaldares malos grandes
9477	El gorila del jefe
9478	Sierra
9479	Abrazo del lycan
9480	Arranca ojos
9481	El minotauro
9482	Vara de médico brujo
9483	Incinerador
9484	Leotardos de choque de hechizo
9485	Vibroespada
9486	Hacha de batalla de carga superior
9487	Superpistola de alta tecnología
9488	Martillo de poder oscilador
9489	Hielera giromática
9490	Megacortadora Gizmotrón
9491	Guantes de piloto célebre
9492	Reactivador de jigaflujo electromagnético
9507	Un cajón bien ordenado
9508	Mono de mecánico
9509	Leotardos de petróleo
9510	Chapines Cueva Honda
9511	Escalpelo Estampa de Sangre
9512	Manteo de metal negro
9513	Bastón Ley
9514	Bastón Arcano
9515	Túnica abisal
9516	Blusa de nudos astral
9517	Bastón celestial
9518	Trituradores de barro
9519	Vapuleadores Piesucios
9520	Cazador silencioso
9521	Machacacráneos
9522	Círculo de Piedras cargado
9523	Temple trol
9527	Vara de tramoyista de hechizos
9528	Corazón oscuro de Edana
9529	Juego de equipo de guerrero interno N25
9530	Cuerno de Espolón de odio
9531	Espaldares de pizarra
9532	Juego de equipo de guerrero interno N30
9533	Anillo de fraternidad masona
9534	Celada de hermandad de ingeniero
9535	Brazales soldados con fuego
9536	Manto alas de hada
9537	Caja bien envuelta
9538	Anillo de oro de Talvash
9539	Caja de raciones
9540	Caja de hechizos
9541	Caja de regalitos
9542	Carta simple
9543	Runa simple
9544	Memorándum simple
9545	Sigilo simple
9546	Pergamino simple
9547	Nota simple
9548	Carta sagrada
9550	Runa codificada
9551	Sigilo codificado
9552	Nota con runas inscritas
9553	Pergamino grabado
9554	Tablilla codificada
9555	Carta codificada
9556	Runa sagrada
9557	Sigilo Sagrado
9558	Memorándum codificado
9559	Pergamino codificado
9560	Pliego codificado
9561	Tablilla sagrada
9562	Tablilla con runas grabadas
9563	Runa consagrada
9564	Tablilla grabada
9565	Nota grabada
9566	Runa grabada
9567	Sigilo grabado
9568	Pliego con runas grabadas
9569	Pergamino Sagrado
9570	Carta consagrada
9571	Carta glífica
9572	<UNUSED> Glyphic Rune
9573	Memorándum glífico
9574	Pergamino glífico
9575	Tablilla glífica
9576	Carta manchada
9577	Memorándum corrupto
9578	Pergamino corrupto
9579	Pliego corrupto
9580	Sigilo Verdantis
9581	Nota de Verdantis
9587	Saco de pelambre descongelada
9588	Anillo de oro de Nogg
9589	Minerales taraceados
9590	Tronco astillado
9591	Tendón resistente
9592	Fragmentos metálicos
9593	Miniatura treant
9594	Lechúcico muisek
9595	Muisek hipogrifo
9596	Dragón feérico muisek
9597	Muisek gigante de montaña
9598	Togas para dormir
9599	Leotardos de malla de corteza
9600	Pantalones con encaje
9601	Botas amortiguadas
9602	Hoja Leñomaleza
9603	Bastón de raíz de arena
9604	Martillo de mecánico
9605	Manteo de mecánico
9606	Recipiente de miniatura treant
9607	Bastión de Ventormenta
9608	Herramienta de desarme de Shoni
9609	Mitones llamativos
9618	Vasija de lechúcico muisek
9619	Vasija de muisek hipogrifo
9620	Vasija de dragón feérico muisek
9621	Vasija de muisek gigante de montaña
9622	Anillo Nudo de Junco
9623	Togas civinad
9624	Peto de corredor
9625	Leotardos duales reforzados
9626	Carga de enano
9627	Norte y guía de la Liga de Expedicionarios
9628	Faltriquera de hierbas de Neeru
9629	Una cabeza encogida
9630	Botas hechas a mano de Pratt
9631	Guantes hechos a mano de Pratt
9632	Guantes hechos a mano de Jangdor
9633	Botas hechas a mano de Jangdor
9634	Guantes aptos para la carga
9635	Manteo de maestro boticario
9636	Fajín de aventurero
9637	Botas lustrosas
9638	Puños chelonianos
9639	La mano de Antu'sul
9640	Mandiletes de maña
9641	Amuleto de sangre de vida
9642	Sortija de la Gran Tortuga
9643	Deflector optomático
9644	Temporizador de huevos termostático
9645	Botas de inventor gnómico
9646	Instrumento de hundimiento gnómico
9647	Experimento volador fallido
9648	Felpa eslabón
9649	Vestimentas de alto rango real
9650	Coraza protectora de honor
9651	Martillo Tormenta de Jinete de grifos
9652	Leotardos de Jinete de grifos
9653	Gafas de corredor acelerado
9654	Fragmento de piedra de hito
9655	Aro de semillas
9656	Mandiletes de granito
9657	Cincho seto
9658	Botas del Maharishi
9660	Capa de admirador de estrellas
9661	Barrera natural
9662	Botas Crestarrápida
9663	Coraza de Jinete del Alba
9664	Integumento de centinela
9665	Guantes Crestala
9666	Faja de Stronghorn
9678	Azotador múrloc de Tok'kar
9679	Trituradora múrloc de Tok'kar
9680	Faca múrloc de Tok'kar
9681	Patas de rey reptador a la parrilla
9682	Cinturón de cuero de jefe
9683	Fuerza del antárbol
9684	Potencia del hipogrifo
9685	Voluntad del Gigante de montaña
9686	Espíritu del dragón feérico
9687	Cinturón de forcejeador
9698	Guantes de Perspicacia
9699	Capa de cuartel
9703	Manteo abrasado
9704	Guantes de ladronzuelo
9705	Cordones de Tharg
9706	Disco de Tharg
9718	Hoja de Héroes reforjada
9719	Hoja de Héroes rota
9738	Gema de Cobrah
9739	Gema de Anacondra
9740	Gema de Pythas
9741	Gema de Serpentis
9742	Cordón simple
9743	Zapatos simples
9744	Sortijas simples
9745	Manteo simple
9746	Guantes simples
9747	Calzones simples
9748	Toga simple
9749	Blusa simple
9750	Fajín de cíngaro
9751	Sandalias de cíngaro
9752	Sortijas de cíngaro
9753	Rodela de cíngaro
9754	Capa de cíngaro
9755	Guantes de cíngaro
9756	Pantalones de cíngaro
9757	Túnica de cíngaro
9758	Cinturón de cadete
9759	Botas de cadete
9760	Brazales de cadete
9761	Capa de cadete
9762	Guanteletes de cadete
9763	Leotardos de cadete
9764	Escudo de cadete
9765	Jubón de cadete
9766	Fajín de tejido verde
9767	Sandalias de tejido verde
9768	Brazales de tejido verde
9769	Rama de tejido verde
9770	Capa de tejido verde
9771	Guantes de tejido verde
9772	Leotardos de tejido verde
9773	Toga de tejido verde
9774	Jubón de tejido verde
9775	Cincho de bandido
9776	Botas de bandido
9777	Brazales de bandido
9778	Rodela de bandido
9779	Capa de bandido
9780	Guantes de bandido
9781	Pantalones de bandido
9782	Chaleco de bandido
9783	Coraza de asaltante
9784	Botas de asaltante
9785	Brazales de asaltante
9786	Capa de asaltante
9787	Guanteletes de asaltante
9788	Cinturón de asaltante
9789	Musleras de asaltante
9790	Escudo de asaltante
9791	Túnica de paño de hiedra
9792	Botas de paño de hiedra
9793	Pulseras de paño de hiedra
9794	Capa de paño de hiedra
9795	Guantes de paño de hiedra
9796	Manto de paño de hiedra
9797	Pantalones de paño de hiedra
9798	Toga de paño de hiedra
9799	Fajín de paño de hiedra
9800	Orbe de hiedra
9801	Cinturón excelente
9802	Botas excelente
9803	Brazales excelente
9804	Rodela excelente
9805	Capa excelente
9806	Guantes excelentes
9807	Hombreras excelentes
9808	Leotardos excelentes
9809	Túnica excelente
9810	Botas reforzadas
9811	Brazales reforzados
9812	Capa reforzada
9813	Guanteletes reforzados
9814	Cinturón reforzado
9815	Leotardos reforzados
9816	Escudo reforzado
9817	Bufas reforzadas
9818	Cadena reforzada
9819	Túnica durable
9820	Botas durables
9821	Brazales durables
9822	Manteo durable
9823	Guantes durables
9824	Hombreras durable
9825	Pantalones durables
9826	Toga durable
9827	Cinturón de cuero escamado
9828	Botas de cuero escamado
9829	Brazales de cuero escamado
9830	Escudo escamado
9831	Capa escamada
9832	Guantes de cuero escamado
9833	Leotardos de cuero escamado
9834	Hombreras de cuero escamado
9835	Túnica de cuero escamado
9836	Armadura a rayas
9837	Brazales a rayas
9838	Capa a rayas
9839	Guanteletes a rayas
9840	Faja a rayas
9841	Leotardos a rayas
9842	Espaldares a rayas
9843	Escudo a rayas
9844	Jubón de implorador
9845	Zapatos de implorador
9846	Brazales de implorador
9847	Capa de implorador
9848	Guantes de implorador
9849	Caperuza de implorador
9850	Manto de implorador
9851	Calzones de implorador
9852	Toga de implorador
9853	Cincho de implorador
9854	Chaleco de arquero
9855	Cinturón de arquero
9856	Botas de arquero
9857	Brazales de arquero
9858	Rodela de arquero
9859	Almete de arquero
9860	Capa de arquero
9861	Guantes de arquero
9862	Pantalones de arquero
9863	Hombreras de arquero
9864	Botas de renegado
9865	Brazales de renegado
9866	Coraza de renegado
9867	Capa de renegado
9868	Guanteletes de renegado
9869	Cinturón de renegado
9870	Aro de renegado
9871	Leotardos de renegado
9872	Espaldares de renegado
9873	Escudo de renegado
9874	Mantón hechicero
9875	Fajín hechicero
9876	Zapatillas hechicero
9877	Capa hechicero
9878	Sombrero hechicero
9879	Pulseras hechicero
9880	Guantes hechicero
9881	Manto hechicero
9882	Esfera hechicero
9883	Pantalones hechicero
9884	Toga hechicero
9885	Botas de cazador
9886	Sortijas de cazador
9887	Armadura de cazador
9889	Cofia de cazador
9890	Manteo de cazador
9891	Cinturón de cazador
9892	Guantes de cazador
9893	Leotardos de cazador
9894	Hombreras de cazador
9895	Botas de brigandina
9896	Brazales de brigandina
9897	Coraza de brigandina
9898	Capa de brigandina
9899	Escudo de brigandina
9900	Guanteletes de brigandina
9901	Cinturón de brigandina
9902	Yelmo de brigandina
9903	Leotardos de brigandina
9904	Espaldares de brigandina
9905	Blusa real
9906	Fajín real
9907	Botas reales
9908	Manteo real
9909	Sortijas reales
9910	Guantes reales
9911	Pantalones reales
9912	Hombrera real
9913	Toga real
9914	Cetro real
9915	Cinta real
9916	Cinturón de rastreador
9917	Botas de rastreador
9918	Defensor brigada
9919	Capa de rastreador
9920	Guantes de rastreador
9921	Cinta de rastreador
9922	Leotardos de rastreador
9923	Hombreras de rastreador
9924	Túnica de rastreador
9925	Muñequeras de rastreador
9926	Botas brigada
9927	Brazales brigada
9928	Peto brigada
9929	Capa brigada
9930	Guanteletes brigada
9931	Faja brigada
9932	Aro brigada
9933	Leotardos brigada
9934	Espaldares brigada
9935	Escudo de placas en relieve
9936	Botas de lego
9937	Sortijas de lego
9938	Capa de lego
9939	Guantes de lego
9940	Caperuza de lego
9941	Manto de lego
9942	Pantalones de lego
9943	Toga de lego
9944	Cristal de lego
9945	Fajín de lego
9946	Túnica de lego
9947	Cinturón de jefe
9948	Botas de jefe
9949	Brazales de jefe
9950	Peto de jefe
9951	Capa de jefe
9952	Guantes de jefe
9953	Penacho de jefe
9954	Leotardos de jefe
9955	Hombreras de jefe
9956	Brazales de belicista
9957	Coraza de belicista
9958	Rodela de belicista
9959	Capa de belicista
9960	Guanteletes de belicista
9961	Cinturón de belicista
9962	Grebas de belicista
9963	Aro de belicista
9964	Leotardos de belicista
9965	Espaldares de belicista
9966	Armadura de placas en relieve
9967	Guanteletes de placas en relieve
9968	Faja de placas en relieve
9969	Casco de placas en relieve
9970	Leotardos de placas en relieve
9971	Espaldares de placas en relieve
9972	Brazales de placas en relieve
9973	Botas de placas en relieve
9974	Escudo de Señor Supremo
9978	Detector de Gahz'rilo
9998	Jubón de paño mágico negro
9999	Leotardos de paño mágico negro
10000	Cuerno de Margol
10001	Toga de paño mágico negro
10002	Pantalones de tejido de sombras
10003	Guantes de paño mágico negro
10004	Toga de tejido de sombras
10005	Cuerno gigante de Margol
10007	Jubón de paño mágico rojo
10008	Máscara de bandido blanca
10009	Pantalones de paño mágico rojo
10010	Pantalones de paño tormentoso
10011	Guantes de paño tormentoso
10018	Guantes de paño mágico rojo
10019	Guantes Vigilasueños
10020	Jubón de paño tormentoso
10021	Jubón Vigilasueños
10022	Certificado de autenticidad
10023	Guantes tejido de sombras
10024	Cinta negra paño mágico
10025	Máscara de tejido de sombras
10026	Botas de paño mágico negro
10027	Hombreras de paño mágico negro
10028	Hombreras de tejido de sombras
10029	Hombreras de paño mágico rojo
10030	Sombrero de almirante
10031	Botas tejido de sombras
10032	Cinta de paño tormentoso
10033	Cinta de paño mágico rojo
10034	Camisa de esmoquin
10035	Pantalones de esmoquin
10036	Chaqueta de esmoquin
10038	Hombreras de paño tormentoso
10039	Botas de paño tormentoso
10040	Vestido de boda blanco
10041	Aro Vigilasueños
10042	Toga de paño ceniza
10043	Leotardos piadosos
10044	Botas de paño ceniza
10045	Pantalones de lino simples
10046	Botas de lino simples
10047	Falda escocesa simple
10048	Falda escocesa de colores
10049	Hoja de diabolista
10050	Bolsa de paño mágico
10051	Bolsa de paño mágico roja
10052	Camisa marcial naranja
10053	Vestido negro simple
10054	Camisa de paño mágico lavanda
10055	Camisa de paño mágico rosa
10056	Camisa de paño mágico naranja
10057	Túnica Tejealba
10058	Sandalias Tejealba
10059	Brazales Tejealba
10060	Manteo Tejealba
10061	Turbante Tejealba
10062	Guantes Tejealba
10063	Hombrera Tejealba
10064	Pantalones Tejealba
10065	Toga Tejealba
10066	Fajín Tejealba
10067	Guardarrenes de rectitud
10068	Botas de rectitud
10069	Brazales de rectitud
10070	Armadura de rectitud
10071	Capa de rectitud
10072	Guantes de rectitud
10073	Casco de rectitud
10074	Leotardos de rectitud
10075	Bufas de rectitud
10076	Guardabrazos de Lord
10077	Peto de Lord
10078	Emblema de Lord
10079	Manteo de Lord
10080	Guanteletes de Lord
10081	Faja de Lord
10082	Botas de Lord
10083	Corona de Lord
10084	Musleras de Lord
10085	Espaldares de Lord
10086	Armadura de placas góticas
10087	Guanteletes de placas góticas
10088	Faja de placas góticas
10089	Escarpes góticos
10090	Casco de placas góticas
10091	Leotardos de placas góticas
10092	Bufas de placas góticas
10093	Deflector de aparecido
10094	Protegebrazos de placas góticas
10095	Botas de concejal
10096	Puños de concejal
10097	Aro de concejal
10098	Capa de concejal
10099	Guantes de concejal
10100	Hombreras de concejal
10101	Pantalones de concejal
10102	Togas de concejal
10103	Fajín de concejal
10104	Túnica de concejal
10105	Armadura de errante
10106	Botas de errante
10107	Brazales de errante
10108	Capa de errante
10109	Cinturón de errante
10110	Guantes de errante
10111	Sombrero de errante
10112	Leotardos de errante
10113	Hombreras de errante
10118	Peto ornamentado
10119	Grebas ornamentadas
10120	Capa ornamentada
10121	Guanteletes ornamentados
10122	Faja ornamentada
10123	Aro ornamentado
10124	Musleras ornamentadas
10125	Espaldares ornamentados
10126	Brazales ornamentados
10127	Brazales de aparecido
10128	Peto de aparecido
10129	Guanteletes de aparecido
10130	Faja de aparecido
10131	Botas de aparecido
10132	Casco de aparecido
10133	Leotardos de aparecido
10134	Hombreras de aparecido
10135	Túnica de consejero mayor
10136	Brazales de consejero mayor
10137	Botas de consejero mayor
10138	Capa de consejero mayor
10139	Aro de consejero mayor
10140	Guantes de consejero mayor
10141	Pantalones de consejero mayor
10142	Manto de consejero mayor
10143	Toga de consejero mayor
10144	Fajín de consejero mayor
10145	Faja poderosa
10146	Botas poderosas
10147	Braquiales poderosos
10148	Capa poderosa
10149	Guanteletes poderosos
10150	Casco poderoso
10151	Túnica poderosa
10152	Leotardos poderosos
10153	Bufas poderosas
10154	Faja voluble
10155	Grebas volubles
10156	Brazales volubles
10157	Peto voluble
10158	Integumento voluble
10159	Capa voluble
10160	Aro voluble
10161	Guanteletes volubles
10162	Musleras volubles
10163	Espaldares volubles
10164	Peto de templario
10165	Guanteletes de templario
10166	Faja de templario
10167	Botas de templario
10168	Corona de templario
10169	Quijotes de templario
10170	Espaldares de templario
10171	Brazales de templario
10172	Manto místico
10173	Brazales místicos
10174	Manteo místico
10175	Turbante místico
10176	Guantes místicos
10177	Leotardos místicos
10178	Toga mística
10179	Botas místicas
10180	Cinturón místico
10181	Armadura mística
10182	Peto de aventurero
10183	Botas de aventurero
10184	Brazales de aventurero
10185	Manteo de aventurero
10186	Guantes de aventurero
10187	Parche de aventurero
10188	Leotardos de aventurero
10189	Hombreras de aventurero
10190	Cinturón de aventurero
10191	Guardabrazos de cruzado
10192	Botas de cruzado
10193	Armadura de cruzado
10194	Capa de cruzado
10195	Escudo de cruzado
10196	Guanteletes de cruzado
10197	Cinturón de cruzado
10198	Yelmo de cruzado
10199	Leotardos de cruzado
10200	Espaldares de cruzado
10201	Grebas de Señor Supremo
10202	Protegebrazos de Señor Supremo
10203	Peto de Señor Supremo
10204	Escudo de láminas pesado
10205	Guanteletes de Señor Supremo
10206	Faja de Señor Supremo
10207	Corona de Señor Supremo
10208	Quijotes de Señor Supremo
10209	Bufas de Señor Supremo
10210	Manto elegante
10211	Botas elegantes
10212	Capa elegante
10213	Brazales elegantes
10214	Guantes elegantes
10215	Togas elegantes
10216	Cinturón elegante
10217	Leotardos elegantes
10218	Túnica elegante
10219	Aro elegante
10220	Túnica Sombra Nocturna
10221	Faja Sombra Nocturna
10222	Botas Sombra Nocturna
10223	Guardabrazos Sombra Nocturna
10224	Capa Sombra Nocturna
10225	Guantes Sombra Nocturna
10226	Casco Sombra Nocturna
10227	Leotardos Sombra Nocturna
10228	Bufas Sombra Nocturna
10229	Brazales grabados
10230	Peto grabado
10231	Manteo grabado
10232	Guanteletes grabados
10233	Faja grabada
10234	Botas grabadas
10235	Yelmo grabado
10236	Leotardos grabados
10237	Espaldares grabados
10238	Botas de láminas pesadas
10239	Protegebrazos de láminas pesados
10240	Coraza de láminas pesada
10241	Yelmo de láminas pesado
10242	Guanteletes de láminas pesados
10243	Faja de láminas pesada
10244	Leotardos de láminas pesados
10245	Espaldares de láminas pesados
10246	Jubón de maestro
10247	Botas de maestro
10248	Brazales de maestro
10249	Capa de maestro
10250	Sombrero de maestro
10251	Guantes de maestro
10252	Leotardos de maestro
10253	Manto de maestro
10254	Toga de maestro
10255	Cinturón de maestro
10256	Brazales de filibustero
10257	Botas de filibustero
10258	Manteo de filibustero
10259	Cinturón de filibustero
10260	Guantes de filibustero
10261	Pañuelo de filibustero
10262	Musleras de filibustero
10263	Hombreras de filibustero
10264	Túnica de filibustero
10265	Brazales de obra maestra
10266	Peto de obra maestra
10267	Manteo de obra maestra
10268	Guanteletes de obra maestra
10269	Faja de obra maestra
10270	Botas de obra maestra
10271	Escudo de obra maestra
10272	Aro de obra maestra
10273	Quijotes de obra maestra
10274	Espaldares de obra maestra
10275	Peto Esmeralda
10276	Escarpes Esmeralda
10277	Guanteletes Esmeralda
10278	Faja Esmeralda
10279	Yelmo esmeralda
10280	Quijotes Esmeralda
10281	Espaldares Esmeralda
10282	Protegebrazos Esmeralda
10283	Muestras de corazón de lobo
10285	Seda de las Sombras
10286	Corazón del Salvaje
10287	Manto de tejido verde
10288	Aro de sabio
10289	Sombrero durable
10290	Tinte rosa
10298	Sortija de Gnomeregan
10299	Amuleto de Gnomeregan
10300	Patrón: jubón de paño mágico rojo
10301	Patrón: máscara de bandido blanca
10302	Patrón: pantalones de paño mágico rojo
10303	Patrón: pantalones de paño tormentoso
10304	Patrón: guantes de paño tormentoso
10305	Pergamino de Protección IV
10306	Pergamino de Espíritu IV
10307	Pergamino de Aguante IV
10308	Pergamino de Intelecto IV
10309	Pergamino de Agilidad IV
10310	Pergamino de Fuerza IV
10311	Patrón: camisa marcial naranja
10312	Patrón: guantes de paño mágico rojo
10313	Patrón: jubón de paño tormentoso
10314	Patrón: camisa de paño mágico lavanda
10315	Patrón: hombreras de paño mágico rojo
10316	Patrón: falda escocesa colorida
10317	Patrón: camisa de paño mágico rosa
10318	Patrón: sombrero de almirante
10319	Patrón: cinta de paño tormentoso
10320	Patrón: cinta de paño mágico rojo
10321	Patrón: camisa de esmoquin
10322	Patrón: hombreras de paño tormentoso
10323	Patrón: pantalones de esmoquin
10324	Patrón: botas de paño tormentoso
10325	Patrón: vestido de boda blanco
10326	Patrón: chaqueta de esmoquin
10327	Cuerno de Echeyakee
10328	Coraza Escarlata
10329	Cinturón Escarlata
10330	Leotardos Escarlata
10331	Guanteletes Escarlata
10332	Botas Escarlata
10333	Muñequeras Escarlata
10338	Cadáver de astacebra fresco
10358	Brazales de Duracin
10359	Botas perpetuas
10360	Serpiente reina negra
10361	Serpiente marrón
10362	Escudo ornamentado
10363	Pared grabada
10364	Escudo de templario
10365	Escudo Esmeralda
10366	Integumento de demonio
10367	Escudo Hiperión
10368	Armadura de placas imbuida
10369	Guanteletes de placas imbuidos
10370	Faja de placas imbuida
10371	Grebas de placas imbuidas
10372	Casco de placas imbuido
10373	Leotardos de placas imbuidos
10374	Espaldares de placas imbuidos
10375	Placas protectoras de brazos imbuidas
10376	Botas de comandante
10377	Protegebrazos de Comandante
10378	Armadura de comandante
10379	Yelmo de comandante
10380	Guanteletes de comandante
10381	Faja de comandante
10382	Leotardos de comandante
10383	Espaldares de comandante
10384	Armadura Hiperión
10385	Grebas Hiperión
10386	Guanteletes Hiperión
10387	Faja Hiperión
10388	Yelmo Hiperión
10389	Quijotes Hiperión
10390	Espaldares Hiperión
10391	Protegebrazos Hiperión
10392	Serpiente carmesí
10393	Cucaracha
10394	Silbato de perro de pradera
10398	Pollo mecánico
10399	Armadura ennegrecida Defias
10400	Leotardos ennegrecidos Defias
10401	Guantes ennegrecidos Defias
10402	Botas ennegrecidas Defias
10403	Cinturón ennegrecido Defias
10404	Cinturón durable
10405	Hombreras de bandido
10406	Cinta de cuero escamado
10407	Hombreras de asaltante
10408	Yelmo a rayas
10409	Botas a rayas
10410	Leotardos del Colmillo
10411	Escarpines del Colmillo
10412	Cinturón del Colmillo
10413	Guantes del Colmillo
10414	Concha de muestra de Quijaforte
10418	Insignia de mitril de luz trémula
10420	Cráneo del Gélido
10421	Jubón de cobre basto
10423	Leotardos de bronce plateado
10424	Diseño: leotardos de bronce plateado
10438	Caja de Felix
10439	Infusión de albaza hirviendo
10440	Jarra de Nori
10441	Fragmento resplandeciente
10442	Artefacto misterioso
10443	Carta chamuscada
10444	Pistola de bengalas de venta estándar
10445	Juego de dibujo
10446	Corazón de Obsidion
10447	Cabeza de Lathoric el Negro
10450	Pluma de hipogrifo sin estropear
10454	Esencia de Eranikus
10455	Esencia encadenada de Eranikus
10456	Un monedero abultado
10457	Caparazón de caracol marino vacío
10458	Oración a Elune
10459	Cabeza del jefe Cornapunta Mantospina
10460	Sangre Hakkari
10461	Brazales enigmáticos
10462	Cinturón enigmático
10463	Patrón: máscara de tejido de sombras
10464	Bastón de Orden
10465	Huevo de Hakkar
10466	Círculo de Piedras Atal'ai
10467	Cartera de comerciante
10478	Gema de maná de Roland
10479	Cartera comercial de Kovic
10498	Microajustador giromático
10499	Gafas Ojo brillante
10500	Gafas de Fuego
10501	Ultragafas Ojo de gato
10502	Gafas extremas de hechizo de poder
10503	Gafas tintadas de rosa
10504	Lentes verdes
10505	Pólvora
10506	Casco de inmersión
10507	Dinamita sólida
10508	Trabuco de mitril
10509	Corazón de llama
10510	Rifle de gran calibre de mitril
10511	Aceite gólem
10512	Balas de mitril de gran impacto
10513	Girotiro de mitril
10514	Bomba de fragmentación de mitril
10515	Antorcha de Retribución
10518	Capa de paracaidista
10538	Tablilla de Beth'Amara
10539	Tablilla de Jin'yael
10540	Tablilla de Markri
10541	Tablilla de Sael'hai
10542	Casco de minero goblin
10543	Casco de albañil goblin
10544	Gran maza Cardoleño
10545	Gafas gnómicas
10546	Mira mortal
10547	Cuchillo de camping
10548	Mira de francotirador
10549	Pantalones de ranchero
10550	Mitones de lana
10551	Daga bañada en torio
10552	Símbolo de Ragnaros
10553	Jubón de supervisor
10554	Pantalones de supervisor
10556	Círculo de Piedras
10558	Núcleo de energía de oro
10559	Tubo de mitril
10560	Disparador inestable
10561	Envoltura de mitril
10562	Bomba de gran carga
10563	Calco: Runa de Beth'Amara
10564	Calco: Runa de Jin'yael
10565	Calco: Runa de Markri
10566	Calco: Runa de Sael'hai
10567	Pistola pinchos
10569	Tesoro oculto del Vuelo negro
10570	Destripahombres
10571	Garrote de hueso de ébano
10572	Fragmento helado
10573	Atizahuesos
10574	Sudario de cadáveres
10575	Muda de piel de vuelo negro
10576	Dragonizo mecánico de mitril
10577	Mortero goblin
10578	Lanzapensamientos
10579	Arco explosivo
10580	Caja goblin "Bum"
10581	Vestimenta cabeza de la Muerte
10582	Botines de brezo
10583	Arnés contra pinchos
10584	Puños Tempesviento
10585	Radio goblin
10586	El grande
10587	Expendedora de bombas goblin
10588	Casco de cohete goblin
10589	Piedra de juramento del Vuelo de Ysera
10590	Caja negra con agujeros
10592	Elixir de ojo de gato
10593	Fragmento draenetista imperfecto
10595	Kum'isha's Junk
10597	Cabeza de Magus Rimtori
10598	Cabeza ensangrentada de Hetaera
10599	Cabeza golpeada de Hetaera
10600	Cabeza amoratada de Hetaera
10601	Esquema: gafas Ojo brillante
10602	Esquema: mira mortal
10603	Esquema: ultragafas Ojo de gato
10604	Esquema: rifle de gran calibre de mitril
10605	Esquema: gafas extremas de hechizo de poder
10606	Esquema: capa de paracaidista
10607	Esquema: casco de inmersión
10608	Esquema: mira de francotirador
10609	Esquema: dragonizo mecánico de mitril
10610	Sangre de Hetaera
10620	Torio
10621	Rollo con runas
10622	Bandera de Kadrak
10623	Bocado de Invierno
10624	Arco hiriente
10625	Espada de sigilo
10626	Martillo de ira
10627	Cachiporra del perro rictus
10628	Arremetida mortal
10629	Botas de caminaniebla
10630	Halo de cazador de almas
10631	Guanteletes Aguasucia
10632	Brazales de escama de babosa
10633	Leotardos Conchaplata
10634	Círculo del Ojo de la mente
10635	Leotardos de anillas pintados
10636	Guantes nómadas
10637	Guantes de cervecero
10638	Manteo de caída larga
10639	Champiñón jacinto
10640	Icor Tejemadera
10641	Lirio alunado
10642	Antídoto de Iverron
10643	Carta lacrada para Ag'tor
10644	Receta: combustible de cohete goblin
10645	Rayo mortal gnómico
10646	Carga de zapador goblin
10647	Tinta de ingeniero
10648	Pliego negro
10649	Fragmento de pesadilla
10650	Melena de jabaespín infestada de peste
10651	Cristal de enfoque arcano rajado
10652	Voluntad del Gigante de montaña
10653	Botas Traillamaradar
10654	Guantes de trenza de yute
10655	Calzones de curruca
10656	Jubón de malla de corteza
10657	Manto Talbar
10658	Galochas del Lodazal
10659	Fragmento de los Pezuña Quebrada
10660	Primera tablilla Mosh'aru
10661	Segunda tablilla Mosh'aru
10662	Huevo de Hakkar relleno
10663	Esencia de Hakkar
10664	Una nota para Magus Rimtori
10678	Nota de Magatha
10679	Nota de Andron
10680	Nota de Jes'rimon
10681	Nota de Xylem
10682	Piedra de juramento de Belnistrasz
10683	Morral de expedicionario
10684	Paracaídas colosal
10686	Égida de batalla
10687	Vial etiquetado vacío #1
10688	Vial etiquetado vacío #2
10689	Vial etiquetado vacío #3
10690	Vial etiquetado vacío #4
10691	Vial lleno marcado como Núm. 1
10692	Vial lleno marcado como Núm. 1
10693	Vial lleno marcado como Núm. 1
10694	Vial lleno marcado como Núm. 1
10695	Caja de viales vacías
10696	Espada Felbane de azsharita encantada
10697	Daga Felbane de azsharita encantada
10698	Bastón Felbane de azsharita encantado
10699	Zarza de Yeh'kinya
10700	Botas encarmine
10701	Botas de Zua'tec
10702	Botas de ogro enigma
10703	Pica endemoniada
10704	Bastón Uñafría
10705	Muñequeras de abeto y sauce
10706	Faja de escama nocturna
10707	Grebas de forjador de acero
10708	Orbe de hechizo de calavera
10709	Orbe de piropiedra
10710	Anillo garra de dragón
10711	Collar de sangre de dragón
10712	Elixir de Cuely
10713	Diseño: cilindro de mitril taraceado
10714	Azsharita cristalina
10715	Mira de Kim'Jael
10716	Rayo reductor gnómico
10717	Brújula de Kim'Jael
10718	Cachivache de Kim'Jael
10719	Alarma móvil
10720	Proyector redomático gnómico
10721	Cinturón de prevención de daño gnómico
10722	Pollo relleno de Kim'Jael
10723	Radio de daño gnómico
10724	Botas cohete gnómicas
10725	Pollo de batalla gnomo
10726	Gorro de control mental gnómico
10727	Pistola de dragón goblin
10728	Patrón: camisa negra de aventurero
10738	Envío a Galvan
10739	Anillo de Entereza
10740	Quijotes centurión
10741	Casco de Lordrec
10742	Leotardos de Vuelo
10743	Protegecabezas Pirodraco
10744	Hacha del draco ébano
10745	Hombreras Kaylari
10746	Protegebrazos de acero rúnico
10747	Fajín de maestro
10748	Botas del placer errante
10749	Yelmo de guardia vengador
10750	Daga dirk Potencia de vida
10751	Aro Ráfaga de gemas
10752	Cofre taraceado Esmeralda
10753	Amuleto de Grol
10754	Amuleto de Sevine
10755	Amuleto de Allistarj
10757	Amuleto del Rapiñador
10758	X'calijabalí
10759	Cuerno de Rapiñador cortado
10760	Puños de cerdo
10761	Daga rabiafría
10762	Togas del Exánime
10763	Barbuta de metal de hielo
10764	Armadura Fríomortal
10765	Dedos de hueso
10766	Rama de podredumbre de la Peste
10767	Guardia de jabalí indómito
10768	Cinturón de campeón de jabalí
10769	Ojo resplandeciente de Mordresh
10770	Calavera inerte Mordresh
10771	Fajín de mago de la Muerte
10772	Cuchilla de glotón
10773	Urna Hakkari
10774	Hombreras de pellejo
10775	Caparazón de Tuten'kash
10776	Manteo de araña sedosa
10777	Guantes araña
10778	Collar de Santuario
10779	Sangre de demonio
10780	Marca de Hakkar
10781	Peto Hakkari
10782	Sudario Hakkari
10783	Bufas Atal'ai
10784	Peto Atal'ai
10785	Leotardos Atal'ai
10786	Botas Atal'ai
10787	Guantes Atal'ai
10788	Faja Atal'ai
10789	Manual de disciplinas de Ingeniería
10790	Tarjeta de miembro del Club de Ingeniería Gnoma
10791	Tarjeta de miembro del Club de Ingeniería Goblin
10792	Compromiso de secreto perpetuo de Nixx
10793	Compromiso de secreto perpetuo de Sobrechispa
10794	Compromiso de secreto perpetuo de Oglethorpe
10795	Sortija de garra de draco
10796	Piedra draco
10797	Sopla Fuego
10798	Anillo de colmillo de Atal'alarion
10799	Cabeza de pincho
10800	Brazales Aguaoscura
10801	Botas de escamas húmedas
10802	Capa velo alado
10803	Hoja de los desdichados
10804	Puño del Condenado
10805	Comedor de muertos
10806	Vestimentas del profeta Atal'ai
10807	Falda escocesa del profeta Atal'ai
10808	Guantes del profeta Atal'ai
10818	Pergamino de Yeh'kinya
10819	Pluma de lechúcico
10820	Cinturón de siembra
10821	Capa de sembrador
10822	Dracochorro oscuro
10823	Espada del vencedor
10824	Talismán Resplandor de Ámbar
10826	Bastón de Conocimiento
10827	Túnica de vigilante
10828	Uña funesta
10829	Ojo de dragón
10830	M73 granada de fragmentación
10831	Orbe de inferi
10832	Manual del buscador de inferi
10833	Cuernos de Eranikus
10834	Juego de rastreo de can manáfago
10835	Emblema de Supremacía
10836	Vara de Corrosión
10837	Diente de Eranikus
10838	Poderío de Hakkar
10839	Nota cristalizada
10840	Nota cristalizada
10841	Té de espina de oro
10842	Pareo de escamas de viento
10843	Manteo Piel emplumada
10844	Aguja de Hakkar
10845	Abrazo de guerrero
10846	Grebas tiro de sangre
10847	Llamada de dragón
10858	Diseño: gran maza de hierro sólido
10918	Envenenar herida
10919	Guantes de boticario
10920	Envenenar herida II
10921	Envenenar herida III
10922	Envenenar herida IV
10938	Esencia mágica inferior
10939	Esencia mágica superior
10940	Polvo extraño
10958	Collar de Hilary
10959	Saco de pellejo de demonio
10978	Fragmento de luz trémula pequeño
10998	Esencia astral inferior
10999	Ferrovil
11000	Llave Sombratiniebla
11018	Tierra de Un'Goro
11020	Faltriquera de siempre verde
11022	Paquete de semillas Tharlendris
11023	Pollo ancona
11024	Caja de hierbas siempre verde
11026	Carcasa de rana de árbol
11027	Caja de rana de madera
11038	Fórmula: encantar arma de 2M: espíritu inferior
11039	Fórmula: encantar capa: agilidad menor
11040	Mañagrana
11058	Aro de Sha'ni
11078	Llave del arca de reliquias
11079	Cabeza cortada Gor'tesh
11080	Cabeza cortada Gor'tesh
11081	Fórmula: encantar escudo: protección inferior
11082	Esencia astral superior
11083	Polvo de alma
11084	Fragmento con luz trémula grande
11085	Llave de cofre del cliente del mes
11086	Jang'thraze el Protector
11098	Fórmula: encantar capa: resistencia inferior a las Sombras
11099	Hierro Negro
11101	Fórmula: encantar brazal: fuerza inferior
11102	Huevo sin abrir de duende dardo
11103	Vale para semillas
11104	Brújula grande
11105	Pliego de mapa enrollado
11106	Llave con cabeza de león
11107	Una talega pequeña
11108	Fotografía descolorida
11109	Comida para pollos especial
11110	Huevo de gallina
11111	Huevo roto de duende dardo
11112	Equipo de investigación
11113	Cajón de alimentos
11114	Hueso de dinosaurio
11115	Llave de caja fuerte secreta
11116	Un diario destrozado
11118	Piedra arcádica
11119	Cosecha de milicia
11120	Martillo de Belgrom
11121	Talwar Aguaoscura
11122	Zanahoria pinchada en un palo
11123	Leotardos de zancalluvia
11124	Yelmo de Exilio
11125	Informe de la vendimia
11126	Tablilla de Kurniya
11127	Mercancías desperdiciadas
11128	Vara de oro
11129	Esencia de los elementos
11130	Vara de oro rúnica
11131	Muestra de pared de colmena
11132	Vial de raspadura sin usar
11133	Espada de aprendiz de Linken
11134	Esencia mística inferior
11135	Esencia mística superior
11136	Espada templada de Linken
11137	Polvo de visión
11138	Fragmento resplandeciente pequeño
11139	Fragmento resplandeciente grande
11140	Llave de celda de prisión
11141	Cebo
11142	Churumbele roto
11143	Engranaje
11144	Vara de veraplata
11145	Vara de veraplata con runas
11146	Churumbele roto y maltrecho
11147	Portada del manual de Churumbele
11148	Página del manual de Churumbele
11149	Manual de Churumbele
11150	Fórmula: encantar guantes: minería
11151	Fórmula: encantar guantes: herboristería
11152	Fórmula: encantar guantes: pesca
11162	Espada de excelencia de Linken
11163	Fórmula: encantar brazal: desvío inferior
11164	Fórmula: encantar arma: bestiacida inferior
11165	Fórmula: encantar arma: mataelementales inferior
11166	Fórmula: encantar guantes: desuello
11167	Fórmula: encantar botas: espíritu inferior
11168	Fórmula: encantar escudo: bloqueo inferior
11169	Libro sobre Aquor
11171	Acero inferi
11172	Garras de plata
11173	Corazón Troncoferro
11174	Esencia abisal inferior
11175	Esencia abisal superior
11176	Polvo onírico
11177	Fragmento radiante pequeño
11178	Fragmento radiante grande
11179	Llama dorada
11184	Cristal de poder azul
11185	Cristal de poder verde
11186	Cristal de poder rojo
11187	Brazales de tallo
11188	Cristal de poder amarillo
11189	Togas de Tierraleña
11190	Guantes de parra
11191	Botas de granjero
11192	Guantes de modisto
11193	Peto Viento abrasador
11194	Camisote de escama prismática
11195	Peto forjado por la guerra
11196	Medallón de ráfaga mental
11197	Llave de guarda oscuro
11198	Runa de Escape
11199	Escudo de ingeniero 1
11200	Escudo de ingeniero 2
11201	Escudo de ingeniero 3
11202	Fórmula: encantar escudo: aguante
11203	Fórmula: encantar guantes: minería avanzada
11204	Fórmula: encantar brazal: espíritu superior
11205	Fórmula: encantar guantes: herboristería avanzada
11206	Fórmula: encantar capa: agilidad inferior
11207	Fórmula: encantar arma: arma ígnea
11208	Fórmula: encantar arma: matanza de demonios
11222	Cabeza de Krom'zar
11223	Fórmula: encantar brazal: desvío
11224	Fórmula: encantar escudo: resistencia a Escarcha
11225	Fórmula: encantar brazal: aguante superior
11226	Fórmula: encantar guantes: equitación
11227	Trozo del estandarte de Krom'zar
11228	Muda de piel de Vuelo demente
11229	Faja de escamas brillantes
11230	Esencia ígnea encerrada
11231	Muda de piel de vuelo negro alterada
11242	Raíz del mal
11243	Elixir de Videre
11262	Orbe de Lorica
11263	Varita de potencia abisal
11265	Gran maza de riscoleño
11266	Fragmento elemental fracturado
11267	Muestra de fragmento elemental
11268	Cabeza de Argelmach
11269	Núcleo elemental intacto
11270	Compromiso firmado de Nixx
11282	Compromiso firmado de Oglethorpe
11283	Compromiso de secreto perpetuo firmado de Sobrechispa
11284	Balas precisas
11285	Flecha dentada
11286	Grilletes de torio
11287	Varita mágica inferior
11288	Varita mágica superior
11289	Varita mística inferior
11290	Varita mística superior
11291	Madera de estrella
11302	Fuerza de Uther
11303	Arco corto refinado
11304	Arco largo refinado
11305	Arco corto denso
11306	Arco corvo sólido
11307	Arco largo macizo
11308	Arco corto nemoroso
11309	El corazón de la montaña
11310	Manto de profeta de llamas
11311	Manteo de escamas de ascuas
11312	Receta de Cebatruenos perdida
11313	Cabeza de Ribbly
11315	Brote pétalo de sangre
11316	Pétalo de sangre
11318	Calima Atal'ai
11319	Irradior sin cargar
11320	Liquidador de pétalo de sangre
11324	Morral de expedicionario
11325	Jarra de cerveza tradicional Hierro Negro
11362	Carcaj fino
11363	Faltriquera de pólvora fina
11364	Tabardo de Ventormenta
11366	Carta de Helendis Rivacuerno
11367	Petición a Bolvar de Solomon
11368	Decreto de Bolvar
11370	Hierro Negro
11371	Lingote Hierro Negro
11382	Sangre de la Montaña
11384	Diente de basilisco partido
11385	Escama de basilisco
11386	Ojo de basilisco fangoso
11387	Corazón de basilisco
11388	Veneno de basilisco
11389	Piel de basilisco fulgurante
11390	Colmillo de murciélago partido
11391	Ala de murciélago con púas
11392	Garra de murciélago cortada
11393	Calavera de murciélago pequeño
11394	Corazón de murciélago
11395	Oreja de murciélago
11402	Pelambre de murciélago impoluta
11403	Colmillo de murciélago grande
11404	Ojo de murciélago malvado
11405	Veta gigante de plata
11406	Cadáver de oso en descomposición
11407	Pelambre de oso rasgado
11408	Mandíbula de oso
11409	Costillar de oso
11410	Garra de oso indómito
11411	Hueso de oso grande
11412	Vial de Nagmara
11413	Vial de Nagmara lleno
11414	Melena canosa
11415	Bayas variadas
11416	Caja torácica delicada
11417	Ala emplumada
11418	Hueso hueco de ala
11419	Huevo sin abrir misterioso
11420	Utensilio de escritura elegante
11422	Obsequio de renovación de ingeniero goblin
11423	Obsequio de renovación de ingeniero gnomo
11442	Juego de diputado de Ventormenta
11444	Jabalí chupón siniestro
11445	Flauta de los antiguos
11446	Una nota arrugada
11462	Cuchillo desechado
11463	Paquete no entregado
11464	Información perdida del alguacil Windsor
11465	Información perdida del alguacil Windsor
11466	Informe de Raschal
11467	Medallón Roca Negra
11468	Talega extraña Hierro Negro
11469	Brazales de Bandasangre
11470	Trascripción de tablilla
11471	Huevo de duende dardo frágil
11472	Costillas de acechador Melenargenta
11473	PX83-Enigmatrón
11474	Huevo de duende dardo
11475	Capa manchada de vino
11476	Pelambre de U'cha
11477	Garra de ravasaurio blanco
11478	Pelambre de gorila de Un'Goro
11479	Pelambre de vapuleador de Un'Goro
11480	Pelambre de Tronador de Un'Goro
11482	Manual de instrucciones de la torre de cristal
11502	Hombreras de piel de conocimiento
11503	Sangre de ámbar
11504	Trozo de trillanodonte muerto
11507	Pelambre de hiena moteada
11508	Zapatillas de Maestro de Juego
11509	Glándula de feromonas de ravasaurio
11510	Cabeza de Lar'korwi
11511	Antorcha Cenarion
11512	Parche de piel contaminada
11513	Vitriolo corrupto
11514	Agente máculo
11515	Fragmento de alma corrupto
11516	Ungüento de planta Cenarion
11522	Tótem de plata de Aquementas
11562	Restaurar cristal
11563	Potencia de cristal
11564	Tutor de cristal
11565	Cristal de reducción
11566	Carga de cristal
11567	Espiral de cristal
11568	Faltriquera de Torwa
11569	Carne de trillanodonte en conserva
11570	Mezcla de feromonas en conserva
11582	Bálsamo inferi
11583	Manzana de cactus
11584	Sorpresa de manzana de cactus
11590	Equipo de reparación mecánico
11602	Llave de Tragapenas
11603	Rebanadora desgarravil
11604	Placa Hierro Negro
11605	Hombreras Hierro Negro
11606	Malla Hierro Negro
11607	Taladora Hierro Negro
11608	Pulverizador Hierro Negro
11609	Muda de piel de vuelo negro alterada
11610	Diseño: pulverizador Hierro Negro
11611	Diseño: taladora Hierro Negro
11612	Diseño: placas Hierro Negro
11614	Diseño: malla Hierro Negro
11615	Diseño: hombreras Hierro Negro
11617	Provisiones de Eridan
11622	Arcano de Reflexión inferior
11623	Capa de lanzaduendes
11624	Hombrera dura
11625	Esfera embrujada
11626	Manteo de velo negro
11627	Grebas de Pie de flota
11628	Arco de maestro de perros de caza
11629	Rifle de maestro de perros de caza
11630	Perdigones de roca
11631	Integumento petravalva
11632	Hombreras Escoria térrea
11633	Caparazón colmillo de araña
11634	Guantes de tela de seda
11635	Faca gancho
11642	Arcano de Constitución inferior
11643	Arcano de Tenacidad inferior
11644	Arcano de Recuperación inferior
11645	Arcano de Voracidad inferior
11646	Arcano de Voracidad inferior
11647	Arcano de Voracidad inferior
11648	Arcano de Voracidad inferior
11649	Arcano de Voracidad inferior
11662	Fajín Ban'thok
11665	Puños de vigía ogro
11668	Flauta de Xavaric
11669	Anillo de gran poder
11674	Lazo maldito de fuego de jade
11675	Botas Sombra demoníaca
11677	Manteo de podredumbre de tumba
11678	Caparazón de Anub'shiah
11679	Guardabrazos rubicundos
11682	Vial de Eridan
11684	Ferromazo
11685	Hombreras de pellejo escindido
11686	Faja de Furia bestial
11702	Desollador de grisosos
11703	Faja muro de piedra
11722	Bufas de posometal
11723	Flameberge equilibrado de Buenacero
11724	Paquete con retraso
11725	Pata de cristal sólido
11726	Cadena de gladiador indómito
11727	Libro de contabilidad de Buenacero
11728	Leotardos de gladiador indómito
11729	Yelmo de gladiador indómito
11730	Mandiletes de gladiador indómito
11731	Grebas de gladiador indómito
11732	Tratado sobre Reflexión
11733	Tratado sobre Constitución
11734	Tratado sobre Tenacidad
11735	Parche Furia Ardiente
11736	Tratado sobre Recuperación
11737	Tratado sobre Voracidad
11742	Morral de caminante
11743	Puño de roca
11744	Puñosangre
11745	Puños de Falange
11746	Yelmo calavera gólem
11747	Togas de zancudo flamígero
11748	Caduceo pírico
11749	Leotardos de escamas abrasadoras
11750	Bastón para prender
11751	Esencia ardiente
11752	Sangre negra de los Atormentados
11753	Ojo de Kajal
11754	Diamante negro
11755	Collar de Verek
11764	Braquiales de pellejo de ceniza
11765	Muñequeras de piromalla
11766	Puños de tejido flamígero
11767	Guardabrazos de placas de ascuas
11768	Brazales incendiarios
11782	Manto boreal
11783	Faja de acero frío
11784	Hoja de Arbiter
11785	Baluarte gólem de roca
11786	Piedra de la Tierra
11787	Botas de esquisto
11802	Leotardos de cresta de lava
11803	Potencia de magma
11804	Cantimplora de Spraggle
11805	Martillo de rubidio
11807	Fajín del Corazón ardiente
11808	Círculo de Llama
11809	Cólera de llamas
11810	Fuerza de voluntad
11811	Corazón de la montaña humeante
11812	Manteo de la Salamandra de Fuego
11813	Fórmula: corazón humeante de la montaña
11814	Puños de arrabios
11815	Mano de Justicia
11816	Hacha de batalla de Forjafuria
11817	Espada de Lord General
11818	Llave del excusado de Grimesilt
11819	Viento segundo
11820	Armadura decorada real
11821	Leotardos de conflicto de guerra
11822	Botas omnitiro
11823	Falda escocesa luminaria
11824	Sortija ciclónica
11825	Bomba mascota
11826	Lil' Humillo
11827	Esquema: Lil' Humillo
11828	Esquema: bomba mascota
11829	Cenizas de Un'Goro
11830	Escama diemetradón de telaraña
11831	Escama de pterrordax de telaraña
11832	Ráfaga de conocimiento
11833	Cebo de reina Gorishi
11834	Alquitrán muy pegajoso
11835	Cerebro de reina Gorishi
11837	Glándula secretora de olor Gorishi
11839	Monóculo de arquitecto jefe
11840	Camisa de maestro constructor
11841	Bombachos de diseñador senior
11842	Manto de perito jefe
11843	Vale bancario
11844	Informe de Un'Goro de Pestlezugg
11845	Bolsa de cuero hecha a mano
11846	Brebaje especial de Zumbang
11847	Capa maltrecha
11848	Cinturón de lienzo
11849	Brazales de metal oxidados
11850	Manteo corto de murciumbrío
11851	Túnica de carroñero
11852	Leotardos de nómada
11853	Botas de senderismo
11854	Destornillador de Churumbele
11855	Llave inglesa de Tork
11856	Hoja élfica ceremonial
11857	Vara santificada
11858	Manteo de batalla dura
11859	Orbe Luna de jade
11860	Pararrayos cargado
11861	Faja de Represalia
11862	Sortija de hueso blanca
11863	Trituradora de hueso blanca
11864	Lanza de hueso blanca
11865	Botas rencor
11866	Cinturón de castigo de Nagmara
11867	Guanteletes exasperantes
11868	Sortija de apnea
11869	Sortija de Sha'ni
11870	Orbe de olvido
11871	Bufas Snarkshaw
11872	Grebas eschewal
11873	Manteo de niebla etérea
11874	Manto de las nubes
11875	Brazales de la Brisa
11876	Túnica de acechador de las llanuras
11882	Leotardos de escolta
11883	Una riñonera sucia
11884	Hombrera luz lunar
11885	Antorcha Sombratiniebla
11886	Mensaje urgente
11887	Carretilla del Círculo Cenarion
11888	Guantes de investigación de Quintis
11889	Espaldares de cortezaférrea
11902	Espada de maestría de Linken
11903	Jaula para gatos (gatito corrupto)
11904	Espíritu de Aquementas
11905	Bumerán de Linken
11906	Machacabestias
11907	Destripador de bestias
11908	Botas de cantera de arqueólogo
11909	Cinturón de herramientas de excavador
11910	Musleras con joyas
11911	Leotardos de copa de árbol
11912	Paquete de contenedores de moco vacíos
11913	Yelmo de Clayridge
11914	Jarra de moco maldito vacía
11915	Bloquea lloviznas de Shizzle
11916	Bozal de Shizzle
11917	Limpiaboquillas de Shizzle
11918	Guantes de gruta
11919	Grebas de placas de risco
11920	Guadaña de aparición
11921	Gigante impermeable
11922	Hoja grabada con sangre
11923	El martillo de Gracia
11924	Togas de la Corona real
11925	Sudario fantasmal
11926	Peto mortífero
11927	Musleras del Guardián eterno
11928	Cetro real Thaurissan
11929	Leotardos de espectro inquietante
11930	El nuevo manteo del emperador
11931	Vengador Forjaterrible
11932	Bastón de sabiduría orientadora
11933	Joya imperial
11934	Lacre de emperador
11935	Piedra Magmus
11936	Cinturón de cazador de reliquia
11937	Saco de monedas gordo
11938	Saco de gemas
11939	Pulsera lustrosa
11940	Collar brillante
11941	Documentos falsos
11942	Documentos legales
11943	Escritura del Puente Thandol
11944	Botitas de bebé Hierro Negro
11945	Anillo Hierro Negro
11946	Collar de ópalo de fuego
11947	Jarra llena de moco maldito
11948	Jarra de moco corrupto vacía
11949	Jarra de moco manchado llena
11950	Frutos de la flor del viento
11951	Tubérculo de blancoria
11952	Aliento de Dragón nocturno
11953	Jarra de muestra pura vacía
11954	Jarra de muestra pura llena
11955	Bolsa de contenedores de lodo vacíos
11962	Esposas
11963	Bufas de penitencia
11964	Cayada Golpeveloz
11965	Anillo de cuarzo
11966	Saco de monedas pequeño
11967	Sortija de zircón
11968	Aro ámbar
11969	Círculo de jacinto
11970	Anillo de espinela
11971	Sortija de amatista
11972	Anillo carneliano
11973	Eslabón de hematites
11974	Anillo aguamarina
11975	Anillo de topacio
11976	Hueso Sardonyx
11977	Aro serpentino
11978	Eslabón de jaspe
11979	Círculo Peridot
11980	Anillo ópalo
11981	Sortija de plomo
11982	Sortija viridiana
11983	Anillo de cromo
11984	Anillo de cobalto
11985	Anillo cerúleo
11986	Aro de talio
11987	Círculo iridio
11988	Sortija de telurio
11989	Anillo de vanadium
11990	Anillo de selenio
11991	Anillo de mercurio
11992	Sortija bermellón
11993	Anillo de terracota
11994	Sortija de coral
11995	Sortija de marfil
11996	Anillo de basalto
11997	Círculo de piedra verde
11998	Aro azabache
11999	Aro de magnetita
12000	Cuchilla de miembro
12001	Anillo de ónice
12002	Círculo de mármol
12003	Cerveza negra enana
12004	Sortija obsidiana
12005	Anillo de granito
12006	Anillo de prado
12007	Anillo de pradera
12008	Anillo de sabana
12009	Anillo tundra
12010	Anillo de pantano
12011	Aro de bosque
12012	Anillo de marisma
12013	Anillo del desierto
12014	Anillo ártico
12015	Anillo del pantano
12016	Anillo de la selva
12017	Sortija prismática
12018	Yelmo de conservador
12019	Talismán cerúleo
12020	Gargantilla de talio
12021	Escarpes de escudo de placas
12022	Cadena iridio
12023	Collar de telurio
12024	Talismán de vanadium
12025	Cadena de selenio
12026	Colgante de mercurio
12027	Collar bermellón
12028	Collar de basalto
12029	Talismán de piedra verde
12030	Cadena azabache
12031	Collar de magnetita
12032	Gargantilla de ónice
12033	Joyas de familia Thaurissan
12034	Collar de mármol
12035	Colgante obsidiano
12036	Collar de granito
12037	Carne misteriosa
12038	Lacre de Lagrave
12039	Collar tundra
12040	Colgante de bosque
12041	Leotardos Cortaviento
12042	Cadena de Mar'li
12043	Gargantilla del desierto
12044	Colgante ártico
12045	Colgante del pantano
12046	Collar de la selva
12047	Collar espectral
12048	Colgante prismático
12049	Armadura de acero seccionador
12050	Botas de calima
12051	Guanteletes descarados
12052	Anillo de la Luna
12053	Anillo de roca volcánica
12054	Sortija de demonio
12055	Sortija de polvo de estrellas
12056	Anillo de los cielos
12057	Sortija de escamas de dragón
12058	Anillo de hueso demoníaco
12059	Medallón de conquistador
12060	Nota de Shindrell
12061	Hoja de Juicio
12062	Hoja apta para la lucha
12064	Caperuza de Maestro de Juego
12065	Amuleto de los elementos
12066	Manteo de esquisto
12082	Bufas de pellejo de vermis
12083	Fajín valconiano
12102	Anillo del Aristócrata
12103	Estrella de Mystaria
12104	Túnica espinapinta
12105	Leotardos de malla de orgullo
12106	Peto de piel de roca
12107	Leotardos de seda susurradora
12108	Armadura de escamas de basalto
12109	Hombre de luna azur
12110	Mantón de lanzalluvias
12111	Guanteletes de placas de lava
12112	Brazales de demonio de cripta
12113	Manteo nacido del sol
12114	Guantes Ocaso
12115	Garra Stalwart
12122	Basura de Kum'isha
12143	Llave de espinazo de dragón
12144	Ovosciloscopio
12162	Diseño: espada corta de hierro endurecido
12163	Diseño: sable de acero lunar
12164	Diseño: hacha de hierro macizo
12184	Carne de raptor
12185	Sombrero de almirante Velasangre
12190	Poción de letargo sin sueños
12191	Arcón de Amanecer de plata
12192	Arcón de Halo de bruma
12202	Carne de tigre
12203	Carne de lobo rojo
12204	Carne de kodo pesada
12205	Carne de araña blanca
12206	Carne de cangrejo tierna
12207	Huevo gigante
12208	Carne de lobo tierna
12209	Chuleta de lobo magro
12210	Raptor asado
12211	Costillas de lobo especiadas
12212	Estofado de la selva
12213	Sorpresa de carroñero
12214	Estofado misterioso
12215	Estofado de kodo pesado
12216	Chili de cangrejo especiado
12217	Ají aliento de dragón
12218	Tortilla de monstruo
12219	Lacre de ascensión sin adornar
12220	Brazal elemental intacto
12223	Ala de murciélago carnosa
12224	Ala de murciélago crujiente
12225	Caña de pescar de la familia Blump
12226	Receta: ala de murciélago crujiente
12227	Receta: chuleta de lobo magro
12228	Receta: raptor asado
12229	Receta: costillas de lobo picantes
12230	Muestra de babosa de Frondavil
12231	Receta: estofado de la selva
12232	Receta: sorpresa de carroñero
12233	Receta: estofado misterioso
12234	Muestra de Frondavil corrupta
12235	Muestra de babosa de Un'Goro
12236	Muestra de Un'Goro pura
12237	Trozos de cangrejo bueno
12238	Mero de Costa Oscura
12239	Receta: ají aliento de dragón
12240	Receta: estofado de kodo pesado
12241	Huevo de dragón recogido
12242	Huesos de criatura marina
12243	Garra humeante
12247	Cuchillo de hoja ancha
12248	Daga dirk temeraria
12249	Hacha despiadada
12250	Hacha de medianoche
12251	Palo grande
12252	Bastón de Protección
12253	Capa roja luminosa
12254	Capa bien aceitada
12255	Leotardos pálidos
12256	Leotardos de paño ceniza
12257	Cinturón con muchas marcas
12258	Cinturón de pinza de serpiente
12259	Daga de acero destellante
12260	Hoja dorada abrasadora
12261	Diseño: hoja dorada abrasadora
12262	Jaula de Mascolupo vacía
12263	Joven lupo encerrado
12264	Lupo porteador
12282	Hacha de batalla desgastada
12283	Esencia de cría
12284	Draco-Incarcinatrix 900
12286	Prototipo de ovosciloscopio
12287	Módulo colectrónico
12288	Moco corrupto encerrado
12289	Restos de tortuga marina
12291	Muestra de moco fusionado
12292	Caja con extrañas marcas
12293	Hilo de oro refinado
12295	Leotardos de las Milicias del pueblo
12296	Chispa de la Milicia del Pueblo
12299	Guantes de red
12300	Orbe de energía dracónica
12301	Llave de jaula de bambú
12302	Riendas del sable de hielo
12303	Riendas del sable de la noche
12323	Lacre de ascensión sin forjar
12324	Lacre de ascensión forjado
12325	Riendas del leopardo primigenio
12326	Riendas del sable leonado
12327	Riendas del dientes de sable
12330	Cuerno del lobo rojo
12334	Fragmentos Machacahielo
12335	Gema de Espina Ahumada
12336	Gema de Cumbrerroca
12337	Gema de Hacha de Sangre
12339	Obsequio de Vaelan
12341	Muestra de fruta Bosque Negro
12342	Muestra de grano Bosque Negro
12343	Muestra de nuez Bosque Negro
12344	Lacre de Ascensión
12345	Pertenencias de Bijou
12346	Bol de limpieza vacío
12347	Bol de limpieza lleno
12349	Muestra del Río Fonroca
12350	Tubo de ensayo vacío
12351	Cuerno del lobo ártico
12352	Broche de Equipasino
12353	Brida de semental blanco
12354	Brida de Palomino
12355	Talismán de Corrupción
12356	Huevo de dracoleón Nido Alto
12358	Tablilla Rocanegra
12359	Lingote de torio
12360	Lingote de arcanita
12361	Zafiro azul
12363	Cristal Arcano
12364	Esmeralda enorme
12365	Piedra densa
12366	Pelaje de yeti grueso
12367	Cuerno de yeti prístino
12368	Táctica del Alba
12369	Cetro de Vectus
12382	Llave de la ciudad
12383	Pluma Lunadón
12384	Carretilla de Mau'ari
12402	Huevo antiguo
12404	Piedra de afilar densa
12405	Armadura de torio
12406	Cinturón de torio
12408	Brazales de torio
12409	Botas de torio
12410	Yelmo de torio
12411	Tercera tablilla Mosh'aru
12412	Cuarta tablilla Mosh'aru
12414	Leotardos de torio
12415	Peto radiante
12416	Cinturón radiante
12417	Aro radiante
12418	Guantes radiantes
12419	Botas radiantes
12420	Leotardos radiantes
12422	Peto de placas imperiales
12424	Cinturón de placas imperiales
12425	Brazales de placas imperiales
12426	Botas de placas imperiales
12427	Yelmo de placas imperiales
12428	Hombreras de placas imperiales
12429	Leotardos de placas imperiales
12430	E'ko Sable de Hielo
12431	E'ko Nevada
12432	Dentoesquirla E'ko
12433	E'ko de lechúcico
12434	E'ko Orvallo
12435	E'ko Cardo Nevado
12436	E'ko Machacahielo
12437	Cajón de Crestabuena
12438	Carta de Tinkee
12440	Magic Knucklebone (DND)
12442	Charm Pouch (DND)
12443	Knucklebone Pouch (DND)
12444	Cuerno de quimera Orvallo
12445	Talega de Felnok
12446	Mosquete Yunquemar
12447	Arco Cardoleño
12448	Rifle de caza ligero
12449	Arco primitivo
12450	Ráfaga juju
12451	Poder juju
12455	Ámbar juju
12457	Frío juju
12458	Astucia juju
12459	Escape juju
12460	Poderío juju
12462	Abrazo de la serpiente alada
12463	Cuchillo carnicero de colmillo de draco
12464	Talones de Llamas de Sangre
12465	Mantón Ocaso
12466	Cordón de espiral del Alba
12467	Huevo extraño
12468	Varita Chilton
12469	Mutilador
12470	Tobilleras Acecharenas
12471	Bastón de Caminadesiertos
12472	Termómetro de Krakle
12522	Guantes voladores de Bingles
12524	Amuleto con plumas azules
12525	Provisiones de Jaron
12527	Partecostillas
12528	El mazo del juez
12529	Portador de Telabrasada
12530	Huevo de araña de la cumbre
12531	Aguja abrasadora
12532	Aguja del Tallapiedras
12533	Pica despiadada
12534	Cabeza de Omokk
12535	Regla de Forja Maldita
12542	Vestimentas de pira funeraria
12543	Piedracanto de Forjaz
12544	Resolución de Thrall
12545	Ojo de Orgrimmar
12546	Puños de aristócrata
12547	Mandilete de Mar Alom
12549	Cajasesos
12550	Grilletes de gólems con runas
12551	Capa escudo de piedra
12552	Abrigo Aterrabojas
12553	Botas Caminaveloz
12554	Manos del Heraldo exaltado
12555	Grebas Belicutor
12556	Botas de suma sacerdotisa
12557	Bufas de acero de ébano
12558	Amuleto con plumas azules
12562	Importantes documentos de Roca Negra
12563	Pedido del señor de la guerra Dientegore
12564	Nota de asesinato
12565	Transportador de gatitos de Winna
12566	Frasquito endurecido
12567	Frasquito lleno
12582	Keris de Zul'Serak
12583	Sierra apocalíptica de Puño Negro
12584	Espada larga de Gran mariscal
12585	Medallón de Ventormenta
12586	Glándula de veneno de inmaduro
12587	Ojo de Visualización
12588	Hombro de picohueso
12589	Fajín pluma de polvo
12590	Artillero vil
12592	Hoja negra de Shahram
12602	Deflector draconiano
12603	Túnica de la noche
12604	Tiara de fuego de estrellas
12605	Calaverador serpentino
12606	Faja cristalizada
12607	Escamas cromáticas luminosas
12608	Delantal de carnicero
12609	Pañuelo de visión policromática
12610	Hombreras de placas rúnicas
12611	Botas de placas rúnicas
12612	Yelmo de placas rúnicas
12613	Peto rúnico
12614	Leotardos de placas rúnicas
12615	Túnica de malla indómita
12616	Botas de malla indómita
12617	Hombreras de malla indómita
12618	Peto de torio encantado
12619	Leotardos de torio encantado
12620	Yelmo de torio encantado
12621	Horqueta de demonio
12622	Carne Dentoesquirla
12623	Carne Orvallo
12624	Malla de espina salvaje
12625	Hombreras Albar
12626	Puños de funeral
12627	Temporal Displacer
12628	Peto de demonio forjado
12630	Cabeza de Rend Puño Negro
12631	Guanteletes de placas ígneas
12632	Guanteletes de tormenta
12633	Yelmo de alma blanca
12634	Faja de cincelador
12635	Pergamino simple
12636	Yelmo del Gran jefe
12637	Guanteletes de Backus
12638	Reloj de Andorhal
12639	Guanteletes bastión
12640	Yelmo corazón de león
12641	Malla invulnerable
12642	Orbe infernal purgado
12643	Piedrafuerte densa
12644	Piedra de pulir densa
12645	Punta de escudo de torio
12646	Esmeralda infus
12647	Rubí de Felhas
12648	Espíritu de manáfago encarcelado
12649	Espíritu infernal encarcelado
12650	Humidificador armonizado
12651	Cuervo negro
12652	Informe de reconocimiento de Bijou
12653	Gancho
12654	Tiro maldito
12655	Lingote de torio encantado
12662	Runa demoníaca
12663	Rama de roble con inscripciones
12682	Diseño: armadura de torio
12683	Diseño: cinturón de torio
12684	Diseño: brazales de torio
12685	Diseño: cinturón radiante
12687	Diseño: hombreras de placas imperiales
12688	Diseño: cinturón de placas imperiales
12689	Diseño: peto radiante
12690	Diseño: brazales de placas imperiales
12691	Diseño: malla de espina salvaje
12692	Diseño: escudo con punta de torio
12693	Diseño: botas de torio
12694	Diseño: yelmo de torio
12695	Diseño: guantes radiantes
12696	Diseño: peto de demonio forjado
12697	Diseño: botas radiantes
12698	Diseño: hombreras Albar
12699	Diseño: guanteletes de placas ígneas
12700	Diseño: botas de placas imperiales
12701	Diseño: yelmo de placas imperiales
12702	Diseño: aro radiante
12703	Diseño: guanteletes de tormenta
12704	Diseño: leotardos de torio
12705	Diseño: peto de placas imperiales
12706	Diseño: hombreras de placas rúnicas
12707	Diseño: botas de placas rúnicas
12708	Cajones de suministros del cruce
12709	Desollador de Pip
12710	Trozo resplandeciente de carne de la Bestia
12711	Diseño: yelmo de alma blanca
12712	Mojo de Warosh
12713	Diseño: leotardos radiantes
12714	Diseño: yelmo de placas rúnicas
12715	Diseño: leotardos de placas imperiales
12716	Diseño: yelmo del Gran Jefe
12717	Diseño: yelmo corazón de león
12718	Diseño: peto rúnico
12719	Diseño: leotardos de placas rúnicas
12720	Diseño: guanteletes bastión
12721	Mitad de talismán de buena suerte
12722	La otra mitad del talismán de buena suerte
12723	Talismán de buena suerte
12724	Paquete de Janice
12725	Diseño: yelmo de torio encantado
12726	Diseño: leotardos de torio encantados
12727	Diseño: peto de torio encantado
12728	Diseño: malla invulnerable
12730	Pergamino de Warosh
12731	Pellejo de bestia prístino
12732	Pita incendiaria
12733	Carne de Sable de Hielo sacra
12734	Hilo escarlata encantado
12735	Punto de abominación deshilachado
12736	Fluido embalsamante Levescarcha
12737	Hierba luminiscente
12738	Llave del excusado de Dalson
12739	Llave del armario de Dalson
12740	Quinta tablilla Mosh'aru
12741	Sexta tablilla Mosh'aru
12752	Almete del Sabio Escarlata
12753	Piel de las Sombras
12756	Leotardos de Arcana
12757	Peto Sed de Sangre
12762	Secreto de diseños
12763	Fruta de eter de Un'Goro
12764	Espada magna de torio
12765	Nota secreta #1
12766	Nota secreta #2
12768	Nota secreta #3
12769	Extracto de Picomadera
12770	Información de Bijou
12771	Frasco vacío de piroagua
12772	Martillo de torio taraceado
12773	Hacha de mano de torio ornamentado
12774	Filo del Alba
12775	Hacha de batalla de torio enorme
12776	Martillo de batalla encantado
12777	Estoque llameante
12778	Cofre de documentos
12779	Filo de runa
12780	Orden del general Drakkisath
12781	Serenidad
12782	Corrupción
12783	Buscalmas
12784	Segadora de arcanita
12785	Partículas incendiarias
12790	Campeón de arcanita
12791	Faca de camarero
12792	Martillo volcánico
12793	Túnica de mixologista
12794	Martillo de tormenta de obra maestra
12795	Espolón de sangre
12796	Martillo de los Titanes
12797	Guardia de Escarcha
12798	Aniquilador
12799	Ópalo grande
12800	Diamante de Azeroth
12802	Lanza Negra
12803	Esencia viva
12804	Mojo potente
12805	Orbe de Fuego
12806	Peto cubierto de runas sin forjar
12807	Estandarte de la Plaga
12808	Esencia de no-muerto
12809	Piedra guardián
12810	Cuero encantado
12811	Orbe de rectitud
12812	Guanteletes de placas sin templar
12813	Frasco de baba misteriosa
12814	Llama en una botella
12815	Antorcha de aviso
12816	Diseño: espada magna de torio
12817	Diseño: extracto de Picomadera
12818	Diseño: martillo de torio taraceado
12819	Diseño: hacha de mano de torio ornamentado
12820	Piroagua de los Nevada
12821	Diseño: filo del Alba
12822	Gotita de horror tóxico
12823	Diseño: hacha de batalla de torio enorme
12824	Diseño: martillo de batalla encantado
12825	Diseño: estoque llameante
12826	Diseño: filo de runa
12827	Diseño: serenidad
12828	Diseño: martillo volcánico
12829	Cajón Nevada
12830	Diseño: corrupción
12831	Diseño: espolón de sangre
12832	Diseño: Lanza Negra
12833	Diseño: martillo de los Titanes
12834	Diseño: campeón de arcanita
12835	Diseño: aniquilador
12836	Diseño: guardia de Escarcha
12837	Diseño: martillo Tormenta de obra maestra
12838	Diseño: segadora de arcanita
12839	Diseño: buscalmas
12840	Piedra de la Plaga de esbirro
12841	Piedra de la Plaga de un invasor
12842	Registro escrito de forma rudimentaria
12843	Piedra de la Plaga de un corruptor
12844	Muestra de valor de Alba Argenta
12845	Medallón de Fe
12846	Comisión del Alba Argenta
12847	Pica manchada de alma
12848	Pico manchado de sangre
12849	Saco besado por demonio
12871	Caparazón cromático
12884	Pezuña de Arnak
12885	Muñeca de Pamela
12886	Cabeza de la muñeca de Pamela
12887	Parte izquierda de la muñeca de Pamela
12888	Parte derecha de la muñeca de Pamela
12891	Pico de Jaron
12894	Alianza de Joseph
12895	Peto del Vuelo cromático
12896	Primer fragmento de reliquia
12897	Segundo fragmento de reliquia
12898	Tercer fragmento de reliquia
12899	Cuarto fragmento de la reliquia
12900	Anales de Villa Darrow
12903	Musleras del desafiante cromático
12904	Sombrero superespecial suami de Shawn
12905	Manteo de fuego salvaje
12906	Agua de poza de la Luna purificada
12907	Agua de poza de la Luna corrupta
12922	Cantimplora vacía
12923	Escama de Awbee
12924	Vela de ritual
12925	Piel de serpiente de Arikara
12926	Sortija flamígera
12927	Hombreras Golpevero
12928	Yeti mecánico de Umi
12929	Talismán Furia de ascuas
12930	Junco maderahelecho
12935	Musleras de maestro de guerra
12936	Ajorcas Belinato
12938	Sangre de héroes
12939	Guardián tribal de Dal'Rend
12940	Carga sacra de Dal'Rend
12942	Llave de jaula de pantera
12945	Musleras del Desafiante cromático
12946	Hipercondensador Gizmo
12947	Anillo de Audacia de Alex
12952	Calavera de Gyth
12953	Almófar ojo de dragón
12954	Tratado de Davil
12955	Escudo de Rutagrana
12956	Cráneo de Horgus
12957	Espada destrozada de Marduk
12958	Receta: transmutar arcanita
12960	Plumas de guerra tribales
12963	Leotardos de maestro del acero
12964	Musleras de Tristam
12965	Leotardos de sudario de espíritus
12966	Guardabrazos de bruma negra
12967	Capa lunasangre
12968	Manteo Tejescarcha
12969	Sauce llorón
12970	Placa ceremonial de general
12973	Bala de cañón Escarlata
12974	El caballero negro
12975	Hacha de prospector
12976	Hoja Parchierro
12977	Guantes de puño de mago
12978	Cinturón de creador de tormentas
12979	Capa Aterra Fuego
12982	Guardapiés forrados con plata
12983	Garrote Rakzur
12984	Llamacielo
12985	Anillo de Defensa
12987	Calzones Tejeoscuro
12988	Túnica de vista estelar
12989	Mordida de gárgola
12990	Filo de cuchilla
12992	Hoja abrasadora
12994	Guanteletes de Thorbia
12996	Sortija de Purificación
12997	Emblema Barbarroja
12998	Manto de mago
12999	Sortijas ala de draco
13000	Bastón de Hale Fuegomago
13001	El círculo de la doncella
13002	Colgante de Lady Alizabeth
13003	Hacha de batalla de Lord Alexander
13004	Antorcha de Austen
13005	Manta de Amy
13006	Masa de McGowan
13007	Capa de llama de mago
13008	Pantalones de Dalewind
13009	Pellejo de vaca reina
13010	Musleras Cantasueños
13011	Cinturón forrado con plata
13012	Brazales Yorgen
13013	Manto de zahorí anciano
13014	Hacha de Rin'ji
13015	Serathil
13016	Killmaim
13017	Hacha de batalla de destripador del infierno
13018	Cuchilla de verdugo
13019	Arco corto de garra de arpía
13020	Arco de artillero del cielo
13021	Aguja
13022	Arco largo de ala de grifo
13023	Arco largo de cuero de águila
13024	Azotador de Beazel
13025	Trineo Muertobosque
13026	Luz del cielo
13027	Cascahuesos
13028	Martillo piedra sangre
13029	Cristal umbrío
13030	Hueso de basilisco
13031	Orbe de Mantoniebla
13032	Espada de Corrupción
13033	Espada de Zealot
13034	Estoque Aceroveloz
13035	Rebanaserpientes
13036	Hoja de asesinato
13037	Aguijonero Pino de cristal
13038	Vientoveloz
13039	Ballesta Atraviesa calaveras
13040	Ballesta certera
13041	Hoja de guardián
13042	Espada del Magistrado
13043	Hoja de los titanes
13044	Destripador demonio
13045	Martillo viscoso
13046	Cerveza de Blanchard
13047	Ramita del Árbol del Mundo
13048	Mazo amenazante
13049	Espada claymore de decano
13051	Fura de bruja
13052	Belicista
13053	Fatídico
13054	Segadora macabra
13055	Masticahuesos
13056	Artillero demente
13057	Pico de sangre
13058	Punta de Khoo
13059	Cuervo de piedra
13060	El taladro
13062	Truenedera
13063	Tumbaestrellas
13064	Encendedor de Jaina
13065	Varita de Allistarj
13066	Bufas de destripador de vermis
13067	Armadura hidrálica
13068	Grebas obsidianas
13070	Botas de escama de Sapphiron
13071	Puño de Hakoo con placas
13072	Guanteletes de piedra
13073	Yelmo de Jarrathol
13074	Leotardos de fragmentos goblin
13075	Musleras alafunesta
13076	Brazales de destripador gigante
13077	Faja de Uther
13079	Escudo de Thorsen
13080	Garra de viuda
13081	Escudo Calaverance
13082	Rodela de ladera
13083	Emblema de la familia Garrett
13084	Cadena caleidoscópica
13085	Gargantilla horizonte
13086	Riendas del Sable de Hielo de Cuna del Invierno
13087	Gargantilla Orgullo de Río
13088	Talismán de Gazlowe
13089	Colgante de Skibi
13090	Peto de los Elegidos
13091	Medallón del Gran Mariscal Morris
13093	Anillo de ámbar sonrojado
13094	La joya de la reina
13095	Sortija de asalto
13096	Sortija de Hierofante
13097	Anillo de Frente de acero
13098	Sortija tejedaño
13099	Mocasines de la liebre blanca
13100	Botas de Furen
13101	Zapatos Correlobos
13102	Gracia de Cassandra
13103	Hombrera de araña venenosa
13105	Anillo de Sutarn
13106	Pulseras mágicas resplandecientes
13107	Puños de calavera mágica
13108	Manto de Golpe de tigre
13109	Manteo de llama negra
13110	Arnés miedo lobo
13111	Sandalias del Insurgente
13112	Yelmo alado
13113	Penacho Plumaluna
13114	Leotardos Aterratrols
13115	Manto de esquilador de ovejas
13116	Bufas de lo oculto
13117	Fajín de Ogron
13118	Fajín serpentino
13119	Brazales kodo encantados
13120	Brazales Furiahonda
13121	Ala del Dracochorro
13122	Manteo de fantasma oscuro
13123	Armadura Caminasueños
13124	Botas de escamas de ravasaurio
13125	Botas de anillas élficas
13126	Guanteletes Belillama
13127	Corona de atracador de hielo
13128	Yelmo de gran Bergg
13129	Leotardos Pirocabello
13130	Musleras Windrunner
13131	Manto de conchas brillantes
13132	Hombreras esqueléticas
13133	Insignias Pirodraco
13134	Cinturón del Gladiador
13135	Guardabrazos señorial
13136	Lanzaguisantes de Timmy
13137	Hilacero
13138	El silenciador
13139	Rompentrañas
13140	Llave roja de sangre
13141	Diente de Gnarr
13142	Faja de Brigam
13143	Marca del Señor Dragón
13144	Cinturón de serenidad
13145	Cinturón de ogro enigma
13146	Escopeta de conchas
13148	Congeladora
13149	Vol. 1 del escrito sobre Invocación de Eldarath
13151	Los estudios místicos de Hor'ank
13152	la historia sin conclusión
13153	Escrito de Mal'cin Vorail
13154	Estudios de lo arcano de Jael'marin
13155	Calavera resonadora
13156	Cristal místico
13157	Calavera fétida
13158	Palabras del Gran Jefe
13159	Polvo de huesos
13161	Bastón de refugio
13162	Garras de reiver
13163	Guadaña incansable
13164	Corazón de la escama
13166	Hombreras embate
13167	Puño de Omokk
13168	Placa del rey chamán
13169	Leotardos de aterracrines
13170	Leotardos de sudario celestial
13171	Mechero de Smokey
13172	Tabaco de calidad de Grimm
13173	Hacha arrojadiza Filo volador
13174	Muestra de carne con peste
13175	Arco tirante de Voone
13176	Datos de la Plaga
13177	Talismán de Evasión
13178	Círculo rosado
13179	Guardabrazos cuorobronce
13180	Agua bendita de Stratholme
13181	Guantes de piel de demonio
13182	Hoja fase
13183	Escupeveneno
13184	Manoplas de lágrimas
13185	Manto de hendeprofeta
13186	Botella de Campo de Piedra Mácula vacía
13187	Botella de lágrimas de Dalson vacía
13188	Botella de El Tormento vacía
13189	Botella de Gangrena de Gahrron vacía
13190	Botella de campo de piedras máculas llena
13191	Botella llena de lágrimas de Dalson
13192	Botella llena de El Tormento
13193	Botella llena de la Gangrena de Gahrron
13194	Llave del caldero del campo de piedras máculas
13195	Llave del caldero de las lágrimas de Dalson
13196	Llave de la caldera de la Gangrena de Gahrron
13197	Llave de caldero rondado del Tormento
13198	Machacador
13199	Ataduras Aplastacrestas
13202	Anales ampliados de Villa Darrow
13203	Capa de estela
13204	Maza de Bashguud
13205	Protector Rhombeard
13206	Leotardos de pelo de lobo
13207	Cabeza de Lord Fel'dan de las Sombras
13208	Guardabrazos aullador pálido
13209	Lacre del Alba
13210	Hombrera de lobo aterrador
13211	Brazales garraja
13212	Collar de pinchos de Halycon
13213	Ojo de Telabrasada
13216	Corona del Penitente
13217	Sortija del Penitente
13218	Colmillo de la Araña de cristal
13223	Faltriquera de cartero de Stratholme
13243	Defensor Argenta
13244	Guanteletes dorados
13245	Espalda de Kresh
13246	Vengador Argenta
13247	Baúl del intendente Zigris
13248	Tiro de ráfaga de arcabuz
13249	Cruzado Argenta
13250	Cabeza de Balnazzar
13251	Cabeza de Barón Osahendido
13252	Faja correnubes
13253	Manos de Poder
13254	Integumento astral
13255	Guanteletes de objetivo real
13257	Bufas rúnicas demoníacas
13258	Guanteletes de pellejo de escoria
13259	Guardapiés de Costillas de Acero
13260	Botas de Bailavientos
13261	Globo de D'sak
13262	Crematoria
13282	Botas de vigía de torre ogro
13283	Anillo de mago
13284	Botas de batalla Dardoveloz
13285	La Cercenadora de Roca Negra
13286	Puafilada
13287	Patrón: arnés de pellejo de raptor
13288	Patrón: cinturón de pellejo de raptor
13289	Libertador de Egan
13302	Llave del buzón de la Fila del Mercado
13303	Llave cuadrada de buzón de cruzado
13304	Llave del buzón de la calle del festival
13305	Llave del buzón de la plaza de los Ancianos
13306	Llave del buzón de la Plaza del Rey
13307	Llave del buzón de Ezra Grimm
13308	Esquema: deflector de hielo
13309	Esquema: trabuco fabricado con amor
13310	Esquema: mira de precisión
13311	Esquema: dragonizo mecánico
13313	Escrituras sacras del Altonato
13314	Abrazo de Alanna
13317	Silbato del raptor de marfil
13320	Acelerador arcano
13321	Mecazancudo verde
13322	Mecazancudo sin pintar
13323	Mecazancudo morado
13324	Mecazancudo azul y rojo
13325	Mecazancudo verde fosforito
13326	Mecazancudo blanco Mod A
13327	Mecazancudo azul hielo modelo A
13328	Carnero negro
13329	Carnero helado
13330	Bolsa de rábano de Derek
13331	Caballo esquelético rojo
13332	Caballo esquelético azul
13333	Caballo esquelético marrón
13334	Caballo de guerra esquelético verde
13335	Riendas de Hemocargador
13340	Manteo del Barón negro
13342	Pez mascota
13343	Piedra mascota
13344	Guanteletes draconianos
13345	Lacre de Rivendare
13346	Togas del Exaltado
13347	Cristal de Zin-Malor
13348	Pelo de demonio
13349	Cetro de los Profanos
13350	Insignia de la Guarda Negra
13351	Delantal de herrero de martillos carmesí
13352	Piedra serpiente de Vosh'gajin
13353	Libro sobre los Muertos
13354	Resonador ectoplásmico
13356	Intensificador somático
13357	Agitador óseo
13358	Hombreras lenguavermis
13359	Corona de Tiranía
13360	Ofrenda del magi élfico
13361	Atracador Forjacráneos
13362	Carta del frente
13363	Proclamación municipal
13364	Anuncio de Ezra Grimm
13365	Aviso de consejo de la ciudad
13366	Juguete ingenioso
13367	Obsequio envuelto
13368	Trizahuesos
13369	Zancudos de fuego
13370	Enfocador vítreo
13371	Padre llama
13372	Caña de negrero
13373	Sortija de Carne
13374	Manto de ladrón de almas
13375	Emblema de Retribución
13376	Capa de tribunal real
13377	Balas de cañón en miniatura
13378	Blusa ruiseñor
13379	Piccolo de la llama ardiente
13380	Obús portátil de Willey
13381	Botas de maestro cañonero
13382	Mensajero bola de cañón
13383	Prendas de lana de juglar saltarín
13384	Faja arco iris
13385	Escrito sobre Conocimiento
13386	Manteo de archivista
13387	Faja de previsión
13388	Túnica de jefe de correos
13389	Pantalones de jefe de correos
13390	Sortija de jefe de correos
13391	Botines de jefe de correos
13392	Lacre de jefe de correos
13393	Embate de Gassol
13394	Abrazo frío de Skul
13395	Garras de Skul
13396	Toque espantoso de Skul
13397	Manto de gárgola Piel de piedra
13398	Botas del Aullador
13399	Talones de gárgola triturados
13400	Protegebrazos del Sádico
13401	La mano cruel de Timmy
13402	Galochas de Timmy
13403	Lazo de Grimagore
13404	Máscara de los Penitentes
13405	Espaldares de los Aterranoches dolidos
13408	Parte almas
13409	Brazales lágrima
13422	Anguila Escama Tormentosa
13423	Aceite de Escama Tormentosa
13442	Poción de ira poderosa
13443	Poción de maná excelente
13444	Poción de maná sublime
13445	Elixir de defensa excelente
13446	Poción de curación sublime
13447	Elixir de los sabios
13448	Las escrituras de Castel Darrow
13450	Las escrituras de Costasur
13451	Las escrituras de Molino Tarren
13452	Elixir de la mangosta
13453	Elixir de potencia bruta
13454	Elixir superior arcano
13455	Poción de escudo de piedra superior
13456	Poción de protección de Escarcha superior
13457	Poción de protección de Fuego superior
13458	Poción de protección de Naturaleza superior
13459	Poción de protección de las Sombras superior
13460	Poción de protección Sagrada superior
13461	Poción de protección de Arcana superior
13462	Poción de purificación
13463	Hojasueño
13464	Sansam dorado
13465	Salviargenta de montaña
13466	Flor de peste
13467	Setelo
13468	Loto negro
13469	Cabeza de Weldon Barov
13470	Cabeza de Alexi Barov
13471	Las escrituras de Rémol
13473	Talismán de buena suerte de piedra mácula
13474	Escopeta del granjero Dalson
13475	Alianza de la familia Dalson
13476	Receta: poción de ira poderosa
13477	Receta: poción de maná excelente
13478	Receta: elixir de defensa excelente
13479	Receta: elixir de los sabios
13480	Receta: poción de curación sublime
13481	Receta: elixir de potencia bruta
13482	Receta: transmutar aire a fuego
13483	Receta: transmutar fuego a tierra
13484	Receta: transmutar tierra a agua
13485	Receta: transmutar agua a aire
13486	Receta: transmutar inerte a agua
13487	Receta: transmutar agua a inerte
13488	Receta: transmutar vida a tierra
13489	Receta: transmutar tierra a vida
13490	Receta: poción de escudo de piedra superior
13491	Receta: elixir de la mangosta
13492	Receta: poción de purificación
13493	Receta: elixir arcano superior
13494	Receta: poción de protección de Fuego superior
13495	Receta: poción de protección de Escarcha superior
13496	Receta: poción de protección de Naturaleza superior
13497	Receta: poción de protección Arcana superior
13498	Leotardos artesanales de maestro herrero
13499	Receta: poción de protección de las Sombras superior
13500	Receta: poción de protección Sagrada superior
13501	Receta: poción de maná sublime
13502	Faja artesanal de maestro herrero
13503	Piedra de alquimista
13505	Hoja rúnica del Barón Rivendare
13506	Frasco de petrificación
13507	Informe del Vigiarrisco Cuernolargo
13508	Ojo de Arachnida
13509	Garra de Previsión
13510	Frasco de los Titanes
13511	Frasco de sabiduría destilada
13512	Frasco de poder supremo
13513	Frasco de resistencia cromática
13514	Gemido del alma en pena
13515	Descargas de relámpagos de Ramstein
13517	Receta: piedra de alquimista
13518	Receta: frasco de petrificación
13519	Receta: frasco de los Titanes
13520	Receta: frasco de sabiduría destilada
13521	Receta: frasco de poder supremo
13522	Receta: frasco de resistencia cromática
13523	Sangre de los inocentes
13524	Cráneo de las Sombras ardientes
13525	Dedos Presotenebra
13526	Faja con marcas de llamas
13527	Grebas de Corredor de lava
13528	Brazales del Vacío del crepúsculo
13529	Colmillo de Nerub'enkan
13530	Zapatillas para correr Gota colmillo
13531	Leotardos de acechacriptas
13532	Garras de Giraoscuro
13533	Espaldares marcados con ácido
13534	Dedo de alma en pena
13535	Brazaletes de fantasma tactofrío
13536	Cuerno de Despertar
13537	Brazales pellejofrío
13538	Espaldares de Gritaviento
13539	Toque de alma en pena
13542	Caja de demonio
13544	Esencia espectral
13545	Marisco
13546	Panzasangre
13562	Restos de Trey Forjaluz
13582	Correa Zergling
13583	Collar panda
13584	Piedra de diablo
13585	Recuerdo de Evocación
13602	Piedra de hechizo superior
13603	Piedra de hechizo sublime
13624	Memorias del Vínculo del Alma
13626	Cabeza humana de Ras Levescarcha
13699	Piedra de fuego
13700	Piedra de fuego superior
13701	Pirorroca sublime
13702	Apocalíseas
13703	Hueso de kodo
13704	Llave esqueleto
13724	Galleta de maná enriquecido
13725	Bolsa de Horrores de Krastinov
13752	Memorias del Vínculo del Alma
13754	Vigorpez lustroso crudo
13755	Calamar de invierno
13756	Lubina cruda
13757	Anguila relámpago
13758	Branquirrojo crudo
13759	Pargo nocturno crudo
13760	Salmón escama de sol crudo
13761	Huevos congelados
13810	Fruta del sol bendita
13811	Collar del Alba
13812	Anillo del Alba
13813	Zumo de fruta del sol bendito
13815	Algunas runas
13816	Espada larga refinada
13817	Espada magna estrecha
13818	Hacha dentada
13819	Hacha de guerra equilibrada
13820	Maza de peso
13821	Gran maza enorme
13822	Daga con pinchos
13823	Bastón de guerra recio
13824	Arco largo corvo
13825	Mosquete primordial
13842	Mañana de otoño/invierno
13843	Tarde de otoño/invierno
13844	Tarde noche de otoño/invierno
13845	Noche de otoño/invierno
13846	Mañana de primavera/verano
13847	Mediodía de primavera/verano
13848	Tarde de primavera/verano
13849	Noche de primavera/verano
13850	Munición de Estruendo
13851	Costillas de lobo picantes
13852	Orden del Gran Cruzado
13853	Trozo de carne de gusano carroñero
13856	Cinturón de paño rúnico
13857	Túnica de paño rúnico
13858	Toga de paño rúnico
13860	Capa de paño rúnico
13863	Guantes de paño rúnico
13864	Botas de paño rúnico
13865	Pantalones de paño rúnico
13866	Cinta de paño rúnico
13867	Hombreras de paño rúnico
13868	Toga Tejescarcha
13869	Túnica Tejescarcha
13870	Guantes Tejescarcha
13871	Pantalones Tejescarcha
13872	Fardo de madera
13873	Llave de la Sala de visión
13874	Cajón pesado
13875	Cofre cerrado recubierto de hierro
13876	Mero de 20 kilos
13877	Mero de 23 kilos
13878	Mero de 26 kilos
13879	Mero de 27 kilos
13880	Mero de 24 kilos
13881	Branquirrojo hinchado
13882	Branquirrojo de 21 kilos
13883	Branquirrojo de 22 kilos
13884	Branquirrojo de 24 kilos
13885	Branquirrojo de 17 kilos
13886	Branquirrojo de 18 kilos
13887	Branquirrojo de 25 kilos
13888	Langosta pinza oscura
13889	Salmón escama blanca crudo
13890	Pez coraza de placas
13891	Salmón hinchado
13892	Recombobulador kodo
13893	Vigorpez crudo grande
13895	Dangui formal
13896	Hanbok de boda verde oscuro
13897	Hanbok tradicional blanco
13898	Dangui real
13899	Hanbok tradicional rojo
13900	Hanbok de boda verde
13901	Salmón de 7 kilos
13902	Salmón de 9 kilos
13903	Salmón de 12 kilos
13904	Salmón de 13 kilos
13905	Salmón de 15 kilos
13906	Salmón de 16 kilos
13907	Langosta de 3 kilos
13908	Langosta de 4 kilos
13909	Langosta de 6 kilos
13910	Langosta de 7 kilos
13911	Langosta de 10 kilos
13912	Langosta de 11 kilos
13913	Langosta de 12 kilos
13914	Vigorpez de 35 kilos
13915	Vigorpez de 42 kilos
13916	Vigorpez de 46 kilos
13917	Vigorpez de 51 kilos
13918	Cofre cerrado reforzado
13920	Escama de dragón sana
13926	Perla de oro
13927	Vigorpez lustroso cocido
13928	Calamar a la parrilla
13929	Lubina ahumada caliente
13930	Filete de branquirrojo
13931	Sopa de aleta nocturna
13932	Salmón escama de sol pochado
13933	Estofado de langosta
13934	Filete de vigorpez
13935	Salmón al horno
13937	Cargo de rector
13938	Pluma amarrahuesos
13939	Receta: serviola moteada
13940	Receta: vigorpez lustroso cocido
13941	Receta: filete de branquirrojo
13942	Receta: calamar a la parrilla
13943	Receta: lubina ahumada caliente
13944	Peto de lápida
13945	Receta: sopa de aleta nocturna
13946	Receta: salmón escama de sol pochado
13947	Receta: estofado de langosta
13948	Receta: filete de vigorpez
13949	Receta: salmón al horno
13950	Cinta de detención
13951	Protegebrazos de acerovigor
13952	Rebanadora de hoja de hielo
13953	Colmillo silencioso
13954	Escarpines Verdantis
13955	Hombreras con forma de piedra
13956	Garra de Andros
13957	Rebanador de gárgolas
13958	Grilletes Vermiothalak
13959	Limitador de circunferencia de Omokk
13960	Corazón del Mefisto
13961	Bozal de Halycon
13962	Playa de Vosh'gajin
13963	Mandiletes de maña de Voone
13964	Espada de bruja
13965	Amplitud de Puño Negro
13966	Marca de Tiranía
13967	Grebas Atracavientos
13968	Ojo de la bestia
13969	Ajorcas de guardia amenazante
13982	Espada de guerra de Castel Darrow
13983	Hacha de guerra de lápida
13984	Pico Darrow
13986	Corona de Castel Darrow
14002	Guarda fuerte de Villa Darrow
14022	Llamador de campesino Barov
14023	Llamador de campesino Barov
14024	Espolón de miedo
14025	Cinturón de místico
14042	Jubón de paño ceniza
14043	Guantes de paño ceniza
14044	Capa de paño ceniza
14045	Pantalones de paño ceniza
14046	Bolsa de paño rúnico
14047	Paño rúnico
14048	Descarga de paño rúnico
14062	Montura de kodo
14083	Bastión de Tyrande
14086	Sandalias perladas
14087	Puños perlados
14088	Capa perlada
14089	Guantes perlados
14090	Calzones perlados
14091	Toga perlada
14093	Cordones perlados
14094	Brazaletes perlados
14095	Sortijas nativas
14096	Jubón nativo
14097	Pantalones nativos
14098	Capa nativa
14099	Fajín nativo
14100	Toga de paño brillante
14101	Guantes de paño brillante
14102	Mitones nativos
14103	Capa de paño brillante
14104	Pantalones de paño brillante
14106	Toga de tela de inferi
14107	Pantalones de tela de inferi
14108	Botas de tela de inferi
14109	Toga nativa
14110	Sandalias nativas
14111	Caperuza de tela de inferi
14112	Hombreras de tela de inferi
14113	Fajín aborigen
14114	Borceguíes aborígenes
14115	Sortijas aborígenes
14116	Manteo aborigen
14117	Guantes aborígenes
14119	Taparrabos aborigen
14120	Toga aborigen
14121	Jubón aborigen
14122	Sortijas de ritual
14123	Manteo de ritual
14124	Guantes de ritual
14125	Leotardos de ritual
14126	Hombrera de ritual
14127	Sudario de ritual
14128	Toga de tejido zahorí
14129	Sandalias de ritual
14130	Turbante de tejido zahorí
14131	Cinturón de ritual
14132	Leotardos de tejido zahorí
14133	Túnica de ritual
14134	Capa de Fuego
14136	Toga de Noche invernal
14137	Leotardos de tela lunar
14138	Jubón de tela lunar
14139	Hombreras de tela lunar
14140	Aro de tela lunar
14141	Jubón Telafantasma
14142	Guantes Telafantasma
14143	Cinturón Telafantasma
14144	Pantalones Telafantasma
14145	Hoja mácula maldita
14146	Guantes de maestría de hechizos
14147	Brazales de morador de cuevas
14148	Puños cristalinos
14149	Manteo subterráneo
14150	Toga de Evocación
14151	Hoja de canto
14152	Toga del Archimago
14153	Toga del Vacío
14154	Vestimentas de fe verdadera
14155	Bolsa de tela lunar
14156	Bolsa sin fondo
14157	Manto pagano
14158	Jubón pagano
14159	Zapatos paganos
14160	Sortijas paganas
14161	Manteo pagano
14162	Mitones paganos
14163	Brazaletes paganos
14164	Cinturón pagano
14165	Calzones paganos
14166	Brazales de bucanero
14167	Manteo de bucanero
14168	Guantes de bucanero
14169	Hombreras aborígenes
14170	Manto de bucanero
14171	Pantalones de bucanero
14172	Togas de bucanero
14173	Cordón de bucanero
14174	Botas de bucanero
14175	Jubón de bucanero
14176	Botas de guardia
14177	Puños de guardia
14178	Capa de guardia
14179	Manteo de guardia
14180	Chaleco de guardia
14181	Mitones de guardia
14182	Manto de guardia
14183	Leotardos de guardia
14184	Togas de guardia
14185	Cincho de guardia
14186	Manto Clamalluvias
14187	Puños Clamalluvias
14188	Capa Clamalluvias
14189	Cofia Clamalluvias
14190	Jubón Clamalluvias
14191	Mitones Clamalluvias
14192	Togas Clamalluvias
14193	Pantalones Clamalluvias
14194	Cordón Clamalluvias
14195	Botas Clamalluvias
14196	Sandalias Piel de Cardo
14197	Sortijas Piel de Cardo
14198	Capa Piel de Cardo
14199	Guantes Piel de Cardo
14200	Cofia Piel de Cardo
14201	Manto Piel de Cardo
14202	Chaleco Piel de Cardo
14203	Pantalones Piel de Cardo
14204	Toga Piel de Cardo
14205	Cinturón Piel de Cardo
14206	Pulseras vitales
14207	Leotardos vitales
14208	Cinta vital
14209	Fajín vital
14210	Manteo vital
14211	Mitones vitales
14212	Hombreras vitales
14213	Vestiduras vitales
14214	Botas vitales
14215	Túnica vital
14216	Chaleco de geomántico
14217	Cordón de geomántico
14218	Botas de geomántico
14219	Capa de geomántico
14220	Almete de geomántico
14221	Brazales de geomántico
14222	Guantes de geomántico
14223	Bufas de geomántico
14224	Pantalones de geomántico
14225	Brazaletes de geomántico
14226	Pulseras de seda de ascuas
14227	Seda de araña Tejehierro
14228	Corona de seda de ascuas
14229	Capa de seda de ascuas
14230	Túnica de seda de ascuas
14231	Mitones de seda de ascuas
14232	Manto de seda de ascuas
14233	Leotardos de seda de ascuas
14234	Togas de seda de ascuas
14235	Cordón de seda de ascuas
14236	Botas de seda de ascuas
14237	Armadura Niebla Negra
14238	Botas Niebla Negra
14239	Manteo Niebla Negra
14240	Sortija Niebla Negra
14241	Manoplas Niebla Negra
14242	Pantalones Niebla Negra
14243	Manto Niebla Negra
14244	Brazaletes Niebla Negra
14245	Faja Niebla Negra
14246	Sombrero de zahorí Niebla Negra
14247	Manto lunar
14248	Ataduras lunares
14249	Jubón lunar
14250	Zapatillas lunares
14251	Capa lunar
14252	Corona lunar
14253	Mitones lunares
14254	Vestimenta lunar
14255	Cinturón lunar
14256	Tela de inferi
14257	Leotardos lunares
14258	Cordón de tejido de sangre
14259	Botas de tejido de sangre
14260	Brazales de tejido de sangre
14261	Capa de tejido de sangre
14262	Mitones de tejido de sangre
14263	Máscara de tejido de sangre
14264	Pantalones de tejido de sangre
14265	Brazaletes de tejido de sangre
14266	Protectores de tejido de sangre
14267	Chaleco de tejido de sangre
14268	Puños de Gaea
14269	Zapatillas de Gaea
14270	Capa de Gaea
14271	Aro de Gaea
14272	Mitones de Gaea
14273	Hombrera de Gaea
14274	Leotardos de Gaea
14275	Vestimenta de Gaea
14276	Cinturón de Gaea
14277	Túnica de Gaea
14278	Manto opulentos
14279	Brazales opulentos
14280	Manteo opulento
14281	Corona opulenta
14282	Guantes opulentos
14283	Leotardos opulentos
14284	Togas opulentas
14285	Botas opulentas
14286	Cinturón opulento
14287	Túnica opulenta
14288	Armadura arácnida
14289	Faja arácnida
14290	Escarpines arácnidos
14291	Pulseras arácnidas
14292	Manteo arácnido
14293	Aro arácnido
14294	Guantes arácnidos
14295	Leotardos arácnidos
14296	Espaldares arácnidos
14297	Togas arácnidas
14298	Bufas de Tirahuesos
14299	Botas de Tirahuesos
14300	Manteo de Tirahuesos
14301	Ataduras de Tirahuesos
14302	Guantes de Tirahuesos
14303	Sudario de Tirahuesos
14304	Cinturón de Tirahuesos
14305	Pareo de Tirahuesos
14306	Jubón de Tirahuesos
14307	Corona de Tirahuesos
14308	Túnica celestial
14309	Cinturón celestial
14310	Zapatillas celestiales
14311	Ataduras celestiales
14312	Corona celestial
14313	Manteo celestial
14314	Mitones celestiales
14315	Falda escocesa celestial
14316	Espaldares celestiales
14317	Togas de seda celestiales
14318	Túnica resplendente
14319	Botas resplendentes
14320	Pulseras resplendentes
14321	Caja resplendente
14322	Aro resplendente
14323	Guanteletes resplendentes
14324	Pareo resplendente
14325	Insignias resplendentes
14326	Togas resplendentes
14327	Cinturón resplendente
14328	Coraza eterna
14329	Botas eternas
14330	Ataduras eternas
14331	Capa eterna
14332	Corona eterna
14333	Guantes eternos
14334	Pareo eterno
14335	Bufas eternas
14336	Brazaletes eternos
14337	Cordón eterno
14338	Tubo de agua vacío
14339	Tubo de agua de poza de la luna
14340	Togas de exánime heladas
14341	Hilo rúnico
14342	Tela lunar
14343	Fragmento luminoso pequeño
14344	Fragmento luminoso grande
14364	Zapatillas de místico
14365	Manteo de místico
14366	Pulseras de místico
14367	Guantes de místico
14368	Hombreras de místico
14369	Atadura de místico
14370	Prendas de lana de mísitico
14371	Toga de místico
14372	Armadura sanguina
14373	Cinturón sanguina
14374	Sandalias sanguinas
14375	Puños sanguinos
14376	Manteo sanguino
14377	Mitones sanguinos
14378	Manto sanguino
14379	Pantalones sanguinos
14380	Toga sanguina
14381	Cartera de Tótem Siniestro
14382	Coraza Durabilidad
14383	Brazales Durabilidad
14384	Botas Durabilidad
14385	Capa Durabilidad
14386	Sombrero Durabilidad
14387	Guantes Durabilidad
14388	Leotardos Durabilidad
14389	Hombreras Durabilidad
14390	Cinturón Durabilidad
14391	Espada Durabilidad
14392	Bastón Durabilidad
14393	Escudo Durabilidad
14394	Arco Durabilidad
14395	Hechizos de las Sombras
14396	Encantamientos desde el infierno
14397	Manto resistente
14398	Túnica resistente
14399	Botas resistentes
14400	Manteo resistente
14401	Cofia resistente
14402	Sortijas resistentes
14403	Manoplas resistentes
14404	Leotardos resistentes
14405	Toga resistente
14406	Cordón resistente
14407	Jubón de paño de piedra
14408	Botas de paño de piedra
14409	Manteo de paño de piedra
14410	Aro de paño de piedra
14411	Guantes de paño de piedra
14412	Insignias de paño de piedra
14413	Toga de paño de piedra
14414	Cinturón de paño de piedra
14415	Calzones de paño de piedra
14416	Ataduras de paño de piedra
14417	Túnica Sedarena
14418	Botas Sedarena
14419	Brazales Sedarena
14420	Manteo Sedarena
14421	Aro Sedarena
14422	Guantes Sedarena
14423	Hombreras Sedarena
14424	Ataduras Sedarena
14425	Brazaletes Sedarena
14426	Faja Sedarena
14427	Brazaletes Cazavientos
14428	Escarpines Cazavientos
14429	Puños Cazavientos
14430	Capa Cazavientos
14431	Manoplas Cazavientos
14432	Hombrera Cazavientos
14433	Cazavientos Prendas de lana
14434	Togas Cazavientos
14435	Cincho Cazavientos
14436	Corona Cazavientos
14437	Jubón sudario de veneno
14438	Botas sudario de veneno
14439	Guardabrazos sudario de veneno
14440	Manteo sudario de veneno
14441	Máscara sudario de veneno
14442	Mitones sudario de veneno
14443	Manto sudario de veneno
14444	Leotardos sudario de veneno
14445	Togas de seda sudario de veneno
14446	Cinturón sudario de veneno
14447	Escarpines de Altonato
14448	Pulseras de Altonato
14449	Corona de Altonato
14450	Capa de Altonato
14451	Guantes de Altonato
14452	Espaldares de Altonato
14453	Togas de Altonato
14454	Cordón de Altonato
14455	Armadura de Altonato acolchada
14456	Jubón elunarita
14457	Puños elunaritas
14458	Botas elunaritas
14459	Capa elunarita
14460	Diadema elunarita
14461	Manoplas elunaritas
14462	Pareo elunarita
14463	Bufas elunaritas
14464	Togas de seda elunaritas
14465	Cinturón elunarita
14466	Patrón: túnica Tejescarcha
14467	Patrón: toga Tejescarcha
14468	Patrón: bolsa de paño rúnico
14469	Patrón: toga de paño rúnico
14470	Patrón: túnica de paño rúnico
14471	Patrón: jubón de paño ceniza
14472	Patrón: capa de paño rúnico
14473	Patrón: cinturón Telafantasma
14474	Patrón: guantes Tejescarcha
14476	Patrón: guantes de paño ceniza
14477	Patrón: guantes Telafantasma
14478	Patrón: toga de paño brillante
14479	Patrón: guantes de paño brillante
14480	Patrón: jubón Telafantasma
14481	Patrón: guantes de paño rúnico
14482	Patrón: capa de paño ceniza
14483	Patrón: pantalones de tela de inferi
14484	Patrón: capa de paño brillante
14485	Patrón: leotardos de tejido zahorí
14486	Patrón: capa de Fuego
14487	Martillo hielahuesos
14488	Patrón: botas de paño rúnico
14489	Patrón: pantalones Tejescarcha
14490	Patrón: pantalones de paño ceniza
14491	Patrón: pantalones de paño rúnico
14492	Patrón: botas de tela de inferi
14493	Patrón: toga de Noche invernal
14494	Patrón: pantalones de paño brillante
14495	Patrón: pantalones Telafantasma
14496	Patrón: caperuza de tela de inferi
14497	Patrón: leotardos de tela lunar
14498	Patrón: cinta de paño rúnico
14499	Patrón: bolsa de tela lunar
14500	Patrón: toga de tejido zahorí
14501	Patrón: jubón de tela lunar
14502	Faja Bocado helado
14503	Garra de la Muerte
14504	Patrón: hombreras de paño rúnico
14505	Patrón: turbante de tejido zahorí
14506	Patrón: toga de tela de inferi
14507	Patrón: hombreras de tela lunar
14508	Patrón: hombreras de tela de inferi
14509	Patrón: aro de tela lunar
14510	Patrón: bolsa sin fondo
14511	Patrón: guantes de maestría de hechizos
14512	Patrón: vestimentas de fe verdadera
14513	Patrón: toga del Archimago
14514	Patrón: toga del Vacío
14522	Leotardos de Maelstrom
14523	Pico de demonio
14525	Guanteletes de huesos apretados
14526	Patrón: tela lunar
14528	Rodela armadósea
14529	Venda de paño rúnico
14530	Venda de paño rúnico pesada
14531	Bastón de Calamiedo
14536	Camisote con huesos
14537	Grebas de luz de cadáver
14538	Manto Caminamuerte
14539	Yelmo de hueso
14540	Corazón de Taragaman el Hambriento
14541	Espada de la familia Barovia
14542	Cajón de Kravel
14543	Guantes sombra oscura
14544	Insignia de Teniente
14545	Leotardos de fantasma
14546	Cuerno de kodo de Roon
14547	Mano de Iruxos
14548	Bufas reales
14549	Botas de evasión
14550	Guardabrazos aterraespadas
14551	Manoplas del Maestro de filos
14552	Espaldares de mazmorras
14553	Fajín de piedad
14554	Quijotes guardanubes
14555	Navaja solar de Alcor
14557	El cuerno de león de Ventormenta
14558	Colgante de Lady Maye
14559	Fajín de prospector
14560	Botas de prospector
14561	Puños de prospector
14562	Coraza de prospector
14563	Capa de prospector
14564	Mitones de prospector
14565	Prendas de lana de prospector
14566	Hombreras de prospector
14567	Cinturón Erizapúas
14568	Botas Erizapúas
14569	Ataduras Erizapúas
14570	Blusa Erizapúas
14571	Manteo Erizapúas
14572	Guantes Erizapúas
14573	Hombrera Erizapúas
14574	Calzones Erizapúas
14576	Empuñadura de ébano de Marduk
14577	Pantalones Humo de calavera
14578	Cordón Dokebi
14579	Botas Dokebi
14580	Brazales Dokebi
14581	Coraza Dokebi
14582	Manteo Dokebi
14583	Guantes Dokebi
14584	Sombrero Dokebi
14585	Leotardos Dokebi
14587	Manto Dokebi
14588	Cordón de ojo de halcón
14589	Zapatos de ojo de halcón
14590	Brazales de ojo de halcón
14591	Yelmo de ojo de halcón
14592	Túnica de ojo de halcón
14593	Capa de ojo de halcón
14594	Guantes de ojo de halcón
14595	Calzones de ojo de halcón
14596	Insignias de ojo de halcón
14598	Pretina de alcaide
14599	Escarpines de alcaide
14600	Muñequeras de alcaide
14601	Brazaletes de alcaide
14602	Capa de alcaide
14603	Manto de alcaide
14604	Sombrero zahorí de alcaide
14605	Prendas de lana del alcaide
14606	Guantes de alcaide
14607	Rodela de ojo de halcón
14608	Rodela Dokebi
14610	Escarabajo de Araj
14611	Camisote Mallasangre
14612	Musleras Mallasangre
14613	Martillo de Taelan
14614	Cinturón Mallasangre
14615	Guanteletes Mallasangre
14616	Botas Mallasangre
14617	Camisa de huesos segados
14619	Fragmentos esqueléticos
14620	Faja de hueso de muerto
14621	Escarpes de hueso de muerto
14622	Guanteletes de hueso de muerto
14623	Musleras de hueso de muerto
14624	Peto de hueso de muerto
14625	Símbolo de Honor perdido
14626	Toga necrópila
14627	Patrón: camisa amarillo brillante
14628	Fragmentos esqueléticos imbuidos
14629	Puños necrópilos
14630	Patrón: capucha de encantador
14631	Botas necrópilas
14632	Leotardos necrópilos
14633	Manto necrópilo
14634	Receta: aceite escarchado
14635	Patrón: cinturón de cuero con gemas incrustadas
14636	Cinturón de cadáver
14637	Armadura de cadáver
14638	Leotardos de cadáver
14639	Esquema: recombobulador menor
14640	Guantes de cadáver
14641	Botos de cadáver
14644	Molde de llave esqueleto
14645	Llave de esqueleto sin terminar
14646	Vale regalo de Crestanorte
14647	Vale regalo del Valle Cretanevada
14648	Vale regalo de Cañada Umbría
14649	Vale regalo del Valle de las Pruebas
14650	Vale regalo del campamento Narache
14651	Vale de Camposanto
14652	Fajín Scorpashi
14653	Zapatillas Scorpashi
14654	Muñequeras Scorpashi
14655	Peto Scorpashi
14656	Manteo Scorpashi
14657	Guantes Scorpashi
14658	Capacete Scorpashi
14659	Leotardos Scorpashi
14660	Hombreras Scorpashi
14661	Cordón de vigilante
14662	Pezuñas de vigilante
14663	Ataduras de vigilante
14664	Armadura de vigilante
14665	Capa de vigilante
14666	Guantes de vigilante
14667	Corona de vigilante
14668	Prendas de lana de vigilante
14669	Manto de vigilante
14670	Armadura de Señor Orgulloso
14671	Botas de Señor Orgulloso
14672	Sortijas de Señor Orgulloso
14673	Manteo de Señor Orgulloso
14674	Faja de Señor Orgulloso
14675	Guantes de Señor Orgulloso
14676	Halo de Señor Orgulloso
14677	Pantalones de Señor Orgulloso
14678	Espaldares de Señor Orgulloso
14679	Del amor y la familia
14680	Jubón de indómito
14681	Botas de indómito
14682	Guardabrazos de indómito
14683	Capa de indómito
14684	Cinturón de indómito
14685	Guanteletes de indómito
14686	Penacho de indómito
14687	Leotardos de indómito
14688	Insignias de indómito
14722	Tobilleras pintura de guerra
14723	Ataduras pintura de guerra
14724	Capa pintura de guerra
14725	Pretina pintura de guerra
14726	Guantes pintura de guerra
14727	Musleras pintura de guerra
14728	Hombreras pintura de guerra
14729	Escudo pintura de guerra
14730	Coraza pintura de guerra
14742	Botas descomunales
14743	Sortijas descomunales
14744	Coraza descomunal
14745	Capa descomunal
14746	Cinturón descomunal
14747	Guanteletes descomunales
14748	Leotardos descomunales
14749	Bufas descomunales
14750	Puños de destripador
14751	Sobretodo de destripador
14752	Manteo de destripador
14753	Capacete de destripador
14754	Guantes de destripador
14755	Fajín de destripador
14756	Zapatillas de destripador
14757	Pantalones de destripador
14758	Hombreras de destripador
14759	Brazales duraderos
14760	Peto duradero
14761	Cinturón duradero
14762	Botas duraderas
14763	Manteo duradero
14764	Guanteletes duraderos
14765	Aro duradero
14766	Calzones duraderos
14767	Espaldares duraderos
14768	Armadura de devastador
14769	Sandalias de devastador
14770	Guardabrazos de devastador
14771	Capa de devastador
14772	Mitones de devastador
14773	Cordón de devastador
14774	Corona de devastador
14775	Prendas de lana de devastador
14776	Manto de devastador
14777	Escudo de devastador
14778	Ataduras de kan
14779	Coraza de kan
14780	Rodela de kan
14781	Capa de kan
14782	Guantes de kan
14783	Cinturón de kan
14784	Grebas de kan
14785	Casco de kan
14786	Musleras de kan
14787	Manto de kan
14788	Guardabrazos protectores
14789	Peto protector
14790	Rodela protectora
14791	Manteo protector
14792	Guanteletes protectores
14793	Pretina protectora
14794	Guardatobillos
14795	Yelmo protector
14796	Musleras protectoras
14797	Almohadillas protectoras
14798	Peto Ansia de Sangre
14799	Botas Ansia de Sangre
14800	Rodela Ansia de Sangre
14801	Manteo Ansia de Sangre
14802	Guanteletes Ansia de Sangre
14803	Cinturón Ansia de Sangre
14804	Yelmo Ansia de Sangre
14805	Calzones Ansia de Sangre
14806	Insignias Ansia de Sangre
14807	Pulseras Ansia de Sangre
14808	Cinturón Golpe de Guerra
14809	Escarpes Golpe de Guerra
14810	Braquiales Golpe de Guerra
14811	Coraza Golpe de Guerra
14812	Rodela Golpe de Guerra
14813	Manteo Golpe de Guerra
14814	Casco Golpe de Guerra
14815	Guanteletes Golpe de Guerra
14816	Musleras Golpe de Guerra
14817	Hombreras Golpe de Guerra
14821	Peto simbólico
14825	Emblema simbólico
14826	Guanteletes simbólicos
14827	Cinturón simbólico
14828	Grebas simbólicas
14829	Quijotes simbólicos
14830	Espaldares simbólicos
14831	Corona simbólica
14832	Protegebrazos simbólicos
14833	Guanteletes de tirano
14834	Guardabrazos de tirano
14835	Coraza de tirano
14838	Cinturón de tirano
14839	Grebas de tirano
14840	Quijotes de tirano
14841	Insignias de tirano
14842	Escudo de tirano
14843	Yelmo de tirano
14844	Coraza de solescama
14846	Guanteletes de solescama
14847	Cinturón de solescama
14848	Escarpes de solescama
14849	Casco de solescama
14850	Quijotes de solescama
14851	Bufas de solescama
14852	Escudo de solescama
14853	Muñequeras de solescama
14854	Peto soldado de caballería
14855	Guanteletes soldado de caballería
14856	Faja soldado de caballería
14857	Escarpes soldado de caballería
14858	Penacho soldado de caballería
14859	Quijotes soldado de caballería
14860	Espaldares soldado de caballería
14861	Protegebrazos soldado de caballería
14862	Peto de Líder de guerra
14863	Guanteletes de Líder de guerra
14864	Cinturón de Líder de guerra
14865	Grebas de Líder de guerra
14866	Corona de Líder de guerra
14867	Leotardos de Líder de guerra
14868	Hombreras de Líder de guerra
14869	Brazales de Líder de guerra
14872	Obsequio de Tirion
14894	Raíz lila
14895	Sobretodo Piedra de sal
14896	Escarpes Piedra de sal
14897	Guanteletes Piedra de sal
14898	Faja Piedra de sal
14899	Yelmo Piedra de sal
14900	Quijotes Piedra de sal
14901	Hombreras Piedra de sal
14902	Escudo Piedra de sal
14903	Braquiales Piedra de sal
14904	Peto tosco
14905	Guanteletes toscos
14906	Cinturón tosco
14907	Casco tosco
14908	Musleras toscas
14909	Hombreras toscas
14910	Guardabrazos tosco
14911	Botas toscas
14912	Escudo tosco
14913	Grebas de jade
14914	Brazales de jade
14915	Peto de jade
14916	Deflector de jade
14917	Guanteletes de jade
14918	Cinturón de jade
14919	Aro de jade
14920	Quijotes de jade
14921	Insignias de jade
14922	Escarpes magnánimos
14923	Guardabrazos magnánimos
14924	Peto magnánimo
14925	Yelmo magnánimo
14926	Guanteletes magnánimos
14927	Cinturón magnánimo
14928	Musleras magnánimas
14929	Hombreras magnánimas
14930	Escudo magnánimo
14931	Armadura heroica
14932	Grebas heroicas
14933	Guanteletes heroicos
14934	Faja heroica
14935	Capacete heroico
14936	Quijotes heroicos
14937	Espaldares heroicos
14938	Brazales heroicos
14939	Coraza de belisario
14940	Escarpes de belisario
14941	Braquiales de belisario
14942	Guanteletes de belisario
14943	Cinturón de belisario
14944	Corona de belisario
14945	Musleras de belisario
14946	Bufas de belisario
14947	Escudo de belisario
14948	Coraza forjada con sangre
14949	Guanteletes forjados con sangre
14950	Cinturón forjado con sangre
14951	Escarpes forjados con sangre
14952	Casco forjado con sangre
14953	Quijotes forjados con sangre
14954	Escudo forjado con sangre
14955	Hombreras forjadas con sangre
14956	Ataduras forjadas con sangre
14957	Escarpes de Gran Jefe
14958	Armadura de Gran Jefe
14959	Guanteletes de Gran Jefe
14960	Cinturón de Gran Jefe
14961	Corona de Gran Jefe
14962	Musleras de Gran Jefe
14963	Espaldares e Gran Jefe
14964	Escudo de Gran Jefe
14965	Ataduras de Gran Jefe
14966	Peto glorioso
14967	Guanteletes gloriosos
14968	Cinturón glorioso
14969	Penacho glorioso
14970	Quijotes gloriosos
14971	Hombros gloriosos
14972	Escarpes gloriosos
14973	Escudo glorioso
14974	Ataduras gloriosas
14975	Arnés exaltado
14976	Guanteletes exaltados
14977	Faja exaltada
14978	Escarpes exaltados
14979	Casco exaltado
14980	Quijotes exaltados
14981	Insignias exaltadas
14982	Escudo exaltado
14983	Braquiales exaltados
15002	Pico de Nimboya
15003	Cinturón primigenio
15004	Botas primigenias
15005	Sortijas primigenias
15006	Rodela primigenia
15007	Manteo primigenio
15008	Mitones primigenios
15009	Leotardos primigenios
15010	Brazaletes primigenios
15011	Cordón lupino
15012	Zapatillas lupinas
15013	Puños lupinos
15014	Rodela lupina
15015	Capa lupina
15016	Mitones lupinos
15017	Leotardos lupinos
15018	Jubón lupino
15019	Manto lupino
15042	Jarra de termitas vacía
15043	Termitas de las Tierras de la Peste
15044	Barril de termitas de las Tierras de la Peste
15045	Peto de escamas de dragón verde
15046	Leotardos de escamas de dragón verde
15047	Peto de escamas de dragón rojo
15048	Peto de escamas de dragón azul
15049	Hombreras de escamas de dragón azul
15050	Peto de escamas de dragón negro
15051	Hombreras de escamas de dragón negro
15052	Leotardos de escamas de dragón negro
15053	Peto volcánico
15054	Leotardos volcánicos
15055	Hombreras volcánicas
15056	Armadura Velotormenta
15057	Pantalones Velotormenta
15058	Hombreras Velotormenta
15059	Peto vivo
15060	Leotardos vivos
15061	Hombreras vivas
15062	Leotardos de demosaurio
15063	Guanteletes de demosaurio
15064	Arnés de oso de guerra
15065	Prendas de lana de oso de guerra
15066	Peto Plumahierro
15067	Hombreras Plumahierro
15068	Túnica Sable de Hielo
15069	Leotardos Sable de Hielo
15070	Guantes Sable de Hielo
15071	Botas Sable de Hielo
15072	Leotardos quiméricos
15073	Botas quiméricas
15074	Guantes quiméricos
15075	Jubón quimérico
15076	Jubón de escórpido pesado
15077	Brazales de escórpido pesado
15078	Guanteletes de escórpido pesado
15079	Leotardos de escórpido pesado
15080	Yelmo de escórpido pesado
15081	Hombreras de escórpido pesado
15082	Cinturón de escórpido pesado
15083	Guanteletes de cuero maligno
15084	Brazales de cuero maligno
15085	Armadura de cuero maligno
15086	Cinta de cuero maligno
15087	Pantalones de cuero maligno
15088	Cinturón de cuero maligno
15090	Armadura de cuero rúnico
15091	Guanteletes de cuero rúnico
15092	Brazales de cuero rúnico
15093	Cinturón de cuero rúnico
15094	Cinta de cuero rúnico
15095	Pantalones de cuero rúnico
15096	Hombreras de cuero rúnico
15102	Muestra probada de Un'Goro
15103	Muestra examinada corrupta
15104	Botas portalas
15105	Bastón de Noh'Orahil
15106	Bastón de Dar'Orahil
15107	Orbe de Noh'Orahil
15108	Orbe de Dar'Orahil
15109	Bastón de Soran'ruk
15110	Cinturón rígido
15111	Mocasines rígidos
15112	Pulseras rígidas
15113	Rodela rígida
15114	Manteo rígido
15115	Guantes rígidos
15116	Hombreras rígidas
15117	Leotardos rígidos
15118	Túnica rígida
15119	Pantalones de Altonato
15120	Faja robusta
15121	Botas robustas
15122	Brazales robustos
15123	Rodela robusta
15124	Capa robusta
15125	Guantes robustos
15126	Leotardos robustos
15127	Hombreras robustas
15128	Túnica robusta
15129	Yelmo robusto
15130	Jubón de degollador
15131	Botas de degollador
15132	Guardabrazos de degollador
15133	Rodela de degollador
15134	Sombrero de degollador
15135	Manteo de degollador
15136	Cinturón de degollador
15137	Mitones de degollador
15138	Capa de escamas de Onyxia
15139	Pantalones de degollador
15140	Manto de degollador
15141	Peto de escamas de Onyxia
15142	Botas Pie fantasmal
15143	Ataduras Pie fantasmal
15144	Harapos Pie fantasmal
15145	Rodela Pie fantasmal
15146	Corona Pie fantasmal
15147	Capa Pie fantasmal
15148	Cinturón Pie fantasmal
15149	Guantes Pie fantasmal
15150	Refuerzo Pie fantasmal
15151	Musleras Pie fantasmal
15152	Zapatos nocturnos
15153	Capa nocturna
15154	Fajín nocturno
15155	Guantes nocturnos
15156	Almete nocturno
15157	Leotardos nocturnos
15158	Hombreras nocturnas
15159	Túnica nocturna
15160	Muñequeras nocturnas
15161	Cinturón imponente
15162	Botas imponentes
15163	Brazales imponentes
15164	Jubón imponente
15165	Manto imponente
15166	Guantes imponentes
15167	Pañuelo imponente
15168	Pantalones imponentes
15169	Hombreras imponentes
15170	Armadura pujante
15171	Botas pujantes
15172	Sortijas pujantes
15173	Manteo pujante
15174	Guantes pujantes
15175	Casco pujante
15176	Pantalones pujantes
15177	Hombreras pujantes
15178	Cinturón pujante
15179	Armadura acolchada pretoriana
15180	Faja de pretoriano
15181	Botas de pretoriano
15182	Muñequeras pretorianas
15183	Capa de pretoriano
15184	Guantes de pretoriano
15185	Almófar de pretoriano
15186	Leotardos de pretoriano
15187	Espaldares pretorianos
15188	Guardabrazos grandiosos
15189	Botas grandiosas
15190	Capa grandiosa
15191	Cinturón grandioso
15192	Guanteletes grandiosos
15193	Corona grandiosa
15194	Musleras grandiosas
15195	Peto grandioso
15196	Tabardo de soldado
15197	Tabardo de explorador
15198	Colores de caballero
15199	Heraldo de guardia de piedra
15200	Insignia de capataz primero
15202	Leotardos de protector salvaje
15203	Musleras de tormenta de entrañas
15204	Varita de piedra lunar
15205	Rifle con vista de búho
15206	Batuta de fuego de jade
15207	Escudo de acero
15208	Polvo lunar Cenarion
15209	Fajo de reliquias
15210	Espada corta de asaltante
15211	Espada corta de militante
15212	Sable de luchador
15213	Hoja de mercenario
15214	Prenda de noble
15215	Bracamarte furioso
15216	Runaespada
15217	Espada de viuda
15218	Espada de cristal
15219	Hoja dimensional
15220	Sable de Belivil
15221	Espada de guerra sagrada
15222	Garrote con púas
15223	Estrella dentada
15224	Machacabatallas
15225	Martillo de secuoya
15226	Garrote gigante
15227	Cachiporra con punta de diamante
15228	Meteorito mortal
15229	Martillo Ventobendito
15230	Cuchilla de peña
15231	Hachuela seccionadora
15232	Cuchilla para picar
15233	Hacha indómita
15234	Guadaña superior
15235	Filo creciente
15236	Cuchilla de la Luna
15237	Cadáver de cosechador
15238	Hacha de Señor de la Guerra
15239	Atracador de piedras máculas
15240	Garra de demonio
15241	Cuchillo de batalla
15242	Estilete afilado
15243	Puñal hindú mortal
15244	Hoja de cuchilla
15245	Daga vorpal
15246	Hoja de demonio
15247	Daga de golpe de sangre
15248	Espada claymore reluciente
15249	Montante pulido
15250	Flamberge de luz trémula
15251	Espada Golpecabeza
15252	Espada con colmillo
15253	Hoja decapitadora
15254	Mandoble oscuro
15255	Flamberge de galante
15256	Espada de masacre
15257	Hoja espinilla
15258	Hoja de guerra divina
15259	Martillo de batalla pesado
15260	Martillo de piedra
15261	Rama de secuoya
15262	Gran maza superior
15263	Marra real
15264	Partedorsales
15265	Castigador
15266	Destructor fiero
15267	Martillobruto
15268	Hacha de dos filos
15269	Hacha de batalla maciza
15270	Hacha de Guerra gigante
15271	Gran hacha colosal
15272	Hacha cuchilla
15273	Golpeamuerte
15274	Bastón largo de adivino
15275	Bastón de taumaturgo
15276	Bastón largo de mago
15277	Kodo gris
15278	Bastón de solsticio
15279	Varita de marfil
15280	Mano de zahorí
15281	Vara Resplandor astral
15282	Dedo de dragón
15283	Varita lunar
15284	Arco de batalla largo
15285	Arco largo de arquero
15286	Arco largo de madera roja
15287	Arco de cruzado
15288	Arco tiroespina
15289	Arco Arcogolpe
15290	Kodo marrón
15291	Taladro de arpía
15292	Kodo verde
15293	Teal Kodo
15294	Arco de asedio
15295	Arco de fuego de pinchos
15296	Arco de ojo de halcón
15297	Brazales de grisezno
15298	Rodela de grisezno
15299	Manteo de grisezno
15300	Guantes griseznos
15301	Zapatillas griseznas
15302	Cinturón de grisezno
15303	Pantalones griseznos
15304	Chaleco griseznos
15305	Zapatos ferales
15306	Ataduras ferales
15307	Rodela feral
15308	Cordón feral
15309	Capa feral
15310	Guantes ferales
15311	Arnés feral
15312	Leotardos ferales
15313	Hombreras ferales
15314	Montón de reliquias
15322	Pistola de ánima lisa
15323	Pistola de percusión
15324	Rifle quemado
15325	Arcabuz certero
15326	Hacha arrojadiza reluciente
15327	Daga arrojadiza maligna
15328	Llave de Joseph
15329	Cinturón de vaquero
15330	Botas de vaquero
15331	Muñequeras de vaquero
15332	Rodela de vaquero
15333	Capa de vaquero
15334	Guantes de vaquero
15335	Espada corta de acero brezo
15336	Leotardos de vaquero
15337	Brazaletes de vaquero
15338	Manto de vaquero
15339	Sombrero de abrecaminos
15340	Capa de abrecaminos
15341	Escarpines de abrecaminos
15342	Integumento de abrecaminos
15343	Guantes de abrecaminos
15344	Pantalones de abrecaminos
15345	Hombreras de abrecaminos
15346	Jubón de abrecaminos
15347	Cinturón de abrecaminos
15348	Brazales de abrecaminos
15349	Cinturón de cazador de cabezas
15350	Zapatillas de cazador de cabezas
15351	Sortijas de cazador de cabezas
15352	Rodela de cazador de cabezas
15353	Penacho de cazador de cabezas
15354	Capa de cazador de cabezas
15355	Mitones de cazador de cabezas
15356	Armadura de cazador de cabezas
15357	Bufas de cazador de cabezas
15358	Prendas de lana
15359	Jubón de timador
15360	Ataduras de timador
15361	Fajín de timador
15362	Botas de timador
15363	Penacho de timador
15364	Capa de timador
15365	Mitones de timador
15366	Leotardos de timador
15367	Protector de timador
15368	Espaldares de timador
15369	Cinturón de Caballero Lobo
15370	Botas de Caballero Lobo
15371	Capa de Caballero Lobo
15372	Guantes de Caballero Lobo
15373	Casco de Caballero Lobo
15374	Leotardos de Caballero Lobo
15375	Hombreras de Caballero Lobo
15376	Armadura acolchada de Caballero Lobo
15377	Muñequeras de Caballero Lobo
15378	Cinturón Garrira
15379	Botas Garrira
15380	Brazales Garrira
15381	Coraza Garrira
15382	Capa Garrira
15383	Guantes Garrira
15384	Yelmo Garrira
15385	Leotardos Garrira
15386	Hombreras Garrira
15387	Pulseras de fuego de jade
15388	Cinturón de fuego de jade
15389	Escarpes de fuego de jade
15390	Coraza de fuego de jade
15391	Almete de fuego de jade
15392	Capa de fuego de jade
15393	Guantes de fuego de jade
15394	Pantalones de fuego de jade
15395	Insignias de fuego de jade
15396	Daga de madera curva
15397	Bastón de roble
15398	Botas de Peinarenas
15399	Cinturón de algas secas
15400	Brazales de concha de almeja
15401	Guantes de gota de pozo
15402	Guanteletes de Noosegrip
15403	Brazales Cresta
15404	Faja arrecife
15405	Guantes de criba
15406	Botas crustáceo
15407	Pellejo basto curado
15408	Escama de escórpido pesado
15409	Sal de roca refinada
15410	Escama de Onyxia
15411	Marca de Fordring
15412	Escamas de dragón verde
15413	Peto de adamantio ornamentado
15414	Escamas de dragón rojo
15415	Escamas de dragón azul
15416	Escamas de dragón negro
15417	Cuero de demosaurio
15418	Martillo de guerra de platino fulgurante
15419	Cuero de oso de guerra
15420	Plumahierro
15421	Sudario del Exilio
15422	Cuero Sable de Hielo
15423	Cuero quimérico
15424	Hacha de Orgrimmar
15425	Brazales incomparables
15426	Botas incomparables
15427	Capa incomparable
15428	Cinturón incomparable
15429	Guantes incomparables
15430	Cinta incomparable
15431	Leotardos incomparables
15432	Hombreras incomparables
15433	Armadura incomparable
15434	Fajín supremo
15435	Zapatos supremos
15436	Brazales supremos
15437	Manteo supremo
15438	Guantes supremos
15439	Corona suprema
15440	Leotardos supremos
15441	Hombreras supremas
15442	Peto supremo
15443	Puñal hindú de Orgrimmar
15444	Bastón de Orgrimmar
15445	Martillo de Orgrimmar
15446	Juego de diputado de Ventormenta
15447	Caña viva
15448	Putrefacción coagulada
15449	Pantalones espantosos
15450	Leotardos de cenagal
15451	Leotardos gárgola
15452	Brazales de cuentas emplumadas
15453	Brazales de sabana
15454	Mano y almirez
15455	Togas guardapolvo
15456	Leotardos de paso ligero
15457	Hombreras del desierto
15458	Botas tundra
15459	Muñequeras tañido rictus
15461	Botas con tacón ligero
15462	Brazales de marga
15463	Guantes de zancudo pálido
15464	Martillo bruto
15465	Varita de picadura
15466	Escudo tintineante
15467	Anillo de la Liga de los Inventores
15468	Mantón Canzalvaje
15469	Cincho Canzalvaje
15470	Leotardos de guardia de las llanuras
15471	Armadura pellejomúsculo
15472	Cinturón de cargador
15473	Botas de cargador
15474	Ataduras de cargador
15475	Capa de cargador
15476	Mitones de cargador
15477	Pantalones de cargador
15478	Escudo de cargador
15479	Armadura de cargador
15480	Restos de faja
15481	Restos de grebas
15482	Restos de sortijas
15483	Restos de manteo
15484	Restos de manoplas
15485	Restos de pantalones
15486	Restos de escudo
15487	Restos de túnica
15488	Sobretodo salpicado de sangre
15489	Escarpes salpicados de sangre
15490	Capa salpicada de sangre
15491	Guantes salpicados de sangre
15492	Fajín salpicado de sangre
15493	Taparrabos salpicado de sangre
15494	Escudo salpicado de sangre
15495	Muñequeras salpicadas de sangre
15496	Hombreras salpicadas de sangre
15497	Cordón de avanzado
15498	Zapatillas de avanzado
15499	Puños de avanzado
15500	Coraza de avanzado
15501	Capa de avanzado
15502	Guantes de avanzado
15503	Musleras de avanzado
15504	Escudo de avanzado
15505	Espaldares de avanzado
15506	Tobilleras de bruto
15507	Brazales de bruto
15508	Manteo de bruto
15509	Mitones de bruto
15510	Cinturón de bruto
15511	Musleras de bruto
15512	Escudo de bruto
15513	Espaldares de bruto
15514	Coraza de bruto
15515	Cinturón de anillas con pinchos
15516	Zapatillas de anillas con pinchos
15517	Muñequeras de anillas con pinchos
15518	Peto de anillas con pinchos
15519	Capa de anillas con pinchos
15520	Guanteletes de anillas con pinchos
15521	Leotardos de anillas con pinchos
15522	Escudo de anillas con pinchos
15523	Hombreras de anillas con pinchos
15524	Sobretodo de avizor
15525	Zapatillas de avizor
15526	Manteo de avizor
15527	Guantes de avizor
15528	Fajín de avizor
15529	Leotardos de avizor
15530	Escudo de avizor
15531	Hombreras de avizor
15532	Braquiales de avizor
15533	Penacho de avizor
15534	Botas de anillas malignas
15535	Brazales de anillas malignos
15536	Coraza de anillas maligna
15537	Capa de anillas maligna
15538	Guanteletes de anillas malignos
15539	Pretina de anillas maligna
15540	Casco de anillas maligno
15541	Musleras de anillas malignas
15542	Hombreras de anillas malignas
15543	Escudo de anillas maligno
15544	Escarpes de escamas gruesas
15545	Pulseras de escamas gruesas
15546	Peto de escamas gruesas
15547	Capa de escamas gruesas
15548	Guanteletes de escamas gruesas
15549	Cinturón de escama gruesa
15550	Corona de escamas gruesas
15551	Musleras de escamas gruesas
15552	Escudo de escamas gruesas
15553	Hombreras de escamas gruesas
15554	Faja de saqueador
15555	Botas de saqueador
15556	Brazales de saqueador
15557	Coraza de saqueador
15558	Corona de saqueador
15559	Capa de saqueador
15560	Guantes de saqueador
15561	Leotardos de saqueador
15562	Espaldares de saqueador
15563	Escudo de saqueador
15564	Complemento basto para armadura
15565	Botas de maleante
15566	Brazales de maleante
15567	Túnica de maleante
15568	Capa de maleante
15569	Emblema de maleante
15570	Guanteletes de maleante
15571	Cinturón de maleante
15572	Aro de maleante
15573	Leotardos de maleante
15574	Hombreras de maleante
15575	Cinturón de conchas brillantes
15576	Escarpes de conchas brillantes
15577	Brazales de conchas brillantes
15578	Peto de conchas brillantes
15579	Capa de conchas brillantes
15580	Felpa de conchas brillantes
15581	Guanteletes de conchas brillantes
15582	Musleras de conchas brillantes
15583	Hombreras de conchas brillantes
15584	Escudo de conchas brillantes
15585	Mandiletes Pardoc
15586	Flor de rápido crecimiento
15587	Faja Colaro
15588	Cinturón con brazales de acero
15589	Vapuleadores de determinación férrea
15590	Pulseras de determinación férrea
15591	Peto de determinación férrea
15592	Rodela de determinación férrea
15593	Corona de determinación férrea
15594	Capa de determinación férrea
15595	Guantes de determinación férrea
15596	Quijotes de determinación férrea
15597	Hombreras de determinación férrea
15598	Faja de determinación férrea
15599	Grebas antiguas
15600	Protegebrazos antiguos
15601	Coraza antigua
15602	Corona antigua
15603	Capa antigua
15604	Defensor antiguo
15605	Guanteletes antiguos
15606	Cinturón antiguo
15607	Musleras antiguas
15608	Espaldares antiguos
15609	Armadura de vínculo de huesos
15610	Brazales de vínculo de huesos
15611	Manteo de vínculo de huesos
15612	Guanteletes de vínculo de huesos
15613	Cinturón de vínculo de huesos
15614	Escarpes de vínculo de huesos
15615	Casco de vínculo de huesos
15616	Quijotes de vínculo de huesos
15617	Insignias de vínculo de huesos
15618	Escudo de pared de vínculo de huesos
15619	Cinturón de malla de grifo
15620	Pulseras de malla de grifo
15621	Rodela de malla de grifo
15622	Peto de malla de grifo
15623	Corona de malla de grifo
15624	Capa de grifo
15625	Guanteletes de malla de grifo
15626	Grebas de malla de grifo
15627	Musleras de malla de grifo
15628	Espaldares de malla de grifo
15629	Brazales formidables
15630	Escarpes formidables
15631	Coraza formidable
15632	Manteo formidable
15633	Emblema formidable
15634	Aro formidable
15635	Guanteletes formidables
15636	Cinturón formidable
15637	Musleras formidables
15638	Hombreras formidables
15639	Brazales de pielférrea
15640	Peto de pielférrea
15641	Cinturón de pielférrea
15642	Grebas de pielférrea
15643	Capa de pielférrea
15644	Guanteletes de pielférrea
15645	Casco de pielférrea
15646	Musleras de pielférrea
15647	Espaldares de pielférrea
15648	Escudo de pielférrea
15649	Brazales despiadados
15650	Sobretodo despiadado
15651	Corona despiadada
15652	Capa despiadada
15653	Guanteletes despiadados
15654	Cinturón despiadado
15655	Musleras despiadadas
15656	Insignias despiadadas
15657	Escudo despiadado
15658	Escarpes impenetrables
15659	Ataduras impenetrables
15660	Peto impenetrable
15661	Capa impenetrable
15662	Guanteletes impenetrables
15663	Cinturón impenetrable
15664	Casco impenetrable
15665	Musleras impenetrables
15666	Espaldares impenetrables
15667	Muro impenetrable
15668	Brazales magníficos
15669	Peto magnífico
15670	Casco magnífico
15671	Capa magnífica
15672	Guanteletes magníficos
15673	Cinturón magnífico
15674	Grebas magníficas
15675	Guardia magnífico
15676	Leotardos magníficos
15677	Hombreras magníficas
15678	Escarpes triunfantes
15679	Brazales triunfantes
15680	Coraza triunfante
15681	Capa triunfante
15682	Guanteletes triunfantes
15683	Faja triunfante
15684	Capacete triunfante
15685	Quijotes triunfantes
15686	Hombreras triunfantes
15687	Escudo triunfante
15688	Judías mágicas
15689	Anillo de comerciante
15690	Collar de huesos de kodo
15691	Pistolero Shottie
15692	Marcador de kodos
15693	Hombreras espléndidas
15694	Grebas despiadadas
15695	Escudo circular con tachuelas
15696	Escrito estropeado
15697	Botas de ladrón kodo
15698	Bufas de riña
15699	Paquete con envoltorio marrón pequeño
15702	Anillo de químico
15703	Bata de químico
15704	Medalla insignia de cazador
15705	Espada Crestamarea
15706	Hoja de rastreador de caza
15707	Fajín Barnaleño
15708	Guantes de cuero infestados
15709	Faja de Gearforge
15710	Polvo lunar Cenarion
15722	Cantimplora de Spraggle
15723	Té con azúcar
15724	Patrón: brazales de escórpido pesado
15725	Patrón: guanteletes de cuero maligno
15726	Patrón: peto de escamas de dragón verde
15727	Patrón: jubón de escórpido pesado
15728	Patrón: brazales de cuero maligno
15729	Patrón: guantes quiméricos
15730	Patrón: peto de escamas de dragón rojo
15731	Patrón: guanteletes de cuero rúnico
15732	Patrón: leotardos volcánicos
15733	Patrón: leotardos de escamas de dragón verde
15734	Patrón: hombreras vivas
15735	Patrón: hombreras Plumahierro
15736	Complejo especial de Smokey
15737	Patrón: botas quiméricas
15738	Patrón: guanteletes de escórpido pesado
15739	Patrón: brazales de cuero rúnico
15740	Patrón: botas Sable de Hielo
15741	Patrón: pantalones Velotormenta
15742	Patrón: arnés de oso de guerra
15743	Patrón: cinturón de escórpido pesado
15744	Patrón: cinta de cuero maligno
15745	Patrón: cinturón de cuero rúnico
15746	Patrón: leotardos quiméricos
15747	Patrón: leotardos Sable de Hielo
15748	Patrón: leotardos de escórpido pesado
15749	Patrón: peto volcánico
15750	Cetro de Luz
15751	Patrón: peto de escamas de dragón azul
15752	Patrón: leotardos vivos
15753	Patrón: armadura Velotormenta
15754	Patrón: prendas de lana de oso de guerra
15755	Patrón: jubón quimérico
15756	Patrón: cinta de cuero rúnico
15757	Patrón: pantalones de cuero maligno
15758	Patrón: guanteletes de demosaurio
15759	Patrón: peto de escamas de dragón negro
15760	Patrón: peto Plumahierro
15761	Patrón: guantes Sable de Hielo
15762	Patrón: yelmo de escórpido pesado
15763	Patrón: hombreras de escamas de dragón azul
15764	Patrón: hombreras Velotormenta
15765	Patrón: pantalones de cuero rúnico
15766	Gema de la Serpiente
15767	Llave de Hameya
15768	Patrón: cinturón de cuero maligno
15769	Patrón: capa de escamas de Onyxia
15770	Patrón: hombreras de escamas de dragón negro
15771	Patrón: peto vivo
15772	Patrón: leotardos de demosaurio
15773	Patrón: armadura de cuero maligno
15774	Patrón: hombreras de escórpido pesado
15775	Patrón: hombreras volcánicas
15776	Patrón: armadura de cuero rúnico
15777	Patrón: hombreras de cuero rúnico
15778	Yeti mecánico
15779	Patrón: túnica Sable de Hielo
15780	Patrón: peto de escamas de Onyxia
15781	Patrón: leotardos de escamas de dragón negro
15782	Hoja de acechabestias
15783	Daga cazabestias
15784	Manto de brisa de cristal
15785	Cabeza de Zaeldarr
15786	Chaleco Pulso helecho
15787	Camisote a rayas de sauce
15788	Informe de Vista Eterna
15789	Capa río profundo
15790	Estudios de Conversación con los espíritus
15791	Fajín turquesa
15792	Bufas de madera surcada
15793	Un hueso roído
15794	Taparrabos rasgado ogro
15795	Guanteletes de bruma Esmeralda
15796	Brazales de espuma marina
15797	Placas lustrosas
15798	Diente de ogro astillado
15799	Medalla de honor heroico
15800	Espada corta de intrépido
15801	Espada corta valerosa
15802	Botas de tela lunar
15803	Libro sobre los Antiguos
15804	Mantón color guinda
15805	Rosa de Penelope
15806	Canción de Mirah
15807	Ballesta ligera
15808	Ballesta ligera refinada
15809	Ballesta pesada
15810	Lanza corta
15811	Lanza pesada
15812	Hombrera orquídea
15813	Cinturón de oro
15814	Destripador de Hameya
15815	Capa de Hameya
15822	Bufas sombradermas
15823	Guanteletes ladrillo de acero
15824	Togas de Astoria
15825	Chaleco de calador
15826	Bálsamo animal sanador
15827	Peto de Luna de jade
15842	Muestra de Cima Calígine vacía
15843	Muestrario de Cima Calígine lleno
15844	Muestra vacía de Salto de Fonroca
15845	Muestrario del Salto de Fonroca lleno
15846	Salero
15847	Registro de Quel'Thalas
15848	Cajón de imanes fantasmales
15849	Ectoplasma
15850	Parche de pelaje de alatardecer
15851	Seta lunar
15852	Cuerno de kodo
15853	Segadora de viento
15854	Plata de danza
15855	Anillo de Protección
15856	Talismán Arcoluz
15857	Vástago aterramagos
15858	Guantes viento libre
15859	Faja de poste marino
15860	Guardabrazos Golpeguiño
15861	Botines Pieveloz
15862	Cuchilla de carga
15863	Cetro solemne
15864	Brazales de cóndor
15865	Rodela garrancla
15866	Bolsa de remedio polvo de velo
15867	Talismán prismático
15868	Orden del Gran Cruzado
15869	Llave esqueleto de plata
15870	Llave esqueleto de oro
15871	Llave esqueleto de veraplata
15872	Llave esqueleto de arcanita
15873	Copa interminable de John Andrajoso
15874	Almeja de forma ovalada
15875	Manzana podrida
15876	Cofre de Nathanos
15877	Adorno de altar
15878	Llave de plata Rackmore
15879	Garra de Señor Supremo Ror
15880	Cabeza de Ramstein el Glotón
15881	Llave de oro de Rackmore
15882	Medio colgante de Buceo
15883	Medio colgante de Natación
15884	Libro de cocina de Augustus
15885	Colgante del León Marino
15886	Filacteria de Timolain
15887	Integumento heroico
15890	Escudo soldado de caballería
15891	Escudo descomunal
15892	Escudo de destripador
15893	Rodela de prospector
15894	Rodela Erizapúas
15895	Rodela quemada
15902	Una bolsa de sorpresas
15903	Garra de diestro
15904	Hojas de diestros
15905	Huesos de metal de diestros
15906	Nudillos de latón para la mano izquierda
15907	Garra para la mano izquierda
15908	Fusta de domador
15909	Hojas para la mano izquierda
15911	Fusta de domador
15912	Orbe de bucanero
15913	Fusta de domador
15914	Fusta de domador
15915	Fusta de domador
15916	Fusta de domador
15917	Fusta de domador
15918	Esfera de implorador
15919	Fusta de domador
15920	Fusta de domador
15921	Fusta de domador
15922	Fusta de domador
15923	Fusta de domador
15924	Carne de almeja ovalada
15925	Bastón de oficial
15926	Orbe Vinculahechizo
15927	Esfera brillante
15928	Vara de hilo de plata
15929	Orbe Cielo Nocturno
15930	Cetro imperial rojo
15931	Estrella Arcana
15932	Piedra de discípulo
15933	Rama simple
15934	Bastón de sabio
15935	Vara durable
15936	Rama Tejealba
15937	Esfera invernal
15938	Orbe místico
15939	Cetro de concejal
15940	Cetro elegante
15941	Centro de consejero mayor
15942	Vara de maestro
15943	Escudo imbuido
15944	Orbe ancestral
15945	Bastón rúnico
15946	Esfera de místico
15947	Estrella sanguina
15962	Vara de sátiro
15963	Rama de paño de piedra
15964	Estrella Sedarena
15965	Orbe Cazavientos
15966	Orbe sudario de veneno
15967	Estrella de Altonato
15968	Esfera elunarita
15969	Orbe perlado
15970	Rama nativa
15971	Vara aborigen
15972	Jarra de ritual
15973	Estrella de guardia
15974	Vara pagana
15975	Cetro Clamalluvias
15976	Rama Piel de Cardo
15977	Orbe vital
15978	Vara de geomántico
15979	Bastón de seda de ascuas
15980	Orbe Niebla Negra
15981	Esfera lunar
15982	Vara de tejido de sangre
15983	Cetro de Gaea
15984	Cetro opulento
15985	Rama arácnida
15986	Estrella de Tirahuesos
15987	Orbe astral
15988	Orbe resplendente
15989	Vara eterna
15990	Escudo duradero
15991	Escudo de Líder de guerra
15992	Pólvora densa
15993	Granada de torio
15994	Trastos wow de torio
15995	Rifle de torio
15996	Sapo mecánico casi vivo
15997	Proyectiles de torio
15998	Nota de Lewis
15999	Gafas extremas de hechizo de poder plus
16000	Tubo de torio
16001	Insignia IS:7 (Fredo)
16002	Insignia IS:7 (Tucentenon)
16003	Insignia IS:7 (Rutger)
16004	Rifle Hierro Negro
16005	Bomba Hierro Negro
16006	Conversor de arcanita delicado
16007	Rifle de arcanita impecable
16008	Gafas de maestro ingeniero
16009	Modulador de amplificación de voz
16022	Dragonizo de arcanita
16023	Muñeco-diana magistral
16026	PVP Plate Helm Alliance
16027	PVP Plate Breastplate Alliance
16028	PVP Plate Legplates Alliance
16029	PVP Plate Gauntlets Alliance
16030	PVP Plate Boots Alliance
16031	PVP Plate Shoulder Alliance
16033	PVP Plate Wrist Alliance
16034	PVP Plate Cloak Alliance
16035	PVP Cloth Helm Horde
16036	PVP Cloth Robe Horde
16037	PVP Cloth Legs Horde
16038	PVP Cloth Shoulder Horde
16039	Filosón Ta'Kierthan
16040	Bomba Arcana
16041	Esquema: granada de torio
16042	Esquema: trastos wow de torio
16043	Esquema: rifle de torio
16044	Esquema: sapo mecánico casi vivo
16045	Esquema: gafas extremas de hechizo de poder plus
16046	Esquema: muñeco-diana magistral
16047	Esquema: tubo de torio
16048	Esquema: rifle Hierro Negro
16049	Esquema: bomba Hierro Negro
16050	Esquema: conversor de arcanita delicado
16051	Esquema: proyectiles de torio
16052	Esquema: modulador de amplificación de voz
16053	Esquema: gafas de maestro ingeniero
16054	Esquema: dragonizo de arcanita
16055	Esquema: bomba Arcana
16056	Esquema: rifle de arcanita impecable
16057	Morral de expedicionario
16058	Lacre de Fordring
16059	Camisa marrón común
16060	Camisa blanca común
16072	Libro de cocina para expertos
16073	Libro de cocina de artesano
16082	Pesca de artesano: El truco de los señuelos
16083	Pesca para expertos: La lubina y tú
16084	Primeros auxilios para expertos: Entre vendas
16085	Primeros auxilios de artesano: Cúrate tú mismo
16110	Receta: tortilla de monstruo
16111	Receta: chili de cangrejo especiado
16112	Manual: venda de seda pesada
16113	Manual: venda de paño mágico
16114	Porra de supervisor
16115	Cajón de Osric
16166	Sopa de judías
16167	Obsequio versicolor
16168	Melocotón del cielo
16169	Pastel de arroz salvaje
16170	Mandú al vapor
16171	Shinsollo
16189	Dorso de la carta de Maggran
16190	Restos de desgarrador Furia Sangrienta
16191	Espejo ornamentado
16192	Colmillo de Besseleth
16202	Esencia eterna inferior
16203	Esencia eterna superior
16204	Polvo de ilusión
16205	Semilla de Gaea
16206	Vara de arcanita
16207	Vara arcanita con runas
16208	Semillas de Gaea encantadas
16209	Pedido de Podrig
16210	Cajón de Gordok
16214	Fórmula: encantar brazal: intelecto superior
16215	Fórmula: encantar botas: aguante superior
16216	Fórmula: encantar capa: resistencia superior
16217	Fórmula: encantar escudo: aguante superior
16218	Fórmula: encantar brazal: espíritu excelente
16219	Fórmula: encantar guantes: agilidad superior
16220	Fórmula: encantar botas: espíritu
16221	Fórmula: encantar pechera: salud sublime
16222	Fórmula: encantar escudo: espíritu excelente
16223	Fórmula: encantar arma: escalofrío gélido
16224	Fórmula: encantar capa: defensa excelente
16242	Fórmula: encantar pechera: maná sublime
16243	Fórmula: vara arcanita con runas
16244	Fórmula: encantar guantes: fuerza superior
16245	Fórmula: encantar botas: agilidad superior
16246	Fórmula: encantar brazal: fuerza excelente
16247	Fórmula: encantar arma de 2M: impacto excelente
16248	Fórmula: encantar arma: profano
16249	Fórmula: encantar arma de 2M: intelecto sublime
16250	Fórmula: encantar arma: golpes excelentes
16251	Fórmula: encantar brazal: aguante excelente
16252	Fórmula: encantar arma: cruzado
16253	Fórmula: encantar pechera: estadística superior
16254	Fórmula: encantar arma: robo de vida
16255	Fórmula: encantar arma de 2M: espíritu sublime
16262	Colección de Nessa
16263	Respuesta de Laird
16282	Fardo de pellejos
16283	Peletería de Ahanu
16302	Grimorio de Descarga de Fuego (Rango 2)
16303	Pata de Ursangous
16304	Cabeza de Shadumbra
16305	Garra de Garrafilada
16306	Carnes de Zargh
16307	Carta de Gryshka
16308	Palanca de Crestanorte
16309	Amuleto de Pirodraco
16310	Lista de Brock
16311	Picos honorarios
16312	Incendritas
16313	Cofre de Felix
16314	Cubo de tornillos de Felix
16315	Capa de sargento mayor
16316	Grimorio de Descarga de Fuego (Rango 3)
16317	Grimorio de Descarga de Fuego (Rango 4)
16318	Grimorio de Descarga de Fuego (Rango 5)
16319	Grimorio de Descarga de Fuego (Rango 6)
16320	Grimorio de Descarga de Fuego (Rango 7)
16321	Grimorio de Pacto de sangre (Rango 1)
16322	Grimorio de Pacto de sangre (Rango 2)
16323	Grimorio de Pacto de sangre (Rango 3)
16324	Grimorio de Pacto de sangre (Rango 4)
16325	Grimorio de Pacto de sangre (Rango 5)
16326	Grimorio de Escudo de Fuego (Rango 1)
16327	Grimorio de Escudo de Fuego (Rango 2)
16328	Grimorio de Escudo de Fuego (Rango 3)
16329	Grimorio de Escudo de Fuego (Rango 4)
16330	Grimorio de Escudo de Fuego (Rango 5)
16331	Grimorio de Cambio de fase
16332	Pico de Thazz'ril
16333	Restos de Samuel
16335	Insignia de capataz primero
16336	Capa de sargento mayor
16337	Capa de sargento mayor
16338	Corcel de Teniente caballero
16339	Corcel de Comandante
16341	Capa de sargento
16342	Manteo de sargento
16343	Montura de Guardia de sangre
16344	Montura de Teniente coronel
16345	Hoja de Gran Señor de la Guerra
16346	Grimorio de Tormento (Rango 2)
16347	Grimorio de Tormento (Rango 3)
16348	Grimorio de Tormento (Rango 4)
16349	Grimorio de Tormento (Rango 5)
16350	Grimorio de Tormento (Rango 6)
16351	Grimorio de Sacrificio (Rango 1)
16352	Grimorio de Sacrificio (Rango 2)
16353	Grimorio de Sacrificio (Rango 3)
16354	Grimorio de Sacrificio (Rango 4)
16355	Grimorio de Sacrificio (Rango 5)
16356	Grimorio de Sacrificio (Rango 6)
16357	Grimorio de Consumir las Sombras (Rango 1)
16358	Grimorio de Consumir las Sombras (Rango 2)
16359	Grimorio de Consumir las Sombras (Rango 3)
16360	Grimorio de Consumir las Sombras (Rango 4)
16361	Grimorio de Consumir las Sombras (Rango 5)
16362	Grimorio de Consumir las Sombras (Rango 6)
16363	Grimorio de Sufrimiento (Rango 1)
16364	Grimorio de Sufrimiento (Rango 2)
16365	Grimorio de Sufrimiento (Rango 3)
16366	Grimorio de Sufrimiento (Rango 4)
16367	Fajín de seda de capitán caballero
16368	Grimorio de Látigo de dolor (Rango 2)
16369	Botas de seda de Teniente caballero
16370	Puños de seda de capitán caballero
16371	Grimorio de Látigo de dolor (Rango 3)
16372	Grimorio de Látigo de dolor (Rango 4)
16373	Grimorio de Látigo de dolor (Rango 5)
16374	Grimorio de Látigo de dolor (Rango 6)
16375	Grimorio de Beso calmante (Rango 1)
16376	Grimorio de Beso calmante (Rango 2)
16377	Grimorio de Beso calmante (Rango 3)
16378	Grimorio de Beso calmante (Rango 4)
16379	Grimorio de Seducción
16380	Grimorio de Invisibilidad inferior
16381	Grimorio de Devorar magia (Rango 2)
16382	Grimorio de Devorar magia (Rango 3)
16383	Grimorio de Devorar magia (Rango 4)
16384	Grimorio de Sangre corrupta (Rango 1)
16385	Grimorio de Sangre corrupta (Rango 2)
16386	Grimorio de Sangre corrupta (Rango 3)
16387	Grimorio de Sangre corrupta (Rango 4)
16388	Grimorio de Bloqueo de hechizos (Rango 1)
16389	Grimorio de Bloqueo de hechizos (Rango 2)
16390	Grimorio de Paranoia
16391	Guantes de seda de Teniente caballero
16392	Botas de cuero de Teniente caballero
16393	Borceguíes de pellejo de dragón de Teniente caballero
16394	Brazales de cuero de capitán caballero
16395	Braquiales de pellejo de dragón de capitán caballero
16396	Guanteletes de cuero de Teniente caballero
16397	Guantes de pellejo de dragón de Teniente caballero
16398	Cinturón de cuero de capitán caballero
16399	Faja de pellejo de dragón de capitán caballero
16400	Faja de anillas de capitán caballero
16401	Botas de anillas de Teniente caballero
16402	Guardabrazos de anillas de capitán caballero
16403	Guanteletes de anillas de Teniente caballero
16404	Guardamuñecas de placas de capitán caballero
16405	Botas de placas de Teniente caballero
16406	Guanteletes de placas de Teniente caballero
16407	Faja de placas de capitán caballero
16408	Globo de agua contaminada
16409	Escarpes de láminas de Teniente caballero
16410	Guanteletes de láminas de Teniente caballero
16411	Cincho de láminas de capitán caballero
16412	Braquiales de láminas de capitán caballero
16413	Vestimenta de seda de Capitán caballero
16414	Leotardos de seda de Capitán caballero
16415	Bufas de seda de Teniente coronel
16416	Corona de Teniente coronel
16417	Armadura de cuero de Capitán caballero
16418	Velo de cuero de Teniente coronel
16419	Musleras de cuero de Capitán caballero
16420	Bufas de cuero de Teniente coronel
16421	Túnica de pellejo de dragón de Capitán caballero
16422	Leotardos de pellejo de dragón de Capitán caballero
16423	Insignias de pellejo de dragón de Teniente coronel
16424	Sudario de pellejo de dragón de Teniente coronel
16425	Camisote de anillas de Capitán caballero
16426	Leotardos de anillas de Capitán caballero
16427	Espaldares de anillas de Teniente coronel
16428	Casco de anillas de Teniente coronel
16429	Yelmo de placas de Teniente coronel
16430	Coraza de placas de Capitán caballero
16431	Leotardos de placas de Capitán caballero
16432	Espaldares de placas de Teniente coronel
16433	Peto de láminas de Capitán caballero
16434	Protegecabezas de láminas de Teniente coronel
16435	Leotardos de láminas de Capitán caballero
16436	Hombreras de láminas de Teniente coronel
16437	Borceguíes de seda de mariscal
16438	Brazales de seda de mariscal
16439	Fajín de seda de mariscal
16440	Guantes de seda de mariscal
16441	Corona de alguacil de campo
16442	Leotardos de seda de mariscal
16443	Vestimentas de seda de alguacil de campo
16444	Bufas de seda de alguacil de campo
16445	Brazales de pellejo de dragón de mariscal
16446	Guardapiés de cuero de mariscal
16447	Guardarrenes de pellejo de dragón de mariscal
16448	Guanteletes de pellejo de dragón de mariscal
16449	Bufas de pellejo de dragón de alguacil de campo
16450	Musleras de pellejo de dragón de mariscal
16451	Casco de pellejo de dragón de alguacil de campo
16452	Peto de pellejo de dragón de alguacil de campo
16453	Coraza de cuero de alguacil de campo
16454	Manoplas de cuero de mariscal
16455	Máscara de cuero de alguacil de campo
16456	Leotardos de cuero de mariscal
16457	Insignias de cuero de alguacil de campo
16458	Cincho de cuero de mariscal
16459	Botas de pellejo de dragón de mariscal
16460	Braquiales de cuero de mariscal
16461	Brazales de anillas de mariscal
16462	Botas de anillas de mariscal
16463	Mandiletes de anillas de mariscal
16464	Faja de anillas de mariscal
16465	Yelmo de anillas de mariscal de campo
16466	Peto de anillas de mariscal de campo
16467	Musleras de anillas de mariscal
16468	Bufas de anillas de mariscal de campo
16469	Guardabrazos de láminas de mariscal
16470	Cinturón de láminas de mariscal
16471	Guantes de láminas de mariscal
16472	Botas de láminas de mariscal
16473	Peto de láminas de alguacil de campo
16474	Yelmo de láminas de alguacil de campo
16475	Quijotes de láminas de mariscal
16476	Espaldares de láminas de alguacil de campo
16477	Armadura de placas de alguacil de campo
16478	Yelmo de placas de alguacil de campo
16479	Musleras de placas de mariscal
16480	Hombreras de placas de alguacil de campo
16481	Brazales de placas de mariscal
16482	Faja de placas de mariscal
16483	Botas de placas de mariscal
16484	Guantes de placas de mariscal
16485	Borceguíes de seda de Guardia de sangre
16486	Puños de seda de Gran capataz
16487	Guantes de seda de Guardia de sangre
16488	Cinturón de seda de legionario
16489	Caperuza de seda de campeón
16490	Pantalones de seda de legionario
16491	Togas de seda de legionario
16492	Hombreras de seda de campeón
16493	Guardabrazos de pellejo de dragón de legionario
16494	Botas de pellejo de dragón de Guardia de sangre
16495	Pretina de pellejo de dragón de legionario
16496	Guanteletes de pellejo de dragón de Guardia de sangre
16497	Guardabrazos de cuero de Gran capataz
16498	Botines de cuero Guardia de sangre
16499	Vicio de cuero de Guardia de sangre
16500	Faja de cuero de legionario
16501	Bufas de pellejo de dragón de campeón
16502	Pantalones de pellejo de dragón de legionario
16503	Yelmo de pellejo de dragón de campeón
16504	Peto de pellejo de dragón de legionario
16505	Camisote de cuero de legionario
16506	Protegecabezas de cuero de campeón
16507	Manto de cuero de campeón
16508	Leotardos de cuero de legionario
16509	Botas de placas de Guardia de sangre
16510	Guantes de placas de Guardia de sangre
16511	Cincho de placas de legionario
16512	Brazales de placas de legionario
16513	Armadura de placas de legionario
16514	Protegecabezas de placas de campeón
16515	Musleras de placas de legionario
16516	Espaldares de placas de campeón
16517	Brazales de anillas de legionario
16518	Botos de malla de Guardia de sangre
16519	Mandiletes de malla de Guardia de sangre
16520	Cincho de malla de legionario
16521	Yelmo de malla de campeón
16522	Coraza de malla de legionario
16523	Leotardos de malla de legionario
16524	Hombreras de malla de campeón
16525	Peto de anillas de legionario
16526	Protegecabezas de anillas de campeón
16527	Leotardos de anillas de legionario
16528	Espaldares de anillas de campeón
16529	Faja de anillas de legionario
16530	Guanteletes de Guardia de sangre
16531	Botas de anillas de Guardia de sangre
16532	Muñequeras de malla de Gran capataz
16533	Capucha de seda de Señor de la Guerra
16534	Pantalones de seda de general
16535	Vestimenta de seda de Señor de la Guerra
16536	Hombrera de seda de Señor de la Guerra
16537	Fajín de seda de general
16538	Puños de seda de general
16539	Botas de seda de general
16540	Manoplas de seda de general
16541	Armadura de placas de Señor de la Guerra
16542	Celada de placas de Señor de la Guerra
16543	Leotardos de placas de general
16544	Hombreras de placas de Señor de la Guerra
16545	Botas de placas de general
16546	Guardabrazos de placas de general
16547	Faja de placas de general
16548	Guanteletes de placas de general
16549	Camisote tejedor de tinieblas de Señor de la Guerra
16550	Casco tejedor de tinieblas de Señor de la Guerra
16551	Insignias tejedor de tinieblas de Señor de la Guerra
16552	Leotardos de pellejo de dragón de general
16553	Brazales de pellejo de dragón de general
16554	Botas de pellejo de dragón de general
16555	Guantes de pellejo de dragón de general
16556	Cinturón de pellejo de dragón de general
16557	Faja de cuero de general
16558	Botines de cuero de general
16559	Braquiales de cuero de general
16560	Mitones de cuero de general
16561	Yelmo de cuero de Señor de la Guerra
16562	Bufas de cuero de Señor de la Guerra
16563	Peto de cuero de Señor de la Guerra
16564	Musleras de cuero de general
16565	Coraza de anillas de Señor de la Guerra
16566	Casco de anillas de Señor de la Guerra
16567	Musleras de anillas de general
16568	Hombreras de anillas de Señor de la Guerra
16569	Escarpes de anillas de general
16570	Guardamuñecas de anillas de general
16571	Guantes de anillas de general
16572	Faja de anillas de General
16573	Botas de malla de general
16574	Guanteletes de malla de general
16575	Pretina de malla de general
16576	Brazales de malla de general
16577	Armadura de malla de Señor de la Guerra
16578	Yelmo de Señor de la Guerra
16579	Leotardos de malla de general
16580	Bufas de malla de Señor de la Guerra
16581	Cristal de resonita
16583	Figura demoníaca
16602	Talismán trol
16603	Cristal de resonita encantado
16604	Togas lunares de Elune
16605	Togas de la luz de Friar
16606	Togas de maleficio juju
16607	Togas de sacrificio de acólito
16608	Cinturón acuario
16622	Lanzaespinas
16623	Medallón opalino
16642	Manual de instrucciones de trituradora: Capítulo 1
16643	Manual de instrucciones de trituradora: Capítulo 2
16644	Manual de instrucciones de trituradora: Capítulo 3
16645	Manual de instrucciones de trituradora: Página 1
16646	Manual de instrucciones de trituradora: Página 2
16647	Manual de instrucciones de trituradora: Página 3
16648	Manual de instrucciones de trituradora: Página 4
16649	Manual de instrucciones de trituradora: Página 5
16650	Manual de instrucciones de trituradora: Página 6
16651	Manual de instrucciones de trituradora: Página 7
16652	Manual de instrucciones de trituradora: Página 8
16653	Manual de instrucciones de trituradora: Página 9
16654	Manual de instrucciones de trituradora: Página 10
16655	Manual de instrucciones de trituradora: Página 11
16656	Manual de instrucciones de trituradora: Página 12
16658	Capa de cazador salvaje
16659	Cinturón de equilibrista
16660	Escudo lodo acumulado
16661	Manteo de sauce suave
16662	Fragmento de Ojo de dragón
16663	Sangre de dragón negro campeón
16664	Brazales ornamentados
16665	Escrito sobre Disparo tranquilizante
16666	Jubón de Elementos
16667	Almófar de elementos
16668	Falda escocesa de elementos
16669	Espaldares de Elementos
16670	Botas de elementos
16671	Ataduras de Elementos
16672	Guanteletes de Elementos
16673	Elementia de cordón
16674	Túnica de acechabestias
16675	Botas de acechabestias
16676	Guantes de acechabestias
16677	Almete de acechabestias
16678	Pantalones de acechabestias
16679	Manto de acechabestias
16680	Cinturón de acechabestias
16681	Ataduras de acechabestias
16682	Botas de magíster
16683	Ataduras de magíster
16684	Guantes de magíster
16685	Cinturón de magíster
16686	Corona de magíster
16687	Leotardos de magíster
16688	Togas de magíster
16689	Manto de magíster
16690	Toga de devoto
16691	Sandalias de devoto
16692	Guantes de devoto
16693	Corona de devoto
16694	Falda de devoto
16695	Manto de devoto
16696	Cinturón de devoto
16697	Brazales de devoto
16698	Máscara Calígine
16699	Leotardos Calígine
16700	Toga Calígine
16701	Manto Calígine
16702	Cinturón Calígine
16703	Brazales Calígine
16704	Sandalias Calígine
16705	Brazaletes Calígine
16706	Jubón Corazón salvaje
16707	Cofia Oficioscuro
16708	Bufas Oficioscuro
16709	Pantalones Oficioscuro
16710	Brazales Oficioscuro
16711	Botas Oficioscuro
16712	Guantes Oficioscuro
16713	Cinturón Oficioscuro
16714	Brazales Corazón salvaje
16715	Botas Corazón salvaje
16716	Cinturón Corazón salvaje
16717	Guantes Corazón salvaje
16718	Bufas Corazón salvaje
16719	Falda escocesa Corazón salvaje
16720	Capucha Corazón salvaje
16721	Túnica Oficioscuro
16722	Brazales Forjaluz
16723	Cinturón Forjaluz
16724	Guanteletes Forjaluz
16725	Botas Forjaluz
16726	Peto Forjaluz
16727	Yelmo Forjaluz
16728	Quijotes Forjaluz
16729	Bufas Forjaluz
16730	Peto de Valor
16731	Yelmo de Valor
16732	Musleras de Valor
16733	Bufas de valor
16734	Botas de valor
16735	Brazales de Valor
16736	Cinturón de Valor
16737	Guanteletes de Valor
16738	Guantes de semilla marchita
16739	Manto de Madera Basta
16740	Guantes de manejo de trituradora
16741	Mitones de aceite
16742	Espadas dentadas Grito de Guerra
16743	Cuerda
16744	Aceite Grito de Guerra
16745	Envío de hachas Grito de Guerra
16746	Informe Grito de Guerra
16747	Candado roto
16748	Forro acolchado
16762	Núcleo de las profundidades
16763	Novedades del corredor Grito de Guerra
16764	Novedades del explorador Grito de Guerra
16765	Actualización de escolta Grito de Guerra
16766	Sopa de almejas de Villabajo
16767	Receta: sopa de almejas de Villabajo
16768	Faltriquera de medicinas fúrbolg
16769	Tótem medicinal fúrbolg
16782	Globo de agua extraño
16783	Fardo de informes
16784	Zafiro de Aku'Mai
16786	Ojo de dragauro negro
16787	Amuleto de Subversión dracónica
16788	Timón del capitán Masatormento
16789	Barra del timón del capitán Masatormento
16790	Nota mojada
16791	Puños corrientes de seda
16792	Garrote gigante
16793	Hombreras Arcometal
16794	Muñequeras para empuñaduras de acero
16795	Corona arcanista
16796	Leotardos arcanistas
16797	Manto arcanista
16798	Togas arcanistas
16799	Ataduras arcanistas
16800	Botas arcanistas
16801	Guantes arcanistas
16802	Cinturón arcanista
16803	Zapatillas corazón inferi
16804	Brazales corazón inferi
16805	Guantes corazón inferi
16806	Cinturón corazón inferi
16807	Hombreras corazón inferi
16808	Cuernos corazón inferi
16809	Togas corazón inferi
16810	Pantalones corazón inferi
16811	Botas de profecía
16812	Guantes de Profecía
16813	Aro de Profecía
16814	Pantalones de profecía
16815	Togas de Profecía
16816	Manto de Profecía
16817	Faja de Profecía
16818	Cinturón viento abisal
16819	Protegebrazos de Profecía
16820	Coraza de destripador nocturno
16821	Abrigo de destripador nocturno
16822	Pantalones de destripador nocturno
16823	Hombreras de destripador nocturno
16824	Botas de destripador nocturno
16825	Pulseras de destripador nocturno
16826	Guantes de destripador nocturno
16827	Cinturón de destripador nocturno
16828	Cinturón Cenarion
16829	Botas Cenarion
16830	Brazales Cenarion
16831	Guantes Cenarion
16832	Bufas Colmillo de Sangre
16833	Vestimentas Cenarion
16834	Yelmo Cenarion
16835	Leotardos Cenarion
16836	Bufas Cenarion
16837	Botas Furia terrenal
16838	Cinturón Furia terrenal
16839	Guanteletes Furia terrenal
16840	Brazales Furia terrenal
16841	Vestimentas Furia terrenal
16842	Casco Furia terrenal
16843	Musleras Furia terrenal
16844	Insignias Furia terrenal
16845	Peto de acechagigantes
16846	Casco de acechagigantes
16847	Leotardos de acechagigantes
16848	Insignia de acechagigantes
16849	Botas de acechagigantes
16850	Brazales de acechagigantes
16851	Cinturón de acechagigantes
16852	Guantes de acechagigantes
16853	Coraza de justiciero
16854	Yelmo de justiciero
16855	Quijotes de justiciero
16856	Bufas de justiciero
16857	Brazales de justiciero
16858	Cinturón de justiciero
16859	Botas de justiciero
16860	Guanteletes de justiciero
16861	Brazales de Poderío
16862	Escarpes de poderío
16863	Guanteletes de Poderío
16864	Cinturón de Poderío
16865	Peto de Poderío
16866	Yelmo de Poderío
16867	Musleras de Poderío
16868	Espaldares de Poderío
16869	El cráneo de Sccentenor
16870	El cráneo de Somnus
16871	El cráneo de Chronalis
16872	El cráneo de Axtroz
16873	Guantes de pelaje trenzado
16882	Caja de trastos maltrecha
16883	Caja de trastos desgastada
16884	Caja de trastos robusta
16885	Caja de trastos pesada
16886	Sable de foragido
16887	Dedo de bruja
16888	Amuleto de Pirodraco apagado
16889	Bastón de apoyo pulido
16890	Alfanje de metal de pizarra
16891	Espada corta de arcilla
16892	Piedra de alma inferior
16893	Piedra de alma
16894	Vara de cristal claro
16895	Piedra de alma superior
16896	Piedra de alma sublime
16897	Coraza de Tempestira
16898	Botas de Tempestira
16899	Manoplas de Tempestira
16900	Abrigo de Tempestira
16901	Musleras de Tempestira
16902	Espaldares de Tempestira
16903	Cinturón de Tempestira
16904	Brazales de Tempestira
16905	Coraza Colmillo de Sangre
16906	Botas Colmillo de Sangre
16907	Guantes Colmillo de Sangre
16908	Caperuza Colmillo de Sangre
16909	Pantalones Colmillo de Sangre
16910	Cinturón Colmillo de Sangre
16911	Brazales Colmillo de Sangre
16912	Botas viento abisal
16913	Guantes viento abisal
16914	Corona viento abisal
16915	Pantalones viento abisal
16916	Togas viento abisal
16917	Manto viento abisal
16918	Ataduras viento abisal
16919	Botas de trascendencia
16920	Manoplas de Trascendencia
16921	Halo de Trascendencia
16922	Leotardos de Trascendencia
16923	Togas de Trascendencia
16924	Espaldares de Trascendencia
16925	Cinturón de Trascendencia
16926	Ataduras de Trascendencia
16927	Botas Némesis
16928	Guantes Némesis
16929	Capacete Némesis
16930	Leotardos Némesis
16931	Togas Némesis
16932	Bufas Némesis
16933	Cinturón Némesis
16934	Brazales Némesis
16935	Brazales de Acechadragón
16936	Cinturón de Acechadragón
16937	Bufas de Acechadragón
16938	Musleras de Acechadragón
16939	Yelmo de Acechadragón
16940	Guanteletes de Acechadragón
16941	Grebas de Acechadragón
16942	Peto de Acechadragón
16943	Brazales de Diez Tormentas
16944	Cinturón de Diez Tormentas
16945	Insignias de diez tormentas
16946	Musleras de Diez Tormentas
16947	Yelmo de diez tormentas
16948	Guanteletes de Diez tormentas
16949	Grebas de Diez Tormentas
16950	Peto de Diez Tormentas
16951	Ataduras de sentencia
16952	Cinturón de sentencia
16953	Bufas de sentencia
16954	Quijotes de sentencia
16955	Corona de sentencia
16956	Guanteletes de sentencia
16957	Escarpes de sentencia
16958	Peto de sentencia
16959	Brazaletes de Cólera
16960	Pretina de Cólera
16961	Espaldares de Cólera
16962	Musleras de Cólera
16963	Yelmo de Cólera
16964	Guanteletes de Cólera
16965	Escarpes de Cólera
16966	Peto de Cólera
16967	Ahi de Feralas
16968	Golpeador Sar'theris
16969	Latipinia azul de La Costa Salvaje
16970	Mahi mahi de Juncobruma
16971	Sorpresa de almejate
16972	Estandarte de Karang
16973	Vial de agua nefasta
16974	Vial de agua vacío
16975	Fajín Grito de Guerra
16976	Tótem de Murgut
16977	Botas Grito de Guerra
16978	Guanteletes Grito de Guerra
16979	Guantes Bengala del Núcleo
16980	Manto Bengala del Núcleo
16981	Brazales de barba de búho
16982	Botas de can del Núcleo
16983	Yelmo de arrabio
16984	Botas de escamas de dragón negro
16985	Botas del Hijo del Viento
16986	Guantes Cumbre de Arena
16987	Cinturón de estridador
16988	Hombreras de anillas ígneas
16989	Faja de anillas ígneas
16990	Capa de duendekin
16991	Venda de selección
16992	Lanzaexplosivos de Smokey
16993	Pistola de fuego de Smokey
16994	Guantes ala del alba
16995	Manto ala del alba
16996	Arco de madera gore
16997	Habitante de Tempestira
16998	Protector sacro
16999	Lacre real de Alexis
17000	Sortija de la Aparición
17001	Círculo elemental
17002	Escupeicor
17003	Martillo Calapetra
17004	Guía de Sara
17005	Túnica de guardia grosero
17006	Musleras de cobalto
17007	Guanteletes de creador de piedras
17008	Pergamino pequeño
17009	Cabeza del Embajador Malcin
17010	Núcleo ígneo
17011	Núcleo de lava
17012	Cuero del Núcleo
17013	Leotardos Hierro Negro
17014	Brazales Hierro Negro
17015	Atracador Hierro Negro
17016	Destructor Hierro Negro
17017	Patrón: manto Bengala del Núcleo
17018	Patrón: guantes Bengala del Núcleo
17019	Polvo Arcano
17020	Partículas Arcanas
17021	Frutos silvestres
17022	Patrón: botas del can del Núcleo
17023	Patrón: yelmo de arrabio
17024	Raíz salvaje
17025	Patrón: botas de escamas de dragón negro
17026	Raíz de espina salvaje
17027	Vela con aroma
17028	Vela sagrada
17029	Vela sacra
17030	Ankh
17031	Runa de Teletransporte
17032	Runa de Portales
17033	Símbolo de Divinidad
17034	Semillas de arce
17035	Semilla Tuercespina
17036	Semilla bosqueceniza
17037	Semillas de carpinus
17038	Semilla Maderaférrea
17039	Partecalaveras
17042	Escupeuñas
17043	Toga de Zealot
17044	Voluntad del Mártir
17045	Sangre del Mártir
17046	Hoja de entrañas
17047	Hombrera luminiscente
17048	Ron Rumsey
17049	Diseño: faja de anillas ígneas
17050	Togas imperiales de Chan
17051	Diseño: brazales Hierro Negro
17052	Diseño: leotardos Hierro Negro
17053	Diseño: hombreras de anillas ígneas
17054	Piedad de Joonho
17055	Machacachanguk
17056	Pluma ligera
17057	Escamas de pez lustrosas
17058	Aceite de pescado
17059	Diseño: atracador Hierro Negro
17060	Diseño: destructor Hierro Negro
17061	Sombra de Juno
17062	Receta: trucha de cabeza de mitril
17063	Sortija de Accuria
17064	Fragmento de la Escama
17065	Medallón del Poderío Férreo
17066	Disco Drillborer
17067	Antiguo grimorio de piedra angular
17068	Libramorte
17069	Marca de artillero
17070	Colmillo de los Místicos
17071	Destripadora
17072	Lanzador tiroexplosión
17073	Tiemblatérrea
17074	Tenebrosa
17075	Vis'kag el Estampa de Sangre
17076	Filo de Atracahuesos
17077	Aplastador carmesí
17078	Mantón de Sapphiron
17082	Fragmento de la Llama
17102	Capa de la Niebla envolvente
17103	Hoja mágica de cantoazur
17104	Segadora raquídea
17105	Martillo de piedra de aura
17106	Defensor de Malistar
17107	Manteo de sangre de dragón
17108	Marca de Desvío
17109	Gargantilla de Iluminación
17110	Lacre del Archimago
17111	Medallón Furia abrasadora
17112	Demoledor empireano
17113	Guardián del Lacre Ámbar
17114	Fragmento de filacteria de Araj
17115	Muestra de ardilla
17116	Muestra de ardilla
17117	Flauta de ratelín
17118	Envase de carne misteriosa
17119	Rata kabob subterránea
17124	Emblema de la Hermandad
17125	Lacre de Ravenholdt
17126	Carta elegante
17142	Fragmento del Rapiñador
17182	Sulfuras, Mano de Ragnaros
17183	Rodela dentada
17184	Escudo pequeño
17185	Rodela redonda
17186	Tarja pequeña
17187	Rodela a rayas
17188	Rodela ensortijada
17189	Rodela de metal
17190	Rodela ornamentada
17191	Cetro de Celebras
17192	Tarja reforzada
17193	Martillo de Sulfuron
17194	Especias de vacaciones
17195	Muérdago falso
17196	Espíritus de vacaciones
17197	Galleta de jengibre
17198	Ponche de huevo
17199	Ponche de huevo estropeado
17200	Receta: galleta de jengibre
17201	Receta: ponche de huevo
17202	Bola de nieve
17203	Lingote de sulfuron
17204	Ojo de Sulfuras
17222	Salchicha de araña
17223	Tronadora
17224	Mira de visión
17242	Llave del cofre de Salem
17262	Llave de James
17302	Obsequio de vacaciones con lazo azul
17303	Papel para envolver con lazo azul
17304	Papel para envolver con lazos verdes
17305	Obsequio de vacaciones con lazos verdes
17306	Sangre de soldado de Pico Tormenta
17307	Papel de envolver con lazos morados
17308	Recuerdo de vacaciones con lazo morado
17309	Brazales que no van a juego
17310	Aspecto de Neptulon
17322	Ojo del Brasadivino
17323	Señal de Mulverick
17324	Señal de Guse
17325	Señal de Jeztor
17326	Carne de soldado de Pico Tormenta
17327	Carne de teniente de Pico Tormenta
17328	Carne de comandante de Pico Tormenta
17329	Mano de Lucifron
17330	Mano de Sulfuron
17331	Mano de Gehennas
17332	Mano de Shazzrah
17333	Quintaesencia de agua
17344	Caña de caramelo
17345	Baba de silítido
17346	Objeto silítido taraceado
17347	Controlador de miembros de la Hermandad (MURP)
17348	Trago de curación sublime
17349	Sequía curativa excelente
17351	Sequía de maná sublime
17352	Sequía de maná excelente
17353	Órdenes de asalto de Pico Tormenta
17354	El ojo que todo lo ve del maestro Ryson
17355	Carta de Rabine
17362	Señal de Ryson
17363	Señal de Ryson
17364	Mira de visión
17384	Unidad trituradora de Zinfizzlex
17402	Aliento invernal del Padre Invierno
17403	Espíritus burbujeantes de Bonvapor
17404	Brebaje de judías mezcladas
17405	Té de jardín verde
17406	Rueda de queso de vacaciones
17407	Pastel de carne casero de Graccu
17408	Ternera picante
17409	Fragmento de cristal taraceado
17410	Unidad trituradora de Zinfizzlex
17411	Sierra de vapor
17413	Códice: Rezo de Entereza
17414	Códice: Rezo de Entereza 2
17422	Trocitos de armadura
17423	Cristal de tormenta
17442	Órdenes de asalto Lobo Gélido
17502	Medalla de soldado Lobo Gélido
17503	Medalla de teniente Lobo Gélido
17504	Medalla de comandante Lobo Gélido
17505	Señal de Inchman
17506	Señal de Vipore
17507	Señal de Slidore
17508	Rodela Piedra de potencia
17522	Suministros de Ferrohondo
17523	Mantón de Smokey
17542	Suministros Dentefrío
17562	Botas tejedor de tinieblas de Teniente caballero
17563	Brazales de de tejido de tinieblas de capitán caballero
17564	Guantes tejedor de tinieblas de Teniente caballero
17565	Cinturón de de tejido de tinieblas de capitán caballero
17566	Protegecabezas de Teniente coronel
17567	Leotardos tejedor de tinieblas de Capitán caballero
17568	Toga tejedor de tinieblas de Capitán caballero
17569	Manto tejedor de tinieblas de Teniente coronel
17570	Caperuza tejedor de tinieblas de campeón
17571	Leotardos tejedor de tinieblas de legionario
17572	Toga tejedor de tinieblas de legionario
17573	Hombreras tejedor de tinieblas de campeón
17574	Cinturón de de tejido de tinieblas de legionario
17575	Brazales de de tejido de tinieblas de legionario
17576	Botas tejedor de tinieblas de Guardia de sangre
17577	Guantes tejedor de tinieblas de Guardia de sangre
17578	Diadema de alguacil de campo
17579	Leotardos tejedor de tinieblas de mariscal
17580	Hombreras tejedor de tinieblas de alguacil de campo
17581	Toga tejedor de tinieblas de alguacil de campo
17582	Puños de tejido de tinieblas de mariscal
17583	Botas tejedor de tinieblas de mariscal
17584	Guantes tejedor de tinieblas de mariscal
17585	Fajín de tejido de tinieblas de mariscal
17586	Botas tejedor de tinieblas de general
17587	Brazales de tejido de tinieblas de general
17588	Guantes tejedor de tinieblas de general
17589	Cinturón de tejido de tinieblas de general
17590	Manto tejedor de tinieblas de Señor de la Guerra
17591	Caperuza tejedor de tinieblas de Señor de la Guerra
17592	Toga tejedor de tinieblas de Señor de la Guerra
17593	Pantalones tejedor de tinieblas de general
17594	Botas de raso de Teniente caballero
17595	Puños de raso de capitán caballero
17596	Guantes de raso de Teniente caballero
17597	Cordón de raso de capitán caballero
17598	Diadema de Teniente coronel
17599	Leotardos de raso de Capitán caballero
17600	Togas de raso de Capitán caballero
17601	Hombrera de raso de Teniente coronel
17602	Penacho de alguacil de campo
17603	Pantalones de raso de mariscal
17604	Manto de raso de alguacil de campo
17605	Vestimentas de raso de alguacil de campo
17606	Brazales de raso de mariscal
17607	Sandalias de raso de mariscal
17608	Guantes de raso de mariscal
17609	Fajín de raso de mariscal
17610	Capucha de raso de campeón
17611	Pantalones de raso de legionario
17612	Vestimentas de raso de legionario
17613	Hombreras de raso de campeón
17614	Fajín de raso de legionario
17615	Puños de raso de legionario
17616	Botas de raso de Guardia de sangre
17617	Guantes de raso de Guardia de sangre
17618	Botas de raso de general
17619	Brazales de raso de general
17620	Guantes de raso de general
17621	Cincho de satén de general
17622	Manto de raso de Señor de la Guerra
17623	Capucha de raso de Señor de la Guerra
17624	Togas de raso de Señor de la Guerra
17625	Leotardos de raso de general
17626	Bozal Lobo Gélido
17642	Pellejo de carnero de Alterac
17643	Pellejo Lobo Gélido
17662	Golosinas robadas
17682	Libro: Obsequio de las fieras
17683	Libro: Obsequio de las fieras 2
17684	Tallas de cristal terádrico
17685	Muestra de Pastos de Bosquehumeante
17686	Arco de maestro cazador
17687	Rifle de maestro cazador
17688	Botas de la selva
17689	Collar de entrenamiento de Pico Tormenta
17690	Insignia Lobo Gélido Rango 1
17691	Insignia de Pico Tormenta Rango 1
17692	Anillo de cuerno
17693	Vial cerúlea cubierta
17694	Sortija del Puño
17695	Manto de castaño
17696	Vial cerúlea llena
17702	Vara de Celebras
17703	Diamante de Celebras
17704	Filo de invierno
17705	Zumbaespada
17706	Diseño: filo de invierno
17707	Fragmento de gemas
17708	Elixir de poder de Escarcha
17709	Receta: elixir de poder de Escarcha
17710	Daga dirk de calcinita
17711	Leotardos de Crestarroca elemental
17712	Festival de Invierno
17713	Anillo de piedra negra
17714	Brazales de la Princesa de piedra
17715	Ojo de Theradras
17716	Señor de las nieves 9000
17717	Rifle megatiro
17718	Rodela hipertécnica de Gizlock
17719	Espada focal de inventor
17720	Esquema: señor de las nieves 9000
17721	Guantes del Padre Invierno
17722	Patrón: guantes del Padre Invierno
17723	Camisa de vacaciones verde
17724	Patrón: camisa de vacaciones verde
17725	Fórmula: encantar arma: poderío del invierno
17726	Obsequio especial de Pastos de Bosquehumeante
17727	Caja con obsequio de Pastos de Bosquehumeante
17728	Botas de escama de cocodrilo albino
17730	Hacha Bocaimán
17731	Pergamino de Celebras
17732	Manto de Mandilete Podrido
17733	Puño de Piedra
17734	Yelmo de la Montaña
17735	El festín del Festival de Invierno
17736	Guanteletes de mandilete de roca
17737	Piedra nube
17738	Garra de Celebras
17739	Mantón de guardia de la arboleda
17740	Penacho de Veritas
17741	Abrazo de la Naturaleza
17742	Sudario fungal
17743	Vara de resurgimiento
17744	Corazón de Noxxion
17745	Pistola ponzoñosa
17746	Grilletes de Noxxion
17747	Latiguillo
17748	Sandalias de Vinerto
17749	Bufas de fitopiel
17750	Faja de clororrejilla
17751	Leotardos de pelabrusels
17752	Látigo de sátiro
17753	Objetivo del vigilante de Verdantis
17754	Leotardos de timador infernal
17755	Fajín de crin de sátiro
17756	Trozo de fragmento oscuro
17757	Amuleto de los espíritus
17758	Amuleto de Unidad
17759	Marca de Resolución
17760	Semilla de vida
17761	Gema del primer Kahn
17762	Gema del segundo Kahn
17763	Gema del tercer Kahn
17764	Gema del cuarto Kahn
17765	Gema del quinto Kahn
17766	Cetro de la princesa Theradras
17767	Celada brotasangre
17768	Aro de Semillaleña
17769	Bufas arbusto
17770	Guanteletes ramazarza
17771	Barra de elementium
17772	Colgante de fragmento oscuro de Entusiasta
17773	Colgante de fragmento de sombras prodigioso
17774	Marca del Elegido
17775	Togas de sagacidad
17776	Yelmo Sprightring
17777	Cadena incansable
17778	Faja arbusto
17779	Espaldares de mole de piedra
17780	Hoja de Oscuridad eterna
17781	Las instrucciones del Paria
17782	Talismán de Trozo de atadura
17783	Talismán de Fragmento de atadura
17822	Mapas Lobo Gélido
17823	Planes de batalla de Pico Tormenta
17849	Insignia de Pico Tormenta
17850	Estandarte Lobo Gélido
17900	Insignia de Pico Tormenta Rango 2
17901	Insignia de Pico Tormenta Rango 3
17902	Insignia de Pico Tormenta Rango 4
17903	Insignia de Pico Tormenta Rango 5
17904	Insignia de Pico Tormenta Rango 6
17905	Insignia Lobo Gélido Rango 2
17906	Insignia Lobo Gélido Rango 3
17907	Insignia Lobo Gélido Rango 4
17908	Insignia Lobo Gélido Rango 5
17909	Insignia Lobo Gélido Rango 6
17922	Armadura de pellejo de león
17943	Puño de Piedra
17962	Saco de gemas azules
17963	Saco de gemas verdes
17964	Saco de gemas grises
17965	Saco de gemas amarillo
17966	Mochila de pellejo de Onyxia
17967	Escama refinada de Onyxia
17968	Escama cargada de Onyxia
17969	Saco de gemas rojo
17982	Núcleo de Ragnaros
18022	Lacre real de Alexis
18023	Colgante de rubí de sangre
18042	Espada con punta de torio
18043	Botas de minero de carbón
18044	Pichel de Hurley
18045	Chuleta de lobo tierno
18046	Receta: chuleta de lobo tierno
18047	Botos de llamas
18048	Martillo de maestro forjador
18082	Vara de irritación de Zum'rah
18083	Mandiletes jumanza
18102	Botas de jinete de dragón
18103	Sortija de Reflexión
18104	Faja Ola feral
18142	Cabeza decapitada de elfo de la noche
18143	Mechón de pelo de gnomo
18144	Astilla de hueso humano
18145	Pezuña tauren
18146	Mojo de trol Lanza Negra
18147	Corazón de los Renegados
18148	Cráneo de Korrak
18149	Runa de Recuerdo
18150	Runa de Recuerdo
18151	Ampolla de amatista llena
18152	Ampolla de amatista
18153	Gema Moro'gai roja
18154	Papel y sobres para cartas de Blizzard
18155	Gema Moro'gai azul
18156	Gema moro'gai verde
18157	Gema Moro'gai negra
18158	Gema Moro'gai de oro
18159	Gema Moro'gai blanca
18160	Receta: té de cardo
18168	Disco reactivo de potencia
18169	Manto del Alba flamígero
18170	Manto del Alba escarchado
18171	Manto arcano del Alba
18172	Manto Naturaleza del Alba
18173	Manto del Alba de las Sombras
18182	Manto del Alba cromático
18202	Garra izquierda de Eskhandar
18203	Garra derecha de Eskhandar
18204	Pelambre de Eskhandar
18205	Collar de Eskhandar
18206	Espinazo de enano
18207	Diente orco
18208	Mantón de Bendición
18209	Bujía cargada
18222	Vid espinosa
18223	Pétalo dentado
18224	Raíz de criminosa
18225	Zapatos de carrera desgastados
18226	Un pacto sellado
18227	Pacificador sin sustancia
18228	Foto autografiada de Tigule
18229	Guía de pesca extrema de Nat Pagle
18230	Botón G.A.N.O. roto
18231	Camiseta sin mangas
18232	Robot de reparación de campo 74A
18233	Pañuelo manchado de lágrimas
18234	Documentos de la importación de trabucos
18235	Esquema: robot de reparación de campo 74A
18236	Muñeco masticado de Gordok
18237	Mandíbula de mastín
18238	Guantes sombradermos
18239	Patrón: guantes sombradermos
18240	Tanino ogro
18241	Brida de corcel de guerra negro
18242	Riendas del tigre de guerra negro
18243	Embestidor negro
18244	Carnero de guerra negro
18245	Cuerno de lobo de guerra negro
18246	Silbato del raptor de guerra negro
18247	Kodo de guerra negro
18248	Caballo de guerra esquelético rojo
18249	Llave creciente
18250	Llave de los grilletes de Gordok
18251	Complemento para armadura del Núcleo
18252	Patrón: complemento para armadura del Núcleo
18253	Poción rejuvenecedora sublime
18254	Sorpresa de tubérculo runtún
18255	Tubérculo runtún
18256	Vial imbuida
18257	Receta: poción rejuvenecedora sublime
18258	Taje ogro de Gordok
18259	Fórmula: encantar arma: poder de hechizos
18260	Fórmula: encantar arma: poder de curación
18261	Libro sobre Conjuros
18262	Piedra de afilar elemental
18263	Brazaletes Bengala del Núcleo
18264	Diseño: piedra de afilar elemental
18265	Patrón: brazaletes Bengala del Núcleo
18266	Llave de patio de Gordok
18267	Receta: sorpresa de tubérculo runtún
18268	Llave de puerta interior de Gordok
18269	Grog verde de Gordok
18282	Rifle de tirador del Núcleo
18283	Acurascopio 247x128 Biznicks
18284	Cerveza paliza de Kreeg
18285	Fragmento de maná cristalizado
18286	Fragmento de maná condensado
18287	Siempreturbio
18288	Piroagua Molasses
18289	Collar de espino con púas
18290	Esquema: Acurascopio de 247x128 Biznicks
18291	Esquema: disco reactivo de potencia
18292	Esquema: rifle de tirador del Núcleo
18294	Elixir de respiración acuática superior
18295	Botas de fase
18296	Sortijas de tirador
18297	Semilla de espinazo
18298	Leotardos no domeñados
18299	Esencia de Hidromilecio
18300	Néctar de Hyjal
18301	Varita de Lethtendris
18302	Sortija de Vigor
18303	Rodela liviana
18304	Malla raíz verde
18305	Musleras arrecife
18306	Guantes de Niebla enigmática
18307	Zapatos corriente
18308	Sombrero ingenioso
18309	Guantes de Restauración
18310	Machete endemoniado
18311	Vara de mediación Quel'dorai
18312	Peto cargado
18313	Yelmo de Conciencia
18314	Anillo de Astucia demoníaca
18315	Anillo de Potencia demoníaca
18316	Adorno obsidiano
18317	Talismán de tempestad
18318	Grebas clementes
18319	Yelmo ferviente
18320	Bufas de corazón de demonio
18321	Vara energética
18322	Botas del canalón
18323	Arco de sátiro
18324	Cortaolas
18325	Almete pellejo inferi
18326	Guanteletes cuchilla
18327	Cordón de parral
18328	Capa Maderaoscura
18329	Arcano de Rapidez
18330	Arcano de Enfoque
18331	Arcano de Protección
18332	Tratado sobre Rapidez
18333	Tratado sobre Enfoque
18334	Tratado sobre Protección
18335	Diamante negro prístino
18336	Guante del Poderío de Gordok
18337	Brazales órficos
18338	Varita de Potencia arcana
18339	Capa de Eidolon
18340	Talismán de Eidolon
18341	Fajín Quel'dorai
18342	Integumento Quel'dorai
18343	Sortija petrificada
18344	Guanteletes Corteza de piedra
18345	Anillo murmurante
18346	Pantalones sin hilos
18347	Hacha bien equilibrada
18348	Quel'Serrar
18349	Guanteletes de Puntería
18350	Capa amplificadora
18351	Brazales sellados mágicamente
18352	Escudo de ladrido petrificado
18353	Bastón de piedra floreada
18354	Collar de Pimgib
18355	Collar de Ferra
18356	Garona: Un Estudio sobre el Sigilo y la Traición.
18357	Códice de Defensa
18358	El libro de cocina del arcanista
18359	La Luz y cómo alterarla
18360	Sombras acechadoras
18361	La mejor raza de cazadores
18362	Sagrada Bologna: lo que la Luz nunca te dirá
18363	El choque de Escarcha y tú
18364	El Sueño Esmeralda
18365	Una copia bien leída de "Pesca arriesgada con Nat Pagle".
18366	Manoplas de Gordok
18367	Guanteletes de Gordok
18368	Guantes de Gordok
18369	Mitones de Gordok
18370	Talismán de vigilancia
18371	Talismán de lectura mental
18372	Hoja de la Luna nueva
18373	Peto de Tranquilidad
18374	Hombreras con marcas de llamas
18375	Brazales del Eclipse
18376	Maza ajada
18377	Guantes rápidos
18378	Leotardos Lunargenta
18379	Grebas odiosas
18380	Quijotes reforzados de Eldritch
18381	Colgante de ojo malvado
18382	Capa oscilante
18383	Guanteletes imbuidos de potencia
18384	Bufas grabadas con bilis
18385	Toga de Noche perpetua
18386	Pantalones de Padre
18387	Guantes Chispa brillante
18388	Machacapiedras
18389	Capa del Cosmos
18390	Leotardos Mohomaraña
18391	Cordón Acecha ojos
18392	Daga de distracción
18393	Brazal Tuercemadera
18394	Muñequeras de grito de demonio
18395	Anillo de llama Esmeralda
18396	Tallador de mentes
18397	Colgante de mago anciano
18398	Aro de la marea
18399	Brisa del mar
18400	Anillo de Piedra viva
18401	Compendio de matar dragones de Nostro
18402	Anillo de cristal resplandeciente
18403	Sello de destripador de dragones
18404	Colgante de diente de Onyxia
18405	Cinturón del archimago
18406	Talismán de sangre de Onyxia
18407	Guantes de tela de inferi
18408	Guantes inferno
18409	Guantes de tela lunar
18410	Espada de esprínter
18411	Botas de soltura
18412	Fragmento del Núcleo
18413	Capa de Protección
18414	Patrón: cinturón del archimago
18415	Patrón: guantes de tela de inferi
18416	Patrón: guantes inferno
18417	Patrón: guantes de tela lunar
18418	Patrón: capa de Protección
18420	Aplastahuesos
18421	Yelmo provinciano
18422	Cabeza de Onyxia
18423	Cabeza de Onyxia
18424	Botas de juncia
18425	Jarra de Kreeg
18426	Tela de araña de Lethtendris
18427	Capa de sargento
18428	Insignia de capataz primero
18429	Brazales de placas de Gran capataz
18430	Brazales de placas de Gran capataz
18432	Muñequeras de malla de Gran capataz
18434	Guardabrazos de pellejo de dragón de Gran capataz
18435	Guardabrazos de cuero de Gran capataz
18436	Guardabrazos de pellejo de dragón de Gran capataz
18437	Puños de seda de Gran capataz
18438	Marca de sargento
18440	Manteo de sargento
18441	Manteo de sargento
18442	Insignia de sargento primero
18443	Insignia de sargento primero
18444	Insignia de sargento primero
18445	Muñequeras de placas de Alférez
18447	Muñequeras de placas de Alférez
18448	Guardabrazos de anillas de Alférez
18449	Guardabrazos de anillas de Alférez
18450	Toga de Combustión
18451	Cinturón de pellejo de hiena
18452	Braquiales de cuero de Alférez
18453	Braquiales de cuero de dragón de Alférez
18454	Braquiales de pellejo de dragón de Alférez
18455	Braquiales de pellejo de dragón de Alférez
18456	Puños de seda de Alférez
18457	Puños de seda de Alférez
18458	Guardabrazos modestos
18459	Muñequeras de galante
18460	Cañón de mano poco sofisticado
18461	Capa de sargento
18462	Puño de hueso dentado
18463	Cuchillo de bolsillo de ogro
18464	Pendiente de Gordok
18465	Lacre real de Eldre'Thalas
18466	Lacre real de Eldre'Thalas
18467	Lacre real de Eldre'Thalas
18468	Lacre real de Eldre'Thalas
18469	Lacre real de Eldre'Thalas
18470	Lacre real de Eldre'Thalas
18471	Lacre real de Eldre'Thalas
18472	Lacre real de Eldre'Thalas
18473	Lacre real de Eldre'Thalas
18475	Cinturón mágico curioso
18476	Botas manchadas de barro
18477	Leotardos peludos
18478	Chaleco de pellejo de hiena
18479	Yelmo de escórpido carroñero
18480	Yelmo de placas escarabajo
18481	Maza Aplastacalaveras
18482	Pistola de mondadientes de ogro
18483	Varita de mediación de maná
18484	Hoja de Cho'Rush
18485	Escudo de observador
18486	Toga de tela lunar
18487	Patrón: toga de tela lunar
18488	Hoja antigua caliente
18489	Espada antigua sin templar
18490	Caperuza de Perspicacia
18491	Hilador de conocimiento
18492	Espada antigua tratada
18493	Bufas de hierro grandes
18494	Hombreras de vigilante de cubil
18495	Capa de reducto
18496	Capa heliotropo
18497	Muñequeras sublimes
18498	Podadora
18499	Escudo barrera
18500	Anillo élfico deslustrado
18501	Fragmento de gangrevid
18502	Guja monstruosa
18503	Peto de Kromcrush
18504	Faja de Perspicacia
18505	Cinturón de Jarrager
18506	Botas de mangosta
18507	Botas de la Luna llena
18508	Brazales de Vuelo veloz
18509	Capa cromática
18510	Pellejo de las fieras
18511	Capa ondeante
18512	Ácido de larval
18513	Una hoja élfica apagada y lisa
18514	Patrón: faja de Perspicacia
18515	Patrón: botas de mangosta
18516	Patrón: brazales de Vuelo veloz
18517	Patrón: capa cromática
18518	Patrón: pellejo de las fieras
18519	Patrón: capa ondeante
18520	Hoja atroz
18521	Botas de metal mugrientas
18522	Sortija del Rey ogro
18523	Piedra con resplandor brillante
18524	Leotardos de Destrucción
18525	Brazales de Prosperidad
18526	Corona del Rey ogro
18527	Guanteletes armoniosos
18528	Bufas de ciclón
18529	Faja de placas elementales
18530	Camisote forjado de ogro
18531	Gran maza implacable
18532	Toga de oleada de mente
18533	Brazales de poder de Gordok
18534	Vara del Magi ogro
18535	Escudo de milicia
18536	Lexicón de milicia
18537	Magnetita de contraataque
18538	Aterratreants
18539	Relicario de Pureza
18540	Relicario de Pureza sellado
18541	Manteo enjundioso
18542	Tifón
18543	Anillo de Entropía
18544	Guanteletes de pellejo maldito
18545	Leotardos de Supremacía arcana
18546	Jaula de cabeza infernal
18547	Faja de hielo sin derretir
18562	Mena de elementium
18563	Brazales del Hijo del Viento
18564	Ataduras del Hijo del Viento
18567	Flujo elemental
18582	Las espadas gemelas de Azzinoth
18583	Guja de guerra de Azzinoth (derecha)
18584	Guja de guerra de Azzinoth (izquierda)
18585	Sortija de Lealtad
18586	Círculo de Soliárbol
18587	Pinzas de batería goblin XL
18588	Dinamita EZ-Thro 2
18590	Sangre de bestia enfurecida
18591	Caja de sangre
18592	Diseño: martillo de Sulfuron
18594	Carga de seforio potente
18595	Ópalo de sangre
18597	Silbato de huérfano orco
18598	Silbato de huérfano humano
18600	Escrito sobre Resplandor Arcano
18601	Prisión de cristal resplandeciente
18602	Escrito sobre Sacrificio
18603	Sangre de sátiro
18604	Lágrimas de los Hederine
18605	Guardia apocalíptico encarcelado
18606	Estandarte de batalla de la Alianza
18607	Estandarte de batalla de la Horda
18608	Bendición
18609	Anatema
18610	Machete cortante
18611	Leotardos Tuercepinos
18612	Botas de anillas sangrientas
18622	Esencia de inferi impecable (Jaedenar)
18623	Esencia de inferi impecable (Portal oscuro)
18624	Esencia de inferi impecable (Azshara)
18625	Núcleo infernal de Kroshius
18626	Fuego inferi
18627	Gong de Dethmoora
18628	Contrato de la Hermandad del Torio
18629	Magnetita negra
18630	Llama del Día del Juicio Final
18631	Transformador de veraplata
18632	Caramelo de los disturbios de Arroyo de la Luna
18633	Piruleta de Styleen
18634	Refractor de hielo Girohielo
18635	Barra de nueces de Bellara
18636	Pinzas de batería estropeadas XL
18637	Recombobulador sublime
18638	Refractor de llamas hiperradiante
18639	Reflector de sombras ultra-flash
18640	Roca de diversión
18641	Dinamita densa
18642	Autógrafo de Jaina
18643	Marca de la pezuña de Cairne
18645	Roboalarma gnómica
18646	El Ojo de Divinidad
18647	Esquema: fuego artificial rojo
18648	Esquema: fuego artificial verde
18649	Esquema: fuego artificial azul
18650	Esquema: dinamita EZ-Thro 2
18651	Esquema: transformador de veraplata
18652	Esquema: refractor de hielo Girohielo
18653	Esquema: pinzas de batería goblin XL
18654	Esquema: robot alarma gnómico
18655	Esquema: recombobulador sublime
18656	Esquema: carga de seforio potente
18657	Esquema: refractor de llamas hiperradiante
18658	Esquema: reflector de sombras ultra-flash
18659	Astilla de Nordrassil
18660	Amplificador de mundo
18661	Esquema: amplificador de mundo
18662	Bola de cuero pesado
18663	Jarra de J'eevee
18664	Un tratado sobre rangos militares
18665	El Ojo de las Sombras
18670	Glifos xorotianos
18671	Cetro del barón Charr
18672	Elemental de ámbar
18673	Pellejo pedregoso de Avalanchion
18674	Sortija de piedra endurecida
18675	Rangos militares de la Horda y Alianza
18676	Fajín del Asaltavientos
18677	Capa Céfiro
18678	Collar helado de Tempestria
18679	Anillo frígido
18680	Arco de hueso antiguo
18681	Chal de entierro
18682	Leotardos de piel de necrófago
18683	Martillo de la Víspera
18684	Anillo opalescente oscuro
18686	Hombreras de huesos de gólem
18687	Polvo estelar xorotiano
18688	Diablillo en una jarra
18689	Capa fantasmal
18690	Leotardos de placas de aparición
18691	Colgante de consejero oscuro
18692	Escarpes de caballero de la Muerte
18693	Mitones escalofrío
18694	Grebas de malla enigmáticas
18695	Escrito vinculado
18696	Escudo con un intrincado adorno de runas
18697	Zapatillas piedrafría
18698	Caperuza de cuero andrajoso
18699	Hombreras de tumba heladas
18700	Brazales maléficos
18701	Sortija de estimulación
18702	Cinturón de la Ordenación
18703	Hoja petrificada vieja
18704	Tendón de dragón azul maduro
18705	Tendón de dragón negro maduro
18706	Maestro de arena
18707	Bastón grabado con runas antigua
18708	Ladrido petrificado
18709	Muñequeras de arena
18710	Brazales de arena
18711	Sortijas de arena
18712	Protegebrazos de arena
18713	Rhok'delar, arco largo de los Guardianes ancianos
18714	Antigua lámina envuelta en tendones
18715	Lok'delar, bastón de los Guardianes ancianos
18716	Botas cubiertas de ceniza
18717	Martillo del Gran cruzado
18718	Yelmo de cruzado grandioso
18719	El corazón del traidor
18720	Sudario de Nathrezim
18721	Faja de bombardeo
18722	Mandiletes de la Muerte
18723	Collar de anillas animado
18724	Tendón de dragón negro encantado
18725	Pacificador
18726	Puños de magistrado
18727	Sombrero de fieltro carmesí
18728	Reliquia de Anastari
18729	Arco chirrido
18730	Mitones con encaje enigmáticos
18731	Patrón: bola de cuero pesado
18734	Capa de luna pálida
18735	Borceguíes de Maleki
18736	Leotardos de can de la Peste
18737	Hachuela rebanadora de huesos
18738	Ballesta de caparazón espinoso
18739	Musleras de placas de quitina
18740	Fajín Thuzadin
18741	Brazal de Morlune
18742	Guardahombros de la milicia de Stratholme
18743	Manteo lujoso
18744	Guantes de piel de murcípeste
18745	Leotardos de paño sacro
18746	Arúspice
18747	Prueba de propiedades de objeto
18749	Alma perdida de cargador
18752	Incensario de exorcismo
18753	Gualdrapa de arcanita
18754	Brazales endurecidos de inferi
18755	Palo de fuego xorotiano
18756	Protector del Guardia del Terror
18757	Manto diabólico
18758	Espada de espectro
18759	Hacha maliciosa
18760	Sortija necromántica
18761	Toque de olvido
18762	Fragmento de la Llama verde
18766	Riendas del sable de hielo ágil
18767	Riendas del sable de niebla ágil
18768	Riendas del sable del Alba ágil
18769	Malla de placas de torio encantado
18770	Malla de placas de torio encantado
18771	Malla de placas de torio encantado
18772	Mecazancudo verde veloz
18773	Mecazancudo blanco veloz
18774	Mecazancudo amarillo veloz
18775	Alimento paca caballos con maná enriquecido
18776	Palomino veloz
18777	Corcel marrón veloz
18778	Corcel blanco veloz
18779	Mitad inferior de Herrería de armaduras avanzada: Volumen 1
18780	Mitad superior de Herrería de armaduras avanzada: Volumen 1
18781	Mitad inferior de Herrería de armaduras avanzada: Volumen 2
18782	Mitad superior de Herrería de armaduras avanzada: Volumen 2
18783	Mitad inferior de Herrería de armaduras avanzada: Volumen 3
18784	Mitad superior de Herrería de armaduras avanzada: Volumen 3
18785	Carnero blanco veloz
18786	Carnero marrón veloz
18787	Carnero gris veloz
18788	Raptor azul veloz
18789	Raptor oliva veloz
18790	Raptor naranja veloz
18791	Caballo de guerra esquelético morado
18792	Gualdrapa de arcanita bendita
18793	Gran kodo blanco
18794	Gran kodo marrón
18795	Gran kodo gris
18796	Cuerno del lobo marrón veloz
18797	Cuerno del lobo maderero veloz
18798	Cuerno del lobo gris veloz
18799	Alma redimida de cargador
18802	Poción enigmática
18803	Dragador de lava hipertérmicamente aislado
18804	Cartera de Lord Grayson
18805	Diente de can del Núcleo
18806	Grebas forjadas del Núcleo
18807	Yelmo de Poder latente
18808	Guantes de la Llama hipnótica
18809	Fajín de los Secretos susurrados
18810	Bufas de crecimiento salvaje
18811	Capa a prueba de fuego
18812	Muñequeras de Auténtico Vuelo
18813	Anillo de Vínculo
18814	Gargantilla del Señor del Fuego
18815	Esencia de la llama pura
18816	Hoja de Perdición
18817	Corona de Destrucción
18818	Instrucciones de Mor'zul
18819	Incensario de exorcismo de Rohan
18820	Talismán de Poder efímero
18821	Anillo de golpe rápido
18822	Hoja afilada obsidiana
18823	Guantes viejos de cuero del Núcleo
18824	Botas templadas de magma
18825	Égida de Gran Mariscal
18826	Escudo de pared de Gran Señor de la Guerra
18827	Hacha de mano de Gran mariscal
18828	Cuchilla de Gran Señor de la Guerra
18829	Bufas del interior de la tierra
18830	Taladora de Gran mariscal
18831	Hacha de batalla de Gran Señor de la Guerra
18832	Hoja de brutalidad
18833	Diana de Gran mariscal
18834	Insignia de la Horda
18835	Arco corvo de Gran Señor de la Guerra
18836	Repetidor de Gran mariscal
18837	Ballesta de Gran Señor de la Guerra
18838	Daga dirk de Gran mariscal
18839	Poción de curación de combate
18840	Cuchilla de Gran Señor de la Guerra
18841	Poción de maná de combate
18842	Bastón de Dominio
18843	Hoja de mano derecha de Gran mariscal
18844	Garra derecha de Gran Señor de la Guerra
18845	Insignia de la Horda
18846	Insignia de la Horda
18847	Hoja de mano izquierda de Gran mariscal
18848	Garra izquierda de Gran Señor de la Guerra
18849	Insignia de la Horda
18850	Insignia de la Horda
18851	Insignia de la Horda
18852	Insignia de la Horda
18853	Insignia de la Horda
18854	Insignia de la Alianza
18855	Cañón de mano de Gran mariscal
18856	Insignia de la Alianza
18857	Insignia de la Alianza
18858	Insignia de la Alianza
18859	Insignia de la Alianza
18860	Limpiacalles de Gran Señor de la Guerra
18861	Quijote de caminante flamígero
18862	Insignia de la Alianza
18863	Insignia de la Alianza
18864	Insignia de la Alianza
18865	Castigadora de Gran mariscal
18866	Cachiporra de Gran Señor de la Guerra
18867	Martillo de batalla de Gran mariscal
18868	Pulverizador de Gran Señor de la Guerra
18869	Guja de Gran mariscal
18870	Yelmo del Dador de vida
18871	Pica de cerdos de Gran Señor de la Guerra
18872	Leotardos de tormenta de maná
18873	Bastón de Gran mariscal
18874	Bastón de guerra de Gran Señor de la Guerra
18875	Pantalones de escamas de salamandra
18876	Espada claymore de Gran mariscal
18877	Espada magna de Gran Señor de la Guerra
18878	Daga de hechicero
18879	Anillo pesado de Hierro Negro
18880	Cabeza de Atracoscuro
18902	Riendas del sable de tormenta ágil
18904	Ultra-reductor de Zorbin
18922	Diseños Secretos: flujo ígneo
18942	Flujo ígneo
18943	Almohada Hierro Negro
18944	Escama de incendosaurio
18945	Residuo Hierro Negro
18946	Cabeza del sobrestante Maltorius
18947	Pellejo de yeti de Cicatriz de ira
18948	Brazales barbáricos
18949	Patrón: brazales barbáricos
18950	Almohada de la ayudante de cámara Pilaprieta
18951	Pilar de aterrizaje de Evonice
18952	Cabeza de Simone
18953	Cabeza de Klinfran
18954	Cabeza de Solenor
18955	Cabeza de Artorius
18956	Resíduo de reducción
18957	Hoja Leñomaleza
18958	Núcleo elemental de Agua
18959	Tobera de herrería
18960	Telescopio de vigía
18961	Caparazón Zukk'ash
18962	Glándulas de Aguijolatigador
18963	Huevo de tortuga (albino)
18964	Huevo de tortuga (leñobeza)
18965	Huevo de tortuga (alconil)
18966	Huevo de tortuga (cuerospalda)
18967	Huevo de tortuga (oliva)
18969	Pellejo de yeti prístino
18972	Pellejo de yeti perfecto
18984	Desgarrador dimensional: Vista Eterna
18986	Transportador ultraseguro: Gadgetzan
18987	Orden de Puño Negro
19002	Cabeza de Nefarian
19003	Cabeza de Nefarian
19004	Piedra de salud menor
19005	Piedra de salud menor
19006	Piedra de salud inferior
19007	Piedra de salud inferior
19008	Piedra de salud
19009	Piedra de salud
19010	Piedra superior de salud
19011	Piedra superior de salud
19012	Piedra de salud sublime
19013	Piedra de salud sublime
19016	Vasija de renacimiento
19017	Esencia del Señor del Fuego
19018	Hoja besada por el viento durmiente
19019	Trueno furioso, espada bendita del Hijo del Viento
19020	Informe del campamento Mojache Zukk'ash
19022	Pescador extremo de Nat Pagle FC-5000
19023	Cebo más preciado de Katoom
19024	Gran maestro de arena
19025	Penacho de Señor del Cielo
19026	Fuego artificial con forma de serpiente
19027	Esquema: fuego artificial con forma de serpiente
19028	Vestido elegante
19029	Cuerno del camorrista Lobo Gélido
19030	Caballo de batalla de Pico Tormenta
19031	Tabardo de batalla Lobo Gélido
19032	Tabardo de batalla de Pico Tormenta
19033	Herramientas perdidas de Esco
19034	Almuerzo de Lard
19035	Cesta de picnic especial de Lard
19036	Mensaje final a Martillo Salvaje
19037	Bufas de pico Esmeralda
19038	Anillo de Sutileza
19039	Sombrero resistente al agua de Zorbin
19040	Megarrebanador de Zorbin
19041	Túnica hecha a mano de Pratt
19042	Túnica hecha a mano de Jangdor
19043	Cinturón Fauces de Madera pesado
19044	Poderío de los Fauces de Madera
19045	Estandarte de batalla de Pico Tormenta
19046	Estandarte de batalla Lobo Gélido
19047	Sabiduría de los Fauce de Madera
19048	Botas Fauces de Madera pesadas
19049	Camorristas Fauces de Madera
19050	Manto de los Fauces de Madera
19051	Faja del Alba
19052	Botines del Alba
19054	Red Dragon Orb
19055	Green Dragon Orb
19056	Botas Argenta
19057	Guantes del Alba
19058	Manto dorado del Alba
19059	Hombreras Argenta
19060	Ración enriquecida del Barranco Grito de Guerra
19061	Ración de hierro del Barranco Grito de Guerra
19062	Ración de campo del Barranco Grito de Guerra
19064	Llave de grillete
19065	Círculo Esmeralda
19066	Venda de paño rúnico del Barranco Grito de Guerra
19067	Venda de paño mágico del Barranco Grito de Guerra
19068	Venda de seda del Barranco Grito de Guerra
19069	Calavera del cazador Malkhor
19070	Huesos del cazador Malkhor
19071	Vasija de sangre corrupta
19083	Capa de legionario Lobo Gélido
19084	Capa de soldado de Pico Tormenta
19085	Capa de consejero Lobo Gélido
19086	Capa de sabio de Pico Tormenta
19087	Cinturón de Lobo Gélido
19088	Cinturón de malla Lobo Gélido
19089	Cinturón de cuero Lobo Gélido
19090	Cinturón de paño Lobo Gélido
19091	Faja de placas de Pico Tormenta
19092	Faja de malla de Pico Tormenta
19093	Faja de cuero de Pico Tormenta
19094	Faja de paño de Pico Tormenta
19095	Colgante de legionario Lobo Gélido
19096	Colgante de consejero Lobo Gélido
19097	Colgante de soldado de Pico Tormenta
19098	Colgante de sabio de Pico Tormenta
19099	Hoja glacial
19100	Daga electrificada
19101	Bastón de tormenta de nieve
19102	Bastón que cruje
19103	Bocado helado
19104	Martillo Golpe de tormenta
19105	Penacho rúnico escarchado
19106	Lanza con punta de hielo
19107	Buscasangre
19108	Varita de Frío cortante
19109	Anillo raíces profundas
19110	Hoja forjada en frío
19111	Insignias de Hacha Invernal
19112	Protegebrazos de acero congelados
19113	Brazales de pellejo de yeti
19114	Arco de tierra alta
19115	Frasco de mojo del bosque
19116	Mitones hojaverde
19117	Quijotes de placas de madera lacadas
19118	Aliento de la Naturaleza
19119	Guantes de pellejo de lechubestia
19120	Runa del Capitán guardia
19121	Capa del bosque profundo
19123	Mitones siermpre cálidos
19124	Leotardos de placas de escoria
19125	Faja de malla chamuscada
19126	Guanteletes de placas de escoria
19127	Túnica de cuero carbonizada
19128	Jubón de malla chamuscado
19129	Toga Resplandor eterno
19130	Mordedura helada
19131	Zapatos Cieganieve
19132	Corona adornada con cristales
19133	Leotardos imbuidos de inferi
19134	Cinturón de piel de guardia apocalíptico
19135	Brazal de luz negra
19136	Cordón de ignición de maná
19137	Faja de avalancha
19138	Sortija de Sulfuras
19139	Hombreras de guardia de Fuego
19140	Sortija de cauterización
19141	Luffa
19142	Grimorio rúnico de fuego
19143	Guanteletes de guardia de llamas
19144	Escarpes del Caminante sobre llamas
19145	Toga de Poder volátil
19146	Muñequeras de Estabilidad
19147	Anillo de poder con hechizos
19148	Yelmo Hierro Negro
19149	Cinturón de lava
19150	Paquete de curación básico de centinela
19151	Paquete de curación estándar de centinela
19152	Paquete de curación avanzado de centinela
19153	Paquete de curación avanzado de escolta
19154	Paquete de curación elemental de escolta
19155	Paquete de curación normal de escolta
19156	Toga Bengala del Núcleo
19157	Guanteletes cromáticos
19159	Collar de tejido de hiedra
19160	Tabardo de ganador de concurso
19162	Cinturón de can del Núcleo
19163	Cinturón de arrabio
19164	Guanteletes Hierro Negro
19165	Leotardos Bengala del Núcleo
19166	Amnistía negra
19167	Furianegra
19168	Guardanegro
19169	Ocaso
19170	Mano de ébano
19182	Vale para la Feria de la Luna Negra
19183	Arena de reloj de arena
19202	Diseño: cinturón Fauces de Madera pesado
19203	Diseño: faja del Alba
19204	Diseño: botas Fauces de Madera pesadas
19205	Diseño: guantes del Alba
19206	Diseño: yelmo Hierro Negro
19207	Diseño: guanteletes Hierro Negro
19208	Diseño: amnistía negra
19209	Diseño: Furianegra
19210	Diseño: mano de ébano
19211	Diseño: guardanegro
19212	Diseño: ocaso
19213	Talismán de Mérito Ala de Plata
19215	Patrón: sabiduría de los Fauces de Madera
19216	Patrón: botas Argenta
19217	Patrón: hombreras Argenta
19218	Patrón: manto de los Fauces de Madera
19219	Patrón: toga Bengala del Núcleo
19220	Patrón: leotardos Bengala del Núcleo
19221	Gran reserva Luna Negra
19222	Cerveza barata
19223	Perro Luna Negra
19224	Alitas súper picantes
19225	Chocolatina frita
19227	As de Bestias
19228	Baraja de Bestias
19229	Fortuna de Sayge #1
19230	Dos de Bestias
19231	Tres de bestias
19232	Cuatro de Bestias
19233	Cinco de Bestias
19234	Seis de bestias
19235	Siete de bestias
19236	Ocho de Bestias
19237	Fortuna de Sayge #19
19238	Fortuna de Sayge #3
19239	Fortuna de Sayge #4
19240	Fortuna de Sayge #5
19241	Fortuna de Sayge #6
19242	Fortuna de Sayge #7
19243	Fortuna de Sayge #8
19244	Fortuna de Sayge #9
19245	Fortuna de Sayge #10
19246	Fortuna de Sayge #11
19247	Fortuna de Sayge #12
19248	Fortuna de Sayge #13
19249	Fortuna de Sayge #14
19250	Fortuna de Sayge #15
19251	Fortuna de Sayge #16
19252	Fortuna de Sayge #18
19253	Fortuna de Sayge #17
19254	Fortuna de Sayge #21
19255	Fortuna de Sayge #22
19256	Fortuna de Sayge #2
19257	Baraja de Señor de la Guerra
19258	As de Señores de la Guerra
19259	Dos de Señores de la Guerra
19260	Tres de Señores de la Guerra
19261	Cuatro de Señores de la Guerra
19262	Cinco de Señores de la Guerra
19263	Seis de Señores de la Guerra
19264	Siete de Señores de la Guerra
19265	Ocho de Señores de la Guerra
19266	Fortuna de Sayge #20
19267	Baraja de Elementales
19268	As de Elementales
19269	Dos de Elementales
19270	Tres de elementales
19271	Cuatro de Elementales
19272	Cinco de Elementales
19273	Seis de elementales
19274	Siete de elementales
19275	Ocho de Elementales
19276	As de Portales
19277	Baraja de Portales
19278	Dos de Portales
19279	Tres de portales
19280	Cuatro de Portales
19281	Cinco de Portales
19282	Seis de portales
19283	Siete de portales
19284	Ocho de Portales
19287	Carta de la Luna Negra: Heroísmo
19288	Carta de la Luna Negra: Dragón azul
19289	Carta de la Luna Negra: La Vorágine
19290	Carta de la Luna Negra: El Vacío Abisal
19291	Caja para guardar de la Luna Negra
19292	Añojo del mes pasado
19293	Añojo del año pasado
19295	Flor de la Luna Negra
19296	Premio superior Luna Negra
19297	Premio de la Luna Negra inferior
19298	Premio de la Feria de Luna Negra menor
19299	Bebida de feria con burbujas
19300	Agua de Cuna del Invierno embotellada
19301	Galleta de maná de Alterac
19302	Anillo de la Luna Negra
19303	Collar de la Luna Negra
19304	Cecina de ternera picante
19305	Pie de kodo en vinagre
19306	Rana crujiente
19307	Venda de paño rúnico grueso de Alterac
19308	Escrito sobre Dominación Arcana
19309	Escrito sobre Potencia de las Sombras
19310	Escrito del Señor del Hielo
19311	Escrito sobre Arcana ígnea
19312	Leu del Vivificador
19315	Toque de Therazane
19316	Flecha con hielo
19317	Bala con hielo
19318	Agua de manantial de Alterac embotellada
19319	Carcaj de pellejo de arpía
19320	Bandolera de piel de gnoll
19321	El objeto indomable
19322	Marca de Honor Grito de Guerra
19323	La potencia imparable
19324	El lobotomizador
19325	Sortija de Don Julio
19326	Patrón: poderío de los Fauces de Madera
19327	Patrón: camorristas Fauces de Madera
19328	Patrón: botines del Alba
19329	Patrón: manto dorado del Alba
19330	Patrón: cinturón de lava
19331	Patrón: guanteletes cromáticos
19332	Patrón: cinturón del can del Núcleo
19333	Patrón: cinturón de arrabio
19334	La espada indomable
19335	Machacapúas
19336	Gema Arcana imbuida
19337	El libro negro
19338	Vale de entrada gratuita
19339	Gema de aceleración mental
19340	Runa de Metamorfosis
19341	Gema dadora de vida
19342	Tótem venenoso
19343	Pergaminos de Luz cegadora
19344	Cristal de alineación natural
19345	Égida de preservación
19346	Hoja colmillo de dragón
19347	Garra de Chromaggus
19348	Protector de escamas de dragón rojo
19349	Baluarte reforzado de elementium
19350	Apuntacorazones
19351	Maladath, Hoja rúnica del Vuelo Negro
19352	Espada templada cromáticamente
19353	Cuchilla de colmillo de draco
19354	Vengador dracónico
19355	Bastón de enfoque del ala de las Sombras
19356	Bastón de la Sombra en llamas
19357	Heraldo de tragedia
19358	Gran maza dracónica
19360	Lok'amir il Romathis
19361	Ashjre'thul, Ballesta de paliza
19362	Filo de la Condena
19363	Crul'shorukh, Filo del Caos
19364	Ashkandi, Gran espada de la Hermandad
19365	Garra del draco negro
19366	Orbe de cazador de dragones
19367	Toque de dragón
19368	Cañón de mano aliento de dragón
19369	Guantes de Evolución rápida
19370	Manto del Conciliábulo Alanegra
19371	Colgante del Dragón Caído
19372	Yelmo de Ira infinita
19373	Espaldares de camada negra
19374	Brazales de Precisión arcana
19375	Mish'undare, Aro del Despelleja Almas
19376	Anillo de juicio de Archimtiros
19377	Talismán de connivencia de Prestor
19378	Capa del Señor de la camada
19379	Lágrima de Neltharion
19380	Eslabón de Therazane
19381	Botas de la Llama de sombras
19382	Sortija de elementium puro
19383	Medallón de cazador de dragones
19384	Anillo de cazador de dragones
19385	Leotardos con poderes
19386	Capa tejida con elementium
19387	Botas cromáticas
19388	Garra de Angelista
19389	Hombreras de pellejo de dragón tirante
19390	Guantes de pellejo de dragón tirante
19391	Geta fulgurante
19392	Faja de Cruzado caído
19393	Guardarrenes enlazados de primalista
19394	Espaldares de talón de draco
19395	Gema rejuvenecedora
19396	Cinturón de pellejo de dragón tirante
19397	Anillo de Roca Negra
19398	Capa de Faucefuego
19399	Toga de ceniza negra
19400	Garra de buche de fuego
19401	Musleras enlazadas de primalista
19402	Musleras de Cruzado caído
19403	Sortija de Concentración forzada
19405	Baluarte bendito de Malfurión
19406	Talismán de colmillo de draco
19407	Guantes de llamas de ébano
19422	Fortuna de la Feria de la Luna Negra
19423	Fortuna de Sayge #23
19424	Fortuna de Sayge #24
19425	Arcón misterioso
19426	Orbe de la Luna Negra
19430	Sudario de Pensamiento puro
19431	Escarabajo inminente de Styleen
19432	Círculo de Potencia aplicada
19433	Leotardos de tejido de ascuas
19434	Sortija del Dominio oscuro
19435	Recolector de esencia
19436	Capa de Poderío dracónico
19437	Botas de pensamiento puro
19438	Botas de Ventisca de Ringo
19439	Chaleco de las Sombras entrelazado
19440	Antídoto potente
19441	Glándula de veneno enorme
19442	Fórmula: antídoto potente
19443	Fortuna de Sayge #25
19444	Fórmula: encantar arma: fuerza
19445	Fórmula: encantar arma: agilidad
19446	Fórmula: encantar brazal: regeneración de maná
19447	Fórmula: encantar brazal: curación
19448	Fórmula: encantar arma: espíritu poderoso
19449	Fórmula: encantar arma: intelecto poderoso
19450	Una casita de Jubling
19451	Fortuna de Sayge #26
19452	Fortuna de Sayge #27
19453	Fortuna de Sayge #28
19454	Fortuna de Sayge #29
19462	Huevo sin abrir de Jubling
19482	Pelambre de conejo L'Artesano
19483	Pelando la cebolla
19484	La alcachofa Lobo Gélido
19491	Amuleto de la Luna Negra
19505	Tabardo de batalla Grito de Guerra
19506	Tabardo de batalla Ala de Plata
19507	Chal de inquisidor
19508	Brazales de cuero marcado
19509	Botas de malla polvorientas
19510	Sortija de legionario
19511	Sortija de legionario
19512	Sortija de legionario
19513	Sortija de legionario
19514	Sortija de protector
19515	Sortija de protector
19516	Sortija de protector
19517	Sortija de protector
19518	Anillo de consejero
19519	Anillo de consejero
19520	Anillo de consejero
19521	Anillo de consejero
19522	Anillo del guardián del Conocimiento
19523	Anillo del guardián del Conocimiento
19524	Anillo del guardián del Conocimiento
19525	Anillo del guardián del Conocimiento
19526	Capa de curador de batalla
19527	Capa de curador de batalla
19528	Capa de curador de batalla
19529	Capa de curador de batalla
19530	Manteo de cuidador
19531	Manteo de cuidador
19532	Manteo de cuidador
19533	Manteo de cuidador
19534	Medallón de explorador
19535	Medallón de explorador
19536	Medallón de explorador
19537	Medallón de explorador
19538	Medallón de centinela
19539	Medallón de centinela
19540	Medallón de centinela
19541	Medallón de centinela
19542	Hoja de explorador
19543	Hoja de explorador
19544	Hoja de explorador
19545	Hoja de explorador
19546	Hoja de centinela
19547	Hoja de centinela
19548	Hoja de centinela
19549	Hoja de centinela
19550	Espada de legionario
19551	Espada de legionario
19552	Espada de legionario
19553	Espada de legionario
19554	Espada de protector
19555	Espada de protector
19556	Espada de protector
19557	Espada de protector
19558	Arco de escolta
19559	Arco de escolta
19560	Arco de escolta
19561	Arco de escolta
19562	Arco de avanzado
19563	Arco de avanzado
19564	Arco de avanzado
19565	Arco de avanzado
19566	Bastón nudoso de consejero
19567	Bastón nudoso de consejero
19568	Bastón nudoso de consejero
19569	Bastón nudoso de consejero
19570	Bastón del guardián del Conocimiento
19571	Bastón del guardián del Conocimiento
19572	Bastón del guardián del Conocimiento
19573	Bastón del guardián del Conocimiento
19574	Fuerza de Mugamba
19575	Fuerza de Mugamba
19576	Fuerza de Mugamba
19577	Ira de Mugamba
19578	Brazales de rabioso
19579	Prenda de Heathen
19580	Brazales de rabioso
19581	Brazales de rabioso
19582	Muñequeras de soplaviento
19583	Muñequeras de soplaviento
19584	Muñequeras de soplaviento
19585	Prenda de Heathen
19586	Prenda de Heathen
19587	Brazales de Acechador de bosque
19588	Prenda de héroe
19589	Brazales de Acechador de bosque
19590	Brazales de Acechador de bosque
19591	El Ojo de Zuldazar
19592	El Ojo de Zuldazar
19593	El Ojo de Zuldazar
19594	El Ojo que todo lo ve de Zuldazar
19595	Ataduras de muñeca de la Dríada
19596	Ataduras de muñeca de la Dríada
19597	Ataduras de muñeca de la Dríada
19598	Guijarro de Kajaro
19599	Guijarro de Kajaro
19600	Guijarro de Kajaro
19601	Joya de Kajaro
19602	Mancha de Kezan
19603	Mancha de Kezan
19604	Mancha de Kezan
19605	Mancha imparable de Kezan
19606	Visión de Voodress
19607	Visión de Voodress
19608	Visión de Voodress
19609	Visión impecable de Voodress
19610	Kelp de los Mares del Sur encantado
19611	Kelp de los Mares del Sur encantado
19612	Kelp de los Mares del Sur encantado
19613	Alga prístina encantada de los Mares del Sur
19614	Talismán de las Sombras Zandalar
19615	Talismán de las Sombras Zandalar
19616	Talismán de las Sombras Zandalar
19617	Talismán de maestría de las Sombras Zandalar
19618	Zarcillo de Maelstrom
19619	Zarcillo de Maelstrom
19620	Zarcillo de Maelstrom
19621	Cólera de Maelstrom
19642	iCoke Prize Voucher
19682	Jubón Vid de sangre
19683	Leotardos Vid de sangre
19684	Botas Vid de sangre
19685	Chaleco de piel de murciélago primigenio
19686	Guantes de piel de murciélago primigenio
19687	Brazales de piel de murciélago primigenio
19688	Peto de tigre de sangre
19689	Hombreras de tigre de sangre
19690	Peto alma de sangre
19691	Hombreras alma de sangre
19692	Guanteletes alma de sangre
19693	Peto Almanegra
19694	Leotardos Almanegra
19695	Hombreras Almanegra
19696	Pan de la cosecha
19697	Recompensa de la Cosecha
19698	Moneda Zulian
19699	Moneda Razzashi
19700	Moneda Hakkari
19701	Moneda Gurubashi
19702	Moneda Vilrama
19703	Moneda Secacorteza
19704	Moneda Furiarena
19705	Moneda Machacacráneos
19706	Moneda Sangrapellejo
19707	Joya Hakkari roja
19708	Joya Hakkari azul
19709	Joya Hakkari amarilla
19710	Joya Hakkari naranja
19711	Joya Hakkari verde
19712	Joya Hakkari morada
19713	Joya Hakkari de bronce
19714	Joya de plata Hakkari
19715	Joya Hakkari de oro
19716	Ataduras Hakkari primigenias
19717	Cabestrillo Hakkari primigenio
19718	Puntal Hakkari primigenio
19719	Faja Hakkari primigenia
19720	Fajín Hakkari primigenio
19721	Chal Hakkari primigenio
19722	Tabardo Hakkari primigenio
19723	Casaca Hakkari primigenia
19724	Égida Hakkari primigenia
19725	Cajón de recursos de Arathi
19726	Vid de sangre
19727	Guadaña de sangre
19764	Patrón: jubón Vid de sangre
19765	Patrón: leotardos Vid de sangre
19766	Patrón: botas Vid de sangre
19767	Cuero de murciélago primigenio
19768	Cuero de tigre primigenio
19769	Patrón: chaleco de piel de murciélago primigenio
19770	Patrón: guantes de piel de murciélago primigenio
19771	Patrón: brazales de piel de murciélago primigenio
19772	Patrón: peto de tigre de sangre
19773	Patrón: hombreras de tigre de sangre
19774	Almarita
19775	Bolsa azur sellada
19776	Diseño: peto alma de sangre
19777	Diseño: hombreras alma de sangre
19778	Diseño: guanteletes alma de sangre
19779	Diseño: peto Almanegra
19780	Diseño: leotardos Almanegra
19781	Diseño: hombreras Almanegra
19782	Presencia de Poderío
19783	Sigilo de Sincretista
19784	Abrazo de la Muerte
19785	Llamada de halcón
19786	Abrazo vigilante de Vodouisant
19787	Presencia de Vista
19788	Maleficio gafado
19789	Aura profética
19790	Caricia de animista
19802	Corazón de Hakkar
19803	Corredor a rayas azules de Brownell
19804	Pez demonio pálido
19805	Pez ángel de Keefer
19806	Pez reina de Dezian
19807	Pezrico moteado
19808	Potenpez Pellejo de Roca
19812	Runa del Alba
19813	Muñeco de vudú perforado
19814	Muñeco de vudú perforado
19815	Muñeco de vudú perforado
19816	Muñeco de vudú perforado
19817	Muñeco de vudú perforado
19818	Muñeco de vudú perforado
19819	Muñeco de vudú perforado
19820	Muñeco de vudú perforado
19821	Muñeco de vudú perforado
19822	Peto de vindicador Zandalar
19823	Cinturón de vindicador Zandalar
19824	Guardabrazos de vindicador Zandalar
19825	Peto de Librepensador Zandalar
19826	Cinturón de Librepensador Zandalar
19827	Guardabrazos de Librepensador Zandalar
19828	Camisote de Augur Zandalar
19829	Cinturón de Augur Zandalar
19830	Brazales de Augur Zandalar
19831	Manto de predador Zandalar
19832	Cinturón de predador Zandalar
19833	Brazales de predador Zandalar
19834	Túnica de sinconcierto Zandalar
19835	Manto de sinconcierto Zandalar
19836	Brazales de sinconcierto Zandalar
19838	Túnica de adivino Zandalar
19839	Cinturón de adivino Zandalar
19840	Brazales de adivino Zandalar
19841	Manto de Confesor Zandalar
19842	Ataduras de Confesor Zandalar
19843	Brazaletes de Confesor Zandalar
19845	Manto de ilusionista Zandalar
19846	Brazaletes de ilusionista Zandalar
19848	Brazaletes de Demoníaco Zandalar
19849	Manto de Demoníaco Zandalar
19850	Tributo de Uther
19851	Tributo a Grom
19852	Destripahombre Hakkari antiguo
19853	Destructor de enanos Gurubashi
19854	Zin'rokh el Destructor de Mundos
19855	Quijotes empapados de sangre
19856	El Ojo de Hakkar
19857	Capa de Consumo
19858	Muestra de honor Zandalar
19859	Colmillo del Ignoto
19861	Toque del Caos
19862	Égida del Dios de la Sangre
19863	Lacre de primalista
19864	Llamasangre
19865	Espada de guerra de los Hakkari
19866	Espada de guerra de los Hakkari
19867	Defensor del Señor de la Sangre
19869	Mandiletes empapados de sangre
19870	Capa loa Hakkari
19871	Talismán de Protección
19872	Raptor Razzashi veloz
19873	Sortija carmesí de Señor Supremo
19874	Alabarda de herrero
19875	Almófar manchado de sangre
19876	Collar de corruptor de alma
19877	Leotardos de animista
19878	Espaldares empapados de sangre
19880	Colección de cabezas Gurubashi
19881	Cabeza de canalizador
19882	La cabeza de Hexxer
19883	Cordón sacro
19884	Sentencia de Jin'do
19885	Ojo maligno de Jin'do
19886	El abrigo de Hexxer
19887	Quijotes manchados de sangre
19888	Abrazo de Señor Supremo
19889	Leotardos empapados de sangre
19890	Brujo de Jin'do
19891	Bolsa de hachazos de Jin'do
19892	Botas de animista
19893	Lacre de Zanzil
19894	Guanteletes empapados de sangre
19895	Falda escocesa tintada de sangre
19896	Garra de Thekal
19897	Botas de traidor
19898	Lacre de Jin
19899	Musleras de ritual
19900	Hacha de piedra Zulian
19901	Rebanadora Zulian
19902	Tigre Zulian veloz
19903	Colmillo de Venoxis
19904	Camisote rúnico manchado de sangre
19905	Sortija de Zanzil
19906	Escarpines empapados de sangre
19907	Capa de pellejo de tigre Zulian
19908	Cetro de Acometida
19909	Voluntad de Arlokk
19910	Garra de Arlokk
19911	Corazón de hierbal
19912	Sortija de ónice de Señor Supremo
19913	Grebas empapados de sangre
19914	Saco de pellejo de pantera
19915	Defensor Zulian
19918	Triturador de Jeklik
19919	Grebas manchadas de sangre
19920	Sortija de primalista
19921	Rebanadora Zulian
19922	Palo de maleficios de Arlokk
19923	talismán ópalo de Jeklik
19925	Sortija de Jin
19927	Toque de Mar'li
19928	Bufas de animista
19929	Guantes tintados de sangre
19930	Ojo de Mar'li
19931	Locura mojo de Gurubashi
19933	Sangre de escórpido resplandeciente
19934	Garra de escórpido grande
19935	Glándula de veneno vacía
19936	Caparazón de escórpido seco
19937	Garra de escórpido pequeña
19938	Pierna de escórpido pesado
19939	Sangre de Gri'lek
19940	Diente de Renataki
19941	Melena de Wushoolay
19942	Hilo de sueño de Hazza'rah
19943	Mojo macizo
19944	Ejecutor de pescado de Nat Pagle
19945	Parche de escamas de lagarto
19946	Arpón de Tigule
19947	Carrete roto de Nat Pagle
19948	Insignia de héroe Zandalar
19949	Medallón de héroe Zandalar
19950	Talismán de héroe Zandalar
19951	Talismán de Poderío de Gri'lek
19952	Talismán de Valor de Gri'lek
19953	Talismán de bestias de Renataki
19954	Talismán de artimañas de Renataki
19955	Talismán de Naturaleza de Wushoolay
19956	Talismán de Espíritus de Wushoolay
19957	Talismán de destrucción de Hazza'rah
19958	Talismán de curación de Hazza'rah
19959	Talismán de magia de Hazza'rah
19960	Miel cristalizada
19961	Molinillo de Gri'lek
19962	Punzón de Gri'lek
19963	Horquilla de Locura
19964	Conducto de alma de Renataki
19965	Atizador de Wushoolay
19967	Entorpecedor
19968	Castigador ígneo
19969	Botas de pescador extremo de Nat Pagle
19970	Caña de pescar de arcanita
19971	Gran línea de pesca de prueba de eternio
19972	Sombrero de pesca de la suerte
19973	Metro de Nat
19974	Cebo de Fangoapestoso
19975	Fangoapestoso Zulian
19978	¡Torneo de pesca!
19979	Gancho del maestro Pescador
19982	Mantón Murciumbrío
19984	Máscara de ébano
19986	Parche de pirata
19989	Escrito sobre Sombras devoradoras
19990	Cuentas de oración benditas
19991	Ojo de demosaurio
19992	Diente de demosaurio
19993	Arco de caza gafado
19994	Fruta de la cosecha
19995	Jabalí de la cosecha
19996	Pez de la cosecha
19997	Néctar de la cosecha
19998	Lentes Vid de sangre
19999	Gafas Vid de sangre
20000	Esquema: gafas Vid de sangre
20001	Esquema: lentes Vid de sangre
20002	Poción superior de letargo sin sueños
20003	Garras de demosaurio
20004	Poción de sangre de trol sublime
20005	Garras de demosaurio
20006	Círculo de Esperanza
20007	Poción de sangre de mago
20008	Poción de acción viva
20009	¡Por la Luz!
20010	El grito del infierno de la Horda
20011	Receta: poción de sangre de mago
20012	Receta: letargo sin sueños superior
20013	Receta: poción de acción viva
20014	Receta: poción de sangre de trol sublime
20015	Plumas de raptor viejo
20016	Calavera trofeo de raptor
20017	Cuernos perfectos
20018	Pellejo de zarpira grisezno
20019	Diente de Morphaz
20020	Fardo de bienes
20021	Pendiente pirata de oro
20022	Llave azur
20023	Fragmento codificado
20024	Conducto de bilis putrefacto
20025	Sangre de Morphaz
20026	Carne en descomposición
20027	Glándula de corcel sano
20028	Polvo relumbrante
20029	Coral encantado
20030	Roca mascota
20031	Mango esencia
20032	Togas de ritual sueltas
20033	Toga de Demoníaco Zandalar
20034	Toga de ilusionista Zandalar
20035	Punta glacial
20036	Rubí de fuego
20037	Colgante de cristal Arcano
20038	Aguijón de Mandokir
20039	Botas Hierro Negro
20040	Diseño: botas Hierro Negro
20041	Faja de placas de montañés
20042	Faja de láminas de montañés
20043	Faja de anillas de montañés
20044	Faja de malla de montañés
20045	Faja de cuero de montañés
20046	Faja de pellejo de lagarto de montañés
20047	Faja de paño de montañés
20048	Grebas de placas de montañés
20049	Grebas de láminas de montañés
20050	Grebas de anillas de montañés
20051	Grebas de malla de montañés
20052	Botas de cuero de montañés
20053	Botas de pellejo de lagarto de montañés
20054	Botas de paño de montañés
20055	Espaldares de anillas de montañés
20056	Espaldares de malla de montañés
20057	Bufas de placas de montañés
20058	Bufas de láminas de montañés
20059	Hombreras de cuero de montañés
20060	Hombreras de pellejo de lagarto de montañés
20061	Insignias de montañés
20062	Ración enriquecida de la Cuenca de Arathi
20063	Ración de campo de la Cuenca de Arathi
20064	Ración de hierro de la Cuenca de Arathi
20065	Venda de paño mágico de la Cuenca de Arathi
20066	Venda de paño rúnico de la Cuenca de Arathi
20067	Venda de seda de la Cuenca de Arathi
20068	Capa de Guardia de la Muerte
20069	Bastón Cortezaférrea
20070	Garra sabia
20071	Talismán de Arathor
20072	Talismán de Rapiñador
20073	Capa de Guardia de honor
20074	Estofado de crocolisco pesado
20075	Receta: estofado de crocolisco pesado
20076	Sello Zandalar de mojo
20077	Sello Zandalar de poderío
20078	Sello Zandalar de serenidad
20079	Espíritu de Zanza
20080	Brillo de Zanza
20081	Agilidad de Zanza
20082	Bastón de aflicción
20083	Lanza de caza
20084	Red de caza
20085	Fragmento Arcano
20086	Cuchillo arrojadizo de acero del Alba
20087	Escamas de vándalo marino
20088	Faja de anillas de montañés
20089	Faja de anillas de montañés
20090	Faja de anillas de montañés
20091	Grebas de anillas de montañés
20092	Grebas de anillas de montañés
20093	Grebas de anillas de montañés
20094	Botas de paño de montañés
20095	Botas de paño de montañés
20096	Botas de paño de montañés
20097	Faja de paño de montañés
20098	Faja de paño de montañés
20099	Faja de paño de montañés
20100	Botas de pellejo de lagarto de montañés
20101	Botas de pellejo de lagarto de montañés
20102	Botas de pellejo de lagarto de montañés
20103	Faja de pellejo de lagarto de montañés
20104	Faja de pellejo de lagarto de montañés
20105	Faja de pellejo de lagarto de montañés
20106	Faja de láminas de montañés
20107	Faja de láminas de montañés
20108	Faja de láminas de montañés
20109	Grebas de láminas de montañés
20110	Grebas de láminas de montañés
20111	Grebas de láminas de montañés
20112	Botas de cuero de montañés
20113	Botas de cuero de montañés
20114	Botas de cuero de montañés
20115	Faja de cuero de montañés
20116	Faja de cuero de montañés
20117	Faja de cuero de montañés
20118	Faja de malla de montañés
20119	Faja de malla de montañés
20120	Faja de malla de montañés
20121	Grebas de malla de montañés
20122	Grebas de malla de montañés
20123	Grebas de malla de montañés
20124	Faja de placas de montañés
20125	Faja de placas de montañés
20126	Faja de placas de montañés
20127	Grebas de placas de montañés
20128	Grebas de placas de montañés
20129	Grebas de placas de montañés
20130	Frasco de diamante
20131	Tabardo de batalla de los Rapiñadores
20132	Tabardo de batalla de Arathor
20134	Yelmo furia del cielo
20150	Faja de anillas de Rapiñador
20151	Faja de anillas de Rapiñador
20152	Faja de anillas de Rapiñador
20153	Faja de anillas de Rapiñador
20154	Grebas de anillas de Rapiñador
20155	Grebas de anillas de Rapiñador
20156	Grebas de anillas de Rapiñador
20157	Grebas de anillas de Rapiñador
20158	Espaldares de anillas de Rapiñador
20159	Botas de paño de Rapiñador
20160	Botas de paño de Rapiñador
20161	Botas de paño de Rapiñador
20162	Botas de paño de Rapiñador
20163	Faja de paño de Rapiñador
20164	Faja de paño de Rapiñador
20165	Faja de paño de Rapiñador
20166	Faja de paño de Rapiñador
20167	Botas de pellejo de lagarto de Rapiñador
20168	Botas de pellejo de lagarto de Rapiñador
20169	Botas de pellejo de lagarto de Rapiñador
20170	Botas de pellejo de lagarto de Rapiñador
20171	Faja de pellejo de lagarto de Rapiñador
20172	Faja de pellejo de lagarto de Rapiñador
20173	Faja de pellejo de lagarto de Rapiñador
20174	Faja de pellejo de lagarto de Rapiñador
20175	Hombreras de pellejo de lagarto de Rapiñador
20176	Insignias de Rapiñador
20177	Faja de láminas de Rapiñador
20178	Faja de láminas de Rapiñador
20179	Faja de láminas de Rapiñador
20180	Faja de láminas de Rapiñador
20181	Grebas de láminas de Rapiñador
20182	Grebas de láminas de Rapiñador
20183	Grebas de láminas de Rapiñador
20184	Bufas de láminas de Rapiñador
20185	Grebas de láminas de Rapiñador
20186	Botas de cuero de Rapiñador
20187	Botas de cuero de Rapiñador
20188	Botas de cuero de Rapiñador
20189	Botas de cuero de Rapiñador
20190	Faja de cuero de Rapiñador Faja
20191	Faja de cuero de Rapiñador Faja
20192	Faja de cuero de Rapiñador Faja
20193	Faja de cuero de Rapiñador Faja
20194	Hombreras de cuero de Rapiñador
20195	Faja de malla de Rapiñador
20196	Faja de malla de Rapiñador
20197	Faja de malla de Rapiñador
20198	Faja de malla de Rapiñador
20199	Grebas de malla de Rapiñador
20200	Grebas de malla de Rapiñador
20201	Grebas de malla de Rapiñador
20202	Grebas de malla de Rapiñador
20203	Espaldares de malla de Rapiñador
20204	Faja de placas de Rapiñador
20205	Faja de placas de Rapiñador
20206	Faja de placas de Rapiñador
20207	Faja de placas de Rapiñador
20208	Grebas de placas de Rapiñador
20209	Grebas de placas de Rapiñador
20210	Grebas de placas de Rapiñador
20211	Grebas de placas de Rapiñador
20212	Bufas de placas de Rapiñador
20213	Cinturón de Cabezas encogidas
20214	Colmillo mental
20215	Cinturón de Cabezas secas
20216	Cinturón de Cabezas conservadas
20217	Cinturón de las Pequeñas cabezas
20218	Capa Hakkari descolorida
20219	Manteo Hakkari andrajoso
20220	Bastón Cortezaférrea
20221	Corcel fabuloso
20222	Ración enriquecida de Rapiñador
20223	Ración de campo de Rapiñador
20224	Ración de hierro de Rapiñador
20225	Ración enriquecida de montañés
20226	Ración de campo de montañés
20227	Ración de hierro de montañés
20228	Paquete de cuidados avanzados de Rapiñador
20229	Paquete de cuidados básicos de Rapiñador
20230	Botiquín estándar de Rapiñador
20231	Paquete de curación avanzada de Arathor
20232	Venda de paño mágico de Rapiñador
20233	Paquete de curación básica de Arathor
20234	Venda de paño rúnico de Rapiñador
20235	Venda de seda de Rapiñador
20236	Paquete de curación estándar de Arathor
20237	Venda de paño mágico de montañés
20243	Venda de paño rúnico de montañés
20244	Venda de seda de montañés
20253	Patrón: arnés de oso de guerra
20254	Patrón: prendas de lana de oso de guerra
20255	Botas Caminasusurro
20256	Lazo de Sacrificio del Barranco Grito de Guerra
20257	Guanteletes de furia marina
20258	Bastón Ceremonial Zulian
20259	Guantes de pellejo de pantera de las Sombras
20260	Leotardos de furia marina
20261	Cinturón de pellejo de pantera de las Sombras
20262	Botas de furia marina
20263	Yelmo Gurubashi
20264	Guanteletes de pacificador
20265	Botas de pacificador
20266	Leotardos de pacificador
20295	Leotardos de escamas de dragón azul
20296	Guanteletes de escamas de dragón verde
20310	Piel de demonio despellejada
20337	Cabeza de gnomo en un palo
20367	Equipo de caza
20368	Arco anodino de Serenidad
20369	Puños azurita
20371	Huevo múrloc azul
20373	Aguijoneros escórpidos Latigosólido
20374	Aguijoneros tenazarios Latigosólido
20375	Aguijonero de Cazador Latigosólido
20376	Colmillo de arácnido de arena
20377	Colmillo de Acecharrocas
20378	Fragmento del Crepúsculo tablilla
20379	Cartera de Noggle
20380	Peto de escamas oníricas
20381	Escama onírica
20382	Patrón: peto de escamas oníricas
20383	Cabeza de Señor de prole Capazote
20384	Fragmento de caparazón de silítido
20385	Pinza de Pinzamorten
20387	Ristra de bombas fétidas de Renegados
20388	Caramelo
20389	Trigo de caramelo
20390	Chocolatina
20391	Máscara de gnomo endeble
20392	Máscara de gnoma endeble
20393	Bolsa de premios
20394	Lexicón del Crepúsculo: Capítulo 1
20395	Lexicón del Crepúsculo: Capítulo 2
20396	Lexicón del Crepúsculo: Capítulo 3
20397	Varita sagrada: Pirata
20398	Varita sagrada: Ninja
20399	Varita sagrada: Gnomo leproso
20400	Bolsa de calabazas
20401	Tablilla del Crepúsculo restaurada
20402	Agente de Nozdormu
20403	Poder de Nozdormu
20404	Texto crepuscular codificado
20405	Trascripción de tablilla decodificada
20406	Manto de fiel del Crepúsculo
20407	Toga de fiel del Crepúsculo
20408	Capucha de fiel del Crepúsculo
20409	Varita sagrada: Fantasma
20410	Varita sagrada: Murciélago
20411	Varita sagrada: Esqueleto
20413	Varita sagrada: Aleatorio
20414	Varita sagrada: Fuego fatuo
20415	La guerra del Mar de Dunas
20416	Emblema de Señalización: Fuego
20418	Emblema de Señalización: Trueno
20419	Emblema de Señalización: Piedra
20420	Emblema de Señalización: Agua
20422	Medallón de estatus de fiel del Crepúsculo
20423	Garra de escórpido arenoso
20424	Carne de gusano de arena
20425	Bastón nudoso de consejero
20426	Anillo de consejero
20427	Capa de curador de batalla
20428	Manteo de cuidador
20429	Sortija de legionario
20430	Espada de legionario
20431	Anillo del guardián del Conocimiento
20432	Sello de Señalización: Fuego
20433	Sello de Señalización: Trueno
20434	Bastón del guardián del Conocimiento
20435	Sello de Señalización: Piedra
20436	Sello de Señalización: Agua
20437	Arco de escolta
20438	Arco de avanzado
20439	Sortija de protector
20440	Espada de protector
20441	Hoja de explorador
20442	Medallón de explorador
20443	Hoja de centinela
20444	Medallón de centinela
20447	Cetro de Señalización: Fuego
20448	Cetro de Señalización: Trueno
20449	Cetro de Señalización: Piedra
20450	Cetro de Señalización: Agua
20451	Anillo de nobleza de fiel del Crepúsculo
20452	Bolas de masa del desierto ahumadas
20453	Juego de trascripción de geólogo
20454	Calco de Colmen'Zora
20455	Calco de Colmen'Ashi
20456	Calco Colmen'Regal
20457	Cerebro silítido de Colmen'Ashi
20458	Colmillo silítido Colmen'Zora
20459	Cerebro silítido de Colmen'Regal
20460	Carta perdida de Brann Barbabronce
20461	Carta perdida de Brann Barbabronce
20462	Medallón de Halloween
20463	Prisma de cristal con inscripciones
20464	Glifos de Llamamiento
20465	Mecanismo de liberación de cristal
20466	Sello de Vyral
20467	Página de receta rota
20469	Recortes de El creyente verdadero descifrado
20475	Gema de alma
20476	Brazales Acecharenas
20477	Guanteletes Acecharenas
20478	Peto Acecharenas
20479	Peto escupefuego
20480	Guanteletes escupefuego
20481	Brazales escupefuego
20485	Lacre del duque
20487	Lok'delar, bastón de los Guardianes ancianos DEP
20488	Rhok'delar, arco de los Guardianes ancianos DEP
20489	Corona del Consejo
20490	Menta de Forjaz
20491	Menta de Entrañas
20492	Turrón de Ventormenta
20493	Turrón de Orgrimmar
20494	Gominola de Gnomeregan
20495	Pastilla de goma Lanza Negra
20496	Mazapán de Darnassus
20497	Mazapanes de Cima del Trueno
20498	Quitina de silítido
20499	Quitina de escórpido rota
20500	Caparazón de silítido ligero
20501	Caparazón de silítido pesado
20502	Escudo Cortezaférrea
20503	Espíritu de agua enamorado
20504	Hoja forjada con luz
20505	Sello caballeresco
20506	Patrón: brazales escupefuego
20507	Patrón: guanteletes escupefuego
20508	Patrón: peto escupefuego
20509	Patrón: brazales Acecharenas
20510	Patrón: guanteletes Acecharenas
20511	Patrón: peto Acecharenas
20512	Orbe santificado
20513	Emblema abisal
20514	Sello abisal
20515	Cetro abisal
20516	Manzana de Halloween
20517	Hombreras acero afilado
20518	Pergamino: crear Emblema de Señalización
20519	Sombrero pirata de los Mares del Sur
20520	Runa oscura
20521	Visor de furia
20522	Bastón feral
20524	Leotardos Pellejo Negro
20525	Sigilo terráneo
20526	Pergamino: crear Emblema de Señalización
20527	Pergamino: crear Emblema de Señalización
20528	Pergamino: crear Emblema de Señalización
20530	Togas de Servidumbre
20531	Pergamino: crear Sello de Señalización
20532	Pergamino: crear Sello de Señalización
20533	Pergamino: crear Sello de Señalización
20534	Fragmento abisal
20535	Pergamino: crear Sello de Señalización
20536	Cosechador de almas
20537	Botas estigias rúnicas
20538	Leotardos estigios rúnicos
20539	Cinturón estigio rúnico
20540	Pergamino: crear Cetro de Señalización
20541	Texto descifrado del Crepúsculo
20542	Pergamino: crear Cetro de Señalización
20543	Pergamino: crear Cetro de Señalización
20544	Pergamino: crear Cetro de Señalización
20545	Texto descifrado del Crepúsculo
20546	Patrón: leotardos estigios rúnicos
20547	Patrón: botas estigias rúnicas
20548	Patrón: cinturón estigio rúnico
20549	Guanteletes runa oscura
20550	Peto runa oscura
20551	Yelmo runa oscura
20552	Texto descifrado del Crepúsculo
20553	Diseño: guanteletes runa oscura
20554	Diseño: peto runa oscura
20555	Diseño: yelmo runa oscura
20556	Bastón salvaje
20557	Golosinas de calabaza de Halloween
20558	Marca de Honor del Barranco Grito de Guerra
20559	Marca de honor de la Cuenca de Arathi
20560	Marca de Honor del Valle de Alterac
20561	Máscara de enano endeble
20562	Máscara de enana endeble
20563	Máscara de elfa de la noche endeble
20564	Máscara de elfo de la noche endeble
20565	Máscara de mujer endeble
20566	Máscara de hombre endeble
20567	Máscara de trol hembra endeble
20568	Máscara de trol endeble
20569	Máscara de orco hembra endeble
20570	Máscara de orco endeble
20571	Máscara de tauren hembra endeble
20572	Máscara de tauren endeble
20573	Máscara de no-muerto endeble
20574	Máscara de no-muerta endeble
20575	Túnica de cría negra
20576	Patrón: túnica de cría negra
20577	Hoja pesadilla
20578	Comillo de dragón Esmeralda
20579	Capa de piel de dragón verde
20580	Martillo de Furia bestial
20581	Bastón de Crecimiento desenfrenado
20582	Piedra de trance
20583	Máscara de enana robusta
20584	Máscara de gnomo hembra robusta
20585	Máscara de mujer robusta
20586	Máscara de elfa de la noche robusta
20587	Máscara de orco hembra robusta
20588	Máscara de tauren hembra robusta
20589	Máscara de trol hembra robusta
20590	Máscara de no-muerta robusta
20591	Máscara de enano robusto
20592	Máscara de gnomo robusto
20593	Máscara de hombre robusto
20594	Máscara de elfo de la noche robusto
20595	Máscara de orco robusto
20596	Máscara de tauren robusto
20597	Máscara de trol robusto
20598	Máscara de no-muerto robusto
20599	Ballesta de hierromadera pulida
20600	Sello de Malfurión
20601	Saco de botín
20602	Cofre de residuos
20603	Bolsa de botín
20604	Limpiador de bomba fétida
20605	Huevos podridos
20606	Pluma vudú ámbar
20607	Pluma de vudú azul
20608	Pluma de vudú verde
20609	Plumas vudú
20610	Ojo de araña tiro de sangre
20611	Garra negra gruesa
20612	Piedra de la Plaga inerte
20613	Madera putrefacta
20614	Esencia de veneno de sangre
20615	Brazaletes de espuelas de dragón
20616	Muñequeras de hueso de dragón
20617	Antiguos leotardos corroídos
20618	Guantes de Poder ilusorio
20619	Grebas grabadas con ácido
20620	Piedra sagrada del poderío
20621	Botas de la Llanura eterna
20622	Collar de corazón de dragón
20623	Aro de Sueños Inquietos
20624	Anillo del Inerte
20625	Cinturón de la Ciénaga oscura
20626	Muñequeras de corteza negra
20627	Pantalones de corazón oscuro
20628	Almete Crecimiento desviado
20629	Guardapiés malignos
20630	Guanteletes de la Luz brillante
20631	Zapatillas de mendigo
20632	Sortija de lágrima mental
20633	Bufas de cuero artificial
20634	Botas de miedo
20635	Vestimentas decoradas con jade
20636	Cristal de hibernación
20637	Espaldares grabados con ácido
20638	Leotardos de la Mente demente
20639	Quijotes con extrañas inscripciones
20640	Cubo de cabezas de los Mares del Sur
20641	Botas de mojo de los Mares del Sur
20642	Túnica de noble anticuada
20643	Sombrero de reservista de Entrañas
20644	Objeto envuelto en pesadillas
20645	Susurro de la Naturaleza
20646	Marca de Correarenas
20647	Daga de cristal negro
20648	Martillo forjado en frío
20649	Colgante prisma de sol
20650	Guanteletes del viento del desierto
20651	Huevo múrloc naranja
20652	Zapatillas de paño abisal
20653	Guanteletes de placas abisales
20654	Bastón de guerra amatista
20655	Mitones de paño abisal
20656	Escarpes de malla abisal
20657	Estilete con punta de cristal
20658	Botas de cuero abisal
20659	Manoplas de malla abisal
20660	Guja Cortapiedras
20661	Guantes de cuero abisal
20662	Grebas de placas abisales
20663	Arco tiro profundo
20664	Fajín de paño abisal
20665	Leotardos de cuero abisal
20666	Martillo de guerra de acero endurecido
20667	Cinturón de cuero abisal
20668	Musleras de malla abisal
20669	Espada claymore Rocanegra
20670	Garra de malla abisal
20671	Quijotes de placas abisales
20672	Varita de cristal centelleante
20673	Faja de placas abisales
20674	Pantalones de paño abisal
20675	Creador de almas
20676	Texto descifrado del Crepúsculo
20677	Texto descifrado del Crepúsculo
20678	Texto descifrado del Crepúsculo
20679	Texto descifrado del Crepúsculo
20680	Espaldares de malla abisal
20681	Brazales de cuero abisal
20682	Sortija de enfoque elemental
20683	Insignias de placas abisales
20684	Guardabrazos de cuero abisal
20685	Collar rompeolas
20686	Hombrera de paño abisal
20687	Protegebrazos de placas abisales
20688	Integumento terráneo
20689	Hombreras de cuero abisal
20690	Muñequeras de paño abisal
20691	Manteo Cortaviento
20692	Sortija multicolor
20693	Capa pesada
20694	Orbe negro resplandeciente
20695	Cuentas de guerra abisales
20696	Gran maza de cristal con pinchos
20697	Manteo tejido cristalino
20698	Hoja elemental armonizada
20699	Quijotes de reservista Cenarion
20700	Quijotes de reservista Cenarion
20701	Musleras de reservista Cenarion
20702	Musleras de reservista Cenarion
20703	Leotardos de reservista Cenarion
20704	Leotardos de reservista Cenarion
20705	Pantalones de reservista Cenarion
20706	Pantalones de reservista Cenarion
20707	Pantalones de reservista Cenarion
20708	Baúl bien sellado
20709	Ron Rumsey ligero
20710	Grebas taraceadas con cristal
20711	Grebas con líneas de cristal
20712	Guanteletes de Caminadesechos
20713	Guanteletes de Acechadesiertos
20714	Botas Tormenta de Arena
20715	Botas de Acechadunas
20716	Guantes de piel de gusano de arena
20717	Guantes flor del desierto
20720	Hoja susurro oscuro
20721	Sortija del Fiel
20722	Lanzababosa de cristal
20723	Pico de confianza de Brann
20724	Bastón del Bosque Negro corrupto
20725	Cristal Nexus
20726	Fórmula: encantar guantes: amenaza
20727	Fórmula: encantar guantes: poder de las Sombras
20728	Fórmula: encantar guantes: poder de Escarcha
20729	Fórmula: encantar guantes: poder de Fuego
20730	Fórmula: encantar guantes: poder de curación
20731	Fórmula: encantar guantes: agilidad excelente
20732	Fórmula: encantar capa: resistencia superior a Fuego
20733	Fórmula: encantar capa: resistencia superior a Naturaleza
20734	Fórmula: encantar capa: sigilo
20735	Fórmula: encantar capa: sutileza
20736	Fórmula: encantar capa: esquivar
20737	Piedra nuclearia abrasada
20741	Tótem de ritual Muertobosque
20742	Tótem de ritual Nevada
20744	Aceite de zahorí menor
20745	Aceite de maná menor
20746	Aceite de zahorí inferior
20747	Aceite de maná inferior
20748	Aceite de maná luminoso
20749	Aceite de zahorí luminoso
20750	Aceite zahorí
20752	Fórmula: aceite de maná menor
20753	Fórmula: aceite de zahorí inferior
20754	Fórmula: aceite de maná inferior
20755	Fórmula: aceite de zahorí
20756	Fórmula: aceite de zahorí luminoso
20757	Fórmula: aceite de maná luminoso
20758	Fórmula: aceite de zahorí menor
20761	Receta: transmutar Fuego elemental
20763	Arma rota
20766	Bolsa babosa
20767	Bolsa cubierta de suciedad
20768	Bolsa de mocos
20769	Supuración desagradable
20770	Icor verde burbujeante
20800	Insignia logística Cenarion
20801	Insignia táctica Cenarion
20802	Insignia de combate Cenarion
20803	Instrucciones de batalla del Crepúsculo
20805	Seguimiento del encargo de logística
20806	Informe de tareas logísticas 10
20807	Informe de tareas logísticas 1
20808	Encargo de combate
20809	Misión táctica
20810	Papeles de servicio de campo firmados
20814	Daga arrojadiza de maestro
20834	Telescopio XT ornamentado
20844	Veneno mortal 5
20858	Escarabajo de piedra
20859	Escarabajo de oro
20860	Escarabajo de plata
20861	Escarabajo de bronce
20862	Escarabajo de cristal
20863	Escarabajo de terracota
20864	Escarabajo de hueso
20865	Escarabajo de marfil
20866	Ídolo azur
20867	Ídolo de ónice
20868	Ídolo luminiscente
20869	Ídolo de ámbar
20870	Ídolo de jaspe
20871	Ídolo obsidiano
20872	Ídolo bermellón
20873	Ídolo de alabastro
20874	Ídolo del Sol
20875	Ídolo de la Noche
20876	Ídolo de Muerte
20877	Ídolo del Sabio
20878	Ídolo de Renacimiento
20879	Ídolo de la Vida
20881	Ídolo de la Disputa
20882	Ídolo de la Guerra
20883	Joya Qiraji con inscripciones
20884	Anillo Qiraji de magíster
20885	Mantón Qiraji marcial
20886	Puño con pinchos Qiraji
20887	Joya Qiraji grabada
20888	Anillo ceremonial Qiraji
20889	Mantón Qiraji real
20890	Empuñadura Qiraji ornamentada
20908	Fuegos artificiales del Festival de Nian
20926	Aro de Vek'nilash
20927	Pellejo intacto de Ouro
20928	Ataduras de mando Qiraji
20929	Caparazón del dios antiguo
20930	Diadema de Vek'lor
20931	Piel del Gran gusano de arena
20932	Ataduras de dominio Qiraji
20933	Colmillo del dios antiguo
20936	Joya Qiraji bendita
20937	Joya Qiraji encajonada
20939	Informe de tareas logísticas 2
20940	Informe de tareas logísticas 3
20941	Informe de tarea de combate 13
20942	Informe de tarea de combate 4
20943	Instrucciones de la misión táctica 11
20944	Instrucciones de la misión táctica 6
20945	Instrucciones de la misión táctica 2
20946	Instrucciones de la misión táctica 3
20947	Instrucciones de la misión táctica 5
20948	Instrucciones de la misión táctica 7
20949	Libro de contabilidad mágico
20951	Gafas de visión de Narain
21023	Pinchos quimerok potentes de Dirge
21024	Solomillo de Quimerok
21025	Receta: pinchos quimerok potentes de Dirge
21027	Cadáver de Lakmaeran
21028	Pollo de 500 kilos
21029	Carta de rescate
21030	Tarta de kimchi de Darnassus
21031	Kimchi de repollo
21032	Carta de amor de Meridith
21033	Rábano kimchi
21037	Mapa rudimentario
21038	Bola de nieve prieta
21039	Turbante de Narain
21040	Toga de Narain
21041	Bolsa de oro
21042	Equipo especial de Narain
21043	Sobre misterioso
21071	Sabiola cruda
21072	Sabiola ahumada
21099	Receta: sabiola ahumada
21100	Moneda de linaje
21103	Dracónico para torpes
21104	Dracónico para torpes
21105	Dracónico para torpes
21106	Dracónico para torpes
21107	Dracónico para torpes
21108	Dracónico para torpes
21109	Dracónico para torpes
21110	Dracónico para torpes
21111	Dracónico para torpes: volumen II
21112	Encuadernación de libro mágico
21113	Baúl hermético
21114	Ron Rumsey oscuro
21115	Talismán de Rapiñador
21116	Talismán de Rapiñador
21117	Talismán de Arathor
21118	Talismán de Arathor
21119	Talismán de Arathor
21120	Talismán de Rapiñador
21126	Aguijón de la Muerte
21128	Bastón de los Profetas Qiraji
21130	Diario de Weavil
21131	Seguimiento del encargo de combate
21132	Encargo de logística
21133	Seguimiento del encargo táctico
21134	Filo oscuro de la locura
21135	Hacha arrojadiza de asesino
21136	Boya de arcanita
21137	Fragmento de cetro azul
21138	Fragmento de cetro rojo
21139	Fragmento de cetro verde
21140	Papel y sobres para cartas de subasta
21141	Fragmento de cetro rojo destruido
21142	De la mesa de Lord Victor Nefarius
21143	Documentos de obligación de campo sin firmar
21144	Antorcha para invocar demonios
21145	Esencia de Xandivious
21146	Fragmento de Corrupción de Pesadilla
21147	Fragmento de Corrupción de Pesadilla
21148	Fragmento de Corrupción de Pesadilla
21149	Fragmento de Corrupción de Pesadilla
21150	Baúl recubierto de hierro
21151	Ron Rumsey etiqueta negra
21152	La corrupción de Pesadilla
21153	Sabiola cruda superior
21154	Vestido de fiesta
21155	Oferta de paz de los Fauces de Madera
21156	Bolsa escarabajo
21157	Vestido de fiesta verde
21158	Informe de explorador de Colmen'Zora
21159	Pedido de explorador de Colmen'Zora
21160	Informe de explorador de Colmen'Regal
21161	Informe de explorador de Colmen'Ashi
21162	Bocanegra hinchado
21163	Pargo de fuego hinchado
21164	Bacalao Piedrescama hinchado
21165	Instrucciones de la misión táctica 8
21166	Instrucciones de la misión táctica 9
21167	Instrucciones de la misión táctica 10
21168	Cría de tiburón
21171	Jarra festiva llena
21173	Jarra festiva vacía
21174	Jarra festiva vacía
21175	El cetro del Mar de Dunas
21176	Cristal resonador negro Qiraji
21177	Símbolo de Reyes
21178	Guantes de Poder de la tierra
21179	Sortija de Cólera de tierra
21180	Terremoto
21181	Gracia de Tierra
21182	Sortija de Poderío de tierra
21183	Jubón Poder terrenal
21184	Brazales de roca profunda
21185	Orbe Calmaterra
21186	Brazales de Furia de roca
21187	Capa Tejetierra
21188	Puño de Cenario
21189	Poderío de Cenario
21190	Cólera de Cenario
21191	Obsequio envuelto con cuidado
21193	Saco de El'saco
21194	Saco grande de El'saco
21195	Sactástico de El'saco
21196	Sello del Vuelo de Bronce
21197	Sello del Vuelo de Bronce
21198	Sello del Vuelo de Bronce
21199	Sello del Vuelo de Bronce
21200	Sello del Vuelo de Bronce
21201	Sello del Vuelo de Bronce
21202	Sello del Vuelo de Bronce
21203	Sello del Vuelo de Bronce
21204	Sello del Vuelo de Bronce
21205	Sello del Vuelo de Bronce
21206	Sello del Vuelo de Bronce
21207	Sello del Vuelo de Bronce
21208	Sello del Vuelo de Bronce
21209	Sello del Vuelo de Bronce
21210	Sello del Vuelo de Bronce
21211	Faltriquera de polvo de reno
21212	Acebo fresco
21213	Acebo en conserva
21214	Escrito sobre Descarga de Escarcha 11
21215	Pastel de macedonia de carne picada de Graccu
21216	Obsequio megaespecial de Pastos de Bosquehumeante
21217	Delicia de sabiolas
21218	Cristal resonador Qiraji azul
21219	Receta: delicia de sabiolas
21220	Cabeza de Osirio el Sinmarcas
21221	Ojo de C'Thun
21222	Quitina blindada
21223	Piedra negra
21224	Fragmento de armadura antigua
21225	Colmillo de silítido pesado
21226	Piedra rúnica
21227	Cráneo de héroe antiguo
21228	Baúl de mitril abollado
21229	Insignia Qiraji de Lord
21230	Artefacto Qiraji antiguo
21232	Armamento imperial Qiraji
21235	Asado del Festival de Invierno
21236	Pan del Festival de Invierno
21237	Atavío imperial Qiraji
21240	Dulce de Festival de Invierno
21241	Ponche de huevo del Festival de Invierno
21242	Hacha de guerra Qiraji bendita
21243	Vigorpez hinchado
21244	Pugio Qiraji bendito
21245	Instrucciones de la misión táctica 1
21246	Informe de tarea de combate 1
21247	Informe de tarea de combate 2
21248	Informe de tarea de combate 5
21249	Informe de tarea de combate 7
21250	Informe de tarea de combate 8
21251	Informe de tarea de combate 9
21252	Informe de tarea de combate 10
21253	Informe de tarea de combate 6
21254	Galleta de Festival de Invierno
21255	Informe de tarea de combate 11
21256	Informe de tarea de combate 12
21257	Informe de tareas logísticas 4
21258	Informe de tareas logísticas 4
21259	Informe de tareas logísticas 5
21260	Informe de tareas logísticas 6
21261	Informe de tareas logísticas 6
21262	Informe de tareas logísticas 8
21263	Informe de tareas logísticas 7
21264	Informe de tareas logísticas 7
21265	Informe de tareas logísticas 9
21266	Encargo de logística
21267	Cáliz de brindis
21268	Martillo de guerra Qiraji bendito
21269	Baluarte Qiraji bendito
21270	Obsequio ligeramente agitado
21271	Obsequio ligeramente agitado
21272	Mosquete Qiraji bendito
21273	Bastón de acólito Qiraji bendito
21275	Bastón de augur Qiraji bendito
21277	Yeti mecánico tranquilo
21278	Guantes Velotormenta
21279	Escrito sobre Bola de Fuego 12
21280	Escrito sobre Misiles Arcanos 8
21281	Grimorio de descarga de las Sombras X
21282	Grimorio de Inmolar VIII
21283	Grimorio de Corrupción VII
21284	Códice de Curación superior 5
21285	Códice de Renovar 10
21287	Códice de Rezo de curación 5
21288	Tratado: Bendición de sabiduría 6
21289	Tratado: Bendición de poderío 7
21290	Tratado: Luz sagrada 5
21291	Tablilla de Ola curativa 10
21292	Tablilla de tótem Fuerza terrenal 5
21293	Tablilla de tótem gracia del aire 3
21294	Libro sobre Toque curativo 11
21295	Libro sobre Estrella de mar 7
21296	Libro sobre Rejuvenecimiento 11
21297	Manual de Golpe Heroico IX
21298	Manual de Grito de batalla VII
21299	Manual de Revancha VI
21300	Vademécum de Puñalada por la espalda IX
21301	Caja de ayudante verde
21302	Vademécum de Veneno mortal V
21303	Vademécum de Amago V
21304	Guía: Multi-tiro V
21305	Caja de ayudante roja
21306	Guía: Mordedura de serpiente IX
21307	Guía: Aspecto del halcón VII
21308	Campanita alegre
21309	Equipo de muñeco de nieve
21310	Obsequio alegremente envuelto
21311	Jubón del Guardián de la Tierra
21312	Cinturón del Guardia del cubil
21313	Bolsa pequeña de El'saco
21314	Cartas y notas de Metzen
21315	Cartera de Bosquehumeante
21316	Leotardos del Ursa
21317	Yelmo del abrecaminos
21318	Guantes del Guardián de la Tierra
21319	Guantes del Abrecaminos
21320	Jubón del guardia del cubil
21321	Cristal resonador Qiraji rojo
21322	Abrazo de Ursa
21323	Cristal resonador Qiraji verde
21324	Cristal resonador Qiraji amarillo
21325	Grinch mecánico
21326	Defensor de los Fauce de Madera
21327	Obsequio que hace tic-tac
21328	Varita de Felicidad del recreo
21329	Corona de conquistador
21330	Las bufas de conquistador
21331	Peto de conquistador
21332	Musleras de conquistador
21333	Grebas de conquistador
21334	Togas clamacondenas
21335	Manto clamacondenas
21336	Pantalones clamacondenas
21337	Aro de clamacondenas
21338	Borceguíes de clamacondenas
21340	Faltriquera de almas
21341	Bolsa de tela de inferi
21342	Bolsa de tela de inferi del Núcleo
21343	Toga enigma
21344	Botas enigma
21345	Hombreras enigma
21346	Leotardos enigma
21347	Aro enigma
21348	Tiara del Oráculo
21349	Borceguíes del Oráculo
21350	Manto del Oráculo
21351	Vestimentas del oráculo
21352	Pantalones del Oráculo
21353	Yelmo del Génesis
21354	Hombreras del Génesis
21355	Botas del Génesis
21356	Pantalones del Génesis
21357	Jubón del Génesis
21358	Patrón: faltriquera de almas
21359	Botas de mortífero
21360	Yelmo de mortífero
21361	Bufas de mortífero
21362	Leotardos de mortífero
21363	Obsequio festivo
21364	Jubón de mortífiero
21365	Guardapiés de artillero
21366	Diadema de artillero
21367	Espaldares de artillero
21368	Leotardos de artillero
21369	Patrón: bolsa de tela de inferi
21370	Camisote de artillero
21371	Patrón: bolsa de tela de inferi del Núcleo
21372	Diadema Clamatormentas
21373	Guardapiés de Clamatormentas
21374	Camisote de Clamatormentas
21375	Leotardos de Clamatormentas
21376	Espaldares de Clamatormentas
21377	Pluma de penacho Muertobosque
21378	Informe de tareas logísticas 1
21379	Informe de tareas logísticas 2
21380	Informe de tareas logísticas 3
21381	Informe de tareas logísticas 9
21382	Informe de tareas logísticas 5
21383	Cuentas de Espíritu Nevada
21384	Informe de tareas logísticas 8
21385	Informe de tareas logísticas 10
21386	Seguimiento del encargo de logística
21387	Corona del Vengador
21388	Grebas del Vengador
21389	Peto del Vengador
21390	Musleras del Vengador
21391	Espaldare del Vengador
21392	Hoz de fuerza implacable
21393	Sello de Fuerza implacable
21394	Mantón de Fuerza implacable
21395	Hoja de Justicia eterna
21396	Anillo de Justicia eterna
21397	Manteo de Justicia eterna
21398	Martillo de la tormenta inminente
21399	Anillo de la tormenta inminente
21400	Capa de la Tormenta inminente
21401	Hacha de la Senda Oculta
21402	Sello de la Senda Oculta
21403	Capa de la Senda oculta
21404	Daga de las Sombras Ocultas
21405	Sortija de las Sombras Ocultas
21406	Capa de las Sombras ocultas
21407	Maza de vida inagotable
21408	Sortija de Vida inagotable
21409	Capa de Vida inagotable
21410	Mazo de Infinita Sabiduría
21411	Anillo de Infinita sabiduría
21412	Sudario de Infinita Sabiduría
21413	Hoja de secretos oscuros
21414	Sortija de Secretos oscuros
21415	Mantón de Secretos oscuros
21416	Puñal hindú de nombres prohibidos
21417	Anillo de nombres prohibidos
21418	Sudario de nombres prohibidos
21436	Sello de mención de honor de la Alianza
21438	Sello de honor de la Alianza
21452	Bastón de las Ruinas
21453	Manto de los Horusath
21454	Hombreras de piedra rúnica
21455	Yelmo Viento del Sur
21456	Capa Tormenta de Arena
21457	Brazales de Brutalidad
21458	Guanteletes de Nueva Vida
21459	Ballesta de Maldición inminente
21460	Yelmo de Dominación
21461	Leotardos de la ventisca negra
21462	Guantes de Sabiduría oscura
21463	Brazal de Osirio
21464	Grilletes del Sinmarcas
21466	Aguijonero de Ayamiss
21467	Coraza de silítido gruesa
21468	Manto de Maz'Nadir
21469	Guanteletes de Viento del Sur
21470	Capa del Salvador
21471	Talón de Concentración de furia
21472	Turbante viento polvoriento
21473	Ojo de Moam
21474	Guardahombros de quitina
21475	Musleras del Destructor
21476	Leotardos escamados obsidianos
21477	Anillo de Furia
21478	Arco de tendón tenso
21479	Guanteletes del Inamovible
21480	Guanteletes de silítido escamados
21481	Botas del Protector del desierto
21482	Botas de las Arenas ígneas
21483	Anillo de los Vientos del desierto
21484	Yelmo de Recrecimiento
21485	Fragmento de la calavera de Buru
21486	Guantes del Enjambre
21487	Guanteletes escamados babosos
21488	Fetiche de pinchos de quitina
21489	Aves arena rápida
21490	Chanclos para babosas
21491	Brazales escamados del Glotón
21492	Destripador de los Qiraji
21493	Botas de la Soldado de Caballería
21494	Garra Viento del Sur
21495	Musleras del comando Qiraji
21496	Brazales de Orden Qiraji
21497	Botas del general Qiraji
21498	Daga Qiraji de sacrificios
21499	Vestimentas del Mar de dunas
21500	Cinturón de la Inquisición
21501	Guantes de pellejo de silítido fortalecido
21502	Muñequeras de atracador de arena
21503	Cinturón del Atracador de arena
21504	Talismán del Mar de Dunas
21505	Gargantilla del Mar de Dunas
21506	Colgante del Mar de Dunas
21507	Amuleto del Mar de Dunas
21508	Marca de Cenarius
21509	Suministros de la campaña solidaria de Ahn'Qiraj
21510	Suministros de la campaña solidaria de Ahn'Qiraj
21511	Suministros de la campaña solidaria de Ahn'Qiraj
21512	Suministros de la campaña solidaria de Ahn'Qiraj
21513	Suministros de la campaña solidaria de Ahn'Qiraj
21514	Informe de tareas logísticas 11
21515	Marca de Rémulos
21517	Turbante de poderío psíquico gnómico
21519	Muérdago
21520	Legado de Cresta Cuervo
21521	Espada rúnica de los rojos
21522	Pena de Cantosombrío
21523	Colmillo de Korialstrasz
21524	Sombrero de invierno rojo
21525	Sombrero de invierno verde
21526	Sortija de Prolavades heladas
21527	Togas Aguaoscura
21528	Bolsa de botín colosal
21529	Amuleto de Escudo de las Sombras
21530	Leotardos incrustados de ónice
21531	Collar de dientes de draco
21532	Botas de esclavo
21533	Coloso de colmillo de Zora
21534	Coloso de comillo de Ashi
21535	Coloso de colmillo de Regal
21536	Piedra elunarita
21537	Albóndigas festivas
21538	Vestido de fiesta rosa
21539	Vestido de fiesta morado
21540	Farol de Elune
21541	Traje de pantalón de fiesta negro
21542	Traje de fiesta
21543	Traje de pantalón de fiesta con cerceta
21544	Traje de pantalón de fiesta azul
21545	Provisiones de Bosquehumeante
21546	Elixir de poder de Fuego superior
21547	Receta: elixir de poder de Fuego superior
21548	Patrón: guantes Velotormenta
21552	Serviola a rayas
21557	Cohete rojo pequeño
21558	Cohete azul pequeño
21559	Cohete verde pequeño
21560	Cohete morado pequeño
21561	Cohete blanco pequeño
21562	Cohete amarillo pequeño
21563	Sortija de Don Rodrigo
21565	Runa de Perfección
21566	Runa de Perfección
21567	Runa de Deber
21568	Runa de Deber
21569	Lanzacohetes pirotécnico
21570	Lanzacohetes
21571	Ristra de cohetes azules
21574	Ristra de cohetes verdes
21575	Ristra de cohetes morados
21576	Ristra de cohetes rojos
21577	Ristra de cohetes blancos
21578	Ristra de cohetes amarillos
21579	Tentáculo derrotado de C'Thun
21581	Guanteletes de Aniquilación
21582	Garra del dios antiguo
21583	Capa de Claridad
21584	Brazales de Juicio eterno
21585	Guanteletes de Tormenta oscura
21586	Cinturón de Agonía interminable
21587	Muñequeras de Castigo
21588	Muñequeras de Furia elemental
21589	Cohete azul grande
21590	Cohete verde grande
21591	Cohete morado grande
21592	Cohete rojo grande
21593	Cohete blanco grande
21594	Brazales del Hijo caído
21595	Cohete amarillo grande
21596	Anillo del destripadioses
21597	Cetro real de Vek'lor
21598	Cinturón Qiraji real
21599	Guantes de Devastación de Vek'lor
21600	Botas de epifanía
21601	Anillo del Emperador Vek'lor
21602	Brazales Qiraji de ejecución
21603	Varita de Nobleza Qiraji
21604	Brazaletes de redención real
21605	Guantes del Templo oculto
21606	Cinturón del Emperador caído
21607	Garra del emperador caído
21608	Amuleto de Vek'nilash
21609	Cinturón regenerador de Vek'nilash
21610	Bloqueador de escamas de gusano
21611	Brazales escarbador
21612	Vapuleadores de escamas de gusano
21613	Botas de pellejo de gusano
21614	Protector de pellejo de gusano
21615	Sombrero perdido de Don Rigoberto
21616	Aguijonero de Huhuran
21617	Guanteletes de pellejo de avispa
21618	Muñequeras de colmena Rapiñador
21619	Guantes del Mesías
21620	Anillo del mártir
21621	Capa de la Colmena dorada
21622	Fémur de silítido afilado
21623	Guanteletes de Campeón recto
21624	Guanteletes de Kalimdor
21625	Broche escarabajo
21626	Leotardos cubiertos de baba
21627	Capa de los Secretos ocultos
21635	Púa del atracador de arena
21639	Espaldares del Implacable
21640	Paquete de fuegos artificiales del Festival Lunar
21645	Botas de tunelador de colmena
21647	Fetiche del Atracador de arena
21648	Botas recompuestas
21650	Destripador Qiraji antiguo
21651	Leotardos escamados de atracador de arena
21652	Coraza caparazón de silítido
21663	Togas del Santo guardián
21664	Gargantilla de púas
21665	Manto de la Revancha Horrenda
21666	Poderío de Sartura
21667	Musleras de Luz resplandeciente
21668	Leotardos escamados de furia Qiraji
21669	Yelmo parra reptadora
21670	Insignia del Guardaenjambre
21671	Togas del Guardia de batalla
21672	Guantes de Aplicación
21673	Garra de silítido
21674	Guanteletes de Determinación férrea
21675	Cinturón de pellejo Qiraji grueso
21676	Leotardos del Enjambre ulceroso
21677	Anillo de Furia Qiraji
21678	Collar de Puridad
21679	Revancha de Kalimdor
21680	Jubón de Ejecución veloz
21681	Anillo del devorado
21682	Guanteletes cubiertos de bilis
21683	Manto de la Cruzada del Desierto
21684	Manto de la Furia del Desierto
21685	Escarabajo petrificado
21686	Manto de Poder frénico
21687	Anillo de oscuridad de Ukko
21688	Botas del Héroe caído
21689	Guantes de Ebru
21690	Talismán de Angelista
21691	Guanteletes comidos de moco
21692	Faja de triada
21693	Apariencia del Devorador
21694	Manto ternario
21695	Toque de Angelista
21696	Togas del Triunvirato
21697	Manteo de la Trinidad
21698	Leotardos de Inmersión
21699	Hombreras de bombardeo
21700	Colgante del guardián Qiraji
21701	Capa de Odio concentrado
21702	Amuleto de Guardia del mal
21703	Martillo de Ji'zhi
21704	Botas de la Profecía cumplida
21705	Botas del Profeta caído
21706	Botas de la Voluntad inquebrantable
21707	Anillo de enjambre de pensamientos
21708	Muñequeras de escamas de escarabajo
21709	Anillo del Dios caído
21710	Capa del Dios caído
21711	Invitación al Festival Lunar
21712	Amuleto del Dios caído
21713	Vela de Elune
21714	Ristra de cohetes azules grandes
21715	Martillo pulido con arena
21716	Ristra de cohetes verdes grandes
21717	Ristra de cohetes morados grandes
21718	Ristra de cohetes rojos grandes
21719	Ristra de cohetes blancos grandes
21720	Ristra de cohetes amarillos grandes
21721	Resplandor lunar
21722	Patrón: vestido de fiesta
21723	Patrón: traje de fiesta
21724	Esquema: cohete azul pequeño
21725	Esquema: cohete verde pequeño
21726	Esquema: cohete rojo pequeño
21727	Esquema: cohete azul grande
21728	Esquema: cohete verde grande
21729	Esquema: cohete rojo grande
21730	Esquema: ristra de cohetes azules
21731	Esquema: ristra de cohetes verdes
21732	Esquema: ristra de cohetes rojos
21733	Esquema: ristra de cohetes azules grandes
21734	Esquema: ristra de cohetes verdes grandes
21735	Esquema: ristra de cohetes rojos grandes
21736	Riendas de montar grifos
21737	Esquema: lanzacohetes
21738	Esquema: lanzacohetes pirotécnico
21740	Recetas de cohete pequeño
21741	Recetas de ristra de cohetes
21742	Recetas de cohetes grandes
21743	Recetas de ristra de cohetes grandes
21744	Ristra de cohetes de la suerte
21745	Piedra lunar de anciano
21746	Sobre rojo de la suerte
21747	Petardo festivo
21749	Informe de tarea de combate 1
21750	Informe de tarea de combate 3
21751	Instrucciones de la misión táctica 4
21761	Llave de cofre escarabajo
21762	Llave de cofre de escarabajo superior
21800	Lanzacáscaras de silítido
21801	Antena de tonificación
21802	El puñal hindú perdido de Zedd
21803	Yelmo del Vengador Sagrado
21804	Almófar de Furia elemental
21805	Espaldares obsidianos pulidos
21806	Mazo de Autoridad Qiraji
21809	Furia del Enjambre olvidado
21810	Botines de nómada errante
21812	Caja de bombones
21813	Bolsa de caramelos
21814	Peto de Aniquilación
21815	Prueba de amor
21816	Corazón de caramelo
21817	Corazón de caramelo
21818	Corazón de caramelo
21819	Corazón de caramelo
21820	Corazón de caramelo
21821	Corazón de caramelo
21822	Corazón de caramelo
21823	Corazón de caramelo
21829	Botella de perfume
21830	Envoltorio vacío
21831	Obsequio envuelto
21833	Botella de colonia
21836	Anillo de caos de Ritssyn
21837	Martillo de guerra Anubisath
21838	Atuendo de Ascensión Real
21839	Cetro del falso profeta
21856	Neretzek, el Sediento de Sangre
21888	Guantes del Inmortal
21889	Guantes de la Profecía redimida
21890	Guantes del Profeta caído
21891	Fragmento de la Estrella caída
21920	Carta arrugada
21921	Nota escrita con pluma con cuidado
21925	Carta inmaculada
21926	Nota ligeramente arrugada
21928	Muestra de sangre de Cuna del Invierno
21935	Ectoplasma de establo
21936	Ectoplasma congelado
21937	Ectoplasma abrasado
21938	Núcleo de magma
21939	Biela de inferi elemental
21946	Destilador ectoplásmico
21960	Silvicultura artesanal
21975	Juramento de Adoración: Ventormenta
21979	Ofrenda de adoración: Darnassus
21980	Ofrenda de adoración: Forjaz
21981	Ofrenda de adoración: Ventormenta
21982	Abalorios de guerra de ogro
21983	Estandarte de la Provocación incompleto
21984	Parte izquierda del amuleto de Lord Valthalak
21985	Contenedor de sangre sellado
21986	Estandarte de provocación
21987	Incendicita de Lord Incendius
21988	Ascua de la Llama
21989	Rescoldo de las brasas
21994	Cinturón de Heroísmo
21995	Botas de heroísmo
21996	Brazales de Heroísmo
21997	Peto de Heroísmo
21998	Guanteletes de Heroísmo
21999	Yelmo de Heroísmo
22000	Musleras de Heroísmo
22001	Bufas de heroísmo
22002	Cinturón Mantoscuro
22003	Botas Mantoscuro
22004	Brazales Mantoscuro
22005	Capa Mantoscuro
22006	Guantes Mantoscuro
22007	Pantalones Mantoscuro
22008	Bufas Mantoscuro
22009	Túnica Mantoscuro
22010	Cinturón de maestro de bestias
22011	Ataduras de maestro de bestias
22013	Almete de maestro de bestias
22014	Brazal Sagrado
22015	Guantes de maestro de bestias
22016	Manto de maestro de bestias
22017	Pantalones de maestro de bestias
22046	Parte derecha del amuleto Lord Valthalak
22047	Parte superior del amuleto de Lord Valthalak
22048	Amuleto de Lord Valthalak
22049	Blandón de Señalización
22050	Blandón de Señalización
22051	Blandón de Señalización
22052	Blandón de Señalización
22056	Blandón de Señalización
22057	Blandón de Invocación
22058	Papel y sobres para cartas de San Valentín
22059	Tarjeta de San Valentín
22060	Túnica de maestro de bestias
22061	Botas de maestro de bestias
22062	Cinturón de hechicero
22063	Ataduras de hechicero
22064	Botas de hechicero
22065	Corona de hechicero
22066	Guantes de hechicero
22067	Leotardos de hechicero
22068	Manto de hechicero
22069	Togas de hechicero
22070	Cinturón Brumamorta
22071	Brazales Brumamorta
22072	Leotardos Brumamorta
22073	Manto Brumamorta
22074	Máscara Brumamorta
22075	Toga Brumamorta
22076	Sandalias Brumamorta
22077	Brazaletes Brumamorta
22078	Cinturón virtuoso
22079	Brazales virtuosos
22080	Corona virtuosa
22081	Guantes virtuosos
22082	Manto virtuoso
22083	Toga virtuosa
22084	Sandalias virtuosas
22085	Falda virtuosa
22086	Cinturón Forjaalma
22087	Botas Forjaalma
22088	Brazales Forjaalma
22089	Peto Forjaalma
22090	Guanteletes Forjaalma
22091	Yelmo Forjaalma
22092	Quijotes Forjaalma
22093	Bufas Forjaalma
22094	Kelp de sangre
22095	Ataduras de Cinco Truenos
22096	Botas de los Cinco Truenos
22097	Almófar de los Cinco Truenos
22098	Cordón de los Cinco Truenos
22099	Guanteletes de los Cinco truenos
22100	Falda escocesa de los Cinco Truenos
22101	Espaldares de los Cinco Truenos
22102	Jubón de los Cinco truenos
22106	Cinturón Cuoroferal
22107	Botas Cuoroferal
22108	Brazales Cuoroferal
22109	Capucha Cuoroferal
22110	Guantes Cuoroferal
22111	Falda escocesa Cuoroferal
22112	Bufas Cuoroferal
22113	Jubón Cuoroferal
22114	Huevo múrloc rosa
22115	Detector de fantasmas extradimensional
22117	Juramento de Lealtad: Ventormenta
22119	Juramento de Lealtad: Forjaz
22120	Juramento de Lealtad: Darnassus
22121	Juramento de Lealtad: Entrañas
22122	Juramento de Lealtad: Cima del Trueno
22123	Juramento de Lealtad: Orgrimmar
22130	Símbolo de Amor
22131	Colección de obsequios de Ventormenta
22132	Colección de obsequios de Forjaz
22133	Colección de obsequios de Darnassus
22134	Colección de obsequios de Entrañas
22135	Colección de obsequios de Cima del Trueno
22136	Colección de obsequios de Orgrimmar
22137	Cartera de Ysida
22138	Brazal Roca Negra
22139	Dije de Ysida
22140	Tarjeta de centinela
22141	Tarjeta de guardia de Forjaz
22142	Tarjeta de bruto
22143	Tarjeta de guardia de Ventormenta
22144	Tarjeta de guardián del Trueno
22145	Tarjeta mohosa de guardián
22149	Cuentas de Mojo de ogro
22150	Cuentas de Poderío de ogro
22151	Agua bendita de Anthion
22152	Faltriquera de Anthion
22154	Juramento de Adoración: Forjaz
22155	Juramento de Adoración: Darnassus
22156	Juramento de Adoración: Orgrimmar
22157	Juramento de Adoración: Entrañas
22158	Juramento de Adoración: Cima del Trueno
22159	Juramento de Amistad: Darnassus
22160	Juramento de Amistad: Forjaz
22161	Juramento de Amistad: Orgrimmar
22162	Juramento de Amistad: Cima del Trueno
22163	Juramento de Amistad: Entrañas
22164	Ofrenda de adoración: Orgrimmar
22165	Ofrenda de adoración: Cima del Trueno
22166	Ofrenda de adoración: Entrañas
22167	Ofrenda de amistad: Darnassus
22168	Ofrenda de amistad: Forjaz
22169	Ofrenda de amistad: Orgrimmar
22170	Ofrenda de amistad: Ventormenta
22171	Ofrenda de amistad: Cima del Trueno
22172	Ofrenda de amistad: Entrañas
22173	Brebaje casero enano
22174	Poema romántico
22175	Tarta recién horneada
22176	Pan casero
22177	Flores recién cogidas
22178	Juramento de Amistad: Ventormenta
22191	Túnica de malla obsidiana
22192	Elixir para Elusión de kelp de sangre
22193	Elixir de Resistencia de kelp de sangre
22194	Garra negra del Destructor
22195	Cinturón obsidiano ligero
22196	Peto obsidiano grueso
22197	Cinturón obsidiano pesado
22198	Escudo dentado obsidiano
22200	Flecha con astil de plata
22201	Relicario de Pureza
22202	Fragmento obsidiano pequeño
22203	Fragmento obsidiano grande
22204	Muñequeras de Renombre
22205	Ataduras de acero negro
22206	Ramo de rosas rojas
22207	Fajín del Gran cazador
22208	Martillo de piedra de lava
22209	Diseño: cinturón obsidiano pesado
22212	Espaldares a medida gólem
22214	Diseño: cinturón obsidiano ligero
22216	Glándula de veneno de Venoxis
22217	Glándula de veneno de Kurinnaxx
22218	Un puñado de pétalos de rosa
22219	Diseño: escudo dentado obsidiano
22220	Diseño: garra negra del Destructor
22221	Diseño: túnica de malla obsidiana
22222	Diseño: peto obsidiano grueso
22223	Protector de cabeza de supervisor
22224	Esencia de espectro irrisorio
22225	Capucha de piel de dragón
22226	Restos druidas
22227	Reliquia de Aldea Brisaestelar
22228	Espada de integrismo luminosa
22229	Cenizas de alma del Desterrado
22230	Pellejo Morromiedo
22231	Botas de precisión de Kayser
22232	Faja de tirador
22233	Baúl de Zigris
22234	Manto de Esperanza Perdida
22235	Astil de flecha de veraplata
22236	Delicia de crema
22237	Deseo oscuro
22238	Crema de frutos cremosa
22239	Dulce sorpresa
22240	Grebas de Desesperación fulminante
22241	Espaldares de guarda oscuro
22242	Correa de Verek
22243	Faltriquera de almas pequeña
22244	Caja de almas
22245	Calzado taraceado con tizne
22246	Faltriquera de paño mágico encantado
22247	Botas de curador de fe
22248	Paño rúnico encantado
22249	Bolsa de encantamiento grande
22250	Faltriquera de hierbas
22251	Bolsa de hierbas Cenarion
22252	Cartera de Cenarius
22253	Escrito de los Perdidos
22254	Varita de Luz eterna
22255	Sortija forjada de magma
22256	Mitones para moldear maná
22257	Sortija de coágulo de sangre
22258	Poción de amor
22259	Pulsera de Amistad no depositada
22260	Pulsera de la amistad
22261	Loco de amor
22262	Colección de obsequios de la Alianza
22263	Colección de obsequios de la Horda
22264	Carta escrita con cuidado
22265	Carta escrita con amor
22266	Erupción de espinas
22267	Turbante de tejechizos
22268	Emblema dracónico imbuido
22269	Capa de merodeador de las Sombras
22270	Botas de atrincheramiento
22271	Leotardos de Magia frenética
22272	Abrazo del bosque
22273	Caperuza Sombra Lunar
22274	Pelambre canoso
22275	Botas Musgo de Fuego
22276	Vestido rojo precioso
22277	Traje de cena rojo
22278	Vestido azul precioso
22279	Vestido negro precioso
22280	Vestido morado precioso
22281	Traje de cena azul
22282	Traje de cena morado
22283	Saco de pan casero
22284	Montón de cartas
22285	Colección de prendas de Ventormenta
22286	Colección de prendas de Forjaz
22287	Caja de cartas
22288	Caja de cerveza casera
22289	Montón de cartas
22290	Colección de prendas de Darnassus
22291	Caja de carpintero
22292	Caja de pasteles
22293	Paquete de cartas
22294	Colección de juramentos de Orgrimmar
22295	Cartera de cartas
22296	Cesta de flores
22297	Colección de prendas de Cima del Trueno
22298	Libro sobre Poemas románticos
22299	Fajo de cartas
22300	Colección de prendas de Entrañas
22301	Toga Hilacero
22302	Capucha Hilacero
22303	Pantalones Hilacero
22304	Guantes Hilacero
22305	Manto Hilacero
22306	Cinturón Hilacero
22307	Patrón: faltriquera de paño mágico encantado
22308	Patrón: bolsa de paño rúnico encantado
22309	Patrón: bolsa de encantamiento grande
22310	Patrón: bolsa de hierbas Cenarion
22311	Botas Hilacero
22312	Patrón: cartera de Cenarius
22313	Brazales Hilacero
22314	Arpón de cazador
22315	Martillo de Revitalización
22317	Nudillos de latón para zurdo
22318	Arco largo de Malgen
22319	Escrito sobre Derecho divino
22320	Víveres de calidad de Mux
22321	Corazón de Vermisthalak
22322	El rompe mandíbulas
22324	Kimchi de invierno
22325	Cinturón del Timador
22326	Sortija de amalgama
22327	Amuleto de los redimidos
22328	Musleras de Vigilancia
22329	Cetro de Enfoque interminable
22330	Sudario de Maestría Arcana
22331	Sortija del Héroe férreo
22332	Hoja de Necromancia
22333	Martillo de Poderío divino
22334	Sortija de Reparación
22335	Bastón de orden de Lord Valthalak
22336	Égida draconiana de la Legión
22337	Sudario de Dominación
22338	Ceniza volcánica
22339	Sortija rúnica de brujería
22340	Colgante de Celeridad
22342	Leotardos de Tormento
22343	Manoplas de Ferocidad
22344	Blandón de Invocación: manual
22345	Tótem de Renacimiento
22347	Repetidor de recarga de Fahrad
22348	Prima de Condemulus
22349	Peto profanado
22350	Túnica profanada
22351	Toga profanada
22352	Quijotes profanados
22353	Yelmo profanado
22354	Espaldares profanados
22355	Brazales profanados
22356	Guardarrenes profanados
22357	Guanteletes profanados
22358	Escarpes profanados
22359	Musleras profanadas
22360	Celada profanada
22361	Bufas profanadas
22362	Muñequeras profanadas
22363	Faja profanada
22364	Manoplas profanadas
22365	Botas profanadas
22366	Leotardos profanados
22367	Aro profanado
22368	Hombreras profanadas
22369	Ataduras profanadas
22370	Cinturón profanado
22371	Guantes profanados
22372	Sandalias profanadas
22373	Restos de cuero
22374	Restos de malla
22375	Restos de coraza
22376	Restos de ropa
22377	El atizador Truenedera
22378	Rebanadora Ravenholdt
22379	Shiv de Shivsprocket
22380	Martillo de cultivo de Simone
22381	Muestra de veneno de Silithus
22382	Contenedor de veneno sellado
22383	Hoja sabia
22384	Persuasor
22385	Leotardos titánicos
22386	Head of Instructor Razuvious DEP
22387	Corazón de Anub'Rekhan
22388	Diseño: leotardos titánicos
22389	Diseño: hoja sabia
22390	Diseño: persuasor
22392	Fórmula: encantar arma de 2M: agilidad
22393	Códice: Rezo de protección de las Sombras
22394	Bastón de Metanoia
22395	Tótem de Ira
22396	Tótem de Vida
22397	Ídolo de Ferocidad
22398	Ídolo de Rejuvenecimiento
22399	Ídolo de Salud
22400	Tratado sobre Verdad
22401	Tratado sobre Esperanza
22402	Tratado sobre Gracia
22403	Collar de conchas nacaradas
22404	Rascaespalda de Willey
22405	Manto de la Cruzada Escarlata
22406	Redención
22407	Yelmo de la Luna nueva
22408	Varita de mojo maligno de Ritssyn
22409	Túnica de la Media Luna
22410	Guanteletes de Destreza
22411	Yelmo del Ejecutor
22412	Manto Thuzadin
22416	Peto Acorator
22417	Quijotes Acorator
22418	Casco Acorator
22419	Hombreras Acorator
22420	Escarpes Acorator
22421	Guanteletes Acorator
22422	Guardarrenes Acorator
22423	Brazales Acorator
22424	Muñequeras de redención
22425	Túnica de redención
22426	Manoplas de redención
22427	Musleras de redención
22428	Celada de redención
22429	Bufas de redención
22430	Botas de redención
22431	Faja de redención
22432	Púa de demosaurio
22433	Sortija de Dominación de Don Mauricio
22434	Champiñón de sangre
22435	Aguijón Gorishi
22436	Túnica acechacriptas
22437	Musleras acechacriptas
22438	Celada acechacriptas
22439	Bufas acechacriptas
22440	Botas acechacriptas
22441	Manoplas acechacriptas
22442	Faja acechacriptas
22443	Muñequeras acechacriptas
22444	Viña podrida
22458	Bastón Sombra Lunar
22464	Túnica Rompeterra
22465	Musleras Rompeterra
22466	Celada Rompeterra
22467	Bufas Rompeterra
22468	Botas Rompeterra
22469	Manoplas Rompeterra
22470	Faja Rompeterra
22471	Muñequeras Rompeterra
22472	Botas de ferocidad
22476	Peto segahuesos
22477	Quijotes segahuesos
22478	Casco segahuesos
22479	Espaldares segahuesos
22480	Escarpes segahuesos
22481	Guanteletes segahuesos
22482	Guardarrenes segahuesos
22483	Brazales segahuesos
22484	Runa necrótica
22488	Túnica Caminasueños
22489	Musleras Caminasueños
22490	Celada Caminasueños
22491	Bufas Caminasueños
22492	Botas Caminasueños
22493	Manoplas Caminasueños
22494	Faja Caminasueños
22495	Muñequeras Caminasueños
22496	Toga Escarchafuego
22497	Leotardos Escarchafuego
22498	Aro Escarchafuego
22499	Hombreras Escarchafuego
22500	Sandalias Escarchafuego
22501	Guantes Escarchafuego
22502	Cinturón Escarchafuego
22503	Ataduras Escarchafuego
22504	Toga Corazón de la Peste
22505	Leotardos Corazón de la Peste
22506	Aro Corazón de la Peste
22507	Hombreras Corazón de la Peste
22508	Sandalias Corazón de la Peste
22509	Guantes Corazón de la Peste
22510	Cinturón Corazón de la Peste
22511	Ataduras Corazón de la Peste
22512	Toga de Fe
22513	Leotardos de Fe
22514	Aro de Fe
22515	Hombreras de Fe
22516	Sandalias de Fe
22517	Guantes de Fe
22518	Cinturón de Fe
22519	Ataduras de Fe
22520	La filacteria de Kel'Thuzad
22523	Insignia del Alba
22524	Insignia de Cruzados
22525	Trozos de demonio de cripta
22526	Fragmentos de huesos
22527	Núcleo de elementos
22528	Sobras Hierro Negro
22529	Fronda indómita
22568	Libranza de artesano lacrada
22589	Atiesh, gran báculo del Guardián
22593	Libranza de paso seguro
22595	Anuncio del llamamiento a las armas
22600	Libranza del artesano: piedrafuerte densa
22601	Libranza del artesano: peto de placas imperiales
22602	Libranza del artesano: martillo volcánico
22603	Libranza del artesano: hacha de batalla de torio enorme
22604	Libranza del artesano: aro radiante
22605	Libranza del artesano: cinta de cuero maligno
22606	Libranza del artesano: complemento basto para armadura
22607	Libranza del artesano: cinturón de cuero maligno
22608	Libranza del artesano: pantalones de cuero rúnico
22609	Libranza del artesano: pantalones de paño brillante
22610	Libranza del artesano: botas de paño rúnico
22611	Libranza del artesano: bolsa de paño rúnico
22612	Libranza del artesano: toga de paño rúnico
22613	Libranza del artesano: carga de zapador goblin
22614	Libranza del artesano: granada de torio
22615	Libranza del artesano: pollo de batalla gnomo
22616	Libranza del artesano: tubo de torio
22617	Libranza del artesano: poción de maná sublime
22618	Libranza del artesano: poción de curación sublime
22619	Libranza del artesano: poción de protección de Escarcha superior
22620	Libranza del artesano: poción de protección Arcana superior
22621	Libranza del artesano: frasco de petrificación
22622	Libranza del artesano: anguila Escama Tormentosa
22623	Libranza del artesano: pez coraza de placas
22624	Libranza del artesano: anguila relámpago
22625	Libranza del artesano: salmón al horno
22626	Libranza del artesano: sorpresa de tubérculo runtún
22630	Atiesh, gran báculo del Guardián
22631	Atiesh, gran báculo del Guardián
22632	Atiesh, gran báculo del Guardián
22635	Integumento de lo salvaje
22636	Integumento de hielo
22637	Ídolo Hakkari primigenio
22638	Integumento de las Sombras
22648	Informe sobre Colmen'Ashi
22649	Informe Colmen'Regal
22650	Informe sobre Colmen'Zora
22651	Musleras de placas de escolta
22652	Jubón glacial
22654	Guantes glaciales
22655	Muñequeras glaciales
22656	El purificador
22657	Amuleto del Alba
22658	Capa glacial
22659	Medallón del Alba
22660	Abrazo de Gaea
22661	Túnica polar
22662	Guantes polares
22663	Brazales polares
22664	Peto de escamas heladas
22665	Brazales de escamas heladas
22666	Guanteletes de escamas heladas
22667	Brazales de Esperanza
22668	Brazales de Subterfugio
22669	Peto Deliriohelado
22670	Guanteletes Deliriohelado
22671	Brazales Deliriohelado
22672	Musleras de láminas de centinela
22673	Leotardos de anillas de escolta
22676	Leotardos de malla de escolta
22678	Talismán de Ascendencia
22679	Bolsa de suministro
22680	Sortija de Resolución
22681	Sortija de Piedad
22682	Runa congelada
22683	Patrón: abrazo de Gaea
22684	Patrón: guantes glaciales
22685	Patrón: capa glacial
22686	Patrón: jubón glacial
22687	Patrón: muñequeras glaciales
22688	Último recurso de Verimonde
22689	Yelmo de cuero santificado
22690	Leotardos del Cazador de la Peste
22691	Crematoria corrupta
22692	Patrón: túnica polar
22694	Patrón: guantes polares
22695	Patrón: brazales polares
22696	Patrón: peto de escamas heladas
22697	Patrón: guanteletes de escamas heladas
22698	Patrón: brazales de escamas heladas
22699	Leotardos Deliriohelado
22700	Leotardos glaciales
22701	Leotardos polares
22702	Leotardos de escamas heladas
22703	Diseño: coraza Deliriohelado
22704	Diseño: guanteletes Deliriohelado
22705	Diseño: brazales Deliriohelado
22707	Garra helada de Ramaladni
22708	Destino de Ramaladni
22711	Capa de los Fieles Hakkari
22712	Poderío de la Tribu
22713	Cetro zulian de Ritos
22714	Guanteletes de sacrificio
22715	Guantes del Atormentado
22716	Cinturón de la poder sin explotar
22718	Máscara empapada de sangre
22719	Vademécum de Omarion
22720	Penacho Zulian
22721	Sortija de Servidumbre
22722	Lacre de rabioso Gurubashi
22723	Una carta del Guardián de los Pergaminos
22725	Sortija de Cenarius
22726	Astilla de Atiesh
22727	Armazón de Atiesh
22728	Mando de tanque a vapor
22729	Esquema: mando de tanque a vapor
22730	Cordón cinturón Acecha ojos
22731	Capa de los Devorados
22732	Marca de C'Thun
22733	Cabeza del báculo Atiesh
22734	Base de Atiesh
22736	Andonisus, Segador de almas
22737	Atiesh, gran báculo del Guardián
22739	Escrito sobre Polimorfismo: tortuga
22740	Pantalones de cuero de escolta
22741	Pantalones de pellejo de lagarto de escolta
22742	Camisa Velasangre
22743	Fajín Velasangre
22744	Botas Velasangre
22745	Pantalones Velasangre
22746	Uniforme de bucanero
22747	Leotardos de seda de escolta
22748	Leotardos de anillas de centinela
22749	Pantalones de cuero de centinela
22750	Pantalones de pellejo de lagarto
22752	Leotardos de seda de centinela
22753	Musleras de láminas de centinela
22754	Quintaesencia eterna
22756	Jubón nemoroso
22757	Corona nemorosa
22758	Hombreras nemorosas
22759	Yelmo zarzal
22760	Botas zarzal
22761	Cinturón zarzal
22762	Peto Parraférrea
22763	Guantes Parraférrea
22764	Cinturón Parraférrea
22765	Carta enmohecida
22766	Diseño: peto Parraférrea
22767	Diseño: guantes Parraférrea
22768	Diseño: cinturón Parraférrea
22769	Patrón: cinturón zarzal
22770	Patrón: botas zarzal
22771	Patrón: yelmo zarzal
22772	Patrón: hombreras nemorosas
22773	Patrón: corona nemorosa
22774	Patrón: jubón nemoroso
22780	Huevo de múrloc blanco
22781	Collar de oso polar
22798	Poderío de Menethil
22799	Buscador de almas
22800	Bastón de azufre
22801	Aguja del Crepúsculo
22802	Caída del rey
22803	Bruma de medianoche
22804	Colmillo de Maexxna
22806	Remordimiento de viuda
22807	Espada de aparición
22808	El castigador
22809	Gran maza del cruzado redimido
22810	Inyector tóxico
22811	Hilo de alma
22812	Esclavizador nerubio
22813	Espada claymore de Poderío profano
22815	División
22816	Hachuela de hueso partido
22818	El portador de la peste
22819	Escudo de Condena
22820	Varita de Fortunas
22821	Dedo condena
22822	iCoke Prize Voucher
22843	Grebas de Guardia de sangre
22852	Botines de pellejo de dragón de Guardia de sangre
22855	Botos tejedor de tinieblas de Guardia de sangre
22856	Botos de cuero de Guardia de sangre
22857	Grebas de malla de Guardia de sangre
22858	Grebas de placas de Guardia de sangre
22859	Botos de raso de Guardia de sangre
22860	Botos de seda de Guardia de sangre
22862	Vicio de anillas de Guardia de sangre
22863	Mandiletes de pellejo de dragón de Guardia de sangre
22864	Mandiletes de cuero de Guardia de sangre
22865	Mitones tejedor de tinieblas de Guardia de sangre
22867	Vicio de malla de Guardia de sangre
22868	Guanteletes de placas de Guardia de sangre
22869	Mitones de raso de Guardia de sangre
22870	Mitones de seda de Guardia de sangre
22872	Camisote de placas de legionario
22873	Leotardos de placas de legionario
22874	Camisote de anillas de legionario
22875	Musleras de anillas de legionario
22876	Camisote de malla de legionario
22877	Coraza de pellejo de dragón de legionario
22878	Leotardos de pellejo de dragón de legionario
22879	Coraza de cuero de legionario
22880	Musleras de cuero de legionario
22881	Musleras tejedor de tinieblas de legionario
22882	Musleras de raso de legionario
22883	Musleras de seda de legionario
22884	Túnica tejedor de tinieblas de legionario
22885	Túnica de raso de legionario
22886	Túnica de seda de legionario
22887	Musleras de malla de legionario
22890	Escrito sobre Custodia de Escarcha 5
22891	Grimorio de Pupilo de las Sombras IV
22892	Piedra necrótica oscura
22895	Rollito de canela mágico
22897	Escrito sobre Conjurar comida 7
22930	Un sobre manchado de sangre
22932	Una carta rota
22935	Toque de Escarcha
22936	Muñequeras de Venganza
22937	Gema de Nerubis
22938	Capa de seda de demonio de cripta
22939	Sortija de Plegarias sin respuesta
22940	Espaldares Deliriohelado
22941	Hombreras polares
22942	El abrazo de la viuda
22943	Colgante de piedra malicia
22944	Una misiva arrugada
22945	Una nota con tono de agobio
22946	Una página hecha jirones
22947	Colgante de Nombres Olvidados
22948	Un documento manchado
22949	Cristal necrótico rajado
22950	Cristal necrótico tenue
22954	Beso de la araña
22960	Capa de Sutura
22961	Sortija de Reanimación
22967	Bufas de escamas heladas
22968	Manto glacial
22970	Un sobre manchado de sangre
22972	Una nota con tono de agobio
22973	Una misiva arrugada
22974	Una página hecha jirones
22975	Un documento manchado
22977	Una carta rota
22981	Collar perdido de Gluth
22983	Manto cubierto de Escarcha
22988	El fin de los sueños
22994	Compendio de Mano de Poder
22999	Tabardo del Alba Argenta
23000	Jaula de costillas de abominación con placas
23001	Ojo de Disminución
23002	Carcasa de tortuga
23004	Ídolo de Longevidad
23005	Tótem de Agua que fluye
23006	Tratado sobre Luz
23007	Collar de Piglet
23008	Informe de investigación lacrado
23009	Varita de la Muerte susurrante
23010	Informe de investigación lacrado
23011	Informe de investigación lacrado
23012	Informe de investigación lacrado
23013	Informe de investigación lacrado
23014	Hoja insaciable
23015	Jaula de ratas
23016	Informe de investigación lacrado
23017	Velo de eclipse
23018	Sello del Defensor caído
23019	Casco Deliriohelado
23020	Casco polar
23021	Las ataduras del cosechador de almas
23022	Pago de Curmudgeon
23023	Collar de sádico
23024	Papeles de servicio de campo listos
23025	Lacre del Condenado
23027	Calor de Perdón
23028	Sortija de granizo
23029	Corazón frígido de Noth
23030	Capa de la Plaga
23031	Sortija de lo Inevitable
23032	Penacho glacial
23033	Almófar de escamas heladas
23034	Nax PH Crit Plate Shoulders
23035	Sombrero de preceptor
23036	Collar de Necropsia
23037	Anillo de fervor espiritual
23038	Sortija de Fuerzas antinaturales
23039	El Ojo de Nerub
23040	Glifo de Desvío
23041	Emblema de destripador
23042	Reflexión de Loatheb
23043	La cara de la Muerte
23044	Presagista de la Condena
23045	Sudario de Dominio
23046	La esencia contenida de Sapphiron
23047	Ojo de los muertos
23048	Ojo derecho de Sapphiron
23049	Ojo izquierdo de Sapphiron
23050	Capa de la Necrópolis
23053	Talismán iracundo de Tempestira
23054	El frío hambriento
23055	Palabra de Fundición
23056	Martillo del Vacío Abisal
23057	Gema de Inocentes atrapados
23058	Collar de mediación de vida
23059	Anillo de Acorator
23060	Anillo segahuesos
23061	Anillo de Fe
23062	Anillo Escarchafuego
23063	Anillo Corazón de la Peste
23064	Anillo del Caminasueños
23065	Anillo del Apocalíptico
23066	Anillo de Redención
23067	Anillo del Acechacriptas
23068	Musleras de Matanza
23069	Atuendo de necrocaballero
23070	Leotardos de Polaridad
23071	Leotardos de Apocalipsis
23072	Puños del Implacable
23073	Botas de desplazamiento
23075	Acuerdo con la Muerte
23078	Guanteletes de Asesino de no-muertos
23081	Mitones de Asesino de no-muertos
23082	Manoplas de Asesino de no-muerto
23083	Llama presa
23084	Guantes de Purificación de no-muertos
23085	Toga de Purificación de no-muertos
23087	Peto de Asesino de no-muertos
23088	Coraza de Asesino de no-muertos
23089	Túnica de Asesino de no-muertos
23090	Brazales de Asesino de no-muertos
23091	Brazales de Limpieza de no-muertos
23092	Muñequeras de Asesino de no-muertos
23093	Muñequeras de Asesino de no-muertos
23122	Piedra de afilar consagrada
23123	Aceite bendito de zahorí
23124	Bastón de Balzaphon
23125	Cadenas del Exánime
23126	Pretina de Balzaphon
23127	Capa de Revanchion
23128	La garra de las Sombras
23129	Brazales de Arreglo
23132	Hoja de Lord Bosque Negro
23139	Rodela de Lord Bosque Negro
23156	Muslo de Bosque Negro
23160	Pan de la amistad
23161	Limonada fresca
23162	Una bolsa muy grande
23163	Performer's Wand
23164	Bubbly Beverage
23168	Daga focal de Desdén
23169	Gargantilla helada de Desdén
23170	La garra helada
23171	El hacha de extirpación
23172	Refreshing Red Apple
23173	Leotardos de piel de abominación
23175	Tasty Summer Treat
23176	Fizzy Energy Drink
23177	Dedo de Lady Falther'ess
23178	Manto de Lady Falther'ess
23179	Llama de Orgrimmar
23180	Llama de Cima del Trueno
23181	Llama de Entrañas
23182	Llama de Ventormenta
23183	Llama de Forjaz
23184	Llama de Darnassus
23192	Tabardo de la Cruzada Escarlata
23193	Riendas de corcel esquelético
23194	Marca del Alba inferior
23195	Marca del Alba
23196	Marca del Alba superior
23197	Ídolo de la Luna
23198	Ídolo de Brutalidad
23199	Tótem de la Tormenta
23200	Tótem de Sostenibilidad
23201	Tratado sobre Divinidad
23203	Tratado sobre Fervor
23206	Marca del Campeón
23207	Marca del Campeón
23211	Esmorc tostado
23215	Bolsa de ingredientes smorc
23219	Faja del Mentor
23220	Toga tejida con cristal
23221	Brazo de Servo mal colocado
23224	Summer Gift Package
23226	Túnica de piel de necrófago
23227	iCoke Gift Box Voucher
23237	Anillo de la Llama eterna
23238	Rodela estigia
23242	Garra de Vermis Escarcha
23243	Hombreras de placas de campeón
23244	Yelmo de placas de campeón
23246	Brebaje festivo ígneo
23247	Flores ardientes
23250	Concha prismática
23251	Yelmo de anillas de campeón
23252	Hombreras de anillas de campeón
23253	Protegecabezas de pellejo de dragón de campeón
23254	Hombreras de pellejo de dragón de campeón
23255	Capucha tejedor de tinieblas de campeón
23256	Bufas tejedor de tinieblas de campeón
23257	Yelmo de cuero de campeón
23258	Hombreras de cuero de campeón
23259	Protegecabezas de malla de campeón
23260	Espaldares de malla de campeón
23261	Caperuza de raso de campeón
23262	Manto de raso de campeón
23263	Capucha de seda de campeón
23264	Manto de seda de campeón
23272	Peto de láminas de Capitán caballero
23273	Leotardos de láminas de Capitán caballero
23274	Guanteletes de láminas de Teniente caballero
23275	Escarpes de láminas de Teniente caballero
23276	Protegecabezas de láminas de Teniente coronel
23277	Hombreras de láminas de Teniente coronel
23278	Grebas de anillas de Teniente caballero
23279	Abrazaderas de anillas de Teniente caballero
23280	Mandiletes de pellejo de dragón de Teniente caballero
23281	Botines de pellejo de dragón de Teniente caballero
23282	Mitones tejedor de tinieblas de Teniente caballero
23283	Botos tejedor de tinieblas de Teniente caballero
23284	Mandiletes de cuero de Teniente caballero
23285	Botos de cuero de Teniente caballero
23286	Guanteletes de placas de Teniente caballero
23287	Grebas de placas de Teniente caballero
23288	Mitones de raso de Teniente caballero
23289	Botos de raso de Teniente caballero
23290	Mitones de seda de Teniente caballero
23291	Botos de seda de Teniente caballero
23292	Camisote de anillas de Capitán caballero
23293	Musleras de anillas de Capitán caballero
23294	Coraza de pellejo de dragón de Capitán caballero
23295	Leotardos de pellejo de dragón de Capitán caballero
23296	Musleras tejedor de tinieblas de Capitán caballero
23297	Túnica tejedor de tinieblas de Capitán caballero
23298	Coraza de cuero de Capitán caballero
23299	Musleras de cuero de Capitán caballero
23300	Camisote de placas de Capitán caballero
23301	Leotardos de placas de Capitán caballero
23302	Musleras de raso de Capitán caballero
23303	Túnica de raso de Capitán caballero
23304	Musleras de seda de Capitán caballero
23305	Túnica de seda de Capitán caballero
23306	Yelmo de anillas de Teniente coronel
23307	Hombreras de anillas de Teniente coronel
23308	Protegecabezas de pellejo de dragón de Teniente coronel
23309	Hombreras de pellejo de dragón de Teniente coronel
23310	Capucha tejedor de tinieblas de Teniente coronel
23311	Bufas tejedor de tinieblas de Teniente coronel
23312	Yelmo de cuero de Teniente coronel
23313	Hombreras de cuero de Teniente coronel
23314	Yelmo de placas de Teniente coronel
23315	Hombreras de placas de Teniente coronel
23316	Caperuza de raso de Teniente coronel
23317	Manto de raso de Teniente coronel
23318	Capucha de seda de Teniente coronel
23319	Mando de seda de Teniente coronel
23320	Tablilla de Choque de llamas 6
23323	Corona del Festival del Fuego
23324	Manto del Festival del Fuego
23326	Salchicha de medianoche
23327	Pan tostado
23360	Cabeza de Instructor Razuvious
23379	Brazales de ceniza
23435	Tarta de bayas de saúco
23451	Hoja de mago de Gran mariscal
23452	Escrito sobre poder del Gran Mariscal
23453	Escrito sobre restauración del Gran Mariscal
23454	Martillo de guerra de Gran Mariscal
23455	Demoledor de Gran mariscal
23456	Hoja ágil de Gran Mariscal
23464	Maza de batalla de Gran Señor de la Guerra
23465	Destructor de Gran Señor de la Guerra
23466	Hoja de hechizo de Gran Señor de la Guerra
23467	Hoja rápida de Gran Señor de la Guerra
23468	Escrito sobre destrucción del Gran Señor de la Guerra
23469	Escrito sobre curación del Gran Señor de la Guerra
23545	Poder de la Plaga
23547	Recuperación de la Plaga
23548	Poderío de la Plaga
23549	Entereza de la Plaga
23557	Larva del Gran Gusano
23558	La coraza del hurgador
23570	Jom Gabbar
23577	El frío voraz
23578	Dieta McSalsasuave
23579	El clásico McSalsasuave
23663	Faja de la furia elemental
23664	Espaldar de la furia elemental
23665	Leotardos de la furia elemental
23666	Cinturón del Gran Cruzado
23667	Bufas del Gran Cruzado
23668	Leotardos del Gran Cruzado
23683	Pastilla copo de cristal para la garganta
23684	Venda de cristal imbuido
23689	Manual: venda de cristal imbuido
23690	Receta: pastilla copo de cristal para la garganta
23705	Tabardo de las llamas
23709	Tabardo de Escarcha
23710	Tabardo de cubierta #3
23712	Cachorro de tigre blanco
23713	Hipogrifillo
23714	Fuego de artificio morado perpetuo
23715	Cóctel de zumo de pulmón perpetuo
23716	Ídolo de ogro tallado
23718	Polvo de scorpok permanente
23719	Compuesto de córtex cerebral permanente
23720	Tortuga de montar
23721	Chicle permanente de mollejas
23722	IFRDHR permanente
23794	Brillo permanente de Zanza
23795	Espíritu permanente de Zanza
23796	Presteza permanente de Zanza
24071	Daga insulsa
24101	Libro de Mordisco feroz V
24102	Manual de Eviscerar IX
24222	El Apuñalador de Sombrapiés
24231	Rapé burdo
24232	Nudo gastado
24281	Hueso tallado de marfil
24282	Diario de un pícaro
24283	Un arma antigua
122270	Ficha de WoW
122284	Ficha de WoW
172070	Pack de atención al cliente
180089	Collera de panda
184937	Reubicador cronológico
184938	Reubicador cronológico sobrecargado
189419	Fire Resist Plate Gear
189420	Fire Resist Plate Gear
189421	Fire Resist Leather Gear
189426	Raid Consumables
189427	More Raid Consumables
190179	Corazón de Avelina
190180	Corazón de Isaac
190181	Corazones de amantes
190186	Figurilla de madera
190187	Pañuelo deshilachado
190232	Pañuelo deshilachado
190307	Antorcha apagada
190308	Antorcha encendida
190309	Figurilla de madera
190325	Monstruo - Íncubo Látigo Maza1H
191204	Piedra de muerte inferior
191249	Piedra de muerte superior
191267	Runa de Teletransporte: Antecámara
191268	Orbe de corrupción
191272	Vara de necromancia
191280	Cúmulo de esporas fúngicas
191288	Runa de Teletransporte: Guarida de la Vermis de Escarcha
191292	Daga ritual
191312	Filacteria de seguridad
191313	Máscara de muerte
191414	Artefacto esquelético
191458	Filacteria destrozada
191459	Runa de fortuna
191477	Amarradero esquelético
191480	Corcel esquelético
191481	Tabardo de maestría
191550	Libro de las piedras de muerte: máscara de muerte
191605	Libro de las piedras de muerte: runa de Teletransporte I
191606	Libro de las piedras de muerte: orbe de corrupción
191607	Libro de las piedras de muerte: artefacto esquelético
191608	Libro de las piedras de muerte: vara de necromancia
191609	Libro de las piedras de muerte: cúmulo de esporas fúngicas
191610	Libro de las piedras de muerte: daga ritual
191611	Libro de las piedras de muerte: filacteria de seguridad
191612	Libro de las piedras de muerte: runa de Teletransporte II
191613	Libro de las piedras de muerte: runa de fortuna
191614	Libro de las piedras de muerte: amarradero esquelético
191656	Esencia de la muerte
191660	Descargas de relámpagos de Thaddius
191661	Colmillo de araña monstruoso
191664	Libro de las piedras de muerte: descargas de relámpagos de Thaddius
191666	Libro de las piedras de muerte: colmillo de araña monstruoso
202251	Bolsa de chucherías para mascotas
202254	Brazales de redirección
202256	Pistola ornamentada de corsario
202641	Libro embarrado
203723	Nota de Cutty
203726	Runa de Cutty
203745	Notas sobre hechizos: Lanza de hielo
203746	Notas sobre hechizos: Llama viviente
203747	Notas sobre hechizos: Dedos de Escarcha
203748	Notas sobre hechizos: Consunción
203749	Notas sobre hechizos: Esclarecimiento
203750	Mapa del tesoro de Elwynn
203751	Notas sobre hechizos: NLILZA ED HEAO
203752	Notas sobre hechizos: LIAMV VLAA
203753	Notas sobre hechizos: DEAR CHDE ESCADOS
203754	Archimago Antonidas: Autobiografía completa
203755	Diario de investigación del archimago Theocritus
203756	Notas de aprendiz de Azora: página 1
203784	Parte superior derecha del mapa
203785	Parte superior izquierda del mapa
203786	Parte inferior derecha del mapa
203787	Parte inferior izquierda del mapa
203960	Notas de aprendiz de Azora: página 2
203961	Notas de aprendiz de Azora: página 3
203962	Notas de aprendiz de Azora: página 4
203990	Runa de Mutilación
203991	Runa de Desenvainado rápido
203992	Runa de Artimañas
203993	Runa de Masacre
203994	Runa de Brebaje letal
204174	Runa de Precisión
204270	Núcleo de las profundidades
204441	Runa de Frenesí sangriento
204476	Cabeza de kóbold cortada
204477	Cabeza de múrloc cortada
204478	Cabeza de gnoll cortada
204688	Fragmento de la primera runa de la cazadora de monstruos
204689	Fragmento de la segunda runa de la cazadora de monstruos
204690	Fragmento de la tercera runa de la cazadora de monstruos
204703	Runa de Devastar
204716	Runa de Asalto frenético
204795	Runa de Tenebrosa
204804	Brazales de Hydraxis
204806	Runa de Ataque de la victoria
204807	Filobraza
204809	Runa de Trueno de furia
204864	Notas de aprendiz de Azora
204905	Tomo agorero
204906	Sangre de gnoll
204907	Mandíbula de lobo
204912	Runa de gracia
205019	Fragmento de alma contaminado
205020	Fragmento de alma puro
205022	Runa de Succión de alma
205181	Artefacto sin identificar
205182	Artefacto sin poder
205183	Artefacto de poder vil
205184	Nota del acólito
205215	Runa de tácticas
205218	Tratado de descubrimiento
205228	Runa de Descarga de caos
205230	Runa de Tormento
205364	Morral del acólito
205420	Tratado de sentencia
205683	Runa de Reprimenda
205685	Runa de Égida
205863	Tratado corrupto
205864	Nota chamuscada
205897	Runa de Luz divina
205905	Recuerdo de un campeón devoto
205932	Profecía sobre la muerte de un rey
205940	Recuerdo de un oscuro propósito
205942	Epifanía quimérica
205943	Profecía sobre una ciudadela profanada
205944	Epifanía recíproca
205945	Recuerdo de un salvador encarcelado
205946	Recuerdo de la traición de un líder
205947	Profecía sobre una ciudadela profanada
205948	Epifanía anodina
205949	Epifanía múltiple
205950	Epifanía tenebrosa
205951	Recuerdo de un acólito preocupado
205952	Recuerdo de un mundo destrozado
205953	Profecía sobre un juramento roto
205961	Carne de ave de Mulgore
205979	Runa de flanco
205995	Almizcle de perro de la pradera
206032	Runa de Trinchar
206155	Runa de Puntería
206157	Carga de seforio de minería
206159	Disfraz de Ventura y Cía.
206168	Runa de la quimera
206169	Runa de Disparo explosivo
206170	Bellota Viento Furioso
206175	Ungüento de pino
206176	Mortero y majadero
206177	Mantequilla de piñones
206264	Runa de Inspiración
206344	Juego de cuchillos
206345	Trozos de pescado
206376	Icono de baluarte
206381	Icono diádico
206382	Icono de tempestad
206383	Icono lítico
206384	Icono astral
206385	Icono clástico
206386	Icono galvánico
206387	Icono kajárico
206388	Icono sulfuroso
206389	Icono de azufre
206390	Icono de ichtys
206391	Icono de sizigia
206466	Corona de la pradera
206469	Flor de la pradera
206954	Ídolo de ira osuna
206963	Runa de Potencial natural
206966	Bulbo de hierba de sátiro
206970	Runa de vida
206975	Llave del depósito del artefacto
206985	Eco del alfa
206989	Runa del Sol
206992	Runa de Testarazo
206994	Cabeza de jabaespín cortada
206995	Cabeza de arpía cortada
207062	Cabeza de centauro cortada
207098	Nota de Ba'so
207106	Parte inferior izquierda del mapa
207107	Parte inferior derecha del mapa
207108	Parte superior izquierda del mapa
207109	Parte superior derecha del mapa
207110	Mapa del tesoro de Durotar
207590	Carne de cerdo de Durotar
207631	Feromonas de víboris
207731	Tomo agorero
207732	Pata de makrura
207733	Calavera de humano de Kul Tiras
207972	Lecciones de Ta'zo
207973	Mandíbula de sabueso
207974	Tomo agorero
207975	Cabeza de murciélago cortada
208005	Llave del arca de reliquias de Agamand
208007	Llave del alijo de restos de naufragio
208034	Mapa del tesoro de Tirisfal
208035	Parte superior derecha del mapa
208036	Parte superior izquierda del mapa
208037	Parte inferior derecha del mapa
208038	Parte inferior izquierda del mapa
208085	Sello de teniente Escarlata
208086	Memorándum Escarlata forjado
208139	Tomo agorero
208140	Sangre de wendigo
208158	Corazón de trogg prístino
208159	Cabeza de trol cortada
208160	Zarpa cortada de wendigo
208180	Almizcle de conejo
208183	Notas del boticario
208185	Manual de metafísica del boticario
208192	Carne de cerdo de Dun Morogh
208196	Sortija de Moa'ki
208205	Nota de Ratanegra
208213	Parte superior derecha del mapa
208215	Parte superior izquierda del mapa
208218	Parte inferior derecha del mapa
208219	Parte inferior izquierda del mapa
208220	Mapa del tesoro de Dun Morogh
208222	Vengadora de la guardia antigua
208223	Morral del acólito
208224	Nota del acólito
208414	Ídolo lunar
208425	Vestigio arcaico brillante
208484	Luz solar
208601	Parte superior derecha del mapa
208602	Parte superior izquierda del mapa
208603	Parte inferior derecha del mapa
208604	Parte inferior izquierda del mapa
208605	Mapa del tesoro de Teldrassil
208607	Almizcle de ciervo
208608	Carne de ave de Teldrassil
208609	Flor del claro
208610	Cabeza de búho cortada
208611	Cabeza de tigre cortada
208612	Cabeza de araña cortada
208682	Huevo de quijaforte abandonado
208687	Runa de Lacerar
208689	Ídolo de ferocidad
208701	Runa de Maestría en bestias
208739	Estandarte de guerra de la Horda
208741	Runa de Ira interminable
208743	Alma de codicia
208744	Runa de descargas de las Sombras
208749	Llave del alijo Tuercepinos
208750	Runa de canalización
208753	Notas sobre hechizos: Regeneración
208754	Notas sobre hechizos: RAGENÓNERICE
208758	Runa terránea
208760	Corona del claro
208764	Runa de la mente
208765	Mano amiga
208766	Mano amiga
208767	Runa de Aliviar
208768	Caja de cerillas de bucanero
208771	Runa de Danza de hojas
208772	Runa de Tajo de sable
208773	Arpón de pesca
208777	Runa del francotirador
208778	Runa de Golpe rápido
208799	Notas sobre hechizos: Bomba viva
208800	Baxtan: Sobre la magia destructiva
208823	Moneda de ofrenda
208828	Recuerdo de un juramento roto
208833	Pastel malévolo
208838	Arcón Hierro Negro
208843	Tótem de batalla
208847	Geoda con forma de cráneo
208848	Geoda con forma de cráneo rajada
208849	Tratado de bendiciones
208851	Tratado de justicia
208853	Notas sobre hechizos: Congelación cerebral
208854	Notas sobre hechizos masticadas
208855	Carnada de atún blanco arco iris
208860	Rumi de Gnomeregan: Obras completas
209027	Bocaditos de cangrejo
209028	Notas sobre hechizos: BAVOB MIVA
209029	Mensaje de Emily
209030	Llave del alijo de equipo
209031	Sobre discreto
209041	Semillas de calabaza mágicas
209042	Harina de hueso sospechosa
209043	Muestra de tierra fértil
209045	Alma del mar
209047	Arpón nudoso
209056	Piezas de repuesto de segador
209057	Prototipo de motor
209058	Núcleo elemental
209059	Anca de dentosangre
209418	Armadura tortuga de adamantita
209420	Branquiflagelo
209421	Cordón de Aquanis
209422	Gargantilla de marea alta
209423	Pañuelo liviano
209424	Barrera de placas de caparazón
209432	Cincho de Ghamoo-Ra
209436	Mordisco de Serra'kis astillada
209523	Manteo de trillador brillante
209524	Ataduras de Serra'kis
209525	Talwar Aguaoscura punzante
209526	PRUEBA Talwar Aguaoscura
209527	Guanteletes de batalla naga
209534	Arbalesta azsh'ari
209559	Cachava del sabio crepuscular
209560	Martillo de juicio recto
209561	Vara del insomne anciano
209562	Golpe Mortal de la Hidra
209563	Desgarracorazones naga
209564	Tridente de guardián
209565	Anillo de las profundidades
209566	Leotardos del fiel
209567	Hacha de coral
209568	Guanteletes de algas
209569	Botas altas de pellejo de múrloc
209570	Tomo de conocimientos de las cavernas
209571	Mortaluz
209572	Pieles negras hervidas
209573	Aguja colérica
209574	Principios desechados de la Mano de Plata
209575	Icono de madera a la deriva tallado
209576	Champiñón expandementes
209577	Puño de lo Salvaje
209578	Braciles de cuero resplandecientes
209579	Trueno Aplastante
209580	Racha de Viento
209581	Escarpes de la Mano de Plata
209590	Globo de agua agrietado
209608	Llave maestra del capitán
209611	Insignia de la Alianza
209612	Insignia de la Alianza
209613	Insignia de la Alianza
209614	Insignia de la Alianza
209615	Insignia de la Alianza
209616	Insignia de la Alianza
209617	Insignia de la Alianza
209618	Insignia de la Alianza
209619	Insignia de la Horda
209620	Insignia de la Horda
209621	Insignia de la Horda
209622	Insignia de la Horda
209623	Insignia de la Horda
209624	Insignia de la Horda
209625	Insignia de la Horda
209626	Insignia de la Horda
209667	Leotardos de soñador de mirada
209668	Sello del Señor Crepuscular
209669	Zapatos de convocador Crepuscular
209670	Pisapieles
209671	Túnica de convocador Crepuscular
209672	Mitones negros
209673	Amuleto de fetiche resplandeciente
209674	Ignición de fénix
209675	Túnica de tejido de almeja
209676	Guardahombros de profundidades aplastantes
209677	Aro de corrientes rápidas
209678	Manto del cazador de trilladores
209679	Hombreras de novicio azsh'ari
209680	Pañuelo impermeable
209681	Huevo múrloc negro
209682	Caperuza resistente
209683	Chal de convocador Crepuscular
209684	Pantalones de parásito de almas
209685	Cincho musgoso antiguo
209686	Collar de huesos dentados
209687	Loriga de piel de hidra
209688	Trabuco de Bael Modan
209689	Vadeadores de caparazón de cangrejo
209690	Almófar escamasombra
209691	Cuchillo de bota vampírico
209692	Espaldares de centinela
209693	Perla Brazanegra perfecta
209694	Daga ritual Brazanegra
209748	Orbe de Althalaxx
209778	Sal de invocador
209779	Mota de Mannoroth
209800	Fragmentos de orbe
209816	Fetiche de travesuras
209817	Broche de abisario
209818	Daga curva solar
209819	Varita de doma de dracoleones
209820	Gargantilla de mortaja negra
209821	Anillo de Vista de las Sombras
209822	Fuerza del Propósito
209823	Sello de bestias
209824	Hombreras resplandecientes
209825	Gargantilla con gotita
209828	Espaldares congelados
209830	Arbalesta de pielférrea
209836	Orbe de Althalaxx
209838	Cristal hipnótico
209840	Varita nudosa de magia salvaje
209841	Esencia de magia salvaje
209843	Almanaque de Nar'thalas, vol. 74
209844	Compendio de Dalaran, vol. 23
209845	Encantamientos y embelesamientos
209846	Secretos de los soñadores
209847	Manual de sistemas arcánicos
209848	Pergaminos de Goaz
209849	Crímenes contra la anatomía
209850	Runas de los reyes hechiceros
209851	La furia de la tierra
209852	Runa de Matar
209872	Yelmo de matadragones
209873	Escudo de matadragones
209874	Lanza de matadragones
210015	Runa de Arremetida enfurecida
210026	Símbolo del tercer búho
210043	Símbolo del segundo búho
210044	Símbolo del primer búho
210045	Sombrahoja
210053	Garra de lobo temible
210055	Huesos humanos de Trabalomas
210056	Tintura del despertar de la muerte
210080	Ofrenda vudú
210137	Runa de Crecimiento salvaje
210138	Ordenanza de los Hierro Negro
210146	Turbocargador de trituradora
210147	Unidad de autorreciclaje de la trituradora
210177	Ataeric: sobre curiosidades Arcanas
210178	Esquema: unidad de autorreciclaje de la trituradora
210179	Notas sobre hechizos: ILMEGAI SARRBES
210183	Cuerno de Xelthos
210186	Carga de irrupción
210187	Pedido de Ventura y Cía.
210188	Pedido triturado
210195	Ídolo desequilibrado
210209	Llave gemela
210210	Certificado de fundador de Industrias de Defensa Grizzwerks
210212	Media llave del hermano
210213	Media llave de la hermana
210229	Runa de Mutilación
210250	Anillo de oro grabado
210251	Anillo de plata grabado
210252	Runa de Puyazos
210253	Tótem de podredumbre
210322	Runa de Veneno
210323	Combinación de caja fuerte
210329	Mapa del tesoro de Trabalomas
210330	Consejo útil
210410	Cebo de sacudidor de agua dulce
210499	Hongociénaga
210500	Runa de las estrellas
210534	Ídolo de las fieras
210568	Filacteria decrépita
210569	Runa de Flagelación
210573	Runa de Ira acuciante
210589	Eco de los ancestros
210596	Runa de Golpes de cobra
210653	Runa de Daga de guardamano
210654	Notas sobre hechizos: Retroceder en el tiempo
210655	Notas sobre hechizos: DEROCE POTER NELETRIEM
210665	Mota de ira torrencial
210667	Mota de ira infernal
210668	Mota de ira sísmica
210696	Terror putrefacto
210708	Elixir de arrepentimiento fusionado
210709	Receta: elixir de arrepentimiento fusionado
210712	Elixir de perspicacia
210713	Alma torturada
210724	Bastón de Hirzek
210741	Moledora automática de muchedumbres
210746	Runa de Escudo de tierra
210763	Rama de Altek
210765	Orbe de Des
210771	Suministros saqueados: lingotes de cobre
210772	Envío de suministros: lingotes de cobre
210773	Manto de la Segunda Guerra
210779	Diseño: manto de la Segunda Guerra
210781	Ataduras de Fénix
210794	Coraza de plata cambiante
210795	Botas de seda de araña extrabidimensional
210811	Runa de furia primigenia
210817	Runa de supervivencia
210818	Runa de lobo solitario
210820	Runa de sacrificio
210822	Epifanía armoniosa
210823	Runa de especialización en doble empuñadura
210824	Runa del pacto
210825	Runa del belisario
210953	Ojo de Bhossca
210955	Uniforme de iniciado Escarlata
210963	Llave del arúspice
210966	Sangre de la Legión
210967	Mensaje confidencial
210968	Llave del relicario
210979	Runa de Paso de las Sombras
210980	Runa de Metamorfosis
211205	Runa de Destripacobras
211247	Patrón: ataduras de Fénix
211263	Coselete de sentencia
211269	Dibujo primitivo
211301	Runa de Exponer debilidad
211315	Suministros saqueados: cuero ligero
211316	Suministros saqueados: flor de paz
211317	Suministros saqueados: hojaplata
211318	Suministros saqueados: pociones de curación menor
211319	Suministros saqueados: espadas cortas de cobre
211320	Suministros saqueados: pantalones de cobre con runas
211321	Suministros saqueados: varitas mágicas inferiores
211322	Suministros saqueados: aceite de zahorí menor
211323	Suministros saqueados: bombas de cobre férreo
211324	Suministros saqueados: trabucos bastos
211325	Suministros saqueados: cinturones de cuero cosidos a mano
211326	Suministros saqueados: jubones de cuero en relieve
211327	Suministros saqueados: pantalones de lino marrones
211328	Suministros saqueados: togas de lino marrón
211329	Suministros saqueados: huevos cocidos con hierbas
211330	Suministros saqueados: carne de lobo especiada
211331	Suministros saqueados: pececito luminoso
211332	Suministros saqueados: vendas de lino gruesas
211365	Envío de suministros
211367	Envío de suministros
211368	Envío de suministros
211382	Cartera de mensajero pequeña
211384	Bolsa de mensajero resistente
211385	Runa de Propagar serpientes
211386	Notas sobre hechizos: Oleada Arcana
211387	Runa de Luz atrayente
211390	Runa de Provocar
211391	Runa de Lluvia de sanación
211392	Runa de Aflicción eterna
211393	Runa de Furia enfocada
211419	Puñado de escamas cambiantes
211420	Dije de escamas cambiante
211421	La caja
211422	Fragmento del Vacío
211423	Guantes de cuero tocados por el Vacío
211427	Receptáculo de almas
211443	Hoja de ira
211444	Capa de invocador
211445	Arco corvo barbárico
211447	Envío de armas
211448	Contrato de adquisición firmado
211449	Perla del Vacío de vengador
211450	Perla del Vacío de invocador
211451	Perla del Vacío de acólito
211452	Perla Brazanegra perfecta
211454	Globo de agua extraño
211455	Guantes sin dedos escurridizos
211456	Daga de sacrificio voluntario
211457	Faja de defensor crepuscular
211458	Escrito sobre Resguardo contra las Sombras
211460	Rodela ártica antigua
211461	Cetro de lápida inscrito
211462	Anillo de sustención eterna
211463	Broches de escarabajos chasqueadores
211464	Manteo de prelación gastado
211465	Botas Nimbus de perspicacia
211466	Faja de duramen de cuidador
211467	Sortija del puño de hierro
211468	Manto de castaño deshilachado
211471	Llave de Fonroca
211472	Tratado de Destierro
211476	Runa de despertar de incendio
211477	Runa de Incinerar
211482	Ofrenda Rompelanzas
211487	Explosivos de demolición
211488	Runa del vengador
211490	Profecía de las Mil Luces
211491	Bolsa de piel de múrloc sin fondo
211492	Bolsa de Kelris
211498	Sable de la noche de centinela de aprendiz
211499	Lobo escolta de aprendiz
211500	Cinta de tela resistente
211501	Coselete de poderío
211502	Guanteletes de cuero tocados por el Vacío
211504	Cota de malla de vengador Crepuscular
211505	Yelmo de vengador Crepuscular
211506	Botas de vengador Crepuscular
211507	Capucha de elementalista Crepuscular
211508	Escarpines de elementalista Crepuscular
211509	Túnica de elementalista Crepuscular
211510	Capucha de destripador Crepuscular
211511	Escarpines de destripador Crepuscular
211512	Guerrera de destripador Crepuscular
211514	Notas sobre hechizos: Regeneración en masa
211527	Saco de dormir acogedor
211528	Perspicacia oscura
211530	Profecía sobre una ciudad sometida
211531	Profecía de los Siete Visitantes
211534	Perspicacia primigenia
211691	Notas sobre hechizos: Explosión Arcana
211777	Manuscrito naga
211779	Amuleto de comprensión
211780	Pergamino: KWYJIBO
211784	Pergamino: WUBBA WUBBA
211785	Pergamino: CWAL
211786	Pergamino: CHAP BALK WELLES
211787	Pergamino: LOWER PING WHOMEVER
211789	Capucha de Artemis
211799	Saco de objetos robados
211800	Pergamino de reintegración
211809	Manual de comprensión
211813	Amuleto de centinela Ala de Plata
211814	Marca de escolta Grito de Guerra
211815	Himno de batalla Ala de Plata
211816	Tambor de batalla Grito de Guerra
211818	Globo de agua extraño
211819	Suministros saqueados: lingotes de bronce
211820	Suministros saqueados: lingotes de plata
211821	Suministros saqueados: cuero medio
211822	Suministros saqueados: hierba cardenal
211823	Suministros saqueados: cardopresto
211824	Suministros saqueados: pociones de maná inferiores
211825	Suministros saqueados: botas de bronce férreas
211826	Suministros saqueados: llaves esqueleto de plata
211827	Suministros saqueados: varas rúnicas de plata
211828	Suministros saqueados: aceite de maná menor
211829	Suministros saqueados: bombas de bronce pequeñas
211830	Suministros saqueados: catalejos ornamentados
211831	Suministros saqueados: capas de cuero oscuro
211832	Suministros saqueados: sobrehombros de montañero
211833	Suministros saqueados: camisas de lana gris
211834	Suministros saqueados: capas con broche de perlas
211835	Suministros saqueados: sabiola ahumada
211836	Suministros saqueados: carne de oso ahumada
211837	Suministros saqueados: almejas picantes a la goblin
211838	Suministros saqueados: vendas de lana gruesa
211839	Envío de suministros
211840	Envío de suministros
211841	Envío de suministros
211842	Almete de meditación destrozado de Rakkamar
211843	Máscara de Desdén
211845	Piedra de afilar Brazanegra
211846	Diseño: piedra de afilar Brazanegra
211848	Aceite de maná Brazanegra
211849	Fórmula: aceite de maná Brazanegra
211852	Manijas de agua contaminada
211853	Pergamino: VOCE WELL
211854	Pergamino: OMIT KESA
211855	Pergamino: STHENIC LUNATE
211856	Almófar de cuero resistente
211857	Máscara de cuero resistente
211933	Suministros saqueados: piedra férrea
211934	Suministros saqueados: pociones de sanación
211935	Suministros saqueados: elixir de poder de Fuego
211940	Guardián tribal de Ecks'av
211941	Yari de caminante de viento
211944	Karma de Tojara
211953	Pergamino de recuperación Arcana I
211954	Pergamino de precisión Arcana I
211955	Pergamino de protección contra lo Arcano - Fuego I
211956	Pergamino de protección contra lo Arcano - Escarcha I
211957	Pergamino de poder Arcano I
212160	Reubicador cronológico
212225	Receptáculo de almas inagotable
212230	Esquema: receptáculo de almas
212548	Runa de Eclipse
212549	Runa del trampero
212551	Runa de Belicismo
212552	Epifanía psicosófica
212559	Runa de la hoja envenenada
212560	Runa de Despertar ancestral
212561	Runa de Oscuridad ardiente
212562	Runa de Frenesí sanador
212568	Trofeo de cabeza de lobo
212580	Bastón del Tradicionalista
212581	Arco de avanzado
212582	Espada de protector
212583	Hoja de centinela
212584	Bastón nudoso de consejero
212585	Arco de escolta
212586	Espada de Legionario
212587	Hoja de Explorador
212588	Guantes de proveedor
212589	Botines de mensajero
212590	Cinta de elevación
212748	Nota ajada
212994	Ataduras de cazatormentas
212996	Ataduras de clamarelámpagos
212997	Ataduras de clamamareas
213074	Runa de nutrición
213086	Runa de la tormenta
213087	Capa de Sargento
213088	Capa de Sargento
213090	Runa de Sinergia
213093	Runa de poder
213094	Runa de Nova de Fuego
213096	Runa de señuelos
213098	Runa de Invocación
213100	Runa de Conocimiento prohibido
213101	Runa de Pirosombra
213102	Runa de Perversión
213103	Runa de Oleada sangrienta
213104	Runa de precisión implacable
213105	Shawarmagedón
213109	Runa de Ira enfocada
213110	Runa del comandante
213111	Runa de intervención
213112	Notas sobre hechizos: Tromba de misiles
213117	Runa de Rabia
213118	Runa del rey de la selva
213119	Runa de instinto
213120	Runa del soñador
213121	Acebo en conserva
213122	Runa de Disparo firme
213123	Runa de exposición
213124	Runa de combate cuerpo a cuerpo
213125	Runa de Vigorización
213126	Runa del peleador
213127	Notas sobre hechizos: DARCAGENO ED FRÍCAROSA
213128	Runa de Piedad
213129	Runa de Abrazo de la Luz
213130	Runa de infusiones
213131	Runa de escudos sacros
213132	Runa del guardián
213136	Runa de Sutileza
213137	Runa del agresor
213138	Runa del zarpasur
213139	Runa del asesino
213140	Profecía de la senda acelerada
213141	Runa de Esperanza
213142	Profecía de malicia encarcelada
213143	Epifanía apócrifa
213144	Epifanía luminosa
213165	Basiliscos: ¿hay que temer la petrificación?
213168	Moneda de sangre de cobre
213169	Moneda de sangre de plata
213170	Moneda de sangre de oro
213278	Manoplas del maestro de las tortas
213279	Capacete reflectante
213280	Miravisor de tirador
213281	Reactivador de hiperflujo electromagnético
213282	Engranaje de innovación hipercargado
213283	Engranaje de conflagración hipercargado
213284	Engranaje de devastación hipercargado
213285	Ataduras manchadas de aceite de Lev
213286	Aguja del Electrocutor
213287	Tuerca hexagonal del Electrocutor
213288	Guanteletes guarros Grubbis
213289	Hidrovara
213290	Vadeadores ácidos
213291	Desfacedor tóxico II
213292	Gigacortadora Gizmotrón
213293	Superpistola de alta tecnología MK VII
213294	Escarpes Cueva Honda
213295	Vibrohoja ultrasónica
213296	Loncheacabezas supercargada
213297	Martillorráfaga oscilador
213298	Mono de mecánico
213299	Pantalones de vertido de petróleo
213300	Guantes de as de combate
213301	Manto sintético
213302	Manto del negociador astuto
213303	Bufas pararrayos
213304	Espaldares matatroggs
213305	Hombreras de placas de aleación mecanizadas
213306	Cubierta de inventiva
213307	Mantón de desmontaje
213308	Prototipo de capa paracaídas
213309	Capa de invención
213310	Camisa brillante hiperconductora
213311	Toga hiperconductora
213312	Mandil aislante
213313	Coselete aislante
213314	Cota de malla electromántica
213315	Camisa de malla electromántica
213316	Coraza de R.I.E.S.G.O.
213317	Estabilizadores de puntería experimentales
213318	Brazales ornamentados de hierro negro
213319	Guantes de maquinista
213320	Dedos de Precisión arcana
213321	Cinturón de brebaje volátil
213322	Pretina de trapicheos
213323	Cordón del interior de la tierra
213324	Ceñidor electromagnético
213325	Faja de visión oscura
213326	Faja de reclamo
213327	Cinturón del trogg rabioso
213328	Bombachos hiperconductores
213329	Falda hiperconductora
213330	Quijotes de R.I.E.S.G.O.
213331	Leotardos aislantes
213332	Musleras aislantes
213333	Calzas electrománticas
213334	Gambesón electromántico
213335	Botas de R.I.E.S.G.O.
213336	Botos hiperconductores
213337	Sandalias hiperconductoras
213338	Botas de toma de tierra electrománticas
213339	Escarpes de toma de tierra electrománticos
213340	Botas de operador de gnomobot
213341	Botas de trabajo aislantes
213342	Galochas aislantes
213343	Distintivo de justicia
213344	Torque de oficial de paz de Gnomeregan
213345	Colgante de pistón
213346	Colgante de vuelta a casa
213347	Cámara de combustión miniaturizada
213348	Experimento giromático 420b
213349	Frasco de pastillas de gniodina
213350	Núcleo endurecido de Wirdal
213351	Escudo pavés irradiado
213352	Gracia del reparador de engranajes
213353	Bastón desfibrilador
213354	Bastón del genio maligno
213355	Aguijón de Falco
213356	Lanzador personalizado de Termochufe
213369	Cuero de tenue resplandor
213370	Restos de cuero irradiado
213371	Caja de solución de gniodina contaminada
213372	Gniodina aislante
213373	Chatarra reflectante
213376	Placas de veraplata de fondo bajo
213378	Microfilamento inestable
213379	Filamento Arcano hiperconductor
213381	Montón de engranajes manchados
213383	Engranajes de veraplata pulidos
213390	Bastión de veraplata giratorio
213407	Hierba gatera
213408	Microajustador giromático
213409	Arcanotriturador de Mekkatorque
213410	Espada cachivache brillante
213411	Encendedor inextinguible de Izzleflick
213412	Escudo de seguridad dieléctrico
213413	Hombreras generosamente acolchadas
213414	Fajín de ensalmarrobots
213415	Cubremuñecas de manitas
213416	Cuchilla de cohete de Termochufe
213417	Almófar de filamentos de veraplata
213418	Anillas de veraplata soldadas
213419	Manual de reparaciones 9-60
213421	Nota chamuscada
213426	Pararrayos de ogro
213427	Chatarra con mugre incrustada
213442	Zarpa de maestropiñón
213443	Obsequio que hace tic-tac
213452	Runa sagrada durmiente
213513	Tratado de Liberación
213526	Anca híbrida
213527	Mezcla de especias de contrabandista
213528	Cerveza suave
213529	Veneno viscoso
213542	El Necro-Gnomicon
213543	Pergamino: COLEGA
213544	Pergamino: OFELTA DE IKOZAS
213545	Pergamino: NIMIPU SETOFELO
213546	Pergamino: SHOOBEEDOOP
213547	Pergamino: QÉU PESADA
213548	Pergamino de Pasaje liminal
213549	Pergamino de Pesca Arcana
213550	Pergamino de Polimorfia: melón extraño
213551	Pergamino de Desplazamiento controlado
213552	Lágrima de Theradras
213553	Lágrima de Theradras
213554	Vial de aguas cristalinas
213558	Ungüento elemental
213559	Palanca de cambios para mecazancudo
213560	Silenciador para mecazancudo
213563	Guía de campo
213564	Pergamino de Evocación menor
213565	Kit de iniciación a la entomología
213583	Talla de azufre
213594	Ídolo del molesto
213599	Visión inquietante
213632	Notas sobre hechizos parciales
213633	Notas sobre hechizos parciales
213634	Notas sobre hechizos parciales
213641	Cajón de chatarra de Gnomeregan
213701	Pluma de arpía resistente
213709	Colmillo de serpiente nubosa
213735	Procesador G-7 N.Ú.C.L.E.O. prístino
213736	Procesador G-7 N.Ú.C.L.E.O. corroído
213737	Ofrenda al espíritu de viento
214435	Llave de jaula de puma
215111	Monóculo de filamento Arcano gneurovinculado
215114	Almófar de escamas hiperconductoras brillante
215115	Cinturón dorado hiperconductor
215129	Fórmula: encantar arma: desmantelar
215138	Fórmula: encantar pechera: Retribucionismo
215141	Sigilo encantado: Innovación
215149	Patrón: monóculo de filamento Arcano gneurovinculado
215152	Patrón: capucha gneurovinculada brillante
215153	Esquema: bastión de veraplata giratorio
215155	Diseño: casco antiinterferencias templado
215156	Esquema: cinturón dorado hiperconductor
215162	Poción de rejuvenecimiento ligeramente irradiada
215163	Receta: poción de rejuvenecimiento ligeramente irradiada
215166	Capucha gneurovinculada brillante
215257	Pergamino de Comprensión
215365	Manto de invocador
215366	Cordón de invocador
215367	Patrón: cuero de tenue resplandor
215368	Patrón: filamento Arcano hiperconductor
215369	Patrón: cordón de invocador
215370	Patrón: manto de invocador
215371	Talismán de Jani
215373	Martillo de entrenamiento de la Mano de Plata
215374	Espada ancestral
215375	Bastón de táctico
215376	Maza de cruzado
215377	Toga irradiada
215378	Botas irradiadas
215379	Calzas irradiadas
215380	Cinturón de entrenamiento servoasistido
215381	Caperuza de canalizador gneuroconductora
215382	Caperuza de escamas resistente a la radiación
215383	Diseño: jaula cerebral de veraplata reflectante
215384	Diseño: placas de veraplata de fondo bajo
215385	Suministros saqueados: lingotes de oro
215386	Suministros saqueados: lingotes de mitril
215387	Suministros saqueados: pellejos pesados
215388	Suministros saqueados: cuero grueso
215389	Suministros saqueados: plantas de pálida
215390	Suministros saqueados: mostachos de Khadgar
215391	Suministros saqueados: plantas de Invernalia
215392	Suministros saqueados: lotos cárdenos
215393	Suministros saqueados: pociones de sanación superiores
215394	Suministros saqueados: pociones de escudo de piedra inferiores
215395	Suministros saqueados: elixires de agilidad
215396	Suministros saqueados: elixires de defensa superiores
215397	Suministros saqueados: hachas de hierro macizo
215398	Suministros saqueados: brazales de hierro verdes
215399	Suministros saqueados: guanteletes de mitril pesados
215400	Suministros saqueados: piedras de pulir sólidas
215401	Suministros saqueados: juegos de segador de la cosecha compactos
215402	Suministros saqueados: bombas de hierro grandes
215403	Suministros saqueados: miras mortales
215404	Suministros saqueados: trabucos de mitril
215405	Suministros saqueados: botas cohete gnómicas
215406	Suministros saqueados: morteros goblin
215407	Suministros saqueados: sobrehombros barbáricos
215408	Suministros saqueados: guantes de guardián
215409	Suministros saqueados: brazales de caparazón de tortuga
215410	Suministros saqueados: cinturones oscurecidos
215411	Suministros saqueados: capas de cuero de Escarcha
215412	Suministros saqueados: guantes sombradermos
215413	Suministros saqueados: camisas blancas formales
215414	Suministros saqueados: bombachos de seda carmesíes
215415	Suministros saqueados: camisas de seda morada viva
215416	Suministros saqueados: máscaras de bandido blancas
215417	Suministros saqueados: sopa de tortuga reconfortante
215418	Suministros saqueados: salchichas de araña
215419	Suministros saqueados: vendas de seda gruesas
215420	Suministros saqueados: bacalao piedrescama
215421	Suministros saqueados: aceite de Fuego
215422	Patrón: almófar de escamas hiperconductoras brillante
215423	Patrón: caperuza de canalizador gneuroconductora
215424	Patrón: caperuza de escamas resistente a la radiación
215425	Eco del pantano
215426	Eco del cementerio
215427	Eco de Arathi
215428	Eco de Theramore
215429	Esquema: engranajes de veraplata pulidos
215430	Restos radiactivos de Gnomeregan
215431	Esquema: bomba de radiación de alto rendimiento
215432	Esquema: bomba de radiación para tontos
215433	Receta: gniodina aislante
215434	SIN USO
215435	Tratado sobre la oración
215436	Tótem de llama vigorizante
215437	Transfiguratroggs 3000
215441	Martillo roto
215443	Fragmento de orbe destrozado
215444	Monstruo - Maza - Tuberías rotas
215449	Encogemundos
215450	Proyecto de tabardo (Aidan)
215456	Mensaje chamuscado
215458	Mensaje adjunto
215459	Mensaje adjunto
215460	Mensaje adjunto
215461	Pollo de combate domesticado
215468	Órdenes del Gran Cruzado
215683	Geomancia: la dura realidad
215815	Magias defensivas para novatos
215816	Una red de mentiras: desmontando mitos y leyendas
215817	Los demonios y tú
215820	Momias: guía para una no-muerte desagradable
215822	¡RwlRwlRwlRwl!
215824	Guía del ludita para cuidar de tu mascota demoníaca
216484	Botas de batalla electroforjadas
216485	Coraza electroforjada
216486	Quijotes electroforjados
216490	Ídolo de la cólera
216491	Envío de madera de Tuercespina
216492	Silbato del raptor de sangre jaspeado
216494	Distorsionador de mundos extravagante de Aragriar
216495	Triturador sanguino
216496	Rompecráneos sanguino
216497	Exanguinadora
216498	Grimorio sanguino encantado
216499	Triturador cortezasanguina
216500	Dije de la arboleda vinculasangre
216501	Barrera de tormenta de sangre
216502	Tótem de guerra de tormenta de sangre
216503	Joya de tormenta de sangre
216504	Sable luz de sangre eclipsado
216505	Radiancia del cruzado luz de sangre
216506	Filo del vengador luz de sangre
216507	Sello sangriento umbrío
216508	Sortija de espiral infernal
216509	Esencia de pacto infernal
216510	Anillo de sangre resonante
216511	Sello de sangre de brasas
216512	Aro de venas congeladas
216513	Dije de sangre de tigre
216514	Carcaj sanguino
216515	Faltriquera para munición sanguina
216516	Arco azotasangre
216517	Santuario sanguino
216518	Sello de curia sangrienta
216519	Sortija de las sombras sanguina
216520	Filo de la cosecha sangrienta
216521	Golpeadores sanguinos prestos
216522	Estilete salpicado de sangre
216523	Llave de jaula oxidada
216570	Riendas del dientes de sable dorado
216606	Runa de Maestría con arma a dos manos
216607	Ofrenda de luz de sangre
216608	Reflectores de rayos radiantes
216610	Órdenes del Gran Cruzado
216615	Baliza de tormenta de sangre ancestral
216616	Llave de la jaula del complejo
216617	Uniforme de luchador Kurzen
216618	Recompensa de la capitana Aransas
216619	Picoteo de estudiante
216620	Capa putresangre
216621	Mantón empapado de sangre
216622	Capa coagulada
216623	Manteo de hemostasia
216633	Tornapunta de veraplata hidráulica
216634	Mecha de cartuchos GG12-082
216635	Núcleo del Vacío descargado
216636	Núcleo del Vacío cargado
216637	Un montón de piezas diversas
216645	Mota de oscuridad
216646	Cajón misterioso de Ziri
216661	Anillo sucio
216662	Anillo de oro luminoso
216673	Anillo de oro luminoso de Talvash
216674	Anillo de oro luminoso de Nogg
216675	Togas civinad prístinas
216676	Peto de corredor ágil
216678	Leotardos triples reforzados
216679	Herramienta para desmontar de Shoni
216680	Mitones llamativos
216698	Braquiales de pellejo de dragón de alférez
216699	Guardabrazos de anillas de alférez
216700	Braquiales de cuero de alférez
216701	Guardamuñecas de placas de alférez
216702	Puños de seda de alférez
216703	Guardamuñecas de malla de gran capataz
216704	Guardabrazos de pellejo de dragón de gran capataz
216705	Brazales de placas de gran capataz
216706	Guardabrazos de cuero de gran capataz
216707	Puños de seda de gran capataz
216738	Manual de Redirigir
216740	Tomo de Intelecto ampliado
216744	Pergamino de Entereza aumentada
216745	Pergamino de Maligno de las Sombras
216746	Vademécum de Grito de orden
216747	Grimorio de Cosecha de almas
216748	Grimorio de Portal de invocación
216764	Panfleto de El corazón de lo salvaje
216767	Panfleto de Revivir
216769	Revelación de Proyección totémica
216770	Tratado de Aspecto de la víbora
216771	Panfleto de Restauración mejorada
216879	Pergamino trol misterioso
216880	Pergamino trol descifrado
216884	Hoja sedienta de sangre
216914	Mención honorífica deslustrada
216918	Botas corazón vil
216919	Fajín corazón vil
216920	Ataduras corazón vil
216921	Mandiletes corazón vil
216922	Corona corazón vil
216923	Leotardos corazón vil
216924	Abrazo corazón vil
216925	Manto corazón vil
216938	Insignia de la Alianza superior
216939	Insignia de la Horda superior
216941	Sigilo de Ariden
216945	Reliquia de Dalaran curiosa
216946	Reliquia de Dalaran relumbrante
216947	Reliquia de Dalaran vibrante
216948	Reliquia de Dalaran extraña
216949	Reliquia de Dalaran pesada
216950	Reliquia de Dalaran espeluznante
216951	Reliquia de Dalaran resbaladiza
216956	Carta rota
216971	Bolsa de monedas de sangre de cobre
216972	Bolsa de monedas de sangre de plata
217005	Manteo de mecánico
217006	Martillo de mecánico
217007	Botas de poder agotado
217008	Pechera de poder agotado
217009	Piernas de poder agotado
217014	Bolsa de suministros
217017	¡Torneo de pesca!
217161	Notas sobre hechizos: ARGEDSCA REOARCAFOÍDN
217244	Patrón: toga de seda carmesí
217245	Toga de seda carmesí
217246	Jubón de tejido mágico negro
217247	Leotardos de tejido mágico negros
217248	Cinturón de seda terránea
217249	Patrón: cinturón de seda terránea
217250	Sobrehombros de seda carmesíes
217251	Patrón: sobrehombros de seda carmesíes
217252	Capa larga de seda
217253	Botas del encantador
217254	Patrón: botas del encantador
217255	Cinturón de seda carmesí
217256	Jubón terráneo
217257	Capucha de encantador
217258	Patrón: capucha de encantador
217259	Máscara de gran vudú
217260	Patrón: máscara de gran vudú
217261	Toga de gran vudú
217262	Patrón: toga de gran vudú
217263	Brazales de cuero de guardián
217264	Patrón: brazales de cuero de guardián
217265	Cinturón de guardián
217266	Patrón: cinturón de guardián
217267	Pantalones de guardián
217268	Coraza de escamas de tortuga
217270	Guantes de escamas de tortuga
217271	Patrón: guantes de escamas de tortuga
217273	Guanteletes de escamas doradas
217274	Diseño: guanteletes de escamas doradas
217275	Botas de escamas doradas
217276	Diseño: botas de escamas doradas
217277	Loriga de escamas doradas
217278	Diseño: loriga de escamas doradas
217279	Almófar de escamas doradas
217280	Diseño: almófar de escamas doradas
217281	Espada ancha de acero lunar
217282	Diseño: espada ancha de acero lunar
217283	Sobrehombros de escamas doradas
217284	Diseño: sobrehombros de escamas doradas
217285	Leotardos de escamas doradas
217286	Diseño: leotardos de escamas doradas
217287	Varita mística superior
217288	Togas del Exánime
217289	Armadura Fríomortal
217290	Ojo resplandeciente de Mordresh
217291	Calavera inerte de Mordresh
217292	Fajín de mago de la Muerte
217293	Manteo de araña sedosa
217294	Embozo embalsamado
217295	Varita necrótica
217296	Dije de fragmento fantasmal
217297	Toga de Doan
217298	Manto de Doan
217299	Vara ilusoria
217300	Sombrero de Melenablanca
217301	Amuleto Triune
217302	Poderío de Mograine
217303	Leotardos tejepiedra
217304	Guantes de Revelosh
217305	Guardabrazos de Revelosh
217306	Botas de Revelosh
217307	Bufas de Revelosh
217308	Sigilo encantado: Innovación
217314	Rifle de vista lunar
217315	Arco de precisión
217336	Monstruo - Íncubo Látigo Maza1H
217337	Envío de suministros
217338	Envío de suministros
217339	Envío de suministros
217345	Veneno sebáceo
217346	Veneno entumecedor
217347	Veneno atrófico
217350	Notas de ingeniería de Termochufe
217351	Notas de ingeniería de Termochufe
217398	Elixir Arcano inferior
217399	Receta: elixir Arcano inferior
217495	Pergamino de crioexplosión
217496	Pergamino de la hoja
217497	Espada Narpas
217609	Dije de Kazdor
217693	Poción de invisibilidad
217704	Cachiporra de hierro
217717	Emblema hueco
217718	Emblema de magia de sangre
217719	Esencia de magia de sangre
217720	Ofrenda de carne
217721	Ofrenda de hueso
217727	Resguardo de los muertos
217736	Runa de camarilla
217737	Dije modificado
219021	Mochila de mensajero pesada
219022	Anillo de transportista
219023	Anillo de funcionario
219024	Anillo de mensajero
219135	Colgante de curiosidad
219136	Colgante de tenacidad
219137	Colgante de iniciativa
219147	Runa de gracia
219223	Furia del maestro del acero
219326	Semilla de renovación
219343	Capucha de afanador
219345	Lazo infernal
219399	Musgo de la Pesadilla
219401	Mena de hierro frío
219402	Escama de dragón tocada por el Sueño
219404	Guadañasombría
219405	Manuscrito de magi ogro
219406	Huevo de dragón verde sin eclosionar
219414	Cáscaras de huevo destrozadas
219444	Raíz del Sueño
219445	Polvo de oro falso
219446	Escama de dragón imbuida por el Sueño
219447	Huevo de dragón tocado por el Sueño
219448	Motor onírico
219449	Profecía de Azshara
219454	Loto estelar
219486	Mena de plataestelar
219487	Concha estelar
219488	Huevo de dragón tocado por las estrellas
219490	Reliquia de Elune
219491	Perla onírica
219514	Raíz lunar
219515	Piedra lunar superior
219517	Escama de dragón lunar
219518	Desvaríos de arpía
219519	Notas del vigilante demente
219520	Huevo de dragón de resplandor lunar
219526	Informe de misión: Bosque del Ocaso
219759	Informe de campo de Kharla
219770	Informe de campo de Gemeron
219771	Informe de campo de Thandros
219772	Informe de campo de Fallia
219773	Informe de misión: Vallefresno
219774	Informe de misión: Tierras del Interior
219775	Informe de misión: Feralas
219776	Informe de inteligencia: Túmulo de Vul'Gol
219778	Informe de inteligencia: El Vergel Pútrido
219803	Informe de inteligencia: La Hacienda Yorgen
219918	Misiva sangrienta
219924	Informe de inteligencia: Canción del Bosque
219925	Informe de inteligencia: Satyrnaar
219926	Informe de inteligencia: Aserradero Grito de Guerra
219927	Trozo de esmeralda
219928	Informe de inteligencia: Agol'watha
219929	Misiva sangrienta
219930	Misiva sangrienta
219935	Hoja de Kajind
219937	Informe de inteligencia: Shaol'watha
219938	Informe de inteligencia: Roca Oculta
219957	Informe de inteligencia: Oneiros
219958	Informe de inteligencia: Los Dos Colosos
219959	Informe de inteligencia: Ruinas de Viento Azabache
219962	Incursiones de la Pesadilla: misión I del Bosque del Ocaso
219963	Autorización de designación: misión I del Bosque del Ocaso
219965	Autorización de designación: misión II del Bosque del Ocaso
219966	Incursiones de la Pesadilla: misión II del Bosque del Ocaso
219967	Incursiones de la Pesadilla: misión III del Bosque del Ocaso
219968	Incursiones de la Pesadilla: misión IV del Bosque del Ocaso
219969	Incursiones de la Pesadilla: misión V del Bosque del Ocaso
219970	Incursiones de la Pesadilla: misión VI del Bosque del Ocaso
219971	Incursiones de la Pesadilla: misión VII del Bosque del Ocaso
219972	Incursiones de la Pesadilla: misión VIII del Bosque del Ocaso
219973	Incursiones de la Pesadilla: misión IX del Bosque del Ocaso
219974	Incursiones de la Pesadilla: misión X del Bosque del Ocaso
219975	Incursiones de la Pesadilla: misión XI del Bosque del Ocaso
219976	Incursiones de la Pesadilla: misión XII del Bosque del Ocaso
219977	Incursiones de la Pesadilla: misión XIII del Bosque del Ocaso
219978	Incursiones de la Pesadilla: misión XIV del Bosque del Ocaso
219979	Incursiones de la Pesadilla: misión XV del Bosque del Ocaso
219980	Incursiones de la Pesadilla: misión XVI del Bosque del Ocaso
219981	Incursiones de la Pesadilla: misión XVII del Bosque del Ocaso
219982	Incursiones de la Pesadilla: misión XVIII del Bosque del Ocaso
219983	Autorización de designación: misión III del Bosque del Ocaso
219984	Autorización de designación: misión IV del Bosque del Ocaso
219985	Autorización de designación: misión V del Bosque del Ocaso
219986	Autorización de designación: misión VI del Bosque del Ocaso
219987	Autorización de designación: misión VII del Bosque del Ocaso
219988	Autorización de designación: misión VIII del Bosque del Ocaso
219989	Autorización de designación: misión IX del Bosque del Ocaso
219990	Autorización de designación: misión X del Bosque del Ocaso
219991	Autorización de designación: misión XI del Bosque del Ocaso
219992	Autorización de designación: misión XII del Bosque del Ocaso
219993	Autorización de designación: misión XIII del Bosque del Ocaso
219994	Autorización de designación: misión XIV del Bosque del Ocaso
219995	Autorización de designación: misión XV del Bosque del Ocaso
219996	Autorización de designación: misión XVI del Bosque del Ocaso
219997	Autorización de designación: misión XVII del Bosque del Ocaso
219998	Autorización de designación: misión XVIII del Bosque del Ocaso
219999	Incursiones de la Pesadilla: misión I de Vallefresno
220000	Incursiones de la Pesadilla: misión II de Vallefresno
220001	Incursiones de la Pesadilla: misión III de Vallefresno
220002	Incursiones de la Pesadilla: misión IV de Vallefresno
220003	Incursiones de la Pesadilla: misión V de Vallefresno
220004	Incursiones de la Pesadilla: misión VI de Vallefresno
220005	Incursiones de la Pesadilla: misión VII de Vallefresno
220006	Incursiones de la Pesadilla: misión VIII de Vallefresno
220007	Incursiones de la Pesadilla: misión IX de Vallefresno
220008	Incursiones de la Pesadilla: misión X de Vallefresno
220009	Incursiones de la Pesadilla: misión XI de Vallefresno
220010	Incursiones de la Pesadilla: misión XII de Vallefresno
220011	Incursiones de la Pesadilla: misión XIII de Vallefresno
220012	Incursiones de la Pesadilla: misión XIV de Vallefresno
220013	Incursiones de la Pesadilla: misión XV de Vallefresno
220014	Incursiones de la Pesadilla: misión XVI de Vallefresno
220015	Incursiones de la Pesadilla: misión XVII de Vallefresno
220016	Incursiones de la Pesadilla: misión XVIII de Vallefresno
220017	Incursiones de la Pesadilla: misión I de las Tierras del Interior
220018	Incursiones de la Pesadilla: misión II de las Tierras del Interior
220019	Incursiones de la Pesadilla: misión III de las Tierras del Interior
220020	Incursiones de la Pesadilla: misión IV de las Tierras del Interior
220021	Incursiones de la Pesadilla: misión V de las Tierras del Interior
220022	Incursiones de la Pesadilla: misión VI de las Tierras del Interior
220023	Incursiones de la Pesadilla: misión VII de las Tierras del Interior
220024	Incursiones de la Pesadilla: misión VIII de las Tierras del Interior
220025	Incursiones de la Pesadilla: misión IX de las Tierras del Interior
220026	Incursiones de la Pesadilla: misión X de las Tierras del Interior
220027	Incursiones de la Pesadilla: misión XI de las Tierras del Interior
220028	Incursiones de la Pesadilla: misión XII de las Tierras del Interior
220029	Incursiones de la Pesadilla: misión XIII de las Tierras del Interior
220030	Incursiones de la Pesadilla: misión XIV de las Tierras del Interior
220031	Incursiones de la Pesadilla: misión XV de las Tierras del Interior
220032	Incursiones de la Pesadilla: misión XVI de las Tierras del Interior
220033	Incursiones de la Pesadilla: misión XVII de las Tierras del Interior
220034	Incursiones de la Pesadilla: misión XVIII de las Tierras del Interior
220035	Incursiones de la Pesadilla: misión I de Feralas
220036	Incursiones de la Pesadilla: misión II de Feralas
220037	Incursiones de la Pesadilla: misión III de Feralas
220038	Incursiones de la Pesadilla: misión IV de Feralas
220039	Incursiones de la Pesadilla: misión V de Feralas
220040	Incursiones de la Pesadilla: misión VI de Feralas
220041	Incursiones de la Pesadilla: misión VII de Feralas
220042	Incursiones de la Pesadilla: misión VIII de Feralas
220043	Incursiones de la Pesadilla: misión IX de Feralas
220044	Incursiones de la Pesadilla: misión X de Feralas
220045	Incursiones de la Pesadilla: misión XI de Feralas
220046	Incursiones de la Pesadilla: misión XII de Feralas
220047	Incursiones de la Pesadilla: misión XIII de Feralas
220048	Incursiones de la Pesadilla: misión XIV de Feralas
220049	Incursiones de la Pesadilla: misión XV de Feralas
220050	Incursiones de la Pesadilla: misión XVI de Feralas
220051	Incursiones de la Pesadilla: misión XVII de Feralas
220052	Incursiones de la Pesadilla: misión XVIII de Feralas
220053	Autorización de designación: misión I de Vallefresno
220054	Autorización de designación: misión II de Vallefresno
220055	Autorización de designación: misión III de Vallefresno
220056	Autorización de designación: misión IV de Vallefresno
220057	Autorización de designación: misión V de Vallefresno
220058	Autorización de designación: misión VI de Vallefresno
220059	Autorización de designación: misión VII de Vallefresno
220060	Autorización de designación: misión VIII de Vallefresno
220061	Autorización de designación: misión IX de Vallefresno
220062	Autorización de designación: misión X de Vallefresno
220063	Autorización de designación: misión XI de Vallefresno
220064	Autorización de designación: misión XII de Vallefresno
220065	Autorización de designación: misión XIII de Vallefresno
220066	Autorización de designación: misión XIV de Vallefresno
220067	Autorización de designación: misión XV de Vallefresno
220068	Autorización de designación: misión XVI de Vallefresno
220069	Autorización de designación: misión XVII de Vallefresno
220070	Autorización de designación: misión XVIII de Vallefresno
220071	Autorización de designación: misión I de las Tierras del Interior
220072	Autorización de designación: misión II de las Tierras del Interior
220073	Autorización de designación: misión III de las Tierras del Interior
220074	Autorización de designación: misión IV de las Tierras del Interior
220075	Autorización de designación: misión V de las Tierras del Interior
220076	Autorización de designación: misión VI de las Tierras del Interior
220077	Autorización de designación: misión VII de las Tierras del Interior
220078	Autorización de designación: misión VIII de las Tierras del Interior
220079	Autorización de designación: misión IX de las Tierras del Interior
220080	Autorización de designación: misión X de las Tierras del Interior
220081	Autorización de designación: misión XI de las Tierras del Interior
220082	Autorización de designación: misión XII de las Tierras del Interior
220083	Autorización de designación: misión XIII de las Tierras del Interior
220084	Autorización de designación: misión XIV de las Tierras del Interior
220085	Autorización de designación: misión XV de las Tierras del Interior
220086	Autorización de designación: misión XVI de las Tierras del Interior
220087	Autorización de designación: misión XVII de las Tierras del Interior
220088	Autorización de designación: misión XVIII de las Tierras del Interior
220089	Autorización de designación: misión I de Feralas
220090	Autorización de designación: misión II de Feralas
220091	Autorización de designación: misión III de Feralas
220092	Autorización de designación: misión IV de Feralas
220093	Autorización de designación: misión V de Feralas
220094	Autorización de designación: misión VI de Feralas
220095	Autorización de designación: misión VII de Feralas
220096	Autorización de designación: misión VIII de Feralas
220097	Autorización de designación: misión IX de Feralas
220098	Autorización de designación: misión X de Feralas
220099	Autorización de designación: misión XI de Feralas
220100	Autorización de designación: misión XII de Feralas
220101	Autorización de designación: misión XIII de Feralas
220102	Autorización de designación: misión XIV de Feralas
220103	Autorización de designación: misión XV de Feralas
220104	Autorización de designación: misión XVI de Feralas
220105	Autorización de designación: misión XVII de Feralas
220106	Autorización de designación: misión XVIII de Feralas
220164	Runa del gladiador
220165	Runa de cólera
220166	Núcleo infernal ígneo
220167	Polvo de sepultura fulgurante
220168	Cerveza fundida de triple elaboración
220169	Símbolo de fe
220173	Parasomnia
220213	Sangre de vida vil
220214	Eslabón de cadena infernal
220216	Lazo infernal
220217	Runa del depredador
220345	Brujería sanguina
220346	Leyendas de los Sabiomar
220347	Lo liminal y lo arcano
220348	Etiqueta cotidiana
220349	Diseño de Fraguapiedra
220350	Viajes venenosos
220351	Sapta de aire turbia
220352	Mente metálica
220353	Códice de conjurador
220360	Runa de Floración
220375	Fragmento de aire
220379	Notas de chamán rasgadas
220446	Tesoro de otro mundo
220510	Esencia elemental
220511	Gran yelmo de la Pesadilla
220512	Casco de oroacero inmaculado
220514	Visera de plumas verdeantes
220515	Casco esmeralda encantado
220516	Visera olvidada de Gasher
220518	Sombrero polvoriento de Ba'ham
220519	Tocado de plumas vudú
220521	Tocado de ritualista Hakkari
220522	Corona de cazador de almas
220523	Rostro del exiliado
220525	Fragmento brillante de aire
220526	Procesador G-7 N.Ú.C.L.E.O. cubierto de fango
220527	Manto de rabioso Atal'ai
220528	Sobrehombros de montero Atal'ai
220529	Bufas de fanatismo
220530	Voluntad del guerrero Atal'ai
220531	Flor morada ondulante
220532	Bufas Atal'ai reforzadas
220533	Coraza Atal'ai reforjada
220534	Abrazo eterno de la serpiente alada
220535	Ropas del profeta Atal'ai
220536	Muñequeras de auxiliador Atal'ai
220537	Brazales Aguaoscura de soñador
220538	Brazales de escama de babosa malditos
220539	Bandas guerreras de sacrificio
220540	Manoplas cargadas de corrupción
220541	Puños de placas infestados
220542	Guanteletes Aguasucia contaminados
220543	Guantes de malla de escamas esmeralda
220544	Garfas de fulgor de sangre
220545	Guantes de luchador fétidos
220546	Manos del atormentado
220547	Guantes del profeta Atal'ai caído
220548	Guantes de aojador Atal'ai
220549	Correa de espiral del Alba
220550	Pretina de saqueador de templos
220551	Fajín de devoto del Sueño Esmeralda
220552	Guardarrenes de dolor
220553	Cinturón del beato renegado
220554	Sortija de colmillo de Atal'alarion
220555	Faja de escamas de serpiente Atal'ai
220556	Falda del profeta Atal'ai caído
220557	Sarong de escamas de viento malditas
220558	Leotardos de asesino Atal'ai
220559	Leotardos de escamas de draco revitalizadas
220560	Quijotes conchaplata
220561	Pateatrols tenaces
220562	Grebas de batalla tirosangre
220563	Botas del chamán de sangre Atal'ai
220564	Botas de reptaescamas reparadas
220565	Botas de caminaniebla etéreas
220566	Garra ardiente
220567	Cabeza de pincho ensangrentada
220568	Pistolahacha de expedicionario del templo
220569	Martillo de ira virulenta
220570	Manto de pesadillas
220571	Arco largo punzante
220572	Ballesta de repetición rápida de Rinzo
220573	Arco de caza de acechaterror
220574	Diente afilado de Eranikus
220575	Tragacondenados
220576	Hacha del verdugo Atal'ai
220577	Poderío del loa de sangre
220578	Puño de los Renegados
220579	Bastón de mojo de médico brujo
220580	Locura del avatar
220581	Machacaserpientes
220582	Grito de dragón
220583	Hoja infame de los desdichados
220584	Hoja de aliento de llama
220585	Uña funesta degradada
220586	Soberbia, la Marcabandidos
220587	Daga sacrificial del Sueño
220588	Garra de colmillo de cobra
220589	Asediador de serpiente
220590	Aguja de adoración Hakkari
220591	Vara vigorizante de Mijan
220594	Guadaña del Sueño
220595	Bastón de enfoque de la Pesadilla
220596	Vara adivinatoria antigua
220597	Piedra draco del presagista del Sueño
220598	Piedra draco del presagista de la Pesadilla
220599	Piedra draco del profeta de sangre
220600	Blasón de supremacía
220601	Protección de médica bruja Hakkari
220602	Medio caparazón de tortuga de las cloacas
220603	Vara de corrosión irreversible
220604	Trofeo de la Pesadilla
220605	Tratado sobre sacrilegio
220606	Ídolo del Sueño
220607	Tótem de linaje atormentado
220608	Manteo Piel emplumada
220609	Mantón del ocaso
220610	Runa de Maña mental
220611	Manteo de maleficio de Hukku
220612	Runa de Maremotos
220613	Runa de Trueno ondulante
220614	Runa de Choque estático
220615	Capa de pelaje de pantera
220616	Runa de sobrecarga
220617	Runa de pandemia
220618	Runa de Aura de Inmolación
220619	Ceremonia de sangre Atal'ai
220620	Cráneo de serpiente alada
220621	Cristal de resonancia de la Pesadilla
220622	Ojo de dragón perfectamente conservado
220623	Guardapelo perdido de Jin'do
220624	Talismán de valor manchado de sangre
220625	Resiliencia del exiliado
220626	Sortija de garra de draco del rabioso
220627	Sortija de garra de draco del acechador
220628	Sortija de garra de draco del presagista
220629	Sortija de garra de draco del profeta de sangre
220630	Sortija de garra de draco del gigante
220632	Medallón de ritual de sangre Atal'ai
220633	Distintivo de ritual de sangre Atal'ai
220634	Talismán de ritual de sangre Atal'ai
220635	Roca encantada de Atal'alarion
220636	Icono de sangre Atal'ai
220637	Marca de ritual Atal'ai
220638	Vara de brujería heterodoxa
220639	Inanimador de Lledra
220642	Armadura de placas de mártir desterrado
220643	Musleras de placas de mártir desterrado
220648	Botas de placas de mártir desterrado
220649	Herencia de Merithra
220650	Peto de profeta obsesionado
220651	Musleras de profeta obsesionado
220652	Botas ornamentadas de profeta obsesionado
220653	Peto de rabioso gemebundo
220654	Quijotes de rabioso gemebundo
220656	Botas de batalla de rabioso gemebundo
220657	Camisote de rabioso excluido
220658	Quijotes de rabioso excluido
220659	Grebas de anillas de rabioso excluido
220660	Camisa de malla de devoto rechazado
220661	Musleras de devoto rechazado
220662	Botas de escamas de devoto rechazado
220663	Leotardos de tejespíritus corrupto
220664	Escarpes de tejespíritus corrupto
220665	Coraza de tejespíritus corrupto
220666	Malla de anillas de cazaterror
220667	Calzas de cazaterror
220668	Grebas de cazaterror
220669	Chaleco de profeta exiliado
220670	Zapatillas de profeta exiliado
220671	Pantalones de cuero de profeta exiliado
220672	Arnés de beato perdido
220673	Leotardos de beato perdido
220674	Espada de sigilo arruinada
220675	Botines de beato perdido
220676	Guerrera de sangre corrupta
220677	Botas de sangre corrupta
220678	Pantalones de sangre corrupta
220679	Leotardos del profeta malevolente
220680	Jubón del profeta malevolente
220681	Sandalias del profeta malevolente
220682	Runa del desenfrenado
220683	Jubón del profeta benevolente
220684	Leotardos del profeta benevolente
220685	Sandalias del profeta benevolente
220686	Terror del cabecilla
220687	Runa del raptor
220688	Manto de pesadillas inerte
220689	Avambrazos potenciados por el Vacío
220738	Hombreras de terror
220739	Espaldares aciagos
220740	Guardahombros del turbador
220741	Espaldares de anillas aulladoras
220742	Bufas chillonas
220743	Guardahombros de anillas cacofónicas
220744	Manto de anillas gemebundas
220745	Membrana de neurosis oscura
220747	Manto de paranoia
220748	Hombreras de obsesión
220749	Manto de locura
220750	Espaldares de mente fracturada
220751	Hombreras del trastornado
220754	Runa de la tormenta de viento
220775	Cupón de cambio de ingeniería
220778	Pantalones de guardasangre coagulada
220779	Guerrera de guardasangre coagulada
220780	Botas de guardasangre coagulada
220781	Leotardos de profeta de la Pesadilla
220783	Vestimentas de profeta de la Pesadilla
220784	Sandalias de profeta de la Pesadilla
220791	Runa del felino de la selva
220792	Pergamino de alivio espacial
220794	Camisote de placas de Caballero
220795	Espaldares de placas de Teniente caballero
220796	Espaldares de placas de Guardia de sangre
220797	Leotardos de placas de Caballero
220798	Leotardos de placas de Guardia de piedra
220799	Grebas de placas de Alférez
220800	Grebas de placas de Gran capataz
220801	Armadura de placas de Guardia de piedra
220803	Yelmo de placas de Guardia de sangre
220804	Yelmo de placas de Teniente caballero
220806	Guanteletes de placas de Alférez
220807	Guanteletes de placas de Gran capataz
220808	Espaldares imbuidos de Teniente caballero
220809	Leotardos imbuidos de Caballero
220810	Casco imbuido de Teniente caballero
220811	Grebas imbuidas de Alférez
220812	Guanteletes imbuidos de Alférez
220813	Armadura imbuida de Caballero
220814	Botas de láminas de Alférez
220815	Peto de láminas de Caballero
220816	Quijotes de láminas de Caballero
220817	Guanteletes de láminas de Alférez
220818	Espaldares de láminas de Teniente caballero
220819	Yelmo de láminas de Teniente caballero
220820	Casco de malla de Guardia de sangre
220821	Casco de anillas de Guardia de sangre
220822	Casco de anillas de Teniente caballero
220823	Cubrehombros de malla de Guardia de sangre
220824	Cubrehombros de anillas de Guardia de sangre
220825	Cubrehombros de anillas de Teniente caballero
220826	Armadura de malla de Guardia de piedra
220827	Armadura de anillas de Guardia de piedra
220828	Armadura de anillas de Caballero
220829	Guanteletes de anillas de Alférez
220830	Guanteletes de anillas de Gran capataz
220831	Guanteletes de malla de Gran capataz
220832	Quijotes de anillas de Caballero
220833	Quijotes de anillas de Guardia de piedra
220834	Quijotes de malla de Guardia de piedra
220835	Escarpes de malla de Gran capataz
220836	Escarpes de anillas de Gran capataz
220837	Escarpes de anillas de Alférez
220838	Pechera con inscripciones de Guardia de piedra
220839	Quijotes con inscripciones de Guardia de piedra
220840	Escarpes con inscripciones de Gran capataz
220841	Hombreras con inscripciones de Guardia de sangre
220842	Capacete con inscripciones de Guardia de sangre
220843	Guanteletes con inscripciones de Gran capataz
220844	Coraza pulsante de Guardia de piedra
220845	Guanteletes pulsantes de Gran capataz
220846	Grebas pulsantes de Gran capataz
220847	Quijotes pulsantes de Guardia de piedra
220848	Casco pulsante de Guardia de sangre
220849	Sobrehombros pulsantes de Guardia de sangre
220850	Cinta de cuero de Teniente caballero
220851	Cinta de cuero de Guardia de sangre
220852	Sobrehombros de cuero de Teniente caballero
220853	Sobrehombros de cuero de Guardia de sangre
220854	Armadura de cuero de Caballero
220855	Armadura de cuero de Guardia de piedra
220856	Guanteletes de cuero de Alférez
220857	Guanteletes de cuero de Gran capataz
220858	Pantalones de cuero de Caballero
220859	Pantalones de cuero de Guardia de piedra
220860	Botas de cuero de Alférez
220861	Botas de cuero de Gran capataz
220862	Botas de cuero agrietado de Alférez
220863	Botas de cuero agrietado de Gran capataz
220864	Leotardos de cuero agrietado de Caballero
220865	Leotardos de cuero agrietado de Guardia de piedra
220866	Guanteletes de cuero agrietado de Alférez
220867	Guanteletes de cuero agrietado de Gran capataz
220868	Guerrera de cuero agrietado de Caballero
220869	Guerrera de cuero agrietado de Guardia de piedra
220870	Bufas de cuero agrietado de Teniente caballero
220871	Bufas de cuero agrietado de Guardia de sangre
220872	Casco de cuero agrietado de Teniente caballero
220873	Casco de cuero agrietado de Guardia de sangre
220874	Yelmo de cuero restaurado de Teniente caballero
220875	Yelmo de cuero restaurado de Guardia de sangre
220876	Bufas de cuero restaurado de Teniente caballero
220877	Bufas de cuero restaurado de Guardia de sangre
220878	Chaleco de cuero restaurado de Caballero
220879	Chaleco de cuero restaurado de Guardia de piedra
220880	Guantes de cuero restaurado de Alférez
220881	Guantes de cuero restaurado de Gran capataz
220882	Leotardos de cuero restaurado de Caballero
220883	Leotardos de cuero restaurado de Guardia de piedra
220884	Botas de cuero restaurado de Alférez
220885	Botas de cuero restaurado de Gran capataz
220886	Jubón de tejido de tinieblas de Caballero
220887	Manto de tejido de tinieblas de Teniente caballero
220888	Leotardos de tejido de tinieblas de Caballero
220889	Sombrero de tejido de tinieblas de Teniente caballero
220890	Guantes de tejido de tinieblas de Alférez
220891	Botas de tejido de tinieblas de Alférez
220892	Armadura de satén de Caballero
220893	Leotardos de satén de Caballero
220894	Hombreras de satén de Teniente caballero
220895	Botas de satén de Alférez
220896	Casquete de satén de Teniente caballero
220897	Guantes de satén de Alférez
220898	Guantes de satén de Gran capataz
220899	Casquete de satén de Guardia de sangre
220900	Botas de satén de Gran capataz
220901	Hombreras de satén de Guardia de sangre
220902	Leotardos de satén de Guardia de piedra
220903	Armadura de satén de Guardia de piedra
220904	Jubón de tejido de tinieblas de Guardia de piedra
220905	Manto de tejido de tinieblas de Guardia de sangre
220906	Leotardos de tejido de tinieblas de Guardia de piedra
220907	Sombrero de tejido de tinieblas de Guardia de sangre
220908	Guantes de tejido de tinieblas de Gran capataz
220909	Botas de tejido de tinieblas de Gran capataz
220912	Martillo de geodas
220913	Runa de demolición
220914	Martillo de geodas roto
220915	Ídolo de arrastrapiés furibundo
220916	Cuerno de estegodón Tronavapuleus
220917	Caja de tinte escarlata
220918	Suministros saqueados: sopa de almejas de Minahonda
220919	Suministros saqueados: sopa de pargo nocturno
220920	Suministros saqueados: chuletas de lobo tierno
220921	Suministros saqueados: vendas de tejido mágico gruesas
220922	Suministros saqueados: soleas
220923	Suministros saqueados: hojasueño
220924	Suministros saqueados: barras de veraplata
220925	Suministros saqueados: barras de torio
220926	Suministros saqueados: cuero basto
220927	Suministros saqueados: pellejos gruesos
220928	Suministros saqueados: barras de torio encantado
220929	Suministros saqueados: pociones de maná excelentes
220930	Suministros saqueados: pociones de sanación sublimes
220931	Suministros saqueados: bombas altamente explosivas
220932	Suministros saqueados: granadas de torio
220933	Suministros saqueados: rifles de torio
220934	Suministros saqueados: almófares de mitril
220935	Suministros saqueados: cinturones de torio
220936	Suministros saqueados: guanteletes de veraplata
220937	Suministros saqueados: refuerzos para armadura bastos
220938	Suministros saqueados: brazales de cuero maligno
220939	Suministros saqueados: brazales de cuero rúnico
220940	Suministros saqueados: cintas de tejido mágico negras
220941	Suministros saqueados: cinturones de paño rúnico
220942	Suministros saqueados: camisas de esmoquin
220964	Avambrazos potenciados por el Vacío descargados
220965	Gran hacha de horrocrusto
221008	Envío de suministros
221009	Envío de suministros
221010	Envío de suministros
221017	Registro de Keldara
221018	Equipo médico de campo
221019	Muestra de hierba de sátiro
221020	Runa de la diosa de la luna
221021	Semilla de pesadilla
221024	Frasco de pesadillas perpetuas
221025	Avambrazos de invocador potenciados por el Vacío
221026	Avambrazos de asesino potenciados por el Vacío
221027	Avambrazos de protector potenciados por el Vacío
221028	Sigilo encantado: Sueños vivos
221030	Mojo Atal'ai de magia prohibida
221191	Piedra del Sueño
221192	Diario onírico
221193	Anillo de esmeralda
221196	Mojo Atal'ai de guerra
221199	Tintura de hierba de sátiro
221256	Brazo derecho del Obliterador
221257	Brazo izquierdo del Obliterador
221258	Pie derecho del Obliterador
221259	Pie izquierdo del Obliterador
221260	Cabeza del Obliterador
221261	Jarabe de susurro salvaje
221262	Ofrenda salvaje
221267	Runa del sediento de sangre
221271	As Salvaje
221272	Baraja Salvaje
221273	Dos Salvaje
221274	Tres Salvaje
221275	Cuatro Salvaje
221276	Cinco Salvaje
221277	Seis Salvaje
221278	Siete Salvaje
221279	Ocho Salvaje
221280	Baraja de Plagas
221281	As de Plagas
221282	Dos de Plagas
221283	Tres de Plagas
221284	Cuatro de Plagas
221285	Cinco de Plagas
221286	Seis de Plagas
221287	Siete de Plagas
221288	Ocho de Plagas
221289	Baraja de Dunas
221290	As de Dunas
221291	Dos de Dunas
221292	Tres de Dunas
221293	Cuatro de Dunas
221294	Cinco de Dunas
221295	Seis de Dunas
221296	Siete de Dunas
221297	Ocho de Dunas
221298	As de Pesadillas
221299	Baraja de Pesadillas
221300	Dos de Pesadillas
221301	Tres de Pesadillas
221302	Cuatro de Pesadillas
221303	Cinco de Pesadillas
221304	Seis de Pesadillas
221305	Siete de Pesadillas
221306	Ocho de Pesadillas
221307	Naipe de la Luna Negra: Descomposición
221308	Naipe de la Luna Negra: Sobrecrecimiento
221309	Naipe de la Luna Negra: Tormenta de arena
221310	Naipe de la Luna Negra: Tormento
221311	Mojo Atal'ai de vida
221312	Frasco de mojo Atal'ai
221313	Frasco de mojo de pesadilla
221314	Cartel de Se busca
221315	Generador de arcoíris
221316	Uniforme que exige aplomo de Premo
221317	Cristal Ley de Feralas
221318	Cristal Ley de Azshara
221319	Cristal Ley de Roca Negra
221320	Cristal Ley de las Tierras del Interior
221321	Sello Atal'ai de poderío
221322	Sello Atal'ai de mojo
221323	Sello Atal'ai de serenidad
221324	Llave Forjatiniebla frágil
221325	Carga explosiva para tontos
221326	Corazón de venado sacro
221327	Esquema: rayo reductor gnómico
221328	Esquema: gafas gnómicas
221329	Esquema: proyector redomático gnómico
221330	Esquema: cinturón de prevención de daño gnómico
221331	Esquema: botas cohete gnómicas
221332	Esquema: gallo de batalla gnómico
221333	Esquema: gorro de control mental gnómico
221334	Esquema: rayo mortal gnómico
221335	Esquema: casco de albañil goblin
221336	Esquema: casco de minero goblin
221337	Esquema: mortero goblin
221338	Esquema: carga de zapador goblin
221339	Esquema: botas de cohete goblin
221340	Esquema: dispensador de bombas goblin
221341	Esquema: el grande
221342	Esquema: escopeta dragón goblin
221343	Esquema: casco de cohete goblin
221344	Libro de hechizos personal
221345	Sangre corrupta de Eranikus
221346	Omóplato del Avatar Caído
221347	Sapta de fuego turbia
221348	Sapta de agua turbia
221349	Sapta de tierra turbia
221350	Notas de chamán chamuscadas
221351	Notas de chamán empapadas
221352	Notas de chamán emborronadas
221353	Fragmento de fuego
221354	Fragmento de agua
221355	Fragmento de tierra
221356	Fragmento brillante de fuego
221357	Fragmento brillante de agua
221358	Fragmento brillante de tierra
221359	Pluma de lechubestia prístina
221360	Papiro farraki
221361	Resina de Zukk'ash
221362	Paño para limpiar armas
221363	Omóplato del Avatar Caído
221364	Moneda de masacre de cobre
221365	Moneda de masacre de plata
221366	Moneda de masacre de oro
221367	Bolsa de monedas de masacre de cobre
221368	Bolsa de monedas de masacre de plata
221369	Succión de la Pesadilla
221370	Medallón precioso
221371	Monedero de secuestrador
221372	Monedero destrozado
221374	Angustia del Sueño
221376	Yelmo del Sueño Esmeralda
221377	Quijotes del Sueño Esmeralda
221378	Guanteletes del Sueño Esmeralda
221379	Escarpes del Sueño Esmeralda
221380	Coraza del Sueño Esmeralda
221381	Espaldares del Sueño Esmeralda
221382	Placa de batalla con esmeraldas incrustadas
221383	Manoplas con esmeraldas incrustadas
221384	Casco con esmeraldas incrustadas
221385	Quijotes con esmeraldas incrustadas
221386	Bufas con esmeraldas incrustadas
221387	Botas de placas con esmeraldas incrustadas
221388	Leotardos de malla de escamas esmeralda
221389	Guanteletes de malla de escamas esmeralda
221390	Coraza de malla de escamas esmeralda
221391	Casco de malla de escamas esmeralda
221392	Sobrehombros de malla de escamas esmeralda
221393	Botas de malla de escamas esmeralda
221394	Botas cargadas esmeralda
221395	Coraza cargada esmeralda
221396	Guanteletes cargados esmeralda
221397	Casco cargado esmeralda
221398	Leotardos cargados esmeralda
221399	Sobrehombros cargados esmeralda
221400	Sobrehombros de anillas esmeralda
221401	Leotardos de anillas esmeralda
221402	Casco de anillas esmeralda
221403	Guanteletes de anillas esmeralda
221404	Coraza de anillas esmeralda
221405	Botas de anillas esmeralda
221406	Jubón de cuero esmeralda
221407	Guantes de cuero esmeralda
221408	Yelmo de cuero esmeralda
221409	Escarpes de cuero esmeralda
221410	Pantalones de cuero esmeralda
221411	Sobrehombros de cuero esmeralda
221412	Guantes de guardasueños esmeralda
221413	Yelmo de guardasueños esmeralda
221414	Pantalones de guardasueños esmeralda
221415	Botas de guardasueños esmeralda
221416	Sobrehombros de guardasueños esmeralda
221417	Pechera de guardasueños esmeralda
221418	Rugido de Agamaggan
221419	Jubón de vigía esmeralda
221420	Botas de vigía esmeralda
221421	Guantes de vigía esmeralda
221422	Yelmo de vigía esmeralda
221423	Leotardos de vigía esmeralda
221424	Sobrehombros de vigía esmeralda
221425	Diadema encantada esmeralda
221426	Botas encantadas esmeralda
221427	Guantes encantados esmeralda
221428	Runa de juego infame
221429	Pantalones encantados esmeralda
221430	Toga encantada esmeralda
221431	Sobrehombros encantados esmeralda
221432	Manto de tejido esmeralda
221433	Runa de enfoque
221434	Toga de tejido esmeralda
221435	Pantalones de tejido esmeralda
221436	Guantes de tejido esmeralda
221437	Diadema de tejido esmeralda
221438	Botas de tejido esmeralda
221439	Armadura del letargo esmeralda
221440	Rugido del Sueño
221441	Celador del Sueño
221442	Rugido del guardián
221443	Rugido de la arboleda
221444	Durian de la selva
221445	Runa de fuego enfocado
221446	Martillo de ritualista
221447	Grimorio de la luna de sangre de ritualista
221448	Talismán de la Arboleda Corrupta
221450	Arco de luchador de fosa Gurubashi
221451	Ballesta sedienta de sangre
221452	Sortija Arcana de sangre enfocada
221453	Sortija de sangre en ebullición
221454	Sortija de sangre glacial
221455	Reverencia de luz de sangre
221456	Sable sanguino eclipsado
221457	Tratado sobre la destrucción dracónica
221458	Sortija de victoria sombría
221459	Sello del sacrificado
221460	Puñal Gurubashi
221461	Runa de Carnicería
221462	Espada de velocidad ensangrentada
221463	Muñeco de vudú ancestral
221464	Tótem de precisión ígnea
221465	Aplastadora corrupta
221466	Aro de sangre ardiente
221467	Ojo de la luna de sangre
221468	Muro de susurros
221469	Lanza con púas de rebanacabezas
221470	Esmeralda del Sueño
221471	Pechera de los Celadores Esmeralda
221473	Runa del velador
221474	Esencia encadenada de Eranikus
221475	Esencia de Eranikus
221480	Notas sobre hechizos: Armadura de arrabio
221481	Epifanía nihilista
221482	Runa de aflicción
221483	Runa de Quemadura
221484	Vara de brujería de médico brujo
221487	Notas sobre hechizos: Protección avanzada
221488	Epifanía firme
221489	Runa de Venganza
221490	Runa de Mareas vivas
221491	Bolsa diente oscuro
221497	Llave vieja
221498	Caja de comida recia
221499	Runa del guardia vil
221510	Runa del caballero
221511	Runa del protector
221512	Runa de prontitud
221513	Runa de potencia
221514	Runa de poder de Fuego
221515	Runa de detonación
221516	Runa de energía primigenia
221517	Runa de Escabechina
221518	Susurros
221519	Orbe Mannoroc
221544	Huevo de cuervo de tormenta
221545	Notas de brujo descifradas
221547	Notas de brujo cifradas
221549	Clave de Deambulador
221780	Cetro de la princesa Theradras
221781	Yelmo de guardia vengador
221782	Yelmo de Exilio
221783	Bufas de justiciero
221785	Vestimentas Cenarion
221971	Cuerno brasasueño
221972	Fuego ardesueño
221973	Colmillo cazasueños
221974	Collar Tótem Siniestro
221975	Bastón Zarpaleña roto
221976	Bastón de naturaleza enfermo
221978	Alma de expedicionario
221979	Profecía del invierno verdeante
221980	Profecía del caos despierto
221981	Profecía de la tribu perdida
222952	Frasco de Sueños Inquietos
222962	Sabiduría de Hyjal
223073	Cubrehombros de malla de Teniente caballero
223074	Quijotes de malla de Caballero
223075	Casco de malla de Teniente caballero
223076	Guanteletes de malla de Alférez
223077	Escarpes de malla de Alférez
223078	Armadura de malla de Caballero
223147	Notas sobre hechizos: Descarga de Fuegotorvo
223148	Un tesoro de otro mundo
223149	Un tesoro de otro mundo
223150	Un tesoro de otro mundo
223151	Un tesoro de otro mundo
223160	Arbusto de los tratos
223161	Cajón de suministros vacío
223162	Morral de mensajero útil
223163	Fórmula: pergamino de alivio espacial
223164	Capucha de curiosidad
223167	Gorro de iniciativa
223168	Fragmento de núcleo del mundo
223169	Gorro de tenacidad
223171	Pergamino de geomancia
223172	Cadena de tenacidad
223173	Cordón de geomántico
223174	Botas de geomántico
223175	Capa de geomántico
223177	Almete de geomántico
223178	Brazales de geomántico
223180	Guantes de geomántico
223181	Bufas de geomántico
223182	Calzas de geomántico
223183	Sobrevesta de geomántico
223186	Entregador de suministros
223192	Cordón del indomable
223193	Corona del tejesueños
223194	Sortija de las tierras salvajes
223195	Amplitud de la bestia
223196	Grebas de matadioses
223197	Defensor de las tierras salvajes
223198	Modas Karkun
223214	Zila Gular
223215	Orah Raka
223216	Rakkan Archim
223217	Rakkas Lek
223218	Tor Kieldaz
223219	Braciles de paño vil
223221	Braciles de cuero vil
223222	Braciles de malla vil
223237	Hombreras de paño vil
223238	Hombreras de cuero vil
223239	Sobrehombros de malla vil
223240	Caperuza de paño vil
223241	Sombrero de cuero vil
223242	Almófar de malla vil
223248	Leotardos de paño vil
223249	Leotardos de cuero vil
223250	Leotardos de malla vil
223251	Leotardos de placas viles
223256	Toga de paño vil
223261	Pechera de cuero vil
223262	Pechera de malla vil
223263	Pechera de placas viles
223283	Mención honorífica manchada de sangre
223288	Runa del martillo
223323	Camisa
223324	Leotardos de zancalluvia
223325	Coraza Hakkari
223326	Embozo Hakkari
223327	Marca de Hakkar
223328	Aro ráfaga de gemas
223329	Puntilla fuerza de vida
223330	Ojo pulsante
223331	Ojo pulsante
223332	Ojo vibrante
223333	Ojo aciago
223334	Ojo resplandeciente
223335	Ojo supurante
223336	Ojo penetrante
223337	Ojo ardiente
223518	Dirk de calcinita
223519	Ojo de Theradras
223520	Espada focal de inventor
223521	Manto de Escamapodrida
223522	Yelmo de la montaña
223523	Piedra nube
223524	Puño de piedra
223525	Ornato de veritas
223526	Sul'thraze la Azotadora
223527	Colmillo de Gahz'rilla
223528	Armadura de escamas de Gahz'rilla
223529	Piel hudú maldita
223530	Falda hudú maldita
223531	Espaldares malos grandes
223532	Amuleto sangrevida
223533	Bastón de Caminadesiertos
223534	Mandiletes jumanza
223535	Vestimentas tribales de Grimlok
223536	Carga de Grimlok
223537	Brazales Placacráneos
223538	Badil
223539	Esfera embrujada
223540	Arco de maestro de perros de caza
223541	Corazón de fragmentos de gemas
223542	Rifle megatiro
223543	Botas de viña pútrida
223544	Bufas de posometal
223545	Rodela hipertécnica de Gizlock
223648	Flecha imbuida del Sueño
223912	Poción de purificación
223913	Poción de sanación sublime
223914	Poción de sanación superior
223962	Tobilleras Acecharenas
223963	Abrazo del licántropo
223964	Hoja de oscuridad eterna
223980	Leotardos de escamas abrasadoras
223981	Togas de zancudo flamígero
223982	Rifle de maestro de perros de caza
223983	Hoja de mediador
223984	Guantes de tela de seda
223985	Sortija ciclópea
223986	Manteo de podredumbre de tumba
223987	Sobrehombros de pellejo escindido
224004	Anillo de esmeralda
224005	Anillo de esmeralda
224006	Anillo de esmeralda
224122	Comesueños
224279	Terrestris
224280	Soberano, Defensor de los Vuelos
224281	Gla'sir
224282	Rae'lar
224409	Asediador de serpiente
224806	Sintonizador de portal de la Legión
224836	Un tesoro de otro mundo
224848	Un tesoro de otro mundo
224849	Un tesoro de otro mundo
224850	Un tesoro de otro mundo
224851	Un tesoro de otro mundo
224893	Sintonizador de portal sobrecargado
224912	Sintonizador de portales
225675	Núcleo de obsidiana tiznado
225676	Núcleo de obsidiana fundido
225686	Runa de Exterminio
225687	Runa de Armadura infernal
225688	Runa de Marca de caos
225689	Notas sobre hechizos: Tromba Arcana
225690	Notas sobre hechizos: Orbe congelado
225691	Notas sobre hechizos: Recalentamiento
225740	Runa de compostura
225838	Icono voltaico
225893	Fin de una época
225914	Runa del espíritu esclavizado
225929	Fragmento de alma apestada
225938	Notas sobre hechizos rasgadas
225939	Notas sobre hechizos rasgadas
225940	Notas sobre hechizos rasgadas
225941	Notas sobre hechizos rasgadas
225942	Carne de jabalí máculo
225943	Trozo de carne rancio
225954	Notas sobre hechizos chamuscadas
225955	Runa del industrioso
226122	Cuerno de Dalton
226201	Hoja del escudero Cuthbert
226207	Eco de Anastari
226208	Eco de Barthilas
226209	Eco de Dathrohan
226210	Eco de Maleki
226211	Eco de Nerub'enkan
226212	Eco de Ramstein
226213	Eco de Osahendido
226214	Eco de Willey
226252	Runa de la guerrilla
226374	Veneno oculto I
226394	Manual de Veneno atrófico
226395	Manual de Veneno entumecedor
226396	Manual de Veneno oculto
226397	Manual de Veneno sebáceo
226401	Tratado sobre el Corazón del león
226402	Revelación de Ira del chamán
226403	Vademécum de Gancho
226404	Real deslustrado de Minahonda
226405	Cajón de suministros de Minahonda dañado
226406	Runa de especialización en espadas
226407	Runa de especialización en hachas
226408	Runa de especialización en mazas
226409	Runa de especialización en dagas
226410	Runa de especialización en armas a distancia
226411	Runa de especialización en armas de puño
226412	Runa de especialización en armas de asta
226413	Runa de especialización en lo Arcano
226414	Runa de especialización en Fuego
226415	Runa de especialización en Escarcha
226416	Runa de especialización en Naturaleza
226417	Runa de especialización en las Sombras
226418	Runa de especialización Sagrada
226419	Runa de especialización en combate feral
226420	Busto finamente tallado
226421	PLACEHOLDER_ASHBRINGER_QUESTITEM_01
226440	Cinturón de Destripador Nocturno
226441	Guantes de Destripador Nocturno
226442	Pulseras de Destripador Nocturno
226443	Botas de Destripador Nocturno
226444	Hombreras de Destripador Nocturno
226445	Pantalones de Destripador Nocturno
226446	Casquete de Destripador Nocturno
226447	Pechera de Destripador Nocturno
226472	Jarro sombrío de Stratholme
226473	Loriga de Destripador Nocturno
226474	Guardarrenes de Destripador Nocturno
226475	Manoplas de Destripador Nocturno
226476	Brazales de Destripador Nocturno
226477	Tabi de Destripador Nocturno
226478	Espaldares de Destripador Nocturno
226479	Musleras de Destripador Nocturno
226480	Caperuza de Destripador Nocturno
226484	Brazales de poderío
226485	Cinturón de poderío
226486	Guanteletes de poderío
226487	Escarpes de poderío
226488	Yelmo de poderío
226489	Coraza de poderío
226490	Quijotes de poderío
226491	Hombreras de poderío
226492	Espaldares de poderío
226493	Leotardos de poderío
226494	Camisote de poderío
226495	Mandíbulas de poderío
226496	Botines de poderío
226497	Manos de poderío
226498	Fajín de poderío
226499	Guardabrazos de poderío
226500	Amuleto Pirodraco astillado
226523	Cuerno de Dalton
226526	Cachivache estropeado
226527	Cubrehombros de acechagigantes
226528	Guantes de acechagigantes
226529	Cinturón de acechagigantes
226530	Brazales de acechagigantes
226531	Botas de acechagigantes
226532	Leotardos de acechagigantes
226533	Casco de acechagigantes
226534	Coraza de acechagigantes
226535	Malla de anillas de acechagigantes
226536	Disfraz de acechagigantes
226537	Leotardos de anillas de acechagigantes
226538	Escarpes de acechagigantes
226540	Manoplas de acechagigantes
226541	Guardamuñecas de acechagigantes
226542	Faja de acechagigantes
226543	Bufas de acechagigantes
226545	Cuerno de Dalton
226546	Sonar del desierto
226547	Pantalones corazón vil
226548	Togas corazón vil
226549	Cuernos corazón vil
226550	Hombreras corazón vil
226551	Cinturón corazón vil
226552	Guantes corazón vil
226553	Brazales corazón vil
226554	Zapatillas corazón vil
226555	Cinturón de arcanista
226556	Guantes de arcanista
226557	Botas de arcanista
226558	Ataduras de arcanista
226559	Togas de arcanista
226560	Manto de arcanista
226561	Leotardos de arcanista
226562	Corona de arcanista
226563	Ropas de arcanista
226564	Ornato de arcanista
226565	Pantalones de arcanista
226566	Sobrehombros de arcanista
226567	Cubremuñecas de arcanista
226568	Sandalias de arcanista
226569	Manoplas de arcanista
226570	Cordón de arcanista
226571	Botas de profecía
226572	Guantes de profecía
226573	Aro de profecía
226574	Pantalones de profecía
226575	Togas de profecía
226576	Manto de profecía
226577	Faja de profecía
226578	Avambrazos de profecía
226579	Cubremuñecas de profecía
226580	Cinturón de profecía
226581	Hombreras de profecía
226582	Ropas de profecía
226583	Leotardos de profecía
226584	Corona de profecía
226585	Manos de profecía
226586	Sandalias de profecía
226587	Runa de artillería
226588	Bufas de justiciero
226589	Brazales de justiciero
226590	Yelmo de justiciero
226591	Guanteletes de justiciero
226592	Cinturón de justiciero
226593	Botas de justiciero
226594	Quijotes de justiciero
226595	Coselete de justiciero
226596	Brazales de guerra de justiciero
226597	Faja de justiciero
226598	Leotardos de justiciero
226599	Corona de justiciero
226600	Mandiletes de justiciero
226601	Botas de batalla de justiciero
226602	Coraza de justiciero
226603	Avambrazos de justiciero
226604	Cinturón de batalla de justiciero
226605	Espaldares de justiciero
226606	Musleras de justiciero
226607	Protegecabezas de justiciero
226608	Manoplas de justiciero
226609	Escarpes de justiciero
226610	Peto de justiciero
226611	Cubrehombros de furia terrenal
226612	Casco de furia terrenal
226613	Botas de furia terrenal
226614	Musleras de furia terrenal
226615	Guanteletes de furia terrenal
226616	Cinturón de furia terrenal
226617	Vestimentas de furia terrenal
226618	Brazales de furia terrenal
226619	Cota guarnecida de furia terrenal
226620	Botos de furia terrenal
226621	Manos de furia terrenal
226622	Visor de furia terrenal
226623	Leotardos de furia terrenal
226624	Manto de furia terrenal
226625	Cordón de furia terrenal
226626	Braciles de furia terrenal
226627	Malla de escamas de furia terrenal
226628	Escarpes de furia terrenal
226629	Manoplas de furia terrenal
226630	Gran yelmo de furia terrenal
226631	Leotardos escamados de furia terrenal
226632	Espaldares de furia terrenal
226633	Guardarrenes de furia terrenal
226634	Guardamuñecas de furia terrenal
226635	Malla de anillas de furia terrenal
226636	Botas de batalla de furia terrenal
226637	Mandiletes de furia terrenal
226638	Celada de furia terrenal
226639	Leotardos de anillas de furia terrenal
226640	Bufas de furia terrenal
226641	Faja de furia terrenal
226642	Ataduras de furia terrenal
226644	Bufas Cenarion
226645	Botas Cenarion
226646	Leotardos Cenarion
226647	Yelmo Cenarion
226648	Guantes Cenarion
226649	Brazales Cenarion
226650	Cinturón Cenarion
226651	Calzas Cenarion
226652	Sandalias Cenarion
226653	Manto Cenarion
226654	Guanteletes Cenarion
226655	Muñequeras Cenarion
226656	Abrazo Cenarion
226657	Cordón Cenarion
226658	Cornamenta Cenarion
226659	Cuernos Cenarion
226660	Faja Cenarion
226661	Guerrera Cenarion
226662	Braciles Cenarion
226663	Botines Cenarion
226664	Puños Cenarion
226665	Sobrehombros Cenarion
226666	Calzas Cenarion
226667	Guardarrenes Cenarion
226668	Guardamuñecas Cenarion
226669	Mandiletes Cenarion
226670	Corona Cenarion
226671	Musleras Cenarion
226673	Botos Cenarion
226674	Espaldares Cenarion
226675	Armadura Cenarion
226678	Premonición y previsión de combate
226679	Perspicacia de errante intemporal
226680	Runa del primer guerrero
226694	Runa de especialización en defensa
226698	Muestrario para terreno compuesto verticalmente
226699	Brida forrada de latón
226700	Guerrera arte sombrío
226701	Cinturón arte sombrío
226702	Guantes arte sombrío
226703	Botas arte sombrío
226704	Brazales arte sombrío
226705	Pantalones arte sombrío
226706	Bufas arte sombrío
226707	Almete arte sombrío
226708	Capucha Corazón Salvaje
226709	Falda Corazón Salvaje
226710	Bufas Corazón Salvaje
226711	Guantes Corazón Salvaje
226712	Cinturón Corazón Salvaje
226713	Botas Corazón Salvaje
226714	Brazales Corazón Salvaje
226715	Jubón Corazón Salvaje
226716	Manto de acechabestias
226717	Ataduras de acechabestias
226718	Cinturón de acechabestias
226719	Pantalones de acechabestias
226720	Almete de acechabestias
226721	Guantes de acechabestias
226722	Botas de acechabestias
226723	Guerrera de acechabestias
226724	Cinturón de magister
226725	Ataduras de magister
226726	Manto de magister
226727	Leotardos de magister
226728	Corona de magister
226729	Togas de magister
226730	Botas de magister
226731	Guantes de magister
226732	Cinturón Forjaluz
226733	Yelmo Forjaluz
226734	Coraza Forjaluz
226735	Bufas Forjaluz
226736	Quijotes Forjaluz
226737	Guanteletes Forjaluz
226738	Botas Forjaluz
226739	Brazales Forjaluz
226740	Guantes de devoto
226741	Manto de devoto
226742	Brazales de devoto
226743	Zapatos de devoto
226744	Cinturón de devoto
226745	Toga de devoto
226746	Corona de devoto
226747	Saya de devoto
226748	Guanteletes de elementos
226749	Jubón de elementos
226750	Falda de elementos
226751	Ataduras de elementos
226752	Botas de elementos
226753	Espaldares de elementos
226754	Cordón de elementos
226755	Almófar de elementos
226756	Manto calígine
226757	Toga calígine
226758	Guantes calígine
226759	Brazales calígine
226760	Leotardos calígine
226761	Cinturón calígine
226762	Máscara calígine
226763	Botas calígine
226764	Botas de valor
226765	Cinturón de valor
226766	Brazales de valor
226767	Quijotes de valor
226768	Bufas de valor
226769	Yelmo de valor
226770	Coraza de valor
226771	Guanteletes de valor
226772	Fajín cuoroferal
226773	Capucha cuoroferal
226774	Galochas cuoroferal
226775	Cubremuñecas cuoroferal
226776	Jubón cuoroferal
226777	Manos cuoroferal
226778	Bufas cuoroferal
226779	Falda cuoroferal
226780	Cordón cuoroferal
226781	Sandalias cuoroferal
226782	Ataduras cuoroferal
226783	Abrazo cuoroferal
226784	Guanteletes cuoroferal
226785	Manto cuoroferal
226786	Ornato cuoroferal
226787	Pantalones cuoroferal
226788	Braciles cuoroferal
226789	Faja cuoroferal
226790	Cubrehombros cuoroferal
226791	Calzas cuoroferal
226792	Gorro cuoroferal
226793	Puños cuoroferal
226794	Botos cuoroferal
226795	Guerrera cuoroferal
226796	Guardamuñecas cuoroferal
226797	Guardarrenes cuoroferal
226798	Espaldares cuoroferal
226799	Musleras cuoroferal
226801	Visera cuoroferal
226802	Mandiletes cuoroferal
226803	Botines cuoroferal
226804	Armadura cuoroferal
226815	Muñequeras cuoroferal
226816	Cintura cuoroferal
226817	Sobrehombros cuoroferal
226818	Piernas cuoroferal
226819	Yelmo cuoroferal
226820	Guantes cuoroferal
226821	Botas cuoroferal
226822	Peto cuoroferal
226825	Guerrera Mantoscuro
226826	Bufas Mantoscuro
226827	Pantalones Mantoscuro
226828	Mandiletes Mantoscuro
226829	Almófar Mantoscuro
226830	Brazales Mantoscuro
226831	Escarpines Mantoscuro
226832	Cinturón Mantoscuro
226835	Guardamuñecas Mantoscuro
226836	Guardarrenes Mantoscuro
226837	Espaldares Mantoscuro
226838	Musleras Mantoscuro
226840	Manoplas Mantoscuro
226841	Visera Mantoscuro
226842	Botines Mantoscuro
226843	Armadura Mantoscuro
226845	Muñequeras Mantoscuro
226846	Cintura Mantoscuro
226847	Sobrehombros Mantoscuro
226848	Grebas Mantoscuro
226849	Yelmo Mantoscuro
226850	Guantes Mantoscuro
226851	Botas Mantoscuro
226852	Peto Mantoscuro
226856	Acelerante de flotabilidad guiada
226857	Botas de batalla de heroísmo
226858	Bufas de heroísmo
226859	Quijotes de heroísmo
226860	Corona de heroísmo
226861	Guanteletes de heroísmo
226862	Coraza de heroísmo
226863	Brazales de heroísmo
226864	Cinturón de heroísmo
226865	Guardamuñecas de heroísmo
226866	Guardarrenes de heroísmo
226867	Espaldares de heroísmo
226868	Musleras de heroísmo
226869	Visera de heroísmo
226870	Manoplas de heroísmo
226871	Escarpes de heroísmo
226872	Coselete de heroísmo
226873	Muñequeras de heroísmo
226874	Cintura de heroísmo
226875	Sobrehombros de heroísmo
226876	pantalones de heroísmo
226877	Yelmo de heroísmo
226878	Guantes de heroísmo
226879	Botas de heroísmo
226880	Peto de heroísmo
226881	Botines de maestro de bestias
226882	Pantalones de maestro de bestias
226883	Guanteletes de maestro de bestias
226884	Manto de maestro de bestias
226885	Ataduras de maestro de bestias
226886	Guerrera de maestro de bestias
226887	Almete de maestro de bestias
226888	Cinturón de maestro de bestias
226889	Brazales de maestro de bestias
226890	Ajustador de maestro de bestias
226891	Espaldares de maestro de bestias
226892	Leotardos de maestro de bestias
226893	Almófar de maestro de bestias
226894	Puños de maestro de bestias
226895	Grebas de maestro de bestias
226896	Cadena de maestro de bestias
226897	Muñequeras de maestro de bestias
226898	Cintura de maestro de bestias
226899	Sobrehombros de maestro de bestias
226900	pantalones de maestro de bestias
226901	Yelmo de maestro de bestias
226902	Guantes de maestro de bestias
226903	Botas de maestro de bestias
226904	Peto de maestro de bestias
226905	Cinturón Brumamorta
226906	Toga Brumamorta
226907	Brazales Brumamorta
226908	Botas Brumamorta
226909	Máscara Brumamorta
226910	Leotardos Brumamorta
226911	Guantes Brumamorta
226912	Manto Brumamorta
226913	Ataduras Brumamorta
226914	Cordón Brumamorta
226915	Cubrehombros Brumamorta
226916	Pantalones Brumamorta
226917	Capucha Brumamorta
226918	Garras Brumamorta
226919	Botines Brumamorta
226920	Abrazo Brumamorta
226921	Muñequeras Brumamorta
226922	Cintura Brumamorta
226923	Sobrehombros Brumamorta
226924	pantalones Brumamorta
226925	Yelmo Brumamorta
226926	Guantes Brumamorta
226927	Botas Brumamorta
226928	Peto Brumamorta
226929	Ataduras de hechicero
226930	Guanteletes de hechicero
226931	Sandalias de hechicero
226932	Togas de hechicero
226933	Leotardos de hechicero
226934	Cinturón de hechicero
226935	Corona de hechicero
226936	Manto de hechicero
226937	Muñequeras de hechicero
226938	Cintura de hechicero
226939	Sobrehombros de hechicero
226940	pantalones de hechicero
226941	Yelmo de hechicero
226942	Guantes de hechicero
226943	Botas de hechicero
226944	Peto de hechicero
226945	Toga del virtuoso
226946	Saya del virtuoso
226947	Corona del virtuoso
226948	Cinturón del virtuoso
226949	Brazales del virtuoso
226950	Mitones del virtuoso
226951	Manto del virtuoso
226952	Zapatos del virtuoso
226953	Cubremuñecas del virtuoso
226954	Cordón del virtuoso
226955	Cubrehombros del virtuoso
226956	Leotardos del virtuoso
226957	Capucha del virtuoso
226958	Manos del virtuoso
226959	Zapatillas del virtuoso
226960	Toga del virtuoso
226961	Muñequeras del virtuoso
226962	Cintura del virtuoso
226963	Sobrehombros del virtuoso
226964	pantalones del virtuoso
226965	Yelmo del virtuoso
226966	Guantes del virtuoso
226967	Botas del virtuoso
226968	Peto del virtuoso
226969	Bufas Forjaalma
226970	Brazales Forjaalma
226971	Cinturón Forjaalma
226972	Quijotes Forjaalma
226973	Coraza Forjaalma
226974	Botas de guerra Forjaalma
226975	Guanteletes Forjaalma
226976	Gran yelmo Forjaalma
226977	Ataduras Forjaalma
226978	Cordón Forjaalma
226979	Cubrehombros Forjaalma
226980	Leotardos Forjaalma
226981	Corona Forjaalma
226982	Puños Forjaalma
226983	Botines Forjaalma
226984	Abrazo Forjaalma
226985	Guardamuñecas Forjaalma
226986	Guardarrenes Forjaalma
226987	Espaldares Forjaalma
226988	Musleras Forjaalma
226989	Visera Forjaalma
226990	Manoplas Forjaalma
226991	Escarpes Forjaalma
226992	Coselete Forjaalma
226993	Muñequeras Forjaalma
226994	Cintura Forjaalma
226995	Sobrehombros Forjaalma
226996	pantalones Forjaalma
226997	Yelmo Forjaalma
226998	Guantes Forjaalma
226999	Botas Forjaalma
227000	Peto Forjaalma
227001	Ataduras de los Cinco Truenos
227002	Almófar de los Cinco Truenos
227003	Espaldares de los Cinco Truenos
227004	Jubón de los Cinco Truenos
227005	Falda de los Cinco Truenos
227006	Guanteletes de los Cinco Truenos
227007	Zapatillas de los Cinco Truenos
227008	Cordón de los Cinco Truenos
227009	Brazales de los Cinco Truenos
227010	Fajín de los Cinco Truenos
227011	Manto de los Cinco Truenos
227012	Leotardos de los Cinco Truenos
227013	Corona de los Cinco Truenos
227014	Agarres de los Cinco Truenos
227015	Grebas de los Cinco Truenos
227016	Guerrera de los Cinco Truenos
227017	Braciles de los Cinco Truenos
227018	Faja de los Cinco Truenos
227019	Bufas de los Cinco Truenos
227020	Quijotes de los Cinco Truenos
227021	Rostro de los Cinco Truenos
227022	Puños de los Cinco Truenos
227023	Botines de los Cinco Truenos
227024	Cadena de los Cinco Truenos
227025	Guardamuñecas de los Cinco Truenos
227026	Guardarrenes de los Cinco Truenos
227027	Guardahombros de los Cinco Truenos
227028	Musleras de los Cinco Truenos
227029	Celada de los Cinco Truenos
227030	Manoplas de los Cinco Truenos
227031	Escarpes de los Cinco Truenos
227032	Coselete de los Cinco Truenos
227033	Muñequeras de los Cinco Truenos
227034	Cintura de los Cinco Truenos
227035	Sobrehombros de los Cinco Truenos
227036	pantalones de los Cinco Truenos
227037	Yelmo de los Cinco Truenos
227038	Guantes de los Cinco Truenos
227039	Botas de los Cinco Truenos
227040	Peto de los Cinco Truenos
227041	Escalpelo de Sombras de la Plaga
227042	Sobrehombros de placas de Campeón
227043	Yelmo de placas de Campeón
227044	Yelmo de placas de Teniente coronel
227045	Sobrehombros de placas de Teniente coronel
227046	Camisote de placas de Capitán caballero
227047	Leotardos de placas de Capitán caballero
227048	Leotardos de placas de Legionario
227049	Camisote de placas de Legionario
227050	Guanteletes de placas de Guardia de sangre
227051	Grebas de placas de Guardia de sangre
227052	Grebas de placas de Teniente caballero
227053	Guanteletes de placas de Teniente caballero
227054	Sobrehombros de cuero de Teniente coronel
227055	Yelmo de cuero de Teniente coronel
227056	Sobrehombros de cuero de Campeón
227057	Yelmo de cuero de Campeón
227058	Pechera de cuero de Capitán caballero
227059	Musleras de cuero de Legionario
227060	Pechera de cuero de Legionario
227061	Musleras de cuero de Capitán caballero
227062	Botos de cuero de Guardia de sangre
227063	Mandiletes de cuero de Guardia de sangre
227064	Botos de cuero de Teniente caballero
227065	Mandiletes de cuero de Teniente caballero
227066	Yelmo de anillas de Teniente coronel
227067	Yelmo de anillas de Campeón
227068	Sobrehombros de anillas de Teniente coronel
227069	Sobrehombros de anillas de Campeón
227070	Camisote de anillas de Capitán caballero
227071	Camisote de anillas de Legionario
227072	Musleras de anillas de Capitán caballero
227073	Musleras de anillas de Legionario
227074	Grebas de anillas de Guardia de sangre
227075	Abrazadera de anillas de Guardia de sangre
227076	Grebas de anillas de Teniente caballero
227077	Abrazaderas de anillas de Teniente caballero
227078	Espaldares de anillas de Campeón
227079	Quijotes de anillas de Legionario
227080	Gran yelmo de anillas de Campeón
227081	Mandiletes de anillas de Guardia de sangre
227082	Escarpes de anillas de Guardia de sangre
227083	Armadura de anillas de Legionario
227084	Espaldares de anillas de Teniente coronel
227085	Quijotes de anillas de Capitán caballero
227086	Gran yelmo de anillas de Teniente coronel
227087	Mandiletes de anillas de Teniente caballero
227088	Escarpes de anillas de Teniente caballero
227089	Armadura de anillas de Capitán caballero
227090	Capucha de tejido de tinieblas de Campeón
227091	Bufas de tejido de tinieblas de Teniente coronel
227092	Bufas de tejido de tinieblas de Campeón
227093	Capucha de tejido de tinieblas de Teniente coronel
227094	Túnica de tejido de tinieblas de Legionario
227095	Musleras de tejido de tinieblas de Capitán caballero
227096	Túnica de tejido de tinieblas de Capitán caballero
227097	Musleras de tejido de tinieblas de Legionario
227098	Botos de tejido de tinieblas de Guardia de sangre
227099	Manijas de tejido de tinieblas de Guardia de sangre
227100	Manijas de tejido de tinieblas de Teniente caballero
227101	Botos de tejido de tinieblas de Teniente caballero
227102	Manto de seda de Teniente coronel
227103	Capucha de seda de Teniente coronel
227104	Manto de seda de Campeón
227105	Capucha de seda de Campeón
227106	Túnica de seda de Legionario
227107	Musleras de seda de Legionario
227108	Túnica de seda de Capitán caballero
227109	Musleras de seda de Capitán caballero
227110	Botos de seda de Guardia de sangre
227111	Manijas de seda de Guardia de sangre
227112	Botos de seda de Teniente caballero
227113	Manijas de seda de Teniente caballero
227114	Guanteletes de seda de Teniente caballero
227115	Guanteletes de seda de Guardia de sangre
227116	Guantes de seda de Teniente caballero
227117	Guantes de seda de Guardia de sangre
227118	Caperuza de satén de Campeón
227119	Manto de satén de Teniente coronel
227120	Manto de satén de Campeón
227121	Caperuza de satén de Teniente coronel
227122	Túnica de satén de Capitán caballero
227123	Musleras de satén de Legionario
227124	Túnica de satén de Legionario
227125	Musleras de satén de Capitán caballero
227126	Manijas de satén de Guardia de sangre
227127	Botos de satén de Guardia de sangre
227128	Manijas de satén de Teniente caballero
227129	Botos de satén de Teniente caballero
227130	Cubrehombros de satén de Campeón
227131	Leotardos de satén de Legionario
227132	Corona de satén de Campeón
227133	Mandiletes de satén de Guardia de sangre
227134	Botines de satén de Guardia de sangre
227135	Toga de satén de Legionario
227136	Cubrehombros de satén de Teniente coronel
227137	Leotardos de satén de Capitán caballero
227138	Corona de satén de Teniente coronel
227139	Mandiletes de satén de Teniente caballero
227140	Botines de satén de Teniente caballero
227141	Toga de satén de Capitán caballero
227142	Coraza de láminas de Capitán caballero
227143	Leotardos de láminas de Capitán caballero
227144	Protegecabezas de láminas de Teniente coronel
227145	Sobrehombros de láminas de Teniente coronel
227146	Escarpes de láminas de Teniente caballero
227147	Guanteletes de láminas de Teniente caballero
227148	Espaldares de láminas de Teniente coronel
227149	Yelmo de láminas de Teniente coronel
227150	Musleras de láminas de Capitán caballero
227151	Peto de láminas de Capitán caballero
227152	Guantes de láminas de Teniente caballero
227153	Grebas de láminas de Teniente caballero
227154	Espaldares de malla de Campeón
227155	Protegecabezas de malla de Campeón
227156	Musleras de malla de Legionario
227157	Camisote de malla de Legionario
227158	Grebas de malla de Guardia de sangre
227159	Abrazadera de malla de Guardia de sangre
227160	Bufas de malla de Campeón
227161	Leotardos de malla de Legionario
227162	Yelmo de malla de Campeón
227163	Guanteletes de malla de Guardia de sangre
227164	Escarpes de malla de Guardia de Sangre
227165	Coraza de malla de Legionario
227166	Cubrehombros de malla de Campeón
227167	Pantalones de malla de Legionario
227168	Capacete de malla de Campeón
227169	Guantes de malla de Guardia de sangre
227170	Botas de malla de Guardia de sangre
227171	Coselete de malla de Legionario
227172	Sobrehombros de pellejo de dragón de Teniente coronel
227173	Protegecabezas de pellejo de dragón de Teniente coronel
227174	Protegecabezas de pellejo de dragón de Campeón
227175	Sobrehombros de pellejo de dragón de Campeón
227176	Pechera de pellejo de dragón de Capitán caballero
227177	Leotardos de pellejo de dragón de Legionario
227178	Leotardos de pellejo de dragón de Capitán caballero
227179	Pechera de pellejo de dragón de Legionario
227180	Mandiletes de pellejo de dragón de Guardia de sangre
227181	Botines de pellejo de dragón de Guardia de sangre
227182	Botines de pellejo de dragón de Teniente caballero
227183	Mandiletes de pellejo de dragón de Teniente caballero
227184	Bufas de pellejo de dragón de Campeón
227185	Pantalones de pellejo de dragón de Legionario
227186	Yelmo de pellejo de dragón de Campeón
227187	Guantes de pellejo de dragón de Guardia de sangre
227188	Botas de pellejo de dragón de Guardia de sangre
227189	Armadura de pellejo de dragón de Legionario
227190	Bufas de pellejo de dragón de Teniente coronel
227191	Pantalones de pellejo de dragón de Capitán caballero
227192	Yelmo de pellejo de dragón de Teniente coronel
227193	Guantes de pellejo de dragón de Teniente caballero
227194	Botas de pellejo de dragón de Teniente caballero
227195	Armadura de pellejo de dragón de Capitán caballero
227196	Guerrera de pellejo de dragón de Capitán caballero
227197	Grebas de pellejo de dragón de Teniente caballero
227198	Guanteletes de pellejo de dragón de Teniente caballero
227199	Ornato de pellejo de dragón de Teniente coronel
227200	Musleras de pellejo de dragón de Capitán caballero
227201	Espaldares de pellejo de dragón de Teniente coronel
227202	Guerrera de pellejo de dragón de Legionario
227203	Grebas de pellejo de dragón de Guardia de sangre
227204	Guanteletes de pellejo de dragón de Guardia de sangre
227205	Ornato de pellejo de dragón de Campeón
227206	Musleras de pellejo de dragón de Legionario
227207	Espaldares de pellejo de dragón de Campeón
227279	Sortija del magister
227280	Arte de las sombras
227282	Anillo de la bruma temible
227284	Sortija de la bestia
227285	Dinámica estructural del flujo
227286	Ron Rumsey caliente con nata
227337	Conjunto de guantes y cinturón felinos
227338	Conjunto de guantes y cinturón astrales
227339	Conjunto de guantes y cinturón de guardián
227340	Conjunto de guantes y cinturón de ensalmador
227341	Conjunto de guantes y cinturón de perseguidor
227342	Conjunto de guantes y cinturón de merodeador
227343	Conjunto de guantes y cinturón clementes
227344	Conjunto de guantes y cinturón radiantes
227345	Conjunto de guantes y cinturón de voluntad divina
227346	Conjunto de guantes y cinturón del alba
227347	Conjunto de guantes y cinturón del crepúsculo
227348	Conjunto de guantes y cinturón de emoción
227349	Conjunto de guantes y cinturón de batalla
227350	Conjunto de guantes y cinturón de alivio
227351	Conjunto de guantes y cinturón de erupción
227352	Conjunto de guantes y cinturón de impacto
227353	Conjunto de guantes y cinturón de determinación
227354	Conjunto de guantes y cinturón corruptos
227355	Conjunto de guantes y cinturón perversos
227356	Conjunto de guantes y cinturón inamovibles
227357	Conjunto de guantes y cinturón imparables
227359	Conjunto de botas, pantalones y sobrehombros felinos
227360	Conjunto de botas, pantalones y sobrehombros astrales
227361	Conjunto de botas, pantalones y sobrehombros de guardián
227365	Conjunto de botas, pantalones y sobrehombros de ensalmador
227366	Conjunto de botas, pantalones y sobrehombros de perseguidor
227367	Conjunto de botas, pantalones y sobrehombros de merodeador
227368	Conjunto de botas, pantalones y sobrehombros clementes
227369	Conjunto de botas, pantalones y sobrehombros radiantes
227370	Conjunto de botas, pantalones y sobrehombros de voluntad divina
227371	Conjunto de botas, pantalones y sobrehombros del alba
227372	Conjunto de botas, pantalones y sobrehombros del crepúsculo
227373	Conjunto de botas, pantalones y sobrehombros de emoción
227374	Conjunto de botas, pantalones y sobrehombros de batalla
227375	Conjunto de botas, pantalones y sobrehombros de alivio
227376	Conjunto de botas, pantalones y sobrehombros de erupción
227377	Conjunto de botas, pantalones y sobrehombros de impacto
227378	Conjunto de botas, pantalones y sobrehombros de determinación
227379	Conjunto de botas, pantalones y sobrehombros corruptos
227380	Conjunto de botas, pantalones y sobrehombros perversos
227381	Conjunto de botas, pantalones y sobrehombros inamovibles
227382	Conjunto de botas, pantalones y sobrehombros imparables
227383	Conjunto de yelmo y pechera felinos
227384	Conjunto de yelmo y pechera astrales
227385	Conjunto de yelmo y pechera de guardián
227387	Conjunto de yelmo y pechera de ensalmador
227388	Conjunto de yelmo y pechera de perseguidor
227389	Conjunto de yelmo y pechera de merodeador
227390	Conjunto de yelmo y pechera clementes
227391	Conjunto de yelmo y pechera radiantes
227392	Conjunto de yelmo y pechera de voluntad divina
227393	Conjunto de yelmo y pechera del alba
227394	Conjunto de yelmo y pechera del crepúsculo
227395	Conjunto de yelmo y pechera de emoción
227396	Conjunto de yelmo y pechera de batalla
227397	Conjunto de yelmo y pechera de alivio
227398	Conjunto de yelmo y pechera de erupción
227399	Conjunto de yelmo y pechera de impacto
227400	Conjunto de yelmo y pechera de determinación
227401	Conjunto de yelmo y pechera corruptos
227402	Conjunto de yelmo y pechera perversos
227403	Conjunto de yelmo y pechera inamovibles
227404	Conjunto de yelmo y pechera imparables
227444	Ídolo de la cazadora
227451	Sigilo de envío
227454	Aro de la marea
227455	Brisa del mar
227456	Runa de la tempestad carmesí
227530	Cinturón incandescente
227531	Ataduras incandescentes
227532	Capucha incandescente
227533	Guantes incandescentes
227534	Leotardos incandescentes
227535	Toga incandescente
227536	Botas incandescentes
227537	Hombreras incandescentes
227549	Pedazo de papiro
227552	Papiro desgarrado
227658	Nota de los Sombra Jurada
227683	Sulfuras, Mano de Ragnaros
227684	Martillo de Sulfuron
227685	Escalpelo de las Sombras modificado
227686	Martillo de guerra ornamentado
227687	Diente de oro favorito de Orthas
227688	Aullavísceras
227689	Armadura de placas parcialmente digerida
227690	Piedra rúnica necrótica
227691	Hoja de Hanna
227724	Mención honorífica manchada de sangre
227727	Diseño: martillo de Sulfuron
227728	Ojo de Sulfuras
227730	Contrato de la Hermandad del Torio
227743	Núcleo de poder obsidiano
227745	Reliquia familiar
227746	Runa del Árbol del Mundo
227747	Registros familiares
227748	Diario de superviviente
227749	Runa de la estrella fugaz
227750	Ataduras de escamas al rojo vivo
227751	Cinturón de escamas al rojo vivo
227752	Sobrehombros de escamas al rojo vivo
227754	Leotardos de escamas al rojo vivo
227755	Yelmo de escamas al rojo vivo
227756	Guantes de escamas al rojo vivo
227757	Botas de escamas al rojo vivo
227758	Torso de escamas al rojo vivo
227759	Guantes de núcleo agostado
227760	Ataduras de núcleo agostado
227761	Cinturón de núcleo agostado
227762	Hombreras de núcleo agostado
227763	Leotardos de núcleo agostado
227764	Yelmo de núcleo agostado
227765	Botas de núcleo agostado
227766	Torso de núcleo agostado
227767	Montón de piedras de llamas
227768	Zumo onírico
227796	Pergamino darnassiano misterioso
227797	Pergamino darnassiano descifrado
227801	Ascuas de las Tierras de Fuego
227802	Monstruo: antorcha
227803	Arnés de oso de guerra temible
227804	Prendas de lana de oso de guerra temible
227805	Ferocidad de los Fauces de Madera
227807	Cinturón Fauces de Madera tupido
227808	Manto de los Fauces de Madera curtido
227809	Guantes de cuero Fauces de Madera tachonados
227810	Botas Fauces de Madera tupidas
227811	Defensor de los Fauces de Madera
227812	Faltriquera de medicinas fúrbolg
227813	Agua bendita de Stratholme potable
227814	Faja del alba radiante
227815	Botines del alba magníficos
227816	Botas de élite Argenta
227817	Guantes del alba radiantes
227818	Manto del alba resplandeciente
227819	Manto del alba flamígero bendito
227820	Brazales Hierro Negro templados
227821	Yelmo de arrabio besado por las llamas
227822	Botas de can del Núcleo gruesas
227823	Guantes Bengala del Núcleo magníficos
227824	Yelmo Hierro Negro templado
227825	Destructora Hierro Negro de magma
227826	Espetadora de llamas Hierro Negro
227827	Faja de anillas de magma
227828	Cinturón del corredor de lava
227829	Botas de escamas de dragón negro endurecidas
227830	Manto Bengala del Núcleo magnífico
227831	Toga Bengala del Núcleo magnífica
227832	Amnistía negra templada
227833	Guja de furia obsidiana
227834	Sobrehombros de cadena de magma
227835	Guanteletes Hierro Negro templados
227836	Leotardos Hierro Negro templados
227837	Cinturón de can del Núcleo grueso
227838	Guanteletes cromáticos brillantes
227839	Leotardos Bengala del Núcleo magníficos
227840	Guardanegra implacable
227841	Botas Hierro Negro templadas
227842	Puño de ébano
227843	Ocaso desgarrador
227844	Bolsa de paño rúnico reforzada de cuero
227845	Segadora de arcanita refinada
227847	Leotardos de núcleo demoníaco
227848	Guanteletes de núcleo demoníaco
227849	Rifle de tirador certero de núcleo ígneo
227850	Hoja sabia del archimago
227851	Coraza de escamas de dragón negro endurecida
227852	Leotardos de escamas de dragón negro endurecidos
227853	Sobrehombros de escamas de dragón negro endurecidos
227854	Capa cambiante magistral
227857	Profanación
227858	Martillo de los dioses salvajes
227859	Sobrehombros Albar fulgurantes
227860	Jubón de tela lunar incandescente
227861	Toga de tela lunar incandescente
227862	Botas de tela lunar incandescente
227863	Aro de tela lunar incandescente
227864	Leotardos de tela lunar incandescente
227865	Guanteletes de placas ígneas de la técnica oculta
227866	Sobrehombros volcánicos magistrales
227867	Leotardos volcánicos magistrales
227868	Coraza volcánica magistral
227869	Capa cromática brillante
227870	Guanteletes de tempestad
227871	Placa Hierro Negro templada
227872	Cimera del gran jefe
227873	Sobrehombros de escamas de dragón azul pulidos
227874	Leotardos de escamas de dragón azul pulidos
227875	Coraza de escamas de dragón azul pulida
227876	Malla invencible
227877	Leotardos de escamas de dragón verde vivientes
227878	Guanteletes de escamas de dragón verde vivientes
227879	Coraza de escamas de dragón verde viviente
227880	Martillo de batalla encantado con pericia
227881	Tranquilidad
227882	Faja de perspicacia Arcana
227883	Avambrazos de vuelo presto
227884	Buscacorazones letal
227885	Guanteletes de bastión recios
227886	Martillo de tormenta magistral de jinete celeste
227887	Guardia de Escarcha endurecida
227888	Sobrehombros de élite Argenta
227895	Patrón: manto del alba dorado
227896	Patrón: botas Argenta
227897	Patrón: sobrehombros Argenta
227898	Patrón: coraza de escamas de dragón azul pulida
227899	Patrón: sobrehombros de escamas de dragón azul pulidos
227900	Patrón: leotardos de escamas de dragón verde vivientes
227901	Diseño: placa Hierro Negro templada
227902	Patrón: coraza de escamas de dragón negro endurecida
227903	Patrón: leotardos de escamas de dragón negro endurecidos
227904	Patrón: sobrehombros de escamas de dragón negro endurecidos
227905	Diseño: martillo de tormenta magistral de jinete celeste
227906	Patrón: coraza volcánica magistral
227907	Patrón: sobrehombros volcánicos magistrales
227908	Patrón: leotardos volcánicos magistrales
227909	Diseño: guanteletes de placas ígneas de la técnica oculta
227910	Patrón: capa cromática brillante
227911	Cabeza de Rend Puño Negro
227912	Divinidad aplicada
227914	Glándula pineal de lechubestia
227915	Dominio del duque
227921	Runa de cuchillos
227922	Runa del espadachín
227923	Botines acuáticos
227924	Frasco poco corriente
227925	Baliza de Hydraxis
227926	Coronación de Hydraxis
227927	Juramento del mar
227928	Llave de caja de herramientas
227930	Llave de caja fuerte
227931	Fardo oculto
227932	Palanca oxidada
227934	Cólera de llamas
227935	Martillo de señor feudal caído
227936	Anillo diplomático
227937	Caja de puzles
227938	Esquirla de Luz
227939	Esquirla de Luz
227940	Espada de lord General
227941	Guadaña de ánima
227947	Espaldares a medida de gólem
227948	Hacha de batalla de Forjainquina
227952	Cota de malla de Gladiador indómito
227955	Yelmo de Gladiador indómito
227956	Coraza de mortífero
227957	Grebas de Gladiador indómito
227958	Embozo fantasmal
227959	Quijotes del Guardián eterno
227960	Gigante impermeable
227961	Mandiletes de Gladiador indómito
227962	Erupción de espinas
227963	Hoja con grabados de sangre
227964	Falda luminaria
227965	Botas omnitiro
227967	Segundo aliento
227970	Manteo de la salamandra de fuego
227971	Puños de arrabio
227972	Ráfaga de conocimiento
227973	Círculo de la llama
227974	Martillo de piedra de lava
227978	Piedra Magmus
227980	Togas de la corona real
227981	Vengador Forjaterrible
227982	Báculo de sabiduría orientadora
227983	Sello Hierro Negro
227984	Cetro real de Thaurissan
227985	El nuevo manteo del emperador
227986	Guardamuñecas de renombre
227987	Fajín de la Gran cacería
227988	Joya imperial
227990	Mano de la Injusticia
227991	Ferromazo
227992	Escarpes de caballero de la Muerte
227993	Empuñadura de ébano de Marduk
227994	Bastón de Calamiedo
227996	Arco de hueso antiguo
227997	Espada de la familia Barovia
227998	Botas Mallasangre
227999	Escarpes de hueso de muerto
228000	Peto de hueso de muerto
228001	Sobrehombros con forma de piedra
228002	Faja de hueso de muerto
228003	Musleras Mallasangre
228004	Grebas Atracavientos
228005	Garra de Andros
228006	Guanteletes de hueso de muerto
228007	Rebanadores de gárgolas
228008	Musleras de hueso de muerto
228009	Botas necrópilas
228010	Manto necrópilo
228011	Puños necrópilos
228012	Camisote Mallasangre
228013	Toga necrópila
228014	Cinturón Mallasangre
228015	Garfa de miedo
228016	Anillo opalescente oscuro
228017	Pantalones Humo de calavera
228018	Leotardos necrópilos
228019	Corazón del maligno
228020	Guanteletes Mallasangre
228021	Espada de bruja
228022	Carga de rector
228023	Abrazo de Alanna
228024	Colmillo silencioso
228025	Coraza de lápida
228026	Hoja del Bosque Negro
228027	Rebanadora de hoja de hielo
228028	Hoja de nigromancia
228029	Hacha de guerra de lápida
228030	Hacha maliciosa
228031	Guantes Sombraoscura
228032	Yelmo de anillos de hueso
228033	Martillo de poderío divino
228034	Manijas escalofrío
228036	Garra de la Muerte
228037	Rodela armadósea
228038	Pantalones de tejido de hierro
228039	Escrito vinculado
228040	Leotardos de fantasma
228041	Leotardos de placas de ánima
228042	Cinta de detención
228044	Leotardos de la Vorágine
228045	Sortija nigromántica
228046	Sortija de dominación de Don Mauricio
228047	Sortija de amalgama
228050	Arco de sátiro
228051	Vara de canalización Quel'dorei
228052	Cortaolas
228053	Yelmo ferviente
228054	Dije de tempestad
228055	Peto energizado
228056	Machete endemoniado
228057	Anillo de potencia demoníaca
228058	Bufas de hierro grandes
228059	Sobrehombros de vigía de cubil
228060	Capa de heliotropo
228061	Guantes Chispa brillante
228062	Caperuza de perspicacia
228063	Cinto Tuercemadera
228064	Escudo de observador
228065	Bufas de ciclón
228066	Guantes de tejido de hierro
228067	Colgante de mago anciano
228068	Cinturón de Jarrager
228069	Quijotes reforzados de Eldritch
228070	Camisote forjado de ogro
228074	Manoplas de la tentación
228075	Lanza del destino
228076	Anillo ardiente de fuego
228077	Ramaoniria
228078	Cáliz maldito
228079	Capa de hojas
228080	Aro de resina
228081	Semilla venenosa germinante
228082	Hacha Grito de Guerra
228083	Corazón de árbol resplandeciente
228084	Extintor en miniatura
228085	Sortija de la Legión desfasada
228086	Sierra de trituradora modificada
228087	Moebius de plata supercargado
228088	Chapas de operario de trituradora
228089	Acechalunas tallado en madera
228090	Daga ritual Cenarion
228091	Botas con espinas
228092	Manto druídico
228093	Corazón oscuro de la oscuridad
228094	Hoja del Señor del Terror
228100	Mantón del Señor del Fuego
228101	Pellejo de behemoth
228102	Mantón de mayordomo
228103	Grebas de los Nathrezim
228104	Togas de Elune
228105	Núcleo de llamas perpetuas
228106	Escudo de vida y muerte
228107	Arco largo de la cazadora caída
228108	Sombra de Aullavísceras
228109	Musleras de sacrificio
228111	Máscara del destripadioses
228112	Toga de pesadilla
228113	Abrazo frío
228114	Diseño: segadora de arcanita refinada
228117	Diseño: campeona de arcanita refinada
228118	Diseño: guanteletes de bastión recios
228119	Patrón: guanteletes de núcleo demoníaco
228120	Patrón: leotardos de núcleo demoníaco
228121	Patrón: bolsa de paño rúnico reforzada de cuero
228122	El Núcleo de Magma
228123	Epifanía exultante
228124	Epifanía onírica
228125	Campeona de arcanita refinada
228126	Epifanía apetitosa
228127	Guardamuñecas de inestabilidad
228128	Martillo del Yunquenegro
228129	Cráneo de Pirosombra
228130	Resguardo altruista
228131	Resguardo altruista
228132	Patatas no-muertas
228133	¿Magma o lava?
228134	Guía completa del norte de Kalimdor
228135	Estudio de la Luz
228136	¡Ca-bum!
228137	Corazón de Golemagg
228138	El caballero y la doncella
228139	Puño de los jurafuegos
228140	La Plaga: ¿Amenaza no-muerta o incomprendida?
228141	Nigromancia para principiantes
228142	Tierra y Fuego
228143	Espada de Pirosombra
228144	Nota extraña
228145	Garra derecha de Magmadar
228146	Garra izquierda de Magmadar
228147	Cuerno de Magmadar
228160	Portador de fe
228162	Engaño
228163	Broche de madre de linaje
228165	Jabalina de matadragones
228166	Llave de la ciudad
228168	Molinillo goblin
228169	Corrigeactitudes
228170	Remo improvisado de los Mares del Sur
228171	Monedero de Kezan
228172	Resguardo de ilusión diente oscuro
228173	Tratado del consagrado
228174	Tratado del devoto
228175	Tratado sobre prontitud sagrada
228176	Tótem de trueno
228177	Tótem de fuego embravecido
228178	Tótem de vitalidad terránea
228179	Tótem de las llanuras
228180	Ídolo del enjambre
228181	Ídolo de desangramiento (felino)
228182	Ídolo de desangramiento (oso)
228183	Ídolo de la arboleda
228184	Tendedero goblin
228185	Botella rota de goblino noir
228186	Alianza abandonada
228187	Palo de los Mares del Sur
228188	Horquilla de Prestor
228189	Ofrenda de Gob
228190	Conocimiento de los Fauces de Madera
228191	Mineral fundido fulgurante
228214	Monstruo - Maza de dos manos, Fuerza imparable
228222	Vademécum de Valor de Azeroth
228227	Scroll of Overwhelming Power
228229	Hoja afilada de obsidiana
228230	Martillo de los titanes refinado
228239	Toga de poder volátil
228240	Quijotes de Despiertallamas
228242	Anillo pesado de Hierro Negro
228243	Anillo de poder con hechizos
228244	Leotardos de tormenta de maná
228245	Pantalones de escamas de salamandra
228246	Guardamuñecas de Estabilidad
228247	Gargantilla de Iluminación
228248	Sacudetierra
228249	Medallón del poderío férreo
228250	Diseño: guanteletes de bastión recios
228251	Patrón: guanteletes de escamas de dragón verde vivientes
228252	Marca de asediador
228253	Escarpes del caminallamas
228254	Botas templadas de magma
228255	Dije de poder efímero
228256	Cordón de ignición de maná
228257	Guantes viejos de cuero del Núcleo
228258	Bufas del interior de la tierra
228259	Grimorio rúnico de Fuego
228260	Guanteletes de guardia de llamas
228261	Anillo de golpe rápido
228262	Aplastador carmesí
228263	Daga de hechicero
228264	Martillo de piedra de aura
228265	Hoja de brutalidad
228266	Disco de horadador
228267	Destripadora
228268	Sello del archimago
228269	Hoja mágica de cantoazur
228270	Lanzador tiroexplosión
228271	Bastón de dominancia
228272	Tenebrosa
228273	Tronadora
228274	Sortija de cauterización
228275	Grebas forjadas del Núcleo
228276	Patrón: capa cambiante magistral
228277	Diente de can del Núcleo
228278	Dragador de lava hipertérmicamente aislado
228279	Sobrehombros de guardia de fuego
228280	Capa a prueba de fuego
228281	Guantes de la llama hipnótica
228282	Fajín de los secretos susurrados
228283	Bufas de crecimiento salvaje
228284	Guardamuñecas de Auténtico Vuelo
228285	Yelmo del dador de vida
228286	Sortija de Accuria
228287	Sortija de Sulfuras
228288	Filo del espetahuesos
228289	Gargantilla del Señor del Fuego
228290	Capa de la niebla envolvente
228291	Corona de Destrucción
228292	Manteo de sangre de dragón
228293	Esencia de la llama pura
228294	Defensor de Malistar
228295	Faja de acometida
228296	Hoja de Perdición
228297	Fragmento de la Llama
228298	Fragmento de la Escama
228299	Segadora espinal
228301	Patrón: avambrazos de Vuelo presto
228303	Patrón: toga de tela lunar incandescente
228304	Esquema: rifle de tirador certero de núcleo ígneo
228305	Diseño: martillo de los titanes refinado
228306	Diseño: Profanación
228307	Diseño: buscacorazones letal
228308	Diseño: Tranquilidad
228309	Patrón: coraza de escamas de dragón verde viviente
228310	Diseño: guardia de Escarcha endurecida
228311	Diseño: martillo de batalla encantado con pericia
228312	Diseño: malla invencible
228313	Diseño: guanteletes de tempestad
228314	Diseño: cimera del gran jefe
228315	Diseño: hoja sabia del archimago
228316	Patrón: jubón de tela lunar incandescente
228317	Patrón: aro de tela lunar incandescente
228318	Patrón: leotardos de tela lunar incandescente
228319	Patrón: faja de perspicacia Arcana
228323	Moneda de carnicería de cobre
228324	Moneda de carnicería de oro
228325	Moneda de carnicería de plata
228326	Bolsa de monedas de carnicería de cobre
228327	Bolsa de monedas de carnicería de plata
228332	Lok'delar, báculo de los Guardianes ancianos
228334	Rhok'delar, arco largo de los Guardianes ancianos
228335	Oración
228336	Anatema
228340	Faja de hielo sin derretir
228345	Leotardos de Supremacía arcana
228347	Tifón
228349	Garra izquierda de Eskhandar
228350	Garra derecha de Eskhandar
228351	Guanteletes de pellejo maldito
228352	Leotardos imbuidos de vileza
228353	Jaula de cabeza infernal
228354	Medallón Furia abrasadora
228355	Cinturón de piel de guardia apocalíptico
228356	Guardián del Sello Ámbar
228357	Brazal de luz negra
228359	Anillo de Entropía
228360	Pelambre de Eskhandar
228381	Mordedura de frío
228382	Colmillo de los Místicos
228383	Manteo enjundioso
228384	Zapatos Velonieve
228385	Corona adornada con cristales
228389	Mantón de Oración
228397	Demoledor empíreo
228410	Hoja terrorífica del Destructor
228432	Silbato de la bestia
228459	Hoja afilada de obsidiana
228460	Segadora espinal
228461	Filo del espetahuesos
228462	Martillo de piedra de aura
228463	Sacudetierra
228464	Sello real de Eldre'Thalas
228465	Sello real de Eldre'Thalas
228466	Sello real de Eldre'Thalas
228467	Sello real de Eldre'Thalas
228468	Leotardos Mohomaraña
228469	Anillo élfico deslustrado
228470	Leotardos Lunargenta
228471	Machacapiedras
228472	Daga de distracción
228473	Gran maza implacable
228474	Toga de oleada de mente
228475	Manto diabólico
228476	Cinturón bordado del archimago
228477	Patrón: cinturón bordado del archimago
228478	Hoja atroz
228479	Leotardos de Destrucción
228480	Corona del Rey ogro
228484	Vara de los magi ogros
228486	Aterrantárboles
228498	Hoja terrorífica del Destructor
228500	Máscara del Imperdonable
228501	Blusa ruiseñor
228502	Flautín de la llama flameante
228503	Prendas de lana de juglar saltarín
228504	Faja arco iris
228505	Capa de tribunal real
228506	Hoja de brutalidad
228508	Martillo del Yunquenegro
228511	Hoja de Perdición
228513	Avambrazos del Sádico
228514	Galochas de Timmy
228515	Lazo de Grimagore
228516	Pacificador
228517	Hoja mágica de cantoazur
228518	Puños de magistrado
228519	Marca de asediador
228520	Manto de ladrón de almas
228521	Manijas con encaje enigmáticas
228522	Obús portátil de Willey
228523	Mensajero bola de cañón
228524	Sello de jefe de correos
228525	Guerrera de jefe de correos
228527	Calzas de jefe de correos
228528	Banda de jefe de correos
228529	Botines de jefe de correos
228530	Musleras de placas de quitina
228531	Fajín Thuzadin
228532	Brazal de Morlune
228533	Collar de conchas nacaradas
228534	Leotardos de can de peste
228535	Hachuela rebanadora de huesos
228536	Estrella de Mystaria
228537	Guanteletes draconianos
228538	Sello de Osahendido
228539	Libro de los Muertos
228540	Corona de Tiranía
228541	Ofrenda del magi élfico
228542	Espetadora Forjacráneos
228543	Hojarruna del Barón Osahendido
228544	Martillo del Gran Cruzado
228545	Yelmo del Gran Cruzado
228546	Embozo de Nathrezim
228547	Toga de tejido de hierro
228548	Cetro de Enfoque interminable
228551	Guerrera de la Media Luna
228552	Guanteletes de ardid
228553	Yelmo del Verdugo
228554	Guantes de piel de demonio
228555	Hoja fase
228556	Delantal de carnicero
228557	Botas de batalla Dardopresto
228558	Puños de funeral
228559	Cuervo negro
228561	Guanteletes de objetivo real
228562	Bufas con runas demoníacas
228563	Globo de D'sak
228564	Botas de vigía de torre ogro
228565	Anillo de mago
228566	Tiara de fuego de estrellas
228567	Faja de cincelador
228568	Guanteletes de Backus
228570	Puño de Omokk
228571	Torso del rey chamán
228572	Guardabrazos cuorobronce
228573	Escupeveneno
228574	Dije de evasión
228575	Brazales garraja
228576	Ojo de Telabrasada
228577	Guanteletes dorados
228578	Fajín pluma de polvo
228579	Faja cristalizada
228583	Sobrehombros Golpevero
228584	Dije Furia de ascuas
228585	Marca del Señor de los dragones
228586	Congeladora
228587	Bastón de refugio
228588	Garras de reiver
228589	Corazón de la escama
228590	Manto de hendevidente
228591	Protector Rhombeard
228592	Colmillo de la araña de cristal
228593	Botas de Bailavientos
228594	Botas de precisión de Kayser
228595	Faja de tirador
228596	Cinturón de tejido de hierro
228597	Botas de tejido de hierro
228598	Brazales de tejido de hierro
228599	Corazón de Vermisthalak
228600	El rompe mandíbulas
228601	Guadaña incansable
228602	Botos de llamas
228603	Sierra de fatalidad Puño Negro
228604	Ojo de Rend
228605	Sobrehombros de huesopúa
228606	Hojanegra de Shahram
228607	Monstruo - Espada de dos manos, básica
228615	Un tesoro de otro mundo
228650	Musleras de maestro de guerra
228651	Ajorcas Belinato
228652	Guardián tribal de Dal'Rend
228653	Carga sacra de Dal'Rend
228659	Báculo con grabados de runas antiguas
228660	Leotardos de maestro del acero
228661	Musleras de Tristam
228662	Guardabrazos de bruma negra
228663	Capa luna de sangre
228664	Manteo de Tejescarcha
228666	Sauce llorón
228667	Sortija tejedaño
228669	Diente de Gnarr
228670	Faja de Brigam
228672	Faja artesanal de maestro herrero
228675	Sortija de Reflexión
228676	Faja Ola feral
228677	Turbante de tejido de hechizos
228678	Emblema dracónico imbuido
228679	Quel'Serrar
228680	Compendio de matar dragones de Nostro
228681	Capucha de tejido de hierro
228682	Bastón de mando de Lord Valthalak
228683	Sortija rúnica de brujería
228684	Colgante de Celeridad
228685	Colgante de diente de Onyxia
228686	Dije de sangre de Onyxia
228687	Sello de matadragones
228688	Cabeza de Onyxia
228689	Cabeza de Onyxia
228690	La Luz y cómo alterarla
228691	Garona: Un Estudio sobre el Sigilo y la Traición.
228692	Códice de Defensa
228693	El libro de cocina del arcanista
228695	Una hoja élfica desafilada
228696	Hoja antigua caliente
228697	Espada antigua tratada
228699	Anillo de Astucia demoníaca
228700	Manto de tejido de hierro
228701	Diente de can del Núcleo
228702	Disco de horadador
228703	Zapatillas de piedrafría
228704	Caperuza de cuero andrajoso
228722	Mano de la Justicia
228746	Mecazancudo verde fosforito
228747	Riendas del dientes de sable dorado
228748	Silbato del raptor de sangre jaspeado
228749	Astilla de Nordrassil
228757	Daga vil
228759	Collera de Eskhandar
228797	Grimorio de Armadura vil
228912	Llave del depósito del artefacto
228922	Bastón de dominancia
228924	Botas Hierro Negro templadas
228925	Botas Hierro Negro templadas
228926	Botas Hierro Negro templadas
228927	Botas Hierro Negro templadas
228928	Botas Hierro Negro templadas
228929	Botas Hierro Negro templadas
228955	Grimorio Piedra angular antigua
228978	Sigilo encantado: Agua corriente
228979	Sigilo encantado: Agua corriente
228980	Revestimiento de escudo conductivo
228981	Fórmula: revestimiento de escudo conductivo
228982	Fórmula: encantar escudo: ley de la naturaleza
228992	Mochila de pellejo de Onyxia
228993	Patrón: bolsa sin fondo
228994	Bolsa sin fondo
229008	Fórmula: Encantar capa: Resistencia al Fuego superior
229009	Fórmula: Encantar capa: Resistencia a la Naturaleza superior
229055	Seda aranasi deshilachada
229056	Trozo de piedra pómez
229057	Artículos incautados
229352	Hallazgos de información
229362	Llave del almacén
229372	Destripadora
229373	Portador de fe
229374	Puño de los jurafuegos
229376	Daga de hechicero
229377	Garra izquierda de Magmadar
229378	Garra derecha de Magmadar
229379	Garra derecha de Eskhandar
229380	Tenebrosa
229381	Tronadora
229382	Dragador de lava hipertérmicamente aislado
229415	Suministros de supervivencia
229416	Pelaje cálido
229749	Portaverdad
229806	Portaverdad
229894	Esmeralda del Sueño
229897	Pergamino: Crear sello de señalización
229906	Escama bronce deslustrada
229909	Bastón de orden
229910	Guadaña del caos
229911	Comesueños de Caius
229964	Pezuña de señor demoníaco
229965	El ojo de Az'olgothal
229966	Torque de la Mano de Plata
229971	Bastón infernal
229972	Bastón de helada
230002	Remate mortal
230018	Fragmentos de orbe Mannoroc
230224	Trueno Furioso, Espada Bendita del Hijo del Viento
230237	Gema Arcana imbuida
230238	El libro negro
230239	Guantes de evolución rápida
230240	Manto del Conciliábulo Alanegra
230241	Machacacolumnas
230242	La espada indomable
230243	Gema de aceleración mental
230244	Sigilo de cambiaformas
230245	Colgante del dragón caído
230246	Yelmo de ira infinita
230247	Hoja colmillo dragón
230248	Protector de escamas de dragón rojo
230249	Gema dadora de vida
230250	Tótem venenoso
230251	Espaldares de linaje negro
230252	Brazales de precisión arcana
230253	Apuntacorazones
230254	Maladath, Hoja rúnica del Vuelo Negro
230255	Cinturón de pellejo de dragón tirante
230256	Espaldares de garfa de draco
230257	Anillo de Roca Negra
230269	Gema rejuvenecedora
230270	Bastón de enfoque de Alasombra
230271	Cuchilla de garfa de draco
230272	Pergaminos de Luz cegadora
230273	Cristal de alineación natural
230274	Toga de ceniza negra
230275	Garra de Faucefogo
230276	Garra del draco negro
230277	Capa de Faucefogo
230278	Musleras del cruzado caído
230279	Musleras enlazadas de primalista
230280	Égida de preservación
230281	Sortija de concentración forzada
230282	Dije de colmillo de draco
230723	Guantes de llamas de ébano
230725	Baluarte bendito de Malfurión
230726	Culebrina aliento de dragón
230733	Embozo de pensamiento puro
230734	Círculo de fuerza aplicada
230735	Leotardos de tejido de ascuas
230736	Escarabajo trabador de Styleen
230737	Toque de dragón
230738	Heraldo de tragedia
230739	Garra de Angelista
230740	Hombreras de pellejo de dragón tirante
230741	Botas cromáticas
230742	Guantes de pellejo de dragón tirante
230743	Geta fulgurante
230744	Capa tejida con elementium
230745	Faja del Cruzado caído
230746	Leotardos potenciados
230747	Espada templada cromáticamente
230751	Obi de ninja
230794	Garra de Chromaggus
230800	Guardarrenes enlazados de primalista
230801	Ashjre'thul, Ballesta de paliza
230802	Baluarte reforzado de elementium
230804	Capa del Señor del linaje
230805	Botas de la Llama de las Sombras
230806	Eslabón de Therazane
230808	Anillo de juicio de Archimtiros
230810	Lágrima de Neltharion
230811	Sortija de elementium puro
230812	Mish'undare, aro del despellejador de mentes
230813	Bastón de la Sombra en llamas
230818	Ashkandi, Espada magna de la Hermandad
230837	Crul'shorukh, Filo del Caos
230838	Lok'amir il Romathis
230839	Anillo de maestro matadragones
230840	Medallón de maestro matadragones
230841	Orbe de maestro matadragones
230842	Capa de poderío dracónico
230843	Botas de pensamiento puro
230844	Gran maza dracónica
230845	Filo de la fatalidad
230846	Sortija del Dominio oscuro
230847	Recolector de esencia
230848	Chaleco de las Sombras entrelazado
230849	Botas de ventisca de Ringo
230854	Sortija de servidumbre
230855	Sello de rabioso Gurubashi
230856	Cinturón de poder sin explotar
230857	Máscara empapada de sangre
230858	Capa de los adoradores Hakkari
230859	Guantes del Atormentado
230860	Poderío de la Tribu
230861	Guanteletes de sacrificio
230862	Ornato Zulian
230863	Cetro Zulian de ritos
230864	Camisote rúnico manchado de sangre
230865	Colmillo de Venoxis
230866	Escarpines empapados de sangre
230867	Sortija de Zanzil
230868	Hacha de piedra Zulian
230903	Pergamino: esencia de Fuego
230904	Pergamino: SEIENACS ED EGUFO
230908	Esencia de Fuego imbuida
230909	Esencia de Fuego agotada
230911	Triturador de Jeklik
230912	Bufas de animista
230913	Dije ópalo de Jeklik
230914	Botas de pacificador
230915	Sortija de primalista
230916	Botas de furia marina
230917	Togas de ritual sueltas
230918	Toque de Mar'li
230919	Grebas manchadas de sangre
230920	Ojo de Mar'li
230921	Sortija de Jin
230922	Dije de protección
230923	Botas de traidor
230925	Garra de Thekal
230926	Leotardos de pacificador
230927	Musleras de ritual
230928	Leotardos de furia marina
230929	Sello de Jin
230930	Cercenadora Zulian
230934	Garra de Arlokk
230939	Voluntad de Arlokk
230941	Palo hudú de Arlokk
230942	Grebas empapadas de sangre
230943	Sortija de ónice de Señor Supremo
230944	Saco de pellejo de pantera
230946	Pergamino: SEIENACS ED AHCSCAER
230947	Pergamino: esencia de Escarcha
230948	Esencia de Escarcha imbuida
230949	Esencia de Escarcha agotada
230984	Bastón de orden incompleto
230989	Defensor del Señor de la Sangre
230991	Alabarda de golpeo
230992	Hoja de guerra de los Hakkari
230993	Aguijón de Mandokir
230994	Leotardos de animista
230995	Mandiletes empapados de sangre
230996	Espaldares empapados de sangre
230997	Falda tintada de sangre
230998	Capa loa Hakkari
230999	Sortija carmesí de Señor Supremo
231000	Sello de primalista
231001	Sello de Zanzil
231002	Brujo de Jin'do
231003	Ojo maligno de Jin'do
231004	Sentencia de Jin'do
231005	Bolsa de mal agüero de Jin'do
231006	Botas de animista
231007	Almófar manchado de sangre
231008	Quijotes manchados de sangre
231009	Leotardos empapados de sangre
231010	Guanteletes empapados de sangre
231011	Guantes tintados de sangre
231012	Abrazo de Señor Supremo
231013	El casquete de aojador
231014	Parche de escamas de lagarto
231015	Máscara de sarga
231016	Ejecutor de pescado de Nat Pagle
231023	Guardamuñecas de Cólera
231024	Guardarrenes de Cólera
231025	Espaldares de Cólera
231026	Musleras de Cólera
231027	Visera de Cólera
231028	Manoplas de Cólera
231029	Escarpes de Cólera
231030	Coselete de Cólera
231031	Brazales de Cólera
231032	Cinturón de Cólera
231033	Sobrehombros de Cólera
231034	Quijotes de Cólera
231035	Yelmo de Cólera
231036	Guanteletes de Cólera
231037	Grebas de Cólera
231038	Coraza de Cólera
231039	Bufas Colmillo de sangre
231040	Pechera Colmillo de sangre
231041	Botas Colmillo de sangre
231042	Guantes Colmillo de sangre
231043	Caperuza Colmillo de sangre
231044	Pantalones Colmillo de sangre
231045	Cinturón Colmillo de sangre
231046	Brazales Colmillo de sangre
231047	Hombreras Colmillo de sangre
231048	Coselete Colmillo de sangre
231049	Escarpines Colmillo de sangre
231050	Manoplas Colmillo de sangre
231051	Capucha Colmillo de sangre
231052	Musleras Colmillo de sangre
231053	Guardarrenes Colmillo de sangre
231054	Guardamuñecas Colmillo de sangre
231055	Brazales de acechadragón
231056	Cinturón de acechadragón
231057	Bufas de acechadragón
231058	Musleras de acechadragón
231059	Yelmo de acechadragón
231060	Guanteletes de acechadragón
231061	Grebas de acechadragón
231062	Coraza de acechadragón
231063	Avambrazos de acechadragón
231065	Faja de acechadragón
231066	Espaldares de acechadragón
231067	Pantalones de acechadragón
231068	Capacete de acechadragón
231069	Mandiletes de acechadragón
231070	Escarpes de acechadragón
231071	Armadura de acechadragón
231072	Botas de némesis
231073	Guantes de némesis
231074	Capacete de némesis
231075	Leotardos de némesis
231076	Togas de némesis
231077	Bufas de némesis
231078	Cinturón de némesis
231079	Brazales de némesis
231090	Botines de némesis
231091	Manoplas de némesis
231092	Capucha de némesis
231093	Pantalones de némesis
231095	Atuendo de némesis
231096	Hombreras de némesis
231097	Cordón de némesis
231098	Brazaletes de némesis
231100	Cinturón viento abisal
231101	Botas viento abisal
231102	Guantes viento abisal
231103	Corona viento abisal
231104	Pantalones viento abisal
231105	Togas viento abisal
231106	Manto viento abisal
231107	Ataduras viento abisal
231108	Fajín viento abisal
231109	Zapatillas viento abisal
231110	Mitones viento abisal
231111	Máscara viento abisal
231112	Leotardos viento abisal
231113	Vestimentas viento abisal
231114	Sobrehombros viento abisal
231115	Brazaletes viento abisal
231155	Botas de trascendencia
231156	Manoplas de trascendencia
231157	Halo de trascendencia
231158	Leotardos de trascendencia
231159	Togas de trascendencia
231160	Espaldares de trascendencia
231161	Cinturón de trascendencia
231162	Ataduras de trascendencia
231165	Botines de trascendencia
231166	Guantes de trascendencia
231167	Corona de trascendencia
231168	Pantalones de trascendencia
231169	Atuendo de trascendencia
231170	Manto de trascendencia
231171	Cordón de trascendencia
231172	Brazales de trascendencia
231174	Ataduras de sentencia
231175	Cinturón de sentencia
231176	Bufas de sentencia
231177	Quijotes de sentencia
231178	Corona de sentencia
231179	Guanteletes de sentencia
231180	Escarpes de sentencia
231181	Coraza de sentencia
231182	Avambrazos de sentencia
231183	Guardarrenes de sentencia
231184	Espaldares de sentencia
231185	Musleras de sentencia
231186	Gran yelmo de sentencia
231187	Coselete de sentencia
231188	Manoplas de sentencia
231189	Grebas de sentencia
231190	Brazales de sentencia
231191	Faja de sentencia
231192	Manto de sentencia
231193	Saya de placas de sentencia
231194	Yelmo de sentencia
231195	Guantes de sentencia
231196	Botines de sentencia
231197	Loriga de sentencia
231198	Guanteletes de diez tormentas
231199	Brazales de diez tormentas
231200	Cinturón de diez tormentas
231201	Cubrehombros de diez tormentas
231202	Quijotes de diez tormentas
231203	Casco de diez tormentas
231204	Grebas de diez tormentas
231205	Coraza de diez tormentas
231206	Manoplas de diez tormentas
231207	Guardamuñecas de diez tormentas
231208	Guardarrenes de diez tormentas
231209	Espaldares de diez tormentas
231210	Musleras de diez tormentas
231211	Visera de diez tormentas
231212	Escarpes de diez tormentas
231213	Coselete de diez tormentas
231214	Guantes de diez tormentas
231215	Ataduras de diez tormentas
231216	Cordón de diez tormentas
231217	Manto de diez tormentas
231218	Falda de diez tormentas
231219	Tocado de diez tormentas
231220	Botas de diez tormentas
231221	Abrazo de diez tormentas
231222	Mandiletes de diez tormentas
231223	Avambrazos de diez tormentas
231224	Faja de diez tormentas
231225	Bufas de diez tormentas
231226	Leotardos de diez tormentas
231227	Corona de diez tormentas
231228	Botines de diez tormentas
231229	Armadura de diez tormentas
231230	Coselete de Tempestira
231231	Botas de Tempestira
231232	Manoplas de Tempestira
231233	Casquete de Tempestira
231234	Musleras de Tempestira
231235	Espaldares de Tempestira
231236	Cinturón de Tempestira
231237	Brazales de Tempestira
231238	Armadura de Tempestira
231239	Botines de Tempestira
231240	Guanteletes de Tempestira
231241	Tocado de Tempestira
231242	Leotardos de Tempestira
231243	Bufas de Tempestira
231244	Guardarrenes de Tempestira
231245	Guardamuñecas de Tempestira
231246	Cuero de Tempestira
231247	Sandalias de Tempestira
231248	Mitones de Tempestira
231249	Astas de Tempestira
231250	Falda de Tempestira
231251	Manto de Tempestira
231252	Cordón de Tempestira
231253	Ataduras de Tempestira
231254	Jubón de Tempestira
231255	Apisonadoras de Tempestira
231256	Mandiletes de Tempestira
231257	Capucha de Tempestira
231258	Calzas de Tempestira
231259	Hombreras de Tempestira
231260	Fajín de Tempestira
231261	Cubremuñecas de Tempestira
231271	Carrete roto de Nat Pagle
231272	Arpón de Tigule
231273	Punzón de Gri'lek
231274	Molinillo de Gri'lek
231275	Castigador de furia abrasadora
231276	Entorpecedor
231277	Horqueta de locura
231278	Arco de caza hudú
231279	Atizador de Wushoolay
231280	Talismán de naturaleza de Wushoolay
231281	Talismán de espíritus de Wushoolay
231282	Talismán de magia helada de Hazza'rah
231283	Talismán de resguardo de Hazza'rah
231284	Talismán de destrucción de Hazza'rah
231285	Talismán de valor de Gri'lek
231286	Talismán de poderío de Gri'lek
231287	Talismán de artimañas de Renataki
231288	Talismán devastador de Renataki
231289	Égida del Dios de la Sangre
231293	Destripahombres Hakkari antiguo
231296	Llamasangre
231298	Pergamino de alivio espacial menor
231299	Quijotes empapados de sangre
231300	Capa de consumo
231301	Colmillo del ignoto
231302	Destructora de enanos Gurubashi
231303	Guanteletes de pacificador
231304	Pergamino: IIALOV ECASPILA EONRM
231305	Guanteletes de furia marina
231306	Collar de corruptor de alma
231307	El Ojo de Hakkar
231308	Toque del Caos
231309	Hoja de guerra de los Hakkari
231315	Zin'rokh, Destructora de Mundos
231316	Alga de los Mares del Sur encantada prístina
231317	Guerrera de haruspex de Zandalar
231318	Cinturón de haruspex de Zandalar
231319	Brazales de haruspex de Zandalar
231320	Cólera de La Vorágine
231321	Manto de depredador de Zandalar
231322	Cinturón de depredador de Zandalar
231323	Brazales de depredador de Zandalar
231324	Joya de Kajaro
231325	Manto de ilusionista de Zandalar
231326	Brazaletes de ilusionista de Zandalar
231327	Toga de ilusionista de Zandalar
231328	Enseña de héroe
231329	Coraza de librepensador de Zandalar
231330	Cinturón de librepensador de Zandalar
231331	Guardabrazos de librepensador de Zandalar
231332	El Ojo que todo lo ve de Zuldazar
231333	Manto de confesor de Zandalar
231334	Ataduras de confesor de Zandalar
231335	Brazaletes de confesor de Zandalar
231336	Dije Zandalari de maestría de las Sombras
231337	Guerrera de sinconcierto de Zandalar
231338	Manto de sinconcierto de Zandalar
231339	Brazales de sinconcierto de Zandalar
231340	Visión inmaculada de Voodress
231341	Camisote de augur de Zandalar
231342	Cinturón de augur de Zandalar
231343	Brazales de augur de Zandalar
231346	Mancha imparable de Kezan
231347	Brazaletes de demoníaco de Zandalar
231348	Toga de demoníaco de Zandalar
231349	Manto de demoníaco de Zandalar
231350	Ira de Mugamba
231351	Guardabrazos de vindicador Zandalar
231352	Cinturón de vindicador Zandalar
231353	Coraza de vindicador Zandalar
231354	Caricia de animista
231355	Equilibrio de animista
231357	Furia de animista
231358	Rugido de animista
231359	Llamada del falcón
231361	Sello de sincretista
231362	Sigilo de sincretista
231363	Blasón de sincretista
231364	Emblema de sincretista
231366	Aura profética
231367	Maldición profética
231368	Abrazo de la Muerte
231370	Avance de la Muerte
231371	Abrazo de Vodouisant
231372	Sudario de Vodouisant
231373	Talismán de Vodouisant
231375	Vigilancia de Vodouisant
231376	Maleficio hudú
231377	Maldición hudú
231378	Disco dorado reluciente
231379	Presencia de poderío
231381	Presencia de valor
231382	Vasija de renacer
231383	Presencia de Vista
231384	Furia del falcón
231385	Simulacro del Alma de Dragón
231386	Escama de dragón negro perfecta
231387	Ira de Tormenta, espada corta santificada del Buscavendavales
231452	Sangre del Iluminado
231460	Quiebraplanos de Azgaloth
231466	Códice de brujo Alanegra
231509	Escrito de Cassandra
231512	Ídolo Hakkari primigenio
231513	Sangre de Gri'lek
231514	Diente de Renataki
231515	Melena de Wushoolay
231516	Hilo del Sueño de Hazza'rah
231517	Muñeco de vudú agujereado
231518	Muñeco de vudú agujereado
231519	Muñeco de vudú agujereado
231520	Muñeco de vudú agujereado
231521	Muñeco de vudú agujereado
231522	Muñeco de vudú agujereado
231523	Muñeco de vudú agujereado
231524	Muñeco de vudú agujereado
231525	Muñeco de vudú agujereado
231530	Armadura de placas de Señor de la Guerra
231531	Botas de placas de general
231532	Guanteletes de placas de general
231533	Leotardos de placas de general
231534	Sobrehombros de placas de Señor de la Guerra
231535	Celada de placas de Señor de la Guerra
231536	Armadura de placas de mariscal de campo
231537	Guardahombros de placas de mariscal de campo
231538	Yelmo de placas de mariscal de campo
231539	Botas de placas de alguacil
231540	Musleras de placas de alguacil
231541	Guanteletes de placas de alguacil
231543	Pechera de cuero de mariscal de campo
231544	Lúas de cuero de alguacil
231545	Máscara de cuero de mariscal de campo
231546	Guardapiés de cuero de alguacil
231547	Cubrehombros de cuero de mariscal de campo
231548	Leotardos de cuero de alguacil
231549	Coraza de cuero de Señor de la Guerra
231551	Bufas de cuero de Señor de la Guerra
231552	Botines de cuero de general
231553	Yelmo de cuero de Señor de la Guerra
231554	Musleras de cuero de general
231555	Mitones de cuero de general
231557	Espaldares de anillas de mariscal de campo
231558	Quijotes de anillas de alguacil
231560	Mandiletes de anillas de alguacil
231561	Escarpes de anillas de alguacil
231562	Gran yelmo de anillas de mariscal de campo
231563	Armadura de anillas de mariscal de campo
231564	Escarpes de anillas de general
231565	Espaldares de anillas de Señor de la Guerra
231566	Armadura de anillas de Señor de la Guerra
231567	Quijotes de anillas de general
231568	Gran yelmo de anillas de Señor de la Guerra
231569	Mandiletes de anillas de general
231570	Grebas de anillas de general
231571	Yelmo de anillas de Señor de la Guerra
231572	Sobrehombros de anillas de Señor de la Guerra
231573	Camisote de anillas de Señor de la Guerra
231574	Musleras de anillas de general
231575	Abrazaderas de anillas de general
231576	Sobrehombros de anillas de mariscal de campo
231577	Musleras de anillas de alguacil
231578	Abrazaderas de anillas de alguacil
231579	Grebas de anillas de alguacil
231580	Yelmo de anillas de mariscal de campo
231581	Camisote de anillas de mariscal de campo
231582	Toga de tejido de tinieblas de mariscal de campo
231583	Sobrehombros de tejido de tinieblas de mariscal de campo
231584	Corona de mariscal de campo
231585	Botas de tejido de tinieblas de alguacil
231586	Guantes de tejido de tinieblas de alguacil
231587	Leotardos de tejido de tinieblas de alguacil
231588	Pantalones de tejido de tinieblas de general
231589	Guantes de tejido de tinieblas de general
231590	Caperuza de tejido de tinieblas de Señor de la Guerra
231591	Toga de tejido de tinieblas de Señor de la Guerra
231592	Manto de tejido de tinieblas de Señor de la Guerra
231593	Botas de tejido de tinieblas de general
231594	Amito de seda de Señor de la Guerra
231595	Calzas de seda de general
231596	Vestiduras de seda de Señor de la Guerra
231597	Botas de seda de general
231598	Guantes de seda de general
231599	Guanteletes de seda de general
231600	Manijas de seda de general
231601	Capucha de seda de Señor de la Guerra
231602	Bufas de seda de mariscal de campo
231603	Vestimentas de seda de mariscal de campo
231604	Nimbo de mariscal de campo
231605	Leotardos de seda de alguacil
231606	Borceguíes de seda de alguacil
231607	Guantes de seda de alguacil
231608	Guanteletes de seda de alguacil
231609	Manijas de seda de alguacil
231610	Botines de satén de general
231611	Cubrehombros de satén de Señor de la Guerra
231612	Togas de satén de Señor de la Guerra
231613	Mandiletes de satén de general
231614	Leotardos de satén de general
231615	Corona de satén de Señor de la Guerra
231616	Corona de satén de mariscal de campo
231617	Mandiletes de satén de alguacil
231618	Toga de satén de mariscal de campo
231619	Leotardos de satén de alguacil
231620	Botines de satén de alguacil
231621	Cubrehombros de satén de mariscal de campo
231622	Caperuza de satén de mariscal de campo
231623	Manijas de satén de alguacil
231624	Túnica de satén de mariscal de campo
231626	Musleras de satén de alguacil
231627	Botos de satén de alguacil
231628	Manto de satén de mariscal de campo
231630	Botos de satén de general
231631	Manto de satén de Señor de la Guerra
231632	Túnica de satén de Señor de la Guerra
231633	Manijas de satén de general
231634	Musleras de satén de general
231635	Caperuza de satén de Señor de la Guerra
231639	Musleras de láminas de alguacil
231640	Yelmo de láminas de mariscal de campo
231641	Peto de láminas de mariscal de campo
231642	Bolsa de hierbas de celador
231643	Guantes de láminas de alguacil
231644	Bolsa de encantamiento de celador
231645	Espaldares de láminas de mariscal de campo
231646	Grebas de láminas de alguacil
231647	Leotardos de láminas de alguacil
231648	Protegecabezas de láminas de mariscal de campo
231649	Coraza de láminas de mariscal de campo
231650	Guanteletes de láminas de alguacil
231651	Sobrehombros de láminas de mariscal de campo
231652	Escarpes de láminas de alguacil
231653	Camisote de malla de Señor de la Guerra
231654	Espaldares de malla de Señor de la Guerra
231655	Abrazaderas de malla de general
231656	Grebas de malla de general
231657	Protegecabezas de malla de Señor de la Guerra
231658	Musleras de malla de general
231659	Bufas de malla de Señor de la Guerra
231660	Guanteletes de malla de general
231661	Escarpes de malla de general
231662	Coraza de malla de Señor de la Guerra
231663	Yelmo de malla de Señor de la Guerra
231664	Leotardos de malla de general
231665	Cubrehombros de malla de Señor de la Guerra
231666	Guantes de malla de general
231667	Botas de malla de general
231668	Coselete de malla de Señor de la Guerra
231669	Capacete de malla de Señor de la Guerra
231670	Pantalones de malla de general
231671	Grebas de pellejo de dragón de general
231672	Espaldares de pellejo de dragón de Señor de la Guerra
231673	Musleras de pellejo de dragón de general
231674	Guerrera de pellejo de dragón de Señor de la Guerra
231675	Ornato de pellejo de dragón de Señor de la Guerra
231676	Guanteletes de pellejo de dragón de general
231677	Guantes de pellejo de dragón de general
231678	Yelmo de pellejo de dragón de Señor de la Guerra
231679	Armadura de pellejo de dragón de Señor de la Guerra
231680	Pantalones de pellejo de dragón de general
231681	Bufas de pellejo de dragón de Señor de la Guerra
231682	Botas de pellejo de dragón de general
231683	Botines de pellejo de dragón de general
231684	Sobrehombros de pellejo de dragón de Señor de la Guerra
231685	Leotardos de pellejo de dragón de general
231686	Pechera de pellejo de dragón de Señor de la Guerra
231687	Protegecabezas de pellejo de dragón de Señor de la Guerra
231688	Mandiletes de pellejo de dragón de general
231689	Protegecabezas de pellejo de dragón de mariscal de campo
231690	Pechera de pellejo de dragón de mariscal de campo
231691	Leotardos de pellejo de dragón de alguacil
231692	Botines de pellejo de dragón de alguacil
231693	Sobrehombros de pellejo de dragón de mariscal de campo
231694	Mandiletes de pellejo de dragón de alguacil
231695	Yelmo de pellejo de dragón de mariscal de campo
231696	Armadura de pellejo de dragón de mariscal de campo
231697	Pantalones de pellejo de dragón de alguacil
231698	Botas de pellejo de dragón de alguacil
231699	Bufas de pellejo de dragón de mariscal de campo
231700	Guantes de pellejo de dragón de alguacil
231701	Ornato de pellejo de dragón de mariscal de campo
231702	Guerrera de pellejo de dragón de mariscal de campo
231703	Musleras de pellejo de dragón de alguacil
231704	Grebas de pellejo de dragón de alguacil
231705	Espaldares de pellejo de dragón de mariscal de campo
231706	Guanteletes de pellejo de dragón de alguacil
231707	Ataduras draconianas
231708	Cinturón draconiano
231709	Hombreras draconianas
231710	Leotardos draconianos
231711	Caperuza draconiana
231712	Guantes draconianos
231713	Botas draconianas
231714	Toga draconiana
231715	Ataduras primigenias
231716	Cinturón primigenio
231717	Hombreras primigenias
231718	Leotardos primigenios
231719	Yelmo primigenio
231720	Guantes primigenios
231721	Botas primigenias
231722	Guadaña del caos agotada
231723	Pechera primigenia
231724	Ataduras antiguas
231725	Cinturón antiguo
231726	Hombreras antiguas
231727	Leotardos antiguos
231728	Yelmo antiguo
231729	Guantes antiguos
231730	Botas antiguas
231731	Pechera antigua
231732	Suministros sospechosos
231752	T03 - Monstruo - Espada, 2M Alianza
231753	Consuelo del Muro Celeste
231754	Cernícalo
231755	Peregrino
231777	Extremidad qiraji cristalizada
231778	Agua de manantial de montaña
231779	Cólera de Wray
231780	Escrito sobre Crear agua VIII
231781	Alma del trueno
231782	Corona del sucesor
231783	Mantón del Señor del Viento
231784	Celda del relámpago
231785	Ecos de traición
231789	Sigilo del guardián
231792	Alma del engaño
231793	Guadaña del caos agotada (engaño)
231794	Guadaña del caos agotada (Vacío)
231795	Guadaña del caos agotada (sometimiento)
231796	Guadaña del caos agotada (devoradora)
231797	Alma del Vacío
231798	Alma del sometimiento
231799	Alma devoradora
231800	Alma de Des'Altek
231803	Dije de connivencia de Prestor
231806	Flecha abrasadora
231807	Disparo abrasador
231811	Tratado sobre conmoción
231814	Corazón cromático
231815	Destello desgarrador
231817	Golpeavientos
231823	Guja de Geddon
231828	Runa de Especialización en meditación
231829	Runa de Especialización en sanación
231836	Pergamino brillante de alivio espacial
231837	Talla de las Sombras
231841	Sangre del Iluminado
231842	Báculo de Nandieb
231843	Primer fragmento de sigilo
231844	Segundo fragmento de sigilo
231845	Tercer fragmento de sigilo
231846	Punzón de Gri'lek
231847	Molinillo de Gri'lek
231848	Ejecutor de pescado de Nat Pagle
231849	Arpón de Tigule
231850	Voluntad de Arlokk
231851	Garra de Arlokk
231852	Destructora de enanos Gurubashi
231853	Hoja de guerra de los Hakkari
231854	Zin'rokh, Destructora de Mundos
231855	Colmillo del ignoto
231856	Destripahombres Hakkari antiguo
231857	Toque del Caos
231858	Llamasangre
231859	Maleficadora de Jin'do
231860	Sentencia de Jin'do
231861	Triturador de Jeklik
231862	Castigador de furia abrasadora
231863	Entorpecedor
231864	Horqueta de locura
231865	Cetro Zulian de ritos
231866	Toque de Mar'li
231867	Defensor del Señor de la Sangre
231868	Aguijón de Mandokir
231869	Hoja de guerra de los Hakkari
231870	Alabarda de golpeo
231871	Atizador de Wushoolay
231872	Arco de caza hudú
231873	Hacha de piedra Zulian
231874	Colmillo de Venoxis
231875	Garra de Thekal
231876	Cercenadora Zulian
231882	Recibo por instrumentos de supresión
231885	Agonía de Escarcha
231890	Terrestris
231891	Tratado del falcón
231901	Portaverdad
231902	Amuleto de Ada
231903	Trozo de tela rasgada
231904	Cuerno mancillado
231909	Luz estelar cristalizada
231910	Corazón de Azgaloth
231911	Sello del general de la Legión
231912	Hoja del foso
231913	Ojo del observador
231995	Escoria de elementium endurecida
231996	Goblinomorfizador sobrecargado
232018	Hoja besada por el viento durmiente
232079	Ataduras de Tempestira
232080	Cordón de Tempestira
232081	Manto de Tempestira
232082	Falda de Tempestira
232083	Astas de Tempestira
232084	Mitones de Tempestira
232085	Sandalias de Tempestira
232086	Cuero de Tempestira
232087	Brazales de Tempestira
232088	Cinturón de Tempestira
232089	Espaldares de Tempestira
232090	Musleras de Tempestira
232091	Casquete de Tempestira
232092	Manoplas de Tempestira
232093	Botas de Tempestira
232094	Coselete de Tempestira
232095	Cubremuñecas de Tempestira
232096	Fajín de Tempestira
232097	Hombreras de Tempestira
232098	Calzas de Tempestira
232099	Capucha de Tempestira
232100	Mandiletes de Tempestira
232101	Apisonadoras de Tempestira
232102	Jubón de Tempestira
232103	Guardamuñecas de Tempestira
232104	Guardarrenes de Tempestira
232105	Bufas de Tempestira
232106	Leotardos de Tempestira
232107	Tocado de Tempestira
232108	Guanteletes de Tempestira
232109	Botines de Tempestira
232110	Armadura de Tempestira
232111	Avambrazos de acechadragón
232112	Faja de acechadragón
232113	Espaldares de acechadragón
232114	Pantalones de acechadragón
232115	Capacete de acechadragón
232116	Mandiletes de acechadragón
232117	Escarpes de acechadragón
232118	Armadura de acechadragón
232119	Brazales de acechadragón
232120	Cinturón de acechadragón
232121	Bufas de acechadragón
232122	Musleras de acechadragón
232123	Yelmo de acechadragón
232124	Guanteletes de acechadragón
232125	Grebas de acechadragón
232126	Coraza de acechadragón
232127	Ataduras viento abisal
232128	Cinturón viento abisal
232129	Manto viento abisal
232130	Pantalones viento abisal
232131	Corona viento abisal
232132	Guantes viento abisal
232133	Botas viento abisal
232134	Togas viento abisal
232135	Brazaletes viento abisal
232136	Fajín viento abisal
232137	Sobrehombros viento abisal
232138	Leotardos viento abisal
232139	Máscara viento abisal
232140	Mitones viento abisal
232141	Zapatillas viento abisal
232142	Vestimentas viento abisal
232143	Ataduras de sentencia
232144	Cinturón de sentencia
232145	Bufas de sentencia
232146	Quijotes de sentencia
232147	Corona de sentencia
232148	Guanteletes de sentencia
232149	Escarpes de sentencia
232150	Coraza de sentencia
232151	Brazales de sentencia
232152	Faja de sentencia
232153	Manto de sentencia
232154	Saya de placas de sentencia
232155	Yelmo de sentencia
232156	Guantes de sentencia
232157	Botines de sentencia
232158	Loriga de sentencia
232159	Avambrazos de sentencia
232160	Guardarrenes de sentencia
232161	Espaldares de sentencia
232162	Musleras de sentencia
232163	Gran yelmo de sentencia
232164	Manoplas de sentencia
232165	Grebas de sentencia
232166	Coselete de sentencia
232167	Brazales de trascendencia
232168	Cordón de trascendencia
232169	Manto de trascendencia
232170	Pantalones de trascendencia
232171	Corona de trascendencia
232172	Guantes de trascendencia
232173	Botines de trascendencia
232174	Atuendo de trascendencia
232175	Ataduras de trascendencia
232176	Cinturón de trascendencia
232177	Espaldares de trascendencia
232178	Leotardos de trascendencia
232179	Halo de trascendencia
232180	Manoplas de trascendencia
232181	Botas de trascendencia
232182	Togas de trascendencia
232183	Brazales Colmillo de sangre
232184	Cinturón Colmillo de sangre
232185	Bufas Colmillo de sangre
232186	Pantalones Colmillo de sangre
232187	Caperuza Colmillo de sangre
232188	Guantes Colmillo de sangre
232189	Botas Colmillo de sangre
232190	Pechera Colmillo de sangre
232191	Guardamuñecas Colmillo de sangre
232192	Guardarrenes Colmillo de sangre
232193	Hombreras Colmillo de sangre
232194	Musleras Colmillo de sangre
232195	Capucha Colmillo de sangre
232196	Manoplas Colmillo de sangre
232197	Escarpines Colmillo de sangre
232198	Coselete Colmillo de sangre
232199	Ataduras de diez tormentas
232200	Cordón de diez tormentas
232201	Manto de diez tormentas
232202	Falda de diez tormentas
232203	Tocado de diez tormentas
232204	Guantes de diez tormentas
232205	Botas de diez tormentas
232206	Abrazo de diez tormentas
232207	Brazales de diez tormentas
232208	Cinturón de diez tormentas
232209	Cubrehombros de diez tormentas
232210	Quijotes de diez tormentas
232211	Casco de diez tormentas
232212	Guanteletes de diez tormentas
232213	Grebas de diez tormentas
232214	Coraza de diez tormentas
232215	Avambrazos de diez tormentas
232216	Faja de diez tormentas
232217	Bufas de diez tormentas
232218	Leotardos de diez tormentas
232219	Corona de diez tormentas
232220	Mandiletes de diez tormentas
232221	Botines de diez tormentas
232222	Armadura de diez tormentas
232223	Guardamuñecas de diez tormentas
232224	Guardarrenes de diez tormentas
232225	Espaldares de diez tormentas
232226	Musleras de diez tormentas
232227	Visera de diez tormentas
232228	Manoplas de diez tormentas
232229	Escarpes de diez tormentas
232230	Coselete de diez tormentas
232231	Brazales de némesis
232232	Cinturón de némesis
232233	Bufas de némesis
232234	Leotardos de némesis
232235	Capacete de némesis
232236	Guantes de némesis
232237	Botas de némesis
232238	Togas de némesis
232239	Brazaletes de némesis
232240	Cordón de némesis
232241	Hombreras de némesis
232242	Pantalones de némesis
232243	Capucha de némesis
232244	Manoplas de némesis
232245	Botines de némesis
232246	Atuendo de némesis
232247	Brazales de Cólera
232248	Cinturón de Cólera
232249	Sobrehombros de Cólera
232250	Quijotes de Cólera
232251	Yelmo de Cólera
232252	Guanteletes de Cólera
232253	Grebas de Cólera
232254	Coraza de Cólera
232255	Guardamuñecas de Cólera
232256	Guardarrenes de Cólera
232257	Espaldares de Cólera
232258	Musleras de Cólera
232259	Visera de Cólera
232260	Manoplas de Cólera
232261	Escarpes de Cólera
232262	Coselete de Cólera
232299	Defensor Zulian
232309	Conducto de alma de Renataki
232310	Conducto de alma de Renataki
232311	Capa de pellejo de tigre Zulian
232312	Sangre del Iluminado
232324	Silbato para aves
232344	Vick's VIP Pass
232357	Vengador dracónico
232358	Relicario vacío
232373	Ojo de Sulfuras refinado
232389	Tratado sobre plenitud
232390	Ídolo de enfoque celestial
232391	Ídolo de enfoque felino
232392	Tótem del trueno implacable
232409	Tótem de los elementos
232414	Hoja de diente de dragón
232416	Tótem de flujo astral
232419	Tótem de corrientes conductoras
232420	Tratado de cólera
232421	Tratado de venganza
232423	Ídolo de la nutrición
232424	Ídolo de crueldad
232433	Venda de paño rúnico densa
232434	Manual: venda de paño rúnico densa
232436	Sopa de Garranegra
232437	Receta: sopa de Garranegra
232438	Branquirrojo ahumado
232443	Receta: branquirrojo ahumado
232454	Emblema de los dioses salvajes
232455	Emblema del deshonor
232456	Emblema del Ojo Violeta
232457	Emblema del núcleo del mundo
232458	Runa de Salvaguardia mejorada
232459	Runa de Explosión de humo
232460	Runa de Desplazamiento
232461	Runa de Desesperación
232462	Runa de Poder purificador
232549	Informe de tareas logísticas VI
232550	Ashkandi, Espada magna de la Hermandad
232551	Gran maza dracónica
232552	Lok'amir il Romathis
232555	Crul'shorukh, Filo del Caos
232556	Bastón de la Sombra en llamas
232557	Zarpa de Chromaggus
232558	Espada templada cromáticamente
232559	Heraldo de tragedia
232561	Zarpa del draco negro
232562	Cuchilla de garfa de draco
232563	Bastón de enfoque de Alasombra
232564	Maladath, Hoja rúnica del Vuelo Negro
232565	Hoja colmillo dragón
232566	La espada indomable
232567	Machacacolumnas
232576	Vengador dracónico
232577	Filo de la fatalidad
232606	Ashjre'thul, Ballesta de paliza
232607	Apuntacorazones
232608	Culebrina aliento de dragón
232610	Fórmula: abrillantador trol magnífico
232611	Abrillantador trol magnífico
232652	Zila Amanemodas
233197	Manual de entrenamiento Argenta
233198	Cuerno del Alba
233200	Semilla de Cantaflor
233201	Orbe fulgurante
233206	Yunque de sobrestante
233208	Bola 8 mágica "defectuosa"
233209	Caldera de piroagua
233211	Concha espiritual
233213	Magnetita antigua
233215	Trampa de arena explosiva
233216	Rayo congelante
233217	Incienso de tunelador
233226	Cuerda antigua Zandalari
233250	Rama antigua
233351	Cristal resonador Qiraji verde claro
233352	Cristal resonador Qiraji azul oscuro
233353	Cristal resonador Qiraji azul claro
233356	Cristal resonador Qiraji naranja
233357	Cristal resonador Qiraji crepuscular
233358	Tanque silítido domado
233362	Cascarón del dios antiguo
233363	Caparazón del dios antiguo
233364	Piel del dios antiguo
233365	Vísceras intactas
233367	Peritoneo intacto
233368	Entrañas intactas
233369	Ataduras de dominio Qiraji
233370	Ataduras de mando Qiraji
233371	Ataduras de soberano Qiraji
233372	Grebas de conquistador
233373	Coraza de conquistador
233374	Musleras de conquistador
233375	Corona de conquistador
233376	Bufas de conquistador
233377	Borceguíes de clamacondenas
233378	Calzas de clamacondenas
233379	Manto de clamacondenas
233380	Togas de clamacondenas
233381	Círculo de clamacondenas
233382	Leotardos de clamatormentas
233383	Espaldares de clamatormentas
233384	Guardapiés de clamatormentas
233385	Diadema de clamatormentas
233386	Camisote de clamatormentas
233387	Bufas de mortífero
233388	Yelmo de mortífero
233389	Jubón de mortífero
233390	Leotardos de mortífero
233391	Botas de mortífero
233392	Borceguíes del Oráculo
233393	Tiara del Oráculo
233394	Manto del Oráculo
233395	Vestimentas del Oráculo
233396	Calzas del Oráculo
233397	Coraza del Vengador
233398	Corona del Vengador
233399	Grebas del Vengador
233400	Musleras del Vengador
233401	Espaldares del Vengador
233402	Togas Enigma
233403	Hombreras enigma
233404	Círculo enigma
233405	Botas enigma
233406	Leotardos enigma
233407	Guardapiés de asediador
233408	Leotardos de asediador
233409	Espaldares de asediador
233410	Diadema de asediador
233411	Camisote de asediador
233412	Yelmo del Génesis
233413	Hombreras del Génesis
233414	Botas del Génesis
233415	Jubón del Génesis
233416	Calzas del Génesis
233417	Maza de vida inagotable
233418	Capa de Vida inagotable
233419	Sortija de Vida inagotable
233420	Capa de la Senda Oculta
233421	Guadaña de la Senda Oculta
233422	Sello de la Senda Oculta
233423	Hoja de secretos oscuros
233424	Mantón de Secretos oscuros
233425	Sortija de Secretos oscuros
233426	Hoja de Justicia eterna
233427	Manteo de Justicia eterna
233428	Anillo de Justicia eterna
233429	Mazo de Infinita sabiduría
233430	Sudario de Infinita sabiduría
233431	Anillo de Infinita sabiduría
233432	Capa de las Sombras ocultas
233433	Daga de las Sombras Ocultas
233434	Sortija de las Sombras Ocultas
233435	Martillo de la tormenta inminente
233436	Capa de la Tormenta inminente
233437	Anillo de la tormenta inminente
233438	Sudario de nombres prohibidos
233439	Kris de nombres prohibidos
233440	Anillo de nombres prohibidos
233441	Mantón de Fuerza implacable
233442	Hoz de fuerza implacable
233443	Sello de Fuerza implacable
233490	Campeón de obsidiana
233491	Atracador de obsidiana
233492	Placa de batalla de zarzapúa
233496	Sobrehombros de bombardeo
233502	Amuleto de Guardia del mal
233503	Colgante del guardián Qiraji
233504	Capa de Odio concentrado
233505	Leotardos de Inmersión
233506	Guardamuñecas de escamas de alfazaque
233507	Anillo de enjambre de pensamientos
233509	Bastón de los Profetas Qiraji
233514	Botas de la Voluntad inflexible
233515	Martillo de Ji'zhi
233516	Coraza de Aniquilación
233517	Botas de la Profecía cumplida
233518	Botas del Profeta caído
233519	Manteo de la Trinidad
233520	Togas del Triunvirato
233521	Manto ternario
233522	Disfraz del Devorador
233523	Faja de triada
233524	Toque de Angelista
233559	Guantes de Ebru
233560	Guanteletes comidos de moco
233561	Botas del Héroe caído
233562	Talismán de Angelista
233563	Manto de Poder frénico
233564	Guanteletes cubiertos de bilis
233565	Anillo de oscuridad de Ukko
233566	Manto de la Furia del Desierto
233567	Manto de la Cruzada del Desierto
233568	Jubón de Ejecución veloz
233569	Anillo del devorado
233570	Escarabajo petrificado
233571	Varita de Nobleza Qiraji
233572	Collar de Pureza
233573	Botas recompuestas
233574	Leotardos del Enjambre ulceroso
233575	Togas del Guardia de batalla
233576	Zarpa de silítido
233577	Cinturón de pellejo Qiraji grueso
233578	Yelmo parra reptadora
233579	Guantes de Aplicación
233580	Insignia del Guardaenjambre
233581	Poderío de Sartura
233582	Guanteletes de Determinación férrea
233583	Musleras de Luz llameante
233584	Leotardos de escamas de furia Qiraji
233585	Destripador Qiraji antiguo
233586	Mandíbula del atracador de arena
233587	Gargantilla de púas
233588	Capa de los Secretos ocultos
233589	Fetiche del Atracador de arena
233590	Botas de tunelador de colmena
233591	Coselete caparazón de silítido
233592	Manto de la Revancha Horrenda
233593	Espaldares del Implacable
233594	Togas del Santo guardián
233595	Leotardos de escamas de atracador de arena
233596	Tratado sobre Purificación
233597	Tótem de Vida
233598	Leotardos cubiertos de baba
233599	Fémur de silítido afilado
233600	Anillo de Furia Qiraji
233601	Broche escarabajo
233602	Ídolo de Salud
233603	Guanteletes de Campeón recto
233604	Guanteletes de Kalimdor
233605	Aguijonero de Huhuran
233606	Capa de la Colmena dorada
233607	Guantes del Mesías
233608	Guanteletes de pellejo de avispa
233609	Anillo del mártir
233610	Guardamuñecas de colmena Rapiñador
233611	Botas de epifanía
233612	Brazales Qiraji de ejecución
233613	Guantes de Devastación de Vek'lor
233614	Cinturón Qiraji real
233615	Anillo del Emperador Vek'lor
233616	Cetro real de Vek'lor
233617	Brazaletes de redención real
233618	Guantes del Templo oculto
233619	Cinturón regenerador de Vek'nilash
233620	Amuleto de Vek'nilash
233621	Revancha de Kalimdor
233622	Garra del Emperador caído
233623	Cinturón del Emperador caído
233624	Sombrero perdido de Don Rigoberto
233625	Brazales de escarbador
233626	Larva del Gran Gusano
233627	Jom Gabbar
233628	La coraza del escarbador
233629	Bloqueador de escamas de gusano
233630	Capa del devorado
233631	Guanteletes de Tormenta oscura
233632	Garra del dios antiguo
233633	Cordón cinturón Acecha ojos
233634	Aguijón de la Muerte
233635	Cinturón de Agonía interminable
233636	Cetro del falso profeta
233637	Guanteletes de Aniquilación
233638	Anillo del destripadioses
233639	Tentáculo derrotado de C'Thun
233640	Filo oscuro de la locura
233641	Capa de Claridad
233642	Marca de C'Thun
233643	Martillo de guerra Anubisath
233644	Atuendo de Ascensión Real
233645	Guantes del Inmortal
233646	Guantes de la Profecía redimida
233647	Neretzek, el Bebedor de sangre
233648	Anillo de caos de Ritssyn
233649	Fragmento de la Estrella caída
233651	Loriga de conquistador
233652	Escarpes de conquistador
233653	Yelmo de conquistador
233654	Escarcelas de conquistador
233658	Espaldares de conquistador
233659	Coselete de mortífero
233660	Botines de mortífero
233661	Visor de mortífero
233662	Pantalones de mortífero
233663	Espaldares de mortífero
233664	Cota guarnecida de asediador
233665	Botines de asediador
233666	Visor de asediador
233667	Quijotes de anillas de asediador
233668	Bufas de asediador
233669	Protegecabezas de clamacondenas
233670	Atuendo de clamacondenas
233671	Hombreras de clamacondenas
233672	Pantalones de clamacondenas
233673	Botines de clamacondenas
233674	Pantalones enigma
233675	Zapatillas enigma
233676	Diadema enigma
233677	Manto enigma
233678	Atuendo enigma
233679	Leotardos del Oráculo
233680	Togas del Oráculo
233681	Hombreras del Oráculo
233682	Corona del Oráculo
233683	Zapatillas del Oráculo
233684	Manto del Vengador
233685	Pantalones de placas del Vengador
233686	Botines del Vengador
233687	Yelmo del Vengador
233688	Loriga del Vengador
233689	Bufas del Vengador
233690	Escarcelas del Vengador
233691	Escarpes del Vengador
233692	Gran yelmo del Vengador
233693	Coselete del Vengador
233694	Coselete de clamatormentas
233695	Visera de clamatormentas
233696	Escarpes de clamatormentas
233697	Bufas de clamatormentas
233698	Quijotes de clamatormentas
233699	Coraza de clamatormentas
233700	Corona de clamatormentas
233701	Botines de clamatormentas
233702	Manto de clamatormentas
233703	Leotardos de anillas de clamatormentas
233704	Abrazo de clamatormentas
233705	Ornato de clamatormentas
233706	Grebas de clamatormentas
233707	Cubrehombros de clamatormentas
233708	Leotardos de malla de clamatormentas
233709	Capucha del Génesis
233710	Pantalones de cuero del Génesis
233711	Armadura del Génesis
233712	Apisonadoras del Génesis
233713	Bufas del Génesis
233714	Leotardos del Génesis
233715	Cuero del Génesis
233716	Botines del Génesis
233717	Manto del Génesis
233718	Ornato del Génesis
233719	Calzones del Génesis
233720	Coselete del Génesis
233721	Grebas del Génesis
233722	Espaldares del Génesis
233723	Máscara del Génesis
233724	Faja de placas curtida en combate
233725	Faja de placas curtida en combate
233726	Guardabrazos de placas curtidos en combate
233727	Guardabrazos de placas curtidos en combate
233728	Insignia ensangrentada
233729	Gargantilla ensangrentada
233730	Dije ensangrentado
233731	Amuleto ensangrentado
233732	Collar ensangrentado
233733	Anillo ensangrentado
233734	Círculo ensangrentado
233735	Aro ensangrentado
233736	Sortija ensangrentada
233737	Capa ensangrentada
233738	Manteo ensangrentado
233739	Mantón ensangrentado
233740	Sudario ensangrentado
233741	Cinturón de láminas curtido en combate
233742	Guardabrazos de láminas curtidos en combate
233743	Muñequeras de láminas curtidas en combate
233744	Cordón de láminas curtido en combate
233745	Pretina de malla curtida en combate
233746	Cordón de malla curtido en combate
233747	Cinturón de malla curtido en combate
233748	Brazales de malla curtidos en combate
233749	Guardamuñecas de malla curtidos en combate
233750	Avambrazos de malla curtidos en combate
233751	Faja de anillas curtida en combate
233752	Faja de anillas curtida en combate
233753	Cinturón de anillas curtido en combate
233754	Cinturón de anillas curtido en combate
233755	Guardamuñecas de anillas curtidos en combate
233756	Guardamuñecas de anillas curtidos en combate
233757	Brazales de anillas curtidos en combate
233758	Brazales de anillas curtidos en combate
233759	Brazales de pellejo de dragón curtidos en combate
233760	Brazales de pellejo de dragón curtidos en combate
233761	Cinturón de pellejo de dragón curtido en combate
233762	Cinturón de pellejo de dragón curtido en combate
233763	Guardarrenes de pellejo de dragón curtido en combate
233764	Guardarrenes de pellejo de dragón curtido en combate
233765	Cordón de pellejo de dragón curtido en combate
233766	Cordón de pellejo de dragón curtido en combate
233767	Muñequeras de pellejo de dragón curtidas en combate
233768	Muñequeras de pellejo de dragón curtidas en combate
233769	Bandas de pellejo de dragón curtidos en combate
233770	Bandas de pellejo de dragón curtidos en combate
233771	Faja de cuero curtida en combate
233772	Faja de cuero curtida en combate
233773	Braquiales de cuero curtidos en combate
233774	Braquiales de cuero curtidos en combate
233775	Puños de seda curtidos en combate
233776	Puños de seda curtidos en combate
233777	Fajín de seda curtido en combate
233778	Fajín de seda curtido en combate
233779	Brazales de satén curtidos en combate
233780	Brazales de satén curtidos en combate
233781	Muñequeras de satén curtidas en combate
233782	Muñequeras de satén curtidas en combate
233783	Fajín de satén curtido en combate
233784	Fajín de satén curtido en combate
233785	Cincho de satén curtido en combate
233786	Cincho de satén curtido en combate
233787	Puños de tejido de tinieblas curtidos en combate
233788	Puños de tejido de tinieblas curtidos en combate
233789	Cinturón de tejido de tinieblas curtido en combate
233790	Cinturón de tejido de tinieblas curtido en combate
233791	Moneda de cobre ensangrentada
233793	Hombreras de zarzapúa
233795	Jaula de cabeza de zarzapúa
233796	Destructor Obsidiano
233797	Martillo de tormenta de obsidiana
233798	Hoja sabia de obsidiana
233801	Defensor obsidiano
233802	Refuerzo para armadura de quitina resplandeciente
233803	Refuerzo para armadura de quitina afilada
233804	Hombreras de filozarza
233808	Capucha de filozarza
233813	Cuero de filozarza
233826	Capucha vampírica
233833	Chal vampírico
233837	Túnica vampírica
233956	Bufanda de seda Qiraji
233958	Manteo de seda Qiraji
233959	Capa de seda Qiraji
233960	Mantón de seda Qiraji
233962	Frasco de locura
233964	Frasco de conocimiento ancestral
233965	Frasco de los dioses antiguos
233966	Frasco de pesar implacable
233967	Elixir de tejón
233968	Elixir del señor de la magia
233969	Elixir de brazo de hierro
233977	Elixir de prontitud
233984	Megabomba Arcana
233985	El fumigador
233986	Bomba de obsidiana
233987	Generador BU3 N4V1-BR4
233988	Disco reactivo de potencia afinado
233990	Piedraveloz
233991	Lágrima de la Soñadora
233992	Magnetita de la represalia
233993	Cronómetro encantado
233994	Broche incrustado de rubíes
233995	Pergamino: cólera del enjambre
233996	Repelente encantado
233997	Fórmula: encantar pechera: estadísticas vivientes
233998	Fórmula: encantar guantes: poder sagrado
233999	Fórmula: encantar guantes: poder Arcano
234000	Libro de plegarias encantado
234001	Tótem encantado
234002	Seta encantada
234003	Lingote de torio imbuido de obsidiana
234004	Piedra de pulir obsidiana
234005	Pólvora obsidiana
234006	Quitina de silítido monstruoso
234007	Quitina de silítido con pinchos
234008	Seda Qiraji
234009	Madeja de seda Qiraji
234010	Bilis de gusano de arena antiguo
234011	Veneno de acechador Qiraji
234012	Cardo de la colmena
234016	Sello del Vuelo Bronce
234017	Sello del Vuelo Bronce
234018	Sello del Vuelo Bronce
234019	Sello del Vuelo Bronce
234020	Sello del Vuelo Bronce
234021	Sello del Vuelo Bronce
234022	Sello del Vuelo Bronce
234023	Sello del Vuelo Bronce
234024	Sello del Vuelo Bronce
234025	Sello del Vuelo Bronce
234026	Sello del Vuelo Bronce
234027	Sello del Vuelo Bronce
234028	Sello del Vuelo Bronce
234029	Sello del Vuelo Bronce
234030	Sello del Vuelo Bronce
234031	Sello del Vuelo Bronce
234032	Sello del Vuelo Bronce
234033	Sello del Vuelo Bronce
234034	Sello del Vuelo Bronce
234035	Sello del Vuelo Bronce
234061	Daga Qiraji de sacrificios
234062	Vestimentas del Mar de Dunas
234063	Cinturón del Atracador de arena
234064	Cinturón de la Inquisición
234065	Guardamuñecas de atracador de arena
234066	Guantes de pellejo de silítido endurecido
234067	Destripador de los Qiraji
234068	Botas de la vanguardia
234069	Botas del general Qiraji
234070	Brazales de Orden Qiraji
234071	Musleras del comando Qiraji
234072	Garra del Viento del Sur
234073	Turbante vientoseco
234075	Guanteletes del Inamovible
234076	Garfa de Concentración de furia
234077	Coselete de silítido gruesa
234078	Guardahombros quitinosos
234079	Capa del Salvador
234080	Ojo de Moam
234081	Guanteletes del Viento del Sur
234082	Manto de Maz'Nadir
234083	Anillo de Furia
234084	Yelmo del Viento del Sur
234085	Diseño: garras negras del Destructor
234086	Garras negras del Destructor
234087	Leotardos de escamas de obsidiana
234088	Musleras del Destructor
234089	Fragmento de la calavera de Buru
234090	Guantes del Enjambre
234091	Guanteletes de escamas babosos
234092	Fetiche de pinchos de quitina
234093	Botas de arenas movedizas
234094	Brazales de escamas del Glotón
234095	Chanclos para babosas
234096	Arco de tendón tenso
234097	Aguijonero de Ayamiss
234098	Botas del Protector del desierto
234099	Botas de las Arenas ígneas
234100	Yelmo de Recrecimiento
234101	Anillo de los Vientos del desierto
234102	Guanteletes de escamas de silítido
234103	Brazales de Brutalidad
234104	Ballesta de Maldición inminente
234105	Guanteletes de Nueva Vida
234106	Guantes de Sabiduría oscura
234107	Yelmo de Dominación
234108	Leotardos de la ventisca negra
234109	Manto de los Horusath
234110	Brazal de Osirio
234111	Sobrehombros de piedra rúnica
234112	Martillo pulido con arena
234113	Capa Tormenta de Arena
234114	Grilletes del Sinmarcas
234115	Bastón de las Ruinas
234116	Furia del Enjambre olvidado
234117	Botines de nómada errante
234118	Mazo de Autoridad Qiraji
234119	Antena de tonificación
234120	Yelmo del Vengador Sagrado
234121	Lanzacáscaras de silítido
234122	El kris perdido de Zedd
234123	Almófar de Furia elemental
234124	Vademécum de Veneno oculto II
234129	Leotardos incrustados de ónice
234130	Amuleto de Escudo de las Sombras
234132	Collar de dientes de draco
234133	Botas de esclavo
234134	Turbante de poderío psíquico gnómico
234135	Sortija de Prolavades heladas
234136	Togas Aguaoscura
234137	Colmillo de Korialstrasz
234138	Pena de Cantosombrío
234139	Legado de Cresta Cuervo
234141	Espada rúnica de los rojos
234142	Elixir de Tragonublo sin fondo
234143	Globo de engaño
234144	Incensario del falso profeta
234145	Joya Hakkari empapada en sangre
234146	Grebas grabadas con ácido
234147	Antiguos leotardos corroídos
234148	Muñequeras de hueso de dragón
234149	Brazaletes de espuelas de dragón
234150	Guantes de poder ilusorio
234151	Capa de piel de dragón verde
234152	Martillo de furia bestial
234153	Bastón de crecimiento desenfrenado
234154	Piedra de trance
234155	Sello de Malfurión
234156	Botas de la llanura eterna
234157	Aro de sueños inquietos
234158	Collar de corazón de dragón
234159	Ballesta de hierromadera pulida
234160	Anillo de los sin vida
234161	Cinturón de la ciénaga oscura
234162	Muñequeras de corteza negra
234163	Pantalones de corazón oscuro
234164	Almete de crecimiento desviado
234165	Guanteletes de luz brillante
234166	Guardapiés malignos
234167	Botas de miedo
234168	Zapatillas de mendigo
234169	Sortija de lágrima mental
234170	Hoja pesadilla
234171	Bufas de cuero artificial
234172	Colmillo de dragón esmeralda
234173	Leotardos de la mente demente
234174	Espaldares grabados con ácido
234175	Cristal de hibernación
234176	Carta de la Luna Negra: Heroísmo
234177	Carta de la Luna Negra: Dragón azul
234178	Carta de la Luna Negra: la Vorágine
234179	Carta de la Luna Negra: el Vacío Abisal
234180	Bengala temporal
234181	Diario de fiel del Crepúsculo
234198	Sello del Vuelo Bronce
234199	Sello del Vuelo Bronce
234200	Sello del Vuelo Bronce
234201	Sello del Vuelo Bronce
234202	Sello del Vuelo Bronce
234220	Diseño: jaula de cabeza de zarzapúa
234221	Diseño: hombreras de zarzapúa
234222	Diseño: placa de batalla de zarzapúa
234223	Diseño: atracadora de obsidiana
234224	Diseño: campeón de obsidiana
234225	Diseño: destructora de obsidiana
234226	Diseño: martillo de tormenta de obsidiana
234227	Diseño: hoja sabia de obsidiana
234228	Diseño: defensora de obsidiana
234235	Patrón: refuerzo para armadura de quitina resplandeciente
234236	Patrón: refuerzo para armadura de quitina afilada
234237	Patrón: capucha de filozarza
234238	Patrón: hombreras de filozarza
234239	Patrón: cuero de filozarza
234240	Patrón: capucha vampírica
234241	Patrón: chal vampírico
234242	Patrón: toga vampírica
234244	Patrón: bufanda de seda Qiraji
234249	Patrón: manteo de seda Qiraji
234250	Patrón: capa de seda Qiraji
234251	Patrón: mantón de seda Qiraji
234252	Receta: frasco de pesar implacable
234253	Receta: frasco de conocimiento ancestral
234255	Receta: frasco de los dioses antiguos
234256	Receta: frasco de locura
234257	Receta: elixir de tejón
234258	Receta: elixir del señor de la magia
234259	Receta: elixir de brazo de hierro
234260	Receta: elixir de prontitud
234261	Esquema: megabomba arcana
234262	Esquema: el fumigador
234263	Esquema: bomba de obsidiana
234264	Esquema: generador BU3 N4V1-BR4
234265	Esquema: disco reactivo de potencia afinado
234266	Fórmula: piedraveloz
234267	Formula: lágrima del soñador
234268	Fórmula: magnetita de la represalia
234269	Fórmula: cronómetro encantado
234270	Fórmula: broche incrustado de rubíes
234271	Fórmula: pergamino: cólera del enjambre
234272	Fórmula: repelente encantado
234275	Fórmula: libro de plegarias encantado
234276	Fórmula: tótem encantado
234277	Fórmula: seta encantada
234278	Manual: fundir lingote de torio imbuido de obsidiana
234279	Diseño: piedra de pulir obsidiana
234280	Esquema: pólvora de obsidiana
234288	Cinturón parraférrea
234289	Diseño: cinturón parraférrea
234290	Guantes parraférrea
234291	Diseño: guantes parraférrea
234292	Peto parraférrea
234293	Diseño: peto parraférrea
234294	Brazales acecharenas
234295	Patrón: brazales acecharenas
234296	Guanteletes acecharenas
234297	Patrón: guanteletes acecharenas
234298	Peto acecharenas
234299	Patrón: peto acecharenas
234300	Brazales escupefuego
234301	Patrón: brazales escupefuego
234302	Guanteletes escupefuego
234303	Patrón: guanteletes escupefuego
234304	Peto escupefuego
234305	Patrón: peto escupefuego
234306	Cinturón zarzal
234307	Patrón: cinturón zarzal
234308	Botas zarzal
234309	Patrón: botas zarzal
234310	Yelmo zarzal
234311	Patrón: yelmo zarzal
234312	Hombreras nemorosas
234314	Patrón: hombreras nemorosas
234315	Corona nemorosa
234316	Patrón: corona nemorosa
234317	Jubón nemoroso
234318	Patrón: jubón nemoroso
234319	Cinturón de obsidiana pesado
234320	Diseño: cinturón de obsidiana pesado
234321	Cinturón de obsidiana ligero
234322	Diseño: cinturón de obsidiana ligero
234324	Peto de escamas oníricas
234325	Patrón: peto de escamas oníricas
234428	Buscacorazones de obsidiana
234429	Diseño: buscacorazones de obsidiana
234434	Escopeta de obsidiana
234435	Esquema: escopeta de obsidiana
234436	Sello del Vuelo Bronce
234437	Sello del Vuelo Bronce
234438	Sello del Vuelo Bronce
234439	Sello del Vuelo Bronce
234440	Sello del Vuelo Bronce
234444	Veneno oculto II
234445	Patrón: madeja de seda Qiraji
234447	Vara de transformación de Burbujas
234458	Diseño: escudo dentado de obsidiana
234459	Escudo dentado de obsidiana
234460	Túnica de malla de obsidiana
234461	Diseño: túnica de malla de obsidiana
234462	Golpeterra
234463	Cólera de Cenarius
234464	Vara de burbujas de Burbujas
234465	Riendas del tigre espectral presto
234467	Vara de dragones de Burbujas
234468	Ídolo de poder osuno
234469	Ídolo de ferocidad felina
234474	Ídolo de cólera sideral
234475	Tratado del exorcista
234476	Tratado sobre Santidad
234477	Tratado sobre Rectitud
234478	Tótem de golpes atronadores
234479	Tótem de magma fluyente
234480	Tótem de trueno piroclástico
234481	Patrón: falda de escamas oníricas
234482	Falda de escamas oníricas
234483	Patrón: brazales de escamas oníricas
234484	Brazales de escamas oníricas
234485	Mitones de escamas oníricas
234486	Patrón: mitones de escamas oníricas
234487	Visor de escamas oníricas
234488	Diseño: visor de escamas oníricas
234542	Espada magna de Gran Señor de la Guerra
234543	Hacha de batalla de Gran Señor de la Guerra
234545	Pulverizador de Gran Señor de la Guerra
234546	Destructor de Gran Señor de la Guerra
234547	Pica de cerdos de Gran Señor de la Guerra
234548	Palo de cerdos de Gran Señor de la Guerra
234549	Bastón de guerra de Gran Señor de la Guerra
234550	Hoja de hechizo de Gran Señor de la Guerra
234551	Maza de batalla de Gran Señor de la Guerra
234552	Hoja de Gran Señor de la Guerra
234553	Hoja rápida de Gran Señor de la Guerra
234554	Cuchilla de Gran Señor de la Guerra
234555	Cachiporra de Gran Señor de la Guerra
234556	Cuchilla de Gran Señor de la Guerra
234557	Garra derecha de Gran Señor de la Guerra
234558	Garra izquierda de Gran Señor de la Guerra
234559	Arco corvo de Gran Señor de la Guerra
234560	Ballesta de Gran Señor de la Guerra
234561	Limpiacalles de Gran Señor de la Guerra
234562	Escudo de pared de Gran Señor de la Guerra
234563	Escrito sobre destrucción del Gran Señor de la Guerra
234564	Escrito sobre curación del Gran Señor de la Guerra
234565	Espada claymore de Gran mariscal
234566	Taladora de Gran mariscal
234567	Martillo de batalla de Gran mariscal
234568	Demoledor de Gran mariscal
234569	Guja de Gran mariscal
234570	Arma de asta de Gran mariscal
234571	Bastón de Gran mariscal
234574	Hoja de mago de Gran mariscal
234576	Martillo de guerra de Gran Mariscal
234578	Espada larga de Gran mariscal
234579	Hoja ágil de Gran Mariscal
234580	Hacha de mano de Gran mariscal
234581	Castigadora de Gran mariscal
234582	Daga dirk de Gran mariscal
234583	Hoja de mano derecha de Gran mariscal
234584	Hoja de mano izquierda de Gran mariscal
234585	Diana de Gran mariscal
234586	Repetidor de Gran mariscal
234587	Cañón de mano de Gran mariscal
234588	Égida de Gran Mariscal
234589	Escrito sobre poder del Gran Mariscal
234590	Escrito sobre restauración del Gran Mariscal
234614	Emblema tocado por el Vacío
234650	Destripador qiraji antiguo
234747	Puño de Cenarius
234748	Brazales de Rocahonda
234749	Orbe calmaterra
234760	Brazales furiarroca
234761	Poderío de Cenarius
234779	Gracia de la tierra
234780	Sortija de Poderío de la tierra
234782	Jubón de Poder terrenal
234785	Guantes de Poder de la tierra
234786	Sortija de Cólera de la tierra
234788	Capa Tejetierra
234792	Rebanadora Ravenholdt
234793	Chafarote de Chafadento
234797	El atizador Truenedera
234798	Condemulus primordial
234799	Repetidor de recarga de Fahrad
234800	Martillo de cultivo de Simone
234801	Amuleto del Dios caído
234802	Capa del Dios caído
234803	Anillo del Dios caído
234804	Hacha de guerra qiraji bendita
234805	Mosquete qiraji bendito
234806	Pugio qiraji bendito
234807	Baluarte qiraji bendito
234808	Bastón de acólito qiraji bendito
234809	Bastón de augur qiraji bendito
234810	Martillo de guerra qiraji bendito
234811	Talismán del Mar de Dunas
234812	Amuleto del Mar de Dunas
234813	Gargantilla del Mar de Dunas
234814	Colgante del Mar de Dunas
234960	Riendas del tigre ensangrentado
234961	Silbato del raptor ensangrentado
234962	Vestimentas decoradas con jade
234963	Quijotes con extrañas inscripciones
234964	Sello del Vuelo Bronce
234965	Sello del Vuelo Bronce
234966	Sello del Vuelo Bronce
234967	Sello del Vuelo Bronce
234968	Sello del Vuelo Bronce
234974	Bastón de los Profetas qiraji
234975	Martillo de Ji'zhi
234976	Varita de la nobleza qiraji
234977	Zarpa de silítido
234978	Mandíbula del atracador de arena
234979	Fémur de silítido afilado
234980	Aguijonero de Huhuran
234981	Revancha de Kalimdor
234983	Larva del Gran Gusano
234984	Aguijón de la Muerte
234985	Filo oscuro de la locura
234986	Martillo de guerra Anubisath
234987	Neretzek, el Bebedor de sangre
234989	Daga qiraji de sacrificios
234990	Destripador de los qiraji
234991	Arco de tendón tenso
234992	Aguijonero de Ayamiss
234993	Ballesta de Maldición inminente
234994	Martillo pulido con arena
234995	Bastón de las Ruinas
234996	Mazo de Autoridad Qiraji
234997	Lanzacáscaras de silítido
234998	El puñal hindú perdido de Zedd
234999	Martillo de guerra qiraji bendito
235000	Bastón de augur qiraji bendito
235001	Bastón de acólito qiraji bendito
235002	Pugio qiraji bendito
235003	Hacha de guerra qiraji bendita
235004	Mosquete qiraji bendito
235005	Hoz de fuerza implacable
235006	Daga de las Sombras Ocultas
235007	Guadaña de la Senda Oculta
235008	Puñal hindú de nombres prohibidos
235009	Martillo de la tormenta inminente
235010	Mazo de sabiduría infinita
235011	Hoja de Justicia eterna
235012	Maza de vida inagotable
235013	Hoja de secretos oscuros
235014	Cetro del falso profeta
235039	Diseño: peto obsidiano grueso
235040	Peto obsidiano grueso
235045	Regalos imperiales qiraji
235046	Armamento imperial qiraji
235047	Guantes del Profeta caído
235048	Cabeza de Osirio el Sinmarcas
235049	Objeto inundado de Pesadilla
235133	Fórmula: tratado sobre Rectitud
235134	Fórmula: tratado del exorcista
235135	Fórmula: tratado sobre Santidad
235136	Fórmula: tótem de trueno piroclástico
235137	Fórmula: tótem de golpes atronadores
235138	Fórmula: tótem de magma fluyente
235139	Fórmula: ídolo de cólera sideral
235140	Fórmula: ídolo de ferocidad felina
235141	Fórmula: ídolo de poder osuno
235142	Moneda de plata ensangrentada
235143	Moneda de oro ensangrentada
235144	Bolsa de monedas de cobre ensangrentadas
235145	Bolsa de monedas de plata ensangrentadas
235275	Baraja de los Portales
235276	Baraja de los Elementales
235277	Baraja de los Señores de la Guerra
235278	Baraja de las Bestias
235282	Antena de tonificación
235473	Barricada de Gran mariscal
235474	Barricada de Gran Señor de la Guerra
235476	Rebanadora de Gran Señor de la Guerra
235477	Partehuesos de Gran Señor de la Guerra
235478	Puñal de Gran Señor de la Guerra
235479	Puñal de Gran mariscal
235480	Partehuesos de Gran mariscal
235481	Rebanadora de Gran mariscal
235497	Jarabe de las arenas
235511	Cristal resonador qiraji amarillo impecable
235512	Cristal resonador qiraji verde impecable
235513	Cristal resonador qiraji azul impecable
235514	Cristal resonador qiraji rojo impecable
235517	Antorcha
235526	Fórmula: Encantar brazales: poder con hechizos
235528	Fórmula: Encantar brazales: agilidad
235529	Mirilla de obsidiana
235530	Esquema: mirilla de obsidiana
235597	Notas sobre hechizos: Congelación profunda
235598	Notas sobre hechizos: Venas heladas
235599	Notas sobre hechizos: Anomalía temporal
235600	Runa de Tormenta divina
235601	Runa de Fanatismo
235602	Runa de Martillo del honrado
235603	Runa de Venganza recta
235604	Runa de Escudo de rectitud
235605	Runa de Conmoción y terror
235785	"Llave" de la jaula del Paso de la Muerte
235786	Bibelot de Karazhan
235787	Rama de maderaférrea antigua
235788	Fuego fatuo entusiasta
235789	Llama de la vida
235790	Pirotigma encantada
235825	Jarabe de las arenas
235852	Bolsa violeta
235867	Pedazo de papiro
235868	Baluarte de ira
235869	Capucha del maestro
235870	Yelmo de cadenas tintineantes
235871	Yelmo de la muerte celosa
235872	Braciles de acechador
235873	Guardianes de la cripta
235874	Manijas de cultor
235875	Guantes de cavatumbas
235876	Manoplas de pecador
235877	Guanteletes de fanático
235878	Cinturón maléfico
235879	Eslabones livianos
235880	Suelas de mendigo
235881	Alpargatas terroríficas
235882	Pasos castañeantes
235883	Traspiés de buceapozos
235884	Sello espectral
235885	Anillo espantoso
235886	Broche de Kaigy
235887	Gargantilla de Barian
235888	Mazapalo
235889	Bastón de sirviente
235890	Aguja de tejesombras
235891	Vieja fiable
235892	Espina dorsal de jinete oscuro
235893	Grimorio Vinculasombras
235894	Muerte de orador del Sino
236002	Lista de componentes
236005	Coraza de acorator
236006	Quijotes de acorator
236007	Casco de acorator
236008	Espaldares de acorator
236009	Escarpes de acorator
236010	Guanteletes de acorator
236011	Guardarrenes de acorator
236012	Brazales de acorator
236013	Anillo de acorator
236014	Loriga de acorator
236015	Escarcelas de acorator
236016	Cuernos de acorator
236017	Hombreras de acorator
236018	Grebas de acorator
236019	Mandiletes de acorator
236020	Cinturón de acorator
236021	Muñequeras de acorator
236022	Sortija de acorator
236023	Coraza Segahuesos
236024	Quijotes Segahuesos
236025	Casco Segahuesos
236026	Espaldares Segahuesos
236027	Escarpes Segahuesos
236028	Guanteletes Segahuesos
236029	Guardarrenes Segahuesos
236030	Brazales Segahuesos
236031	Anillo Segahuesos
236032	Cinturón Segahuesos
236033	Botines Segahuesos
236034	Sortija de Segahuesos
236035	Manto Segahuesos
236036	Leotardos Segahuesos
236037	Máscara Segahuesos
236038	Mandiletes Segahuesos
236039	Coselete Segahuesos
236040	Guardamuñecas Segahuesos
236041	Anillo del Acechacriptas
236042	Guardamuñecas Acechacriptas
236043	Guerrera Acechacriptas
236044	Bufas Acechacriptas
236045	Musleras Acechacriptas
236046	Celada Acechacriptas
236047	Manoplas Acechacriptas
236048	Faja Acechacriptas
236049	Botas Acechacriptas
236050	Avambrazos Acechacriptas
236051	Cinturón Acechacriptas
236052	Espaldares Acechacriptas
236053	Leotardos Acechacriptas
236054	Visor Acechacriptas
236055	Guanteletes Acechacriptas
236056	Sortija del Acechacriptas
236057	Grebas Acechacriptas
236058	Coraza Acechacriptas
236059	Sandalias corazón de peste
236060	Leotardos corazón de peste
236061	Ataduras corazón de peste
236062	Toga corazón de peste
236063	Guantes corazón de peste
236064	Aro corazón de peste
236065	Hombreras corazón de peste
236066	Cinturón corazón de peste
236067	Anillo corazón de peste
236068	Guardamuñecas corazón de peste
236069	Guardarrenes corazón de peste
236070	Manto corazón de peste
236071	Pantalones corazón de peste
236072	Corona corazón de peste
236073	Manoplas corazón de peste
236074	Aro de corazón de peste
236075	Botas corazón de peste
236076	Atuendo corazón de peste
236077	Ataduras de Pirofrío
236078	Cinturón de Pirofrío
236079	Leotardos de Pirofrío
236080	Sandalias de Pirofrío
236081	Toga de Pirofrío
236082	Guantes de Pirofrío
236083	Aro de Pirofrío
236084	Hombreras de Pirofrío
236085	Anillo de Pirofrío
236087	Cubremuñecas de Pirofrío
236088	Guardarrenes de Pirofrío
236089	Manto de Pirofrío
236090	Pantalones de Pirofrío
236091	Caperuza de Pirofrío
236092	Mitones de Pirofrío
236093	Sortija de Pirofrío
236094	Botas de Pirofrío
236095	Atuendo de Pirofrío
236097	Toga de Fe
236098	Cinturón de Fe
236099	Sandalias de Fe
236100	Ataduras de Fe
236101	Leotardos de Fe
236102	Hombreras de Fe
236103	Aro de Fe
236104	Guantes de Fe
236105	Anillo de Fe
236106	Muñequeras de Fe
236107	Faja de Fe
236108	Manto de Fe
236109	Pantalones de Fe
236110	Corona de Fe
236111	Manos de Fe
236112	Sortija de Fe
236113	Botas de Fe
236114	Atuendo de Fe
236115	Guerrera de Redención
236116	Anillo de Redención
236117	Celada de Redención
236118	Manoplas de Redención
236119	Guardamuñecas de Redención
236120	Faja de Redención
236121	Musleras de Redención
236122	Bufas de Redención
236123	Botas de Redención
236124	Avambrazos de Redención
236125	Cinturón de Redención
236126	Hombreras de Redención
236127	Leotardos de Redención
236128	Casco de Redención
236129	Guantes de Redención
236130	Sortija de Redención
236131	Grebas de Redención
236132	Coraza de Redención
236133	Brazales de Redención
236134	Guardarrenes de Redención
236135	Espaldares de Redención
236136	Quijotes de Redención
236137	Corona de Redención
236138	Guanteletes de Redención
236139	Aro de Redención
236140	Escarpes de Redención
236141	Coselete de Redención
236142	Manoplas Rompeterra
236143	Musleras Rompeterra
236144	Celada Rompeterra
236145	Bufas Rompeterra
236146	Botas Rompeterra
236147	Guerrera Rompeterra
236148	Faja Rompeterra
236149	Guardamuñecas Rompeterra
236150	Anillo del Apocalíptico
236151	Ataduras Rompeterra
236152	Cordón Rompeterra
236153	Manto Rompeterra
236154	Falda Rompeterra
236155	Corona Rompeterra
236156	Mitones Rompeterra
236157	Sortija del Apocalíptico
236158	Grebas Rompeterra
236159	Abrazo Rompeterra
236160	Brazales Rompeterra
236162	Guardarrenes Rompeterra
236163	Espaldares Rompeterra
236164	Quijotes Rompeterra
236165	Visera Rompeterra
236166	Guantes Rompeterra
236167	Aro del Apocalíptico
236168	Escarpes Rompeterra
236169	Coselete Rompeterra
236170	Avambrazos Rompeterra
236171	Cinturón Rompeterra
236172	Cubrehombros Rompeterra
236173	Leotardos Rompeterra
236174	Casco Rompeterra
236175	Mandiletes Rompeterra
236176	Sello del Apocalíptico
236177	Botines Rompeterra
236179	Armadura Rompeterra
236182	Celada Caminasueños
236183	Guardamuñecas Caminasueños
236184	Manoplas Caminasueños
236185	Botas Caminasueños
236186	Guerrera Caminasueños
236187	Faja Caminasueños
236188	Musleras Caminasueños
236189	Bufas Caminasueños
236190	Anillo del Caminasueños
236192	Ataduras Caminasueños
236193	Cordón Caminasueños
236194	Manto Caminasueños
236195	Falda Caminasueños
236196	Caperuza Caminasueños
236197	Mitones Caminasueños
236198	Sortija del Caminasueños
236199	Sandalias Caminasueños
236200	Cuero Caminasueños
236201	Brazales Caminasueños
236202	Guardarrenes Caminasueños
236203	Espaldares Caminasueños
236204	Leotardos Caminasueños
236205	Tocado Caminasueños
236206	Guanteletes Caminasueños
236207	Aro del Caminasueños
236208	Escarpes Caminasueños
236209	Armadura Caminasueños
236210	Cubremuñecas Caminasueños
236211	Fajín Caminasueños
236212	Hombreras Caminasueños
236213	Calzas Caminasueños
236214	Capucha Caminasueños
236215	Mandiletes Caminasueños
236216	Sello del Caminasueños
236217	Apisonadoras Caminasueños
236218	Jubón Caminasueños
236219	Presagista de la Fatalidad
236220	Atuendo de necrocaballero
236221	Brazo de servo mal colocado
236222	Guerrera de piel de necrófago
236223	Anillo de la llama eterna
236224	Rodela estigia
236225	Faja de la furia elemental
236226	Espaldares de la furia elemental
236227	Cinturón del Gran Cruzado
236228	Bufas del Gran Cruzado
236229	Leotardos del Gran Cruzado
236230	Leotardos de la furia elemental
236231	Coraza profanada
236232	Guardarrenes profanados
236233	Guanteletes profanados
236234	Escarpes profanados
236235	Brazales profanados
236236	Casco profanado
236237	Espaldares profanados
236238	Quijotes profanados
236239	Sandalias profanadas
236240	Hombreras profanadas
236241	Aro profanado
236242	Toga profanada
236243	Guantes profanados
236244	Cinturón profanado
236245	Ataduras profanadas
236246	Leotardos profanados
236247	Guardamuñecas profanadas
236248	Botas profanadas
236249	Celada profanada
236250	Manoplas profanadas
236251	Guerrera profanada
236252	Faja profanada
236253	Musleras profanadas
236254	Bufas profanadas
236255	Guardamuñecas de Venganza
236256	Toque de Escarcha
236257	Gema de Nerubis
236258	Capa de seda de demonio de cripta
236259	Sortija de Plegarias sin respuesta
236260	Espaldares Deliriohelado
236261	Colgante de piedra malicia
236262	Hombreras polares
236263	Remordimiento de viuda
236264	El abrazo de la viuda
236265	Espada de aparición
236266	Colgante de Nombres Olvidados
236267	Toga tejida con cristal
236268	Beso de la araña
236269	Colmillo de Maexxna
236270	Hachuela de hueso partido
236271	Tratado sobre Luz
236272	Capa de la Plaga
236273	Sortija de lo Inevitable
236274	Sortija de granizo
236275	Corazón frígido de Noth
236276	Tótem de Agua que fluye
236277	Collar de necropsia
236278	Tocado glacial
236279	Sombrero de preceptor
236280	Quijotes de Matanza
236281	Almófar de escamas heladas
236282	Reflexión de Loatheb
236283	Anillo de fervor espiritual
236284	Bastón de azufre
236285	El Ojo de Nerub
236286	Sortija de Fuerzas antinaturales
236287	División
236288	El portador de peste
236289	Capa de Sutura
236290	Varita de Fortunas
236291	Sortija de Reanimación
236292	Bruma de medianoche
236293	Inyector tóxico
236294	Bufas de escamas heladas
236295	Manto glacial
236296	Acuerdo con la Muerte
236297	El fin de los sueños
236298	Manto cubierto de Escarcha
236299	Mandoble de Poderío profano
236300	Collar perdido de Gluth
236301	Compendio de Mano de Poder
236302	Ojo de Disminución
236303	Leotardos de Polaridad
236304	Caja torácica de abominación con placas
236305	Aguja del Crepúsculo
236306	El castigador
236307	Velo de eclipse
236308	Ídolo de Longevidad
236309	Faja del Mentor
236310	Varita de la Muerte susurrante
236311	Sello del defensor caído
236312	Iblis, hoja del serafín caído
236313	Las ataduras del cosechador de almas
236314	Botas de desplazamiento
236315	Casco polar
236316	Collera de sádico
236317	Vis'era la Sacatripas
236318	Sello del condenado
236319	Leotardos de Apocalipsis
236320	Calor de Perdón
236321	Gran maza del cruzado redimido
236322	Hilo de alma
236323	Recuperación de la Plaga
236324	Poder de la Plaga
236325	Entereza de la Plaga
236326	Poderío de la Plaga
236327	Capa de la Necrópolis
236328	Ojo izquierdo de Sapphiron
236329	Ojo de los muertos
236330	Ojo derecho de Sapphiron
236331	La esencia contenida de Sapphiron
236333	Sudario de Dominio
236334	Emblema de destripador
236335	Puños del Implacable
236336	La cara de la Muerte
236337	Glifo de Desvío
236338	Garra de vermis de escarcha
236339	Gressil, alba de la ruina
236340	Poderío de Menethil
236341	El frío voraz
236342	Dije iracundo de Tempestira
236343	Caída del Rey
236344	Esclavizador nerubiano
236345	Gema de Inocentes atrapados
236346	Buscador de almas
236347	Escudo de Condena
236348	Martillo del Vacío Abisal
236349	Dedo condena
236350	La filacteria de Kel'Thuzad
236351	Marca del Campeón
236352	Marca del Campeón
236354	Sello del Alba de aspirante
236355	Sello del Alba de iniciado
236356	Sello del Alba de escudero
236357	Sello del Alba de caballero
236358	Sello del Alba de templario
236360	Sello del Alba de campeón
236361	Sello del Alba de vanguardia
236362	Sello del Alba de cruzado
236363	Sello del Alba de comandante
236364	Sello del Alba de alto señor
236374	Sello del Alba de comandante
236375	Sello del Alba de alto señor
236376	Sello del Alba de cruzado
236378	Sello del Alba de vanguardia
236379	Sello del Alba de campeón
236380	Sello del Alba de templario
236382	Sello del Alba de caballero
236383	Sello del Alba de escudero
236384	Sello del Alba de iniciado
236385	Sello del Alba de aspirante
236386	Sello del Alba de alto señor
236388	Sello del Alba de comandante
236389	Sello del Alba de cruzado
236390	Sello del Alba de vanguardia
236391	Sello del Alba de campeón
236392	Sello del Alba de templario
236393	Sello del Alba de caballero
236394	Sello del Alba de escudero
236395	Sello del Alba de iniciado
236396	Sello del Alba de aspirante
236397	Remanentes de valor
236398	Atiesh, gran báculo del Guardián
236399	Atiesh, gran báculo del Guardián
236400	Atiesh, gran báculo del Guardián
236401	Atiesh, gran báculo del Guardián
236414	Cajón de suministros de Minahonda dañado
236417	Alma del táctico
236418	Alma del veterano de guerra
236419	Alma del pronosticador de batalla
236420	Alma del buscasangre
236421	Alma del titán
236422	Alma del destructor
236423	Alma del vinculado a la muerte
236424	Alma del sanguinista
236425	Alma del bloqueador inmaculado
236426	Alma del salvaje
236427	Alma de enemistad
236428	Alma del deflector
236429	Alma del desfacedor
236430	Alma del incesante
236431	Alma del atronador
236432	Alma del centinela
236433	Alma del zarpasur
236434	Alma del gladiador
236435	Alma de la réplica
236436	Alma del evasivo
236437	Alma del toxicólogo
236438	Alma del verdugo
236439	Alma del oportunista
236440	Alma del carnicero
236441	Alma del fantasma
236442	Alma del malandrín
236443	Alma del amante de la adrenalina
236444	Alma del sabio del cuchillo
236445	Alma del acechador
236446	Alma del eficiente
236447	Alma del malabarista de cuchillos
236448	Alma del maestro de las sombras
236449	Alma del equilibrista
236450	Alma del camorrista preparado
236451	Alma del cinturón negro
236452	Alma del esgrimista
236453	Alma del espadachín
236454	Alma del sanguinario
236455	Alma del transfusor
236456	Alma del refinado
236457	Alma del exterminador
236458	Alma del sembrador de podredumbre
236459	Alma del malévolo
236460	Alma del sombramántico
236461	Alma del presagista del caos
236462	Alma del prendellamas
236463	Alma del pastor infernal
236464	Alma del señor de los demonios
236465	Alma del exorcista de demonios
236466	Alma del dolorido
236467	Alma del espectro de llama
236468	Alma del devoracarne
236469	Alma del abisal
236470	Alma del natovacío
236471	Alma de la hoja umbría
236472	Alma del ritualista
236473	Alma del propagador de dolor
236474	Alma del embaucador
236475	Alma del buscapresas
236476	Alma del tirador certero
236477	Alma del hostigador de peligros
236478	Alma del alternador
236479	Alma del toxinólogo
236480	Alma del cazarrecompensas
236481	Alma del tirador diestro
236482	Alma del cuidador de bestias
236483	Alma del maestro de canes
236484	Alma del domador de alfas
236485	Alma del montero
236487	Alma del vengador
236488	Alma de los ecos
236489	Alma del azotador letal
236490	Alma del cinético
236491	Alma del estratega
236492	Alma del golpeador mortífero
236493	Alma del sanador apresurado
236494	Alma del refinado
236495	Alma del celebrante
236496	Alma del fiel
236497	Alma del fortuito
236498	Alma del resonante
236499	Alma del devoto
236500	Alma del arzobispo
236501	Alma del penitente
236502	Alma del guarda del alma
236503	Alma del caminador del crepúsculo
236504	Alma del rompementes
236505	Alma del mortífero
236506	Alma de la fuente de espíritus
236507	Alma del fanático
236508	Alma del profanador inflexible
236509	Alma del desacatador
236510	Alma del pesteador
236511	Alma del reverberante
236512	Alma del cronosanador
236513	Alma del anhelo temporal
236514	Alma del precognitivo
236515	Alma del arcanista
236516	Alma del cuidador eterno
236517	Alma del conminahechizos
236518	Alma del forjarresguardos
236519	Alma de la conquista del invierno
236520	Alma del criomántico
236521	Alma del evocador
236522	Alma del elementalista
236523	Alma del armero mágico
236524	Alma del calcinante
236525	Alma de la convergencia abrasadora
236526	Alma de la llamarada perpetua
236527	Alma del pirómano
236528	Alma del encendedor
236529	Alma del incendiario
236530	Alma del bloqueador inmaculado
236531	Alma del celador de la Luz
236532	Alma del defensor radiante
236533	Alma del portaescudos
236534	Alma del bastión
236535	Alma del ajustador de cuentas
236536	Alma del acorazado
236537	Alma del guardián
236538	Alma del pacificador
236539	Alma del refinado
236540	Alma del parangón
236541	Alma del inquisidor
236542	Alma del soberano
236543	Alma del dominador
236544	Alma del vindicador
236545	Alma del altruista
236546	Alma del enjuiciador
236547	Alma del portador del sello
236548	Alma del justicar
236549	Alma del adjudicador
236550	Alma del ascendiente
236551	Alma del reprensor
236552	Alma del excomulgador
236553	Alma del iluminado
236554	Alma del exiliado
236555	Alma del templario
236556	Alma del viajero del viento
236557	Alma del maestro de escudos
236558	Alma del protector totémico
236559	Alma del amortiguador de choques
236560	Alma del baluarte espiritual
236561	Alma del invocador de vorágines
236562	Alma del caminante de lava
236563	Alma del verdadero alfa
236564	Alma del guardián de tótems
236565	Alma de los ancestros
236566	Alma del tejespíritus
236567	Alma del caminante de las aguas
236568	Alma del cuidador de las tormentas
236569	Alma del sabio elemental
236570	Alma del vitalista
236571	Alma del sanador espiritual
236572	Alma del refinado
236573	Alma del jefe de la tribu
236574	Alma cargada de furia
236575	Alma del rompetormentas
236576	Alma de la tempestad
236577	Alma del machacador sísmico
236578	Alma del clamallamas
236579	Alma del volcán
236580	Alma de la llama furibunda
236581	Alma del maestro de los elementos
236582	Alma del miembro de la tribu
236583	Alma del espíritu guía
236584	Alma del ancestro
236585	Alma de los elementos
236586	Alma del sabio de lava
236587	Alma del celador ancestral
236588	Alma del corrupto
236589	Alma de la pata ligera
236590	Alma del feroz
236591	Alma del cambiante
236592	Alma del territorial
236593	Alma de la bestia
236594	Alma del lacerador
236595	Alma del furioso
236596	Alma del mutilador
236597	Alma del enervador
236598	Alma del nutricio
236599	Alma del calmado
236600	Alma del caminasueños
236601	Alma del cuidador de arboleda
236602	Alma del sabio emplumado
236603	Alma del profeta benevolente
236604	Alma del tejevidas
236605	Alma del iluminador
236606	Alma de instintos depredadores
236607	Alma del destripador
236608	Alma de la zarpa
236609	Alma del orgulloso
236610	Alma del bárbaro
236611	Alma del frenético
236612	Alma del desangrador
236613	Alma del guardián de espinas
236614	Alma del lunático
236615	Alma del llamaestrellas
236616	Alma de la noche
236617	Alma de los guardianes
236618	Alma del colérico
236619	Alma del distinguido
236620	Alma del ascendiente astral
236621	Alma del invocador de cometas
236622	Alma del bosque
236623	Alma de experiencia animal
236642	Manijas de ensalmador
236643	Guantes del Vigía de la noche
236644	Manoplas de plañidera
236645	Guanteletes de controlador de la Luz
236656	Runa congelada
236657	Rama podrida de Burbujas
236658	Trofeo de espina dorsal de Burbujas
236660	Colmillo trol de Burbujas
236661	Caja torácica de rivalidad de Burbujas
236662	Riendas de Guerra
236663	Riendas de Conquista
236664	Riendas de Muerte
236665	Riendas de Hambruna
236690	Capa glacial
236692	Guantes glaciales
236693	Muñequeras glaciales
236694	Jubón glacial
236695	Coraza Deliriohelado
236696	Brazales Deliriohelado
236697	Guanteletes Deliriohelado
236698	Brazales de escamas heladas
236699	Coraza de escamas heladas
236700	Guanteletes de escamas heladas
236701	Brazales polares
236702	Guerrera polar
236703	Guantes polares
236704	Muñequeras heladas
236705	Guantes helados
236706	Jubón helado
236707	Guerrera de Asesino de no-muertos
236708	Coraza de Asesino de no-muertos
236709	Coselete de Asesino de no-muertos
236710	Guardamuñecas de Asesino de no-muertos
236711	Cubremuñecas de Asesino de no-muertos
236712	Brazales de Asesino de no-muertos
236713	Manijas de Asesino de no-muertos
236714	Guanteletes de Asesino de no-muertos
236715	Manoplas de Asesino de no-muertos
236716	Brazales de Limpieza de no-muertos
236717	Guantes de Limpieza de no-muertos
236718	Toga de Limpieza de no-muertos
236719	Brazales de Purificación de no-muertos
236720	Guantes de Purificación de no-muertos
236721	Toga de Purificación de no-muertos
236722	Brazales de Resguardo de no-muertos
236723	Guantes de Resguardo de no-muertos
236724	Toga de Resguardo de no-muertos
236725	Cubremuñecas de Limpieza de no-muertos
236726	Manijas de Limpieza de no-muertos
236727	Guerrera de Limpieza de no-muertos
236728	Cubremuñecas de Purificación de no-muertos
236729	Manijas de Purificación de no-muertos
236730	Guerrera de Purificación de no-muertos
236731	Cubremuñecas de Resguardo de no-muertos
236732	Manijas de Resguardo de no-muertos
236733	Guerrera de Resguardo de no-muertos
236734	Guardamuñecas de Limpieza de no-muertos
236735	Manoplas de Limpieza de no-muertos
236736	Coselete de Limpieza de no-muertos
236737	Guardamuñecas de Resguardo de no-muertos
236738	Manoplas de Resguardo de no-muertos
236739	Coselete de Resguardo de no-muertos
236740	Guardamuñecas de Purificación de no-muertos
236741	Manoplas de Purificación de no-muertos
236742	Coselete de Purificación de no-muertos
236743	Brazales de Purificación de no-muertos
236744	Guanteletes de Purificación de no-muertos
236745	Coraza de Purificación de no-muertos
236746	Brazales de Resguardo de no-muertos
236747	Guanteletes de Resguardo de no-muertos
236748	Coraza de Resguardo de no-muertos
236750	Corazón de la Fatalidad
236782	Collera de Sairuh
236786	Corazón de la Fatalidad
236864	Carcaj de escarcha de alma
236869	Faltriquera para munición de escarcha de alma
236871	Sensores de censor aterradores
236872	Esquema: sensores de censor aterradores
236878	Reliquia misteriosa
236879	Reliquia misteriosa
236880	Reliquia misteriosa
237011	Llave del rastrillo
237020	Insignia Escarlata
237023	Arbusto desplegable
237024	Entrada para la ópera
237037	Tarjeta de miembro del Club Alcurnia
237041	Tomo de Bengala encantada
237143	Órdenes de la comandante
237163	Cráneo de héroe antiguo
237261	Arena fina
237263	Bolsa de suministros
237275	Casco Deliriohelado
237277	Leotardos escarchados
237278	El purificador
237279	Amuleto del alba
237280	Medallón del alba
237281	Brazales de Esperanza
237282	Brazales de Subterfugio
237283	Talismán de Ascensión
237284	Bolsa de suministros
237285	Sortija de Resolución
237286	Sortija de Piedad
237287	Último recurso de Verimonde
237288	Yelmo de cuero santificado
237289	Leotardos del Cazador de la Peste
237290	Leotardos Deliriohelado
237291	Leotardos glaciales
237292	Leotardos polares
237293	Leotardos de escamas heladas
237294	Garra helada de Ramaladni
237302	Tabardo del Enclave Escarlata
237381	Anillo profanado
237386	Cajón de suministros de Minahonda destrozado
237504	Envío de suministros
237512	Hoja de inquisición
237577	Tótem de Poderío profano
237773	Palabra de deshielo
237810	Piedra de afilar consagrada equilibrada
237814	Musleras de láminas de centinela
237815	Leotardos de seda de centinela
237817	Pantalones de pellejo de lagarto de centinela
237818	Pantalones de cuero de centinela
237819	Leotardos de anillas de centinela
237820	Leotardos de seda de escolta
237821	Pantalones de pellejo de lagarto de escolta
237822	Pantalones de cuero de escolta
237823	Leotardos de malla de escolta
237824	Leotardos de anillas de escolta
237825	Musleras de placas de centinela
237826	Musleras de placas de escolta
238234	Aceite de zahorí bendito
238241	Piedra de afilar consagrada
238264	Caperuza de augur Escarlata
238265	Manto de augur Escarlata
238266	Prendas de augur Escarlata
238267	Puños de augur Escarlata
238268	Mitones de augur Escarlata
238269	Correa de augur Escarlata
238270	Leotardos de augur Escarlata
238271	Suelas de augur Escarlata
238272	Bandana de infiltrado Escarlata
238273	Hombreras de infiltrado Escarlata
238274	Jubón de infiltrado Escarlata
238275	Brazales de infiltrado Escarlata
238276	Guantes de infiltrado Escarlata
238277	Cinturón de infiltrado Escarlata
238278	Pantalones de infiltrado Escarlata
238279	Zapatos de infiltrado Escarlata
238280	Almófar de cazador Escarlata
238281	Espaldares de cazador Escarlata
238282	Cadena de cazador Escarlata
238283	Guardamuñecas de cazador Escarlata
238284	Manoplas de cazador Escarlata
238285	Cinto de cazador Escarlata
238286	Musleras de cazador Escarlata
238287	Botas de cazador Escarlata
238288	Casco de soldado Escarlata
238289	Bufas de soldado Escarlata
238290	Peto de soldado Escarlata
238291	Protectores de soldado Escarlata
238292	Mandiletes de soldado Escarlata
238293	Guardarrenes de soldado Escarlata
238294	Quijotes de soldado Escarlata
238295	Apisonadoras de soldado Escarlata
238298	Patrón: caperuza de augur Escarlata
238299	Patrón: manto de augur Escarlata
238300	Patrón: prendas de augur Escarlata
238301	Patrón: puños de augur Escarlata
238302	Patrón: mitones de augur Escarlata
238303	Patrón: correa de augur Escarlata
238304	Patrón: leotardos de augur Escarlata
238305	Patrón: suelas de augur Escarlata
238306	Patrón: bandana de infiltrado Escarlata
238307	Patrón: hombreras de infiltrado Escarlata
238308	Patrón: jubón de infiltrado Escarlata
238309	Patrón: brazales de infiltrado Escarlata
238310	Patrón: guantes de infiltrado Escarlata
238311	Patrón: cinturón de infiltrado Escarlata
238312	Patrón: pantalones de infiltrado Escarlata
238313	Patrón: zapatos de infiltrado Escarlata
238314	Patrón: almófar de cazador Escarlata
238315	Patrón: espaldares de cazador Escarlata
238316	Patrón: cadena de cazador Escarlata
238317	Patrón: guardamuñecas de cazador Escarlata
238318	Patrón: manoplas de cazador Escarlata
238319	Patrón: cinto de cazador Escarlata
238320	Patrón: musleras de cazador Escarlata
238321	Patrón: botas de cazador Escarlata
238322	Diseño: casco de soldado Escarlata
238323	Diseño: bufas de soldado Escarlata
238324	Diseño: peto de soldado Escarlata
238325	Diseño: protectores de soldado Escarlata
238326	Diseño: mandiletes de soldado Escarlata
238327	Diseño: guardarrenes de soldado Escarlata
238328	Diseño: quijotes de soldado Escarlata
238329	Diseño: apisonadoras de soldado Escarlata
238348	El hacha de extirpación
238349	Leotardos de piel de abominación
238350	Daga focal de Desdén
238351	La garra helada
238352	Gargantilla helada de Desdén
238353	Manto de Lady Falther'ess
238354	Dedo de Lady Falther'ess
238355	Cadenas del Exánime
238356	Pretina de Balzaphon
238357	Bastón de Balzaphon
238358	Muslo de Bosque Negro
238360	Rodela de Lord Bosque Negro
238361	Hoja de Lord Bosque Negro
238362	Brazales de Arreglo
238363	La garra de las Sombras
238364	Capa de Revanchion
238637	Filete de merodeador
238638	Filete de falda
238639	Tortilla del alba
238641	Festín de pez moteado
238642	Gran festín de langostas
238645	Receta: filete de merodeador
238646	Receta: filete de falda
238647	Receta: tortilla del alba
238649	Receta: festín de pez moteado
238650	Receta: gran festín de langostas
238681	Bolsa polvorienta
238687	Gran maza de embate
238734	Caja de manitas: teletransporte
238735	Caja de manitas: propulsiones de nitro
238736	Caja de manitas: desplazamiento magnético
238737	Caja de manitas
238781	Transportador cuasiseguro: Nuevo Avalon
238782	Esquema: caja de manitas
238783	Esquema: caja de manitas: teletransporte
238784	Esquema: caja de manitas: propulsiones de nitro
238785	Esquema: caja de manitas: desplazamiento magnético
238786	Esquema: modificación: teletransporte
238787	Esquema: modificación: propulsiones de nitro
238788	Esquema: modificación: desplazamiento magnético
238789	Esquema: transportador cuasiseguro: Nuevo Avalon
238794	Sobras nada apetitosas
238811	Manzana jugosa
238830	Mira de manzana
238831	Cuerda de manzana
238899	Surtido de peces
238925	Carcaj Escarlata
238926	Faltriquera de munición Escarlata
238927	Patrón: carcaj Escarlata
238928	Patrón: faltriquera de munición Escarlata
238935	Carne delicadamente plagada
238945	Caladbajopiedra
238960	Cajón de intendente
238961	Caladbolg
238985	Cajón pesado
239010	Empuñadura de la Crematoria
239011	Fragmento de luz cristalizada
239012	Astilla de luz cristalizada
239013	Hacha cristalina
239016	Sales sagradas
239017	Especias exquisitas
239021	Libro de cocina de Carrie
239060	Voluntad de la Montaña
239092	Franqueo absurdamente caro
239097	Llave de la catedral
239117	Cáliz de cruzado
239119	Flecha sagrada
239147	Morral de cruzado
239148	Bolsa de tela del Alba Carmesí
239149	Patrón: morral de cruzado
239150	Patrón: bolsa de tela del Alba Carmesí
239159	T03 - Enclave Escarlata - Escudo de capitán
239196	Hoja forjada por la Luz arruinada
239197	Hoja reforjada de la Crematoria
239215	Emblema carbonizado
239216	Hierro forjado por la Luz
239218	Nota de labrapiedras
239219	Emblema de la Crematoria
239222	Esquema: arbusto desplegable
239223	Casa de atrezo
239225	Pluma elegante
239246	Lista de la compra de Fundefusibles
239248	Caja de trastos Escarlata
239292	Notas de Forjador
239301	Crematoria corrupta
239302	Cinturón de uniforme Escarlata
239316	Churumbele de triangulación
239512	Muñequeras de hiendeluz
239513	Cinturón de hiendeluz
239514	Mandiletes de hiendeluz
239515	Grebas de hiendeluz
239516	Sobrehombros de hiendeluz
239517	Gran yelmo de hiendeluz
239518	Escarcelas de hiendeluz
239519	Loriga de hiendeluz
239520	Brazales de hiendeluz
239521	Guardarrenes de hiendeluz
239522	Guanteletes de hiendeluz
239523	Escarpes de hiendeluz
239524	Espaldares de hiendeluz
239525	Casco de hiendeluz
239526	Quijotes de hiendeluz
239527	Coraza de hiendeluz
239529	Coraza de acechador de albas
239530	Grebas de acechador de albas
239531	Guanteletes de acechador de albas
239532	Visor de acechador de albas
239533	Leotardos de acechador de albas
239534	Espaldares de acechador de albas
239535	Cinturón de acechador de albas
239536	Avambrazos de acechador de albas
239537	Botas de acechador de albas
239538	Faja de acechador de albas
239539	Manoplas de acechador de albas
239540	Celada de acechador de albas
239541	Musleras de acechador de albas
239542	Bufas de acechador de albas
239543	Túnica de acechador de albas
239544	Guardamuñecas de acechador de albas
239547	Guardamuñecas de animaocaso
239548	Coselete de animaocaso
239549	Mandiletes de animaocaso
239550	Máscara de animaocaso
239551	Leotardos de animaocaso
239552	Manto de animaocaso
239553	Botines de animaocaso
239554	Cinturón de animaocaso
239555	Brazales de animaocaso
239556	Guardarrenes de animaocaso
239557	Guanteletes de animaocaso
239558	Escarpes de animaocaso
239559	Espaldares de animaocaso
239560	Casco de animaocaso
239561	Quijotes de animaocaso
239562	Coraza de animaocaso
239565	Atuendo de revelación
239572	Botas de revelación
239574	Manoplas de revelación
239575	Corona de revelación
239577	Pantalones de revelación
239581	Manto de revelación
239582	Faja de revelación
239583	Muñequeras de revelación
239584	Guantes de revelación
239585	Aro de revelación
239586	Hombreras de revelación
239587	Leotardos de revelación
239588	Ataduras de revelación
239589	Sandalias de revelación
239590	Cinturón de revelación
239591	Toga de revelación
239694	Pacto de la Luz
239695	Corcel Escarlata
239696	Empuñadura de la Crematoria
239698	Tejido de tela del Alba
239706	Escarpes consagrados
239707	Casco consagrado
239708	Espaldares consagrados
239709	Quijotes consagrados
239710	Sandalias consagradas
239712	Hombreras consagradas
239714	Aro consagrado
239715	Toga consagrada
239716	Guantes consagrados
239718	Cinturón consagrado
239719	Ataduras consagradas
239721	Leotardos consagrados
239722	Guardamuñecas consagrados
239726	Botas consagradas
239729	Celada consagrada
239730	Manoplas consagradas
239731	Guerrera consagrada
239756	Faja consagrada
239757	Musleras consagradas
239758	Bufas consagradas
239759	Brazales consagrados
239760	Guardarrenes consagrados
239761	Coraza consagrada
239762	Guanteletes consagrados
239764	Filohoja carmesí
240018	Manual de manitas de Fundefusibles
240020	Musleras de inquisición
240021	Bufas de inquisición
240022	Botas de inquisición
240023	Avambrazos de inquisición
240024	Cinturón de inquisición
240025	Hombreras de inquisición
240026	Leotardos de inquisición
240027	Casco de inquisición
240028	Guantes de inquisición
240029	Grebas de inquisición
240030	Coraza de inquisición
240031	Brazales de inquisición
240032	Guardarrenes de inquisición
240033	Espaldares de inquisición
240034	Quijotes de inquisición
240035	Corona de inquisición
240036	Guanteletes de inquisición
240037	Escarpes de inquisición
240038	Coselete de inquisición
240039	Guerrera de inquisición
240040	Celada de inquisición
240041	Manoplas de inquisición
240042	Guardamuñecas de inquisición
240043	Faja de inquisición
240044	Cubremuñecas de hojafuego
240045	Guardarrenes de hojafuego
240046	Manto de hojafuego
240047	Pantalones de hojafuego
240048	Caperuza de hojafuego
240049	Mitones de hojafuego
240050	Botas de hojafuego
240051	Atuendo de hojafuego
240052	Ataduras de hojafuego
240053	Cinturón de hojafuego
240054	Hombreras de hojafuego
240055	Leotardos de hojafuego
240056	Aro de hojafuego
240057	Guantes de hojafuego
240058	Sandalias de hojafuego
240059	Túnica de hojafuego
240060	Cubremuñecas de oteador
240061	Fajín de oteador
240062	Hombreras de oteador
240063	Calzas de oteador
240064	Capucha de oteador
240065	Mandiletes de oteador
240066	Apisonadoras de oteador
240067	Jubón de oteador
240068	Ataduras de oteador
240069	Cordón de oteador
240070	Manto de oteador
240071	Falda de oteador
240072	Caperuza de oteador
240073	Mitones de oteador
240074	Sandalias de oteador
240075	Cueros de oteador
240076	Brazales de oteador
240077	Guardarrenes de oteador
240078	Espaldares de oteador
240079	Leotardos de oteador
240080	Tocado de oteador
240081	Guanteletes de oteador
240082	Escarpes de oteador
240083	Armadura de oteador
240084	Guardamuñecas de oteador
240085	Faja de oteador
240086	Bufas de oteador
240087	Musleras de oteador
240088	Celada de oteador
240089	Manoplas de oteador
240090	Botas de oteador
240091	Guerrera de oteador
240092	Guerrera de aplastaalmas
240093	Botas de aplastaalmas
240095	Manoplas de aplastaalmas
240096	Celada de aplastaalmas
240097	Musleras de aplastaalmas
240098	Bufas de aplastaalmas
240099	Faja de aplastaalmas
240100	Guardamuñecas de aplastaalmas
240101	Coselete de aplastaalmas
240102	Escarpes de aplastaalmas
240103	Guantes de aplastaalmas
240104	Visera de aplastaalmas
240105	Quijotes de aplastaalmas
240106	Espaldares de aplastaalmas
240107	Guardarrenes de aplastaalmas
240108	Brazales de aplastaalmas
240109	Abrazo de aplastaalmas
240110	Grebas de aplastaalmas
240122	Mitones de aplastaalmas
240123	Corona de aplastaalmas
240124	Falda de aplastaalmas
240125	Manto de aplastaalmas
240126	Cordón de aplastaalmas
240127	Ataduras de aplastaalmas
240128	Armadura de aplastaalmas
240129	Botines de aplastaalmas
240130	Mandiletes de aplastaalmas
240131	Casco de aplastaalmas
240132	Bastón de prueba
240134	Leotardos de aplastaalmas
240135	Cubrehombros de aplastaalmas
240136	Cinturón de aplastaalmas
240137	Avambrazos de aplastaalmas
240138	Toga herética
240139	Sandalias heréticas
240140	Guantes heréticos
240141	Capucha herética
240142	Leotardos heréticos
240143	Hombreras heréticas
240144	Cinturón herético
240145	Ataduras heréticas
240146	Atuendo herético
240147	Manoplas heréticas
240148	Caperuza herética
240149	Pantalones heréticos
240150	Manto herético
240151	Guardarrenes heréticos
240152	Guardamuñecas heréticas
240153	Botas heréticas
240174	Solistra, colmillo de la Primera Luz
240195	Espada invisible
240832	Glándula nivifaciente
240835	Cajón de suministros de Claro de la Luna
240836	Silbato de Thisalee
240837	Cordeles del destino
240839	Thal'kituun, el invitado oculto
240841	Guardia del alto comandante
240842	Sembrador de podredumbre Escarlata
240843	Pistola ventajosa
240844	Atizadora de Putress
240845	Prototipo de imán
240846	Chatarra magnética
240848	Restos de Nordrassil
240849	Bastón del claro
240850	Martillo de puñoluz
240851	Regicidio
240852	Cuchilla carmesí
240853	Caída de la reina
240854	Piedad
240919	Ravagane
240920	Leogan
240921	Aplastadora Escarlata
240922	Engaño
240923	Duplicidad
240924	Arma de asta de la bestia
240925	Experimento 800M
240936	Crematoria inerte
240945	Porción de tarta de manzana de Carrie
240997	Espuela de Fratley
240998	Filo soporífero
241001	Caída de Tyr
241002	Remanentes del rojo
241003	Espejismo, varita ilusoria
241004	Enigma
241006	Aguja de sacrificio
241008	Condenación
241011	Gran bastón de lealtad
241012	Varita de Reanimación
241015	Égida de El Bastión Escarlata
241017	Capricho demoníaco
241018	Corazón de Nathrezim
241020	Diario completo de Putress
241021	La Luz
241022	Capa de Albar
241023	Mantón del despiadado
241024	Manteo de comandante Escarlata
241025	Bandera del almirante quebrado
241026	Chal de cardenal
241027	Guardia de celador escudo
241028	Aro Nathrezim
241029	Sortija de Baelin
241030	Anillo de fraternidad de Mason
241031	Promesa de Barthalomew
241032	Anillo de resurrección
241034	Corazón de Luz
241037	Experimento abandonado
241038	Didgeridoo de sir Dornel
241039	Infusión de almas
241068	Confalón de Stiltz
241069	Collar de asfixia
241070	Esperanza de Herod
241071	Dije del canalla Escarlata
241072	Frasco de pus
241073	Toque de la Luz
241074	Yelmo de la Cruzada Carmesí
241075	Yelmo de destructor enfurecido
241076	Capucha de la curia
241077	Sombrero de cardenal
241078	Sudario del embalsamado
241079	Peso del mundo
241080	Espaldar de Herod
241081	Crematoria corrupta
241082	Crematoria
241083	T03 - Enclave Escarlata - Espada de dos manos de banda
241084	T03 - Enclave Escarlata - Espada de Herod - Normal
241085	T03 - Enclave Escarlata - Espada de una mano
241086	Escudo pavés Escarlata
241087	Bastón Escarlata
241088	Bastón Escarlata
241089	Daga Escarlata
241090	Gran hacha Escarlata
241091	Maza Escarlata
241092	Filo Escarlata
241120	T03 - Enclave Escarlata - Espada de Herod - Magma
241121	Daga renacida
241122	Cuchillo renacido
241123	Daga renacida
241124	Cuchillo renacido
241128	Montón de portaportadores
241152	Hombreras forjadas al alba
241153	Manto de Doan
241154	Manto de piel de oso
241156	Toga contagiada
241157	Peto Escarlata
241158	Cadenas de los abandonados
241159	Atuendo de monasterio
241160	Malla de anillas del alba vetusto
241161	Coraza de templario
241162	Cuero bendecido por el sol
241163	Brazales de llamarada solar
241164	Retales de cuero Argenta
241165	Cubremuñecas de penitente
241166	Braciles del amanecer
241167	Grilletes de prisionero
241168	Mandiletes de llamarada solar
241169	Prototipo de propulsiones de nitro
241170	Protectores del Enclave
241171	Guantes de almas difuntas
241172	Guanteletes fijados de Caldoran
241173	Cincho de alto zahorí
241174	Faja del campeón renacido
241175	Cinturón portaherramientas de torturador
241176	Legado de Diesalven
241177	Falda del arcanista Escarlata
241178	Coraza de placas incondicional
241179	Leotardos de catástrofe
241180	Leotardos de escamas de luz
241181	Leotardos de anillas del alba vetusto
241182	Musleras de placas de templario
241183	Caminacenizas
241184	Sandalias de salvador
241185	Botas para entrenar osos
241186	Botas de malla escarlata pulidas
241187	Botines de guerra carmesíes
241190	Silbato para aves
241191	Fórmula: encantar arma: gran cruzado
241195	Fórmula: encantar arma 2M: gran arcanista
241201	Fórmula: encantar arma: gran hechicero
241212	Cañón gallináceo
241241	Doblón de la suerte
241613	Ya no se usa
241629	Bala de cañón Escarlata
241649	Guanteletes de la guardia de Trabalomas
241650	Poción de sanación descolorida sublime
241651	Receta: poción de sanación descolorida sublime
241652	Corazón de bestia descolorido
241653	Hoja caliente
241654	Crematoria inerte
241655	Poción de sanación mal usada
241656	Poción de sanación mal usada
241657	Hoja templada
242018	Corazón sangrante de las Tierras de la Peste
242224	Cesta de corazones
242256	Bolsa de bombas incendiarias
242257	Muestra alquímica misteriosa
242258	Notas de investigación
242266	Creación de resguardos
242267	De arcanista a archimago
242268	Si le entregas un encantamiento a un cruzado
242269	Luminosidad del gran hechicero
242270	Luminosidad del gran arcanista
242271	Luminosidad del gran cruzado
242310	Mano de justicia renacida
242311	Talismán de Leonid
242312	Sello de la familia Barthalomew
242313	Diario del Venerado
242314	Ascuas del cruzado caído
242315	Cenizas de arrogancia
242316	Polvo del desafiante
242317	Libro de plegarias profanado
242319	Nuevas muestras de la plaga
242320	Nuevas muestras de la plaga
242361	Fórmula: Encantar arma 2M: gran inquisidor
242362	Radiancia del gran inquisidor
242363	¡Quién, qué, dónde, cuándo y muere! Las cinco claves de una inquisición adecuada
242364	Tendón de dragón de luz maduro
242365	Ala de Balnazzar
242366	Sino ineludible
242367	Cuerda que nunca yerra
242425	Página de diario arrancada, hoja 1
242426	Página de diario arrancada, hoja 2
242427	Diario de Putress
242428	Página de diario arrancada, hoja 3
242429	Diario de Putress
242430	Página de diario arrancada, hoja 4
242431	Página de diario arrancada, hoja 5
242432	Diario de Putress
242433	Página de diario arrancada, hoja 6
242434	Diario de Putress
242435	Diario de Putress
242436	Diario de Putress
242465	Fragmentos de cáliz apiñados
242793	Cañón portátil
243010	Crematoria corrupta
243064	Bastón largo
243065	Varita rota
243177	Juguete ingenioso
243198	Mira de precisión avícola
243229	Piedra de hogar del Alba
243230	Hoja forjada por la Luz arruinada
243345	Bastón largo
244353	Mira de precisión avícola
244460	Caladbolg
245675	Llave de puerta interior de Gordok
246055	Mandiletes de inquisición
246056	Ajorcas de inquisición
246057	Apisonadoras de inquisición
246058	Pantalones de placas de inquisición
246059	Cordón de inquisición
246060	Loriga de inquisición
246061	Cubrehombros de inquisición
246062	Visera de inquisición
]==]
