-- ============================================================
-- AH Analyzer Pro 5.7 - Tab "Buchhaltung"
--   Zeitraum: Heute / 7 Tage / 30 Tage / Alles
--   Karten:   Einnahmen (nach AH-Anteil), Ausgaben, Gebühren, Gewinn
--   Ansichten:
--     Pro Item  - Erlös, Kosten, Gebühren, Gewinn je Item
--     Verlauf   - alle Buchungen
--     Statistik - Verkaufsquote je Item, Verkäufe nach Uhrzeit und Wochentag
--     Gold      - alle Charaktere, Gold der letzten 30 Tage
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C

local KIND_LABEL = { sale = "Verkauf", buy = "Kauf", deposit = "Einstellgebühr" }
local KIND_COLOR = { sale = "33dd55", buy = "ff9933", deposit = "aaaaaa" }
local WEEKDAYS = { "Mo", "Di", "Mi", "Do", "Fr", "Sa", "So" }

local function Signed(v)
    if not v then return "-" end
    if v < 0 then return "|cffff5544-" .. A:FormatMoney(-v) .. "|r" end
    if v > 0 then return "|cff33dd55" .. A:FormatMoney(v) .. "|r" end
    return A:FormatMoney(0)
end

-- Einfaches Balkendiagramm aus Texturen
local function BarChart(parent, n, width, height)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(width, height)
    UI:Box(f, C.panel, C.border)
    f.title = UI:Label(f, "", "GameFontNormalSmall", C.accent)
    f.title:SetPoint("TOPLEFT", 8, -6)
    f.title:SetWidth(width - 16)
    f.info = UI:Label(f, "", "GameFontDisableSmall", C.textDim)
    f.info:SetPoint("BOTTOMLEFT", 8, 6)
    f.info:SetWidth(width - 16)
    f.bars, f.labels = {}, {}
    local plotW = width - 16
    local bw = plotW / n
    for i = 1, n do
        local b = f:CreateTexture(nil, "ARTWORK")
        b:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.8)
        b:SetWidth(math.max(1, bw - 2))
        b:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 8 + (i - 1) * bw, 34)
        b:SetHeight(1)
        f.bars[i] = b
        local l = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        l:SetPoint("TOP", b, "BOTTOM", 0, -2)
        f.labels[i] = l
    end
    f.plotH = height - 34 - 30
    -- values: Zahlen (oder nil), labels: Text unter den Balken (oder "")
    function f:SetData(values, labels, highlight)
        local maxV = 0
        for i = 1, n do if values[i] and values[i] > maxV then maxV = values[i] end end
        for i = 1, n do
            local v = values[i]
            local h = (v and maxV > 0) and math.max(1, v / maxV * self.plotH) or 1
            self.bars[i]:SetHeight(h)
            local col = (highlight and highlight[i]) and C.green or C.accent
            self.bars[i]:SetColorTexture(col[1], col[2], col[3], v and 0.85 or 0.15)
            self.labels[i]:SetText(labels and labels[i] or "")
        end
    end
    return f
end

local function BuildLedger(parent)
    local p = CreateFrame("Frame", nil, parent)
    local Le = A.Ledger
    p.period = A.db.ledger.period or "7"
    p.view = A.db.ledger.view or "items"

    local head = UI:TabTitle(p, L["Buchhaltung"], "ledger")
    head.line:Hide()          -- rechts daneben sitzen die Zeitraum-Knöpfe

    -- Zeitraum
    p.periodButtons = {}
    local prev
    for _, per in ipairs(Le.PERIODS) do
        local b = UI:Button(p, L[per.label], 80, 22, function()
            p.period = per.key
            A.db.ledger.period = per.key
            p:Refresh()
        end)
        if prev then b:SetPoint("LEFT", prev, "RIGHT", 4, 0) else b:SetPoint("LEFT", head, "RIGHT", 20, 0) end
        b.key = per.key
        table.insert(p.periodButtons, b)
        prev = b
    end

    -- Karten
    p.cards = {}
    local cardDefs = {
        { key = "income", title = L["Einnahmen"], tip = L["Verkäufe nach Abzug des AH-Anteils (5 %)"], icon = "Interface\\Icons\\INV_Misc_Coin_02" },
        { key = "spent", title = L["Ausgaben"], tip = L["Käufe im Auktionshaus"], icon = "Interface\\Icons\\INV_Misc_Bag_10" },
        { key = "fees", title = L["Gebühren"], tip = L["Einstellgebühren (verlorene - bei Verkauf erstattete)"], icon = "Interface\\Icons\\INV_Misc_Note_01" },
        { key = "profit", title = L["Gewinn"], tip = L["Einnahmen - Ausgaben - Gebühren"], icon = "Interface\\Icons\\INV_Misc_Coin_01" },
    }
    for i, d in ipairs(cardDefs) do
        local c = UI:Card(p, 222, 62, d.title, d.icon)
        c:SetPoint("TOPLEFT", (i - 1) * 228, -32)
        c.index = i
        c:EnableMouse(true)
        c:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:SetText(d.title, 1, 1, 1)
            GameTooltip:AddLine(d.tip, 0.9, 0.9, 0.9, true)
            GameTooltip:Show()
        end)
        c:SetScript("OnLeave", function() GameTooltip:Hide() end)
        p.cards[d.key] = c
    end

    -- Ansichten
    p.viewButtons = {}
    local views = { { "items", L["Pro Item"] }, { "log", L["Verlauf"] }, { "stats", L["Statistik"] }, { "gold", L["Gold"] }, { "assets", L["Vermögen"] }, { "guild", L["Gildenbank"] } }
    prev = nil
    for _, v in ipairs(views) do
        local b = UI:Button(p, v[2], 100, 22, function()
            p.view = v[1]
            A.db.ledger.view = v[1]
            p:Refresh()
        end)
        if prev then b:SetPoint("LEFT", prev, "RIGHT", 4, 0) else b:SetPoint("TOPLEFT", 0, -104) end
        b.view, b.label2 = v[1], v[2]
        p.viewButtons[v[1]] = b
        prev = b
    end
    p.itemsBtn, p.logBtn, p.statsBtn, p.goldBtn = p.viewButtons.items, p.viewButtons.log, p.viewButtons.stats, p.viewButtons.gold
    p.info = UI:Label(p, "", "GameFontDisableSmall", C.textDim)
    p.info:SetPoint("LEFT", prev, "RIGHT", 12, 0)
    p.info:SetPoint("RIGHT", p, "RIGHT", 0, 0)       -- Rest der Zeile (6 Ansichts-Knöpfe davor)
    if p.info.SetWordWrap then p.info:SetWordWrap(true) end

    -- ---------- Pro Item ----------
    p.itemTable = UI:Table(p, {
        columns = {
            { key = "name", title = L["Item"], width = 210 },
            { key = "soldQty", title = L["verkauft"], width = 70, align = "RIGHT" },
            { key = "income", title = L["Erlös"], width = 120, align = "RIGHT" },
            { key = "boughtQty", title = L["gekauft"], width = 70, align = "RIGHT" },
            { key = "spent", title = L["Kosten"], width = 120, align = "RIGHT" },
            { key = "fees", title = L["Gebühren"], width = 100, align = "RIGHT" },
            { key = "profit", title = L["Gewinn"], width = 130, align = "RIGHT" },
        },
        rows = 12, rowHeight = 22, sortKey = "profit", sortAsc = false,
        cell = function(r, key)
            if key == "name" then return r.name end
            if key == "soldQty" or key == "boughtQty" then return r[key] > 0 and tostring(r[key]) or "-" end
            if key == "profit" then return Signed(r.profit) end
            if key == "fees" then return r.fees ~= 0 and Signed(-r.fees) or "-" end
            return r[key] > 0 and A:FormatMoney(r[key]) or "-"
        end,
        sortValue = function(r, key)
            if key == "name" then return string.lower(r.name) end
            return r[key]
        end,
        onClick = function(r) if r.itemID then UI:OpenChart(r.itemID) end end,
        emptyText = L["Noch keine Buchungen in diesem Zeitraum.\nÖffne deinen Briefkasten - die Rechnungen werden automatisch gelesen."],
    })
    p.itemTable:Fill(0, -134, 0, 24)

    -- ---------- Verlauf ----------
    p.logTable = UI:Table(p, {
        columns = {
            { key = "t", title = L["Datum"], width = 110 },
            { key = "kind", title = L["Art"], width = 110 },
            { key = "name", title = L["Item"], width = 210 },
            { key = "qty", title = L["Menge"], width = 60, align = "RIGHT" },
            { key = "net", title = L["Betrag"], width = 130, align = "RIGHT" },
            { key = "player", title = L["Mitspieler"], width = 120 },
            { key = "src", title = L["Quelle"], width = 80 },
        },
        rows = 12, rowHeight = 22, sortKey = "t", sortAsc = false,
        cell = function(e, key)
            if key == "t" then return date("%d.%m. %H:%M", e.t) end
            if key == "kind" then return "|cff" .. (KIND_COLOR[e.kind] or "ffffff") .. L[KIND_LABEL[e.kind] or e.kind] .. "|r" end
            if key == "name" then return e.itemID and A:GetItemName(e.itemID) or e.name or "?" end
            if key == "qty" then return tostring(e.qty or 1) end
            if key == "net" then return Signed(e.net) end
            if key == "player" then return e.player or "" end
            if key == "src" then
                return L[({ mail = "Post", sniper = "Sniper", post = "Verkaufen", buy = "Einkauf" })[e.src] or "-"]
            end
        end,
        sortValue = function(e, key)
            if key == "name" then return string.lower(e.name or "") end
            if key == "kind" or key == "player" or key == "src" then return tostring(e[key] or "") end
            return e[key]
        end,
        emptyText = L["Noch keine Buchungen in diesem Zeitraum.\nÖffne deinen Briefkasten - die Rechnungen werden automatisch gelesen."],
    })
    p.logTable:Fill(0, -134, 0, 24)

    -- ---------- Statistik ----------
    p.statsFrame = CreateFrame("Frame", nil, p)
    p.statsFrame:SetPoint("TOPLEFT", 0, -134)
    p.statsFrame:SetSize(930, 300)
    p.statTable = UI:Table(p.statsFrame, {
        columns = {
            { key = "name", title = L["Item"], width = 180 },
            { key = "posted", title = L["eingestellt"], width = 76, align = "RIGHT" },
            { key = "sold", title = L["verkauft"], width = 70, align = "RIGHT" },
            { key = "rate", title = L["Quote"], width = 62, align = "RIGHT",
              tooltip = L["Verkauft / eingestellt (nur Auktionen, die du über das Addon eingestellt hast)"] },
            { key = "avg", title = L["Ø Preis"], width = 100, align = "RIGHT" },
        },
        rows = 12, rowHeight = 22, sortKey = "sold", sortAsc = false,
        cell = function(r, key)
            if key == "name" then return r.name end
            if key == "rate" then
                if not r.rate then return "|cff666666-|r" end
                local col = (r.rate >= 60 and "33dd55") or (r.rate >= 30 and "ffcc33") or "ff5544"
                return string.format("|cff%s%d%%|r", col, math.floor(r.rate + 0.5))
            end
            if key == "avg" then return A:FormatMoney(r.avg) end
            return r[key] > 0 and tostring(r[key]) or "-"
        end,
        sortValue = function(r, key)
            if key == "name" then return string.lower(r.name) end
            return r[key]
        end,
        onClick = function(r) if r.itemID then UI:OpenChart(r.itemID) end end,
        emptyText = L["Noch keine Verkäufe in diesem Zeitraum."],
    })
    p.statTable:SetPoint("TOPLEFT", 0, 0)
    p.hourChart = BarChart(p.statsFrame, 24, 395, 150)
    p.hourChart:SetPoint("TOPLEFT", 530, 0)
    p.dayChart = BarChart(p.statsFrame, 7, 395, 140)
    p.dayChart:SetPoint("TOPLEFT", p.hourChart, "BOTTOMLEFT", 0, -4)

    -- ---------- Gold ----------
    p.goldFrame = CreateFrame("Frame", nil, p)
    p.goldFrame:SetPoint("TOPLEFT", 0, -134)
    p.goldFrame:SetSize(930, 300)
    p.charTable = UI:Table(p.goldFrame, {
        columns = {
            { key = "name", title = L["Charakter"], width = 140 },
            { key = "money", title = L["Gold"], width = 130, align = "RIGHT" },
            { key = "items", title = L["Items"], width = 56, align = "RIGHT",
              tooltip = L["Gegenstände in Taschen und Bank (Bank: beim letzten Öffnen der Bank)"] },
            { key = "updated", title = L["zuletzt"], width = 96 },
        },
        rows = 12, rowHeight = 22, idKey = "key", sortKey = "money", sortAsc = false,
        itemTooltip = false, noMenu = true,
        cell = function(c, key)
            if key == "name" then return (c.me and "|cffffd700* |r" or "") .. c.name end
            if key == "money" then return A:FormatMoney(c.money) end
            if key == "items" then return tostring(c.items) end
            if key == "updated" then return A:FormatAgo(c.updated) end
        end,
        sortValue = function(c, key)
            if key == "name" then return string.lower(c.name) end
            return c[key]
        end,
        action = {
            text = "X", width = 26,
            tooltip = L["Charakter aus der Liste entfernen (zweimal klicken)"],
            onClick = function(c)
                if p.confirmChar ~= c.key then
                    p.confirmChar = c.key
                    p.info:SetText(L["Nochmal klicken, um den Charakter zu entfernen."])
                    return
                end
                p.confirmChar = nil
                local _, msg = A.Chars:Remove(c.key)
                p.info:SetText(msg)
                p:Refresh()
            end,
        },
        emptyText = L["Noch keine Charaktere."],
    })
    p.charTable:SetPoint("TOPLEFT", 0, 0)
    p.goldChart = BarChart(p.goldFrame, 30, 410, 294)
    p.goldChart:SetPoint("TOPLEFT", 500, 0)

    -- ---------- Vermögen: Taschen, Bank, Twinks ----------
    p.assetTable = UI:Table(p, {
        columns = {
            { key = "name", title = L["Item"], width = 220 },
            { key = "count", title = L["Menge"], width = 60, align = "RIGHT" },
            { key = "where", title = L["Wo"], width = 190,
              tooltip = L["T = Taschen, B = Bank (dieser Charakter), W = Twinks"] },
            { key = "unit", title = L["Marktwert"], width = 110, align = "RIGHT" },
            { key = "value", title = L["Wert"], width = 120, align = "RIGHT",
              tooltip = L["Menge x Marktwert"] },
            { key = "vendorValue", title = L["Händler"], width = 100, align = "RIGHT",
              tooltip = L["Was ein Händler für alles zusammen zahlt"] },
        },
        rows = 12, rowHeight = 22, sortKey = "value", sortAsc = false,
        cell = function(r, key)
            if key == "name" then return r.name end
            if key == "count" then return tostring(r.count) end
            if key == "where" then
                local parts = {}
                if r.bags > 0 then table.insert(parts, "T " .. r.bags) end
                if r.bank > 0 then table.insert(parts, "B " .. r.bank) end
                if r.alts > 0 then table.insert(parts, "W " .. r.alts) end
                if (r.guild or 0) > 0 then table.insert(parts, "G " .. r.guild) end
                return table.concat(parts, "  ")
            end
            if key == "unit" then return r.unit and A:FormatMoney(math.floor(r.unit)) or "|cff777777-|r" end
            if key == "value" then return r.value > 0 and A:FormatMoney(r.value) or "|cff777777-|r" end
            if key == "vendorValue" then return r.vendorValue > 0 and A:FormatMoney(r.vendorValue) or "|cff777777-|r" end
        end,
        sortValue = function(r, key)
            if key == "name" then return string.lower(r.name or "") end
            if key == "where" then return r.alts end
            return r[key] or 0
        end,
        onClick = function(r) UI:OpenChart(r.itemID) end,
        emptyText = L["Noch keine Daten. Taschen werden beim Einloggen gelesen, die Bank beim Öffnen der Bank."],
    })
    p.assetTable:Fill(0, -134, 0, 24)
    p.assetTable:Hide()

    p.hint = UI:Label(p, L["Verkäufe und Käufe kommen aus den Rechnungen im Briefkasten (einfach öffnen), Einstellgebühren aus dem Tab Verkaufen."], "GameFontDisableSmall", C.textDim)
    p.hint:SetPoint("BOTTOMLEFT", 0, 4)
    p.hint:SetWidth(900)

    -- ------------------------------------------------------------
    function p:RefreshStats()
        local st = Le:Stats(self.period)
        self.statTable:SetData(st.items, true)
        local values, labels, hl = {}, {}, {}
        for h = 0, 23 do
            values[h + 1] = st.hours[h].n > 0 and st.hours[h].n or nil
            labels[h + 1] = (h % 3 == 0) and tostring(h) or ""
        end
        for k = 1, math.min(3, #st.best) do hl[st.best[k] + 1] = true end
        self.hourChart:SetData(values, labels, hl)
        self.hourChart.title:SetText(L["Verkäufe nach Uhrzeit"])
        if #st.best > 0 then
            local parts = {}
            for k = 1, math.min(3, #st.best) do table.insert(parts, string.format("%02d-%02d", st.best[k], (st.best[k] + 1) % 24)) end
            self.hourChart.info:SetText(L["Beste Zeit: "] .. table.concat(parts, ", ") .. L[" Uhr"])
        else
            self.hourChart.info:SetText(L["Noch keine Verkäufe in diesem Zeitraum."])
        end
        local dv, dl, bestDay, bestN = {}, {}, nil, 0
        for d = 1, 7 do
            dv[d] = st.weekdays[d].n > 0 and st.weekdays[d].n or nil
            dl[d] = L[WEEKDAYS[d]]
            if st.weekdays[d].n > bestN then bestDay, bestN = d, st.weekdays[d].n end
        end
        self.dayChart:SetData(dv, dl, bestDay and { [bestDay] = true } or nil)
        self.dayChart.title:SetText(L["Verkäufe nach Wochentag"])
        self.dayChart.info:SetText("")
        local posted, sold = 0, 0
        for _, r in ipairs(st.items) do posted = posted + r.posted; sold = sold + r.sold end
        self.info:SetText(posted > 0 and string.format(L["Verkaufsquote gesamt: %d %% (%d von %d)"], math.floor(math.min(100, sold / posted * 100) + 0.5), sold, posted)
            or L["Verkaufsquote: erst Auktionen über den Tab Verkaufen einstellen."])
    end

    function p:RefreshGold()
        local chars = A.Chars:GetAll()
        self.charTable:SetData(chars, true)
        local days = A.Chars:DailyTotals(30)
        local values, labels = {}, {}
        for i, d in ipairs(days) do
            values[i] = d.money
            labels[i] = (i % 5 == 0 or i == 30) and date("%d.", d.t) or ""
        end
        self.goldChart:SetData(values, labels)
        self.goldChart.title:SetText(L["Gold aller Charaktere (30 Tage)"])
        local first, last
        for _, d in ipairs(days) do if d.money then first = first or d.money; last = d.money end end
        local change = (first and last) and (last - first) or 0
        self.goldChart.info:SetText(string.format(L["Gesamt: %s   |   30 Tage: %s"], A:FormatMoney(A.Chars:TotalMoney()), Signed(change)))
        if not self.confirmChar then
            self.info:SetText(string.format(L["%d Charaktere - Bank wird beim Öffnen der Bank aktualisiert"], #chars))
        end
    end

    -- Karten auf die ganze Breite verteilen
    function p:LayoutCards()
        local w = self:GetWidth()
        if not w or w < 400 then return end
        local cw = math.floor((w - 18) / 4)
        for _, c in pairs(self.cards) do
            c:SetWidth(cw)
            c:ClearAllPoints()
            c:SetPoint("TOPLEFT", (c.index - 1) * (cw + 6), -32)
        end
    end

    function p:Refresh()
        self:LayoutCards()
        for _, b in ipairs(self.periodButtons) do
            b.label:SetTextColor(unpack(b.key == self.period and C.accent or C.text))
        end
        local s = Le:Summary(self.period)
        self.cards.income.value:SetText(A:FormatMoney(s.income))
        self.cards.income.sub:SetText(string.format(L["%d Verkäufe, AH-Anteil %s"], s.sales, A:FormatMoney(s.cut, true)))
        self.cards.spent.value:SetText(A:FormatMoney(s.spent))
        self.cards.spent.sub:SetText(string.format(L["%d Käufe"], s.buys))
        self.cards.fees.value:SetText(A:FormatMoney(math.max(0, s.fees)))
        self.cards.fees.sub:SetText("")
        self.cards.profit.value:SetText(Signed(s.profit))
        self.cards.profit.sub:SetText(s.profit >= 0 and L["im Plus"] or L["im Minus"])
        for key, b in pairs(self.viewButtons) do
            b:SetText(key == self.view and ("> " .. b.label2 .. " <") or b.label2)
            -- Breite an den (übersetzten) Text anpassen: sechs Ansichten in einer Zeile
            local fs = b.label or (b.GetFontString and b:GetFontString())
            local w = fs and fs.GetStringWidth and fs:GetStringWidth()
            if w and w > 0 then b:SetWidth(math.max(64, math.floor(w + 18))) end
        end
        self.itemTable:Hide(); self.logTable:Hide(); self.statsFrame:Hide(); self.goldFrame:Hide(); self.assetTable:Hide()
        self.hint:SetShown(self.view == "items" or self.view == "log")
        if self.view == "items" then
            self.itemTable:Show()
            local rows = Le:ByItem(self.period)
            self.itemTable:SetData(rows, true)
            self.info:SetText(string.format(L["%d Items - Klick öffnet den Preisverlauf"], #rows))
        elseif self.view == "log" then
            self.logTable:Show()
            local entries = {}
            for _, e in ipairs(Le:GetEntries(self.period)) do
                local net
                if e.kind == "sale" then net = e.amount - (e.cut or 0) else net = -e.amount end
                table.insert(entries, { t = e.t, kind = e.kind, itemID = e.itemID, name = e.name, qty = e.qty, net = net,
                                        player = e.player, src = e.src })
            end
            self.logTable:SetData(entries, true)
            self.info:SetText(string.format(L["%d Buchungen"], #entries))
        elseif self.view == "stats" then
            self.statsFrame:Show()
            self:RefreshStats()
        elseif self.view == "guild" then
            self.assetTable:Show()
            local K = A.Comfort
            local rows, tot = K:GuildBankValue()
            if not K:GuildBankSupported() then
                self.assetTable.empty:SetText(L["Eine Gildenbank gibt es in dieser WoW-Version nicht (erst ab TBC)."])
            elseif not tot.guild then
                self.assetTable.empty:SetText(L["Du bist in keiner Gilde."])
            else
                self.assetTable.empty:SetText(L["Noch keine Daten. Öffne einmal die Gildenbank - alle Fächer, die du sehen darfst, werden gelesen."])
            end
            self.assetTable:SetData(rows, true)
            if tot.time then
                self.info:SetText(string.format(L["%s: Waren %s (Marktwert) / %s (Händler)   |   Gold %s   |   Stand %s"],
                    tot.guild or "?", A:FormatMoney(tot.market), A:FormatMoney(tot.vendor), A:FormatMoney(tot.gold), A:FormatAgo(tot.time)))
            else
                self.info:SetText("")
            end
        elseif self.view == "assets" then
            self.assetTable:Show()
            self.assetTable.empty:SetText(L["Noch keine Daten. Taschen werden beim Einloggen gelesen, die Bank beim Öffnen der Bank."])
            local rows, tot = A.Extras:InventoryValue()
            self.assetTable:SetData(rows, true)
            self.info:SetText(string.format(L["Waren: %s (Marktwert) / %s (Händler)   |   Gold: %s   |   Gesamt: %s"],
                A:FormatMoney(tot.market), A:FormatMoney(tot.vendor), A:FormatMoney(tot.gold), A:FormatMoney(tot.market + tot.gold)))
        else
            self.goldFrame:Show()
            self:RefreshGold()
        end
    end

    return p
end

UI:RegisterTab("ledger", "Buchhaltung", 5.5, BuildLedger)

A:On("LEDGER_CHANGED", function()
    if UI.activeTab == "ledger" then UI:RefreshActive() end
end)
A:On("CHARS_CHANGED", function()
    local tab = UI:GetTab("ledger")
    if UI.activeTab == "ledger" and tab and tab.panel and tab.panel.view == "gold" then UI:RefreshActive() end
end)

A:On("GUILDBANK_CHANGED", function()
    local tab = UI:GetTab("ledger")
    if tab and tab.panel and tab.panel:IsVisible() and tab.panel.view == "guild" then tab.panel:Refresh() end
end)
