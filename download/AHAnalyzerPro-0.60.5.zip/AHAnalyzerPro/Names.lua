-- ============================================================
-- AH Analyzer Pro 4.6 - Item-Namen in allen WoW-Sprachen
--
-- * Eingebaute Namensliste (Ordner Data): rund 23.000 Items von
--   WoW Forever / Classic in Englisch, Deutsch, Französisch, Spanisch (EU),
--   Spanisch (LA), Portugiesisch, Italienisch*, Russisch, Koreanisch,
--   Chinesisch (vereinfacht/traditionell).  (*Italienisch nur über Sync)
--   Quellen und Lizenzen: Data/QUELLEN.txt
-- * Suche nach Name in jeder Sprache, nach Item-ID oder per Item-Link
--   (Shift-Klick auf ein Item, während ein Suchfeld aktiv ist).
-- * Groß/klein, Umlaute und Akzente sind egal (ä = a, ß = ss, é = e ...),
--   Wörter dürfen in beliebiger Reihenfolge stehen, Teile reichen.
-- * Zusätzlich lernt das Addon Namen aus deinem Client und von Mitspielern
--   (Preis-Sync) - das deckt auch Items ab, die nicht in der Liste stehen.
-- * Anzeigesprache einstellbar (Optionen), Standard: Englisch.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local N = {}
A.Names = N

-- Alle Sprachen, die es im WoW-Client gibt
N.LOCALES = {
    { code = "enUS", label = "Englisch" },
    { code = "deDE", label = "Deutsch" },
    { code = "frFR", label = "Französisch" },
    { code = "esES", label = "Spanisch (Europa)" },
    { code = "esMX", label = "Spanisch (Lateinamerika)" },
    { code = "ptBR", label = "Portugiesisch" },
    { code = "itIT", label = "Italienisch" },
    { code = "ruRU", label = "Russisch" },
    { code = "koKR", label = "Koreanisch" },
    { code = "zhCN", label = "Chinesisch (vereinfacht)" },
    { code = "zhTW", label = "Chinesisch (traditionell)" },
}
N.VALID = {}
for i, l in ipairs(N.LOCALES) do N.VALID[l.code] = i end

local RESEND_AFTER = 3 * 86400     -- eigene Namen alle 3 Tage erneut teilen
local MAX_NAME = 90                -- Bytes
local MAX_HITS_PER_LOCALE = 400    -- Obergrenze pro Sprache und Suche (Tempo)

-- eingebaute Daten (aus Data/Names_*.lua): [Sprache] = "\nID\tName\nID\tName\n..."
local function RawData()
    return AHAnalyzerPro_NameData or {}
end

-- ------------------------------------------------------------
-- Sprache des Clients
-- ------------------------------------------------------------
function N:ClientLocale()
    local loc = GetLocale and GetLocale() or "enUS"
    if loc == "enGB" then loc = "enUS" end
    if not N.VALID[loc] then loc = "enUS" end
    return loc
end

function N:LocaleLabel(code)
    if code == "auto" then
        return string.format(L["Automatisch (%s)"], self:LocaleLabel(self:ClientLocale()))
    end
    local i = N.VALID[code]
    return i and L[N.LOCALES[i].label] or tostring(code)
end

-- Einstellung: "auto" (= Sprache des Clients, Standard) oder ein Sprach-Code
function N:DisplaySetting()
    local s = A.db and A.db.settings
    local loc = s and s.nameLocale or "auto"
    if loc ~= "auto" and not N.VALID[loc] then loc = "auto" end
    return loc
end

-- Sprache, in der Item-Namen angezeigt werden
function N:DisplayLocale()
    local loc = self:DisplaySetting()
    if loc == "auto" then return self:ClientLocale() end
    return loc
end

function N:SetDisplayLocale(code)
    if not A.db or (code ~= "auto" and not N.VALID[code]) then return false end
    A.db.settings.nameLocale = code
    A.db.settings.nameLocaleChosen = (code ~= "auto")
    A:Fire("DATA_CHANGED")
    return true
end

-- nächste / vorige Einstellung (für den Knopf in den Optionen): Automatisch, Englisch, Deutsch, ...
function N:CycleDisplayLocale(step)
    local list = { "auto" }
    for _, l in ipairs(N.LOCALES) do table.insert(list, l.code) end
    local cur = self:DisplaySetting()
    local i = 1
    for k, code in ipairs(list) do if code == cur then i = k end end
    i = ((i - 1 + (step or 1)) % #list) + 1
    self:SetDisplayLocale(list[i])
    return list[i]
end

-- ------------------------------------------------------------
-- Vereinheitlichen für die Suche (UTF-8)
-- ------------------------------------------------------------
local FOLD = {
    ["à"] = "a", ["á"] = "a", ["â"] = "a", ["ã"] = "a", ["ä"] = "a", ["å"] = "a", ["æ"] = "ae",
    ["ç"] = "c", ["è"] = "e", ["é"] = "e", ["ê"] = "e", ["ë"] = "e",
    ["ì"] = "i", ["í"] = "i", ["î"] = "i", ["ï"] = "i", ["ñ"] = "n",
    ["ò"] = "o", ["ó"] = "o", ["ô"] = "o", ["õ"] = "o", ["ö"] = "o", ["ø"] = "o",
    ["ù"] = "u", ["ú"] = "u", ["û"] = "u", ["ü"] = "u", ["ý"] = "y", ["ÿ"] = "y", ["ß"] = "ss",
}

-- Buchstaben vereinheitlichen; Tab und Zeilenumbruch bleiben erhalten
local function Fold(s)
    s = s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    s = string.lower(s)
    -- Latein-1 Großbuchstaben (À-Þ) -> klein
    s = s:gsub("\195([\128-\158])", function(c)
        local b = c:byte()
        if b == 151 then return "\195" .. c end            -- ×
        return "\195" .. string.char(b + 32)
    end)
    s = s:gsub("\197\146", "oe"):gsub("\197\147", "oe")     -- Œ œ
    -- Kyrillisch: А-П -> а-п, Р-Я -> р-я, Ё -> е
    s = s:gsub("\208([\144-\159])", function(c) return "\208" .. string.char(c:byte() + 32) end)
    s = s:gsub("\208([\160-\175])", function(c) return "\209" .. string.char(c:byte() - 32) end)
    s = s:gsub("\208\129", "\208\181"):gsub("\209\145", "\208\181")
    -- Akzente weg
    s = s:gsub("\195[\128-\191]", FOLD)
    -- Satzzeichen zu Leerzeichen
    s = s:gsub("\226\128[\152\153\156\157]", " ")             -- typografische Anführungszeichen
    s = s:gsub("[%'%\"%-%.,:;!%?%(%)%[%]/]", " ")
    s = s:gsub(" +", " ")
    return s
end

local function Normalize(s)
    if type(s) ~= "string" then return "" end
    s = Fold(s)
    s = s:gsub("%s+", " "):gsub("^ ", ""):gsub(" $", "")
    return s
end
N.Normalize = Normalize

local function Words(q)
    local out = {}
    for w in q:gmatch("%S+") do table.insert(out, w) end
    return out
end

-- ------------------------------------------------------------
-- Eingebaute Namensliste
-- ------------------------------------------------------------
local builtinTables = {}   -- [Sprache][itemID] = Name (nur bei Bedarf aufgebaut)
local normBlobs = {}       -- [Sprache] = vereinheitlichter Textblock für die Suche
local builtinCounts = {}

function N:HasBuiltin(loc)
    return RawData()[loc] ~= nil
end

function N:BuiltinCount(loc)
    if builtinCounts[loc] == nil then
        local blob = RawData()[loc]
        local n = 0
        if blob then
            local _, count = blob:gsub("\n%d+\t", "")
            n = count
        end
        builtinCounts[loc] = n
    end
    return builtinCounts[loc]
end

-- id -> Name für eine Sprache (Tabelle wird beim ersten Zugriff gebaut)
function N:BuiltinTable(loc)
    local t = builtinTables[loc]
    if not t then
        t = {}
        local blob = RawData()[loc]
        if blob then
            for id, name in blob:gmatch("\n(%d+)\t([^\n]*)") do t[tonumber(id)] = name end
        end
        builtinTables[loc] = t
    end
    return t
end

function N:BuiltinGet(itemID, loc)
    if not RawData()[loc] then return nil end
    return self:BuiltinTable(loc)[itemID]
end

-- Textblock für die Suche vereinheitlichen (wird auch zum Erzeugen von Data/Search_*.lua benutzt)
function N.NormalizeBlob(blob)
    local nb = Fold(blob)
    nb = nb:gsub(" ?\n ?", "\n")
    nb = nb:gsub("\t ", "\t")
    return nb
end

local function NormBlob(loc)
    local nb = normBlobs[loc]
    if nb == nil then
        -- fertig aufbereitet mitgeliefert (Data/Search_*.lua), sonst jetzt berechnen
        local pre = AHAnalyzerPro_NameSearch and AHAnalyzerPro_NameSearch[loc]
        local blob = RawData()[loc]
        if pre then
            nb = pre
        elseif blob then
            nb = N.NormalizeBlob(blob)
        else
            nb = false
        end
        normBlobs[loc] = nb
    end
    return nb
end

-- Vorab aufbereiten (nur nötig, falls Data/Search_*.lua fehlt; nach und nach, damit nichts ruckelt)
function N:Prewarm()
    local list = {}
    local pre = AHAnalyzerPro_NameSearch or {}
    for _, l in ipairs(N.LOCALES) do if RawData()[l.code] and not pre[l.code] then table.insert(list, l.code) end end
    for i, loc in ipairs(list) do
        if C_Timer and C_Timer.After then
            C_Timer.After(4 + i, function() NormBlob(loc) end)
        else
            NormBlob(loc)
        end
    end
end

-- Treffer im Textblock einer Sprache: ruft fn(itemID, vereinheitlichterName) für jede Zeile mit dem Wort
local function ScanBlob(loc, word, limit, fn)
    local nb = NormBlob(loc)
    if not nb or word == "" then return end
    local pos, hits = 1, 0
    while true do
        local s = nb:find(word, pos, true)
        if not s then break end
        local from = math.max(1, s - 300)
        local seg = nb:sub(from, s)
        local nl = seg:match(".*()\n")
        local lineStart = nl and (from + nl - 1) or 1
        local lineEnd = nb:find("\n", s, true) or (#nb + 1)
        local line = nb:sub(lineStart + 1, lineEnd - 1)
        local id, name = line:match("^(%d+)\t(.*)$")
        if id and s > lineStart + #id + 1 then
            fn(tonumber(id), name)
            hits = hits + 1
            if limit and hits >= limit then break end
        end
        pos = lineEnd + 1
    end
end

-- ------------------------------------------------------------
-- Gelernte Namen: A.db.names[locale][itemID] = Name (Client + Sync)
-- ------------------------------------------------------------
local normCache = {}     -- [locale][itemID] = vereinheitlichter Name

local function Store(loc)
    A.db.names[loc] = A.db.names[loc] or {}
    return A.db.names[loc]
end

-- Name lernen. fromSync: kam von einem Mitspieler
function N:Learn(itemID, name, loc, fromSync)
    if not A.db or not itemID or type(name) ~= "string" then return false end
    itemID = tonumber(itemID)
    if not itemID or itemID <= 0 or itemID >= 10000000 then return false end
    loc = loc or self:ClientLocale()
    if not N.VALID[loc] then return false end
    name = name:gsub("|", ""):gsub("[\r\n\t;=]", " ")
    if name == "" or #name > MAX_NAME or name:find("^Item #") then return false end
    -- Namen in der eigenen Client-Sprache kennt der Client selbst am besten
    if fromSync and loc == self:ClientLocale() then return false end
    -- schon in der eingebauten Liste: nichts zu tun
    if fromSync and self:BuiltinGet(itemID, loc) == name then return false end
    local store = Store(loc)
    if store[itemID] == name then return false end
    store[itemID] = name
    if normCache[loc] then normCache[loc][itemID] = nil end
    return true
end

-- Name in einer Sprache: gelernt > eingebaut
function N:Get(itemID, loc)
    loc = loc or self:DisplayLocale()
    local store = A.db and A.db.names[loc]
    return (store and store[itemID]) or self:BuiltinGet(itemID, loc)
end

function N:CountNames(loc)
    local learned = A:CountTable(A.db and A.db.names[loc])
    return self:BuiltinCount(loc) + learned
end

local function NormName(loc, itemID, name)
    normCache[loc] = normCache[loc] or {}
    local n = normCache[loc][itemID]
    if not n then
        n = Normalize(name)
        normCache[loc][itemID] = n
    end
    return n
end

-- ------------------------------------------------------------
-- Suche
-- ------------------------------------------------------------
-- Item-ID aus Zahl oder Item-Link
function N:ParseID(text)
    if type(text) == "number" then return text end
    if type(text) ~= "string" then return nil end
    local id = text:match("item:(%d+)")
    if id then return tonumber(id) end
    local trimmed = text:gsub("^%s+", ""):gsub("%s+$", "")
    if trimmed:match("^%d+$") then return tonumber(trimmed) end
    return nil
end

local function Score(n, q, words)
    if n == q then return 100 end
    if n:sub(1, #q) == q then return 70 end
    local boundary = false
    for _, w in ipairs(words) do
        local pos = n:find(w, 1, true)
        if not pos then return 0 end
        if pos == 1 or n:sub(pos - 1, pos - 1) == " " then boundary = true end
    end
    return boundary and 40 or 20
end

-- das längste Wort ist am seltensten -> damit im Textblock suchen
local function LongestWord(words)
    local best = words[1] or ""
    for _, w in ipairs(words) do if #w > #best then best = w end end
    return best
end

-- gelernte Namen + Client-Namen eines Items prüfen
function N:MatchItem(itemID, q, words)
    local best, bestLoc, bestName = 0, nil, nil
    local client = self:ClientLocale()
    local cname = A:GetClientItemName(itemID)
    if cname and not cname:find("^Item #") then
        local s = Score(NormName(client, itemID, cname), q, words)
        if s > best then best, bestLoc, bestName = s, client, cname end
    end
    for loc, store in pairs(A.db.names) do
        local nm = store[itemID]
        if nm and loc ~= client then
            local s = Score(NormName(loc, itemID, nm), q, words)
            if s > best then best, bestLoc, bestName = s, loc, nm end
        end
    end
    return best, bestLoc, bestName
end

-- Treffer aus der eingebauten Liste (alle Sprachen): [itemID] = { score, loc }
function N:SearchBuiltin(q, words, limit)
    local hits = {}
    local key = LongestWord(words)
    if string.len(key) < 2 then return hits end
    for loc in pairs(RawData()) do
        ScanBlob(loc, key, limit, function(id, normName)
            local s = Score(normName, q, words)
            if s > 0 and (not hits[id] or s > hits[id].score) then
                hits[id] = { score = s, loc = loc }
            end
        end)
    end
    return hits
end

-- Für Listenfilter: vorbereitete Suche
function N:PrepareQuery(text)
    if not text or text == "" then return nil end
    local id = self:ParseID(text)
    local q = Normalize(text)
    if q == "" and not id then return nil end
    local pq = { id = id, q = q, words = Words(q) }
    pq.builtin = (q ~= "") and self:SearchBuiltin(q, pq.words, nil) or {}
    return pq
end

function N:Matches(itemID, pq)
    if not pq then return true end
    if pq.id and pq.id == itemID then return true end
    if pq.q == "" then return false end
    if pq.builtin[itemID] then return true end
    return (self:MatchItem(itemID, pq.q, pq.words)) > 0
end

-- Suche nach Name (jede Sprache), ID oder Link.
-- Rückgabe: Liste { itemID, name (Anzeigesprache), matched, matchedLocale, score }
function N:Search(text, limit)
    limit = limit or 10
    local out = {}
    if not A.db then return out end
    local id = self:ParseID(text)
    if id then
        table.insert(out, { itemID = id, name = A:GetItemName(id), score = 1000 })
        return out
    end
    local q = Normalize(text)
    if string.len(q) < 2 then return out end
    local words = Words(q)
    local best = {}     -- [itemID] = { score, loc, name }

    -- 1. eingebaute Liste
    for itemID, h in pairs(self:SearchBuiltin(q, words, MAX_HITS_PER_LOCALE)) do
        best[itemID] = { score = h.score, loc = h.loc }
    end
    -- 2. eigene Marktdaten und gelernte Namen
    local ids = {}
    for itemID in pairs(A.db.marketData) do ids[itemID] = true end
    for _, store in pairs(A.db.names) do for itemID in pairs(store) do ids[itemID] = true end end
    for itemID in pairs(ids) do
        local s, loc, nm = self:MatchItem(itemID, q, words)
        if s > 0 and (not best[itemID] or s > best[itemID].score) then
            best[itemID] = { score = s, loc = loc, name = nm }
        end
    end

    for itemID, b in pairs(best) do
        local matched = b.name or self:Get(itemID, b.loc)
        table.insert(out, { itemID = itemID, name = A:GetItemName(itemID), matched = matched, matchedLocale = b.loc, score = b.score })
    end
    table.sort(out, function(a, b)
        if a.score ~= b.score then return a.score > b.score end
        if #a.name ~= #b.name then return #a.name < #b.name end
        return a.name < b.name
    end)
    while #out > limit do table.remove(out) end
    return out
end

-- Eingabe eindeutig einem Item zuordnen.
-- Rückgabe: itemID oder nil, Anzahl Treffer
function N:Resolve(text)
    local id = self:ParseID(text)
    if id then return id, 1 end
    local results = self:Search(text, 500)
    if #results == 0 then return nil, 0 end
    local exact = {}
    for _, r in ipairs(results) do
        if r.score >= 100 then table.insert(exact, r.itemID) end
    end
    if #exact == 1 then return exact[1], 1 end
    if #exact > 1 then
        -- gleicher Name für mehrere IDs: das Item aus den eigenen Scans bevorzugen
        local seen = {}
        for _, e in ipairs(exact) do if A.db.marketData[e] then table.insert(seen, e) end end
        if #seen == 1 then return seen[1], 1 end
        return nil, #exact
    end
    if #results == 1 then return results[1].itemID, 1 end
    -- eindeutiger Wortanfang schlägt bloße Teiltreffer
    local starts = {}
    for _, r in ipairs(results) do if r.score >= 70 then table.insert(starts, r.itemID) end end
    if #starts == 1 then return starts[1], 1 end
    return nil, #results
end

-- ------------------------------------------------------------
-- Eigene Namen lernen und mit Mitspielern teilen
-- ------------------------------------------------------------
-- alle Namen aus den Marktdaten übernehmen (Client-Sprache)
function N:LearnFromMarket()
    if not A.db then return 0 end
    local n = 0
    local loc = self:ClientLocale()
    for itemID, entry in pairs(A.db.marketData) do
        A:Pause()
        local name = entry.name
        if (not name or name:find("^Item #")) and GetItemInfo then
            local ok, gi = pcall(GetItemInfo, itemID)
            if ok and gi then name = gi; entry.name = gi end
        end
        -- nur merken, was die eingebaute Liste nicht schon genauso kennt
        if name and self:BuiltinGet(itemID, loc) ~= name and self:Learn(itemID, name, loc) then n = n + 1 end
    end
    return n
end

-- Namen der gescannten Items an alle schicken, die nicht in der eingebauten Liste stehen
-- (z.B. neue Forever-Items) und länger nicht gesendet wurden
function N:ShareNames(itemIDs)
    local S = A.Sync
    if not (S and S.BroadcastNames and S:IsEnabled() and S:IsConnected()) then return 0 end
    local loc = self:ClientLocale()
    local now = time()
    local sent = A.db.namesSent
    local store = A.db.names[loc] or {}
    local list = {}
    for itemID in pairs(itemIDs or {}) do
        A:Pause()
        local nm = store[itemID]
        if nm and (sent[itemID] or 0) < now - RESEND_AFTER then
            table.insert(list, { id = itemID, name = nm })
            sent[itemID] = now
        end
    end
    if #list > 0 then S:BroadcastNames(loc, list) end
    return #list
end

-- Namen von Mitspielern empfangen
function N:HandleNames(loc, payload)
    if not N.VALID[loc] or type(payload) ~= "string" then return 0 end
    local added = 0
    for part in payload:gmatch("[^;]+") do
        local a, nm = part:match("^(%w+)=(.+)$")
        local id = a and A.Sync.Dec(a)
        if id and self:Learn(id, nm, loc, true) then added = added + 1 end
    end
    if added > 0 then
        A.db.sync.namesReceived = (A.db.sync.namesReceived or 0) + added
    end
    return added
end

function N:GetDebugText()
    local parts = {}
    for _, l in ipairs(N.LOCALES) do
        local b, g = self:BuiltinCount(l.code), A:CountTable(A.db and A.db.names[l.code])
        if b + g > 0 then table.insert(parts, l.code .. "=" .. b .. (g > 0 and ("+" .. g) or "")) end
    end
    return L["Client="] .. self:ClientLocale() .. L[", Anzeige="] .. self:DisplayLocale()
        .. L[", Namen (eingebaut+gelernt): "] .. (#parts > 0 and table.concat(parts, " ") or L["keine"])
end

A:On("READY", function()
    N:LearnFromMarket()
    N:Prewarm()
end)

A:On("SCAN_FINISHED", function(_, best)
    A:Job("names", function()
        N:LearnFromMarket()
        N:ShareNames(best)
    end)
end)
