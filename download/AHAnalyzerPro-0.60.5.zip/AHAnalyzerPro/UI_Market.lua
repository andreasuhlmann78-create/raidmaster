-- ============================================================
-- AH Analyzer Pro 5.3 - Tab "Markt" (alle Items, Suche, Sortierung,
-- Marktwert und Preis in % vom Marktwert)
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C

local function BuildMarket(parent)
    local p = CreateFrame("Frame", nil, parent)

    local head = UI:TabTitle(p, L["Marktdaten"], "market")

    p.search = UI:EditBox(p, 260, 24, L["Suchen: Name (jede Sprache) oder ID"])
    p.search:SetPoint("TOPLEFT", 0, -30)
    p.search:SetScript("OnTextChanged", function() p:Refresh() end)
    UI:AttachItemSearch(p.search, { suggest = false })
    p.search:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)

    local clear = UI:Button(p, L["Leeren"], 70, 24, function()
        for _, e in ipairs({ p.search, p.ilvlMin, p.ilvlMax }) do
            e:SetText(""); e:ClearFocus(); e:UpdatePlaceholder()
        end
    end)
    clear:SetPoint("LEFT", p.search, "RIGHT", 6, 0)

    -- Filter: nur Items mit Trend-Daten
    p.onlyTrend = false
    local trendBtn
    trendBtn = UI:Button(p, L["Nur mit Trend: aus"], 140, 24, function()
        p.onlyTrend = not p.onlyTrend
        trendBtn:SetText(L["Nur mit Trend: "] .. (p.onlyTrend and L["an"] or L["aus"]))
        p:Refresh()
    end)
    trendBtn:SetPoint("LEFT", clear, "RIGHT", 6, 0)
    trendBtn.tooltip = L["Zeigt nur Items, für die schon ein Vergleich mit einem früheren Scan möglich ist."]

    -- Itemlevel-Bereich
    p.ilvlMin = UI:EditBox(p, 50, 24, L["iLvl ab"])
    p.ilvlMin:SetPoint("LEFT", trendBtn, "RIGHT", 6, 0)
    p.ilvlMax = UI:EditBox(p, 50, 24, L["iLvl bis"])
    p.ilvlMax:SetPoint("LEFT", p.ilvlMin, "RIGHT", 4, 0)
    for _, e in ipairs({ p.ilvlMin, p.ilvlMax }) do
        e.tooltipText = L["Gegenstandsstufe (iLvl): zeigt nur Items in diesem Bereich."]
        e:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
            GameTooltip:SetText(self.tooltipText, 1, 1, 1, 1, true)
            GameTooltip:Show()
        end)
        e:SetScript("OnLeave", function() GameTooltip:Hide() end)
        e:SetScript("OnTextChanged", function() if p.Refresh then p:Refresh() end end)
        e:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    end
    UI:ChainEdits({ p.search, p.ilvlMin, p.ilvlMax })

    p.info = UI:Label(p, "", "GameFontDisableSmall", C.textDim)
    p.info:SetPoint("LEFT", p.ilvlMax, "RIGHT", 12, 0)

    local columns = {
        { key = "name", title = L["Item"], width = 206 },
        { key = "price", title = L["Preis"], width = 118, align = "RIGHT" },
        { key = "market", title = L["Marktwert"], width = 118, align = "RIGHT",
          tooltip = L["Median der Preise der letzten 14 Tage - einzelne Ausreißer zählen kaum"] },
        { key = "pct", title = L["% Markt"], width = 64, align = "RIGHT",
          tooltip = L["Aktueller Preis in Prozent vom Marktwert.\nGrün = günstig, Orange/Rot = teuer."] },
        { key = "quantity", title = L["Menge"], width = 58, align = "RIGHT" },
        { key = "change", title = L["seit Scan"], width = 70, align = "RIGHT" },
        { key = "day", title = L["24 Std."], width = 68, align = "RIGHT" },
        { key = "week", title = L["7 Tage"], width = 68, align = "RIGHT" },
        { key = "month", title = L["30 Tage"], width = 68, align = "RIGHT" },
    }

    p.table = UI:Table(p, {
        columns = columns,
        rows = 17,
        rowHeight = 22,
        sortKey = "name",
        sortAsc = true,
        cell = function(item, key)
            if key == "name" then
                local mark = (A.Watchlist and A.Watchlist:Contains(item.itemID)) and "|cffffd700*|r " or ""
                return mark .. item.name
            end
            if key == "price" then return A:FormatMoney(item.price) end
            if key == "market" then return A:FormatMoney(item.market) end
            if key == "pct" then return A:FormatMarketPercent(item.pct) end
            if key == "quantity" then return tostring(item.quantity) end
            return A:FormatPercent(item[key])
        end,
        sortValue = function(item, key)
            if key == "name" then return string.lower(item.name) end
            return item[key]
        end,
        onClick = function(item) UI:OpenChart(item.itemID) end,
        action = {
            text = "+", width = 28,
            tooltip = L["Zur Watchlist hinzufügen"],
            onClick = function(item)
                local ok, msg = A.Watchlist:Add(tostring(item.itemID))
                A:Print(msg)
            end,
        },
        emptyText = L["Keine Daten. Öffne das Auktionshaus und starte unten rechts einen Scan."],
    })
    p.table:Fill(0, -80, 0, 4)          -- ganzer Platz unter der Suche

    function p:Refresh()
        local list = A:BuildItemList(self.search:GetText())
        if self.onlyTrend then
            local filtered = {}
            for _, it in ipairs(list) do
                if it.change or it.day or it.week or it.month then table.insert(filtered, it) end
            end
            list = filtered
        end
        local a, b = tonumber(self.ilvlMin:GetText() or ""), tonumber(self.ilvlMax:GetText() or "")
        if a and b and a > b then a, b = b, a end
        list = UI:FilterIlvl(list, a, b)
        self.info:SetText(L["Klick = Preisverlauf   |   + = Watchlist   |   Spaltenkopf = sortieren"])
        self.table:SetData(list, true)
    end

    return p
end

UI:RegisterTab("market", "Markt", 2, BuildMarket)

-- nachgeladene Itemlevel: Filter im Markt neu anwenden
A:On("ITEMINFO_LOADED", function()
    local tab = UI:GetTab("market")
    local p = tab and tab.panel
    if p and p:IsVisible() and p.ilvlMin and ((p.ilvlMin:GetText() or "") ~= "" or (p.ilvlMax:GetText() or "") ~= "") then p:Refresh() end
end)
