-- ============================================================
-- AH Analyzer Pro 5.8 - Entzauberungswert (Classic), lernt mit
--
-- Erwarteter Wert beim Entzaubern eines grünen, blauen oder epischen
-- Rüstungs- oder Waffenteils: Summe aus Wahrscheinlichkeit x Ø Menge
-- x Marktwert des Materials. Startwerte sind die bekannten
-- Classic-Richtwerte. Jede eigene Entzauberung wird erkannt und
-- gespeichert - die Werte nähern sich so immer mehr der Realität
-- auf deinem Server an.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local D = {}
A.Disenchant = D

-- Material
local STRANGE, SOUL, VISION, DREAM, ILLUSION = 10940, 11083, 11137, 11176, 16204
local LMAGIC, GMAGIC, LASTRAL, GASTRAL = 10938, 10939, 10998, 11082
local LMYSTIC, GMYSTIC, LNETHER, GNETHER, LETERNAL, GETERNAL = 11134, 11135, 11174, 11175, 16202, 16203
local SGLIMMER, LGLIMMER, SGLOW, LGLOW = 10978, 11084, 11138, 11139
local SRADIANT, LRADIANT, SBRILLIANT, LBRILLIANT, NEXUS = 11177, 11178, 14343, 14344, 20725

-- Grün: { bis Itemlevel, Staub, Ø Staub, Essenz, Ø Essenz, Splitter }
local UNCOMMON = {
    { 15, STRANGE, 1.5, LMAGIC, 1.5, SGLIMMER },
    { 20, STRANGE, 2.5, GMAGIC, 1.5, SGLIMMER },
    { 25, STRANGE, 5.0, LASTRAL, 1.5, SGLIMMER },
    { 30, SOUL, 1.5, GASTRAL, 1.5, LGLIMMER },
    { 35, SOUL, 3.5, LMYSTIC, 1.5, SGLOW },
    { 40, VISION, 1.5, GMYSTIC, 1.5, LGLOW },
    { 45, VISION, 3.5, LNETHER, 1.5, SRADIANT },
    { 50, DREAM, 1.5, GNETHER, 1.5, LRADIANT },
    { 55, DREAM, 3.5, LETERNAL, 1.5, SBRILLIANT },
    { 60, ILLUSION, 1.5, GETERNAL, 1.5, LBRILLIANT },
    { 65, ILLUSION, 3.5, GETERNAL, 2.5, LBRILLIANT },
}
-- Blau: { bis Itemlevel, Splitter }
local RARE = {
    { 25, SGLIMMER }, { 30, LGLIMMER }, { 35, SGLOW }, { 40, LGLOW },
    { 45, SRADIANT }, { 50, LRADIANT }, { 55, SBRILLIANT }, { 65, LBRILLIANT },
}
-- Episch: { ab, bis Itemlevel, Material, Ø Menge }
local EPIC = {
    { 40, 45, SRADIANT, 3 }, { 46, 50, LRADIANT, 3 }, { 51, 55, SBRILLIANT, 3 },
    { 56, 60, NEXUS, 1 }, { 61, 94, NEXUS, 1.5 },
}

-- Verhältnis bei grünen Items (Rüstung): Staub / Essenz / Splitter
D.GREEN_DUST, D.GREEN_ESSENCE, D.GREEN_SHARD = 0.70, 0.25, 0.05

-- nicht entzauberbar, obwohl Rüstung
local NOT_DE = { INVTYPE_BODY = true, INVTYPE_TABARD = true, INVTYPE_BAG = true, INVTYPE_AMMO = true, INVTYPE_QUIVER = true, [""] = true }

-- Startwerte aus der Tabelle: Ertrag { { itemID, Chance (0-1), Ø Menge }, ... }, Gruppe, oder nil.
-- Gruppe = Qualität : Itemlevel-Stufe : Waffe/Rüstung - alle Items einer Gruppe
-- geben laut Tabelle dieselben Materialien und lernen deshalb gemeinsam.
function D:Prior(itemID)
    if not GetItemInfo or not itemID then return nil end
    local info = { pcall(GetItemInfo, itemID) }
    if not info[1] or not info[2] then return nil end
    local quality, ilvl, equipLoc, classID = info[4], info[5], info[10], info[13]
    if not quality or quality < 2 or quality > 4 or not ilvl then return nil end
    if classID ~= 2 and classID ~= 4 then return nil end
    if NOT_DE[equipLoc or ""] then return nil end
    local weapon = (classID == 2)
    if quality == 2 then
        if ilvl < 5 then return nil end
        for k, b in ipairs(UNCOMMON) do
            if ilvl <= b[1] then
                -- Startwerte grün, alle Stufen (in der Beta von WoW Forever beobachtet:
                -- 70 % Staub, 25 % Essenz, 5 % Splitter; Waffen gespiegelt: 70 % Essenz)
                local pDust, pEss = D.GREEN_DUST, D.GREEN_ESSENCE
                if weapon then pDust, pEss = D.GREEN_ESSENCE, D.GREEN_DUST end
                local out = { { b[2], pDust, b[3] }, { b[4], pEss, b[5] } }
                table.insert(out, { b[6], D.GREEN_SHARD, 1 })
                return out, "2:" .. k .. ":" .. (weapon and "w" or "a")
            end
        end
        return nil
    elseif quality == 3 then
        if ilvl < 11 then return nil end
        for k, b in ipairs(RARE) do
            if ilvl <= b[1] then
                if b[2] == LBRILLIANT and ilvl >= 56 then
                    return { { LBRILLIANT, 0.995, 1 }, { NEXUS, 0.005, 1 } }, "3:" .. k
                end
                return { { b[2], 1, 1 } }, "3:" .. k
            end
        end
        return nil
    else
        for k, b in ipairs(EPIC) do
            if ilvl >= b[1] and ilvl <= b[2] then return { { b[3], 1, b[4] } }, "4:" .. k end
        end
        return nil
    end
end

-- ------------------------------------------------------------
-- Lernen aus eigenen Entzauberungen
-- Die Tabelle zählt wie PRIOR_WEIGHT gedachte Entzauberungen. Jede echte
-- Entzauberung verschiebt Chance und Menge Richtung deiner Ergebnisse:
--   Chance = (Tabelle x W + gesehen) / (W + Anzahl Entzauberungen)
--   Menge  = (Tabelle x W x Chance + Summe) / (W x Chance + gesehen)
-- Nach 10 eigenen Entzauberungen zählen deine Ergebnisse zur Hälfte,
-- nach 50 zu 83 %, nach 100 zu 91 %.
-- ------------------------------------------------------------
D.PRIOR_WEIGHT = 10

local function Stats() return A.db and A.db.deStats end

-- alle Materialien, die beim Entzaubern herauskommen können
local MATERIALS = {}
for _, b in ipairs(UNCOMMON) do MATERIALS[b[2]] = true; MATERIALS[b[4]] = true; if b[6] then MATERIALS[b[6]] = true end end
for _, b in ipairs(RARE) do MATERIALS[b[2]] = true end
for _, b in ipairs(EPIC) do MATERIALS[b[3]] = true end
MATERIALS[NEXUS] = true
D.MATERIALS = MATERIALS

-- Ertrag (Tabelle + eigene Ergebnisse), Gruppe, Anzahl eigener Entzauberungen
function D:Yield(itemID)
    local prior, key = self:Prior(itemID)
    if not prior then return nil end
    local db = Stats()
    local st = db and db[key]
    if not st or (st.n or 0) == 0 then return prior, key, 0 end
    local W, n = self.PRIOR_WEIGHT, st.n
    local out, seen = {}, {}
    for _, e in ipairs(prior) do
        local m = st.mats[e[1]]
        local times, total = m and m.times or 0, m and m.total or 0
        local chance = (e[2] * W + times) / (W + n)
        local den = e[2] * W + times
        local avg = (den > 0) and ((e[2] * W * e[3] + total) / den) or e[3]
        table.insert(out, { e[1], chance, avg })
        seen[e[1]] = true
    end
    -- Material, das die Tabelle nicht kennt, aber herauskam
    for id, m in pairs(st.mats) do
        if not seen[id] and m.times > 0 then
            table.insert(out, { id, m.times / (W + n), m.total / m.times })
        end
    end
    return out, key, n
end

-- ein Ergebnis speichern. loot = { { itemID, Menge }, ... }
function D:Record(itemID, loot)
    local prior, key = self:Prior(itemID)
    local db = Stats()
    if not prior or not db or type(loot) ~= "table" or #loot == 0 then return false end
    local sums = {}
    for _, l in ipairs(loot) do
        if not MATERIALS[l[1]] then return false end      -- fremde Beute: nicht mitzählen
        sums[l[1]] = (sums[l[1]] or 0) + (l[2] or 1)
    end
    local st = db[key]
    if not st then st = { n = 0, mats = {} }; db[key] = st end
    st.n = st.n + 1
    st.updated = time()
    for id, qty in pairs(sums) do
        local m = st.mats[id]
        if not m then m = { times = 0, total = 0 }; st.mats[id] = m end
        m.times = m.times + 1
        m.total = m.total + qty
    end
    self.lastRecord = { itemID = itemID, key = key, loot = loot }
    A:Fire("DE_LEARNED", itemID, key)
    A:Fire("DATA_CHANGED")
    return true
end

function D:TotalLearned()
    local groups, n = 0, 0
    for _, st in pairs(Stats() or {}) do groups = groups + 1; n = n + (st.n or 0) end
    return n, groups
end

function D:Reset()
    if A.db then A.db.deStats = {} end
    A:Fire("DATA_CHANGED")
end

-- ------------------------------------------------------------
-- Entzaubern erkennen:
--   1. Item wird angeklickt, während ein Zauber auf ein Ziel wartet -> Kandidat
--   2. der Zauber "Entzaubern" ist erfolgreich -> Kandidat wird entzaubert
--   3. das Beute-Fenster öffnet sich -> Materialien lesen und speichern
-- ------------------------------------------------------------
local DE_SPELL = 13262
local candidate, pending
local WINDOW = 10            -- Sekunden zwischen den Schritten

local function ItemAt(bag, slot)
    if C_Container and C_Container.GetContainerItemInfo then
        local info = C_Container.GetContainerItemInfo(bag, slot)
        return info and info.itemID
    elseif GetContainerItemLink then
        local link = GetContainerItemLink(bag, slot)
        return link and tonumber(link:match("item:(%d+)"))
    end
end

local function OnItemTargeted(bag, slot)
    if not (SpellIsTargeting and SpellIsTargeting()) then return end
    local id = ItemAt(bag, slot)
    if id and D:Prior(id) then candidate = { itemID = id, t = GetTime() } end
end

local function IsDisenchant(spellID)
    if spellID == DE_SPELL then return true end
    if GetSpellInfo and spellID then
        local a, b = GetSpellInfo(spellID), GetSpellInfo(DE_SPELL)
        return a ~= nil and a == b
    end
    return false
end

function D:ReadLoot()
    if not (GetNumLootItems and GetLootSlotLink) then return nil end
    local out = {}
    for i = 1, GetNumLootItems() or 0 do
        local link = GetLootSlotLink(i)
        local id = link and tonumber(link:match("item:(%d+)"))
        local qty = 1
        if GetLootSlotInfo then
            local _, _, q = GetLootSlotInfo(i)
            if type(q) == "number" and q > 0 then qty = q end
        end
        if id then table.insert(out, { id, qty }) end
    end
    return out
end

local hooked = false
local function Hook()
    if hooked or not hooksecurefunc then return end
    hooked = true
    if C_Container and C_Container.UseContainerItem then pcall(hooksecurefunc, C_Container, "UseContainerItem", OnItemTargeted) end
    if C_Container and C_Container.PickupContainerItem then pcall(hooksecurefunc, C_Container, "PickupContainerItem", OnItemTargeted) end
    if UseContainerItem then pcall(hooksecurefunc, "UseContainerItem", OnItemTargeted) end
    if PickupContainerItem then pcall(hooksecurefunc, "PickupContainerItem", OnItemTargeted) end
end

local evt = CreateFrame("Frame")
for _, e in ipairs({ "UNIT_SPELLCAST_SUCCEEDED", "LOOT_OPENED", "LOOT_READY" }) do pcall(evt.RegisterEvent, evt, e) end
evt:SetScript("OnEvent", function(_, event, a1, a2, a3)
    if event == "UNIT_SPELLCAST_SUCCEEDED" then
        if a1 ~= "player" then return end
        if IsDisenchant(a3) and candidate and GetTime() - candidate.t < WINDOW then
            pending = { itemID = candidate.itemID, t = GetTime() }
        else
            pending = nil      -- anderer Zauber oder kein Item angeklickt: nichts zuordnen
        end
        candidate = nil
    elseif (event == "LOOT_OPENED" or event == "LOOT_READY") and pending then
        if GetTime() - pending.t < WINDOW then
            local loot = D:ReadLoot()
            if loot and #loot > 0 then
                local ok = D:Record(pending.itemID, loot)
                pending = nil
                if ok then
                    local n = select(3, D:Yield(D.lastRecord.itemID)) or 0
                    if n % 10 == 0 then
                        A:Print(string.format(L["Entzaubern: %d eigene Ergebnisse in dieser Gruppe - Werte angepasst."], n))
                    end
                end
            end
        else
            pending = nil
        end
    end
end)
A:On("READY", Hook)

-- erwarteter Wert in Kupfer (Marktwert des Materials), nil wenn nicht entzauberbar oder ohne Preise
-- complete = false, wenn für ein Material noch kein Preis bekannt ist; learned = eigene Entzauberungen
function D:GetValue(itemID)
    local y, _, learned = self:Yield(itemID)
    if not y then return nil end
    local value, complete, any = 0, true, false
    for _, e in ipairs(y) do
        local p = A:GetMarketValue(e[1])
        if p then value = value + e[2] * e[3] * p; any = true
        elseif e[2] >= 0.05 then complete = false end
    end
    if not any then return nil end
    return math.floor(value + 0.5), complete, y, learned or 0
end

-- Items, die im Auktionshaus gerade billiger sind als ihr Entzauberungswert
-- (nach AH-Gebühr beim Verkauf des Materials), nur aktuelle Preise
function D:FindDeals()
    local out = {}
    if not A.db then return out end
    local fresh = time() - A.FRESH_SECONDS
    for itemID in pairs(A.db.marketData) do
        local price, qty, t = A:GetCurrent(itemID)
        if price and t and t >= fresh then
            local v, complete = self:GetValue(itemID)
            if v and complete then
                local net = math.floor(v * 0.95 + 0.5)
                if net > price then
                    table.insert(out, { itemID = itemID, name = A:GetItemName(itemID), price = price, value = v,
                                        net = net, profit = net - price, pct = (net - price) / net * 100, quantity = qty or 1 })
                end
            end
        end
    end
    return out
end
