-- ============================================================
-- AH Analyzer Pro 0.59.33 - Komfort
--   * Alt-Klick auf ein Item (Taschen, Chat-Link): Preisverlauf / Einkauf öffnen
--   * Verkaufschance im Tooltip (aus der eigenen Buchhaltung)
--   * Erinnerung bei ablaufenden Auktionen
--   * Gold-Ziel
--   * Gildenbank lesen und bewerten
--   * Raid-Vorrat als Einkaufsliste
--   * Favoriten im Einkauf
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local K = {}
A.Comfort = K

local AH_CUT = 0.95
local function S() return A.db and A.db.settings or {} end

-- ============================================================
-- 1. Alt-Klick auf ein Item: Preisverlauf (oder Einkauf, wenn das Auktionshaus offen ist)
--    (Shift ist schon belegt: Stapel teilen und Links in den Chat)
-- ============================================================
function K:AltClickEnabled() return S().altClick ~= false end

function K:OnModifiedClick(link)
    if not self:AltClickEnabled() or type(link) ~= "string" then return end
    if not (IsAltKeyDown and IsAltKeyDown()) then return end
    if (IsShiftKeyDown and IsShiftKeyDown()) or (IsControlKeyDown and IsControlKeyDown()) then return end
    local id = tonumber(link:match("item:(%d+)"))
    if not id then return end
    local UI = A.UI
    if A:IsAHOpen() and UI.OpenBuyFor then
        UI:OpenBuyFor(id)
    elseif UI.OpenChart then
        UI:OpenChart(id)
    end
    return true
end

if hooksecurefunc and HandleModifiedItemClick then
    pcall(hooksecurefunc, "HandleModifiedItemClick", function(link) K:OnModifiedClick(link) end)
end

-- ============================================================
-- 2. Verkaufschance: wie viel von dem, was du eingestellt hast, wurde verkauft (60 Tage)
--    und wie lange es typischerweise gedauert hat
-- ============================================================
K.CHANCE_DAYS = 60
local chanceCache, chanceTime = nil, 0

local function Median(list)
    if #list == 0 then return nil end
    table.sort(list)
    local m = math.floor((#list + 1) / 2)
    if #list % 2 == 1 then return list[m] end
    return (list[m] + list[m + 1]) / 2
end

function K:BuildChances()
    local out = {}
    local entries = A.db and A.db.ledger and A.db.ledger.entries or {}
    local from = time() - self.CHANCE_DAYS * 86400
    local posts = {}           -- [itemID] = { Zeitpunkte }
    for _, e in ipairs(entries) do
        if e.itemID and e.t >= from then
            local r = out[e.itemID]
            if not r then r = { posted = 0, sold = 0, delays = {} }; out[e.itemID] = r end
            if e.kind == "deposit" and e.src == "post" then
                r.posted = r.posted + (e.qty or 1)
                posts[e.itemID] = posts[e.itemID] or {}
                table.insert(posts[e.itemID], e.t)
            elseif e.kind == "sale" then
                r.sold = r.sold + (e.qty or 1)
                local st = (A.Ledger and A.Ledger.SaleTime) and A.Ledger:SaleTime(e) or e.t
                -- letztes Einstellen davor
                local best
                for _, pt in ipairs(posts[e.itemID] or {}) do
                    if pt <= st and (not best or pt > best) then best = pt end
                end
                if best and st - best < 3 * 86400 then table.insert(r.delays, st - best) end
            end
        end
    end
    for id, r in pairs(out) do
        if r.posted > 0 then
            r.rate = math.min(100, r.sold / r.posted * 100)
            r.delay = Median(r.delays)
        end
    end
    return out
end

-- Rückgabe: { rate = %, posted, sold, delay = Sek. } oder nil (zu wenig Daten)
function K:SellChance(itemID)
    if not itemID then return nil end
    if not chanceCache or GetTime() - chanceTime > 60 then
        chanceCache, chanceTime = self:BuildChances(), GetTime()
    end
    local r = chanceCache[itemID]
    if not r or not r.rate or r.posted < 3 then return nil end
    return r
end

function K:InvalidateChances() chanceCache = nil end
A:On("LEDGER_CHANGED", function() K:InvalidateChances() end)

function K:FormatDelay(sec)
    if not sec then return nil end
    if sec < 3600 then return L["unter 1 Std."] end
    if sec < 86400 then return string.format(L["ca. %d Std."], math.floor(sec / 3600 + 0.5)) end
    return string.format(L["ca. %d Tage"], math.floor(sec / 86400 + 0.5))
end

function K:ChanceText(itemID)
    local r = self:SellChance(itemID)
    if not r then return nil end
    local color = (r.rate >= 70 and "33dd55") or (r.rate >= 40 and "ffcc33") or "ff5544"
    local text = string.format("|cff%s%d %%|r (%d/%d)", color, math.floor(r.rate + 0.5), r.sold, r.posted)
    local d = self:FormatDelay(r.delay)
    if d then text = text .. ", " .. d end
    return text
end

-- ============================================================
-- 3. Ablaufende Auktionen
-- ============================================================
function K:ExpiryEnabled() return S().expiryReminder ~= false end

local function EndsDB()
    if not A.db then return {} end
    A.db.ownedEnds = A.db.ownedEnds or {}
    return A.db.ownedEnds
end

-- nach jedem Lesen der eigenen Auktionen: Endzeiten merken, bald ablaufende melden
function K:OnOwnedRead(owned)
    local now = time()
    local ends = {}
    local soon = {}
    self.warned = self.warned or {}
    for _, o in ipairs(owned or {}) do
        if not o.sold and o.itemID and o.timeLeft then
            table.insert(ends, { itemID = o.itemID, qty = o.qty or 1, endsAt = now + o.timeLeft })
            if o.timeLeft <= 1800 and not self.warned[o.auctionID] then
                self.warned[o.auctionID] = true
                table.insert(soon, o)
            end
        end
    end
    if A.db then A.db.ownedEnds = ends end
    if #soon > 0 and self:ExpiryEnabled() then
        local names, cheapest = {}, 0
        for k, o in ipairs(soon) do
            if k <= 4 then table.insert(names, (o.qty or 1) .. "x " .. (o.name or A:GetItemName(o.itemID))) end
            if o.status == "günstigstes" or o.status == "gleich" then cheapest = cheapest + 1 end
        end
        if #soon > 4 then table.insert(names, "...") end
        local msg = string.format(L["|cffffcc33%d Auktionen laufen in weniger als 30 Min. ab:|r %s"], #soon, table.concat(names, ", "))
        if cheapest > 0 then
            msg = msg .. "  " .. string.format(L["(%d davon noch günstigstes Angebot - nach der Rückkehr per Post mit 'Neu einstellen' wieder rein)"], cheapest)
        end
        A:Print(msg)
    end
end

-- beim Einloggen: was ist seit dem letzten Besuch abgelaufen, was läuft bald ab?
function K:LoginExpiryCheck()
    if not self:ExpiryEnabled() then return end
    local now = time()
    local expired, soon, keep = 0, 0, {}
    for _, e in ipairs(EndsDB()) do
        if e.endsAt <= now then
            expired = expired + 1
        else
            if e.endsAt - now <= 2 * 3600 then soon = soon + 1 end
            table.insert(keep, e)
        end
    end
    if A.db then A.db.ownedEnds = keep end
    if expired > 0 then
        A:Print(string.format(L["Seit deinem letzten Besuch sind %d Auktionen abgelaufen - am Briefkasten abholen, dann 'Neu einstellen' (Reiter Auktionen)."], expired))
    end
    if soon > 0 then
        A:Print(string.format(L["%d Auktionen laufen in den nächsten 2 Std. ab."], soon))
    end
end

-- verkauft: nicht mehr als "abgelaufen" zählen
function K:ForgetOne(itemID)
    local list = EndsDB()
    for i, e in ipairs(list) do
        if e.itemID == itemID then table.remove(list, i); return end
    end
end

-- ============================================================
-- 4. Gold-Ziel (alle Charaktere zusammen)
-- ============================================================
function K:GoldGoal() return S().goldGoal end

function K:SetGoldGoal(copper)
    if not A.db then return end
    if copper and copper > 0 then
        A.db.settings.goldGoal = math.floor(copper)
        A.db.settings.goldGoalReached = nil
        self:CheckGoldGoal()
    else
        A.db.settings.goldGoal = nil
        A.db.settings.goldGoalReached = nil
    end
    A:Fire("GOLDGOAL_CHANGED")
end

function K:GoldProgress()
    local goal = self:GoldGoal()
    if not goal then return nil end
    local total = A.Chars and A.Chars:TotalMoney() or (GetMoney and GetMoney()) or 0
    return total, goal, math.min(100, total / goal * 100)
end

function K:GoldGoalText()
    local total, goal, pct = self:GoldProgress()
    if not total then return nil end
    return string.format(L["Gold-Ziel: %s von %s (%d %%)"], A:FormatMoney(total), A:FormatMoney(goal), math.floor(pct))
end

function K:CheckGoldGoal()
    local total, goal = self:GoldProgress()
    if not total or S().goldGoalReached then return false end
    if total >= goal then
        A.db.settings.goldGoalReached = true
        A:Print(string.format(L["|cff33dd55Gold-Ziel erreicht!|r Alle Charaktere zusammen: %s (Ziel %s)."], A:FormatMoney(total), A:FormatMoney(goal)))
        if PlaySound then pcall(PlaySound, 888) end      -- Stufenaufstieg-Klang
        A:Fire("GOLDGOAL_CHANGED")
        return true
    end
    return false
end

-- /ahp ziel 5000  |  /ahp ziel aus  |  /ahp ziel
function K:GoalCommand(arg)
    arg = (arg or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if arg == "" then
        A:Print(self:GoldGoalText() or L["Kein Gold-Ziel gesetzt. Beispiel: /ahp ziel 5000"])
        return
    end
    local low = arg:lower()
    if low == "aus" or low == "off" or low == "0" then
        self:SetGoldGoal(nil)
        A:Print(L["Gold-Ziel gelöscht."])
        return
    end
    local g = tonumber((arg:gsub("[gG]$", ""):gsub("[%.']", ""):gsub(",", ".")))
    if not g or g <= 0 then
        A:Print(L["Kein Gold-Ziel gesetzt. Beispiel: /ahp ziel 5000"])
        return
    end
    self:SetGoldGoal(g * 10000)
    A:Print(self:GoldGoalText())
end

-- ============================================================
-- 5. Gildenbank (ab TBC): Inhalt lesen und bewerten
-- ============================================================
local function GuildName()
    if not GetGuildInfo then return nil end
    local ok, name = pcall(GetGuildInfo, "player")
    return ok and name or nil
end

function K:GuildBankSupported()
    return GetNumGuildBankTabs ~= nil and GetGuildBankItemLink ~= nil
end

local function GuildDB()
    if not A.db then return {} end
    A.db.guildBank = A.db.guildBank or {}
    return A.db.guildBank
end

function K:ScanGuildBank()
    if not self:GuildBankSupported() then return false end
    local guild = GuildName()
    if not guild then return false end
    local db = GuildDB()
    local g = db[guild] or { tabs = {} }
    db[guild] = g
    local nTabs = GetNumGuildBankTabs() or 0
    local slots = MAX_GUILDBANK_SLOTS_PER_TAB or 98
    local read = 0
    for tab = 1, nTabs do
        local okT, _, _, isViewable = pcall(GetGuildBankTabInfo, tab)
        if okT and isViewable ~= false then
            local items, any = {}, false
            for slot = 1, slots do
                local link = GetGuildBankItemLink(tab, slot)
                if link then
                    local id = tonumber(link:match("item:(%d+)"))
                    local _, count = GetGuildBankItemInfo(tab, slot)
                    if id then items[id] = (items[id] or 0) + (count or 1); any = true end
                end
            end
            -- leere Antwort (Fach noch nicht geladen) nicht über alte Daten schreiben
            if any or not g.tabs[tab] then g.tabs[tab] = items; read = read + 1 end
        end
    end
    for tab in pairs(g.tabs) do if tab > nTabs then g.tabs[tab] = nil end end
    if GetGuildBankMoney then local okM, m = pcall(GetGuildBankMoney); if okM and m then g.money = m end end
    g.time = time()
    A:Fire("GUILDBANK_CHANGED")
    return read > 0
end

function K:GuildBankData()
    local guild = GuildName()
    return guild and GuildDB()[guild] or nil, guild
end

-- wie Extras:InventoryValue, nur für die Gildenbank
function K:GuildBankValue()
    local g, guild = self:GuildBankData()
    local rows = {}
    if not g then return rows, { market = 0, vendor = 0, gold = 0, guild = guild } end
    local byID = {}
    for _, items in pairs(g.tabs or {}) do
        for id, n in pairs(items) do byID[id] = (byID[id] or 0) + n end
    end
    local totalMV, totalVendor = 0, 0
    for id, n in pairs(byID) do
        local mv = A:GetMarketValue(id)
        local vp = A:GetVendorPrice(id)
        local r = { itemID = id, count = n, bags = 0, bank = 0, alts = 0, guild = n, unit = mv,
                    value = mv and math.floor(mv * n) or 0, vendorValue = vp and vp * n or 0 }
        r.best = math.max(math.floor(r.value * AH_CUT), r.vendorValue)
        if r.value > 0 or r.vendorValue > 0 then
            r.name = A:GetItemName(id)
            totalMV = totalMV + r.value
            totalVendor = totalVendor + r.vendorValue
            table.insert(rows, r)
        end
    end
    return rows, { market = totalMV, vendor = totalVendor, gold = g.money or 0, guild = guild, time = g.time }
end

-- ============================================================
-- 6. Raid-Vorrat: Tränke, Fläschchen und Buff-Food für eine Raidwoche
-- ============================================================
K.RAID_SETS = {
    classic = {
        { 13446, 10 }, -- Erheblicher Heiltrank
        { 13444, 10 }, -- Erheblicher Manatrank
        { 13510, 1 },  -- Fläschchen der Titanen
        { 13452, 4 },  -- Elixier des Mungos
        { 9206, 4 },   -- Elixier der Riesen
        { 13454, 4 },  -- Großes arkanes Elixier
        { 20007, 4 },  -- Magiebluttrank
        { 3825, 4 },   -- Elixier der Seelenstärke
        { 13457, 5 },  -- Großer Feuerschutztrank
        { 5634, 2 },   -- Trank der freien Aktion
        { 20452, 10 }, -- Geräucherte Wüstenknödel
    },
    tbc = {
        { 22829, 10 }, -- Super-Heiltrank
        { 22832, 10 }, -- Super-Manatrank
        { 22854, 2 },  -- Fläschchen des unerbittlichen Angriffs
        { 22861, 2 },  -- Fläschchen des blendenden Lichts
        { 22851, 2 },  -- Fläschchen der Stärkung
        { 22853, 2 },  -- Fläschchen der mächtigen Wiederherstellung
        { 22838, 4 },  -- Hasttrank
        { 22839, 4 },  -- Zerstörungstrank
        { 27667, 10 }, -- Würziger Flusskrebs
    },
    wrath = {
        { 33447, 10 }, -- Runenheiltrank
        { 33448, 10 }, -- Runenmanatrank
        { 46377, 2 },  -- Fläschchen der endlosen Wut
        { 46376, 2 },  -- Fläschchen des Frostwyrms
        { 46379, 2 },  -- Fläschchen des Steinbluts
        { 40211, 4 },  -- Trank der Schnelligkeit
        { 40212, 4 },  -- Trank der wilden Magie
        { 43015, 2 },  -- Fischfest
    },
}

function K:RaidSetKey()
    local p = WOW_PROJECT_ID
    if p == (WOW_PROJECT_CLASSIC or 2) then return "classic" end
    if p == (WOW_PROJECT_BURNING_CRUSADE_CLASSIC or 5) then return "tbc" end
    if p == (WOW_PROJECT_WRATH_CLASSIC or 11) then return "wrath" end
    -- alte Clients ohne WOW_PROJECT_ID (z.B. private Server)
    if not p then
        local build = GetBuildInfo and select(4, GetBuildInfo()) or 0
        if build < 20000 then return "classic" elseif build < 30000 then return "tbc" elseif build < 40000 then return "wrath" end
    end
    return nil
end

function K:CreateRaidList(weeks)
    local key = self:RaidSetKey()
    local set = key and self.RAID_SETS[key]
    if not set then return false, L["Die Raid-Vorlage gibt es für Classic, TBC und Wrath."] end
    weeks = math.max(1, math.floor(tonumber(weeks) or 1))
    local Li = A.Lists
    local name = L["Raid-Vorrat"]
    if not Li:Exists(name) then Li:Create(name) end
    for _, e in ipairs(set) do
        local qty = e[2] * weeks
        local items = A.db.lists and A.db.lists.items and A.db.lists.items[name]
        if items and items.entries[e[1]] then Li:SetQty(name, e[1], qty) else Li:AddItem(name, tostring(e[1]), qty) end
    end
    local cost = Li.TotalCost and Li:TotalCost(name)
    local msg = string.format(L["Einkaufsliste '%s' mit %d Items angelegt (Mengen für eine Raidwoche, anpassbar)."], name, #set)
    if type(cost) == "number" and cost > 0 then msg = msg .. "  " .. string.format(L["Kosten zum aktuellen Preis: %s"], A:FormatMoney(cost)) end
    return true, msg, name
end

-- ============================================================
-- 7. Favoriten im Einkauf (gespeicherte Suchen)
-- ============================================================
local function FavDB()
    if not A.db then return {} end
    A.db.buyFavorites = A.db.buyFavorites or {}
    return A.db.buyFavorites
end
K.FavDB = FavDB
K.MAX_FAVS = 12

function K:FavLabel(q)
    local parts = {}
    if q.text and q.text ~= "" then table.insert(parts, '"' .. q.text .. '"') end
    if q.cat and q.cat ~= "all" and A.Buy then table.insert(parts, A.Buy:CatLabel(q.cat)) end
    if q.minLevel or q.maxLevel then table.insert(parts, L["St. "] .. (q.minLevel or "") .. "-" .. (q.maxLevel or "")) end
    if q.minIlvl or q.maxIlvl then table.insert(parts, "iLvl " .. (q.minIlvl or "") .. "-" .. (q.maxIlvl or "")) end
    if q.quals then
        local min
        for k = 0, 5 do if q.quals[k] then min = k; break end end
        local names = { [0] = "Grau", "Weiß", "Grün", "Blau", "Episch", "Legendär" }
        if min and names[min] then table.insert(parts, L["ab "] .. L[names[min]]) end
    end
    if #parts == 0 then return L["Alle"] end
    return table.concat(parts, ", ")
end

function K:AddFavorite(q)
    if not q then return false, L["Erst eine Suche starten."] end
    local list = FavDB()
    local copy = { text = q.text or "", cat = q.cat or "all", minLevel = q.minLevel, maxLevel = q.maxLevel,
                   minIlvl = q.minIlvl, maxIlvl = q.maxIlvl }
    if q.quals then copy.quals = {}; for k, v in pairs(q.quals) do copy.quals[k] = v end end
    copy.label = self:FavLabel(copy)
    for _, f in ipairs(list) do
        if f.label == copy.label then return false, L["Diese Suche ist schon ein Favorit."] end
    end
    if #list >= self.MAX_FAVS then return false, string.format(L["Höchstens %d Favoriten."], self.MAX_FAVS) end
    table.insert(list, copy)
    A:Fire("FAVORITES_CHANGED")
    return true, L["Favorit gespeichert: "] .. copy.label
end

function K:RemoveFavorite(index)
    local list = FavDB()
    if not list[index] then return false end
    table.remove(list, index)
    A:Fire("FAVORITES_CHANGED")
    return true
end

-- ------------------------------------------------------------
-- Ereignisse
-- ------------------------------------------------------------
local evt = CreateFrame("Frame")
for _, e in ipairs({ "PLAYER_MONEY", "GUILDBANKFRAME_OPENED", "GUILDBANKBAGSLOTS_CHANGED", "GUILDBANK_UPDATE_MONEY", "GUILDBANKFRAME_CLOSED" }) do
    pcall(evt.RegisterEvent, evt, e)
end
local gbDirty, gbAcc = false, 0
evt:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_MONEY" then
        -- Charaktere zuerst aktualisieren lassen
        if C_Timer and C_Timer.After then C_Timer.After(0.2, function() K:CheckGoldGoal() end) else K:CheckGoldGoal() end
    elseif event == "GUILDBANKFRAME_OPENED" then
        K.gbOpen = true
        if QueryGuildBankTab and GetNumGuildBankTabs then
            for tab = 1, (GetNumGuildBankTabs() or 0) do pcall(QueryGuildBankTab, tab) end
        end
        gbDirty = true
    elseif event == "GUILDBANKFRAME_CLOSED" then
        if gbDirty then K:ScanGuildBank(); gbDirty = false end
        K.gbOpen = false
    else
        gbDirty = true
    end
end)
evt:SetScript("OnUpdate", function(_, dt)
    if not gbDirty then return end
    gbAcc = gbAcc + (dt or 0)
    if gbAcc < 1 then return end
    gbAcc, gbDirty = 0, false
    K:ScanGuildBank()
end)

A:On("READY", function()
    -- eigene Auktionen beobachten
    local Se = A.Seller
    if Se and not Se.__comfortHooked then
        Se.__comfortHooked = true
        local read = Se.ReadOwned
        Se.ReadOwned = function(self, ...)
            local r = read(self, ...)
            pcall(K.OnOwnedRead, K, self.owned)
            return r
        end
        local sold = Se.OnSold
        Se.OnSold = function(self, name, ...)
            local o = self.FindOwnedByName and self:FindOwnedByName(name)
            local id = (o and o.itemID) or (A.FindItemByName and A:FindItemByName(name))
            if id then K:ForgetOne(id) end
            return sold(self, name, ...)
        end
    end
    if C_Timer and C_Timer.After then
        C_Timer.After(10, function() pcall(K.LoginExpiryCheck, K); pcall(K.CheckGoldGoal, K) end)
    end
end)
