-- ============================================================
-- AH Analyzer Pro 5.8 - Preise und Preisverlauf im Item-Tooltip
--
-- Überall, wo WoW einen Item-Tooltip zeigt (Taschen, Auktionshaus,
-- Chat-Links, Listen anderer Addons, unsere eigenen Tabellen):
--   * zusätzliche Zeilen: aktueller Preis (mit % vom Marktwert),
--     Marktwert (Median 14 Tage), Trend 24 Std., Händlerpreis
--   * ein kleines Preisdiagramm direkt unter dem Tooltip
-- Beides lässt sich in den Optionen ein- und ausschalten.
-- Fehler in diesem Modul dürfen den Tooltip nie kaputt machen (pcall).
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local TT = {}
A.Tooltip = TT

local CW, CH = 240, 92                  -- Größe des Diagramms
local PAD_L, PAD_R, PAD_T, PAD_B = 6, 6, 20, 16

-- wählbare Zeiträume für das Diagramm (0 = aus)
TT.PERIODS = { 0, 1, 7, 30 }
local PERIOD_LABEL = { [1] = "24 Std.", [7] = "7 Tage", [30] = "30 Tage" }

function TT:Settings()
    local s = A.db and A.db.settings
    return s
end

function TT:ChartDays()
    local s = self:Settings()
    if not s then return 0 end
    local d = s.tooltipChartDays
    if d == nil then d = 7 end
    return d
end

function TT:PeriodLabel(days)
    days = days or self:ChartDays()
    if days == 0 then return L["aus"] end
    return L[PERIOD_LABEL[days] or "7 Tage"]
end

function TT:CycleChartDays()
    local s = self:Settings()
    if not s then return end
    local cur, i = self:ChartDays(), 1
    for k, d in ipairs(self.PERIODS) do if d == cur then i = k end end
    i = (i % #self.PERIODS) + 1
    s.tooltipChartDays = self.PERIODS[i]
    return s.tooltipChartDays
end

-- ------------------------------------------------------------
-- Diagramm-Fenster (wird einmal gebaut und wiederverwendet)
-- ------------------------------------------------------------
local chart

local function GetChart()
    if chart then return chart end
    local UI, C = A.UI, A.UI.C
    local f = CreateFrame("Frame", "AHAnalyzerProTooltipChart", UIParent)
    f:SetSize(CW, CH)
    f:SetFrameStrata("TOOLTIP")
    f:SetClampedToScreen(true)
    f:EnableMouse(false)
    UI:Box(f, { 0.03, 0.03, 0.05, 0.92 }, C.border)
    f:Hide()

    f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    f.title:SetPoint("TOPLEFT", 6, -5)
    f.title:SetJustifyH("LEFT")
    f.high = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.high:SetPoint("TOPRIGHT", -6, -5)
    f.high:SetJustifyH("RIGHT")
    f.low = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.low:SetPoint("BOTTOMRIGHT", -6, 3)
    f.low:SetJustifyH("RIGHT")
    f.from = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    f.from:SetPoint("BOTTOMLEFT", 6, 3)
    f.from:SetJustifyH("LEFT")

    f.lines, f.dots, f.used = {}, {}, { lines = 0, dots = 0 }
    f.canRotate = true

    function f:Clear()
        for _, t in ipairs(self.lines) do t:Hide() end
        for _, t in ipairs(self.dots) do t:Hide() end
        self.used.lines, self.used.dots = 0, 0
        if self.avg then self.avg:Hide() end
    end

    function f:Dot(x, y, size, r, g, b, a)
        self.used.dots = self.used.dots + 1
        local t = self.dots[self.used.dots]
        if not t then
            t = self:CreateTexture(nil, "OVERLAY")
            self.dots[self.used.dots] = t
        end
        t:SetColorTexture(r, g, b, a or 1)
        t:SetSize(size, size)
        t:ClearAllPoints()
        t:SetPoint("CENTER", self, "BOTTOMLEFT", x, y)
        t:Show()
    end

    function f:Line(x1, y1, x2, y2, r, g, b)
        local dx, dy = x2 - x1, y2 - y1
        local len = math.sqrt(dx * dx + dy * dy)
        if len < 0.5 then return end
        if self.canRotate then
            self.used.lines = self.used.lines + 1
            local t = self.lines[self.used.lines]
            if not t then
                t = self:CreateTexture(nil, "ARTWORK")
                self.lines[self.used.lines] = t
            end
            t:SetColorTexture(r, g, b, 0.95)
            t:ClearAllPoints()
            t:SetSize(len, 2)
            t:SetPoint("CENTER", self, "BOTTOMLEFT", (x1 + x2) / 2, (y1 + y2) / 2)
            local ok = t.SetRotation and pcall(t.SetRotation, t, math.atan2(dy, dx))
            if ok then
                t:Show()
                return
            end
            t:Hide()
            self.canRotate = false
        end
        -- Rückfall ohne Drehen: Linie aus kleinen Punkten
        local steps = math.min(40, math.max(2, math.floor(len / 2)))
        for i = 0, steps do
            self:Dot(x1 + dx * i / steps, y1 + dy * i / steps, 2, r, g, b, 0.95)
        end
    end

    chart = f
    return f
end

-- Preispunkte des Zeitraums
local function Points(itemID, days)
    local out = {}
    local limit = time() - days * 86400
    for _, e in ipairs(A:GetHistory(itemID)) do
        if e.t >= limit and e.p and e.p > 0 and not e.u then table.insert(out, e) end      -- ohne unbestätigte (Lockangebote)
    end
    return out
end

function TT:HideChart(owner)
    if chart and (owner == nil or chart.owner == owner) then
        chart:Hide()
        chart.owner = nil
    end
end

function TT:ShowChart(tooltip, itemID)
    local days = self:ChartDays()
    if days == 0 then return self:HideChart() end
    local points = Points(itemID, days)
    if #points < 2 then return self:HideChart() end

    local f = GetChart()
    local C = A.UI.C
    f:Clear()

    local w = CW
    local tw = tooltip.GetWidth and tooltip:GetWidth()
    if tw and tw > w then w = tw end
    f:SetWidth(w)

    local minP, maxP = points[1].p, points[1].p
    for _, e in ipairs(points) do
        if e.p < minP then minP = e.p end
        if e.p > maxP then maxP = e.p end
    end
    local lo, hi = minP, maxP
    if hi == lo then lo, hi = lo * 0.9, hi * 1.1 + 1 end
    local minT, maxT = points[1].t, points[#points].t
    if maxT == minT then maxT = minT + 1 end

    local plotW, plotH = w - PAD_L - PAD_R, CH - PAD_T - PAD_B
    local function X(t) return PAD_L + (t - minT) / (maxT - minT) * plotW end
    local function Y(p) return PAD_B + (p - lo) / (hi - lo) * plotH end

    -- Linie beim Marktwert (Median der gezeigten Preise)
    local values = {}
    for i, e in ipairs(points) do values[i] = e.p end
    local avg = A.Median(values)
    if not f.avg then f.avg = f:CreateTexture(nil, "BORDER") end
    f.avg:SetColorTexture(1, 0.8, 0.2, 0.35)
    f.avg:ClearAllPoints()
    f.avg:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", PAD_L, Y(avg))
    f.avg:SetSize(plotW, 1)
    f.avg:Show()

    -- Steigt der Preis -> grün, fällt er -> rot, sonst Akzentfarbe
    local first, last = points[1].p, points[#points].p
    local col = C.accent
    if last > first * 1.02 then col = C.green elseif last < first * 0.98 then col = C.red end

    local px, py
    for _, e in ipairs(points) do
        local x, y = X(e.t), Y(e.p)
        if px then f:Line(px, py, x, y, col[1], col[2], col[3]) end
        px, py = x, y
    end
    f:Dot(px, py, 5, 1, 1, 1, 1)          -- aktueller Preis

    f.title:SetText("|cff00d1d1AH Analyzer|r  " .. string.format(L["Preisverlauf (%s)"], self:PeriodLabel(days)))
    f.high:SetText(A:FormatMoney(maxP, true))
    f.low:SetText(A:FormatMoney(minP, true))
    f.from:SetText(date("%d.%m.", minT) .. "  -  " .. date("%d.%m.", maxT))

    -- unter den Tooltip, oder darüber, wenn unten kein Platz ist
    f:ClearAllPoints()
    local bottom = tooltip.GetBottom and tooltip:GetBottom()
    if bottom and bottom < CH + 10 then
        f:SetPoint("BOTTOMLEFT", tooltip, "TOPLEFT", 0, 2)
    else
        f:SetPoint("TOPLEFT", tooltip, "BOTTOMLEFT", 0, -2)
    end
    f.owner = tooltip
    f:Show()
end

-- ------------------------------------------------------------
-- Zusätzliche Zeilen im Tooltip
-- ------------------------------------------------------------
function TT:AddLines(tooltip, itemID)
    local s = self:Settings()
    local showInfo = not (s and s.tooltipInfo == false)
    local vendor = (not s or s.tooltipVendor ~= false) and A:GetVendorPrice(itemID) or nil
    -- beim Händler zeigt WoW den Verkaufspreis selbst an
    if vendor and type(MerchantFrame) == "table" and MerchantFrame.IsShown and MerchantFrame:IsShown() then vendor = nil end
    if vendor and vendor <= 0 then vendor = nil end
    if not showInfo and not vendor then return end
    tooltip:AddLine(" ")
    if not showInfo then
        tooltip:AddDoubleLine("|cff00d1d1AH Analyzer|r  " .. L["Händlerpreis"], A:FormatMoney(vendor), 1, 1, 1, 1, 1, 1)
        return
    end
    local cur = A:GetCurrent(itemID)
    if not cur then
        tooltip:AddLine(L["AH Analyzer: noch keine Preisdaten"], 0.6, 0.6, 0.6)
        if vendor then tooltip:AddDoubleLine(L["Händlerpreis"], A:FormatMoney(vendor), 0.8, 0.8, 0.8, 1, 1, 1) end
        TT:AddExtraLines(tooltip, itemID)
        return
    end
    local pct = A:GetMarketPercent(itemID, cur)
    local priceText = A:FormatMoney(cur)
    if pct then priceText = priceText .. "  (" .. A:FormatMarketPercent(pct) .. ")" end
    tooltip:AddDoubleLine("|cff00d1d1AH Analyzer|r  " .. L["Preis"], priceText, 1, 1, 1, 1, 1, 1)
    local mv = A:GetMarketValue(itemID)
    if mv then
        tooltip:AddDoubleLine(L["Marktwert (Median 14 Tage)"], A:FormatMoney(mv), 0.8, 0.8, 0.8, 1, 1, 1)
    end
    local trend = A:GetTrend(itemID, 86400)
    if trend then
        tooltip:AddDoubleLine(L["Trend 24 Std."], A:FormatPercent(trend), 0.8, 0.8, 0.8, 1, 1, 1)
    end
    if vendor then
        local color = (vendor > cur) and "|cff33dd55" or ""
        tooltip:AddDoubleLine(L["Händlerpreis"], color .. A:FormatMoney(vendor) .. (color ~= "" and "|r" or ""), 0.8, 0.8, 0.8, 1, 1, 1)
    end
    TT:AddExtraLines(tooltip, itemID)
    local w = A.db.watchlist[itemID]
    if w and (w.buyBelow or w.sellAbove) then
        local parts = {}
        if w.buyBelow then table.insert(parts, L["Kaufen <"] .. " " .. A:FormatMoney(w.buyBelow, true)) end
        if w.sellAbove then table.insert(parts, L["Verkaufen >"] .. " " .. A:FormatMoney(w.sellAbove, true)) end
        tooltip:AddDoubleLine(L["Watchlist"], table.concat(parts, "  "), 0.8, 0.8, 0.8, 1, 1, 1)
    end
end

-- Zusatzzeilen: beim Händler kaufen, Entzauberungswert, Bestand der Twinks
function TT:AddExtraLines(tooltip, itemID)
    local s = self:Settings() or {}
    local atMerchant = type(MerchantFrame) == "table" and MerchantFrame.IsShown and MerchantFrame:IsShown()
    local buy = A:GetVendorBuyPrice(itemID)
    if buy and not atMerchant then
        tooltip:AddDoubleLine(L["Beim Händler kaufen"], A:FormatMoney(buy), 0.8, 0.8, 0.8, 1, 1, 1)
    end
    if s.tooltipDE ~= false and A.Disenchant then
        local v, complete, _, learned = A.Disenchant:GetValue(itemID)
        if v then
            local label = (learned and learned > 0) and string.format(L["Entzaubern (Ø, %d eigene)"], learned) or L["Entzaubern (Ø)"]
            tooltip:AddDoubleLine(label, "~" .. A:FormatMoney(v) .. (complete and "" or " +?"), 0.8, 0.8, 0.8, 1, 1, 1)
        end
    end
    if s.tooltipChance ~= false and A.Comfort then
        local chance = A.Comfort:ChanceText(itemID)
        if chance then tooltip:AddDoubleLine(L["Verkaufschance (deine)"], chance, 0.8, 0.8, 0.8, 1, 1, 1) end
    end
    if s.tooltipChars ~= false and A.Chars then
        local list, total = A.Chars:ItemCounts(itemID)
        local others = 0
        for _, c in ipairs(list) do if not c.me then others = others + 1 end end
        if others > 0 then
            local parts = {}
            for k, c in ipairs(list) do
                if k > 4 then table.insert(parts, "..."); break end
                local n = c.bags + c.bank
                local where = (c.bank > 0 and c.bags == 0) and L[" (Bank)"] or ""
                table.insert(parts, c.name .. " " .. n .. where)
            end
            tooltip:AddDoubleLine(string.format(L["Bestand (%d)"], total), table.concat(parts, ", "), 0.8, 0.8, 0.8, 1, 1, 1)
        end
    end
end

-- Item-ID aus Tooltip-Daten oder Tooltip-Link
local function ItemIDOf(tooltip, data)
    if type(data) == "table" and type(data.id) == "number" then return data.id end
    if tooltip.GetItem then
        local ok, _, link = pcall(tooltip.GetItem, tooltip)
        if ok and type(link) == "string" then
            local id = link:match("item:(%d+)")
            if id then return tonumber(id) end
        end
    end
    return nil
end

local MAIN_TIPS = {}      -- Tooltips, unter denen das Diagramm erscheinen darf

function TT:Handle(tooltip, data)
    if not A.db or type(tooltip) ~= "table" or not tooltip.AddLine then return end
    local itemID = ItemIDOf(tooltip, data)
    if not itemID then return end
    -- jede Tooltip-Anzeige nur einmal ergänzen
    if tooltip.__ahapItem == itemID then return end
    tooltip.__ahapItem = itemID
    self:AddLines(tooltip, itemID)
    if MAIN_TIPS[tooltip] then self:ShowChart(tooltip, itemID) end
end

local function Cleared(tooltip)
    tooltip.__ahapItem = nil
    TT:HideChart(tooltip)
end

-- ------------------------------------------------------------
-- Einhängen (neue Clients: TooltipDataProcessor, ältere: OnTooltipSetItem)
-- ------------------------------------------------------------
function TT:Install()
    if self.installed then return end
    self.installed = true
    for _, tip in ipairs({ GameTooltip, ItemRefTooltip }) do
        if type(tip) == "table" then
            MAIN_TIPS[tip] = true
            if tip.HookScript then
                pcall(tip.HookScript, tip, "OnTooltipCleared", Cleared)
                pcall(tip.HookScript, tip, "OnHide", Cleared)
            end
        end
    end
    local handler = function(tooltip, data)
        local ok, err = pcall(TT.Handle, TT, tooltip, data)
        if not ok and not TT.reported then
            TT.reported = true
            A:Print("Tooltip: " .. tostring(err))
        end
    end
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, handler)
        self.mode = "TooltipDataProcessor"
    else
        local tips = { GameTooltip, ItemRefTooltip, ShoppingTooltip1, ShoppingTooltip2 }
        for _, tip in ipairs(tips) do
            if type(tip) == "table" and tip.HookScript then
                pcall(tip.HookScript, tip, "OnTooltipSetItem", function(t) handler(t) end)
                if not MAIN_TIPS[tip] then pcall(tip.HookScript, tip, "OnTooltipCleared", Cleared) end
            end
        end
        self.mode = "OnTooltipSetItem"
    end
end

function TT:GetDebugText()
    return "Modus=" .. tostring(self.mode) .. ", Zeilen=" .. ((A.db and A.db.settings.tooltipInfo == false) and "aus" or "an")
        .. ", Händlerpreis=" .. ((A.db and A.db.settings.tooltipVendor == false) and "aus" or "an")
        .. ", Diagramm=" .. self:PeriodLabel()
end

A:On("READY", function() TT:Install() end)
