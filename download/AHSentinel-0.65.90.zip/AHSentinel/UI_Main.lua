if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.8 - Hauptfenster, Designs, Tab-System, Bausteine
--
-- Zwei Designs, jederzeit umschaltbar (Optionen oder /ahs design):
--   "classic" - im Stil des WoW-Auktionshauses: dunkles Holz, Goldrahmen,
--               rote WoW-Knöpfe, Reiter unten am Fenster
--   "modern"  - flach und dunkel mit Cyan-Akzent
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
-- Retail 12.x: die alten Item-/Zauber-Funktionen gibt es nur noch in C_Item / C_Spell
local GetItemInfo = GetItemInfo or (C_Item and C_Item.GetItemInfo)
local GetItemInfoInstant = GetItemInfoInstant or (C_Item and C_Item.GetItemInfoInstant)
local GetItemIcon = GetItemIcon or (C_Item and C_Item.GetItemIconByID)
local A = AHAnalyzerPro
local L = A.L

local UI = {}
A.UI = UI

-- ------------------------------------------------------------
-- Farbpaletten
-- ------------------------------------------------------------
UI.THEMES = {
    modern = {
        label     = "Modern",
        bg        = { 0.07, 0.075, 0.09, 0.97 },
        panel     = { 0.11, 0.12, 0.145, 1 },
        panel2    = { 0.14, 0.15, 0.18, 1 },
        border    = { 0.22, 0.24, 0.29, 1 },
        frameEdge = { 0, 0, 0, 1 },
        bar       = { 0.045, 0.05, 0.06, 1 },
        input     = { 0.05, 0.055, 0.07, 1 },
        accent    = { 0.0, 0.82, 0.82, 1 },
        accentDim = { 0.0, 0.40, 0.42, 1 },
        heading   = { 0.92, 0.93, 0.96, 1 },
        text      = { 0.92, 0.93, 0.96, 1 },
        textDim   = { 0.58, 0.60, 0.66, 1 },
        green     = { 0.20, 0.87, 0.33, 1 },
        red       = { 1.00, 0.33, 0.27, 1 },
        yellow    = { 1.00, 0.80, 0.20, 1 },
    },
    classic = {
        label     = "Klassisch",
        bg        = { 0.11, 0.075, 0.04, 0.97 },     -- dunkles Holz
        panel     = { 0.035, 0.025, 0.015, 0.92 },   -- Listenhintergrund
        panel2    = { 0.20, 0.14, 0.07, 1 },         -- Kopfzeilen
        border    = { 0.58, 0.45, 0.20, 1 },         -- Goldrahmen
        frameEdge = { 0.72, 0.58, 0.28, 1 },
        bar       = { 0.17, 0.115, 0.06, 1 },
        input     = { 0.02, 0.015, 0.01, 1 },
        accent    = { 1.00, 0.82, 0.00, 1 },         -- WoW-Gold
        accentDim = { 0.55, 0.10, 0.06, 1 },
        heading   = { 1.00, 0.82, 0.00, 1 },
        text      = { 1.00, 0.97, 0.90, 1 },
        textDim   = { 0.75, 0.66, 0.50, 1 },
        green     = { 0.20, 0.87, 0.33, 1 },
        red       = { 1.00, 0.33, 0.27, 1 },
        yellow    = { 1.00, 0.80, 0.20, 1 },
    },
}

-- UI.C ist EINE Tabelle, die beim Umschalten neu befüllt wird.
-- Alle Tabs halten eine Referenz darauf und bekommen so automatisch die neuen Farben.
UI.C = {}
local C = UI.C
UI.theme = "modern"

function UI:ApplyPalette(name)
    if not self.THEMES[name] then name = "classic" end
    self.theme = name
    for k, v in pairs(self.THEMES[name]) do
        if type(v) == "table" then C[k] = { v[1], v[2], v[3], v[4] } else C[k] = v end
    end
end
UI:ApplyPalette("modern")

function UI:IsClassic()
    return self.theme == "classic"
end

local TEX = {
    btnUp       = "Interface\\Buttons\\UI-Panel-Button-Up",
    btnDown     = "Interface\\Buttons\\UI-Panel-Button-Down",
    btnDisabled = "Interface\\Buttons\\UI-Panel-Button-Disabled",
    btnHL       = "Interface\\Buttons\\UI-Panel-Button-Highlight",
    tabActive   = "Interface\\PaperDollInfoFrame\\UI-Character-ActiveTab",
    tabInactive = "Interface\\PaperDollInfoFrame\\UI-Character-InActiveTab",
    close       = "Interface\\Buttons\\UI-Panel-MinimizeButton-Up",
    closeDown   = "Interface\\Buttons\\UI-Panel-MinimizeButton-Down",
    closeHL     = "Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight",
}
UI.TEX = TEX

-- ------------------------------------------------------------
-- Grundbausteine (ohne BackdropTemplate, läuft auf jedem Client)
-- ------------------------------------------------------------
-- Farbverlauf auf einer Textur (neue und alte Client-Schnittstelle).
-- VERTICAL: 1 = unten, 2 = oben; HORIZONTAL: 1 = links, 2 = rechts
function UI:Gradient(tex, orientation, r1, g1, b1, a1, r2, g2, b2, a2)
    tex:SetColorTexture(1, 1, 1, 1)
    if tex.SetGradientAlpha and pcall(tex.SetGradientAlpha, tex, orientation, r1, g1, b1, a1, r2, g2, b2, a2) then return true end
    if tex.SetGradient and CreateColor then
        local ok = pcall(tex.SetGradient, tex, orientation, CreateColor(r1, g1, b1, a1), CreateColor(r2, g2, b2, a2))
        if ok then return true end
    end
    tex:SetColorTexture(r2, g2, b2, (a1 + a2) / 2)      -- ohne Verlauf: Mittelwert
    return false
end

function UI:Box(frame, bg, border, thickness)
    if not frame.__bg then
        frame.__bg = frame:CreateTexture(nil, "BACKGROUND")
        frame.__bg:SetAllPoints()
        -- dezenter Glanz von oben (gibt den Flächen Tiefe)
        frame.__sheen = frame:CreateTexture(nil, "BACKGROUND", nil, 1)
        frame.__sheen:SetPoint("TOPLEFT")
        frame.__sheen:SetPoint("TOPRIGHT")
        frame.__sheen:SetPoint("BOTTOM", frame, "CENTER", 0, 0)
    end
    frame.__bg:SetColorTexture(unpack(bg or C.panel))
    UI:Gradient(frame.__sheen, "VERTICAL", 1, 1, 1, 0, 1, 0.92, 0.75, 0.045)
    if border then
        local th = thickness or 1
        if not frame.__edges then
            frame.__edges = {}
            for i = 1, 4 do frame.__edges[i] = frame:CreateTexture(nil, "BORDER") end
            local t, b, l, r = unpack(frame.__edges)
            t:SetPoint("TOPLEFT"); t:SetPoint("TOPRIGHT"); t:SetHeight(th)
            b:SetPoint("BOTTOMLEFT"); b:SetPoint("BOTTOMRIGHT"); b:SetHeight(th)
            l:SetPoint("TOPLEFT"); l:SetPoint("BOTTOMLEFT"); l:SetWidth(th)
            r:SetPoint("TOPRIGHT"); r:SetPoint("BOTTOMRIGHT"); r:SetWidth(th)
        end
        for _, e in ipairs(frame.__edges) do e:SetColorTexture(unpack(border)) end
        -- feiner Schatten innen am Rahmen (wirkt wie eingelegt)
        if not frame.__inner then
            frame.__inner = {}
            local th = thickness or 1
            for i = 1, 2 do frame.__inner[i] = frame:CreateTexture(nil, "BORDER", nil, -1) end
            local t, l = frame.__inner[1], frame.__inner[2]
            t:SetPoint("TOPLEFT", th, -th); t:SetPoint("TOPRIGHT", -th, -th); t:SetHeight(1)
            l:SetPoint("TOPLEFT", th, -th); l:SetPoint("BOTTOMLEFT", th, th); l:SetWidth(1)
        end
        for _, e in ipairs(frame.__inner) do e:SetColorTexture(0, 0, 0, 0.55) end
    end
    return frame
end

-- ------------------------------------------------------------
-- Überschrift eines Reiters: Symbol, Titel und eine auslaufende Goldlinie
-- ------------------------------------------------------------
UI.TAB_ICONS = {
    overview = "Interface\\Icons\\INV_Misc_Spyglass_03",
    buy = "Interface\\Icons\\INV_Misc_Coin_02",
    market = "Interface\\Icons\\INV_Scroll_03",
    watchlist = "Interface\\Icons\\Spell_Holy_MindVision",
    sniper = "Interface\\Icons\\Ability_Hunter_SniperShot",
    watcher = "Interface\\Icons\\Ability_Hunter_EagleEye",
    sell = "Interface\\Icons\\INV_Misc_Bag_10",
    auctions = "Interface\\Icons\\INV_Misc_Note_02",
    charts = "Interface\\Icons\\INV_Misc_Map_01",
    profit = "Interface\\Icons\\INV_Misc_Coin_01",
    ledger = "Interface\\Icons\\INV_Scroll_08",
}

function UI:TabTitle(parent, text, tabID)
    local icon = parent:CreateTexture(nil, "ARTWORK")
    icon:SetSize(20, 20)
    icon:SetPoint("TOPLEFT", 0, 1)
    icon:SetTexture(self.TAB_ICONS[tabID] or "Interface\\Icons\\INV_Misc_Coin_02")
    if icon.SetTexCoord then icon:SetTexCoord(0.08, 0.92, 0.08, 0.92) end
    local fs = UI:Label(parent, text, "GameFontNormalLarge", C.heading)
    fs:SetPoint("LEFT", icon, "RIGHT", 7, 0)
    if fs.SetShadowOffset then fs:SetShadowOffset(1, -1) end
    local line = parent:CreateTexture(nil, "BORDER")
    line:SetHeight(1)
    line:SetPoint("LEFT", fs, "RIGHT", 10, 0)
    line:SetWidth(140)
    UI:Gradient(line, "HORIZONTAL", C.accent[1], C.accent[2], C.accent[3], 0.55, C.accent[1], C.accent[2], C.accent[3], 0)
    fs.icon, fs.line = icon, line
    return fs
end

function UI:Label(parent, text, font, color)
    -- große Überschriften: im klassischen Design golden wie bei Blizzard
    if font == "GameFontNormalLarge" and (color == nil or color == C.text) then color = C.heading end
    local fs = parent:CreateFontString(nil, "OVERLAY", font or "GameFontHighlight")
    fs:SetText(text or "")
    fs:SetTextColor(unpack(color or C.text))
    fs:SetJustifyH("LEFT")
    return fs
end

-- Tooltip neben das eigene Fenster setzen, nie über dessen Knöpfe (Befund 20:15 B3, wie ProfessionSentinel 0.9.32):
-- rechts neben dem obersten Fenster auf Höhe des Elements, links, wenn rechts kein Platz ist.
function UI:AnchorTooltip(owner)
    GameTooltip:SetOwner(owner, "ANCHOR_NONE")
    GameTooltip:ClearAllPoints()
    local top = owner
    while top.GetParent and top:GetParent() and top:GetParent() ~= UIParent do top = top:GetParent() end
    local ok = pcall(function()
        local s1, s2 = owner:GetEffectiveScale(), top:GetEffectiveScale()
        local dy = ((owner:GetTop() or 0) * s1 - (top:GetTop() or 0) * s2) / s2
        local right = (top:GetRight() or 0) * s2
        local screen = (UIParent:GetRight() or 0) * UIParent:GetEffectiveScale()
        if top == owner or right + 300 * s2 < screen then
            GameTooltip:SetPoint("TOPLEFT", top, "TOPRIGHT", 4, dy)
        else
            GameTooltip:SetPoint("TOPRIGHT", top, "TOPLEFT", -4, dy)
        end
    end)
    if not ok then GameTooltip:SetOwner(owner, "ANCHOR_CURSOR") end
end

local function ShowTooltip(self)
    if self.tooltip then
        UI:AnchorTooltip(self)
        GameTooltip:SetText(self.tooltip, 1, 1, 1, 1, true)
        GameTooltip:Show()
    end
end

-- Knopf. style: "primary" | "normal" | "danger"
-- Klassisch: roter WoW-Knopf mit Goldschrift. Modern: flacher Knopf.
function UI:Button(parent, text, width, height, onClick, style)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width or 120, height or 24)
    b.enabledState = true
    local classic = UI:IsClassic()

    b.label = b:CreateFontString(nil, "OVERLAY", classic and "GameFontNormalSmall" or "GameFontHighlightSmall")
    b.label:SetPoint("CENTER", 0, classic and 1 or 0)
    b.label:SetText(text or "")
    local textColor = (classic and style ~= "primary") and C.accent or C.text

    if classic then
        b.__tex = b:CreateTexture(nil, "BACKGROUND")
        b.__tex:SetAllPoints()
        b.__hl = b:CreateTexture(nil, "HIGHLIGHT")
        b.__hl:SetAllPoints()
        b.__hl:SetTexture(TEX.btnHL)
        b.__hl:SetTexCoord(0, 0.625, 0, 0.6875)
        if b.__hl.SetBlendMode then b.__hl:SetBlendMode("ADD") end
        function b:Paint(path)
            self.__tex:SetTexture(path)
            self.__tex:SetTexCoord(0, 0.625, 0, 0.6875)
        end
        b:Paint(TEX.btnUp)
        b:SetScript("OnMouseDown", function(self)
            if self.enabledState then self:Paint(TEX.btnDown); self.label:SetPoint("CENTER", 1, 0) end
        end)
        b:SetScript("OnMouseUp", function(self)
            if self.enabledState then self:Paint(TEX.btnUp) end
            self.label:SetPoint("CENTER", 0, 1)
        end)
        b:SetScript("OnEnter", ShowTooltip)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    else
        local base = (style == "primary" and C.accentDim) or (style == "danger" and { 0.45, 0.12, 0.10, 1 }) or C.panel2
        local hover = (style == "primary" and C.accent) or (style == "danger" and { 0.70, 0.18, 0.15, 1 }) or { 0.20, 0.22, 0.27, 1 }
        b.__base, b.__hover = base, hover
        UI:Box(b, base, C.border)
        b:SetScript("OnEnter", function(self)
            if self.enabledState then self.__bg:SetColorTexture(unpack(hover)) end
            ShowTooltip(self)
        end)
        b:SetScript("OnLeave", function(self)
            self.__bg:SetColorTexture(unpack(self.enabledState and base or { 0.12, 0.12, 0.14, 1 }))
            GameTooltip:Hide()
        end)
    end
    b.label:SetTextColor(unpack(textColor))

    b:SetScript("OnClick", function(self, ...)
        if self.enabledState and onClick then onClick(self, ...) end
    end)
    function b:SetText(t) self.label:SetText(t) end
    function b:GetText() return self.label:GetText() end
    function b:SetActive(on)
        self.enabledState = on and true or false
        if self.__tex then
            self:Paint(on and TEX.btnUp or TEX.btnDisabled)
            self.__hl:SetAlpha(on and 1 or 0)
        else
            self.__bg:SetColorTexture(unpack(on and self.__base or { 0.12, 0.12, 0.14, 1 }))
        end
        self.label:SetTextColor(unpack(on and textColor or C.textDim))
    end
    return b
end

-- Eingabefeld mit Platzhaltertext
function UI:EditBox(parent, width, height, placeholder)
    local e = CreateFrame("EditBox", nil, parent)
    e:SetSize(width or 150, height or 22)
    e:SetAutoFocus(false)
    e:SetFontObject(ChatFontNormal or GameFontHighlight)
    e:SetTextInsets(6, 6, 0, 0)
    e:SetMaxLetters(80)
    UI:Box(e, C.input, C.border)
    e.placeholder = e:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    e.placeholder:SetPoint("LEFT", 7, 0)
    e.placeholder:SetPoint("RIGHT", -4, 0)          -- nie über den Rand hinaus (sonst überlappen Nachbarfelder)
    e.placeholder:SetJustifyH("LEFT")
    if e.placeholder.SetWordWrap then e.placeholder:SetWordWrap(false) end
    e.placeholder:SetText(placeholder or "")
    local function updatePlaceholder(self)
        if self:GetText() == "" and not self:HasFocus() then self.placeholder:Show() else self.placeholder:Hide() end
    end
    e:SetScript("OnEditFocusGained", function(self)
        self.placeholder:Hide()
        for _, edge in ipairs(self.__edges) do edge:SetColorTexture(unpack(C.accent)) end
    end)
    e:SetScript("OnEditFocusLost", function(self)
        updatePlaceholder(self)
        for _, edge in ipairs(self.__edges) do edge:SetColorTexture(unpack(C.border)) end
    end)
    e:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    e:SetScript("OnTabPressed", function(self)
        if self.nextBox then self.nextBox:SetFocus() else self:ClearFocus() end
    end)
    e.UpdatePlaceholder = updatePlaceholder
    return e
end

-- ------------------------------------------------------------
-- Geld-Eingabe wie im Auktionshaus: [Gold] (G) [Silber] (S) [Kupfer] (K)
-- Gold darf Nachkommastellen haben (12.5) - eingefügter Text wie "12g 50s 3k" geht auch.
-- m:GetCopper(), m:SetCopper(kupfer), m:Clear(), m:SetFocus(), m.boxes = { gold, silber, kupfer }
-- ------------------------------------------------------------
local COIN_TEX = {
    "Interface\\MoneyFrame\\UI-GoldIcon",
    "Interface\\MoneyFrame\\UI-SilverIcon",
    "Interface\\MoneyFrame\\UI-CopperIcon",
}

function UI:MoneyInput(parent, onChange)
    -- EIN Feld statt drei: "5s", "1g 20s", "4s85k", "1.5" (= Gold). Rechts steht immer, was verstanden wurde.
    -- Drei kleine Felder führten zu Fehleingaben (Silber getippt, im Gold-Feld gelandet).
    local m = CreateFrame("Frame", nil, parent)
    m:SetSize(154, 24)
    local e = UI:EditBox(m, 154, 24, L["z. B. 5s oder 1g 20s"])
    e:SetPoint("LEFT", 0, 0)
    e:SetMaxLetters(24)
    e:SetTextInsets(6, 6, 0, 0)
    e.hint = e:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    e.hint:SetPoint("RIGHT", -6, 0)
    e.hint:SetJustifyH("RIGHT")
    local function updateHint()
        local text = e:GetText() or ""
        if text:match("^%s*$") then e.hint:SetText(""); return end
        local copper = A:ParseGold(text)
        if not copper then
            e.hint:SetText("|cffff5544?|r")
        else
            -- immer zeigen, was verstanden wurde (reine Zahl = Gold, "5s" = 5 Silber ...)
            e.hint:SetText("= " .. A:FormatMoney(copper))
        end
    end
    e:SetScript("OnTextChanged", function(self, userInput)
        updateHint()
        if onChange then onChange(m, userInput) end
    end)
    -- nach der Eingabe einheitlich schreiben (z. B. "120s" -> "1g 20s")
    e:HookScript("OnEditFocusLost", function(self)
        local copper = A:ParseGold(self:GetText())
        if copper then self:SetText(A:FormatMoneyInput(copper)) end
        updateHint()
    end)
    m.edit = e
    m.boxes = { e, e, e }      -- alte Schnittstelle (drei Felder) zeigt auf dasselbe Feld

    function m:GetCopper() return A:ParseGold(self.edit:GetText()) end

    function m:SetCopper(copper)
        if not copper or copper <= 0 then return self:Clear() end
        self.edit:SetText(A:FormatMoneyInput(copper))
        self.edit:UpdatePlaceholder()
        updateHint()
    end

    function m:Clear()
        self.edit:SetText(""); self.edit:ClearFocus(); self.edit:UpdatePlaceholder()
        updateHint()
    end

    function m:SetFocus() self.edit:SetFocus() end

    function m:SetOnEnter(fn) self.edit:SetScript("OnEnterPressed", fn) end

    m.tooltip = L["Betrag: z. B. 5s, 1g 20s, 4s 85c oder 1.5 (= 1g 50s)"]
    e.tooltip = m.tooltip
    return m
end

-- ------------------------------------------------------------
-- Seltenheit: Aufklappmenü zum Anhaken (Grau, Weiß, Grün, Blau, Episch)
-- q = UI:QualityPicker(parent, width, onChange)
--   q:GetSet()  -> nil (alle) oder { [Qualität] = true, ... }
--   q:SetSet(set) / q:Reset()
-- ------------------------------------------------------------
UI.QUALITIES = {
    { q = 0, name = "Grau", color = "9d9d9d" },
    { q = 1, name = "Weiß", color = "ffffff" },
    { q = 2, name = "Grün", color = "1eff00" },
    { q = 3, name = "Blau", color = "0070dd" },
    { q = 4, name = "Episch", color = "a335ee" },
}

-- Kurztext einer Auswahl: "Alle Seltenheiten", "Grün - Episch" oder "Grün, Episch"
function UI:QualitySummary(set)
    if not set then return L["Alle Seltenheiten"] end
    local on = {}
    for _, d in ipairs(self.QUALITIES) do if set[d.q] then table.insert(on, d) end end
    if #on == 0 then return "|cffff5544" .. L["keine"] .. "|r" end
    if #on == #self.QUALITIES then return L["Alle Seltenheiten"] end
    local function c(d) return "|cff" .. d.color .. L[d.name] .. "|r" end
    local contiguous = (on[#on].q - on[1].q + 1) == #on
    if #on == 1 then return c(on[1]) end
    if contiguous and #on > 2 then return c(on[1]) .. " - " .. c(on[#on]) end
    local parts = {}
    for _, d in ipairs(on) do table.insert(parts, c(d)) end
    return table.concat(parts, ", ")
end

function UI:QualityPicker(parent, width, onChange)
    local p = UI:Button(parent, "", width or 150, 24)
    p.sel = {}
    for _, d in ipairs(UI.QUALITIES) do p.sel[d.q] = true end

    local menu = CreateFrame("Frame", nil, p)
    menu:SetFrameStrata("FULLSCREEN_DIALOG")
    menu:SetPoint("TOPLEFT", p, "BOTTOMLEFT", 0, -2)
    menu:SetSize(math.max(width or 150, 150), 24 + (#UI.QUALITIES + 1) * 22)
    menu:EnableMouse(true)
    UI:Box(menu, { C.bg[1], C.bg[2], C.bg[3], 1 }, C.frameEdge or C.border)
    menu:Hide()
    p.menu = menu

    local rows = {}
    local function changed()
        p:Refresh()
        if onChange then onChange(p:GetSet()) end
    end
    local function addRow(i, label, fn)
        local b = CreateFrame("Button", nil, menu)
        b:SetSize(menu:GetWidth() - 12, 20)
        b:SetPoint("TOPLEFT", 6, -6 - (i - 1) * 22)
        b.box = b:CreateTexture(nil, "ARTWORK")
        b.box:SetSize(16, 16)
        b.box:SetPoint("LEFT", 2, 0)
        b.box:SetTexture("Interface\\Buttons\\UI-CheckBox-Up")
        b.check = b:CreateTexture(nil, "OVERLAY")
        b.check:SetSize(16, 16)
        b.check:SetPoint("LEFT", 2, 0)
        b.check:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
        b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        b.text:SetPoint("LEFT", 24, 0)
        b.text:SetText(label)
        local hl = b:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        hl:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.15)
        b:SetScript("OnClick", fn)
        rows[i] = b
        return b
    end
    -- "Alle" an/aus
    p.allRow = addRow(1, L["Alle"], function()
        local all = true
        for _, d in ipairs(UI.QUALITIES) do if not p.sel[d.q] then all = false end end
        for _, d in ipairs(UI.QUALITIES) do p.sel[d.q] = not all end
        changed()
    end)
    p.rows = {}
    for i, d in ipairs(UI.QUALITIES) do
        p.rows[d.q] = addRow(i + 1, "|cff" .. d.color .. L[d.name] .. "|r", function()
            p.sel[d.q] = not p.sel[d.q]
            changed()
        end)
    end
    local ok = UI:Button(menu, L["OK"], 60, 20, function() menu:Hide() end)
    ok:SetPoint("BOTTOMRIGHT", -6, 6)

    -- schließt sich, wenn die Maus länger weg ist
    menu.away = 0
    menu:SetScript("OnUpdate", function(self, dt)
        local over = (self.IsMouseOver and self:IsMouseOver()) or (p.IsMouseOver and p:IsMouseOver())
        if over then self.away = 0 return end
        self.away = self.away + (dt or 0)
        if self.away > 2 then self:Hide() end
    end)

    p:SetScript("OnClick", function()
        if menu:IsShown() then menu:Hide() else menu.away = 0; menu:Show() end
    end)
    p.tooltip = L["Seltenheit: anklicken, dann die gewünschten anhaken"]

    function p:GetSet()
        local all, set = true, {}
        for _, d in ipairs(UI.QUALITIES) do
            if self.sel[d.q] then set[d.q] = true else all = false end
        end
        if all then return nil end
        return set
    end
    function p:SetSet(set)
        for _, d in ipairs(UI.QUALITIES) do self.sel[d.q] = (set == nil) or (set[d.q] and true or false) end
        self:Refresh()
    end
    function p:Reset() self:SetSet(nil) end
    function p:Refresh()
        self:SetText(UI:QualitySummary(self:GetSet()))
        local all = true
        for _, d in ipairs(UI.QUALITIES) do
            local r = self.rows[d.q]
            if self.sel[d.q] then r.check:Show() else r.check:Hide(); all = false end
        end
        if all then self.allRow.check:Show() else self.allRow.check:Hide() end
    end
    p:Refresh()
    return p
end

-- Tab-Reihenfolge für mehrere Eingabefelder (Tab-Taste springt weiter)
function UI:ChainEdits(list)
    -- doppelte Einträge (z. B. Geldfeld = ein Feld) nur einmal
    local seen, uniq = {}, {}
    for _, e in ipairs(list) do if not seen[e] then seen[e] = true; table.insert(uniq, e) end end
    for i, e in ipairs(uniq) do e.nextBox = uniq[i + 1] or uniq[1] end
end

-- Kennzahl-Karte
function UI:Card(parent, width, height, title, icon)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(width, height)
    UI:Box(f, C.panel, C.border)
    if icon then
        -- Symbol rechts, leicht abgedunkelt im Hintergrund der Karte
        f.icon = f:CreateTexture(nil, "ARTWORK")
        f.icon:SetTexture(icon)
        f.icon:SetSize(height - 22, height - 22)
        f.icon:SetPoint("RIGHT", -10, 0)
        if f.icon.SetTexCoord then f.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92) end
        if f.icon.SetAlpha then f.icon:SetAlpha(0.85) end
    end
    local bar = f:CreateTexture(nil, "ARTWORK")
    bar:SetColorTexture(unpack(C.accent))
    bar:SetPoint("TOPLEFT"); bar:SetPoint("BOTTOMLEFT"); bar:SetWidth(3)
    f.bar = bar
    f.title = UI:Label(f, title, "GameFontNormalSmall", C.textDim)
    f.title:SetPoint("TOPLEFT", 12, -9)
    f.value = UI:Label(f, "-", "GameFontNormalLarge", C.text)
    f.value:SetTextColor(unpack(C.text))
    if f.value.SetShadowOffset then f.value:SetShadowOffset(1, -1) end
    local pa = C.panel[4] or 1
    UI:Gradient(f.__bg, "VERTICAL", C.panel[1], C.panel[2], C.panel[3], pa,
        math.min(1, C.panel[1] + 0.06), math.min(1, C.panel[2] + 0.045), math.min(1, C.panel[3] + 0.025), pa)
    f.value:SetPoint("TOPLEFT", 12, -26)
    f.sub = UI:Label(f, "", "GameFontDisableSmall", C.textDim)
    f.sub:SetPoint("BOTTOMLEFT", 12, 8)
    return f
end

-- ------------------------------------------------------------
-- Tabelle mit Kopfzeile, Sortierung, Mausrad-Blättern
-- cfg = {
--   columns = { { key, title, width, align, tooltip }, ... },
--   rows = 15, rowHeight = 22,
--   cell = function(item, key) return text end,
--   sortValue = function(item, key) return value end,
--   sortKey = "name", sortAsc = true,
--   onClick = function(item) end,
--   action = { text = "+", width = 26, tooltip = "...", onClick = function(item) end },
--   emptyText = "...",
--   idKey = "itemID",  -- Feld, an dem die markierte Zeile erkannt wird
--   noMenu = true,     -- kein Rechtsklick-Menü
--   flex = "name",     -- Spalte, die mitwächst, wenn die Tabelle breiter ist (Standard: erste Spalte)
-- }
-- Platz füllen: t:Fill(links, oben, rechts, unten) verankert die Tabelle an
-- allen vier Seiten des Elternfensters - Spaltenbreite und Zeilenzahl passen
-- sich dann dem verfügbaren Platz an.
-- Rechtsklick auf eine Zeile mit Item öffnet das Item-Menü.
-- ------------------------------------------------------------
-- Item-Daten für Tabellen: Seltenheit, Itemlevel (nur Waffen/Rüstung), Klasse - gemerkt
local itemMeta = {}
function UI:ItemMeta(id)
    if type(id) ~= "number" then return nil end
    local m = itemMeta[id]
    if m then return m end
    local quality, ilvl, classID
    if GetItemInfo then
        local ok, name, _, q, il, _, _, _, _, _, _, _, cl = pcall(GetItemInfo, id)
        if ok and name then quality, ilvl, classID = q, il, cl end
    end
    if not classID and GetItemInfoInstant then
        local ok, _, _, _, _, _, cl = pcall(GetItemInfoInstant, id)
        if ok then classID = cl end
    end
    m = { quality = quality, ilvl = ilvl, classID = classID }
    if quality then itemMeta[id] = m end            -- erst merken, wenn der Client das Item kennt
    return m
end

local GEAR_CLASS = { [2] = true, [4] = true }      -- Waffen, Rüstung
function UI:ItemLevel(id)
    local m = self:ItemMeta(id)
    if m and m.ilvl and m.ilvl > 1 and GEAR_CLASS[m.classID] then return m.ilvl end
    return nil
end

-- Itemlevel für jedes Item (auch Handwerkswaren) - z. B. für "Kaufen"
function UI:AnyItemLevel(id)
    local m = self:ItemMeta(id)
    if m and m.ilvl and m.ilvl > 0 then return m.ilvl end
    return nil
end

-- Liste nach Itemlevel filtern (min/max = nil: keine Grenze). Unbekannte Itemlevel werden
-- nachgeladen und solange ausgeblendet; die Tabellen zeichnen neu, sobald die Daten da sind.
function UI:FilterIlvl(list, minIl, maxIl, getID)
    if not (minIl or maxIl) or not list then return list end
    local out = {}
    for _, it in ipairs(list) do
        local id = getID and getID(it) or it.itemID
        local il = it.ilvl or self:AnyItemLevel(id)
        if il then
            if (not minIl or il >= minIl) and (not maxIl or il <= maxIl) then table.insert(out, it) end
        else
            self:RequestItemInfo(id)
        end
    end
    return out
end

-- Item-Daten nachladen (Itemlevel/Seltenheit unbekannter Items); meldet ITEMINFO_LOADED gesammelt
local requested = {}
function UI:RequestItemInfo(id)
    if type(id) ~= "number" or requested[id] then return end
    requested[id] = true
    if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id)
    elseif GetItemInfo then pcall(GetItemInfo, id) end
end
do
    local f = CreateFrame("Frame")
    pcall(f.RegisterEvent, f, "GET_ITEM_INFO_RECEIVED")
    pcall(f.RegisterEvent, f, "ITEM_DATA_LOAD_RESULT")     -- Retail: Antwort auf C_Item.RequestLoadItemDataByID
    local pending, wait = false, 0
    f:SetScript("OnEvent", function() pending = true end)
    f:SetScript("OnUpdate", function(_, dt)
        if not pending then return end
        wait = wait + (dt or 0)
        if wait < 0.3 then return end
        wait, pending = 0, false
        A:Fire("ITEMINFO_LOADED")
    end)
end

-- Item-Tabellen (Spalte "Item"): automatisch eine iLvl-Spalte (Waffen und Rüstung)
-- und Sortierung der Item-Spalte nach Seltenheit, dann Name
local function PrepareItemColumns(cfg)
    if cfg.__prepared then return end
    cfg.__prepared = true
    local nameIdx, hasIlvl
    for i, col in ipairs(cfg.columns) do
        if col.key == "name" and col.title == L["Item"] then nameIdx = i end
        if col.key == "ilvl" then hasIlvl = true end
    end
    if not nameIdx then return end
    cfg.itemTable = true
    local cols = {}
    for i, col in ipairs(cfg.columns) do
        if i == nameIdx then
            local c = {}
            for k, v in pairs(col) do c[k] = v end
            c.tooltip = c.tooltip or L["Sortiert nach Seltenheit, dann nach Name"]
            col = c
        end
        table.insert(cols, col)
        if i == nameIdx and not hasIlvl and cfg.ilvl ~= false then
            table.insert(cols, { key = "ilvl", title = "iLvl", width = 40, align = "RIGHT",
                tooltip = L["Gegenstandsstufe (Waffen und Rüstung)"] })
            -- Platz dafür nimmt sich die Item-Spalte
            cols[i].width = math.max(110, (cols[i].width or 150) - 40)
        end
    end
    cfg.columns = cols
    local cell, sortValue = cfg.cell, cfg.sortValue
    if hasIlvl or cfg.ilvl == false then return end
    -- die neue Spalte kennt die Tabelle selbst nicht: Werte kommen von hier
    cfg.cell = function(item, key)
        if key == "ilvl" then
            local il = item.ilvl or UI:ItemLevel(item.itemID)
            return il and tostring(il) or ""
        end
        return cell(item, key)
    end
    if sortValue then
        cfg.sortValue = function(item, key)
            if key == "ilvl" then return item.ilvl or UI:ItemLevel(item.itemID) or 0 end
            return sortValue(item, key)
        end
    end
end

function UI:Table(parent, cfg)
    PrepareItemColumns(cfg)
    local rowH = cfg.rowHeight or 22
    local numRows = cfg.rows or 12
    local headerH = 22
    local actionW = cfg.action and (cfg.action.width or 26) or 0

    local t = CreateFrame("Frame", nil, parent)
    UI:Box(t, C.panel, C.border)
    t.items = {}
    t.offset = 0
    t.sortKey = cfg.sortKey
    t.sortAsc = cfg.sortAsc ~= false
    t:EnableMouseWheel(true)

    local totalW = 0
    for _, col in ipairs(cfg.columns) do totalW = totalW + col.width end
    local baseW, baseH = totalW + actionW + 26, headerH + numRows * rowH + 8
    t:SetSize(baseW, baseH)
    t.numRows = numRows

    -- wachsende Spalte
    local flexIndex = 1
    for i, col in ipairs(cfg.columns) do if cfg.flex and col.key == cfg.flex then flexIndex = i end end
    local extraW = 0
    local function ColWidth(i) return cfg.columns[i].width + ((i == flexIndex) and extraW or 0) end

    -- Kopfzeile
    local header = CreateFrame("Frame", nil, t)
    header:SetPoint("TOPLEFT", 1, -1)
    header:SetPoint("TOPRIGHT", -1, -1)
    header:SetHeight(headerH)
    UI:Box(header, C.panel2)
    UI:Gradient(header.__bg, "VERTICAL", C.panel2[1] * 0.75, C.panel2[2] * 0.75, C.panel2[3] * 0.75, 1, C.panel2[1] * 1.25, C.panel2[2] * 1.25, C.panel2[3] * 1.25, 1)
    header.line = header:CreateTexture(nil, "ARTWORK")          -- goldene Linie unter der Kopfzeile
    header.line:SetPoint("BOTTOMLEFT"); header.line:SetPoint("BOTTOMRIGHT"); header.line:SetHeight(1)
    UI:Gradient(header.line, "HORIZONTAL", C.accent[1], C.accent[2], C.accent[3], 0.7, C.accent[1], C.accent[2], C.accent[3], 0.15)
    t.headerCells = {}
    for _, col in ipairs(cfg.columns) do
        local hb = CreateFrame("Button", nil, header)
        hb.text = hb:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        hb.text:SetPoint(col.align == "RIGHT" and "RIGHT" or "LEFT", col.align == "RIGHT" and -6 or 0, 0)
        hb.text:SetTextColor(unpack(C.textDim))
        hb.col = col
        hb:SetScript("OnClick", function()
            if cfg.sortValue == nil or col.noSort then return end
            if t.sortKey == col.key then t.sortAsc = not t.sortAsc else t.sortKey = col.key; t.sortAsc = (col.align ~= "RIGHT") end
            t:Sort(); t:Render()
        end)
        hb:SetScript("OnEnter", function(self)
            self.text:SetTextColor(unpack(C.text))
            if col.tooltip then
                UI:AnchorTooltip(self)
                GameTooltip:SetText(col.title, 1, 1, 1)
                GameTooltip:AddLine(col.tooltip, 0.9, 0.9, 0.9, true)
                GameTooltip:Show()
            end
        end)
        hb:SetScript("OnLeave", function(self)
            t:UpdateHeader()
            if col.tooltip then GameTooltip:Hide() end
        end)
        table.insert(t.headerCells, hb)
    end
    local function LayoutHeader()
        local x = 6
        for i, hb in ipairs(t.headerCells) do
            hb:ClearAllPoints()
            hb:SetPoint("LEFT", x, 0)
            hb:SetSize(ColWidth(i), headerH)
            x = x + ColWidth(i)
        end
    end
    LayoutHeader()

    function t:UpdateHeader()
        for _, hb in ipairs(self.headerCells) do
            local title = hb.col.title
            if self.sortKey == hb.col.key then
                title = title .. (self.sortAsc and " ^" or " v")
                hb.text:SetTextColor(C.heading[1], C.heading[2], C.heading[3], 1)
            else
                hb.text:SetTextColor(C.heading[1], C.heading[2], C.heading[3], 0.7)
            end
            hb.text:SetText(title)
        end
    end

    -- Zeilen (werden bei Bedarf nachgebaut, wenn die Tabelle höher wird)
    t.rows = {}
    local function LayoutRow(r)
        local cx = 6
        for c, fs in ipairs(r.cells) do
            fs:ClearAllPoints()
            fs:SetWidth(ColWidth(c) - 6)
            fs:SetPoint("LEFT", cx, 0)
            cx = cx + ColWidth(c)
        end
        if r.action then
            r.action:ClearAllPoints()
            r.action:SetPoint("LEFT", cx, 0)
        end
    end
    local function MakeRow(i)
        local r = CreateFrame("Button", nil, t)
        r:SetHeight(rowH)
        r:SetPoint("TOPLEFT", 1, -(headerH + 1 + (i - 1) * rowH))
        r:SetPoint("RIGHT", t, "RIGHT", -18, 0)
        if r.RegisterForClicks then r:RegisterForClicks("LeftButtonUp", "RightButtonUp") end
        r.bg = r:CreateTexture(nil, "BACKGROUND")
        r.bg:SetAllPoints()
        r.bg:SetColorTexture(1, 1, 1, (i % 2 == 0) and 0.025 or 0)
        -- Maus darüber: weicher Schimmer von links
        local hl = r:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        UI:Gradient(hl, "HORIZONTAL", C.accent[1], C.accent[2], C.accent[3], 0.16, C.accent[1], C.accent[2], C.accent[3], 0.02)
        -- gewählte Zeile: goldener Balken links und Verlauf
        r.sel = r:CreateTexture(nil, "ARTWORK")
        r.sel:SetAllPoints()
        UI:Gradient(r.sel, "HORIZONTAL", C.accent[1], C.accent[2], C.accent[3], 0.28, C.accent[1], C.accent[2], C.accent[3], 0.05)
        r.selBar = r:CreateTexture(nil, "OVERLAY")
        r.selBar:SetPoint("TOPLEFT"); r.selBar:SetPoint("BOTTOMLEFT"); r.selBar:SetWidth(3)
        r.selBar:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.9)
        r.sel:Hide(); r.selBar:Hide()
        r.cells = {}
        for _, col in ipairs(cfg.columns) do
            local fs = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            fs:SetHeight(rowH)
            fs:SetJustifyH(col.align or "LEFT")
            if fs.SetWordWrap then fs:SetWordWrap(false) end
            table.insert(r.cells, fs)
        end
        if cfg.action then
            local ab = UI:Button(r, cfg.action.text, actionW - 4, rowH - 4, function()
                if r.item and cfg.action.onClick then cfg.action.onClick(r.item) end
            end)
            ab.tooltip = cfg.action.tooltip
            r.action = ab
        end
        LayoutRow(r)
        r:SetScript("OnClick", function(self, button)
            if not self.item then return end
            if button == "RightButton" then
                if self.item.itemID and not cfg.noMenu then UI:ShowItemMenu(self.item.itemID, self) end
                return
            end
            if cfg.onClick then
                t.selectedID = self.item[cfg.idKey or "itemID"]
                cfg.onClick(self.item)
                t:Render()
            end
        end)
        r:SetScript("OnEnter", function(self)
            if self.item and cfg.onHover then pcall(cfg.onHover, self.item) end
            if self.item and self.item.itemID and cfg.itemTooltip ~= false then
                UI:AnchorTooltip(self)
                -- Kaufpreis dieser Zeile für "Gewinn beim Kauf" im Tooltip (Kaufliste, Sniper, Schnäppchen)
                local it = self.item
                local unit = it.price or it.unit or ((it.buyout and it.qty and it.qty > 0) and math.floor(it.buyout / it.qty)) or nil
                if A.Tooltip then A.Tooltip.buyContext = (cfg.buyPrices ~= false and unit) and { itemID = it.itemID, price = unit } or nil end
                local ok = pcall(GameTooltip.SetHyperlink, GameTooltip, "item:" .. self.item.itemID)
                if A.Tooltip then A.Tooltip.buyContext = nil end
                if not ok then GameTooltip:SetText(self.item.name or "") end
                if cfg.tooltipLines then pcall(cfg.tooltipLines, self.item, GameTooltip) end
                if not cfg.noMenu then GameTooltip:AddLine(L["Rechtsklick: Optionen"], 0.6, 0.6, 0.6) end
                GameTooltip:Show()
            end
        end)
        r:SetScript("OnLeave", function() GameTooltip:Hide() end)
        t.rows[i] = r
        return r
    end
    for i = 1, numRows do MakeRow(i) end

    -- Blättern
    t.scrollText = UI:Label(t, "", "GameFontDisableSmall", C.textDim)
    t.scrollText:SetPoint("BOTTOMRIGHT", t, "TOPRIGHT", -2, 3)
    t.scrollText:SetJustifyH("RIGHT")

    -- Seitenleiste über der Tabelle: "123 Einträge  < 1 2 3 ... 20 >" - Klick springt zur Seite
    local pager = CreateFrame("Frame", nil, t)
    pager:SetPoint("BOTTOMRIGHT", t, "TOPRIGHT", -2, 1)
    pager:SetSize(10, 16)
    pager:Hide()
    pager.buttons = {}
    t.pager = pager
    local function PageButton(i)
        local b = pager.buttons[i]
        if b then return b end
        b = CreateFrame("Button", nil, pager)
        b:SetHeight(16)
        b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        b.text:SetPoint("CENTER", 0, 0)
        b.hl = b:CreateTexture(nil, "BACKGROUND")
        b.hl:SetAllPoints()
        b.hl:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.18)
        b.hl:Hide()
        b:SetScript("OnClick", function(self)
            if self.page then t:GoToPage(self.page) end
        end)
        b:SetScript("OnEnter", function(self)
            if self.page and not self.current then self.text:SetTextColor(1, 1, 1) ; self.hl:Show() end
        end)
        b:SetScript("OnLeave", function(self)
            if not self.current then self.hl:Hide() end
            self.text:SetTextColor(unpack(self.current and C.accent or (self.page and C.text or C.textDim)))
        end)
        pager.buttons[i] = b
        return b
    end

    function t:PageInfo()
        local rowsN = math.max(1, self.numRows)
        local count = #self.items
        local pages = math.max(1, math.ceil(count / rowsN))
        -- aktuelle Seite: die, auf der die oberste Zeile steht (letzte Seite, wenn ganz unten)
        local maxOffset = math.max(0, count - rowsN)
        local page = (self.offset >= maxOffset and count > rowsN) and pages or (math.floor(self.offset / rowsN) + 1)
        return page, pages
    end

    function t:GoToPage(page)
        local _, pages = self:PageInfo()
        page = math.max(1, math.min(pages, page))
        local maxOffset = math.max(0, #self.items - self.numRows)
        self.offset = math.min(maxOffset, (page - 1) * self.numRows)
        self:Render()
    end

    -- Seitenzahlen: erste, letzte und um die aktuelle herum, dazwischen "..."
    local function PageList(page, pages, around)
        local list, last = {}, 0
        for p = 1, pages do
            if p == 1 or p == pages or math.abs(p - page) <= around then
                if p - last > 1 then table.insert(list, "...") end
                table.insert(list, p)
                last = p
            end
        end
        return list
    end

    function t:UpdatePager()
        local count, rowsN = #self.items, self.numRows
        if cfg.noCount or count <= rowsN then
            pager:Hide()
            self.scrollText:Show()
            return
        end
        self.scrollText:Hide()
        local page, pages = self:PageInfo()
        local compact = cfg.shortCount or (self:GetWidth() or 0) < 380
        local entries = {}
        table.insert(entries, { text = "<", page = page > 1 and page - 1 or nil, w = 18 })
        if compact then
            table.insert(entries, { text = page .. " / " .. pages, w = 14 + 7 * (#tostring(page) + #tostring(pages)) })
        else
            for _, p in ipairs(PageList(page, pages, (self:GetWidth() or 0) > 600 and 2 or 1)) do
                if p == "..." then table.insert(entries, { text = "...", w = 16 })
                else table.insert(entries, { text = tostring(p), page = p, current = p == page, w = 10 + 7 * #tostring(p) }) end
            end
        end
        table.insert(entries, { text = ">", page = page < pages and page + 1 or nil, w = 18 })
        if not compact then
            table.insert(entries, 1, { text = string.format(L["%d Einträge"], count) .. "  ", w = 18 + 6 * #tostring(count) + 50, label = true })
        end
        local x = 0
        for i = #entries, 1, -1 do
            local e = entries[i]
            local b = PageButton(i)
            b:ClearAllPoints()
            b:SetPoint("RIGHT", pager, "RIGHT", -x, 0)
            b:SetWidth(e.w)
            b.text:SetText(e.text)
            b.page, b.current = (not e.current) and e.page or nil, e.current
            b.text:ClearAllPoints()
            if e.label then b.text:SetPoint("RIGHT", 0, 0) else b.text:SetPoint("CENTER", 0, 0) end
            b.text:SetTextColor(unpack(e.current and C.accent or ((e.page and not e.label) and C.text or C.textDim)))
            if e.current then b.hl:Show() else b.hl:Hide() end
            b:EnableMouse(e.page ~= nil and not e.current)
            b:Show()
            x = x + e.w + 2
        end
        for i = #entries + 1, #pager.buttons do pager.buttons[i]:Hide() end
        pager:SetWidth(math.max(10, x))
        pager:Show()
    end

    local track = t:CreateTexture(nil, "ARTWORK")
    track:SetColorTexture(1, 1, 1, 0.04)
    track:SetPoint("TOPRIGHT", -5, -(headerH + 4))
    track:SetPoint("BOTTOMRIGHT", -5, 4)
    track:SetWidth(8)
    t.thumb = t:CreateTexture(nil, "OVERLAY")
    t.thumb:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.85)
    t.thumb:SetAlpha(0.75)
    t.thumb:SetWidth(8)
    t.trackHeight = numRows * rowH - 6

    -- Scrollbalken mit der Maus ziehen bzw. in die Leiste klicken
    local bar = CreateFrame("Frame", nil, t)
    bar:SetPoint("TOPRIGHT", -1, -(headerH + 4))
    bar:SetPoint("BOTTOMRIGHT", -1, 4)
    bar:SetWidth(16)
    bar:SetFrameLevel(t:GetFrameLevel() + 10)
    bar:EnableMouse(true)
    t.scrollBar = bar
    local function CursorFromTop()
        local _, cy = GetCursorPosition()
        local scale = bar:GetEffectiveScale() or 1
        local top = bar:GetTop() or 0
        return top - cy / scale
    end
    function t:ScrollToThumb(pos)
        local count = #self.items
        local maxOffset = math.max(0, count - self.numRows)
        if maxOffset == 0 then return end
        local room = math.max(1, self.trackHeight - (self.thumbH or 16))
        local frac = math.min(1, math.max(0, pos / room))
        local off = math.floor(frac * maxOffset + 0.5)
        if off ~= self.offset then
            self.offset = off
            self:Render()
        end
    end
    bar:SetScript("OnMouseDown", function(self, button)
        if button and button ~= "LeftButton" then return end
        if #t.items <= t.numRows then return end
        local y = CursorFromTop()
        local h = t.thumbH or 16
        local pos = t.thumbPos or 0
        if y >= pos and y <= pos + h then
            self.grab = y - pos                      -- am Griff angefasst: Abstand merken
        else
            self.grab = h / 2                        -- in die Leiste geklickt: dorthin springen
            t:ScrollToThumb(y - self.grab)
        end
        t.thumb:SetAlpha(1)
        self:SetScript("OnUpdate", function()
            t:ScrollToThumb(CursorFromTop() - (self.grab or 0))
        end)
    end)
    bar:SetScript("OnMouseUp", function(self)
        self:SetScript("OnUpdate", nil)
        self.grab = nil
        if not self:IsMouseOver() then t.thumb:SetAlpha(0.75) end
    end)
    bar:SetScript("OnEnter", function() t.thumb:SetAlpha(1) end)
    bar:SetScript("OnLeave", function(self) if not self.grab then t.thumb:SetAlpha(0.75) end end)
    bar:SetScript("OnHide", function(self) self:SetScript("OnUpdate", nil); self.grab = nil end)

    t.empty = UI:Label(t, cfg.emptyText or L["Keine Daten."], "GameFontHighlight", C.textDim)
    t.empty:SetPoint("CENTER", 0, -10)
    t.empty:SetJustifyH("CENTER")

    -- an allen vier Seiten verankern (Abstände wie bei SetPoint: links, oben, rechts, unten)
    function t:Fill(left, top, right, bottom, rel)
        rel = rel or self:GetParent()
        self.filling = true
        self:ClearAllPoints()
        self:SetPoint("TOPLEFT", rel, "TOPLEFT", left or 0, top or 0)
        self:SetPoint("BOTTOMRIGHT", rel, "BOTTOMRIGHT", right or 0, bottom or 0)
        self:Fit()
        return self
    end

    -- linke Spalte mit fester Breite, oben bis unten (Abstände: links, oben, Breite, unten)
    function t:FillColumn(left, top, width, bottom, rel)
        rel = rel or self:GetParent()
        self.filling = true
        self:ClearAllPoints()
        self:SetPoint("TOPLEFT", rel, "TOPLEFT", left or 0, top or 0)
        self:SetPoint("BOTTOMLEFT", rel, "BOTTOMLEFT", left or 0, bottom or 0)
        self:SetWidth(width)
        self:Fit()
        return self
    end

    -- frei verankert: { relPoint, x, y } für die linke obere und die rechte untere Ecke
    function t:FillAnchors(tl, br, rel)
        rel = rel or self:GetParent()
        self.filling = true
        self:ClearAllPoints()
        self:SetPoint("TOPLEFT", rel, tl[1], tl[2], tl[3])
        self:SetPoint("BOTTOMRIGHT", rel, br[1], br[2], br[3])
        self:Fit()
        return self
    end

    -- Zeilenzahl und Breite der wachsenden Spalte an die aktuelle Größe anpassen
    function t:Fit()
        local w, h = self:GetWidth(), self:GetHeight()
        if not self.filling or not w or not h or w < 50 or h < headerH + rowH then return end
        if w == self.fitW and h == self.fitH then return end
        self.fitW, self.fitH = w, h
        extraW = math.max(0, math.floor(w - baseW))
        local n = math.max(1, math.floor((h - headerH - 8) / rowH))
        for i = #self.rows + 1, n do MakeRow(i) end
        for i, r in ipairs(self.rows) do
            LayoutRow(r)
            if i > n then r:Hide(); r.item = nil end
        end
        self.numRows = n
        self.trackHeight = n * rowH - 6
        LayoutHeader()
    end
    t:SetScript("OnSizeChanged", function(self) if self.filling then self:Fit(); self:Render() end end)

    t:SetScript("OnMouseWheel", function(self, delta)
        -- wartet ein Treffer und kauft das Mausrad: kaufen statt blättern
        if A.Sniper and A.Sniper.WheelBuy and A.Sniper:WheelBuy(delta) then return end
        local maxOffset = math.max(0, #self.items - self.numRows)
        self.offset = math.min(maxOffset, math.max(0, self.offset - delta * 3))
        self:Render()
    end)

    -- Sortieren: Sortierwert pro Zeile nur einmal berechnen, dann Mergesort,
    -- der bei langen Listen (tausende Items) zwischendurch pausieren darf
    function t:Sort()
        if not cfg.sortValue or not self.sortKey then return end
        local key, asc = self.sortKey, self.sortAsc
        local items = self.items
        local n = #items
        if n < 2 then return end
        local keys, names = {}, {}
        -- Item-Spalte: zuerst nach Seltenheit (Episch vor Blau vor Grün ...), dann nach Name
        local byRarity = cfg.itemTable and key == "name"
        local quals = byRarity and {} or nil
        for i, it in ipairs(items) do
            keys[it] = cfg.sortValue(it, key)
            names[it] = it.name or ""
            if byRarity then
                local q = it.quality
                if q == nil then local m = UI:ItemMeta(it.itemID); q = m and m.quality end
                quals[it] = q or -1
            end
            if i % 200 == 0 then A:Pause() end
        end
        local function less(a, b)
            if byRarity then
                -- aufsteigend (^) = höchste Seltenheit zuerst; Namen immer A-Z
                local qa, qb = quals[a], quals[b]
                if qa ~= qb then if asc then return qa > qb end return qa < qb end
                local na, nb = keys[a], keys[b]
                if type(na) ~= "string" then na = string.lower(names[a]) end
                if type(nb) ~= "string" then nb = string.lower(names[b]) end
                if na ~= nb then return na < nb end
                return false
            end
            local va, vb = keys[a], keys[b]
            if va == nil and vb == nil then return names[a] < names[b] end
            if va == nil then return false end
            if vb == nil then return true end
            if va == vb then return names[a] < names[b] end
            if asc then return va < vb end
            return va > vb
        end
        if n <= 400 then table.sort(items, less); return end
        local src, dst = items, {}
        local width = 1
        local steps = 0
        while width < n do
            local i = 1
            while i <= n do
                local mid, hi = math.min(i + width, n + 1), math.min(i + 2 * width, n + 1)
                local l, r, k = i, mid, i
                while l < mid and r < hi do
                    if less(src[r], src[l]) then dst[k] = src[r]; r = r + 1 else dst[k] = src[l]; l = l + 1 end
                    k = k + 1
                end
                while l < mid do dst[k] = src[l]; l = l + 1; k = k + 1 end
                while r < hi do dst[k] = src[r]; r = r + 1; k = k + 1 end
                steps = steps + (hi - i)
                i = hi
                if steps > 2000 then steps = 0; A:Pause() end
            end
            src, dst = dst, src
            width = width * 2
        end
        if src ~= items then for i = 1, n do items[i] = src[i] end end
    end

    function t:SetData(items, keepOffset)
        self.items = items or {}
        if not keepOffset then self.offset = 0 end
        self:Sort()
        self:Render()
    end

    -- Item-Spalte: Symbol und Farbe der Seltenheit (wie im Spiel)
    local QHEX = { [0] = "ff9d9d9d", "ffffffff", "ff1eff00", "ff0070dd", "ffa335ee", "ffff8000", "ffe6cc80", "ff00ccff" }
    local function ItemIcon(id)
        if GetItemIcon then
            local ok, tex = pcall(GetItemIcon, id)
            if ok and tex then return tex end
        end
        if GetItemInfoInstant then
            local ok, _, _, _, _, tex = pcall(GetItemInfoInstant, id)
            if ok and tex then return tex end
        end
        return nil
    end
    local function Decorate(item, text)
        local id = item.itemID
        if cfg.icons == false or type(id) ~= "number" or text == "" then return text end
        if not text:find("|c", 1, true) and GetItemInfo then
            local ok, _, _, q = pcall(GetItemInfo, id)
            if ok and q and QHEX[q] and q ~= 1 then text = "|c" .. QHEX[q] .. text .. "|r" end
        end
        local tex = ItemIcon(id)
        if tex then text = "|T" .. tex .. ":16:16:0:0:64:64:5:59:5:59|t " .. text end
        return text
    end

    function t:Render()
        if self.filling then self:Fit() end
        local rowsN = self.numRows
        local count = #self.items
        local maxOffset = math.max(0, count - rowsN)
        if self.offset > maxOffset then self.offset = maxOffset end
        for i, r in ipairs(self.rows) do
            local item = (i <= rowsN) and self.items[self.offset + i] or nil
            r.item = item
            if item then
                for c, col in ipairs(cfg.columns) do
                    local text = cfg.cell(item, col.key) or ""
                    if col.key == "name" then text = Decorate(item, tostring(text)) end
                    r.cells[c]:SetText(text)
                end
                if r.action then
                    -- Knopf je Zeile: Beschriftung und Zustand dürfen von der Zeile abhängen
                    if cfg.action.label then
                        local txt, active = cfg.action.label(item)
                        if txt then
                            r.action:SetText(txt)
                            if r.action.SetActive then r.action:SetActive(active ~= false) end
                            r.action:Show()
                        else
                            r.action:Hide()
                        end
                    else
                        r.action:Show()
                    end
                end
                if self.selectedID and item[cfg.idKey or "itemID"] == self.selectedID then r.sel:Show(); r.selBar:Show() else r.sel:Hide(); r.selBar:Hide() end
                r:Show()
            else
                r:Hide()
            end
        end
        if count == 0 then self.empty:Show() else self.empty:Hide() end
        if count > rowsN then
            local h = math.max(16, self.trackHeight * rowsN / count)
            local pos = (self.trackHeight - h) * (self.offset / maxOffset)
            self.thumbH, self.thumbPos = h, pos
            self.thumb:SetHeight(h)
            self.thumb:ClearAllPoints()
            self.thumb:SetPoint("TOPRIGHT", self, "TOPRIGHT", -5, -(headerH + 4 + pos))
            self.thumb:Show()
            self.scrollText:SetText("")
        else
            self.thumb:Hide()
            self.scrollText:SetText((count > 0 and not cfg.noCount) and (count .. L[" Einträge"]) or "")
        end
        self:UpdatePager()
        self:UpdateHeader()
    end

    t:UpdateHeader()
    return t
end

-- Fenster mit ESC schließbar machen (jeden Namen nur einmal eintragen)
-- Esc schließt nur dieses Fenster. Über UISpecialFrames würde WoW bei Esc ALLE Fenster auf
-- einmal schließen - auch das Auktionshaus. Darum fängt das Fenster Esc selbst ab und reicht
-- alle anderen Tasten an das Spiel weiter (im Kampf ist das Weiterreichen gesperrt: dann bleibt
-- es beim Weiterreichen, Esc schließt das Fenster trotzdem).
-- Item-Name einer Tabellenzeile immer frisch in der eingestellten Sprache holen
-- (gespeicherte Namen stammen aus der Sprache, die beim Suchen aktiv war)
-- Retail: Handwerksmaterial und hergestellte Items gibt es in mehreren Qualitätsstufen
-- (z. B. dreimal "Bismut"). Ohne Kennzeichen sehen die Zeilen gleich aus.
local tierCache = {}
local function TierAtlas(tier)
    for _, fmt in ipairs({ "Professions-ChatIcon-Quality-Tier%d", "Professions-Icon-Quality-Tier%d-Small" }) do
        local atlas = string.format(fmt, tier)
        if C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo(atlas) then return atlas end
    end
end
function A:QualityTierMarkup(itemID)
    if type(itemID) ~= "number" then return "" end
    local c = tierCache[itemID]
    if c then return c end
    local T = C_TradeSkillUI
    local tier
    if T then
        if T.GetItemReagentQualityByItemInfo then
            local ok, q = pcall(T.GetItemReagentQualityByItemInfo, itemID)
            if ok and type(q) == "number" and q > 0 then tier = q end
        end
        if not tier and T.GetItemCraftedQualityByItemInfo then
            local ok, q = pcall(T.GetItemCraftedQualityByItemInfo, itemID)
            if ok and type(q) == "number" and q > 0 then tier = q end
        end
    end
    if not tier then
        -- Daten evtl. noch nicht geladen: nicht dauerhaft "ohne Stufe" merken
        if T and GetItemInfo and GetItemInfo(itemID) then tierCache[itemID] = "" end
        return ""
    end
    local atlas = TierAtlas(tier)
    c = atlas and (" |A:" .. atlas .. ":14:14|a") or (" |cffffd100(" .. tier .. ")|r")
    tierCache[itemID] = c
    return c
end

function UI.ItemName(row)
    if not row then return "" end
    local id = row.itemID or (type(row.itemKey) == "table" and row.itemKey.itemID) or nil
    if id and not row.noLiveName then
        local nm = A:GetItemName(id)
        if nm and nm ~= "" then return nm .. A:QualityTierMarkup(id) end
    end
    return row.name or ""
end

function UI:EscCloses(frame)
    if not (frame and frame.EnableKeyboard and frame.SetPropagateKeyboardInput) or frame.__escHooked then return false end
    frame.__escHooked = true
    frame:EnableKeyboard(true)
    local function free() return not A:InCombat() end     -- (= InCombatLockdown, im Test simulierbar)
    if free() then frame:SetPropagateKeyboardInput(true) end
    frame:SetScript("OnKeyDown", function(self, key)
        if key == "ESCAPE" then
            if free() then self:SetPropagateKeyboardInput(false) end
            self:Hide()
        elseif free() then
            self:SetPropagateKeyboardInput(true)
        end
    end)
    frame:HookScript("OnShow", function(self) if free() then self:SetPropagateKeyboardInput(true) end end)
    -- nach dem Schließen gleich wieder auf "weiterreichen": wird das Fenster später im Kampf
    -- geöffnet, dürfen keine Tasten hängen bleiben (erst im nächsten Bild, sonst ginge das Esc doch weiter)
    frame:HookScript("OnHide", function(self)
        if C_Timer and C_Timer.After then
            C_Timer.After(0, function() if free() and not self:IsShown() then self:SetPropagateKeyboardInput(true) end end)
        end
    end)
    return true
end

function UI:RegisterSpecial(name)
    if not name then return end
    -- Zusätzlich als "Menü" melden: WoW schließt bei Esc zuerst offene Menüs und hört dann auf.
    -- So bleibt das Auktionshaus offen, auch wenn das Fenster die Taste selbst nicht bekommt.
    if type(UIMenus) == "table" then
        local known = false
        for _, n in ipairs(UIMenus) do if n == name then known = true; break end end
        if not known then table.insert(UIMenus, name) end
    end
    if self:EscCloses(_G[name]) then return end
    if not UISpecialFrames then return end
    for _, n in ipairs(UISpecialFrames) do if n == name then return end end
    table.insert(UISpecialFrames, name)
end

-- ------------------------------------------------------------
-- Kleines Fenster (Optionen, Hilfe, Menü) im aktuellen Design
-- ------------------------------------------------------------
function UI:Dialog(name, width, height, titleText)
    local w = CreateFrame("Frame", name, UIParent)
    if A.RegisterUI then A.RegisterUI(w, name or titleText) end     -- Oberflächen-Prüfung im Client (UICheck.lua)
    w:SetSize(width, height)
    w:SetPoint("CENTER")
    w:SetFrameStrata("DIALOG")
    w:SetToplevel(true)
    w:SetClampedToScreen(true)
    w:SetMovable(true)
    w:EnableMouse(true)
    w:RegisterForDrag("LeftButton")
    w:SetScript("OnDragStart", w.StartMoving)
    w:SetScript("OnDragStop", w.StopMovingOrSizing)
    UI:Box(w, C.bg, C.frameEdge, UI:IsClassic() and 2 or 1)
    if A.db then w:SetScale(A.db.settings.scale or 1) end
    UI:RegisterSpecial(name)
    -- ein stehengebliebener Item-Tooltip soll nicht über dem neuen Fenster hängen
    w:HookScript("OnShow", function() if GameTooltip and GameTooltip.Hide then GameTooltip:Hide() end end)
    w.title = UI:Label(w, titleText or "", "GameFontNormal", C.accent)
    w.title:SetPoint("TOPLEFT", 14, -12)
    w.close = UI:CloseButton(w, function() w:Hide() end)
    w.close:SetPoint("TOPRIGHT", -6, -6)
    return w
end

function UI:CloseButton(parent, onClick)
    if UI:IsClassic() then
        local b = CreateFrame("Button", nil, parent)
        b:SetSize(28, 28)
        b:SetNormalTexture(TEX.close)
        b:SetPushedTexture(TEX.closeDown)
        b:SetHighlightTexture(TEX.closeHL)
        b:SetScript("OnClick", onClick)
        b:SetScript("OnEnter", function(self)
            UI:AnchorTooltip(self); GameTooltip:SetText(L["Schließen (ESC)"]); GameTooltip:Show()
        end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        return b
    end
    local b = UI:Button(parent, "X", 26, 22, onClick, "danger")
    b.tooltip = L["Schließen (ESC)"]
    return b
end

-- ------------------------------------------------------------
-- Item-Suche in Eingabefeldern: Vorschläge beim Tippen (jede Sprache),
-- Shift-Klick auf ein Item fügt es ein.
-- opts = { onPick = function(itemID) end, suggest = true/false }
-- ------------------------------------------------------------
local function ChainScript(frame, script, fn)
    local prev = frame:GetScript(script)
    frame:SetScript(script, function(...)
        if prev then prev(...) end
        fn(...)
    end)
end

function UI:AttachItemSearch(box, opts)
    opts = opts or {}
    box.acceptsItemLinks = true
    box.itemOpts = opts
    ChainScript(box, "OnTextChanged", function(self, userInput)
        if self.itemID and self:GetText() ~= self.itemText then self.itemID = nil end
        if userInput and opts.suggest ~= false then UI:UpdateSuggest(self) end
    end)
    ChainScript(box, "OnEditFocusLost", function(self)
        if C_Timer and C_Timer.After then
            C_Timer.After(0.3, function()
                if UI.suggest and UI.suggest.box == self then UI.suggest:Hide() end
            end)
        end
    end)
    ChainScript(box, "OnEscapePressed", function() UI:HideSuggest() end)
    return box
end

-- Text oder (wenn ein Vorschlag/Link gewählt wurde) die Item-ID
function UI:GetItemInput(box)
    if box.itemID and box:GetText() == box.itemText then return tostring(box.itemID) end
    return box:GetText()
end

function UI:SetItemInput(box, itemID)
    local name = A:GetItemName(itemID)
    box.itemText = name
    box:SetText(name)
    box.itemID = itemID
    if box.UpdatePlaceholder then box:UpdatePlaceholder() end
end

function UI:PickSuggestion(box, itemID)
    self:SetItemInput(box, itemID)
    self:HideSuggest()
    if box.itemOpts and box.itemOpts.onPick then box.itemOpts.onPick(itemID) end
end

function UI:HideSuggest()
    if self.suggest then self.suggest:Hide() end
end

function UI:UpdateSuggest(box)
    local text = box:GetText() or ""
    local results = (A.Names and string.len(text) >= 2) and A.Names:Search(text, 8) or {}
    if #results == 0 or (A.Names:ParseID(text) and #results == 1) then
        self:HideSuggest()
        return
    end
    if not self.suggest then
        local s = CreateFrame("Frame", "AHAnalyzerProSuggest", UIParent)
        s:SetFrameStrata("FULLSCREEN_DIALOG")
        s:SetClampedToScreen(true)
        s:EnableMouse(true)
        UI:Box(s, C.bg, C.frameEdge)
        s.rows = {}
        for i = 1, 8 do
            local b = CreateFrame("Button", nil, s)
            b:SetHeight(20)
            b:SetPoint("TOPLEFT", 4, -4 - (i - 1) * 20)
            b:SetPoint("RIGHT", s, "RIGHT", -4, 0)
            b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            b.text:SetPoint("LEFT", 6, 0)
            b.text:SetPoint("RIGHT", -6, 0)
            b.text:SetJustifyH("LEFT")
            if b.text.SetWordWrap then b.text:SetWordWrap(false) end
            local hl = b:CreateTexture(nil, "HIGHLIGHT")
            hl:SetAllPoints()
            hl:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.2)
            b:SetScript("OnClick", function(self)
                if self.itemID and UI.suggest.box then UI:PickSuggestion(UI.suggest.box, self.itemID) end
            end)
            s.rows[i] = b
        end
        self.suggest = s
    end
    local s = self.suggest
    s.box = box
    s:SetScale(box:GetEffectiveScale() and (box:GetEffectiveScale() / (UIParent:GetEffectiveScale() or 1)) or 1)
    s:ClearAllPoints()
    s:SetPoint("TOPLEFT", box, "BOTTOMLEFT", 0, -2)
    s:SetWidth(math.max(280, box:GetWidth() or 0))
    local display = A.Names:DisplayLocale()
    for i, b in ipairs(s.rows) do
        local r = results[i]
        if r then
            local label = r.name
            if r.matched and r.matched ~= r.name then
                label = label .. "  |cff888888(" .. r.matched .. ", " .. A.Names:LocaleLabel(r.matchedLocale) .. ")|r"
            end
            b.text:SetText(label)
            b.itemID = r.itemID
            b:Show()
        else
            b.itemID = nil
            b:Hide()
        end
    end
    s:SetHeight(8 + math.min(#results, 8) * 20)
    s:Show()
end

-- Shift-Klick auf ein Item (Taschen, Chat, Auktionshaus) fügt es in ein aktives Suchfeld ein
function UI:OnInsertLink(link)
    if type(link) ~= "string" then return end
    local box = GetCurrentKeyBoardFocus and GetCurrentKeyBoardFocus()
    if not (box and box.acceptsItemLinks) then return end
    local id = A.Names and A.Names:ParseID(link)
    if not id then return end
    local name = link:match("|h%[(.-)%]|h") or link:match("%[(.-)%]")
    if name then A.Names:Learn(id, name) end
    self:PickSuggestion(box, id)
    if box.itemOpts and box.itemOpts.onLink then box.itemOpts.onLink(id) end
end

if hooksecurefunc then
    if ChatEdit_InsertLink then
        pcall(hooksecurefunc, "ChatEdit_InsertLink", function(link) UI:OnInsertLink(link) end)
    end
    if ChatFrameUtil and ChatFrameUtil.InsertLink then
        pcall(hooksecurefunc, ChatFrameUtil, "InsertLink", function(link) UI:OnInsertLink(link) end)
    end
end

-- ------------------------------------------------------------
-- Tab-Verwaltung
-- builder(parent) muss ein Frame zurückgeben. Optional: frame:Refresh()
-- ------------------------------------------------------------
UI.tabs = {}
UI.activeTab = nil
local ModernTab           -- weiter unten definiert (auch für die Unterreiter)

function UI:RegisterTab(id, label, order, builder)
    for _, tab in ipairs(self.tabs) do
        if tab.id == id then return end
    end
    table.insert(self.tabs, { id = id, label = label, order = order or 99, builder = builder })
    table.sort(self.tabs, function(a, b) return a.order < b.order end)
    if self.frame then self:BuildTabBar() end
end

-- Kurzform, falls andere Dateien A:RegisterTab benutzen
function A:RegisterTab(id, label, order, builder)
    UI:RegisterTab(id, label, order, builder)
end

function UI:GetTab(id)
    for _, tab in ipairs(self.tabs) do
        if tab.id == id then return tab end
    end
end

-- ------------------------------------------------------------
-- Haupt-Reiter (Gruppen) mit Unterreitern
--   Übersicht | Kaufen (Einkauf, Sniper, Wächter, Schnäppchen) | Verkaufen (Einstellen, Meine Auktionen)
--   | Markt (Alle Preise, Watchlist) | Buchhaltung
-- Der Preisverlauf (charts) ist ein eigenes Fenster und kein Reiter.
-- Reiter anderer Dateien, die in keiner Gruppe stehen, werden eigene Haupt-Reiter.
-- ------------------------------------------------------------
UI.GROUPS = {
    { id = "overview", label = "Übersicht", tabs = { "overview" } },
    { id = "kaufen", label = "Kaufen", tabs = { "buy", "sniper", "watcher", "profit" } },
    { id = "verkaufen", label = "Verkaufen", tabs = { "sell", "auctions" } },
    { id = "markt", label = "Markt", tabs = { "marketview", "watchlist" } },
    { id = "ledger", label = "Buchhaltung", tabs = { "ledger" } },
}
UI.SUBLABELS = {
    buy = "Einkauf", sniper = "Sniper", watcher = "Wächter", profit = "Schnäppchen",
    sell = "Einstellen", auctions = "Meine Auktionen", market = "Alle Preise", watchlist = "Watchlist", marketview = "Markt",
}
-- Stufe 3 M2 (Entscheid des Nutzers 10.11.): die Liste aller Items ist aus der Anzeige verschwunden - der Reiter bleibt
-- geladen (andere Teile und Tests öffnen ihn gezielt), steht aber in keiner Leiste mehr. Nachschlagen: Suche im Markt.
UI.HIDDEN_TABS = { market = true }
UI.WINDOW_TABS = { charts = true }      -- eigenes Fenster statt Reiter
UI.SUBBAR_H = 30                        -- Höhe der Unterreiter-Leiste

-- sichtbare Gruppen (nur registrierte Reiter; fremde Reiter als eigene Gruppe)
function UI:Groups()
    local out, used = {}, {}
    for _, g in ipairs(self.GROUPS) do
        local tabs = {}
        for _, id in ipairs(g.tabs) do
            if self:GetTab(id) then table.insert(tabs, id); used[id] = true end
        end
        if #tabs > 0 then table.insert(out, { id = g.id, label = g.label, tabs = tabs }) end
    end
    for _, tab in ipairs(self.tabs) do
        if not used[tab.id] and not self.WINDOW_TABS[tab.id] and not self.HIDDEN_TABS[tab.id] then
            table.insert(out, { id = tab.id, label = tab.label, tabs = { tab.id } })
        end
    end
    return out
end

function UI:GroupOf(tabID)
    for _, g in ipairs(self:Groups()) do
        for _, id in ipairs(g.tabs) do if id == tabID then return g end end
    end
    return nil
end

-- Haupt-Reiter wählen: zuletzt benutzter Unterreiter (oder der erste)
function UI:SelectGroup(groupID)
    for _, g in ipairs(self:Groups()) do
        if g.id == groupID then
            local last = A.db and A.db.settings.lastSub and A.db.settings.lastSub[groupID]
            local target = g.tabs[1]
            for _, id in ipairs(g.tabs) do if id == last then target = id end end
            return self:SelectTab(target)
        end
    end
end

-- Platz eines Reiter-Inhalts: unter der Unterreiter-Leiste, wenn die Gruppe mehrere Reiter hat
function UI:PlacePanel(panel, host, tabID)
    if not (panel and host) then return end
    local g = self:GroupOf(tabID)
    local off = (g and #g.tabs > 1) and self.SUBBAR_H or 0
    panel:ClearAllPoints()
    panel:SetPoint("TOPLEFT", host.content, "TOPLEFT", 0, -off)
    panel:SetPoint("BOTTOMRIGHT", host.content, "BOTTOMRIGHT", 0, 0)
end

-- Unterreiter-Leiste oben im Inhaltsbereich
function UI:UpdateSubBar(host)
    host = host or self:Host()
    if not (host and host.content) then return end
    local g = self.activeTab and self:GroupOf(self.activeTab)
    local bar = host.subBar
    if not bar then
        bar = CreateFrame("Frame", nil, host.content)
        bar:SetPoint("TOPLEFT", host.content, "TOPLEFT", 0, 0)
        bar:SetPoint("TOPRIGHT", host.content, "TOPRIGHT", 0, 0)
        bar:SetHeight(self.SUBBAR_H - 6)
        local line = bar:CreateTexture(nil, "ARTWORK")
        line:SetColorTexture(unpack(C.border))
        line:SetPoint("BOTTOMLEFT"); line:SetPoint("BOTTOMRIGHT"); line:SetHeight(1)
        bar.buttons = {}
        host.subBar = bar
    end
    if not g or #g.tabs < 2 then bar:Hide(); return end
    if bar.groupID ~= g.id then
        for _, b in ipairs(bar.buttons) do b:Hide() end
        bar.buttons = {}
        local x = 0
        for _, id in ipairs(g.tabs) do
            local tab = self:GetTab(id)
            local b = ModernTab(bar, L[self.SUBLABELS[id] or (tab and tab.label) or id], true)
            b:SetHeight(self.SUBBAR_H - 6)
            b.tabID = id
            b:SetPoint("BOTTOMLEFT", x, 0)
            b:SetScript("OnClick", function() UI:SelectTab(id) end)
            x = x + b:GetWidth() + 4
            table.insert(bar.buttons, b)
        end
        bar.groupID = g.id
    end
    for _, b in ipairs(bar.buttons) do b:Show(); b:SetSelected(b.tabID == self.activeTab) end
    bar:Show()
end

function UI:GetTabDebug()
    local names = {}
    for _, tab in ipairs(self.tabs) do
        table.insert(names, tab.id .. (tab.panel and L["(geladen)"] or ""))
    end
    return #self.tabs .. L[" registriert: "] .. table.concat(names, ", ") .. L["  |  aktiv: "] .. tostring(self.activeTab)
        .. L["  |  Design: "] .. self.theme
end

-- Klassischer Reiter (wie unten am Auktionshaus)
local function ClassicTab(bar, label)
    local b = CreateFrame("Button", nil, bar)
    b:SetHeight(32)
    b.text = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    b.text:SetPoint("CENTER", 0, 2)
    b.text:SetText(label)
    b:SetWidth(math.max(86, (b.text:GetStringWidth() or 60) + 40))
    b.parts = {}
    local coords = { { 0, 0.15625 }, { 0.15625, 0.84375 }, { 0.84375, 1 } }
    for i = 1, 3 do
        local tex = b:CreateTexture(nil, "BACKGROUND")
        tex:SetTexCoord(coords[i][1], coords[i][2], 0, 1)
        tex:SetHeight(32)
        b.parts[i] = tex
    end
    b.parts[1]:SetPoint("TOPLEFT"); b.parts[1]:SetWidth(20)
    b.parts[3]:SetPoint("TOPRIGHT"); b.parts[3]:SetWidth(20)
    b.parts[2]:SetPoint("TOPLEFT", b.parts[1], "TOPRIGHT")
    b.parts[2]:SetPoint("TOPRIGHT", b.parts[3], "TOPLEFT")
    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetPoint("TOPLEFT", 10, -4); hl:SetPoint("BOTTOMRIGHT", -10, 6)
    hl:SetColorTexture(1, 0.82, 0, 0.12)
    function b:SetSelected(on)
        for _, tex in ipairs(self.parts) do tex:SetTexture(on and TEX.tabActive or TEX.tabInactive) end
        self.text:SetTextColor(unpack(on and { 1, 1, 1, 1 } or C.accent))
    end
    return b
end

-- Moderner Reiter (oben, Linie unter dem aktiven). compact = kleinere Schrift (im Auktionshaus)
function ModernTab(bar, label, compact)
    local b = CreateFrame("Button", nil, bar)
    b:SetHeight(30)
    b.text = b:CreateFontString(nil, "OVERLAY", compact and "GameFontHighlightSmall" or "GameFontHighlight")
    b.text:SetPoint("CENTER", 0, 1)
    b.text:SetText(label)
    b:SetWidth(math.max(compact and 60 or 90, (b.text:GetStringWidth() or 60) + (compact and 20 or 28)))
    b.line = b:CreateTexture(nil, "OVERLAY")
    b.line:SetColorTexture(unpack(C.accent))
    b.line:SetPoint("BOTTOMLEFT"); b.line:SetPoint("BOTTOMRIGHT"); b.line:SetHeight(2)
    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.05)
    function b:SetSelected(on)
        if on then self.line:Show() else self.line:Hide() end
        self.text:SetTextColor(unpack(on and C.accent or C.textDim))
    end
    return b
end

-- ------------------------------------------------------------
-- Anzeigeorte: eigenes Fenster (self.frame) oder eingebettet ins
-- Auktionshaus (self.ahHost). Die Reiter-Inhalte werden umgehängt.
-- ------------------------------------------------------------
function UI:Host()
    if self.ahOverlay and self.ahOverlay:IsVisible() then return self.ahHost end
    return self.frame
end

function UI:IsVisible()
    if self.ahOverlay and self.ahOverlay:IsVisible() then return true end
    return (self.frame and self.frame:IsShown()) and true or false
end

function UI:AttachPanels(host)
    if not host then return end
    for _, tab in ipairs(self.tabs) do
        if tab.panel and not tab.windowed and tab.panel:GetParent() ~= host.content then
            tab.panel:SetParent(host.content)
            self:PlacePanel(tab.panel, host, tab.id)
        end
    end
    -- Unterreiter-Leiste hängt am jeweiligen Inhaltsbereich
    if host.subBar then host.subBar.groupID = nil end
end

function UI:BuildTabBar(host)
    host = host or self.frame
    if not host then return end
    local bar = host.tabBar
    if bar.buttons then
        for _, b in ipairs(bar.buttons) do b:Hide() end
    end
    bar.buttons = {}
    -- eingebettet: Reiter immer oben (unten sitzen die Reiter des Auktionshauses)
    local classic = self:IsClassic() and not host.embedded
    local x0 = classic and 14 or (host.embedded and 0 or 12)
    local gap = classic and -8 or (host.embedded and 2 or 4)
    local total = 0
    for _, g in ipairs(self:Groups()) do
        local b = classic and ClassicTab(bar, L[g.label]) or ModernTab(bar, L[g.label], host.embedded)
        b.tabID = g.tabs[1]
        b.groupID = g.id
        b.groupTabs = g.tabs
        b:SetScript("OnClick", function() UI:SelectGroup(g.id) end)
        table.insert(bar.buttons, b)
        total = total + b:GetWidth() + gap
    end
    -- zu wenig Platz (z.B. im Auktionshaus, rechts sitzen Scan/Optionen/Hilfe): Reiter schmaler machen
    local avail = (host.TabSpace and host:TabSpace()) or ((host:GetWidth() or 960) - 2 * x0)
    if total > avail and #bar.buttons > 0 then
        local factor = avail / total
        for _, b in ipairs(bar.buttons) do
            local minW = (b.text and b.text.GetStringWidth and b.text:GetStringWidth() or 40) + 12
            b:SetWidth(math.max(minW, math.floor(b:GetWidth() * factor)))
        end
    end
    local x = x0
    for _, b in ipairs(bar.buttons) do
        if classic then b:SetPoint("TOPLEFT", x, 0) else b:SetPoint("BOTTOMLEFT", x, 0) end
        x = x + b:GetWidth() + gap
    end
    bar.usedWidth = x - gap
    self:UpdateTabBar()
end

function UI:UpdateTabBar()
    local g = self.activeTab and self:GroupOf(self.activeTab)
    for _, host in ipairs({ self.frame or false, self.ahHost or false }) do
        if host and host.tabBar.buttons then
            for _, b in ipairs(host.tabBar.buttons) do
                b:SetSelected(g ~= nil and b.groupID == g.id)
            end
        end
    end
    self:UpdateSubBar()
    self:UpdateHeaderStatus()
end

function UI:SelectTab(id, keepReturn)
    -- Preisverlauf: eigenes Fenster
    if self.WINDOW_TABS[id] then return self:OpenChart(nil) end
    -- Gruppen-ID statt Reiter-ID
    if not self:GetTab(id) then
        for _, g in ipairs(self:Groups()) do if g.id == id then return self:SelectGroup(id) end end
    end
    if not keepReturn then self.chartReturn = nil end
    local host = self:Host() or self:EnsureFrame()
    self:AttachPanels(host)
    local target
    for _, tab in ipairs(self.tabs) do
        if tab.id == id then target = tab end
        if tab.panel and not tab.windowed then tab.panel:Hide() end
    end
    if not target then return end

    if not target.panel then
        local ok, panelOrErr = pcall(target.builder, host.content)
        if ok and panelOrErr then
            target.panel = panelOrErr
            self:PlacePanel(target.panel, host, id)
        else
            local errFrame = CreateFrame("Frame", nil, host.content)
            errFrame:SetAllPoints()
            local msg = UI:Label(errFrame, L["Dieser Tab konnte nicht geladen werden:\n\n"] .. tostring(panelOrErr), "GameFontHighlight", C.red)
            msg:SetPoint("CENTER")
            msg:SetJustifyH("CENTER")
            target.panel = errFrame
            A:Print(L["Fehler im Tab '"] .. id .. "': " .. tostring(panelOrErr))
        end
    end

    self.activeTab = id
    if A.db then
        A.db.settings.lastTab = id
        local g = self:GroupOf(id)
        if g then
            A.db.settings.lastSub = A.db.settings.lastSub or {}
            A.db.settings.lastSub[g.id] = id
        end
    end
    self:PlacePanel(target.panel, host, id)
    target.panel:Show()
    self:RefreshActive()
    self:UpdateTabBar()
    return target.panel
end

-- neue Daten: aktiven Reiter im Hintergrund neu aufbauen (in Portionen, ohne Ruckeln).
-- Mehrere Meldungen kurz hintereinander werden zu einem Neuaufbau zusammengefasst.
-- Höchstens ein Neuaufbau pro Sekunde (nach einem Scan kommen viele Meldungen kurz hintereinander).
function UI:RefreshLater()
    if not self:IsVisible() then return end
    self.refreshWanted = true
end

local refreshTimer = CreateFrame("Frame")
refreshTimer:SetScript("OnUpdate", function()
    if not UI.refreshWanted or A:HasJob("ui-refresh") then return end
    if GetTime() - (UI.lastBgRefresh or 0) < 1 then return end
    UI.refreshWanted = false
    A:Job("ui-refresh", function()
        if UI:IsVisible() then
            for _, tab in ipairs(UI.tabs) do
                if tab.id == UI.activeTab and tab.panel and tab.panel.Refresh then
                    tab.panel:Refresh()          -- ohne pcall, damit lange Listen pausieren dürfen
                end
            end
            UI:UpdateStatus()
        end
        UI.lastBgRefresh = GetTime()
    end)
end)

-- Zwischenspeicher (A:CachedValue) im Hintergrund fertig: sichtbare Ansicht neu zeichnen (höchstens alle 0,5 s)
A:On("CACHE_UPDATED", function()
    if UI.cacheRefreshPlanned then return end
    UI.cacheRefreshPlanned = true
    local function go() UI.cacheRefreshPlanned = nil; if UI:IsVisible() or (UI.chartWin and UI.chartWin:IsShown()) then UI:RefreshActive() end end
    if C_Timer and C_Timer.After then C_Timer.After(0.5, go) else go() end
end)

function UI:RefreshActive()
    local ct = self.chartWin and self.chartWin:IsShown() and self:GetTab("charts")
    if ct and ct.panel and ct.panel.Refresh then pcall(ct.panel.Refresh, ct.panel) end
    if not self:IsVisible() then return end
    for _, tab in ipairs(self.tabs) do
        if tab.id == self.activeTab and tab.panel and tab.panel.Refresh then
            local ok, err = pcall(tab.panel.Refresh, tab.panel)
            if not ok then A:Print(L["Fehler beim Aktualisieren ('"] .. tab.id .. "'): " .. tostring(err)) end
        end
    end
    self:UpdateStatus()
end

-- ------------------------------------------------------------
-- Hauptfenster
-- ------------------------------------------------------------
function UI:EnsureFrame()
    if self.frame then return self.frame end
    if A.db then self:ApplyPalette(A.db.settings.theme or "classic") end
    local classic = self:IsClassic()

    local f = CreateFrame("Frame", "AHAnalyzerProWindow", UIParent)
    f:SetSize(960, 640)
    f:SetPoint("CENTER")
    f:SetFrameStrata("HIGH")
    f:SetToplevel(true)
    f:SetClampedToScreen(true)
    f:SetMovable(true)
    f:EnableMouse(true)
    -- Mausrad über dem Fenster: kauft einen wartenden Treffer (wie über der Spielwelt)
    f:EnableMouseWheel(true)
    f:SetScript("OnMouseWheel", function(_, delta) if A.Sniper and A.Sniper.WheelBuy then A.Sniper:WheelBuy(delta) end end)
    f:Hide()
    UI:Box(f, C.bg, C.frameEdge, classic and 3 or 1)
    UI:RegisterSpecial("AHAnalyzerProWindow")
    if A.db then f:SetScale(UI:WindowScale()) end

    local pos = A.db and A.db.settings.windowPos
    if pos then
        f:ClearAllPoints()
        f:SetPoint(pos.point or "CENTER", UIParent, pos.relPoint or "CENTER", pos.x or 0, pos.y or 0)
    end

    -- Titelleiste
    local title = CreateFrame("Frame", nil, f)
    title:SetPoint("TOPLEFT", classic and 3 or 0, classic and -3 or 0)
    title:SetPoint("TOPRIGHT", classic and -3 or 0, classic and -3 or 0)
    title:SetHeight(classic and 36 or 40)
    UI:Box(title, C.bar)
    if classic then
        local line = title:CreateTexture(nil, "ARTWORK")
        line:SetColorTexture(unpack(C.border))
        line:SetPoint("BOTTOMLEFT"); line:SetPoint("BOTTOMRIGHT"); line:SetHeight(2)
    end
    title:EnableMouse(true)
    title:RegisterForDrag("LeftButton")
    title:SetScript("OnDragStart", function() f:StartMoving() end)
    title:SetScript("OnDragStop", function()
        f:StopMovingOrSizing()
        local point, _, relPoint, x, y = f:GetPoint()
        if A.db then A.db.settings.windowPos = { point = point, relPoint = relPoint, x = x, y = y } end
    end)

    local icon = title:CreateTexture(nil, "ARTWORK")
    icon:SetSize(22, 22)
    icon:SetPoint("LEFT", 12, 0)
    icon:SetTexture(A.ICON or "Interface\\Icons\\INV_Misc_Coin_02")

    local t = UI:Label(title, "AHSentinel", classic and "GameFontNormal" or "GameFontNormalLarge", C.accent)
    if classic then t:SetPoint("CENTER", 0, 0) else t:SetPoint("LEFT", icon, "RIGHT", 10, 0) end
    local v = UI:Label(title, "v" .. A.version, "GameFontDisableSmall", C.textDim)
    v:SetPoint("LEFT", t, "RIGHT", 8, -1)

    local close = UI:CloseButton(title, function() f:Hide() end)
    close:SetPoint("RIGHT", classic and -2 or -8, 0)

    f.optionsButton = UI:Button(title, L["Optionen"], 80, 22, function() UI:ToggleOptions() end)
    f.optionsButton:SetPoint("RIGHT", close, "LEFT", classic and -4 or -6, 0)
    f.optionsButton.tooltip = L["Design (Klassisch/Modern), Fenstergröße, Ton, Preis-Sync, Sniper-Tempo, CSV-Export"]

    f.helpButton = UI:Button(title, "?", 24, 22, function() UI:ShowHelp() end)
    f.helpButton:SetPoint("RIGHT", f.optionsButton, "LEFT", -4, 0)

    f.donateButton = UI:Button(title, L["Unterstützen"], 96, 22, function() UI:ShowDonate() end)
    f.donateButton:SetPoint("RIGHT", f.helpButton, "LEFT", -6, 0)
    f.donateButton.tooltip = L["AHSentinel mit einer Spende unterstützen (PayPal)"]
    f.helpButton.tooltip = L["Hilfe zu diesem Tab"]

    -- Test: Selbsttest und Testmodus (alles gefahrlos mit echten Daten ausprobieren)
    f.testButton = UI:Button(title, L["Test"], 64, 22, function() if A.SelfTest then A.SelfTest:ShowWindow() end end)
    f.testButton:SetPoint("RIGHT", f.donateButton, "LEFT", -6, 0)
    f.testButton.tooltip = L["Test: Selbsttest und Testmodus.\nIm Testmodus alle Funktionen mit echten Auktionshaus-Daten ausprobieren -\nKaufen, Bieten, Einstellen und Abbrechen sind nur simuliert."]

    -- Sniper und Wächter: Status in der Kopfzeile (Klick: an/aus, Rechtsklick: Reiter öffnen)
    local function statusButton(kind)
        local b = UI:Button(title, "", 112, 22, function(self, button)
            if button == "RightButton" then
                UI:SelectTab(kind)
            elseif kind == "sniper" then
                if A.Sniper then A.Sniper:ToggleArmed() end
            else
                if A.Watcher then A.Watcher:Toggle() end
            end
            UI:UpdateHeaderStatus()
        end)
        if b.RegisterForClicks then b:RegisterForClicks("LeftButtonUp", "RightButtonUp") end
        b.tooltip = kind == "sniper" and L["Sniper an / aus (Rechtsklick: Reiter Sniper)"] or L["Wächter an / aus (Rechtsklick: Reiter Wächter)"]
        return b
    end
    f.sniperStatus = statusButton("sniper")
    f.watcherStatus = statusButton("watcher")
    if classic then
        f.sniperStatus:SetPoint("LEFT", icon, "RIGHT", 10, 0)
    else
        f.sniperStatus:SetPoint("LEFT", v, "RIGHT", 16, 1)
    end
    f.watcherStatus:SetPoint("LEFT", f.sniperStatus, "RIGHT", 4, 0)

    -- Statusleiste
    local status = CreateFrame("Frame", nil, f)
    status:SetPoint("BOTTOMLEFT", classic and 3 or 0, classic and 3 or 0)
    status:SetPoint("BOTTOMRIGHT", classic and -3 or 0, classic and 3 or 0)
    status:SetHeight(34)
    UI:Box(status, C.bar)
    if classic then
        local line = status:CreateTexture(nil, "ARTWORK")
        line:SetColorTexture(unpack(C.border))
        line:SetPoint("TOPLEFT"); line:SetPoint("TOPRIGHT"); line:SetHeight(2)
    end
    f.statusDot = status:CreateTexture(nil, "ARTWORK")
    f.statusDot:SetSize(8, 8)
    f.statusDot:SetPoint("LEFT", 14, 0)
    f.statusText = UI:Label(status, "", "GameFontHighlightSmall", C.textDim)
    f.statusText:SetPoint("LEFT", f.statusDot, "RIGHT", 8, 0)

    f.scanButton = UI:Button(status, L["Markt scannen"], 200, 24, function() A:StartFullScan() end, "primary")
    f.scanButton:SetPoint("RIGHT", -24, 0)

    -- Größe frei einstellbar: Ecke unten rechts ziehen
    f:SetResizable(true)
    local grip = CreateFrame("Button", nil, f)
    grip:SetSize(16, 16)
    grip:SetPoint("BOTTOMRIGHT", classic and -4 or -2, classic and 4 or 2)
    grip:SetFrameLevel(f:GetFrameLevel() + 20)
    grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    grip:SetScript("OnMouseDown", function(_, button)
        if button and button ~= "LeftButton" then return end
        UI:UpdateResizeBounds()
        f:StartSizing("BOTTOMRIGHT")
        f.sizing = true
    end)
    grip:SetScript("OnMouseUp", function() UI:FinishResize() end)
    grip:SetScript("OnHide", function() if f.sizing then UI:FinishResize() end end)
    grip:SetScript("OnEnter", function(self)
        UI:AnchorTooltip(self)
        GameTooltip:SetText(L["Fenstergröße ändern"], 1, 1, 1)
        GameTooltip:AddLine(L["Ziehen zum Vergrößern/Verkleinern.\nSchriftgröße: Optionen -> Schrift- und Inhaltsgröße."], 0.9, 0.9, 0.9, true)
        GameTooltip:Show()
    end)
    grip:SetScript("OnLeave", function() GameTooltip:Hide() end)
    f.grip = grip
    f:SetScript("OnSizeChanged", function(self, w, h)
        if not self.tabBar then return end
        -- Reiterleiste an die neue Breite anpassen (Tabellen passen sich selbst an)
        if not self.relayoutPending and C_Timer and C_Timer.After then
            self.relayoutPending = true
            C_Timer.After(0.05, function()
                self.relayoutPending = false
                UI:BuildTabBar(self)
            end)
        end
    end)
    f.scanButton.tooltip = L["Scannt das ganze Auktionshaus.\nDer Server erlaubt das nur alle 15 Minuten."]

    -- Tab-Leiste: klassisch unten am Fenster (wie das Auktionshaus), modern oben
    local tabBar = CreateFrame("Frame", nil, f)
    if classic then
        tabBar:SetPoint("TOPLEFT", f, "BOTTOMLEFT", 0, 2)
        tabBar:SetPoint("TOPRIGHT", f, "BOTTOMRIGHT", 0, 2)
        tabBar:SetHeight(32)
    else
        tabBar:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, 0)
        tabBar:SetPoint("TOPRIGHT", title, "BOTTOMRIGHT", 0, 0)
        tabBar:SetHeight(34)
        local tabLine = tabBar:CreateTexture(nil, "ARTWORK")
        tabLine:SetColorTexture(unpack(C.border))
        tabLine:SetPoint("BOTTOMLEFT"); tabLine:SetPoint("BOTTOMRIGHT"); tabLine:SetHeight(1)
    end
    f.tabBar = tabBar

    -- Inhaltsbereich
    local content = CreateFrame("Frame", nil, f)
    if classic then
        content:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 12, -14)
    else
        content:SetPoint("TOPLEFT", tabBar, "BOTTOMLEFT", 14, -12)
    end
    content:SetPoint("BOTTOMRIGHT", status, "TOPRIGHT", -14, 10)
    f.content = content

    -- Status regelmäßig aktualisieren (nur wenn sichtbar)
    local elapsed = 0
    f:SetScript("OnUpdate", function(_, dt)
        elapsed = elapsed + (dt or 0)
        if elapsed >= 0.5 then
            elapsed = 0
            UI:UpdateStatus()
        end
    end)
    f:SetScript("OnShow", function() UI:RefreshActive() end)
    f:SetScript("OnHide", function() UI:HideMenu(); UI:HideSuggest() end)

    self.frame = f
    if A.RegisterUI then A.RegisterUI(f, "Hauptfenster") end
    self:FitToAH()
    self:BuildTabBar()
    return f
end

-- Text setzen; passt er nicht auf den Knopf, die Kurzform nehmen
local function FitText(b, long, short)
    b:SetText(long)
    local w = b.label and b.label.GetStringWidth and b.label:GetStringWidth()
    if short and w and w > b:GetWidth() - 8 then b:SetText(short) end
end

local function UpdateScanButton(b)
    if not b then return nil end
    if A:IsScanning() then
        local n = (A.scanState.lastCount and A.scanState.lastCount > 0) and A.scanState.lastCount or ""
        FitText(b, L["Scan läuft ... "] .. n, "... " .. n)
        b:SetActive(false)
        return C.yellow
    elseif not A:IsScanReady() then
        local t = A:FormatDuration(A:GetCooldownRemaining())
        FitText(b, L["Nächster Scan in "] .. t, "Scan " .. t)
        b:SetActive(false)
        return C.red
    end
    local ahOpen = A:IsAHOpen()
    b:SetText(ahOpen and L["Markt scannen"] or L["Markt scannen (AH öffnen)"])
    b:SetActive(true)
    return ahOpen and C.green or C.textDim
end

function UI:UpdateHeaderStatus()
    local tOn = A.TestMode and A.TestMode.active
    local tText = tOn and ("|cffff5544" .. L["Test AN"] .. "|r") or L["Test"]
    -- Knopf "Test" nur für den Entwickler (sonst unsichtbar und ohne Platz)
    local dev = A:IsDev()
    local function vis(b, w)
        if not b then return end
        b:SetText(tText)
        b:SetShown(dev)
        b:SetWidth(dev and w or 0.1)
    end
    vis(self.ahHost and self.ahHost.testButton, 44)
    local f = self.frame
    if not (f and f.sniperStatus and A.db) then return end
    vis(f.testButton, 64)
    local on = function(v) return v and ("|cff33dd55" .. L["an"] .. "|r") or ("|cff888888" .. L["aus"] .. "|r") end
    local sn = A.Sniper and A.Sniper.IsArmed and A.Sniper:IsArmed()
    local wa = A.Watcher and A.Watcher.IsEnabled and A.Watcher:IsEnabled()
    f.sniperStatus:SetText(L["Sniper"] .. ": " .. on(sn))
    f.watcherStatus:SetText(L["Wächter"] .. ": " .. on(wa))
end

function UI:UpdateStatus()
    if not A.db then return end
    self:UpdateHeaderStatus()
    if self.ahHost then UpdateScanButton(self.ahHost.scanButton) end
    local f = self.frame
    if f then
        local ahOpen = A:IsAHOpen()
        local items = A:MarketItemCount()
        local text = ((A.TestMode and A.TestMode.active) and ("|cffff5544" .. L["TESTMODUS - Handel nur simuliert"] .. "|r   |   ") or "")
            .. (ahOpen and L["|cff33dd55Auktionshaus offen|r"] or L["|cffff5544Auktionshaus geschlossen|r"])
            .. "   |   " .. items .. L[" Items   |   letzter Scan "] .. A:FormatAgo(A.db.lastScanTime)
        if A.Sync then
            text = text .. "   |   " .. A.Sync:GetStatusText()
        end
        if A.Sniper and A.db.sniper and A.db.sniper.armed then
            text = text .. L["   |   |cff33dd55Sniper an|r"]
        end
        f.statusText:SetText(text)
        f.statusDot:SetColorTexture(unpack(UpdateScanButton(f.scanButton)))
    end
    if self.options and self.options:IsShown() then self.options:Refresh() end
end

-- Öffnen: bei offenem Auktionshaus im Auktionshaus-Fenster, sonst im eigenen Fenster
function UI:Show()
    if self:CanIntegrate() and self:ShowInAH() then return end
    self:EnsureFrame()
    self:AttachPanels(self.frame)
    pcall(self.PlaceDefault, self)
    self.frame:Show()
    self:AfterShow()
end

-- Befund 22:25 2d: Standardposition (nicht vom Spieler verschoben) nie über dem offenen Auktionshaus - daneben, wenn
-- der Platz reicht; sonst wie bisher in der Mitte (EnsureOnScreen hält es im Bildschirm)
function UI:PlaceDefault()
    local f = self.frame
    if not f or (A.db and A.db.settings.windowPos) then return end
    local ah = _G.AuctionHouseFrame or _G.AuctionFrame
    f:ClearAllPoints()
    if ah and ah.IsShown and ah:IsShown() then
        local s1, s2 = ah:GetEffectiveScale(), f:GetEffectiveScale()
        local right = (ah:GetRight() or 0) * s1
        local screen = (UIParent:GetRight() or 0) * UIParent:GetEffectiveScale()
        if right + (f:GetWidth() or 0) * s2 + 8 <= screen then
            f:SetPoint("TOPLEFT", ah, "TOPRIGHT", 8 * s1 / s2, 0)
            return
        end
    end
    f:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
end

function UI:AfterShow()
    if self.frame and self.frame:IsShown() then pcall(self.EnsureOnScreen, self) end
    if not self.activeTab and self.tabs[1] then
        local last = A.db and A.db.settings.lastTab
        self:SelectTab((last and self:GetTab(last)) and last or self.tabs[1].id)
    else
        self:SelectTab(self.activeTab)
    end
    -- Beim allerersten Öffnen kurz erklären, wie alles funktioniert
    if A.db and not A.db.settings.helpSeen then
        A.db.settings.helpSeen = true
        self:ShowHelp("start")
    end
end

function UI:Hide()
    if self.frame then self.frame:Hide() end
    if self.ahOverlay and self.ahOverlay:IsVisible() then self:LeaveAH() end
end

function UI:Toggle()
    if self:IsVisible() then self:Hide() else self:Show() end
end

function UI:ResetPosition()
    if A.db then A.db.settings.windowPos = nil; A.db.settings.windowSize = nil end
    if self.frame then self.frame.fitW = nil; self:FitToAH() end
    if self.frame then
        self.frame:ClearAllPoints()
        self.frame:SetPoint("CENTER")
    end
end

-- Kurzformen für Button & Befehle
function A:ToggleMainWindow() UI:Toggle() end
function A:ShowMainWindow() UI:Show() end

-- Von anderen Tabs aus zu einem Item im Chart springen
-- Preisverlauf als eigenes Fenster (neben dem Addon; das Addon bleibt, wo es war)
function UI:EnsureChartWindow()
    if self.chartWin then return self.chartWin end
    local w = self:Dialog("AHAnalyzerProChartWindow", 920, 580, "")
    w:SetFrameStrata("DIALOG")
    w:SetResizable(true)
    if w.SetResizeBounds then w:SetResizeBounds(760, 480) elseif w.SetMinResize then w:SetMinResize(760, 480) end
    local pos = A.db and A.db.settings.chartWinPos
    if pos then
        w:ClearAllPoints()
        w:SetPoint(pos.point or "CENTER", UIParent, pos.relPoint or "CENTER", pos.x or 0, pos.y or 0)
    end
    w:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relPoint, x, y = self:GetPoint()
        if A.db then A.db.settings.chartWinPos = { point = point, relPoint = relPoint, x = x, y = y } end
    end)
    local content = CreateFrame("Frame", nil, w)
    -- oben eine eigene Zeile für den Schließen-Knopf: die Zeitraum-Knöpfe liegen darunter
    content:SetPoint("TOPLEFT", 14, -34)
    content:SetPoint("BOTTOMRIGHT", -14, 14)
    w.content = content
    w.close:ClearAllPoints()
    w.close:SetPoint("TOPRIGHT", -6, -6)
    w.close:SetFrameLevel((w:GetFrameLevel() or 1) + 20)
    -- auch am Titel "Preisverlauf" verschieben (nicht nur am äußersten Rand)
    local drag = CreateFrame("Frame", nil, w)
    drag:SetPoint("TOPLEFT", content, "TOPLEFT", 0, 0)
    drag:SetSize(296, 28)
    drag:SetFrameLevel(content:GetFrameLevel())
    drag:EnableMouse(true)
    drag:RegisterForDrag("LeftButton")
    drag:SetScript("OnDragStart", function() w:StartMoving() end)
    drag:SetScript("OnDragStop", function() local fn = w:GetScript("OnDragStop"); if fn then fn(w) end end)
    w.dragArea = drag
    local grip = CreateFrame("Button", nil, w)
    grip:SetSize(16, 16)
    grip:SetPoint("BOTTOMRIGHT", -2, 2)
    grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetScript("OnMouseDown", function() w:StartSizing("BOTTOMRIGHT") end)
    grip:SetScript("OnMouseUp", function() w:StopMovingOrSizing(); UI:RefreshChart() end)
    w:HookScript("OnShow", function() UI:RefreshChart() end)      -- Hook: Esc- und Tooltip-Hooks bleiben erhalten
    self.chartWin = w
    local tab = self:GetTab("charts")
    if tab then
        if tab.panel then
            tab.panel:SetParent(content)
        else
            tab.panel = tab.builder(content)
        end
        tab.windowed = true
        tab.panel:ClearAllPoints()
        tab.panel:SetAllPoints(content)
        tab.panel:Show()
    end
    w:Hide()
    return w
end

function UI:RefreshChart()
    local tab = self:GetTab("charts")
    if tab and tab.panel and tab.panel.Refresh and self.chartWin and self.chartWin:IsShown() then
        local ok, err = pcall(tab.panel.Refresh, tab.panel)
        if not ok then A:Print(L["Fehler beim Aktualisieren ('"] .. "charts" .. "'): " .. tostring(err)) end
    end
end

function UI:OpenChart(itemID)
    local w = self:EnsureChartWindow()
    if itemID then self.pendingChartItem = itemID end
    self.chartReturn = nil
    w:Show()
    w:Raise()
    self:RefreshChart()
    local tab = self:GetTab("charts")
    return tab and tab.panel
end

-- früher: zurück aus dem Reiter Preisverlauf; jetzt: Fenster schließen
function UI:ChartBack()
    self.chartReturn = nil
    if self.chartWin then self.chartWin:Hide() end
end

-- Item als Sniper-Ziel vorbereiten (Formular ausfüllen)
function UI:OpenSniperFor(itemID)
    self:Show()
    local panel = self:SelectTab("sniper")
    if panel and panel.Prefill then panel:Prefill(itemID) end
end

-- ------------------------------------------------------------
-- Einbindung ins Auktionshaus-Fenster
--   * zusätzlicher Reiter "AHSentinel" unten neben Kaufen / Verkaufen / Auktionen
--   * ein Klick zeigt das ganze Addon im Auktionshaus-Fenster (über dem Blizzard-Inhalt)
--   * ein Klick auf einen Blizzard-Reiter schaltet zurück
-- Es werden keine Blizzard-Funktionen ersetzt, nur ergänzt (hooksecurefunc),
-- damit Kaufen & Co. im Auktionshaus weiter ohne Fehler funktionieren.
-- ------------------------------------------------------------
local AH_W, AH_H = 944, 544     -- Größe der eingebetteten Ansicht vor dem Einpassen

-- nur echte Fenster-Objekte (Tabellen) zählen
local function IsWidget(x) return type(x) == "table" end

-- Auktionshaus-Fenster: modern (AuctionHouseFrame) oder altes Classic-Fenster (AuctionFrame)
local function AHFrame()
    if IsWidget(AuctionHouseFrame) then return AuctionHouseFrame, "modern" end
    if IsWidget(AuctionFrame) then return AuctionFrame, "legacy" end
    return nil
end
UI.AHFrame = AHFrame

function UI:CanIntegrate()
    return A.db ~= nil and A.db.settings.ahIntegration ~= false and AHFrame() ~= nil and A:IsAHOpen()
end

-- Blizzard-Reiter des Auktionshauses (ohne unseren eigenen)
local function AHTabs(exclude)
    local ah, kind = AHFrame()
    local list = {}
    local function add(t)
        if IsWidget(t) and t ~= UI.ahTab and t ~= exclude then table.insert(list, t) end
    end
    if ah and type(ah.Tabs) == "table" then
        for _, t in ipairs(ah.Tabs) do add(t) end
    end
    if #list == 0 then
        local prefix = (kind == "legacy") and "AuctionFrameTab" or "AuctionHouseFrameTab"
        for i = 1, 8 do add(_G[prefix .. i]) end
    end
    if #list == 0 and ah then
        for _, n in ipairs({ "BuyTab", "SellTab", "AuctionsTab" }) do add(ah[n]) end
    end
    return list
end

local function AHSearchBar()
    local ah = AHFrame()
    local sb = ah and ah.SearchBar
    if IsWidget(sb) then return sb end
    return nil
end

local TAB_TEMPLATES = {
    "AuctionHouseFrameDisplayModeTabTemplate",
    "AuctionHouseFrameTabTemplate",
    "AuctionTabTemplate",
    "PanelTabButtonTemplate",
    "CharacterFrameTabButtonTemplate",
}

-- Fehler bei der Einbindung einmal melden und für /ahs ahdebug merken
function UI:ReportAHError(err)
    self.ahLastError = tostring(err)
    A:ReportError("AH-Einbindung", err)
    if not self.ahErrorShown then
        self.ahErrorShown = true
        A:Print(L["AH-Einbindung fehlgeschlagen: "] .. self.ahLastError .. "  (/ahs ahdebug)")
    end
end

function UI:EnsureAHTab()
    local ah, kind = AHFrame()
    if not ah then return nil end
    if self.ahTab then
        self.ahTab:Show()
        pcall(self.PlaceAHTab, self)
        return self.ahTab
    end
    -- vorhandene Reiter VOR dem Erzeugen merken: manche Blizzard-Vorlagen tragen
    -- einen neuen Reiter selbst in die Reiterliste ein
    local tabs = AHTabs()
    local last = tabs[#tabs]

    local b
    for _, tpl in ipairs(TAB_TEMPLATES) do
        local ok, f = pcall(CreateFrame, "Button", "AHAnalyzerProAHTab", ah, tpl)
        if ok and f then
            b = f
            b.template = tpl
            break
        end
    end
    -- unseren Reiter wieder aus Blizzards Reiterliste nehmen, damit Blizzard ihn nicht verwaltet
    if b and type(ah.Tabs) == "table" then
        for i = #ah.Tabs, 1, -1 do
            if ah.Tabs[i] == b then table.remove(ah.Tabs, i) end
        end
    end
    if b then
        b:SetText("AHSentinel")
        if PanelTemplates_TabResize then pcall(PanelTemplates_TabResize, b, 0) end
        if (b:GetWidth() or 0) < 40 then b:SetWidth(110) end
    else
        b = ClassicTab(ah, "AHSentinel")      -- Rückfall: eigener Reiter im gleichen Stil
        b:SetSelected(false)
    end
    -- rechts neben den letzten Blizzard-Reiter (auch Reiter anderer Addons)
    b:ClearAllPoints()
    if last and last ~= b then
        b:SetPoint("LEFT", last, "RIGHT", 3, 0)
    else
        b:SetPoint("TOPLEFT", ah, "BOTTOMLEFT", 20, 2)
    end
    b.anchorTab = last
    b:SetScript("OnClick", function()
        if A.db and A.db.settings.ahIntegration == false then
            -- eigenes Fenster (vom Auktionshaus gelöst): ein-/ausblenden
            UI:EnsureFrame()
            if UI.frame:IsShown() then UI.frame:Hide() else UI:Show() end
            return
        end
        local ok, err = pcall(UI.ShowInAH, UI)
        if not ok then UI:ReportAHError(err) end
    end)
    b:SetScript("OnEnter", function(self)
        UI:AnchorTooltip(self)
        GameTooltip:SetText("AHSentinel")
        GameTooltip:AddLine(L["Scan, Preisverlauf, Watchlist, Sniper und mehr - hier im Auktionshaus"], 1, 1, 1, true)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:Show()
    self.ahTab = b
    self.ahTabHooks = self.ahTabHooks or {}
    for _, t in ipairs(tabs) do self.ahTabHooks[t] = true end

    -- Klick auf einen Blizzard-Reiter: zurück zur Blizzard-Ansicht (nur einmal einhängen)
    if not self.ahHooked then
        self.ahHooked = true
        if ah.SetDisplayMode and hooksecurefunc then
            pcall(hooksecurefunc, ah, "SetDisplayMode", function() UI:OnBlizzardView() end)
        end
        if kind == "legacy" and AuctionFrameTab_OnClick and hooksecurefunc then
            pcall(hooksecurefunc, "AuctionFrameTab_OnClick", function() UI:OnBlizzardView() end)
        end
        for _, t in ipairs(tabs) do
            if t.HookScript then pcall(t.HookScript, t, "OnClick", function() UI:OnBlizzardView() end) end
        end
    end
    pcall(self.PlaceAHTab, self)
    return b
end

-- hängt Frame x (über seine Anker) an Frame target?
local function DependsOn(x, target, depth)
    depth = depth or 0
    if depth > 12 or not (x and x.GetNumPoints and x.GetPoint) then return false end
    local ok, n = pcall(x.GetNumPoints, x)
    if not ok or not n then return false end
    for i = 1, n do
        local ok2, _, rel = pcall(x.GetPoint, x, i)
        if ok2 and rel then
            if rel == target then return true end
            if type(rel) == "table" and DependsOn(rel, target, depth + 1) then return true end
        end
    end
    return false
end

-- alle sichtbaren Reiter unten am Auktionshaus: Blizzard UND andere Addons (TSM, Auctionator ...)
local function AllAHTabs(ah, own)
    local list, seen = {}, {}
    local function add(t)
        if IsWidget(t) and t ~= own and not seen[t] and t.IsShown and t:IsShown() then
            seen[t] = true
            table.insert(list, t)
        end
    end
    if type(ah.Tabs) == "table" then for _, t in ipairs(ah.Tabs) do add(t) end end
    for _, prefix in ipairs({ "AuctionFrameTab", "AuctionHouseFrameTab" }) do
        for i = 1, 20 do add(_G[prefix .. i]) end
    end
    if ah.GetChildren then
        for _, c in ipairs({ ah:GetChildren() }) do
            local okT, typ = pcall(c.GetObjectType, c)
            local okN, name = pcall(c.GetName, c)
            if okT and typ == "Button" and okN and type(name) == "string" and name:find("Tab") then add(c) end
        end
    end
    return list
end

-- unseren Reiter rechts neben den äußersten Reiter setzen. Andere Addons hängen ihre
-- Reiter oft erst nach uns an - deshalb beim Öffnen und kurz danach erneut aufrufen.
function UI:PlaceAHTab()
    local b, ah = self.ahTab, AHFrame()
    if not (b and ah) then return end
    local bottom = ah.GetBottom and ah:GetBottom()
    local best, bestR
    for _, t in ipairs(AllAHTabs(ah, b)) do
        -- Reiter, die schon rechts von uns hängen, nicht nehmen (sonst Kreis-Anker)
        if not DependsOn(t, b) then
            local okR, r = pcall(t.GetRight, t)
            local okT, top = pcall(t.GetTop, t)
            local nearBottom = not (bottom and okT and top) or top <= bottom + 40
            if okR and r and nearBottom and (not bestR or r > bestR) then best, bestR = t, r end
        end
        -- Klick auf einen fremden Reiter beendet unsere Ansicht
        self.ahTabHooks = self.ahTabHooks or {}
        if not self.ahTabHooks[t] and t.HookScript then
            self.ahTabHooks[t] = true
            pcall(t.HookScript, t, "OnClick", function() UI:OnBlizzardView() end)
        end
    end
    if best and best ~= b.anchorTab then
        b:ClearAllPoints()
        b:SetPoint("LEFT", best, "RIGHT", 3, 0)
        b.anchorTab = best
    end
end

function UI:SetAHTabSelected(on)
    local b = self.ahTab
    if not b then return end
    if b.template and PanelTemplates_SelectTab and PanelTemplates_DeselectTab then
        pcall(on and PanelTemplates_SelectTab or PanelTemplates_DeselectTab, b)
    elseif b.SetSelected then
        b:SetSelected(on)
    end
    if on and PanelTemplates_DeselectTab then
        for _, t in ipairs(AHTabs(b)) do pcall(PanelTemplates_DeselectTab, t) end
    end
end

-- Blizzard hat selbst eine Ansicht gewählt (Kaufen, Verkaufen, Auktionen)
function UI:OnBlizzardView()
    self.searchBarHidden = false          -- Blizzard kümmert sich selbst um seine Suchleiste
    if self.ahOverlay and self.ahOverlay:IsShown() then
        self.ahOverlay:Hide()
        self:SetAHTabSelected(false)
        self:HideMenu()
        self:HideSuggest()
    end
end

function UI:EnsureAHHost()
    if self.ahHost then return self.ahHost end
    local ah, kind = AHFrame()
    -- Abdeckung über dem Blizzard-Inhalt (unterhalb von Titel und Porträt)
    local o = CreateFrame("Frame", "AHAnalyzerProAHPanel", ah)
    self.ahOverlay = o
    self:AnchorAHOverlay()
    if ah.GetFrameLevel then o:SetFrameLevel((ah:GetFrameLevel() or 1) + 30) end
    o:EnableMouse(true)
    o:EnableMouseWheel(true)
    o:SetScript("OnMouseWheel", function(_, delta) if A.Sniper and A.Sniper.WheelBuy then A.Sniper:WheelBuy(delta) end end)
    UI:Box(o, { C.bg[1], C.bg[2], C.bg[3], 1 }, C.border)      -- deckend: nichts von Blizzard scheint durch
    o:Hide()

    local h = CreateFrame("Frame", nil, o)
    h:SetSize(AH_W, AH_H)
    h:SetPoint("TOPLEFT", 0, 0)
    h.embedded = true

    -- Reiter des Addons oben, rechts daneben Scan, Optionen, Hilfe
    local tb = CreateFrame("Frame", nil, h)
    tb:SetPoint("TOPLEFT", 6, -2)
    tb:SetPoint("TOPRIGHT", -6, -2)
    tb:SetHeight(32)
    local line = tb:CreateTexture(nil, "ARTWORK")
    line:SetColorTexture(unpack(C.border))
    line:SetPoint("BOTTOMLEFT"); line:SetPoint("BOTTOMRIGHT"); line:SetHeight(1)
    h.tabBar = tb

    h.scanButton = UI:Button(tb, L["Markt scannen"], 130, 24, function() A:StartFullScan() end, "primary")
    h.scanButton:SetPoint("RIGHT", 0, 3)
    h.scanButton.tooltip = L["Scannt das ganze Auktionshaus.\nDer Server erlaubt das nur alle 15 Minuten."]
    -- Optionen als Zahnrad (spart Platz für die Reiter in allen Sprachen)
    h.optionsButton = UI:Button(tb, "", 24, 24, function() UI:ToggleOptions() end)
    h.optionsButton:SetPoint("RIGHT", h.scanButton, "LEFT", -6, 0)
    h.optionsButton.tooltip = L["Optionen"]
    h.optionsButton.icon = h.optionsButton:CreateTexture(nil, "OVERLAY")
    h.optionsButton.icon:SetTexture("Interface\\Icons\\INV_Misc_Gear_01")
    h.optionsButton.icon:SetPoint("CENTER")
    h.optionsButton.icon:SetSize(18, 18)
    if h.optionsButton.icon.SetTexCoord then h.optionsButton.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92) end
    h.helpButton = UI:Button(tb, "?", 24, 24, function() UI:ShowHelp() end)
    h.helpButton:SetPoint("RIGHT", h.optionsButton, "LEFT", -4, 0)
    h.helpButton.tooltip = L["Hilfe zu diesem Tab"]
    -- Test: Selbsttest und Testmodus
    h.testButton = UI:Button(tb, L["Test"], 44, 24, function() if A.SelfTest then A.SelfTest:ShowWindow() end end)
    h.testButton:SetPoint("RIGHT", h.helpButton, "LEFT", -4, 0)
    h.testButton.tooltip = L["Test: Selbsttest und Testmodus.\nIm Testmodus alle Funktionen mit echten Auktionshaus-Daten ausprobieren -\nKaufen, Bieten, Einstellen und Abbrechen sind nur simuliert."]
    -- vergrößert verdeckt das Addon die Reiter des Auktionshauses: eigener Zurück-Knopf
    h.backButton = UI:Button(tb, "<", 24, 24, function() UI:LeaveAH() end)
    h.backButton:SetPoint("RIGHT", h.testButton, "LEFT", -4, 0)
    h.backButton.tooltip = L["Zurück zum Auktionshaus"]
    h.backButton:Hide()
    -- Platz für die Reiter: Breite der Leiste minus Scan, Optionen und Hilfe (und Zurück)
    function h:TabSpace()
        local extra = self.backButton:IsShown() and 28 or 0
        return ((self:GetWidth() or AH_W) - 12) - (130 + 6 + 24 + 4 + 24 + 4 + 44) - 10 - extra
    end

    local content = CreateFrame("Frame", nil, h)
    content:SetPoint("TOPLEFT", tb, "BOTTOMLEFT", 0, -8)
    content:SetPoint("BOTTOMRIGHT", h, "BOTTOMRIGHT", -6, 2)
    h.content = content

    -- die ganze Fläche des Auktionshauses füllen: Maßstab so, dass mindestens die
    -- Grundgröße hineinpasst, der Rest wird zu zusätzlicher Breite bzw. Höhe
    -- (die Tabellen der Reiter dehnen sich mit)
    local function fit()
        local w, hh = o:GetWidth(), o:GetHeight()
        if not w or not hh or w <= 0 or hh <= 0 then return end
        local s = math.min(w / AH_W, hh / AH_H)
        h:SetScale(s)
        h:ClearAllPoints()
        h:SetPoint("TOPLEFT", o, "TOPLEFT", 0, 0)
        local nw, nh = math.floor(w / s), math.floor(hh / s)
        if nw ~= h.fitW or nh ~= h.fitH then
            h.fitW, h.fitH = nw, nh
            h:SetSize(nw, nh)
            UI:BuildTabBar(h)
            UI:RefreshActive()
        end
    end
    h.Fit = fit
    o:SetScript("OnShow", function() fit(); UI:RefreshActive() end)
    o:SetScript("OnSizeChanged", fit)
    o:SetScript("OnHide", function() UI:HideMenu(); UI:HideSuggest() end)
    local elapsed = 0
    o:SetScript("OnUpdate", function(_, dt)
        elapsed = elapsed + (dt or 0)
        if elapsed >= 0.5 then
            elapsed = 0
            UI:UpdateStatus()
        end
    end)

    self.ahOverlay, self.ahHost = o, h
    h.backButton:SetShown(self:AHZoom() > 1.001)
    self:BuildTabBar(h)
    return h
end

-- Vergrößerung im Auktionshaus (1 = genau die Fläche des Auktionshauses)
function UI:AHZoom()
    local z = A.db and A.db.settings.ahZoom or 1
    return math.max(1, math.min(1.6, z))
end

-- Abdeckung über das Auktionshaus legen; vergrößert ragt sie nach rechts und unten hinaus
function UI:AnchorAHOverlay()
    local o = self.ahOverlay
    local ah, kind = AHFrame()
    if not (o and ah) then return end
    local l, t, r, b
    if kind == "legacy" then
        -- klassisches Auktionshaus: direkt unter dem Titel, deckt auch die Blizzard-Suchzeile ab
        l, t, r, b = 20, -36, -8, 14
    else
        l, t, r, b = 6, -58, -6, 6
    end
    local zoom = self:AHZoom()
    o:ClearAllPoints()
    local aw, ahh = ah:GetWidth() or 0, ah:GetHeight() or 0
    local bw, bh = aw - l + r, ahh + t - b
    if zoom <= 1.001 or bw <= 0 or bh <= 0 then
        o:SetPoint("TOPLEFT", ah, "TOPLEFT", l, t)
        o:SetPoint("BOTTOMRIGHT", ah, "BOTTOMRIGHT", r, b)
    else
        -- nicht über den Bildschirmrand hinaus
        local es = ah.GetEffectiveScale and ah:GetEffectiveScale() or 1
        local ps = UIParent and UIParent.GetEffectiveScale and UIParent:GetEffectiveScale() or 1
        local left, top = ah.GetLeft and ah:GetLeft(), ah.GetTop and ah:GetTop()
        if left and top and UIParent and UIParent.GetWidth and es > 0 then
            local screenW = (UIParent:GetWidth() or 0) * ps / es
            local roomW = screenW - (left + l) - 4
            local roomH = (top + t) - 4
            if roomW > 0 then zoom = math.min(zoom, roomW / bw) end
            if roomH > 0 then zoom = math.min(zoom, roomH / bh) end
            zoom = math.max(1, zoom)
        end
        o:SetPoint("TOPLEFT", ah, "TOPLEFT", l, t)
        o:SetSize(math.floor(bw * zoom), math.floor(bh * zoom))
    end
    if self.ahHost then
        self.ahHost.backButton:SetShown(zoom > 1.001)
        if self.ahHost.Fit then self.ahHost.Fit() end
    end
end

function UI:SetAHZoom(z)
    A.db.settings.ahZoom = math.floor(math.max(1, math.min(1.6, z)) * 20 + 0.5) / 20
    self:AnchorAHOverlay()
    if self.ahHost then self.ahHost.fitW = nil; if self.ahHost.Fit then self.ahHost.Fit() end end
    self:FitToAH()
end

function UI:ShowInAH()
    if not self:CanIntegrate() then return false end
    self:EnsureAHTab()
    local host = self:EnsureAHHost()
    if self.frame and self.frame:IsShown() then self.frame:Hide() end
    -- Blizzard-Suchleiste über dem Inhalt ausblenden, solange unsere Ansicht offen ist
    local sb = AHSearchBar()
    if sb and sb:IsShown() then
        sb:Hide()
        self.searchBarHidden = true
    end
    self.ahOverlay:Show()
    self:SetAHTabSelected(true)
    self:AttachPanels(host)
    self:AfterShow()
    return true
end

-- zurück zur Blizzard-Ansicht "Kaufen"
function UI:LeaveAH()
    if not self.ahOverlay then return end
    self.ahOverlay:Hide()
    self:SetAHTabSelected(false)
    local first = AHTabs()[1]
    if first and first.Click then pcall(first.Click, first) end
    self:RestoreSearchBar()
end

function UI:RestoreSearchBar()
    local sb = AHSearchBar()
    if self.searchBarHidden and sb then sb:Show() end
    self.searchBarHidden = false
end

function UI:OnAHClosed()
    if self.ahOverlay then
        self.ahOverlay:Hide()
        self:SetAHTabSelected(false)
    end
    self:RestoreSearchBar()
end

function UI:OnAHOpened(attempt)
    if A.db and AHFrame() then pcall(self.MeasureAH, self) end
    if not (A.db and A.db.settings.ahIntegration ~= false) then
        -- eigenes Fenster: Reiter "AHSentinel" am Auktionshaus blendet es ein/aus
        attempt = attempt or 1
        if not AHFrame() then
            if attempt < 20 and C_Timer and C_Timer.After then
                C_Timer.After(0.25, function() if A:IsAHOpen() then UI:OnAHOpened(attempt + 1) end end)
            end
            return
        end
        self:HookAHFrame()
        pcall(self.EnsureAHTab, self)
        if C_Timer and C_Timer.After then
            for _, d in ipairs({ 0.1, 0.5, 1.5, 4 }) do
                C_Timer.After(d, function() if A:IsAHOpen() then pcall(UI.PlaceAHTab, UI) end end)
            end
        end
        return
    end
    attempt = attempt or 1
    if not AHFrame() then
        -- das Auktionshaus-Fenster lädt Blizzard erst beim Öffnen: mehrmals nachsehen
        if attempt < 20 and C_Timer and C_Timer.After then
            C_Timer.After(0.25, function() if A:IsAHOpen() then UI:OnAHOpened(attempt + 1) end end)
        end
        return
    end
    self:HookAHFrame()
    local ok, err = pcall(self.EnsureAHTab, self)
    if not ok then return self:ReportAHError(err) end
    -- Reiter anderer Addons kommen oft etwas später dazu
    if C_Timer and C_Timer.After then
        for _, d in ipairs({ 0.1, 0.5, 1.5, 4 }) do
            C_Timer.After(d, function() if A:IsAHOpen() then pcall(UI.PlaceAHTab, UI) end end)
        end
    end
    if self.ahOverlay then pcall(self.AnchorAHOverlay, self) end
    -- eigenes Fenster war offen: direkt ins Auktionshaus umziehen
    if self.frame and self.frame:IsShown() then
        local ok2, err2 = pcall(self.ShowInAH, self)
        if not ok2 then self:ReportAHError(err2) end
    end
end

-- Öffnen/Schließen direkt am Auktionshaus-Fenster erkennen
-- (falls der Client die Auktionshaus-Ereignisse anders oder gar nicht meldet)
function UI:HookAHFrame()
    local ah = AHFrame()
    if not ah or self.ahFrameHooked == ah or not ah.HookScript then return end
    self.ahFrameHooked = ah
    pcall(ah.HookScript, ah, "OnShow", function() A:SetAHOpenState(true) end)
    pcall(ah.HookScript, ah, "OnHide", function() A:SetAHOpenState(false) end)
end

-- Diagnose: /ahs ahdebug
function UI:PrintAHDebug()
    local ah, kind = AHFrame()
    local function yn(v) return v and "ja" or "nein" end
    A:Print("AH-Einbindung: " .. yn(A.db and A.db.settings.ahIntegration ~= false) .. ", AH offen: " .. yn(A:IsAHOpen())
        .. " (Ereignis: " .. tostring(A.ahOpen) .. ")")
    if not ah then
        A:Print("Auktionshaus-Fenster: nicht gefunden (AuctionHouseFrame=" .. type(AuctionHouseFrame) .. ", AuctionFrame=" .. type(AuctionFrame) .. ")")
    else
        local w, h = ah:GetWidth(), ah:GetHeight()
        A:Print("Fenster: " .. tostring(ah.GetName and ah:GetName()) .. " (" .. kind .. "), Größe " .. math.floor(w or 0) .. "x" .. math.floor(h or 0)
            .. ", sichtbar " .. yn(ah:IsShown()) .. ", SetDisplayMode " .. yn(ah.SetDisplayMode) .. ", Suchleiste " .. yn(AHSearchBar()))
        local names = {}
        for _, t in ipairs(AHTabs()) do
            table.insert(names, tostring(t.GetName and t:GetName() or "?") .. "=" .. tostring(t.GetText and t:GetText() or "") .. (t:IsShown() and "" or "(versteckt)"))
        end
        A:Print("Reiter (" .. #names .. "): " .. table.concat(names, ", "))
        if type(ah.Tabs) == "table" then A:Print("ah.Tabs: " .. #ah.Tabs .. " Einträge") end
        local avail = {}
        for _, tpl in ipairs(TAB_TEMPLATES) do
            local ok, f = pcall(CreateFrame, "Button", nil, UIParent, tpl)
            if ok and f then
                table.insert(avail, tpl)
                f:Hide()
                if type(ah.Tabs) == "table" then
                    for i = #ah.Tabs, 1, -1 do if ah.Tabs[i] == f then table.remove(ah.Tabs, i) end end
                end
            end
        end
        A:Print("Vorlagen vorhanden: " .. (#avail > 0 and table.concat(avail, ", ") or "keine"))
    end
    local b = self.ahTab
    if b then
        local p1, rel = b:GetPoint()
        A:Print("Unser Reiter: Vorlage " .. tostring(b.template or "eigene") .. ", sichtbar " .. yn(b:IsShown()) .. ", Breite " .. math.floor(b:GetWidth() or 0)
            .. ", Anker " .. tostring(p1) .. " an " .. tostring(rel and rel.GetName and rel:GetName() or rel))
    else
        A:Print("Unser Reiter: noch nicht erstellt")
    end
    A:Print("Ansicht im AH: " .. (self.ahOverlay and (yn(self.ahOverlay:IsShown()) .. ", Breite " .. math.floor(self.ahOverlay:GetWidth() or 0)
        .. ", Höhe " .. math.floor(self.ahOverlay:GetHeight() or 0)) or "noch nicht erstellt"))
    A:Print("Letzter Fehler: " .. tostring(self.ahLastError or "keiner"))
end

-- /ahs ah: Ansicht im Auktionshaus von Hand öffnen
function UI:ForceAH()
    if not (A.db and A.db.settings.ahIntegration ~= false) then return A:Print(L["Die Einbindung ins Auktionshaus ist ausgeschaltet (Optionen)."]) end
    if not A:IsAHOpen() then return A:Print(L["Bitte zuerst das Auktionshaus öffnen."]) end
    if not AHFrame() then return A:Print(L["Auktionshaus-Fenster nicht gefunden."] .. "  (/ahs ahdebug)") end
    local ok, err = pcall(self.ShowInAH, self)
    if not ok then self:ReportAHError(err) end
end

-- Blizzard lädt das Auktionshaus-Fenster nachträglich: dann sofort einhängen
do
    local loader = CreateFrame("Frame")
    pcall(loader.RegisterEvent, loader, "ADDON_LOADED")
    loader:SetScript("OnEvent", function(_, _, name)
        if type(name) == "string" and name:find("^Blizzard_Auction") then
            UI:HookAHFrame()
            if A:IsAHOpen() then UI:OnAHOpened() end
        end
    end)
end
A:On("READY", function() UI:HookAHFrame() end)

function UI:SetIntegration(on)
    if not A.db then return end
    A.db.settings.ahIntegration = on and true or false
    if on then
        if A:IsAHOpen() then self:OnAHOpened() end
    else
        local inAH = self.ahOverlay and self.ahOverlay:IsVisible()
        if inAH then self:LeaveAH() end
        if inAH then self:Show() end
        if A:IsAHOpen() then self:OnAHOpened() end       -- Reiter blendet jetzt das eigene Fenster ein/aus
    end
end

-- ------------------------------------------------------------
-- Design umschalten (ohne /reload): Fenster wird neu aufgebaut
-- ------------------------------------------------------------
function UI:SetTheme(name)
    if not self.THEMES[name] then return false end
    if A.db then A.db.settings.theme = name end
    return self:Rebuild(name)
end

-- Alle Fenster neu aufbauen (nach Design- oder Sprachwechsel)
function UI:Rebuild(name)
    name = name or (A.db and A.db.settings.theme) or "classic"
    if not self.THEMES[name] then name = "classic" end
    local wasShown = self.frame and self.frame:IsShown()
    local wasInAH = self.ahOverlay and self.ahOverlay:IsVisible()
    local optionsShown = self.options and self.options:IsShown()
    local active = self.activeTab

    -- alte Fenster ausblenden und vergessen (der Reiter im Auktionshaus bleibt)
    local chartShown = self.chartWin and self.chartWin:IsShown()
    local todayShown = self.todayWin and self.todayWin:IsShown()
    for _, key in ipairs({ "frame", "options", "helpWindow", "textWindow", "donateWindow", "menu", "suggest", "ahOverlay", "chartWin",
                           "todayWin", "mailRulesWindow" }) do
        if self[key] then self[key]:Hide(); self[key] = nil end
    end
    self.ahHost = nil
    for _, tab in ipairs(self.tabs) do tab.panel = nil; tab.windowed = nil end
    self.activeTab = nil

    self:ApplyPalette(name)
    A:Fire("THEME_CHANGED", name)

    if wasShown or wasInAH then
        self:Show()
        if active then self:SelectTab(active) end
    end
    if optionsShown then self:ShowOptions() end
    if chartShown then self:OpenChart(nil) end
    if todayShown and self.ShowToday then self:ShowToday() end
    return true
end

function UI:ToggleTheme()
    self:SetTheme(self.theme == "classic" and "modern" or "classic")
    A:Print(L["Design: "] .. L[self.THEMES[self.theme].label])
end

function UI:SetScale(scale)
    scale = math.floor(math.max(0.6, math.min(1.4, scale)) * 100 + 0.5) / 100
    if A.db then A.db.settings.scale = scale end
    for _, key in ipairs({ "frame", "options", "helpWindow", "textWindow", "listsWindow" }) do
        if self[key] then self[key]:SetScale(scale) end
    end
    self:FitToAH()          -- Hauptfenster: Maßstab kommt aus "Schrift- und Inhaltsgröße"
    return scale
end

-- ------------------------------------------------------------
-- Fenster so groß wie das Auktionshaus-Fenster
-- Die Größe des Auktionshauses wird bei jedem Öffnen gemessen und gemerkt
-- (in Bildschirm-Einheiten, also inkl. UI-Skalierung), damit das eigene
-- Fenster auch bei geschlossenem Auktionshaus gleich groß ist.
-- ------------------------------------------------------------
local WIN_W, WIN_H = 960, 640

function UI:MeasureAH()
    local ah = self.AHFrame and self.AHFrame()
    if not (ah and ah.GetWidth and ah:IsShown()) then return false end
    local w, h = ah:GetWidth(), ah:GetHeight()
    if not w or not h or w < 200 or h < 200 then return false end
    local es = ah.GetEffectiveScale and ah:GetEffectiveScale() or 1
    local ps = UIParent and UIParent.GetEffectiveScale and UIParent:GetEffectiveScale() or 1
    if not es or es <= 0 or not ps or ps <= 0 then return false end
    A.db.settings.ahSize = { w = w * es / ps, h = h * es / ps }
    self:FitToAH()
    return true
end

-- Maßstab des eigenen Fensters, damit es so groß ist wie das Auktionshaus (nil = noch nie gemessen)
function UI:AHMatchScale()
    local s = A.db and A.db.settings
    if not (s and s.ahSize) then return nil end
    local sc = math.min(s.ahSize.w / WIN_W, s.ahSize.h / WIN_H)
    return math.max(0.4, math.min(2, sc))
end

-- Eigenes Fenster: frei verschieb- und vergrößerbar (Ecke unten rechts).
-- Maßstab (Schriftgröße) = wie das Auktionshaus x Option "Schrift- und Inhaltsgröße";
-- Größe = vom Spieler gezogen (gespeichert), sonst anfangs so groß wie das Auktionshaus.
local MIN_W, MIN_H = 960, 640

function UI:WindowScale()
    return (self:AHMatchScale() or 1) * self:AHZoom()
end

-- Grenzen fürs Ziehen: nicht kleiner als die Grundgröße, nicht größer als der Bildschirm
function UI:UpdateResizeBounds()
    local f = self.frame
    if not f then return end
    local sc = f:GetScale() or 1
    local sw = (UIParent and UIParent.GetWidth and UIParent:GetWidth() or 1920) / sc
    local sh = (UIParent and UIParent.GetHeight and UIParent:GetHeight() or 1080) / sc
    local maxW, maxH = math.max(MIN_W, sw), math.max(MIN_H, sh)
    if f.SetResizeBounds then pcall(f.SetResizeBounds, f, MIN_W, MIN_H, maxW, maxH)
    else
        if f.SetMinResize then pcall(f.SetMinResize, f, MIN_W, MIN_H) end
        if f.SetMaxResize then pcall(f.SetMaxResize, f, maxW, maxH) end
    end
    return maxW, maxH
end

function UI:FinishResize()
    local f = self.frame
    if not f then return end
    f:StopMovingOrSizing()
    f.sizing = false
    local maxW, maxH = self:UpdateResizeBounds()
    local w = math.floor(math.max(MIN_W, math.min(maxW, f:GetWidth() or MIN_W)))
    local h = math.floor(math.max(MIN_H, math.min(maxH, f:GetHeight() or MIN_H)))
    if A.db then
        A.db.settings.windowSize = { w = w, h = h }
        local point, _, relPoint, x, y = f:GetPoint()
        if point then A.db.settings.windowPos = { point = point, relPoint = relPoint, x = x, y = y } end
    end
    f:SetSize(w, h)
    f.fitW, f.fitH = w, h
    self:BuildTabBar(f)
    self:RefreshActive()
end

function UI:FitToAH()
    local f = self.frame
    if not (f and A.db) then return false end
    local s = A.db.settings
    local sc = self:WindowScale()
    f:SetScale(sc)
    local w, h
    if s.windowSize then
        w, h = s.windowSize.w, s.windowSize.h
    elseif s.ahSize then
        local base = self:AHMatchScale() or 1
        w, h = s.ahSize.w / base, s.ahSize.h / base        -- anfangs: so groß wie das Auktionshaus
    else
        w, h = WIN_W, WIN_H
    end
    local maxW, maxH = self:UpdateResizeBounds()
    w = math.floor(math.max(MIN_W, math.min(maxW or w, w)))
    h = math.floor(math.max(MIN_H, math.min(maxH or h, h)))
    if w ~= f.fitW or h ~= f.fitH then
        f.fitW, f.fitH = w, h
        f:SetSize(w, h)
        if f.tabBar then self:BuildTabBar(f) end
        if f:IsShown() then self:RefreshActive() end
    end
    return true
end

-- Hauptfenster immer ganz im Bildschirm (Entscheid der Prüf-Sitzung 9. Nov. 09:35, T193):
-- höchstens 90 % von UIParent (sonst kleiner skaliert) und Position an den Rand geklemmt.
UI.SCREEN_SHARE = 0.9
function UI:EnsureOnScreen(f)
    f = f or self.frame
    if not (f and f.GetRect and UIParent and UIParent.GetWidth) then return false end
    local ps = UIParent.GetEffectiveScale and UIParent:GetEffectiveScale() or 1
    local sw, sh = (UIParent:GetWidth() or 0) * ps, (UIParent:GetHeight() or 0) * ps
    if sw <= 0 or sh <= 0 then return false end
    local changed = false
    -- 1. Grösse: in Pixeln höchstens 90 % des Bildschirms -> Massstab verkleinern
    local sc = f:GetEffectiveScale() or 1
    local w, h = (f:GetWidth() or 0) * sc, (f:GetHeight() or 0) * sc
    if w > 0 and h > 0 then
        local k = math.min(1, self.SCREEN_SHARE * sw / w, self.SCREEN_SHARE * sh / h)
        if k < 0.999 then
            f:SetScale((f:GetScale() or 1) * k)
            changed = true
        end
    end
    -- 2. Position: ganz im Bildschirm
    local l, b, fw, fh = f:GetRect()
    if l and fw then
        sc = f:GetEffectiveScale() or 1
        local L_, B_, R_, T_ = l * sc, b * sc, (l + fw) * sc, (b + fh) * sc
        local dx = (L_ < 0) and -L_ or ((R_ > sw) and (sw - R_) or 0)
        local dy = (B_ < 0) and -B_ or ((T_ > sh) and (sh - T_) or 0)
        if dx ~= 0 or dy ~= 0 then
            f:ClearAllPoints()
            f:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", (L_ + dx) / sc, (B_ + dy) / sc)
            changed = true
        end
    end
    return changed
end
do
    local ev = CreateFrame("Frame")
    for _, e in ipairs({ "UI_SCALE_CHANGED", "DISPLAY_SIZE_CHANGED" }) do pcall(ev.RegisterEvent, ev, e) end
    ev:SetScript("OnEvent", function()
        if UI.frame then pcall(UI.FitToAH, UI); pcall(UI.EnsureOnScreen, UI) end
    end)
end

-- Fenstergröße zurück auf die Größe des Auktionshauses
function UI:ResetWindowSize()
    if A.db then A.db.settings.windowSize = nil end
    if self.frame then self.frame.fitW = nil end
    self:FitToAH()
end


-- ------------------------------------------------------------
-- Optionen (alles Wichtige an einem Ort)
-- ------------------------------------------------------------
UI.OPTION_LABEL_W = 148
function UI:ShowOptions()
    if not self.options then
        -- zwei Spalten, damit das Fenster auch auf kleineren Bildschirmen passt
        -- O1 (Befund Optionen überlagert, 10.11.): Zeilen aus dem Zähler - Spalte = (Zeile - 1) / COL_ROWS, beliebig viele
        -- Spalten; die Fensterbreite folgt der Zahl der Spalten (nie zwei Optionen auf derselben Stelle)
        local COL_ROWS, COL_W = 20, 430
        local w = self:Dialog("AHAnalyzerProOptions", 2 * COL_W - 10, 46 + COL_ROWS * 32 + 44, L["Optionen"])
        local rows = {}

        local function row(label)
            local index = #rows + 1
            local col = math.floor((index - 1) / COL_ROWS)
            local y = -46 - ((index - 1) % COL_ROWS) * 32
            local need = (col + 1) * COL_W - 10
            if (w:GetWidth() or 0) < need then w:SetWidth(need) end
            local x = col * COL_W
            local l = UI:Label(w, label, "GameFontHighlightSmall", C.text)
            -- feste Spaltenbreite bis zu den Knöpfen; lange Texte (Französisch, Spanisch, Russisch ...)
            -- brechen in eine zweite Zeile um, statt abgeschnitten zu werden oder unter die Knöpfe zu laufen
            l:SetPoint("TOPLEFT", x + 18, y + 2)
            l:SetSize(UI.OPTION_LABEL_W, 28)
            l:SetJustifyV("MIDDLE")
            if l.SetWordWrap then l:SetWordWrap(true) end
            if l.SetMaxLines then l:SetMaxLines(2) end
            if (l:GetStringWidth() or 0) > UI.OPTION_LABEL_W * 2 - 16 and GameFontHighlightExtraSmall then
                l:SetFontObject(GameFontHighlightExtraSmall)
            end
            w.optionLabels = w.optionLabels or {}
            table.insert(w.optionLabels, l)
            local r = { label = l, y = y, x = x }
            table.insert(rows, r)
            return r
        end

        -- Design
        local r = row(L["Design"])
        w.classicBtn = UI:Button(w, L["Klassisch"], 100, 24, function() UI:SetTheme("classic") end)
        w.classicBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.classicBtn.tooltip = L["Wie das WoW-Auktionshaus: Holz, Gold, rote Knöpfe, Reiter unten"]
        w.modernBtn = UI:Button(w, L["Modern"], 100, 24, function() UI:SetTheme("modern") end)
        w.modernBtn:SetPoint("LEFT", w.classicBtn, "RIGHT", 6, 0)
        w.modernBtn.tooltip = L["Flach und dunkel"]

        -- Im Auktionshaus-Fenster anzeigen
        r = row(L["Im Auktionshaus anzeigen"])
        w.ahBtn = UI:Button(w, "", 100, 24, function()
            UI:SetIntegration(A.db.settings.ahIntegration == false)
            if UI.options then UI.options:Refresh() end
        end)
        w.ahBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.ahBtn.tooltip = L["Das Addon als eigener Reiter im Auktionshaus-Fenster.\nBei geschlossenem Auktionshaus öffnet sich das eigene Fenster."]

        -- Item-Tooltip: Preiszeilen und Preisdiagramm
        r = row(L["Preis im Tooltip"])
        w.ttInfoBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.tooltipInfo = (A.db.settings.tooltipInfo == false)
            w:Refresh()
        end)
        w.ttInfoBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.ttInfoBtn.tooltip = L["Zeigt beim Überfahren eines Items Preis, Marktwert und Trend im Tooltip"]
        r = row(L["Preisverlauf im Tooltip"])
        w.ttChartBtn = UI:Button(w, "", 100, 24, function()
            A.Tooltip:CycleChartDays()
            w:Refresh()
        end)
        w.ttChartBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.ttChartBtn.tooltip = L["Zeigt beim Überfahren eines Items ein kleines Preisdiagramm unter dem Tooltip.\nKlick: Zeitraum wechseln (aus / 24 Std. / 7 Tage / 30 Tage)"]

        r = row(L["Händlerpreis im Tooltip"])
        w.ttVendorBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.tooltipVendor = (A.db.settings.tooltipVendor == false)
            w:Refresh()
        end)
        w.ttVendorBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.ttVendorBtn.tooltip = L["Zeigt im Item-Tooltip, was ein Händler für das Item zahlt"]

        r = row(L["Mehr im Tooltip"])
        w.ttCharsBtn = UI:Button(w, "", 112, 24, function()
            A.db.settings.tooltipChars = (A.db.settings.tooltipChars == false)
            w:Refresh()
        end)
        w.ttCharsBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.ttCharsBtn.tooltip = L["Wie viele Stück deine anderen Charaktere haben (Taschen und Bank)"]
        w.ttDEBtn = UI:Button(w, "", 112, 24, function()
            A.db.settings.tooltipDE = (A.db.settings.tooltipDE == false)
            w:Refresh()
        end)
        w.ttDEBtn:SetPoint("LEFT", w.ttCharsBtn, "RIGHT", 6, 0)
        w.ttDEBtn.tooltip = L["Erwarteter Wert beim Entzaubern (grüne, blaue, epische Ausrüstung)"]

        r = row(L["Mit dem Auktionshaus öffnen und schliessen"])
        w.openAHBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.openWithAH = (A.db.settings.openWithAH == false)
            w:Refresh()
        end)
        w.openAHBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.openAHBtn.tooltip = L["Öffnet das AHSentinel-Fenster, wenn du das Auktionshaus öffnest, und schliesst es wieder mit dem Auktionshaus.\nWar es vorher schon offen, bleibt es offen."]

        r = row(L["Entzauber-Details im Tooltip"])
        w.ttDEDetailBtn = UI:Button(w, "", 150, 24, function()
            local order = { short = "mats", mats = "all", all = "short" }
            local cur = A.Tooltip and A.Tooltip:DEMode() or "mats"
            A.db.settings.tooltipDEMode = order[cur] or "mats"
            A.db.settings.tooltipDEDetail = nil
            w:Refresh()
        end)
        w.ttDEDetailBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.ttDEDetailBtn.tooltip = L["kurz: nur \"Entzauberungswert\".\nmit Materialien: dazu je Material Chance und Preis.\nalles: die ganze Rechnung (tatsächlich und geschätzt).\nShift im Tooltip zeigt immer die ganze Rechnung."]

        r = row(L["Entzaubern gelernt"])
        w.deText = UI:Label(w, "", "GameFontHighlightSmall", C.text)
        w.deText:SetPoint("TOPLEFT", r.x + 170, r.y - 5)
        w.deText:SetWidth(110)
        w.deReset = UI:Button(w, L["Zurücksetzen"], 110, 24, function()
            -- N2: nichts gelernt, aber eine Sicherung da -> der Knopf holt sie zurück
            local D = A.Disenchant
            if (D:TotalLearned()) == 0 and A.db.deBackup and #A.db.deBackup > 0 then
                local ok, n = D:RestoreBackup()
                if ok then A:Print(string.format(L["Entzauber-Ergebnisse wiederhergestellt: %d"], n or 0)) end
                w:Refresh()
                return
            end
            if not w.deConfirm then
                -- Schutz der echten Entzauber-Daten: Rückfrage mit Anzahl, vorher Sicherung (D:Reset)
                w.deConfirm = true
                w.deReset:SetText(L["Wirklich?"])
                A:Print(string.format(L["Wirklich alle %d Entzauber-Ergebnisse löschen? Nochmals klicken. Vorher wird gesichert."],
                    (A.Disenchant:TotalLearned())))
                return
            end
            w.deConfirm = nil
            A.Disenchant:Reset()
            w:Refresh()
        end, "danger")
        w.deReset:SetPoint("TOPLEFT", r.x + 286, r.y)
        w.deReset.tooltip = L["Vergisst alle Entzauberungs-Ergebnisse (eigene und geteilte) - danach gelten wieder die Tabellenwerte, geteilte kommen beim nächsten Einloggen neu"]

        r = row(L["Knöpfe am Briefkasten"])
        w.mailBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.mailButtons = (A.db.settings.mailButtons == false)
            if A.Mailer and A.Mailer.buttons then A.Mailer.buttons:SetShown(A.db.settings.mailButtons ~= false) end
            w:Refresh()
        end)
        w.mailBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.mailBtn.tooltip = L["'AH-Post abholen' und 'Alles' am Briefkasten"]

        r = row(L["Meldung bei Verkauf"])
        w.saleBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.saleAlert = (A.db.settings.saleAlert == false)
            w:Refresh()
        end)
        w.saleBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.saleBtn.tooltip = L["Sobald eine deiner Auktionen verkauft ist: Meldung mit Erlös und Gewinn\n(gegenüber deinem Einkaufspreis) und ein Münzklang."]

        r = row(L["Preisschutz beim Einstellen"])
        w.guardBtn = UI:Button(w, "", 206, 24, function()
            if A.Seller then A.Seller:CycleGuard() end
            w:Refresh()
        end)
        w.guardBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.guardBtn.tooltip = L["Warnt vor dem Einstellen, wenn dein Preis weit unter dem Marktwert liegt\noder sich an einem auffällig billigen Einzelstück orientiert.\nDann ist ein zweiter Klick nötig; die Serie überspringt solche Items.\nKlick: Schwelle wechseln (aus / 20 / 30 / 40 / 50 %)."]

        r = row(A:IsForever() and L["Warnung AH-Gebühr"] or L["Warnung Einstellgebühr"])
        w.feeBtn = UI:Button(w, "", 206, 24, function()
            if A.Seller then A.Seller:CycleFeeWarn() end
            w:Refresh()
        end)
        w.feeBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.feeBtn.tooltip = L["Warnt beim Einstellen, wenn die Einstellgebühr mehr als diesen Anteil vom Preis ausmacht.\nDann ist ein zweiter Klick nötig.\nKlick: Schwelle wechseln (aus / 5 / 10 / 20 / 30 %)."]

        r = row(L["Unter Händlerpreis ab"])
        w.vflipBtn = UI:Button(w, "", 206, 24, function()
            local steps, cur = { 0, 500, 1000, 5000, 10000 }, A:VendorFlipMin()
            local idx = 1
            for i, v in ipairs(steps) do if v == cur then idx = i end end
            A.db.settings.vendorFlipMin = steps[idx % #steps + 1]
            w:Refresh()
        end)
        w.vflipBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.vflipBtn.tooltip = L["\"Heute tun\" zeigt Angebote unter dem Händlerpreis (kaufen und beim Händler verkaufen) erst ab diesem Gewinn je Angebot.\nKlick: wechseln (alle / 5s / 10s / 50s / 1g)."]

        r = row(L["Gewinn im Berufsfenster"])
        w.craftBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.craftPanel = (A.db.settings.craftPanel == false)
            if A.db.settings.craftPanel == false and A.Crafting and A.Crafting.panel then A.Crafting.panel:Hide() end
            w:Refresh()
        end)
        w.craftBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.craftBtn.tooltip = L["Zeigt neben dem Berufsfenster Materialkosten, Wert und Gewinn der Rezepte"]

        -- Sprache des Addons (Standard: wie der Client)
        r = row(L["Sprache des Addons"])
        w.uiLangBtn = UI:Button(w, "", 206, 24, function(self, button)
            A:CycleUILanguage(button == "RightButton" and -1 or 1)
            if UI.options then UI.options:Refresh() end
        end)
        if w.uiLangBtn.RegisterForClicks then w.uiLangBtn:RegisterForClicks("LeftButtonUp", "RightButtonUp") end
        w.uiLangBtn:SetPoint("TOPLEFT", r.x + 170, r.y)

        -- Sprache der Item-Namen
        r = row(L["Item-Namen anzeigen in"])
        w.langBtn = UI:Button(w, "", 206, 24, function(self, button)
            A.Names:CycleDisplayLocale(button == "RightButton" and -1 or 1)
            w:Refresh()
        end)
        if w.langBtn.RegisterForClicks then w.langBtn:RegisterForClicks("LeftButtonUp", "RightButtonUp") end
        w.langBtn:SetPoint("TOPLEFT", r.x + 170, r.y)

        -- Geldanzeige: Münzsymbole oder Buchstaben
        r = row(L["Geldanzeige"])
        w.moneyBtn = UI:Button(w, "", 206, 24, function()
            local s = A.db.settings
            s.moneyStyle = (s.moneyStyle == "letters") and "icons" or "letters"
            w:Refresh()
            UI:RefreshActive()
        end)
        w.moneyBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.moneyBtn.tooltip = L["Gold, Silber und Kupfer als WoW-Münzsymbole oder als Buchstaben"]

        -- D1 (Wunsch 07:25): Standard-Laufzeit beim Einstellen (Stufe 1/2/3, Beschriftung aus dem Spiel), Standard Stufe 1
        r = row(L["Standard-Laufzeit"])
        w.durationBtn = UI:Button(w, "", 160, 24, function()
            local d = A:StandardDurationStep()
            A.db.settings.defaultDuration = (d % 3) + 1
            if A.ResetOutlook then A:ResetOutlook() end
            A:Fire("SETTINGS_CHANGED")
            w:Refresh()
        end)
        w.durationBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.durationBtn.tooltip = L["So lange laufen deine Auktionen, wenn du nichts anderes wählst (Verkaufen, Serie, Neu einstellen, Heute tun). Auch die Rechnungen (Einzahlung, Absatz) nehmen sie."]

        -- Befehlsliste beim Tippen von /ahs (CmdHint.lua, Anweisung L7)
        r = row(L["Befehlsliste beim Tippen"])
        w.cmdHintBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.cmdHint = (A.db.settings.cmdHint == false)
            if A.db.settings.cmdHint == false and A.CmdHint then A.CmdHint:Hide() end
            w:Refresh()
        end)
        w.cmdHintBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.cmdHintBtn.tooltip = L["Tippst du im Chat /ahs, erscheinen darüber alle Befehle - die meistbenutzten oben. Klick führt den Befehl aus."]

        -- Schnell-Vollscan (Vollscan.lua V2): der Scan-Knopf liest alle Einzelauktionen (nur modernes Auktionshaus)
        r = row(L["Schnell-Vollscan"])
        w.fastScanBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.fastScan = not A.db.settings.fastScan
            w:Refresh()
        end)
        w.fastScanBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.fastScanBtn.tooltip = L["Der Scan-Knopf liest alle Einzelauktionen auf einmal (mit Restzeit). Damit misst AHSentinel den echten Absatz und die Warteschlange zu deinem Preis. Höchstens alle 15 Minuten; nur im modernen Auktionshaus."]

        -- Stufe 2: Lern-Datenbank (Learn.lua) - Standard an; Ausprobieren Standard aus; Tagesbudget je Strategie
        r = row(L["Lernen"])
        w.learnBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.learn = (A.db.settings.learn == false)
            if A.ResetOutlook then A:ResetOutlook() end
            w:Refresh()
        end)
        w.learnBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.learnBtn.tooltip = L["AHSentinel lernt im Hintergrund aus deinen Verkäufen, Käufen und Entzauberungen (Verkaufschance je Preis, Preisgrenzen, Sicherheitsmarge beim Kaufen). Aus: Rechnungen wie ohne Lernen."]
        r = row(L["Ausprobieren (+5 %)"])
        w.exploreBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.learnExplore = not A.db.settings.learnExplore
            w:Refresh()
        end)
        w.exploreBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.exploreBtn.tooltip = L["Jede 10. Einstellung schlägt 5 % mehr vor, um zu lernen, ob ein höherer Preis noch verkauft. Kann einzelne Verkäufe kosten."]
        r = row(L["Tagesbudget je Strategie"])
        w.budgetBtn = UI:Button(w, "", 100, 24, function()
            local cur = A.db.settings.learnBudget
            local steps = { 5, 10, 20, 25, 0 }
            local idx = 4
            for i, v in ipairs(steps) do if v == (cur == nil and 25 or cur) then idx = i end end
            A.db.settings.learnBudget = steps[idx % #steps + 1]
            w:Refresh()
        end)
        w.budgetBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.budgetBtn.tooltip = L["Solange eine Kauf-Strategie (Entzaubern, Flip, Händler) weniger als 60 % Treffer hat, gibt sie am Tag höchstens so viel deines Golds aus (Wächter, Sammelkauf, Heute tun)."]

        -- K1 (Entscheid 10.11.): Markt rechnet höchstens mit X % des Golds (Zahl, Standard 25, nie über 50)
        r = row(L["Markt: höchstens % des Golds"])
        w.capitalBox = UI:EditBox(w, 60, 24, "25")
        w.capitalBox:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.capitalBox:SetMaxLetters(3)
        local function applyCapital(self)
            local p = A:SetMarketCapitalPct(self:GetText())
            self:SetText(tostring(p))
            self:ClearFocus()
        end
        w.capitalBox:SetScript("OnEnterPressed", applyCapital)
        w.capitalBox:HookScript("OnEditFocusLost", function(self) self:SetText(tostring(A:MarketCapitalPct())) end)
        w.capitalBox.tooltip = L["Alle Kaufvorschläge im Markt (Heute, Flippen, Händler, Lücken) zusammen höchstens so viel Prozent deines Golds. Standard 25 %, höchstens 50 %. Eingabe mit Enter bestätigen."]
        w.capitalBox:SetScript("OnEnter", function(self)
            UI:AnchorTooltip(self); GameTooltip:SetText(self.tooltip, 1, 1, 1, 1, true); GameTooltip:Show()
        end)
        w.capitalBox:SetScript("OnLeave", function() GameTooltip:Hide() end)

        -- E4b (Entscheid 10.11. 16:15): Mindestgewinn der Ansicht "Entzaubern" (Standard 20 %, 10–50 %)
        r = row(L["Entzaubern: Mindestgewinn %"])
        w.deMinBox = UI:EditBox(w, 60, 24, "20")
        w.deMinBox:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.deMinBox:SetMaxLetters(3)
        w.deMinBox:SetScript("OnEnterPressed", function(self)
            local MV = A.MarketView
            local p = MV and MV:SetDEMinPct(self:GetText()) or 20
            self:SetText(tostring(p))
            self:ClearFocus()
        end)
        w.deMinBox:HookScript("OnEditFocusLost", function(self) if A.MarketView then self:SetText(tostring(A.MarketView:DEMinPct())) end end)
        w.deMinBox.tooltip = L["Markt -> Entzaubern zeigt nur Teile mit mindestens so viel Gewinn nach dem Entzaubern (nach Gebühren). Standard 20 %, 10–50 %. Mit Enter bestätigen."]
        w.deMinBox:SetScript("OnEnter", function(self)
            UI:AnchorTooltip(self); GameTooltip:SetText(self.tooltip, 1, 1, 1, 1, true); GameTooltip:Show()
        end)
        w.deMinBox:SetScript("OnLeave", function() GameTooltip:Hide() end)

        -- Stufe 3 M6: einzige neue Option des Markt-Reiters
        r = row(L["Markt: Standard-Ansicht"])
        w.marketViewBtn = UI:Button(w, "", 120, 24, function()
            local MV = A.MarketView
            if not MV then return end
            local cur, idx = MV:DefaultView(), 1
            for i, v in ipairs(MV.VIEWS) do if v == cur then idx = i end end
            A.db.settings.marketView = MV.VIEWS[idx % #MV.VIEWS + 1]
            w:Refresh()
        end)
        w.marketViewBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.marketViewBtn.tooltip = L["Welche Ansicht der Markt-Reiter beim Öffnen zeigt (Standard: Heute)."]

        -- Fenstergröße
        r = row(L["Fenstergröße"])
        w.scaleDown = UI:Button(w, "-", 28, 24, function() UI:SetScale((A.db.settings.scale or 1) - 0.05); w:Refresh() end)
        w.scaleDown:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.scaleText = UI:Label(w, "", "GameFontHighlight", C.text)
        w.scaleText:SetPoint("LEFT", w.scaleDown, "RIGHT", 10, 0)
        w.scaleText:SetWidth(50); w.scaleText:SetJustifyH("CENTER")
        w.scaleUp = UI:Button(w, "+", 28, 24, function() UI:SetScale((A.db.settings.scale or 1) + 0.05); w:Refresh() end)
        w.scaleUp:SetPoint("LEFT", w.scaleText, "RIGHT", 10, 0)
        w.scaleDown.tooltip = L["Größe von Optionen, Hilfe und Listen.\nDas Hauptfenster ist immer so groß wie das Auktionshaus."]
        w.scaleUp.tooltip = w.scaleDown.tooltip

        -- Größe des Addons im Auktionshaus (Schrift und alles andere wächst mit)
        r = row(L["Schrift- und Inhaltsgröße"])
        w.zoomDown = UI:Button(w, "-", 28, 24, function() UI:SetAHZoom(UI:AHZoom() - 0.1); w:Refresh() end)
        w.zoomDown:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.zoomText = UI:Label(w, "", "GameFontHighlight", C.text)
        w.zoomText:SetPoint("LEFT", w.zoomDown, "RIGHT", 10, 0)
        w.zoomText:SetWidth(50); w.zoomText:SetJustifyH("CENTER")
        w.zoomUp = UI:Button(w, "+", 28, 24, function() UI:SetAHZoom(UI:AHZoom() + 0.1); w:Refresh() end)
        w.zoomUp:SetPoint("LEFT", w.zoomText, "RIGHT", 10, 0)
        w.zoomDown.tooltip = L["Größere Schrift und Inhalte im Addon-Fenster.\nDie Fenstergröße selbst ziehst du an der Ecke unten rechts.\n(Im Auktionshaus eingebettet ragt das Addon dann über das Auktionshaus hinaus.)"]
        w.zoomUp.tooltip = w.zoomDown.tooltip

        -- Ton
        r = row(L["Ton bei Treffern und Alarmen"])
        w.soundBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.alertSound = not A.db.settings.alertSound
            w:Refresh()
        end)
        w.soundBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        -- SG4: Signal bei Sniper-Treffer (an/aus) und Farbe - in derselben Zeile, keine neue Zeile (UICheck K)
        w.signalBtn = UI:Button(w, "", 110, 24, function()
            A.db.settings.sniperSignal = (A.db.settings.sniperSignal == false)
            w:Refresh()
        end)
        w.signalBtn:SetPoint("LEFT", w.soundBtn, "RIGHT", 6, 0)
        w.signalBtn.tooltip = L["Signal bei Sniper-Treffer: der Bildschirmrand leuchtet kurz auf (wie bei wenig Leben)."]
        w.signalColorBtn = UI:Button(w, "", 70, 24, function()
            A.Sniper:CycleSignalColor()
            w:Refresh()
        end)
        w.signalColorBtn:SetPoint("LEFT", w.signalBtn, "RIGHT", 6, 0)
        w.signalColorBtn.tooltip = L["Farbe des Signals (Gold, Grün, Blau)"]

        -- Sync
        r = row(L["Preise mit Mitspielern teilen"])
        w.syncBtn = UI:Button(w, "", 100, 24, function()
            if A.Sync then A.Sync:Toggle() end
            w:Refresh()
        end)
        w.syncBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.syncBtn.tooltip = L["Nach jedem Scan werden deine Preise an alle Spieler mit diesem Addon verteilt,\nund du bekommst ihre."]
        w.syncGuildBtn = UI:Button(w, "", 100, 24, function()
            if A.Sync then A.Sync:SetGuildOnly(not A.Sync:GuildOnly()) end
            w:Refresh()
        end)
        w.syncGuildBtn:SetPoint("LEFT", w.syncBtn, "RIGHT", 6, 0)
        w.syncGuildBtn.tooltip = L["Mit wem geteilt wird: Gilde und Gruppe oder nur deine Gilde.\n(Eigene Kanäle gehen in WoW Forever nicht - geteilt wird nur über Gilde und Gruppe.)"]

        -- Sniper-Tempo
        r = row(L["Sniper sucht alle"])
        w.snipeDown = UI:Button(w, "-", 28, 24, function()
            A.db.sniper.interval = math.max(0, (A.db.sniper.interval or 0) - 1); w:Refresh()
        end)
        w.snipeDown:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.snipeText = UI:Label(w, "", "GameFontHighlight", C.text)
        w.snipeText:SetPoint("LEFT", w.snipeDown, "RIGHT", 10, 0)
        w.snipeText:SetWidth(50); w.snipeText:SetJustifyH("CENTER")
        w.snipeUp = UI:Button(w, "+", 28, 24, function()
            A.db.sniper.interval = math.min(30, (A.db.sniper.interval or 0) + 1); w:Refresh()
        end)
        w.snipeUp:SetPoint("LEFT", w.snipeText, "RIGHT", 10, 0)

        -- Kauf-Taste für Sniper und Wächter (Standard: Mausrad)
        local function keyRow(label, kind)
            local rr = row(label)
            local wheel = UI:Button(w, L["Mausrad"], 80, 24, function()
                A.Sniper:UseMouseWheel(kind); w:Refresh()
            end)
            wheel:SetPoint("TOPLEFT", rr.x + 170, rr.y)
            wheel.tooltip = L["Mausrad als Auslöser (beide Richtungen)"]
            local own = UI:Button(w, L["Eigene Taste"], 104, 24, function()
                if A.UI.OpenKeyCapture then
                    A.UI.OpenKeyCapture(function(key)
                        A.Sniper:SetBinds(A.UI.KeyToBinds(key), kind)
                        if UI.options then UI.options:Refresh() end
                    end)
                end
            end)
            own:SetPoint("LEFT", wheel, "RIGHT", 6, 0)
            own.tooltip = L["Eigene Taste oder Maustaste als Auslöser wählen"]
            local txt = UI:Label(w, "", "GameFontHighlightSmall", C.accent)
            txt:SetPoint("TOPLEFT", rr.x + 18, rr.y - 19)
            txt:SetWidth(150)
            return txt
        end
        w.snKeyText = keyRow(L["Sniper kauft mit"], "sniper")
        w.wKeyText = keyRow(L["Wächter kauft mit"], "watcher")

        -- Tagesbilanz, Händler-Knopf, Post an Twinks
        r = row(L["Tagesbilanz beim Einloggen"])
        w.dailyBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.dailySummary = (A.db.settings.dailySummary == false)
            w:Refresh()
        end)
        w.dailyBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.dailyBtn.tooltip = L["Einmal am Tag beim Einloggen: Gewinn von gestern, letzte 7 Tage,\nGold aller Charaktere und was zum Neu-Einstellen wartet (auch: /ahs bilanz)."]
        w.dailyNow = UI:Button(w, L["Jetzt zeigen"], 100, 24, function()
            if A.Extras then A.Extras:ShowDailySummary(true) end
        end)
        w.dailyNow:SetPoint("LEFT", w.dailyBtn, "RIGHT", 6, 0)

        r = row(L["Knopf beim Händler"])
        w.vendorBtn = UI:Button(w, "", 100, 24, function()
            -- immer ausdrücklich speichern (ohne Einstellung hängt "an/aus" davon ab, ob LevelPilot graue Items verkauft)
            A.db.settings.vendorButton = not UI:VendorButtonEnabled()
            if UI.UpdateVendorButton then UI:UpdateVendorButton() end
            w:Refresh()
        end)
        w.vendorBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.vendorBtn.tooltip = L["Beim Händler: Knopf, der Schrott und alles verkauft,\nwas beim Händler mehr bringt als im Auktionshaus."]

        r = row(L["Post an Twinks"])
        w.rulesBtn = UI:Button(w, L["Regeln festlegen"], 206, 24, function() UI:ShowMailRules() end)
        w.rulesBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.rulesBtn.tooltip = L["Welche Waren an welchen Twink? Verschickt wird am Briefkasten mit dem Knopf 'An Twinks'."]

        r = row(L["Knopf an der Minikarte"])
        w.minimapBtn = UI:Button(w, "", 100, 24, function()
            A:SetMinimapButtonShown(A.db.settings.minimapHide and true or false)
            w:Refresh()
        end)
        w.minimapBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.minimapBtn.tooltip = L["Runder Knopf an der Minikarte - mit der Maus rund um die Minikarte ziehen.\nLinksklick: Fenster, Rechtsklick: Markt scannen."]

        -- Komfort
        r = row(L["Post automatisch abholen"])
        w.autoMailBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.autoCollect = (A.db.settings.autoCollect == false)
            w:Refresh()
        end)
        w.autoMailBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.autoMailBtn.tooltip = L["Beim Öffnen des Briefkastens wird die Auktionspost gleich abgeholt.\nShift beim Öffnen gedrückt halten = diesmal nicht."]

        r = row(L["Alt-Klick auf ein Item"])
        w.altClickBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.altClick = (A.db.settings.altClick == false)
            w:Refresh()
        end)
        w.altClickBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.altClickBtn.tooltip = L["Alt-Klick auf ein Item in den Taschen oder einen Link im Chat:\nöffnet den Preisverlauf - bei offenem Auktionshaus den Einkauf."]

        r = row(L["Verkaufschance im Tooltip"])
        w.chanceBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.tooltipChance = (A.db.settings.tooltipChance == false)
            w:Refresh()
        end)
        w.chanceBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.chanceBtn.tooltip = L["Aus deiner Buchhaltung (60 Tage): wie viel von dem, was du eingestellt hast,\nverkauft wurde und wie lange es meist gedauert hat. Ab 3 eingestellten Stück."]

        r = row(L["Ablauf-Erinnerung"])
        w.expiryBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.expiryReminder = (A.db.settings.expiryReminder == false)
            w:Refresh()
        end)
        w.expiryBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.expiryBtn.tooltip = L["Meldung, wenn eigene Auktionen in weniger als 30 Min. ablaufen,\nund beim Einloggen, was seit dem letzten Besuch abgelaufen ist."]

        r = row(L["Gold-Ziel (alle Charaktere)"])
        w.goalBox = UI:EditBox(w, 100, 24, L["Gold"])
        w.goalBox:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.goalBox:SetScript("OnEnterPressed", function(self)
            self:ClearFocus()
            local g = tonumber(((self:GetText() or ""):gsub("[%.' ]", ""):gsub(",", ".")))
            A.Comfort:SetGoldGoal(g and g * 10000 or nil)
            w:Refresh()
        end)
        w.goalSet = UI:Button(w, L["Setzen"], 100, 24, function()
            local g = tonumber(((w.goalBox:GetText() or ""):gsub("[%.' ]", ""):gsub(",", ".")))
            A.Comfort:SetGoldGoal(g and g * 10000 or nil)
            w.goalBox:ClearFocus()
            w:Refresh()
        end)
        w.goalSet:SetPoint("LEFT", w.goalBox, "RIGHT", 6, 0)
        w.goalSet.tooltip = L["Meldung mit Ton, sobald alle Charaktere zusammen so viel Gold haben.\nLeer lassen und 'Setzen' = Ziel löschen. Auch: /ahs ziel 5000"]
        w.goalText = UI:Label(w, "", "GameFontHighlightSmall", C.accent)
        w.goalText:SetPoint("TOPLEFT", r.x + 18, r.y - 19)
        w.goalText:SetWidth(150)

        r = row(L["Selbsttest"])
        w.selfTestBtn = UI:Button(w, L["Test öffnen"], 206, 24, function() A.SelfTest:ShowWindow() end)
        w.selfTestBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.selfTestBtn.tooltip = L["Prüft alle Funktionen mit echten Daten aus dem Auktionshaus (Scan, Reiter, Suchen).\nKauft und stellt nichts ein. Auch: /ahs test"]
        -- nur für den Entwickler
        if not A:IsDev() then r.label:Hide(); w.selfTestBtn:Hide() end

        -- Daten
        r = row(L["Daten"])
        w.exportBtn = UI:Button(w, L["CSV-Export"], 100, 24, function() A:ExportCSV() end)
        w.exportBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.exportBtn.tooltip = L["Alle Preise als Text zum Kopieren (z.B. für Excel)"]
        w.resetBtn = UI:Button(w, L["Positionen"], 100, 24, function()
            if A.ResetButtonPosition then A:ResetButtonPosition() end
            UI:ResetPosition()
        end)
        w.resetBtn:SetPoint("LEFT", w.exportBtn, "RIGHT", 6, 0)

        r = row(L["Addon unterstützen"])
        w.donateBtn = UI:Button(w, L["Unterstützen"], 206, 24, function() UI:ShowDonate() end, "primary")
        w.donateBtn:SetPoint("TOPLEFT", r.x + 170, r.y)
        w.donateBtn.tooltip = L["AHSentinel mit einer Spende unterstützen (PayPal)"]
        w.resetBtn.tooltip = L["Fenster und Münz-Button wieder in die Bildschirmmitte"]

        local hint = UI:Label(w, L["Chat-Befehle: /ahs, /ahs scan, /ahs sniper, /ahs design, /ahs debug"], "GameFontDisableSmall", C.textDim)
        hint:SetPoint("BOTTOMLEFT", 18, 14)

        function w:Refresh()
            local s = A.db.settings
            self.classicBtn:SetText(UI.theme == "classic" and L["> Klassisch <"] or L["Klassisch"])
            self.modernBtn:SetText(UI.theme == "modern" and L["> Modern <"] or L["Modern"])
            self.scaleText:SetText(math.floor((s.scale or 1) * 100 + 0.5) .. " %")
            self.zoomText:SetText(math.floor(UI:AHZoom() * 100 + 0.5) .. " %")
            self.soundBtn:SetText(s.alertSound and L["an"] or L["aus"])
            self.signalBtn:SetText(L["Signal"] .. ": " .. ((s.sniperSignal ~= false) and L["an"] or L["aus"]))
            self.signalColorBtn:SetText(L[A.Sniper.SIGNAL_LABELS[A.Sniper:SignalColorKey()]])
            self.syncBtn:SetText((A.Sync and A.Sync:IsEnabled()) and L["an"] or L["aus"])
            self.snKeyText:SetText(A.Sniper:GetBindsText("sniper"))
            self.wKeyText:SetText(A.Sniper:GetBindsText("watcher"))
            local si = A.db.sniper.interval or 0
            self.snipeText:SetText(si <= 0 and L["max."] or (si .. L[" Sek."]))
            self.snipeDown.tooltip = L["max. = so oft, wie der Server Suchen erlaubt"]
            self.snipeUp.tooltip = self.snipeDown.tooltip
            local N = A.Names
            self.uiLangBtn:SetText(A:UILanguageLabel())
            self.ahBtn:SetText((s.ahIntegration ~= false) and L["an"] or L["aus"])
            self.ttInfoBtn:SetText((s.tooltipInfo ~= false) and L["an"] or L["aus"])
            self.ttChartBtn:SetText(A.Tooltip:PeriodLabel())
            self.ttVendorBtn:SetText((s.tooltipVendor ~= false) and L["an"] or L["aus"])
            if self.cmdHintBtn then self.cmdHintBtn:SetText((s.cmdHint ~= false) and L["an"] or L["aus"]) end
            if self.marketViewBtn and A.MarketView then self.marketViewBtn:SetText(L[A.MarketView.LABELS[A.MarketView:DefaultView()]]) end
            if self.learnBtn then self.learnBtn:SetText((s.learn ~= false) and L["an"] or L["aus"]) end
            if self.exploreBtn then self.exploreBtn:SetText(s.learnExplore and L["an"] or L["aus"]) end
            if self.capitalBox and not self.capitalBox:HasFocus() then self.capitalBox:SetText(tostring(A:MarketCapitalPct())) end
            if self.deMinBox and A.MarketView and not self.deMinBox:HasFocus() then self.deMinBox:SetText(tostring(A.MarketView:DEMinPct())) end
            if self.budgetBtn then
                local b = s.learnBudget == nil and A:MarketCapitalPct() or math.min(s.learnBudget, A:MarketCapitalPct())
                self.budgetBtn:SetText(b == 0 and L["aus"] or (b .. " %"))
            end
            if self.fastScanBtn then
                local avail = A.FullScan and A.FullScan:Available()
                self.fastScanBtn:SetText(not avail and L["nicht verfügbar"] or (s.fastScan and L["an"] or L["aus"]))
            end
            if self.durationBtn and A.Seller then self.durationBtn:SetText(A.Seller:DurationLabel(A:StandardDurationStep())) end
            self.craftBtn:SetText((s.craftPanel ~= false) and L["an"] or L["aus"])
            self.ttCharsBtn:SetText(L["Twinks: "] .. ((s.tooltipChars ~= false) and L["an"] or L["aus"]))
            self.ttDEBtn:SetText(L["Entzaub.: "] .. ((s.tooltipDE ~= false) and L["an"] or L["aus"]))
            self.openAHBtn:SetText((s.openWithAH ~= false) and L["an"] or L["aus"])
            local dm = A.Tooltip and A.Tooltip:DEMode() or "mats"
            self.ttDEDetailBtn:SetText(({ short = L["kurz"], mats = L["mit Materialien"], all = L["alles"] })[dm])
            self.mailBtn:SetText((s.mailButtons ~= false) and L["an"] or L["aus"])
            self.saleBtn:SetText((s.saleAlert ~= false) and L["an"] or L["aus"])
            self.dailyBtn:SetText((s.dailySummary ~= false) and L["an"] or L["aus"])
            self.vendorBtn:SetText(UI:VendorButtonEnabled() and L["an"] or L["aus"])
            self.syncGuildBtn:SetText((A.Sync and A.Sync:GuildOnly()) and L["nur Gilde"] or L["alle"])
            self.autoMailBtn:SetText((s.autoCollect ~= false) and L["an"] or L["aus"])
            self.minimapBtn:SetText((not s.minimapHide) and L["an"] or L["aus"])
            self.altClickBtn:SetText((s.altClick ~= false) and L["an"] or L["aus"])
            self.chanceBtn:SetText((s.tooltipChance ~= false) and L["an"] or L["aus"])
            self.expiryBtn:SetText((s.expiryReminder ~= false) and L["an"] or L["aus"])
            if not self.goalBox:HasFocus() then
                self.goalBox:SetText(s.goldGoal and tostring(math.floor(s.goldGoal / 10000)) or "")
                if self.goalBox.UpdatePlaceholder then self.goalBox:UpdatePlaceholder() end
            end
            local _, _, pct = A.Comfort:GoldProgress()
            self.goalText:SetText(pct and string.format(L["erreicht: %d %%"], math.floor(pct)) or "")
            local gp = A.Seller and A.Seller:GuardPercent() or 0
            self.guardBtn:SetText(gp > 0 and string.format(L["ab %d %% unter Marktwert"], gp) or L["aus"])
            local fp = A.Seller and A.Seller:FeeWarnPercent() or 0
            self.feeBtn:SetText(fp > 0 and string.format(L["ab %d %% vom Preis"], fp) or L["aus"])
            local vm = A:VendorFlipMin()
            self.vflipBtn:SetText(vm > 0 and string.format(L["ab %s Gewinn"], A:FormatMoney(vm)) or L["alle"])
            local deN, deG = A.Disenchant:TotalLearned()
            local shN = A.Disenchant:TotalShared()
            self.deText:SetText(shN > 0 and string.format(L["%d (+%d geteilt)"], deN, shN) or string.format(L["%d in %d Gruppen"], deN, deG))
            if not self.deConfirm then
                local canRestore = A.Disenchant and (A.Disenchant:TotalLearned()) == 0 and A.db.deBackup and #A.db.deBackup > 0
                self.deReset:SetText(canRestore and L["Wiederherstellen"] or L["Zurücksetzen"])
            end
            self.moneyBtn:SetText(((s.moneyStyle == "letters") and L["Buchstaben"] or L["Münzsymbole"]) .. ":  " .. A:FormatMoney(123456))
            local loc = N:DisplayLocale()
            self.langBtn:SetText(N:LocaleLabel(N:DisplaySetting()) .. " (" .. N:CountNames(loc) .. ")")
            local lines = { L["Linksklick: nächste Sprache, Rechtsklick: vorige"], "",
                L["Gesucht wird immer in ALLEN Sprachen."], L["Bekannte Namen:"] }
            for _, l in ipairs(N.LOCALES) do
                local c = N:CountNames(l.code)
                local mark = (l.code == N:ClientLocale()) and L["  (dein Client)"] or ""
                table.insert(lines, "  " .. N:LocaleLabel(l.code) .. ": " .. c .. mark)
            end
            table.insert(lines, "")
            table.insert(lines, L["Eingebaute Namensliste: rund 23.000 Items (Quelle: QuestieDB,"])
            table.insert(lines, L["wow-classic-items - siehe Data/QUELLEN.txt). Fehlende Namen lernt"])
            table.insert(lines, L["das Addon aus deinem Client und über den Preis-Sync von Mitspielern."])
            table.insert(lines, L["Unbekannte Namen werden in deiner Client-Sprache gezeigt."])
            table.insert(lines, L["Russisch/Koreanisch/Chinesisch braucht passende Schriftarten im Client."])
            self.langBtn.tooltip = table.concat(lines, "\n")
        end
        w:SetScript("OnShow", function(self) self:Refresh() end)
        self.options = w
    end
    self.options:Show()
    self.options:Refresh()
end

function UI:ToggleOptions()
    if self.options and self.options:IsShown() then self.options:Hide() else self:ShowOptions() end
end

-- ------------------------------------------------------------
-- Hilfe (kurz, pro Tab)
-- ------------------------------------------------------------
UI.HELP_DE = {
    start = {
        "Willkommen bei AHSentinel",
        "So einfach geht's:\n\n"
        .. "1.  Auktionshaus öffnen und unten auf |cffffd100Markt scannen|r klicken.\n"
        .. "     (Der Server erlaubt einen Scan alle 15 Minuten.)\n\n"
        .. "2.  Oben 5 Reiter: Übersicht, Kaufen, Verkaufen, Markt, Buchhaltung -\n"
        .. "     darin Unterreiter. Sniper und Wächter schaltest du in der Kopfzeile an und aus.\n\n"
        .. "3.  Items findest du per |cffffd100Name in jeder Sprache|r (Teile reichen,\n"
        .. "     Umlaute egal), per Item-ID oder per |cffffd100Shift-Klick|r auf ein Item.\n\n"
        .. "4.  |cffffd100Rechtsklick auf ein Item|r: Preisverlauf, Watchlist,\n"
        .. "     Sniper-Ziel oder im Auktionshaus suchen.\n\n"
        .. "5.  Unter |cffffd100Kaufen -> Sniper|r Ziele eintragen, Sniper-Modus an -\n"
        .. "     eine Mausrad-Raste kauft das nächste passende Angebot (Waren in WoW Forever: 2 Rasten).\n\n"
        .. "Design (Klassisch/Modern), Fenstergröße, Ton und mehr: |cffffd100Optionen|r oben.\n"
        .. "Diese Hilfe gibt es jederzeit über den Knopf |cffffd100?|r",
    },
    overview = {
        "Übersicht",
        "Die wichtigsten Zahlen auf einen Blick: Anzahl Items, letzter und nächster Scan,\n"
        .. "aktive Watchlist-Alarme sowie die größten Preisanstiege und -rückgänge.\n\n"
        .. "Trends brauchen mindestens zwei Scans.\n"
        .. "Klick auf ein Item öffnet den Preisverlauf, Rechtsklick zeigt alle Optionen.",
    },
    market = {
        "Markt",
        [[
Alle gescannten Items mit aktuellem Preis, Marktwert und Trend.

- |cffffd100Marktwert|r = Median der Preise der letzten 14 Tage
  (einzelne Ausreißer zählen kaum).
- |cffffd100% Markt|r: aktueller Preis im Verhältnis zum Marktwert.
  Grün = günstig, Orange/Rot = teuer.
- Oben suchen: Name in jeder Sprache, Teil reicht, Umlaute egal.
  Auch Item-ID oder Shift-Klick auf ein Item geht.
- Spaltenkopf anklicken = sortieren.
- |cffffd100+|r setzt das Item auf die Watchlist.
- Rechtsklick: Preisverlauf, Sniper-Ziel, Einkaufsliste, im Auktionshaus suchen.]],
    },
    marketview = { "Markt", [[
Der Markt zeigt, was sich jetzt lohnt - in 6 Ansichten:
- |cffffd100Heute|r: deine Sachen zuerst, darunter die besten Chancen.
- |cffffd100Flippen|r: unter deiner Kaufgrenze kaufen und wieder einstellen.
- |cffffd100Händler|r: Sofortkauf unter dem Händlerpreis.
- |cffffd100Lücken|r: wenig Angebot, stetiger Absatz, Preis steigt.
- |cffffd100Überfüllt|r: lieber nicht einstellen.
- |cffffd100Trends|r: stabile Bewegungen über 7 und 30 Tage.
Der Knopf rechts macht immer den nächsten Schritt (Prüfen -> Kaufen -> Einstellen),
nie ohne deinen Klick. Klick auf eine Zeile: Details rechts mit EINER Empfehlung.
Suche oben: jedes Item nachschlagen. Oben links: Preis-Index typischer Waren.]] },
    watchlist = {
        "Watchlist",
        "Items beobachten und benachrichtigt werden.\n"
        .. "Item per Name (jede Sprache, Vorschläge erscheinen beim Tippen), ID\n"
        .. "oder Shift-Klick auf ein Item eintragen.\n\n"
        .. "- |cffffd100Kaufen unter|r: Meldung, wenn der Preis darunter fällt.\n"
        .. "- |cffffd100Verkaufen über|r: Meldung, wenn der Preis darüber steigt.\n"
        .. "Preise in Gold, z.B. 12.5 oder 12g 50s.\n"
        .. "Geprüft wird nach jedem Scan (auch mit Preisen von Mitspielern).",
    },
    sniper = {
        "Sniper",
        "1.  Item (Name in jeder Sprache, ID oder Shift-Klick) oder Suchwort,\n"
        .. "     |cffffd100Max-Preis pro Stück|r, |cffffd100Menge|r und\n"
        .. "     |cffffd100Budget|r eintragen. Menge leer = 1, Budget leer = Menge x Max-Preis.\n"
        .. "     Unter |cffffd100Filter|r: Seltenheit (Grau bis Episch), Itemlevel und Stufe.\n\n"
        .. "2.  Auktionshaus offen lassen und |cffffd100Sniper-Modus: AN|r.\n"
        .. "     Der Sniper sucht deine Ziele selbstständig der Reihe nach.\n\n"
        .. "3.  Bei einem Treffer: |cffffd100Mausrad drehen|r (hoch oder runter) = kaufen.\n"
        .. "     Handelswaren in WoW Forever: 1. Raste reserviert den Preis, 2. Raste kauft (sonst oft eine Raste).\n"
        .. "     Statt Mausrad geht auch eine eigene Taste.\n\n"
        .. "Gekauft wird nur mit deinem Mausrad / deiner Taste - nie ohne dich.\n"
        .. "Das Mausrad kauft nur, wenn die Maus über der Spielwelt ist (nicht über Fenstern).\n\n" .. "|cffffd100Einkaufslisten|r (Knopf oben): Items mit Mengen sammeln und mit einem Klick als Sniper-Ziele anlegen.",
    },
    charts = {
        "Charts",
        [[
Preisverlauf eines Items über die Zeit.

Item links auswählen oder irgendwo per Rechtsklick > Preisverlauf.
Punkte von Mitspielern (Preis-Sync) sind im Tooltip markiert.
|cffffd100Graue Punkte|r = unbestätigt (vermutlich Lockangebot) - zählen nicht.

|cffffd100EMA|r (Knopf oben) - gleitende Durchschnitte über die Zeit:
- blau = 6 Stunden, orange = 1 Tag, lila = 7 Tage
- nur echte Preise (ohne Lockangebote), ab 10 Preisen
Grüner Punkt: die 1-Tages-EMA steigt über die 7-Tages-EMA (Preis zieht an).
Roter Punkt: sie fällt darunter (Preis gibt nach).]],
    },
    profit = {
        "Profit",
        [[
Flipping-Rechner: Einkaufspreis, Verkaufspreis und Menge eintragen -
der Gewinn nach Auktionshaus-Gebühr wird sofort berechnet.

Schnäppchen in zwei Ansichten:
- |cffffd100Unter Marktwert|r: Items deutlich unter ihrem Marktwert
  (Median 14 Tage). |cffffd100+|r = auf die Watchlist.
- |cffffd100Unter Händlerpreis|r: im Auktionshaus billiger, als ein Händler zahlt.
  Kaufen und beim Händler verkaufen = sicherer Gewinn.
  |cffffd100+|r = Sniper-Ziel, das alle diese Angebote kauft.

Klick auf eine Zeile füllt den Rechner aus.
- |cffffd100Unter Entzauberwert|r: Ausrüstung billiger als ihr Entzauberungswert (Richtwerte).
  Jede eigene Entzauberung wird gemerkt - die Werte nähern sich deinem Server an.]],
    },
    sell = {
        "Verkaufen",
        [[
1.  Links ein Item aus deinen Taschen anklicken - die aktuellen
     Angebote werden geladen.
2.  Der |cffffd100Vorschlag|r unterbietet das günstigste fremde Angebot
     (um 1 Kupfer, 1 % oder 5 %). Ohne Angebote: Marktwert.
     Klick auf ein Angebot übernimmt dessen Preis.
3.  Menge und Dauer wählen, Gebühren prüfen, |cffffd100Einstellen|r klicken.

- Waren (stapelbar): eine Auktion mit der ganzen Menge.
- Einzelstücke (z.B. Ausrüstung): ein Klick = eine Auktion.
- Zahlt ein Händler mehr als das Auktionshaus netto, warnt das Addon
  und will einen zweiten Klick.
Eingestellt wird nur per Klick - so verlangt es WoW.
|cffffd100Serie|r (unten links): alle Items mit gemerktem Preis nacheinander, ein Klick pro Auktion.]],
    },
    auctions = {
        "Auktionen",
        [[
Deine eigenen Auktionen mit Status:
|cff33dd55günstigstes|r, |cffffcc33gleich|r, |cffff5544unterboten|r oder |cff00d1d1verkauft|r.

- |cffffd100Unterbietung prüfen|r lädt die aktuellen Preise all deiner Items.
- |cffffd100Nächste unterbotene abbrechen|r: jeder Klick bricht eine unterbotene
  Auktion ab. Danach im Tab Verkaufen neu und günstiger einstellen.
- |cffffd100X|r in einer Zeile bricht genau diese Auktion ab.

Beim Abbrechen ist die Einstellgebühr verloren.]],
    },
    ledger = {
        "Buchhaltung",
        [[
Was du im Auktionshaus verdienst und ausgibst.

- Verkäufe und Käufe liest das Addon aus den Rechnungen in deinem
  |cffffd100Briefkasten|r - einfach öffnen, abholen musst du nichts.
  Doppelt gezählt wird nie.
- Käufe über den Sniper und Einstellgebühren aus dem Tab Verkaufen
  werden sofort gebucht.
- Einnahmen sind nach Abzug des AH-Anteils (5 %).
  Gewinn = Einnahmen - Ausgaben - Gebühren.
- Oben den Zeitraum wählen, Ansicht |cffffd100Pro Item|r oder |cffffd100Verlauf|r.
- |cffffd100Statistik|r: Verkaufsquote je Item, beste Uhrzeit und Wochentag.
- |cffffd100Gold|r: alle Charaktere und dein Gold der letzten 30 Tage.
Am Briefkasten: |cffffd100AH-Post abholen|r holt alles mit einem Klick.]],
    },
    watcher = {
        "Schnäppchen-Wächter",
        [[
Sucht nebenbei Handwerkswaren deutlich unter dem Marktwert -
egal, was du gerade snipst.

1.  |cffffd100Wächter: AN|r und das Auktionshaus offen lassen.
2.  |cffffd100Treffer ab|r: z.B. höchstens 50 % vom Marktwert (Median 14 Tage).
     |cffffd100Mindestwert/Stück|r: Kleinkram ausblenden (Standard 10 Kupfer).
     |cffffd100Budget je Schnäppchen|r: so viel gibt ein Kauf höchstens aus.
3.  Kategorien wählen (Kräuter, Erz, Stoff, Leder, Verzauberung ...).
     Waffen und Rüstung werden nie durchsucht.

Alle Kategorien laufen in einer Suche. Lehnt der Server das ab,
sucht der Wächter von selbst Kategorie für Kategorie.
Jeder Treffer wird einzeln nachgeprüft: |cffffd100Lockangebote|r (1 Stück ganz unten) zählen nicht.
Kaufen mit |cffffd100Mausrad / eigener Taste|r wie beim Sniper
- Waren in WoW Forever: 1. Raste reserviert, 2. Raste kauft. Nie ohne dich.
Beim Warenkauf nimmt der Server immer die günstigsten Stücke zuerst,
ein Lockstück wird also mitgekauft.]],
    },
    buy = {
        "Einkauf",
        [[
Kaufen wie im Auktionshaus - mit Marktwert dazu.

1.  Oben einen |cffffd100Namen|r eingeben (Sprache deines Spiels, Teil reicht)
     und/oder links eine |cffffd100Kategorie|r wählen. Stufe und Seltenheit filtern.
2.  In der Liste ein Item anklicken: alle Angebote erscheinen.
3.  |cffffd100Waren|r (Kräuter, Erz, Stoff ...): Menge eintragen oder eine Preisstufe
     anklicken, |cffffd100Jetzt kaufen|r, dann |cffffd100Kauf bestätigen|r mit dem Preis vom Server.
4.  |cffffd100Ausrüstung|r: Angebot anklicken, |cffffd100Sofortkauf|r (2. Klick bestätigt)
     oder ein |cffffd100Gebot|r eingeben und |cffffd100Bieten|r.

|cffffd100% Markt|r zeigt, wie günstig ein Angebot ist (Median 14 Tage).
|cffffd100Lockangebote|r sind markiert; der Server verkauft immer die
günstigsten Stücke zuerst, ein Lockstück ist also im Preis enthalten.
Sniper, Preisprüfung und Wächter warten, solange du hier suchst.]],
    },
}

UI.HELP_EN = {
    start = {
        "Welcome to AHSentinel",
        "It's this easy:\n\n"
        .. "1.  Open the auction house and click |cffffd100Scan market|r at the bottom.\n"
        .. "     (The server allows one scan every 15 minutes.)\n\n"
        .. "2.  Five tabs at the top: Overview, Buy, Sell, Market, Ledger -\n"
        .. "     each with sub-tabs. Turn the sniper and watcher on and off in the title bar.\n\n"
        .. "3.  Find items by |cffffd100name in any language|r (parts are enough,\n"
        .. "     accents don't matter), by item ID or by |cffffd100shift-clicking|r an item.\n\n"
        .. "4.  |cffffd100Right-click an item|r: price history, watchlist,\n"
        .. "     sniper target or search in the auction house.\n\n"
        .. "5.  Under |cffffd100Buy -> Sniper|r add targets and turn sniper mode on -\n"
        .. "     one notch of the mouse wheel buys the next matching listing (commodities in WoW Forever: 2 notches).\n\n"
        .. "Design (Classic/Modern), language, window size, sound and more: |cffffd100Options|r at the top.\n"
        .. "This help is always available via the |cffffd100?|r button",
    },
    overview = {
        "Overview",
        "The key figures at a glance: number of items, last and next scan,\n"
        .. "active watchlist alerts and the biggest price increases and drops.\n\n"
        .. "Trends need at least two scans.\n"
        .. "Click an item to open its price history, right-click for all options.",
    },
    market = {
        "Market",
        [[
All scanned items with current price, market value and trend.

- |cffffd100Market value|r = median of the prices of the last 14 days
  (single outliers barely count).
- |cffffd100% market|r: current price compared to the market value.
  Green = cheap, orange/red = expensive.
- Search at the top: name in any language, parts are enough, accents don't matter.
  Item ID or shift-clicking an item works too.
- Click a column header = sort.
- |cffffd100+|r puts the item on the watchlist.
- Right-click: price history, sniper target, shopping list, search in the auction house.]],
    },
    marketview = { "Market", [[
The market shows what pays off right now - in 6 views:
- |cffffd100Today|r: your things first, then the best chances.
- |cffffd100Flip|r: buy below your buy limit and post again.
- |cffffd100Vendor|r: buyout below the vendor price.
- |cffffd100Gaps|r: low supply, steady sales, rising price.
- |cffffd100Crowded|r: better not post.
- |cffffd100Trends|r: stable moves over 7 and 30 days.
The button on the right always does the next step (check -> buy -> post),
never without your click. Click a row: details on the right with ONE recommendation.
Search at the top: look up any item. Top left: price index of typical goods.]] },
    watchlist = {
        "Watchlist",
        "Watch items and get notified.\n"
        .. "Enter an item by name (any language, suggestions appear while typing), ID\n"
        .. "or by shift-clicking an item.\n\n"
        .. "- |cffffd100Buy below|r: message when the price falls below it.\n"
        .. "- |cffffd100Sell above|r: message when the price rises above it.\n"
        .. "Prices in gold, e.g. 12.5 or 12g 50s.\n"
        .. "Checked after every scan (also with prices from other players).",
    },
    sniper = {
        "Sniper",
        "1.  Enter an item (name in any language, ID or shift-click) or a search term,\n"
        .. "     the |cffffd100max price per item|r, |cffffd100quantity|r and\n"
        .. "     |cffffd100budget|r. Empty quantity = 1, empty budget = quantity x max price.\n"
        .. "     Under |cffffd100Filter|r: rarity (Poor to Epic), item level and required level.\n\n"
        .. "2.  Keep the auction house open and set |cffffd100Sniper mode: ON|r.\n"
        .. "     The sniper searches your targets one after another on its own.\n\n"
        .. "3.  On a hit: |cffffd100turn the mouse wheel|r (up or down) = buy.\n"
        .. "     Commodities in WoW Forever: 1st notch reserves the price, 2nd notch buys (elsewhere often one notch).\n"
        .. "     Instead of the mouse wheel you can use your own key.\n\n"
        .. "Nothing is bought without your mouse wheel / key - never without you.\n"
        .. "The mouse wheel only buys while the cursor is over the game world (not over windows).\n\n" .. "|cffffd100Shopping lists|r (button at the top): collect items with quantities and turn them into sniper targets with one click.",
    },
    charts = {
        "Charts",
        [[
Price history of an item over time.

Select an item on the left or right-click it anywhere > price history.
Points from other players (price sync) are marked in the tooltip.
|cffffd100Grey points|r = unverified (probably a bait offer) - they don't count.

|cffffd100EMA|r (button at the top) - moving averages over time:
- blue = 6 hours, orange = 1 day, purple = 7 days
- real prices only (no bait offers), from 10 prices on
Green point: the 1-day EMA rises above the 7-day EMA (price picking up).
Red point: it falls below (price easing).]],
    },
    profit = {
        "Profit",
        [[
Flipping calculator: enter buy price, sell price and quantity -
the profit after the auction house fee is calculated right away.

Bargains in two views:
- |cffffd100Below market value|r: items well below their market value
  (14-day median). |cffffd100+|r = to the watchlist.
- |cffffd100Below vendor price|r: cheaper in the auction house than a vendor pays.
  Buy and sell to a vendor = guaranteed profit.
  |cffffd100+|r = sniper target that buys all these listings.

Click a row to fill in the calculator.
- |cffffd100Below disenchant value|r: gear cheaper than its disenchant value (estimates).
  Every disenchant you do is remembered - the values move towards your server's reality.]],
    },
    sell = {
        "Sell",
        [[
1.  Click an item from your bags on the left - its current
     listings are loaded.
2.  The |cffffd100suggestion|r undercuts the lowest listing from others
     (by 1 copper, 1 % or 5 %). Without listings: market value.
     Clicking a listing takes over its price.
3.  Choose quantity and duration, check the fees, click |cffffd100Post|r.

- Commodities (stackable): one auction with the whole quantity.
- Single items (e.g. gear): one click = one auction.
- If a vendor pays more than the auction house net, the addon warns
  and asks for a second click.
Posting only happens on your click - WoW requires that.
|cffffd100Series|r (bottom left): all items with a remembered price in a row, one click per auction.]],
    },
    auctions = {
        "Auctions",
        [[
Your own auctions with their status:
|cff33dd55lowest|r, |cffffcc33tied|r, |cffff5544undercut|r or |cff00d1d1sold|r.

- |cffffd100Check undercuts|r loads the current prices of all your items.
- |cffffd100Cancel next undercut|r: every click cancels one undercut auction.
  Then repost it cheaper in the Sell tab.
- |cffffd100X|r in a row cancels exactly that auction.

When cancelling, the deposit is lost.]],
    },
    ledger = {
        "Ledger",
        [[
What you earn and spend in the auction house.

- Sales and purchases are read from the invoices in your
  |cffffd100mailbox|r - just open it, you don't have to collect anything.
  Nothing is ever counted twice.
- Purchases via the sniper and deposits from the Sell tab
  are booked right away.
- Income is after the AH cut (5 %).
  Profit = income - spending - fees.
- Pick the period at the top, view |cffffd100Per item|r or |cffffd100History|r.
- |cffffd100Statistics|r: sell-through per item, best time of day and weekday.
- |cffffd100Gold|r: all characters and your gold over the last 30 days.
At the mailbox: |cffffd100Collect AH mail|r takes everything with one click.]],
    },
    watcher = {
        "Bargain watcher",
        [[
Searches trade goods well below market value on the side -
no matter what you are sniping right now.

1.  |cffffd100Watcher: ON|r and keep the auction house open.
2.  |cffffd100Hit at|r: e.g. at most 50 % of market value (14-day median).
     |cffffd100Min. value/item|r: hide small stuff (default 10 copper).
     |cffffd100Budget per bargain|r: the most one purchase spends.
3.  Choose categories (herbs, ore, cloth, leather, enchanting ...).
     Weapons and armor are never searched.

All categories run in one search. If the server rejects that,
the watcher switches to one category at a time by itself.
Every hit is checked with a single search: |cffffd100bait offers|r (1 item at the very bottom) don't count.
Buy with the |cffffd100mouse wheel / your own key|r like the sniper
- commodities in WoW Forever: 1st notch reserves, 2nd buys. Never without you.
For commodities the server always sells the cheapest units first,
so a bait unit is bought along.]],
    },
    buy = {
        "Buy",
        [[
Buy like in the auction house - with market value added.

1.  Enter a |cffffd100name|r at the top (your game language, part is enough)
     and/or pick a |cffffd100category|r on the left. Filter by level and rarity.
2.  Click an item in the list: all listings appear.
3.  |cffffd100Commodities|r (herbs, ore, cloth ...): enter a quantity or click a price
     tier, |cffffd100Buy now|r, then |cffffd100Confirm purchase|r with the server's price.
4.  |cffffd100Gear|r: click a listing, |cffffd100Buyout|r (2nd click confirms)
     or enter a |cffffd100bid|r and click |cffffd100Bid|r.

|cffffd100% market|r shows how cheap a listing is (14-day median).
|cffffd100Bait offers|r are marked; the server always sells the cheapest
units first, so a bait unit is included in the price.
Sniper, price check and watcher wait while you search here.]],
    },
}

function UI:ShowHelp(id)
    id = id or self.activeTab or "start"
    local help
    if A.uiLang == "deDE" then help = self.HELP_DE
    else help = A.HELP[A.uiLang] or self.HELP_EN end
    local h = help[id] or help.start
    if not self.helpWindow then
        local w = self:Dialog("AHAnalyzerProHelp", 580, 390, "")
        w.text = UI:Label(w, "", "GameFontHighlight", C.text)
        w.text:SetPoint("TOPLEFT", 20, -46)
        w.text:SetWidth(540)
        w.text:SetJustifyV("TOP")
        if w.text.SetSpacing then w.text:SetSpacing(2) end
        w.ok = UI:Button(w, L["Alles klar"], 110, 26, function() w:Hide() end, "primary")
        w.ok:SetPoint("BOTTOM", 0, 14)
        self.helpWindow = w
    end
    self.helpWindow.title:SetText(L["Hilfe: "] .. h[1])
    self.helpWindow.text:SetText(h[2])
    self.helpWindow:Show()
end

-- ------------------------------------------------------------
-- Rechtsklick-Menü für Items (überall gleich)
-- ------------------------------------------------------------
function UI:HideMenu()
    if self.menu then self.menu:Hide() end
end

function UI:ShowItemMenu(itemID, anchor)
    if not self.menu then
        local m = CreateFrame("Frame", "AHAnalyzerProItemMenu", UIParent)
        m:SetFrameStrata("FULLSCREEN_DIALOG")
        m:SetClampedToScreen(true)
        m:EnableMouse(true)
        UI:Box(m, C.bg, C.frameEdge, UI:IsClassic() and 2 or 1)
        UI:RegisterSpecial("AHAnalyzerProItemMenu")
        m.title = UI:Label(m, "", "GameFontNormalSmall", C.accent)
        m.title:SetPoint("TOPLEFT", 10, -8)
        m.title:SetWidth(180)
        if m.title.SetWordWrap then m.title:SetWordWrap(false) end
        m.entries = {}
        local labels = {
            { "chart", L["Preisverlauf anzeigen"] },
            { "watch", L["Auf die Watchlist"] },
            { "sniper", L["Als Sniper-Ziel eintragen"] },
            { "list", L["Auf eine Einkaufsliste"] },
            { "ah", L["Im Auktionshaus suchen"] },
            { "close", L["Schließen"] },
        }
        for i, def in ipairs(labels) do
            local b = CreateFrame("Button", nil, m)
            b:SetSize(184, 20)
            b:SetPoint("TOPLEFT", 8, -24 - (i - 1) * 21)
            b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            b.text:SetPoint("LEFT", 6, 0)
            b.text:SetText(def[2])
            local hl = b:CreateTexture(nil, "HIGHLIGHT")
            hl:SetAllPoints()
            hl:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.2)
            b.action = def[1]
            b:SetScript("OnClick", function(self) UI:OnMenuClick(self.action) end)
            m.entries[def[1]] = b
        end
        m:SetSize(200, 24 + #labels * 21 + 8)
        -- schließt sich, wenn die Maus länger weg ist
        m.away = 0
        m:SetScript("OnUpdate", function(self, dt)
            if self.IsMouseOver and self:IsMouseOver() then self.away = 0 return end
            self.away = self.away + (dt or 0)
            if self.away > 2.5 then self:Hide() end
        end)
        self.menu = m
    end
    local m = self.menu
    m.itemID = itemID
    m.away = 0
    m.title:SetText(A:GetItemName(itemID))
    local onList = A.Watchlist and A.Watchlist:Contains(itemID)
    m.entries.watch.text:SetText(onList and L["Von der Watchlist entfernen"] or L["Auf die Watchlist"])
    m:ClearAllPoints()
    if anchor and GetCursorPosition and UIParent.GetEffectiveScale then
        local x, y = GetCursorPosition()
        local s = UIParent:GetEffectiveScale() or 1
        if x and y then
            m:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", x / s - 4, y / s + 4)
        else
            m:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, 0)
        end
    elseif anchor then
        m:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, 0)
    else
        m:SetPoint("CENTER")
    end
    m:Show()
end

function UI:OnMenuClick(action)
    local m = self.menu
    local id = m and m.itemID
    if m then m:Hide() end
    if not id then return end
    if action == "chart" then
        self:OpenChart(id)
    elseif action == "watch" then
        local ok, msg
        if A.Watchlist:Contains(id) then ok, msg = A.Watchlist:Remove(id) else ok, msg = A.Watchlist:Add(tostring(id)) end
        A:Print(msg)
    elseif action == "sniper" then
        self:OpenSniperFor(id)
    elseif action == "ah" then
        local _, msg = A.Sniper:OpenInAH(id)
        A:Print(msg)
    elseif action == "list" then
        local w = self:ShowLists()
        if w then
            self:SetItemInput(w.item, id)
            w.qty:SetFocus()
        end
    end
end

-- ------------------------------------------------------------
-- Textfenster (für CSV-Export)
-- ------------------------------------------------------------
-- Unterstützen (Spende): Dank + Link zum Kopieren (WoW kann keine Webseiten öffnen)
function UI:ShowDonate()
    if not self.donateWindow then
        local w = self:Dialog("AHAnalyzerProDonate", 480, 236, L["AHSentinel unterstützen"])
        local icon = w:CreateTexture(nil, "ARTWORK")
        icon:SetSize(36, 36)
        icon:SetPoint("TOPLEFT", 16, -42)
        icon:SetTexture(A.ICON or "Interface\\Icons\\INV_Misc_Coin_02")
        local text = UI:Label(w, L["Danke, dass du AHSentinel unterstützt! Jede Spende hilft mir, mehr Zeit in neue Funktionen, schnelle Fehlerbehebungen und die Unterstützung aller WoW-Versionen zu stecken. Viel Erfolg beim Goldmachen!"], "GameFontHighlight", C.text)
        text:SetPoint("TOPLEFT", icon, "TOPRIGHT", 12, 0)
        text:SetPoint("RIGHT", w, "RIGHT", -16, 0)
        text:SetJustifyH("LEFT")
        if text.SetWordWrap then text:SetWordWrap(true) end
        local eb = UI:EditBox(w, 448, 26, "")
        eb:SetPoint("TOPLEFT", 16, -150)
        eb:SetText(A.DONATE_URL)
        -- nur zum Kopieren: Änderungen sofort zurücknehmen
        eb:SetScript("OnTextChanged", function(self, user)
            if user and self:GetText() ~= A.DONATE_URL then self:SetText(A.DONATE_URL); self:HighlightText() end
        end)
        eb:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
        eb:SetScript("OnEscapePressed", function() w:Hide() end)
        eb:SetScript("OnEnterPressed", function() w:Hide() end)
        w.edit = eb
        local hint = UI:Label(w, L["Strg+C kopiert den PayPal-Link - dann im Browser einfügen."], "GameFontDisableSmall", C.textDim)
        hint:SetPoint("TOPLEFT", eb, "BOTTOMLEFT", 2, -8)
        local sig = UI:Label(w, "- GoldSentinel", "GameFontNormalSmall", C.accent)
        sig:SetPoint("BOTTOMRIGHT", -16, 14)
        self.donateWindow = w
    end
    local w = self.donateWindow
    w:Show()
    w.edit:SetText(A.DONATE_URL)
    w.edit:SetFocus()
    w.edit:HighlightText()
    return w
end

function UI:ShowTextWindow(titleText, text)
    if not self.textWindow then
        local w = self:Dialog("AHAnalyzerProTextWindow", 700, 460, "")

        local area = CreateFrame("Frame", nil, w)
        area:SetPoint("TOPLEFT", 12, -40)
        area:SetPoint("BOTTOMRIGHT", -12, 12)
        UI:Box(area, C.input, C.border)

        local sf = CreateFrame("ScrollFrame", nil, area)
        sf:SetPoint("TOPLEFT", 6, -6)
        sf:SetPoint("BOTTOMRIGHT", -6, 6)
        local eb = CreateFrame("EditBox", nil, sf)
        eb:SetMultiLine(true)
        eb:SetAutoFocus(false)
        eb:SetFontObject(ChatFontNormal or GameFontHighlightSmall)
        eb:SetWidth(650)
        eb:SetScript("OnEscapePressed", function() w:Hide() end)
        -- Cursor sichtbar halten (Pfeiltasten, Bild auf/ab)
        -- Nur auf echte Bewegungen des Cursors reagieren: manche Clients melden das Ereignis
        -- bei jedem Neuzeichnen, das hat das Scrollen mit dem Mausrad immer wieder zurückgesetzt.
        eb:SetScript("OnCursorChanged", function(self, x, y, cw, ch)
            -- nur echte Bewegungen des Cursors (Tasten), nicht Neuzeichnen beim Scrollen mit dem Mausrad
            local pos = self.GetCursorPosition and self:GetCursorPosition() or y
            if self.lastCursorPos == pos then return end
            self.lastCursorPos = pos
            if sf.wheelT and GetTime() - sf.wheelT < 0.6 then return end
            local top = -(y or 0)
            local s = sf:GetVerticalScroll() or 0
            local h = sf:GetHeight() or 0
            if top < s then sf:SetVerticalScroll(top)
            elseif top + (ch or 14) > s + h then sf:SetVerticalScroll(math.max(0, top + (ch or 14) - h)) end
        end)
        sf:SetScrollChild(eb)
        sf:EnableMouseWheel(true)
        sf:SetScript("OnMouseWheel", function(self, delta)
            self.wheelT = GetTime()
            local range = self:GetVerticalScrollRange() or 0
            local step = IsShiftKeyDown and IsShiftKeyDown() and 300 or 75
            local newPos = math.max(0, math.min(range, self:GetVerticalScroll() - delta * step))
            self:SetVerticalScroll(newPos)
        end)
        w.edit = eb
        -- immer vor allen anderen Addon-Fenstern (z. B. vor dem Selbsttest)
        w:SetFrameStrata("FULLSCREEN_DIALOG")
        w:SetToplevel(true)
        self.textWindow = w
    end
    local w = self.textWindow
    w.title:SetText(titleText or "")
    w.edit:SetText(text or "")
    -- Höhe des Textfelds an den Inhalt anpassen, sonst lässt sich nicht scrollen
    local lines = 0
    for line in ((text or "") .. "\n"):gmatch("(.-)\n") do
        lines = lines + math.max(1, math.ceil(#line / 95))
    end
    w.edit:SetHeight(math.max(380, lines * 15 + 20))
    if w.edit:GetParent().SetVerticalScroll then w.edit:GetParent():SetVerticalScroll(0) end
    w:Show()
    w:Raise()
    w.edit.lastCursorPos = nil
    w.edit:SetFocus()
    w.edit:SetCursorPosition(0)     -- Anfang des Berichts zeigen
    w.edit:HighlightText()          -- alles markiert: Strg+C kopiert sofort
end

-- ------------------------------------------------------------
-- Auf Kern-Ereignisse reagieren
-- ------------------------------------------------------------
A:On("READY", function()
    -- gespeichertes Design laden, bevor irgendein Fenster gebaut wird
    UI:ApplyPalette(A.db.settings.theme or "classic")
end)
A:On("SCAN_STARTED", function() UI:UpdateStatus() end)
A:On("SCAN_PROGRESS", function() UI:UpdateStatus() end)
A:On("SCAN_FAILED", function() UI:UpdateStatus() end)
A:On("DATA_CHANGED", function() UI:RefreshLater() end)
A:On("WATCHLIST_CHANGED", function() UI:RefreshActive() end)
-- Mit dem Auktionshaus öffnen und schliessen (Wunsch des Nutzers 9. Nov. 09:26, Option ab Werk an):
-- AH auf -> Fenster auf; AH zu -> Fenster zu. War das Fenster schon vorher offen, bleibt es danach offen.
-- Nie im Kampf aufdrängen.
function UI:OpenWithAHEnabled()
    return not (A.db and A.db.settings.openWithAH == false)
end
-- before = war das Fenster sichtbar, BEVOR es beim Öffnen ins Auktionshaus umzog
function UI:OnAHStateAuto(open, before)
    local combat = A.InCombat and A:InCombat()
    if open then
        self.wasOpenBeforeAH = before and true or false
        self.autoOpened = nil
        if self:OpenWithAHEnabled() and not before and not combat then
            self:Show()
            self.autoOpened = true
        end
    else
        local was = self.wasOpenBeforeAH
        self.wasOpenBeforeAH = nil
        if self.autoOpened then
            self.autoOpened = nil
            self:Hide()
        elseif was and self:OpenWithAHEnabled() and not self:IsVisible() and not combat then
            self:Show()          -- vorher offen (im AH eingebettet): nach dem Schliessen als eigenes Fenster weiter
        end
    end
end
A:On("AH_STATE", function()
    local open = A:IsAHOpen()
    local before = UI:IsVisible()
    if open then UI:OnAHOpened() else UI:OnAHClosed() end
    local ok, err = pcall(UI.OnAHStateAuto, UI, open, before)
    if not ok and A.ReportError then A:ReportError("OpenWithAH", err) end
    if A.Spieltest and A.Spieltest.activeUntil then pcall(A.Spieltest.OnAHState, A.Spieltest, open, before) end
    UI:UpdateStatus()
end)
A:On("SYNC_CHANGED", function() UI:UpdateStatus() end)
-- Kopfzeile "Sniper: an/aus · Wächter: an/aus" immer aktuell halten
A:On("WATCHER_CHANGED", function() UI:UpdateHeaderStatus() end)
A:On("SNIPER_CHANGED", function() UI:UpdateHeaderStatus() end)
A:On("TESTMODE_CHANGED", function()
    -- Meldungen aus dem Test (z. B. "Ziel gesetzt: ...") nicht stehen lassen
    for _, tab in ipairs(UI.tabs or {}) do
        local p = tab.panel
        if p and p.message and p.message.SetText then p.message:SetText("") end
    end
    UI:UpdateStatus()
end)
-- Sprache gewechselt: alle Fenster in der neuen Sprache neu aufbauen
A:On("LANGUAGE_CHANGED", function() UI:Rebuild() end)
