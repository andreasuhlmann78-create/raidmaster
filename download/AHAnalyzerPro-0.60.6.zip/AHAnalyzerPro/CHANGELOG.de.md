# AH Analyzer Pro – Änderungen (deutsch)

Diese Datei ist die deutsche Zusammenfassung für Discord. Die ausführliche englische Fassung steht in CHANGELOG.md.

## 0.60.6

- **Selbsttest simuliert echten Handel:** Mit den echten Angeboten aus dem Auktionshaus spielt er jetzt Sofortkauf, Gebot, Sniper-Kauf, Einstellen und Abbrechen genau wie im Ernstfall durch – gleiches Angebot, gleicher Preis, gleicher Befehl. Nur der Befehl an den Server wird abgefangen: Es wird nichts gekauft, eingestellt oder abgebrochen, und am Ende prüft der Test, dass dein Gold unverändert ist. Meldungen im Chat sind dabei mit „[Simulation]“ markiert.
- **Selbsttest:** Der Wächter wird nach seiner Testrunde gleich wieder ausgeschaltet und blockiert die folgenden Server-Suchen nicht mehr.

## 0.60.5

- **Behoben (klassische Clients):** Beim Öffnen des Auktionshauses konnte der Lua-Fehler „attempt to compare number with nil“ kommen (Gebote nach einem Reload).
- **Kopfzeile:** „Sniper: an/aus“ und „Wächter: an/aus“ stimmen jetzt immer, auch nach dem Umschalten.
- **Selbsttest:** Läuft im Hintergrund noch ein Markt-Scan, laufen die Server-Suchen nicht mehr alle in die Zeitüberschreitung – beim Test mit gespeicherten Daten wird der Scan beendet, sonst wird auf ihn gewartet. Ein neuer Scan ist während des Tests gesperrt.
- **Selbsttest:** Danach sind Einstellungen, Wächter und Fenster (Reiter, oder geschlossen) zuverlässig wie vorher. Klappt etwas nicht, steht es im Bericht.
- **Textfenster** („Bericht kopieren“) öffnet sich immer vorne, beginnt oben und scrollt mit dem Mausrad zügig (mit Shift in großen Schritten).

## 0.60.4

- **Selbsttest mit gespeicherten Daten:** neuer Knopf „Mit gespeicherten Daten“ im Selbsttest-Fenster (oder `/ahp test daten`). Er testet mit den Auktionshaus-Daten, die du schon gescannt hast – **kein neuer Scan**. Er läuft sogar bei geschlossenem Auktionshaus, dann werden nur die Suchen beim Server übersprungen.

## 0.60.3

- **Behoben für TBC Anniversary (und andere klassische Clients):** „Meine Auktionen“ wurde nie aktualisiert, und manche Meldungen des Auktionshauses (z. B. „eingestellt“) kamen nicht an. Diese Clients kennen die Ereignis-Namen des neuen Auktionshauses, lösen sie beim klassischen aber nie aus – das Addon nutzt dort jetzt immer seine eigenen. Gefunden mit dem neuen Selbsttest.
- **Selbsttest:** Der kopierte Bericht lässt sich jetzt scrollen, die Ergebnisliste ist breiter – Maus über eine Zeile zeigt den ganzen Text.

## 0.60.2

- **Selbsttest:** Optionen → „Selbsttest“ oder `/ahp test` prüft alle Funktionen mit echten Daten aus deinem Auktionshaus: Markt-Scan (falls nötig), Marktdaten, alle Reiter, alle Auswertungen und echte Suchen beim Server (Einkauf, Preisprüfung, Sniper, Wächter, eigene Auktionen). Während des Tests sind **Kaufen, Bieten, Einstellen und Abbrechen gesperrt**, danach sind Einstellungen und Sniper-Ziele wie vorher. Das Ergebnis erscheint in einem Fenster, lässt sich als Bericht kopieren und wird gespeichert.

## 0.60.1

- **Echter Minikarten-Knopf:** Der Knopf sitzt jetzt wie bei anderen Addons an der Minikarte – mit der Maus **rund um die Minikarte ziehen**, die Position wird gespeichert. Funktioniert mit runden und eckigen Minikarten. Ein-/ausblenden in den Optionen oder mit `/ahp minimap`, `/ahp reset` holt ihn zurück.
- **Neues Icon:** eine goldene **Waage** – am Minikarten-Knopf, oben im Fenster und in der Addon-Liste.

## 0.60.0

**Aufgeräumtes Fenster – 5 Reiter statt 11:**

- **Übersicht · Kaufen · Verkaufen · Markt · Buchhaltung.** Was zusammengehört, steht jetzt als Unterreiter:
  Kaufen = Einkauf, Sniper, Wächter, Schnäppchen · Verkaufen = Einstellen, Meine Auktionen · Markt = Alle Preise, Watchlist.
  Alle Funktionen sind noch da, nichts ist weggefallen.
- **Preisverlauf im eigenen Fenster:** Ein Klick auf ein Item öffnet den Verlauf neben dem Addon – die Liste, aus der du kommst, bleibt genau, wo sie war. Das Fenster lässt sich verschieben und in der Größe ziehen.
- **Sniper und Wächter in der Kopfzeile:** auf einen Blick sehen, ob sie laufen, und mit einem Klick an- oder ausschalten (Rechtsklick öffnet ihren Reiter).
- **Merkt sich, wo du warst:** Das Addon öffnet sich im zuletzt benutzten Reiter, jeder Haupt-Reiter merkt sich seinen Unterreiter.

## 0.59.33

**Komfort-Update – zwölf kleine Dinge, die jeden Tag Klicks sparen:**

- **Stapelgröße und Anzahl Stapel** (klassisches Auktionshaus): z. B. 5 Stapel à 20 – wird pro Item gemerkt, auch für die Serie.
- **Post automatisch abholen:** Beim Öffnen des Briefkastens wird die Auktionspost gleich abgeholt (Shift beim Öffnen = diesmal nicht).
- **Mindestpreis pro Item:** Knopf „Min“ beim Verkaufen – darunter wird nie unterboten, die Serie wartet statt billig zu verkaufen.
- **Nur was mir fehlt:** Am Berufsfenster kommt nur die fehlende Menge auf die Einkaufsliste (Taschen, Bank und Twinks werden gezählt).
- **Alt-Klick auf ein Item** in den Taschen oder im Chat: öffnet den Preisverlauf, bei offenem Auktionshaus den Einkauf.
- **Verkaufschance im Tooltip:** wie viel von dem, was du eingestellt hast, verkauft wurde und wie lange es meist dauert.
- **Erinnerung bei ablaufenden Auktionen** und beim Einloggen, was seit dem letzten Besuch abgelaufen ist.
- **Favoriten im Einkauf:** Suchen speichern und mit einem Klick wieder ausführen.
- **Gold-Ziel** für alle Charaktere zusammen (Optionen oder `/ahp ziel 5000`).
- **Gildenbank-Wert** in der Buchhaltung (ab TBC).
- **Raid-Vorrat:** Einkaufsliste mit Tränken, Fläschchen, Elixieren und Buff-Food für eine Raidwoche (`/ahp raid`).
- **Preis-Sync nur mit der Gilde** als neue Option.

## 0.59.32

- **Keine absurden Gewinne mehr:** Items mit 1000 % Gewinn oder mehr (fast immer Fehldaten) erscheinen nicht mehr bei den Schnäppchen und nicht mehr unter „Größte Preisanstiege“.

## 0.59.31

- **Itemlevel als Suchfilter:** Felder „iLvl ab / bis“ im Einkauf und im Markt – filtern sofort, ohne neue Suche beim Server.

## 0.59.30

- **Schrott beim Händler verkaufen** mit einem Knopf (graue Items und alles, was beim Händler mehr bringt).
- **Vermögen:** Wert von Taschen, Bank und Twinks plus das Gold aller Charaktere.
- **Tagesbilanz beim Einloggen**, jederzeit mit `/ahp bilanz`.
- **Neu einstellen mit einem Klick** für abgelaufene Auktionen.
- **Flip-Empfehlungen**, **Post an Twinks**, **/ahp help** im Chat.
- Einkauf: iLvl für jedes Item · Verkaufen: Angebote erscheinen viel schneller.
