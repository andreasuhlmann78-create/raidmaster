if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.9 - Sniper (Logik)
--
-- Ziele: ein Item (Name/ID) oder ein Suchbegriff, jeweils mit
--   Max. Preis pro Stück, Menge, Budget (max. Gold),
--   Seltenheit (Grau bis Episch), Itemlevel und benötigter Stufe.
--
-- Sniper-Modus AN + Auktionshaus offen:
--   * der Sniper sucht die Ziele selbstständig der Reihe nach
--   * jede Mausrad-Raste (oder deine eigene Taste) kauft das nächste
--     passende Angebot, bis Menge oder Budget erreicht ist
--   * Waren (stapelbare Handelswaren): der Sniper holt sich den Preis
--     schon beim Treffer vom Server (Reservierung ohne Tastendruck) -
--     EINE Raste kauft dann sofort. Geht das auf dem Server nicht, wird
--     automatisch auf 2 Rasten umgestellt (1. reserviert, 2. kauft).
-- Gekauft wird NIE ohne deinen Tastendruck (das verlangt WoW selbst).
--
-- Lockangebote: liegt bei Waren ganz unten ein einzelnes Stück, ist das
-- meist ein Köder. Der Sniper löst darauf nicht aus. Kommt ein echter
-- Treffer, nimmt der Server beim Warenkauf trotzdem immer die günstigsten
-- Stücke zuerst - das Lockstück wird also mitgekauft (und mitgerechnet).
--
-- Schnäppchen-Wächter: vorübergehende Ziele (nicht gespeichert), die der
-- Wächter anlegt. Gekauft wird darüber ebenfalls nur per Tastendruck.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
-- Retail 12.x: die alten Item-/Zauber-Funktionen gibt es nur noch in C_Item / C_Spell
local GetItemInfo = GetItemInfo or (C_Item and C_Item.GetItemInfo)
local GetDetailedItemLevelInfo = GetDetailedItemLevelInfo or (C_Item and C_Item.GetDetailedItemLevelInfo)
local A = AHAnalyzerPro
local L = A.L

local Sn = {}
A.Sniper = Sn

local MIN_INTERVAL = 0          -- automatische Suche: 0 = so oft, wie der Server erlaubt
local ALERT_REPEAT = 4          -- Signal wiederholen, solange ein Treffer kaufbar ist (Sek.)
local PRINT_REPEAT = 30         -- Chat-Meldung zum selben Treffer höchstens so oft
local FOCUS_RECHECK = 10        -- altes AH: wartender Treffer wird so oft (Sek.) nachgeprüft
local TIMEOUT = 8               -- Sekunden, bis eine Suche als ergebnislos gilt
local RESULT_FRESH = 30         -- so lange (Sek.) gelten gefundene Angebote als aktuell (Ausrüstung/Einzelangebote)
local RESULT_FRESH_COMMODITY = 3 -- C2: Waren-Treffer nur 3 s (danach erst neu suchen, nicht reservieren)
local PRESS_DEBOUNCE = 0.3      -- Mindestabstand zwischen zwei Käufen per Taste (Reservieren / Kauf-Start)
local CONFIRM_DEBOUNCE = 0.05   -- A2: Bestätigen (pending ready) - kein Doppelkauf möglich, pending wird geleert
Sn.RESULT_FRESH_COMMODITY, Sn.CONFIRM_DEBOUNCE, Sn.PRESS_DEBOUNCE = RESULT_FRESH_COMMODITY, CONFIRM_DEBOUNCE, PRESS_DEBOUNCE
local CONFIRM_TIMEOUT = 10      -- reservierter Warenpreis verfällt nach x Sek.
local AUTO_REQUOTE = 8          -- Sofortkauf: Preis so oft (Sek.) neu holen, solange der Treffer wartet

Sn.QUALITY = {
    [0] = { name = "Grau", short = "Gr", color = "9d9d9d", filter = "PoorQuality" },
    [1] = { name = "Weiß", short = "We", color = "ffffff", filter = "CommonQuality" },
    [2] = { name = "Grün", short = "Gn", color = "1eff00", filter = "UncommonQuality" },
    [3] = { name = "Blau", short = "Bl", color = "0070dd", filter = "RareQuality" },
    [4] = { name = "Episch", short = "Ep", color = "a335ee", filter = "EpicQuality" },
}

Sn.search = nil         -- laufende Suche
Sn.result = nil         -- letztes Ergebnis { key, itemID, listings, time, commodity, candidates }
Sn.pending = nil        -- Waren-Kauf wartet auf Bestätigung
Sn.lastSearch = -100
Sn.lastPress = -100
Sn.rotation = 0
Sn.lastPurchase = nil
Sn.extra = {}           -- vorübergehende Ziele des Schnäppchen-Wächters [key] = Ziel

local function DB()
    return A.db and A.db.sniper
end

local function SafeCall(fn, ...)
    if not fn then return nil end
    local ok, a = pcall(fn, ...)
    if ok then return a end
    if A.ReportOnce then A:ReportOnce(fn, "SafeCall:Sniper", a) end
    return nil
end

local function Now()
    return GetTime()
end

function Sn:QualityText(q)
    local d = self.QUALITY[q or 0]
    if not d then return "?" end
    return "|cff" .. d.color .. L[d.name] .. "|r"
end

-- ------------------------------------------------------------
-- Ziele verwalten
-- ------------------------------------------------------------
function Sn:GetTarget(key)
    local db = DB()
    if not key then return nil end
    return (db and db.targets[key]) or self.extra[key]
end

-- vorübergehendes Ziel (Wächter): nicht gespeichert
function Sn:AddExtraTarget(t)
    self.extra[t.key] = t
    self:ApplyBindings()
    A:Fire("SNIPER_CHANGED")
end

function Sn:RemoveExtraTarget(key)
    if not self.extra[key] then return end
    self.extra[key] = nil
    if self.result and self.result.key == key then self.result = nil end
    if self.current == key then self.current = nil end
    self:ApplyBindings()
    A:Fire("SNIPER_CHANGED")
end

function Sn:HasExtraTargets()
    for _, t in pairs(self.extra) do
        if not self:IsDone(t) then return true end
    end
    return false
end

-- input: Item-Name, Item-ID oder Suchbegriff
-- f: { quals = { [Qualität] = true } oder nil (alle), ilvlMin, ilvlMax, lvlMin, lvlMax }
--    (ältere Aufrufer: qMin/qMax als Bereich)
-- H4: liegt Max/Stück über dem Netto-Verkaufswert (letzter Scan − AH-Anteil − Einzahlungsrisiko)? Dann Verlust je
-- Stück (Kupfer), sonst nil. Nur Hinweis, kein Verbot.
-- S3 (Befund Sniper 10.11. 16:30): derselbe Wert wie im Tooltip - der höhere von realistischem Verkaufswert und
-- Entzauberwert (netto); bei Entzauber-Zielen zählt also der Entzauberwert ("lohnt bis")
function Sn:MaxOverValue(t)
    if not (t and t.itemID and t.maxPrice) then return nil end
    local ok, net = pcall(A.NetSellValue, A, t.itemID)
    if not ok then net = nil end
    local D = A.Disenchant
    if D and D.Prior and D.DealValue and D:Prior(t.itemID) then
        local okD, _, deNet, complete = pcall(D.DealValue, D, t.itemID)
        if okD and deNet and complete and (not net or deNet > net) then net = deNet end
    end
    if not net then return nil end
    net = math.floor(net)
    if t.maxPrice > net then return t.maxPrice - net end
    return nil
end

function Sn:SetTarget(input, maxPrice, qty, budget, f)
    local db = DB()
    if not db then return false, L["Datenbank nicht bereit."] end
    input = input and tostring(input):gsub("^%s+", ""):gsub("%s+$", "") or ""
    if input == "" then return false, L["Bitte Item-Name, Item-ID oder Suchbegriff eingeben."] end
    if not maxPrice or maxPrice <= 0 then return false, L["Bitte einen Max.-Preis pro Stück eingeben (Gold, Silber, Kupfer)."] end
    qty = math.floor(tonumber(qty) or 1)
    if qty < 1 then qty = 1 end
    if not budget or budget <= 0 then budget = maxPrice * qty end
    if budget < maxPrice then return false, L["Das Budget ist kleiner als der Max.-Preis für ein Stück."] end
    f = f or {}
    local quals = f.quals
    if not quals and (f.qMin or f.qMax) then
        local lo, hi = f.qMin or 0, f.qMax or 4
        if lo > hi then lo, hi = hi, lo end
        if lo > 0 or hi < 4 then
            quals = {}
            for q = lo, hi do quals[q] = true end
        end
    end
    if quals and next(quals) == nil then return false, L["Bitte mindestens eine Seltenheit anhaken."] end
    local qMin, qMax = 0, 4
    if quals then
        qMin, qMax = 4, 0
        for q in pairs(quals) do qMin = math.min(qMin, q); qMax = math.max(qMax, q) end
    end

    local itemID, matches = A:FindItemByName(input)
    local t = {
        maxPrice = maxPrice, qty = qty, budget = budget,
        bought = 0, spent = 0,
        qMin = qMin, qMax = qMax, quals = quals,
        ilvlMin = f.ilvlMin, ilvlMax = f.ilvlMax,
        lvlMin = f.lvlMin, lvlMax = f.lvlMax,
        added = time(),
        de = f.de or nil,                    -- MP2: Höchstpreis kommt aus dem Entzauberwert
    }
    if itemID then
        t.kind, t.itemID, t.key = "item", itemID, "i:" .. itemID
    else
        if string.len(input) < 3 then return false, L["Suchbegriff bitte mit mindestens 3 Zeichen."] end
        t.kind, t.text, t.key = "text", input, "t:" .. string.lower(input)
    end
    local existed = db.targets[t.key] ~= nil
    db.targets[t.key] = t
    if self.result and self.result.key == t.key then self.result = nil end
    A:Fire("SNIPER_CHANGED")
    local msg = (existed and L["Ziel aktualisiert: "] or L["Ziel gesetzt: "]) .. self:TargetName(t)
        .. " - " .. qty .. L[" Stück, max. "] .. A:FormatMoney(maxPrice) .. L["/Stück, Budget "] .. A:FormatMoney(budget)
    local over = self:MaxOverValue(t)
    if over then msg = msg .. "  |cffffcc00" .. string.format(L["Max über Verkaufswert – jeder Kauf verliert ca. %s/Stück"], A:FormatMoney(over)) .. "|r" end
    if t.kind == "text" and matches and matches > 1 then
        msg = msg .. L["  (Suchwort, passt auf "] .. matches .. L[" Items - für ein bestimmtes Item einen Vorschlag anklicken)"]
    end
    return true, msg
end

function Sn:RemoveTarget(key)
    local db = DB()
    if self.extra[key] then
        local name = self:TargetName(self.extra[key])
        self:RemoveExtraTarget(key)
        return true, L["Ziel entfernt: "] .. name
    end
    if not (db and db.targets[key]) then return false, L["Ziel nicht gefunden."] end
    local name = self:TargetName(db.targets[key])
    db.targets[key] = nil
    if self.result and self.result.key == key then self.result = nil end
    A:Fire("SNIPER_CHANGED")
    return true, L["Ziel entfernt: "] .. name
end

function Sn:ResetProgress(key)
    local t = self:GetTarget(key)
    if not t then return false, L["Ziel nicht gefunden."] end
    t.bought, t.spent, t.budgetNote = 0, 0, nil
    A:Fire("SNIPER_CHANGED")
    return true, L["Zähler zurückgesetzt: "] .. self:TargetName(t)
end

function Sn:TargetName(t)
    if t.kind == "item" then return A:GetItemName(t.itemID) end
    return "\"" .. t.text .. "\""
end

function Sn:Remaining(t)
    return (t.qty or 0) - (t.bought or 0), (t.budget or 0) - (t.spent or 0)
end

-- SN3/SN4: Budget reicht für kein weiteres Stück zum Max-Preis
function Sn:BudgetUsedUp(t)
    local _, b = self:Remaining(t)
    return b <= 0 or (t.maxPrice and t.maxPrice > 0 and b < t.maxPrice) or false
end
function Sn:BudgetText(t)
    return string.format(L["Budget von %s ist aufgebraucht (%d Stück gekauft). Für mehr das Budget erhöhen."],
        A:FormatMoney(t.budget or 0), t.bought or 0)
end
-- SN4: Stück = min(Menge, floor(Budget / Max-Preis))
function Sn:BudgetPieces(t)
    if not (t.maxPrice and t.maxPrice > 0) then return t.qty or 0 end
    return math.min(t.qty or 0, math.floor((t.budget or 0) / t.maxPrice))
end
-- SN2: "50/100 gekauft · Budget 5g aufgebraucht" bzw. "… · Budget übrig 2g 90s"
function Sn:ProgressText(t)
    local _, b = self:Remaining(t)
    local s = string.format(L["%d/%d gekauft"], t.bought or 0, t.qty or 0)
    if self:BudgetUsedUp(t) and (t.bought or 0) < (t.qty or 0) then
        return s .. " · " .. string.format(L["Budget %s aufgebraucht"], A:FormatMoney(t.budget or 0, true))
    end
    return s .. " · " .. string.format(L["Budget übrig %s"], A:FormatMoney(math.max(0, b), true))
end
-- SN1: gekauft in dieser Suche (Zeilen mit Status "gekauft"): Stück, Summe, verpasst
function Sn:ResultBought(r)
    r = r or self.result
    if not r then return 0, 0, 0 end
    local n, sum = 0, 0
    for _, l in ipairs(r.listings or {}) do
        local u = l.used or 0
        if u > 0 and not l.bait then
            n = n + u
            sum = sum + ((r.commodity or not l.buyout) and u * (l.price or 0) or l.buyout)
        end
    end
    local missed = math.max(0, (self:Stats().missed or 0) - (r.missedStart or 0))
    return n, sum, missed
end

function Sn:IsDone(t)
    local q, b = self:Remaining(t)
    return q <= 0 or b <= 0
end

-- gewählte Seltenheiten eines Ziels: nil = alle, sonst { [Qualität] = true }
-- (ältere Ziele haben nur einen Bereich qMin..qMax)
function Sn:QualSet(t)
    if t.quals then return t.quals end
    local lo, hi = t.qMin or 0, t.qMax or 4
    if lo == 0 and hi == 4 then return nil end
    local set = {}
    for q = lo, hi do set[q] = true end
    return set
end

function Sn:FilterText(t)
    local parts = {}
    local set = self:QualSet(t)
    if set then
        local list, n = {}, 0
        for q = 0, 4 do if set[q] then n = n + 1; list[n] = q end end
        if n > 2 and list[n] - list[1] + 1 == n then
            table.insert(parts, L[self.QUALITY[list[1]].short] .. "-" .. L[self.QUALITY[list[n]].short])
        else
            local s = {}
            for _, q in ipairs(list) do table.insert(s, L[self.QUALITY[q].short]) end
            table.insert(parts, table.concat(s, ","))
        end
    end
    if t.ilvlMin or t.ilvlMax then table.insert(parts, "i" .. (t.ilvlMin or "") .. "-" .. (t.ilvlMax or "")) end
    if t.lvlMin or t.lvlMax then table.insert(parts, L["St"] .. (t.lvlMin or "") .. "-" .. (t.lvlMax or "")) end
    if #parts == 0 then return L["alle"] end
    return table.concat(parts, " ")
end

local function TargetEntry(key, t)
    local qLeft, bLeft = Sn:Remaining(t)
    return {
        key = key,
        itemID = t.itemID,
        name = Sn:TargetName(t),
        kind = t.kind,
        maxPrice = t.maxPrice,
        overValue = (not t.watch) and Sn:MaxOverValue(t) or nil,     -- H4
        hitN = t.hitN or 0, boughtN = t.boughtN or 0,                  -- D2/D3
        qty = t.qty, bought = t.bought or 0,
        budget = t.budget, spent = t.spent or 0,
        qtyLeft = qLeft, budgetLeft = bLeft,
        filter = Sn:FilterText(t),
        done = Sn:IsDone(t),
        checked = t.checked,
        found = t.found,
        watch = t.watch,
        target = t,
    }
end

function Sn:GetTargets()
    local out = {}
    local db = DB()
    if not db then return out end
    for key, t in pairs(db.targets) do table.insert(out, TargetEntry(key, t)) end
    for key, t in pairs(self.extra) do table.insert(out, TargetEntry(key, t)) end
    table.sort(out, function(a, b)
        if (a.watch and true or false) ~= (b.watch and true or false) then return a.watch and true or false end
        return string.lower(a.name) < string.lower(b.name)
    end)
    return out
end

-- offene Ziele. Ist nur der Wächter aktiv (Sniper-Modus aus), nur dessen Ziele.
function Sn:GetActiveTargets(onlyWatch)
    local db = DB()
    if onlyWatch == nil then onlyWatch = not (db and db.armed) and self:HasExtraTargets() end
    local out = {}
    for _, e in ipairs(self:GetTargets()) do
        if not e.done and (not onlyWatch or e.watch) and not self:ItemPaused(e.itemID) then table.insert(out, e) end
    end
    return out
end

-- Alte Ziele (Watchlist "Kaufen unter") einmalig übernehmen
function Sn:ImportOld()
    local db = DB()
    if not db or db.imported then return end
    db.imported = true
    for itemID, w in pairs(A.db.watchlist or {}) do
        if w.buyBelow and w.buyBelow > 0 and not db.targets["i:" .. itemID] then
            db.targets["i:" .. itemID] = {
                kind = "item", itemID = itemID, key = "i:" .. itemID,
                maxPrice = w.buyBelow, qty = 1, budget = w.buyBelow,
                bought = 0, spent = 0, qMin = 0, qMax = 4, added = time(),
            }
        end
    end
end

-- ------------------------------------------------------------
-- Filter: Seltenheit, Itemlevel, Stufe
-- ------------------------------------------------------------
local function InRange(value, min, max)
    if value == nil then return true end          -- unbekannt: nicht ausfiltern
    if min and value < min then return false end
    if max and value > max then return false end
    return true
end

-- item: itemID oder itemLink. ilvl: Itemlevel des Angebots (falls bekannt)
-- Rückgabe: passt (bool), Qualität, Itemlevel, Stufe
function Sn:ItemPasses(t, item, ilvl)
    local quality, itemLevel, reqLevel
    if GetItemInfo and item then
        local ok, name, _, q, il, req = pcall(GetItemInfo, item)
        if ok and name then quality, itemLevel, reqLevel = q, il, req end
    end
    if ilvl and ilvl > 0 then itemLevel = ilvl end
    local set = self:QualSet(t)
    local pass = (quality == nil or set == nil or set[quality] == true)
        and InRange(itemLevel, t.ilvlMin, t.ilvlMax)
        and InRange(reqLevel, t.lvlMin, t.lvlMax)
    return pass, quality, itemLevel, reqLevel
end

local function ListingItemLevel(link)
    if not link then return nil end
    if GetDetailedItemLevelInfo then
        local lvl = SafeCall(GetDetailedItemLevelInfo, link)
        if lvl and lvl > 0 then return lvl end
    end
    return nil
end

-- ------------------------------------------------------------
-- API
-- ------------------------------------------------------------
function Sn:CheckAPI()
    local C = A.AH
    return {
        SendSearchQuery = C ~= nil and C.SendSearchQuery ~= nil,
        SendBrowseQuery = C ~= nil and C.SendBrowseQuery ~= nil,
        CommodityResults = C ~= nil and C.GetCommoditySearchResultInfo ~= nil,
        ItemResults = C ~= nil and C.GetItemSearchResultInfo ~= nil,
        PlaceBid = C ~= nil and C.PlaceBid ~= nil,
        CommodityBuy = C ~= nil and C.StartCommoditiesPurchase ~= nil and C.ConfirmCommoditiesPurchase ~= nil,
        Bindings = SetOverrideBindingClick ~= nil and ClearOverrideBindings ~= nil,
    }
end

local function MakeKey(itemID)
    if A.AH.MakeItemKey then
        local ok, key = pcall(A.AH.MakeItemKey, itemID)
        if ok and key then return key end
    end
    return { itemID = itemID, itemLevel = 0, itemSuffix = 0, battlePetSpeciesID = 0 }
end

local SORTS = { { sortOrder = 0, reverseSort = false } }

local function QualityFilters(t)
    local out = {}
    local set = Sn:QualSet(t)
    if not set then return out end
    if not (Enum and Enum.AuctionHouseFilter) then return out end
    for q = 0, 4 do
        local v = set[q] and Enum.AuctionHouseFilter[Sn.QUALITY[q].filter]
        if v then table.insert(out, v) end
    end
    return out
end

-- Angebote eines Items lesen
local function ReadListings(t, itemID, key)
    local C = A.AH
    local listings = {}
    local commodity = false

    local nCom = SafeCall(C.GetNumCommoditySearchResults, itemID) or 0
    if nCom > 0 then
        commodity = true
        local pass, quality, ilvl = Sn:ItemPasses(t, itemID)
        for i = 1, nCom do
            local info = SafeCall(C.GetCommoditySearchResultInfo, itemID, i)
            if type(info) == "table" and info.unitPrice and info.unitPrice > 0 then
                table.insert(listings, {
                    price = info.unitPrice, qty = info.quantity or 1,
                    own = info.containsOwnerItem or false,
                    pass = pass, quality = quality, ilvl = ilvl, commodity = true,
                })
            end
        end
    else
        local nItem = SafeCall(C.GetNumItemSearchResults, key) or 0
        for i = 1, nItem do
            local info = SafeCall(C.GetItemSearchResultInfo, key, i)
            if type(info) == "table" and info.buyoutAmount and info.buyoutAmount > 0 then
                local qty = info.quantity or 1
                local pass, quality, ilvl = Sn:ItemPasses(t, info.itemLink or itemID, ListingItemLevel(info.itemLink))
                table.insert(listings, {
                    price = math.floor(info.buyoutAmount / math.max(1, qty)),
                    buyout = info.buyoutAmount, qty = qty,
                    auctionID = info.auctionID,
                    own = info.containsOwnerItem or false,
                    pass = pass, quality = quality, ilvl = ilvl, commodity = false,
                })
            end
        end
    end
    table.sort(listings, function(a, b) return a.price < b.price end)
    if commodity then A:MarkBait(listings) end
    return listings, commodity
end

local function ItemResultsFull(itemID, key)
    local C = A.AH
    if SafeCall(C.HasFullCommoditySearchResults, itemID) then return true end
    return SafeCall(C.HasFullItemSearchResults, key) == true
end

-- ------------------------------------------------------------
-- Suche (eine Suche pro Ziel, nacheinander)
-- ------------------------------------------------------------
function Sn:IsBusy()
    return self.search ~= nil
end

function Sn:CanSearch()
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    if self.search then return false, L["Suche läuft noch ..."], true end
    local p = self.pending
    if p and not (p.auto and p.state == "ready") then return false, L["Erst den laufenden Kauf bestätigen."], true end
    -- S2/T-SR4: nur der normale Markt-Scan blockiert; der Schnell-Vollscan (ReplicateItems) nicht
    if A:IsScanning(true) then return false, L["Warte, bis der Markt-Scan fertig ist."] end
    if A.Seller and A.Seller:IsBusy() then return false, L["Suche läuft noch ..."], true end
    if A.Seller and A.Seller.HasUrgent and A.Seller:HasUrgent() then return false, L["Suche läuft noch ..."], true end
    if A.Watcher and A.Watcher:IsBusy() then return false, L["Suche läuft noch ..."], true end
    if A.Buy and A.Buy:Blocks() then return false, L["Suche läuft noch ..."], true end
    if not A:CanQueryNow("sniper") then
        return false, L["Kurz warten (max. eine Suche alle "] .. string.format("%.1f", A:QueryGap()) .. L[" Sek.)."], true
    end
    if not (A.AH and A.AH.SendSearchQuery) then
        return false, L["Dein Client unterstützt keine Einzel-Suche (SendSearchQuery fehlt)."]
    end
    return true
end

local function StartItemStage(s, itemID, key)
    local ok, err = pcall(A.AH.SendSearchQuery, key, SORTS, false)
    A:NoteQuery()
    if not ok then A:QueryError(); return false, L["Suche fehlgeschlagen: "] .. tostring(err) end
    s.stage, s.itemID, s.key = "items", itemID, key
    s.started, s.lastCount, s.lastChange, s.answered = Now(), -1, Now(), false
    return true
end

function Sn:Search(targetKey)
    local t = self:GetTarget(targetKey)
    if not t then return false, L["Ziel nicht gefunden."] end
    local ok, msg, soft = self:CanSearch()
    if not ok then return false, msg, soft end

    local s = { targetKey = targetKey }
    if t.kind == "item" then
        local okStart, err = StartItemStage(s, t.itemID, MakeKey(t.itemID))
        if not okStart then return false, err end
    else
        if not A.AH.SendBrowseQuery then
            return false, L["Suchbegriffe brauchen SendBrowseQuery - fehlt in deinem Client. Bitte Item-Name oder ID nutzen."]
        end
        local query = {
            searchString = t.text,
            sorts = SORTS,
            filters = QualityFilters(t),
            itemClassFilters = {},
            minLevel = t.lvlMin or 0,
            maxLevel = t.lvlMax or 0,
        }
        local okQ, err = pcall(A.AH.SendBrowseQuery, query)
        A:NoteQuery()
        if not okQ then A:QueryError(); return false, L["Suche fehlgeschlagen: "] .. tostring(err) end
        s.stage, s.started, s.lastCount, s.lastChange, s.answered = "browse", Now(), -1, Now(), false
    end

    self.search = s
    self.lastSearch = Now()
    self.current = targetKey
    A:Fire("SNIPER_CHANGED")
    return true, L["Suche: "] .. self:TargetName(t) .. " ..."
end

-- wird regelmäßig aufgerufen, solange eine Suche läuft
function Sn:PollSearch()
    local s = self.search
    if not s then return end
    local t = self:GetTarget(s.targetKey)
    if not t or not A:IsAHOpen() then
        self.search = nil
        A:Fire("SNIPER_CHANGED")
        return
    end

    if s.stage == "browse" then
        local results = SafeCall(A.AH.GetBrowseResults) or {}
        local count = #results
        local now = Now()
        if count ~= s.lastCount then s.lastCount, s.lastChange = count, now end
        local full = SafeCall(A.AH.HasFullBrowseResults)
        local timedOut = now - s.started > TIMEOUT
        if not ((count > 0 and (full or now - s.lastChange >= 0.75)) or (s.answered and count == 0 and now - s.lastChange >= 0.5) or timedOut) then return end

        -- passende Items heraussuchen
        local candidates = {}
        for _, r in ipairs(results) do
            local ik = r.itemKey
            if ik and ik.itemID and r.minPrice and r.minPrice > 0 and r.minPrice <= t.maxPrice then
                local pass = self:ItemPasses(t, ik.itemID, (ik.itemLevel or 0) > 0 and ik.itemLevel or nil)
                if pass then table.insert(candidates, { itemKey = ik, minPrice = r.minPrice }) end
            end
        end
        table.sort(candidates, function(a, b) return a.minPrice < b.minPrice end)
        s.candidates = #candidates
        if #candidates == 0 then
            self:FinishSearch(nil, {}, false, 0)
            return
        end
        -- günstigsten Kandidaten genauer ansehen (Einzelangebote)
        local c = candidates[1]
        if not A:QueryReady() then return end      -- Server-Drossel: gleich nochmal
        local okStart = StartItemStage(s, c.itemKey.itemID, c.itemKey)
        if not okStart then self:FinishSearch(nil, {}, false, #candidates) end
        return
    end

    -- Stufe "items": Angebote lesen
    local okRead, listings, commodity = pcall(ReadListings, t, s.itemID, s.key)
    if not okRead then listings, commodity = {}, false end
    local count = #listings
    local now = Now()
    if count ~= s.lastCount then s.lastCount, s.lastChange = count, now end
    local full = ItemResultsFull(s.itemID, s.key)
    local timedOut = now - s.started > TIMEOUT
    local done = (full and (count > 0 or s.answered or now - s.started >= 1))
        or (count > 0 and now - s.lastChange >= 0.75)
        or timedOut
    if done then
        if timedOut and count == 0 then A:QueryError() end
        self:FinishSearch(s.itemID, listings, commodity, s.candidates)
    end
end

-- Signal (wiederholt, solange der Treffer da ist) und Chat-Meldung (nur bei neuem Treffer)
function Sn:Alert(plan, fresh)
    local now = Now()
    local id = plan.itemID .. ":" .. plan.qty .. ":" .. (plan.total or 0)
    if fresh and (id ~= self.lastAlertID or now - (self.lastPrint or -100) >= PRINT_REPEAT) then
        A:Print(L["|cff33dd55Treffer:|r "] .. plan.qty .. "x " .. A:GetItemName(plan.itemID) .. L[" für "] .. A:FormatMoney(plan.total)
            .. " - " .. self:GetBindsText() .. L[" zum Kaufen"])
        self.lastPrint = now
    end
    if fresh and id ~= self.lastAlertID and self.Signal then pcall(self.Signal, self, plan) end     -- SG1: neuer Treffer
    if A.db.settings.alertSound and PlaySound and (id ~= self.lastAlertID or now - (self.lastSound or -100) >= ALERT_REPEAT) then
        pcall(PlaySound, 8959)
        self.lastSound = now
    end
    self.lastAlertID = id
end

-- S5 (Wunsch des Nutzers 10.11. 16:28): "Kauf fehlgeschlagen" nur EINMAL - je Angebot (auctionID) höchstens einmal,
-- weitere Fehlschläge höchstens alle FAIL_GAP Sekunden als Sammelzeile; danach gleich zum nächsten passenden Angebot
Sn.FAIL_GAP = 30
Sn.failSeen = Sn.failSeen or {}
function Sn:ReportFail(auctionID, text)
    if auctionID then
        if self.failSeen[auctionID] then return false end
        self.failSeen[auctionID] = true
    end
    local now = Now()
    if now - (self.failLast or -1000) >= self.FAIL_GAP then
        self.failLast, self.failMore = now, 0
        A:Print(text or L["|cffff5544Kauf fehlgeschlagen|r (Angebot weg oder nicht genug Gold)."])
        if C_Timer and C_Timer.After then
            C_Timer.After(self.FAIL_GAP, function() Sn:FlushFails() end)
        end
        return true
    end
    self.failMore = (self.failMore or 0) + 1
    return false
end
-- S6 (Nachtrag 10.11. 17:00): tote Angebote je auctionID für DEAD_TTL sperren (der Server liefert sie aus dem
-- Zwischenspeicher noch einmal); eine neue auctionID zum gleichen Preis bleibt kaufbar. Waren ohne auctionID:
-- gleiche Kombination Item+Preis+Menge DEAD_COMMODITY_TTL überspringen.
Sn.DEAD_TTL = 600
Sn.DEAD_COMMODITY_TTL = 60
Sn.dead = Sn.dead or {}
Sn.deadCommodity = Sn.deadCommodity or {}
Sn.deadRedelivered = Sn.deadRedelivered or 0
-- S7e: Fehlschläge mit verschiedenen auctionIDs beim gleichen Item zählen; ab PAUSE_FAILS das Item PAUSE_TIME pausieren
Sn.PAUSE_FAILS = 3
Sn.PAUSE_TIME = 600
Sn.failIDs = Sn.failIDs or {}
Sn.itemPause = Sn.itemPause or {}
function Sn:MarkDead(listing, itemID, why)
    if not listing then return end
    listing.gone = true
    if listing.auctionID then
        self.dead[listing.auctionID] = Now() + self.DEAD_TTL
    elseif itemID and listing.price then
        self.deadCommodity[itemID .. ":" .. listing.price .. ":" .. (listing.qty or 0)] = Now() + self.DEAD_COMMODITY_TTL
    end
    -- S7a/c: ausblenden (Einzelangebot sofort, Ware nach 2 Fehlschlägen)
    A:HideDeadOffer(itemID, listing.auctionID, listing.price, listing.qty, why or "Kauf fehlgeschlagen")
    if itemID and listing.auctionID then
        local set = self.failIDs[itemID] or {}
        self.failIDs[itemID] = set
        if not set[listing.auctionID] then
            set[listing.auctionID] = true
            local n = 0
            for _ in pairs(set) do n = n + 1 end
            if n >= self.PAUSE_FAILS and not self:ItemPaused(itemID) then
                self.itemPause[itemID] = Now() + self.PAUSE_TIME
                self.failIDs[itemID] = {}
                if A.Diag then pcall(A.Diag.Add, A.Diag, "SNIPER-PAUSE", string.format("Item %s · %d verschiedene Angebote gescheitert · %d Min. pausiert",
                    tostring(itemID), n, math.floor(self.PAUSE_TIME / 60))) end
                A:Print(string.format(L["Sniper: %d Käufe beim gleichen Item gescheitert - Item %d Min. pausiert."], n, math.floor(self.PAUSE_TIME / 60)))
            end
        end
    end
end
function Sn:ItemPaused(itemID)
    local u = itemID and self.itemPause[itemID]
    if u and u > Now() then return true end
    if u then self.itemPause[itemID] = nil end
    return false
end
-- S7d: Hinweis für die Statuszeile ("1 totes Angebot ausgeblendet") und Tooltip (Preis und Grund)
function Sn:HiddenNote(r)
    r = r or self.result
    local n = r and r.hidden and #r.hidden or 0
    if n == 0 then return nil end
    local tip = {}
    for _, e in ipairs(r.hidden) do
        local d = e.auctionID and A.deadOffers.ids[e.auctionID] or nil
        tip[#tip + 1] = A:FormatMoney(e.price or 0) .. " · " .. tostring(d and d.why or L["Kauf fehlgeschlagen"])
    end
    return string.format(n == 1 and L["%d totes Angebot ausgeblendet"] or L["%d tote Angebote ausgeblendet"], n), tip
end
-- Statuszeile ohne Treffer: "Günstigstes" nur aus sichtbaren Angeboten, dazu der Hinweis
function Sn:NothingText(r)
    r = r or self.result
    local first
    for _, l in ipairs(r and r.listings or {}) do if not l.gone and not l.bait then first = l; break end end
    first = first or (r and r.listings[1])
    local txt
    if first then txt = L["Nichts Passendes unter deinem Max-Preis. Günstigstes: "] .. A:FormatMoney(first.price)
    else txt = L["|cffaaaaaaKeine Angebote gefunden.|r"] end
    -- MP2: Entzauber-Ziel mit veralteten Materialpreisen -> kein Kauf, Grund sichtbar
    if r and r.staleNote then txt = "|cffff9933" .. r.staleNote .. " – " .. L["erst scannen"] .. "|r · " .. txt end
    local note, tip = self:HiddenNote(r)
    if note then
        if #tip <= 2 then note = note .. " (" .. table.concat(tip, ", ") .. ")" end
        txt = txt .. " · |cff888888" .. note .. "|r"
    end
    return txt
end
-- neue Suchergebnisse: tote Angebote wieder als "weg" markieren; Anzahl der wieder gelieferten zählen
function Sn:ApplyDead(itemID, listings)
    local now, n = Now(), 0
    for _, l in ipairs(listings or {}) do
        local exp
        if l.auctionID then exp = self.dead[l.auctionID]
        elseif itemID and l.price then exp = self.deadCommodity[itemID .. ":" .. l.price .. ":" .. (l.qty or 0)] end
        if exp and exp > now then
            l.gone = true; n = n + 1
            A:HideDeadOffer(itemID, l.auctionID, l.price, l.qty, "nach weg wieder geliefert")   -- S7a
        end
    end
    if n > 0 then self.deadRedelivered = self.deadRedelivered + n end
    return n
end

function Sn:FlushFails()
    local n = self.failMore or 0
    self.failMore = 0
    if n > 0 then
        A:Print(string.format(L["%d weitere Angebote waren schon weg - der Sniper sucht weiter."], n))
        self.failLast = Now()
    end
    return n
end

function Sn:FinishSearch(itemID, listings, commodity, candidates)
    local s = self.search
    self.search = nil
    if not s then return end
    local t = self:GetTarget(s.targetKey)
    if not t then A:Fire("SNIPER_CHANGED"); return end

    A:CleanDeadOffers()                                            -- Hinweis 6e: abgelaufene Einträge entfernen
    do local now = Now()
        for k, e in pairs(self.dead) do if e <= now then self.dead[k] = nil end end
        for k, e in pairs(self.deadCommodity) do if e <= now then self.deadCommodity[k] = nil end end
    end
    local deadAgain = self:ApplyDead(itemID, listings)             -- S6
    local _, hidden = A:FilterDead(itemID, listings)               -- S7: tote Angebote ganz aus der Liste
    local newResult = {
        key = s.targetKey, itemID = itemID, listings = listings or {}, hidden = hidden,
        commodity = commodity, time = Now(), stamp = time(), candidates = candidates,
        missedStart = self:Stats().missed or 0,          -- SN1: verpasst in dieser Suche
    }
    -- S2/S4: Stand der Selbst-Suche und Protokoll SNIPER-SUCHE (ohne Namen), je Ziel höchstens einmal je Minute
    local hits = 0
    for _, l in ipairs(newResult.listings) do if not l.own and not l.bait and not l.gone and l.price and t.maxPrice and l.price <= t.maxPrice then hits = hits + 1 end end
    self.lastDone = { time = Now(), hits = hits, n = #newResult.listings }
    self.diagAt = self.diagAt or {}
    if A.Diag and Now() - (self.diagAt[s.targetKey] or -1000) >= 60 then
        self.diagAt[s.targetKey] = Now()
        pcall(A.Diag.Add, A.Diag, "SNIPER-SUCHE", string.format("Ziel %s · Angebote %d · Treffer ≤ Max %d · gekauft %d · Sperre %s · tot wieder geliefert %d (Sitzung %d)",
            tostring(itemID or "?"), #newResult.listings, hits, t.bought or 0, tostring(self.waitReason or "-"), deadAgain, self.deadRedelivered))
    end
    -- ein kaufbarer Treffer eines ANDEREN Ziels bleibt stehen, bis ein neuer Treffer kommt
    -- (die Suche läuft weiter, der Treffer bleibt per Mausrad/Taste kaufbar)
    local keep = self.result
    local keepHit = keep and keep.key ~= s.targetKey and keep.itemID and self:IsResultFresh() and self.hasPlan
    local prevResult = self.result
    self.result = newResult
    t.checked = time()

    -- günstigsten echten Preis (ohne Lockangebote) in den Preisverlauf
    local first
    for _, l in ipairs(listings or {}) do if not l.bait then first = l; break end end
    if itemID and first then
        local totalQty = 0
        for _, l in ipairs(listings) do if not l.bait then totalQty = totalQty + l.qty end end
        A:VerifyPrice(itemID, first.price, totalQty)
    end

    local plan = self:PlanNext()
    t.found = plan and plan.qty or 0
    if not plan and keepHit then
        -- nichts Neues: alten Treffer wieder anzeigen (bleibt kaufbar)
        self.result = prevResult
        plan = self:PlanNext()
        self.hasPlan = plan ~= nil
        if plan and not t.watch then self:Alert(plan, false) end
        A:Fire("SNIPER_CHANGED")
        A:Fire("DATA_CHANGED")
        return
    end
    self.hasPlan = plan ~= nil
    -- D1: Treffer messen; ohne Kauf verschwundener Treffer = "weg"
    if plan and not t.watch then
        self:MeterHit(t, s.started)
    elseif not plan and self.episode and self.episode.key == t.key and not self.pending and not self.inFlight then
        self:MeterEnd("weg")
    end
    if t.watch then
        if A.Watcher then A.Watcher:OnVerified(t, plan, self.result) end
    elseif plan then
        self:Alert(plan, true)
    end

    A:Fire("SNIPER_CHANGED")
    A:Fire("DATA_CHANGED")
end

-- ------------------------------------------------------------
-- D MESSEN (Anweisung 17:35): je Treffer die Zeiten Suche->Treffer, Treffer->Reservierung, Reservierung->bereit,
-- bereit->bestätigt, bestätigt->Kauf bestätigt und das Ergebnis (gekauft / weg / gestiegen / Fehler / abgelaufen).
-- Tageszahlen in db.stats, je Ziel hitN/boughtN, Protokoll gebündelt (eine Zeile je Minute, keine Namen).
-- ------------------------------------------------------------
Sn.MISS_KINDS = { weg = true, gestiegen = true, Fehler = true, abgelaufen = true }
Sn.HIT_WINDOW = 600              -- B2: Treffer der letzten 10 Min. zählen fürs Gewicht
Sn.hitTimes = {}                 -- [key] = { Zeitpunkte }
Sn.meterBuf = { n = 0, out = {}, sums = {}, cnt = {}, last = 0 }

local function Today() return A:DayStart(time()) end
function Sn:Stats()
    local db = DB()
    if not db then return { hits = 0, bought = 0, missed = 0, reactSum = 0, reactN = 0 } end
    local st = db.stats
    if type(st) ~= "table" or st.day ~= Today() then
        st = { day = Today(), hits = 0, bought = 0, missed = 0, reactSum = 0, reactN = 0 }
        -- Testroutine: nur lesen (Anzeige), die echten Tageszahlen nicht anlegen (Sandbox, Befund 22:25 "sniper.stats")
        if A.TestRoutine and A.TestRoutine.running and not self.testMeter then return st end
        db.stats = st
    end
    return st
end

-- Treffer beginnt (eigenes Ziel, Suche fand einen Kauf)
function Sn:MeterHit(t, searchStarted)
    if not t or t.watch then return end
    -- Testroutine: Treffer der Test-Suchen nicht in die echten Tageszahlen (Sandbox, Befund 22:25 "sniper.stats")
    if A.TestRoutine and A.TestRoutine.running and not self.testMeter then return end
    local ep = self.episode
    if ep and ep.key == t.key then return end                -- derselbe Treffer, nur neu gesucht
    if ep then self:MeterEnd("weg") end
    self.episode = { key = t.key, tSearch = searchStarted, tHit = Now() }
    local st = self:Stats()
    st.hits = st.hits + 1
    t.hitN = (t.hitN or 0) + 1
    local list = self.hitTimes[t.key] or {}
    list[#list + 1] = Now()
    self.hitTimes[t.key] = list
end

function Sn:MeterMark(field)
    local ep = self.episode
    if ep and not ep[field] then ep[field] = Now() end
end

-- Treffer endet mit Ergebnis
function Sn:MeterEnd(result)
    local ep = self.episode
    if not ep then return end
    self.episode = nil
    local st = self:Stats()
    local t = self:GetTarget(ep.key)
    if result == "gekauft" then
        st.bought = st.bought + 1
        if t then t.boughtN = (t.boughtN or 0) + 1 end
        if ep.tConfirm then st.reactSum = st.reactSum + (ep.tConfirm - ep.tHit); st.reactN = st.reactN + 1 end
    elseif self.MISS_KINDS[result] then
        st.missed = st.missed + 1
    end
    local b = self.meterBuf
    b.n = b.n + 1
    b.out[result] = (b.out[result] or 0) + 1
    local function add(name, a, z)
        if a and z and z >= a then
            b.sums[name] = (b.sums[name] or 0) + (z - a) * 1000
            b.cnt[name] = (b.cnt[name] or 0) + 1
        end
    end
    add("Suche>Treffer", ep.tSearch, ep.tHit)
    add("Treffer>Reserv.", ep.tHit, ep.tReserve)
    add("Reserv.>bereit", ep.tReserve, ep.tReady)
    add("bereit>bestätigt", ep.tReady, ep.tConfirm)
    add("bestätigt>gekauft", ep.tConfirm, ep.tDone)
    self.lastEpisode = { result = result, times = {
        ep.tSearch and ep.tHit and (ep.tHit - ep.tSearch) or nil, ep.tReserve and (ep.tReserve - ep.tHit) or nil,
        ep.tReady and ep.tReserve and (ep.tReady - ep.tReserve) or nil, ep.tConfirm and ep.tReady and (ep.tConfirm - ep.tReady) or nil,
        ep.tDone and ep.tConfirm and (ep.tDone - ep.tConfirm) or nil } }
end

-- eine Protokollzeile je Minute
function Sn:MeterFlush(force)
    local b = self.meterBuf
    if b.n == 0 or (not force and Now() - b.last < 60) then return end
    local parts = {}
    for _, k in ipairs({ "gekauft", "weg", "gestiegen", "Fehler", "abgelaufen" }) do
        if b.out[k] then parts[#parts + 1] = k .. " " .. b.out[k] end
    end
    local times = {}
    for _, k in ipairs({ "Suche>Treffer", "Treffer>Reserv.", "Reserv.>bereit", "bereit>bestätigt", "bestätigt>gekauft" }) do
        if b.cnt[k] then times[#times + 1] = string.format("%s %d ms", k, math.floor(b.sums[k] / b.cnt[k] + 0.5)) end
    end
    if A.Diag then A.Diag:Add("SNIPER", string.format("Treffer %d · %s · Ø %s", b.n, table.concat(parts, ", "), table.concat(times, ", "))) end
    self.meterBuf = { n = 0, out = {}, sums = {}, cnt = {}, last = Now() }
end

-- D2: "Heute: N Treffer · N gekauft · N verpasst · Ø Reaktion X s"
function Sn:StatsText()
    local st = self:Stats()
    local react = st.reactN > 0 and string.format("%.1f", st.reactSum / st.reactN) or "-"
    return string.format(L["Heute: %d Treffer · %d gekauft · %d verpasst · Ø Reaktion %s s"], st.hits, st.bought, st.missed, react)
end

-- D3: viele Treffer, wenig gekauft -> andere sind schneller
function Sn:OthersFaster(t)
    local h, b = t and t.hitN or 0, t and t.boughtN or 0
    return h >= 10 and b / h < 0.20
end

-- B2: Gewicht eines Ziels = 1 + Treffer der letzten 10 Min.; ohne Treffer seit 10 Min. nur jede dritte Runde
function Sn:TargetWeight(t, now)
    now = now or Now()
    local list = self.hitTimes[t.key]
    local n = 0
    if list then
        local keep = {}
        for _, x in ipairs(list) do if now - x <= self.HIT_WINDOW then keep[#keep + 1] = x; n = n + 1 end end
        self.hitTimes[t.key] = keep
    end
    if n == 0 then return 1 / 3 end
    return 1 + n
end

-- Nächstes offenes Ziel suchen
-- Wartet ein kaufbarer Treffer auf Mausrad/Taste?
function Sn:HitWaiting()
    if self.pending then return true end
    return self:IsResultFresh() and self.hasPlan and self.result and self.result.itemID ~= nil or false
end

-- Ist der Sniper mit Suchen dran? (Wächter wechselt sich mit ihm ab)
function Sn:WantsTurn()
    if not self:IsArmed() or self.search then return false end
    if self.pending and not (self.pending.auto and self.pending.state == "ready") then return false end
    if #self:GetActiveTargets() == 0 then return false end
    for _, t in pairs(self.extra) do if not t.checked then return true end end            -- neues Wächter-Schnäppchen
    return Now() - self.lastSearch >= math.max(MIN_INTERVAL, DB().interval or 0)
end

function Sn:CheckNext()
    local targets = self:GetActiveTargets()
    if #targets == 0 then
        return false, L["Keine offenen Ziele. Lege oben ein Ziel an (oder alle Ziele sind erfüllt)."]
    end
    local ok, msg, soft = self:CanSearch()
    if not ok then return false, msg, soft end
    -- neue Schnäppchen des Wächters haben Vorrang
    for _, e in ipairs(targets) do
        if e.watch and not e.checked then return self:Search(e.key) end
    end
    return self:Search(self:PickTarget(targets).key)
end

-- B2: gewichtete Reihenfolge (glatt verteilt, kein Ziel fällt heraus)
Sn.credit = {}
function Sn:PickTarget(targets)
    local now, best, total = Now(), nil, 0
    for _, e in ipairs(targets) do
        local w = self:TargetWeight(e, now)
        total = total + w
        self.credit[e.key] = (self.credit[e.key] or 0) + w
        if not best or self.credit[e.key] > self.credit[best.key] then best = e end
    end
    self.credit[best.key] = self.credit[best.key] - total
    return best
end

-- ------------------------------------------------------------
-- Kaufplanung: was kauft der nächste Tastendruck?
-- ------------------------------------------------------------
function Sn:IsResultFresh()
    local r = self.result
    if not r then return false end
    return (Now() - r.time) <= (r.commodity and RESULT_FRESH_COMMODITY or RESULT_FRESH)
end

-- Markiert jedes Angebot mit einem Status und liefert den nächsten Kauf
-- MP2: Ziel hängt am Entzauberwert und das Hauptmaterial ist veraltet -> nicht kaufen
function Sn:DEStale(t, itemID)
    local D = A.Disenchant
    if not (D and D.StaleMain and itemID and D:Prior(itemID)) then return false end
    if not t.de then
        local sell = A:RealValue(itemID, 1)
        if sell and sell >= (t.maxPrice or 0) then return false end      -- Höchstpreis schon durch den Verkauf gedeckt
        -- nur sperren, wenn der Entzauberwert den Höchstpreis trägt (ohne Entzauberwert: normales Ziel)
        local okV, dv = pcall(D.DealValue, D, itemID)
        if not (okV and dv and dv > (sell or 0)) then return false end
    end
    local ok, stale = pcall(D.StaleMain, D, itemID)
    return ok and stale or false
end
function Sn:PlanNext()
    local r = self.result
    if not r or not r.itemID then return nil end
    local t = self:GetTarget(r.key)
    if not t then return nil end
    if self:DEStale(t, r.itemID) then
        self.staleBlock = r.itemID
        r.staleNote = L["Materialpreise veraltet"]
        return nil
    end
    local qtyLeft, budgetLeft = self:Remaining(t)
    local money = GetMoney and GetMoney() or math.huge
    local limit = math.min(budgetLeft, money)

    for _, l in ipairs(r.listings) do l.status, l.planned = nil, nil end

    if r.commodity then
        -- Lockangebote: lösen nichts aus, werden aber bei einem echten Treffer
        -- vom Server zuerst verkauft (günstigste Stücke zuerst) - also einrechnen
        local takeQty, takeCost, realQty = 0, 0, 0
        for _, l in ipairs(r.listings) do
            local avail = l.qty - (l.used or 0)
            if l.gone then
                l.status = "weg"                       -- S6: tote Ware (60 s gesperrt)
            elseif l.bait and avail > 0 then
                l.status = "Lockangebot"
                if l.price <= t.maxPrice and takeQty < qtyLeft and takeCost + l.price <= limit then
                    local n = math.min(avail, qtyLeft - takeQty)
                    takeQty, takeCost = takeQty + n, takeCost + n * l.price
                    l.planned = n
                end
            elseif avail <= 0 then
                l.status = "gekauft"
            elseif l.own then
                l.status = "eigenes"
            elseif not l.pass then
                l.status = "Filter"
            elseif l.price > t.maxPrice then
                l.status = "zu teuer"
            elseif takeQty >= qtyLeft then
                l.status = "Menge erreicht"
            else
                local n = math.min(avail, qtyLeft - takeQty)
                n = math.min(n, math.floor((limit - takeCost) / l.price))
                if n <= 0 then
                    l.status = (money < budgetLeft) and "zu wenig Gold" or "über Budget"
                else
                    takeQty = takeQty + n
                    takeCost = takeCost + n * l.price
                    realQty = realQty + n
                    l.planned = n
                    l.status = "kaufbar"
                end
            end
        end
        if realQty > 0 then
            return { kind = "commodity", key = r.key, itemID = r.itemID, qty = takeQty, total = takeCost, bait = takeQty - realQty }
        end
        -- nur Lockangebote unter dem Max-Preis: kein Treffer
        for _, l in ipairs(r.listings) do l.planned = nil end
        return nil
    end

    local plan
    for _, l in ipairs(r.listings) do
        if l.used and l.used > 0 then
            l.status = "gekauft"
        elseif l.gone then
            l.status = "weg"                           -- S5: Kauf fehlgeschlagen, nicht erneut versuchen
        elseif l.own then
            l.status = "eigenes"
        elseif not l.pass then
            l.status = "Filter"
        elseif l.price > t.maxPrice then
            l.status = "zu teuer"
        elseif l.qty > qtyLeft then
            l.status = "Stapel zu groß"
        elseif l.buyout > limit then
            l.status = (l.buyout > money) and "zu wenig Gold" or "über Budget"
        elseif not l.auctionID then
            l.status = "keine ID"
        else
            l.status = "kaufbar"
            if not plan then
                l.planned = l.qty
                plan = { kind = "item", key = r.key, itemID = r.itemID, qty = l.qty, total = l.buyout, listing = l }
            end
        end
    end
    return plan
end

-- Gesamtmenge, die bei diesem Item insgesamt gekauft wird (bis Ziel-Menge / Budget / Gold reichen)
-- Rückgabe: Stück, Kosten, Anzahl Käufe (Rasten) - oder nil
function Sn:PlanTotal()
    local r = self.result
    if not (r and r.itemID) then return nil end
    local t = self:GetTarget(r.key)
    if not t then return nil end
    local plan = self:PlanNext()
    if not plan then return nil end
    if r.commodity then return plan.qty, plan.total, 1 end     -- Waren: ein Kauf über alles
    local qLeft, bLeft = self:Remaining(t)
    local money = GetMoney and GetMoney() or math.huge
    local limit = math.min(bLeft, money)
    local qty, cost, n = 0, 0, 0
    for _, l in ipairs(r.listings) do
        if l.status == "kaufbar" or l.planned then
            if qty + l.qty <= qLeft and cost + l.buyout <= limit then
                qty, cost, n = qty + l.qty, cost + l.buyout, n + 1
            end
        end
    end
    if qty == 0 then return nil end
    return qty, cost, n
end

-- ------------------------------------------------------------
-- Kaufen (nur durch Tastendruck / Mausrad / Klick)
-- ------------------------------------------------------------
local function CountPurchase(t, qty, cost)
    t.bought = (t.bought or 0) + qty
    t.spent = (t.spent or 0) + cost
end

function Sn:Buy(plan)
    if not self:HardwareOK() then return false, L["Kaufen nur per Taste oder Mausrad."] end
    local t = self:GetTarget(plan.key)
    if not t then return false, L["Ziel nicht gefunden."] end
    local name = A:GetItemName(plan.itemID)
    local C = A.AH

    if plan.kind == "item" then
        if not C.PlaceBid then return false, L["Dein Client unterstützt keinen Sofortkauf (PlaceBid fehlt)."] end
        -- vor dem Befehl merken: der Testmodus erkennt daran den Sniper-Kauf (statt eines Gebots)
        self.buying = { auctionID = plan.listing.auctionID, cost = plan.total }
        local ok, err = pcall(C.PlaceBid, plan.listing.auctionID, plan.total)
        self.buying = nil
        if not ok then return false, L["Kauf fehlgeschlagen: "] .. tostring(err) end
        plan.listing.used = plan.qty
        CountPurchase(t, plan.qty, plan.total)
        self:MeterMark("tReserve"); self:MeterMark("tReady"); self:MeterMark("tConfirm"); self:MeterMark("tDone")
        self:MeterEnd("gekauft")
        self.lastPurchase = { key = plan.key, itemID = plan.itemID, qty = plan.qty, cost = plan.total, time = Now(), listing = plan.listing }
        local msg = L["Gekauft: "] .. plan.qty .. "x " .. name .. L[" für "] .. A:FormatMoney(plan.total)
        A:Print(msg)
        self:AfterPurchase(t)
        return true, msg
    end

    -- Waren: Preis reservieren, Bestätigung mit dem nächsten Druck
    return self:Reserve(plan, false)
end

-- Sofortkauf mit einer Raste möglich? (abschaltbar, schaltet sich bei Problemen selbst ab)
-- Sofortkauf (vorab reservieren ohne Tastendruck) gibt es nicht mehr: Reservieren nur aus einem Tastendruck
-- (Anweisung 17:35). Waren immer mit 2 Rasten: 1. reserviert, 2. kauft.
function Sn:InstantEnabled()
    return false
end

-- Darf der Sniper Waren OHNE Tastendruck vorab reservieren? (C_AuctionHouse.StartCommoditiesPurchase)
-- WoW Forever erlaubt den Aufruf nur mit Tastendruck/Klick (ADDON_ACTION_BLOCKED, Befund 8. Nov.). Hat WoW den
-- Aufruf in diesem Client einmal geblockt, bleibt das gespeichert (je Interface-Nummer), auch über /reload hinaus.
local function Interface() return GetBuildInfo and tonumber((select(4, GetBuildInfo()))) or 0 end
function Sn:AutoReserveBlocked()
    if A:IsForever() then return true end
    local db = DB()
    return db ~= nil and db.instantBlocked ~= nil and db.instantBlocked == Interface()
end

-- Warenpreis beim Server reservieren.
-- auto = true: vom Sniper selbst beim Treffer (ohne Tastendruck), damit EINE Raste sofort kauft.
function Sn:Reserve(plan, auto)
    if not self:HardwareOK() then return false, L["Kaufen nur per Taste oder Mausrad."] end
    local C = A.AH
    local name = A:GetItemName(plan.itemID)
    if not (C.StartCommoditiesPurchase and C.ConfirmCommoditiesPurchase) then
        return false, L["Dein Client unterstützt keinen Warenkauf (StartCommoditiesPurchase fehlt)."]
    end
    local ok, err = pcall(C.StartCommoditiesPurchase, plan.itemID, plan.qty)
    if auto then A:NoteQuery() end
    if not ok then
        if auto then
            self:DisableInstant()
            return false
        end
        return false, L["Kauf fehlgeschlagen: "] .. tostring(err)
    end
    self:MeterMark("tReserve")
    self.pending = {
        key = plan.key, itemID = plan.itemID, qty = plan.qty,
        expected = plan.total, started = Now(), auto = auto or nil,
        state = self.priceEvents and "waiting" or "ready",
        total = (not self.priceEvents) and plan.total or nil,
    }
    if auto then
        A:Fire("SNIPER_CHANGED")
        return true
    end
    local msg
    if self.priceEvents then
        msg = L["Preis wird geprüft: "] .. plan.qty .. "x " .. name .. " ..."
    else
        msg = plan.qty .. "x " .. name .. L[" für ca. "] .. A:FormatMoney(plan.total) .. L[" - nochmal drücken zum Bestätigen"]
    end
    A:Print(msg)
    A:Fire("SNIPER_CHANGED")
    return true, msg
end

function Sn:Confirm()
    if not self:HardwareOK() then return false, L["Kaufen nur per Taste oder Mausrad."] end
    if A.Activity then pcall(A.Activity.PlayerAction, A.Activity) end      -- H9: Mausrad/Taste = Handlung
    local p = self.pending
    if not p then return false, L["Nichts zu bestätigen."] end
    if p.state ~= "ready" then
        -- A3 (17:35): Rasten in der Wartezeit still übergehen (keine Chat-Zeile, kein Ton); sie kaufen nie
        return false, nil, true
    end
    local t = self:GetTarget(p.key)
    self.pending = nil
    self:StopAlert()
    if not t then return false, L["Ziel nicht gefunden."] end
    self.confirming = p          -- für das Testmodus-Protokoll (Art und Preis des Kaufs)
    local ok, err = pcall(A.AH.ConfirmCommoditiesPurchase, p.itemID, p.qty)
    if not ok then
        A:Fire("SNIPER_CHANGED")
        return false, L["Kauf fehlgeschlagen: "] .. tostring(err)
    end
    local cost = p.total or p.expected
    self:MeterMark("tConfirm")
    -- S1: erst "gesendet"; gezählt und "Gekauft" gemeldet wird beim Erfolg (COMMODITY_PURCHASE_SUCCEEDED bzw. Rückfall
    -- nach 3 s: Gold weniger geworden), "Kauf fehlgeschlagen" bei Fehler - kein Zählen und Zurücknehmen mehr
    self.inFlight = { key = p.key, itemID = p.itemID, qty = p.qty, cost = cost, time = Now(),
        money = GetMoney and GetMoney() or nil }
    local sent = "|cff999999" .. L["Kauf gesendet: "] .. p.qty .. "x " .. A:GetItemName(p.itemID) .. L[" für "] .. A:FormatMoney(cost) .. "|r"
    A:Print(sent)
    if C_Timer and C_Timer.After then
        local fl = self.inFlight
        C_Timer.After(self.INFLIGHT_FALLBACK, function() Sn:InFlightFallback(fl) end)
    end
    A:Fire("SNIPER_CHANGED")
    return true, sent
end

Sn.INFLIGHT_FALLBACK = 3      -- Sekunden: ohne Erfolgs-/Fehlermeldung über das Gold entscheiden
Sn.INFLIGHT_MAX = 10          -- so lange gilt ein Fehler noch als Antwort auf den gesendeten Kauf

-- Rückfall: keine Meldung vom Server - ist das Gold weniger geworden, war der Kauf erfolgreich
function Sn:InFlightFallback(fl)
    if not fl or self.inFlight ~= fl then return end
    local now = GetMoney and GetMoney() or nil
    if now and fl.money and fl.money - now >= math.floor((fl.cost or 0) * 0.5) and fl.money > now then
        self:PurchaseSucceeded()
    elseif fl.errorSeen then
        -- AH-Fehler gesehen und kein Gold weg: der Kauf ist gescheitert
        self.inFlight = nil
        self:MeterEnd("Fehler")
        self:ReportFail(nil)
        A:Fire("SNIPER_CHANGED")
    end
end

-- Warenkauf vom Server bestätigt: jetzt zählen und melden
function Sn:PurchaseSucceeded()
    local p = self.inFlight
    if not p then return false end
    self.inFlight = nil
    self:MeterMark("tDone")
    self:MeterEnd("gekauft")
    local t = self:GetTarget(p.key)
    local cost = p.cost
    if t then CountPurchase(t, p.qty, cost) end
    -- gekaufte Menge aus den Angeboten nehmen
    if self.result and self.result.key == p.key then
        local left = p.qty
        for _, l in ipairs(self.result.listings) do
            if left <= 0 then break end
            if l.planned and l.planned > 0 then
                local n = math.min(l.planned, left)
                l.used = (l.used or 0) + n
                left = left - n
            end
        end
    end
    self.lastPurchase = { key = p.key, itemID = p.itemID, qty = p.qty, cost = cost, time = Now(), confirmed = true }
    local msg = L["Gekauft: "] .. p.qty .. "x " .. A:GetItemName(p.itemID) .. L[" für "] .. A:FormatMoney(cost)
    A:Print(msg)
    A:Fire("SNIPER_PURCHASE_DONE", self.lastPurchase)      -- Buchhaltung bucht jetzt (Reihenfolge der Ereignisse egal)
    if t then self:AfterPurchase(t) else A:Fire("SNIPER_CHANGED") end
    return true, msg
end

-- S3: Preis bestätigt - Ton (Option "Ton bei Treffern"), Kaufen-Knopf blinkt, grosser Hinweis (nie im Kampf)
function Sn:StartAlert(p)
    self.buyAlert = { started = Now() }
    if A.db and A.db.settings.alertSound and PlaySound then pcall(PlaySound, 8959) end
    if not A:InCombat() then
        self:BuyHint(string.format(L["Jetzt kaufen: %s"], self:GetBindsText()))
    end
    A:Fire("SNIPER_CHANGED")
end

-- G2 (Befund 16:54): "Jetzt kaufen" nur EINMAL (eigene Zeile, nicht RaidNotice und nicht UIErrorsFrame), höchstens 2 s,
-- oberhalb der Aktionsleisten statt in der Bildschirmmitte über offenen Fenstern. Gleicher Text innerhalb von 2 s: nichts.
Sn.HINT_SECONDS = 2
Sn.hintCount = 0
function Sn:BuyHint(text)
    local now = GetTime()
    if self.hintText == text and self.hintAt and now - self.hintAt < self.HINT_SECONDS then return false end
    self.hintText, self.hintAt = text, now
    self.hintCount = self.hintCount + 1
    local f = self.hintFrame
    if not f then
        f = CreateFrame("Frame", nil, UIParent)
        f:SetSize(600, 30)
        f:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, 190)
        f:SetFrameStrata("HIGH")
        f.text = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        f.text:SetPoint("CENTER")
        f:EnableMouse(false)
        self.hintFrame = f
    end
    local shown = "AHSentinel: " .. text
    if A.TestMode and A.TestMode.active then shown = "[Test] " .. shown end
    f.text:SetText(shown)
    f.text:SetTextColor(1, 0.82, 0)
    f:Show()
    A.lastScreenMessage = shown
    local token = now
    f.token = token
    if C_Timer and C_Timer.After then
        C_Timer.After(self.HINT_SECONDS, function() if f.token == token then f:Hide() end end)
    end
    return true
end
function Sn:StopAlert()
    if self.buyAlert then self.buyAlert = nil; A:Fire("SNIPER_CHANGED") end
end

-- Sofortkauf geht nicht (keine Preisbestätigung vom Server): zurück zu 2 Rasten
-- blocked = true: WoW hat den Aufruf ohne Tastendruck geblockt -> dauerhaft für diesen Client merken
function Sn:DisableInstant(blocked)
    if blocked then
        local db = DB()
        if db then db.instantBlocked = Interface() end
    end
    if self.instantFailed then return end
    self.instantFailed = true
    if blocked then
        A:Print(L["Sofortkauf mit einer Raste erlaubt WoW hier nur mit Tastendruck - Waren mit 2 Rasten: 1. reserviert, 2. kauft."])
    else
        A:Print(L["Sofortkauf mit einer Raste geht hier nicht (keine Preisbestätigung vom Server) - Waren wieder mit 2 Rasten: 1. reserviert, 2. kauft."])
    end
    A:Fire("SNIPER_CHANGED")
end

function Sn:CancelPending(reason)
    local p = self.pending
    if not p then return end
    self.pending = nil
    self.buyAlert = nil
    if A.AH and A.AH.CancelCommoditiesPurchase then
        pcall(A.AH.CancelCommoditiesPurchase)
    end
    if reason then A:Print(reason) end
    A:Fire("SNIPER_CHANGED")
end

function Sn:AfterPurchase(t)
    self:StopSignal("Kauf")                                    -- SG2
    if t.watch then
        if self:IsDone(t) then self:RemoveExtraTarget(t.key) end
        if A.Watcher then A.Watcher:OnBought(t) end
        A:Fire("SNIPER_CHANGED")
        return
    end
    -- SN3 (Anweisung 10.11.): Budget aufgebraucht, Menge offen -> einmal melden; das Ziel bleibt (pausiert)
    local qLeft, bLeft = self:Remaining(t)
    if qLeft > 0 and self:BudgetUsedUp(t) then
        if not t.budgetNote then
            t.budgetNote = true
            A:Print(self:BudgetText(t))
        end
        A:Fire("SNIPER_CHANGED")
        return
    end
    if self:IsDone(t) then
        A:Print(L["|cff33dd55Ziel erfüllt:|r "] .. self:TargetName(t) .. " - " .. t.bought .. L[" Stück für "] .. A:FormatMoney(t.spent))
        if #self:GetActiveTargets(false) == 0 and DB().armed then
            A:Print(L["Alle Ziele erfüllt - Sniper-Modus aus."])
            self:SetArmed(false)
        end
    end
    A:Fire("SNIPER_CHANGED")
end

-- Ein Tastendruck / eine Mausrad-Raste / Klick auf "Kaufen"
-- Rückgabe: ok, Meldung, leise (true = keine Meldung nötig)
-- Mausrad über den Fenstern des Addons: Bindungen greifen dort nicht (die Fenster fangen das
-- Rad ab). Wartet ein Treffer und ist das Mausrad die Kauf-Taste, wird hier gekauft.
-- Rückgabe: true = Rad wurde für den Kauf benutzt (nicht blättern)
local function Mods()
    local m = ""
    if IsAltKeyDown and IsAltKeyDown() then m = m .. "ALT-" end
    if IsControlKeyDown and IsControlKeyDown() then m = m .. "CTRL-" end
    if IsShiftKeyDown and IsShiftKeyDown() then m = m .. "SHIFT-" end
    return m
end

function Sn:WheelBuy(delta)
    if not (A:IsAHOpen() and self.HitWaiting and self:HitWaiting()) then return false end
    local key = Mods() .. ((delta or 0) > 0 and "MOUSEWHEELUP" or "MOUSEWHEELDOWN")
    local db = DB()
    local function has(kind)
        for _, k in ipairs(self:GetBinds(kind)) do if k == key then return true end end
        return false
    end
    local s = db and db.armed and has("sniper")
    local w = self:HasExtraTargets() and has("watcher")
    if not (s or w) then return false end
    local kind = (s and w) and nil or (s and "sniper" or "watcher")
    -- passt der wartende Treffer zur Taste?
    local key2 = self.pending and self.pending.key or (self.result and self.result.key)
    if kind then
        local t = key2 and self:GetTarget(key2)
        if ((kind == "watcher") ~= (t and t.watch or false)) then return false end
    end
    local ok, msg = self:OnTrigger(kind)
    if msg and not ok then A:Print(msg) end
    return true
end

-- gehört ein Ziel zur Taste? (kind nil = beide)
local function KindMatches(kind, key)
    if not kind then return true end
    local t = key and Sn:GetTarget(key)
    local isWatch = t and t.watch or false
    return (kind == "watcher") == isWatch
end

-- Grundsatz (Anweisung 17:35, nicht verhandelbar): Reservieren und Kaufen NUR aus einem echten Tasten-/Mausrad-/
-- Klick-Ereignis des Spielers - nie aus Timer, OnUpdate, Ereignis oder Schleife. Alle Wege laufen über OnTrigger
-- (Auslöser-Knöpfe, Knopf "Kaufen"); nur dort ist Sn.inTrigger gesetzt, Buy/Reserve/Confirm prüfen das.
function Sn:OnTrigger(kind)
    if self.inTrigger then return false, nil, true end
    self.inTrigger = true
    local r = { pcall(self.OnTriggerInner, self, kind) }
    self.inTrigger = nil
    if not r[1] then error(r[2], 0) end
    return unpack(r, 2, table.maxn(r))
end

function Sn:HardwareOK()
    return self.inTrigger == true
end

function Sn:OnTriggerInner(kind)
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    -- A2: Bestätigen nur 0,05 s gesperrt, Reservieren/Kauf-Start 0,3 s; A3: Rasten in der Wartezeit still übergehen
    local ready = self.pending and self.pending.state == "ready"
    if Now() - self.lastPress < (ready and CONFIRM_DEBOUNCE or PRESS_DEBOUNCE) then return false, nil, true end
    if self.pending and not ready then return false, nil, true end
    self.lastPress = Now()

    if self.pending then
        if not KindMatches(kind, self.pending.key) then return false, nil, true end
        return self:Confirm()
    end

    if self:IsResultFresh() then
        local plan = self:PlanNext()
        if plan and not KindMatches(kind, plan.key) then return false, nil, true end
        if plan then
            -- altes AH: Angebot muss in der Liste stehen - sonst Seite laden, nächste Raste kauft
            if plan.kind == "item" and A.AH.PrepareBuy and plan.listing and not A.AH.PrepareBuy(plan.listing.auctionID) then
                return false, L["Treffer wird geladen - gleich nochmal drehen/drücken."]
            end
            return self:Buy(plan)
        end
    end
    if kind == "watcher" then return false, nil, true end
    -- nichts zu kaufen: sofort weitersuchen (wenn erlaubt)
    local ok, msg, soft = self:CheckNext()
    if soft then return false, nil, true end
    return ok, msg
end

-- ------------------------------------------------------------
-- Ereignisse rund um den Kauf
-- ------------------------------------------------------------
local evt = CreateFrame("Frame")
Sn.evt = evt            -- für die Testroutine (Ereignisse mit Testargumenten nachspielen)
local function Reg(e) return A:RegisterAHEvent(evt, e) end
Sn.priceEvents = Reg("COMMODITY_PRICE_UPDATED")
Reg("COMMODITY_PRICE_UNAVAILABLE")
Reg("COMMODITY_PURCHASE_FAILED")
Reg("COMMODITY_PURCHASE_SUCCEEDED")
Reg("AUCTION_HOUSE_SHOW_ERROR")
Reg("PLAYER_REGEN_ENABLED")
-- WoW blockiert einen geschützten Aufruf ohne Lua-Fehler (pcall meldet Erfolg) - nur dieses Ereignis zeigt es
pcall(evt.RegisterEvent, evt, "ADDON_ACTION_BLOCKED")
pcall(evt.RegisterEvent, evt, "ADDON_ACTION_FORBIDDEN")

function Sn:OnEvent(event, a1, a2)
    if event == "ADDON_ACTION_BLOCKED" or event == "ADDON_ACTION_FORBIDDEN" then
        local G = _G.GoldSentinelGame
        if G and G.AnySecret and G.AnySecret(a1, a2) then return end     -- geschützter Wert (WoW Forever)
        -- nur unsere eigenen Aufrufe: ein vorab (ohne Tastendruck) reservierter Warenkauf wurde geblockt
        local mine = a1 == A.ADDON_NAME or a1 == "AHSentinel" or a1 == "AHAnalyzerPro"
        local func = tostring(a2 or "")
        if mine and (func:find("Commodit") or (self.pending and self.pending.auto)) then
            if self.pending and self.pending.auto then self.pending = nil end
            self:DisableInstant(true)
            A:Fire("SNIPER_CHANGED")
        end
        return
    end
    if event == "PLAYER_REGEN_ENABLED" then
        if self.pendingBindings then self:ApplyBindings() end
    elseif event == "COMMODITY_PRICE_UPDATED" then
        local p = self.pending
        if not p or p.state ~= "waiting" then return end
        local unit, total = a1, a2
        local t = self:GetTarget(p.key)
        local budgetLeft = 0
        if t then
            local _, b = self:Remaining(t)
            budgetLeft = b
        end
        if t and unit and total and unit <= t.maxPrice and total <= budgetLeft then
            -- C3: Teilkauf - liefert der Server weniger Stücke (total / Stückpreis), wird diese Menge gekauft und gebucht
            if unit > 0 then
                local q = math.floor(total / unit + 0.5)
                if q >= 1 and q < (p.qty or q) then p.qty = q end
            end
            p.state, p.total, p.started = "ready", total, Now()
            self:MeterMark("tReady")
            if p.auto then A:Fire("SNIPER_CHANGED"); return end      -- Sofortkauf: eine Raste kauft
            A:Print(L["Preis bestätigt: "] .. p.qty .. "x " .. A:GetItemName(p.itemID) .. L[" für "] .. A:FormatMoney(total)
                .. L[" - nochmal "] .. self:GetBindsText() .. L[" zum Kaufen"])
            self:StartAlert(p)
        else
            if p.auto then
                -- vorab geholter Preis passt nicht mehr: Angebote neu suchen statt immer wieder zu reservieren
                self.result = nil
                self:CancelPending(L["Treffer ist weg - Preis inzwischen gestiegen ("] .. A:FormatMoney(total) .. L[")."])
            else
                self:CancelPending(L["Preis ist inzwischen gestiegen ("] .. A:FormatMoney(total) .. L[") - Kauf abgebrochen."])
                self:MeterEnd("gestiegen")
            end
        end
    elseif event == "COMMODITY_PRICE_UNAVAILABLE" then
        self:MeterEnd("weg")
        local p = self.pending
        if p and p.auto then
            self.result = nil
            self:CancelPending(L["Treffer ist weg - Angebot nicht mehr verfügbar."])
        else
            self:CancelPending(L["Angebot nicht mehr verfügbar - Kauf abgebrochen."])
        end
    elseif event == "COMMODITY_PURCHASE_SUCCEEDED" then
        if self.inFlight then self:PurchaseSucceeded() end
    elseif event == "AUCTION_HOUSE_SHOW_ERROR" and self.inFlight and Now() - self.inFlight.time < self.INFLIGHT_MAX then
        -- offener Punkt 3: ein AH-Fehler kann von etwas anderem kommen (Suche, "Datenbank beschäftigt") - den Kauf
        -- nicht verwerfen; entschieden wird über SUCCEEDED / PURCHASE_FAILED bzw. den Gold-Rückfall
        self.inFlight.errorSeen = true
    elseif event == "COMMODITY_PURCHASE_FAILED" and self.inFlight and Now() - self.inFlight.time < self.INFLIGHT_MAX then
        self:MeterEnd("Fehler")
        -- gesendeter Warenkauf gescheitert: nichts zählen (es wurde noch nichts gezählt)
        self.inFlight = nil
        -- S6: die geplanten Waren-Angebote (ohne auctionID) 60 s überspringen
        local r = self.result
        if r and r.commodity then
            for _, l in ipairs(r.listings or {}) do if l.planned and l.planned > 0 then self:MarkDead(l, r.itemID) end end
        end
        self:ReportFail(nil)
        A:Fire("SNIPER_CHANGED")
    elseif event == "COMMODITY_PURCHASE_FAILED" or event == "AUCTION_HOUSE_SHOW_ERROR" then
        local lp = self.lastPurchase
        if lp and Now() - lp.time < 5 and not lp.confirmed then
            local t = self:GetTarget(lp.key)
            if t then
                t.bought = math.max(0, (t.bought or 0) - lp.qty)
                t.spent = math.max(0, (t.spent or 0) - lp.cost)
            end
            -- S5: Angebot gilt als weg (nicht erneut versuchen), gleich zum nächsten passenden; keins mehr da -> neue Suche
            if lp.listing then lp.listing.used = nil; self:MarkDead(lp.listing, lp.itemID) end
            self.lastPurchase = nil
            self:ReportFail(lp.listing and lp.listing.auctionID or lp.auctionID,
                L["|cffff5544Kauf fehlgeschlagen|r (Angebot weg oder nicht genug Gold) - Zähler korrigiert."])
            if not self:PlanNext() then self.lastSearch = -100 end
            A:Fire("SNIPER_CHANGED")
        end
    end
end

evt:SetScript("OnEvent", function(_, event, a1, a2) Sn:OnEvent(event, a1, a2) end)

-- ------------------------------------------------------------
-- Auslöser: Mausrad oder selbst gewählte Taste
-- Aktiv nur im Sniper-Modus UND bei offenem Auktionshaus.
-- Über Listen/Fenstern scrollt das Mausrad weiter normal.
-- ------------------------------------------------------------
-- drei Auslöser: gleiche Taste für beide / nur Sniper-Treffer / nur Wächter-Treffer
local function MakeTrigger(name, kind)
    local b = CreateFrame("Button", name, UIParent)
    b:Hide()
    b:SetScript("OnClick", function()
        local ok, msg = Sn:OnTrigger(kind)
        if msg and not ok then A:Print(msg) end
    end)
    return b
end
local triggerButton = MakeTrigger("AHAnalyzerProSnipeButton", nil)
local sniperButton = MakeTrigger("AHAnalyzerProSnipeOnlyButton", "sniper")
local watcherButton = MakeTrigger("AHAnalyzerProWatchButton", "watcher")
Sn.triggerButton, Sn.sniperButton, Sn.watcherButton = triggerButton, sniperButton, watcherButton

local KEY_NAMES = {
    MOUSEWHEELUP = "Mausrad hoch",
    MOUSEWHEELDOWN = "Mausrad runter",
    BUTTON3 = "Mittlere Maustaste",
    BUTTON4 = "Maustaste 4",
    BUTTON5 = "Maustaste 5",
}

function Sn:KeyName(key)
    if not key then return "-" end
    local mods, base = key:match("^(.*%-)(.-)$")
    if not base or base == "" then mods, base = "", key end
    local name = KEY_NAMES[base] and L[KEY_NAMES[base]]
    if not name and GetBindingText then
        local ok, txt = pcall(GetBindingText, base)
        if ok and txt and txt ~= "" then name = txt end
    end
    mods = mods:gsub("SHIFT%-", "Shift+"):gsub("CTRL%-", L["Strg+"]):gsub("ALT%-", "Alt+")
    return mods .. (name or base)
end

-- Tasten: kind = "sniper" (Standard) oder "watcher" - jede Seite hat ihre eigene Belegung
local WHEEL = { "MOUSEWHEELUP", "MOUSEWHEELDOWN" }
function Sn:GetBinds(kind)
    if kind == "watcher" then
        local w = A.db and A.db.watcher
        if w and not w.binds then w.binds = { WHEEL[1], WHEEL[2] } end
        return w and w.binds or {}
    end
    local db = DB()
    return db and db.binds or {}
end

function Sn:IsMouseWheelBind(kind)
    local b = self:GetBinds(kind)
    return #b == 2 and b[1] == WHEEL[1] and b[2] == WHEEL[2]
end

function Sn:GetBindsText(kind)
    local b = self:GetBinds(kind)
    if #b == 0 then return L["keine Taste"] end
    if self:IsMouseWheelBind(kind) then return L["Mausrad"] end
    local names = {}
    for _, k in ipairs(b) do table.insert(names, self:KeyName(k)) end
    return table.concat(names, " / ")
end

function Sn:SetBinds(list, kind)
    if kind == "watcher" then
        if not (A.db and A.db.watcher) then return end
        A.db.watcher.binds = list
    else
        local db = DB()
        if not db then return end
        db.binds = list
    end
    self:ApplyBindings()
    A:Fire("SNIPER_CHANGED")
    A:Fire("WATCHER_CHANGED")
end

function Sn:UseMouseWheel(kind)
    self:SetBinds({ WHEEL[1], WHEEL[2] }, kind)
end

function Sn:IsArmed()
    local db = DB()
    if not (db and A:IsAHOpen()) then return false end
    if db.armed then return true end
    return self:HasExtraTargets()      -- Wächter hat Schnäppchen: Taste/Mausrad kauft diese
end

function Sn:SetArmed(on)
    local db = DB()
    if not db then return end
    db.armed = on and true or false
    if not db.armed then self:CancelPending() end
    self:ApplyBindings()
    A:Fire("SNIPER_CHANGED")
end

function Sn:ToggleArmed()
    local db = DB()
    if not db then return end
    self:SetArmed(not db.armed)
    A:Print(L["Sniper-Modus "] .. (db.armed and (L["|cff33dd55AN|r - Kaufen mit "] .. self:GetBindsText()) or L["|cffff5544AUS|r"]))
end

function Sn:ApplyBindings()
    if not (SetOverrideBindingClick and ClearOverrideBindings) then return end
    if A:InCombat() then            -- (= InCombatLockdown; die Testroutine kann den Kampf simulieren)
        self.pendingBindings = true          -- im Kampf nicht erlaubt, danach nachholen
        return
    end
    self.pendingBindings = false
    ClearOverrideBindings(triggerButton)
    ClearOverrideBindings(sniperButton)
    ClearOverrideBindings(watcherButton)
    local db = DB()
    if not (db and A:IsAHOpen()) then return end
    -- Sniper-Taste: im Sniper-Modus; Wächter-Taste: sobald der Wächter Schnäppchen gefunden hat
    -- (sonst bleibt das Mausrad frei für die Kamera)
    local snOn = db.armed and true or false
    local wOn = self:HasExtraTargets()
    local sKeys, wKeys = {}, {}
    if snOn then for _, k in ipairs(self:GetBinds("sniper")) do sKeys[k] = true end end
    if wOn then for _, k in ipairs(self:GetBinds("watcher")) do wKeys[k] = true end end
    for k in pairs(sKeys) do
        if wKeys[k] then
            pcall(SetOverrideBindingClick, triggerButton, true, k, "AHAnalyzerProSnipeButton")
        else
            pcall(SetOverrideBindingClick, sniperButton, true, k, "AHAnalyzerProSnipeOnlyButton")
        end
    end
    for k in pairs(wKeys) do
        if not sKeys[k] then pcall(SetOverrideBindingClick, watcherButton, true, k, "AHAnalyzerProWatchButton") end
    end
end

-- ------------------------------------------------------------
-- Selbstständige Suche (nur Sniper-Modus AN + Auktionshaus offen)
-- ------------------------------------------------------------
-- B1: Sniper AN mit offenen eigenen Zielen (nicht nur Wächter-Schnäppchen)?
function Sn:HasOwnTargets()
    local db = DB()
    if not (db and db.armed and self:IsArmed()) then return false end       -- Sniper-Modus AN (nicht nur Wächter-Schnäppchen)
    for _, t in pairs(db.targets or {}) do
        if not t.watch and not self:IsDone(t) then return true end
    end
    return false
end

function Sn:Tick()
    pcall(self.MeterFlush, self)
    if self.search then
        self:PollSearch()
        return
    end

    local p = self.pending
    if p then
        if p.state == "waiting" and Now() - p.started > 5 then
            if p.auto then
                self:CancelPending()
                self:DisableInstant()
            else
                self:CancelPending(L["Keine Preisbestätigung vom Server - Kauf abgebrochen."])
                self:MeterEnd("abgelaufen")
            end
        elseif p.auto and p.state == "ready" and Now() - p.started > AUTO_REQUOTE then
            self:CancelPending()          -- Preis gleich frisch holen (nächster Takt)
        elseif p.state == "ready" and Now() - p.started > CONFIRM_TIMEOUT then
            self:CancelPending(L["Reservierter Preis verfallen - Kauf abgebrochen."])
            self:MeterEnd("abgelaufen")
        end
        -- vorab reservierter Sofortkauf: weitersuchen; sonst wartet der Kauf auf dich
        p = self.pending
        if p and not (p.auto and p.state == "ready") then return end
    end

    if not self:IsArmed() then self.waitReason = nil; return end
    -- S2 (Befund 10.11. 16:30): Grund merken, warum die Selbst-Suche wartet (Statuszeile, Protokoll SNIPER-SUCHE);
    -- Einkauf/Preisprüfung blockieren höchstens BLOCK_MAX Sekunden am Stück
    local function wait(reason)
        if self.waitReason ~= reason then self.waitReason, self.waitSince = reason, Now() end
    end
    if A:IsScanning(true) then return wait("scan") end
    local blocked = (A.Buy and A.Buy:Blocks() and "buy") or (A.Seller and A.Seller.HasWork and A.Seller:HasWork() and "seller") or nil
    if blocked then
        wait(blocked)
        if Now() - (self.waitSince or Now()) < self.BLOCK_MAX then return end
        if not self.blockNoted then
            self.blockNoted = true
            if A.Diag then pcall(A.Diag.Add, A.Diag, "SNIPER-SUCHE", "Sperre " .. blocked .. " länger als " .. self.BLOCK_MAX .. " s - Sniper sucht trotzdem") end
        end
    end

    -- Treffer wartet: Signal wiederholen (solange er kaufbar ist)
    if self:HitWaiting() then
        local plan = self:PlanNext()
        if plan then
            local t = self:GetTarget(plan.key)
            if t and not t.watch then self:Alert(plan, false) end
            -- altes AH: Treffer muss in der Liste des Auktionshauses bleiben, sonst lässt er sich
            -- nicht kaufen -> nichts anderes suchen, Treffer nur ab und zu nachprüfen
            if A.AH_LEGACY then
                if plan.kind == "item" and plan.listing and A.AH.PrepareBuy then A.AH.PrepareBuy(plan.listing.auctionID) end
                if Now() - self.lastSearch >= FOCUS_RECHECK and A:CanQueryNow("sniper") and not self.pending then
                    self:Search(plan.key)
                end
                return
            end
        end
    end
    -- neue Wächter-Schnäppchen sofort prüfen, sonst im eingestellten Abstand (Standard: so oft der Server erlaubt)
    local urgent = false
    for _, t in pairs(self.extra) do if not t.checked then urgent = true end end
    local interval = urgent and 0 or math.max(MIN_INTERVAL, DB().interval or 0)
    self.nextSearchAt = self.lastSearch + interval
    if Now() - self.lastSearch < interval then return wait(nil) end
    local W = A.Watcher
    if W and W:IsBusy() then return wait("watcher") end
    -- B1 (17:35): hat der Sniper eigene Ziele (Sniper-Modus AN), pausiert der Wächter und der Sniper sucht ohne
    -- Abwechslung. Prüft er nur Wächter-Schnäppchen, wechseln sich beide weiter ab.
    if not self:HasOwnTargets() and not urgent and W and W.WantsTurn and W:WantsTurn() and self.lastSearch > (W.lastRound or -100) then return wait("watcher") end
    local ok, msg = self:CheckNext()
    if ok then wait(nil); self.blockNoted = nil else wait(msg and ("msg:" .. msg) or "?") end
end

Sn.BLOCK_MAX = 20
-- S2: Statuszeile der Selbst-Suche ("nächste Suche in 12 s · zuletzt vor 40 s: 5 Treffer" bzw. "wartet: …")
function Sn:AutoStatus()
    local db = DB()
    if not (db and db.armed) then return nil end
    if not A:IsAHOpen() then return L["Sniper-Modus an – sucht, sobald das Auktionshaus offen ist."] end
    local parts = {}
    local now = Now()
    if self.search then
        parts[#parts + 1] = L["sucht gerade ..."]
    elseif self.waitReason then
        local why = self.waitReason
        local txt = ({ scan = L["wartet: Markt-Scan läuft"], buy = L["wartet: Einkauf sucht"], seller = L["wartet: Preisprüfung läuft"],
            watcher = L["wartet: Wächter ist dran"] })[why]
        if not txt and why:sub(1, 4) == "msg:" then txt = L["wartet: "] .. why:sub(5) end
        parts[#parts + 1] = txt or (L["wartet: "] .. why)
    elseif self.nextSearchAt then
        parts[#parts + 1] = string.format(L["nächste Suche in %d s"], math.max(0, math.ceil(self.nextSearchAt - now)))
    end
    if self.lastDone then
        parts[#parts + 1] = string.format(L["zuletzt vor %d s: %d Treffer"], math.floor(now - self.lastDone.time), self.lastDone.hits or 0)
    end
    local VS = A.FullScan
    if VS and VS.Wait and VS:Wait() > 0 then
        parts[#parts + 1] = string.format(L["Vollscan-Sperre noch %d Min. (Sniper sucht trotzdem)"], math.ceil(VS:Wait() / 60))
    end
    return table.concat(parts, " · ")
end

-- Ergebnisse sofort auswerten, sobald der Server sie meldet
A:On("SEARCH_RESULTS", function()
    if Sn.search then Sn.search.answered = true; Sn:PollSearch() end
end)
A:On("BROWSE_RESULTS", function()
    if Sn.search and Sn.search.stage == "browse" then Sn.search.answered = true; Sn:PollSearch() end
end)

local ticker = CreateFrame("Frame")
local acc = 0
ticker:SetScript("OnUpdate", function(_, dt)
    acc = acc + (dt or 0)
    if acc < 0.1 then return end
    acc = 0
    Sn:Tick()
end)

A:On("AH_STATE", function()
    if A:IsAHOpen() then Sn.lastSearch = -100 end            -- S2: beim Öffnen des AH (auch nach /reload) sofort suchen
    if not A:IsAHOpen() then
        Sn.search = nil
        Sn:CancelPending()
        wipe(Sn.extra)
    end
    Sn:ApplyBindings()
    A:Fire("SNIPER_CHANGED")
end)
A:On("READY", function()
    Sn:ImportOld()
    Sn:ApplyBindings()
end)

-- ------------------------------------------------------------
-- Item in der normalen Auktionshaus-Suche öffnen
-- ------------------------------------------------------------
function Sn:OpenInAH(itemID)
    if not itemID then return false, L["Kein Item gewählt."] end
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    local name = A:GetClientItemName(itemID)    -- das Auktionshaus sucht in der Sprache des Clients
    -- Addon-Ansicht im Auktionshaus offen: erst zur Blizzard-Ansicht wechseln
    local UI = A.UI
    if UI and UI.ahOverlay and UI.ahOverlay:IsShown() and UI.LeaveAH then pcall(UI.LeaveAH, UI) end
    -- klassisches Auktionshaus (Classic Era, WoW Forever, TBC, Wrath): Reiter "Durchsuchen"
    if type(AuctionFrame) == "table" and not (type(AuctionHouseFrame) == "table") then
        local browse = _G.AuctionFrameBrowse
        if not (browse and browse:IsShown()) and _G.AuctionFrameTab1 and _G.AuctionFrameTab1.Click then
            pcall(_G.AuctionFrameTab1.Click, _G.AuctionFrameTab1)
        end
        local box = _G.BrowseName
        if box and box.SetText then
            pcall(box.SetText, box, name)
            if type(AuctionFrameBrowse_Search) == "function" and pcall(AuctionFrameBrowse_Search) then
                return true, L["Im Auktionshaus gesucht: "] .. name
            end
            local btn = _G.BrowseSearchButton
            if btn and btn.Click and pcall(btn.Click, btn) then
                return true, L["Im Auktionshaus gesucht: "] .. name
            end
            return true, L["Name eingetragen - im Auktionshaus auf Suchen klicken."]
        end
    end
    local bar = AuctionHouseFrame and AuctionHouseFrame.SearchBar
    local box = bar and bar.SearchBox
    if box and box.SetText then
        pcall(box.SetText, box, name)
        if bar.StartSearch then
            local ok = pcall(bar.StartSearch, bar)
            if ok then return true, L["Im Auktionshaus gesucht: "] .. name end
        end
        return true, L["Name eingetragen - im Auktionshaus auf Suchen klicken."]
    end
    return false, L["Suchfeld des Auktionshauses nicht gefunden. Suche dort nach: "] .. name
end

function Sn:GetStatusText()
    local db = DB()
    if not db then return "" end
    if not db.armed then
        if self:IsArmed() and not self.pending then
            if self:IsResultFresh() and self:PlanNext() then
                return L["|cff33dd55Schnäppchen! "] .. self:GetBindsText("watcher") .. L[" zum Kaufen|r"]
            end
            return L["|cffffcc33Wächter: Schnäppchen werden geprüft ...|r"]
        end
        if not self.pending then return L["|cffff5544Sniper-Modus AUS|r"] end
    end
    if not A:IsAHOpen() then return L["|cffffcc33Sniper-Modus AN - wartet auf das Auktionshaus|r"] end
    if self.pending then
        if self.pending.state == "ready" then
            if self.pending.auto then return L["|cff33dd55Treffer! "] .. self:GetBindsText() .. L[" zum Kaufen|r"] end
            -- 2 Rasten (WoW Forever): reserviert - nochmal drehen zum Kaufen, mit Restzeit bis der Preis verfällt
            local left = math.max(0, math.ceil(CONFIRM_TIMEOUT - (Now() - (self.pending.started or Now()))))
            return string.format(L["|cff33dd55Reserviert - nochmal %s zum Kaufen (%d s)|r"], self:GetBindsText(), left)
        end
        return L["|cffffcc33Preis wird geprüft ...|r"]
    end
    -- ein wartender Treffer geht vor "Sucht" (Forever: ohne Vorab-Reservierung sucht der Sniper weiter)
    if self:IsResultFresh() then
        local plan = self:PlanNext()
        if plan then
            -- Waren in WoW Forever (Entscheid 9. Nov. 09:35): 1. Raste reserviert, 2. Raste kauft
            if plan.kind == "commodity" and not self:InstantEnabled() then
                return string.format(L["|cff33dd55Treffer! 1. %s: Preis reservieren · 2. %s: kaufen|r"], self:GetBindsText(), self:GetBindsText())
            end
            return L["|cff33dd55Treffer! "] .. self:GetBindsText() .. L[" zum Kaufen|r"]
        end
    end
    if self.search then
        local t = self:GetTarget(self.search.targetKey)
        return L["|cffffcc33Sucht: "] .. (t and self:TargetName(t) or "?") .. "|r"
    end
    if #self:GetActiveTargets(false) == 0 then return L["|cffaaaaaaKeine offenen Ziele|r"] end
    return L["|cff33dd55Sniper-Modus AN - sucht selbstständig|r"]
end

function Sn:GetDebugText()
    local api = self:CheckAPI()
    local function yn(b) return b and L["ja"] or L["nein"] end
    local db = DB()
    return L["Einzel-Suche="] .. yn(api.SendSearchQuery)
        .. L[", Suchbegriff="] .. yn(api.SendBrowseQuery)
        .. L[", Sofortkauf="] .. yn(api.PlaceBid)
        .. L[", Warenkauf="] .. yn(api.CommodityBuy)
        .. L[", Preis-Events="] .. yn(self.priceEvents)
        .. L[", Sofortkauf="] .. yn(self:InstantEnabled())
        .. L[", Tastenbelegung="] .. yn(api.Bindings)
        .. L[", Modus="] .. (self:IsArmed() and L["scharf"] or (db and db.armed and L["an (AH zu)"] or L["aus"]))
        .. L[", Auslöser="] .. self:GetBindsText()
        .. L[", Ziele="] .. #self:GetTargets() .. L[" (offen "] .. #self:GetActiveTargets() .. ")"
end

-- ============================================================
-- SG1–SG5 (Wunsch des Nutzers 11.11. 15:23): optisches Signal bei einem echten Sniper-Treffer - der Bildschirmrand
-- pulsiert 3 Mal (je 0,6 s) in Gold, wie das Rand-Glühen bei wenig Leben. Eigener Vollbild-Frame, nimmt keine Maus an,
-- verändert keinen Blizzard-Frame. Weicher Rand aus eigenen Streifen (WHITE8X8 mit abnehmendem Alpha) - braucht keine
-- Spieldatei, die es in einem Client nicht geben könnte.
-- ============================================================
Sn.SIGNAL_PULSES = 3
Sn.SIGNAL_PULSE = 0.6
Sn.SIGNAL_MAX = 4          -- spätestens nach 4 s aus
Sn.SIGNAL_GAP = 3          -- höchstens 1 Signal je 3 s
Sn.SIGNAL_ALPHA = 0.7
Sn.SIGNAL_STRIPS = 10
Sn.SIGNAL_WIDTH = 7
Sn.SIGNAL_COLORS = { gold = { 1, 0.82, 0 }, gruen = { 0.2, 0.9, 0.3 }, blau = { 0.3, 0.6, 1 } }
Sn.SIGNAL_ORDER = { "gold", "gruen", "blau" }
Sn.SIGNAL_LABELS = { gold = "Gold", gruen = "Grün", blau = "Blau" }

function Sn:SignalOn() return not (A.db and A.db.settings.sniperSignal == false) end
function Sn:SignalColorKey()
    local k = A.db and A.db.settings.sniperSignalColor
    return self.SIGNAL_COLORS[k or ""] and k or "gold"
end
function Sn:CycleSignalColor()
    local cur, nextK = self:SignalColorKey(), "gold"
    for i, k in ipairs(self.SIGNAL_ORDER) do if k == cur then nextK = self.SIGNAL_ORDER[i % #self.SIGNAL_ORDER + 1] end end
    A.db.settings.sniperSignalColor = nextK
    return nextK
end

function Sn:SignalFrame()
    local f = self.signalFrame
    if f then return f end
    f = CreateFrame("Frame", nil, UIParent)
    f:SetAllPoints(UIParent)
    f:SetFrameStrata("FULLSCREEN")
    f:EnableMouse(false)
    if f.EnableMouseWheel then f:EnableMouseWheel(false) end
    f.tex = {}
    local n, w = self.SIGNAL_STRIPS, self.SIGNAL_WIDTH
    for i = 1, n do
        local a = (1 - (i - 1) / n) ^ 2                 -- aussen kräftig, nach innen weich
        local off = (i - 1) * w
        for _, side in ipairs({ "TOP", "BOTTOM", "LEFT", "RIGHT" }) do
            local t = f:CreateTexture(nil, "OVERLAY")
            t:SetTexture("Interface\\Buttons\\WHITE8X8")
            if side == "TOP" or side == "BOTTOM" then
                t:SetHeight(w)
                t:SetPoint(side .. "LEFT", f, side .. "LEFT", off, side == "TOP" and -off or off)
                t:SetPoint(side .. "RIGHT", f, side .. "RIGHT", -off, side == "TOP" and -off or off)
            else
                t:SetWidth(w)
                t:SetPoint("TOP" .. side, f, "TOP" .. side, side == "LEFT" and off or -off, -off - w)
                t:SetPoint("BOTTOM" .. side, f, "BOTTOM" .. side, side == "LEFT" and off or -off, off + w)
            end
            t.base = a
            f.tex[#f.tex + 1] = t
        end
    end
    f:Hide()
    f:SetScript("OnUpdate", function(self2)
        local d = GetTime() - (self2.started or 0)
        local total = Sn.SIGNAL_PULSES * Sn.SIGNAL_PULSE
        if d >= math.min(total, Sn.SIGNAL_MAX) then Sn:StopSignal("Ende"); return end
        self2:SetAlpha(Sn.SIGNAL_ALPHA * math.abs(math.sin(math.pi * d / Sn.SIGNAL_PULSE)))
    end)
    self.signalFrame = f
    return f
end

-- Signal für einen Treffer; zurück: true, wenn gezeigt (sonst false, Grund)
function Sn:Signal(plan)
    if not self:SignalOn() then return false, "Option aus" end
    if not A:IsAHOpen() then return false, "AH zu" end
    if A:InCombat() then return false, "Kampf" end
    if plan then
        if plan.itemID and self.ItemPaused and self:ItemPaused(plan.itemID) then return false, "pausiert" end
        local l = plan.listing
        if l and (l.gone or A:IsDeadOffer(plan.itemID, l.auctionID, l.price, l.qty)) then return false, "totes Angebot" end
    end
    local now = GetTime()
    if self.signalAt and now - self.signalAt < self.SIGNAL_GAP then return false, "zu kurz nach dem letzten" end
    self.signalAt = now
    local f = self:SignalFrame()
    local c = self.SIGNAL_COLORS[self:SignalColorKey()]
    for _, t in ipairs(f.tex) do t:SetVertexColor(c[1], c[2], c[3], t.base) end
    f.started = now
    f.color, f.rgb = self:SignalColorKey(), c
    f:SetAlpha(0)
    f:Show()
    self.signalCount = (self.signalCount or 0) + 1
    return true
end
function Sn:StopSignal(why)
    local f = self.signalFrame
    if f and f:IsShown() then f:Hide(); f.stopped = why end
end
function Sn:SignalShown() return self.signalFrame ~= nil and self.signalFrame:IsShown() end

-- SG2: aus bei Kauf, beim Schliessen des AH und wenn der Treffer weg ist
A:On("AH_STATE", function() if not A:IsAHOpen() then Sn:StopSignal("AH zu") end end)
A:On("BUY_PURCHASE_RESULT", function() Sn:StopSignal("Kauf") end)
A:On("SNIPER_CHANGED", function()
    if Sn.signalFrame and Sn.signalFrame:IsShown() and not Sn.hasPlan then Sn:StopSignal("weiter") end
end)
