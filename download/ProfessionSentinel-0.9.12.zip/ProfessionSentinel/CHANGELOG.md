# ProfessionSentinel – Changelog

## 0.9.12
Fixes from the review of 0.9.11 ("Korrekturen aus der Nachprüfung 0.9.11"):
- **No Blizzard function is replaced any more, not even in the test routine (taint):** the addon now calls the game API only through its own table `ns.API` (filled when the addon loads; functions of `C_` tables get flat entries such as `ns.API.MerchantGetItemInfo`; missing functions stay empty, so older game versions keep their old ways). The test routine only switches entries of this table. The `[api]` cases only run with `/ps testroutine api` (with a warning before the start), no longer in the normal run
- **One place for actions with consequences:** buying at the vendor, whispering enchanting offers (with `C_ChatInfo.SendChatMessage` as a second way if the global function is missing), crafting and the map pin all go through `ns.Act`; during a test run it only writes them down. New test case **T180** (area I) checks that every action path arrives there and nothing real happens; `tests/check_actions.py` checks the source code
- **T145 memory:** measured after releasing the run's own copies and two full garbage collections, with a longer warm-up; offline the measurement no longer counts LuaJIT's compiled code (the game has no JIT)
- Test routine: the sub-runs of T20 and T110 really only take area F now
- **Realms with a hyphen** (e.g. Retail "Azjol-Nerub"): your own character no longer shows up among "your other characters" in the tooltip (new test case T181)
- "Please /reload" after every test run; the remaining test texts ("GoldSentinelTest/SavedVariables missing", "Run again", "Select all") now come from the locales (EN/DE)
- Protected values (WoW Forever, Retail in combat): learned-recipe event, tooltips, the enchanting customer and the guild list ask `IsSecret` first, before any comparison
- Nothing changes for players in how the addon looks or works

## 0.9.11
- Internal: **one test routine** for the developer (`/ps testroutine`, button "Test everything" in test mode): 179 test cases (T01–T179) in ten areas, results go to the review through the shared `GoldSentinelTest.lua`. `/ps selftest` and `/ps autotest` now run on the same machine. Nothing changes for players
- Lua errors of the addon are now counted locally (at most 50 kinds) and sent with the next test report; nothing is sent anywhere by the addon itself
- Fixes found by the new test cases (older game versions behave exactly as before):
  - modern client: stack size, vendor sell price, disenchant values and shift-click links also work without the old `GetItemInfo`
  - protected values in combat (WoW Forever, Retail): learned-recipe events, tooltips, the customer for enchanting offers and the guild list never use them
  - errors inside AHSentinel no longer break the enchanter tab; damaged saved data (favor costs, plan target, enchanting prices, characters) is repaired on load instead of causing Lua errors
  - buying, whispering, sniper targets and waypoints are refused in combat with a short message

## 0.9.10
Recipe data updated (WoW Forever client 1.60.1.70753, QuestieDB 2026-11-02):
- **New recipe:** Enchant Boots - Speed (Enchanting, skill 280) – formula from a vendor
- **37 recipes with a newly known vendor source**, now with price and required skill: e.g. the Veteran's/Guard's/Protector's chain armor sets (Blacksmithing 80–125), 18 Leatherworking patterns, the Heart of the Mountain formulas (Enchanting 265) and Minor Spellblasting Potion (Alchemy 35)
- Classic Era and Retail: no changes to recipes (data source date only)

## 0.9.9
Fixes from the review of 0.9.8:
- **WoW Forever, reputation:** your reputation is now also read on the modern client (`C_Reputation`) – the reputation line of favor recipes turns green or red again instead of always yellow
- **Merchant's Favor from AHSentinel:** only Merchant's Favor is taken over, no other currency (otherwise price and balance were wrong)
- **Costs not readable?** If the client cannot read favor costs at the vendor, the addon says so once per vendor visit; the diagnosis shows "vendor costs readable: yes/no"
- **Crate calculator:** for green crates (bars, bolts, parts) the cheaper of buying and **crafting yourself** counts; the tooltip shows which one was used
- **New, off by default:** the best crate (gold per favor) at the top of "craft today" – switch it on in the Favor tab or with `/ps kisten`
- Favor cost and reputation now also in the item tooltip (bags, AH)
- Older game versions: buying at the vendor exactly as before again; the new tab layout without gaps only applies to WoW Forever

## 0.9.8
- Internal: **GoldSentinelGame.lua version 2** – wins over early, withdrawn versions in other GoldSentinel addons and stays compatible with them (no Lua errors when several addons bring different versions). Nothing changes for players

## 0.9.7
- **WoW Forever, vendors:** when a supply-camp vendor was only visited with AHSentinel, ProfessionSentinel now also takes over the currency – your Merchant's Favor balance shows up without visiting the vendor yourself. Order of the costs: read at the vendor yourself → read by AHSentinel → guides
- Buying at the vendor and reading the costs no longer depend on old vendor functions missing in the modern client (count, link, purchase); older game versions are unchanged (test in the client)

## 0.9.6
- Internal: the game version now comes from **GoldSentinelGame.lua**, the shared detection of all GoldSentinel addons (the same file as in RaidMaster, GuildSentinel, ThreatSentinel and BuffSentinel). WoW Forever always counts as a modern client there, never as Classic. `/gsgame` shows what was detected in the chat. Nothing else changes for players

## 0.9.5
- **WoW Forever: new "Favor" tab** (Merchant's Favor)
  - **Favor planner:** put favor recipes (click) and goals – Pack Kodo 6000, Minimule 1500, profession certification 1000, tabard 200 – on a wish list; the addon shows your balance and how much is still missing. Learned recipes drop out by themselves
  - **Favor recipes of your profession** with cost, reputation and **who in the guild already knows them** (data from GuildSentinel/RaidMaster)
  - **Crate calculator:** all 30 Waylaid Crates with the cheapest material bundle (AH or vendor prices), the empty crate from the AH and **gold per favor point**. Crates in your bags come first, "ready" means the material is already there. The favor of artisan crates is still estimated
- **WoW Forever: buying at the vendor** (levelling plan, craft today) now uses the vendor functions of the modern client – the old ones no longer exist there (test in the client)
- When AHSentinel reads Merchant's Favor costs at the vendor, ProfessionSentinel uses them if it has none of its own yet
- 0.9.3 and 0.9.4 (shared game-version detection) were withdrawn; it will come later for all GoldSentinel addons together

## 0.9.2
- **WoW Forever: supply-camp recipes cost Merchant's Favor, not gold.** The 310 recipes of "Durotar Supply and Logistics" (Horde, Barrens) and the "Azeroth Commerce Authority" (Alliance, Three Corners) showed a gold price that does not apply in the game. The tooltip now shows the cost in **Merchant's Favor** and the required **reputation** (Alliance players see their faction)
- The values come from public guides (beta). **When you open a supply-camp vendor, the addon reads the real costs** and remembers them – they then win over the guide values. Once you have seen the currency at the vendor, the tooltip also shows how much of it you have
- Recipes that regular vendors sell as well (e.g. Smoked Sagefish) keep their gold price

## 0.9.1
- **WoW Forever: listing fee** – every auction costs at least 1 silver and it is not refunded. It is now taken off the AH proceeds (on top of the 5 % cut): making gold, levelling, craft today, disenchant materials
- Cheap items are therefore often worth more at the vendor – the addon then uses the vendor price (e.g. AH 1s 50c → only 42c left, the vendor pays 71c)
- The tooltip shows the fee as its own line

## 0.9.0
- **Craft today** (top of the "Ranking" tab, `/ps heute`): the most profitable crafts of all your professions – learned recipes, sold in the AH, net after the 5 % cut; at most 5 per recipe and 20 % of your gold per row
- **One click = next step:** buy vendor reagents (vendor open) → buy AH reagents (via AHSentinel) → craft (profession window open) → list in the AH (via AHSentinel)
- API for AHSentinel: the craft suggestions can show up in its "Heute tun" (coming with the next AHSentinel version)

## 0.8.3
- Internal: the developer test-mode window (`/ps test`) now opens on the first try after login. Nothing changes for players

## 0.8.2
- Internal: the developer autotest names the reason when the test-mode window does not open, and only toggles groups that have rows (no more false warnings for empty rankings). Nothing changes for players

## 0.8.1
- Retail: fixed the error "Attempt to register unknown event TRADE_SKILL_UPDATE" while loading – profession events are only registered if the client knows them

## 0.8.0
- **Retail** (12.1.5 Midnight, interface 120105): ProfessionSentinel now runs in regular WoW as well – with about **10,170 recipes of every expansion** straight from the Retail client
- In Retail **every expansion is its own profession with its own skill**, like the profession window (e.g. "Midnight Leatherworking", "Classic Leatherworking") – recipes, lifeline, ranking, levelling plan to the expansion's cap, reputation, recipe alarm and reagent tooltip work there
- Retail has no QuestieDB: no vendor, drop and trainer locations (the Trainers tab is hidden there); vendor goods like threads and dyes come from Classic, new vendor prices are read by AHSentinel when you visit a vendor
- Enchanting in Retail: only "sell enchants" – the disenchant tables do not apply there
- Vendor prices: where the data knows none, ProfessionSentinel uses the price AHSentinel read at the vendor (all game versions)

## 0.7.1
- Internal: automatic in-game test for the developer (opens every tab and button for each profession, catches Lua errors and writes a report). Nothing changes for players

## 0.7.0
- **Levelling plan** (new "Plan" tab): from your skill to 75/150/225/300 – which recipe how often, with a shopping list (missing after bags and bank). One click buys exactly what is missing at the open vendor, another puts the AH reagents into AHSentinel's sniper (market value + 10 %)
- **Reputation recipes:** the tooltip shows which reputation and standing is needed – green if you have it (also new Forever factions like Kirin Tor)
- **Recipe alarm:** when a recipe you or one of your characters misses is in the AH (AHSentinel scan) you get a message with a sound; the Recipes tab lists them on top, click = sniper. On/off: `/ps alarm`
- **Guild** (data from GuildSentinel / RaidMaster): who can craft the recipe (online first), group "Nobody in the guild knows" and the **cooldowns** (transmute, mooncloth, salt shaker)
- **Recipes in your bags:** who still needs them – or nobody (then sell); **reagent tooltip:** how many recipes use an item and which of them you know (raid materials like Lava Core too)
- **Sell enchants:** right-click whispers materials and price to the customer (also with their own materials)
- Levelling: profitable recipes with a low chance no longer win just because many crafts add up – profit counts per craft × chance

## 0.6.5
- Enchanting: at the **first login** a window asks for your goal – **make gold** (default, marked), **sell enchants** or **both**. It stays open until you picked one, and you close it yourself with "Done". Until then make gold applies. Change it later with `/ps ziel` or at the top of the "Enchanter" tab

## 0.6.4
- Enchanting: no question at login any more – the default is **make gold**. Switching to selling enchants or both is optional with `/ps ziel` or at the top of the "Enchanter" tab; once per character a short chat hint explains it

## 0.6.3
- Test mode and self-test (`/ps test`, `/ps selftest`) are now only available to the developer – like in AHSentinel. For everyone else the addon works exactly the same, just without these tools

## 0.6.2
- Enchanter: "Bargains in the AH" only lists items that keep your **minimum margin when disenchanting** – exactly the ones the sniper buys

## 0.6.1
- Only for enchanters with the goal "make gold" or "both": **buy with the sniper** – one click puts the bargains (items cheaper than disenchanted) or the AH reagents of your best "craft & disenchant" recipes into AHSentinel's sniper. Max price and amount are set, you only set the budget
- **Minimum margin when disenchanting** (default 20 %): you pay at most 80 % of what the materials bring after the AH cut
- Disenchanting only lives in the "Enchanter" tab now: "Making gold" in the other professions' ranking counts selling only again
- "Craft & disenchant" now covers the recipes of **all your professions**

## 0.6.0
- Enchanting: characters with enchanting are asked once what for – **make gold**, **sell enchants** or **both**. The enchanting part follows that choice, everything else stays the same. Change it any time with `/ps ziel` or in the new "Enchanter" tab
- **Make gold:** disenchant value of every craftable item (materials minus the 5 % AH cut). "Making gold" takes disenchanting when it brings more (DE); new group **"Craft & disenchant"** – buy reagents, craft, disenchant, sorted by profit
- "Enchanter" tab: **bargains in the AH** that cost less than they bring disenchanted, and the **learned drop chances** compared with the starting values
- Drop chances learn from every disenchant – yours and those of every player with AHSentinel. Starting values for green items: 75 % dust, 20 % essence, 5 % shard (weapons the other way round)
- **Sell enchants:** all your enchants with their material cost (AH or vendor prices) and your **selling price** – you set the surcharge in % and a minimum profit
- Levelling still counts selling only
- Test mode: simulate an enchanter and cycle through the three goals

## 0.5.1
- Profit calculation deducts the 5 % auction house cut from the sale price – ranking, making gold and net per point use what you actually receive
- If the vendor pays more after the cut, the vendor value counts
- Tooltip shows AH price, AH cut (5 %) and what you receive from the AH

## 0.5.0
- Gold in the ranking: "Levelling" sorted by gold per skill point, new group "Making gold" sorted by net profit per craft – grey recipes included
- Reagent costs: vendor items at the vendor price, everything else at the AH value (also farmed material); product at the higher of AH value and vendor sell value
- AH values from AHSentinel (otherwise TSM or Auctionator); without an AH addon the ranking stays on reagents per skill point
- Rows show where the reagents come from (AH / vendor / farm) and "+10s 80c/pt"; the tooltip breaks down every reagent with price, cost, sell value and net
- Test mode: "test prices" to try the gold ranking without an AH scan

## 0.4.0
- Levelling ranking: every recipe that gives points at your skill – learned and not learned – sorted by reagents per skill point (reagents ÷ chance of a point)
- New "Ranking" tab with the full list, top 10 on top of the "Recipes" tab; recipes you still have to learn are tagged [learn] with their source
- Star on the best learned recipe in Blizzard's recipe list, hint with place and reagents per point on the profession window (click selects it)
- Recipes far above your skill no longer count as orange: missing learn levels are estimated (WoW Forever from the Era level of the same recipe)
- Classic Era: Season of Discovery recipes removed (1267 real Era recipes)

## 0.3.0
- New "Trainers" tab: every trainer of the open profession by rank – Journeyman (to 150), Expert (to 225), Artisan (to 300), specialisations – with zone, coordinates and faction; your next rank is marked
- Vendors and drop mobs in the recipe tooltip now show zone and coordinates
- Click a trainer for a waypoint; right-click a recipe for a waypoint to the nearest vendor (TomTom if installed, otherwise the game's map pin)
- Zone names in the client's language; new WoW Forever zones (Isle of Zephras, Riverlands) supported
- Test mode: trainer and waypoint checks, "test waypoint" button

## 0.2.0
- Detects the game version from the client and adapts: WoW Forever (own recipes and skill levels – many recipes turn grey sooner) and Classic Era (classic profession and enchanting windows)
- Lifeline: a thin line under every recipe (orange → yellow → green → grey) with a marker at your skill and how many crafts it takes until the next colour – in Blizzard's recipe list and in the "All recipes" panel
- Tooltip shows crafts until yellow, green and grey
- Test mode (/ps test): diagnostics, simulated skill, simulated learned state, panel without profession window, self-test (/ps selftest)
- /ps line toggles the lifeline
- Fixed swapped skill levels on a few client recipes (e.g. Charged Scale of Onyxia)

## 0.1.0
- First release for WoW Forever (Interface 16001)
- "All recipes" panel docked to the profession window, grouped like the client's categories
- Learned recipes greyed out, missing recipes in rarity colour
- Tooltips with skill levels, reagents and recipe sources (trainer, vendor, drop, quest)
- Recipe item tooltips show learned / not learned for all your characters
- 2210 recipes, 934 of them new in WoW Forever
