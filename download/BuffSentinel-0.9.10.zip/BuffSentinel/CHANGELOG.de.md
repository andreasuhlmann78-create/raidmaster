# BuffSentinel – Änderungen

## 0.9.10
- Tooltips im Optionsfenster, im Gruppen-Raster, in der Reinigungsleiste und beim PayPal-Knopf erscheinen jetzt neben dem Fenster statt darüber und verdecken so keine anderen Knöpfe mehr.
- Testroutine (nur Entwickler): neuer Bereich K „oberflaeche“ prüft die Oberfläche im echten Client (aus der GoldSentinel-Vorlage, neue Datei `UICheck.lua`): eigene Tooltips verdecken keine Knöpfe (T140), kein Überlappen mit Blizzard- oder anderen GoldSentinel-Fenstern (T141, frei schwebende Anzeigen ausgenommen), Fenster ganz im Bildschirm (T142), Knopf-Beschriftungen nicht abgeschnitten (T143), angezeigte Spielwerte plausibel – Stufe, Klasse, Spielversion, Talentpunkte, Zeilen im Gruppen-Raster, eigene Buffs (T144), keine Fehlerschleife mit derselben Meldung über 10× (T145). Ohne echten Client werden T140–T143 übersprungen, nie als OK gezählt. Bereich K läuft zuerst, bevor andere Bereiche Testwerte setzen. Nur lesen, nichts wird verändert.

## 0.9.9
- WoW Forever: neu gelernte Zauber werden wieder ohne `/reload` erkannt. Das Ereignis LEARNED_SPELL_IN_TAB gibt es in Forever nicht; BuffSentinel hört jetzt zusätzlich auf LEARNED_SPELL_IN_SKILL_LINE und meldet nur Ereignisse an, die der Client kennt (C_EventUtils.IsEventValid, wo vorhanden).
- Testroutine (nur Entwickler): T29 lässt Ereignisse zu, die der Client nicht kennt, und prüft, dass neu gelernte Zauber immer erkannt werden; der Kampf-Bericht schreibt „echte Aktionen: im Kampf-Teil nicht gezählt“ statt eines alten Werts aus dem letzten automatischen Lauf.

## 0.9.8
- **WoW Forever / Retail – behebt Lua-Fehler aus den Testberichten** („GetAuraDataByIndex(): Auras cannot be accessed when secret while tainted by 'BuffSentinel'“, bei UNIT_AURA und direkt nach dem Kampf). BuffSentinel liest Auren jetzt nur noch, wenn das Spiel es erlaubt: nicht im Kampf, nicht im ersten Moment nach dem Kampf (stattdessen eine halbe Sekunde später), nicht bei Gruppenmitgliedern oder Zielen, die selbst kämpfen, und nicht, solange das Spiel geschützte Auren meldet. Verweigert das Spiel den Zugriff trotzdem, wird der Aufruf abgefangen, die letzten bekannten Werte bleiben (keine falschen „Buff fehlt“-Warnungen) und das Lesen pausiert 2 Sekunden – kein Lua-Fehler.
- Alte Clients (Classic Era, TBC, Wrath, Cata, MoP) unverändert.
- Testroutine (nur Entwickler): neuer Fall T139 stellt den verweigerten Zugriff, das verzögerte Lesen nach dem Kampf, ein kämpfendes Gruppenmitglied und geschützte Auren nach.

## 0.9.7
- **Sprachen:** BuffSentinel richtet sich jetzt nach der Sprache des Spiel-Clients (für alle Spieler). Englisch ist der Standard, Deutsch vollständig übersetzt; alle anderen Sprachen zeigen vorerst Englisch. Alle Texte stehen in der neuen Datei `Locales.lua`: Chat-Meldungen, Optionen, Gruppen-Raster, Tooltips, Minimap-Button, Testleiste, Anordnen-Leiste, Warnungen auf den Buttons (z. B. „FREIZAUBER!“ / „CLEARCASTING!“), Skillungs- und Tonnamen sowie der Bericht der Testroutine. Zauber- und Talentnamen kommen wie bisher aus dem Spiel.
- Neuer Befehl `/bsen help` (auch `/bsen hilfe`) mit allen Befehlen; englische Kurzformen `/bsen move`, `/bsen errors`, `/bsen donate` funktionieren in jeder Sprache.
- Beschreibung in der Addon-Liste auf Englisch, im deutschen Client auf Deutsch.
- Testroutine (nur Entwickler): Sprachtests im Bereich F (jeder englische Text hat einen deutschen, Platzhalter stimmen überein, Hilfe unter einem englischen Client ohne Deutsch – T98, T137, T138); Endzählung „echte Aktionen: 0“ mit neuem Fall T136 (Senden, Chat und Kanal betreten werden nur mitgezählt, nie ausgelöst); die Bitte um `/reload` kommt nach jedem Lauf; T134 steht im Kampf-Bericht nur noch einmal.

## 0.9.6
- WoW Forever: Die Seiten Procs und Cooldowns zeigen jetzt denselben klaren Hinweis wie die übrigen Seiten – im Kampf keine Anzeige von Procs, Cooldowns und Buffs, Reinigen-Raster aus, Procs werden nicht automatisch gelernt. Die Zeile „lernt neue Procs automatisch“ erscheint in Forever nicht mehr. (Wie bisher zeigt BuffSentinel in Forever im Kampf nichts an; Buff-Erinnerungen kommen vor dem Pull und ausserhalb des Kampfes.)
- Beschädigte gespeicherte Einstellungen (falsche Werte, unvollständige Positionen) werden beim Laden repariert statt Lua-Fehler auszulösen.
- Forever/Retail: Tooltips von Gruppen-Raster, Buttons und Reinigungsleiste verketten keine geschützten Spielernamen mehr (kein Lua-Fehler im Kampf); Addon-Nachrichten und Kanal-Meldungen mit geschützten Werten werden ignoriert.
- Automatisches Lernen baut die Anzeige nicht mehr mitten im Einlesen der Auren neu auf.
- Fehler (auch beim Einlesen, auf den Optionsseiten und beim Namen-Teilen) werden gezählt, in `/bsen fehler` gezeigt und über die gemeinsame Datei `GoldSentinelTest.lua` (unverändert übernommen) an die Testberichte von GoldSentinel gemeldet. `/bsen fehler` zeigt zusätzlich die Zahl offener Berichte.
- Nur für den Entwickler: Testroutine `/bsen testroutine [bereich|kampf]`, `/bsen selbsttest` (simuliert WoW Forever über `GoldSentinelGame.SetTestFlavor`) und Knopf „Alles testen“. Sie sendet nichts, betritt keinen Kanal, wirkt keinen Zauber und lässt deine gespeicherten Einstellungen unverändert.

## 0.9.5
- Fehler in Event-Handlern werden jetzt mitgezählt und erscheinen in `/bsen fehler` (im Chat weiterhin nur der erste).
- Forever/Retail: Kann BuffSentinel die Buttons vor dem Kampf nicht mehr verstecken (Kampfsperre schon aktiv), holt es das direkt nach dem Kampf nach.
- WoW Forever – klar benannt, auch in den Optionen und auf der Seite „Reinigen“: im Kampf keine Anzeige von Procs, Cooldowns und Buffs (geheime Werte), das Reinigen-Raster ist aus (auch ausserhalb des Kampfes), Procs werden nicht automatisch gelernt. Buff-Erinnerungen kommen vor dem Pull und ausserhalb des Kampfes.

## 0.9.4
- `GoldSentinelGame.lua` auf Version 2: setzt sich gegen frühe, zurückgenommene Fassungen durch, die andere GoldSentinel-Addons evtl. noch mitbringen – keine Lua-Fehler, wenn mehrere Addons gleichzeitig geladen sind.

## 0.9.3
- Versionserkennung über die gemeinsame Datei `GoldSentinelGame.lua` aller GoldSentinel-Addons (unverändert übernommen, in der .toc direkt nach `GoldSentinelDev.lua`). WoW Forever wird auch über die Projekt-ID des Spiels erkannt, falls sich die Interface-Nummer zum Launch ändert.
- Die Sperren für den modernen Client hängen jetzt an `GoldSentinelGame.IsModern` (Forever, Retail oder ein Client mit geheimen Werten). Classic Era, TBC, Wrath, Cata und MoP Classic laufen unverändert.
- Gruppennamen laufen über `GoldSentinelGame.Short` (geheime Namen werden nie gespeichert).
- `/gsgame` zeigt die erkannte Spielversion; `/bsen fehler` zeigt dieselbe Zeile zusätzlich zur Fehler-Diagnose.

## 0.9.1 – WoW Forever fest gemacht
- WoW Forever läuft auf dem modernen Client mit denselben Addon-Sperren wie Retail (kein Kampflog, im Kampf „geheime Werte“). BuffSentinel behandelt Forever jetzt genauso: Buff-Erinnerungen vor dem Pull, im Kampf keine Auswertung von Auren, Abklingzeiten, Lebenspunkten und Namen – einmaliger Hinweis im Chat (für Procs im Kampf den Cooldown Manager des Spiels nutzen). Die Weiche prüft, ob das Spiel geheime Werte kennt; Classic Era, TBC, Wrath, Cata und MoP Classic laufen unverändert.
- Kampflog wird auf Forever und Retail nicht mehr registriert; Überwältigen, Rache und Riposte werden dort über „Fähigkeit nutzbar“ erkannt.
- Geheime Werte werden überall geprüft, bevor gerechnet oder verglichen wird: eigene Auren (Stapel, Ablauf, Zauber-ID), Ziel-Lebenspunkte (Hinrichten), Gruppennamen, Debuff-Arten beim Reinigen, Abklingzeiten. Geheime Abklingzeiten gelten nicht mehr als „bereit“ – kein falsches Aufleuchten mit Ton beim Pull.
- Forever/Retail: Vor dem Kampf werden alle Klick-Buttons versteckt, damit keine unsichtbaren Buttons im Kampf Klicks abfangen.
- Fehler frieren die Anzeige nicht mehr ein: jeder Button wird einzeln abgesichert, Fehler werden gezählt. Neuer Befehl `/bsen fehler` zeigt die Diagnose.

## 0.9.0
- Neuer Reiter „Optionen“ (ersetzt „Zonen & Anzeige“) mit allen Einstellungen an einem Ort: Warntöne, Zonen, Cooldowns & Reinigen, automatisches Lernen, Anzeige & Anordnen, Grössen, Minimap, Namen teilen.
- Warntöne frei wählbar, für jede Art einzeln (Hupe bei ausgelaufenem eigenem Buff, Gruppen-Buff fehlt, Proc, Cooldown bereit, Debuff zum Reinigen, wichtiger Raid-Debuff, Klingel):
  - Ein/Aus und Ton pro Klasse und Skillung (wechselt mit der Skillung), mit „für alle Skillungen übernehmen“ und „Skillung auf Standard“.
  - Grosse Auswahl: rund 50 Töne aus dem Spiel (nur die, die es in deiner WoW-Version gibt), Glocken, Gong, Kriegstrommel und weitere Effekte, alle Töne aus LibSharedMedia anderer Addons und eigene Dateien bzw. Sound-IDs.
  - Auswahlfenster mit Anhören (Rechtsklick nur anhören), Knopf „Anhören“ in jeder Zeile.
  - Tonkanal wählbar (Gesamt, Effekte, Dialog, Umgebung, Musik) und Abstand der Hupe 3–60 s.
- Bisherige Ton-Einstellungen werden übernommen.

## 0.8.6
- Schlachtruf hupt jetzt wie alle eigenen Buffs, bis er erneuert ist (keine Klingel mehr als Standard; die Klingel lässt sich pro Eintrag weiter einschalten).
- Druide Wilder Kampf: Der Freizauber-Button wirkt je nach Gestalt Schreddern (Katze) oder Zermalmen (Bär) und erscheint in beiden Gestalten. Die Zuordnung passt sich an, auch wenn noch nicht alle Gestalten gelernt sind.

## 0.8.5
- Läuft ein eigener Buff aus (Rüstung, Schild, Waffenverzauberung, Gift …), hupt BuffSentinel alle 5 Sekunden, bis er erneuert ist (abschaltbar, Abstand 5/10/15/30 s). Einträge mit Klingel wie Schlachtruf klingeln stattdessen.
- Procs erscheinen nur noch, wenn sie in deiner aktuellen Haltung bzw. Gestalt möglich sind (z. B. Überwältigen nur in Kampfhaltung, Schreddern nur in Katzengestalt). Fehlt nur Wut/Mana/Energie, bleibt der Proc blau getönt sichtbar.

## 0.8.4
- Töne sind standardmässig aus (auch in bestehenden Profilen einmalig ausgeschaltet; danach gilt deine eigene Wahl).
- Neu: eigene Klingel pro Eintrag (Knopf „Ton“ auf den Seiten Procs, Buffs und Cooldowns). Sie klingelt auch, wenn die allgemeinen Töne aus sind. Standardmässig hat nur Schlachtruf eine Klingel.
- „Sounds testen“ spielt auch die Klingel.

## 0.8.3
- Der Testmodus mit allen Klassen und Skillungen ist jetzt ein Entwickler-Werkzeug (GoldSentinelDev). Für alle anderen öffnen Testmodus-Aufrufe (`/bsen test`, Shift + Linksklick auf den Minimap-Button) das Anordnen.
- „Sounds testen“ gibt es jetzt in der Anordnen-Leiste.

## 0.8.2
- Neu: Knopf „Anordnen“ oben im Einstellungsfenster (auch Strg + Linksklick auf den Minimap-Button oder `/bsen anordnen`). Zeigt wie im Testmodus alle deine eigenen Buttons zum Verschieben, dazu eine Leiste mit Grösse, Abstand und Richtung (waagrecht/senkrecht) für jede Gruppe.
- Fensterpositionen werden gespeichert (Einstellungen, Gruppen-Raster, Test- und Anordnen-Leiste). „Alle Positionen zurücksetzen“ setzt auch die Fenster zurück.

## 0.8.1
- Neu: Grösse pro Gruppe einstellbar – Procs, Buffs, Cooldowns und Reinigen je 50–200 %, zusätzlich zur Gesamtgrösse (Seite „Zonen & Anzeige“). Die Gruppen und frei platzierten Buttons bleiben beim Ändern an ihrer Stelle.
- Neuer Knopf „Grössen zurücksetzen“.

## 0.8.0
- Neu: **Automatisches Lernen.** Trifft BuffSentinel auf Procs oder Fähigkeiten, die noch nicht in seinen Daten stehen (z. B. Neuheiten in WoW Forever), nimmt es sie selbst auf:
  - Procs: Ein kurzer Buff, den du dir im Kampf selbst gibst und der dreimal beim Wirken desselben Zaubers verbraucht wird, bekommt einen Proc-Button für diesen Zauber. Buffs, die nur auslaufen (Waffen-Verzauberungen, Schmuckstücke), und Buffs von anderen Spielern werden nicht aufgenommen.
  - Fähigkeiten: Klassenzauber mit mindestens 10 s Abklingzeit kommen in die Cooldown-Leiste, sobald du sie wirkst oder neu erlernst (Lehrer, Talentpunkt).
  - Gelerntes merkt sich BuffSentinel pro Skillung und für alle Charaktere des Accounts.
  - Entdeckungen werden mit anderen BuffSentinel-Nutzern geteilt (nur Zauber-IDs, abschaltbar).
  - Übersicht, Entfernen und Ein/Aus auf der Seite „Aufnahme“.
- Noch nicht erlernte Zauber (grau im Zauberbuch von Cata/MoP) und Zauber anderer Spezialisierungen gelten nicht mehr als gelernt.

## 0.7.3
- Lange zusammengesetzte Wörter werden an der Wortfuge auf zwei Zeilen getrennt (z. B. „BLITZSCHLAG-“ / „SCHILD!“), statt die Schrift zu verkleinern. Kleiner wird sie nur, wenn das nicht reicht.
- Umlaute werden in Warnungen jetzt richtig gross geschrieben („SEELENSTÄRKE“ statt „SEELENSTäRKE“).

## 0.7.2
- Priester: Woge des Lichts wirkt in TBC Göttliche Pein (Blitzheilung erst ab WotLK).
- Jäger: Fass! ist in TBC eine Grundfähigkeit – jetzt bei allen Skillungen.
- Krieger: Befehlsruf ab TBC; neue Buff-Erinnerung für Toben (TBC, Furor).
- Procs über einen Buff heissen nach ihrer Quelle (z. B. „SCHATTENTRANCE!“), darunter steht der Zauber, den der Klick wirkt.
- Lange Beschriftungen werden automatisch kleiner statt abgeschnitten.
- Reinigungsleiste sitzt jetzt links unter den Buffs, die Titel von Cooldowns und Reinigen stehen über ihrer Fläche – keine Überlappungen mehr.

## 0.7.1
- Behoben: Hauptbaum wird richtig erkannt (z. B. 14/41/0 = Furor statt Waffen), auch mit Zweitskillung – die aktive Talentgruppe wird ausdrücklich gelesen.
- Behoben: Talente und Procs werden nach WoW-Version gefiltert. WoW-Forever-Talente (Bloodthrill, Vanguard) und WotLK-Procs (Plötzlicher Tod, Schäumendes Blut, Schwert und Schild, Hot Streak) erscheinen nicht mehr in TBC/Classic Era.
- Behoben: Der Testmodus zeigt Talent-Procs nur für die gewählte Skillung (z. B. Hot Streak nur Feuer, Anmut der Natur nur Gleichgewicht).
- Die Listen in den Einstellungen springen beim Abhaken nicht mehr; neuer Knopf „Auto“ setzt einen Eintrag auf die automatische Auswahl zurück.
- Fehlende Schriftzeichen (Pfeil, Häkchen) und ein veralteter Hinweistext behoben.
- Testmodus-Layout: zweizeilige Beschriftungen, Gruppentitel neben der Fläche, Flächen wachsen mit der Anzahl Buttons, Testleiste ganz oben, Einstellungsfenster schliesst sich beim Start, Reinigungsleiste mit 5 Beispielplätzen und ausgeblendet bei Klassen ohne Reinigen.
- Hexenmeister-Procs heissen nach ihrer Quelle (Schattentrance, Heimzahlen).
- Server-Sync versucht den Kanalbeitritt mehrmals und zeigt einen klaren Status.
- Behoben: Tooltip blieb nach dem Öffnen des Spendenfensters stehen.

## 0.7.0
- Neuer Knopf „Unterstützen“ (PayPal) oben im Einstellungsfenster und auf der Seite „Zonen & Anzeige“, auch per `/bsen spenden`. Öffnet sich nur auf Klick – kein Aufpoppen, keine Chat-Meldungen.

## 0.6.3
- Mindestens 3 Sekunden zwischen Warntönen, derselbe Ton höchstens alle 4 Sekunden.
- „Sounds testen“ spielt alle Töne mit 3 Sekunden Abstand und zeigt an, welcher läuft.

## 0.6.1
- WoW Forever: neue Paladin- (Siegel der Wut, Lichtwacht, Stimme der Wahrheit, Schnelles Richturteil, Bollwerk des Templers, Lichtenergie) und Schamanen-Fähigkeiten (Wut des Weitsehers, Feuernova, Totemprojektion).
- Testmodus in Classic Era zeigt nur die Klassen deiner Fraktion.

## 0.6.0
- Testmodus mit Beispielanzeige für alle Klassen und Skillungen; Buttons frei platzierbar.

## 0.5.0
- Reinigungsleiste für Mitspieler und Entzaubern von Gegnern.

## 0.4.0
- Erste Version: Proc-Buttons, Buff-Wächter mit Ein-Klick-Buff, Cooldown-Leiste, Skillungserkennung, alle WoW-Versionen.
