# ProfessionSentinel – Änderungen

## 0.2.0
- Erkennt die Spielversion am Client und passt sich an: WoW Forever (eigene Rezepte und Fertigkeitsstufen – viele Rezepte werden früher grau) und Classic Era (klassisches Berufs- und Verzauberungsfenster)
- Lebenslinie: dünne Linie unter jedem Rezept (orange → gelb → grün → grau) mit Markierung deiner Fertigkeit und wie oft du bis zur nächsten Farbe herstellen musst – in Blizzards Rezeptliste und im Panel „Alle Rezepte“
- Tooltip zeigt Herstellungen bis Gelb, Grün und Grau
- Testmodus (/ps test): Diagnose, simulierte Fertigkeit, simuliert gelernt/nicht gelernt, Panel ohne Berufsfenster, Selbsttest (/ps selftest)
- /ps line schaltet die Lebenslinie an und aus
- Vertauschte Fertigkeitsstufen bei einzelnen Rezepten im Client korrigiert (z. B. Aufgeladene Schuppe von Onyxia)

## 0.1.0
- Erste Version für WoW Forever (Interface 16001)
- Knopf „Alle Rezepte“ im Berufsfenster, gegliedert wie die Kategorien im Spiel
- Gelernte Rezepte ausgegraut, fehlende in Seltenheitsfarbe
- Tooltips mit Fertigkeitsstufen, Reagenzien und Quelle (Lehrer, Händler, Drop, Quest)
- Tooltip bei Rezepten: gelernt oder nicht, auch für deine anderen Charaktere
- 2210 Rezepte, davon 934 neu in WoW Forever
