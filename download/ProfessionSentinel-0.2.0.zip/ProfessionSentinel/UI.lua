local _, ns = ...
local L = ns.L

-- Panel docked to the profession window of the running game version:
--   WoW Forever: ProfessionsFrame (Blizzard_Professions, Retail-style)
--   Classic Era: TradeSkillFrame (Blizzard_TradeSkillUI) and CraftFrame (Blizzard_CraftUI, enchanting)
-- Shows every recipe of the open profession: learned ones greyed out, missing ones in rarity colour,
-- each with the lifeline (crafts until yellow / green / grey).

local UI = {}
ns.UI = UI

local PANEL_WIDTH = 420
local ROW_HEIGHT = 28

local panel, scrollBox, scrollBar, searchBox, missingCheck, summary, testBadge, infoText
local collapsed
local currentHost -- frame the panel is docked to (nil = free-floating test mode)

---------------------------------------------------------------------------
-- Current profession and rank
---------------------------------------------------------------------------
local function ForeverProfession()
    if not C_TradeSkillUI then return nil end
    local prof, rank, maxRank
    if C_TradeSkillUI.GetChildProfessionInfo then
        local info = C_TradeSkillUI.GetChildProfessionInfo()
        if info and info.professionID then
            prof = ns.ResolveProf(info.professionID) or ns.ResolveProf(info.parentProfessionID)
            rank, maxRank = info.skillLevel, info.maxSkillLevel
        end
    end
    if not prof and C_TradeSkillUI.GetBaseProfessionInfo then
        local info = C_TradeSkillUI.GetBaseProfessionInfo()
        if info and info.professionID then
            prof = ns.ResolveProf(info.professionID)
            rank = rank or info.skillLevel
            maxRank = maxRank or info.maxSkillLevel
        end
    end
    return prof, rank, maxRank
end

local function EraProfession()
    if currentHost == CraftFrame and GetCraftDisplaySkillLine then
        local name, rank, maxRank = GetCraftDisplaySkillLine()
        return ns.MatchProfession(name), rank, maxRank
    end
    if GetTradeSkillLine then
        local name, rank, maxRank = GetTradeSkillLine()
        return ns.MatchProfession(name), rank, maxRank
    end
end

local function CurrentProfession()
    local prof, rank, maxRank
    if ns.Sim and ns.Sim.prof then
        prof = ns.Sim.prof
        rank, maxRank = ns.Scan:Rank(prof)
    elseif ns.IsForever then
        prof, rank, maxRank = ForeverProfession()
    else
        prof, rank, maxRank = EraProfession()
    end
    if prof and not rank then rank, maxRank = ns.Scan:Rank(prof) end
    return prof, ns.EffectiveRank(rank), maxRank
end

local function IsLearned(r)
    if ns.IsLearned(r) then return true end
    if ns.Sim and ns.Sim.known then return false end
    -- WoW Forever: ask the open profession window directly
    if ns.IsForever and C_TradeSkillUI and C_TradeSkillUI.GetRecipeInfo and not (ns.Sim and ns.Sim.prof) then
        local linked = C_TradeSkillUI.IsTradeSkillLinked and C_TradeSkillUI.IsTradeSkillLinked()
        if not linked then
            local info = C_TradeSkillUI.GetRecipeInfo(r.spell)
            if info and info.learned then
                local c = ns.Char(); if c then c.known[r.spell] = true end
                return true
            end
        end
    end
    return false
end

---------------------------------------------------------------------------
-- Colours and texts
---------------------------------------------------------------------------
local DIFF = { red = "ff4040", orange = "ff8040", yellow = "ffd23f", green = "40c040", grey = "808080", white = "ffffff" }

local function SkillLevelsText(r)
    local parts = {}
    if (r.req or 0) > 1 then parts[#parts + 1] = "|cff" .. DIFF.orange .. r.req .. "|r" end
    if (r.yellow or 0) > 0 then
        parts[#parts + 1] = "|cff" .. DIFF.yellow .. r.yellow .. "|r"
        parts[#parts + 1] = "|cff" .. DIFF.green .. r.green .. "|r"
        parts[#parts + 1] = "|cff" .. DIFF.grey .. r.grey .. "|r"
    end
    return table.concat(parts, "  ")
end

local function MoneyText(copper)
    if not copper or copper <= 0 then return "" end
    if GetCoinTextureString then return GetCoinTextureString(copper) end
    return string.format("%dg %ds %dc", copper / 10000, (copper / 100) % 100, copper % 100)
end

---------------------------------------------------------------------------
-- Sources (Trainer / Vendor / Drop ...)
---------------------------------------------------------------------------
local function NPCLine(id, playerFaction)
    local n = ns.NPCs[id]
    if not n then return "NPC " .. id, true end
    local name, zone, fac, sub, lvl = n[1], n[2], n[3], n[4], n[5]
    local s = name
    if sub then s = s .. " |cff9d9d9d<" .. sub .. ">|r" end
    local extra = {}
    if lvl then extra[#extra + 1] = L.LEVEL .. " " .. lvl end
    if zone then extra[#extra + 1] = zone end
    if #extra > 0 then s = s .. " |cffb0b0b0(" .. table.concat(extra, ", ") .. ")|r" end
    local friendly = true
    if fac and playerFaction then
        local want = playerFaction == "Horde" and "H" or "A"
        friendly = fac:find(want, 1, true) ~= nil
    end
    return s, friendly
end

function UI:AddSourceLines(tt, r)
    local faction = UnitFactionGroup("player")
    local S = ns.SRC
    if bit.band(r.src, S.TRAINER) ~= 0 then
        tt:AddLine((r.req or 0) > 1 and string.format(L.SRC_TRAINER_AT, r.req) or L.SRC_TRAINER, 1, 1, 1)
    end
    if bit.band(r.src, S.AUTO) ~= 0 then tt:AddLine(L.SRC_AUTO, 1, 1, 1) end
    for _, ri in ipairs(r.recipeItems) do
        local q = ns.ItemQuality(ri.id)
        local line = "|cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(ri.id) .. "|r"
        if ri.rs then line = line .. "  |cffb0b0b0(" .. L.REQ .. " " .. ri.rs .. ")|r" end
        tt:AddLine(line)
        if ri.v then
            local sorted = {}
            for _, id in ipairs(ri.v) do
                local s, ok = NPCLine(id, faction)
                if ok then table.insert(sorted, 1, { s, ok }) else sorted[#sorted + 1] = { s, ok } end
            end
            for i, e in ipairs(sorted) do
                if i <= 4 then
                    tt:AddLine("   " .. L.SRC_VENDOR .. ": " .. e[1] .. (e[2] and "" or " |cffff6060[" .. L.OTHER_FACTION .. "]|r"), 0.85, 0.85, 0.85)
                end
            end
            if #ri.v > 4 then tt:AddLine("   " .. string.format(L.MORE, #ri.v - 4), 0.6, 0.6, 0.6) end
            if ri.bp then tt:AddLine("   " .. MoneyText(ri.bp), 1, 1, 1) end
        end
        if ri.d then
            if (ri.dn or 0) > 15 then
                tt:AddLine("   " .. string.format(L.SRC_WORLDDROP, ri.dn), 0.85, 0.85, 0.85)
            else
                for i, id in ipairs(ri.d) do
                    if i <= 4 then tt:AddLine("   " .. L.SRC_DROP .. ": " .. (NPCLine(id)), 0.85, 0.85, 0.85) end
                end
                if (ri.dn or #ri.d) > 4 then tt:AddLine("   " .. string.format(L.MORE, (ri.dn or #ri.d) - 4), 0.6, 0.6, 0.6) end
            end
        end
        if ri.qr then tt:AddLine("   " .. string.format(L.SRC_QUEST, ri.qr), 0.85, 0.85, 0.85) end
        if ri.o then tt:AddLine("   " .. string.format(L.SRC_CONTAINER, ri.o), 0.85, 0.85, 0.85) end
        if not (ri.v or ri.d or ri.qr or ri.o) then tt:AddLine("   " .. L.SRC_UNKNOWN, 0.6, 0.6, 0.6) end
    end
end

local function LifelineTooltipLines(tt, r, rank)
    local LL = ns.Lifeline
    local c = rank and LL and LL.Calc(r, rank)
    if not c then return end
    tt:AddLine(" ")
    tt:AddLine(L.LL_TITLE, 1, 0.82, 0)
    local parts = {}
    local function add(key, n, exact)
        if n then parts[#parts + 1] = "|cff" .. LL.HEX[key] .. L["LL_" .. key:upper()] .. " " .. (exact and "" or "≈") .. math.floor(n + 0.5) .. "×|r" end
    end
    add("yellow", c.toYellow, true)
    add("green", c.toGreen, c.toYellow and c.toGreen and r.green <= r.yellow)
    add("grey", c.toGrey, false)
    if #parts > 0 then
        tt:AddLine(table.concat(parts, "   "))
    else
        tt:AddLine(c.textColored)
    end
    tt:AddLine(L.LL_TIP_EXACT, 0.6, 0.6, 0.6, true)
end

function UI:ShowRecipeTooltip(owner, r, rank)
    local tt = GameTooltip
    tt:SetOwner(owner, "ANCHOR_RIGHT")
    local qr, qg, qb = ns.QualityRGB(r.quality)
    tt:AddLine(ns.RecipeName(r), qr, qg, qb)
    if r.cat then tt:AddLine(ns.ProfName(r.prof) .. " - " .. r.cat, 0.7, 0.7, 0.7) end
    if r.isNew then tt:AddLine("|cff3fc7eb" .. L.F_NEW .. "|r") end
    if IsLearned(r) then tt:AddLine(L.ALREADY_LEARNED, 0.5, 0.5, 0.5) end
    local levels = SkillLevelsText(r)
    if levels ~= "" then tt:AddDoubleLine(L.SKILL_LEVELS, levels, 1, 0.82, 0) end
    LifelineTooltipLines(tt, r, rank)
    if r.out then
        local cnt = (r.outMax or 1) > 1 and (r.outMin == r.outMax and (" x" .. r.outMin) or (" x" .. r.outMin .. "-" .. r.outMax)) or ""
        local q = ns.ItemQuality(r.out)
        tt:AddLine(" ")
        tt:AddLine(L.CREATES .. ": |cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(r.out) .. "|r" .. cnt, 1, 0.82, 0)
    elseif r.ench then
        tt:AddLine(" ")
        tt:AddLine(L.ENCHANT, 1, 0.82, 0)
    end
    if #r.reagents > 0 then
        tt:AddLine(" ")
        tt:AddLine(L.REAGENTS, 1, 0.82, 0)
        for i = 1, #r.reagents, 2 do
            local id, need = r.reagents[i], r.reagents[i + 1]
            local have = ns.GetItemCount(id)
            local q = ns.ItemQuality(id)
            local col = have >= need and "1eff00" or "ff6060"
            tt:AddDoubleLine("|T" .. ns.GetItemIcon(id) .. ":0|t |cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(id) .. "|r",
                "|cff" .. col .. have .. "/" .. need .. "|r")
        end
    end
    tt:AddLine(" ")
    tt:AddLine(L.SOURCES, 1, 0.82, 0)
    self:AddSourceLines(tt, r)
    tt:Show()
end

---------------------------------------------------------------------------
-- Selecting a learned recipe in the Blizzard window
---------------------------------------------------------------------------
local function SelectInBlizzard(r)
    if ns.IsForever then
        if C_TradeSkillUI and C_TradeSkillUI.OpenRecipe then C_TradeSkillUI.OpenRecipe(r.spell) end
        return
    end
    local wanted = { [r.name:lower()] = true }
    if r.nameEN then wanted[r.nameEN:lower()] = true end
    if currentHost == CraftFrame and GetNumCrafts then
        for i = 1, GetNumCrafts() do
            local name = GetCraftInfo(i)
            if name and wanted[name:lower()] then
                if CraftFrame_SetSelection then CraftFrame_SetSelection(i) end
                if CraftFrame_Update then CraftFrame_Update() end
                return
            end
        end
    elseif GetNumTradeSkills then
        for i = 1, GetNumTradeSkills() do
            local name = GetTradeSkillInfo(i)
            if name and wanted[name:lower()] then
                if TradeSkillFrame_SetSelection then TradeSkillFrame_SetSelection(i) end
                if TradeSkillFrame_Update then TradeSkillFrame_Update() end
                return
            end
        end
    end
end

---------------------------------------------------------------------------
-- List rows
---------------------------------------------------------------------------
local function RowIcon(r)
    if r.out then return ns.GetItemIcon(r.out) end
    return ns.GetSpellIcon(r.spell)
end

local function InitHeader(button, node)
    local data = node:GetData()
    if not button.label then
        button:SetHeight(ROW_HEIGHT)
        button.bg = button:CreateTexture(nil, "BACKGROUND")
        button.bg:SetAllPoints()
        button.bg:SetColorTexture(1, 1, 1, 0.06)
        button.arrow = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        button.arrow:SetPoint("LEFT", 4, 0)
        button.label = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        button.label:SetPoint("LEFT", 20, 0)
        button.count = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        button.count:SetPoint("RIGHT", -6, 0)
        button:SetHighlightTexture("Interface\\Buttons\\UI-Listbox-Highlight2", "ADD")
        button:GetHighlightTexture():SetAlpha(0.2)
    end
    button.label:SetText(data.name)
    button.count:SetText(data.known .. "/" .. data.total)
    button.arrow:SetText(node:IsCollapsed() and "+" or "-")
    button:SetScript("OnClick", function()
        node:ToggleCollapsed()
        collapsed[data.name] = node:IsCollapsed() or nil
        button.arrow:SetText(node:IsCollapsed() and "+" or "-")
    end)
    button:SetScript("OnEnter", nil)
    button:SetScript("OnLeave", nil)
end

local function InitRow(button, node)
    local data = node:GetData()
    local r = data.recipe
    if not button.name then
        button:SetHeight(ROW_HEIGHT)
        button.check = button:CreateTexture(nil, "OVERLAY")
        button.check:SetSize(14, 14)
        button.check:SetPoint("TOPLEFT", 4, -3)
        button.check:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready")
        button.icon = button:CreateTexture(nil, "ARTWORK")
        button.icon:SetSize(16, 16)
        button.icon:SetPoint("TOPLEFT", 22, -2)
        button.name = button:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        button.name:SetPoint("LEFT", button.icon, "RIGHT", 6, 0)
        button.name:SetPoint("RIGHT", button, "RIGHT", -70, 0)
        button.name:SetJustifyH("LEFT")
        button.name:SetWordWrap(false)
        button.new = button:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        button.new:SetPoint("TOPRIGHT", -38, -4)
        button.new:SetTextColor(0.25, 0.78, 0.92)
        button.skill = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        button.skill:SetPoint("TOPRIGHT", -6, -4)
        button.skill:SetJustifyH("RIGHT")
        button.line = ns.Lifeline.Create(button, 2)
        button.line:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 44, 5)
        button.line:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -112, 5)
        button.hint = button:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
        button.hint:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -6, 2)
        button.hint:SetWidth(104)
        button.hint:SetJustifyH("RIGHT")
        button.hint:SetWordWrap(false)
        button:SetHighlightTexture("Interface\\Buttons\\UI-Listbox-Highlight2", "ADD")
        button:GetHighlightTexture():SetAlpha(0.25)
        button:RegisterForClicks("LeftButtonUp")
    end
    local learned = data.learned
    button.icon:SetTexture(RowIcon(r))
    button.icon:SetDesaturated(learned)
    button.icon:SetAlpha(learned and 0.5 or 1)
    button.check:SetShown(learned)
    local qr, qg, qb = ns.QualityRGB(r.quality)
    button.name:SetText(ns.RecipeName(r))
    if learned then
        -- leicht ausgegraut: rarity colour mixed with grey and dimmed
        button.name:SetTextColor(qr * 0.4 + 0.3, qg * 0.4 + 0.3, qb * 0.4 + 0.3)
        button.name:SetAlpha(0.6)
    else
        button.name:SetTextColor(qr, qg, qb)
        button.name:SetAlpha(1)
    end
    button.new:SetText(r.isNew and L.NEW_TAG or "")
    local lvl = (r.req or 0) > 1 and r.req or (r.yellow or 0)
    local calc = ns.Lifeline.Calc(r, data.rank)
    local stateHex = calc and ns.Lifeline.HEX[calc.state] or "ffffff"
    button.skill:SetText(lvl > 0 and ("|cff" .. stateHex .. lvl .. "|r") or "")
    button.skill:SetAlpha(learned and 0.6 or 1)
    if ns.db.lifeline ~= false then
        ns.Lifeline.Update(button.line, r, data.rank, learned)
        button.hint:SetText(calc and calc.textColored or "")
        button.hint:SetAlpha(learned and 0.6 or 1)
        button.hint:Show()
    else
        button.line:Hide()
        button.hint:Hide()
    end
    button:SetScript("OnEnter", function(self) UI:ShowRecipeTooltip(self, r, data.rank) end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    button:SetScript("OnClick", function()
        if IsModifiedClick and IsModifiedClick("CHATLINK") then
            local link = r.recipeItems[1] and ns.GetItemLink(r.recipeItems[1].id) or (r.out and ns.GetItemLink(r.out))
            if link and ChatEdit_InsertLink then ChatEdit_InsertLink(link) end
            return
        end
        if learned and not (ns.Sim and ns.Sim.prof) then SelectInBlizzard(r) end
    end)
end

local function MatchesSearch(r, text)
    if text == "" then return true end
    if r.searchText:find(text, 1, true) then return true end
    if r.out and ns.ItemName(r.out):lower():find(text, 1, true) then return true end
    for i = 1, #r.reagents, 2 do
        if ns.ItemName(r.reagents[i]):lower():find(text, 1, true) then return true end
    end
    return false
end

---------------------------------------------------------------------------
-- Refresh
---------------------------------------------------------------------------
function UI:Refresh()
    if not panel or not panel:IsShown() then return end
    testBadge:SetShown(ns.Sim ~= nil and (ns.Sim.rank ~= nil or ns.Sim.known ~= nil or ns.Sim.prof ~= nil))
    local prof, rank, maxRank = CurrentProfession()
    if not prof then
        panel:SetTitle(L.TITLE)
        summary:SetText(L.OPEN_PROF_FIRST)
        scrollBox:SetDataProvider(CreateTreeDataProvider())
        return
    end
    panel:SetTitle(ns.ProfName(prof))
    local text = (searchBox:GetText() or ""):lower()
    local onlyMissing = missingCheck:GetChecked()

    local dp = CreateTreeDataProvider()
    local cats, order = {}, {}
    local total, known = 0, 0
    for _, r in ipairs(ns.ByProf[prof] or {}) do
        local learned = IsLearned(r)
        total = total + 1
        if learned then known = known + 1 end
        if MatchesSearch(r, text) and not (onlyMissing and learned) then
            local cname = r.cat or ns.ProfName(prof)
            local c = cats[cname]
            if not c then
                c = { name = cname, items = {}, known = 0, total = 0 }
                cats[cname] = c
                order[#order + 1] = c
            end
            c.total = c.total + 1
            if learned then c.known = c.known + 1 end
            c.items[#c.items + 1] = { recipe = r, learned = learned, rank = rank }
        end
    end
    for _, c in ipairs(order) do
        local header = dp:Insert({ header = true, name = c.name, known = c.known, total = c.total })
        for _, item in ipairs(c.items) do header:Insert(item) end
        if collapsed[c.name] and text == "" then header:SetCollapsed(true) end
    end
    scrollBox:SetDataProvider(dp, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition)
    local rankText = rank and string.format("   %s: %d%s", L.YOUR_SKILL, rank, maxRank and maxRank > 0 and ("/" .. maxRank) or "") or ""
    summary:SetText(string.format("%d/%d %s%s", known, total, L.KNOWN, rankText))
end

---------------------------------------------------------------------------
-- Panel
---------------------------------------------------------------------------
local function CreatePanel()
    panel = CreateFrame("Frame", "ProfessionSentinelPanel", UIParent, "ButtonFrameTemplate")
    panel:SetWidth(PANEL_WIDTH)
    panel:SetHeight(560)
    panel:SetFrameStrata("HIGH")
    panel:SetClampedToScreen(true)
    if ButtonFrameTemplate_HidePortrait then ButtonFrameTemplate_HidePortrait(panel) end
    if ButtonFrameTemplate_HideButtonBar then ButtonFrameTemplate_HideButtonBar(panel) end
    panel:SetTitle(L.TITLE)
    panel:Hide()
    if panel.CloseButton then
        panel.CloseButton:SetScript("OnClick", function()
            panel:Hide()
            if currentHost then ns.db.panelOpen = false end
        end)
    end

    testBadge = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    testBadge:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -30, -6)
    testBadge:SetText("|cffff4040" .. L.TEST_ACTIVE .. "|r")
    testBadge:Hide()

    searchBox = CreateFrame("EditBox", nil, panel, "SearchBoxTemplate")
    searchBox:SetHeight(20)
    searchBox:SetPoint("TOPLEFT", panel, "TOPLEFT", 16, -30)
    searchBox:SetPoint("RIGHT", panel, "RIGHT", -140, 0)
    searchBox:SetAutoFocus(false)
    if searchBox.Instructions then searchBox.Instructions:SetText(L.SEARCH) end
    searchBox:HookScript("OnTextChanged", function() UI:Refresh() end)

    missingCheck = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    missingCheck:SetSize(22, 22)
    missingCheck:SetPoint("LEFT", searchBox, "RIGHT", 8, 0)
    local mlabel = missingCheck:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    mlabel:SetPoint("LEFT", missingCheck, "RIGHT", 2, 0)
    mlabel:SetText(L.F_MISSING)
    missingCheck:SetChecked(ns.db.filters.missing)
    missingCheck:SetScript("OnClick", function(self)
        ns.db.filters.missing = self:GetChecked() and true or false
        UI:Refresh()
    end)

    summary = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    summary:SetPoint("TOPLEFT", searchBox, "BOTTOMLEFT", -4, -6)
    summary:SetJustifyH("LEFT")

    local inset = panel.Inset or panel
    if panel.Inset then
        panel.Inset:ClearAllPoints()
        panel.Inset:SetPoint("TOPLEFT", panel, "TOPLEFT", 8, -76)
        panel.Inset:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -6, 22)
    end

    scrollBox = CreateFrame("Frame", nil, inset, "WowScrollBoxList")
    scrollBox:SetPoint("TOPLEFT", inset, "TOPLEFT", 4, -4)
    scrollBox:SetPoint("BOTTOMRIGHT", inset, "BOTTOMRIGHT", -20, 4)
    scrollBar = CreateFrame("EventFrame", nil, inset, "MinimalScrollBar")
    scrollBar:SetPoint("TOPLEFT", scrollBox, "TOPRIGHT", 4, 0)
    scrollBar:SetPoint("BOTTOMLEFT", scrollBox, "BOTTOMRIGHT", 4, 0)

    local view = CreateScrollBoxListTreeListView(0)
    view:SetElementExtent(ROW_HEIGHT)
    view:SetElementFactory(function(factory, node)
        -- different frame types = separate frame pools, so headers and recipe rows never share a frame
        if node:GetData().header then factory("CheckButton", InitHeader) else factory("Button", InitRow) end
    end)
    ScrollUtil.InitScrollBoxListWithScrollBar(scrollBox, scrollBar, view)

    infoText = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    infoText:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -10, 6)
    local qdate = (ns.DataMeta.questie or ""):match("%d%d%d%d%-%d%d%-%d%d") or "?"
    infoText:SetText(string.format(L.DATA_INFO, ns.FlavorName(), ns.DataMeta.build or "?", qdate))

    panel:SetScript("OnShow", function() UI:Refresh() end)
    panel:SetScript("OnHide", function() GameTooltip:Hide() end)
end

-- Dock the panel to a host frame (nil = free-floating in the screen centre, used by test mode)
function UI:AttachTo(host)
    if not panel then CreatePanel() end
    currentHost = host
    panel:ClearAllPoints()
    if host then
        panel:SetPoint("TOPLEFT", host, "TOPRIGHT", 2, 0)
        panel:SetHeight(math.max(host:GetHeight() or 560, 440))
        panel:SetMovable(false)
        panel:RegisterForDrag()
    else
        panel:SetPoint("CENTER", UIParent, "CENTER", 220, 0)
        panel:SetHeight(560)
        panel:SetMovable(true)
        panel:EnableMouse(true)
        panel:RegisterForDrag("LeftButton")
        panel:SetScript("OnDragStart", panel.StartMoving)
        panel:SetScript("OnDragStop", panel.StopMovingOrSizing)
    end
end

function UI:Show(host)
    self:AttachTo(host)
    panel:Show()
    self:Refresh()
end

function UI:Hide()
    if panel then panel:Hide() end
end

function UI:IsShown()
    return panel and panel:IsShown()
end

local function ActiveHost()
    if ns.IsForever then
        return ProfessionsFrame and ProfessionsFrame:IsShown() and ProfessionsFrame or nil
    end
    if CraftFrame and CraftFrame:IsShown() then return CraftFrame end
    if TradeSkillFrame and TradeSkillFrame:IsShown() then return TradeSkillFrame end
end

function UI:Toggle()
    local host = ActiveHost()
    if panel and panel:IsShown() then
        panel:Hide()
        if host then ns.db.panelOpen = false end
        return
    end
    if not host and not (ns.Sim and ns.Sim.prof) then
        ns.Print(L.OPEN_PROF_FIRST)
        return
    end
    if host then ns.db.panelOpen = true end
    self:Show(host)
end

---------------------------------------------------------------------------
-- Hosts: toggle button + show/hide with the profession window
---------------------------------------------------------------------------
local hostsDone = {}

local function SetupHost(host)
    if not host or hostsDone[host] then return end
    hostsDone[host] = true
    collapsed = ns.db.collapsed or {}
    ns.db.collapsed = collapsed
    local b = CreateFrame("Button", nil, host, "UIPanelButtonTemplate")
    b:SetSize(130, 22)
    b:SetPoint("TOPRIGHT", host, "BOTTOMRIGHT", -6, ns.IsForever and 0 or 70)
    b:SetText(L.ALL_RECIPES)
    b:SetScript("OnClick", function()
        if panel and panel:IsShown() and currentHost == host then
            panel:Hide(); ns.db.panelOpen = false
        else
            ns.db.panelOpen = true
            UI:Show(host)
        end
    end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("ProfessionSentinel", 0.25, 0.78, 0.92)
        GameTooltip:AddLine(L.SUBTITLE, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    host:HookScript("OnShow", function()
        if ns.db.panelOpen ~= false then UI:Show(host) end
    end)
    host:HookScript("OnHide", function()
        if currentHost == host and panel then panel:Hide() end
    end)
    if host:IsShown() and ns.db.panelOpen ~= false then UI:Show(host) end
end

local loader = CreateFrame("Frame")
loader:RegisterEvent("ADDON_LOADED")
loader:RegisterEvent("PLAYER_LOGIN")
loader:RegisterEvent("TRADE_SKILL_LIST_UPDATE")
loader:RegisterEvent("TRADE_SKILL_DATA_SOURCE_CHANGED")
loader:RegisterEvent("TRADE_SKILL_UPDATE")
loader:RegisterEvent("CRAFT_UPDATE")
loader:SetScript("OnEvent", function(_, event, name)
    if not ns.Flavor or not ns.db then return end
    collapsed = collapsed or ns.db.collapsed or {}
    if event == "ADDON_LOADED" then
        if name == "Blizzard_Professions" and ns.IsForever then SetupHost(ProfessionsFrame)
        elseif name == "Blizzard_TradeSkillUI" and ns.IsEra then SetupHost(TradeSkillFrame)
        elseif name == "Blizzard_CraftUI" and ns.IsEra then SetupHost(CraftFrame) end
    elseif event == "PLAYER_LOGIN" then
        if ns.IsForever and ProfessionsFrame then SetupHost(ProfessionsFrame) end
        if ns.IsEra and TradeSkillFrame then SetupHost(TradeSkillFrame) end
        if ns.IsEra and CraftFrame then SetupHost(CraftFrame) end
    elseif panel then
        UI:Refresh()
    end
end)
