if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.9 - Schnäppchen-Wächter (Logik)
--
-- Läuft neben dem Sniper, egal was du gerade snipen willst:
-- * durchsucht regelmäßig die Handwerkswaren-Kategorien (Kräuter, Erz,
--   Stoff, Leder, Verzauberungsmaterial, Elementar, Edelsteine,
--   Kochzutaten, optional Verbrauchbares) - KEINE Waffen/Rüstung
-- * alle gewählten Kategorien in EINER Suche; lehnt der Server das ab oder
--   kommt nichts zurück, wird automatisch Kategorie für Kategorie gesucht
-- * Treffer: Preis <= x % vom Marktwert (Median) und Marktwert >= Mindestwert
-- * jeder Treffer wird per Einzelsuche nachgeprüft - Lockangebote
--   (1 Stück ganz unten) zählen nicht
-- * bestätigte Schnäppchen werden vorübergehende Sniper-Ziele: kaufen mit
--   derselben Taste / demselben Mausrad wie beim Sniper (nur per Tastendruck)
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local W = {}
A.Watcher = W

local ROUND_TIMEOUT = 10        -- Sekunden, bis eine Runde als ergebnislos gilt
local MAX_PAGES = 10            -- höchstens so viele Ergebnisseiten pro Runde
local MAX_NEW = 5               -- höchstens so viele neue Kandidaten pro Runde
local TARGET_LIFE = 120         -- so lange (Sek.) bleibt ein Schnäppchen kaufbar, dann neu prüfen
local REJECT_TIME = 600         -- abgelehnter Preis (Lockangebot/weg) wird so lange ignoriert
local LIST_TIME = 300           -- erledigte Einträge bleiben so lange in der Liste
local MIN_GAP = 0               -- keine eigene Pause: so oft, wie der Server erlaubt (Tempo regelt A:CanQueryNow)
local USER_GRACE = 6            -- nach eigener Suche im Einkauf so lange Vorrang für dich
local SORTS = { { sortOrder = 0, reverseSort = false } }

local CLASS = (Enum and Enum.ItemClass) or {}
local TRADE = CLASS.Tradegoods or 7
local GEM = CLASS.Gem or 3
local CONSUMABLE = CLASS.Consumable or 0

-- Kategorien: Liste von { classID, subClassID } (subClassID nil = ganze Klasse)
W.CATS = {
    { key = "herb",       label = "Kräuter",               filters = { { TRADE, 9 } } },
    { key = "metal",      label = "Metall & Stein",        filters = { { TRADE, 7 } } },
    { key = "cloth",      label = "Stoff",                 filters = { { TRADE, 5 } } },
    { key = "leather",    label = "Leder",                 filters = { { TRADE, 6 } } },
    { key = "enchanting", label = "Verzauberungsmaterial", filters = { { TRADE, 12 } } },
    { key = "elemental",  label = "Elementar",             filters = { { TRADE, 10 } } },
    { key = "gems",       label = "Edelsteine",            filters = { { GEM }, { TRADE, 4 } } },
    { key = "cooking",    label = "Kochzutaten",           filters = { { TRADE, 8 } } },
    { key = "consumable", label = "Verbrauchbares",        filters = { { CONSUMABLE } } },
}

W.THRESHOLDS = { 30, 40, 50, 60, 70 }

W.round = nil           -- laufende Runde
W.lastRound = -100
W.catPos = 0            -- Einzel-Modus: zuletzt gesuchte Kategorie
W.emptyRounds = 0
W.opps = {}             -- [itemID] = Eintrag der Liste
W.rejected = {}         -- [itemID] = { price, time }
W.stats = { rounds = 0, results = 0, candidates = 0, verified = 0, bait = 0, gone = 0 }

local function DB() return A.db and A.db.watcher end
local function Now() return GetTime() end

local function SafeCall(fn, ...)
    if not fn then return nil end
    local ok, a = pcall(fn, ...)
    if ok then return a end
    return nil
end

-- ------------------------------------------------------------
-- Einstellungen
-- ------------------------------------------------------------
function W:IsEnabled()
    local db = DB()
    return db and db.enabled and true or false
end

function W:SetEnabled(on)
    local db = DB()
    if not db then return end
    db.enabled = on and true or false
    if not db.enabled then
        self:Abort()
        self:ClearTargets()
    else
        self.lastRound = -100
    end
    A:Fire("WATCHER_CHANGED")
end

function W:Toggle()
    self:SetEnabled(not self:IsEnabled())
    A:Print(L["Schnäppchen-Wächter "] .. (self:IsEnabled() and L["|cff33dd55AN|r"] or L["|cffff5544AUS|r"]))
end

function W:SetThreshold(pct)
    local db = DB()
    db.threshold = math.max(5, math.min(95, math.floor(pct or 50)))
    A:Fire("WATCHER_CHANGED")
end

function W:SetMinValue(copper)
    local db = DB()
    db.minValue = math.max(1, math.floor(copper or 10))
    A:Fire("WATCHER_CHANGED")
end

function W:SetBudget(copper)
    local db = DB()
    if copper and copper > 0 then db.budget = math.floor(copper) end
    A:Fire("WATCHER_CHANGED")
end

function W:ToggleCategory(key)
    local db = DB()
    db.cats[key] = not db.cats[key]
    A:Fire("WATCHER_CHANGED")
    return db.cats[key]
end

function W:CategoryLabel(key)
    for _, c in ipairs(self.CATS) do if c.key == key then return L[c.label] end end
    return key
end

function W:ActiveCategories()
    local db = DB()
    local out = {}
    for _, c in ipairs(self.CATS) do
        if db and db.cats[c.key] then table.insert(out, c) end
    end
    return out
end

function W:ModeLabel()
    local db = DB()
    return (db and db.mode == "single") and L["einzeln"] or L["alle zusammen"]
end

-- ------------------------------------------------------------
-- Runde: eine Suche über die Kategorien
-- ------------------------------------------------------------
function W:IsBusy()
    return self.round ~= nil
end

function W:Abort()
    self.round = nil
end

local function BuildClassFilters(cats)
    local out = {}
    for _, c in ipairs(cats) do
        for _, f in ipairs(c.filters) do
            table.insert(out, { classID = f[1], subClassID = f[2] })
        end
    end
    return out
end

function W:WhyWaiting()
    if not self:IsEnabled() then return L["aus"] end
    if not A:IsAHOpen() then return L["wartet auf das Auktionshaus"] end
    if A:IsScanning() then return L["wartet, bis der Markt-Scan fertig ist"] end
    if #self:ActiveCategories() == 0 then return L["keine Kategorie gewählt"] end
    local Sn = A.Sniper
    if Sn and (Sn:IsBusy() or (Sn.pending and not Sn.pending.auto)) then return L["wartet auf den Sniper"] end
    if A.Seller and (A.Seller.HasWork and A.Seller:HasWork() or A.Seller:IsBusy()) then return L["wartet auf die Preisprüfung"] end
    if A.Buy and A.Buy:Blocks() then return L["wartet auf den Einkauf"] end
    if self:HoldingForScan() then return L["Komplett-Scan hat Vorrang"] end
    return nil
end

-- Pause nach einer Runde: so kurz wie möglich (alter fester Wert 20 Sek. gilt nicht mehr)
function W:Gap()
    local db = DB()
    if db.interval == 20 then db.interval = nil end
    return math.max(MIN_GAP, db.interval or 0)
end

-- Möchte der Wächter jetzt suchen? (ohne Rücksicht auf den Sniper - fürs Abwechseln)
function W:WantsTurn()
    if self.round or self:WhyWaiting() then return false end
    if A.AH_LEGACY and A.Sniper and A.Sniper.HitWaiting and A.Sniper:HitWaiting() then return false end
    if Now() - self.lastRound < self:Gap() then return false end
    local B = A.Buy
    if B and B.lastUse and Now() - B.lastUse < USER_GRACE then return false end
    return true
end

-- Wer ist gerade vor dem Wächter dran? (nil = niemand, der Wächter darf suchen)
-- Wollen beide suchen, wechseln sie sich ab: Sniper, Wächter, Sniper, ...
function W:YieldReason()
    local Sn = A.Sniper
    -- altes AH: ein wartender Treffer muss in der Liste bleiben, sonst lässt er sich nicht kaufen
    if A.AH_LEGACY and Sn and Sn.HitWaiting and Sn:HitWaiting() then return L["Treffer wartet auf deinen Kauf"] end
    if Sn and Sn.WantsTurn and Sn:WantsTurn() and (Sn.lastSearch or -100) <= self.lastRound then return L["Sniper ist dran"] end
    local B = A.Buy
    if B and B.lastUse and Now() - B.lastUse < USER_GRACE then return L["Vorrang für deine Suche"] end
    return nil
end

function W:CanStartRound()
    if self.round or self:WhyWaiting() then return false end
    if Now() - self.lastRound < self:Gap() then return false end
    if self:YieldReason() then return false end
    return A:CanQueryNow()
end

function W:StartRound()
    local db = DB()
    local cats = self:ActiveCategories()
    if #cats == 0 then return false end
    local used
    if db.mode == "single" then
        self.catPos = (self.catPos % #cats) + 1
        used = { cats[self.catPos] }
    else
        used = cats
    end
    local query = {
        searchString = "",
        sorts = SORTS,
        filters = {},
        itemClassFilters = BuildClassFilters(used),
        minLevel = 0,
        maxLevel = 0,
    }
    local ok, err = pcall(A.AH.SendBrowseQuery, query)
    A:NoteQuery()
    self.lastRound = Now()
    if not ok then
        A:QueryError()
        self.lastError = tostring(err)
        if db.mode ~= "single" then
            db.mode = "single"
            A:Print(L["Wächter: kombinierte Suche abgelehnt - sucht jetzt Kategorie für Kategorie."])
        end
        A:Fire("WATCHER_CHANGED")
        return false
    end
    self.round = { started = Now(), lastCount = -1, lastChange = Now(), pages = 0, waitingMore = false, cats = used, mode = db.mode }
    A:Fire("WATCHER_CHANGED")
    return true
end

function W:PollRound()
    local r = self.round
    if not r then return end
    if not A:IsAHOpen() or A:IsScanning() then self.round = nil; return end
    local C = A.AH
    local results = SafeCall(C.GetBrowseResults) or {}
    local count = #results
    local now = Now()
    -- altes AH: Fortschritt an den erhaltenen Seiten messen (neue Seite = oft keine neuen Items)
    local gotPages
    if C.GetBrowseProgress then gotPages = C.GetBrowseProgress() end
    local sig = gotPages and (count .. ":" .. gotPages) or count
    if sig ~= r.lastCount then r.lastCount, r.lastChange, r.waitingMore = sig, now, false end
    local full = SafeCall(C.HasFullBrowseResults)

    -- weitere Seiten
    if count > 0 and full == false and not r.waitingMore and r.pages < MAX_PAGES and A:QueryReady() and C.RequestMoreBrowseResults then
        if pcall(C.RequestMoreBrowseResults) then
            r.pages, r.waitingMore = r.pages + 1, true
            return
        end
    end

    local timedOut = now - r.started > ROUND_TIMEOUT
    local done
    if A.AH_LEGACY then
        -- altes AH: zwischen den Seiten sperrt der Server einige Sekunden - nicht vorzeitig aufhören
        -- (sonst sieht der Wächter nur die erste Seite = die seltensten, meist teuersten Items)
        done = (count > 0 and (full == true or r.pages >= MAX_PAGES))
            or (count > 0 and now - r.lastChange >= 15)
            or (count == 0 and r.answered and now - r.lastChange >= 0.5)
            or (count == 0 and timedOut)
    else
        done = (count > 0 and (full == true or r.pages >= MAX_PAGES or (not r.waitingMore and now - r.lastChange >= 1)))
            or (count > 0 and r.waitingMore and now - r.lastChange >= 3)
            or (count == 0 and r.answered and now - r.lastChange >= 0.5)
            or timedOut
    end
    if not done then return end
    self.round = nil
    self.lastRound = Now()          -- Pause zählt ab dem Ende der Runde
    self:CheckScanAllowance()
    self:FinishRound(results, r)
end

-- Der Server erlaubt einen Komplett-Scan nur alle 15 Minuten.
-- Altes AH (Classic Era, TBC): Weg wie bis 0.64.2 - keine Pause. Dort kann "kein Komplett-Scan" auch von
-- einem anderen Addon kommen, die seitenweise Suche des Wächters läuft trotzdem.
-- Moderne API (WoW Forever, Retail): Ist der Komplett-Scan fällig und verwirft der Server Anfragen
-- (AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED), pausiert der Wächter, bis der Scan gelaufen ist
-- (höchstens 15 Min.), damit der Scan Vorrang hat.
W.DROP_WINDOW = 60      -- so lange (Sek.) zählt ein verworfener Auftrag als "Server ist am Limit"

local function ScanDueModern()
    if A.AH_LEGACY then return false end
    if not (A.IsScanReady and A:IsScanReady()) then return false end
    if A.IsScanning and A:IsScanning() then return false end
    return true
end

-- maxSeconds: höchstens so lange pausieren (Standard 15 Min.; beim Scan-Wunsch 2 Min.)
function W:HoldForScan(maxSeconds)
    local h = self.holdForScan
    if h then
        if maxSeconds and h.max and maxSeconds > h.max - (time() - h.since) then h.since, h.max = time(), maxSeconds end
        return
    end
    self.holdForScan = { since = time(), lastScan = A.db and A.db.lastScanTime or 0, max = maxSeconds }
    self.stats.scanHolds = (self.stats.scanHolds or 0) + 1
end

function W:CheckScanAllowance()
    if not ScanDueModern() then return end
    local drop = A.lastThrottleDrop
    if drop and GetTime() - drop < self.DROP_WINDOW then self:HoldForScan() end
end

-- vom Kern bei AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED aufgerufen
function W:OnThrottleDrop()
    if ScanDueModern() then self:HoldForScan() end
end

function W:HoldingForScan()
    local h = self.holdForScan
    if not h then return false end
    if (A.db and A.db.lastScanTime or 0) ~= h.lastScan or time() - h.since > (h.max or A.SCAN_COOLDOWN or 900) then
        self.holdForScan = nil
        return false
    end
    return true
end

function W:FinishRound(results, r)
    local db = DB()
    self.stats.rounds = self.stats.rounds + 1
    self.stats.results = self.stats.results + #results
    self.lastResults = #results

    -- nichts zurück: Server kann die kombinierte Suche evtl. nicht -> einzeln
    if #results == 0 then
        self.emptyRounds = self.emptyRounds + 1
        if r.mode ~= "single" and self.emptyRounds >= 2 and #r.cats > 1 then
            db.mode = "single"
            self.emptyRounds = 0
            A:Print(L["Wächter: kombinierte Suche liefert nichts - sucht jetzt Kategorie für Kategorie."])
        end
        A:Fire("WATCHER_CHANGED")
        return
    end
    self.emptyRounds = 0

    local Sn = A.Sniper
    local now = time()
    local ratio = (db.threshold or 50) / 100
    local found = {}
    for _, res in ipairs(results) do
        local key = res.itemKey
        local itemID = (type(key) == "table" and key.itemID) or res.itemID
        local price = res.minPrice
        if itemID and price and price > 0 and A:IsCommodityItem(itemID) then
            local mv = A:GetMarketValue(itemID)
            -- nur bei belastbarem Marktwert: bei Mondpreisen/seltenen Items/Preissturz wirkt sonst
            -- fast alles wie ein Schnäppchen (im Test z. B. "0 % vom Marktwert")
            local reliable = not A.IsReliable or A:IsReliable(itemID)
            if mv and reliable and mv >= (db.minValue or 10) and price <= mv * ratio then
                local rej = self.rejected[itemID]
                local skip = rej and rej.price == price and now - rej.time < REJECT_TIME
                if not skip and Sn and not Sn.extra["w:" .. itemID] then
                    table.insert(found, { itemID = itemID, price = price, market = mv, pct = price / mv * 100 })
                end
            end
        end
    end
    table.sort(found, function(x, y) return x.pct < y.pct end)
    for k = 1, math.min(MAX_NEW, #found) do
        self:AddCandidate(found[k])
    end
    A:Fire("WATCHER_CHANGED")
end

-- Kandidat -> vorübergehendes Sniper-Ziel, wird sofort per Einzelsuche geprüft
function W:AddCandidate(c)
    local db = DB()
    local Sn = A.Sniper
    self.stats.candidates = self.stats.candidates + 1
    local maxPrice = math.max(1, math.floor(c.market * (db.threshold or 50) / 100))
    local t = {
        kind = "item", itemID = c.itemID, key = "w:" .. c.itemID, watch = true,
        maxPrice = maxPrice, qty = 100000, budget = db.budget or 500000,
        bought = 0, spent = 0, qMin = 0, qMax = 4,
        added = time(), created = Now(), market = c.market, browsePrice = c.price,
    }
    Sn:AddExtraTarget(t)
    self.opps[c.itemID] = {
        itemID = c.itemID, name = A:GetItemName(c.itemID), key = t.key,
        price = c.price, market = c.market, pct = c.pct, maxPrice = maxPrice,
        status = "prüft", time = time(), created = Now(),
    }
end

-- Ergebnis der Einzelsuche (vom Sniper)
function W:OnVerified(t, plan, result)
    local o = self.opps[t.itemID]
    if not o then
        o = { itemID = t.itemID, name = A:GetItemName(t.itemID), key = t.key, market = t.market, maxPrice = t.maxPrice, time = time(), created = Now() }
        self.opps[t.itemID] = o
    end
    o.checked = Now()
    if plan then
        -- echtes Schnäppchen: günstigstes echtes Angebot
        local first
        for _, l in ipairs(result and result.listings or {}) do
            if not l.bait and not l.own then first = l; break end
        end
        o.status = "kaufbar"
        o.price = first and first.price or o.price
        o.pct = (o.price and o.market and o.market > 0) and (o.price / o.market * 100) or o.pct
        o.qty = plan.qty - (plan.bait or 0)
        o.total = plan.total
        o.bait = plan.bait
        if not o.announced then
            o.announced = true
            self.stats.verified = self.stats.verified + 1
            local db = DB()
            db.found = (db.found or 0) + 1
            A:Print(string.format(L["|cff33dd55Schnäppchen:|r %dx %s für je %s (%d %% vom Marktwert) - %s zum Kaufen"],
                o.qty, o.name, A:FormatMoney(o.price), math.floor((o.pct or 0) + 0.5), A.Sniper:GetBindsText("watcher")))
            if A.db.settings.alertSound and PlaySound then pcall(PlaySound, 8959) end
        end
    else
        -- kein echtes Angebot unter der Grenze: Lockangebot oder schon weg
        local bait = false
        for _, l in ipairs(result and result.listings or {}) do
            if l.bait and l.price <= t.maxPrice then bait = true end
        end
        o.status = bait and "Lockangebot" or "weg"
        if bait then self.stats.bait = self.stats.bait + 1 else self.stats.gone = self.stats.gone + 1 end
        self.rejected[t.itemID] = { price = t.browsePrice or o.price, time = time() }
        o.doneAt = Now()
        A.Sniper:RemoveExtraTarget(t.key)
    end
    A:Fire("WATCHER_CHANGED")
end

-- gekauft: ein Kauf nimmt alles Passende (bis zum Budget) - das Schnäppchen ist damit erledigt.
-- Kommt neue Ware nach, findet die nächste Runde sie wieder.
function W:OnBought(t)
    local o = self.opps[t.itemID]
    if o then
        o.boughtQty = t.bought
        o.spent = t.spent
        o.status = "gekauft"
        o.doneAt = Now()
    end
    if A.Sniper.extra[t.key] then A.Sniper:RemoveExtraTarget(t.key) end
    A:Fire("WATCHER_CHANGED")
end

-- Ziele des Wächters entfernen
function W:ClearTargets()
    local Sn = A.Sniper
    if not Sn then return end
    local keys = {}
    for key, t in pairs(Sn.extra) do if t.watch then table.insert(keys, key) end end
    for _, key in ipairs(keys) do Sn:RemoveExtraTarget(key) end
end

-- abgelaufene Schnäppchen aufräumen
function W:Cleanup()
    local Sn = A.Sniper
    local now = Now()
    local changed = false
    for key, t in pairs(Sn.extra) do
        if t.watch and now - (t.created or now) > TARGET_LIFE then
            local waiting = Sn.result and Sn.result.key == key and Sn:IsResultFresh() and Sn:PlanNext()
            local buying = Sn.pending and Sn.pending.key == key
            if not waiting and not buying then
                Sn:RemoveExtraTarget(key)
                local o = self.opps[t.itemID]
                if o and o.status ~= "gekauft" then
                    o.status = (t.bought or 0) > 0 and "gekauft" or "abgelaufen"
                    o.doneAt = now
                end
                changed = true
            end
        end
    end
    for id, o in pairs(self.opps) do
        if o.doneAt and now - o.doneAt > LIST_TIME then self.opps[id] = nil; changed = true end
    end
    if changed then A:Fire("WATCHER_CHANGED") end
end

-- Liste für die Anzeige (neueste zuerst)
function W:GetOpportunities()
    local out = {}
    for _, o in pairs(self.opps) do table.insert(out, o) end
    table.sort(out, function(x, y)
        local ax = (x.status == "kaufbar") and 0 or (x.status == "prüft" and 1 or 2)
        local ay = (y.status == "kaufbar") and 0 or (y.status == "prüft" and 1 or 2)
        if ax ~= ay then return ax < ay end
        return (x.created or 0) > (y.created or 0)
    end)
    return out
end

-- Eintrag anklicken: Ergebnis zeigen bzw. sofort nachprüfen
function W:Select(o)
    local Sn = A.Sniper
    if not (o and Sn.extra[o.key]) then return false, L["Schnäppchen ist nicht mehr aktiv."] end
    if Sn.result and Sn.result.key == o.key and Sn:IsResultFresh() then return true, nil end
    return Sn:Search(o.key)
end

function W:GetStatusText()
    local wait = self:WhyWaiting()
    if not self:IsEnabled() then return L["|cffff5544Wächter AUS|r"] end
    if wait then return "|cffffcc33" .. L["Wächter AN"] .. " - " .. wait .. "|r" end
    if self.round then return L["|cffffcc33Wächter sucht ...|r"] end
    local left = math.max(0, self:Gap() - (Now() - self.lastRound))
    if left <= 0 then
        local why = self:YieldReason()
        if why then return L["|cff33dd55Wächter AN|r"] .. " - " .. why end
        return L["|cff33dd55Wächter AN|r"] .. " - " .. L["nächste Runde, sobald der Server frei ist"]
    end
    return string.format(L["|cff33dd55Wächter AN|r - nächste Runde in %d Sek."], math.ceil(left))
end

function W:GetDebugText()
    local db = DB()
    if not db then return "-" end
    local s = self.stats
    return string.format(L["%s, Modus=%s, Kategorien=%d, Schwelle=%d %%, Runden=%d, Ergebnisse=%d, Kandidaten=%d, bestätigt=%d, Lockangebote=%d, weg=%d"],
        db.enabled and L["an"] or L["aus"], self:ModeLabel(), #self:ActiveCategories(), db.threshold or 50,
        s.rounds, s.results, s.candidates, s.verified, s.bait, s.gone)
        .. ((s.scanHolds or 0) > 0 and string.format(L[", für den Komplett-Scan pausiert: %d"], s.scanHolds) or "")
end

-- ------------------------------------------------------------
-- Takt und Ereignisse
-- ------------------------------------------------------------
function W:Tick()
    if not A.db then return end
    if self.round then self:PollRound(); return end
    if self:CanStartRound() then self:StartRound() end
end

A:On("BROWSE_RESULTS", function()
    if W.round then W.round.answered = true; W:PollRound() end
end)
A:On("QUERY_READY", function()
    if W.round then W:PollRound() end
end)
A:On("SCAN_STARTED", function() W:Abort() end)
A:On("AH_STATE", function()
    if not A:IsAHOpen() then
        W.round = nil
        for _, o in pairs(W.opps) do
            if o.status == "prüft" or o.status == "kaufbar" then o.status = "abgelaufen"; o.doneAt = Now() end
        end
    else
        W.lastRound = Now() - 15      -- erste Runde kurz nach dem Öffnen
    end
    A:Fire("WATCHER_CHANGED")
end)

local ticker = CreateFrame("Frame")
local acc, cleanAcc = 0, 0
ticker:SetScript("OnUpdate", function(_, dt)
    acc = acc + (dt or 0)
    cleanAcc = cleanAcc + (dt or 0)
    if acc >= 0.1 then
        acc = 0
        W:Tick()
    end
    if cleanAcc >= 1 then
        cleanAcc = 0
        if A.Sniper then W:Cleanup() end
    end
end)
