if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.7 - Briefkasten: Post abholen
--
-- Am Briefkasten erscheinen zwei Knöpfe:
--   "AH-Post abholen" - Gold und Items aus Auktionspost (verkauft,
--                        gekauft, abgelaufen, abgebrochen, überboten)
--   "Alles"           - jede Post (außer Nachnahme)
-- Vorher werden alle Rechnungen für die Buchhaltung gelesen.
-- Abgeholt wird eins nach dem anderen (der Server braucht kurz),
-- bei vollen Taschen wird angehalten. Nachnahme (COD) wird nie bezahlt.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

-- Briefkasten über A.Inbox (im Testmodus: Test-Briefkasten mit fiktiver Post)
local function GetInboxNumItems(...) return A.Inbox.GetInboxNumItems(...) end
local function GetInboxHeaderInfo(...) return A.Inbox.GetInboxHeaderInfo(...) end
local function GetInboxInvoiceInfo(...) return A.Inbox.GetInboxInvoiceInfo(...) end
local function GetInboxItem(...) return A.Inbox.GetInboxItem(...) end
local function GetInboxItemLink(...) return A.Inbox.GetInboxItemLink(...) end
local function TakeInboxMoney(...) return A.Inbox.TakeInboxMoney(...) end
local function TakeInboxItem(...) return A.Inbox.TakeInboxItem(...) end

local M = {}
A.Mailer = M

local STEP = 0.35          -- Sekunden zwischen zwei Aktionen
local WAIT_MAX = 3         -- so lange auf die Antwort des Servers warten

M.running = false

-- Betreff-Muster der Auktionspost aus Blizzards eigenen Texten (jede Sprache)
local function SubjectPatterns()
    local out = {}
    for _, g in ipairs({ "AUCTION_SOLD_MAIL_SUBJECT", "AUCTION_WON_MAIL_SUBJECT", "AUCTION_EXPIRED_MAIL_SUBJECT",
                         "AUCTION_REMOVED_MAIL_SUBJECT", "AUCTION_OUTBID_MAIL_SUBJECT" }) do
        local fmt = _G[g]
        if type(fmt) == "string" and fmt ~= "" then
            local esc = fmt:gsub("([%(%)%.%+%-%*%?%[%]%^%$])", "%%%1")
            esc = esc:gsub("%%s", ".+")
            esc = esc:gsub("%%d", "%%d+")
            local pat = "^" .. esc
            table.insert(out, pat)
        end
    end
    return out
end

-- Post mit zurückgekommener Ware (abgelaufen oder abgebrochen)?
function M:IsReturnMail(i)
    if not self.returnPatterns then
        self.returnPatterns = {}
        for _, g in ipairs({ "AUCTION_EXPIRED_MAIL_SUBJECT", "AUCTION_REMOVED_MAIL_SUBJECT" }) do
            local fmt = _G[g]
            if type(fmt) == "string" and fmt ~= "" then
                local esc = fmt:gsub("([%(%)%.%+%-%*%?%[%]%^%$])", "%%%1")
                esc = esc:gsub("%%s", ".+")
                table.insert(self.returnPatterns, "^" .. esc)
            end
        end
    end
    local ok, _, _, _, subject = pcall(GetInboxHeaderInfo, i)
    if not (ok and type(subject) == "string") then return false end
    for _, pat in ipairs(self.returnPatterns) do
        if subject:find(pat) then return true end
    end
    return false
end

function M:IsAuctionMail(i)
    local okI, invoiceType = pcall(GetInboxInvoiceInfo, i)
    if okI and invoiceType then return true end
    local ok, _, _, sender, subject = pcall(GetInboxHeaderInfo, i)
    if not ok then return false end
    for _, pat in ipairs(self.patterns or {}) do
        if type(subject) == "string" and subject:find(pat) then return true end
    end
    return false
end

local function FreeSlots()
    local n = 0
    for bag = 0, (NUM_BAG_SLOTS or 4) + (NUM_REAGENTBAG_SLOTS or 0) do   -- Retail: auch die Reagenzientasche
        if C_Container and C_Container.GetContainerNumFreeSlots then
            n = n + (select(1, C_Container.GetContainerNumFreeSlots(bag)) or 0)
        elseif GetContainerNumFreeSlots then
            n = n + (select(1, GetContainerNumFreeSlots(bag)) or 0)
        end
    end
    return n
end

local function FirstAttachment(i)
    if not GetInboxItem then return nil end
    for a = 1, (ATTACHMENTS_MAX_RECEIVE or 16) do
        local ok, name, itemID = pcall(GetInboxItem, i, a)
        if ok and (name or itemID) then return a, itemID end
    end
    return nil
end

-- nächste Post mit etwas zum Abholen
function M:NextMail()
    local n = GetInboxNumItems and GetInboxNumItems() or 0
    for i = 1, n do
        local ok, _, _, sender, subject, money, cod, _, itemCount = pcall(GetInboxHeaderInfo, i)
        if ok and (not cod or cod == 0) and ((money or 0) > 0 or (itemCount or 0) > 0) then
            if not self.onlyAH or self:IsAuctionMail(i) then
                return i, money or 0, itemCount or 0
            end
        end
    end
    return nil
end

function M:Start(onlyAH)
    if self.running then return false, L["Läuft schon ..."] end
    if not A.Inbox.Available() then return false, L["Dein Client unterstützt das Abholen der Post nicht."] end
    self.patterns = SubjectPatterns()
    self.onlyAH = onlyAH and true or false
    -- erst die Rechnungen buchen, bevor die Post verschwindet
    if A.Ledger then pcall(A.Ledger.ScanInbox, A.Ledger) end
    -- nichts da: gleich sagen (sonst sieht man nicht, dass der Klick angekommen ist)
    if not self:NextMail() then
        local msg = onlyAH and L["Keine Auktionspost zum Abholen."] or L["Nichts zum Abholen."]
        A:ScreenMessage(msg, 0.8, 0.8, 0.8)
        return true, msg
    end
    self.running = true
    self.money, self.items, self.mails = 0, 0, 0
    self.waiting, self.lastAction = nil, 0
    self.startMoney = GetMoney and GetMoney() or 0
    A:Fire("MAILER_CHANGED")
    return true, onlyAH and L["Hole Auktionspost ab ..."] or L["Hole alle Post ab ..."]
end

-- Liegt Auktionspost im Briefkasten?
function M:HasAHMail()
    if not A.Inbox.Available() then return false end
    local pats = SubjectPatterns()
    local n = GetInboxNumItems() or 0
    for i = 1, n do
        local ok, _, _, _, subject, money, cod, _, itemCount = pcall(GetInboxHeaderInfo, i)
        if ok and type(subject) == "string" and (cod or 0) == 0 and ((money or 0) > 0 or (itemCount or 0) > 0) then
            for _, pat in ipairs(pats) do
                if subject:find(pat) then return true end
            end
        end
    end
    return false
end

-- automatisch abholen, sobald der Briefkasten offen ist (Shift beim Öffnen = nicht abholen)
function M:AutoEnabled()
    return not (A.db and A.db.settings.autoCollect == false)
end

function M:TryAuto()
    if not self.autoPending then return end
    self.autoPending = nil
    if self.running or not self:AutoEnabled() then return end
    if IsShiftKeyDown and IsShiftKeyDown() then return end
    if self:HasAHMail() then
        local ok, msg = self:Start(true)
        if ok and msg then A:Print(msg) end
    end
end

function M:Stop(reason)
    if not self.running then return end
    self.running = false
    local gained = (GetMoney and GetMoney() or 0) - (self.startMoney or 0)
    -- Testmodus: Gold aus dem Test-Briefkasten ist nur gezählt, nicht wirklich da
    if A.TestMode and A.TestMode.active then gained = gained + A.TestMode:TakeMailMoneyCount() end
    local msg = string.format(L["Post abgeholt: %s, %d Items"], A:FormatMoney(math.max(0, gained)), self.items)
    if reason then msg = msg .. " - " .. reason end
    A:Print(msg)
    A:ScreenMessage(msg, 0.2, 0.87, 0.33)
    A:Fire("MAILER_CHANGED")
end

function M:Step()
    if not self.running then return end
    if not (MailFrame and MailFrame.IsShown and MailFrame:IsShown()) then return self:Stop(L["Briefkasten geschlossen"]) end
    local now = GetTime()
    if self.waiting and now - self.lastAction < WAIT_MAX then return end
    -- Testmodus: langsamer, damit man "Anhalten" sieht und ausprobieren kann
    local step = (A.TestMode and A.TestMode.active) and 0.8 or STEP
    if now - self.lastAction < step then return end
    self.waiting = nil
    local i, money, itemCount = self:NextMail()
    if not i then return self:Stop() end
    if money > 0 then
        pcall(TakeInboxMoney, i)
    else
        if FreeSlots() == 0 then return self:Stop(L["|cffff5544Taschen voll|r"]) end
        local a = FirstAttachment(i)
        if not a then
            -- Anzahl gemeldet, aber kein Anhang lesbar: Post überspringen
            self.skip = (self.skip or 0) + 1
            if self.skip > 5 then return self:Stop() end
            return
        end
        -- abgelaufene / abgebrochene Auktion? -> zum Neu-Einstellen merken
        if A.Extras and self:IsReturnMail(i) then
            local okI, _, itemID, _, count = pcall(GetInboxItem, i, a)
            if not (okI and itemID) and GetInboxItemLink then
                local link = GetInboxItemLink(i, a)
                itemID = link and tonumber(link:match("item:(%d+)"))
            end
            if itemID then A.Extras:NoteReturned(itemID, okI and count or 1) end
        end
        pcall(TakeInboxItem, i, a)
        self.items = self.items + 1
    end
    self.waiting = true
    self.lastAction = now
end

local evt = CreateFrame("Frame")
for _, e in ipairs({ "MAIL_SHOW", "MAIL_CLOSED", "MAIL_INBOX_UPDATE", "UI_ERROR_MESSAGE" }) do pcall(evt.RegisterEvent, evt, e) end
evt:SetScript("OnEvent", function(_, event, a1, a2)
    if event == "MAIL_SHOW" then
        M:EnsureButtons()
        M.autoPending = true
        if C_Timer and C_Timer.After then C_Timer.After(1.5, function() M:TryAuto() end) end
    elseif event == "MAIL_CLOSED" then
        if M.running then M:Stop(L["Briefkasten geschlossen"]) end
    elseif event == "MAIL_INBOX_UPDATE" then
        M.waiting = nil      -- Server hat geantwortet
        if M.autoPending then M:TryAuto() end
    elseif event == "UI_ERROR_MESSAGE" and M.running then
        local msg = tostring(a2 or a1 or "")
        if ERR_INV_FULL and msg == ERR_INV_FULL or msg:lower():find("voll") or msg:lower():find("full") then
            M:Stop(L["|cffff5544Taschen voll|r"])
        end
    end
end)
local acc = 0
evt:SetScript("OnUpdate", function(_, dt)
    acc = acc + (dt or 0)
    if acc < 0.1 then return end
    acc = 0
    if M.running then M:Step() end
end)

-- Knöpfe am Briefkasten
function M:EnsureButtons()
    if self.buttons or not (A.db and A.db.settings.mailButtons ~= false) then
        if self.buttons then self.buttons:Show() end
        return
    end
    local parent = (type(InboxFrame) == "table" and InboxFrame) or (type(MailFrame) == "table" and MailFrame)
    if not parent then return end
    local frame = (type(MailFrame) == "table" and MailFrame) or parent
    local UI = A.UI
    local C = UI.C
    -- Eigene Leiste RECHTS NEBEN dem Briefkasten (nicht darüber): nichts überlappt den Rahmen,
    -- das Porträt oder Blizzards eigene Knöpfe. Untereinander, gleich breit.
    local W, BH, GAP = 150, 24, 6
    local f = CreateFrame("Frame", "AHAnalyzerProMailButtons", parent)
    f:SetPoint("TOPLEFT", frame, "TOPRIGHT", 4, -24)
    f:SetFrameLevel((parent.GetFrameLevel and parent:GetFrameLevel() or 1) + 10)
    if f.EnableMouse then f:EnableMouse(true) end
    UI:Box(f, C.bg, C.frameEdge, UI:IsClassic() and 2 or 1)
    f.title = UI:Label(f, "AHSentinel", "GameFontNormal", C.accent)
    f.title:SetPoint("TOP", 0, -8)
    local function place() end   -- Anordnung macht f:UpdateState()
    f.ah = UI:Button(f, L["AH-Post abholen"], W, BH, function()
        local ok, msg = M:Start(true)
        if msg then A:Print(msg) end
    end, "primary")
    place(f.ah)
    f.ah.tooltip = L["Holt Gold und Items aus der Auktionspost ab (nacheinander).\nRechnungen werden vorher für die Buchhaltung gelesen."]
    -- "Alles abholen" nur, wenn WoW keinen eigenen Knopf dafür hat ("Alle öffnen" unten im Briefkasten)
    f.all = UI:Button(f, L["Alles abholen"], W, BH, function()
        local ok, msg = M:Start(false)
        if msg then A:Print(msg) end
    end)
    f.all.tooltip = L["Holt jede Post ab (Nachnahme wird nie bezahlt)"]
    place(f.all)
    f.alts = UI:Button(f, L["An Twinks"], W, BH, function(btn, button)
        if button == "RightButton" or not next(A.Extras.RulesDB()) then
            if button ~= "RightButton" then
                A:Print(L["Post an Twinks: noch keine Regel - nichts verschickt. Hier die Regeln festlegen."])
            end
            UI:ShowMailRules()
            return
        end
        local ok, msg = A.Extras:MailStep()
        if msg then A:Print(msg) end
    end)
    if f.alts.RegisterForClicks then f.alts:RegisterForClicks("LeftButtonUp", "RightButtonUp") end
    place(f.alts)
    f.alts:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(L["Post an Twinks"], 1, 1, 1)
        local plan, order = A.Extras:MailPlan()
        if #order == 0 then
            GameTooltip:AddLine(L["Nichts zu verschicken. Rechtsklick: Regeln festlegen."], 0.9, 0.9, 0.9, true)
        else
            for _, to in ipairs(order) do
                GameTooltip:AddDoubleLine(to, string.format(L["%d Stapel"], #plan[to]), 1, 0.82, 0, 1, 1, 1)
            end
            GameTooltip:AddLine(L["Klick: eine Post verschicken. Rechtsklick: Regeln."], 0.6, 0.6, 0.6, true)
        end
        GameTooltip:Show()
    end)
    f.alts:SetScript("OnLeave", function() GameTooltip:Hide() end)
    -- Anhalten: nur sichtbar, solange abgeholt wird (statt eines dauerhaften roten "X")
    f.stop = UI:Button(f, L["Anhalten"], W, BH, function() M:Stop(L["angehalten"]) end, "danger")
    place(f.stop)
    f.stop.tooltip = L["Abholen anhalten"]
    -- zurückgekommene Ware (abgelaufen / abgebrochen): Hinweis mit Anzahl, Einstellen geht am Auktionshaus
    f.repost = UI:Button(f, "", W, BH, function()
        if A:IsAHOpen() and A.Extras then
            local ok, msg = A.Extras:RepostStep()
            if msg then A:Print(msg) end
        else
            A:Print(L["Neu einstellen geht am Auktionshaus: Verkaufen -> Meine Auktionen."])
        end
    end)
    place(f.repost)
    f.repost.tooltip = L["Zurückgekommene Auktionen (abgelaufen oder abgebrochen), die noch in den Taschen liegen.\nEinstellen am Auktionshaus: Verkaufen -> Meine Auktionen."]
    -- untereinander anordnen, nur was gerade Sinn ergibt:
    --  "Alles abholen" nur ohne WoW-eigenes "Alle öffnen" (oder im Testmodus für die Test-Post),
    --  "Anhalten" nur, solange abgeholt wird
    function f:UpdateState()
        local hasOpenAll = type(OpenAllMail) == "table"
        local test = A.TestMode and A.TestMode.active
        local list = { self.ah }
        if not hasOpenAll or test then table.insert(list, self.all); self.all:Show() else self.all:Hide() end
        table.insert(list, self.alts)
        if M.running then table.insert(list, self.stop); self.stop:Show() else self.stop:Hide() end
        local rc = A.Extras and A.Extras.RepostCount and A.Extras:RepostCount() or 0
        if rc > 0 then
            self.repost:SetText(string.format(L["Neu einstellen (%d)"], rc))
            table.insert(list, self.repost); self.repost:Show()
        else
            self.repost:Hide()
        end
        local y = -30
        for _, b in ipairs(list) do
            b:ClearAllPoints()
            b:SetPoint("TOP", self, "TOP", 0, y)
            y = y - BH - GAP
        end
        self:SetSize(W + 16, -y + 6)
    end
    f:UpdateState()
    self.buttons = f
    if not M.stateHooked then
        M.stateHooked = true
        local function upd() if M.buttons and M.buttons.UpdateState then M.buttons:UpdateState() end end
        A:On("MAILER_CHANGED", upd)
        A:On("TESTMODE_CHANGED", upd)
        A:On("SELLER_CHANGED", upd)      -- zurückgekommene Ware gezählt
    end
end

A:On("THEME_CHANGED", function()
    if M.buttons then M.buttons:Hide(); M.buttons = nil end
    -- Briefkasten offen (z. B. Sprachwechsel dort): Leiste gleich neu in der neuen Sprache
    if type(MailFrame) == "table" and MailFrame.IsShown and MailFrame:IsShown() then M:EnsureButtons() end
end)
