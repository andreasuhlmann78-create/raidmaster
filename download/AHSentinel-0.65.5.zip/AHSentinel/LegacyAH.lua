if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Auktionshaus-Schnittstelle für alle Clients
--
-- Moderne Clients (WoW Forever, Cataclysm/MoP Classic, Retail) haben
-- C_AuctionHouse mit Browse-/Item-Suche. Ältere Clients (Classic Era,
-- TBC Anniversary, Wrath Classic) kennen nur das alte Auktionshaus mit
-- QueryAuctionItems/GetAuctionItemInfo.
--
-- Das Addon spricht nur noch A.AH an:
--   * modern: A.AH = C_AuctionHouse (unverändert)
--   * alt:    A.AH = diese Nachbildung auf Basis der alten Befehle
-- Die globale Tabelle C_AuctionHouse wird NIE verändert (sonst würde
-- das Blizzard-Auktionsfenster "verunreinigt").
--
-- Ereignisse, die es im alten Client nicht gibt (z.B.
-- ITEM_SEARCH_RESULTS_UPDATED), meldet diese Datei selbst an die
-- Frames, die sich mit A:RegisterAHEvent angemeldet haben.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
-- Retail 12.x: die alten Item-/Zauber-Funktionen gibt es nur noch in C_Item / C_Spell
local GetItemInfo = GetItemInfo or (C_Item and C_Item.GetItemInfo)
local A = AHAnalyzerPro

local modern = type(C_AuctionHouse) == "table" and C_AuctionHouse.SendBrowseQuery ~= nil
local legacy = (not modern) and type(QueryAuctionItems) == "function" and type(GetAuctionItemInfo) == "function"

A.AH_LEGACY = legacy

-- Ereignis anmelden: echtes Ereignis, sonst (alter Client) Nachbildung
local fakeFrames = {}            -- [Ereignis] = { frame, ... }
local SUPPORTED = {}             -- Ereignisse, die die Nachbildung wirklich auslöst

-- alle angemeldeten Rahmen je Ereignis (für den Testmodus: simulierte Server-Antworten)
local allFrames = {}
function A:SimulateAHEvent(event, ...)
    for _, f in ipairs(allFrames[event] or {}) do
        local fn = f.GetScript and f:GetScript("OnEvent")
        if fn then
            local ok, err = pcall(fn, f, event, ...)
            if not ok and A.Print then A:Print("Test " .. event .. ": " .. tostring(err)) end
        end
    end
end

function A:RegisterAHEvent(frame, event)
    allFrames[event] = allFrames[event] or {}
    table.insert(allFrames[event], frame)
    -- altes Auktionshaus: Ereignisse, die die Nachbildung auslöst, immer über die Nachbildung.
    -- Manche Clients (z. B. TBC Anniversary) kennen die Namen der neuen AH-Ereignisse,
    -- lösen sie aber für das alte Auktionshaus nie aus - die Anmeldung gelingt, es kommt nie etwas an.
    if legacy and SUPPORTED[event] then
        fakeFrames[event] = fakeFrames[event] or {}
        table.insert(fakeFrames[event], frame)
        return true
    end
    local ok = pcall(frame.RegisterEvent, frame, event)
    if ok then return true end
    if not legacy then return false end
    fakeFrames[event] = fakeFrames[event] or {}
    table.insert(fakeFrames[event], frame)
    return SUPPORTED[event] == true
end

if not legacy then
    A.AH = C_AuctionHouse
    return
end

-- ------------------------------------------------------------
-- Ab hier: alter Client
-- ------------------------------------------------------------
local AH = {}
A.AH = AH

local L = A.L or setmetatable({}, { __index = function(_, k) return k end })
local EN = A.EN
if EN then
    EN["Angebot nicht mehr in der aktuellen Liste - bitte neu suchen."] = "Listing is no longer in the current list - please search again."
    EN["Item-Name unbekannt - Suche nicht möglich."] = "Item name unknown - cannot search."
    EN["Auktionshaus-Liste wird gelesen ..."] = "Reading auction house list ..."
    EN["Altes Auktionshaus erkannt (Classic) - Scan, Suche, Kauf und Einstellen laufen über die klassische Schnittstelle."] = "Classic auction house detected - scan, search, buying and posting use the classic interface."
    EN["Komplett-Scan ist erst in einigen Minuten wieder erlaubt - Scan läuft Seite für Seite (langsamer)."] = "A full scan is only allowed again in a few minutes - scanning page by page (slower)."
    EN["Item konnte nicht in das Verkaufsfeld gelegt werden."] = "Could not place the item in the sell slot."
    EN["Auktion nicht mehr in der Liste - bitte eigene Auktionen neu laden."] = "Auction is no longer in the list - please reload your auctions."
    EN[" (klassisches Auktionshaus)"] = " (classic auction house)"
end

for _, e in ipairs({
    "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED", "AUCTION_HOUSE_BROWSE_RESULTS_ADDED",
    "ITEM_SEARCH_RESULTS_UPDATED", "AUCTION_HOUSE_THROTTLED_SYSTEM_READY",
    "AUCTION_HOUSE_SHOW_ERROR", "AUCTION_HOUSE_PURCHASE_COMPLETED",
    "AUCTION_HOUSE_AUCTION_CREATED", "AUCTION_CANCELED", "OWNED_AUCTIONS_UPDATED",
}) do SUPPORTED[e] = true end

local function Fire(event, ...)
    local list = fakeFrames[event]
    if not list then return end
    for _, f in ipairs(list) do
        local fn = f.GetScript and f:GetScript("OnEvent")
        if fn then
            local ok, err = pcall(fn, f, event, ...)
            if not ok and A.Print then A:Print("LegacyAH " .. event .. ": " .. tostring(err)) end
        end
    end
end

local PAGE_SIZE = NUM_AUCTION_ITEMS_PER_PAGE or 50
local SEARCH_MAX_PAGES = 10
local GETALL_CHUNK = 2000

local function Now() return GetTime() end

local function CanQuery()
    if not CanSendAuctionQuery then return true, false end
    local ok, can, canAll = pcall(CanSendAuctionQuery)
    if not ok then return true, false end
    return can and true or false, canAll and true or false
end

-- eine Zeile der Liste "list"/"owner" lesen
-- Restzeit-Stufe des alten Auktionshauses -> Sekunden (Obergrenze)
local BID_TIME_LEFT = { 1799, 7199, 43199, 172800 }
local function TimeLeftOf(listType, i)
    if not GetAuctionItemTimeLeft then return nil end
    local ok, t = pcall(GetAuctionItemTimeLeft, listType, i)
    return ok and t and BID_TIME_LEFT[t] or nil
end

local function ReadRow(listType, i)
    local name, _, count, quality, _, level, _, minBid, minInc, buyout, bidAmount, highBidder, _, owner, _, saleStatus, itemID =
        GetAuctionItemInfo(listType, i)
    if not itemID then
        local link = GetAuctionItemLink and GetAuctionItemLink(listType, i)
        itemID = link and tonumber(link:match("item:(%d+)"))
    end
    minBid, bidAmount = minBid or 0, bidAmount or 0
    -- nächstes gültiges Gebot: über dem aktuellen Gebot um die Mindesterhöhung, sonst das Startgebot
    local nextBid = (bidAmount > 0) and (bidAmount + (minInc or 0)) or minBid
    return {
        name = name, count = count or 1, quality = quality, level = level,
        minBid = minBid, buyout = buyout or 0, bid = bidAmount, nextBid = nextBid,
        highBidder = highBidder and true or false, timeLeft = TimeLeftOf(listType, i),
        owner = owner, sold = saleStatus == 1, itemID = itemID,
    }
end

local function IsOwn(owner)
    if not owner then return false end
    local me = UnitName and UnitName("player")
    return owner == me or (me and owner:match("^" .. me .. "%-") ~= nil) or false
end

-- ------------------------------------------------------------
-- Laufende Anfrage (es gibt im alten Client nur EINE Ergebnisliste)
-- ------------------------------------------------------------
local cur = nil          -- { kind = "browse"/"search", ... }
local nextID = 0
local rowsByID = {}      -- [auctionID] = { page, index, itemID, count, buyout }

local function NewID(row)
    nextID = nextID + 1
    rowsByID[nextID] = row
    return nextID
end

local function SendQuery(q, page)
    page = page or 0
    local ok, err = pcall(QueryAuctionItems, q.text or "", q.minLevel, q.maxLevel, page,
        false, nil, q.getAll or false, q.exact or false, q.filters)
    if not ok then error(err, 0) end
    q.page = page
    q.sentAt = Now()
    q.waiting = true
end

-- Daten einer Seite übernehmen (wird bei jedem Listen-Update erneut gerufen)
local function ReadPage(q)
    local batch, total = GetNumAuctionItems("list")
    batch, total = batch or 0, total or 0
    q.total = total
    local rows = {}
    for i = 1, batch do
        local r = ReadRow("list", i)
        if r.itemID and (q.kind == "browse" or r.itemID == q.itemID) then
            r.page, r.index = q.page, i
            table.insert(rows, r)
            if A.NoteBid and r.nextBid > 0 and not r.highBidder then
                A:NoteBid(r.itemID, r.nextBid, r.count, r.timeLeft, r.buyout, IsOwn(r.owner))
            end
        end
    end
    q.pages[q.page] = rows
    q.dirty = true
    q.waiting = false
    q.lastUpdate = Now()
    local maxPage = math.max(0, math.ceil(total / PAGE_SIZE) - 1)
    q.lastPage = maxPage
    if q.kind == "search" then
        q.full = (q.page >= maxPage) or (q.page + 1 >= SEARCH_MAX_PAGES)
    else
        q.full = q.page >= maxPage
    end
    if q.pinned then q.full = true end           -- Seite für einen Kauf geladen: nicht weiterblättern
end

-- getAll: ganze Liste stückweise lesen (sonst stockt das Spiel)
local function StartGetAllRead(q)
    local batch = GetNumAuctionItems("list") or 0
    q.reading = { pos = 1, n = batch, agg = {} }
end

local function StepGetAllRead(q)
    local r = q.reading
    -- pro Frame nur ein paar Millisekunden lesen (sonst ruckelt das Spiel)
    local clock = debugprofilestop
    local start = clock and clock()
    local last = math.min(r.n, r.pos + GETALL_CHUNK - 1)
    for i = r.pos, last do
        if start and i > r.pos + 50 and clock() - start > (A.FRAME_BUDGET or 6) then last = i - 1; break end
        local name, _, count, _, _, _, _, minBid, minInc, buyout, bidAmount, highBidder, _, owner, _, _, itemID = GetAuctionItemInfo("list", i)
        count = count or 1
        -- Gebot weit unter Wert? merken (Marktwert pro Item nur einmal je Scan berechnen)
        if itemID and A.NoteBid and (minBid or 0) > 0 and not highBidder then
            r.mv = r.mv or {}
            local mv = r.mv[itemID]
            if mv == nil then mv = A:GetMarketValue(itemID) or false; r.mv[itemID] = mv end
            if mv then
                local nb = ((bidAmount or 0) > 0) and (bidAmount + (minInc or 0)) or minBid
                if nb / math.max(1, count) <= mv * A.BID_PREFILTER then
                    A:NoteBid(itemID, nb, count, TimeLeftOf("list", i), buyout, IsOwn(owner), mv)
                end
            end
        end
        if itemID and buyout and buyout > 0 then
            local unit = math.floor(buyout / math.max(1, count))
            local b = r.agg[itemID]
            if not b then
                r.agg[itemID] = { itemKey = { itemID = itemID, itemLevel = 0, itemSuffix = 0, battlePetSpeciesID = 0 },
                                  minPrice = unit, totalQuantity = count }
            else
                if unit < b.minPrice then b.minPrice = unit end
                b.totalQuantity = b.totalQuantity + count
            end
        end
    end
    r.pos = last + 1
    if r.pos > r.n then
        local list = {}
        for _, v in pairs(r.agg) do table.insert(list, v) end
        q.results = list
        q.reading = nil
        q.full = true
        q.waiting = false
        Fire("AUCTION_HOUSE_BROWSE_RESULTS_UPDATED")
    end
end

-- Browse-Ergebnisse: pro Item günstigster Stückpreis und Gesamtmenge
local function BuildBrowseResults(q)
    if q.getAll then return q.results or {} end
    if not q.dirty and q.results then return q.results end
    local agg, list = {}, {}
    for _, rows in pairs(q.pages) do
        for _, r in ipairs(rows) do
            if r.buyout > 0 then
                local unit = math.floor(r.buyout / math.max(1, r.count))
                local b = agg[r.itemID]
                if not b then
                    b = { itemKey = { itemID = r.itemID, itemLevel = 0, itemSuffix = 0, battlePetSpeciesID = 0 },
                          minPrice = unit, totalQuantity = r.count }
                    agg[r.itemID] = b
                    table.insert(list, b)
                else
                    if unit < b.minPrice then b.minPrice = unit end
                    b.totalQuantity = b.totalQuantity + r.count
                end
            end
        end
    end
    q.results, q.dirty = list, false
    return list
end

local function BuildSearchRows(q)
    if not q.dirty and q.rows then return q.rows end
    local out = {}
    local pages = {}
    for p in pairs(q.pages) do table.insert(pages, p) end
    table.sort(pages)
    for _, p in ipairs(pages) do
        for _, r in ipairs(q.pages[p]) do
            if not r.id then r.id = NewID(r) end
            table.insert(out, r)
        end
    end
    q.rows, q.dirty = out, false
    return out
end

-- ------------------------------------------------------------
-- Browse-Suche (Markt-Scan, Sniper-Suchbegriffe, Wächter)
-- ------------------------------------------------------------
local function ToFilters(query)
    local list = query.itemClassFilters
    if type(list) ~= "table" or #list == 0 then return nil end
    local out = {}
    for _, f in ipairs(list) do
        table.insert(out, { classID = f.classID, subClassID = f.subClassID, inventoryType = f.inventoryType })
    end
    return out
end

function AH.SendBrowseQuery(query)
    query = query or {}
    local text = query.searchString or ""
    local filters = ToFilters(query)
    local q = {
        kind = "browse", text = text, filters = filters, pages = {}, dirty = true,
        minLevel = (query.minLevel or 0) > 0 and query.minLevel or nil,
        maxLevel = (query.maxLevel or 0) > 0 and query.maxLevel or nil,
    }
    -- leere Suche ohne Filter = kompletter Markt-Scan: alles auf einmal, wenn der Server es erlaubt
    if text == "" and not filters and not q.minLevel and not q.maxLevel then
        local _, canAll = CanQuery()
        if canAll then
            q.getAll = true
            A:Print(L["Auktionshaus-Liste wird gelesen ..."])
        else
            A:Print(L["Komplett-Scan ist erst in einigen Minuten wieder erlaubt - Scan läuft Seite für Seite (langsamer)."])
        end
    end
    cur = q
    SendQuery(q, 0)
end

function AH.GetBrowseResults()
    if not cur or cur.kind ~= "browse" then return {} end
    return BuildBrowseResults(cur)
end

function AH.GetNumBrowseResults()
    return #AH.GetBrowseResults()
end

-- laufende Browse-Suche abbrechen: keine weiteren Seiten mehr anfordern
-- (sonst verbraucht die alte Suche die Server-Sperre, bevor die neue starten darf)
function AH.AbortBrowse()
    if cur and cur.kind == "browse" and not cur.getAll then
        cur.wantMore = false
        cur.full = true
    end
end

-- Fortschritt der seitenweisen Suche: erhaltene Seiten, Seiten insgesamt
function AH.GetBrowseProgress()
    if not cur or cur.kind ~= "browse" then return nil end
    local got = 0
    for _ in pairs(cur.pages) do got = got + 1 end
    return got, (cur.lastPage or 0) + 1, cur.waiting or cur.wantMore or false
end

function AH.HasFullBrowseResults()
    if not cur or cur.kind ~= "browse" then return false end
    return cur.full == true
end

-- nächste Seite: wird gesendet, sobald der Server wieder Anfragen annimmt
function AH.RequestMoreBrowseResults()
    if not cur or cur.kind ~= "browse" or cur.full or cur.getAll then return end
    cur.wantMore = true
end

-- ------------------------------------------------------------
-- Einzelsuche nach einem Item (Sniper, Preisprüfung)
-- ------------------------------------------------------------
function AH.MakeItemKey(itemID)
    return { itemID = itemID, itemLevel = 0, itemSuffix = 0, battlePetSpeciesID = 0 }
end

local function ItemName(itemID)
    local name = GetItemInfo and GetItemInfo(itemID)
    if name and name ~= "" then return name end
    if A.GetItemName then
        local n = A:GetItemName(itemID)
        if n and n ~= "" and not n:match("^Item %d+$") and not n:match("^%[?%d+%]?$") then return n end
    end
    return nil
end

function AH.SendSearchQuery(itemKey)
    local itemID = type(itemKey) == "table" and itemKey.itemID or tonumber(itemKey)
    if not itemID then error("itemKey", 0) end
    local name = ItemName(itemID)
    local q = { kind = "search", itemID = itemID, key = itemKey, pages = {}, dirty = true }
    cur = q
    if not name then
        -- Name unbekannt: leeres, fertiges Ergebnis melden
        q.full = true
        C_Timer.After(0, function() Fire("ITEM_SEARCH_RESULTS_UPDATED", itemKey) end)
        return
    end
    q.text, q.exact = name, true
    SendQuery(q, 0)
end

local function SearchFor(key)
    local id = type(key) == "table" and key.itemID or key
    if cur and cur.kind == "search" and cur.itemID == id then return cur end
    return nil
end

function AH.GetNumItemSearchResults(itemKey)
    local q = SearchFor(itemKey)
    if not q then return 0 end
    return #BuildSearchRows(q)
end

function AH.GetItemSearchResultInfo(itemKey, index)
    local q = SearchFor(itemKey)
    if not q then return nil end
    local r = BuildSearchRows(q)[index]
    if not r then return nil end
    local link = GetAuctionItemLink and r.page == q.page and GetAuctionItemLink("list", r.index) or nil
    return {
        auctionID = r.id, itemKey = q.key, itemLink = link, quantity = r.count,
        buyoutAmount = r.buyout > 0 and r.buyout or nil, bidAmount = r.bid, minBid = r.nextBid or r.minBid,
        timeLeftSeconds = r.timeLeft, bidder = r.highBidder and UnitName and UnitName("player") or nil,
        containsOwnerItem = IsOwn(r.owner), owners = { r.owner },
    }
end

function AH.HasFullItemSearchResults(itemKey)
    local q = SearchFor(itemKey)
    return q ~= nil and q.full == true and not q.waiting
end

-- Waren gibt es im alten Auktionshaus nicht (alles sind Einzelangebote/Stapel)
function AH.GetNumCommoditySearchResults() return 0 end
function AH.GetCommoditySearchResultInfo() return nil end
function AH.HasFullCommoditySearchResults() return false end

-- ------------------------------------------------------------
-- Kaufen (Sofortkauf eines Stapels)
-- ------------------------------------------------------------
local pendingAction = nil      -- { kind = "buy"/"post"/"cancel", id, time }

local function Matches(i, row)
    local r = ReadRow("list", i)
    return r.itemID == row.itemID and r.count == row.count and r.buyout == row.buyout and not IsOwn(r.owner)
end

-- Kauf vorbereiten: Im alten Auktionshaus lässt sich nur kaufen, was gerade in der Liste steht.
-- Liegt das Angebot auf einer anderen Ergebnisseite, wird diese Seite geladen.
-- Rückgabe: true = sofort kaufbar
function AH.IsBuyReady(auctionID)
    local row = rowsByID[auctionID]
    if not (row and cur and cur.kind == "search") or cur.waiting then return false end
    local batch = GetNumAuctionItems("list") or 0
    if row.page == cur.page and row.index <= batch and Matches(row.index, row) then return true end
    for i = 1, batch do if Matches(i, row) then return true end end
    return false
end

function AH.PrepareBuy(auctionID)
    if AH.IsBuyReady(auctionID) then return true end
    local row = rowsByID[auctionID]
    if not (row and cur and cur.kind == "search") then return false end
    cur.pinned, cur.full, cur.wantMore = true, true, false
    if not cur.waiting and cur.page ~= row.page then cur.wantPage = row.page end
    return false
end

function AH.PlaceBid(auctionID, amount)
    local row = rowsByID[auctionID]
    if not row then error(L["Angebot nicht mehr in der aktuellen Liste - bitte neu suchen."], 0) end
    local batch = GetNumAuctionItems("list") or 0
    local index
    if row.page == (cur and cur.page) and row.index <= batch and Matches(row.index, row) then
        index = row.index
    else
        for i = 1, batch do
            if Matches(i, row) then index = i; break end
        end
    end
    if not index then error(L["Angebot nicht mehr in der aktuellen Liste - bitte neu suchen."], 0) end
    PlaceAuctionBid("list", index, amount or row.buyout)
    pendingAction = { kind = "buy", id = auctionID, time = Now() }
end

-- ------------------------------------------------------------
-- Einstellen
-- ------------------------------------------------------------
local function BagSlot(loc)
    if type(loc) == "table" and loc.GetBagAndSlot then return loc:GetBagAndSlot() end
    return nil
end

local function Pickup(bag, slot)
    if C_Container and C_Container.PickupContainerItem then
        C_Container.PickupContainerItem(bag, slot)
    else
        PickupContainerItem(bag, slot)
    end
end

local function MaxStack(itemID)
    local stack = itemID and select(8, GetItemInfo(itemID))
    return math.max(1, stack or 1)
end

local LearnDeposit   -- weiter unten: Einstellgebühr lernen
local function LegacyPost(loc, duration, stackSize, numStacks, unitPrice)
    local bag, slot = BagSlot(loc)
    if not bag then error(L["Item konnte nicht in das Verkaufsfeld gelegt werden."], 0) end
    ClearCursor()
    Pickup(bag, slot)
    ClickAuctionSellItemButton()
    ClearCursor()
    local name = GetAuctionSellItemInfo and GetAuctionSellItemInfo()
    if not name then error(L["Item konnte nicht in das Verkaufsfeld gelegt werden."], 0) end
    pcall(LearnDeposit, bag, slot, duration or 2, stackSize, numStacks)
    local buyout = math.max(1, math.floor(unitPrice * stackSize))
    PostAuction(buyout, buyout, duration or 2, stackSize, numStacks)
    pendingAction = { kind = "post", time = Now() }
end

-- Waren: qty Stück als möglichst große Stapel
function AH.PostCommodity(loc, duration, qty, unitPrice, wantStack)
    local itemID = C_Item and C_Item.GetItemID and select(2, pcall(C_Item.GetItemID, loc))
    if type(itemID) ~= "number" then
        local bag, slot = BagSlot(loc)
        local link = bag and (C_Container and C_Container.GetContainerItemLink and C_Container.GetContainerItemLink(bag, slot)
            or (GetContainerItemLink and GetContainerItemLink(bag, slot)))
        itemID = link and tonumber(link:match("item:(%d+)"))
    end
    local stackSize = math.min(qty, MaxStack(itemID))
    if wantStack and wantStack >= 1 then stackSize = math.min(stackSize, math.floor(wantStack)) end
    local numStacks = math.max(1, math.floor(qty / stackSize))
    LegacyPost(loc, duration, stackSize, numStacks, unitPrice)
end

function AH.PostItem(loc, duration, quantity, bid, buyout)
    LegacyPost(loc, duration, 1, quantity or 1, buyout)
end

-- Einstellgebühr: im alten Client erst bekannt, wenn das Item im Verkaufsfeld liegt
-- Einstellgebühr schätzen: Händlerpreis x Faktor je Dauer (1/2/3). Den genauen Faktor lernt das
-- Addon beim ersten echten Einstellen (dann kennt der Server die Gebühr) und merkt ihn sich.
AH.DEPOSIT_GUESS = { [1] = 0.15, [2] = 0.30, [3] = 0.60 }
local function DepositFactor(duration)
    local learned = A.db and A.db.settings.depositFactors
    if learned and learned[duration] then return learned[duration], true end
    return AH.DEPOSIT_GUESS[duration] or AH.DEPOSIT_GUESS[2], false
end
function AH.EstimateDeposit(itemID, duration, qty)
    local vendor = itemID and A.GetVendorPrice and A:GetVendorPrice(itemID)
    -- WoW Forever: ohne Händlerpreis gilt trotzdem die Mindestgebühr von 1 Silber
    if not vendor or vendor <= 0 then
        if A.IsForever and A:IsForever() and itemID then return A.FOREVER_MIN_FEE, false end
        return nil
    end
    local f, exact = DepositFactor(duration or 2)
    local dep = math.max(1, math.floor(vendor * (qty or 1) * f + 0.5))
    if A.IsForever and A:IsForever() then dep = math.max(dep, A.FOREVER_MIN_FEE) end
    return dep, exact
end
local function ItemIDFromLoc(loc)
    if type(loc) ~= "table" then return nil end
    if loc.GetBagAndSlot then
        local bag, slot = loc:GetBagAndSlot()
        local link = bag and ((C_Container and C_Container.GetContainerItemLink and C_Container.GetContainerItemLink(bag, slot))
            or (GetContainerItemLink and GetContainerItemLink(bag, slot)))
        return link and tonumber(link:match("item:(%d+)"))
    end
    return nil
end
function AH.CalculateCommodityDeposit(itemID, duration, qty) return (AH.EstimateDeposit(itemID, duration, qty)) end
function AH.CalculateItemDeposit(loc, duration, qty) return (AH.EstimateDeposit(ItemIDFromLoc(loc), duration, qty)) end
function AH.DepositIsEstimate(duration) return not select(2, DepositFactor(duration or 2)) end

-- beim echten Einstellen: Gebühr vom Server lesen und den Faktor lernen
LearnDeposit = function(bag, slot, duration, stackSize, numStacks)
    if not (CalculateAuctionDeposit and A.db) then return end
    local link = (C_Container and C_Container.GetContainerItemLink and C_Container.GetContainerItemLink(bag, slot))
        or (GetContainerItemLink and GetContainerItemLink(bag, slot))
    local itemID = link and tonumber(link:match("item:(%d+)"))
    local vendor = itemID and A:GetVendorPrice(itemID)
    if not vendor or vendor <= 0 then return end
    local ok, dep = pcall(CalculateAuctionDeposit, duration, stackSize, numStacks)
    local units = stackSize * numStacks
    if not (ok and type(dep) == "number" and dep > 0) then
        ok, dep = pcall(CalculateAuctionDeposit, duration)
        units = stackSize
    end
    if not (ok and type(dep) == "number" and dep > 0) then return end
    local f = dep / (vendor * units)
    if f > 0.005 and f < 10 then
        A.db.settings.depositFactors = A.db.settings.depositFactors or {}
        A.db.settings.depositFactors[duration] = math.floor(f * 10000 + 0.5) / 10000
    end
end

-- ------------------------------------------------------------
-- Eigene Auktionen
-- ------------------------------------------------------------
local owned = {}
local OWN_BASE = 1000000
local TIME_LEFT = { 1800, 7200, 28800, 86400 }

function AH.QueryOwnedAuctions()
    if GetOwnerAuctionItems then GetOwnerAuctionItems() end
    -- Liste ist oft schon geladen: sofort melden
    C_Timer.After(0.3, function() Fire("OWNED_AUCTIONS_UPDATED") end)
end

function AH.GetNumOwnedAuctions()
    local n = GetNumAuctionItems("owner")
    return n or 0
end

function AH.GetOwnedAuctionInfo(i)
    local r = ReadRow("owner", i)
    if not r.itemID then return nil end
    local id = OWN_BASE + i
    owned[id] = { index = i, itemID = r.itemID, count = r.count, buyout = r.buyout }
    local tl = GetAuctionItemTimeLeft and GetAuctionItemTimeLeft("owner", i)
    return {
        auctionID = id, itemKey = AH.MakeItemKey(r.itemID),
        itemLink = GetAuctionItemLink and GetAuctionItemLink("owner", i),
        quantity = r.count, buyoutAmount = r.buyout > 0 and r.buyout or nil, bidAmount = r.bid,
        status = r.sold and 1 or 0, timeLeftSeconds = tl and TIME_LEFT[tl] or nil,
    }
end

function AH.CanCancelAuction(auctionID)
    return owned[auctionID] ~= nil
end

function AH.CancelAuction(auctionID)
    local o = owned[auctionID]
    if not o then error(L["Auktion nicht mehr in der Liste - bitte eigene Auktionen neu laden."], 0) end
    local n = GetNumAuctionItems("owner") or 0
    local index
    local function same(i)
        local r = ReadRow("owner", i)
        return r.itemID == o.itemID and r.count == o.count and r.buyout == o.buyout and not r.sold
    end
    if o.index <= n and same(o.index) then index = o.index
    else for i = 1, n do if same(i) then index = i; break end end end
    if not index then error(L["Auktion nicht mehr in der Liste - bitte eigene Auktionen neu laden."], 0) end
    _G.CancelAuction(index)
    pendingAction = { kind = "cancel", id = auctionID, time = Now() }
end

-- ------------------------------------------------------------
-- Drossel
-- ------------------------------------------------------------
function AH.IsThrottledMessageSystemReady()
    if cur and cur.reading then return false end
    return (CanQuery())
end

-- ------------------------------------------------------------
-- Ereignisse des alten Clients übersetzen
-- ------------------------------------------------------------
local evt = CreateFrame("Frame")
for _, e in ipairs({ "AUCTION_ITEM_LIST_UPDATE", "AUCTION_OWNED_LIST_UPDATE", "CHAT_MSG_SYSTEM",
                     "UI_ERROR_MESSAGE", "AUCTION_HOUSE_SHOW", "AUCTION_HOUSE_CLOSED" }) do
    pcall(evt.RegisterEvent, evt, e)
end

-- Fehlermeldungen, die zu Kauf/Einstellen/Abbrechen gehören
local AUCTION_ERRORS = {
    "ERR_AUCTION_BID_OWN", "ERR_AUCTION_DATABASE_ERROR", "ERR_AUCTION_ENOUGH_ITEMS", "ERR_AUCTION_HIGHER_BID",
    "ERR_AUCTION_MIN_BID", "ERR_AUCTION_REPAIR_ITEM", "ERR_AUCTION_USED_CHARGES", "ERR_AUCTION_WRAPPED_ITEM",
    "ERR_AUCTION_LIMITED_DURATION_ITEM", "ERR_AUCTION_BAG", "ERR_AUCTION_BOUND_ITEM", "ERR_AUCTION_CONJURED_ITEM",
    "ERR_AUCTION_QUEST_ITEM", "ERR_ITEM_NOT_FOUND", "ERR_NOT_ENOUGH_MONEY", "ERR_AUCTION_HOUSE_DISABLED",
    "ERR_ITEM_LOCKED", "ERR_RESTRICTED_ACCOUNT",
}
local function IsAuctionError(msg)
    for _, g in ipairs(AUCTION_ERRORS) do
        local s = _G[g]
        if s and msg == s then return true end
    end
    return false
end

local function SystemIs(msg, global)
    local s = _G[global]
    return s and msg == s
end

evt:SetScript("OnEvent", function(_, event, a1, a2)
    if event == "AUCTION_ITEM_LIST_UPDATE" then
        local q = cur
        if not q or not q.sentAt or q.reading or (q.getAll and q.full) then return end
        if q.getAll then
            -- Daten kommen in Schüben: erst lesen, wenn es ruhig ist (siehe Takt unten)
            q.lastUpdate = Now()
            q.gotData = true
            return
        end
        local wasWaiting = q.waiting
        ReadPage(q)
        if q.kind == "browse" then
            Fire(wasWaiting and q.page > 0 and "AUCTION_HOUSE_BROWSE_RESULTS_ADDED" or "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED")
        else
            if not q.full then q.wantMore = true end
            Fire("ITEM_SEARCH_RESULTS_UPDATED", q.key)
        end
    elseif event == "AUCTION_OWNED_LIST_UPDATE" then
        Fire("OWNED_AUCTIONS_UPDATED")
    elseif event == "CHAT_MSG_SYSTEM" then
        local msg = a1
        if SystemIs(msg, "ERR_AUCTION_BID_PLACED") or SystemIs(msg, "ERR_AUCTION_WON_S") then
            if pendingAction and pendingAction.kind == "buy" then
                Fire("AUCTION_HOUSE_PURCHASE_COMPLETED", pendingAction.id)
                pendingAction = nil
            end
        elseif SystemIs(msg, "ERR_AUCTION_STARTED") then
            Fire("AUCTION_HOUSE_AUCTION_CREATED")
            if pendingAction and pendingAction.kind == "post" then pendingAction = nil end
        elseif SystemIs(msg, "ERR_AUCTION_REMOVED") then
            Fire("AUCTION_CANCELED", pendingAction and pendingAction.id)
            if pendingAction and pendingAction.kind == "cancel" then pendingAction = nil end
        end
    elseif event == "UI_ERROR_MESSAGE" then
        -- Classic: (Fehlertyp, Text); sehr alte Clients: (Text)
        local msg = type(a2) == "string" and a2 or a1
        if pendingAction and Now() - pendingAction.time < 5 and type(msg) == "string" and IsAuctionError(msg) then
            pendingAction = nil
            Fire("AUCTION_HOUSE_SHOW_ERROR")
        end
    elseif event == "AUCTION_HOUSE_SHOW" then
        if not A.legacyNoticeShown then
            A.legacyNoticeShown = true
            A:Print(L["Altes Auktionshaus erkannt (Classic) - Scan, Suche, Kauf und Einstellen laufen über die klassische Schnittstelle."])
        end
    elseif event == "AUCTION_HOUSE_CLOSED" then
        cur = nil
        pendingAction = nil
        wipe(rowsByID)
        wipe(owned)
    end
end)

-- Takt: weitere Seiten senden, getAll stückweise lesen, "bereit" melden
local wasReady = true
evt:SetScript("OnUpdate", function()
    local q = cur
    if q then
        if q.reading then
            StepGetAllRead(q)
        elseif q.getAll and q.gotData and not q.full and Now() - (q.lastUpdate or 0) >= 1 then
            StartGetAllRead(q)
        elseif q.wantPage and not q.waiting then
            if CanQuery() then
                local p = q.wantPage
                q.wantPage = nil
                pcall(SendQuery, q, p)
            end
        elseif q.wantMore and not q.waiting and not q.full then
            if CanQuery() then
                q.wantMore = false
                local ok = pcall(SendQuery, q, (q.page or 0) + 1)
                if not ok then q.full = true end
            end
        elseif q.waiting and q.sentAt and not q.getAll and Now() - q.sentAt > 10 then
            -- keine Antwort: Seite als fertig werten
            q.waiting = false
            q.full = true
            if q.kind == "search" then Fire("ITEM_SEARCH_RESULTS_UPDATED", q.key)
            else Fire("AUCTION_HOUSE_BROWSE_RESULTS_UPDATED") end
        end
    end
    local ready = AH.IsThrottledMessageSystemReady()
    if ready and not wasReady then Fire("AUCTION_HOUSE_THROTTLED_SYSTEM_READY") end
    wasReady = ready
end)
