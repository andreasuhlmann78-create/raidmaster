-- BuffSentinel – Prüfliste im Spiel (Entscheid des Nutzers 16.11.2026 06:47; gemeinsamer Baustein GoldSentinelPruefliste.lua)
-- Copyright (c) 2026 GoldSentinel. All Rights Reserved.
--
-- Nur im Entwicklermodus (GoldSentinelDev): "/bsen prüfliste" öffnet die Liste der Punkte, die im echten Spiel geprüft werden
-- müssen. Jeder Punkt sagt genau, was zu tun ist und was zu sehen sein muss. Wo BuffSentinel es selbst erkennt, wird der Punkt
-- von selbst erledigt (BS.PLHit an der Stelle im Code, wo die Funktion wirklich gewirkt hat). Ohne Entwicklermodus: wirkungslos.
-- Höchstens 14 Punkte; nach der Prüfung durch die Prüf-Sitzung erledigte Punkte in der nächsten Version herausnehmen.

local ADDON, BS = ...
local L = BS.L

-- Reihenfolge = wie man es im Spiel am besten nacheinander macht (zuerst Stadt, dann Klassen-Punkte, zuletzt Gruppe/Kampf)
BS.PRUEF_POINTS = {
    { id = "DURA", title = "Reparatur-Erinnerung in der Stadt", since = "0.9.25",
      todo = "Mit einem Gegenstand unter 30 % Haltbarkeit in eine Hauptstadt (z. B. Orgrimmar) gehen und absteigen.",
      expect = "Knopf \"REPARIEREN!\" mit dem Prozentwert des schwächsten Gegenstands (z. B. 25%). Nach dem Reparieren ist er weg." },
    { id = "READY", title = "Zeile beim Bereitschaftscheck", since = "0.9.26",
      todo = "In einer Gruppe einen Bereitschaftscheck starten lassen (Gruppenleiter: Rechtsklick aufs eigene Bild > Bereitschaftscheck).",
      expect = "Eine Zeile im eigenen Chat: \"Bereitschaftscheck – es fehlt: …\" oder \"Bereitschaftscheck: alles bereit.\"" },
    { id = "PERF", title = "Zeile LEISTUNG nach einem Kampf", since = "0.9.41",
      todo = "Einen Kampf führen (ein Mob reicht, besser ein Dungeon-Boss), danach /bsen protokoll öffnen.",
      expect = "Zeile \"LEISTUNG Kampf: längster Rahmen durch BuffSentinel … ms (…), über 16 ms: 0 von … Rahmen\"." },
    { id = "AMMO", title = "Jäger: Munition knapp (WoW Forever)", since = "0.9.23",
      todo = "Jäger mit Bogen oder Schusswaffe: so viele Pfeile/Kugeln verkaufen oder ablegen, dass weniger als 200 übrig sind.",
      expect = "Ausserhalb des Kampfes Knopf \"MUNITION KNAPP!\" mit der Restzahl. Erscheint nichts: bitte \"Nicht OK\" (Munitionsplatz fehlt)." },
    { id = "PET", title = "Jäger/Hexer: Begleiter fehlt", since = "0.9.24",
      todo = "Begleiter wegschicken (Tier freilassen bzw. Dämon entlassen) und 3 Sekunden warten; danach wieder rufen.",
      expect = "Nach 3 Sekunden \"BEGLEITER FEHLT!\" bzw. \"DÄMON FEHLT!\"; nach dem Rufen sofort weg. Beim Ab- und Aufsteigen kein Aufblinken." },
    { id = "PETFOOD", title = "Jäger: füttern und Tierfutter", since = "0.9.42",
      todo = "Jäger: 1) Begleiter, der nicht glücklich ist (Symbol am Begleiterbild gelb/rot). 2) In WoW Forever: weniger als 10 Stück Futter, das er frisst.",
      expect = "1) \"BEGLEITER FÜTTERN!\" mit \"zufrieden 100%\"/\"unglücklich 75%\". 2) \"TIERFUTTER KNAPP!\" mit der Zahl. Fehlt etwas: \"Nicht OK\"." },
    { id = "INFIRE", title = "Priester: Inneres Feuer Aufladungen", since = "0.9.30",
      todo = "Priester mit Innerem Feuer so oft treffen lassen, bis weniger als 5 Aufladungen übrig sind; Kampf beenden.",
      expect = "\"INNERES FEUER ERNEUERN!\" mit der Restzahl; Klick wirkt Inneres Feuer. Erscheint nichts: \"Nicht OK\"." },
    { id = "HEXER", title = "Hexer: Splitter, Platz, Gesundheitsstein", since = "0.9.35",
      todo = "Hexenmeister: Gesundheitsstein in die Bank legen (oder weniger als 3 Seelensplitter, oder volle Taschen).",
      expect = "\"KEIN GESUNDHEITSSTEIN!\" bzw. \"SPLITTER KNAPP!\" bzw. \"KEIN PLATZ FÜR SPLITTER!\"; nach dem Beheben weg." },
    { id = "SOULSTONE", title = "Hexer: Seelenstein in der Gruppe", since = "0.9.32",
      todo = "Hexenmeister in einer Gruppe, in der niemand einen Seelenstein hat; danach einen Seelenstein auf jemanden legen.",
      expect = "\"KEIN SEELENSTEIN IN DER GRUPPE!\"; nach dem Auflegen weg." },
    { id = "TOTEM", title = "Schamane: Totem fehlt", since = "0.9.40",
      todo = "Schamane: ein Totem (z. B. Feuertotem) in die Bank legen. Wrath: zusätzlich ein Meistertotem nur im Relikt-Platz testen.",
      expect = "\"TOTEM FEHLT!\" mit dem Element (z. B. \"Feuer\"); mit Meistertotem (Tasche oder Relikt-Platz) keine Meldung." },
    { id = "WAFFE", title = "Schamane: Waffen-IDs messen", since = "0.9.20",
      todo = "Schamane: 1) nur eigene Waffenverzauberung, 2) nur Waffen-Totem, 3) beides gleichzeitig – je einige Sekunden stehen lassen.",
      expect = "In /bsen protokoll drei Zeilen \"WAFFE mh=… oh=… totem=…\". Das Addon erkennt alle drei Fälle selbst." },
    { id = "REAG", title = "Reagenz knapp in der Gruppe", since = "0.9.27",
      todo = "Magier/Priester/Druide/Paladin in einer Gruppe mit weniger als 10 Gruppenbuff-Reagenzien (Paladin: 20 Symbole).",
      expect = "\"REAGENZ KNAPP!\" mit der Anzahl; allein keine Meldung." },
    { id = "RESTOCK", title = "Nachkaufen beim Händler (ein Klick)", since = "0.9.47",
      todo = "Optionen: \"Nachkaufen-Knopf beim Händler\" einschalten. Mit knapper Munition oder knappem Reagenz zum passenden Händler, ihn ansprechen, Knopf unter dem Händlerfenster einmal klicken.",
      expect = "Knopf \"Nachkaufen: <Anzahl>× <Ware> für <Preis>\"; nach dem Klick genau diese Menge gekauft, Knopf kurz grau, Gold höchstens um den Preis weniger, mindestens 1g übrig." },
    { id = "RF", title = "Paladin: Zorn der Gerechtigkeit", since = "0.9.39",
      todo = "Paladin (Heilig oder Vergeltung) in einer Gruppe, ohne Tank-Rolle, Zorn der Gerechtigkeit anmachen.",
      expect = "Genau EINE Zeile im eigenen Chat \"Hinweis: Zorn der Gerechtigkeit ist an …\"; in derselben Gruppe keine zweite." },
}

-- Eintrag (Schlüssel) -> Punkt, der als erledigt gilt, sobald die Erinnerung im echten Spiel erschienen ist
BS.PRUEF_BY_KEY = {
    durability = "DURA", ammo = "AMMO", pet = "PET", pethappy = "PETFOOD", petfood = "PETFOOD", innerfire_ch = "INFIRE",
    healthstone = "HEXER", shards = "HEXER", shardspace = "HEXER", soulstone = "SOULSTONE", totems = "TOTEM",
    r_powder = "REAG", r_candle = "REAG", r_gotw = "REAG", r_symbol = "REAG",
}

-- Liste anmelden (beim Einloggen und beim Öffnen – der Entwicklermodus kann erst später eingeschaltet werden)
function BS:SetupPruefliste()
    local P = GoldSentinelPruefliste
    if not P or not P.Register then self.PL = nil; return nil end
    -- schon echt angemeldet? (die leere Liste ohne Entwicklermodus liefert für jedes Feld eine Funktion – darum auf Text prüfen)
    if self.PL and type(rawget(self.PL, "addon")) == "string" then return self.PL end
    self.PL = P:Register("BuffSentinel", { db = function() return BuffSentinelDB end, version = BS.version,
        points = BS.PRUEF_POINTS })
    return self.PL
end

-- Punkt als erledigt melden – nur im echten Spiel (nicht während der Testroutine), je Sitzung höchstens einmal je Punkt
BS.plSeen = {}
function BS.PLHit(id, note)
    if not id or BS.plSeen[id] then return false end
    if BS.Selftest and BS.Selftest.running then return false end
    local PL = BS.PL
    if not PL or not PL.Hit then return false end
    BS.plSeen[id] = true
    local ok, r = pcall(PL.Hit, PL, id, note)
    return ok and r or false
end

-- Slash-Befehl (nur Entwickler; die Prüfung macht der Befehl selbst über GoldSentinelDev:Require)
function BS:OpenPruefliste()
    if not (GoldSentinelDev and GoldSentinelDev:Require("BuffSentinel")) then return false end
    local PL = self:SetupPruefliste()
    if PL and PL.Open then return PL:Open() end
    return false
end

-- Zeilen für Testbericht und Protokoll (leer ohne Entwicklermodus)
function BS:PrueflisteLines()
    local PL = self.PL
    if not PL or not PL.ReportLines then return {} end
    local ok, lines = pcall(PL.ReportLines, PL)
    return ok and type(lines) == "table" and lines or {}
end
