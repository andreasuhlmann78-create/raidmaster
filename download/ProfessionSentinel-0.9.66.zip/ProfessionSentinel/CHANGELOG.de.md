# ProfessionSentinel – Änderungen

## 0.9.66
- Für den Entwickler: Die Zusammenfassung von `/ps testroutine alles` nennt auch den Start (Sicherung der gespeicherten Daten) und den Rückbau am Ende mit ihrer Dauer – beide hängen von der Datenmenge im Spiel ab

- **Ein fehlerhaftes AHSentinel bremst nicht mehr:** Wirft eine Funktion eines anderen Addons zehnmal hintereinander einen Fehler, fragt ProfessionSentinel sie 30 Sekunden nicht mehr und rechnet so weiter wie ohne das Addon. Vorher kostete jede Ansicht mit tausenden fehlerhaften Preisabfragen spürbar Zeit
- Gemeinsame Marktdaten: Test-Item-IDs werden nie gespeichert oder geteilt und beim Laden entfernt
- Gemeinsame Marktdaten: kein Ruckeln mehr nach einem Vollscan (Arbeit auf mehrere Bilder verteilt)
- Für den Entwickler (Befund PS-RUN-1): `/ps testroutine alles` friert das Spiel nicht mehr ein. Keine ganze Speicherbereinigung am Stück mehr (vorher 31 je Lauf, jede im Spiel Sekunden), sie läuft in Portionen von höchstens 4 ms mit Zeitlimit. Schwere Prüfungen sind in Schritte zu je einem Bild geteilt, das Fenster baut auch im Test in Portionen. Die Zusammenfassung nennt jeden Schritt über 16 ms mit Namen. Ein Fehler im Abschluss lässt keinen Lauf hängen
- Test T289 neu

- Für den Entwickler: Prüfliste im Spiel genauer – jeder Schritt genau EIN Handgriff, „Was du siehst“ wörtlich wie im Spiel (Testroutine, Minimap-Knopf), jede Anweisung passt ins Fenster; Test T285 prüft das jetzt mit

- **Mehr Lehrer und Händler mit Ort:** Die Rezeptdaten lesen die Zonen jetzt richtig aus QuestieDB. Bisher fielen NPCs weg, deren Ort eine Korrektur von Questie setzt – jetzt sind sie da: in WoW Forever 30 Lehrer mehr (262 statt 232) (z. B. der Schmiede-Lehrer in Tirisfal und die Lehrer der Startgebiete), 47 statt 116 NPCs ohne Koordinaten; in Classic Era 5 statt 51
- **„AHS-Liste“ im Rezept-Detail:** Mit AHSentinel legt ein Klick die Materialien des gewählten Rezepts als Einkaufsliste in AHSentinel an (Rechtsklick: nur was dir fehlt). Ersetzt die Knöpfe des AHSentinel-Fensters, das neben ProfessionSentinel ausgeblendet ist
- Für den Entwickler: Prüfliste im Spiel (`/ps prüfliste`) mit genauen Schritten je Punkt, die sich selbst abhakt; `/ps testroutine alles` endet mit EINER Zusammenfassung (bestanden, nicht prüfbar mit Grund, langsame Schritte) und bricht beim Abmelden sauber ab; `/ps warnprobe` zeigt die Verlust-Warnung als Probe
- Gemeinsame Datei GoldSentinelDev Version 2 (Figuren nur noch als Prüfsumme)
- Tests T285–T288 neu

- **„Heute herstellen“ ohne überflutete Produkte:** Ist der Markt eines Produkts überflutet, fehlt es in „Heute herstellen“, auf der Karte „Jetzt“ und in „Heute tun“ von AHSentinel – die Liste sagt dasselbe wie der Tooltip („jetzt nicht herstellen“). Antwort der Prüf-Sitzung 01:18
- Test T284 neu

Marktlage im Rezept-Tooltip (Ausbau B5):
- **Markt überflutet:** Liegen beim Produkt viel mehr Angebote im AH als gestern und ist der Preis gefallen (Messung von AHSentinel), steht im Tooltip „Markt überflutet … jetzt nicht herstellen“
- **Richtung der Stufe:** Fallen, steigen oder stehen die Preise der Stufe des Produkts an der Spitze (Stufenband von AHSentinel), sagt eine Zeile, was zu tun ist – z. B. „nur herstellen, was du gleich verkaufst“
- Immer höchstens eine Zeile; bei ruhigem Markt keine
- Test T283 neu

Warnschutz fürs Herstellen (Ausbau B4, wie der Warnschutz von AHSentinel beim Einstellen):
- **Warnung vor Verlust:** Bevor ProfessionSentinel ein Gold-Rezept herstellt („Heute herstellen“, Karte „Jetzt“, „Heute tun“ in AHSentinel), wird der Preis neu gerechnet. Bringt der Verkauf nach AH-Gebühr weniger als das Material kostet, kommt zuerst eine Warnung mit Ton: Material, Erlös, Verlust je Herstellung und gesamt
- **Trotzdem herstellen** stellt sofort her – ohne zweite Frage und ohne Sperre
- **Stattdessen: <Rezept>** schlägt das beste andere Rezept vor, das dieselbe Prüfung jetzt besteht – der Vorschlag löst die Warnung nie wieder aus. Bringt alles Verlust, gibt es keinen Vorschlag
- Herstellen zum Skillen wird nie gefragt
- Test T282 neu

Korrektur Verkaufschance (Befund PS58-1 der Prüf-Sitzung):
- **Die Verkaufschance kommt jetzt aus dem richtigen Wert:** AHSentinel liefert sie als 4. Wert von „Lohnt bis“ (0–100 %, leer = lernt noch). 0.9.58 las den 3. Wert („sicher“/„unsicher“) und zeigte darum oft 100 % statt der gelernten Quote
- Ältere AHSentinel-Versionen mit nur 3 Werten: „sicher“ zählt wie bisher als 100 %
- Alle Rückgabewerte fremder Addons kommen vollständig an, auch hinter einem leeren Wert
- Test T281 erweitert (echte Reihenfolge, lernt noch, alte AHSentinel-Version)

## 0.9.58
Gelernte Verkaufschance aus AHSentinel (Ausbau B2):
- **Die Gold-Liste ordnet nach dem erwarteten Gewinn:** Gewinn je Herstellung × Verkaufschance, die AHSentinel aus echten Verkäufen gelernt hat. Ein Rezept mit +1g, das sich nur zu 40 % verkauft, steht hinter einem mit +60s, das sich immer verkauft
- **Tooltip:** „Erwartet (verkauft sich zu 77 %): +x“; die Zahl in der Zeile bleibt der Gewinn je Herstellung
- **„lernt noch“:** Kennt AHSentinel die Verkaufschance eines Produkts noch nicht, steht das als Wort in der Zeile; der Gewinn ist dann nicht gewichtet
- Test T281 neu; T255 prüft die neue Reihenfolge

## 0.9.57
Weg zeigen mit LevelPilot:
- **„Weg zeigen“ (nächster Lehrer, Lernort eines Rezepts) nutzt zuerst LevelPilot**, wenn es geladen ist – Navigation mit Pfeil bis zum Ziel. Sonst wie bisher TomTom, Kartenpin oder Chat
- Ein Fehler in LevelPilot blockiert nichts: er wird gezählt, dann übernimmt TomTom bzw. die Karte
- Test T280 neu

## 0.9.56
Skillen: „Billigst“ oder „Mit Vorrat“ (Antwort der Prüf-Sitzung 23:48):
- **Plan mit dem, was du hast:** Neue Ansicht „Mit Vorrat“ im Reiter Skillen – Material in Taschen und Bank wird zuerst verbraucht (kostet nichts), der Rest zum Marktpreis. Ein Rezept wird nur so lange bevorzugt, wie sein Material reicht; danach geht der Plan auf den billigsten Weg zurück
- Ohne Vorrat ist der Plan genau der „Billigst“-Plan (geprüft)
- Der Umschalter im Reiter Skillen: Billigst · Mit Vorrat · Rangliste · Lehrer
- Test T279 neu (mit Gegenprobe)

## 0.9.55
Nachprüfung 0.9.54 (Hinweise PS54-1/2) und Texte (Schritt 5 der UI-Überarbeitung 2):
- **Skillspur misst je Figur:** Die gemessene Chance gehört jetzt der Figur (z. B. unterschiedliche Ränge von „Working Overtime“ in WoW Forever werden nicht mehr vermischt); der Tooltip sagt „… Herstellungen dieser Figur“
- **„Alle herstellen“ zählt richtig:** Bei mehreren Herstellungen kurz hintereinander zählt jede genau einmal, und ein Punkt gehört genau zu der Herstellung, nach der er kam
- **Klare Wörter:** „Gewinn je Herstellung“ statt „Netto“, „zu wenig Angebote“ statt „Leiter zu kurz“; die Erklärung des Reiters Gold ist kürzer
- Tests T240 (beide Hinweise, mit Gegenprobe) und T278 (keine Fachwörter, Sätze ≤ 20 Wörter) neu

## 0.9.54
Skillspur im Handwerksbuch (Schritt 4 der UI-Überarbeitung 2):
- **Feine Linie unter jedem Rezept** im Blizzard-Berufsfenster: Abschnitte Orange/Gelb/Grün/Grau im Verhältnis der Stufen dieses Rezepts, der aktuelle Abschnitt kräftig, die anderen nur angedeutet; ein feiner weisser Strich zeigt deine Fertigkeit und wandert nach jedem Punkt mit
- **Rechts EINE kleine Zahl:** bei Orange die sicheren Punkte bis Gelb („5“), bei Gelb/Grün die Chance auf den nächsten Punkt („70 %“), bei Grau nichts – keine „≈6×“ und „20×“ mehr
- **Gemessene Chance:** Jede eigene Herstellung wird gezählt (Farbe, Abstand zu Grau, Punkt ja/nein – nur Zahlen). Ab 30 Fällen je Band zeigt die Skillspur die gemessene Chance statt der Schätzung; der Tooltip sagt, welche gilt
- **Tooltip** einer Zeile: die Stufen (gelb ab, grün ab, grau ab), sichere Punkte bzw. Chance mit Herkunft, ein Satz zur Rechnung
- Die Zeile „Bestes: …“ unter dem Berufsfenster entfällt – dafür gibt es den Reiter „Jetzt“
- Einstellung heisst jetzt „Skillspur im Handwerksbuch“ (Standard an, `/ps line`)
- Tests T239–T240 neu gefasst (Skillspur, Messung mit Gegenprobe)

## 0.9.53
Nachprüfung 0.9.52 (Befund PS52-1, Gold-Sicherheit):
- **Sniper kauft höchstens 1,25 × Marktpreis:** Bei sehr gewinnbringenden Rezepten lag der „Kauf bis“-Preis teils beim Mehrfachen des Marktpreises – der Sniper hätte so teuer gekauft, obwohl das Material gleichzeitig günstiger zu haben war (und der Verkaufspreis ist selbst nur geschätzt). Die Einkaufsliste zeigt jetzt beides: „lohnt bis X, Sniper kauft bis Y“
- Test T277 prüft Faktor 3 (Sniper = 1,25 × Markt) und die Gegenprobe ohne Gewinn (+10 %)

## 0.9.52
Einkauf-Leiste mit Warteschlange (Schritt 3 der UI-Überarbeitung 2):
- **Warteschlange:** Rezepte mit Anzahl vormerken – in den Details („Vormerken“) oder mit Rechtsklick auf eine Karte im Reiter „Jetzt“. Die Warteschlange bleibt nach dem Ausloggen erhalten und zählt beim Herstellen von selbst herunter
- **Leiste unten im Fenster:** „Warteschlange 3 · fehlt: 12× Leinenstoff, 4× Grober Faden“ – ein Klick öffnet die Warteschlange und EINE Einkaufsliste für alle vorgemerkten Rezepte (Taschen und Bank gezählt, selbst günstiger herstellbare Zwischenprodukte aufgelöst)
- **Kaufen nur per Klick:** „Fehlendes beim Händler kaufen“ am offenen Händler; „Fehlendes aus dem AH in den Sniper“ mit einem „Kauf bis“-Preis je Material – der höchste Preis, bei dem das Rezept noch deinen Mindestgewinn bringt. Darüber kauft der Sniper nie
- Test T277 neu; T118 besteht jetzt auch im Schnelltest (Liste gekürzt)

## 0.9.51
Neues Fenster, Teil 4 (Schritt 2 der UI-Überarbeitung 2):
- **Reiter Gold ist eine Liste:** Für Verzauberer stehen Ziel, Sniper-Knöpfe, Schnäppchen zum Entzaubern, „Herstellen zum Entzaubern“ und die Entzauber-Chancen jetzt als Abschnitt unten in der Gold-Liste – keine eigene Ansicht und kein Umschalter mehr. Ein gespeicherter Reiter „Verzauberer“ öffnet die Gold-Liste
- Test T80 prüft den Abschnitt (mit und ohne Verzauberkunst)

## 0.9.50
Neues Fenster, Teil 3 (Schritt 2 der UI-Überarbeitung 2): eine Zahl je Zeile
- **Rezepte:** rechts die Fertigkeitsstufe in der Farbe deiner Fertigkeit, daneben die Quelle als kleines Symbol (Lehrer, Händler, Händlergunst, Drop, Quest). Den Gewinn findest du im Reiter Gold, in den Details und im Tooltip
- **Skillen:** im Plan rechts nur noch „6×“ (wie oft herstellen); der Bereich „von–bis“ steht im Tooltip. Die feine Lebenslinie gibt es nur noch hier
- **Gold:** rechts der Gewinn je Herstellung mit dem Weg; „verkauft sich in 2 Tagen höchstens n“ steht im Tooltip, „kaum Absatz“ bleibt als Wort
- Keine Platz-Nummern und keine Sterne mehr vor den Namen (der Stern bleibt an einer Stelle: in der Blizzard-Liste)
- Test T276 neu

## 0.9.49
Neues Fenster, Teil 2 (Schritt 2 der UI-Überarbeitung 2):
- **Nächster Lehrer nach Entfernung:** Kurz vor oder an der Fertigkeitsgrenze zeigen der Reiter „Jetzt“ und der Plan den nächsten passenden Lehrer deiner Fraktion mit Entfernung („~300 Yards, Orgrimmar“); ein Klick zeigt den Weg (TomTom, Kartenpin oder Chat). Ohne Position (z. B. in einer Instanz) zuerst eine Hauptstadt deiner Fraktion
- **Stufe zu niedrig?** Dann steht dort „Experte ab Stufe 20 (du: 18)“ statt eines Wegs
- **Liste der Lehrer** nach Entfernung sortiert (freundliche zuerst), mit Entfernung je Lehrer und dem nächsten Lehrer in der Zusammenfassung; in Retail ein ehrlicher Satz statt einer leeren Liste
- **Beruf wechseln ohne alten Inhalt:** Beim Wechsel (z. B. Schneiderei → Kochen) erscheinen sofort der richtige Beruf, sein Reiter und sein zuletzt gezeigter Inhalt; die frischen Zahlen kommen danach in kleinen Portionen
- Tests T274–T275 neu; T271 und T274 laufen jetzt in jeder Testroutine (vorher nur mit `/ps testroutine api`)

## 0.9.48
Nachprüfung 0.9.47 (Befund PS47-1):
- **Gewinn-Fenster von AHSentinel kommt wieder, wenn du das Öffnen abschaltest:** AHSentinel fragt den Schalter „Mit dem Berufsfenster öffnen“ an einer anderen Stelle ab – ProfessionSentinel beantwortet die Frage jetzt dort auch. Vorher blieb mit `/ps auto` aus am Berufsfenster gar keine Gewinnliste
- Test T273 prüft beide Wege (mit Nachbildung der Abfrage von AHSentinel); Test T80 heisst jetzt „vier Reiter“

## 0.9.47
Neues Fenster, Teil 1 (Schritt 2 der UI-Überarbeitung 2):
- **Vier Reiter, eine Frage je Reiter:** „Jetzt“ (was mache ich jetzt?), „Skillen“, „Gold“, „Rezepte“. Echte Reiter mit Akzentlinie statt grauer Knöpfe; die Ansichten eines Reiters (z. B. Plan / Rangliste / Lehrer) sind ein kleiner Umschalter darunter. Keine Ansicht und kein Befehl fällt weg
- **Reiter „Jetzt“ (Startseite):** höchstens drei Karten mit je einer Zahl und einem Klick – nächster Skillpunkt („6×“ bis Gelb, Material da oder was fehlt), bestes Gold-Rezept jetzt (Gewinn je Herstellung, dieselbe Zahl wie im Reiter Gold), ein Rezept im AH für eine deiner Figuren (der günstigste Einzelfall statt „340 Rezepte“). Dazu eine Karte kurz vor und an der Fertigkeitsgrenze (75/150/225) und die Abklingzeiten als kleine Zeile
- **Öffnet sich mit dem Berufsfenster** und schliesst sich mit ihm (Einstellung „Mit dem Berufsfenster öffnen“, Standard an, `/ps auto`). Der Knopf am Berufsfenster heisst jetzt „ProfessionSentinel“ und bringt das Fenster immer zurück
- **Jeder Beruf merkt sich seinen Reiter** (z. B. Kochen → Skillen, Schneiderei → Gold); die Kopfzeile zeigt Beruf und Fertigkeit („Schneiderei 110/150“)
- **Dunkler Stil** wie AHSentinel (Standard), der klassische Blizzard-Stil bleibt als Einstellung (`/ps stil`)
- **Rezepte:** ein Umschalter Alle / Gelernt / Lernbar / Fehlt (in WoW Forever dazu „Händlergunst“); der alte Haken „Nur fehlende“ ist weg – er wirkte schon nicht mehr, der Filter „Fehlt“ zeigt genau das
- Überall „Händlergunst“ statt nur „Gunst“
- Für AHSentinel: `ProfessionSentinelAPI.IsEnabled()` – false, wenn du das Öffnen mit dem Berufsfenster abgeschaltet hast (dann zeigt AHSentinel sein Gewinn-Fenster wieder)
- Der Skillplan rechnet auch als Hintergrund-Aufgabe in Portionen (unter Lua 5.1 vorher 18–21 ms am Stück)
- Tests T272–T273 neu, T118 prüft die vier Reiter

## 0.9.46
Kein Ruckeln mehr durch ProfessionSentinel (Schritt 1 der UI-Überarbeitung 2: PS-TC1, A1–A4):
- **Schwere Rechnungen laufen im Hintergrund in kleinen Portionen** (höchstens 6 ms je Bild): der Rezept-Alarm nach einem AH-Scan, „Heute herstellen“ und die Rezeptliste für AHSentinel. Im Spiel wurden vorher bis 921 ms in einem Bild gemessen
- **„Heute herstellen“ für AHSentinel aus dem Zwischenspeicher:** ein Aufruf dauert höchstens 2 ms (vorher 153 ms am Stück); neu berechnet wird nach Scan, Rezept- oder Preisänderung im Hintergrund, bis dahin gilt die letzte Liste
- **Rücksicht auf den Sniper:** solange der Sniper von AHSentinel im Ruhemodus läuft, warten diese Rechnungen (höchstens 30 Minuten)
- **Item-Infos nach einem Vollscan:** nur selbst angefragte Gegenstände zählen, gesammelt höchstens alle 5 Sekunden ein Neuzeichnen (vorher jede Sekunde ein ganzer Neuaufbau)
- **Neue Schnittstelle für AHSentinel:** `ProfessionSentinelAPI.KnownRecipes()` – die gelernten Rezepte der Figur (und gemerkter Twinks) mit Produkt, Zutaten, Fertigkeit und Farbe, ohne Namen
- **Klick auf „Entzaubern“ von AHSentinel geht wieder:** die Zeile „Bestes:“ unter dem Berufsfenster ist nur noch so breit wie ihr Text
- **Messung je Weg:** `/ps protokoll` und der Testbericht zeigen die langsamsten Wege dieser Sitzung (rot über 16 ms) und die Hintergrund-Aufgaben; der Testbericht zeigt, welche TOC-Datei das Spiel geladen hat
- Gemeinsame Datei GoldSentinelMarkt.lua auf Version 7 (weniger Speicher beim Weitergeben eines Scans)
- Tests T268–T271 neu, T143 misst die Portionen, T266 verlangt Version 7; der Schnelltest vergleicht seine Fehler mit einer festen Liste

## 0.9.45
Nachprüfung 0.9.44:
- Gemeinsame Datei GoldSentinelMarkt.lua aktualisiert (Version 2: ist AHSentinel geladen, liest sie nichts selbst – AHSentinel gibt seinen Scan weiter, kein doppeltes Lesen, kein Ruckeln; kleinere Warteschlange)
- An/Aus-Meldungen (/ps markt, alarm, line, kisten, menge) in der Sprache des Spiels („an/aus“ bzw. „on/off“)
- Schnittstelle für AHSentinel (Herstellungs-Kette): „Heute herstellen“ meldet je Eintrag „gesichert“, Materialien mit Mengen, Beruf, Abklingzeit. Nicht gesicherte Einträge erscheinen nirgends; im Testbericht stehen sie mit Ursache
- Tests T266 (aktuelle Kopie), neu T267

## 0.9.44
Marktdaten-Netz (Auftrag MN1–MN4):
- **Marktdaten teilen:** ProfessionSentinel bringt die gemeinsame Datei GoldSentinelMarkt.lua (Version 1) mit. Sie liest jeden Vollscan im Auktionshaus mit, den irgendein Addon macht (sie löst selbst nie einen Scan aus), speichert je Item den tiefsten Preis, Menge und gemessenen Absatz – ohne Namen – und teilt die Preise mit anderen GoldSentinel-Nutzern, wenn ein Addon mit GoldSentinelSync geladen ist (z. B. AHSentinel). Keine Abfrage, Standard an
- Neuer Schalter **„Marktdaten teilen (anonym, nur Preise)“** in den Optionen (Rechtsklick auf den Minimap-Button) und `/ps markt`
- Testbericht mit der Zeile „MARKT-NETZ: Version, an/aus, mitgelesene Scans, gesendet/empfangen, Speicher“; neuer Test T266
- Testroutine: „Addon nicht geladen“ während eines Tests wirkt jetzt wirklich (Ersatzwert false statt nil)

## 0.9.43
Nachprüfung 0.9.42, Punkt 5:
- **Tests ersetzen andere Addons nicht mehr:** AHSentinel, auxForever, Auctionator, Auctioneer, TSM, Enchantrix, TomTom und RaidMaster werden nur noch über eine eigene Nahtstelle gelesen (`ns.Foreign`). Testroutine und Testmodus legen ihre Ersatzwerte in eine eigene Tabelle – das echte AHSentinel, seine API und andere Abonnenten sehen während eines Tests nie Testwerte. Die Testroutine verweigert jeden Versuch, ein fremdes Addon oder dessen API zu ersetzen (neuer Test T265)
- Befehlsliste über dem Chat (BL3/BL4): wartet auf die Antwort, wie der Baustein CmdHint bereitgestellt wird (shared/ oder Kopie) – die Datei in AHSentinel ist an AHSentinel gebunden und lässt sich nicht unverändert übernehmen

## 0.9.42
Antworten der Prüf-Sitzung (F1–F6) und Befehlsliste, Teil 1 (Auftrag BL):
- **Hohe Margen sind echt (F1):** Über 300 % Gewinn allein zeigt jetzt die Zahl, gelb mit „sehr hohe Marge – Absatz prüfen“ (z. B. Rippchen vom tobenden Raptor 361 %). Grau „Daten prüfen“ nur mit einem zweiten Zeichen: dünner Markt, alter Preis, Aufkauf oder eine Zutat, deren Leiter die nötige Menge nicht hat
- **AHSentinel „Lohnt bis“ (F2):** wird als Stückpreis gelesen (gefragt für 1 Stück); die Sicherheit (0–1 oder „unsicher“) unter 60 % zeigt „unsicher“
- **Trend „ruhig“ (F3)** gibt keinen Band-Hinweis
- **Raid-Bedarf (F4):** Der Filter im Reiter „Gold“ heisst „Nur Raid-Bedarf“ (Essen, Tränke, Fläschchen) und bleibt auch nach dem Raidstart; der Hinweis „Raidstart 9.12.“ steht nur bis dahin (WoW Forever). In allen Classic-Versionen
- **Befehle aus einer Tabelle (BL1/BL2):** Alle /ps-Befehle stehen jetzt in EINER Tabelle, aus der der Befehl ausgeführt wird und aus der die Liste beim Tippen kommt (deutsche und englische Wörter, Zusatz wie „an|aus|bericht“, Entwickler-Befehle nur für den Entwickler, meistbenutzte oben). Eine frisch gewählte Zeile (≤ 10 s) wird mit Enter statt des angefangenen Worts ausgeführt. Das Fenster über dem Chat kommt mit dem gemeinsamen Baustein (AHSentinel CmdHint, sobald CH dort fertig ist)
- Neu: `/ps hilfe` (auch `help`, `?`)
- Tests: T247/T249/T257 für F1, T251 für F3/F4, neu T262–T264 (T-BL1/2/3/5/6)

## 0.9.41
Marktwissen für Herstellen und Gold-Rangliste (Auftrag PM1–PM7, 13. Nov.) und umfassende Tests (TU1–TU9):
- **Beide Richtungen (PM1):** Je Rezept „Herstellen lohnt +x“ oder „Zutat lieber roh verkaufen +y“ (die Zutaten nach 5 % im AH gegen das Produkt). Rezepte mit Verlust, deren Zutaten du in den Taschen hast, stehen im Reiter „Gold“ in der eigenen Gruppe „Zutaten lieber roh verkaufen“ statt zu verschwinden. Tooltip und Details zeigen die Richtung
- **Echte Marktpreise (PM2):** AH-Zutaten über die Preisleiter für die benötigte Menge (so viele Herstellungen, wie der Markt in etwa 2 Tagen nimmt, höchstens 20), nicht das günstigste Einzelstück; ist der Händler billiger als die Leiter, der Händler. Produkt wie bisher nach 5 % und Einzahlungsrisiko, Menge Mittel aus min/max. Rezepte mit Abklingzeit (Transmutieren, Mondstoff, Salz) rechnen „je Abklingzeit“
- **Kein Schein-Gewinn mehr (PM3):** Preise älter als 6 Std., Aufkauf (ganze Leiter über 150 % des Marktwerts), dünner Markt (unter 5 Angebote) oder über 300 % Gewinn -> keine Zahl, sondern grau „Daten prüfen“ / „Aufkauf“ / „dünner Markt“ – im Tooltip, in den Details, in der Gold-Rangliste (eigene Gruppe „Daten prüfen“) und in „Heute herstellen“. Ohne Preise bleibt die Rangliste nach Stufe wie bisher
- **Eine Zahl mit AHSentinel (PM4):** Ist AHSentinel geladen, kommen die Herstellkosten aus API.MaterialCost für das Produkt (seine Leiter), der Verkauf aus API.NetSale, und sobald AHSentinel sie hat aus API.WorthUpTo („Lohnt bis“) und API.MarketState (Aufkauf/Flut/dünn/alt, Trend). Ohne AHSentinel dieselben Regeln selbst
- **Levelwelle (PM5):** Hinweis oben im Reiter „Gold“, wenn die Ware eines Stufenbands (1–25, 26–45, 46–60) fällt, steigt oder an der Spitze ist (nur Richtung). In WoW Forever bis zum Raidstart am 9.12. ein Filter „Nur Raid-Essen und -Tränke“
- **Nachprüfung (PM6):** „Herstellen lohnt“ wird beim Herstellen mit erwartetem Erlös gemerkt; eine Verkaufs-Rechnung in der Post (nur gelesen, Forever-Feldlage: Gesamt und Menge) zählt als Treffer, nach 7 Tagen ohne Verkauf als Fehlschlag. Ab 20 Fällen unter 60 % Treffern steht „unsicher“ neben der Zahl. Trefferquote je Beruf im Testbericht
- **Klick auf eine Top-Zeile im Reiter „Rezepte“** öffnet die Details – so gewollt (Nachprüfung 0.9.39, Punkt 1); T243 prüft es
- **Umfassende Tests (TU1–TU9):** neue Bereiche M (Markt, T247–T253 mit den gemessenen Zahlen: Eberfleisch −1s 18c roh, Raptor-Rippchen 5s 86c -> 26s 99c, Leiter für 20 Zutaten, Aufkauf/dünn/alt/über 300 %, gleiche Zahl mit und ohne AHSentinel, Band fällt, Treffer zählen, Abklingzeit) und U (T254 Lagen-Katalog, T255 Abläufe wie ein Spieler, T256 Standardwerte, T257 1000 Zufallsfälle mit festem Startwert, T258 echte Daten, T259 Regressionen, T260 Spielversionen/geheime Werte/Sprachen/Skalierung), T261 Diagnose Höchstwert je Version. Der Testbericht hat je Bereich TU1–TU7 eine Zeile „OK · FEHLER · SKIP“ und „Regressionen: n von m vorhanden“. Nach jedem AH-Scan prüft das Addon still seine Grundregeln auf den echten Daten (Diagnose „GRUNDREGEL VERLETZT“)

## 0.9.40
Rezeptdaten aktualisiert (WoW-Forever-Client 1.60.1.70938, QuestieDB 90ab55b 2026-11-12):
- **WoW Forever – Lager-Rezepte („Lager aufschlagen“):** 25 Lagerteile werden jetzt gleich bei der Stufe grau, auf der man sie lernt (z. B. Lagerzelt, Amboss, Gewächshaus bei 140; Lagerfeuer des Gesellen 95, Expertenlagerfeuer 205); der **Gerbrahmen** (Lederverarbeitung) ist jetzt schon ab 125 statt 140 lernbar
- **WoW Forever – Schneider-Taschen brauchen mehr Stoff:** Grüne und Rote Wolltasche 5 Wollstoff (bisher 4), Grünes Seidenpack 5 und Schwarzes Seidenpack 6 Seidenstoff, Rote Magiestofftasche 5 Magiestoff – Gewinn und Einkaufslisten rechnen automatisch damit
- **WoW Forever – Schmiedekunst:** Grober Schleifstein bleibt länger grün (grün 70, grau 90 statt 62/75)
- Keine neuen Rezepte, Händler, Drops oder Lehrer; Classic Era (1.15.9.70576) und Retail (12.1.5.70783) unverändert

## 0.9.39
Nachprüfung von 0.9.38 (11. Nov.):
- **Schnellerer Neuaufbau (Punkt 1):** Auch Klick, Reiter, Suche und Einstellungen zeichnen jetzt in Portionen (die erste Portion sofort im selben Frame – meist schon die ganze Arbeit –, der Rest in den nächsten Frames, je etwa 10 ms Arbeit); Ranglisten und Plan geben zwischen den Rezepten ab (AD.Ranking, AD.GoldRanking, Plan); der Plan im Reiter „Skillen“ bleibt gespeichert, bis sich Fertigkeit, Ziel, gelernte Rezepte oder Preise ändern, und schaut nur noch die Rezepte an, die einen Punkt geben können (lernbar und noch nicht grau) – der Plan 1 -> 300 ist etwa doppelt so schnell; „Danach orange“ nimmt die schon gerechneten Werte. Neuer Testfall **T246** (Bereich H): 300 Rezepte, Reiter „Skillen“ und ein Klick – jede Portion unter 16 ms, Plan aus dem Zwischenspeicher
- **GoldSentinelTest 2 (Punkt 2):** Fehlerberichte an den Entwickler teilen (nur mit Zustimmung, /gstest). Testfall **T245** (T-GT1 Version 2, T-GT2 ohne Zustimmung nichts im Ausgang)
- **Details nur im Reiter „Rezepte“ (Punkt 3):** Ein Klick in den Reitern „Gold“ und „Skillen“ öffnet sie nicht mehr (T243 ergänzt). Gelernte Zeilen haben bewusst kein Kennzeichen (sie sind blasser; der Filter „Gelernt“ zeigt sie)
- Diagnose-Protokoll: Die Portionen eines Aufbaus sind ein Eintrag „UI:Aufbau (Teil)“

## 0.9.38
Rezeptdaten aktualisiert (WoW-Forever-Client 1.60.1.70888, Retail 12.1.5.70783, QuestieDB e19dfdf 2026-11-11):
- **WoW Forever:** 104 Rezepte mehr mit bekannter Quelle (2211 -> 2315) – Lederverarbeitung 36, Schmiedekunst 27, Schneiderei 20, Verzauberkunst 9, Ingenieurskunst 6, Alchemie 4, Kochkunst 2 (z. B. Goldener Schuppenkürass, Brustplatte des scharlachroten Soldaten, Hyperleitender Arkanfaden, Elixier der verschmolzenen Reue)
- 151 Rezepte mit bisher unbekannter Quelle zeigen jetzt, woher sie kommen: 49 neue Händler und 110 neue Drop-Quellen (z. B. Rüstung des scharlachroten Soldaten, Goldene Schuppenteile, Schlaue Schlammpackung)
- Kochlehrer-Liste in WoW Forever bereinigt (ein Eintrag entfernt); Fertigkeitsstufen unverändert
- Classic Era und Retail: keine Rezeptänderungen

## 0.9.37
UI-Rework, Teil B – der Rest (Nachprüfung von 0.9.36):
- **Blizzard-Berufsfenster (U6):** je Rezeptzeile nur noch EIN kurzes Zeichen am rechten Rand – die Anzahl bis zur nächsten Farbe („19×“) in dieser Farbe, in der Schrift der Zeile; bei Grau nichts. Kein grauer Text und keine Balken unter dem Namen mehr. Das Zeichen erscheint nur, wo es weder Name noch Anzahl („[38]“) berührt, sonst nichts. Era/TBC (TradeSkillFrame, CraftFrame) und das moderne Berufsfenster. Unten eine kurze Zeile „Bestes: <Rezept>“ (hell, mit „…“ gekürzt erst ab Fensterbreite)
- **Details im Reiter „Rezepte“ (U2):** Ein Klick auf eine Zeile zeigt unter der Liste: Materialien mit Herkunft, Bestand und Preis, Verkauf netto, Gewinn je Herstellung mit bestem Weg, Absatz, woher das Rezept kommt, Knöpfe „Herstellen“ und „Einkaufsliste“ (Händlerware beim offenen Händler, AH-Zutaten in AHSentinels Sniper). Dieselben Zahlen wie Tooltip und Gold-Rangliste
- **Eine Zahl je Zeile (U3):** Reiter „Rezepte“ Farbpunkt, Name, Status (lernbar / fehlt) und der Gewinn mit „verk.“ / „ent.“; Reiter „Skillen“ das Material pro Skillpunkt
- **Reiter „Skillen“ (U4):** oben „Nächster Schritt: 112 -> 125“ mit Rezept und Anzahl, kurz vor dem Umschlag auf Gelb (≤ 2 Herstellungen) schon das nächste orange Rezept, und wo ein fehlendes Rezept zu lernen ist (Klick: Wegpunkt); auch der Plan ohne Preise bevorzugt Orange
- **Keine langen Chat-Ausgaben (U8):** Der Rezept-Alarm schreibt höchstens eine kurze Zeile je Sitzung; die Liste steht im Reiter „Rezepte“, die Zahl am Reiter
- Testfälle T239 (T-UI5), T240 (T-UI6 „Bestes:“), T241 (T-UI9), T242 (Bereich K: Zeichen nie über Name/Anzahl), T243 (T-UI8), T244 (nächster Schritt / nächstes Orange); T67 angepasst

## 0.9.36
UI-Rework, Teil B – Tooltip Variante A (Entscheid vom 9. Nov. 17:55, wie der AHSentinel-Tooltip):
- **Ohne Shift drei Blöcke:** Kopf (Name, „Platz · gelernt/lernbar/fehlt“, Skillfarbe als Punkt mit der Anzahl bis zur nächsten Farbe, z. B. „grün ≈13×“); Urteil („Herstellen lohnt sich“ / „lohnt nicht“ / „unsicher“ mit dem EINEN Gewinn je Herstellung – dieselbe Funktion wie Gold-Rangliste und Panel –, dann Verkaufen / Entzaubern mit dem besseren Weg zuerst, Händler, Skillen als Material pro Punkt); Materialien (Summe, je Zutat eine Zeile mit Herkunft „AH“ / „Händler“ / „aus Leinenstoff“, Preis je Herstellung und Bestand „2/1“)
- **Mit Shift:** die ganze Rechnung (Kosten, Verkauf, 5 % Anteil, Einzahlungsrisiko, Händler, Entzaubern), Fertigkeitsstufen und Chance bei der aktuellen Farbe, Quellen, Gilde, Preisquelle; Shift drücken oder loslassen zeichnet den Tooltip neu
- **Aus dem Tooltip entfernt:** Ranglistenplätze und Erklärtexte (stehen im Panel) – das Wollcape zeigt nicht mehr drei verschiedene Zahlen für dasselbe
- **Muster-Tooltips:** „Muster · fehlt / lernbar ab …“ und das Urteil des hergestellten Items; Gunstkosten, Gilde und Charaktere mit Shift
- Testfälle **T236–T238** (T-TT1 ohne Shift, T-TT2 mit Shift, T-TT3 gleicher Gewinn wie die Rangliste), T75 (T-TT4 Muster), T122/T153/T168 angepasst (Quellen und Gunstkosten jetzt mit Shift)

## 0.9.35
Nachprüfung von 0.9.33 (9. Nov., 17:30):
- **Händlerpreis ist kein AH-Preis:** Kennt AHSentinel.API.Price nur den Ankaufpreis des Händlers („vendor“), wird die nächste Quelle gefragt; der Händlerwert kommt nur über VendorSell / VendorBuy (Material war zu billig, Gewinn zu hoch)
- **API.MaterialCost wird nicht mehr für eine Zutat gefragt** (es sind die Kosten, das Item herzustellen): Jede Zutat geht den eigenen günstigsten Weg (AH, Händler, selbst aus bekanntem Rezept) mit den Preisen der Quelle – Leinenstoffballen 25c im AH und 16c selbst -> 16c „aus Leinenstoff“, 10c im AH -> AH
- **Entzaubern im besten Weg nur für Verzauberer, die Gold machen** (auch AHSentinels Werte und Enchantrix; Retail nie) – ein Schneider bekommt „verk.“
- **Einkaufslisten kaufen das Material einer selbst hergestellten Zutat:** Plan, „Heute tun“ und Sammelkauf setzen Leinenstoff auf die Liste, nicht den Ballen; der Ballen steht als „selbst herstellen“
- **„Heute tun“ nach Absatz:** höchstens, was sich in ~2 Tagen verkauft; „kaum“ und unter dem Mindestgewinn fallen weg; in der Gold-Rangliste unter dem Mindestgewinn grau; der Mindestgewinn wird einmal je Rangliste geholt
- **Verzauberer-Dienst:** wieder dein Aufschlag (nicht AHSentinels Mindestgewinn im AH)
- Spieltest S5 vergleicht mit AHSentinels echter Zahl (API.NetSale .cut); der Tooltip zeigt „Verkauf im AH“ nur mit echtem AH-Preis; Diagnose-Protokoll: Höchstwert je Version und letzter Wert; Bereich K: Zeile „Preise: …“ nicht abgeschnitten (T235); `tests/run_offline.py --lua51` läuft mit echtem Lua 5.1
- Testfälle T232–T235, T220/T225/T216 angepasst

## 0.9.34
UI-Rework, Teil A – das Panel (Anweisung der Prüfung vom 9. Nov. 17:05):
- **Drei Reiter, je eine Frage:** „Rezepte“ (Was kann ich, was gibt es? – auch die Händlergunst-Ansicht), „Skillen“ (Ansichten Plan · Rangliste · Lehrer), „Gold“ (Ansichten „Herstellen lohnt“ und „Entzaubern“ für Verzauberer). Jede alte Ansicht bleibt als Ansicht ihres Reiters erreichbar; der Reiter merkt sich die zuletzt benutzte
- **Reiter „Rezepte“ nach Platz wie im Spiel gruppiert:** Kopf, Schultern, Brust, Taille, Beine, Hände, Füsse, Umhang, Handgelenke, Waffen, Schilde, Schmuck, Taschen, Tränke, Elixiere, Fläschchen, Transmutation, Essen, Stoffe und Zwischenprodukte, Gebrauchsgegenstände, Sonstiges – aus Ausrüstungsplatz bzw. Item-Klasse des Ergebnisses (GetItemInfoInstant), nie aus dem Rezeptnamen; Gruppen mit Anzahl auf-/zuklappbar, Zustand gemerkt
- **Filter „Alle · Gelernt · Lernbar · Fehlt“** mit Anzahl (ersetzen das Kästchen „nur fehlend“); Standard Gelernt + Lernbar
- **Skillen: Orange bevorzugt** – Gelb nur vor Orange, wenn es weniger als die Hälfte Material pro Punkt braucht, Grün ebenso gegen Gelb
- **Reiter „Gold“:** Herstellen nach echtem Gewinn (bester Weg, Menge nach Absatz), was sich kaum verkauft oder nichts bringt in einer eigenen, zugeklappten Gruppe, der Weg zum Entzauber-Handel und zu den Schnäppchen; unten „Preise: …“, Gold pro Stunde (nur aus AHSentinel) und „Mindestgewinn 20 %“
- **`ProfessionSentinel.IsPanelShown()`** für AHSentinel: Solange das Panel offen ist, blendet es sein Gewinn-Fenster aus
- Testfälle **T228–T231** (T-UI2 Gruppen, T-UI3 Filter, T-UI4 Orange zuerst, T-UI7 IsPanelShown) und T118 (T-UI1 drei Reiter), T80/T82/T167 an die Reiter angepasst
- Teil B (Zeichen im Berufsfenster, kurze Tooltips, Details beim Anklicken, Chat-Hinweise) folgt

## 0.9.33
Werte aus AHSentinel und anderen AH-Addons, Regelwerk GoldSentinel (Anweisung der Prüfung vom 9. Nov., 16:50):
- **Ein Preis-Vermittler** (neue Datei PriceSource.lua): Alle Werte kommen von einer Stelle, in dieser Reihenfolge – AHSentinel (`AHSentinel.API` Version 1; bis sie veröffentlicht ist seine bestehenden Funktionen RealPrice/RealValue/AuctionFee/CutPct/ListingDeposit), dann **auxForever** (`AuxForeverAPI.GetLatestPrice`), **Auctionator** (`Auctionator.API.v1`), **Auctioneer** (`Auctioneer:Statistics`, Entzauberungswerte von Enchantrix), TSM (Retail), sonst eigene Rechnung. Alle Namen im Code dieser Addons geprüft; fehlt eine Funktion, wird die Quelle weggelassen und „PREISQUELLE <Addon>: Funktion nicht gefunden“ ins Diagnose-Protokoll geschrieben; bei Fehlern kommt die nächste Quelle. Panel und Tooltip zeigen „Preise: AHSentinel“ / „auxForever“ / … / „eigene“
- **Gebühr nach Regelwerk** (im Spiel gemessen): 5 % vom Verkaufspreis beim Verkauf (kein 1s-Minimum mehr); die Einzahlung (Händlerpreis × Menge × 5 % je 2 Std., Forever-Minimum misst AHSentinel, heute 1s) kommt beim Verkauf zurück – es zählt nur der erwartete Verlust Einzahlung × (1 − p)/p. Der Anteil wird abgerundet: passt zu allen drei gemessenen Rechnungen (202 von 4042, 837 von 16744, 313 von 6279). Era/TBC/Retail unverändert
- **Rechenwert = günstigstes Angebot aus dem letzten Scan**, nicht der Median; Verkaufswert netto nach Anteil und Einzahlungsrisiko, mindestens der Händlerwert – keine Gebühr doppelt
- **Günstigster Materialweg:** AH, Händler oder selbst hergestellt aus einem bekannten Rezept (höchstens 2 Stufen, keine Schleifen) – Tooltip „aus Leinenstoff“
- **Bester Weg je Rezept:** Die Gold-Rangliste rechnet mit dem Besseren aus Verkaufen und Entzaubern, gekennzeichnet „verk.“ / „ent.“ wie in AHSentinel
- **Entzauberungswert aus AHSentinel** (`DisenchantValue`), wenn vorhanden; eigener Wert nur ohne
- **Menge nach Absatz:** „≤N“ = was sich in etwa 2 Tagen verkauft (Absatz pro Tag aus AHSentinel); „kaum“ bekommt keine Gewinn-Empfehlung und kommt ans Ende
- **Mindestgewinn aus AHSentinel** (`MinProfitPct`), sonst dein eigener; **Gold pro Stunde beim Herstellen** nur, wenn AHSentinel ihn misst („Herstellen: 1g 20s/Std.“); Abo auf AHSentinels Änderungen (Scan, Buchungen) – Werte neu, gedrosselt
- Testfälle **T220–T227** (T-PS1 bis T-PS9; T-PS4 ist der neue T35), T33/T34/T35/T100/T117/T213/T216 und der alte Selbsttest an die neuen Regeln angepasst

## 0.9.32
Nachprüfung vom 9. Nov., 11:25:
- **Herstellen ruckelt nicht mehr** (Spieltest S7 „3 LANGSAM“, bis 131 ms je hergestelltem Gegenstand): Während du herstellst, werden nur noch die Zähler der sichtbaren Zeilen nachgeführt (Fertigkeit, „N× bis gelb“, Taschen) – kein Neuaufbau der Liste. Eine echte Änderung (Fertigkeitspunkt) baut höchstens einmal je 2 s neu auf, und einmal, wenn das Herstellen endet. Ein solcher Aufbau wird auf mehrere Frames verteilt (etwa 10 ms Arbeit je Frame) und erst fertig angezeigt; Klick, Reiter und Suche bauen weiterhin sofort auf. Schnäppchen und Ausbeute-Chancen im Reiter „Entzaubern“ (rechnet AHSentinel über den ganzen Scan) werden 30 s zwischengespeichert und nicht mehr bei jedem hergestellten Gegenstand neu gerechnet. Neuer Testfall **T219** (Bereich H): 5× Herstellen -> höchstens 1 Aufbau je 2 s, jeder Teil unter 16 ms
- **Tooltips neben dem Panel:** Tooltips von Zeilen und Knöpfen im Panel (auch „Kaufen“, die Reiter und das Kästchen) liegen neben dem Panel – rechts davon (rechts neben dem angedockten AHSentinel-Fenster, falls es dort sitzt), links, wenn rechts kein Platz ist – und verdecken nicht mehr den Schliessen-Knopf oder andere Knöpfe (Spieltest S8 / Testfall T206). Neuer Testfall **T218**
- **Gleiche AH-Gebühr wie AHSentinel:** Die echte Gebührenfunktion von AHSentinel `ForeverAuctionFee` wird benutzt (als Methode, nur in WoW Forever; die alten Namen bleiben als Rückfall), und die eigene Rechnung rundet wie AHSentinel (2010c -> 101c, bisher 100c). Spieltest S5 kann jetzt ein Ergebnis liefern. Testfälle T35 und T213 benutzen den echten Namen
- **Spieltest:** Ein FEHLER bleibt im Bericht stehen (ein späteres OK löscht ihn nicht mehr), ein OK wird nur einmal geschrieben (keine Protokollzeile bei jedem Neuaufbau), S2 wird nur geprüft, wenn Beruf oder Fertigkeit wechseln. S10 wird erst nach beiden Fällen OK (Fenster offen; mit Chat-Eingabe nur Link, kein Fenster) und wird FEHLER, wenn sich im Chat-Fall unser Fenster öffnet. Neuer Testfall **T217**
- **Mengenfenster am Händler:** Esc schliesst es jetzt, egal wo der Fokus ist; der freie Platz in den Taschen zählt auch angebrochene Stapel desselben Gegenstands und – bei Handwerkswaren in Retail – die Reagenzientasche (kein „Taschen voll“ mehr zu früh). T215 schliesst das Fenster über das echte Ereignis MERCHANT_CLOSED
- Gemeinsame Datei GoldSentinelGame.lua auf Version 3 (nur Kommentare); keine echten Spielernamen mehr in Beispielen und Tests

## 0.9.31
Entzaubern und Preise richtig rechnen (Anweisung der Prüfung vom 9. Nov., Teil A):
- **A1 Entzauber-Tabelle aus Disenchantry** (1.1.2 von x_Raven_x, MIT-Lizenz – `LICENSE-Disenchantry.txt` liegt bei): ersetzt ohne AHSentinel unsere vereinfachte Tabelle, die jedem grünen Gegenstand einen Splitter anhängte. Jetzt grün Itemstufe 5–15: 80/20 ohne Splitter; 21–25 Rüstung 75/15/10; 51–65 Waffen 22/75/3; WoW-Forever-Waffen 21–30: Grosse Magieessenz; Mengen min–max (für die Rechnung der Mittelwert); blau bis Itemstufe 80 mit Nexuskristall 0,5 %; episch mit Mengen
- **A2 Wert und Gewinn getrennt:** „Entzauberungswert (Ø)“ und „Entzauberungswert nach Gebühren“; als Gewinn nur „Herstellen & Entzaubern: Gewinn = Entzauberungswert nach Gebühren − Materialkosten“. Kein Fenster nennt den reinen Wert „Gewinn“
- **A3 Sicherheitsabschlag:** Unter 10 echten Entzauberungen der Gruppe (eigene + geteilte) ist der Entzauberungswert für Gewinn und Rangliste 10 % tiefer; der Tooltip zeigt den Abschlag und „(geschätzt)“
- **A4 Händlerpreis:** zuerst der Preis, den AHSentinel beim Händler wirklich gesehen hat (aktuell, für WoW Forever genau), dann das Datenpaket
- **A5 Kaufpreis:** Im AH gekaufte Zutaten werden mit dem günstigsten Angebot des letzten Scans gerechnet (AHSentinel `GetCurrent`, solange nicht älter als 3 h), sonst mit dem Marktwert; der Tooltip nennt die Quelle („AH aktuell“ / „Markt“). Produkte zum Verkaufen behalten den Marktwert, bis AHSentinel eine einzige Preisfunktion hat (Teil B)
- Testroutine: neuer Testfall **T216** (Braune Leinenhose ohne AHSentinel → 2 Materialien 80/20; Itemstufe 23 Rüstung → 75/15/10; Waffe 53 → 22/75/3; Forever-Waffe 25 → Grosse Magieessenz; keine Beschriftung nennt den Wert „Gewinn“; Abschlag unter 10 Entzauberungen; beobachteter Händlerpreis vor Datenpaket; Zutat zum Kaufen mit aktuellem Preis, alter Scan → Markt); T178 an die neue Reihenfolge angepasst

## 0.9.30
Wunsch des Nutzers (9. November): **Mengenfenster am Händler**
- **Shift+Klick auf eine Ware im Blizzard-Händlerfenster** öffnet ein kleines Fenster von ProfessionSentinel statt Blizzards Dialog (der nur bis zu einem Stapel geht): Icon, Name, Preis pro Stück (bzw. pro Packung), Mengenfeld, Gesamtpreis, „Kaufen“ und „Abbrechen“. Vorbelegt mit der fehlenden Menge laut Einkaufsliste, sonst ein Stapel. Enter = Kaufen, Esc = Abbrechen, Mausrad ±1, Shift+Mausrad ±1 Stapel
- „Kaufen“ kauft genau diese Menge über mehrere Käufe – dieselbe Funktion wie die Einkaufsliste (volle Stapel, dann der Rest; Packungen aufgerundet mit Hinweis; begrenzte Ware höchstens so viel, wie der Händler hat, mit Hinweis; zu wenig Gold oder volle Taschen: so viel wie möglich und eine Chat-Zeile). Nur auf Klick, nie automatisch; das Fenster dockt rechts am Händlerfenster an und schliesst mit ihm
- Rechtsklick (1 kaufen) und Linksklick (aufnehmen) bleiben, wie sie sind; bei aktivem Chat-Eingabefeld fügt Shift+Klick nur den Link ein. Kein Taint: nur `hooksecurefunc` auf `MerchantItemButton_OnModifiedClick`, Blizzards Dialog wird danach nur ausgeblendet. Classic Era genauso
- Option „Mengenfenster am Händler (Shift+Klick)“, Standard an, `/ps menge`; steht beim Rechtsklick auf den Minimap-Button bei den übrigen Optionen
- Spieltest: neue Prüfung **S10** „Shift+Klick öffnet das Mengenfenster, Blizzard-Dialog geschlossen, Chat-Link geht weiter“
- Testroutine: neuer Testfall **T215** (Fenster öffnet, Blizzard-Dialog zu; Chat-Feld aktiv → nur Link; Option aus; 60 bei Stapel 20 → 20+20+20; Packung 5, Eingabe 12 → 15 mit Hinweis; begrenzte Ware 3, Eingabe 10 → 3 mit Hinweis; Gold für 7 → 7; Händler zu → Fenster zu)

## 0.9.29
Wunsch des Nutzers (9. November): **Händlerware in freier Menge kaufen**
- **Einkaufsliste (Reiter „Plan“):** Bei offenem Händler bekommt jede Zeile mit Händlerware (z. B. Leere Phiole, Grober Faden) ein Mengenfeld – vorbelegt mit der fehlenden Menge, frei änderbar – und einen Knopf **„Kaufen“**. Der Tooltip des Knopfs zeigt vor dem Kauf den Gesamtpreis
- Auf Klick kauft er **genau diese Menge**, auch über mehrere Käufe (volle Stapel bis zum Höchstwert des Händlers, dann der Rest); Ware in Packungen (z. B. 5 Stück) wird auf ganze Packungen aufgerundet, der Chat sagt es. Zu wenig Gold, volle Taschen oder der Händler hat nicht mehr: so viel wie möglich und eine Chat-Zeile. Nur auf Klick bei offenem Händler, nie automatisch; die Käufe laufen wie bisher über `ns.Act`. Das Diagnose-Protokoll notiert KAUF (Material, gewünscht, gekauft, Preis)
- Spieltest: neue Prüfung **S9** „gekaufte Menge = eingegebene Menge (bzw. ganze Packungen)“ – vergleicht kurz nach dem Kauf die Taschen
- Testroutine: neuer Testfall **T214** (16 bei Stapel 20 → 1 Kauf; 50 → 20+20+10; Packung 5, Eingabe 12 → 15 mit Hinweis; Gold reicht für 7 → 7 und Meldung; volle Taschen; ohne offenen Händler nichts; S9); T213 an S9 angepasst

## 0.9.28
- **Neu: Spieltest `/ps spieltest an|aus|bericht`** (Wunsch des Nutzers): Statt die Checkliste von Hand abzuarbeiten, prüft ProfessionSentinel sich selbst, während du spielst – sobald du die Lage herstellst (Berufsfenster öffnen, Rezepte anklicken, herstellen, Skillpunkt holen). Es ruft nie selbst eine geschützte Funktion auf und tut im Kampf nichts an der Oberfläche. Standard aus; eingeschaltet läuft er bis /reload, höchstens 2 Stunden
  - **S1** Klick öffnet das Rezept sofort (Weg „Liste“, < 0,5 s; Ergebnis nach 5 Klicks) · **S2** Fertigkeit > 0 und der Plan beginnt bei der Fertigkeit · **S3** „N× bis Gelb“ sinkt nach einem Skillpunkt · **S4** Panel überdeckt weder Berufsfenster noch AHSentinel-Fenster (auch wenn es später erscheint) · **S5** AH-Gebühr ist dieselbe Zahl wie in AHSentinel · **S6** Rangliste Leveln: gelernte zuerst, nach Material pro Punkt sortiert, nichts Graues · **S7** 5 Gegenstände herstellen löst keinen Sturm aus (höchstens 2 Neuaufbauten/s, nichts über 16 ms) · **S8** die Oberflächen-Prüfung aus Bereich K einmal bei offenem Berufsfenster
  - Jedes Ergebnis (OK / FEHLER mit Messwert und Erwartung) kommt ins Diagnose-Protokoll; ein FEHLER gibt eine Chat-Zeile je Prüfung. `/ps spieltest bericht` listet OK / FEHLER / offen mit der Lage, die noch fehlt, und speichert einen GSTEST1-Bericht (Bereich „S“) für die Prüfung. Keine Namen
- Testroutine: neuer Testfall **T213** (jede Prüfung S1–S8 mit einer OK- und einer FEHLER-Lage, eine Chat-Zeile je FEHLER, Bericht mit OK/FEHLER/offen)

## 0.9.27
Leistung (im Spiel brauchte das Panel bis 44 ms, das beste Rezept 20 ms, AD.Plan 68 ms; Grenze 16 ms) und zwei Befunde der Testroutine:
- **Einmal je Durchlauf rechnen:** Ein Update (AD.Update, UI:Refresh, AD.Plan) bewertete ein Rezept bis zu dreimal (Leveln, Gold, Entzaubern) und fragte AHSentinel immer wieder nach denselben Marktpreisen. Jetzt wird jeder AH-Wert, jeder Rezeptpreis und jede Taschenzahl einmal je Durchlauf berechnet; der Zwischenspeicher wird am Ende des Durchlaufs verworfen, es veraltet also nichts
- **Diagnose-Protokoll zeigt den langsamen Teil:** Neben UI:Refresh protokolliert es jetzt UI:UpdateBest und UI:Refresh/<Ansicht> einzeln (nur über 16 ms)
- **T145 Speicher:** Nach dem Lauf verwirft die Testroutine vor der Messung die abgeleiteten Zwischenspeicher, die sie mit Testdaten gefüllt hat (Gilden-Index mit 300 Mitgliedern, Ranglisten mit „alles gelernt“, Rezept-ID-Tabelle, eigene Kopie des Berichts)
- **T132 globale Namen:** Die Unterelemente, die Blizzard-Vorlagen nach unseren eigenen Fenstern benennen (…Bg, …CloseButton, …Inset, …Portrait, …TitleText), gelten als eigene und werden nicht mehr gemeldet
- Testroutine: neuer Testfall **T212** (ein Update fragt jeden Marktpreis und jede Taschenzahl nur einmal; der Durchlauf endet immer)

## 0.9.26
Die Testroutine prüft die Oberfläche im echten Client (Anweisung vom 5. Nov., Vorlage UICheck.lua):
- **Neu UICheck.lua** (aus der GoldSentinel-Vorlage, in allen vier TOCs): Panel, Diagnose-Protokoll, Testbericht, Testmodus und die Verzauberer-Frage melden sich mit `ns.RegisterUI` an – so können auch die anderen GoldSentinel-Addons gegen sie prüfen
- **Neuer Bereich K** (`/ps testroutine k`): **T206** eigene Tooltips verdecken keine Knöpfe, **T207** kein Überlappen mit Berufsfenster, AHSentinel-Gewinn-Fenster und anderen GoldSentinel-Fenstern, **T208** Fenster ganz im Bildschirm, **T209** Beschriftungen von Knöpfen nicht abgeschnitten – diese vier nur im echten Client mit offenem Panel (sonst mit Hinweis übersprungen, nie als OK gezählt); **T210** Spielwerte plausibel: „Fertigkeit > 0, wenn Beruf gelernt“ und „Plan beginnt bei der Fertigkeit“ (`ns.Plausible`); **T211** keine Fehlerschleife (gleiche Meldung mehr als 10×)

## 0.9.25
**Gebührenregel für WoW Forever (Angabe des Nutzers vom 9. November, ersetzt alle früheren):** Es gibt nur EINE Gebühr – die AH-Gebühr = max(5 % vom Verkaufspreis der Auktion, 1 Silber), pro Auktion (pro eingestelltem Stapel, nicht pro Stück), bezahlt beim Einstellen. Eine separate Einstellgebühr gibt es nicht.
- Prices.lua: keine Einstellgebühr aus dem Händlerwert mehr. Gebühr pro Stück = max(5 % × Verkaufspreis eines vollen Stapels, 1s) ÷ Stapelgrösse; netto = AH-Wert − AH-Gebühr. Ist AHSentinel geladen, wird dessen Gebührenfunktion verwendet (gleiche Zahl in beiden Addons). Entzauberungsmaterial genauso. Classic Era, TBC und Retail unverändert (5 % Kommission beim Verkauf)
- Tooltip: eine Zeile „AH-Gebühr (5 %, mind. 1s)“ statt „AH-Kommission“ plus „Einstellgebühr“; unter dem Netto „davon AH-Gebühr“
- Testroutine: T35 prüft jetzt die Regel (3s 90c → 1s, 2s → 1s, 1g → 5s, Stapel 20 × 1c → einmal 1s, keine eigene Einstellgebühr, AHSentinel-Funktion gilt); T33 und der alte Selbsttest angepasst

## 0.9.24
Korrektur aus dem Diagnose-Protokoll (0.9.22 in WoW Forever): **Ereignis-Sturm am Berufsfenster** – 7450 Neuaufbauten durch TRADE_SKILL_LIST_UPDATE, UI:Refresh 101 ms und AD.Update 39 ms bei jedem Mal; das waren die Ruckler.
- **Ursache:** Nach jedem TRADE_SKILL_LIST_UPDATE wurden alle Rezepte gescannt und alles neu gerechnet und gezeichnet – auch bei geschlossenem Panel. Das Lesen der Rezeptliste kann das Spiel wieder TRADE_SKILL_LIST_UPDATE senden lassen, der Scan hat sich also selbst angetrieben
- **Jetzt:** Listen-Ereignisse direkt nach dem eigenen Scan werden verworfen (1 s); Ereignisse werden gesammelt (ein Scan je 0,5 s); ein voller Neuaufbau (rechnen + zeichnen) nur, wenn sich Beruf, Fertigkeit oder gelernte Rezepte wirklich geändert haben oder das Fenster geöffnet / ein Rezept gelernt / ein Skillpunkt geholt wurde. Sonst wird nur ein sichtbares Panel aus dem Zwischenspeicher neu gezeichnet – ein verborgenes gar nicht. Ergebnisse bleiben bis zu 30 s gespeichert (vorher 5 s). Das Panel wird höchstens alle 0,5 s neu aufgebaut
- **Andocken:** Das Panel dockt auch neu an, wenn das AHSentinel-Fenster seine Grösse ändert (OnSizeChanged), zusätzlich zu OnShow/OnHide und jedem eigenen Refresh
- Die Tooltip-Zeile „davon Einstellgebühr“ (Schritt 1 der Liste vom 9. Nov.) ist seit 0.9.19 drin
- Testroutine: neuer Testfall **T205** (100 Listen-Ereignisse ohne Änderung → kein voller Neuaufbau, verborgenes Panel nicht neu gezeichnet, Ereignisse direkt nach dem eigenen Scan verworfen; ein Skillpunkt baut weiter neu auf); T91 und T190 angepasst

## 0.9.23
Korrektur aus dem Spiel (WoW Forever, 5. November): Mit 0.9.20 sprang das Berufsfenster immer noch sehr langsam zum Rezept.
- **Auswahl über die Liste des Fensters, wie AHSentinel:** Ein Klick wählt das Rezept jetzt mit `ProfessionsFrame.CraftingPage.RecipeList:SelectRecipe(recipeInfo, true)` – das springt im selben Frame dorthin. `C_TradeSkillUI.OpenRecipe` (springt in WoW Forever erst viel später) ist nur noch der Rückfall. Das Diagnose-Protokoll zeigt den Weg („Liste“ / „OpenRecipe“)
- **Rezept-ID-Tabelle bleibt erhalten:** Sie wird nur noch neu gelesen, wenn das Fenster öffnet oder den Beruf wechselt oder ein Rezept gelernt wurde – nicht mehr bei jedem TRADE_SKILL_LIST_UPDATE (vorher musste der nächste Klick alle Rezepte neu lesen)
- Testroutine: neue Testfälle **T203** (Klick wählt über die Liste und scrollt dorthin, kein OpenRecipe; Auswahl im selben Frame gemeldet; Rückfall auf OpenRecipe) und **T204** (20 Listen-Ereignisse → Tabelle höchstens 1× gebaut; Berufswechsel baut sie neu)

## 0.9.22
Testroutine nach den bei LevelPilot bewährten Regeln:
- **Ehrliche Zählung:** Ein Testfall, der nichts geprüft hat, zählt nie mehr als OK – er gilt als übersprungen („nicht automatisiert – keine Prüfung lief“). Das betraf T195 im modernen Client. Nach jedem Lauf folgt den Zahlen eine Zeile **„Nicht automatisiert: N“** (übersprungen plus im Client prüfen)
- **Feste Liste „im Spiel prüfen“:** Der Lauf merkt sich alle Fälle, die nur das Spiel prüfen kann; `/ps testroutine liste` gibt sie mit Anleitung aus und sagt, wie man bestätigt (`/ps testroutine ok <ID>`)
- **Jeder Fehler aus dem Spiel hat einen eigenen Testfall** – geprüft vom neuen Fall **T202** (Popup-%, Andocken, Fertigkeit 0, spät erscheinendes AHSentinel-Fenster, Klick ohne AHSentinel und ohne Warten, Diagnose-Protokoll)

## 0.9.21
- **Neu: Diagnose-Protokoll `/ps protokoll`** (nach dem Vorbild von LevelPilot): ein Fenster mit kopierbarem Text – Version, Client, Interface, Sitzungen, geänderte Einstellungen, Diagnose (Preisquelle, Panel offen, angedockt an Berufsfenster oder AHSentinel-Fenster, Neuaufbauten) und die Einträge, neueste zuerst: **KLICK** (Rezept, Zauber-ID, Rezept-ID, Weg, ms, ausgewählt ja/nein), **AUFBAU** (gesammelter Neuaufbau: Auslöser, Anfragen, ms), **LANGSAM** (UI:Refresh, AD.Update, Plan über 16 ms), **ÜBERLAPPT** (keine freie Stelle / Panel überdeckt das AHSentinel-Fenster), **FEHLER** (Lua-Fehler des Addons, gleicher Fehler nur gezählt). Ringpuffer mit 200 Einträgen in ProfessionSentinelDB.diag
- Beim /reload oder Ausloggen wird das Protokoll als **GSDIAG1**-Zeichenkette in `ProfessionSentinelDB.diagExport` abgelegt (Kopfzeile `GSDIAG1|ProfessionSentinel|<Version>|<Client>|<Interface>|<Datum>`, dann der Text, höchstens 24 000 Zeichen), damit der RaidMasterUploader es wie die GSTEST1-Berichte mitschicken kann. Spieler-, Realm-, Gilden- und Charakternamen werden durch `<Name>` ersetzt. Die Testroutine schreibt nie ins echte Protokoll
- Testroutine: neue Testfälle **T198** (alle fünf Arten, zählen statt fluten, Klick im Panel wird protokolliert), **T199** (Ringpuffer, Testlauf schreibt nicht, beschädigtes Protokoll repariert), **T200** (GSDIAG1-Kopfzeile, Grösse, Köder-Namen nie im Export, kein Export während der Testroutine), **T201** (`/ps protokoll` öffnet das Fenster)

## 0.9.20
Korrektur aus dem Spiel (WoW Forever, 5. November): Ein Klick im Panel öffnete das Rezept nur, wenn es vorher in AHSentinel angeklickt worden war; sonst sprang das Fenster erst nach 50 Sekunden oder mehr dorthin.
- **ProfessionSentinel ermittelt die Rezept-ID des offenen Fensters jetzt selbst** (ohne AHSentinel): Die Rezept-IDs des Fensters (GetAllRecipeIDs) werden einmal in eine Tabelle Name / Ergebnis-Item → Rezept-ID gelesen, erneut wenn sich die Liste des Fensters ändert. Ein Klick nimmt die eigene ID des Fensters – nach deutschem oder englischem Namen, sonst nach Ergebnis-Item, sonst die ID, die das Fenster zur Zauber-ID meldet – und öffnet sie sofort. Im selben Frame wird geprüft, ob das Fenster es zeigt (kein Timer)
- Testroutine: neuer Testfall **T197** (der Fall aus dem Spiel: ohne AHSentinel, das Fenster antwortet auch auf die Zauber-ID, führt das Rezept aber unter eigener ID → seine ID wird sofort geöffnet, ohne Timer, bestätigt in < 0,5 s; Ergebnis-Item bei anderem Namen); T196 angepasst

## 0.9.19
Korrektur aus dem Spiel (WoW Forever, 5. November):
- **Behoben: Ein Klick auf ein Rezept öffnete seit 0.9.18 nichts mehr** (dafür kam eine Chat-Meldung). Unsere Daten führen die Classic-Zauber-ID, das moderne Berufsfenster kennt das Rezept aber teils unter einer anderen Rezept-ID. Der Klick sucht jetzt die Rezept-ID des offenen Fensters: die Zauber-ID, wenn das Fenster sie unter demselben Namen kennt, sonst das Rezept des Fensters mit demselben deutschen oder englischen Namen (ohne Platzhalter- und Umschmiede-Einträge), und öffnet dieses. Die Meldung kommt nur noch, wenn das Rezept wirklich nicht im Fenster ist. Ein Linksklick löst weiterhin genau einmal aus (beim Drücken)
- **Tooltip: „davon Einstellgebühr“** unter „Netto pro Herstellung“ (und unter dem Entzauberungs-Netto) in WoW Forever, damit die Zahl nachvollziehbar ist. Die Rechnung selbst bleibt gleich (Einstellgebühr mind. 1s pro Auktion, nie erstattet; 5 % Kommission)
- Testroutine: neuer Testfall **T196** (Zauber-ID → Rezept-ID des Fensters, deutscher und englischer Name, gleiche ID, Rezept fehlt → Meldung; eine Aktion pro Klick); T193/T194 angepasst

## 0.9.18
Korrektur aus dem Spiel (WoW Forever, 5. November): Ein Klick auf ein Rezept im Panel öffnete es im Berufsfenster nur manchmal.
- **Ursache: Die Liste wurde während des Klicks neu aufgebaut.** Berufs-Ereignisse kommen in Schüben (TRADE_SKILL_LIST_UPDATE mehrmals pro Sekunde), und jedes baute das Panel neu auf. Jetzt werden sie gesammelt, und das Panel wird höchstens alle 0,4 s neu aufgebaut
- **Einmal rechnen, oft zeichnen:** Leveln-, Gold- und Material-Rangliste werden zwischengespeichert und nur neu gerechnet, wenn sich Beruf, Fertigkeit, Rezept-/Lerndaten, Testmodus oder Preisquelle ändern (bei AH-Preisen spätestens nach 5 s). Reiterwechsel und Tippen im Suchfeld zeichnen nur noch
- **Linksklick beim Drücken:** Zeilen nehmen den Linksklick schon beim Drücken an, ein Neuaufbau zwischen Drücken und Loslassen kann ihn nicht mehr verschlucken
- **Öffnen ist robuster:** Ein Suchtext im Berufsfenster wird vorher geleert; in Classic Era auch der Namensfilter, und zugeklappte Kategorien werden aufgeklappt. Geht es trotzdem nicht, sagt eine kurze Chat-Meldung (DE/EN) Bescheid, statt dass nichts passiert. Der Hintergrund der Liste nimmt keine Klicks an
- Testroutine: neue Testfälle **T192** (20 Ereignisse in 1 s → höchstens 3 Neuaufbauten; Zwischenspeicher), **T193** (Klick bei geplantem Neuaufbau öffnet das Rezept), **T194** (Suchtext aktiv → richtiges Rezept; Meldung bei Fehlschlag), **T195** (zugeklappte Kategorie; Hintergrund nimmt keine Klicks)

## 0.9.17
Wunsch des Nutzers (5. November):
- **Reiter Rangliste: „Leveln – Material pro Skillpunkt“** statt „Gold pro Skillpunkt“. Zuerst stehen die gelernten Rezepte, darunter die noch nicht gelernten (eigener Unterteil „Noch nicht gelernt“). Beide Teile sind nach der geringsten Materialmenge pro erwartetem Skillpunkt sortiert – reine Menge der Reagenzien, nicht ihr Gold-Wert. Zwischenprodukte desselben Berufs zählen als ihr Grundmaterial (Schmiedekunst rechnet in Barren). Erwartete Punkte pro Herstellung: orange 1, gelb 0,5, grün 0,25; graue Rezepte fallen weg. Die Zeile zeigt dort keinen Gold-Wert mehr, nur noch, wie oft bis zur nächsten Farbe. „Gold verdienen“, „Top 10“, der Stern und der Levelplan bleiben, wie sie sind
- Testroutine: neuer Testfall **T191** (orange 2 Barren und gelb 1 Barren beide Wert 2, Gleichstand in stabiler Reihenfolge; ungelerntes Rezept mit Wert 1 unter allen gelernten; graues Rezept fehlt; Zwischenprodukt als Grundmaterial)

## 0.9.16
Korrektur aus dem Spiel (WoW Forever, 5. November):
- **Das Gewinn-Fenster von AHSentinel liegt nicht mehr über dem Panel:** Es erscheint oft später (z. B. bei der Rezeptwahl), wenn das Panel schon angedockt ist. Mit AHSentinel 0.65.11+ hängt sich das Panel jetzt einmal über `AHAnalyzerPro.Crafting:GetDockFrame(true)` an das AHSentinel-Fenster (auch solange es verborgen ist) und dockt neu an, sobald es ein- oder ausgeblendet wird, bei jedem eigenen Refresh und bei TRADE_SKILL_SHOW. Ältere AHSentinel-Versionen laufen wie bisher
- Testroutine: neuer Testfall **T190** (AHSentinel-Fenster erscheint nach dem Panel → einmal gehakt, rechts daneben angedockt, kein Überlappen; ältere AHSentinel-Versionen)

## 0.9.15
Korrektur aus dem Spiel (WoW Forever, 5. November):
- **Behoben: Fertigkeit im modernen Client als 0 gelesen** (WoW Forever, Retail): Der Levelplan begann bei 0 (z. B. Kochkunst 110/150: „von 0 bis 75“, Angeln 114/150: „von 0 bis 20“), und die Lebenslinie zeigte fast überall dasselbe „45× bis Gelb“ und zählte nicht herunter. Die Unterberufs-Info des Fensters kann 0 oder einen veralteten Wert liefern. Jetzt werden alle Quellen des offenen Berufs gelesen (Unter- und Hauptberufs-Info des Berufsfensters, die Fertigkeitslinie, GetProfessions/GetProfessionInfo), und der höchste gültige Wert gilt. Bei jedem Skillpunkt (CHAT_MSG_SKILL, SKILL_LINES_CHANGED, TRADE_SKILL_LIST_UPDATE) werden Plan und Lebenslinie damit neu gezeichnet. Ist kein gültiger Wert lesbar, zeigt der Plan „Fertigkeit unbekannt“, statt ab 0 zu planen
- Der Platzhalter im Suchfeld ist kürzer und bleibt auf einer Zeile
- Testroutine: neuer Testfall **T189** (Fertigkeit 110 simuliert → Plan beginnt bei 110; +1 → „N× bis Gelb“ sinkt; veralteter Wert und Rückfall; unbekannt bleibt unbekannt)

## 0.9.14
Korrekturen aus der Testroutine im Spiel (WoW Forever, 5. November):
- **Behoben: Lua-Fehler in den Eingabefenstern** für Aufschlag, Mindestgewinn und Entzauberungs-Marge (`GameDialog.lua: invalid option in 'format'`). Das Spiel schickt den Text des Fensters durch `string.format`, das „%“ in „in %“ brach das ab; jedes „%“ geht jetzt als „%%“ hinein. Testfall **T63** prüft jetzt auch, dass der Text `string.format` übersteht
- **Kein Überlappen mehr am Berufsfenster:** Ist das Gewinn-Fenster von AHSentinel offen, dockt das Panel rechts daran an, sonst wie bisher direkt rechts am Berufsfenster. Benutzt wird nur die Schnittstelle `AHAnalyzerPro.Crafting:GetDockFrame()` von AHSentinel; ältere AHSentinel-Versionen ohne sie bleiben unberührt (keine Suche nach Fenstern). Wird das AHSentinel-Fenster ein- oder ausgeblendet, dockt das Panel neu an. Am rechten Bildschirmrand weicht es unter das AHSentinel-Fenster oder links neben das Berufsfenster aus – nie über ein anderes Fenster. Verschoben wird nur das eigene Panel
- Testroutine: neue Testfälle **T187** (kein Überlappen mit und ohne AHSentinel, Bildschirmrand, ältere AHSentinel-Versionen, Fehler in der Schnittstelle) und **T188** (im Spiel mit AHSentinel prüfen)

## 0.9.13
- **Neu: Minimap-Button** (Buch-Symbol, wie bei allen GoldSentinel-Addons): Linksklick öffnet oder schliesst das Panel wie `/ps`, Rechtsklick listet die Optionen mit ihrem Stand und dem Befehl zum Umschalten (ProfessionSentinel hat kein Optionsfenster – seine Optionen sind die `/ps`-Befehle), Ziehen verschiebt ihn um die Minimap; die Position wird pro Konto gespeichert. `/ps minimap` blendet ihn aus und ein (Standard: an, auch in `/ps help`). Keine Bibliothek nötig, läuft in allen Spielversionen; beschädigte gespeicherte Positionen werden beim Laden repariert
- Testroutine: neue Testfälle **T182–T185** (Bereich B: Button da und sichtbar, aus-/einblenden mit `/ps minimap`, gespeicherter Winkel → Position nach /reload, simuliertes Ziehen, Reparatur beschädigter Werte, Linksklick öffnet und schliesst, Rechtsklick Optionen, Tooltip auf Englisch und Deutsch) und **T186** (im Spiel prüfen: sichtbar, Ziehen, Sprache des Tooltips)
- Testroutine: Die Beschreibung von `/ps testroutine api` sagt jetzt, was passiert – es werden nur Einträge der eigenen Tabelle `ns.API` umgeschaltet, nie eine Blizzard-Funktion

## 0.9.12
Korrekturen aus der Nachprüfung 0.9.11:
- **Keine Blizzard-Funktion wird mehr ersetzt, auch nicht in der Testroutine (Taint):** Das Addon ruft die Spiel-API nur noch über seine eigene Tabelle `ns.API` auf (beim Laden befüllt; Funktionen aus `C_`-Tabellen bekommen flache Einträge wie `ns.API.MerchantGetItemInfo`; fehlende Funktionen bleiben leer, ältere Spielversionen gehen also ihren alten Weg). Die Testroutine schaltet nur Einträge dieser Tabelle um. Die `[api]`-Fälle laufen nur noch mit `/ps testroutine api` (mit Warnung vor dem Start), nicht mehr im normalen Lauf
- **Eine Stelle für Aktionen mit Folgen:** Kaufen beim Händler, VZ-Angebote flüstern (mit `C_ChatInfo.SendChatMessage` als zweitem Weg, falls die globale Funktion fehlt), Herstellen und der Kartenpin laufen über `ns.Act`; im Testlauf schreibt es nur mit. Neuer Testfall **T180** (Bereich I) prüft, dass jeder Aktionsweg dort ankommt und nichts Echtes passiert; `tests/check_actions.py` prüft den Quelltext
- **T145 Speicher:** gemessen nach Freigabe der eigenen Kopien des Laufs und zwei vollen Speicherbereinigungen, mit längerem Aufwärmen; offline zählt die Messung den kompilierten Code von LuaJIT nicht mehr mit (das Spiel hat kein JIT)
- Testroutine: Die Unterläufe von T20 und T110 nehmen jetzt wirklich nur Bereich F
- **Realms mit Bindestrich** (z. B. Retail „Azjol-Nerub“): Der eigene Charakter erscheint im Tooltip nicht mehr bei „deine anderen Charaktere“ (neuer Testfall T181)
- „Bitte /reload“ nach jedem Testlauf; die restlichen Testtexte („GoldSentinelTest/SavedVariables fehlen“, „Erneut starten“, „Alles markieren“) kommen jetzt aus den Locales (EN/DE)
- Geschützte Werte (WoW Forever, Retail im Kampf): Ereignis „Rezept gelernt“, Tooltips, der VZ-Kunde und die Gildenliste fragen zuerst `IsSecret`, vor jedem Vergleich
- Für Spieler ändert sich an Aussehen und Bedienung nichts

## 0.9.11
- Intern: **eine Testroutine** für den Entwickler (`/ps testroutine`, Knopf „Alles testen“ im Testmodus): 179 Testfälle (T01–T179) in zehn Bereichen, die Ergebnisse gehen über die gemeinsame `GoldSentinelTest.lua` an die Prüfung. `/ps selftest` und `/ps autotest` laufen jetzt über dieselbe Maschine. Für Spieler ändert sich nichts
- Lua-Fehler des Addons werden jetzt lokal gezählt (höchstens 50 Arten) und mit dem nächsten Testbericht gemeldet; das Addon selbst sendet nichts
- Behoben, gefunden von den neuen Testfällen (ältere Spielversionen laufen exakt wie bisher):
  - moderner Client: Stapelgröße, Händler-Verkaufspreis, Entzauberungswerte und Shift-Klick-Links gehen auch ohne das alte `GetItemInfo`
  - geschützte Werte im Kampf (WoW Forever, Retail): Ereignis „Rezept gelernt“, Tooltips, der Kunde für VZ-Angebote und die Gildenliste benutzen sie nie
  - Fehler in AHSentinel brechen den Verzauberer-Reiter nicht mehr ab; beschädigte gespeicherte Daten (Favor-Kosten, Planziel, VZ-Preise, Charaktere) werden beim Laden repariert statt Lua-Fehler auszulösen
  - Einkaufen, Flüstern, Sniper-Ziele und Wegpunkte werden im Kampf mit kurzem Hinweis abgelehnt

## 0.9.10
Rezeptdaten aktualisiert (WoW-Forever-Client 1.60.1.70753, QuestieDB 2026-11-02):
- **Neues Rezept:** Stiefel - Geschwindigkeit (Verzauberkunst, Stufe 280) – Formel beim Händler
- **37 Rezepte mit neu bekannter Händlerquelle**, jetzt mit Preis und benötigter Stufe: z. B. die Kettenrüstungen des Veteranen, Gardisten und Beschützers (Schmiedekunst 80–125), 18 Lederverarbeitungs-Muster, die Herz-des-Berges-Formeln (Verzauberkunst 265) und Schwacher Trank des Zauberschlags (Alchemie 35)
- Classic Era und Retail: keine Änderungen an Rezepten (nur Datenstand)

## 0.9.9
Korrekturen aus der Nachprüfung von 0.9.8:
- **WoW Forever, Ruf:** Dein Ruf wird jetzt auch im modernen Client gelesen (`C_Reputation`) – die Rufstufe bei Favor-Rezepten wird wieder grün bzw. rot statt immer gelb
- **Händlergunst von AHSentinel:** übernommen wird nur noch Merchant's Favor, keine andere Währung (sonst stimmten Preis und Stand nicht)
- **Kosten nicht lesbar?** Kann der Client die Favor-Kosten beim Händler nicht lesen, sagt das Addon das einmal pro Händlerbesuch; in der Diagnose steht „Händler-Kosten lesbar: ja/nein“
- **Kistenrechner:** Bei grünen Kisten (Barren, Stoffballen, Bauteile) zählt jetzt das Günstigere aus Kaufen und **selbst Herstellen**; im Tooltip steht, was benutzt wurde
- **Neu, standardmässig aus:** die beste Kiste (Gold pro Gunst) oben in „Heute herstellen“ – einschalten im Reiter Gunst oder mit `/ps kisten`
- Favor-Kosten und Rufstufe jetzt auch im Item-Tooltip (Taschen, AH)
- Ältere Spielversionen: Händlerkauf wieder exakt wie früher; die neue Reiter-Verteilung ohne Lücken gilt nur in WoW Forever

## 0.9.8
- Intern: **GoldSentinelGame.lua Version 2** – setzt sich gegen frühe, zurückgezogene Fassungen anderer GoldSentinel-Addons durch und verträgt sich mit ihnen (keine Lua-Fehler, wenn mehrere Addons verschiedene Fassungen mitbringen). Für Spieler ändert sich nichts

## 0.9.7
- **WoW Forever, Händler:** Wurde ein Handelslager-Händler nur mit AHSentinel besucht, übernimmt ProfessionSentinel jetzt auch die Währung – der Stand deiner Händlergunst erscheint dann ohne eigenen Händlerbesuch. Reihenfolge der Kosten: selbst beim Händler gelesen → von AHSentinel gelesen → Guides
- Händlerkauf und Lesen der Kosten sind gegen fehlende alte Händler-Funktionen im modernen Client abgesichert (Anzahl, Link, Kauf); ältere Spielversionen laufen unverändert (im Client testen)

## 0.9.6
- Intern: Die Spielversion kommt jetzt aus **GoldSentinelGame.lua**, der gemeinsamen Erkennung aller GoldSentinel-Addons (dieselbe Datei wie in RaidMaster, GuildSentinel, ThreatSentinel und BuffSentinel). WoW Forever gilt dort immer als moderner Client, nie als Classic. `/gsgame` zeigt im Chat, was erkannt wurde. Für Spieler ändert sich sonst nichts

## 0.9.5
- **WoW Forever: neuer Reiter „Gunst“** (Händlergunst / Merchant's Favor)
  - **Favor-Planer:** Favor-Rezepte (Klick) und Ziele – Packkodo 6000, Minimuli 1500, Berufs-Zertifizierung 1000, Wappenrock 200 – auf die Wunschliste; das Addon zeigt deinen Stand und wie viel noch fehlt. Gelernte Rezepte fallen von selbst heraus
  - **Favor-Rezepte deines Berufs** mit Kosten, Rufstufe und **wer in der Gilde sie schon kann** (Daten aus GuildSentinel/RaidMaster)
  - **Kistenrechner:** alle 30 Abgefangenen Kisten mit dem günstigsten Materialbündel (AH- bzw. Händlerpreise), der leeren Kiste aus dem AH und **Gold pro Gunst-Punkt**. Kisten in deinen Taschen stehen oben, „bereit“ heißt: das Material liegt schon da. Die Gunst der Fachmann-Kisten ist noch geschätzt
- **WoW Forever: Kauf beim Händler** (Levelplan, Heute herstellen) nutzt jetzt die Händler-Funktionen des modernen Clients – die alten gibt es dort nicht mehr (im Client testen)
- Liest AHSentinel beim Händler die Kosten in Händlergunst, nutzt ProfessionSentinel diese Werte, wenn es selbst noch keine hat
- 0.9.3 und 0.9.4 (gemeinsame Versionserkennung) wurden zurückgezogen; sie kommt später für alle GoldSentinel-Addons zusammen

## 0.9.2
- **WoW Forever: Rezepte der Handelslager kosten Händlergunst statt Gold.** Bei den 310 Rezepten von „Versorgung und Logistik Durotar“ (Horde, Brachland) und der „Handelskommission von Azeroth“ (Allianz, Three Corners) stand bisher ein Goldpreis, der im Spiel nicht gilt. Jetzt zeigt der Tooltip die Kosten in **Merchant's Favor** und die nötige **Rufstufe** (Allianz-Spieler sehen ihre Fraktion)
- Die Werte stammen aus öffentlichen Guides (Beta-Stand). **Öffnest du einen Handelslager-Händler, liest das Addon die echten Kosten aus** und merkt sie sich – diese gelten dann vor den Guide-Werten. Hast du die Währung einmal beim Händler gesehen, steht im Tooltip auch, wie viel du davon hast
- Rezepte, die es auch bei normalen Händlern gibt (z. B. Geräucherter Weisenfisch), behalten ihren Goldpreis

## 0.9.1
- **WoW Forever: Einstellgebühr** – jede Auktion kostet mindestens 1 Silber, und die gibt es nicht zurück. Sie wird jetzt vom AH-Erlös abgezogen (zusätzlich zu 5 % Kommission): Gold verdienen, Leveln, Heute herstellen, Entzaubern-Material
- Günstige Items lohnen sich dadurch oft eher beim Händler – das Addon nimmt dann den Händlerpreis (z. B. AH 1s 50c → nur 42c übrig, Händler zahlt 71c)
- Tooltip zeigt die Gebühr als eigene Zeile

## 0.9.0
- **Heute herstellen** (oben im Reiter „Rangliste“, `/ps heute`): die lukrativsten Herstellungen aus allen deinen Berufen – gelernte Rezepte, Verkauf im AH, netto nach 5 % Kommission; höchstens 5 pro Rezept und 20 % deines Golds pro Zeile
- **Ein Klick = nächster Schritt:** Händlerware kaufen (Händler offen) → AH-Zutaten kaufen (über AHSentinel) → herstellen (Berufsfenster offen) → im AH einstellen (über AHSentinel)
- Schnittstelle für AHSentinel: Die Herstellungs-Vorschläge können dort in „Heute tun“ erscheinen (kommt mit der nächsten AHSentinel-Version)

## 0.8.3
- Intern: Das Testmodus-Fenster für den Entwickler (`/ps test`) geht nach dem Einloggen schon beim ersten Mal auf. Für Spieler ändert sich nichts

## 0.8.2
- Intern: Der Entwickler-Autotest nennt den Grund, wenn das Testmodus-Fenster nicht aufgeht, und klappt nur Gruppen mit Zeilen auf und zu (keine falschen Warnungen mehr bei leeren Ranglisten). Für Spieler ändert sich nichts

## 0.8.1
- Retail: Fehler „Attempt to register unknown event TRADE_SKILL_UPDATE“ beim Laden behoben – Berufs-Ereignisse werden nur noch angemeldet, wenn das Spiel sie kennt

## 0.8.0
- **Retail** (12.1.5 Midnight, Interface 120105): ProfessionSentinel läuft jetzt auch im normalen WoW – mit rund **10 170 Rezepten aller Erweiterungen** direkt aus dem Retail-Client
- In Retail ist **jede Erweiterung ein eigener Beruf mit eigener Stufe** wie im Berufsfenster (z. B. „Lederverarbeitung von Midnight“, „Klassische Lederverarbeitung“) – Rezepte, Lebenslinie, Rangliste, Levelplan bis zur Höchststufe der Erweiterung, Ruf, Rezept-Alarm und Material-Tooltip funktionieren dort
- Retail hat keine QuestieDB: keine Händler-, Drop- und Lehrer-Koordinaten (der Reiter „Lehrer“ ist dort ausgeblendet); Händlerware wie Fäden und Farbstoffe wird aus Classic übernommen, neue Händlerpreise liest AHSentinel beim Händlerbesuch
- Verzauberkunst in Retail: nur „VZ verkaufen“ – die Entzauberungstabellen gelten dort nicht
- Händlerpreise: wo die Daten keinen kennen, nimmt ProfessionSentinel den Preis, den AHSentinel beim Händler abgelesen hat (alle Spielversionen)

## 0.7.1
- Intern: automatischer Test im Spiel für den Entwickler (öffnet für jeden Beruf alle Reiter und Knöpfe, fängt Lua-Fehler ab und schreibt einen Bericht). Für Spieler ändert sich nichts

## 0.7.0
- **Levelplan** (neuer Reiter „Plan“): von deiner Fertigkeit bis 75/150/225/300 – welches Rezept wie oft, mit Einkaufsliste (fehlt nach Taschen und Bank). Ein Klick kauft beim offenen Händler genau das Fehlende, ein zweiter legt die AH-Zutaten in den Sniper von AHSentinel (Marktwert + 10 %)
- **Ruf-Rezepte:** im Tooltip steht, welcher Ruf auf welcher Stufe nötig ist – grün, wenn du ihn schon hast (auch neue Forever-Fraktionen wie Kirin Tor)
- **Rezept-Alarm:** liegt ein Rezept, das dir oder einem Twink fehlt, im AH (Scan mit AHSentinel), kommt eine Meldung mit Ton; im Reiter „Rezepte“ stehen sie oben, Klick = Sniper. Aus/an: `/ps alarm`
- **Gilde** (Daten aus GuildSentinel / RaidMaster): wer kann das Rezept herstellen (online zuerst), Gruppe „Kennt niemand in der Gilde“ und die **Abklingzeiten** (Transmutation, Mondstoff, Salzstreuer)
- **Rezepte in deinen Taschen:** wer sie noch braucht – oder keiner (dann verkaufen); **Material-Tooltip:** in wie vielen Rezepten ein Material gebraucht wird und welche davon du kennst (auch Raid-Material wie Lavakern)
- **VZ verkaufen:** Rechtsklick flüstert dem Kunden Material und Preis (auch mit seinem Material)
- Leveln: profitable Rezepte mit kleiner Chance gewinnen nicht mehr nur, weil viele Herstellungen viel Gewinn ergeben – Gewinn zählt pro Herstellung × Chance

## 0.6.5
- Verzauberkunst: Beim **ersten Einloggen** fragt ein Fenster nach deinem Ziel – **Gold machen** (Standard, vorgemerkt), **VZ verkaufen** oder **beides**. Das Fenster bleibt offen, bis du eins gewählt hast, und du schließt es selbst mit „Fertig“. Bis dahin gilt Gold machen. Später ändern: `/ps ziel` oder oben im Reiter „Verzauberer“

## 0.6.4
- Verzauberkunst: keine Frage mehr beim Einloggen – Standard ist **Gold machen**. Umstellen auf VZ verkaufen oder beides optional mit `/ps ziel` oder oben im Reiter „Verzauberer“; einmal pro Charakter kommt ein kurzer Hinweis im Chat

## 0.6.3
- Testmodus und Selbsttest (`/ps test`, `/ps selftest`) gibt es nur noch für den Entwickler – wie bei AHSentinel. Für alle anderen funktioniert das Addon genau gleich, nur ohne diese Werkzeuge

## 0.6.2
- Verzauberer: „Schnäppchen im AH“ zeigt nur noch Gegenstände, die deine **Mindestmarge beim Entzaubern** einhalten – genau die, die auch der Sniper kauft

## 0.6.1
- Nur für Verzauberer mit dem Ziel „Gold machen“ oder „beides“: **Mit dem Sniper kaufen** – ein Klick legt die Schnäppchen (Gegenstände billiger als entzaubert) oder die AH-Zutaten deiner besten Rezepte aus „Herstellen & Entzaubern“ als Ziele in den Sniper von AHSentinel. Max-Preis und Menge sind schon eingestellt, du stellst nur noch das Budget ein
- **Mindestmarge beim Entzaubern** (Standard 20 %) einstellbar: du zahlst höchstens 80 % dessen, was das Material nach AH-Kommission bringt
- Entzaubern gibt es nur noch im Reiter „Verzauberer“: „Gold verdienen“ in der Rangliste der anderen Berufe rechnet wieder nur mit dem Verkauf
- „Herstellen & Entzaubern“ umfasst jetzt die Rezepte **aller deiner Berufe**

## 0.6.0
- Verzauberkunst: Wer Verzauberkunst hat, wird einmal gefragt, wofür – **Gold machen**, **VZ verkaufen** oder **beides**. Das Addon richtet den Verzauberungsteil danach aus, alles andere bleibt gleich. Ändern jederzeit mit `/ps ziel` oder im neuen Reiter „Verzauberer“
- **Gold machen:** Entzauberungswert jedes herstellbaren Gegenstands (Material abzüglich 5 % AH-Kommission). „Gold verdienen“ nimmt Entzaubern, wenn es mehr bringt (DE); neue Gruppe **„Herstellen & Entzaubern“** – Material kaufen, herstellen, entzaubern, nach Gewinn sortiert
- Reiter „Verzauberer“: **Schnäppchen im AH**, die weniger kosten, als sie entzaubert bringen, und die **gelernten Dropchancen** im Vergleich zu den Startwerten
- Dropchancen lernen aus jeder Entzauberung – deiner und der aller Spieler mit AHSentinel. Startwerte bei grünen Teilen: 75 % Staub, 20 % Essenz, 5 % Splitter (Waffen umgekehrt)
- **VZ verkaufen:** alle deine Verzauberungen mit Materialkosten (AH- bzw. Händlerpreise) und deinem **Verkaufspreis** – Aufschlag in % und Mindestgewinn stellst du selbst ein
- Leveln rechnet weiter nur mit dem Verkauf
- Testmodus: Verzauberer simulieren und die drei Ziele durchschalten

## 0.5.1
- Gewinnrechnung zieht die 5 % AH-Kommission vom Verkaufspreis ab – Rangliste, Gold verdienen und Netto pro Punkt rechnen mit dem echten Erlös
- Lohnt sich der Händler nach Abzug der Kommission mehr, zählt der Händlerpreis
- Tooltip zeigt Verkauf im AH, AH-Kommission (5 %) und Erlös aus dem AH

## 0.5.0
- Gold in der Rangliste: „Leveln“ nach Gold pro Skillpunkt, neue Gruppe „Gold verdienen“ nach Netto-Gewinn pro Herstellung – auch graue Rezepte
- Materialkosten: Händlerware zum Händlerpreis, alles andere zum AH-Wert (auch selbst Gefarmtes); Produkt zum höheren Wert aus AH und Händler
- AH-Werte aus AHSentinel (sonst TSM oder Auctionator); ohne AH-Addon bleibt die Rangliste bei Material pro Skillpunkt
- Zeilen zeigen die Herkunft der Zutaten (AH / Händler / Farm) und „+10s 80c/Pkt“; der Tooltip schlüsselt jede Zutat mit Preis, Kosten, Verkaufswert und Netto auf
- Testmodus: „Testpreise“, um die Gold-Rangliste ohne AH-Scan auszuprobieren

## 0.4.0
- Rangliste zum Leveln: alle Rezepte, die bei deiner Fertigkeit Punkte bringen – gelernte und nicht gelernte – sortiert nach Material pro Skillpunkt (Material ÷ Chance auf einen Punkt)
- Neuer Reiter „Rangliste“ mit der ganzen Liste, Top 10 oben im Reiter „Rezepte“; noch nicht gelernte Rezepte mit [lernen] und Quelle
- Stern beim besten gelernten Rezept in Blizzards Rezeptliste, Hinweis mit Platz und Material pro Punkt am Berufsfenster (Klick wählt es aus)
- Rezepte weit über deiner Fertigkeit zählen nicht mehr als orange: fehlende Lernstufen werden geschätzt (WoW Forever über die Era-Stufe desselben Rezepts)
- Classic Era: Rezepte aus Season of Discovery entfernt (1267 echte Era-Rezepte)

## 0.3.0
- Neuer Reiter „Lehrer“: alle Lehrer des offenen Berufs nach Rang – Geselle (bis 150), Experte (bis 225), Fachmann (bis 300), Spezialisierungen – mit Zone, Koordinaten und Fraktion; dein nächster Rang ist markiert
- Händler und Drop-Gegner im Rezept-Tooltip jetzt mit Zone und Koordinaten
- Klick auf einen Lehrer setzt einen Wegpunkt, Rechtsklick auf ein Rezept einen Wegpunkt zum nächsten Händler (TomTom, sonst Kartenpin des Spiels)
- Zonennamen in der Sprache des Spiels; neue WoW-Forever-Gebiete (Insel Zephras, Flusslande) unterstützt
- Testmodus: Prüfungen für Lehrer und Wegpunkte, Knopf „Wegpunkt testen“

## 0.2.0
- Erkennt die Spielversion am Client und passt sich an: WoW Forever (eigene Rezepte und Fertigkeitsstufen – viele Rezepte werden früher grau) und Classic Era (klassisches Berufs- und Verzauberungsfenster)
- Lebenslinie: dünne Linie unter jedem Rezept (orange → gelb → grün → grau) mit Markierung deiner Fertigkeit und wie oft du bis zur nächsten Farbe herstellen musst – in Blizzards Rezeptliste und im Panel „Alle Rezepte“
- Tooltip zeigt Herstellungen bis Gelb, Grün und Grau
- Testmodus (/ps test): Diagnose, simulierte Fertigkeit, simuliert gelernt/nicht gelernt, Panel ohne Berufsfenster, Selbsttest (/ps selftest)
- /ps line schaltet die Lebenslinie an und aus
- Vertauschte Fertigkeitsstufen bei einzelnen Rezepten im Client korrigiert (z. B. Aufgeladene Schuppe von Onyxia)

## 0.1.0
- Erste Version für WoW Forever (Interface 16001)
- Knopf „Alle Rezepte“ im Berufsfenster, gegliedert wie die Kategorien im Spiel
- Gelernte Rezepte ausgegraut, fehlende in Seltenheitsfarbe
- Tooltips mit Fertigkeitsstufen, Reagenzien und Quelle (Lehrer, Händler, Drop, Quest)
- Tooltip bei Rezepten: gelernt oder nicht, auch für deine anderen Charaktere
- 2210 Rezepte, davon 934 neu in WoW Forever
