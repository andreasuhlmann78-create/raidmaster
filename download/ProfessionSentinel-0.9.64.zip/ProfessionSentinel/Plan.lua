local _, ns = ...
local L = ns.L

-- Levelling plan tab: target, steps and shopping list (Advisor.Plan / Advisor.Shopping),
-- buying the missing reagents at an open vendor and handing the AH reagents to AHSentinel's sniper.

local PL = {}
ns.Plan = PL

PL.CAPS = { 75, 150, 225, 300 }
PL.TOLERANCE = 10      -- sniper max price: market value + 10 %

-- target per profession (saved), otherwise the cap of the current rank
function PL.Target(prof, rank, maxRank)
    -- Retail: every expansion line has its own cap (e.g. 100) – that is the target
    if ns.IsRetail then return (maxRank and maxRank > (rank or 0)) and maxRank or math.max((rank or 0) + 1, maxRank or 0) end
    local pt = ns.db and ns.db.planTarget
    local t = type(pt) == "table" and pt[prof] or nil
    if type(t) == "number" and type(rank) == "number" and t > rank then return t end
    return ns.Advisor.DefaultTarget(rank, maxRank)
end

-- next cap above the current target (wraps to the first cap above your skill)
function PL.CycleTarget(prof, rank, maxRank)
    if ns.IsRetail then return end
    if type(ns.db.planTarget) ~= "table" then ns.db.planTarget = {} end
    local cur = PL.Target(prof, rank, maxRank)
    local nextT
    for _, c in ipairs(PL.CAPS) do
        if c > cur then nextT = c; break end
    end
    if not nextT then
        for _, c in ipairs(PL.CAPS) do if c > (rank or 0) then nextT = c; break end end
    end
    ns.db.planTarget[prof] = nextT or 300
    if ns.RefreshAll then ns.RefreshAll() end
end

-- current plan (computed when the tab is shown)
PL.current = nil

-- withStock (0.9.56): "with what I have" – bags and bank first (AD.Plan stock)
function PL.Build(prof, rank, maxRank, withStock)
    if not prof or not rank then PL.current = nil; return nil end
    local t0 = ns.DiagClock and ns.DiagClock()          -- diagnostic log: LANGSAM over 16 ms
    local target = PL.Target(prof, rank, maxRank)
    -- the steps are kept until skill, target, learned recipes (AD.stamp), price source or prices change
    -- (review 0.9.38, point 1); the shopping list (bags) is computed each time
    local PS, P = ns.PriceSource, ns.Prices
    local key = table.concat({ prof, rank, target, ns.Advisor.stamp or 0, tostring(P and P.SourceName()),
        PS and PS.changes or 0, math.floor(((GetTime and GetTime()) or 0) / 30), tostring(ns.Sim), withStock and "stock" or "" }, "|")
    local plan
    if PL.cache and PL.cache.key == key then
        plan = PL.cache.plan
        PL.cacheHits = (PL.cacheHits or 0) + 1
    else
        plan = ns.Advisor.Plan(ns.ByProf[prof], rank, target, nil, nil,
            withStock and function(id) return ns.GetItemCount(id, true) or 0 end or nil)
        PL.cache = { key = key, plan = plan }
    end
    plan.list, plan.totals = ns.Advisor.Shopping(plan)
    plan.prof = prof
    PL.current = plan
    if t0 and ns.DiagSlow then ns.DiagSlow("Plan", t0) end
    return plan
end

---------------------------------------------------------------------------
-- Vendor: buy what is still missing (only what the open vendor sells)
---------------------------------------------------------------------------
-- Vendor access goes through PL.* (exported), so the test routine can check the buying logic with stubs
-- and never buys anything for real.
local function MerchantItemID(i)
    if ns.API.GetMerchantItemID then
        local ok, id = pcall(ns.API.GetMerchantItemID, i)
        if ok and id then return id end
    end
    if not ns.API.GetMerchantItemLink then return nil end
    local ok, link = pcall(ns.API.GetMerchantItemLink, i)
    return ok and type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil
end

-- price, stack per purchase, available (-1 = unlimited) of a vendor slot.
-- Old clients: GetMerchantItemInfo exactly as before; only where it is gone (modern client: WoW Forever,
-- Retail) C_MerchantFrame.GetItemInfo.
local function MerchantItemInfo(i)
    if ns.API.GetMerchantItemInfo then return ns.API.GetMerchantItemInfo(i) end      -- old clients: exactly as before
    if ns.API.MerchantGetItemInfo then
        local ok, info = pcall(ns.API.MerchantGetItemInfo, i)
        if ok and type(info) == "table" then return info.name, info.texture, info.price, info.stackCount, info.numAvailable end
    end
    return nil
end
PL.MerchantItemInfo = MerchantItemInfo
PL.MerchantItemID = MerchantItemID

local function MerchantNumItems()
    if ns.API.GetMerchantNumItems then return ns.API.GetMerchantNumItems() or 0 end
    if ns.API.MerchantGetNumItems then
        local ok, n = pcall(ns.API.MerchantGetNumItems)
        return ok and tonumber(n) or 0
    end
    return 0
end

-- buy n of a vendor slot: through ns.Act (BuyMerchantItem, in the modern client C_MerchantFrame.BuyItem
-- if the old function is gone)
local function BuyItem(i, n)
    return ns.Act("buy", i, n) and true or false
end
PL.MerchantNumItems = MerchantNumItems
PL.BuyItem = BuyItem
function PL.MerchantMaxStack(i) return GetMerchantItemMaxStack and GetMerchantItemMaxStack(i) or 20 end
function PL.Money() return GetMoney() end

function PL.MerchantOpen()
    return MerchantFrame and MerchantFrame.IsShown and MerchantFrame:IsShown() or false
end

function PL.BuyFromVendor()
    local plan = PL.current
    if not plan then return 0 end
    if ns.BlockedInCombat() then return 0 end
    if not PL.MerchantOpen() then ns.Print(L.PLAN_NO_MERCHANT); return 0 end
    local missing = {}
    for _, e in ipairs(plan.list or {}) do
        if e.missing > 0 then missing[e.id] = e.missing end
    end
    local bought, spent = 0, 0
    for i = 1, PL.MerchantNumItems() do
        local id = PL.MerchantItemID(i)
        local need = id and missing[id]
        if need and need > 0 then
            local _, _, price, stackCount, numAvailable = PL.MerchantItemInfo(i)
            stackCount = math.max(1, stackCount or 1)
            local maxStack = PL.MerchantMaxStack(i)
            if stackCount > 1 then
                -- sold in bundles: one purchase = one bundle
                local bundles = math.ceil(need / stackCount)
                if numAvailable and numAvailable >= 0 then bundles = math.min(bundles, numAvailable) end
                for _ = 1, bundles do
                    if PL.Money() < (price or 0) then break end
                    if not PL.BuyItem(i, 1) then break end
                    bought = bought + stackCount; spent = spent + (price or 0)
                end
            else
                local left = need
                if numAvailable and numAvailable >= 0 then left = math.min(left, numAvailable) end
                while left > 0 do
                    local n = math.min(left, math.max(1, maxStack))
                    if PL.Money() < (price or 0) * n then n = math.floor(PL.Money() / math.max(1, price or 1)) end
                    if n <= 0 then break end
                    if not PL.BuyItem(i, n) then break end
                    left = left - n
                    bought = bought + n; spent = spent + (price or 0) * n
                end
            end
        end
    end
    ns.Print(bought > 0 and string.format(L.PLAN_BOUGHT, bought, ns.Prices.MoneyPlain(spent)) or L.PLAN_VENDOR_NOTHING)
    if C_Timer then C_Timer.After(1, function() if ns.RefreshAll then ns.RefreshAll() end end) end
    return bought
end

---------------------------------------------------------------------------
-- Vendor: buy a free amount of ONE reagent (shopping list row: amount field + "Buy", wish of 9 Nov.)
-- Only on click with the vendor open, never automatically. Exactly the amount, over several purchases (full stacks
-- up to GetMerchantItemMaxStack, then the rest); vendor bundles (e.g. 5 per purchase) rounded up to whole bundles
-- (said in the chat). Not enough gold or bag room: as much as possible and a chat line.
---------------------------------------------------------------------------
-- vendor slot of an item: slot, price per purchase, pieces per purchase, available (-1 = unlimited), max per purchase
function PL.FindVendorSlot(itemID)
    if not itemID then return nil end
    for i = 1, PL.MerchantNumItems() do
        if PL.MerchantItemID(i) == itemID then
            local _, _, price, stackCount, numAvailable = PL.MerchantItemInfo(i)
            return i, price or 0, math.max(1, stackCount or 1), numAvailable, math.max(1, PL.MerchantMaxStack(i) or 1)
        end
    end
end

-- pieces of this item that still fit into the bags; nil = unknown (no limit)
--   free slots × stack size, plus the room left in stacks of the same item already in the bags,
--   plus the free slots of the reagent bag (Retail, bag 5) when the item is a crafting reagent
PL.REAGENT_BAG = 5
local function API(name) return ns.API["Container" .. name] or ns.API[name] end

-- pieces in one bag slot (modern: table with stackCount; old: 2nd return value)
function PL.SlotCount(bag, slot)
    local fn = API("GetContainerItemInfo")
    if not fn then return nil end
    local ok, a, b = pcall(fn, bag, slot)
    if not ok then return nil end
    if type(a) == "table" then return a.stackCount end
    return type(b) == "number" and b or nil
end

function PL.IsCraftingReagent(itemID)
    if not ns.ItemInfo then return false end
    local ok, v = pcall(function() return select(17, ns.ItemInfo(itemID)) end)
    return ok and v == true
end

function PL.BagRoom(itemID)
    local freeFn = API("GetContainerNumFreeSlots")
    if not freeFn then return nil end
    local stack = ns.Prices and ns.Prices.StackSize(itemID) or 1
    local bags = { 0, 1, 2, 3, 4 }
    if PL.IsCraftingReagent(itemID) then bags[#bags + 1] = PL.REAGENT_BAG end
    local slotsFn, idFn = API("GetContainerNumSlots"), API("GetContainerItemID")
    local room = 0
    for _, bag in ipairs(bags) do
        local ok, n = pcall(freeFn, bag)
        if ok and type(n) == "number" then room = room + n * stack end
        -- started stacks of the same item
        if stack > 1 and slotsFn and idFn then
            local okS, slots = pcall(slotsFn, bag)
            for slot = 1, (okS and type(slots) == "number") and slots or 0 do
                local okI, id = pcall(idFn, bag, slot)
                if okI and id == itemID then
                    local c = PL.SlotCount(bag, slot)
                    if c and c < stack then room = room + (stack - c) end
                end
            end
        end
    end
    return room
end

-- the purchases for n pieces (pure): returns { calls = { count per BuyItem call }, bought, spent, rounded, limit }
-- price = price of one purchase, stackCount = pieces per purchase (bundle), numAvailable -1/nil = unlimited
function PL.PlanPurchase(n, price, stackCount, numAvailable, maxStack, money, room)
    local res = { calls = {}, bought = 0, spent = 0, rounded = false, limit = nil }
    n = math.floor(tonumber(n) or 0)
    if n <= 0 then return res end
    price, stackCount, maxStack = price or 0, math.max(1, stackCount or 1), math.max(1, maxStack or 1)
    local function cap(units, why)
        if units < res.want then res.want, res.limit = math.max(0, units), res.limit or why end
    end
    if stackCount > 1 then
        -- bundles: one purchase = one bundle; round up to whole bundles
        res.want = math.ceil(n / stackCount)
        res.rounded = res.want * stackCount ~= n
        if numAvailable and numAvailable >= 0 then cap(numAvailable, "stock") end
        if price > 0 and money then cap(math.floor(money / price), "gold") end
        if room then cap(math.floor(room / stackCount), "bags") end
        for _ = 1, res.want do res.calls[#res.calls + 1] = 1 end
        res.bought, res.spent = res.want * stackCount, res.want * price
    else
        res.want = n
        if numAvailable and numAvailable >= 0 then cap(numAvailable, "stock") end
        if price > 0 and money then cap(math.floor(money / price), "gold") end
        if room then cap(room, "bags") end
        local left = res.want
        while left > 0 do
            local k = math.min(left, maxStack)
            res.calls[#res.calls + 1] = k
            left = left - k
        end
        res.bought, res.spent = res.want, res.want * price
    end
    res.want = nil
    return res
end

-- price of n pieces at the open vendor (for the button's tooltip); nil if the vendor does not sell it
function PL.Quote(itemID, n)
    local slot, price, stackCount, numAvailable, maxStack = PL.FindVendorSlot(itemID)
    if not slot then return nil end
    return PL.PlanPurchase(n, price, stackCount, numAvailable, maxStack, nil, nil)
end

local LIMIT_TEXT = { gold = "PLAN_LIMIT_GOLD", bags = "PLAN_LIMIT_BAGS", stock = "PLAN_LIMIT_STOCK" }

function PL.BuyAmount(itemID, n)
    n = math.floor(tonumber(n) or 0)
    if n <= 0 or not itemID then return 0 end
    if ns.BlockedInCombat() then return 0 end
    if not PL.MerchantOpen() then ns.Print(L.PLAN_NO_MERCHANT); return 0 end
    local slot, price, stackCount, numAvailable, maxStack = PL.FindVendorSlot(itemID)
    if not slot then ns.Print(L.PLAN_VENDOR_NOT_SOLD); return 0 end
    local plan = PL.PlanPurchase(n, price, stackCount, numAvailable, maxStack, PL.Money(), PL.BagRoom(itemID))
    local before = ns.GetItemCount(itemID, false)
    local done, spent = 0, 0
    for _, k in ipairs(plan.calls) do
        if not PL.BuyItem(slot, k) then break end
        done = done + k * stackCount
        spent = spent + price * (stackCount > 1 and 1 or k)
    end
    local name = ns.ItemName(itemID)
    if plan.rounded then ns.Print(string.format(L.PLAN_BUY_ROUNDED, n, stackCount, done)) end
    if plan.limit then ns.Print(string.format(L.PLAN_BUY_LIMITED, done, n, L[LIMIT_TEXT[plan.limit]] or plan.limit)) end
    ns.Print(done > 0 and string.format(L.PLAN_BUY_DONE, done, name, ns.Prices.MoneyPlain(spent)) or L.PLAN_VENDOR_NOTHING)
    if ns.Diag then ns.Diag("KAUF", string.format("%s · gewünscht %d · gekauft %d · %s", name, n, done, ns.Prices.MoneyPlain(spent))) end
    if ns.Spieltest and ns.Spieltest.IsOn() then pcall(ns.Spieltest.OnBuy, itemID, before, done) end
    if ns.API.TimerAfter then ns.API.TimerAfter(1, function() if ns.RefreshAll then ns.RefreshAll() end end) end
    return done, plan
end

---------------------------------------------------------------------------
-- AH: missing reagents (not sold by a vendor) into AHSentinel's sniper
-- max price = market value + tolerance, amount = what is missing
---------------------------------------------------------------------------
function PL.SniperTargets(list, tolerance)
    tolerance = tolerance or PL.TOLERANCE
    local out = {}
    for _, e in ipairs(list or {}) do
        if e.missing > 0 and e.origin ~= "vendor" and e.origin ~= "craft" and e.known and e.unit > 0 then
            out[#out + 1] = { id = e.id, maxPrice = math.max(1, math.floor(e.unit * (1 + tolerance / 100))), qty = e.missing }
        end
    end
    return out
end

function PL.ToSniper()
    local plan = PL.current
    if not plan then return 0 end
    if ns.BlockedInCombat() then return 0 end
    local targets = PL.SniperTargets(plan.list)
    if #targets == 0 then ns.Print(L.PLAN_SNIPE_NOTHING); return 0 end
    return ns.Disenchant.SendToSniper(targets, L.PLAN_SNIPE_WHAT, L.PLAN_SNIPE_DONE)
end

-- refresh the vendor button when a merchant opens or closes
local ev = ns.AddEventFrame(CreateFrame("Frame"), "Plan")
pcall(ev.RegisterEvent, ev, "MERCHANT_SHOW")
pcall(ev.RegisterEvent, ev, "MERCHANT_CLOSED")
ev:SetScript("OnEvent", function()
    if ns.db and ns.db.panelMode == "plan" and ns.UI and ns.UI.Refresh then ns.UI:Refresh() end
end)
