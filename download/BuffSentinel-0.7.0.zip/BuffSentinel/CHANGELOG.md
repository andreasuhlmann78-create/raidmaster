# BuffSentinel – Changelog

## 0.7.0
- New "Support" button (PayPal) in the settings window header and on the "Zonen & Anzeige" page; also `/bsen donate` (or `/bsen support`). Opens only on click – no pop-ups, no chat messages.

## 0.6.3
- At least 3 seconds between alert sounds, the same sound at most every 4 seconds.
- "Test sounds" plays all alerts 3 seconds apart and shows which one is playing.

## 0.6.1
- WoW Forever: new Paladin (Seal of Fury, Light's Vigil, Voice of Truth, Swift Judgement, Templar's Bulwark, Infusion of Light) and Shaman abilities (Rage of the Farseer, Fire Nova, Totemic Projection).
- Test mode in Classic Era shows only the classes of your faction.

## 0.6.0
- Test mode with sample display for all classes and specs; buttons can be placed freely.

## 0.5.0
- Dispel bar for party/raid members and enemy dispel/purge buttons.

## 0.4.0
- First release: proc buttons, buff reminders with one-click buffing, cooldown bar, talent detection, all WoW versions.
