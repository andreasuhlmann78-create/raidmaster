# BuffSentinel – Änderungen

## 0.7.0
- Neuer Knopf „Unterstützen“ (PayPal) oben im Einstellungsfenster und auf der Seite „Zonen & Anzeige“, auch per `/bsen spenden`. Öffnet sich nur auf Klick – kein Aufpoppen, keine Chat-Meldungen.

## 0.6.3
- Mindestens 3 Sekunden zwischen Warntönen, derselbe Ton höchstens alle 4 Sekunden.
- „Sounds testen“ spielt alle Töne mit 3 Sekunden Abstand und zeigt an, welcher läuft.

## 0.6.1
- WoW Forever: neue Paladin- (Siegel der Wut, Lichtwacht, Stimme der Wahrheit, Schnelles Richturteil, Bollwerk des Templers, Lichtenergie) und Schamanen-Fähigkeiten (Wut des Weitsehers, Feuernova, Totemprojektion).
- Testmodus in Classic Era zeigt nur die Klassen deiner Fraktion.

## 0.6.0
- Testmodus mit Beispielanzeige für alle Klassen und Skillungen; Buttons frei platzierbar.

## 0.5.0
- Reinigungsleiste für Mitspieler und Entzaubern von Gegnern.

## 0.4.0
- Erste Version: Proc-Buttons, Buff-Wächter mit Ein-Klick-Buff, Cooldown-Leiste, Skillungserkennung, alle WoW-Versionen.
