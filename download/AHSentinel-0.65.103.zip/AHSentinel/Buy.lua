if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 0.59.13 - Einkauf (Logik) - wie der Kaufen-Reiter des Auktionshauses
--
-- * Suche nach Name und/oder Kategorie, Stufe von/bis, Seltenheit
--   -> Liste der Items mit günstigstem Preis und verfügbarer Menge
-- * Item anklicken -> alle Angebote
--   - Waren: Menge wählen, Preis vom Server holen, Kauf bestätigen
--   - Einzelangebote (Ausrüstung): Sofortkauf oder Gebot
-- * Gekauft wird nur per Klick (das verlangt WoW selbst).
-- * Läuft über A.AH - also auch mit dem klassischen Auktionshaus.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
-- Retail 12.x: die alten Item-/Zauber-Funktionen gibt es nur noch in C_Item / C_Spell
local GetItemInfo = GetItemInfo or (C_Item and C_Item.GetItemInfo)
local GetItemInfoInstant = GetItemInfoInstant or (C_Item and C_Item.GetItemInfoInstant)
local GetDetailedItemLevelInfo = GetDetailedItemLevelInfo or (C_Item and C_Item.GetDetailedItemLevelInfo)
local A = AHAnalyzerPro
local L = A.L

local B = {}
A.Buy = B

local TIMEOUT = 10              -- Sekunden, bis eine Suche als ergebnislos gilt
local MAX_PAGES = 20            -- höchstens so viele Ergebnisseiten
local PRICE_WAIT = 6            -- so lange auf die Preisbestätigung des Servers warten
local SORTS = { { sortOrder = 0, reverseSort = false } }

local CLASS = (Enum and Enum.ItemClass) or {}
local TRADE = CLASS.Tradegoods or 7

-- Kategorien wie im Auktionshaus (level = Einrückung). Feste Liste nur als Rückfall, wenn das Spiel keine
-- Kategorien liefert; sonst baut B:BuildCategories() Haupt- und Unterkategorien mit Namen und Reihenfolge aus dem Spiel.
B.BASE_CATS = {
    { key = "all",        label = "Alle",                  filters = nil },
    { key = "weapon",     label = "Waffen",                filters = { { CLASS.Weapon or 2 } } },
    { key = "armor",      label = "Rüstung",               filters = { { CLASS.Armor or 4 } } },
    { key = "container",  label = "Behälter",              filters = { { CLASS.Container or 1 } } },
    { key = "consumable", label = "Verbrauchbares",        filters = { { CLASS.Consumable or 0 } } },
    { key = "trade",      label = "Handwerkswaren",        filters = { { TRADE } } },
    { key = "cloth",      label = "Stoff",                 filters = { { TRADE, 5 } }, level = 1 },
    { key = "leather",    label = "Leder",                 filters = { { TRADE, 6 } }, level = 1 },
    { key = "metal",      label = "Metall & Stein",        filters = { { TRADE, 7 } }, level = 1 },
    { key = "herb",       label = "Kräuter",               filters = { { TRADE, 9 } }, level = 1 },
    { key = "cooking",    label = "Kochzutaten",           filters = { { TRADE, 8 } }, level = 1 },
    { key = "elemental",  label = "Elementar",             filters = { { TRADE, 10 } }, level = 1 },
    { key = "enchanting", label = "Verzauberungsmaterial", filters = { { TRADE, 12 } }, level = 1 },
    { key = "gems",       label = "Edelsteine",            filters = { { CLASS.Gem or 3 } } },
    { key = "recipe",     label = "Rezepte",               filters = { { CLASS.Recipe or 9 } } },
    { key = "misc",       label = "Verschiedenes",         filters = { { CLASS.Miscellaneous or 15 } } },
}
B.CATS = B.BASE_CATS

-- bisherige Schlüssel bleiben gleich (Favoriten, Post-Regeln): [Klasse] bzw. [Klasse.Unterklasse] -> Schlüssel
local OLD_KEYS = { [CLASS.Weapon or 2] = "weapon", [CLASS.Armor or 4] = "armor", [CLASS.Container or 1] = "container",
    [CLASS.Consumable or 0] = "consumable", [TRADE] = "trade", [CLASS.Gem or 3] = "gems", [CLASS.Recipe or 9] = "recipe",
    [CLASS.Miscellaneous or 15] = "misc",
    [TRADE .. ".5"] = "cloth", [TRADE .. ".6"] = "leather", [TRADE .. ".7"] = "metal", [TRADE .. ".9"] = "herb",
    [TRADE .. ".8"] = "cooking", [TRADE .. ".10"] = "elemental", [TRADE .. ".12"] = "enchanting" }
-- Reihenfolge der Hauptkategorien im Blizzard-AH (nur Rückfall ohne AuctionCategories)
local CLASS_ORDER = { 2, 4, 1, 3, 8, 0, 16, 7, 9, 17, 12, 15 }
-- Classic-Inhalte (Era, TBC, WoW Forever): Reihenfolge des klassischen AH, mit Projektil, Köcher, Reagenz
local CLASS_ORDER_CLASSIC = { 2, 4, 1, 0, 7, 6, 11, 9, 5, 15, 12 }
local function ClassOrder()
    if A.AH_LEGACY or A:IsForever() then return CLASS_ORDER_CLASSIC end
    return CLASS_ORDER
end
B.ClassOrder = ClassOrder      -- nur lesen (Testroutine T200)

-- Schlüssel NUR aus Klasse/Unterklasse (nie aus inventoryType oder der Anzahl Filter): so ist er in beiden Quellen
-- (AuctionCategories und Item-Klassen) gleich, und Post-Regeln finden ihre Kategorie auch nach /reload ohne AH-Besuch.
local function CatKey(f)
    if not f then return nil end
    local k = (f[2] == nil) and OLD_KEYS[f[1]] or OLD_KEYS[f[1] .. "." .. tostring(f[2])]
    if k then return k end
    return "c" .. f[1] .. (f[2] and ("_" .. f[2]) or "")
end
-- Schlüssel einer Gruppe von Filtern: eine Klasse + eine Unterklasse -> wie CatKey; mehrere Unterklassen derselben
-- Klasse -> sortierte Liste ("c2_0-4-7"); verschiedene Klassen oder fehlende Unterklasse -> Schlüssel der ersten Klasse
local function GroupKey(fs)
    if not (fs and fs[1]) then return nil end
    local cl, subs, seen = fs[1][1], {}, {}
    for _, f in ipairs(fs) do
        if f[1] ~= cl or f[2] == nil then return CatKey({ cl }) end
        if not seen[f[2]] then seen[f[2]] = true; subs[#subs + 1] = f[2] end
    end
    if #subs == 1 then return CatKey({ cl, subs[1] }) end
    table.sort(subs)
    return "c" .. cl .. "_" .. table.concat(subs, "-")
end
-- Hauptkategorie: immer der Schlüssel der Klasse (wie im Rückfall), nur ein einzelner Filter mit Unterklasse behält sie
local function MainKey(fs)
    if not (fs and fs[1]) then return nil end
    if #fs == 1 then return CatKey({ fs[1][1], fs[1][2] }) end
    return CatKey({ fs[1][1] })
end
B.CatKey, B.GroupKey, B.MainKey = CatKey, GroupKey, MainKey      -- nur lesen (Testroutine T200)

local function SubClasses(classID)
    -- Unterklassen in der Reihenfolge des Auktionshauses (modern als Tabelle, alt als einzelne Werte)
    for _, fn in ipairs({ C_AuctionHouse and C_AuctionHouse.GetAuctionItemSubClasses or false, GetAuctionItemSubClasses or false }) do
        if fn then
            local ok, a = pcall(function() return { fn(classID) } end)
            if ok and type(a) == "table" then
                if type(a[1]) == "table" then a = a[1] end
                if #a > 0 then return a end
            end
        end
    end
    return {}
end
local function Call(fn, ...)
    if not fn then return nil end
    local ok, r = pcall(fn, ...)
    if ok then return r end
    return nil
end
local function ClassName(classID, subClassID)
    local I = C_Item
    if subClassID then return Call((I and I.GetItemSubClassInfo) or GetItemSubClassInfo, classID, subClassID) end
    return Call((I and I.GetItemClassInfo) or GetItemClassInfo, classID)
end

-- Kategorien aus dem Spiel. Quelle 1: AuctionCategories (Blizzard-AH, ab dem ersten Öffnen geladen) -
-- genau die Namen, Filter und Reihenfolge des Blizzard-AH. Quelle 2: Item-Klassen und Unterklassen des Spiels.
-- Bis zu zwei Unterebenen wie im Blizzard-AH (z. B. Waffen -> Einhändig -> Äxte); die dritte Ebene erscheint nur
-- unter der gewählten zweiten. Nahtstelle für die Testroutine: B.testCategories statt _G.AuctionCategories.
function B:BuildCategories()
    local out = { { key = "all", label = "Alle", filters = nil } }
    local seen = {}
    local function add(c)
        if not c.key then return nil end
        local base, n = c.key, 1
        while seen[c.key] do n = n + 1; c.key = base .. "_" .. n end     -- Schlüssel eindeutig halten
        seen[c.key] = true
        table.insert(out, c)
        return c
    end
    local function filtersOf(cat)
        local fs = {}
        for _, f in ipairs(cat.filters or {}) do
            if type(f) == "table" and f.classID then table.insert(fs, { f.classID, f.subClassID, f.inventoryType }) end
        end
        return fs
    end
    local AC = self.testCategories or _G.AuctionCategories
    if type(AC) == "table" and #AC > 0 then
        for _, cat in ipairs(AC) do
            local fs = filtersOf(cat)
            -- nur Kategorien mit Item-Klassen-Filter (keine WoW-Marke o. Ä.)
            if cat.name and #fs > 0 and not cat.implicitFilter then
                local main = add({ key = MainKey(fs), text = cat.name, label = cat.name, filters = fs, game = true })
                for _, sub in ipairs(cat.subCategories or {}) do
                    local sf = filtersOf(sub)
                    if sub.name and #sf > 0 then
                        local s1 = add({ key = GroupKey(sf), text = sub.name, label = sub.name,
                              filters = sf, level = 1, parent = main.key, game = true })
                        for _, sub2 in ipairs(sub.subCategories or {}) do
                            local sf2 = filtersOf(sub2)
                            if sub2.name and #sf2 > 0 then
                                add({ key = GroupKey(sf2), text = sub2.name, label = sub2.name,
                                      filters = sf2, level = 2, parent = s1.key, game = true })
                            end
                        end
                    end
                end
            end
        end
    else
        for _, classID in ipairs(ClassOrder()) do
            local name = ClassName(classID)
            if name and name ~= "" then
                local main = add({ key = CatKey({ classID }), text = name, label = name, filters = { { classID } }, game = true })
                for _, sub in ipairs(SubClasses(classID)) do
                    local sname = type(sub) == "number" and ClassName(classID, sub)
                    if sname and sname ~= "" then
                        add({ key = CatKey({ classID, sub }), text = sname, label = sname, filters = { { classID, sub } },
                              level = 1, parent = main.key, game = true })
                    end
                end
            end
        end
    end
    if #out < 4 then self.CATS = self.BASE_CATS; self.catsFromGame = "fest"; return false end   -- Spiel liefert nichts: feste Liste
    self.CATS = out
    self.catsFromGame = (type(AC) == "table" and #AC > 0) and "AuctionCategories" or "ItemClass"
    A:Fire("BUY_CATEGORIES_CHANGED")
    return true
end

-- Anzeige-Name einer Kategorie (Spiel-Namen schon in der Sprache des Clients)
function B:CatText(c)
    if not c then return "" end
    return c.text or L[c.label]
end

-- sichtbare Liste: alle Hauptkategorien, Unterkategorien nur unter der gewählten (wie im Blizzard-AH)
function B:VisibleCats(selectedKey)
    local byKey = {}
    for _, c in ipairs(self.CATS) do byKey[c.key] = c end
    local sel = byKey[selectedKey]
    -- offene Hauptkategorie und offene Unterkategorie (Ebene 1) der Auswahl
    local open, openSub
    if sel then
        if sel.level == 2 then openSub = sel.parent; open = byKey[sel.parent] and byKey[sel.parent].parent
        elseif sel.level == 1 then openSub = sel.key; open = sel.parent
        else open = sel.key end
    end
    local out = {}
    for _, c in ipairs(self.CATS) do
        if not c.level or not c.parent then table.insert(out, c)
        elseif c.level == 1 and c.parent == open then table.insert(out, c)
        elseif c.level == 2 and openSub and c.parent == openSub then table.insert(out, c) end
    end
    return out
end

B.search = nil          -- laufende Suche (browse oder items)
B.wanted = nil          -- Suche wartet, bis andere Suchen fertig sind
B.results = {}          -- Items der letzten Suche
B.detail = nil          -- gewähltes Item mit Angeboten
B.pending = nil         -- Warenkauf: Preis vom Server angefragt / bestätigt
B.lastPurchase = nil

local function Now() return GetTime() end

local function SafeCall(fn, ...)
    if not fn then return nil end
    local ok, a = pcall(fn, ...)
    if ok then return a end
    if A.ReportOnce then A:ReportOnce(fn, "SafeCall:Buy", a) end
    return nil
end

local function Changed() A:Fire("BUY_CHANGED") end

-- Ergebnisse je Suche merken: zwischen Kategorien hin und her wechseln geht dann sofort
local CACHE_SECS = 180
B.cache = {}

local function QueryKey(q)
    local quals = {}
    if q.quals then for k, on in pairs(q.quals) do if on then table.insert(quals, k) end end end
    table.sort(quals)
    return table.concat({ string.lower(q.text or ""), q.cat or "all", q.minLevel or "", q.maxLevel or "",
        q.quals and table.concat(quals, ",") or "*" }, "|")
end
B.QueryKey = QueryKey

-- ------------------------------------------------------------
-- Zustand
-- ------------------------------------------------------------
function B:IsBusy()
    return self.search ~= nil
end

function B:HasPending()
    return self.pending ~= nil
end

-- sollen Sniper, Preisprüfung und Wächter gerade warten? (Klicks im Einkauf haben Vorrang)
function B:Blocks()
    return self.search ~= nil or self.wanted ~= nil or self.pending ~= nil
end

-- warten andere Teile des Addons gerade auf eigene Suchergebnisse?
function B:OthersBusy()
    if A:IsScanning() then return L["Warte, bis der Markt-Scan fertig ist."] end
    local Sn = A.Sniper
    if Sn and (Sn:IsBusy() or (Sn.pending and not Sn.pending.auto)) then return L["Warte auf den Sniper ..."] end
    if A.Seller and A.Seller:IsBusy() then return L["Warte auf die Preisprüfung ..."] end
    if A.Watcher and A.Watcher:IsBusy() then return L["Warte auf den Wächter ..."] end
    return nil
end

function B:CatLabel(key)
    for _, c in ipairs(self.CATS) do if c.key == key then return self:CatText(c) end end
    return ""
end

-- gewählte Seltenheiten (nil = alle) -> Filter für die Suche
local function QualityFilters(quals)
    local out = {}
    if not quals or not (Enum and Enum.AuctionHouseFilter) then return out end
    local names = { [0] = "PoorQuality", "CommonQuality", "UncommonQuality", "RareQuality", "EpicQuality", "LegendaryQuality" }
    for q = 0, 5 do
        local v = quals[q] and names[q] and Enum.AuctionHouseFilter[names[q]]
        if v then table.insert(out, v) end
    end
    return out
end

local function ClassFilters(cat)
    local out = {}
    for _, c in ipairs(B.CATS) do
        if c.key == cat and c.filters then
            for _, f in ipairs(c.filters) do table.insert(out, { classID = f[1], subClassID = f[2], inventoryType = f[3] }) end
        end
    end
    return out
end

-- ------------------------------------------------------------
-- Suche (Liste der Items)
-- q = { text, cat, minLevel, maxLevel, quals = { [Qualität] = true } oder nil }
-- ------------------------------------------------------------
-- force = true: nicht aus dem Zwischenspeicher, sondern neu beim Server fragen (Knopf "Suchen")
function B:Search(q, force)
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    if not (A.AH and A.AH.SendBrowseQuery) then return false, L["Dein Client unterstützt die Auktionshaus-Suche nicht (SendBrowseQuery fehlt)."] end
    q = q or {}
    q.text = (q.text or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if q.text == "" and (not q.cat or q.cat == "all") and not q.minLevel and not q.maxLevel and not q.quals
        and not q.minIlvl and not q.maxIlvl then
        return false, L["Suchbegriff eingeben oder links eine Kategorie wählen."]
    end
    -- laufende Suche abbrechen: die neue hat Vorrang (nicht erst alle Seiten der alten abwarten)
    if self.search and self.search.kind == "browse" then
        if A.AH.AbortBrowse then pcall(A.AH.AbortBrowse) end
        self.search = nil
    end
    self.lastUse = Now()
    self.lastQuery = q
    self.detail = nil
    self.partial = nil
    -- vor kurzem schon gesucht: sofort anzeigen
    local c = self.cache[QueryKey(q)]
    if not force and c and Now() - c.t < CACHE_SECS then
        self.wanted = nil
        self.results, self.resultsTime = c.results, c.time
        self.message = (#c.results == 0) and L["Keine Angebote gefunden."] or nil
        Changed()
        return true, string.format(L["Stand von vor %d Sek. - 'Suchen' lädt neu."], math.floor(Now() - c.t))
    end
    self.snapshot = self:Snapshot(q)
    self.snapshotTime = A.db and A.db.lastScanTime
    self.wanted = { kind = "browse", q = q }
    self:TryStart()
    Changed()
    return true, self.search and L["Suche läuft ..."] or (self:OthersBusy() or L["Suche läuft ..."])
end

-- Angebote eines Items laden
-- S8 (Befund 11.11., Einkauf "~"-Zeilen, Detail leer): Zeilen aus dem Scan haben keinen echten itemKey (Itemstufe/Suffix).
-- Vor der Detailsuche einmal per Browse (Name) den itemKey aus GetBrowseResults holen; findet auch Browse das Item nicht,
-- ist die Zeile veraltet: sofort aus der Liste und aus "Entzaubern lohnt", und die Scan-Quelle zeigt sie erst wieder,
-- wenn ein neuerer Scan das Item führt (B.goneScan).
B.goneScan = B.goneScan or {}
function B:ScanRow(itemID)
    for _, r in ipairs(self.results or {}) do
        if r.itemID == itemID and r.fromScan then return r end
    end
    return nil
end
function B:MarkGoneScan(itemID, why)
    self.goneScan[itemID] = time()
    self:MarkGone(itemID, { qty = math.huge })
    self.message = L["Keine Angebote mehr – aus der Liste genommen"]
    if A.Diag then pcall(A.Diag.Add, A.Diag, "DETAIL-LEER", string.format("Item %d · Zeile aus dem Scan · %s · aus der Liste genommen", itemID, tostring(why or "-"))) end
end

function B:Open(itemKey, name)
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    -- S8: Zeile aus dem Scan (nur Item-ID) -> erst den echten itemKey über Browse holen (nicht im alten AH: dort keine Keys)
    if type(itemKey) == "number" and not A.AH_LEGACY and A.AH.SendBrowseQuery and self:ScanRow(itemKey) then
        local id = itemKey
        local row = self:ScanRow(id)
        self:CancelPending()
        self.lastUse = Now()
        local nm = name or A:GetItemName(id)
        local age = row and row.fromScan and math.max(0, time() - row.fromScan) or nil
        self.detail = { itemKey = { itemID = id, itemLevel = 0, itemSuffix = 0, battlePetSpeciesID = 0 }, itemID = id, name = nm, listings = {}, loading = true,
            probing = true, scanAge = age }
        self.wanted = { kind = "browse", q = { text = A:GetClientItemName(id) or nm or "" }, probeFor = id, scanAge = age }
        self:TryStart()
        Changed()
        return true
    end
    if type(itemKey) == "number" then itemKey = (A.AH.MakeItemKey and SafeCall(A.AH.MakeItemKey, itemKey)) or { itemID = itemKey, itemLevel = 0, itemSuffix = 0, battlePetSpeciesID = 0 } end
    self:CancelPending()
    self.lastUse = Now()
    -- laufende Kategorie-Suche abbrechen, damit die Angebote sofort geladen werden
    if self.search and self.search.kind == "browse" then
        if A.AH.AbortBrowse then pcall(A.AH.AbortBrowse) end
        self.results = self.partial or self.snapshot or self.results
        self.search, self.partial, self.snapshot = nil, nil, nil
    end
    if self.wanted and self.wanted.kind == "browse" then
        self.results = self.snapshot or self.results
        self.wanted, self.snapshot = nil, nil
    end
    self.detail = { itemKey = itemKey, itemID = itemKey.itemID, name = name or A:GetItemName(itemKey.itemID), listings = {}, loading = true }
    self.wanted = { kind = "items", itemKey = itemKey }
    self:TryStart()
    Changed()
    return true
end

function B:Back()
    self:CancelPending()
    self.detail = nil
    if self.wanted and self.wanted.kind == "items" then self.wanted = nil end
    Changed()
end

function B:Refresh()
    if self.detail then return self:Open(self.detail.itemKey, self.detail.name) end
    if self.lastQuery then return self:Search(self.lastQuery) end
    return false
end

-- gewünschte Suche starten, sobald alles frei ist
function B:TryStart()
    local w = self.wanted
    if not w or self.search then return end
    if not A:IsAHOpen() then self.wanted = nil; return end
    -- Was du selbst suchst, geht vor: eine laufende Wächter-Runde wird abgebrochen
    -- (sonst wartet der Einkauf, solange der Wächter an ist)
    if A.Watcher and A.Watcher:IsBusy() and not A:IsScanning() then
        pcall(A.Watcher.Abort, A.Watcher)
        if A.AH and A.AH.AbortBrowse then pcall(A.AH.AbortBrowse) end
    end
    if self:OthersBusy() or not A:CanQueryNow() then return end
    -- vorab reservierter Sniper-Preis würde von der Suche nicht gestört, ein eigener Kauf schon
    self.wanted = nil
    local ok, err
    if w.kind == "browse" then
        local q = w.q
        ok, err = pcall(A.AH.SendBrowseQuery, {
            searchString = q.text or "",
            sorts = SORTS,
            filters = QualityFilters(q.quals),
            itemClassFilters = ClassFilters(q.cat),
            minLevel = q.minLevel or 0,
            maxLevel = q.maxLevel or 0,
        })
    else
        ok, err = pcall(A.AH.SendSearchQuery, w.itemKey, SORTS, true)
    end
    A:NoteQuery()
    if not ok then
        A:QueryError()
        self.message = L["Suche fehlgeschlagen: "] .. tostring(err)
        if self.detail then self.detail.loading = false end
        Changed()
        return
    end
    self.message = nil
    self.search = { kind = w.kind, q = w.q, itemKey = w.itemKey, started = Now(), lastCount = -1, lastChange = Now(), pages = 0,
        probeFor = w.probeFor, scanAge = w.scanAge }
    Changed()
end

-- ------------------------------------------------------------
-- Ergebnisse lesen
-- ------------------------------------------------------------
local function ItemInfo(itemID)
    if not GetItemInfo then return nil end
    local ok, name, _, quality, ilvl, req, _, _, stack = pcall(GetItemInfo, itemID)
    if ok and name then return quality, ilvl, req, stack end
    return nil
end

local function ReadBrowse(q)
    local out = {}
    for _, r in ipairs(SafeCall(A.AH.GetBrowseResults) or {}) do
        local key = r.itemKey
        local id = type(key) == "table" and key.itemID
        if id then
            local quality, ilvl, req = ItemInfo(id)
            local keep = true
            if q and q.quals and quality and not q.quals[quality] then keep = false end
            if keep then
                table.insert(out, {
                    itemKey = key, itemID = id, name = A:GetItemName(id),
                    price = r.minPrice, qty = r.totalQuantity or 0,
                    quality = quality, ilvl = (key.itemLevel and key.itemLevel > 0) and key.itemLevel or ilvl, req = req,
                    pct = r.minPrice and A:GetMarketPercent(id, r.minPrice) or nil,
                    own = r.containsOwnerItem,
                })
            end
        end
    end
    return out
end

-- S8: Ergebnis der Browse-Gegenprobe für eine Scan-Zeile
function B:ProbeDone(s)
    local id = s.probeFor
    local found, n = nil, 0
    for _, r in ipairs(ReadBrowse(nil)) do
        if r.itemID == id then
            n = n + 1
            if not found or (r.price and found.price and r.price < found.price) then found = r end
        end
    end
    local d = self.detail
    if A.Diag then
        pcall(A.Diag.Add, A.Diag, "DETAIL-PROBE", string.format("Item %d · Quelle Scan (Alter %s Min.) · Browse %d Treffer%s", id,
            s.scanAge and tostring(math.floor(s.scanAge / 60)) or "?", n,
            found and type(found.itemKey) == "table" and string.format(" · itemKey %s/%s", tostring(found.itemKey.itemLevel or 0), tostring(found.itemKey.itemSuffix or 0)) or ""))
    end
    if found and type(found.itemKey) == "table" then
        -- Zeile bekommt den echten itemKey (und den Live-Preis), dann die Detailsuche damit
        for _, r in ipairs(self.results or {}) do
            if r.itemID == id and r.fromScan then r.itemKey, r.fromScan, r.price, r.qty = found.itemKey, nil, found.price or r.price, found.qty or r.qty end
        end
        if d and d.itemID == id then return self:Open(found.itemKey, d.name) end
        Changed()
        return true
    end
    self:MarkGoneScan(id, string.format("Browse 0 Treffer, Scan-Alter %s Min.", s.scanAge and tostring(math.floor(s.scanAge / 60)) or "?"))
    if d and d.itemID == id then d.loading, d.probing, d.listings, d.time = false, nil, {}, time() end
    Changed()
    return false
end

-- ------------------------------------------------------------
-- Sofort-Anzeige aus dem letzten Markt-Scan: Das alte Auktionshaus liefert nur 50 Angebote
-- pro Abfrage und sperrt zwischen den Seiten einige Sekunden. Damit man nicht warten muss,
-- zeigen wir sofort, was der letzte Scan kennt - die Live-Suche ersetzt es Seite für Seite.
-- ------------------------------------------------------------
local SNAPSHOT_MAX_AGE = 24 * 3600     -- ältere Scan-Preise nicht mehr zeigen
local classCache = {}                   -- [itemID] = { classID, subClassID, quality, req, ilvl } oder false

local function ItemClassInfo(id)
    local c = classCache[id]
    if c then return c end
    local classID, subClassID, quality, req, ilvl
    if GetItemInfo then
        local ok, name, _, q, il, rq, _, _, _, _, _, _, cl, sc = pcall(GetItemInfo, id)
        if ok and name then quality, ilvl, req, classID, subClassID = q, il, rq, cl, sc end
    end
    if not classID and GetItemInfoInstant then
        -- Klasse kennt der Client auch ohne geladene Item-Daten
        local ok, _, _, _, _, _, cl, sc = pcall(GetItemInfoInstant, id)
        if ok then classID, subClassID = cl, sc end
    end
    if not classID then return nil end
    c = { classID, subClassID, quality, req, ilvl }
    if quality then classCache[id] = c end              -- vollständig: merken
    return c
end

local function CatMatches(cat, classID, subClassID)
    if not cat or not cat.filters then return true end
    for _, f in ipairs(cat.filters) do
        if classID == f[1] and (f[2] == nil or subClassID == f[2]) then return true end
    end
    return false
end

function B:Snapshot(q)
    local out = {}
    local db = A.db and A.db.marketData
    if not db then return out end
    local cat
    if q.cat and q.cat ~= "all" then
        for _, c in ipairs(self.CATS) do if c.key == q.cat then cat = c end end
    end
    local text = string.lower(q.text or "")
    local cutoff = time() - SNAPSHOT_MAX_AGE
    for id in pairs(db) do
        local price, qty, t = A:GetCurrent(id)
        local gone = B.goneScan[id]
        if gone and t and t > gone then B.goneScan[id] = nil; gone = nil end     -- S8: neuerer Scan führt das Item wieder
        if price and price > 0 and t and t >= cutoff and not gone then
            local info = ItemClassInfo(id)
            local keep = info ~= nil
            if keep and cat then keep = CatMatches(cat, info[1], info[2]) end
            if keep and q.quals and info[3] and not q.quals[info[3]] then keep = false end
            if keep and q.minLevel and (info[4] or 0) < q.minLevel then keep = false end
            if keep and q.maxLevel and (info[4] or 0) > q.maxLevel then keep = false end
            local name
            if keep then
                name = A:GetItemName(id)
                if text ~= "" then
                    local client = A:GetClientItemName(id)
                    keep = (name and string.lower(name):find(text, 1, true))
                        or (client and string.lower(client):find(text, 1, true)) or false
                end
            end
            if keep then
                table.insert(out, {
                    itemKey = id, itemID = id, name = name, price = price, qty = qty or 0,
                    quality = info[3], ilvl = info[5], req = info[4],
                    pct = A:GetMarketPercent(id, price), fromScan = t,
                })
            end
        end
    end
    return out
end

-- Live-Ergebnisse gehen vor, Scan-Einträge füllen auf
local function Merge(snapshot, live)
    if not snapshot or #snapshot == 0 then return live end
    local out, seen = {}, {}
    for _, r in ipairs(live) do seen[r.itemID] = true; table.insert(out, r) end
    for _, r in ipairs(snapshot) do if not seen[r.itemID] then table.insert(out, r) end end
    return out
end

local function ReadListings(itemKey)
    local C = A.AH
    local id = itemKey.itemID
    local out = {}
    local nCom = SafeCall(C.GetNumCommoditySearchResults, id) or 0
    if nCom > 0 then
        for i = 1, nCom do
            local info = SafeCall(C.GetCommoditySearchResultInfo, id, i)
            if i == 1 and A.Forecast then pcall(A.Forecast.NoteM2, A.Forecast, "com", info) end      -- Messauftrag M2
            if type(info) == "table" and info.unitPrice and info.unitPrice > 0 then
                local ownQty = info.numOwnerItems or (info.containsOwnerItem and info.quantity) or 0
                table.insert(out, { price = info.unitPrice, qty = info.quantity or 1, own = ownQty > 0, ownQty = ownQty })
            end
        end
        table.sort(out, function(a, b) return a.price < b.price end)
        A:FilterDead(id, out)                    -- S7: tote Angebote zählen nirgends
        A:MarkBait(out)
        return out, true
    end
    local n = SafeCall(C.GetNumItemSearchResults, itemKey) or 0
    for i = 1, n do
        local info = SafeCall(C.GetItemSearchResultInfo, itemKey, i)
        if i == 1 and A.Forecast then pcall(A.Forecast.NoteM2, A.Forecast, "item", info) end      -- Messauftrag M2
        if type(info) == "table" then
            local qty = info.quantity or 1
            local buyout = (info.buyoutAmount and info.buyoutAmount > 0) and info.buyoutAmount or nil
            local ilvl
            if info.itemLink and GetDetailedItemLevelInfo then ilvl = SafeCall(GetDetailedItemLevelInfo, info.itemLink) end
            table.insert(out, {
                auctionID = info.auctionID, qty = qty, buyout = buyout,
                price = buyout and math.floor(buyout / math.max(1, qty)) or nil,
                bid = info.bidAmount, minBid = info.minBid, link = info.itemLink, ilvl = info.itemKey and info.itemKey.itemLevel or ilvl,
                own = info.containsOwnerItem or false, timeLeft = info.timeLeftSeconds,
                hasBidder = (info.bidder ~= nil) or nil,
            })
            if A.NoteBid and info.minBid and info.minBid > 0 and not info.containsOwnerItem then
                A:NoteBid(id, info.minBid, qty, info.timeLeftSeconds, buyout, false)
            end
        end
    end
    -- Sofortkauf zuerst nach Preis, reine Gebote ans Ende
    table.sort(out, function(a, b)
        if (a.price ~= nil) ~= (b.price ~= nil) then return a.price ~= nil end
        if a.price and b.price and a.price ~= b.price then return a.price < b.price end
        return (a.bid or a.minBid or 0) < (b.bid or b.minBid or 0)
    end)
    A:FilterDead(id, out)                        -- S7
    return out, false
end

local function ItemFull(itemKey)
    local C = A.AH
    if SafeCall(C.HasFullCommoditySearchResults, itemKey.itemID) then return true end
    return SafeCall(C.HasFullItemSearchResults, itemKey) == true
end

function B:Poll()
    local s = self.search
    if not s then return end
    if not A:IsAHOpen() then self.search = nil; return end
    local now = Now()
    local timedOut = now - s.started > TIMEOUT

    if s.kind == "browse" then
        local C = A.AH
        local count = SafeCall(C.GetNumBrowseResults) or #(SafeCall(C.GetBrowseResults) or {})
        -- Altes AH: Fortschritt an den erhaltenen Seiten messen - eine neue Seite bringt oft
        -- keine neuen Items (gleiche Items, weitere Angebote), ist aber trotzdem Fortschritt
        local gotPages, totalPages
        if C.GetBrowseProgress then gotPages, totalPages = C.GetBrowseProgress() end
        local sig = gotPages and (count .. ":" .. gotPages) or count
        if sig ~= s.lastCount then
            s.lastCount, s.lastChange, s.waitingMore = sig, now, false
            s.progress = gotPages and totalPages and totalPages > 1 and { gotPages, math.min(totalPages, MAX_PAGES) } or nil
            -- Zwischenstand schon anzeigen (nicht bei der S8-Gegenprobe: die Liste bleibt, wie sie ist)
            if count > 0 and not s.probeFor then
                self.partial = Merge(self.snapshot, ReadBrowse(s.q))
                Changed()
            end
        end
        local full = SafeCall(C.HasFullBrowseResults)
        if count > 0 and full == false and not s.waitingMore and s.pages < MAX_PAGES and A:QueryReady() and C.RequestMoreBrowseResults then
            if pcall(C.RequestMoreBrowseResults) then
                s.pages, s.waitingMore = s.pages + 1, true
                return
            end
        end
        local done
        if A.AH_LEGACY then
            -- Altes AH: jede Seite muss einzeln abgefragt werden, dazwischen sperrt der Server
            -- für ein paar Sekunden. Nicht vorzeitig aufhören, sonst fehlen z.B. alle blauen
            -- und weißen Items (die Liste kommt nach Seltenheit sortiert).
            done = (count > 0 and (full == true or s.pages >= MAX_PAGES))
                or (count > 0 and now - s.lastChange >= 15)
                or (count == 0 and s.answered and now - s.lastChange >= 0.5)
                or (count == 0 and timedOut)
        else
            done = (count > 0 and (full == true or s.pages >= MAX_PAGES or (not s.waitingMore and now - s.lastChange >= 1)))
                or (count > 0 and s.waitingMore and now - s.lastChange >= 3)
                or (count == 0 and s.answered and now - s.lastChange >= 0.5)
                or timedOut
        end
        if not done then return end
        self.search, self.partial = nil, nil
        if s.probeFor then return self:ProbeDone(s) end
        local live = ReadBrowse(s.q)
        -- nur vollständige Antworten merken (keine abgebrochenen oder leeren Fehlversuche)
        local complete = full == true or (not A.AH_LEGACY and not timedOut)
        -- vollständig: nur, was jetzt wirklich im Auktionshaus ist; sonst mit Scan-Daten auffüllen
        self.results = complete and live or Merge(self.snapshot, live)
        self.snapshot = nil
        self.resultsTime = time()
        if #self.results > 0 and complete then
            self.cache[QueryKey(s.q)] = { results = self.results, t = Now(), time = self.resultsTime }
        end
        self.message = (#self.results == 0) and L["Keine Angebote gefunden."] or nil
        Changed()
        return
    end

    local okRead, listings, commodity = pcall(ReadListings, s.itemKey)
    if not okRead then listings, commodity = {}, false end
    local count = #listings
    if count ~= s.lastCount then s.lastCount, s.lastChange = count, now end
    local full = ItemFull(s.itemKey)
    local done = (full and (count > 0 or s.answered or now - s.started >= 1))
        or (count > 0 and now - s.lastChange >= 0.75)
        or timedOut
    if not done then return end
    self.search = nil
    local d = self.detail
    -- K6 (Nachtrag 08:45): Detailsuche leer, obwohl der Scan das Item führt -> einmal mit dem allgemeinen itemKey
    -- (ohne Itemstufe/Suffix) nachladen; bleibt es leer, Zeile aus der Einkaufsliste und Protokoll DETAIL-LEER
    if d and d.itemID == s.itemKey.itemID and count == 0 and not commodity then
        local k = s.itemKey
        local special = (k.itemLevel or 0) ~= 0 or (k.itemSuffix or 0) ~= 0
        local plain = special and A.AH.MakeItemKey and SafeCall(A.AH.MakeItemKey, k.itemID)
        if plain and not d.retried then
            d.retried, d.scanKey = true, k
            self.wanted = { kind = "items", itemKey = plain }
            self:TryStart()
            Changed()
            return
        end
        if A.Diag then
            local sk = d.scanKey or k
            pcall(A.Diag.Add, A.Diag, "DETAIL-LEER", string.format("Item %d · itemKey Scan %s/%s · Detail %s/%s · Treffer 0",
                k.itemID, tostring(sk.itemLevel or 0), tostring(sk.itemSuffix or 0), tostring(k.itemLevel or 0), tostring(k.itemSuffix or 0)))
        end
        self:MarkGone(k.itemID, { qty = math.huge })
        self.goneScan[k.itemID] = time()                -- S8: auch die Scan-Quelle bis zum nächsten Scan
        self.message = L["Keine Angebote mehr – aus der Liste genommen"]
    end
    if d and d.itemID == s.itemKey.itemID then
        d.listings, d.commodity, d.loading, d.time = listings, commodity, false, time()
        -- günstigsten echten Preis (ohne Lockangebote) in den Preisverlauf
        local first, total = nil, 0
        for _, l in ipairs(listings) do
            if not l.bait and l.price then
                first = first or l
                total = total + l.qty
            end
        end
        if first then A:VerifyPrice(d.itemID, first.price, total) end
        if d.commodity then
            d.qty = math.min(d.qty or 1, math.max(1, self:Available()))
        end
    end
    Changed()
    A:Fire("DATA_CHANGED")
end

-- ------------------------------------------------------------
-- Waren kaufen: Menge -> Preis vom Server -> bestätigen
-- ------------------------------------------------------------
-- kaufbare Menge (ohne eigene Angebote)
function B:Available()
    local d = self.detail
    if not (d and d.commodity) then return 0 end
    local n = 0
    for _, l in ipairs(d.listings) do n = n + math.max(0, l.qty - (l.ownQty or 0)) end
    return n
end

-- Kosten für qty Stück (günstigste zuerst, wie der Server) -> total, Stückpreis Ø, höchster Preis, Lockstücke
function B:Quote(qty)
    local d = self.detail
    if not (d and d.commodity) or not qty or qty < 1 then return nil end
    local left, total, top, bait = qty, 0, 0, 0
    for _, l in ipairs(d.listings) do
        if left <= 0 then break end
        local avail = math.max(0, l.qty - (l.ownQty or 0))
        local n = math.min(left, avail)
        if n > 0 then
            total = total + n * l.price
            top = l.price
            if l.bait then bait = bait + n end
            left = left - n
        end
    end
    if left > 0 then return nil end
    return total, total / qty, top, bait
end

function B:SetQuantity(qty)
    local d = self.detail
    if not d then return end
    d.qty = math.max(1, math.min(math.floor(tonumber(qty) or 1), math.max(1, self:Available())))
    if self.pending then self:CancelPending() end
    Changed()
end

-- Menge bis einschließlich dieser Zeile (Klick auf eine Preisstufe)
function B:QuantityUpTo(listing)
    local d = self.detail
    if not (d and d.commodity) then return end
    local n = 0
    for _, l in ipairs(d.listings) do
        n = n + math.max(0, l.qty - (l.ownQty or 0))
        if l == listing then break end
    end
    self:SetQuantity(math.max(1, n))
end

function B:StartCommodity()
    local d = self.detail
    local C = A.AH
    if not (d and d.commodity) then return false end
    if not (C.StartCommoditiesPurchase and C.ConfirmCommoditiesPurchase) then
        return false, L["Dein Client unterstützt keinen Warenkauf (StartCommoditiesPurchase fehlt)."]
    end
    local qty = d.qty or 1
    local total = self:Quote(qty)
    if not total then return false, L["So viele sind nicht verfügbar."] end
    -- ein vorab reservierter Sniper-Preis würde sonst überschrieben
    if A.Sniper and A.Sniper.pending then A.Sniper:CancelPending() end
    local ok, err = pcall(C.StartCommoditiesPurchase, d.itemID, qty)
    if not ok then return false, L["Kauf fehlgeschlagen: "] .. tostring(err) end
    self.pending = { itemID = d.itemID, qty = qty, expected = total, started = Now(), state = "waiting" }
    Changed()
    return true, L["Preis wird vom Server geholt ..."]
end

function B:ConfirmCommodity()
    local p = self.pending
    if not p then return false, L["Nichts zu bestätigen."] end
    if p.state ~= "ready" then return false, L["Preis wird noch geprüft ..."] end
    self.pending = nil
    self.confirming = p          -- für das Testmodus-Protokoll (Art und Preis des Kaufs)
    local ok, err = pcall(A.AH.ConfirmCommoditiesPurchase, p.itemID, p.qty)
    if not ok then Changed(); return false, L["Kauf fehlgeschlagen: "] .. tostring(err) end
    self.lastPurchase = { itemID = p.itemID, qty = p.qty, cost = p.total, time = Now() }
    Changed()
    return true, L["Kauf wird ausgeführt ..."]
end

function B:CancelPending()
    if not self.pending then return end
    self.pending = nil
    if A.AH and A.AH.CancelCommoditiesPurchase then pcall(A.AH.CancelCommoditiesPurchase) end
    Changed()
end

-- ------------------------------------------------------------
-- Einzelangebote: Sofortkauf und Gebot
-- ------------------------------------------------------------
function B:BuyItem(l)
    if not (l and l.auctionID and l.buyout) then return false, L["Kein Sofortkauf-Preis."] end
    if l.own then return false, L["Das ist dein eigenes Angebot."] end
    if GetMoney and GetMoney() < l.buyout then return false, L["Nicht genug Gold."] end
    if l.dead then return false, L["Angebot ist weg (vermutlich schon gekauft)."] end        -- K2: totes Angebot gesperrt
    self.buying = { auctionID = l.auctionID, cost = l.buyout }
    local ok, err = pcall(A.AH.PlaceBid, l.auctionID, l.buyout)
    self.buying = nil
    if not ok then return false, L["Kauf fehlgeschlagen: "] .. tostring(err) end
    l.used = true
    self.lastPurchase = { itemID = self.detail and self.detail.itemID, qty = l.qty, cost = l.buyout, time = Now(), listing = l,
        auctionID = l.auctionID, bid = l.bid, minBid = l.minBid, listAge = self.detail and self.detail.time and (time() - self.detail.time) or nil,
        resultsAge = self.resultsTime and (time() - self.resultsTime) or nil }
    if A.Ledger and A.Ledger.NotePurchase then A.Ledger:NotePurchase(self.lastPurchase, "buy") end      -- PD1
    Changed()
    return true, L["Kauf wird ausgeführt ..."]
end

-- kleinstes erlaubtes Gebot
-- K3 (Befund Sofortkauf 08:45): +5 % nur, wenn schon jemand geboten hat. Ohne Bieter ist bidAmount das Startgebot -
-- dann ist das Mindestgebot genau dieses (bzw. minBid vom Server). Modern: minBid kommt vom Server (schon richtig);
-- alt: highBidder / nextBid.
function B:MinBid(l)
    if not l then return nil end
    if l.minBid and l.minBid > 0 then return l.minBid end
    if l.bid and l.bid > 0 then
        if l.hasBidder then return l.bid + math.max(1, math.floor(l.bid * 0.05)) end
        return l.bid
    end
    return nil
end
-- Gebotsfeld nur, wenn ein Gebot billiger als Sofortkauf möglich ist
function B:CanBid(l)
    local min = self:MinBid(l)
    return min ~= nil and (not l.buyout or min < l.buyout)
end

function B:PlaceBid(l, amount)
    if not (l and l.auctionID) then return false, L["Kein Angebot gewählt."] end
    if l.own then return false, L["Das ist dein eigenes Angebot."] end
    local min = self:MinBid(l)
    if not amount or amount <= 0 then return false, L["Bitte ein Gebot eingeben."] end
    if min and amount < min then return false, L["Gebot zu niedrig - mindestens "] .. A:FormatMoney(min) end
    if l.buyout and amount >= l.buyout then return self:BuyItem(l) end
    if GetMoney and GetMoney() < amount then return false, L["Nicht genug Gold."] end
    local ok, err = pcall(A.AH.PlaceBid, l.auctionID, amount)
    if not ok then return false, L["Gebot fehlgeschlagen: "] .. tostring(err) end
    self.lastBid = { time = Now(), amount = amount }
    Changed()
    return true, L["Gebot abgegeben: "] .. A:FormatMoney(amount)
end

-- ------------------------------------------------------------
-- Ereignisse
-- ------------------------------------------------------------
local evt = CreateFrame("Frame")
local function Reg(e) return A:RegisterAHEvent(evt, e) end
B.priceEvents = Reg("COMMODITY_PRICE_UPDATED")
Reg("COMMODITY_PRICE_UNAVAILABLE")
Reg("COMMODITY_PURCHASE_SUCCEEDED")
Reg("COMMODITY_PURCHASE_FAILED")
Reg("AUCTION_HOUSE_PURCHASE_COMPLETED")
Reg("AUCTION_HOUSE_SHOW_ERROR")
Reg("UI_ERROR_MESSAGE")

-- K1/K2/K4: Fehlschlag genau melden, totes Angebot aus Detail und Liste nehmen, Protokoll KAUF-FEHLER (ohne Namen)
local GONE = { HigherBid = true, ItemNotFound = true, BidOwn = false, ItemHasQuote = true, NotEnoughItems = true }
function B:PurchaseFailed(lp, code)
    local text, name
    if A.Seller and A.Seller.ErrorText then text, name = A.Seller:ErrorText(code) end
    local ui = self.lastUIError
    if not text and ui and Now() - ui.time < 3 then text = ui.msg end
    local money = GetMoney and GetMoney() or nil
    local poor = money and lp.cost and money < lp.cost
    local gone = (name and GONE[name]) or (not name and not poor)
    local msg
    if poor then msg = L["|cffff5544Kauf fehlgeschlagen|r: Nicht genug Gold."]
    elseif gone then msg = L["|cffff5544Kauf fehlgeschlagen|r: Angebot ist weg (vermutlich schon gekauft)."]
    else msg = L["|cffff5544Kauf fehlgeschlagen|r: "] .. tostring(text or name or "?") end
    if text and not poor then msg = msg .. " |cff999999(" .. text .. ")|r" end
    self.message = msg
    A:Print(msg)
    if gone and lp.listing then lp.listing.dead = true end
    if gone and lp.itemID then self:MarkGone(lp.itemID, lp.listing) end
    if A.Diag then
        pcall(A.Diag.Add, A.Diag, "KAUF-FEHLER", string.format("Item %s · auctionID %s · Preis %s · buyout %s · bid %s · minBid %s · Fehler %s · Liste %s s alt · Angebote %s s alt",
            tostring(lp.itemID), tostring(lp.auctionID), tostring(lp.cost), tostring(lp.cost), tostring(lp.bid), tostring(lp.minBid),
            tostring(name or text or code or "?"), tostring(lp.resultsAge or "-"), tostring(lp.listAge or "-")))
    end
    A:Fire("BUY_PURCHASE_RESULT", false, lp)
    Changed()
    if C_Timer and C_Timer.After then
        C_Timer.After(0.5, function() if B.detail and A:IsAHOpen() then B:Open(B.detail.itemKey, B.detail.name) end end)
    end
end

-- Angebot ist weg: in der Einkaufsliste die Menge senken; ohne weitere Angebote die Zeile entfernen
function B:MarkGone(itemID, listing)
    for i = #(self.results or {}), 1, -1 do
        local r = self.results[i]
        if r.itemID == itemID then
            r.quantity = math.max(0, (r.quantity or 1) - ((listing and listing.qty) or 1))
            if r.quantity <= 0 then table.remove(self.results, i) end
        end
    end
end

local function AfterPurchase()
    local lp = B.lastPurchase
    if lp and not lp.done then
        lp.done = true
        local msg = L["Gekauft: "] .. lp.qty .. "x " .. A:GetItemName(lp.itemID) .. L[" für "] .. A:FormatMoney(lp.cost or 0)
        A:Print(msg)
        B.message, B.messageOK = msg, true      -- ersetzt "Kauf wird ausgeführt ..."
        Changed()
    end
    -- Angebote neu laden
    C_Timer.After(0.5, function() if B.detail and A:IsAHOpen() then B:Open(B.detail.itemKey, B.detail.name) end end)
end

evt:SetScript("OnEvent", function(_, event, a1, a2)
    -- Punkt 0 (Befund 10.11.): geschützte Werte (WoW Forever "secret string") nie indizieren
    do local G = _G.GoldSentinelGame; if G and G.AnySecret and G.AnySecret(a1, a2) then return end end
    if event == "COMMODITY_PRICE_UPDATED" then
        local p = B.pending
        if not p or p.state ~= "waiting" then return end
        p.unit, p.total, p.state, p.started = a1, a2, "ready", Now()
        Changed()
    elseif event == "COMMODITY_PRICE_UNAVAILABLE" then
        if B.pending then
            B.pending = nil
            B.message = L["Angebot nicht mehr verfügbar - Kauf abgebrochen."]
            Changed()
        end
    elseif event == "COMMODITY_PURCHASE_SUCCEEDED" or event == "AUCTION_HOUSE_PURCHASE_COMPLETED" then
        local lp = B.lastPurchase
        if lp and Now() - lp.time < 15 and not lp.done then
            AfterPurchase()
            A:Fire("BUY_PURCHASE_RESULT", true, lp)       -- Sammelkauf zählt erst jetzt (offener Punkt 4)
        end
    elseif event == "UI_ERROR_MESSAGE" then
        local msg = type(a2) == "string" and a2 or (type(a1) == "string" and a1 or nil)
        if msg then B.lastUIError = { msg = msg, time = Now() } end
    elseif event == "COMMODITY_PURCHASE_FAILED" or event == "AUCTION_HOUSE_SHOW_ERROR" then
        local lp = B.lastPurchase
        if lp and not lp.done and Now() - lp.time < 5 then
            lp.done, lp.failed = true, true
            local code = (event == "AUCTION_HOUSE_SHOW_ERROR") and a1 or nil
            -- kurz warten: der Text des Spiels (UI_ERROR_MESSAGE) kann direkt danach kommen
            local function report() B:PurchaseFailed(lp, code) end
            if C_Timer and C_Timer.After then C_Timer.After(0.2, report) else report() end
        elseif B.lastBid and Now() - B.lastBid.time < 5 then
            B.lastBid = nil
            B.message = L["|cffff5544Gebot fehlgeschlagen.|r"]
            Changed()
        end
    end
end)

A:On("BROWSE_RESULTS", function()
    if B.search and B.search.kind == "browse" then B.search.answered = true; B:Poll() end
end)
A:On("SEARCH_RESULTS", function()
    if B.search and B.search.kind == "items" then B.search.answered = true; B:Poll() end
end)
A:On("QUERY_READY", function() if not B.search then B:TryStart() end end)
A:On("AH_STATE", function()
    if not A:IsAHOpen() then
        B.search, B.wanted, B.pending, B.partial, B.snapshot = nil, nil, nil, nil, nil
        wipe(B.cache)
    end
    Changed()
end)

local ticker = CreateFrame("Frame")
local acc = 0
ticker:SetScript("OnUpdate", function(_, dt)
    acc = acc + (dt or 0)
    if acc < 0.1 then return end
    acc = 0
    if B.search then B:Poll() elseif B.wanted then B:TryStart() end
    local p = B.pending
    if p then
        if p.state == "waiting" and Now() - p.started > PRICE_WAIT then
            if not B.priceEvents then
                p.state, p.total = "ready", p.expected      -- Client ohne Preis-Ereignis: geschätzten Preis zeigen
            else
                B.pending = nil
                B.message = L["Keine Preisbestätigung vom Server - Kauf abgebrochen."]
                if A.AH.CancelCommoditiesPurchase then pcall(A.AH.CancelCommoditiesPurchase) end
            end
            Changed()
        elseif p.state == "ready" and Now() - p.started > 30 then
            B:CancelPending()
            B.message = L["Reservierter Preis verfallen - bitte neu kaufen."]
            Changed()
        end
    end
end)

function B:GetDebugText()
    return string.format("Suche=%s, wartet=%s, Ergebnisse=%d, Item=%s, Kauf=%s",
        self.search and self.search.kind or "-", self.wanted and self.wanted.kind or "-", #self.results,
        self.detail and tostring(self.detail.itemID) or "-", self.pending and self.pending.state or "-")
end

-- Kategorien aus dem Spiel holen: beim Einloggen (Item-Klassen) und sobald das Blizzard-AH geladen ist
-- (AuctionCategories - lädt erst beim ersten Öffnen des Auktionshauses)
local catFrame = CreateFrame("Frame")
B.catFrame = catFrame
for _, e in ipairs({ "PLAYER_LOGIN", "ADDON_LOADED", "AUCTION_HOUSE_SHOW" }) do pcall(catFrame.RegisterEvent, catFrame, e) end
catFrame:SetScript("OnEvent", function(_, event, name)
    if event == "ADDON_LOADED" and name ~= "Blizzard_AuctionHouseUI" and name ~= "Blizzard_AuctionUI" then return end
    local ok, err = pcall(B.BuildCategories, B)
    if not ok and A.ReportError then A:ReportError("Buy:Kategorien", err) end
end)
