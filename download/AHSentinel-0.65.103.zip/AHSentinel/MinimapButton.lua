if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 0.60.1 - Knopf an der Minikarte
-- Rund wie bei anderen Addons, mit der Maus rund um die Minikarte ziehen.
-- Linksklick: Fenster   Rechtsklick: Markt scannen   Ziehen: verschieben
-- Die Position (Winkel) wird gespeichert; ausblenden in den Optionen oder mit /ahs minimap.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local C = A.UI.C

A.ICON = "Interface\\AddOns\\AHSentinel\\Media\\Icon"
local DEFAULT_ANGLE = 225          -- unten links an der Minikarte

local function Settings() return A.db and A.db.settings or {} end

-- eckige Minikarten (andere Addons können die Form ändern): Knopf am Rand des Quadrats
local function IsSquare()
    if not GetMinimapShape then return false end
    local ok, shape = pcall(GetMinimapShape)
    return ok and shape == "SQUARE"
end

-- Knopf an den Rand der Minikarte setzen (Winkel in Grad, 0 = rechts, 90 = oben)
local function PlaceAt(btn, angle)
    local map = btn:GetParent()
    local rad = math.rad(angle or DEFAULT_ANGLE)
    local x, y = math.cos(rad), math.sin(rad)
    local rw = (map:GetWidth() or 140) / 2 + 10
    local rh = (map:GetHeight() or 140) / 2 + 10
    if IsSquare() then
        -- auf den Rand des Quadrats projizieren
        local m = math.max(math.abs(x), math.abs(y))
        if m > 0 then x, y = x / m, y / m end
    end
    btn:ClearAllPoints()
    btn:SetPoint("CENTER", map, "CENTER", x * rw, y * rh)
end

-- Winkel der Maus zur Mitte der Minikarte
local function CursorAngle(map)
    local mx, my = map:GetCenter()
    local px, py = GetCursorPosition()
    local scale = map:GetEffectiveScale() or 1
    px, py = px / scale, py / scale
    return math.deg(math.atan2(py - my, px - mx)) % 360
end

local function CreateButton()
    if A.FloatingButton then return A.FloatingButton end
    local map = (type(Minimap) == "table" and Minimap.GetCenter) and Minimap or UIParent

    local btn = CreateFrame("Button", "AHAnalyzerProMinimapButton", map)
    btn:SetSize(31, 31)
    btn:SetFrameStrata("MEDIUM")
    btn:SetFrameLevel(8)
    btn:EnableMouse(true)
    btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    btn:RegisterForDrag("LeftButton")
    if btn.SetHighlightTexture then btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight") end

    -- Aufbau wie die Minikarten-Knöpfe von Blizzard: dunkler Grund, Icon, goldener Ring
    local bg = btn:CreateTexture(nil, "BACKGROUND")
    bg:SetSize(24, 24)
    bg:SetPoint("CENTER", 0, 0)
    bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")

    local icon = btn:CreateTexture(nil, "ARTWORK")
    icon:SetSize(21, 21)
    icon:SetPoint("CENTER", 0, 0)
    icon:SetTexture(A.ICON)
    btn.icon = icon

    local border = btn:CreateTexture(nil, "OVERLAY")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT", 0, 0)
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")

    -- Restzeit bis zum nächsten Scan unter dem Knopf
    btn.timer = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    btn.timer:SetPoint("TOP", btn, "BOTTOM", 0, 2)

    -- Ziehen: rund um die Minikarte
    btn:SetScript("OnDragStart", function(self)
        self.dragging = true
        self:SetScript("OnUpdate", function(s)
            local angle = CursorAngle(s:GetParent())
            s.angle = angle
            PlaceAt(s, angle)
        end)
        GameTooltip:Hide()
    end)
    btn:SetScript("OnDragStop", function(self)
        self:SetScript("OnUpdate", self.statusUpdate)
        self.dragging = false
        self.dragEnded = GetTime()
        if A.db and self.angle then A.db.settings.minimapAngle = math.floor(self.angle * 10 + 0.5) / 10 end
    end)

    btn:SetScript("OnClick", function(self, mouseButton)
        if self.dragEnded and GetTime() - self.dragEnded < 0.2 then return end
        if mouseButton == "RightButton" then
            A:StartFullScan()
        else
            A.UI:Toggle()
        end
    end)

    btn:SetScript("OnEnter", function(self)
        if self.dragging then return end
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("AHSentinel", C.accent[1], C.accent[2], C.accent[3])
        GameTooltip:AddLine(" ")
        if A.db then
            GameTooltip:AddDoubleLine(L["Items in der Datenbank:"], tostring(A:CountTable(A.db.marketData)), 0.8, 0.8, 0.8, 1, 1, 1)
            GameTooltip:AddDoubleLine(L["Letzter Scan:"], A:FormatAgo(A.db.lastScanTime), 0.8, 0.8, 0.8, 1, 1, 1)
            if A:IsScanning() then
                GameTooltip:AddDoubleLine(L["Scan:"], L["läuft gerade"], 0.8, 0.8, 0.8, 1, 0.8, 0.2)
            elseif A:IsScanReady() then
                GameTooltip:AddDoubleLine(L["Scan:"], L["bereit"], 0.8, 0.8, 0.8, 0.2, 0.9, 0.3)
            else
                GameTooltip:AddDoubleLine(L["Scan möglich in:"], A:FormatDuration(A:GetCooldownRemaining()), 0.8, 0.8, 0.8, 1, 0.4, 0.3)
            end
            if A.Watchlist and A.Watchlist:CountAlerts() > 0 then
                GameTooltip:AddDoubleLine(L["Watchlist-Alarme:"], tostring(A.Watchlist:CountAlerts()), 0.8, 0.8, 0.8, 0.2, 0.9, 0.3)
            end
        end
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine(L["Linksklick: Fenster öffnen/schließen"], 0.6, 0.6, 0.6)
        GameTooltip:AddLine(L["Rechtsklick: Markt scannen"], 0.6, 0.6, 0.6)
        GameTooltip:AddLine(L["Ziehen: rund um die Minikarte verschieben"], 0.6, 0.6, 0.6)
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Status jede halbe Sekunde: grau während der Sperrzeit, Restzeit darunter
    local elapsed = 1
    btn.statusUpdate = function(self, dt)
        elapsed = elapsed + (dt or 0)
        if elapsed < 0.5 then return end
        elapsed = 0
        if A:IsScanning() then
            self.icon:SetVertexColor(1, 1, 1)
            if self.icon.SetDesaturated then self.icon:SetDesaturated(false) end
            self.timer:SetText(L["|cffffcc33Scan|r"])
        elseif A:IsScanReady() then
            self.icon:SetVertexColor(1, 1, 1)
            if self.icon.SetDesaturated then self.icon:SetDesaturated(false) end
            self.timer:SetText("")
        else
            self.icon:SetVertexColor(0.6, 0.6, 0.6)
            if self.icon.SetDesaturated then self.icon:SetDesaturated(true) end
            self.timer:SetText(A:FormatDuration(A:GetCooldownRemaining()))
        end
    end
    btn:SetScript("OnUpdate", btn.statusUpdate)

    btn.angle = Settings().minimapAngle or DEFAULT_ANGLE
    PlaceAt(btn, btn.angle)
    if Settings().minimapHide then btn:Hide() else btn:Show() end
    A.FloatingButton = btn
    A.MinimapButton = btn
    return btn
end

-- an/aus (Optionen, /ahs minimap)
function A:SetMinimapButtonShown(on)
    if not self.db then return end
    self.db.settings.minimapHide = not on or nil
    local btn = self.FloatingButton or CreateButton()
    if on then btn:Show() else btn:Hide() end
end

function A:ToggleMinimapButton()
    local on = self.db and self.db.settings.minimapHide
    self:SetMinimapButtonShown(on and true or false)
    self:Print(on and L["Knopf an der Minikarte: an"] or L["Knopf an der Minikarte: aus (/ahs minimap zeigt ihn wieder)"])
end

-- Winkel direkt setzen (für Tests und /ahs reset)
function A:SetMinimapAngle(angle)
    if not self.db then return end
    self.db.settings.minimapAngle = angle
    local btn = self.FloatingButton
    if btn then btn.angle = angle; PlaceAt(btn, angle) end
end

function A:ResetButtonPosition()
    if self.db then
        self.db.settings.buttonPos = nil
        self.db.settings.minimapAngle = nil
        self.db.settings.minimapHide = nil
    end
    local btn = self.FloatingButton
    if btn then
        btn.angle = DEFAULT_ANGLE
        PlaceAt(btn, DEFAULT_ANGLE)
        btn:Show()
    end
    self:Print(L["Positionen zurückgesetzt."])
end

-- Knopf erst erstellen, wenn die gespeicherten Daten geladen sind
A:On("READY", function()
    CreateButton()
end)
