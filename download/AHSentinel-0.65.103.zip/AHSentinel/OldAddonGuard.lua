-- ============================================================
-- AHSentinel - Schutz vor dem alten "AH Analyzer Pro" (bis 0.61)
--
-- AHSentinel benutzt (für ProfessionSentinel und alte Daten) dieselbe globale Tabelle
-- "AHAnalyzerPro" wie das alte Addon. Liegt das volle alte Addon noch im AddOns-Ordner und
-- wird geladen, würden beide in dieselbe Tabelle schreiben (doppelte Ereignisse und Befehle,
-- Lua-Fehler). Dann lädt AHSentinel nicht weiter und bittet einmal, den alten Ordner zu löschen.
-- Die alten Daten werden vorher für AHSentinel gesichert (wie bei der normalen Übernahme).
--
-- Steht in der .toc direkt nach den gemeinsamen Dateien und VOR allen eigenen Dateien.
-- Jede eigene Datei beginnt mit:  if AHSentinel_Blocked then return end
-- ============================================================

local OLD = "AHAnalyzerPro"
local SELF = ... or "AHSentinel"

local function Call(f, ...)
    if type(f) ~= "function" then return nil end
    local ok, a, b, c, d = pcall(f, ...)
    if ok then return a, b, c, d end
    return nil
end

local AddOns = C_AddOns
local IsLoaded = (AddOns and AddOns.IsAddOnLoaded) or IsAddOnLoaded
local Meta = (AddOns and AddOns.GetAddOnMetadata) or GetAddOnMetadata
local Info = (AddOns and AddOns.GetAddOnInfo) or GetAddOnInfo

-- "0.61.2" < "0.62"?
local function OlderThan062(v)
    if type(v) ~= "string" then return false end
    local a, b = v:match("^%s*(%d+)%.(%d+)")
    a, b = tonumber(a), tonumber(b)
    if not a then return false end
    return a < 0 or (a == 0 and b < 62)
end

local function OldAddonActive()
    local version = Call(Meta, OLD, "Version")
    if not OlderThan062(version) then return false end     -- Übergangsordner (0.62.0) oder gar nicht da
    if Call(IsLoaded, OLD) then return true end
    local _, _, _, loadable = Call(Info, OLD)              -- aktiviert, wird gleich noch geladen
    return loadable == true or loadable == 1
end

AHSentinel_Blocked = OldAddonActive() or nil
if not AHSentinel_Blocked then return end

local MSG = {
    deDE = "Bitte den alten Ordner AddOns\\AHAnalyzerPro löschen – AHSentinel ersetzt ihn. Bis dahin ist AHSentinel aus; deine Daten sind gesichert.",
    enUS = "Please delete the old folder AddOns\\AHAnalyzerPro – AHSentinel replaces it. Until then AHSentinel stays off; your data is saved.",
    frFR = "Veuillez supprimer l'ancien dossier AddOns\\AHAnalyzerPro – AHSentinel le remplace. D'ici là, AHSentinel reste désactivé ; vos données sont sauvegardées.",
    esES = "Borra la carpeta antigua AddOns\\AHAnalyzerPro: AHSentinel la sustituye. Hasta entonces AHSentinel queda desactivado; tus datos están guardados.",
    esMX = "Borra la carpeta antigua AddOns\\AHAnalyzerPro: AHSentinel la sustituye. Hasta entonces AHSentinel queda desactivado; tus datos están guardados.",
    ptBR = "Apague a pasta antiga AddOns\\AHAnalyzerPro – o AHSentinel a substitui. Até lá o AHSentinel fica desligado; seus dados estão salvos.",
    itIT = "Elimina la vecchia cartella AddOns\\AHAnalyzerPro – AHSentinel la sostituisce. Fino ad allora AHSentinel resta spento; i tuoi dati sono salvati.",
    ruRU = "Удалите старую папку AddOns\\AHAnalyzerPro – её заменяет AHSentinel. До этого AHSentinel отключён; ваши данные сохранены.",
    koKR = "예전 폴더 AddOns\\AHAnalyzerPro를 삭제하세요. AHSentinel이 이를 대체합니다. 그때까지 AHSentinel은 꺼져 있으며 데이터는 저장되어 있습니다.",
    zhCN = "请删除旧文件夹 AddOns\\AHAnalyzerPro，AHSentinel 已取代它。在此之前 AHSentinel 不会运行；你的数据已保存。",
    zhTW = "請刪除舊資料夾 AddOns\\AHAnalyzerPro，AHSentinel 已取代它。在此之前 AHSentinel 不會運行；你的資料已儲存。",
}

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(self, event, name)
    if event == "ADDON_LOADED" and name == SELF then
        -- alte Daten für AHSentinel sichern (gleiche Regel wie die Übernahme in AHAnalyzerPro.lua);
        -- das alte Addon behält seine Daten, beide werden beim Ausloggen gespeichert
        if type(AHSentinelDB) ~= "table" and type(AHAnalyzerProDB) == "table" and AHAnalyzerProDB.marketData then
            AHSentinelDB = AHAnalyzerProDB
        end
    elseif event == "PLAYER_LOGIN" then
        local loc = (GetLocale and GetLocale()) or "enUS"
        local text = "|cff00d1d1[AHSentinel]|r |cffff5544" .. (MSG[loc] or MSG.enUS) .. "|r"
        if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then DEFAULT_CHAT_FRAME:AddMessage(text) else print(text) end
        self:UnregisterAllEvents()
    end
end)
