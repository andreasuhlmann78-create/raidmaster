if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 0.59.30 - Oberflächen der Extras
--   * Knopf am Händler: Schrott & Lohnendes verkaufen
--   * Knopf am Briefkasten: Post an Twinks
--   * Fenster: Regeln für die Post an Twinks
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C
local X = A.Extras

-- ------------------------------------------------------------
-- Händler
-- ------------------------------------------------------------
-- LevelPilot verkauft graue Items selbst beim Öffnen des Händlers (Option autoSellGrey, ab Werk an).
-- Dann braucht es unseren Knopf nicht: ab Werk aus, solange der Spieler ihn nicht selbst einschaltet.
-- Nur lesen; LevelPilot wird nie verändert.
function UI:LevelPilotSellsGrey()
    local CA = A:Global("C_AddOns")
    local isLoaded = (CA and CA.IsAddOnLoaded) or A:Global("IsAddOnLoaded")
    if type(isLoaded) ~= "function" then return false end
    local ok, loaded = pcall(isLoaded, "LevelPilot")
    if not (ok and loaded) then return false end
    -- Einstellung von LevelPilot lesen, wo immer sie liegt; fehlt sie, gilt LevelPilots Werkseinstellung (an)
    local ov = A.apiOverride and A.apiOverride.LevelPilotDB
    local candidates = ov ~= nil and { ov ~= false and ov or nil } or { _G.LevelPilotDB, _G.LevelPilotCharDB, _G.LevelPilotSettings }
    for _, db in pairs(candidates) do
        if type(db) == "table" then
            for _, s in ipairs({ db, db.settings, db.profile, db.options }) do
                if type(s) == "table" and s.autoSellGrey == false then return false end
            end
        end
    end
    return true
end

-- Ist der Händler-Knopf an? Eigene Einstellung gewinnt; ohne Einstellung: aus, wenn LevelPilot graue Items verkauft.
function UI:VendorButtonEnabled()
    local v = A.db and A.db.settings and A.db.settings.vendorButton
    if v == true or v == false then return v end
    return not self:LevelPilotSellsGrey()
end

-- Überdeckt ein Rechteck einen Reiter des Händlerfensters (Händler / Rückkauf)? Gibt den Namen des Reiters zurück.
local function Overlap(a, b)
    if not (a and b and a.GetRect and b.GetRect) then return false end
    local ax, ay, aw, ah = a:GetRect()
    local bx, by, bw, bh = b:GetRect()
    if not (ax and bx) then return false end
    return ax < bx + bw and bx < ax + aw and ay < by + bh and by < ay + ah
end
function UI:VendorButtonOverlap(button)
    local b = button or self.vendorButton
    if not (b and b.IsShown and b:IsShown()) then return nil end
    for i = 1, 4 do
        local tab = _G["MerchantFrameTab" .. i]
        if tab and tab.IsShown and tab:IsShown() and Overlap(b, tab) then return "MerchantFrameTab" .. i end
    end
    return nil
end

function UI:UpdateVendorButton()
    if not (X and X.atMerchant) then
        if self.vendorButton then self.vendorButton:Hide() end
        return
    end
    if not self:VendorButtonEnabled() then
        if self.vendorButton then self.vendorButton:Hide() end
        return
    end
    local parent = (type(MerchantFrame) == "table") and MerchantFrame or UIParent
    if not self.vendorButton then
        local b = UI:Button(parent, "", 220, 22, function()
            local ok, msg = X:SellToVendor()
            if msg then A:Print(msg) end
        end, "primary")
        -- Über dem Händlerfenster (oben rechts), nie unten bei den Blizzard-Reitern "Händler" / "Rückkauf"
        b:SetPoint("BOTTOMRIGHT", parent, "TOPRIGHT", 0, 4)
        if A.RegisterUI then A.RegisterUI(b, "Knopf beim Händler") end     -- Oberflächen-Prüfung (UICheck.lua)
        b:SetScript("OnEnter", function(self)
            local list, total, junk, better = X:VendorCandidates()
            UI:AnchorTooltip(self)
            GameTooltip:SetText(L["Schrott & Lohnendes verkaufen"], 1, 1, 1)
            GameTooltip:AddLine(L["Verkauft graue Items und alles, was beim Händler mehr bringt\nals im Auktionshaus nach dem AH-Anteil."], 0.9, 0.9, 0.9, true)
            GameTooltip:AddLine(" ")
            GameTooltip:AddDoubleLine(L["Schrott"], A:FormatMoney(junk), 0.6, 0.6, 0.6, 1, 1, 1)
            GameTooltip:AddDoubleLine(L["Beim Händler lohnender"], A:FormatMoney(better), 0.6, 0.6, 0.6, 1, 1, 1)
            for i, e in ipairs(list) do
                if i > 12 then GameTooltip:AddLine(string.format(L["... und %d weitere"], #list - 12), 0.6, 0.6, 0.6); break end
                GameTooltip:AddDoubleLine(e.count .. "x " .. A:GetItemName(e.itemID), A:FormatMoney(e.value), 0.9, 0.9, 0.9, 1, 1, 1)
            end
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        self.vendorButton = b
    end
    local list, total = X:VendorCandidates()
    local b = self.vendorButton
    -- nichts zu verkaufen: Knopf ganz weg statt "Verkaufen: 0 Items (0)"
    if #list == 0 then b:Hide(); return end
    b:SetText(string.format(L["Verkaufen: %d Items (%s)"], #list, A:FormatMoney(total)))
    b:SetActive(not X.selling)
    b:Show()
end
A:On("VENDOR_CHANGED", function() UI:UpdateVendorButton() end)

-- ------------------------------------------------------------
-- Kategorie-Menü (eigenes Fenster, kein Blizzard-Dropdown - taint-frei)
-- Klick auf eine Kategorie mit Unterkategorien klappt sie auf; ein zweiter Klick (oder ohne Unterkategorien) wählt.
-- Mausrad blättert, wenn die Liste länger ist als das Fenster.
-- ------------------------------------------------------------
local MENU_ROWS = 24
function UI:CategoryMenu(anchor, currentKey, onPick)
    local m = self.catMenu
    if not m then
        m = CreateFrame("Frame", "AHSentinelCategoryMenu", UIParent)
        if A.RegisterUI then A.RegisterUI(m, "Kategorie-Menü") end
        m:SetSize(230, MENU_ROWS * 18 + 34)
        m:SetFrameStrata("FULLSCREEN_DIALOG")
        m:SetClampedToScreen(true)
        m:EnableMouse(true)
        UI:Box(m, C.bg, C.frameEdge, 1)
        m.hint = UI:Label(m, L["Klick: aufklappen / wählen"], "GameFontDisableSmall", C.textDim)
        m.hint:SetPoint("TOPLEFT", 8, -6)
        m.close = UI:Button(m, "X", 22, 18, function() m:Hide() end, "danger")
        m.close:SetPoint("TOPRIGHT", -4, -4)
        m.rows = {}
        for k = 1, MENU_ROWS do
            local b = UI:Button(m, "", 214, 17, function(btn) m:Click(btn.cat) end)
            b:SetPoint("TOPLEFT", 8, -26 - (k - 1) * 18)
            if b.label then b.label:ClearAllPoints(); b.label:SetPoint("LEFT", 6, 0) end
            m.rows[k] = b
        end
        m.offset = 0
        if m.EnableMouseWheel then m:EnableMouseWheel(true) end
        m:SetScript("OnMouseWheel", function(self, delta)
            self.offset = math.max(0, math.min(self.offset - delta * 3, math.max(0, #self.list - MENU_ROWS)))
            self:Fill()
        end)
        function m:HasChildren(c)
            for _, x in ipairs(A.Buy.CATS or {}) do if x.parent == c.key then return true end end
            return false
        end
        function m:Fill()
            local B = A.Buy
            local list = {}
            for _, c in ipairs(B:VisibleCats(self.open)) do
                if c.key ~= "all" and c.filters then list[#list + 1] = c end
            end
            self.list = list
            for k = 1, MENU_ROWS do
                local b, c = self.rows[k], list[k + self.offset]
                b.cat = c
                if c then
                    local mark = self:HasChildren(c) and ((self.open == c.key or self.openSub == c.key) and "- " or "+ ") or "   "
                    local sel = (c.key == self.current) and "|cff00d1d1" or ""
                    b:SetText(string.rep("   ", c.level or 0) .. mark .. sel .. B:CatText(c) .. (sel ~= "" and "|r" or ""))
                    b:Show()
                else
                    b:Hide()
                end
            end
        end
        function m:Click(c)
            if not c then return end
            local opened = (self.open == c.key) or (self.openSub == c.key)
            if self:HasChildren(c) and not opened then
                self.open = c.key
                self.openSub = (c.level == 1) and c.key or nil
                self:Fill()
                return
            end
            self:Hide()
            if self.onPick then self.onPick(c) end
        end
        self.catMenu = m
    end
    m.onPick, m.current, m.offset = onPick, currentKey, 0
    m.open = currentKey
    local cur = currentKey and A.Extras and A.Extras.CatByKey and A.Extras:CatByKey(currentKey)
    m.openSub = cur and cur.level == 1 and cur.key or (cur and cur.level == 2 and cur.parent) or nil
    m:ClearAllPoints()
    m:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -2)
    m:Fill()
    m:Show()
    return m
end

-- ------------------------------------------------------------
-- Post an Twinks: Regeln
-- ------------------------------------------------------------
local MAX_RULES = 8

function UI:ShowMailRules()
    if not self.mailRulesWindow then
        local w = self:Dialog("AHAnalyzerProMailRules", 470, 120 + MAX_RULES * 30, L["Post an Twinks"])
        local intro = UI:Label(w, L["Welche Waren an welchen Charakter? Am Briefkasten verschickt der Knopf\n'An Twinks' pro Klick eine Post mit passenden Waren aus deinen Taschen."], "GameFontHighlightSmall", C.textDim)
        intro:SetPoint("TOPLEFT", 16, -36)
        w.rows = {}
        local cats = X:RuleCategories()
        for i = 1, MAX_RULES do
            local r = CreateFrame("Frame", nil, w)
            r:SetSize(440, 26)
            r:SetPoint("TOPLEFT", 16, -70 - (i - 1) * 30)
            r.cat = UI:Button(r, "", 190, 24, function(self)
                local rule = X.RulesDB()[i]
                if not rule then return end
                -- Auswahlmenü wie im Blizzard-AH (offener Punkt 12): Hauptkategorie aufklappen, dann wählen
                UI:CategoryMenu(self, rule.cat, function(c)
                    X:SetRuleCategory(rule, c)
                    w:Refresh()
                end)
            end)
            r.cat:SetPoint("LEFT", 0, 0)
            r.cat.tooltip = L["Kategorie wählen (Menü wie im Auktionshaus)"]
            local arrow = UI:Label(r, "->", "GameFontHighlight", C.textDim)
            arrow:SetPoint("LEFT", r.cat, "RIGHT", 8, 0)
            r.to = UI:EditBox(r, 150, 24, L["Charakter"])
            r.to:SetPoint("LEFT", arrow, "RIGHT", 8, 0)
            r.to:SetScript("OnTextChanged", function(self)
                local rule = X.RulesDB()[i]
                if rule then rule.to = self:GetText() end
            end)
            r.del = UI:Button(r, "X", 26, 24, function()
                table.remove(X.RulesDB(), i)
                w:Refresh()
            end, "danger")
            r.del:SetPoint("LEFT", r.to, "RIGHT", 8, 0)
            r.del.tooltip = L["Regel löschen"]
            w.rows[i] = r
        end
        w.add = UI:Button(w, L["+ Regel"], 110, 24, function()
            local rules = X.RulesDB()
            if #rules >= MAX_RULES then return end
            table.insert(rules, { cat = "herb", to = "" })
            w:Refresh()
        end, "primary")
        w.add:SetPoint("BOTTOMLEFT", 16, 16)
        w.alts = UI:Label(w, "", "GameFontDisableSmall", C.textDim)
        w.alts:SetPoint("LEFT", w.add, "RIGHT", 12, 0)
        w.alts:SetWidth(320)
        function w:Refresh()
            local rules = X.RulesDB()
            for i, r in ipairs(self.rows) do
                local rule = rules[i]
                if rule then
                    local c = X:CatByKey(rule.cat)
                    r.cat:SetText(c and A.Buy:CatText(c) or rule.catText or "?")
                    if not r.to:HasFocus() then r.to:SetText(rule.to or "") end
                    r:Show()
                else
                    r:Hide()
                end
            end
            self.add:SetActive(#rules < MAX_RULES)
            -- bekannte Twinks als Hilfe
            local names = {}
            local me = UnitName and UnitName("player")
            for _, c in ipairs(A.Chars and A.Chars:GetAll() or {}) do
                if c.name ~= me then table.insert(names, c.name) end
            end
            self.alts:SetText(#names > 0 and (L["Deine Twinks: "] .. table.concat(names, ", ")) or "")
            A:Fire("MAILRULES_CHANGED")
        end
        w:SetScript("OnShow", function(self) self:Refresh() end)
        self.mailRulesWindow = w
    end
    self.mailRulesWindow:Show()
    self.mailRulesWindow:Refresh()
    return self.mailRulesWindow
end
