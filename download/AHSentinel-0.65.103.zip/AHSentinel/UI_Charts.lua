if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.9 - Tab "Charts" (Preisverlauf, Linie beim Median,
-- EMAs über 6 Stunden / 1 Tag / 7 Tage, Kreuzungen 1 Tag / 7 Tage)
-- Unbestätigte Preise (mögliche Lockangebote) sind grau und zählen nicht.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
-- Retail 12.x: die alten Item-/Zauber-Funktionen gibt es nur noch in C_Item / C_Spell
local GetItemInfo = GetItemInfo or (C_Item and C_Item.GetItemInfo)
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C

local RANGES = {
    { key = "day", label = "24 Std.", seconds = 86400 },
    { key = "week", label = "7 Tage", seconds = 7 * 86400 },
    { key = "month", label = "30 Tage", seconds = 30 * 86400 },
    { key = "all", label = "Alles", seconds = nil },
}

local function BuildCharts(parent)
    local p = CreateFrame("Frame", nil, parent)
    p.range = "week"

    -- ---------------- Linke Seite: Item-Auswahl ----------------
    local head = UI:TabTitle(p, L["Preisverlauf"], "charts")

    -- Zurück zum Reiter, aus dem man hierher gesprungen ist (z.B. Markt)
    p.backBtn = UI:Button(p, "", 120, 22, function() UI:ChartBack() end)
    p.backBtn:SetPoint("LEFT", head, "RIGHT", 10, 0)
    p.backBtn:Hide()

    p.search = UI:EditBox(p, 296, 24, L["Suchen: Name (jede Sprache) oder ID"])
    p.search:SetPoint("TOPLEFT", 0, -30)
    p.search:SetScript("OnTextChanged", function() p:RefreshList() end)
    UI:AttachItemSearch(p.search, { suggest = false, onLink = function(id) p.selected = id; p:Draw() end })
    p.search:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)

    p.list = UI:Table(p, {
        columns = {
            { key = "name", title = L["Item"], width = 170 },
            { key = "points", title = L["Punkte"], width = 100, align = "RIGHT" },
        },
        rows = 18,
        rowHeight = 22,
        sortKey = "name",
        cell = function(item, key)
            if key == "name" then return UI.ItemName(item) end
            return tostring(item.points)
        end,
        sortValue = function(item, key)
            if key == "name" then return string.lower(UI.ItemName(item)) end
            return item.points
        end,
        onClick = function(item)
            p.selected = item.itemID
            p:Draw()
        end,
        emptyText = L["Keine Daten."],
        shortCount = true,
    })
    p.list:FillColumn(0, -88, 296, 4)   -- linke Spalte bis ganz unten

    -- Seltenheit (Aufklappmenü zum Anhaken) über der Liste
    p.qualPicker = UI:QualityPicker(p, 140, function() p:RefreshList() end)
    p.qualPicker:SetPoint("TOPLEFT", 0, -58)

    -- ---------------- Rechte Seite: Diagramm ----------------
    local right = CreateFrame("Frame", nil, p)
    right:SetPoint("TOPLEFT", p.search, "TOPRIGHT", 14, 30)
    right:SetPoint("BOTTOMRIGHT", 0, 0)

    p.itemName = UI:Label(right, L["Kein Item gewählt"], "GameFontNormalLarge", C.accent)
    p.itemName:SetPoint("TOPLEFT", 0, 0)
    p.itemName:SetWidth(330)
    if p.itemName.SetWordWrap then p.itemName:SetWordWrap(false) end

    p.rangeButtons = {}
    local prev
    for i = #RANGES, 1, -1 do
        local r = RANGES[i]
        local b = UI:Button(right, L[r.label], 68, 22, function()
            p.range = r.key
            p:Draw()
        end)
        if prev then b:SetPoint("RIGHT", prev, "LEFT", -4, 0) else b:SetPoint("TOPRIGHT", 0, 0) end
        b.rangeKey = r.key
        p.rangeButtons[r.key] = b
        prev = b
    end

    local watchBtn = UI:Button(right, L["Zur Watchlist"], 110, 22, function()
        if p.selected then
            local _, msg = A.Watchlist:Add(tostring(p.selected))
            A:Print(msg)
        end
    end)
    watchBtn:SetPoint("TOPRIGHT", 0, -28)

    p.emaBtn = UI:Button(right, "", 76, 22, function()
        A.db.settings.chartEMA = not A.db.settings.chartEMA
        p:Draw()
    end)
    p.emaBtn:SetPoint("RIGHT", watchBtn, "LEFT", -4, 0)
    p.emaBtn.tooltip = L["Gleitende Durchschnitte (EMA) ein/aus:\nblau = 6 Stunden, orange = 1 Tag, lila = 7 Tage.\nNur echte Preise (ohne Lockangebote), ab 10 Preisen.\nPfeile: 1-Tages-EMA kreuzt die 7-Tages-EMA\n(grün = nach oben, rot = nach unten)."]

    p.stats = UI:Label(right, "", "GameFontHighlightSmall", C.text)
    p.stats:SetPoint("TOPLEFT", 0, -32)

    local canvas = CreateFrame("Frame", nil, right)
    canvas:SetPoint("TOPLEFT", 0, -58)
    canvas:SetPoint("BOTTOMRIGHT", 0, 0)
    UI:Box(canvas, C.panel, C.border)
    p.canvas = canvas

    p.message = UI:Label(canvas, L["Links ein Item auswählen."], "GameFontHighlight", C.textDim)
    p.message:SetPoint("CENTER")
    p.message:SetJustifyH("CENTER")

    -- Objekt-Pools
    p.pool = { lines = {}, dots = {}, labels = {}, grid = {}, fill = {} }
    p.used = { lines = 0, dots = 0, labels = 0, grid = 0, fill = 0 }
    p.canRotate = true

    local function getLine()
        p.used.lines = p.used.lines + 1
        local t = p.pool.lines[p.used.lines]
        if not t then
            t = canvas:CreateTexture(nil, "ARTWORK")
            p.pool.lines[p.used.lines] = t
        end
        t:Show()
        return t
    end
    -- schmale senkrechte Streifen für die Fläche unter der Preislinie
    local function getFill()
        p.used.fill = p.used.fill + 1
        local t = p.pool.fill[p.used.fill]
        if not t then
            t = canvas:CreateTexture(nil, "BACKGROUND", nil, 3)
            p.pool.fill[p.used.fill] = t
        end
        t:Show()
        return t
    end
    local function getGrid()
        p.used.grid = p.used.grid + 1
        local t = p.pool.grid[p.used.grid]
        if not t then
            t = canvas:CreateTexture(nil, "BORDER")
            p.pool.grid[p.used.grid] = t
        end
        t:Show()
        return t
    end
    local function getLabel()
        p.used.labels = p.used.labels + 1
        local l = p.pool.labels[p.used.labels]
        if not l then
            l = canvas:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
            p.pool.labels[p.used.labels] = l
        end
        l:Show()
        return l
    end
    local function getDot()
        p.used.dots = p.used.dots + 1
        local d = p.pool.dots[p.used.dots]
        if not d then
            d = CreateFrame("Frame", nil, canvas)
            d:SetSize(10, 10)
            d.tex = d:CreateTexture(nil, "OVERLAY")
            d.tex:SetPoint("CENTER")
            d.tex:SetSize(5, 5)
            d.tex:SetColorTexture(1, 1, 1, 1)
            d:EnableMouse(true)
            d:SetScript("OnEnter", function(self)
                self.tex:SetSize(8, 8)
                UI:AnchorTooltip(self)
                if self.cross then
                    local c = self.cross
                    GameTooltip:AddLine(date("%d.%m.%Y %H:%M", c.t), 1, 1, 1)
                    if c.up then
                        GameTooltip:AddLine(L["EMA 1 Tag steigt über EMA 7 Tage"], 0.2, 0.87, 0.33)
                    else
                        GameTooltip:AddLine(L["EMA 1 Tag fällt unter EMA 7 Tage"], 1, 0.33, 0.27)
                    end
                    GameTooltip:AddLine(L["bei "] .. A:FormatMoney(math.floor(c.v + 0.5)), 0.8, 0.8, 0.8)
                    GameTooltip:Show()
                    return
                end
                GameTooltip:AddLine(date("%d.%m.%Y %H:%M", self.entry.t), 1, 1, 1)
                GameTooltip:AddLine(L["Preis: "] .. A:FormatMoney(self.entry.p), 1, 1, 1)
                GameTooltip:AddLine(L["Menge: "] .. tostring(self.entry.q or 0), 0.7, 0.7, 0.7)
                GameTooltip:AddLine(self.entry.s and L["Quelle: Mitspieler (Sync)"] or L["Quelle: eigener Scan"], 0.5, 0.8, 0.8)
                if self.entry.u then
                    GameTooltip:AddLine(L["Unbestätigt - vermutlich Lockangebot, zählt nicht"], 0.6, 0.6, 0.6)
                elseif self.entry.v then
                    GameTooltip:AddLine(L["Nachgeprüft (ohne Lockangebote)"], 0.5, 0.8, 0.5)
                end
                GameTooltip:Show()
            end)
            d:SetScript("OnLeave", function(self)
                self.tex:SetSize(self.size or 5, self.size or 5)
                GameTooltip:Hide()
            end)
            p.pool.dots[p.used.dots] = d
        end
        d.cross, d.size = nil, 5
        d.tex:SetSize(5, 5)
        d.tex:SetColorTexture(1, 1, 1, 1)
        d:Show()
        return d
    end

    local function clearCanvas()
        for kind, list in pairs(p.pool) do
            for _, obj in ipairs(list) do obj:Hide() end
            p.used[kind] = 0
        end
    end

    local function drawLine(x1, y1, x2, y2, r, g, b, a, thickness)
        if not p.canRotate then return end
        local dx, dy = x2 - x1, y2 - y1
        local len = math.sqrt(dx * dx + dy * dy)
        if len < 0.5 then return end
        local t = getLine()
        t:SetColorTexture(r, g, b, a or 1)
        t:ClearAllPoints()
        t:SetSize(len, thickness or 2)
        t:SetPoint("CENTER", canvas, "BOTTOMLEFT", (x1 + x2) / 2, (y1 + y2) / 2)
        local ok = pcall(t.SetRotation, t, math.atan2(dy, dx))
        if not ok then
            p.canRotate = false
            t:Hide()
        end
    end

    function p:Draw()
        clearCanvas()
        local emaOn = A.db.settings.chartEMA ~= false
        self.emaBtn:SetText(emaOn and L["EMA: an"] or L["EMA: aus"])
        for key, b in pairs(self.rangeButtons) do
            b.label:SetTextColor(unpack(key == self.range and C.accent or C.text))
        end
        self.list.selectedID = self.selected
        self.list:Render()

        if not self.selected then
            self.itemName:SetText(L["Kein Item gewählt"])
            self.stats:SetText("")
            self.message:SetText(L["Links ein Item auswählen."])
            self.message:Show()
            return
        end

        self.itemName:SetText(A:GetItemName(self.selected))

        local seconds
        for _, r in ipairs(RANGES) do if r.key == self.range then seconds = r.seconds end end
        local limit = seconds and (time() - seconds) or 0
        local points, real = {}, {}
        for _, e in ipairs(A:GetHistory(self.selected)) do
            if e.t >= limit then
                table.insert(points, e)
                if not e.u then table.insert(real, e) end
            end
        end

        -- EMAs (über den ganzen Verlauf berechnet, gezeigt im Zeitraum)
        local emas, crosses, emaCount = {}, {}, 0
        if emaOn then
            for _, def in ipairs(A.EMA) do
                local series = A:GetEMASeries(self.selected, def.tau)
                emaCount = #series
                if #series >= A.EMA_MIN_POINTS then
                    local vis = {}
                    for _, pt in ipairs(series) do if pt.t >= limit then table.insert(vis, pt) end end
                    table.insert(emas, { def = def, points = vis })
                end
            end
            if #emas > 0 then
                for _, c in ipairs(A:GetEMACrossings(self.selected, A.EMA[2].tau, A.EMA[3].tau)) do
                    if c.t >= limit then table.insert(crosses, c) end
                end
            end
        end

        local stats = A:GetStats(self.selected, seconds)
        local cur = A:GetCurrent(self.selected)
        if stats then
            local change = nil
            if #real >= 2 and real[1].p > 0 then
                change = (real[#real].p - real[1].p) / real[1].p * 100
            end
            self.stats:SetText(L["Aktuell "] .. A:FormatMoney(cur) .. L["    Median "] .. A:FormatMoney(stats.median)
                .. L["    Min "] .. A:FormatMoney(stats.min) .. L["    Max "] .. A:FormatMoney(stats.max)
                .. L["    Trend "] .. A:FormatPercent(change))
        else
            self.stats:SetText(L["Aktuell "] .. A:FormatMoney(cur))
        end

        if #points < 2 then
            self.message:SetText(L["Zu wenige Datenpunkte in diesem Zeitraum ("] .. #points .. L[").\nJeder Scan fügt einen Punkt hinzu - einen größeren Zeitraum wählen\noder später erneut scannen."])
            self.message:Show()
            return
        end
        self.message:Hide()

        local w, h = canvas:GetWidth(), canvas:GetHeight()
        if not w or w < 50 then w, h = 610, 430 end
        local padL, padR, padT, padB = 78, 16, 16, 28
        local plotW, plotH = w - padL - padR, h - padT - padB

        local minP, maxP = points[1].p, points[1].p
        local minT, maxT = points[1].t, points[#points].t
        for _, e in ipairs(points) do
            if e.p < minP then minP = e.p end
            if e.p > maxP then maxP = e.p end
        end
        for _, em in ipairs(emas) do
            for _, pt in ipairs(em.points) do
                if pt.v < minP then minP = pt.v end
                if pt.v > maxP then maxP = pt.v end
            end
        end
        if maxP == minP then
            minP = minP * 0.9
            maxP = maxP * 1.1 + 1
        else
            local margin = (maxP - minP) * 0.08
            minP = math.max(0, minP - margin)
            maxP = maxP + margin
        end
        -- Winzige Schwankungen (z.B. 5 Kupfer bei 6 Gold) nicht als Absturz zeichnen:
        -- Achse mindestens 2 % des Preises hoch
        local minSpan = maxP * 0.02
        if maxP - minP < minSpan then
            local mid = (maxP + minP) / 2
            minP = math.max(0, mid - minSpan / 2)
            maxP = mid + minSpan / 2
        end
        -- Beschriftung so genau, dass sich die Linien unterscheiden
        local step = (maxP - minP) / 4
        local preciseLabels = step < 10000 and maxP >= 10000
        if maxT == minT then maxT = minT + 1 end

        local function X(t) return padL + (t - minT) / (maxT - minT) * plotW end
        local function Y(price) return padB + (price - minP) / (maxP - minP) * plotH end

        -- Gitter + Preisbeschriftung
        for i = 0, 4 do
            local price = minP + (maxP - minP) * i / 4
            local y = Y(price)
            local g = getGrid()
            g:SetColorTexture(1, 1, 1, 0.06)
            g:ClearAllPoints()
            g:SetPoint("BOTTOMLEFT", canvas, "BOTTOMLEFT", padL, y)
            g:SetSize(plotW, 1)
            local l = getLabel()
            l:ClearAllPoints()
            l:SetPoint("RIGHT", canvas, "BOTTOMLEFT", padL - 6, y)
            l:SetJustifyH("RIGHT")
            l:SetText(A:FormatMoney(price, not preciseLabels))
        end

        -- Zeitbeschriftung
        local fmt = (maxT - minT) > 2 * 86400 and "%d.%m." or "%H:%M"
        for i = 0, 2 do
            local t = minT + (maxT - minT) * i / 2
            local l = getLabel()
            l:ClearAllPoints()
            l:SetPoint("TOP", canvas, "BOTTOMLEFT", X(t), padB - 6)
            l:SetJustifyH("CENTER")
            l:SetText(date(fmt, t))
        end

        -- Linie beim Median (Marktwert des Zeitraums)
        if stats then
            local ay = Y(stats.median)
            local g = getGrid()
            g:SetColorTexture(C.yellow[1], C.yellow[2], C.yellow[3], 0.35)
            g:ClearAllPoints()
            g:SetPoint("BOTTOMLEFT", canvas, "BOTTOMLEFT", padL, ay)
            g:SetSize(plotW, 1)
            local l = getLabel()
            l:ClearAllPoints()
            l:SetPoint("BOTTOMRIGHT", canvas, "BOTTOMLEFT", padL + plotW, ay + 2)
            l:SetJustifyH("RIGHT")
            l:SetText("|cffffcc33" .. L["Median"] .. "|r")
        end

        -- EMA-Linien (unter der Preislinie)
        for _, em in ipairs(emas) do
            local col = em.def.color
            local px, py
            for _, pt in ipairs(em.points) do
                local x, y = X(pt.t), Y(pt.v)
                if px then drawLine(px, py, x, y, col[1], col[2], col[3], 0.75, 1.5) end
                px, py = x, y
            end
        end

        -- Fläche unter der Preislinie: sanft nach unten auslaufend
        do
            local real = {}
            for _, e in ipairs(points) do if not e.u then table.insert(real, { X(e.t), Y(e.p) }) end end
            local STEP = 3
            for i = 2, #real do
                local x1, y1, x2, y2 = real[i - 1][1], real[i - 1][2], real[i][1], real[i][2]
                local x = x1
                while x < x2 do
                    local w = math.min(STEP, x2 - x)
                    local y = y1 + (y2 - y1) * ((x + w / 2 - x1) / math.max(1, x2 - x1))
                    if y > padB + 1 then
                        local f = getFill()
                        f:ClearAllPoints()
                        f:SetPoint("BOTTOMLEFT", canvas, "BOTTOMLEFT", x, padB)
                        f:SetSize(w + 0.5, y - padB)
                        UI:Gradient(f, "VERTICAL", C.accent[1], C.accent[2], C.accent[3], 0, C.accent[1], C.accent[2], C.accent[3], 0.22)
                    end
                    x = x + STEP
                end
            end
        end

        -- Linie (nur echte Preise) + Punkte (unbestätigte grau)
        local prevX, prevY
        local lastDot
        for _, e in ipairs(points) do
            local x, y = X(e.t), Y(e.p)
            if not e.u then
                if prevX then
                    drawLine(prevX, prevY, x, y, C.accent[1], C.accent[2], C.accent[3], 0.9, 2)
                end
                prevX, prevY = x, y
            end
            local d = getDot()
            d.entry = e
            d.tex:SetSize(4, 4)
            d.size = 4
            if e.u then d.tex:SetColorTexture(0.5, 0.5, 0.5, 0.8) else lastDot = d end
            d:ClearAllPoints()
            d:SetPoint("CENTER", canvas, "BOTTOMLEFT", x, y)
        end
        -- aktueller Preis hervorgehoben
        if lastDot then
            lastDot.size = 8
            lastDot.tex:SetSize(8, 8)
            lastDot.tex:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 1)
        end

        -- Kreuzungen 1 Tag / 7 Tage
        for _, c in ipairs(crosses) do
            local d = getDot()
            d.entry, d.cross, d.size = nil, c, 9
            d.tex:SetSize(9, 9)
            if c.up then d.tex:SetColorTexture(0.2, 0.87, 0.33, 1) else d.tex:SetColorTexture(1, 0.33, 0.27, 1) end
            d:ClearAllPoints()
            d:SetPoint("CENTER", canvas, "BOTTOMLEFT", X(c.t), Y(c.v))
        end

        -- Legende
        if emaOn then
            local l = getLabel()
            l:ClearAllPoints()
            l:SetPoint("TOPLEFT", canvas, "TOPLEFT", padL + 4, -4)
            l:SetJustifyH("LEFT")
            if #emas > 0 then
                local parts = {}
                for _, em in ipairs(emas) do
                    local col = em.def.color
                    table.insert(parts, string.format("|cff%02x%02x%02x%s|r", col[1] * 255, col[2] * 255, col[3] * 255, L[em.def.label]))
                end
                l:SetText(table.concat(parts, "   "))
            else
                l:SetText(string.format(L["EMAs ab %d echten Preisen (bisher %d)"], A.EMA_MIN_POINTS, emaCount))
            end
        end
    end

    function p:RefreshList()
        local list = A:BuildItemList(self.search:GetText())
        local set = self.qualPicker and self.qualPicker:GetSet()
        if set then
            local filtered = {}
            for _, it in ipairs(list) do
                local q
                if GetItemInfo then
                    local ok, _, _, quality = pcall(GetItemInfo, it.itemID)
                    if ok then q = quality end
                end
                if q == nil or set[q] then table.insert(filtered, it) end
            end
            list = filtered
        end
        self.list:SetData(list, true)
    end

    function p:Refresh()
        if UI.pendingChartItem then
            self.selected = UI.pendingChartItem
            UI.pendingChartItem = nil
        end
        local r = UI.chartReturn
        if r then
            local tab = UI:GetTab(r.tab)
            self.backBtn:SetText("< " .. L[tab and tab.label or r.tab])
            self.backBtn.tooltip = L["Zurück, an dieselbe Stelle in der Liste"]
            self.backBtn:Show()
            if head.line then head.line:Hide() end
        else
            self.backBtn:Hide()
            if head.line then head.line:Show() end
        end
        self:RefreshList()
        self:Draw()
    end

    return p
end

UI:RegisterTab("charts", "Charts", 4, BuildCharts)
