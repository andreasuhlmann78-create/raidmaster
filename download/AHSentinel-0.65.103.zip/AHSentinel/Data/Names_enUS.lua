if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- AHSentinel - Item-Namen (enUS), 25816 Items
-- Quelle: siehe Data/QUELLEN.txt. Automatisch erzeugt, nicht von Hand ändern.
AHAnalyzerPro_NameData = AHAnalyzerPro_NameData or {}
AHAnalyzerPro_NameData["enUS"] = [==[

25	Worn Shortsword
35	Bent Staff
36	Worn Mace
37	Worn Axe
38	Recruit's Shirt
39	Recruit's Pants
40	Recruit's Boots
43	Squire's Boots
44	Squire's Pants
45	Squire's Shirt
47	Footpad's Shoes
48	Footpad's Pants
49	Footpad's Shirt
51	Neophyte's Boots
52	Neophyte's Pants
53	Neophyte's Shirt
55	Apprentice's Boots
56	Apprentice's Robe
57	Acolyte's Robe
59	Acolyte's Shoes
60	Layered Tunic
61	Dwarven Leather Pants
79	Dwarven Cloth Britches
80	Soft Fur-lined Shoes
85	Dirty Leather Vest
117	Tough Jerky
118	Minor Healing Potion
120	Thug Pants
121	Thug Boots
127	Trapper's Shirt
129	Rugged Trapper's Boots
139	Brawler's Pants
140	Brawler's Boots
147	Rugged Trapper's Pants
148	Rugged Trapper's Shirt
153	Primitive Kilt
154	Primitive Mantle
159	Refreshing Spring Water
182	Garrick's Head
193	Tattered Cloth Vest
194	Tattered Cloth Pants
195	Tattered Cloth Boots
200	Thick Cloth Vest
201	Thick Cloth Pants
202	Thick Cloth Shoes
203	Thick Cloth Gloves
209	Dirty Leather Pants
210	Dirty Leather Boots
236	Cured Leather Armor
237	Cured Leather Pants
238	Cured Leather Boots
239	Cured Leather Gloves
285	Scalemail Vest
286	Scalemail Pants
287	Scalemail Boots
414	Dalaran Sharp
422	Dwarven Mild
537	Dull Frenzy Scale
555	Rough Vulture Feathers
556	Buzzard Beak
647	Destiny
710	Bracers of the People's Militia
711	Tattered Cloth Gloves
714	Dirty Leather Gloves
718	Scalemail Gloves
719	Rabbit Handler Gloves
720	Brawler Gloves
723	Goretusk Liver
724	Goretusk Liver Pie
725	Gnoll Paw
727	Notched Shortsword
728	Recipe: Westfall Stew
729	Stringy Vulture Meat
730	Murloc Eye
731	Goretusk Snout
732	Okra
733	Westfall Stew
735	Rolf and Malakai's Medallions
737	Holy Spring Water
738	Sack of Barley
739	Sack of Corn
740	Sack of Rye
742	A Sycamore Branch
743	Bundle of Charred Oak
744	Thunderbrew's Boot Flask
745	Marshal McBride's Documents
748	Stormwind Armor Marker
750	Tough Wolf Meat
752	Red Burlap Bandana
753	Dragonmaw Shortsword
754	Shortsword of Vengeance
755	Melted Candle
756	Tunnel Pick
763	Ice-covered Bracers
765	Silverleaf
766	Flanged Mace
767	Long Bo Staff
768	Lumberjack Axe
769	Chunk of Boar Meat
770	Pointy Crocolisk Tooth
771	Chipped Boar Tusk
772	Large Candle
773	Gold Dust
774	Malachite
776	Vendetta
777	Prowler Teeth
778	Kobold Excavation Pick
779	Shiny Seashell
780	Torn Murloc Fin
781	Stone Gnoll Hammer
782	Painted Gnoll Armband
783	Light Hide
785	Mageroyal
787	Slitherskin Mackerel
789	Stout Battlehammer
790	Forester's Axe
791	Gnarled Ash Staff
792	Knitted Sandals
793	Knitted Gloves
794	Knitted Pants
795	Knitted Tunic
796	Rough Leather Boots
797	Rough Leather Gloves
798	Rough Leather Pants
799	Rough Leather Vest
804	Large Blue Sack
805	Small Red Pouch
809	Bloodrazor
810	Hammer of the Northern Wind
811	Axe of the Deep Woods
812	Glowing Brightwood Staff
813	Broken Cog
814	Flask of Oil
816	Small Hand Blade
818	Tigerseye
820	Slicer Blade
821	Riverpaw Leather Vest
826	Brutish Riverpaw Axe
827	Wicked Blackjack
828	Small Blue Pouch
829	Red Leather Bandana
832	Silver Defias Belt
833	Lifestone
835	Large Rope Net
837	Heavy Weave Armor
838	Heavy Weave Pants
839	Heavy Weave Gloves
840	Heavy Weave Shoes
841	Furlbrow's Pocket Watch
843	Tanned Leather Boots
844	Tanned Leather Gloves
845	Tanned Leather Pants
846	Tanned Leather Jerkin
847	Chainmail Armor
848	Chainmail Pants
849	Chainmail Boots
850	Chainmail Gloves
851	Cutlass
852	Mace
853	Hatchet
854	Quarter Staff
856	Blue Leather Bag
857	Large Red Sack
858	Lesser Healing Potion
859	Fine Cloth Shirt
860	Cavalier's Boots
862	Runed Ring
863	Gloom Reaper
864	Knightly Longsword
865	Leaden Mace
866	Monk's Staff
867	Gloves of Holy Might
868	Ardent Custodian
869	Dazzling Longsword
870	Fiery War Axe
871	Flurry Axe
872	Rockslicer
873	Staff of Jordan
875	Brown Horse Summoning
876	Worn Wooden Buckler
878	Fist-sized Spinneret
880	Staff of Horrors
884	Ghoul Rib
885	Black Metal Axe
886	Black Metal Shortsword
887	Pound of Flesh
888	Naga Battle Gloves
889	A Dusty Unsent Letter
890	Twisted Chanter's Staff
892	Gnoll Casting Gloves
893	Dire Wolf Fang
895	Worgen Skull
896	Worgen Fang
897	Madwolf Bracers
899	Venom Web Fang
901	Deptecated White Stallion Summoning (Mount)
910	An Undelivered Letter
911	Ironwood Treebranch
913	Huge Ogre Sword
914	Large Ogre Chain Armor
915	Red Silk Bandana
916	A Torn Journal Page
918	Deviate Hide Pack
920	Wicked Spiked Mace
921	A Faded Journal Page
922	Dacian Falx
923	Longsword
924	Maul
925	Flail
926	Battle Axe
927	Double Axe
928	Long Staff
929	Healing Potion
932	Fel Steed Saddlebags
933	Large Rucksack
934	Stalvan's Reaper
935	Night Watch Shortsword
936	Midnight Mace
937	Black Duskwood Staff
938	Muddy Journal Pages
939	A Bloodstained Journal Page
940	Robes of Insight
942	Freezing Band
943	Warden Staff
944	Elemental Mage Staff
945	Shadow Sword
948	Nature Sword
954	Scroll of Strength
955	Scroll of Intellect
957	William's Shipment
961	Healing Herb
962	Pork Belly Pie
966	Tome of Frost Shield
967	Tome of Frost Ward
968	Tome of Fire Blast
973	Tome of Fireball II
974	Tome of Frost Armor II
975	Tome of Chains of Ice
976	Tome of Remove Curse
980	Tome of Frost Shield II
981	Bernice's Necklace
983	Red Linen Sash
985	Tome of Khadgar's Unlocking
986	Tome of Frostbolt II
989	Tome of Frost Nova
992	Tome of Fireball III
994	Tome of Ice Armor
997	Fire Sword of Crippling
1004	Tome of Chains of Ice II
1006	Brass Collar
1008	Well-used Sword
1009	Compact Hammer
1010	Gnarled Short Staff
1011	Sharp Axe
1013	Iron Rivet
1015	Lean Wolf Flank
1017	Seasoned Wolf Kabob
1019	Red Linen Bandana
1029	Tablet of Serpent Totem
1030	Tablet of Unyielding Will
1031	Tablet of Molten Blast
1032	Tablet of Agitating Totem
1033	Tablet of Nullify Poison
1034	Tablet of Undying Strength
1035	Tablet of Call Spirit
1036	Tablet of Nullify Disease
1037	Tablet of Lightning Bolt II
1038	Tablet of Restoration II
1041	Horn of the Black Wolf
1048	Tablet of Lightning Shield II
1049	Tablet of Purge
1052	Tablet of Spirit Armor II
1053	Tablet of Molten Blast II
1057	Tablet of Restoration III
1058	Tablet of Lightning Bolt III
1061	Tablet of Nullify Poison II
1063	Tablet of Nullify Disease II
1072	Full Moonshine
1074	Hard Spider Leg Tip
1075	Shadowhide Pendant
1076	Defias Renegade Ring
1077	Defias Mage Ring
1080	Tough Condor Meat
1081	Crisp Spider Meat
1082	Redridge Goulash
1083	Glyph of Azora
1084	Codex of Renew
1085	Codex of Mind Vision
1086	Codex of Inner Fire
1087	Codex of Shadow Word: Pain
1088	Codex of Renew II
1089	Codex of Nullify Disease
1090	Codex of Resurrection
1091	Codex of Holy Smite II
1092	Codex of Lesser Heal II
1093	Codex of Remove Curse
1095	Codex of Dispel Magic
1096	Codex of Shadow Word: Pain II
1100	Monster Bag
1101	Codex of Renew V
1102	Codex of Lesser Heal III
1105	Codex of Renew VI
1108	Codex of Renew III
1109	Codex of Dominate
1111	Codex of Sleep
1112	Codex of Holy Word: Fortitude II
1113	Conjured Bread
1114	Conjured Rye
1116	Ring of Pure Silver
1119	Bottled Spirits
1121	Feet of the Lynx
1127	Flash Bundle
1129	Ghoul Fang
1130	Vial of Spider Venom
1131	Totem of Infliction
1132	Horn of the Timber Wolf
1133	Horn of the Winter Wolf
1134	Horn of the Gray Wolf
1136	Libram: Divine Favor II
1138	Libram: Divine Favor
1139	Libram: Cleanse
1141	Libram: Holy Light II
1144	Libram: Divine Shield
1146	Libram: Resurrection
1149	Libram: Seal of Might II
1150	Libram: Purify
1151	Libram: Holy Light III
1154	Belt of the People's Militia
1155	Rod of the Sleepwalker
1156	Lavishly Jeweled Ring
1158	Solid Metal Club
1159	Militia Quarterstaff
1161	Militia Shortsword
1164	Sam's Tome
1166	Dented Buckler
1167	Small Targe
1168	Skullflame Shield
1169	Blackskull Shield
1171	Well-stitched Robe
1172	Grayson's Torch
1173	Weather-worn Boots
1175	A Gold Tooth
1176	Smelling Salts
1177	Oil of Olaf
1178	Explosive Rocket
1179	Ice Cold Milk
1180	Scroll of Stamina
1181	Scroll of Spirit
1182	Brass-studded Bracers
1183	Elastic Wristguards
1187	Spiked Collar
1189	Overseer's Ring
1190	Overseer's Cloak
1191	Bag of Marbles
1193	Banded Buckler
1194	Bastard Sword
1195	Kobold Mining Shovel
1196	Tabar
1197	Giant Mace
1198	Claymore
1199	Charged Soulstone
1200	Large Wooden Shield
1201	Dull Heater Shield
1202	Wall Shield
1203	Aegis of Stormwind
1204	The Green Tower
1205	Melon Juice
1206	Moss Agate
1207	Murphstar
1208	Maybell's Love Letter
1210	Shadowgem
1211	Gnoll War Harness
1212	Gnoll Spittle
1213	Gnoll Kindred Bracers
1214	Gnoll Punisher
1215	Support Girdle
1216	Frost Bracers
1217	Unknown Reward
1218	Heavy Gnoll War Club
1219	Redridge Machete
1220	Lupine Axe
1221	Underbelly Whelp Scale
1222	Broken Tooth
1224	Grimoire of Sense Demons
1228	Grimoire of Blood Boil
1229	Grimoire of Create Soulstone
1231	Grimoire of Shadow Bolt II
1232	Grimoire of Demon Skin II
1238	Grimoire of Fear
1239	Grimoire of Siphon Mana
1243	Grimoire of Shadow Bolt III
1244	Grimoire of Demon Armor
1245	Grimoire of Immolate II
1246	Grimoire of Demon Breath
1250	Grimoire of Detect Lesser Invisibility
1251	Linen Bandage
1252	Gramma Stonefield's Note
1254	Lesser Firestone
1256	Crystal Kelp Frond
1257	Invisibility Liquor
1260	Tharil'zun's Head
1261	Midnight Orb
1262	Keg of Thunderbrew Lager
1263	Brain Hacker
1264	Headbasher
1265	Scorpion Sting
1270	Finely Woven Cloak
1273	Forest Chain
1274	Hops
1275	Deputy Chain Coat
1276	Fire Hardened Buckler
1280	Cloaked Hood
1282	Sparkmetal Coif
1283	Verner's Note
1284	Crate of Horseshoes
1287	Giant Tarantula Fang
1288	Large Venom Sac
1292	Butcher's Cleaver
1293	The State of Lakeshire
1294	The General's Response
1296	Blackrock Mace
1297	Robes of the Shadowcaster
1299	Lesser Belt of the Spire
1300	Lesser Staff of the Spire
1302	Black Whelp Gloves
1303	Bridgeworker's Gloves
1304	Riding Gloves
1306	Wolfmane Wristguards
1307	Gold Pickup Schedule
1309	Oslow's Toolbox
1310	Smith's Trousers
1314	Ghoul Fingers
1315	Lei of Lilies
1317	Hardened Root Staff
1318	Night Reaver
1319	Ring of Iron Will
1322	Fishliver Oil
1325	Daffodil Bouquet
1326	Sauteed Sunfish
1327	Wiley's Note
1328	Book of Faerie Fire
1332	Book of Cure Poison
1334	Book of Rejuvenation II
1339	Book of Entangling Roots
1341	Book of Moonfire
1349	Abercrombie's Crate
1351	Fingerbone Bracers
1352	Cracked Skull Mortar
1353	Shaw's Report
1355	Buckskin Cape
1356	Commendation - Elwynn Forest
1357	Captain Sander's Treasure Map
1358	A Clue to Sander's Treasure
1359	Lion-stamped Gloves
1360	Stormwind Chain Gloves
1361	Another Clue to Sander's Treasure
1362	Final Clue to Sander's Treasure
1364	Ragged Leather Vest
1366	Ragged Leather Pants
1367	Ragged Leather Boots
1368	Ragged Leather Gloves
1369	Ragged Leather Belt
1370	Ragged Leather Bracers
1372	Ragged Cloak
1374	Frayed Shoes
1376	Frayed Cloak
1377	Frayed Gloves
1378	Frayed Pants
1380	Frayed Robe
1381	A Mysterious Message
1382	Rock Mace
1383	Stone Tomahawk
1384	Dull Blade
1386	Thistlewood Axe
1387	Ghoulfang
1388	Crooked Staff
1389	Kobold Mining Mallet
1391	Riverpaw Mystic Staff
1394	Driftwood Club
1395	Apprentice's Pants
1396	Acolyte's Pants
1399	Magic Candle
1400	Swiftfeather Token
1401	Green Tea Leaf
1402	Brimstone
1404	Tidal Charm
1405	Foamspittle Staff
1406	Pearl-encrusted Spear
1407	Solomon's Plea to Westfall
1408	Stoutmantle's Response to Solomon
1409	Solomon's Plea to Darkshire
1410	Ebonlocke's Response to Solomon
1411	Withered Staff
1412	Crude Bastard Sword
1413	Feeble Sword
1414	Cracked Sledge
1415	Carpenter's Mallet
1416	Rusty Hatchet
1417	Beaten Battle Axe
1418	Worn Leather Belt
1419	Worn Leather Boots
1420	Worn Leather Bracers
1421	Worn Hide Cloak
1422	Worn Leather Gloves
1423	Worn Leather Pants
1425	Worn Leather Vest
1427	Patchwork Shoes
1429	Patchwork Cloak
1430	Patchwork Gloves
1431	Patchwork Pants
1433	Patchwork Armor
1434	Glowing Wax Stick
1436	Frontier Britches
1438	Warrior's Shield
1440	Gnoll Skull Basher
1443	Jeweled Amulet of Cainwyn
1445	Blackrock Pauldrons
1446	Blackrock Boots
1447	Ring of Saviors
1448	Blackrock Gauntlets
1449	Minor Channeling Ring
1450	Potion of Fervor
1451	Bottle of Zombie Juice
1453	Spectral Comb
1454	Axe of the Enforcer
1455	Blackrock Champion's Axe
1457	Shadowhide Mace
1458	Shadowhide Maul
1459	Shadowhide Scalper
1460	Shadowhide Two-handed Sword
1461	Slayer's Battle Axe
1462	Ring of the Shadow
1464	Buzzard Talon
1465	Tigerbane
1467	Spotted Sunfish
1468	Murloc Fin
1469	Scimitar of Atun
1470	Murloc Skin Bag
1473	Riverside Staff
1475	Small Venom Sac
1476	Snapped Spider Limb
1477	Scroll of Agility II
1478	Scroll of Protection II
1479	Salma's Oven Mitts
1480	Fist of the People's Militia
1481	Grimclaw
1482	Shadowfang
1483	Face Smasher
1484	Witching Stave
1485	Pitchfork
1486	Tree Bark Jacket
1487	Conjured Pumpernickel
1488	Avenger's Armor
1489	Gloomshroud Armor
1490	Guardian Talisman
1491	Ring of Precision
1493	Heavy Marauder Scimitar
1495	Calico Shoes
1497	Calico Cloak
1498	Calico Gloves
1499	Calico Pants
1500	Master Totem
1501	Calico Tunic
1502	Warped Leather Belt
1503	Warped Leather Boots
1504	Warped Leather Bracers
1505	Warped Cloak
1506	Warped Leather Gloves
1507	Warped Leather Pants
1509	Warped Leather Vest
1510	Heavy Hammer
1511	Commoner's Sword
1512	Crude Battle Axe
1514	Rusty Warhammer
1515	Rough Wooden Staff
1516	Worn Hatchet
1518	Ghost Hair Comb
1519	Bloodscalp Ear
1520	Troll Sweat
1521	Lumbering Ogre Axe
1522	Headhunting Spear
1523	Huge Stone Club
1524	Skullsplitter Tusk
1528	Handful of Oats
1529	Jade
1532	Shrunken Head
1534	Libram: Holy Light IV
1536	Libram: Seal of Wrath
1539	Gnarled Hermit's Staff
1547	Shield of the Faith
1554	Tome of Frostbolt III
1557	Buckler of the Seas
1559	Tome of Arcane Missiles II
1560	Bluegill Sandals
1561	Harvester's Robe
1566	Edge of the People's Militia
1567	Tome of Khadgar's Unlocking II
1568	Tome of Water Elemental
1571	Tome of Frost Nova II
1574	Tome of Fire Ward
1588	Tablet of Molten Blast III
1589	Tablet of Spirit Armor III
1591	Tablet of Lightning Shield III
1596	Ghost Hair Thread
1597	Tablet of Lightning Storm
1598	Rot Blossom
1602	Sickle Axe
1603	Tablet of Call Spirit II
1604	Chromatic Sword
1607	Soulkeeper
1608	Skullcrusher Mace
1613	Spiritchaser Staff
1619	Tablet of Lightning Storm II
1623	Raptor Skin Pouch
1624	Skullsplitter Helm
1625	Exquisite Flamberge
1630	Broken Electro-lantern
1637	Letter to Ello
1639	Grinning Axe
1640	Monstrous War Axe
1641	Codex of Shadow Word: Pain III
1645	Moonberry Juice
1648	Codex of Heal IV
1651	Codex of Holy Word: Shield VI
1652	Sturdy Lunchbox
1656	Translated Letter
1657	Codex of Resurrection II
1658	Codex of Shadow Word: Pain IV
1659	Engineering Gloves
1664	Spellforce Rod
1676	Codex of Sleep II
1677	Drake-scale Vest
1678	Black Ogre Kickers
1679	Korg Bat
1680	Headchopper
1681	Grimoire of Cripple
1685	Troll-hide Bag
1686	Bristly Whisker
1687	Retractable Claw
1688	Long Soft Tail
1696	Curved Raptor Talon
1697	Keen Raptor Tooth
1701	Curved Basilisk Claw
1702	Intact Basilisk Spine
1703	Crystal Basilisk Spine
1705	Lesser Moonstone
1706	Azuredeep Shards
1707	Stormwind Brie
1708	Sweet Nectar
1710	Greater Healing Potion
1711	Scroll of Stamina II
1712	Scroll of Spirit II
1713	Ankh of Life
1714	Necklace of Calisea
1715	Polished Jazeraint Armor
1716	Robe of the Magi
1717	Double Link Tunic
1718	Basilisk Hide Pants
1720	Tanglewood Staff
1721	Viking Warhammer
1722	Thornstone Sledgehammer
1725	Large Knapsack
1726	Poison-tipped Bone Spear
1727	Sword of Decay
1728	Teebu's Blazing Longsword
1729	Gunnysack of the Night Watch
1730	Worn Mail Belt
1731	Worn Mail Boots
1732	Worn Mail Bracers
1733	Worn Cloak
1734	Worn Mail Gloves
1735	Worn Mail Pants
1737	Worn Mail Vest
1738	Laced Mail Belt
1739	Laced Mail Boots
1740	Laced Mail Bracers
1741	Laced Cloak
1742	Laced Mail Gloves
1743	Laced Mail Pants
1744	Laced Mail Shoulderpads
1745	Laced Mail Vest
1746	Linked Chain Belt
1747	Linked Chain Boots
1748	Linked Chain Bracers
1749	Linked Chain Cloak
1750	Linked Chain Gloves
1751	Linked Chain Pants
1752	Linked Chain Shoulderpads
1753	Linked Chain Vest
1754	Reinforced Chain Belt
1755	Reinforced Chain Boots
1756	Reinforced Chain Bracers
1757	Reinforced Chain Cloak
1758	Reinforced Chain Gloves
1759	Reinforced Chain Pants
1760	Reinforced Chain Shoulderpads
1761	Reinforced Chain Vest
1764	Canvas Shoes
1766	Canvas Cloak
1767	Canvas Gloves
1768	Canvas Pants
1769	Canvas Shoulderpads
1770	Canvas Vest
1772	Brocade Shoes
1774	Brocade Cloak
1775	Brocade Gloves
1776	Brocade Pants
1777	Brocade Shoulderpads
1778	Brocade Vest
1780	Cross-stitched Sandals
1782	Cross-stitched Cloak
1783	Cross-stitched Gloves
1784	Cross-stitched Pants
1785	Cross-stitched Shoulderpads
1786	Cross-stitched Vest
1787	Patched Leather Belt
1788	Patched Leather Boots
1789	Patched Leather Bracers
1790	Patched Cloak
1791	Patched Leather Gloves
1792	Patched Leather Pants
1793	Patched Leather Shoulderpads
1794	Patched Leather Jerkin
1795	Rawhide Belt
1796	Rawhide Boots
1797	Rawhide Bracers
1798	Rawhide Cloak
1799	Rawhide Gloves
1800	Rawhide Pants
1801	Rawhide Shoulderpads
1802	Rawhide Tunic
1803	Tough Leather Belt
1804	Tough Leather Boots
1805	Tough Leather Bracers
1806	Tough Cloak
1807	Tough Leather Gloves
1808	Tough Leather Pants
1809	Tough Leather Shoulderpads
1810	Tough Leather Armor
1811	Blunt Claymore
1812	Short-handled Battle Axe
1813	Chipped Quarterstaff
1814	Battered Mallet
1815	Ornamental Mace
1816	Unbalanced Axe
1817	Stock Shortsword
1818	Standard Claymore
1819	Gouging Pick
1820	Wooden Maul
1821	Warped Blade
1822	Cedar Walking Stick
1823	Bludgeoning Cudgel
1824	Shiny War Axe
1825	Bulky Bludgeon
1826	Rock Maul
1827	Meat Cleaver
1828	Stone War Axe
1829	Short Cutlass
1830	Long Bastard Sword
1831	Oaken War Staff
1832	Lucky Trousers
1835	Dirty Leather Belt
1836	Dirty Leather Bracers
1839	Rough Leather Belt
1840	Rough Leather Bracers
1843	Tanned Leather Belt
1844	Tanned Leather Bracers
1845	Chainmail Belt
1846	Chainmail Bracers
1849	Cured Leather Belt
1850	Cured Leather Bracers
1851	Cleansing Water
1852	Scalemail Bracers
1853	Scalemail Belt
1875	Thistlenettle's Badge
1877	Book of Rejuvenation III
1882	Book of Moonfire III
1886	Book of Moonfire II
1893	Miner's Revenge
1894	Miners' Union Card
1913	Studded Blackjack
1917	Jeweled Dagger
1922	Supplies for Sven
1923	Ambassador's Satchel
1925	Defias Rapier
1926	Weighted Sap
1927	Deadmines Cleaver
1928	Defias Mage Staff
1929	Silk-threaded Trousers
1930	Stonemason Cloak
1931	Huge Gnoll Claw
1933	Staff of Conjuring
1934	Stonemason Trousers
1935	Assassin's Blade
1936	Goblin Screwdriver
1937	Buzz Saw
1938	Block Mallet
1939	Skin of Sweet Rum
1941	Cask of Merlot
1942	Bottle of Moonshine
1943	Goblin Mail Leggings
1944	Metalworking Gloves
1945	Woodworking Gloves
1946	Mary's Looking Glass
1951	Blackwater Cutlass
1955	Dragonmaw Chain Boots
1956	Faded Shadowhide Pendant
1958	Petrified Shinbone
1959	Cold Iron Pick
1962	Glowing Shadowhide Pendant
1965	White Wolf Gloves
1968	Ogre's Monocle
1970	Restoring Balm
1971	Furlbrow's Deed
1972	Westfall Deed
1973	Orb of Deception
1974	Mindthrust Bracers
1976	Slaghammer
1977	20-slot Bag
1978	Wolfclaw Gloves
1979	Wall of the Dead
1980	Underworld Band
1981	Icemail Jerkin
1982	Nightblade
1986	Gutrender
1987	Krazek's Fixed Pot
1988	Chief Brigadier Gauntlets
1990	Ballast Maul
1991	Goblin Power Shovel
1992	Swampchill Fetish
1993	Ogremind Ring
1994	Ebonclaw Reaver
1996	Voodoo Band
1997	Pressed Felt Robe
1998	Bloodscalp Channeling Staff
2000	Archeus
2004	Grelin Whitebeard's Journal
2005	The First Troll Legend
2006	The Second Troll Legend
2007	The Third Troll Legend
2008	The Fourth Troll Legend
2011	Twisted Sabre
2013	Cryptbone Staff
2014	Black Metal Greatsword
2015	Black Metal War Axe
2016	Dusty Chain Armor
2017	Glowing Leather Bracers
2018	Skeletal Longsword
2020	Hollowfang Blade
2021	Green Carapace Shield
2024	Espadon
2025	Bearded Axe
2026	Rock Hammer
2027	Scimitar
2028	Hammer
2029	Cleaver
2030	Gnarled Staff
2032	Gallan Cuffs
2033	Ambassador's Boots
2034	Scholarly Robes
2035	Sword of the Night Sky
2036	Dusty Mining Gloves
2037	Tunneler's Boots
2039	Plains Ring
2040	Troll Protector
2041	Tunic of Westfall
2042	Staff of Westfall
2043	Ring of Forlorn Spirits
2044	Crescent of Forlorn Spirits
2046	Bluegill Kukri
2047	Anvilmar Hand Axe
2048	Anvilmar Hammer
2054	Trogg Hand Axe
2055	Small Wooden Hammer
2056	The Velvet Hammer
2057	Pitted Defias Shortsword
2058	Kazon's Maul
2059	Sentry Cloak
2064	Trogg Club
2065	Rockjaw Blade
2066	Skull Hatchet
2067	Frostbit Staff
2069	Black Bear Hide Vest
2070	Darnassian Bleu
2072	Dwarven Magestaff
2073	Dwarven Hatchet
2074	Solid Shortblade
2075	Priest's Mace
2077	Magician Staff
2078	Northern Shortsword
2079	Sergeant's Warhammer
2080	Hillborne Axe
2082	Wizbang's Gunnysack
2084	Darksteel Bastard Sword
2085	Chunk of Flesh
2087	Hard Crawler Carapace
2088	Long Crawler Limb
2089	Scrimshaw Dagger
2091	Magic Dust
2092	Worn Dagger
2098	Double-barreled Shotgun
2099	Dwarven Hand Cannon
2100	Precisely Calibrated Boomstick
2101	Light Quiver
2102	Small Ammo Pouch
2105	Thug Shirt
2108	Frostmane Leather Vest
2109	Frostmane Chain Vest
2110	Light Magesmith Robe
2112	Lumberjack Jerkin
2113	Calor's Note
2114	Snowy Robe
2117	Thin Cloth Shoes
2119	Thin Cloth Gloves
2120	Thin Cloth Pants
2121	Thin Cloth Armor
2122	Cracked Leather Belt
2123	Cracked Leather Boots
2124	Cracked Leather Bracers
2125	Cracked Leather Gloves
2126	Cracked Leather Pants
2127	Cracked Leather Vest
2128	Scratched Claymore
2129	Large Round Shield
2130	Club
2131	Shortsword
2132	Short Staff
2133	Small Shield
2134	Hand Axe
2136	Conjured Purified Water
2137	Whittling Knife
2138	Sharpened Letter Opener
2139	Dirk
2140	Carving Knife
2141	Cuirboulli Vest
2142	Cuirboulli Belt
2143	Cuirboulli Boots
2144	Cuirboulli Bracers
2145	Cuirboulli Gloves
2146	Cuirboulli Pants
2148	Polished Scale Belt
2149	Polished Scale Boots
2150	Polished Scale Bracers
2151	Polished Scale Gloves
2152	Polished Scale Leggings
2153	Polished Scale Vest
2154	The Story of Morgan Ladimore
2156	Padded Boots
2158	Padded Gloves
2159	Padded Pants
2160	Padded Armor
2161	Book from Sven's Farm
2162	Sarah's Ring
2163	Shadowblade
2164	Gut Ripper
2166	Foreman's Leggings
2167	Foreman's Gloves
2168	Foreman's Boots
2169	Buzzer Blade
2172	Rustic Belt
2175	Shadowhide Battle Axe
2186	Outfitter Belt
2187	A Stack of Letters
2188	A Letter to Grelin Whitebeard
2194	Diamond Hammer
2195	Anvilmar Knife
2203	Brashclaw's Chopper
2204	Brashclaw's Skewer
2205	Duskbringer
2207	Jambiya
2208	Poniard
2209	Kris
2210	Battered Buckler
2211	Bent Large Shield
2212	Cracked Buckler
2213	Worn Large Shield
2214	Wooden Buckler
2215	Wooden Shield
2216	Simple Buckler
2217	Rectangular Shield
2218	Craftsman's Dagger
2219	Small Round Shield
2220	Box Shield
2221	Targe Shield
2222	Tower Shield
2223	The Collector's Schedule
2224	Militia Dagger
2225	Sharp Kitchen Knife
2226	Ogremage Staff
2227	Heavy Ogre War Axe
2230	Gloves of Brawn
2231	Inferno Robe
2232	Dark Runner Boots
2233	Shadow Weaver Leggings
2234	Nightwalker Armor
2235	Brackclaw
2236	Blackfang
2237	Patched Pants
2238	Urchin's Pants
2239	The Collector's Ring
2240	Rugged Cape
2241	Desperado Cape
2243	Hand of Edward the Odd
2244	Krol Blade
2245	Helm of Narv
2246	Myrmidon's Signet
2249	Militia Buckler
2250	Dusky Crab Cakes
2251	Gooey Spider Leg
2252	Miscellaneous Goblin Supplies
2254	Icepane Warhammer
2256	Skeletal Club
2257	Frostmane Staff
2258	Frostmane Shortsword
2259	Frostmane Club
2260	Frostmane Hand Axe
2262	Mark of Kern
2263	Phytoblade
2264	Mantle of Thieves
2265	Stonesplinter Axe
2266	Stonesplinter Dagger
2267	Stonesplinter Mace
2268	Stonesplinter Blade
2271	Staff of the Blessed Seer
2273	Guerrilla Armor
2274	Sapper's Gloves
2276	Swampwalker Boots
2277	Necromancer Leggings
2278	Forest Tracker Epaulets
2280	Kam's Walking Stick
2281	Rodentia Flint Axe
2282	Rodentia Shortsword
2283	Rat Cloth Belt
2284	Rat Cloth Cloak
2287	Haunch of Meat
2288	Conjured Fresh Water
2289	Scroll of Strength II
2290	Scroll of Intellect II
2291	Kang the Decapitator
2292	Necrology Robes
2295	Large Boar Tusk
2296	Great Goretusk Snout
2299	Burning War Axe
2300	Embossed Leather Vest
2302	Handstitched Leather Boots
2303	Handstitched Leather Pants
2304	Light Armor Kit
2307	Fine Leather Boots
2308	Fine Leather Cloak
2309	Embossed Leather Boots
2310	Embossed Leather Cloak
2311	White Leather Jerkin
2312	Fine Leather Gloves
2313	Medium Armor Kit
2314	Toughened Leather Armor
2315	Dark Leather Boots
2316	Dark Leather Cloak
2317	Dark Leather Tunic
2318	Light Leather
2319	Medium Leather
2320	Coarse Thread
2321	Fine Thread
2324	Bleach
2325	Black Dye
2326	Ivy-weave Bracers
2327	Sturdy Leather Bracers
2361	Battleworn Hammer
2362	Worn Wooden Shield
2364	Woven Vest
2366	Woven Pants
2367	Woven Boots
2369	Woven Gloves
2370	Battered Leather Harness
2371	Battered Leather Belt
2372	Battered Leather Pants
2373	Battered Leather Boots
2374	Battered Leather Bracers
2375	Battered Leather Gloves
2376	Worn Heater Shield
2377	Round Buckler
2378	Skeleton Finger
2379	Tarnished Chain Vest
2380	Tarnished Chain Belt
2381	Tarnished Chain Leggings
2382	The Embalmer's Heart
2383	Tarnished Chain Boots
2384	Tarnished Chain Bracers
2385	Tarnished Chain Gloves
2386	Rusted Chain Vest
2387	Rusted Chain Belt
2388	Rusted Chain Leggings
2389	Rusted Chain Boots
2390	Rusted Chain Bracers
2391	Rusted Chain Gloves
2392	Light Mail Armor
2393	Light Mail Belt
2394	Light Mail Leggings
2395	Light Mail Boots
2396	Light Mail Bracers
2397	Light Mail Gloves
2398	Light Chain Armor
2399	Light Chain Belt
2400	Light Chain Leggings
2401	Light Chain Boots
2402	Light Chain Bracers
2403	Light Chain Gloves
2406	Pattern: Fine Leather Boots
2407	Pattern: White Leather Jerkin
2408	Pattern: Fine Leather Gloves
2409	Pattern: Dark Leather Tunic
2410	Smoky Torch
2411	Black Stallion Bridle
2413	Palomino
2414	Pinto Bridle
2415	White Stallion
2417	Augmented Chain Vest
2418	Augmented Chain Leggings
2419	Augmented Chain Belt
2420	Augmented Chain Boots
2421	Augmented Chain Bracers
2422	Augmented Chain Gloves
2423	Brigandine Vest
2424	Brigandine Belt
2425	Brigandine Leggings
2426	Brigandine Boots
2427	Brigandine Bracers
2428	Brigandine Gloves
2429	Russet Vest
2431	Russet Pants
2432	Russet Boots
2434	Russet Gloves
2435	Embroidered Armor
2437	Embroidered Pants
2438	Embroidered Boots
2440	Embroidered Gloves
2441	Ringed Buckler
2442	Reinforced Targe
2443	Metal Buckler
2444	Ornate Buckler
2445	Large Metal Shield
2446	Kite Shield
2447	Peacebloom
2448	Heavy Pavise
2449	Earthroot
2450	Briarthorn
2451	Crested Heater Shield
2452	Swiftthistle
2453	Bruiseweed
2454	Elixir of Lion's Strength
2455	Minor Mana Potion
2456	Minor Rejuvenation Potion
2457	Elixir of Minor Agility
2458	Elixir of Minor Fortitude
2459	Swiftness Potion
2460	Elixir of Tongues (NYI)
2463	Studded Doublet
2464	Studded Belt
2465	Studded Pants
2466	Skullsplitter Fetish
2467	Studded Boots
2468	Studded Bracers
2469	Studded Gloves
2470	Reinforced Leather Vest
2471	Reinforced Leather Belt
2472	Reinforced Leather Pants
2473	Reinforced Leather Boots
2474	Reinforced Leather Bracers
2475	Reinforced Leather Gloves
2476	Chilled Basilisk Haunch
2477	Ravager's Skull
2479	Broad Axe
2480	Large Club
2481	Peon Sword
2482	Inferior Tomahawk
2483	Rough Broad Axe
2484	Small Knife
2485	Splintered Board
2486	Large Stone Mace
2487	Acolyte Staff
2488	Gladius
2489	Two-handed Sword
2490	Tomahawk
2491	Large Axe
2492	Cudgel
2493	Wooden Mallet
2494	Stiletto
2495	Walking Stick
2496	Raider Shortsword
2497	Rusted Claymore
2498	Small Tomahawk
2499	Double-bladed Axe
2500	Light Hammer
2501	Wooden Warhammer
2502	Scuffed Dagger
2503	Adept Short Staff
2504	Worn Shortbow
2505	Polished Shortbow
2506	Hornwood Recurve Bow
2507	Laminated Recurve Bow
2509	Ornate Blunderbuss
2510	Solid Blunderbuss
2511	Hunter's Boomstick
2512	Rough Arrow
2514	Depricated Sharp Arrow
2515	Sharp Arrow
2516	Light Shot
2519	Heavy Shot
2520	Broadsword
2521	Flamberge
2522	Crescent Axe
2523	Bullova
2524	Truncheon
2525	War Hammer
2526	Main Gauche
2527	Battle Staff
2528	Falchion
2529	Zweihander
2530	Francisca
2531	Great Axe
2532	Morning Star
2533	War Maul
2534	Rondel
2535	War Staff
2536	Trogg Stone Tooth
2545	Malleable Chain Leggings
2546	Royal Frostmane Girdle
2547	Boar Handler Gloves
2548	Barrel of Barleybrew Scalder
2549	Staff of the Shade
2553	Recipe: Elixir of Minor Agility
2555	Recipe: Swiftness Potion
2556	Recipe: Elixir of Tongues
2560	Jitters' Completed Journal
2561	Chok'sul's Head
2562	Bouquet of Scarlet Begonias
2563	Strange Smelling Powder
2564	Elven Spirit Claws
2565	Rod of Molten Fire
2566	Sacrificial Robes
2567	Evocator's Blade
2568	Brown Linen Vest
2569	Linen Boots
2570	Linen Cloak
2571	Viny Wrappings
2572	Red Linen Robe
2575	Red Linen Shirt
2576	White Linen Shirt
2577	Blue Linen Shirt
2578	Barbaric Linen Vest
2579	Green Linen Shirt
2580	Reinforced Linen Cape
2581	Heavy Linen Bandage
2582	Green Woolen Vest
2583	Woolen Boots
2584	Woolen Cape
2585	Gray Woolen Robe
2586	Gamemaster's Robe
2587	Gray Woolen Shirt
2589	Linen Cloth
2590	Forest Spider Webbing
2591	Dirty Trogg Cloth
2592	Wool Cloth
2593	Flask of Port
2594	Flagon of Mead
2595	Jug of Bourbon
2596	Skin of Dwarven Stout
2598	Pattern: Red Linen Robe
2601	Pattern: Gray Woolen Robe
2604	Red Dye
2605	Green Dye
2606	Lurker Venom
2607	Mo'grosh Crystal
2608	Threshadon Ambergris
2609	Disarming Colloid
2610	Disarming Mixture
2611	Crude Flint
2612	Plain Robe
2613	Double-stitched Robes
2614	Robe of Apprenticeship
2615	Chromatic Robe
2616	Shimmering Silk Robes
2617	Burning Robes
2618	Silver Dress Robes
2619	Grelin's Report
2620	Augural Shroud
2621	Cowl of Necromancy
2622	Nimar's Tribal Headdress
2623	Holy Diadem
2624	Thinking Cap
2625	Menethil Statuette
2628	Senir's Report
2629	Intrepid Strongbox Key
2632	Curved Dagger
2633	Jungle Remedy
2634	Venom Fern Extract
2635	Loose Chain Belt
2636	Carved Stone Idol
2637	Ironband's Progress Report
2639	Merrin's Letter
2640	Miners' Gear
2642	Loose Chain Boots
2643	Loose Chain Bracers
2644	Loose Chain Cloak
2645	Loose Chain Gloves
2646	Loose Chain Pants
2648	Loose Chain Vest
2649	Flimsy Chain Belt
2650	Flimsy Chain Boots
2651	Flimsy Chain Bracers
2652	Flimsy Chain Cloak
2653	Flimsy Chain Gloves
2654	Flimsy Chain Pants
2656	Flimsy Chain Vest
2657	Red Leather Bag
2658	Ados Fragment
2659	Modr Fragment
2660	Golm Fragment
2661	Neru Fragment
2662	Ribbly's Quiver
2663	Ribbly's Bandolier
2664	Spinner Fang
2665	Stormwind Seasoning Herbs
2666	Barrel of Thunder Ale
2667	MacGrann's Dried Meats
2668	Threshadon Tooth
2669	Threshadon Claw
2671	Wendigo Mane
2672	Stringy Wolf Meat
2673	Coyote Meat
2674	Crawler Meat
2675	Crawler Claw
2676	Shimmerweed
2677	Boar Ribs
2678	Mild Spices
2679	Charred Wolf Meat
2680	Spiced Wolf Meat
2681	Roasted Boar Meat
2682	Cooked Crab Claw
2683	Crab Cake
2684	Coyote Steak
2685	Succulent Pork Ribs
2686	Thunder Ale
2687	Dry Pork Ribs
2688	Squirrel Nut
2690	Latched Belt
2691	Outfitter Boots
2692	Hot Spices
2693	Stormwind Seasoning Salts
2694	Settler's Leggings
2696	Cask of Evershine
2697	Recipe: Goretusk Liver Pie
2698	Recipe: Cooked Crab Claw
2699	Recipe: Redridge Goulash
2700	Recipe: Succulent Pork Ribs
2701	Recipe: Seasoned Wolf Kabob
2702	Lightforge Ingot
2712	Crate of Lightforge Ingots
2713	Ol' Sooty's Head
2719	Small Brass Key
2720	Muddy Note
2721	Holy Shroud
2722	Wine Ticket
2723	Bottle of Pinot Noir
2724	Cloth Request
2725	Green Hills of Stranglethorn - Page 1
2728	Green Hills of Stranglethorn - Page 4
2730	Green Hills of Stranglethorn - Page 6
2732	Green Hills of Stranglethorn - Page 8
2734	Green Hills of Stranglethorn - Page 10
2735	Green Hills of Stranglethorn - Page 11
2738	Green Hills of Stranglethorn - Page 14
2740	Green Hills of Stranglethorn - Page 16
2742	Green Hills of Stranglethorn - Page 18
2744	Green Hills of Stranglethorn - Page 20
2745	Green Hills of Stranglethorn - Page 21
2748	Green Hills of Stranglethorn - Page 24
2749	Green Hills of Stranglethorn - Page 25
2750	Green Hills of Stranglethorn - Page 26
2751	Green Hills of Stranglethorn - Page 27
2754	Tarnished Bastard Sword
2755	Green Hills of Stranglethorn
2756	Green Hills of Stranglethorn - Chapter I
2757	Green Hills of Stranglethorn - Chapter II
2758	Green Hills of Stranglethorn - Chapter III
2759	Green Hills of Stranglethorn - Chapter IV
2760	Thurman's Sewing Kit
2763	Fisherman Knife
2764	Small Dagger
2765	Hunting Knife
2766	Deft Stiletto
2770	Copper Ore
2771	Tin Ore
2772	Iron Ore
2773	Cracked Shortbow
2774	Rust-covered Blunderbuss
2775	Silver Ore
2776	Gold Ore
2777	Feeble Shortbow
2778	Cheap Blunderbuss
2779	Tear of Tilloa
2780	Light Hunting Bow
2781	Dirty Blunderbuss
2782	Mishandled Recurve Bow
2783	Shoddy Blunderbuss
2784	Musquash Root
2785	Stiff Recurve Bow
2786	Oiled Blunderbuss
2787	Trogg Dagger
2788	Black Claw Stout
2795	Book: Stresses of Iron
2797	Heart of Mokk
2798	Rethban Ore
2799	Gorilla Fang
2800	Black Velvet Robes
2801	Blade of Hanna
2802	Blazing Emblem
2805	Yeti Fur Cloak
2806	Package for Stormpike
2807	Guillotine Axe
2808	Torch of Holy Flame
2815	Curve-bladed Ripper
2816	Death Speaker Scepter
2817	Soft Leather Tunic
2818	Stretched Leather Trousers
2819	Cross Dagger
2820	Nifty Stopwatch
2821	Mo'grosh Masher
2822	Mo'grosh Toothpick
2823	Mo'grosh Can Opener
2824	Hurricane
2825	Bow of Searing Arrows
2828	Nissa's Remains
2829	Gregor's Remains
2830	Thurman's Remains
2831	Devlin's Remains
2832	Verna's Westfall Stew Recipe
2833	The Lich's Spellbook
2834	Embalming Ichor
2835	Rough Stone
2836	Coarse Stone
2837	Thurman's Letter
2838	Heavy Stone
2839	A Letter to Yvette
2840	Copper Bar
2841	Bronze Bar
2842	Silver Bar
2843	Dirty Knucklebones
2844	Copper Mace
2845	Copper Axe
2846	Tirisfal Pumpkin
2847	Copper Shortsword
2848	Bronze Mace
2849	Bronze Axe
2850	Bronze Shortsword
2851	Copper Chain Belt
2852	Copper Chain Pants
2853	Copper Bracers
2854	Runed Copper Bracers
2855	Putrid Claw
2856	Iron Pike
2857	Runed Copper Belt
2858	Darkhound Blood
2859	Vile Fin Scale
2862	Rough Sharpening Stone
2863	Coarse Sharpening Stone
2864	Runed Copper Breastplate
2865	Rough Bronze Leggings
2866	Rough Bronze Cuirass
2867	Rough Bronze Bracers
2868	Patterned Bronze Bracers
2869	Silvered Bronze Breastplate
2870	Shining Silver Breastplate
2871	Heavy Sharpening Stone
2872	Vicious Night Web Spider Venom
2874	An Unsent Letter
2875	Scarlet Insignia Ring
2876	Duskbat Pelt
2877	Combatant Claymore
2878	Bearded Boneaxe
2879	Antipodean Rod
2880	Weak Flux
2881	Plans: Runed Copper Breastplate
2882	Plans: Silvered Bronze Shoulders
2883	Plans: Deadly Bronze Poniard
2885	Scarlet Crusade Documents
2886	Crag Boar Rib
2887	Ruined Wolf Pelt
2888	Beer Basted Boar Ribs
2889	Recipe: Beer Basted Boar Ribs
2890	Ruined Boar Pelt
2891	Letter to the City Architect
2892	Deadly Poison
2893	Deadly Poison II
2894	Rhapsody Malt
2895	Creeping Pain
2896	Creeping Anguish
2898	Mountaineer Chestpiece
2899	Wendigo Collar
2900	Stone Buckler
2901	Mining Pick
2902	Cloak of the Faith
2903	Daryl's Hunting Bow
2904	Daryl's Hunting Rifle
2905	Goat Fur Cloak
2906	Darkshire Mail Leggings
2907	Dwarven Tree Chopper
2908	Thornblade
2909	Red Wool Bandana
2910	Gold Militia Boots
2911	Keller's Girdle
2912	Claw of the Shadowmancer
2913	Silk Mantle of Gamn
2915	Taran Icebreaker
2916	Gold Lion Shield
2917	Tranquil Ring
2919	Relic of the Ancients
2920	Sacred Relic
2921	Blessed Relic
2922	Spirit Relic
2923	Relic of Righteousness
2924	Crocolisk Meat
2925	Crocolisk Skin
2926	Head of Bazil Thredd
2927	Creeping Torment
2928	Dust of Decay
2929	Tomb Rot
2930	Essence of Pain
2931	Maiden's Anguish
2932	Torment Vine
2933	Seal of Wrynn
2934	Ruined Leather Scraps
2939	Crocolisk Tear
2940	Bloody Bear Paw
2941	Prison Shank
2942	Iron Knuckles
2943	Eye of Paleth
2944	Cursed Eye of Paleth
2946	Balanced Throwing Dagger
2947	Small Throwing Knife
2949	Mariner Boots
2950	Icicle Rod
2951	Ring of the Underwood
2953	Watch Master's Cloak
2954	Night Watch Pantaloons
2955	First Mate Hat
2956	Report on the Defias Brotherhood
2957	Journeyman's Vest
2958	Journeyman's Pants
2959	Journeyman's Boots
2960	Journeyman's Gloves
2961	Burnt Leather Vest
2962	Burnt Leather Breeches
2963	Burnt Leather Boots
2964	Burnt Leather Gloves
2965	Warrior's Tunic
2966	Warrior's Pants
2967	Warrior's Boots
2968	Warrior's Gloves
2969	Spellbinder Vest
2970	Spellbinder Pants
2971	Spellbinder Boots
2972	Spellbinder Gloves
2973	Hunting Tunic
2974	Hunting Pants
2975	Hunting Boots
2976	Hunting Gloves
2977	Veteran Armor
2978	Veteran Leggings
2979	Veteran Boots
2980	Veteran Gloves
2981	Seer's Robe
2982	Seer's Pants
2983	Seer's Boots
2984	Seer's Gloves
2985	Inscribed Leather Breastplate
2986	Inscribed Leather Pants
2987	Inscribed Leather Boots
2988	Inscribed Leather Gloves
2989	Burnished Tunic
2990	Burnished Leggings
2991	Burnished Boots
2992	Burnished Gloves
2996	Bolt of Linen Cloth
2997	Bolt of Woolen Cloth
2998	A Simple Compass
2999	Steelgrill's Tools
3000	Brood Mother Carapace
3002	Relic Horn of Justice
3003	Relic of the Eye
3004	Relic of the Dead
3005	Relic of Truth
3006	Holy Relic Shard
3008	Wendigo Fur Cloak
3010	Fine Sand
3011	Feathered Headdress
3012	Scroll of Agility
3013	Scroll of Protection
3014	Battleworn Axe
3016	Gunther's Spellbook
3017	Sevren's Orders
3018	Hide of Lupos
3019	Noble's Robe
3020	Enduring Cap
3021	Ranger Bow
3022	Bluegill Breeches
3023	Large Bore Blunderbuss
3024	BKP 2700 "Enforcer"
3025	BKP 42 "Ultra"
3026	Reinforced Bow
3027	Heavy Recurve Bow
3028	Longbow
3029	Depricated Whipwood Arrow
3030	Razor Arrow
3031	Depricated Razor Arrow
3033	Solid Shot
3034	Glyphed Breastplate
3035	Laced Pumpkin
3036	Heavy Shortbow
3037	Whipwood Recurve Bow
3039	Short Ash Bow
3040	Hunter's Muzzle Loader
3041	"Mage-Eye" Blunderbuss
3042	BKP "Sparrow" Smallbore
3044	OLDMonster - Mace, Standard Basic Offhand
3045	Lambent Scale Boots
3047	Lambent Scale Gloves
3048	Lambent Scale Legguards
3049	Lambent Scale Breastplate
3053	Humbert's Chestpiece
3055	Forest Leather Chestpiece
3056	Forest Leather Pants
3057	Forest Leather Boots
3058	Forest Leather Gloves
3065	Bright Boots
3066	Bright Gloves
3067	Bright Pants
3069	Bright Robe
3070	Ensign Cloak
3071	Striking Hatchet
3072	Smoldering Robe
3073	Smoldering Pants
3074	Smoldering Gloves
3075	Eye of Flame
3076	Smoldering Boots
3078	Naga Heartpiercer
3079	Skorn's Rifle
3080	Candle of Beckoning
3081	Nether Gem
3082	Dargol's Skull
3083	Restabilization Cog
3084	Gyromechanic Gear
3085	Barrel of Shimmer Stout
3086	Cask of Shimmer Stout
3087	Mug of Shimmer Stout
3088	Book of Rejuvenation IV
3089	Tome of Flamestrike
3090	Tome of Frostbolt
3091	Tome of Arcane Intellect II
3092	Tome of Flamestrike III
3093	Tome of Flamestrike II
3094	Tome of Fire Blast II
3095	Tome of Fire Blast III
3096	Tome of Feather Fall
3097	Tome of Conjure Water II
3098	Tome of Slow
3099	Tome of Ice Armor II
3100	Tome of Blizzard II
3101	Tome of Frost Nova III
3102	Tome of Arcane Intellect III
3103	Coldridge Hammer
3107	Keen Throwing Knife
3108	Heavy Throwing Dagger
3110	Tunnel Rat Ear
3111	Crude Throwing Axe
3113	Codex of Holy Word: Shield
3114	Codex of Shadow Word: Befuddle
3115	Codex of Renew IV
3116	Codex of Holy Word: Shield II
3117	Hildelve's Journal
3118	Codex of Greater Heal
3119	Codex of Holy Word: Shield V
3120	Codex of Holy Smite IV
3121	Codex of Levitate
3122	Codex of Holy Word: Shield III
3123	Codex of Holy Word: Fortitude III
3124	Codex of Inner Fire III
3125	Tablet of Serpent Totem II
3126	Tablet of Shock II
3127	Tablet of Shock III
3129	Tablet of Lightning Bolt IV
3130	Tablet of Restoration IV
3131	Weighted Throwing Axe
3132	Tablet of Molten Blast IV
3133	Tablet of Mana Totem
3134	Grimoire of Curse of Mannoroth
3135	Sharp Throwing Axe
3137	Deadly Throwing Axe
3138	Grimoire of Shadow Bolt IV
3139	Grimoire of Demon Armor II
3140	Grimoire of Blood Boil II
3141	Grimoire of Life Drain
3142	Grimoire of Curse of Sargeras
3143	Grimoire of Burning Spirit
3144	Grimoire of Burning Spirit II
3146	Grimoire of Burning Spirit III
3148	Work Shirt
3151	Siege Brigade Vest
3152	Driving Gloves
3153	Oil-stained Cloak
3154	Thelsamar Axe
3155	Remedy of Arugal
3156	Glutton Shackle
3157	Darksoul Shackle
3158	Burnt Hide Bracers
3160	Ironplate Buckler
3161	Robe of the Keeper
3162	Notched Rib
3163	Blackened Skull
3164	Discolored Worg Heart
3165	Quinn's Potion
3166	Ironheart Chain
3167	Thick Spider Hair
3168	Chipped Scale
3169	Chipped Bear Tooth
3170	Large Bear Tooth
3171	Broken Boar Tusk
3172	Boar Intestines
3173	Bear Meat
3174	Spider Ichor
3175	Ruined Dragonhide
3176	Small Claw
3177	Tiny Fang
3179	Cracked Dragon Molting
3180	Flecked Raptor Scale
3181	Partially Digested Meat
3182	Spider's Silk
3183	Mangy Claw
3184	Hook Dagger
3185	Acrobatic Staff
3186	Viking Sword
3187	Sacrificial Kris
3188	Coral Claymore
3189	Wood Chopper
3190	Beatstick
3191	Arced War Axe
3192	Short Bastard Sword
3193	Oak Mallet
3194	Black Malice
3195	Barbaric Battle Axe
3196	Edged Bastard Sword
3197	Stonecutter Claymore
3198	Battering Hammer
3199	Battle Slayer
3200	Burnt Leather Bracers
3201	Barbarian War Axe
3202	Forest Leather Bracers
3203	Dense Triangle Mace
3204	Deepwood Bracers
3205	Inscribed Leather Bracers
3206	Cavalier Two-hander
3207	Hunting Bracers
3208	Conk Hammer
3209	Ancient War Sword
3210	Brutal War Axe
3211	Burnished Bracers
3212	Lambent Scale Bracers
3213	Veteran Bracers
3214	Warrior's Bracers
3216	Warm Winter Robe
3217	Foreman Belt
3218	Pyrewood Shackle
3220	Blood Sausage
3222	Wicked Dagger
3223	Frostmane Scepter
3224	Silver-lined Bracers
3225	Bloodstained Knife
3227	Nightbane Staff
3228	Jimmied Handcuffs
3229	Tarantula Silk Sash
3230	Black Wolf Bracers
3231	Cutthroat Pauldrons
3233	Gnoll Hide Sack
3234	Deliah's Ring
3235	Ring of Scorn
3236	Rot Hide Ichor
3237	Sample Ichor
3238	Johaan's Findings
3239	Rough Weightstone
3240	Coarse Weightstone
3241	Heavy Weightstone
3248	Translated Letter from The Embalmer
3250	Bethor's Scroll
3251	Bethor's Potion
3252	Deathstalker Report
3253	Grizzled Bear Heart
3254	Skittering Blood
3255	Berard's Journal
3256	Lake Skulker Moss
3257	Lake Creeper Moss
3258	Hardened Tumor
3259	Ruined Bat Hide
3260	Scarlet Initiate Robes
3261	Webbed Cloak
3262	Putrid Wooden Hammer
3263	Webbed Pants
3264	Duskbat Wing
3265	Scavenger Paw
3266	Scarlet Armband
3267	Forsaken Shortsword
3268	Forsaken Dagger
3269	Forsaken Maul
3270	Flax Vest
3272	Zombie Skin Leggings
3273	Rugged Mail Vest
3274	Flax Boots
3275	Flax Gloves
3276	Deathguard Buckler
3277	Executor Staff
3278	Aura Proc Damage Sword
3279	Battle Chain Boots
3280	Battle Chain Bracers
3281	Battle Chain Gloves
3282	Battle Chain Pants
3283	Battle Chain Tunic
3284	Tribal Boots
3285	Tribal Bracers
3286	Tribal Gloves
3287	Tribal Pants
3288	Tribal Vest
3289	Ancestral Boots
3290	Ancestral Gloves
3291	Ancestral Woollies
3292	Ancestral Tunic
3293	Deadman Cleaver
3294	Deadman Club
3295	Deadman Blade
3296	Deadman Dagger
3297	Fel Moss
3299	Fractured Canine
3300	Rabbit's Foot
3301	Sharp Canine
3302	Brackwater Boots
3303	Brackwater Bracers
3304	Brackwater Gauntlets
3305	Brackwater Leggings
3306	Brackwater Vest
3307	Barbaric Cloth Boots
3308	Barbaric Cloth Gloves
3309	Barbaric Loincloth
3310	Barbaric Cloth Vest
3311	Ceremonial Leather Ankleguards
3312	Ceremonial Leather Bracers
3313	Ceremonial Leather Harness
3314	Ceremonial Leather Gloves
3315	Ceremonial Leather Loincloth
3316	Alaric's Head
3317	A Talking Head
3318	Alaric's Remains
3319	Short Sabre
3320	Bonecaster Sash
3321	Gray Fur Booties
3322	Wispy Cloak
3323	Ghostly Bracers
3324	Ghostly Mantle
3325	Vile Fin Battle Axe
3327	Vile Fin Oracle Staff
3328	Spider Web Robe
3329	Spiked Wooden Plank
3330	Dargol's Hauberk
3331	Melrache's Cape
3332	Perrine's Boots
3334	Farmer's Shovel
3335	Farmer's Broom
3336	Flesh Piercer
3337	Dragonmaw War Banner
3339	Dwarven Tinder
3340	Incendicite Ore
3341	Gauntlets of Ogre Strength
3342	Captain Sander's Shirt
3343	Captain Sander's Booty Bag
3344	Captain Sander's Sash
3345	Silk Wizard Hat
3347	Bundle of Crocolisk Skins
3348	Giant Crocolisk Skin
3349	Sida's Bag
3352	Ooze-covered Bag
3353	Rune-inscribed Pendant
3354	Dalaran Pendant
3355	Wild Steelbloom
3356	Kingsblood
3357	Liferoot
3358	Khadgar's Whisker
3360	Stitches' Femur
3363	Frayed Belt
3365	Frayed Bracers
3369	Grave Moss
3370	Patchwork Belt
3371	Empty Vial
3372	Leaded Vial
3373	Patchwork Bracers
3374	Calico Belt
3375	Calico Bracers
3376	Canvas Belt
3377	Canvas Bracers
3378	Brocade Belt
3379	Brocade Bracers
3380	Cross-stitched Belt
3381	Cross-stitched Bracers
3382	Weak Troll's Blood Potion
3383	Elixir of Wisdom
3384	Minor Magic Resistance Potion
3385	Lesser Mana Potion
3386	Elixir of Poison Resistance
3387	Limited Invulnerability Potion
3388	Strong Troll's Blood Potion
3389	Elixir of Defense
3390	Elixir of Lesser Agility
3391	Elixir of Ogre's Strength
3392	Ringed Helm
3393	Recipe: Minor Magic Resistance Potion
3394	Recipe: Elixir of Poison Resistance
3395	Recipe: Limited Invulnerability Potion
3396	Recipe: Elixir of Lesser Agility
3397	Young Crocolisk Skin
3399	Vulture Talon
3400	Lucine Longsword
3401	Rough Crocolisk Scale
3402	Soft Patch of Fur
3403	Ivory Boar Tusk
3404	Buzzard Wing
3405	Raven Claw Talisman
3406	Black Feather Quill
3407	Sapphire of Sky
3408	Rune of Nesting
3409	Nightsaber Fang
3411	Strigid Owl Feather
3412	Webwood Spider Silk
3413	Doomspike
3414	Crested Scepter
3415	Staff of the Friar
3416	Martyr's Chain
3417	Onyx Claymore
3418	Fel Cone
3419	Red Rose
3420	Black Rose
3421	Simple Wildflowers
3422	Beautiful Wildflowers
3423	Bouquet of White Roses
3424	Bouquet of Black Roses
3425	Woven Wand
3426	Bold Yellow Shirt
3427	Stylish Black Shirt
3428	Common Gray Shirt
3429	Guardsman Belt
3430	Sniper Rifle
3431	Bone-studded Leather
3434	Slumber Sand
3435	Zombie Skin Bracers
3437	Clasped Belt
3438	Ankh of Resurrection
3439	Zombie Skin Boots
3440	Bonecracker
3442	Apprentice Sash
3443	Ceremonial Tomahawk
3444	Tiller's Vest
3445	Ceremonial Knife
3446	Darkwood Staff
3447	Cryptwalker Boots
3448	Senggin Root
3449	Mystic Shawl
3450	Faerleia's Shield
3451	Nightglow Concoction
3452	Ceranium Rod
3453	Quilted Bracers
3454	Reconnaissance Boots
3455	Deathstalker Shortsword
3456	Dog Whistle
3457	Stamped Trousers
3458	Rugged Mail Gloves
3460	Johaan's Special Drink
3461	High Robe of the Adjudicator
3462	Talonstrike
3463	Silver Star
3464	Feathered Arrow
3465	Exploding Shot
3466	Strong Flux
3467	Dull Iron Key
3468	Renferrel's Findings
3469	Copper Chain Boots
3470	Rough Grinding Stone
3471	Copper Chain Vest
3472	Runed Copper Gauntlets
3473	Runed Copper Pants
3474	Gemmed Copper Gauntlets
3475	Cloak of Flames
3476	Gray Bear Tongue
3477	Creeper Ichor
3478	Coarse Grinding Stone
3480	Rough Bronze Shoulders
3481	Silvered Bronze Shoulders
3482	Silvered Bronze Boots
3483	Silvered Bronze Gauntlets
3484	Green Iron Boots
3485	Green Iron Gauntlets
3486	Heavy Grinding Stone
3487	Heavy Copper Broadsword
3488	Copper Battle Axe
3489	Thick War Axe
3490	Deadly Bronze Poniard
3491	Heavy Bronze Mace
3492	Mighty Iron Hammer
3493	Raptor's End
3495	Elixir of Suffering
3496	Mountain Lion Blood
3497	Elixir of Pain
3498	Taretha's Necklace
3499	Burnished Gold Key
3502	Mudsnout Blossoms
3505	Alterac Signet Ring
3506	Mudsnout Composite
3508	Mudsnout Mixture
3509	Daggerspine Scale
3510	Torn Fin Eye
3511	Cloak of the People's Militia
3514	Mor'Ladim's Skull
3515	Ataeric's Staff
3516	Lescovar's Head
3517	Keg of Shindigger Stout
3518	Decrypted Letter
3520	Tainted Keg
3521	Cleverly Encrypted Letter
3522	Black Night Elf Breastplate
3526	Black Night Elf Gloves
3527	White Night Elf Breastplate
3528	Red Leather C03 Breastplate
3529	Black Night Elf Helm
3530	Wool Bandage
3531	Heavy Wool Bandage
3533	Red Leather C03 Boots
3535	Red Leather C03 Bracers
3536	Demon Hunter Blindfold
3537	Black Leather D02 Breastplate
3538	Gray Leather D02 Breastplate
3541	Black Leather D02 Boots
3542	Gray Leather D02 Boots
3545	Black Leather D02 Bracers
3546	Gray Leather D02 Bracers
3547	White Leather D03 Breastplate
3550	Targ's Head
3551	Muckrake's Head
3552	Glommus's Head
3553	Mug'thol's Head
3554	Crown of Will
3555	Robe of Solomon
3556	Dread Mage Hat
3558	Fen Keeper Robe
3559	Night Watch Gauntlets
3560	Mantle of Honor
3561	Resilient Poncho
3562	Belt of Vindication
3563	Seafarer's Pantaloons
3564	Shipment of Iron
3565	Beerstained Gloves
3566	Raptorbane Armor
3567	Dwarven Fishing Pole
3569	Vicar's Robe
3570	Bonegrinding Pestle
3571	Trogg Beater
3572	Daryl's Shortsword
3573	Hunting Quiver
3574	Hunting Ammo Sack
3575	Iron Bar
3576	Tin Bar
3577	Gold Bar
3578	Harvester's Pants
3581	Serrated Knife
3582	Acidproof Cloak
3583	Weathered Belt
3585	Camouflaged Tunic
3586	Logsplitter
3587	Embroidered Belt
3588	Embroidered Bracers
3589	Heavy Weave Belt
3590	Heavy Weave Bracers
3591	Padded Belt
3592	Padded Bracers
3593	Russet Belt
3594	Russet Bracers
3595	Tattered Cloth Belt
3596	Tattered Cloth Bracers
3597	Thick Cloth Belt
3598	Thick Cloth Bracers
3599	Thin Cloth Belt
3600	Thin Cloth Bracers
3601	Syndicate Missive
3602	Knitted Belt
3603	Knitted Bracers
3604	Bandolier of the Night Watch
3605	Quiver of the Night Watch
3606	Woven Belt
3607	Woven Bracers
3608	Plans: Mighty Iron Hammer
3609	Plans: Copper Chain Vest
3610	Plans: Gemmed Copper Gauntlets
3611	Plans: Green Iron Boots
3612	Plans: Green Iron Gauntlets
3613	Valdred's Hands
3614	Yowler's Paw
3615	Kurzen's Head
3616	Mind's Eye
3617	Pendant of Shadow
3618	Gobbler's Head
3619	Snellig's Snuffbox
3620	Lillith's Remains
3621	Ivar's Head
3622	Essence of Nightlash
3623	Thule's Head
3625	Nek'rosh's Head
3626	Head of Baron Vardus
3627	Fang of Vagash
3628	Hand of Dextren Ward
3629	Mistmantle Family Ring
3630	Head of Targorr
3631	Bellygrub's Tusk
3632	Fangore's Paw
3633	Head of Gath'Ilzogg
3634	Head of Grimson
3635	Maggot Eye's Paw
3637	Head of VanCleef
3638	Sarltooth's Talon
3639	Ear of Balgaras
3640	Head of Deepfury
3641	Journeyman's Bracers
3642	Ancestral Bracers
3643	Spellbinder Bracers
3644	Barbaric Cloth Bracers
3645	Seer's Cuffs
3647	Bright Bracers
3648	Warrior's Buckler
3649	Tribal Buckler
3650	Battle Shield
3651	Veteran Shield
3652	Hunting Buckler
3653	Ceremonial Buckler
3654	Brackwater Shield
3655	Burnished Shield
3656	Lambent Scale Shield
3657	Hillsbrad Town Registry
3658	Recovered Tome
3659	Worn Leather Book
3660	Tomes of Alterac
3661	Handcrafted Staff
3662	Crocolisk Steak
3663	Murloc Fin Soup
3664	Crocolisk Gumbo
3665	Curiously Tasty Omelet
3666	Gooey Spider Cake
3667	Tender Crocolisk Meat
3668	Assassin's Contract
3669	Gelatinous Goo
3670	Large Slimy Bone
3671	Lifeless Skull
3672	Head of Nagaz
3673	Broken Arrow
3674	Decomposed Boot
3675	Extinguished Torch
3676	Slimy Ichor
3678	Recipe: Crocolisk Steak
3679	Recipe: Blood Sausage
3680	Recipe: Murloc Fin Soup
3681	Recipe: Crocolisk Gumbo
3682	Recipe: Curiously Tasty Omelet
3683	Recipe: Gooey Spider Cake
3684	Perenolde Tiara
3685	Raptor Egg
3688	Bloodstone Oval
3689	Bloodstone Marble
3690	Bloodstone Shard
3691	Bloodstone Wedge
3692	Hillsbrad Human Skull
3693	Humbert's Sword
3701	Darthalia's Sealed Commendation
3702	Bear Gall Bladder
3703	Southshore Stout
3704	Rusted Iron Key
3706	Ensorcelled Parchment
3707	Nagaz Parchment
3708	Helcular's Rod
3710	Rod of Helcular
3711	Belamoore's Research Journal
3712	Turtle Meat
3713	Soothing Spices
3714	Worn Stone Token
3715	Bracers of Earth Binding
3716	Murloc Head
3717	Sack of Murloc Heads
3718	Foreboding Plans
3719	Hillman's Cloak
3720	Yeti Fur
3721	Farren's Report
3722	Familiar Hide
3723	Familiar Fang
3724	Familiar Claw
3725	Familiar Horn
3726	Big Bear Steak
3727	Hot Lion Chops
3728	Tasty Lion Steak
3729	Soothing Turtle Bisque
3730	Big Bear Meat
3731	Lion Meat
3732	Hooded Cowl
3733	Orcish War Chain
3734	Recipe: Big Bear Steak
3735	Recipe: Hot Lion Chops
3736	Recipe: Tasty Lion Steak
3737	Recipe: Soothing Turtle Bisque
3738	Brewing Rod
3739	Skull Ring
3740	Decapitating Sword
3741	Stomping Boots
3742	Bow of Plunder
3743	Sentry Buckler
3744	Bloodstone Pendant
3745	Rune of Opening
3747	Meditative Sash
3748	Feline Mantle
3749	High Apothecary Cloak
3750	Ribbed Breastplate
3751	Mercenary Leggings
3752	Grunt Vest
3753	Shepherd's Girdle
3754	Shepherd's Gloves
3755	Fish Gutter
3758	Crusader Belt
3759	Insulated Sage Gloves
3760	Band of the Undercity
3761	Deadskull Shield
3762	Librarian's Satchel
3763	Lunar Buckler
3764	Mantis Boots
3765	Brigand's Pauldrons
3766	Gryphon Feather Quill
3767	Fine Parchment
3769	Broken Wand
3770	Mutton Chop
3771	Wild Hog Shank
3772	Conjured Spring Water
3775	Crippling Poison
3776	Crippling Poison II
3777	Lethargy Root
3778	Taut Compound Bow
3779	Hefty War Axe
3780	Long-barreled Musket
3781	Broad Claymore
3782	Large War Club
3783	Light Scimitar
3784	Metal Stave
3785	Keen Axe
3786	Shiny Dirk
3787	Stone Club
3788	Soul Crystal Relic
3789	Relic Stone of Piety
3790	Consecrated Relic Parchment
3791	Relic of the Light
3792	Interlaced Belt
3793	Interlaced Boots
3794	Interlaced Bracers
3795	Interlaced Cloak
3796	Interlaced Gloves
3797	Interlaced Pants
3798	Interlaced Shoulderpads
3799	Interlaced Vest
3800	Hardened Leather Belt
3801	Hardened Leather Boots
3802	Hardened Leather Bracers
3803	Hardened Cloak
3804	Hardened Leather Gloves
3805	Hardened Leather Pants
3806	Hardened Leather Shoulderpads
3807	Hardened Leather Tunic
3808	Double Mail Belt
3809	Double Mail Boots
3810	Double Mail Bracers
3811	Double-stitched Cloak
3812	Double Mail Gloves
3813	Double Mail Pants
3814	Double Mail Shoulderpads
3815	Double Mail Vest
3816	Reflective Heater
3817	Reinforced Buckler
3818	Fadeleaf
3819	Wintersbite
3820	Stranglekelp
3821	Goldthorn
3822	Runic Darkblade
3823	Lesser Invisibility Potion
3824	Shadow Oil
3825	Elixir of Fortitude
3826	Mighty Troll's Blood Potion
3827	Mana Potion
3828	Elixir of Detect Lesser Invisibility
3829	Frost Oil
3830	Recipe: Elixir of Fortitude
3831	Recipe: Mighty Troll's Blood Potion
3832	Recipe: Elixir of Detect Lesser Invisibility
3833	Adept's Cloak
3834	Sturdy Cloth Trousers
3835	Green Iron Bracers
3836	Green Iron Helm
3837	Golden Scale Coif
3838	Shadowmaw Claw
3839	Pristine Tigress Fang
3840	Green Iron Shoulders
3841	Golden Scale Shoulders
3842	Green Iron Leggings
3843	Golden Scale Leggings
3844	Green Iron Hauberk
3845	Golden Scale Cuirass
3846	Polished Steel Boots
3847	Golden Scale Boots
3848	Big Bronze Knife
3849	Hardened Iron Shortsword
3850	Jade Serpentblade
3851	Solid Iron Maul
3852	Golden Iron Destroyer
3853	Moonsteel Broadsword
3854	Frost Tiger Blade
3855	Massive Iron Axe
3856	Shadow Crescent Axe
3857	Coal
3858	Mithril Ore
3859	Steel Bar
3860	Mithril Bar
3861	Blacksteel Bar
3862	Aged Gorilla Sinew
3863	Jungle Stalker Feather
3864	Citrine
3866	Plans: Jade Serpentblade
3867	Plans: Golden Iron Destroyer
3868	Plans: Frost Tiger Blade
3869	Plans: Shadow Crescent Axe
3870	Plans: Green Iron Shoulders
3871	Plans: Golden Scale Shoulders
3872	Plans: Golden Scale Leggings
3873	Plans: Golden Scale Cuirass
3874	Plans: Polished Steel Boots
3875	Plans: Golden Scale Boots
3876	Fang of Bhag'thera
3877	Talon of Tethis
3879	Paw of Sin'Dall
3880	Head of Bangalash
3882	Buzzard Feather
3889	Russet Hat
3890	Studded Hat
3891	Augmented Chain Helm
3892	Embroidered Hat
3893	Reinforced Leather Cap
3894	Brigandine Helm
3897	Dizzy's Eye
3898	Library Scrip
3899	Legends of the Gurubashi, Volume 3
3900	Pupellyverbos Port
3901	Bloodscalp Tusk
3902	Staff of Nobles
3904	Gan'zulah's Head
3905	Nezzliok's Head
3906	Balia'mah Trophy
3907	Ziata'jai Trophy
3908	Zul'Mamwe Trophy
3909	Broken Armor of Ana'thek
3910	Snuff
3911	Pulsing Blue Shard
3912	Soul Gem
3913	Filled Soul Gem
3914	Journeyman's Backpack
3915	Bloody Bone Necklace
3916	Split Bone Necklace
3917	Singing Blue Crystal
3918	Singing Crystal Shard
3919	Mistvale Giblets
3920	Bloodsail Charts
3921	Bloodsail Orders
3922	Shaky's Payment
3923	Water Elemental Bracers
3924	Maury's Clubbed Foot
3925	Jon-Jon's Golden Spyglass
3926	Chucky's Huge Ring
3927	Fine Aged Cheddar
3928	Superior Healing Potion
3929	Maury's Loot
3930	Maury's Key
3931	Poisoned Spider Fang
3932	Smotts' Chest
3935	Smotts' Cutlass
3936	Crochet Belt
3937	Crochet Boots
3938	Crochet Bracers
3939	Crochet Cloak
3940	Crochet Gloves
3941	Crochet Pants
3942	Crochet Shoulderpads
3943	Crochet Vest
3944	Twill Belt
3945	Twill Boots
3946	Twill Bracers
3947	Twill Cloak
3948	Twill Gloves
3949	Twill Pants
3950	Twill Shoulderpads
3951	Twill Vest
3952	Mesh Belt
3953	Mesh Boots
3954	Mesh Bracers
3955	Mesh Cloak
3956	Mesh Gloves
3957	Mesh Pants
3958	Mesh Mantle
3959	Mesh Armor
3960	Bag of Water Elemental Bracers
3961	Thick Leather Belt
3962	Thick Leather Boots
3963	Thick Leather Bracers
3964	Thick Cloak
3965	Thick Leather Gloves
3966	Thick Leather Pants
3967	Thick Leather Shoulderpads
3968	Thick Leather Tunic
3969	Smooth Leather Belt
3970	Smooth Leather Boots
3971	Smooth Leather Bracers
3972	Smooth Cloak
3973	Smooth Leather Gloves
3974	Smooth Leather Pants
3975	Smooth Leather Shoulderpads
3976	Smooth Leather Armor
3977	Strapped Belt
3978	Strapped Boots
3979	Strapped Bracers
3980	Strapped Cloak
3981	Strapped Gloves
3982	Strapped Pants
3983	Strapped Shoulderpads
3984	Strapped Armor
3985	Monogrammed Sash
3986	Protective Pavise
3987	Deflecting Tower
3988	Plate Wall Shield
3989	Blocking Targe
3990	Crested Buckler
3991	Plated Buckler
3992	Laminated Scale Belt
3993	Laminated Scale Boots
3994	Laminated Scale Bracers
3995	Laminated Scale Cloak
3996	Laminated Scale Gloves
3997	Laminated Scale Pants
3998	Laminated Scale Shoulderpads
3999	Laminated Scale Armor
4000	Overlinked Chain Belt
4001	Overlinked Chain Boots
4002	Overlinked Chain Bracers
4003	Overlinked Chain Cloak
4004	Overlinked Chain Gloves
4005	Overlinked Chain Pants
4006	Overlinked Chain Shoulderpads
4007	Overlinked Chain Armor
4008	Sterling Chain Belt
4009	Sterling Chain Boots
4010	Sterling Chain Bracers
4011	Sterling Chain Cloak
4012	Sterling Chain Gloves
4013	Sterling Chain Pants
4014	Sterling Chain Shoulderpads
4015	Sterling Chain Armor
4016	Zanzil's Mixture
4017	Sharp Shortsword
4018	Whetted Claymore
4019	Heavy Flint Axe
4020	Splintering Battle Axe
4021	Blunting Mace
4022	Crushing Maul
4023	Fine Pointed Dagger
4024	Heavy War Staff
4025	Balanced Long Bow
4026	Sentinel Musket
4027	Catelyn's Blade
4028	Bundle of Akiris Reeds
4029	Akiris Reed
4030	Holy Relic Water
4031	Hallowed Relic Charm
4032	Radiant Relic Hammer
4033	Dawn's Glow
4034	Stone of the Tides
4035	Silver-thread Robe
4036	Silver-thread Cuffs
4037	Silver-thread Pants
4038	Nightsky Robe
4039	Nightsky Cowl
4040	Nightsky Gloves
4041	Aurora Cowl
4042	Aurora Gloves
4043	Aurora Bracers
4044	Aurora Pants
4045	Mistscape Bracers
4046	Mistscape Pants
4047	Mistscape Boots
4048	Emblazoned Hat
4049	Emblazoned Bracers
4050	Emblazoned Leggings
4051	Emblazoned Boots
4052	Insignia Cap
4053	Large River Crocolisk Skin
4054	Insignia Leggings
4055	Insignia Boots
4056	Cortello's Riddle
4057	Insignia Chestguard
4058	Glyphed Breastplate
4059	Glyphed Bracers
4060	Glyphed Leggings
4061	Imperial Leather Bracers
4062	Imperial Leather Pants
4063	Imperial Leather Gloves
4064	Emblazoned Buckler
4065	Combat Shield
4066	Insignia Buckler
4067	Glyphed Buckler
4068	Chief Brigadier Shield
4069	Blackforge Buckler
4070	Jouster's Crest
4071	Glimmering Mail Breastplate
4072	Glimmering Mail Gauntlets
4073	Glimmering Mail Greaves
4074	Mail Combat Armor
4075	Mail Combat Gauntlets
4076	Mail Combat Boots
4077	Mail Combat Headguard
4078	Chief Brigadier Coif
4079	Chief Brigadier Leggings
4080	Blackforge Cowl
4082	Blackforge Breastplate
4083	Blackforge Gauntlets
4084	Blackforge Leggings
4085	Krazek's Crock Pot
4086	Flash Rifle
4087	Trueshot Bow
4088	Dreadblade
4089	Ricochet Blunderbuss
4090	Mug O' Hurt
4091	Widowmaker
4092	Prismatic Basilisk Scale
4093	Large Basilisk Tail
4094	Tablet Shard
4095	Deprecate Snare Kit
4096	Coarse Gorilla Hair
4097	Chipped Gorilla Tooth
4098	Carefully Folded Note
4099	Tuft of Gorilla Hair
4100	Crumpled Note
4101	Ripped Note
4102	Torn Note
4103	Shackle Key
4104	Snapjaw Crocolisk Skin
4105	Elder Crocolisk Skin
4106	Tumbled Crystal
4107	Tiger Hunter Gloves
4108	Panther Hunter Leggings
4109	Excelsior Boots
4110	Master Hunter's Bow
4111	Master Hunter's Rifle
4112	Choker of the High Shaman
4113	Medicine Blanket
4114	Darktide Cape
4115	Grom'gol Buckler
4116	Olmann Sewar
4117	Scorching Sash
4118	Poobah's Nose Ring
4119	Raptor Hunter Tunic
4120	Robe of Crystal Waters
4121	Gemmed Gloves
4122	Bookmaker's Scepter
4123	Frost Metal Pauldrons
4124	Cap of Harmony
4125	Tranquil Orb
4126	Guerrilla Cleaver
4127	Shrapnel Blaster
4128	Silver Spade
4129	Collection Plate
4130	Smotts' Compass
4131	Belt of Corruption
4132	Darkspear Armsplints
4133	Darkspear Cuffs
4134	Nimboya's Mystical Staff
4135	Bloodbone Band
4136	Darkspear Boots
4137	Darkspear Shoes
4138	Blackwater Tunic
4139	Junglewalker Sandals
4140	Palm Frond Mantle
4141	Tome of Conjure Food
4143	Tome of Conjure Food II
4145	Tome of Conjure Mana Gem
4146	Tome of Polymorph: Sheep
4147	Tome of Conjure Food III
4148	Tome of Counterspell
4149	Tome of Frost Shield III
4150	Tome of Conjure Water IV
4151	Tome of Frostbolt IV
4152	Tome of Conjure Food IV
4153	Tome of Arcane Missiles III
4154	Tome of Slow II
4155	Tome of Water Elemental II
4157	Tome of Dampen Magic
4158	Tome of Khadgar's Unlocking III
4159	Tome of Arcane Missiles
4161	Tome of Fireball IV
4162	Tome of Blink II
4164	Libram: Holy Light V
4165	Libram: Holy Light VI
4166	Libram: Seal of Protection
4167	Libram: Judgement
4168	Tablet of Ensnaring Totem
4169	Tablet of Unyielding Will II
4170	Tablet of Astral Recall
4171	Tablet of Agitating Totem III
4172	Tablet of Thunderclap II
4173	Tablet of Shock IV
4174	Tablet of Shock V
4175	Tablet of Lightning Shield IV
4176	Tablet of Undying Strength II
4177	Tablet of Nature Resistance
4178	Tablet of Lightning Bolt V
4179	Tablet of Restoration V
4180	Tablet of Ethereal Form II
4181	Tablet of Agitating Totem IV
4182	Tablet of Unyielding Will III
4183	Tablet of Healing Totem V
4184	Tablet of Molten Blast V
4185	Tablet of Group Astral Recall
4186	Tablet of Fire Resistance
4187	Tablet of Serpent Totem V
4188	Tablet of Invisibility Totem
4189	Tablet of Chain Lightning
4190	Feathered Armor
4191	Feathered Leggings
4194	Feathered Bracers
4195	Feathered Boots
4196	Feathered Mantle
4197	Berylline Pads
4198	Grimoire of Soul Funnel
4199	Grimoire of Soul Funnel II
4200	Grimoire of Immolate III
4201	Grimoire of Eye of Kilrogg
4202	Grimoire of Fear II
4203	Grimoire of Pestilence II
4204	Grimoire of Soul Funnel III
4205	Grimoire of Immolate IV
4206	Grimoire of Curse of Sargeras II
4207	Grimoire of Curse of Archimonde
4208	Grimoire of Mind Bomb
4209	Grimoire of Shadow Ward
4210	Grimoire of Create Lesser Bloodstone
4211	Grimoire of Pestilence
4212	Grimoire of Curse of Mannoroth III
4213	Grimoire of Doom
4214	Grimoire of Life Drain III
4215	Grimoire of Rain of Fire
4216	Grimoire of Holy Ward
4217	Grimoire of Soul Funnel IV
4218	Grimoire of Create Bloodstone
4219	Grimoire of Burning Spirit IV
4220	Grimoire of Blood Boil III
4221	Grimoire of Detect Invisibility
4223	Book of Abolish Magic
4225	Book of Entangling Roots III
4226	Book of Wrath VI
4228	Book of Moonfire IV
4230	Book of Healing Touch VI
4231	Cured Light Hide
4232	Medium Hide
4233	Cured Medium Hide
4234	Heavy Leather
4235	Heavy Hide
4236	Cured Heavy Hide
4237	Handstitched Leather Belt
4238	Linen Bag
4239	Embossed Leather Gloves
4240	Woolen Bag
4241	Green Woolen Bag
4242	Embossed Leather Pants
4243	Fine Leather Tunic
4244	Hillman's Leather Vest
4245	Small Silk Pack
4246	Fine Leather Belt
4247	Hillman's Leather Gloves
4248	Dark Leather Gloves
4249	Dark Leather Belt
4250	Hillman's Belt
4251	Hillman's Shoulders
4252	Dark Leather Shoulders
4253	Toughened Leather Gloves
4254	Barbaric Gloves
4255	Green Leather Armor
4256	Guardian Armor
4257	Green Leather Belt
4258	Guardian Belt
4259	Green Leather Bracers
4260	Guardian Leather Bracers
4261	Solliden's Trousers
4262	Gem-studded Leather Belt
4263	Standard Issue Shield
4264	Barbaric Belt
4265	Heavy Armor Kit
4266	Codex of Inner Fire II
4267	Codex of Shadow Word: Fumble
4268	Codex of Heal II
4269	Codex of Prayer of Healing
4270	Codex of Heal III
4271	Codex of Holy Smite V
4272	Codex of Holy Protection
4273	Codex of Heal
4274	Codex of Divine Escape
4275	Codex of Mind Rot
4276	Codex of Shadow Word: Fumble II
4277	Codex of Shadow Word: Befuddle II
4278	Lesser Bloodstone Ore
4279	Codex of Shadow Word: Pain V
4280	Codex of Holy Word: Shield IV
4281	Codex of Shadow Protection
4282	Codex of Dispel Magic II
4283	Codex of Sleep III
4284	Codex of Holy Smite VI
4285	Codex of Holy Word: Fortitude IV
4286	Codex of Prayer of Healing II
4287	Codex of Nullify Disease II
4288	Codex of Remove Curse II
4289	Salt
4290	Dust Bowl
4291	Silken Thread
4292	Pattern: Green Woolen Bag
4293	Pattern: Hillman's Leather Vest
4294	Pattern: Hillman's Belt
4296	Pattern: Dark Leather Shoulders
4297	Pattern: Barbaric Gloves
4298	Pattern: Guardian Belt
4299	Pattern: Guardian Armor
4300	Pattern: Guardian Leather Bracers
4301	Pattern: Barbaric Belt
4302	Small Green Dagger
4303	Cranial Thumper
4304	Thick Leather
4305	Bolt of Silk Cloth
4306	Silk Cloth
4307	Heavy Linen Gloves
4308	Green Linen Bracers
4309	Handstitched Linen Britches
4310	Heavy Woolen Gloves
4311	Heavy Woolen Cloak
4312	Soft-soled Linen Boots
4313	Red Woolen Boots
4314	Double-stitched Woolen Shoulders
4315	Reinforced Woolen Shoulders
4316	Heavy Woolen Pants
4317	Phoenix Pants
4318	Gloves of Meditation
4319	Azure Silk Gloves
4320	Spidersilk Boots
4321	Spider Silk Slippers
4322	Enchanter's Cowl
4323	Shadow Hood
4324	Azure Silk Vest
4325	Boots of the Enchanter
4326	Long Silken Cloak
4327	Icy Cloak
4328	Spider Belt
4329	Star Belt
4330	Stylish Red Shirt
4331	Phoenix Gloves
4332	Bright Yellow Shirt
4333	Dark Silk Shirt
4334	Formal White Shirt
4335	Rich Purple Silk Shirt
4336	Black Swashbuckler's Shirt
4337	Thick Spider's Silk
4338	Mageweave Cloth
4339	Bolt of Mageweave
4340	Gray Dye
4341	Yellow Dye
4342	Purple Dye
4343	Brown Linen Pants
4344	Brown Linen Shirt
4345	Pattern: Red Woolen Boots
4346	Pattern: Heavy Woolen Cloak
4347	Pattern: Reinforced Woolen Shoulders
4348	Pattern: Phoenix Gloves
4349	Pattern: Phoenix Pants
4350	Pattern: Spider Silk Slippers
4351	Pattern: Shadow Hood
4352	Pattern: Boots of the Enchanter
4353	Pattern: Spider Belt
4354	Pattern: Rich Purple Silk Shirt
4355	Pattern: Icy Cloak
4356	Pattern: Star Belt
4357	Rough Blasting Powder
4358	Rough Dynamite
4359	Handful of Copper Bolts
4360	Rough Copper Bomb
4361	Copper Tube
4362	Rough Boomstick
4363	Copper Modulator
4364	Coarse Blasting Powder
4365	Coarse Dynamite
4366	Target Dummy
4367	Small Seaforium Charge
4368	Flying Tiger Goggles
4369	Deadly Blunderbuss
4370	Large Copper Bomb
4371	Bronze Tube
4372	Lovingly Crafted Boomstick
4373	Shadow Goggles
4374	Small Bronze Bomb
4375	Whirring Bronze Gizmo
4376	Flame Deflector
4377	Heavy Blasting Powder
4378	Heavy Dynamite
4379	Silver-plated Shotgun
4380	Big Bronze Bomb
4381	Minor Recombobulator
4382	Bronze Framework
4383	Moonsight Rifle
4384	Explosive Sheep
4385	Green Tinted Goggles
4386	Ice Deflector
4387	Iron Strut
4388	Discombobulator Ray
4389	Gyrochronatom
4390	Iron Grenade
4391	Compact Harvest Reaper Kit
4392	Advanced Target Dummy
4393	Craftsman's Monocle
4394	Big Iron Bomb
4395	Goblin Land Mine
4396	Mechanical Dragonling
4397	Gnomish Cloaking Device
4398	Large Seaforium Charge
4399	Wooden Stock
4400	Heavy Stock
4401	Mechanical Squirrel Box
4402	Small Flame Sac
4403	Portable Bronze Mortar
4404	Silver Contact
4405	Crude Scope
4406	Standard Scope
4407	Accurate Scope
4408	Schematic: Mechanical Squirrel
4409	Schematic: Small Seaforium Charge
4410	Schematic: Shadow Goggles
4411	Schematic: Flame Deflector
4412	Schematic: Moonsight Rifle
4413	Schematic: Discombobulator Ray
4414	Schematic: Portable Bronze Mortar
4415	Schematic: Craftsman's Monocle
4416	Schematic: Goblin Land Mine
4417	Schematic: Large Seaforium Charge
4419	Scroll of Intellect III
4421	Scroll of Protection III
4422	Scroll of Stamina III
4424	Scroll of Spirit III
4425	Scroll of Agility III
4426	Scroll of Strength III
4428	Spider Palp
4429	Deepfury's Orders
4430	Ethereal Talisman
4432	Sully Balloo's Letter
4433	Waterlogged Envelope
4434	Scarecrow Trousers
4435	Mote of Myzrael
4436	Jewel-encrusted Sash
4437	Channeler's Staff
4438	Pugilist Bracers
4439	Bruiser Club
4440	Sigil of Strom
4441	MacKreel's Moonshine
4443	Grim Pauldrons
4444	Black Husk Shield
4445	Flesh Carver
4446	Blackvenom Blade
4447	Cloak of Night
4448	Husk of Naraxis
4449	Naraxis' Fang
4450	Sigil Fragment
4453	Sigil of Thoradin
4454	Talon of Vultros
4455	Raptor Hide Harness
4456	Raptor Hide Belt
4457	Barbecued Buzzard Wing
4458	Sigil of Arathor
4459	Brittle Dragon Bone
4460	Ripped Wing Webbing
4461	Raptor Hide
4462	Cloak of Rot
4463	Beaded Raptor Collar
4464	Trouncing Boots
4465	Bonefist Gauntlets
4466	Sigil of Trollbane
4467	Sigil of Ignaeus
4468	Sheathed Trol'kalar
4469	Rod of Order
4470	Simple Wood
4471	Flint and Tinder
4472	Scroll of Myzrael
4473	Eldritch Shackles
4474	Ravenwood Bow
4476	Beastwalker Robe
4477	Nefarious Buckler
4478	Iridescent Scale Leggings
4479	Burning Charm
4480	Thundering Charm
4481	Cresting Charm
4482	Sealed Folder
4483	Burning Key
4484	Cresting Key
4485	Thundering Key
4487	Maiden's Folly Charts
4488	Spirit of Silverpine Charts
4489	Maiden's Folly Log
4490	Spirit of Silverpine Log
4491	Goggles of Gem Hunting
4492	Elven Gem
4493	Elven Gems
4494	Seahorn's Sealed Letter
4495	Bloodstone Amulet
4496	Small Brown Pouch
4497	Heavy Brown Bag
4498	Brown Leather Satchel
4499	Huge Brown Sack
4500	Traveler's Backpack
4502	Sample Elven Gem
4503	Witherbark Tusk
4504	Dwarven Guard Cloak
4505	Swampland Trousers
4506	Stromgarde Badge
4507	Pit Fighter's Shield
4508	Blood-tinged Armor
4509	Seawolf Gloves
4510	Befouled Bloodstone Orb
4511	Black Water Hammer
4512	Highland Raptor Eye
4513	Raptor Heart
4514	Sara Balloo's Plea
4515	Marez's Head
4516	Otto's Head
4517	Falconcrest's Head
4518	Torn Scroll Fragment
4519	Crumpled Scroll Fragment
4520	Singed Scroll Fragment
4521	Alterac Granite
4522	Witherbark Medicine Pouch
4524	Balloo's Memorial
4525	Trelane's Wand of Invocation
4526	Raptor Talon Amulet
4527	Azure Agate
4528	Tor'gan's Orb
4529	Enchanted Agate
4530	Trelane's Phylactery
4531	Trelane's Orb
4532	Trelane's Ember Agate
4533	Sealed Letter to Archmage Malin
4534	Steel-clasped Bracers
4535	Ironforge Memorial Ring
4536	Shiny Red Apple
4537	Tel'Abim Banana
4538	Snapvine Watermelon
4539	Goldenbark Apple
4540	Tough Hunk of Bread
4541	Freshly Baked Bread
4542	Moist Cornbread
4543	White Drakeskin Cap
4544	Mulgore Spice Bread
4545	Radiant Silver Bracers
4546	Call of the Raptor
4547	Gnomish Zapper
4548	Servomechanic Sledgehammer
4549	Seafire Band
4550	Coldwater Ring
4551	Or'Kalar's Head
4552	Smooth Stone Chip
4553	Jagged Piece of Stone
4554	Shiny Polished Stone
4555	Thick Scaly Tail
4556	Speckled Shell Fragment
4557	Fiery Gland
4558	Empty Barrel
4560	Fine Scimitar
4561	Scalping Tomahawk
4562	Severing Axe
4563	Billy Club
4564	Spiked Club
4565	Simple Dagger
4566	Sturdy Quarterstaff
4567	Merc Sword
4568	Grunt Axe
4569	Staunch Hammer
4570	Birchwood Maul
4571	War Knife
4575	Medicine Staff
4576	Light Bow
4577	Compact Shotgun
4580	Sabertooth Fang
4581	Patch of Fine Fur
4582	Soft Bushy Tail
4583	Thick Furry Mane
4584	Large Trophy Paw
4585	Dripping Spider Mandible
4586	Smooth Raptor Skin
4587	Tribal Raptor Feathers
4588	Pristine Raptor Skull
4589	Long Elegant Feather
4590	Curved Yellow Bill
4591	Eagle Eye
4592	Longjaw Mud Snapper
4593	Bristle Whisker Catfish
4594	Rockscale Cod
4595	Junglevine Wine
4596	Discolored Healing Potion
4597	Recipe: Discolored Healing Potion
4598	Goblin Fishing Pole
4599	Cured Ham Steak
4600	Cherry Grog
4601	Soft Banana Bread
4602	Moon Harvest Pumpkin
4603	Raw Spotted Yellowtail
4604	Forest Mushroom Cap
4605	Red-speckled Mushroom
4606	Spongy Morel
4607	Delicious Cave Mold
4608	Raw Black Truffle
4609	Recipe: Barbecued Buzzard Wing
4610	Carved Stone Urn
4611	Blue Pearl
4612	Black Drake's Heart
4613	Corroded Black Box
4614	Pendant of Myzrael
4615	Blacklash's Bindings
4616	Ryedol's Lucky Pick
4621	Ambassador Infernus' Bracer
4622	Sealed Note to Advisor Belgrum
4623	Lesser Stoneshield Potion
4624	Recipe: Lesser Stoneshield Potion
4625	Firebloom
4626	Small Stone Shard
4627	Large Stone Slab
4628	Bracers of Rock Binding
4629	Supply Crate
4630	Scrap Metal
4631	Tablet of Ryun'eh
4632	Ornate Bronze Lockbox
4633	Heavy Bronze Lockbox
4634	Iron Lockbox
4635	Hammertoe's Amulet
4636	Strong Iron Lockbox
4637	Steel Lockbox
4638	Reinforced Steel Lockbox
4639	Enchanted Sea Kelp
4640	Sign of the Earth
4641	Hand of Dagun
4643	Grimsteel Cape
4644	The Legacy Heart
4645	Chains of Hematus
4646	Star of Xil'yeh
4647	Yagyin's Digest
4648	Sigil of the Hammer
4649	Bonegrip's Note
4650	Bel'dugur's Note
4652	Salbac Shield
4653	Ironheel Boots
4654	Mysterious Fossil
4655	Giant Clam Meat
4656	Small Pumpkin
4658	Warrior's Cloak
4659	Warrior's Girdle
4660	Walking Boots
4661	Bright Mantle
4662	Journeyman's Cloak
4663	Journeyman's Belt
4665	Burnt Cloak
4666	Burnt Leather Belt
4668	Battle Chain Cloak
4669	Battle Chain Girdle
4671	Ancestral Cloak
4672	Ancestral Belt
4674	Tribal Cloak
4675	Tribal Belt
4676	Skeletal Gauntlets
4677	Veteran Cloak
4678	Veteran Girdle
4680	Brackwater Cloak
4681	Brackwater Girdle
4683	Spellbinder Cloak
4684	Spellbinder Belt
4686	Barbaric Cloth Cloak
4687	Barbaric Cloth Belt
4689	Hunting Cloak
4690	Hunting Belt
4692	Ceremonial Cloak
4693	Ceremonial Leather Belt
4694	Burnished Pauldrons
4695	Burnished Cloak
4696	Lapidis Tankard of Tidesippe
4697	Burnished Girdle
4698	Seer's Mantle
4699	Seer's Belt
4700	Inscribed Leather Spaulders
4701	Inscribed Cloak
4702	Prospector's Pick
4703	Broken Tools
4705	Lambent Scale Pauldrons
4706	Lambent Scale Cloak
4707	Lambent Scale Girdle
4708	Bright Belt
4709	Forest Leather Mantle
4710	Forest Cloak
4711	Glimmering Cloak
4712	Glimmering Mail Girdle
4713	Silver-thread Cloak
4714	Silver-thread Sash
4715	Emblazoned Cloak
4716	Combat Cloak
4717	Mail Combat Belt
4718	Nightsky Mantle
4719	Nightsky Cloak
4720	Nightsky Sash
4721	Insignia Mantle
4722	Insignia Cloak
4723	Humbert's Pants
4724	Humbert's Helm
4725	Chief Brigadier Pauldrons
4726	Chief Brigadier Cloak
4727	Chief Brigadier Girdle
4728	Twain's Shoulder
4729	Aurora Mantle
4731	Glyphed Epaulets
4732	Glyphed Cloak
4733	Blackforge Pauldrons
4734	Mistscape Mantle
4735	Mistscape Cloak
4736	Mistscape Sash
4737	Imperial Leather Spaulders
4738	Imperial Leather Belt
4739	Plainstrider Meat
4740	Plainstrider Feather
4741	Stromgarde Cavalry Leggings
4742	Mountain Cougar Pelt
4743	Pulsating Crystalline Shard
4744	Arcane Runed Bracers
4745	War Rider Bracers
4746	Doomsayer's Robe
4747	Stormbull Well Water
4748	Redhorn Well Water
4749	Wildmane Well Water
4751	Windfury Talon
4752	Azure Feather
4753	Bronze Feather
4755	Water Pitcher
4756	Ruined Cat Pelt
4757	Cracked Egg Shells
4758	Prairie Wolf Paw
4759	Plainstrider Talon
4763	Blackwood Recurve Bow
4765	Enamelled Broadsword
4766	Feral Blade
4767	Coppercloth Gloves
4768	Adept's Gloves
4769	Trophy Swoop Quill
4770	Bristleback Belt
4771	Harvest Cloak
4772	Warm Cloak
4775	Cracked Bill
4776	Ruffled Feather
4777	Ironwood Maul
4778	Heavy Spiked Mace
4779	Dull Kodo Tooth
4780	Kodo Horn Fragment
4781	Whispering Vest
4782	Solstice Robe
4783	Totem of Hawkwind
4784	Lifeless Stone
4785	Brimstone Belt
4786	Wise Man's Belt
4787	Burning Pitch
4788	Agile Boots
4789	Stable Boots
4790	Inferno Cloak
4791	Enchanted Water
4792	Spirit Cloak
4793	Sylvan Cloak
4794	Wolf Bracers
4795	Bear Bracers
4796	Owl Bracers
4797	Fiery Cloak
4798	Heavy Runed Cloak
4799	Antiquated Cloak
4800	Mighty Chain Pants
4801	Stalker Claws
4802	Cougar Claws
4803	Prairie Alpha Tooth
4804	Prairie Wolf Heart
4805	Flatland Cougar Femur
4806	Plainstrider Scale
4807	Swoop Gizzard
4808	Well Stone
4809	Ambercorn
4810	Boulder Pads
4813	Small Leather Collar
4814	Discolored Fang
4816	Legionnaire's Leggings
4817	Blessed Claymore
4818	Executioner's Sword
4819	Fizsprocket's Clipboard
4820	Guardian Buckler
4821	Bear Buckler
4822	Owl's Disk
4823	Water of the Seers
4824	Blurred Axe
4825	Callous Axe
4826	Marauder Axe
4827	Wizard's Belt
4828	Nightwind Belt
4829	Dreamer's Belt
4830	Saber Leggings
4831	Stalking Pants
4832	Mystic Sarong
4833	Glorious Shoulders
4834	Venture Co. Documents
4835	Elite Shoulders
4836	Fireproof Orb
4837	Strength of Will
4838	Orb of Power
4840	Long Bayonet
4841	Horn of Arra'chea
4843	Amethyst Runestone
4844	Opal Runestone
4845	Diamond Runestone
4846	Cog #5
4847	Lotwil's Shackles of Elemental Binding
4848	Battleboar Snout
4849	Battleboar Flank
4850	Bristleback Attack Plans
4851	Dirt-stained Map
4852	Flash Bomb
4854	Demon Scarred Cloak
4859	Burning Blade Medallion
4860	Glistening Frenzy Scale
4861	Sleek Feathered Tunic
4862	Scorpid Worker Tail
4863	Gnomish Tools
4864	Minshina's Skull
4865	Ruined Pelt
4866	Zalazane's Head
4867	Broken Scorpid Leg
4869	Fizzle's Claw
4870	Canvas Scraps
4871	Searing Collar
4872	Dry Scorpid Eye
4873	Dry Hardened Barnacle
4874	Clean Fishbones
4875	Slimy Bone
4876	Bloody Leather Boot
4877	Stone Arrowhead
4878	Broken Bloodstained Bow
4879	Squashed Rabbit Carcass
4880	Broken Spear
4881	Aged Envelope
4882	Benedict's Key
4883	Admiral Proudmoore's Orders
4886	Venomtail Poison Sac
4887	Intact Makrura Eye
4888	Crawler Mucus
4890	Taillasher Egg
4891	Kron's Amulet
4892	Durotar Tiger Fur
4893	Savannah Lion Tusk
4894	Plainstrider Kidney
4895	Thunder Lizard Horn
4896	Kodo Liver
4897	Thunderhawk Saliva Gland
4898	Lightning Gland
4903	Eye of Burning Shadow
4904	Venomtail Antidote
4905	Sarkoth's Mangled Claw
4906	Rainwalker Boots
4907	Woodland Tunic
4908	Nomadic Bracers
4909	Kodo Hunter's Leggings
4910	Painted Chain Gloves
4911	Thick Bark Buckler
4913	Painted Chain Belt
4914	Battleworn Leather Gloves
4915	Soft Wool Boots
4916	Soft Wool Vest
4917	Battleworn Chain Leggings
4918	Sack of Supplies
4919	Soft Wool Belt
4920	Battleworn Cape
4921	Dust-covered Leggings
4922	Jagged Chain Vest
4923	Primitive Hatchet
4924	Primitive Club
4925	Primitive Hand Blade
4926	Chen's Empty Keg
4928	Sandrunner Wristguards
4929	Light Scorpid Armor
4930	Handmade Leather Bag
4931	Hickory Shortbow
4932	Harpy Wing Clipper
4933	Seasoned Fighter's Cloak
4935	Wide Metal Girdle
4936	Dirt-trodden Boots
4937	Charging Buckler
4938	Blemished Wooden Staff
4939	Steady Bastard Sword
4940	Veiled Grips
4941	Really Sticky Glue
4942	Tiger Hide Boots
4944	Handsewn Cloak
4945	Faintly Glowing Skull
4946	Lightweight Boots
4947	Jagged Dagger
4948	Stinging Mace
4949	Orcish Cleaver
4951	Squealer's Belt
4952	Stormstout
4953	Trogg Ale
4954	Nomadic Belt
4958	Sun-beaten Cloak
4959	Throwing Tomahawk
4960	Flash Pellet
4961	Dreamwatcher Staff
4962	Double-layered Gloves
4963	Thunderhorn Cloak
4964	Goblin Smasher
4965	Bloodhoof Hand Axe
4966	Mazzranache's Head
4967	Tribal Warrior's Shield
4968	Bound Harness
4969	Fortified Bindings
4970	Rough-hewn Kodo Leggings
4971	Skorn's Hammer
4972	Cliff Runner Boots
4973	Plains Hunter Wristguards
4974	Compact Fighting Knife
4975	Vigilant Buckler
4976	Mistspray Kilt
4977	Sword of Hammerfall
4978	Ryedol's Hammer
4979	Enchanted Stonecloth Bracers
4980	Prospector Gloves
4981	Agmond's Belt Pouch
4982	Ripped Prospector Belt
4983	Rock Pulverizer
4984	Skull of Impending Doom
4986	Flawed Power Stone
4987	Dwarf Captain's Sword
4988	Burning Obsidian Band
4989	Mage Dragon Robe
4990	Scorched Bands
4992	Recruitment Letter
4995	Signed Recruitment Letter
4998	Blood Ring
4999	Azora's Will
5000	Coral Band
5001	Heart Ring
5002	Glowing Green Talisman
5003	Crystal Starfire Medallion
5004	Mark of the Kirin Tor
5005	Emberspark Pendant
5006	Khazgorm's Journal
5007	Band of Thorns
5008	Quicksilver Ring
5009	Mindbender Loop
5010	Inscribed Gold Ring
5011	Welken Ring
5012	Fungal Spores
5013	Fertile Bulb
5014	Wrapping Paper (PT)
5015	Wrapped Item (PT)
5016	Artisan's Trousers
5017	Nitroglycerin
5018	Wood Pulp
5019	Sodium Nitrate
5020	Kolkar Booty Key
5021	Explosive Stick of Gann
5022	Barak's Head
5023	Verog's Head
5024	Frost Vial
5025	Hezrul's Head
5026	Fire Tar
5027	Rendered Spores
5028	Lord Sakrasis' Scepter
5029	Talisman of the Naga Lord
5030	Centaur Bracers
5038	Tear of the Moons
5040	Shadow Hunter Knife
5042	Red Ribboned Wrapping Paper
5043	Red Ribboned Gift
5044	Blue Ribboned Gift
5045	Skull Gift
5048	Blue Ribboned Wrapping Paper
5049	Self-locking Ironpaper
5050	Ignition Key
5051	Dig Rat
5052	Unconscious Dig Rat
5054	Samophlange
5055	Intact Raptor Horn
5056	Root Sample
5057	Ripe Watermelon
5058	Silithid Egg
5059	Digging Claw
5060	Thieves' Tools
5061	Stolen Silver
5062	Raptor Head
5063	Kreenig Snarlsnout's Tusk
5064	Witchwing Talon
5065	Harpy Lieutenant Ring
5066	Fissure Plant
5067	Serena's Head
5068	Dried Seeds
5069	Fire Wand
5071	Shadow Wand
5072	Lok's Skull
5073	Nak's Skull
5074	Kuz's Skull
5075	Blood Shard
5076	Shipment of Boots
5077	Telescopic Lens
5078	Theramore Medal
5079	Cold Basilisk Eye
5080	Gazlowe's Ledger
5081	Kodo Hide Bag
5082	Thin Kodo Leather
5083	Pattern: Kodo Hide Bag
5084	Baron Longshore's Head
5085	Bristleback Quilboar Tusk
5086	Zhevra Hooves
5087	Plainstrider Beak
5088	Control Console Operating Manual
5089	Console Key
5092	Charred Razormane Wand
5093	Razormane Backstabber
5094	Razormane War Shield
5095	Rainbow Fin Albacore
5096	Prowler Claws
5097	Cats Eye Emerald
5098	Altered Snapjaw Shell
5099	Hoof of Lakota'mani
5100	Echeyakee's Hide
5101	Ishamuhale's Fang
5102	Owatanka's Tailspike
5103	Washte Pawne's Feather
5104	Heart of Isha Awak
5105	Explosive Shell
5106	Red Defias Mask
5107	Deckhand's Shirt
5108	Dark Iron Leather
5109	Stonesplinter Rags
5110	Dalaran Wizard's Robe
5111	Rathorian's Cape
5112	Ritual Blade
5113	Mark of the Syndicate
5114	Severed Talon
5115	Broken Wishbone
5116	Long Tail Feather
5117	Vibrant Plume
5118	Large Flat Tooth
5119	Fine Loose Hair
5120	Long Tail Hair
5121	Dirty Kodo Scale
5122	Thick Kodo Hair
5123	Steel Arrowhead
5124	Small Raptor Tooth
5125	Charged Scale
5126	Knowledge: Defias Disguise
5127	Knowledge: South Seas Pirate Disguise
5128	Shed Lizard Skin
5129	Knowledge: Dark Iron Dwarf Disguise
5130	Knowledge: Dalaran Wizard Disguise
5131	Knowledge: Stonesplinter Disguise
5132	Knowledge: Syndicate Disguise
5133	Seeping Gizzard
5134	Small Furry Paw
5135	Thin Black Claw
5136	Torn Furry Ear
5137	Bright Eyeball
5138	Harvester's Head
5139	Book of Thorns
5140	Flash Powder
5141	Book of Regrowth
5142	Book of Wrath II
5143	Thunder Lizard Blood
5145	Book of Healing Touch II
5147	Book of Entangling Roots II
5148	Book of Thorns II
5149	Book of Wrath III
5150	Book of Healing Touch III
5151	Book of Wrath IV
5152	Book of Healing Touch IV
5153	Book of Mark of the Wild IV
5154	Book of Thorns III
5155	Book of Mark of the Wild II
5156	Book of Wrath V
5158	Book of Tranquility
5160	Book of Healing Touch V
5163	Book of Mark of the Wild III
5164	Thunderhawk Wings
5165	Sunscale Feather
5166	Webwood Venom Sac
5167	Webwood Egg
5168	Timberling Seed
5169	Timberling Sprout
5170	Mossy Tumor
5172	Death Capsule
5173	Deathweed
5174	Note from Neeru
5175	Earth Totem
5176	Fire Totem
5177	Water Totem
5178	Air Totem
5179	Moss-twined Heart
5180	Necklace of Harmony
5181	Vibrant Silk Cape
5182	Shiver Blade
5183	Pulsating Hydra Heart
5184	Filled Crystal Phial
5185	Crystal Phial
5186	Partially Filled Vessel
5187	Rhahk'Zor's Hammer
5188	Filled Vessel
5189	Glowing Fruit
5190	Shimmering Frond
5191	Cruel Barb
5192	Thief's Blade
5193	Cape of the Brotherhood
5194	Taskmaster Axe
5195	Gold-flecked Gloves
5196	Smite's Reaver
5197	Cookie's Tenderizer
5198	Cookie's Stirring Rod
5199	Smelting Pants
5200	Impaling Harpoon
5201	Emberstone Staff
5202	Corsair's Overshirt
5203	Flatland Prowler Claw
5204	Bloodfeather Belt
5205	Sprouted Frond
5206	Bogling Root
5207	Opaque Wand
5208	Smoldering Wand
5209	Gloom Wand
5210	Burning Wand
5211	Dusk Wand
5212	Blazing Wand
5213	Scorching Wand
5214	Wand of Eventide
5215	Ember Wand
5216	Umbral Wand
5217	Tainted Heart
5218	Cleansed Timberling Heart
5219	Inscribed Bark
5220	Gnarlpine Fang
5221	Melenas' Head
5223	Empty Mana Gem
5227	Empty Mana Jewel
5229	Handstitched Leather Bracers
5232	Minor Soulstone
5233	Stone of Relu
5234	Flagongut's Fossil
5235	Alchemist's Wand
5236	Combustible Wand
5237	Mind-numbing Poison
5238	Pitchwood Wand
5239	Blackbone Wand
5240	Torchlight Wand
5241	Dwarven Flamestick
5242	Cinder Wand
5243	Firebelcher
5244	Consecrated Wand
5245	Summoner's Wand
5246	Excavation Rod
5247	Rod of Sorrow
5248	Flash Wand
5249	Burning Sliver
5250	Charred Wand
5251	Phial of Scrying
5252	Wand of Decay
5253	Goblin Igniter
5254	Rugged Spaulders
5255	Quilboar Tomahawk
5256	Kovork's Rattle
5257	Dark Hooded Cape
5259	Flaming Arrows
5263	Pocket Lint
5264	Complimentary Beer Token
5265	Watered-down Beer
5266	Eye of Adaegus
5267	Scarlet Kris
5268	Cracked Silithid Shell
5269	Silithid Ichor
5270	Death Cap
5271	Scaber Stalk
5272	Insane Scribbles
5273	Mathystra Relic
5274	Rose Mantle
5275	Binding Girdle
5279	Harpy Skinner
5283	"Monster - Dagger, Ornate Spikey Base"
5299	Gloves of the Moon
5302	Cobalt Buckler
5306	Wind Rider Staff
5309	Privateer Musket
5310	Sea Dog Britches
5311	Buckled Boots
5312	Riveted Gauntlets
5313	Totemic Clan Ring
5314	Boar Hunter's Cape
5315	Timberland Armguards
5316	Barkshell Tunic
5317	Dry Moss Tunic
5318	Zhovur Axe
5319	Bashing Pauldrons
5320	Padded Lamellar Boots
5321	Elegant Shortsword
5322	Demolition Hammer
5323	Everglow Lantern
5324	Engineer's Hammer
5325	Welding Shield
5326	Flaring Baton
5327	Greasy Tinker's Pants
5328	Cinched Belt
5329	Cat Figurine
5330	Elven Cup Relic
5332	Glowing Cat Figurine
5333	Mathystra Relic
5335	A Sack of Coins
5336	Grell Earring
5337	Wayfaring Gloves
5338	Ancient Moonstone Seal
5339	Serpentbloom
5340	Cauldron Stirrer
5341	Spore-covered Tunic
5342	Raptor Punch
5343	Barkeeper's Cloak
5344	Pointed Axe
5345	Stonewood Hammer
5346	Orcish Battle Bow
5347	Pestilent Wand
5348	Worn Parchment
5349	Conjured Muffin
5350	Conjured Water
5351	Bounty Hunter's Ring
5352	Book: The Powers Below
5353	Message for Elissa Starbreeze
5354	Letter to Delgren
5355	Beastmaster's Girdle
5356	Branding Rod
5357	Ward of the Vale
5359	Lorgalis Manuscript
5360	Highborne Relic
5361	Fishbone Toothpick
5362	Chew Toy
5363	Folded Handkerchief
5364	Dry Salt Lick
5366	Glowing Soul Gem
5367	Primitive Rock Tool
5368	Empty Wallet
5369	Gnawed Bone
5370	Bent Spoon
5371	Piece of Coral
5373	Lucky Charm
5374	Small Pocket Watch
5375	Scratching Stick
5376	Broken Mirror
5377	Scallop Shell
5379	Boot Knife
5380	Sealed Letter to Elissa
5381	Sealed Letter to Balthule
5382	Anaya's Pendant
5383	Athrikus Narassin's Head
5385	Crawler Leg
5386	Fine Moonstalker Pelt
5387	Enchanted Moonstalker Cloak
5388	Ran Bloodtooth's Skull
5389	Corrupted Furbolg Totem
5390	Fandral's Message
5391	Rare Earth
5392	Thistlewood Dagger
5393	Thistlewood Staff
5394	Archery Training Gloves
5395	Woodland Shield
5396	Key to Searing Gorge
5397	Defias Gunpowder
5398	Canopy Leggings
5399	Tracking Boots
5400	Blood of Cobrahn
5401	Blood of Pythas
5402	Blood of Anacondra
5403	Blood of Serpentis
5404	Serpent's Shoulders
5405	Draped Cloak
5406	Empty Minor Bloodstone
5411	Winterhoof Cleansing Totem
5412	Thresher Eye
5413	Moonstalker Fang
5414	Grizzled Scalp
5415	Thunderhorn Cleansing Totem
5416	Wildmane Cleansing Totem
5419	Feral Bracers
5420	Banshee Armor
5421	Fiery Blaze Enchantment
5422	Brambleweed Leggings
5423	Boahn's Fang
5424	Ancient Statuette
5425	Runescale Girdle
5426	Serpent's Kiss
5427	Crude Pocket Watch
5428	An Exotic Cookbook
5429	A Pretty Rock
5430	Intricate Bauble
5431	Empty Hip Flask
5432	Hickory Pipe
5433	Rag Doll
5435	Shiny Dinglehopper
5437	Bathran's Hair
5439	Small Quiver
5440	Bottle of Disease
5441	Small Shot Pouch
5442	Head of Arugal
5443	Gold-plated Buckler
5444	Miner's Cape
5445	Ring of Zoram
5446	Broken Elemental Bracer
5447	Damaged Elemental Bracer
5448	Fractured Elemental Bracer
5451	Crushed Elemental Bracer
5455	Divined Scroll
5456	Divining Scroll
5457	Severed Voodoo Claw
5458	Dirtwood Belt
5459	Defender Axe
5460	Orendil's Cure
5461	Branch of Cenarius
5462	Dartol's Rod of Transformation
5463	Glowing Gem
5464	Iron Shaft
5465	Small Spider Leg
5466	Scorpid Stinger
5467	Kodo Meat
5468	Soft Frenzy Flesh
5469	Strider Meat
5470	Thunder Lizard Tail
5471	Stag Meat
5472	Kaldorei Spider Kabob
5473	Scorpid Surprise
5474	Roasted Kodo Meat
5475	Wooden Key
5476	Fillet of Frenzy
5477	Strider Stew
5478	Dig Rat Stew
5479	Crispy Lizard Tail
5480	Lean Venison
5481	Satyr Horns
5482	Recipe: Kaldorei Spider Kabob
5483	Recipe: Scorpid Surprise
5484	Recipe: Roasted Kodo Meat
5485	Recipe: Fillet of Frenzy
5486	Recipe: Strider Stew
5487	Recipe: Dig Rat Stew
5488	Recipe: Crispy Lizard Tail
5489	Recipe: Lean Venison
5490	Wrathtail Head
5493	Elune's Tear
5494	Handful of Stardust
5498	Small Lustrous Pearl
5500	Iridescent Pearl
5503	Clam Meat
5504	Tangy Clam Meat
5505	Teronis' Journal
5506	Beady Eye Stalk
5507	Ornate Spyglass
5508	Fallen Moonstone
5509	Healthstone
5510	Greater Healthstone
5511	Lesser Healthstone
5512	Minor Healthstone
5513	Mana Jade
5514	Mana Agate
5516	Threshadon Fang
5517	Tiny Bronze Key
5518	Tiny Iron Key
5519	Iron Pommel
5520	Velinde's Journal
5521	Velinde's Key
5522	Spellstone
5523	Small Barnacled Clam
5524	Thick-shelled Clam
5525	Boiled Clams
5526	Clam Chowder
5527	Goblin Deviled Clams
5528	Recipe: Clam Chowder
5529	Tomb Dust
5530	Blinding Powder
5533	Ilkrud Magthrull's Tome
5534	Parker's Lunch
5535	Compendium of the Fallen
5536	Mythology of the Titans
5537	Sarilus Foulborne's Head
5538	Vorrel's Wedding Ring
5539	Letter of Commendation
5540	Pearl-handled Dagger
5541	Iridescent Hammer
5542	Pearl-clasped Cloak
5543	Plans: Iridescent Hammer
5544	Dal Bloodclaw's Skull
5547	Reconstructed Rod
5562	The Lay of Ameth'Aran
5563	The Fall of Ameth'Aran
5565	Infernal Stone
5566	Broken Antler
5567	Silver Hook
5568	Smooth Pebble
5569	Seaweed
5570	Deepmoss Egg
5571	Small Black Pouch
5572	Small Green Pouch
5573	Green Leather Bag
5574	White Leather Bag
5575	Large Green Sack
5576	Large Brown Sack
5577	Plans: Rough Bronze Bracers
5578	Plans: Silvered Bronze Breastplate
5579	Militia Warhammer
5580	Militia Hammer
5581	Smooth Walking Staff
5582	Stonetalon Sap
5583	Fey Dragon Scale
5584	Twilight Whisker
5585	Courser Eye
5586	Thistlewood Blade
5587	Thornroot Club
5588	Lydon's Toxin
5589	Moss-covered Gauntlets
5590	Cord Bracers
5591	Rain-spotted Cape
5592	Shackled Girdle
5593	Crag Buckler
5594	Letter to Jin'Zil
5595	Thicket Hammer
5596	Ashwood Bow
5601	Hatched Egg Sac
5602	Sticky Spider Webbing
5603	Wizbang's Gunnysack
5604	Elven Wand
5605	Pruning Knife
5606	Gardening Gloves
5608	Living Cowl
5609	Steadfast Cinch
5610	Gustweald Cloak
5611	Tear of Grief
5612	Ivy Cuffs
5613	Staff of the Purifier
5614	Seraph's Strike
5615	Woodsman Sword
5616	Gutwrencher
5617	Vagabond Leggings
5618	Scout's Cloak
5619	Jade Phial
5620	Vial of Innocent Blood
5621	Tourmaline Phial
5622	Clergy Ring
5623	Amethyst Phial
5624	Circlet of the Order
5626	Skullchipper
5627	Relic Blade
5628	Zamah's Note
5629	Hammerfist Gloves
5630	Windfelt Gloves
5631	Rage Potion
5633	Great Rage Potion
5634	Free Action Potion
5635	Sharp Claw
5636	Delicate Feather
5637	Large Fang
5638	Toxic Fogger
5639	Filled Jade Phial
5640	Recipe: Rage Potion
5641	Recipe: Cowardly Flight Potion
5642	Recipe: Free Action Potion
5643	Recipe: Great Rage Potion
5644	Tome of Conjure Water
5645	Filled Tourmaline Phial
5646	Vial of Blessed Water
5647	Tome of Blink
5648	Tome of Frost Armor III
5649	Tome of Blizzard
5650	Tome of Conjure Water III
5654	Instant Toxin
5655	Chestnut Mare Bridle
5656	Brown Horse Bridle
5657	Recipe: Instant Toxin
5658	Libram: Seal of Might
5659	Smoldering Embers
5660	Libram: Seal of Righteousness
5661	Libram: Seal of Righteousness II
5662	Libram: Seal of Righteousness III
5663	Horn of the Red Wolf
5664	Corroded Shrapnel
5665	Horn of the Dire Wolf
5666	Libram: Seal of Wrath II
5667	Libram: Seal of Wisdom II
5668	Horn of the Brown Wolf
5669	Dust Devil Debris
5670	Libram: Seal of Wrath IV
5671	Libram: Seal of Might III
5672	Libram: Exorcism
5673	Libram: Exorcism II
5674	Libram: Exorcism III
5675	Crystalized Scales
5676	Libram: Sense Undead
5677	Libram: Turn Undead
5679	Libram: Seal of Wisdom III
5680	Libram: Seal of Protection II
5681	Corrosive Sap
5682	Libram: Turn Undead II
5683	Libram: Divine Shield II
5684	Libram: Seal of Salvation
5685	Libram: Redemption
5686	Ordanus' Head
5687	Gatekeeper's Key
5689	Sleepers' Key
5690	Claw Key
5691	Barrow Key
5692	Remote Detonator (Red)
5693	Remote Detonator (Blue)
5694	NG-5 Explosives (Red)
5695	NG-5 Explosives (Blue)
5696	Tablet of Shock
5697	Tablet of Healing Totem
5698	Tablet of Lightning Shield
5699	Tablet of Ghost Wolf
5700	Tablet of Healing Totem II
5701	Tablet of Sentry Totem
5702	Tablet of Agitating Totem II
5703	Tablet of Thunderclap
5704	Tablet of Water Breathing
5705	Tablet of Healing Totem III
5706	Tablet of Serpent Totem III
5707	Tablet of Far Sight
5708	Tablet of Ethereal Form
5709	Tablet of Water Walking
5710	Tablet of Healing Totem IV
5711	Tablet of Ghost Wolf II
5712	Tablet of Serpent Totem IV
5713	Tablet of Thunderbolt
5714	Tablet of Ensnaring Totem II
5715	Tablet of Lightning Storm III
5716	Tablet of Restoration VI
5717	Venture Co. Letters
5718	Venture Co. Engineering Plans
5719	Grimoire of Life Drain II
5720	Grimoire of Curse of Mannoroth II
5721	Grimoire of Create Spellstone
5722	Grimoire of Siphon Mana II
5723	Grimoire of Curse of Sargeras III
5724	Grimoire of Curse of Tongues
5725	Grimoire of Pestilence III
5726	Grimoire of Create Greater Bloodstone
5727	Grimoire of Mana Funnel
5728	Grimoire of Rain of Fire II
5729	Grimoire of Fear III
5730	Book of Rejuvenation
5731	Scroll of Messaging
5732	NG-5
5733	Unidentified Ore
5734	Super Reaper 6000 Blueprints
5735	Sealed Envelope
5736	Gerenzo's Mechanical Arm
5737	Covert Ops Plans: Alpha & Beta
5738	Covert Ops Pack
5739	Barbaric Harness
5740	Red Fireworks Rocket
5741	Rock Chip
5742	Gemstone Dagger
5743	Prismstone Ring
5744	Pale Skinner
5748	Centaur Longbow
5749	Scythe Axe
5750	Warchief's Girdle
5751	Webwing Cloak
5752	Wyvern Tailspike
5753	Ruffled Chaplet
5754	Wolfpack Medallion
5755	Onyx Shredder Plate
5756	Sliverblade
5757	Hardwood Cudgel
5758	Mithril Lockbox
5759	Thorium Lockbox
5760	Eternium Lockbox
5761	Anvilmar Sledge
5762	Red Linen Bag
5763	Red Woolen Bag
5764	Green Silk Pack
5765	Black Silk Pack
5766	Lesser Wizard's Robe
5767	Violet Robes
5768	Gnome Race Ticket
5769	Goblin Race Ticket
5770	Robes of Arcana
5771	Pattern: Red Linen Bag
5772	Pattern: Red Woolen Bag
5773	Pattern: Robes of Arcana
5774	Pattern: Green Silk Pack
5775	Pattern: Black Silk Pack
5776	Elder's Cane
5777	Brave's Axe
5778	Primitive Walking Stick
5779	Forsaken Bastard Sword
5780	Murloc Scale Belt
5781	Murloc Scale Breastplate
5782	Thick Murloc Armor
5783	Murloc Scale Bracers
5784	Slimy Murloc Scale
5785	Thick Murloc Scale
5786	Pattern: Murloc Scale Belt
5787	Pattern: Murloc Scale Breastplate
5788	Pattern: Thick Murloc Armor
5789	Pattern: Murloc Scale Bracers
5790	Lonebrow's Journal
5791	Henrig Lonebrow's Journal
5792	Razorflank's Medallion
5793	Razorflank's Heart
5794	Salty Scorpid Venom
5795	Hardened Tortoise Shell
5796	Encrusted Tail Fin
5797	Indurium Flake
5798	Rocket Car Parts
5799	Kravel's Parts Order
5800	Kravel's Parts
5801	Kraul Guano
5802	Delicate Car Parts
5803	Speck of Dream Dust
5804	Goblin Rumors
5805	Heart of Zeal
5806	Fool's Stout
5807	Fool's Stout Report
5808	Pridewing Venom Sac
5809	Highperch Venom Sac
5810	Fresh Carcass
5811	Frostmaw's Mane
5812	Robes of Antiquity
5813	Emil's Brand
5814	Snapbrook Armor
5815	Glacial Stone
5816	Light of Elune
5817	Lunaris Bow
5818	Moonbeam Wand
5819	Sunblaze Coif
5820	Faerie Mantle
5821	Darkstalker Boots
5822	Hedgeseed Gauntlets
5823	Poisonous Mushroom
5824	Tablet of Will
5825	Treshala's Pendant
5826	Kravel's Scheme
5827	Fizzle Brassbolts' Letter
5829	Razor-sharp Beak
5830	Kenata's Head
5831	Fardel's Head
5832	Marcel's Head
5833	Indurium Ore
5834	Mok'Morokk's Snuff
5835	Mok'Morokk's Grog
5836	Mok'Morokk's Strongbox
5837	Steelsnap's Rib
5838	Kodo Skin Scroll
5839	Journal Page
5840	Searing Tongue
5841	Searing Heart
5842	Unrefined Ore Sample
5843	Grenka's Claw
5844	Fragments of Rok'Alim
5845	Flank of Meat
5846	Korran's Sealed Note
5847	Mirefin Head
5848	Hollow Vulture Bone
5849	Crate of Crash Helmets
5850	Belgrom's Sealed Note
5851	Cozzle's Key
5852	Fuel Regulator Blueprints
5853	Intact Silithid Carapace
5854	Silithid Talon
5855	Silithid Heart
5857	Gnome Prize Box
5858	Goblin Prize Box
5859	Party Grenade
5860	Legacy of the Aspects
5861	Beginnings of the Undead Threat
5862	Seaforium Booster
5863	Guild Charter
5864	Gray Ram
5865	Modified Seaforium Booster
5866	Sample of Indurium Ore
5867	Etched Phial
5868	Filled Etched Phial
5869	Cloven Hoof
5871	Large Hoof
5872	Brown Ram
5873	White Ram
5874	Harness: Black Ram
5875	Harness: Blue Ram
5876	Blueleaf Tuber
5877	Cracked Silithid Carapace
5878	Super Snuff
5879	Twilight Pendant
5880	Crate With Holes
5881	Head of Kelris
5882	Captain's Documents
5883	Forked Mudrock Tongue
5884	Unpopped Darkmist Eye
5897	Snufflenose Owner's Manual
5916	Gnome Camera Key
5917	Spy's Report
5918	Defiant Orc Head
5919	Blackened Iron Shield
5936	Animal Skin Belt
5937	Goblin Camera Key
5938	Pristine Crawler Leg
5939	Sewing Gloves
5940	Bone Buckler
5941	Brass Scale Pants
5942	Jeweled Pendant
5943	Rift Bracers
5944	Greaves of the People's Militia
5945	Deadmire's Tooth
5946	Sealed Note to Elling
5947	Defias Docket
5948	Letter to Jorgen
5949	Scrap of Paper
5950	Reethe's Badge
5951	Moist Towelette
5952	Corrupted Brain Stem
5956	Blacksmith Hammer
5957	Handstitched Leather Vest
5958	Fine Leather Pants
5959	Acidic Venom Sac
5960	Sealed Note to Watcher Backus
5961	Dark Leather Pants
5962	Guardian Pants
5963	Barbaric Leggings
5964	Barbaric Shoulders
5965	Guardian Cloak
5966	Guardian Gloves
5967	Girdle of Nobility
5968	Rugged Boots
5969	Regent's Cloak
5970	Serpent Gloves
5971	Feathered Cape
5972	Pattern: Fine Leather Pants
5973	Pattern: Barbaric Leggings
5974	Pattern: Guardian Cloak
5975	Ruffian Belt
5976	Guild Tabard
5996	Elixir of Water Breathing
5997	Elixir of Minor Defense
5998	Stormpike's Request
6016	Wolf Heart Sample
6037	Truesilver Bar
6038	Giant Clam Scorcho
6039	Recipe: Giant Clam Scorcho
6040	Golden Scale Bracers
6041	Steel Weapon Chain
6042	Iron Shield Spike
6043	Iron Counterweight
6044	Plans: Iron Shield Spike
6045	Plans: Iron Counterweight
6046	Plans: Steel Weapon Chain
6047	Plans: Golden Scale Coif
6048	Shadow Protection Potion
6049	Fire Protection Potion
6050	Frost Protection Potion
6051	Holy Protection Potion
6052	Nature Protection Potion
6053	Recipe: Holy Protection Potion
6054	Recipe: Shadow Protection Potion
6055	Recipe: Fire Protection Potion
6056	Recipe: Frost Protection Potion
6057	Recipe: Nature Protection Potion
6058	Blackened Leather Belt
6059	Nomadic Vest
6060	Flax Bracers
6061	Graystone Bracers
6062	Heavy Cord Bracers
6063	Cold Steel Gauntlets
6064	Miniature Platinum Discs
6065	Khadgar's Essays on Dimensional Convergence
6066	Khan Dez'hepah's Head
6067	Centaur Ear
6068	Recipe: Shadow Oil
6069	Crudely Dried Meat
6070	Wolfskin Bracers
6071	Draenethyst Crystal
6072	Khan Jehn's Head
6073	Khan Shaka's Head
6074	War Horn Mouthpiece
6075	Vimes's Report
6076	Tapered Pants
6077	Maraudine Key Fragment
6078	Pikeman Shield
6079	Crude Charm
6080	Shadow Panther Heart
6081	Mire Lord Fungus
6082	Deepstrider Tumor
6083	Broken Tears
6084	Stormwind Guard Leggings
6085	Footman Tunic
6086	Faustin's Truth Serum
6087	Chausses of Westfall
6089	Zraedus's Brew
6091	Crate of Power Stones
6092	Black Whelp Boots
6093	Orc Crusher
6094	Piercing Axe
6095	Wandering Boots
6096	Apprentice's Shirt
6097	Acolyte's Shirt
6098	Neophyte's Robe
6116	Apprentice's Robe
6117	Squire's Shirt
6118	Squire's Pants
6119	Neophyte's Robe
6120	Recruit's Shirt
6121	Recruit's Pants
6122	Recruit's Boots
6123	Novice's Robe
6124	Novice's Pants
6125	Brawler's Harness
6126	Trapper's Pants
6127	Trapper's Boots
6129	Acolyte's Robe
6130	Trapper's Shirt
6131	Trapper's Pants
6132	Libram: Seal of Wisdom
6133	Libram: Seal of Fury
6134	Primitive Mantle
6135	Primitive Kilt
6136	Thug Shirt
6137	Thug Pants
6138	Thug Boots
6139	Novice's Robe
6140	Apprentice's Robe
6144	Neophyte's Robe
6145	Clarice's Pendant
6146	Sundried Driftwood
6148	Web-covered Boots
6149	Greater Mana Potion
6150	A Frayed Knot
6166	Coyote Jawbone
6167	Neeka's Report
6168	Sawtooth Snapper Claw
6169	Unprepared Sawtooth Flank
6170	Wizards' Reagents
6171	Wolf Handler Gloves
6172	Lost Supplies
6173	Snow Boots
6174	Twain Random Sword
6175	Atal'ai Artifact
6176	Dwarven Kite Shield
6177	Ironwrought Bracers
6178	Shipment to Nethergarde
6179	Privateer's Cape
6180	Slarkskin
6181	Fetish of Hakkar
6182	Dim Torch
6183	Unlit Poor Torch
6184	Monstrous Crawler Leg
6185	Bear Shawl
6186	Trogg Slicer
6187	Dwarven Defender
6188	Mud Stompers
6189	Durable Chain Shoulders
6190	Draenethyst Shard
6191	Kimbra Boots
6192	Khan Hratha's Head
6193	Bundle of Atal'ai Artifacts
6194	Barreling Reaper
6195	Wax-polished Armor
6196	Noboru's Cudgel
6197	Loch Croc Hide Vest
6198	Jurassic Wristguards
6199	Black Widow Band
6200	Garneg's War Belt
6201	Lithe Boots
6202	Fingerless Gloves
6203	Thuggish Shield
6204	Tribal Worg Helm
6205	Burrowing Shovel
6206	Rock Chipper
6207	PVP - Horde Tower Plans
6208	PVP - Alliance Tower Plans
6209	PVP - Horde Mine Deed
6210	PVP - Alliance Mine Deed
6211	Recipe: Elixir of Ogre's Strength
6212	Head of Jammal'an
6214	Heavy Copper Maul
6215	Balanced Fighting Stick
6216	Mystical Powder
6217	Copper Rod
6218	Runed Copper Rod
6219	Arclight Spanner
6220	Meteor Shard
6222	Formula: Imbue Chest - Minor Spirit
6223	Crest of Darkshire
6226	Bloody Apron
6238	Brown Linen Robe
6239	Red Linen Vest
6240	Blue Linen Vest
6241	White Linen Robe
6242	Blue Linen Robe
6243	Green Woolen Robe
6245	Karnitol's Satchel
6246	Hatefury Claw
6247	Hatefury Horn
6248	Scorpashi Venom
6249	Aged Kodo Hide
6250	Felhound Brain
6251	Nether Wing
6252	Doomwarder Blood
6253	Leftwitch's Package
6256	Fishing Pole
6257	Roc Gizzard
6258	Ironfur Liver
6259	Groddoc Liver
6260	Blue Dye
6261	Orange Dye
6262	Galen's Journal
6263	Blue Overalls
6264	Greater Adept's Robe
6265	Soul Shard
6266	Disciple's Vest
6267	Disciple's Pants
6268	Pioneer Tunic
6269	Pioneer Trousers
6270	Pattern: Blue Linen Vest
6271	Pattern: Red Linen Vest
6272	Pattern: Blue Linen Robe
6273	Pattern: Green Woolen Robe
6274	Pattern: Blue Overalls
6275	Pattern: Greater Adept's Robe
6276	Musty Note
6277	Musty Parchment
6278	Musty Scroll
6279	Musty Letter
6280	Musty Missive
6281	Rattlecage Skull
6282	Sacred Burial Trousers
6283	The Book of Ur
6284	Runes of Summoning
6285	Egalin's Grimoire
6286	Pure Hearts
6287	Atal'ai Tablet Fragment
6288	Atal'ai Tablet
6289	Raw Longjaw Mud Snapper
6290	Brilliant Smallfish
6291	Raw Brilliant Smallfish
6292	10 Pound Mud Snapper
6293	Dried Bat Blood
6294	12 Pound Mud Snapper
6295	15 Pound Mud Snapper
6296	Patch of Bat Hair
6298	Bloody Bat Fang
6299	Sickly Looking Fish
6300	Husk Fragment
6302	Delicate Insect Wing
6303	Raw Slitherskin Mackerel
6304	Damp Diary Page (Day 4)
6305	Damp Diary Page (Day 87)
6306	Damp Diary Page (Day 512)
6307	Message in a Bottle
6308	Raw Bristle Whisker Catfish
6309	17 Pound Catfish
6310	19 Pound Catfish
6311	22 Pound Catfish
6312	Dalin's Heart
6313	Comar's Heart
6314	Wolfmaster Cape
6315	Steelarrow Crossbow
6316	Loch Frenzy Delight
6317	Raw Loch Frenzy
6318	Odo's Ley Staff
6319	Girdle of the Blindwatcher
6320	Commander's Crest
6321	Silverlaine's Family Seal
6323	Baron's Scepter
6324	Robes of Arugal
6325	Recipe: Brilliant Smallfish
6326	Recipe: Slitherskin Mackerel
6327	The Pacifier
6328	Recipe: Longjaw Mud Snapper
6329	Recipe: Loch Frenzy Delight
6330	Recipe: Bristle Whisker Catfish
6331	Howling Blade
6332	Black Pearl Ring
6333	Spikelash Dagger
6335	Grizzled Boots
6336	Infantry Tunic
6337	Infantry Leggings
6338	Silver Rod
6339	Runed Silver Rod
6340	Fenrus' Hide
6341	Eerie Stable Lantern
6342	Formula: Enchant Chest - Minor Mana
6343	Formula: Imbue Chest - Spirit
6344	Formula: Enchant Bracer - Minor Spirit
6345	Formula: Imbue Cloak - Protection
6346	Formula: Enchant Chest - Lesser Mana
6347	Formula: Enchant Bracer - Minor Strength
6348	Formula: Enchant Weapon - Minor Beastslayer
6349	Formula: Enchant 2H Weapon - Lesser Intellect
6350	Rough Bronze Boots
6351	Dented Crate
6352	Waterlogged Crate
6353	Small Chest
6354	Small Locked Chest
6355	Sturdy Locked Chest
6356	Battered Chest
6357	Sealed Crate
6358	Oily Blackmouth
6359	Firefin Snapper
6360	Steelscale Crushfish
6361	Raw Rainbow Fin Albacore
6362	Raw Rockscale Cod
6363	26 Pound Catfish
6364	32 Pound Catfish
6365	Strong Fishing Pole
6366	Darkwood Fishing Pole
6367	Big Iron Fishing Pole
6368	Recipe: Rainbow Fin Albacore
6369	Recipe: Rockscale Cod
6370	Blackmouth Oil
6371	Fire Oil
6372	Swim Speed Potion
6373	Elixir of Firepower
6374	Enchanted Powder
6375	Formula: Enchant Bracer - Lesser Spirit
6376	Formula: Enchant Boots - Minor Stamina
6377	Formula: Enchant Boots - Minor Agility
6378	Seer's Cape
6379	Inscribed Leather Belt
6380	Inscribed Buckler
6381	Bright Cloak
6382	Forest Leather Belt
6383	Forest Buckler
6384	Stylish Blue Shirt
6385	Stylish Green Shirt
6386	Glimmering Mail Legguards
6387	Glimmering Mail Bracers
6388	Glimmering Mail Pauldrons
6389	Glimmering Mail Coif
6390	Pattern: Stylish Blue Shirt
6391	Pattern: Stylish Green Shirt
6392	Belt of Arugal
6393	Silver-thread Gloves
6394	Silver-thread Boots
6395	Silver-thread Amice
6396	Emblazoned Chestpiece
6397	Emblazoned Gloves
6398	Emblazoned Belt
6399	Emblazoned Shoulders
6400	Glimmering Shield
6401	Pattern: Dark Silk Shirt
6402	Mail Combat Leggings
6403	Mail Combat Armguards
6404	Mail Combat Spaulders
6405	Nightsky Trousers
6406	Nightsky Boots
6407	Nightsky Wristbands
6408	Insignia Gloves
6409	Insignia Belt
6410	Insignia Bracers
6411	Chief Brigadier Armor
6412	Chief Brigadier Boots
6413	Chief Brigadier Bracers
6414	Seal of Sylvanas
6415	Aurora Robe
6416	Aurora Boots
6417	Aurora Cloak
6418	Aurora Sash
6419	Glyphed Mitts
6420	Glyphed Boots
6421	Glyphed Belt
6422	Glyphed Helm
6423	Blackforge Greaves
6424	Blackforge Cape
6425	Blackforge Girdle
6426	Blackforge Bracers
6427	Mistscape Robe
6428	Mistscape Gloves
6429	Mistscape Wizard Hat
6430	Imperial Leather Breastplate
6431	Imperial Leather Boots
6432	Imperial Cloak
6433	Imperial Leather Helm
6435	Infused Burning Gem
6436	Burning Gem
6438	Dull Elemental Bracer
6439	Broken Binding Bracer
6440	Brainlash
6441	Shadowstalker Scalp
6442	Oracle Crystal
6443	Deviate Hide
6444	Forked Tongue
6445	Brittle Molting
6446	Snakeskin Bag
6447	Worn Turtle Shell Shield
6448	Tail Spike
6449	Glowing Lizardscale Cloak
6450	Silk Bandage
6451	Heavy Silk Bandage
6452	Anti-Venom
6453	Strong Anti-Venom
6454	Manual: Strong Anti-Venom
6456	Acidic Slime
6457	Rusted Engineering Parts
6458	Oil Covered Fish
6459	Savage Trodders
6460	Cobrahn's Grasp
6461	Slime-encrusted Pads
6462	Secure Crate
6463	Deep Fathom Ring
6464	Wailing Essence
6465	Robe of the Moccasin
6466	Deviate Scale Cloak
6467	Deviate Scale Gloves
6468	Deviate Scale Belt
6469	Venomstrike
6470	Deviate Scale
6471	Perfect Deviate Scale
6472	Stinging Viper
6473	Armor of the Fang
6474	Pattern: Deviate Scale Cloak
6475	Pattern: Deviate Scale Gloves
6476	Pattern: Deviate Scale Belt
6477	Grassland Sash
6478	Rat Stompers
6479	Malem Pendant
6480	Slick Deviate Leggings
6481	Dagmire Gauntlets
6482	Firewalker Boots
6486	Singed Scale
6487	Vile Familiar Head
6488	Simple Tablet
6489	Weatherworn Parchment
6490	Dark Parchment
6491	Heavy Parchment
6492	Sooty Parchment
6493	Tattered Parchment
6494	Scrawled Parchment
6495	Weatherbeaten Parchment
6496	Detailed Parchment
6497	Simple Parchment
6498	Inscribed Kodo Leather
6499	Inscribed Kodo Leather
6500	Inscribed Kodo Leather
6501	Inscribed Kodo Leather
6502	Violet Scale Armor
6503	Harlequin Robes
6504	Wingblade
6505	Crescent Staff
6506	Infantry Boots
6507	Infantry Bracers
6508	Infantry Cloak
6509	Infantry Belt
6510	Infantry Gauntlets
6511	Journeyman's Robe
6512	Disciple's Robe
6513	Disciple's Sash
6514	Disciple's Cloak
6515	Disciple's Gloves
6516	Imp Summoning Scroll
6517	Pioneer Belt
6518	Pioneer Boots
6519	Pioneer Bracers
6520	Pioneer Cloak
6521	Pioneer Gloves
6522	Deviate Fish
6523	Buckled Harness
6524	Studded Leather Harness
6525	Grunt's Harness
6526	Battle Harness
6527	Ancestral Robe
6528	Spellbinder Robe
6529	Shiny Bauble
6530	Nightcrawlers
6531	Barbaric Cloth Robe
6532	Bright Baubles
6533	Aquadynamic Fish Attractor
6534	Forged Steel Bars
6535	Tablet of Verga
6536	Willow Vest
6537	Willow Boots
6538	Willow Robe
6539	Willow Belt
6540	Willow Pants
6541	Willow Gloves
6542	Willow Cape
6543	Willow Bracers
6544	Voidwalker Summoning Scroll
6545	Soldier's Armor
6546	Soldier's Leggings
6547	Soldier's Gauntlets
6548	Soldier's Girdle
6549	Soldier's Cloak
6550	Soldier's Wristguards
6551	Soldier's Boots
6552	Bard's Tunic
6553	Bard's Trousers
6554	Bard's Gloves
6555	Bard's Cloak
6556	Bard's Bracers
6557	Bard's Boots
6558	Bard's Belt
6559	Bard's Buckler
6560	Soldier's Shield
6561	Seer's Padded Armor
6562	Shimmering Boots
6563	Shimmering Bracers
6564	Shimmering Cloak
6565	Shimmering Gloves
6566	Shimmering Amice
6567	Shimmering Armor
6568	Shimmering Trousers
6569	Shimmering Robe
6570	Shimmering Sash
6571	Scouting Buckler
6572	Defender Shield
6573	Defender Boots
6574	Defender Bracers
6575	Defender Cloak
6576	Defender Girdle
6577	Defender Gauntlets
6578	Defender Leggings
6579	Defender Spaulders
6580	Defender Tunic
6581	Scouting Belt
6582	Scouting Boots
6583	Scouting Bracers
6584	Scouting Tunic
6585	Scouting Cloak
6586	Scouting Gloves
6587	Scouting Trousers
6588	Scouting Spaulders
6589	Viridian Band
6590	Battleforge Boots
6591	Battleforge Wristguards
6592	Battleforge Armor
6593	Battleforge Cloak
6594	Battleforge Girdle
6595	Battleforge Gauntlets
6596	Battleforge Legguards
6597	Battleforge Shoulderguards
6598	Dervish Buckler
6599	Battleforge Shield
6600	Dervish Belt
6601	Dervish Boots
6602	Dervish Bracers
6603	Dervish Tunic
6604	Dervish Cape
6605	Dervish Gloves
6607	Dervish Leggings
6608	Bright Armor
6609	Sage's Cloth
6610	Sage's Robe
6611	Sage's Sash
6612	Sage's Boots
6613	Sage's Bracers
6614	Sage's Cloak
6615	Sage's Gloves
6616	Sage's Pants
6617	Sage's Mantle
6619	Manual: The Path of Defense
6620	Elaborate Parchment
6621	Manual of Taunt
6622	Sword of Zeal
6623	Succubus Summoning Scroll
6624	Ken'zigla's Draught
6625	Dirt-caked Pendant
6626	Dogran's Pendant
6627	Mutant Scale Breastplate
6628	Raven's Claws
6629	Sporid Cape
6630	Seedcloud Buckler
6631	Living Root
6632	Feyscale Cloak
6633	Butcher's Slicer
6634	Ritual Salve
6635	Earth Sapta
6636	Fire Sapta
6637	Water Sapta
6638	Air Sapta
6640	Felstalker Hoof
6641	Haunting Blade
6642	Phantom Armor
6643	Bloated Smallfish
6644	Bloated Mackerel
6645	Bloated Mud Snapper
6646	Bloated Albacore
6647	Bloated Catfish
6648	Stoneskin Totem Scroll
6649	Searing Totem Scroll
6650	Healing Stream Totem Scroll
6651	Broken Wine Bottle
6652	Reagent Pouch
6653	Torch of the Dormant Flame
6654	Torch of the Eternal Flame
6655	Glowing Ember
6656	Rough Quartz
6657	Savory Deviate Delight
6658	Example Collar
6659	Scarab Trousers
6660	Julie's Dagger
6661	Recipe: Savory Deviate Delight
6662	Elixir of Giant Growth
6663	Recipe: Elixir of Giant Growth
6664	Voodoo Mantle
6665	Hexed Bracers
6666	Dredge Boots
6667	Engineer's Cloak
6668	Draftsman Boots
6669	Sacred Band
6670	Panther Armor
6671	Juggernaut Leggings
6672	Schematic: Flash Bomb
6675	Tempered Bracers
6676	Constable Buckler
6677	Spellcrafter Wand
6678	Band of Elven Grace
6679	Armor Piercer
6681	Thornspike
6682	Death Speaker Robes
6684	Snufflenose Command Stick
6685	Death Speaker Mantle
6686	Tusken Helm
6687	Corpsemaker
6688	Whisperwind Headdress
6689	Wind Spirit Staff
6690	Ferine Leggings
6691	Swinetusk Shank
6692	Pronged Reaver
6693	Agamaggan's Clutch
6694	Heart of Agamaggan
6695	Stygian Bone Amulet
6696	Nightstalker Bow
6697	Batwing Mantle
6698	Stone of Pierce
6707	Stone of Lapidis
6708	Stone of Goodman
6709	Moonglow Vest
6710	Pattern: Moonglow Vest
6711	Stone of Kurtz
6712	Practice Lock
6713	Ripped Pants
6714	Ez-Thro Dynamite
6715	Ruined Jumper Cables
6716	Schematic: EZ-Thro Dynamite
6717	Gaffer Jack
6718	Electropeller
6719	Windborne Belt
6720	Spirit Hunter Headdress
6721	Chestplate of Kor
6722	Beastial Manacles
6723	Medal of Courage
6724	Stone of Backus
6725	Marbled Buckler
6726	Razzeric's Customized Seatbelt
6727	Razzeric's Racing Grips
6728	Stone of Brownell
6729	Fizzle's Zippy Lighter
6730	Ironforge Chain
6731	Ironforge Breastplate
6732	Gnomish Mechanic's Gloves
6733	Ironforge Gauntlets
6734	Plans: Ironforge Chain
6735	Plans: Ironforge Breastplate
6736	Plans: Ironforge Gauntlets
6737	Dryleaf Pants
6738	Bleeding Crescent
6739	Cliffrunner's Aim
6740	Azure Sash
6741	Orcish War Sword
6742	Stonefist Girdle
6743	Sustaining Ring
6744	Gloves of Kapelan
6745	Swiftrunner Cape
6746	Basalt Buckler
6747	Enforcer Pauldrons
6748	Monkey Ring
6749	Tiger Band
6750	Snake Hoop
6751	Mourning Shawl
6752	Lancer Boots
6753	Feather Charm
6754	Large Moneybag
6755	A Small Container of Gems
6756	Jewelry Box
6757	Jaina's Signet Ring
6766	Flayed Demon Skin (old2)
6767	Tyranis' Pendant
6773	Gelkis Marauder Chain
6774	Uthek's Finger
6775	Tome of Divinity
6776	Tome of Valor
6777	Tome of Righteousness
6778	Tome of Justice
6779	Tome of Nobility
6780	Lilac Sash
6781	Bartleby's Mug
6782	Marshal Haggard's Badge
6783	Dead-tooth's Key
6784	Braced Handguards
6785	Powers of the Void
6786	Simple Dress
6787	White Woolen Dress
6788	Magram Hunter's Belt
6789	Ceremonial Centaur Blanket
6790	Ring of Calm
6791	Hellion Boots
6792	Sanguine Pauldrons
6793	Auric Bracers
6794	Stormfire Gauntlets
6795	White Swashbuckler's Shirt
6796	Red Swashbuckler's Shirt
6797	Eyepoker
6798	Blasting Hackbut
6799	Vejrek's Head
6800	Umbral Ore
6801	Baroque Apron
6802	Sword of Omen
6803	Prophetic Cane
6804	Windstorm Hammer
6805	Horn of Vorlus
6806	Dancing Flame
6807	Frog Leg Stew
6808	Elunite Ore
6809	Elura's Medallion
6810	Surena's Choker
6811	Aquadynamic Fish Lens
6812	Case of Elunite
6826	Brilliant Scale
6827	Box of Supplies
6828	Visionary Buckler
6829	Sword of Serenity
6830	Bonebiter
6831	Black Menace
6832	Cloak of Blight
6833	White Tuxedo Shirt
6834	Black Tuxedo
6835	Black Tuxedo Pants
6836	Dress Shoes
6837	Wedding Dress
6838	Scorched Spider Fang
6839	Charred Horn
6840	Galvanized Horn
6841	Vial of Phlogiston
6842	Furen's Instructions
6843	Cask of Scalder
6844	Burning Blood
6845	Burning Rock
6846	Defias Script
6847	Dark Iron Script
6848	Searing Coral
6849	Sunscorched Shell
6850	Bloodscalp Scalp
6851	Essence of the Exile
6852	Eternal Eye
6866	Symbol of Life
6887	Spotted Yellowtail
6888	Herb Baked Egg
6889	Small Egg
6890	Smoked Bear Meat
6891	Recipe: Herb Baked Egg
6892	Recipe: Smoked Bear Meat
6893	Workshop Key
6894	Whirlwind Heart
6895	Jordan's Smithing Hammer
6897	Manual: Path of the Berserker
6898	Orb of Soran'ruk
6899	Warlock Orb 35
6900	Enchanted Gold Bloodrobe
6901	Glowing Thresher Cape
6902	Bands of Serra'kis
6903	Gaze Dreamer Pants
6904	Bite of Serra'kis
6905	Reef Axe
6906	Algae Fists
6907	Tortoise Armor
6908	Ghamoo-ra's Bind
6909	Strike of the Hydra
6910	Leech Pants
6911	Moss Cinch
6912	Heartswood
6913	Heartswood Core
6914	Soran'ruk Fragment
6915	Large Soran'ruk Fragment
6916	Tome of Divinity
6926	Furen's Notes
6927	Big Will's Ear
6928	Bloodstone Choker
6929	Bath'rah's Parchment
6930	Rod of Channeling
6931	Moldy Tome
6947	Instant Poison
6948	Hearthstone
6949	Instant Poison II
6950	Instant Poison III
6951	Mind-numbing Poison II
6952	Thick Bear Fur
6953	Verigan's Fist
6966	Elunite Axe
6967	Elunite Sword
6968	Elunite Hammer
6969	Elunite Dagger
6970	Furen's Favor
6971	Fire Hardened Coif
6972	Fire Hardened Hauberk
6973	Fire Hardened Leggings
6974	Fire Hardened Gauntlets
6975	Whirlwind Axe
6976	Whirlwind Warhammer
6977	Whirlwind Sword
6978	Umbral Axe
6979	Haggard's Axe
6980	Haggard's Dagger
6981	Umbral Dagger
6982	Umbral Mace
6983	Haggard's Hammer
6984	Umbral Sword
6985	Haggard's Sword
6986	Crimson Lotus
6987	Fish Scale
6988	Felhunter Summoning Scroll
6989	Vial of Hatefury Blood
6990	Lesser Infernal Stone
6991	Smoldering Coal
6992	Jordan's Ore Shipment
6993	Jordan's Refined Ore Shipment
6994	Whitestone Oak Lumber
6995	Corrupted Kor Gem
6996	Jordan's Weapon Notes
6997	Tattered Manuscript
6998	Nimbus Boots
6999	Tome of the Cabal
7000	Heartwood Girdle
7001	Gravestone Scepter
7002	Arctic Buckler
7003	Beetle Clasps
7004	Prelacy Cape
7005	Skinning Knife
7006	Reconstructed Tome
7007	Backus' Phat Lewt
7026	Linen Belt
7027	Boots of Darkness
7046	Azure Silk Pants
7047	Hands of Darkness
7048	Azure Silk Hood
7049	Truefaith Gloves
7050	Silk Headband
7051	Earthen Vest
7052	Azure Silk Belt
7053	Azure Silk Cloak
7054	Robe of Power
7055	Crimson Silk Belt
7056	Crimson Silk Cloak
7057	Green Silken Shoulders
7058	Crimson Silk Vest
7059	Crimson Silk Shoulders
7060	Azure Shoulders
7061	Earthen Silk Belt
7062	Crimson Silk Pantaloons
7063	Crimson Silk Robe
7064	Crimson Silk Gloves
7065	Green Silk Armor
7067	Elemental Earth
7068	Elemental Fire
7069	Elemental Air
7070	Elemental Water
7071	Iron Buckle
7072	Naga Scale
7073	Broken Fang
7074	Chipped Claw
7075	Core of Earth
7076	Essence of Earth
7077	Heart of Fire
7078	Essence of Fire
7079	Globe of Water
7080	Essence of Water
7081	Breath of Wind
7082	Essence of Air
7083	Purified Kor Gem
7084	Pattern: Crimson Silk Shoulders
7085	Pattern: Azure Shoulders
7086	Pattern: Earthen Silk Belt
7087	Pattern: Crimson Silk Cloak
7088	Pattern: Crimson Silk Robe
7089	Pattern: Azure Silk Cloak
7090	Pattern: Green Silk Armor
7091	Pattern: Truefaith Gloves
7092	Pattern: Hands of Darkness
7093	Pattern: Boots of Darkness
7094	Driftwood Branch
7095	Bog Boots
7096	Plucked Feather
7097	Leg Meat
7098	Splintered Tusk
7099	Severed Pincer
7100	Sticky Ichor
7101	Bug Eye
7106	Zodiac Gloves
7107	Belt of the Stars
7108	Infantry Shield
7109	Pioneer Buckler
7110	Silver-thread Armor
7111	Nightsky Armor
7112	Aurora Armor
7113	Mistscape Armor
7114	Pattern: Azure Silk Gloves
7115	Heirloom Axe
7116	Heirloom Dagger
7117	Heirloom Hammer
7118	Heirloom Sword
7119	Twitching Antenna
7120	Ruga's Bulwark
7126	Smoky Iron Ingot
7127	Powdered Azurite
7128	Uncloven Satyr Hoof
7129	Brutal Gauntlets
7130	Brutal Helm
7131	Dragonmaw Shinbone
7132	Brutal Legguards
7133	Brutal Hauberk
7134	Sturdy Dragonmaw Shinbone
7135	Broken Dragonmaw Shinbone
7146	The Scarlet Key
7148	Goblin Jumper Cables
7166	Copper Dagger
7170	Twain Random Sword FOO
7187	VanCleef's Boots
7188	Stormwind Guard Shield
7189	Goblin Rocket Boots
7190	Scorched Rocket Boots
7191	Fused Wiring
7192	Schematic: Goblin Rocket Boots
7206	Mirror Lake Water Sample
7207	Jennea's Flask
7208	Tazan's Key
7209	Tazan's Satchel
7226	Mage-tastic Gizmonitor
7227	Balnir Snapdragons
7228	Tigule and Foror's Strawberry Ice Cream
7229	Explorer's Vest
7230	Smite's Mighty Hammer
7231	Astor's Letter of Introduction
7247	Chest of Containment Coffers
7249	Charged Rift Gem
7266	Ur's Treatise on Shadow Magic
7267	Pristine Spider Silk
7268	Xavian Water Sample
7269	Deino's Flask
7270	Laughing Sister's Hair
7271	Flawless Ivory Tusk
7272	Bolt Charged Bramble
7273	Witherbark Totem Stick
7274	Rituals of Power
7275	The Agamaggan Scrolls
7276	Handstitched Leather Cloak
7277	Handstitched Leather Bracers
7278	Light Leather Quiver
7279	Small Leather Ammo Pouch
7280	Rugged Leather Pants
7281	Light Leather Bracers
7282	Light Leather Pants
7283	Black Whelp Cloak
7284	Red Whelp Gloves
7285	Nimble Leather Gloves
7286	Black Whelp Scale
7287	Red Whelp Scale
7288	Pattern: Rugged Leather Pants
7289	Pattern: Black Whelp Cloak
7290	Pattern: Red Whelp Gloves
7291	Infernal Orb
7292	Filled Containment Coffer
7293	Dalaran Mana Gem
7294	Andron's Ledger
7295	Tazan's Logbook
7296	Extinguished Torch
7297	Morbent's Bane
7298	Blade of Cunning
7306	Fenwick's Head
7307	Flesh Eating Worm
7308	Cantation of Manifestation
7309	Dalaran Status Report
7326	Thun'grim's Axe
7327	Thun'grim's Dagger
7328	Thun'grim's Mace
7329	Thun'grim's Sword
7330	Infiltrator Buckler
7331	Phalanx Shield
7332	Regal Armor
7333	Overseer's Whistle
7334	Efflorescent Robe
7335	Grizzly Tunic
7336	Wildwood Chain
7337	The Rock
7338	Mood Ring
7339	Miniscule Diamond Ring
7340	Flawless Diamond Solitaire
7341	Cubic Zirconia Ring
7342	Silver Piffeny Band
7343	Bingles' Wrench
7344	Torch of Holy Flame
7345	Bingles' Screwdriver
7346	Bingles' Hammer
7347	Bingles' Cog Inverter
7348	Fletcher's Gloves
7349	Herbalist's Gloves
7350	Disciple's Bracers
7351	Disciple's Boots
7352	Earthen Leather Shoulders
7353	Elder's Padded Armor
7354	Elder's Boots
7355	Elder's Bracers
7356	Elder's Cloak
7357	Elder's Hat
7358	Pilferer's Gloves
7359	Heavy Earthen Gloves
7360	Pattern: Dark Leather Gloves
7361	Pattern: Herbalist's Gloves
7362	Pattern: Earthen Leather Shoulders
7363	Pattern: Pilferer's Gloves
7364	Pattern: Heavy Earthen Gloves
7365	Gnoam Sprecklesprocket
7366	Elder's Gloves
7367	Elder's Mantle
7368	Elder's Pants
7369	Elder's Robe
7370	Elder's Sash
7371	Heavy Quiver
7372	Heavy Leather Ammo Pouch
7373	Dusky Leather Leggings
7374	Dusky Leather Armor
7375	Green Whelp Armor
7376	Bingles' Blastencapper
7377	Frost Leather Cloak
7378	Dusky Bracers
7386	Green Whelp Bracers
7387	Dusky Belt
7388	Skull Key
7389	Venture Co. Ledger
7390	Dusky Boots
7391	Swift Boots
7392	Green Whelp Scale
7406	Infiltrator Cord
7407	Infiltrator Armor
7408	Infiltrator Shoulders
7409	Infiltrator Boots
7410	Infiltrator Bracers
7411	Infiltrator Cloak
7412	Infiltrator Gloves
7413	Infiltrator Cap
7414	Infiltrator Pants
7415	Dervish Spaulders
7416	Phalanx Bracers
7417	Phalanx Boots
7418	Phalanx Breastplate
7419	Phalanx Cloak
7420	Phalanx Headguard
7421	Phalanx Gauntlets
7422	Phalanx Girdle
7423	Phalanx Leggings
7424	Phalanx Spaulders
7425	Cyrik's Head
7426	Cerulean Ring
7427	Cerulean Talisman
7428	Shadowcat Hide
7429	Twilight Armor
7430	Twilight Robe
7431	Twilight Pants
7432	Twilight Cowl
7433	Twilight Gloves
7434	Twilight Boots
7435	Twilight Mantle
7436	Twilight Cape
7437	Twilight Cuffs
7438	Twilight Belt
7439	Sentinel Breastplate
7440	Sentinel Trousers
7441	Sentinel Cap
7442	Gyromast's Key
7443	Sentinel Gloves
7444	Sentinel Boots
7445	Sentinel Shoulders
7446	Sentinel Cloak
7447	Sentinel Bracers
7448	Sentinel Girdle
7449	Pattern: Dusky Leather Leggings
7450	Pattern: Green Whelp Armor
7451	Pattern: Green Whelp Bracers
7452	Pattern: Dusky Boots
7453	Pattern: Swift Boots
7454	Knight's Breastplate
7455	Knight's Legguards
7456	Knight's Headguard
7457	Knight's Gauntlets
7458	Knight's Boots
7459	Knight's Pauldrons
7460	Knight's Cloak
7461	Knight's Bracers
7462	Knight's Girdle
7463	Sentinel Buckler
7464	Glyphs of Summoning
7465	Knight's Crest
7466	Vermilion Band
7467	Vermilion Necklace
7468	Regal Robe
7469	Regal Leggings
7470	Regal Wizard Hat
7471	Regal Gloves
7472	Regal Boots
7473	Regal Mantle
7474	Regal Cloak
7475	Regal Cuffs
7476	Regal Sash
7477	Ranger Tunic
7478	Ranger Leggings
7479	Ranger Helm
7480	Ranger Gloves
7481	Ranger Boots
7482	Ranger Shoulders
7483	Ranger Cloak
7484	Ranger Wristguards
7485	Ranger Cord
7486	Captain's Breastplate
7487	Captain's Leggings
7488	Captain's Circlet
7489	Captain's Gauntlets
7490	Captain's Boots
7491	Captain's Shoulderguards
7492	Captain's Cloak
7493	Captain's Bracers
7494	Captain's Waistguard
7495	Captain's Buckler
7496	Field Plate Shield
7497	Ivory Band
7498	Top of Gelkak's Key
7499	Middle of Gelkak's Key
7500	Bottom of Gelkak's Key
7506	Gnomish Universal Remote
7507	Arcane Orb
7508	Ley Orb
7509	Manaweave Robe
7510	Lesser Spellfire Robes
7511	Astral Knot Robe
7512	Nether-lace Robe
7513	Ragefire Wand
7514	Icefury Wand
7515	Celestial Orb
7516	Tabetha's Instructions
7517	Gossamer Tunic
7518	Gossamer Robe
7519	Gossamer Pants
7520	Gossamer Headpiece
7521	Gossamer Gloves
7522	Gossamer Boots
7523	Gossamer Shoulderpads
7524	Gossamer Cape
7525	Gossamer Bracers
7526	Gossamer Belt
7527	Cabalist Chestpiece
7528	Cabalist Leggings
7529	Cabalist Helm
7530	Cabalist Gloves
7531	Cabalist Boots
7532	Cabalist Spaulders
7533	Cabalist Cloak
7534	Cabalist Bracers
7535	Cabalist Belt
7536	Champion's Wall Shield
7537	Gothic Shield
7538	Champion's Armor
7539	Champion's Leggings
7540	Champion's Helmet
7541	Champion's Gauntlets
7542	Champion's Greaves
7543	Champion's Pauldrons
7544	Champion's Cape
7545	Champion's Bracers
7546	Champion's Girdle
7547	Onyx Ring
7548	Onyx Choker
7549	Fairy's Embrace
7550	Warrior's Honor
7551	Entwined Opaline Talisman
7552	Falcon's Hook
7553	Band of the Unicorn
7554	Willow Branch
7555	Regal Star
7556	Twilight Orb
7557	Gossamer Rod
7558	Shimmering Stave
7559	Runic Cane
7560	Schematic: Gnomish Universal Remote
7561	Schematic: Goblin Jumper Cables
7566	Agamand Family Sword
7567	Agamand Family Axe
7568	Agamand Family Dagger
7569	Agamand Family Mace
7586	Tharnariun's Hope
7587	Thun'grim's Instructions
7606	Polar Gauntlets
7607	Sable Wand
7608	Seer's Fine Stein
7609	Elder's Amber Stave
7610	Aurora Sphere
7611	Mistscape Stave
7613	Pattern: Green Leather Armor
7626	Bundle of Furs
7627	Dolanaar Delivery
7628	Nondescript Letter
7629	Ukor's Burden
7646	Crate of Inn Supplies
7666	Shattered Necklace
7667	Talvash's Phial of Scrying
7668	Bloodstained Journal
7669	Shattered Necklace Ruby
7670	Shattered Necklace Sapphire
7671	Shattered Necklace Topaz
7672	Shattered Necklace Power Source
7673	Talvash's Enhancing Necklace
7674	Delivery to Mathias
7675	Defias Shipping Schedule
7676	Thistle Tea
7678	Recipe: Thistle Tea
7679	Shrike Bat Fang
7680	Jadespine Basilisk Scale
7681	Obsidian Golem Shard
7682	Torturing Poker
7683	Bloody Brass Knuckles
7684	Bloodmage Mantle
7685	Orb of the Forgotten Seer
7686	Ironspine's Eye
7687	Ironspine's Fist
7688	Ironspine's Ribcage
7689	Morbid Dawn
7690	Ebon Vise
7691	Embalmed Shroud
7708	Necrotic Wand
7709	Blighted Leggings
7710	Loksey's Training Stick
7711	Robe of Doan
7712	Mantle of Doan
7713	Illusionary Rod
7714	Hypnotic Blade
7715	Onin's Report
7716	Shattered Necklace
7717	Ravager
7718	Herod's Shoulder
7719	Raging Berserker's Helm
7720	Whitemane's Chapeau
7721	Hand of Righteousness
7722	Triune Amulet
7723	Mograine's Might
7724	Gauntlets of Divinity
7725	Tabard of the Scarlet Crusade
7726	Aegis of the Scarlet Commander
7727	Watchman Pauldrons
7728	Beguiler Robes
7729	Chesterfall Musket
7730	Cobalt Crusher
7731	Ghostshard Talisman
7733	Staff of Prehistoria
7734	Six Demon Bag
7735	Jannok's Rose
7736	Fight Club
7737	Sethir's Journal
7738	Evergreen Gloves
7739	Timberland Cape
7740	Gni'kiv Medallion
7741	The Shaft of Tsol
7742	Schematic: Gnomish Cloaking Device
7746	Explorers' League Commendation
7747	Vile Protector
7748	Forcestone Buckler
7749	Omega Orb
7750	Mantle of Woe
7751	Vorrel's Boots
7752	Dreamslayer
7753	Bloodspiller
7754	Harbinger Boots
7755	Flintrock Shoulders
7756	Dog Training Gloves
7757	Windweaver Staff
7758	Ruthless Shiv
7759	Archon Chestpiece
7760	Warchief Kilt
7761	Steelclaw Reaver
7766	Empty Brown Waterskin
7767	Empty Blue Waterskin
7768	Empty Red Waterskin
7769	Filled Brown Waterskin
7770	Filled Blue Waterskin
7771	Filled Red Waterskin
7786	Headsplitter
7787	Resplendent Guardian
7806	Lollipop
7807	Candy Bar
7808	Chocolate Square
7809	Easter Dress
7810	Vial of Purest Water
7811	Remaining Drops of Purest Water
7812	Corrupt Manifestation's Bracers
7813	Shard of Water
7846	Crag Coyote Fang
7847	Buzzard Gizzard
7848	Rock Elemental Shard
7866	Empty Thaumaturgy Vessel
7867	Vessel of Dragon's Blood
7868	Thieven' Kit
7869	Lucius's Lockbox
7870	Thaumaturgy Vessel Lockbox
7871	Token of Thievery
7872	Rusty Thieves' Tools
7886	Untranslated Journal
7887	Necklace and Gem Salvage
7888	Jarkal's Enhancing Necklace
7906	Horns of Nez'ra
7907	Certificate of Thievery
7908	Klaven Mortwake's Journal
7909	Aquamarine
7910	Star Ruby
7911	Truesilver Ore
7912	Solid Stone
7913	Barbaric Iron Shoulders
7914	Barbaric Iron Breastplate
7915	Barbaric Iron Helm
7916	Barbaric Iron Boots
7917	Barbaric Iron Gloves
7918	Heavy Mithril Shoulder
7919	Heavy Mithril Gauntlet
7920	Mithril Scale Pants
7921	Heavy Mithril Pants
7922	Steel Plate Helm
7923	Defias Tower Key
7924	Mithril Scale Bracers
7925	Mithril Scale Gloves
7926	Ornate Mithril Pants
7927	Ornate Mithril Gloves
7928	Ornate Mithril Shoulder
7929	Orcish War Leggings
7930	Heavy Mithril Breastplate
7931	Mithril Coif
7932	Mithril Scale Shoulders
7933	Heavy Mithril Boots
7934	Heavy Mithril Helm
7935	Ornate Mithril Breastplate
7936	Ornate Mithril Boots
7937	Ornate Mithril Helm
7938	Truesilver Gauntlets
7939	Truesilver Breastplate
7941	Heavy Mithril Axe
7942	Blue Glittering Axe
7943	Wicked Mithril Blade
7944	Dazzling Mithril Rapier
7945	Big Black Mace
7946	Runed Mithril Hammer
7947	Ebon Shiv
7948	Ninja Belt
7949	Ninja Pants
7950	Ninja Armor
7951	Ninja Gloves
7952	Ninja Boots
7953	Mask of Thero-Shan
7954	The Shatterer
7955	Copper Claymore
7956	Bronze Warhammer
7957	Bronze Greatsword
7958	Bronze Battle Axe
7959	Blight
7960	Truesilver Champion
7961	Phantom Blade
7963	Steel Breastplate
7964	Solid Sharpening Stone
7965	Solid Weightstone
7966	Solid Grinding Stone
7967	Mithril Shield Spike
7968	Southsea Treasure
7969	Mithril Spurs
7970	E.C.A.C.
7971	Black Pearl
7972	Ichor of Undeath
7973	Big-mouth Clam
7974	Zesty Clam Meat
7975	Plans: Heavy Mithril Pants
7976	Plans: Mithril Shield Spike
7977	Plans: Mithril Scale Gloves
7978	Plans: Barbaric Iron Shoulders
7979	Plans: Barbaric Iron Breastplate
7980	Plans: Barbaric Iron Helm
7981	Plans: Barbaric Iron Boots
7982	Plans: Barbaric Iron Gloves
7983	Plans: Ornate Mithril Pants
7984	Plans: Ornate Mithril Gloves
7985	Plans: Ornate Mithril Shoulder
7986	Plans: Ornate Mithril Breastplate
7987	Plans: Ornate Mithril Helm
7988	Plans: Ornate Mithril Boots
7989	Plans: Mithril Spurs
7990	Plans: Heavy Mithril Helm
7991	Plans: Mithril Scale Shoulders
7992	Plans: Blue Glittering Axe
7993	Plans: Dazzling Mithril Rapier
7994	Plans: Orcish War Leggings
7995	Plans: Mithril Scale Bracers
7996	Lucky Fishing Hat
7997	Red Defias Mask
8006	The Ziggler
8007	Mana Citrine
8008	Mana Ruby
8009	Dentrium Power Stone
8026	Garrett Family Treasure
8027	Krom Stoutarm's Treasure
8028	Plans: Runed Mithril Hammer
8029	Plans: Wicked Mithril Blade
8030	Plans: Ebon Shiv
8046	Kearnen's Journal
8047	Magenta Fungus Cap
8048	Emerald Dreamcatcher
8049	Gnarlpine Necklace
8050	Tallonkai's Jewel
8051	Flare Gun
8052	An'Alleum Power Stone
8053	Obsidian Power Source
8066	Fizzule's Whistle
8067	Crafted Light Shot
8068	Crafted Heavy Shot
8069	Crafted Solid Shot
8070	Reward Voucher
8071	Sizzle Stick
8072	Silixiz's Tower Key
8073	Cache of Zanzil's Altered Mixture
8074	Gallywix's Head
8075	Conjured Sourdough
8076	Conjured Sweet Roll
8077	Conjured Mineral Water
8078	Conjured Sparkling Water
8079	Conjured Crystal Water
8080	Light Plate Chestpiece
8081	Light Plate Belt
8082	Light Plate Boots
8083	Light Plate Bracers
8084	Light Plate Gloves
8085	Light Plate Pants
8086	Light Plate Shoulderpads
8087	Sample of Zanzil's Altered Mixture
8088	Platemail Belt
8089	Platemail Boots
8090	Platemail Bracers
8091	Platemail Gloves
8092	Platemail Helm
8093	Platemail Leggings
8094	Platemail Armor
8095	Hinott's Oil
8106	Hibernal Armor
8107	Hibernal Boots
8108	Hibernal Bracers
8109	Hibernal Cloak
8110	Hibernal Gloves
8111	Hibernal Mantle
8112	Hibernal Pants
8113	Hibernal Robe
8114	Hibernal Sash
8115	Hibernal Cowl
8116	Heraldic Belt
8117	Heraldic Boots
8118	Heraldic Bracers
8119	Heraldic Breastplate
8120	Heraldic Cloak
8121	Heraldic Gloves
8122	Heraldic Headpiece
8123	Heraldic Leggings
8124	Heraldic Spaulders
8125	Myrmidon's Bracers
8126	Myrmidon's Breastplate
8127	Myrmidon's Cape
8128	Myrmidon's Gauntlets
8129	Myrmidon's Girdle
8130	Myrmidon's Greaves
8131	Myrmidon's Helm
8132	Myrmidon's Leggings
8133	Myrmidon's Pauldrons
8134	Myrmidon's Defender
8135	Chromite Shield
8136	Gargantuan Tumor
8137	Chromite Bracers
8138	Chromite Chestplate
8139	Chromite Gauntlets
8140	Chromite Girdle
8141	Chromite Greaves
8142	Chromite Barbute
8143	Chromite Legplates
8144	Chromite Pauldrons
8146	Wicked Claw
8147	Tiny Copper Key
8148	Tiny Silver Key
8149	Voodoo Charm
8150	Deeprock Salt
8151	Flask of Mojo
8152	Flask of Big Mojo
8153	Wildvine
8154	Scorpid Scale
8155	Sathrah's Sacrifice
8156	Jouster's Wristguards
8157	Jouster's Chestplate
8158	Jouster's Gauntlets
8159	Jouster's Girdle
8160	Jouster's Greaves
8161	Jouster's Visor
8162	Jouster's Legplates
8163	Jouster's Pauldrons
8165	Worn Dragonscale
8167	Turtle Scale
8168	Jet Black Feather
8169	Thick Hide
8170	Rugged Leather
8171	Rugged Hide
8172	Cured Thick Hide
8173	Thick Armor Kit
8174	Comfortable Leather Hat
8175	Nightscape Tunic
8176	Nightscape Headband
8177	Practice Sword
8178	Training Sword
8179	Cadet's Bow
8180	Hunting Bow
8181	Hunting Rifle
8182	Pellet Rifle
8183	Precision Bow
8184	Firestarter
8185	Turtle Scale Leggings
8186	Dire Wand
8187	Turtle Scale Gloves
8188	Explosive Shotgun
8189	Turtle Scale Breastplate
8190	Hanzo Sword
8191	Turtle Scale Helm
8192	Nightscape Shoulders
8193	Nightscape Pants
8194	Goblin Nutcracker
8195	Nightscape Cloak
8196	Ebon Scimitar
8197	Nightscape Boots
8198	Turtle Scale Bracers
8199	Battlefield Destroyer
8200	Big Voodoo Robe
8201	Big Voodoo Mask
8202	Big Voodoo Pants
8203	Tough Scorpid Breastplate
8204	Tough Scorpid Gloves
8205	Tough Scorpid Bracers
8206	Tough Scorpid Leggings
8207	Tough Scorpid Shoulders
8208	Tough Scorpid Helm
8209	Tough Scorpid Boots
8210	Wild Leather Shoulders
8211	Wild Leather Vest
8212	Wild Leather Leggings
8213	Wild Leather Boots
8214	Wild Leather Helmet
8215	Wild Leather Cloak
8216	Big Voodoo Cloak
8217	Quickdraw Quiver
8218	Thick Leather Ammo Pouch
8223	Blade of the Basilisk
8224	Silithid Ripper
8225	Tainted Pierce
8226	The Butcher
8243	Scooby Snack
8244	Flawless Draenethyst Sphere
8245	Imperial Red Tunic
8246	Imperial Red Boots
8247	Imperial Red Bracers
8248	Imperial Red Cloak
8249	Imperial Red Gloves
8250	Imperial Red Mantle
8251	Imperial Red Pants
8252	Imperial Red Robe
8253	Imperial Red Sash
8254	Imperial Red Circlet
8255	Serpentskin Girdle
8256	Serpentskin Boots
8257	Serpentskin Bracers
8258	Serpentskin Armor
8259	Serpentskin Cloak
8260	Serpentskin Gloves
8261	Serpentskin Helm
8262	Serpentskin Leggings
8263	Serpentskin Spaulders
8264	Ebonhold Wristguards
8265	Ebonhold Armor
8266	Ebonhold Cloak
8267	Ebonhold Gauntlets
8268	Ebonhold Girdle
8269	Ebonhold Boots
8270	Ebonhold Helmet
8271	Ebonhold Leggings
8272	Ebonhold Shoulderpads
8273	Valorous Wristguards
8274	Valorous Chestguard
8275	Ebonhold Buckler
8276	Valorous Gauntlets
8277	Valorous Girdle
8278	Valorous Greaves
8279	Valorous Helm
8280	Valorous Legguards
8281	Valorous Pauldrons
8282	Valorous Shield
8283	Arcane Armor
8284	Arcane Boots
8285	Arcane Bands
8286	Arcane Cloak
8287	Arcane Gloves
8288	Arcane Pads
8289	Arcane Leggings
8290	Arcane Robe
8291	Arcane Sash
8292	Arcane Cover
8293	Traveler's Belt
8294	Traveler's Boots
8295	Traveler's Bracers
8296	Traveler's Jerkin
8297	Traveler's Cloak
8298	Traveler's Gloves
8299	Traveler's Helm
8300	Traveler's Leggings
8301	Traveler's Spaulders
8302	Hero's Bracers
8303	Hero's Breastplate
8304	Hero's Cape
8305	Hero's Gauntlets
8306	Hero's Belt
8307	Hero's Boots
8308	Hero's Band
8309	Hero's Leggings
8310	Hero's Pauldrons
8311	Alabaster Plate Vambraces
8312	Alabaster Breastplate
8313	Hero's Buckler
8314	Alabaster Plate Gauntlets
8315	Alabaster Plate Girdle
8316	Alabaster Plate Greaves
8317	Alabaster Plate Helmet
8318	Alabaster Plate Leggings
8319	Alabaster Plate Pauldrons
8320	Alabaster Shield
8343	Heavy Silken Thread
8344	Silvery Spinnerets
8345	Wolfshead Helm
8346	Gauntlets of the Sea
8347	Dragonscale Gauntlets
8348	Helm of Fire
8349	Feathered Breastplate
8350	The 1 Ring
8363	Shaman Voodoo Charm
8364	Mithril Head Trout
8365	Raw Mithril Head Trout
8366	Bloated Trout
8367	Dragonscale Breastplate
8368	Thick Wolfhide
8383	Plain Letter
8384	Pattern: Comfortable Leather Hat
8385	Pattern: Turtle Scale Gloves
8386	Pattern: Big Voodoo Robe
8387	Pattern: Big Voodoo Mask
8388	Pattern: Nightscape Cloak
8389	Pattern: Big Voodoo Pants
8390	Pattern: Big Voodoo Cloak
8391	Snickerfang Jowl
8392	Blasted Boar Lung
8393	Scorpok Pincer
8394	Basilisk Brain
8395	Pattern: Tough Scorpid Breastplate
8396	Vulture Gizzard
8397	Pattern: Tough Scorpid Bracers
8398	Pattern: Tough Scorpid Gloves
8399	Pattern: Tough Scorpid Boots
8400	Pattern: Tough Scorpid Shoulders
8401	Pattern: Tough Scorpid Leggings
8402	Pattern: Tough Scorpid Helm
8403	Pattern: Wild Leather Shoulders
8404	Pattern: Wild Leather Vest
8405	Pattern: Wild Leather Helmet
8406	Pattern: Wild Leather Boots
8407	Pattern: Wild Leather Leggings
8408	Pattern: Wild Leather Cloak
8409	Pattern: Nightscape Shoulders
8410	R.O.I.D.S.
8411	Lung Juice Cocktail
8412	Ground Scorpok Assay
8423	Cerebral Cortex Compound
8424	Gizzard Gum
8425	Parrot Droppings
8426	Large Ruffled Feather
8427	Mutilated Rat Carcass
8428	Laden Dew Gland
8429	Punctured Dew Gland
8430	Empty Dew Gland
8431	Spool of Light Chartreuse Silk Thread
8432	Eau de Mixilpixil
8443	Gahz'ridian Ornament
8444	Executioner's Key
8463	Warchief's Orders
8483	Wastewander Water Pouch
8484	Gadgetzan Water Co. Care Package
8485	Cat Carrier (Bombay)
8486	Cat Carrier (Cornish Rex)
8487	Cat Carrier (Orange Tabby)
8488	Cat Carrier (Silver Tabby)
8489	Cat Carrier (White Kitten)
8490	Cat Carrier (Siamese)
8491	Cat Carrier (Black Tabby)
8492	Parrot Cage (Green Wing Macaw)
8493	Weegli's Barrel
8494	Parrot Cage (Hyacinth Macaw)
8495	Parrot Cage (Senegal)
8496	Parrot Cage (Cockatiel)
8497	Rabbit Crate (Snowshoe)
8498	Tiny Emerald Whelpling
8499	Tiny Crimson Whelpling
8500	Great Horned Owl
8501	Hawk Owl
8502	Bronze Lotterybox
8503	Heavy Bronze Lotterybox
8504	Iron Lotterybox
8505	Heavy Iron Lotterybox
8506	Mithril Lotterybox
8507	Heavy Mithril Lotterybox
8508	Large Fin
8523	Field Testing Kit
8524	Model 4711-FTZ Power Source
8525	Zinge's Purchase Order
8526	Violet Tragan
8527	Sealed Field Testing Kit
8528	Violet Powder
8529	Noggenfogger Elixir
8543	Underwater Mushroom Cap
8544	Mageweave Bandage
8545	Heavy Mageweave Bandage
8546	Powerful Smelling Salts
8548	Divino-matic Rod
8563	Red Mechanostrider
8564	Hippogryph Egg
8583	Horn of the Skeletal Mount
8584	Untapped Dowsing Widget
8585	Tapped Dowsing Widget
8586	Whistle of the Mottled Red Raptor
8587	Centipaar Insect Parts
8588	Whistle of the Emerald Raptor
8591	Whistle of the Turquoise Raptor
8592	Whistle of the Violet Raptor
8593	Scrimshank's Surveying Gear
8594	Insect Analysis Report
8595	Blue Mechanostrider
8603	Thistleshrub Dew
8623	OOX-17/TN Distress Beacon
8624	Red Sparkler
8625	White Sparkler
8626	Blue Sparkler
8627	Reins of the Night saber
8628	Reins of the Spotted Nightsaber
8629	Reins of the Striped Nightsaber
8630	Reins of the Bengal Tiger
8631	Reins of the Striped Frostsaber
8632	Reins of the Spotted Frostsaber
8633	Reins of the Leopard
8643	Extraordinary Egg
8644	Fine Egg
8645	Ordinary Egg
8646	Bad Egg
8647	Egg Crate
8663	Mithril Insignia
8683	Clara's Fresh Apple
8684	Hinterlands Honey Ripple
8685	Dran's Ripple Delivery
8686	Mithril Pendant
8687	Sealed Description of Thredd's Visitor
8703	Signet of Expertise
8704	OOX-09/HL Distress Beacon
8705	OOX-22/FE Distress Beacon
8707	Gahz'rilla's Electrified Scale
8708	Hammer of Expertise
8723	Caliph Scorpidsting's Head
8724	Rin'ji's Secret
8743	Book of Mark of the Wild
8744	Book of Wrath
8746	Interlaced Cowl
8747	Hardened Leather Helm
8748	Double Mail Coif
8749	Crochet Hat
8750	Thick Leather Hat
8751	Overlinked Coif
8752	Laminated Scale Circlet
8753	Smooth Leather Helmet
8754	Twill Cover
8755	Light Plate Helmet
8756	Book of Regrowth II
8757	Book of Starfire
8758	Book of Remove Curse
8759	Book of Regrowth III
8760	Book of Abolish Poison
8761	Book of Starfire II
8762	Book of Rejuvenation V
8763	Book of Moonfire V
8764	Book of Faerie Fire II
8765	Book of Regrowth IV
8766	Morning Glory Dew
8768	Book of Starfire III
8769	Book of Thorns IV
8770	Book of Moonfire VI
8771	Book of Rejuvenation VI
8772	Book of Regrowth V
8773	Book of Entangling Roots V
8774	Book of Healing Touch VII
8775	Book of Tranquility II
8776	Book of Mark of the Wild VI
8777	Book of Moonfire IX
8778	Book of Rejuvenation VII
8779	Book of Faerie Fire III
8780	Book of Starfire V
8781	Book of Regrowth VII
8782	Book of Thorns V
8783	Book of Healing Touch IX
8784	Book of Wrath VII
8785	Book of Rejuvenation IX
8786	Book of Tranquility III
8787	Book of Soothe Animal
8788	Book of Soothe Animal II
8789	Book of Soothe Animal III
8790	Book of Faerie Fire IV
8791	Book of Regrowth VIII
8792	Book of Thorns VI
8793	Book of Wrath VIII
8794	Book of Healing Touch X
8795	Book of Entangling Roots VI
8796	Book of Moonfire X
8797	Book of Rejuvenation X
8798	Book of Starfire VI
8799	Book of Mark of the Wild VII
8800	Book of Regrowth IX
8801	Book of Tranquility IV
8802	Tome of Arcane Intellect
8804	Tome of Arcane Explosion
8805	Tome of Detect Magic
8806	Tome of Remove Lesser Curse
8807	Tome of Amplify Magic
8808	Tome of Mana Shield
8809	Tome of Sleep
8810	Tome of Sleep II
8811	Tome of Scorch
8812	Tome of Arcane Explosion II
8813	Tome of Dampen Magic II
8814	Tome of Fireball V
8815	Tome of Cone of Cold
8816	Tome of Frostbolt V
8818	Tome of Mana Shield II
8819	Tome of Scorch II
8820	Tome of Fire Ward II
8821	Tome of Amplify Magic II
8822	Tome of Arcane Explosion III
8823	Tome of Fire Blast IV
8824	Tome of Fireball VI
8825	Tome of Frost Ward III
8826	Tome of Arcane Missiles IV
8827	Elixir of Water Walking
8828	Tome of Frostbolt VI
8829	Tome of Cone of Cold II
8830	Tome of Scorch III
8831	Purple Lotus
8832	Tome of Blizzard III
8833	Tome of Mana Shield III
8834	Tome of Dampen Magic III
8835	Tome of Fireball VII
8836	Arthas' Tears
8837	Tome of Arcane Explosion V
8838	Sungrass
8839	Blindweed
8840	Renegade Boots
8841	Tome of Fire Blast V
8842	Tome of Frostbolt VII
8843	Tome of Fire Ward III
8844	Tome of Sleep III
8845	Ghost Mushroom
8846	Gromsblood
8847	Tome of Scorch V
8848	Tome of Flamestrike IV
8849	Tome of Arcane Missiles V
8850	Tome of Conjure Water V
8851	Tome of Fireball VIII
8852	Tome of Arcane Intellect IV
8853	Tome of Conjure Food V
8854	Tome of Cone of Cold III
8855	Tome of Amplify Magic III
8856	Tome of Frostbolt VIII
8857	Tome of Blizzard IV
8858	Tome of Mana Shield IV
8859	Tome of Fire Blast VI
8860	Tome of Fireball IX
8861	Tome of Conjure Mana Gem III
8862	Tome of Arcane Missiles VI
8863	Tome of Dampen Magic IV
8864	Tome of Flamestrike V
8865	Tome of Ice Armor III
8866	Tome of Cone of Cold IV
8867	Tome of Frostbolt IX
8868	Tome of Conjure Water VI
8869	Tome of Fire Ward IV
8871	Tome of Conjure Food VI
8872	Tome of Blizzard V
8873	Tome of Mana Shield V
8874	Tome of Scorch VI
8875	Tome of Frost Ward IV
8876	Tome of Frost Ward II
8877	Tome of Fireball X
8878	Tome of Fire Blast VII
8879	Tome of Frost Nova IV
8880	Tome of Arcane Explosion VI
8881	Tome of Khadgar's Unlocking IV
8882	Tome of Amplify Magic IV
8883	Tome of Arcane Intellect V
8884	Tome of Frostbolt X
8885	Tome of Arcane Missiles VII
8886	Tome of Flamestrike VI
8887	Tome of Scorch VII
8888	Tome of Cone of Cold V
8889	Tome of Conjure Mana Gem IV
8890	Tome of Fireball XI
8891	Tome of Ice Armor IV
8892	Tome of Conjure Water VII
8893	Tome of Sleep IV
8894	Tome of Dampen Magic V
8895	Tome of Blizzard VI
8896	Tome of Mana Shield VI
8897	Tome of Fire Ward V
8898	Tome of Arcane Explosion IV
8899	Tome of Scorch IV
8900	Book of Entangling Roots IV
8901	Book of Healing Touch VIII
8902	Book of Mark of the Wild V
8903	Book of Moonfire VII
8904	Book of Moonfire VIII
8905	Book of Regrowth VI
8906	Book of Rejuvenation VIII
8907	Book of Starfire IV
8909	Libram: Holy Strike II
8910	Libram: Lay on Hands
8911	Libram: Fist of Justice
8912	Libram: Crusader Strike
8913	Libram: Holy Strike III
8914	Libram: Crusader Strike II
8915	Libram: Holy Strike IV
8916	Libram: Fist of Justice II
8917	Libram: Lay on Hands II
8918	Libram: Seal of Protection III
8919	Libram: Holy Strike V
8920	Libram: Crusader Strike III
8921	Libram: Fist of Justice III
8922	Libram: Holy Strike VI
8923	Essence of Agony
8924	Dust of Deterioration
8925	Crystal Vial
8926	Instant Poison IV
8927	Instant Poison V
8928	Instant Poison VI
8929	Libram: Exorcism IV
8930	Libram: Seal of Righteousness IV
8931	Libram: Crusader Strike IV
8932	Alterac Swiss
8933	Libram: Holy Light VII
8934	Libram: Holy Strike VII
8935	Libram: Judgement II
8936	Libram: Seal of Wrath III
8937	Libram: Lay on Hands III
8938	Libram: Turn Undead III
8939	Libram: Exorcism V
8940	Libram: Fist of Justice IV
8941	Libram: Holy Light VIII
8942	Libram: Seal of Righteousness V
8943	Libram: Holy Strike VIII
8944	Libram: Crusader Strike V
8945	Libram: Judgement III
8947	Libram: Exorcism VI
8948	Dried King Bolete
8949	Elixir of Agility
8950	Homemade Cherry Pie
8951	Elixir of Greater Defense
8952	Roasted Quail
8953	Deep Fried Plantains
8954	Codex of Holy Word: Fortitude
8955	Codex of Fade
8956	Oil of Immolation
8957	Spinefin Halibut
8958	Codex of Mind Blast
8959	Raw Spinefin Halibut
8960	Codex of Cure Disease
8961	Codex of Psychic Scream
8962	Codex of Mind Blast II
8963	Codex of Mind Soothe
8964	Codex of Flash Heal
8965	Codex of Fade II
8966	Codex of Shackle Undead
8967	Codex of Mind Blast III
8968	Codex of Mana Burn
8969	Codex of Flash Heal II
8971	Codex of Psychic Scream II
8972	Codex of Mind Blast IV
8973	Thick Yeti Hide
8974	Codex of Mind Control
8975	Codex of Fade III
8976	Codex of Abolish Disease
8977	Codex of Mana Burn II
8978	Codex of Flash Heal III
8980	Codex of Mind Blast V
8981	Codex of Mind Soothe II
8983	Codex of Flash Heal IV
8984	Deadly Poison III
8985	Deadly Poison IV
8986	Codex of Shackle Undead II
8987	Codex of Holy Protection II
8988	Codex of Mana Burn III
8989	Codex of Fade IV
8990	Codex of Mind Blast VI
8991	Codex of Inner Fire IV
8992	Codex of Psychic Scream III
8993	Codex of Shadow Protection II
8994	Codex of Shadow Word: Pain VI
8995	Codex of Holy Word: Shield VII
8996	Codex of Resurrection III
8997	Codex of Mind Control II
8998	Codex of Mind Vision II
8999	Codex of Flash Heal V
9000	Codex of Renew VII
9001	Codex of Greater Heal II
9002	Codex of Mind Blast VII
9003	Codex of Holy Smite VII
9004	Codex of Holy Word: Fortitude V
9005	Codex of Mana Burn IV
9006	Codex of Holy Word: Shield VIII
9007	Codex of Fade V
9008	Codex of Prayer of Healing III
9009	Codex of Inner Fire V
9010	Codex of Flash Heal VI
9011	Codex of Shadow Word: Pain VII
9012	Codex of Renew VIII
9013	Codex of Greater Heal III
9014	Codex of Mind Soothe III
9015	Codex of Mind Blast VIII
9016	Codex of Holy Smite VIII
9017	Codex of Holy Protection III
9018	Codex of Holy Word: Shield IX
9019	Codex of Renew IX
9020	Codex of Psychic Scream IV
9021	Codex of Mana Burn V
9022	Codex of Flash Heal VII
9023	Codex of Shadow Protection III
9024	Codex of Mind Control III
9025	Codex of Greater Heal IV
9026	Codex of Resurrection IV
9027	Codex of Mind Blast IX
9028	Codex of Shadow Word: Pain VIII
9029	Codex of Fade VI
9030	Restorative Potion
9031	Codex of Shackle Undead III
9032	Codex of Prayer of Healing IV
9033	Codex of Inner Fire VI
9034	Codex of Holy Word: Fortitude VI
9035	Codex of Holy Word: Shield X
9036	Magic Resistance Potion
9037	Tablet of Rockbiter Weapon
9039	Tablet of Earth Shock
9040	Tablet of Healing Wave II
9041	Tablet of Earthbind Totem
9043	Tablet of Stoneclaw Totem
9044	Tablet of Earth Shock II
9046	Tablet of Strength of Earth Totem
9047	Tablet of Flame Shock
9048	Tablet of Rebirth
9049	Tablet of Fire Nova Totem
9050	Tablet of Healing Wave III
9051	Tablet of Earth Shock III
9052	Tablet of Stoneskin Totem II
9053	Tablet of Rockbiter Weapon II
9054	Tablet of Flame Shock II
9055	Tablet of Stoneclaw Totem II
9056	Tablet of Healing Wave IV
9057	Tablet of Frostbrand Weapon
9058	Tablet of Frost Shock
9059	Tablet of Flametongue Weapon
9060	Inlaid Mithril Cylinder
9061	Goblin Rocket Fuel
9062	Tablet of Cure Disease
9063	Tablet of Poison Cleansing Totem
9064	Tablet of Flametongue Weapon II
9065	Tablet of Fire Nova Totem II
9066	Tablet of Frost Resistance Totem
9067	Tablet of Strength of Earth Totem II
9068	Tablet of Stoneskin Totem III
9069	Tablet of Earth Shock IV
9070	Tablet of Healing Wave V
9071	Tablet of Mana Font Totem
9072	Tablet of Flametongue Totem
9073	Tablet of Windfury Weapon
9074	Tablet of Flame Shock III
9075	Tablet of Fire Resistance Totem
9076	Tablet of Magma Totem
9077	Tablet of Stoneclaw Totem III
9078	Tablet of Grounding Totem
9079	Tablet of Lightning Shock
9080	Tablet of Nature Resistance Totem
9081	Tablet of Healing Stream Totem II
9082	Tablet of Rockbiter Weapon III
9083	Tablet of Searing Totem III
9084	Tablet of Windfury Totem
9085	Tablet of Fire Nova Totem III
9086	Tablet of Healing Wave VI
9087	Tablet of Purge II
9088	Gift of Arthas
9089	Tablet of Frost Shock II
9090	Tablet of Frostbrand Weapon II
9091	Tablet of Stoneskin Totem IV
9093	Tablet of Mana Font Totem II
9094	Tablet of Flametongue Weapon III
9095	Tablet of Earth Shock V
9096	Tablet of Disease Cleansing Totem
9097	Tablet of Magma Totem II
9098	Tablet of Strength of Earth Totem III
9099	Tablet of Stoneclaw Totem IV
9100	Tablet of Lightning Shield V
9101	Tablet of Windfury Weapon II
9102	Tablet of Chain Lightning II
9103	Tablet of Healing Stream Totem III
9104	Tablet of Searing Totem IV
9105	Tablet of Healing Wave VII
9123	Tablet of Lightning Bolt VI
9124	Tablet of Lightning Shock II
9125	Tablet of Grace of Air Totem
9126	Tablet of Flametongue Totem II
9127	Tablet of Fire Resistance Totem II
9128	Tablet of Fire Nova Totem IV
9129	Tablet of Rockbiter Weapon IV
9130	Tablet of Nature Resistance Totem II
9131	Tablet of Stoneskin Totem V
9132	Tablet of Molten Blast VI
9133	Tablet of Chain Heal II
9134	Tablet of Windfury Totem II
9135	Tablet of Frost Shock III
9136	Tablet of Mana Font Totem III
9137	Tablet of Lightning Shield VI
9138	Tablet of Magma Totem III
9139	Tablet of Frostbrand Weapon III
9140	Tablet of Chain Lightning III
9141	Tablet of Stoneclaw Totem V
9142	Tablet of Earth Shock VI
9143	Tablet of Healing Wave VIII
9144	Wildvine Potion
9145	Tablet of Lightning Bolt VII
9146	Tablet of Searing Totem V
9147	Tablet of Healing Stream Totem IV
9148	Tablet of Flametongue Weapon IV
9149	Philosopher's Stone
9150	Tablet of Strength of Earth Totem IV
9151	Tablet of Flame Shock V
9152	Tablet of Fire Nova Totem V
9153	Rig Blueprints
9154	Elixir of Detect Undead
9155	Arcane Elixir
9156	Tablet of Molten Blast VII
9157	Tablet of Chain Heal III
9158	Tablet of Frost Resistance Totem III
9159	Tablet of Lightning Shock III
9160	Tablet of Windfury Weapon III
9161	Tablet of Stoneskin Totem VI
9162	Tablet of Lightning Shield VII
9164	Tablet of Grace of Air Totem II
9165	Tablet of Flametongue Totem III
9166	Tablet of Mana Font Totem IV
9167	Tablet of Chain Lightning IV
9168	Tablet of Healing Wave IX
9169	Tablet of Lightning Bolt VIII
9170	Tablet of Fire Resistance Totem III
9171	Tablet of Magma Totem IV
9172	Invisibility Potion
9173	Goblin Transponder
9174	Tablet of Frost Shock IV
9175	Tablet of Rockbiter Weapon V
9176	Tablet of Stoneclaw Totem VI
9177	Tablet of Earth Shock VII
9178	Tablet of Nature Resistance Totem III
9179	Elixir of Greater Intellect
9180	Tablet of Windfury Totem III
9181	Tablet of Healing Stream Totem V
9182	Tablet of Searing Totem VI
9183	Tablet of Chain Heal
9184	Tablet of Flame Shock IV
9185	Tablet of Frost Resistance Totem II
9186	Mind-numbing Poison III
9187	Elixir of Greater Agility
9188	Tablet of Searing Totem II
9189	Shay's Bell
9190	Grimoire of Immolate
9191	Grimoire of Curse of Weakness
9192	Grimoire of Corruption
9193	Grimoire of Life Tap
9194	Grimoire of Curse of Agony
9195	Grimoire of Drain Soul
9197	Elixir of Dream Vision
9198	Grimoire of Health Funnel
9199	Grimoire of Curse of Recklessness
9200	Grimoire of Curse of Weakness II
9201	Grimoire of Corruption II
9202	Grimoire of Life Tap II
9203	Grimoire of Ritual of Summoning
9204	Grimoire of Health Funnel II
9205	Grimoire of Curse of Agony II
9206	Elixir of Giants
9207	Grimoire of Create Bloodstone II
9208	Grimoire of Drain Soul II
9209	Grimoire of Curse of Weakness III
9210	Ghost Dye
9211	Grimoire of Curse of Recklessness II
9212	Grimoire of Shadow Bolt V
9214	Grimoire of Inferno
9215	Grimoire of Health Funnel III
9216	Grimoire of Corruption III
9217	Grimoire of Life Tap III
9218	Grimoire of Enslave Demon
9219	Grimoire of Hellfire
9221	Grimoire of Curse of Agony III
9222	Grimoire of Curse of the Elements
9223	Grimoire of Curse of Weakness IV
9224	Elixir of Demonslaying
9225	Grimoire of Shadow Bolt VI
9226	Grimoire of Health Funnel IV
9227	Grimoire of Drain Soul III
9228	Grimoire of Create Bloodstone III
9229	Grimoire of Life Drain IV
9230	Grimoire of Curse of Recklessness III
9231	Grimoire of Corruption IV
9233	Elixir of Detect Demon
9234	Tiara of the Deep
9235	Pratt's Letter
9236	Jangdor's Letter
9237	Woodpaw Gnoll Mane
9238	Uncracked Scarab Shell
9240	Mallet of Zul'Farrak
9241	Sacred Mallet
9242	Ancient Tablet
9243	Shriveled Heart
9244	Stoley's Shipment
9245	Stoley's Bottle
9246	Firebeard's Head
9247	Hatecrest Naga Scale
9248	Mysterious Relic
9249	Captain's Key
9250	Ship Schedule
9251	Upper Map Fragment
9252	Lower Map Fragment
9253	Middle Map Fragment
9254	Cuergo's Treasure Map
9255	Lahassa Essence
9256	Imbel Essence
9257	Samha Essence
9258	Byltan Essence
9259	Troll Tribal Necklace
9260	Volatile Rum
9261	Lead Ore
9262	Black Vitriol
9263	Troyas' Stave
9264	Elixir of Shadow Power
9265	Cuergo's Hidden Treasure
9266	Woodpaw Battle Plans
9275	Cuergo's Key
9276	Pirate's Footlocker
9277	Techbot's Memory Core
9278	Essential Artificial
9279	White Punch Card
9280	Yellow Punch Card
9281	Red Punch Card
9282	Blue Punch Card
9283	Empty Leaden Collection Phial
9284	Full Leaden Collection Phial
9285	Field Plate Vambraces
9286	Field Plate Armor
9287	Field Plate Gauntlets
9288	Field Plate Girdle
9289	Field Plate Boots
9290	Field Plate Helmet
9291	Field Plate Leggings
9292	Field Plate Pauldrons
9293	Recipe: Magic Resistance Potion
9294	Recipe: Wildvine Potion
9295	Recipe: Invisibility Potion
9296	Recipe: Gift of Arthas
9297	Recipe: Elixir of Dream Vision
9298	Recipe: Elixir of Giants
9299	Thermaplugg's Safe Combination
9300	Recipe: Elixir of Demonslaying
9301	Recipe: Elixir of Shadow Power
9302	Recipe: Ghost Dye
9303	Recipe: Philosopher's Stone
9304	Recipe: Transmute Iron to Gold
9305	Recipe: Transmute Mithril to Truesilver
9306	Stave of Equinex
9307	A Sparkling Stone
9308	Grime-Encrusted Object
9309	Robo-mechanical Guts
9311	Default Stationery
9312	Blue Firework
9313	Green Firework
9314	Red Streaks Firework
9315	Yellow Rose Firework
9316	Prismatic Punch Card
9317	Red, White and Blue Firework
9318	Red Firework
9319	Nimboya's Laden Pike
9320	Witherbark Skull
9321	Venom Bottle
9322	Undamaged Venom Sac
9323	Gadrin's Parchment
9324	Shadra's Venom
9325	A Small Stave
9326	Grime-Encrusted Ring
9327	Security DELTA Data Access Card
9328	Super Snapper FX
9329	A Short Note
9330	Snapshot of Gammerita
9331	Feralas: A History
9332	Crusted Bandages
9333	Tarnished Silver Necklace
9334	Cracked Pottery
9335	Broken Obsidian Club
9336	Gold-capped Troll Tusk
9355	Hoop Earring
9356	A Wooden Leg
9357	A Parrot Skeleton
9358	A Head Rag
9359	Wirt's Third Leg
9360	Cuergo's Gold
9361	Cuergo's Gold with Worm
9362	Brilliant Gold Ring
9363	Sparklematic-Wrapped Box
9364	Heavy Leaden Collection Phial
9365	High Potency Radioactive Fallout
9366	Golden Scale Gauntlets
9367	Plans: Golden Scale Gauntlets
9368	Jer'kai's Signet Ring
9369	Iridescent Sprite Darter Wing
9370	Gordunni Scroll
9371	Gordunni Orb
9372	Sul'thraze the Lasher
9375	Expert Goldminer's Helmet
9378	Shovelphlange's Mining Axe
9379	Sang'thraze the Deflector
9380	Jang'thraze the Protector
9381	Earthen Rod
9382	Tromping Miner's Boots
9383	Obsidian Cleaver
9384	Stonevault Shiv
9385	Archaic Defender
9386	Excavator's Brand
9387	Revelosh's Boots
9388	Revelosh's Armguards
9389	Revelosh's Spaulders
9390	Revelosh's Gloves
9391	The Shoveler
9392	Annealed Blade
9393	Beacon of Hope
9394	Horned Viking Helmet
9396	Legguards of the Vault
9397	Energy Cloak
9398	Worn Running Boots
9399	Precision Arrow
9400	Baelog's Shortbow
9401	Nordic Longshank
9402	Earthborn Kilt
9403	Battered Viking Shield
9404	Olaf's All Purpose Shield
9405	Girdle of Golem Strength
9406	Spirewind Fetter
9407	Stoneweaver Leggings
9408	Ironshod Bludgeon
9409	Ironaya's Bracers
9410	Cragfists
9411	Rockshard Pauldrons
9412	Galgann's Fireblaster
9413	The Rockpounder
9414	Oilskin Leggings
9415	Grimlok's Tribal Vestments
9416	Grimlok's Charge
9417	Archaedic Shard
9418	Stoneslayer
9419	Galgann's Firehammer
9420	Adventurer's Pith Helmet
9421	Major Healthstone
9422	Shadowforge Bushmaster
9423	The Jackhammer
9424	Ginn-su Sword
9425	Pendulum of Doom
9426	Monolithic Bow
9427	Stonevault Bonebreaker
9428	Unearthed Bands
9429	Miner's Hat of the Deep
9430	Spaulders of a Lost Age
9431	Papal Fez
9432	Skullplate Bracers
9433	Forgotten Wraps
9434	Elemental Raiment
9435	Reticulated Bone Gauntlets
9436	Faranell's Parcel
9437	Untested Basilisk Sample
9438	Acceptable Scorpid Sample
9439	Untested Hyena Sample
9440	Acceptable Basilisk Sample
9441	Acceptable Hyena Sample
9442	Untested Scorpid Sample
9443	Used Monster Sample
9444	Techbot CPU Shell
9445	Grubbis Paws
9446	Electrocutioner Leg
9447	Electrocutioner Lagnut
9448	Spidertank Oilrag
9449	Manual Crowd Pummeler
9450	Gnomebot Operating Boots
9451	Bubbling Water
9452	Hydrocane
9453	Toxic Revenger
9454	Acidic Walkers
9455	Emissary Cuffs
9456	Glass Shooter
9457	Royal Diplomatic Scepter
9458	Thermaplugg's Central Core
9459	Thermaplugg's Left Arm
9460	Grimtotem Horn
9461	Charged Gear
9462	Crate of Grimtotem Horns
9463	Gordunni Cobalt
9465	Digmaster 5000
9466	Orwin's Shovel
9467	Gahz'rilla Fang
9468	Sharpbeak's Feather
9469	Gahz'rilla Scale Armor
9470	Bad Mojo Mask
9471	Nekrum's Medallion
9472	Hexx's Key
9473	Jinxed Hoodoo Skin
9474	Jinxed Hoodoo Kilt
9475	Diabolic Skiver
9476	Big Bad Pauldrons
9477	The Chief's Enforcer
9478	Ripsaw
9479	Embrace of the Lycan
9480	Eyegouger
9481	The Minotaur
9482	Witch Doctor's Cane
9483	Flaming Incinerator
9484	Spellshock Leggings
9485	Vibroblade
9486	Supercharger Battle Axe
9487	Hi-tech Supergun
9488	Oscillating Power Hammer
9489	Gyromatic Icemaker
9490	Gizmotron Megachopper
9491	Hotshot Pilot's Gloves
9492	Electromagnetic Gigaflux Reactivator
9507	A Carefully-packed Crate
9508	Mechbuilder's Overalls
9509	Petrolspill Leggings
9510	Caverndeep Trudgers
9511	Bloodletter Scalpel
9512	Blackmetal Cape
9513	Ley Staff
9514	Arcane Staff
9515	Nether-lace Tunic
9516	Astral Knot Blouse
9517	Celestial Stave
9518	Mud's Crushers
9519	Durtfeet Stompers
9520	Silent Hunter
9521	Skullsplitter
9522	Energized Stone Circle
9523	Troll Temper
9527	Spellshifter Rod
9528	Edana's Dark Heart
9529	Internal Warrior Equipment Kit L25
9530	Horn of Hatetalon
9531	Gemshale Pauldrons
9532	Internal Warrior Equipment Kit L30
9533	Masons Fraternity Ring
9534	Engineer's Guild Headpiece
9535	Fire-welded Bracers
9536	Fairywing Mantle
9537	Neatly Wrapped Box
9538	Talvash's Gold Ring
9539	Box of Rations
9540	Box of Spells
9541	Box of Goodies
9542	Simple Letter
9543	Simple Rune
9544	Simple Memorandum
9545	Simple Sigil
9546	Simple Scroll
9547	Simple Note
9548	Hallowed Letter
9550	Encrypted Rune
9551	Encrypted Sigil
9552	Rune-Inscribed Note
9553	Etched Parchment
9554	Encrypted Tablet
9555	Encrypted Letter
9556	Hallowed Rune
9557	Hallowed Sigil
9558	Encrypted Memorandum
9559	Encrypted Scroll
9560	Encrypted Parchment
9561	Hallowed Tablet
9562	Rune-Inscribed Tablet
9563	Consecrated Rune
9564	Etched Tablet
9565	Etched Note
9566	Etched Rune
9567	Etched Sigil
9568	Rune-Inscribed Parchment
9569	Hallowed Scroll
9570	Consecrated Letter
9571	Glyphic Letter
9572	Glyphic Rune
9573	Glyphic Memorandum
9574	Glyphic Scroll
9575	Glyphic Tablet
9576	Tainted Letter
9577	Tainted Memorandum
9578	Tainted Scroll
9579	Tainted Parchment
9580	Verdant Sigil
9581	Verdant Note
9587	Thawpelt Sack
9588	Nogg's Gold Ring
9589	Encrusted Minerals
9590	Splintered Log
9591	Resilient Sinew
9592	Metallic Fragments
9593	Treant Muisek
9594	Wildkin Muisek
9595	Hippogryph Muisek
9596	Faerie Dragon Muisek
9597	Mountain Giant Muisek
9598	Sleeping Robes
9599	Barkmail Leggings
9600	Lace Pants
9601	Cushioned Boots
9602	Brushwood Blade
9603	Gritroot Staff
9604	Mechanic's Pipehammer
9605	Repairman's Cape
9606	Treant Muisek Vessel
9607	Bastion of Stormwind
9608	Shoni's Disarming Tool
9609	Shilly Mitts
9618	Wildkin Muisek Vessel
9619	Hippogryph Muisek Vessel
9620	Faerie Dragon Muisek Vessel
9621	Mountain Giant Muisek Vessel
9622	Reedknot Ring
9623	Civinad Robes
9624	Triprunner Dungarees
9625	Dual Reinforced Leggings
9626	Dwarven Charge
9627	Explorer's League Lodestar
9628	Neeru's Herb Pouch
9629	A Shrunken Head
9630	Pratt's Handcrafted Boots
9631	Pratt's Handcrafted Gloves
9632	Jangdor's Handcrafted Gloves
9633	Jangdor's Handcrafted Boots
9634	Skilled Handling Gloves
9635	Master Apothecary Cape
9636	Swashbuckler Sash
9637	Shinkicker Boots
9638	Chelonian Cuffs
9639	The Hand of Antu'sul
9640	Vice Grips
9641	Lifeblood Amulet
9642	Band of the Great Tortoise
9643	Optomatic Deflector
9644	Thermotastic Egg Timer
9645	Gnomish Inventor Boots
9646	Gnomish Water Sinking Device
9647	Failed Flying Experiment
9648	Chainlink Towel
9649	Royal Highmark Vestments
9650	Honorguard Chestpiece
9651	Gryphon Rider's Stormhammer
9652	Gryphon Rider's Leggings
9653	Speedy Racer Goggles
9654	Cairnstone Sliver
9655	Seedtime Hoop
9656	Granite Grips
9657	Vinehedge Cinch
9658	Boots of the Maharishi
9660	Stargazer Cloak
9661	Earthclasp Barrier
9662	Rushridge Boots
9663	Dawnrider's Chestpiece
9664	Sentinel's Guard
9665	Wingcrest Gloves
9666	Stronghorn Girdle
9678	Tok'kar's Murloc Basher
9679	Tok'kar's Murloc Chopper
9680	Tok'kar's Murloc Shanker
9681	Grilled King Crawler Legs
9682	Leather Chef's Belt
9683	Strength of the Treant
9684	Force of the Hippogryph
9685	Will of the Mountain Giant
9686	Spirit of the Faerie Dragon
9687	Grappler's Belt
9698	Gloves of Insight
9699	Garrison Cloak
9703	Scorched Cape
9704	Rustler Gloves
9705	Tharg's Shoelace
9706	Tharg's Disk
9718	Reforged Blade of Heroes
9719	Broken Blade of Heroes
9738	Gem of Cobrahn
9739	Gem of Anacondra
9740	Gem of Pythas
9741	Gem of Serpentis
9742	Simple Cord
9743	Simple Shoes
9744	Simple Bands
9745	Simple Cape
9746	Simple Gloves
9747	Simple Britches
9748	Simple Robe
9749	Simple Blouse
9750	Gypsy Sash
9751	Gypsy Sandals
9752	Gypsy Bands
9753	Gypsy Buckler
9754	Gypsy Cloak
9755	Gypsy Gloves
9756	Gypsy Trousers
9757	Gypsy Tunic
9758	Cadet Belt
9759	Cadet Boots
9760	Cadet Bracers
9761	Cadet Cloak
9762	Cadet Gauntlets
9763	Cadet Leggings
9764	Cadet Shield
9765	Cadet Vest
9766	Greenweave Sash
9767	Greenweave Sandals
9768	Greenweave Bracers
9769	Greenweave Branch
9770	Greenweave Cloak
9771	Greenweave Gloves
9772	Greenweave Leggings
9773	Greenweave Robe
9774	Greenweave Vest
9775	Bandit Cinch
9776	Bandit Boots
9777	Bandit Bracers
9778	Bandit Buckler
9779	Bandit Cloak
9780	Bandit Gloves
9781	Bandit Pants
9782	Bandit Jerkin
9783	Raider's Chestpiece
9784	Raider's Boots
9785	Raider's Bracers
9786	Raider's Cloak
9787	Raider's Gauntlets
9788	Raider's Belt
9789	Raider's Legguards
9790	Raider's Shield
9791	Ivycloth Tunic
9792	Ivycloth Boots
9793	Ivycloth Bracelets
9794	Ivycloth Cloak
9795	Ivycloth Gloves
9796	Ivycloth Mantle
9797	Ivycloth Pants
9798	Ivycloth Robe
9799	Ivycloth Sash
9800	Ivy Orb
9801	Superior Belt
9802	Superior Boots
9803	Superior Bracers
9804	Superior Buckler
9805	Superior Cloak
9806	Superior Gloves
9807	Superior Shoulders
9808	Superior Leggings
9809	Superior Tunic
9810	Fortified Boots
9811	Fortified Bracers
9812	Fortified Cloak
9813	Fortified Gauntlets
9814	Fortified Belt
9815	Fortified Leggings
9816	Fortified Shield
9817	Fortified Spaulders
9818	Fortified Chain
9819	Durable Tunic
9820	Durable Boots
9821	Durable Bracers
9822	Durable Cape
9823	Durable Gloves
9824	Durable Shoulders
9825	Durable Pants
9826	Durable Robe
9827	Scaled Leather Belt
9828	Scaled Leather Boots
9829	Scaled Leather Bracers
9830	Scaled Shield
9831	Scaled Cloak
9832	Scaled Leather Gloves
9833	Scaled Leather Leggings
9834	Scaled Leather Shoulders
9835	Scaled Leather Tunic
9836	Banded Armor
9837	Banded Bracers
9838	Banded Cloak
9839	Banded Gauntlets
9840	Banded Girdle
9841	Banded Leggings
9842	Banded Pauldrons
9843	Banded Shield
9844	Conjurer's Vest
9845	Conjurer's Shoes
9846	Conjurer's Bracers
9847	Conjurer's Cloak
9848	Conjurer's Gloves
9849	Conjurer's Hood
9850	Conjurer's Mantle
9851	Conjurer's Breeches
9852	Conjurer's Robe
9853	Conjurer's Cinch
9854	Archer's Jerkin
9855	Archer's Belt
9856	Archer's Boots
9857	Archer's Bracers
9858	Archer's Buckler
9859	Archer's Cap
9860	Archer's Cloak
9861	Archer's Gloves
9862	Archer's Trousers
9863	Archer's Shoulderpads
9864	Renegade Boots
9865	Renegade Bracers
9866	Renegade Chestguard
9867	Renegade Cloak
9868	Renegade Gauntlets
9869	Renegade Belt
9870	Renegade Circlet
9871	Renegade Leggings
9872	Renegade Pauldrons
9873	Renegade Shield
9874	Sorcerer Drape
9875	Sorcerer Sash
9876	Sorcerer Slippers
9877	Sorcerer Cloak
9878	Sorcerer Hat
9879	Sorcerer Bracelets
9880	Sorcerer Gloves
9881	Sorcerer Mantle
9882	Sorcerer Sphere
9883	Sorcerer Pants
9884	Sorcerer Robe
9885	Huntsman's Boots
9886	Huntsman's Bands
9887	Huntsman's Armor
9888	Elven Protector
9889	Huntsman's Cap
9890	Huntsman's Cape
9891	Huntsman's Belt
9892	Huntsman's Gloves
9893	Huntsman's Leggings
9894	Huntsman's Shoulders
9895	Jazeraint Boots
9896	Jazeraint Bracers
9897	Jazeraint Chestguard
9898	Jazeraint Cloak
9899	Jazeraint Shield
9900	Jazeraint Gauntlets
9901	Jazeraint Belt
9902	Jazeraint Helm
9903	Jazeraint Leggings
9904	Jazeraint Pauldrons
9905	Royal Blouse
9906	Royal Sash
9907	Royal Boots
9908	Royal Cape
9909	Royal Bands
9910	Royal Gloves
9911	Royal Trousers
9912	Royal Amice
9913	Royal Gown
9914	Royal Scepter
9915	Royal Headband
9916	Tracker's Belt
9917	Tracker's Boots
9918	Brigade Defender
9919	Tracker's Cloak
9920	Tracker's Gloves
9921	Tracker's Headband
9922	Tracker's Leggings
9923	Tracker's Shoulderpads
9924	Tracker's Tunic
9925	Tracker's Wristguards
9926	Brigade Boots
9927	Brigade Bracers
9928	Brigade Breastplate
9929	Brigade Cloak
9930	Brigade Gauntlets
9931	Brigade Girdle
9932	Brigade Circlet
9933	Brigade Leggings
9934	Brigade Pauldrons
9935	Embossed Plate Shield
9936	Abjurer's Boots
9937	Abjurer's Bands
9938	Abjurer's Cloak
9939	Abjurer's Gloves
9940	Abjurer's Hood
9941	Abjurer's Mantle
9942	Abjurer's Pants
9943	Abjurer's Robe
9944	Abjurer's Crystal
9945	Abjurer's Sash
9946	Abjurer's Tunic
9947	Chieftain's Belt
9948	Chieftain's Boots
9949	Chieftain's Bracers
9950	Chieftain's Breastplate
9951	Chieftain's Cloak
9952	Chieftain's Gloves
9953	Chieftain's Headdress
9954	Chieftain's Leggings
9955	Chieftain's Shoulders
9956	Warmonger's Bracers
9957	Warmonger's Chestpiece
9958	Warmonger's Buckler
9959	Warmonger's Cloak
9960	Warmonger's Gauntlets
9961	Warmonger's Belt
9962	Warmonger's Greaves
9963	Warmonger's Circlet
9964	Warmonger's Leggings
9965	Warmonger's Pauldrons
9966	Embossed Plate Armor
9967	Embossed Plate Gauntlets
9968	Embossed Plate Girdle
9969	Embossed Plate Helmet
9970	Embossed Plate Leggings
9971	Embossed Plate Pauldrons
9972	Embossed Plate Bracers
9973	Embossed Plate Boots
9974	Overlord's Shield
9978	Gahz'ridian Detector
9998	Black Mageweave Vest
9999	Black Mageweave Leggings
10000	Margol's Horn
10001	Black Mageweave Robe
10002	Shadoweave Pants
10003	Black Mageweave Gloves
10004	Shadoweave Robe
10005	Margol's Gigantic Horn
10007	Red Mageweave Vest
10008	White Bandit Mask
10009	Red Mageweave Pants
10010	Stormcloth Pants
10011	Stormcloth Gloves
10018	Red Mageweave Gloves
10019	Dreamweave Gloves
10020	Stormcloth Vest
10021	Dreamweave Vest
10022	Proof of Deed
10023	Shadoweave Gloves
10024	Black Mageweave Headband
10025	Shadoweave Mask
10026	Black Mageweave Boots
10027	Black Mageweave Shoulders
10028	Shadoweave Shoulders
10029	Red Mageweave Shoulders
10030	Admiral's Hat
10031	Shadoweave Boots
10032	Stormcloth Headband
10033	Red Mageweave Headband
10034	Tuxedo Shirt
10035	Tuxedo Pants
10036	Tuxedo Jacket
10038	Stormcloth Shoulders
10039	Stormcloth Boots
10040	White Wedding Dress
10041	Dreamweave Circlet
10042	Cindercloth Robe
10043	Pious Legwraps
10044	Cindercloth Boots
10045	Simple Linen Pants
10046	Simple Linen Boots
10047	Simple Kilt
10048	Colorful Kilt
10049	Diabolist's Blade
10050	Mageweave Bag
10051	Red Mageweave Bag
10052	Orange Martial Shirt
10053	Simple Black Dress
10054	Lavender Mageweave Shirt
10055	Pink Mageweave Shirt
10056	Orange Mageweave Shirt
10057	Duskwoven Tunic
10058	Duskwoven Sandals
10059	Duskwoven Bracers
10060	Duskwoven Cape
10061	Duskwoven Turban
10062	Duskwoven Gloves
10063	Duskwoven Amice
10064	Duskwoven Pants
10065	Duskwoven Robe
10066	Duskwoven Sash
10067	Righteous Waistguard
10068	Righteous Boots
10069	Righteous Bracers
10070	Righteous Armor
10071	Righteous Cloak
10072	Righteous Gloves
10073	Righteous Helmet
10074	Righteous Leggings
10075	Righteous Spaulders
10076	Lord's Armguards
10077	Lord's Breastplate
10078	Lord's Crest
10079	Lord's Cape
10080	Lord's Gauntlets
10081	Lord's Girdle
10082	Lord's Boots
10083	Lord's Crown
10084	Lord's Legguards
10085	Lord's Pauldrons
10086	Gothic Plate Armor
10087	Gothic Plate Gauntlets
10088	Gothic Plate Girdle
10089	Gothic Sabatons
10090	Gothic Plate Helmet
10091	Gothic Plate Leggings
10092	Gothic Plate Spaulders
10093	Revenant Deflector
10094	Gothic Plate Vambraces
10095	Councillor's Boots
10096	Councillor's Cuffs
10097	Councillor's Circlet
10098	Councillor's Cloak
10099	Councillor's Gloves
10100	Councillor's Shoulders
10101	Councillor's Pants
10102	Councillor's Robes
10103	Councillor's Sash
10104	Councillor's Tunic
10105	Wanderer's Armor
10106	Wanderer's Boots
10107	Wanderer's Bracers
10108	Wanderer's Cloak
10109	Wanderer's Belt
10110	Wanderer's Gloves
10111	Wanderer's Hat
10112	Wanderer's Leggings
10113	Wanderer's Shoulders
10118	Ornate Breastplate
10119	Ornate Greaves
10120	Ornate Cloak
10121	Ornate Gauntlets
10122	Ornate Girdle
10123	Ornate Circlet
10124	Ornate Legguards
10125	Ornate Pauldrons
10126	Ornate Bracers
10127	Revenant Bracers
10128	Revenant Chestplate
10129	Revenant Gauntlets
10130	Revenant Girdle
10131	Revenant Boots
10132	Revenant Helmet
10133	Revenant Leggings
10134	Revenant Shoulders
10135	High Councillor's Tunic
10136	High Councillor's Bracers
10137	High Councillor's Boots
10138	High Councillor's Cloak
10139	High Councillor's Circlet
10140	High Councillor's Gloves
10141	High Councillor's Pants
10142	High Councillor's Mantle
10143	High Councillor's Robe
10144	High Councillor's Sash
10145	Mighty Girdle
10146	Mighty Boots
10147	Mighty Armsplints
10148	Mighty Cloak
10149	Mighty Gauntlets
10150	Mighty Helmet
10151	Mighty Tunic
10152	Mighty Leggings
10153	Mighty Spaulders
10154	Mercurial Girdle
10155	Mercurial Greaves
10156	Mercurial Bracers
10157	Mercurial Breastplate
10158	Mercurial Guard
10159	Mercurial Cloak
10160	Mercurial Circlet
10161	Mercurial Gauntlets
10162	Mercurial Legguards
10163	Mercurial Pauldrons
10164	Templar Chestplate
10165	Templar Gauntlets
10166	Templar Girdle
10167	Templar Boots
10168	Templar Crown
10169	Templar Legplates
10170	Templar Pauldrons
10171	Templar Bracers
10172	Mystical Mantle
10173	Mystical Bracers
10174	Mystical Cape
10175	Mystical Headwrap
10176	Mystical Gloves
10177	Mystical Leggings
10178	Mystical Robe
10179	Mystical Boots
10180	Mystical Belt
10181	Mystical Armor
10182	Swashbuckler's Breastplate
10183	Swashbuckler's Boots
10184	Swashbuckler's Bracers
10185	Swashbuckler's Cape
10186	Swashbuckler's Gloves
10187	Swashbuckler's Eyepatch
10188	Swashbuckler's Leggings
10189	Swashbuckler's Shoulderpads
10190	Swashbuckler's Belt
10191	Crusader's Armguards
10192	Crusader's Boots
10193	Crusader's Armor
10194	Crusader's Cloak
10195	Crusader's Shield
10196	Crusader's Gauntlets
10197	Crusader's Belt
10198	Crusader's Helm
10199	Crusader's Leggings
10200	Crusader's Pauldrons
10201	Overlord's Greaves
10202	Overlord's Vambraces
10203	Overlord's Chestplate
10204	Heavy Lamellar Shield
10205	Overlord's Gauntlets
10206	Overlord's Girdle
10207	Overlord's Crown
10208	Overlord's Legplates
10209	Overlord's Spaulders
10210	Elegant Mantle
10211	Elegant Boots
10212	Elegant Cloak
10213	Elegant Bracers
10214	Elegant Gloves
10215	Elegant Robes
10216	Elegant Belt
10217	Elegant Leggings
10218	Elegant Tunic
10219	Elegant Circlet
10220	Nightshade Tunic
10221	Nightshade Girdle
10222	Nightshade Boots
10223	Nightshade Armguards
10224	Nightshade Cloak
10225	Nightshade Gloves
10226	Nightshade Helmet
10227	Nightshade Leggings
10228	Nightshade Spaulders
10229	Engraved Bracers
10230	Engraved Breastplate
10231	Engraved Cape
10232	Engraved Gauntlets
10233	Engraved Girdle
10234	Engraved Boots
10235	Engraved Helm
10236	Engraved Leggings
10237	Engraved Pauldrons
10238	Heavy Lamellar Boots
10239	Heavy Lamellar Vambraces
10240	Heavy Lamellar Chestpiece
10241	Heavy Lamellar Helm
10242	Heavy Lamellar Gauntlets
10243	Heavy Lamellar Girdle
10244	Heavy Lamellar Leggings
10245	Heavy Lamellar Pauldrons
10246	Master's Vest
10247	Master's Boots
10248	Master's Bracers
10249	Master's Cloak
10250	Master's Hat
10251	Master's Gloves
10252	Master's Leggings
10253	Master's Mantle
10254	Master's Robe
10255	Master's Belt
10256	Adventurer's Bracers
10257	Adventurer's Boots
10258	Adventurer's Cape
10259	Adventurer's Belt
10260	Adventurer's Gloves
10261	Adventurer's Bandana
10262	Adventurer's Legguards
10263	Adventurer's Shoulders
10264	Adventurer's Tunic
10265	Masterwork Bracers
10266	Masterwork Breastplate
10267	Masterwork Cape
10268	Masterwork Gauntlets
10269	Masterwork Girdle
10270	Masterwork Boots
10271	Masterwork Shield
10272	Masterwork Circlet
10273	Masterwork Legplates
10274	Masterwork Pauldrons
10275	Emerald Breastplate
10276	Emerald Sabatons
10277	Emerald Gauntlets
10278	Emerald Girdle
10279	Emerald Helm
10280	Emerald Legplates
10281	Emerald Pauldrons
10282	Emerald Vambraces
10283	Wolf Heart Samples
10285	Shadow Silk
10286	Heart of the Wild
10287	Greenweave Mantle
10288	Sage's Circlet
10289	Durable Hat
10290	Pink Dye
10298	Gnomeregan Band
10299	Gnomeregan Amulet
10300	Pattern: Red Mageweave Vest
10301	Pattern: White Bandit Mask
10302	Pattern: Red Mageweave Pants
10303	Pattern: Stormcloth Pants
10304	Pattern: Stormcloth Gloves
10305	Scroll of Protection IV
10306	Scroll of Spirit IV
10307	Scroll of Stamina IV
10308	Scroll of Intellect IV
10309	Scroll of Agility IV
10310	Scroll of Strength IV
10311	Pattern: Orange Martial Shirt
10312	Pattern: Red Mageweave Gloves
10313	Pattern: Stormcloth Vest
10314	Pattern: Lavender Mageweave Shirt
10315	Pattern: Red Mageweave Shoulders
10316	Pattern: Colorful Kilt
10317	Pattern: Pink Mageweave Shirt
10318	Pattern: Admiral's Hat
10319	Pattern: Stormcloth Headband
10320	Pattern: Red Mageweave Headband
10321	Pattern: Tuxedo Shirt
10322	Pattern: Stormcloth Shoulders
10323	Pattern: Tuxedo Pants
10324	Pattern: Stormcloth Boots
10325	Pattern: White Wedding Dress
10326	Pattern: Tuxedo Jacket
10327	Horn of Echeyakee
10328	Scarlet Chestpiece
10329	Scarlet Belt
10330	Scarlet Leggings
10331	Scarlet Gauntlets
10332	Scarlet Boots
10333	Scarlet Wristguards
10338	Fresh Zhevra Carcass
10358	Duracin Bracers
10359	Everlast Boots
10360	Black Kingsnake
10361	Brown Snake
10362	Ornate Shield
10363	Engraved Wall
10364	Templar Shield
10365	Emerald Shield
10366	Demon Guard
10367	Hyperion Shield
10368	Imbued Plate Armor
10369	Imbued Plate Gauntlets
10370	Imbued Plate Girdle
10371	Imbued Plate Greaves
10372	Imbued Plate Helmet
10373	Imbued Plate Leggings
10374	Imbued Plate Pauldrons
10375	Imbued Plate Vambraces
10376	Commander's Boots
10377	Commander's Vambraces
10378	Commander's Armor
10379	Commander's Helm
10380	Commander's Gauntlets
10381	Commander's Girdle
10382	Commander's Leggings
10383	Commander's Pauldrons
10384	Hyperion Armor
10385	Hyperion Greaves
10386	Hyperion Gauntlets
10387	Hyperion Girdle
10388	Hyperion Helm
10389	Hyperion Legplates
10390	Hyperion Pauldrons
10391	Hyperion Vambraces
10392	Crimson Snake
10393	Cockroach
10394	Prairie Dog Whistle
10398	Mechanical Chicken
10399	Blackened Defias Armor
10400	Blackened Defias Leggings
10401	Blackened Defias Gloves
10402	Blackened Defias Boots
10403	Blackened Defias Belt
10404	Durable Belt
10405	Bandit Shoulders
10406	Scaled Leather Headband
10407	Raider's Shoulderpads
10408	Banded Helm
10409	Banded Boots
10410	Leggings of the Fang
10411	Footpads of the Fang
10412	Belt of the Fang
10413	Gloves of the Fang
10414	Sample Snapjaw Shell
10418	Glimmering Mithril Insignia
10420	Skull of the Coldbringer
10421	Rough Copper Vest
10423	Silvered Bronze Leggings
10424	Plans: Silvered Bronze Leggings
10438	Felix's Box
10439	Durnan's Scalding Mornbrew
10440	Nori's Mug
10441	Glowing Shard
10442	Mysterious Artifact
10443	Singed Letter
10444	Standard Issue Flare Gun
10445	Drawing Kit
10446	Heart of Obsidion
10447	Head of Lathoric the Black
10450	Undamaged Hippogryph Feather
10454	Essence of Eranikus
10455	Chained Essence of Eranikus
10456	A Bulging Coin Purse
10457	Empty Sea Snail Shell
10458	Prayer to Elune
10459	Chief Sharptusk Thornmantle's Head
10460	Hakkari Blood
10461	Shadowy Bracers
10462	Shadowy Belt
10463	Pattern: Shadoweave Mask
10464	Staff of Command
10465	Egg of Hakkar
10466	Atal'ai Stone Circle
10467	Trader's Satchel
10478	Roland's Mana Gem
10479	Kovic's Trading Satchel
10498	Gyromatic Micro-Adjustor
10499	Bright-Eye Goggles
10500	Fire Goggles
10501	Catseye Ultra Goggles
10502	Spellpower Goggles Xtreme
10503	Rose Colored Goggles
10504	Green Lens
10505	Solid Blasting Powder
10506	Deepdive Helmet
10507	Solid Dynamite
10508	Mithril Blunderbuss
10509	Heart of Flame
10510	Mithril Heavy-bore Rifle
10511	Golem Oil
10512	Hi-Impact Mithril Slugs
10513	Mithril Gyro-Shot
10514	Mithril Frag Bomb
10515	Torch of Retribution
10518	Parachute Cloak
10538	Tablet of Beth'Amara
10539	Tablet of Jin'yael
10540	Tablet of Markri
10541	Tablet of Sael'hai
10542	Goblin Mining Helmet
10543	Goblin Construction Helmet
10544	Thistlewood Maul
10545	Gnomish Goggles
10546	Deadly Scope
10547	Camping Knife
10548	Sniper Scope
10549	Rancher's Trousers
10550	Wooly Mittens
10551	Thorium Plated Dagger
10552	Symbol of Ragnaros
10553	Foreman Vest
10554	Foreman Pants
10556	Stone Circle
10558	Gold Power Core
10559	Mithril Tube
10560	Unstable Trigger
10561	Mithril Casing
10562	Hi-Explosive Bomb
10563	Rubbing: Rune of Beth'Amara
10564	Rubbing: Rune of Jin'yael
10565	Rubbing: Rune of Markri
10566	Rubbing: Rune of Sael'hai
10567	Quillshooter
10569	Hoard of the Black Dragonflight
10570	Manslayer
10571	Ebony Boneclub
10572	Freezing Shard
10573	Boneslasher
10574	Corpseshroud
10575	Black Dragonflight Molt
10576	Mithril Mechanical Dragonling
10577	Goblin Mortar
10578	Thoughtcast Boots
10579	Explosive Arrow
10580	Goblin "Boom" Box
10581	Death's Head Vestment
10582	Briar Tredders
10583	Quillward Harness
10584	Stormgale Fists
10585	Goblin Radio
10586	The Big One
10587	Goblin Bomb Dispenser
10588	Goblin Rocket Helmet
10589	Oathstone of Ysera's Dragonflight
10590	Pocked Black Box
10592	Catseye Elixir
10593	Imperfect Draenethyst Fragment
10595	Kum'sha's Junk
10597	Head of Magus Rimtori
10598	Hetaera's Bloodied Head
10599	Hetaera's Beaten Head
10600	Hetaera's Bruised Head
10601	Schematic: Bright-Eye Goggles
10602	Schematic: Deadly Scope
10603	Schematic: Catseye Ultra Goggles
10604	Schematic: Mithril Heavy-bore Rifle
10605	Schematic: Spellpower Goggles Xtreme
10606	Schematic: Parachute Cloak
10607	Schematic: Deepdive Helmet
10608	Schematic: Sniper Scope
10609	Schematic: Mithril Mechanical Dragonling
10610	Hetaera's Blood
10620	Thorium Ore
10621	Runed Scroll
10622	Kadrak's Flag
10623	Winter's Bite
10624	Stinging Bow
10625	Stealthblade
10626	Ragehammer
10627	Bludgeon of the Grinning Dog
10628	Deathblow
10629	Mistwalker Boots
10630	Soulcatcher Halo
10631	Murkwater Gauntlets
10632	Slimescale Bracers
10633	Silvershell Leggings
10634	Mindseye Circle
10635	Painted Chain Leggings
10636	Nomadic Gloves
10637	Brewer's Gloves
10638	Long Draping Cape
10639	Hyacinth Mushroom
10640	Webwood Ichor
10641	Moonpetal Lily
10642	Iverron's Antidote
10643	Sealed Letter to Ag'tor
10644	Recipe: Goblin Rocket Fuel
10645	Gnomish Death Ray
10646	Goblin Sapper Charge
10647	Engineer's Ink
10648	Blank Parchment
10649	Nightmare Shard
10650	Plague-Infested Quilboar Mane
10651	Cracked Arcane Focusing Crystal
10652	Will of the Mountain Giant
10653	Trailblazer Boots
10654	Jutebraid Gloves
10655	Sedgeweed Britches
10656	Barkmail Vest
10657	Talbar Mantle
10658	Quagmire Galoshes
10659	Shard of Afrasa
10660	First Mosh'aru Tablet
10661	Second Mosh'aru Tablet
10662	Filled Egg of Hakkar
10663	Essence of Hakkar
10664	A Note to Magus Rimtori
10678	Magatha's Note
10679	Andron's Note
10680	Jes'rimon's Note
10681	Xylem's Note
10682	Belnistrasz's Oathstone
10683	Explorer's Knapsack
10684	Colossal Parachute
10686	Aegis of Battle
10687	Empty Vial Labeled #1
10688	Empty Vial Labeled #2
10689	Empty Vial Labeled #3
10690	Empty Vial Labeled #4
10691	Filled Vial Labeled #1
10692	Filled Vial Labeled #2
10693	Filled Vial Labeled #3
10694	Filled Vial Labeled #4
10695	Box of Empty Vials
10696	Enchanted Azsharite Felbane Sword
10697	Enchanted Azsharite Felbane Dagger
10698	Enchanted Azsharite Felbane Staff
10699	Yeh'kinya's Bramble
10700	Encarmine Boots
10701	Boots of Zua'tec
10702	Enormous Ogre Boots
10703	Fiendish Skiv
10704	Chillnail Splinter
10705	Firwillow Wristbands
10706	Nightscale Girdle
10707	Steelsmith Greaves
10708	Skullspell Orb
10709	Pyrestone Orb
10710	Dragonclaw Ring
10711	Dragon's Blood Necklace
10712	Cuely's Elixir
10713	Plans: Inlaid Mithril Cylinder
10714	Crystallized Azsharite
10715	Kim'Jael's Scope
10716	Gnomish Shrink Ray
10717	Kim'Jael's Compass
10718	Kim'Jael's Wizzlegoober
10719	Mobile Alarm
10720	Gnomish Net-o-Matic Projector
10721	Gnomish Harm Prevention Belt
10722	Kim'Jael's Stuffed Chicken
10723	Gnomish Ham Radio
10724	Gnomish Rocket Boots
10725	Gnomish Battle Chicken
10726	Gnomish Mind Control Cap
10727	Goblin Dragon Gun
10728	Pattern: Black Swashbuckler's Shirt
10738	Shipment to Galvan
10739	Ring of Fortitude
10740	Centurion Legplates
10741	Lordrec Helmet
10742	Dragonflight Leggings
10743	Drakefire Headguard
10744	Axe of the Ebon Drake
10745	Kaylari Shoulders
10746	Runesteel Vambraces
10747	Teacher's Sash
10748	Wanderlust Boots
10749	Avenguard Helm
10750	Lifeforce Dirk
10751	Gemburst Circlet
10752	Emerald Encrusted Chest
10753	Amulet of Grol
10754	Amulet of Sevine
10755	Amulet of Allistarj
10757	Ward of the Defiler
10758	X'caliboar
10759	Severed Horn of the Defiler
10760	Swine Fists
10761	Coldrage Dagger
10762	Robes of the Lich
10763	Icemetal Barbute
10764	Deathchill Armor
10765	Bonefingers
10766	Plaguerot Sprig
10767	Savage Boar's Guard
10768	Boar Champion's Belt
10769	Glowing Eye of Mordresh
10770	Mordresh's Lifeless Skull
10771	Deathmage Sash
10772	Glutton's Cleaver
10773	Hakkari Urn
10774	Fleshhide Shoulders
10775	Carapace of Tuten'kash
10776	Silky Spider Cape
10777	Arachnid Gloves
10778	Necklace of Sanctuary
10779	Demon's Blood
10780	Mark of Hakkar
10781	Hakkari Breastplate
10782	Hakkari Shroud
10783	Atal'ai Spaulders
10784	Atal'ai Breastplate
10785	Atal'ai Leggings
10786	Atal'ai Boots
10787	Atal'ai Gloves
10788	Atal'ai Girdle
10789	Manual of Engineering Disciplines
10790	Gnome Engineer Membership Card
10791	Goblin Engineer Membership Card
10792	Nixx's Pledge of Secrecy
10793	Overspark's Pledge of Secrecy
10794	Oglethorpe's Pledge of Secrecy
10795	Drakeclaw Band
10796	Drakestone
10797	Firebreather
10798	Atal'alarion's Tusk Ring
10799	Headspike
10800	Darkwater Bracers
10801	Slitherscale Boots
10802	Wingveil Cloak
10803	Blade of the Wretched
10804	Fist of the Damned
10805	Eater of the Dead
10806	Vestments of the Atal'ai Prophet
10807	Kilt of the Atal'ai Prophet
10808	Gloves of the Atal'ai Prophet
10818	Yeh'kinya's Scroll
10819	Wildkin Feather
10820	Jackseed Belt
10821	Sower's Cloak
10822	Dark Whelpling
10823	Vanquisher's Sword
10824	Amberglow Talisman
10826	Staff of Lore
10827	Surveyor's Tunic
10828	Dire Nail
10829	Dragon's Eye
10830	M73 Frag Grenade
10831	Fel Orb
10832	Fel Tracker Owner's Manual
10833	Horns of Eranikus
10834	Felhound Tracker Kit
10835	Crest of Supremacy
10836	Rod of Corrosion
10837	Tooth of Eranikus
10838	Might of Hakkar
10839	Crystallized Note
10840	Crystallized Note
10841	Goldthorn Tea
10842	Windscale Sarong
10843	Featherskin Cape
10844	Spire of Hakkar
10845	Warrior's Embrace
10846	Bloodshot Greaves
10847	Dragon's Call
10858	Plans: Solid Iron Maul
10918	Wound Poison
10919	Apothecary Gloves
10920	Wound Poison II
10921	Wound Poison III
10922	Wound Poison IV
10938	Lesser Magic Essence
10939	Greater Magic Essence
10940	Strange Dust
10958	Hilary's Necklace
10959	Demon Hide Sack
10978	Small Glimmering Shard
10998	Lesser Astral Essence
10999	Ironfel
11000	Shadowforge Key
11018	Un'Goro Soil
11020	Evergreen Pouch
11022	Packet of Tharlendris Seeds
11023	Ancona Chicken
11024	Evergreen Herb Casing
11026	Tree Frog Box
11027	Wood Frog Box
11038	Formula: Enchant 2H Weapon - Lesser Spirit
11039	Formula: Enchant Cloak - Minor Agility
11040	Morrowgrain
11058	Sha'ni's Nose-Ring
11078	Relic Coffer Key
11079	Gor'tesh's Lopped Off Head
11080	Gor'tesh's Lopped Off Head
11081	Formula: Enchant Shield - Lesser Protection
11082	Greater Astral Essence
11083	Soul Dust
11084	Large Glimmering Shard
11085	Customer of the Month Coffer Key
11086	Jang'thraze the Protector
11098	Formula: Enchant Cloak - Lesser Shadow Resistance
11101	Formula: Enchant Bracer - Lesser Strength
11102	Unhatched Sprite Darter Egg
11103	Seed Voucher
11104	Large Compass
11105	Curled Map Parchment
11106	Lion-headed Key
11107	A Small Pack
11108	Faded Photograph
11109	Special Chicken Feed
11110	Chicken Egg
11111	Broken Sprite Darter Egg
11112	Research Equipment
11113	Crate of Foodstuffs
11114	Dinosaur Bone
11115	Secret Safe Key
11116	A Mangled Journal
11118	Archaedic Stone
11119	Milly's Harvest
11120	Belgrom's Hammer
11121	Darkwater Talwar
11122	Carrot on a Stick
11123	Rainstrider Leggings
11124	Helm of Exile
11125	Grape Manifest
11126	Tablet of Kurniya
11127	Scavenged Goods
11128	Golden Rod
11129	Essence of the Elements
11130	Runed Golden Rod
11131	Hive Wall Sample
11133	Linken's Training Sword
11134	Lesser Mystic Essence
11135	Greater Mystic Essence
11136	Linken's Tempered Sword
11137	Vision Dust
11138	Small Glowing Shard
11139	Large Glowing Shard
11140	Prison Cell Key
11141	Bait
11142	Broken Samophlange
11143	Nugget Slug
11144	Truesilver Rod
11145	Runed Truesilver Rod
11146	Broken and Battered Samophlange
11147	Samophlange Manual Cover
11148	Samophlange Manual Page
11149	Samophlange Manual
11150	Formula: Enchant Gloves - Mining
11151	Formula: Enchant Gloves - Herbalism
11152	Formula: Enchant Gloves - Fishing
11162	Linken's Superior Sword
11163	Formula: Enchant Bracer - Lesser Deflection
11164	Formula: Enchant Weapon - Lesser Beastslayer
11165	Formula: Enchant Weapon - Lesser Elemental Slayer
11166	Formula: Enchant Gloves - Skinning
11167	Formula: Enchant Boots - Lesser Spirit
11168	Formula: Enchant Shield - Lesser Block
11169	Book of Aquor
11171	Fel Iron
11172	Silvery Claws
11173	Irontree Heart
11174	Lesser Nether Essence
11175	Greater Nether Essence
11176	Dream Dust
11177	Small Radiant Shard
11178	Large Radiant Shard
11179	Golden Flame
11184	Blue Power Crystal
11185	Green Power Crystal
11186	Red Power Crystal
11187	Stemleaf Bracers
11188	Yellow Power Crystal
11189	Woodland Robes
11190	Viny Gloves
11191	Farmer's Boots
11192	Outfitter Gloves
11193	Blazewind Breastplate
11194	Prismscale Hauberk
11195	Warforged Chestplate
11196	Mindburst Medallion
11197	Dark Keeper Key
11198	Rune of Escape
11199	Engineer's Shield 1
11200	Engineer's Shield 2
11201	Engineer's Shield 3
11202	Formula: Enchant Shield - Stamina
11203	Formula: Enchant Gloves - Advanced Mining
11204	Formula: Enchant Bracer - Greater Spirit
11205	Formula: Enchant Gloves - Advanced Herbalism
11206	Formula: Enchant Cloak - Lesser Agility
11207	Formula: Enchant Weapon - Fiery Weapon
11208	Formula: Enchant Weapon - Demonslaying
11222	Head of Krom'zar
11223	Formula: Enchant Bracer - Deflection
11224	Formula: Enchant Shield - Frost Resistance
11225	Formula: Enchant Bracer - Greater Stamina
11226	Formula: Enchant Gloves - Riding Skill
11227	Piece of Krom'zar's Banner
11228	Frenzied Dragonflight Molt
11229	Brightscale Girdle
11230	Encased Fiery Essence
11231	Altered Black Dragonflight Molt
11242	Evoroot
11243	Videre Elixir
11262	Orb of Lorica
11263	Nether Force Wand
11265	Cragwood Maul
11266	Fractured Elemental Shard
11267	Elemental Shard Sample
11268	Head of Argelmach
11269	Intact Elemental Core
11270	Nixx's Signed Pledge
11282	Oglethorpe's Signed Pledge
11283	Overspark's Signed Pledge
11284	Accurate Slugs
11285	Jagged Arrow
11286	Thorium Shackles
11287	Lesser Magic Wand
11288	Greater Magic Wand
11289	Lesser Mystic Wand
11290	Greater Mystic Wand
11291	Star Wood
11302	Uther's Strength
11303	Fine Shortbow
11304	Fine Longbow
11305	Dense Shortbow
11306	Sturdy Recurve
11307	Massive Longbow
11308	Sylvan Shortbow
11309	The Heart of the Mountain
11310	Flameseer Mantle
11311	Emberscale Cape
11312	Lost Thunderbrew Recipe
11313	Ribbly's Head
11315	Bloodpetal Sprout
11316	Bloodpetal
11318	Atal'ai Haze
11319	Unloaded Zapper
11320	Bloodpetal Zapper
11324	Explorer's Knapsack
11325	Dark Iron Ale Mug
11362	Medium Quiver
11363	Medium Shot Pouch
11364	Tabard of Stormwind
11366	Helendis Riverhorn's Letter
11367	Solomon's Plea to Bolvar
11368	Bolvar's Decree
11370	Dark Iron Ore
11371	Dark Iron Bar
11382	Blood of the Mountain
11384	Broken Basilisk Teeth
11385	Basilisk Scale
11386	Squishy Basilisk Eye
11387	Basilisk Heart
11388	Basilisk Venom
11389	Shimmering Basilisk Skin
11390	Broken Bat Fang
11391	Spined Bat Wing
11392	Severed Bat Claw
11393	Small Bat Skull
11394	Bat Heart
11395	Bat Ear
11402	Sleek Bat Pelt
11403	Large Bat Fang
11404	Evil Bat Eye
11405	Giant Silver Vein
11406	Rotting Bear Carcass
11407	Torn Bear Pelt
11408	Bear Jaw
11409	Bear Flank
11410	Savage Bear Claw
11411	Large Bear Bone
11412	Nagmara's Vial
11413	Nagmara's Filled Vial
11414	Grizzled Mane
11415	Mixed Berries
11416	Delicate Ribcage
11417	Feathery Wing
11418	Hollow Wing Bone
11419	Mysterious Unhatched Egg
11420	Elegant Writing Tool
11422	Goblin Engineer's Renewal Gift
11423	Gnome Engineer's Renewal Gift
11444	Grim Guzzler Boar
11445	Flute of the Ancients
11446	A Crumpled Up Note
11462	Discarded Knife
11463	Undelivered Parcel
11464	Marshal Windsor's Lost Information
11465	Marshal Windsor's Lost Information
11466	Raschal's Report
11467	Blackrock Medallion
11468	Dark Iron Fanny Pack
11469	Bloodband Bracers
11470	Tablet Transcript
11471	Fragile Sprite Darter Egg
11472	Silvermane Stalker Flank
11473	PX83-Enigmatron
11474	Sprite Darter Egg
11475	Wine-stained Cloak
11476	U'cha's Pelt
11477	White Ravasaur Claw
11478	Un'Goro Gorilla Pelt
11479	Un'Goro Stomper Pelt
11480	Un'Goro Thunderer Pelt
11482	Crystal Pylon User's Manual
11502	Loreskin Shoulders
11503	Blood Amber
11504	Piece of Threshadon Carcass
11507	Spotted Hyena Pelt
11508	Gamemaster's Slippers
11509	Ravasaur Pheromone Gland
11510	Lar'korwi's Head
11511	Cenarion Beacon
11512	Patch of Tainted Skin
11513	Tainted Vitriol
11514	Fel Creep
11515	Corrupted Soul Shard
11516	Cenarion Plant Salve
11522	Silver Totem of Aquementas
11562	Crystal Restore
11563	Crystal Force
11564	Crystal Ward
11565	Crystal Yield
11566	Crystal Charge
11567	Crystal Spire
11568	Torwa's Pouch
11569	Preserved Threshadon Meat
11570	Preserved Pheromone Mixture
11582	Fel Salve
11583	Cactus Apple
11584	Cactus Apple Surprise
11590	Mechanical Repair Kit
11602	Grim Guzzler Key
11603	Vilerend Slicer
11604	Dark Iron Plate
11605	Dark Iron Shoulders
11606	Dark Iron Mail
11607	Dark Iron Sunderer
11608	Dark Iron Pulverizer
11609	Altered Black Dragonflight Molt
11610	Plans: Dark Iron Pulverizer
11611	Plans: Dark Iron Sunderer
11612	Plans: Dark Iron Plate
11613	DEBUG Samophlange Manual Cover
11614	Plans: Dark Iron Mail
11615	Plans: Dark Iron Shoulders
11616	DEBUG Samophlange Manual Page
11617	Eridan's Supplies
11622	Lesser Arcanum of Rumination
11623	Spritecaster Cape
11624	Kentic Amice
11625	Enthralled Sphere
11626	Blackveil Cape
11627	Fleetfoot Greaves
11628	Houndmaster's Bow
11629	Houndmaster's Rifle
11630	Rockshard Pellets
11631	Stoneshell Guard
11632	Earthslag Shoulders
11633	Spiderfang Carapace
11634	Silkweb Gloves
11635	Hookfang Shanker
11642	Lesser Arcanum of Constitution
11643	Lesser Arcanum of Tenacity
11644	Lesser Arcanum of Resilience
11645	Lesser Arcanum of Voracity
11646	Lesser Arcanum of Voracity
11647	Lesser Arcanum of Voracity
11648	Lesser Arcanum of Voracity
11649	Lesser Arcanum of Voracity
11662	Ban'thok Sash
11665	Ogreseer Fists
11668	Flute of Xavaric
11669	Naglering
11674	Jadefire Felbind
11675	Shadefiend Boots
11677	Graverot Cape
11678	Carapace of Anub'shiah
11679	Rubicund Armguards
11682	Eridan's Vial
11684	Ironfoe
11685	Splinthide Shoulders
11686	Girdle of Beastial Fury
11702	Grizzle's Skinner
11703	Stonewall Girdle
11722	Dregmetal Spaulders
11723	Goodsteel's Balanced Flameberge
11724	Overdue Package
11725	Solid Crystal Leg Shaft
11726	Savage Gladiator Chain
11727	Goodsteel Ledger
11728	Savage Gladiator Leggings
11729	Savage Gladiator Helm
11730	Savage Gladiator Grips
11731	Savage Gladiator Greaves
11732	Libram of Rumination
11733	Libram of Constitution
11734	Libram of Tenacity
11735	Ragefury Eyepatch
11736	Libram of Resilience
11737	Libram of Voracity
11742	Wayfarer's Knapsack
11743	Rockfist
11744	Bloodfist
11745	Fists of Phalanx
11746	Golem Skull Helm
11747	Flamestrider Robes
11748	Pyric Caduceus
11749	Searingscale Leggings
11750	Kindling Stave
11751	Burning Essence
11752	Black Blood of the Tormented
11753	Eye of Kajal
11754	Black Diamond
11755	Verek's Collar
11764	Cinderhide Armsplints
11765	Pyremail Wristguards
11766	Flameweave Cuffs
11767	Emberplate Armguards
11768	Incendic Bracers
11782	Boreal Mantle
11783	Chillsteel Girdle
11784	Arbiter's Blade
11785	Rock Golem Bulwark
11786	Stone of the Earth
11787	Shalehusk Boots
11802	Lavacrest Leggings
11803	Force of Magma
11804	Spraggle's Canteen
11805	Rubidium Hammer
11807	Sash of the Burning Heart
11808	Circle of Flame
11809	Flame Wrath
11810	Force of Will
11811	Smoking Heart of the Mountain
11812	Cape of the Fire Salamander
11813	Formula: Smoking Heart of the Mountain
11814	Molten Fists
11815	Hand of Justice
11816	Angerforge's Battle Axe
11817	Lord General's Sword
11818	Grimesilt Outhouse Key
11819	Second Wind
11820	Royal Decorated Armor
11821	Warstrife Leggings
11822	Omnicast Boots
11823	Luminary Kilt
11824	Cyclopean Band
11825	Pet Bombling
11826	Lil' Smoky
11827	Schematic: Lil' Smoky
11828	Schematic: Pet Bombling
11829	Un'Goro Ash
11830	Webbed Diemetradon Scale
11831	Webbed Pterrordax Scale
11832	Burst of Knowledge
11833	Gorishi Queen Lure
11834	Super Sticky Tar
11835	Gorishi Queen Brain
11837	Gorishi Scent Gland
11839	Chief Architect's Monocle
11840	Master Builder's Shirt
11841	Senior Designer's Pantaloons
11842	Lead Surveyor's Mantle
11843	Bank Voucher
11844	Pestlezugg's Un'Goro Report
11845	Handmade Leather Bag
11846	Wizbang's Special Brew
11847	Battered Cloak
11848	Flax Belt
11849	Rustmetal Bracers
11850	Short Duskbat Cape
11851	Scavenger Tunic
11852	Roamer's Leggings
11853	Rambling Boots
11854	Samophlange Screwdriver
11855	Tork Wrench
11856	Ceremonial Elven Blade
11857	Sanctimonial Rod
11858	Battlehard Cape
11859	Jademoon Orb
11860	Charged Lightning Rod
11861	Girdle of Reprisal
11862	White Bone Band
11863	White Bone Shredder
11864	White Bone Spear
11865	Rancor Boots
11866	Nagmara's Whipping Belt
11867	Maddening Gauntlets
11868	Choking Band
11869	Sha'ni's Ring
11870	Oblivion Orb
11871	Snarkshaw Spaulders
11872	Eschewal Greaves
11873	Ethereal Mist Cape
11874	Clouddrift Mantle
11875	Breezecloud Bracers
11876	Plainstalker Tunic
11882	Outrider Leggings
11883	A Dingy Fanny Pack
11884	Moonlit Amice
11885	Shadowforge Torch
11886	Urgent Message
11887	Cenarion Circle Cache
11888	Quintis' Research Gloves
11889	Bark Iron Pauldrons
11902	Linken's Sword of Mastery
11903	Cat Carrier (Corrupted Kitten)
11904	Spirit of Aquementas
11905	Linken's Boomerang
11906	Beastsmasher
11907	Beastslayer
11908	Archaeologist's Quarry Boots
11909	Excavator's Utility Belt
11910	Bejeweled Legguards
11911	Treetop Leggings
11912	Package of Empty Ooze Containers
11913	Clayridge Helm
11914	Empty Cursed Ooze Jar
11915	Shizzle's Drizzle Blocker
11916	Shizzle's Muzzle
11917	Shizzle's Nozzle Wiper
11918	Grotslab Gloves
11919	Cragplate Greaves
11920	Wraith Scythe
11921	Impervious Giant
11922	Blood-etched Blade
11923	The Hammer of Grace
11924	Robes of the Royal Crown
11925	Ghostshroud
11926	Deathdealer Breastplate
11927	Legplates of the Eternal Guardian
11928	Thaurissan's Royal Scepter
11929	Haunting Specter Leggings
11930	The Emperor's New Cape
11931	Dreadforge Retaliator
11932	Guiding Stave of Wisdom
11933	Imperial Jewel
11934	Emperor's Seal
11935	Magmus Stone
11936	Relic Hunter Belt
11937	Fat Sack of Coins
11938	Sack of Gems
11939	Shiny Bracelet
11940	Sparkly Necklace
11941	False Documents
11942	Legal Documents
11943	Deed to Thandol Span
11944	Dark Iron Baby Booties
11945	Dark Iron Ring
11946	Fire Opal Necklace
11947	Filled Cursed Ooze Jar
11948	Empty Tainted Ooze Jar
11949	Filled Tainted Ooze Jar
11950	Windblossom Berries
11951	Whipper Root Tuber
11952	Night Dragon's Breath
11953	Empty Pure Sample Jar
11954	Filled Pure Sample Jar
11955	Bag of Empty Ooze Containers
11962	Manacle Cuffs
11963	Penance Spaulders
11964	Swiftstrike Cudgel
11965	Quartz Ring
11966	Small Sack of Coins
11967	Zircon Band
11968	Amber Hoop
11969	Jacinth Circle
11970	Spinel Ring
11971	Amethyst Band
11972	Carnelian Loop
11973	Hematite Link
11974	Aquamarine Ring
11975	Topaz Ring
11976	Sardonyx Knuckle
11977	Serpentine Loop
11978	Jasper Link
11979	Peridot Circle
11980	Opal Ring
11981	Lead Band
11982	Viridian Band
11983	Chrome Ring
11984	Cobalt Ring
11985	Cerulean Ring
11986	Thallium Hoop
11987	Iridium Circle
11988	Tellurium Band
11989	Vanadium Loop
11990	Selenium Loop
11991	Quicksilver Ring
11992	Vermilion Band
11993	Clay Ring
11994	Coral Band
11995	Ivory Band
11996	Basalt Ring
11997	Greenstone Circle
11998	Jet Loop
11999	Lodestone Hoop
12000	Limb Cleaver
12001	Onyx Ring
12002	Marble Circle
12003	Dark Dwarven Lager
12004	Obsidian Band
12005	Granite Ring
12006	Meadow Ring
12007	Prairie Ring
12008	Savannah Ring
12009	Tundra Ring
12010	Fen Ring
12011	Forest Hoop
12012	Marsh Ring
12013	Desert Ring
12014	Arctic Ring
12015	Swamp Ring
12016	Jungle Ring
12017	Prismatic Band
12018	Conservator Helm
12019	Cerulean Talisman
12020	Thallium Choker
12021	Shieldplate Sabatons
12022	Iridium Chain
12023	Tellurium Necklace
12024	Vanadium Talisman
12025	Selenium Chain
12026	Quicksilver Pendant
12027	Vermilion Necklace
12028	Basalt Necklace
12029	Greenstone Talisman
12030	Jet Chain
12031	Lodestone Necklace
12032	Onyx Choker
12033	Thaurissan Family Jewels
12034	Marble Necklace
12035	Obsidian Pendant
12036	Granite Necklace
12037	Mystery Meat
12038	Lagrave's Seal
12039	Tundra Necklace
12040	Forest Pendant
12041	Windshear Leggings
12042	Marsh Chain
12043	Desert Choker
12044	Arctic Pendant
12045	Swamp Pendant
12046	Jungle Necklace
12047	Spectral Necklace
12048	Prismatic Pendant
12049	Splintsteel Armor
12050	Hazecover Boots
12051	Brazen Gauntlets
12052	Ring of the Moon
12053	Volcanic Rock Ring
12054	Demon Band
12055	Stardust Band
12056	Ring of the Heavens
12057	Dragonscale Band
12058	Demonic Bone Ring
12059	Conqueror's Medallion
12060	Shindrell's Note
12061	Blade of Reckoning
12062	Skilled Fighting Blade
12064	Gamemaster Hood
12065	Ward of the Elements
12066	Shaleskin Cape
12082	Wyrmhide Spaulders
12083	Valconian Sash
12102	Ring of the Aristocrat
12103	Star of Mystaria
12104	Brindlethorn Tunic
12105	Pridemail Leggings
12106	Boulderskin Breastplate
12107	Whispersilk Leggings
12108	Basaltscale Armor
12109	Azure Moon Amice
12110	Raincaster Drape
12111	Lavaplate Gauntlets
12112	Crypt Demon Bracers
12113	Sunborne Cape
12114	Nightfall Gloves
12115	Stalwart Clutch
12122	Kum'isha's Junk
12143	Dragonspine Key
12144	Eggscilloscope
12162	Plans: Hardened Iron Shortsword
12163	Plans: Moonsteel Broadsword
12164	Plans: Massive Iron Axe
12184	Raptor Flesh
12185	Bloodsail Admiral's Hat
12190	Dreamless Sleep Potion
12191	Silver Dawning's Lockbox
12192	Mist Veil's Lockbox
12202	Tiger Meat
12203	Red Wolf Meat
12204	Heavy Kodo Meat
12205	White Spider Meat
12206	Tender Crab Meat
12207	Giant Egg
12208	Tender Wolf Meat
12209	Lean Wolf Steak
12210	Roast Raptor
12211	Spiced Wolf Ribs
12212	Jungle Stew
12213	Carrion Surprise
12214	Mystery Stew
12215	Heavy Kodo Stew
12216	Spiced Chili Crab
12217	Dragonbreath Chili
12218	Monster Omelet
12219	Unadorned Seal of Ascension
12220	Intact Elemental Bracer
12223	Meaty Bat Wing
12224	Crispy Bat Wing
12225	Blump Family Fishing Pole
12226	Recipe: Crispy Bat Wing
12227	Recipe: Lean Wolf Steak
12228	Recipe: Roast Raptor
12229	Recipe: Hot Wolf Ribs
12230	Felwood Slime Sample
12231	Recipe: Jungle Stew
12232	Recipe: Carrion Surprise
12233	Recipe: Mystery Stew
12234	Corrupted Felwood Sample
12235	Un'Goro Slime Sample
12236	Pure Un'Goro Sample
12237	Fine Crab Chunks
12238	Darkshore Grouper
12239	Recipe: Dragonbreath Chili
12240	Recipe: Heavy Kodo Stew
12241	Collected Dragon Egg
12242	Sea Creature Bones
12243	Smoldering Claw
12247	Broad Bladed Knife
12248	Daring Dirk
12249	Merciless Axe
12250	Midnight Axe
12251	Big Stick
12252	Staff of Protection
12253	Brilliant Red Cloak
12254	Well Oiled Cloak
12255	Pale Leggings
12256	Cindercloth Leggings
12257	Heavy Notched Belt
12258	Serpent Clasp Belt
12259	Glinting Steel Dagger
12260	Searing Golden Blade
12261	Plans: Searing Golden Blade
12262	Empty Worg Pup Cage
12263	Caged Worg Pup
12264	Worg Carrier
12282	Worn Battleaxe
12283	Broodling Essence
12284	Draco-Incarcinatrix 900
12286	Eggscilloscope Prototype
12287	Collectronic Module
12288	Encased Corrupt Ooze
12289	Sea Turtle Remains
12291	Merged Ooze Sample
12292	Strangely Marked Box
12293	Fine Gold Thread
12295	Leggings of the People's Militia
12296	Spark of the People's Militia
12299	Netted Gloves
12300	Orb of Draconic Energy
12301	Bamboo Cage Key
12302	Reins of the Frostsaber
12303	Reins of the Nightsaber
12323	Unforged Seal of Ascension
12324	Forged Seal of Ascension
12325	Reins of the Primal Leopard
12326	Reins of the Tawny Sabercat
12327	Reins of the Golden Sabercat
12330	Horn of the Red Wolf
12334	Frostmaul Shards
12335	Gemstone of Smolderthorn
12336	Gemstone of Spirestone
12337	Gemstone of Bloodaxe
12339	Vaelan's Gift
12341	Blackwood Fruit Sample
12342	Blackwood Grain Sample
12343	Blackwood Nut Sample
12344	Seal of Ascension
12345	Bijou's Belongings
12346	Empty Cleansing Bowl
12347	Filled Cleansing Bowl
12349	Cliffspring River Sample
12350	Empty Sampling Tube
12351	Horn of the Arctic Wolf
12352	Doomrigger's Clasp
12353	White Stallion Bridle
12354	Palomino Bridle
12355	Talisman of Corruption
12356	Highperch Wyvern Egg
12358	Darkstone Tablet
12359	Thorium Bar
12360	Arcanite Bar
12361	Blue Sapphire
12363	Arcane Crystal
12364	Huge Emerald
12365	Dense Stone
12366	Thick Yeti Fur
12367	Pristine Yeti Horn
12368	Dawn's Gambit
12369	Scepter of Vectus
12382	Key to the City
12383	Moontouched Feather
12384	Cache of Mau'ari
12400	The Judge's Gavel
12402	Ancient Egg
12404	Dense Sharpening Stone
12405	Thorium Armor
12406	Thorium Belt
12408	Thorium Bracers
12409	Thorium Boots
12410	Thorium Helm
12411	Third Mosh'aru Tablet
12412	Fourth Mosh'aru Tablet
12414	Thorium Leggings
12415	Radiant Breastplate
12416	Radiant Belt
12417	Radiant Circlet
12418	Radiant Gloves
12419	Radiant Boots
12420	Radiant Leggings
12422	Imperial Plate Chest
12424	Imperial Plate Belt
12425	Imperial Plate Bracers
12426	Imperial Plate Boots
12427	Imperial Plate Helm
12428	Imperial Plate Shoulders
12429	Imperial Plate Leggings
12430	Frostsaber E'ko
12431	Winterfall E'ko
12432	Shardtooth E'ko
12433	Wildkin E'ko
12434	Chillwind E'ko
12435	Ice Thistle E'ko
12436	Frostmaul E'ko
12437	Ridgewell's Crate
12438	Tinkee's Letter
12440	Magic Knucklebone (DND)
12442	Charm Pouch (DND)
12443	Knucklebone Pouch (DND)
12444	Uncracked Chillwind Horn
12445	Felnok's Package
12446	Anvilmar Musket
12447	Thistlewood Bow
12448	Light Hunting Rifle
12449	Primitive Bow
12450	Juju Flurry
12451	Juju Power
12455	Juju Ember
12457	Juju Chill
12458	Juju Guile
12459	Juju Escape
12460	Juju Might
12462	Embrace of the Wind Serpent
12463	Drakefang Butcher
12464	Bloodfire Talons
12465	Nightfall Drape
12466	Dawnspire Cord
12467	Alien Egg
12468	Chilton Wand
12469	Mutilator
12470	Sandstalker Ankleguards
12471	Desertwalker Cane
12472	Krakle's Thermometer
12522	Bingles' Flying Gloves
12524	Blue-feathered Amulet
12525	Jaron's Supplies
12527	Ribsplitter
12528	The Judge's Gavel
12529	Smolderweb Carrier
12530	Spire Spider Egg
12531	Searing Needle
12532	Spire of the Stoneshaper
12533	Roughshod Pike
12534	Omokk's Head
12535	Doomforged Straightedge
12542	Funeral Pyre Vestment
12543	Songstone of Ironforge
12544	Thrall's Resolve
12545	Eye of Orgrimmar
12546	Aristocratic Cuffs
12547	Mar Alom's Grip
12548	Magni's Will
12549	Braincage
12550	Runed Golem Shackles
12551	Stoneshield Cloak
12552	Blisterbane Wrap
12553	Swiftwalker Boots
12554	Hands of the Exalted Herald
12555	Battlechaser's Greaves
12556	High Priestess Boots
12557	Ebonsteel Spaulders
12558	Blue-feathered Necklace
12562	Important Blackrock Documents
12563	Warlord Goretooth's Command
12564	Assassination Note
12565	Winna's Kitten Carrier
12566	Hardened Flasket
12567	Filled Flasket
12582	Keris of Zul'Serak
12583	Blackhand Doomsaw
12584	Grand Marshal's Longsword
12585	Stormwind Medallion
12586	Immature Venom Sac
12587	Eye of Rend
12588	Bonespike Shoulder
12589	Dustfeather Sash
12590	Felstriker
12592	Blackblade of Shahram
12602	Draconian Deflector
12603	Nightbrace Tunic
12604	Starfire Tiara
12605	Serpentine Skuller
12606	Crystallized Girdle
12607	Brilliant Chromatic Scale
12608	Butcher's Apron
12609	Polychromatic Visionwrap
12610	Runic Plate Shoulders
12611	Runic Plate Boots
12612	Runic Plate Helm
12613	Runic Breastplate
12614	Runic Plate Leggings
12615	Savage Mail Tunic
12616	Savage Mail Boots
12617	Savage Mail Shoulders
12618	Enchanted Thorium Breastplate
12619	Enchanted Thorium Leggings
12620	Enchanted Thorium Helm
12621	Demonfork
12622	Shardtooth Meat
12623	Chillwind Meat
12624	Wildthorn Mail
12625	Dawnbringer Shoulders
12626	Funeral Cuffs
12627	Temporal Displacer
12628	Demon Forged Breastplate
12630	Head of Rend Blackhand
12631	Fiery Plate Gauntlets
12632	Storm Gauntlets
12633	Whitesoul Helm
12634	Chiselbrand Girdle
12635	Simple Parchment
12636	Helm of the Great Chief
12637	Backusarian Gauntlets
12638	Andorhal Watch
12639	Stronghold Gauntlets
12640	Lionheart Helm
12641	Invulnerable Mail
12642	Cleansed Infernal Orb
12643	Dense Weightstone
12644	Dense Grinding Stone
12645	Thorium Shield Spike
12646	Infus Emerald
12647	Felhas Ruby
12648	Imprisoned Felhound Spirit
12649	Imprisoned Infernal Spirit
12650	Attuned Dampener
12651	Blackcrow
12652	Bijou's Reconnaissance Report
12653	Riphook
12654	Doomshot
12655	Enchanted Thorium Bar
12662	Demonic Rune
12663	Glyphed Oaken Branch
12682	Plans: Thorium Armor
12683	Plans: Thorium Belt
12684	Plans: Thorium Bracers
12685	Plans: Radiant Belt
12687	Plans: Imperial Plate Shoulders
12688	Plans: Imperial Plate Belt
12689	Plans: Radiant Breastplate
12690	Plans: Imperial Plate Bracers
12691	Plans: Wildthorn Mail
12692	Plans: Thorium Shield Spike
12693	Plans: Thorium Boots
12694	Plans: Thorium Helm
12695	Plans: Radiant Gloves
12696	Plans: Demon Forged Breastplate
12697	Plans: Radiant Boots
12698	Plans: Dawnbringer Shoulders
12699	Plans: Fiery Plate Gauntlets
12700	Plans: Imperial Plate Boots
12701	Plans: Imperial Plate Helm
12702	Plans: Radiant Circlet
12703	Plans: Storm Gauntlets
12704	Plans: Thorium Leggings
12705	Plans: Imperial Plate Chest
12706	Plans: Runic Plate Shoulders
12707	Plans: Runic Plate Boots
12708	Crossroads' Supply Crates
12709	Finkle's Skinner
12710	Glowing Hunk of the Beast's Flesh
12711	Plans: Whitesoul Helm
12712	Warosh's Mojo
12713	Plans: Radiant Leggings
12714	Plans: Runic Plate Helm
12715	Plans: Imperial Plate Leggings
12716	Plans: Helm of the Great Chief
12717	Plans: Lionheart Helm
12718	Plans: Runic Breastplate
12719	Plans: Runic Plate Leggings
12720	Plans: Stronghold Gauntlets
12721	Good Luck Half-Charm
12722	Good Luck Other-Half-Charm
12723	Good Luck Charm
12724	Janice's Parcel
12725	Plans: Enchanted Thorium Helm
12726	Plans: Enchanted Thorium Leggings
12727	Plans: Enchanted Thorium Breastplate
12728	Plans: Invulnerable Mail
12730	Warosh's Scroll
12731	Pristine Hide of the Beast
12732	Incendia Agave
12733	Sacred Frostsaber Meat
12734	Enchanted Scarlet Thread
12735	Frayed Abomination Stitching
12736	Frostwhisper's Embalming Fluid
12737	Gloom Weed
12738	Dalson Outhouse Key
12739	Dalson Cabinet Key
12740	Fifth Mosh'aru Tablet
12741	Sixth Mosh'aru Tablet
12752	Cap of the Scarlet Savant
12753	Skin of Shadow
12756	Leggings of Arcana
12757	Breastplate of Bloodthirst
12762	Secrecy of Plans
12763	Un'Goro Etherfruit
12764	Thorium Greatsword
12765	Secret Note #1
12766	Secret Note #2
12768	Secret Note #3
12769	Bleakwood Hew
12770	Bijou's Information
12771	Empty Firewater Flask
12772	Inlaid Thorium Hammer
12773	Ornate Thorium Handaxe
12774	Dawn's Edge
12775	Huge Thorium Battleaxe
12776	Enchanted Battlehammer
12777	Blazing Rapier
12778	Document Chest
12779	Rune Edge
12780	General Drakkisath's Command
12781	Serenity
12782	Corruption
12783	Heartseeker
12784	Arcanite Reaper
12785	Incendia Powder
12789	QATest Raid Buffs lvl 60
12790	Arcanite Champion
12791	Barman Shanker
12792	Volcanic Hammer
12793	Mixologist's Tunic
12794	Masterwork Stormhammer
12795	Blood Talon
12796	Hammer of the Titans
12797	Frostguard
12798	Annihilator
12799	Large Opal
12800	Azerothian Diamond
12802	Darkspear
12803	Living Essence
12804	Powerful Mojo
12805	Orb of Fire
12806	Unforged Rune Covered Breastplate
12807	Scourge Banner
12808	Essence of Undeath
12809	Guardian Stone
12810	Enchanted Leather
12811	Righteous Orb
12812	Unfired Plate Gauntlets
12813	Flask of Mystery Goo
12814	Flame in a Bottle
12815	Beacon Torch
12816	Plans: Thorium Greatsword
12817	Plans: Bleakwood Hew
12818	Plans: Inlaid Thorium Hammer
12819	Plans: Ornate Thorium Handaxe
12820	Winterfall Firewater
12821	Plans: Dawn's Edge
12822	Toxic Horror Droplet
12823	Plans: Huge Thorium Battleaxe
12824	Plans: Enchanted Battlehammer
12825	Plans: Blazing Rapier
12826	Plans: Rune Edge
12827	Plans: Serenity
12828	Plans: Volcanic Hammer
12829	Winterfall Crate
12830	Plans: Corruption
12831	Plans: Blood Talon
12832	Plans: Darkspear
12833	Plans: Hammer of the Titans
12834	Plans: Arcanite Champion
12835	Plans: Annihilator
12836	Plans: Frostguard
12837	Plans: Masterwork Stormhammer
12838	Plans: Arcanite Reaper
12839	Plans: Heartseeker
12840	Minion's Scourgestone
12841	Invader's Scourgestone
12842	Crudely-written Log
12843	Corruptor's Scourgestone
12844	Argent Dawn Valor Token
12845	Medallion of Faith
12846	Argent Dawn Commission
12847	Soul Stained Pike
12848	Blood Stained Pike
12849	Demon Kissed Sack
12866	Jade Bracers
12871	Chromatic Carapace
12884	Arnak's Hoof
12885	Pamela's Doll
12886	Pamela's Doll's Head
12887	Pamela's Doll's Left Side
12888	Pamela's Doll's Right Side
12891	Jaron's Pick
12894	Joseph's Wedding Ring
12895	Breastplate of the Chromatic Flight
12896	First Relic Fragment
12897	Second Relic Fragment
12898	Third Relic Fragment
12899	Fourth Relic Fragment
12900	Annals of Darrowshire
12903	Legguards of the Chromatic Defier
12904	Shawn's Super Special Swami Hat
12905	Wildfire Cape
12906	Purified Moonwell Water
12907	Corrupt Moonwell Water
12922	Empty Canteen
12923	Awbee's Scale
12924	Ritual Candle
12925	Arikara Serpent Skin
12926	Flaming Band
12927	Truestrike Shoulders
12928	Umi's Mechanical Yeti
12929	Emberfury Talisman
12930	Briarwood Reed
12935	Warmaster Legguards
12936	Battleborn Armbraces
12938	Blood of Heroes
12939	Dal'Rend's Tribal Guardian
12940	Dal'Rend's Sacred Charge
12942	Panther Cage Key
12945	Legplates of the Chromatic Defier
12946	Hypercapacitor Gizmo
12947	Alex's Ring of Audacity
12952	Gyth's Skull
12953	Dragoneye Coif
12954	Davil's Libram
12955	Redpath's Shield
12956	Skull of Horgus
12957	Shattered Sword of Marduk
12958	Recipe: Transmute Arcanite
12960	Tribal War Feathers
12963	Blademaster Leggings
12964	Tristam Legguards
12965	Spiritshroud Leggings
12966	Blackmist Armguards
12967	Bloodmoon Cloak
12968	Frostweaver Cape
12969	Seeping Willow
12970	General's Ceremonial Plate
12973	Scarlet Cannonball
12974	The Black Knight
12975	Prospector Axe
12976	Ironpatch Blade
12977	Magefist Gloves
12978	Stormbringer Belt
12979	Firebane Cloak
12982	Silver-linked Footguards
12983	Rakzur Club
12984	Skycaller
12985	Ring of Defense
12987	Darkweave Breeches
12988	Starsight Tunic
12989	Gargoyle's Bite
12990	Razor's Edge
12992	Searing Blade
12994	Thorbia's Gauntlets
12996	Band of Purification
12997	Redbeard Crest
12998	Magician's Mantle
12999	Drakewing Bands
13000	Staff of Hale Magefire
13001	Maiden's Circle
13002	Lady Alizabeth's Pendant
13003	Lord Alexander's Battle Axe
13004	Torch of Austen
13005	Amy's Blanket
13006	Mass of McGowan
13007	Mageflame Cloak
13008	Dalewind Trousers
13009	Cow King's Hide
13010	Dreamsinger Legguards
13011	Silver-lined Belt
13012	Yorgen Bracers
13013	Elder Wizard's Mantle
13014	Axe of Rin'ji
13015	Serathil
13016	Killmaim
13017	Hellslayer Battle Axe
13018	Executioner's Cleaver
13019	Harpyclaw Short Bow
13020	Skystriker Bow
13021	Needle Threader
13022	Gryphonwing Long Bow
13023	Eaglehorn Long Bow
13024	Beazel's Basher
13025	Deadwood Sledge
13026	Heaven's Light
13027	Bonesnapper
13028	Bludstone Hammer
13029	Umbral Crystal
13030	Basilisk Bone
13031	Orb of Mistmantle
13032	Sword of Corruption
13033	Zealot Blade
13034	Speedsteel Rapier
13035	Serpent Slicer
13036	Assassination Blade
13037	Crystalpine Stinger
13038	Swiftwind
13039	Skull Splitting Crossbow
13040	Heartseeking Crossbow
13041	Guardian Blade
13042	Sword of the Magistrate
13043	Blade of the Titans
13044	Demonslayer
13045	Viscous Hammer
13046	Blanchard's Stout
13047	Twig of the World Tree
13048	Looming Gavel
13049	Deanship Claymore
13051	Witchfury
13052	Warmonger
13053	Doombringer
13054	Grim Reaper
13055	Bonechewer
13056	Frenzied Striker
13057	Bloodpike
13058	Khoo's Point
13059	Stoneraven
13060	The Needler
13062	Thunderwood
13063	Starfaller
13064	Jaina's Firestarter
13065	Wand of Allistarj
13066	Wyrmslayer Spaulders
13067	Hydralick Armor
13068	Obsidian Greaves
13070	Sapphiron's Scale Boots
13071	Plated Fist of Hakoo
13072	Stonegrip Gauntlets
13073	Mugthol's Helm
13074	Golem Shard Leggings
13075	Direwing Legguards
13076	Giantslayer Bracers
13077	Girdle of Uther
13079	Shield of Thorsen
13080	Widow's Clutch
13081	Skullance Shield
13082	Mountainside Buckler
13083	Garrett Family Crest
13084	Kaleidoscope Chain
13085	Horizon Choker
13086	Reins of the Winterspring Frostsaber
13087	River Pride Choker
13088	Gazlowe's Charm
13089	Skibi's Pendant
13090	Breastplate of the Chosen
13091	Medallion of Grand Marshal Morris
13092	Dragonstalker Tunic
13093	Blush Ember Ring
13094	The Queen's Jewel
13095	Assault Band
13096	Band of the Hierophant
13097	Thunderbrow Ring
13098	Painweaver Band
13099	Moccasins of the White Hare
13100	Furen's Boots
13101	Wolfrunner Shoes
13102	Cassandra's Grace
13103	Pads of the Venom Spider
13105	Sutarn's Ring
13106	Glowing Magical Bracelets
13107	Magiskull Cuffs
13108	Tigerstrike Mantle
13109	Blackflame Cape
13110	Wolffear Harness
13111	Sandals of the Insurgent
13112	Winged Helm
13113	Feathermoon Headdress
13114	Troll's Bane Leggings
13115	Sheepshear Mantle
13116	Spaulders of the Unseen
13117	Ogron's Sash
13118	Serpentine Sash
13119	Enchanted Kodo Bracers
13120	Deepfury Bracers
13121	Wing of the Whelpling
13122	Dark Phantom Cape
13123	Dreamwalker Armor
13124	Ravasaur Scale Boots
13125	Elven Chain Boots
13126	Battlecaller Gauntlets
13127	Frostreaver Crown
13128	High Bergg Helm
13129	Firemane Leggings
13130	Windrunner Legguards
13131	Sparkleshell Mantle
13132	Skeletal Shoulders
13133	Drakesfire Epaulets
13134	Belt of the Gladiator
13135	Lordly Armguards
13136	Lil Timmy's Peashooter
13137	Ironweaver
13138	The Silencer
13139	Guttbuster
13140	Blood Red Key
13141	Tooth of Gnarr
13142	Brigam Girdle
13143	Mark of the Dragon Lord
13144	Serenity Belt
13145	Enormous Ogre Belt
13146	Shell Launcher Shotgun
13148	Chillpike
13149	Eldarathian Tome of Summoning Vol. 1
13151	The Mystic Studies of Hor'ank
13152	The Story With No Conclusion
13153	Tome of Mal'cin Vorail
13154	Jael'marin's Studies of the Arcane
13155	Resonating Skull
13156	Mystic Crystal
13157	Fetid Skull
13158	Words of the High Chief
13159	Bone Dust
13161	Trindlehaven Staff
13162	Reiver Claws
13163	Relentless Scythe
13164	Heart of the Scale
13166	Slamshot Shoulders
13167	Fist of Omokk
13168	Plate of the Shaman King
13169	Tressermane Leggings
13170	Skyshroud Leggings
13171	Smokey's Lighter
13172	Siabi's Premium Tobacco
13173	Flightblade Throwing Axe
13174	Plagued Flesh Sample
13175	Voone's Twitchbow
13176	Scourge Data
13177	Talisman of Evasion
13178	Rosewine Circle
13179	Brazecore Armguards
13180	Stratholme Holy Water
13181	Demonskin Gloves
13182	Phase Blade
13183	Venomspitter
13184	Fallbrush Handgrips
13185	Sunderseer Mantle
13186	Empty Felstone Field Bottle
13187	Empty Dalson's Tears Bottle
13188	Empty Writhing Haunt Bottle
13189	Empty Gahrron's Withering Bottle
13190	Filled Felstone Field Bottle
13191	Filled Dalson's Tears Bottle
13192	Filled Writhing Haunt Bottle
13193	Filled Gahrron's Withering Bottle
13194	Felstone Field Cauldron Key
13195	Dalson's Tears Cauldron Key
13196	Gahrron's Withering Cauldron Key
13197	Writhing Haunt Cauldron Key
13198	Hurd Smasher
13199	Crushridge Bindings
13202	Extended Annals of Darrowshire
13203	Armswake Cloak
13204	Bashguuder
13205	Rhombeard Protector
13206	Wolfshear Leggings
13207	Shadow Lord Fel'dan's Head
13208	Bleak Howler Armguards
13209	Seal of the Dawn
13210	Pads of the Dread Wolf
13211	Slashclaw Bracers
13212	Halycon's Spiked Collar
13213	Smolderweb's Eye
13216	Crown of the Penitent
13217	Band of the Penitent
13218	Fang of the Crystal Spider
13223	Stratholme Courier's Pouch
13243	Argent Defender
13244	Gilded Gauntlets
13245	Kresh's Back
13246	Argent Avenger
13247	Quartermaster Zigris' Footlocker
13248	Burstshot Harquebus
13249	Argent Crusader
13250	Head of Balnazzar
13251	Head of Baron Rivendare
13252	Cloudrunner Girdle
13253	Hands of Power
13254	Astral Guard
13255	Trueaim Gauntlets
13257	Demonic Runed Spaulders
13258	Slaghide Gauntlets
13259	Ribsteel Footguards
13260	Wind Dancer Boots
13261	Globe of D'sak
13262	Ashbringer
13282	Ogreseer Tower Boots
13283	Magus Ring
13284	Swiftdart Battleboots
13285	The Nicker
13286	Rivenspike
13287	Pattern: Raptor Hide Harness
13288	Pattern: Raptor Hide Belt
13289	Egan's Blaster
13302	Market Row Postbox Key
13303	Crusaders' Square Postbox Key
13304	Festival Lane Postbox Key
13305	Elders' Square Postbox Key
13306	King's Square Postbox Key
13307	Fras Siabi's Postbox Key
13308	Schematic: Ice Deflector
13309	Schematic: Lovingly Crafted Boomstick
13310	Schematic: Accurate Scope
13311	Schematic: Mechanical Dragonling
13313	Sacred Highborne Writings
13314	Alanna's Embrace
13315	Testament of Hope
13317	Whistle of the Ivory Raptor
13320	Arcane Quickener
13321	Green Mechanostrider
13322	Unpainted Mechanostrider
13323	Purple Mechanostrider
13324	Red and Blue Mechanostrider
13325	Fluorescent Green Mechanostrider
13326	White Mechanostrider Mod A
13327	Icy Blue Mechanostrider Mod A
13328	Black Ram
13329	Frost Ram
13330	Derek's Radish Bag
13331	Red Skeletal Horse
13332	Blue Skeletal Horse
13333	Brown Skeletal Horse
13334	Green Skeletal Warhorse
13335	Deathcharger's Reins
13340	Cape of the Black Baron
13342	Pet Fish
13343	Pet Stone
13344	Dracorian Gauntlets
13345	Seal of Rivendare
13346	Robes of the Exalted
13347	Crystal of Zin-Malor
13348	Demonshear
13349	Scepter of the Unholy
13350	Insignia of the Black Guard
13351	Crimson Hammersmith's Apron
13352	Vosh'gajin's Snakestone
13353	Book of the Dead
13354	Ectoplasmic Resonator
13356	Somatic Intensifier
13357	Osseous Agitator
13358	Wyrmtongue Shoulders
13359	Crown of Tyranny
13360	Gift of the Elven Magi
13361	Skullforge Reaver
13362	Letter from the Front
13363	Municipal Proclamation
13364	Fras Siabi's Advertisement
13365	Town Meeting Notice
13366	Ingenious Toy
13367	Wrapped Gift
13368	Bonescraper
13369	Fire Striders
13370	Vitreous Focuser
13371	Father Flame
13372	Slavedriver's Cane
13373	Band of Flesh
13374	Soulstealer Mantle
13375	Crest of Retribution
13376	Royal Tribunal Cloak
13377	Miniature Cannon Balls
13378	Songbird Blouse
13379	Piccolo of the Flaming Fire
13380	Willey's Portable Howitzer
13381	Master Cannoneer Boots
13382	Cannonball Runner
13383	Woollies of the Prancing Minstrel
13384	Rainbow Girdle
13385	Tome of Knowledge
13386	Archivist Cape
13387	Foresight Girdle
13388	The Postmaster's Tunic
13389	The Postmaster's Trousers
13390	The Postmaster's Band
13391	The Postmaster's Treads
13392	The Postmaster's Seal
13393	Malown's Slam
13394	Skul's Cold Embrace
13395	Skul's Fingerbone Claws
13396	Skul's Ghastly Touch
13397	Stoneskin Gargoyle Cape
13398	Boots of the Shrieker
13399	Gargoyle Shredder Talons
13400	Vambraces of the Sadist
13401	The Cruel Hand of Timmy
13402	Timmy's Galoshes
13403	Grimgore Noose
13404	Mask of the Unforgiven
13405	Wailing Nightbane Pauldrons
13408	Soul Breaker
13409	Tearfall Bracers
13422	Stonescale Eel
13423	Stonescale Oil
13442	Mighty Rage Potion
13443	Superior Mana Potion
13444	Major Mana Potion
13445	Elixir of Superior Defense
13446	Major Healing Potion
13447	Elixir of the Sages
13448	The Deed to Caer Darrow
13450	The Deed to Southshore
13451	The Deed to Tarren Mill
13452	Elixir of the Mongoose
13453	Elixir of Brute Force
13454	Greater Arcane Elixir
13455	Greater Stoneshield Potion
13456	Greater Frost Protection Potion
13457	Greater Fire Protection Potion
13458	Greater Nature Protection Potion
13459	Greater Shadow Protection Potion
13460	Greater Holy Protection Potion
13461	Greater Arcane Protection Potion
13462	Purification Potion
13463	Dreamfoil
13464	Golden Sansam
13465	Mountain Silversage
13466	Plaguebloom
13467	Icecap
13468	Black Lotus
13469	Head of Weldon Barov
13470	Head of Alexi Barov
13471	The Deed to Brill
13473	Felstone Good Luck Charm
13474	Farmer Dalson's Shotgun
13475	Dalson Family Wedding Ring
13476	Recipe: Mighty Rage Potion
13477	Recipe: Superior Mana Potion
13478	Recipe: Elixir of Superior Defense
13479	Recipe: Elixir of the Sages
13480	Recipe: Major Healing Potion
13481	Recipe: Elixir of Brute Force
13482	Recipe: Transmute Air to Fire
13483	Recipe: Transmute Fire to Earth
13484	Recipe: Transmute Earth to Water
13485	Recipe: Transmute Water to Air
13486	Recipe: Transmute Undeath to Water
13487	Recipe: Transmute Water to Undeath
13488	Recipe: Transmute Life to Earth
13489	Recipe: Transmute Earth to Life
13490	Recipe: Greater Stoneshield Potion
13491	Recipe: Elixir of the Mongoose
13492	Recipe: Purification Potion
13493	Recipe: Greater Arcane Elixir
13494	Recipe: Greater Fire Protection Potion
13495	Recipe: Greater Frost Protection Potion
13496	Recipe: Greater Nature Protection Potion
13497	Recipe: Greater Arcane Protection Potion
13498	Handcrafted Mastersmith Leggings
13499	Recipe: Greater Shadow Protection Potion
13500	Recipe: Greater Holy Protection Potion
13501	Recipe: Major Mana Potion
13502	Handcrafted Mastersmith Girdle
13503	Alchemist's Stone
13505	Runeblade of Baron Rivendare
13506	Flask of Petrification
13507	Cliffwatcher Longhorn Report
13508	Eye of Arachnida
13509	Clutch of Foresight
13510	Flask of the Titans
13511	Flask of Distilled Wisdom
13512	Flask of Supreme Power
13513	Flask of Chromatic Resistance
13514	Wail of the Banshee
13515	Ramstein's Lightning Bolts
13517	Recipe: Alchemist's Stone
13518	Recipe: Flask of Petrification
13519	Recipe: Flask of the Titans
13520	Recipe: Flask of Distilled Wisdom
13521	Recipe: Flask of Supreme Power
13522	Recipe: Flask of Chromatic Resistance
13523	Blood of Innocents
13524	Skull of Burning Shadows
13525	Darkbind Fingers
13526	Flamescarred Girdle
13527	Lavawalker Greaves
13528	Twilight Void Bracers
13529	Husk of Nerub'enkan
13530	Fangdrip Runners
13531	Crypt Stalker Leggings
13532	Darkspinner Claws
13533	Acid-etched Pauldrons
13534	Banshee Finger
13535	Coldtouch Phantom Wraps
13536	Horn of Awakening
13537	Chillhide Bracers
13538	Windshrieker Pauldrons
13539	Banshee's Touch
13542	Demon Box
13544	Spectral Essence
13545	Shellfish
13546	Bloodbelly Fish
13562	Remains of Trey Lightforge
13582	Zergling Leash
13583	Panda Collar
13584	Diablo Stone
13585	Keepsake of Remembrance
13602	Greater Spellstone
13603	Major Spellstone
13624	Soulbound Keepsake
13626	Human Head of Ras Frostwhisper
13699	Firestone
13700	Greater Firestone
13701	Major Firestone
13702	Doom Weed
13703	Kodo Bone
13704	Skeleton Key
13724	Enriched Manna Biscuit
13725	Krastinov's Bag of Horrors
13752	Soulbound Keepsake
13754	Raw Glossy Mightfish
13755	Winter Squid
13756	Raw Summer Bass
13757	Lightning Eel
13758	Raw Redgill
13759	Raw Nightfin Snapper
13760	Raw Sunscale Salmon
13761	Frozen Eggs
13810	Blessed Sunfruit
13811	Necklace of the Dawn
13812	Ring of the Dawn
13813	Blessed Sunfruit Juice
13815	Some Rune
13816	Fine Longsword
13817	Tapered Greatsword
13818	Jagged Axe
13819	Balanced War Axe
13820	Clout Mace
13821	Bulky Maul
13822	Spiked Dagger
13823	Stout War Staff
13824	Recurve Long Bow
13825	Primed Musket
13842	Fall/Winter Morning
13843	Fall/Winter Afternoon
13844	Fall/Winter Evening
13845	Fall/Winter Night
13846	Spring/Summer Morning
13847	Spring/Summer Afternoon
13848	Spring/Summer Evening
13849	Spring/Summer Night
13850	Rumbleshot's Ammo
13851	Hot Wolf Ribs
13852	The Grand Crusader's Command
13853	Slab of Carrion Worm Meat
13856	Runecloth Belt
13857	Runecloth Tunic
13858	Runecloth Robe
13860	Runecloth Cloak
13863	Runecloth Gloves
13864	Runecloth Boots
13865	Runecloth Pants
13866	Runecloth Headband
13867	Runecloth Shoulders
13868	Frostweave Robe
13869	Frostweave Tunic
13870	Frostweave Gloves
13871	Frostweave Pants
13872	Bundle of Wood
13873	Viewing Room Key
13874	Heavy Crate
13875	Ironbound Locked Chest
13876	40 Pound Grouper
13877	47 Pound Grouper
13878	53 Pound Grouper
13879	59 Pound Grouper
13880	68 Pound Grouper
13881	Bloated Redgill
13882	42 Pound Redgill
13883	45 Pound Redgill
13884	49 Pound Redgill
13885	34 Pound Redgill
13886	37 Pound Redgill
13887	52 Pound Redgill
13888	Darkclaw Lobster
13889	Raw Whitescale Salmon
13890	Plated Armorfish
13891	Bloated Salmon
13892	Kodo Kombobulator
13893	Large Raw Mightfish
13895	Formal Dangui
13896	Dark Green Wedding Hanbok
13897	White Traditional Hanbok
13898	Royal Dangui
13899	Red Traditional Hanbok
13900	Green Wedding Hanbok
13901	15 Pound Salmon
13902	18 Pound Salmon
13903	22 Pound Salmon
13904	25 Pound Salmon
13905	29 Pound Salmon
13906	32 Pound Salmon
13907	7 Pound Lobster
13908	9 Pound Lobster
13909	12 Pound Lobster
13910	15 Pound Lobster
13911	19 Pound Lobster
13912	21 Pound Lobster
13913	22 Pound Lobster
13914	70 Pound Mightfish
13915	85 Pound Mightfish
13916	92 Pound Mightfish
13917	103 Pound Mightfish
13918	Reinforced Locked Chest
13920	Healthy Dragon Scale
13926	Golden Pearl
13927	Cooked Glossy Mightfish
13928	Grilled Squid
13929	Hot Smoked Bass
13930	Filet of Redgill
13931	Nightfin Soup
13932	Poached Sunscale Salmon
13933	Lobster Stew
13934	Mightfish Steak
13935	Baked Salmon
13936	Dreadmaster's Shroud
13937	Headmaster's Charge
13938	Bonecreeper Stylus
13939	Recipe: Spotted Yellowtail
13940	Recipe: Cooked Glossy Mightfish
13941	Recipe: Filet of Redgill
13942	Recipe: Grilled Squid
13943	Recipe: Hot Smoked Bass
13944	Tombstone Breastplate
13945	Recipe: Nightfin Soup
13946	Recipe: Poached Sunscale Salmon
13947	Recipe: Lobster Stew
13948	Recipe: Mightfish Steak
13949	Recipe: Baked Salmon
13950	Detention Strap
13951	Vigorsteel Vambraces
13952	Iceblade Hacker
13953	Silent Fang
13954	Verdant Footpads
13955	Stoneform Shoulders
13956	Clutch of Andros
13957	Gargoyle Slashers
13958	Wyrmthalak's Shackles
13959	Omokk's Girth Restrainer
13960	Heart of the Fiend
13961	Halycon's Muzzle
13962	Vosh'gajin's Strand
13963	Voone's Vice Grips
13964	Witchblade
13965	Blackhand's Breadth
13966	Mark of Tyranny
13967	Windreaver Greaves
13968	Eye of the Beast
13969	Loomguard Armbraces
13982	Warblade of Caer Darrow
13983	Gravestone War Axe
13984	Darrowspike
13986	Crown of Caer Darrow
14002	Darrowshire Strongguard
14022	Barov Peasant Caller
14023	Barov Peasant Caller
14024	Frightalon
14025	Mystic's Belt
14042	Cindercloth Vest
14043	Cindercloth Gloves
14044	Cindercloth Cloak
14045	Cindercloth Pants
14046	Runecloth Bag
14047	Runecloth
14048	Bolt of Runecloth
14062	Kodo Mount
14083	Tyrande's Staff
14086	Beaded Sandals
14087	Beaded Cuffs
14088	Beaded Cloak
14089	Beaded Gloves
14090	Beaded Britches
14091	Beaded Robe
14093	Beaded Cord
14094	Beaded Wraps
14095	Native Bands
14096	Native Vest
14097	Native Pants
14098	Native Cloak
14099	Native Sash
14100	Brightcloth Robe
14101	Brightcloth Gloves
14102	Native Handwraps
14103	Brightcloth Cloak
14104	Brightcloth Pants
14106	Felcloth Robe
14107	Felcloth Pants
14108	Felcloth Boots
14109	Native Robe
14110	Native Sandals
14111	Felcloth Hood
14112	Felcloth Shoulders
14113	Aboriginal Sash
14114	Aboriginal Footwraps
14115	Aboriginal Bands
14116	Aboriginal Cape
14117	Aboriginal Gloves
14119	Aboriginal Loincloth
14120	Aboriginal Robe
14121	Aboriginal Vest
14122	Ritual Bands
14123	Ritual Cape
14124	Ritual Gloves
14125	Ritual Leggings
14126	Ritual Amice
14127	Ritual Shroud
14128	Wizardweave Robe
14129	Ritual Sandals
14130	Wizardweave Turban
14131	Ritual Belt
14132	Wizardweave Leggings
14133	Ritual Tunic
14134	Cloak of Fire
14136	Robe of Winter Night
14137	Mooncloth Leggings
14138	Mooncloth Vest
14139	Mooncloth Shoulders
14140	Mooncloth Circlet
14141	Ghostweave Vest
14142	Ghostweave Gloves
14143	Ghostweave Belt
14144	Ghostweave Pants
14145	Cursed Felblade
14146	Gloves of Spell Mastery
14147	Cavedweller Bracers
14148	Crystalline Cuffs
14149	Subterranean Cape
14150	Robe of Evocation
14151	Chanting Blade
14152	Robe of the Archmage
14153	Robe of the Void
14154	Truefaith Vestments
14155	Mooncloth Bag
14156	Bottomless Bag
14157	Pagan Mantle
14158	Pagan Vest
14159	Pagan Shoes
14160	Pagan Bands
14161	Pagan Cape
14162	Pagan Mitts
14163	Pagan Wraps
14164	Pagan Belt
14165	Pagan Britches
14166	Buccaneer's Bracers
14167	Buccaneer's Cape
14168	Buccaneer's Gloves
14169	Aboriginal Shoulder Pads
14170	Buccaneer's Mantle
14171	Buccaneer's Pants
14172	Buccaneer's Robes
14173	Buccaneer's Cord
14174	Buccaneer's Boots
14175	Buccaneer's Vest
14176	Watcher's Boots
14177	Watcher's Cuffs
14178	Watcher's Cap
14179	Watcher's Cape
14180	Watcher's Jerkin
14181	Watcher's Handwraps
14182	Watcher's Mantle
14183	Watcher's Leggings
14184	Watcher's Robes
14185	Watcher's Cinch
14186	Raincaller Mantle
14187	Raincaller Cuffs
14188	Raincaller Cloak
14189	Raincaller Cap
14190	Raincaller Vest
14191	Raincaller Mitts
14192	Raincaller Robes
14193	Raincaller Pants
14194	Raincaller Cord
14195	Raincaller Boots
14196	Thistlefur Sandals
14197	Thistlefur Bands
14198	Thistlefur Cloak
14199	Thistlefur Gloves
14200	Thistlefur Cap
14201	Thistlefur Mantle
14202	Thistlefur Jerkin
14203	Thistlefur Pants
14204	Thistlefur Robe
14205	Thistlefur Belt
14206	Vital Bracelets
14207	Vital Leggings
14208	Vital Headband
14209	Vital Sash
14210	Vital Cape
14211	Vital Handwraps
14212	Vital Shoulders
14213	Vital Raiment
14214	Vital Boots
14215	Vital Tunic
14216	Geomancer's Jerkin
14217	Geomancer's Cord
14218	Geomancer's Boots
14219	Geomancer's Cloak
14220	Geomancer's Cap
14221	Geomancer's Bracers
14222	Geomancer's Gloves
14223	Geomancer's Spaulders
14224	Geomancer's Trousers
14225	Geomancer's Wraps
14226	Embersilk Bracelets
14227	Ironweb Spider Silk
14228	Embersilk Coronet
14229	Embersilk Cloak
14230	Embersilk Tunic
14231	Embersilk Mitts
14232	Embersilk Mantle
14233	Embersilk Leggings
14234	Embersilk Robes
14235	Embersilk Cord
14236	Embersilk Boots
14237	Darkmist Armor
14238	Darkmist Boots
14239	Darkmist Cape
14240	Darkmist Bands
14241	Darkmist Handguards
14242	Darkmist Pants
14243	Darkmist Mantle
14244	Darkmist Wraps
14245	Darkmist Girdle
14246	Darkmist Wizard Hat
14247	Lunar Mantle
14248	Lunar Bindings
14249	Lunar Vest
14250	Lunar Slippers
14251	Lunar Cloak
14252	Lunar Coronet
14253	Lunar Handwraps
14254	Lunar Raiment
14255	Lunar Belt
14256	Felcloth
14257	Lunar Leggings
14258	Bloodwoven Cord
14259	Bloodwoven Boots
14260	Bloodwoven Bracers
14261	Bloodwoven Cloak
14262	Bloodwoven Mitts
14263	Bloodwoven Mask
14264	Bloodwoven Pants
14265	Bloodwoven Wraps
14266	Bloodwoven Pads
14267	Bloodwoven Jerkin
14268	Gaea's Cuffs
14269	Gaea's Slippers
14270	Gaea's Cloak
14271	Gaea's Circlet
14272	Gaea's Handwraps
14273	Gaea's Amice
14274	Gaea's Leggings
14275	Gaea's Raiment
14276	Gaea's Belt
14277	Gaea's Tunic
14278	Opulent Mantle
14279	Opulent Bracers
14280	Opulent Cape
14281	Opulent Crown
14282	Opulent Gloves
14283	Opulent Leggings
14284	Opulent Robes
14285	Opulent Boots
14286	Opulent Belt
14287	Opulent Tunic
14288	Arachnidian Armor
14289	Arachnidian Girdle
14290	Arachnidian Footpads
14291	Arachnidian Bracelets
14292	Arachnidian Cape
14293	Arachnidian Circlet
14294	Arachnidian Gloves
14295	Arachnidian Legguards
14296	Arachnidian Pauldrons
14297	Arachnidian Robes
14298	Bonecaster's Spaulders
14299	Bonecaster's Boots
14300	Bonecaster's Cape
14301	Bonecaster's Bindings
14302	Bonecaster's Gloves
14303	Bonecaster's Shroud
14304	Bonecaster's Belt
14305	Bonecaster's Sarong
14306	Bonecaster's Vest
14307	Bonecaster's Crown
14308	Celestial Tunic
14309	Celestial Belt
14310	Celestial Slippers
14311	Celestial Bindings
14312	Celestial Crown
14313	Celestial Cape
14314	Celestial Handwraps
14315	Celestial Kilt
14316	Celestial Pauldrons
14317	Celestial Silk Robes
14318	Resplendent Tunic
14319	Resplendent Boots
14320	Resplendent Bracelets
14321	Resplendent Cloak
14322	Resplendent Circlet
14323	Resplendent Gauntlets
14324	Resplendent Sarong
14325	Resplendent Epaulets
14326	Resplendent Robes
14327	Resplendent Belt
14328	Eternal Chestguard
14329	Eternal Boots
14330	Eternal Bindings
14331	Eternal Cloak
14332	Eternal Crown
14333	Eternal Gloves
14334	Eternal Sarong
14335	Eternal Spaulders
14336	Eternal Wraps
14337	Eternal Cord
14338	Empty Water Tube
14339	Moonwell Water Tube
14340	Freezing Lich Robes
14341	Rune Thread
14342	Mooncloth
14343	Small Brilliant Shard
14344	Large Brilliant Shard
14364	Mystic's Slippers
14365	Mystic's Cape
14366	Mystic's Bracelets
14367	Mystic's Gloves
14368	Mystic's Shoulder Pads
14369	Mystic's Wrap
14370	Mystic's Woolies
14371	Mystic's Robe
14372	Sanguine Armor
14373	Sanguine Belt
14374	Sanguine Sandals
14375	Sanguine Cuffs
14376	Sanguine Cape
14377	Sanguine Handwraps
14378	Sanguine Mantle
14379	Sanguine Trousers
14380	Sanguine Robe
14381	Grimtotem Satchel
14382	Durability Chestpiece
14383	Durability Bracers
14384	Durability Boots
14385	Durability Cloak
14386	Durability Hat
14387	Durability Gloves
14388	Durability Leggings
14389	Durability Shoulderpads
14390	Durability Belt
14391	Durability Sword
14392	Durability Staff
14393	Durability Shield
14394	Durability Bow
14395	Spells of Shadow
14396	Incantations from the Nether
14397	Resilient Mantle
14398	Resilient Tunic
14399	Resilient Boots
14400	Resilient Cape
14401	Resilient Cap
14402	Resilient Bands
14403	Resilient Handgrips
14404	Resilient Leggings
14405	Resilient Robe
14406	Resilient Cord
14407	Stonecloth Vest
14408	Stonecloth Boots
14409	Stonecloth Cape
14410	Stonecloth Circlet
14411	Stonecloth Gloves
14412	Stonecloth Epaulets
14413	Stonecloth Robe
14414	Stonecloth Belt
14415	Stonecloth Britches
14416	Stonecloth Bindings
14417	Silksand Tunic
14418	Silksand Boots
14419	Silksand Bracers
14420	Silksand Cape
14421	Silksand Circlet
14422	Silksand Gloves
14423	Silksand Shoulder Pads
14424	Silksand Legwraps
14425	Silksand Wraps
14426	Silksand Girdle
14427	Windchaser Wraps
14428	Windchaser Footpads
14429	Windchaser Cuffs
14430	Windchaser Cloak
14431	Windchaser Handguards
14432	Windchaser Amice
14433	Windchaser Woolies
14434	Windchaser Robes
14435	Windchaser Cinch
14436	Windchaser Coronet
14437	Venomshroud Vest
14438	Venomshroud Boots
14439	Venomshroud Armguards
14440	Venomshroud Cape
14441	Venomshroud Mask
14442	Venomshroud Mitts
14443	Venomshroud Mantle
14444	Venomshroud Leggings
14445	Venomshroud Silk Robes
14446	Venomshroud Belt
14447	Highborne Footpads
14448	Highborne Bracelets
14449	Highborne Crown
14450	Highborne Cloak
14451	Highborne Gloves
14452	Highborne Pauldrons
14453	Highborne Robes
14454	Highborne Cord
14455	Highborne Padded Armor
14456	Elunarian Vest
14457	Elunarian Cuffs
14458	Elunarian Boots
14459	Elunarian Cloak
14460	Elunarian Diadem
14461	Elunarian Handgrips
14462	Elunarian Sarong
14463	Elunarian Spaulders
14464	Elunarian Silk Robes
14465	Elunarian Belt
14466	Pattern: Frostweave Tunic
14467	Pattern: Frostweave Robe
14468	Pattern: Runecloth Bag
14469	Pattern: Runecloth Robe
14470	Pattern: Runecloth Tunic
14471	Pattern: Cindercloth Vest
14472	Pattern: Runecloth Cloak
14473	Pattern: Ghostweave Belt
14474	Pattern: Frostweave Gloves
14476	Pattern: Cindercloth Gloves
14477	Pattern: Ghostweave Gloves
14478	Pattern: Brightcloth Robe
14479	Pattern: Brightcloth Gloves
14480	Pattern: Ghostweave Vest
14481	Pattern: Runecloth Gloves
14482	Pattern: Cindercloth Cloak
14483	Pattern: Felcloth Pants
14484	Pattern: Brightcloth Cloak
14485	Pattern: Wizardweave Leggings
14486	Pattern: Cloak of Fire
14487	Bonechill Hammer
14488	Pattern: Runecloth Boots
14489	Pattern: Frostweave Pants
14490	Pattern: Cindercloth Pants
14491	Pattern: Runecloth Pants
14492	Pattern: Felcloth Boots
14493	Pattern: Robe of Winter Night
14494	Pattern: Brightcloth Pants
14495	Pattern: Ghostweave Pants
14496	Pattern: Felcloth Hood
14497	Pattern: Mooncloth Leggings
14498	Pattern: Runecloth Headband
14499	Pattern: Mooncloth Bag
14500	Pattern: Wizardweave Robe
14501	Pattern: Mooncloth Vest
14502	Frostbite Girdle
14503	Death's Clutch
14504	Pattern: Runecloth Shoulders
14505	Pattern: Wizardweave Turban
14506	Pattern: Felcloth Robe
14507	Pattern: Mooncloth Shoulders
14508	Pattern: Felcloth Shoulders
14509	Pattern: Mooncloth Circlet
14510	Pattern: Bottomless Bag
14511	Pattern: Gloves of Spell Mastery
14512	Pattern: Truefaith Vestments
14513	Pattern: Robe of the Archmage
14514	Pattern: Robe of the Void
14522	Maelstrom Leggings
14523	Demon Pick
14525	Boneclenched Gauntlets
14526	Pattern: Mooncloth
14528	Rattlecage Buckler
14529	Runecloth Bandage
14530	Heavy Runecloth Bandage
14531	Frightskull Shaft
14536	Bonebrace Hauberk
14537	Corpselight Greaves
14538	Deadwalker Mantle
14539	Bone Ring Helm
14540	Taragaman the Hungerer's Heart
14541	Barovian Family Sword
14542	Kravel's Crate
14543	Darkshade Gloves
14544	Lieutenant's Insignia
14545	Ghostloom Leggings
14546	Roon's Kodo Horn
14547	Hand of Iruxos
14548	Royal Cap Spaulders
14549	Boots of Avoidance
14550	Bladebane Armguards
14551	Edgemaster's Handguards
14552	Stockade Pauldrons
14553	Sash of Mercy
14554	Cloudkeeper Legplates
14555	Alcor's Sunrazor
14557	The Lion Horn of Stormwind
14558	Lady Maye's Pendant
14559	Prospector's Sash
14560	Prospector's Boots
14561	Prospector's Cuffs
14562	Prospector's Chestpiece
14563	Prospector's Cloak
14564	Prospector's Mitts
14565	Prospector's Woolies
14566	Prospector's Pads
14567	Bristlebark Belt
14568	Bristlebark Boots
14569	Bristlebark Bindings
14570	Bristlebark Blouse
14571	Bristlebark Cape
14572	Bristlebark Gloves
14573	Bristlebark Amice
14574	Bristlebark Britches
14576	Ebon Hilt of Marduk
14577	Skullsmoke Pants
14578	Dokebi Cord
14579	Dokebi Boots
14580	Dokebi Bracers
14581	Dokebi Chestguard
14582	Dokebi Cape
14583	Dokebi Gloves
14584	Dokebi Hat
14585	Dokebi Leggings
14587	Dokebi Mantle
14588	Hawkeye's Cord
14589	Hawkeye's Shoes
14590	Hawkeye's Bracers
14591	Hawkeye's Helm
14592	Hawkeye's Tunic
14593	Hawkeye's Cloak
14594	Hawkeye's Gloves
14595	Hawkeye's Breeches
14596	Hawkeye's Epaulets
14598	Warden's Waistband
14599	Warden's Footpads
14600	Warden's Wristbands
14601	Warden's Wraps
14602	Warden's Cloak
14603	Warden's Mantle
14604	Warden's Wizard Hat
14605	Warden's Woolies
14606	Warden's Gloves
14607	Hawkeye's Buckler
14608	Dokebi Buckler
14610	Araj's Scarab
14611	Bloodmail Hauberk
14612	Bloodmail Legguards
14613	Taelan's Hammer
14614	Bloodmail Belt
14615	Bloodmail Gauntlets
14616	Bloodmail Boots
14617	Sawbones Shirt
14619	Skeletal Fragments
14620	Deathbone Girdle
14621	Deathbone Sabatons
14622	Deathbone Gauntlets
14623	Deathbone Legguards
14624	Deathbone Chestplate
14625	Symbol of Lost Honor
14626	Necropile Robe
14627	Pattern: Bright Yellow Shirt
14628	Imbued Skeletal Fragments
14629	Necropile Cuffs
14630	Pattern: Enchanter's Cowl
14631	Necropile Boots
14632	Necropile Leggings
14633	Necropile Mantle
14634	Recipe: Frost Oil
14635	Pattern: Gem-studded Leather Belt
14636	Cadaverous Belt
14637	Cadaverous Armor
14638	Cadaverous Leggings
14639	Schematic: Minor Recombobulator
14640	Cadaverous Gloves
14641	Cadaverous Walkers
14644	Skeleton Key Mold
14645	Unfinished Skeleton Key
14646	Northshire Gift Voucher
14647	Coldridge Valley Gift Voucher
14648	Shadowglen Gift Voucher
14649	Valley of Trials Gift Voucher
14650	Camp Narache Gift Voucher
14651	Deathknell Gift Voucher
14652	Scorpashi Sash
14653	Scorpashi Slippers
14654	Scorpashi Wristbands
14655	Scorpashi Breastplate
14656	Scorpashi Cape
14657	Scorpashi Gloves
14658	Scorpashi Skullcap
14659	Scorpashi Leggings
14660	Scorpashi Shoulder Pads
14661	Keeper's Cord
14662	Keeper's Hooves
14663	Keeper's Bindings
14664	Keeper's Armor
14665	Keeper's Cloak
14666	Keeper's Gloves
14667	Keeper's Wreath
14668	Keeper's Woolies
14669	Keeper's Mantle
14670	Pridelord Armor
14671	Pridelord Boots
14672	Pridelord Bands
14673	Pridelord Cape
14674	Pridelord Girdle
14675	Pridelord Gloves
14676	Pridelord Halo
14677	Pridelord Pants
14678	Pridelord Pauldrons
14679	Of Love and Family
14680	Indomitable Vest
14681	Indomitable Boots
14682	Indomitable Armguards
14683	Indomitable Cloak
14684	Indomitable Belt
14685	Indomitable Gauntlets
14686	Indomitable Headdress
14687	Indomitable Leggings
14688	Indomitable Epaulets
14722	War Paint Anklewraps
14723	War Paint Bindings
14724	War Paint Cloak
14725	War Paint Waistband
14726	War Paint Gloves
14727	War Paint Legguards
14728	War Paint Shoulder Pads
14729	War Paint Shield
14730	War Paint Chestpiece
14742	Hulking Boots
14743	Hulking Bands
14744	Hulking Chestguard
14745	Hulking Cloak
14746	Hulking Belt
14747	Hulking Gauntlets
14748	Hulking Leggings
14749	Hulking Spaulders
14750	Slayer's Cuffs
14751	Slayer's Surcoat
14752	Slayer's Cape
14753	Slayer's Skullcap
14754	Slayer's Gloves
14755	Slayer's Sash
14756	Slayer's Slippers
14757	Slayer's Pants
14758	Slayer's Shoulder Pads
14759	Enduring Bracers
14760	Enduring Breastplate
14761	Enduring Belt
14762	Enduring Boots
14763	Enduring Cape
14764	Enduring Gauntlets
14765	Enduring Circlet
14766	Enduring Breeches
14767	Enduring Pauldrons
14768	Ravager's Armor
14769	Ravager's Sandals
14770	Ravager's Armguards
14771	Ravager's Cloak
14772	Ravager's Handwraps
14773	Ravager's Cord
14774	Ravager's Crown
14775	Ravager's Woolies
14776	Ravager's Mantle
14777	Ravager's Shield
14778	Khan's Bindings
14779	Khan's Chestpiece
14780	Khan's Buckler
14781	Khan's Cloak
14782	Khan's Gloves
14783	Khan's Belt
14784	Khan's Greaves
14785	Khan's Helmet
14786	Khan's Legguards
14787	Khan's Mantle
14788	Protector Armguards
14789	Protector Breastplate
14790	Protector Buckler
14791	Protector Cape
14792	Protector Gauntlets
14793	Protector Waistband
14794	Protector Ankleguards
14795	Protector Helm
14796	Protector Legguards
14797	Protector Pads
14798	Bloodlust Breastplate
14799	Bloodlust Boots
14800	Bloodlust Buckler
14801	Bloodlust Cape
14802	Bloodlust Gauntlets
14803	Bloodlust Belt
14804	Bloodlust Helm
14805	Bloodlust Britches
14806	Bloodlust Epaulets
14807	Bloodlust Bracelets
14808	Warstrike Belt
14809	Warstrike Sabatons
14810	Warstrike Armsplints
14811	Warstrike Chestguard
14812	Warstrike Buckler
14813	Warstrike Cape
14814	Warstrike Helmet
14815	Warstrike Gauntlets
14816	Warstrike Legguards
14817	Warstrike Shoulder Pads
14821	Symbolic Breastplate
14825	Symbolic Crest
14826	Symbolic Gauntlets
14827	Symbolic Belt
14828	Symbolic Greaves
14829	Symbolic Legplates
14830	Symbolic Pauldrons
14831	Symbolic Crown
14832	Symbolic Vambraces
14833	Tyrant's Gauntlets
14834	Tyrant's Armguards
14835	Tyrant's Chestpiece
14838	Tyrant's Belt
14839	Tyrant's Greaves
14840	Tyrant's Legplates
14841	Tyrant's Epaulets
14842	Tyrant's Shield
14843	Tyrant's Helm
14844	Sunscale Chestguard
14846	Sunscale Gauntlets
14847	Sunscale Belt
14848	Sunscale Sabatons
14849	Sunscale Helmet
14850	Sunscale Legplates
14851	Sunscale Spaulders
14852	Sunscale Shield
14853	Sunscale Wristguards
14854	Vanguard Breastplate
14855	Vanguard Gauntlets
14856	Vanguard Girdle
14857	Vanguard Sabatons
14858	Vanguard Headdress
14859	Vanguard Legplates
14860	Vanguard Pauldrons
14861	Vanguard Vambraces
14862	Warleader's Breastplate
14863	Warleader's Gauntlets
14864	Warleader's Belt
14865	Warleader's Greaves
14866	Warleader's Crown
14867	Warleader's Leggings
14868	Warleader's Shoulders
14869	Warleader's Bracers
14872	Tirion's Gift
14894	Lily Root
14895	Saltstone Surcoat
14896	Saltstone Sabatons
14897	Saltstone Gauntlets
14898	Saltstone Girdle
14899	Saltstone Helm
14900	Saltstone Legplates
14901	Saltstone Shoulder Pads
14902	Saltstone Shield
14903	Saltstone Armsplints
14904	Brutish Breastplate
14905	Brutish Gauntlets
14906	Brutish Belt
14907	Brutish Helmet
14908	Brutish Legguards
14909	Brutish Shoulders
14910	Brutish Armguards
14911	Brutish Boots
14912	Brutish Shield
14913	Jade Greaves
14914	Jade Bracers
14915	Jade Breastplate
14916	Jade Deflector
14917	Jade Gauntlets
14918	Jade Belt
14919	Jade Circlet
14920	Jade Legplates
14921	Jade Epaulets
14922	Lofty Sabatons
14923	Lofty Armguards
14924	Lofty Breastplate
14925	Lofty Helm
14926	Lofty Gauntlets
14927	Lofty Belt
14928	Lofty Legguards
14929	Lofty Shoulder Pads
14930	Lofty Shield
14931	Heroic Armor
14932	Heroic Greaves
14933	Heroic Gauntlets
14934	Heroic Girdle
14935	Heroic Skullcap
14936	Heroic Legplates
14937	Heroic Pauldrons
14938	Heroic Bracers
14939	Warbringer's Chestguard
14940	Warbringer's Sabatons
14941	Warbringer's Armsplints
14942	Warbringer's Gauntlets
14943	Warbringer's Belt
14944	Warbringer's Crown
14945	Warbringer's Legguards
14946	Warbringer's Spaulders
14947	Warbringer's Shield
14948	Bloodforged Chestpiece
14949	Bloodforged Gauntlets
14950	Bloodforged Belt
14951	Bloodforged Sabatons
14952	Bloodforged Helmet
14953	Bloodforged Legplates
14954	Bloodforged Shield
14955	Bloodforged Shoulder Pads
14956	Bloodforged Bindings
14957	High Chief's Sabatons
14958	High Chief's Armor
14959	High Chief's Gauntlets
14960	High Chief's Belt
14961	High Chief's Crown
14962	High Chief's Legguards
14963	High Chief's Pauldrons
14964	High Chief's Shield
14965	High Chief's Bindings
14966	Glorious Breastplate
14967	Glorious Gauntlets
14968	Glorious Belt
14969	Glorious Headdress
14970	Glorious Legplates
14971	Glorious Shoulder Pads
14972	Glorious Sabatons
14973	Glorious Shield
14974	Glorious Bindings
14975	Exalted Harness
14976	Exalted Gauntlets
14977	Exalted Girdle
14978	Exalted Sabatons
14979	Exalted Helmet
14980	Exalted Legplates
14981	Exalted Epaulets
14982	Exalted Shield
14983	Exalted Armsplints
15002	Nimboya's Pike
15003	Primal Belt
15004	Primal Boots
15005	Primal Bands
15006	Primal Buckler
15007	Primal Cape
15008	Primal Mitts
15009	Primal Leggings
15010	Primal Wraps
15011	Lupine Cord
15012	Lupine Slippers
15013	Lupine Cuffs
15014	Lupine Buckler
15015	Lupine Cloak
15016	Lupine Handwraps
15017	Lupine Leggings
15018	Lupine Vest
15019	Lupine Mantle
15042	Empty Termite Jar
15043	Plagueland Termites
15044	Barrel of Plagueland Termites
15045	Green Dragonscale Breastplate
15046	Green Dragonscale Leggings
15047	Red Dragonscale Breastplate
15048	Blue Dragonscale Breastplate
15049	Blue Dragonscale Shoulders
15050	Black Dragonscale Breastplate
15051	Black Dragonscale Shoulders
15052	Black Dragonscale Leggings
15053	Volcanic Breastplate
15054	Volcanic Leggings
15055	Volcanic Shoulders
15056	Stormshroud Armor
15057	Stormshroud Pants
15058	Stormshroud Shoulders
15059	Living Breastplate
15060	Living Leggings
15061	Living Shoulders
15062	Devilsaur Leggings
15063	Devilsaur Gauntlets
15064	Warbear Harness
15065	Warbear Woolies
15066	Ironfeather Breastplate
15067	Ironfeather Shoulders
15068	Frostsaber Tunic
15069	Frostsaber Leggings
15070	Frostsaber Gloves
15071	Frostsaber Boots
15072	Chimeric Leggings
15073	Chimeric Boots
15074	Chimeric Gloves
15075	Chimeric Vest
15076	Heavy Scorpid Vest
15077	Heavy Scorpid Bracers
15078	Heavy Scorpid Gauntlet
15079	Heavy Scorpid Leggings
15080	Heavy Scorpid Helm
15081	Heavy Scorpid Shoulders
15082	Heavy Scorpid Belt
15083	Wicked Leather Gauntlets
15084	Wicked Leather Bracers
15085	Wicked Leather Armor
15086	Wicked Leather Headband
15087	Wicked Leather Pants
15088	Wicked Leather Belt
15090	Runic Leather Armor
15091	Runic Leather Gauntlets
15092	Runic Leather Bracers
15093	Runic Leather Belt
15094	Runic Leather Headband
15095	Runic Leather Pants
15096	Runic Leather Shoulders
15102	Un'Goro Tested Sample
15103	Corrupt Tested Sample
15104	Wingborne Boots
15105	Staff of Noh'Orahil
15106	Staff of Dar'Orahil
15107	Orb of Noh'Orahil
15108	Orb of Dar'Orahil
15109	Staff of Soran'ruk
15110	Rigid Belt
15111	Rigid Moccasins
15112	Rigid Bracelets
15113	Rigid Buckler
15114	Rigid Cape
15115	Rigid Gloves
15116	Rigid Shoulders
15117	Rigid Leggings
15118	Rigid Tunic
15119	Highborne Pants
15120	Robust Girdle
15121	Robust Boots
15122	Robust Bracers
15123	Robust Buckler
15124	Robust Cloak
15125	Robust Gloves
15126	Robust Leggings
15127	Robust Shoulders
15128	Robust Tunic
15129	Robust Helm
15130	Cutthroat's Vest
15131	Cutthroat's Boots
15132	Cutthroat's Armguards
15133	Cutthroat's Buckler
15134	Cutthroat's Hat
15135	Cutthroat's Cape
15136	Cutthroat's Belt
15137	Cutthroat's Mitts
15138	Onyxia Scale Cloak
15139	Cutthroat's Pants
15140	Cutthroat's Mantle
15141	Onyxia Scale Breastplate
15142	Ghostwalker Boots
15143	Ghostwalker Bindings
15144	Ghostwalker Rags
15145	Ghostwalker Buckler
15146	Ghostwalker Crown
15147	Ghostwalker Cloak
15148	Ghostwalker Belt
15149	Ghostwalker Gloves
15150	Ghostwalker Pads
15151	Ghostwalker Legguards
15152	Nocturnal Shoes
15153	Nocturnal Cloak
15154	Nocturnal Sash
15155	Nocturnal Gloves
15156	Nocturnal Cap
15157	Nocturnal Leggings
15158	Nocturnal Shoulder Pads
15159	Nocturnal Tunic
15160	Nocturnal Wristbands
15161	Imposing Belt
15162	Imposing Boots
15163	Imposing Bracers
15164	Imposing Vest
15165	Imposing Cape
15166	Imposing Gloves
15167	Imposing Bandana
15168	Imposing Pants
15169	Imposing Shoulders
15170	Potent Armor
15171	Potent Boots
15172	Potent Bands
15173	Potent Cape
15174	Potent Gloves
15175	Potent Helmet
15176	Potent Pants
15177	Potent Shoulders
15178	Potent Belt
15179	Praetorian Padded Armor
15180	Praetorian Girdle
15181	Praetorian Boots
15182	Praetorian Wristbands
15183	Praetorian Cloak
15184	Praetorian Gloves
15185	Praetorian Coif
15186	Praetorian Leggings
15187	Praetorian Pauldrons
15188	Grand Armguards
15189	Grand Boots
15190	Grand Cloak
15191	Grand Belt
15192	Grand Gauntlets
15193	Grand Crown
15194	Grand Legguards
15195	Grand Breastplate
15196	Private's Tabard
15197	Scout's Tabard
15198	Knight's Colors
15199	Stone Guard's Herald
15200	Senior Sergeant's Insignia
15202	Wildkeeper Leggings
15203	Guststorm Legguards
15204	Moonstone Wand
15205	Owlsight Rifle
15206	Jadefinger Baton
15207	Steelcap Shield
15208	Cenarion Moondust
15209	Relic Bundle
15210	Raider Shortsword
15211	Militant Shortsword
15212	Fighter Broadsword
15213	Mercenary Blade
15214	Nobles Brand
15215	Furious Falchion
15216	Rune Sword
15217	Widow Blade
15218	Crystal Sword
15219	Dimensional Blade
15220	Battlefell Sabre
15221	Holy War Sword
15222	Barbed Club
15223	Jagged Star
15224	Battlesmasher
15225	Sequoia Hammer
15226	Giant Club
15227	Diamond-Tip Bludgeon
15228	Smashing Star
15229	Blesswind Hammer
15230	Ridge Cleaver
15231	Splitting Hatchet
15232	Hacking Cleaver
15233	Savage Axe
15234	Greater Scythe
15235	Crescent Edge
15236	Moon Cleaver
15237	Corpse Harvester
15238	Warlord's Axe
15239	Felstone Reaver
15240	Demon's Claw
15241	Battle Knife
15242	Honed Stiletto
15243	Deadly Kris
15244	Razor Blade
15245	Vorpal Dagger
15246	Demon Blade
15247	Bloodstrike Dagger
15248	Gleaming Claymore
15249	Polished Zweihander
15250	Glimmering Flamberge
15251	Headstriker Sword
15252	Tusker Sword
15253	Beheading Blade
15254	Dark Espadon
15255	Gallant Flamberge
15256	Massacre Sword
15257	Shin Blade
15258	Divine Warblade
15259	Hefty Battlehammer
15260	Stone Hammer
15261	Sequoia Branch
15262	Greater Maul
15263	Royal Mallet
15264	Backbreaker
15265	Painbringer
15266	Fierce Mauler
15267	Brutehammer
15268	Twin-bladed Axe
15269	Massive Battle Axe
15270	Gigantic War Axe
15271	Colossal Great Axe
15272	Razor Axe
15273	Death Striker
15274	Diviner Long Staff
15275	Thaumaturgist Staff
15276	Magus Long Staff
15277	Gray Kodo
15278	Solstice Staff
15279	Ivory Wand
15280	Wizard's Hand
15281	Glowstar Rod
15282	Dragon Finger
15283	Lunar Wand
15284	Long Battle Bow
15285	Archer's Longbow
15286	Long Redwood Bow
15287	Crusader Bow
15288	Blasthorn Bow
15289	Archstrike Bow
15290	Brown Kodo
15291	Harpy Needler
15292	Green Kodo
15293	Teal Kodo
15294	Siege Bow
15295	Quillfire Bow
15296	Hawkeye Bow
15297	Grizzly Bracers
15298	Grizzly Buckler
15299	Grizzly Cape
15300	Grizzly Gloves
15301	Grizzly Slippers
15302	Grizzly Belt
15303	Grizzly Pants
15304	Grizzly Jerkin
15305	Feral Shoes
15306	Feral Bindings
15307	Feral Buckler
15308	Feral Cord
15309	Feral Cloak
15310	Feral Gloves
15311	Feral Harness
15312	Feral Leggings
15313	Feral Shoulder Pads
15314	Bundle of Relics
15322	Smoothbore Gun
15323	Percussion Shotgun
15324	Burnside Rifle
15325	Sharpshooter Harquebus
15326	Gleaming Throwing Axe
15327	Wicked Throwing Dagger
15328	Joseph's Key
15329	Wrangler's Belt
15330	Wrangler's Boots
15331	Wrangler's Wristbands
15332	Wrangler's Buckler
15333	Wrangler's Cloak
15334	Wrangler's Gloves
15335	Briarsteel Shortsword
15336	Wrangler's Leggings
15337	Wrangler's Wraps
15338	Wrangler's Mantle
15339	Pathfinder Hat
15340	Pathfinder Cloak
15341	Pathfinder Footpads
15342	Pathfinder Guard
15343	Pathfinder Gloves
15344	Pathfinder Pants
15345	Pathfinder Shoulder Pads
15346	Pathfinder Vest
15347	Pathfinder Belt
15348	Pathfinder Bracers
15349	Headhunter's Belt
15350	Headhunter's Slippers
15351	Headhunter's Bands
15352	Headhunter's Buckler
15353	Headhunter's Headdress
15354	Headhunter's Cloak
15355	Headhunter's Mitts
15356	Headhunter's Armor
15357	Headhunter's Spaulders
15358	Headhunter's Woolies
15359	Trickster's Vest
15360	Trickster's Bindings
15361	Trickster's Sash
15362	Trickster's Boots
15363	Trickster's Headdress
15364	Trickster's Cloak
15365	Trickster's Handwraps
15366	Trickster's Leggings
15367	Trickster's Protector
15368	Trickster's Pauldrons
15369	Wolf Rider's Belt
15370	Wolf Rider's Boots
15371	Wolf Rider's Cloak
15372	Wolf Rider's Gloves
15373	Wolf Rider's Headgear
15374	Wolf Rider's Leggings
15375	Wolf Rider's Shoulder Pads
15376	Wolf Rider's Padded Armor
15377	Wolf Rider's Wristbands
15378	Rageclaw Belt
15379	Rageclaw Boots
15380	Rageclaw Bracers
15381	Rageclaw Chestguard
15382	Rageclaw Cloak
15383	Rageclaw Gloves
15384	Rageclaw Helm
15385	Rageclaw Leggings
15386	Rageclaw Shoulder Pads
15387	Jadefire Bracelets
15388	Jadefire Belt
15389	Jadefire Sabatons
15390	Jadefire Chestguard
15391	Jadefire Cap
15392	Jadefire Cloak
15393	Jadefire Gloves
15394	Jadefire Pants
15395	Jadefire Epaulets
15396	Curvewood Dagger
15397	Oakthrush Staff
15398	Sandcomber Boots
15399	Dryweed Belt
15400	Clamshell Bracers
15401	Welldrip Gloves
15402	Noosegrip Gauntlets
15403	Ridgeback Bracers
15404	Breakwater Girdle
15405	Shucking Gloves
15406	Crustacean Boots
15407	Cured Rugged Hide
15408	Heavy Scorpid Scale
15409	Refined Deeprock Salt
15410	Scale of Onyxia
15411	Mark of Fordring
15412	Green Dragonscale
15413	Ornate Adamantium Breastplate
15414	Red Dragonscale
15415	Blue Dragonscale
15416	Black Dragonscale
15417	Devilsaur Leather
15418	Shimmering Platinum Warhammer
15419	Warbear Leather
15420	Ironfeather
15421	Shroud of the Exile
15422	Frostsaber Leather
15423	Chimera Leather
15424	Axe of Orgrimmar
15425	Peerless Bracers
15426	Peerless Boots
15427	Peerless Cloak
15428	Peerless Belt
15429	Peerless Gloves
15430	Peerless Headband
15431	Peerless Leggings
15432	Peerless Shoulders
15433	Peerless Armor
15434	Supreme Sash
15435	Supreme Shoes
15436	Supreme Bracers
15437	Supreme Cape
15438	Supreme Gloves
15439	Supreme Crown
15440	Supreme Leggings
15441	Supreme Shoulders
15442	Supreme Breastplate
15443	Kris of Orgrimmar
15444	Staff of Orgrimmar
15445	Hammer of Orgrimmar
15446	Stormwind Deputy Kit
15447	Living Rot
15448	Coagulated Rot
15449	Ghastly Trousers
15450	Dredgemire Leggings
15451	Gargoyle Leggings
15452	Featherbead Bracers
15453	Savannah Bracers
15454	Mortar and Pestle
15455	Dustfall Robes
15456	Lightstep Leggings
15457	Desert Shoulders
15458	Tundra Boots
15459	Grimtoll Wristguards
15461	Lightheel Boots
15462	Loamflake Bracers
15463	Palestrider Gloves
15464	Brute Hammer
15465	Stingshot Wand
15466	Clink Shield
15467	Inventor's League Ring
15468	Windsong Drape
15469	Windsong Cinch
15470	Plainsguard Leggings
15471	Brawnhide Armor
15472	Charger's Belt
15473	Charger's Boots
15474	Charger's Bindings
15475	Charger's Cloak
15476	Charger's Handwraps
15477	Charger's Pants
15478	Charger's Shield
15479	Charger's Armor
15480	War Torn Girdle
15481	War Torn Greaves
15482	War Torn Bands
15483	War Torn Cape
15484	War Torn Handgrips
15485	War Torn Pants
15486	War Torn Shield
15487	War Torn Tunic
15488	Bloodspattered Surcoat
15489	Bloodspattered Sabatons
15490	Bloodspattered Cloak
15491	Bloodspattered Gloves
15492	Bloodspattered Sash
15493	Bloodspattered Loincloth
15494	Bloodspattered Shield
15495	Bloodspattered Wristbands
15496	Bloodspattered Shoulder Pads
15497	Outrunner's Cord
15498	Outrunner's Slippers
15499	Outrunner's Cuffs
15500	Outrunner's Chestguard
15501	Outrunner's Cloak
15502	Outrunner's Gloves
15503	Outrunner's Legguards
15504	Outrunner's Shield
15505	Outrunner's Pauldrons
15506	Grunt's AnkleWraps
15507	Grunt's Bracers
15508	Grunt's Cape
15509	Grunt's Handwraps
15510	Grunt's Belt
15511	Grunt's Legguards
15512	Grunt's Shield
15513	Grunt's Pauldrons
15514	Grunt's Chestpiece
15515	Spiked Chain Belt
15516	Spiked Chain Slippers
15517	Spiked Chain Wristbands
15518	Spiked Chain Breastplate
15519	Spiked Chain Cloak
15520	Spiked Chain Gauntlets
15521	Spiked Chain Leggings
15522	Spiked Chain Shield
15523	Spiked Chain Shoulder Pads
15524	Sentry's Surcoat
15525	Sentry's Slippers
15526	Sentry's Cape
15527	Sentry's Gloves
15528	Sentry's Sash
15529	Sentry's Leggings
15530	Sentry's Shield
15531	Sentry's Shoulderguards
15532	Sentry's Armsplints
15533	Sentry's Headdress
15534	Wicked Chain Boots
15535	Wicked Chain Bracers
15536	Wicked Chain Chestpiece
15537	Wicked Chain Cloak
15538	Wicked Chain Gauntlets
15539	Wicked Chain Waistband
15540	Wicked Chain Helmet
15541	Wicked Chain Legguards
15542	Wicked Chain Shoulder Pads
15543	Wicked Chain Shield
15544	Thick Scale Sabatons
15545	Thick Scale Bracelets
15546	Thick Scale Breastplate
15547	Thick Scale Cloak
15548	Thick Scale Gauntlets
15549	Thick Scale Belt
15550	Thick Scale Crown
15551	Thick Scale Legguards
15552	Thick Scale Shield
15553	Thick Scale Shoulder Pads
15554	Pillager's Girdle
15555	Pillager's Boots
15556	Pillager's Bracers
15557	Pillager's Chestguard
15558	Pillager's Crown
15559	Pillager's Cloak
15560	Pillager's Gloves
15561	Pillager's Leggings
15562	Pillager's Pauldrons
15563	Pillager's Shield
15564	Rugged Armor Kit
15565	Marauder's Boots
15566	Marauder's Bracers
15567	Marauder's Tunic
15568	Marauder's Cloak
15569	Marauder's Crest
15570	Marauder's Gauntlets
15571	Marauder's Belt
15572	Marauder's Circlet
15573	Marauder's Leggings
15574	Marauder's Shoulder Pads
15575	Sparkleshell Belt
15576	Sparkleshell Sabatons
15577	Sparkleshell Bracers
15578	Sparkleshell Breastplate
15579	Sparkleshell Cloak
15580	Sparkleshell Headwrap
15581	Sparkleshell Gauntlets
15582	Sparkleshell Legguards
15583	Sparkleshell Shoulder Pads
15584	Sparkleshell Shield
15585	Pardoc Grips
15586	Fast-growing Flower
15587	Ringtail Girdle
15588	Bracesteel Belt
15589	Steadfast Stompers
15590	Steadfast Bracelets
15591	Steadfast Breastplate
15592	Steadfast Buckler
15593	Steadfast Coronet
15594	Steadfast Cloak
15595	Steadfast Gloves
15596	Steadfast Legplates
15597	Steadfast Shoulders
15598	Steadfast Girdle
15599	Ancient Greaves
15600	Ancient Vambraces
15601	Ancient Chestpiece
15602	Ancient Crown
15603	Ancient Cloak
15604	Ancient Defender
15605	Ancient Gauntlets
15606	Ancient Belt
15607	Ancient Legguards
15608	Ancient Pauldrons
15609	Bonelink Armor
15610	Bonelink Bracers
15611	Bonelink Cape
15612	Bonelink Gauntlets
15613	Bonelink Belt
15614	Bonelink Sabatons
15615	Bonelink Helmet
15616	Bonelink Legplates
15617	Bonelink Epaulets
15618	Bonelink Wall Shield
15619	Gryphon Mail Belt
15620	Gryphon Mail Bracelets
15621	Gryphon Mail Buckler
15622	Gryphon Mail Breastplate
15623	Gryphon Mail Crown
15624	Gryphon Cloak
15625	Gryphon Mail Gauntlets
15626	Gryphon Mail Greaves
15627	Gryphon Mail Legguards
15628	Gryphon Mail Pauldrons
15629	Formidable Bracers
15630	Formidable Sabatons
15631	Formidable Chestpiece
15632	Formidable Cape
15633	Formidable Crest
15634	Formidable Circlet
15635	Formidable Gauntlets
15636	Formidable Belt
15637	Formidable Legguards
15638	Formidable Shoulder Pads
15639	Ironhide Bracers
15640	Ironhide Breastplate
15641	Ironhide Belt
15642	Ironhide Greaves
15643	Ironhide Cloak
15644	Ironhide Gauntlets
15645	Ironhide Helmet
15646	Ironhide Legguards
15647	Ironhide Pauldrons
15648	Ironhide Shield
15649	Merciless Bracers
15650	Merciless Surcoat
15651	Merciless Crown
15652	Merciless Cloak
15653	Merciless Gauntlets
15654	Merciless Belt
15655	Merciless Legguards
15656	Merciless Epaulets
15657	Merciless Shield
15658	Impenetrable Sabatons
15659	Impenetrable Bindings
15660	Impenetrable Breastplate
15661	Impenetrable Cloak
15662	Impenetrable Gauntlets
15663	Impenetrable Belt
15664	Impenetrable Helmet
15665	Impenetrable Legguards
15666	Impenetrable Pauldrons
15667	Impenetrable Wall
15668	Magnificent Bracers
15669	Magnificent Breastplate
15670	Magnificent Helmet
15671	Magnificent Cloak
15672	Magnificent Gauntlets
15673	Magnificent Belt
15674	Magnificent Greaves
15675	Magnificent Guard
15676	Magnificent Leggings
15677	Magnificent Shoulders
15678	Triumphant Sabatons
15679	Triumphant Bracers
15680	Triumphant Chestpiece
15681	Triumphant Cloak
15682	Triumphant Gauntlets
15683	Triumphant Girdle
15684	Triumphant Skullcap
15685	Triumphant Legplates
15686	Triumphant Shoulder Pads
15687	Triumphant Shield
15688	Magic Beans
15689	Trader's Ring
15690	Kodobone Necklace
15691	Sidegunner Shottie
15692	Kodo Brander
15693	Grand Shoulders
15694	Merciless Greaves
15695	Studded Ring Shield
15696	Ruined Tome
15697	Kodo Rustler Boots
15698	Wrangling Spaulders
15699	Small Brown-wrapped Package
15702	Chemist's Ring
15703	Chemist's Smock
15704	Hunter's Insignia Medal
15705	Tidecrest Blade
15706	Hunt Tracker Blade
15707	Brantwood Sash
15708	Blight Leather Gloves
15709	Gearforge Girdle
15710	Cenarion Lunardust
15722	Spraggle's Canteen
15723	Tea with Sugar
15724	Pattern: Heavy Scorpid Bracers
15725	Pattern: Wicked Leather Gauntlets
15726	Pattern: Green Dragonscale Breastplate
15727	Pattern: Heavy Scorpid Vest
15728	Pattern: Wicked Leather Bracers
15729	Pattern: Chimeric Gloves
15730	Pattern: Red Dragonscale Breastplate
15731	Pattern: Runic Leather Gauntlets
15732	Pattern: Volcanic Leggings
15733	Pattern: Green Dragonscale Leggings
15734	Pattern: Living Shoulders
15735	Pattern: Ironfeather Shoulders
15736	Smokey's Special Compound
15737	Pattern: Chimeric Boots
15738	Pattern: Heavy Scorpid Gauntlets
15739	Pattern: Runic Leather Bracers
15740	Pattern: Frostsaber Boots
15741	Pattern: Stormshroud Pants
15742	Pattern: Warbear Harness
15743	Pattern: Heavy Scorpid Belt
15744	Pattern: Wicked Leather Headband
15745	Pattern: Runic Leather Belt
15746	Pattern: Chimeric Leggings
15747	Pattern: Frostsaber Leggings
15748	Pattern: Heavy Scorpid Leggings
15749	Pattern: Volcanic Breastplate
15750	Sceptre of Light
15751	Pattern: Blue Dragonscale Breastplate
15752	Pattern: Living Leggings
15753	Pattern: Stormshroud Armor
15754	Pattern: Warbear Woolies
15755	Pattern: Chimeric Vest
15756	Pattern: Runic Leather Headband
15757	Pattern: Wicked Leather Pants
15758	Pattern: Devilsaur Gauntlets
15759	Pattern: Black Dragonscale Breastplate
15760	Pattern: Ironfeather Breastplate
15761	Pattern: Frostsaber Gloves
15762	Pattern: Heavy Scorpid Helm
15763	Pattern: Blue Dragonscale Shoulders
15764	Pattern: Stormshroud Shoulders
15765	Pattern: Runic Leather Pants
15766	Gem of the Serpent
15767	Hameya's Key
15768	Pattern: Wicked Leather Belt
15769	Pattern: Onyxia Scale Cloak
15770	Pattern: Black Dragonscale Shoulders
15771	Pattern: Living Breastplate
15772	Pattern: Devilsaur Leggings
15773	Pattern: Wicked Leather Armor
15774	Pattern: Heavy Scorpid Shoulders
15775	Pattern: Volcanic Shoulders
15776	Pattern: Runic Leather Armor
15777	Pattern: Runic Leather Shoulders
15778	Mechanical Yeti
15779	Pattern: Frostsaber Tunic
15780	Pattern: Onyxia Scale Breastplate
15781	Pattern: Black Dragonscale Leggings
15782	Beaststalker Blade
15783	Beasthunter Dagger
15784	Crystal Breeze Mantle
15785	Zaeldarr's Head
15786	Fernpulse Jerkin
15787	Willow Band Hauberk
15788	Everlook Report
15789	Deep River Cloak
15790	Studies in Spirit Speaking
15791	Turquoise Sash
15792	Plow Wood Spaulders
15793	A Chewed Bone
15794	Ripped Ogre Loincloth
15795	Emerald Mist Gauntlets
15796	Seaspray Bracers
15797	Shining Armplates
15798	Chipped Ogre Teeth
15799	Heroic Commendation Medal
15800	Intrepid Shortsword
15801	Valiant Shortsword
15802	Mooncloth Boots
15803	Book of the Ancients
15804	Cerise Drape
15805	Penelope's Rose
15806	Mirah's Song
15807	Light Crossbow
15808	Fine Light Crossbow
15809	Heavy Crossbow
15810	Short Spear
15811	Heavy Spear
15812	Orchid Amice
15813	Gold Link Belt
15814	Hameya's Slayer
15815	Hameya's Cloak
15822	Shadowskin Spaulders
15823	Bricksteel Gauntlets
15824	Astoria Robes
15825	Traphook Jerkin
15826	Curative Animal Salve
15827	Jadescale Breastplate
15842	Empty Dreadmist Peak Sampler
15843	Filled Dreadmist Peak Sampler
15844	Empty Cliffspring Falls Sampler
15845	Filled Cliffspring Falls Sampler
15846	Salt Shaker
15847	Quel'Thalas Registry
15848	Crate of Ghost Magnets
15849	Ghost-o-plasm
15850	Patch of Duskwing's Fur
15851	Lunar Fungus
15852	Kodo Horn
15853	Windreaper
15854	Dancing Sliver
15855	Ring of Protection
15856	Archlight Talisman
15857	Magebane Scion
15858	Freewind Gloves
15859	Seapost Girdle
15860	Blinkstrike Armguards
15861	Swiftfoot Treads
15862	Blitzcleaver
15863	Grave Scepter
15864	Condor Bracers
15865	Anchorhold Buckler
15866	Veildust Medicine Bag
15867	Prismcharm
15868	The Grand Crusader's Command
15869	Silver Skeleton Key
15870	Golden Skeleton Key
15871	Truesilver Skeleton Key
15872	Arcanite Skeleton Key
15873	Ragged John's Neverending Cup
15874	Soft-shelled Clam
15875	Rotten Apple
15876	Nathanos' Chest
15877	Shrine Bauble
15878	Rackmore's Silver Key
15879	Overlord Ror's Claw
15880	Head of Ramstein the Gorger
15881	Rackmore's Golden Key
15882	Half Pendant of Aquatic Endurance
15883	Half Pendant of Aquatic Agility
15884	Augustus' Receipt Book
15885	Pendant of the Sea Lion
15886	Timolain's Phylactery
15887	Heroic Guard
15890	Vanguard Shield
15891	Hulking Shield
15892	Slayer's Shield
15893	Prospector's Buckler
15894	Bristlebark Buckler
15895	Burnt Buckler
15902	A Crazy Grab Bag
15903	Right-Handed Claw
15904	Right-Handed Blades
15905	Right-Handed Brass Knuckles
15906	Left-Handed Brass Knuckles
15907	Left-Handed Claw
15908	Taming Rod
15909	Left-Handed Blades
15911	Taming Rod
15912	Buccaneer's Orb
15913	Taming Rod
15914	Taming Rod
15915	Taming Rod
15916	Taming Rod
15917	Taming Rod
15918	Conjurer's Sphere
15919	Taming Rod
15920	Taming Rod
15921	Taming Rod
15922	Taming Rod
15923	Taming Rod
15924	Soft-shelled Clam Meat
15925	Journeyman's Stave
15926	Spellbinder Orb
15927	Bright Sphere
15928	Silver-thread Rod
15929	Nightsky Orb
15930	Imperial Red Scepter
15931	Arcane Star
15932	Disciple's Stein
15933	Simple Branch
15934	Sage's Stave
15935	Durable Rod
15936	Duskwoven Branch
15937	Hibernal Sphere
15938	Mystical Orb
15939	Councillor's Scepter
15940	Elegant Scepter
15941	High Councillor's Scepter
15942	Master's Rod
15943	Imbued Shield
15944	Ancestral Orb
15945	Runic Stave
15946	Mystic's Sphere
15947	Sanguine Star
15962	Satyr's Rod
15963	Stonecloth Branch
15964	Silksand Star
15965	Windchaser Orb
15966	Venomshroud Orb
15967	Highborne Star
15968	Elunarian Sphere
15969	Beaded Orb
15970	Native Branch
15971	Aboriginal Rod
15972	Ritual Stein
15973	Watcher's Star
15974	Pagan Rod
15975	Raincaller Scepter
15976	Thistlefur Branch
15977	Vital Orb
15978	Geomancer's Rod
15979	Embersilk Stave
15980	Darkmist Orb
15981	Lunar Sphere
15982	Bloodwoven Rod
15983	Gaea's Scepter
15984	Opulent Scepter
15985	Arachnidian Branch
15986	Bonecaster's Star
15987	Astral Orb
15988	Resplendent Orb
15989	Eternal Rod
15990	Enduring Shield
15991	Warleader's Shield
15992	Dense Blasting Powder
15993	Thorium Grenade
15994	Thorium Widget
15995	Thorium Rifle
15996	Lifelike Mechanical Toad
15997	Thorium Shells
15998	Lewis' Note
15999	Spellpower Goggles Xtreme Plus
16000	Thorium Tube
16001	SI:7 Insignia (Fredo)
16002	SI:7 Insignia (Turyen)
16003	SI:7 Insignia (Rutger)
16004	Dark Iron Rifle
16005	Dark Iron Bomb
16006	Delicate Arcanite Converter
16007	Flawless Arcanite Rifle
16008	Master Engineer's Goggles
16009	Voice Amplification Modulator
16022	Arcanite Dragonling
16023	Masterwork Target Dummy
16026	PVP Plate Helm Alliance
16027	PVP Plate Breastplate Alliance
16028	PVP Plate Legplates Alliance
16029	PVP Plate Gauntlets Alliance
16030	PVP Plate Boots Alliance
16031	PVP Plate Shoulder Alliance
16033	PVP Plate Wrist Alliance
16034	PVP Plate Cloak Alliance
16035	PVP Cloth Helm Horde
16036	PVP Cloth Robe Horde
16037	PVP Cloth Legs Horde
16038	PVP Cloth Shoulder Horde
16039	Ta'Kierthan Songblade
16040	Arcane Bomb
16041	Schematic: Thorium Grenade
16042	Schematic: Thorium Widget
16043	Schematic: Thorium Rifle
16044	Schematic: Lifelike Mechanical Toad
16045	Schematic: Spellpower Goggles Xtreme Plus
16046	Schematic: Masterwork Target Dummy
16047	Schematic: Thorium Tube
16048	Schematic: Dark Iron Rifle
16049	Schematic: Dark Iron Bomb
16050	Schematic: Delicate Arcanite Converter
16051	Schematic: Thorium Shells
16052	Schematic: Voice Amplification Modulator
16053	Schematic: Master Engineer's Goggles
16054	Schematic: Arcanite Dragonling
16055	Schematic: Arcane Bomb
16056	Schematic: Flawless Arcanite Rifle
16057	Explorer's Knapsack
16058	Fordring's Seal
16059	Common Brown Shirt
16060	Common White Shirt
16072	Expert Cookbook
16073	Artisan Cookbook
16082	Artisan Fishing - The Way of the Lure
16083	Expert Fishing - The Bass and You
16084	Expert First Aid - Under Wraps
16085	Artisan First Aid - Heal Thyself
16110	Recipe: Monster Omelet
16111	Recipe: Spiced Chili Crab
16112	Manual: Heavy Silk Bandage
16113	Manual: Mageweave Bandage
16114	Foreman's Blackjack
16115	Osric's Crate
16166	Bean Soup
16167	Versicolor Treat
16168	Heaven Peach
16169	Wild Ricecake
16170	Steamed Mandu
16171	Shinsollo
16189	Maggran's Reserve Letter
16190	Bloodfury Ripper's Remains
16191	Ornate Mirror
16192	Besseleth's Fang
16202	Lesser Eternal Essence
16203	Greater Eternal Essence
16204	Illusion Dust
16205	Gaea Seed
16206	Arcanite Rod
16207	Runed Arcanite Rod
16208	Enchanted Gaea Seeds
16209	Podrig's Order
16210	Gordon's Crate
16214	Formula: Enchant Bracer - Greater Intellect
16215	Formula: Enchant Boots - Greater Stamina
16216	Formula: Enchant Cloak - Greater Resistance
16217	Formula: Enchant Shield - Greater Stamina
16218	Formula: Enchant Bracer - Superior Spirit
16219	Formula: Enchant Gloves - Greater Agility
16220	Formula: Enchant Boots - Spirit
16221	Formula: Enchant Chest - Major Health
16222	Formula: Enchant Shield - Superior Spirit
16223	Formula: Enchant Weapon - Icy Chill
16224	Formula: Enchant Cloak - Superior Defense
16242	Formula: Enchant Chest - Major Mana
16243	Formula: Runed Arcanite Rod
16244	Formula: Enchant Gloves - Greater Strength
16245	Formula: Enchant Boots - Greater Agility
16246	Formula: Enchant Bracer - Superior Strength
16247	Formula: Enchant 2H Weapon - Superior Impact
16248	Formula: Enchant Weapon - Unholy
16249	Formula: Enchant 2H Weapon - Major Intellect
16250	Formula: Enchant Weapon - Superior Striking
16251	Formula: Enchant Bracer - Superior Stamina
16252	Formula: Enchant Weapon - Crusader
16253	Formula: Enchant Chest - Greater Stats
16254	Formula: Enchant Weapon - Lifestealing
16255	Formula: Enchant 2H Weapon - Major Spirit
16262	Nessa's Collection
16263	Laird's Response
16282	Bundle of Hides
16283	Ahanu's Leather Goods
16302	Grimoire of Firebolt (Rank 2)
16303	Ursangous's Paw
16304	Shadumbra's Head
16305	Sharptalon's Claw
16306	Zargh's Meats
16307	Gryshka's Letter
16308	Northridge Crowbar
16309	Drakefire Amulet
16310	Brock's List
16311	Honorary Picks
16312	Incendrites
16313	Felix's Chest
16314	Felix's Bucket of Bolts
16315	Sergeant Major's Cape
16316	Grimoire of Firebolt (Rank 3)
16317	Grimoire of Firebolt (Rank 4)
16318	Grimoire of Firebolt (Rank 5)
16319	Grimoire of Firebolt (Rank 6)
16320	Grimoire of Firebolt (Rank 7)
16321	Grimoire of Blood Pact (Rank 1)
16322	Grimoire of Blood Pact (Rank 2)
16323	Grimoire of Blood Pact (Rank 3)
16324	Grimoire of Blood Pact (Rank 4)
16325	Grimoire of Blood Pact (Rank 5)
16326	Grimoire of Fire Shield (Rank 1)
16327	Grimoire of Fire Shield (Rank 2)
16328	Grimoire of Fire Shield (Rank 3)
16329	Grimoire of Fire Shield (Rank 4)
16330	Grimoire of Fire Shield (Rank 5)
16331	Grimoire of Phase Shift
16332	Thazz'ril's Pick
16333	Samuel's Remains
16334	Sergeant's Insignia
16335	Senior Sergeant's Insignia
16336	Sergeant Major's Cape
16337	Sergeant Major's Cape
16338	Knight-Lieutenant's Steed
16339	Commander's Steed
16340	First Sergeant's Cloak
16341	Sergeant's Cloak
16342	Sergeant's Cape
16343	Blood Guard's Mount
16344	zzUNUSEDLieutenant General's Mount
16345	High Warlord's Blade
16346	Grimoire of Torment (Rank 2)
16347	Grimoire of Torment (Rank 3)
16348	Grimoire of Torment (Rank 4)
16349	Grimoire of Torment (Rank 5)
16350	Grimoire of Torment (Rank 6)
16351	Grimoire of Sacrifice (Rank 1)
16352	Grimoire of Sacrifice (Rank 2)
16353	Grimoire of Sacrifice (Rank 3)
16354	Grimoire of Sacrifice (Rank 4)
16355	Grimoire of Sacrifice (Rank 5)
16356	Grimoire of Sacrifice (Rank 6)
16357	Grimoire of Consume Shadows (Rank 1)
16358	Grimoire of Consume Shadows (Rank 2)
16359	Grimoire of Consume Shadows (Rank 3)
16360	Grimoire of Consume Shadows (Rank 4)
16361	Grimoire of Consume Shadows (Rank 5)
16362	Grimoire of Consume Shadows (Rank 6)
16363	Grimoire of Suffering (Rank 1)
16364	Grimoire of Suffering (Rank 2)
16365	Grimoire of Suffering (Rank 3)
16366	Grimoire of Suffering (Rank 4)
16368	Grimoire of Lash of Pain (Rank 2)
16369	Knight-Lieutenant's Silk Boots
16371	Grimoire of Lash of Pain (Rank 3)
16372	Grimoire of Lash of Pain (Rank 4)
16373	Grimoire of Lash of Pain (Rank 5)
16374	Grimoire of Lash of Pain (Rank 6)
16375	Grimoire of Soothing Kiss (Rank 1)
16376	Grimoire of Soothing Kiss (Rank 2)
16377	Grimoire of Soothing Kiss (Rank 3)
16378	Grimoire of Soothing Kiss (Rank 4)
16379	Grimoire of Seduction
16380	Grimoire of Lesser Invisibility
16381	Grimoire of Devour Magic (Rank 2)
16382	Grimoire of Devour Magic (Rank 3)
16383	Grimoire of Devour Magic (Rank 4)
16384	Grimoire of Tainted Blood (Rank 1)
16385	Grimoire of Tainted Blood (Rank 2)
16386	Grimoire of Tainted Blood (Rank 3)
16387	Grimoire of Tainted Blood (Rank 4)
16388	Grimoire of Spell Lock (Rank 1)
16389	Grimoire of Spell Lock (Rank 2)
16390	Grimoire of Paranoia
16391	Knight-Lieutenant's Silk Gloves
16392	Knight-Lieutenant's Leather Boots
16393	Knight-Lieutenant's Dragonhide Footwraps
16396	Knight-Lieutenant's Leather Gauntlets
16397	Knight-Lieutenant's Dragonhide Gloves
16401	Knight-Lieutenant's Chain Boots
16403	Knight-Lieutenant's Chain Gauntlets
16405	Knight-Lieutenant's Plate Boots
16406	Knight-Lieutenant's Plate Gauntlets
16408	Befouled Water Globe
16409	Knight-Lieutenant's Lamellar Sabatons
16410	Knight-Lieutenant's Lamellar Gauntlets
16413	Knight-Captain's Silk Raiment
16414	Knight-Captain's Silk Leggings
16415	Lieutenant Commander's Silk Spaulders
16416	Lieutenant Commander's Crown
16417	Knight-Captain's Leather Armor
16418	Lieutenant Commander's Leather Veil
16419	Knight-Captain's Leather Legguards
16420	Lieutenant Commander's Leather Spaulders
16421	Knight-Captain's Dragonhide Tunic
16422	Knight-Captain's Dragonhide Leggings
16423	Lieutenant Commander's Dragonhide Epaulets
16424	Lieutenant Commander's Dragonhide Shroud
16425	Knight-Captain's Chain Hauberk
16426	Knight-Captain's Chain Leggings
16427	Lieutenant Commander's Chain Pauldrons
16428	Lieutenant Commander's Chain Helmet
16429	Lieutenant Commander's Plate Helm
16430	Knight-Captain's Plate Chestguard
16431	Knight-Captain's Plate Leggings
16432	Lieutenant Commander's Plate Pauldrons
16433	Knight-Captain's Lamellar Breastplate
16434	Lieutenant Commander's Lamellar Headguard
16435	Knight-Captain's Lamellar Leggings
16436	Lieutenant Commander's Lamellar Shoulders
16437	Marshal's Silk Footwraps
16440	Marshal's Silk Gloves
16441	Field Marshal's Coronet
16442	Marshal's Silk Leggings
16443	Field Marshal's Silk Vestments
16444	Field Marshal's Silk Spaulders
16446	Marshal's Leather Footguards
16448	Marshal's Dragonhide Gauntlets
16449	Field Marshal's Dragonhide Spaulders
16450	Marshal's Dragonhide Legguards
16451	Field Marshal's Dragonhide Helmet
16452	Field Marshal's Dragonhide Breastplate
16453	Field Marshal's Leather Chestpiece
16454	Marshal's Leather Handgrips
16455	Field Marshal's Leather Mask
16456	Marshal's Leather Leggings
16457	Field Marshal's Leather Epaulets
16459	Marshal's Dragonhide Boots
16462	Marshal's Chain Boots
16463	Marshal's Chain Grips
16465	Field Marshal's Chain Helm
16466	Field Marshal's Chain Breastplate
16467	Marshal's Chain Legguards
16468	Field Marshal's Chain Spaulders
16471	Marshal's Lamellar Gloves
16472	Marshal's Lamellar Boots
16473	Field Marshal's Lamellar Chestplate
16474	Field Marshal's Lamellar Faceguard
16475	Marshal's Lamellar Legplates
16476	Field Marshal's Lamellar Pauldrons
16477	Field Marshal's Plate Armor
16478	Field Marshal's Plate Helm
16479	Marshal's Plate Legguards
16480	Field Marshal's Plate Shoulderguards
16483	Marshal's Plate Boots
16484	Marshal's Plate Gauntlets
16485	Blood Guard's Silk Footwraps
16486	First Sergeant's Silk Cuffs
16487	Blood Guard's Silk Gloves
16489	Champion's Silk Hood
16490	Legionnaire's Silk Pants
16491	Legionnaire's Silk Robes
16492	Champion's Silk Shoulderpads
16494	Blood Guard's Dragonhide Boots
16496	Blood Guard's Dragonhide Gauntlets
16497	First Sergeant's Leather Armguards
16498	Blood Guard's Leather Treads
16499	Blood Guard's Leather Vices
16501	Champion's Dragonhide Spaulders
16502	Legionnaire's Dragonhide Trousers
16503	Champion's Dragonhide Helm
16504	Legionnaire's Dragonhide Breastplate
16505	Legionnaire's Leather Hauberk
16506	Champion's Leather Headguard
16507	Champion's Leather Mantle
16508	Legionnaire's Leather Leggings
16509	Blood Guard's Plate Boots
16510	Blood Guard's Plate Gloves
16513	Legionnaire's Plate Armor
16514	Champion's Plate Headguard
16515	Legionnaire's Plate Legguards
16516	Champion's Plate Pauldrons
16518	Blood Guard's Mail Walkers
16519	Blood Guard's Mail Grips
16521	Champion's Mail Helm
16522	Legionnaire's Mail Chestpiece
16523	Legionnaire's Mail Leggings
16524	Champion's Mail Shoulders
16525	Legionnaire's Chain Breastplate
16526	Champion's Chain Headguard
16527	Legionnaire's Chain Leggings
16528	Champion's Chain Pauldrons
16530	Blood Guard's Chain Gauntlets
16531	Blood Guard's Chain Boots
16532	First Sergeant's Mail Wristguards
16533	Warlord's Silk Cowl
16534	General's Silk Trousers
16535	Warlord's Silk Raiment
16536	Warlord's Silk Amice
16539	General's Silk Boots
16540	General's Silk Handguards
16541	Warlord's Plate Armor
16542	Warlord's Plate Headpiece
16543	General's Plate Leggings
16544	Warlord's Plate Shoulders
16545	General's Plate Boots
16548	General's Plate Gauntlets
16549	Warlord's Dragonhide Hauberk
16550	Warlord's Dragonhide Helmet
16551	Warlord's Dragonhide Epaulets
16552	General's Dragonhide Leggings
16554	General's Dragonhide Boots
16555	General's Dragonhide Gloves
16558	General's Leather Treads
16560	General's Leather Mitts
16561	Warlord's Leather Helm
16562	Warlord's Leather Spaulders
16563	Warlord's Leather Breastplate
16564	General's Leather Legguards
16565	Warlord's Chain Chestpiece
16566	Warlord's Chain Helmet
16567	General's Chain Legguards
16568	Warlord's Chain Shoulders
16569	General's Chain Boots
16571	General's Chain Gloves
16573	General's Mail Boots
16574	General's Mail Gauntlets
16577	Warlord's Mail Armor
16578	Warlord's Mail Helm
16579	General's Mail Leggings
16580	Warlord's Mail Spaulders
16581	Resonite Crystal
16583	Demonic Figurine
16602	Troll Charm
16603	Enchanted Resonite Crystal
16604	Moon Robes of Elune
16605	Friar's Robes of the Light
16606	Juju Hex Robes
16607	Acolyte's Sacrificial Robes
16608	Aquarius Belt
16622	Thornflinger
16623	Opaline Medallion
16642	Shredder Operating Manual - Chapter 1
16643	Shredder Operating Manual - Chapter 2
16644	Shredder Operating Manual - Chapter 3
16645	Shredder Operating Manual - Page 1
16646	Shredder Operating Manual - Page 2
16647	Shredder Operating Manual - Page 3
16648	Shredder Operating Manual - Page 4
16649	Shredder Operating Manual - Page 5
16650	Shredder Operating Manual - Page 6
16651	Shredder Operating Manual - Page 7
16652	Shredder Operating Manual - Page 8
16653	Shredder Operating Manual - Page 9
16654	Shredder Operating Manual - Page 10
16655	Shredder Operating Manual - Page 11
16656	Shredder Operating Manual - Page 12
16658	Wildhunter Cloak
16659	Deftkin Belt
16660	Driftmire Shield
16661	Soft Willow Cape
16662	Fragment of the Dragon's Eye
16663	Blood of the Black Dragon Champion
16664	Ornate Bracers
16665	Tome of Tranquilizing Shot
16666	Vest of Elements
16667	Coif of Elements
16668	Kilt of Elements
16669	Pauldrons of Elements
16670	Boots of Elements
16671	Bindings of Elements
16672	Gauntlets of Elements
16673	Cord of Elements
16674	Beaststalker's Tunic
16675	Beaststalker's Boots
16676	Beaststalker's Gloves
16677	Beaststalker's Cap
16678	Beaststalker's Pants
16679	Beaststalker's Mantle
16680	Beaststalker's Belt
16681	Beaststalker's Bindings
16682	Magister's Boots
16683	Magister's Bindings
16684	Magister's Gloves
16685	Magister's Belt
16686	Magister's Crown
16687	Magister's Leggings
16688	Magister's Robes
16689	Magister's Mantle
16690	Devout Robe
16691	Devout Sandals
16692	Devout Gloves
16693	Devout Crown
16694	Devout Skirt
16695	Devout Mantle
16696	Devout Belt
16697	Devout Bracers
16698	Dreadmist Mask
16699	Dreadmist Leggings
16700	Dreadmist Robe
16701	Dreadmist Mantle
16702	Dreadmist Belt
16703	Dreadmist Bracers
16704	Dreadmist Sandals
16705	Dreadmist Wraps
16706	Wildheart Vest
16707	Shadowcraft Cap
16708	Shadowcraft Spaulders
16709	Shadowcraft Pants
16710	Shadowcraft Bracers
16711	Shadowcraft Boots
16712	Shadowcraft Gloves
16713	Shadowcraft Belt
16714	Wildheart Bracers
16715	Wildheart Boots
16716	Wildheart Belt
16717	Wildheart Gloves
16718	Wildheart Spaulders
16719	Wildheart Kilt
16720	Wildheart Cowl
16721	Shadowcraft Tunic
16722	Lightforge Bracers
16723	Lightforge Belt
16724	Lightforge Gauntlets
16725	Lightforge Boots
16726	Lightforge Breastplate
16727	Lightforge Helm
16728	Lightforge Legplates
16729	Lightforge Spaulders
16730	Breastplate of Valor
16731	Helm of Valor
16732	Legplates of Valor
16733	Spaulders of Valor
16734	Boots of Valor
16735	Bracers of Valor
16736	Belt of Valor
16737	Gauntlets of Valor
16738	Witherseed Gloves
16739	Rugwood Mantle
16740	Shredder Operating Gloves
16741	Oilrag Handwraps
16742	Warsong Saw Blades
16743	Logging Rope
16744	Warsong Oil
16745	Warsong Axe Shipment
16746	Warsong Report
16747	Broken Lock
16748	Padded Lining
16762	Fathom Core
16763	Warsong Runner Update
16764	Warsong Scout Update
16765	Warsong Outrider Update
16766	Undermine Clam Chowder
16767	Recipe: Undermine Clam Chowder
16768	Furbolg Medicine Pouch
16769	Furbolg Medicine Totem
16782	Strange Water Globe
16783	Bundle of Reports
16784	Sapphire of Aku'Mai
16785	Rexxar's Testament
16786	Black Dragonspawn Eye
16787	Amulet of Draconic Subversion
16788	Captain Rackmore's Wheel
16789	Captain Rackmore's Tiller
16790	Damp Note
16791	Silkstream Cuffs
16792	Giant Club
16793	Arcmetal Shoulders
16794	Gripsteel Wristguards
16795	Arcanist Crown
16796	Arcanist Leggings
16797	Arcanist Mantle
16798	Arcanist Robes
16799	Arcanist Bindings
16800	Arcanist Boots
16801	Arcanist Gloves
16802	Arcanist Belt
16803	Felheart Slippers
16804	Felheart Bracers
16805	Felheart Gloves
16806	Felheart Belt
16807	Felheart Shoulder Pads
16808	Felheart Horns
16809	Felheart Robes
16810	Felheart Pants
16811	Boots of Prophecy
16812	Gloves of Prophecy
16813	Circlet of Prophecy
16814	Pants of Prophecy
16815	Robes of Prophecy
16816	Mantle of Prophecy
16817	Girdle of Prophecy
16818	Netherwind Belt
16819	Vambraces of Prophecy
16820	Nightslayer Chestpiece
16821	Nightslayer Cover
16822	Nightslayer Pants
16823	Nightslayer Shoulder Pads
16824	Nightslayer Boots
16825	Nightslayer Bracelets
16826	Nightslayer Gloves
16827	Nightslayer Belt
16828	Cenarion Belt
16829	Cenarion Boots
16830	Cenarion Bracers
16831	Cenarion Gloves
16832	Bloodfang Spaulders
16833	Cenarion Vestments
16834	Cenarion Helm
16835	Cenarion Leggings
16836	Cenarion Spaulders
16837	Earthfury Boots
16838	Earthfury Belt
16839	Earthfury Gauntlets
16840	Earthfury Bracers
16841	Earthfury Vestments
16842	Earthfury Helmet
16843	Earthfury Legguards
16844	Earthfury Epaulets
16845	Giantstalker's Breastplate
16846	Giantstalker's Helmet
16847	Giantstalker's Leggings
16848	Giantstalker's Epaulets
16849	Giantstalker's Boots
16850	Giantstalker's Bracers
16851	Giantstalker's Belt
16852	Giantstalker's Gloves
16853	Lawbringer Chestguard
16854	Lawbringer Helm
16855	Lawbringer Legplates
16856	Lawbringer Spaulders
16857	Lawbringer Bracers
16858	Lawbringer Belt
16859	Lawbringer Boots
16860	Lawbringer Gauntlets
16861	Bracers of Might
16862	Sabatons of Might
16863	Gauntlets of Might
16864	Belt of Might
16865	Breastplate of Might
16866	Helm of Might
16867	Legplates of Might
16868	Pauldrons of Might
16869	The Skull of Scryer
16870	The Skull of Somnus
16871	The Skull of Chronalis
16872	The Skull of Axtroz
16873	Braidfur Gloves
16882	Battered Junkbox
16883	Worn Junkbox
16884	Sturdy Junkbox
16885	Heavy Junkbox
16886	Outlaw Sabre
16887	Witch's Finger
16888	Dull Drakefire Amulet
16889	Polished Walking Staff
16890	Slatemetal Cutlass
16891	Claystone Shortsword
16892	Lesser Soulstone
16893	Soulstone
16894	Clear Crystal Rod
16895	Greater Soulstone
16896	Major Soulstone
16897	Stormrage Chestguard
16898	Stormrage Boots
16899	Stormrage Handguards
16900	Stormrage Cover
16901	Stormrage Legguards
16902	Stormrage Pauldrons
16903	Stormrage Belt
16904	Stormrage Bracers
16905	Bloodfang Chestpiece
16906	Bloodfang Boots
16907	Bloodfang Gloves
16908	Bloodfang Hood
16909	Bloodfang Pants
16910	Bloodfang Belt
16911	Bloodfang Bracers
16912	Netherwind Boots
16913	Netherwind Gloves
16914	Netherwind Crown
16915	Netherwind Pants
16916	Netherwind Robes
16917	Netherwind Mantle
16918	Netherwind Bindings
16919	Boots of Transcendence
16920	Handguards of Transcendence
16921	Halo of Transcendence
16922	Leggings of Transcendence
16923	Robes of Transcendence
16924	Pauldrons of Transcendence
16925	Belt of Transcendence
16926	Bindings of Transcendence
16927	Nemesis Boots
16928	Nemesis Gloves
16929	Nemesis Skullcap
16930	Nemesis Leggings
16931	Nemesis Robes
16932	Nemesis Spaulders
16933	Nemesis Belt
16934	Nemesis Bracers
16935	Dragonstalker's Bracers
16936	Dragonstalker's Belt
16937	Dragonstalker's Spaulders
16938	Dragonstalker's Legguards
16939	Dragonstalker's Helm
16940	Dragonstalker's Gauntlets
16941	Dragonstalker's Greaves
16942	Dragonstalker's Breastplate
16943	Bracers of Ten Storms
16944	Belt of Ten Storms
16945	Epaulets of Ten Storms
16946	Legplates of Ten Storms
16947	Helmet of Ten Storms
16948	Gauntlets of Ten Storms
16949	Greaves of Ten Storms
16950	Breastplate of Ten Storms
16951	Judgement Bindings
16952	Judgement Belt
16953	Judgement Spaulders
16954	Judgement Legplates
16955	Judgement Crown
16956	Judgement Gauntlets
16957	Judgement Sabatons
16958	Judgement Breastplate
16959	Bracelets of Wrath
16960	Waistband of Wrath
16961	Pauldrons of Wrath
16962	Legplates of Wrath
16963	Helm of Wrath
16964	Gauntlets of Wrath
16965	Sabatons of Wrath
16966	Breastplate of Wrath
16967	Feralas Ahi
16968	Sar'theris Striker
16969	Savage Coast Blue Sailfin
16970	Misty Reed Mahi Mahi
16971	Clamlette Surprise
16972	Karang's Banner
16973	Vial of Dire Water
16974	Empty Water Vial
16975	Warsong Sash
16976	Murgut's Totem
16977	Warsong Boots
16978	Warsong Gauntlets
16979	Flarecore Gloves
16980	Flarecore Mantle
16981	Owlbeard Bracers
16982	Corehound Boots
16983	Molten Helm
16984	Black Dragonscale Boots
16985	Windseeker Boots
16986	Sandspire Gloves
16987	Screecher Belt
16988	Fiery Chain Shoulders
16989	Fiery Chain Girdle
16990	Spritekin Cloak
16991	Triage Bandage
16992	Smokey's Explosive Launcher
16993	Smokey's Fireshooter
16994	Duskwing Gloves
16995	Duskwing Mantle
16996	Gorewood Bow
16997	Stormrager
16998	Sacred Protector
16999	Royal Seal of Alexis
17000	Band of the Wraith
17001	Elemental Circle
17002	Ichor Spitter
17003	Skullstone Hammer
17004	Sarah's Guide
17005	Boorguard Tunic
17006	Cobalt Legguards
17007	Stonerender Gauntlets
17008	Small Scroll
17009	Ambassador Malcin's Head
17010	Fiery Core
17011	Lava Core
17012	Core Leather
17013	Dark Iron Leggings
17014	Dark Iron Bracers
17015	Dark Iron Reaver
17016	Dark Iron Destroyer
17017	Pattern: Flarecore Mantle
17018	Pattern: Flarecore Gloves
17019	Arcane Dust
17020	Arcane Powder
17021	Wild Berries
17022	Pattern: Corehound Boots
17023	Pattern: Molten Helm
17024	Wild Root
17025	Pattern: Black Dragonscale Boots
17026	Wild Thornroot
17027	Scented Candle
17028	Holy Candle
17029	Sacred Candle
17030	Ankh
17031	Rune of Teleportation
17032	Rune of Portals
17033	Symbol of Divinity
17034	Maple Seed
17035	Stranglethorn Seed
17036	Ashwood Seed
17037	Hornbeam Seed
17038	Ironwood Seed
17039	Skullbreaker
17042	Nail Spitter
17043	Zealot's Robe
17044	Will of the Martyr
17045	Blood of the Martyr
17046	Gutterblade
17047	Luminescent Amice
17048	Rumsey Rum
17049	Plans: Fiery Chain Girdle
17050	Chan's Imperial Robes
17051	Plans: Dark Iron Bracers
17052	Plans: Dark Iron Leggings
17053	Plans: Fiery Chain Shoulders
17054	Joonho's Mercy
17055	Changuk Smasher
17056	Light Feather
17057	Shiny Fish Scales
17058	Fish Oil
17059	Plans: Dark Iron Reaver
17060	Plans: Dark Iron Destroyer
17061	Juno's Shadow
17062	Recipe: Mithril Head Trout
17063	Band of Accuria
17064	Shard of the Scale
17065	Medallion of Steadfast Might
17066	Drillborer Disk
17067	Ancient Cornerstone Grimoire
17068	Deathbringer
17069	Striker's Mark
17070	Fang of the Mystics
17071	Gutgore Ripper
17072	Blastershot Launcher
17073	Earthshaker
17074	Shadowstrike
17075	Vis'kag the Bloodletter
17076	Bonereaver's Edge
17077	Crimson Shocker
17078	Sapphiron Drape
17082	Shard of the Flame
17102	Cloak of the Shrouded Mists
17103	Azuresong Mageblade
17104	Spinal Reaper
17105	Aurastone Hammer
17106	Malistar's Defender
17107	Dragon's Blood Cape
17108	Mark of Deflection
17109	Choker of Enlightenment
17110	Seal of the Archmagus
17111	Blazefury Medallion
17112	Empyrean Demolisher
17113	Amberseal Keeper
17114	Araj's Phylactery Shard
17115	Squirrel Token
17116	Squirrel Token
17117	Rat Catcher's Flute
17118	Carton of Mystery Meat
17119	Deeprun Rat Kabob
17124	Syndicate Emblem
17125	Seal of Ravenholdt
17126	Elegant Letter
17142	Shard of the Defiler
17182	Sulfuras, Hand of Ragnaros
17183	Dented Buckler
17184	Small Shield
17185	Round Buckler
17186	Small Targe
17187	Banded Buckler
17188	Ringed Buckler
17189	Metal Buckler
17190	Ornate Buckler
17191	Scepter of Celebras
17192	Reinforced Targe
17193	Sulfuron Hammer
17194	Holiday Spices
17195	Fake Mistletoe
17196	Holiday Spirits
17197	Gingerbread Cookie
17198	Egg Nog
17199	Bad Egg Nog
17200	Recipe: Gingerbread Cookie
17201	Recipe: Egg Nog
17202	Snowball
17203	Sulfuron Ingot
17204	Eye of Sulfuras
17222	Spider Sausage
17223	Thunderstrike
17224	Scrying Scope
17242	Key to Salem's Chest
17262	James' Key
17302	Blue Ribboned Holiday Gift
17303	Blue Ribboned Wrapping Paper
17304	Green Ribboned Wrapping Paper
17305	Green Ribboned Holiday Gift
17306	Stormpike Soldier's Blood
17307	Purple Ribboned Wrapping Paper
17308	Purple Ribboned Holiday Gift
17309	Discordant Bracers
17310	Aspect of Neptulon
17322	Eye of the Emberseer
17323	Mulverick's Beacon
17324	Guse's Beacon
17325	Jeztor's Beacon
17326	Stormpike Soldier's Flesh
17327	Stormpike Lieutenant's Flesh
17328	Stormpike Commander's Flesh
17329	Hand of Lucifron
17330	Hand of Sulfuron
17331	Hand of Gehennas
17332	Hand of Shazzrah
17333	Aqual Quintessence
17344	Candy Cane
17345	Silithid Goo
17346	Encrusted Silithid Object
17347	Syndicate Man Tracker (MURP)
17348	Major Healing Draught
17349	Superior Healing Draught
17351	Major Mana Draught
17352	Superior Mana Draught
17353	Stormpike Assault Orders
17354	Master Ryson's All Seeing Eye
17355	Rabine's Letter
17362	Ryson's Beacon
17363	Ryson's Beacon
17364	Scrying Scope
17384	Zinfizzlex's Portable Shredder Unit
17402	Greatfather's Winter Ale
17403	Steamwheedle Fizzy Spirits
17404	Blended Bean Brew
17405	Green Garden Tea
17406	Holiday Cheesewheel
17407	Graccu's Homemade Meat Pie
17408	Spicy Beefstick
17409	Encrusted Crystal Fragment
17410	Zinfizzlex's Portable Shredder Unit
17411	Steamsaw
17413	Codex: Prayer of Fortitude
17414	Codex: Prayer of Fortitude II
17422	Armor Scraps
17423	Storm Crystal
17442	Frostwolf Assault Orders
17502	Frostwolf Soldier's Medal
17503	Frostwolf Lieutenant's Medal
17504	Frostwolf Commander's Medal
17505	Ichman's Beacon
17506	Vipore's Beacon
17507	Slidore's Beacon
17508	Forcestone Buckler
17522	Irondeep Supplies
17523	Smokey's Drape
17542	Coldtooth Supplies
17562	Knight-Lieutenant's Dreadweave Boots
17564	Knight-Lieutenant's Dreadweave Gloves
17566	Lieutenant Commander's Headguard
17567	Knight-Captain's Dreadweave Leggings
17568	Knight-Captain's Dreadweave Robe
17569	Lieutenant Commander's Dreadweave Mantle
17570	Champion's Dreadweave Hood
17571	Legionnaire's Dreadweave Leggings
17572	Legionnaire's Dreadweave Robe
17573	Champion's Dreadweave Shoulders
17576	Blood Guard's Dreadweave Boots
17577	Blood Guard's Dreadweave Gloves
17578	Field Marshal's Coronal
17579	Marshal's Dreadweave Leggings
17580	Field Marshal's Dreadweave Shoulders
17581	Field Marshal's Dreadweave Robe
17583	Marshal's Dreadweave Boots
17584	Marshal's Dreadweave Gloves
17586	General's Dreadweave Boots
17588	General's Dreadweave Gloves
17590	Warlord's Dreadweave Mantle
17591	Warlord's Dreadweave Hood
17592	Warlord's Dreadweave Robe
17593	General's Dreadweave Pants
17594	Knight-Lieutenant's Satin Boots
17596	Knight-Lieutenant's Satin Gloves
17598	Lieutenant Commander's Diadem
17599	Knight-Captain's Satin Leggings
17600	Knight-Captain's Satin Robes
17601	Lieutenant Commander's Satin Amice
17602	Field Marshal's Headdress
17603	Marshal's Satin Pants
17604	Field Marshal's Satin Mantle
17605	Field Marshal's Satin Vestments
17607	Marshal's Satin Sandals
17608	Marshal's Satin Gloves
17610	Champion's Satin Cowl
17611	Legionnaire's Satin Trousers
17612	Legionnaire's Satin Vestments
17613	Champion's Satin Shoulderpads
17616	Blood Guard's Satin Boots
17617	Blood Guard's Satin Gloves
17618	General's Satin Boots
17620	General's Satin Gloves
17622	Warlord's Satin Mantle
17623	Warlord's Satin Cowl
17624	Warlord's Satin Robes
17625	General's Satin Leggings
17626	Frostwolf Muzzle
17642	Alterac Ram Hide
17643	Frostwolf Hide
17662	Stolen Treats
17682	Book: Gift of the Wild
17683	Book: Gift of the Wild II
17684	Theradric Crystal Carving
17685	Smokywood Pastures Sampler
17686	Master Hunter's Bow
17687	Master Hunter's Rifle
17688	Jungle Boots
17689	Stormpike Training Collar
17690	Frostwolf Insignia Rank 1
17691	Stormpike Insignia Rank 1
17692	Horn Ring
17693	Coated Cerulean Vial
17694	Band of the Fist
17695	Chestnut Mantle
17696	Filled Cerulean Vial
17702	Celebrian Rod
17703	Celebrian Diamond
17704	Edge of Winter
17705	Thrash Blade
17706	Plans: Edge of Winter
17707	Gemshard Heart
17708	Elixir of Frost Power
17709	Recipe: Elixir of Frost Power
17710	Charstone Dirk
17711	Elemental Rockridge Leggings
17712	Winter Veil Disguise Kit
17713	Blackstone Ring
17714	Bracers of the Stone Princess
17715	Eye of Theradras
17716	SnowMaster 9000
17717	Megashot Rifle
17718	Gizlock's Hypertech Buckler
17719	Inventor's Focal Sword
17720	Schematic: Snowmaster 9000
17721	Gloves of the Greatfather
17722	Pattern: Gloves of the Greatfather
17723	Green Holiday Shirt
17724	Pattern: Green Holiday Shirt
17725	Formula: Enchant Weapon - Winter's Might
17726	Smokywood Pastures Special Gift
17727	Smokywood Pastures Gift Pack
17728	Albino Crocscale Boots
17730	Gatorbite Axe
17731	Scroll of Celebras
17732	Rotgrip Mantle
17733	Fist of Stone
17734	Helm of the Mountain
17735	The Feast of Winter Veil
17736	Rockgrip Gauntlets
17737	Cloud Stone
17738	Claw of Celebras
17739	Grovekeeper's Drape
17740	Soothsayer's Headdress
17741	Nature's Embrace
17742	Fungus Shroud Armor
17743	Resurgence Rod
17744	Heart of Noxxion
17745	Noxious Shooter
17746	Noxxion's Shackles
17747	Razorlash Root
17748	Vinerot Sandals
17749	Phytoskin Spaulders
17750	Chloromesh Girdle
17751	Brusslehide Leggings
17752	Satyr's Lash
17753	Verdant Keeper's Aim
17754	Infernal Trickster Leggings
17755	Satyrmane Sash
17756	Shadowshard Fragment
17757	Amulet of Spirits
17758	Amulet of Union
17759	Mark of Resolution
17760	Seed of Life
17761	Gem of the First Khan
17762	Gem of the Second Kahn
17763	Gem of the Third Kahn
17764	Gem of the Fourth Kahn
17765	Gem of the Fifth Kahn
17766	Princess Theradras' Scepter
17767	Bloomsprout Headpiece
17768	Woodseed Hoop
17769	Sagebrush Spaulders
17770	Branchclaw Gauntlets
17771	Elementium Bar
17772	Zealous Shadowshard Pendant
17773	Prodigious Shadowshard Pendant
17774	Mark of the Chosen
17775	Acumen Robes
17776	Sprightring Helm
17777	Relentless Chain
17778	Sagebrush Girdle
17779	Hulkstone Pauldrons
17780	Blade of Eternal Darkness
17781	The Pariah's Instructions
17782	Talisman of Binding Shard
17783	Talisman of Binding Fragment
17822	Frostwolf Maps
17823	Stormpike Battle Plans
17849	Stormpike Banner
17850	Frostwolf Banner
17900	Stormpike Insignia Rank 2
17901	Stormpike Insignia Rank 3
17902	Stormpike Insignia Rank 4
17903	Stormpike Insignia Rank 5
17904	Stormpike Insignia Rank 6
17905	Frostwolf Insignia Rank 2
17906	Frostwolf Insignia Rank 3
17907	Frostwolf Insignia Rank 4
17908	Frostwolf Insignia Rank 5
17909	Frostwolf Insignia Rank 6
17922	Lionfur Armor
17943	Fist of Stone
17962	Blue Sack of Gems
17963	Green Sack of Gems
17964	Gray Sack of Gems
17965	Yellow Sack of Gems
17966	Onyxia Hide Backpack
17967	Refined Scale of Onyxia
17968	Charged Scale of Onyxia
17969	Red Sack of Gems
17982	Ragnaros Core
18000	Tough Jerky
18001	Tough Hunk of Bread
18002	Forest Mushroom Cap
18005	Refreshing Spring Water
18022	Royal Seal of Alexis
18023	Blood Ruby Pendant
18042	Thorium Headed Arrow
18043	Coal Miner Boots
18044	Hurley's Tankard
18045	Tender Wolf Steak
18046	Recipe: Tender Wolf Steak
18047	Flame Walkers
18048	Mastersmith's Hammer
18082	Zum'rah's Vexing Cane
18083	Jumanza Grips
18102	Dragonrider Boots
18103	Band of Rumination
18104	Feralsurge Girdle
18142	Severed Night Elf Head
18143	Tuft of Gnome Hair
18144	Human Bone Chip
18145	Tauren Hoof
18146	Darkspear Troll Mojo
18147	Forsaken Heart
18148	Skull of Korrak
18149	Rune of Recall
18150	Rune of Recall
18151	Filled Amethyst Phial
18152	Amethyst Phial
18153	Red Moro'gai Gem
18154	Blizzard Stationery
18155	Blue Moro'gai Gem
18156	Green Moro'gai Gem
18157	Black Moro'gai Gem
18158	Gold Moro'gai Gem
18159	White Moro'gai Gem
18160	Recipe: Thistle Tea
18168	Force Reactive Disk
18169	Flame Mantle of the Dawn
18170	Frost Mantle of the Dawn
18171	Arcane Mantle of the Dawn
18172	Nature Mantle of the Dawn
18173	Shadow Mantle of the Dawn
18182	Chromatic Mantle of the Dawn
18202	Eskhandar's Left Claw
18203	Eskhandar's Right Claw
18204	Eskhandar's Pelt
18205	Eskhandar's Collar
18206	Dwarf Spine
18207	Orc Tooth
18208	Drape of Benediction
18209	Energized Sparkplug
18222	Thorny Vine
18223	Serrated Petal
18224	Lasher Root
18225	Worn Running Shoes
18226	A Sealed Pact
18227	Nubless Pacifier
18228	Autographed Picture of Foror & Tigule
18229	Nat Pagle's Guide to Extreme Anglin'
18230	Broken I.W.I.N. Button
18231	Sleeveless T-Shirt
18232	Field Repair Bot 74A
18233	Tear Stained Handkerchief
18234	Document from Boomstick Imports
18235	Schematic: Field Repair Bot 74A
18236	Gordok Chew Toy
18237	Mastiff Jawbone
18238	Shadowskin Gloves
18239	Pattern: Shadowskin Gloves
18240	Ogre Tannin
18241	Black War Steed Bridle
18242	Reins of the Black War Tiger
18243	Black Battlestrider
18244	Black War Ram
18245	Horn of the Black War Wolf
18246	Whistle of the Black War Raptor
18247	Black War Kodo
18248	Red Skeletal Warhorse
18249	Crescent Key
18250	Gordok Shackle Key
18251	Core Armor Kit
18252	Pattern: Core Armor Kit
18253	Major Rejuvenation Potion
18254	Runn Tum Tuber Surprise
18255	Runn Tum Tuber
18256	Imbued Vial
18257	Recipe: Major Rejuvenation Potion
18258	Gordok Ogre Suit
18259	Formula: Enchant Weapon - Spell Power
18260	Formula: Enchant Weapon - Healing Power
18261	Book of Incantations
18262	Elemental Sharpening Stone
18263	Flarecore Wraps
18264	Plans: Elemental Sharpening Stone
18265	Pattern: Flarecore Wraps
18266	Gordok Courtyard Key
18267	Recipe: Runn Tum Tuber Surprise
18268	Gordok Inner Door Key
18269	Gordok Green Grog
18282	Core Marksman Rifle
18283	Biznicks 247x128 Accurascope
18284	Kreeg's Stout Beatdown
18285	Crystallized Mana Shard
18286	Condensed Mana Fragment
18287	Evermurky
18288	Molasses Firewater
18289	Barbed Thorn Necklace
18290	Schematic: Biznicks 247x128 Accurascope
18291	Schematic: Force Reactive Disk
18292	Schematic: Core Marksman Rifle
18294	Elixir of Greater Water Breathing
18295	Phasing Boots
18296	Marksman Bands
18297	Thornling Seed
18298	Unbridled Leggings
18299	Hydrospawn Essence
18300	Hyjal Nectar
18301	Lethtendris's Wand
18302	Band of Vigor
18303	Nimble Buckler
18304	Greenroot Mail
18305	Breakwater Legguards
18306	Gloves of Shadowy Mist
18307	Riptide Shoes
18308	Clever Hat
18309	Gloves of Restoration
18310	Fiendish Machete
18311	Quel'dorai Channeling Rod
18312	Energized Chestplate
18313	Helm of Awareness
18314	Ring of Demonic Guile
18315	Ring of Demonic Potency
18316	Obsidian Bauble
18317	Tempest Talisman
18318	Merciful Greaves
18319	Fervent Helm
18320	Demonheart Spaulders
18321	Energetic Rod
18322	Waterspout Boots
18323	Satyr's Bow
18324	Waveslicer
18325	Felhide Cap
18326	Razor Gauntlets
18327	Whipvine Cord
18328	Shadewood Cloak
18329	Arcanum of Rapidity
18330	Arcanum of Focus
18331	Arcanum of Protection
18332	Libram of Rapidity
18333	Libram of Focus
18334	Libram of Protection
18335	Pristine Black Diamond
18336	Gauntlet of Gordok Might
18337	Orphic Bracers
18338	Wand of Arcane Potency
18339	Eidolon Cloak
18340	Eidolon Talisman
18341	Quel'dorei Sash
18342	Quel'dorei Guard
18343	Petrified Band
18344	Stonebark Gauntlets
18345	Murmuring Ring
18346	Threadbare Trousers
18347	Well Balanced Axe
18348	Quel'Serrar
18349	Gauntlets of Accuracy
18350	Amplifying Cloak
18351	Magically Sealed Bracers
18352	Petrified Bark Shield
18353	Stoneflower Staff
18354	Pimgib's Collar
18355	Ferra's Collar
18356	Garona: A Study on Stealth and Treachery
18357	Codex of Defense
18358	The Arcanist's Cookbook
18359	The Light and How to Swing It
18360	Harnessing Shadows
18361	The Greatest Race of Hunters
18362	Holy Bologna: What the Light Won't Tell You
18363	Frost Shock and You
18364	The Emerald Dream
18365	A Thoroughly Read Copy of "Nat Pagle's Extreme' Anglin."
18366	Gordok's Handguards
18367	Gordok's Gauntlets
18368	Gordok's Gloves
18369	Gordok's Handwraps
18370	Vigilance Charm
18371	Mindtap Talisman
18372	Blade of the New Moon
18373	Chestplate of Tranquility
18374	Flamescarred Shoulders
18375	Bracers of the Eclipse
18376	Timeworn Mace
18377	Quickdraw Gloves
18378	Silvermoon Leggings
18379	Odious Greaves
18380	Eldritch Reinforced Legplates
18381	Evil Eye Pendant
18382	Fluctuating Cloak
18383	Force Imbued Gauntlets
18384	Bile-etched Spaulders
18385	Robe of Everlasting Night
18386	Padre's Trousers
18387	Brightspark Gloves
18388	Stoneshatter
18389	Cloak of the Cosmos
18390	Tanglemoss Leggings
18391	Eyestalk Cord
18392	Distracting Dagger
18393	Warpwood Binding
18394	Demon Howl Wristguards
18395	Emerald Flame Ring
18396	Mind Carver
18397	Elder Magus Pendant
18398	Tidal Loop
18399	Ocean's Breeze
18400	Ring of Living Stone
18401	Foror's Compendium of Dragon Slaying
18402	Glowing Crystal Ring
18403	Dragonslayer's Signet
18404	Onyxia Tooth Pendant
18405	Belt of the Archmage
18406	Onyxia Blood Talisman
18407	Felcloth Gloves
18408	Inferno Gloves
18409	Mooncloth Gloves
18410	Sprinter's Sword
18411	Spry Boots
18412	Core Fragment
18413	Cloak of Warding
18414	Pattern: Belt of the Archmage
18415	Pattern: Felcloth Gloves
18416	Pattern: Inferno Gloves
18417	Pattern: Mooncloth Gloves
18418	Pattern: Cloak of Warding
18420	Bonecrusher
18421	Backwood Helm
18422	Head of Onyxia
18423	Head of Onyxia
18424	Sedge Boots
18425	Kreeg's Mug
18426	Lethtendris's Web
18427	Sergeant's Cloak
18428	Senior Sergeant's Insignia
18429	First Sergeant's Plate Bracers
18430	First Sergeant's Plate Bracers
18432	First Sergeant's Mail Wristguards
18434	First Sergeant's Dragonhide Armguards
18435	First Sergeant's Leather Armguards
18436	First Sergeant's Dragonhide Armguards
18437	First Sergeant's Silk Cuffs
18438	Sergeant's Mark
18440	Sergeant's Cape
18441	Sergeant's Cape
18442	Master Sergeant's Insignia
18443	Master Sergeant's Insignia
18444	Master Sergeant's Insignia
18445	Sergeant Major's Plate Wristguards
18447	Sergeant Major's Plate Wristguards
18448	Sergeant Major's Chain Armguards
18449	Sergeant Major's Chain Armguards
18450	Robe of Combustion
18451	Hyena Hide Belt
18452	Sergeant Major's Leather Armsplints
18453	Sergeant Major's Leather Armsplints
18454	Sergeant Major's Dragonhide Armsplints
18455	Sergeant Major's Dragonhide Armsplints
18456	Sergeant Major's Silk Cuffs
18457	Sergeant Major's Silk Cuffs
18458	Modest Armguards
18459	Gallant's Wristguards
18460	Unsophisticated Hand Cannon
18461	Sergeant's Cloak
18462	Jagged Bone Fist
18463	Ogre Pocket Knife
18464	Gordok Nose Ring
18465	Royal Seal of Eldre'Thalas
18466	Royal Seal of Eldre'Thalas
18467	Royal Seal of Eldre'Thalas
18468	Royal Seal of Eldre'Thalas
18469	Royal Seal of Eldre'Thalas
18470	Royal Seal of Eldre'Thalas
18471	Royal Seal of Eldre'Thalas
18472	Royal Seal of Eldre'Thalas
18473	Royal Seal of Eldre'Thalas
18475	Oddly Magical Belt
18476	Mud Stained Boots
18477	Shaggy Leggings
18478	Hyena Hide Jerkin
18479	Carrion Scorpid Helm
18480	Scarab Plate Helm
18481	Skullcracking Mace
18482	Ogre Toothpick Shooter
18483	Mana Channeling Wand
18484	Cho'Rush's Blade
18485	Observer's Shield
18486	Mooncloth Robe
18487	Pattern: Mooncloth Robe
18488	Heated Ancient Blade
18489	Unfired Ancient Blade
18490	Insightful Hood
18491	Lorespinner
18492	Treated Ancient Blade
18493	Bulky Iron Spaulders
18494	Denwatcher's Shoulders
18495	Redoubt Cloak
18496	Heliotrope Cloak
18497	Sublime Wristguards
18498	Hedgecutter
18499	Barrier Shield
18500	Tarnished Elven Ring
18501	Felvine Shard
18502	Monstrous Glaive
18503	Kromcrush's Chestplate
18504	Girdle of Insight
18505	Mugger's Belt
18506	Mongoose Boots
18507	Boots of the Full Moon
18508	Swift Flight Bracers
18509	Chromatic Cloak
18510	Hide of the Wild
18511	Shifting Cloak
18512	Larval Acid
18513	A Dull and Flat Elven Blade
18514	Pattern: Girdle of Insight
18515	Pattern: Mongoose Boots
18516	Pattern: Swift Flight Bracers
18517	Pattern: Chromatic Cloak
18518	Pattern: Hide of the Wild
18519	Pattern: Shifting Cloak
18520	Barbarous Blade
18521	Grimy Metal Boots
18522	Band of the Ogre King
18523	Brightly Glowing Stone
18524	Leggings of Destruction
18525	Bracers of Prosperity
18526	Crown of the Ogre King
18527	Harmonious Gauntlets
18528	Cyclone Spaulders
18529	Elemental Plate Girdle
18530	Ogre Forged Hauberk
18531	Unyielding Maul
18532	Mindsurge Robe
18533	Gordok Bracers of Power
18534	Rod of the Ogre Magi
18535	Milli's Shield
18536	Milli's Lexicon
18537	Counterattack Lodestone
18538	Treant's Bane
18539	Reliquary of Purity
18540	Sealed Reliquary of Purity
18541	Puissant Cape
18542	Typhoon
18543	Ring of Entropy
18544	Doomhide Gauntlets
18545	Leggings of Arcane Supremacy
18546	Infernal Headcage
18547	Unmelting Ice Girdle
18562	Elementium Ore
18563	Bindings of the Windseeker
18564	Bindings of the Windseeker
18565	Vessel of Rebirth
18566	Essence of the Firelord
18567	Elemental Flux
18582	The Twin Blades of Azzinoth
18583	Warglaive of Azzinoth (Right)
18584	Warglaive of Azzinoth (Left)
18585	Band of Allegiance
18586	Lonetree's Circle
18587	Goblin Jumper Cables XL
18588	Ez-Thro Dynamite II
18590	Raging Beast's Blood
18591	Case of Blood
18592	Plans: Sulfuron Hammer
18594	Powerful Seaforium Charge
18595	Blood Opal
18597	Orcish Orphan Whistle
18598	Human Orphan Whistle
18600	Tome of Arcane Brilliance
18601	Glowing Crystal Prison
18602	Tome of Sacrifice
18603	Satyr Blood
18604	Tears of the Hederine
18605	Imprisoned Doomguard
18606	Alliance Battle Standard
18607	Horde Battle Standard
18608	Benediction
18609	Anathema
18610	Keen Machete
18611	Gnarlpine Leggings
18612	Bloody Chain Boots
18622	Flawless Fel Essence (Jaedenar)
18623	Flawless Fel Essence (Dark Portal)
18624	Flawless Fel Essence (Azshara)
18625	Kroshius' Infernal Core
18626	Fel Fire
18627	Gong of Dethmoora
18628	Thorium Brotherhood Contract
18629	Black Lodestone
18630	Doomsday Flare
18631	Truesilver Transformer
18632	Moonbrook Riot Taffy
18633	Styleen's Sour Suckerpop
18634	Gyrofreeze Ice Reflector
18635	Bellara's Nutterbar
18636	Ruined Jumper Cables XL
18637	Major Recombobulator
18638	Hyper-Radiant Flame Reflector
18639	Ultra-Flash Shadow Reflector
18640	Happy Fun Rock
18641	Dense Dynamite
18642	Jaina's Autograph
18643	Cairne's Hoofprint
18645	Alarm-O-Bot
18646	The Eye of Divinity
18647	Schematic: Red Firework
18648	Schematic: Green Firework
18649	Schematic: Blue Firework
18650	Schematic: EZ-Thro Dynamite II
18651	Schematic: Truesilver Transformer
18652	Schematic: Gyrofreeze Ice Reflector
18653	Schematic: Goblin Jumper Cables XL
18654	Schematic: Gnomish Alarm-O-Bot
18655	Schematic: Major Recombobulator
18656	Schematic: Powerful Seaforium Charge
18657	Schematic: Hyper-Radiant Flame Reflector
18658	Schematic: Ultra-Flash Shadow Reflector
18659	Splinter of Nordrassil
18660	World Enlarger
18661	Schematic: World Enlarger
18662	Heavy Leather Ball
18663	J'eevee's Jar
18664	A Treatise on Military Ranks
18665	The Eye of Shadow
18670	Xorothian Glyphs
18671	Baron Charr's Sceptre
18672	Elemental Ember
18673	Avalanchion's Stony Hide
18674	Hardened Stone Band
18675	Military Ranks of the Horde & Alliance
18676	Sash of the Windreaver
18677	Zephyr Cloak
18678	Tempestria's Frozen Necklace
18679	Frigid Ring
18680	Ancient Bone Bow
18681	Burial Shawl
18682	Ghoul Skin Leggings
18683	Hammer of the Vesper
18684	Dimly Opalescent Ring
18686	Bone Golem Shoulders
18687	Xorothian Stardust
18688	Imp in a Jar
18689	Phantasmal Cloak
18690	Wraithplate Leggings
18691	Dark Advisor's Pendant
18692	Death Knight Sabatons
18693	Shivery Handwraps
18694	Shadowy Mail Greaves
18695	Spellbound Tome
18696	Intricately Runed Shield
18697	Coldstone Slippers
18698	Tattered Leather Hood
18699	Icy Tomb Spaulders
18700	Malefic Bracers
18701	Innervating Band
18702	Belt of the Ordained
18703	Ancient Petrified Leaf
18704	Mature Blue Dragon Sinew
18705	Mature Black Dragon Sinew
18706	Arena Master
18707	Ancient Rune Etched Stave
18708	Petrified Bark
18709	Arena Wristguards
18710	Arena Bracers
18711	Arena Bands
18712	Arena Vambraces
18713	Rhok'delar, Longbow of the Ancient Keepers
18714	Ancient Sinew Wrapped Lamina
18715	Lok'delar, Stave of the Ancient Keepers
18716	Ash Covered Boots
18717	Hammer of the Grand Crusader
18718	Grand Crusader's Helm
18719	The Traitor's Heart
18720	Shroud of the Nathrezim
18721	Barrage Girdle
18722	Death Grips
18723	Animated Chain Necklace
18724	Enchanted Black Dragon Sinew
18725	Peacemaker
18726	Magistrate's Cuffs
18727	Crimson Felt Hat
18728	Anastari Heirloom
18729	Screeching Bow
18730	Shadowy Laced Handwraps
18731	Pattern: Heavy Leather Ball
18734	Pale Moon Cloak
18735	Maleki's Footwraps
18736	Plaguehound Leggings
18737	Bone Slicing Hatchet
18738	Carapace Spine Crossbow
18739	Chitinous Plate Legguards
18740	Thuzadin Sash
18741	Morlune's Bracer
18742	Stratholme Militia Shoulderguard
18743	Gracious Cape
18744	Plaguebat Fur Gloves
18745	Sacred Cloth Leggings
18746	Divination Scryer
18749	Charger's Lost Soul
18752	Exorcism Censer
18753	Arcanite Barding
18754	Fel Hardened Bracers
18755	Xorothian Firestick
18756	Dreadguard's Protector
18757	Diabolic Mantle
18758	Specter's Blade
18759	Malicious Axe
18760	Necromantic Band
18761	Oblivion's Touch
18762	Shard of the Green Flame
18766	Reins of the Swift Frostsaber
18767	Reins of the Swift Mistsaber
18768	Reins of the Swift Dawnsaber
18769	Enchanted Thorium Platemail
18770	Enchanted Thorium Platemail
18771	Enchanted Thorium Platemail
18772	Swift Green Mechanostrider
18773	Swift White Mechanostrider
18774	Swift Yellow Mechanostrider
18775	Manna-Enriched Horse Feed
18776	Swift Palomino
18777	Swift Brown Steed
18778	Swift White Steed
18779	Bottom Half of Advanced Armorsmithing: Volume I
18780	Top Half of Advanced Armorsmithing: Volume I
18781	Bottom Half of Advanced Armorsmithing: Volume II
18782	Top Half of Advanced Armorsmithing: Volume II
18783	Bottom Half of Advanced Armorsmithing: Volume III
18784	Top Half of Advanced Armorsmithing: Volume III
18785	Swift White Ram
18786	Swift Brown Ram
18787	Swift Gray Ram
18788	Swift Blue Raptor
18789	Swift Olive Raptor
18790	Swift Orange Raptor
18791	Purple Skeletal Warhorse
18792	Blessed Arcanite Barding
18793	Great White Kodo
18794	Great Brown Kodo
18795	Great Gray Kodo
18796	Horn of the Swift Brown Wolf
18797	Horn of the Swift Timber Wolf
18798	Horn of the Swift Gray Wolf
18799	Charger's Redeemed Soul
18802	Shadowy Potion
18803	Finkle's Lava Dredger
18804	Lord Grayson's Satchel
18805	Core Hound Tooth
18806	Core Forged Greaves
18807	Helm of Latent Power
18808	Gloves of the Hypnotic Flame
18809	Sash of Whispered Secrets
18810	Wild Growth Spaulders
18811	Fireproof Cloak
18812	Wristguards of True Flight
18813	Ring of Binding
18814	Choker of the Fire Lord
18815	Essence of the Pure Flame
18816	Perdition's Blade
18817	Crown of Destruction
18818	Mor'zul's Instructions
18819	Rohan's Exorcism Censer
18820	Talisman of Ephemeral Power
18821	Quick Strike Ring
18822	Obsidian Edged Blade
18823	Aged Core Leather Gloves
18824	Magma Tempered Boots
18825	Grand Marshal's Aegis
18826	High Warlord's Shield Wall
18827	Grand Marshal's Handaxe
18828	High Warlord's Cleaver
18829	Deep Earth Spaulders
18830	Grand Marshal's Sunderer
18831	High Warlord's Battle Axe
18832	Brutality Blade
18833	Grand Marshal's Bullseye
18834	Insignia of the Horde
18835	High Warlord's Recurve
18836	Grand Marshal's Repeater
18837	High Warlord's Crossbow
18838	Grand Marshal's Dirk
18839	Combat Healing Potion
18840	High Warlord's Razor
18841	Combat Mana Potion
18842	Staff of Dominance
18843	Grand Marshal's Right Hand Blade
18844	High Warlord's Right Claw
18845	Insignia of the Horde
18846	Insignia of the Horde
18847	Grand Marshal's Left Hand Blade
18848	High Warlord's Left Claw
18849	Insignia of the Horde
18850	Insignia of the Horde
18851	Insignia of the Horde
18852	Insignia of the Horde
18853	Insignia of the Horde
18854	Insignia of the Alliance
18855	Grand Marshal's Hand Cannon
18856	Insignia of the Alliance
18857	Insignia of the Alliance
18858	Insignia of the Alliance
18859	Insignia of the Alliance
18860	High Warlord's Street Sweeper
18861	Flamewaker Legplates
18862	Insignia of the Alliance
18863	Insignia of the Alliance
18864	Insignia of the Alliance
18865	Grand Marshal's Punisher
18866	High Warlord's Bludgeon
18867	Grand Marshal's Battle Hammer
18868	High Warlord's Pulverizer
18869	Grand Marshal's Glaive
18870	Helm of the Lifegiver
18871	High Warlord's Pig Sticker
18872	Manastorm Leggings
18873	Grand Marshal's Stave
18874	High Warlord's War Staff
18875	Salamander Scale Pants
18876	Grand Marshal's Claymore
18877	High Warlord's Greatsword
18878	Sorcerous Dagger
18879	Heavy Dark Iron Ring
18880	Darkreaver's Head
18902	Reins of the Swift Stormsaber
18904	Zorbin's Ultra-Shrinker
18922	Secret Plans: Fiery Flux
18942	Fiery Flux
18943	Dark Iron Pillow
18944	Incendosaur Scale
18945	Dark Iron Residue
18946	Head of Overseer Maltorius
18947	Rage Scar Yeti Hide
18948	Barbaric Bracers
18949	Pattern: Barbaric Bracers
18950	Chambermaid Pillaclencher's Pillow
18951	Evonice's Landin' Pilla
18952	Simone's Head
18953	Klinfran's Head
18954	Solenor's Head
18955	Artorius's Head
18956	Miniaturization Residue
18957	Brushwood Blade
18958	Water Elemental Core
18959	Smithing Tuyere
18960	Lookout's Spyglass
18961	Zukk'ash Carapace
18962	Stinglasher's Glands
18963	Turtle Egg (Albino)
18964	Turtle Egg (Loggerhead)
18965	Turtle Egg (Hawksbill)
18966	Turtle Egg (Leatherback)
18967	Turtle Egg (Olive)
18969	Pristine Yeti Hide
18970	Ring of Critical Testing 2
18972	Perfect Yeti Hide
18984	Dimensional Ripper - Everlook
18986	Ultrasafe Transporter: Gadgetzan
18987	Blackhand's Command
19002	Head of Nefarian
19003	Head of Nefarian
19004	Minor Healthstone
19005	Minor Healthstone
19006	Lesser Healthstone
19007	Lesser Healthstone
19008	Healthstone
19009	Healthstone
19010	Greater Healthstone
19011	Greater Healthstone
19012	Major Healthstone
19013	Major Healthstone
19016	Vessel of Rebirth
19017	Essence of the Firelord
19018	Dormant Wind Kissed Blade
19019	Thunderfury, Blessed Blade of the Windseeker
19020	Camp Mojache Zukk'ash Report
19022	Nat Pagle's Extreme Angler FC-5000
19023	Katoom's Best Lure
19024	Arena Grand Master
19025	Skylord Plume
19026	Snake Burst Firework
19027	Schematic: Snake Burst Firework
19028	Elegant Dress
19029	Horn of the Frostwolf Howler
19030	Stormpike Battle Charger
19031	Frostwolf Battle Tabard
19032	Stormpike Battle Tabard
19033	Slagtree's Lost Tools
19034	Lard's Lunch
19035	Lard's Special Picnic Basket
19036	Final Message to the Wildhammer
19037	Emerald Peak Spaulders
19038	Ring of Subtlety
19039	Zorbin's Water Resistant Hat
19040	Zorbin's Mega-Slicer
19041	Pratt's Handcrafted Tunic
19042	Jangdor's Handcrafted Tunic
19043	Heavy Timbermaw Belt
19044	Might of the Timbermaw
19045	Stormpike Battle Standard
19046	Frostwolf Battle Standard
19047	Wisdom of the Timbermaw
19048	Heavy Timbermaw Boots
19049	Timbermaw Brawlers
19050	Mantle of the Timbermaw
19051	Girdle of the Dawn
19052	Dawn Treaders
19054	Red Dragon Orb
19055	Green Dragon Orb
19056	Argent Boots
19057	Gloves of the Dawn
19058	Golden Mantle of the Dawn
19059	Argent Shoulders
19060	Warsong Gulch Enriched Ration
19061	Warsong Gulch Iron Ration
19062	Warsong Gulch Field Ration
19064	Shackle Key
19065	Emerald Circle
19066	Warsong Gulch Runecloth Bandage
19067	Warsong Gulch Mageweave Bandage
19068	Warsong Gulch Silk Bandage
19069	Huntsman Malkhor's Skull
19070	Huntsman Malkhor's Bones
19071	Vessel of Tainted Blood
19083	Frostwolf Legionnaire's Cloak
19084	Stormpike Soldier's Cloak
19085	Frostwolf Advisor's Cloak
19086	Stormpike Sage's Cloak
19087	Frostwolf Plate Belt
19088	Frostwolf Mail Belt
19089	Frostwolf Leather Belt
19090	Frostwolf Cloth Belt
19091	Stormpike Plate Girdle
19092	Stormpike Mail Girdle
19093	Stormpike Leather Girdle
19094	Stormpike Cloth Girdle
19095	Frostwolf Legionnaire's Pendant
19096	Frostwolf Advisor's Pendant
19097	Stormpike Soldier's Pendant
19098	Stormpike Sage's Pendant
19099	Glacial Blade
19100	Electrified Dagger
19101	Whiteout Staff
19102	Crackling Staff
19103	Frostbite
19104	Stormstrike Hammer
19105	Frost Runed Headdress
19106	Ice Barbed Spear
19107	Bloodseeker
19108	Wand of Biting Cold
19109	Deep Rooted Ring
19110	Cold Forged Blade
19111	Winteraxe Epaulets
19112	Frozen Steel Vambraces
19113	Yeti Hide Bracers
19114	Highland Bow
19115	Flask of Forest Mojo
19116	Greenleaf Handwraps
19117	Laquered Wooden Plate Legplates
19118	Nature's Breath
19119	Owlbeast Hide Gloves
19120	Rune of the Guard Captain
19121	Deep Woodlands Cloak
19123	Everwarm Handwraps
19124	Slagplate Leggings
19125	Seared Mail Girdle
19126	Slagplate Gauntlets
19127	Charred Leather Tunic
19128	Seared Mail Vest
19129	Everglowing Robe
19130	Cold Snap
19131	Snowblind Shoes
19132	Crystal Adorned Crown
19133	Fel Infused Leggings
19134	Flayed Doomguard Belt
19135	Blacklight Bracer
19136	Mana Igniting Cord
19137	Onslaught Girdle
19138	Band of Sulfuras
19139	Fireguard Shoulders
19140	Cauterizing Band
19141	Luffa
19142	Fire Runed Grimoire
19143	Flameguard Gauntlets
19144	Sabatons of the Flamewalker
19145	Robe of Volatile Power
19146	Wristguards of Stability
19147	Ring of Spell Power
19148	Dark Iron Helm
19149	Lava Belt
19150	Sentinel Basic Care Package
19151	Sentinel Standard Care Package
19152	Sentinel Advanced Care Package
19153	Outrider Advanced Care Package
19154	Outrider Basic Care Package
19155	Outrider Standard Care Package
19156	Flarecore Robe
19157	Chromatic Gauntlets
19159	Woven Ivy Necklace
19160	Contest Winner's Tabard
19162	Corehound Belt
19163	Molten Belt
19164	Dark Iron Gauntlets
19165	Flarecore Leggings
19166	Black Amnesty
19167	Blackfury
19168	Blackguard
19169	Nightfall
19170	Ebon Hand
19182	Darkmoon Faire Prize Ticket
19183	Hourglass Sand
19202	Plans: Heavy Timbermaw Belt
19203	Plans: Girdle of the Dawn
19204	Plans: Heavy Timbermaw Boots
19205	Plans: Gloves of the Dawn
19206	Plans: Dark Iron Helm
19207	Plans: Dark Iron Gauntlets
19208	Plans: Black Amnesty
19209	Plans: Blackfury
19210	Plans: Ebon Hand
19211	Plans: Blackguard
19212	Plans: Nightfall
19213	Silverwing Talisman of Merit
19215	Pattern: Wisdom of the Timbermaw
19216	Pattern: Argent Boots
19217	Pattern: Argent Shoulders
19218	Pattern: Mantle of the Timbermaw
19219	Pattern: Flarecore Robe
19220	Pattern: Flarecore Leggings
19221	Darkmoon Special Reserve
19222	Cheap Beer
19223	Darkmoon Dog
19224	Red Hot Wings
19225	Deep Fried Candybar
19227	Ace of Beasts
19228	Beasts Deck
19229	Sayge's Fortune #1
19230	Two of Beasts
19231	Three of Beasts
19232	Four of Beasts
19233	Five of Beasts
19234	Six of Beasts
19235	Seven of Beasts
19236	Eight of Beasts
19237	Sayge's Fortune #19
19238	Sayge's Fortune #3
19239	Sayge's Fortune #4
19240	Sayge's Fortune #5
19241	Sayge's Fortune #6
19242	Sayge's Fortune #7
19243	Sayge's Fortune #8
19244	Sayge's Fortune #9
19245	Sayge's Fortune #10
19246	Sayge's Fortune #11
19247	Sayge's Fortune #12
19248	Sayge's Fortune #13
19249	Sayge's Fortune #14
19250	Sayge's Fortune #15
19251	Sayge's Fortune #16
19252	Sayge's Fortune #18
19253	Sayge's Fortune #17
19254	Sayge's Fortune #21
19255	Sayge's Fortune #22
19256	Sayge's Fortune #2
19257	Warlords Deck
19258	Ace of Warlords
19259	Two of Warlords
19260	Three of Warlords
19261	Four of Warlords
19262	Five of Warlords
19263	Six of Warlords
19264	Seven of Warlords
19265	Eight of Warlords
19266	Sayge's Fortune #20
19267	Elementals Deck
19268	Ace of Elementals
19269	Two of Elementals
19270	Three of Elementals
19271	Four of Elementals
19272	Five of Elementals
19273	Six of Elementals
19274	Seven of Elementals
19275	Eight of Elementals
19276	Ace of Portals
19277	Portals Deck
19278	Two of Portals
19279	Three of Portals
19280	Four of Portals
19281	Five of Portals
19282	Six of Portals
19283	Seven of Portals
19284	Eight of Portals
19287	Darkmoon Card: Heroism
19288	Darkmoon Card: Blue Dragon
19289	Darkmoon Card: Maelstrom
19290	Darkmoon Card: Twisting Nether
19291	Darkmoon Storage Box
19292	Last Month's Mutton
19293	Last Year's Mutton
19295	Darkmoon Flower
19296	Greater Darkmoon Prize
19297	Lesser Darkmoon Prize
19298	Minor Darkmoon Prize
19299	Fizzy Faire Drink
19300	Bottled Winterspring Water
19301	Alterac Manna Biscuit
19302	Darkmoon Ring
19303	Darkmoon Necklace
19304	Spiced Beef Jerky
19305	Pickled Kodo Foot
19306	Crunchy Frog
19307	Alterac Heavy Runecloth Bandage
19308	Tome of Arcane Domination
19309	Tome of Shadow Force
19310	Tome of the Ice Lord
19311	Tome of Fiery Arcana
19312	Lei of the Lifegiver
19315	Therazane's Touch
19316	Ice Threaded Arrow
19317	Ice Threaded Bullet
19318	Bottled Alterac Spring Water
19319	Harpy Hide Quiver
19320	Gnoll Skin Bandolier
19321	The Immovable Object
19322	Warsong Mark of Honor
19323	The Unstoppable Force
19324	The Lobotomizer
19325	Don Julio's Band
19326	Pattern: Might of the Timbermaw
19327	Pattern: Timbermaw Brawlers
19328	Pattern: Dawn Treaders
19329	Pattern: Golden Mantle of the Dawn
19330	Pattern: Lava Belt
19331	Pattern: Chromatic Gauntlets
19332	Pattern: Corehound Belt
19333	Pattern: Molten Belt
19334	The Untamed Blade
19335	Spineshatter
19336	Arcane Infused Gem
19337	The Black Book
19338	Free Ticket Voucher
19339	Mind Quickening Gem
19340	Rune of Metamorphosis
19341	Lifegiving Gem
19342	Venomous Totem
19343	Scrolls of Blinding Light
19344	Natural Alignment Crystal
19345	Aegis of Preservation
19346	Dragonfang Blade
19347	Claw of Chromaggus
19348	Red Dragonscale Protector
19349	Elementium Reinforced Bulwark
19350	Heartstriker
19351	Maladath, Runed Blade of the Black Flight
19352	Chromatically Tempered Sword
19353	Drake Talon Cleaver
19354	Draconic Avenger
19355	Shadow Wing Focus Staff
19356	Staff of the Shadow Flame
19357	Herald of Woe
19358	Draconic Maul
19360	Lok'amir il Romathis
19361	Ashjre'thul, Crossbow of Smiting
19362	Doom's Edge
19363	Crul'shorukh, Edge of Chaos
19364	Ashkandi, Greatsword of the Brotherhood
19365	Claw of the Black Drake
19366	Master Dragonslayer's Orb
19367	Dragon's Touch
19368	Dragonbreath Hand Cannon
19369	Gloves of Rapid Evolution
19370	Mantle of the Blackwing Cabal
19371	Pendant of the Fallen Dragon
19372	Helm of Endless Rage
19373	Black Brood Pauldrons
19374	Bracers of Arcane Accuracy
19375	Mish'undare, Circlet of the Mind Flayer
19376	Archimtiros' Ring of Reckoning
19377	Prestor's Talisman of Connivery
19378	Cloak of the Brood Lord
19379	Neltharion's Tear
19380	Therazane's Link
19381	Boots of the Shadow Flame
19382	Pure Elementium Band
19383	Master Dragonslayer's Medallion
19384	Master Dragonslayer's Ring
19385	Empowered Leggings
19386	Elementium Threaded Cloak
19387	Chromatic Boots
19388	Angelista's Grasp
19389	Taut Dragonhide Shoulderpads
19390	Taut Dragonhide Gloves
19391	Shimmering Geta
19392	Girdle of the Fallen Crusader
19393	Primalist's Linked Waistguard
19394	Drake Talon Pauldrons
19395	Rejuvenating Gem
19396	Taut Dragonhide Belt
19397	Ring of Blackrock
19398	Cloak of Firemaw
19399	Black Ash Robe
19400	Firemaw's Clutch
19401	Primalist's Linked Legguards
19402	Legguards of the Fallen Crusader
19403	Band of Forced Concentration
19405	Malfurion's Blessed Bulwark
19406	Drake Fang Talisman
19407	Ebony Flame Gloves
19422	Darkmoon Faire Fortune
19423	Sayge's Fortune #23
19424	Sayge's Fortune #24
19425	Mysterious Lockbox
19426	Orb of the Darkmoon
19430	Shroud of Pure Thought
19431	Styleen's Impeding Scarab
19432	Circle of Applied Force
19433	Emberweave Leggings
19434	Band of Dark Dominion
19435	Essence Gatherer
19436	Cloak of Draconic Might
19437	Boots of Pure Thought
19438	Ringo's Blizzard Boots
19439	Interlaced Shadow Jerkin
19440	Powerful Anti-Venom
19441	Huge Venom Sac
19442	Formula: Powerful Anti-Venom
19443	Sayge's Fortune #25
19444	Formula: Enchant Weapon - Strength
19445	Formula: Enchant Weapon - Agility
19446	Formula: Enchant Bracer - Mana Regeneration
19447	Formula: Enchant Bracer - Healing
19448	Formula: Enchant Weapon - Mighty Spirit
19449	Formula: Enchant Weapon - Mighty Intellect
19450	A Jubling's Tiny Home
19451	Sayge's Fortune #26
19452	Sayge's Fortune #27
19453	Sayge's Fortune #28
19454	Sayge's Fortune #29
19462	Unhatched Jubling Egg
19482	LeCraft Rabbit Pelt
19483	Peeling the Onion
19484	The Frostwolf Artichoke
19491	Amulet of the Darkmoon
19505	Warsong Battle Tabard
19506	Silverwing Battle Tabard
19507	Inquisitor's Shawl
19508	Branded Leather Bracers
19509	Dusty Mail Boots
19510	Legionnaire's Band
19511	Legionnaire's Band
19512	Legionnaire's Band
19513	Legionnaire's Band
19514	Protector's Band
19515	Protector's Band
19516	Protector's Band
19517	Protector's Band
19518	Advisor's Ring
19519	Advisor's Ring
19520	Advisor's Ring
19521	Advisor's Ring
19522	Lorekeeper's Ring
19523	Lorekeeper's Ring
19524	Lorekeeper's Ring
19525	Lorekeeper's Ring
19526	Battle Healer's Cloak
19527	Battle Healer's Cloak
19528	Battle Healer's Cloak
19529	Battle Healer's Cloak
19530	Caretaker's Cape
19531	Caretaker's Cape
19532	Caretaker's Cape
19533	Caretaker's Cape
19534	Scout's Medallion
19535	Scout's Medallion
19536	Scout's Medallion
19537	Scout's Medallion
19538	Sentinel's Medallion
19539	Sentinel's Medallion
19540	Sentinel's Medallion
19541	Sentinel's Medallion
19542	Scout's Blade
19543	Scout's Blade
19544	Scout's Blade
19545	Scout's Blade
19546	Sentinel's Blade
19547	Sentinel's Blade
19548	Sentinel's Blade
19549	Sentinel's Blade
19550	Legionnaire's Sword
19551	Legionnaire's Sword
19552	Legionnaire's Sword
19553	Legionnaire's Sword
19554	Protector's Sword
19555	Protector's Sword
19556	Protector's Sword
19557	Protector's Sword
19558	Outrider's Bow
19559	Outrider's Bow
19560	Outrider's Bow
19561	Outrider's Bow
19562	Outrunner's Bow
19563	Outrunner's Bow
19564	Outrunner's Bow
19565	Outrunner's Bow
19566	Advisor's Gnarled Staff
19567	Advisor's Gnarled Staff
19568	Advisor's Gnarled Staff
19569	Advisor's Gnarled Staff
19570	Lorekeeper's Staff
19571	Lorekeeper's Staff
19572	Lorekeeper's Staff
19573	Lorekeeper's Staff
19574	Strength of Mugamba
19575	Strength of Mugamba
19576	Strength of Mugamba
19577	Rage of Mugamba
19578	Berserker Bracers
19579	Heathen's Brand
19580	Berserker Bracers
19581	Berserker Bracers
19582	Windtalker's Wristguards
19583	Windtalker's Wristguards
19584	Windtalker's Wristguards
19585	Heathen's Brand
19586	Heathen's Brand
19587	Forest Stalker's Bracers
19588	Hero's Brand
19589	Forest Stalker's Bracers
19590	Forest Stalker's Bracers
19591	The Eye of Zuldazar
19592	The Eye of Zuldazar
19593	The Eye of Zuldazar
19594	The All-Seeing Eye of Zuldazar
19595	Dryad's Wrist Bindings
19596	Dryad's Wrist Bindings
19597	Dryad's Wrist Bindings
19598	Pebble of Kajaro
19599	Pebble of Kajaro
19600	Pebble of Kajaro
19601	Jewel of Kajaro
19602	Kezan's Taint
19603	Kezan's Taint
19604	Kezan's Taint
19605	Kezan's Unstoppable Taint
19606	Vision of Voodress
19607	Vision of Voodress
19608	Vision of Voodress
19609	Unmarred Vision of Voodress
19610	Enchanted South Seas Kelp
19611	Enchanted South Seas Kelp
19612	Enchanted South Seas Kelp
19613	Pristine Enchanted South Seas Kelp
19614	Zandalarian Shadow Talisman
19615	Zandalarian Shadow Talisman
19616	Zandalarian Shadow Talisman
19617	Zandalarian Shadow Mastery Talisman
19618	Maelstrom's Tendril
19619	Maelstrom's Tendril
19620	Maelstrom's Tendril
19621	Maelstrom's Wrath
19642	iCoke Prize Voucher
19682	Bloodvine Vest
19683	Bloodvine Leggings
19684	Bloodvine Boots
19685	Primal Batskin Jerkin
19686	Primal Batskin Gloves
19687	Primal Batskin Bracers
19688	Blood Tiger Breastplate
19689	Blood Tiger Shoulders
19690	Bloodsoul Breastplate
19691	Bloodsoul Shoulders
19692	Bloodsoul Gauntlets
19693	Darksoul Breastplate
19694	Darksoul Leggings
19695	Darksoul Shoulders
19696	Harvest Bread
19697	Bounty of the Harvest
19698	Zulian Coin
19699	Razzashi Coin
19700	Hakkari Coin
19701	Gurubashi Coin
19702	Vilebranch Coin
19703	Witherbark Coin
19704	Sandfury Coin
19705	Skullsplitter Coin
19706	Bloodscalp Coin
19707	Red Hakkari Bijou
19708	Blue Hakkari Bijou
19709	Yellow Hakkari Bijou
19710	Orange Hakkari Bijou
19711	Green Hakkari Bijou
19712	Purple Hakkari Bijou
19713	Bronze Hakkari Bijou
19714	Silver Hakkari Bijou
19715	Gold Hakkari Bijou
19716	Primal Hakkari Bindings
19717	Primal Hakkari Armsplint
19718	Primal Hakkari Stanchion
19719	Primal Hakkari Girdle
19720	Primal Hakkari Sash
19721	Primal Hakkari Shawl
19722	Primal Hakkari Tabard
19723	Primal Hakkari Kossack
19724	Primal Hakkari Aegis
19725	Arathi Resource Crate
19726	Bloodvine
19727	Blood Scythe
19760	Overlord's Embrace
19764	Pattern: Bloodvine Vest
19765	Pattern: Bloodvine Leggings
19766	Pattern: Bloodvine Boots
19767	Primal Bat Leather
19768	Primal Tiger Leather
19769	Pattern: Primal Batskin Jerkin
19770	Pattern: Primal Batskin Gloves
19771	Pattern: Primal Batskin Bracers
19772	Pattern: Blood Tiger Breastplate
19773	Pattern: Blood Tiger Shoulders
19774	Souldarite
19775	Sealed Azure Bag
19776	Plans: Bloodsoul Breastplate
19777	Plans: Bloodsoul Shoulders
19778	Plans: Bloodsoul Gauntlets
19779	Plans: Darksoul Breastplate
19780	Plans: Darksoul Leggings
19781	Plans: Darksoul Shoulders
19782	Presence of Might
19783	Syncretist's Sigil
19784	Death's Embrace
19785	Falcon's Call
19786	Vodouisant's Vigilant Embrace
19787	Presence of Sight
19788	Hoodoo Hex
19789	Prophetic Aura
19790	Animist's Caress
19802	Heart of Hakkar
19803	Brownell's Blue Striped Racer
19804	Pale Ghoulfish
19805	Keefer's Angelfish
19806	Dezian Queenfish
19807	Speckled Tastyfish
19808	Rockhide Strongfish
19812	Rune of the Dawn
19813	Punctured Voodoo Doll
19814	Punctured Voodoo Doll
19815	Punctured Voodoo Doll
19816	Punctured Voodoo Doll
19817	Punctured Voodoo Doll
19818	Punctured Voodoo Doll
19819	Punctured Voodoo Doll
19820	Punctured Voodoo Doll
19821	Punctured Voodoo Doll
19822	Zandalar Vindicator's Breastplate
19823	Zandalar Vindicator's Belt
19824	Zandalar Vindicator's Armguards
19825	Zandalar Freethinker's Breastplate
19826	Zandalar Freethinker's Belt
19827	Zandalar Freethinker's Armguards
19828	Zandalar Augur's Hauberk
19829	Zandalar Augur's Belt
19830	Zandalar Augur's Bracers
19831	Zandalar Predator's Mantle
19832	Zandalar Predator's Belt
19833	Zandalar Predator's Bracers
19834	Zandalar Madcap's Tunic
19835	Zandalar Madcap's Mantle
19836	Zandalar Madcap's Bracers
19838	Zandalar Haruspex's Tunic
19839	Zandalar Haruspex's Belt
19840	Zandalar Haruspex's Bracers
19841	Zandalar Confessor's Mantle
19842	Zandalar Confessor's Bindings
19843	Zandalar Confessor's Wraps
19845	Zandalar Illusionist's Mantle
19846	Zandalar Illusionist's Wraps
19848	Zandalar Demoniac's Wraps
19849	Zandalar Demoniac's Mantle
19850	Uther's Tribute
19851	Grom's Tribute
19852	Ancient Hakkari Manslayer
19853	Gurubashi Dwarf Destroyer
19854	Zin'rokh, Destroyer of Worlds
19855	Bloodsoaked Legplates
19856	The Eye of Hakkar
19857	Cloak of Consumption
19858	Zandalar Honor Token
19859	Fang of the Faceless
19861	Touch of Chaos
19862	Aegis of the Blood God
19863	Primalist's Seal
19864	Bloodcaller
19865	Warblade of the Hakkari
19866	Warblade of the Hakkari
19867	Bloodlord's Defender
19869	Blooddrenched Grips
19870	Hakkari Loa Cloak
19871	Talisman of Protection
19872	Swift Razzashi Raptor
19873	Overlord's Crimson Band
19874	Halberd of Smiting
19875	Bloodstained Coif
19876	Soul Corrupter's Necklace
19877	Animist's Leggings
19878	Bloodsoaked Pauldrons
19880	Gurubashi Head Collection
19881	Channeler's Head
19882	The Hexxer's Head
19883	Sacred Cord
19884	Jin'do's Judgement
19885	Jin'do's Evil Eye
19886	The Hexxer's Cover
19887	Bloodstained Legplates
19888	Overlord's Embrace
19889	Blooddrenched Leggings
19890	Jin'do's Hexxer
19891	Jin'do's Bag of Whammies
19892	Animist's Boots
19893	Zanzil's Seal
19894	Bloodsoaked Gauntlets
19895	Bloodtinged Kilt
19896	Thekal's Grasp
19897	Betrayer's Boots
19898	Seal of Jin
19899	Ritualistic Legguards
19900	Zulian Stone Axe
19901	Zulian Slicer
19902	Swift Zulian Tiger
19903	Fang of Venoxis
19904	Runed Bloodstained Hauberk
19905	Zanzil's Band
19906	Blooddrenched Footpads
19907	Zulian Tigerhide Cloak
19908	Sceptre of Smiting
19909	Will of Arlokk
19910	Arlokk's Grasp
19911	Whipweed Heart
19912	Overlord's Onyx Band
19913	Bloodsoaked Greaves
19914	Panther Hide Sack
19915	Zulian Defender
19918	Jeklik's Crusher
19919	Bloodstained Greaves
19920	Primalist's Band
19921	Zulian Hacker
19922	Arlokk's Hoodoo Stick
19923	Jeklik's Opaline Talisman
19925	Band of Jin
19927	Mar'li's Touch
19928	Animist's Spaulders
19929	Bloodtinged Gloves
19930	Mar'li's Eye
19931	Gurubashi Mojo Madness
19933	Glowing Scorpid Blood
19934	Large Scorpid Claw
19935	Empty Venom Sac
19936	Dried Scorpid Carapace
19937	Small Scorpid Claw
19938	Heavy Scorpid Leg
19939	Gri'lek's Blood
19940	Renataki's Tooth
19941	Wushoolay's Mane
19942	Hazza'rah's Dream Thread
19943	Massive Mojo
19944	Nat Pagle's Fish Terminator
19945	Foror's Eyepatch
19946	Tigule's Harpoon
19947	Nat Pagle's Broken Reel
19948	Zandalarian Hero Badge
19949	Zandalarian Hero Medallion
19950	Zandalarian Hero Charm
19951	Gri'lek's Charm of Might
19952	Gri'lek's Charm of Valor
19953	Renataki's Charm of Beasts
19954	Renataki's Charm of Trickery
19955	Wushoolay's Charm of Nature
19956	Wushoolay's Charm of Spirits
19957	Hazza'rah's Charm of Destruction
19958	Hazza'rah's Charm of Healing
19959	Hazza'rah's Charm of Magic
19960	Crystalized Honey
19961	Gri'lek's Grinder
19962	Gri'lek's Carver
19963	Pitchfork of Madness
19964	Renataki's Soul Conduit
19965	Wushoolay's Poker
19967	Thoughtblighter
19968	Fiery Retributer
19969	Nat Pagle's Extreme Anglin' Boots
19970	Arcanite Fishing Pole
19972	Lucky Fishing Hat
19973	Nat's Measuring Tape
19974	Mudskunk Lure
19975	Zulian Mudskunk
19978	Fishing Tournament!
19979	Hook of the Master Angler
19982	Duskbat Drape
19984	Ebon Mask
19986	Pirate's Eye Patch
19989	Tome of Devouring Shadows
19990	Blessed Prayer Beads
19991	Devilsaur Eye
19992	Devilsaur Tooth
19993	Hoodoo Hunting Bow
19994	Harvest Fruit
19995	Harvest Boar
19996	Harvest Fish
19997	Harvest Nectar
19998	Bloodvine Lens
19999	Bloodvine Goggles
20000	Schematic: Bloodvine Goggles
20001	Schematic: Bloodvine Lens
20002	Greater Dreamless Sleep Potion
20003	Devilsaur Claws
20004	Major Troll's Blood Potion
20005	Devilsaur Claws
20006	Circle of Hope
20007	Mageblood Potion
20008	Living Action Potion
20009	For the Light!
20010	The Horde's Hellscream
20011	Recipe: Mageblood Potion
20012	Recipe: Greater Dreamless Sleep
20013	Recipe: Living Action Potion
20014	Recipe: Major Troll's Blood Potion
20015	Elder Raptor Feathers
20016	Trophy Raptor Skull
20017	Perfect Courser Antler
20018	Angerclaw Grizzly Hide
20019	Tooth of Morphaz
20020	Bundle of Goods
20021	Gold Pirate Earring
20022	Azure Key
20023	Encoded Fragment
20024	Putrid Bile Duct
20025	Blood of Morphaz
20026	Rotting Flesh
20027	Healthy Courser Gland
20028	Glittering Dust
20029	Enchanted Coral
20030	Pet Rock
20031	Essence Mango
20032	Flowing Ritual Robes
20033	Zandalar Demoniac's Robe
20034	Zandalar Illusionist's Robe
20035	Glacial Spike
20036	Fire Ruby
20037	Arcane Crystal Pendant
20038	Mandokir's Sting
20039	Dark Iron Boots
20040	Plans: Dark Iron Boots
20041	Highlander's Plate Girdle
20042	Highlander's Lamellar Girdle
20043	Highlander's Chain Girdle
20044	Highlander's Mail Girdle
20045	Highlander's Leather Girdle
20046	Highlander's Lizardhide Girdle
20047	Highlander's Cloth Girdle
20048	Highlander's Plate Greaves
20049	Highlander's Lamellar Greaves
20050	Highlander's Chain Greaves
20051	Highlander's Mail Greaves
20052	Highlander's Leather Boots
20053	Highlander's Lizardhide Boots
20054	Highlander's Cloth Boots
20055	Highlander's Chain Pauldrons
20056	Highlander's Mail Pauldrons
20057	Highlander's Plate Spaulders
20058	Highlander's Lamellar Spaulders
20059	Highlander's Leather Shoulders
20060	Highlander's Lizardhide Shoulders
20061	Highlander's Epaulets
20062	Arathi Basin Enriched Ration
20063	Arathi Basin Field Ration
20064	Arathi Basin Iron Ration
20065	Arathi Basin Mageweave Bandage
20066	Arathi Basin Runecloth Bandage
20067	Arathi Basin Silk Bandage
20068	Deathguard's Cloak
20069	Ironbark Staff
20070	Sageclaw
20071	Talisman of Arathor
20072	Defiler's Talisman
20073	Cloak of the Honor Guard
20074	Heavy Crocolisk Stew
20075	Recipe: Heavy Crocolisk Stew
20076	Zandalar Signet of Mojo
20077	Zandalar Signet of Might
20078	Zandalar Signet of Serenity
20079	Spirit of Zanza
20080	Sheen of Zanza
20081	Swiftness of Zanza
20082	Woestave
20083	Hunting Spear
20084	Hunting Net
20085	Arcane Shard
20086	Dusksteel Throwing Knife
20087	Wavethrasher Scales
20088	Highlander's Chain Girdle
20089	Highlander's Chain Girdle
20090	Highlander's Chain Girdle
20091	Highlander's Chain Greaves
20092	Highlander's Chain Greaves
20093	Highlander's Chain Greaves
20094	Highlander's Cloth Boots
20095	Highlander's Cloth Boots
20096	Highlander's Cloth Boots
20097	Highlander's Cloth Girdle
20098	Highlander's Cloth Girdle
20099	Highlander's Cloth Girdle
20100	Highlander's Lizardhide Boots
20101	Highlander's Lizardhide Boots
20102	Highlander's Lizardhide Boots
20103	Highlander's Lizardhide Girdle
20104	Highlander's Lizardhide Girdle
20105	Highlander's Lizardhide Girdle
20106	Highlander's Lamellar Girdle
20107	Highlander's Lamellar Girdle
20108	Highlander's Lamellar Girdle
20109	Highlander's Lamellar Greaves
20110	Highlander's Lamellar Greaves
20111	Highlander's Lamellar Greaves
20112	Highlander's Leather Boots
20113	Highlander's Leather Boots
20114	Highlander's Leather Boots
20115	Highlander's Leather Girdle
20116	Highlander's Leather Girdle
20117	Highlander's Leather Girdle
20118	Highlander's Mail Girdle
20119	Highlander's Mail Girdle
20120	Highlander's Mail Girdle
20121	Highlander's Mail Greaves
20122	Highlander's Mail Greaves
20123	Highlander's Mail Greaves
20124	Highlander's Plate Girdle
20125	Highlander's Plate Girdle
20126	Highlander's Plate Girdle
20127	Highlander's Plate Greaves
20128	Highlander's Plate Greaves
20129	Highlander's Plate Greaves
20130	Diamond Flask
20131	Battle Tabard of the Defilers
20132	Arathor Battle Tabard
20134	Skyfury Helm
20150	Defiler's Chain Girdle
20151	Defiler's Chain Girdle
20152	Defiler's Chain Girdle
20153	Defiler's Chain Girdle
20154	Defiler's Chain Greaves
20155	Defiler's Chain Greaves
20156	Defiler's Chain Greaves
20157	Defiler's Chain Greaves
20158	Defiler's Chain Pauldrons
20159	Defiler's Cloth Boots
20160	Defiler's Cloth Boots
20161	Defiler's Cloth Boots
20162	Defiler's Cloth Boots
20163	Defiler's Cloth Girdle
20164	Defiler's Cloth Girdle
20165	Defiler's Cloth Girdle
20166	Defiler's Cloth Girdle
20167	Defiler's Lizardhide Boots
20168	Defiler's Lizardhide Boots
20169	Defiler's Lizardhide Boots
20170	Defiler's Lizardhide Boots
20171	Defiler's Lizardhide Girdle
20172	Defiler's Lizardhide Girdle
20173	Defiler's Lizardhide Girdle
20174	Defiler's Lizardhide Girdle
20175	Defiler's Lizardhide Shoulders
20176	Defiler's Epaulets
20177	Defiler's Lamellar Girdle
20178	Defiler's Lamellar Girdle
20179	Defiler's Lamellar Girdle
20180	Defiler's Lamellar Girdle
20181	Defiler's Lamellar Greaves
20182	Defiler's Lamellar Greaves
20183	Defiler's Lamellar Greaves
20184	Defiler's Lamellar Spaulders
20185	Defiler's Lamellar Greaves
20186	Defiler's Leather Boots
20187	Defiler's Leather Boots
20188	Defiler's Leather Boots
20189	Defiler's Leather Boots
20190	Defiler's Leather Girdle
20191	Defiler's Leather Girdle
20192	Defiler's Leather Girdle
20193	Defiler's Leather Girdle
20194	Defiler's Leather Shoulders
20195	Defiler's Mail Girdle
20196	Defiler's Mail Girdle
20197	Defiler's Mail Girdle
20198	Defiler's Mail Girdle
20199	Defiler's Mail Greaves
20200	Defiler's Mail Greaves
20201	Defiler's Mail Greaves
20202	Defiler's Mail Greaves
20203	Defiler's Mail Pauldrons
20204	Defiler's Plate Girdle
20205	Defiler's Plate Girdle
20206	Defiler's Plate Girdle
20207	Defiler's Plate Girdle
20208	Defiler's Plate Greaves
20209	Defiler's Plate Greaves
20210	Defiler's Plate Greaves
20211	Defiler's Plate Greaves
20212	Defiler's Plate Spaulders
20213	Belt of Shrunken Heads
20214	Mindfang
20215	Belt of Shriveled Heads
20216	Belt of Preserved Heads
20217	Belt of Tiny Heads
20218	Faded Hakkari Cloak
20219	Tattered Hakkari Cape
20220	Ironbark Staff
20222	Defiler's Enriched Ration
20223	Defiler's Field Ration
20224	Defiler's Iron Ration
20225	Highlander's Enriched Ration
20226	Highlander's Field Ration
20227	Highlander's Iron Ration
20228	Defiler's Advanced Care Package
20229	Defiler's Basic Care Package
20230	Defiler's Standard Care Package
20231	Arathor Advanced Care Package
20232	Defiler's Mageweave Bandage
20233	Arathor Basic Care Package
20234	Defiler's Runecloth Bandage
20235	Defiler's Silk Bandage
20236	Arathor Standard Care Package
20237	Highlander's Mageweave Bandage
20243	Highlander's Runecloth Bandage
20244	Highlander's Silk Bandage
20253	Pattern: Warbear Harness
20254	Pattern: Warbear Woolies
20255	Whisperwalk Boots
20256	Warsong Gulch Ribbon of Sacrifice
20257	Seafury Gauntlets
20258	Zulian Ceremonial Staff
20259	Shadow Panther Hide Gloves
20260	Seafury Leggings
20261	Shadow Panther Hide Belt
20262	Seafury Boots
20263	Gurubashi Helm
20264	Peacekeeper Gauntlets
20265	Peacekeeper Boots
20266	Peacekeeper Leggings
20295	Blue Dragonscale Leggings
20296	Green Dragonscale Gauntlets
20310	Flayed Demon Skin
20337	Gnome Head on a Stick
20367	Hunting Gear
20368	Bland Bow of Steadiness
20369	Azurite Fists
20371	Blue Murloc Egg
20373	Stonelash Scorpid Stinger
20374	Stonelash Pincer Stinger
20375	Stonelash Flayer Stinger
20376	Sand Skitterer Fang
20377	Rock Stalker Fang
20378	Twilight Tablet Fragment
20379	Noggle's Satchel
20380	Dreamscale Breastplate
20381	Dreamscale
20382	Pattern: Dreamscale Breastplate
20383	Head of the Broodlord Lashlayer
20384	Silithid Carapace Fragment
20385	Deathclasp's Pincer
20387	Forsaken Stink Bomb Cluster
20388	Lollipop
20389	Candy Corn
20390	Candy Bar
20391	Flimsy Male Gnome Mask
20392	Flimsy Female Gnome Mask
20393	Treat Bag
20394	Twilight Lexicon - Chapter 1
20395	Twilight Lexicon - Chapter 2
20396	Twilight Lexicon - Chapter 3
20397	Hallowed Wand - Pirate
20398	Hallowed Wand - Ninja
20399	Hallowed Wand - Leper Gnome
20400	Pumpkin Bag
20401	Restored Twilight Tablet
20402	Agent of Nozdormu
20403	Proxy of Nozdormu
20404	Encrypted Twilight Text
20405	Decoded Tablet Transcription
20406	Twilight Cultist Mantle
20407	Twilight Cultist Robe
20408	Twilight Cultist Cowl
20409	Hallowed Wand - Ghost
20410	Hallowed Wand - Bat
20411	Hallowed Wand - Skeleton
20413	Hallowed Wand - Random
20414	Hallowed Wand - Wisp
20415	The War of the Shifting Sands
20416	Crest of Beckoning: Fire
20418	Crest of Beckoning: Thunder
20419	Crest of Beckoning: Stone
20420	Crest of Beckoning: Water
20422	Twilight Cultist Medallion of Station
20423	Sandy Scorpid Claw
20424	Sandworm Meat
20425	Advisor's Gnarled Staff
20426	Advisor's Ring
20427	Battle Healer's Cloak
20428	Caretaker's Cape
20429	Legionnaire's Band
20430	Legionnaire's Sword
20431	Lorekeeper's Ring
20432	Signet of Beckoning: Fire
20433	Signet of Beckoning: Thunder
20434	Lorekeeper's Staff
20435	Signet of Beckoning: Stone
20436	Signet of Beckoning: Water
20437	Outrider's Bow
20438	Outrunner's Bow
20439	Protector's Band
20440	Protector's Sword
20441	Scout's Blade
20442	Scout's Medallion
20443	Sentinel's Blade
20444	Sentinel's Medallion
20447	Scepter of Beckoning: Fire
20448	Scepter of Beckoning: Thunder
20449	Scepter of Beckoning: Stone
20450	Scepter of Beckoning: Water
20451	Twilight Cultist Ring of Lordship
20452	Smoked Desert Dumplings
20453	Geologist's Transcription Kit
20454	Hive'Zora Rubbing
20455	Hive'Ashi Rubbing
20456	Hive'Regal Rubbing
20457	Hive'Ashi Silithid Brain
20458	Hive'Zora Silithid Brain
20459	Hive'Regal Silithid Brain
20460	Brann Bronzebeard's Lost Letter
20461	Brann Bronzebeard's Lost Letter
20463	Glyphed Crystal Prism
20464	Glyphs of Calling
20465	Crystal Unlocking Mechanism
20466	Vyral's Signet Ring
20467	Torn Recipe Page
20469	Decoded True Believer Clippings
20470	Solanian's Scrying Orb
20471	Scroll of Scourge Magic
20472	Solanian's Journal
20473	The Arcanist's Compendium, Volume 4
20474	Sunstrider Book Satchel
20475	Adamantite Arrow Maker
20476	Sandstalker Bracers
20477	Sandstalker Gauntlets
20478	Sandstalker Breastplate
20479	Spitfire Breastplate
20480	Spitfire Gauntlets
20481	Spitfire Bracers
20482	Arcane Sliver
20483	Tainted Arcane Sliver
20485	Duke's Seal
20487	Lok'delar, Stave of the Ancient Keepers DEP
20488	Rhok'delar, Longbow of the Ancient Keepers DEP
20489	Crown of the Council
20490	Ironforge Mint
20491	Undercity Mint
20492	Stormwind Nougat
20493	Orgrimmar Nougat
20494	Gnomeregan Gumdrop
20495	Darkspear Gumdrop
20496	Darnassus Marzipan
20497	Thunder Bluff Marzipan
20498	Silithid Chitin
20499	Broken Silithid Chitin
20500	Light Silithid Carapace
20501	Heavy Silithid Carapace
20502	Ironbark Shield
20503	Enamored Water Spirit
20504	Lightforged Blade
20505	Chivalrous Signet
20506	Pattern: Spitfire Bracers
20507	Pattern: Spitfire Gauntlets
20508	Pattern: Spitfire Breastplate
20509	Pattern: Sandstalker Bracers
20510	Pattern: Sandstalker Gauntlets
20511	Pattern: Sandstalker Breastplate
20512	Sanctified Orb
20513	Abyssal Crest
20514	Abyssal Signet
20515	Abyssal Scepter
20516	Bobbing Apple
20517	Razorsteel Shoulders
20518	Scroll: Create Crest of Beckoning
20519	Southsea Pirate Hat
20520	Dark Rune
20521	Fury Visor
20522	Feral Staff
20524	Shadowhide Leggings
20525	Earthen Sigil
20526	Scroll: Create Crest of Beckoning
20527	Scroll: Create Crest of Beckoning
20528	Scroll: Create Crest of Beckoning
20530	Robes of Servitude
20531	Scroll: Create Signet of Beckoning
20532	Scroll: Create Signet of Beckoning
20533	Scroll: Create Signet of Beckoning
20534	Abyss Shard
20535	Scroll: Create Signet of Beckoning
20536	Soul Harvester
20537	Runed Stygian Boots
20538	Runed Stygian Leggings
20539	Runed Stygian Belt
20540	Scroll: Create Scepter of Beckoning
20541	Decoded Twilight Text
20542	Scroll: Create Scepter of Beckoning
20543	Scroll: Create Scepter of Beckoning
20544	Scroll: Create Scepter of Beckoning
20545	Decoded Twilight Text
20546	Pattern: Runed Stygian Leggings
20547	Pattern: Runed Stygian Boots
20548	Pattern: Runed Stygian Belt
20549	Darkrune Gauntlets
20550	Darkrune Breastplate
20551	Darkrune Helm
20552	Decoded Twilight Text
20553	Plans: Darkrune Gauntlets
20554	Plans: Darkrune Breastplate
20555	Plans: Darkrune Helm
20556	Wildstaff
20557	Hallow's End Pumpkin Treat
20558	Warsong Gulch Mark of Honor
20559	Arathi Basin Mark of Honor
20560	Alterac Valley Mark of Honor
20561	Flimsy Male Dwarf Mask
20562	Flimsy Female Dwarf Mask
20563	Flimsy Female Nightelf Mask
20564	Flimsy Male Nightelf Mask
20565	Flimsy Female Human Mask
20566	Flimsy Male Human Mask
20567	Flimsy Female Troll Mask
20568	Flimsy Male Troll Mask
20569	Flimsy Female Orc Mask
20570	Flimsy Male Orc Mask
20571	Flimsy Female Tauren Mask
20572	Flimsy Male Tauren Mask
20573	Flimsy Male Undead Mask
20574	Flimsy Female Undead Mask
20575	Black Whelp Tunic
20576	Pattern: Black Whelp Tunic
20577	Nightmare Blade
20578	Emerald Dragonfang
20579	Green Dragonskin Cloak
20580	Hammer of Bestial Fury
20581	Staff of Rampant Growth
20582	Trance Stone
20583	Sturdy Female Dwarf Mask
20584	Sturdy Female Gnome Mask
20585	Sturdy Female Human Mask
20586	Sturdy Female Night Elf Mask
20587	Sturdy Female Orc Mask
20588	Sturdy Female Tauren Mask
20589	Sturdy Female Troll Mask
20590	Sturdy Female Undead Mask
20591	Sturdy Male Dwarf Mask
20592	Sturdy Male Gnome Mask
20593	Sturdy Male Human Mask
20594	Sturdy Male Night Elf Mask
20595	Sturdy Male Orc Mask
20596	Sturdy Male Tauren Mask
20597	Sturdy Male Troll Mask
20598	Sturdy Male Undead Mask
20599	Polished Ironwood Crossbow
20600	Malfurion's Signet Ring
20601	Sack of Spoils
20602	Chest of Spoils
20603	Bag of Spoils
20604	Stink Bomb Cleaner
20605	Rotten Eggs
20606	Amber Voodoo Feather
20607	Blue Voodoo Feather
20608	Green Voodoo Feather
20609	Voodoo Feathers
20610	Bloodshot Spider Eye
20611	Thick Black Claw
20612	Inert Scourgestone
20613	Rotting Wood
20614	Bloodvenom Essence
20615	Dragonspur Wraps
20616	Dragonbone Wristguards
20617	Ancient Corroded Leggings
20618	Gloves of Delusional Power
20619	Acid Inscribed Greaves
20620	Holy Mightstone
20621	Boots of the Endless Moor
20622	Dragonheart Necklace
20623	Circlet of Restless Dreams
20624	Ring of the Unliving
20625	Belt of the Dark Bog
20626	Black Bark Wristbands
20627	Dark Heart Pants
20628	Deviate Growth Cap
20629	Malignant Footguards
20630	Gauntlets of the Shining Light
20631	Mendicant's Slippers
20632	Mindtear Band
20633	Unnatural Leather Spaulders
20634	Boots of Fright
20635	Jade Inlaid Vestments
20636	Hibernation Crystal
20637	Acid Inscribed Pauldrons
20638	Leggings of the Demented Mind
20639	Strangely Glyphed Legplates
20640	Southsea Head Bucket
20641	Southsea Mojo Boots
20642	Antiquated Nobleman's Tunic
20643	Undercity Reservist's Cap
20644	Nightmare Engulfed Object
20645	Nature's Whisper
20646	Sandstrider's Mark
20647	Black Crystal Dagger
20648	Cold Forged Hammer
20649	Sunprism Pendant
20650	Desert Wind Gauntlets
20651	Orange Murloc Egg
20652	Abyssal Cloth Slippers
20653	Abyssal Plate Gauntlets
20654	Amethyst War Staff
20655	Abyssal Cloth Handwraps
20656	Abyssal Mail Sabatons
20657	Crystal Tipped Stiletto
20658	Abyssal Leather Boots
20659	Abyssal Mail Handguards
20660	Stonecutting Glaive
20661	Abyssal Leather Gloves
20662	Abyssal Plate Greaves
20663	Deep Strike Bow
20664	Abyssal Cloth Sash
20665	Abyssal Leather Leggings
20666	Hardened Steel Warhammer
20667	Abyssal Leather Belt
20668	Abyssal Mail Legguards
20669	Darkstone Claymore
20670	Abyssal Mail Clutch
20671	Abyssal Plate Legplates
20672	Sparkling Crystal Wand
20673	Abyssal Plate Girdle
20674	Abyssal Cloth Pants
20675	Soulrender
20676	Decoded Twilight Text
20677	Decoded Twilight Text
20678	Decoded Twilight Text
20679	Decoded Twilight Text
20680	Abyssal Mail Pauldrons
20681	Abyssal Leather Bracers
20682	Elemental Focus Band
20683	Abyssal Plate Epaulets
20684	Abyssal Mail Armguards
20685	Wavefront Necklace
20686	Abyssal Cloth Amice
20687	Abyssal Plate Vambraces
20688	Earthen Guard
20689	Abyssal Leather Shoulders
20690	Abyssal Cloth Wristbands
20691	Windshear Cape
20692	Multicolored Band
20693	Weighted Cloak
20694	Glowing Black Orb
20695	Abyssal War Beads
20696	Crystal Spiked Maul
20697	Crystalline Threaded Cape
20698	Elemental Attuned Blade
20699	Cenarion Reservist's Legplates
20700	Cenarion Reservist's Legplates
20701	Cenarion Reservist's Legguards
20702	Cenarion Reservist's Legguards
20703	Cenarion Reservist's Leggings
20704	Cenarion Reservist's Leggings
20705	Cenarion Reservist's Pants
20706	Cenarion Reservist's Pants
20707	Cenarion Reservist's Pants
20708	Tightly Sealed Trunk
20709	Rumsey Rum Light
20710	Crystal Encrusted Greaves
20711	Crystal Lined Greaves
20712	Wastewalker's Gauntlets
20713	Desertstalkers's Gauntlets
20714	Sandstorm Boots
20715	Dunestalker's Boots
20716	Sandworm Skin Gloves
20717	Desert Bloom Gloves
20720	Dark Whisper Blade
20721	Band of the Cultist
20722	Crystal Slugthrower
20723	Brann's Trusty Pick
20724	Corrupted Blackwood Staff
20725	Nexus Crystal
20726	Formula: Enchant Gloves - Threat
20727	Formula: Enchant Gloves - Shadow Power
20728	Formula: Enchant Gloves - Frost Power
20729	Formula: Enchant Gloves - Fire Power
20730	Formula: Enchant Gloves - Healing Power
20731	Formula: Enchant Gloves - Superior Agility
20732	Formula: Enchant Cloak - Greater Fire Resistance
20733	Formula: Enchant Cloak - Greater Nature Resistance
20734	Formula: Enchant Cloak - Stealth
20735	Formula: Enchant Cloak - Subtlety
20736	Formula: Enchant Cloak - Dodge
20737	Singed Corestone
20741	Deadwood Ritual Totem
20742	Winterfall Ritual Totem
20743	Unstable Mana Crystal
20744	Minor Wizard Oil
20745	Minor Mana Oil
20746	Lesser Wizard Oil
20747	Lesser Mana Oil
20748	Brilliant Mana Oil
20749	Brilliant Wizard Oil
20750	Wizard Oil
20752	Formula: Minor Mana Oil
20753	Formula: Lesser Wizard Oil
20754	Formula: Lesser Mana Oil
20755	Formula: Wizard Oil
20756	Formula: Brilliant Wizard Oil
20757	Formula: Brilliant Mana Oil
20758	Formula: Minor Wizard Oil
20759	Otembe's Hammer
20760	Chieftain Zul'Marosh's Head
20761	Recipe: Transmute Elemental Fire
20763	Broken Weapon
20764	Prospector Anvilward's Head
20765	Incriminating Documents
20766	Slimy Bag
20767	Scum Covered Bag
20768	Oozing Bag
20769	Disgusting Oozeling
20770	Bubbling Green Ichor
20771	Tainted Soil Sample
20772	Springpaw Pelt
20797	Lynx Collar
20798	Intact Arcane Converter
20799	Felendren's Head
20800	Cenarion Logistics Badge
20801	Cenarion Tactical Badge
20802	Cenarion Combat Badge
20803	Twilight Battle Orders
20804	Erona's Package
20805	Followup Logistics Assignment
20806	Logistics Task Briefing X
20807	Logistics Task Briefing I
20808	Combat Assignment
20809	Tactical Assignment
20810	Signed Field Duty Papers
20812	Tattered Pelt
20813	Lynx Tooth
20814	Broken Master's Throwing Dagger
20815	Jeweler's Kit
20816	Delicate Copper Wire
20817	Bronze Setting
20818	Elegant Silver Ring
20819	Cut Malachite
20820	Simple Pearl Ring
20821	Inlaid Malachite Ring
20822	Cut Tigerseye
20823	Gloom Band
20824	Simple Grinder
20825	Cut Shadowgem
20826	Heavy Silver Ring
20827	Ring of Silver Might
20828	Ring of Twilight Shadows
20829	Cut Moonstone
20830	Amulet of the Moon
20831	Heavy Golden Necklace of Battle
20832	Moonsoul Crown
20833	Wicked Moonstone Ring
20834	Ornate Spyglass XT
20835	Sunstrider Sword
20836	Sunstrider Dagger
20837	Sunstrider Axe
20838	Sunstrider Bow
20839	Sunstrider Staff
20840	Sunstrider Mace
20841	Sunstrider Shield
20842	Frayed Tender Vine
20843	Smashed Petal
20844	Deadly Poison V
20845	Torn Wyrm Scale
20846	Faintly Glowing Eye
20847	Wraith Fragment
20848	Sparkling Dust
20849	Arcane Forged Shortsword
20850	Arcane Forged Axe
20851	Arcane Forged Mace
20852	Arcane Forged Dirk
20853	Mana Gathering Staff
20854	Design: Amulet of the Moon
20855	Design: Wicked Moonstone Ring
20856	Design: Heavy Golden Necklace of Battle
20857	Honey Bread
20858	Stone Scarab
20859	Gold Scarab
20860	Silver Scarab
20861	Bronze Scarab
20862	Crystal Scarab
20863	Clay Scarab
20864	Bone Scarab
20865	Ivory Scarab
20866	Azure Idol
20867	Onyx Idol
20868	Lambent Idol
20869	Amber Idol
20870	Jasper Idol
20871	Obsidian Idol
20872	Vermillion Idol
20873	Alabaster Idol
20874	Idol of the Sun
20875	Idol of Night
20876	Idol of Death
20877	Idol of the Sage
20878	Idol of Rebirth
20879	Idol of Life
20881	Idol of Strife
20882	Idol of War
20883	Qiraji Glyphed Jewel
20884	Qiraji Magisterial Ring
20885	Qiraji Martial Drape
20886	Qiraji Spiked Hilt
20887	Qiraji Engraved Jewel
20888	Qiraji Ceremonial Ring
20889	Qiraji Regal Drape
20890	Qiraji Ornate Hilt
20891	Neophyte's Robe
20892	Acolyte's Robe
20893	Apprentice's Robe
20894	Apprentice's Pants
20895	Apprentice's Boots
20896	Lookout's Pants
20897	Lookout's Tunic
20898	Lookout's Shoes
20899	Warder's Pants
20900	Warder's Boots
20901	Warder's Shirt
20902	Recruit's Pants
20903	Recruit's Boots
20904	Recruit's Tunic
20906	Braided Copper Ring
20907	Solid Bronze Ring
20908	Festival of Nian Firework
20909	Barbaric Iron Collar
20910	Stiff Shortbow
20911	Light Guard
20912	Large Shield
20913	Medium Guard
20914	Unadorned Chain Belt
20915	Unadorned Chain Boots
20916	Unadorned Chain Bracers
20917	Unadorned Chain Gloves
20918	Unadorned Chain Leggings
20919	Unadorned Chain Vest
20920	Sun Cured Belt
20921	Sun Cured Boots
20922	Sun Cured Bracers
20923	Sun Cured Gloves
20924	Sun Cured Pants
20925	Sun Cured Vest
20926	Vek'nilash's Circlet
20927	Ouro's Intact Hide
20928	Qiraji Bindings of Command
20930	Vek'lor's Diadem
20931	Skin of the Great Sandworm
20932	Qiraji Bindings of Dominance
20934	Wraith Essence
20935	Tainted Wraith Essence
20936	Qiraji Blessed Jewel
20937	Qiraji Encased Jewel
20938	Sunstrider Isle Gift Voucher
20939	Logistics Task Briefing II
20940	Logistics Task Briefing III
20941	Combat Task Briefing XII
20942	Combat Task Briefing III
20943	Tactical Task Briefing X
20944	Tactical Task Briefing IX
20945	Tactical Task Briefing II
20946	Tactical Task Briefing III
20947	Tactical Task Briefing IV
20948	Tactical Task Briefing V
20949	Magical Ledger
20950	Pendant of the Agate Shield
20951	Narain's Scrying Goggles
20952	Cut Agate
20953	Cut Jade
20954	Heavy Iron Knuckles
20955	Golden Dragon Ring
20956	Silver Rose Pendant
20957	Cut Citrine
20958	Blazing Citrine Ring
20959	The Jade Eye
20960	Engraved Truesilver Ring
20961	Citrine Ring of Rapid Healing
20962	Cut Aquamarine
20963	Mithril Filigree
20964	Aquamarine Signet
20965	Cut Ruby
20966	Jade Pendant of Blasting
20967	Citrine Pendant of Golden Healing
20969	Ruby Crown of Restoration
20970	Design: Pendant of the Agate Shield
20971	Design: Heavy Iron Knuckles
20972	Design: Silver Rose Pendant
20973	Design: Blazing Citrine Ring
20974	Design: Jade Pendant of Blasting
20975	Design: The Jade Eye
20976	Design: Citrine Pendant of Golden Healing
20977	Recruit's Shortsword
20978	New Bent Staff
20979	Warder's Axe
20980	Warder's Shortbow
20981	Neophyte's Mace
20982	Sharp Dagger
20983	Acolyte's Dagger
20984	Recruit's Shield
20985	Light Cloth Shoes
20986	Light Cloth Pants
20987	Light Cloth Gloves
20988	Light Cloth Bracers
20989	Light Cloth Belt
20990	Light Cloth Armor
20991	Daylight Cloak
20992	Sunrise Bracers
20993	Lynxskin Gloves
20994	Green Chain Vest
20995	Well Watcher Gloves
20996	Sunspire Cord
20997	Green Chain Boots
20998	Wyrm Sash
20999	Green Chain Gauntlets
21000	Vigorous Bracers
21001	Striding Pants
21002	Unkempt Belt
21003	Unkempt Bracers
21004	Unkempt Cloak
21005	Unkempt Gloves
21006	Unkempt Pants
21007	Unkempt Robe
21008	Unkempt Shoes
21009	Scraggy Leather Belt
21010	Scraggy Leather Boots
21011	Scraggy Leather Bracers
21012	Scraggy Leather Gloves
21013	Scraggy Leather Pants
21014	Scraggy Leather Vest
21015	Shoddy Chain Belt
21016	Shoddy Chain Vest
21017	Shoddy Chain Pants
21018	Shoddy Chain Gloves
21019	Shoddy Chain Bracers
21020	Shoddy Chain Boots
21021	Battered Shield
21022	Weather Beaten Buckler
21023	Dirge's Kickin' Chimaerok Chops
21024	Chimaerok Tenderloin
21025	Recipe: Dirge's Kickin' Chimaerok Chops
21026	Oracle Sphere
21027	Lakmaeran's Carcass
21028	500 Pound Chicken
21029	Ransom Letter
21030	Darnassus Kimchi Pie
21031	Cabbage Kimchi
21032	Meridith's Love Letter
21033	Radish Kimchi
21037	Crude Map
21038	Hardpacked Snowball
21039	Narain's Turban
21040	Narain's Robe
21041	Bag of Gold
21042	Narain's Special Kit
21043	Mysterious Envelope
21071	Raw Sagefish
21072	Smoked Sagefish
21099	Recipe: Smoked Sagefish
21100	Coin of Ancestry
21103	Draconic for Dummies
21104	Draconic for Dummies
21105	Draconic for Dummies
21106	Draconic for Dummies
21107	Draconic for Dummies
21108	Draconic for Dummies
21109	Draconic for Dummies
21110	Draconic for Dummies
21111	Draconic For Dummies: Volume II
21112	Magical Book Binding
21113	Watertight Trunk
21114	Rumsey Rum Dark
21115	Defiler's Talisman
21116	Defiler's Talisman
21117	Talisman of Arathor
21118	Talisman of Arathor
21119	Talisman of Arathor
21120	Defiler's Talisman
21126	Death's Sting
21128	Staff of the Qiraji Prophets
21130	Diary of Weavil
21131	Followup Combat Assignment
21132	Logistics Assignment
21133	Followup Tactical Assignment
21134	Dark Edge of Insanity
21135	Broken Assassin's Throwing Axe
21136	Arcanite Buoy
21137	Blue Scepter Shard
21138	Red Scepter Shard
21139	Green Scepter Shard
21140	Auction Stationery
21141	Destroyed Red Scepter Shard
21142	From the Desk of Lord Victor Nefarius
21143	Unsigned Field Duty Papers
21144	Demon Summoning Torch
21145	Essence of Xandivious
21146	Fragment of the Nightmare's Corruption
21147	Fragment of the Nightmare's Corruption
21148	Fragment of the Nightmare's Corruption
21149	Fragment of the Nightmare's Corruption
21150	Iron Bound Trunk
21151	Rumsey Rum Black Label
21152	The Nightmare's Corruption
21153	Raw Greater Sagefish
21154	Festival Dress
21155	Timbermaw Offering of Peace
21156	Scarab Bag
21157	Festive Green Dress
21158	Hive'Zora Scout Report
21159	Hive'Zora Scout Orders
21160	Hive'Regal Scout Report
21161	Hive'Ashi Scout Report
21162	Bloated Oily Blackmouth
21163	Bloated Firefin
21164	Bloated Rockscale Cod
21165	Tactical Task Briefing VI
21166	Tactical Task Briefing VII
21167	Tactical Task Briefing VIII
21168	Baby Shark
21171	Filled Festive Mug
21173	Empty Festive Mug
21174	Empty Festive Mug
21175	The Scepter of the Shifting Sands
21176	Black Qiraji Resonating Crystal
21177	Symbol of Kings
21178	Gloves of Earthen Power
21179	Band of Earthen Wrath
21180	Earthstrike
21181	Grace of Earth
21182	Band of Earthen Might
21183	Earthpower Vest
21184	Deeprock Bracers
21185	Earthcalm Orb
21186	Rockfury Bracers
21187	Earthweave Cloak
21188	Fist of Cenarius
21189	Might of Cenarius
21190	Wrath of Cenarius
21191	Carefully Wrapped Present
21193	D'Sak's Sack
21194	D'Sak's Big Sack
21195	D'Sak's Sacktastic
21196	Signet Ring of the Bronze Dragonflight
21197	Signet Ring of the Bronze Dragonflight
21198	Signet Ring of the Bronze Dragonflight
21199	Signet Ring of the Bronze Dragonflight
21200	Signet Ring of the Bronze Dragonflight
21201	Signet Ring of the Bronze Dragonflight
21202	Signet Ring of the Bronze Dragonflight
21203	Signet Ring of the Bronze Dragonflight
21204	Signet Ring of the Bronze Dragonflight
21205	Signet Ring of the Bronze Dragonflight
21206	Signet Ring of the Bronze Dragonflight
21207	Signet Ring of the Bronze Dragonflight
21208	Signet Ring of the Bronze Dragonflight
21209	Signet Ring of the Bronze Dragonflight
21210	Signet Ring of the Bronze Dragonflight
21211	Pouch of Reindeer Dust
21212	Fresh Holly
21213	Preserved Holly
21214	Tome of Frostbolt XI
21215	Graccu's Mince Meat Fruitcake
21216	Smokywood Pastures Extra-Special Gift
21217	Sagefish Delight
21218	Blue Qiraji Resonating Crystal
21219	Recipe: Sagefish Delight
21220	Head of Ossirian the Unscarred
21221	Eye of C'Thun
21222	Armored Chitin
21223	Black Stone
21224	Ancient Armor Fragment
21225	Heavy Silithid Husk
21226	Runic Stone
21227	Ancient Hero's Skull
21228	Mithril Bound Trunk
21229	Qiraji Lord's Insignia
21230	Ancient Qiraji Artifact
21232	Imperial Qiraji Armaments
21235	Winter Veil Roast
21236	Winter Veil Loaf
21237	Imperial Qiraji Regalia
21240	Winter Veil Candy
21241	Winter Veil Eggnog
21242	Blessed Qiraji War Axe
21243	Bloated Mightfish
21244	Blessed Qiraji Pugio
21245	Tactical Task Briefing I
21246	Combat Task Briefing I
21247	Combat Task Briefing II
21248	Combat Task Briefing IV
21249	Combat Task Briefing V
21250	Combat Task Briefing VI
21251	Combat Task Briefing VII
21252	Combat Task Briefing VIII
21253	Combat Task Briefing IX
21254	Winter Veil Cookie
21255	Combat Task Briefing X
21256	Combat Task Briefing XI
21257	Logistics Task Briefing IV
21258	Logistics Task Briefing IV
21259	Logistics Task Briefing V
21260	Logistics Task Briefing VI
21261	Logistics Task Briefing VI
21262	Logistics Task Briefing VIII
21263	Logistics Task Briefing VII
21264	Logistics Task Briefing VII
21265	Logistics Task Briefing IX
21266	Logistics Assignment
21267	Toasting Goblet
21268	Blessed Qiraji War Hammer
21269	Blessed Qiraji Bulwark
21270	Gently Shaken Gift
21271	Gently Shaken Gift
21272	Blessed Qiraji Musket
21273	Blessed Qiraji Acolyte Staff
21275	Blessed Qiraji Augur Staff
21277	Tranquil Mechanical Yeti
21278	Stormshroud Gloves
21279	Tome of Fireball XII
21280	Tome of Arcane Missiles VIII
21281	Grimoire of Shadow Bolt X
21282	Grimoire of Immolate VIII
21283	Grimoire of Corruption VII
21284	Codex of Greater Heal V
21285	Codex of Renew X
21287	Codex of Prayer of Healing V
21288	Libram: Blessing of Wisdom VI
21289	Libram: Blessing of Might VII
21290	Libram: Holy Light IX
21291	Tablet of Healing Wave X
21292	Tablet of Strength of Earth Totem V
21293	Tablet of Grace of Air Totem III
21294	Book of Healing Touch XI
21295	Book of Starfire VII
21296	Book of Rejuvenation XI
21297	Manual of Heroic Strike IX
21298	Manual of Battle Shout VII
21299	Manual of Revenge VI
21300	Handbook of Backstab IX
21301	Green Helper Box
21302	Handbook of Deadly Poison V
21303	Handbook of Feint V
21304	Guide: Multi-Shot V
21305	Red Helper Box
21306	Guide: Serpent Sting IX
21307	Guide: Aspect of the Hawk VII
21308	Jingling Bell
21309	Snowman Kit
21310	Gaily Wrapped Present
21311	Earth Warder's Vest
21312	Belt of the Den Watcher
21313	D'Sak's Small bag
21314	Metzen's Letters and Notes
21315	Smokywood Satchel
21316	Leggings of the Ursa
21317	Helm of the Pathfinder
21318	Earth Warder's Gloves
21319	Gloves of the Pathfinder
21320	Vest of the Den Watcher
21321	Red Qiraji Resonating Crystal
21322	Ursa's Embrace
21323	Green Qiraji Resonating Crystal
21324	Yellow Qiraji Resonating Crystal
21325	Mechanical Greench
21326	Defender of the Timbermaw
21327	Ticking Present
21328	Wand of Holiday Cheer
21329	Conqueror's Crown
21330	Conqueror's Spaulders
21331	Conqueror's Breastplate
21332	Conqueror's Legguards
21333	Conqueror's Greaves
21334	Doomcaller's Robes
21335	Doomcaller's Mantle
21336	Doomcaller's Trousers
21337	Doomcaller's Circlet
21338	Doomcaller's Footwraps
21340	Soul Pouch
21341	Felcloth Bag
21342	Core Felcloth Bag
21343	Enigma Robes
21344	Enigma Boots
21345	Enigma Shoulderpads
21346	Enigma Leggings
21347	Enigma Circlet
21348	Tiara of the Oracle
21349	Footwraps of the Oracle
21350	Mantle of the Oracle
21351	Vestments of the Oracle
21352	Trousers of the Oracle
21353	Genesis Helm
21354	Genesis Shoulderpads
21355	Genesis Boots
21356	Genesis Trousers
21357	Genesis Vest
21358	Pattern: Soul Pouch
21359	Deathdealer's Boots
21360	Deathdealer's Helm
21361	Deathdealer's Spaulders
21362	Deathdealer's Leggings
21363	Festive Gift
21364	Deathdealer's Vest
21365	Striker's Footguards
21366	Striker's Diadem
21367	Striker's Pauldrons
21368	Striker's Leggings
21369	Pattern: Felcloth Bag
21370	Striker's Hauberk
21371	Pattern: Core Felcloth Bag
21372	Stormcaller's Diadem
21373	Stormcaller's Footguards
21374	Stormcaller's Hauberk
21375	Stormcaller's Leggings
21376	Stormcaller's Pauldrons
21377	Deadwood Headdress Feather
21378	Logistics Task Briefing I
21379	Logistics Task Briefing II
21380	Logistics Task Briefing III
21381	Logistics Task Briefing IX
21382	Logistics Task Briefing V
21383	Winterfall Spirit Beads
21384	Logistics Task Briefing VIII
21385	Logistics Task Briefing X
21386	Followup Logistics Assignment
21387	Avenger's Crown
21388	Avenger's Greaves
21389	Avenger's Breastplate
21390	Avenger's Legguards
21391	Avenger's Pauldrons
21392	Sickle of Unyielding Strength
21393	Signet of Unyielding Strength
21394	Drape of Unyielding Strength
21395	Blade of Eternal Justice
21396	Ring of Eternal Justice
21397	Cape of Eternal Justice
21398	Hammer of the Gathering Storm
21399	Ring of the Gathering Storm
21400	Cloak of the Gathering Storm
21401	Scythe of the Unseen Path
21402	Signet of the Unseen Path
21403	Cloak of the Unseen Path
21404	Dagger of Veiled Shadows
21405	Band of Veiled Shadows
21406	Cloak of Veiled Shadows
21407	Mace of Unending Life
21408	Band of Unending Life
21409	Cloak of Unending Life
21410	Gavel of Infinite Wisdom
21411	Ring of Infinite Wisdom
21412	Shroud of Infinite Wisdom
21413	Blade of Vaulted Secrets
21414	Band of Vaulted Secrets
21415	Drape of Vaulted Secrets
21416	Kris of Unspoken Names
21417	Ring of Unspoken Names
21418	Shroud of Unspoken Names
21436	Alliance Commendation Signet
21438	Horde Commendation Signet
21452	Staff of the Ruins
21453	Mantle of the Horusath
21454	Runic Stone Shoulders
21455	Southwind Helm
21456	Sandstorm Cloak
21457	Bracers of Brutality
21458	Gauntlets of New Life
21459	Crossbow of Imminent Doom
21460	Helm of Domination
21461	Leggings of the Black Blizzard
21462	Gloves of Dark Wisdom
21463	Ossirian's Binding
21464	Shackles of the Unscarred
21466	Stinger of Ayamiss
21467	Thick Silithid Chestguard
21468	Mantle of Maz'Nadir
21469	Gauntlets of Southwind
21470	Cloak of the Savior
21471	Talon of Furious Concentration
21472	Dustwind Turban
21473	Eye of Moam
21474	Chitinous Shoulderguards
21475	Legplates of the Destroyer
21476	Obsidian Scaled Leggings
21477	Ring of Fury
21478	Bow of Taut Sinew
21479	Gauntlets of the Immovable
21480	Scaled Silithid Gauntlets
21481	Boots of the Desert Protector
21482	Boots of the Fiery Sands
21483	Ring of the Desert Winds
21484	Helm of Regrowth
21485	Buru's Skull Fragment
21486	Gloves of the Swarm
21487	Slimy Scaled Gauntlets
21488	Fetish of Chitinous Spikes
21489	Quicksand Waders
21490	Slime Kickers
21491	Scaled Bracers of the Gorger
21492	Manslayer of the Qiraji
21493	Boots of the Vanguard
21494	Southwind's Grasp
21495	Legplates of the Qiraji Command
21496	Bracers of Qiraji Command
21497	Boots of the Qiraji General
21498	Qiraji Sacrificial Dagger
21499	Vestments of the Shifting Sands
21500	Belt of the Inquisition
21501	Toughened Silithid Hide Gloves
21502	Sand Reaver Wristguards
21503	Belt of the Sand Reaver
21504	Charm of the Shifting Sands
21505	Choker of the Shifting Sands
21506	Pendant of the Shifting Sands
21507	Amulet of the Shifting Sands
21508	Mark of Cenarius
21509	Ahn'Qiraj War Effort Supplies
21510	Ahn'Qiraj War Effort Supplies
21511	Ahn'Qiraj War Effort Supplies
21512	Ahn'Qiraj War Effort Supplies
21513	Ahn'Qiraj War Effort Supplies
21514	Logistics Task Briefing XI
21515	Mark of Remulos
21517	Gnomish Turban of Psychic Might
21519	Mistletoe
21520	Ravencrest's Legacy
21521	Runesword of the Red
21522	Shadowsong's Sorrow
21523	Fang of Korialstrasz
21524	Red Winter Hat
21525	Green Winter Hat
21526	Band of Icy Depths
21527	Darkwater Robes
21528	Colossal Bag of Loot
21529	Amulet of Shadow Shielding
21530	Onyx Embedded Leggings
21531	Drake Tooth Necklace
21532	Drudge Boots
21533	Colossus of Zora's Husk
21534	Colossus of Ashi's Husk
21535	Colossus of Regal's Husk
21536	Elune Stone
21537	Festival Dumplings
21538	Festive Pink Dress
21539	Festive Purple Dress
21540	Elune's Lantern
21541	Festive Black Pant Suit
21542	Festival Suit
21543	Festive Teal Pant Suit
21544	Festive Blue Pant Suit
21545	Smokywood Supplies
21546	Elixir of Greater Firepower
21547	Recipe: Elixir of Greater Firepower
21548	Pattern: Stormshroud Gloves
21552	Striped Yellowtail
21557	Small Red Rocket
21558	Small Blue Rocket
21559	Small Green Rocket
21560	Small Purple Rocket
21561	Small White Rocket
21562	Small Yellow Rocket
21563	Don Rodrigo's Band
21565	Rune of Perfection
21566	Rune of Perfection
21567	Rune of Duty
21568	Rune of Duty
21569	Firework Launcher
21570	Cluster Launcher
21571	Blue Rocket Cluster
21574	Green Rocket Cluster
21575	Purple Rocket Cluster
21576	Red Rocket Cluster
21577	White Rocket Cluster
21578	Yellow Rocket Cluster
21579	Vanquished Tentacle of C'Thun
21581	Gauntlets of Annihilation
21583	Cloak of Clarity
21584	Bracers of Eternal Reckoning
21585	Dark Storm Gauntlets
21586	Belt of Never-ending Agony
21587	Wristguards of Castigation
21588	Wristguards of Elemental Fury
21589	Large Blue Rocket
21590	Large Green Rocket
21591	Large Purple Rocket
21592	Large Red Rocket
21593	Large White Rocket
21594	Bracers of the Fallen Son
21595	Large Yellow Rocket
21596	Ring of the Godslayer
21597	Royal Scepter of Vek'lor
21598	Royal Qiraji Belt
21599	Vek'lor's Gloves of Devastation
21600	Boots of Epiphany
21601	Ring of Emperor Vek'lor
21602	Qiraji Execution Bracers
21603	Wand of Qiraji Nobility
21604	Bracelets of Royal Redemption
21605	Gloves of the Hidden Temple
21606	Belt of the Fallen Emperor
21607	Grasp of the Fallen Emperor
21608	Amulet of Vek'nilash
21609	Regenerating Belt of Vek'nilash
21610	Wormscale Blocker
21611	Burrower Bracers
21612	Wormscale Stompers
21613	Wormhide Boots
21614	Wormhide Protector
21615	Don Rigoberto's Lost Hat
21616	Huhuran's Stinger
21617	Wasphide Gauntlets
21618	Hive Defiler Wristguards
21619	Gloves of the Messiah
21620	Ring of the Martyr
21621	Cloak of the Golden Hive
21622	Sharpened Silithid Femur
21623	Gauntlets of the Righteous Champion
21624	Gauntlets of Kalimdor
21625	Scarab Brooch
21626	Slime-coated Leggings
21627	Cloak of Untold Secrets
21635	Barb of the Sand Reaver
21639	Pauldrons of the Unrelenting
21640	Lunar Festival Fireworks Pack
21645	Hive Tunneler's Boots
21647	Fetish of the Sand Reaver
21648	Recomposed Boots
21650	Ancient Qiraji Ripper
21651	Scaled Sand Reaver Leggings
21652	Silithid Carapace Chestguard
21663	Robes of the Guardian Saint
21664	Barbed Choker
21665	Mantle of Wicked Revenge
21666	Sartura's Might
21667	Legplates of Blazing Light
21668	Scaled Leggings of Qiraji Fury
21669	Creeping Vine Helm
21670	Badge of the Swarmguard
21671	Robes of the Battleguard
21672	Gloves of Enforcement
21673	Silithid Claw
21674	Gauntlets of Steadfast Determination
21675	Thick Qirajihide Belt
21676	Leggings of the Festering Swarm
21677	Ring of the Qiraji Fury
21678	Necklace of Purity
21679	Kalimdor's Revenge
21680	Vest of Swift Execution
21681	Ring of the Devoured
21682	Bile-Covered Gauntlets
21683	Mantle of the Desert Crusade
21684	Mantle of the Desert's Fury
21685	Petrified Scarab
21686	Mantle of Phrenic Power
21687	Ukko's Ring of Darkness
21688	Boots of the Fallen Hero
21689	Gloves of Ebru
21690	Angelista's Charm
21691	Ooze-ridden Gauntlets
21692	Triad Girdle
21693	Guise of the Devourer
21694	Ternary Mantle
21695	Angelista's Touch
21696	Robes of the Triumvirate
21697	Cape of the Trinity
21698	Leggings of Immersion
21699	Barrage Shoulders
21700	Pendant of the Qiraji Guardian
21701	Cloak of Concentrated Hatred
21702	Amulet of Foul Warding
21703	Hammer of Ji'zhi
21704	Boots of the Redeemed Prophecy
21705	Boots of the Fallen Prophet
21706	Boots of the Unwavering Will
21707	Ring of Swarming Thought
21708	Beetle Scaled Wristguards
21709	Ring of the Fallen God
21710	Cloak of the Fallen God
21711	Lunar Festival Invitation
21712	Amulet of the Fallen God
21713	Elune's Candle
21714	Large Blue Rocket Cluster
21715	Sand Polished Hammer
21716	Large Green Rocket Cluster
21717	Large Purple Rocket Cluster
21718	Large Red Rocket Cluster
21719	Large White Rocket Cluster
21720	Large Yellow Rocket Cluster
21721	Moonglow
21722	Pattern: Festival Dress
21723	Pattern: Festive Red Pant Suit
21724	Schematic: Small Blue Rocket
21725	Schematic: Small Green Rocket
21726	Schematic: Small Red Rocket
21727	Schematic: Large Blue Rocket
21728	Schematic: Large Green Rocket
21729	Schematic: Large Red Rocket
21730	Schematic: Blue Rocket Cluster
21731	Schematic: Green Rocket Cluster
21732	Schematic: Red Rocket Cluster
21733	Schematic: Large Blue Rocket Cluster
21734	Schematic: Large Green Rocket Cluster
21735	Schematic: Large Red Rocket Cluster
21736	Nether Drake Reins
21737	Schematic: Cluster Launcher
21738	Schematic: Firework Launcher
21739	Lunar Festival Invitation DEBUG
21740	Small Rocket Recipes
21741	Cluster Rocket Recipes
21742	Large Rocket Recipes
21743	Large Cluster Rocket Recipes
21744	Lucky Rocket Cluster
21745	Elder's Moonstone
21746	Lucky Red Envelope
21747	Festival Firecracker
21748	Figurine - Jade Owl
21749	Combat Task Briefing I
21750	Combat Task Briefing II
21751	Tactical Task Briefing III
21752	Thorium Setting
21753	Gem Studded Band
21754	The Aquamarine Ward
21755	Aquamarine Pendant of the Warrior
21756	Figurine - Golden Hare
21757	Grimscale Murloc Head
21758	Figurine - Black Pearl Panther
21760	Figurine - Truesilver Crab
21761	Scarab Coffer Key
21762	Greater Scarab Coffer Key
21763	Figurine - Truesilver Boar
21764	Ruby Pendant of Fire
21765	Truesilver Healing Ring
21766	Opal Necklace of Impact
21767	Simple Opal Ring
21768	Sapphire Signet
21769	Figurine - Ruby Serpent
21770	Ring of Mmmrrrggglll
21771	Captain Kelisendra's Cargo
21772	Cut Sapphire
21773	Cut Opal
21774	Emerald Crown of Destruction
21775	Onslaught Ring
21776	Captain Kelisendra's Lost Rutters
21777	Figurine - Emerald Owl
21778	Ring of Bitter Shadows
21779	Band of Natural Fire
21780	Blood Crown
21781	Thaelis's Head
21783	Magister Duskwither's Journal
21784	Figurine - Black Diamond Crab
21785	Cut Emerald
21786	Cut Azerothian Diamond
21789	Figurine - Dark Iron Scorpid
21790	Sapphire Pendant of Winter Night
21791	Living Emerald Pendant
21792	Necklace of the Diamond Tower
21793	Arcanite Sword Pendant
21800	Silithid Husked Launcher
21801	Antenna of Invigoration
21802	The Lost Kris of Zedd
21803	Helm of the Holy Avenger
21804	Coif of Elemental Fury
21805	Polished Obsidian Pauldrons
21806	Gavel of Qiraji Authority
21807	Unmarked Letter
21808	Arcane Core
21809	Fury of the Forgotten Swarm
21810	Treads of the Wandering Nomad
21812	Box of Chocolates
21813	Bag of Candies
21814	Breastplate of Annihilation
21815	Love Token
21816	Heart Candy
21817	Heart Candy
21818	Heart Candy
21819	Heart Candy
21820	Heart Candy
21821	Heart Candy
21822	Heart Candy
21823	Heart Candy
21829	Perfume Bottle
21830	Empty Wrapper
21831	Wrappered Gift
21833	Cologne Bottle
21835	Anesthetic Poison
21836	Ritssyn's Ring of Chaos
21837	Anubisath Warhammer
21838	Garb of Royal Ascension
21839	Scepter of the False Prophet
21840	Bolt of Netherweave
21841	Netherweave Bag
21842	Bolt of Imbued Netherweave
21843	Imbued Netherweave Bag
21844	Bolt of Soulcloth
21845	Primal Mooncloth
21846	Spellfire Belt
21847	Spellfire Gloves
21848	Spellfire Robe
21849	Netherweave Bracers
21850	Netherweave Belt
21851	Netherweave Gloves
21852	Netherweave Pants
21853	Netherweave Boots
21854	Netherweave Robe
21855	Netherweave Tunic
21856	Neretzek, The Blood Drinker
21858	Spellfire Bag
21859	Imbued Netherweave Pants
21860	Imbued Netherweave Boots
21861	Imbued Netherweave Robe
21862	Imbued Netherweave Tunic
21863	Soulcloth Gloves
21864	Soulcloth Shoulders
21865	Soulcloth Vest
21866	Arcanoweave Bracers
21867	Arcanoweave Boots
21868	Arcanoweave Robe
21869	Frozen Shadoweave Shoulders
21870	Frozen Shadoweave Boots
21871	Frozen Shadoweave Robe
21872	Ebon Shadowbag
21873	Primal Mooncloth Belt
21874	Primal Mooncloth Shoulders
21875	Primal Mooncloth Robe
21876	Primal Mooncloth Bag
21877	Netherweave Cloth
21878	zzDEPRECATED Spellthread
21879	Charged Draenethyst Crystal
21880	Perfect Draenethyst Crystal
21881	Netherweb Spider Silk
21882	Soul Essence
21883	Ebon Felcloth
21884	Primal Fire
21885	Primal Water
21886	Primal Life
21887	Knothide Leather
21888	Gloves of the Immortal
21889	Gloves of the Redeemed Prophecy
21890	Gloves of the Fallen Prophet
21891	Shard of the Fallen Star
21892	Pattern: Bolt of Imbued Netherweave
21893	Pattern: Imbued Netherweave Bag
21894	Pattern: Bolt of Soulcloth
21895	Pattern: Primal Mooncloth
21896	Pattern: Netherweave Robe
21897	Pattern: Netherweave Tunic
21898	Pattern: Imbued Netherweave Pants
21899	Pattern: Imbued Netherweave Boots
21900	Pattern: Imbued Netherweave Robe
21901	Pattern: Imbued Netherweave Tunic
21902	Pattern: Soulcloth Gloves
21903	Pattern: Soulcloth Shoulders
21904	Pattern: Soulcloth Vest
21905	Pattern: Arcanoweave Bracers
21906	Pattern: Arcanoweave Boots
21907	Pattern: Arcanoweave Robe
21908	Pattern: Spellfire Belt
21909	Pattern: Spellfire Gloves
21910	Pattern: Spellfire Robe
21911	Pattern: Spellfire Bag
21912	Pattern: Frozen Shadoweave Shoulders
21913	Pattern: Frozen Shadoweave Robe
21914	Pattern: Frozen Shadoweave Boots
21915	Pattern: Ebon Shadowbag
21916	Pattern: Primal Mooncloth Belt
21917	Pattern: Primal Mooncloth Robe
21918	Pattern: Primal Mooncloth Shoulders
21919	Pattern: Primal Mooncloth Bag
21920	Creased Letter
21921	Carefully Penned Note
21924	Pattern: Runecloth Robe
21925	Immaculate Letter
21926	Slightly Creased Note
21927	Instant Poison VII
21928	Winterspring Blood Sample
21929	Flame Spessarite
21931	Woven Copper Ring
21932	Heavy Copper Ring
21933	Thick Bronze Necklace
21934	Ornate Tigerseye Necklace
21935	Stable Ectoplasm
21936	Frozen Ectoplasm
21937	Scorched Ectoplasm
21938	Magma Core
21939	Fel Elemental Rod
21940	Design: Golden Hare
21941	Design: Black Pearl Panther
21942	Design: Ruby Crown of Restoration
21943	Design: Truesilver Crab
21944	Design: Truesilver Boar
21945	Design: The Aquamarine Ward
21946	Ectoplasmic Distiller
21947	Design: Gem Studded Band
21948	Design: Opal Necklace of Impact
21949	Design: Ruby Serpent
21951	Design: Cut Azerothian Diamond
21952	Design: Emerald Crown of Destruction
21953	Design: Emerald Owl
21954	Design: Ring of Bitter Shadows
21955	Design: Black Diamond Crab
21956	Design: Dark Iron Scorpid
21957	Design: Necklace of the Diamond Tower
21958	Design: Arcanite Sword Pendant
21959	Design: Blood Crown
21960	Handmade Woodcraft
21975	Pledge of Adoration: Stormwind
21979	Gift of Adoration: Darnassus
21980	Gift of Adoration: Ironforge
21981	Gift of Adoration: Stormwind
21982	Ogre Warbeads
21983	Incomplete Banner of Provocation
21984	Left Piece of Lord Valthalak's Amulet
21985	Sealed Blood Container
21986	Banner of Provocation
21987	Incendicite of Incendius
21988	Ember of Emberseer
21989	Cinder of Cynders
21990	Netherweave Bandage
21991	Heavy Netherweave Bandage
21992	Manual: Netherweave Bandage
21993	Manual: Heavy Netherweave Bandage
21994	Belt of Heroism
21995	Boots of Heroism
21996	Bracers of Heroism
21997	Breastplate of Heroism
21998	Gauntlets of Heroism
21999	Helm of Heroism
22000	Legplates of Heroism
22001	Spaulders of Heroism
22002	Darkmantle Belt
22003	Darkmantle Boots
22004	Darkmantle Bracers
22005	Darkmantle Cap
22006	Darkmantle Gloves
22007	Darkmantle Pants
22008	Darkmantle Spaulders
22009	Darkmantle Tunic
22010	Beastmaster's Belt
22011	Beastmaster's Bindings
22012	Master First Aid - Doctor in the House
22013	Beastmaster's Cap
22014	Hallowed Brazier
22015	Beastmaster's Gloves
22016	Beastmaster's Mantle
22017	Beastmaster's Pants
22018	Conjured Glacier Water
22019	Conjured Croissant
22044	Mana Emerald
22046	Right Piece of Lord Valthalak's Amulet
22047	Top Piece of Lord Valthalak's Amulet
22048	Lord Valthalak's Amulet
22049	Brazier of Beckoning
22050	Brazier of Beckoning
22051	Brazier of Beckoning
22052	Brazier of Beckoning
22053	Deadly Poison VI
22054	Deadly Poison VII
22055	Wound Poison V
22056	Brazier of Beckoning
22057	Brazier of Invocation
22058	Valentine's Day Stationery
22059	Valentine's Day Card
22060	Beastmaster's Tunic
22061	Beastmaster's Boots
22062	Sorcerer's Belt
22063	Sorcerer's Bindings
22064	Sorcerer's Boots
22065	Sorcerer's Crown
22066	Sorcerer's Gloves
22067	Sorcerer's Leggings
22068	Sorcerer's Mantle
22069	Sorcerer's Robes
22070	Deathmist Belt
22071	Deathmist Bracers
22072	Deathmist Leggings
22073	Deathmist Mantle
22074	Deathmist Mask
22075	Deathmist Robe
22076	Deathmist Sandals
22077	Deathmist Wraps
22078	Virtuous Belt
22079	Virtuous Bracers
22080	Virtuous Crown
22081	Virtuous Gloves
22082	Virtuous Mantle
22083	Virtuous Robe
22084	Virtuous Sandals
22085	Virtuous Skirt
22086	Soulforge Belt
22087	Soulforge Boots
22088	Soulforge Bracers
22089	Soulforge Breastplate
22090	Soulforge Gauntlets
22091	Soulforge Helm
22092	Soulforge Legplates
22093	Soulforge Spaulders
22094	Bloodkelp
22095	Bindings of The Five Thunders
22096	Boots of The Five Thunders
22097	Coif of The Five Thunders
22098	Cord of The Five Thunders
22099	Gauntlets of The Five Thunders
22100	Kilt of The Five Thunders
22101	Pauldrons of The Five Thunders
22102	Vest of The Five Thunders
22103	Master Healthstone
22104	Master Healthstone
22105	Master Healthstone
22106	Feralheart Belt
22107	Feralheart Boots
22108	Feralheart Bracers
22109	Feralheart Cowl
22110	Feralheart Gloves
22111	Feralheart Kilt
22112	Feralheart Spaulders
22113	Feralheart Vest
22114	Pink Murloc Egg
22115	Extra-Dimensional Ghost Revealer
22116	Master Soulstone
22117	Pledge of Loyalty: Stormwind
22119	Pledge of Loyalty: Ironforge
22120	Pledge of Loyalty: Darnassus
22121	Pledge of Loyalty: Undercity
22122	Pledge of Loyalty: Thunder Bluff
22123	Pledge of Loyalty: Orgrimmar
22128	Master Firestone
22130	Symbol of Love
22131	Stormwind Gift Collection
22132	Ironforge Gift Collection
22133	Darnassus Gift Collection
22134	Undercity Gift Collection
22135	Thunder Bluff Gift Collection
22136	Orgrimmar Gift Collection
22137	Ysida's Satchel
22138	Blackrock Bracer
22139	Ysida's Locket
22140	Sentinel's Card
22141	Ironforge Guard's Card
22142	Grunt's Card
22143	Stormwind Guard's Card
22144	Bluffwatcher's Card
22145	Guardian's Moldy Card
22146	Book: Gift of the Wild III
22147	Flintweed Seed
22148	Wild Quillvine
22149	Beads of Ogre Mojo
22150	Beads of Ogre Might
22151	Anthion's Holy Water
22152	Anthion's Pouch
22153	Tome of Arcane Brilliance 2
22154	Pledge of Adoration: Ironforge
22155	Pledge of Adoration: Darnassus
22156	Pledge of Adoration: Orgrimmar
22157	Pledge of Adoration: Undercity
22158	Pledge of Adoration: Thunder Bluff
22159	Pledge of Friendship: Darnassus
22160	Pledge of Friendship: Ironforge
22161	Pledge of Friendship: Orgrimmar
22162	Pledge of Friendship: Thunder Bluff
22163	Pledge of Friendship: Undercity
22164	Gift of Adoration: Orgrimmar
22165	Gift of Adoration: Thunder Bluff
22166	Gift of Adoration: Undercity
22167	Gift of Friendship: Darnassus
22168	Gift of Friendship: Ironforge
22169	Gift of Friendship: Orgrimmar
22170	Gift of Friendship: Stormwind
22171	Gift of Friendship: Thunder Bluff
22172	Gift of Friendship: Undercity
22173	Dwarven Homebrew
22174	Romantic Poem
22175	Freshly Baked Pie
22176	Homemade Bread
22177	Freshly Picked Flowers
22178	Pledge of Friendship: Stormwind
22179	Grimoire of Firebolt (Rank 8)
22180	Grimoire of Blood Pact (Rank 6)
22181	Grimoire of Fire Shield (Rank 6)
22182	Grimoire of Torment (Rank 7)
22183	Grimoire of Suffering (Rank 5)
22184	Grimoire of Consume Shadows (Rank 7)
22185	Grimoire of Sacrifice (Rank 7)
22186	Grimoire of Lash of Pain (Rank 7)
22187	Grimoire of Soothing Kiss (Rank 5)
22188	Grimoire of Devour Magic (Rank 5)
22189	Grimoire of Devour Magic (Rank 6)
22190	Grimoire of Tainted Blood (Rank 5)
22191	Obsidian Mail Tunic
22192	Bloodkelp Elixir of Dodging
22193	Bloodkelp Elixir of Resistance
22194	Black Grasp of the Destroyer
22195	Light Obsidian Belt
22196	Thick Obsidian Breastplate
22197	Heavy Obsidian Belt
22198	Jagged Obsidian Shield
22200	Silver Shafted Arrow
22201	Reliquary of Purity
22202	Small Obsidian Shard
22203	Large Obsidian Shard
22204	Wristguards of Renown
22205	Black Steel Bindings
22206	Bouquet of Red Roses
22207	Sash of the Grand Hunt
22208	Lavastone Hammer
22209	Plans: Heavy Obsidian Belt
22212	Golem Fitted Pauldrons
22214	Plans: Light Obsidian Belt
22216	Venoxis's Venom Sac
22217	Kurinnaxx's Venom Sac
22218	Handful of Rose Petals
22219	Plans: Jagged Obsidian Shield
22220	Plans: Black Grasp of the Destroyer
22221	Plans: Obsidian Mail Tunic
22222	Plans: Thick Obsidian Breastplate
22223	Foreman's Head Protector
22224	Jeering Spectre's Essence
22225	Dragonskin Cowl
22226	Druidical Remains
22227	Starbreeze Village Relic
22228	Brilliant Sword of Zealotry
22229	Soul Ashes of the Banished
22230	Frightmaw Hide
22231	Kayser's Boots of Precision
22232	Marksman's Girdle
22233	Zigris' Footlocker
22234	Mantle of Lost Hope
22235	Truesilver Shafted Arrow
22236	Buttermilk Delight
22237	Dark Desire
22238	Very Berry Cream
22239	Sweet Surprise
22240	Greaves of Withering Despair
22241	Dark Warder's Pauldrons
22242	Verek's Leash
22243	Small Soul Pouch
22244	Box of Souls
22245	Soot Encrusted Footwear
22246	Enchanted Mageweave Pouch
22247	Faith Healer's Boots
22248	Enchanted Runecloth Bag
22249	Big Bag of Enchantment
22250	Herb Pouch
22251	Cenarion Herb Bag
22252	Satchel of Cenarius
22253	Tome of the Lost
22254	Wand of Eternal Light
22255	Magma Forged Band
22256	Mana Shaping Handwraps
22257	Bloodclot Band
22258	Love Potion
22259	Unbestowed Friendship Bracelet
22260	Friendship Bracelet
22261	Love Fool
22262	Alliance Gift Collection
22263	Horde Gift Collection
22264	Carefully Written Letter
22265	Lovingly Composed Letter
22266	Flarethorn
22267	Spellweaver's Turban
22268	Draconic Infused Emblem
22269	Shadow Prowler's Cloak
22270	Entrenching Boots
22271	Leggings of Frenzied Magic
22272	Forest's Embrace
22273	Moonshadow Hood
22274	Grizzled Pelt
22275	Firemoss Boots
22276	Lovely Red Dress
22277	Red Dinner Suit
22278	Lovely Blue Dress
22279	Lovely Black Dress
22280	Lovely Purple Dress
22281	Blue Dinner Suit
22282	Purple Dinner Suit
22283	Sack of Homemade Bread
22284	Bundle of Cards
22285	Stormwind Pledge Collection
22286	Ironforge Pledge Collection
22287	Parcel of Cards
22288	Case of Homebrew
22289	Stack of Cards
22290	Darnassus Pledge Collection
22291	Box of Woodcrafts
22292	Box of Fresh Pies
22293	Package of Cards
22294	Orgrimmar Pledge Collection
22295	Satchel of Cards
22296	Basket of Flowers
22297	Thunder Bluff Pledge Collection
22298	Book of Romantic Poems
22299	Sheaf of Cards
22300	Undercity Pledge Collection
22301	Ironweave Robe
22302	Ironweave Cowl
22303	Ironweave Pants
22304	Ironweave Gloves
22305	Ironweave Mantle
22306	Ironweave Belt
22307	Pattern: Enchanted Mageweave Pouch
22308	Pattern: Enchanted Runecloth Bag
22309	Pattern: Big Bag of Enchantment
22310	Pattern: Cenarion Herb Bag
22311	Ironweave Boots
22312	Pattern: Satchel of Cenarius
22313	Ironweave Bracers
22314	Huntsman's Harpoon
22315	Hammer of Revitalization
22317	Lefty's Brass Knuckle
22318	Malgen's Long Bow
22319	Tome of Divine Right
22320	Mux's Quality Goods
22321	Heart of Wyrmthalak
22322	The Jaw Breaker
22324	Winter Kimchi
22325	Belt of the Trickster
22326	Amalgam's Band
22327	Amulet of the Redeemed
22328	Legplates of Vigilance
22329	Scepter of Interminable Focus
22330	Shroud of Arcane Mastery
22331	Band of the Steadfast Hero
22332	Blade of Necromancy
22333	Hammer of Divine Might
22334	Band of Mending
22335	Lord Valthalak's Staff of Command
22336	Draconian Aegis of the Legion
22337	Shroud of Domination
22338	Volcanic Ash
22339	Rune Band of Wizardry
22340	Pendant of Celerity
22342	Leggings of Torment
22343	Handguards of Savagery
22344	Brazier of Invocation: User's Manual
22345	Totem of Rebirth
22347	Fahrad's Reloading Repeater
22348	Doomulus Prime
22349	Desecrated Breastplate
22350	Desecrated Tunic
22351	Desecrated Robe
22352	Desecrated Legplates
22353	Desecrated Helmet
22354	Desecrated Pauldrons
22355	Desecrated Bracers
22356	Desecrated Waistguard
22357	Desecrated Gauntlets
22358	Desecrated Sabatons
22359	Desecrated Legguards
22360	Desecrated Headpiece
22361	Desecrated Spaulders
22362	Desecrated Wristguards
22363	Desecrated Girdle
22364	Desecrated Handguards
22365	Desecrated Boots
22366	Desecrated Leggings
22367	Desecrated Circlet
22368	Desecrated Shoulderpads
22369	Desecrated Bindings
22370	Desecrated Belt
22371	Desecrated Gloves
22372	Desecrated Sandals
22373	Wartorn Leather Scrap
22374	Wartorn Chain Scrap
22375	Wartorn Plate Scrap
22376	Wartorn Cloth Scrap
22377	The Thunderwood Poker
22378	Ravenholdt Slicer
22379	Shivsprocket's Shiv
22380	Simone's Cultivating Hammer
22381	Silithus Venom Sample
22382	Sealed Venom Container
22383	Sageblade
22384	Persuader
22385	Titanic Leggings
22386	Head of Instructor Razuvious DEP
22387	Heart of Anub'Rekhan
22388	Plans: Titanic Leggings
22389	Plans: Sageblade
22390	Plans: Persuader
22392	Formula: Enchant 2H Weapon - Agility
22393	Codex: Prayer of Shadow Protection
22394	Staff of Metanoia
22395	Totem of Rage
22396	Totem of Life
22397	Idol of Ferocity
22398	Idol of Rejuvenation
22399	Idol of Health
22400	Libram of Truth
22401	Libram of Hope
22402	Libram of Grace
22403	Diana's Pearl Necklace
22404	Willey's Back Scratcher
22405	Mantle of the Scarlet Crusade
22406	Redemption
22407	Helm of the New Moon
22408	Ritssyn's Wand of Bad Mojo
22409	Tunic of the Crescent Moon
22410	Gauntlets of Deftness
22411	Helm of the Executioner
22412	Thuzadin Mantle
22413	Sin'dorei Armaments
22414	Antheol's Elemental Grimoire
22415	Dragonhawk Feather
22416	Dreadnaught Breastplate
22417	Dreadnaught Legplates
22418	Dreadnaught Helmet
22419	Dreadnaught Pauldrons
22420	Dreadnaught Sabatons
22421	Dreadnaught Gauntlets
22422	Dreadnaught Waistguard
22423	Dreadnaught Bracers
22424	Redemption Wristguards
22425	Redemption Tunic
22426	Redemption Handguards
22427	Redemption Legguards
22428	Redemption Headpiece
22429	Redemption Spaulders
22430	Redemption Boots
22431	Redemption Girdle
22432	Devilsaur Barb
22433	Don Mauricio's Band of Domination
22434	Bloodcap
22435	Gorishi Sting
22436	Cryptstalker Tunic
22437	Cryptstalker Legguards
22438	Cryptstalker Headpiece
22439	Cryptstalker Spaulders
22440	Cryptstalker Boots
22441	Cryptstalker Handguards
22442	Cryptstalker Girdle
22443	Cryptstalker Wristguards
22444	Putrid Vine
22445	Arcane Dust
22446	Greater Planar Essence
22447	Lesser Planar Essence
22448	Small Prismatic Shard
22449	Large Prismatic Shard
22450	Void Crystal
22451	Primal Air
22452	Primal Earth
22456	Primal Shadow
22457	Primal Mana
22458	Moonshadow Stave
22459	Void Sphere
22460	Prismatic Sphere
22461	Runed Fel Iron Rod
22462	Runed Adamantite Rod
22463	Runed Eternium Rod
22464	Earthshatter Tunic
22465	Earthshatter Legguards
22466	Earthshatter Headpiece
22467	Earthshatter Spaulders
22468	Earthshatter Boots
22469	Earthshatter Handguards
22470	Earthshatter Girdle
22471	Earthshatter Wristguards
22472	Boots of Ferocity
22473	Antheol's Disciplinary Rod
22474	Meledor's Apprentice Badge
22475	Ralen's Apprentice Badge
22476	Bonescythe Breastplate
22477	Bonescythe Legplates
22478	Bonescythe Helmet
22479	Bonescythe Pauldrons
22480	Bonescythe Sabatons
22481	Bonescythe Gauntlets
22482	Bonescythe Waistguard
22483	Bonescythe Bracers
22484	Necrotic Rune
22487	Aldaron's Head
22488	Dreamwalker Tunic
22489	Dreamwalker Legguards
22490	Dreamwalker Headpiece
22491	Dreamwalker Spaulders
22492	Dreamwalker Boots
22493	Dreamwalker Handguards
22494	Dreamwalker Girdle
22495	Dreamwalker Wristguards
22496	Frostfire Robe
22497	Frostfire Leggings
22498	Frostfire Circlet
22499	Frostfire Shoulderpads
22500	Frostfire Sandals
22501	Frostfire Gloves
22502	Frostfire Belt
22503	Frostfire Bindings
22504	Plagueheart Robe
22505	Plagueheart Leggings
22506	Plagueheart Circlet
22507	Plagueheart Shoulderpads
22508	Plagueheart Sandals
22509	Plagueheart Gloves
22510	Plagueheart Belt
22511	Plagueheart Bindings
22512	Robe of Faith
22513	Leggings of Faith
22514	Circlet of Faith
22515	Shoulderpads of Faith
22516	Sandals of Faith
22517	Gloves of Faith
22518	Belt of Faith
22519	Bindings of Faith
22520	The Phylactery of Kel'Thuzad
22521	Superior Mana Oil
22522	Superior Wizard Oil
22523	Insignia of the Dawn
22524	Insignia of the Crusade
22525	Crypt Fiend Parts
22526	Bone Fragments
22527	Core of Elements
22528	Dark Iron Scraps
22529	Savage Frond
22530	Formula: Enchant Bracer - Major Defense
22531	Formula: Enchant Bracer - Superior Healing
22532	Formula: Enchant Bracer - Restore Mana Prime
22533	Formula: Enchant Bracer - Fortitude
22534	Formula: Enchant Bracer - Spellpower
22535	Formula: Enchant Ring - Striking
22536	Formula: Enchant Ring - Spellpower
22537	Formula: Enchant Ring - Healing Power
22538	Formula: Enchant Ring - Stats
22539	Formula: Enchant Shield - Intellect
22540	Formula: Enchant Shield - Shield Block
22541	Formula: Enchant Shield - Resistance
22542	Formula: Enchant Boots - Vitality
22543	Formula: Enchant Boots - Fortitude
22544	Formula: Enchant Boots - Dexterity
22545	Formula: Enchant Boots - Surefooted
22547	Formula: Enchant Chest - Exceptional Stats
22548	Formula: Enchant Cloak - Major Resistance
22549	Quartermaster Lymel's Bill of Lading
22550	Quartermaster Lymel's Goods
22551	Formula: Enchant Weapon - Major Intellect
22552	Formula: Enchant Weapon - Major Striking
22553	Formula: Enchant Weapon - Potency
22554	Formula: Enchant 2H Weapon - Savagery
22555	Formula: Enchant Weapon - Major Spellpower
22556	Formula: Enchant 2H Weapon - Major Agility
22557	Formula: Enchant Weapon - Battlemaster
22558	Formula: Enchant Weapon - Spellsurge
22559	Formula: Enchant Weapon - Mongoose
22560	Formula: Enchant Weapon - Sunfire
22561	Formula: Enchant Weapon - Soulfrost
22562	Formula: Superior Mana Oil
22563	Formula: Superior Wizard Oil
22564	Formula: Arcane Dust
22565	Formula: Large Prismatic Shard
22566	Phantasmal Substance
22567	Gargoyle Fragment
22568	Sealed Craftsman's Writ
22569	Intact Spider Fang
22570	Plagued Blood Sample
22571	Courier's Bag
22572	Mote of Air
22573	Mote of Earth
22574	Mote of Fire
22575	Mote of Life
22576	Mote of Mana
22577	Mote of Shadow
22578	Mote of Water
22579	Plagued Murloc Spine
22580	Crystallized Mana Essence
22581	Damaged Arcane Instruments
22582	Case of Crystallized Essences
22583	Rathis Tomber's Supplies
22589	Atiesh, Greatstaff of the Guardian
22590	Night Elf Plans: An'daroth
22591	Night Elf Plans: An'owyn
22592	Night Elf Plans: Scrying on the Sin'dorei
22593	Writ of Safe Passage
22594	Night Elf Plans
22595	Call to Arms Announcement
22597	The Lady's Necklace
22598	Stone of Light
22599	Stone of Flame
22600	Craftsman's Writ - Dense Weightstone
22601	Craftsman's Writ - Imperial Plate Chest
22602	Craftsman's Writ - Volcanic Hammer
22603	Craftsman's Writ - Huge Thorium Battleaxe
22604	Craftsman's Writ - Radiant Circlet
22605	Craftsman's Writ - Wicked Leather Headband
22606	Craftsman's Writ - Rugged Armor Kit
22607	Craftsman's Writ - Wicked Leather Belt
22608	Craftsman's Writ - Runic Leather Pants
22609	Craftsman's Writ - Brightcloth Pants
22610	Craftsman's Writ - Runecloth Boots
22611	Craftsman's Writ - Runecloth Bag
22612	Craftsman's Writ - Runecloth Robe
22613	Craftsman's Writ - Goblin Sapper Charge
22614	Craftsman's Writ - Thorium Grenade
22615	Craftsman's Writ - Gnomish Battle Chicken
22616	Craftsman's Writ - Thorium Tube
22617	Craftsman's Writ - Major Mana Potion
22618	Craftsman's Writ - Major Healing Potion
22619	Craftsman's Writ - Greater Frost Protection Potion
22620	Craftsman's Writ - Greater Arcane Protection Potion
22621	Craftsman's Writ - Flask of Petrification
22622	Craftsman's Writ - Stonescale Eel
22623	Craftsman's Writ - Plated Armorfish
22624	Craftsman's Writ - Lightning Eel
22625	Craftsman's Writ - Baked Salmon
22626	Craftsman's Writ - Runn Tum Tuber Surprise
22627	The Lady's Necklace
22628	Renzithen's Restorative Draught
22629	Sealed Sin'dorei Orders
22630	Atiesh, Greatstaff of the Guardian
22631	Atiesh, Greatstaff of the Guardian
22632	Atiesh, Greatstaff of the Guardian
22633	Troll Juju
22634	Underlight Ore
22635	Savage Guard
22636	Ice Guard
22637	Primal Hakkari Idol
22638	Shadow Guard
22639	Zeb'Sora Troll Ear
22640	Head of Kel'gash the Wicked
22641	Rotting Heart
22642	Spinal Dust
22644	Crunchy Spider Leg
22645	Crunchy Spider Surprise
22646	Master Spellstone
22647	Recipe: Crunchy Spider Surprise
22648	Hive'Ashi Dossier
22649	Hive'Regal Dossier
22650	Hive'Zora Dossier
22651	Outrider's Plate Legguards
22652	Glacial Vest
22653	Dar'Khan's Head
22654	Glacial Gloves
22655	Glacial Wrists
22656	The Purifier
22657	Amulet of the Dawn
22658	Glacial Cloak
22659	Medallion of the Dawn
22660	Gaea's Embrace
22661	Polar Tunic
22662	Polar Gloves
22663	Polar Bracers
22664	Icy Scale Breastplate
22665	Icy Scale Bracers
22666	Icy Scale Gauntlets
22667	Bracers of Hope
22668	Bracers of Subterfuge
22669	Icebane Breastplate
22670	Icebane Gauntlets
22671	Icebane Bracers
22672	Sentinel's Plate Legguards
22673	Outrider's Chain Leggings
22674	Wavefront Medallion
22675	Bundle of Medallions
22676	Outrider's Mail Leggings
22677	Catlord Claws
22678	Talisman of Ascendance
22679	Supply Bag
22680	Band of Resolution
22681	Band of Piety
22682	Frozen Rune
22683	Pattern: Gaea's Embrace
22684	Pattern: Glacial Gloves
22685	Pattern: Glacial Cloak
22686	Pattern: Glacial Vest
22687	Pattern: Glacial Wrists
22688	Verimonde's Last Resort
22689	Sanctified Leather Helm
22690	Leggings of the Plague Hunter
22691	Corrupted Ashbringer
22692	Pattern: Polar Tunic
22693	Infused Crystal
22694	Pattern: Polar Gloves
22695	Pattern: Polar Bracers
22696	Pattern: Icy Scale Breastplate
22697	Pattern: Icy Scale Gauntlets
22698	Pattern: Icy Scale Bracers
22699	Icebane Leggings
22700	Glacial Leggings
22701	Polar Leggings
22702	Icy Scale Leggings
22703	Plans: Icebane Breastplate
22704	Plans: Icebane Gauntlets
22705	Plans: Icebane Bracers
22706	Dar'Khan's Journal
22707	Ramaladni's Icy Grasp
22708	Fate of Ramaladni
22710	Bloodthistle
22711	Cloak of the Hakkari Worshipers
22712	Might of the Tribe
22713	Zulian Scepter of Rites
22714	Sacrificial Gauntlets
22715	Gloves of the Tormented
22716	Belt of Untapped Power
22717	Letter from Silvermoon
22718	Blooddrenched Mask
22719	Omarion's Handbook
22720	Zulian Headdress
22721	Band of Servitude
22722	Seal of the Gurubashi Berserker
22723	A Letter from the Keeper of the Rolls
22725	Band of Cenarius
22726	Splinter of Atiesh
22727	Frame of Atiesh
22728	Steam Tonk Controller
22729	Schematic: Steam Tonk Controller
22730	Eyestalk Waist Cord
22731	Cloak of the Devoured
22732	Mark of C'Thun
22733	Staff Head of Atiesh
22734	Base of Atiesh
22735	Research Notes
22736	Andonisus, Reaper of Souls
22737	Atiesh, Greatstaff of the Guardian
22739	Tome of Polymorph: Turtle
22740	Outrider's Leather Pants
22741	Outrider's Lizardhide Pants
22742	Bloodsail Shirt
22743	Bloodsail Sash
22744	Bloodsail Boots
22745	Bloodsail Pants
22746	Buccaneer's Uniform
22747	Outrider's Silk Leggings
22748	Sentinel's Chain Leggings
22749	Sentinel's Leather Pants
22750	Sentinel's Lizardhide Pants
22752	Sentinel's Silk Leggings
22753	Sentinel's Lamellar Legguards
22754	Eternal Quintessence
22755	Blazing Torch
22756	Sylvan Vest
22757	Sylvan Crown
22758	Sylvan Shoulders
22759	Bramblewood Helm
22760	Bramblewood Boots
22761	Bramblewood Belt
22762	Ironvine Breastplate
22763	Ironvine Gloves
22764	Ironvine Belt
22765	Mildewed Letter
22766	Plans: Ironvine Breastplate
22767	Plans: Ironvine Gloves
22768	Plans: Ironvine Belt
22769	Pattern: Bramblewood Belt
22770	Pattern: Bramblewood Boots
22771	Pattern: Bramblewood Helm
22772	Pattern: Sylvan Shoulders
22773	Pattern: Sylvan Crown
22774	Pattern: Sylvan Vest
22775	Suntouched Special Reserve
22776	Springpaw Appetizers
22777	Bundle of Fireworks
22778	Scourgebane Infusion
22779	Scourgebane Draught
22780	White Murloc Egg
22781	Polar Bear Collar
22782	Sin'dorei Cloak of Warding
22783	Sunwell Blade
22784	Sunwell Orb
22785	Felweed
22786	Dreaming Glory
22787	Ragveil
22788	Flame Cap
22789	Terocone
22790	Ancient Lichen
22791	Netherbloom
22792	Nightmare Vine
22793	Mana Thistle
22794	Fel Lotus
22795	Fel Blossom
22796	Apothecary's Poison
22797	Nightmare Seed
22798	Might of Menethil
22799	Soulseeker
22800	Brimstone Staff
22801	Spire of Twilight
22802	Kingsfall
22803	Midnight Haze
22804	Maexxna's Fang
22806	Widow's Remorse
22807	Wraith Blade
22808	The Castigator
22809	Maul of the Redeemed Crusader
22810	Toxin Injector
22811	Soulstring
22812	Nerubian Slavemaker
22813	Claymore of Unholy Might
22815	Severance
22816	Hatchet of Sundered Bone
22818	The Plague Bearer
22819	Shield of Condemnation
22820	Wand of Fates
22821	Doomfinger
22822	iCoke Prize Voucher
22823	Elixir of Camouflage
22824	Elixir of Major Strength
22825	Elixir of Healing Power
22826	Sneaking Potion
22827	Elixir of Major Frost Power
22828	Insane Strength Potion
22829	Super Healing Potion
22830	Elixir of the Searching Eye
22831	Elixir of Major Agility
22832	Super Mana Potion
22833	Elixir of Major Firepower
22834	Elixir of Major Defense
22835	Elixir of Major Shadow Power
22836	Major Dreamless Sleep Potion
22837	Heroic Potion
22838	Haste Potion
22839	Destruction Potion
22840	Elixir of Major Mageblood
22841	Major Fire Protection Potion
22842	Major Frost Protection Potion
22843	Blood Guard's Chain Greaves
22844	Major Nature Protection Potion
22845	Major Arcane Protection Potion
22846	Major Shadow Protection Potion
22847	Major Holy Protection Potion
22848	Elixir of Empowerment
22849	Ironshield Potion
22850	Super Rejuvenation Potion
22851	Flask of Fortification
22852	Blood Guard's Dragonhide Treads
22853	Flask of Mighty Restoration
22854	Flask of Relentless Assault
22855	Blood Guard's Dreadweave Walkers
22856	Blood Guard's Leather Walkers
22857	Blood Guard's Mail Greaves
22858	Blood Guard's Plate Greaves
22859	Blood Guard's Satin Walkers
22860	Blood Guard's Silk Walkers
22861	Flask of Blinding Light
22862	Blood Guard's Chain Vices
22863	Blood Guard's Dragonhide Grips
22864	Blood Guard's Leather Grips
22865	Blood Guard's Dreadweave Handwraps
22866	Flask of Pure Death
22867	Blood Guard's Mail Vices
22868	Blood Guard's Plate Gauntlets
22869	Blood Guard's Satin Handwraps
22870	Blood Guard's Silk Handwraps
22871	Shrouding Potion
22872	Legionnaire's Plate Hauberk
22873	Legionnaire's Plate Leggings
22874	Legionnaire's Chain Hauberk
22875	Legionnaire's Chain Legguards
22876	Legionnaire's Mail Hauberk
22877	Legionnaire's Dragonhide Chestpiece
22878	Legionnaire's Dragonhide Leggings
22879	Legionnaire's Leather Chestpiece
22880	Legionnaire's Leather Legguards
22881	Legionnaire's Dreadweave Legguards
22882	Legionnaire's Satin Legguards
22883	Legionnaire's Silk Legguards
22884	Legionnaire's Dreadweave Tunic
22885	Legionnaire's Satin Tunic
22886	Legionnaire's Silk Tunic
22887	Legionnaire's Mail Legguards
22888	Ammen Vale Gift Voucher
22889	Vial of Moth Blood
22890	Tome of Frost Ward V
22891	Grimoire of Shadow Ward IV
22892	Dim Necrotic Stone
22893	Luzran's Head
22894	Knucklerot's Head
22895	Conjured Cinnamon Roll
22896	Healing Crystal
22897	Tome of Conjure Food VII
22898	Consecrated Crystal
22899	Etched Crystal
22900	Recipe: Elixir of Camouflage
22901	Recipe: Sneaking Potion
22902	Recipe: Elixir of Major Frost Power
22903	Recipe: Insane Strength Potion
22904	Recipe: Elixir of the Searching Eye
22905	Recipe: Elixir of Major Agility
22906	Recipe: Shrouding Potion
22907	Recipe: Super Mana Potion
22908	Recipe: Elixir of Major Firepower
22909	Recipe: Elixir of Major Defense
22910	Recipe: Elixir of Major Shadow Power
22911	Recipe: Major Dreamless Sleep Potion
22912	Recipe: Heroic Potion
22913	Recipe: Haste Potion
22914	Recipe: Destruction Potion
22915	Recipe: Transmute Primal Air to Fire
22916	Recipe: Transmute Primal Earth to Water
22917	Recipe: Transmute Primal Fire to Earth
22918	Recipe: Transmute Primal Water to Air
22919	Recipe: Elixir of Major Mageblood
22920	Recipe: Major Fire Protection Potion
22921	Recipe: Major Frost Protection Potion
22922	Recipe: Major Nature Protection Potion
22923	Recipe: Major Arcane Protection Potion
22924	Recipe: Major Shadow Protection Potion
22925	Recipe: Major Holy Protection Potion
22926	Recipe: Elixir of Empowerment
22927	Recipe: Ironshield Potion
22928	Simple Crystal
22929	Glyphic Crystal
22930	A Bloodstained Envelope
22931	Hallowed Crystal
22932	A Torn Letter
22934	Lasher Sample
22935	Touch of Frost
22936	Wristguards of Vengeance
22937	Gem of Nerubis
22938	Cryptfiend Silk Cloak
22939	Band of Unanswered Prayers
22940	Icebane Pauldrons
22941	Polar Shoulder Pads
22942	The Widow's Embrace
22943	Malice Stone Pendant
22944	A Crumpled Missive
22945	A Careworn Note
22946	A Ragged Page
22947	Pendant of Forgotten Names
22948	A Smudged Document
22949	Cracked Necrotic Crystal
22950	Faint Necrotic Crystal
22951	Springpaw Hide Leggings
22952	Springpaw Hide Cloak
22953	Fur Lined Chain Shirt
22954	Kiss of the Spider
22955	Neutralizing Agent
22956	Rusty Mace
22957	Rusty Sin'dorei Sword
22958	Farstrider Sword
22959	Smooth Metal Staff
22960	Cloak of Suturing
22961	Band of Reanimation
22962	Inoculating Crystal
22963	Ranger's Pocketknife
22964	Sunsail Bracers
22965	Longshoreman's Bindings
22966	Silk Wristbands
22967	Icy Scale Spaulders
22968	Glacial Mantle
22969	Ven'jashi's Bow
22970	A Bloodstained Envelope
22971	Hoodoo Wand
22972	A Careworn Note
22973	A Crumpled Missive
22974	A Ragged Page
22975	A Smudged Document
22976	Magister's Pouch
22977	A Torn Letter
22978	Emitter Spare Part
22979	Slayer's Band
22980	Staff of the Sun
22981	Gluth's Missing Collar
22982	Farstrider's Longbow
22983	Rime Covered Mantle
22984	Dawnblade
22985	Suncrown Hauberk
22986	Apothecary's Robe
22987	Deathstalker's Vest
22988	The End of Dreams
22989	Blood Elf Amulet
22990	Tranquillien Champion's Cloak
22991	Apprentice Boots
22992	Bogwalker Boots
22993	Volunteer's Greaves
22994	Digested Hand of Power
22995	Sin'dorei Warblade
22996	Reforged Quel'dorei Crest
22997	Ley-Keeper's Wand
22998	Ghostclaw Leggings
22999	Tabard of the Argent Dawn
23000	Plated Abomination Ribcage
23001	Eye of Diminution
23002	Turtle Box
23003	Blood Elf Plans
23004	Idol of Longevity
23005	Totem of Flowing Water
23006	Libram of Light
23007	Piglet's Collar
23008	Sealed Research Report
23009	Wand of the Whispering Dead
23010	Sealed Research Report
23011	Sealed Research Report
23012	Sealed Research Report
23013	Sealed Research Report
23014	Iblis, Blade of the Fallen Seraph
23015	Rat Cage
23016	Sealed Research Report
23017	Veil of Eclipse
23018	Signet of the Fallen Defender
23019	Icebane Helmet
23020	Polar Helmet
23021	The Soul Harvester's Bindings
23022	Curmudgeon's Payoff
23023	Sadist's Collar
23024	Prepared Field Duty Papers
23025	Seal of the Damned
23026	Supply Request Crystal
23027	Warmth of Forgiveness
23028	Hailstone Band
23029	Noth's Frigid Heart
23030	Cloak of the Scourge
23031	Band of the Inevitable
23032	Glacial Headdress
23033	Icy Scale Coif
23035	Preceptor's Hat
23036	Necklace of Necropsy
23037	Ring of Spiritual Fervor
23038	Band of Unnatural Forces
23039	The Eye of Nerub
23040	Glyph of Deflection
23041	Slayer's Crest
23042	Loatheb's Reflection
23043	The Face of Death
23044	Harbinger of Doom
23045	Shroud of Dominion
23046	The Restrained Essence of Sapphiron
23047	Eye of the Dead
23048	Sapphiron's Right Eye
23049	Sapphiron's Left Eye
23050	Cloak of the Necropolis
23051	Glaive of the Defender
23053	Stormrage's Talisman of Seething
23054	Gressil, Dawn of Ruin
23055	Word of Thawing
23056	Hammer of the Twisting Nether
23057	Gem of Trapped Innocents
23058	Life Channeling Necklace
23059	Ring of the Dreadnaught
23060	Bonescythe Ring
23061	Ring of Faith
23062	Frostfire Ring
23063	Plagueheart Ring
23064	Ring of The Dreamwalker
23065	Ring of the Earthshatterer
23066	Ring of Redemption
23067	Ring of  the Cryptstalker
23068	Legplates of Carnage
23069	Necro-Knight's Garb
23070	Leggings of Polarity
23071	Leggings of Apocalypse
23072	Fists of the Unrelenting
23073	Boots of Displacement
23075	Death's Bargain
23076	Brilliant Citrine
23077	Blood Garnet
23078	Gauntlets of Undead Slaying
23079	Deep Peridot
23081	Handwraps of Undead Slaying
23082	Handguards of Undead Slaying
23083	Captured Flame
23084	Gloves of Undead Cleansing
23085	Robe of Undead Cleansing
23087	Breastplate of Undead Slaying
23088	Chestguard of Undead Slaying
23089	Tunic of Undead Slaying
23090	Bracers of Undead Slaying
23091	Bracers of Undead Cleansing
23092	Wristguards of Undead Slaying
23093	Wristwraps of Undead Slaying
23094	Teardrop Blood Garnet
23095	Bold Blood Garnet
23096	Runed Blood Garnet
23097	Delicate Blood Garnet
23098	Inscribed Flame Spessarite
23099	Luminous Flame Spessarite
23100	Glinting Flame Spessarite
23101	Potent Flame Spessarite
23103	Radiant Deep Peridot
23104	Jagged Deep Peridot
23105	Enduring Deep Peridot
23106	Dazzling Deep Peridot
23107	Shadow Draenite
23108	Glowing Shadow Draenite
23109	Royal Shadow Draenite
23110	Shifting Shadow Draenite
23111	Sovereign Shadow Draenite
23112	Golden Draenite
23113	Brilliant Golden Draenite
23114	Gleaming Golden Draenite
23115	Thick Golden Draenite
23116	Rigid Golden Draenite
23117	Azure Moonstone
23118	Solid Azure Moonstone
23119	Sparkling Azure Moonstone
23120	Stormy Azure Moonstone
23121	Lustrous Azure Moonstone
23122	Consecrated Sharpening Stone
23123	Blessed Wizard Oil
23124	Staff of Balzaphon
23125	Chains of the Lich
23126	Waistband of Balzaphon
23127	Cloak of Revanchion
23128	The Shadow's Grasp
23129	Bracers of Mending
23130	Design: Teardrop Blood Garnet
23131	Design: Bold Blood Garnet
23132	Lord Blackwood's Blade
23133	Design: Runed Blood Garnet
23134	Design: Delicate Blood Garnet
23135	Design: Inscribed Flame Spessarite
23136	Design: Luminous Flame Spessarite
23137	Design: Glinting Flame Spessarite
23138	Design: Potent Flame Spessarite
23139	Lord Blackwood's Buckler
23140	Design: Radiant Deep Peridot
23141	Design: Jagged Deep Peridot
23142	Design: Enduring Deep Peridot
23143	Design: Dazzling Deep Peridot
23144	Design: Glowing Shadow Draenite
23145	Design: Royal Shadow Draenite
23146	Design: Shifting Shadow Draenite
23147	Design: Sovereign Shadow Draenite
23148	Design: Brilliant Golden Draenite
23149	Design: Gleaming Golden Draenite
23150	Design: Thick Golden Draenite
23151	Design: Rigid Golden Draenite
23152	Design: Solid Azure Moonstone
23153	Design: Sparkling Azure Moonstone
23154	Design: Stormy Azure Moonstone
23155	Design: Lustrous Azure Moonstone
23156	Blackwood's Thigh
23157	Thick Citrine
23158	Solid Aquamarine
23159	Sparkling Aquamarine
23160	Friendship Bread
23161	Freshly-Squeezed Lemonade
23162	Foror's Crate of Endless Resist Gear Storage
23163	Performer's Wand
23164	Bubbly Beverage
23165	Headhunter Axe
23166	Hexxer Stave
23167	Shadowcaster Mace
23168	Scorn's Focal Dagger
23169	Scorn's Icy Choker
23170	The Frozen Clutch
23171	The Axe of Severing
23172	Refreshing Red Apple
23173	Abomination Skin Leggings
23175	Tasty Summer Treat
23176	Fizzy Energy Drink
23177	Lady Falther'ess' Finger
23178	Mantle of Lady Falther'ess
23179	Flame of Orgrimmar
23180	Flame of Thunder Bluff
23181	Flame of the Undercity
23182	Flame of Stormwind
23183	Flame of Ironforge
23184	Flame of Darnassus
23191	Crystal Controlling Orb
23192	Tabard of the Scarlet Crusade
23193	Naxxramas Deathcharger Reins
23194	Lesser Mark of the Dawn
23195	Mark of the Dawn
23196	Greater Mark of the Dawn
23197	Idol of the Moon
23198	Idol of Brutality
23199	Totem of the Storm
23200	Totem of Sustaining
23201	Libram of Divinity
23203	Libram of Fervor
23205	Hellfire Spineleaf
23206	Mark of the Champion
23207	Mark of the Champion
23211	Toasted Smorc
23212	Scrapper's Vest
23213	Scrapper's Pants
23214	Plump Helboar Carcass
23215	Bag of Smorc Ingredients
23216	Pulsating Voidwalker Essence
23217	Ravager Egg
23218	Condensed Voidwalker Essence
23219	Girdle of the Mentor
23220	Crystal Webbed Robe
23221	Misplaced Servo Arm
23222	Clefthoof Hide
23223	Clefthoof Bones
23224	Summer Gift Package
23226	Ghoul Skin Tunic
23227	iCoke Gift Box Voucher
23229	Sword of Sockety Goodness
23230	Dagger of Sockety Goodness
23231	Clefthoof Sinew
23232	Huge Sword of Sockety Goodness
23233	Red Bryanite of Strength stuff
23234	Blue Bryanite of Agility
23235	Yellow Bryanite of Stamina
23236	Meta Bryanite
23237	Ring of the Eternal Flame
23238	Stygian Buckler
23239	Plump Buzzard Wing
23242	Claw of the Frost Wyrm
23243	Champion's Plate Shoulders
23244	Champion's Plate Helm
23246	Fiery Festival Brew
23247	Burning Blossom
23248	Purified Helboar Meat
23249	Amani Invasion Plans
23250	Prismatic Shell
23251	Champion's Chain Helm
23252	Champion's Chain Shoulders
23253	Champion's Dragonhide Headguard
23254	Champion's Dragonhide Shoulders
23255	Champion's Dreadweave Cowl
23256	Champion's Dreadweave Spaulders
23257	Champion's Leather Helm
23258	Champion's Leather Shoulders
23259	Champion's Mail Headguard
23260	Champion's Mail Pauldrons
23261	Champion's Satin Hood
23262	Champion's Satin Mantle
23263	Champion's Silk Cowl
23264	Champion's Silk Mantle
23265	Blackened Chain Girdle
23266	Ranger's Vest
23267	Satin Lined Boots
23268	Purification Mixture
23269	Felblood Sample
23270	Tainted Helboar Meat
23272	Knight-Captain's Lamellar Breastplate
23273	Knight-Captain's Lamellar Leggings
23274	Knight-Lieutenant's Lamellar Gauntlets
23275	Knight-Lieutenant's Lamellar Sabatons
23276	Lieutenant Commander's Lamellar Headguard
23277	Lieutenant Commander's Lamellar Shoulders
23278	Knight-Lieutenant's Chain Greaves
23279	Knight-Lieutenant's Chain Vices
23280	Knight-Lieutenant's Dragonhide Grips
23281	Knight-Lieutenant's Dragonhide Treads
23282	Knight-Lieutenant's Dreadweave Handwraps
23283	Knight-Lieutenant's Dreadweave Walkers
23284	Knight-Lieutenant's Leather Grips
23285	Knight-Lieutenant's Leather Walkers
23286	Knight-Lieutenant's Plate Gauntlets
23287	Knight-Lieutenant's Plate Greaves
23288	Knight-Lieutenant's Satin Handwraps
23289	Knight-Lieutenant's Satin Walkers
23290	Knight-Lieutenant's Silk Handwraps
23291	Knight-Lieutenant's Silk Walkers
23292	Knight-Captain's Chain Hauberk
23293	Knight-Captain's Chain Legguards
23294	Knight-Captain's Dragonhide Chestpiece
23295	Knight-Captain's Dragonhide Leggings
23296	Knight-Captain's Dreadweave Legguards
23297	Knight-Captain's Dreadweave Tunic
23298	Knight-Captain's Leather Chestpiece
23299	Knight-Captain's Leather Legguards
23300	Knight-Captain's Plate Hauberk
23301	Knight-Captain's Plate Leggings
23302	Knight-Captain's Satin Legguards
23303	Knight-Captain's Satin Tunic
23304	Knight-Captain's Silk Legguards
23305	Knight-Captain's Silk Tunic
23306	Lieutenant Commander's Chain Helm
23307	Lieutenant Commander's Chain Shoulders
23308	Lieutenant Commander's Dragonhide Headguard
23309	Lieutenant Commander's Dragonhide Shoulders
23310	Lieutenant Commander's Dreadweave Cowl
23311	Lieutenant Commander's Dreadweave Spaulders
23312	Lieutenant Commander's Leather Helm
23313	Lieutenant Commander's Leather Shoulders
23314	Lieutenant Commander's Plate Helm
23315	Lieutenant Commander's Plate Shoulders
23316	Lieutenant Commander's Satin Hood
23317	Lieutenant Commander's Satin Mantle
23318	Lieutenant Commander's Silk Cowl
23319	Lieutenant Commander's Silk Mantle
23320	Tablet of Flame Shock VI
23321	Recruit's Robe
23322	Acolyte's Robe
23323	Crown of the Fire Festival
23324	Mantle of the Fire Festival
23326	Midsummer Sausage
23327	Fire-toasted Bun
23329	Enriched Lasher Root
23330	Wilted Petal
23331	Broken Vine
23332	Withered Lasher Root
23333	Shattered Power Core
23334	Cracked Power Core
23336	Helboar Blood Sample
23337	Cenarion Antidote
23338	Eroded Leather Case
23339	Arelion's Journal
23340	Arelion's Journal Page 2
23341	Arelion's Journal Page 3
23342	Arelion's Journal Page 4
23343	Torn Pilgrim's Pack
23344	Scout's Pants
23345	Scout's Shirt
23346	Battleworn Claymore
23347	Weathered Crossbow
23348	Scout's Boots
23349	Battleworn Shoes
23350	Battleworn Pants
23351	Battleworn Shirt
23352	Potent Voidwalker Essence
23353	Mana Residue
23354	Crystalized Mana Residue
23355	Toxic Helboar Meat
23357	Hatched Ravager Egg
23358	Signaling Gem
23360	Head of Instructor Razuvious
23361	Cleansing Vial
23362	Hammer of the Sun
23363	Titanic Breastplate
23364	zzDEPRECATEDHeart of the Sky
23365	Steel Rimmed Buckler
23366	zzDEPRECATEDPerfect Diamond
23367	Light Silk Robe
23368	Soft Leather Boots
23370	Ley-Keeper's Blade
23371	Velania's Walking Stick
23372	Bloodhawk Claymore
23373	Long Knife
23374	Warp Hound Blood
23375	Black Leather Vest
23376	Gatewatcher's Chain Gloves
23377	Guard's Leggings
23378	Undamaged Warp Hound Corpse
23379	Cinder Bracers
23380	Broken Power Core
23381	Chipped Power Core
23383	Ripped Wyrm Scale
23384	Dimly Glowing Eye
23385	Dormant Mana Powder
23386	Condensed Mana Powder
23387	Bonestripper Tail Feather
23388	Tranquillien Tabard
23389	Empty Draenei Supply Pouch
23390	Exodar Bastard Sword
23391	Exodar Dagger
23392	Exodar Maul
23393	Exodar Shortsword
23394	Healing Salve
23395	Farstrider's Buckler
23396	Slightly Used Ranger's Blade
23397	Satin Lined Gloves
23398	Worn Ranger's Bow
23399	Fallen Apprentice's Robe
23400	Sylastor's Cloak
23401	Divining Crystal
23402	Arcanist's Dagger
23403	Salvaged Mail Leggings
23404	Padded Running Shoes
23405	Farstrider's Tunic
23406	Sentry Bracers
23407	Supple Cotton Bracer
23408	Farstrider's Bracers
23409	Well Crafted Long Bow
23410	Well Crafted Sword
23411	Well Crafted Staff
23412	Troll Kickers
23413	Troll Kickers
23414	Troll Kickers
23415	Survival Knife
23417	Sanctified Crystal
23420	Engraved Axe
23421	Engraved Sword
23422	Engraved Dagger
23423	Mercenary Greatsword
23424	Fel Iron Ore
23425	Adamantite Ore
23426	Khorium Ore
23427	Eternium Ore
23429	Mercenary Clout
23430	Mercenary Sword
23431	Mercenary Stiletto
23432	Engraved Greatsword
23433	Blood Robes
23434	Robes of the Shard
23435	Elderberry Pie
23436	Living Ruby
23437	Talasite
23438	Star of Elune
23439	Noble Topaz
23440	Dawnstone
23441	Nightseye
23442	Glowing Sanctified Crystal
23444	Goldenmist Special Brew
23445	Fel Iron Bar
23446	Adamantite Bar
23447	Eternium Bar
23448	Felsteel Bar
23449	Khorium Bar
23451	Grand Marshal's Mageblade
23452	Grand Marshal's Tome of Power
23453	Grand Marshal's Tome of Restoration
23454	Grand Marshal's Warhammer
23455	Grand Marshal's Demolisher
23456	Grand Marshal's Swiftblade
23457	High Warlord's Destroyer
23458	High Warlord's Spellblade
23459	High Warlord's Battle Mace
23460	Broken Blood Sample
23461	High Warlord's Quickblade
23462	High Warlord's Tome of Destruction
23463	High Warlord's Tome of Mending
23464	High Warlord's Battle Mace
23465	High Warlord's Destroyer
23466	High Warlord's Spellblade
23467	High Warlord's Quickblade
23468	High Warlord's Tome of Destruction
23469	High Warlord's Tome of Mending
23470	Rugged Trapper's Shirt
23471	Rugged Trapper's Pants
23472	Rugged Trapper's Boots
23473	Recruit's Shirt
23474	Recruit's Pants
23475	Recruit's Boots
23476	Squire's Shirt
23477	Squire's Pants
23478	Recruit's Pants
23479	Recruit's Robe
23480	Lit Torch
23482	Fel Iron Plate Gloves
23483	Haal'eshi Scroll
23484	Fel Iron Plate Belt
23485	Empty Birdcage
23486	Caged Female Kaliri Hatchling
23487	Fel Iron Plate Boots
23488	Fel Iron Plate Pants
23489	Fel Iron Breastplate
23490	Fel Iron Chain Tunic
23491	Fel Iron Chain Gloves
23492	Suntouched Special Reserve
23493	Fel Iron Chain Coif
23494	Fel Iron Chain Bracers
23495	Springpaw Appetizer
23497	Fel Iron Hatchet
23498	Fel Iron Hammer
23499	Fel Iron Greatsword
23500	Saltheril's Haven Party Invitation
23501	Bloodthistle Petal
23502	Adamantite Maul
23503	Adamantite Cleaver
23504	Adamantite Dagger
23505	Adamantite Rapier
23506	Adamantite Plate Bracers
23507	Adamantite Breastplate
23508	Adamantite Plate Gloves
23509	Enchanted Adamantite Breastplate
23510	Enchanted Adamantite Belt
23511	Enchanted Adamantite Boots
23512	Enchanted Adamantite Leggings
23513	Flamebane Breastplate
23514	Flamebane Gloves
23515	Flamebane Bracers
23516	Flamebane Helm
23517	Felsteel Gloves
23518	Felsteel Leggings
23519	Felsteel Helm
23520	Ragesteel Gloves
23521	Ragesteel Helm
23522	Ragesteel Breastplate
23523	Khorium Pants
23524	Khorium Belt
23525	Khorium Boots
23526	Swiftsteel Gloves
23527	Earthpeace Breastplate
23528	Fel Sharpening Stone
23529	Adamantite Sharpening Stone
23530	Felsteel Shield Spike
23531	Felfury Gauntlets
23532	Gauntlets of the Iron Tower
23533	Steelgrip Gauntlets
23534	Storm Helm
23535	Helm of the Stalwart Defender
23536	Oathkeeper's Helm
23537	Black Felsteel Bracers
23538	Bracers of the Green Fortress
23539	Blessed Bracers
23540	Felsteel Longblade
23541	Khorium Champion
23542	Fel Edged Battleaxe
23543	Felsteel Reaper
23544	Runic Hammer
23545	Power of the Scourge
23546	Fel Hardened Maul
23547	Resilience of the Scourge
23548	Might of the Scourge
23549	Fortitude of the Scourge
23550	Heavy Stone Axe
23551	Azure Phial
23552	Filled Azure Phial
23553	Living Branch
23554	Eternium Runed Blade
23555	Dirge
23556	Hand of Eternity
23557	Larvae of the Great Worm
23558	The Burrower's Shell
23559	Lesser Rune of Warding
23560	Arena Team Charter (2v2)
23561	Arena Team Charter (3v3)
23562	Arena Team Charter (5v5)
23563	Nether Chain Shirt
23564	Twisting Nether Chain Shirt
23565	Embrace of the Twisting Nether
23566	Azure Phial
23568	Bundle of Vials
23569	Letter from the Mag'har
23570	Jom Gabbar
23571	Primal Might
23572	Primal Nether
23573	Hardened Adamantite Bar
23574	Recipe: Transmute Primal Might
23575	Lesser Ward of Shielding
23576	Greater Ward of Shielding
23577	The Hungering Cold
23578	Diet McWeaksauce
23579	The McWeaksauce Classic
23580	Avruu's Orb
23584	Loch Modan Lager
23585	Stouthammer Lite
23586	Aerie Peak Pale Ale
23587	Mirren's Drinking Hat
23588	Kaliri Feather
23589	Mag'har Ancestral Beads
23590	Plans: Adamantite Maul
23591	Plans: Adamantite Cleaver
23592	Plans: Adamantite Dagger
23593	Plans: Adamantite Rapier
23594	Plans: Adamantite Plate Bracers
23595	Plans: Adamantite Plate Gloves
23596	Plans: Adamantite Breastplate
23597	Plans: Enchanted Adamantite Belt
23598	Plans: Enchanted Adamantite Boots
23599	Plans: Enchanted Adamantite Breastplate
23600	Plans: Enchanted Adamantite Leggings
23601	Plans: Flamebane Bracers
23602	Plans: Flamebane Helm
23603	Plans: Flamebane Gloves
23604	Plans: Flamebane Breastplate
23605	Plans: Felsteel Gloves
23606	Plans: Felsteel Leggings
23607	Plans: Felsteel Helm
23608	Plans: Khorium Belt
23609	Plans: Khorium Pants
23610	Plans: Khorium Boots
23611	Plans: Ragesteel Gloves
23612	Plans: Ragesteel Helm
23613	Plans: Ragesteel Breastplate
23614	Red Snapper
23615	Plans: Swiftsteel Gloves
23616	Crushed Crystal Fragment
23617	Plans: Earthpeace Breastplate
23618	Plans: Adamantite Sharpening Stone
23619	Plans: Felsteel Shield Spike
23620	Plans: Felfury Gauntlets
23621	Plans: Gauntlets of the Iron Tower
23622	Plans: Steelgrip Gauntlets
23623	Plans: Storm Helm
23624	Plans: Helm of the Stalwart Defender
23625	Plans: Oathkeeper's Helm
23626	Plans: Black Felsteel Bracers
23627	Plans: Bracers of the Green Fortress
23628	Plans: Blessed Bracers
23629	Plans: Felsteel Longblade
23630	Plans: Khorium Champion
23631	Plans: Fel Edged Battleaxe
23632	Plans: Felsteel Reaper
23633	Plans: Runic Hammer
23634	Plans: Fel Hardened Maul
23635	Plans: Eternium Runed Blade
23636	Plans: Dirge
23637	Plans: Hand of Eternity
23638	Plans: Lesser Ward of Shielding
23639	Plans: Greater Ward of Shielding
23642	Sha'naar Relic
23643	Purifying Earth
23644	Crate of Reagents
23645	Seer's Relic
23646	Shipment of Rare Crystals
23654	Draenei Fishing Net
23655	Elven Manacles
23657	Dawn Runner Cargo
23658	Advisor's Pack
23659	Fel-Tainted Morsels
23660	Advisor's Rapier
23661	Mark of the Lightbringer
23662	Letter from Nazgrel
23663	Girdle of Elemental Fury
23664	Pauldrons of Elemental Fury
23665	Leggings of Elemental Fury
23666	Belt of the Grand Crusader
23667	Spaulders of the Grand Crusader
23668	Leggings of the Grand Crusader
23669	Ancestral Spirit Wolf Totem
23670	Thalanaar Moonwell Water
23671	Earth Crystal
23672	Crate of Red Snapper
23675	Robotron Control Unit
23676	Moongraze Stag Tenderloin
23677	Moongraze Buck Hide
23678	Faintly Glowing Crystal
23679	Bloodscalp Totem
23680	Gift of Naias
23681	Heart of Naias
23682	Ritual Torch
23685	Root Trapper Vine
23686	Lacy Handkerchief
23687	Blacktalon's Claws
23688	Hauteur's Ashes
23691	Corrupted Mark of the Lightbringer
23692	Azure Snapdragon Bulb
23693	Carinda's Scroll of Retribution
23694	Gryphon Egg
23695	Featherbeard's Map
23697	Taming Rod
23702	Taming Rod
23703	Taming Rod
23704	Eversong Port
23705	Tabard of Flame
23706	Arcane Fragment
23707	Spindleweb Silk Gland
23709	Tabard of Frost
23710	Upperdeck Tabard #3
23711	Grimoire of Intercept (Rank 1)
23712	White Tiger Cub
23713	Hippogryph Hatchling
23714	Perpetual Purple Firework
23715	Permanent Lung Juice Cocktail
23716	Carved Ogre Idol
23717	Pitted Gold Band
23718	Permanent Ground Scorpok Assay
23719	Permanent Cerebral Cortex Compound
23720	Riding Turtle
23721	Permanent Gizzard Gum
23722	Permanent R.O.I.D.S.
23723	Warchief Kargath's Fist
23726	Fel Ember
23729	Fel Horde Banner
23730	Grimoire of Intercept (Rank 2)
23731	Grimoire of Intercept (Rank 3)
23732	Voidstone
23733	Ritual Torch
23734	Grimoire of Cleave (Rank 1)
23735	Grand Warlock's Amulet
23736	Fel Iron Bomb
23737	Adamantite Grenade
23738	Nautical Compass
23739	Nautical Map
23740	Top Secret Venture Company Plans
23742	Fel Iron Musket
23744	Foul Essence
23745	Grimoire of Cleave (Rank 2)
23746	Adamantite Rifle
23747	Felsteel Boomstick
23748	Ornate Khorium Rifle
23749	Empty Bota Bag
23750	Filled Bota Bag
23751	Skin of Purest Water
23752	Flask of Purest Water
23753	Drycap Mushroom
23754	Bristlehide Clefthoof Hide
23755	Grimoire of Cleave (Rank 3)
23756	Cookie's Jumbo Gumbo
23757	Skittering Crawler Meat
23758	Cogspinner Goggles
23759	Rune Covered Tablet
23760	Chalice of Elune
23761	Power Amplification Goggles
23762	Ultra-Spectropic Detection Goggles
23763	Hyper-Vision Goggles
23764	Adamantite Scope
23765	Khorium Scope
23766	Stabilized Eternium Scope
23767	Crashin' Thrashin' Robot
23768	White Smoke Flare
23769	Red Smoke Flare
23770	Blue Smoke Flare
23771	Green Smoke Flare
23772	Fel Iron Shells
23773	Adamantite Shells
23774	Fel Iron Toolbox
23775	Titanium Toolbox
23776	Warsong Lumber
23777	Diabolical Plans
23778	Sentinel Luciel's Report
23779	Ancient Relic
23780	Diabolical Plans
23781	Elemental Blasting Powder
23782	Fel Iron Casing
23783	Handful of Fel Iron Bolts
23784	Adamantite Frame
23785	Hardened Adamantite Tube
23786	Khorium Power Core
23787	Felsteel Stabilizer
23788	Tree Seedlings
23789	Remains of Cowlen's Family
23790	Hollowed Out Tree
23791	Pile of Leaves
23792	Tree Disguise Kit
23793	Heavy Knothide Leather
23794	Permanent Sheen of Zanza
23795	Permanent Spirit of Zanza
23796	Permanent Swiftness of Zanza
23797	Diabolical Plans
23798	Diabolical Plans
23799	Schematic: Adamantite Rifle
23800	Schematic: Felsteel Boomstick
23801	Bristlelimb Key
23802	Schematic: Ornate Khorium Rifle
23803	Schematic: Cogspinner Goggles
23804	Schematic: Power Amplification Goggles
23805	Schematic: Ultra-Spectropic Detection Goggles
23806	Schematic: Hyper-Vision Goggles
23807	Schematic: Adamantite Scope
23808	Schematic: Khorium Scope
23809	Schematic: Stabilized Eternium Scope
23810	Schematic: Crashin' Thrashin' Robot
23811	Schematic: White Smoke Flare
23812	Schematic: Red Smoke Flare
23813	Schematic: Blue Smoke Flare
23814	Schematic: Green Smoke Flare
23815	Schematic: Adamantite Shell Machine
23816	Schematic: Fel Iron Toolbox
23817	Schematic: Titanium Toolbox
23818	Stillpine Furbolg Language Primer
23819	Elemental Seaforium Charge
23820	Critter Enlarger
23821	Zapthrottle Mote Extractor
23822	Healing Potion Injector
23823	Mana Potion Injector
23824	Rocket Boots Xtreme
23825	Nigh Invulnerability Belt
23826	The Bigger One
23827	Super Sapper Charge
23828	Gnomish Power Goggles
23829	Gnomish Battle Goggles
23830	Clopper's Equipment
23831	Goblin Tonk Controller
23832	Gnomish Tonk Controller
23833	Crude Murloc Knife
23834	Crude Murloc Idol
23835	Gnomish Poultryizer
23836	Goblin Rocket Launcher
23837	Weathered Treasure Map
23838	Foreman's Enchanted Helmet
23839	Foreman's Reinforced Helmet
23840	Remote Mail Terminal
23841	Gnomish Flame Turret
23843	Whorl of Air
23844	Nolkai's Lantern
23845	Ravager Hide
23846	Nolkai's Box
23847	Nolkai's Band
23848	Nethergarde Bitter
23849	Stillpine Grain
23850	Gurf's Dignity
23851	Battered Journal
23852	Nolkai's Bag
23853	Letter to <Name>
23854	Shadoweave Cloth
23855	Spellfire Cloth
23857	Legacy of the Mountain King
23858	Singed Page
23859	Nazzivus Monument Glyph
23860	The Kurken's Hide
23861	Drawing Kit
23862	Redemption of the Fallen
23863	Corrupted Crystal
23864	Torment of the Worgen
23865	Wrath of the Titans
23866	Singed Page
23867	Singed Page
23868	Singed Page
23869	Crystallized Bark
23870	Red Crystal Pendant
23871	Potion of Water Breathing
23872	Blue Satchel
23873	Galaen's Amulet
23874	Schematic: Elemental Seaforium Charge
23875	Crystal Mining Pick
23876	Crystal Mining Pick
23877	Crystal Mining Pick
23878	Impact Site Crystal Sample
23879	Altered Crystal Sample
23880	Axxarien Crystal Sample
23881	Gargolmar's Hand
23882	Schematic: Critter Enlarger
23883	Schematic: Healing Potion Injector
23884	Schematic: Mana Potion Injector
23885	Schematic: Remote Mail Terminal
23886	Omor's Hoof
23887	Schematic: Rocket Boots Xtreme
23888	Schematic: Zapthrottle Mote Extractor
23890	Ominous Letter
23891	Ominous Letter
23892	Ominous Letter
23893	Ominous Letter
23894	Fel Orc Blood Vial
23895	Netted Goods
23896	Taming Totem
23897	Taming Totem
23898	Taming Totem
23899	Traitor's Communication
23900	Tzerak's Armor Plate
23901	Nazan's Head
23902	Topher's List
23903	Nurguni's Supplies
23904	Shattered Blade
23909	Blood Elf Bandit Mask
23910	Blood Elf Communication
23919	Stack of Reports
23920	Tattered Handkerchief
23921	Bulging Sack of Silver
23922	Rat Skeleton
23923	Amani Sacrificial Dagger
23924	Robes of Silvermoon
23925	Ravager Cage Key
23926	Tome of Divinity
23927	Sand Pear
23928	The Exarch's Orders
23929	Letter from Lor'themar Theron
23930	Letter Sealed by Sylvanas
23931	Azure Watch Robes
23932	Survey Data Crystal
23933	Medivh's Journal
23934	Medivh's Journal
23937	Letter of Introduction
23938	Pristine Ravager Carapace
23939	Pristine Ravager Claw
23940	Pristine Ravager Fang
23941	Crushed Ravager Carapace
23942	Crushed Ravager Fang
23943	Crushed Ravager Claw
23944	Broken Ravager Carapace
23945	Broken Ravager Fang
23946	Broken Ravager Claw
23947	Cracked Ravager Carapace
23948	Cracked Ravager Fang
23949	Cracked Ravager Claw
23950	Damaged Ravager Carapace
23951	Damaged Ravager Fang
23952	Damaged Ravager Claw
23953	Worn Ravager Carapace
23954	Worn Ravager Fang
23955	Worn Ravager Claw
23957	Weathered Ravager Carapace
23958	Weathered Ravager Fang
23959	Weathered Ravager Claw
23960	Beaten Ravager Carapace
23961	Beaten Ravager Fang
23962	Beaten Ravager Claw
23965	Chipped Ravager Claw
23966	Flawed Ravager Carapace
23967	Flawed Ravager Fang
23968	Flawed Ravager Claw
23969	Imperfect Ravager Carapace
23970	Imperfect Ravager Fang
23971	Imperfect Ravager Claw
23972	Mangled Ravager Carapace
23973	Mangled Ravager Fang
23974	Mangled Ravager Claw
23975	Damaged Ravager Fang
23976	Gnarled Ravager Carapace
23977	Gnarled Ravager Fang
23978	Gnarled Ravager Claw
23979	Chipped Ravager Carapace
23980	Chipped Ravager Fang
23981	Steam Pump Part
23982	Kessel's Whistle
23983	Shadowbat Blood
23984	Irradiated Crystal Shard
23985	Crystal of Vitality
23986	Crystal of Insight
23987	Mutated Petal
23988	Mutated Vine
23989	Crystal of Ferocity
23990	Completed Star Chart
23992	Torn Saurian Pelt
23993	Cracked Saurian Claw
23994	Thorny Constrictor Vine
23995	Murloc Tagger
23997	Head of Tel'athion
23999	Honor Hold Tabard
24000	Formula: Enchant Bracer - Superior Healing
24001	Recipe: Elixir of Major Agility
24002	Plans: Felsteel Shield Spike
24003	Formula: Enchant Chest - Exceptional Stats
24004	Thrallmar Tabard
24005	Murloc Tag Stub
24006	Grunt's Waterskin
24007	Footman's Waterskin
24008	Dried Mushroom Rations
24009	Dried Fruit Rations
24020	Shadowrend Longblade
24021	Light-Touched Breastplate
24022	Scale Leggings of the Skirmisher
24023	Bracers of Finesse
24024	Pauldrons of Arcane Rage
24025	Deathclaw's Paw
24026	Elder Brown Bear Flank
24027	Bold Living Ruby
24028	Delicate Living Ruby
24029	Teardrop Living Ruby
24030	Runed Living Ruby
24031	Bright Living Ruby
24032	Subtle Living Ruby
24033	Solid Star of Elune
24035	Sparkling Star of Elune
24036	Flashing Living Ruby
24037	Lustrous Star of Elune
24039	Stormy Star of Elune
24040	Blood Mushroom
24041	Aquatic Stinkhorn
24042	Ruinous Polyspore
24043	Fel Cone Fungus
24044	Hellreaver
24045	Band of Renewal
24046	Kilt of Rolling Thunders
24047	Brilliant Dawnstone
24048	Smooth Dawnstone
24049	Ysera's Tear
24050	Gleaming Dawnstone
24051	Rigid Dawnstone
24052	Thick Dawnstone
24053	Mystic Dawnstone
24054	Sovereign Nightseye
24055	Shifting Nightseye
24056	Glowing Nightseye
24057	Royal Nightseye
24058	Inscribed Noble Topaz
24059	Potent Noble Topaz
24060	Luminous Noble Topaz
24061	Glinting Noble Topaz
24062	Enduring Talasite
24063	Shifting Sash of Midnight
24064	Ironsole Clompers
24065	Dazzling Talasite
24066	Radiant Talasite
24067	Jagged Talasite
24068	Arcane Residue
24069	Crystalfire Staff
24071	Bland Dagger
24072	Sand Pear Pie
24073	Garrote-String Necklace
24074	Fel Iron Blood Ring
24075	Golden Draenite Ring
24076	Azure Moonstone Ring
24077	Thick Adamantite Necklace
24078	Heavy Adamantite Ring
24079	Khorium Band of Shadows
24080	Khorium Band of Frost
24081	Satyrnaar Fel Wood
24082	Khorium Inferno Band
24083	Lifegiver Britches
24084	Draenei Banner
24085	Khorium Band of Leaves
24086	Arcane Khorium Band
24087	Heavy Felsteel Ring
24088	Delicate Eternium Ring
24089	Blazing Eternium Band
24090	Bloodstained Ravager Gauntlets
24091	Tenacious Defender
24092	Pendant of Frozen Flame
24093	Pendant of Thawing
24094	Heart Fire Warhammer
24095	Pendant of Withering
24096	Heartblood Prayer Beads
24097	Pendant of Shadow's End
24098	Pendant of the Null Rune
24099	The High Chief's Key
24100	Warder's Dagger
24101	Book of Ferocious Bite V
24102	Manual of Eviscerate IX
24103	Moongraze Hide Boots
24104	Moongraze Fur Cloak
24105	Roasted Moongraze Tenderloin
24106	Thick Felsteel Necklace
24107	Ravager Chitin Tunic
24108	Ravager Hide Leggings
24109	Thick Ravager Belt
24110	Living Ruby Pendant
24111	Kurken Hide Jerkin
24112	Kurkenstoks
24113	Cowlen's Bracers of Kinship
24114	Braided Eternium Chain
24115	TestProspectIronOre
24116	Eye of the Night
24117	Embrace of the Dawn
24118	Signet of Argas
24119	Band of Argas
24120	Seal of Argas
24121	Chain of the Twilight Owl
24122	Coronet of Verdant Flame
24123	Circlet of Arcane Might
24124	Figurine - Felsteel Boar
24125	Figurine - Dawnstone Crab
24126	Figurine - Living Ruby Serpent
24127	Figurine - Talasite Owl
24128	Figurine - Nightseye Panther
24129	Salvaged Leather Belt
24130	Worn Slippers
24131	Slightly Rusted Bracers
24132	A Letter from the Admiral
24133	Weathered Mail Tunic
24134	Weathered Leather Vest
24135	Weathered Cloth Armor
24136	Farstrider's Bow
24138	Silver Crossbow
24139	Faint Arcane Essence
24140	Blackened Urn
24141	Battle Worn Gauntlets
24142	Battle Worn Gloves
24143	Initiate's Shirt
24144	Battle Worn Handguards
24145	Initiate's Pants
24146	Initiate's Boots
24147	Unprepared Star Chart
24148	Partial Star Chart
24149	Unfinished Star Chart
24150	Mok'Nathal Wildercloak
24151	Mok'Nathal Clan Ring
24152	Charred Bone Fragment
24153	Bloodcursed Soul
24154	Witching Band
24155	Ursol's Claw
24156	Filled Shimmering Vessel
24157	Shimmering Vessel
24158	Design: Khorium Band of Shadows
24159	Design: Khorium Band of Frost
24160	Design: Khorium Inferno Band
24161	Design: Khorium Band of Leaves
24162	Design: Arcane Khorium Band
24163	Design: Heavy Felsteel Ring
24164	Design: Delicate Eternium Ring
24165	Design: Blazing Eternium Band
24166	Design: Thick Felsteel Necklace
24167	Design: Living Ruby Pendant
24168	Design: Braided Eternium Chain
24169	Design: Eye of the Night
24170	Design: Embrace of the Dawn
24171	Design: Chain of the Twilight Owl
24172	Design: Coronet of Verdant Flame
24173	Design: Circlet of Arcane Might
24174	Design: Pendant of Frozen Flame
24175	Design: Pendant of Thawing
24176	Design: Pendant of Withering
24177	Design: Pendant of Shadow's End
24178	Design: Pendant of the Null Rune
24179	Design: Felsteel Boar
24180	Design: Dawnstone Crab
24181	Design: Living Ruby Serpent
24182	Design: Talasite Owl
24183	Design: Nightseye Panther
24184	Filled Shimmering Vessel
24185	Dragon Bone
24186	Copper Powder
24187	Shiny Rock
24188	Tin Powder
24189	Crystalline Fragments
24190	Iron Powder
24191	Small Gem Shards
24192	Design: Bright Living Ruby
24193	Design: Bold Living Ruby
24194	Design: Delicate Living Ruby
24195	Design: Teardrop Living Ruby
24196	Design: Runed Living Ruby
24197	Design: Subtle Living Ruby
24198	Design: Flashing Living Ruby
24199	Design: Solid Star of Elune
24200	Design: Sparkling Star of Elune
24201	Design: Lustrous Star of Elune
24202	Design: Stormy Star of Elune
24203	Design: Brilliant Dawnstone
24204	Design: Smooth Dawnstone
24205	Design: Rigid Dawnstone
24206	Design: Gleaming Dawnstone
24207	Design: Thick Dawnstone
24208	Design: Mystic Dawnstone
24209	Design: Sovereign Nightseye
24210	Design: Shifting Nightseye
24211	Design: Glowing Nightseye
24212	Design: Royal Nightseye
24213	Design: Inscribed Noble Topaz
24214	Design: Potent Noble Topaz
24215	Design: Luminous Noble Topaz
24216	Design: Glinting Noble Topaz
24217	Design: Enduring Talasite
24218	Design: Radiant Talasite
24219	Design: Dazzling Talasite
24220	Design: Jagged Talasite
24221	Bundle of Dragon Bones
24222	The Shadowfoot Stabber
24223	Bloodvalor's Notes
24224	Crate of Bloodforged Ingots
24225	Blood of the Wrathful
24226	Blood Knight Insignia
24227	Soft Leather Belt
24228	The Sun King's Command
24230	Velen's Orders
24231	Coarse Snuff
24232	Shabby Knot
24233	Discarded Nutriment
24234	Mithril Powder
24235	Thorium Powder
24236	Medical Supplies
24237	Galaen's Journal
24238	Mushroom Sample
24239	Crate of Materials
24240	Box of Mushrooms
24241	Green Chain Belt
24242	Fel Iron Powder
24243	Adamantite Powder
24245	Glowcap
24246	Sanguine Hibiscus
24247	Underspore Frond
24248	Brain of the Black Stalker
24249	Unyielding Bracers
24250	Bracers of Havok
24251	Blackstrike Bracers
24252	Cloak of the Black Void
24253	Cloak of Eternity
24254	White Remedy Cape
24255	Unyielding Girdle
24256	Girdle of Ruination
24257	Black Belt of Knowledge
24258	Resolute Cape
24259	Vengeance Wrap
24260	Manaweave Cloak
24261	Whitemend Pants
24262	Spellstrike Pants
24263	Battlecast Pants
24264	Whitemend Hood
24266	Spellstrike Hood
24267	Battlecast Hood
24268	Netherweave Net
24269	Netherweave Net
24270	Bag of Jewels
24271	Spellcloth
24272	Shadowcloth
24273	Mystic Spellthread
24274	Runic Spellthread
24275	Silver Spellthread
24276	Golden Spellthread
24277	Items for Magister Astalor Bloodsworn
24278	Flare Gun
24279	Vicious Teromoth Sample
24280	Naga Claws
24281	Carved Ivory Bone
24282	Rogue's Diary
24283	An Antique Gun
24284	Tyr's Hand Holy Water
24285	Crepuscular Powder
24286	Arcane Catalyst
24287	Extinguishing Mixture
24288	Rune Thread
24289	Chrono-beacon
24290	Mature Spore Sac
24291	Bog Lord Tendril
24292	Pattern: Mystic Spellthread
24293	Pattern: Silver Spellthread
24294	Pattern: Runic Spellthread
24295	Pattern: Golden Spellthread
24296	Pattern: Unyielding Bracers
24297	Pattern: Bracers of Havok
24298	Pattern: Blackstrike Bracers
24299	Pattern: Cloak of the Black Void
24300	Pattern: Cloak of Eternity
24301	Pattern: White Remedy Cape
24302	Pattern: Unyielding Girdle
24303	Pattern: Girdle of Ruination
24304	Pattern: Black Belt of Knowledge
24305	Pattern: Resolute Cape
24306	Pattern: Vengeance Wrap
24307	Pattern: Manaweave Cloak
24308	Pattern: Whitemend Pants
24309	Pattern: Spellstrike Pants
24310	Pattern: Battlecast Pants
24311	Pattern: Whitemend Hood
24312	Pattern: Spellstrike Hood
24313	Pattern: Battlecast Hood
24314	Pattern: Bag of Jewels
24315	Pattern: Heavy Netherweave Net
24316	Pattern: Spellcloth
24317	Bloodmyst Water Sample
24318	Water Sample Flask
24323	Translated Sunhawk Missive
24330	Drain Schematics
24334	Wheel of the Lost Hope
24335	Orb of Returning
24336	Fireproof Satchel
24337	Deactivating Jewel
24338	Hellfire Spineleaf
24339	Stung
24340	Vandril's Hand Me Down Pants
24341	Fortified Oven Mitts
24342	Stillpine Shocker
24343	The Thumper
24344	Tabard of the Hand
24345	Book of Cower IV
24346	Robe of the Dragon Slayer
24347	Vest of the Dragon Slayer
24348	Tunic of the Dragon Slayer
24349	Signet Ring of the Hand
24350	Signet Ring of the Hand
24351	Mace of the Hand
24352	Blade of the Hand
24353	Crossbow of the Hand
24354	Staff of the Hand
24355	Ironvine Seeds
24356	Wastewalker Shiv
24357	Vest of Living Lightning
24359	Princely Reign Leggings
24360	Tracker's Belt
24361	Spellfire Longsword
24362	Spore-Soaked Vaneer
24363	Unscarred Breastplate
24364	Azureplate Greaves
24365	Deft Handguards
24366	Scorpid-Sting Mantle
24367	Orders from Lady Vashj
24368	Coilfang Armaments
24369	Coilfang Spellbook
24372	Diaphanous Wing
24373	Scout Jyoba's Report
24374	Eel Filet
24375	Thick Hydra Scale
24376	Runed Fungalcap
24378	Coilfang Hammer of Renewal
24379	Bogstrok Scale Cloak
24380	Calming Spore Reed
24381	Coilfang Needler
24382	Zurai's Report
24383	Fulgor Spore
24384	Diamond-Core Sledgemace
24385	Pendant of Battle-Lust
24386	Libram of Saints Departed
24387	Ironblade Gauntlets
24388	Girdle of the Gale Storm
24389	Legion Blunderbuss
24390	Auslese's Light Channeler
24391	Kilt of the Night Strider
24392	Arcing Bracers
24393	Bloody Surgeon's Mitts
24394	Warsong Howling Axe
24395	Mindfire Waistband
24396	Vest of Vengeance
24397	Raiments of Divine Authority
24398	Mantle of the Dusk-Dweller
24399	Sunhawk Missive
24400	Dead Mire Soil Sample
24401	Unidentified Plant Parts
24402	Package of Identified Plants
24403	Common Fern
24404	Ruined Specimen
24405	Common Azerothian Species
24406	Common Flower
24407	Uncatalogued Species
24408	Edible Stalks
24411	Ikeyen's Belongings
24412	Warden's Arrow
24413	Totem of the Thunderhead
24414	Blood Elf Plans
24415	Vindicator Idaar's Letter
24416	Corrupted Flower
24417	Scout's Arrow
24419	Digested Caracoli
24421	Nagrand Cherry
24422	Feralfen Idol
24423	Beaten Chain Leggings
24424	Rough Leather Leggings
24425	Hand Sewn Pants
24426	Spore Bat Eye
24427	Fen Strider Tentacle
24428	Ahuurn's Elixir
24429	Expedition Flare
24430	Seafarer's Blade
24431	McWeaksauce's Meat Tenderizer
24432	The Shell Cracker
24433	Crossbow of the Albatross
24434	The Discipline Stick
24435	Reinforced Mail Boots
24436	Huntsman's Bracers
24437	Slightly Worn Bracer
24438	Fur Covered Robe
24439	Savage Leggings
24440	Heavy Chain Leggings
24441	Exodar Crossbow
24442	Mail Belt of the Silverpine
24443	Bracers of Shed Fur
24444	Newly Weaved Pants
24445	Fortified Wristguards
24446	Sturdy Leather Belt
24447	Naga Scale Boots
24448	Battle Tested Blade
24449	Fertile Spores
24450	Manaspark Gloves
24451	Lykul Bloodbands
24452	Starlight Gauntlets
24453	Zangartooth Shortblade
24454	Cloak of Enduring Swiftness
24455	Tunic of the Nightwatcher
24456	Greaves of the Iron Guardian
24457	Truth Bearer Shoulderguards
24458	Studded Girdle of Virtue
24459	Cloak of Healing Rays
24460	Talisman of Tenacity
24461	Hatebringer
24462	Luminous Pearls of Insight
24463	Pauldrons of Brute Force
24464	The Stalker's Fangs
24465	Shamblehide Chestguard
24466	Skulldugger's Leggings
24467	Living Fire
24468	Burstcap Mushroom
24469	Muck-ridden Core
24470	Murloc Cage
24471	Ango'rosh Attack Plans
24472	Boss Grog'ak's Head
24473	Enraged Crusher Core
24474	Violet Scrying Crystal
24475	Gordawg's Imprint
24476	Jaggal Clam
24477	Jaggal Clam Meat
24478	Jaggal Pearl
24479	Shadow Pearl
24480	Ghostly Essence
24481	Robes of the Augurer
24482	Alturus's Report
24483	Withered Basidium
24484	Withered Basidium
24485	Marshlight Bleeder Venom
24486	Fenclaw Hide
24487	Second Key Fragment
24488	Third Key Fragment
24489	Restored Apprentice's Key
24490	The Master's Key
24491	Cannonball
24492	Keanna's Log
24493	Marshfang Slicer Blade
24494	Tears of the Goddess
24496	Horn of Banthar
24497	Feralfen Protection Totem
24498	Feralfen Totem
24499	Daggerfen Poison Manual
24500	Daggerfen Poison Vial
24501	Gordawg's Boulder
24502	Warmaul Skull
24503	Gurok's Earthen Head
24504	Howling Wind
24505	Heart of Tusker
24506	Elemental Sliver
24507	Elemental Shard
24508	Elemental Fragment
24509	Primordial Element
24510	Primordial Core
24511	Primordial Essence
24513	Eye of Gutripper
24514	First Key Fragment
24515	Mangy Mane
24516	Damaged Rock Flayer Talon
24517	Blood Soaked Tail
24518	Coarse Mane
24519	Twisted Rock Flayer Talon
24520	Honor Hold Favor
24521	Mangled Tail
24522	Thrallmar Favor
24523	Hoof of Bach'lor
24538	Fire Bomb
24539	Marsh Lichen
24540	Edible Fern
24541	Medicinal Swamp Moss
24542	Murkblood Idol
24543	Head of Ortor of Murkblood
24544	Gladiator's Plate Chestpiece
24545	Gladiator's Plate Helm
24546	Gladiator's Plate Shoulders
24547	Gladiator's Plate Legguards
24549	Gladiator's Plate Gauntlets
24550	Gladiator's Greatsword
24551	Talisman of the Horde
24552	Gladiator's Dreadweave Robe
24553	Gladiator's Dreadweave Hood
24554	Gladiator's Dreadweave Mantle
24555	Gladiator's Dreadweave Leggings
24556	Gladiator's Dreadweave Gloves
24557	Gladiator's War Staff
24558	Murkblood Invasion Plans
24559	Murkblood Invasion Plans
24560	Torch of Liquid Fire
24573	Elder Kuruti's Response
24575	Outlander's Girdle
24576	Loosely Threaded Belt
24577	Loosely Threaded Boots
24578	Loosely Threaded Bracers
24579	Mark of Honor Hold
24580	Loosely Threaded Hat
24581	Mark of Thrallmar
24582	Outlander's Boots
24583	Outlander's Tunic
24584	Outlander's Gloves
24585	Outlander's Facewrap
24586	Outlander's Leggings
24587	Outlander's Pauldrons
24588	Outlander's Bracers
24589	Fireheart Girdle
24590	Fireheart Boots
24591	Fireheart Chestpiece
24592	Fireheart Gloves
24593	Fireheart Skullcap
24594	Fireheart Leggings
24595	Fireheart Shoulderpads
24596	Fireheart Bracers
24597	Starfire Sash
24598	Starfire Sandals
24599	Starfire Vest
24600	Starfire Gloves
24601	Starfire Circlet
24602	Starfire Trousers
24603	Starfire Mantle
24604	Starfire Wristwraps
24605	Laughing Skull Waistguard
24606	Laughing Skull Boot
24607	Laughing Skull Tunic
24608	Laughing Skull Gloves
24609	Laughing Skull Cap
24610	Laughing Skull Pants
24611	Laughing Skull Shoulderpads
24612	Laughing Skull Bracelets
24613	Vindicator Belt
24614	Vindicator Boots
24615	Vindicator Tunic
24616	Vindicator Gloves
24617	Vindicator Cap
24618	Vindicator Pants
24619	Vindicator Shoulderpads
24620	Vindicator Bracers
24621	Slavehandler Belt
24622	Slavehandler Footpads
24623	Slavehandler Jerkin
24624	Slavehandler Handwraps
24625	Slavehandler Cap
24626	Slavehandler Pants
24627	Slavehandler Amice
24628	Slavehandler Wristguards
24629	Feralfen Sash
24630	Feralfen Sandals
24631	Feralfen Jerkin
24632	Feralfen Hand
24633	Feralfen Hood
24634	Feralfen Pants
24635	Feralfen Amice
24636	Feralfen Cuffs
24637	Mistyreed Belt
24638	Mistyreed Boot
24639	Mistyreed Tunic
24640	Mistyreed Gloves
24641	Mistyreed Hood
24642	Mistyreed Pants
24643	Mistyreed Shoulderpads
24644	Mistyreed Bracer
24645	Astralaan Belt
24646	Astralaan Boots
24647	Astralaan Robe
24648	Astralaan Gloves
24649	Astralaan Headdress
24650	Astralaan Pants
24651	Astralaan Shoulderpads
24652	Astralaan Bracer
24653	Consortium Sash
24654	Consortium Boot
24655	Consortium Robe
24656	Consortium Gloves
24657	Consortium Hood
24658	Consortium Pants
24659	Consortium Mantle
24660	Consortium Bracer
24661	Shadow Council Chain
24662	Shadow Council Boots
24663	Shadow Council Tunic
24664	Shadow Council Gloves
24665	Shadow Council Cowl
24666	Shadow Council Pants
24667	Shadow Council Mantle
24668	Shadow Council Bracer
24669	Eldr'naan Belt
24670	Eldr'naan Boot
24671	Eldr'naan Jerkin
24672	Eldr'naan Gloves
24673	Eldr'naan Hood
24674	Eldr'naan Pants
24675	Eldr'naan Shoulderpads
24676	Eldr'naan Bracelets
24677	Archmage Belt
24678	Archmage Slippers
24679	Archmage Robe
24680	Archmage Gloves
24681	Archmage Headpiece
24682	Archmage Pants
24683	Archmage Mantle
24684	Archmage Bracelets
24685	Elementalist Belt
24686	Elementalist Boots
24687	Elementalist Tunic
24688	Elementalist Gloves
24689	Elementalist Skullcap
24690	Elementalist Leggings
24691	Elementalist Mantle
24692	Elementalist Bracelets
24693	Bonechewer Pelt-Girdle
24694	Bonechewer Shredboots
24695	Bonechewer Chestpiece
24696	Bonechewer Spikegloves
24697	Bonechewer Skincloak
24698	Bonechewer Ripleggings
24699	Bonechewer Shoulderguards
24700	Bonechewer Bands
24701	Haal'eshi Cord
24702	Haal'eshi Boots
24703	Haal'eshi Jerkin
24704	Haal'eshi Gloves
24705	Haal'eshi Hat
24706	Haal'eshi Leggings
24707	Haal'eshi Pauldrons
24708	Haal'eshi Bindings
24709	Vengeance Belt
24710	Vengeance Boots
24711	Vengeance Chestpiece
24712	Vengeance Gloves
24713	Vengeance Helm
24714	Vengeance Legguards
24715	Vengeance Pauldrons
24716	Vengeance Bands
24717	Dreghood Belt
24718	Dreghood Boots
24719	Dreghood Chestpiece
24720	Dreghood Gloves
24721	Dreghood Cowl
24722	Dreghood Trousers
24723	Dreghood Pauldrons
24724	Dreghood Bands
24725	Dementia Cord
24726	Dementia Boots
24727	Dementia Vest
24728	Dementia Gloves
24729	Dementia Hood
24730	Dementia Trousers
24731	Dementia Shoulderguards
24732	Dementia Armguards
24733	Sunroc Waistband
24734	Sunroc Boots
24735	Sunroc Chestpiece
24736	Sunroc Gloves
24737	Sunroc Mask
24738	Sunroc Pants
24739	Sunroc Shoulderguards
24740	Sunroc Armguards
24741	Ranger Belt
24742	Ranger Boots
24743	Ranger Jerkin
24744	Ranger Gloves
24745	Ranger Hat
24746	Ranger Pants
24747	Ranger Pauldrons
24748	Ranger Armguards
24749	Daggerfen Belt
24750	Daggerfen Boots
24751	Daggerfen Battlevest
24752	Daggerfen Gloves
24753	Daggerfen Cowl
24754	Daggerfen Stitchpants
24755	Daggerfen Pauldrons
24756	Daggerfen Bindings
24757	Umbrafen Waistband
24758	Umbrafen Boots
24759	Umbrafen Tunic
24760	Umbrafen Gloves
24761	Umbrafen Cap
24762	Umbrafen Britches
24763	Umbrafen Shoulderguards
24764	Umbrafen Bindings
24765	Clefthoof Belt
24766	Clefthoof Wanderboots
24767	Clefthoof Hidemantle
24768	Clefthoof Gloves
24769	Clefthoof Cover
24770	Clefthoof Britches
24771	Clefthoof Shoulderguards
24772	Clefthoof Bracers
24773	Boneshredder Belt
24774	Boneshredder Boots
24775	Boneshredder Jerkin
24776	Boneshredder Gloves
24777	Boneshredder Skullcap
24778	Boneshredder Britches
24779	Boneshredder Shoulderguards
24780	Boneshredder Wristguards
24781	Murkblood Belt
24782	Loosely Threaded Gloves
24783	Murkblood Boots
24784	Murkblood Chestpiece
24785	Murkblood Gloves
24786	Murkblood Cover
24787	Murkblood Pants
24788	Murkblood Shoulderguards
24789	Murkblood Bracers
24790	Expedition Girdle
24791	Expedition Boots
24792	Expedition Tunic
24793	Expedition Gloves
24794	Expedition Hood
24795	Expedition Pants
24796	Expedition Shoulderguards
24797	Expedition Bracers
24798	Dragonhawk Belt
24799	Dragonhawk Boots
24800	Dragonhawk Tunic
24801	Dragonhawk Gloves
24802	Dragonhawk Hat
24803	Dragonhawk Pants
24804	Dragonhawk Shoulderguards
24805	Dragonhawk Bands
24806	Unyielding Waistband
24807	Unyielding Footwraps
24808	Unyielding Chain Vest
24809	Unyielding Fists
24810	Unyielding Helm
24811	Unyielding Leggings
24812	Unyielding Spaulders
24813	Unyielding Bindings
24814	Felstone Waistband
24815	Felstone Greaves
24816	Felstone Chain Vest
24817	Felstone Gauntlets
24818	Felstone Helm
24819	Felstone Leggings
24820	Felstone Spaulders
24821	Felstone Bindings
24822	Netherstalker Belt
24823	Netherstalker Greaves
24824	Netherstalker Armor
24825	Netherstalker Gloves
24826	Netherstalker Helmet
24827	Netherstalker Legguards
24828	Netherstalker Mantle
24829	Netherstalker Bracer
24830	Nexus-Strider Belt
24831	Nexus-Strider Greaves
24832	Nexus-Strider Breastplate
24833	Nexus-Strider Gloves
24834	Nexus-Strider Helmet
24835	Nexus-Strider Legwraps
24836	Nexus-Strider Mantle
24837	Nexus-Strider Bracer
24838	Wrathfin Waistband
24839	Wrathfin Greaves
24840	Wrathfin Armor
24841	Wrathfin Gloves
24842	Wrathfin Helmet
24843	Wrathfin Legguards
24844	Wrathfin Mantle
24845	Wrathfin Bindings
24846	Fenclaw Waistband
24847	Fenclaw Footwraps
24848	Fenclaw Armor
24849	Fenclaw Fists
24850	Fenclaw Helm
24851	Fenclaw Legguards
24852	Fenclaw Mantle
24853	Fenclaw Bindings
24854	Marshcreeper Belt
24855	Marshcreeper Sludgeboots
24856	Marshcreeper Fen-Vest
24857	Marshcreeper Gloves
24858	Marshcreeper Helm
24859	Marshcreeper Leggings
24860	Marshcreeper Mantle
24861	Marshcreeper Bracelets
24862	Blood Knight Girdle
24863	Blood Knight Boots
24864	Blood Knight Breastplate
24865	Blood Knight Gauntlets
24866	Blood Knight Helm
24867	Blood Knight Greaves
24868	Blood Knight Pauldrons
24869	Blood Knight Bracers
24870	Ironspine Belt
24871	Ironspine Greaves
24872	Ironspine Chain Vest
24873	Ironspine Gloves
24874	Ironspine Helm
24875	Ironspine Legguards
24876	Ironspine Shoulderguards
24877	Ironspine Bracelets
24878	Der'izu Belt
24879	Der'izu Greaves
24880	Der'izu Chestpiece
24881	Der'izu Fists
24882	Der'izu Helm
24883	Der'izu Legguards
24884	Der'izu Spaulders
24885	Der'izu Bracer
24886	Skettis Belt
24887	Skettis Footwraps
24888	Skettis Chestpiece
24889	Skettis Gauntlets
24890	Skettis Helmet
24891	Skettis Legguards
24892	Skettis Spaulders
24893	Skettis Bracer
24894	Sundered Waistband
24895	Sundered Footwraps
24896	Sundered Chestpiece
24897	Sundered Gauntlets
24898	Sundered Helmet
24899	Sundered Legguards
24900	Sundered Spaulders
24901	Tortured Bracer
24902	Talhide Stitched-Belt
24903	Talhide Lined-Boots
24904	Talhide Chestpiece
24905	Talhide Lined-Gloves
24906	Talhide Helmet
24907	Talhide Lined-Leggings
24908	Talhide Shoulderguards
24909	Talhide Lined-Bracers
24910	Netherstorm Belt
24911	Netherstorm Greaves
24912	Netherstorm Chestpiece
24913	Netherstorm Gauntlets
24914	Netherstorm Helm
24915	Netherstorm Legguards
24916	Netherstorm Shoulderguards
24917	Netherstorm Bracer
24918	Grimscale Belt
24919	Grimscale Sabatons
24920	Grimscale Armor
24921	Grimscale Gauntlets
24922	Grimscale Helm
24923	Grimscale Legguards
24924	Grimscale Pauldrons
24925	Grimscale Vambraces
24926	Ango'rosh Belt
24927	Ango'rosh Sabatons
24928	Ango'rosh Breastplate
24929	Ango'rosh Gauntlets
24930	Ango'rosh Helm
24931	Ango'rosh Legguards
24932	Ango'rosh Pauldrons
24933	Ango'rosh Vambraces
24934	Darkcrest Belt
24935	Darkcrest Sabatons
24936	Darkcrest Breastplate
24937	Darkcrest Gauntlets
24938	Darkcrest Helm
24939	Darkcrest Legguards
24940	Darkcrest Pauldrons
24941	Darkcrest Bracers
24942	Bloodscale Belt
24943	Bloodscale Sabatons
24944	Bloodscale Breastplate
24945	Bloodscale Gauntlets
24946	Bloodscale Helm
24947	Bloodscale Legguards
24948	Bloodscale Pauldrons
24949	Bloodscale Bracers
24950	Bogslayer Belt
24951	Bogslayer Sabatons
24952	Bogslayer Breastplate
24953	Bogslayer Gauntlets
24954	Bogslayer Helm
24955	Bogslayer Legplates
24956	Bogslayer Pauldrons
24957	Bogslayer Bracers
24958	Khan'aish Girdle
24959	Khan'aish Greaves
24960	Khan'aish Breastplate
24961	Khan'aish Gloves
24962	Khan'aish Helmet
24963	Khan'aish Legplates
24964	Khan'aish Epaulets
24965	Khan'aish Bracers
24966	Talonguard Girdle
24967	Talonguard Greaves
24968	Talonguard Armor
24969	Talonguard Gloves
24970	Talonguard Helmet
24971	Talonguard Legplates
24972	Talonguard Epaulets
24973	Talonguard Bracers
24974	Reaver Girdle
24975	Reaver Greaves
24976	Reaver Armor
24977	Reaver Gloves
24978	Reaver Helmet
24979	Reaver Legplates
24980	Reaver Epaulets
24981	Reaver Bracers
24982	Boulderfist Belt
24983	Boulderfist Greaves
24984	Boulderfist Armor
24985	Boulderfist Gloves
24986	Boulderfist Helm
24987	Boulderfist Legplates
24988	Boulderfist Epaulets
24989	Boulderfist Bracers
24990	Warmaul Belt
24991	Warmaul Greaves
24992	Warmaul Breastplate
24993	Warmaul Gloves
24994	Warmaul Helmet
24995	Warmaul Legplates
24996	Warmaul Epaulets
24997	Warmaul Vambraces
24998	Bloodfist Girdle
24999	Bloodfist Greaves
25000	Bloodfist Breastplate
25001	Bloodfist Gloves
25002	Bloodfist Helmet
25003	Bloodfist Legplates
25004	Bloodfist Epaulets
25005	Bloodfist Vambraces
25006	Conqueror's Girdle
25007	Conqueror's Greaves
25008	Conqueror's Breastplate
25009	Conqueror's Gauntlets
25010	Conqueror's Helmet
25011	Conqueror's Legplates
25012	Conqueror's Epaulets
25013	Conqueror's Vambraces
25014	Shattered Hand Belt
25015	Shattered Hand Sabatons
25016	Shattered Hand Breastplate
25017	Shattered Hand Gauntlets
25018	Shattered Hand Helmet
25019	Shattered Hand Legplates
25020	Shattered Hand Epaulets
25021	Shattered Hand Vambraces
25022	Warlord's Iron-Girdle
25023	Warlord's Sabatons
25024	Warlord's Iron-Breastplate
25025	Warlord's Iron-Gauntlets
25026	Warlord's Iron-Helm
25027	Warlord's Iron-Legplates
25028	Warlord's Iron-Epaulets
25029	Warlord's Iron-Vambraces
25030	Silky Velvet Cloak
25031	Silvermoon Royal Cloak
25032	Hellfire Cloak
25033	Scavenger's Cloak
25034	Elementalist Cloak
25035	Silver-Lined Cloak
25036	Boulderfist Cloak
25037	Patched Cape
25038	Forest Shroud
25039	Farseer Cloak
25040	Murkblood Cape
25041	Ambusher's Cloak
25042	Nether Cloak
25043	Amber Cape
25044	Rubellite Ring
25045	Azurite Ring
25046	Spined Ring
25047	Tourmaline Loop
25048	Smoky Quartz Ring
25049	Scheelite Ring
25050	Moldavite Ring
25051	Blue Topaz Band
25052	Hauyne Ring
25053	Lazuli Ring
25054	Sodalite Band
25055	Alexandrite Ring
25056	Almandine Ring
25057	Amber Band
25058	Anglesite Choker
25059	Fire Opal Collar
25060	Sunstone Necklace
25061	Hiddenite Necklace
25062	Zircon Amulet
25063	Multi-Colored Beads
25064	Amethyst Pendant
25065	Turquoise Brooch
25066	Pink Sapphire Necklace
25067	Diopside Beads
25068	Kunzite Necklace
25069	Epidote Stone Necklace
25070	Coral Beads
25071	Tanzanite Pendant
25072	Northman's Shield
25073	Emperor Shield
25074	Telaari Shield
25075	Hardened Steel Shield
25076	Screaming Shield
25077	Modani War-Shield
25078	Zangari Shield
25079	Outland Shield
25080	Spell-Breaker Shield
25081	Bayeaux Shield
25082	Fel-Iron Shield
25083	Smouldering Shield
25084	Zeth'Gor Shield
25085	Dragonscale Shield
25086	Dreamseeker Dandelion
25087	Bleeding Eye
25088	Laughing Skull Orb
25089	Supplicant's Rod
25090	Slavehandler Rod
25091	Mistyreed Torch
25092	Consortium Crystal
25093	Shadow Council Orb
25094	Eldr'naan Scepter
25095	Archmage Orb
25096	Elementalist Star
25097	Astralaan Orb
25098	Tuurik Torch
25099	Draenei Crystal Rod
25100	Liege Blade
25101	Cross Pommel Dagger
25102	Jaedenis Dagger
25103	Nightstalker Dagger
25104	Anzac Dagger
25105	Arachnid Dagger
25106	Cobra Shortblade
25107	Draconic Dagger
25108	Grave Keeper Knife
25109	Moon Blade
25110	Sharp Bowie Knife
25111	Lionhead Dagger
25112	Fel Ripper
25113	Phantom Dagger
25114	Doomsayer's Mace
25115	Riversong Mace
25116	Pneumatic War Hammer
25117	Flanged Battle Mace
25118	Battle Star
25119	Silvermoon War-Mace
25120	Rockshard Club
25121	Dreaded Mace
25122	Khorium Plated Bludgeon
25123	Boneshredder Mace
25124	Footman Mace
25125	Retro-Spike Club
25126	Anvilmar Hammer
25127	Knight's War Hammer
25128	Shining Mace
25129	Giant's Leg Bone
25130	Gronn-Bone Club
25131	Hateful Bludgeon
25132	Thrallmar War Hammer
25133	Stormwind Maul
25134	Highmountain Hammer
25135	Clefthoof Mace
25136	Blood Stained Hammer
25137	Draenethyst Mallet
25138	Blood Knight Maul
25139	Algaz Battle Hammer
25140	Commanding Mallet
25141	Halaani Hammer
25142	Telaari Longblade
25143	Silver Hand Blade
25144	Skettis Curved Blade
25145	Wisdom Blade
25146	Light-Etched Longsword
25147	Skystrider Katana
25148	Bone Collector Sword
25149	Baron's Broadsword
25150	Honor Hold Saber
25151	Assassins' Short Blade
25152	Howling Sword
25153	Gladiator Greatblade
25154	Blood Groove Blade
25155	Iron Skull Sword
25156	Royal Crusader Sword
25157	Serpentlord Claymore
25158	Skeletal Broadsword
25159	Thunderstrike Falchion
25160	Vengeance Blade
25161	Dragon Wing Blade
25162	Darkened Broadsword
25163	Elexorien Blade
25164	Crude Umbrafen Blade
25165	Boulderfist Claymore
25166	Mok'Nathal Warblade
25167	Nethersteel Claymore
25168	Sha'tari Longsword
25169	Fel Orc Brute Sword
25170	Rattan Bo Staff
25171	Straight Hardwood Staff
25172	Jinbali Warp-Staff
25173	Master's Bo Staff
25174	Hanbo Staff
25175	Demoniac Longstaff
25176	Taiji Quarterstaff
25177	Tanjo Staff
25178	Bata Staff
25179	Nguni Stick
25180	Calenda Fighting Stick
25181	Tapered Staff
25182	Crystal-Etched Warstaff
25183	Voodoo Hex-Staff
25184	Ravager Claws
25185	Thrasher Blades
25186	Vampiric Handscythes
25187	Shekketh Talons
25188	Spleenripper Claws
25189	Ironspine Point
25190	Wight's Claws
25191	Dread Fangs
25192	Gutrippers
25193	Deathclaw Talons
25194	Serpent's Fangs
25195	Diamond Tipped Claws
25196	Boneshredder Claws
25197	Razor Scythes
25198	Karaborian Battle Axe
25199	Knight's War Axe
25200	Jagged Broadaxe
25201	Reaver's Sickle
25202	Kingly Axe
25203	Chipped Woodchopper
25204	Colossal War Axe
25205	Silvermoon Crescent Axe
25206	Berserker Axe
25207	Shadowmoon Cleaver
25208	Bladespire Broadaxe
25209	Amani Tomahawk
25210	Double-Bladed Axe
25211	Rockbiter Cutter
25212	Lucky Strike Axe
25213	Fel-Touched Axe
25214	Mok'Nathal Battleaxe
25215	Spiked Battle Axe
25216	Ogre Splitting Axe
25217	Sundering Axe
25218	Silver-Edged Axe
25219	Rending Claw
25220	Glorious War-Axe
25221	Ghostly Battle Axe
25222	Ceremonial Slayer's Axe
25223	Windcaller Hatchet
25224	Slavemaster Axe
25225	Deepforge Broadaxe
25226	War Scythe
25227	Sha'tari Longspear
25228	Halberd Polearm
25229	Partisan Polearm
25230	Voulge Blade
25231	Fel-Wrought Halberd
25232	War Glaive
25233	Battle Scythe
25234	Telaari Polearm
25235	Ethereal-Etched Glaive
25236	Grim Scythe
25237	Nether Trident
25238	Hellfire War Spear
25239	Legend's Glaive
25240	Azerothian Longbow
25241	Ashenvale Longbow
25242	Telaari Longbow
25243	Windtalker Bow
25244	Viper Bow
25245	Razorsong Bow
25246	Thalassian Compound Bow
25247	Expert's Bow
25248	Talbuk Hunting Bow
25249	Ranger's Recurved Bow
25250	Rocslayer Longbow
25251	Orc Flatbow
25252	Dream Catcher Bow
25253	Windspear Longbow
25254	Tower Crossbow
25255	Ram's Head Crossbow
25256	Stronghold Crossbow
25257	Citadel Crossbow
25258	Repeater Crossbow
25259	Collapsible Crossbow
25260	Archer's Crossbow
25261	Mighty Crossbow
25262	Battle Damaged Crossbow
25263	Assassins' Silent Crossbow
25264	Pocket Ballista
25265	Barreled Crossbow
25266	Well-Balanced Crossbow
25267	Rampant Crossbow
25268	Lead-Slug Shotgun
25269	Longbeard Rifle
25270	Gnomish Assault Rifle
25271	Croc-Hunter's Rifle
25272	PC-54 Shotgun
25273	Sawed-Off Shotgun
25274	Cliffjumper Shotgun
25275	Dragonbreath Musket
25276	Tauren Runed Musket
25277	Sporting Rifle
25278	Nessingwary Longrifle
25279	Sen'jin Longrifle
25280	Game Hunter Musket
25281	Big-Boar Battle Rifle
25282	Mahogany Wand
25283	Crystallized Ebony Wand
25284	Purpleheart Wand
25285	Bloodwood Wand
25286	Yew Wand
25287	Magician's Wand
25288	Conjurer's Wand
25289	Majestic Wand
25290	Solitaire Wand
25291	Nobility Torch
25292	Mechano-Wand
25293	Draenethyst Wand
25294	Dragonscale Wand
25295	Flawless Wand
25296	Absorption Dagger
25297	Tuning Knife
25298	Combustion Dagger
25299	Siphoning Dagger
25300	Lightning Dagger
25301	Shattering Dagger
25302	Soul-Drain Dagger
25303	Amplifying Blade
25304	Destructo-Blade
25305	Elemental Dagger
25306	Permafrost Dagger
25307	Shadow Dagger
25308	Thunder Spike
25309	Warpdagger
25310	Naaru Lightmace
25311	Revitalizing Hammer
25312	Glorious Scepter
25313	Cold-Iron Scepter
25314	Ceremonial Hammer
25315	Restorative Mace
25316	Spirit-Clad Mace
25317	Lesser Sledgemace
25318	Ancestral Hammer
25319	Tranquility Mace
25320	Queen's Insignia
25321	Divine Hammer
25322	Lordly Scepter
25323	Ascendant's Scepter
25324	Angerstaff
25325	Brutal Scar-Limb
25326	Primal Lore-Staff
25327	Frenzied Staff
25328	Faerie-Kind Staff
25329	Tranquility Staff
25330	Starshine Staff
25331	Vengeance Staff
25332	Reflective Staff
25333	Purification Staff
25334	Intimidating Greatstaff
25335	Feral Warp-Staff
25336	Splintering Greatstaff
25337	Swarming Sting-Staff
25338	Loosely Threaded Pants
25339	Loosely Threaded Shoulderpads
25340	Loosely Threaded Vest
25341	Dilapidated Cloth Belt
25342	Dilapidated Cloth Boots
25343	Dilapidated Cloth Bracers
25344	Dilapidated Cloth Gloves
25345	Dilapidated Cloth Hat
25346	Dilapidated Cloth Pants
25347	Dilapidated Cloth Shoulderpads
25348	Dilapidated Cloth Vest
25349	Moldy Leather Armor
25350	Moldy Leather Belt
25351	Moldy Leather Boots
25352	Moldy Leather Bracers
25353	Moldy Leather Gloves
25354	Moldy Leather Helmet
25355	Moldy Leather Pants
25356	Moldy Leather Shoulderpads
25357	Decaying Leather Armor
25358	Decaying Leather Belt
25359	Decaying Leather Boots
25360	Decaying Leather Bracers
25361	Decaying Leather Gloves
25362	Decaying Leather Helmet
25363	Decaying Leather Pants
25364	Decaying Leather Shoulderpads
25365	Eroded Mail Armor
25366	Eroded Mail Belt
25367	Eroded Mail Boots
25368	Eroded Mail Bracers
25369	Eroded Mail Circlet
25370	Eroded Mail Gloves
25371	Eroded Mail Pants
25372	Eroded Mail Shoulderpads
25373	Corroded Mail Armor
25374	Corroded Mail Belt
25375	Corroded Mail Boots
25376	Corroded Mail Bracers
25377	Corroded Mail Circlet
25378	Corroded Mail Gloves
25379	Corroded Mail Pants
25380	Corroded Mail Shoulderpads
25381	Tarnished Plate Belt
25382	Tarnished Plate Boots
25383	Tarnished Plate Bracers
25384	Tarnished Plate Chestpiece
25385	Tarnished Plate Gloves
25386	Tarnished Plate Helmet
25387	Tarnished Plate Pants
25388	Tarnished Plate Shoulderpads
25389	Deteriorating Plate Belt
25390	Deteriorating Plate Boots
25391	Deteriorating Plate Bracers
25392	Deteriorating Plate Chestpiece
25393	Deteriorating Plate Gloves
25394	Deteriorating Plate Helmet
25395	Deteriorating Plate Pants
25396	Deteriorating Plate Shoulderpads
25397	Eroded Axe
25398	Stone Reaper
25399	Deteriorating Blade
25400	Tarnished Claymore
25401	Corroded Mace
25402	The Stoppable Force
25403	Sharpened Stilleto
25404	Dense War Staff
25405	Rusted Musket
25406	Broken Longbow
25407	The Movable Object
25408	Shiny Tail Hair
25409	Resilient Tail Hair
25410	Damaged Hoof
25411	Worn Hoof
25412	Dirt-covered Fur
25413	Smooth Fur
25414	Brittle Horn
25415	Aged Horn
25416	Oshu'gun Crystal Fragment
25417	Bloody Fang
25418	Razor Sharp Fang
25419	Unmarked Bag of Gems
25420	Severed Claw
25421	Gnarled Claw
25422	Bulging Sack of Gems
25423	Bag of Premium Gems
25424	Gem-Stuffed Envelope
25425	Molted Feather
25426	Brilliant Feather
25427	Beaten Talon
25428	Savage Talon
25429	Grime-Encrusted Scale
25430	Glimmering Scale
25431	Ripped Fin
25432	Pristine Fin
25433	Obsidian Warbeads
25434	Fractured Carapace
25435	Hardened Carapace
25436	Twitching Leg
25437	Barbed Leg
25438	Malachite Pendant
25439	Tigerseye Band
25440	Cracked Boar Tusk
25441	Gnarled Boar Tusk
25442	Mangled Snout
25443	Bloody Snout
25444	Corrosive Ichor
25445	Wretched Ichor
25446	Brittle Skull
25447	Broken Skull
25448	Blacksting's Stinger
25449	Bundle of Skins
25450	Creeping Moss
25451	Swamp Moss
25452	Blighted Fungus
25453	Death Cap Fungus
25454	Luminescent Globe
25455	Phosphorescent Globe
25456	Glowing Spores
25457	Incandescent Spores
25458	Mag'har Battle Standard
25459	"Count" Ungula's Mandible
25460	Bleeding Hollow Supply Crate
25461	Book of Forgotten Names
25462	Tome of Dusk
25463	Pair of Ivory Tusks
25464	Blood-Tempered Ranseur
25465	Stormcrow Amulet
25466	Broken Antenna
25467	Torn Moth Wing
25468	Boulderfist Plans
25469	Grimoire of Avoidance
25470	Golden Gryphon
25471	Ebon Gryphon
25472	Snowy Gryphon
25473	Swift Blue Gryphon
25474	Tawny Windrider
25475	Blue Windrider
25476	Green Windrider
25477	Swift Red Windrider
25478	Defender's Gauntlets
25479	Boots of the Earthcaller
25480	Wastewalker's Sash
25481	Suntrider's Gauntlets
25482	Venn'ren's Boots
25483	Fine Sash
25484	Telhamat Pendant
25485	Amaan's Signet
25486	Demonslayer's Wristguards
25487	Wind Dancer's Pendant
25488	Signet of Aeranas
25489	Windtalker's Cloak
25490	Boulderfist Key
25491	Salvaged Spore Sacs
25492	Earthcaller's Mace
25493	QR 9447 2H Axe
25494	Totemic Staff
25495	Wolfrider's Dagger
25496	Mag'har Bow
25497	Broken Balanced Stone Dirk
25498	Rough Stone Statue
25499	Felblood Band
25500	Felforce Medallion
25501	Lost Anchorite's Cloak
25502	Lightbearer's Gauntlets
25503	Flamehandler's Gloves
25504	Pilgrim's Belt
25505	Carinda's Wedding Band
25506	Vindicator's Chain Helm
25507	Leggings of Telhamat
25508	Omenai Vest
25509	Northwind Cleft Key
25510	Ceremonial Robes
25511	Thunderforge Leggings
25512	Tribal Hauberk
25513	Clefthoof Hide Mask
25514	Ikeyen's Pauldrons
25515	Mud Encrusted Boots
25516	Ikeyen's Boots
25517	Preserver's Medallion
25518	Explorer's Leggings
25519	Warden's Hammer
25521	Greater Rune of Warding
25522	Marshstrider's Spaulders
25523	Windcaller's Gauntlets
25524	Cenarion Expedition Boots
25525	Zangar Epaulets
25526	Plans: Greater Rune of Warding
25527	Swift Red Gryphon
25528	Swift Green Gryphon
25529	Swift Purple Gryphon
25530	Helm of Natural Purity
25531	Swift Green Windrider
25532	Swift Yellow Windrider
25533	Swift Purple Windrider
25534	Marsh Survivalist's Belt
25535	Netherwhelp's Collar
25536	Sporeggar Smasher
25537	Hewing Axe of the Marsh
25538	Sporeling Claw
25539	Potion of Water Breathing
25540	Dark Cloak of the Marsh
25541	Cenarion Ring of Casting
25542	Lucky Circle of the Fool
25543	Talbuk Sticker
25544	Zerid's Vintage Musket
25545	Talbuk Dirk
25546	QR XXXX Paladin Chest
25547	QR XXXX Druid Shoulders
25548	Tallstalk Mushroom
25549	Blood Knight Tabard
25550	Redcap Toadstool
25551	QR XXXX Hunter Legs
25552	Warmaul Ogre Banner
25553	Exodar Staff
25554	Kil'sorrow Armaments
25555	Kil'sorrow Banner
25556	Oversized Ogre Hauberk
25557	Salvaged Ango'rosh Pauldrons
25558	Ango'rosh Souleater's Cowl
25559	Lo'ap's Tunic of Muck Diving
25560	Lo'ap's Muck Diving Pads
25561	Muck-ridden Galoshes
25562	Earthen Mark of Razing
25563	Earthen Mark of Power
25564	Earthen Mark of Health
25565	Spaulders of the Ring
25566	Judicator's Gauntlets
25567	Cord of the Ring
25568	Warcaster's Scaled Leggings
25569	Murkblood Avenger's Chestplate
25570	Melia's Lustrous Crown
25571	QR 9863 Druid Helm
25572	QR 9863 Shaman Legs
25573	QR 9863 Warrior Chest
25574	Greenkeeper's Pantaloons
25575	Thunderbringer's Guard
25576	Smuggler's Mitts
25577	Greenblood Pantaloons
25578	Caustic Feelers
25579	Dark Shaman's Cover
25580	QR 9867 Warrior Legs
25581	QR 9867 Hunter Gloves
25582	QR 9867 Druid Moonkin Belt
25583	Eighty Silver Links
25584	Murkblood Oven Mitts
25585	Murkblood Avenger's Legplates
25586	Burning Blade Peace Offering
25589	Clefthoof Helm
25590	Head of Cho'war
25591	Clefthoof Gloves
25592	Clefthoof Wristguards
25593	Windroc Greaves
25594	Windroc Boots
25595	Windroc Shroud
25596	Peep's Whistle
25597	Vindicator's Cinch
25598	Fen Strider's Bracer
25599	Explorer's Bands
25600	Bog Walker's Bands
25601	Murk-Darkened Bracers
25602	Bog Walker's Belt
25603	Lantresor's Warblade
25604	Warmaul Prison Key
25605	Burning Blade Devotee's Cinch
25606	Burning Blade Cultist Band
25607	Burning Blade Cultist Band
25608	Lantresor's Warblade
25609	Burning Blade Devotee's Cinch
25610	Fen Strider's Footguards
25611	The Witch Doctor's Wraps
25612	Daggerfen Mail
25613	Feralfen Mystic's Handwraps
25614	Feralfen Beastmaster's Hauberk
25615	Feralfen Champion's Boots
25616	Tim's Trusty Helmet
25617	Captain Krosh's Crash Helmet
25618	Telaar Courier's Cloak
25619	Glowing Crystal Insignia
25620	Ancient Crystal Talisman
25621	Serpent Spirit's Drape
25622	Staff of the Four Golden Coins
25623	Bracers of the Battle Cleric
25624	King's Bulwark
25625	QR 9922 Feral Druid Staff
25626	QR 9922 Paladin Bracer
25627	QR 9922 Shield
25628	Ogre Mauler's Badge
25629	Ogre Handler's Shooter
25630	Ogre Basher's Slippers
25631	Boots of the Specialist
25632	Wand of Happiness
25633	Uniting Charm
25634	Oshu'gun Relic
25635	Eye of Veil Skith
25636	Talbuk Cape
25637	Ethereal Sash
25638	Eye of Veil Reskk
25639	Hemet's Elekk Gun
25640	Nesingwary Safari Stick
25641	Broken Fitz's Throwing Axe
25642	Eye of Veil Shienor
25643	Harold's Rejuvenating Broach
25644	Blessed Book of Nagrand
25645	Totem of the Plains
25647	Telaar Supply Crate
25648	Cho'war's Key
25649	Knothide Leather Scraps
25650	Knothide Armor Kit
25651	Vindicator's Armor Kit
25652	Magister's Armor Kit
25653	Riding Crop
25654	Felscale Gloves
25655	Felscale Boots
25656	Felscale Pants
25657	Felscale Breastplate
25658	Damp Woolen Blanket
25659	Scaled Draenic Boots
25660	Scaled Draenic Vest
25661	Scaled Draenic Gloves
25662	Scaled Draenic Pants
25666	Mug'gok's Head
25667	ObsoleteIdol of the Beast
25668	Thick Draenic Boots
25669	Thick Draenic Gloves
25670	Thick Draenic Pants
25671	Thick Draenic Vest
25672	Teromoth Sample
25673	Wild Draenish Boots
25674	Wild Draenish Gloves
25675	Wild Draenish Leggings
25676	Wild Draenish Vest
25677	Terokkar Chokeberry
25678	Warp Hunter Essence
25679	Comfortable Insoles
25680	Stylin' Purple Hat
25681	Stylin' Adventure Hat
25682	Stylin' Jungle Hat
25683	Stylin' Crimson Hat
25684	Kokorek's Talisman
25685	Fel Leather Gloves
25686	Fel Leather Boots
25687	Fel Leather Leggings
25689	Heavy Clefthoof Vest
25690	Heavy Clefthoof Leggings
25691	Heavy Clefthoof Boots
25692	Netherfury Leggings
25693	Netherfury Boots
25694	Netherfury Belt
25695	Felstalker Belt
25696	Felstalker Breastplate
25697	Felstalker Bracers
25699	Crystal Infused Leather
25700	Fel Scales
25701	Breastplate of Retribution
25702	Scaled Legs of Ruination
25703	Zhevra Leather
25705	Luanga's Orders
25706	Luanga's Orders
25707	Fel Hide
25708	Thick Clefthoof Leather
25710	Moonkin Headdress
25711	Deadly Borer Leggings
25712	Perfectly Balanced Cape
25713	Holy Healing Band
25714	Crimson Pendant of Clarity
25715	Jade Warrior Pauldrons
25716	Handguards of Precision
25717	Sure-Step Boots
25718	Mantle of Magical Might
25719	Arakkoa Feather
25720	Pattern: Heavy Knothide Leather
25721	Pattern: Vindicator's Armor Kit
25722	Pattern: Magister's Armor Kit
25723	Bent Antenna
25724	Ripped Moth Wing
25725	Pattern: Riding Crop
25726	Pattern: Comfortable Insoles
25727	Sealed Box
25728	Pattern: Stylin' Purple Hat
25729	Pattern: Stylin' Adventure Hat
25730	Pattern: Stylin' Jungle Hat
25731	Pattern: Stylin' Crimson Hat
25732	Pattern: Fel Leather Gloves
25733	Pattern: Fel Leather Boots
25734	Pattern: Fel Leather Leggings
25735	Pattern: Heavy Clefthoof Vest
25736	Pattern: Heavy Clefthoof Leggings
25737	Pattern: Heavy Clefthoof Boots
25738	Pattern: Felstalker Belt
25739	Pattern: Felstalker Bracers
25740	Pattern: Felstalker Breastplate
25741	Pattern: Netherfury Belt
25742	Pattern: Netherfury Leggings
25743	Pattern: Netherfury Boots
25744	Dampscale Basilisk Eye
25745	Olemba Seed
25746	Box of Parts
25751	The Master Planner's Blueprints
25754	Mana Bomb Code Sheet 1
25755	Mana Bomb Code Sheet 2
25756	Mana Bomb Code Sheet 3
25757	Mana Bomb Code Sheet 4
25759	Mogor's Anointing Club
25760	Battle Mage's Baton
25761	Staff of Beasts
25762	Honed Voidaxe
25763	Ceremonial Warmaul Blood-blade
25764	Mag'hari Fury Brand
25765	Fel Orc Plans
25766	"Creatures That Owe Sal'salabim Golds"
25767	Raliq's Debt
25768	Coosh'coosh's Debt
25769	Floon's Debt
25770	Fel Cannon Activator
25771	Fel Cannon Activator
25772	Crystalline Kopesh
25773	Hungering Bone Cudgel
25774	Azure Lightblade
25775	Ogre Slayer's Band
25776	Ogre Slayer's Pendant
25777	Ogre Slayer's Cover
25778	Manacles of Remembrance
25779	Warmaul Slayer's Band
25780	Warmaul Defender's Cloak
25781	Segmented Breastplate
25782	Sunstrider Legguards
25783	Pilgrim's Cover
25784	Imbued Chain
25785	Adept's Band
25786	Hypnotist's Watch
25787	Charm of Alacrity
25788	Dauntless Handguards
25789	Rune-Engraved Belt
25790	Expedition Scout's Epaulets
25791	Gloves of Preservation
25792	Curate's Boots
25793	Curate's Footwraps
25794	Bone Studded Girdle
25795	Gloves of Preservation
25796	Lurking Shadow Spaulders
25797	Crushing Grasp
25802	Dreadfang Venom Sac
25803	Medallion of the Valiant Guardian
25804	Naliko's Revenge
25805	Mantle of Vivification
25806	Nethekurse's Rod of Torment
25807	Timber Worg Tail
25808	Rod of Dire Shadows
25809	Maimfist's Choker
25810	Vicar's Cloak
25811	Conquerer's Band
25812	Timber Worg Pelt
25813	Small Mushroom
25814	Deathskitter's Fang
25815	Stonegazer's Blood
25817	Blessed Vial
25819	Breastplate of the Warbringer
25820	Metallic Headband of Simm'onz
25821	Leggings of Unending Assault
25822	Watcher's Tunic
25823	Grunt's Waraxe
25824	Farseer's Band
25825	Footman's Longsword
25826	Sage's Band
25827	Muck-Covered Drape
25828	Petrified Lichen Guard
25829	Talisman of the Alliance
25830	Gladiator's Leather Helm
25831	Gladiator's Leather Tunic
25832	Gladiator's Leather Spaulders
25833	Gladiator's Leather Legguards
25834	Gladiator's Leather Gloves
25835	Explorer's Walking Stick
25836	Preserver's Cudgel
25837	Ironjaw's Pelt
25838	Warden's Hauberk
25840	Extract of the Afterlife
25841	Draenei Vessel
25842	Restless Bones
25843	Fel Iron Rod
25844	Adamantite Rod
25845	Eternium Rod
25846	Plans: Adamantite Rod
25847	Plans: Eternium Rod
25848	Formula: Runed Adamantite Rod
25849	Formula: Runed Eternium Rod
25850	Tuurem Artifact
25852	Tail Feather of Torgos
25853	Pack of Incendiary Bombs
25854	Gladiator's Silk Amice
25855	Gladiator's Silk Cowl
25856	Gladiator's Silk Raiment
25857	Gladiator's Silk Handguards
25858	Gladiator's Silk Trousers
25861	Crude Throwing Axe
25862	Marshberry
25863	Olemba Root
25864	Telaari Frond
25865	Dragonspine
25866	Greatmother's List of Herbs
25867	Earthstorm Diamond
25868	Skyfire Diamond
25869	Recipe: Transmute Earthstorm Diamond
25870	Recipe: Transmute Skyfire Diamond
25871	Standard Thrown Weapon
25872	Balanced Throwing Dagger
25873	Keen Throwing Knife
25874	Large Throwing Knife
25875	Deadly Throwing Axe
25876	Gleaming Throwing Axe
25877	Master's Throwing Dagger
25878	Dusksteel Throwing Knife
25880	Coarse Stone Statue
25881	Heavy Stone Statue
25882	Solid Stone Statue
25883	Dense Stone Statue
25884	Primal Stone Statue
25886	Purple Smoke Flare
25887	Schematic: Purple Smoke Flare
25888	Design: Primal Stone Statue
25889	Draenei Holy Water
25890	Destructive Skyfire Diamond
25891	Pristine Shimmerscale Eel
25893	Mystical Skyfire Diamond
25894	Swift Skyfire Diamond
25895	Enigmatic Skyfire Diamond
25896	Powerful Earthstorm Diamond
25897	Bracing Earthstorm Diamond
25898	Tenacious Earthstorm Diamond
25899	Brutal Earthstorm Diamond
25900	Grimoire of Demonic Frenzy
25901	Insightful Earthstorm Diamond
25902	Design: Powerful Earthstorm Diamond
25903	Design: Bracing Earthstorm Diamond
25904	Design: Insightful Earthstorm Diamond
25905	Design: Tenacious Earthstorm Diamond
25906	Design: Brutal Earthstorm Diamond
25907	Design: Destructive Skyfire Diamond
25908	Design: Swift Skyfire Diamond
25909	Design: Mystical Skyfire Diamond
25910	Design: Enigmatic Skyfire Diamond
25911	Salvaged Wood
25912	Salvaged Metal
25913	Ring of the Slain Anchorite
25914	Broken Choker
25915	Fallen Vindicator's Blade
25916	Terokkar Axe
25917	Healer's Staff of the Forest
25918	Blood-Guided Knife
25919	Sedai's Necklace
25920	Sedai's Blade
25921	Sedai's Ring
25922	Fearless Girdle
25923	Fierce Mantle
25924	Swamprunner's Boots
25925	Terrorcloth Mantle
25926	Nexus-Stalker's Band
25927	Consortium Cloak of the Quick
25928	Ethereal Healing Pendant
25929	Cenarion Thicket Legplates
25930	Cenarion Thicket Helm
25931	Cenarion Thicket Circlet
25932	Cenarion Thicket Jerkin
25933	Extra Sharp Blade
25934	Spiked Destroyer
25935	Invincible Stave
25936	Terokkar Tablet of Vim
25937	Terokkar Tablet of Precision
25938	Mysteries of the Light
25939	Voidfire Wand
25940	Idol of the Claw
25941	Boots of the Outlander
25942	Faith Bearer's Gauntlets
25943	Creepjacker
25944	Shaarde the Greater
25945	Cloak of Revival
25946	Nethershade Boots
25947	Lightning-Rod Pauldrons
25948	Girdle of the Penitent
25949	Gloves of the Afterlife
25950	Staff of Polarities
25951	Fleet Refugee's Boots
25952	Scimitar of the Nexus-Stalkers
25953	Ethereal Warp-Bow
25954	Sigil of Shaffar
25955	Mask of the Howling Storm
25956	Nexus-Bracers of Vigor
25957	Ethereal Boots of the Skystrider
25958	Eagle Engraved Bracers
25959	Feathered Armbands
25960	Talonstalker Bracers
25961	Feathered Wrist Cuffs
25962	Longstrider's Loop
25963	Kokorek's Signet
25964	Shaarde the Lesser
25965	Cloak of Grasping Talons
25966	Arakkoa Sage's Shawl
25967	Eagle Crested Pauldrons
25968	Shalassi Sentry's Epaulets
25969	Rapscallion's Touch
25970	Shalassi Oracle's Sandals
25971	Stout Oak Longbow
25972	Deadeye's Piece
25973	Dark Augur's Wand
25974	Helm of Lupine Cunning
25975	Wolf Hunter's Guise
25976	Helm of Lupine Grace
25977	Helm of Lupine Ferocity
25978	Seth's Graphite Fishing Pole
25979	Flintlocke's Piloting Pants
25980	Aerodynamic Scaled Vest
25981	Dirigible Crash Helmet
25982	Foreman's Sash
25983	Heavy Miner's Belt
25984	Miner's Brace
25985	Cenarion Naturalist's Staff
25986	Dreadtusk's Fury
25987	Helboar Carving Blade
25988	Glowing Alabaster Ring
25989	Draenethyst Chaplet
25990	Smooth Soapstone Band
25991	Seamless Stone Band
25992	Enforcer's Chain
25993	Finely Wrought Chain
25994	Rune of Force
25995	Star of Sha'naar
25996	Emblem of Perseverance
25997	Gladiator's Linked Armor
25998	Gladiator's Linked Helm
25999	Gladiator's Linked Spaulders
26000	Gladiator's Linked Gauntlets
26001	Gladiator's Linked Leggings
26002	Flaming Torch
26004	Farmhand's Vest
26005	Jessera's Fungus Lined Tunic
26006	Crystal-Flecked Pants
26007	Vindicator's Woolies
26008	Scholar's Gloves
26009	Flutterer Silk Handwraps
26010	Vindicator's Soft Sole Slippers
26011	Cryo-Core Attendant's Boots
26012	Kessel's Cinch Wrap
26013	Cincture of Woven Reeds
26014	Jessera's Fungus Lined Cuffs
26015	Anchorite Neophyte's Cuffs
26016	Surveyor's Mantle
26017	Venomous Silk Cover
26018	Elekk Handler's Leathers
26019	Jessera's Fungus Lined Vest
26020	Shard-Covered Leggings
26021	Vindicator's Leather Chaps
26022	Researcher's Gloves
26023	Ravager Hide Gloves
26024	Vindicator's Leather Moccasins
26025	Technician's Boots
26026	Ornately Tooled Belt
26027	Kessel's Sweat Stained Elekk Leash
26028	Jessera's Fungus Lined Bands
26029	Watchman's Bracers
26030	Jessera's Fungus Lined Hauberk
26031	Elekk Rider's Mail
26032	Crystal-Studded Legguards
26033	Vindicator's Iron Legguards
26034	Protective Field Gloves
26035	Corin's Handguards
26036	Vindicator's Stompers
26037	Lightweight Mesh Boots
26038	Segmented Girdle
26039	Kessel's Sturdy Riding Handle
26040	Jessera's Fungus Lined Bracers
26041	Vigilant Vambraces
26042	Oshu'gun Crystal Powder Sample
26043	Oshu'gun Crystal Powder Sample
26044	Halaa Research Token
26045	Halaa Battle Token
26048	Letter to Kialon
26050	Fist of Argus
26051	2 Stone Sledgehammer
26052	Vindicator's Smasher
26053	Elekk Handler's Blade
26054	Blade of Argus
26055	Oculus of the Hidden Eye
27317	Elemental Sapta
27357	Potion of Greater Vision
27388	Mr. Pinchy
27389	Surplus Bastard Sword
27390	Vindicator's Letter Opener
27398	Carved Crystalline Orb
27399	Stillpine Defender
27400	Peacekeeper's Buckler
27401	Arugoo's Crossbow of Destruction
27402	Huntsman's Crossbow
27403	Stillpine Stinger
27404	Lightspark
27408	Hope Bearer Helm
27409	Raven-Heart Headdress
27410	Collar of Command
27411	Slippers of Serenity
27412	Ironstaff of Regeneration
27413	Ring of the Exarchs
27414	Mok'Nathal Beast-Mask
27415	Darkguard Face Mask
27416	Fetish of the Fallen
27417	Ravenwing Pauldrons
27418	Stormreaver Shadow-Kilt
27419	Forge Camp: Spite Plans
27420	Uther's Ceremonial Warboots
27421	Forge Camp: Rage Plans
27422	Barbed Gill Trout
27423	Cloak of Impulsiveness
27424	Amani Venom-Axe
27425	Spotted Feltail
27426	Northshire Battlemace
27427	Durotan's Battle Harness
27428	Stormfront Gauntlets
27429	Zangarian Sporefish
27430	Scaled Greaves of Patience
27431	Time-Shifted Dagger
27432	Broxigar's Ring of Valor
27433	Pauldrons of Sufferance
27434	Mantle of Perenolde
27435	Figluster's Mudfish
27436	Iron Band of the Unbreakable
27437	Icefin Bluefish
27438	Golden Darter
27439	Furious Crawdad
27440	Diamond Prism of Recurrence
27441	Felblood Snapper
27442	Goldenscale Vendorfish
27443	Steam Pump Debris
27444	Foulfin
27445	Magical Crawdad Box
27446	Mr. Pinchy's Gift
27447	Bracers of Just Rewards
27448	Cloak of the Everliving
27449	Blood Knight Defender
27450	Wild Stalker Boots
27451	Boots of the Darkwalker
27452	Light Scribe Bands
27453	Averinn's Ring of Slaying
27454	Volcanic Pauldrons
27455	Irondrake Faceguard
27456	Raiments of Nature's Breath
27457	Life Bearer's Gauntlets
27458	Oceansong Kilt
27459	Vambraces of Daring
27460	Reavers' Ring
27461	Chestguard of the Prowler
27462	Crimson Bracers of Gloom
27463	Terror Flame Dagger
27464	Omor's Unyielding Will
27465	Mana-Etched Gloves
27466	Headdress of Alacrity
27467	Silent-Strider Kneeboots
27468	Moonglade Handwraps
27469	Gladiator's Mail Armor
27470	Gladiator's Mail Gauntlets
27471	Gladiator's Mail Helm
27472	Gladiator's Mail Leggings
27473	Gladiator's Mail Spaulders
27474	Beast Lord Handguards
27475	Gauntlets of the Bold
27476	Truncheon of Five Hells
27477	Faol's Signet of Cleansing
27478	Girdle of the Blasted Reaches
27479	Flaming Torch
27480	Soul Device
27481	Heavy Supply Crate
27483	Moon-Touched Bands
27484	Libram of Avengement
27485	Embroidered Cape of Mysteries
27487	Bloodlord Legplates
27488	Mage-Collar of the Firestorm
27489	Virtue Bearer's Vambraces
27490	Firebrand Battleaxe
27491	Signet of Repose
27492	Moonchild Leggings
27493	Gloves of the Deadwatcher
27494	Emerald Eye Bracer
27495	Soldier's Dog Tags
27497	Doomplate Gauntlets
27498	Scroll of Agility V
27499	Scroll of Intellect V
27500	Scroll of Protection V
27501	Scroll of Spirit V
27502	Scroll of Stamina V
27503	Scroll of Strength V
27505	Ruby Helm of the Just
27506	Robe of Effervescent Light
27507	Adamantine Repeater
27508	Incanter's Gloves
27509	Handgrips of Assassination
27510	Tidefury Gauntlets
27511	Inscribed Scrollcase
27512	The Willbreaker
27513	Curious Crate
27514	Leggings of the Unrepentant
27515	Huge Spotted Feltail
27516	Enormous Barbed Gill Trout
27517	Bands of Nethekurse
27518	Ivory Idol of the Moongoddess
27519	Cloak of Malice
27520	Greathelm of the Unbreakable
27521	Telaari Hunting Girdle
27522	World's End Bracers
27523	Exarch's Diamond Band
27524	Firemaul of Destruction
27525	Jeweled Boots of Sanctification
27526	Skyfire Hawk-Bow
27527	Greaves of the Shatterer
27528	Gauntlets of Desolation
27529	Figurine of the Colossus
27531	Wastewalker Gloves
27532	Master Fishing - The Art of Angling
27533	Demonblood Eviscerator
27534	Hortus' Seal of Brilliance
27535	Gauntlets of the Righteous
27536	Hallowed Handwraps
27537	Gloves of Oblivion
27538	Lightsworn Hammer
27539	Justice Bearer's Pauldrons
27540	Nexus Torch
27541	Archery Belt of the Broken
27542	Cord of Belief
27543	Starlight Dagger
27544	Totem of Spontaneous Regrowth
27545	Mennu's Scaled Leggings
27546	Traitor's Noose
27547	Coldwhisper Cord
27548	Girdle of Many Blessings
27549	Wavefury Boots
27550	Ironscale War Cloak
27551	Skeletal Necklace of Battlerage
27552	Soft Leather Vest
27553	Crimson Steer Energy Drink
27631	Needle Shrike
27632	Terokk's Quill
27633	Terokk's Mask
27634	The Saga of Terokk
27635	Lynx Steak
27636	Bat Bites
27637	Shadowstalker's Sash
27638	Hierophant's Sash
27639	Slayer's Waistguard
27640	Hand of Argus Crossfire
27641	Vindicator's Walking Stick
27643	Stormbreaker's Girdle
27644	Avenger's Waistguard
27645	Dreamstalker Sash
27646	Marksman's Belt
27647	Marksman's Legguards
27648	Dreamstalker Leggings
27649	Hierophant's Leggings
27650	Shadowstalker's Leggings
27651	Buzzard Bites
27652	Stormbreaker's Leggings
27653	Slayer's Leggings
27654	Avenger's Legplates
27655	Ravager Dog
27656	Sporeling Snack
27657	Blackened Basilisk
27658	Roasted Clefthoof
27659	Warp Burger
27660	Talbuk Steak
27661	Blackened Trout
27662	Feltail Delight
27663	Blackened Sporefish
27664	Grilled Mudfish
27665	Poached Bluefish
27666	Golden Fish Sticks
27667	Spicy Crawdad
27668	Lynx Meat
27669	Bat Flesh
27671	Buzzard Meat
27672	Girdle of the Immovable
27673	Phosphorescent Blade
27674	Ravager Flesh
27676	Strange Spores
27677	Chunk o' Basilisk
27678	Clefthoof Meat
27679	Sublime Mystic Dawnstone
27680	Halaani Bag
27681	Warped Flesh
27682	Talbuk Venison
27683	Quagmirran's Eye
27684	Recipe: Buzzard Bites
27685	Recipe: Lynx Steak
27686	Recipe: Roasted Moongraze Tenderloin
27687	Recipe: Bat Bites
27688	Recipe: Ravager Dog
27689	Recipe: Sporeling Snack
27690	Recipe: Blackened Basilisk
27691	Recipe: Roasted Clefthoof
27692	Recipe: Warp Burger
27693	Recipe: Talbuk Steak
27694	Recipe: Blackened Trout
27695	Recipe: Feltail Delight
27696	Recipe: Blackened Sporefish
27697	Recipe: Grilled Mudfish
27698	Recipe: Poached Bluefish
27699	Recipe: Golden Fish Sticks
27700	Recipe: Spicy Crawdad
27702	Gladiator's Lamellar Chestpiece
27703	Gladiator's Lamellar Gauntlets
27704	Gladiator's Lamellar Helm
27705	Gladiator's Lamellar Legguards
27706	Gladiator's Lamellar Shoulders
27707	Gladiator's Satin Gloves
27708	Gladiator's Satin Hood
27709	Gladiator's Satin Leggings
27710	Gladiator's Satin Mantle
27711	Gladiator's Satin Robe
27712	Shackles of Quagmirran
27713	Pauldrons of Desolation
27714	Swamplight Lantern
27715	Circle's Stalwart Helmet
27716	Refuge Armor
27717	Expedition Forager Leggings
27718	Aldor Defender's Legplates
27719	Aldor Leggings of Puissance
27720	Robes of the Aldor
27721	Expedition Footgear
27722	Gloves of Marshmanship
27723	Belt of the Moonkin
27724	Wild Shoulderpads
27725	Expedition Mantle
27726	Hearty Cenarion Cincture
27727	Swift Cenarion Footwear
27728	Cushy Cenarion Walkers
27729	Humanoid Skull
27730	Watcher's Cloak of Vigilance
27731	Vindicator's Cloak
27732	Infiltrator's Cloak
27733	Warden's Ring of Precision
27734	Expedition Caster's Band
27735	Pendant of the Marsh
27736	Master Cookbook
27737	Moonglade Shoulders
27738	Incanter's Pauldrons
27739	Spaulders of the Righteous
27740	Band of Ursol
27741	Bleeding Hollow Warhammer
27742	Mage-Fury Girdle
27743	Girdle of Living Flame
27744	Idol of Ursoc
27745	Hungarhide Gauntlets
27746	Arcanium Signet Bands
27747	Boggspine Knuckles
27748	Cassock of the Loyal
27749	Staff of the Wild
27750	Hammer of the Sporelings
27751	Survivalist's Pike
27752	Zangarmarsh Claymore
27753	Ensorcelled Marshfang Blade
27754	Keen Marshfang Slicer
27755	Girdle of Gallantry
27756	Marshfang Blade Axe
27757	Greatstaff of the Leviathan
27758	Hydra-fang Necklace
27759	Headdress of the Tides
27760	Dunewind Sash
27761	Ring of the Shadow Deeps
27762	Weathered Band of the Swamplord
27763	Crown of the Forest Lord
27764	Hands of the Sun
27765	Armwraps of Disdain
27766	Swampstone Necklace
27767	Bogreaver
27768	Oracle Belt of Timeless Mystery
27769	Endbringer
27770	Argussian Compass
27771	Doomplate Shoulderguards
27772	Stormshield of Renewal
27773	Barbaric Legstraps
27775	Hallowed Pauldrons
27776	Shoulderpads of Assassination
27777	Stark Blood Garnet
27778	Spaulders of Oblivion
27779	Bone Chain Necklace
27780	Ring of Fabled Hope
27781	Demonfang Ritual Helm
27783	Moonrage Girdle
27784	Scintillating Coral Band
27785	Notched Deep Peridot
27786	Barbed Deep Peridot
27787	Chestguard of No Remorse
27788	Bloodsworn Warboots
27789	Cloak of Whispering Shells
27790	Mask of Penance
27791	Serpentcrest Life-Staff
27792	Steam-Hinge Chain of Valor
27793	Earth Mantle Handwraps
27794	Recoilless Rocket Ripper X-54
27795	Sash of Serpentra
27796	Mana-Etched Spaulders
27797	Wastewalker Shoulderpads
27798	Gauntlets of Vindication
27799	Vermillion Robes of the Dominant
27800	Earthsoul Britches
27801	Beast Lord Mantle
27802	Tidefury Shoulderguards
27803	Shoulderguards of the Bold
27804	Devilshark Cape
27805	Ring of the Silver Hand
27806	Fathomheart Gauntlets
27807	Air Elemental Gas
27808	Jump-a-tron 4000 Key
27809	Barbed Deep Peridot
27812	Stark Blood Garnet
27813	Boots of the Colossus
27814	Twinblade of Mastery
27815	Totem of the Astral Winds
27816	Mindrage Pauldrons
27817	Starbolt Longbow
27818	Starry Robes of the Crescent
27820	Notched Deep Peridot
27821	Extravagant Boots of Malice
27822	Crystal Band of Valor
27823	Shard Encrusted Breastplate
27824	Robe of the Great Dark Beyond
27825	Predatory Gloves
27826	Mantle of the Sea Wolf
27827	Lucid Dream Bracers
27828	Warp-Scarab Brooch
27829	Axe of the Nexus-Kings
27830	Circlet of the Victor
27831	Mantle of the Unforgiven
27832	Band of the Victor
27833	Band of the Victor
27834	Circlet of the Victor
27835	Stillwater Girdle
27837	Wastewalker Leggings
27838	Incanter's Trousers
27839	Legplates of the Righteous
27840	Scepter of Sha'tar
27841	Severed Talon of the Matriarch
27842	Grand Scepter of the Nexus-Kings
27843	Glyph-Lined Sash
27844	Pauldrons of Swift Retribution
27845	Magma Plume Boots
27846	Claw of the Watcher
27847	Fanblade Pauldrons
27848	Embroidered Spellpyre Boots
27854	Smoked Talbuk Venison
27855	Mag'har Grainbread
27856	Skethyl Berries
27857	Garadar Sharp
27858	Sunspring Carp
27859	Zangar Caps
27860	Purified Draenic Water
27861	Lathrai's Stolen Goods
27863	Extended Cost Bryanite
27864	Brian's Bryanite of Extended Cost Copying
27865	Bracers of Shirrak
27866	Scintillating Headdress of Second Sight
27867	Boots of the Unjust
27868	Runesong Dagger
27869	Soulpriest's Ring of Resolve
27870	Doomplate Legguards
27871	Maladaar's Blessed Chaplet
27872	The Harvester of Souls
27873	Moonglade Pants
27874	Beast Lord Leggings
27875	Hallowed Trousers
27876	Will of the Fallen Exarch
27877	Draenic Wildstaff
27878	Auchenai Death Shroud
27879	Gladiator's Scaled Chestpiece
27880	Gladiator's Scaled Gauntlets
27881	Gladiator's Scaled Helm
27882	Gladiator's Scaled Legguards
27883	Gladiator's Scaled Shoulders
27884	Ornate Boots of the Sanctified
27885	Soul-Wand of the Aldor
27886	Idol of the Emerald Queen
27887	Platinum Shield of the Valorous
27888	Dream-Wing Helm
27889	Jaedenfire Gloves of Annihilation
27890	Wand of the Netherwing
27891	Adamantine Figurine
27892	Cloak of the Inciter
27893	Ornate Leggings of the Venerated
27894	Tangled Mane
27895	Band of Many Prisms
27896	Alembic of Infernal Power
27897	Breastplate of Many Graces
27898	Wrathfire Hand-Cannon
27899	Mana Wrath
27900	Jewel of Charismatic Mystique
27901	Blackout Truncheon
27902	Silent Slippers of Meditation
27903	Sonic Spear
27904	Resounding Ring of Glory
27905	Greatsword of Horrid Dreams
27906	Crimsonforge Breastplate
27907	Mana-Etched Pantaloons
27908	Leggings of Assassination
27909	Tidefury Kilt
27910	Silvermoon Crest Shield
27911	Epoch's Whispering Cinch
27912	Harness of the Deep Currents
27913	Whispering Blade of Slaying
27914	Moonstrider Boots
27915	Sky-Hunter Swift Boots
27916	Sethekk Feather-Darts
27917	Libram of the Eternal Rest
27918	Bands of Syth
27919	Light-Woven Slippers
27920	Mark of Conquest
27921	Mark of Conquest
27922	Mark of Defiance
27924	Mark of Defiance
27925	Ravenclaw Band
27926	Mark of Vindication
27927	Mark of Vindication
27928	Terminal Edge
27929	Terminal Edge
27930	Splintermark
27931	Splintermark
27932	Razor Claw
27933	Serrated Tooth
27934	Vorpal Claw
27935	Needle Fang
27936	Greaves of Desolation
27937	Sky Breaker
27938	Savage Mask of the Lynx Lord
27939	Incendic Rod
27940	Marvelous Madstone of Immortality
27941	Compassionate Critter's Friend
27942	Incendic Rod
27943	Chieftain Mummaki's Totem
27944	Talisman of True Treasure Tracking
27945	Shark's Tooth of Bona Fide Fluidic Mobility
27946	Avian Cloak of Feathers
27947	Totem of Impact
27948	Trousers of Oblivion
27949	Libram of Zeal
27976	Polished Pendant of Edible Energy
27977	Legplates of the Bold
27978	Soap on a Rope
27979	Stone of Stupendous Springing Strides
27980	Terokk's Nightmace
27981	Sethekk Oracle Cloak
27982	Charm of Potent and Powerful Passions
27983	Libram of Zeal
27984	Totem of Impact
27985	Deathforge Girdle
27986	Crow Wing Reaper
27987	Melmorta's Twilight Longbow
27988	Burnoose of Shifting Ages
27989	Idol of Savagery
27990	Idol of Savagery
27991	Shadow Labyrinth Key
27992	Infallible Tikbalang Ward
27993	Mask of Inner Fire
27994	Mantle of Three Terrors
27995	Sun-Gilded Shouldercaps
27996	Ring of Spiritual Precision
28024	Orion's Report
28025	Video Mount
28026	Crazy Cenarion Cloak
28027	Lunatic's Choker
28028	Moonstruck Bands
28029	Goldenvine Wraps
28030	Spell-slinger's Protector
28031	Nomad's Woven Cloak
28032	Delicate Green Poncho
28033	Epoch-Mender
28034	Hourglass of the Unraveller
28038	Seaforium PU-36 Explosive Nether Modulator
28039	Crude Explosives
28040	Vengeance of the Illidari
28041	Bladefist's Breadth
28042	Regal Protectorate
28043	Demon Stalker Pendant
28044	Band of the Demon Stalker
28045	Cloak of the Demon Stalker
28046	Legion Missive
28047	Nekrogg's Key
28048	Crude Explosives
28050	Sacred Feather Vest
28051	Jerkin of the Untamed Spirit
28052	Goldweave Tunic
28053	Wicked Arrow
28054	Fleshripper's Bladed Chestplate
28055	Gilded Crimson Chestplate
28056	Blackflight Arrow
28057	Bonechewer Berserker's Vest
28058	Shredded Wyrm Wing
28059	Iridescent Eye
28060	Impact Shot
28061	Ironbite Shell
28062	Expedition Repeater
28063	Survivalist's Wand
28064	Idol of the Wild
28065	Libram of Wracking
28066	Totem of Lightning
28068	Grimoire of Suffering (Rank 6)
28069	Golden Cenarion Greaves
28070	Verdant Handwraps
28071	Grimoire of Anguish (Rank 1)
28072	Grimoire of Anguish (Rank 2)
28073	Grimoire of Anguish (Rank 3)
28074	Studded Green Anklewraps
28075	Destroyers' Mantle
28099	Drillmaster Zurok's Orders
28100	Volatile Healing Potion
28101	Unstable Mana Potion
28102	Onslaught Elixir
28103	Adept's Elixir
28104	Elixir of Mastery
28105	Duron's Report
28106	Kingston's Primers
28107	Legion Missive
28108	Power Infused Mushroom
28109	Essence Infused Mushroom
28110	Fat Gnome and Little Elf
28111	Everlasting Underspore Frond
28112	Underspore Pod
28113	Warboss Nekrogg's Orders
28114	Warboss Nekrogg's Orders
28116	Zeppelin Debris
28118	Runed Ornate Ruby
28119	Smooth Ornate Dawnstone
28120	Gleaming Ornate Dawnstone
28121	Icon of Unyielding Courage
28123	Potent Ornate Topaz
28124	Liar's Cord
28126	Gladiator's Dragonhide Gloves
28127	Gladiator's Dragonhide Helm
28128	Gladiator's Dragonhide Legguards
28129	Gladiator's Dragonhide Spaulders
28130	Gladiator's Dragonhide Tunic
28131	Reaver Buster Launcher
28132	Area 52 Special
28134	Brooch of Heightened Potential
28135	Bomb Crate
28136	Gladiator's Wyrmhide Gloves
28137	Gladiator's Wyrmhide Helm
28138	Gladiator's Wyrmhide Legguards
28139	Gladiator's Wyrmhide Spaulders
28140	Gladiator's Wyrmhide Tunic
28141	Ranger's Sash
28142	Farstrider's Belt
28143	Rusted Chain Girdle
28144	Troll Handler Gloves
28145	Tranquillien Wraps
28146	Courier's Wraps
28147	Tranquillien Scout's Bracers
28148	Bronze Mail Bracers
28149	Tranquillien Breeches
28150	Renzithen's Dusty Cloak
28151	Arcanist's Wand
28152	Quel'Thalas Recurve
28153	Farstrider's Shield
28154	Red Silk Trousers
28155	Apothecary's Waistband
28156	Rotting Handwraps
28157	Black Leather Jerkin
28158	Batskin Belt
28159	Undertaker's Gloves
28160	An'telas Scale Shirt
28161	Tranquillien Scale Leggings
28162	Tranquillien Defender's Girdle
28163	Maltendis's Handguards
28164	Tranquillien Flamberge
28166	Shield of the Void
28167	Sha'tari Wrought Armguards
28168	Insignia of the Mag'hari Hero
28169	Mag'hari Ritualist's Horns
28170	Auchenai Bracers
28171	Spymistress's Wristguards
28172	Mag'hari Scout's Tunic
28173	Mag'hari Huntsman's Leggings
28174	Shattrath Wraps
28175	Mag'hari Warlord's Legplates
28176	Sha'tari Wrought Greaves
28177	Auchenai Boots
28178	Spymistress's Boots
28179	Shattrath Jumpers
28180	Myrmidon's Headdress
28181	Earthwarden's Coif
28182	Helm of the Claw
28183	Hydromancer's Headwrap
28184	Millennium Blade
28185	Khadgar's Kilt of Abjuration
28186	Laughing Skull Battle-Harness
28187	Star-Heart Lamp
28188	Bloodfire Greatstaff
28189	Latro's Shifting Sword
28190	Scarab of the Infinite Cycle
28191	Mana-Etched Vestments
28192	Helm of Desolation
28193	Mana-Etched Crown
28194	Primal Surge Bracers
28202	Moonglade Robe
28203	Breastplate of the Righteous
28204	Tunic of Assassination
28205	Breastplate of the Bold
28206	Cowl of the Guiltless
28207	Pauldrons of the Crimson Flight
28210	Bloodskull Destroyer
28211	Lieutenant's Signet of Lordaeron
28212	Aran's Sorcerous Slacks
28213	Lordaeron Medical Guide
28214	Grips of the Lunar Eclipse
28215	Mok'Nathal Mask of Battle
28216	Dathrohan's Ceremonial Hammer
28217	Tarren Mill Vitality Locket
28218	Pontiff's Pantaloons of Prophecy
28219	Emerald-Scale Greaves
28220	Moon-Crown Antlers
28221	Boots of the Watchful Heart
28222	Reaver of the Infinites
28223	Arcanist's Stone
28224	Wastewalker Helm
28225	Doomplate Warhelm
28226	Timeslicer
28227	Sparking Arcanite Ring
28228	Beast Lord Cuirass
28229	Incanter's Robe
28230	Hallowed Garments
28231	Tidefury Chestpiece
28232	Robe of Oblivion
28233	Necklace of Resplendent Hope
28234	Medallion of the Alliance
28235	Medallion of the Alliance
28236	Medallion of the Alliance
28237	Medallion of the Alliance
28238	Medallion of the Alliance
28239	Medallion of the Horde
28240	Medallion of the Horde
28241	Medallion of the Horde
28242	Medallion of the Horde
28243	Medallion of the Horde
28244	Pendant of Triumph
28245	Pendant of Dominance
28246	Band of Triumph
28247	Band of Dominance
28248	Totem of the Void
28249	Capacitus' Cloak of Calibration
28250	Vestia's Pauldrons of Inner Grace
28251	Boots of the Glade-Keeper
28252	Bloodfyre Robes of Annihilation
28253	Plasma Rat's Hyper-Scythe
28254	Warp Engineer's Prismatic Chain
28255	Lunar-Claw Pauldrons
28256	Thoriumweave Cloak
28257	Hammer of the Penitent
28258	Nethershrike
28259	Cosmic Lifeband
28260	Manual of the Nethermancer
28261	Video Invis
28262	Jade-Skull Breastplate
28263	Stellaris
28264	Wastewalker Tunic
28265	Dath'Remar's Ring of Defense
28266	Molten Earth Kilt
28267	Edge of the Cosmos
28268	Natural Mender's Wraps
28269	Baba's Cloak of Arcanistry
28270	Formula: Enchant Chest - Major Resilience
28271	Formula: Enchant Gloves - Spell Strike
28272	Formula: Enchant Gloves - Major Spellpower
28273	Formula: Enchant Gloves - Major Healing
28274	Formula: Enchant Cloak - Spell Penetration
28275	Beast Lord Helm
28276	Formula: Enchant Cloak - Greater Arcane Resistance
28277	Formula: Enchant Cloak - Greater Shadow Resistance
28278	Incanter's Cowl
28279	Formula: Enchant Boots - Cat's Swiftness
28280	Formula: Enchant Boots - Boar's Speed
28281	Formula: Enchant Weapon - Major Healing
28282	Formula: Enchant Shield - Major Stamina
28283	Soul Mirror
28284	Don Carlos Tequila
28285	Helm of the Righteous
28286	Telescopic Sharprifle
28287	Vial of Sedative Serum
28288	Abacus of Violent Odds
28289	Dargonhawk Whistle
28290	Smooth Golden Draenite
28291	Design: Smooth Golden Draenite
28292	Archmage Vargoth's Staff
28293	High Warlord's Claymore
28294	Gladiator's Heavy Crossbow
28295	Gladiator's Slicer
28296	Libram of the Lightbringer
28297	Gladiator's Spellblade
28298	Gladiator's Decapitator
28299	Gladiator's Bonegrinder
28300	Gladiator's Painsaw
28301	Syrannis' Mystic Sheen
28302	Gladiator's Bonecracker
28303	Invoker's Signet
28304	Prismatic Mittens of Mending
28305	Gladiator's Pummeler
28306	Towering Mantle of the Hunt
28307	Gladiator's Quickblade
28308	Gladiator's Cleaver
28309	Gladiator's Hacker
28310	Gladiator's Shiv
28311	Revenger
28312	Gladiator's Shanker
28313	Gladiator's Right Ripper
28314	Gladiator's Left Ripper
28315	Stormreaver Warblades
28316	Aegis of the Sunbird
28317	Energis Armwraps
28318	Obsidian Clodstompers
28319	Gladiator's War Edge
28320	Gladiator's Touch of Defeat
28321	Enchanted Thorium Torque
28322	Runed Dagger of Solace
28323	Ring of Umbral Doom
28324	Gauntlets of Cruel Intention
28325	Dreamer's Dragonstaff
28327	Arcane Netherband
28328	Mithril-Bark Cloak
28331	Gladiator's Chain Helm
28332	Gladiator's Chain Leggings
28333	Gladiator's Chain Spaulders
28334	Gladiator's Chain Armor
28335	Gladiator's Chain Gauntlets
28336	Belmara's Tome
28337	Breastplate of Righteous Fury
28338	Devil-Stitched Leggings
28339	Boots of the Shifting Sands
28340	Mantle of Autumn
28341	Warpstaff of Arcanum
28342	Warp Infused Drape
28343	Jagged Bark Pendant
28344	Wyrmfury Pauldrons
28345	Warp Splinter's Thorn
28346	Gladiator's Endgame
28347	Warpscale Leggings
28348	Moonglade Cowl
28349	Tidefury Helm
28350	Warhelm of the Bold
28351	Dathric's Blade
28352	Luminrath's Mantle
28353	Cohlien's Cap
28355	Gladiator's Idol of Tenacity
28356	Gladiator's Libram of Justice
28357	Gladiator's Totem of the Third Wind
28358	Gladiator's Shield Wall
28359	Netherologist's Notes
28360	Mighty Blood Garnet
28361	Mighty Blood Garnet
28362	Bold Ornate Ruby
28363	Inscribed Ornate Topaz
28364	Etherlithium Matrix Crystal
28367	Greatsword of Forlorn Visions
28368	Sigil of Krasus
28369	Battery Recharging Blaster
28370	Bangle of Endless Blessings
28371	Netherfury Cape
28372	Idol of Feral Shadows
28373	Cloak of Scintillating Auras
28374	Mana-Sphere Shoulderguards
28375	Rubium War-Girdle
28376	B'naar Personnel Roster
28377	Sergeant's Heavy Cloak
28378	Sergeant's Heavy Cape
28379	Sergeant's Heavy Cape
28380	Sergeant's Heavy Cloak
28381	General's Plate Bracers
28383	General's Plate Greaves
28384	Outland Striders
28385	General's Plate Belt
28386	Nether Core's Control Rod
28387	Lamp of Peaceful Repose
28390	Thatia's Self-Correcting Gauntlets
28391	Worldfire Chestguard
28392	Reflex Blades
28393	Warmaul of Infused Light
28394	Ryngo's Band of Ingenuity
28395	Shattered Halls Key
28396	Gloves of the Unbound
28397	Emberhawk Crossbow
28398	The Sleeper's Cord
28399	Filtered Draenic Water
28400	Warp-Storm Warblade
28401	Hauberk of Desolation
28402	General's Dreadweave Stalkers
28403	Doomplate Chestguard
28404	General's Dreadweave Belt
28405	General's Dreadweave Cuffs
28406	Sigil-Laced Boots
28407	Elementium Band of the Sentry
28408	Broken Silver Star
28409	General's Silk Belt
28410	General's Silk Footguards
28411	General's Silk Cuffs
28412	Lamp of Peaceful Radiance
28413	Hallowed Crown
28414	Helm of Assassination
28415	Hood of Oblivion
28416	Hungering Spineripper
28417	Nether Ray Stinger
28418	Shiffar's Nexus-Horn
28419	Choker of Fluid Thought
28420	Fel Weightstone
28421	Adamantite Weightstone
28422	General's Leather Boots
28423	General's Leather Belt
28424	General's Leather Bracers
28425	Fireguard
28426	Blazeguard
28427	Blazefury
28428	Lionheart Blade
28429	Lionheart Champion
28430	Lionheart Executioner
28431	The Planar Edge
28432	Black Planar Edge
28433	Wicked Edge of the Planes
28434	Lunar Crescent
28435	Mooncleaver
28436	Bloodmoon
28437	Drakefist Hammer
28438	Dragonmaw
28439	Dragonstrike
28440	Thunder
28441	Deep Thunder
28442	Stormherald
28443	General's Dragonhide Belt
28444	General's Dragonhide Boots
28445	General's Dragonhide Bracers
28446	General's Wyrmhide Belt
28447	General's Wyrmhide Boots
28448	General's Wyrmhide Bracers
28449	General's Chain Sabatons
28450	General's Chain Girdle
28451	General's Chain Bracers
28452	Bloodgem Shard
28453	Bracers of the White Stag
28454	Stalker's War Bands
28455	Archmage Vargoth's Staff
28457	Ethereal Technology
28458	Bold Tourmaline
28459	Delicate Tourmaline
28460	Teardrop Tourmaline
28461	Runed Tourmaline
28462	Bright Tourmaline
28463	Solid Zircon
28464	Sparkling Zircon
28465	Lustrous Zircon
28466	Brilliant Amber
28467	Smooth Amber
28468	Rigid Amber
28469	Gleaming Amber
28470	Thick Amber
28471	Krasus' Compendium
28472	Krasus's Compendium - Chapter 1
28473	Krasus's Compendium - Chapter 2
28474	Krasus's Compendium - Chapter 3
28475	Heliotrope Oculus
28476	Gladiator's Maul
28477	Harbinger Bands
28478	To'arch's Primers
28479	Stone of Glacius
28481	Brown Elekk
28482	Great Elite Elekk
28483	Breastplate of Kings
28484	Bulwark of Kings
28485	Bulwark of the Ancient Kings
28486	Moser's Magnificent Muffin
28490	Shaffar's Wrappings
28491	Windwalker's Footwraps
28492	Talonite's Boots
28493	Dreadhawk's Schynbald
28494	Ravenguard's Greaves
28495	Windwalker's Sash
28496	Talonite's Belt
28497	Dreadhawk's Girdle
28498	Ravenguard's Baldric
28499	Arakkoa Hunter's Supplies
28500	Fossil Oil
28501	Ravager Egg Omelet
28502	Vambraces of Courage
28503	Whirlwind Bracers
28504	Steelhawk Crossbow
28505	Gauntlets of Renewed Hope
28506	Gloves of Dexterous Manipulation
28507	Handwraps of Flowing Thought
28508	Gloves of Saintly Blessings
28509	Worgen Claw Necklace
28510	Spectral Band of Innervation
28511	Bands of Indwelling
28512	Bracers of Justice
28513	Demonic Rune Stone
28514	Bracers of Maliciousness
28515	Bands of Nefarious Deeds
28516	Barbed Choker of Discipline
28517	Boots of Foretelling
28518	Iron Gauntlets of the Maiden
28519	Gloves of Quickening
28520	Gloves of Centering
28521	Mitts of the Treemender
28522	Shard of the Virtuous
28523	Totem of Healing Rains
28524	Emerald Ripper
28525	Signet of Unshakable Faith
28526	Etherlithium Matrix Crystals
28527	Mana Wraith Essence
28528	Moroes' Lucky Pocket Watch
28529	Royal Cloak of Arathi Kings
28530	Brooch of Unquenchable Fury
28531	Barbed Shrike
28532	Silver Throwing Knifes
28533	Wooden Boomerang
28534	Fel Tipped Dart
28535	Amani Throwing Axe
28536	Jagged Guillotine
28537	Wildhammer Throwing Axe
28538	Forked Shuriken
28539	Razor-Edged Boomerang
28540	Arakkoa Talon-Axe
28541	Sawshrike
28542	Heartseeker Knives
28543	Dreghood Throwing Axe
28544	Assassin's Shuriken
28545	Edgewalker Longboots
28547	Elemental Power Extractor
28548	Elemental Power
28549	Armory History
28550	Flaming Torch
28551	Fel Reaver Part
28552	A Mysterious Tome
28553	Band of the Exorcist
28554	Shredder Spare Parts
28555	Seal of the Exorcist
28556	Swift Windfire Diamond
28557	Swift Starfire Diamond
28558	Spirit Shard
28559	Exorcist's Plate Helm
28560	Exorcist's Lamellar Helm
28561	Exorcist's Leather Helm
28562	Unyielding Battle Horn
28563	Doomclaw's Hand
28564	Energy Isolation Cube
28565	Nethershard Girdle
28566	Crimson Girdle of the Indomitable
28567	Belt of Gale Force
28568	Idol of the Avian Heart
28569	Boots of Valiance
28570	Shadow-Cloak of Dalaran
28571	Blank Scroll
28572	Blade of the Unrequited
28573	Despair
28574	Exorcist's Dragonhide Helm
28575	Exorcist's Wyrmhide Helm
28576	Exorcist's Chain Helm
28577	Exorcist's Linked Helm
28578	Masquerade Gown
28579	Romulo's Poison Vial
28580	B'naar Console Transcription
28581	Wolfslayer Sniper Rifle
28582	Red Riding Hood's Cloak
28583	Big Bad Wolf's Head
28584	Big Bad Wolf's Paw
28585	Ruby Slippers
28586	Wicked Witch's Hat
28587	Legacy
28588	Blue Diamond Witchwand
28589	Beastmaw Pauldrons
28590	Ribbon of Sacrifice
28591	Earthsoul Leggings
28592	Libram of Souls Redeemed
28593	Eternium Greathelm
28594	Trial-Fire Trousers
28595	Bright Blood Garnet
28596	Design: Bright Blood Garnet
28597	Panzar'Thar Breastplate
28598	Fel Reaver Construction Manual
28599	Scaled Breastplate of Carnage
28600	Stonebough Jerkin
28601	Chestguard of the Conniver
28602	Robe of the Elder Scribes
28603	Talisman of Nightbane
28604	Nightstaff of the Everliving
28605	General's Linked Bracers
28606	Shield of Impenetrable Darkness
28607	Sunfury Disguise
28608	Ironstriders of Urgency
28609	Emberspur Talisman
28610	Ferocious Swift-Kickers
28611	Dragonheart Flameshield
28612	Pauldrons of the Solace-Giver
28613	Grand Marshal's Chain Armor
28614	Grand Marshal's Chain Gauntlets
28615	Grand Marshal's Chain Helm
28616	Grand Marshal's Chain Leggings
28617	Grand Marshal's Chain Spaulders
28618	Grand Marshal's Dragonhide Gloves
28619	Grand Marshal's Dragonhide Helm
28620	Grand Marshal's Dragonhide Legguards
28621	Wrynn Dynasty Greaves
28622	Grand Marshal's Dragonhide Spaulders
28623	Grand Marshal's Dragonhide Tunic
28624	Grand Marshal's Dreadweave Gloves
28625	Grand Marshal's Dreadweave Hood
28626	Grand Marshal's Dreadweave Leggings
28627	Grand Marshal's Dreadweave Mantle
28628	Grand Marshal's Dreadweave Robe
28629	General's Linked Girdle
28630	General's Linked Sabatons
28631	Dragon-Quake Shoulderguards
28632	Plans: Adamantite Weightstone
28633	Staff of Infinite Mysteries
28634	Scrap Reaver X6000 Controller
28635	Sunfury Arcanist Robes
28636	Sunfury Researcher Gloves
28637	Sunfury Guardsman Medallion
28638	General's Mail Bracers
28639	General's Mail Girdle
28640	General's Mail Sabatons
28641	General's Lamellar Belt
28642	General's Lamellar Greaves
28643	General's Lamellar Bracers
28644	General's Scaled Belt
28645	General's Scaled Greaves
28646	General's Scaled Bracers
28647	Forest Wind Shoulderpads
28649	Garona's Signet Ring
28651	Unyielding Battle Horn
28652	Cincture of Will
28653	Shadowvine Cloak of Infusion
28654	Malefic Girdle
28655	Cord of Nature's Sustenance
28656	Girdle of the Prowler
28657	Fool's Bane
28658	Terestian's Stranglestaff
28659	Xavian Stiletto
28660	Gilded Thorium Cloak
28661	Mender's Heart-Ring
28662	Breastplate of the Lightbinder
28663	Boots of the Incorrupt
28664	Nitrin's Instructions
28665	Mountain Gronn Eyeball
28666	Pauldrons of the Justice-Seeker
28667	Flawless Greater Windroc Beak
28668	Aged Clefthoof Blubber
28669	Rapscallion Boots
28670	Boots of the Infernal Coven
28671	Steelspine Faceguard
28672	Drape of the Dark Reavers
28673	Tirisfal Wand of Ascendancy
28674	Saberclaw Talisman
28675	Shermanar Great-Ring
28676	Heart of Urtrak
28677	The Book of the Dead
28679	Grand Marshal's Lamellar Chestpiece
28680	Grand Marshal's Lamellar Gauntlets
28681	Grand Marshal's Lamellar Helm
28683	Grand Marshal's Lamellar Shoulders
28684	Grand Marshal's Leather Gloves
28685	Grand Marshal's Leather Helm
28686	Grand Marshal's Leather Legguards
28687	Grand Marshal's Leather Spaulders
28688	Grand Marshal's Leather Tunic
28689	Grand Marshal's Linked Armor
28690	Grand Marshal's Linked Gauntlets
28691	Grand Marshal's Linked Helm
28692	Grand Marshal's Linked Leggings
28693	Grand Marshal's Linked Spaulders
28694	Grand Marshal's Mail Armor
28695	Grand Marshal's Mail Gauntlets
28696	Grand Marshal's Mail Helm
28697	Grand Marshal's Mail Leggings
28698	Grand Marshal's Mail Spaulders
28699	Grand Marshal's Plate Chestpiece
28700	Grand Marshal's Plate Gauntlets
28701	Grand Marshal's Plate Helm
28702	Grand Marshal's Plate Legguards
28703	Grand Marshal's Plate Shoulders
28704	Grand Marshal's Satin Gloves
28705	Grand Marshal's Satin Hood
28706	Grand Marshal's Satin Leggings
28707	Grand Marshal's Satin Mantle
28708	Grand Marshal's Satin Robe
28709	Grand Marshal's Scaled Chestpiece
28710	Grand Marshal's Scaled Gauntlets
28711	Grand Marshal's Scaled Helm
28712	Grand Marshal's Scaled Legguards
28713	Grand Marshal's Scaled Shoulders
28714	Grand Marshal's Silk Amice
28715	Grand Marshal's Silk Cowl
28716	Grand Marshal's Silk Handguards
28717	Grand Marshal's Silk Raiment
28718	Grand Marshal's Silk Trousers
28719	Grand Marshal's Wyrmhide Gloves
28720	Grand Marshal's Wyrmhide Helm
28721	Grand Marshal's Wyrmhide Legguards
28722	Grand Marshal's Wyrmhide Spaulders
28723	Grand Marshal's Wyrmhide Tunic
28724	Grand Marshal's Lamellar Legguards
28725	Rune Activation Device
28726	Mantle of the Mind Flayer
28727	Pendant of the Violet Eye
28728	Aran's Soothing Sapphire
28729	Spiteblade
28730	Mithril Band of the Unscarred
28731	Shining Chain of the Afterworld
28732	Cowl of Defiance
28733	Girdle of Truth
28734	Jewel of Infinite Possibilities
28735	Earthblood Chestguard
28740	Rip-Flayer Leggings
28741	Skulker's Greaves
28742	Pantaloons of Repentance
28743	Mantle of Abrahmis
28744	Uni-Mind Headdress
28745	Mithril Chain of Heroism
28746	Fiend Slayer Boots
28747	Battlescar Boots
28748	Legplates of the Innocent
28749	King's Defender
28750	Girdle of Treachery
28751	Heart-Flame Leggings
28752	Forestlord Striders
28753	Ring of Recurrence
28754	Triptych Shield of the Ancients
28755	Bladed Shoulderpads of the Merciless
28756	Headdress of the High Potentate
28757	Ring of a Thousand Marks
28758	Exorcist's Mail Helm
28759	Exorcist's Dreadweave Hood
28760	Exorcist's Silk Hood
28761	Exorcist's Scaled Helm
28762	Adornment of Stolen Souls
28763	Jade Ring of the Everliving
28764	Farstrider Wildercloak
28765	Stainless Cloak of the Pure Hearted
28766	Ruby Drape of the Mysticant
28767	The Decapitator
28768	Malchazeen
28769	The Keystone
28770	Nathrezim Mindblade
28771	Light's Justice
28772	Sunfury Bow of the Phoenix
28773	Gorehowl
28774	Glaive of the Pit
28775	Thundering Greathelm
28776	Liar's Tongue Gloves
28777	Cloak of the Pit Stalker
28778	Terror Pit Girdle
28779	Girdle of the Endless Pit
28780	Soul-Eater's Handwraps
28781	Karaborian Talisman
28782	Crystalheart Pulse-Staff
28783	Eredar Wand of Obliteration
28784	Unyielding Banner Scrap
28785	The Lightning Capacitor
28786	Apex's Crystal Focus
28787	Annihilator Servo
28788	Tabard of the Protector
28789	Eye of Magtheridon
28790	Naaru Lightwarden's Band
28791	Ring of the Recalcitrant
28792	A'dal's Signet of Defense
28793	Band of Crimson Fury
28794	Axe of the Gronn Lords
28795	Bladespire Warbands
28796	Malefic Mask of the Shadows
28797	Brute Cloak of the Ogre-Magi
28798	Badge of the Protector
28799	Belt of Divine Inspiration
28800	Hammer of the Naaru
28801	Maulgar's Warhelm
28802	Bloodmaw Magus-Blade
28803	Cowl of Nature's Breath
28804	Collar of Cho'gall
28805	High Warlord's Chain Armor
28806	High Warlord's Chain Gauntlets
28807	High Warlord's Chain Helm
28808	High Warlord's Chain Leggings
28809	High Warlord's Chain Spaulders
28810	Windshear Boots
28811	High Warlord's Dragonhide Gloves
28812	High Warlord's Dragonhide Helm
28813	High Warlord's Dragonhide Legguards
28814	High Warlord's Dragonhide Spaulders
28815	High Warlord's Dragonhide Tunic
28817	High Warlord's Dreadweave Gloves
28818	High Warlord's Dreadweave Hood
28819	High Warlord's Dreadweave Leggings
28820	High Warlord's Dreadweave Mantle
28821	High Warlord's Dreadweave Robe
28822	Teeth of Gruul
28823	Eye of Gruul
28824	Gauntlets of Martial Perfection
28825	Aldori Legacy Defender
28826	Shuriken of Negation
28827	Gauntlets of the Dragonslayer
28828	Gronn-Stitched Girdle
28829	Arklon Crystal Artifact
28830	Dragonspine Trophy
28831	High Warlord's Lamellar Chestpiece
28832	High Warlord's Lamellar Gauntlets
28833	High Warlord's Lamellar Helm
28834	High Warlord's Lamellar Legguards
28835	High Warlord's Lamellar Shoulders
28836	High Warlord's Leather Gloves
28837	High Warlord's Leather Helm
28838	High Warlord's Leather Legguards
28839	High Warlord's Leather Spaulders
28840	High Warlord's Leather Tunic
28841	High Warlord's Linked Armor
28842	High Warlord's Linked Gauntlets
28843	High Warlord's Linked Helm
28844	High Warlord's Linked Leggings
28845	High Warlord's Linked Spaulders
28846	High Warlord's Mail Armor
28847	High Warlord's Mail Gauntlets
28848	High Warlord's Mail Helm
28849	High Warlord's Mail Leggings
28850	High Warlord's Mail Spaulders
28851	High Warlord's Plate Chestpiece
28852	High Warlord's Plate Gauntlets
28853	High Warlord's Plate Helm
28854	High Warlord's Plate Legguards
28855	High Warlord's Plate Shoulders
28856	High Warlord's Satin Gloves
28857	High Warlord's Satin Hood
28858	High Warlord's Satin Leggings
28859	High Warlord's Satin Mantle
28860	High Warlord's Satin Robe
28861	High Warlord's Scaled Chestpiece
28862	High Warlord's Scaled Gauntlets
28863	High Warlord's Scaled Helm
28864	High Warlord's Scaled Legguards
28865	High Warlord's Scaled Shoulders
28866	High Warlord's Silk Amice
28867	High Warlord's Silk Cowl
28868	High Warlord's Silk Handguards
28869	High Warlord's Silk Raiment
28870	High Warlord's Silk Trousers
28871	High Warlord's Wyrmhide Gloves
28872	High Warlord's Wyrmhide Helm
28873	High Warlord's Wyrmhide Legguards
28874	High Warlord's Wyrmhide Spaulders
28875	High Warlord's Wyrmhide Tunic
28878	Inscription of Faith
28881	Inscription of Discipline
28882	Inscription of Warding
28885	Inscription of Vengeance
28886	Greater Inscription of Discipline
28887	Greater Inscription of Faith
28888	Greater Inscription of Vengeance
28889	Greater Inscription of Warding
28903	Inscription of the Orb
28904	Inscription of the Oracle
28907	Inscription of the Blade
28908	Inscription of the Knight
28909	Greater Inscription of the Orb
28910	Greater Inscription of the Blade
28911	Greater Inscription of the Knight
28912	Greater Inscription of the Oracle
28913	Box of Surveying Equipment
28915	Reins of the Dark Riding Talbuk
28917	High Warlord's Bonegrinder
28918	High Warlord's Decapitator
28919	High Warlord's Maul
28920	High Warlord's Cleaver
28921	High Warlord's Hacker
28922	High Warlord's Left Ripper
28923	High Warlord's Painsaw
28924	High Warlord's Bonecracker
28925	High Warlord's Pummeler
28926	High Warlord's Quickblade
28927	Red Hawkstrider
28928	High Warlord's Right Ripper
28929	High Warlord's Shanker
28930	High Warlord's Shiv
28931	High Warlord's Spellblade
28933	High Warlord's Heavy Crossbow
28934	Surveying Equipment
28935	High Warlord's War Staff
28936	Swift Pink Hawkstrider
28937	High Warlord's Slicer
28938	High Warlord's Battletome
28939	High Warlord's Barricade
28940	Grand Marshal's Barricade
28941	Grand Marshal's Battletome
28942	Grand Marshal's Bonegrinder
28943	Grand Marshal's Warblade
28944	Grand Marshal's Cleaver
28945	Grand Marshal's Decapitator
28946	Grand Marshal's Hacker
28947	Grand Marshal's Left Ripper
28948	Grand Marshal's Maul
28949	Grand Marshal's Painsaw
28950	Grand Marshal's Bonecracker
28951	Grand Marshal's Pummeler
28952	Grand Marshal's Quickblade
28953	Grand Marshal's Right Ripper
28954	Grand Marshal's Shanker
28955	Grand Marshal's Shiv
28956	Grand Marshal's Slicer
28957	Grand Marshal's Spellblade
28959	Grand Marshal's War Staff
28960	Grand Marshal's Heavy Crossbow
28962	Triangulation Device
28963	Voidheart Crown
28964	Voidheart Robe
28966	Voidheart Leggings
28967	Voidheart Mantle
28968	Voidheart Gloves
28969	Teleporter Power Pack
28970	Nether Dragon Essence
28971	Nether Dragonkin Egg
28972	Flightblade Throwing Axe
28973	Marshal's Chain Bracers
28974	Marshal's Chain Girdle
28975	Marshal's Chain Sabatons
28976	Marshal's Dragonhide Belt
28977	Marshal's Dragonhide Boots
28978	Marshal's Dragonhide Bracers
28979	Light Throwing Knife
28980	Marshal's Dreadweave Belt
28981	Marshal's Dreadweave Cuffs
28982	Marshal's Dreadweave Stalkers
28983	Marshal's Lamellar Belt
28984	Marshal's Lamellar Bracers
28985	Marshal's Lamellar Greaves
28986	Marshal's Leather Belt
28987	Marshal's Leather Boots
28988	Marshal's Leather Bracers
28989	Marshal's Linked Bracers
28990	Marshal's Linked Girdle
28991	Marshal's Linked Sabatons
28992	Marshal's Mail Bracers
28993	Marshal's Mail Girdle
28994	Marshal's Mail Sabatons
28995	Marshal's Plate Belt
28996	Marshal's Plate Bracers
28997	Marshal's Plate Greaves
28998	Marshal's Scaled Belt
28999	Marshal's Scaled Bracers
29000	Marshal's Scaled Greaves
29001	Marshal's Silk Belt
29002	Marshal's Silk Cuffs
29003	Marshal's Silk Footguards
29004	Marshal's Wyrmhide Belt
29005	Marshal's Wyrmhide Boots
29006	Marshal's Wyrmhide Bracers
29007	Weighted Throwing Axe
29008	Sharp Throwing Axe
29009	Heavy Throwing Dagger
29010	Wicked Throwing Dagger
29011	Warbringer Greathelm
29012	Warbringer Chestguard
29013	Jagged Throwing Axe
29014	Blacksteel Throwing Dagger
29015	Warbringer Legguards
29016	Warbringer Shoulderguards
29017	Warbringer Handguards
29018	Triangulation Device
29019	Warbringer Breastplate
29020	Warbringer Gauntlets
29021	Warbringer Battle-Helm
29022	Warbringer Greaves
29023	Warbringer Shoulderplates
29024	Eye of the Storm Mark of Honor
29026	Ata'mal Crystal
29027	Unstable Warp Rift Generator
29028	Cyclone Headdress
29029	Cyclone Hauberk
29030	Cyclone Kilt
29031	Cyclone Shoulderpads
29032	Cyclone Gloves
29033	Cyclone Chestguard
29034	Cyclone Handguards
29035	Cyclone Faceguard
29036	Cyclone Legguards
29037	Cyclone Shoulderguards
29038	Cyclone Breastplate
29039	Cyclone Gauntlets
29040	Cyclone Helm
29041	Draenethyst Crystal of Command
29042	Cyclone War-Kilt
29043	Cyclone Shoulderplates
29044	Netherblade Facemask
29045	Netherblade Chestpiece
29046	Netherblade Breeches
29047	Netherblade Shoulderpads
29048	Netherblade Gloves
29049	Light-Collar of the Incarnate
29050	Robes of the Incarnate
29051	Warp Nether
29052	Warp Nether Extractor
29053	Trousers of the Incarnate
29054	Light-Mantle of the Incarnate
29055	Handwraps of the Incarnate
29056	Shroud of the Incarnate
29057	Gloves of the Incarnate
29058	Soul-Collar of the Incarnate
29059	Leggings of the Incarnate
29060	Soul-Mantle of the Incarnate
29061	Justicar Diadem
29062	Justicar Chestpiece
29063	Justicar Leggings
29064	Justicar Pauldrons
29065	Justicar Gloves
29066	Justicar Chestguard
29067	Justicar Handguards
29068	Justicar Faceguard
29069	Justicar Legguards
29070	Justicar Shoulderguards
29071	Justicar Breastplate
29072	Justicar Gauntlets
29073	Justicar Crown
29074	Justicar Greaves
29075	Justicar Shoulderplates
29076	Collar of the Aldor
29077	Vestments of the Aldor
29078	Legwraps of the Aldor
29079	Pauldrons of the Aldor
29080	Gloves of the Aldor
29081	Demon Stalker Greathelm
29082	Demon Stalker Harness
29083	Demon Stalker Greaves
29084	Demon Stalker Shoulderguards
29085	Demon Stalker Gauntlets
29086	Crown of Malorne
29087	Chestguard of Malorne
29088	Legguards of Malorne
29089	Shoulderguards of Malorne
29090	Handguards of Malorne
29091	Chestpiece of Malorne
29092	Gloves of Malorne
29093	Antlers of Malorne
29094	Britches of Malorne
29095	Pauldrons of Malorne
29096	Breastplate of Malorne
29097	Gauntlets of Malorne
29098	Stag-Helm of Malorne
29099	Greaves of Malorne
29100	Mantle of Malorne
29101	Challenge of the Blue Flight
29102	Reins of the Cobalt War Talbuk
29103	Reins of the White War Talbuk
29104	Reins of the Silver War Talbuk
29105	Reins of the Tan War Talbuk
29106	Ata'mal Crystal
29108	Blade of the Unyielding
29109	Rod of the Unyielding
29110	Ruined Scented Candle
29111	Box of Stale Candy
29112	Cenarion Spirits
29113	Demonic Essence
29115	Consortium Blaster
29116	Nomad's Leggings
29117	Stormspire Vest
29118	Smuggler's Ammo Pouch
29119	Haramad's Bargain
29120	Pattern: Truefaith Vestments
29121	Guile of Khoraazi
29122	Nether Runner's Cowl
29123	Medallion of the Lightbearer
29124	Vindicator's Brand
29125	Retainer's Blade
29126	Seer's Signet
29127	Vindicator's Hauberk
29128	Lightwarden's Band
29129	Anchorite's Robes
29130	Auchenai Staff
29131	Retainer's Leggings
29132	Scryer's Bloodgem
29133	Seer's Cane
29134	Gauntlets of the Chosen
29135	Earthcaller's Headdress
29136	Far Seer's Helm
29137	Hellscream's Will
29138	Arechron's Gift
29139	Ceremonial Cover
29140	Cloak of the Ancient Spirits
29141	Tempest Leggings
29142	Kurenai Kilt
29143	Clefthoof Hide Quiver
29144	Worg Hide Quiver
29145	Band of Ancestral Spirits
29146	Band of Elemental Spirits
29147	Talbuk Hide Spaulders
29148	Blackened Leather Spaulders
29149	Sporeling's Firestick
29150	Hardened Stone Shard
29151	Veteran's Musket
29152	Marksman's Bow
29153	Blade of the Archmage
29154	Legion Cannon
29155	Stormcaller
29156	Honor's Call
29157	Golden Ring of Power
29158	Truesilver Commander's Ring
29159	Glowing Thorium Band
29160	Emerald Lion Ring
29161	Void Ridge Soul Shard
29162	Galaxis Soul Shard
29163	Raw Farahlite
29164	Farahlite Core
29165	Warbringer
29166	Hellforged Halberd
29167	Blackened Spear
29168	Ancestral Band
29169	Ring of Convalescence
29170	Windcaller's Orb
29171	Earthwarden
29172	Ashyen's Gift
29173	Strength of the Untamed
29174	Watcher's Cowl
29175	Gavel of Pure Light
29176	Crest of the Sha'tar
29177	A'dal's Command
29179	Xi'ri's Gift
29180	Blessed Scale Girdle
29181	Timelapse Shard
29182	Riftmaker
29183	Bindings of the Timewalker
29184	Timewarden's Leggings
29185	Continuum Blade
29186	Glyph of the Defender
29187	Inscription of Endurance
29189	Glyph of Renewal
29190	Glyph of Renewal
29191	Glyph of Power
29192	Glyph of Ferocity
29193	Glyph of the Gladiator
29194	Glyph of Nature Warding
29195	Glyph of Arcane Warding
29196	Glyph of Fire Warding
29197	Glyph of Fire Warding
29198	Glyph of Frost Warding
29199	Glyph of Shadow Warding
29200	Falfindel's Blaster
29201	Thick Bronze Darts
29202	Whirling Steel Axes
29203	Enchanted Thorium Blades
29204	Felsteel Whisper Knives
29205	Inquisitor's Crest - Top Half
29206	Inquisitor's Crest - Bottom Half
29207	Conjuring Powder
29209	Zaxxis Insignia
29210	Assassin's Throwing Axe
29211	Fitz's Throwing Axe
29212	Balanced Stone Dirk
29213	Pattern: Felstalker Belt
29214	Pattern: Felstalker Bracers
29215	Pattern: Felstalker Breastplate
29216	Flawless Crystal Shard
29217	Pattern: Netherfury Belt
29218	Pattern: Netherfury Boots
29219	Pattern: Netherfury Leggings
29220	Blue Hawkstrider
29221	Black Hawkstrider
29222	Purple Hawkstrider
29223	Swift Green Hawkstrider
29224	Swift Purple Hawkstrider
29226	Warp Rift Generator
29227	Reins of the Cobalt War Talbuk
29228	Reins of the Dark War Talbuk
29229	Reins of the Silver War Talbuk
29230	Reins of the Tan War Talbuk
29231	Reins of the White War Talbuk
29232	Recipe: Transmute Skyfire Diamond
29233	Dathric's Blade
29234	Belmara's Tome
29235	Luminrath's Mantle
29236	Cohlien's Cap
29237	Warpath Bracers
29238	Lion's Heart Girdle
29239	Eaglecrest Warboots
29240	Bands of Negation
29241	Belt of Depravity
29242	Boots of Blasphemy
29243	Wave-Fury Vambraces
29244	Wave-Song Girdle
29245	Wave-Crest Striders
29246	Nightfall Wristguards
29247	Girdle of the Deathdealer
29248	Shadowstep Striders
29249	Bands of the Benevolent
29250	Cord of Sanctification
29251	Boots of the Pious
29252	Bracers of Dignity
29253	Girdle of Valorous Deeds
29254	Boots of the Righteous Path
29255	Bands of Rarefied Magic
29257	Sash of Arcane Visions
29258	Boots of Ethereal Manipulation
29259	Bracers of the Hunt
29260	Heart of the Fel Reaver
29261	Girdle of Ferocity
29262	Boots of the Endless Hunt
29263	Forestheart Bracers
29264	Tree-Mender's Belt
29265	Barkchip Boots
29266	Azure-Shield of Coldarra
29267	Light-Bearer's Faith Shield
29268	Mazthoril Honor Shield
29269	Sapphiron's Wing Bone
29270	Flametongue Seal
29271	Talisman of Kalecgos
29272	Orb of the Soul-Eater
29273	Khadgar's Knapsack
29274	Tears of Heaven
29275	Searing Sunblade
29276	Violet Signet
29277	Violet Signet
29278	Violet Signet
29279	Violet Signet of the Great Protector
29280	Violet Signet
29281	Violet Signet
29282	Violet Signet
29283	Violet Signet of the Master Assassin
29284	Violet Signet
29285	Violet Signet
29286	Violet Signet
29287	Violet Signet of the Archmage
29288	Violet Signet
29289	Violet Signet
29290	Violet Signet of the Grand Restorer
29291	Violet Signet
29292	Helboar Bacon
29293	Bonestripper Buzzard Hotwings
29294	Band of Eternity
29295	Band of Eternity
29296	Band of Eternity
29297	Band of the Eternal Defender
29298	Band of Eternity
29299	Band of Eternity
29300	Band of Eternity
29301	Band of the Eternal Champion
29302	Band of Eternity
29303	Band of Eternity
29304	Band of Eternity
29305	Band of the Eternal Sage
29306	Band of Eternity
29307	Band of Eternity
29308	Band of Eternity
29309	Band of the Eternal Restorer
29311	Fel Reaver Construction Manual
29312	Cover of Righteous Fury
29313	Earthbreaker's Greaves
29314	Leggings of the Third Coin
29315	Gloves of Penitence
29316	Warchief's Mantle
29317	Tempest's Touch
29318	Southshore Sneakers
29319	Tarren Mill Defender's Cinch
29320	Band of the Guardian
29321	Time-bending Gem
29322	Keeper's Ring of Piety
29323	Andormu's Tear
29324	Warp-Attuned Orb
29325	Flesh Beast's Metal Greaves
29326	Consortium Mantle of Phasing
29327	Cryo-mitts
29328	Consortium Prince's Wrap
29329	Terokk's Quill
29330	The Saga of Terokk
29331	Annals of Kirin'Var
29332	Terokk's Mask
29333	Torc of the Sethekk Prophet
29334	Sethekk Oracle's Focus
29335	Talon Lord's Collar
29336	Mark of the Ravenguard
29337	The Exarch's Protector
29338	Loathsome Remnant
29339	Auchenai Tracker's Hauberk
29340	Auchenai Monk's Tunic
29341	Auchenai Anchorite's Robe
29342	Consortium Plated Legguards
29343	Haramad's Leggings of the Third Coin
29344	Haramad's Linked Chain Pantaloons
29345	Haramad's Leg Wraps
29346	Feltooth Eviscerator
29347	Talisman of the Breaker
29348	The Bladefist
29349	Adamantine Chain of the Unbroken
29350	The Black Stalk
29351	Wrathtide Longbow
29352	Cobalt Band of Tyrigosa
29353	Shockwave Truncheon
29354	Light-Touched Stole of Altruism
29355	Terokk's Shadowstaff
29356	Quantum Blade
29357	Master Thief's Gloves
29359	Feral Staff of Lashing
29360	Vileblade of the Betrayer
29361	Naberius's Phylactery
29362	The Sun Eater
29363	Mana Wyrmling
29364	Brown Rabbit Crate
29365	Smithing Hammer
29366	B'naar Access Crystal
29367	Ring of Cryptic Dreams
29368	Manasurge Pendant
29369	Shawl of Shifting Probabilities
29370	Icon of the Silver Crescent
29371	Nexus-Claw
29372	Void-Talon
29373	Band of Halos
29374	Necklace of Eternal Hope
29375	Bishop's Cloak
29376	Essence of the Martyr
29377	Ethereum Phase-Spear
29378	Starheart Baton
29379	Ring of Arathi Warlords
29380	Ethereum Phase Blade
29381	Choker of Vile Intent
29382	Blood Knight War Cloak
29383	Bloodlust Brooch
29384	Ring of Unyielding Force
29385	Farstrider Defender's Cloak
29386	Necklace of the Juggernaut
29387	Gnomeregan Auto-Blocker 600
29388	Libram of Repentance
29389	Totem of the Pulsing Earth
29390	Everbloom Idol
29391	Pulse Dagger
29393	Diamond Berries
29394	Lyribread
29395	Ethermead
29396	Coruu Access Crystal
29397	Duro Access Crystal
29398	Circle of Banishing
29399	Rod of the Void Caller
29400	Abyssal Shroud
29401	Sparkling Southshore Cider
29411	Ara Access Crystal
29412	Jessen's Special Slop
29425	Mark of Kil'jaeden
29426	Firewing Signet
29427	Mark of the Betrayer
29428	Bessy's Bell
29429	Boom's Doom
29434	Badge of Justice
29443	Bloodmaul Brutebane Brew
29445	Surveying Markers
29447	Fel Zapper
29448	Mag'har Mild Cheese
29449	Bladespire Bagel
29450	Telaari Grapes
29451	Clefthoof Ribs
29452	Zangar Trout
29453	Sporeggar Mushroom
29454	Silverwine
29456	Gift of the Ethereal
29457	Nethershard
29458	Aegis of the Vindicator
29459	Ethereum Relay Data
29460	Ethereum Prison Key
29461	Mana Bomb Fragment
29463	Amber Bands of the Aggressor
29464	Shaleskin Shale
29465	Black Battlestrider
29466	Black War Kodo
29467	Black War Ram
29468	Black War Steed Bridle
29469	Horn of the Black War Wolf
29470	Red Skeletal Warhorse
29471	Reins of the Black War Tiger
29472	Whistle of the Black War Raptor
29473	Protectorate Igniter
29474	Ivory Bell
29475	Pacifying Dust
29476	Crimson Crystal Shard
29477	Crimson Crystal Shard
29478	Seed of Revitalization
29480	Parched Hydra Sample
29481	Withered Bog Lord Sample
29482	Ethereum Essence
29483	Shadow Armor Kit
29485	Flame Armor Kit
29486	Frost Armor Kit
29487	Nature Armor Kit
29488	Arcane Armor Kit
29489	Enchanted Felscale Leggings
29490	Enchanted Felscale Gloves
29491	Enchanted Felscale Boots
29492	Flamescale Leggings
29493	Flamescale Boots
29494	Flamescale Belt
29495	Enchanted Clefthoof Leggings
29496	Enchanted Clefthoof Gloves
29497	Enchanted Clefthoof Boots
29498	Blastguard Pants
29499	Blastguard Boots
29500	Blastguard Belt
29501	Sha'naar Key
29502	Cobrascale Hood
29503	Cobrascale Gloves
29504	Windscale Hood
29505	Hood of Primal Life
29506	Gloves of the Living Touch
29507	Windslayer Wraps
29508	Living Dragonscale Helm
29509	Windstrike Gloves
29510	Netherdrake Helm
29511	Netherdrake Gloves
29512	Earthen Netherscale Boots
29513	Staff of the Dreghood Elders
29514	Thick Netherscale Breastplate
29515	Ebon Netherscale Breastplate
29516	Ebon Netherscale Belt
29517	Ebon Netherscale Bracers
29518	Amani Scimitar
29519	Netherstrike Breastplate
29520	Netherstrike Belt
29521	Netherstrike Bracers
29522	Windhawk Hauberk
29523	Windhawk Bracers
29524	Windhawk Belt
29525	Primalstrike Vest
29526	Primalstrike Belt
29527	Primalstrike Bracers
29528	Drums of War
29529	Drums of Battle
29530	Drums of Speed
29531	Drums of Restoration
29532	Drums of Panic
29533	Cobrahide Leg Armor
29534	Clefthide Leg Armor
29535	Nethercobra Leg Armor
29536	Nethercleft Leg Armor
29539	Cobra Scales
29540	Reinforced Mining Bag
29545	Sunfury Military Briefing
29546	Sunfury Arcane Briefing
29547	Wind Scales
29548	Nether Dragonscales
29549	Codex: Prayer of Fortitude III
29550	Tome of Conjure Water IX
29551	Severed Tail
29552	Broken Rock Flayer Talon
29553	Basilisk Liver
29554	Encrusted Basilisk Skin
29555	Glimmering Basilisk Skin
29556	Basilisk Venom Sac
29557	Rainbow Feather
29558	Charged Scale
29559	Vibrant Feather
29560	Electrified Scale
29561	Dragon Femur
29562	Dragon's Tooth
29563	Dragon's Claw
29564	Dragon's Fang
29565	Raptor Liver
29566	Raptor Blood Feather
29567	Raptor Talon
29568	Raptor War Feather
29569	Strong Junkbox
29570	A Gnome Effigy
29571	A Steamy Romance Novel
29572	Aboriginal Carvings
29573	Embalming Fluid
29574	Mummified Parts
29575	A Jack 'o Lantern
29576	Shark Bait
29577	Troll Keepsake
29578	Crystalized Stone
29579	Crystalized Stone Chips
29580	Crystal Fragments
29581	Strange Crystal
29582	Ethereum Data Cell
29583	Sinister Scimitar
29584	Throat Piercers
29585	Legion Whip
29586	Head of Forgefiend Razorsaw
29588	Burning Legion Missive
29589	Burning Legion Missive
29590	Burning Legion Missive
29591	Prepared Ethereum Wrapping
29592	Insignia of the Horde
29593	Insignia of the Alliance
29594	Knight-Lieutenant's Mail Greaves
29595	Knight-Lieutenant's Mail Vices
29596	Knight-Captain's Mail Hauberk
29597	Knight-Captain's Mail Legguards
29598	Lieutenant Commander's Mail Headguard
29599	Lieutenant Commander's Mail Pauldrons
29600	Blood Guard's Lamellar Gauntlets
29601	Blood Guard's Lamellar Sabatons
29602	Legionnaire's Lamellar Breastplate
29603	Legionnaire's Lamellar Leggings
29604	Champion's Lamellar Headguard
29605	Champion's Lamellar Shoulders
29606	Marshal's Mail Boots
29607	Marshal's Mail Gauntlets
29608	Marshal's Mail Leggings
29609	Field Marshal's Mail Armor
29610	Field Marshal's Mail Helm
29611	Field Marshal's Mail Spaulders
29612	General's Lamellar Boots
29613	General's Lamellar Gloves
29614	General's Lamellar Legplates
29615	Warlord's Lamellar Chestplate
29616	Warlord's Lamellar Faceguard
29617	Warlord's Lamellar Pauldrons
29618	Protectorate Disruptor
29624	First Half of Socrethar's Stone
29625	Second Half of Socrethar's Stone
29664	Pattern: Reinforced Mining Bag
29669	Pattern: Shadow Armor Kit
29672	Pattern: Flame Armor Kit
29673	Pattern: Frost Armor Kit
29674	Pattern: Nature Armor Kit
29675	Pattern: Arcane Armor Kit
29677	Pattern: Enchanted Felscale Leggings
29682	Pattern: Enchanted Felscale Gloves
29684	Pattern: Enchanted Felscale Boots
29689	Pattern: Flamescale Leggings
29691	Pattern: Flamescale Boots
29693	Pattern: Flamescale Belt
29698	Pattern: Enchanted Clefthoof Leggings
29699	Socrethar's Teleportation Stone
29700	Pattern: Enchanted Clefthoof Gloves
29701	Pattern: Enchanted Clefthoof Boots
29702	Pattern: Blastguard Pants
29703	Pattern: Blastguard Boots
29704	Pattern: Blastguard Belt
29713	Pattern: Drums of Panic
29714	Pattern: Drums of Restoration
29717	Pattern: Drums of Battle
29718	Pattern: Drums of Speed
29719	Pattern: Cobrahide Leg Armor
29720	Pattern: Clefthide Leg Armor
29721	Pattern: Nethercleft Leg Armor
29722	Pattern: Nethercobra Leg Armor
29723	Pattern: Cobrascale Hood
29724	Pattern: Cobrascale Gloves
29725	Pattern: Windscale Hood
29726	Pattern: Hood of Primal Life
29727	Pattern: Gloves of the Living Touch
29728	Pattern: Windslayer Wraps
29729	Pattern: Living Dragonscale Helm
29730	Pattern: Earthen Netherscale Boots
29731	Pattern: Windstrike Gloves
29732	Pattern: Netherdrake Helm
29733	Pattern: Netherdrake Gloves
29734	Pattern: Thick Netherscale Breastplate
29735	Holy Dust
29736	Arcane Rune
29737	Navuud's Concoction
29738	Vial of Void Horror Ooze
29739	Arcane Tome
29740	Fel Armament
29741	Diagnostic Results
29742	The Warden's Key
29743	Purple Elekk
29744	Gray Elekk
29745	Great Blue Elekk
29746	Great Green Elekk
29747	Great Purple Elekk
29749	Farahlon Lasher Cutting
29750	Ethereum Stasis Chamber Key
29751	Talbuk Horn Sample
29753	Chestguard of the Fallen Defender
29754	Chestguard of the Fallen Champion
29755	Chestguard of the Fallen Hero
29756	Gloves of the Fallen Hero
29757	Gloves of the Fallen Champion
29758	Gloves of the Fallen Defender
29759	Helm of the Fallen Hero
29760	Helm of the Fallen Champion
29761	Helm of the Fallen Defender
29762	Pauldrons of the Fallen Hero
29763	Pauldrons of the Fallen Champion
29764	Pauldrons of the Fallen Defender
29765	Leggings of the Fallen Hero
29766	Leggings of the Fallen Champion
29767	Leggings of the Fallen Defender
29768	Hulking Hydra Heart
29769	Diagnostic Results
29770	Experimental Repair Apparatus
29771	Kirin'Var Journeyman's Belt
29772	Kirin'Var Scout's Belt
29773	Battle-Mage's Helmet
29774	Kirin'Var Defender's Chausses
29775	Pendant of the Battle-Mage
29776	Core of Ar'kelos
29777	Cloak of the Valiant Defender
29778	Phase Disruptor
29779	Rejuvenating Scepter
29780	Kirin Tor Apprentice's Robes
29781	Lifewarden's Breastplate
29782	Coif of the Wicked
29783	Legguards of the Resolute Defender
29784	Harmony's Touch
29785	Crimson Mail Bracers
29786	Kirin'Var Defender's Greaves
29787	Master Smith's Hammer
29788	Finely Wrought Scale Leggings
29789	Andrethan's Masterwork
29790	Demolition Charges
29791	Reinforced Heaume
29792	Dawnstrike's Cloak
29793	Signet of the Violet Tower
29794	Strength of the Violet Tower
29795	Burning Legion Gate Key
29796	Socrethar's Teleportation Stone
29797	Orders From Kael'thas
29798	Dome Generator Segment
29799	Lifeless Tendril
29800	Evil Eye
29801	Ripfang Lynx Pelt
29802	Barbscale Crocolisk Skin
29803	Diagnostic Device
29804	Wrangler's Boots
29805	Socrethar's Head
29806	Cowpoke's Riding Gloves
29807	Engraved Cattleman's Buckle
29808	Shimmering Azure Boots
29810	Dragon Crested Epaulets
29811	Goldenlink Bracers
29812	Blued Steel Gauntlets
29813	Cloak of Woven Energy
29814	Celestial Jewel Ring
29815	Chain of Glowing Tendrils
29817	Talbuk Tagger
29818	Energy Field Modulator
29822	Fragment of Dimensius
29837	QAEnchant Weapon +81 Healing
29838	QAEnchant Weapon Battlemaster
29839	QAEnchant Weapon Mongoose
29840	QAEnchant Weapon Soulfrost
29841	QAEnchant Weapon Sunfire
29842	QAEnchant Weapon +40 Spell Damage
29843	QAEnchant Weapon +30 Intellect
29844	QAEnchant Weapon +7 Damage
29845	QAEnchant Weapon +20 Strength
29846	QAEnchant 2H Weapon +35 Agility
29847	QAEnchant 2H Weapon +70 Attack Power
29848	QAEnchant Shield +5 Resistances
29849	QAEnchant Shield +18 Stamina
29850	QAEnchant Shield +12 Intellect
29851	QAEnchant Shield +15 Block Value
29852	QAEnchant Boots +9 Stamina & +8% Speed
29853	QAEnchant Boots +6 Agility & +8% Speed
29854	QAEnchant Boots +5 Snare Resist & +10 Hit Rating
29856	QAEnchant Boots +12 Agility
29857	QAEnchant Boots +12 Stamina
29858	QAEnchant Cloak +15 Shadow Resistance
29859	QAEnchant Cloak +15 Arcane Resistance
29860	QAEnchant Cloak +12 Agility
29861	QAEnchant Cloak +20 Spell Penetration
29862	QAEnchant Gloves +35 Healing
29863	QAEnchant Gloves +20 Spell Damage
29864	QAEnchant Gloves +15 Spell Hit Rating
29866	QAEnchant Gloves +10 Spell Crit Rating
29867	QAEnchant Gloves +15 Strength
29868	QAEnchant Gloves +26 Attack Power
29869	QAEnchant Chest +15 Resilience
29870	QAEnchant Chest +6 Mana5
29871	QAEnchant Chest +15 Spirit
29872	QAEnchant Chest +6 Stats
29873	QAEnchant Chest +150 Mana
29874	QAEnchant Chest +150 Health
29877	Indalamar's Super Hot
29886	Hunter 105 Epic Ammo Box
29887	Hunter 150 Epic Ammo Box
29901	Blue Moth Egg
29902	Red Moth Egg
29903	Yellow Moth Egg
29904	White Moth Egg
29905	Kael's Vial Remnant
29906	Vashj's Vial Remnant
29908	Rage Reaver
29909	Screaming Dagger
29910	The Staff of Twin Worlds
29911	Agamaggan's Quill
29912	The Final Code
29913	Foe Reaver
29914	Hellfire Skiver
29915	Desolation Rod
29916	Ironstar Repeater
29917	Landslide Buckler
29918	Mindstorm Wristbands
29919	Adamantine Kite Shield
29920	Phoenix-Ring of Rebirth
29921	Fire Crest Breastplate
29922	Band of Al'ar
29923	Talisman of the Sun King
29924	Netherbane
29925	Phoenix-Wing Cloak
29926	Whispering Tunic
29927	Shadowbrim Travel Hat
29928	Wanderer's Stitched Trousers
29929	Raging Spirit Harness
29930	Nature-Stitched Kilt
29931	Phantasmal Headdress
29932	Arcane Ringed Tunic
29933	Arcane Ringed Greaves
29934	Helm of Affinity
29935	Fire Scarred Breastplate
29936	Skyfire Greaves
29937	Helm of Infinite Visions
29938	Battle Seeker Chestguard
29939	Flayer-Hide Leggings
29940	Veteran's Skullcap
29941	Scale Brand Breastplate
29942	Battle Scarred Leggings
29943	Legionnaire's Studded Helm
29944	Protectorate Breastplate
29945	Magistrate's Greaves
29946	Invader's Greathelm
29947	Gloves of the Searing Grip
29948	Claw of the Phoenix
29949	Arcanite Steam-Pistol
29950	Greaves of the Bloodwarder
29951	Star-Strider Boots
29952	Rina's Bough
29953	Golden Dragonhawk Hatchling
29954	Spiritbinder's Mantle
29955	Mana Infused Wristguards
29956	Red Dragonhawk Hatchling
29957	Silver Dragonhawk Hatchling
29958	Blue Dragonhawk Hatchling
29959	Spiritualist's Gauntlets
29960	Captured Firefly
29961	Enraged Earthen Soul
29962	Heartrazor
29963	Enraged Fiery Soul
29964	Blackstorm Leggings
29965	Girdle of the Righteous Path
29966	Vambraces of Ending
29967	Nether Vest
29968	Nether Leggings
29969	Sparky's Discarded Helmet
29970	Wildfeather Leggings
29971	Dragonstrike Leggings
29972	Trousers of the Astromancer
29973	Primalstorm Breastplate
29974	Living Crystal Breastplate
29975	Golden Dragonstrike Breastplate
29976	Worldstorm Gauntlets
29977	Star-Soul Breeches
29978	Consortium Combatant's Robes
29979	Netherstorm Eyepatch
29980	Midrealm Leggings
29981	Ethereum Life-Staff
29982	Wand of the Forgotten Star
29983	Fel-Steel Warhelm
29984	Girdle of Zaetar
29985	Void Reaver Greaves
29986	Cowl of the Grand Engineer
29987	Gauntlets of the Sun King
29988	The Nexus Key
29989	Sunshower Light Cloak
29990	Crown of the Sun
29991	Sunhawk Leggings
29992	Royal Cloak of the Sunstriders
29993	Twinblade of the Phoenix
29994	Thalassian Wildercloak
29995	Leggings of Murderous Intent
29996	Rod of the Sun King
29997	Band of the Ranger-General
29998	Royal Gauntlets of Silvermoon
29999	After Hours Pauldrons
30000	Mixologist's Gloves
30001	Doc's Belt
30002	Boot's Boots
30003	Gloves of the Nether-Stalker
30004	Landing Boots
30005	Overmaster's Shoulders
30006	Wind Trader's Band
30007	The Darkener's Grasp
30008	Pendant of the Lost Ages
30009	The Burning Crusader
30010	Fleshling Simulation Staff
30011	Ameer's Impulse Taser
30012	Ameer's Judgement
30013	Twin-Bladed Ripper
30014	X-52 Pilot's Leggings
30015	The Sun King's Talisman
30016	X-52 Technician's Helm
30017	Telonicus's Pendant of Mayhem
30018	Lord Sanguinar's Claim
30019	Area 52 Defender's Pants
30020	Fire-Cord of the Magus
30021	Wildfury Greatstaff
30022	Pendant of the Perilous
30023	Totem of the Maelstrom
30024	Mantle of the Elven Kings
30025	Serpentshrine Shuriken
30026	Bands of the Celestial Archer
30027	Boots of Courage Unending
30028	Seventh Ring of the Tirisfalen
30029	Bark-Gloves of Ancient Wisdom
30030	Girdle of Fallen Stars
30031	Red Havoc Boots
30032	Red Belt of Battle
30033	Boots of the Protector
30034	Belt of the Guardian
30035	Boots of the Long Road
30036	Belt of the Long Road
30037	Boots of Blasting
30038	Belt of Blasting
30039	Boots of Utter Darkness
30040	Belt of Deep Shadow
30041	Boots of Natural Grace
30042	Belt of Natural Power
30043	Hurricane Boots
30044	Monsoon Belt
30045	Boots of the Crimson Hawk
30046	Belt of the Black Eagle
30047	Blackfathom Warbands
30048	Brighthelm of Justice
30049	Fathomstone
30050	Boots of the Shifting Nightmare
30051	Idol of the Crescent Goddess
30052	Ring of Lethality
30053	Pauldrons of the Wardancer
30054	Ranger-General's Chestguard
30055	Shoulderpads of the Stranger
30056	Robe of Hateful Echoes
30057	Bracers of Eradication
30058	Mallet of the Tides
30059	Choker of Animalistic Fury
30060	Boots of Effortless Striking
30061	Ancestral Ring of Conquest
30062	Grove-Bands of Remulos
30063	Libram of Absolute Truth
30064	Cord of Screaming Terrors
30065	Glowing Breastplate of Truth
30066	Tempest-Strider Boots
30067	Velvet Boots of the Guardian
30068	Girdle of the Tidal Call
30069	Earthforged Leggings
30070	Windforged Leggings
30071	Light Earthforged Blade
30072	Light Skyforged Axe
30073	Light Emberforged Hammer
30074	Heavy Earthforged Breastplate
30075	Gnarled Chestpiece of the Ancients
30076	Stormforged Hauberk
30077	Windforged Rapier
30079	Illidari Shoulderpads
30080	Luminescent Rod of the Naaru
30081	Warboots of Obliteration
30082	Talon of Azshara
30083	Ring of Sundered Souls
30084	Pauldrons of the Argent Sentinel
30085	Mantle of the Tireless Tracker
30086	Stoneforged Claymore
30087	Stormforged Axe
30088	Skyforged Great Axe
30089	Lavaforged Warhammer
30090	World Breaker
30091	True-Aim Stalker Bands
30092	Orca-Hide Boots
30093	Great Earthforged Hammer
30094	Totem of Spirits
30095	Fang of the Leviathan
30096	Girdle of the Invulnerable
30097	Coral-Barbed Shoulderpads
30098	Razor-Scale Battlecloak
30099	Frayed Tether of the Drowned
30100	Soul-Strider Boots
30101	Bloodsea Brigand's Vest
30102	Krakken-Heart Breastplate
30103	Fang of Vashj
30104	Cobra-Lash Boots
30105	Serpent Spine Longbow
30106	Belt of One-Hundred Deaths
30107	Vestments of the Sea-Witch
30108	Lightfathom Scepter
30109	Ring of Endless Coils
30110	Coral Band of the Revived
30111	Runetotem's Mantle
30112	Glorious Gauntlets of Crestfall
30113	Destroyer Chestguard
30114	Destroyer Handguards
30115	Destroyer Greathelm
30116	Destroyer Legguards
30117	Destroyer Shoulderguards
30118	Destroyer Breastplate
30119	Destroyer Gauntlets
30120	Destroyer Battle-Helm
30121	Destroyer Greaves
30122	Destroyer Shoulderblades
30123	Crystalforge Chestguard
30124	Crystalforge Handguards
30125	Crystalforge Faceguard
30126	Crystalforge Legguards
30127	Crystalforge Shoulderguards
30129	Crystalforge Breastplate
30130	Crystalforge Gauntlets
30131	Crystalforge War-Helm
30132	Crystalforge Greaves
30133	Crystalforge Shoulderbraces
30134	Crystalforge Chestpiece
30135	Crystalforge Gloves
30136	Crystalforge Greathelm
30137	Crystalforge Leggings
30138	Crystalforge Pauldrons
30139	Rift Stalker Hauberk
30140	Rift Stalker Gauntlets
30141	Rift Stalker Helm
30142	Rift Stalker Leggings
30143	Rift Stalker Mantle
30144	Deathmantle Chestguard
30145	Deathmantle Handguards
30146	Deathmantle Helm
30148	Deathmantle Legguards
30149	Deathmantle Shoulderpads
30150	Vestments of the Avatar
30151	Gloves of the Avatar
30152	Cowl of the Avatar
30153	Breeches of the Avatar
30154	Mantle of the Avatar
30155	Clam Bar
30156	Recipe: Clam Bar
30157	Cursed Talisman
30158	Morkh's Shattered Armor
30159	Shroud of the Avatar
30160	Handguards of the Avatar
30161	Hood of the Avatar
30162	Leggings of the Avatar
30163	Wings of the Avatar
30164	Cataclysm Chestguard
30165	Cataclysm Gloves
30166	Cataclysm Headguard
30167	Cataclysm Legguards
30168	Cataclysm Shoulderguards
30169	Cataclysm Chestpiece
30170	Cataclysm Handgrips
30171	Cataclysm Headpiece
30172	Cataclysm Leggings
30173	Cataclysm Shoulderpads
30174	Dust of the Fey Drake
30175	Gor'drek's Ointment
30177	Stronglimb Deeproot's Trunk
30183	Nether Vortex
30184	Thunderlord Dire Wolf Tail
30185	Cataclysm Chestplate
30186	Gladiator's Felweave Amice
30187	Gladiator's Felweave Cowl
30188	Gladiator's Felweave Handguards
30189	Cataclysm Gauntlets
30190	Cataclysm Helm
30191	QAEnchant Ring +2 Weapon Damage
30192	Cataclysm Legplates
30193	QAEnchant Ring +12 Spell Damage
30194	Cataclysm Shoulderplates
30195	QAEnchant Ring +20 Healing
30196	Robes of Tirisfal
30197	QAEnchant Ring +4 Stats
30198	QAEnchant Cloak +7 Resistances
30199	QAEnchant Boots +4 Health & Mana5
30200	Gladiator's Felweave Raiment
30201	Gladiator's Felweave Trousers
30205	Gloves of Tirisfal
30206	Cowl of Tirisfal
30207	Leggings of Tirisfal
30210	Mantle of Tirisfal
30211	Gloves of the Corruptor
30212	Hood of the Corruptor
30213	Leggings of the Corruptor
30214	Robe of the Corruptor
30215	Mantle of the Corruptor
30216	Nordrassil Chestguard
30217	Nordrassil Gloves
30218	Junior Technician 3rd Grade Shoulders
30219	Nordrassil Headguard
30220	Nordrassil Life-Kilt
30221	Nordrassil Life-Mantle
30222	Nordrassil Chestplate
30223	Nordrassil Handgrips
30224	Junior Technician 3rd Grade Gloves
30225	Junior Technician 3rd Grade Bracers
30226	Alley's Recurve
30227	Mark V's Throwing Star
30228	Nordrassil Headdress
30229	Nordrassil Feral-Kilt
30230	Nordrassil Feral-Mantle
30231	Nordrassil Chestpiece
30232	Nordrassil Gauntlets
30233	Nordrassil Headpiece
30234	Nordrassil Wrath-Kilt
30235	Nordrassil Wrath-Mantle
30236	Chestguard of the Vanquished Champion
30237	Chestguard of the Vanquished Defender
30238	Chestguard of the Vanquished Hero
30239	Gloves of the Vanquished Champion
30240	Gloves of the Vanquished Defender
30241	Gloves of the Vanquished Hero
30242	Helm of the Vanquished Champion
30243	Helm of the Vanquished Defender
30244	Helm of the Vanquished Hero
30245	Leggings of the Vanquished Champion
30246	Leggings of the Vanquished Defender
30247	Leggings of the Vanquished Hero
30248	Pauldrons of the Vanquished Champion
30249	Pauldrons of the Vanquished Defender
30250	Pauldrons of the Vanquished Hero
30251	Rina's Diminution Powder
30252	Unearthed Enkaat Wand
30253	Ethereal Gloves
30254	Zephyrion's Belt
30255	Chestguard of the Stormspire
30256	Pants of the Naaru
30257	Shattrath Leggings
30258	Chestplate of A'dal
30259	Voren'thal's Presence
30260	Voren'thal's Package
30262	Trep's Shoulderguards
30263	Heavy-Duty Engineering Boots
30264	Area 52 Engineering Gloves
30265	Zaxxis Bracers
30266	Zaxxis Boots
30267	Zaxxis Gloves
30268	Heap Leggings
30269	Warp-Raider's Eyepatch
30270	Scavenged Breastplate
30271	Midrealm Hat
30272	Eco-Dome Leggings
30273	Duro Footgear
30274	Papa's Armbands
30275	Mech Tech Shoulders
30276	Wheeler Family Heirloom
30277	Ripfang Paw
30278	Pilfered Ethereal Blade
30279	Mama's Insurance
30280	Pattern: Belt of Blasting
30281	Pattern: Belt of the Long Road
30282	Pattern: Boots of Blasting
30283	Pattern: Boots of the Long Road
30284	Audi's Embroidered Boots
30285	B.O.O.M. Operative's Belt
30286	Otherworldly Pauldrons
30287	Mantle of Arcane Mastery
30288	Cenarion Warden's Gloves
30289	Cenarion Warden's Belt
30290	Leggings of Concentrated Power
30291	Nexus-Guard's Pauldrons
30292	My Little Friend
30293	Heavenly Inspiration
30294	Red Pointy Hat
30295	Exotic Spiked Shoulders
30296	Lost Chestplate of the Reverent
30297	Circlet of the Starcaller
30298	Void Slayer's Tunic
30299	Starcaller's Plated Legguards
30300	Dabiri's Enigma
30301	Pattern: Belt of Natural Power
30302	Pattern: Belt of Deep Shadow
30303	Pattern: Belt of the Black Eagle
30304	Pattern: Monsoon Belt
30305	Pattern: Boots of Natural Grace
30306	Pattern: Boots of Utter Darkness
30307	Pattern: Boots of the Crimson Hawk
30308	Pattern: Hurricane Boots
30309	Stonebreaker Brew
30311	Warp Slicer
30312	Infinity Blade
30313	Staff of Disintegration
30314	Phaseshift Bulwark
30315	Draenethyst Mine Crystal
30316	Devastation
30317	Cosmic Infuser
30318	Netherstrand Longbow
30319	Nether Spike
30320	Bundle of Nether Spikes
30321	Plans: Belt of the Guardian
30322	Plans: Red Belt of Battle
30323	Plans: Boots of the Protector
30324	Plans: Red Havoc Boots
30325	Ravenous Ravager Egg
30326	Bonechewer Blood Samples
30327	Bonechewer Blood
30328	Protectorate Assassin's Tunic
30329	Flesh Handler's Headpiece
30330	Starcaller's Plated Belt
30331	Diviner's Cinch
30332	Ferocious Bands
30333	Spaulders of the Protectorate
30334	Starcaller's Plated Stompers
30335	Druidic Force Boots
30336	Surger's Hand Wraps
30337	Protectorate Headplate
30338	Diviner's Cloak
30339	Protectorate Assassin's Ring
30340	Starkiller's Bauble
30341	Flesh Handler's Gauntlets
30342	Protectorate Waistband
30343	Medallion of the Horde
30344	Medallion of the Horde
30345	Medallion of the Horde
30346	Medallion of the Horde
30348	Medallion of the Alliance
30349	Medallion of the Alliance
30350	Medallion of the Alliance
30351	Medallion of the Alliance
30352	Demolisher's Bracers
30353	Bloodmaul Brutebane Keg
30354	Ultra Deconsolodation Zapper
30355	Grilled Shadowmoon Tuber
30356	Shadowmoon Tuber
30357	Oronok's Tuber of Healing
30358	Oronok's Tuber of Agility
30359	Oronok's Tuber of Strength
30360	Lurky's Egg
30361	Oronok's Tuber of Spell Power
30362	Energized Helm
30363	Warp-Shielded Hauberk
30364	Resonating Axe
30365	Overseer's Signet
30366	Manastorm Band
30368	Slippers of the High Priestess
30369	Cleansed Fel Pauldrons
30370	Gauntlets of the Redeemed Vindicator
30371	Lightwarden's Girdle
30372	Socrethar's Girdle
30373	Netherfused Pauldrons
30374	Greaves of Spellpower
30375	Gauntlets of the Vanquisher
30377	Karja's Medallion
30378	Thalodien's Charm
30379	Vindicator's Light Vest
30380	Girdle of the Lost Vindicator
30381	Kaylaan's Spaulders
30382	Aldor Ceremonial Wraps
30383	Belt of the Sage
30384	Brightdawn Bracers
30385	QR XXXX Plate Spell Bracer
30386	Bloodguard's Greaves
30394	Sunfury Blade
30395	Warp-Master's Maul
30396	Jeweled Halberd
30397	Spymaster's Crossbow
30398	Boots of the Beneficent
30399	Nightstalker's Wristguards
30400	Thadell's Bracers
30401	Farahlite Studded Boots
30402	Field Agent's Bracers
30404	Bleeding Hollow Blood Sample
30413	Vindicator Vuuleen's Blade
30415	Vindicator Vuuleen's Shield
30416	Bladespire Clan Banner
30417	Helm of Gurn Grubnosh
30418	Darkspear (Purple Glow)
30419	Brilliant Necklace
30420	Heavy Jade Ring
30421	Red Ring of Destruction
30422	Diamond Focus Ring
30425	Bleeding Hollow Blood
30426	Coilskar Chest Key
30428	First Fragment of the Cipher of Damnation
30429	Grom'tor's Lockbox
30430	Boiled Blood
30431	Thunderlord Clan Artifact
30432	Thunderlord Clan Drum
30433	Thunderlord Clan Arrow
30434	Thunderlord Clan Tablet
30435	The Thunderspike
30436	Jagged Blue Crystal
30437	Jagged Red Crystal
30438	Cache of the Legion Key
30442	Crystalline Key
30443	Recipe: Transmute Primal Fire to Earth
30444	Pattern: Reinforced Mining Bag
30446	Solarian's Sapphire
30447	Tome of Fiery Redemption
30448	Talon of Al'ar
30449	Void Star Talisman
30450	Warp-Spring Coil
30451	Lohn'goron, Bow of the Torn-heart
30453	Second Fragment of the Cipher of Damnation
30454	Ar'tor's Lockbox
30457	Gilneas Sparkling Water
30458	Stromgarde Muenster
30459	Netherflame Robe
30460	Netherflame Belt
30461	Netherflame Boots
30462	Oronok's Boar Whistle
30463	Lifeblood Belt
30464	Lifeblood Bracers
30465	Lifeblood Leggings
30466	Crocolisk Tooth
30467	Crocolisk Tail
30468	T'chali's Hookah
30469	Pattern: Netherflame Robe
30470	Pattern: Netherflame Belt
30471	Pattern: Netherflame Boots
30472	Pattern: Lifeblood Leggings
30473	Pattern: Lifeblood Belt
30474	Pattern: Lifeblood Bracers
30475	Razor Thorn
30476	Hypnotic Flower
30477	Connective Tissue
30478	Stringy Ectoplasm
30479	Wicked Strong Fetish
30480	Fiery Warhorse's Reins
30481	Fiery Soul Fragment
30483	Pattern: Shadowcloth
30486	Merciless Gladiator's Plate Chestpiece
30487	Merciless Gladiator's Plate Gauntlets
30488	Merciless Gladiator's Plate Helm
30489	Merciless Gladiator's Plate Legguards
30490	Merciless Gladiator's Plate Shoulders
30491	General's Plate Greaves Tier 2
30497	Sentinel's Mail Leggings
30498	Outrider's Lamellar Legguards
30499	Brightsong Wine
30500	Rotten Arakkoa Egg
30501	Bundle of Bloodthistle
30503	Archeologist's Shrunken Head
30504	Leafblade Dagger
30505	Ghostclaw Tunic
30506	Snipe Egg
30507	Lucky Rock
30508	Pickled Murloc Head
30509	Armor Fragment
30510	Imbued Leaf
30511	Stonewood
30512	Giant Spinneret
30513	Bloody Spider Fang
30514	Nether Guards
30515	Junior Technician 3rd Grade Goggles
30516	Chief Engineer's Belt
30517	Netherfarer's Leggings
30518	Warpthread Vest
30519	Boots of the Nexus Warden
30520	Gold-Trimmed Cuffs
30521	Warpweaver's Gloves
30522	Conjurer's Staff
30523	Hotshot Cattle Prod
30524	Ancient Draenei Manuscript, Chapter 1
30525	Ancient Draenei Manuscript, Chapter 2
30526	Ancient Draenei Manuscript, Chapter 3
30527	Draenei Tomb Relic
30529	Plucked Lashh'an Feather
30530	Fistful of Feathers
30531	Breeches of the Occultist
30532	Kirin Tor Master's Trousers
30533	Vanquisher's Legplates
30534	Wyrmscale Greaves
30535	Forestwalker Kilt
30536	Greaves of the Martyr
30538	Midnight Legguards
30539	Tally's Waiver (Signed)
30540	Tally's Waiver (Unsigned)
30541	Stormsong Kilt
30542	Dimensional Ripper - Area 52
30543	Pontifex Kilt
30544	Ultrasafe Transporter: Toshley's Station
30545	Cavrylin's Medallion
30546	Sovereign Tanzanite
30547	Luminous Fire Opal
30548	Polished Chrysoprase
30549	Shifting Tanzanite
30550	Sundered Chrysoprase
30551	Infused Fire Opal
30552	Blessed Tanzanite
30553	Pristine Fire Opal
30554	Stalwart Fire Opal
30555	Glowing Tanzanite
30556	Glinting Fire Opal
30558	Glimmering Fire Opal
30559	Etched Fire Opal
30560	Rune Covered Chrysoprase
30561	Vekh'nir Crystal
30563	Regal Tanzanite
30564	Shining Fire Opal
30565	Assassin's Fire Opal
30566	Defender's Tanzanite
30567	Charged Vekh'nir Crystal
30568	The Sharp Cookie
30569	Proximo's Rudius
30570	Arkadian Claymore
30571	Don Rodrigo's Heart
30572	Imperial Tanzanite
30573	Mysterious Fire Opal
30574	Brutal Tanzanite
30575	Nimble Fire Opal
30579	Illidari-Bane Shard
30581	Durable Fire Opal
30582	Deadly Fire Opal
30583	Timeless Chrysoprase
30584	Enscribed Fire Opal
30585	Glistening Fire Opal
30586	Seer's Chrysoprase
30587	Champion's Fire Opal
30588	Potent Fire Opal
30589	Dazzling Chrysoprase
30590	Enduring Chrysoprase
30591	Empowered Fire Opal
30592	Steady Chrysoprase
30593	Iridescent Fire Opal
30594	Effulgent Chrysoprase
30595	Legion Codex Key
30596	Baa'ri Tablet Fragment
30597	Halaani Claymore
30598	Don Amancio's Heart
30599	Avenging Blades
30600	Fluorescent Tanzanite
30601	Beaming Fire Opal
30602	Jagged Chrysoprase
30603	Royal Tanzanite
30604	Resplendent Fire Opal
30605	Vivid Chrysoprase
30606	Lambent Chrysoprase
30607	Splendid Fire Opal
30608	Radiant Chrysoprase
30609	Swift Nether Drake
30610	Smoked Black Bear Meat
30611	Halaani Razorshaft
30612	Halaani Grimshot
30613	Felfire Diemetradon Eye
30614	Fel Bomb
30615	Halaani Whiskey
30616	Bundle of Bloodthistle
30617	Stormrage Missive
30618	Trachela's Carcass
30619	Fel Reaver's Piston
30620	Spyglass of the Hidden Fleet
30621	Prism of Inner Calm
30622	Flamewrought Key
30623	Reservoir Key
30626	Sextant of Unstable Currents
30627	Tsunami Talisman
30628	Fel Reaver Power Core
30629	Scarab of Displacement
30630	Fel Reaver Energy Matrix
30631	Fel Reaver Armor Plate
30632	Lament of the Highborne
30633	Auchenai Key
30634	Warpforged Key
30635	Key of Time
30637	Flamewrought Key
30638	Box o' Tricks
30639	Blood Elf Disguise
30640	Eclipsion Armor
30641	Boots of Elusion
30642	Drape of the Righteous
30643	Belt of the Tracker
30644	Grips of Deftness
30645	Third Fragment of the Cipher of Damnation
30646	Borak's Lockbox
30649	Orders From Akama
30650	Dertrok's Wand Case
30651	Dertrok's First Wand
30652	Dertrok's Second Wand
30653	Dertrok's Third Wand
30654	Dertrok's Fourth Wand
30655	Infused Vekh'nir Crystal
30656	Protovoltaic Magneto Collector
30657	The Cipher of Damnation
30658	Flanis's Pack
30659	Kagrosh's Pack
30663	Fathom-Brooch of the Tidewalker
30664	Living Root of the Wildheart
30665	Earring of Soulful Meditation
30666	Ritssyn's Lost Pendant
30667	Ring of Unrelenting Storms
30668	Grasp of the Dead
30672	Elemental Displacer
30673	Inferno Waist Cord
30674	Zierhut's Lost Treads
30675	Lurker's Cord
30676	Lurker's Grasp
30677	Lurker's Belt
30678	Lurker's Girdle
30679	Sunfury Glaive
30680	Glider's Foot-Wraps
30681	Glider's Boots
30682	Glider's Sabatons
30683	Glider's Greaves
30684	Ravager's Cuffs
30685	Ravager's Wrist-Wraps
30686	Ravager's Bands
30687	Ravager's Bracers
30688	Deathforge Key
30689	Razuun's Orders
30690	Power Converter
30691	Haalum's Medallion Fragment
30692	Eykenen's Medallion Fragment
30693	Lakaan's Medallion Fragment
30694	Uylaru's Medallion Fragment
30695	Legion Teleporter Control
30696	Scourgebane
30700	Scourgestone Fragments
30701	Oscillating Frequency Scanners
30703	Conjured Mountain Spring Water
30704	Ruuan'ok Claw
30705	Spaulders of Slaughter
30706	Harbinger's Pendant
30707	Nimble-foot Treads
30708	Belt of Flowing Thought
30709	Pantaloons of Flaming Wrath
30710	Blood Guard's Necklace of Ferocity
30712	The Doctor's Key
30713	The Art of Fel Reaver Maintenance
30716	Ever-burning Ash
30717	Harbinger's Pendant
30719	Spectrecles
30720	Serpent-Coil Braid
30721	Spectrecles
30722	Ethereum Nexus-Reaver
30723	Talon of the Tempest
30724	Barrel-Blade Longrifle
30725	Anger-Spark Gloves
30726	Archaic Charm of Presence
30727	Gilded Trousers of Benediction
30728	Fathom-Helm of the Deeps
30729	Black-Iron Battlecloak
30730	Terrorweave Tunic
30731	Faceguard of the Endless Watch
30732	Exodar Life-Staff
30733	Hope Ender
30734	Leggings of the Seventh Circle
30735	Ancient Spellcloak of the Highborne
30736	Ring of Flowing Light
30737	Gold-Leaf Wildboots
30738	Ring of Reciprocity
30739	Scaled Greaves of the Marksman
30740	Ripfiend Shoulderplates
30741	Topaz-Studded Battlegrips
30742	Temporal Phase Modulator
30743	Proto-Nether Drake Essence
30744	Draenic Leather Pack
30745	Heavy Toolbox
30746	Mining Sack
30747	Gem Pouch
30748	Enchanter's Satchel
30749	Draenic Sparring Blade
30750	Draenic Warblade
30751	Mag'hari Light Axe
30752	Mag'hari Battleaxe
30753	Warphorn Spear
30754	Ancient Bone Mace
30755	Mag'hari Fighting Claw
30756	Illidari-Bane Shard
30757	Draenic Light Crossbow
30758	Aldor Guardian Rifle
30759	Mag'hari Light Recurve
30760	Formal Draenic Robe
30761	Infernoweave Leggings
30762	Infernoweave Robe
30763	Infernoweave Boots
30764	Infernoweave Gloves
30765	Heavy Draenic Breastplate
30766	Inferno Tempered Leggings
30767	Inferno Tempered Gauntlets
30768	Inferno Tempered Boots
30769	Inferno Tempered Chestguard
30770	Inferno Forged Boots
30771	Heavy Draenic Bracers
30772	Inferno Forged Leggings
30773	Inferno Forged Hauberk
30774	Inferno Forged Gloves
30775	Layered Bone Shield
30776	Inferno Hardened Chestguard
30777	Aldor Heavy Belt
30778	Inferno Hardened Leggings
30779	Inferno Hardened Boots
30780	Inferno Hardened Gloves
30781	Mag'hari Chain Vest
30782	Adolescent Nether Drake Essence
30783	Mature Nether Drake Essence
30784	Worn Mag'hari Gauntlets
30785	Morgroron's Glaive
30786	Makazradon's Glaive
30787	Illidari-Bane Mageblade
30788	Illidari-Bane Broadsword
30789	Illidari-Bane Claymore
30791	Silkwing Cocoon
30792	Iridescent Wing
30793	Skettis See Invis Potion
30794	Shredder Keys
30796	Outland Ore
30797	Gorefiend's Armor
30798	Extra Sharp Daggermaw Tooth
30799	Gorefiend's Cloak
30800	Gorefiend's Truncheon
30803	Felhound Whistle
30804	Bronze Band of Force
30805	Thick Stain Resistant Gloves
30806	Fel Hound Walking Kit
30807	Uvuros's Fiery Mane
30808	Book of Fel Names
30809	Mark of Sargeras
30810	Sunfury Signet
30811	Scroll of Demonic Unbanishing
30812	Iridescent Scale
30813	Envenomed Fang
30814	Enormous Molar
30815	Giant Scale
30816	Spice Bread
30817	Simple Flour
30818	Repolarized Magneto Sphere
30819	Felfire Spleen
30820	Vicious Scorpid Claw
30821	Envenomed Scorpid Stinger
30822	Box of Ingots
30823	Demon Warding Totem
30824	Overcharged Manacell
30825	Ring of Arcane Shielding
30826	Design: Ring of Arcane Shielding
30827	Lexicon Demonica
30828	Vial of Underworld Loam
30829	Tear of the Earthmother
30830	Trident of the Outcast Tribe
30831	Cloak of Arcane Evasion
30832	Gavel of Unearthed Secrets
30833	Pattern: Cloak of Arcane Evasion
30834	Shapeshifter's Signet
30835	Salvager's Hauberk
30836	Leggings of the Skettis Exile
30837	Flameheart Bracers
30838	Flameheart Gloves
30839	Flameheart Vest
30840	Ether-Energized Flesh
30841	Lower City Prayerbook
30842	Pattern: Flameheart Bracers
30843	Pattern: Flameheart Gloves
30844	Pattern: Flameheart Vest
30845	Glyph of Chromatic Warding
30846	Glyph of the Outcast
30847	X-52 Rocket Helmet
30849	Scalewing Lightning Gland
30850	Freshly Drawn Blood
30851	Felspine's Hide
30852	Multi-Spectrum Light Trap
30853	Imbued Silver Spear
30854	Book of Fel Names
30855	Shatterstone Pick
30856	Underworld Helm
30857	Deep Core Lantern
30858	Peon Sleep Potion
30859	Wand of the Seer
30860	Kaylaan's Signet
30861	Furious Shackles
30862	Blessed Adamantite Bracers
30863	Deadly Cuffs
30864	Bracers of the Pathfinder
30865	Tracker's Blade
30866	Blood-stained Pauldrons
30867	Overdeveloped Felfire Gizzard
30868	Rejuvenating Bracers
30869	Howling Wind Bracers
30870	Cuffs of Devastation
30871	Bracers of Martyrdom
30872	Chronicle of Dark Secrets
30873	Stillwater Boots
30874	The Unbreakable Will
30875	Forged Illidari-Bane Blade
30876	Quenched Illidari-Bane Blade
30877	QAEnchant Bracer +6 Mana5 Sec
30878	Glimmering Steel Mantle
30879	Don Alejandro's Money Belt
30880	Quickstrider Moccasins
30881	Blade of Infamy
30882	Bastion of Light
30883	Pillar of Ferocity
30884	Hatefury Mantle
30885	Archbishop's Slippers
30886	Enchanted Leather Sandals
30887	Golden Links of Restoration
30888	Anetheron's Noose
30889	Kaz'rogal's Hardened Heart
30890	Collection of Souls
30891	Black Featherlight Boots
30892	Beast-tamer's Shoulders
30893	Sun-touched Chain Leggings
30894	Blue Suede Shoes
30895	Angelista's Sash
30896	Glory of the Defender
30897	Girdle of Hope
30898	Shady Dealer's Pantaloons
30899	Don Rodrigo's Poncho
30900	Bow-stitched Leggings
30901	Boundless Agony
30902	Cataclysm's Edge
30903	Legguards of Endless Rage
30904	Savior's Grasp
30905	Midnight Chestguard
30906	Bristleblitz Striker
30907	Mail of Fevered Pursuit
30908	Apostle of Argus
30909	Antonidas's Aegis of Rapt Concentration
30910	Tempest of Chaos
30911	Scepter of Purification
30912	Leggings of Eternity
30913	Robes of Rhonin
30914	Belt of the Crescent Moon
30915	Belt of Seething Fury
30916	Leggings of Channeled Elements
30917	Razorfury Mantle
30918	Hammer of Atonement
30919	Valestalker Girdle
30920	QR 10574 Cloth Mage Chest
30921	QR 10637 Cloth Mage Legs
30922	Ata'mal Crown
30923	Grom'tor's Bloodied Bandage
30924	Gloves of the High Magus
30925	Spaulders of the Torn-heart
30926	Ashwalker's Footwraps
30927	Earthmender's Bracer of Shattering
30928	Sketh'lon Survivor's Tunic
30929	Soothsayer's Kilt
30930	Grips of the Void
30931	Ghostly Headwrap
30932	Akama's Sash
30933	Hauberk of Karabor
30934	QR 10574 Leather Rogue Legs
30935	QR 10637 Leather Rogue Helm
30936	Eva's Strap
30937	Earthmender's Fists of Undoing
30938	Azurestrike Shoulders
30939	Felboar Hide Shoes
30940	Aged Leather Bindings
30941	Ash Tempered Legguards
30942	Manimal's Cinch
30943	Verdant Gloves
30944	Umberhowl's Collar
30945	Grom'tor's Friend's Cousin's Tunic
30946	Mooncrest Headdress
30947	Crimson Mail Hauberk
30948	Sunfury Legguards
30949	QR 10574 Mail Hunter Helm
30950	Darkhunter's Cinch
30951	Ar'tor's Mainstay
30952	Earthmender's Crimson Spaulders
30953	Boots of the Skybreaker
30954	QR 10637 Mail Hunter Bracers
30955	Crown of Cinders
30958	Blackened Chain Greaves
30959	Torn-heart Family Tunic
30960	Runed Sketh'lon Legplates
30961	Ash-Covered Helm
30962	Borak's Belt of Bravery
30963	QR 10574 Plate Warrior Gloves
30964	Skybreaker's Pauldrons
30965	QR 10637 Plate Warrior Boots
30966	Singed Vambraces
30967	The Hands of Fate
30968	Earthmender's Plated Boots
30969	Onslaught Gauntlets
30970	Onslaught Handguards
30971	Torn-heart Cloak
30972	Onslaught Battle-Helm
30973	Band of Anguish
30974	Onslaught Greathelm
30975	Onslaught Breastplate
30976	Onslaught Chestguard
30977	Onslaught Greaves
30978	Onslaught Legguards
30979	Onslaught Shoulderblades
30980	Onslaught Shoulderguards
30981	Grom'tor's Pendant of Conquest
30982	Lightbringer Gauntlets
30983	Lightbringer Gloves
30984	Spellbreaker's Buckler
30985	Lightbringer Handguards
30986	Bloodforged Guard
30987	Lightbringer Faceguard
30988	Lightbringer Greathelm
30989	Lightbringer War-Helm
30990	Lightbringer Breastplate
30991	Lightbringer Chestguard
30992	Lightbringer Chestpiece
30993	Lightbringer Greaves
30994	Lightbringer Leggings
30995	Lightbringer Legguards
30996	Lightbringer Pauldrons
30997	Lightbringer Shoulderbraces
30998	Lightbringer Shoulderguards
30999	Ashtongue Blade
31000	Bloodwarder's Rifle
31001	Gronnstalker's Gloves
31002	Summoner's Blade
31003	Gronnstalker's Helmet
31004	Gronnstalker's Chestguard
31005	Gronnstalker's Leggings
31006	Gronnstalker's Spaulders
31007	Skyshatter Gloves
31008	Skyshatter Gauntlets
31009	Wildcaller
31010	Slayer's Axe
31011	Skyshatter Grips
31012	Skyshatter Helmet
31013	Ceremonial Kris
31014	Skyshatter Headguard
31015	Skyshatter Cover
31016	Skyshatter Chestguard
31017	Skyshatter Breastplate
31018	Skyshatter Tunic
31019	Skyshatter Leggings
31020	Skyshatter Legguards
31021	Skyshatter Pants
31022	Skyshatter Shoulderpads
31023	Skyshatter Mantle
31024	Skyshatter Pauldrons
31025	Idol of the Avenger
31026	Slayer's Handguards
31027	Slayer's Helm
31028	Slayer's Chestguard
31029	Slayer's Legguards
31030	Slayer's Shoulderpads
31031	Stormfury Totem
31032	Thunderheart Gloves
31033	Libram of Righteous Power
31034	Thunderheart Gauntlets
31035	Thunderheart Handguards
31036	Oronok's Ancient Scepter
31037	Thunderheart Helmet
31038	Staff of the Redeemer
31039	Thunderheart Cover
31040	Thunderheart Headguard
31041	Thunderheart Tunic
31042	Thunderheart Chestguard
31043	Thunderheart Vest
31044	Thunderheart Leggings
31045	Thunderheart Legguards
31046	Thunderheart Pants
31047	Thunderheart Spaulders
31048	Thunderheart Pauldrons
31049	Thunderheart Shoulderpads
31050	Gloves of the Malefic
31051	Hood of the Malefic
31052	Robe of the Malefic
31053	Leggings of the Malefic
31054	Mantle of the Malefic
31055	Gloves of the Tempest
31056	Cowl of the Tempest
31057	Robes of the Tempest
31058	Leggings of the Tempest
31059	Mantle of the Tempest
31060	Gloves of Absolution
31061	Handguards of Absolution
31062	Torn-heart Axe of Battle
31063	Cowl of Absolution
31064	Hood of Absolution
31065	Shroud of Absolution
31066	Vestments of Absolution
31067	Leggings of Absolution
31068	Breeches of Absolution
31069	Mantle of Absolution
31070	Shoulderpads of Absolution
31071	Grom'tor's Charge
31072	Lohn'goron, Bow of the Torn-heart
31073	Borak's Reminder
31074	Amulet of the Torn-heart
31075	Evoker's Mark of the Redemption
31076	Spellsword's Mark of the Redemption
31077	Slayer's Mark of the Redemption
31078	Protector's Mark of the Redemption
31079	Mercurial Adamantite
31080	Mercurial Stone
31084	Key to the Arcatraz
31085	Top Shard of the Arcatraz Key
31086	Bottom Shard of the Arcatraz Key
31087	Ata'mal Crystal
31088	Tainted Core
31089	Chestguard of the Forgotten Conqueror
31090	Chestguard of the Forgotten Vanquisher
31091	Chestguard of the Forgotten Protector
31092	Gloves of the Forgotten Conqueror
31093	Gloves of the Forgotten Vanquisher
31094	Gloves of the Forgotten Protector
31095	Helm of the Forgotten Protector
31096	Helm of the Forgotten Vanquisher
31097	Helm of the Forgotten Conqueror
31098	Leggings of the Forgotten Conqueror
31099	Leggings of the Forgotten Vanquisher
31100	Leggings of the Forgotten Protector
31101	Pauldrons of the Forgotten Conqueror
31102	Pauldrons of the Forgotten Vanquisher
31103	Pauldrons of the Forgotten Protector
31104	Evoker's Helmet of Second Sight
31105	Overlord's Helmet of Second Sight
31106	Stalker's Helmet of Second Sight
31107	Shamanistic Helmet of Second Sight
31108	Kor'kron Flare Gun
31109	Stealther's Helmet of Second Sight
31110	Druidic Helmet of Second Sight
31111	Uvuros Hide Gloves
31112	Uvuros Hide Boots
31113	Violet Badge
31114	Uvuros Hide Cinch
31115	Uvuros Plated Spaulders
31116	Infused Amethyst
31117	Soothing Amethyst
31118	Pulsing Amethyst
31119	Wyrmcult Net
31120	Meeting Note
31121	Costume Scraps
31122	Overseer Disguise
31123	Spinning Nether-weather Vane
31124	Nether-weather Vane
31125	Boots of the Decimator
31126	Gloves of Ferocity
31127	Hauberk of Totemic Rage
31128	Rexxar's Whistle
31129	Blackwhelp Net
31130	Wyrmcult Blackwhelp
31131	Sash of Silent Blades
31132	Crust Burster Venom Gland
31133	Leggings of Concentrated Darkness
31134	Blade of Misfortune
31135	Baron Sablemane's Poison
31136	Breastplate of Blade Turning
31137	Gauntlets of Purification
31138	Storm Lord's Girdle
31139	Fist of Reckoning
31140	Cloak of Entropy
31141	Kodohide Drum
31142	Blade of Trapped Knowledge
31143	Shroud of Frenzy
31144	Spirit's Whistle
31145	Headdress of the Sleeper
31146	Rexxar's Battle Horn
31147	Pendant of Cunning
31148	Demon Hide Spaulders
31149	Gloves of Pandemonium
31150	Gloves of Piety
31151	Girdle of Siege
31152	Chestguard of Illumination
31153	Axe of the Legion
31154	Bronze Torc
31155	Drakescale Breastplate
31156	Drakescale Hauberk
31157	Drakehide Tunic
31158	Drakeweave Raiment
31159	Felstone Pauldrons
31160	Felstone Epaulets
31161	Felstone Spaulders
31162	Felstone Mantle
31163	Nethersteel Handguards
31164	Nethersteel Gauntlets
31165	Nethersteel-Reinforced Gloves
31166	Nethersteel-Lined Handwraps
31168	Demon-Forged Chestguard
31169	Sketh'lon War Totem
31170	Demon-Forged Hauberk
31172	Demon-Cured Tunic
31173	Boots of Savagery
31174	Demonweave Raiment
31175	Blade Dancer's Wristguards
31176	Rockwurm Plate Handguards
31177	Rockwurm Scale Gauntlets
31178	Amulet of Unstable Power
31179	Rockwurm Hide Gloves
31180	Gauntlets of the Skullsplitter
31181	Rockwurm Hide Handwraps
31182	Legion Helm
31183	Legion Coif
31184	Legion Headguard
31185	Legion Crown
31186	Braxxis' Staff of Slumber
31187	Boots of the Pathfinder
31188	Crocolisk Scale Vambraces
31189	Crocolisk Scale Wristguards
31190	The Dreamer's Shoulderpads
31191	Crocolisk Hide Bracers
31192	Crocolisk Hide Bindings
31193	Blade of Unquenched Thirst
31194	Gronn-Blessed Warbeads
31195	Voidplate Girdle
31196	Amulet of Sanctification
31197	Voidscale Belt
31198	Voidhide Cord
31199	Voidweave Cilice
31200	Shield of the Wayward Footman
31201	Illidari Cloak
31202	Girdle of Divine Blessing
31203	Arcane Loop
31204	The Gunblade
31209	Chimaerascale Legplates
31210	Chimaerascale Legguards
31211	Chimaerahide Pants
31212	Chimaerahide Leggings
31213	Abyssal Plate Sabatons
31214	Abyssal Mail Greaves
31215	Abyssal Leather Treads
31216	Abyssal Cloth Footwraps
31217	Crimson Beholder Eye
31218	Fiery Beholder Eye
31219	Emerald Beholder Eye
31220	Amethyst Beholder Eye
31221	Illidari Vambraces
31222	Headdress of Inner Rage
31223	Illidari Wristguards
31224	Illidari Bracers
31225	Illidari Bindings
31226	Leggings of the Sly
31227	Feathered Girdle
31228	Feathered Belt
31229	Feathered Waistband
31230	Abyss Walker's Boots
31231	Feathered Sash
31232	Grim Sabatons
31233	Grim Greaves
31234	Crystalblade of the Draenei
31235	Grim Boots
31236	Grim Slippers
31237	Elekk Hide Leggings
31238	Dragonbone Ring
31239	Primed Key Mold
31240	Scales of the Beast
31241	Primed Key Mold
31242	Nagascale Legplates
31243	Nagascale Legguards
31244	Nagahide Pants
31245	Primed Key Mold
31246	Nagahide Leggings
31247	Bog Pauldrons
31248	Bog Epaulets
31249	Bog Spaulders
31250	Bog Mantle
31251	Unfired Key Mold
31252	Charred Key Mold
31253	(Action Figure) Night Elf Druid Staff
31254	Striderhide Cloak
31255	Cloak of the Craft
31256	Silvermoon Armor
31257	(Action Figure) Troll Priest Staff
31258	Band of Sorrow
31259	(Action Figure) Human Warrior Sword
31260	Sketh'lon Commander's Journal - Page 1
31261	Sketh'lon Commander's Journal - Page 2
31262	Sketh'lon Commander's Journal - Page 3
31263	Silvermoon Tunic
31264	Silvermoon Robes
31265	(Action Figure) Human Warrior Shield
31266	(Action Figure) Tauren Hunter Polearm
31267	(Action Figure) Gnome Warrior Sword
31268	Abomination Cleaver
31269	Ghoul Hammer
31270	Banshee Rod
31271	Illidan's Command
31272	Crown of Endless Knowledge
31275	Necklace of Trophies
31276	Boots of Zealotry
31277	Pathfinder's Band
31278	Illidari Tabard
31279	Enchanted Illidari Tabard
31280	Thundercaller's Gauntlets
31281	Mask of Veiled Death
31282	Shroud of Spiritual Purity
31283	Sash of Sealed Fate
31284	Bracers of Recklessness
31285	Chestguard of the Talon
31286	Breastplate of Rapid Striking
31287	Draenei Honor Guard Shield
31288	The Master's Treads
31289	Staff of Divine Infusion
31290	Band of Dominion
31291	Crystalforged War Axe
31292	Crystal Pulse Shield
31293	Girdle of Gale Force
31294	Pauldrons of Surging Mana
31295	Chestguard of the Dark Stalker
31297	Robe of the Crimson Order
31298	Legguards of the Shattered Hand
31299	The Oathkeeper
31300	Ironroot Seeds
31302	onster - Sword, Stratholme D3
31303	Valanos' Longbow
31304	The Essence Focuser
31305	Ced's Carver
31306	Leggings of the Sacred Crest
31307	Heart of Fury
31308	The Bringer of Death
31310	Wildhammer Flare Gun
31312	Sinister Area 52 Boots
31313	Nether-Rocket Gloves
31314	Rocket-Chief Pauldrons
31315	Goblin Girdle
31316	Lianthe's Key
31317	Rod of Lianthe
31318	Singing Crystal Axe
31319	Band of Impenetrable Defenses
31320	Chestguard of Exile
31321	Choker of Repentance
31322	The Hammer of Destiny
31323	Don Santos' Famous Hunting Rifle
31324	Sketh'lon Feather
31326	Truestrike Ring
31328	Leggings of Beast Mastery
31329	Lifegiving Cloak
31330	Lightning Crown
31331	The Night Blade
31332	Blinkstrike
31333	The Night Watchman
31334	Staff of Natural Fury
31335	Pants of Living Growth
31336	Blade of Wizardry
31337	Orb of the Blackwhelp
31338	Charlotte's Ivy
31339	Lola's Eve
31340	Will of Edward the Odd
31341	Wyrmcultist's Cloak
31342	The Ancient Scepter of Sue-Min
31343	Kamaei's Cerulean Skirt
31344	Ceremonial Incense
31345	The Journal of Val'zareq
31346	Burning Bleeding Hollow Torch
31347	Bleeding Hollow Torch
31349	Grulloc's Sack
31350	Huffer's Whistle
31351	Dragonfire Trap
31354	Recipe: Flask of the Titans
31355	Recipe: Flask of Supreme Power
31356	Recipe: Flask of Distilled Wisdom
31357	Recipe: Flask of Chromatic Resistance
31358	Design: Dawnstone Crab
31359	Design: Enduring Deep Peridot
31360	Unfinished Headpiece
31361	Pattern: Cobrahide Leg Armor
31362	Pattern: Nethercobra Leg Armor
31363	Gorgrom's Favor
31364	Wildguard Breastplate
31365	Energized Headpiece
31366	Felsworn Gas Mask
31367	Wildguard Leggings
31368	Wildguard Helm
31369	Iceguard Breastplate
31370	Iceguard Leggings
31371	Iceguard Helm
31372	Rocknail Flayer Carcass
31373	Rocknail Flayer Giblets
31374	Worg Master's Head
31375	Gladiator's Kodohide Gloves
31376	Gladiator's Kodohide Helm
31377	Gladiator's Kodohide Legguards
31378	Gladiator's Kodohide Spaulders
31379	Gladiator's Kodohide Tunic
31380	Acrobat's Mark of the Sha'tar
31381	Aggressor's Mark of the Sha'tar
31382	Mage's Mark of the Sha'tar
31383	Spiritualist's Mark of the Sha'tar
31384	Damaged Mask
31386	Staff of Parshah
31387	Mystery Mask
31389	Captured Eye of Grillok
31390	Plans: Wildguard Breastplate
31391	Plans: Wildguard Leggings
31392	Plans: Wildguard Helm
31393	Plans: Iceguard Breastplate
31394	Plans: Iceguard Leggings
31395	Plans: Iceguard Helm
31396	Gladiator's Ringmail Armor
31397	Gladiator's Ringmail Gauntlets
31398	The Frozen Eye
31399	The Natural Ward
31400	Gladiator's Ringmail Helm
31401	Design: The Frozen Eye
31402	Design: The Natural Ward
31403	Sablemane's Sleeping Powder
31404	Green Trophy Tabard of the Illidari
31405	Purple Trophy Tabard of the Illidari
31406	Gladiator's Ringmail Leggings
31407	Gladiator's Ringmail Spaulders
31408	Offering of the Sha'tar
31409	Gladiator's Mooncloth Gloves
31410	Gladiator's Mooncloth Hood
31411	Gladiator's Mooncloth Leggings
31412	Gladiator's Mooncloth Mantle
31413	Gladiator's Mooncloth Robe
31414	Wild Wood Staff
31415	Iron Oak Shield
31416	Scorch Wood Bow
31417	Staff of the Ashtongue Deathsworn
31418	Sylvanaar Gloves
31419	Living Grove Shoulderpads
31420	Protector's Boots
31421	Sentinel Armbands
31422	Heavy Elven Dirk
31423	Wolf Hewer's Axe
31424	Arcane Wand of Sylvanaar
31425	Ogre Vanquisher's Belt
31426	Agile Mountain Bracers
31427	Sylvanaar Defender's Pauldrons
31428	Commander Skyshadow's Gloves
31429	Spelunker's Mantle
31430	Miner's Gloves
31431	All-Weather Armguards
31432	Explorer's Boots
31433	Sylvanaar Elite Caster's Armor
31434	Ogre Assassin's Britches
31435	Gurn's Horned Helmet
31436	Sylvanaar Champion's Shoulders
31437	Medicinal Drake Essence
31438	Fizit's Mantle of Drake Hunting
31439	Precise Gloves of Alacrity
31440	Devolved Drake Girdle
31441	Clocktock's Jumpers
31442	Metro's Slimming Legs
31443	Nickwinkle's Harness Experiment
31444	Party Hat Mistake
31445	Last Year's "In" Belt
31446	Vibro Shanker
31447	Vibro Dagger
31448	Vibro Sword
31449	Distilled Stalker Sight
31450	Stealth of the Stalker
31451	Pure Energy
31452	Energized Wristwraps
31453	Charged Footwear
31454	Scalewing Gloves
31455	Muscle Toning Belt
31456	Gnomish Casting Boots
31457	Toshley's Station Hero's Hat
31458	Razaani-Buster Leggings
31459	Soul Saver's Chest Plate
31460	Sha'tari Vindicator's Waistguard
31461	A'dal's Gift
31462	Shattrath's Champion Belt
31463	Zezzak's Shard
31464	Naaru Belt of Precision
31465	Sha'tari Anchorite's Cloak
31469	Black Dragon Corpse
31470	Witch Doctor's Beads
31471	T'chali's Kilt
31472	Hexxer's Belt
31473	Ogre Defiler's Handguards
31474	Wand of the Ancestors
31475	Thunderlord Scalpel
31476	Slow Death Dirk
31477	Red Hands of the Thunderlord
31478	Tor'chunk's Foot Covers
31479	Rugged Mountain Bracers
31480	Ogre Beater's Belt
31481	Thunderlord Armbands
31482	Dire Wolf Handler Gloves
31483	Gor'drek's Pauldrons
31484	Wolf Chaps
31485	Dark Deed Leggings
31486	Bear-Strength Harness
31487	Wild Horned Helm
31488	Boots of the Ancient-Killer
31489	Orb of the Grishna
31490	Netherwing Protector's Shield
31491	Netherwing Defender's Shield
31492	Claw of the Netherwing Flight
31493	Netherwing Spiritualist's Charm
31494	Netherwing Sorceror's Charm
31495	Grishnath Orb
31496	Tome of Fireball XIV
31498	Tome of Frostbolt XIV
31500	Tome of Arcane Missiles XI
31501	Tome of Conjure Food VIII
31502	Libram: Blessing of Might VIII
31503	Libram: Greater Blessing of Might III
31504	Nethervine Crystal
31505	Manual of Heroic Strike XI
31506	Manual of Revenge VIII
31507	Grimoire of Searing Pain
31508	Coven Britches
31509	Wyrmcultist's Hood
31510	Hewing Gloves
31511	Chest of the Wyrmcult
31512	Tree Warden's Belt
31513	Blackwhelp Belt
31514	Dragonkin Shirt
31515	Whelpscale Gauntlets
31516	Bracers of the Weald
31517	Dire Pinfeather
31518	Exorcism Feather
31519	Inkling's Leggings
31520	Blackwing Helm
31521	Expedition Defender's Shoulders
31522	Primal Mooncloth Supplies
31523	Treebole's Hoop
31524	Square of Imbued Netherweave
31525	Vial of Primal Reagents
31526	Raven's Wood Exorciser's Band
31527	Leafbeard Ring
31528	Ring of the Stonebark
31529	Grillok's Eyepatch
31530	Sample of Primal Mooncloth
31531	Wraithcloth Bindings
31532	Supple Leather Boots
31533	Diluvian Spaulders
31534	Whiteknuckle Gauntlets
31535	Bloodboil Poison
31536	Camp Anger Key
31537	Darktread Boots
31538	Twin Moon Shoulderguards
31539	Chaintwine Cinch
31540	Fairweather's Wristguards
31541	Whistling Sword
31542	Fanged Axe
31543	Adjudicator's Staff
31544	Clefthoof Hide Leggings
31545	Oilcloth Breeches
31546	Tourmaline Crown
31547	Malefactor's Eyepatch
31548	Blackened Chestplate
31549	Leonine Breastplate
31550	Albreck's Findings
31552	Windchanneller's Miter
31553	Windchanneller's Mantle
31554	Windchanneller's Tunic
31555	Windchanneller's Ceinture
31556	Windchanneller's Leggings
31557	Windchanneller's Boots
31558	Windchanneller's Bindings
31559	Windchanneller's Gloves
31560	Skystalker's Shroud
31561	Skystalker's Shoulders
31562	Skystalker's Tunic
31563	Skystalker's Cord
31564	Skystalker's Leggings
31565	Skystalker's Boots
31566	Skystalker's Bracers
31567	Skystalker's Gloves
31568	Mistshroud Helm
31569	Mistshroud Shoulders
31570	Mistshroud Tunic
31571	Mistshroud Belt
31572	Mistshroud Pants
31573	Mistshroud Boots
31574	Mistshroud Bracers
31575	Mistshroud Gauntlets
31576	Slatesteel Helm
31577	Slatesteel Shoulders
31578	Slatesteel Breastplate
31579	Slatesteel Girdle
31580	Slatesteel Leggings
31581	Slatesteel Boots
31582	Slatesteel Bracers
31583	Slatesteel Gauntlets
31584	High Warlord's Kodohide Gloves
31585	High Warlord's Kodohide Helm
31586	High Warlord's Kodohide Legguards
31587	High Warlord's Kodohide Spaulders
31588	High Warlord's Kodohide Tunic
31589	Grand Marshal's Kodohide Gloves
31590	Grand Marshal's Kodohide Helm
31591	Grand Marshal's Kodohide Legguards
31592	Grand Marshal's Kodohide Spaulders
31593	Grand Marshal's Kodohide Tunic
31594	General's Kodohide Belt
31595	General's Kodohide Boots
31596	Marshal's Kodohide Belt
31597	Marshal's Kodohide Boots
31598	General's Kodohide Bracers
31599	Marshal's Kodohide Bracers
31606	Demoniac Scryer
31607	Demoniac Scryer Reading
31610	Rod of Purification
31613	Gladiator's Ornamented Chestguard
31614	Gladiator's Ornamented Gloves
31615	Ancient Draenei Arcane Relic
31616	Gladiator's Ornamented Headcover
31617	Ancient Draenei War Talisman
31618	Gladiator's Ornamented Legplates
31619	Gladiator's Ornamented Spaulders
31620	Grand Marshal's Mooncloth Mitts
31621	High Warlord's Mooncloth Mitts
31622	Grand Marshal's Mooncloth Cowl
31623	Grand Marshal's Mooncloth Legguards
31624	Grand Marshal's Mooncloth Shoulderpads
31625	Grand Marshal's Mooncloth Vestments
31626	High Warlord's Mooncloth Cowl
31627	High Warlord's Mooncloth Legguards
31628	High Warlord's Mooncloth Shoulderpads
31629	High Warlord's Mooncloth Vestments
31630	Grand Marshal's Ornamented Chestplate
31631	Grand Marshal's Ornamented Gloves
31632	Grand Marshal's Ornamented Headguard
31633	Grand Marshal's Ornamented Leggings
31634	Grand Marshal's Ornamented Spaulders
31635	High Warlord's Ornamented Chestplate
31636	High Warlord's Ornamented Gloves
31637	High Warlord's Ornamented Headguard
31638	High Warlord's Ornamented Leggings
31639	High Warlord's Ornamented Spaulders
31640	Grand Marshal's Ringmail Chestguard
31641	Grand Marshal's Ringmail Gloves
31642	Grand Marshal's Ringmail Headpiece
31643	Grand Marshal's Ringmail Legguards
31644	Grand Marshal's Ringmail Shoulders
31646	High Warlord's Ringmail Chestguard
31647	High Warlord's Ringmail Gloves
31648	High Warlord's Ringmail Headpiece
31649	High Warlord's Ringmail Legguards
31650	High Warlord's Ringmail Shoulderpads
31651	Bladespire Totem
31652	Enchanted Nethervine Crystal
31653	Condensed Nether Gas
31655	Veil Skith Prison Key
31656	Lesser Nether Drake Spirit
31657	Chemise of Rebirth
31658	Scout's Hood
31659	Researcher's Mantle
31660	Feralfen Skulker's Belt
31661	Leesa'oh's Wristbands
31662	Rilak's Missive
31663	Spirit Calling Totems
31664	Zuluhed's Key
31665	Toy RC Mortar Tank
31666	Battered Steam Tonk Controller
31667	Knife of a Thousand Lies
31668	Orb Collecting Totem
31670	Raptor Ribs
31671	Serpent Flesh
31672	Mok'Nathal Shortribs
31673	Crunchy Serpent
31674	Recipe: Crunchy Serpent
31675	Recipe: Mok'Nathal Shortribs
31676	Fel Regeneration Potion
31677	Fel Mana Potion
31678	Mental Interference Rod
31679	Fel Strength Elixir
31680	Recipe: Fel Strength Elixir
31681	Recipe: Fel Regeneration Potion
31682	Recipe: Fel Mana Potion
31683	Dreadwing Skin Belt
31684	Netherhide Gloves
31685	Brood Mother Leggings
31686	Nether Protector's Chest
31687	Mok'Nathal Mantle
31688	Spiritcaller's Mask
31689	Mok'Nathal Hero's Pantaloons
31690	Belt of the Soul Saver
31691	Natasha's Guardian Cord
31692	Natasha's Ember Necklace
31693	Natasha's Arcane Filament
31694	Natasha's Pack Collar
31695	Natasha's Choker
31696	Natasha's Battle Chain
31697	Dread Relic
31698	Letter from Shattrath
31699	Imbued Draenethyst Crystal
31700	Runed Silver Staff
31701	Saboteur's Axe
31702	Challenge from the Horde
31703	Nether-Stalker's Blade
31704	The Tempest Key
31705	Derelict Caravan Chest Key
31706	The Head of the Hand of Kargath
31707	Cabal Orders
31708	Scroll of Atalor
31709	Drape of Arunen
31710	Gavel of K'alen
31711	Nether-Empowered Footgear
31712	Mok'Nathal Champion's Shoulderguards
31713	Ritualist's Helm
31714	Nether Drake Wristguards
31715	Demoniac Soul Prison
31717	Shadowcast Tunic
31718	Darkstorm Tunic
31719	Stormstrike Vest
31720	Battlemaster's Breastplate
31721	Kalithresh's Trident
31722	Murmur's Essence
31723	Madman's Blade
31724	Arakkoa Divining Rod
31725	Cilice of Suffering
31726	Necklace of Bloodied Feathers
31727	Choker of Bloodied Feathers
31728	Heirloom Signet of Willpower
31729	Heirloom Signet of Valor
31730	Heirloom Signet of Convalescence
31731	Mekeda's Gift
31732	Unearthed Orb
31733	Akuno's Blade
31734	Ancient Draenei Crest
31735	Timeless Shell
31736	Crystal of Deep Shadows
31737	Timeless Arrow
31739	Smoke Beacon
31740	Meeting Note
31741	Nether-wraith Essence
31742	Nether-wraith Beacon
31744	Botanist's Field Guide
31745	Illidari-Bane Dagger
31746	Phoenix-fire Band
31747	Potent Sha'tari Pendant
31748	Shattrath Choker of Power
31749	A'dal's Recovery Necklace
31750	Earthen Signet
31751	Blazing Signet
31752	Sablemane's Trap
31753	Essence of Infinity
31754	Grisly Totem
31755	Wyvern Cage Key
31756	Dib'Muad's Crysknife
31757	Fel Cannonball
31758	Revered Mother's Crysknife
31759	Shani's Crysknife
31760	Miniwing
31761	Talonbranch Wand
31762	Feather-Wrapped Bow
31763	Druid Signal
31764	Stillfire Leggings
31765	Redeemer's Plate
31766	Skywitch Hat
31767	[TXT]Rexxar's Misha Summoner
31768	Deep Mire Cloak
31769	Sha'tari Torch
31770	Marsh Bracers
31772	Anchorite Relic
31773	Mag'har Tabard
31774	Kurenai Tabard
31775	Sporeggar Tabard
31776	Consortium Tabard
31777	Keepers of Time Tabard
31778	Lower City Tabard
31779	Aldor Tabard
31780	Scryers Tabard
31781	Sha'tar Tabard
31782	Warpstalker Breastplate
31783	Bloodfire Leggings
31784	Ancient Terokkar Hood
31785	Edge of Inevitability
31786	Blacksting Shoulders
31787	Stalwart Girdle
31788	Blacksting Gloves
31789	Marshfang Boots
31790	Expedition Pendant
31791	Wildlord's Band
31792	Evergrove Ranger's Cloak
31793	Ruuan Weald Wristguards
31794	Sha'tari Vindicator's Legplates
31795	Draenei Prayer Beads
31796	Sha'tari Marksman's Gloves
31797	Elekk Hide Spaulders
31798	Death-Speaker's Tunic
31799	Fei Fei Doggy Treat
31800	Outcast's Cache
31804	Cenarion Expedition Tabard
31807	Naturalized Ammunition
31808	Sablemane's Signet
31809	Evergrove Wand
31810	Fumper
31811	Dread Relic
31812	Doom Skull
31813	Warp Chaser Blood
31814	Mature Bone Sifter Carcass
31815	Zeppit's Crystal
31816	Dragonbone Greatsword
31817	Dragonbone Shoulders
31818	Dragonbone Talisman
31819	Noble Plate Pauldrons
31820	Blessed Signet Ring
31821	Blade of Retribution
31823	Book of Many Blessings
31825	Fumper
31826	Enormous Bone Worm Organs
31827	Sablemane's Trap
31828	Ritual Prayer Beads
31829	Reins of the Cobalt Riding Talbuk
31830	Reins of the Cobalt Riding Talbuk
31831	Reins of the Silver Riding Talbuk
31832	Reins of the Silver Riding Talbuk
31833	Reins of the Tan Riding Talbuk
31834	Reins of the Tan Riding Talbuk
31835	Reins of the White Riding Talbuk
31836	Reins of the White Riding Talbuk
31837	Codex: Prayer of Shadow Protection II
31838	Major Combat Healing Potion
31839	Major Combat Healing Potion
31840	Major Combat Mana Potion
31841	Major Combat Mana Potion
31842	QAEnchant Bracer +12 Intellect
31843	QAEnchant Bracer +24 Attack Power
31844	QAEnchant Bracer +30 Healing
31845	QAEnchant Bracer +15 Spell Damage
31846	QAEnchant Bracer +12 Defense
31847	QAEnchant Bracer +12 Stamina
31848	QAEnchant Bracer +4 All Stats
31849	QAEnchant Bracer +12 Strength
31852	Major Combat Healing Potion
31853	Major Combat Healing Potion
31854	Major Combat Mana Potion
31855	Major Combat Mana Potion
31856	Darkmoon Card: Crusade
31857	Darkmoon Card: Wrath
31858	Darkmoon Card: Vengeance
31859	Darkmoon Card: Madness
31860	Great Golden Draenite
31861	Great Dawnstone
31862	Balanced Shadow Draenite
31863	Balanced Nightseye
31864	Infused Shadow Draenite
31865	Infused Nightseye
31866	Veiled Flame Spessarite
31867	Veiled Noble Topaz
31868	Wicked Noble Topaz
31869	Wicked Flame Spessarite
31870	Design: Great Golden Draenite
31871	Design: Balanced Shadow Draenite
31872	Design: Infused Shadow Draenite
31873	Design: Veiled Flame Spessarite
31874	Design: Wicked Flame Spessarite
31875	Design: Great Dawnstone
31876	Design: Balanced Nightseye
31877	Design: Infused Nightseye
31878	Design: Veiled Noble Topaz
31879	Design: Wicked Noble Topaz
31880	Blood Elf Orphan Whistle
31881	Draenei Orphan Whistle
31882	Ace of Blessings
31883	Eight of Blessings
31884	Five of Blessings
31885	Four of Blessings
31886	Seven of Blessings
31887	Six of Blessings
31888	Three of Blessings
31889	Two of Blessings
31890	Blessings Deck
31891	Storms Deck
31892	Ace of Storms
31893	Eight of Storms
31894	Five of Storms
31895	Four of Storms
31896	Seven of Storms
31898	Six of Storms
31899	Three of Storms
31900	Two of Storms
31901	Ace of Furies
31902	Eight of Furies
31903	Five of Furies
31904	Four of Furies
31905	Seven of Furies
31906	Six of Furies
31907	Furies Deck
31908	Three of Furies
31909	Two of Furies
31910	Ace of Lunacy
31911	Eight of Lunacy
31912	Five of Lunacy
31913	Four of Lunacy
31914	Lunacy Deck
31915	Seven of Lunacy
31916	Six of Lunacy
31917	Three of Lunacy
31918	Two of Lunacy
31919	Nexus-Prince's Ring of Balance
31920	Shaffar's Band of Brutality
31921	Yor's Collapsing Band
31922	Ring of Conflict Survival
31923	Band of the Crystalline Void
31924	Yor's Revenge
31925	Fiery Band
31926	Frigid Band
31927	Living Band
31928	Dark Band
31929	Enigmatic Band
31930	Enigmatic Charm
31931	Fiery Charm
31932	Living Charm
31933	Dark Charm
31934	Frigid Charm
31935	Frigid Cloak
31936	Fiery Cloak
31937	Living Cloak
31938	Enigmatic Cloak
31939	Dark Cloak
31940	Ethereum Torque
31941	Mark of the Nexus-King
31942	Deathwing Brood Cloak
31943	Ethereum Band
31944	Demonic Capacitor
31945	Shadow Circuit
31946	Ashtongue Cowl
31947	Energized Isolation Cube
31948	Skystalk
31949	Warden's Arrow
31950	Bogblossom
31951	Toy Dragon
31952	Khorium Lockbox
31953	Ward of Waking
31954	Chewed Up Boot
31955	Arelion's Knapsack
31956	Salvaged Ethereum Prison Key
31957	Ethereum Prisoner I.D. Tag
31958	Merciless Gladiator's Bonecracker
31959	Merciless Gladiator's Bonegrinder
31960	Merciless Gladiator's Chain Armor
31961	Merciless Gladiator's Chain Gauntlets
31962	Merciless Gladiator's Chain Helm
31963	Merciless Gladiator's Chain Leggings
31964	Merciless Gladiator's Chain Spaulders
31965	Merciless Gladiator's Cleaver
31966	Merciless Gladiator's Decapitator
31967	Merciless Gladiator's Dragonhide Gloves
31968	Merciless Gladiator's Dragonhide Helm
31969	Merciless Gladiator's Dragonhide Legguards
31971	Merciless Gladiator's Dragonhide Spaulders
31972	Merciless Gladiator's Dragonhide Tunic
31973	Merciless Gladiator's Dreadweave Gloves
31974	Merciless Gladiator's Dreadweave Hood
31975	Merciless Gladiator's Dreadweave Leggings
31976	Merciless Gladiator's Dreadweave Mantle
31977	Merciless Gladiator's Dreadweave Robe
31978	Merciless Gladiator's Endgame
31979	Merciless Gladiator's Felweave Amice
31980	Merciless Gladiator's Felweave Cowl
31981	Merciless Gladiator's Felweave Handguards
31982	Merciless Gladiator's Felweave Raiment
31983	Merciless Gladiator's Felweave Trousers
31984	Merciless Gladiator's Greatsword
31985	Merciless Gladiator's Hacker
31986	Merciless Gladiator's Crossbow of the Phoenix
31987	Merciless Gladiator's Kodohide Gloves
31988	Merciless Gladiator's Kodohide Helm
31989	Merciless Gladiator's Kodohide Legguards
31990	Merciless Gladiator's Kodohide Spaulders
31991	Merciless Gladiator's Kodohide Tunic
31992	Merciless Gladiator's Lamellar Chestpiece
31993	Merciless Gladiator's Lamellar Gauntlets
31994	Ethereum Key Tablet - Alpha
31995	Merciless Gladiator's Lamellar Legguards
31996	Merciless Gladiator's Lamellar Shoulders
31997	Merciless Gladiator's Lamellar Helm
31998	Merciless Gladiator's Leather Gloves
31999	Merciless Gladiator's Leather Helm
32000	Merciless Gladiator's Leather Legguards
32001	Merciless Gladiator's Leather Spaulders
32002	Merciless Gladiator's Leather Tunic
32003	Merciless Gladiator's Left Ripper
32004	Merciless Gladiator's Linked Armor
32005	Merciless Gladiator's Linked Gauntlets
32006	Merciless Gladiator's Linked Helm
32007	Merciless Gladiator's Linked Leggings
32008	Merciless Gladiator's Linked Spaulders
32009	Merciless Gladiator's Mail Armor
32010	Merciless Gladiator's Mail Gauntlets
32011	Merciless Gladiator's Mail Helm
32012	Merciless Gladiator's Mail Leggings
32013	Merciless Gladiator's Mail Spaulders
32014	Merciless Gladiator's Maul
32015	Merciless Gladiator's Mooncloth Gloves
32016	Merciless Gladiator's Mooncloth Hood
32017	Merciless Gladiator's Mooncloth Leggings
32018	Merciless Gladiator's Mooncloth Mantle
32019	Merciless Gladiator's Mooncloth Robe
32020	Merciless Gladiator's Ornamented Chestguard
32021	Merciless Gladiator's Ornamented Gloves
32022	Merciless Gladiator's Ornamented Headcover
32023	Merciless Gladiator's Ornamented Legplates
32024	Merciless Gladiator's Ornamented Spaulders
32025	Merciless Gladiator's Painsaw
32026	Merciless Gladiator's Pummeler
32027	Merciless Gladiator's Quickblade
32028	Merciless Gladiator's Right Ripper
32029	Merciless Gladiator's Ringmail Armor
32030	Merciless Gladiator's Ringmail Gauntlets
32031	Merciless Gladiator's Ringmail Helm
32032	Merciless Gladiator's Ringmail Leggings
32033	Merciless Gladiator's Ringmail Spaulders
32034	Merciless Gladiator's Satin Gloves
32035	Merciless Gladiator's Satin Hood
32036	Merciless Gladiator's Satin Leggings
32037	Merciless Gladiator's Satin Mantle
32038	Merciless Gladiator's Satin Robe
32039	Merciless Gladiator's Scaled Chestpiece
32040	Merciless Gladiator's Scaled Gauntlets
32041	Merciless Gladiator's Scaled Helm
32042	Merciless Gladiator's Scaled Legguards
32043	Merciless Gladiator's Scaled Shoulders
32044	Merciless Gladiator's Shanker
32045	Merciless Gladiator's Shield Wall
32046	Merciless Gladiator's Shiv
32047	Merciless Gladiator's Silk Amice
32048	Merciless Gladiator's Silk Cowl
32049	Merciless Gladiator's Silk Handguards
32050	Merciless Gladiator's Silk Raiment
32051	Merciless Gladiator's Silk Trousers
32052	Merciless Gladiator's Slicer
32053	Merciless Gladiator's Spellblade
32054	Merciless Gladiator's War Edge
32055	Merciless Gladiator's War Staff
32056	Merciless Gladiator's Wyrmhide Gloves
32057	Merciless Gladiator's Wyrmhide Helm
32058	Merciless Gladiator's Wyrmhide Legguards
32059	Merciless Gladiator's Wyrmhide Spaulders
32060	Merciless Gladiator's Wyrmhide Tunic
32061	Evidence from Alpha
32062	Elixir of Major Fortitude
32063	Earthen Elixir
32064	Protectorate Treasure Cache
32067	Elixir of Draenic Wisdom
32068	Elixir of Ironskin
32069	Mana-Tombs Stasis Chamber Key
32070	Recipe: Earthen Elixir
32071	Recipe: Elixir of Ironskin
32072	Gauntlets of Dissension
32073	Spaulders of Dementia
32074	Relics of Aviana
32075	Book of the Raven
32076	Handguards of the Steady
32077	Wrath Infused Gauntlets
32078	Pauldrons of Wild Magic
32079	Shaffar's Stasis Chamber Key
32080	Mantle of Shadowy Embrace
32081	Eye of the Stalker
32082	The Fel Barrier
32083	Faceguard of Determination
32084	Helmet of the Steadfast Champion
32085	Warpstalker Helm
32086	Storm Master's Helmet
32087	Mask of the Deceiver
32088	Cowl of Beastly Rage
32089	Mana-Binders Cowl
32090	Cowl of Naaru Blessings
32092	The Eye of Haramad
32093	Chancellor's Dreadweave Gloves
32094	Chancellor's Dreadweave Hood
32095	Chancellor's Dreadweave Leggings
32096	Chancellor's Dreadweave Mantle
32097	Chancellor's Dreadweave Robe
32098	Chancellor's Mooncloth Cowl
32099	Chancellor's Mooncloth Legguards
32100	Chancellor's Mooncloth Mitts
32101	Chancellor's Mooncloth Shoulderpads
32102	Chancellor's Mooncloth Vestments
32103	Chancellor's Satin Gloves
32104	Chancellor's Satin Hood
32105	Chancellor's Satin Leggings
32106	Chancellor's Satin Mantle
32107	Chancellor's Satin Robe
32108	Chancellor's Silk Amice
32109	Chancellor's Silk Cowl
32110	Chancellor's Silk Handguards
32111	Chancellor's Silk Raiment
32112	Chancellor's Silk Trousers
32113	Chancellor's Dragonhide Gloves
32114	Chancellor's Dragonhide Helm
32115	Chancellor's Dragonhide Legguards
32116	Chancellor's Dragonhide Spaulders
32117	Chancellor's Dragonhide Tunic
32118	Chancellor's Kodohide Gloves
32119	Chancellor's Kodohide Helm
32120	Chancellor's Leather Legguards
32121	Chancellor's Kodohide Spaulders
32122	Chancellor's Kodohide Legguards
32123	Chancellor's Kodohide Tunic
32124	Chancellor's Leather Gloves
32125	Chancellor's Leather Helm
32126	Chancellor's Leather Spaulders
32127	Chancellor's Leather Tunic
32128	Chancellor's Wyrmhide Gloves
32129	Chancellor's Wyrmhide Helm
32130	Chancellor's Wyrmhide Legguards
32131	Chancellor's Wyrmhide Spaulders
32132	Chancellor's Wyrmhide Tunic
32133	Chancellor's Chain Armor
32134	Chancellor's Chain Gauntlets
32135	Chancellor's Chain Helm
32136	Chancellor's Chain Leggings
32137	Chancellor's Chain Spaulders
32138	Chancellor's Linked Armor
32139	Chancellor's Linked Gauntlets
32140	Chancellor's Linked Helm
32141	Chancellor's Linked Leggings
32142	Chancellor's Linked Spaulders
32143	Chancellor's Mail Armor
32144	Chancellor's Mail Gauntlets
32145	Chancellor's Mail Helm
32146	Chancellor's Mail Leggings
32147	Chancellor's Mail Spaulders
32148	Chancellor's Ringmail Chestguard
32149	Chancellor's Ringmail Gloves
32150	Chancellor's Ringmail Headpiece
32151	Chancellor's Ringmail Legguards
32152	Chancellor's Ringmail Shoulders
32153	Chancellor's Lamellar Chestpiece
32154	Chancellor's Lamellar Gauntlets
32155	Chancellor's Lamellar Helm
32156	Chancellor's Lamellar Legguards
32157	Chancellor's Lamellar Shoulders
32158	Chancellor's Ornamented Chestplate
32159	Chancellor's Ornamented Gloves
32160	Chancellor's Ornamented Headguard
32161	Chancellor's Ornamented Leggings
32162	Chancellor's Ornamented Spaulders
32163	Chancellor's Plate Chestpiece
32164	Chancellor's Plate Gauntlets
32165	Chancellor's Plate Helm
32166	Chancellor's Plate Legguards
32167	Chancellor's Plate Shoulders
32168	Chancellor's Scaled Chestpiece
32169	Chancellor's Scaled Gauntlets
32170	Chancellor's Scaled Helm
32171	Chancellor's Scaled Legguards
32172	Chancellor's Scaled Shoulders
32173	Chancellor's Bonecracker
32174	Chancellor's Cleaver
32175	Chancellor's Hacker
32176	Chancellor's Pummeler
32177	Chancellor's Quickblade
32178	Chancellor's Shanker
32179	Chancellor's Shiv
32180	Chancellor's Slicer
32181	Chancellor's Bonegrinder
32182	Chancellor's Decapitator
32183	Chancellor's Maul
32184	Chancellor's Painsaw
32185	Chancellor's War Staff
32186	Chancellor's Warblade
32187	Chancellor's Heavy Crossbow
32188	Chancellor's Left Ripper
32189	Chancellor's Right Ripper
32190	Chancellor's Spellblade
32191	Chancellor's Battletome
32192	Chancellor's Barricade
32193	Bold Crimson Spinel
32194	Delicate Crimson Spinel
32195	Teardrop Crimson Spinel
32196	Runed Crimson Spinel
32197	Bright Crimson Spinel
32198	Subtle Crimson Spinel
32199	Flashing Crimson Spinel
32200	Solid Empyrean Sapphire
32201	Sparkling Empyrean Sapphire
32202	Lustrous Empyrean Sapphire
32203	Stormy Empyrean Sapphire
32204	Brilliant Lionseye
32205	Smooth Lionseye
32206	Rigid Lionseye
32207	Gleaming Lionseye
32208	Thick Lionseye
32209	Mystic Lionseye
32210	Great Lionseye
32211	Sovereign Shadowsong Amethyst
32212	Shifting Shadowsong Amethyst
32213	Balanced Shadowsong Amethyst
32214	Infused Shadowsong Amethyst
32215	Glowing Shadowsong Amethyst
32216	Royal Shadowsong Amethyst
32217	Inscribed Pyrestone
32218	Potent Pyrestone
32219	Luminous Pyrestone
32220	Glinting Pyrestone
32221	Veiled Pyrestone
32222	Wicked Pyrestone
32223	Enduring Seaspray Emerald
32224	Radiant Seaspray Emerald
32225	Dazzling Seaspray Emerald
32226	Jagged Seaspray Emerald
32227	Crimson Spinel
32228	Empyrean Sapphire
32229	Lionseye
32230	Shadowsong Amethyst
32231	Pyrestone
32232	Eternium Shell Bracers
32233	Wolpertinger's Tankard
32234	Fists of Mukoa
32235	Cursed Vision of Sargeras
32236	Rising Tide
32237	The Maelstrom's Fury
32238	Ring of Calming Waves
32239	Slippers of the Seacaller
32240	Guise of the Tidal Lurker
32241	Helm of Soothing Currents
32242	Boots of Oceanic Fury
32243	Pearl Inlaid Boots
32244	Seer's Stone
32245	Tide-stomper's Greaves
32247	Ring of Captured Storms
32248	Halberd of Desolation
32249	Seaspray Emerald
32250	Pauldrons of Abyssal Fury
32251	Wraps of Precise Flight
32252	Nether Shadow Tunic
32253	Legionkiller
32254	The Brutalizer
32255	Felstone Bulwark
32256	Waistwrap of Infinity
32257	Idol of the White Stag
32258	Naturalist's Preserving Cinch
32259	Bands of the Coming Storm
32260	Choker of Endless Nightmares
32261	Band of the Abyssal Lord
32262	Syphon of the Nathrezim
32263	Praetorian's Legguards
32264	Shoulders of the Hidden Predator
32265	Shadow-walker's Cord
32266	Ring of Deceitful Intent
32267	Boots of the Resilient
32268	Myrmidon's Treads
32269	Messenger of Fate
32270	Focused Mana Bindings
32271	Kilt of Immortal Nature
32273	Amice of Brilliant Light
32274	Design: Bold Crimson Spinel
32275	Spiritwalker Gauntlets
32276	Flashfire Girdle
32277	Design: Delicate Crimson Spinel
32278	Grips of Silent Justice
32279	The Seeker's Wristguards
32280	Gauntlets of Enforcement
32281	Design: Teardrop Crimson Spinel
32282	Design: Runed Crimson Spinel
32283	Design: Bright Crimson Spinel
32284	Design: Subtle Crimson Spinel
32285	Design: Flashing Crimson Spinel
32286	Design: Solid Empyrean Sapphire
32287	Design: Sparkling Empyrean Sapphire
32288	Design: Lustrous Empyrean Sapphire
32289	Design: Stormy Empyrean Sapphire
32290	Design: Brilliant Lionseye
32291	Design: Smooth Lionseye
32292	Design: Rigid Lionseye
32293	Design: Gleaming Lionseye
32294	Design: Thick Lionseye
32295	Design: Mystic Lionseye
32296	Design: Great Lionseye
32297	Design: Sovereign Shadowsong Amethyst
32298	Design: Shifting Shadowsong Amethyst
32299	Design: Balanced Shadowsong Amethyst
32300	Design: Infused Shadowsong Amethyst
32301	Design: Glowing Shadowsong Amethyst
32302	Design: Royal Shadowsong Amethyst
32303	Design: Inscribed Pyrestone
32304	Design: Potent Pyrestone
32305	Design: Luminous Pyrestone
32306	Design: Glinting Pyrestone
32307	Design: Veiled Pyrestone
32308	Design: Wicked Pyrestone
32309	Design: Enduring Seaspray Emerald
32310	Design: Radiant Seaspray Emerald
32311	Design: Dazzling Seaspray Emerald
32312	Design: Jagged Seaspray Emerald
32313	Raven Stone
32314	Green Riding Nether Ray
32315	Cenarion Sparrowhawk Whistle
32316	Purple Riding Nether Ray
32317	Red Riding Nether Ray
32318	Silver Riding Nether Ray
32319	Blue Riding Nether Ray
32320	Captive Sparrowhawk
32321	Sparrowhawk Net
32323	Shadowmoon Destroyer's Drape
32324	Insidious Bands
32325	Rifle of the Stoic Guardian
32326	Twisted Blades of Zarak
32327	Robe of the Shadow Council
32328	Botanist's Gloves of Growth
32329	Cowl of Benevolence
32330	Totem of Ancestral Guidance
32331	Cloak of the Illidari Council
32332	Torch of the Damned
32333	Girdle of Stability
32334	Vest of Mounting Assault
32335	Unstoppable Aggressor's Ring
32336	Black Bow of the Betrayer
32337	Shroud of Forgiveness
32338	Blood-cursed Shoulderpads
32339	Belt of Primal Majesty
32340	Garments of Temperance
32341	Leggings of Divine Retribution
32342	Girdle of Mighty Resolve
32343	Wand of Prismatic Focus
32344	Staff of Immaculate Recovery
32345	Dreadboots of the Legion
32346	Boneweave Girdle
32347	Grips of Damnation
32348	Soul Cleaver
32349	Translucent Spellthread Necklace
32350	Touch of Inspiration
32351	Elunite Empowered Bracers
32352	Naturewarden's Treads
32353	Gloves of Unfailing Faith
32354	Crown of Empowered Fate
32355	Essence of the Eagle
32356	Essence of the Hawk
32357	Essence of the Falcon
32358	Vim'gol's Vile Grimoire
32359	Arthorn's Package
32361	Blind-Seers Icon
32362	Pendant of Titans
32363	Naaru-Blessed Life Rod
32364	Southfury Moonstone
32365	Heartshatter Breastplate
32366	Shadowmaster's Boots
32367	Leggings of Devastation
32368	Tome of the Lightbringer
32369	Blade of Savagery
32370	Nadina's Pendant of Purity
32373	Helm of the Illidari Shatterer
32374	Zhar'doom, Greatstaff of the Devourer
32375	Bulwark of Azzinoth
32376	Forest Prowler's Helm
32377	Mantle of Darkness
32378	Silver Star
32379	Grulloc's Dragon Skull
32380	Maggoc's Treasure Chest
32381	Schematic: Fused Wiring
32382	Slaag's Standard
32383	Skulloc's Soul
32385	Magtheridon's Head
32386	Magtheridon's Head
32387	Idol of the Raven Goddess
32388	Shadow Dust
32389	Soulguard Leggings
32390	Soulguard Girdle
32391	Soulguard Slippers
32392	Soulguard Bracers
32393	Redeemed Soul Cinch
32394	Redeemed Soul Moccasins
32395	Redeemed Soul Wristguards
32396	Redeemed Soul Legguards
32397	Waistguard of Shackled Souls
32398	Boots of Shackled Souls
32399	Bracers of Shackled Souls
32400	Greaves of Shackled Souls
32401	Shadesteel Girdle
32402	Shadesteel Sabots
32403	Shadesteel Bracers
32404	Shadesteel Greaves
32405	Verdant Sphere
32406	Skyguard Blasting Charges
32407	Creature - Maiev's Glaive
32408	Naj'entus Spine
32409	Relentless Earthstorm Diamond
32410	Thundering Skyfire Diamond
32411	Design: Thundering Skyfire Diamond
32412	Design: Relentless Earthstorm Diamond
32413	Frost Grenade
32414	Tom's Legs A
32415	Tom's Legs B
32416	Tom's Legs C
32417	Tom's Legs 1
32418	Tom's Legs 2
32419	Tom's Legs 3
32420	Night's End
32421	Tom's Axe A
32422	Tom's Axe B
32423	Icy Blasting Primers
32424	Blade's Edge Ogre Brew
32426	Testing Darkrune
32427	Netherwing Crystal
32428	Heart of Darkness
32429	Pattern: Boots of Shackled Souls
32430	Pattern: Bracers of Shackled Souls
32431	Pattern: Greaves of Shackled Souls
32432	Pattern: Waistguard of Shackled Souls
32433	Pattern: Redeemed Soul Moccasins
32434	Pattern: Redeemed Soul Wristguards
32435	Pattern: Redeemed Soul Legguards
32436	Pattern: Redeemed Soul Cinch
32437	Pattern: Soulguard Slippers
32438	Pattern: Soulguard Bracers
32439	Pattern: Soulguard Leggings
32440	Pattern: Soulguard Girdle
32441	Plans: Shadesteel Sabots
32442	Plans: Shadesteel Bracers
32443	Plans: Shadesteel Greaves
32444	Plans: Shadesteel Girdle
32445	Skyguard Tabard
32446	Elixir of Shadows
32447	Pattern: Night's End
32449	Essence-Infused Moonstone
32450	Gladiator's Gavel
32451	Gladiator's Salvation
32452	Gladiator's Reprieve
32453	Star's Tears
32454	Arthorn's Research
32455	Star's Lament
32456	Skyguard Bombs
32457	Arakkoa Fetish
32458	Ashes of Al'ar
32459	Time-Phased Phylactery
32461	Furious Gizmatic Goggles
32462	Morthis' Materials
32464	Nethercite Ore
32465	Fortune Coin
32466	Bland Blade
32467	Vim'gol's Grimoire
32468	Netherdust Pollen
32469	Illidari Service Papers
32470	Nethermine Flayer Hide
32471	Shard of Azzinoth
32472	Justicebringer 2000 Specs
32473	Tankatronic Goggles
32474	Surestrike Goggles v2.0
32475	Living Replicator Specs
32476	Gadgetstorm Goggles
32478	Deathblow X11 Goggles
32479	Wonderheal XT40 Shades
32480	Magnified Moon Specs
32481	Charm of Swift Flight
32482	Touch of Victory
32483	The Skull of Gul'dan
32485	Ashtongue Talisman of Valor
32486	Ashtongue Talisman of Equilibrium
32487	Ashtongue Talisman of Swiftness
32488	Ashtongue Talisman of Insight
32489	Ashtongue Talisman of Zeal
32490	Ashtongue Talisman of Acumen
32491	Ashtongue Talisman of Vision
32492	Ashtongue Talisman of Lethality
32493	Ashtongue Talisman of Shadows
32494	Destruction Holo-gogs
32495	Powerheal 4000 Lens
32496	Memento of Tyrande
32497	Stormrage Signet Ring
32498	Fortune Coin
32500	Crystal Spire of Karabor
32501	Shadowmoon Insignia
32502	Fel Gland
32503	Yarzill's Mutton
32505	Madness of the Betrayer
32506	Netherwing Egg
32508	Necklace of the Deep
32509	Netherwing Relic
32510	Softstep Boots of Tracking
32512	Girdle of Lordaeron's Fallen
32513	Wristbands of Divine Influence
32514	Skettis Band
32515	Wristguards of Determination
32516	Wraps of Purification
32517	The Wavemender's Mantle
32518	Veil of Turning Leaves
32519	Belt of Divine Guidance
32520	Manaforged Sphere
32521	Faceplate of the Impenetrable
32522	Demonic Bulwark
32523	Ishaal's Almanac
32524	Shroud of the Highborne
32525	Cowl of the Illidari High Lord
32526	Band of Devastation
32527	Ring of Ancient Knowledge
32528	Blessed Band of Karabor
32529	Heretic's Gauntlets
32531	Gezzarak's Fang
32532	Windrager's Coils
32533	Karrog's Shard
32534	Brooch of the Immortal King
32535	Gift of the Talonpriests
32536	Terokk's Gavel
32537	Terokk's Gavel
32538	Skywitch's Drape
32539	Skyguard's Drape
32540	Terokk's Might
32541	Terokk's Wisdom
32542	Imp in a Ball
32561	Tier 5 Arrow Box
32563	Grilled Picnic Treat
32564	Ishaal's Almanac
32566	Picnic Basket
32567	Aether Ray Eye
32568	Swiftsteel Bracers
32569	Apexis Shard
32570	Swiftsteel Shoulders
32571	Dawnsteel Bracers
32572	Apexis Crystal
32573	Dawnsteel Shoulders
32574	Bindings of Lightning Reflexes
32575	Shoulders of Lightning Reflexes
32576	Depleted Crystal Focus
32577	Living Earth Bindings
32578	Charged Crystal Focus
32579	Living Earth Shoulders
32580	Swiftstrike Bracers
32581	Swiftstrike Shoulders
32582	Bracers of Renewed Life
32583	Shoulderpads of Renewed Life
32584	Swiftheal Wraps
32585	Swiftheal Mantle
32586	Bracers of Nimble Thought
32587	Mantle of Nimble Thought
32588	Banana Charm
32589	Hellfire-Encased Pendant
32590	Nethervoid Cloak
32591	Choker of Serrated Blades
32592	Chestguard of Relentless Storms
32593	Treads of the Den Mother
32595	Ogrela Reagent Dust
32596	Unstable Flask of the Elder
32597	Unstable Flask of the Soldier
32598	Unstable Flask of the Beast
32599	Unstable Flask of the Bandit
32600	Unstable Flask of the Physician
32601	Unstable Flask of the Sorcerer
32602	Crystalforged Darkrune
32606	Girdle of the Lightbearer
32608	Pillager's Gauntlets
32609	Boots of the Divine Light
32616	Egbert's Egg
32617	Sleepy Willy
32619	Preserved Fruit
32620	Time-Lost Scroll
32621	Partially Digested Hand
32622	Elekk Training Collar
32623	Bossi's Spare Parts
32624	Large Iron Metamorphosis Geode
32625	Small Iron Metamorphosis Geode
32626	Large Copper Metamorphosis Geode
32627	Small Copper Metamorphosis Geode
32628	Large Silver Metamorphosis Geode
32629	Large Gold Metamorphosis Geode
32630	Small Gold Metamorphosis Geode
32631	Small Silver Metamorphosis Geode
32634	Unstable Amethyst
32635	Unstable Peridot
32636	Unstable Sapphire
32637	Unstable Citrine
32638	Unstable Topaz
32639	Unstable Talasite
32640	Potent Unstable Diamond
32641	Imbued Unstable Diamond
32642	Raw Darkrune
32643	Darkrune
32645	Crystalline Crossbow
32646	Medallion of Karabor
32647	Shard-bound Bracers
32648	Vortex Walking Boots
32649	Medallion of Karabor
32650	Cerulean Crystal Rod
32651	Crystal Orb of Enlightenment
32652	Ogri'la Aegis
32653	Apexis Cloak
32654	Crystalforged Trinket
32655	Crystalweave Bracers
32656	Crystalhide Handwraps
32657	Arthorn's Sparrowhawk Whistle
32658	Badge of Tenacity
32659	Crystal-Infused Shiv
32660	Crystalforged Sword
32661	Apexis Crystal Mace
32662	Flaming Quartz Staff
32663	Apexis Cleaver
32664	Dreamcrystal Band
32665	Crystalweave Cape
32666	Hardened Hide of Tyrantus
32667	Bash Ale
32668	Dos Ogris
32670	Depleted Two-Handed Axe
32671	Depleted Mace
32672	Depleted Badge
32673	Depleted Dagger
32674	Depleted Sword
32675	Depleted Mail Gauntlets
32676	Depleted Cloth Bracers
32677	Depleted Cloak
32678	Depleted Ring
32679	Depleted Staff
32680	Booterang
32681	Onyx Scale of Rivendark
32682	Obsidia Scale
32683	Jet Scale of Furywing
32684	Insidion's Ebony Scale
32685	Ogri'la Chicken Fingers
32686	Mingo's Fortune Giblets
32687	Hazzik's Package
32688	Bloodstained Fortune
32689	Bloodstained Fortune
32690	Bloodstained Fortune
32691	Bloodstained Fortune
32692	Bloodstained Fortune
32693	Bloodstained Fortune
32694	Overseer's Badge
32695	Captain's Badge
32696	Banishing Crystal
32697	Apexis Guardian's Head
32698	Wrangling Rope
32700	Bloodstained Fortune
32701	Bloodstained Fortune
32702	Bloodstained Fortune
32703	Bloodstained Fortune
32704	Bloodstained Fortune
32705	Bloodstained Fortune
32706	Bloodstained Fortune
32707	Bloodstained Fortune
32708	Bloodstained Fortune
32709	Bloodstained Fortune
32710	Bloodstained Fortune
32711	Bloodstained Fortune
32712	Bloodstained Fortune
32713	Bloodstained Fortune
32714	Splintered Spider Fang
32715	Akkarai's Talons
32716	Gezzarak's Claws
32717	Karrog's Spine
32718	Vakkiz's Scale
32720	Time-Lost Offering
32721	Skyguard Rations
32722	Enriched Terocone Juice
32723	Nethermine Cargo
32724	Sludge-covered Object
32725	Murkblood Miner's Pick
32726	Murkblood Escape Plans
32727	Vial of Tears
32728	Sludge
32732	Dragon Teeth
32733	Fel Whip
32734	Hand of the Overseer
32735	Radiant Spencerite
32736	Plans: Swiftsteel Bracers
32737	Plans: Swiftsteel Shoulders
32738	Plans: Dawnsteel Bracers
32739	Plans: Dawnsteel Shoulders
32741	Shabby Arakkoa Disguise
32742	Adversarial Bloodlines
32744	Pattern: Bracers of Renewed Life
32745	Pattern: Shoulderpads of Renewed Life
32746	Pattern: Swiftstrike Bracers
32747	Pattern: Swiftstrike Shoulders
32748	Pattern: Bindings of Lightning Reflexes
32749	Pattern: Shoulders of Lightning Reflexes
32750	Pattern: Living Earth Bindings
32751	Pattern: Living Earth Shoulders
32752	Pattern: Swiftheal Wraps
32753	Pattern: Swiftheal Mantle
32754	Pattern: Bracers of Nimble Thought
32755	Pattern: Mantle of Nimble Thought
32756	Gyro-Balanced Khorium Destroyer
32757	Blessed Medallion of Karabor
32758	Brute Cologne
32759	Accelerator Module
32760	The Macho Gnome's Arrow
32761	The Sarge's Bullet
32762	Rulkster's Brain Juice
32763	Rulkster's Secret Sauce
32764	Flaskataur's Celestial Brew
32765	Flaskataur's Tears
32766	Flaskataur's Flask of Flaskocity
32767	Flaskataur's Flask of Pretty Good Power
32768	Reins of the Raven Lord
32769	Belt of the Raven Lord
32770	Skyguard Silver Cross
32771	Airman's Ribbon of Gallantry
32772	Brilliant Pearl Band
32773	Bash'ir's Skeleton Key
32774	The Black Pearl
32775	Deepdiving Pearl
32776	Crown of the Sea Witch
32777	Kronk's Grab Bag
32778	Boots of Righteous Fortitude
32779	Band of Frigid Elements
32780	The Boomstick
32781	Talon of Anzu
32782	Time-Lost Figurine
32783	Blue Ogre Brew
32784	Red Ogre Brew
32785	Veteran's Chain Sabatons
32786	Veteran's Dragonhide Boots
32787	Veteran's Dreadweave Stalkers
32788	Veteran's Kodohide Boots
32789	Veteran's Lamellar Greaves
32790	Veteran's Leather Boots
32791	Veteran's Linked Sabatons
32792	Veteran's Mail Sabatons
32793	Veteran's Plate Greaves
32794	Veteran's Scaled Greaves
32795	Veteran's Silk Footguards
32796	Veteran's Wyrmhide Boots
32797	Veteran's Chain Girdle
32798	Veteran's Dragonhide Belt
32799	Veteran's Dreadweave Belt
32800	Veteran's Kodohide Belt
32801	Veteran's Lamellar Belt
32802	Veteran's Leather Belt
32803	Veteran's Linked Girdle
32804	Veteran's Mail Girdle
32805	Veteran's Plate Belt
32806	Veteran's Scaled Belt
32807	Veteran's Silk Belt
32808	Veteran's Wyrmhide Belt
32809	Veteran's Chain Bracers
32810	Veteran's Dragonhide Bracers
32811	Veteran's Dreadweave Cuffs
32812	Veteran's Kodohide Bracers
32813	Veteran's Lamellar Bracers
32814	Veteran's Leather Bracers
32816	Veteran's Linked Bracers
32817	Veteran's Mail Bracers
32818	Veteran's Plate Bracers
32819	Veteran's Scaled Bracers
32820	Veteran's Silk Cuffs
32821	Veteran's Wyrmhide Bracers
32822	Flawless Arcane Essence
32823	Illidari Lord Balthas' Instructions
32824	Tigole's Trashbringer
32825	Soul Cannon
32828	Ogri'la Tabard
32829	Windcharger's Lance
32830	Severin's Cane
32831	Jeweled Rod
32832	Scout's Throwing Knives
32833	Purified Jaggal Pearl
32834	Nether Ray Cage
32835	Ogri'la Care Package
32836	Purified Shadow Pearl
32837	Warglaive of Azzinoth
32838	Warglaive of Azzinoth
32839	Cauldron of Major Arcane Protection
32840	Major Arcane Protection Potion
32842	Dragonmaw Flare Gun
32843	Scryer Medals
32844	Major Nature Protection Potion
32845	Major Shadow Protection Potion
32846	Major Fire Protection Potion
32847	Major Frost Protection Potion
32848	Explosives Package
32849	Cauldron of Major Fire Protection
32850	Cauldron of Major Frost Protection
32851	Cauldron of Major Nature Protection
32852	Cauldron of Major Shadow Protection
32853	Aldor Medals
32854	Hammer of Righteous Might
32857	Reins of the Onyx Netherwing Drake
32858	Reins of the Azure Netherwing Drake
32859	Reins of the Cobalt Netherwing Drake
32860	Reins of the Purple Netherwing Drake
32861	Reins of the Veridian Netherwing Drake
32862	Reins of the Violet Netherwing Drake
32863	Skybreaker Whip
32864	Commander's Badge
32865	Drake Tamer's Gloves
32866	Ascendant's Boots
32867	Dragonmaw Augur's Cinch
32868	Skybreaker's Mantle
32869	Illidari Lord's Tunic
32870	Legguards of Contemplation
32871	Horns of the Illidari
32872	Illidari Rod of Discipline
32882	Hellfire Shot
32883	Felbane Slugs
32888	The Relics of Terokk
32895	Scroll of the Maelstrom
32896	Scroll of the Sun
32897	Mark of the Illidari
32898	Shattrath Flask of Fortification
32899	Shattrath Flask of Mighty Restoration
32900	Shattrath Flask of Supreme Power
32901	Shattrath Flask of Relentless Assault
32902	Bottled Nethergon Energy
32903	Cenarion Mana Salve
32904	Cenarion Healing Salve
32905	Bottled Nethergon Vapor
32906	Stunned Wolpertinger
32907	Wolpertinger Net
32908	Tempest Keep Armaments
32909	Blue Ogre Brew Special
32910	Red Ogre Brew Special
32912	Yellow Brewfest Stein
32914	Bland Shiv
32915	Filled Yellow Brewfest Stein
32916	Grimbooze's Research Notes
32917	Filled Yellow Brewfest Stein
32918	Filled Yellow Brewfest Stein
32919	Filled Yellow Brewfest Stein
32920	Filled Yellow Brewfest Stein
32921	Brewfest Mug 2007 (Filled, F)
32941	Corruptor's Signet
32942	Ring of the Overseer
32943	Swiftsteel Bludgeon
32944	Talon of the Phoenix
32945	Fist of Molten Fury
32946	Claw of Molten Fury
32947	Auchenai Healing Potion
32948	Auchenai Mana Potion
32949	Unusually Slow Sword
32950	Unusually Slow Mace
32951	Unusually Slow Two-Hander
32952	QAEnchant Weapon Spellsurge
32954	Tom's Boots 1
32955	Tom's Boots 2
32956	Tom's Boots 3
32957	Tom's Bracer 1
32958	Tom's Bracer 2
32959	Tom's Bracer 3
32960	Elekk Dispersion Ray
32961	Merciless Gladiator's Reprieve
32962	Merciless Gladiator's Touch of Defeat
32963	Merciless Gladiator's Gavel
32964	Merciless Gladiator's Salvation
32965	DEBUG - Headless Horseman - Create Fire Node
32966	DEBUG - Headless Horseman - Start Fire
32967	DEBUG - Headless Horseman - Extinguish Fire
32971	Water Bucket
32973	General's Mooncloth Cuffs
32974	General's Mooncloth Belt
32975	General's Mooncloth Slippers
32976	Marshal's Mooncloth Belt
32977	Marshal's Mooncloth Cuffs
32978	Marshal's Mooncloth Slippers
32979	Veteran's Mooncloth Belt
32980	Veteran's Mooncloth Cuffs
32981	Veteran's Mooncloth Slippers
32982	General's Ornamented Belt
32983	General's Ornamented Bracers
32984	General's Ornamented Greaves
32985	Marshal's Ornamented Belt
32986	Marshal's Ornamented Bracers
32987	Marshal's Ornamented Greaves
32988	Veteran's Ornamented Belt
32989	Veteran's Ornamented Bracers
32990	Veteran's Ornamented Greaves
32991	General's Ringmail Bracers
32992	General's Ringmail Girdle
32993	General's Ringmail Sabatons
32994	Marshal's Ringmail Bracers
32995	Marshal's Ringmail Girdle
32996	Marshal's Ringmail Sabatons
32997	Veteran's Ringmail Bracers
32998	Veteran's Ringmail Girdle
32999	Veteran's Ringmail Sabatons
33001	Reflective Dust
33004	Clamlette Magnifique
33006	Vengeful Gladiator's Heavy Crossbow
33007	Grimbooze's Secret Recipe
33008	Deserter Propaganda
33009	Tender Strider Meat
33010	Griftah's Note
33012	Terokkar Lilac
33013	Budd's Map of Zul'Aman
33014	Fine Poking Stick
33015	Altered Leaflets
33016	Blue Brewfest Stein
33017	Filled Blue Brewfest Stein
33018	Filled Blue Brewfest Stein
33019	Filled Blue Brewfest Stein
33020	Filled Blue Brewfest Stein
33021	Filled Blue Brewfest Stein
33022	Brewfest Mug 2008 (Filled, F)
33023	Savory Sausage
33024	Pickled Sausage
33025	Spicy Smoked Sausage
33026	The Golden Link
33028	Barleybrew Light
33029	Barleybrew Dark
33030	Barleybrew Clear
33031	Thunder 45
33032	Thunderbrew Ale
33033	Thunderbrew Stout
33034	Gordok Grog
33035	Ogre Mead
33036	Mudder's Milk
33037	Defias Orders
33038	Damaged Diving Gear
33039	Tool Kit
33040	Repaired Diving Gear
33041	Salvaged Strongbox
33042	Black Coffee
33043	The Essential Brewfest Pretzel
33044	Salvage Kit
33045	Renn's Supplies
33046	Insignia of PvP Pwn
33047	Belbi's Eyesight Enhancing Romance Goggles
33048	Stewed Trout
33050	Grimtotem Note
33051	Grimtotem Battle Plan
33052	Fisherman's Feast
33053	Hot Buttered Trout
33054	The Seal of Danzalar
33055	Band of Vile Aggression
33056	Veteran's Band of Dominance
33057	Veteran's Band of Triumph
33058	Band of the Vigilant
33061	Grimtotem Key
33064	Veteran's Band of Salvation
33065	Veteran's Pendant of Dominance
33066	Veteran's Pendant of Triumph
33067	Veteran's Pendant of Conquest
33068	Veteran's Pendant of Salvation
33069	Sturdy Rope
33070	Raptor Bait
33071	Blackhoof Armaments
33072	Tabetha's Torch
33073	Test_Ears_Hidden(builtByBlue)
33074	Test_Eyes_Hidden(builtByBlue)
33075	Test_NoseAndEars_Hidden(builtByBlue)
33076	Merciless Gladiator's Idol of Tenacity
33077	Merciless Gladiator's Libram of Justice
33078	Merciless Gladiator's Totem of the Third Wind
33079	Murloc Costume
33081	Voodoo Skull
33082	Wreath
33083	Orcish Grog
33085	Bloodfen Feather
33086	Stonemaul Banner
33087	Black Dragonkin Essence
33088	Brogg's Totem
33091	Energized Totem
33092	Healing Potion Injector
33093	Mana Potion Injector
33095	Stonemaul Banner
33096	Complimentary Brewfest Sampler
33097	Mushroom Ring
33101	Captured Totem
33102	Blood of Zul'jin
33103	Marsh Venom
33104	Ring of Skill
33105	Budd's Guise of Zul'aman
33106	Forest Troll Tusk
33107	Tattered Voodoo Doll
33108	Ooze Buster
33110	Razorspine's Sword
33112	Witchbane
33113	Witchbane Torch
33114	Sealed Letter
33115	Sealed Letter
33117	Jack-o'-Lantern
33122	Cloak of Darkness
33124	Pattern: Cloak of Darkness
33126	Thresher Oil
33127	Dastardly Denizens of the Deep
33131	Crimson Sun
33132	Delicate Fire Ruby
33133	Don Julio's Heart
33134	Kailee's Rose
33135	Falling Star
33137	Sparkling Falling Star
33138	Mystic Bladestone
33139	Brilliant Bladestone
33140	Blood of Amber
33141	Great Bladestone
33142	Rigid Bladestone
33143	Stone of Blades
33144	Facet of Eternity
33148	Formula: Enchant Cloak - Dodge
33149	Formula: Enchant Cloak - Stealth
33150	Formula: Enchant Cloak - Subtlety
33151	Formula: Enchant Cloak - Subtlety
33152	Formula: Enchant Gloves - Superior Agility
33153	Formula: Enchant Gloves - Threat
33154	Sinister Squashling
33155	Design: Kailee's Rose
33156	Design: Crimson Sun
33157	Design: Falling Star
33158	Design: Stone of Blades
33159	Design: Blood of Amber
33160	Design: Facet of Eternity
33163	Zeppelin Cargo
33165	Formula: Enchant Weapon - Greater Agility
33166	Pagle's Fish Paste, Extra Strength
33173	Ragesteel Shoulders
33174	Plans: Ragesteel Shoulders
33175	Wyrmtail
33176	Flying Broom
33182	Swift Flying Broom
33184	Swift Magic Broom
33185	Adamantite Weapon Chain
33186	Plans: Adamantite Weapon Chain
33189	Rickety Magic Broom
33191	Jungle Stompers
33192	Carved Witch Doctor's Stick
33193	Mossy Band
33194	Ancient Ceremonial Band
33195	Cracked Stone Band
33196	Softly-Glowing Ring
33197	Mossy Necklace
33198	Necklace of Decay
33200	Ancient Ceremonial Necklace
33201	Silver Moonstone Pendant
33202	Marsh Frog Leg
33203	Robes of Heavenly Purpose
33204	Shadowprowler's Chestguard
33205	Pattern: Shadowprowler's Chestguard
33206	Pauldrons of Primal Fury
33207	Implacable Guardian Sabatons
33208	Flask of Chromatic Wonder
33209	Recipe: Flask of Chromatic Wonder
33211	Bladeangel's Money Belt
33214	Akil'zon's Talonblade
33215	Bloodstained Elven Battlevest
33216	Chestguard of Hidden Purpose
33217	Unstacked Tricky Treat
33218	Goblin Gumbeaux
33219	Goblin Gumbo Kettle
33222	Nyn'jah's Tabi Boots
33223	Fishing Chair
33224	Reins of the Spectral Tiger
33225	Reins of the Swift Spectral Tiger
33226	Tricky Treat
33228	Crimson Tunic
33229	Mordant's Travel Tunic
33230	Leggings of the Long Road
33231	Oversized Stonemaul Hood
33232	Journeyman's Cowl
33233	Cobalt-threaded Gloves
33234	Iced Berry Slush
33235	Journeyman's Epaulets
33236	Fizzy Faire Drink "Classic"
33237	Brogg's Battle Harness
33239	Marshwarden's Tunic
33240	Grimtotem Earthbinder's Tunic
33241	Oiled Leather Leggings
33242	Raptorhide Legguards
33243	Skirmisher's Cover
33244	The Wanderer's Cover
33245	Grimsby's Gaudy Girdle
33246	Funnel Cake
33247	Swift Wind Spaulders
33248	Crested Shoulderpads
33249	Boots of the Skirmisher
33250	Archer's Wristguard
33251	Steel-banded Hauberk
33252	Gleaming Scale Breastplate
33253	Golden Helm
33254	Afrazi Forest Strider Drumstick
33255	Rustproof Waistguard
33256	Refitted Bruiser Gauntlets
33257	Scaled Marshwalkers
33258	Protective Engineer's Leggings
33259	Crimson Barbut
33260	Spellbound Cloak
33261	Destroyer's Cloak
33262	Morlann's Seal
33263	Raptor Eye Ring
33264	Glowing Tourmaline Ring
33265	Pendant of Ferocity
33266	Book of the Adept
33267	Fleshripper
33268	Bone Dirk
33269	Bejeweled Dagger
33270	Mariner's Sword
33271	Battlecaster's Edge
33272	Biting Axe
33273	Seasoned Marshwood Bow
33274	Mercenary's Crossbow
33277	Tome of Thomas Thomson
33279	Iron-tusk Girdle
33280	War-Feathered Loop
33281	Brooch of Nature's Mercy
33283	Amani Punisher
33285	Fury of the Ursine
33286	Mojo-mender's Mask
33287	Gnarled Ironwood Pauldrons
33288	Complimentary Brewfest Sampler DEBUG
33291	Voodoo-woven Belt
33292	Hallowed Helm
33293	Signet of Ancient Magics
33296	Brooch of Deftness
33297	The Savage's Choker
33298	Prowler's Strikeblade
33299	Spaulders of the Advocate
33300	Shoulderpads of Dancing Blades
33303	Skullshatter Warboots
33304	Cloak of Subjugated Power
33305	Design: Don Julio's Heart
33306	Ram Racing Reins
33307	Formula: Enchant Weapon - Executioner
33309	Merciless Gladiator's Redoubt
33313	Merciless Gladiator's Barrier
33315	QAEnchant Weapon Executioner
33317	Robe of Departed Spirits
33322	Shimmer-pelt Vest
33324	Treads of the Life Path
33325	Voodoo Shaker
33326	Bulwark of the Amani Empire
33327	Mask of Introspection
33328	Arrow-fall Chestguard
33329	Shadowtooth Trollskin Cuirass
33331	Chain of Unleashed Rage
33332	Enamelled Disc of Mojo
33333	Kharmaa's Shroud of Hope
33334	Fetish of the Primal Gods
33354	Wub's Cursed Hexblade
33356	Helm of Natural Regeneration
33357	Footpads of Madness
33386	Man'kin'do's Belt
33388	Heartless
33389	Dagger of Bad Mojo
33421	Battleworn Tuskguard
33432	Coif of the Jungle Stalker
33442	Target Rifle
33446	Girdle of Stromgarde's Hope
33453	Hood of Hexing
33455	Brewfest Prize Ticket
33463	Hood of the Third Eye
33464	Hex Lord's Voodoo Pauldrons
33465	Staff of Primal Fury
33466	Loop of Cursed Bones
33467	Blade of Twisted Visions
33468	Dark Blessing
33469	Hauberk of the Empire's Champion
33471	Two-toed Sandals
33473	Chestguard of the Warlord
33474	Ancient Amani Longbow
33476	Cleaver of the Unforgiving
33478	Jin'rohk, The Great Apocalypse
33479	Grimgrin Faceguard
33480	Cord of Braided Troll Hair
33481	Pauldrons of Stone Resolve
33482	Cobra-Lash Boots
33483	Life-step Belt
33484	Dory's Embrace
33489	Mantle of Ill Intent
33490	Staff of Dark Mending
33491	Tuskbreaker
33492	Trollbane
33493	Umbral Shiv
33494	Amani Divining Staff
33495	Rage
33496	Signet of Primal Wrath
33497	Mana Attuned Band
33498	Signet of the Quiet Forest
33499	Signet of the Last Defender
33500	Signet of Eternal Life
33501	Bloodthirster's Wargreaves
33502	Libram of Mending
33503	Libram of Divine Judgement
33504	Libram of Divine Purpose
33505	Totem of Living Water
33506	Skycall Totem
33507	Stonebreaker's Totem
33508	Idol of Budding Life
33509	Idol of Terror
33510	Idol of the Unseen Moon
33512	Furious Deathgrips
33513	Eternium Rage-shackles
33514	Pauldrons of Gruesome Fate
33515	Unwavering Legguards
33516	Bracers of the Ancient Phalanx
33517	Bonefist Gauntlets
33518	High Justicar's Legplates
33519	Handguards of the Templar
33520	Vambraces of the Naaru
33522	Chestguard of the Stoic Guardian
33523	Sabatons of the Righteous Defender
33524	Girdle of the Protector
33527	Shifting Camouflage Pants
33528	Gauntlets of Sniping
33529	Steadying Bracers
33530	Natural Life Leggings
33531	Polished Waterscale Gloves
33532	Gleaming Earthen Bracers
33533	Avalanche Leggings
33534	Grips of Nature's Wrath
33535	Earthquake Bracers
33536	Stormwrap
33537	Treads of Booming Thunder
33538	Shallow-grave Trousers
33539	Trickster's Stickyfingers
33540	Master Assassin Wristwraps
33542	Shaman Testing Axe
33543	Shaman Testing Dagger
33552	Pants of Splendid Recovery
33557	Gargon's Bracers of Peaceful Slumber
33559	Starfire Waistband
33566	Blessed Elunite Coverings
33570	TEMP - Dwarf Loot 1
33572	TEMP - Dwarf Loot 2
33573	TEMP - Dwarf Loot 3
33574	TEMP - Dwarf Loot 4
33577	Moon-walkers
33578	Armwraps of the Kaldorei Protector
33579	Vestments of Hibernation
33580	Band of the Swift Paw
33582	Footwraps of Wild Encroachment
33583	Waistguard of the Great Beast
33584	Pantaloons of Arcane Annihilation
33585	Achromic Trousers of the Naaru
33586	Studious Wraps
33587	Light-Blessed Bonds
33588	Runed Spell-cuffs
33589	Wristguards of Tranquil Thought
33590	Cloak of Fiends
33591	Shadowcaster's Drape
33592	Cloak of Ancient Rituals
33593	Slikk's Cloak of Placation
33600	TEMP - Troll Loot 1
33601	TEMP - Troll Loot 3
33602	TEMP - Troll Loot 2
33603	TEMP - Troll Loot 4
33622	Design: Relentless Earthstorm Diamond
33623	TEMP - Orc Loot 1
33624	TEMP - Orc Loot 2
33625	TEMP - Orc Loot 3
33626	TEMP - Orc Loot 4
33633	Forceful Earthstorm Diamond
33640	Fury
33661	Vengeful Gladiator's Barrier
33662	Vengeful Gladiator's Bonecracker
33663	Vengeful Gladiator's Bonegrinder
33664	Vengeful Gladiator's Chain Armor
33665	Vengeful Gladiator's Chain Gauntlets
33666	Vengeful Gladiator's Chain Helm
33667	Vengeful Gladiator's Chain Leggings
33668	Vengeful Gladiator's Chain Spaulders
33669	Vengeful Gladiator's Cleaver
33670	Vengeful Gladiator's Decapitator
33671	Vengeful Gladiator's Dragonhide Gloves
33672	Vengeful Gladiator's Dragonhide Helm
33673	Vengeful Gladiator's Dragonhide Legguards
33674	Vengeful Gladiator's Dragonhide Spaulders
33675	Vengeful Gladiator's Dragonhide Tunic
33676	Vengeful Gladiator's Dreadweave Gloves
33677	Vengeful Gladiator's Dreadweave Hood
33678	Vengeful Gladiator's Dreadweave Leggings
33679	Vengeful Gladiator's Dreadweave Mantle
33680	Vengeful Gladiator's Dreadweave Robe
33681	Vengeful Gladiator's Endgame
33682	Vengeful Gladiator's Felweave Amice
33683	Vengeful Gladiator's Felweave Cowl
33684	Vengeful Gladiator's Felweave Handguards
33685	Vengeful Gladiator's Felweave Raiment
33686	Vengeful Gladiator's Felweave Trousers
33687	Vengeful Gladiator's Gavel
33688	Vengeful Gladiator's Greatsword
33689	Vengeful Gladiator's Hacker
33690	Vengeful Gladiator's Kodohide Gloves
33691	Vengeful Gladiator's Kodohide Helm
33692	Vengeful Gladiator's Kodohide Legguards
33693	Vengeful Gladiator's Kodohide Spaulders
33694	Vengeful Gladiator's Kodohide Tunic
33695	Vengeful Gladiator's Lamellar Chestpiece
33696	Vengeful Gladiator's Lamellar Gauntlets
33697	Vengeful Gladiator's Lamellar Helm
33698	Vengeful Gladiator's Lamellar Legguards
33699	Vengeful Gladiator's Lamellar Shoulders
33700	Vengeful Gladiator's Leather Gloves
33701	Vengeful Gladiator's Leather Helm
33702	Vengeful Gladiator's Leather Legguards
33703	Vengeful Gladiator's Leather Spaulders
33704	Vengeful Gladiator's Leather Tunic
33705	Vengeful Gladiator's Left Ripper
33706	Vengeful Gladiator's Linked Armor
33707	Vengeful Gladiator's Linked Gauntlets
33708	Vengeful Gladiator's Linked Helm
33709	Vengeful Gladiator's Linked Leggings
33710	Vengeful Gladiator's Linked Spaulders
33711	Vengeful Gladiator's Mail Armor
33712	Vengeful Gladiator's Mail Gauntlets
33713	Vengeful Gladiator's Mail Helm
33714	Vengeful Gladiator's Mail Leggings
33715	Vengeful Gladiator's Mail Spaulders
33716	Vengeful Gladiator's Staff
33717	Vengeful Gladiator's Mooncloth Gloves
33718	Vengeful Gladiator's Mooncloth Hood
33719	Vengeful Gladiator's Mooncloth Leggings
33720	Vengeful Gladiator's Mooncloth Mantle
33721	Vengeful Gladiator's Mooncloth Robe
33722	Vengeful Gladiator's Ornamented Chestguard
33723	Vengeful Gladiator's Ornamented Gloves
33724	Vengeful Gladiator's Ornamented Headcover
33725	Vengeful Gladiator's Ornamented Legplates
33726	Vengeful Gladiator's Ornamented Spaulders
33727	Vengeful Gladiator's Painsaw
33728	Vengeful Gladiator's Plate Chestpiece
33729	Vengeful Gladiator's Plate Gauntlets
33730	Vengeful Gladiator's Plate Helm
33731	Vengeful Gladiator's Plate Legguards
33732	Vengeful Gladiator's Plate Shoulders
33733	Vengeful Gladiator's Pummeler
33734	Vengeful Gladiator's Quickblade
33735	Vengeful Gladiator's Redoubt
33736	Vengeful Gladiator's Reprieve
33737	Vengeful Gladiator's Right Ripper
33738	Vengeful Gladiator's Ringmail Armor
33739	Vengeful Gladiator's Ringmail Gauntlets
33740	Vengeful Gladiator's Ringmail Helm
33741	Vengeful Gladiator's Ringmail Leggings
33742	Vengeful Gladiator's Ringmail Spaulders
33743	Vengeful Gladiator's Salvation
33744	Vengeful Gladiator's Satin Gloves
33745	Vengeful Gladiator's Satin Hood
33746	Vengeful Gladiator's Satin Leggings
33747	Vengeful Gladiator's Satin Mantle
33748	Vengeful Gladiator's Satin Robe
33749	Vengeful Gladiator's Scaled Chestpiece
33750	Vengeful Gladiator's Scaled Gauntlets
33751	Vengeful Gladiator's Scaled Helm
33752	Vengeful Gladiator's Scaled Legguards
33753	Vengeful Gladiator's Scaled Shoulders
33754	Vengeful Gladiator's Shanker
33755	Vengeful Gladiator's Shield Wall
33756	Vengeful Gladiator's Shiv
33757	Vengeful Gladiator's Silk Amice
33758	Vengeful Gladiator's Silk Cowl
33759	Vengeful Gladiator's Silk Handguards
33760	Vengeful Gladiator's Silk Raiment
33761	Vengeful Gladiator's Silk Trousers
33762	Vengeful Gladiator's Slicer
33763	Vengeful Gladiator's Spellblade
33764	Vengeful Gladiator's Touch of Defeat
33765	Vengeful Gladiator's War Edge
33766	Vengeful Gladiator's War Staff
33767	Vengeful Gladiator's Wyrmhide Gloves
33768	Vengeful Gladiator's Wyrmhide Helm
33769	Vengeful Gladiator's Wyrmhide Legguards
33770	Vengeful Gladiator's Wyrmhide Spaulders
33771	Vengeful Gladiator's Wyrmhide Tunic
33772	Testing Gladiator's Lamellar Shoulders
33782	Steady Talasite
33783	Design: Steady Talasite
33784	Darkrune Fragment
33785	TEMP - Gnome Loot 1
33786	TEMP - Gnome Loot 2
33787	TEMP - Gnome Loot 3
33788	TEMP - Gnome Loot 4
33791	Heavy Copper Longsword
33792	Plans: Heavy Copper Longsword
33797	Portable Brewfest Keg
33801	Vengeful Gladiator's Mutilator
33803	Adamantite Stinger
33804	Schematic: Adamantite Arrow Maker
33805	Shadowhunter's Treads
33807	Vazruden's Horn
33808	The Horseman's Helm
33809	Amani War Bear
33810	Amani Mask of Death
33811	Vindicator's Plate Belt
33812	Vindicator's Plate Greaves
33813	Vindicator's Plate Bracers
33814	Keli'dan's Feathered Stave
33815	Bladefist's Seal
33816	Toothy's Bucket
33818	Muckbreath's Bucket
33820	Weather-Beaten Fishing Hat
33821	The Heart of Quagmirran
33823	Bloodfin Catfish
33824	Crescent-Tail Skullfish
33825	Skullfish Soup
33826	Black Stalker Egg
33827	The Warlord's Treatise
33828	Tome of Diabolic Remedy
33829	Hex Shrunken Head
33830	Ancient Aqir Artifact
33831	Berserker's Call
33832	Battlemaster's Determination
33833	Nazan's Riding Crop
33834	The Headfeathers of Ikiss
33835	Shaffar's Wondrous Amulet
33836	The Exarch's Soul Gem
33837	Cooking Pot
33838	Giant Kaliri Wing
33839	Kaliri Stew
33840	Murmur's Whisper
33841	Vengeful Gladiator's Idol of Tenacity
33842	Vengeful Gladiator's Libram of Justice
33843	Vengeful Gladiator's Totem of the Third Wind
33844	Barrel of Fish
33846	Ruined Fishing Net
33847	Epoch Hunter's Head
33848	Demon Broiled Surprise
33849	Mana Berry
33850	Spiritual Soup
33851	Cooking Pot
33852	Cooking Pot
33853	Vindicator's Band of Dominance
33854	Unidentified Eye
33855	Tarnished Silver Ring
33856	List of Goods
33857	Crate of Meat
33858	Aeonus's Hourglass
33859	Warp Splinter Clipping
33860	Pathaleon's Projector
33861	The Scroll of Skyriss
33862	Brewfest Regalia
33863	Brewfest Dress
33864	Brown Brewfest Hat
33865	Amani Hex Stick
33866	Stormchops
33867	Broiled Bloodfin
33868	Brewfest Boots
33869	Recipe: Broiled Bloodfin
33870	Recipe: Skullfish Soup
33871	Recipe: Stormchops
33872	Spicy Hot Talbuk
33873	Recipe: Spicy Hot Talbuk
33874	Kibler's Bits
33875	Recipe: Kibler's Bits
33876	Vindicator's Chain Bracers
33877	Vindicator's Chain Girdle
33878	Vindicator's Chain Sabatons
33879	Vindicator's Dragonhide Belt
33880	Vindicator's Dragonhide Boots
33881	Vindicator's Dragonhide Bracers
33882	Vindicator's Dreadweave Belt
33883	Vindicator's Dreadweave Cuffs
33884	Vindicator's Dreadweave Stalkers
33885	Vindicator's Kodohide Belt
33886	Vindicator's Kodohide Boots
33887	Vindicator's Kodohide Bracers
33888	Vindicator's Lamellar Belt
33889	Vindicator's Lamellar Bracers
33890	Vindicator's Lamellar Greaves
33891	Vindicator's Leather Belt
33892	Vindicator's Leather Boots
33893	Vindicator's Leather Bracers
33894	Vindicator's Linked Bracers
33895	Vindicator's Linked Girdle
33896	Vindicator's Linked Sabatons
33897	Vindicator's Mail Bracers
33898	Vindicator's Mail Girdle
33899	Vindicator's Mail Sabatons
33900	Vindicator's Mooncloth Belt
33901	Vindicator's Mooncloth Cuffs
33902	Vindicator's Mooncloth Slippers
33903	Vindicator's Ornamented Belt
33904	Vindicator's Ornamented Bracers
33905	Vindicator's Ornamented Greaves
33906	Vindicator's Ringmail Bracers
33907	Vindicator's Ringmail Girdle
33908	Vindicator's Ringmail Sabatons
33909	Vindicator's Scaled Belt
33910	Vindicator's Scaled Bracers
33911	Vindicator's Scaled Greaves
33912	Vindicator's Silk Belt
33913	Vindicator's Silk Cuffs
33914	Vindicator's Silk Footguards
33915	Vindicator's Wyrmhide Belt
33916	Vindicator's Wyrmhide Boots
33917	Vindicator's Wyrmhide Bracers
33918	Vindicator's Band of Salvation
33919	Vindicator's Band of Triumph
33920	Vindicator's Pendant of Conquest
33921	Vindicator's Pendant of Dominance
33922	Vindicator's Pendant of Salvation
33923	Vindicator's Pendant of Triumph
33924	Delicious Chocolate Cake
33925	Recipe: Delicious Chocolate Cake
33926	Sealed Scroll Case
33927	Brewfest Pony Keg
33928	Hollowed Bone Decanter
33929	Brewfest Brew
33930	Amani Charm of the Bloodletter
33931	Amani Charm of Mighty Mojo
33932	Amani Charm of the Witch Doctor
33933	Amani Charm of the Raging Defender
33934	Crystal Healing Potion
33935	Crystal Mana Potion
33936	Gladiator's Libram of Fortitude
33937	Merciless Gladiator's Libram of Fortitude
33938	Vengeful Gladiator's Libram of Fortitude
33939	Gladiator's Totem of Indomitability
33940	Merciless Gladiator's Totem of Indomitability
33941	Vengeful Gladiator's Totem of Indomitability
33942	Gladiator's Idol of Steadfastness
33943	Merciless Gladiator's Idol of Steadfastness
33944	Vengeful Gladiator's Idol of Steadfastness
33945	Gladiator's Idol of Resolve
33946	Merciless Gladiator's Idol of Resolve
33947	Vengeful Gladiator's Idol of Resolve
33948	Gladiator's Libram of Vengeance
33949	Merciless Gladiator's Libram of Vengeance
33950	Vengeful Gladiator's Libram of Vengeance
33951	Gladiator's Totem of Survival
33952	Merciless Gladiator's Totem of Survival
33953	Vengeful Gladiator's Totem of Survival
33954	Plans: Hammer of Righteous Might
33955	Brewfest Stein Voucher
33956	Harkor's Home Brew
33957	Witches Band
33958	The Horseman's Signet Ring
33959	Ring of Ghoulish Delight
33964	Helm of the Stormcaller
33965	Hauberk of the Furious Elements
33966	Brewfest Slippers
33967	Green Brewfest Hat
33968	Blue Brewfest Hat
33969	Purple Brewfest Hat
33970	Pauldrons of the Furious Elements
33971	Elunite Imbued Leggings
33972	Mask of Primal Power
33973	Pauldrons of Tribal Fury
33974	Grasp of the Moonkin
33976	Brewfest Ram
33977	Swift Brewfest Ram
33978	"Honorary Brewer" Hand Stamp
33985	Dreary Candle
33986	Indalamar's Ring of 200 Crit
33987	Indalamar's Ring of 200 Spell Crit
33988	Indalamar's Ring of 200 Haste
33989	Indalamar's Ring of 200 Spell Haste
33993	Mojo
33995	Indalamar's Ring of Healer Ownage
33996	Indalamar's Ring of 234 Spell Damage
33997	Indalamar's Ring of 400 Attack Power
33998	Indalamar's Ring of 1400 Armor Penetration
33999	Cenarion War Hippogryph
34000	Flimsy Female Blood Elf Mask
34001	Flimsy Female Draenei Mask
34002	Flimsy Male Blood Elf Mask
34003	Flimsy Male Draenei Mask
34008	Blix's Eyesight Enhancing Romance Goggles
34009	Hammer of Judgement
34010	Pepe's Shroud of Pacification
34011	Illidari Runeshield
34012	Shroud of the Final Stand
34014	Vengeful Gladiator's Waraxe
34015	Vengeful Gladiator's Chopper
34016	Vengeful Gladiator's Left Render
34017	Small Step Brew
34018	Long Stride Brew
34019	Path of Brew
34020	Jungle River Water
34021	Brewdoo Magic
34022	Stout Shrunken Head
34028	"Honorary Brewer" Hand Stamp
34029	Tiny Voodoo Mask
34033	Vengeful Gladiator's Grimoire
34039	Bow of Unusual Slowness
34044	B-Ball
34046	Skill: Catch
34047	Skill: Sprint
34048	Skill: Tackle
34049	Battlemaster's Audacity
34050	Battlemaster's Perseverance
34059	Vengeful Gladiator's Baton of Light
34060	Flying Machine Control
34061	Turbo-Charged Flying Machine Control
34062	Conjured Manna Biscuit
34063	Dried Sausage
34064	Succulent Sausage
34065	Spiced Onion Cheese
34066	Vengeful Gladiator's Piercing Touch
34067	Tattered Hexcloth Sack
34068	Weighted Jack-o'-Lantern
34071	Bunch of Jack-o'-Lanterns
34073	The Horseman's Signet Ring
34074	Witches Band
34075	Ring of Ghoulish Delight
34077	Smashed Pumpkin Loot
34085	Red Winter Clothes
34086	Winter Boots
34087	Green Winter Clothes
34089	Alicia's Poem
34092	Merciless Nether Drake
34094	Indalamar's Ring of 200 Attack Power
34095	Indalamar's Ring of 200 Hit Rating
34099	Knothide Ammo Pouch
34100	Knothide Quiver
34105	Quiver of a Thousand Feathers
34106	Netherscale Ammo Pouch
34107	Tattered Shoulderpads
34109	Weather-Beaten Journal
34113	Field Repair Bot 110G
34114	Schematic: Field Repair Bot 110G
34129	Swift Warstrider
34130	Recovery Diver's Potion
34140	Dark Iron Tankard
34141	Dark Iron Ale Keg
34151	Player, Draenei/Tauren
34152	Player, Dwarf/Orc
34153	Player, Gnome/Blood Elf
34154	Player, Human/Undead
34155	Player, Troll/Night Elf
34156	BLB - Kit
34157	Head of Kael'thas
34158	Team A Tabard
34159	Team B Tabard
34160	The Signet Ring of Prince Kael'thas
34161	Kael's Standard
34162	Battlemaster's Depravity
34163	Battlemaster's Cruelty
34164	Dragonscale-Encrusted Longblade
34165	Fang of Kalecgos
34166	Band of Lucent Beams
34167	Legplates of the Holy Juggernaut
34168	Starstalker Legguards
34169	Breeches of Natural Aggression
34170	Pantaloons of Calming Strife
34171	Winter Stationery
34172	Pattern: Drums of Speed
34173	Pattern: Drums of Speed
34174	Pattern: Drums of Restoration
34175	Pattern: Drums of Restoration
34176	Reign of Misery
34177	Clutch of Demise
34178	Collar of the Pit Lord
34179	Heart of the Pit
34180	Felfury Legplates
34181	Leggings of Calamity
34182	Grand Magister's Staff of Torrents
34183	Shivering Felspine
34184	Brooch of the Highborne
34185	Sword Breaker's Bulwark
34186	Chain Links of the Tumultuous Storm
34188	Leggings of the Immortal Night
34189	Band of Ruinous Delight
34190	Crimson Paragon's Cover
34191	Handful of Snowflakes
34192	Pauldrons of Perseverance
34193	Spaulders of the Thalassian Savior
34194	Mantle of the Golden Forest
34195	Shoulderpads of Vehemence
34196	Golden Bow of Quel'Thalas
34197	Shiv of Exsanguination
34198	Stanchion of Primal Instinct
34199	Archon's Gavel
34200	Pattern: Quiver of a Thousand Feathers
34201	Pattern: Netherscale Ammo Pouch
34202	Shawl of Wonderment
34203	Grip of Mannoroth
34204	Amulet of Unfettered Magics
34205	Shroud of Redeemed Souls
34206	Book of Highborne Hymns
34207	Glove Reinforcements
34208	Equilibrium Epaulets
34209	Spaulders of Reclamation
34210	Amice of the Convoker
34211	Harness of Carnal Instinct
34212	Sunglow Vest
34213	Ring of Hardened Resolve
34214	Muramasa
34215	Warharness of Reckless Fury
34216	Heroic Judicator's Chestguard
34218	Pattern: Netherscale Ammo Pouch
34220	Chaotic Skyfire Diamond
34221	Design: Chaotic Skyfire Diamond
34227	Deadman's Hand
34228	Vicious Hawkstrider Hauberk
34229	Garments of Serene Shores
34230	Ring of Omnipotence
34231	Aegis of Angelic Fortune
34232	Fel Conquerer Raiments
34233	Robes of Faltered Light
34234	Shadowed Gauntlets of Paroxysm
34240	Gauntlets of the Soothed Soul
34241	Cloak of Unforgivable Sin
34242	Tattered Cape of Antonidas
34243	Helm of Burning Righteousness
34244	Duplicitous Guise
34245	Cover of Ursol the Wise
34246	Smuggled Mana Cell
34247	Apolyon, the Soul-Render
34248	Bash'ir Phasing Device
34249	Hula Girl Doll
34250	Skill: Throw Bullet
34251	Skill: Throw
34252	Skill: Juke
34253	Sizzling Embers
34254	Razorthorn Root
34255	Razorthorn Flayer Gland
34256	Charmed Amani Jewel
34257	Fel Siphon
34258	Love Rocket
34259	Demonic Blood
34261	Pattern: Green Winter Clothes
34262	Pattern: Winter Boots
34319	Pattern: Red Winter Clothes
34329	Crux of the Apocalypse
34330	Heavy Knothide Armor Kit
34331	Hand of the Deceiver
34332	Cowl of Gul'dan
34333	Coif of Alleria
34334	Thori'dal, the Stars' Fury
34335	Hammer of Sanctification
34336	Sunflare
34337	Golden Staff of the Sin'dorei
34338	Mana Remnants
34339	Cowl of Light's Purity
34340	Dark Conjuror's Collar
34341	Borderland Paingrips
34342	Handguards of the Dawn
34343	Thalassian Ranger Gauntlets
34344	Handguards of Defiled Worlds
34345	Crown of Anasterian
34346	Mounting Vengeance
34347	Wand of the Demonsoul
34348	Wand of Cleansing Light
34349	Blade of Life's Inevitability
34350	Gauntlets of the Ancient Shadowmoon
34351	Tranquil Majesty Wraps
34352	Borderland Fortress Grips
34353	Quad Deathblow X44 Goggles
34354	Mayhem Projection Goggles
34355	Lightning Etched Specs
34356	Surestrike Goggles v3.0
34357	Hard Khorium Goggles
34358	Hard Khorium Choker
34359	Pendant of Sunfire
34360	Amulet of Flowing Life
34361	Hard Khorium Band
34362	Loop of Forged Power
34363	Ring of Flowing Life
34364	Sunfire Robe
34365	Robe of Eternal Light
34366	Sunfire Handwraps
34367	Hands of Eternal Light
34368	Attuned Crystal Cores
34369	Carapace of Sun and Shadow
34370	Gloves of Immortal Dusk
34371	Leather Chestguard of the Sun
34372	Leather Gauntlets of the Sun
34373	Embrace of the Phoenix
34374	Fletcher's Gloves of the Phoenix
34375	Sun-Drenched Scale Chestguard
34376	Sun-Drenched Scale Gloves
34377	Hard Khorium Battleplate
34378	Hard Khorium Battlefists
34379	Sunblessed Breastplate
34380	Sunblessed Gauntlets
34381	Felstrength Legplates
34382	Judicator's Legguards
34383	Kilt of Spiritual Reconstruction
34384	Breeches of Natural Splendor
34385	Leggings of the Immortal Beast
34386	Pantaloons of Growing Strife
34388	Pauldrons of Berserking
34389	Spaulders of the Thalassian Defender
34390	Erupting Epaulets
34391	Spaulders of Devastation
34392	Demontooth Shoulderpads
34393	Shoulderpads of Knowledge's Pursuit
34394	Breastplate of Agony's Aversion
34395	Noble Judicator's Chestguard
34396	Garments of Crashing Shores
34397	Bladed Chaos Tunic
34398	Utopian Tunic of Elune
34399	Robes of Ghostly Hatred
34400	Crown of Dath'Remar
34401	Helm of Uther's Resolve
34402	Shroud of Chieftain Ner'zhul
34403	Cover of Ursoc the Mighty
34404	Mask of the Fury Hunter
34405	Helm of Arcane Purity
34406	Gloves of Tyri's Power
34407	Tranquil Moonlight Wraps
34408	Gloves of the Forest Drifter
34409	Gauntlets of the Ancient Frostwolf
34410	Honeyed Holiday Ham
34411	Hot Apple Cider
34412	Sparkling Apple Cider
34413	Recipe: Hot Apple Cider
34414	Shattered Sun Banner
34415	Crystaline Shard Shield
34416	Gloves of the Dune
34417	Marauder's Handwraps
34418	Scrying Wand
34419	Thorium Flight Blade
34420	Captured Legion Scroll
34421	Cave Crawler's Mail Treads
34422	Tempered Thorium Boots
34423	Strength of the High Chief
34424	Power of the High Chief
34425	Clockwork Rocket Bot
34426	Winter Veil Gift
34427	Blackened Naaru Sliver
34428	Steely Naaru Sliver
34429	Shifting Naaru Sliver
34430	Glimmering Naaru Sliver
34431	Lightbringer Bands
34432	Lightbringer Bracers
34433	Lightbringer Wristguards
34434	Bracers of Absolution
34435	Cuffs of Absolution
34436	Bracers of the Malefic
34437	Skyshatter Bands
34438	Skyshatter Bracers
34439	Skyshatter Wristguards
34440	Mad Alchemist's Potion
34441	Onslaught Bracers
34442	Onslaught Wristguards
34443	Gronnstalker's Bracers
34444	Thunderheart Wristguards
34445	Thunderheart Bracers
34446	Thunderheart Bands
34447	Bracers of the Tempest
34448	Slayer's Bracers
34469	Strange Engine Part
34470	Timbal's Focusing Crystal
34471	Vial of the Sunwell
34472	Shard of Contempt
34473	Commendation of Kael'thas
34474	Strange Engine Part
34475	Arcane Charges
34476	Broken Engine Part
34477	Darkspine Chest Key
34478	Tiny Sporebat
34479	Darkspine Iron Ore
34480	Romantic Picnic Basket
34481	Recipe: Mad Alchemist's Potion
34482	Leatherworker's Satchel
34483	Orb of Murloc Control
34485	Lightbringer Girdle
34487	Lightbringer Belt
34488	Lightbringer Waistguard
34489	Flaming Oil
34490	Bag of Many Hides
34491	Pattern: Bag of Many Hides
34492	Rocket Chicken
34493	Dragon Kite
34494	Paper Zeppelin
34496	Upper Deck - Paper Airplane Book
34497	Paper Flying Machine
34498	Paper Zeppelin Kit
34499	Paper Flying Machine Kit
34500	Ata'mal Armament
34501	Cleansed Ata'mal Metal
34502	Bloodberry
34503	Box of Adamantite Shells
34504	Adamantite Shell Machine
34518	Golden Pig Coin
34519	Silver Pig Coin
34527	Belt of Absolution
34528	Cord of Absolution
34529	Vengeful Gladiator's Longbow
34530	Vengeful Gladiator's Rifle
34533	Astromancer's Crystal
34535	Azure Whelpling
34537	Bloodberry Elixir
34538	Blessed Weapon Coating
34539	Righteous Weapon Coating
34540	Vengeful Gladiator's Battle Staff
34541	Belt of the Malefic
34542	Skyshatter Cord
34543	Skyshatter Belt
34544	Essence of the Immortals
34545	Skyshatter Girdle
34546	Onslaught Belt
34547	Onslaught Waistguard
34548	Cache of the Shattered Sun
34549	Gronnstalker's Belt
34550	Indalamar's Ring of 200 Spirit
34551	Indalamar's Ring of 80 mp5
34554	Thunderheart Belt
34555	Thunderheart Cord
34556	Thunderheart Waistguard
34557	Belt of the Tempest
34558	Slayer's Belt
34559	Lightbringer Treads
34560	Lightbringer Stompers
34561	Lightbringer Boots
34562	Boots of Absolution
34563	Treads of Absolution
34564	Boots of the Malefic
34565	Skyshatter Boots
34566	Skyshatter Treads
34567	Skyshatter Greaves
34568	Onslaught Boots
34569	Onslaught Treads
34570	Gronnstalker's Boots
34571	Thunderheart Boots
34572	Thunderheart Footwraps
34573	Thunderheart Treads
34574	Boots of the Tempest
34575	Slayer's Boots
34576	Battlemaster's Cruelty
34577	Battlemaster's Depravity
34578	Battlemaster's Determination
34579	Battlemaster's Audacity
34580	Battlemaster's Perseverance
34581	Mysterious Arrow
34582	Mysterious Shell
34583	Aldor Supplies Package
34584	Scryer Supplies Package
34585	Scryer Supplies Package
34587	Aldor Supplies Package
34592	Aldor Supplies Package
34593	Scryer Supplies Package
34594	Scryer Supplies Package
34595	Aldor Supplies Package
34599	Juggling Torch
34601	Shoulderplates of Everlasting Pain
34602	Eversong Cuffs
34603	Distracting Blades
34604	Jaded Crystal Dagger
34605	Breastplate of Fierce Survival
34606	Edge of Oppression
34607	Fel-tinged Mantle
34608	Rod of the Blazing Light
34609	Quickening Blade of the Prince
34610	Scarlet Sin'dorei Robes
34611	Cudgel of Consecration
34612	Greaves of the Penitent Knight
34613	Shoulderpads of the Silvermoon Retainer
34614	Tunic of the Ranger Lord
34615	Netherforce Chestplate
34616	Breeching Comet
34622	Spinesever
34625	Kharmaa's Ring of Fate
34626	Prototype Tonk Controller
34627	Heavy Tonk Armor
34664	Sunmote
34665	Bombardier's Blade
34666	The Sunbreaker
34667	Archmage's Guile
34670	Seeker's Gavel
34671	K'iru's Presage
34672	Inuuro's Blade
34673	Legionfoe
34674	Truestrike Crossbow
34675	Sunward Crest
34676	Dawnforged Defender
34677	Shattered Sun Pendant of Restoration
34678	Shattered Sun Pendant of Acumen
34679	Shattered Sun Pendant of Might
34680	Shattered Sun Pendant of Resolve
34683	Sandals of Summer
34684	Handful of Summer Petals
34685	Vestment of Summer
34686	Brazier of Dancing Flames
34689	Design: Chaotic Skyfire Diamond
34697	Bindings of Raging Fire
34698	Bracers of the Forest Stalker
34699	Sun-forged Cleaver
34700	Gauntlets of Divine Blessings
34701	Leggings of the Betrayed
34702	Cloak of Swift Mending
34703	Latro's Dancing Blade
34704	Band of Arcane Alacrity
34705	Bracers of Divine Infusion
34706	Band of Determination
34707	Boots of Resuscitation
34708	Cloak of the Coming Night
34712	Prismatic Signet
34780	Naaru Ration
34783	Nightstrike
34788	Duskhallow Mantle
34789	Bracers of Slaughter
34790	Battle-mace of the High Priestess
34791	Gauntlets of the Tranquil Waves
34792	Cloak of the Betrayed
34793	Cord of Reconstruction
34794	Axe of Shattered Dreams
34795	Helm of Sanctification
34796	Robes of Summer Flame
34797	Sun-infused Focus Staff
34798	Band of Celerity
34799	Hauberk of the War Bringer
34807	Sunstrider Warboots
34808	Gloves of Arcane Acuity
34809	Sunrage Treads
34810	Cloak of Blade Turning
34822	Ancient Coin
34823	Beautiful Glass Eye
34824	Silver Statuette
34825	Mithril Shaving Razor
34826	Gold Wedding Band
34827	Noble's Monocle
34828	Antique Silver Cufflinks
34829	Ornate Drinking Stein
34831	Eye of the Sea
34832	Captain Rumsey's Lager
34833	Unlit Torches
34834	Recipe: Captain Rumsey's Lager
34836	Spun Truesilver Fishing Line
34837	The 2 Ring
34838	Mariner's Log
34839	Piece of Polished Driftwood
34840	Broken Spyglass
34841	Salvaged Scrap Metal
34843	Giant Shark Tooth
34845	Pit Lord's Satchel
34846	Black Sack of Gems
34847	Annihilator Holo-Gogs
34848	Bracers of the Forgotten Conqueror
34850	Midsummer Ground Flower
34851	Bracers of the Forgotten Protector
34852	Bracers of the Forgotten Vanquisher
34853	Belt of the Forgotten Conqueror
34854	Belt of the Forgotten Protector
34855	Belt of the Forgotten Vanquisher
34856	Boots of the Forgotten Conqueror
34857	Boots of the Forgotten Protector
34858	Boots of the Forgotten Vanquisher
34859	Razor Sharp Fillet Knife
34860	Rusted Lock
34861	Sharpened Fish Hook
34862	Practice Torches
34863	Bag of Fishing Treasures
34864	Baby Crocolisk
34865	Blackfin Darter
34866	Giant Freshwater Shrimp
34867	Monstrous Felblood Snapper
34868	World's Largest Mudfish
34872	Formula: Void Shatter
34887	Angelista's Revenge
34888	Ring of the Stalwart Protector
34889	Fused Nethergon Band
34890	Anveena's Touch
34891	The Blade of Harbingers
34892	Crossbow of Relentless Strikes
34893	Vanir's Right Fist of Brutality
34894	Blade of Serration
34895	Scryer's Blade of Focus
34896	Gavel of Naaru Blessings
34898	Staff of the Forest Lord
34900	Shroud of Nature's Harmony
34901	Grovewalker's Leggings
34902	Oakleaf-Spun Handguards
34903	Embrace of Starlight
34904	Barbed Gloves of the Sage
34905	Crystalwind Leggings
34906	Embrace of Everlasting Prowess
34907	Shattered Gem Fragments
34910	Tameless Breeches
34911	Handwraps of the Aggressor
34912	Scaled Drakeskin Chestguard
34914	Leggings of the Pursuit
34916	Gauntlets of Rapidity
34917	Shroud of the Lore`nial
34918	Legwraps of Sweltering Flame
34919	Boots of Incantations
34921	Ecclesiastical Cuirass
34922	Greaves of Pacification
34923	Waistguard of Reparation
34924	Gown of Spiritual Wonder
34925	Adorned Supernal Legwraps
34926	Slippers of Dutiful Mending
34927	Tunic of the Dark Hour
34928	Trousers of the Scryers' Retainer
34929	Belt of the Silent Path
34930	Wave of Life Chestguard
34931	Runed Scales of Antiquity
34932	Clutch of the Soothing Breeze
34933	Hauberk of Whirling Fury
34934	Rushing Storm Kilt
34935	Aftershock Waistguard
34936	Tormented Demonsoul Robes
34937	Corrupted Soulcloth Pantaloons
34938	Enslaved Doomguard Soulgrips
34939	Chestplate of Stoicism
34940	Sunguard Legplates
34941	Girdle of the Fearless
34942	Breastplate of Ire
34943	Legplates of Unending Fury
34944	Girdle of Seething Rage
34945	Shattrath Protectorate's Breastplate
34946	Inscribed Legplates of the Aldor
34947	Blue's Greaves of the Righteous Guardian
34949	Swift Blade of Uncertainty
34950	Vanir's Left Fist of Savagery
34951	Vanir's Left Fist of Brutality
34952	The Mutilator
34953	Earthen Ring Magma Totem
34955	Scorched Stone
34985	Brutal Gladiator's Baton of Light
34986	Brutal Gladiator's Barrier
34987	Brutal Gladiator's Battle Staff
34988	Brutal Gladiator's Bonecracker
34989	Brutal Gladiator's Bonegrinder
34990	Brutal Gladiator's Chain Armor
34991	Brutal Gladiator's Chain Gauntlets
34992	Brutal Gladiator's Chain Helm
34993	Brutal Gladiator's Chain Leggings
34994	Brutal Gladiator's Chain Spaulders
34995	Brutal Gladiator's Chopper
34996	Brutal Gladiator's Cleaver
34997	Brutal Gladiator's Decapitator
34998	Brutal Gladiator's Dragonhide Gloves
34999	Brutal Gladiator's Dragonhide Helm
35000	Brutal Gladiator's Dragonhide Legguards
35001	Brutal Gladiator's Dragonhide Spaulders
35002	Brutal Gladiator's Dragonhide Tunic
35003	Brutal Gladiator's Dreadweave Gloves
35004	Brutal Gladiator's Dreadweave Hood
35005	Brutal Gladiator's Dreadweave Leggings
35006	Brutal Gladiator's Dreadweave Mantle
35007	Brutal Gladiator's Dreadweave Robe
35008	Brutal Gladiator's Endgame
35009	Brutal Gladiator's Felweave Amice
35010	Brutal Gladiator's Felweave Cowl
35011	Brutal Gladiator's Felweave Handguards
35012	Brutal Gladiator's Felweave Raiment
35013	Brutal Gladiator's Felweave Trousers
35014	Brutal Gladiator's Gavel
35015	Brutal Gladiator's Greatsword
35016	Brutal Gladiator's Grimoire
35017	Brutal Gladiator's Hacker
35018	Brutal Gladiator's Heavy Crossbow
35019	Brutal Gladiator's Idol of Resolve
35020	Brutal Gladiator's Idol of Steadfastness
35021	Brutal Gladiator's Idol of Tenacity
35022	Brutal Gladiator's Kodohide Gloves
35023	Brutal Gladiator's Kodohide Helm
35024	Brutal Gladiator's Kodohide Legguards
35025	Brutal Gladiator's Kodohide Spaulders
35026	Brutal Gladiator's Kodohide Tunic
35027	Brutal Gladiator's Lamellar Chestpiece
35028	Brutal Gladiator's Lamellar Gauntlets
35029	Brutal Gladiator's Lamellar Helm
35030	Brutal Gladiator's Lamellar Legguards
35031	Brutal Gladiator's Lamellar Shoulders
35032	Brutal Gladiator's Leather Gloves
35033	Brutal Gladiator's Leather Helm
35034	Brutal Gladiator's Leather Legguards
35035	Brutal Gladiator's Leather Spaulders
35036	Brutal Gladiator's Leather Tunic
35037	Brutal Gladiator's Left Render
35038	Brutal Gladiator's Left Ripper
35039	Brutal Gladiator's Libram of Fortitude
35040	Brutal Gladiator's Libram of Justice
35041	Brutal Gladiator's Libram of Vengeance
35042	Brutal Gladiator's Linked Armor
35043	Brutal Gladiator's Linked Gauntlets
35044	Brutal Gladiator's Linked Helm
35045	Brutal Gladiator's Linked Leggings
35046	Brutal Gladiator's Linked Spaulders
35047	Brutal Gladiator's Longbow
35048	Brutal Gladiator's Mail Armor
35049	Brutal Gladiator's Mail Gauntlets
35050	Brutal Gladiator's Mail Helm
35051	Brutal Gladiator's Mail Leggings
35052	Brutal Gladiator's Mail Spaulders
35053	Brutal Gladiator's Mooncloth Gloves
35054	Brutal Gladiator's Mooncloth Hood
35055	Brutal Gladiator's Mooncloth Leggings
35056	Brutal Gladiator's Mooncloth Mantle
35057	Brutal Gladiator's Mooncloth Robe
35058	Brutal Gladiator's Mutilator
35059	Brutal Gladiator's Ornamented Chestguard
35060	Brutal Gladiator's Ornamented Gloves
35061	Brutal Gladiator's Ornamented Headcover
35062	Brutal Gladiator's Ornamented Legplates
35063	Brutal Gladiator's Ornamented Spaulders
35064	Brutal Gladiator's Painsaw
35065	Brutal Gladiator's Piercing Touch
35066	Brutal Gladiator's Plate Chestpiece
35067	Brutal Gladiator's Plate Gauntlets
35068	Brutal Gladiator's Plate Helm
35069	Brutal Gladiator's Plate Legguards
35070	Brutal Gladiator's Plate Shoulders
35071	Brutal Gladiator's Pummeler
35072	Brutal Gladiator's Quickblade
35073	Brutal Gladiator's Redoubt
35074	Brutal Gladiator's Reprieve
35075	Brutal Gladiator's Rifle
35076	Brutal Gladiator's Right Ripper
35077	Brutal Gladiator's Ringmail Armor
35078	Brutal Gladiator's Ringmail Gauntlets
35079	Brutal Gladiator's Ringmail Helm
35080	Brutal Gladiator's Ringmail Leggings
35081	Brutal Gladiator's Ringmail Spaulders
35082	Brutal Gladiator's Salvation
35083	Brutal Gladiator's Satin Gloves
35084	Brutal Gladiator's Satin Hood
35085	Brutal Gladiator's Satin Leggings
35086	Brutal Gladiator's Satin Mantle
35087	Brutal Gladiator's Satin Robe
35088	Brutal Gladiator's Scaled Chestpiece
35089	Brutal Gladiator's Scaled Gauntlets
35090	Brutal Gladiator's Scaled Helm
35091	Brutal Gladiator's Scaled Legguards
35092	Brutal Gladiator's Scaled Shoulders
35093	Brutal Gladiator's Shanker
35094	Brutal Gladiator's Shield Wall
35095	Brutal Gladiator's Shiv
35096	Brutal Gladiator's Silk Amice
35097	Brutal Gladiator's Silk Cowl
35098	Brutal Gladiator's Silk Handguards
35099	Brutal Gladiator's Silk Raiment
35100	Brutal Gladiator's Silk Trousers
35101	Brutal Gladiator's Slicer
35102	Brutal Gladiator's Spellblade
35103	Brutal Gladiator's Staff
35104	Brutal Gladiator's Totem of Indomitability
35105	Brutal Gladiator's Totem of Survival
35106	Brutal Gladiator's Totem of the Third Wind
35107	Brutal Gladiator's Touch of Defeat
35108	Brutal Gladiator's War Edge
35109	Brutal Gladiator's War Staff
35110	Brutal Gladiator's Waraxe
35111	Brutal Gladiator's Wyrmhide Gloves
35112	Brutal Gladiator's Wyrmhide Helm
35113	Brutal Gladiator's Wyrmhide Legguards
35114	Brutal Gladiator's Wyrmhide Spaulders
35115	Brutal Gladiator's Wyrmhide Tunic
35128	Hardened Khorium
35129	Guardian's Band of Dominance
35130	Guardian's Band of Salvation
35131	Guardian's Band of Triumph
35132	Guardian's Pendant of Conquest
35133	Guardian's Pendant of Dominance
35134	Guardian's Pendant of Salvation
35135	Guardian's Pendant of Triumph
35136	Guardian's Chain Sabatons
35137	Guardian's Dragonhide Boots
35138	Guardian's Dreadweave Stalkers
35139	Guardian's Kodohide Boots
35140	Guardian's Lamellar Greaves
35141	Guardian's Leather Boots
35142	Guardian's Linked Sabatons
35143	Guardian's Mail Sabatons
35144	Guardian's Mooncloth Slippers
35145	Guardian's Ornamented Greaves
35146	Guardian's Plate Greaves
35147	Guardian's Ringmail Sabatons
35148	Guardian's Scaled Greaves
35149	Guardian's Silk Footguards
35150	Guardian's Wyrmhide Boots
35151	Guardian's Chain Girdle
35152	Guardian's Dragonhide Belt
35153	Guardian's Dreadweave Belt
35154	Guardian's Kodohide Belt
35155	Guardian's Lamellar Belt
35156	Guardian's Leather Belt
35157	Guardian's Linked Girdle
35158	Guardian's Mail Girdle
35159	Guardian's Mooncloth Belt
35160	Guardian's Ornamented Belt
35161	Guardian's Plate Belt
35162	Guardian's Ringmail Girdle
35163	Guardian's Scaled Belt
35164	Guardian's Silk Belt
35165	Guardian's Wyrmhide Belt
35166	Guardian's Chain Bracers
35167	Guardian's Dragonhide Bracers
35168	Guardian's Dreadweave Cuffs
35169	Guardian's Kodohide Bracers
35170	Guardian's Lamellar Bracers
35171	Guardian's Leather Bracers
35172	Guardian's Linked Bracers
35173	Guardian's Mail Bracers
35174	Guardian's Mooncloth Cuffs
35175	Guardian's Ornamented Bracers
35176	Guardian's Plate Bracers
35177	Guardian's Ringmail Bracers
35178	Guardian's Scaled Bracers
35179	Guardian's Silk Cuffs
35180	Guardian's Wyrmhide Bracers
35181	Powerheal 9000 Lens
35182	Hyper-Magnified Moon Specs
35183	Wonderheal XT68 Shades
35184	Primal-Attuned Goggles
35185	Justicebringer 3000 Specs
35186	Schematic: Annihilator Holo-Gogs
35187	Schematic: Justicebringer 3000 Specs
35189	Schematic: Powerheal 9000 Lens
35190	Schematic: Hyper-Magnified Moon Specs
35191	Schematic: Wonderheal XT68 Shades
35192	Schematic: Primal-Attuned Goggles
35193	Schematic: Lightning Etched Specs
35194	Schematic: Surestrike Goggles v3.0
35195	Schematic: Mayhem Projection Goggles
35196	Schematic: Hard Khorium Goggles
35197	Schematic: Quad Deathblow X44 Goggles
35198	Design: Loop of Forged Power
35199	Design: Ring of Flowing Life
35200	Design: Hard Khorium Band
35201	Design: Pendant of Sunfire
35202	Design: Amulet of Flowing Life
35203	Design: Hard Khorium Choker
35204	Pattern: Sunfire Handwraps
35205	Pattern: Hands of Eternal Light
35206	Pattern: Sunfire Robe
35207	Pattern: Robe of Eternal Light
35208	Plans: Sunblessed Gauntlets
35209	Plans: Hard Khorium Battlefists
35210	Plans: Sunblessed Breastplate
35211	Plans: Hard Khorium Battleplate
35212	Pattern: Leather Gauntlets of the Sun
35213	Pattern: Fletcher's Gloves of the Phoenix
35214	Pattern: Gloves of Immortal Dusk
35215	Pattern: Sun-Drenched Scale Gloves
35216	Pattern: Leather Chestguard of the Sun
35217	Pattern: Embrace of the Phoenix
35218	Pattern: Carapace of Sun and Shadow
35219	Pattern: Sun-Drenched Scale Chestguard
35221	Tabard of the Shattered Sun
35225	X-51 Nether-Rocket
35226	X-51 Nether-Rocket X-TREME
35227	Goblin Weather Machine - Prototype 01-B
35229	Nether Residue
35230	Darnarian's Scroll of Teleportation
35231	Sunfury Attack Plans
35232	Shattered Sun Supplies
35233	Multiphase Spectrographic Goggles
35237	Orb of the Crawler
35238	Design: Balanced Shadowsong Amethyst
35239	Design: Glowing Shadowsong Amethyst
35240	Design: Infused Shadowsong Amethyst
35241	Design: Royal Shadowsong Amethyst
35242	Design: Shifting Shadowsong Amethyst
35243	Design: Sovereign Shadowsong Amethyst
35244	Design: Bold Crimson Spinel
35245	Design: Bright Crimson Spinel
35246	Design: Delicate Crimson Spinel
35247	Design: Flashing Crimson Spinel
35248	Design: Runed Crimson Spinel
35249	Design: Subtle Crimson Spinel
35250	Design: Teardrop Crimson Spinel
35251	Design: Dazzling Seaspray Emerald
35252	Design: Enduring Seaspray Emerald
35253	Design: Jagged Seaspray Emerald
35254	Design: Radiant Seaspray Emerald
35255	Design: Brilliant Lionseye
35256	Design: Gleaming Lionseye
35257	Design: Great Lionseye
35258	Design: Mystic Lionseye
35259	Design: Rigid Lionseye
35260	Design: Smooth Lionseye
35261	Design: Thick Lionseye
35262	Design: Lustrous Empyrean Sapphire
35263	Design: Solid Empyrean Sapphire
35264	Design: Sparkling Empyrean Sapphire
35265	Design: Stormy Empyrean Sapphire
35266	Design: Glinting Pyrestone
35267	Design: Inscribed Pyrestone
35268	Design: Luminous Pyrestone
35269	Design: Potent Pyrestone
35270	Design: Veiled Pyrestone
35271	Design: Wicked Pyrestone
35273	Study of Advanced Smelting
35275	Orb of the Sin'dorei
35277	Twilight Correspondence
35279	Tabard of Summer Skies
35280	Tabard of Summer Flames
35282	Sin'dorei Band of Dominance
35283	Sin'dorei Band of Salvation
35284	Sin'dorei Band of Triumph
35285	Giant Sunfish
35286	Bloated Giant Sunfish
35287	Luminous Bluetail
35290	Sin'dorei Pendant of Conquest
35291	Sin'dorei Pendant of Salvation
35292	Sin'dorei Pendant of Triumph
35294	Recipe: Elixir of Empowerment
35295	Recipe: Haste Potion
35296	Plans: Adamantite Weapon Chain
35297	Formula: Enchant Boots - Boar's Speed
35298	Formula: Enchant Boots - Vitality
35299	Formula: Enchant Boots - Cat's Swiftness
35300	Pattern: Windstrike Gloves
35301	Pattern: Netherdrake Gloves
35302	Pattern: Cobrascale Gloves
35303	Pattern: Gloves of the Living Touch
35304	Design: Solid Star of Elune
35305	Design: Runed Living Ruby
35306	Design: Bright Living Ruby
35307	Design: Rigid Dawnstone
35308	Pattern: Unyielding Bracers
35309	Pattern: Unyielding Girdle
35310	Schematic: Healing Potion Injector
35311	Schematic: Mana Potion Injector
35313	Bloated Barbed Gill Trout
35314	Partially Digested Weeds
35315	Quick Dawnstone
35316	Reckless Noble Topaz
35317	Vindicator's Pendant of Reprieve
35318	Forceful Talasite
35319	Vindicator's Pendant of Subjugation
35320	Vindicator's Band of Subjugation
35321	Cloak of Arcane Alacrity
35322	Design: Quick Dawnstone
35323	Design: Reckless Noble Topaz
35324	Cloak of Swift Reprieve
35325	Design: Forceful Talasite
35326	Battlemaster's Alacrity
35327	Battlemaster's Alacrity
35328	Dreadweave Gloves
35329	Dreadweave Hood
35330	Dreadweave Leggings
35331	Dreadweave Mantle
35332	Dreadweave Robe
35333	Mooncloth Cowl
35334	Mooncloth Legguards
35335	Mooncloth Mitts
35336	Mooncloth Shoulderpads
35337	Mooncloth Vestments
35338	Satin Gloves
35339	Satin Hood
35340	Satin Leggings
35341	Satin Mantle
35342	Satin Robe
35343	Evoker's Silk Amice
35344	Evoker's Silk Cowl
35345	Evoker's Silk Handguards
35346	Evoker's Silk Raiment
35347	Evoker's Silk Trousers
35348	Bag of Fishing Treasures
35349	Snarly's Bucket
35350	Chuck's Bucket
35356	Dragonhide Gloves
35357	Dragonhide Helm
35358	Dragonhide Legguards
35359	Dragonhide Spaulders
35360	Dragonhide Robe
35361	Kodohide Gloves
35362	Kodohide Helm
35363	Kodohide Legguards
35364	Kodohide Spaulders
35365	Kodohide Robe
35366	Opportunist's Leather Gloves
35367	Opportunist's Leather Helm
35368	Opportunist's Leather Legguards
35369	Opportunist's Leather Spaulders
35370	Opportunist's Leather Tunic
35371	Wyrmhide Gloves
35372	Wyrmhide Helm
35373	Wyrmhide Legguards
35374	Wyrmhide Spaulders
35375	Wyrmhide Robe
35376	Stalker's Chain Armor
35377	Stalker's Chain Gauntlets
35378	Stalker's Chain Helm
35379	Stalker's Chain Leggings
35380	Stalker's Chain Spaulders
35381	Seer's Linked Armor
35382	Seer's Linked Gauntlets
35383	Seer's Linked Helm
35384	Seer's Linked Leggings
35385	Seer's Linked Spaulders
35386	Seer's Mail Armor
35387	Seer's Mail Gauntlets
35388	Seer's Mail Helm
35389	Seer's Mail Leggings
35390	Seer's Mail Spaulders
35391	Seer's Ringmail Chestguard
35392	Seer's Ringmail Gloves
35393	Seer's Ringmail Headpiece
35394	Seer's Ringmail Legguards
35395	Seer's Ringmail Shoulderpads
35396	Enchant 2H Weapon - Major Agility
35397	Enchant 2H Weapon - Savagery
35398	Enchant Boots - Boar's Speed
35399	Enchant Boots - Cat's Swiftness
35400	Enchant Boots - Dexterity
35402	Crusader's Ornamented Chestplate
35403	Crusader's Ornamented Gloves
35404	Crusader's Ornamented Headguard
35405	Crusader's Ornamented Leggings
35406	Crusader's Ornamented Spaulders
35407	Savage Plate Chestpiece
35408	Savage Plate Gauntlets
35409	Savage Plate Helm
35410	Savage Plate Legguards
35411	Savage Plate Shoulders
35412	Crusader's Scaled Chestpiece
35413	Crusader's Scaled Gauntlets
35414	Crusader's Scaled Helm
35415	Crusader's Scaled Legguards
35416	Crusader's Scaled Shoulders
35417	Enchant Boots - Fortitude
35418	Enchant Boots - Surefooted
35419	Enchant Boots - Vitality
35420	Enchant Bracer - Brawn
35421	Enchant Bracer - Fortitude
35422	Enchant Bracer - Major Defense
35423	Enchant Bracer - Major Intellect
35424	Enchant Bracer - Restore Mana Prime
35425	Enchant Bracer - Spellpower
35426	Enchant Bracer - Stats
35427	Enchant Bracer - Superior Healing
35428	Enchant Chest - Exceptional Health
35429	Enchant Chest - Exceptional Stats
35430	Enchant Chest - Major Resilience
35431	Enchant Chest - Major Spirit
35432	Enchant Cloak - Greater Agility
35433	Enchant Cloak - Greater Arcane Resistance
35434	Enchant Cloak - Greater Shadow Resistance
35435	Enchant Cloak - Major Resistance
35436	Enchant Cloak - Spell Penetration
35437	Enchant Cloak - Major Armor
35438	Enchant Gloves - Assault
35439	Enchant Gloves - Blasting
35440	Enchant Gloves - Major Healing
35441	Enchant Gloves - Major Spellpower
35442	Enchant Gloves - Major Strength
35443	Enchant Gloves - Spell Strike
35444	Enchant Ring - Healing Power
35445	Enchant Ring - Spellpower
35446	Enchant Ring - Stats
35447	Enchant Ring - Striking
35448	Enchant Shield - Intellect
35449	Enchant Shield - Major Stamina
35450	Enchant Shield - Resistance
35451	Enchant Shield - Shield Block
35452	Enchant Weapon - Battlemaster
35453	Enchant Weapon - Greater Agility
35454	Enchant Weapon - Major Healing
35455	Enchant Weapon - Major Intellect
35456	Enchant Weapon - Major Spellpower
35457	Enchant Weapon - Major Striking
35458	Enchant Weapon - Mongoose
35459	Enchant Weapon - Potency
35460	Enchant Weapon - Soulfrost
35461	Enchant Weapon - Spellsurge
35462	Enchant Weapon - Sunfire
35464	Dreadweave Robe
35465	Evoker's Silk Amice
35466	Satin Hood
35467	Mooncloth Vestments
35468	Opportunist's Leather Gloves
35469	Dragonhide Robe
35470	Kodohide Spaulders
35471	Wyrmhide Gloves
35472	Seer's Mail Armor
35473	Seer's Ringmail Gloves
35474	Seer's Linked Helm
35475	Stalker's Chain Gauntlets
35476	Crusader's Ornamented Spaulders
35477	Crusader's Scaled Gauntlets
35478	Savage Plate Helm
35487	Bright Crimson Spinel
35488	Runed Crimson Spinel
35489	Teardrop Crimson Spinel
35494	Shroud of Winter's Chill
35495	The Frost Lord's War Cloak
35496	Icebound Cloak
35497	Cloak of the Frigid Winds
35498	Formula: Enchant Weapon - Deathfrost
35500	Formula: Enchant Chest - Defense
35501	Eternal Earthstorm Diamond
35502	Design: Eternal Earthstorm Diamond
35503	Ember Skyfire Diamond
35504	Phoenix Hatchling
35505	Design: Ember Skyfire Diamond
35507	Amulet of Bitter Hatred
35508	Choker of the Arctic Flow
35509	Amulet of Glacial Tranquility
35511	Hailstone Pendant
35512	Pocket Full of Snow
35513	Swift White Hawkstrider
35514	Frostscythe of Lord Ahune
35516	Sun Touched Satchel
35517	Pattern: Bindings of Lightning Reflexes
35518	Pattern: Bracers of Nimble Thought
35519	Pattern: Bracers of Renewed Life
35520	Pattern: Living Earth Bindings
35521	Pattern: Living Earth Shoulders
35522	Pattern: Mantle of Nimble Thought
35523	Pattern: Shoulderpads of Renewed Life
35524	Pattern: Shoulders of Lightning Reflexes
35525	Pattern: Swiftheal Mantle
35526	Pattern: Swiftheal Wraps
35527	Pattern: Swiftstrike Bracers
35528	Pattern: Swiftstrike Shoulders
35529	Plans: Dawnsteel Bracers
35530	Plans: Dawnsteel Shoulders
35531	Plans: Swiftsteel Bracers
35532	Plans: Swiftsteel Shoulders
35533	Design: Amulet of Flowing Life
35534	Design: Hard Khorium Band
35535	Design: Hard Khorium Choker
35536	Design: Loop of Forged Power
35537	Design: Pendant of Sunfire
35538	Design: Ring of Flowing Life
35539	Pattern: Carapace of Sun and Shadow
35540	Pattern: Embrace of the Phoenix
35541	Pattern: Fletcher's Gloves of the Phoenix
35542	Pattern: Gloves of Immortal Dusk
35544	Pattern: Hands of Eternal Light
35545	Pattern: Leather Chestguard of the Sun
35546	Pattern: Leather Gauntlets of the Sun
35548	Pattern: Robe of Eternal Light
35549	Pattern: Sun-Drenched Scale Chestguard
35550	Pattern: Sun-Drenched Scale Gloves
35551	Pattern: Sunfire Handwraps
35552	Pattern: Sunfire Robe
35553	Plans: Hard Khorium Battlefists
35554	Plans: Hard Khorium Battleplate
35555	Plans: Sunblessed Breastplate
35556	Plans: Sunblessed Gauntlets
35557	Huge Snowball
35562	Bear Flank
35563	Charred Bear Kabobs
35564	Recipe: Charred Bear Kabobs
35565	Juicy Bear Burger
35566	Recipe: Juicy Bear Burger
35568	Flame of Silvermoon
35569	Flame of the Exodar
35581	Rocket Boots Xtreme Lite
35582	Schematic: Rocket Boots Xtreme Lite
35691	Ruined Metal Parts
35693	Figurine - Empyrean Tortoise
35694	Figurine - Khorium Boar
35695	Design: Figurine - Empyrean Tortoise
35696	Design: Figurine - Khorium Boar
35697	Design: Figurine - Crimson Serpent
35698	Design: Figurine - Shadowsong Panther
35699	Design: Figurine - Seaspray Albatross
35700	Figurine - Crimson Serpent
35702	Figurine - Shadowsong Panther
35703	Figurine - Seaspray Albatross
35707	Regal Nightseye
35708	Design: Regal Nightseye
35710	Delicious Baked Ham
35716	Shattrath Flask of Pure Death
35717	Shattrath Flask of Blinding Light
35720	Lord of Frost's Private Label
35721	Flaskataur's Lamp
35722	Foror's Wipe Neutralizer
35723	Shards of Ahune
35725	Summer Incense
35728	Greater Inscription of the Blade
35729	Greater Inscription of the Knight
35730	Greater Inscription of the Oracle
35731	Greater Inscription of the Orb
35733	Ring of Harmonic Beauty
35748	Guardian's Alchemist Stone
35749	Sorcerer's Alchemist Stone
35750	Redeemer's Alchemist Stone
35751	Assassin's Alchemist Stone
35752	Recipe: Guardian's Alchemist Stone
35753	Recipe: Sorcerer's Alchemist Stone
35754	Recipe: Redeemer's Alchemist Stone
35755	Recipe: Assassin's Alchemist Stone
35756	Formula: Enchant Cloak - Steelweave
35758	Steady Seaspray Emerald
35759	Forceful Seaspray Emerald
35760	Reckless Pyrestone
35761	Quick Lionseye
35762	Design: Reckless Pyrestone
35763	Design: Quick Lionseye
35764	Design: Steady Seaspray Emerald
35765	Design: Forceful Seaspray Emerald
35766	Design: Steady Seaspray Emerald
35767	Design: Reckless Pyrestone
35768	Design: Quick Lionseye
35769	Design: Forceful Seaspray Emerald
35828	Totemic Beacon
35874	Whizzlespark's Portable Pet Mansion
35906	Reins of the Black War Elekk
35945	Brilliant Glass
36737	Brutal Gladiator's Hatchet
36748	Dark Brewmaiden's Brew
36876	Scorched Holy Symbol
36877	Folded Letter
36941	Competitor's Tabard
37011	Magic Broom
37012	The Horseman's Reins
37127	Brightbrew Charm
37128	Balebrew Charm
37148	Singed Page
37297	Gold Medallion
37298	Competitor's Souvenir
37311	Skybreaker Whip
37312	Carrot on a Stick
37313	Riding Crop
37488	Wild Winter Pilsner
37489	Izzard's Ever Flavor
37490	Aromatic Honey Brew
37491	Metok's Bubble Bock
37492	Springtime Stout
37493	Blackrock Lager
37494	Stranglethorn Brew
37495	Draenic Pale Ale
37496	Binary Brew
37497	Autumnal Acorn Ale
37498	Bartlett's Bitter Brew
37499	Lord of Frost's Private Label
37503	Purified Shadowsong Amethyst
37504	Design: Purified Shadowsong Amethyst
37567	Healing Injector Kit
37571	"Brew of the Month" Club Membership Form
37582	Pyroblast Cinnamon Ball
37583	G.N.E.R.D.S.
37584	Soothing Spearmint Candy
37585	Chewy Fel Taffy
37586	Handful of Candy
37588	Mostly Digested Fish
37596	Direbrew's Bottle DO NOT USE
37597	Direbrew's Shanker
37599	"Brew of the Month" Club Membership Form
37604	Tooth Pick
37605	Pouch of Pennies
37606	Penny Pouch
37676	Vengeful Nether Drake
37710	Crashin' Thrashin' Racer Controller
37719	Swift Zhevra
37736	"Brew of the Month" Club Membership Form
37737	"Brew of the Month" Club Membership Form
37739	Brutal Gladiator's Blade of Alacrity
37740	Brutal Gladiator's Swift Judgement
37750	Fresh Brewfest Hops
37816	Preserved Brewfest Hops
37827	Brewfest Kodo
37828	Great Brewfest Kodo
37829	Brewfest Prize Token
37863	Direbrew's Remote
37864	Medallion of the Alliance
37865	Medallion of the Horde
37898	Wild Winter Pilsner
37899	Izzard's Ever Flavor
37900	Aromatic Honey Brew
37901	Metok's Bubble Bock
37902	Springtime Stout
37903	Blackrock Lager
37904	Stranglethorn Brew
37905	Draenic Pale Ale
37906	Binary Brew
37907	Autumnal Acorn Ale
37908	Bartlett's Bitter Brew
37909	Lord of Frost's Private Label
37915	Pattern: Dress Shoes
37927	Guardian's Band of Subjugation
37928	Guardian's Pendant of Subjugation
37929	Guardian's Pendant of Reprieve
37934	Noble's Elementium Signet
38050	Soul-Trader Beacon
38082	"Gigantique" Bag
38089	Ruby Shades
38090	Sapphire Pinky Ring
38091	Gold Eternium Band
38160	Soul-Trader's Bindings
38161	Soul-Trader's Gloves
38162	Soul-Trader's Boots
38163	Soul-Trader's Head Wrap
38175	The Horseman's Blade
38186	Ethereal Credit
38225	Mycah's Botanical Bag
38229	Pattern: Mycah's Botanical Bag
38233	Path of Illidan
38276	Haliscan Brimmed Hat
38277	Haliscan Jacket
38278	Haliscan Pantaloons
38280	Direbrew's Dire Brew
38281	Direbrew's Dire Brew
38285	Soul-Trader's Waistband
38286	Soul-Trader's Pauldrons
38287	Empty Mug of Direbrew
38288	Direbrew Hops
38289	Coren's Lucky Coin
38290	Dark Iron Smoking Pipe
38291	Ethereal Mutagen
38294	Ethereal Liqueur
38300	Diluted Ethereum Essence
38301	D.I.S.C.O.
38308	Ethereal Essence Sphere
38309	Tabard of Nature
38310	Tabard of the Arcane
38311	Tabard of the Void
38312	Tabard of Brilliance
38313	Tabard of Fury
38314	Tabard of the Defender
38320	Dire Brew
38327	Pattern: Haliscan Jacket
38328	Pattern: Haliscan Pantaloons
38329	Don Carlos' Hat
38427	Pickled Egg
38428	Rock-Salted Pretzel
38429	Blackrock Spring Water
38430	Blackrock Mineral Water
38431	Blackrock Fortified Water
38432	Plugger's Blackrock Ale
38466	Sulfuron Slammer
38506	Don Carlos' Famous Hat
38518	Cro's Apple
38545	Bold Ornate Ruby
38546	Gleaming Ornate Dawnstone
38547	Inscribed Ornate Topaz
38548	Potent Ornate Topaz
38549	Runed Ornate Ruby
38550	Smooth Ornate Dawnstone
38576	Big Battle Bear
38577	Party G.R.E.N.A.D.E.
38578	The Flag of Ownership
38579	Venomous Tome
38587	Empty Brewfest Stein
38626	Empty Brew Bottle
38628	Nether Ray Fry
39476	Fresh Goblin Brewfest Hops
39477	Fresh Dwarven Brewfest Hops
39656	Tyrael's Hilt
43516	Brutal Nether Drake
]==]
