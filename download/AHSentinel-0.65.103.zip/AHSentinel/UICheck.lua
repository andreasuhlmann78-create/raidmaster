if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Prüfung der Oberfläche im echten Client (Testfälle T191–T196, Bereich K)
-- Übernommen aus shared/vorlage/__ADDON__/UICheck.lua (T18–T23), angepasst an AHSentinel (AHAnalyzerPro.UIC).
--
-- Anlass (Live-Test 5. Nov. 2026): eigene Tooltips verdeckten Knöpfe, Fenster lagen übereinander, Anzeigen rechneten
-- mit falschen Spielwerten, ein Fehler kam 588×. Offline sieht man das nicht – darum prüft die Testroutine es im
-- Spiel selbst. Nur lesen, nichts verändern.
--
-- Benutzung:
--   A.RegisterUI(frame, "Name")          -- jedes eigene Fenster anmelden (UI:Dialog, Hauptfenster, Gewinn-Fenster)
--   A.Plausible("Name", function() return ok, wert, erwartet end)   -- Spielwert-Prüfung für T195
-- Andere GoldSentinel-Addons melden ihre Fenster in der globalen Liste GoldSentinelUIFrames an (T192 prüft gegeneinander).
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local ADDON = "AHSentinel"

local ns = A.UIC or {}
A.UIC = ns
ns.uiFrames = ns.uiFrames or {}
ns.plausible = ns.plausible or {}
ns.UI_LOOP_LIMIT = 10                       -- dieselbe Fehlermeldung öfter -> Fehlerschleife (T196)

-- Blizzard-Fenster, an die GoldSentinel-Addons andocken (dürfen nicht überdeckt werden)
ns.UI_BLIZZARD = { "ProfessionsFrame", "TradeSkillFrame", "CraftFrame", "MerchantFrame", "AuctionHouseFrame",
                   "AuctionFrame", "MailFrame", "QuestLogFrame", "WorldMapFrame", "CharacterFrame",
                   "MerchantFrameTab1", "MerchantFrameTab2" }     -- Reiter Händler / Rückkauf (Knopf beim Händler, 5. Nov.)

GoldSentinelUIFrames = GoldSentinelUIFrames or {}

function ns.RegisterUI(frame, name)
    if not frame then return end
    for _, e in ipairs(ns.uiFrames) do if e.frame == frame then return end end
    local e = { frame = frame, name = name or (frame.GetName and frame:GetName()) or ADDON }
    ns.uiFrames[#ns.uiFrames + 1] = e
    GoldSentinelUIFrames[#GoldSentinelUIFrames + 1] = { frame = frame, name = e.name, addon = ADDON }
end
A.RegisterUI = ns.RegisterUI

function ns.Plausible(name, fn) ns.plausible[#ns.plausible + 1] = { name = name, fn = fn } end
A.Plausible = ns.Plausible

local U = {}
ns.UICheck = U

-- Liefert GetRect echte Positionen (Anker werden ausgewertet)? Offline-Nachbauten geben oft feste Werte zurück.
function U.LayoutReal()
    if U.layoutReal ~= nil then return U.layoutReal end
    local ok, real = pcall(function()
        local f = CreateFrame("Frame", nil, UIParent)
        f:SetSize(10, 10)
        f:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 37, 53)
        local l, b = f:GetRect()
        f:Hide()
        return l ~= nil and math.abs(l - 37) < 1 and math.abs(b - 53) < 1
    end)
    U.layoutReal = (ok and real) and true or false
    return U.layoutReal
end

-- Ist der echte Client da (Rechtecke, Kinder, Tooltip, echtes Layout)? Sonst werden die Fälle ehrlich übersprungen.
function U.Available()
    local f = ns.uiFrames[1] and ns.uiFrames[1].frame
    return f and type(f.GetRect) == "function" and type(f.GetChildren) == "function"
        and type(GameTooltip) == "table" and type(GameTooltip.GetRect) == "function"
        and type(UIParent) == "table" and type(UIParent.GetRect) == "function" and U.LayoutReal() and true or false
end

-- clickArea = true: nur die Klickfläche (ohne unsichtbaren Rand, GetHitRectInsets) - für Blizzard-Fenster
function U.Rect(f, clickArea)
    if not (f and f.GetRect) then return nil end
    local ok, l, b, w, h = pcall(f.GetRect, f)
    if not ok or not l or not w or w <= 0 or h <= 0 then return nil end
    if clickArea and f.GetHitRectInsets then
        local ok2, il, ir, it, ib = pcall(f.GetHitRectInsets, f)
        if ok2 and type(il) == "number" then
            l, w = l + il, w - il - (ir or 0)
            b, h = b + (ib or 0), h - (it or 0) - (ib or 0)
            if w <= 0 or h <= 0 then return nil end
        end
    end
    local s = f.GetEffectiveScale and f:GetEffectiveScale() or 1
    return { l = l * s, b = b * s, r = (l + w) * s, t = (b + h) * s }
end

-- Fläche der Überschneidung (0 = keine). Ein Pixel Rand gilt als "angedockt", nicht als Überlappen.
function U.Overlap(a, c)
    if not (a and c) then return 0 end
    local w = math.min(a.r, c.r) - math.max(a.l, c.l) - 1
    local h = math.min(a.t, c.t) - math.max(a.b, c.b) - 1
    return (w > 0 and h > 0) and w * h or 0
end

local function Shown(f) return f and f.IsVisible and f:IsVisible() end

-- Name für den Bericht; ohne Namen und Text: Tooltip-Anfang bzw. Rahmenname des nächsten benannten Elternteils
-- (Befund 20:15 B3: "'X' verdeckt ''" war nicht zu finden)
local function Name(f)
    local n = f and f.GetName and f:GetName()
    if n then return n end
    local t = f and f.GetText and f:GetText()
    if t and t ~= "" then return "'" .. tostring(t) .. "'" end
    -- R3 (Nachprüfung Punkt 7): Text der Schrift im Knopf (eigene Knöpfe haben ein Label) und die Lage im Fenster
    local lbl = f and (f.label or f.text or f.Text)
    local lt = lbl and lbl.GetText and lbl:GetText()
    if lt and lt ~= "" then
        local ok, x, y = pcall(function() return math.floor(f:GetLeft() or 0), math.floor(f:GetTop() or 0) end)
        return "'" .. tostring(lt):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "") .. "'" .. (ok and string.format(" bei %d/%d", x, y) or "")
    end
    local tip = f and type(f.tooltip) == "string" and f.tooltip
    if tip and tip ~= "" then return "'" .. tip:gsub("\n.*", ""):sub(1, 30) .. "…'" end
    local kind = tostring(f and f.GetObjectType and f:GetObjectType() or "?")
    local p = f and f.GetParent and f:GetParent()
    while p do
        local pn = p.GetName and p:GetName()
        if pn then return kind .. " in " .. pn end
        p = p.GetParent and p:GetParent()
    end
    return kind
end

-- alle sichtbaren Nachfahren eines Fensters
function U.Descendants(f, out)
    out = out or {}
    if not (f and f.GetChildren) then return out end
    for _, c in ipairs({ f:GetChildren() }) do
        if Shown(c) then out[#out + 1] = c; U.Descendants(c, out) end
    end
    return out
end

local function IsControl(f)
    return f.IsObjectType and (f:IsObjectType("Button") or f:IsObjectType("EditBox") or f:IsObjectType("CheckButton")
        or f:IsObjectType("Slider")) and true or false
end

-- O2 (Befund Optionen überlagert): in einem Fenster überschneiden sich keine zwei Knöpfe/Eingabefelder und keine zwei
-- Beschriftungen der Optionszeilen (w.optionLabels). Rückgabe: Probleme, Zahl der geprüften Paare.
function U.ControlsOverlapNothing(win)
    local problems, tested = {}, 0
    if not Shown(win) then return problems, 0 end
    local items = {}
    local wr = U.Rect(win)
    local wArea = wr and (wr.r - wr.l) * (wr.t - wr.b) or 0
    for _, c in ipairs(U.Descendants(win)) do
        if IsControl(c) then
            -- grossflächige Hintergrund-Knöpfe (Ziehen, Klick-Fänger) sind keine Zeilen-Elemente
            local r = U.Rect(c)
            local big = r and wArea > 0 and (r.r - r.l) * (r.t - r.b) > wArea * 0.25
            if not big then items[#items + 1] = c end
        end
    end
    for _, l in ipairs(win.optionLabels or {}) do if Shown(l) then items[#items + 1] = l end end
    local rects = {}
    for i, it in ipairs(items) do rects[i] = U.Rect(it) end
    -- Lage nicht messbar (Nachbau ohne Anker-Rechnung: fast alle Elemente auf derselben Stelle) -> nicht prüfen
    local same, first = 0, rects[1]
    for _, r in ipairs(rects) do if first and r and r.l == first.l and r.t == first.t then same = same + 1 end end
    if #items > 4 and same > #items / 2 then return problems, 0 end
    for i = 1, #items do
        for j = i + 1, #items do
            local a, b = items[i], items[j]
            -- ein Knopf in einem anderen Knopf (z. B. Zeilen einer Tabelle) ist kein Überlagern
            local nested = (a.GetParent and a:GetParent() == b) or (b.GetParent and b:GetParent() == a)
            if rects[i] and rects[j] and not nested then
                tested = tested + 1
                if U.Overlap(rects[i], rects[j]) > 0 then
                    problems[#problems + 1] = Name(a) .. " überlagert " .. Name(b)
                end
            end
        end
    end
    return problems, tested
end

-- T191: kein eigener Tooltip verdeckt einen Knopf desselben Fensters
function U.TooltipsCoverNothing()
    local problems, tested = {}, 0
    for _, e in ipairs(ns.uiFrames) do
        if Shown(e.frame) then
            local all = U.Descendants(e.frame)
            for _, el in ipairs(all) do
                local enter = el.GetScript and el:GetScript("OnEnter")
                if enter then
                    tested = tested + 1
                    pcall(enter, el)
                    local tip = Shown(GameTooltip) and U.Rect(GameTooltip)
                    if tip then
                        for _, other in ipairs(all) do
                            if other ~= el and IsControl(other) and U.Overlap(tip, U.Rect(other)) > 0 then
                                problems[#problems + 1] = Name(el) .. " verdeckt " .. Name(other)
                                break
                            end
                        end
                    end
                    local leave = el:GetScript("OnLeave")
                    if leave then pcall(leave, el) end
                    if GameTooltip.Hide then GameTooltip:Hide() end
                end
            end
        end
    end
    return problems, tested
end

-- T192: eigene sichtbare Fenster überdecken weder Blizzard-Fenster noch Fenster anderer GoldSentinel-Addons
-- Fenster der Prüfung selbst (Ergebnis der Testroutine/des Selbsttests) zählen nicht (Befund 20:15 C3)
local TEST_WINDOWS = { AHAnalyzerProSelfTest = true, GoldSentinelTestFrame = true }
local function IsTestWindow(f)
    local n = f and f.GetName and f:GetName()
    return n ~= nil and TEST_WINDOWS[n] == true
end
U.IsTestWindow = IsTestWindow

-- Befund 22:25 2d: Ein vom Spieler hingeschobenes Fenster ist kein Fehler des Addons (nur Hinweis). Geprüft wird die
-- Stelle, an die AHSentinel sein Fenster SELBST setzt.
local function UserMoved(f)
    if A.UI and f == A.UI.frame then return A.db and A.db.settings and A.db.settings.windowPos ~= nil end
    if f.userMoved then return true end
    local ok, v = pcall(function() return f.IsUserPlaced and f:IsUserPlaced() end)
    return ok and v and true or false
end
-- unsichtbar (Alpha 0, z. B. ein leerer Anker) zählt nicht als Überdeckung
local function Visible(f)
    if not Shown(f) then return false end
    local ok, a = pcall(function() return f.GetEffectiveAlpha and f:GetEffectiveAlpha() or 1 end)
    return not ok or type(a) ~= "number" or a > 0.01
end

-- R4 (Befund 0.65.65): leerer Rahmen (ohne sichtbare Textur/Schrift, auch in den direkten Kindern) - z. B. ein Anker
-- eines anderen Addons. Überdeckung damit ist nur ein Hinweis.
local function Empty(f, depth)
    depth = depth or 0
    local ok, res = pcall(function()
        for _, r in ipairs({ f:GetRegions() }) do
            if r.IsShown and r:IsShown() then
                local t = r.GetObjectType and r:GetObjectType()
                if t == "FontString" then
                    local txt = r:GetText()
                    if txt and txt ~= "" then return false end
                elseif t == "Texture" then
                    local a = r.GetAlpha and r:GetAlpha() or 1
                    local tex = r.GetTexture and r:GetTexture()
                    if a > 0.01 and tex then return false end
                end
            end
        end
        if depth < 2 and f.GetChildren then
            for _, c in ipairs({ f:GetChildren() }) do
                if c.IsShown and c:IsShown() and not Empty(c, depth + 1) then return false end
            end
        end
        return true
    end)
    return ok and res or false
end
U.Empty = Empty

function U.WindowsOverlapNothing()
    local problems, tested, hints = {}, 0, {}
    for _, e in ipairs(ns.uiFrames) do
        local mine = Shown(e.frame) and not IsTestWindow(e.frame) and U.Rect(e.frame)
        local list = UserMoved(e.frame) and hints or problems
        local suffix = UserMoved(e.frame) and " (vom Spieler verschoben)" or ""
        if mine then
            for _, bn in ipairs(ns.UI_BLIZZARD) do
                local bf = _G[bn]
                -- Hauptfenster im Auktionshaus (Einbindung an): liegt absichtlich über dem Blizzard-AH
                local integrated = e.frame == (A.UI and A.UI.frame) and (bn == "AuctionHouseFrame" or bn == "AuctionFrame")
                    and A.UI.CanIntegrate and A.UI:CanIntegrate()
                if Shown(bf) and not integrated then
                    tested = tested + 1
                    if U.Overlap(mine, U.Rect(bf, true)) > 0 then list[#list + 1] = e.name .. " überdeckt " .. bn .. suffix end
                end
            end
            for _, o in ipairs(GoldSentinelUIFrames) do
                if o.addon ~= ADDON and Visible(o.frame) and not IsTestWindow(o.frame) then
                    tested = tested + 1
                    if U.Overlap(mine, U.Rect(o.frame)) > 0 then
                        local empty = Empty(o.frame)
                        local target = empty and hints or list
                        target[#target + 1] = e.name .. " überdeckt " .. o.name .. " (" .. o.addon .. ")" .. suffix
                            .. (empty and " (leerer Rahmen)" or "")
                    end
                end
            end
        end
    end
    return problems, tested, hints
end

-- T193: sichtbare Fenster liegen ganz im Bildschirm
function U.InsideScreen()
    local problems, tested, screen = {}, 0, U.Rect(UIParent)
    for _, e in ipairs(ns.uiFrames) do
        local r = Shown(e.frame) and U.Rect(e.frame)
        if r and screen then
            tested = tested + 1
            if r.l < screen.l - 1 or r.b < screen.b - 1 or r.r > screen.r + 1 or r.t > screen.t + 1 then
                problems[#problems + 1] = e.name .. " ragt aus dem Bildschirm"
            end
        end
    end
    return problems, tested
end

-- T194: Beschriftungen von Knöpfen sind nicht abgeschnitten (andere Texte nur als Hinweis)
function U.TextFits()
    local problems, hints, tested = {}, {}, 0
    for _, e in ipairs(ns.uiFrames) do
        if Shown(e.frame) then
            for _, el in ipairs(U.Descendants(e.frame)) do
                local fs = el.GetFontString and el:GetFontString()
                if fs and fs.IsTruncated then
                    tested = tested + 1
                    if fs:IsTruncated() then problems[#problems + 1] = Name(el) .. " Beschriftung abgeschnitten" end
                end
                for _, region in ipairs(el.GetRegions and { el:GetRegions() } or {}) do
                    if region.IsObjectType and region:IsObjectType("FontString") and region.IsTruncated and Shown(region) then
                        tested = tested + 1
                        if region:IsTruncated() then hints[#hints + 1] = Name(el) .. ": Text gekürzt" end
                    end
                end
            end
        end
    end
    return problems, tested, hints
end

-- T195: angezeigte Spielwerte plausibel (Prüfungen meldet das Addon mit A.Plausible an)
function U.ValuesPlausible()
    local problems = {}
    for _, p in ipairs(ns.plausible) do
        local ok, good, got, want = pcall(p.fn)
        if not ok then problems[#problems + 1] = p.name .. ": Lua-Fehler " .. tostring(good)
        elseif good == false then problems[#problems + 1] = p.name .. ": " .. tostring(got) .. " (erwartet " .. tostring(want) .. ")" end
    end
    return problems, #ns.plausible
end

-- T196: keine Fehlerschleife – dieselbe Meldung höchstens UI_LOOP_LIMIT× (Diagnose-Protokoll der echten Daten)
function U.NoErrorLoops()
    local problems = {}
    local db = A.db
    local entries = db and db.diag and db.diag.entries or {}
    for _, en in ipairs(entries) do
        if en.k == "FEHLER" and (en.n or 1) > ns.UI_LOOP_LIMIT then
            problems[#problems + 1] = (en.n or 1) .. "× " .. tostring(en.t)
        end
    end
    return problems, #entries
end

-- ------------------------------------------------------------
-- Spielwerte, die AHSentinel anzeigt (T195)
-- ------------------------------------------------------------
local function IsSecret(v)
    local G = _G.GoldSentinelGame
    return G and G.IsSecret and G.IsSecret(v) or false
end

ns.Plausible("Stufe des Charakters", function()
    local lvl = UnitLevel and UnitLevel("player")
    if type(lvl) ~= "number" or IsSecret(lvl) then return true, "nicht lesbar" end
    return lvl >= 1 and lvl <= 100, lvl, "1–100"
end)

ns.Plausible("Gold (Anzeige = GetMoney)", function()
    local m = GetMoney and GetMoney()
    if type(m) ~= "number" or IsSecret(m) then return true, "nicht lesbar" end
    return m >= 0, m, ">= 0"
end)

-- Gewinn-Fenster: Zeile Einstellgebühr nur in WoW Forever (sonst kommt die Gebühr beim Verkauf zurück)
ns.Plausible("Gewinn-Fenster: Zeile Einstellgebühr nur in Forever", function()
    local Cr = A.Crafting
    local f = Cr and Cr.panel
    if not (f and f:IsShown() and f.deposit) then return true, "Gewinn-Fenster zu" end
    local fv = A:IsForever() and true or false
    return (f.deposit:IsShown() and true or false) == fv, f.deposit:IsShown() and "sichtbar" or "verborgen",
        fv and "sichtbar" or "verborgen"
end)

-- Gewinn-Fenster: Gewinn = Wert x 0,95 - Material - Einstellgebühr (gewähltes Rezept)
ns.Plausible("Gewinn-Fenster: Gewinn passt zu Wert, Material und Gebühr", function()
    local Cr = A.Crafting
    if not (Cr and Cr.panel and Cr.panel:IsShown() and Cr.kind and Cr.API and Cr.API[Cr.kind]) then return true, "Gewinn-Fenster zu" end
    local idx = Cr.API[Cr.kind].selected()
    local r = idx and Cr:ReadRecipe(Cr.kind, idx)
    if not (r and r.profit and r.net) then return true, "kein Rezept mit Preis gewählt" end
    local want = r.net - (r.deposit or 0) - r.cost
    return r.profit == want, r.profit, want
end)

-- Heute tun: "Unter Händlerpreis" nur mit Händlerpreis über dem Kaufpreis
ns.Plausible("Heute tun: Unter Händlerpreis nur mit Gewinn", function()
    if not A.VendorFlipOffers then return true, "fehlt" end
    local ok, list = pcall(A.VendorFlipOffers, A, 0, 10)
    if not ok then return false, tostring(list), "kein Lua-Fehler" end
    for _, d in ipairs(list) do
        if not (d.vendor and d.price and d.vendor > d.price) then return false, tostring(d.itemID), "Händlerpreis > Kaufpreis" end
    end
    return true, #list .. " Angebote"
end)
