-- AHSentinel - Suchindex (ptBR), aus Names_ptBR.lua erzeugt. Nicht von Hand ändern.
AHAnalyzerPro_NameSearch = AHAnalyzerPro_NameSearch or {}
AHAnalyzerPro_NameSearch["ptBR"] = [==[

25	espadim usado
35	cajado curvado
36	maca gasta
37	machado usado
38	camisa do recruta
39	calcas do recruta
40	botas do recruta
43	botas do escudeiro
44	calcas do escudeiro
45	camisa do escudeiro
47	sapatos do salteador
48	calcas do salteador
49	camisa do salteador
51	botas do neofito
52	calcas do neofito
53	camisa do neofito
55	botas do aprendiz
56	veste do aprendiz
57	veste do acolito
59	sapatos do acolito
60	tunica em camadas
61	calcas de couro enanicas
79	culotes enanicos de tecido
80	sapatos forrados de pelame macios
85	colete de couro sujo
117	carne seca dura
118	pocao menor de cura
120	calcas do capanga
121	botas do meliante
127	camisa do coureador
129	botas rusticas do coureador
139	calcas do brigao
140	botas do brigao
147	calcas grosseiras do coureador
148	camisa grosseira do coureador
153	kilt primitivo
154	poncho primitivo
159	agua refrescante da fonte
182	cabeca do garrick
193	colete de tecido esfarrapado
194	calcas de tecido esfarrapado
195	botas de tecido esfarrapado
200	colete de tecido grosso
201	calcas de tecido grosso
202	sapatos de tecido grosso
203	luvas de tecido grosso
209	calcas de couro sujas
210	botas de couro sujas
236	armadura de couro curado
237	calcas de couro curado
238	botas de couro curado
239	luvas de couro curado
285	colete de malha em escamas
286	calcas de malha em escamas
287	botas de malha em escamas
414	queijo azedo de dalaran
422	queijo enanico suave
537	escama cega de farnesim
555	penas asperas de abutre
556	bico de urubu
647	destino
710	bracadeiras da milicia do povo
711	luvas de tecido esfarrapado
714	luvas de couro sujas
718	luvas de malha em escamas
719	luvas do tratador de coelhos
720	luvas do brigao
723	figado de goretusco
724	empadao de figado de goretusco
725	pata de gnoll
727	espada curta chanfrada
728	receita ensopado de cerro oeste
729	acem de abutre
730	olho de murloc
731	focinho de goretusco
732	quiabo
733	ensopado de cerro oeste
735	medalhoes de rodolfo e malaquias
737	agua da fonte abencoada
738	saco de cevada
739	saco de milho
740	saco de centeio
742	um galho de platano
743	bracada de carvalho calcinado
744	frasco de bota do cervaforte
745	documentos do major belmonte
748	vale armadura de ventobravo
750	carne dura de lobo
752	bandana de lona vermelha
753	espada curta presa do dragao
754	espada curta da vinganca
755	vela derretida
756	picareta de tunel
763	bracadeiras cobertas de gelo
765	folha prata
766	maca bordejada
767	cajado bo longo
768	machado de lenhador
769	naco de carne de javali
770	dente pontudo de crocolisco
771	presa lascada de javali
772	vela grande
773	po de ouro
774	malaquita
776	vendeta
777	dentes de lobo tocaieiro
778	picareta de escavacao kobold
779	concha brilhante
780	barbatana rasgada de murloc
781	martelo de pedra dos gnolls
782	bracadeiras pintadas dos gnolls
783	pelego leve
785	magi real
787	cavala deslizapele
789	martelo de batalha corpulento
790	machado do mateiro
791	cajado fraxineo nodoso
792	sandalias tricotadas
793	luvas tricotadas
794	calcas tricotadas
795	tunica tricotada
796	botas de couro aspero
797	luvas de couro aspero
798	calcas de couro grosseiro
799	vestimenta de couro aspero
804	saco azul grande
805	bolsa vermelha pequena
809	navalha sangrenta
810	martelo do vento do norte
811	machado das matas profundas
812	cajado faiscante do bosque brilhante
813	engrenagem quebrada
814	frasco de oleo
816	faquinha de combate
818	olho de tigre
820	lamina fatiadora
821	colete de couro dos pata molhada
826	machado embrutecido dos pata molhada
827	cassetete malvado
828	bolsa azul pequena
829	bandana vermelha de couro
832	cinto prateado dos defias
833	pedra vital
835	rede grande de corda
837	armadura de trama pesada
838	calcas de trama pesada
839	luvas de trama pesada
840	sapatos de trama pesada
841	relogio de bolso do taturana
843	botas de couro curtido
844	luvas de couro curtido
845	calcas de couro curtido
846	gibao de couro curtido
847	armadura de malha de aneis
848	calcas de malha de aneis
849	botas de malha de aneis
850	luvas de malha de aneis
851	alfanje
852	maca
853	machadinha
854	cajado de combate
856	bolsa de couro azul
857	saco vermelho grande
858	pocao inferior de cura
859	camisa de tecido de qualidade
860	botas do fidalgo
862	anel runico
863	semeia pranto
864	espada longa cavaleiresca
865	maca de chumbo
866	cajado do monge
867	luvas do poder sagrado
868	protetor ardente
869	espada longa ofuscante
870	machado de guerra abrasador
871	machado de rajadas
872	corta pedra
873	cajado de jardel
875	evocacao de cavalo castanho
876	broquel de madeira usado
878	fiandeira do tamanho da mao
880	cajado dos horrores
884	costela de carnical
885	machado de metal preto
886	espada curta de metal preto
887	quilo de carne
888	luvas nagas de batalha
889	carta nao enviada e empoeirada
890	cajado do chantre retorcido
892	luvas misticas de gnoll
893	presa de lobo hediondo
895	cranio de worgen
896	presa de worgen
897	bracadeiras do lobo enfurecido
899	presa de teia peconhenta
901	deptecated white stallion summoning mount
910	carta nao entregue
911	galho de pau ferro
913	espada ogra enorme
914	armadura ogra grande encadeada
915	bandana de seda vermelha
916	pagina de diario rasgada
918	mochila de pelego anormal
920	maca farpada perversa
921	pagina de diario esmaecida
922	falx dacia
923	espada longa
924	malho
925	mangual
926	machado de batalha
927	machado duplo
928	cajado longo
929	pocao de cura
932	alforje do corcel vil
933	mochilao de amarrar
934	foice do galvao
935	espada curta da vigilia noturna
936	maca da meia noite
937	cajado preto de madeirumbra
938	paginas de diario enlameadas
939	pagina de diario manchada de sangue
940	vestes da perspicacia
942	elo congelante
943	cajado guardiao
944	cajado elemental do mago
945	espada sombria
948	espada da natureza
954	pergaminho de forca
955	pergaminho do intelecto
957	carregamento do guilherme
961	erva curativa
962	torta de barriga de porco
966	tomo do escudo gelido
967	tomo de protecao contra gelo
968	tomo de impacto de fogo
973	tomo de bola de fogo ii
974	tomo de armadura gelida ii
975	tomo de correntes de gelo
976	tomo de remover maldicao
980	tomo do escudo gelido ii
981	colar de berenice
983	faixa de linho vermelho
985	tomo de destravamento de hadggar
986	tomo de seta de gelo ii
989	tomo de nova congelante
992	tomo de bola de fogo iii
994	tomo de armadura de gelo
997	espada de fogo debilitante
1002	tomo inferior de invisibilidade
1004	tomo de correntes de gelo ii
1006	colar de latao
1008	espada muito usada
1009	martelo compacto
1010	cajado curto nodoso
1011	machado afiado
1013	rebite de ferro
1015	lombo de lobo magro
1017	kebab temperado de lobo
1019	bandana de linho vermelha
1029	tabuleta de totem serpente
1030	tabuleta da vontade obstinada
1031	tabuleta de impacto derretido
1032	tabuleta de totem agitador
1033	tabuleta de anular veneno
1034	tabuleta da forca imortal
1035	tabuleta de invocar espirito
1036	tabuleta de anular doenca
1037	tabuleta de raio ii
1038	tabuleta de restauracao ii
1041	trompa do lobo preto
1048	tabuleta de escudo de raios ii
1049	tabuleta de expurgar
1052	tabuleta de armadura espiritual ii
1053	tabuleta de impacto derretido ii
1057	tabuleta de restauracao iii
1058	tabuleta de raio iii
1061	tabuleta de anular veneno ii
1063	tabuleta de anular doenca ii
1072	pinga cara cheia
1074	ponta dura de perna de aranha
1075	pingente umbrapele
1076	anel de renegado defias
1077	anel de mago defias
1080	carne dura de condor
1081	carne crocante de aranha
1082	gulache de cristarrubra
1083	glifo de azora
1084	codice de renovar
1085	codice de visao da mente
1086	codice de fogo interior
1087	codice de palavra sombria dor
1088	codice de renovar ii
1089	codice de anular doenca
1090	codice de ressurreicao
1091	codice de punicao sagrada ii
1092	codice de cura inferior ii
1093	codice de remover maldicao
1095	codice de dissipar magia
1096	codice de palavra sombria dor ii
1100	codice de punicao sagrada iii
1101	codice de renovar v
1102	codice de cura inferior iii
1105	codice de renovar vi
1108	codice de renovar iii
1109	codice de dominar
1111	codice de sono
1112	codice de palavra sagrada fortitude ii
1113	pao conjurado
1114	pao de centeio conjurado
1116	anel de prata pura
1119	garrafa de destilado
1121	pes do lince
1127	saco de chamas
1129	presa de carnical
1130	ampola de peconha de aranha
1131	totem do castigo
1132	trompa do lobo silvestre
1133	trompa do lobo hibernal
1134	trompa do lobo cinza
1136	incunabulo favorecimento divino ii
1138	incunabulo favorecimento divino
1139	incunabulo purificacao
1141	incunabulo luz sagrada ii
1144	incunabulo escudo divino
1146	incunabulo ressurreicao
1149	incunabulo selo do poder ii
1150	incunabulo purificar
1151	incunabulo luz sagrada iii
1154	cinto da milicia do povo
1155	bastao do sonambulo
1156	anel carregado de gemas
1158	porrete de metal macico
1159	cajado de milicia
1161	espada curta de milicia
1164	tomo de sam
1166	broquel amassado
1167	tarja pequena
1168	escudo do cranio flamejante
1169	escudo cranionegro
1171	veste bem costurada
1172	tocha do calvino
1173	botas gastas
1175	um dente de ouro
1176	sais aromaticos
1177	oleo de olaf
1178	foguete explosivo
1179	leite gelado
1180	pergaminho do vigor
1181	pergaminho do espirito
1182	bracadeiras com cravos de latao
1183	munhequeiras elasticas
1187	coleira farpada
1189	anel do feitor
1190	manto do feitor
1191	saco de bolas de gude
1193	broquel estriado
1194	espada bastarda
1195	pa de mineracao kobold
1196	tabar
1197	maca gigante
1198	espadao
1199	pedra da alma carregada
1200	escudo grande de madeira
1201	escudo brasonado simples
1202	muralha de protecao
1203	egide de ventobravo
1204	a torre verde
1205	suco de melao
1206	agata musgosa
1207	maca massa
1208	carta de amor de mabel
1210	tenebrita
1211	arnes gnoll de guerra
1212	saliva de gnoll
1213	bracadeiras gnoll gemeas
1214	castigador gnoll
1215	cinturao de suporte
1216	bracadeiras gelidas
1217	recompensa desconhecida
1218	clava de guerra gnoll pesada
1219	facao de cristarrubra
1220	machado lupino
1221	escama de ventre de dragonete
1222	dente quebrado
1224	grimorio de detectar demonios
1228	grimorio de sangue fervente
1229	grimorio de criar pedra da alma
1231	grimorio de seta sombria ii
1232	grimorio de pele de demonio ii
1238	grimorio de medo
1239	grimorio de sugar mana
1243	grimorio de seta sombria iii
1244	grimorio de armadura demoniaca
1245	grimorio de imolacao ii
1246	grimorio de bafo demoniaco
1250	grimorio de detectar invisibilidade inferior
1251	bandagem de linho
1252	bilhete da vo campedra
1254	pedra de fogo inferior
1256	folha de cristalga
1257	elixir de invisibilidade
1259	jyoo test item
1260	cabeca do tharil zun
1261	orbe da meia noite
1262	barrilete de cervaforte
1263	talha mentes
1264	afunda cucas
1265	picada do escorpiao
1270	manto finamente tecido
1273	corrente florestal
1274	lupulo
1275	cota encadeada do adjunto
1276	broquel endurecido pelo fogo
1280	manto com capuz
1282	coifa brilho metalico
1283	bilhete de vervo
1284	caixote de ferraduras
1287	presa de tarantula gigante
1288	vesicula de peconha grande
1292	cutelo do acougueiro
1293	a situacao de lago placido
1294	a resposta do general
1296	maca de rocha negra
1297	vestes do lanca sombras
1299	cinto inferior da torre
1300	cajado inferior da torre
1302	luvas de dragonete negro
1303	luvas de operario da ponte
1304	luvas de montaria
1306	munhequeiras lupogrenha
1307	agenda de coleta de ouro
1309	caixa de ferramentas do oslow
1310	calcas de ferreiro
1314	dedos de carnical
1315	colar de lirios
1317	cajado de raiz densa
1318	aniquilador noturno
1319	anel de vontade ferrea
1322	oleo de figado de peixe
1325	buque de narcisos
1326	peixe lua refogado
1327	bilhete do wiley
1328	livro de fogo feerico
1332	livro de curar veneno
1334	livro de rejuvenescimento ii
1339	livro de raizes enredantes
1341	livro de fogo lunar
1349	caixote do abercrombie
1351	bracadeiras osso de dedo
1352	morteiro do cranio partido
1353	relatorio do shaw
1355	capa de camurca
1356	comenda – floresta de elwynn
1357	mapa do tesouro do capitao albernaz
1358	pista para o tesouro do albernaz
1359	luvas com selo leonino
1360	luvas encadeadas de ventobravo
1361	outra pista para o tesouro do albernaz
1362	pista final para o tesouro do albernaz
1364	colete de couro roto
1366	calcas de couro roto
1367	botas de couro roto
1368	luvas de couro roto
1369	cinto de couro roto
1370	bracadeiras de couro roto
1372	manto roto
1374	sapatos puidos
1376	manto puido
1377	luvas puidas
1378	calcas puidas
1380	veste puida
1381	uma mensagem misteriosa
1382	maca de rocha
1383	machadinha aborigene
1384	lamina cega
1386	machado de pau cardo
1387	presa de carnical
1388	cajado torto
1389	marreta de mineracao kobold
1391	cajado de mistico pata molhada
1394	clava de madeira flutuante
1395	calcas do aprendiz
1396	calcas do acolito
1399	vela magica
1400	ficha de penaveloz
1401	folha de cha verde
1402	sulfur
1404	patua das mares
1405	cajado cospe espuma
1406	lanca incrustada de perolas
1407	apelo de salomao a cerro oeste
1408	resposta de mantoforte a salomao
1409	apelo de salomao a vila sombria
1410	resposta de ebonlocke a salomao
1411	cajado ressequido
1412	espada bastarda grosseira
1413	espada debil
1414	marreta rachada
1415	marreta de carpinteiro
1416	machadinha enferrujada
1417	machado de batalha gasto
1418	cinto de couro desgastado
1419	botas de couro desgastado
1420	bracadeiras de couro desgastado
1421	manto de pelego desgastado
1422	luvas de couro desgastado
1423	calcas de couro desgastado
1425	colete de couro desgastado
1427	sapatos de retalhos
1429	manto de retalhos
1430	luvas de retalhos
1431	calcas de retalhos
1433	armadura de retalhos
1434	palito de cera faiscante
1436	culotes da fronteira
1438	escudo do guerreiro
1440	esmaga cranio gnoll
1443	amuleto incrustado de cainwyn
1445	brafoneiras de rocha negra
1446	botas de rocha negra
1447	anel dos salvadores
1448	manoplas de rocha negra
1449	anel de canalizacao menor
1450	pocao de fervor
1451	garrafa de suco de zumbi
1453	pente espectral
1454	machado do impositor
1455	machado do campeao de rocha negra
1457	maca umbrapele
1458	malho umbrapele
1459	escalpelador umbrapele
1460	espada de duas maos umbrapele
1461	machado de batalha do matador
1462	anel das sombras
1464	garra de urubu
1465	tigrazar
1467	peixe lua malhado
1468	barbatana de murloc
1469	cimitarra de aton
1470	bolsa de pele de murloc
1473	cajado da ribeira
1475	vesicula pequena de peconha
1476	perna quebrada de aranha
1477	pergaminho de agilidade ii
1478	pergaminho de protecao ii
1479	luvas termicas da salma
1480	punho da milicia do povo
1481	garratroz
1482	presa negra
1483	catxau
1484	baculo de bruxaria
1485	forcado
1486	jaqueta de casca de arvore
1487	pao preto conjurado
1488	armadura do vingador
1489	armadura tristeveu
1490	talisma do guardiao
1491	anel da precisao
1493	cimitarra espoliadora pesada
1495	sapatos de calico
1497	manto de calico
1498	luvas de calico
1499	calcas de calico
1501	tunica de calico
1502	cinto de couro deformado
1503	botas de couro deformado
1504	bracadeiras de couro deformado
1505	manto deformado
1506	luvas de couro deformado
1507	calcas de couro deformado
1509	colete de couro deformado
1510	martelo pesado
1511	espada do plebeu
1512	machado de batalha grosseiro
1513	montante velha
1514	martelo de guerra enferrujado
1515	cajado rustico de madeira
1516	machadinha desgastada
1518	pente de fantasma
1519	orelha de sanguescalpo
1520	suor de troll
1521	machado de lenhador do ogro
1522	lanca do cacador de cabecas
1523	grande clava de pedra
1524	presa rachacranio
1528	punhado de aveia
1529	jade
1532	cabeca encolhida
1534	incunabulo luz sagrada iv
1536	incunabulo selo da ira
1537	comedouro da velha brancurinha
1539	cajado nodoso do eremita
1547	escudo da fe
1554	tomo de seta de gelo iii
1557	broquel dos mares
1559	tomo de misseis arcanos ii
1560	sandalias dos guelrazul
1561	veste do ceifador
1566	gume da milicia do povo
1567	tomo de destravamento de hadggar ii
1568	tomo de elemental da agua
1571	tomo de nova congelante ii
1574	tomo de protecao contra fogo
1588	tabuleta de impacto derretido iii
1589	tabuleta de armadura espiritual iii
1591	tabuleta de escudo de raios iii
1596	linha de cabelo de fantasma
1597	tabuleta de tempestade de raios
1598	flores do mal
1602	machado foice
1603	tabuleta de invocar espirito ii
1604	espada cromatica
1607	devoralmas
1608	maca quebra cranios
1613	cajado caca fantasmas
1619	tabuleta de tempestade de raios ii
1623	bolsa de pele de raptor
1624	elmo rachacranio
1625	flamberge excelente
1630	eletrolanterna quebrada
1637	carta para malaquias
1639	machado sarcastico
1640	machado de guerra monstruoso
1641	codice de palavra sombria dor iii
1645	suco de lunamora
1648	codice de cura iv
1651	codice de palavra sagrada escudo vi
1652	lancheira robusta
1656	carta traduzida
1657	codice de ressurreicao ii
1658	codice de palavra sombria dor iv
1659	luvas de engenharia
1664	bastao da forca mistica
1676	codice de sono ii
1677	colete de escama de draco
1678	pisantes pretos de ogro
1679	bastao korg
1680	cortacabecas
1681	grimorio de aleijar
1685	bolsa de couro de troll
1686	pelo de bigode cerdoso
1687	garra retratil
1688	longa cauda macia
1696	garra curva de raptor
1697	dente afiado de raptor
1701	garra curva de basilisco
1702	espinha intacta de basilisco
1703	costela de basilisco de cristal
1705	pedra da lua inferior
1706	estilhacos azul profundo
1707	brie de ventobravo
1708	nectar doce
1710	pocao maior de cura
1711	pergaminho do vigor ii
1712	pergaminho do espirito ii
1713	ankh da vida
1714	colar de calissea
1715	armadura jazerina polida
1716	veste dos magos
1717	tunica de malha dupla
1718	calcas de pelego de basilisco
1720	cajado de madeira emaranhada
1721	martelo de guerra viquingue
1722	marrao petracardo
1725	mochila grande
1726	lanca de osso de ponta venenosa
1727	espada da decomposicao
1728	espada longa fulgurante do teebu
1729	saco de aniagem da vigilia noturna
1730	cinto de malha desgastado
1731	botas de malha desgastadas
1732	bracadeiras de malha desgastadas
1733	manto desgastado
1734	luvas de malha desgastadas
1735	calcas de malha desgastadas
1737	colete de malha desgastado
1738	cinto de malha com rendas
1739	botas de malha com rendas
1740	bracadeiras de malha com rendas
1741	manto com rendas
1742	luvas de malha com rendas
1743	calcas de malha com rendas
1744	ombreiras de malha com rendas
1745	colete de malha com rendas
1746	cinto de malha articulada
1747	botas de malha articulada
1748	bracadeiras de malha articulada
1749	manto de malha articulada
1750	luvas de malha articulada
1751	calcas de malha articulada
1752	ombreiras de malha articulada
1753	colete de malha articulada
1754	cinto encadeado reforcado
1755	botas encadeadas reforcadas
1756	bracadeiras encadeadas reforcadas
1757	manto encadeado reforcado
1758	luvas encadeadas reforcadas
1759	calcas encadeadas reforcadas
1760	ombreiras encadeadas reforcadas
1761	colete encadeado reforcado
1764	sapatos de lona
1766	manto de lona
1767	luvas de lona
1768	calcas de lona
1769	ombreiras de lona
1770	colete de lona
1772	sapatos brocados
1774	manto brocado
1775	luvas brocadas
1776	calcas brocadas
1777	ombreiras brocadas
1778	colete brocado
1780	sandalias em ponto de cruz
1782	manto em ponto de cruz
1783	luvas em ponto de cruz
1784	calcas em ponto de cruz
1785	ombreiras em ponto de cruz
1786	colete em ponto de cruz
1787	cinto de couro remendado
1788	botas de couro remendadas
1789	bracadeiras de couro remendadas
1790	manto remendado
1791	luvas de couro remendadas
1792	calcas de couro remendadas
1793	ombreiras de couro remendadas
1794	gibao de couro remendado
1795	cinto de couro cru
1796	botas de couro cru
1797	bracadeiras de couro cru
1798	manto de couro cru
1799	luvas de couro cru
1800	calcas de couro cru
1801	ombreiras de couro cru
1802	tunica de couro cru
1803	cinto de couro resistente
1804	botas de couro resistente
1805	bracadeiras de couro resistente
1806	manto resistente
1807	luvas de couro resistente
1808	calcas de couro resistente
1809	ombreiras de couro resistente
1810	armadura de couro resistente
1811	espadao cego
1812	machado de batalha de cabo curto
1813	bastao lascado
1814	marreta desgastada
1815	maca ornamentada
1816	machado desequilibrado
1817	espada curta comum
1818	espadao padrao
1819	picareta de mutilacao
1820	malho de madeira
1821	lamina deformada
1822	bengala de cedro
1823	porrete contundente
1824	machado de guerra brilhante
1825	marreta grotesca
1826	malho de rocha
1827	cutelo de carne
1828	machado de guerra de pedra
1829	alfanje curto
1830	espada bastarda longa
1831	cajado de guerra de carvalho
1832	calcas da sorte
1835	cinto de couro sujo
1836	bracadeiras de couro sujas
1839	cinto de couro aspero
1840	bracadeiras de couro grosseiro
1843	cinto de couro curtido
1844	bracadeiras de couro curtido
1845	cinto de malha de aneis
1846	bracadeiras de malha de aneis
1849	cinto de couro curado
1850	bracadeiras de couro curado
1851	agua purificante
1852	bracadeiras de malha de escamas
1853	cinto de malha de escamas
1875	distintivo de cardurtiga
1877	livro de rejuvenescimento iii
1882	livro de fogo lunar iii
1886	livro de fogo lunar ii
1893	revanche do minerador
1894	carteira do sindicato dos mineradores
1913	cassetete com pontas
1917	adaga ornamentada
1922	suprimentos para noel
1923	algibeira do embaixador
1925	florete defias
1926	maca gravosa
1927	cutelo de minas mortas
1928	cajado de mago defias
1929	calcotes cerzidos com seda
1930	manto do alvanel
1931	enorme garra de gnoll
1933	cajado de conjuracao
1934	calcotes do alvanel
1935	lamina do assassino
1936	chave de fenda goblin
1937	vibrasserra
1938	marreta de cepo
1939	odre de rum doce
1941	barril de vinho merlot
1942	garrafa de pinga
1943	perneiras de malha goblinicas
1944	luvas de metalurgia
1945	luvas do madeireiro
1946	espelho de maria
1951	alfanje aguanegra
1955	botas encadeadas presa do dragao
1956	pingente umbrapele esmaecido
1958	tibia petrificada
1959	picareta de ferro frio
1962	pingente umbrapele faiscante
1965	luvas do lobo branco
1968	monoculo do ogro
1970	balsamo restaurador
1971	escritura do taturana
1972	escritura de cerro oeste
1973	orbe do logro
1974	bracadeiras do impulso mental
1975	antiga montante de pysan
1976	tira da mira
1977	bolsa de 20 espacos
1978	luvas lupigarras
1979	muralha dos mortos
1980	elo do submundo
1981	gibao malha de gelo
1982	lamina soturna
1986	rasgatripa
1987	cacarola melhorada do krazek
1988	manoplas do brigadeiro chefe
1990	malho pesado
1991	pa movida a goblin
1992	fetiche palustre
1993	anel da mente do ogro
1994	aniquilador garra de ebano
1996	anel vodu
1997	veste de feltro prensado
1998	cajado de canalizador sanguescalpo
2000	arque
2004	diario de grolin barbabranca
2005	a primeira lenda troll
2006	a segunda lenda troll
2007	a terceira lenda troll
2008	a quarta lenda troll
2011	sabre retorcido
2013	cajado criptosseo
2014	montante de metal preto
2015	machado de guerra de metal preto
2016	armadura encadeada empoeirada
2017	bracadeiras de couro faiscante
2018	espada longa descarnada
2020	lamina da presa oca
2021	escudo de carapaca verde
2024	tarasca
2025	machado farpado
2026	martelo de rocha
2027	cimitarra
2028	martelo
2029	cutelo
2030	cajado nodoso
2032	manilhas gallan
2033	botas do embaixador
2034	vestes do erudito
2035	espada do ceu noturno
2036	luvas de mineracao empoeiradas
2037	botas do escavador
2039	anel das planicies
2040	guarda troll
2041	tunica do cerro oeste
2042	cajado do cerro oeste
2043	anel dos espiritos desamparados
2044	crescente dos espiritos desamparados
2046	kukri dos guelrazul
2047	machado pequeno de sidermar
2048	martelo de sidermar
2054	machadinha trogg
2055	martelinho de madeira
2056	o martelo de veludo
2057	espada curta escalavrada defias
2058	marreta do kazon
2059	manto da sentinela
2064	clava trogg
2065	lamina pedraqueixo
2066	machado de cranios
2067	cajado da bola de gelo
2069	colete de pelego de urso preto
2070	queijo roquefort darnassiano
2072	cajado enanico do mago
2073	machadinha enanica
2074	espadim macico
2075	maca do sacerdote
2077	cajado do magico
2078	espada curta do norte
2079	martelo de guerra do sargento
2080	machado montes
2082	saco de aniagem do lhogolho
2084	espada bastarda de trevaco
2085	naco de carne
2087	carapaca dura de rastejante
2088	perna longa de rastejante
2089	adaga do entalhador
2091	po magico
2092	punhal usado
2098	espingarda de cano duplo
2099	canhao de mao enanico
2100	cano de atirar precisamente calibrado
2101	aljava leve
2102	bornal pequeno para municao
2105	camisa do capanga
2108	colete de couro jubafria
2109	colete encadeado jubafria
2110	veste leve de magifice
2112	gibao do lenhador
2113	bilhete do petronio
2114	veste nevada
2117	sapatos de tecido fino
2119	luvas de tecido fino
2120	calcas de tecido fino
2121	armadura de tecido fino
2122	cinto de couro rachado
2123	botas de couro rachado
2124	bracadeiras de couro rachado
2125	luvas de couro rachado
2126	calcas de couro rachado
2127	vestimenta de couro rachado
2128	espadao arranhado
2129	escudo grande redondo
2130	clava
2131	espada curta
2132	cajado curto
2133	escudo pequeno
2134	machado pequeno
2136	agua purificada conjurada
2137	faca talhadora
2138	abridor de cartas afiado
2139	punhal
2140	faca de entalhar
2141	colete de couro cozido
2142	cinto de couro cozido
2143	botas de couro cozido
2144	bracadeiras de couro cozido
2145	luvas de couro cozido
2146	calcas de couro cozido
2148	cinto de escama polida
2149	botas de escama polida
2150	bracadeiras de escama polida
2151	luvas de escama polida
2152	perneiras de escama polida
2153	colete de escama polida
2154	a historia de morgan ladimore
2156	botas acolchoadas
2158	luvas acolchoadas
2159	calcas acolchoadas
2160	armadura acolchoada
2161	livro da fazenda de noel
2162	anel de sarah
2163	lamina das sombras
2164	ranca tripa
2165	cobertor da velha brancurinha
2166	perneiras do capataz
2167	luvas do capataz
2168	botas do encarregado
2169	lamina alarme
2172	cinto rustico
2173	cinto de couro velho
2175	machado de batalha umbrapele
2186	cinto do provedor
2187	uma pilha de cartas
2188	uma carta para grolin barbabranca
2194	martelo diamante
2195	faca de sidermar
2203	cutelo do garrafina
2204	espetinho do garrafina
2205	noctifera
2207	jambiya
2208	coto
2209	cris
2210	broquel desgastado
2211	escudo grande amassado
2212	broquel rachado
2213	escudo grande desgastado
2214	broquel de madeira
2215	escudo de madeira
2216	broquel simples
2217	escudo retangular
2218	adaga do artifice
2219	broquel pequeno
2220	escudo de tampa
2221	escudo tarja
2222	escudo torreao
2223	a escala do coletor
2224	adaga de milicia
2225	faca de cozinha afiada
2226	cajado do ogro mago
2227	machado de guerra ogrico pesado
2230	luvas da forca muscular
2231	veste infernal
2232	botas do corretreva
2233	perneiras tece sombras
2234	armadura do noctivago
2235	garramente
2236	presanegra
2237	calcas remendadas
2238	calcas do pivete
2239	o anel do coletor
2240	capa rustica
2241	capa de facinora
2243	mao de edward o excentrico
2244	lamina krol
2245	elmo de narv
2246	sinete do mirmidao
2249	broquel da milicia
2250	bolinhos de caranguejo crepuscular
2251	perna de aranha pegajosa
2252	suprimentos goblin sortidos
2254	martelo de cristal de gelo
2256	clava esqueletica
2257	cajado jubafria
2258	espada curta jubafria
2259	clava jubafria
2260	machadinha jubafria
2262	marca de kern
2263	fitolamina
2264	dragonas dos larapios
2265	machado dos lascapedra
2266	adaga dos lascapedra
2267	maca dos lascapedra
2268	lamina dos lascapedra
2271	cajado do vidente abencoado
2273	armadura de guerrilha
2274	luvas do sapador
2276	botas do andarilho do pantano
2277	perneiras do necromante
2278	palas do rastreador
2280	bengala do kam
2281	machado duro rodentia
2282	espada curta rodentia
2283	cinto de tecido de rato
2284	manto de tecido de rato
2287	pernil de carne
2288	agua doce conjurada
2289	pergaminho de forca ii
2290	pergaminho do intelecto ii
2291	kang o decapitador
2292	vestes da necrologia
2295	presa grande de javali
2296	focinho do grande goretusco
2299	machado de guerra incandescente
2300	colete de couro com relevo
2302	botas de couro feitas a mao
2303	calcas de couro feitas a mao
2304	kit de armadura leve
2307	botas de couro de qualidade
2308	manto de couro de qualidade
2309	botas de couro com relevo
2310	manto de couro com relevo
2311	gibao de couro branco
2312	luvas de couro de qualidade
2313	kit de armadura media
2314	armadura de couro resistente
2315	botas de couro escuro
2316	manto de couro escuro
2317	tunica de couro escuro
2318	couro leve
2319	couro medio
2320	fio grosso
2321	fio delicado
2324	alvejante
2325	pigmento preto
2326	bracadeiras de hera trancada
2327	bracadeiras de couro resistente
2361	martelo gasto em batalha
2362	escudo de madeira usado
2364	colete trancado
2366	calcas trancadas
2367	botas trancadas
2369	luvas trancadas
2370	arnes de couro surrado
2371	cinto de couro surrado
2372	calcas de couro surradas
2373	botas de couro surradas
2374	bracadeiras de couro surradas
2375	luvas de couro surradas
2376	escudo brasonado usado
2377	broquel redondo
2378	dedo descarnado
2379	vestimenta encadeada manchada
2380	cinto encadeado manchado
2381	perneiras encadeadas manchadas
2382	coracao do embalsamador
2383	botas encadeadas manchadas
2384	bracadeiras encadeadas manchadas
2385	luvas encadeadas manchadas
2386	colete encadeado enferrujado
2387	cinto encadeado enferrujado
2388	perneiras encadeadas enferrujadas
2389	botas encadeadas enferrujadas
2390	bracadeiras encadeadas enferrujadas
2391	luvas encadeadas enferrujadas
2392	armadura de malha leve
2393	cinto de malha leve
2394	perneiras de malha leve
2395	botas de malha leve
2396	bracadeiras de malha leve
2397	luvas de malha leve
2398	armadura encadeada leve
2399	cinto encadeado leve
2400	perneiras encadeadas leves
2401	botas encadeadas leves
2402	bracadeiras encadeadas leves
2403	luvas encadeadas leves
2406	molde botas de couro de qualidade
2407	molde gibao de couro branco
2408	molde luvas de couro de qualidade
2409	molde tunica de couro escuro
2410	tocha fumacenta
2411	redea de garanhao preto
2413	baio
2414	bridao de tobiano
2415	garanhao branco
2417	colete encadeado aumentado
2418	perneiras encadeadas aumentadas
2419	cinto encadeado aumentado
2420	botas encadeadas aumentadas
2421	bracadeiras encadeadas aumentadas
2422	luvas encadeadas aumentadas
2423	colete de brigandina
2424	cinto de brigandina
2425	perneiras de brigandina
2426	botas de brigandina
2427	bracadeiras de brigandina
2428	luvas de brigandina
2429	colete de burel
2431	calcas de burel
2432	botas de burel
2434	luvas de burel
2435	armadura ornada
2437	calcas ornadas
2438	botas ornadas
2440	luvas ornadas
2441	broquel circular
2442	tarja reforcada
2443	broquel de metal
2444	broquel ornado
2445	escudo de metal grande
2446	escudo ogival
2447	botao da paz
2448	paves pesado
2449	raiz telurica
2450	cravespinho
2451	escudo brasonado timbrado
2452	cardo veloz
2453	ervamossa
2454	elixir de forca de leao
2455	pocao menor de mana
2456	pocao menor de rejuvenescimento
2457	elixir de agilidade menor
2458	elixir de fortitude menor
2459	pocao de rapidez
2460	elixir of tongues nyi
2463	gibao cravejado
2464	cinto cravejado
2465	calcas cravejadas
2466	fetiche rachacranio
2467	botas cravejadas
2468	bracadeiras cravejadas
2469	luvas cravejadas
2470	colete de couro reforcado
2471	cinto de couro reforcado
2472	calcas de couro reforcado
2473	botas de couro reforcado
2474	bracadeiras de couro reforcado
2475	luvas de couro reforcado
2476	anca fria de basilisco
2477	cranio do assolador
2479	machado largo
2480	clava grande
2481	espada de peao
2482	machadinha inferior
2483	machado largo rustico
2484	faquinha
2485	tabua farpada
2486	maca de pedra grande
2487	cajado de acolito
2488	gladio
2489	espada de duas maos
2490	machadinha
2491	machado largo
2492	clava
2493	marreta de madeira
2494	estilete
2495	bengala
2496	espada curta do saqueador
2497	espadao enferrujado
2498	machadinha pequena
2499	machado de duas laminas
2500	martelo leve
2501	martelo de guerra de madeira
2502	adaga arranhada
2503	cajado curto de adepto
2504	arco curto usado
2505	arco curto polido
2506	arco recurvo de pau de chifre
2507	arco recurvo laminado
2508	bacamarte velho
2509	bacamarte ornado
2510	bacamarte macico
2511	cano de atirar do cacador
2512	flecha rustica
2514	depricated sharp arrow
2515	flecha afiada
2516	municao leve
2519	municao pesada
2520	espada larga
2521	flamberge
2522	machado crescente
2523	bullova
2524	porrete
2525	martelo de guerra
2526	adaga de bloqueio
2527	cajado de batalha
2528	alfanje
2529	bihander
2530	francica
2531	machado grande
2532	maca de guerra
2533	malho de guerra
2534	rondel
2535	cajado de guerra
2536	dente de pedra de trogg
2545	perneiras encadeadas maleaveis
2546	cinturao real jubafria
2547	luvas do tratador de javalis
2548	barril de grogue do cervevada
2549	cajado do vulto
2553	receita elixir de agilidade menor
2555	receita pocao de rapidez
2556	receita elixir de linguas
2560	diario completo de medrisco
2561	cabeca de chok sul
2562	buque de begonias escarlate
2563	po com cheiro estranho
2564	garras elficas espirituais
2565	bastao de fogo derretido
2566	vestes do sacrificio
2567	lamina do invocador
2568	colete marrom de linho
2569	botas de linho
2570	manto de linho
2571	botas vinosas
2572	veste de linho vermelha
2575	camisa vermelha de linho
2576	camisa branca de linho
2577	camisa de linho azul
2578	colete de linho barbaresco
2579	camisa verde de linho
2580	capa reforcada de linho
2581	bandagem de linho grossa
2582	colete de la verde
2583	botas de la
2584	capa de la
2585	veste de la cinza
2586	veste do mestre do jogo
2587	camisa de la cinza
2589	linho
2590	teia de aranha da floresta
2591	tecido trogg sujo
2592	la
2593	frasco de vinho do porto de ventobravo
2594	jarra de hidromel enanico
2595	jarra de bourbon dos ermos
2596	odre de stout enanica
2598	molde veste de linho vermelha
2601	molde veste de la cinza
2604	pigmento vermelho
2605	pigmento verde
2606	peconha de tocaieiro
2607	cristal mo grosh
2608	ambar gris de manguadonte
2609	coloide de desarme
2610	mistura de desarme
2611	pederneira grotesca
2612	veste simples
2613	vestes de costura dupla
2614	veste do aprendizado
2615	veste cromatica
2616	vestes cintilante de seda
2617	vestes incandescentes
2618	vestes prateadas
2619	relatorio de grolin
2620	mortalha profetica
2621	capucho de necromancia
2622	cocar tribal de nimar
2623	diadema sagrado
2624	casquete do pensamento
2625	estatueta de menethil
2628	relatorio de senir
2629	chave do cofre do intrepido
2632	adaga recurva
2633	remedio da mata
2634	extrato de samambaia peconhenta
2635	cinto folgado encadeado
2636	idolo esculpido em pedra
2637	relatorio de progresso de bandaferro
2639	carta de marina
2640	equipamento de mineracao
2642	botas folgadas encadeadas
2643	bracadeiras folgadas encadeadas
2644	manto folgado encadeado
2645	luvas folgadas encadeadas
2646	calcas folgadas encadeadas
2648	colete folgado encadeado
2649	cinto fragil encadeado
2650	botas frageis encadeadas
2651	bracadeiras frageis encadeadas
2652	manto fragil encadeado
2653	luvas frageis encadeadas
2654	calcas frageis encadeadas
2656	colete fragil encadeado
2657	bolsa de couro vermelha
2658	fragmento de ados
2659	fragmento de modr
2660	fragmento de golm
2661	fragmento neru
2662	aljava do ribas
2663	bandoleira do ribas
2664	presa de tecela
2665	tempero de ventobravo
2666	barril de cerveja do trovao
2667	carne seca do macgrann
2668	dente de manguadonte
2669	garra de manguadonte
2671	crina de wendigo
2672	acem de lobo
2673	carne de coiote
2674	carne de rastejante
2675	garra de rastejante
2676	tremulerva
2677	costelinhas de javali
2678	temperos suaves
2679	carne tostada de lobo
2680	carne temperada de lobo
2681	carne assada de porco
2682	pinca de caranguejo cozida
2683	bolinho de caranguejo
2684	bife de coiote
2685	costelinhas suinas suculentas
2686	cerveja do trovao
2687	costelinhas suinas ressecadas
2688	noz de esquilo
2690	cinto com aldrava
2691	botas do provedor
2692	temperos picantes
2694	perneiras do colonizador
2695	monstro maca clava com pontas
2696	barril de sempre aceso
2697	receita empadao de figado de goretusco
2698	receita pinca de caranguejo cozida
2699	receita gulache de cristarrubra
2700	receita costelinhas suinas suculentas
2701	receita kebab temperado de lobo
2702	lingote da forja de luz
2712	caixote de lingotes de forja de luz
2713	cabeca do velho fumaca
2719	pequena chave de latao
2720	bilhete lamacento
2721	mortalha sagrada
2722	vale vinho
2723	garrafa de noir de dalaran
2724	pedido de tecido
2725	grande espinhaco veredas – pagina 1
2728	grande espinhaco veredas – pagina 4
2730	grande espinhaco veredas – pagina 6
2732	grande espinhaco veredas – pagina 8
2734	grande espinhaco veredas – pagina 10
2735	grande espinhaco veredas – pagina 11
2738	grande espinhaco veredas – pagina 14
2740	grande espinhaco veredas – pagina 16
2742	grande espinhaco veredas – pagina 18
2744	grande espinhaco veredas – pagina 20
2745	grande espinhaco veredas – pagina 21
2748	grande espinhaco veredas – pagina 24
2749	grande espinhaco veredas – pagina 25
2750	grande espinhaco veredas – pagina 26
2751	grande espinhaco veredas – pagina 27
2754	espada bastarda manchada
2755	grande espinhaco veredas
2756	grande espinhaco veredas – capitulo i
2757	grande espinhaco veredas – capitulo ii
2758	grande espinhaco veredas – capitulo iii
2759	grande espinhaco veredas – capitulo iv
2760	kit de costura do antonio
2763	faca do pescador
2764	adaga pequena
2765	faca de caca
2766	estilete habil
2770	minerio de cobre
2771	minerio de estanho
2772	minerio de ferro
2773	arco curto rachado
2774	bacamarte coberto de ferrugem
2775	minerio de prata
2776	minerio de ouro
2777	arco curto debil
2778	bacamarte barato
2779	lagrima de tirsa
2780	arco leve de caca
2781	bacamarte sujo
2782	arco recurvo mal manejado
2783	bacamarte fajuto
2784	raiz almiscarada
2785	arco recurvo rigido
2786	bacamarte oleado
2787	adaga trogg
2788	chope garra negra
2794	um velho livro de historia
2795	livro fadigas do ferro
2797	coracao de mokk
2798	minerio retibano
2799	presa de gorila
2800	vestes de veludo preto
2801	lamina de hanna
2802	emblema fulgurante
2805	manto de pele de yeti
2806	pacote para lancatroz
2807	machado guilhotina
2808	tocha de chamas
2815	estripador de fio curvo
2816	cetro do morta voz
2817	tunica de couro macio
2818	calcas de couro esticadas
2819	adaga transversal
2820	cronometro bacana
2821	triturador mo grosh
2822	palito de dente mo grosh
2823	abridor de lata mo grosh
2824	furacao
2825	arco das flechas calcinantes
2828	restos mortais de nissa
2829	restos mortais de gregor
2830	restos mortais de timoteo
2831	restos mortais de delmiro
2832	receita de ensopado do cerro oeste da vera
2833	grimorio do lich
2834	linfa embalsamadora
2835	pedra rustica
2836	pedra bruta
2837	carta de timoteo
2838	pedra pesada
2839	uma carta para ivete
2840	barra de cobre
2841	barra de bronze
2842	barra de prata
2843	nos dos dedos sujos
2844	maca de cobre
2845	machado de cobre
2846	abobora de tirisfal
2847	espada curta de cobre
2848	maca de bronze
2849	machado de bronze
2850	espada curta de bronze
2851	cinto encadeado de cobre
2852	calcas encadeadas de cobre
2853	bracadeiras de cobre
2854	bracadeiras runicas de cobre
2855	garra putrida
2856	pique ferreo
2857	cinto runico de cobre
2858	sangue de cao das trevas
2859	escama de pinavil
2862	pedra de afiar rustica
2863	pedra de afiar grosseira
2864	peitoral runico de cobre
2865	perneiras rusticas de bronze
2866	corselete rustico de bronze
2867	bracadeiras rusticas de bronze
2868	bracadeiras decoradas de bronze
2869	peitoral de bronze prateado
2870	peitoral de prata rutilante
2871	pedra de afiar pesada
2872	peconha de trevateia malevola
2874	carta nao enviada
2875	anel com insignia escarlate
2876	pelagem de quiropusculo
2877	espadao do combatente
2878	machado farpado de osso
2879	bastao antipoda
2880	catalisador fraco
2881	instrucoes peitoral runico de cobre
2882	instrucoes omoplatas de bronze prateado
2883	instrucoes punhal mortal de bronze
2885	documentos da cruzada escarlate
2886	costeleta de rochetusco
2887	pelagem de lobo arruinada
2888	costelinhas de javali na cerveja
2889	receita costelinhas de javali na cerveja
2890	pelagem de javali arruinada
2891	carta para o arquiteto da cidade
2892	veneno mortal
2893	veneno mortal ii
2894	malte rapsodia
2895	dor gradativa
2896	angustia gradativa
2898	peito d armas do montanhista
2899	faixa wendigo
2900	broquel de pedra
2901	picareta de mineracao
2902	manto da fe
2903	arco de caca de daryl
2904	rifle de caca de daryl
2905	manto de pele de bode
2906	perneiras de malha de vila sombria
2907	cortador de arvore enanico
2908	lamina espinhosa
2909	bandana vermelha de la
2910	botas douradas de milicia
2911	cinturao de keller
2912	garra do sombramante
2913	dragonas sedosas de gamn
2915	quebragelo taranico
2916	escudo do leao dourado
2917	anel placido
2919	reliquia dos ancioes
2920	reliquia sagrada
2921	reliquia abencoada
2922	reliquia do espirito
2923	reliquia da retidao
2924	carne de crocolisco
2925	pele de crocolisco
2926	cabeca de basilio taborda
2927	tormento gradativo
2928	poeira da decomposicao
2929	podridao da tumba
2930	essencia da dor
2932	ramo do tormento
2933	selo de wrynn
2934	pedacos arruinados de couro
2939	lagrima de crocolisco
2940	pata ensanguentada de urso
2941	estoque de presidio
2942	soqueira de ferro
2943	olho de paleth
2944	olho maldito de paleth
2946	adaga de arremesso equilibrada
2947	faca de arremesso pequena
2949	botas de marinheiro
2950	bastao do pingente de gelo
2951	anel do subraxilo
2953	manto do mestre vigilante
2954	pantalonas da vigilia noturna
2955	chapeu do imediato
2956	relatorio sobre a irmandade defias
2957	colete do profissional
2958	calcas do profissional
2959	botas do profissional
2960	luvas do profissional
2961	colete de couro queimado
2962	calcoes de couro queimado
2963	botas de couro queimado
2964	luvas de couro queimado
2965	tunica do guerreiro
2966	calcas do guerreiro
2967	botas do guerreiro
2968	luvas do guerreiro
2969	colete mesmerizador
2970	calcas mesmerizadoras
2971	botas mesmerizadoras
2972	luvas mesmerizadoras
2973	tunica de caca
2974	calcas de caca
2975	botas de caca
2976	luvas de caca
2977	armadura do veterano
2978	perneiras do veterano
2979	botas do veterano
2980	luvas do veterano
2981	veste do vidente
2982	calcas do vidente
2983	botas do vidente
2984	luvas do vidente
2985	peitoral de couro inscrito
2986	calcas de couro inscritas
2987	botas de couro inscritas
2988	luvas de couro inscritas
2989	tunica lustrada
2990	perneiras lustradas
2991	botas lustradas
2992	luvas lustradas
2996	peca de linho
2997	peca de la
2998	uma bussola simples
2999	ferramentas do gradaco
3000	carapaca da grande mae
3002	chifre reliquia da justica
3003	reliquia do olho
3004	reliquia dos mortos
3005	reliquia da verdade
3006	estilhaco de reliquia sagrada
3008	manto de pele de wendigo
3010	areia fina
3011	cocar com penas
3012	pergaminho de agilidade
3013	pergaminho de protecao
3014	machado gasto em batalha
3016	grimorio de tertuliano
3017	ordens de sevren
3018	pelego de lupos
3019	veste do nobre
3020	casquete resistente
3021	arco do patrulheiro
3022	calcoes dos guelrazul
3023	bacamarte de calibre largo
3024	persuasor bkp 2700
3025	ultra bkp 42
3026	arco reforcado
3027	arco recurvo pesado
3028	arco longo
3029	flecha de pau de acoite
3030	flecha navalha
3031	flecha navalha
3033	municao macica
3035	abobora inoculada
3036	arco curto pesado
3037	arco recurvo de pau de acoite
3039	arco fraxineo curto
3040	espingarda de antecarga do cacador
3041	bacamarte olho de mago
3042	pardal bkp de calibre pequeno
3045	botas bruxuleantes de escama
3047	luvas bruxuleantes de escama
3048	guarda pernas bruxuleantes de escama
3049	peitoral bruxuleante de escama
3053	peito d armas do humberto
3055	peito d armas de couro da floresta
3056	calcas de couro da floresta
3057	botas de couro da floresta
3058	luvas de couro da floresta
3065	botas brilhantes
3066	luvas brilhantes
3067	calcas brilhantes
3069	veste brilhante
3070	manto do alferes
3071	machadinha de ataque
3072	veste fumegante
3073	calcas fumegantes
3074	luvas fumegantes
3075	olho da chama
3076	botas fumegantes
3078	fura coracao das nagas
3079	bacamarte de skorn
3080	vela de sinalizacao
3081	gema eterea
3082	cranio de dargol
3083	roda de reestabilizacao
3084	equipamento giromecanico
3085	barril de cerveja tremeluz
3086	tonel de cerveja tremeluz
3087	caneca de cerveja tremeluz
3088	livro de rejuvenescimento iv
3089	tomo de golpe flamejante
3090	tomo de seta de gelo
3091	tomo de intelecto arcano ii
3092	tomo de golpe flamejante iii
3093	tomo de golpe flamejante ii
3094	tomo de impacto de fogo ii
3095	tomo de impacto de fogo iii
3096	tomo de queda de pluma
3097	tomo de conjurar agua ii
3098	tomo de retardar
3099	tomo de armadura de gelo ii
3100	tomo de nevasca ii
3101	tomo de nova congelante iii
3102	tomo de intelecto arcano iii
3103	martelo de cristalgida
3107	faca de arremesso afiada
3108	adaga de arremesso pesada
3110	orelha de ratatunel
3111	machado de arremesso rudimentar
3113	codice de palavra sagrada escudo
3114	codice de palavra sombria estontear
3115	codice de renovar iv
3116	codice de palavra sagrada escudo ii
3117	diario de hildelve
3118	codice de cura maior
3119	codice de palavra sagrada escudo v
3120	codice de punicao sagrada iv
3121	codice de levitar
3122	codice de palavra sagrada escudo iii
3123	codice de palavra sagrada fortitude iii
3124	codice de fogo interior iii
3125	tabuleta de totem serpente ii
3126	tabuleta de choque ii
3127	tabuleta de choque iii
3129	tabuleta de raio iv
3130	tabuleta de restauracao iv
3131	machado de arremesso pesado
3132	tabuleta de impacto derretido iv
3133	tabuleta de totem de mana
3134	grimorio de maldicao de mannoroth
3135	machado de arremesso afiado
3137	machado de arremesso mortal
3138	grimorio de seta sombria iv
3139	grimorio de armadura demoniaca ii
3140	grimorio de sangue fervente ii
3141	grimorio de drenar vida
3142	grimorio de maldicao de sargeras
3143	grimorio de espirito incandescente
3144	grimorio de espirito incandescente ii
3146	grimorio de espirito incandescente iii
3151	colete da brigada de cerco
3152	luvas para dirigir
3153	manto manchado de oleo
3154	machado de thelsamar
3155	remedio de arugal
3156	grilhao de glutao
3157	grilhao almanegra
3158	bracadeiras de pelego queimado
3160	broquel de placas ferreas
3161	veste do guardiao
3162	costela carcomida
3163	cranio enegrecido
3164	coracao descolorido de worg
3165	pocao de quinn
3166	corrente de coracao ferreo
3167	pelo grosso de aranha
3168	escama lascada
3169	dente lascado de urso
3170	dente grande de urso
3171	presa quebrada de javali
3172	tripas de javali
3173	carne de urso
3174	linfa de aranha
3175	couro de dragao arruinado
3176	garra pequena
3177	presinha
3179	exuvia dragonica rachada
3180	escama sarapintada de raptor
3181	carne parcialmente digerida
3182	seda da aranha
3183	pata sarnenta
3184	adaga enganchadora
3185	cajado acrobatico
3186	espada viking
3187	cris sacrificial
3188	espadao coral
3189	cortalenha
3190	porrete
3191	machado de guerra recurvo
3192	espada bastarda curta
3193	marreta de carvalho
3194	malicia negra
3195	machado de batalha barbaresco
3196	espada bastarda afiada
3197	espadao lapidante
3198	martelo ariete
3199	belocida
3200	bracadeiras de couro queimado
3201	machado de guerra barbaro
3202	bracadeiras de couro da floresta
3203	maca triangular densa
3204	bracadeiras de lenhafunda
3205	bracadeiras de couro inscritas
3206	espada de mao dupla do fidalgo
3207	bracadeiras de caca
3208	martelo kabong
3209	espada belica antiga
3210	machado de guerra brutal
3211	bracadeiras lustradas
3212	bracadeiras bruxuleantes de escama
3213	bracadeiras do veterano
3214	bracadeiras do guerreiro
3216	veste grossa de inverno
3217	cinto do encarregado
3218	grilha de lenhardente
3220	chourico
3222	adaga malefica
3223	cetro jubafria
3224	bracadeiras forradas com prata
3225	faca manchada de sangue
3227	cajado do nocturno
3228	grilhoes forcados
3229	faixa de seda de tarantula
3230	bracadeiras do lobo preto
3231	brafoneiras degoladoras
3233	sacola de pelego de gnoll
3234	anel de deliah
3235	anel do escarnio
3236	linfa de putricouro
3237	amostra de linfa
3238	achados de joaquino
3239	contrapeso rustico
3240	contrapeso grosseiro
3241	contrapeso pesado
3248	carta do embalsamador traduzida
3249	conjured test item
3250	pergaminho de boanerges
3251	pocao de boanerges
3252	relatorio do sicario
3253	coracao de urso cinzento
3254	sangue de pateante
3255	diario de berardo
3256	musgo de sorrateiro do lago
3257	musgo de rastejante do lago
3258	tumor endurecido
3259	pelego de morcego arruinado
3260	vestes do iniciado escarlate
3261	manto enredado
3262	martelo de madeira podre
3263	calcas enredadas
3264	asa de quiropusculo
3265	pata de carniceiro
3266	bracadeiras escarlate
3267	espada curta dos renegados
3268	adaga dos renegados
3269	malho dos renegados
3270	colete de linhao
3272	perneiras de pele de zumbi
3273	colete de malha rustico
3274	botas de linhao
3275	luvas de linhao
3276	broquel do necroguarda
3277	cajado do executor
3278	aura de proc de espada de dano
3279	botas encadeadas de batalha
3280	bracadeiras encadeadas de batalha
3281	luvas encadeadas de batalha
3282	calcas encadeadas de batalha
3283	tunica encadeada de batalha
3284	botas tribais
3285	bracadeiras tribais
3286	luvas tribais
3287	calcas tribais
3288	colete tribal
3289	botas ancestrais
3290	luvas ancestrais
3291	tanga do ancestral
3292	tunica ancestral
3293	cutelo do defunto
3294	clava do defunto
3295	lamina do defunto
3296	adaga do defunto
3297	limo vil
3299	canino fraturado
3300	pata de coelho
3301	canino afiado
3302	botas salobras
3303	bracadeiras salobras
3304	manoplas salobras
3305	perneiras salobras
3306	colete salobro
3307	botas de tecido barbarescas
3308	luvas de tecido barbarescas
3309	tanga barbaresca
3310	colete de tecido barbaresco
3311	tornozeleiras cerimoniais de couro
3312	bracadeiras cerimoniais de couro
3313	arnes cerimonial de couro
3314	luvas cerimoniais de couro
3315	tanga cerimonial de couro
3316	cabeca de alaric
3317	uma cabeca falante
3318	restos mortais de alaric
3319	sabre curto
3320	faixa do osteurgo
3321	botinas de pele cinzas
3322	manto tenue
3323	bracadeiras fantasmagoricas
3324	dragonas fantasmagoricas
3325	machado de batalha de pinavil
3327	cajado de oraculo de pinavil
3328	veste teia de aranha
3329	prancha de madeira com pregos
3330	cota de dargol
3331	capa de metrache
3332	botas de perrine
3334	pa do fazendeiro
3335	vassoura do fazendeiro
3336	fura carne
3337	estandarte de guerra presa do dragao
3339	isca de pederneira enanica
3340	minerio de incendicita
3341	manoplas da forca ogrica
3342	camisa do capitao albernaz
3343	saco de butim do capitao albernaz
3344	faixa do capitao albernaz
3345	chapeu de teurgo de seda
3347	pacote de peles de crocolisco
3348	pele de crocolisco gigante
3349	bolsa da cida
3352	bolsa coberta de gosma
3353	pingente inscrito em runas
3354	pingente de dalaran
3355	acera agreste
3356	sangue real
3357	raiz da vida
3358	bigode de hadggar
3360	femur do suturino
3363	cinto puido
3365	bracadeiras puidas
3369	musgo de tumba
3370	cinto de retalhos
3371	ampola vazia
3372	ampola chumbada
3373	bracadeiras de retalhos
3374	cinto de calico
3375	bracadeiras de calico
3376	cinto de lona
3377	bracadeiras de lona
3378	cinto brocado
3379	bracadeiras brocadas
3380	cinto em ponto de cruz
3381	bracadeiras em ponto de cruz
3382	pocao fraca de sangue de troll
3383	elixir de sabedoria
3384	pocao menor de resistencia a magia
3385	pocao inferior de mana
3386	elixir de resistencia a veneno
3387	pocao de invulnerabilidade limitada
3388	pocao forte de sangue de troll
3389	elixir de defesa
3390	elixir de agilidade inferior
3391	elixir de forca do ogro
3392	elmo de elos
3393	receita pocao menor de resistencia a magia
3394	receita elixir de resistencia a veneno
3395	receita pocao de invulnerabilidade limitada
3396	receita elixir de agilidade inferior
3397	pele de crocolisco jovem
3399	garra de abutre
3400	espada lucina
3401	escama aspera de crocolisco
3402	tufo macio de pele
3403	presa de marfim de javali
3404	asa de urubu
3405	talisma de garra de corvo
3406	calamo de pena negra
3407	safira do ceu
3408	runa da nidificacao
3409	presa de sabre da noite
3411	pena estrigida de coruja
3412	seda de aranha lenhateia
3413	estaca da perdicao
3414	cetro timbrado
3415	cajado monastico
3416	correntes do martir
3417	espadao de onix
3418	pinha vil
3419	rosa vermelha
3420	rosa negra
3421	flores silvestres simples
3422	belas flores silvestres
3423	buque de rosas brancas
3424	buque de rosas pretas
3425	varinha entretecida
3426	camisa amarelo cheguei
3427	camisa preta estilosa
3428	camisa cinza comum
3429	cinto do guarda
3430	rifle de francoatirador
3431	couro cravejado com ossos
3434	areia do sono
3435	bracadeiras de pele zumbis
3437	cinto afivelado
3438	ankh da ressurreicao
3439	botas de pele zumbis
3440	racha osso
3442	faixa de aprendiz
3443	machadinha aborigine cerimonial
3444	colete do lavrador
3445	faca cerimonial
3446	cajado lenhanegra
3447	botas andacripta
3448	raiz de senggin
3449	xale mistico
3450	escudo de faerleia
3451	beberagem do brilho da noite
3452	bastao de ceranio
3453	bracadeiras acolchoadas
3454	botas de reconhecimento
3455	espada curta do sicario
3456	apito de caes
3457	calcas estampadas
3458	luvas grosseiras de malha
3460	bebida especial do joaquino
3461	grande veste do arbitro
3462	lancagarra
3463	estrela de prata
3464	flecha com penas
3465	tiro detonador
3466	catalisador forte
3467	chave de ouro desluzido
3468	achados de renferrel
3469	botas encadeadas de cobre
3470	pedra de amolar rustica
3471	colete encadeado de cobre
3472	manoplas runicas de cobre
3473	calcas runicas de cobre
3474	manoplas de cobre com gemas
3475	manto das chamas
3476	lingua de urso cinzento
3477	pus de rastejante
3478	pedra de amolar grosseira
3480	omoplatas rusticas de bronze
3481	omoplatas de bronze prateado
3482	botas de bronze prateado
3483	manoplas de bronze prateado
3484	botas verdes de ferro
3485	manoplas verdes de ferro
3486	pedra de amolar pesada
3487	espada larga pesada de cobre
3488	machado de batalha de cobre
3489	machado de guerra grosso
3490	punhal mortal de bronze
3491	maca pesada de bronze
3492	martelo potente de ferro
3493	verdugo dos raptors
3495	elixir do sofrimento
3496	sangue de leao da montanha
3497	elixir da dor
3498	colar de taretha
3499	chave de ouro lustroso
3502	cogumelos fucalama
3505	anel sinete de alterac
3506	composto fucalama
3508	mistura fucalama
3509	escama de espinhadaga
3510	olho de rancapina
3511	manto da milicia do povo
3514	cranio de mor ladim
3515	cajado de ataeric
3516	cabeca de lescovar
3517	barril de stout do festeiro
3518	carta decifrada
3520	barril estragado
3521	carta habilmente cifrada
3522	peitoral preto de elfo noturno
3523	calcas pretas de elfo noturno nao usadas
3524	botas pretas de elfo noturno nao usadas
3525	bracadeiras pretas de elfo noturno nao usadas
3526	luvas pretas de elfo noturno
3527	peitoral branco de elfo noturno
3528	peitoral c03 de couro vermelho
3529	elmo preto de elfo noturno
3530	bandagem de la
3531	bandagem grossa de la
3532	unused red leather c03 pants
3533	botas c03 de couro vermelho
3534	unused red leather c03 gloves
3535	bracadeiras c03 de couro vermelho
3536	venda do cacador de demonios
3537	peitoral d02 de couro preto
3538	peitoral d02 de couro cinza
3539	unused black leather d02 pants
3540	unused gray leather d02 pants
3541	botas d02 de couro preto
3542	botas d02 de couro cinza
3543	unused black leather d02 gloves
3544	unused gray leather d02 gloves
3545	bracadeiras d02 de couro preto
3546	bracadeiras d02 de couro cinza
3547	peitoral d03 de couro branco
3548	unused white leather d03 pants
3549	unused white leather d03 gloves
3550	cabeca do targ
3551	cabeca de revirestrume
3552	cabeca de glommus
3553	cabeca de mug thol
3554	coroa da vontade
3555	veste de salomao
3556	chapeu de mago do horror
3557	tabardo de bucha nao usado
3558	veste do protetor do charco
3559	manoplas da vigilia noturna
3560	dragonas da honra
3561	poncho resiliente
3562	cinto da vindicacao
3563	pantalonas do marinheiro
3564	carregamento de ferro
3565	luvas manchadas de cerveja
3566	armadura arruina raptor
3567	vara de pescar enanica
3569	veste do vicario
3570	pilao para ossos
3571	batedor trogg
3572	espada curta de daryl
3573	aljava de caca
3574	saco de municao de caca
3575	barra de ferro
3576	barra de estanho
3577	barra de ouro
3578	calcas do ceifador
3581	faca serrilhada
3582	manto a prova de acido
3583	cinto surrado
3585	tunica camuflada
3586	rachalenha
3587	cinto ornado
3588	bracadeiras ornadas
3589	cinto de trama pesada
3590	bracadeiras de trama pesada
3591	cinto acolchoado
3592	bracadeiras acolchoadas
3593	cinto de burel
3594	bracadeiras de burel
3595	cinto de tecido esfarrapado
3596	bracadeiras de tecido esfarrapado
3597	cinto de tecido grosso
3598	bracadeiras de tecido grosso
3599	cinto de tecido fino
3600	bracadeiras de tecido fino
3601	missiva da camarilha
3602	cinto tricotado
3603	bracadeiras tricotadas
3604	cartucheira da vigilia noturna
3605	aljava da vigilia noturna
3606	cinto trancado
3607	bracadeiras trancadas
3608	instrucoes martelo potente de ferro
3609	instrucoes colete encadeado de cobre
3610	instrucoes manoplas de cobre com gemas
3611	instrucoes botas verdes de ferro
3612	instrucoes manoplas verdes de ferro
3613	maos de valdred
3614	pata de berrante
3615	cabeca do kurzen
3616	olho da mente
3617	pingente das sombras
3618	cabeca de comilao
3619	caixa de rape do expedito
3620	restos mortais de lillith
3621	cabeca de ivar
3622	essencia de vergasta
3623	cabeca de thule
3625	cabeca do nek rosh
3626	cabeca do barao vardus
3627	presa de ragash
3628	mao de flavio lucio
3629	anel da familia brumanto
3630	cabeca de targorr
3631	presa de ronquifuca
3632	pata de mordente
3633	cabeca de gath ilzogg
3634	cabeca de severo
3635	pata do olho de verme
3636	escama do velho olho turvo
3637	cabeca do vancleef
3638	garra do sarilodonte
3639	orelha do balgaras
3640	cabeca de fundafuria
3641	bracadeiras do profissional
3642	bracadeiras ancestrais
3643	bracadeiras mesmerizadoras
3644	bracadeiras de tecido barbarescas
3645	manilhas do vidente
3647	bracadeiras brilhantes
3648	broquel do guerreiro
3649	broquel tribal
3650	escudo de batalha
3651	escudo do veterano
3652	broquel de caca
3653	broquel cerimonial
3654	escudo salobro
3655	escudo lustrado
3656	escudo bruxuleante de escama
3657	cartorio de eira dos montes
3658	tomo recuperado
3659	livro de couro desgastado
3660	tomos de alterac
3661	cajado artesanal
3662	bife de crocolisco
3663	sopa de barbatana de murloc
3664	bobo de crocolisco
3665	omelete curiosamente saboroso
3666	bolo de aranha pegajoso
3667	carne tenra de crocolisco
3668	contrato do assassino
3669	meleca gelatinosa
3670	osso enlameado grande
3671	cranio inerte
3672	cabeca de nagaz
3673	flecha quebrada
3674	bota em decomposicao
3675	tocha extinta
3676	linfa viscosa
3678	receita bife de crocolisco
3679	receita chourico
3680	receita sopa de barbatana de murloc
3681	receita bobo de crocolisco
3682	receita omelete curiosamente saboroso
3683	receita bolo de aranha pegajoso
3684	tiara de perenolde
3685	ovo de raptor
3688	oval de pedra sangrenta
3689	bola de gude de pedra sangrenta
3690	lasca de pedra sangrenta
3691	cunha de pedra sangrenta
3692	cranio humano de eira dos montes
3693	espada do humberto
3701	comenda lacrada de darthalia
3702	vesicula biliar de urso
3703	stout da costa sul
3704	chave de ferro enferrujada
3706	pergaminho encantado
3707	pergaminho de nagaz
3708	bastao de helcolar
3710	bastao de helcolar
3711	diario de pesquisa de belamore
3712	carne de tartaruga
3713	temperos reconfortantes
3714	ficha de pedra gasta
3715	bracadeiras do vinculo a terra
3716	cabeca de murloc
3717	saco com cabecas de murloc
3718	planos agourentos
3719	manto do montanhista
3720	pele de yeti
3721	relatorio de farrio
3722	pelego conhecido
3723	presa conhecida
3724	garra conhecida
3725	chifre conhecido
3726	file de ursao
3727	costeletas picantes de leao
3728	bife saboroso de leao
3729	caldo reconfortante de tartaruga
3730	carne de ursao
3731	carne de leao
3732	capa com capucho
3733	corrente belica orquica
3734	receita file de ursao
3735	receita costeletas picantes de leao
3736	receita bife saboroso de leao
3737	receita caldo reconfortante de tartaruga
3738	bastao do processamento
3739	anel de cranio
3740	espada decapitante
3741	botas da pisadura
3742	arco da pilhagem
3743	broquel da sentinela
3744	pingente de pedra sangrenta
3745	runa de abertura
3747	faixa meditativa
3748	dragonas felinas
3749	manto da gra boticaria
3750	peitoral com suportes
3751	perneiras mercenarias
3752	colete do bruto
3753	cinturao do pastor
3754	luvas do pastor
3755	rasgador de peixe
3758	cinto do cruzado
3759	luvas isolantes do sabio
3760	elo da cidade baixa
3761	escudo cranio morto
3762	algibeira do bibliotecario
3763	broquel lunar
3764	botas do mantideo
3765	brafoneiras do bandoleiro
3766	calamo de pena de grifo
3767	pergaminho de qualidade
3769	varinha quebrada
3770	costela de carneiro
3771	pernil de porco do mato
3772	agua da fonte conjurada
3775	veneno debilitante
3776	veneno debilitante ii
3777	raiz da letargia
3778	arco composto firme
3779	machado de guerra robusto
3780	mosquete de cano longo
3781	espadao largo
3782	grande clava de guerra
3783	cimitarra leve
3784	baculo de metal
3785	machado afiado
3786	punhal brilhante
3787	clava de pedra
3788	reliquia do cristal de alma
3789	pedra reliquia da devocao
3790	pergaminho reliquia consagrado
3791	reliquia da luz
3792	cinto entrelacado
3793	botas entrelacadas
3794	bracadeiras entrelacadas
3795	manto entrelacado
3796	luvas entrelacadas
3797	calcas entrelacadas
3798	ombreiras entrelacadas
3799	colete entrelacado
3800	cinto de couro endurecido
3801	botas de couro endurecido
3802	bracadeiras de couro endurecido
3803	manto endurecido
3804	luvas de couro endurecido
3805	calcas de couro endurecido
3806	ombreiras de couro endurecido
3807	tunica de couro endurecido
3808	cinto de malha dupla
3809	botas de malha dupla
3810	bracadeiras de malha dupla
3811	manto de costura dupla
3812	luvas de malha dupla
3813	calcas de malha dupla
3814	ombreiras de malha dupla
3815	colete de malha dupla
3816	escudo refletor
3817	broquel reforcado
3818	some folha
3819	boquinha do inverno
3820	estrangulalga
3821	espinheira dourada
3822	laminegra runica
3823	pocao inferior de invisibilidade
3824	oleo de sombra
3825	elixir de fortitude
3826	pocao potente de sangue de troll
3827	pocao de mana
3828	elixir de detectar invisibilidade inferior
3829	oleo gelido
3830	receita elixir de fortitude
3831	receita pocao potente de sangue de troll
3832	receita elixir de detectar invisibilidade inferior
3833	manto do adepto
3834	calcas de tecido resistente
3835	bracadeiras verdes de ferro
3836	elmo verde de ferro
3837	coifa de escama dourada
3838	garra de umbragorja
3839	presa imaculada de tigresa
3840	omoplatas verdes de ferro
3841	omoplatas de escama dourada
3842	perneiras verdes de ferro
3843	perneiras de escama dourada
3844	cota verde de ferro
3845	corselete de escama dourada
3846	botas de aco polido
3847	botas de escama dourada
3848	faca grande de bronze
3849	espada curta de ferro temperado
3850	espada viperina de jade
3851	malho de ferro macico
3852	destruidor de ferro dourado
3853	espada larga de lunaco
3854	lamina do tigre de gelo
3855	machado solido de ferro
3856	machado crescente das sombras
3857	carvao
3858	minerio de mithril
3859	barra de aco
3860	barra de mithril
3861	barra de aconegro
3862	tendao de gorila velho
3863	pena de espreitador da selva
3864	citrino
3866	instrucoes espada viperina de jade
3867	instrucoes destruidor de ferro dourado
3868	instrucoes lamina do tigre de gelo
3869	instrucoes machado crescente das sombras
3870	instrucoes omoplatas verdes de ferro
3871	instrucoes omoplatas de escama dourada
3872	instrucoes perneiras de escama dourada
3873	instrucoes corselete de escama dourada
3874	instrucoes botas de aco polido
3875	instrucoes botas de escama dourada
3876	presa de bhag thera
3877	gadanho de tethis
3879	pata de sin dall
3880	cabeca de bangalash
3882	pena de urubu
3889	chapeu de burel
3890	chapeu cravejado
3891	elmo encadeado aumentado
3892	chapeu ornado
3893	casquete de couro reforcado
3894	elmo de brigandina
3897	olho do dizzy
3898	canhoto da biblioteca
3899	lendas dos gurubashi volume 3
3900	xerez de pupellyverbos
3901	presa de sanguescalpo
3902	cajado dos nobres
3904	cabeca de gan zulah
3905	cabeca de nezzliok
3906	trofeu de balia mah
3907	trofeu de ziata jai
3908	trofeu zul mamwe
3909	armadura quebrada de ana thek
3910	rape
3911	estilhaco azul pulsante
3912	gema animica
3913	joia de alma plena
3914	mochila do profissional
3915	colar de osso ensanguentado
3916	colar de osso partido
3917	cristal azul canoro
3918	estilhaco de cristal cantante
3919	miudos de gorila do vale da nevoa
3920	cartas de navegacao da vela sangrenta
3921	ordens da vela sangrenta
3922	pagamento do sacode
3923	bracadeiras do elemental da agua
3924	pe de clava do maury
3925	luneta dourada de janjao
3926	anel enorme do chucky
3927	cheddar bem envelhecido
3928	pocao superior de cura
3929	saque do maury
3930	chave de maury
3931	presa envenenada de aranha
3932	bau do smotts
3935	alfanje de smotts
3936	cinto de croche
3937	botas de croche
3938	bracadeiras de croche
3939	manto de croche
3940	luvas de croche
3941	calcas de croche
3942	ombreiras de croche
3943	colete de croche
3944	cinto de sarja
3945	botas de sarja
3946	bracadeiras de sarja
3947	manto de sarja
3948	luvas de sarja
3949	calcas de sarja
3950	ombreiras de sarja
3951	colete de sarja
3952	cinto de rede metalica
3953	botas de rede metalica
3954	bracadeiras de rede metalica
3955	manto de rede metalica
3956	luvas de rede metalica
3957	calcas de rede metalica
3958	dragonas de rede metalica
3959	armadura de rede metalica
3960	bolsa de bracadeiras de elementais da agua
3961	cinto de couro grosso
3962	botas de couro grosso
3963	bracadeiras de couro grosso
3964	manto grosso
3965	luvas de couro grosso
3966	calcas de couro grosso
3967	ombreiras de couro grosso
3968	tunica de couro grosso
3969	cinto de couro liso
3970	botas de couro liso
3971	bracadeiras de couro liso
3972	manto liso
3973	luvas de couro liso
3974	calcas de couro liso
3975	ombreiras de couro liso
3976	armadura de couro liso
3977	cinto enfaixado
3978	botas enfaixadas
3979	bracadeiras enfaixadas
3980	manto enfaixado
3981	luvas enfaixadas
3982	calcas enfaixadas
3983	ombreiras enfaixadas
3984	armadura enfaixada
3985	faixa com monograma
3986	paves protetor
3987	torre defletora
3988	muralha de protecao de placa
3989	tarja de bloqueio
3990	broquel timbrado
3991	broquel de placas
3992	cinto laminado de escama
3993	botas laminadas de escama
3994	bracadeiras laminadas de escama
3995	manto laminado de escama
3996	luvas laminadas de escama
3997	calcas laminadas de escama
3998	ombreiras laminadas de escama
3999	armadura laminada de escama
4000	cinto de malha entretecida
4001	botas de malha entretecida
4002	bracadeiras de malha entretecida
4003	manto de malha entretecida
4004	luvas de malha entretecida
4005	calcas de malha entretecida
4006	ombreiras de malha entretecida
4007	armadura de malha entretecida
4008	cinto encadeado excelente
4009	botas encadeadas excelentes
4010	bracadeiras encadeadas excelentes
4011	manto encadeado excelente
4012	luvas encadeadas excelentes
4013	calcas encadeadas excelentes
4014	ombreiras encadeadas excelentes
4015	armadura encadeada excelente
4016	preparado de zanzil
4017	espada curta afiada
4018	espadao afiado
4019	machado duro de silex
4020	machado de batalha estilhacante
4021	maca rombuda
4022	malho esmagante
4023	adaga pontuda de qualidade
4024	cajado de guerra pesado
4025	arco longo equilibrado
4026	mosquete da sentinela
4027	lamina de catelyn
4028	feixe de junco de akiris
4029	junco de akiris
4030	agua da reliquia sagrada
4031	patua da reliquia sagrada
4032	martelo reliquia radiante
4033	brilho da aurora
4034	pedra das mares
4035	veste de fio de prata
4036	manilhas de fio de prata
4037	calcas de fio de prata
4038	veste do ceu noturno
4039	capucho do ceu noturno
4040	luvas do ceu noturno
4041	capucho da aurora
4042	luvas da aurora
4043	bracadeiras da aurora
4044	calcas da aurora
4045	bracadeiras enevoadas
4046	calcas enevoadas
4047	botas enevoadas
4048	chapeu brasonado
4049	bracadeiras brasonadas
4050	perneiras brasonadas
4051	botas brasonadas
4052	casquete com insignia
4053	pele de crocolisco grande do rio
4054	perneiras com insignia
4055	botas com insignia
4056	charada do cortello
4057	couraca com insignia
4058	peitoral glifico
4059	bracadeiras glificas
4060	perneiras glificas
4061	bracadeiras imperiais de couro
4062	calcas imperiais de couro
4063	luvas imperiais de couro
4064	broquel brasonado
4065	escudo de combate
4066	broquel com insignia
4067	broquel glifico
4068	escudo do brigadeiro chefe
4069	broquel de forja negra
4070	timbre do justador
4071	peitoral de malha furta cor
4072	manoplas de malha furta cor
4073	grevas de malha furta cor
4074	armadura de combate de malha
4075	manoplas de combate de malha
4076	botas de combate de malha
4077	cimeira de combate de malha
4078	touca do brigadeiro chefe
4079	perneiras do brigadeiro chefe
4080	capucho forja negra
4082	peitoral forja negra
4083	manoplas forja negra
4084	perneiras forja negra
4085	cacarola meia boca do krazek
4086	rifle relampago
4087	arco tirocerto
4088	terroraco
4089	bacamarte ricochete
4090	caneca d aleijar
4091	fazedor de viuvas
4092	escama prismatica de basilisco
4093	cauda grande de basilisco
4094	estilhaco de tabuleta
4095	kit deprecado de armadilha
4096	pelo aspero de gorila
4097	dente lascado de gorila
4098	bilhete cuidadosamente dobrado
4099	tufo de pelo de gorila
4100	bilhete amarrotado
4101	bilhete rasgado
4102	bilhete rasgado
4103	chave dos grilhoes
4104	pele de crocolisco arapuca
4105	pele de crocolisco anciao
4106	cristal rolado
4107	luvas do cacador de tigres
4108	perneiras do cacador de panteras
4109	botas excelsior
4110	arco do mestre cacador
4111	rifle do mestre cacador
4112	gargantilha do sumo xama
4113	cobertor medicinal
4114	capa ondanegra
4115	broquel grom gol
4116	diad orin
4117	cinta causticante
4118	argola de nariz da princesa manda chuva
4119	tunica do cacador de raptor
4120	veste das aguas cristalinas
4121	luvas de pedraria
4122	cetro do contador
4123	brafoneiras de metal gelido
4124	casquete da harmonia
4125	orbe sereno
4126	cutelo de guerrilha
4127	trabuco de estilhacos
4128	pa de prata
4129	bandeja de coleta
4130	bussola de smotts
4131	cinto de corrupcao
4132	talas lancanegra
4133	manilhas lancanegra
4134	cajado mistico de nimboya
4135	anel osso sangrento
4136	botas lancanegra
4137	sapatos lancanegra
4138	tunica de aguanegra
4139	sandalias do andarilho das selvas
4140	dragonas de fronde de palmeira
4141	tomo de conjurar comida
4142	tomo de polimorfia porco
4143	tomo de conjurar comida ii
4144	tomo de polimorfia vaca
4145	tomo de conjurar gema de mana
4146	tomo do polimorfo ovelha
4147	tomo de conjurar comida iii
4148	tomo de contrafeitico
4149	tomo do escudo gelido iii
4150	tomo de conjurar agua iv
4151	tomo de seta de gelo iv
4152	tomo de conjurar comida iv
4153	tomo de misseis arcanos iii
4154	tomo de retardar ii
4155	tomo de elemental da agua ii
4157	tomo de atenuar magia
4158	tomo de destravamento de hadggar iii
4159	tomo de misseis arcanos
4160	tomo de invisibilidade
4161	tomo de bola de fogo iv
4162	tomo de lampejo ii
4164	incunabulo luz sagrada v
4165	incunabulo luz sagrada vi
4166	incunabulo selo da protecao
4167	incunabulo julgamento
4168	tabuleta de totem enredante
4169	tabuleta da vontade obstinada ii
4170	tabuleta de revocacao astral
4171	tabuleta de totem agitador ii
4172	tabuleta de trovoada ii
4173	tabuleta de choque iv
4174	tabuleta de choque v
4175	tabuleta de escudo de raios iv
4176	tabuleta da forca imortal ii
4177	tabuleta de resistencia a natureza
4178	tabuleta de raio v
4179	tabuleta de restauracao v
4180	tabuleta de forma eterea ii
4181	tabuleta de totem agitador iv
4182	tabuleta da vontade obstinada iii
4183	tabuleta de totem curativo v
4184	tabuleta de impacto derretido v
4185	tabuleta de revocacao astral em grupo
4186	tabuleta de resistencia ao fogo
4187	tabuleta de totem serpente v
4188	tabuleta de totem de invisibilidade
4189	tabuleta de cadeia de raios
4190	armadura com penas
4191	perneiras com penas nao usadas
4192	manoplas com penas nao usadas
4194	bracadeiras com penas
4195	botas com penas
4196	dragonas emplumadas
4197	ombreiras berilias
4198	grimorio de funil de alma
4199	grimorio de funil de alma ii
4200	grimorio de imolacao iii
4201	grimorio de olho de kilrogg
4202	grimorio de medo ii
4203	grimorio de pestilencia ii
4204	grimorio de funil de alma iii
4205	grimorio de imolacao iv
4206	grimorio de maldicao de sargeras ii
4207	grimorio de maldicao de arquimonde
4208	grimorio de bomba psiquica
4209	grimorio de protecao contra sombras
4210	grimorio de criar pedra sangrenta inferior
4211	grimorio de pestilencia
4212	grimorio de maldicao de mannoroth iii
4213	grimorio de perdicao
4214	grimorio de drenar vida iii
4215	grimorio de chuva de fogo
4216	grimorio de protecao sagrada
4217	grimorio de funil de alma iv
4218	grimorio de criar pedra sangrenta
4219	grimorio de espirito incandescente iv
4220	grimorio de sangue fervente iii
4221	grimorio de detectar invisibilidade
4223	livro de abolir magia
4225	livro de raizes enredantes iii
4226	livro de ira vi
4228	livro de fogo lunar iv
4230	livro de toque de cura vi
4231	pelego leve curado
4232	pelego medio
4233	pelego medio curado
4234	couro pesado
4235	pelego pesado
4236	pelego pesado curado
4237	cinto de couro feito a mao
4238	bolsa de linho
4239	luvas de couro com relevo
4240	bolsa de la
4241	bolsa de la verde
4242	calcas de couro com relevo
4243	tunica de couro de qualidade
4244	colete de couro do montanhista
4245	mochila pequena de seda
4246	cinto de couro de qualidade
4247	luvas de couro do montanhista
4248	luvas de couro escuro
4249	cinto de couro escuro
4250	cinto do montanhista
4251	omoplatas do montanhista
4252	omoplatas de couro escuro
4253	luvas de couro resistente
4254	luvas barbarescas
4255	armadura de couro verde
4256	armadura do guardiao
4257	cinto de couro verde
4258	cinto do guardiao
4259	bracadeiras de couro verde
4260	bracadeiras de couro do guardiao
4261	calcas de solliden
4262	cinto de couro rematado de gemas
4263	escudo padrao
4264	cinto barbaresco
4265	kit de armadura pesada
4266	codice de fogo interior ii
4267	codice de palavra sombria deixar escapar
4268	codice de cura ii
4269	codice de prece de cura
4270	codice de cura ii
4271	codice de punicao sagrada v
4272	codice de protecao sagrada
4273	codice de cura
4274	codice de fuga divina
4275	codice de putrefacao da mente
4276	codice de palavra sombria deixar escapar ii
4277	codice de palavra sombria estontear ii
4278	minerio de pedra sangrenta inferior
4279	codice de palavra sombria dor v
4280	codice de palavra sagrada escudo iv
4281	codice de protecao sombria
4282	codice de dissipar magia ii
4283	codice de sono iii
4284	codice de punicao sagrada vi
4285	codice de palavra sagrada fortitude iv
4286	codice de prece de cura ii
4287	codice de anular doenca ii
4288	codice de remover maldicao ii
4289	sal
4290	bacia de poeira
4291	fio de seda
4292	molde bolsa de la verde
4293	molde colete de couro do montanhista
4294	molde cinto do montanhista
4295	molde luvas de couro de costura dupla velho
4296	molde omoplatas de couro escuro
4297	molde luvas barbarescas
4298	molde cinto do guardiao
4299	molde armadura do guardiao
4300	molde bracadeiras de couro do guardiao
4301	molde cinto barbaresco
4302	adaga verde pequena
4303	espancador craniano
4304	couro grosso
4305	peca de seda
4306	seda
4307	luvas pesadas de linho
4308	bracadeiras de linho verde
4309	culotes de linho costurados a mao
4310	luvas pesadas de la
4311	manto pesado de la
4312	botas de linho de sola macia
4313	botas de la vermelhas
4314	omoplatas de la em ponto duplo
4315	omoplatas reforcadas de linho
4316	calcas pesadas de la
4317	calcas da fenix
4318	luvas de meditacao
4319	luvas de seda lazuli
4320	botas de sedaracna
4321	sapatilhas de seda de aranha
4322	capucho do encantador
4323	capuz das sombras
4324	colete de seda lazuli
4325	botas do encantador
4326	manto longo sedoso
4327	manto gelado
4328	cinto da aranha
4329	cinto das estrelas
4330	camisa vermelha estilosa
4331	luvas da fenix
4332	camisa amarela berrante
4333	camisa de seda preta
4334	camisa branca formal
4335	camisa luxuosa de seda roxa
4336	camisa preta do espadachim
4337	seda grossa de aranha
4338	magitrama
4339	peca de magitrama
4340	pigmento cinza
4341	pigmento amarelo
4342	pigmento roxo
4343	calcas de linho marrom
4344	camisa de linho marrom
4345	molde botas de la vermelhas
4346	molde manto pesado de la
4347	molde omoplatas reforcadas de linho
4348	molde luvas da fenix
4349	molde calcas da fenix
4350	molde sapatilhas de seda de aranha
4351	molde capuz das sombras
4352	molde botas do encantador
4353	molde cinto da aranha
4354	molde camisa luxuosa de seda roxa
4355	molde manto gelado
4356	molde cinto das estrelas
4357	po explosivo grosseiro
4358	dinamite grosseira
4359	punhado de parafusos de cobre
4360	bomba grosseira de cobre
4361	tubo de cobre
4362	cano de atirar rudimentar
4363	modulador de cobre
4364	po explosivo granuloso
4365	dinamite granulosa
4366	boneco alvo
4367	carga pequena de cequatrum
4368	oculos de tigre voador
4369	bacamarte mortal
4370	bomba grande de cobre
4371	tubo de bronze
4372	cano de atirar feito com carinho
4373	oculos sombrios
4374	bomba pequena de bronze
4375	tranqueira zumbidora de bronze
4376	defletor de chamas
4377	po explosivo pesado
4378	dinamite pesada
4379	espingarda folheada a prata
4380	bomba grande de bronze
4381	rebotocador menor
4382	estrutura de bronze
4383	rifle miraluna
4384	ovelha explosiva
4385	oculos tintos de verde
4386	defletor de gelo
4387	escora de ferro
4388	raio abotocador
4389	giroscronatom
4390	granada de ferro
4391	kit de ceifa colheitas compacto
4392	boneco alvo avancado
4393	monoculo do artifice
4394	bomba grande de ferro
4395	mina terrestre goblinica
4396	dragonete mecanico
4397	dispositivo ocultador gnomico
4398	carga grande de cequatrum
4399	coronha de madeira
4400	coronha pesada
4401	caixa de esquilo mecanico
4402	pequena bolsa de chamas
4403	morteiro portatil de bronze
4404	contato de prata
4405	mira rudimentar
4406	mira padrao
4407	mira de precisao
4408	diagrama esquilo mecanico
4409	diagrama carga pequena de cequatrum
4410	diagrama oculos sombrios
4411	diagrama defletor de chamas
4412	diagrama rifle miraluna
4413	diagrama raio abotocador
4414	diagrama morteiro portatil de bronze
4415	diagrama monoculo do artifice
4416	diagrama mina terrestre goblinica
4417	diagrama carga grande de cequatrum
4419	pergaminho do intelecto iii
4421	pergaminho de protecao iii
4422	pergaminho do vigor iii
4424	pergaminho do espirito iii
4425	pergaminho de agilidade iii
4426	pergaminho de forca iii
4428	palpo de aranha
4429	ordens do fundafuria
4430	talisma etereo
4432	carta de floriano caxias
4433	envelope ensopado
4434	calcas de espantalho
4435	particula de myzrael
4436	faixa incrustada de joias
4437	cajado do canalizador
4438	bracadeiras de pugilista
4439	clava do bordoeiro
4440	signo de strom
4441	pinga de mackreel
4443	brafoneiras inflexiveis
4444	escudo de casca preta
4445	escava carne
4446	lamina peconha negra
4447	manto da noite
4448	carapaca de naraxis
4449	presa de naraxis
4450	fragmento de signo
4453	signo de thoradin
4454	garra de vultros
4455	arnes de pelego de raptor
4456	cinto de pelego de raptor
4457	asa de urubu grelhada
4458	signo de arathor
4459	osso quebradico de dragao
4460	cincha alada rasgada
4461	pelego de raptor
4462	manto de putrefacao
4463	colar de contas de raptor
4464	botas espancadoras
4465	manoplas punho de osso
4466	signo de matatroll
4467	signo de ignaeus
4468	trol kalar embainhada
4469	bastao de ordem
4470	madeira simples
4471	pederneira e lenha
4472	pergaminho de myzrael
4473	grilhoes sobrenaturais
4474	arco de madeira de corvo
4476	veste do caminhante ferino
4477	broquel nefasto
4478	perneiras de escama iridescente
4479	patua ardente
4480	patua trovejante
4481	patua pontudo
4482	pasta lacrada
4483	chave ardente
4484	chave troante
4485	chave trovejante
4487	mapas da extravagancia da donzela
4488	mapas do espirito de pinhaprata
4489	diario de bordo da extravagancia da donzela
4490	diario de bordo do espirito de pinhaprata
4491	oculos para cacar gemas
4492	gema elfica
4493	gemas elficas
4494	carta lacrada do chifre do mar
4495	amuleto de pedra sangrenta
4496	bolsa marrom pequena
4497	bolsa marrom pesada
4498	bolsa de couro marrom
4499	saco marrom enorme
4500	mochila do viajante
4502	amostra de gema elfica
4503	presa de cascasseca
4504	manto de guarda anao
4505	calcas das terras pantanosas
4506	insignia de stromgarde
4507	escudo do lutador do fosso
4508	armadura tingida de sangue
4509	luvas lobo do mar
4510	orbe de pedra sangrenta conspurcado
4511	martelo agua negra
4512	olho de raptor do planalto
4513	coracao de raptor
4514	apelo de sara caxias
4515	cabeca de marez
4516	cabeca de otto
4517	cabeca de falcocrista
4518	fragmento de pergaminho rasgado
4519	fragmento de pergaminho amassado
4520	fragmento de pergaminho chamuscado
4521	granito de alterac
4522	bolsa medicinal de cascasseca
4524	memorial a caxias
4525	varinha de evocacao de trelane
4526	amuleto de garra de raptor
4527	agata lazuli
4528	orbe de tor gan
4529	agata encantada
4530	filacterio de trelane
4531	orbe de trelane
4532	agata de fogo de trelane
4533	carta lacrada para o arquimago malin
4534	bracadeiras com fecho de aco
4535	anel comemorativo de altaforja
4536	maca vermelha brilhante
4537	banana de tel abim
4538	melancia estala vinha
4539	maca casca dourada
4540	naco de pao duro
4541	pao fresquinho
4542	broa de milho molhadinha
4543	casquete de pele de draco branco
4544	pao condimentado de mulgore
4545	bracadeiras de prata radiante
4546	chamado do raptor
4547	fulminador gnomico
4548	marrao servomecanico
4549	elo fogo do mar
4550	anel agua fria
4551	cabeca de or kalar
4552	lasca de pedra lisa
4553	pedaco de pedra pontudo
4554	pedra polida brilhosa
4555	cauda escamosa grossa
4556	pedaco de concha manchada
4557	glandula abrasadora
4558	barril vazio
4559	chu s quest item
4560	cimitarra de qualidade
4561	machadinha de escalpelamento
4562	machado decepante
4563	clava do billy
4564	clava com pontas
4565	adaga simples
4566	bastao de luta resistente
4567	espada mercenaria
4568	machado do recruta
4569	martelo leal
4570	malho de betula
4571	faca de guerra
4575	cajado medicinal
4576	arco leve
4577	espingarda compacta
4580	presa de dente de sabre
4581	tufo de pele fino
4582	cauda pompom macia
4583	juba peluda grossa
4584	trofeu de pata gigante
4585	mandibula de aranha babujante
4586	pele lisa de raptor
4587	penas de raptor tribal
4588	cranio impoluto de raptor
4589	pena longa elegante
4590	bico amarelo curvado
4591	olho de aguia
4592	pargo da lama bocalonga
4593	bagre de bigode cerdoso
4594	bacalhau escama de pedra
4595	vinho selvavinha
4596	pocao descolorida de cura
4597	receita pocao descolorida de cura
4598	vara goblinica de pesca
4599	peca de presunto curado
4600	grogue de cereja
4601	pao de banana macio
4602	abobora da colheita lunar
4603	rabo amarelo mosqueado cru
4604	cogumelo da floresta
4605	cogumelo de bolinhas vermelhas
4606	morel esponjoso
4607	mofo de caverna delicioso
4608	trufa preta crua
4609	receita asa de urubu grelhada
4610	urna de pedra com gravuras
4611	perola azul
4612	coracao de draco preto
4613	caixa preta corroida
4614	pingente de myzrael
4615	bracadeiras de neracoite
4616	picareta da sorte de ryedol
4621	bracadeira do embaixador infernus
4622	bilhete lacrado para o conselheiro belgrum
4623	pocao inferior de escudopetreo
4624	receita pocao de escudopetreo inferior
4625	ignidea
4626	estilhaco pequeno de pedra
4627	laje grande
4628	bracadeiras de liga de pedra
4629	caixote de suprimentos
4630	sucata
4631	tabuleta de ryun eh
4632	cofre de bronze ornado
4633	cofre de bronze pesado
4634	cofre de ferro
4635	amuleto do pe de malho
4636	cofre robusto de ferro
4637	cofre de aco
4638	cofre de aco reforcado
4639	alga marinha encantada
4640	signo da terra
4641	mao de dagun
4643	capa de aco inexoravel
4644	o coracao da heranca
4645	grilhoes de hematus
4646	estrela de xil yeh
4647	compendio de yagyin
4648	signo do martelo
4649	bilhete de agarrosso
4650	bilhete de bel dugur
4652	escudo salbac
4653	botas talao de ferro
4654	fossil misterioso
4655	carne de marisco gigante
4656	abobora pequena
4658	manto do guerreiro
4659	cinturao do guerreiro
4660	botas de caminhada
4661	dragonas brilhantes
4662	manto do profissional
4663	cinto do profissional
4665	manto queimado
4666	cinto de couro queimado
4668	manto encadeado de batalha
4669	cinturao encadeado de batalha
4671	manto ancestral
4672	cinto ancestral
4674	manto tribal
4675	cinto tribal
4676	manoplas esqueleticas
4677	manto do veterano
4678	cinturao do veterano
4680	manto salobro
4681	cinturao salobro
4683	manto mesmerizador
4684	cinto mesmerizador
4686	manto de tecido barbaresco
4687	cinto de tecido barbaresco
4689	manto de caca
4690	cinto de caca
4692	manto cerimonial
4693	cinto cerimonial de couro
4694	brafoneiras lustradas
4695	manto lustrado
4696	caneca bebemares de lapidis
4697	cinturao lustrado
4698	dragonas do vidente
4699	cinto do vidente
4700	espaldares de couro inscritos
4701	manto inscrito
4702	picareta do prospector
4703	ferramentas quebradas
4705	brafoneiras bruxuleantes de escama
4706	manto bruxuleante de escama
4707	cinturao bruxuleante de escama
4708	cinto brilhante
4709	dragonas de couro da floresta
4710	manto da floresta
4711	manto furta cor
4712	cinturao de malha furta cor
4713	manto de fio de prata
4714	faixa de fio de prata
4715	manto brasonado
4716	manto de combate
4717	cinto de combate de malha
4718	dragonas do ceu noturno
4719	manto do ceu noturno
4720	faixa do ceu noturno
4721	dragonas com insignia
4722	manto com insignia
4723	calcas do humberto
4724	elmo do humberto
4725	brafoneiras do brigadeiro chefe
4726	manto do brigadeiro chefe
4727	cinturao do brigadeiro chefe
4728	ombreiras do toninho
4729	dragonas da aurora
4731	palas glificas
4732	manto glifico
4733	brafoneiras forja negra
4734	dragonas enevoadas
4735	manto enevoado
4736	faixa enevoada
4737	espaldares imperiais de couro
4738	cinto imperial de couro
4739	carne de pinote
4740	pena de pinote
4741	perneiras de cavalaria de stromgarde
4742	pelagem de puma da montanha
4743	estilhaco cristalino pulsante
4744	bracadeiras arcanas com runas
4745	bracadeiras de manticora de batalha
4746	veste do agourento
4747	agua do poco touro tormenta
4748	agua do poco tromparrubra
4749	agua do poco juba agreste
4751	garra de ventofuria
4752	pena lazuli
4753	pena bronze
4755	jarra d agua
4756	pelagem de gato arruinada
4757	casca rachada de ovo
4758	pata de lobo da pradaria
4759	garra de pinote
4763	arco recurvo de bosquenero
4765	espada larga esmaltada
4766	lamina feral
4767	luvas de trama cuprica
4768	luvas do adepto
4769	trofeu de calamo de rapineiro
4770	cinto de costagulha
4771	manto da colheita
4772	manto calido
4775	bico rachado
4776	pena ericada
4777	malho de pau ferro
4778	maca pesada com pontas
4779	dente fosco de kodo
4780	fragmento de chifre de kodo
4781	colete sussurrante
4782	veste do solsticio
4783	totem do vento do falcao
4784	pedra sem vida
4785	cinto sulfureo
4786	cinto do homem sabio
4787	piche ardente
4788	botas ageis
4789	botas estaveis
4790	manto infernal
4791	agua encantada
4792	manto dos espiritos
4793	manto silvestre
4794	bracadeiras do lobo
4795	bracadeiras do urso
4796	bracadeiras da coruja
4797	manto igneo
4798	manto runico pesado
4799	manto antiquado
4800	calcas encadeadas potentes
4801	garras de espreitador
4802	garras de puma
4803	dente de lobo da pradaria alfa
4804	coracao de lobo da pradaria
4805	femur de puma das estepes
4806	escama de pinote
4807	moela de rapineiro
4808	pedra de poco
4809	pinhambar
4810	ombreiras do penedo
4813	coleira de couro pequena
4814	presa descolorida
4816	perneiras do legionario
4817	espadao abencoado
4818	espada do carrasco
4819	prancheta do geringonca
4820	broquel do guardiao
4821	broquel do urso
4822	disco da coruja
4823	agua dos videntes
4824	machado sujo
4825	machado caloso
4826	machado do espoliador
4827	cinto do teurgo
4828	cinto do vento noturno
4829	cinto do sonhador
4830	perneiras do sabre
4831	calcas de espreitar
4832	sarongue mistico
4833	omoplatas gloriosas
4834	documentos da empreendimentos s a
4835	omoplatas de elite
4836	orbe a prova de fogo
4837	forca de vontade
4838	orbe do poder
4840	baioneta longa
4841	chifre de arra chea
4843	pedra runica de ametista
4844	pedra runica de opala
4845	pedra runica de diamante
4846	engrenagem nº 5
4847	grilhoes de laco elemental do lotwil
4848	focinho de javalico
4849	flanco de javalico
4850	plano de ataque dos costagulha
4851	mapa sujo de terra
4852	bomba de clarao
4854	manto marcado por demonios
4855	unused cloth shoulder a01 gray
4856	ombreira de tecido nao usada a02 amarela
4857	ombreira de tecido nao usada b01 prata
4858	ombreira de tecido nao usada a02 preta
4859	medalhao da lamina ardente
4860	escama fulgida de farnesim
4861	tunica de plumas
4862	cauda de escorpideo operario
4863	ferramentas gnomicas
4864	cranio de minshina
4865	pelagem arruinada
4866	cabeca do zalazane
4867	perna quebrada de escorpideo
4869	garra do bulho
4870	retalho de lona
4871	colar calcinante
4872	olho seco de escorpideo
4873	craca dura e seca
4874	espinhas limpas
4875	osso enlameado
4876	botas de couro ensanguentadas
4877	ponta de flecha de pedra
4878	arco quebrado manchado de sangue
4879	carcaca de coelho esmagado
4880	lanca quebrada
4881	envelope envelhecido
4882	chave de bento
4883	ordens do almirante proudmore
4886	vesicula de veneno de caudaconha
4887	olho de makrura intacto
4888	muco de rastejante
4890	ovo de acoitacauda
4891	amuleto de kron
4892	pele de tigre de durotar
4893	presa de leao da savana
4894	rim de pinote
4895	cifre de lagarto trovejante
4896	figado de kodo
4897	glandula salivar de falcotrom
4898	glandula relampejante
4903	olho da sombra ardente
4904	antidoto para caudaconha
4905	garra mutilada de sarkoth
4906	botas do pe d agua
4907	tunica do bosque
4908	bracadeiras nomades
4909	perneiras do cacador de kodos
4910	luvas encadeadas pintadas
4911	broquel de casca grossa
4913	cinto encadeado pintado
4914	luvas de couro desgastadas em batalha
4915	botas de casimira
4916	colete de casimira
4917	perneiras encadeadas desgastadas em batalha
4918	saco de suprimentos
4919	cinto de casimira
4920	capa desgastada em batalha
4921	perneiras empoeiradas
4922	colete encadeado serrilhado
4923	machadinha primitiva
4924	clava primitiva
4925	navalha primitiva
4926	barril vazio do chen
4928	munhequeiras do corredor da areia
4929	armadura escorpidea leve
4930	bolsa de couro artesanal
4931	arco curto de nogueira
4932	corta asa de harpia
4933	manto do lutador experiente
4935	cinturao largo de metal
4936	botas sujas de barro
4937	broquel de carga
4938	cajado de madeira manchado
4939	espada bastarda firme
4940	guantes velados
4941	cola grudenta a beca
4942	botas de pelego de tigre
4944	manto costurado a mao
4945	cranio levemente faiscante
4946	botas leves
4947	adaga serrilhada
4948	maca pungente
4949	cutelo orc
4951	cinto do grunhido
4952	malte do trovao
4953	cerveja trogg
4954	cinto nomade
4957	porta moedas velho
4958	manto insolado
4959	machadinha de arremesso
4960	projetil faiscante
4961	cajado do velador de sonhos
4962	luvas de duas camadas
4963	manto chifre troante
4964	esmaga goblin
4965	machado pequeno casco sangrento
4966	cabeca do mazzranache
4967	escudo do guerreiro tribal
4968	arnes atado
4969	guarda bracos reforcados
4970	perneiras rusticas de kodo
4971	martelo de skorn
4972	botas do corremontes
4973	munhequeiras do cacador das planicies
4974	punhal de combate
4975	broquel vigilante
4976	kilt brumaceiro
4977	espada de ruina do martelo
4978	martelo de ryedol
4979	bracadeiras de panopetreo encantadas
4980	luvas de prospector
4981	bornal de cinto de agmundo
4982	cinturao rasgado de prospector
4983	pulverizador de rochas
4984	cranio do destino iminente
4986	pedra do poder defeituosa
4987	espada de capitao dos anoes
4988	elo obsidiano ardente
4989	veste de dragao mago
4990	embraces calcinados
4992	carta de recrutamento
4995	carta de recrutamento assinada
4998	anel de sangue
4999	vontade de azora
5000	anel de coral
5001	anel do coracao
5002	talisma verde faiscante
5003	medalhao de cristal do fogo estelar
5004	marca do kirin tor
5005	pingente brasardente
5006	diario de khazgorm
5007	anel de espinhos
5008	anel de mercurio
5009	anel pasmante
5010	anel de ouro inscrito
5011	anel celeste
5012	esporos de fungos
5013	bulbo fertil
5014	wrapping paper pt
5015	wrapped item pt
5016	calcas do artifice
5017	nitroglicerina
5018	polpa de madeira
5019	nitrato de sodio
5020	chave do butim de kolkar
5021	banana de dinamite de gann
5022	cabeca do findekodo
5023	cabeca do verog
5024	ampola gelida
5025	cabeca do hezrul
5026	piche igneo
5027	esporos entregues
5028	cetro de lorde sakrasis
5029	talisma do lorde naga
5030	bracadeiras de centauro
5038	lagrima das luas
5040	faca de cacador sombrio
5042	papel de embrulho com fita vermelha
5043	presente com fita vermelha
5044	presente com fita azul
5045	presente de cranio
5046	presente fechado
5047	papel de embrulho de caveira
5048	papel de embrulho com fita azul
5049	papel ferro autotrancante
5050	chave de ignicao
5051	ratoupeira
5052	ratoupeira inconsciente
5054	rebimboca
5055	chifre intacto de raptor
5056	amostra de raiz
5057	melancia madura
5058	ovo de silitideo
5059	garra de escavacao
5060	ferramentas de ladroes
5061	prata roubada
5062	cabeca de raptor
5063	presa de kreenig rosnento
5064	garra de asabruxa
5065	anel de tenente harpia
5066	planta da fenda
5067	cabeca da serena
5068	sementes secas
5069	varinha de fogo
5071	varinha sombria
5072	cranio de lok
5073	cranio de nak
5074	cranio de kaz
5075	estilhaco de sangue
5076	carregamento de botas
5077	lente telescopica
5078	medalha de theramore
5079	olho frio de basilisco
5080	livro caixa do gasganete
5081	bolsa de pelego de kodo
5082	couro fino de kodo
5083	molde bolsa de pelego de kodo
5084	cabeca do barao longacosta
5085	presa de javatusco costagulha
5086	cascos de zevra
5087	bico de pinote
5088	manual de operacao do console de controle
5089	chave do painel
5092	varinha de crinavalha carbonizada
5093	punhal crinavalha
5094	escudo de guerra crinavalha
5095	albacora arco iris
5096	garras de predador
5097	esmeralda olho de gato
5098	casco alterado de mordelisca
5099	casco de lakota mani
5100	pelego de echeyaki
5101	presa de ishamuhale
5102	ponta da cauda de owatanka
5103	pena de anhan guera
5104	coracao de isha awak
5105	capsula explosiva
5107	camisa de marujo
5108	couro ferro negro
5109	farrapos dos lascapedra
5110	veste do teurgo de dalaran
5111	capa do rathorian
5112	lamina de ritual
5113	marca da camarilha
5114	garra decepada
5115	furcula quebrada
5116	pena longa de cauda
5117	pluma vibrante
5118	dente grande e chato
5119	cabelos finos soltos
5120	pelo de cauda longo
5121	escama suja de kodo
5122	pelo grosso de kodo
5123	ponta de flecha de aco
5124	dente pequeno de raptor
5125	escama carregada
5126	conhecimento disfarce defias
5127	conhecimento mascara de pirata dos mares do sul
5128	pele de lagarto caida
5129	conhecimento disfarce de anao ferro negro
5130	conhecimento disfarce de teurgo de dalaran
5131	conhecimento disfarce dos lascapedra
5132	conhecimento disfarce da camarilha
5133	moela pingante
5134	pequena pata peluda
5135	garra preta fina
5136	orelha peluda arrancada
5137	globo ocular brilhante
5138	cabeca do segador
5139	livro de espinhos
5140	po de clarao
5141	livro de recrescimento
5142	livro de ira ii
5143	sangue de lagarto trovejante
5145	livro de toque de cura ii
5147	livro de raizes enredantes ii
5148	livro de espinhos ii
5149	livro de ira iii
5150	livro de toque de cura iii
5151	livro de ira iv
5152	livro de toque de cura iv
5153	livro de marca do indomado iv
5154	livro de espinhos iii
5155	livro de marca do indomado ii
5156	livro de ira v
5158	livro de tranquilidade
5160	livro de toque de cura v
5163	livro de marca do indomado iii
5164	asas de falcotrom
5165	pena de helioscamo
5166	vesicula de peconha de lenhateia
5167	ovo de lenhateia
5168	semente de muscoide
5169	broto de muscoide
5170	tumor musguento
5172	capsula da morte
5173	vinha da morte
5174	bilhete de neeru
5175	totem da terra
5176	totem do fogo
5177	totem da agua
5178	totem do ar
5179	coracao enroscado em musgo
5180	colar da harmonia
5181	capa de seda vibrante
5182	lamina do calafrio
5183	coracao pulsante de hidra
5184	frasco de cristal cheio
5185	frasco de cristal
5186	recipiente parcialmente cheio
5187	martelo de rhahk zor
5188	recipiente cheio
5189	fruta brilhante
5190	fronde cintilante
5191	farpa cruel
5192	lamina do ladrao
5193	capa da irmandade
5194	machado do capataz
5195	luvas salpicadas de ouro
5196	aniquilador do castiga
5197	amaciante do cuca
5198	cajado mexedor do cuca
5199	calcas de fundicao
5200	arpao de empalamento
5201	cajado da pedra incandescente
5202	pulover do corsario
5203	garra de predador das estepes
5204	cinto plumassangue
5205	fronde desenvolvida
5206	raiz de brejicola
5207	varinha opaca
5208	varinha fumegante
5209	varinha merencoria
5210	varinha incandescente
5211	varinha do crepusculo
5212	varinha fulgurante
5213	varinha calcinante
5214	varinha do entardecer
5215	varinha incandescente
5216	varinha do umbral
5217	coracao maculado
5218	coracao purificado de muscoide
5219	casca de arvore inscrita
5220	presa de masca pinho
5221	cabeca de malinus
5223	gema de mana vazia
5227	joia de mana vazia
5229	pedra sangrenta maior vazia
5232	pedra da alma menor
5233	pedra de relu
5234	fossil do pancacheia
5235	varinha do alquimista
5236	varinha inflamavel
5237	veneno entorpecente
5238	varinha resinada
5239	varinha de osso preto
5240	varinha de luz da tocha
5241	vara lume enanica
5242	varinha de cinzas
5243	arrota fogos
5244	varinha consagrada
5245	varinha do evocador
5246	bastao de escavacao
5247	bastao da tristeza
5248	varinha faiscante
5249	lasca ardente
5250	varinha carbonizada
5251	frasco de videncia
5252	varinha de apodrecimento
5253	disparador goblinico
5254	espaldares rusticos
5255	machadinha javatusca
5256	chocalho do kovork
5257	capa com capuz escura
5259	monstro arco vermelho
5263	fiapo de bolso
5264	ficha de cerveja gratis
5265	cerveja aguada
5266	olho de adaegus
5267	cris escarlate
5268	casca rachada de silitideo
5269	linfa silitidea
5270	cogumelo cicuta
5271	galho de piolho
5272	rabiscos malucos
5273	reliquia de mathistra
5274	dragonas rosas
5275	cinturao do vinculo
5279	esfolador de harpia
5299	luvas da lua
5302	broquel de cobalto
5306	cajado da manticora
5309	mosquete do corsario
5310	culotes de lobo do mar
5311	botas com fivelas
5312	manoplas rebitadas
5313	anel do cla totemico
5314	capa do cacador de javalis
5315	guarda bracos das terras florestais
5316	tunica de couraca lenhosa
5317	tunica de musgo seco
5318	machado de zhovur
5319	brafoneiras espancadoras
5320	botas lamelares acolchoadas
5321	espada curta elegante
5322	martelo da demolicao
5323	lanterna do brilho eterno
5324	martelo do engenheiro
5325	escudo de soldagem
5326	bastao igneo
5327	calcas graxentas do faz tudo
5328	cinto cingido
5329	estatueta de gato
5330	reliquia de taca elfica
5332	estatueta de gato faiscante
5334	xerez de 99 anos
5335	saco de moedas
5336	brinco de capeta
5337	luvas da jornada
5338	selo antigo de pedra da lua
5339	ofidea
5340	mexedor de caldeirao
5341	tunica coberta de esporos
5342	ponche de raptor
5343	manto de taberneiro
5344	machado pontudo
5345	martelo de petralenha
5346	arco de batalha orquico
5347	varinha pestilenta
5348	pergaminho gasto
5349	muffin conjurado
5350	agua conjurada
5351	anel do cacador de recompensas
5352	livro os poderes de baixo
5353	mensagem para elissa brisastral
5354	carta para dinis
5355	cinturao do senhor das feras
5356	bastao de marcar
5357	protetor do vale
5359	manuscrito de lorgalis
5360	reliquia dos altaneiros
5361	palito de dente de espinha de peixe
5362	brinquedinho de morder
5363	lenco dobrado
5364	pedra de sal seca
5366	gema animica faiscante
5367	ferramenta primitiva de rocha
5368	carteira vazia
5369	osso roido
5370	colher torta
5371	pedaco de coral
5373	patua da sorte
5374	relogio de bolso pequeno
5375	graveto para cocar
5376	espelho quebrado
5377	concha de vieira
5379	faca de bota
5380	carta lacrada para elissa
5381	carta lacrada para balthule
5382	pingente de anaya
5383	cabeca do athrikus narassin
5385	pata de rastejante
5386	pelagem de espreitaluna fina
5387	manto encantado de espreitaluna
5388	cranio de ran dente sangrento
5389	totem de pelurso corrompido
5390	mensagem de fandral
5391	terra rara
5392	adaga de pau cardo
5393	cajado de pau cardo
5394	luvas de treinamento em arco e flecha
5395	escudo do bosque
5396	chave da garganta abrasadora
5397	polvora defias
5398	perneiras das frondes
5399	botas de rastrear
5400	sangue de cobrahn
5401	sangue de pitias
5402	sangue de sucurina
5403	sangue de serpentis
5404	omoplatas da serpente
5405	manto drapejado
5406	pedra sangrenta menor vazia
5411	totem de purificacao casco invernal
5412	olho de mangual
5413	presa de espreitaluna
5414	escalpo grisalho
5415	totem de purificacao chifre troante
5416	totem de purificacao juba agreste
5419	bracadeiras ferais
5420	armadura da banshee
5421	encantamento de labareda abrasadora
5422	perneiras de erva espinho
5423	presa de jibohm
5424	estatueta ancestral
5425	cinturao de escama runica
5426	beijo da serpente
5427	relogio de bolso bruto
5428	um livro de receitas exotico
5429	uma pedra bonitinha
5430	quinquilharia trabalhada
5431	odre vazio
5432	cachimbo de nogueira
5433	boneca de pano
5435	bruguzumba brilhante
5437	cabelo de bathran
5439	aljava pequena
5440	garrafa de molestia
5441	bornal pequeno para projeteis
5442	cabeca de arugal
5443	broquel de placas de ouro
5444	capa do minerador
5445	anel de zoram
5446	bracadeira elemental quebrada
5447	bracadeira elemental danificada
5448	bracadeira elemental fraturada
5451	bracadeira elemental esmagada
5455	pergaminho vaticinado
5456	pergaminho divinatorio
5457	garra de vodu partida
5458	cinto bosque de terra
5459	machado defensor
5460	cura de orendil
5461	ramo de cenarius
5462	bastao de transformacao de dartol
5463	gema faiscante
5464	haste de ferro
5465	perna pequena de aranha
5466	aguilhao de escorpideo
5467	carne de kodo
5468	carne macia de farnesim
5469	carne de moa
5470	rabo de lagarto trovejante
5471	carne de cervo
5472	kebab kaldorei de aranha
5473	escondidinho de escorpideo
5474	carne assada de kodo
5475	chave de madeira
5476	file de farnesim
5477	ensopado de moa
5478	ensopado de ratoupeira
5479	rabo de lagarto crocante
5480	carne magra de caca
5481	chifres de satiro
5482	receita kebab kaldorei de aranha
5483	receita escondidinho de escorpideo
5484	receita carne assada de kodo
5485	receita file de farnesim
5486	receita ensopado de moa
5487	receita ensopado de ratoupeira
5488	receita rabo de lagarto crocante
5489	receita carne magra de caca
5490	cabeca de iracauda
5493	lagrima de eluna
5494	punhado de poeira estelar
5498	perolinha lustrosa
5500	perola iridescente
5503	carne de marisco
5504	carne de marisco pungente
5505	diario de teronis
5506	talo de olhinho vil
5507	luneta ornada
5508	pedra da lua caida
5509	pedra de vida
5510	pedra de vida maior
5511	pedra de vida inferior
5512	pedra de vida menor
5513	jade de mana
5514	agata de mana
5516	presa de manguadonte
5517	chavinha de bronze
5518	chavinha de ferro
5519	castao de ferro
5520	diario de velinde
5521	chave de velinde
5522	pedra magica
5523	marisquinho com cracas
5524	marisco de casca grossa
5525	mariscos fervidos
5526	ensopado de marisco
5527	marisco a la goblin
5528	receita ensopado de marisco
5529	poeira de tumba
5530	po cegante
5533	tomo de ilkrud magthrull
5534	almoco do florestan
5535	compendio dos caidos
5536	mitologia dos titas
5537	cabeca do sarilus malnato
5538	alianca de casamento de vorrel
5539	carta de comenda
5540	adaga com cabo de madreperola
5541	martelo iridescente
5542	manto com fecho de perola
5543	instrucoes martelo iridescente
5544	cranio de dal sangarra
5547	bastao reconstruido
5565	pedra infernal
5566	galhada quebrada
5567	gancho de prata
5568	cascalho liso
5569	algas marinhas
5570	ovo de aranha de fundolimo
5571	bolsa preta pequena
5572	bolsa verde pequena
5573	bolsa de couro verde
5574	bolsa de couro branca
5575	saco verde grande
5576	saco marrom grande
5577	instrucoes bracadeiras rusticas de bronze
5578	instrucoes peitoral de bronze prateado
5579	martelo de guerra de milicia
5580	martelo de milicia
5581	cajado liso de viagem
5582	seiva das torres de pedra
5583	escama de dragao encantado
5584	bigodes de felino do crepusculo
5585	olho de corcel
5586	lamina de pau cardo
5587	clava raiz espinhosa
5588	toxina do lindolfo
5589	manoplas cobertas de musgo
5590	bracadeiras de cordao
5591	capa manchada de chuva
5592	cinturao acorrentada
5593	broquel rochedo
5594	carta para jin zil
5595	martelo da mata
5596	arco de freixo
5601	bolsa de ovos chocados
5602	teia grudenta de aranha
5603	saco de aniagem do lhogolho
5604	varinha elfica
5605	faca de podar
5606	luvas de jardinagem
5608	capucho vivo
5609	cilha constante
5610	manto da rajada florestal
5611	lagrima de luto
5612	manilhas de hera
5613	cajado do purificador
5614	golpe de seraph
5615	espada do mateiro
5616	rancatripa
5617	perneiras do vagabundo
5618	manto do batedor
5619	frasco de jade
5620	ampola de sangue inocente
5621	frasco de turmalina
5622	anel do clero
5623	frasco de ametista
5624	diadema da ordem
5626	lasca cranio
5627	lamina rara
5628	bilhete de zamah
5629	luvas de punho de martelo
5630	luvas toque de vento
5631	pocao de raiva
5632	pocao da fuga covarde
5633	pocao grandiosa de raiva
5634	pocao de acao desimpedida
5635	garra afiada
5636	pena delicada
5637	presa grande
5638	vaporizador toxico
5639	frasco de jade cheio
5640	receita pocao de raiva
5641	receita pocao da fuga covarde
5642	receita pocao de acao desimpedida
5643	receita pocao grandiosa de raiva
5644	tomo de conjurar agua
5645	frasco de turmalina cheio
5646	ampola de agua benta
5647	tomo de lampejo
5648	tomo de armadura gelida iii
5649	tomo de nevasca
5650	tomo de conjurar agua iii
5654	toxina instantanea
5655	redea de egua alaza
5656	redea de cavalo castanho
5657	receita toxina instantanea
5658	incunabulo selo do poder
5659	brasas fumegantes
5660	incunabulo selo da retidao
5661	incunabulo selo da retidao ii
5662	incunabulo selo da retidao iii
5663	trompa do lobo vermelho
5664	estilhacos corroidos
5665	trompa do lobo hediondo
5666	incunabulo selo da ira ii
5667	incunabulo selo da sabedoria ii
5668	trompa do lobo marrom
5669	destrocos do redemoinho de poeira
5670	incunabulo selo da ira iv
5671	incunabulo selo do poder iii
5672	incunabulo exorcismo
5673	incunabulo exorcismo ii
5674	incunabulo exorcismo iii
5675	escamas cristalizadas
5676	incunabulo detectar morto vivo
5677	incunabulo esconjurar morto vivo
5678	incunabulo selo do sacrificio
5679	incunabulo selo da sabedoria iii
5680	incunabulo selo da protecao ii
5681	seiva corrosiva
5682	incunabulo esconjurar morto vivo ii
5683	incunabulo escudo divino ii
5684	incunabulo selo da salvacao
5685	incunabulo redencao
5686	cabeca de ornanos
5687	chave do guardiao do portal
5689	chave do adormecido
5690	chave da garra
5691	chave da ermida
5692	detonador remoto vermelho
5693	detonador remoto azul
5694	explosivos ng 5 vermelho
5695	explosivos ng 5 azul
5696	tabuleta de choque
5697	tabuleta de totem curativo
5698	tabuleta de escudo de raios
5699	tabuleta de lobo fantasma
5700	tabuleta de totem curativo ii
5701	tabuleta de totem sentinela
5702	tabuleta de totem agitador ii
5703	tabuleta de trovoada
5704	tabuleta de respiracao aquatica
5705	tabuleta de totem curativo iii
5706	tabuleta de totem serpente iii
5707	tabuleta de visao distante
5708	tabuleta de forma eterea
5709	tabuleta de andar sobre a agua
5710	tabuleta de totem curativo iv
5711	tabuleta de lobo fantasma ii
5712	tabuleta de totem serpente iv
5713	tabuleta de seta trovejante
5714	tabuleta de totem enredante ii
5715	tabuleta de tempestade de raios iii
5716	tabuleta de restauracao vi
5717	cartas da empreendimentos s a
5718	plano de engenharia da empreendimentos s a
5719	grimorio de drenar vida ii
5720	grimorio de maldicao de mannoroth ii
5721	grimorio de criar pedra magica
5722	grimorio de sugar mana ii
5723	grimorio de maldicao de sargeras iii
5724	grimorio de maldicao de linguas
5725	grimorio de pestilencia iii
5726	grimorio de criar pedra sangrenta maior
5727	grimorio de funil de mana
5728	grimorio de chuva de fogo ii
5729	grimorio de medo iii
5730	livro de rejuvenescimento
5731	pergaminho de mensagem
5732	ng 5
5733	minerio nao identificado
5734	diagramas do super ceifador 6000
5735	envelope selado
5736	braco mecanico do hanfritz
5737	plano de operacoes secretas alfa & beta
5738	mochila de operacoes secretas
5739	arnes barbaresco
5740	foguete de fogos de artificio vermelhos
5741	lasca de rocha
5742	adaga com pedra preciosa
5743	anel de pedraprisma
5744	escalpelo palido
5748	arco longo de centauro
5749	machado foice
5750	cinturao do chefe guerreiro
5751	manto de teiasa
5752	ponta de cauda de manticora
5753	camalha ericada
5754	medalhao da alcateia
5755	peitoral de onix retalhador
5756	lamina talhada
5757	clava de madeira dura
5758	cofre de mithril
5759	cofre de torio
5760	cofre de eternio
5761	marreta de sidermar
5762	bolsa de linho vermelha
5763	bolsa de la vermelha
5764	mochila de seda verde
5765	mochila de seda preta
5766	veste inferior do teurgo
5767	vestes violeta
5768	ingresso para a corrida de gnomos
5769	ingresso para a corrida de goblins
5770	vestes de arcana
5771	molde bolsa de linho vermelha
5772	molde bolsa de la vermelha
5773	molde vestes de arcana
5774	molde mochila de seda verde
5775	molde mochila de seda preta
5776	bengala do anciao
5777	machado do valente
5778	bengala primitiva
5779	espada bastarda dos renegados
5780	cinto de escama de murloc
5781	peitoral de escama de murloc
5782	armadura grossa de murloc
5783	bracadeiras de escama de murloc
5784	escama viscosa de murloc
5785	escama grossa de murloc
5786	molde cinto de escama de murloc
5787	molde peitoral de escama de murloc
5788	molde armadura grossa de murloc
5789	molde bracadeiras de escama de murloc
5790	diario do monocelha
5791	diario de henrig monocelha
5792	medalhao da talhaflanco
5793	coracao da talhaflanco
5794	peconha salgada de escorpideo
5795	casco endurecido de tartaruga
5796	barbatana de cauda incrustada
5797	lamina de indurio
5798	pecas de carro foguete
5799	encomenda de pecas de kravel
5800	pecas de kravel
5801	guano de morcego
5802	pecas frageis de carro
5803	particula de po onirico
5804	rumores goblinicos
5805	coracao do fanatismo
5806	cerveja escura do tonto
5807	relatorio sobre cerveja escura do tonto
5808	vesicula de peconha de asaltiva
5809	vesicula de peconha de alcandora
5810	carcaca fresca
5811	juba de bocarragelo
5812	vestes da antiguidade
5813	marca de emilio
5814	armadura riacho estrondoso
5815	pedra glacial
5816	luz de eluna
5817	arco lunaris
5818	varinha raio lunar
5819	coifa ardessol
5820	dragonas feericas
5821	botas do espreita treva
5822	manoplas semente de sebe
5823	cogumelo venenoso
5824	tabuleta da vontade
5825	pingente de treshala
5826	plano de kravel
5827	carta de xabu latafuso
5829	bico afiadissimo
5830	cabeca de kenata
5831	cabeca de fardel
5832	cabeca de marcel
5833	minerio de indurio
5834	rape de mok morokk
5835	beberagem de mok morokk
5836	cofre de mok morokk
5837	costela do estalaco
5838	pergaminho de pele de kodo
5839	pagina de diario
5840	lingua calcinante
5841	coracao calcinante
5842	amostra nao refinada de minerio
5843	garra da grenka
5844	fragmentos de rok alim
5845	flanco de carne
5846	bilhete selado de korran
5847	cabeca de lamapina
5848	osso oco de abutre
5849	caixote de capacetes de protecao
5850	bilhete selado de belgrom
5851	chave do cosella
5852	esquemas do regulador de combustivel
5853	carapaca intacta de silitideo
5854	garra de silitideo
5855	coracao de silitideo
5857	caixa de premios de gnomo
5858	caixa de premios de goblin
5859	granada de festa
5860	legado dos aspectos
5861	inicio da ameaca dos mortos vivos
5862	foguete de cequatrum
5863	contrato de guilda
5864	carneiro cinza
5865	foguete de cequatrum modificado
5866	amostra de minerio de indurio
5867	frasco cinzelado
5868	frasco cinzelado cheio
5869	casco fendido
5871	casco grande
5872	carneiro marrom
5873	carneiro branco
5874	arnes carneiro preto
5875	arnes carneiro azul
5876	tuberculo folhazul
5877	carapaca rachada de silitideo
5878	super rape
5879	pingente do crepusculo
5880	caixote com furos
5881	cabeca de kelris
5882	documentos do capitao
5883	lingua bifurcada de pedralama
5884	olho nevoa negra inteiro
5897	manual de proprietario do fungafuca
5916	chave de camera gnomica
5917	relatorio do espiao
5918	cabeca de orc desafiante
5919	escudo de ferro enegrecido
5936	cinto de pele de animal
5937	chave de camera goblinica
5938	pata impecavel de rastejante
5939	luvas de costura
5940	broquel de osso
5941	calcas de escama de latao
5942	pingente adornado
5943	bracadeiras da fenda
5944	grevas da milicia do povo
5945	dente de mortocharco
5946	bilhete lacrado para eling
5947	sumula defias
5948	carta a jorge
5949	pedaco de papel
5950	distintivo de reethe
5951	toalhinha umida
5952	tronco encefalico corrompido
5956	martelo de ferreiro
5957	colete de couro feito a mao
5958	calcas de couro de qualidade
5959	vesicula de peconha acida
5960	bilhete lacrado para o vigia backor
5961	calcas de couro escuro
5962	calcas do guardiao
5963	perneiras barbarescas
5964	omoplatas barbarescas
5965	manto do guardiao
5966	luvas do guardiao
5967	cinturao de nobreza
5968	botas rusticas
5969	manto do regente
5970	luvas da serpente
5971	capa de penas
5972	molde calcas de couro de qualidade
5973	molde perneiras barbarescas
5974	molde manto do guardiao
5975	cinto do rufiao
5976	tabardo de guilda
5996	elixir de respiracao aquatica
5997	elixir de defesa menor
5998	pedido de lancatroz
6016	amostra de coracao de lobo
6037	barra de veraprata
6038	torresmo de marisco gigante
6039	receita torresmo de marisco gigante
6040	bracadeiras de escama dourada
6041	corrente de arma de aco
6042	espigao de escudo de ferro
6043	contrapeso de ferro
6044	instrucoes espigao de escudo de ferro
6045	instrucoes contrapeso de ferro
6046	instrucoes corrente de arma de aco
6047	instrucoes coifa de escama dourada
6048	pocao de protecao contra a sombra
6049	pocao de protecao contra o fogo
6050	pocao de protecao contra o gelo
6051	pocao de protecao contra o sagrado
6052	pocao de protecao contra a natureza
6053	receita pocao de protecao contra o sagrado
6054	receita pocao de protecao contra a sombra
6055	receita pocao de protecao contra o fogo
6056	receita pocao de protecao contra o gelo
6057	receita pocao de protecao contra a natureza
6058	cinto de couro enegrecido
6059	colete nomade
6060	bracadeiras de linhao
6061	bracadeiras pedragris
6062	bracadeiras de corda grossa
6063	manoplas de aco frio
6064	discos de platina miniatura
6065	ensaios de hadggar sobre convergencia dimensional
6066	cabeca de khan dez hepah
6067	orelha de centauro
6068	receita oleo de sombra
6069	carne mal desidratada
6070	bracadeiras de pele de lobo
6071	cristal de draenetista
6072	cabeca de khan jehn
6073	cabeca de khan shaka
6074	boquilha da corneta de guerra
6075	relatorio de valente
6076	calcas afuniladas
6077	fragmento de chave dos maraudinos
6078	escudo do piqueiro
6079	patua grosseiro
6080	coracao de pantera das sombras
6081	fungo do senhor do brejo
6082	tumor passofundo
6083	lagrimas partidas
6084	perneiras da guarda de ventobravo
6085	tunica de soldado raso
6086	soro da verdade do faustino
6087	calcoes do cerro oeste
6089	cerveja de zaerdus
6091	caixote de pedras de poder
6092	botas de dragonete negro
6093	esmaga orc
6094	machado perfurante
6095	botas do errante
6096	camisa do aprendiz
6097	camisa do acolito
6098	veste do neofito
6116	veste do aprendiz
6117	camisa do escudeiro
6118	calcas do escudeiro
6119	veste do neofito
6120	camisa do recruta
6121	calcas do recruta
6122	botas do recruta
6123	veste do novico
6124	calcas do novico
6125	arnes do brigao
6126	calcas do coureador
6127	botas do coureador
6129	veste do acolito
6130	camisa do coureador
6131	calcas do coureador
6132	incunabulo selo da sabedoria
6133	incunabulo selo da furia
6134	poncho primitivo
6135	kilt primitivo
6136	camisa do capanga
6137	calcas do capanga
6138	botas do meliante
6139	veste do novico
6140	veste do aprendiz
6144	veste do neofito
6145	pingente da clarice
6146	madeira flutuante seca ao sol
6147	cinto velho e roto
6148	botas cobertas de teia
6149	pocao maior de mana
6150	um no gasto
6166	mandibula de coiote
6167	relatorio de nika
6168	garra de tartalisca dentesserra
6169	anca nao tratada de dentesserra
6170	reagentes do teurgo
6171	luvas do tratador de lobos
6172	suprimentos perdidos
6173	botas de neve
6174	espada aleatoria do twain
6175	artefato atal ai
6176	escudo ogival enanico
6177	bracadeiras de ferro martelado
6178	remessa para etergarde
6179	capa do corsario
6180	pelecapto
6181	fetiche de hakkar
6182	tocha apagadica
6183	tocha inferior apagada
6184	perna de rastejante monstruoso
6185	xale de urso
6186	fatiador trogg
6187	defensor enanico
6188	pisoteadores da lama
6189	omoplatas encadeadas duraveis
6190	estilhaco de draenetista
6191	botas kimbra
6192	cabeca de khan hratha
6193	saco de artefatos atal ai
6194	ceifadeira de tanoeiro
6195	armadura polida com cera
6196	clava de noboru
6197	colete de couro de crocolisco lacustre
6198	munhequeiras jurassicas
6199	elo da viuva negra
6200	cinto de guerra do garbeg
6201	botas flexiveis
6202	luvas sem dedos
6203	escudo velhaco
6204	elmo tribal worg
6205	pa escavadora
6206	lascador de rocha
6207	jxj planta da torre da horda
6208	jxj planta da torre da alianca
6209	jxj escritura de mina da horda
6210	jxj escritura de mina da alianca
6211	receita elixir de forca do ogro
6212	cabeca de jammal an
6214	malho pesado de cobre
6215	vara de luta balanceada
6216	polvora mistica
6217	bastao de cobre
6218	bastao runico de cobre
6219	chave de arco voltaico
6220	estilhaco de meteoro
6222	formula encantamento menor de espirito torso
6223	escudo de vila sombria
6226	avental ensanguentado
6232	monstro item flor buque rosas
6233	monstro item flor buque flores do campo
6237	monstro item flor buque rosas negras
6238	veste de linho marrom
6239	colete de linho vermelho
6240	colete de linho azul
6241	veste de linho branca
6242	veste de linho azul
6243	veste de la verde
6244	ggggfg
6245	algibeira de karnitol
6246	garra furiodio
6247	chifre furiodio
6248	peconha de scorpachi
6249	pelego envelhecido de kodo
6250	cerebro de canisvil
6251	asa eterea
6252	sangue do guardiao da ruina
6253	encomenda de sinismago
6256	vara de pescar
6257	moela de roca
6258	figado de veloferreo
6259	figado de groddoc
6260	pigmento azul
6261	pigmento laranja
6262	diario de galeno
6263	jardineira azul
6264	veste do grandioso adepto
6265	estilhaco de alma
6266	colete do discipulo
6267	calcas do discipulo
6268	tunica do pioneiro
6269	calcas do pioneiro
6270	molde colete de linho azul
6271	molde colete de linho vermelho
6272	molde veste de linho azul
6273	molde veste de la verde
6274	molde jardineira azul
6275	molde veste do grandioso adepto
6276	bilhete mofado
6277	pergaminho mofado
6278	pergaminho mofado
6279	carta mofada
6280	missiva mofada
6281	cranio de range ossos
6282	calcas do sepultamento sagrado
6283	o livro de ur
6284	runas de evocacao
6285	grimorio de egalin
6286	coracoes puros
6287	fragmento de tabuleta atal ai
6288	tabuleta atal ai
6289	pargo da lama bocalonga cru
6290	peixinho brilhante
6291	peixinho brilhante cru
6292	pargo da lama de 5 quilos
6293	sangue seco de morcego
6294	pargo da lama de 6 quilos
6295	pargo da lama de 7 quilos
6296	tufo de pelos de morcego
6297	cranio velho
6298	presa ensanguentada de morcego
6299	peixe com aparencia doentia
6300	fragmento de carcaca
6301	cranio velho do condutor
6302	asa delicada de inseto
6303	cavala deslizapele crua
6304	pagina umida de diario dia 4
6305	pagina umida de diario dia 87
6306	pagina umida de diario dia 512
6307	mensagem na garrafa
6308	bagre de bigode cerdoso cru
6309	bagre de 8 quilos
6310	bagre de 9 quilos
6311	bagre de 11 quilos
6312	coracao de dalin
6313	coracao de comar
6314	capa do mestre dos lobos
6315	besta flechaco
6316	delicia de farnesim lacustre
6317	farnesim lacustre cru
6318	cajado de meridiano de odo
6319	cinturao do vigia cego
6320	escudo do comandante
6321	selo da familia silverlaine
6323	cetro do barao
6324	vestes de arugal
6325	receita peixinho brilhante
6326	receita cavala deslizapele
6327	o pacificador
6328	receita pargo da lama bocalonga
6329	receita delicia de farnesim lacustre
6330	receita bagre de bigode cerdoso
6331	lamina uivante
6332	anel de perola negra
6333	adaga acoitagulha
6335	botas cinzentas
6336	tunica de infantaria
6337	perneiras de infantaria
6338	bastao de prata
6339	bastao runico de prata
6340	pelego de fenrus
6341	lanterna lugubre de estabulo
6342	formula encantamento menor de mana torso
6343	formula encantamento de espirito torso
6344	formula encantamento menor de espirito bracadeiras
6345	formula encantamento de protecao manto
6346	formula encantamento inferior de mana torso
6347	formula encantamento menor de forca bracadeiras
6348	formula encantamento menor de matador de feras arma
6349	formula encantamento inferior de intelecto arma de 2m
6350	botas rusticas de bronze
6351	caixote amassado
6352	caixote encharcado
6353	bau pequeno
6354	bau pequeno trancado
6355	bau resistente trancado
6356	bau desgastado
6357	caixote selado
6358	bocanera oleoso
6359	pargo pinafogo
6360	peixe maca escamaco
6361	albacora arco iris crua
6362	bacalhau escama de pedra cru
6363	bagre de 13 quilos
6364	bagre de 16 quilos
6365	vara de pescar forte
6366	vara de pescar lenhanegra
6367	grande vara de pescar de ferro
6368	receita albacora arco iris
6369	receita bacalhau escama de pedra
6370	oleo de bocanera
6371	oleo igneo
6372	pocao de velocidade de nado
6373	elixir de poder de fogo
6374	po encantado
6375	formula encantamento inferior de espirito bracadeiras
6376	formula encantamento menor de vigor botas
6377	formula encantamento menor de agilidade botas
6378	capa do vidente
6379	cinto de couro inscrito
6380	broquel inscrito
6381	manto brilhante
6382	cinto de couro da floresta
6383	broquel da floresta
6384	camisa azul estilosa
6385	camisa verde estilosa
6386	guarda pernas de malha luzentes
6387	bracadeiras de malha luzentes
6388	brafoneiras de malha luzentes
6389	touca de malha luzente
6390	molde camisa azul estilosa
6391	molde camisa verde estilosa
6392	cinto de arugal
6393	luvas de fio de prata
6394	botas de fio de prata
6395	sobreveste de fio de prata
6396	peito d armas brasonado
6397	luvas brasonadas
6398	cinto brasonado
6399	omoplatas brasonadas
6400	escudo luzente
6401	molde camisa de seda preta
6402	perneiras de combate de malha
6403	guarda bracos de combate de malha
6404	espaldares de combate de malha
6405	calcas do ceu noturno
6406	botas do ceu noturno
6407	munhequeiras do ceu noturno
6408	luvas com insignia
6409	cinto com insignia
6410	bracadeiras com insignia
6411	armadura do brigadeiro chefe
6412	botas do brigadeiro chefe
6413	bracadeiras do brigadeiro chefe
6414	selo de sylvana
6415	veste da aurora
6416	botas da aurora
6417	manto da aurora
6418	faixa da aurora
6419	luvas glificas
6420	botas glificas
6421	cinto glifico
6422	elmo glifico
6423	grevas forja negra
6424	capa forja negra
6425	cinturao forja negra
6426	bracadeiras forja negra
6427	veste enevoada
6428	luvas enevoadas
6429	chapeu de teurgo enevoado
6430	peitoral imperial de couro
6431	botas imperiais de couro
6432	manto imperial
6433	elmo imperial de couro
6435	gema ardente infusa
6436	gema ardente
6438	bracadeira elemental fraca
6439	bracadeira atadora quebrada
6440	acoita cerebro
6441	escalpo de assombrante
6442	cristal de oraculo
6443	pelego anormal
6444	lingua bifurcada
6445	exuvia quebradica
6446	bolsa de couro de cobra
6447	escudo gasto de casco de tartaruga
6448	espinho de cauda
6449	manto faiscante de escama de lagarto
6450	bandagem de seda
6451	bandagem grossa de seda
6452	antipeconha
6453	antipeconha forte
6454	manual antipeconha forte
6455	roda antiga de vagao
6456	visgo acido
6457	pecas de engenharia enferrujadas
6458	peixe coberto de oleo
6459	pisantes selvagens
6460	agarra de cobrahn
6461	ombreiras incrustadas de visgo
6462	caixote fechado
6463	anel da suma profundeza
6464	essencia ululante
6465	veste de caninana
6466	manto de escama anormal
6467	luvas de escama anormal
6468	cinto de escama anormal
6469	golpe venenoso
6470	escama anormal
6471	escama anormal perfeita
6472	vibora pungente
6473	armadura da presa
6474	molde manto de escama anormal
6475	molde luvas de escama anormal
6476	molde cinto de escama anormal
6477	faixa da campina
6478	pisoteadores pisa ratos
6479	pingente de malem
6480	perneiras anormais lustrosas
6481	manoplas lamacentas
6482	botas andachama
6486	escama chamuscada
6487	cabeca de demonio familiar vil
6488	tabuleta simples
6489	pergaminho deteriorado
6490	pergaminho escuro
6491	pergaminho pesado
6492	pergaminho tisnado
6493	pergaminho esfarrapado
6494	pergaminho rabiscado
6495	pergaminho castigado pelo tempo
6496	pergaminho detalhado
6497	pergaminho simples
6498	couro de kodo inscrito
6499	couro de kodo inscrito
6500	couro de kodo inscrito
6501	couro de kodo inscrito
6502	armadura de escama violeta
6503	vestes do arlequim
6504	laminasa
6505	cajado crescente
6506	botas de infantaria
6507	bracadeiras de infantaria
6508	manto de infantaria
6509	cinto de infantaria
6510	manoplas de infantaria
6511	veste do profissional
6512	veste do discipulo
6513	faixa do discipulo
6514	manto do discipulo
6515	luvas do discipulo
6516	pergaminho de evocar diabrete
6517	cinto do pioneiro
6518	botas do pioneiro
6519	bracadeiras do pioneiro
6520	manto do pioneiro
6521	luvas do pioneiro
6522	peixe anormal
6523	arnes amassado
6524	arnes de couro cravejado
6525	arnes do bruto
6526	arnes de batalha
6527	veste ancestral
6528	veste do mesmerizador
6529	micanga brilhosa
6530	reptantes
6531	veste de tecido barbaresca
6532	iscas brilhantes
6533	pega peixes aquadinamico
6534	barras de aco forjado
6535	tabuleta de verga
6536	colete do salgueiro
6537	botas do salgueiro
6538	veste do salgueiro
6539	cinto do salgueiro
6540	calcas do salgueiro
6541	luvas do salgueiro
6542	capa do salgueiro
6543	bracadeiras do salgueiro
6544	pergaminho de evocar emissario do caos
6545	armadura do soldado
6546	perneiras do soldado
6547	manoplas do soldado
6548	cinturao do soldado
6549	manto do soldado
6550	munhequeiras do soldado
6551	botas do soldado
6552	tunica do bardo
6553	calcas do bardo
6554	luvas do bardo
6555	manto do bardo
6556	bracadeiras do bardo
6557	botas do bardo
6558	cinto do bardo
6559	broquel do bardo
6560	escudo do soldado
6561	armadura acolchoada do vidente
6562	botas cintilantes
6563	bracadeiras cintilantes
6564	manto cintilante
6565	luvas cintilantes
6566	sobreveste cintilante
6567	armadura cintilante
6568	calcas cintilantes
6569	veste cintilante
6570	faixa cintilante
6571	broquel de observacao
6572	escudo do defensor
6573	botas de defensor
6574	bracadeiras de defensor
6575	manto do defensor
6576	cinturao do defensor
6577	manoplas do defensor
6578	perneiras do defensor
6579	espaldares do defensor
6580	tunica do defensor
6581	cinto de observacao
6582	botas de observacao
6583	bracadeiras de observacao
6584	tunica de observacao
6585	manto de observacao
6586	luvas de observacao
6587	calcas de observacao
6588	espaldares de observacao
6589	anel viridiano
6590	botas forja da batalha
6591	munhequeiras forja da batalha
6592	armadura forja da batalha
6593	manto forja da batalha
6594	cinturao forja da batalha
6595	manoplas forja da batalha
6596	guarda pernas forja da batalha
6597	guarda ombros forja da batalha
6598	broquel do dervixe
6599	escudo forja da batalha
6600	cinto do dervixe
6601	botas do dervixe
6602	bracadeiras do dervixe
6603	tunica do dervixe
6604	capa do dervixe
6605	luvas do dervixe
6607	perneiras do dervixe
6608	armadura brilhante
6609	traje do sabio
6610	veste do sabio
6611	faixa do sabio
6612	botas do sabio
6613	bracadeiras do sabio
6614	manto do sabio
6615	luvas do sabio
6616	calcas do sabio
6617	dragonas do sabio
6619	manual o caminho da defesa
6620	pergaminho elaborado
6621	manual de provocar
6622	espada do zelo
6623	pergaminho de evocar sucubo
6624	trago do ken zigla
6625	pingente coberto de terra
6626	pingente de dogran
6627	peitoral de escamas mutantes
6628	gadanhos do corvo
6629	capa esporifera
6630	broquel da nuvem de sementes
6631	raiz viva
6632	manto de escama encantada
6633	fatiador do acougueiro
6634	unguento de ritual
6635	sapta da terra
6636	sapta do fogo
6637	sapta da agua
6638	sapta do ar
6640	casco de espreitador vil
6641	lamina de assombracao
6642	armadura fantasma
6643	peixinho inchado
6644	cavala inchada
6645	pargo da lama inchado
6646	albacora inchada
6647	bagre inchado
6648	pergaminho de totem litopele
6649	pergaminho de totem calcinante
6650	pergaminho de totem de torrente curativa
6651	garrafa de vinho quebrada
6652	bornal de reagentes
6653	tocha da chama latente
6654	tocha da chama eterna
6655	brasa faiscante
6656	quartzo grosseiro
6657	delicia de peixe anormal
6658	colar de amostra
6659	calcas do escaravelho
6660	adaga de julie
6661	receita delicia de peixe anormal
6662	elixir de crescimento gigantesco
6663	receita elixir de crescimento gigantesco
6664	dragonas vodu
6665	bracadeiras bagateadas
6666	botas de mourejar
6667	manto do engenheiro
6668	botas do escrevente
6669	anel sagrado
6670	armadura da pantera
6671	perneiras do implacavel
6672	diagrama bomba de clarao
6675	bracadeiras temperadas
6676	broquel do condestavel
6677	varinha de feiticaria
6678	anel do donaire elfico
6679	fura armadura
6681	punhal espinhado
6682	vestes do morta voz
6684	bastao de adestramento do fungafuca
6685	dragonas do morta voz
6686	elmo com presas
6687	cria cadaver
6688	cocar murmureolo
6689	cajado espirito do vento
6690	perneiras ferinas
6691	adaga presa de suino
6692	aniquilador denteado
6693	gancho de agamaggan
6694	coracao de agamaggan
6695	amuleto de osso estigio
6696	arco espreitanoite
6697	dragonas quiropteras
6698	pedra de pierce
6707	pedra de lapidis
6708	pedra de bonhomme
6709	colete brilho da lua
6710	molde colete brilho da lua
6711	pedra de kurtz
6712	fechadura de exercicio
6713	calcas rasgadas
6714	dinamite taca facil
6715	cabo de chupeta arruinado
6716	diagrama dinamite taca facil
6717	deschanfrador
6718	eletromola
6719	cinto pairavento
6720	cocar do cacador espiritual
6721	guarda peito de kor
6722	algemas bestiais
6723	medalha de bravura
6724	pedra de backor
6725	broquel marmoreo
6726	cinto de seguranca personalizado do razzeric
6727	luvas de corrida do razzeric
6728	pedra do rosado
6729	isqueiro zippy do xabu
6730	corrente de altaforja
6731	peitoral de altaforja
6732	luvas do mecanico gnomico
6733	manoplas de altaforja
6734	instrucoes corrente de altaforja
6735	instrucoes peitoral de altaforja
6736	instrucoes manoplas de altaforja
6737	calcas folhasseca
6738	crescente sangrento
6739	mira do corredor do despenhadeiro
6740	faixa lazuli
6741	espada belica orquica
6742	cinturao punhopetreo
6743	anel do encorajamento
6744	luvas de kapelan
6745	capa do correleve
6746	broquel de basalto
6747	brafoneiras do impositor
6748	anel simio
6749	elo tigrino
6750	aro ofidio
6751	xale da lamentacao
6752	botas lanceiras
6753	patua de penas
6754	porta moedas grande
6755	pequena caixa de gemas
6756	porta joias
6757	anel sinete de jaina
6766	flayed demon skin old2
6767	pingente de tyranis
6773	corrente do espoliador gelkis
6774	dedo de uthek
6775	tomo de divindade
6776	tomo de valor
6777	tomo de retidao
6778	tomo de justica
6779	tomo de nobreza
6780	faixa lilas
6781	caneca do bartolino
6782	distintivo do delegado fadigas
6783	chave do dente podre
6784	protetores de mao reforcados
6785	poderes do caos
6786	vestido simples
6787	vestido branco de la
6788	cinto do cacador magram
6789	manta cerimonial do centauro
6790	anel da calma
6791	botas do desordeiro
6792	brafoneiras sanguineas
6793	bracadeiras auricas
6794	manoplas do fogo da tempestade
6795	camisa branca do espadachim
6796	camisa vermelha do espadachim
6797	fura olhos
6798	arcabuz explosivo
6799	cabeca de vejrek
6800	minerio umbratico
6801	avental barroco
6802	espada do agouro
6803	bordao profetico
6804	martelo ventempesta
6805	trompa de vorlus
6806	chama dancante
6807	ensopado de perna de sapo
6808	minerio de elunita
6809	medalhao de elura
6810	gargantilha de surena
6811	peixescopio aquadinamico
6812	caixote de elunita
6826	escama brilhante
6827	caixa de suprimentos
6828	broquel do visionario
6829	espada da serenidade
6830	morde ossos
6831	ameaca negra
6832	manto empesteado
6833	camisa branca de smoking
6834	smoking preto
6835	calca preta de smoking
6836	sapatos sociais
6837	vestido de noiva
6838	presa de aranha calcinada
6839	chifre calcinado
6840	chifre galvanizado
6841	ampola de flogisto
6842	instrucoes de furen
6843	barril de grogue
6844	sangue ardente
6845	pedra ardente
6846	carta de defias
6847	carta de ferro negro
6848	coral causticante
6849	casca queimada de sol
6850	escalpo de sanguescalpo
6851	essencia dos exilados
6852	olho eterno
6866	simbolo da vida
6887	rabo amarelo mosqueado
6888	ovo assado com ervas
6889	ovo pequeno
6890	carne de urso defumada
6891	receita ovo assado com ervas
6892	receita carne de urso defumada
6893	chave da oficina
6894	coracao rodopiante
6895	martelo de ferreiro de jardel
6897	manual caminho do berserker
6898	orbe de soran ruk
6899	orbe de bruxo 35
6900	robessangre dourado encantado
6901	capa do trilhador reluzente
6902	embraces de serra kis
6903	calcas do vislumbrador
6904	dentada de serra kis
6905	machado do recife
6906	punhos de algas
6907	armadura de tartaruga
6908	elo de ghamoo ra
6909	golpe da hidra
6910	calcas da sanguessuga
6911	cilha de musgo
6912	palocordio
6913	cerne de palocordio
6914	fragmento de soran ruk
6915	fragmento grande de soran ruk
6916	tomo de divindade
6926	notas de furen
6927	orelha do grande gui
6928	gargantilha de pedra sangrenta
6929	pergaminho de bath rah
6930	bastao de canalizacao
6931	tomo mofado
6947	veneno instantaneo
6948	pedra de regresso
6949	veneno instantaneo ii
6950	veneno instantaneo iii
6951	veneno entorpecente ii
6952	pele grossa de urso
6953	punho de verigan
6966	machado de elunita
6967	espada de elunita
6968	martelo de elunita
6969	adaga de elunita
6970	benevolencia de furen
6971	coifa endurecida pelo fogo
6972	cota endurecida pelo fogo
6973	perneiras temperadas pelo fogo
6974	manoplas endurecidas pelo fogo
6975	machado redemoinho
6976	martelo de guerra redemoinho
6977	espada redemoinho
6978	machado umbreo
6979	machado de fadigas
6980	adaga de fadigas
6981	adaga umbrea
6982	maca umbrea
6983	martelo do fadigas
6984	espada umbrea
6985	espada de fadigas
6986	lotus rubro
6987	escama de peixe
6988	pergaminho de evocar cacador vil
6989	ampola de sangue de furiodio
6990	pedra infernal menor
6991	carvao fumegante
6992	carregamento de minerio do jardel
6993	carregamento de minerio refinado do jardel
6994	madeira de carvalho de pedralva
6995	gema kor corrompida
6996	anotacoes do jardel sobre armas
6997	manuscrito rasgado
6998	botas nimbus
6999	tomo do conluio
7000	cinturao de alburno
7001	cetro da lapide
7002	broquel artico
7003	broches de besouro
7004	capa da prelacao
7005	faca de esfolamento
7006	tomo reformado
7007	pilhagem gorrda de backor
7026	cinto de linho
7027	botas da escuridao
7046	calcas de seda lazuli
7047	maos das trevas
7048	capuz de seda lazuli
7049	luvas da fe verdadeira
7050	bandana de seda
7051	colete terrano
7052	cinto de seda lazuli
7053	manto de seda lazuli
7054	veste do poder
7055	cinto de seda carmesim
7056	manto de seda carmesim
7057	omoplatas de seda verde
7058	colete de seda carmesim
7059	omoplatas de seda carmesim
7060	omoplatas lazuli
7061	cinto de seda terrano
7062	pantalonas de seda carmesim
7063	veste de seda carmesim
7064	luvas de seda carmesim
7065	armadura de seda verde
7067	terra elemental
7068	fogo elemental
7069	ar elemental
7070	agua elemental
7071	broquel de ferro
7072	escama de naga
7073	presa quebrada
7074	garra lascada
7075	nucleo da terra
7076	essencia da terra
7077	coracao de fogo
7078	essencia do fogo
7079	globo de agua
7080	essencia da agua
7081	sopro eolico
7082	essencia do ar
7083	gema de kor purificada
7084	molde omoplatas de seda carmesim
7085	molde omoplatas lazuli
7086	molde cinto de seda terrano
7087	molde manto de seda carmesim
7088	molde veste de seda carmesim
7089	molde manto de seda lazuli
7090	molde armadura de seda verde
7091	molde luvas da fe verdadeira
7092	molde maos das trevas
7093	molde botas da escuridao
7094	galho de madeira flutuante
7095	botas do brejo
7096	pena arrancada
7097	carne de coxa
7098	presa estilhacada
7099	tenaz partida
7100	linfa grudenta
7101	olho de inseto
7106	luvas do zodiaco
7107	cinturao estelar
7108	escudo de infantaria
7109	broquel do pioneiro
7110	armadura de fio de prata
7111	armadura do ceu noturno
7112	armadura da aurora
7113	armadura enevoada
7114	molde luvas de seda lazuli
7115	machado da heranca
7116	adaga de heranca
7117	martelo de heranca
7118	espada de heranca
7119	antena agitada
7120	baluarte do ruga
7126	lingote fumegante de ferro
7127	azurita pulverizada
7128	casco nao fendido de satiro
7129	manoplas brutais
7130	elmo brutal
7131	tibia de presa do dragao
7132	guarda pernas brutais
7133	cota brutal
7134	tibia firme de presa do dragao
7135	tibia quebrada de presa do dragao
7146	a chave escarlate
7148	cabo de chupeta goblinico
7166	adaga de cobre
7170	espada aleatoria do twain foo
7187	botas de vancleef
7188	escudo da guarda de ventobravo
7189	botas foguete goblinicas
7190	botas foguete calcinadas
7191	fiacao com fusivel
7192	diagrama botas foguete goblinicas
7206	amostra de agua do lago espelhado
7207	frasco de jennea
7208	chave de tazan
7209	algibeira de tazan
7226	treconitor magostatico
7227	boca de leao de balnir
7228	sorvete de morango de tigule
7229	colete do explorador
7230	martelo potente do castiga
7231	carta de apresentacao do astolfo
7247	bau de cofres de contencao
7249	gema energizada da fenda
7266	tratado de ur sobre umbromancia
7267	seda pura de aranha
7268	amostra de agua xaviana
7269	frasco de denya
7270	cabelo da irma risonha
7271	presa de marmore impecavel
7272	moracea carregada por raio
7273	vara totemica dos cascasseca
7274	rituais do poder
7275	os pergaminhos agamaggan
7276	manto de couro feito a mao
7277	bracadeiras de couro feitas a mao
7278	aljava de couro leve
7279	bornal de municao pequeno de couro
7280	calcas de couro rustico
7281	bracadeiras de couro leve
7282	calcas de couro leve
7283	manto de dragonete negro
7284	luvas de dragonete vermelho
7285	luvas ageis de couro
7286	escama de dragonete negro
7287	escama de dragonete vermelho
7288	molde calcas de couro rustico
7289	molde manto de dragonete negro
7290	molde luvas de dragonete vermelho
7291	orbe infernal
7292	cofre de contencao cheio
7293	gema de mana de dalaran
7294	livro caixa de andron
7295	caderno de tazan
7296	tocha apagada
7297	desgraca de morbidio
7298	lamina da astucia
7306	cabeca do fenwick
7307	verme come carne
7308	cantochao da manifestacao
7309	relatorio situacional de dalaran
7326	machado do thun grim
7327	adaga do thun grim
7328	maca do thun grim
7329	espada do thun grim
7330	broquel do infiltrador
7331	escudo da falange
7332	armadura regia
7333	apito do supervisor
7334	veste florescente
7335	tunica gris
7336	cota encadeada matagreste
7337	a pedra
7338	anel dos sentimentos
7339	anel com diamante minusculo
7340	diamante solitario impecavel
7341	anel de zirconia cubica
7342	anel de prata da agasterne
7343	chave de boca do gomez
7344	tocha da chama sagrada
7345	chave de fenda do gomez
7346	martelo do gomez
7347	inversor de engrenagem do gomez
7348	luvas do seteiro
7349	luvas do herborista
7350	bracadeiras do discipulo
7351	botas do discipulo
7352	omoplatas terranas de couro
7353	armadura acolchoada do anciao
7354	botas do anciao
7355	bracadeiras do anciao
7356	manto do anciao
7357	chapeu do anciao
7358	luvas do surrupiador
7359	luvas terranas pesadas
7360	molde luvas de couro escuro
7361	molde luvas do herborista
7362	molde omoplatas terranas de couro
7363	molde luvas do surrupiador
7364	molde luvas terranas pesadas
7365	engrenotreco gnomo
7366	luvas do anciao
7367	dragonas do anciao
7368	calcas do anciao
7369	veste do anciao
7370	faixa do anciao
7371	aljava pesada
7372	bornal de municao de couro pesado
7373	perneiras de couro crepuscular
7374	armadura de couro crepuscular
7375	armadura de dragonete verde
7376	detona cuca do gomez
7377	manto de couro gelido
7378	bracadeiras crepusculares
7386	bracadeiras de dragonete verde
7387	cinto crepuscular
7388	chave de cranio
7389	livro caixa da empreendimentos s a
7390	botas crepusculares
7391	botas velozes
7392	escama de dragonete verde
7406	cordao do infiltrador
7407	armadura do infiltrador
7408	omoplatas do infiltrador
7409	botas do infiltrador
7410	bracadeiras do infiltrador
7411	manto do infiltrador
7412	luvas do infiltrador
7413	casquete do infiltrador
7414	calcas do infiltrador
7415	espaldares do dervixe
7416	bracadeiras da falange
7417	botas da falange
7418	peitoral da falange
7419	manto da falange
7420	cimeira da falange
7421	manoplas da falange
7422	cinturao da falange
7423	perneiras da falange
7424	espaldares da falange
7425	cabeca do cyrik
7426	anel ceruleo
7427	talisma ceruleo
7428	pelego de gato das sombras
7429	armadura crepuscular
7430	veste crepuscular
7431	calcas crepusculares
7432	capucho crepuscular
7433	luvas crepusculares
7434	botas crepusculares
7435	dragonas crepusculares
7436	capa crepuscular
7437	manilhas crepusculares
7438	cinto crepuscular
7439	peitoral da sentinela
7440	calcas da sentinela
7441	casquete da sentinela
7442	chave de giramastro
7443	luvas da sentinela
7444	botas da sentinela
7445	omoplatas da sentinela
7446	manto da sentinela
7447	bracadeiras da sentinela
7448	cinturao da sentinela
7449	molde perneiras de couro crepuscular
7450	molde armadura de dragonete verde
7451	molde bracadeiras de dragonete verde
7452	molde botas crepusculares
7453	molde botas velozes
7454	peitoral do cavaleiro
7455	guarda pernas do cavaleiro
7456	cimeira do cavaleiro
7457	manoplas do cavaleiro
7458	botas do cavaleiro
7459	brafoneiras do cavaleiro
7460	manto do cavaleiro
7461	bracadeiras do cavaleiro
7462	cinturao do cavaleiro
7463	broquel da sentinela
7464	glifos de evocacao
7465	timbre do cavaleiro
7466	anel de cinabrio
7467	colar de cinabrio
7468	veste regia
7469	perneiras regias
7470	chapeu de teurgo regio
7471	luvas regias
7472	botas regias
7473	dragonas regias
7474	manto regio
7475	manilhas regias
7476	faixa regia
7477	tunica do patrulheiro
7478	perneiras do patrulheiro
7479	elmo do patrulheiro
7480	luvas do patrulheiro
7481	botas do patrulheiro
7482	omoplatas do patrulheiro
7483	manto do patrulheiro
7484	munhequeiras do patrulheiro
7485	cordao do patrulheiro
7486	peitoral do capitao
7487	perneiras do capitao
7488	diadema do capitao
7489	manoplas do capitao
7490	botas do capitao
7491	guarda ombros do capitao
7492	manto do capitao
7493	bracadeiras do capitao
7494	cinta do capitao
7495	broquel do capitao
7496	escudo de placa do campo de batalha
7497	anel de marfim
7498	parte de cima da chave de gelkak
7499	parte do meio da chave de gelkak
7500	parte de baixo da chave de gelkak
7506	controle remoto universal gnomico
7507	orbe arcano
7508	orbe meridiano
7509	veste de fios de mana
7510	vestes de fogo mistico inferior
7511	veste do no astral
7512	veste de renda eterea
7513	varinha iraflama
7514	varinha da furia glacial
7515	orbe celestial
7516	instrucoes de tabetha
7517	tunica de teia diafana
7518	veste de teia diafana
7519	calcas de teia diafana
7520	bacinete de teia diafana
7521	luvas de teia diafana
7522	botas de teia diafana
7523	ombreiras de teia diafana
7524	capa de teia diafana
7525	bracadeiras de teia diafana
7526	cinto de teia diafana
7527	peito d armas cabalistico
7528	perneiras cabalisticas
7529	elmo cabalistico
7530	luvas cabalisticas
7531	botas cabalisticas
7532	espaldares cabalisticos
7533	manto cabalistico
7534	bracadeiras cabalisticas
7535	cinto cabalistico
7536	muralha de protecao do campeao
7537	escudo gotico
7538	armadura do campeao
7539	perneiras do campeao
7540	capacete do campeao
7541	manoplas do campeao
7542	grevas do campeao
7543	brafoneiras do campeao
7544	capa do campeao
7545	bracadeiras do campeao
7546	cinturao do campeao
7547	anel de onix
7548	gargantilha de onix
7549	abraco da fada
7550	honra do guerreiro
7551	talisma entrelacado de opalina
7552	gancho do falcao
7553	anel do unicornio
7554	ramo de salgueiro
7555	estrela regia
7556	orbe crepuscular
7557	bastao de teia diafana
7558	baculo cintilante
7559	bordao runico
7560	diagrama controle remoto universal gnomico
7561	diagrama cabo de chupeta goblinico
7566	espada da familia agamand
7567	machado da familia agamand
7568	adaga da familia agamand
7569	maca da familia agamand
7586	esperanca de tharnariun
7587	instrucoes de thun grim
7606	manoplas polares
7607	varinha de zibelina
7608	caneco de qualidade do vidente
7609	baculo ambar do anciao
7610	esfera da aurora
7611	baculo enevoado
7613	molde armadura de couro verde
7626	trouxa de peles
7627	entrega para dolanaar
7628	carta comum
7629	fardo de ulkor
7646	caixote com provisoes para estalagem
7666	colar estilhacado
7667	frasco de videncia de didie
7668	diario manchado de sangue
7669	rubi do colar estilhacado
7670	safira do colar estilhacado
7671	topazio do colar estilhacado
7672	fonte de forca do colar estilhacado
7673	colar de aprimoramento do didie
7674	encomenda para mathias
7675	horario de embarque de defias
7676	cha de cardo
7678	receita cha de cardo
7679	presa de morcego corvoide
7680	escama de basilisco jadespinho
7681	estilhaco de golem de obsidiana
7682	aticador de tortura
7683	soqueira ensanguentada
7684	dragonas do mago sangrento
7685	orbe do vidente esquecido
7686	olho do espinha de ferro
7687	punho do espinha de ferro
7688	caixa toracica do espinha de ferro
7689	aurora morbida
7690	torno de ebano
7691	mortalha embalsamada
7708	varinha necrotica
7709	perneiras empesteadas
7710	vara de treinamento do lobato
7711	veste de doan
7712	dragonas de doan
7713	bastao do ilusionista
7714	lamina hipnotica
7715	relatorio de onin
7716	colar estilhacado
7717	assolador
7718	ombreiras de herodes
7719	elmo do berserker em furia
7720	chapeu do cristalba
7721	mao da retidao
7722	amuleto triuno
7723	poder de mograine
7724	manoplas da divindade
7726	egide do comandante escarlate
7727	brafoneiras do vigia
7728	vestes do cativador
7729	mosquete chesterfall
7730	esmagador de cobalto
7731	talisma do fragmento espectral
7733	cajado da pre historia
7734	bolsa seis demonios
7735	rosa de jannok
7736	clava da luta
7737	diario de sethir
7738	luvas perenes
7739	capa das terras florestais
7740	medalhao de gni kiv
7741	o bastao de tsol
7742	diagrama dispositivo ocultador gnomico
7746	comenda da liga de exploradores
7747	protetor torpe
7748	broquel pedraforte
7749	orbe omega
7750	dragonas do sofrimento
7751	botas do vorrel
7752	destruidor de sonhos
7753	espirra sangue
7754	botas do precursor
7755	omoplatas pedernais
7756	luvas de adestramento de caes
7757	cajado teceventos
7758	estoque impiedoso
7759	peito d armas do arconte
7760	kilt do chefe guerreiro
7761	aniquilador garra de aco
7766	odre marrom vazio
7767	odre azul vazio
7768	odre vermelho vazio
7769	odre marrom cheio
7770	odre azul cheio
7771	odre vermelho cheio
7786	rachacranio
7787	guardiao resplandecente
7806	pirulito
7807	barra de chocolate
7808	tablete de chocolate
7809	vestido de pascoa
7810	ampola da mais pura agua
7811	gotas restantes da mais pura agua
7812	bracadeiras da manifestacao corrupta
7813	estilhaco de agua
7846	presa de coiote do rochedo
7847	moela de urubu
7848	estilhaco de elemental da rocha
7866	recipiente de taumaturgia vazio
7867	recipiente com sangue de dragao
7868	thieven kit
7869	bau do lucius
7870	cofre com recipientes de taumaturgia
7871	simbolo de ladroagem
7872	ferramentas enferrujadas de ladroes
7886	diario nao traduzido
7887	colar e gema recuperados
7888	colar de aprimoramento do jarkal
7906	chifres de nez ra
7907	certificado de ladroagem
7908	diario de filipe pinel
7909	agua marinha
7910	rubi estrela
7911	minerio de veraprata
7912	pedra macica
7913	omoplatas de ferro barbarescas
7914	peitoral de ferro barbaresco
7915	elmo de ferro barbaresco
7916	botas de ferro barbarescas
7917	luvas de ferro barbarescas
7918	ombreiras pesadas de mithril
7919	manoplas pesadas de mithril
7920	calcas de escama de mithril
7921	calcas pesadas de mithril
7922	elmo de placa de aco
7923	chave da torre defias
7924	bracadeiras de escama de mithril
7925	luvas de escama de mithril
7926	calcas ornadas de mithril
7927	luvas ornadas de mithril
7928	ombreiras ornadas de mithril
7929	perneiras de guerra orquicas
7930	peitoral pesado de mithril
7931	coifa de mithril
7932	omoplatas de escama de mithril
7933	botas pesadas de mithril
7934	elmo pesado de mithril
7935	peitoral ornado de mithril
7936	botas ornadas de mithril
7937	elmo ornado de mithril
7938	manoplas veraprata
7939	peitoral veraprata
7941	machado pesado de mithril
7942	machado azul reluzente
7943	lamina malefica de mithril
7944	florete ofuscante de mithril
7945	grande maca preta
7946	martelo de mithril runico
7947	estoque de ebano
7948	cinturao de thero shan
7949	perneiras de thero shan
7950	armadura de thero shan
7951	maos de thero shan
7952	botas de thero shan
7953	mascara de thero shan
7954	o despedacador
7955	espadao de cobre
7956	martelo de guerra de bronze
7957	montante de bronze
7958	machado de batalha de bronze
7959	praga
7960	campea de veraprata
7961	lamina fantasma
7963	peitoral de aco
7964	pedra de afiar macica
7965	contrapeso macico
7966	pedra de amolar macica
7967	espigao de escudo de mithril
7968	tesouro dos mares do sul
7969	esporas de mithril
7970	b e c a
7971	perola negra
7972	linfa de morte viva
7973	marisco boca grande
7974	carne de marisco condimentada
7975	instrucoes calcas pesadas de mithril
7976	instrucoes espigao de escudo de mithril
7977	instrucoes luvas de escama de mithril
7978	instrucoes omoplatas de ferro barbarescas
7979	instrucoes peitoral de ferro barbaresco
7980	instrucoes elmo de ferro barbaresco
7981	instrucoes botas de ferro barbarescas
7982	instrucoes luvas de ferro barbarescas
7983	instrucoes calcas ornadas de mithril
7984	instrucoes luvas ornadas de mithril
7985	instrucoes ombreiras ornadas de mithril
7986	instrucoes peitoral ornado de mithril
7987	instrucoes elmo ornado de mithril
7988	instrucoes botas ornadas de mithril
7989	instrucoes esporas de mithril
7990	instrucoes elmo pesado de mithril
7991	instrucoes omoplatas de escama de mithril
7992	instrucoes machado azul reluzente
7993	instrucoes florete ofuscante de mithril
7994	instrucoes perneiras de guerra orquicas
7995	instrucoes bracadeiras de escama de mithril
7996	chapeu de pescaria usado
7997	mascara vermelha defias
8006	o candiru
8007	citrino de mana
8008	rubi de mana
8009	pedra de energia de dentrio
8026	tesouro da familia garreta
8027	tesouro do krom bracoforte
8028	instrucoes martelo de mithril runico
8029	instrucoes lamina malefica de mithril
8030	instrucoes estoque de ebano
8046	diario de marta
8047	campanula de fungo magenta
8048	apanhador de sonhos de esmeralda
8049	colar de masca pinho
8050	joia de tallonkai
8051	sinalizador
8052	pedra de energia de an alleum
8053	fonte de energia de obsidiana
8066	apito do arruela
8067	municao leve manufaturada
8068	municao pesada manufaturada
8069	chumbo macico manufaturado
8070	vale recompensa
8071	espeto de churrasco
8072	chave da torre de biela
8073	esconderijo da mistura adulterada do zanzil
8074	cabeca do gallywix
8075	pao azedo conjurado
8076	pao doce conjurado
8077	agua mineral conjurada
8078	agua borbulhante conjurada
8079	agua cristalina conjurada
8080	peito d armas leve de placa
8081	cinto leve de placa
8082	botas leves de placa
8083	bracadeiras leves de placa
8084	luvas leves de placa
8085	calcas leves de placa
8086	ombreiras leves de placa
8087	amostra de preparado adulterado de zanzil
8088	cinto de malha de placa
8089	botas de malha de placa
8090	bracadeiras de malha de placa
8091	luvas de malha de placa
8092	elmo de malha de placa
8093	perneiras de malha de placa
8094	armadura de malha de placa
8095	oleo do hinoto
8106	armadura hibernal
8107	botas hibernais
8108	bracadeiras hibernais
8109	manto hibernal
8110	luvas hibernais
8111	dragonas hibernais
8112	calcas hibernais
8113	veste hibernal
8114	faixa hibernal
8115	capucho hibernal
8116	cinto heraldico
8117	botas heraldicas
8118	bracadeiras heraldicas
8119	peitoral heraldico
8120	manto heraldico
8121	luvas heraldicas
8122	bacinete heraldico
8123	perneiras heraldicas
8124	espaldares heraldicos
8125	bracadeiras do mirmidao
8126	peitoral do mirmidao
8127	capa do mirmidao
8128	manoplas do mirmidao
8129	cinturao do mirmidao
8130	grevas do mirmidao
8131	elmo do mirmidao
8132	perneiras do mirmidao
8133	brafoneiras do mirmidao
8134	defensor do mirmidao
8135	escudo de cromita
8136	tumor gigantesco
8137	bracadeiras de cromita
8138	guarda peito de cromita
8139	manoplas de cromita
8140	cinturao de cromita
8141	grevas de cromita
8142	celada de cromita
8143	coxotes de cromita
8144	brafoneiras de cromita
8146	garra malefica
8147	chavinha de cobre
8148	chavinha de prata
8149	patua vodu
8150	sal rochafunda
8151	frasco de mojo
8152	frasco de mojo grande
8153	vinha selvagem
8154	escama de escorpideo
8155	sacrificio de sathrah
8156	munhequeiras do justador
8157	guarda peito do justador
8158	manoplas do justador
8159	cinturao do justador
8160	grevas do justador
8161	viseira do justador
8162	coxotes do justador
8163	brafoneiras do justador
8164	papel de carta de teste
8165	escama gasta de dragao
8167	escama de tartaruga
8168	pena azeviche
8169	pelego grosso
8170	couro rustico
8171	pelego rustico
8172	pelego grosso curado
8173	kit de armadura grossa
8174	chapeu confortavel de couro
8175	tunica da escapada noturna
8176	bandana da escapada noturna
8177	espada de exercicio
8178	espada de treino
8179	arco dos cadetes
8180	arco de caca
8181	rifle de caca
8182	rifle de chumbinho
8183	arco de precisao
8184	tacafogo
8185	perneiras de escama de tartaruga
8186	varinha severa
8187	luvas de escama de tartaruga
8188	espingarda explosiva
8189	peitoral de escama de tartaruga
8190	espada hanzo
8191	elmo de escama de tartaruga
8192	omoplatas da escapada noturna
8193	calcas da escapada noturna
8194	quebra nozes goblinico
8195	manto da escapada noturna
8196	cimitarra de ebano
8197	botas da escapada noturna
8198	bracadeiras de escama de tartaruga
8199	destruidor do campo de batalha
8200	veste do grande vodu
8201	mascara do grande vodu
8202	calcas do grande vodu
8203	peitoral escorpideo resistente
8204	luvas escorpideas resistentes
8205	bracadeiras escorpideas resistentes
8206	perneiras escorpideas resistentes
8207	omoplatas escorpideas resistentes
8208	elmo escorpideo resistente
8209	botas escorpideas resistentes
8210	omoplatas de couro silvestre
8211	colete de couro silvestre
8212	perneiras de couro silvestre
8213	botas de couro silvestre
8214	capacete de couro silvestre
8215	manto de couro silvestre
8216	manto do grande vodu
8217	aljava saca rapido
8218	bornal para municao de couro grosso
8223	lamina do basilisco
8224	estripador silitideo
8225	florete maldito
8226	o carniceiro
8243	biscoito do scooby
8244	esfera impecavel de draenetista
8245	tunica imperial vermelha
8246	botas imperiais vermelhas
8247	bracadeiras imperiais vermelhas
8248	manto imperial vermelho
8249	luvas imperiais vermelhas
8250	dragonas imperiais vermelhas
8251	calcas imperiais vermelhas
8252	veste imperial vermelha
8253	faixa imperial vermelha
8254	diadema imperial vermelho
8255	cinturao de couro de serpente
8256	botas de couro de serpente
8257	bracadeiras de couro de serpente
8258	armadura de couro de serpente
8259	manto de couro de serpente
8260	luvas de couro de serpente
8261	elmo de couro de serpente
8262	perneiras de couro de serpente
8263	espaldares de couro de serpente
8264	munhequeiras do bastiao de ebano
8265	armadura do bastiao de ebano
8266	manto do bastiao de ebano
8267	manoplas do bastiao de ebano
8268	cinturao do bastiao de ebano
8269	botas do bastiao de ebano
8270	capacete do bastiao de ebano
8271	perneiras do bastiao de ebano
8272	ombreiras do bastiao de ebano
8273	munhequeiras valorosas
8274	couraca valorosa
8275	broquel do bastiao de ebano
8276	manoplas valorosas
8277	cinturao valoroso
8278	grevas valorosas
8279	elmo valoroso
8280	guarda pernas valorosos
8281	brafoneiras valorosas
8282	escudo valoroso
8283	armadura arcana
8284	botas arcanas
8285	embraces arcanos
8286	manto arcano
8287	luvas arcanas
8288	ombreiras arcanas
8289	perneiras arcanas
8290	veste arcana
8291	faixa arcana
8292	mantel arcano
8293	cinto do viajante
8294	botas do viajante
8295	bracadeiras do viajante
8296	gibao do viajante
8297	manto do viajante
8298	luvas do viajante
8299	elmo do viajante
8300	perneiras do viajante
8301	espaldares do viajante
8302	bracadeiras do heroi
8303	peitoral do heroi
8304	capa do heroi
8305	manoplas do heroi
8306	cinto do heroi
8307	botas do heroi
8308	elo do heroi
8309	perneiras do heroi
8310	brafoneiras do heroi
8311	avambracos de placa de alabastro
8312	peitoral de alabastro
8313	broquel do heroi
8314	manoplas de placa de alabastro
8315	cinturao de placa de alabastro
8316	grevas de placa de alabastro
8317	capacete de placa de alabastro
8318	perneiras de placa de alabastro
8319	brafoneiras de placa de alabastro
8320	escudo de alabastro
8343	fio grosso de seda
8344	fiandeiras prateadas
8345	elmo cabeca de lobo
8346	manoplas do mar
8347	manoplas de escama de dragao
8348	elmo de fogo
8349	peitoral emplumado
8350	o 1 anel
8363	patua vodu de xama
8364	truta cabeca de mithril
8365	truta cabeca de mithril crua
8366	truta inchada
8367	peitoral de escama de dragao
8368	lupelego grosso
8383	carta simples
8384	molde chapeu confortavel de couro
8385	molde luvas de escama de tartaruga
8386	molde veste do grande vodu
8387	molde mascara do grande vodu
8388	molde manto da escapada noturna
8389	molde calcas do grande vodu
8390	molde manto do grande vodu
8391	mandibula de rasgarrindo
8392	pulmao de javali destrocado
8393	tenaz de escorpode
8394	cerebro de basilisco
8395	molde peitoral escorpideo resistente
8396	moela de abutre
8397	molde bracadeiras escorpideas resistentes
8398	molde luvas escorpideas resistentes
8399	molde botas escorpideas resistentes
8400	molde omoplatas escorpideas resistentes
8401	molde perneiras escorpideas resistentes
8402	molde elmo escorpideo resistente
8403	molde omoplatas de couro silvestre
8404	molde colete de couro silvestre
8405	molde capacete de couro silvestre
8406	molde botas de couro silvestre
8407	molde perneiras de couro silvestre
8408	molde manto de couro silvestre
8409	molde omoplatas da escapada noturna
8410	b o m b a
8411	coquetel de sumo de pulmao
8412	amostra de escorpode macerado
8423	composto de cortex cerebral
8424	chiclete de moela
8425	titica de papagaio
8426	pena grande ericada
8427	carcaca mutilada de rato
8428	glandula de orvalho cheia
8429	glandula de orvalho perfurada
8430	glandula de orvalho vazia
8431	bobina de seda chartreuse leve
8432	colonia de mixilpixil
8443	ornamento de gahz ridian
8444	chave do carrasco
8463	ordens do chefe guerreiro
8483	bolsa de agua do errante
8484	pacote de suprimentos da cia aguas de geringontzan
8485	transportador de gato bombaim
8486	transportador de gato cornish rex
8487	transportador de gato tigrado laranja
8488	transportador de gato tigrado prateado
8489	transportador de gato branco
8490	transportador de gato siames
8491	transportador de gato tigrado preto
8492	poleiro de papagaio arara da asa verde
8493	barrica do weegli
8494	poleiro de papagaio arara jacinto
8495	poleiro de papagaio senegal
8496	poleiro de papagaio cacatua
8497	caixote de coelho nevinhal
8498	dragonetinho esmeralda
8499	dragonetinho carmesim
8500	grande coruja com chifres
8501	falcoruja
8502	caixa de loteria de bronze
8503	caixa de loteria de bronze pesada
8504	caixa de loteria de ferro
8505	caixa de loteria de ferro pesada
8506	caixa de loteria de mithril
8507	caixa de loteria de mithril pesada
8508	barbatana grande
8523	kit de teste de campo
8524	modelo 4711 ktc fonte de energia
8525	ordem de compra da zilda
8526	tragao violeta
8527	kit de teste de campo lacrado
8528	po violeta
8529	elixir nublacuca
8543	cogumelo subaquatico
8544	bandagem de magitrama
8545	bandagem grossa de magitrama
8546	sais aromaticos poderosos
8547	formula sais aromaticos poderosos
8548	bastao divinomatico
8563	mecanostruz vermelho
8564	ovo de hipogrifo
8583	trompa da montaria descarnada
8584	treco de coleta vazio
8585	treco de coleta cheio
8586	apito do raptor vermelho mosqueado
8587	pedacos de inseto centiparte
8588	apito do raptor esmeralda
8589	apito velho do raptor marfim
8590	apito velho do raptor obsidiano
8591	apito do raptor turquesa
8592	apito do raptor violeta
8593	aparelho de inspecao do anilhacido
8594	relatorio de analise de insetos
8595	mecanostruz azul
8603	orvalho moitagulhas
8623	transmissor de emergencia oox 17 tn
8624	faiscante vermelho
8625	faiscante branco
8626	faiscante azul
8627	redeas do sabre da noite
8628	redeas do sabre da noite malhado
8629	redeas do sabre da noite listrado
8630	redeas do tigre de bengala
8631	redeas do sabre de gelo listrado
8632	redeas do sabre de gelo malhado
8633	redeas do leopardo
8643	ovo extraordinario
8644	ovo fecundo
8645	ovo comum
8646	ovo gorado
8647	caixa de ovos
8663	insignia de mithril
8683	maca fresca da clara
8684	suco gami das terras agrestes
8685	entrega de suco gami de dran
8686	pingente de mithril
8687	descricao do visitante de thredd lacrada
8703	sinete da aptidao
8704	transmissor de emergencia oox 09 hl
8705	transmissor de emergencia oox 22 fe
8707	escama eletrificada de gahz rilla
8708	martelo da aptidao
8723	cabeca do califa escorpicada
8724	segredo de rin ji
8743	livro de marca do indomado
8744	livro de ira
8745	livro de toque de cura
8746	capucho entrelacado
8747	elmo de couro endurecido
8748	coifa de malha dupla
8749	chapeu de croche
8750	chapeu de couro grosso
8751	coifa entretecida
8752	diadema laminado de escama
8753	capacete de couro liso
8754	capuz de sarja
8755	capacete leve de placa
8756	livro de recrescimento ii
8757	livro de fogo estelar
8758	livro de remover maldicao
8759	livro de recrescimento iii
8760	livro de abolir veneno
8761	livro de fogo estelar ii
8762	livro de rejuvenescimento v
8763	livro de fogo lunar v
8764	livro de fogo feerico ii
8765	livro de recrescimento iv
8766	orvalho da gloria matinal
8768	livro de fogo estelar iii
8769	livro de espinhos iv
8770	livro de fogo lunar vi
8771	livro de rejuvenescimento vi
8772	livro de recrescimento v
8773	livro de raizes enredantes v
8774	livro de toque de cura vii
8775	livro de tranquilidade ii
8776	livro de marca do indomado vi
8777	livro de fogo lunar ix
8778	livro de rejuvenescimento vii
8779	livro de fogo feerico iii
8780	livro de fogo estelar v
8781	livro de recrescimento vii
8782	livro de espinhos v
8783	livro de toque de cura ix
8784	livro de ira vii
8785	livro de rejuvenescimento ix
8786	livro de tranquilidade iii
8787	livro de acalmar animal
8788	livro de acalmar animal ii
8789	livro de acalmar animal iii
8790	livro de fogo feerico iv
8791	livro de recrescimento viii
8792	livro de espinhos vi
8793	livro de ira viii
8794	livro de toque de cura x
8795	livro de raizes enredantes vi
8796	livro de fogo lunar x
8797	livro de rejuvenescimento x
8798	livro de fogo estelar vi
8799	livro de marca do indomado vii
8800	livro de recrescimento ix
8801	livro de tranquilidade iv
8802	tomo de intelecto arcano
8803	tomo de bola de fogo
8804	tomo de explosao arcana
8805	tomo de detectar magia
8806	tomo de remover maldicao inferior
8807	tomo de amplificar magia
8808	tomo de escudo de mana
8809	tomo de sono
8810	tomo de sono ii
8811	tomo de calcinar
8812	tomo de explosao arcana ii
8813	tomo de atenuar magia ii
8814	tomo de bola de fogo v
8815	tomo de cone de frio
8816	tomo de seta de gelo v
8818	tomo de escudo de mana ii
8819	tomo de calcinar ii
8820	tomo de protecao contra fogo ii
8821	tomo de amplificar magia ii
8822	tomo de explosao arcana iii
8823	tomo de impacto de fogo iv
8824	tomo de bola de fogo vi
8825	tomo de protecao contra gelo iii
8826	tomo de misseis arcanos iv
8827	elixir de andar sobre a agua
8828	tomo de seta de gelo vi
8829	tomo de cone de frio ii
8830	tomo de calcinar iii
8831	lotus roxo
8832	tomo de nevasca iii
8833	tomo de escudo de mana iii
8834	tomo de atenuar magia iii
8835	tomo de bola de fogo vii
8836	lagrimas de arthas
8837	tomo de explosao arcana v
8838	ervassol
8839	ervacega
8840	tomo de conjurar gema de mana ii
8841	tomo de impacto de fogo v
8842	tomo de seta de gelo vii
8843	tomo de protecao contra fogo iii
8844	tomo de sono iii
8845	cogumelo fantasma
8846	sangue de grom
8847	tomo de calcinar v
8848	tomo de golpe flamejante iv
8849	tomo de misseis arcanos v
8850	tomo de conjurar agua v
8851	tomo de bola de fogo viii
8852	tomo de intelecto arcano iv
8853	tomo de conjurar comida v
8854	tomo de cone de frio iii
8855	tomo de amplificar magia iii
8856	tomo de seta de gelo viii
8857	tomo de nevasca iv
8858	tomo de escudo de mana iv
8859	tomo de impacto de fogo vi
8860	tomo de bola de fogo ix
8861	tomo de conjurar gema de mana iii
8862	tomo de misseis arcanos vi
8863	tomo de atenuar magia iv
8864	tomo de golpe flamejante v
8865	tomo de armadura de gelo iii
8866	tomo de cone de frio iv
8867	tomo de seta de gelo ix
8868	tomo de conjurar agua vi
8869	tomo de protecao contra fogo iv
8870	tomo maior de invisibilidade
8871	tomo de conjurar comida vi
8872	tomo de nevasca v
8873	tomo de escudo de mana v
8874	tomo de calcinar vi
8875	tomo de protecao contra gelo iv
8876	tomo de protecao contra gelo ii
8877	tomo de bola de fogo x
8878	tomo de impacto de fogo vii
8879	tomo de nova congelante iv
8880	tomo de explosao arcana vi
8881	tomo de destravamento de hadggar iv
8882	tomo de amplificar magia iv
8883	tomo de intelecto arcano v
8884	tomo de seta de gelo x
8885	tomo de misseis arcanos vii
8886	tomo de golpe flamejante vi
8887	tomo de calcinar vii
8888	tomo de cone de frio v
8889	tomo de conjurar gema de mana iv
8890	tomo de bola de fogo xi
8891	tomo de armadura de gelo iv
8892	tomo de conjurar agua vii
8893	tomo de sono iv
8894	tomo de atenuar magia v
8895	tomo de nevasca vi
8896	tomo de escudo de mana vi
8897	tomo de protecao contra fogo v
8898	tomo de explosao arcana iv
8899	tomo de calcinar iv
8900	livro de raizes enredantes iv
8901	livro de toque de cura viii
8902	livro de marca do indomado v
8903	livro de fogo lunar vii
8904	livro de fogo lunar viii
8905	livro de recrescimento vi
8906	livro de rejuvenescimento viii
8907	livro de fogo estelar iv
8909	incunabulo golpe sagrado ii
8910	incunabulo impor as maos
8911	incunabulo punho da justica
8912	incunabulo golpe do cruzado
8913	incunabulo golpe sagrado iii
8914	incunabulo golpe do cruzado ii
8915	incunabulo golpe sagrado iv
8916	incunabulo punho da justica ii
8917	incunabulo impor as maos ii
8918	incunabulo selo da protecao iii
8919	incunabulo golpe sagrado v
8920	incunabulo golpe do cruzado iii
8921	incunabulo punho da justica iii
8922	incunabulo golpe sagrado vi
8923	essencia da agonia
8924	poeira da deterioracao
8925	ampola de cristal
8926	veneno instantaneo iv
8927	veneno instantaneo v
8928	veneno instantaneo vi
8929	incunabulo exorcismo iv
8930	incunabulo selo da retidao iv
8931	incunabulo golpe do cruzado iv
8932	queijo furado de alterac
8933	incunabulo luz sagrada vii
8934	incunabulo golpe sagrado vii
8935	incunabulo julgamento ii
8936	incunabulo selo da ira iii
8937	incunabulo impor as maos iii
8938	incunabulo esconjurar morto vivo iii
8939	incunabulo exorcismo v
8940	incunabulo punho da justica iv
8941	incunabulo luz sagrada viii
8942	incunabulo selo da retidao v
8943	incunabulo golpe sagrado viii
8944	incunabulo golpe do cruzado v
8945	incunabulo julgamento iii
8947	incunabulo exorcismo vi
8948	boleto rei seco
8949	elixir de agilidade
8950	torta de cereja caseira
8951	elixir de defesa maior
8952	codorna assada
8953	platanos fritos
8954	codice de palavra sagrada fortitude
8955	codice de desvanecer
8956	oleo de imolacao
8957	halibute espinhapina
8958	codice de impacto da mente
8959	halibute espinhapina cru
8960	codice de curar doenca
8961	codice de grito psiquico
8962	codice de impacto da mente ii
8963	codice de reconforto mental
8964	codice de cura celere
8965	codice de desvanecer ii
8966	codice de agrilhoar morto vivo
8967	codice de impacto da mente iii
8968	codice de exaurir mana
8969	codice de cura celere ii
8971	codice de grito psiquico ii
8972	codice de impacto da mente iv
8973	pelego grosso de yeti
8974	codice de controle mental
8975	codice de desvanecer iii
8976	codice de abolir doenca
8977	codice de exaurir mana ii
8978	codice de cura celere iii
8980	codice de impacto da mente v
8981	codice de reconforto mental ii
8983	codice de cura celere iv
8984	veneno mortal iii
8985	veneno mortal iv
8986	codice de agrilhoar morto vivo ii
8987	codice de protecao sagrada ii
8988	codice de exaurir mana iii
8989	codice de desvanecer iv
8990	codice de impacto da mente vi
8991	codice de fogo interior iv
8992	codice de grito psiquico iii
8993	codice de protecao sombria ii
8994	codice de palavra sombria dor vi
8995	codice de palavra sagrada escudo vii
8996	codice de ressurreicao iii
8997	codice de controle mental ii
8998	codice de visao da mente ii
8999	codice de cura celere v
9000	codice de renovar vii
9001	codice de cura maior ii
9002	codice de impacto da mente vii
9003	codice de punicao sagrada vii
9004	codice de palavra sagrada fortitude v
9005	codice de exaurir mana iv
9006	codice de palavra sagrada escudo viii
9007	codice de desvanecer v
9008	codice de prece de cura iii
9009	codice de fogo interior v
9010	codice de cura celere vi
9011	codice de palavra sombria dor vii
9012	codice de renovar viii
9013	codice de cura maior iii
9014	codice de reconforto mental iii
9015	codice de impacto da mente viii
9016	codice de punicao sagrada viii
9017	codice de protecao sagrada iii
9018	codice de palavra sagrada escudo ix
9019	codice de renovar ix
9020	codice de grito psiquico iv
9021	codice de exaurir mana v
9022	codice de cura celere vii
9023	codice de protecao sombria iii
9024	codice de controle mental iii
9025	codice de cura maior iv
9026	codice de ressurreicao iv
9027	codice de impacto da mente ix
9028	codice de palavra sombria dor viii
9029	codice de desvanecer vi
9030	pocao de restauracao
9031	codice de agrilhoar morto vivo iii
9032	codice de prece de cura iv
9033	codice de fogo interior vi
9034	codice de palavra sagrada fortitude vi
9035	codice de palavra sagrada escudo x
9036	pocao de resistencia a magia
9037	tabuleta de arma trinca pedra
9039	tabuleta de choque terreno
9040	tabuleta de onda curativa ii
9041	tabuleta de totem de prisao terrena
9043	tabuleta de totem da garra de pedra
9044	tabuleta de choque terreno ii
9046	tabuleta de totem da forca da terra
9047	tabuleta de choque flamejante
9048	tabuleta de renascimento
9049	tabuleta de totem de nova de fogo
9050	tabuleta de onda curativa iii
9051	tabuleta de choque terreno iii
9052	tabuleta de totem litopele ii
9053	tabuleta de arma trinca pedra ii
9054	tabuleta de choque flamejante ii
9055	tabuleta de totem da garra de pedra ii
9056	tabuleta de onda curativa iv
9057	tabuleta de arma de marca gelida
9058	tabuleta de choque gelido
9059	tabuleta de arma com labaredas
9060	cilindro marchetado de mithril
9061	combustivel de foguete goblinico
9062	tabuleta de curar doenca
9063	tabuleta de totem antiveneno
9064	tabuleta de arma com labaredas ii
9065	tabuleta de totem de nova de fogo ii
9066	tabuleta de totem de resistencia ao gelo
9067	tabuleta de totem forca da terra ii
9068	tabuleta de totem litopele iii
9069	tabuleta de choque terreno iv
9070	tabuleta de onda curativa v
9071	tabuleta de totem de fonte de mana
9072	tabuleta de totem de labaredas
9073	tabuleta de arma de furia dos ventos
9074	tabuleta de choque flamejante iii
9075	tabuleta de totem de resistencia ao fogo
9076	tabuleta de totem de magma
9077	tabuleta de totem da garra de pedra iii
9078	tabuleta de totem de aterramento
9079	tabuleta de choque de raio
9080	tabuleta de totem de resistencia a natureza
9081	tabuleta de totem de torrente curativa ii
9082	tabuleta de arma trinca pedra iii
9083	tabuleta de totem calcinante iii
9084	tabuleta de totem de furia dos ventos
9085	tabuleta de totem de nova de fogo iii
9086	tabuleta de onda curativa vi
9087	tabuleta de expurgar ii
9088	dadiva de arthas
9089	tabuleta de choque gelido ii
9090	tabuleta de arma de marca gelida ii
9091	tabuleta de totem litopele iv
9092	tabuleta de totem sentinela
9093	tabuleta de totem de fonte de mana ii
9094	tabuleta de arma com labaredas iii
9095	tabuleta de choque terreno v
9096	tabuleta de totem antidoenca
9097	tabuleta de totem de magma ii
9098	tabuleta de totem forca da terra iii
9099	tabuleta de totem da garra de pedra iv
9100	tabuleta de escudo de raios v
9101	tabuleta de arma de furia dos ventos ii
9102	tabuleta de cadeia de raios ii
9103	tabuleta de totem de torrente curativa iii
9104	tabuleta de totem calcinante iv
9105	tabuleta de onda curativa vii
9123	tabuleta de raio vi
9124	tabuleta de choque de raio ii
9125	tabuleta de totem da graca do ar
9126	tabuleta de totem de labaredas ii
9127	tabuleta de totem de resistencia ao fogo ii
9128	tabuleta de totem de nova de fogo iv
9129	tabuleta de arma trinca pedra iv
9130	tabuleta de totem de resistencia a natureza ii
9131	tabuleta de totem litopele v
9132	tabuleta de impacto derretido vi
9133	tabuleta de cura encadeada ii
9134	tabuleta de totem de furia dos ventos ii
9135	tabuleta de choque gelido iii
9136	tabuleta de totem de fonte de mana iii
9137	tabuleta de escudo de raios vi
9138	tabuleta de totem de magma iii
9139	tabuleta de arma de marca gelida iii
9140	tabuleta de cadeia de raios iii
9141	tabuleta de totem da garra de pedra v
9142	tabuleta de choque terreno vi
9143	tabuleta de onda curativa viii
9144	pocao de vinha selvagem
9145	tabuleta de raio vii
9146	tabuleta de totem calcinante v
9147	tabuleta de totem de torrente curativa iv
9148	tabuleta de arma com labaredas iv
9149	pedra filosofal
9150	tabuleta de totem forca da terra iv
9151	tabuleta de choque flamejante v
9152	tabuleta de totem de nova de fogo v
9153	projeto de mecatraje
9154	elixir de deteccao de mortos vivos
9155	elixir arcano
9156	tabuleta de impacto derretido vii
9157	tabuleta de cura encadeada iii
9158	tabuleta de totem de resistencia ao gelo iii
9159	tabuleta de choque de raio iii
9160	tabuleta de arma de furia dos ventos iii
9161	tabuleta de totem litopele vi
9162	tabuleta de escudo de raios vii
9164	tabuleta de totem da graca do ar ii
9165	tabuleta de totem de labaredas iii
9166	tabuleta de totem de fonte de mana iv
9167	tabuleta de cadeia de raios iv
9168	tabuleta de onda curativa ix
9169	tabuleta de raio viii
9170	tabuleta de totem de resistencia ao fogo iii
9171	tabuleta de totem de magma iv
9172	pocao de invisibilidade
9173	transponder goblinico
9174	tabuleta de choque gelido iv
9175	tabuleta de arma trinca pedra v
9176	tabuleta de totem da garra de pedra vi
9177	tabuleta de choque terreno vii
9178	tabuleta de totem de resistencia a natureza iii
9179	elixir de intelecto maior
9180	tabuleta de totem de furia dos ventos iii
9181	tabuleta de totem de torrente curativa v
9182	tabuleta de totem calcinante vi
9183	tabuleta de cura encadeada
9184	tabuleta de choque flamejante iv
9185	tabuleta de totem de resistencia ao gelo ii
9186	veneno entorpecente iii
9187	elixir de agilidade maior
9188	tabuleta de totem calcinante ii
9189	sino de shay
9190	grimorio de imolacao
9191	grimorio de maldicao da fraqueza
9192	grimorio de corrupcao
9193	grimorio de conversao de vida
9194	grimorio de maldicao da agonia
9195	grimorio de drenar alma
9197	elixir de visao de sonhos
9198	grimorio de funil de vida
9199	grimorio de maldicao da temeridade
9200	grimorio de maldicao da fraqueza ii
9201	grimorio de corrupcao ii
9202	grimorio de conversao de vida ii
9203	grimorio de ritual de evocacao
9204	grimorio de funil de vida ii
9205	grimorio de maldicao da agonia ii
9206	elixir de gigantes
9207	grimorio de criar pedra sangrenta ii
9208	grimorio de drenar alma ii
9209	grimorio de maldicao da fraqueza iii
9210	pigmento fantasma
9211	grimorio de maldicao da temeridade ii
9212	grimorio de seta sombria v
9214	grimorio de inferno
9215	grimorio de funil de vida iii
9216	grimorio de corrupcao iii
9217	grimorio de conversao de vida iii
9218	grimorio de escravizar demonio
9219	grimorio de fogo do inferno
9221	grimorio de maldicao da agonia iii
9222	grimorio de maldicao dos elementos
9223	grimorio de maldicao da fraqueza iv
9224	elixir de demonicidio
9225	grimorio de seta sombria vi
9226	grimorio de funil de vida iv
9227	grimorio de drenar alma iii
9228	grimorio de criar pedra sangrenta iii
9229	grimorio de drenar vida iv
9230	grimorio de maldicao da temeridade iii
9231	grimorio de corrupcao iv
9233	elixir de deteccao de demonios
9234	tiara das profundezas
9235	carta de pradal
9236	carta de jangdor
9237	juba de gnoll patabua
9238	couraca de escaravelho fechada
9240	marreta de zul farrak
9241	marreta sagrada
9242	tabuleta ancestral
9243	coracao murcho
9244	carregamento do esmirno
9245	garrafa do esmirno
9246	cabeca de barbarruiva
9247	escama de naga cristafuria
9248	reliquia misteriosa
9249	chave do capitao
9250	horario do navio
9251	fragmento superior do mapa
9252	fragmento inferior do mapa
9253	fragmento intermediario do mapa
9254	mapa do tesouro do cuergo
9255	essencia lahassa
9256	essencia imbel
9257	essencia samha
9258	essencia byltan
9259	colar tribal troll
9260	rum volatil
9261	minerio de chumbo
9262	vitriolo preto
9263	baculo de troyas
9264	elixir de poder sombrio
9265	tesouro escondido do cuergo
9266	plano de batalha de patabua
9275	chave do cuergo
9276	maleta do pirata
9277	nucleo de memoria do tecnobo
9278	artificio essencial
9279	cartao perfurado branco
9280	cartao perfurado amarelo
9281	cartao perfurado vermelho
9282	cartao perfurado azul
9283	coletor de chumbo vazio
9284	coletor de chumbo cheio
9285	avambracos de placa do campo de batalha
9286	armadura de placa do campo de batalha
9287	manoplas de placa do campo de batalha
9288	cinturao de placa do campo de batalha
9289	botas de placa do campo de batalha
9290	capacete de placa do campo de batalha
9291	perneiras de placa do campo de batalha
9292	brafoneiras de placa do campo de batalha
9293	receita pocao de resistencia a magia
9294	receita pocao de vinha selvagem
9295	receita pocao de invisibilidade
9296	receita dadiva de arthas
9297	receita elixir de visao de sonhos
9298	receita elixir de gigantes
9299	combinacao do cofre do termaplugue
9300	receita elixir de demonicidio
9301	receita elixir de poder sombrio
9302	receita pigmento fantasma
9303	receita pedra filosofal
9304	receita transmutar ferro em ouro
9305	receita transmutar mithril em veraprata
9306	baculo de equinex
9307	uma pedra rutilante
9308	objeto encardido
9309	tripas mecanoboticas
9311	papel de carta padrao
9312	fogos de artificio azuis
9313	fogos de artificio verdes
9314	fogos de artificio de centelhas vermelhas
9315	fogos de artificio da rosa amarela
9316	cartao perfurado prismatico
9317	fogos de artificio vermelho branco e azul
9318	fogos de artificio vermelhos
9319	pique de nimboya repleto
9320	cranio de cascasseca
9321	garrafa de peconha
9322	vesicula de peconha intacta
9323	pergaminho de gadrin
9324	peconha de shadra
9325	um baculo pequeno
9326	anel encardido
9327	cartao de seguranca de acesso delta
9328	superinstantanea fx
9329	um bilhete
9330	foto de gammerita
9331	feralas uma historia
9332	bandagens sujas
9333	colar de prata manchada
9334	potes quebrados
9335	taco de obsidiana quebrado
9336	presa de ouro do troll
9355	brinco de argola
9356	uma perna de pau
9357	esqueleto de papagaio
9358	um turbante
9359	lampada dos mares do sul
9360	cuergo ouro
9361	cuergo ouro com verme
9362	anel de ouro brilhante
9363	caixa da brastematic
9364	coletor de chumbo pesado
9365	residuo radioativo de alta potencia
9366	manoplas de escama dourada
9367	instrucoes manoplas de escama dourada
9368	anel sinete de jer kai
9369	asa iridescente de dardejante
9370	pergaminho gordunni
9371	orbe gordunni
9372	sul thraze a acoitadora
9375	elmo do eximio garimpeiro
9378	machado de mineracao do pa de flange
9379	sang thraze a defletora
9380	jang thraze a protetora
9381	bastao terrano
9382	botas do minerador pisoteante
9383	cutelo obsidiano
9384	estoque da abobada de pedra
9385	defensor arcaico
9386	marca do escavador
9387	botas do revelosh
9388	guarda bracos do revelosh
9389	espaldares do revelosh
9390	luvas do revelosh
9391	o padejador
9392	lamina temperada
9393	raio de esperanca
9394	capacete viking com chifres
9395	luvas dos antigos
9396	guarda pernas da abobada
9397	manto de energia
9398	botas de corrida gastas
9399	flecha de precisao
9400	arco curto de baelog
9401	cimitarra nordica
9402	kilt terreno
9403	escudo viking surrado
9404	escudo versatil do olaf
9405	cinturao da forca do golem
9406	grilhao pinavento
9407	perneiras tecepedra
9408	porrete com ferros
9409	bracadeiras da ferronaya
9410	punhacos
9411	brafoneiras lascarrocha
9412	pregafogo do galgann
9413	o socapedra
9414	perneiras de oleado
9415	vestimenta tribal do grimlok
9416	impeto de grimlok
9417	estilhaco arcadico
9418	matapedra
9419	martelo de fogo do galgann
9420	capacete do vigor do aventureiro
9421	pedra de vida elevada
9422	mateiro de umbraforja
9423	a britadeira
9424	espada ginn su
9425	pendulo da perdicao
9426	arco monolitico
9427	quebraossos da abobada de pedra
9428	embraces desenterrados
9429	capacete de minerador das profundezas
9430	espaldares da era perdida
9431	tarbuche papal
9432	bracadeiras de placa craniana
9433	bandagens esquecidas
9434	traje do elemental
9435	manoplas de osso reticulado
9436	embrulho do faranello
9437	amostra nao testada de basilisco
9438	amostra aceitavel de escorpideo
9439	amostra nao testada de hiena
9440	amostra aceitavel de basilisco
9441	amostra aceitavel de hiena
9442	amostra nao testada de escorpideo
9443	amostra usada de monstro
9444	casco da cpu do tecnobo
9445	patas de grudio
9446	perna do eletrocutor
9447	porca do eletrocutor
9448	trapo oleoso do aracnotanque
9449	espanca gente manual
9450	botas de operacao do gnomobo
9451	agua borbulhante
9452	hidrobengala
9453	vingador toxico
9454	chancas acidas
9455	manilhas do emissario
9456	carabina de vidro
9457	cetro diplomatico real
9458	nucleo central de termaplugue
9459	braco esquerdo do termaplugue
9460	chifre de temivel totem
9461	engrenagem carregada
9462	caixa de chifres temivel totem
9463	cobalto gordunni
9465	mestrescavadora 5000
9466	pa de orwin
9467	presa de gahz rilla
9468	pena de bicoafiado
9469	armadura de escama de gahz rilla
9470	mascara do mojo ruim
9471	medalhao de nekrum
9472	chave de bagata
9473	peitoral azarado
9474	kilt azarado
9475	laminador diabolico
9476	brafoneiras sinistronas
9477	a garantia do chefe
9478	serrote
9479	abraco de lycan
9480	rancazoio
9481	minotauro
9482	bengala do mandingueiro
9483	incinerador flamejante
9484	perneiras do choque mistico
9485	vibrolamina
9486	machado de guerra superataque
9487	superarma hi tech
9488	martelo do poder oscilante
9489	fazedor de gelo giromatico
9490	megafaca trecotronica
9491	luvas do piloto gostosao
9492	reativador do gigafluxo eletromagnetico
9507	caixote cuidadosamente embalado
9508	macacao do criador de robos
9509	perneiras com gasolina
9510	botinas furnafunda
9511	escalpelo do dessangrador
9512	capa de metal preto
9513	cajado meridiano
9514	cajado arcano
9515	tunica do laco etereo
9516	bata do no astral
9517	baculo celestial
9518	esmagadores de lama
9519	pisoteadores pe sujo
9520	cacador silencioso
9521	rachacranio
9522	circulo de pedra energizado
9523	tempera de troll
9527	bastao converte feitico
9528	coracao sombrio de edana
9529	kit de equipamento para guerreiro interno l25
9530	chifre de iragarra
9531	brafoneiras de xisto gema
9532	kit de equipamento para guerreiro interno l30
9533	anel da confraria macom
9534	bacinete da guilda do engenheiro
9535	bracadeiras soldadas
9536	dragonas asa de fada
9537	caixa bem embrulhada
9538	anel de ouro do didie
9539	caixa de racoes
9540	caixa de feiticos
9541	caixa de gostosuras
9542	carta simples
9543	runa simples
9544	memorando simples
9545	selo simples
9546	pergaminho simples
9547	bilhete
9548	carta santificada
9550	runa cifrada
9551	selo cifrado
9552	bilhete inscrito em runas
9553	pergaminho cinzelado
9554	tabuleta cifrada
9555	carta cifrada
9556	runa santificada
9557	selo sagrado
9558	memorando cifrado
9559	pergaminho cifrado
9560	pergaminho cifrado
9561	tabuleta consagrada
9562	tabuleta inscrita em runas
9563	runa consagrada
9564	tabuleta cinzelada
9565	bilhete cinzelado
9566	runa cinzelada
9567	selo cinzelado
9568	pergaminho inscrito em runas
9569	pergaminho consagrado
9570	carta consagrada
9571	carta glifica
9572	<unused> glyphic rune
9573	memorando glifico
9574	pergaminho glifico
9575	tabuleta glifica
9576	carta conspurcada
9577	memorando maculado
9578	pergaminho conspurcado
9579	pergaminho conspurcado
9580	selo verdejante
9581	bilhete verdejante
9587	saco de degelocouro
9588	anel de ouro do nogg
9589	minerais incrustados
9590	pedaco de lenha
9591	tendao resiliente
9592	fragmentos metalicos
9593	muisec de arvoroso
9594	muisec de coruscante
9595	muisec de hipogrifo
9596	muisec de dragoleta
9597	muisec de gigante da montanha
9598	vestes de dormir
9599	perneiras de malha de tronco
9600	calcas galonadas
9601	botas almofadadas
9602	lamina matagal
9603	cajado pardo
9604	martelo do mecanico
9605	capa do mecanico
9606	recipiente de muisec de arvoroso
9607	bastiao de ventobravo
9608	ferramenta de desarme da shoni
9609	luvas bechil
9618	recipiente de muisec de coruscante
9619	recipiente de muisec de hipogrifo
9620	recipiente de muisec de dragoleta
9621	recipiente de muisec de gigante da montanha
9622	anel de no de bambu
9623	vestes de civinada
9624	culotes corretrecho
9625	perneiras duplas reforcadas
9626	carga enanica
9627	estrela guia da liga dos exploradores
9628	bolsa de herborismo de neeru
9629	cabeca encolhida
9630	botas artesanais de pradal
9631	luvas artesanais de pradal
9632	luvas artesanais de jangdor
9633	botas artesanais de jangdor
9634	luvas do manejo habil
9635	capa do mestre boticario
9636	faixa do valentao
9637	botas chuta canela
9638	manilhas quelonianas
9639	a mao de antu sul
9640	manoplas imorais
9641	amuleto de sangue vital
9642	elo da grande tartaruga
9643	defletor optomatico
9644	temporizador de ovo termostatico
9645	botas do inventor gnomico
9646	dispositivo gnomico de afundamento
9647	experimento voador fracassado
9648	toalha de cota de malha
9649	vestimenta da altivez real
9650	peito d armas da guarda honoraria
9651	martelo da tempestade do cavalga grifo
9652	perneiras do cavalga grifo
9653	oculos do corredor veloz
9654	lasca de pedra do memorial
9655	anel epoca de semear
9656	manoplas de granito
9657	cilha sebevideira
9658	botas do maharishi
9660	manto do contemplador das estrelas
9661	broquel fechaterra
9662	botas serrapressa
9663	peito d armas do cavaleiro da aurora
9664	protetor da sentinela
9665	luvas brasao asa
9666	cinturao chifreforte
9678	esmagador de murloc de tok kar
9679	cortador de murloc do tok kar
9680	perfurador de murloc de tok kar
9681	patas grelhadas de caranguejo rei
9682	cinto de couro do chef
9683	forca do arvoroso
9684	forca do hipogrifo
9685	vontade do gigante da montanha
9686	espirito de dragoleta
9687	cinto do lacador
9698	luvas da perspicacia
9699	manto da guarnicao
9703	capa calcinada
9704	luvas do larapio
9705	cadarco de tharg
9706	disco de tharg
9718	lamina dos herois reforjada
9719	lamina dos herois quebrada
9738	gema de cobrahn
9739	gema de sucurina
9740	gema de pitias
9741	gema de serpentis
9742	cordao simples
9743	sapatos simples
9744	embraces simples
9745	capa simples
9746	luvas simples
9747	culotes simples
9748	veste simples
9749	blusa simples
9750	faixa zingara
9751	sandalias zingaras
9752	embraces zingaros
9753	broquel zingaro
9754	manto zingaro
9755	luvas zingaras
9756	calcas zingaras
9757	tunica zingara
9758	cinto de cadete
9759	botas de cadete
9760	bracadeiras de cadete
9761	manto de cadete
9762	manoplas de cadete
9763	perneiras de cadete
9764	escudo de cadete
9765	colete de cadete
9766	faixa teciverde
9767	sandalias teciverde
9768	bracadeiras teciverde
9769	galho teciverde
9770	manto teciverde
9771	luvas teciverde
9772	perneiras teciverde
9773	veste teciverde
9774	colete teciverde
9775	cilha do bandido
9776	botas do bandido
9777	bracadeiras do bandido
9778	broquel do bandido
9779	manto do bandido
9780	luvas do bandido
9781	calcas do bandido
9782	gibao do bandido
9783	peito d armas do saqueador
9784	botas do saqueador
9785	bracadeiras do saqueador
9786	manto do saqueador
9787	manoplas do saqueador
9788	cinto do saqueador
9789	guarda pernas do saqueador
9790	escudo do saqueador
9791	tunica de pano de hera
9792	botas de pano de hera
9793	braceletes de pano de hera
9794	manto de pano de hera
9795	luvas de pano de hera
9796	dragonas de pano de hera
9797	calcas de pano de hera
9798	veste de pano de hera
9799	faixa de pano de hera
9800	orbe hera
9801	cinto superior
9802	botas superiores
9803	bracadeiras superiores
9804	broquel superior
9805	manto superior
9806	luvas superiores
9807	omoplatas superiores
9808	perneiras superiores
9809	tunica superior
9810	botas reforcadas
9811	bracadeiras reforcadas
9812	manto reforcado
9813	manoplas reforcadas
9814	cinto reforcado
9815	perneiras reforcadas
9816	escudo reforcado
9817	espaldares reforcados
9818	corrente reforcada
9819	tunica duravel
9820	botas duraveis
9821	bracadeiras duraveis
9822	capa duravel
9823	luvas duraveis
9824	omoplatas duraveis
9825	calcas duraveis
9826	veste duravel
9827	cinto em escamas de couro
9828	botas em escamas de couro
9829	bracadeiras em escamas de couro
9830	escudo em escamas
9831	manto em escamas
9832	luvas em escamas de couro
9833	perneiras em escamas de couro
9834	omoplatas em escamas de couro
9835	tunica em escamas de couro
9836	armadura atada
9837	bracadeiras atadas
9838	manto atado
9839	manoplas atadas
9840	cinturao atado
9841	perneiras atadas
9842	brafoneiras atadas
9843	escudo atado
9844	colete do conjurador
9845	sapatos do conjurador
9846	bracadeiras do conjurador
9847	manto do conjurador
9848	luvas do conjurador
9849	capuz do conjurador
9850	dragonas do conjurador
9851	calcoes do conjurador
9852	veste do conjurador
9853	cilha do conjurador
9854	gibao do arqueiro
9855	cinto do arqueiro
9856	botas do arqueiro
9857	bracadeiras do arqueiro
9858	broquel do arqueiro
9859	casquete do arqueiro
9860	manto do arqueiro
9861	luvas do arqueiro
9862	calcas do arqueiro
9863	ombreiras do arqueiro
9864	botas do renegado
9865	bracadeiras do renegado
9866	couraca do renegado
9867	manto do renegado
9868	manoplas do renegado
9869	cinto do renegado
9870	diadema do renegado
9871	perneiras do renegado
9872	brafoneiras do renegado
9873	escudo do renegado
9874	clamide feiticeira
9875	faixa feiticeira
9876	sapatilhas feiticeiras
9877	manto feiticeiro
9878	chapeu feiticeiro
9879	braceletes feiticeiros
9880	luvas feiticeiras
9881	dragonas feiticeiras
9882	esfera feiticeira
9883	calcas feiticeiras
9884	veste feiticeira
9885	botas do guarda caca
9886	embraces do guarda caca
9887	armadura do guarda caca
9889	casquete do guarda caca
9890	capa do guarda caca
9891	cinto do guarda caca
9892	luvas do guarda caca
9893	perneiras do guarda caca
9894	omoplatas do guarda caca
9895	botas brigandinas
9896	bracadeiras brigandinas
9897	couraca brigandina
9898	manto brigandino
9899	escudo brigandino
9900	manoplas brigandinas
9901	cinto brigandino
9902	elmo brigandino
9903	perneiras brigandinas
9904	brafoneiras brigandinas
9905	blusa real
9906	faixa real
9907	botas reais
9908	capa real
9909	embraces reais
9910	luvas reais
9911	calcas reais
9912	sobreveste real
9913	toga real
9914	cetro real
9915	bandana real
9916	cinto do rastreador
9917	botas do rastreador
9918	defensor da brigada
9919	manto do rastreador
9920	luvas do rastreador
9921	bandana do rastreador
9922	perneiras do rastreador
9923	ombreiras do rastreador
9924	tunica do rastreador
9925	munhequeiras do rastreador
9926	botas da brigada
9927	bracadeiras da brigada
9928	peitoral da brigada
9929	manto da brigada
9930	manoplas da brigada
9931	cinturao da brigada
9932	diadema da brigada
9933	perneiras da brigada
9934	brafoneiras da brigada
9935	escudo de placa em alto relevo
9936	botas do abjurador
9937	embraces do abjurador
9938	manto do abjurador
9939	luvas do abjurador
9940	capuz do abjurador
9941	dragonas do abjurador
9942	calcas do abjurador
9943	veste do abjurador
9944	cristal do abjurador
9945	faixa do abjurador
9946	tunica do abjurador
9947	cinto do chefe tribal
9948	botas do chefe tribal
9949	bracadeiras do chefe tribal
9950	peitoral do chefe tribal
9951	manto do chefe tribal
9952	luvas do chefe tribal
9953	cocar do chefe tribal
9954	perneiras do chefe tribal
9955	omoplatas do chefe tribal
9956	bracadeiras do fomentador de guerra
9957	peito d armas do fomentador de guerra
9958	broquel do fomentador de guerra
9959	manto do fomentador de guerra
9960	manoplas do fomentador de guerra
9961	cinto do fomentador de guerra
9962	grevas do fomentador de guerra
9963	diadema do fomentador de guerra
9964	perneiras do fomentador de guerra
9965	brafoneiras do fomentador de guerra
9966	armadura de placa em alto relevo
9967	manoplas de placa em alto relevo
9968	cinturao de placa em alto relevo
9969	capacete de placa em alto relevo
9970	perneiras de placa em alto relevo
9971	brafoneiras de placa em alto relevo
9972	bracadeiras de placa em alto relevo
9973	botas de placa em alto relevo
9974	escudo do lorde supremo
9978	detector de gahz ridian
9998	colete de magitrama preta
9999	perneiras de magitrama preta
10000	chifre de margol
10001	veste de magitrama preta
10002	calcas de umbratrama
10003	luvas de magitrama pretas
10004	veste de umbratrama
10005	chifre gigante de margol
10007	colete de magitrama vermelho
10008	mascara branca do bandido
10009	calcas de magitrama vermelhas
10010	calcas de tempestrama
10011	luvas de tempestrama
10018	luvas de magitrama vermelhas
10019	luvas de oniritrama
10020	colete de tempestrama
10021	colete de oniritrama
10022	certificado de realizacao
10023	luvas de umbratrama
10024	bandana de magitrama preta
10025	mascara de umbratrama
10026	botas de magitrama preta
10027	omoplatas de magitrama pretas
10028	omoplatas de umbratrama
10029	omoplatas de magitrama vermelhas
10030	chapeu do almirante
10031	botas de umbratrama
10032	bandana de tempestrama
10033	bandana de magitrama vermelha
10034	camisa de smoking
10035	calcas de smoking
10036	paleto de smoking
10038	omoplatas de tempestrama
10039	botas de tempestrama
10040	vestido de noiva branco
10041	diadema de oniritrama
10042	veste de brasatrama
10043	culotes pios
10044	botas de brasatrama
10045	calcas simples de linho
10046	botas simples de linho
10047	kilt simples
10048	kilt colorido
10049	lamina do diabolista
10050	bolsa de magitrama
10051	bolsa de magitrama vermelha
10052	camisa marcial laranja
10053	vestido preto simples
10054	camisa de magitrama lavanda
10055	camisa de magitrama rosa
10056	camisa de magitrama laranja
10057	tunica do anoitecer
10058	sandalias do anoitecer
10059	bracadeiras do anoitecer
10060	capa do anoitecer
10061	turbante do anoitecer
10062	luvas do anoitecer
10063	sobreveste do anoitecer
10064	calcas do anoitecer
10065	veste do anoitecer
10066	faixa do anoitecer
10067	cinta integra
10068	botas integras
10069	bracadeiras integras
10070	armadura integra
10071	manto integro
10072	luvas integras
10073	capacete integro
10074	perneiras integras
10075	espaldares integros
10076	guarda bracos do lorde
10077	peitoral do lorde
10078	timbre do lorde
10079	capa do lorde
10080	manoplas do lorde
10081	cinturao do lorde
10082	botas do lorde
10083	coroa do lorde
10084	guarda pernas do lorde
10085	brafoneiras do lorde
10086	armadura gotica de placa
10087	manoplas goticas de placa
10088	cinturao gotico de placa
10089	escarpes goticos
10090	capacete gotico de placa
10091	perneiras goticas de placa
10092	espaldares goticos de placa
10093	defletor do elemental vingativo
10094	avambracos goticos de placa
10095	botas do conselheiro
10096	manilhas do conselheiro
10097	diadema do conselheiro
10098	manto do conselheiro
10099	luvas do conselheiro
10100	omoplatas do conselheiro
10101	calcas do conselheiro
10102	vestes do conselheiro
10103	faixa do conselheiro
10104	tunica do conselheiro
10105	armadura do errante
10106	botas do errante
10107	bracadeiras do errante
10108	manto do errante
10109	cinto do errante
10110	luvas do errante
10111	chapeu do errante
10112	perneiras do errante
10113	omoplatas do errante
10118	peitoral ornado
10119	grevas ornadas
10120	manto ornado
10121	manoplas ornadas
10122	cinturao ornado
10123	diadema ornado
10124	guarda pernas ornados
10125	brafoneiras ornadas
10126	bracadeiras ornadas
10127	bracadeiras do elemental vingativo
10128	guarda peito do elemental vingativo
10129	manoplas do elemental vingativo
10130	cinturao do elemental vingativo
10131	botas do elemental vingativo
10132	capacete do elemental vingativo
10133	perneiras do elemental vingativo
10134	omoplatas do elemental vingativo
10135	tunica do alto conselheiro
10136	bracadeiras do alto conselheiro
10137	botas do alto conselheiro
10138	manto do alto conselheiro
10139	diadema do alto conselheiro
10140	luvas do alto conselheiro
10141	calcas do alto conselheiro
10142	dragonas do alto conselheiro
10143	veste do alto conselheiro
10144	faixa do alto conselheiro
10145	cinturao poderoso
10146	botas poderosas
10147	pulseiras poderosas
10148	manto poderoso
10149	manoplas poderosas
10150	capacete poderoso
10151	tunica poderosa
10152	perneiras poderosas
10153	espaldares poderosos
10154	cinturao mercurial
10155	grevas mercuriais
10156	bracadeiras mercuriais
10157	peitoral mercurial
10158	guarda mercurial
10159	manto mercurial
10160	diadema mercurial
10161	manoplas mercuriais
10162	guarda pernas mercuriais
10163	brafoneiras mercuriais
10164	guarda peito templario
10165	manoplas templarias
10166	cinturao templario
10167	botas templarias
10168	coroa templaria
10169	coxotes templarios
10170	brafoneiras templarias
10171	bracadeiras templarias
10172	dragonas misticas
10173	bracadeiras misticas
10174	capa mistica
10175	turbante mistico
10176	luvas misticas
10177	perneiras misticas
10178	veste mistica
10179	botas misticas
10180	cinto mistico
10181	armadura mistica
10182	peitoral do espadachim
10183	botas do espadachim
10184	bracadeiras do espadachim
10185	capa do espadachim
10186	luvas do espadachim
10187	tapa olho do espadachim
10188	perneiras do espadachim
10189	ombreiras do espadachim
10190	cinto do espadachim
10191	guarda bracos do cruzado
10192	botas do cruzado
10193	armadura do cruzado
10194	manto do cruzado
10195	escudo do cruzado
10196	manoplas do cruzado
10197	cinto do cruzado
10198	elmo do cruzado
10199	perneiras do cruzado
10200	brafoneiras do cruzado
10201	grevas do lorde supremo
10202	avambracos do lorde supremo
10203	guarda peito do lorde supremo
10204	escudo lamelar pesado
10205	manoplas do lorde supremo
10206	cinturao do lorde supremo
10207	coroa do lorde supremo
10208	coxotes do lorde supremo
10209	espaldares do lorde supremo
10210	dragonas elegantes
10211	botas elegantes
10212	manto elegante
10213	bracadeiras elegantes
10214	luvas elegantes
10215	vestes elegantes
10216	cinto elegante
10217	perneiras elegantes
10218	tunica elegante
10219	diadema elegante
10220	tunica de erva moura
10221	cinturao de erva moura
10222	botas de erva moura
10223	guarda bracos de erva moura
10224	manto de erva moura
10225	luvas de erva moura
10226	capacete de erva moura
10227	perneiras de erva moura
10228	espaldares de erva moura
10229	bracadeiras gravadas
10230	peitoral gravado
10231	capa gravada
10232	manoplas gravadas
10233	cinturao gravado
10234	botas gravadas
10235	elmo gravado
10236	perneiras gravadas
10237	brafoneiras gravadas
10238	botas lamelares pesadas
10239	avambracos lamelares pesados
10240	peito d armas lamelar pesado
10241	elmo lamelar pesado
10242	manoplas lamelares pesadas
10243	cinturao lamelar pesado
10244	perneiras lamelares pesadas
10245	brafoneiras lamelares pesadas
10246	colete do mestre
10247	botas do mestre
10248	bracadeiras do mestre
10249	manto do mestre
10250	chapeu do mestre
10251	luvas do mestre
10252	perneiras do mestre
10253	dragonas do mestre
10254	veste do mestre
10255	cinto do mestre
10256	bracadeiras do aventureiro
10257	botas do aventureiro
10258	capa do aventureiro
10259	cinto do aventureiro
10260	luvas do aventureiro
10261	bandana do aventureiro
10262	guarda pernas do aventureiro
10263	omoplatas do aventureiro
10264	tunica do aventureiro
10265	bracadeiras magistrais
10266	peitoral magistral
10267	capa magistral
10268	manoplas magistrais
10269	cinturao magistral
10270	botas magistrais
10271	escudo magistral
10272	diadema magistral
10273	coxotes magistrais
10274	brafoneiras magistrais
10275	peitoral esmeralda
10276	escarpes esmeralda
10277	manoplas esmeralda
10278	cinturao esmeralda
10279	elmo esmeralda
10280	coxotes esmeralda
10281	brafoneiras esmeralda
10282	avambracos esmeralda
10283	amostras de coracao de lobo
10285	seda sombria
10286	coracao das selvas
10287	dragonas de teciverde
10288	diadema do sabio
10289	chapeu duravel
10290	pigmento cor de rosa
10298	elo de gnomeregan
10299	amuleto de gnomeregan
10300	molde colete de magitrama vermelho
10301	molde mascara branca do bandido
10302	molde calcas de magitrama vermelhas
10303	molde calcas de tempestrama
10304	molde luvas de tempestrama
10305	pergaminho de protecao iv
10306	pergaminho do espirito iv
10307	pergaminho do vigor iv
10308	pergaminho do intelecto iv
10309	pergaminho de agilidade iv
10310	pergaminho de forca iv
10311	molde camisa marcial laranja
10312	molde luvas de magitrama vermelhas
10313	molde colete de tempestrama
10314	molde camisa de magitrama lavanda
10315	molde omoplatas de magitrama vermelhas
10316	molde kilt colorido
10317	molde camisa de magitrama rosa
10318	molde chapeu do almirante
10319	molde bandana de tempestrama
10320	molde bandana de magitrama vermelha
10321	molde camisa de smoking
10322	molde omoplatas de tempestrama
10323	molde calcas de smoking
10324	molde botas de tempestrama
10325	molde vestido de noiva branco
10326	molde paleto de smoking
10327	berrante de echeyaki
10328	peito d armas escarlate
10329	cinto escarlate
10330	perneiras escarlate
10331	manoplas escarlate
10332	botas escarlate
10333	munhequeiras escarlate
10338	carcaca fresca de zevra
10358	bracadeiras de duracin
10359	botas sempiternas
10360	cobra rei preta
10361	cobra marrom
10362	escudo ornado
10363	parede gravada
10364	escudo templario
10365	escudo esmeralda
10366	guarda demoniaca
10367	escudo hyperion
10368	armadura de placa imbuida
10369	manoplas de placa imbuidas
10370	cinturao de placa imbuido
10371	grevas de placa imbuidas
10372	capacete de placa imbuido
10373	perneiras de placa imbuidas
10374	brafoneiras de placa imbuidas
10375	avambracos de placa imbuidos
10376	botas do comandante
10377	avambracos do comandante
10378	armadura do comandante
10379	elmo do comandante
10380	manoplas do comandante
10381	cinturao do comandante
10382	perneiras do comandante
10383	brafoneiras do comandante
10384	armadura hyperion
10385	grevas hyperion
10386	manoplas hyperion
10387	cinturao hyperion
10388	elmo hyperion
10389	coxotes hyperion
10390	brafoneiras hyperion
10391	avambracos hyperion
10392	cobra carmesim
10393	barata
10394	apito de cao da pradaria
10398	frango mecanico
10399	armadura enegrecida dos defias
10400	perneiras enegrecidas dos defias
10401	luvas enegrecidas dos defias
10402	botas enegrecidas dos defias
10403	cinto enegrecido dos defias
10404	cinto duravel
10405	omoplatas do bandido
10406	bandana em escamas de couro
10407	ombreiras do saqueador
10408	elmo atado
10409	botas atadas
10410	perneiras da presa
10411	pisantes da presa
10412	cinto da presa
10413	luvas da presa
10414	amostra de casco de mordelisca
10418	insignia de mithril rutilante
10420	cranio do frigifero
10421	colete de cobre grosseiro
10423	perneiras de bronze prateado
10424	instrucoes perneiras de bronze prateado
10438	caixa do felix
10439	rabo de galo escaldante de durnan
10440	caneca de nori
10441	estilhaco chamejante
10442	artefato misterioso
10443	carta chamuscada
10444	pistola sinalizadora modelo padrao
10445	kit de desenho
10446	coracao de obsidiao
10447	cabeca de latorico o negro
10450	pena intacta de hipogrifo
10454	essencia de eranicos
10455	essencia acorrentada de eranicos
10456	algibeira cheia de moedas
10457	concha vazia de caracol do mar
10458	oracao a eluna
10459	cabeca do chefe presadura mantospinho
10460	sangue hakkari
10461	braceleiras sombrias
10462	cinto sombrio
10463	molde mascara de umbratrama
10464	cajado de comando
10465	ovo de hakkar
10466	circulo de pedra atal ai
10467	algibeira do comerciante
10478	gema de mana do jak
10479	bolsa de comercio de kovic
10498	micro ajustador giromatico
10499	oculos brilho do olhar
10500	oculos igneos
10501	ultra oculos olho de gato
10502	oculos de poder magico xtremo
10503	oculos cor de rosa
10504	lente verde
10505	po explosivo macico
10506	capacete das profundezas
10507	dinamite macica
10508	bacamarte de mithril
10509	coracao das chamas
10510	rifle de mithril de grosso calibre
10511	oleo de golem
10512	projeteis mithrilicos de alto impacto
10513	cartuchos giroscopicos de mithril
10514	bomba de fragmentacao de mithril
10515	tocha da retribuicao
10518	manto paraquedas
10538	tabuleta de beth amara
10539	tabuleta de jin yael
10540	tabuleta de markri
10541	tabuleta de sael hai
10542	capacete de mineracao goblinico
10543	capacete de operario goblinico
10544	malho de pau cardo
10545	oculos gnomicos
10546	mira letal
10547	faca campeira
10548	mira de francoatirador
10549	calcas do rancheiro
10550	mitenes de la
10551	punhal de placas de torio
10552	simbolo de ragnaros
10553	colete do encarregado
10554	calcas do encarregado
10556	circulo de pedra
10558	nucleo de forca de ouro
10559	tubo de mithril
10560	gatilho instavel
10561	carcaca de mithril
10562	bomba de alto explosivo
10563	decalque runa de beth amara
10564	decalque runa de jin yael
10565	decalque runa de markri
10566	decalque runa de sael hai
10567	lanca espinho
10569	tesouro da revoada negra
10570	homicida
10571	clavosso de ebano
10572	estilha congelante
10573	acoita osso
10574	mortalha cadaverica
10575	muda de pele da revoada negra
10576	dragonete mecanico de mithril
10577	morteiro goblinico
10578	botas penseiras
10579	flecha explosiva
10580	caixabum goblinica
10581	vestimenta da cabeca da morte
10582	andejo do urzal
10583	arnes afasta espinho
10584	punhos ventempesta
10585	radio goblinico
10586	o bombao
10587	distribuidor de bombas goblinico
10588	capacete foguete goblinico
10589	pedra do juramento da revoada de ysera
10590	caixa preta esburacada
10592	elixir olho de gato
10593	fragmento imperfeito de draenetista
10595	kum isha s junk
10597	cabeca da maga rimtori
10598	cabeca ensanguentada de hetaera
10599	cabeca arrebentada de hetaera
10600	cabeca ferida de hetaera
10601	diagrama oculos brilho do olhar
10602	diagrama mira letal
10603	diagrama ultra oculos olho de gato
10604	diagrama rifle de mithril de grosso calibre
10605	diagrama oculos de poder magico xtremo
10606	diagrama manto paraquedas
10607	diagrama capacete das profundezas
10608	diagrama mira de francoatirador
10609	diagrama dragonete mecanico de mithril
10610	sangue de hetaera
10620	minerio de torio
10621	pergaminho runico
10622	bandeira de kadrak
10623	mordida do inverno
10624	arco ferroante
10625	lamina furtiva
10626	martelo da ira
10627	porrete do cao sorridente
10628	golpe mortal
10629	botas do andanevoa
10630	halo cata almas
10631	manoplas d agua suja
10632	bracadeiras escamalodo
10633	perneiras conchaprata
10634	circulo do olho da mente
10635	perneiras encadeadas pintadas
10636	luvas nomades
10637	luvas do cervejeiro
10638	capa drapejada longa
10639	cogumelo jacinto
10640	linfa de lenhateia
10641	lirio lunapetala
10642	antidoto de iverron
10643	carta lacrada para ag tor
10644	receita combustivel de foguete goblinico
10645	raio gnomico da morte
10646	carga sapadora goblinica
10647	tinta de engenheiro
10648	pergaminho em branco
10649	lasca de pesadelo
10650	juba de javatusco pestilento
10651	cristal arcano de concentracao rachado
10652	vontade do gigante da montanha
10653	botas abretrilhas
10654	luvas de trancajuta
10655	culotes semente de junca
10656	colete de malha de tronco
10657	dragonas barraltas
10658	galochas do atoleiro
10659	estilhaco dos cascos fendidos
10660	primeira tabuleta mosh aru
10661	segunda tabuleta mosh aru
10662	ovo de hakkar cheio
10663	essencia de hakkar
10664	um bilhete para a maga rimtori
10678	bilhete de magatha
10679	bilhete de andron
10680	bilhete de sona rima
10681	bilhete de tauriel
10682	pedra do juramento de belnistrasz
10683	mochila do explorador
10684	paraquedas colossal
10686	egide de batalha
10687	ampola vazia rotulada nº 1
10688	ampola vazia rotulada nº 2
10689	ampola vazia rotulada nº 3
10690	ampola vazia rotulada nº 4
10691	ampola cheia rotulada nº 1
10692	ampola cheia rotulada nº 2
10693	ampola cheia rotulada nº 3
10694	ampola cheia rotulada nº 4
10695	caixa de ampolas vazias
10696	espada destruicao vil de azsharita encantada
10697	adaga destruicao vil de azsharita encantada
10698	cajado destruicao vil de azsharita encantada
10699	moracea de yeh kinya
10700	botas encarnadas
10701	botas de zua tec
10702	botas ogricas gigantescas
10703	lamina bestial
10704	estilhacador garrafria
10705	munhequeiras do salgueiro
10706	cinturao escama noturna
10707	grevas de ferreiro de aco
10708	orbe do feitico craniano
10709	orbe de lumepedra
10710	anel dragogarra
10711	colar de sangue de dragao
10712	elixir do arnaldo
10713	instrucoes cilindro marchetado de mithril
10714	azsharita cristalizada
10715	telescopio do kam arawn
10716	raio gnomico encolhedor
10717	bussola do kam arawn
10718	chinforimpola do kam arawn
10719	alarme movel
10720	projetor gnomico redomatico
10721	cinto gnomico de prevencao de ferimentos
10722	frango recheado do kam arawn
10723	radioamador gnomico
10724	botas foguete gnomicas
10725	frango de batalha gnomico
10726	casquete gnomico de controle mental
10727	pistola dragonica goblinica
10728	molde camisa preta do espadachim
10738	remessa para galvan
10739	anel da fortitude
10740	coxotes do centuriao
10741	capacete de lordrec
10742	perneiras da revoada
10743	cimeira da chama draconica
10744	machado do draco ebaneo
10745	omoplatas kaylari
10746	avambracos de runaco
10747	faixa do professor
10748	botas de flanar
10749	elmo de vanguarda
10750	punhal de forca vital
10751	diadema explodegema
10752	arca incrustada de esmeraldas
10753	amuleto de grol
10754	amuleto de sevine
10755	amuleto de allistarj
10757	protecao do profanador
10758	javalibur
10759	chifre decepado de profanador
10760	punhos de javali
10761	adaga fria ira
10762	vestes do lich
10763	celada metal de gelo
10764	armadura criomortis
10765	falanges
10766	varinha praga putrida
10767	guarda do javali selvagem
10768	cinto do campeao dos javalis
10769	olho faiscante de mordresh
10770	cranio inerte de mordresh
10771	faixa do mago da morte
10772	cutelo do glutao
10773	urna hakkari
10774	omoplatas couro de carne
10775	carapaca de tutan kash
10776	capa seda de aranha
10777	luvas aracnideas
10778	colar do santuario
10779	sangue de demonio
10780	marca de hakkar
10781	peitoral de hakkari
10782	mortalha hakkari
10783	espaldares atal ai
10784	peitoral atal ai
10785	perneiras atal ai
10786	botas atal ai
10787	luvas atal ai
10788	cinturao atal ai
10789	manual das disciplinas de engenharia
10790	cartao de engenheiro gnomico associado
10791	cartao de engenheiro goblinico associado
10792	pacto de sigilo do nixx
10793	pacto de sigilo do superchispa
10794	pacto de sigilo do olhatorto
10795	anel garradraca
10796	pedra de draco
10797	soprafogo
10798	anel da presa de atal arion
10799	picante
10800	bracadeiras aguanegra
10801	botas coleantes
10802	manto asaveu
10803	lamina do ignobil
10804	punho dos malditos
10805	devoramortos
10806	vestimenta do profeta atal ai
10807	kilt do profeta atal ai
10808	luvas do profeta atal ai
10818	pergaminho de yeh kinya
10819	pena de coruscante
10820	cinto da semeadura
10821	manto do semeador
10822	dragonetinho negro
10823	espada do vencedor
10824	talisma de brilhambar
10826	cajado da tradicao
10827	tunica do topografo
10828	unha ma
10829	olho do dragao
10830	granada de fragmentacao m73
10831	orbe vil
10832	manual de proprietario do rastreador vil
10833	chifres de eranicos
10834	kit de rastreador canisvil
10835	escudo da supremacia
10836	bastao de corrosao
10837	dente de eranicos
10838	poder do hakkar
10839	bilhete cristalizado
10840	bilhete cristalizado
10841	cha de espinheira dourada
10842	sarongue escameolo
10843	capa de pelepluma
10844	agulha de hakkar
10845	abraco do guerreiro
10846	grevas injetadas de sangue
10847	chamado do dragao
10858	instrucoes malho de ferro macico
10918	veneno ferino
10919	luvas de boticario
10920	veneno ferino ii
10921	veneno ferino iii
10922	veneno ferino iv
10938	essencia magica inferior
10939	essencia magica maior
10940	po estranho
10958	colar da hilaria
10959	bolsa de pelego de demonio
10978	estilhaco luminoso pequeno
10998	essencia astral inferior
10999	ferrovil
11000	chave de umbraforja
11018	solo de un goro
11020	bornal de sempre viva
11022	pacote de sementes de tharlendris
11023	galinha ancona
11024	caixa de erva sempre viva
11026	caixa de sapo arboricola
11027	caixa de sapo dos bosques
11038	formula encantamento inferior de espirito arma de 2m
11039	formula encantamento menor de agilidade manto
11040	grao matinal
11058	argola nasal de sha ni
11078	chave da arca de reliquias
11079	cabeca decepada do gor tesh
11080	cabeca decepada do gor tesh
11081	formula encantamento inferior de protecao escudo
11082	essencia astral maior
11083	po d alma
11084	estilhaco luminoso grande
11085	chave do cofre do cliente do mes
11086	jang thraze a protetora
11098	formula encantamento inferior de resistencia a sombra manto
11099	minerio de ferro negro
11101	formula encantamento inferior de forca bracadeiras
11102	ovo choco de dardejante
11103	vale sementes
11104	bussola grande
11105	mapa em de pergaminho enrolado
11106	chave de cabeca de leao
11107	um pacote pequeno
11108	fotografia esmaecida
11109	racao especial de galinha
11110	ovo de galinha
11111	ovo quebrado de dardejante
11112	equipamento de pesquisa
11113	caixote de comestiveis
11114	osso de dinossauro
11115	chave do cofre secreto
11116	um diario destrocado
11118	pedra arcadica
11119	colheita da madel
11120	martelo de belgrom
11121	talwar aguanegra
11122	o burro e a cenoura
11123	perneiras do andarilho das chuvas
11124	elmo do exilio
11125	manifesto da uva
11126	tabuleta de kurniya
11127	material reaproveitado
11128	bastao dourado
11129	essencia dos elementos
11130	bastao runico dourado
11131	amostra de parede de colmeia
11132	frasco para amostra vazio
11133	espada de treinamento de linken
11134	essencia mistica inferior
11135	essencia mistica maior
11136	espada temperada de linken
11137	po visionario
11138	estilhaco faiscante pequeno
11139	estilhaco faiscante grande
11140	chave de cela da prisao
11141	isca
11142	rebimboca quebrada
11143	chumbalheira
11144	bastao de veraprata
11145	bastao runico de veraprata
11146	rebimboca quebrada e surrada
11147	capa do manual da rebimboca
11148	pagina do manual da rebimboca
11149	manual da rebimboca
11150	formula encantamento de mineracao luvas
11151	formula encantamento de herborismo luvas
11152	formula encantamento de pescaria luvas
11162	espada superior de linken
11163	formula encantamento inferior de deflexao bracadeiras
11164	formula encantamento inferior de matador de feras arma
11165	formula encantamento inferior de matador de elementais arma
11166	formula encantamento de esfolamento luvas
11167	formula encantamento inferior de espirito botas
11168	formula encantamento inferior de bloqueio escudo
11169	livro de aquor
11171	ferrovil
11172	garras prateadas
11173	coracao de ferrarbol
11174	essencia eterea inferior
11175	essencia eterea maior
11176	po onirico
11177	estilhaco radiante pequeno
11178	estilhaco radiante grande
11179	chama dourada
11184	cristal de poder azul
11185	cristal de poder verde
11186	cristal de poder vermelho
11187	bracadeiras folhaste
11188	cristal de poder amarelo
11189	vestes do bosque
11190	luvas vinosas
11191	botas do fazendeiro
11192	luvas do provedor
11193	peitoral lufardente
11194	cota de escamaprisma
11195	guarda peito forjado para guerra
11196	medalhao de explosao mental
11197	chave do guardiao sombrio
11198	runa de fuga
11199	escudo 1 do engenheiro
11200	escudo 2 do engenheiro
11201	escudo 3 do engenheiro
11202	formula encantamento de vigor escudo
11203	formula encantamento de mineracao avancada luvas
11204	formula encantamento maior de espirito bracadeiras
11205	formula encantamento de herborismo avancado luvas
11206	formula encantamento inferior de agilidade manto
11207	formula encantamento de arma ignea arma
11208	formula encantamento de demonicidio arma
11222	cabeca do krom zar
11223	formula encantamento de deflexao bracadeiras
11224	formula encantamento de resistencia ao gelo escudo
11225	formula encantamento maior de vigor bracadeiras
11226	formula encantamento de pericia de montaria luvas
11227	pedaco do estandarte de krom zar
11228	muda de pele de revoada frenetica
11229	cinturao escama brilhante
11230	essencia abrasadora aprisionada
11231	muda de pele alterada da revoada negra
11242	raiz do mal
11243	elixir videre
11262	orbe de lorica
11263	varinha da forca eterea
11265	malho de madeira densa
11266	estilhaco elemental fraturado
11267	amostra de estilhaco elemental
11268	cabeca de argelmach
11269	nucleo de elemental intacto
11270	pacto assinado pelo nixx
11282	pacto assinado pelo olhatorto
11283	pacto assinado pelo superchispa
11284	balas de precisao
11285	flecha serrilhada
11286	grilhoes de torio
11287	varinha magica inferior
11288	varinha magica maior
11289	varinha mistica inferior
11290	varinha mistica maior
11291	estrelenha
11302	forca de uther
11303	arco curto de qualidade
11304	arco longo de qualidade
11305	arco curto denso
11306	arco recurvo robusto
11307	arco longo macico
11308	arco curto silvestre
11309	o coracao da montanha
11310	dragonas do videchamas
11311	capa de escamabrasa
11312	receita perdida de cervaforte
11313	cabeca do ribas
11315	broto de petala sangrenta
11316	petala sangrenta
11318	bruma de atal ai
11319	fulminadora descarregada
11320	fulminadora de petala sangrenta
11321	monstro espada2m horda gigantesca
11324	mochila do explorador
11325	caneca de cerveja ferro negro
11362	aljava media
11363	bornal medio para projeteis
11364	tabardo de ventobravo
11366	carta de helendis flumicornio
11367	apelo de salomao a bolvar
11368	decreto de bolvar
11370	minerio de ferro negro
11371	barra de ferro negro
11382	sangue da montanha
11384	dentes quebrados de basilisco
11385	escama de basilisco
11386	olho esponjoso de basilisco
11387	coracao de basilisco
11388	peconha de basilisco
11389	pele cintilante de basilisco
11390	presa quebrada de morcego
11391	asa espinhosa de morcego
11392	garra decepada de morcego
11393	cranio pequeno de morcego
11394	coracao de morcego
11395	orelha de morcego
11402	pelagem lustrosa de morcego
11403	presa grande de morcego
11404	olho maligno de morcego
11405	veio de prata gigante
11406	carcaca apodrecida de urso
11407	pelagem rasgada de urso
11408	mandibula de urso
11409	flanco de urso
11410	garra de urso selvagem
11411	osso grande de urso
11412	ampola da nagmara
11413	ampola da nagmara cheia
11414	juba grisalha
11415	frutinhas mistas
11416	caixa toracica delicada
11417	asa penosa
11418	osso oco de asa
11419	ovo choco misterioso
11420	pena elegante de caligrafia
11422	brinde de renovacao do engenheiro goblinico
11423	brinde de renovacao do engenheiro gnomico
11442	kit de subdelegado de ventobravo
11444	javali do glutao implacavel
11445	flauta dos anciaos
11446	bilhete amassado
11462	faca descartada
11463	pacote extraviado
11464	informacoes perdidas do marechal vilasboas
11465	informacoes perdidas do marechal vilasboas
11466	relatorio do patiphe
11467	medalhao rocha negra
11468	pochete ferro negro
11469	bracadeiras feixessangue
11470	transcricao de tabuleta
11471	ovo fragil de dardejante
11472	lombo de espreitador jubaprata
11473	px83 enigmatron
11474	ovo de dardejante
11475	manto manchado de vinho
11476	pelagem de u cha
11477	garra branca de ravassauro
11478	pelagem de gorila de un goro
11479	pelagem de pisoteador de un goro
11480	pelagem de trovejador de un goro
11482	manual do usuario da torre de cristal
11502	omoplatas dermossapiens
11503	ambar de sangue
11504	pedaco de carcaca de manguadonte
11507	pelagem malhada de hiena
11508	sapatilhas do mestre do jogo
11509	glandula de feromonio de ravassauro
11510	cabeca do lar korwi
11511	lampiao cenariano
11512	retalho de pele maculada
11513	vitriolo maculado
11514	fluido malevo
11515	estilhaco de alma corrompida
11516	balsamo vegetal cenariano
11522	totem de prata de aquementas
11562	restauracao de cristal
11563	forca de cristal
11564	protecao de cristal
11565	subjugacao de cristal
11566	carga de cristal
11567	aguilhao de cristal
11568	bornal do torwa
11569	carne de manguadonte em conserva
11570	mistura de feromonios em conserva
11582	unguento perfido
11583	sabra
11584	surpresa de sabra
11590	kit de reparos mecanicos
11602	chave do glutao implacavel
11603	fatiador rasgavil
11604	peitoral ferro negro
11605	omoplatas ferro negro
11606	cota de malha ferro negro
11607	talhador ferro negro
11608	pulverizador ferro negro
11609	muda de pele alterada da revoada negra
11610	instrucoes pulverizador ferro negro
11611	instrucoes talhador ferro negro
11612	instrucoes peitoral ferro negro
11614	instrucoes cota de malha ferro negro
11615	instrucoes omoplatas ferro negro
11617	suprimentos de eridan
11622	arcano inferior da reflexao
11623	capa lanca quimera
11624	sobreveste magna
11625	esfera encantada
11626	capa veu negro
11627	grevas papa jardas
11628	arco do mestre de matilha
11629	rifle do mestre de matilha
11630	projeteis lascarrocha
11631	guarda litocasco
11632	omoplatas dos escombros
11633	carapaca aracnopresa
11634	luvas de teiasseda
11635	estoque gancho mau
11642	arcano inferior da constituicao
11643	arcano inferior da tenacidade
11644	arcano inferior da resiliencia
11645	arcano inferior da voracidade
11646	arcano inferior da voracidade
11647	arcano inferior da voracidade
11648	arcano inferior da voracidade
11649	arcano inferior da voracidade
11662	faixa ban thok
11665	punhos do ogro vigia
11668	flauta de xavaric
11669	grande anel arcano
11674	ligavil de flamejade
11675	botas umbradictas
11677	capa podretumba
11678	carapaca de anub shiah
11679	guarda bracos rubicundos
11682	ampola de eridan
11684	inimigo de ferro
11685	omoplatas de courotala
11686	cinturao da furia bestial
11702	esfolador do grisalho
11703	cinturao muro de pedra
11722	espaldares de metalreles
11723	flamberge balanceada de massoaco
11724	pacote atrasado
11725	haste de perna de cristal macico
11726	cota encadeada do gladiador selvagem
11727	livro de a massoaco
11728	perneiras do gladiador selvagem
11729	elmo do gladiador selvagem
11730	guantes do gladiador selvagem
11731	grevas do gladiador selvagem
11732	incunabulo da reflexao
11733	incunabulo da constituicao
11734	incunabulo da tenacidade
11735	tapa olho da colera
11736	incunabulo da resiliencia
11737	incunabulo da voracidade
11742	mochila do viajor
11743	punho de rocha
11744	punho de sangue
11745	punhos do falange
11746	elmo cranio de golem
11747	vestes do vagachamas
11748	caduceu pirico
11749	perneiras de escama ignea
11750	baculo lenhoso
11751	essencia flamejante
11752	sangue negro dos atormentados
11753	olho de kajal
11754	diamante preto
11755	colar de verek
11764	braceleiras de courogris
11765	munhequeiras de piromalha
11766	manilhas de flamapano
11767	guarda bracos de placa ignea
11768	bracadeiras incandescentes
11782	dragonas boreais
11783	cinturao acogelido
11784	lamina do mediador
11785	baluarte do golem de rocha
11786	pedra da terra
11787	botas litocasca
11802	perneiras de cristalava
11803	forca de magma
11804	cantil da espraga
11805	martelo de rubidio
11807	faixa do coracao ardente
11808	circulo de fogo
11809	ira chamejante
11810	forca de vontade
11811	coracao fumegante da montanha
11812	capa da salamandra de fogo
11813	formula coracao fumegante da montanha
11814	punhos derretidos
11815	mao da justica
11816	machado de batalha de forjaversa
11817	espada do grao general
11818	chave da casinha de pedrassuja
11819	folego renovado
11820	armadura real adornada
11821	perneiras da discordia
11822	botas pluriarranque
11823	kilt luminar
11824	elo ciclopico
11825	bombinha de estimacao
11826	fumacinho
11827	diagrama fumacinho
11828	diagrama bombinha de estimacao
11829	cinza de un goro
11830	escama de dimetrodonte palmado
11831	escama de pterrordax palmado
11832	explosao de conhecimento
11833	isca para a rainha gorishi
11834	piche supergrudento
11835	cerebro da rainha gorishi
11837	glandula odorifera gorishi
11839	monoculo do arquiteto chefe
11840	camisa do mestre construtor
11841	pantalonas do projetista senior
11842	dragonas do topografo mor
11843	comprovante bancario
11844	relatorio de un goro do almofarrista
11845	bolsa de couro artesanal
11846	beberagem especial de lhogolho
11847	manto surrado
11848	cinto de linhao
11849	bracadeiras de metal enferrujado
11850	capa curta do quiropusculo
11851	tunica do catador
11852	perneiras do errante
11853	botas do errante
11854	chave de fenda da rebimboca
11855	chave de torque
11856	lamina cerimonial elfica
11857	bastao santimonial
11858	capa da batalha ardua
11859	orbe lunajade
11860	para raios carregado
11861	cinturao da reprimenda
11862	anel de osso branco
11863	retalhador de osso branco
11864	lanca de osso branco
11865	botas do rancor
11866	cinto enlacado da nagmara
11867	manoplas da insanidade
11868	elo da sufocacao
11869	anel de sha ni
11870	orbe do oblivio
11871	espaldares do madeirame
11872	grevas de evitacao
11873	capa da nevoa eterea
11874	dragonas rachanuvem
11875	bracadeira nuvem zefira
11876	tunica espreitaprados
11882	perneiras do pioneiro
11883	pochete suja
11884	sobreveste luz do luar
11885	tocha de umbraforja
11886	mensagem urgente
11887	bau do circulo cenariano
11888	luvas de pesquisa do quintis
11889	brafoneiras de cascaferro
11902	espada da maestria de linken
11903	transportador de gato gatinho corrompido
11904	espirito de aquementas
11905	bumerangue de linken
11906	esmagaferas
11907	matador de feras
11908	botas de escavacao do arqueologo
11909	cinto de utilidades do escavador
11910	guarda pernas adornados
11911	perneiras de coparborea
11912	pacote de recipientes vazios de gosma
11913	elmo cristargila
11914	jarra de gosma amaldicoada vazia
11915	bloqueador de garoa do chislo
11916	focinheira do chislo
11917	limpa focinho do chislo
11918	luvas lajegrota
11919	grevas de placapenha
11920	ceifa almas
11921	colosso inexpugnavel
11922	lamina gravada em sangue
11923	martelo da dadiva
11924	vestes da coroa real
11925	fantasmalha
11926	peitoral causamortis
11927	coxotes do guardiao eterno
11928	cetro real de thaurissan
11929	perneiras da assombracao
11930	a capa nova do imperador
11931	retaliador deimoforja
11932	baculo guia da sabedoria
11933	joia da coroa
11934	selo do imperador
11935	pedra magmus
11936	cinto do cacador de reliquias
11937	saco gordo de moedas
11938	saco de gemas
11939	bracelete reluzente
11940	colar cintilante
11941	documentos falsos
11942	documentos legais
11943	escritura da ponte thandol
11944	botinhas de bebe ferro negro
11945	anel ferro negro
11946	colar de opala de fogo
11947	jarra de gosma amaldicoada cheia
11948	jarra de gosma maculada vazia
11949	jarra de gosma maculada cheia
11950	amoras do botao selvagem
11951	tuberculo de raiz acoite
11952	sopro de dragao noturno
11953	jarra de amostra pura vazia
11954	jarra de amostra pura cheia
11955	bolsa de recipientes de gosma vazios
11962	manilhas
11963	espaldares da penitencia
11964	clava golpepresto
11965	anel de quartzo
11966	saco de moedas pequeno
11967	anel de zircao
11968	anel de ambar
11969	circulo de jacinto
11970	anel de espinelio
11971	anel de ametista
11972	argola de cornalina
11973	anel de hematita
11974	anel de agua marinha
11975	anel de topazio
11976	anel de sardonica
11977	argola de serpentina
11978	anel de jaspe
11979	circulo de peridoto
11980	anel de opala
11981	anel de chumbo
11982	anel viridiano
11983	anel cromado
11984	anel de cobalto
11985	anel ceruleo
11986	aro de talio
11987	circulo de iridio
11988	elo de telurio
11989	argola de vanadio
11990	argola de selenio
11991	anel de mercurio
11992	anel de cinabrio
11993	anel de argila
11994	anel de coral
11995	anel de marfim
11996	anel de basalto
11997	circulo de clorastolita
11998	argola de azeviche
11999	aro de magnetita
12000	decepador
12001	anel de onix
12002	circulo de marmore
12003	cerveja escura dos anoes
12004	anel obsidiano
12005	anel de granito
12006	anel do prado
12007	anel da pradaria
12008	anel da savana
12009	anel da tundra
12010	anel do charco
12011	aro da floresta
12012	anel do pantano
12013	anel do deserto
12014	anel artico
12015	anel do pantanal
12016	anel da selva
12017	anel prismatico
12018	elmo do protetor
12019	talisma ceruleo
12020	gargantilha de talio
12021	escarpes de blindaplaca
12022	corrente de iridio
12023	colar de telurio
12024	talisma de vanadio
12025	colar de selenio
12026	pingente de mercurio
12027	colar de cinabrio
12028	colar de basalto
12029	talisma de clorastolita
12030	corrente de azeviche
12031	colar de magnetita
12032	gargantilha de onix
12033	joias da familia thaurissan
12034	colar de marmore
12035	pingente obsidiano
12036	colar de granito
12037	carne misteriosa
12038	selo de lagrave
12039	colar da tundra
12040	pingente da floresta
12041	perneiras cortavento
12042	colar do pantano
12043	gargantilha do deserto
12044	pingente artico
12045	pingente do pantanal
12046	colar da selva
12047	colar espectral
12048	pingente prismatico
12049	peitoral trinca aco
12050	botas enevoadas
12051	manoplas de latao
12052	anel da lua
12053	anel de rocha vulcanica
12054	anel demoniaco
12055	anel de poeira estelar
12056	anel dos ceus
12057	anel de escama de dragao
12058	anel de osso demoniaco
12059	medalhao do conquistador
12060	bilhete de shindrell
12061	lamina do discernimento
12062	lamina da aptidao guerreira
12064	capuz do mestre do jogo
12065	protetor dos elementos
12066	capa de xistocouro
12082	espaldares de couro de serpe
12083	faixa valconiana
12102	anel do aristocrata
12103	estrela de mystaria
12104	tunica espinopetrea
12105	perneiras de malha soberba
12106	peitoral de rochapele
12107	perneiras de murmusseda
12108	armadura de escama basaltica
12109	sobreveste da lua lazuli
12110	clamide lancachuva
12111	manoplas de placamagma
12112	bracadeiras do demonio da cripta
12113	capa helionata
12114	luvas do ocaso
12115	amarra impavida
12122	sucata do kum isha
12143	chave de espinodrago
12144	ovosciloscopio
12162	instrucoes espada curta de ferro temperado
12163	instrucoes espada larga de lunaco
12164	instrucoes machado solido de ferro
12184	carne de raptor
12185	chapeu do almirante da vela sangrenta
12190	pocao do sono sem sonhos
12191	bau do aurora de prata
12192	bau do veu das brumas
12202	carne de tigre
12203	carne vermelha de lobo
12204	carne gorda de kodo
12205	carne de aranha branca
12206	carne tenra de caranguejo
12207	ovo gigantesco
12208	carne tenra de lobo
12209	file de lobo magro
12210	raptor assado
12211	costelinhas temperadas de lobo
12212	ensopado da selva
12213	escondidinho de carniceiro
12214	ensopado misterioso
12215	ensopado grosso de kodo
12216	chili temperado de caranguejo
12217	chili bafo de dragao
12218	omelete monstro
12219	selo da ascensao sem adorno
12220	bracadeira elemental intacta
12223	asa de morcego carnuda
12224	asa de morcego crocante
12225	vara de pescar da familia blump
12226	receita asa de morcego crocante
12227	receita file de lobo magro
12228	receita raptor assado
12229	receita costelinhas picantes de lobo
12230	amostra de visgo da selva maleva
12231	receita ensopado da selva
12232	receita escondidinho de carniceiro
12233	receita ensopado misterioso
12234	amostra corrompida da selva maleva
12235	amostra de visgo de un goro
12236	amostra pura de un goro
12237	pedacos delicados de caranguejo
12238	garoupa da costa negra
12239	receita chili bafo de dragao
12240	receita ensopado grosso de kodo
12241	ovo de dragao recolhido
12242	ossos de criaturas marinhas
12243	garra fumegante
12247	faca de lamina larga
12248	punhal audaz
12249	machado impiedoso
12250	machado da meia noite
12251	trocho
12252	cajado da protecao
12253	manto vermelho brilhante
12254	manto bem oleado
12255	perneiras palidas
12256	perneiras de brasatrama
12257	cinto pesado entalhado
12258	cinto do abraco da serpente
12259	adaga de aco irisado
12260	lamina dourada calcinante
12261	instrucoes lamina dourada calcinante
12262	jaula vazia de filhote de worg
12263	filhote de worg enjaulado
12264	jaula de worg
12282	machado de batalha usado
12283	essencia da reproducao
12284	draco incarcinatrix 900
12286	prototipo de ovosciloscopio
12287	modulo colectronico
12288	gosma corrupta enfrascada
12289	carcaca de tartaruga marinha
12291	amostra de gosma amalgamada
12292	caixa com marcacoes estranhas
12293	fio de ouro de qualidade
12295	perneiras da milicia do povo
12296	centelha da milicia do povo
12299	luvas de rede
12300	orbe de energia draconica
12301	chave da gaiola de bambu
12302	redeas do sabre de gelo
12303	redeas do sabre da noite
12323	selo da ascensao de metal bruto
12324	selo forjado da ascensao
12325	redeas do leopardo primevo
12326	redeas do gato de sabre fulvo
12327	redeas do gato de sabre dourado
12330	trompa do lobo vermelho
12334	lascas de friomalho
12335	gema de espinho fumeo
12336	gema de agulhapetrea
12337	gema de machado sangrento
12339	presente de vaelan
12341	amostra de fruta bosquenero
12342	amostra de grao bosquenero
12343	amostra de castanha bosquenero
12344	selo da ascensao
12345	pertences de biju
12346	bacia de limpeza vazia
12347	bacia de limpeza cheia
12349	amostra do rio fontescarpa
12350	tubo de amostragem vazio
12351	trompa do lobo artico
12352	broche do finitudo
12353	redea de garanhao branco
12354	redea de baio
12355	talisma de corrupcao
12356	ovo de manticora de alcandora
12358	tabuleta de pedranegra
12359	barra de torio
12360	barra de arcanita
12361	safira azul
12363	cristal arcano
12364	esmeralda enorme
12365	pedra densa
12366	pele grossa de yeti
12367	chifre impoluto de yeti
12368	aposta da aurora
12369	cetro de vectus
12382	chave da cidade
12383	pena lunamarca
12384	provisoes de mau ari
12402	ovo velho
12404	pedra de afiar densa
12405	armadura de torio
12406	cinto de torio
12408	bracadeiras de torio
12409	botas de torio
12410	elmo de torio
12411	terceira tabuleta mosh aru
12412	quarta tabuleta mosh aru
12414	perneiras de torio
12415	peitoral radiante
12416	cinto radiante
12417	diadema radiante
12418	luvas radiantes
12419	botas radiantes
12420	perneiras radiantes
12422	torso de placa imperial
12424	cinto de placa imperial
12425	bracadeiras de placa imperial
12426	botas de placa imperial
12427	elmo de placa imperial
12428	omoplatas de placa imperial
12429	perneiras de placa imperial
12430	e ko de sabre de gelo
12431	e ko de invernoso
12432	e ko de dentilhaco
12433	e ko de coruscante
12434	e ko de ventogelante
12435	e ko de cardo de gelo
12436	e ko de friomalho
12437	caixote de espargosa
12438	carta de vera
12440	magic knucklebone dnd
12442	charm pouch dnd
12443	knucklebone pouch dnd
12444	chifre inteirico de quimera ventogelante
12445	pacote do felnok
12446	mosquete de sidermar
12447	arco de pau cardo
12448	fuzil leve de caca
12449	arco primitivo
12450	lufada juju
12451	poderio juju
12452	monstro escudo horda a02 prata
12455	brasa juju
12457	calafrio juju
12458	astucia juju
12459	esquiva juju
12460	poder juju
12462	abraco da serpente do vento
12463	acougueiro dracopresa
12464	garras rubrofogo
12465	clamide do ocaso
12466	corda albagulha
12467	ovo alienigena
12468	varinha de chilton
12469	mutilador
12470	tornozeleira do espreitareia
12471	cajado do nomade do deserto
12472	termometro do gualter
12522	luvas de aviacao do gomez
12524	amuleto de penas azuis
12525	suprimentos do jaron
12527	rachacostela
12528	o martelo do juiz
12529	jaula de queimateia
12530	ovo de aranha do pinaculo
12531	agulha calcinante
12532	aguilhao do lapidador
12533	pique da brutalidade
12534	cabeca do omokk
12535	gumeliso forjamaldita
12542	traje da pira funeraria
12543	pedra cantante de altaforja
12544	determinacao de thrall
12545	olho de orgrimmar
12546	manilhas aristocraticas
12547	guantes de mar alom
12548	vontade de magni
12549	guarda cerebro
12550	grilhoes runicos de golem
12551	manto escudopetreo
12552	manta balsamica
12553	botas passopresto
12554	maos do arauto exaltado
12555	grevas do mavorcio
12556	botas da alta sacerdotisa
12557	espaldares de acoebano
12558	colar de penas azuis
12562	documentos importantes dos rocha negra
12563	comando do senhor da guerra trincador
12564	bilhete de assassinato
12565	porta gato da winna
12566	frasquinho endurecido
12567	frasquinho cheio
12582	keris de zul serak
12583	serra maldita do mao negra
12584	espada longa do grao marechal
12585	medalhao de ventobravo
12586	vesicula de peconha imatura
12587	olho de laceral
12588	ombreiras de espetosso
12589	faixa plumafina
12590	adagavil
12592	lamina negra de shahram
12602	defletor draconiano
12603	tunica elonoturno
12604	tiara do fogo estelar
12605	escalavrador sinuoso
12606	cinturao cristalizado
12607	escama cromatica brilhante
12608	avental do acougueiro
12609	veste de visao policromatica
12610	omoplatas de placa runica
12611	botas de placa runica
12612	elmo de placa runica
12613	peitoral runico
12614	perneiras de placa runica
12615	tunica selvagem de malha
12616	botas selvagens de malha
12617	omoplatas selvagens de malha
12618	peitoral de torio encantado
12619	perneiras de torio encantado
12620	elmo de torio encantado
12621	garfo do demonio
12622	carne de dentilhaco
12623	carne de ventogelante
12624	cota de malha cardagreste
12625	omoplatas d alvorada
12626	manilhas funereas
12627	deslocador temporal
12628	peitoral forjado pelo demonio
12630	cabeca do laceral mao negra
12631	manoplas de placa abrasadoras
12632	manoplas da tempestade
12633	elmo da alma alva
12634	cinturao do cinzelador
12635	pergaminho simples
12636	elmo do grande chefe
12637	manoplas backorianas
12638	relogio de andorhal
12639	manoplas da fortaleza
12640	elmo coracao de leao
12641	cota de malha invulneravel
12642	orbe infernal purificado
12643	contrapeso denso
12644	pedra de amolar densa
12645	espigao de escudo de torio
12646	esmeralda infusa
12647	rubi de felhas
12648	espirito de canisvil aprisionado
12649	espirito infernal aprisionado
12650	amortecedor ajustado
12651	corvonegro
12652	relatorio de reconhecimento de biju
12653	gancho estripador
12654	tiromaldito
12655	barra de torio encantado
12662	runa demoniaca
12663	galho de carvalho com glifos
12682	instrucoes armadura de torio
12683	instrucoes cinto de torio
12684	instrucoes bracadeiras de torio
12685	instrucoes cinto radiante
12687	instrucoes omoplatas de placa imperial
12688	instrucoes cinto de placa imperial
12689	instrucoes peitoral radiante
12690	instrucoes bracadeiras de placa imperial
12691	instrucoes cota de malha cardagreste
12692	instrucoes espigao de escudo de torio
12693	instrucoes botas de torio
12694	instrucoes elmo de torio
12695	instrucoes luvas radiantes
12696	instrucoes peitoral forjado pelo demonio
12697	instrucoes botas radiantes
12698	instrucoes omoplatas d alvorada
12699	instrucoes manoplas de placa abrasadoras
12700	instrucoes botas de placa imperial
12701	instrucoes elmo de placa imperial
12702	instrucoes diadema radiante
12703	instrucoes manoplas da tempestade
12704	instrucoes perneiras de torio
12705	instrucoes torso de placa imperial
12706	instrucoes omoplatas de placa runica
12707	instrucoes botas de placa runica
12708	caixote de suprimentos da encruzilhada
12709	esfolador de lepido
12710	naco brilhante de carne da besta
12711	instrucoes elmo da alma alva
12712	mojo do warosh
12713	instrucoes perneiras radiantes
12714	instrucoes elmo de placa runica
12715	instrucoes perneiras de placa imperial
12716	instrucoes elmo do grande chefe
12717	instrucoes elmo coracao de leao
12718	instrucoes peitoral runico
12719	instrucoes perneiras de placa runica
12720	instrucoes manoplas da fortaleza
12721	meio pingente da sorte
12722	outra metade do pingente da sorte
12723	pingente da sorte
12724	embrulho da janice
12725	instrucoes elmo de torio encantado
12726	instrucoes perneiras de torio encantado
12727	instrucoes peitoral de torio encantado
12728	instrucoes cota de malha invulneravel
12730	pergaminho do warosh
12731	pelego imaculado da fera
12732	agave incendia
12733	carne de sabre de gelo sagrado
12734	fio escarlate encantado
12735	sutura de abominacao puida
12736	fluido de embalsamamento de friomurmuro
12737	erva do emo
12738	chave da casinha dos dalson
12739	chave do armario dos dalson
12740	quinta tabuleta mosh aru
12741	sexta tabuleta mosh aru
12752	casquete do sabio escarlate
12753	pele de sombra
12756	perneiras do arcanismo
12757	peitoral da sede de sangue
12762	sigilo dos planos
12763	eterfruta de un goro
12764	montante de torio
12765	bilhete secreto nº 1
12766	bilhete secreto nº 2
12768	bilhete secreto nº 3
12769	desbasteiro de lenhavil
12770	informacoes de biju
12771	frasco vazio de aguardente
12772	martelo marchetado de torio
12773	machadinha ornada de torio
12774	limiar da aurora
12775	machado de batalha de torio enorme
12776	martelo de batalha encantado
12777	florete fulgurante
12778	bau de documentos
12779	gume runico
12780	comando do general drakkisath
12781	serenidade
12782	corrupcao
12783	acerta peito
12784	retalhador de arcanita
12785	po de incendia
12789	corneta de uber bonus teste
12790	campeao de arcanita
12791	estoque do taberneiro
12792	martelo vulcanico
12793	tunica do mixologo
12794	martelo magistral da tempestade
12795	garra sangrenta
12796	martelo dos titas
12797	guardafria
12798	aniquilador
12799	opala grande
12800	diamante azerotiano
12802	lancanegra
12803	essencia viva
12804	mojo poderoso
12805	orbe de fogo
12806	peitoral runico de metal bruto
12807	estandarte do flagelo
12808	essencia de morte viva
12809	pedra guardia
12810	couro encantado
12811	orbe da retidao
12812	manoplas de placa crua
12813	frasco de meleca misteriosa
12814	chama engarrafada
12815	tocha sinalizadora
12816	instrucoes montante de torio
12817	instrucoes desbasteiro de lenhavil
12818	instrucoes martelo marchetado de torio
12819	instrucoes machadinha ornada de torio
12820	aguardente invernosa
12821	instrucoes limiar da aurora
12822	gotinha de horror toxico
12823	instrucoes machado de batalha de torio enorme
12824	instrucoes martelo de batalha encantado
12825	instrucoes florete fulgurante
12826	instrucoes gume runico
12827	instrucoes serenidade
12828	instrucoes martelo vulcanico
12829	caixote dos invernosos
12830	instrucoes corrupcao
12831	instrucoes garra sangrenta
12832	instrucoes lancanegra
12833	instrucoes martelo dos titas
12834	instrucoes campeao de arcanita
12835	instrucoes aniquilador
12836	instrucoes guardafria
12837	instrucoes martelo magistral da tempestade
12838	instrucoes retalhador de arcanita
12839	instrucoes acerta peito
12840	pedra do flagelo do lacaio
12841	pedra do flagelo do invasor
12842	registro escrito grosseiramente
12843	pedra do flagelo do corruptor
12844	simbolo de bravura da aurora argentea
12845	medalhao da fe
12846	ordem da aurora argentea
12847	pique manchado de almas
12848	pique manchado de sangue
12849	saco que o diabo beijou
12871	carapaca cromatica
12884	casco de arnak
12885	boneca de pamela
12886	cabeca da boneca de pamela
12887	parte esquerda da boneca de pamela
12888	parte direita da boneca de pamela
12891	picareta do jaron
12894	anel de casamento do josefo
12895	peitoral da revoada cromatica
12896	primeiro fragmento de reliquia
12897	segundo fragmento de reliquia
12898	terceiro fragmento de reliquia
12899	quarto fragmento de reliquia
12900	anais da vila das flechas
12903	guarda pernas do desafiante cromatico
12904	chapeu swami super especial do shawn
12905	capa do fogo indomito
12906	agua purificada do poco lunar
12907	agua corrompida do poco lunar
12922	cantil vazio
12923	escama do awbee
12924	vela ritual
12925	pele da serpente arikara
12926	elo flamejante
12927	omoplatas golpecerto
12928	yeti mecanico da umi
12929	talisma furiarrubra
12930	junco rosabrava
12935	guarda pernas do mestre guerreiro
12936	braceleiras belinato
12938	sangue dos herois
12939	guardiao tribal de dal rend
12940	encargo sagrado de dal rend
12942	chave da jaula da pantera
12945	coxotes do desafiante cromatico
12946	dispositivo hipercapacitador
12947	anel da audacia de alex
12952	cranio de gyth
12953	coifa olho de dragao
12954	incunabulo de davil
12955	escudo de trilharrubra
12956	cranio de horgus
12957	espada estilhacada de marduk
12958	receita transmutar arcanita
12960	penas de guerra tribais
12963	perneiras do mestre de espadas
12964	guarda pernas de tristam
12965	perneiras de mortalha espectral
12966	guarda bracos de brumanegra
12967	manto de sangreluna
12968	capa do tecegelo
12969	salgueiro intruso
12970	placa cerimonial do general
12973	bala de canhao escarlate
12974	o cavaleiro negro
12975	machado do prospector
12976	lamina ferroque
12977	luvas punhomago
12978	cinto traztormenta
12979	manto fogazar
12982	guarda pes de trama de prata
12983	clava rakzur
12984	clamaceus
12985	anel de defesa
12987	calcoes de trevatrama
12988	tunica astroptikon
12989	mordida de gargula
12990	fio da navalha
12992	lamina calcinante
12994	manoplas de torbia
12996	anel da purificacao
12997	escudo barbarruiva
12998	dragonas do magico
12999	embraces dracoflama
13000	cajado de hale flamagus
13001	aro da donzela
13002	pingente da lady elizebeth
13003	machado de batalha do lorde alexandre
13004	tocha de austen
13005	cobertor de amy
13006	marreta de herrera
13007	manto flamago
13008	calcas ventoval
13009	pelego do rei das vacas
13010	guarda pernas cantonirio
13011	cinto forrado de prata
13012	bracadeiras dos figueira
13013	dragonas do teurgo anciao
13014	machado de rin ji
13015	serathil
13016	mataleija
13017	machado de batalha infernocida
13018	cutelo do carrasco
13019	arco curto garrarpia
13020	arco atacaceu
13021	lancagulhas
13022	arco longo asa de grifo
13023	arco longo hastaguia
13024	esmagante de beazel
13025	marreta de lenha morta
13026	luz do paraiso
13027	quebraossos
13028	martelo sanguipetrus
13029	cristal do umbral
13030	osso de basilisco
13031	orbe brumanto
13032	espada da corrupcao
13033	lamina do zelote
13034	florete aco veloz
13035	fatia serpente
13036	lamina do assassinato
13037	aguilhante cristalpinus
13038	velozvento
13039	besta parte cranio
13040	besta cordicrava
13041	lamina guardia
13042	espada do magistrado
13043	lamina dos titas
13044	matademonios
13045	martelo viscoso
13046	dureza de blanchard
13047	rama da arvore do mundo
13048	martelete assomante
13049	espadao da reitoria
13051	bruxafuria
13052	fomentador da guerra
13053	arauto da ruina
13054	anjo da morte
13055	mascaosso
13056	golpeador frenetico
13057	piquessangue
13058	ponta de khraa
13059	petrocorvus
13060	o alfinetador
13062	pau de trovao
13063	derruba estrelas
13064	incendiario de jaina
13065	varinha de allistarj
13066	espaldares do mata serpe
13067	armadura hidraliska
13068	grevas obsidianas
13070	botas de escama de sapphiron
13071	punho de placas de hakhan
13072	manoplas pegapetrea
13073	elmo de mugthol
13074	perneiras do estilhaco de golem
13075	guarda pernas cruelasa
13076	bracadeiras do mata gigantes
13077	cinturao de uther
13079	escudo de turgo
13080	ninho da viuva
13081	escudo craniolanca
13082	broquel montes
13083	brasao da familia garreta
13084	corrente caleidoscopica
13085	gargantilha do horizonte
13086	redeas do sabre de gelo de hibernia
13087	gargantilha do rio altivo
13088	patua do gasganete
13089	pingente de skibi
13090	peitoral dos escolhidos
13091	medalhao do grao marechal morres
13093	anel brasa viva
13094	a joia da rainha
13095	anel de assalto
13096	anel do hierofante
13097	anel frontrovao
13098	elo tecemagoa
13099	mocassins da lebre branca
13100	botas do furen
13101	sapatos lupivelos
13102	enfeite de cassandra
13103	espaldares da aranha peconhenta
13105	anel de sutarn
13106	braceletes faiscantes magicos
13107	manilhas magicranicas
13108	dragonas tigrataque
13109	capa neroflama
13110	arnes lupifobo
13111	sandalias do insurgente
13112	elmo alado
13113	adorno plumaluna
13114	perneiras da perdicao do troll
13115	dragonas tosavelo
13116	espaldares do oculto
13117	faixa de ogron
13118	faixa serpentina
13119	bracadeiras encantadas do kodo
13120	bracadeiras fundafuria
13121	asa do dragonetinho
13122	capa do fantasma obscuro
13123	armadura andassonho
13124	botas de escama de ravassauro
13125	botas elficas encadeadas
13126	manoplas do anunciador de batalhas
13127	coroa friarrasa
13128	elmo do grao bergg
13129	perneiras flamigrenha
13130	guarda pernas de correventos
13131	dragonas quelobrilho
13132	omoplatas esqueleticas
13133	palas dracoflama
13134	cinto do gladiador
13135	guarda bracos senhoriais
13136	cospe fogo do toninho
13137	tramaferrea
13138	o silenciador
13139	furatripa
13140	chave vermelho sangue
13141	dente de gnarr
13142	cinturao de brigam
13143	marca do senhor dos dragoes
13144	cinto da serenidade
13145	cinto enorme do ogro
13146	espingarda cospe bala
13148	cravija
13149	tomo eldarathiano de evocacao vol 1
13151	os estudos misticos de hor ank
13152	a historia sem conclusao
13153	tomo de mal cin vorail
13154	estudos de jael marin sobre o arcano
13155	cranio ressonante
13156	cristal mistico
13157	cranio fetido
13158	palavras do chefe supremo
13159	farinha de osso
13161	cajado do refugio
13162	garras do gatuno
13163	foice implacavel
13164	coracao da escama
13166	omoplatas do embate
13167	punho de omokk
13168	peitoral do rei xama
13169	perneiras crinalonga
13170	perneiras do manto celeste
13171	isqueiro do fumaca
13172	tabaco da lata do carranca
13173	machado de arremesso fialado
13174	amostra de carne infectada
13175	arco retorcido de voone
13176	dados do flagelo
13177	talisma da evasao
13178	circulo vermelho vinho
13179	guarda bracos de cernecupreo
13180	agua benta de stratholme
13181	luvas de pele de demonio
13182	lamina fase
13183	cospeconha
13184	guantes de lagrimas
13185	dragonas do fendevidente
13186	garrafa do campo pedravil vazia
13187	garrafa para lagrimas de dalson vazia
13188	garrafa para antro repelente vazia
13189	garrafa da aridez de garrao vazia
13190	garrafa do campo pedravil cheia
13191	garrafa para lagrimas de dalson cheia
13192	garrafa para antro repelente cheia
13193	garrafa da aridez de garrao cheia
13194	chave do caldeirao do campo pedravil
13195	chave do caldeirao das lagrimas de dalson
13196	chave do caldeirao da aridez de garrao
13197	chave do caldeirao do antro repelente
13198	tequebro
13199	braceletes massacrista
13202	anais estendidos da vila das flechas
13203	manto da vigilia
13204	clavabam
13205	protetor rumbarbo
13206	perneiras de pelo de lobo
13207	cabeca do lorde das sombras fel dan
13208	guarda bracos do uivo arrepiante
13209	selo da aurora
13210	ombreiras do lobo pavoroso
13211	bracadeiras garracortante
13212	enforcador do halycon
13213	olho de queimateia
13216	coroa do penitente
13217	anel do penitente
13218	presa da aranha de cristal
13223	bolsa do mensageiro de stratholme
13243	defensor argenteo
13244	manoplas douradas
13245	casco do cresh
13246	vingadora argentea
13247	bau do intendente zigris
13248	arcabuz escopeta
13249	cruzado argenteo
13250	cabeca do balnazzar
13251	cabeca do barao rivendare
13252	cinturao do correnuvens
13253	maos do poder
13254	guarda astral
13255	manoplas miracerta
13257	espaldares com runas demoniacas
13258	manoplas de courescoria
13259	guarda pes de ripaco
13260	botas do dancarino dos ventos
13261	globo de d sak
13262	a crematoria
13282	botas do vigia da torre ogra
13283	anel do mago
13284	botas de batalha dardejantes
13285	o fatiador de rocha negra
13286	puatrifida
13287	molde arnes de pelego de raptor
13288	molde cinto de pelego de raptor
13289	canhao de ectoplasma do egan
13302	chave da caixa postal da travessa do comercio
13303	chave da caixa postal da praca dos cruzados
13304	chave da caixa postal da alameda do festival
13305	chave da caixa postal da praca dos anciaos
13306	chave da caixa postal da praca do rei
13307	chave da caixa postal de ezra carranca
13308	diagrama defletor de gelo
13309	diagrama cano de atirar feito com carinho
13310	diagrama mira de precisao
13311	diagrama dragonete mecanico
13313	escritos sagrados dos altaneiros
13314	abraco de aline
13317	apito do raptor marfim
13320	acelerador arcano
13321	mecanostruz verde
13322	mecanostruz sem pintura
13323	mecanostruz roxo
13324	mecanostruz vermelho e azul
13325	mecanostruz verde fluorescente
13326	mecanostruz branco modelo a
13327	mecanostruz azul gelo modelo a
13328	carneiro preto
13329	carneiro do gelo
13330	saco de rabanetes do derek
13331	cavalo descarnado vermelho
13332	cavalo descarnado azul
13333	cavalo descarnado castanho
13334	cavalo de guerra descarnado verde
13335	redeas do corcel da morte
13340	capa do barao negro
13342	peixe de estimacao
13343	pedra de estimacao
13344	manoplas dracorias
13345	marca de rivendare
13346	vestes dos exaltados
13347	cristal de zin malor
13348	gumedonho
13349	cetro do profano
13350	insignia da guarda negra
13351	avental do forjador de martelos carmesim
13352	litofidia de vosh gajin
13353	livro dos mortos
13354	ressonador ectoplasmico
13356	intensificador somatico
13357	agitador osseo
13358	omoplatas lingua de serpe
13359	coroa da tirania
13360	dadiva dos magos elficos
13361	aniquilador forjacranio
13362	carta do front de batalha
13363	decreto municipal
13364	anuncio de ezra carranca
13365	aviso de reuniao da cidade
13366	brinquedo engenhoso
13367	presente embrulhado
13368	raspa ossos
13369	botas de fogo
13370	focador vitreo
13371	chama paternal
13372	cajado do feitor
13373	anel de carne
13374	dragonas roubalmas
13375	escudo da retribuicao
13376	manto do tribunal real
13377	minibalas de canhao
13378	blusa ornicanto
13379	flautim do fogo flamejante
13380	obus portatil do gualter
13381	botas do mestre canhoneiro
13382	fura bloqueio
13383	tanga do menestrel saracoteante
13384	cinturao do arco iris
13385	tomo de conhecimento
13386	capa do arquivista
13387	cinturao da antecipacao
13388	a tunica do chefe do correio
13389	as calcas do chefe do correio
13390	a bandana do chefe do correio
13391	as botinas do chefe do correio
13392	o selo do chefe do correio
13393	marretao do malone
13394	abraco frio de kranio
13395	garras de osso de kranio
13396	toque horrendo de kranio
13397	capa de gargula litopele
13398	botas do guinchador
13399	gadanhos rasgargula
13400	avambracos do sadico
13401	a mao cruel de tico
13402	galochas do timmy
13403	laco da violencia
13404	mascara do imperdoavel
13405	brafoneiras do nocturno uivante
13408	quebra alma
13409	bracadeiras lacrimais
13422	enguia petrescama
13423	oleo de petrescama
13442	pocao potente de raiva
13443	pocao superior de mana
13444	pocao elevada de mana
13445	elixir de defesa superior
13446	pocao elevada de cura
13447	elixir dos sabios
13448	a escritura de castro das flechas
13450	a escritura de costa sul
13451	a escritura da serraria tarren
13452	elixir do mangusto
13453	elixir da forca bruta
13454	elixir arcano maior
13455	pocao maior de escudopetreo
13456	pocao maior de protecao contra o gelo
13457	pocao maior de protecao contra o fogo
13458	pocao maior de protecao contra a natureza
13459	pocao maior de protecao contra a sombra
13460	pocao maior de protecao contra o sagrado
13461	pocao maior de protecao contra o arcano
13462	pocao de purificacao
13463	folha de sonho
13464	sonsona dourada
13465	salvia prata da montanha
13466	pragonia
13467	chapeu de gelo
13468	lotus preto
13469	cabeca de weldon barov
13470	cabeca de alexi barov
13471	a escritura de montalvo
13473	pingente da sorte pedravil
13474	espingarda do fazendeiro dalson
13475	anel de casamento da familia dalson
13476	receita pocao potente de raiva
13477	receita pocao superior de mana
13478	receita elixir de defesa superior
13479	receita elixir dos sabios
13480	receita pocao elevada de cura
13481	receita elixir da forca bruta
13482	receita transmutar ar em fogo
13483	receita transmutar fogo em terra
13484	receita transmutar terra em agua
13485	receita transmutar agua em ar
13486	receita transmutar morte viva em agua
13487	receita transmutar agua em morte viva
13488	receita transmutar vida em terra
13489	receita transmutar terra em vida
13490	receita pocao de escudopetreo maior
13491	receita elixir do mangusto
13492	receita pocao de purificacao
13493	receita elixir arcano maior
13494	receita pocao maior de protecao contra o fogo
13495	receita pocao maior de protecao contra o gelo
13496	receita pocao maior de protecao contra a natureza
13497	receita pocao maior de protecao contra o arcano
13498	perneiras artesanais do mestre ferreiro
13499	receita pocao maior de protecao contra a sombra
13500	receita pocao maior de protecao contra o sagrado
13501	receita pocao elevada de mana
13502	cinturao artesanal do mestre ferreiro
13503	pedra dos alquimistas
13505	lamina runica do barao rivendare
13506	frasco de petrificacao
13507	relatorio de vigia do rochedo chifre longo
13508	olho de aracnida
13509	amarra da antecipacao
13510	frasco dos titas
13511	frasco de sabedoria destilada
13512	frasco de poder supremo
13513	frasco de resistencia cromatica
13514	uivo da banshee
13515	parafusos eletrificados de ramstein
13517	receita pedra dos alquimistas
13518	receita frasco de petrificacao
13519	receita frasco dos titas
13520	receita frasco de sabedoria destilada
13521	receita frasco de poder supremo
13522	receita frasco de resistencia cromatica
13523	sangue dos inocentes
13524	cranio das sombras incandescentes
13525	dedos da conexao malevola
13526	cinturao marcado de fogo
13527	grevas do andarilho da lava
13528	bracadeiras do vacuo do crepusculo
13529	carcaca de nerub enkan
13530	pisantes das presas pingantes
13531	perneiras do espreitador da cripta
13532	garras de tecer escuridao
13533	brafoneiras gravadas com acido
13534	dedo de banshee
13535	vestes fantasmagoricas do toque gelido
13536	corneta do despertar
13537	bracadeiras couralgidas
13538	brafoneiras guinchavento
13539	toque da banshee
13542	caixa demoniaca
13544	essencia espectral
13545	lagostim
13546	peixe panca sangrenta
13562	restos mortais de trey forjaleve
13582	correia do zergnideo
13583	coleira do panda
13584	pedra do diablo
13585	livro de recordacoes
13602	pedra magica maior
13603	pedra magica elevada
13624	lembranca vinculada
13626	cabeca humana de ras friomurmuro
13699	pedra de fogo
13700	pedra de fogo maior
13701	pedra de fogo elevada
13702	erva do demo
13703	osso de kodo
13704	chave mestra
13724	biscoito de mana enriquecido
13725	saco de horrores de krastinov
13752	lembranca vinculada
13754	parrudo lustroso cru
13755	lula invernal
13756	perca verao crua
13757	enguia eletrica
13758	vermelhao cru
13759	pargo pinoturno cru
13760	salmao helioscamo cru
13761	ovos congelados
13810	frutassol abencoada
13811	colar da aurora
13812	anel da aurora
13813	suco de frutassol abencoada
13815	essa tal runa
13816	espada longa de qualidade
13817	montante afilada
13818	machado entalhado
13819	machado de guerra equilibrado
13820	maca de pancada
13821	malho avantajado
13822	adaga com pontas
13823	cajado de guerra resoluto
13824	arco longo recurvo
13825	mosquete carregado
13842	manha de outono inverno
13843	tarde de outono inverno
13844	fim da tarde de outono inverno
13845	noite de outono inverno
13846	manha primavera verao
13847	tarde primavera verao
13848	fim da tarde primavera verao
13849	noite primavera verao
13850	municao do estremetiro
13851	costelinhas picantes de lobo
13852	ordens do grao cruzado
13853	naco de carne de verme carniceiro
13856	cinto de runatrama
13857	tunica de runatrama
13858	veste de runatrama
13860	manto de runatrama
13863	luvas de runatrama
13864	botas de runatrama
13865	calcas de runatrama
13866	bandana de runatrama
13867	omoplatas de runatrama
13868	veste de friotrama
13869	tunica de friotrama
13870	luvas de friotrama
13871	calcas de friotrama
13872	feixe de lenha
13873	chave da sala de exibicao
13874	caixote pesado
13875	bau lacrado com ferro
13876	garoupa de 20 quilos
13877	garoupa de 23 quilos
13878	garoupa de 26 quilos
13879	garoupa de 29 quilos
13880	garoupa de 34 quilos
13881	vermelhao inchado
13882	vermelhao de 21 quilos
13883	vermelhao de 23 quilos
13884	vermelhao de 24 quilos
13885	vermelhao de 17 quilos
13886	vermelhao de 18 quilos
13887	vermelhao de 26 quilos
13888	lagosta pincanegra
13889	salmao escama branca cru
13890	peixe armadura de placas
13891	salmao inchado
13892	kodoagrupandador
13893	grande parrudo cru
13895	dangui formal
13896	hanbok verde escuro de casamento
13897	hanbok tradicional branco
13898	dangui real
13899	hanbok tradicional vermelho
13900	hanbok verde de casamento
13901	salmao de 7 quilos
13902	salmao de 9 quilos
13903	salmao de 11 quilos
13904	salmao de 13 quilos
13905	salmao de 15 quilos
13906	salmao de 16 quilos
13907	lagosta de 3 quilos
13908	lagosta de 4 quilos
13909	lagosta de 6 quilos
13910	lagosta de 7 quilos
13911	lagosta de 9 quilos
13912	lagosta de 10 quilos
13913	lagosta de 11 quilos
13914	parrudo de 35 quilos
13915	parrudo de 43 quilos
13916	parrudo de 46 quilos
13917	parrudo de 51 quilos
13918	bau resistente trancado
13920	escama de dragao saudavel
13926	perola dourada
13927	parrudo lustroso cozido
13928	lula grelhada
13929	robalo defumado picante
13930	file de vermelhao
13931	sopa de pinoturno
13932	salmao helioscamo poche
13933	ensopado de lagosta
13934	file de parrudo
13935	salmao assado
13937	dever do diretor
13938	calamo de rastejossos
13939	receita rabo amarelo mosqueado
13940	receita parrudo lustroso cozido
13941	receita file de vermelhao
13942	receita lula grelhada
13943	receita robalo defumado picante
13944	peitoral da lapide
13945	receita sopa de pinoturno
13946	receita salmao helioscamo poche
13947	receita ensopado de lagosta
13948	receita file de parrudo
13949	receita salmao assado
13950	cinta de detencao
13951	avambracos de acoforte
13952	decepador gelamina
13953	presa silente
13954	pisantes verdejantes
13955	omoplatas feitas de pedra
13956	amarra de andros
13957	corta gargulas
13958	grilhoes de wyrmthalak
13959	cilha do omokk
13960	coracao do demonio
13961	focinheira do halycon
13962	cordao de vosh gajin
13963	manoplas imorais de voone
13964	bruxilamina
13965	amplitude do mao negra
13966	marca da tirania
13967	grevas assolaventos
13968	olho da fera
13969	braceleiras guarda vulto
13982	lamina de guerra de castro das flechas
13983	machado de guerra da lapide
13984	flechespeto
13986	coroa do castro das flechas
14002	guardaforte da vila das flechas
14022	convocador de servicais de barov
14023	convocador de servicais de barov
14024	gadanhorror
14025	cinto do mistico
14042	colete de brasatrama
14043	luvas de brasatrama
14044	manto de brasatrama
14045	calcas de brasatrama
14046	bolsa de runatrama
14047	runatrama
14048	peca de runatrama
14062	kodo de montaria
14083	cajado de tyrande
14086	sandalias enfeitadas
14087	manilhas enfeitadas
14088	manto enfeitado
14089	luvas enfeitadas
14090	culotes enfeitados
14091	veste enfeitada
14093	cordao enfeitado
14094	colete enfeitado
14095	embraces nativos
14096	colete nativo
14097	calcas nativas
14098	manto nativo
14099	faixa nativa
14100	veste de lumetrama
14101	luvas de lumetrama
14102	mitenes nativas
14103	manto de lumetrama
14104	calcas de lumetrama
14106	veste de tecido vil
14107	calcas de tecido vil
14108	botas de tecido vil
14109	veste nativa
14110	sandalias nativas
14111	capuz de tecido vil
14112	omoplatas de tecido vil
14113	faixa aborigene
14114	palmilhas aborigenes
14115	embraces aborigenes
14116	capa aborigene
14117	luvas aborigenes
14119	tanga aborigene
14120	veste aborigene
14121	colete aborigene
14122	embraces ritualistas
14123	capa ritual
14124	luvas rituais
14125	perneiras rituais
14126	sobreveste ritual
14127	mortalha ritual
14128	veste de bruxatrama
14129	sandalias rituais
14130	turbante de bruxatrama
14131	cinto ritual
14132	perneiras de bruxatrama
14133	tunica ritual
14134	manto de fogo
14136	veste da noite de inverno
14137	perneiras de lunatrama
14138	colete de lunatrama
14139	omoplatas de lunatrama
14140	diadema de lunatrama
14141	colete de espectrama
14142	luvas de espectrama
14143	cinto de espectrama
14144	calcas de espectrama
14145	lamina vil amaldicoada
14146	luvas de maestria em feiticaria
14147	bracadeiras cavernicolas
14148	manilhas cristalinas
14149	capa subterranea
14150	veste de evocacao
14151	lamina cantante
14152	veste do arquimago
14153	veste do caos
14154	vestimenta da fe verdadeira
14155	bolsa de lunatrama
14156	bolsa sem fundo
14157	dragonas pagas
14158	colete pagao
14159	sapatos pagaos
14160	embraces pagaos
14161	capa paga
14162	luvas pagas
14163	veste paga
14164	cinto pagao
14165	culotes pagaos
14166	bracadeiras do bucaneiro
14167	capa do bucaneiro
14168	luvas do bucaneiro
14169	ombreiras aborigenes
14170	dragonas do bucaneiro
14171	calcas do bucaneiro
14172	vestes do bucaneiro
14173	cordao do bucaneiro
14174	botas do bucaneiro
14175	colete do bucaneiro
14176	botas do vigia
14177	manilhas do vigia
14178	chapeu pontudo do vigia
14179	capa do vigia
14180	gibao do vigia
14181	mitenes do vigia
14182	dragonas do vigia
14183	perneiras do vigia
14184	vestes do vigia
14185	cinturao do vigia
14186	dragonas clamachuva
14187	manilhas clamachuva
14188	manto clamachuva
14189	capuz clamachuva
14190	colete clamachuva
14191	luvas clamachuva
14192	vestes clamachuva
14193	calcas clamachuva
14194	cordao clamachuva
14195	botas clamachuva
14196	sandalias pelocardo
14197	embraces pelocardo
14198	manto pelocardo
14199	luvas pelocardo
14200	capuz pelocardo
14201	dragonas pelocardo
14202	gibao pelocardo
14203	calcas pelocardo
14204	veste pelocardo
14205	cinto pelocardo
14206	braceletes vitais
14207	perneiras vitais
14208	bandana vital
14209	faixa vital
14210	capa vital
14211	mitenes vitais
14212	omoplatas vitais
14213	traje vital
14214	botas vitais
14215	tunica vital
14216	gibao do geomante
14217	cordao do geomante
14218	botas do geomante
14219	manto do geomante
14220	bandana do geomante
14221	bracadeiras do geomante
14222	luvas do geomante
14223	espaldares do geomante
14224	calcas do geomante
14225	veste do geomante
14226	braceletes de seribrasa
14227	seda de aranha ferroteia
14228	bandana de seribrasa
14229	manto de seribrasa
14230	tunica de seribrasa
14231	luvas de seribrasa
14232	dragonas de seribrasa
14233	perneiras de seribrasa
14234	vestes de seribrasa
14235	cordao de seribrasa
14236	botas de seribrasa
14237	armadura nevoa negra
14238	botas nevoa negra
14239	capa nevoa negra
14240	embraces nevoa negra
14241	protetores de mao nevoa negra
14242	calcas nevoa negra
14243	dragonas nevoa negra
14244	veste nevoa negra
14245	cinturao nevoa negra
14246	chapeu de teurgo nevoa negra
14247	dragonas lunares
14248	braceletes lunares
14249	colete lunar
14250	sapatilhas lunares
14251	manto lunar
14252	diadema lunar
14253	mitenes lunares
14254	traje lunar
14255	cinto lunar
14256	tecido vil
14257	perneiras lunares
14258	cordao tecido em sangue
14259	botas tecidas em sangue
14260	bracadeiras tecidas em sangue
14261	manto tecido em sangue
14262	luvas tecidas em sangue
14263	mascara tecida em sangue
14264	calcas tecidas em sangue
14265	veste tecida em sangue
14266	ombreiras tecidas em sangue
14267	gibao tecido em sangue
14268	manilhas de gaia
14269	sapatilhas de gaia
14270	manto de gaia
14271	diadema de gaia
14272	mitenes de gaia
14273	sobreveste de gaia
14274	perneiras de gaia
14275	traje de gaia
14276	cinto de gaia
14277	tunica de gaia
14278	dragonas opulentas
14279	braceleiras opulentas
14280	capa opulenta
14281	coroa opulenta
14282	luvas opulentas
14283	perneiras opulentas
14284	vestes opulentas
14285	botas opulentas
14286	cinto opulento
14287	tunica opulenta
14288	armadura aracnoide
14289	cinturao aracnoide
14290	pisantes aracnoides
14291	braceletes aracnoides
14292	capa aracnoide
14293	diadema aracnoide
14294	luvas aracnoides
14295	guarda pernas aracnoides
14296	brafoneiras aracnoides
14297	vestes aracnoides
14298	espaldares do osteurgo
14299	botas do osteurgo
14300	capa do osteurgo
14301	braceletes do osteurgo
14302	luvas do osteurgo
14303	mortalha do osteurgo
14304	cinto do osteurgo
14305	sarongue do osteurgo
14306	colete do osteurgo
14307	coroa do osteurgo
14308	tunica celestial
14309	cinto celestial
14310	sapatilhas celestiais
14311	bracadeiras celestiais
14312	coroa celestial
14313	capa celestial
14314	mitenes celestiais
14315	kilt celestial
14316	brafoneiras celestiais
14317	vestes de seda celestiais
14318	tunica resplandecente
14319	botas resplandecentes
14320	braceletes resplandecentes
14321	manto resplandecente
14322	diadema resplandecente
14323	manoplas resplandecentes
14324	sarongue resplandecente
14325	palas resplandecentes
14326	vestes resplandecentes
14327	cinto resplandecente
14328	couraca eterna
14329	botas eternas
14330	bracadeiras eternas
14331	manto eterno
14332	coroa eterna
14333	luvas eternas
14334	sarongue eterno
14335	espaldares eternos
14336	veste eterna
14337	cordao eterno
14338	tubo de agua vazio
14339	tubo de agua do poco lunar
14340	vestes gelidas de lich
14341	fio runico
14342	lunatrama
14343	estilhaco brilhante pequeno
14344	estilhaco brilhante grande
14364	sapatilhas do mistico
14365	capa do mistico
14366	braceletes do mistico
14367	luvas do mistico
14368	ombreiras do mistico
14369	colete do mistico
14370	bermuda do mistico
14371	veste do mistico
14372	armadura sanguinea
14373	cinto sanguineo
14374	sandalias sanguineas
14375	manilhas sanguineas
14376	capa sanguinea
14377	mitenes sanguineas
14378	dragonas sanguineas
14379	calcas sanguineas
14380	veste sanguinea
14381	algibeira do temivel totem
14382	peito d armas da durabilidade
14383	bracadeiras da durabilidade
14384	botas da durabilidade
14385	manto da durabilidade
14386	chapeu da durabilidade
14387	luvas da durabilidade
14388	perneiras da durabilidade
14389	ombreiras da durabilidade
14390	cinto da durabilidade
14391	espada da durabilidade
14392	cajado da durabilidade
14393	escudo da durabilidade
14394	arco da durabilidade
14395	feiticos da sombra
14396	encantamentos do eter
14397	dragonas resilientes
14398	tunica resiliente
14399	botas resilientes
14400	capa resiliente
14401	capuz resiliente
14402	embraces resilientes
14403	guantes resilientes
14404	perneiras resilientes
14405	veste resiliente
14406	cordao resiliente
14407	colete de panopetreo
14408	botas de panopetreo
14409	capa de panopetreo
14410	bandana de panopetreo
14411	luvas de panopetreo
14412	palas de panopetreo
14413	veste de panopetreo
14414	cinto de panopetreo
14415	culotes de panopetreo
14416	bracadeiras de panopetreo
14417	tunica sedareia
14418	botas sedareia
14419	bracadeiras sedareia
14420	capa sedareia
14421	bandana sedareia
14422	luvas sedareia
14423	ombreiras de sedareia
14424	culotes sedareia
14425	veste sedareia
14426	cinturao sedareia
14427	colete seguevento
14428	pisantes seguevento
14429	manilhas seguevento
14430	manto seguevento
14431	protetores de mao seguevento
14432	sobreveste seguevento
14433	calcas seguevento
14434	vestes seguevento
14435	cilha seguevento
14436	diadema seguevento
14437	colete venomortalha
14438	botas venomortalha
14439	guarda bracos venomortalha
14440	capa venomortalha
14441	mascara venomortalha
14442	luvas venomortalha
14443	dragonas venomortalha
14444	perneiras venomortalha
14445	vestes de seda venomortalha
14446	cinto venomortalha
14447	pisantes altaneiros
14448	braceletes altaneiros
14449	coroa altaneira
14450	manto altaneiro
14451	luvas altaneiras
14452	brafoneiras altaneiras
14453	vestes altaneiras
14454	cordao dos altaneiros
14455	armadura acolchoada altaneira
14456	colete elunario
14457	manilhas elunarias
14458	botas elunarias
14459	manto elunario
14460	diadema elunario
14461	guantes elunarios
14462	sarongue elunario
14463	espaldares elunarios
14464	vestes elunarias de seda
14465	cinto elunario
14466	molde tunica de friotrama
14467	molde veste de friotrama
14468	molde bolsa de runatrama
14469	molde veste de runatrama
14470	molde tunica de runatrama
14471	molde colete de brasatrama
14472	molde manto de runatrama
14473	molde cinto de espectrama
14474	molde luvas de friotrama
14476	molde luvas de brasatrama
14477	molde luvas de espectrama
14478	molde veste de lumetrama
14479	molde luvas de lumetrama
14480	molde colete de espectrama
14481	molde luvas de runatrama
14482	molde manto de brasatrama
14483	molde calcas de tecido vil
14484	molde manto de lumetrama
14485	molde perneiras de bruxatrama
14486	molde manto de fogo
14487	martelo friosso
14488	molde botas de runatrama
14489	molde calcas de friotrama
14490	molde calcas de brasatrama
14491	molde calcas de runatrama
14492	molde botas de tecido vil
14493	molde veste da noite de inverno
14494	molde calcas de lumetrama
14495	molde calcas de espectrama
14496	molde capuz de tecido vil
14497	molde perneiras de lunatrama
14498	molde bandana de runatrama
14499	molde bolsa de lunatrama
14500	molde veste de bruxatrama
14501	molde colete de lunatrama
14502	cinturao mandibulas de gelo
14503	garras da morte
14504	molde omoplatas de runatrama
14505	molde turbante de bruxatrama
14506	molde veste de tecido vil
14507	molde omoplatas de lunatrama
14508	molde omoplatas de tecido vil
14509	molde diadema de lunatrama
14510	molde bolsa sem fundo
14511	molde luvas de maestria em feiticaria
14512	molde vestimenta da fe verdadeira
14513	molde veste do arquimago
14514	molde veste do caos
14522	perneiras da voragem
14523	picareta do diabo
14525	manoplas ossapertos
14526	molde lunatrama
14528	broquel range ossos
14529	bandagem de runatrama
14530	bandagem grossa de runatrama
14531	cajado atacaveira
14536	cota ossabracos
14537	grevas cadaverinas
14538	manto do necrambulo
14539	elmo de elo osseo
14540	coracao de taragaman o famelico
14541	espada da familia barov
14542	caixote de kravel
14543	luvas nerumbra
14544	insignia do tenente
14545	perneiras vultear
14546	chifre de kodo de roon
14547	mao da iruxos
14548	espaldares regios
14549	botas de evasao
14550	guarda bracos laminazar
14551	protetores de mao do mestre laminar
14552	brafoneiras do carcere
14553	faixa da misericordia
14554	coxotes do guardiao nebuloso
14555	navalha solar de alcor
14557	trombeta leonina de ventobravo
14558	pingente da lady maye
14559	faixa do prospector
14560	botas do prospector
14561	manilhas do prospector
14562	peito d armas do prospector
14563	manto do prospector
14564	luvas do prospector
14565	bermuda do prospector
14566	ombreiras do prospector
14567	cinto felpado
14568	botas felpadas
14569	braceletes felpados
14570	camisa felpada
14571	capa felpada
14572	luvas felpadas
14573	sobreveste felpada
14574	culotes felpados
14576	cabo de ebano de marduque
14577	calcas cranio fumegante
14578	cordao dokebi
14579	botas dokebi
14580	bracadeiras dokebi
14581	couraca dokebi
14582	capa dokebi
14583	luvas dokebi
14584	chapeu dokebi
14585	perneiras dokebi
14587	dragonas dokebi
14588	cordao olho de falcao
14589	sapatos olho de falcao
14590	bracadeira olho de falcao
14591	elmo olho de falcao
14592	tunica olho de falcao
14593	manto olho de falcao
14594	luvas olho de falcao
14595	calcoes olho de falcao
14596	palas olho de falcao
14598	cintel do vigilante
14599	pisantes do vigilante
14600	munhequeiras do vigilante
14601	colete do vigilante
14602	manto do vigilante
14603	dragonas do vigilante
14604	casquete do vigilante
14605	bermuda do vigilante
14606	luvas do vigilante
14607	broquel olho de falcao
14608	broquel dokebi
14610	escaravelho de araj
14611	cota de malha sangrenta
14612	guarda pernas de malha sangrenta
14613	martelo de taelan
14614	cinto de malha sangrenta
14615	manoplas de malha sangrenta
14616	botas de malha sangrenta
14617	camisa do amputador
14619	fragmentos de ossos
14620	cinturao ossomorte
14621	escarpes ossomorte
14622	manoplas ossomorte
14623	guarda pernas ossomorte
14624	guarda peito ossomorte
14625	simbolo da honra perdida
14626	veste necropila
14627	molde camisa amarela berrante
14628	fragmentos de ossos imbuidos
14629	braceletes necropilos
14630	molde capucho do encantador
14631	botas necropilas
14632	perneiras necropilas
14633	dragonas necropilas
14634	receita oleo gelido
14635	molde cinto de couro rematado de gemas
14636	cinto cadaverico
14637	armadura cadaverica
14638	perneiras cadavericas
14639	diagrama rebotocador menor
14640	luvas cadavericas
14641	chancas cadavericas
14644	molde de chave mestra
14645	chave mestra inacabada
14646	vale brinde de vila norte
14647	vale brinde do vale cristalgida
14648	vale brinde de umbravale
14649	vale brinde do vale das provacoes
14650	vale brinde da aldeia narache
14651	vale brinde de plangemortis
14652	faixa scorpashi
14653	sapatilhas scorpashi
14654	munhequeiras scorpashi
14655	peitoral scorpashi
14656	capa scorpashi
14657	luvas scorpashi
14658	casquete scorpashi
14659	perneiras scorpashi
14660	espaldares scorpashi
14661	cordao do guardiao
14662	cascos do guardiao
14663	braceletes do guardiao
14664	armadura do guardiao
14665	manto do guardiao
14666	luvas do guardiao
14667	capacete do guardiao
14668	bermuda do guardiao
14669	dragonas do guardiao
14670	armadura soberba
14671	botas soberbas
14672	embraces soberbos
14673	capa soberba
14674	cinturao soberbo
14675	luvas soberbas
14676	halo soberbo
14677	calcas soberbas
14678	brafoneiras soberbas
14679	do amor e da familia
14680	colete indomavel
14681	botas indomaveis
14682	guarda bracos indomaveis
14683	manto indomavel
14684	cinto indomavel
14685	manoplas indomaveis
14686	capacete indomavel
14687	perneiras indomaveis
14688	palas indomaveis
14722	tornozeleiras pintadas para a guerra
14723	bracadeiras de pintura de guerra
14724	manto de pintura de guerra
14725	cintel de pintura de guerra
14726	luvas de pintura de guerra
14727	guarda pernas de pintura de guerra
14728	ombreiras de pintura de guerra
14729	escudo de pintura de guerra
14730	peito d armas de pintura de guerra
14742	botas grandiosas
14743	embraces grandiosos
14744	couraca grandiosa
14745	manto grandioso
14746	cinto grandioso
14747	manoplas grandiosas
14748	perneiras grandiosas
14749	espaldares grandiosos
14750	manilhas do matador
14751	peitoral do matador
14752	capa do matador
14753	casquete do matador
14754	luvas do matador
14755	faixa do matador
14756	sapatilhas do matador
14757	calcas do matador
14758	ombreiras do matador
14759	bracadeiras resistentes
14760	peitoral resistente
14761	cinto resistente
14762	botas resistentes
14763	capa resistente
14764	manoplas resistentes
14765	diadema resistente
14766	calcoes resistentes
14767	brafoneiras resistentes
14768	armadura do assolador
14769	sandalias do assolador
14770	guarda bracos do assolador
14771	manto do assolador
14772	mitenes do assolador
14773	cordao do assolador
14774	coroa do assolador
14775	bermuda do assolador
14776	dragonas do assolador
14777	escudo do assolador
14778	braceletes do khan
14779	peito d armas do khan
14780	broquel do khan
14781	manto do khan
14782	luvas do khan
14783	cinto do khan
14784	grevas do khan
14785	capacete do khan
14786	guarda pernas do khan
14787	dragonas do khan
14788	guarda bracos protetores
14789	peitoral protetor
14790	broquel protetor
14791	capa protetora
14792	manoplas protetoras
14793	cintel protetor
14794	tornozeleiras protetoras
14795	elmo protetor
14796	guarda pernas protetores
14797	ombreiras protetoras
14798	peitoral sede de sangue
14799	botas sede de sangue
14800	broquel sede de sangue
14801	capa sede de sangue
14802	manoplas sede de sangue
14803	cinto sede de sangue
14804	elmo sede de sangue
14805	culotes sede de sangue
14806	palas sede de sangue
14807	braceletes sede de sangue
14808	cinto guerreador
14809	escarpes guerreadores
14810	pulseiras guerreadoras
14811	couraca guerreadora
14812	broquel guerreador
14813	capa guerreadora
14814	coifa guerreadora
14815	manoplas guerreadoras
14816	guarda pernas guerreadores
14817	ombreiras guerreadoras
14821	peitoral simbolico
14825	escudo simbolico
14826	manoplas simbolicas
14827	cinto simbolico
14828	grevas simbolicas
14829	coxotes simbolicos
14830	brafoneiras simbolicas
14831	coroa simbolica
14832	avambracos simbolicos
14833	manoplas do tirano
14834	guarda bracos do tirano
14835	peito d armas do tirano
14838	cinto do tirano
14839	grevas do tirano
14840	coxotes do tirano
14841	palas do tirano
14842	escudo do tirano
14843	elmo do tirano
14844	couraca de helioscamo
14846	manoplas de helioscamo
14847	cinto de helioscamo
14848	escarpes de helioscamo
14849	capacete de helioscamo
14850	coxotes de helioscamo
14851	espaldares de helioscamo
14852	escudo de helioscamo
14853	munhequeiras de helioscamo
14854	peitoral de vanguarda
14855	manoplas de vanguarda
14856	cinturao de vanguarda
14857	escarpes de vanguarda
14858	diadema de vanguarda
14859	coxotes de vanguarda
14860	brafoneiras de vanguarda
14861	avambracos de vanguarda
14862	peitoral do lider guerreiro
14863	manoplas do lider guerreiro
14864	cinto do lider guerreiro
14865	grevas do lider guerreiro
14866	coroa do lider guerreiro
14867	perneiras do lider guerreiro
14868	omoplatas do lider guerreiro
14869	bracadeiras do lider guerreiro
14872	dadiva de tirion
14894	raiz de lirio
14895	sobretudo sal gema
14896	escarpes sal gema
14897	manoplas sal gema
14898	cinturao sal gema
14899	elmo sal gema
14900	coxotes sal gema
14901	guarda ombros sal gema
14902	escudo sal gema
14903	pulseiras sal gema
14904	peitoral brutal
14905	manoplas brutais
14906	cinto brutal
14907	capacete brutal
14908	guarda pernas brutais
14909	omoplatas brutais
14910	guarda bracos brutais
14911	botas brutais
14912	escudo brutal
14913	grevas jade
14914	bracadeiras jade
14915	peitoral jade
14916	defletor jade
14917	manoplas jade
14918	cinto jade
14919	diadema jade
14920	coxotes jade
14921	palas jade
14922	escarpes soberbos
14923	guarda bracos soberbos
14924	peitoral soberbo
14925	elmo soberbo
14926	manoplas soberbas
14927	cinto soberbo
14928	guarda pernas soberbas
14929	guarda ombros soberbos
14930	escudo soberbo
14931	armadura heroica
14932	grevas heroicas
14933	manoplas heroicas
14934	cinturao heroico
14935	elmo heroico
14936	coxotes heroicos
14937	brafoneiras heroicas
14938	bracadeiras heroicas
14939	couraca do armipotente
14940	escarpes do armipotente
14941	pulseiras do armipotente
14942	manoplas do armipotente
14943	cinto do armipotente
14944	coroa do armipotente
14945	guarda pernas do armipotente
14946	espaldares do armipotente
14947	escudo do armipotente
14948	peito d armas forjado em sangue
14949	manoplas forjadas em sangue
14950	cinto forjado em sangue
14951	escarpes forjados em sangue
14952	capacete forjado em sangue
14953	coxotes forjados em sangue
14954	escudo forjado em sangue
14955	protecao de ombros forjada em sangue
14956	braceletes forjados em sangue
14957	escarpes do chefe supremo
14958	armadura do chefe supremo
14959	manoplas do chefe supremo
14960	cinto do chefe supremo
14961	coroa do chefe supremo
14962	guarda pernas do chefe supremo
14963	brafoneiras do chefe supremo
14964	escudo do chefe supremo
14965	bracadeiras do chefe supremo
14966	peitoral glorioso
14967	manoplas gloriosas
14968	cinto glorioso
14969	diadema glorioso
14970	coxotes gloriosos
14971	espaldares gloriosos
14972	escarpes gloriosos
14973	escudo glorioso
14974	braceletes gloriosos
14975	arnes exaltado
14976	manoplas exaltadas
14977	cinturao exaltado
14978	escarpes exaltados
14979	capacete exaltado
14980	coxotes exaltados
14981	palas exaltadas
14982	escudo exaltado
14983	pulseiras exaltadas
15002	pique de nimboya
15003	cinto primevo
15004	botas primevas
15005	embraces primevos
15006	broquel primevo
15007	capa primeva
15008	luvas primevas
15009	perneiras primevas
15010	veste primeva
15011	cordao lupino
15012	sapatilhas lupinas
15013	manilhas lupinas
15014	broquel lupino
15015	manto lupino
15016	mitenes lupinas
15017	perneiras lupinas
15018	colete lupino
15019	dragonas lupinas
15042	jarra de cupins vazia
15043	cupins das terras pestilentas
15044	barril de cupins das terras pestilentas
15045	peitoral de escama de dragao verde
15046	perneiras de escama de dragao verde
15047	peitoral de escama de dragao vermelho
15048	peitoral de escama de dragao azul
15049	omoplatas de escama de dragao azul
15050	peitoral de escama de dragao negro
15051	omoplatas de escama de dragao negro
15052	perneiras de escama de dragao negro
15053	peitoral vulcanico
15054	perneiras vulcanicas
15055	omoplatas vulcanicas
15056	armadura do veu da tempestade
15057	calcas do veu da tempestade
15058	omoplatas do veu da tempestade
15059	peitoral vivo
15060	perneiras vivas
15061	omoplatas vivas
15062	perneiras de demossauro
15063	manoplas de demossauro
15064	arnes de urso de guerra
15065	bermuda de urso de guerra
15066	peitoral de penaferrea
15067	omoplatas de penaferrea
15068	tunica sabre de gelo
15069	perneiras sabre de gelo
15070	luvas sabre de gelo
15071	botas sabre de gelo
15072	perneiras quimericas
15073	botas quimericas
15074	luvas quimericas
15075	colete quimerico
15076	colete escorpideo pesado
15077	bracadeiras escorpideas pesadas
15078	manopla escorpidea pesada
15079	perneiras escorpideas pesadas
15080	elmo escorpideo pesado
15081	omoplatas escorpideas pesadas
15082	cinto escorpideo pesado
15083	manoplas de couro malefico
15084	bracadeiras de couro malefico
15085	armadura de couro malefico
15086	bandana de couro malefico
15087	calcas de couro malefico
15088	cinto de couro malefico
15090	armadura de couro runico
15091	manoplas de couro runico
15092	bracadeiras de couro runico
15093	cinto de couro runico
15094	bandana de couro runico
15095	calcas de couro runico
15096	omoplatas de couro runico
15102	amostra de un goro testada
15103	amostra testada corrompida
15104	botas aleas
15105	cajado de noh orathil
15106	cajado de dar orathil
15107	orbe de nor orahil
15108	orbe de dar orathil
15109	cajado de soran ruk
15110	cinto rigido
15111	mocassins rigidos
15112	braceletes rigidos
15113	broquel rigido
15114	capa rigida
15115	luvas rigidas
15116	omoplatas rigidas
15117	perneiras rigidas
15118	tunica rigida
15119	calcas altaneiras
15120	cinturao robusto
15121	botas robustas
15122	bracadeiras robustas
15123	broquel robusto
15124	manto robusto
15125	luvas robustas
15126	perneiras robustas
15127	omoplatas robustas
15128	tunica robusta
15129	elmo robusto
15130	colete do degolador
15131	botas do degolador
15132	guarda bracos do degolador
15133	broquel do degolador
15134	capacete do degolador
15135	capa do degolador
15136	cinto do degolador
15137	luvas do degolador
15138	manto de escama da onyxia
15139	calcas do degolador
15140	dragonas do degolador
15141	peitoral de escama da onyxia
15142	botas do andarilho fantasma
15143	bracadeiras do andarilho fantasma
15144	trapos do andarilho fantasma
15145	broquel do andarilho fantasma
15146	coroa do andarilho fantasma
15147	manto do andarilho fantasma
15148	cinto do andarilho fantasma
15149	luvas do andarilho fantasma
15150	ombreiras do andarilho fantasma
15151	guarda pernas do andarilho fantasma
15152	sapatos noturnos
15153	manto noturno
15154	faixa noturna
15155	luvas noturnas
15156	chapeu noturno
15157	perneiras noturnas
15158	ombreiras noturnas
15159	tunica noturna
15160	munhequeiras noturnas
15161	cinto imponente
15162	botas imponentes
15163	bracadeiras imponentes
15164	colete imponente
15165	capa imponente
15166	luvas imponentes
15167	bandana imponente
15168	calcas imponentes
15169	omoplatas imponentes
15170	armadura potente
15171	botas potentes
15172	embraces potentes
15173	capa potente
15174	luvas potentes
15175	capacete potente
15176	calcas potentes
15177	omoplatas potentes
15178	cinto potente
15179	armadura acolchoada pretoriana
15180	cinturao pretoriano
15181	botas pretorianas
15182	munhequeiras pretorianas
15183	manto pretoriano
15184	luvas pretorianas
15185	coifa pretoriana
15186	perneiras pretorianas
15187	brafoneiras pretorianas
15188	guarda bracos vultosos
15189	botas vultosas
15190	manto vultoso
15191	cinto vultoso
15192	manoplas vultosas
15193	capacete vultoso
15194	guarda pernas vultosos
15195	peitoral vultoso
15196	tabardo do recruta
15197	tabardo do batedor
15198	cores do cavaleiro
15199	arauto do guarda petreo
15200	insignia do primeiro sargento
15202	perneiras do guardiao selvagem
15203	guarda pernas da rajada tempestiva
15204	varinha de pedra da lua
15205	rifle de visao de coruja
15206	bastao dedo de jade
15207	escudo folheaco
15208	poeira de lua cenariana
15209	saco de reliquias
15210	espada curta do saqueador
15211	espada curta militante
15212	espada larga do lutador
15213	lamina mercenaria
15214	espada dos nobres
15215	alfanje furioso
15216	espada runica
15217	lamina da viuva
15218	espada de cristal
15219	lamina dimensional
15220	sabre tombatalha
15221	espada da sagrada batalha
15222	maca espigada
15223	estrela entalhada
15224	esmagalutas
15225	martelo de sequoia
15226	clava gigante
15227	maca com pontas de diamante
15228	esmagamassa
15229	martelo ventobento
15230	cutelo arpado
15231	machadinha rachante
15232	cutelo decepante
15233	machado selvagem
15234	machado grandioso
15235	fio crescente
15236	cutelo da lua
15237	cata cadaver
15238	machado do senhor da guerra
15239	aniquilador pedravil
15240	garra do demonio
15241	faca de batalha
15242	estilete amolado
15243	cris mortal
15244	laminavalha
15245	adaga vorpal
15246	lamina do demonio
15247	adaga sangrataca
15248	espadao rebrilhante
15249	bihander polida
15250	flamberge luminoso
15251	espada atacabecas
15252	espada colmilha
15253	lamina decapitante
15254	espadao sombrio
15255	flamberge pomposa
15256	espada de massacre
15257	lamina shin
15258	lamina de guerra divina
15259	martelo de batalha robusto
15260	martelo de pedra
15261	galho de sequoia
15262	malho grandioso
15263	marreta real
15264	quebradorso
15265	traztormento
15266	malhador tenaz
15267	brutomalho
15268	machado de fio duplo
15269	machado de batalha macico
15270	machado de guerra gigante
15271	machado grande colossal
15272	barbeador de macho
15273	golpe da morte
15274	cajado longo do vidente
15275	cajado do taumaturgo
15276	cajado longo do mago
15277	kodo cinza
15278	cajado do solsticio
15279	varinha de marfim
15280	mao do teurgo
15281	bastao lumestela
15282	dedo de dragao
15283	varinha lunar
15284	arco longo de batalha
15285	arco longo do arqueiro
15286	arco longo de sequoia
15287	arco do cruzado
15288	arco estalaste
15289	arco arcataque
15290	kodo marrom
15291	agulhante da harpia
15292	kodo verde
15293	kodo ardosia
15294	arco de cerco
15295	arco calamigneo
15296	arco do olho de falcao
15297	bracadeiras pardas
15298	broquel pardo
15299	capa parda
15300	luvas pardas
15301	sapatilhas pardas
15302	cinto pardo
15303	calcas pardas
15304	gibao pardo
15305	sapatos ferais
15306	braceletes ferais
15307	broquel feral
15308	cordao feral
15309	manto feral
15310	luvas ferais
15311	arnes feral
15312	perneiras ferais
15313	ombreiras ferais
15314	colecao de reliquias
15322	espingarda de cano liso
15323	espingarda de percussao
15324	rifle ardelado
15325	arcabuz do atirador de elite
15326	machado de arremesso rebrilhante
15327	adaga de arremesso malefica
15328	chave de josefo
15329	cinto do boiadeiro
15330	botas do boiadeiro
15331	munhequeiras do boiadeiro
15332	broquel do boiadeiro
15333	manto do boiadeiro
15334	luvas do boiadeiro
15335	espadim de aco torga
15336	perneiras do boiadeiro
15337	colete do boiadeiro
15338	dragonas do boiadeiro
15339	casquete desbravador
15340	manto desbravador
15341	pisantes desbravadores
15342	protetor desbravador
15343	luvas desbravadoras
15344	calcas desbravadoras
15345	ombreiras desbravadoras
15346	colete desbravador
15347	cinto desbravador
15348	bracadeiras desbravadoras
15349	cinto do cacador de cabecas
15350	sapatilhas do cacador de cabecas
15351	embraces do cacador de cabecas
15352	broquel do cacador de cabecas
15353	touca do cacador de cabecas
15354	manto do cacador de cabecas
15355	luvas do cacador de cabecas
15356	armadura do cacador de cabecas
15357	espaldares do cacador de cabecas
15358	bermuda do cacador de cabecas
15359	colete do trapaceiro
15360	bracadeiras do trapaceiro
15361	faixa do trapaceiro
15362	botas do trapaceiro
15363	cocar do trapaceiro
15364	manto do trapaceiro
15365	mitenes do trapaceiro
15366	perneiras do trapaceiro
15367	protetor do trapaceiro
15368	brafoneiras do trapaceiro
15369	cinto do cavalga lobo
15370	botas do cavalga lobo
15371	manto do cavalga lobo
15372	luvas do cavalga lobo
15373	cocar do cavalga lobo
15374	perneiras do cavalga lobo
15375	ombreiras do cavalga lobo
15376	armadura acolchoada do cavalga lobo
15377	munhequeiras do cavalga lobo
15378	cinto patafuria
15379	botas patafuria
15380	bracadeiras patafuria
15381	couraca patafuria
15382	manto patafuria
15383	luvas patafuria
15384	cocar patafuria
15385	perneiras patafuria
15386	guarda ombros patafuria
15387	braceletes flamejade
15388	cinto flamejade
15389	escarpes flamejade
15390	couraca flamejade
15391	casquete flamejade
15392	manto flamejade
15393	luvas flamejade
15394	calcas flamejade
15395	palas flamejade
15396	adaga de madeira curva
15397	cajado de tordo do carvalho
15398	botas do rastelo de areia
15399	cinto de erva seca
15400	bracadeiras de conchas
15401	luvas mina d agua
15402	manoplas da pegada nodosa
15403	bracadeiras da costa escarpada
15404	cinturao rompe agua
15405	luvas de debulha
15406	botas crustaceas
15407	pelego rustico curado
15408	escama pesada de escorpideo
15409	sal rochafunda refinado
15410	escama da onyxia
15411	marca de fordring
15412	escama de dragao verde
15413	peitoral ornado de adamantio
15414	escama de dragao vermelho
15415	escama de dragao azul
15416	escama de dragao negro
15417	couro de demossauro
15418	martelo de guerra de platina cintilante
15419	couro de urso de guerra
15420	penaferrea
15421	mortalha dos exilados
15422	couro pedra sabre
15423	couro de quimera
15424	machado de orgrimmar
15425	bracadeiras inigualaveis
15426	botas inigualaveis
15427	manto inigualavel
15428	cinto inigualavel
15429	luvas inigualaveis
15430	bandana inigualavel
15431	perneiras inigualaveis
15432	omoplatas inigualaveis
15433	armadura inigualavel
15434	faixa suprema
15435	sapatos supremos
15436	bracadeiras supremas
15437	capa suprema
15438	luvas supremas
15439	coroa suprema
15440	perneiras supremas
15441	omoplatas supremas
15442	peitoral supremo
15443	cris de orgrimmar
15444	cajado de orgrimmar
15445	martelo de orgrimmar
15446	kit de subdelegado de ventobravo
15447	putrefacao viva
15448	putrefacao coagulada
15449	calcas medonhas
15450	perneiras dragalodo
15451	perneiras da gargula
15452	bracadeiras enfeitadas de penas
15453	bracadeiras da savana
15454	almofariz e pilao
15455	vestes quedapo
15456	perneiras pe ligeiro
15457	omoplatas do deserto
15458	botas tundricas
15459	munhequeiras sinisdobre
15461	botas saltoleve
15462	bracadeiras argilofloco
15463	luvas do andarilho palido
15464	martelo bruto
15465	varinha ferroada
15466	escudo do tinido
15467	anel da liga do inventor
15468	clamide canteolo
15469	cilha canteolo
15470	perneiras do guarda das planicies
15471	armadura couroforte
15472	cinto do corcel
15473	botas do corcel
15474	bracadeiras do corcel
15475	manto do corcel
15476	mitenes do corcel
15477	calcas do corcel
15478	escudo do corcel
15479	armadura do corcel
15480	cinturao rasgado em combate
15481	grevas rasgadas em combate
15482	embraces rasgados em combate
15483	capa rasgada em combate
15484	luvas rasgadas em combate
15485	calcas rasgadas em combate
15486	escudo rasgado em combate
15487	tunica rasgada em combate
15488	sobretudo salpicado de sangue
15489	escarpes salpicados de sangue
15490	manto salpicado de sangue
15491	luvas salpicadas de sangue
15492	faixa salpicada de sangue
15493	tanga salpicada de sangue
15494	escudo salpicado de sangue
15495	munhequeiras salpicadas de sangue
15496	ombreiras salpicadas de sangue
15497	cordao do vanguardeiro
15498	sapatilhas do vanguardeiro
15499	manilhas do vanguardeiro
15500	couraca do vanguardeiro
15501	manto do vanguardeiro
15502	luvas do vanguardeiro
15503	guarda pernas do vanguardeiro
15504	escudo do vanguardeiro
15505	brafoneiras do vanguardeiro
15506	tornozeleiras do bruto
15507	bracadeiras do bruto
15508	capa do bruto
15509	mitenes do bruto
15510	cinto do bruto
15511	guarda pernas do bruto
15512	escudo do bruto
15513	brafoneiras do bruto
15514	peito d armas do bruto
15515	cinto de malha farpada
15516	sapatilhas de malha farpada
15517	munhequeiras de malha farpada
15518	peitoral de malha farpada
15519	manto de malha farpada
15520	manoplas de malha farpada
15521	perneiras de malha farpada
15522	escudo de malha farpada
15523	espaldares de malha farpada
15524	sobretudo da sentinela
15525	sapatilhas da sentinela
15526	capa da sentinela
15527	luvas da sentinela
15528	faixa da sentinela
15529	perneiras da sentinela
15530	escudo da sentinela
15531	guarda ombros da sentinela
15532	pulseiras da sentinela
15533	diadema da sentinela
15534	botas de malha perversas
15535	bracadeiras encadeadas perversas
15536	peito d armas encadeado perverso
15537	manto encadeado perverso
15538	manoplas encadeadas perversas
15539	cintel encadeado perverso
15540	capacete encadeado perverso
15541	guarda pernas encadeadas perversas
15542	ombreiras encadeadas perversas
15543	escudo encadeado perverso
15544	escarpes de escama grossos
15545	braceletes de escama grossos
15546	peitoral de escama grosso
15547	manto de escama grosso
15548	manoplas de escama grossas
15549	cinto de escama grosso
15550	coroa de escama grossa
15551	guarda pernas de escama grossos
15552	escudo de escama grosso
15553	espaldares de escamas grossas
15554	cinturao do rapinante
15555	botas do rapinante
15556	bracadeiras do rapinante
15557	couraca do rapinante
15558	coroa do rapinante
15559	manto do rapinante
15560	luvas do rapinante
15561	perneiras do rapinante
15562	brafoneiras do rapinante
15563	escudo do rapinante
15564	kit de armadura rustica
15565	botas do espoliador
15566	bracadeiras do espoliador
15567	tunica do espoliador
15568	manto do espoliador
15569	escudo do espoliador
15570	manoplas do espoliador
15571	cinto do espoliador
15572	diadema do espoliador
15573	perneiras do espoliador
15574	ombreiras do espoliador
15575	cinto conchalume
15576	escarpes conchalume
15577	bracadeiras conchalume
15578	peitoral conchalume
15579	manto conchalume
15580	capuz conchalume
15581	manoplas conchalume
15582	guarda pernas conchalume
15583	ombreiras conchalume
15584	escudo conchalume
15585	guantes imorais
15586	flor de crescimento rapido
15587	cinturao do marsupial
15588	cinto de aco reforcado
15589	pisoteadores constantes
15590	braceletes constantes
15591	peitoral constante
15592	broquel constante
15593	diadema constante
15594	manto constante
15595	luvas constantes
15596	coxotes constantes
15597	omoplatas constantes
15598	cinturao constante
15599	grevas antigas
15600	avambracos antigos
15601	peito d armas antigo
15602	coroa antiga
15603	manto antigo
15604	defensor antigo
15605	manoplas antigas
15606	cinto antigo
15607	guarda pernas antigos
15608	brafoneiras antigas
15609	armadura de osteocota
15610	bracadeiras de osteocota
15611	capa de osteocota
15612	manoplas de osteocota
15613	cinto de osteocota
15614	escarpes de osteocota
15615	capacete de osteocota
15616	coxotes de osteocota
15617	palas de osteocota
15618	muralha de protecao de osteocota
15619	cinto grifico de malha
15620	braceletes grificos de malha
15621	broquel grifico de malha
15622	peitoral grifico de malha
15623	coroa grifica de malha
15624	manto grifico
15625	manoplas grificas de malha
15626	grevas grificas de malha
15627	guarda pernas grificos de malha
15628	brafoneiras grificas de malha
15629	bracadeiras formidaveis
15630	escarpes formidaveis
15631	peito d armas formidavel
15632	capa formidavel
15633	escudo formidavel
15634	diadema formidavel
15635	manoplas formidaveis
15636	cinto formidavel
15637	guarda pernas formidaveis
15638	espaldares formidaveis
15639	bracadeiras couroferreas
15640	peitoral couroferreo
15641	cinto couroferreo
15642	grevas couroferreas
15643	manto couroferreo
15644	manoplas couroferreas
15645	capacete couroferreo
15646	guarda pernas couroferreo
15647	brafoneiras couroferreas
15648	escudo couroferreo
15649	bracadeiras impiedosas
15650	sobretudo impiedoso
15651	coroa impiedosa
15652	manto impiedoso
15653	manoplas impiedosas
15654	cinto impiedoso
15655	guarda pernas impiedosos
15656	palas impiedosas
15657	escudo impiedoso
15658	escarpes impenetraveis
15659	braceletes impenetraveis
15660	peitoral impenetravel
15661	manto impenetravel
15662	manoplas impenetraveis
15663	cinto impenetravel
15664	capacete impenetravel
15665	guarda pernas impenetraveis
15666	brafoneiras impenetraveis
15667	muro impenetravel
15668	bracadeiras magnificas
15669	peitoral magnifico
15670	capacete magnifico
15671	manto magnifico
15672	manoplas magnificas
15673	cinto magnifico
15674	grevas magnificas
15675	protetor magnifico
15676	perneiras magnificas
15677	omoplatas magnificas
15678	escarpes triunfantes
15679	bracadeiras triunfantes
15680	peito d armas triunfante
15681	manto triunfante
15682	manoplas triunfantes
15683	cinturao triunfante
15684	elmo triunfante
15685	coxotes triunfantes
15686	ombreiras triunfantes
15687	escudo triunfante
15688	feijoes magicos
15689	anel do mercador
15690	colar de osso de kodo
15691	arcabuz do artilheiro de flanco
15692	ferrete de kodos
15693	omoplatas vultosas
15694	grevas impiedosas
15695	escudo anelar rebitado
15696	livro estragado
15697	botas do ladrao de kodo
15698	espaldares contendores
15699	embrulho pardo pequeno
15702	anel do quimico
15703	guarda po do quimico
15704	medalha da insignia do cacador
15705	lamina insignia da mare
15706	lamina rastreadora de caca
15707	faixa lenhabram
15708	luvas de couro empesteadas
15709	cinturao forjadentada
15710	po lunar cenariano
15722	cantil da espraga
15723	cha com acucar
15724	molde bracadeiras escorpideas pesadas
15725	molde manoplas de couro malefico
15726	molde peitoral de escama de dragao verde
15727	molde colete escorpideo pesado
15728	molde bracadeiras de couro malefico
15729	molde luvas quimericas
15730	molde peitoral de escama de dragao vermelho
15731	molde manoplas de couro runico
15732	molde perneiras vulcanicas
15733	molde perneiras de escama de dragao verde
15734	molde omoplatas vivas
15735	molde omoplatas de penaferrea
15736	composto quimico especial do fumaca
15737	molde botas quimericas
15738	molde manoplas escorpideas pesadas
15739	molde bracadeiras de couro runico
15740	molde botas sabre de gelo
15741	molde calcas do veu da tempestade
15742	molde arnes de urso de guerra
15743	molde cinto escorpideo pesado
15744	molde bandana de couro malefico
15745	molde cinto de couro runico
15746	molde perneiras quimericas
15747	molde perneiras sabre de gelo
15748	molde perneiras escorpideas pesadas
15749	molde peitoral vulcanico
15750	o cetro de luz
15751	molde peitoral de escama de dragao azul
15752	molde perneiras vivas
15753	molde armadura do veu da tempestade
15754	molde bermuda de urso de guerra
15755	molde colete quimerico
15756	molde bandana de couro runico
15757	molde calcas de couro malefico
15758	molde manoplas de demossauro
15759	molde peitoral de escama de dragao negro
15760	molde peitoral de penaferrea
15761	molde luvas sabre de gelo
15762	molde elmo escorpideo pesado
15763	molde omoplatas de escama de dragao azul
15764	molde omoplatas do veu da tempestade
15765	molde calcas de couro runico
15766	gema da serpente
15767	chave de hameya
15768	molde cinto de couro malefico
15769	molde manto de escama da onyxia
15770	molde omoplatas de escama de dragao negro
15771	molde peitoral vivo
15772	molde perneiras de demossauro
15773	molde armadura de couro malefico
15774	molde omoplatas escorpideas pesadas
15775	molde omoplatas vulcanicas
15776	molde armadura de couro runico
15777	molde omoplatas de couro runico
15778	yeti mecanico
15779	molde tunica sabre de gelo
15780	molde peitoral de escama da onyxia
15781	molde perneiras de escama de dragao negro
15782	lamina do espreitador de feras
15783	adaga do cacador de feras
15784	dragonas da brisa cristalina
15785	cabeca de zaeldarr
15786	gibao pulso da samambaia
15787	cota de tira de salgueiro
15788	relatorio de visteterna
15789	manto do rio profundo
15790	estudos sobre comunicacao com espiritos
15791	faixa turquesa
15792	espaldares de madeira de arado
15793	um osso roido
15794	tanga rasgada de ogro
15795	manoplas da nevoa esmeralda
15796	bracadeiras espuma marinha
15797	bracadeiras rutilantes
15798	dentes lascados de ogro
15799	medalha da comenda heroica
15800	espada curta intrepida
15801	espada curta valente
15802	botas de lunatrama
15803	livro dos anciaos
15804	clamide de cerise
15805	rosa de penelope
15806	cancao de mirah
15807	besta leve
15808	besta leve de qualidade
15809	balestra
15810	lanca curta
15811	lanca pesada
15812	sobreveste orquidea
15813	cinto de elos de ouro
15814	espada de hameya
15815	manto de hameya
15822	espaldares de couro sombrio
15823	manopla tijolaco
15824	vestes de astoria
15825	gibao do cacador
15826	balsamo curativo para animais
15827	peitoral escamajade
15842	amostra vazia do morro de brumedo
15843	amostra cheia do morro de brumedo
15844	amostra vazia das quedas de fontescarpa
15845	amostra cheia das quedas de fontescarpa
15846	refinador de sal
15847	arquivos de quel thalas
15848	caixote de imas fantasmais
15849	fantasmoplasma
15850	tufo de pele de quiroscuro
15851	fungo lunar
15852	chifre de kodo
15853	ceifavento
15854	estilhaco dancante
15855	anel de protecao
15856	talisma curvaluz
15857	rebento arruinamago
15858	luvas livrevento
15859	cinturao do postilhao
15860	guarda bracos infligidores
15861	botinas de sete leguas
15862	cutelo de assalto
15863	cetro solene
15864	braceletes do condor
15865	broquel ancorote
15866	bornal medicinal de povelo
15867	talisma prismatico
15868	ordens do grao cruzado
15869	chave mestra de prata
15870	chave mestra dourada
15871	chave mestra de veraprata
15872	chave mestra de arcanita
15873	caneca interminavel do joao roto
15874	marisco de casca mole
15875	maca podre
15876	bau de nathanos
15877	adorno de altar
15878	chave prateada de rodovalho
15879	garra do suserano ror
15880	cabeca de ramstein o devorador
15881	chave dourada de rodovalho
15882	meio pingente da resistencia aquatica
15883	meio pingente da agilidade aquatica
15884	livro caixa do augustus
15885	pingente do leao marinho
15886	filacterio do timolain
15887	protetor heroico
15890	escudo de vanguarda
15891	escudo grandioso
15892	escudo do matador
15893	broquel do prospector
15894	broquel felpado
15895	broquel queimado
15902	caixa surpresa do augustus
15903	garra de destro
15904	laminas de destro
15905	soqueira de destro
15906	soqueira de canhoto
15907	garra de canhoto
15908	bastao de adestramento
15909	laminas de canhoto
15911	bastao de adestramento
15912	orbe do bucaneiro
15913	bastao de adestramento
15914	bastao de adestramento
15915	bastao de adestramento
15916	bastao de adestramento
15917	bastao de adestramento
15918	esfera do conjurador
15919	bastao de adestramento
15920	bastao de adestramento
15921	bastao de adestramento
15922	bastao de adestramento
15923	bastao de adestramento
15924	carne de marisco de casca mole
15925	baculo do profissional
15926	orbe mesmerizador
15927	esfera brilhante
15928	bastao de fio de prata
15929	orbe do ceu noturno
15930	cetro imperial vermelho
15931	estrela arcana
15932	caneco do discipulo
15933	ramo simples
15934	baculo do sabio
15935	bastao duravel
15936	ramo do anoitecer
15937	esfera hibernal
15938	orbe mistico
15939	cetro do conselheiro
15940	cetro elegante
15941	cetro do alto conselheiro
15942	bastao do mestre
15943	escudo imbuido
15944	orbe ancestral
15945	baculo runico
15946	esfera do mistico
15947	estrela sanguinea
15962	bastao do satiro
15963	galho de panopetreo
15964	estrela sedareia
15965	orbe seguevento
15966	orbe venomortalha
15967	estrela altaneira
15968	esfera elunaria
15969	orbe enfeitado
15970	galho nativo
15971	bastao aborigene
15972	caneco ritual
15973	estrela do atalaia
15974	bastao pagao
15975	cetro clamachuva
15976	galho pelocardo
15977	orbe vital
15978	bastao do geomante
15979	baculo de seribrasa
15980	orbe nevoa negra
15981	esfera lunar
15982	bastao tecido em sangue
15983	cetro de gaia
15984	cetro opulento
15985	vara aracnoide
15986	estrela do osteurgo
15987	orbe astral
15988	orbe resplandecente
15989	bastao eterno
15990	escudo resistente
15991	escudo do lider guerreiro
15992	po explosivo denso
15993	granada de torio
15994	treco de torio
15995	rifle de torio
15996	sapo mecanico realista
15997	cartuchos de torio
15998	bilhete do ludovico
15999	oculos de poder magico xtremo plus
16000	tubo de torio
16001	insignia si 7 fredo
16002	insignia si 7 turyen
16003	insignia si 7 rutger
16004	rifle de ferro negro
16005	bomba de ferro negro
16006	conversor delicado de arcanita
16007	rifle impecavel de arcanita
16008	oculos do mestre engenheiro
16009	modulador de amplificacao de voz
16022	dragonete de arcanita
16023	boneco alvo magistral
16026	pvp plate helm alliance
16027	pvp plate breastplate alliance
16028	pvp plate legplates alliance
16029	pvp plate gauntlets alliance
16030	pvp plate boots alliance
16031	pvp plate shoulder alliance
16033	pvp plate wrist alliance
16034	pvp plate cloak alliance
16035	pvp cloth helm horde
16036	pvp cloth robe horde
16037	pvp cloth legs horde
16038	pvp cloth shoulder horde
16039	espada cantante ta kierthan
16040	bomba arcana
16041	diagrama granada de torio
16042	diagrama treco de torio
16043	diagrama rifle de torio
16044	diagrama sapo mecanico realista
16045	diagrama oculos de poder magico xtremo plus
16046	diagrama boneco alvo magistral
16047	diagrama tubo de torio
16048	diagrama rifle de ferro negro
16049	diagrama bomba de ferro negro
16050	diagrama conversor delicado de arcanita
16051	diagrama cartuchos de torio
16052	diagrama modulador de amplificacao de voz
16053	diagrama oculos do mestre engenheiro
16054	diagrama dragonete de arcanita
16055	diagrama bomba arcana
16056	diagrama rifle impecavel de arcanita
16057	mochila do explorador
16058	selo de fordring
16059	camisa marrom comum
16060	camisa branca comum
16072	livro de receitas de perito
16073	livro de receitas de artifice
16082	pescador artifice – o caminho da isca
16083	pescador perito – o bagre e voce
16084	socorrista perito – enfaixado
16085	socorrista artifice – cura a ti mesmo
16110	receita omelete monstro
16111	receita chili temperado de caranguejo
16112	manual bandagem grossa de seda
16113	manual bandagem de magitrama
16114	cassetete do encarregado
16115	caixote de larso
16166	sopa de feijao
16167	delicia variegada
16168	pessego celestial
16169	bolinho de arroz selvagem
16170	mandu no vapor
16171	shinsollo
16189	carta de dispensa de maggran
16190	restos mortais de estripadora furissangue
16191	espelho ornado
16192	presa de besseleth
16202	essencia eterna inferior
16203	essencia eterna maior
16204	po da ilusao
16205	semente de gaia
16206	bastao de arcanita
16207	bastao runico de arcanita
16208	sementes encantadas de gaia
16209	ordens do rodrigo
16210	caixote do antonio
16214	formula encantamento maior de intelecto bracadeiras
16215	formula encantamento maior de vigor botas
16216	formula encantamento maior de resistencia manto
16217	formula encantamento maior de vigor escudo
16218	formula encantamento superior de espirito bracadeiras
16219	formula encantamento maior de agilidade luvas
16220	formula encantamento de espirito botas
16221	formula encantamento elevado de vida torso
16222	formula encantamento superior de espirito escudo
16223	formula encantamento do arrepio gelido arma
16224	formula encantamento superior de defesa manto
16242	formula encantamento elevado de mana torso
16243	formula bastao runico de arcanita
16244	formula encantamento maior de forca luvas
16245	formula encantamento maior de agilidade botas
16246	formula encantamento superior de forca bracadeiras
16247	formula encantamento superior de impacto arma de 2m
16248	formula encantamento profano arma
16249	formula encantamento elevado de intelecto arma de 2m
16250	formula encantamento superior de ataque arma
16251	formula encantamento superior de vigor bracadeiras
16252	formula encantamento do cruzado arma
16253	formula encantamento maior de atributos torso
16254	formula encantamento de roubo de vida arma
16255	formula encantamento elevado de espirito arma de 2m
16262	colecao de nessa
16263	resposta de laird
16282	pacote de peles
16283	artigos em couro do ahanu
16302	grimorio de seta de fogo grau 2
16303	pata de ursangous
16304	cabeca de shadumbra
16305	garra de garraguda
16306	carnes de zargh
16307	carta de gryshka
16308	pe de cabra de beiranorte
16309	amuleto da chama draconica
16310	lista de brock
16311	picaretas honorarias
16312	incenderitas
16313	bau do felix
16314	balde de parafusos do felix
16315	capa do primeiro sargento
16316	grimorio de seta de fogo grau 3
16317	grimorio de seta de fogo grau 4
16318	grimorio de seta de fogo grau 5
16319	grimorio de seta de fogo grau 6
16320	grimorio de seta de fogo grau 7
16321	grimorio de pacto de sangue grau 1
16322	grimorio de pacto de sangue grau 2
16323	grimorio de pacto de sangue grau 3
16324	grimorio de pacto de sangue grau 4
16325	grimorio de pacto de sangue grau 5
16326	grimorio de escudo igneo grau 1
16327	grimorio de escudo igneo grau 2
16328	grimorio de escudo igneo grau 3
16329	grimorio de escudo igneo grau 4
16330	grimorio de escudo igneo grau 5
16331	grimorio de mudanca de fase
16332	picareta de thazz ril
16333	restos mortais de samuel
16335	insignia do primeiro sargento
16336	capa do primeiro sargento
16337	capa do primeiro sargento
16338	corcel do tenente cavaleiro
16339	corcel do comandante
16341	manto do sargento
16342	capa do sargento
16343	montaria do guarda de sangue
16344	montaria do tenente general
16345	lamina do sumo senhor da guerra
16346	grimorio de tormento grau 2
16347	grimorio de tormento grau 3
16348	grimorio de tormento grau 4
16349	grimorio de tormento grau 5
16350	grimorio de tormento grau 6
16351	grimorio de sacrificar grau 1
16352	grimorio de sacrificar grau 2
16353	grimorio de sacrificar grau 3
16354	grimorio de sacrificar grau 4
16355	grimorio de sacrificar grau 5
16356	grimorio de sacrificar grau 6
16357	grimorio de consumir sombras grau 1
16358	grimorio de consumir sombras grau 2
16359	grimorio de consumir sombras grau 3
16360	grimorio de consumir sombras grau 4
16361	grimorio de consumir sombras grau 5
16362	grimorio de consumir sombras grau 6
16363	grimorio de sofrimento grau 1
16364	grimorio de sofrimento grau 2
16365	grimorio de sofrimento grau 3
16366	grimorio de sofrimento grau 4
16367	faixa de seda do capitao cavaleiro
16368	grimorio de acoite da dor grau 2
16369	botas de seda do tenente cavaleiro
16370	manilhas de seda do capitao cavaleiro
16371	grimorio de acoite da dor grau 3
16372	grimorio de acoite da dor grau 4
16373	grimorio de acoite da dor grau 5
16374	grimorio de acoite da dor grau 6
16375	grimorio de beijo reconfortante grau 1
16376	grimorio de beijo reconfortante grau 2
16377	grimorio de beijo reconfortante grau 3
16378	grimorio de beijo reconfortante grau 4
16379	grimorio de seducao
16380	grimorio de invisibilidade inferior
16381	grimorio de devorar magia grau 2
16382	grimorio de devorar magia grau 3
16383	grimorio de devorar magia grau 4
16384	grimorio de sangue maculado grau 1
16385	grimorio de sangue maculado grau 2
16386	grimorio de sangue maculado grau 3
16387	grimorio de sangue maculado grau 4
16388	grimorio de bloquear feitico grau 1
16389	grimorio de bloquear feitico grau 2
16390	grimorio de paranoia
16391	luvas de seda do tenente cavaleiro
16392	botas de couro do tenente cavaleiro
16393	palmilhas de couro de dragao do tenente cavaleiro
16394	bracadeiras de couro do capitao cavaleiro
16395	pulseiras de couro de dragao do capitao cavaleiro
16396	manoplas de couro do tenente cavaleiro
16397	luvas de couro de dragao do tenente cavaleiro
16398	cinto de couro do capitao cavaleiro
16399	cinturao de couro de dragao do capitao cavaleiro
16400	cinturao encadeado do capitao cavaleiro
16401	botas encadeadas do tenente cavaleiro
16402	guarda bracos encadeados do capitao cavaleiro
16403	manoplas encadeadas do tenente cavaleiro
16404	munhequeiras de placa do capitao cavaleiro
16405	botas de placa do tenente cavaleiro
16406	manoplas de placa do tenente cavaleiro
16407	cinturao de placa do capitao cavaleiro
16408	globo d agua conspurcado
16409	escarpes lamelares do tenente cavaleiro
16410	manoplas lamelares do tenente cavaleiro
16411	cilha lamelar do capitao cavaleiro
16412	pulseiras lamelares do capitao cavaleiro
16413	traje de seda do capitao cavaleiro
16414	perneiras de seda do capitao cavaleiro
16415	brafoneiras de seda do tenente comandante
16416	coroa do tenente comandante
16417	armadura de couro do capitao cavaleiro
16418	mascara de couro do tenente comandante
16419	guarda pernas de couro do capitao cavaleiro
16420	espaldares de couro do tenente comandante
16421	tunica de couro de dragao do capitao cavaleiro
16422	perneiras de couro de dragao do capitao cavaleiro
16423	palas de couro de dragao do tenente comandante
16424	mortalha de couro de dragao do tenente comandante
16425	cota encadeada do capitao cavaleiro
16426	perneiras encadeadas do capitao cavaleiro
16427	brafoneiras encadeadas do tenente comandante
16428	capacete encadeado do tenente comandante
16429	elmo de placa do tenente comandante
16430	couraca de placa do capitao cavaleiro
16431	perneiras de placa do capitao cavaleiro
16432	brafoneiras de placa do tenente comandante
16433	peitoral lamelar do capitao cavaleiro
16434	cimeira lamelar do tenente comandante
16435	perneiras lamelares do capitao cavaleiro
16436	omoplatas lamelares do tenente comandante
16437	palmilhas de seda do marechal
16438	bracadeiras de seda do marechal
16439	faixa de seda do marechal
16440	luvas de seda do marechal
16441	coroa do marechal de campo
16442	perneiras de seda do marechal
16443	vestimenta de seda do marechal de campo
16444	espaldares de seda do marechal de campo
16445	bracadeiras de couro de dragao do marechal
16446	guarda pes de couro do marechal
16447	cinta de couro de dragao do marechal
16448	manoplas de couro de dragao do marechal
16449	espaldares de couro de dragao do marechal de campo
16450	guarda pernas de couro de dragao do marechal
16451	capacete de couro de dragao do marechal de campo
16452	peitoral de couro de dragao do marechal de campo
16453	peito d armas de couro do marechal de campo
16454	guantes de couro do marechal
16455	mascara de couro do marechal de campo
16456	perneiras de couro do marechal
16457	palas de couro do marechal de campo
16458	cilha de couro do marechal
16459	botas de couro de dragao do marechal
16460	pulseiras de couro do marechal
16461	bracadeiras encadeadas do marechal
16462	botas encadeadas do marechal
16463	guantes encadeados do marechal
16464	cinturao encadeado do marechal
16465	elmo encadeado do marechal de campo
16466	peitoral encadeado do marechal de campo
16467	guarda pernas encadeados do marechal
16468	espaldares encadeados do marechal de campo
16469	guarda bracos lamelares do marechal
16470	cinto lamelar do marechal
16471	luvas lamelares do marechal
16472	botas lamelares do marechal
16473	guarda peito lamelar do marechal de campo
16474	viseira lamelar do marechal de campo
16475	coxotes lamelares do marechal
16476	brafoneiras lamelares do marechal de campo
16477	armadura de placa do marechal de campo
16478	elmo de placa do marechal de campo
16479	guarda pernas de placa do marechal
16480	guarda ombros de placa do marechal de campo
16481	bracadeiras de placa do marechal
16482	cinturao de placa do marechal
16483	botas de placa do marechal
16484	manoplas de placa do marechal
16485	palmilhas de seda do guarda de sangue
16486	manilhas de seda do primeiro sargento
16487	luvas de seda do guarda de sangue
16488	cinto de seda do legionario
16489	capuz de seda do campeao
16490	calcas de seda do legionario
16491	vestes de seda do legionario
16492	ombreiras de seda do campeao
16493	guarda bracos de couro de dragao do legionario
16494	botas de couro de dragao do guarda de sangue
16495	cintel de couro de dragao do legionario
16496	manoplas de couro de dragao do guarda de sangue
16497	guarda bracos de couro do primeiro sargento
16498	botinas de couro do guarda de sangue
16499	luvas de couro do guarda de sangue
16500	cinturao de couro do legionario
16501	espaldares de couro de dragao do campeao
16502	calcas de couro de dragao do legionario
16503	elmo de couro de dragao do campeao
16504	peitoral de couro de dragao do legionario
16505	cota de couro do legionario
16506	cimeira de couro do campeao
16507	dragonas de couro do campeao
16508	perneiras de couro do legionario
16509	botas de placa do guarda de sangue
16510	luvas de placa do guarda de sangue
16511	cilha de placa do legionario
16512	bracadeiras de placa do legionario
16513	armadura de placa do legionario
16514	cimeira de placa do campeao
16515	guarda pernas de placa do legionario
16516	brafoneiras de placa do campeao
16517	bracadeiras encadeadas do legionario
16518	chancas de malha do guarda de sangue
16519	guantes de malha do guarda de sangue
16520	cilha de malha do legionario
16521	elmo de malha do campeao
16522	peito d armas de malha do legionario
16523	perneiras de malha do legionario
16524	omoplatas de malha do campeao
16525	peitoral encadeado do legionario
16526	cimeira encadeada do campeao
16527	perneiras encadeadas do legionario
16528	brafoneiras encadeadas do campeao
16529	cinturao encadeado do legionario
16530	manoplas encadeadas do guarda de sangue
16531	botas encadeadas do guarda de sangue
16532	munhequeiras de malha do primeiro sargento
16533	capucho de seda do senhor da guerra
16534	calcas de seda do general
16535	traje de seda do senhor da guerra
16536	sobreveste de seda do senhor da guerra
16537	faixa de seda do general
16538	manilhas de seda do general
16539	botas de seda do general
16540	protetores de mao de seda do general
16541	armadura de placa do senhor da guerra
16542	bacinete de placa do senhor da guerra
16543	perneiras de placa do general
16544	omoplatas de placa do senhor da guerra
16545	botas de placa do general
16546	guarda bracos de placa do general
16547	cinturao de placa do general
16548	manoplas de placa do general
16549	cota de couro de dragao do senhor da guerra
16550	capacete de couro de dragao do senhor da guerra
16551	palas de couro de dragao do senhor da guerra
16552	perneiras de couro de dragao do general
16553	bracadeiras de couro de dragao do general
16554	botas de couro de dragao do general
16555	luvas de couro de dragao do general
16556	cinto de couro de dragao do general
16557	cinturao de couro do general
16558	botinas de couro do general
16559	pulseiras de couro do general
16560	luvas de couro do general
16561	elmo de couro do senhor da guerra
16562	espaldares de couro do senhor da guerra
16563	peitoral de couro do senhor da guerra
16564	guarda pernas de couro do general
16565	peito d armas encadeado do senhor da guerra
16566	capacete encadeado do senhor da guerra
16567	guarda pernas encadeados do general
16568	omoplatas encadeadas do senhor da guerra
16569	escarpes encadeados do general
16570	munhequeiras encadeadas do general
16571	luvas encadeadas do general
16572	cinturao encadeado do general
16573	botas de malha do general
16574	manoplas de malha do general
16575	cintel de malha do general
16576	bracadeiras de malha do general
16577	armadura de malha do senhor da guerra
16578	elmo de malha do senhor da guerra
16579	perneiras de malha do general
16580	espaldares de malha do senhor da guerra
16581	cristal de ressonita
16583	estatueta demoniaca
16602	patua troll
16603	cristal de ressonita encantado
16604	vestes lunares de eluna
16605	vestes de luz do frei
16606	vestes maleficas juju
16607	vestes de sacrificio do acolito
16608	cinturao de aquarius
16622	taca espinhos
16623	medalhao de opalina
16642	manual de operacao do retalhador capitulo 1
16643	manual de operacao do retalhador capitulo 2
16644	manual de operacao do retalhador capitulo 3
16645	manual de operacao do retalhador pagina 1
16646	manual de operacao do retalhador pagina 2
16647	manual de operacao do retalhador pagina 3
16648	manual de operacao do retalhador pagina 4
16649	manual de operacao do retalhador pagina 5
16650	manual de operacao do retalhador pagina 6
16651	manual de operacao do retalhador pagina 7
16652	manual de operacao do retalhador pagina 8
16653	manual de operacao do retalhador pagina 9
16654	manual de operacao do retalhador pagina 10
16655	manual de operacao do retalhador pagina 11
16656	manual de operacao do retalhador pagina 12
16658	manto do cacador selvagem
16659	cinto habil
16660	escudo lodo flutuante
16661	capa macia do salgueiro
16662	fragmento do olho do dragao
16663	sangue do campeao dos dragoes negros
16664	bracadeiras ornadas
16665	tomo de tiro tranquilizante
16666	colete dos elementos
16667	coifa dos elementos
16668	kilt dos elementos
16669	brafoneiras dos elementos
16670	botas dos elementos
16671	braceletes dos elementos
16672	manoplas dos elementos
16673	cordao dos elementos
16674	tunica do espreitador de feras
16675	botas do espreitador de feras
16676	luvas do espreitador de feras
16677	casquete do espreitador de feras
16678	calcas do espreitador de feras
16679	dragonas do espreitador de feras
16680	cinto do espreitador de feras
16681	braceletes do espreitador de feras
16682	botas do magister
16683	braceletes do magister
16684	luvas do magister
16685	cinto do magister
16686	coroa do magister
16687	perneiras do magister
16688	vestes do magister
16689	dragonas do magister
16690	veste do devoto
16691	sandalias do devoto
16692	luvas do devoto
16693	coroa do devoto
16694	saia do devoto
16695	dragonas do devoto
16696	cinto do devoto
16697	bracadeiras do devoto
16698	mascara de brumedo
16699	perneiras de brumedo
16700	veste de brumedo
16701	dragonas de brumedo
16702	cinto de brumedo
16703	bracadeiras de brumedo
16704	sandalias de brumedo
16705	guarda bracos de brumedo
16706	colete do coracao selvagem
16707	capuz da arte sombria
16708	espaldares da arte sombria
16709	calcas da arte sombria
16710	bracadeiras da arte sombria
16711	botas da arte sombria
16712	luvas da arte sombria
16713	cinto da arte sombria
16714	bracadeiras do coracao selvagem
16715	botas do coracao selvagem
16716	cinto do coracao selvagem
16717	luvas do coracao selvagem
16718	dragonas do coracao selvagem
16719	kilt do coracao selvagem
16720	capucho do coracao selvagem
16721	tunica da arte sombria
16722	bracadeiras da forja de luz
16723	cinto da forja de luz
16724	manoplas da forja de luz
16725	botas da forja de luz
16726	peitoral da forja de luz
16727	elmo da forja de luz
16728	coxotes da forja de luz
16729	espaldares da forja de luz
16730	peitoral do valor
16731	elmo do valor
16732	coxotes do valor
16733	espaldares do valor
16734	botas do valor
16735	bracadeiras do valor
16736	cinto do valor
16737	manoplas do valor
16738	luvas murchagrao
16739	dragonas madeiroso
16740	luvas para operar retalhadora
16741	mitenes de trapo oleoso
16742	laminas serrilhadas dos brado guerreiro
16743	corda para transportar toras
16744	oleo dos brado guerreiro
16745	carregamento de machados dos brado guerreiro
16746	relatorio dos brado guerreiro
16747	tranca quebrada
16748	forro acolchoado
16762	nucleo das profundezas
16763	informe do mensageiro do brado guerreiro
16764	informe do batedor do brado guerreiro
16765	informe do pioneiro do brado guerreiro
16766	ensopado de marisco inframina
16767	receita ensopado de marisco inframina
16768	bolsa medicinal de pelurso
16769	totem medicinal de pelurso
16782	globo d agua estranho
16783	monte de relatorios
16784	safira de aku mai
16786	olho de dragomorfo preto
16787	amuleto de subversao draconica
16788	leme do capitao rodovalho
16789	cana do leme do capitao rodovalho
16790	bilhete umido
16791	manilhas da torrente sedosa
16792	clava gigante
16793	omoplatas de arquimetal
16794	munhequeiras da pegada ferrea
16795	coroa do arcanista
16796	perneiras do arcanista
16797	dragonas do arcanista
16798	vestes do arcanista
16799	braceletes do arcanista
16800	botas do arcanista
16801	luvas do arcanista
16802	cinto do arcanista
16803	sapatilhas vilcordias
16804	bracadeiras vilcordias
16805	luvas vilcordias
16806	cinto vilcordio
16807	ombreiras vilcordias
16808	chifres vilcordios
16809	vestes vilcordias
16810	calcas vilcordias
16811	botas da profecia
16812	luvas da profecia
16813	diadema da profecia
16814	calcas da profecia
16815	vestes da profecia
16816	dragonas da profecia
16817	cinturao da profecia
16818	cinto do vento etereo
16819	avambracos da profecia
16820	peito d armas do matador noturno
16821	elmo do matador noturno
16822	calcas do matador noturno
16823	ombreiras do matador noturno
16824	botas do matador noturno
16825	braceletes do matador noturno
16826	luvas do matador noturno
16827	cinto do matador noturno
16828	cinto cenariano
16829	botas cenarianas
16830	bracadeiras cenarianas
16831	luvas cenarianas
16832	espaldares dentessangue
16833	vestimenta cenariana
16834	elmo cenariano
16835	perneiras cenarianas
16836	espaldares cenarianos
16837	botas terrafuria
16838	cinto terrafuria
16839	manoplas terrafuria
16840	bracadeiras terrafuria
16841	vestimenta terrafuria
16842	capacete terrafuria
16843	guarda pernas terrafuria
16844	palas terrafuria
16845	peitoral do espreita gigantes
16846	capacete do espreita gigantes
16847	perneiras do espreita gigantes
16848	palas do espreita gigantes
16849	botas do espreita gigantes
16850	bracadeiras do espreita gigantes
16851	cinto do espreita gigantes
16852	luvas do espreita gigantes
16853	couraca do mantenedor da lei
16854	elmo do mantenedor da lei
16855	coxotes do mantenedor da lei
16856	espaldares do mantenedor da lei
16857	bracadeiras do mantenedor da lei
16858	cinto do mantenedor da lei
16859	botas do mantenedor da lei
16860	manoplas do mantenedor da lei
16861	bracadeiras do poder
16862	escarpes do poder
16863	manoplas do poder
16864	cinto do poder
16865	peitoral do poder
16866	elmo do poder
16867	coxotes do poder
16868	brafoneiras do poder
16869	cranio de augure
16870	cranio de somnus
16871	cranio de chronalis
16872	cranio de axtroz
16873	luvas de trancas de pele
16882	caixa de tralhas desgastada
16883	caixa de tralhas gasta
16884	caixa de tralhas robusta
16885	caixa de tralhas pesada
16886	sabre do fora da lei
16887	dedo de bruxa
16888	amuleto da chama draconica fraco
16889	bengala polida
16890	alfanje de ardosia
16891	espada curta de argilito
16892	pedra da alma inferior
16893	pedra da alma
16894	bastao de cristal claro
16895	pedra da alma maior
16896	pedra da alma elevada
16897	couraca tempesfuria
16898	botas tempesfuria
16899	protetores de mao tempesfuria
16900	mantel tempesfuria
16901	guarda pernas tempesfuria
16902	brafoneiras tempesfuria
16903	cinto tempesfuria
16904	bracadeiras tempesfuria
16905	peito d armas dentessangue
16906	botas dentessangue
16907	luvas dentessangue
16908	capuz dentessangue
16909	calcas dentessangue
16910	cinto dentessangue
16911	bracadeiras dentessangue
16912	botas do vento etereo
16913	luvas do vento etereo
16914	coroa do vento etereo
16915	calcas do vento etereo
16916	vestes do vento etereo
16917	dragonas do vento etereo
16918	bracadeiras do vento etereo
16919	botas da transcendencia
16920	protetores de mao da transcendencia
16921	halo da transcendencia
16922	perneiras da transcendencia
16923	vestes da transcendencia
16924	brafoneiras da transcendencia
16925	cinto da transcendencia
16926	bracadeiras da transcendencia
16927	botas da nemesis
16928	luvas da nemesis
16929	casquete da nemesis
16930	perneiras da nemesis
16931	vestes da nemesis
16932	espaldares da nemesis
16933	cinto da nemesis
16934	bracadeiras da nemesis
16935	bracadeiras do espreita dragao
16936	cinto do espreita dragao
16937	espaldares do espreita dragao
16938	guarda pernas do espreita dragao
16939	elmo do espreita dragao
16940	manoplas do espreita dragao
16941	grevas do espreita dragao
16942	peitoral do espreita dragao
16943	bracadeiras das dez tempestades
16944	cinto das dez tempestades
16945	palas das dez tempestades
16946	coxotes das dez tempestades
16947	capacete das dez tempestades
16948	manoplas das dez tempestades
16949	grevas das dez tempestades
16950	peitoral das dez tempestades
16951	bracadeiras do julgamento
16952	cinto do julgamento
16953	espaldares do julgamento
16954	coxotes do julgamento
16955	coroa do julgamento
16956	manoplas do julgamento
16957	escarpes do julgamento
16958	peitoral do julgamento
16959	braceleiras da ira
16960	cintel da ira
16961	brafoneiras da ira
16962	coxotes da ira
16963	elmo da ira
16964	manoplas da ira
16965	escarpes da ira
16966	peitoral da ira
16967	atum amarelo de feralas
16968	piranha de sar theris
16969	molinesia azul da costa selvagem
16970	gracape brumalga
16971	escondidinho marisquete
16972	estandarte de karang
16973	ampola de agua hedionda
16974	ampola vazia de agua
16975	faixa do brado guerreiro
16976	totem de murgut
16977	botas do brado guerreiro
16978	manoplas do brado guerreiro
16979	luvas do nucleo flamifero
16980	dragonas do nucleo flamifero
16981	bracadeiras da barba da coruja
16982	botas de cao do nucleo
16983	elmo derretido
16984	botas de escama de dragao negro
16985	botas do perseguidor dos ventos
16986	luvas das agulhas arenosas
16987	cinto do guinchador
16988	omoplatas encadeadas abrasadoras
16989	cinturao encadeado abrasador
16990	manto das fadas
16991	bandagem de triagem
16992	lanca bombas do fumaca
16993	lanca fogo do fumaca
16994	luvas de quiroscuro
16995	dragonas de quiroscuro
16996	arco de rubraplanta
16997	tempestofurio
16998	protetor sagrado
16999	selo real de alexis
17000	anel do espectro
17001	anel elemental
17002	cospeconha
17003	martelo rochacranio
17004	guia de sarah
17005	tunica do guarda grosseiro
17006	guarda pernas de cobalto
17007	manoplas racha pedras
17008	pergaminho pequeno
17009	cabeca do embaixador malcin
17010	nucleo de fogo
17011	nucleo de lava
17012	couro do nucleo
17013	perneiras ferro negro
17014	bracadeiras ferro negro
17015	aniquilador ferro negro
17016	destruidor ferro negro
17017	molde dragonas do nucleo flamifero
17018	molde luvas do nucleo flamifero
17019	po arcano
17020	po arcano
17021	frutas do bosque
17022	molde botas de cao do nucleo
17023	molde elmo derretido
17024	raiz selvagem
17025	molde botas de escama de dragao negro
17026	tuberspinho selvagem
17027	vela aromatica
17028	vela sagrada
17029	vela sacra
17030	ankh
17031	runa de teleporte
17032	runa de portais
17033	simbolo da divindade
17034	semente de bordo
17035	semente do espinhaco
17036	semente de freixo
17037	semente de alamo
17038	semente de pau ferro
17039	quebra cranio
17042	cospe unha
17043	veste do zelote
17044	vontade do martir
17045	sangue do martir
17046	rasga sarjeta
17047	sobreveste luminescente
17048	rum rumsey
17049	instrucoes cinturao encadeado abrasador
17050	vestes imperiais de chan
17051	instrucoes bracadeiras ferro negro
17052	instrucoes perneiras ferro negro
17053	instrucoes omoplatas encadeadas abrasadoras
17054	clemencia de joonho
17055	esmaga changuk
17056	pluma
17057	escamas brilhantes de peixe
17058	oleo de peixe
17059	instrucoes aniquilador ferro negro
17060	instrucoes destruidor ferro negro
17061	sombra de juno
17062	receita truta cabeca de mithril
17063	anel de accuria
17064	estilhaco da escama
17065	medalhao do poder estavel
17066	disco do perfurador
17067	grimorio antigo da pedra angular
17068	mortifero
17069	marca do atirador
17070	presa dos misticos
17071	rasgatripas
17072	lanca pipoco
17073	treme terra
17074	golpe sombrio
17075	vis kag o dessangrador
17076	gume rasgaosso
17077	choque carmesim
17078	clamide de sapphiron
17082	estilhaco da chama
17102	manto envolto em brumas
17103	magespada lazulicanto
17104	ceifa espinhaco
17105	martelo petraura
17106	defensor de malistar
17107	capa de sangue de dragao
17108	marca de deflexao
17109	gargantilha do esclarecimento
17110	selo do arquimago
17111	medalhao de ardenfuria
17112	demolidor empireo
17113	guardiao do selo ambar
17114	fragmento de filacterio de araj
17115	emblema do esquilo
17116	emblema do esquilo
17117	flauta do pegador de ratos
17118	caixa de carne duvidosa
17119	kebab de rato correfundo
17124	emblema da camarilha
17125	selo de corvoforte
17126	carta elegante
17142	estilhaco do profanador
17182	sulfuras a mao de ragnaros
17183	broquel amassado
17184	escudo pequeno
17185	broquel redondo
17186	tarja pequena
17187	broquel estriado
17188	broquel circular
17189	broquel de metal
17190	broquel ornado
17191	cetro de celebras
17192	tarja reforcada
17193	martelo de sulfuron
17194	temperos festivos
17195	visco falso
17196	bebidas de fim de ano
17197	biscoito de gengibre
17198	gemada
17199	gemada de ovo gorado
17200	receita biscoito de gengibre
17201	receita gemada
17202	bola de neve
17203	lingote de sulfuron
17204	olho de sulfuras
17222	linguica de aranha
17223	golpeforte
17224	mira de videncia
17242	chave do bau de salem
17262	chave do tiago
17302	presente de festas com fita azul
17303	papel de embrulho com fita azul
17304	papel de embrulho com fita verde
17305	presente de festas com fita verde
17306	sangue do soldado lancatroz
17307	papel de embrulho com fita roxa
17308	presente de festas com fita roxa
17309	bracadeiras dissonantes
17310	aspecto de neptulon
17322	olho do mirabrasa
17323	sinaleiro de mulverick
17324	sinaleiro de guse
17325	sinaleiro de jeztor
17326	carne do soldado lancatroz
17327	carne do tenente lancatroz
17328	carne do comandante lancatroz
17329	mao de lucifron
17330	mao de sulfuron
17331	mao de geena
17332	mao de shazzrah
17333	quintessencia aquatica
17344	bengalinha doce
17345	meleca de silitideo
17346	objeto silitideo incrustado
17347	rastreador de homem da camarilha murp
17348	tisana de cura elevada
17349	tisana de cura superior
17351	tisana de mana elevada
17352	tisana de mana superior
17353	instrucoes de ataque dos lancatroz
17354	olho que tudo ve do mestre ruben
17355	carta de ravine
17362	sinaleiro de ruben
17363	sinaleiro de ruben
17364	mira de videncia
17384	unidade retalhadora portatil do borogodo
17402	cerveja invernal do papai inverno
17403	drinque borbulhante de bondebico
17404	bebida de graos misturados
17405	cha verde de jardim
17406	roda de queijo de festa
17407	bolo de carne caseiro do gracco
17408	salame picante
17409	fragmento incrustado de cristal
17410	unidade retalhadora portatil do borogodo
17411	serra a vapor
17413	codice prece da fortitude
17414	codice prece da fortitude ii
17422	sobras de armadura
17423	cristal de tempestade
17442	instrucoes de ataque dos lobo do gelo
17502	medalha do soldado lobo do gelo
17503	medalha do tenente lobo do gelo
17504	medalha do comandante lobo do gelo
17505	sinaleiro de ichman
17506	sinaleiro de vipore
17507	sinaleiro de slidore
17508	broquel pedraforte
17522	suprimentos dos ferrofundo
17523	clamide do fumaca
17542	suprimentos de dentefrio
17562	botas de medotrama do tenente cavaleiro
17563	bracadeiras de medotrama do capitao cavaleiro
17564	luvas de medotrama do tenente cavaleiro
17565	cinto de medotrama do capitao cavaleiro
17566	cimeira do tenente comandante
17567	perneiras de medotrama do capitao cavaleiro
17568	veste de medotrama do capitao cavaleiro
17569	dragonas de medotrama do tenente comandante
17570	capuz de medotrama do campeao
17571	perneiras de medotrama do legionario
17572	veste de medotrama do legionario
17573	omoplatas de medotrama do campeao
17574	cinto de medotrama do legionario
17575	bracadeiras de medotrama do legionario
17576	botas de medotrama do guarda de sangue
17577	luvas de medotrama do guarda de sangue
17578	diadema do marechal de campo
17579	perneiras de medotrama do marechal
17580	omoplatas de medotrama do marechal de campo
17581	veste de medotrama do marechal de campo
17582	manilhas de medotrama do marechal
17583	botas de medotrama do marechal
17584	luvas de medotrama do marechal
17585	faixa de medotrama do marechal
17586	botas de medotrama do general
17587	bracadeiras de medotrama do general
17588	luvas de medotrama do general
17589	cinto de medotrama do general
17590	dragonas de medotrama do senhor da guerra
17591	capuz de medotrama do senhor da guerra
17592	veste de medotrama do senhor da guerra
17593	calcas de medotrama do general
17594	botas de cetim do tenente cavaleiro
17595	manilhas de cetim do capitao cavaleiro
17596	luvas de cetim do tenente cavaleiro
17597	cordao de cetim do capitao cavaleiro
17598	diadema do tenente comandante
17599	perneiras de cetim do capitao cavaleiro
17600	vestes de cetim do capitao cavaleiro
17601	sobreveste de cetim do tenente comandante
17602	elmo do marechal de campo
17603	calcas de cetim do marechal
17604	dragonas de cetim do marechal de campo
17605	vestimenta de cetim do marechal de campo
17606	bracadeiras de cetim do marechal
17607	sandalias de cetim do marechal
17608	luvas de cetim do marechal
17609	faixa de cetim do marechal
17610	capucho de cetim do campeao
17611	calcas de cetim do legionario
17612	vestimenta de cetim do legionario
17613	ombreiras de cetim do campeao
17614	faixa de cetim do legionario
17615	manilhas de cetim do legionario
17616	botas de cetim do guarda de sangue
17617	luvas de cetim do guarda de sangue
17618	botas de cetim do general
17619	bracadeiras de cetim do general
17620	luvas de cetim do general
17621	cilha de cetim do general
17622	dragonas de cetim do senhor da guerra
17623	capucho de cetim do senhor da guerra
17624	vestes de cetim do senhor da guerra
17625	perneiras de cetim do general
17626	focinheira de lobo do gelo
17642	pelego de carneiro de alterac
17643	pelego dos lobo do gelo
17662	gostosuras roubadas
17682	livro dadiva do indomado
17683	livro dadiva do indomado ii
17684	entalhe de cristal teradrico
17685	amostras da fazenda bosque defumado
17686	arco do mestre cacador
17687	rifle do mestre cacador
17688	botas da selva
17689	coleira de treinamento de lancatroz
17690	insignia lobo do gelo grau 1
17691	insignia lancatroz grau 1
17692	anel de chifre
17693	ampola cerulea tampada
17694	elo do punho
17695	dragonas castanhas
17696	ampola cerulea cheia
17702	bastao de celebras
17703	diamante de celebras
17704	limiar do inverno
17705	lamina cruel
17706	instrucoes limiar do inverno
17707	coracao de lasca preciosa
17708	elixir de poder gelido
17709	receita elixir de poder gelido
17710	punhal de aragonita
17711	perneiras da cordilheira elemental
17712	kit de disfarce do veu de inverno
17713	anel de pedra negra
17714	bracadeiras da princesa de pedra
17715	olho de theradras
17716	mestreneves 9000
17717	rifle megatiro
17718	broquel modernaco de bugitranca
17719	espada focal do inventor
17720	diagrama mestreneves 9000
17721	luvas do grande pai
17722	molde luvas do grande pai
17723	camisa verde festiva
17724	molde camisa verde festiva
17725	formula encantamento de poder do inverno arma
17726	presente especial da fazenda bosque defumado
17727	pacote de presentes da fazenda bosque defumado
17728	botas de escama de crocodilo albino
17730	machado dente de crocodilo
17731	pergaminho de celebras
17732	dragonas putrigarra
17733	punho de pedra
17734	elmo da montanha
17735	a festa do veu de inverno
17736	manoplas de pedra
17737	pedra nuvem
17738	garra de celebras
17739	clamide do guardiao do bosque
17740	cocar do adivinho
17741	abraco da natureza
17742	armadura de cogumelo
17743	bastao da ressurgencia
17744	coracao de toxxico
17745	clavina toxica
17746	grilhoes de toxxico
17747	raiz de azorrague
17748	sandalias de vinhaputrida
17749	espaldares de fitocouro
17750	cinturao de clorofio
17751	perneiras de pelebroto
17752	acoite do satiro
17753	mira do guardiao verdejante
17754	perneiras do trapaceiro infernal
17755	faixa de crina de satiro
17756	fragmento de lascanegra
17757	amuleto dos espiritos
17758	amuleto da uniao
17759	marca da determinacao
17760	semente da vida
17761	gema do primeiro khan
17762	gema do segundo khan
17763	gema do terceiro khan
17764	gema do quarto khan
17765	gema do quinto khan
17766	cetro da princesa theradras
17767	bacinete brotoflorido
17768	anel semelenha
17769	espaldares de artemisia
17770	manoplas da garra silvestre
17771	barra de elementio
17772	pingente zeloso lascanegra
17773	pingente lascanegra do prodigio
17774	marca do escolhido
17775	vestes da perspicacia
17776	elmo de eloduende
17777	cota encadeada implacavel
17778	cinturao de artemisia
17779	brafoneiras de pedramo
17780	lamina da escuridao eterna
17781	as instrucoes do paria
17782	estilhaco do talisma da uniao
17783	fragmento do talisma da uniao
17822	mapas dos lobo do gelo
17823	plano de batalha dos lancatroz
17849	estandarte dos lancatroz
17850	estandarte dos lobo do gelo
17900	insignia lancatroz grau 2
17901	insignia lancatroz grau 3
17902	insignia lancatroz grau 4
17903	insignia lancatroz grau 5
17904	insignia lancatroz grau 6
17905	insignia lobo do gelo grau 2
17906	insignia lobo do gelo grau 3
17907	insignia lobo do gelo grau 4
17908	insignia lobo do gelo grau 5
17909	insignia lobo do gelo grau 6
17922	armadura de pelame de leao
17943	punho de pedra
17962	saco azul de gemas
17963	saco verde de gemas
17964	saco cinza de gemas
17965	saco amarelo de gemas
17966	mochila de pelego da onyxia
17967	escama da onyxia refinada
17968	escama da onyxia carregada
17969	saco vermelho de gemas
17982	nucleo de ragnaros
18022	selo real de alexis
18023	pingente de rubi sangue
18042	flecha com ponteira de torio
18043	botas do minerador de carvao
18044	caneco do hurley
18045	file macio de lobo
18046	receita file macio de lobo
18047	pisa chamas
18048	martelo do mestre ferreiro
18082	bengala aperreante do zum rah
18083	guantes de jumanza
18102	botas de ginete do dragao
18103	elo da ruminacao
18104	cinturao torrente feral
18142	cabeca decepada de elfo noturno
18143	tufo de cabelo de gnomo
18144	lasca de osso humano
18145	casco de tauren
18146	mojo de troll lancanegra
18147	coracao renegado
18148	cranio de korrak
18149	runa de revocacao
18150	runa de revocacao
18151	frasco de ametista cheio
18152	frasco de ametista
18153	gema vermelha moro gai
18154	timbre da blizzard
18155	gema azul moro gai
18156	gema verde moro gai
18157	gema preta moro gai
18158	gema dourada moro gai
18159	gema branca moro gai
18160	receita cha de cardo
18168	disco de forca reativa
18169	dragonas flamejantes da aurora
18170	dragonas gelidas da aurora
18171	dragonas arcanas da aurora
18172	dragonas naturais da aurora
18173	dragonas sombrias da aurora
18182	dragonas cromaticas da aurora
18202	garra esquerda de eskhandar
18203	garra direita de eskhandar
18204	pelagem de eskhandar
18205	coleira de eskhandar
18206	espinha de anao
18207	dente de orc
18208	clamide de bencao
18209	vela de ignicao energizada
18222	cipo espinhoso
18223	petala serrilhada
18224	raiz de acoitadeira
18225	sapatos de corrida usados
18226	um pacto selado
18227	chupeta gasta
18228	foto autografada de tigule
18229	supremo guia de pesca do nat pagle
18230	botao j a g a n h e i quebrado
18231	camiseta sem manga
18232	robo de reparos em campo 74a
18233	lenco borrado de lagrimas
18234	documento da importadora pau de fogo
18235	diagrama robo de reparos em campo 74a
18236	brinquedinho de morder dos gordok
18237	mandibula de mastim
18238	luvas de couro sombrio
18239	molde luvas de couro sombrio
18240	tanino ogrico
18241	bridao de corcel de guerra preto
18242	redeas do tigre de guerra preto
18243	tanquestruz preto
18244	carneiro de guerra preto
18245	trompa do lobo de guerra preto
18246	apito do raptor de guerra preto
18247	kodo de guerra preto
18248	cavalo de guerra descarnado vermelho
18249	chave do crescente
18250	chave dos grilhoes dos gordok
18251	kit de armadura do nucleo
18252	molde kit de armadura do nucleo
18253	pocao elevada de rejuvenescimento
18254	escondidinho de batata ratapla
18255	batata ratapla
18256	ampola imbuida
18257	receita pocao elevada de rejuvenescimento
18258	traje de ogro gordok
18259	formula encantamento de poder magico arma
18260	formula encantamento de poder de cura arma
18261	livro de encantamentos
18262	pedra de afiar elemental
18263	braceletes do nucleo flamifero
18264	instrucoes pedra de afiar elemental
18265	molde braceletes do nucleo flamifero
18266	chave do patio dos gordok
18267	receita escondidinho de batata ratapla
18268	chave da porta de dentro dos gordok
18269	grogue verde dos gordok
18282	rifle nuclear de atirador perito
18283	precisoscopio 247x128 biznicks
18284	engasga gato do kreeg
18285	estilhaco de mana cristalizado
18286	fragmento de mana condensado
18287	amargosa
18288	calibrina de melaco
18289	colar de espinhos
18290	diagrama precisoscopio 247x128 biznicks
18291	diagrama disco de forca reativa
18292	diagrama rifle nuclear de atirador perito
18294	elixir de respiracao aquatica maior
18295	botas evanescentes
18296	embraces do atirador perito
18297	semente de espinim
18298	perneiras desenfreadas
18299	essencia de rebentagua
18300	nectar de hyjal
18301	varinha de letendris
18302	elo de vigor
18303	broquel ligeiro
18304	malha de raiz verde
18305	guarda pernas rompe agua
18306	luvas das brumas lugubres
18307	sapatos do rasgamar
18308	chapeu esperto
18309	luvas de restauracao
18310	facao do diabo
18311	bastao de canalizacao quel dorai
18312	guarda peito energizado
18313	elmo de atencao
18314	anel do logro demoniaco
18315	anel de potencia demoniaca
18316	adorno de obsidiana
18317	talisma da tempestade
18318	grevas misericordiosas
18319	elmo fervente
18320	espaldares do coracao demoniaco
18321	bastao energetico
18322	botas da tromba d agua
18323	arco do satiro
18324	corta onda
18325	casquete de couro vil
18326	manoplas navalha
18327	cordao de vinhacoite
18328	manto do bosque das sombras
18329	arcano de rapidez
18330	arcano de concentracao
18331	arcano de protecao
18332	incunabulo de rapidez
18333	incunabulo de concentracao
18334	incunabulo de protecao
18335	diamante preto limpido
18336	manoplas do poder de gordok
18337	bracadeiras orficas
18338	varinha de potencia arcana
18339	manto eidolon
18340	talisma eidolon
18341	faixa quel dorai
18342	guarda quel dorai
18343	elo petrificado
18344	manoplas litocasca
18345	anel murmurante
18346	calcas surradas
18347	machado bem equilibrado
18348	quel serrar
18349	manoplas de precisao
18350	manto amplificador
18351	bracadeiras magicamente seladas
18352	escudo de casca petrificada
18353	cajado de florpetrea
18354	colar do diabretao
18355	colar de fera
18356	garona um estudo sobre furtividade e traicao
18357	codice de defesa
18358	livro de receitas do arcanista
18359	a luz e como ativa la
18360	sombras agrilhoantes
18361	a grande corrida dos cacadores
18362	cacarolas o que a luz nao lhe contara
18363	o choque gelido e voce
18364	sonho esmeralda
18365	exemplar lido ate o final de a pesca radical de nat pagle
18366	protetores de mao de gordok
18367	manoplas de gordok
18368	luvas de gordok
18369	mitenes de gordok
18370	patua da cautela
18371	talisma destrava mentes
18372	lamina da lua nova
18373	guarda peito da tranquilidade
18374	omoplatas chamuscadas
18375	bracadeiras do eclipse
18376	maca envelhecida
18377	luvas do saca rapido
18378	perneiras de luaprata
18379	grevas detestaveis
18380	coxotes reforcados sobrenaturais
18381	pingente do mau olhado
18382	manto de flutuacao
18383	manoplas imbuidas em forca
18384	espaldares gravados com bile
18385	veste da noite sem fim
18386	calcas do padre
18387	luvas fagulhantes
18388	quebra pedra
18389	manto do cosmos
18390	perneiras de liquen emaranhado
18391	cordao do olho furtivo
18392	adaga de distracao
18393	vinculo de lenhatorta
18394	munhequeiras do uivo demoniaco
18395	anel flamejante de esmeralda
18396	entalhador de mentes
18397	pingente de mago anciao
18398	argola das mares
18399	brisa oceanica
18400	anel da pedra viva
18401	compendio do abate de dragoes de nostro
18402	anel de cristal faiscante
18403	sinete do mata dragoes
18404	pingente de dente de onyxia
18405	cinto do arquimago
18406	talisma de sangue de onyxia
18407	luvas de tecido vil
18408	luvas inferno
18409	luvas de lunatrama
18410	espada do velocista
18411	botas vivazes
18412	fragmento de nucleo
18413	manto de protecao
18414	molde cinto do arquimago
18415	molde luvas de tecido vil
18416	molde luvas inferno
18417	molde luvas de lunatrama
18418	molde manto de protecao
18420	esmaga ossos
18421	elmo de madeira da costa
18422	cabeca da onyxia
18423	cabeca da onyxia
18424	botas de junco
18425	caneco de cerveja do kreeg
18426	teia de letendris
18427	manto do sargento
18428	insignia do primeiro sargento
18429	bracadeiras de placa do primeiro sargento
18430	bracadeiras de placa do primeiro sargento
18432	munhequeiras de malha do primeiro sargento
18434	guarda bracos de couro de dragao do primeiro sargento
18435	guarda bracos de couro do primeiro sargento
18436	guarda bracos de couro de dragao do primeiro sargento
18437	manilhas de seda do primeiro sargento
18438	insignia de sargento
18440	capa do sargento
18441	capa do sargento
18442	insignia do sargento mor
18443	insignia do sargento mor
18444	insignia do sargento mor
18445	munhequeiras de placa do sargento mor
18447	munhequeiras de placa do sargento mor
18448	guarda bracos encadeados do sargento mor
18449	guarda bracos encadeados do sargento mor
18450	veste de combustao
18451	cinto de pelego de hiena
18452	bracadeiras de couro do sargento mor
18453	bracadeiras de couro do sargento mor
18454	bracadeiras de couro de dragao do sargento mor
18455	bracadeiras de couro de dragao do sargento mor
18456	manilhas de seda do sargento mor
18457	manilhas de seda do sargento mor
18458	guarda bracos discretos
18459	munhequeiras do nobre
18460	bazuca rudimentar
18461	manto do sargento
18462	soqueira de osso serrilhada
18463	punhal ogro
18464	anel nasal dos gorgok
18465	selo real de eldre thalas
18466	selo real de eldre thalas
18467	selo real de eldre thalas
18468	selo real de eldre thalas
18469	selo real de eldre thalas
18470	selo real de eldre thalas
18471	selo real de eldre thalas
18472	selo real de eldre thalas
18473	selo real de eldre thalas
18475	cinto estranhamente magico
18476	botas manchadas de lama
18477	perneiras felpadas
18478	gibao de pelego de hiena
18479	elmo do escorpideo carniceiro
18480	elmo de placa do escaravelho
18481	maca quebra cranio
18482	lancador ogro de palitos
18483	varinha canalizadora de mana
18484	lamina de ez magg
18485	escudo do observador
18486	veste de lunatrama
18487	molde veste de lunatrama
18488	lamina ancestral incandescente
18489	lamina ancestral virgem
18490	capuz perceptivo
18491	espiral do saber
18492	lamina ancestral temperada
18493	espaldares de ferro volumosos
18494	omoplatas do vigia do covil
18495	manto do reduto
18496	manto heliotropico
18497	munhequeiras sublimes
18498	o podador
18499	escudo de barreira
18500	anel elfico manchado
18501	lasca de vinhavil
18502	glaive monstruosa
18503	guarda peito de kebrapaw
18504	cinturao da percepcao
18505	cinto do trombadinha
18506	botas do mangusto
18507	botas da lua cheia
18508	bracadeiras do voo veloz
18509	manto cromatico
18510	pelego da natureza
18511	manto cambiante
18512	acido larval
18513	lamina elfica lisa e cega
18514	molde cinturao da percepcao
18515	molde botas do mangusto
18516	molde bracadeiras do voo veloz
18517	molde manto cromatico
18518	molde pelego da natureza
18519	molde manto cambiante
18520	lamina barbara
18521	botas de metal sujas
18522	elo do rei ogro
18523	pedra cintilando fulgurantemente
18524	perneiras da destruicao
18525	bracadeiras de prosperidade
18526	coroa do rei ogro
18527	manoplas harmoniosas
18528	espaldares ciclonicos
18529	cinturao elemental de placa
18530	cota forjada pelos ogros
18531	malho inexoravel
18532	veste da onda mental
18533	bracadeiras de poder dos gordok
18534	bastao dos magos ogros
18535	escudo de milli
18536	lexico de milli
18537	magnetita de contra ataque
18538	perdicao do arvoroso
18539	relicario da pureza
18540	relicario da pureza selado
18541	capa pujante
18542	tufao
18543	elo da entropia
18544	manoplas de couro da perdicao
18545	perneiras da supremacia arcana
18546	jaula craniana infernal
18547	cinturao de gelo que nao derrete
18562	minerio de elementio
18563	grilhoes do perseguidor dos ventos
18564	grilhoes do perseguidor dos ventos
18567	fluxo elemental
18582	as laminas gemeas de azzinoth
18583	glaive de guerra de azzinoth direita
18584	glaive de guerra de azzinoth esquerda
18585	elo da lealdade
18586	circulo do solarbol
18587	cabo de chupeta goblinico xg
18588	dinamite taca facil ii
18590	sangue de fera em furia
18591	caixote de sangue
18592	instrucoes martelo de sulfuron
18594	carga poderosa de cequatrum
18595	opala de sangue
18597	apito de orfao orc
18598	apito de orfao humano
18600	tomo de inteligencia arcana
18601	prisao de cristal faiscante
18602	tomo do sacrificio
18603	sangue de satiro
18604	lagrimas dos hederine
18605	demonarca aprisionado
18606	estandarte de batalha da alianca
18607	estandarte de batalha da horda
18608	bencao
18609	anatema
18610	facao afiado
18611	perneiras masca pinho
18612	botas encadeadas ensanguentadas
18622	essencia vil impecavel jaedenar
18623	essencia vil impecavel portal negro
18624	essencia vil impecavel azshara
18625	amago infernal de kroshius
18626	fogo vil
18627	gongo de defimura
18628	contrato da irmandade do torio
18629	magnetita preta
18630	feixe de luz do juizo final
18631	transformador veraprata
18632	puxa puxa do tumulto do arroio da lua
18633	pirulito azedo da stilosa
18634	refletor de gelo girogelido
18635	barrinha da bellara
18636	cabo de chupeta arruinado xg
18637	rebotocador maior
18638	refletor de chamas hiper radiante
18639	refletor de sombras ultrafulgurante
18640	rocha alegre e divertida
18641	dinamite densa
18642	autografo da jaina
18643	impressao do casco de caerne
18645	alarmobo gnomico
18646	o olho da divindade
18647	diagrama fogos de artificio vermelhos
18648	diagrama fogos de artificio verdes
18649	diagrama fogos de artificio azuis
18650	diagrama dinamite taca facil ii
18651	diagrama transformador veraprata
18652	diagrama refletor de gelo girogelido
18653	diagrama cabo de chupeta goblinico xg
18654	diagrama alarmobo gnomico
18655	diagrama rebotocador maior
18656	diagrama carga poderosa de cequatrum
18657	diagrama refletor de chamas hiper radiante
18658	diagrama refletor de sombras ultrafulgurante
18659	lasca de nordrassil
18660	aumentador de mundo
18661	diagrama aumentador de mundo
18662	bola de couro pesado
18663	jarra do jivil
18664	um tratado sobre patentes militares
18665	a visao das sombras
18670	glifos zorothianos
18671	cetro do barao charr
18672	brasa elemental
18673	pelego petreo de avalanchion
18674	elo endurecido de pedra
18675	patentes militares da horda e da alianca
18676	faixa do teceventos
18677	manto do zefiro
18678	colar congelado de tempestria
18679	anel frigido
18680	arco de ossos antigos
18681	xale de enterro
18682	perneiras de pele de carnical
18683	martelo das vesperas
18684	anel fracamente irisado
18686	omoplatas de golem osseo
18687	poeira estelar zorotiana
18688	diabrete numa jarra
18689	manto fantasmal
18690	perneiras placa da ira
18691	pingente do conselheiro sombrio
18692	escarpes do cavaleiro da morte
18693	mitenes tremelicantes
18694	grevas sombrias de malha
18695	tomo enfeiticado
18696	escudo com runas intricadas
18697	sapatilhas petralgida
18698	capuz de couro esfarrapado
18699	espaldares da tumba gelida
18700	bracadeiras maleficas
18701	elo enervante
18702	cinto do ordenado
18703	folha antiga petrificada
18704	tendao de dragao azul maduro
18705	tendao de dragao negro maduro
18706	mestre da arena
18707	baculo antigo cinzelado com runas
18708	casca petrificada
18709	munhequeiras da arena
18710	braceleiras da arena
18711	embraces da arena
18712	avambracos da arena
18713	rhok delar arco longo dos guardioes antigos
18714	lamina embrulhada de tendao antigo
18715	lok delar baculo dos guardioes antigos
18716	botas cobertas de cinza
18717	martelo do grande cruzado
18718	elmo do grao cruzado
18719	o coracao do traidor
18720	mortalha dos nathrezim
18721	cinturao da barragem
18722	guantes da morte
18723	colar encadeado animado
18724	tendao de dragao negro encantado
18725	pacificador
18726	manilhas do magistrado
18727	chapeu de feltro carmesim
18728	heranca de anastari
18729	arco guinchador
18730	mitenes de renda sombria
18731	molde bola de couro pesado
18734	manto da lua palida
18735	palmilhas de maleki
18736	perneiras do cao pestilento
18737	machadinha corta osso
18738	besta de espinha de carapaca
18739	guarda pernas de placa quitinoso
18740	faixa de thuzadin
18741	bracadeiras de morlune
18742	guarda ombros da milicia de stratholme
18743	capa graciosa
18744	luvas de pele de quiroprago
18745	perneiras de tecido sagrado
18746	cristal divinatorio
18749	alma perdida do corcel
18752	incensorio de exorcismo
18753	barda de arcanita
18754	bracadeiras de tempera vil
18755	corcel medonho zorothiano
18756	protetor do deimoguarda
18757	dragonas diabolicas
18758	lamina do espectro
18759	machado malicioso
18760	anel necromantico
18761	toque do oblivio
18762	estilhaco da chama verde
18766	redeas do sabre de gelo veloz
18767	redeas do sabre das brumas veloz
18768	redeas do sabre da aurora veloz
18769	malha de placas de torio encantado
18770	malha de placas de torio encantado
18771	malha de placas de torio encantado
18772	mecanostruz verde veloz
18773	mecanostruz branco veloz
18774	mecanostruz amarelo veloz
18775	racao de cavalo enriquecida com mana
18776	baio veloz
18777	corcel castanho veloz
18778	corcel branco veloz
18779	metade inferior de forja avancada de armaduras volume i
18780	metade superior de forja avancada de armaduras volume i
18781	metade inferior de forja avancada de armaduras volume ii
18782	metade superior de forja avancada de armaduras volume ii
18783	metade inferior de forja avancada de armaduras volume iii
18784	metade superior de forja avancada de armaduras volume iii
18785	carneiro branco veloz
18786	carneiro marrom veloz
18787	carneiro cinza veloz
18788	raptor azul veloz
18789	raptor oliva veloz
18790	raptor laranja veloz
18791	cavalo de guerra descarnado roxo
18792	barda de arcanita abencoada
18793	grande kodo branco
18794	grande kodo marrom
18795	grande kodo cinza
18796	trompa do lobo marrom veloz
18797	trompa do lobo silvestre veloz
18798	trompa do lobo cinza veloz
18799	alma redimida do corcel
18802	pocao sombria
18803	draga de lava com isolamento hipertermico
18804	algibeira de lorde grayson
18805	dente de cao magma
18806	grevas forjadas no nucleo
18807	elmo do poder latente
18808	luvas da chama hipnotica
18809	faixa dos segredos sussurrados
18810	espaldares do crescimento silvestre
18811	manto a prova de fogo
18812	munhequeiras do voo constante
18813	anel do vinculo
18814	gargantilha do senhor do fogo
18815	essencia da chama pura
18816	lamina da perdicao
18817	coroa da destruicao
18818	instrucoes de mor zul
18819	incensorio de exorcismo de rohan
18820	talisma do poder efemero
18821	anel do golpe presto
18822	lamina afiada obsidiana
18823	luvas velhas de couro do nucleo
18824	botas temperadas no magma
18825	egide do grao marechal
18826	muralha de escudos do sumo senhor da guerra
18827	machado de mao do grao marechal
18828	cutelo do sumo senhor da guerra
18829	espaldares da terra profunda
18830	talho do grao marechal
18831	machado de batalha do sumo senhor da guerra
18832	lamina da brutalidade
18833	disparo certeiro do grao marechal
18834	insignia da horda
18835	arco recurvo do sumo senhor da guerra
18836	besta de repeticao do grao marechal
18837	besta do sumo senhor da guerra
18838	punhal do grao marechal
18839	pocao de combate de cura
18840	navalha do sumo senhor da guerra
18841	pocao de combate de mana
18842	cajado de dominancia
18843	lamina destra do grao marechal
18844	garra direita do sumo senhor da guerra
18845	insignia da horda
18846	insignia da horda
18847	lamina sinistra do grao marechal
18848	garra esquerda do sumo senhor da guerra
18849	insignia da horda
18850	insignia da horda
18851	insignia da horda
18852	insignia da horda
18853	insignia da horda
18854	insignia da alianca
18855	canhao de mao do grao marechal
18856	insignia da alianca
18857	insignia da alianca
18858	insignia da alianca
18859	insignia da alianca
18860	abre alas do sumo senhor da guerra
18861	coxotes do ardilante
18862	insignia da alianca
18863	insignia da alianca
18864	insignia da alianca
18865	castigador do grao marechal
18866	porrete do sumo senhor da guerra
18867	martelo de batalha do grao marechal
18868	pulverizador do sumo senhor da guerra
18869	glaive do grao marechal
18870	elmo do vivificador
18871	dessangrador do sumo senhor da guerra
18872	perneiras da tempestade de mana
18873	baculo do grao marechal
18874	cajado de guerra do sumo senhor da guerra
18875	calcas de escama de salamandra
18876	espadao do grao marechal
18877	montante do sumo senhor da guerra
18878	punhal do feiticeiro
18879	anel pesado de ferro negro
18880	cabeca de noctilatrus
18902	redeas do sabre do trovao veloz
18904	ultra encolhedor de zorbin
18922	instrucoes secretas fluxo igneo
18942	fluxo igneo
18943	travesseiro de ferro negro
18944	escama de incendossauro
18945	residuo de ferro negro
18946	cabeca do feitor maltorius
18947	pelego de yeti cortifuria
18948	bracadeiras barbarescas
18949	molde bracadeiras barbarescas
18950	travesseiro da camareira alma fada
18951	travesseiro de aterrissagem de evonice
18952	cabeca da simone
18953	cabeca do klinfran
18954	cabeca do solenor
18955	cabeca do artorius
18956	residuo de miniaturizacao
18957	lamina matagal
18958	amago do elemental de agua
18959	alcaraviz de ferraria
18960	luneta do espia
18961	carapaca de zukk ash
18962	glandulas de cravacoite
18963	ovo de tartaruga albina
18964	ovo de tartaruga maritima
18965	ovo de tartaruga falconil
18966	ovo de tartaruga de couro
18967	ovo de tartaruga verde oliva
18969	pelego imaculado de yeti
18972	pelego perfeito de yeti
18984	estripador dimensional visteterna
18986	transportador ultrasseguro geringontzan
18987	comando do mao negra
19002	cabeca de nefarian
19003	cabeca de nefarian
19004	pedra de vida menor
19005	pedra de vida menor
19006	pedra de vida inferior
19007	pedra de vida inferior
19008	pedra de vida
19009	pedra de vida
19010	pedra de vida maior
19011	pedra de vida maior
19012	pedra de vida elevada
19013	pedra de vida elevada
19016	casulo de renascimento
19017	essencia do senhor do fogo
19018	lamina latente beijada pelo vento
19019	tormentaria lamina sagrada do perseguidor dos ventos
19020	relatorio sobre zukk ash da aldeia mojache
19022	vara de pescar suprema fc 5000 do nat pagle
19023	melhor isca de katum
19024	grande mestre da arena
19025	pluma de senhor celeste
19026	rojao rabo de cobra
19027	diagrama rojao rabo de cobra
19028	vestido elegante
19029	trompa de uivador lobo do gelo
19030	carneiro de batalha lancatroz
19031	tabardo de batalha dos lobo do gelo
19032	tabardo de batalha dos lancatroz
19033	ferramentas perdidas de escoriarvore
19034	almoco do banha
19035	cesta de piquenique especial do banha
19036	mensagem final para os martelo feroz
19037	espaldares pico da esmeralda
19038	anel da sutileza
19039	chapeu a prova d agua de zorbin
19040	mega fatiador de zorbin
19041	tunica artesanal de pradal
19042	tunica artesanal de jangdor
19043	cinto pesado dos presamatos
19044	poder dos presamatos
19045	estandarte de batalha lancatroz
19046	estandarte de batalha do lobo do gelo
19047	sabedoria dos presamatos
19048	botas pesadas dos presamatos
19049	soqueiras dos presamatos
19050	dragonas dos presamatos
19051	cinturao da aurora
19052	botinas da aurora
19054	red dragon orb
19055	green dragon orb
19056	botas argenteas
19057	luvas da aurora
19058	dragonas douradas da aurora
19059	omoplatas argenteas
19060	racao enriquecida da ravina brado guerreiro
19061	racao de ferro da ravina brado guerreiro
19062	racao de batalha da ravina brado guerreiro
19064	chave dos grilhoes
19065	circulo esmeraldino
19066	bandagem de runatrama da ravina brado guerreiro
19067	bandagem de magitrama da ravina brado guerreiro
19068	bandagem de seda da ravina brado guerreiro
19069	cranio do guarda caca malkhor
19070	ossos do guarda caca malkhor
19071	recipiente com sangue maculado
19083	manto do legionario lobo do gelo
19084	manto do soldado lancatroz
19085	manto do conselheiro lobo do gelo
19086	manto do sabio lancatroz
19087	cinto de placa dos lobo do gelo
19088	cinto de malha dos lobo do gelo
19089	cinto de couro dos lobo do gelo
19090	cinto de tecido dos lobo do gelo
19091	cinturao de placa lancatroz
19092	cinturao de malha lancatroz
19093	cinturao de couro lancatroz
19094	cinturao de tecido lancatroz
19095	pingente do legionario lobo do gelo
19096	pingente do conselheiro lobo do gelo
19097	pingente do soldado lancatroz
19098	pingente do sabio lancatroz
19099	lamina glacial
19100	adaga eletrificada
19101	cajado de tormento gelido
19102	cajado estalante
19103	queimadura de frio
19104	martelo do ataque da tempestade
19105	turbante de geada runica
19106	lanca farpada de gelo
19107	sanguinario
19108	varinha do frio penetrante
19109	anel bastante enraizado
19110	lamina forjada a frio
19111	palas de invernacha
19112	avambracos de aco congelado
19113	bracadeiras de pelego de yeti
19114	arco montanhes
19115	frasco de mojo florestal
19116	mitenes folhaverde
19117	coxotes de placa de madeira laqueada
19118	alento da natureza
19119	luvas de pelego de feruja
19120	runa do capitao da guarda
19121	manto do bosque cerrado
19123	mitenes semprequentes
19124	perneiras plaquescoria
19125	cinturao chamuscada de malha
19126	manoplas plaquescoria
19127	tunica de couro esturricada
19128	colete de malha chamuscado
19129	veste semprebrilha
19130	ruptura do gelo
19131	sapatos ceganeve
19132	coroa adornada de cristais
19133	perneiras infusas em vileza
19134	cinto esfolado de demonarca
19135	bracadeiras luz negra
19136	cordao da ignicao de mana
19137	cinturao da ofensiva
19138	elo de sulfuras
19139	omoplatas da guarda de fogo
19140	elo da cauterizacao
19141	bucha
19142	grimorio runico de fogo
19143	manoplas da guarda ignea
19144	escarpes do pisabrasa
19145	veste do poder volatil
19146	munhequeiras da estabilidade
19147	anel do feitico poderoso
19148	elmo ferro negro
19149	cinto de lava
19150	kit de sobrevivencia basico de sentinela
19151	kit de sobrevivencia padrao de sentinela
19152	kit de sobrevivencia avancado de sentinela
19153	kit de sobrevivencia avancado de pioneiro
19154	kit de sobrevivencia basico de pioneiro
19155	kit de sobrevivencia padrao de pioneiro
19156	veste do nucleo flamifero
19157	manoplas cromaticas
19159	colar de hera trancada
19160	tabardo do vencedor do torneio
19162	cinto do cao do nucleo
19163	cinto derretido
19164	manoplas ferro negro
19165	perneiras do nucleo flamifero
19166	anistia negra
19167	furia negra
19168	guarda negra
19169	martelo do ocaso
19170	mao de ebano
19182	cupom premiado da feira de negraluna
19183	areia de ampulheta
19202	instrucoes cinto pesado dos presamatos
19203	instrucoes cinturao da aurora
19204	instrucoes botas pesadas dos presamatos
19205	instrucoes luvas da aurora
19206	instrucoes elmo ferro negro
19207	instrucoes manoplas ferro negro
19208	instrucoes anistia negra
19209	instrucoes furia negra
19210	instrucoes mao de ebano
19211	instrucoes guarda negra
19212	instrucoes martelo do ocaso
19213	talisma de merito da asa de prata
19215	molde sabedoria dos presamatos
19216	molde botas argenteas
19217	molde omoplatas argenteas
19218	molde dragonas dos presamatos
19219	molde veste do nucleo flamifero
19220	molde perneiras do nucleo flamifero
19221	reserva especial de negraluna
19222	cerveja barata
19223	salsichao de negraluna
19224	asinhas apimentadas
19225	caramelo frito
19227	as de feras
19228	baralho de feras
19229	previsao do malaby no 1
19230	dois de feras
19231	tres de feras
19232	quatro de feras
19233	cinco de feras
19234	seis de feras
19235	sete de feras
19236	oito de feras
19237	previsao do malaby no 19
19238	previsao do malaby no 3
19239	previsao do malaby no 4
19240	previsao do malaby no 5
19241	previsao do malaby no 6
19242	previsao do malaby no 7
19243	previsao do malaby no 8
19244	previsao do malaby no 9
19245	previsao do malaby no 10
19246	previsao do malaby no 11
19247	previsao do malaby no 12
19248	previsao do malaby no 13
19249	previsao do malaby no 14
19250	previsao do malaby no 15
19251	previsao do malaby no 16
19252	previsao do malaby no 18
19253	previsao do malaby no 17
19254	previsao do malaby no 21
19255	previsao do malaby no 22
19256	previsao do malaby no 2
19257	baralho de generais
19258	as de generais
19259	dois de generais
19260	tres de generais
19261	quatro de generais
19262	cinco de generais
19263	seis de generais
19264	sete de generais
19265	oito de generais
19266	previsao do malaby no 20
19267	baralho de elementais
19268	as de elementais
19269	dois de elementais
19270	tres de elementais
19271	quatro de elementais
19272	cinco de elementais
19273	seis de elementais
19274	sete de elementais
19275	oito de elementais
19276	as de portais
19277	baralho de portais
19278	dois de portais
19279	tres de portais
19280	quatro de portais
19281	cinco de portais
19282	seis de portais
19283	sete de portais
19284	oito de portais
19287	carta de negraluna heroismo
19288	carta de negraluna dragao azul
19289	carta de negraluna voragem
19290	carta de negraluna espiral eterea
19291	caixote de guardados de negraluna
19292	pernil de carneiro do mes passado
19293	pernil de carneiro do ano passado
19295	flor de negraluna
19296	premio maior de negraluna
19297	premio inferior de negraluna
19298	premio menor de negraluna
19299	cara cola espumante
19300	agua de hibernia engarrafada
19301	biscoito de mana de alterac
19302	anel de negraluna
19303	colar de negraluna
19304	carne seca temperada
19305	pe de kodo em conserva
19306	ra crocante
19307	bandagem grossa de runatrama de alterac
19308	tomo de dominacao arcana
19309	tomo do poder da sombra
19310	tomo do senhor do gelo
19311	tomo de arcano abrasador
19312	flores do vivificador
19315	toque de therazane
19316	flecha de trama gelida
19317	bala de trama gelida
19318	agua engarrafada da fonte de alterac
19319	aljava de pelego de harpia
19320	bandoleira de pele de gnoll
19321	o objeto inamovivel
19322	marca de honra da ravina brado guerreiro
19323	a forca incontrolavel
19324	o lobotomizador
19325	elo de dom julio
19326	molde poder dos presamatos
19327	molde soqueiras dos presamatos
19328	molde botinas da aurora
19329	molde dragonas douradas da aurora
19330	molde cinto de lava
19331	molde manoplas cromaticas
19332	molde cinto do cao do nucleo
19333	molde cinto derretido
19334	a lamina indomavel
19335	quebra espinha
19336	gema arcana infusa
19337	o livro preto
19338	vale cupom
19339	gema do pensapresto
19340	runa da metamorfose
19341	gema da vivificacao
19342	totem peconhento
19343	pergaminhos de luz cegante
19344	cristal de alinhamento natural
19345	egide de preservacao
19346	lamina dendragonia
19347	garra de cromaggus
19348	protetor de escama de dragao vermelho
19349	baluarte reforcado de elementio
19350	furapeito
19351	maladath lamina runica da revoada negra
19352	espada temperada cromaticamente
19353	cutelo de garra de draco
19354	vingador draconico
19355	cajado de foco da asa sombria
19356	cajado da chama sombria
19357	arauto do sofrimento
19358	marreta draconica
19360	lok amir il romathis
19361	ashjre thul besta da punicao
19362	gume da perdicao
19363	crul shorukh beira do caos
19364	ashkandi montante da irmandade
19365	garra do draco preto
19366	orbe do mestre mata dragoes
19367	toque do dragao
19368	carabina bafo de dragao
19369	luvas da rapida evolucao
19370	dragonas do conciliabulo do asa negra
19371	pingente do dragao caido
19372	elmo do raiva infinita
19373	brafoneiras de couraca preta
19374	bracadeiras da precisao arcana
19375	mish undare diadema do esfolador mental
19376	anel do discernimento de archimtiros
19377	talisma da conspiracao do prestor
19378	manto do senhor da prole
19379	lagrima de neltharion
19380	elo de therazane
19381	botas da chama sombria
19382	elo de elementio puro
19383	medalhao do mestre mata dragoes
19384	anel do mestre mata dragoes
19385	perneiras carregadas
19386	manto tecido com elementio
19387	botas cromaticas
19388	garra da angelista
19389	ombreiras de couro de dragao retesado
19390	luvas de couro de dragao retesado
19391	geta cintilante
19392	cinturao do cruzado caido
19393	cinta articulada do primalista
19394	brafoneiras de garra de draco
19395	gema rejuvenescedora
19396	cinto de couro de dragao retesado
19397	anel de rocha negra
19398	manto do fogorja
19399	veste freixo preto
19400	amarra do fogorja
19401	guarda pernas articulados do primalista
19402	guarda pernas do cruzado caido
19403	elo da concentracao forcada
19405	baluarte abencoado de malfurion
19406	talisma de presa de draco
19407	luvas da chama ebanea
19422	sorte da feira de negraluna
19423	previsao do malaby no 23
19424	previsao do malaby no 24
19425	arca misteriosa
19426	orbe de negraluna
19430	mortalha do pensamento puro
19431	escaravelho iminente de styleen
19432	circulo da forca aplicada
19433	perneiras de tecebrasa
19434	elo do dominio sombrio
19435	coletador de essencias
19436	manto do poder draconico
19437	botas do pensamento puro
19438	botas da nevasca do ringo
19439	gibao entrelacado das sombras
19440	antipeconha poderoso
19441	vesicula de peconha enorme
19442	formula antipeconha poderoso
19443	previsao do malaby no 25
19444	formula encantamento de forca arma
19445	formula encantamento de agilidade – arma
19446	formula encantamento de regeneracao de mana bracadeiras
19447	formula encantamento de cura bracadeiras
19448	formula encantamento potente de espirito arma
19449	formula encantamento potente de intelecto arma
19450	casinha de jublinho
19451	previsao do malaby no 26
19452	previsao do malaby no 27
19453	previsao do malaby no 28
19454	previsao do malaby no 29
19462	ovo de jublinho
19482	pelagem de coelho bel arte
19483	descascando a cebola
19484	alcachofra do lobo do gelo
19491	amuleto de negraluna
19505	tabardo de batalha do brado guerreiro
19506	tabardo de batalha da asa de prata
19507	ombreiras do inquisidor
19508	bracadeiras de couro marcado
19509	botas de malha empoeiradas
19510	elo do legionario
19511	elo do legionario
19512	elo do legionario
19513	elo do legionario
19514	elo do protetor
19515	elo do protetor
19516	elo do protetor
19517	elo do protetor
19518	anel do conselheiro
19519	anel do conselheiro
19520	anel do conselheiro
19521	anel do conselheiro
19522	anel do erudito
19523	anel do erudito
19524	anel do erudito
19525	anel do erudito
19526	manto do curandeiro de batalha
19527	manto do curandeiro de batalha
19528	manto do curandeiro de batalha
19529	manto do curandeiro de batalha
19530	capa do zelador
19531	capa do zelador
19532	capa do zelador
19533	capa do zelador
19534	medalhao do batedor
19535	medalhao do batedor
19536	medalhao do batedor
19537	medalhao do batedor
19538	medalhao da sentinela
19539	medalhao da sentinela
19540	medalhao da sentinela
19541	medalhao da sentinela
19542	lamina do batedor
19543	lamina do batedor
19544	lamina do batedor
19545	lamina do batedor
19546	lamina da sentinela
19547	lamina da sentinela
19548	lamina da sentinela
19549	lamina da sentinela
19550	espada do legionario
19551	espada do legionario
19552	espada do legionario
19553	espada do legionario
19554	espada do protetor
19555	espada do protetor
19556	espada do protetor
19557	espada do protetor
19558	arco do pioneiro
19559	arco do pioneiro
19560	arco do pioneiro
19561	arco do pioneiro
19562	arco do vanguardeiro
19563	arco do vanguardeiro
19564	arco do vanguardeiro
19565	arco do vanguardeiro
19566	cajado nodoso do conselheiro
19567	cajado nodoso do conselheiro
19568	cajado nodoso do conselheiro
19569	cajado nodoso do conselheiro
19570	cajado do erudito
19571	cajado do erudito
19572	cajado do erudito
19573	cajado do erudito
19574	forca de mugamba
19575	forca de mugamba
19576	forca de mugamba
19577	raiva de mugamba
19578	bracadeiras do berserker
19579	marca do pagao
19580	bracadeiras do berserker
19581	bracadeiras do berserker
19582	munhequeiras da voz do vento
19583	munhequeiras da voz do vento
19584	munhequeiras da voz do vento
19585	marca do pagao
19586	marca do pagao
19587	bracadeiras do espreitador florestal
19588	marca do heroi
19589	bracadeiras do espreitador florestal
19590	bracadeiras do espreitador florestal
19591	olho de zuldazar
19592	olho de zuldazar
19593	olho de zuldazar
19594	olho que tudo ve de zuldazar
19595	bracadeiras da driade
19596	bracadeiras da driade
19597	bracadeiras da driade
19598	cascalho de jakaro
19599	cascalho de jakaro
19600	cascalho de jakaro
19601	joia de jakaro
19602	macula de kezan
19603	macula de kezan
19604	macula de kezan
19605	macula irrefreavel de kezan
19606	visao de voduria
19607	visao de voduria
19608	visao de voduria
19609	visao imaculada de voduria
19610	alga encantada dos mares do sul
19611	alga encantada dos mares do sul
19612	alga encantada dos mares do sul
19613	alga encantada dos mares do sul imaculada
19614	talisma sombrio zandalariano
19615	talisma sombrio zandalariano
19616	talisma sombrio zandalariano
19617	talisma zandalariano de dominio das sombras
19618	gavinha da voragem
19619	gavinha da voragem
19620	gavinha da voragem
19621	ira da voragem
19642	icoke prize voucher
19682	colete vinassangre
19683	perneiras vinassangre
19684	botas vinassangre
19685	gibao primevo de pele de morcego
19686	luvas primevas de pele de morcego
19687	bracadeiras primevas de pele de morcego
19688	peitoral do tigre sangrento
19689	omoplatas do tigre sangrento
19690	peitoral almassangre
19691	omoplatas almassangre
19692	manoplas almassangre
19693	peitoral almanegra
19694	perneiras almanegra
19695	omoplatas almanegra
19696	pao da colheita
19697	recompensa da colheita
19698	moeda zulian
19699	moeda razzashi
19700	moeda hakkari
19701	moeda gurubashi
19702	moeda ramatorpe
19703	moeda cascasseca
19704	moeda zangareia
19705	moeda rachacranio
19706	moeda sanguescalpo
19707	joia hakkari vermelha
19708	joia hakkari azul
19709	joia hakkari amarela
19710	joia hakkari laranja
19711	joia hakkari verde
19712	joia hakkari roxa
19713	joia hakkari bronzea
19714	joia hakkari prateada
19715	joia hakkari dourada
19716	bracadeiras hakkari primevas
19717	tala hakkari primeva
19718	pilar hakkari primevo
19719	cinturao hakkari primevo
19720	faixa hakkari primeva
19721	xale hakkari primevo
19722	tabardo hakkari primevo
19723	gibao hakkari primevo
19724	egide hakkari primeva
19725	caixa de recursos arathi
19726	vinassangre
19727	foice sangrenta
19764	molde colete vinassangre
19765	molde perneiras vinassangre
19766	molde botas vinassangre
19767	couro de morcego primevo
19768	couro de tigre primevo
19769	molde gibao primevo de pele de morcego
19770	molde luvas primevas de pele de morcego
19771	molde bracadeiras primevas de pele de morcego
19772	molde peitoral do tigre sangrento
19773	molde omoplatas do tigre sangrento
19774	almalita
19775	saco lazuli lacrado
19776	instrucoes peitoral almassangre
19777	instrucoes omoplatas almassangre
19778	instrucoes manoplas almassangre
19779	instrucoes peitoral almanegra
19780	instrucoes perneiras almanegra
19781	instrucoes omoplatas almanegra
19782	presenca de poder
19783	signo do sincretista
19784	abraco da morte
19785	chamado do falcao
19786	abraco protetor do voduzeiro
19787	presenca de visao
19788	mandinga azarenta
19789	aura profetica
19790	caricia do animista
19802	coracao de hakkar
19803	veloso azul listrado do rosado
19804	peixe carnical palido
19805	acara bandeira
19806	peixe rainha deziano
19807	papa fina pintado
19808	maciste litoderme
19812	runa da aurora
19813	boneca vodu perfurada
19814	boneca vodu perfurada
19815	boneca vodu perfurada
19816	boneca vodu perfurada
19817	boneca vodu perfurada
19818	boneca vodu perfurada
19819	boneca vodu perfurada
19820	boneca vodu perfurada
19821	boneca vodu perfurada
19822	peitoral do vindicante zandalar
19823	cinto do vindicante zandalar
19824	bracadeiras do vindicante zandalar
19825	peitoral do livre pensador zandalar
19826	cinto do livre pensador zandalar
19827	bracadeiras do livre pensador zandalar
19828	cota do augure zandalar
19829	cinto do augure zandalar
19830	bracadeiras do augure zandalar
19831	dragonas do predador zandalar
19832	cinto do predador zandalar
19833	bracadeiras do predador zandalar
19834	tunica do lunatico zandalar
19835	dragonas do lunatico zandalar
19836	bracadeiras do lunatico zandalar
19838	tunica do haruspice zandalar
19839	cinto do haruspice zandalar
19840	bracadeiras do haruspice zandalar
19841	dragonas do confessor zandalar
19842	cinturao do confessor zandalar
19843	bracadeiras do confessor zandalar
19845	dragonas do ilusionista zandalar
19846	bracelete do ilusionista zandalar
19848	bracadeiras do demoniaco zandalar
19849	dragonas do demoniaco zandalar
19850	tributo de uther
19851	tributo de grom
19852	antigo matador de homens hakkari
19853	destruidor gurubashi de anoes
19854	zin rokh a destruidora de mundos
19855	coxotes banhados em sangue
19856	olho de hakkar
19857	manto da consumicao
19858	emblema honorifico de zandalar
19859	presas dos sem rosto
19861	toque do caos
19862	egide do deus sangrento
19863	selo do primalista
19864	chama sangue
19865	lamina de guerra dos hakkari
19866	lamina de guerra dos hakkari
19867	defensor do sangrelorde
19869	manoplas banhadas em sangue
19870	manto do loa hakkari
19871	talisma de protecao
19872	raptor razzashi veloz
19873	anel carmesim do lorde supremo
19874	alabarda de punicao
19875	coifa manchada de sangue
19876	colar do corruptor de almas
19877	perneiras do animista
19878	brafoneiras banhadas em sangue
19880	colecao de cabecas de gurubashi
19881	cabeca do canalizador
19882	cabeca do bagateiro
19883	cordao sagrado
19884	julgamento de jin do
19885	mau olhado de jin do
19886	mantel do bagateiro
19887	coxotes manchados de sangue
19888	abraco do lorde supremo
19889	perneiras banhadas em sangue
19890	martelo de jin do
19891	saco de sortilegios de jin do
19892	botas do animista
19893	selo de zanzil
19894	manoplas banhadas em sangue
19895	kilt tinto de sangue
19896	soqueira do thekal
19897	botas do traidor
19898	selo de jin
19899	guarda pernas rituais
19900	martelo de pedra zulian
19901	fatiador zulian
19902	tigre zulian veloz
19903	presas de venoxis
19904	cota runica manchada de sangue
19905	anel de zanzil
19906	pisantes banhados em sangue
19907	manto de pele de tigre zulian
19908	cetro de punicao
19909	proposito de arlokk
19910	soqueira da arlokk
19911	coracao chicotalga
19912	anel de onix do lorde supremo
19913	grevas banhadas em sangue
19914	bolsa de pelego de pantera
19915	defensor zulian
19918	esmagador da jeklik
19919	grevas manchadas de sangue
19920	anel do primalista
19921	machado zulian
19922	bastao azarento da arlokk
19923	talisma de opalina da jeklik
19925	anel de jin
19927	toque da mar li
19928	espaldares do animista
19929	luvas tingidas de sangue
19930	olho da mar li
19931	insania mojo gurubashi
19933	sangue luminescente de escorpideo
19934	garra grande de escorpideo
19935	vesicula de peconha vazia
19936	carapaca seca de escorpideo
19937	garra pequena de escorpideo
19938	perna pesada de escorpideo
19939	sangue de gri lek
19940	dente de renataki
19941	juba de vuxulai
19942	fio dos sonhos de hazza rah
19943	mega mojo
19944	exterminador de peixes de nat pagle
19945	tapa olho de escama de lagarto
19946	arpao de tigule
19947	carretel quebrado do nat pagle
19948	insignia heroica zandalariana
19949	medalhao heroico zandalariano
19950	patua heroico zandalariano
19951	patua do poder de gri lek
19952	patua valoroso de gri lek
19953	patua bestial de renataki
19954	patua ardiloso de renataki
19955	patua natural de vuxulai
19956	patua espiritual de vuxulai
19957	patua destruidor de hazza rah
19958	patua curativo de hazza rah
19959	patua magico de hazza rah
19960	mel cristalizado
19961	triturador do gri lek
19962	buril do gri lek
19963	forcado da loucura
19964	conduto da alma de renataki
19965	aticador de vuxulai
19967	o destruidor de pensamentos
19968	vingador de fogo
19969	botas radicais de pesca de nat pagle
19970	vara de pescar de arcanita
19971	prototipo de linha de pesca de eternio
19972	chapeu de pescaria da sorte
19973	fita metrica do nat
19974	isca para gambalama
19975	gambalama zulian
19978	campeonato de pesca
19979	anzol do pescador mestre
19982	clamide quiropusculo
19984	mascara de ebano
19986	tapa olho de pirata
19989	tomo de sombras devoradoras
19990	contas de oracao abencoadas
19991	olho de demossauro
19992	dente de demossauro
19993	arco de caca azarento
19994	fruta da colheita
19995	javali da colheita
19996	peixe da colheita
19997	nectar da colheita
19998	lente vinassangre
19999	oculos vinassangre
20000	diagrama oculos vinassangre
20001	diagrama lente vinassangre
20002	pocao maior do sono sem sonhos
20003	garras de demossauro
20004	pocao elevada de sangue de troll
20005	garras de demossauro
20006	circulo de esperanca
20007	pocao de sangue de mago
20008	pocao de acao vivaz
20009	pela luz
20010	o grito infernal da horda
20011	receita pocao de sangue de mago
20012	receita sonho sem sonhos maior
20013	receita pocao de acao vivaz
20014	receita pocao elevada de sangue de troll
20015	penas de raptor anciao
20016	trofeu de cranio de raptor
20017	galhada perfeita de ginete
20018	pelego de urso cinzento garraivoso
20019	dente de morphaz
20020	fardo de mercadorias
20021	brinco pirata de ouro
20022	chave lazuli
20023	fragmento codificado
20024	ducto biliar putrido
20025	sangue de morphaz
20026	carne putrefata
20027	glandula de ginete saudavel
20028	po reluzente
20029	coral encantado
20030	rocha de estimacao
20031	mangaroma
20032	vestes rituais esvoacantes
20033	veste do demoniaco zandalar
20034	veste do ilusionista zandalar
20035	punhal glacial
20036	rubi de fogo
20037	pingente de cristal arcano
20038	ferrao do mandokir
20039	botas ferro negro
20040	instrucoes botas ferro negro
20041	cinturao de placa do highlander
20042	cinturao lamelar do highlander
20043	cinturao encadeado do highlander
20044	cinturao de malha das terras altas
20045	cinturao de couro do highlander
20046	cinturao de couro de lagarto do highlander
20047	cinturao de tecido do highlander
20048	grevas de placa do highlander
20049	grevas lamelares do highlander
20050	grevas encadeadas do highlander
20051	grevas de malha das terras altas
20052	botas de couro do highlander
20053	botas de couro de lagarto do highlander
20054	botas de tecido do highlander
20055	brafoneiras encadeadas do highlander
20056	brafoneiras de malha do highlander
20057	espaldares de placa do highlander
20058	espaldares lamelares do highlander
20059	omoplatas de couro do highlander
20060	omoplatas de couro de lagarto do highlander
20061	palas do highlander
20062	racao enriquecida da bacia arathi
20063	racao de campanha da bacia arathi
20064	racao de ferro da bacia arathi
20065	bandagem de magitrama da bacia arathi
20066	bandagem de runatrama da bacia arathi
20067	bandagem de seda da bacia arathi
20068	manto do necroguarda
20069	cajado de cascaferro
20070	garrassabia
20071	talisma de arathor
20072	talisma do profanador
20073	manto da guarda de honra
20074	ensopado grosso de crocolisco
20075	receita ensopado grosso de crocolisco
20076	sinete zandalar de mojo
20077	sinete zandalar de poder
20078	sinete zandalar de serenidade
20079	espirito de zanza
20080	reflexo de zanza
20081	rapidez de zanza
20082	vara do padecimento
20083	lanca de caca
20084	rede de caca
20085	estilhaco arcano
20086	faca de arremesso crepusculo de aco
20087	escamas de fura ondas
20088	cinturao encadeado do highlander
20089	cinturao encadeado do highlander
20090	cinturao encadeado do highlander
20091	grevas encadeadas do highlander
20092	grevas encadeadas do highlander
20093	grevas encadeadas do highlander
20094	botas de tecido do highlander
20095	botas de tecido do highlander
20096	botas de tecido do highlander
20097	cinturao de tecido do highlander
20098	cinturao de tecido do highlander
20099	cinturao de tecido do highlander
20100	botas de couro de lagarto do highlander
20101	botas de couro de lagarto do highlander
20102	botas de couro de lagarto do highlander
20103	cinturao de couro de lagarto do highlander
20104	cinturao de couro de lagarto do highlander
20105	cinturao de couro de lagarto do highlander
20106	cinturao lamelar do highlander
20107	cinturao lamelar do highlander
20108	cinturao lamelar do highlander
20109	grevas lamelares do highlander
20110	grevas lamelares do highlander
20111	grevas lamelares do highlander
20112	botas de couro do highlander
20113	botas de couro do highlander
20114	botas de couro do highlander
20115	cinturao de couro do highlander
20116	cinturao de couro do highlander
20117	cinturao de couro do highlander
20118	cinturao de malha das terras altas
20119	cinturao de malha das terras altas
20120	cinturao de malha das terras altas
20121	grevas de malha das terras altas
20122	grevas de malha das terras altas
20123	grevas de malha das terras altas
20124	cinturao de placa do highlander
20125	cinturao de placa do highlander
20126	cinturao de placa do highlander
20127	grevas de placa do highlander
20128	grevas de placa do highlander
20129	grevas de placa do highlander
20130	frasco de diamante
20131	tabardo de batalha dos profanadores
20132	tabardo de batalha de arathor
20134	elmo de furia celeste
20150	cinturao de malha do profanador
20151	cinturao de malha do profanador
20152	cinturao de malha do profanador
20153	cinturao de malha do profanador
20154	grevas encadeadas do profanador
20155	grevas encadeadas do profanador
20156	grevas encadeadas do profanador
20157	grevas encadeadas do profanador
20158	brafoneiras encadeadas do profanador
20159	botas de tecido do profanador
20160	botas de tecido do profanador
20161	botas de tecido do profanador
20162	botas de tecido do profanador
20163	cinturao de tecido do profanador
20164	cinturao de tecido do profanador
20165	cinturao de tecido do profanador
20166	cinturao de tecido do profanador
20167	botas de couro de lagarto do profanador
20168	botas de couro de lagarto do profanador
20169	botas de couro de lagarto do profanador
20170	botas de couro de lagarto do profanador
20171	cinturao de couro de lagarto do profanador
20172	cinturao de couro de lagarto do profanador
20173	cinturao de couro de lagarto do profanador
20174	cinturao de couro de lagarto do profanador
20175	omoplatas de couro de lagarto do profanador
20176	palas do profanador
20177	cinturao lamelar do profanador
20178	cinturao lamelar do profanador
20179	cinturao lamelar do profanador
20180	cinturao lamelar do profanador
20181	grevas lamelares do profanador
20182	grevas lamelares do profanador
20183	grevas lamelares do profanador
20184	espaldares lamelares do profanador
20185	grevas lamelares do profanador
20186	botas de couro do profanador
20187	botas de couro do profanador
20188	botas de couro do profanador
20189	botas de couro do profanador
20190	cinturao de couro do profanador
20191	cinturao de couro do profanador
20192	cinturao de couro do profanador
20193	cinturao de couro do profanador
20194	omoplatas de couro do profanador
20195	cinturao de malha do profanador
20196	cinturao de malha do profanador
20197	cinturao de malha do profanador
20198	cinturao de malha do profanador
20199	grevas de malha do profanador
20200	grevas de malha do profanador
20201	grevas de malha do profanador
20202	grevas de malha do profanador
20203	brafoneiras de malha do profanador
20204	cinturao de placa do profanador
20205	cinturao de placa do profanador
20206	cinturao de placa do profanador
20207	cinturao de placa do profanador
20208	grevas de placa do profanador
20209	grevas de placa do profanador
20210	grevas de placa do profanador
20211	grevas de placa do profanador
20212	espaldares de placa do profanador
20213	cinto de cabecas encolhidas
20214	presa da mente
20215	cinto de cabecas enrugadas
20216	cinto de cabecas preservadas
20217	cinto de minicabecas
20218	manto hakkari desbotado
20219	capa hakkari esfarrapada
20220	cajado de cascaferro
20221	corcel fabuloso
20222	racao enriquecida do profanador
20223	racao de campanha do profanador
20224	racao de ferro do profanador
20225	racao enriquecida do highlander
20226	racao de campanha do highlander
20227	racao de ferro do highlander
20228	kit de sobrevivencia avancado do profanador
20229	kit de sobrevivencia basico do profanador
20230	kit de sobrevivencia padrao do profanador
20231	kit de sobrevivencia avancado de arathor
20232	bandagem de magitrama do profanador
20233	kit de sobrevivencia basico de arathor
20234	bandagem de runatrama do profanador
20235	bandagem de seda do profanador
20236	kit de sobrevivencia padrao de arathor
20237	bandagem de magitrama do highlander
20243	bandagem de runatrama do highlander
20244	bandagem de seda do highlander
20253	molde arnes de urso de guerra
20254	molde bermuda de urso de guerra
20255	botas murmupasso
20256	fita de sacrificio da ravina brado guerreiro
20257	manoplas da furia dos mares
20258	cajado cerimonial zulian
20259	luvas de pelego de pantera das sombras
20260	perneiras da furia dos mares
20261	cinto de pelego de pantera das sombras
20262	botas da furia dos mares
20263	elmo gurubashi
20264	manoplas do pacificador
20265	botas do pacificador
20266	perneiras do pacificador
20295	perneiras de escama de dragao azul
20296	manoplas de escama de dragao verde
20310	pele de demonio esfolada
20337	o burro e a cenoura
20367	equipamento de caca
20368	arco brando da estabilidade
20369	punhos de azurita
20371	ovo de murloc azul
20373	aguilhao de escorpideo petracoite
20374	aguilhao de tenaz petracoite
20375	aguilhao de esfolador petracoite
20376	presa de rastejante da areia
20377	presa de espreitadora de rocha
20378	fragmento de tabuleta do crepusculo
20379	algibeira do noggel
20380	peitoral de escama de sonhos
20381	escama de sonhos
20382	molde peitoral de escama de sonhos
20383	cabeca do prolemestre flagelador
20384	fragmento de carapaca silitidea
20385	tenaz da agarramata
20387	salva de bombas fedidas dos renegados
20388	pirulito
20389	milho doce
20390	barra de chocolate
20391	mascara fragil de gnomo
20392	mascara fragil de gnomida
20393	bolsa de gostosuras
20394	dicionario do crepusculo – capitulo 1
20395	dicionario do crepusculo – capitulo 2
20396	dicionario do crepusculo – capitulo 3
20397	varinha feiticeira pirata
20398	varinha feiticeira ninja
20399	varinha feiticeira gnomo leproso
20400	saco de abobora
20401	tabuleta restaurada do crepusculo
20402	agente de nozdormu
20403	procurador de nozdormu
20404	texto codificado do crepusculo
20405	transcricao decodificada da tabuleta
20406	dragonas de sectario do crepusculo
20407	veste de sectario do crepusculo
20408	capucho de sectario do crepusculo
20409	varinha feiticeira fantasma
20410	varinha feiticeira morcego
20411	varinha feiticeira esqueleto
20413	varinha feiticeira aleatorio
20414	varinha feiticeira – fogo fatuo
20415	a guerra das areias cambiantes
20416	escudo chamariz fogo
20418	escudo chamariz trovao
20419	brasao chamariz pedra
20420	escudo chamariz agua
20422	medalhao de posto do sectario do crepusculo
20423	pinca arenosa de escorpideo
20424	carne de verme da areia
20425	cajado nodoso do conselheiro
20426	anel do conselheiro
20427	manto do curandeiro de batalha
20428	capa do zelador
20429	elo do legionario
20430	espada do legionario
20431	anel do erudito
20432	sinete chamariz fogo
20433	sinete chamariz trovao
20434	cajado do erudito
20435	sinete chamariz pedra
20436	sinete chamariz agua
20437	arco do pioneiro
20438	arco do vanguardeiro
20439	elo do protetor
20440	espada do protetor
20441	lamina do batedor
20442	medalhao do batedor
20443	lamina da sentinela
20444	medalhao da sentinela
20447	cetro chamariz fogo
20448	cetro chamariz trovao
20449	cetro chamariz pedra
20450	cetro chamariz agua
20451	anel de suserania do sectario do crepusculo
20452	bolinhos defumados do deserto
20453	kit de transcricao do geologo
20454	decalque de colme zora
20455	decalque de colme ashi
20456	decalque de colme regia
20457	cerebro de silitideo de colme ashi
20458	cerebro de silitideo de colme zora
20459	cerebro de silitideo de colme regia
20460	carta perdida de brann barbabronze
20461	carta perdida de brann barbabronze
20462	medalhao de noturnalia
20463	prisma de cristal com glifos
20464	glifos de evocacao
20465	mecanismo de destrancamento de cristal
20466	anel sinete do viral
20467	pagina rasgada de receita
20469	recortes decodificados da crente fiel
20475	gema animica
20476	bracadeiras espreitareia
20477	manoplas espreitareia
20478	peitoral espreitareia
20479	peitoral cospefogo
20480	manoplas cospefogo
20481	bracadeiras cospefogo
20485	selo do duque
20487	lok delar baculo dos guardioes antigos dep
20488	rhok delar arco longo dos guardioes antigos dep
20489	coroa do conselho
20490	balinha de altaforja
20491	balinha da cidade baixa
20492	nougat de ventobravo
20493	nougat de orgrimmar
20494	jujuba de gnomeregan
20495	jujuba lancanegra
20496	marzipa de darnassus
20497	marzipa do penhasco do trovao
20498	quitina de silitideo
20499	quitina quebrada de silitideo
20500	carapaca leve de silitideo
20501	carapaca pesada de silitideo
20502	escudo de cascaferro
20503	espirito de agua enamorado
20504	lamina forjada em luz
20505	sinete cavalheiresco
20506	molde bracadeiras cospefogo
20507	molde manoplas cospefogo
20508	molde peitoral cospefogo
20509	molde bracadeiras espreitareia
20510	molde manoplas espreitareia
20511	molde peitoral espreitareia
20512	orbe santificado
20513	escudo abissal
20514	sinete abissal
20515	cetro abissal
20516	maca flutuante
20517	ombros de navalhaco
20518	pergaminho criar escudo chamariz
20519	chapeu de pirata dos mares do sul
20520	runa negra
20521	viseira da furia
20522	cajado feral
20524	perneiras umbrapele
20525	signo terrano
20526	pergaminho criar escudo chamariz
20527	pergaminho criar escudo chamariz
20528	pergaminho criar escudo chamariz
20530	vestes da sujeicao
20531	pergaminho criar sinete chamariz
20532	pergaminho criar sinete chamariz
20533	pergaminho criar sinete chamariz
20534	fragmento do abismo
20535	pergaminho criar sinete chamariz
20536	ceifalmas
20537	botas runicas estigias
20538	perneiras runicas estigias
20539	cinto runico estigio
20540	pergaminho criar cetro chamariz
20541	texto decodificado do crepusculo
20542	pergaminho criar cetro chamariz
20543	pergaminho criar cetro chamariz
20544	pergaminho criar cetro chamariz
20545	texto decodificado do crepusculo
20546	molde perneiras runicas estigias
20547	molde botas runicas estigias
20548	molde cinto runico estigio
20549	manoplas runanegra
20550	peitoral runanegra
20551	elmo runanegra
20552	texto decodificado do crepusculo
20553	instrucoes manoplas runanegra
20554	instrucoes peitoral runanegra
20555	instrucoes elmo runanegra
20556	cajado selvagem
20557	gostosura de abobora da noturnalia
20558	marca de honra da ravina brado guerreiro
20559	marca de honra da bacia arathi
20560	marca de honra do vale alterac
20561	mascara fragil de anao
20562	mascara fragil de ana
20563	mascara fragil de elfa noturna
20564	mascara fragil de elfo noturno
20565	mascara fragil de humana
20566	mascara fragil de humano
20567	mascara fragil de trolesa
20568	mascara fragil de troll
20569	mascara fragil de orquisa
20570	mascara fragil de orc
20571	mascara fragil de taurena
20572	mascara fragil de tauren
20573	mascara fragil de morto vivo
20574	mascara fragil de morta viva
20575	tunica de dragonete negro
20576	molde tunica de dragonete negro
20577	lamina de pesadelo
20578	esmeralda dendragonia
20579	manto verde de peledrago
20580	martelo da furia bestial
20581	cajado do crescimento descontrolado
20582	pedra do transe
20583	mascara resistente de ana
20584	mascara resistente de gnomida
20585	mascara resistente de humana
20586	mascara resistente de elfa noturna
20587	mascara resistente de orquisa
20588	mascara resistente de taurena
20589	mascara resistente de trolesa
20590	mascara resistente de morta viva
20591	mascara resistente de anao
20592	mascara resistente de gnomo
20593	mascara resistente de humano
20594	mascara resistente de elfo noturno
20595	mascara resistente de orc
20596	mascara resistente de tauren
20597	mascara resistente de troll
20598	mascara resistente de morto vivo
20599	besta de pau ferro polido
20600	anel sinete de malfurion
20601	saca com espolios
20602	bau com espolios
20603	saco com espolios
20604	limpador de bomba fedida
20605	ovos podres
20606	pena vodu ambar
20607	pena vodu azul
20608	pena vodu verde
20609	penas vodu
20610	olho injetado de aranha
20611	garra preta macica
20612	pedra do flagelo inerte
20613	madeira podre
20614	essencia de peconha
20615	bracadeiras draguilhao
20616	munhequeiras de osso de dragao
20617	perneiras antigas corroidas
20618	luvas do poder ilusorio
20619	grevas inscritas com acido
20620	megalito sagrado
20621	botas do pantano sem fim
20622	colar dracordio
20623	diadema dos sonhos inquietos
20624	anel do vivo morto
20625	cinto do brejo negro
20626	braceleiras da casca preta
20627	calcas do coracao negro
20628	casquete do crescimento anormal
20629	guarda pes malignos
20630	manoplas da luz rutilante
20631	sapatilhas do mendicante
20632	faixa rasgamentes
20633	brafoneiras sinistras de couro
20634	botas do medo
20635	vestimenta marchetada de jade
20636	cristal de hibernacao
20637	brafoneiras inscritas com acido
20638	perneiras do demente
20639	coxotes com estranhos entalhes
20640	balde cefalico do mar do sul
20641	botas do mojo do mar do sul
20642	tunica do fidalgo antiquado
20643	casquete do reservista da cidade baixa
20644	objeto mergulhado em pesadelos
20645	sussurro da natureza
20646	marca do arenomoa
20647	punhal de cristal preto
20648	martelo forjado a frio
20649	pingente prismassol
20650	manoplas do vento do deserto
20651	ovo de murloc laranja
20652	sapatilhas de tecido abissal
20653	manoplas de placa abissal
20654	cajado de batalha ametista
20655	mitenes de tecido abissal
20656	escarpes de malha abissal
20657	estilete de ponta de cristal
20658	botas de couro abissal
20659	protetores de mao de malha abissal
20660	glaive lapidadora
20661	luvas de couro abissal
20662	grevas de placa abissal
20663	arco do golpe profundo
20664	faixa de tecido abissal
20665	perneiras de couro abissal
20666	martelo de guerra de aco temperado
20667	cinto de couro abissal
20668	guarda pernas de malha abissal
20669	espadao pedranegra
20670	amarra de malha abissal
20671	coxotes de placa abissal
20672	varinha de cristal rutilante
20673	cinturao de placa abissal
20674	calcas de tecido abissal
20675	rasgalmas
20676	texto decodificado do crepusculo
20677	texto decodificado do crepusculo
20678	texto decodificado do crepusculo
20679	texto decodificado do crepusculo
20680	brafoneiras de malha abissal
20681	bracadeiras de couro abissal
20682	anel da concentracao elemental
20683	palas de placa abissal
20684	guarda bracos de malha abissal
20685	colar das ondas
20686	sobreveste de tecido abissal
20687	avambracos de placa abissal
20688	guarda terrano
20689	omoplatas de couro abissal
20690	guarda bracos de tecido abissal
20691	capa cortavento
20692	anel multicolorido
20693	manto balanceado
20694	orbe negro faiscante
20695	contas de guerra abissais
20696	malho pontudo de cristal
20697	capa bordada cristalina
20698	lamina em sintonia elemental
20699	coxotes do reservista cenariano
20700	coxotes do reservista cenariano
20701	guarda pernas do reservista cenariano
20702	guarda pernas do reservista cenariano
20703	perneiras do reservista cenariano
20704	perneiras do reservista cenariano
20705	calcas do reservista cenariano
20706	calcas do reservista cenariano
20707	calcas do reservista cenariano
20708	arca hermeticamente lacrada
20709	rum rumsey carta prata
20710	grevas incrustadas de cristal
20711	grevas tauxiadas de cristal
20712	manoplas do ermambulo
20713	manoplas do espreitadeserto
20714	botas da tempestade de areia
20715	botas do espreitaduna
20716	luvas de pele de verme da areia
20717	luvas dioneia do deserto
20720	lamina do sussuro negro
20721	elo do sectario
20722	cospe bala cristalino
20723	picareta fiel do brann
20724	cajado bosquenero corrompido
20725	cristal do nexus
20726	formula encantamento de ameaca luvas
20727	formula encantamento de poder sombrio luvas
20728	formula encantamento de poder gelido luvas
20729	formula encantamento de poder igneo luvas
20730	formula encantamento de poder de cura luvas
20731	formula encantamento superior de agilidade luvas
20732	formula encantamento maior de resistencia ao fogo manto
20733	formula encantamento maior de resistencia a natureza manto
20734	formula encantamento de furtividade manto
20735	formula encantamento de sutileza manto
20736	formula encantamento de esquiva manto
20737	pedra nuclear chamuscada
20741	totem ritual de lenha morta
20742	totem ritual invernoso
20744	oleo menor de teurgo
20745	oleo menor de mana
20746	oleo inferior de teurgo
20747	oleo inferior de mana
20748	oleo brilhante de mana
20749	oleo brilhante de teurgo
20750	oleo de teurgo
20752	formula oleo menor de mana
20753	formula oleo inferior de teurgo
20754	formula oleo inferior de mana
20755	formula oleo de teurgo
20756	formula oleo brilhante de teurgo
20757	formula oleo brilhante de mana
20758	formula oleo menor de teurgo
20761	receita transmutar fogo elemental
20763	arma quebrada
20766	bolsa gosmenta
20767	sacola coberta de escuma
20768	sacola gosmenta
20769	gosmicula nojenta
20770	linfa verde borbulhante
20800	insignia logistica cenariana
20801	insignia tatica cenariana
20802	insignia de combate cenariana
20803	ordens de batalha do martelo do crepusculo
20805	missao de logistica continuada
20806	instrucoes de logistica x
20807	instrucoes de logistica i
20808	missao de combate
20809	missao tatica
20810	papeis assinados de servico em campanha
20814	adaga de arremesso do mestre
20834	luneta ornada xt
20844	veneno mortal v
20858	escaravelho de pedra
20859	escaravelho de ouro
20860	escaravelho de prata
20861	escaravelho de bronze
20862	escaravelho de cristal
20863	escaravelho de barro
20864	escaravelho de osso
20865	escaravelho de marfim
20866	idolo lazuli
20867	idolo onix
20868	idolo bruxuleante
20869	idolo ambar
20870	idolo de jaspe
20871	idolo obsidiano
20872	idolo vermelho
20873	idolo de alabastro
20874	idolo do sol
20875	idolo da noite
20876	idolo da morte
20877	idolo do sabio
20878	idolo do renascimento
20879	idolo da vida
20881	idolo da disputa
20882	idolo da guerra
20883	joia qiraji com glifos
20884	anel magistral qiraji
20885	clamide marcial qiraji
20886	punho de pontas qiraji
20887	joia gravada qiraji
20888	anel cerimonial qiraji
20889	clamide regia qiraji
20890	punho ornamentado qiraji
20908	fogo de artificio do festival de nian
20926	diadema de vek nilash
20927	pelego intacto de ouroboros
20928	braceletes qiraji de comando
20929	carapaca do deus antigo
20930	diadema de vek lor
20931	pele do grande verme da areia
20932	braceletes qiraji de dominancia
20933	carapaca do deus antigo
20936	joia qiraji abencoada
20937	joia incrustada qiraji
20939	instrucoes de logistica ii
20940	instrucoes de logistica iii
20941	instrucoes de combate xii
20942	instrucoes de combate iii
20943	instrucoes taticas x
20944	instrucoes taticas ix
20945	instrucoes taticas ii
20946	instrucoes taticas iii
20947	instrucoes taticas iv
20948	instrucoes taticas v
20949	livro caixa magico
20951	oculos da videncia de narain
21023	costeletas sinistronas de quimeroco do funesto
21024	lombo de quimeroco
21025	receita costeletas sinistronas de quimeroco do funesto
21027	carcaca de lakmaeran
21028	frango de 250 quilos
21029	pedido de resgate
21030	torta de ragu de darnassus
21031	ragu de repolho
21032	carta de amor de meridith
21033	ragu de rabanete
21037	mapa rudimentar
21038	bola de neve bem compacta
21039	turbante de narain
21040	veste de narain
21041	saco de ouro
21042	kit especial de narain
21043	envelope misterioso
21071	sabichao cru
21072	sabichao defumado
21099	receita sabichao defumado
21100	moeda dos ancestrais
21103	draconico para leigos
21104	draconico para leigos
21105	draconico para leigos
21106	draconico para leigos
21107	draconico para leigos
21108	draconico para leigos
21109	draconico para leigos
21110	draconico para leigos
21111	draconico para leigos volume ii
21112	capa magica de livros
21113	arca a prova d agua
21114	rum rumsey carta ouro
21115	talisma do profanador
21116	talisma do profanador
21117	talisma de arathor
21118	talisma de arathor
21119	talisma de arathor
21120	talisma do profanador
21126	aguilhao da morte
21128	cajado dos profetas qiraji
21130	diario do ivio
21131	missao de combate continuada
21132	missao de logistica
21133	missao tatica continuada
21134	gume negro da insanidade
21135	machado de arremesso do assassino
21136	boia de arcanita
21137	estilhaco de cetro azul
21138	estilhaco de cetro vermelho
21139	estilhaco de cetro verde
21140	papel timbrado de leilao
21141	estilhaco de cetro vermelho destruido
21142	do punho de lorde victor nefarius
21143	papeis em branco de servico em campanha
21144	tocha de evocacao demoniaca
21145	essencia de shandivious
21146	fragmento da corrupcao do pesadelo
21147	fragmento da corrupcao do pesadelo
21148	fragmento da corrupcao do pesadelo
21149	fragmento da corrupcao do pesadelo
21150	arca com tiras de ferro
21151	rum rumsey carta negra
21152	a corrupcao do pesadelo
21153	sabichao maior cru
21154	vestido do festival
21155	oferenda de paz dos presamatos
21156	bolsa do escaravelho
21157	vestido festivo verde
21158	relatorio do batedor de colme zora
21159	ordens do batedor de colme zora
21160	relatorio do batedor de colme regia
21161	relatorio do batedor de colme ashi
21162	bocanera oleoso inchado
21163	pinafogo inchado
21164	bacalhau escama de pedra inchado
21165	instrucoes taticas vi
21166	instrucoes taticas vii
21167	instrucoes taticas viii
21168	tubarinho
21171	caneca festiva cheia
21173	caneca festiva vazia
21174	caneca festiva vazia
21175	cetro das areias cambiantes
21176	cristal ressonante qiraji preto
21177	simbolo dos reis
21178	luvas do poder terrano
21179	anel da ira terrana
21180	golpe terreno
21181	dadiva da terra
21182	elo do poder terrano
21183	colete do poder terreno
21184	bracadeiras rochafunda
21185	orbe terramansa
21186	bracadeiras rochafuria
21187	manto de trama terrena
21188	punho de cenarius
21189	poder de cenarius
21190	ira de cenarius
21191	presente cuidadosamente embrulhado
21193	sacola de d sak
21194	sacolao de d sak
21195	sacotastico de d sak
21196	anel sinete da revoada bronze
21197	anel sinete da revoada bronze
21198	anel sinete da revoada bronze
21199	anel sinete da revoada bronze
21200	anel sinete da revoada bronze
21201	anel sinete da revoada bronze
21202	anel sinete da revoada bronze
21203	anel sinete da revoada bronze
21204	anel sinete da revoada bronze
21205	anel sinete da revoada bronze
21206	anel sinete da revoada bronze
21207	anel sinete da revoada bronze
21208	anel sinete da revoada bronze
21209	anel sinete da revoada bronze
21210	anel sinete da revoada bronze
21211	bolsa de po de rena
21212	azevinho fresco
21213	azevinho seco
21214	tomo de seta de gelo xi
21215	bolo de frutas com carne moida do gracco
21216	presente extra especial da fazenda bosque defumado
21217	delicia de sabichao
21218	cristal ressonante qiraji azul
21219	receita delicia de sabichao
21220	cabeca de ossirian o intocado
21221	olho de c thun
21222	quitina encouracada
21223	pedra negra
21224	fragmento de armadura antiga
21225	casca silitidea pesada
21226	pedra runica
21227	cranio do guerreiro antigo
21228	arca com tiras de mithril
21229	insignia do lorde qiraji
21230	artefato qiraji antigo
21232	armamentos imperiais qirajis
21235	assado do veu de inverno
21236	pao do veu de inverno
21237	paramentos imperiais qirajis
21240	doce do veu de inverno
21241	batida de ovo do veu de inverno
21242	machado de guerra qiraji abencoado
21243	parrudo inchado
21244	pugio qiraji abencoado
21245	instrucoes taticas i
21246	instrucoes de combate i
21247	instrucoes de combate ii
21248	instrucoes de combate iv
21249	instrucoes de combate v
21250	instrucoes de combate vi
21251	instrucoes de combate vii
21252	instrucoes de combate viii
21253	instrucoes de combate ix
21254	biscoito do veu de inverno
21255	instrucoes de combate x
21256	instrucoes de combate xi
21257	instrucoes de logistica iv
21258	instrucoes de logistica iv
21259	instrucoes de logistica v
21260	instrucoes de logistica vi
21261	instrucoes de logistica vi
21262	instrucoes de logistica viii
21263	instrucoes de logistica vii
21264	instrucoes de logistica vii
21265	instrucoes de logistica ix
21266	missao de logistica
21267	calice de brindar
21268	martelo de guerra qiraji abencoado
21269	baluarte qiraji abencoado
21270	presente chacoalhado gentilmente
21271	presente chacoalhado gentilmente
21272	mosquete qiraji abencoado
21273	cajado qiraji abencoado do acolito
21275	cajado qiraji abencoado do augure
21277	yeti mecanico pacato
21278	luvas do veu da tempestade
21279	tomo de bola de fogo xii
21280	tomo de misseis arcanos viii
21281	grimorio de seta sombria x
21282	grimorio de imolacao viii
21283	grimorio de corrupcao vii
21284	codice de cura maior v
21285	codice de renovar ix
21287	codice de prece de cura v
21288	incunabulo bencao da sabedoria vi
21289	incunabulo bencao do poder vii
21290	incunabulo luz sagrada ix
21291	tabuleta de onda curativa x
21292	tabuleta de totem da forca da terra v
21293	tabuleta de totem da graca do ar iii
21294	livro de toque de cura xi
21295	livro de fogo estelar vii
21296	livro de rejuvenescimento xi
21297	manual de golpe heroico ix
21298	manual de grito de batalha vii
21299	manual de revanche vi
21300	guia da punhalada pelas costas ix
21301	caixa ajudante verde
21302	guia de veneno mortal v
21303	guia de finta v
21304	guia tiro multiplo v
21305	caixa ajudante vermelha
21306	guia picada de serpente ix
21307	guia aspecto do falcao vii
21308	sino pequenino
21309	kit de boneco de neve
21310	presente alegremente embrulhado
21311	colete do guardador da terra
21312	cinto do vigia do covil
21313	bolsinha de d sak
21314	cartas e anotacoes do metzen
21315	algibeira do bosque defumado
21316	perneiras do ursino
21317	elmo do desbravador
21318	luvas do guardador da terra
21319	luvas do desbravador
21320	colete do vigia do covil
21321	cristal ressonante qiraji vermelho
21322	abraco do ursino
21323	cristal ressonante qiraji verde
21324	cristal ressonante qiraji amarelo
21325	greench mecanico
21326	defensor dos presamatos
21327	presente tiquetaqueante
21328	varinha de alegria das festas
21329	coroa do conquistador
21330	espaldares do conquistador
21331	peitoral do conquistador
21332	guarda pernas do conquistador
21333	grevas do conquistador
21334	vestes do arauto da ruina
21335	dragonas do arauto da ruina
21336	calcas do arauto da ruina
21337	diadema do arauto da ruina
21338	palmilhas do arauto da ruina
21340	bolsa de almas
21341	bolsa de tecido vil
21342	bolsa principal de tecido vil
21343	vestes enigmaticas
21344	botas enigmaticas
21345	ombreiras enigmaticas
21346	perneiras enigmaticas
21347	diadema enigmatico
21348	tiara do oraculo
21349	palmilhas do oraculo
21350	dragonas do oraculo
21351	vestimenta do oraculo
21352	calcas do oraculo
21353	elmo da genese
21354	ombreiras da genese
21355	botas da genese
21356	calcas da genese
21357	colete da genese
21358	molde bolsa de almas
21359	botas do causamortis
21360	elmo do causamortis
21361	espaldares do causamortis
21362	perneiras do causamortis
21363	presente festivo
21364	colete do causamortis
21365	guarda pes do atirador
21366	diadema do atirador
21367	brafoneiras do atirador
21368	perneiras do atirador
21369	molde bolsa de tecido vil
21370	cota do atirador
21371	molde bolsa principal de tecido vil
21372	diadema do tempestario
21373	guarda pes do tempestario
21374	cota do tempestario
21375	perneiras do tempestario
21376	brafoneiras do tempestario
21377	pena do cocar de lenha morta
21378	instrucoes de logistica i
21379	instrucoes de logistica ii
21380	instrucoes de logistica iii
21381	instrucoes de logistica ix
21382	instrucoes de logistica v
21383	contas espirituais de invernoso
21384	instrucoes de logistica viii
21385	instrucoes de logistica x
21386	missao de logistica continuada
21387	coroa do vingador
21388	grevas do vingador
21389	peitoral do vingador
21390	guarda pernas do vingador
21391	brafoneiras do vingador
21392	foice da forca obstinada
21393	sinete da forca obstinada
21394	clamide da forca obstinada
21395	lamina da justica eterna
21396	anel da justica eterna
21397	capa da justica eterna
21398	martelo da tempestade iminente
21399	anel da tempestade iminente
21400	manto da tempestade iminente
21401	foice do caminho oculto
21402	sinete do caminho oculto
21403	manto do caminho oculto
21404	adaga das sombras veladas
21405	anel das sombras veladas
21406	manto das sombras veladas
21407	maca da vida interminavel
21408	anel da vida interminavel
21409	manto da vida interminavel
21410	martelete da sabedoria infinita
21411	anel da sabedoria infinita
21412	mortalha da sabedoria infinita
21413	lamina dos segredos obscuros
21414	anel dos segredos obscuros
21415	clamide dos segredos obscuros
21416	cris dos nomes proibidos
21417	anel dos nomes proibidos
21418	mortalha dos nomes proibidos
21436	sinete de comenda da alianca
21438	sinete de comenda da horda
21452	cajado das ruinas
21453	dragonas dos horusath
21454	omoplatas de pedra runica
21455	elmo do vento sul
21456	manto da tempestade de areia
21457	bracadeiras da brutalidade
21458	manoplas da vida nova
21459	besta da ruina iminente
21460	elmo da dominacao
21461	perneiras da nevasca negra
21462	luvas da sabedoria negra
21463	cinturao de ossirian
21464	grilhoes do imaculado
21466	aguilhao de ayamiss
21467	couraca silitidea grossa
21468	dragonas de maz nadir
21469	manoplas do vento sul
21470	manto do salvador
21471	garra da concentracao furiosa
21472	turbante sopravento
21473	olho de moam
21474	guarda ombros quitinosos
21475	coxotes do destruidor
21476	perneiras em escamas obsidianas
21477	anel da furia
21478	arco do tendao estirado
21479	manoplas do impassivel
21480	manoplas do silitideo em escamas
21481	botas do protetor do deserto
21482	botas das areias abrasadoras
21483	anel dos ventos do deserto
21484	elmo do recrescimento
21485	fragmento do cranio de buru
21486	luvas do enxame
21487	manoplas em escamas viscosas
21488	fetiche de espinhos quitinosos
21489	galochas da areia movedica
21490	pisantes de visgo
21491	bracadeiras em escamas do engolidor
21492	a degola homens qiraji
21493	botas da vanguarda
21494	cinturao do vento sul
21495	coxotes do comando qiraji
21496	bracadeiras do comando qiraji
21497	botas do general qiraji
21498	adaga sacrifical qiraji
21499	vestimenta das areias cambiantes
21500	cinto da inquisicao
21501	luvas de casca silitidea reforcada
21502	munhequeiras do aniquilador arenoso
21503	cinto do aniquilador arenoso
21504	patua das areias cambiantes
21505	gargantilha das areias cambiantes
21506	pingente das areias cambiantes
21507	amuleto das areias cambiantes
21508	marca de cenarius
21509	suprimentos de guerra em ahn qiraj
21510	suprimentos de guerra em ahn qiraj
21511	suprimentos de guerra em ahn qiraj
21512	suprimentos de guerra em ahn qiraj
21513	suprimentos de guerra em ahn qiraj
21514	instrucoes de logistica xi
21515	marca de remulos
21517	turbante gnomico do poder psiquico
21519	visco
21520	legado dos cristacorvo
21521	espada runica do vermelho
21522	lamento dos cantonegro
21523	presa de korialstrasz
21524	chapeu vermelho de inverno
21525	chapeu verde de inverno
21526	elo das profundezas congelantes
21527	vestes da agua negra
21528	sacola colossal de despojos
21529	amuleto de anteparo sombrio
21530	perneiras engastadas com onix
21531	colar de dente de draco
21532	botas labutadoras
21533	carapaca do colosso de zora
21534	carapaca do colosso de ashi
21535	carapaca do colosso de regia
21536	pedra de eluna
21537	bolinhos do festival
21538	vestido festivo rosa
21539	vestido festivo roxo
21540	lanterna de eluna
21541	conjunto festivo preto
21542	roupa do festival
21543	conjunto festivo ardosia
21544	conjunto festivo azul
21545	suprimento do bosque defumado
21546	elixir de poder de fogo maior
21547	receita elixir de poder de fogo maior
21548	molde luvas do veu da tempestade
21550	monstro arco kaldorei
21552	rabo amarelo listrado
21557	foguete vermelho pequeno
21558	foguete azul pequeno
21559	foguete verde pequeno
21560	foguete roxo pequeno
21561	foguete branco pequeno
21562	foguete amarelo pequeno
21563	elo de dom rodrigo
21565	runa da perfeicao
21566	runa da perfeicao
21567	runa do dever
21568	runa do dever
21569	lancador de fogos de artificio
21570	lancador de salva de fogos de artificio
21571	salva de foguetes azuis
21574	salva de foguetes verdes
21575	salva de foguetes roxos
21576	salva de foguetes vermelhos
21577	salva de foguetes brancos
21578	salva de foguetes amarelos
21579	tentaculo derrotado de c thun
21580	monstro machado de 2m horda jxj
21581	manoplas da aniquilacao
21582	cinturao do deus antigo
21583	manto da clareza
21584	bracadeiras do juizo eterno
21585	manoplas da tempestade negra
21586	cinto da agonia sem fim
21587	munhequeiras do castigo
21588	munhequeiras da furia elemental
21589	foguete azul grande
21590	foguete verde grande
21591	foguete roxo grande
21592	foguete vermelho grande
21593	foguete branco grande
21594	bracadeiras do filho caido
21595	foguete amarelo grande
21596	anel do assassino de deuses
21597	cetro real de vek lor
21598	cinto real qiraji
21599	luvas devastadoras de vek lor
21600	botas da epifania
21601	anel do imperador vek lor
21602	bracadeiras qiraji da execucao
21603	varinha da nobreza qiraji
21604	braceletes da redencao real
21605	luvas do templo oculto
21606	cinto do imperador caido
21607	garra do imperador caido
21608	amuleto de vek nilash
21609	cinto regenerador de vek nilash
21610	bloqueador de escamas de verme
21611	bracadeiras do escavador
21612	pisoteadores de escamas de verme
21613	botas de pele de verme
21614	protetor de pele de verme
21615	chapeu perdido de dom rigoberto
21616	aguilhao de huhuran
21617	manoplas de casca de vespa
21618	munhequeiras do profanador de colmeias
21619	luvas do messias
21620	anel do martir
21621	manto da colmeia dourada
21622	femur silitideo afiado
21623	manoplas do campeao integro
21624	manoplas de kalimdor
21625	broche do escaravelho
21626	perneiras cobertas de visco
21627	manto dos segredos nao revelados
21635	farpa do aniquilador arenoso
21639	brafoneiras do implacavel
21640	caixote de fogos de artificio do festival da lua
21645	botas do escavador de colmeias
21647	fetiche do aniquilador arenoso
21648	botas reconstruidas
21650	antiga estripadora qiraji
21651	perneiras em escamas do aniquilador arenoso
21652	couraca de carapaca silitidea
21663	vestes do santo guardiao
21664	gargantilha farpada
21665	dragonas da revanche perversa
21666	poder de sartura
21667	coxotes da luz fulgurante
21668	perneiras em escamas da furia qiraji
21669	elmo da vinha assustadora
21670	distintivo dos guarda enxames
21671	vestes da guarda de batalha
21672	luvas da coacao
21673	garra silitidea
21674	manoplas da determinacao inabalavel
21675	cinto de escamas qiraji grosso
21676	perneiras do enxame ulceroso
21677	anel da furia qiraji
21678	colar da pureza
21679	revanche de kalimdor
21680	colete da execucao rapida
21681	anel do devorado
21682	manoplas cobertas de bile
21683	dragonas da cruzada do deserto
21684	dragonas da furia do deserto
21685	escaravelho petrificado
21686	dragonas do poder frenico
21687	anel das trevas de ukko
21688	botas do heroi caido
21689	luvas de ebru
21690	patua da angelista
21691	manoplas gosmentas
21692	cinturao triade
21693	mascara do devorador
21694	dragonas ternarias
21695	toque da angelista
21696	vestes do triunvirato
21697	capa da trindade
21698	perneiras da imersao
21699	omoplatas da barragem
21700	pingente do guardiao qiraji
21701	manto do odio concentrado
21702	amuleto da protecao putrida
21703	martelo de ji zhi
21704	botas da profecia cumprida
21705	botas do profeta caido
21706	botas da vontade resoluta
21707	anel do enxame de pensamentos
21708	munhequeiras em escamas do besouro
21709	anel do deus caido
21710	manto do deus caido
21711	convite do festival da lua
21712	amuleto do deus caido
21713	vela de eluna
21714	grande salva de foguetes azuis
21715	martelo polido com areia
21716	grande salva de foguetes verdes
21717	grande salva de foguetes roxos
21718	grande salva de foguetes vermelhos
21719	grande salva de foguetes brancos
21720	grande salva de foguetes amarelos
21721	brilho da lua
21722	molde vestido do festival
21723	molde roupa do festival
21724	diagrama foguete azul pequeno
21725	diagrama foguete verde pequeno
21726	diagrama foguete vermelho pequeno
21727	diagrama foguete azul grande
21728	diagrama foguete verde grande
21729	diagrama foguete vermelho grande
21730	diagrama salva de foguetes azuis
21731	diagrama salva de foguetes verdes
21732	diagrama salva de foguetes vermelhos
21733	diagrama grande salva de foguetes azuis
21734	diagrama grande salva de foguetes verdes
21735	diagrama grande salva de foguetes vermelhos
21736	redeas do grifo de montaria
21737	diagrama lancador de salva de fogos de artificio
21738	diagrama lancador de fogos de artificio
21740	receitas de foguetes pequenos
21741	receitas de foguetes de salva
21742	receitas de foguetes grandes
21743	receitas de foguetes de salva grande
21744	salva de foguetes da sorte
21745	pedra da lua do anciao
21746	envelope vermelho da sorte
21747	bombinha do festival
21749	instrucoes de combate i
21750	instrucoes de combate ii
21751	instrucoes taticas iii
21761	chave da arca do escaravelho
21762	chave maior da arca do escaravelho
21800	lancador encouracado silitideo
21801	tentaculo do fortalecimento
21802	a cris perdida de zedd
21803	elmo do vingador sagrado
21804	coifa da furia elemental
21805	brafoneiras de obsidiana polida
21806	martelete da autoridade qiraji
21809	furia do enxame esquecido
21810	botinas do nomade errante
21812	caixa de bombons
21813	saco de balas
21814	peitoral da aniquilacao
21815	prova de amor
21816	coracao doce
21817	coracao doce
21818	coracao doce
21819	coracao doce
21820	coracao doce
21821	coracao doce
21822	coracao doce
21823	coracao doce
21829	frasco de perfume
21830	embrulho vazio
21831	presente embrulhado
21833	vidro de colonia
21836	anel do caos de ritssyn
21837	martelo de guerra dos anubisath
21838	vestes da ascensao real
21839	cetro do falso profeta
21856	neretzek o sanguinario
21888	luvas do imortal
21889	luvas da profecia cumprida
21890	luvas do profeta caido
21891	fragmento da estrela caida
21920	carta vincada
21921	bilhete cuidadosamente escrito
21925	carta imaculada
21926	bilhete levemente vincado
21928	amostra de sangue de hibernia
21935	ectoplasma estavel
21936	ectoplasma congelado
21937	ectoplasma chamuscado
21938	nucleo de magma
21939	bastao de elemental vil
21946	destilador ectoplasmico
21960	artigos de madeira feitos a mao
21975	jura de adoracao ventobravo
21979	presente de adoracao darnassus
21980	presente de adoracao altaforja
21981	presente de adoracao ventobravo
21982	colar de guerra dos ogros
21983	estandarte incompleto da provocacao
21984	parte esquerda do amuleto do lorde valthalak
21985	recipiente lacrado de sangue
21986	estandarte da provocacao
21987	incendicita de incendius
21988	brasa do mirabrasa
21989	cinza das cinzas
21994	cinto do heroismo
21995	botas do heroismo
21996	bracadeiras do heroismo
21997	peitoral do heroismo
21998	manoplas do heroismo
21999	elmo do heroismo
22000	coxotes do heroismo
22001	espaldares do heroismo
22002	cinto do manto negro
22003	botas do manto negro
22004	bracadeiras do manto negro
22005	casquete do manto negro
22006	luvas do manto negro
22007	calcas do manto negro
22008	espaldares do manto negro
22009	tunica do manto negro
22010	cinto do senhor das feras
22011	braceletes do senhor das feras
22013	casquete do senhor das feras
22014	braseiro santificado
22015	luvas do senhor das feras
22016	dragonas do senhor das feras
22017	calcas do senhor das feras
22046	parte direita do amuleto do lorde valthalak
22047	parte superior do amuleto do lorde valthalak
22048	amuleto do lorde valthalak
22049	braseiro de sinalizacao
22050	braseiro de sinalizacao
22051	braseiro de sinalizacao
22052	braseiro de sinalizacao
22056	braseiro de sinalizacao
22057	braseiro de invocacao
22058	papel de carta de dia dos namorados
22059	cartao de dia dos namorados
22060	tunica do senhor das feras
22061	botas do senhor das feras
22062	cinto do feiticeiro
22063	bracadeiras do feiticeiro
22064	botas do feiticeiro
22065	coroa do feiticeiro
22066	luvas do feiticeiro
22067	perneiras do feiticeiro
22068	dragonas do feiticeiro
22069	vestes do feiticeiro
22070	cinto brumorte
22071	bracadeiras brumorte
22072	perneiras brumorte
22073	dragonas brumorte
22074	mascara brumorte
22075	veste brumorte
22076	sandalias brumorte
22077	guarda bracos brumorte
22078	cinto do virtuoso
22079	bracadeiras do virtuoso
22080	coroa do virtuoso
22081	luvas do virtuoso
22082	dragonas do virtuoso
22083	veste do virtuoso
22084	sandalias do virtuoso
22085	saia do virtuoso
22086	cinto da forja da alma
22087	botas da forja da alma
22088	bracadeiras da forja da alma
22089	peitoral da forja da alma
22090	manoplas da forja da alma
22091	elmo da forja das almas
22092	coxotes da forja da alma
22093	espaldares da forja da alma
22094	algassangue
22095	braceletes dos cinco trovoes
22096	botas dos cinco trovoes
22097	coifa dos cinco trovoes
22098	cordao dos cinco trovoes
22099	manoplas dos cinco trovoes
22100	kilt dos cinco trovoes
22101	brafoneiras dos cinco trovoes
22102	colete dos cinco trovoes
22106	cinto do coracao feral
22107	botas do coracao feral
22108	bracadeiras do coracao feral
22109	capucho do coracao feral
22110	luvas do coracao feral
22111	kilt do coracao feral
22112	espaldares do coracao feral
22113	colete do coracao feral
22114	ovo de murloc rosa
22115	revelador extradimensional de fantasmas
22117	jura de lealdade ventobravo
22119	jura de lealdade altaforja
22120	jura de lealdade darnassus
22121	jura de lealdade cidade baixa
22122	jura de lealdade penhasco do trovao
22123	jura de lealdade orgrimmar
22130	simbolo do amor
22131	colecao de presentes de ventobravo
22132	colecao de presentes de altaforja
22133	colecao de presentes de darnassus
22134	colecao de presentes da cidade baixa
22135	colecao de presentes do penhasco do trovao
22136	colecao de presentes de orgrimmar
22137	algibeira de ysida
22138	bracelete de rocha negra
22139	medalhao de ysida
22140	cartao da sentinela
22141	cartao do guarda de altaforja
22142	cartao do bruto
22143	cartao do guarda de ventobravo
22144	cartao do vigia do penhasco
22145	cartao mofado do guardiao
22149	contas de mojo ogro
22150	contas de poder ogro
22151	agua benta de anthion
22152	bornal do anthion
22154	jura de adoracao altaforja
22155	jura de adoracao darnassus
22156	jura de adoracao orgrimmar
22157	jura de adoracao cidade baixa
22158	jura de adoracao penhasco do trovao
22159	jura de amizade darnassus
22160	jura de amizade altaforja
22161	jura de amizade orgrimmar
22162	jura de amizade penhasco do trovao
22163	jura de amizade cidade baixa
22164	presente de adoracao orgrimmar
22165	presente de adoracao penhasco do trovao
22166	presente de adoracao cidade baixa
22167	presente de amizade darnassus
22168	presente de amizade altaforja
22169	presente de amizade orgrimmar
22170	presente de amizade ventobravo
22171	presente de amizade penhasco do trovao
22172	presente de amizade cidade baixa
22173	cerveja caseira enanica
22174	poesia romantica
22175	torta fresquinha
22176	pao caseiro
22177	flores recem colhidas
22178	jura de amizade ventobravo
22191	tunica de malha de obsidiana
22192	elixir de algassangue de esquiva
22193	elixir de algassangue de resistencia
22194	garra negra do destruidor
22195	cinto leve de obsidiana
22196	peitoral grosso de obsidiana
22197	cinto pesado de obsidiana
22198	escudo serrilhado obsidiano
22200	flecha com haste de prata
22201	relicario da pureza
22202	pequeno estilhaco de obsidiana
22203	grande estilhaco de obsidiana
22204	munhequeiras do renome
22205	braceletes de aco negro
22206	buque de rosas vermelhas
22207	faixa da grande cacada
22208	martelo de litomagma
22209	instrucoes cinto pesado de obsidiana
22212	brafoneiras para golem
22214	instrucoes cinto leve de obsidiana
22216	vesicula de peconha de venoxis
22217	vesicula de peconha de kurinnaxx
22218	punhado de petalas de rosas
22219	instrucoes escudo serrilhado obsidiano
22220	instrucoes garra negra do destruidor
22221	instrucoes tunica de malha de obsidiana
22222	instrucoes peitoral grosso de obsidiana
22223	protetor de cabeca do capataz
22224	essencia de espirito zombeteiro
22225	capucho de pele de dragao
22226	restos mortais druidicos
22227	reliquia do vilarejo brisastral
22228	espada brilhante do fanatismo
22229	cinzas de alma banida
22230	pelego boquiaberto
22231	botas de precisao do kayser
22232	cinturao do atirador perito
22233	bau do zigris
22234	dragonas das esperancas perdidas
22235	flecha com haste de veraprata
22236	delicia de leitelho
22237	desejo negro
22238	creme absoluta fruta
22239	doce surpresa
22240	grevas do desespero paralisante
22241	espaldares do guardador obscuro
22242	coleira de verek
22243	bolsinho de almas
22244	caixa de almas
22245	calcados coberto de cinzas
22246	saco de magitrama encantado
22247	botas do curandeiro da fe
22248	bolsa de runatrama encantada
22249	grande bolsa de encantamentos
22250	bolsa de herborismo
22251	bolsa de herborismo cenariana
22252	algibeira de cenarius
22253	tomo dos perdidos
22254	varinha da luz eterna
22255	elo forjado em magma
22256	mitenes de moldar mana
22257	elo de sangue coagulado
22258	pocao do amor
22259	bracelete da amizade nao concedida
22260	bracelete da amizade
22261	tolo apaixonado
22262	colecao de presentes da alianca
22263	colecao de presentes da horda
22264	carta cuidadosamente escrita
22265	carta escrita com amor
22266	espinho igneo
22267	turbante do tecencantos
22268	emblema draconico infuso
22269	manto do predador das sombras
22270	botas de trincheira
22271	perneiras da magia desenfreada
22272	abraco da floresta
22273	capuz umbraluna
22274	pelagem cinzenta
22275	botas musgo de fogo
22276	vestido vermelho encantador
22277	traje esporte fino vermelho
22278	vestido azul encantador
22279	vestido preto encantador
22280	vestido roxo encantador
22281	traje esporte fino azul
22282	traje esporte fino roxo
22283	saco de pao caseiro
22284	monte de cartoes
22285	colecao de juras a ventobravo
22286	colecao de juras a altaforja
22287	embrulho de cartoes
22288	engradado de cerveja caseira
22289	pilha de cartoes
22290	colecao de juras a darnassus
22291	caixa de artigos de madeira
22292	caixa com tortas fresquinhas
22293	pacote de cartoes
22294	colecao de juras a orgrimmar
22295	mochila de cartoes
22296	cesta de flores
22297	colecao de juras a penhasco do trovao
22298	livro de poesias romanticas
22299	bracada de cartoes
22300	colecao de juras a cidade baixa
22301	veste de tramaferrea
22302	capucho de tramaferrea
22303	calcas de tramaferrea
22304	luvas de tramaferrea
22305	dragonas de tramaferrea
22306	cinto de tramaferrea
22307	molde saco de magitrama encantado
22308	molde bolsa de runatrama encantada
22309	molde grande bolsa de encantamentos
22310	molde bolsa de herborismo cenariana
22311	botas de tramaferrea
22312	molde algibeira de cenarius
22313	bracadeiras de tramaferrea
22314	arpao do guarda caca
22315	martelo da revitalizacao
22317	soqueira do canhoto
22318	arco longo de malgen
22319	tomo do direito divino
22320	mercadorias de qualidade de mux
22321	coracao de wyrmthalak
22322	quebra queixo
22324	ragu de inverno
22325	cinto do trapaceiro
22326	anel do amalgama
22327	amuleto do redimido
22328	coxotes da vigilancia
22329	cetro da concentracao interminavel
22330	mortalha do misterio arcano
22331	anel do heroi resoluto
22332	lamina de necromancia
22333	martelo do poder divino
22334	anel da recomposicao
22335	cajado de comando do senhor valthalak
22336	egide draconiana da legiao
22337	mortalha da dominacao
22338	cinza vulcanica
22339	elo runico da bruxaria
22340	pingente da celeridade
22342	perneiras do tormento
22343	protetores de mao selvagens
22344	braseiro de invocacao manual do usuario
22345	totem de renascimento
22347	repetidor de recarga de fahrad
22348	arruinus prime
22349	peitoral profanado
22350	tunica profanada
22351	veste profanada
22352	coxotes profanados
22353	capacete profanado
22354	brafoneiras profanadas
22355	bracadeiras profanadas
22356	cinta profanada
22357	manoplas profanadas
22358	escarpes profanados
22359	guarda pernas profanado
22360	bacinete profanado
22361	espaldares profanados
22362	munhequeiras profanadas
22363	cinturao profanado
22364	protetores de mao profanados
22365	botas profanadas
22366	perneiras profanadas
22367	diadema profanado
22368	ombreiras profanadas
22369	braceletes profanados
22370	cinto profanado
22371	luvas profanadas
22372	sandalias profanadas
22373	restos de couro
22374	restos de cota de malha
22375	restos de placas
22376	restos de tecido
22377	aticador pau de trovao
22378	fatiadora de corvoforte
22379	lanceta do engrenofaca
22380	martelo de cultivo da simone
22381	amostra de peconha de silithus
22382	recipiente de peconha lacrado
22383	lamina do sabio
22384	persuasor
22385	perneiras titanicas
22386	head of instructor razuvious dep
22387	coracao de anub rekhan
22388	instrucoes perneiras titanicas
22389	instrucoes lamina do sabio
22390	instrucoes persuasor
22392	formula encantamento de agilidade – arma de 2m
22393	codice prece de protecao sombria
22394	cajado da metanoia
22395	totem da raiva
22396	totem da vida
22397	idolo da ferocidade
22398	idolo de rejuvenescimento
22399	idolo da saude
22400	incunabulo da verdade
22401	incunabulo da esperanca
22402	incunabulo da graca
22403	colar de concha iridescente
22404	coca costas do gualter
22405	manto da cruzada escarlate
22406	redencao
22407	elmo da lua nova
22408	varinha de mojo ruim de ritssyn
22409	tunica da lua crescente
22410	manoplas de destreza
22411	elmo do carrasco
22412	dragonas de thuzadin
22416	peitoral couracado
22417	coxotes couracados
22418	capacete couracado
22419	brafoneiras couracadas
22420	escarpes couracados
22421	manoplas couracadas
22422	cinta couracada
22423	bracadeiras couracadas
22424	munhequeiras da redencao
22425	tunica da redencao
22426	protetores de mao da redencao
22427	guarda pernas da redencao
22428	bacinete da redencao
22429	espaldares da redencao
22430	botas da redencao
22431	cinturao da redencao
22432	farpa para demossauro
22433	anel da dominacao de dom mauricio
22434	cogumelo vermelho
22435	ferrao de gorishi
22436	tunica criptalante
22437	guarda pernas criptalantes
22438	bacinete criptalante
22439	espaldares criptalantes
22440	botas criptalantes
22441	protetores de mao criptalantes
22442	cinturao criptalante
22443	munhequeiras criptalantes
22444	trepadeira putrida
22458	baculo umbraluna
22464	tunica quebraterra
22465	guarda pernas quebraterra
22466	bacinete quebraterra
22467	espaldares quebraterra
22468	botas quebraterra
22469	protetores de mao quebraterra
22470	cinturao quebraterra
22471	munhequeiras quebraterra
22472	botas de ferocidade
22476	peitoral ceifa ossos
22477	coxotes ceifa ossos
22478	capacete ceifa ossos
22479	brafoneiras ceifa ossos
22480	escarpes ceifa ossos
22481	manoplas ceifa ossos
22482	cinta ceifa ossos
22483	bracadeiras ceifa ossos
22484	runa necrotica
22488	tunica andassonho
22489	guarda pernas andassonho
22490	bacinete andassonho
22491	espaldares andassonho
22492	botas andassonho
22493	protetores de mao andassonho
22494	cinturao andassonho
22495	munhequeiras andassonho
22496	veste de fogofrio
22497	perneiras de fogofrio
22498	diadema de fogofrio
22499	ombreiras de fogofrio
22500	sandalias de fogofrio
22501	luvas de fogofrio
22502	cinto de fogofrio
22503	braceletes de fogofrio
22504	veste do coracao pestilento
22505	perneiras do coracao pestilento
22506	diadema do coracao pestilento
22507	ombreiras do coracao pestilento
22508	sandalias do coracao pestilento
22509	luvas do coracao pestilento
22510	cinto do coracao pestilento
22511	braceletes do coracao pestilento
22512	veste da fe
22513	perneiras da fe
22514	diadema da fe
22515	ombreiras da fe
22516	sandalias da fe
22517	luvas da fe
22518	cinto da fe
22519	braceletes da fe
22520	o filacterio de kel thuzad
22523	insignia da aurora
22524	insignia da cruzada
22525	pedacos de carnifice da cripta
22526	fragmentos de osso
22527	nucleo dos elementos
22528	sucata de ferro negro
22529	fronde selvagem
22568	escritura do artifice
22589	atiesh grande cajado do guardiao
22593	salvo conduto
22595	anuncio do chamado as armas
22600	escritura do artifice – contrapeso denso
22601	escritura do artifice – peitoral de placa imperial
22602	escritura do artifice – martelo vulcanico
22603	escritura do artifice – machado de batalha de torio enorme
22604	escritura do artifice – diadema radiante
22605	escritura do artifice – bandana de couro malefico
22606	escritura do artifice – kit de armadura rustica
22607	escritura do artifice – cinto de couro malefico
22608	escritura do artifice – calcas de couro runico
22609	escritura do artifice – calcas de lumetrama
22610	escritura do artifice – botas de runatrama
22611	escritura do artifice – bolsa de runatrama
22612	escritura do artifice – veste de runatrama
22613	escritura do artifice – carga sapadora goblinica
22614	escritura do artifice – granada de torio
22615	escritura do artifice – frango de batalha gnomico
22616	escritura do artifice – tubo de torio
22617	escritura do artifice – pocao elevada de mana
22618	escritura do artifice – pocao elevada de cura
22619	escritura do artifice – pocao maior de protecao contra o gelo
22620	escritura do artifice – pocao maior de protecao contra o arcano
22621	escritura do artesao frasco de petrificacao
22622	escritura do artifice – enguia petrescama
22623	escritura do artifice – peixe armadura de placas
22624	escritura do artifice – enguia eletrica
22625	escritura do artifice – salmao assado
22626	escritura do artifice – escondidinho de batata ratapla
22630	atiesh grande cajado do guardiao
22631	atiesh grande cajado do guardiao
22632	atiesh grande cajado do guardiao
22635	guarda selvagem
22636	guardafria
22637	idolo hakkari primevo
22638	guardassombra
22648	dossie de colme ashi
22649	dossie de colme regia
22650	dossie de colme zora
22651	guarda pernas de placa do pioneiro
22652	colete glacial
22654	luvas glaciais
22655	pulsos glaciais
22656	o purificador
22657	amuleto da aurora
22658	manto glacial
22659	medalhao da aurora
22660	abraco de gaia
22661	tunica polar
22662	luvas polares
22663	bracadeiras polares
22664	peitoral de escama gelada
22665	bracadeiras de escama gelada
22666	manoplas de escama gelada
22667	bracadeiras da esperanca
22668	braceleiras do subterfugio
22669	peitoral da perdicao gelida
22670	manoplas da perdicao gelida
22671	bracadeiras da perdicao gelida
22672	guarda pernas de placa da sentinela
22673	perneiras encadeadas do pioneiro
22676	perneiras de malha do pioneiro
22678	talisma da ascendencia
22679	sacola de suprimentos
22680	elo da resolucao
22681	elo da devocao
22682	runa congelada
22683	molde abraco de gaia
22684	molde luvas glaciais
22685	molde manto glacial
22686	molde colete glacial
22687	molde pulsos glaciais
22688	ultimo recurso de verimonde
22689	elmo santificado de couro
22690	perneiras do cacador de pestes
22691	a crematoria corrompida
22692	molde tunica polar
22694	molde luvas polares
22695	molde bracadeiras polares
22696	molde peitoral de escama gelada
22697	molde manoplas de escama gelada
22698	molde bracadeiras de escama gelada
22699	perneiras da perdicao gelida
22700	perneiras glaciais
22701	perneiras polares
22702	perneiras de escama gelada
22703	instrucoes peitoral da perdicao gelida
22704	instrucoes manoplas da perdicao gelida
22705	instrucoes bracadeiras da perdicao gelida
22707	toque frio de ramaladni
22708	destino de ramaladni
22711	manto dos adoradores hakkari
22712	poder da tribo
22713	cetro ritual zulian
22714	manoplas sacrificais
22715	luvas do atormentado
22716	cinto do poder libertado
22718	mascara ensanguentada
22719	manual de omarion
22720	turbante zulian
22721	anel de servidao
22722	selo do berserker gurubashi
22723	uma carta do guardiao dos pergaminhos
22725	anel de cenarius
22726	lasca de atiesh
22727	cajado de atiesh
22728	controlador de tonque a vapor
22729	diagrama controlador de tonque a vapor
22730	cordao de cintura do olho furtivo
22731	manto dos devorados
22732	marca de c thun
22733	ponta do cajado de atiesh
22734	base de atiesh
22736	andonisus ceifador de almas
22737	atiesh grande cajado do guardiao
22739	tomo do polimorfo tartaruga
22740	calcas de couro do pioneiro
22741	calcas de couro de lagarto do pioneiro
22742	camisa vela sangrenta
22743	faixa vela sangrenta
22744	botas vela sangrenta
22745	calcas vela sangrenta
22746	uniforme de bucaneiro
22747	perneiras de seda do pioneiro
22748	perneiras encadeadas da sentinela
22749	calcas de couro da sentinela
22750	calcas de couro de lagarto da sentinela
22752	perneiras de seda da sentinela
22753	guarda pernas lamelares da sentinela
22754	quintessencia eterna
22756	colete silvestre
22757	coroa silvestre
22758	omoplatas silvestres
22759	elmo de sarca
22760	botas de sarca
22761	cinto de sarca
22762	peitoral vinaferro
22763	luvas vinaferro
22764	cinto vinaferro
22765	carta desbotada
22766	instrucoes peitoral vinaferro
22767	instrucoes luvas vinaferro
22768	instrucoes cinto vinaferro
22769	molde cinto de sarca
22770	molde botas de sarca
22771	molde elmo de sarca
22772	molde omoplatas silvestres
22773	molde coroa silvestre
22774	molde colete silvestre
22780	ovo de murloc branco
22781	coleira do urso polar
22798	poder de menethil
22799	cacador de almas
22800	cajado sulfureo
22801	cajado do crepusculo
22802	queda do monarca
22803	bruma da meia noite
22804	presa de maexxna
22806	remorso da viuva
22807	lamina espectral
22808	o castigador
22809	malho do cruzado redimido
22810	injetor de toxinas
22811	cordao das almas
22812	escravizador nerubiano
22813	espadao do poder profano
22815	ruptura
22816	machadinha de osso partido
22818	o portador da peste
22819	escudo da condenacao
22820	varinha do destino
22821	dedo do destino
22822	icoke prize voucher
22843	grevas encadeadas do guarda de sangue
22852	botinas de couro de dragao do guarda de sangue
22855	chancas de medotrama do guarda de sangue
22856	chancas de couro do guarda de sangue
22857	grevas de malha do guarda de sangue
22858	grevas de placa do guarda de sangue
22859	chancas de cetim do guarda de sangue
22860	chancas de seda do guarda de sangue
22862	luvas encadeadas do guarda de sangue
22863	guantes de couro de dragao do guarda de sangue
22864	guantes de couro do guarda de sangue
22865	mitenes de medotrama do guarda de sangue
22867	luvas de malha do guarda de sangue
22868	manoplas de placa do guarda de sangue
22869	mitenes de cetim do guarda de sangue
22870	mitenes de seda do guarda de sangue
22872	cota de placa do legionario
22873	perneiras de placa do legionario
22874	cota encadeada do legionario
22875	guarda pernas encadeados do legionario
22876	cota de malha do legionario
22877	peito d armas de couro de dragao do legionario
22878	perneiras de couro de dragao do legionario
22879	peito d armas de couro do legionario
22880	guarda pernas de couro do legionario
22881	guarda pernas de medotrama do legionario
22882	guarda pernas de cetim do legionario
22883	guarda pernas de seda do legionario
22884	tunica de medotrama do legionario
22885	tunica de cetim do legionario
22886	tunica de seda do legionario
22887	guarda pernas de malha do legionario
22890	tomo de protecao contra gelo v
22891	grimorio de protecao contra sombras iv
22892	pedra necrotica opaca
22895	rocambole de canela conjurado
22897	tomo de conjurar comida vii
22930	envelope manchado de sangue
22932	carta rasgada
22935	toque de gelo
22936	munhequeiras da vinganca
22937	gema de nerubis
22938	manto de seda de carnifice da cripta
22939	elo das preces nao atendidas
22940	brafoneiras da perdicao gelida
22941	espaldares polares
22942	o abraco da viuva
22943	pingente de pedra da malicia
22944	missiva amassada
22945	bilhete aflito
22946	uma pagina desalinhada
22947	pingente dos nomes esquecidos
22948	um documento borrado
22949	cristal necrotico rachado
22950	cristal necrotico fugaz
22954	beijo da aranha
22960	manto de sutura
22961	elo de reanimacao
22967	espaldares de escama gelada
22968	dragonas glaciais
22970	envelope manchado de sangue
22972	bilhete aflito
22973	missiva amassada
22974	uma pagina desalinhada
22975	um documento borrado
22977	carta rasgada
22981	coleira perdida do gluth
22983	dragonas cobertas de geada
22988	o fim dos sonhos
22994	mao consumida do poder
22999	tabardo da aurora argentea
23000	condrios de placas da abominacao
23001	olho da diminuicao
23002	caixa de tartaruga
23004	idolo da longevidade
23005	totem da agua corrente
23006	incunabulo da luz
23007	coleira do leitao
23008	relatorio de pesquisa lacrado
23009	varinha dos mortos sussurrantes
23010	relatorio de pesquisa lacrado
23011	relatorio de pesquisa lacrado
23012	relatorio de pesquisa lacrado
23013	relatorio de pesquisa lacrado
23014	iblis lamina do serafim caido
23015	jaula de rato
23016	relatorio de pesquisa lacrado
23017	veu do eclipse
23018	sinete do defensor caido
23019	capacete da perdicao gelida
23020	capacete polar
23021	bracadeiras do ceifador de almas
23022	recompensa do rabugento
23023	coleira do sadico
23024	papeis preparados de servico em campanha
23025	selo do maldito
23027	cordialidade do perdao
23028	elo de granizo
23029	coracao frigido de noth
23030	manto do flagelo
23031	anel do inevitavel
23032	diadema glacial
23033	coifa de escama gelada
23034	nax ph crit plate shoulders
23035	chapeu do preceptor
23036	colar da necropsia
23037	anel do fervor espiritual
23038	elo das forcas sobrenaturais
23039	o olho de nerub
23040	glifo de deflexao
23041	escudo do matador
23042	reflexao de repugnaz
23043	a face da morte
23044	emissario da destruicao
23045	mortalha de dominio
23046	a essencia contida de sapphiron
23047	olho dos mortos
23048	olho direito do sapphiron
23049	olho esquerdo do sapphiron
23050	manto da necropole
23053	talisma da ebulicao de tempesfuria
23054	gressil o despertar da decadencia
23055	palavra do degelo
23056	martelo de espiral eterea
23057	gema dos inocentes encurralados
23058	colar da canalizacao de vida
23059	anel couracado
23060	anel ceifa ossos
23061	anel da fe
23062	anel de fogofrio
23063	anel do coracao pestilento
23064	anel andassonho
23065	anel quebraterra
23066	anel da redencao
23067	anel criptalante
23068	coxotes da chacina
23069	traje do necro cavaleiro
23070	perneiras da polaridade
23071	perneiras do apocalipse
23072	brafoneiras do implacavel
23073	botas do deslocamento
23075	oferta da morte
23078	manoplas de matar mortos vivos
23081	mitenes de matar mortos vivos
23082	protetores de mao de matar mortos vivos
23083	chama capturada
23084	luvas da purificacao de mortos vivos
23085	veste da purificacao de mortos vivos
23087	peitoral de matar mortos vivos
23088	couraca de matar mortos vivos
23089	tunica de matar mortos vivos
23090	bracadeiras de matar mortos vivos
23091	bracadeiras da purificacao de mortos vivos
23092	bracadeiras de matar mortos vivos
23093	munhequeiras de matar mortos vivos
23122	pedra de afiar consagrada
23123	oleo abencoado de teurgo
23124	cajado de balzaphon
23125	correntes do lich
23126	cintel de balzaphon
23127	manto de revanchion
23128	soqueira da sombra
23129	bracadeiras de recomposicao
23132	lamina do lorde umbraxilos
23139	broquel do lorde umbraxilos
23156	coxa do umbraxilos
23160	pao da amizade
23161	limonada fresquinha
23162	bolsa grandona
23163	performer s wand
23164	bubbly beverage
23168	adaga focal de escarne
23169	gargantilha gelida de escarne
23170	a garra gelida
23171	o machado de decepar
23172	refreshing red apple
23173	perneiras de pele de abominacao
23175	tasty summer treat
23176	fizzy energy drink
23177	varinha da lady falther essa
23178	dragonas da lady falther ess
23179	chama de orgrimmar
23180	chama do penhasco do trovao
23181	chama da cidade baixa
23182	chama de ventobravo
23183	chama de altaforja
23184	chama de darnassus
23192	tabardo da cruzada escarlate
23193	redeas do corcel descarnado
23194	marca inferior da aurora
23195	marca da aurora
23196	marca maior da aurora
23197	idolo da lua
23198	idolo de brutalidade
23199	totem de tempestade
23200	totem de sustentacao
23201	incunabulo da divindade
23203	incunabulo do fervor
23206	marca do campeao
23207	marca do campeao
23211	orcmellow tostado
23215	saco de ingredientes de orcmellow
23219	cinturao do mentor
23220	veste tecida com cristais
23221	braco perdido do servo
23224	summer gift package
23226	tunica de pele de carnical
23227	icoke gift box voucher
23237	anel da chama eterna
23238	broquel estigio
23242	garra da serpe gelida
23243	omoplatas de placa do campeao
23244	elmo de placa do campeao
23246	bebida fogosa do festival
23247	flor de fogo
23250	concha prismatica
23251	elmo encadeado do campeao
23252	omoplatas encadeadas do campeao
23253	cimeira de couro de dragao do campeao
23254	omoplatas de couro de dragao do campeao
23255	capucho de medotrama do campeao
23256	espaldares de medotrama do campeao
23257	elmo de couro do campeao
23258	omoplatas de couro do campeao
23259	cimeira de malha do campeao
23260	brafoneiras de malha do campeao
23261	capuz de cetim do campeao
23262	dragonas de cetim do campeao
23263	capucho de seda do campeao
23264	dragonas de seda do campeao
23272	peitoral lamelar do capitao cavaleiro
23273	perneiras lamelares do capitao cavaleiro
23274	manoplas lamelares do tenente cavaleiro
23275	escarpes lamelares do tenente cavaleiro
23276	cimeira lamelar do tenente comandante
23277	omoplatas lamelares do tenente comandante
23278	grevas encadeadas do tenente cavaleiro
23279	munhequeiras encadeadas do tenente cavaleiro
23280	guantes de couro de dragao do tenente cavaleiro
23281	botinas de couro de dragao do tenente cavaleiro
23282	mitenes de medotrama do tenente cavaleiro
23283	chancas de couro do tenente cavaleiro
23284	guantes de couro do tenente cavaleiro
23285	chancas de couro do tenente cavaleiro
23286	manoplas de placa do tenente cavaleiro
23287	grevas de placa do tenente cavaleiro
23288	mitenes de cetim do tenente cavaleiro
23289	chancas de cetim do tenente cavaleiro
23290	mitenes de seda do tenente cavaleiro
23291	chancas de seda do tenente cavaleiro
23292	cota encadeada do capitao cavaleiro
23293	guarda pernas encadeadas do capitao cavaleiro
23294	peito d armas de couro de dragao do capitao cavaleiro
23295	perneiras de couro de dragao do capitao cavaleiro
23296	guarda pernas de medotrama do capitao cavaleiro
23297	tunica de medotrama do capitao cavaleiro
23298	peito d armas de couro do capitao cavaleiro
23299	guarda pernas de couro do capitao cavaleiro
23300	cota de placa do capitao cavaleiro
23301	perneiras de placa do capitao cavaleiro
23302	guarda pernas de cetim do capitao cavaleiro
23303	tunica de cetim do capitao cavaleiro
23304	guarda pernas de seda do capitao cavaleiro
23305	tunica de seda do capitao cavaleiro
23306	elmo encadeado do tenente comandante
23307	omoplatas encadeadas do tenente comandante
23308	cimeira de couro de dragao do tenente comandante
23309	omoplatas de couro de dragao do tenente comandante
23310	capucho de medotrama do tenente comandante
23311	espaldares de medotrama do tenente comandante
23312	elmo de couro do tenente comandante
23313	omoplatas de couro do tenente comandante
23314	elmo de placa do tenente comandante
23315	omoplatas de placa do tenente comandante
23316	capuz de cetim do tenente comandante
23317	dragonas de cetim do tenente comandante
23318	capucho de seda do tenente comandante
23319	dragonas de seda do tenente comandante
23320	tabuleta de choque flamejante vi
23323	coroa do festival do fogo
23324	dragonas do festival do fogo
23326	linguica do solsticio
23327	pao doce tostado no fogo
23360	cabeca do instrutor razuvio
23379	braceletes do elemental de brasas
23435	torta de sabugo
23451	magespada do grao marechal
23452	tomo de poder do grao marechal
23453	tomo de restauracao do grao marechal
23454	martelo de guerra do grao marechal
23455	demolidor do grao marechal
23456	lamina celere do grao marechal
23464	maca de batalha do sumo senhor da guerra
23465	destruidor do sumo senhor da guerra
23466	lamina enfeiticada do sumo senhor da guerra
23467	gumepresto do sumo senhor da guerra
23468	tomo de destruicao do sumo senhor da guerra
23469	tomo de recomposicao do sumo senhor da guerra
23545	poder do flagelo
23547	resiliencia do flagelo
23548	poder do flagelo
23549	fortitude do flagelo
23557	larva do grande verme
23558	a carapaca do escavador
23570	jom gabbar
23577	o frio voraz
23578	macmolhofraco dietetico
23579	o classico macmolhofraco
23656	item de teste promocional
23663	cinturao da furia elemental
23664	brafoneiras da furia elemental
23665	perneiras de furia elemental
23666	cinto do grande cruzado
23667	espaldares do grande cruzado
23668	perneiras do grande cruzado
23683	pastilha de lasca de cristal
23684	bandagem infusa com cristal
23689	manual bandagem infusa com cristal
23690	receita pastilha de lasca de cristal
23705	tabardo das chamas
23709	tabardo de gelo
23710	tabardo nº 3 do conves superior
23712	cria de tigre branco
23713	filhote de hipogrifo
23714	fogos de artificio roxos perpetuos
23715	coquetel de sumo de pulmao permanente
23716	idolo de ogro entalhado
23718	amostra de escorpode macerado permanente
23719	composto de cortex cerebral permanente
23720	tartaruga de montaria
23721	chiclete de moela permanente
23722	b o m b a permanente
23794	reflexo de zanza inesgotavel
23795	espirito de zanza permanente
23796	rapidez de zanza permanente
24071	adaga branda
24101	livro de mordida feroz v
24102	manual de eviscerar ix
24222	o apunhalador pe sombrio
24231	rape ordinario
24232	no ordinario
24281	marfim entalhado
24282	diario do ladino
24283	pistola antiga
122270	ficha de wow
122284	ficha de wow
172070	pacote do atendimento ao cliente
180089	coleira do panda
184937	deslocador dadiva do tempo
184938	deslocador dadiva do tempo supercarregado
189419	fire resist plate gear
189420	fire resist plate gear
189421	fire resist leather gear
189426	raid consumables
189427	more raid consumables
190179	coracao de avelina
190180	coracao de isaac
190181	coracoes dos amantes
190186	estatueta de madeira
190187	lenco fenecido
190232	lenco fenecido
190307	tocha apagada
190308	tocha acesa
190309	estatueta de madeira
190325	monstro incubo chicote maca 1m
191204	pedra mortal menor
191249	pedra mortal maior
191267	runa de teleporte antecamara
191268	orbe da corrupcao
191272	bastao da necromancia
191280	aglomerado de esporos fungicos
191288	runa de teleporte covil da serpe gelida
191292	adaga ritualistica
191312	filacterio infalivel
191313	mascara da morte
191414	artefato esqueletal
191458	filacterio estilhacado
191459	runa da fortuna
191477	poste de amarrar esqueletal
191480	corcel descarnado
191481	tabardo da maestria
191550	livro das pedras mortais mascara da morte
191605	livro das pedras mortais runa de teleporte i
191606	livro das pedras mortais orbe da corrupcao
191607	livro das pedras mortais artefato esqueletal
191608	livro das pedras mortais bastao da necromancia
191609	livro das pedras mortais aglomerado de esporos fungicos
191610	livro das pedras mortais adaga ritualistica
191611	livro das pedras mortais filacterio infalivel
191612	livro das pedras mortais runa de teleporte ii
191613	livro das pedras mortais runa da fortuna
191614	livro das pedras mortais poste de amarrar esqueletal
191656	essencia da morte
191660	raios de thaddius
191661	presa de aranha monstruosa
191664	livro das pedras mortais raios de thaddius
191666	livro das pedras mortais presa de aranha monstruosa
202251	saco de guloseimas para ajudantes
202254	bracadeiras do redirecionamento
202256	pistola ornada do corsario
202641	caderno coberto de lama
203723	bilhete do picote
203726	runa do picote
203745	anotacoes de feiticos lanca de gelo
203746	anotacoes de feiticos chama viva
203747	anotacoes de feiticos dedos glaciais
203748	anotacoes de feiticos combustao
203749	anotacoes de feiticos esclarecimento
203750	mapa do tesouro de elwynn
203751	anotacoes de feiticos aleg den acol
203752	anotacoes de feiticos vacma ihav
203753	anotacoes de feiticos colesdi dasgai
203754	arquimago antonidas a biografia completa
203755	diario de pesquisa do arquimago teocrito
203756	notas do aprendiz de azora pagina 1
203784	pedaco do canto direito superior do mapa
203785	pedaco do canto esquerdo superior do mapa
203786	pedaco do canto direito inferior do mapa
203787	pedaco do canto esquerdo inferior do mapa
203960	notas do aprendiz de azora pagina 2
203961	notas do aprendiz de azora pagina 3
203962	notas do aprendiz de azora pagina 4
203990	runa da mutilacao
203991	runa de saque rapido
203992	runa dos ardis
203993	runa do massacre
203994	runa da mistura mortifera
204174	runa da precisao
204270	nucleo das profundezas
204441	runa do frenesi de sangue
204476	cabeca de kobold decepada
204477	cabeca de murloc decepada
204478	cabeca de gnoll decepada
204688	primeiro fragmento da runa do cacador de monstros
204689	segundo fragmento da runa do cacador de monstros
204690	terceiro fragmento da runa do cacador de monstros
204703	runa de devastar
204716	runa do ataque frenetico
204795	runa do golpe sombrio
204804	braceletes hidraxianos
204806	runa do impeto da vitoria
204807	lamina das profundezas
204809	runa do trovao furioso
204864	notas do aprendiz de azora
204905	tomo agourento
204906	sangue de gnoll
204907	mandibula de lobo
204910	monstro tridente naga ouro
204912	runa da graca
205019	estilhaco de alma maculado
205020	estilhaco de alma puro
205022	runa do sifao da alma
205181	artefato nao identificado
205182	artefato sem poderes
205183	artefato movido a vileza
205184	nota do acolito
205215	runa da tatica
205218	incunabulo da descoberta
205228	runa da seta do caos
205230	runa da assombracao
205364	mochila do acolito
205420	incunabulo do julgamento
205683	runa de repreensao
205685	runa de egide
205863	incunabulo corrompido
205864	bilhete calcinado
205897	runa da luz divina
205905	memoria de um campeao devoto
205932	profecia do obito de um rei
205940	memoria de um proposito sombrio
205942	epifania quimerica
205943	profecia de uma cidadela profanada
205944	epifania reciproca
205945	memoria de um salvador aprisionado
205946	memoria da traicao de um lider
205947	profecia de uma cidadela profanada
205948	epifania anodina
205949	epifania multipla
205950	epifania tenebrosa
205951	memoria de um acolito conturbado
205952	memoria de um mundo despedacado
205953	profecia de um voto quebrado
205961	carne de passaro de mulgore
205979	runa de flanqueamento
205995	almiscar de cao da pradaria
206032	runa de trinchar
206155	runa de atirador de precisao
206157	carga de mineracao de cequatrum
206159	disfarce da empreendimentos s a
206168	runa da quimera
206169	runa de tiro explosivo
206170	cone de furia dos ventos
206175	unguento de pinhao
206176	almofariz e pilao
206177	manteiga de pinhao
206264	runa de inspiracao
206344	jogo de facas
206345	pedacos de peixe
206376	icone do baluarte
206381	icone diadico
206382	icone tempestuoso
206383	icone litico
206384	icone astral
206385	icone clastico
206386	icone galvanico
206387	icone kajarico
206388	icone sulfureo
206389	icone de enxofre
206390	icone ictio
206391	icone sizigico
206466	coroa da pradaria
206469	flor da pradaria
206954	idolo de raiva ursina
206963	runa do potencial natural
206966	bulbo de satiridea
206970	runa da vida
206975	chave do deposito de artefatos
206985	eco do alfa
206989	runa do sol
206992	runa de esmagar cranio
206994	cabeca de javatusco decepada
206995	cabeca de harpia decepada
207062	cabeca de centauro decepada
207098	bilhete de ba so
207106	pedaco do canto esquerdo inferior do mapa
207107	pedaco do canto direito inferior do mapa
207108	pedaco do canto esquerdo superior do mapa
207109	pedaco do canto direito superior do mapa
207110	mapa do tesouro de durotar
207590	carne de porco de durotar
207631	feromonio de aspide
207731	tomo agourento
207732	perna de makrura
207733	cranio kultireno
207972	as licoes de ta zo
207973	mandibula de canaz
207974	tomo agourento
207975	cabeca de morcego decepada
208005	chave da arca de reliquias dos agamand
208007	chave do bau do naufragio
208034	mapa do tesouro de tirisfal
208035	pedaco do canto direito superior do mapa
208036	pedaco do canto esquerdo superior do mapa
208037	pedaco do canto direito inferior do mapa
208038	pedaco do canto esquerdo inferior do mapa
208085	anel sinete do tenente escarlate
208086	memorando escarlate forjado
208139	tomo agourento
208140	sangue de wendigo
208158	coracao de trogg imaculado
208159	cabeca de troll decepada
208160	pata de wendigo decepada
208180	almiscar de coelho
208183	notas de boticario
208185	a cartilha metafisica do boticario
208192	carne de porco de dun morogh
208196	anel de moa kin
208205	anotacao de raturno
208213	pedaco do canto direito superior do mapa
208215	pedaco do canto esquerdo superior do mapa
208218	pedaco do canto direito inferior do mapa
208219	pedaco do canto esquerdo inferior do mapa
208220	mapa do tesouro de dun morogh
208222	retaliador da velha guarda
208223	mochila do acolito
208224	nota do acolito
208414	idolo lunar
208425	vestigio arcaico brilhoso
208484	luz do sol
208601	pedaco do canto direito superior do mapa
208602	pedaco do canto esquerdo superior do mapa
208603	pedaco do canto direito inferior do mapa
208604	pedaco do canto esquerdo inferior do mapa
208605	mapa do tesouro de teldrassil
208607	almiscar de cervo
208608	carne de ave de teldrassil
208609	flor da clareira
208610	cabeca de tigre decepada
208611	cabeca de tigre decepada
208612	cabeca de aranha decepada
208682	ovo de mordelisca abandonado
208687	runa de lacerar
208689	idolo feroz
208701	runa de dominio das feras
208739	estandarte de guerra da horda
208741	runa de raiva infinita
208743	alma de ganancia
208744	runa de setas sombrias
208749	chave do estoque de masca pinho
208750	runa de canalizacao
208753	anotacoes de feiticos regeneracao
208754	anotacoes de feiticos recao ernage
208758	runa terrana
208760	coroa da clareira
208764	runa da mente
208765	mao amiga
208766	mao amiga
208767	runa de recomposicao
208768	caixa de fosforos dos bucaneiros
208771	runa de danca de laminas
208772	runa de talho de sabre
208773	arpao de pesca
208777	runa do franco atirador
208778	runa de golpe rapido
208799	anotacoes de feiticos bomba viva
208800	baxtan sobre magias destrutivas
208823	moeda de oferenda
208828	memoria de um voto quebrado
208833	torta malevolente
208838	cofre de ferro negro
208843	totem de batalha
208847	geodo de caveira
208848	geodo de caveira rachado
208849	incunabulo das bencaos
208851	incunabulo de justica
208853	anotacoes de feiticos congelamento cerebral
208854	anotacoes de feiticos mastigadas
208855	isca de albacora arco iris
208860	rumi de gnomeregan trabalhos reunidos
209027	petiscos de caranguejo
209028	anotacoes de feiticos ibamb vova
209029	mensagem de emily
209030	chave do estoque de equipamentos
209031	envelope discreto
209041	sementes de abobora magicas
209042	farinha de osso de peixe
209043	amostra de solo fertil
209045	alma do mar
209047	arpao nodoso
209056	pecas sobressalentes do ceifador
209057	prototipo de engenho
209058	nucleo de elemental
209059	pernil de goretusco
209418	armadura de tartaruga adamantina
209420	bate guelra
209421	cordao de aquanis
209422	gargantilha de mare alta
209423	lenco esvoacante
209424	barreira de placa de carapaca
209432	cilha de ghamoo ra
209436	dentada de serra kis lascada
209523	capa do trilhador cintilante
209524	amarras de serra kis
209525	talwar aguanegra aprimorado
209527	manoplas da batalha das nagas
209534	arcobalista de azshari
209559	bengala do sabio do crepusculo
209560	julgamento do martelo da retidao
209561	bastao do sonambulo ancestral
209562	golpe da hidra mortal
209563	rompe coracao das nagas
209564	tridente do guardiao
209565	anel de lugares profundos
209566	perneiras do fiel
209567	machado do recife de coral
209568	manoplas de algas
209569	botas altas de pelego de murloc
209570	tomo da historia da caverna
209571	luz morta
209572	couros cozidos pretos
209573	pinaculo furioso
209574	preceitos descartados do punho de prata
209575	icone de madeira entalhada
209576	cogumelo da expansao mental
209577	punho do indomado
209578	embraces de couro faiscante
209579	trovao estrondoso
209580	vento tempestuoso
209581	escarpes de punho de prata
209590	globo d agua rachado
209608	chave mestra do capitao
209611	insignia da alianca
209612	insignia da alianca
209613	insignia da alianca
209614	insignia da alianca
209615	insignia da alianca
209616	insignia da alianca
209617	insignia da alianca
209618	insignia da alianca
209619	insignia da horda
209620	insignia da horda
209621	insignia da horda
209622	insignia da horda
209623	insignia da horda
209624	insignia da horda
209625	insignia da horda
209626	insignia da horda
209667	perneiras do vislumbrador
209668	sinete do lorde do crepusculo
209669	sapatos do invocador do crepusculo
209670	pisantes de pele
209671	vestes do invocador do crepusculo
209672	luvas sem dedos pretas
209673	amuleto de fetiche chamejante
209674	ignicao da fenix
209675	tunica de tramaconcha
209676	guarda ombros de profundezas esmagadoras
209677	aro de correntes rapidas
209678	manto do assassino de manguais
209679	ombreiras da novica azshari
209680	lenco a prova d agua
209681	ovo de murloc preto
209682	capuz resistente
209683	xale do invocador do crepusculo
209684	calcas da sanguessuga de alma
209685	cilha de musgo antiga
209686	colar de osso serrilhado
209687	couraca de pele de hidra
209688	bacamarte de bael modan
209689	galochas de cascoguejo
209690	coifa de trevescama
209691	faca de bota vampirica
209692	brafoneiras da sentinela
209693	perola das profundezas negras perfeita
209694	adaga ritual das profundezas negras
209748	orbe de althalaxx
209778	sal do evocador
209779	particula de mannoroth
209800	fragmentos de orbe
209816	fetiche de traquinagem
209817	broche do emissario do caos
209818	crescente tocado pelo sol
209819	varinha de domar manticora
209820	gargantilha de mortalha negra
209821	anel do mirante negro
209822	forca do proposito
209823	sinete de feras
209824	ombreiras cintilantes
209825	gargantilha de gotinha
209828	brafoneiras subzero
209830	arcobalista de couro de ferro
209836	orbe de althalaxx
209838	cristal hipnotico
209840	varinha nodosa de magia selvagem
209841	essencia de magia selvagem
209843	almanaque de nar thalas vol 74
209844	o resumo de dalaran vol 23
209845	encantamentos e glamours
209846	segredos dos sonhadores
209847	manual de sistemas arcanicos
209848	pergaminhos de goaz
209849	crimes contra a anatomia
209850	runas dos reis feiticeiros
209851	furia da terra
209852	runa de comando para matar
209872	elmo do mata dragoes
209873	escudo do mata dragoes
209874	lanca do mata dragoes
210015	runa de golpe furioso
210026	simbolo da terceira coruja
210043	simbolo da segunda coruja
210044	simbolo da primeira coruja
210045	folhumbra
210053	pata de lobo hediondo
210055	ossos humanos de eira dos montes
210056	tintura da morte desperta
210080	oferenda vodu
210137	runa do crescimento silvestre
210138	artilharia dos ferro negro
210146	turbocompressor de retalhador
210147	unidade retalhadora autorrecuperavel
210177	ataeric sobre curiosidades arcanas
210178	diagrama unidade retalhadora autorrecuperavel
210179	anotacoes de feiticos vedasi si lessam
210183	trompa de xelthos
210186	carga de transposicao
210187	ordem de servico da empreendimentos s a
210188	ordem de servico triturada
210195	idolo desequilibrado
210209	chave gemea
210210	certificado de fundacao das industrias de defesa grizzutil
210212	metade de chave do irmao
210213	metade de chave da irma
210229	runa da mutilacao
210250	anel de ouro gravado
210251	anel de prata gravado
210252	runa da estocada
210253	totem de podridao
210322	runa de peconha
210323	combinacao do cofre
210329	mapa do tesouro de eira dos montes
210330	dica quente
210410	isca de tartalisca de agua doce
210499	charcomelo
210500	runa das estrelas
210534	idolo do selvagem
210568	filacterio decrepito
210569	runa de flagelacao
210573	runa de raiva debilitante
210589	eco dos antepassados
210596	runa de golpes de naja
210653	runa de adaga de bloqueio
210654	anotacoes de feiticos retroceder tempo
210655	anotacoes de feiticos depomectre retro
210665	granulo de raiva torrencial
210667	granulo de raiva infernal
210668	granulo de raiva sismica
210696	ruina dos putridos
210708	elixir do arrependimento coalescido
210709	receita elixir do arrependimento coalescido
210712	elixir da percepcao
210713	alma torturada
210724	cajado de hirzek
210741	espanca gente automatico
210746	runa de escudo da terra
210763	ramo de altek
210765	orbe de des
210771	suprimentos escondidos barras de cobre
210772	carga de suprimentos barras de cobre
210773	dragonas da segunda guerra
210779	instrucoes dragonas da segunda guerra
210781	braceletes da fenix
210794	peitoral de prata cambiante
210795	botas de sedaracna extraplanares
210811	runa da furia primordial
210817	runa da sobrevivencia
210818	runa do lobo solitario
210820	runa do sacrificio
210822	epifania harmoniosa
210823	runa de especializacao em duas armas
210824	runa do pacto
210825	runa do armipotente
210953	olho de bhossca
210955	uniforme de iniciado escarlate
210963	chave dos augures
210966	sangue da legiao
210967	mensagem confidencial
210968	chave do relicario
210979	runa do passo furtivo
210980	runa da metamorfose
211205	runa do exterminador de najas
211247	molde braceletes da fenix
211263	couraca do julgamento
211269	desenho primitivo
211301	runa de expor fraqueza
211315	suprimentos escondidos couro leve
211316	suprimentos escondidos botao da paz
211317	suprimentos escondidos folha prata
211318	suprimentos escondidos pocoes menores de cura
211319	suprimentos escondidos espadas curtas de cobre
211320	suprimentos escondidos calcas runicas de cobre
211321	suprimentos escondidos varinhas magicas inferiores
211322	suprimentos escondidos oleo menor de teurgo
211323	suprimentos escondidos bombas grosseiras de cobre
211324	suprimentos escondidos canos de atirar rudimentares
211325	suprimentos escondidos cinto de couro feito a mao
211326	suprimentos escondidos colete de couro com relevo
211327	suprimentos escondidos calcas de linho marrom
211328	suprimentos escondidos veste de linho marrom
211329	suprimentos escondidos ovo assado com ervas
211330	suprimentos escondidos carne temperada de lobo
211331	suprimentos escondidos peixinho brilhante
211332	suprimentos escondidos bandagem de linho grossa
211365	remessa de suprimentos
211367	remessa de suprimentos
211368	remessa de suprimentos
211382	algibeira de mensageiro pequena
211384	bolsa de mensageiro resistente
211385	runa de espalhar de serpente
211386	anotacoes de feiticos surto arcano
211387	runa de luz estupenda
211390	runa de provocacao
211391	runa de chuva curativa
211392	runa de agonia eterna
211393	runa de furia obcecada
211419	punhado de escamas cambiantes
211420	talisma de escama cambiante
211421	a caixa
211422	estilhaco do caos
211423	luvas de couro tocadas pelo caos
211427	receptaculo de alma
211443	lamina da raiva
211444	manto do evocador
211445	arco recurvo barbaro
211447	carregamento de armas
211448	contrato de aquisicao assinado
211449	perola do caos do vingador
211450	perola do caos do invocador
211451	perola do caos do acolito
211452	perola das profundezas negras perfeita
211454	globo d agua estranho
211455	luvas sem dedos elegantes
211456	adaga do sacrificio voluntario
211457	cinturao do defensor do crepusculo
211458	tomo de protecao contra sombra
211460	broquel artico ancestral
211461	cetro da lapide inscrita
211462	anel do encorajamento continuo
211463	broches de besouro tremelicantes
211464	capa da prelacao usada
211465	botas nimbus da percepcao
211466	cinturao de alburno do conservador
211467	aro do punho de ferro
211468	dragonas castanhas puidas
211471	chave fontescarpa
211472	incunabulo do banimento
211476	rastro das runas do fogo
211477	runa de incinerar
211482	oferenda da lanca partida
211487	explosivos de demolicao
211488	runa do vingador
211490	profecia de milhares de luzes
211491	bolsa de pele de murloc sem fundo
211492	algibeira de kelris
211498	sabre da noite sentinela do aprendiz
211499	lobo pioneiro do aprendiz
211500	faixa de tecido resiliente
211501	couraca do poder
211502	manoplas de couro tocadas pelo caos
211504	corrente do vingador do crepusculo
211505	elmo do vingador do crepusculo
211506	botas do vingador do crepusculo
211507	capucho do elementalista do crepusculo
211508	pisantes do elementalista do crepusculo
211509	veste do elementalista do crepusculo
211510	capucho do matador do crepusculo
211511	pisantes do matador do crepusculo
211512	tunica do matador do crepusculo
211514	anotacoes de feiticos regeneracao em massa
211527	saco de dormir aconchegante
211528	percepcao sombria
211530	profecia de uma cidade escravizada
211531	profecia dos sete visitantes
211534	percepcao primeva
211691	anotacoes de feiticos impacto arcano
211777	manuscrito naga
211779	patua da compreensao
211780	pergaminho kwyjibo
211784	pergaminho adubidibe
211785	pergaminho cwal
211786	pergaminho cara luta welles
211787	pergaminho ping mais baixo alguem
211789	capucho de artemis
211799	saco de mercadorias roubadas
211800	pergaminho da reintegracao
211809	cartilha introdutoria
211813	patua de sentinela da asa de prata
211814	marca do pioneiro do brado guerreiro
211815	hino de batalha da asa de prata
211816	tambor de batalha do brado guerreiro
211818	globo d agua estranho
211819	suprimentos escondidos barras de bronze
211820	suprimentos escondidos barras de prata
211821	suprimentos escondidos couro medio
211822	suprimentos escondidos ervamossa
211823	suprimentos escondidos cardo veloz
211824	suprimentos escondidos pocoes inferiores de mana
211825	suprimentos escondidos botas rusticas de bronze
211826	suprimentos escondidos chaves mestras de prata
211827	suprimentos escondidos bastoes runicos de prata
211828	suprimentos escondidos oleo menor de mana
211829	suprimentos escondidos bombas pequenas de bronze
211830	suprimentos escondidos luneta ornada
211831	suprimentos escondidos manto de couro escuro
211832	suprimentos escondidos omoplatas do montanhista
211833	suprimentos escondidos camisa de la cinza
211834	suprimentos escondidos manto com fecho de perola
211835	suprimentos escondidos sabichao defumado
211836	suprimentos escondidos carne de urso defumada
211837	suprimentos escondidos marisco a la goblin
211838	suprimentos escondidos bandagens grossas de la
211839	remessa de suprimentos
211840	remessa de suprimentos
211841	remessa de suprimentos
211842	casquete do pensamento de rakkamar
211843	mascara do escarnio
211845	pedra de afiar das profundezas negras
211846	instrucoes pedra de afiar das profundezas negras
211848	oleo de mana das profundezas negras
211849	formula oleo de mana das profundezas negras
211852	mitenes da agua poluida
211853	pergaminho poco voce
211854	pergaminho omitir kesa
211855	pergaminho luar vigoroso
211856	coifa de malha resiliente
211857	mascara de couro resiliente
211933	suprimentos escondidos pedra rustica
211934	suprimentos escondidos pocoes de cura
211935	suprimentos escondidos elixir de poder de fogo
211940	guardiao tribal de ecks av
211941	yari do andavento
211944	karma de tojara
211953	pergaminho da recuperacao arcana i
211954	pergaminho da precisao arcana i
211955	pergaminho da protecao contra o arcano fogo i
211956	pergaminho da protecao contra o arcano gelo i
211957	pergaminho de poder arcano
212160	deslocador dadiva do tempo
212225	receptaculo de alma eterno
212230	diagrama receptaculo de alma
212548	runa do eclipse
212549	runa do coureador
212551	runa da guerra
212552	epifania psicosofica
212559	runa de lamina envenenada
212560	runa do despertar ancestral
212561	runa da escuridao sombria
212562	runa de raiva curativa
212568	trofeu de cabeca de lobo
212580	cajado do erudito
212581	arco do vanguardeiro
212582	espada do protetor
212583	lamina da sentinela
212584	cajado nodoso do conselheiro
212585	arco do pioneiro
212586	espada do legionario
212587	lamina do batedor
212588	luvas do fornecedor
212589	botinas do mensageiro
212590	correia de icamento
212748	bilhete desgastado
212994	braceletes do caca temporal
212996	braceletes do traztrovao
212997	braceletes do chamare
213074	runa da nutricao
213086	runa da tempestade
213087	manto do sargento
213088	manto do sargento
213090	runa da sinergia
213093	runa de poder
213094	runa da nova de fogo
213096	runa do chamariz
213098	runa da invocacao
213100	runa do conhecimento proibido
213101	runa das chamas sombrias
213102	runa da perversidade
213103	runa da rebentacao de sangue
213104	runa da precisao implacavel
213105	xauarmagedom
213109	runa da raiva concentrada
213110	runa do comandante
213111	runa da intervencao
213112	anotacoes de feiticos salva de misseis
213117	runa de berserk
213118	runa do rei da selva
213119	runa do instinto
213120	runa do sonhador
213121	azevinho seco
213122	runa do tiro firme
213123	runa da exposicao
213124	runa do combate corpo a corpo
213125	runa do envigoramento
213126	runa do desmanchador
213127	anotacoes de feiticos tcoesgie laomdeag
213128	runa da piedade
213129	runa do abraco da luz
213130	runa das infusoes
213131	runa dos escudos sagrados
213132	runa do guardiao
213136	runa do subterfugio
213137	runa do agressor
213138	runa do canhoto
213139	runa do assassino
213140	profecia do caminho vivificado
213141	runa da esperanca
213142	profecia da malicia aprisionada
213143	epifania apocrifa
213144	epifania luminosa
213165	basiliscos quem tem medo de virar pedra
213168	moeda de cobre sangrenta
213169	moeda de prata sangrenta
213170	moeda de ouro sangrenta
213278	protetores de mao do maestro da paulada
213279	morriao refletor
213280	visor de mira do atirador perito
213281	reativador do hiperfluxo eletromagnetico
213282	maquina de inovacao hipercarregada
213283	maquina de conflagracao hipercarregada
213284	maquina de devastacao hipercarregada
213285	braceletes manchados de oleo de lev
213286	agulha do eletrocutor
213287	porca do eletrocutor
213288	manoplas grudentas de grudio
213289	hidrobaculo
213290	galochas acidas
213291	vingador toxico ii
213292	gigafaca trecotronica
213293	superarma de alta tecnologia v7
213294	escarpes de furnafunda
213295	vibrolamina ultrassonica
213296	corta cabecas supercarregado
213297	martelo explosivo oscilante
213298	macacao do criador de robos
213299	calcas molhadas com gasolina
213300	luvas do mestre do combate
213301	dragonas sinteticas
213302	dragonas do negociador astuto
213303	espaldares para raios
213304	brafoneiras do matador de troggs
213305	placa d ombros de liga usinada
213306	murca da inventividade
213307	clamide do desmantelamento
213308	prototipo de manto paraquedas
213309	manto da invencao
213310	claramisa hipercondutora
213311	veste hipercondutora
213312	avental com isolamento termico
213313	couraca com isolamento termico
213314	malha de aneis eletromantica
213315	camisa encadeada eletromantica
213316	peitoral p e r i g o
213317	estabilizadores de mira experimentais
213318	bracelete ornado de ferro negro
213319	luvas do maquinista
213320	dedos da precisao arcana
213321	cinto com preparado volatil
213322	cintel da crocodilagem
213323	cordao da terra profunda
213324	cinto de corda eletromagnetico
213325	cinturao da visao no escuro
213326	cinturao da reclamacao
213327	cinto do berserker trogg
213328	pantalonas hipercondutoras
213329	saiote hipercondutor
213330	coxotes p e r i g o
213331	perneiras com isolamento termico
213332	guarda pernas com isolamento termico
213333	chausses eletromanticos
213334	perponte eletromantico
213335	botas p e r i g o
213336	chancas hipercondutoras
213337	sandalias hipercondutoras
213338	botas de aterramento eletromanticas
213339	escarpes de aterramento eletromanticos
213340	botas de operador de gnomobo
213341	botinas de seguranca com isolamento termico
213342	galochas com isolamento termico
213343	distintivo da justica
213344	torque de agente da paz de gnomeregan
213345	pingente de pistao
213346	pingente do regresso
213347	camara de combustao miniaturizada
213348	experimento giromatico 420b
213349	frasco de pilulas de gniodina
213350	nucleo endurecido de wirdal
213351	escudo torreao irradiado
213352	graca do remendogenheiro
213353	cajado desfribilador
213354	cajado do genio do mal
213355	ferroada de falco
213356	canhao personalizado de termaplugue
213369	couro levemente luminoso
213370	pedacos irradiados de couro
213371	caixote de solucao de gniodina maculada
213372	gniodina com isolamento termico
213373	sucata reflexiva
213376	placas de veraprata de baixa radioatividade
213378	microfilamento instavel
213379	arcanofilamento hipercondutor
213381	pilha de engrenagens manchadas
213383	engrenagens de veraprata polidas
213390	engrenomuralha de veraprata rodopiante
213391	manoplas de mithril eletrificadas
213407	erva de gato
213408	macro ajustador giromatico
213409	retalhador arcano do mekkatorque
213410	trecolamina reluzente
213411	ignicao inextinguivel de izelflix
213412	escudo de seguranca dieletrico
213413	ombreiras generosamente acolchoadas
213414	faixa do meca reparador
213415	bracadeiras do faz tudo
213416	cutelo foguete de termaplugue
213417	coifa de filamentos de veraprata
213418	aneletes de veraprata soldados
213419	manual de reparo do 9 60
213421	bilhete chamuscado
213426	para raios ogrico
213427	sucata encardida
213442	garra do engrenomestre
213443	presente tiquetaqueante
213452	runa sagrada dormente
213513	incunabulo da libertacao
213526	pernil hibrido
213527	mistura de temperos do contrabandista
213528	cerveja balsamica
213529	veneno viscoso
213542	necro gnomicon
213543	pergaminho falae
213544	pergaminho dastefo riatorlim
213545	pergaminho tosim dopotag
213546	pergaminho lalaraia
213547	pergaminho daspe aque
213548	pergaminho de passagem liminar
213549	pergaminho de pesca arcana
213550	pergaminho de polimorfia melao estranho
213551	pergaminho do deslocamento controlado
213552	lagrima de theradras
213553	lagrima de theradras
213554	ampola de agua cristalina
213558	balsamo elemental
213559	cambio de mecanostruz
213560	silenciador de mecanostruz
213563	guia de campo
213564	pergaminho da evocacao menor
213565	kit basico de entomologia
213583	entalhe com enxofre
213594	idolo da interpelacao
213599	visao perturbadora
213632	anotacoes de feiticos parciais
213633	anotacoes de feiticos parciais
213634	anotacoes de feiticos parciais
213641	caixa de sucata de gnomeregan
213701	pena resistente de harpia
213709	presa de serpente das nuvens
213735	processador n u c l e o g 7 imaculado
213736	processador n u c l e o g 7 corroido
213737	oferenda ao espirito do vento
214435	chave de jaula de puma
215111	monoculo gneuroarticulado de arcanofilamento
215114	coifa de escama hipercondutora luminescente
215115	faixa de ouro hipercondutora
215129	formula encantamento de desmanche arma
215138	formula encantamento de re talhacao torso
215141	signo encantado inovacao
215149	molde monoculo gneuroarticulado de arcanofilamento
215152	molde capucho gneuroarticulado luminescente
215153	diagrama engrenomuralha de veraprata rodopiante
215155	instrucoes elmo temperado com cancelamento de interferencias
215156	diagrama faixa de ouro hipercondutora
215162	pocao de rejuvenescimento ligeiramente irradiada
215163	receita pocao de rejuvenescimento ligeiramente irradiada
215166	capucho gneuroarticulado luminescente
215257	pergaminho da compreensao
215365	dragonas do invocador
215366	cordao do invocador
215367	molde couro levemente luminescente
215368	molde arcanofilamento hipercondutor
215369	molde cordao do invocador
215370	molde dragonas do invocador
215371	patua de jani
215373	martelo de treinamento do punho de prata
215374	espada ancestral
215375	cajado tatico
215376	maca do cruzado
215377	veste irradiada
215378	botas irradiadas
215379	calcotes irradiados
215380	cinto para levantamento de peso assistido
215381	capuz gneurocondutor do canalizador
215382	capuz de escamas com resistencia a radiacao
215383	instrucoes guarda cerebro de veraprata refletor
215384	instrucoes placas de veraprata de baixa radioatividade
215385	suprimentos escondidos barras de ouro
215386	suprimentos escondidos barras de mithril
215387	suprimentos escondidos pelego pesado
215388	suprimentos escondidos couros grossos
215389	suprimentos escondidos some folha
215390	suprimentos escondidos bigode de hadggar
215391	suprimentos escondidos boquinha do inverno
215392	suprimentos escondidos lotus roxo
215393	suprimentos escondidos pocoes maiores de cura
215394	suprimentos escondidos pocoes inferiores de escudopetreo
215395	suprimentos escondidos elixires de agilidade
215396	suprimentos escondidos elixires de defesa maior
215397	suprimentos escondidos machados solidos de ferro
215398	suprimentos escondidos bracadeiras verdes de ferro
215399	suprimentos escondidos manoplas pesadas de mithril
215400	suprimentos escondidos pedras de amolar macicas
215401	suprimentos escondidos kits de ceifa colheitas compactos
215402	suprimentos escondidos bombas grandes de ferro
215403	suprimentos escondidos miras letais
215404	suprimentos escondidos bacamarte de mithril
215405	suprimentos escondidos botas foguete gnomicas
215406	suprimentos escondidos morteiros goblinicos
215407	suprimentos escondidos omoplatas barbarescas
215408	suprimentos escondidos luvas do guardiao
215409	suprimentos escondidos bracadeiras de escama de tartaruga
215410	suprimentos escondidos cintos crepusculares
215411	suprimentos escondidos mantos de couro gelido
215412	suprimentos escondidos luvas de couro sombrio
215413	suprimentos escondidos camisas brancas formais
215414	suprimentos escondidos pantalonas de seda carmesim
215415	suprimentos escondidos camisas luxuosas de seda roxa
215416	suprimentos escondidos mascaras brancas do bandido
215417	suprimentos escondidos caldo reconfortante de tartaruga
215418	suprimentos escondidos linguicas de aranha
215419	suprimentos escondidos bandagens grossas de seda
215420	suprimentos escondidos bacalhau escama de pedra
215421	suprimentos escondidos oleo igneo
215422	molde coifa de escama hipercondutora luminescente
215423	molde capuz gneurocondutor do canalizador
215424	molde capuz de escamas com resistencia a radiacao
215425	eco do pantano
215426	eco do cemiterio
215427	eco de arathi
215428	eco de theramore
215429	diagrama engrenagens de veraprata polidas
215430	precipitacao de gnomeregan
215431	diagrama bomba radioativa de alta potencia
215432	diagrama bomba radioativa taca facil
215433	receita gniodina com isolamento termico
215434	nao usado
215435	incunabulo da bencao
215436	totem da chama revigorante
215437	transfigurador trogg 3000
215441	martelo quebrado
215443	fragmento de orbe estilhacado
215444	monstro maca canos quebrados
215449	encolhedor de mundo
215450	projeto de tabardo aidan
215456	mensagem chamuscada
215458	mensagem inclusa
215459	mensagem inclusa
215460	mensagem inclusa
215461	galinha de ataque domesticada
215468	ordens do grande cruzado
215683	geomancia a verdade nua e crua
215815	magia defensiva basica
215816	uma rede de mentiras desmascarando mitos e lendas
215817	demonios e voce
215820	mumias um guia para os desagradaveis mortos vivos
215822	rwlrwlrwlrwl
215824	um guia ludita para cuidar da sua mascote demoniaca
216484	botas de batalha eletroforjadas
216485	peitoral eletroforjado
216486	coxotes eletroforjados
216490	idolo da ira
216491	carregamento de madeira da selva do espinhaco
216492	apito do raptor sanguineo mosqueado
216494	distorcedor de mundo extravagante de aragriar
216495	esmagador sanguineo
216496	quebra cranios sanguineo
216497	dessangre
216498	grimorio sanguineo encantado
216499	esmagador de casca sanguinea
216500	talisma do bosque com elos de sangue
216501	barreira da tempestade de sangue
216502	totem belico da tempestade de sangue
216503	joia da tempestade de sangue
216504	sabre da luz sangrenta eclipsada
216505	resplendor do cruzado da luz sangrenta
216506	lamina do vingador da luz sangrenta
216507	selo de sangue do umbral
216508	elo da serpentina sanguinea infernal
216509	essencia do pacto infernal
216510	circulo da ressonancia do sangue
216511	selo do sangue
216512	aro das veias geladas
216513	talisma sangue de tigre
216514	aljava sanguinea
216515	bornal de municao sanguinea
216516	arco sangracoite
216517	santuario sanguineo
216518	selo do pacto de sangue
216519	elo da sombra sanguinea
216520	lamina ceifa sangue
216521	golpeadores sanguineos velozes
216522	estilete respingado de sangue
216523	chave da jaula enferrujada
216570	redeas do gato de sabre dourado
216606	runa de maestria em duas maos
216607	oferenda de luz sangrenta
216608	refletores de raios radiantes
216610	ordens do grande cruzado
216615	sinalizador da tempestade de sangue ancestral
216616	chave da jaula composta
216617	uniforme do combatente de kurzen
216618	recompensa da capita aransas
216619	racao de estudante
216620	manto sanguiputrido
216621	clamide banhada em sangue
216622	manto coagulado
216623	capa de homeostase
216633	escora de veraprata hidraulica
216634	fusivel de cartucho gg12 082
216635	nucleo de caos gasto
216636	nucleo de caos carregado
216637	pilha de pecas aleatorias
216645	particula de escuridao
216646	caixote misterioso de ziri
216661	anel encardido
216662	anel de ouro brilhante
216673	anel de ouro brilhante de didie
216674	anel de ouro brilhante de nogg
216675	vestes de civinada impecaveis
216676	culotes corretrecho ageis
216678	perneiras triplamente reforcadas
216679	ferramenta de desmanche da shoni
216680	meias luvas bechil
216698	bracadeiras de couro de dragao do sargento mor
216699	guarda bracos encadeados do sargento mor
216700	bracadeiras de couro do sargento mor
216701	munhequeiras de placa do sargento mor
216702	manilhas de seda do sargento mor
216703	munhequeiras de malha do primeiro sargento
216704	guarda bracos de couro de dragao do primeiro sargento
216705	bracadeiras de placa do primeiro sargento
216706	guarda bracos de couro do primeiro sargento
216707	manilhas de seda do primeiro sargento
216738	manual de redirecionamento
216740	tomo do intelecto expandido
216744	pergaminho da fortitude aumentada
216745	pergaminho do demonio das sombras
216746	manual do brado de comando
216747	grimorio da colheita de almas
216748	grimorio de portal de evocacao
216764	folheto de indomabilidade profunda
216767	folheto de reviver
216769	revelacao de projecao totemica
216770	tratado do aspecto da vibora
216771	folheto de restauracao aprimorada
216879	pergaminho trolico misterioso
216880	pergaminho trolico decifrado
216884	lamina sanguissedenta
216914	comenda maculada
216918	botas vilcordias
216919	faixa vilcordia
216920	braceletes vilcordios
216921	guantes vilcordias
216922	coroa vilcordia
216923	perneiras vilcordias
216924	abraco vilcordio
216925	dragonas vilcordias
216938	insignia da alianca maior
216939	insignia da horda maior
216941	signo de ariden
216945	reliquia de dalaran curiosa
216946	reliquia de dalaran brilhante
216947	reliquia de dalaran zunidora
216948	reliquia de dalaran estranha
216949	reliquia de dalaran pesada
216950	reliquia de dalaran medonha
216951	reliquia de dalaran escorregadia
216956	carta rasgada
216971	algibeira de moedas de cobre sangrentas
216972	algibeira de moedas de prata sangrentas
217005	capa do mecanico
217006	martelo do mecanico
217007	botas sem bateria
217008	peitoral sem bateria
217009	perneiras sem bateria
217014	sacola de suprimentos
217017	torneio de pesca
217161	anotacoes de feiticos etaf ed goroifrof
217244	molde veste de seda carmesim
217245	veste de seda carmesim
217246	colete de magitrama preta
217247	perneiras de magitrama preta
217248	cinto de seda terrano
217249	molde cinto de seda terrano
217250	omoplatas de seda carmesim
217251	molde omoplatas de seda carmesim
217252	manto longo sedoso
217253	botas do encantador
217254	molde botas do encantador
217255	cinto de seda carmesim
217256	colete terrano
217257	capucho do encantador
217258	molde capucho do encantador
217259	mascara do grande vodu
217260	molde mascara do grande vodu
217261	veste do grande vodu
217262	molde veste do grande vodu
217263	bracadeiras de couro do guardiao
217264	molde bracadeiras de couro do guardiao
217265	cinto do guardiao
217266	molde cinto do guardiao
217267	calcas do guardiao
217268	peitoral de escama de tartaruga
217270	luvas de escama de tartaruga
217271	molde luvas de escama de tartaruga
217273	manoplas de escama dourada
217274	instrucoes manoplas de escama dourada
217275	botas de escama dourada
217276	instrucoes botas de escama dourada
217277	corselete de escama dourada
217278	instrucoes corselete de escama dourada
217279	coifa de escama dourada
217280	instrucoes coifa de escama dourada
217281	espada larga de lunaco
217282	instrucoes espada larga de lunaco
217283	omoplatas de escama dourada
217284	instrucoes omoplatas de escama dourada
217285	perneiras de escama dourada
217286	instrucoes perneiras de escama dourada
217287	varinha mistica maior
217288	vestes do lich
217289	armadura criomortis
217290	olho faiscante de mordresh
217291	cranio inerte de mordresh
217292	faixa do mago da morte
217293	capa seda de aranha
217294	mortalha embalsamada
217295	varinha necrotica
217296	talisma do fragmento espectral
217297	veste de doan
217298	dragonas de doan
217299	bastao do ilusionista
217300	chapeu do cristalba
217301	amuleto triuno
217302	poder de mograine
217303	perneiras tecepedra
217304	luvas do revelosh
217305	guarda bracos do revelosh
217306	botas do revelosh
217307	espaldares do revelosh
217308	signo encantado inovacao
217314	rifle miraluna
217315	arco de precisao
217336	monstro incubo chicote maca 1m
217337	remessa de suprimentos
217338	remessa de suprimentos
217339	remessa de suprimentos
217345	veneno sebaceo
217346	veneno entorpecente
217347	veneno atrofico
217350	anotacoes de engenharia de termaplugue
217351	anotacoes de engenharia de termaplugue
217398	elixir arcano inferior
217399	receita elixir arcano inferior
217495	pergaminho de crioimpacto
217496	pergaminho da lamina
217497	espada de narpas
217609	talisma de kazdor
217693	pocao de invisibilidade
217704	porrete com ferros
217717	emblema vazio
217718	emblema da magia de sangue
217719	essencia de magia de sangue
217720	oferenda de carne
217721	oferenda de ossos
217727	protecao dos mortos
217736	runa da confraria
217737	talisma modificado
219021	bolsa carteiro parruda
219022	anel do carregador
219023	anel do vendedor
219024	anel do mensageiro
219135	pingente interessante
219136	pingente da tenacidade
219137	pingente da iniciativa
219147	runa da graca
219223	furia do mestre de espadas
219326	semente de renovacao
219343	capucho do mao leve
219345	laco infernal
219399	musgo do pesadelo
219401	minerio de ferro frio
219402	escama de dragao tocada pelo sonho
219404	foice das sombras
219405	texto de magus ogro
219406	ovo de dragao verde nao chocado
219414	cascas de ovo estilhacadas
219444	raiz de sonho
219445	po de ouro de tolo
219446	escama de dragao infusa pelo sonho
219447	ovo de dragao tocado pelo sonho
219448	motonirico
219449	profecia azshariana
219454	lotus estelar
219486	minerio de silvestela
219487	casco de estrela
219488	ovo de dragao tocado pelas estrelas
219490	reliquia elunar
219491	perola onirica
219514	raiz da lua
219515	pedra da lua maior
219517	escama de dragao lunar
219518	escrito das harpias
219519	anotacoes do guardiao louco
219520	ovo de dragao do brilho da lua
219526	instrucoes de missao floresta do crepusculo
219759	relatorio de campo de charla
219770	relatorio de campo de gemeron
219771	relatorio de campo de thandros
219772	relatorio de campo de fallia
219773	instrucoes de missao vale gris
219774	instrucoes de missao terras agrestes
219775	instrucoes de missao feralas
219776	relatorio de inteligencia gruta de vul gol
219778	relatorio de inteligencia o horto putrido
219803	relatorio de inteligencia fazenda dos figueira
219918	missiva sangrenta
219924	relatorio de inteligencia cantilenda
219925	relatorio de inteligencia satyrnaar
219926	relatorio de inteligencia acampamento de lenhadores brado guerreiro
219927	estilha de esmeralda
219928	relatorio de inteligencia agol watha
219929	missiva sangrenta
219930	missiva sangrenta
219935	lamina de kajind
219937	relatorio de inteligencia shaol watha
219938	relatorio de inteligencia rocha oculta
219957	relatorio de inteligencia oneiros
219958	relatorio de inteligencia colossos gemeos
219959	relatorio de inteligencia ruinas dos ventos corvejantes
219962	incursoes pesadelares missao da floresta do crepusculo i
219963	autorizacao de delegacao missao da floresta do crepusculo i
219965	autorizacao de delegacao missao da floresta do crepusculo ii
219966	incursoes pesadelares missao da floresta do crepusculo ii
219967	incursoes pesadelares missao da floresta do crepusculo iii
219968	incursoes pesadelares missao da floresta do crepusculo iv
219969	incursoes pesadelares missao da floresta do crepusculo v
219970	incursoes pesadelares missao da floresta do crepusculo vi
219971	incursoes pesadelares missao da floresta do crepusculo vii
219972	incursoes pesadelares missao da floresta do crepusculo viii
219973	incursoes pesadelares missao da floresta do crepusculo ix
219974	incursoes pesadelares missao da floresta do crepusculo x
219975	incursoes pesadelares missao da floresta do crepusculo xi
219976	incursoes pesadelares missao da floresta do crepusculo xii
219977	incursoes pesadelares missao da floresta do crepusculo xiii
219978	incursoes pesadelares missao da floresta do crepusculo xiv
219979	incursoes pesadelares missao da floresta do crepusculo xv
219980	incursoes pesadelares missao da floresta do crepusculo xvi
219981	incursoes pesadelares missao da floresta do crepusculo xvii
219982	incursoes pesadelares missao da floresta do crepusculo xviii
219983	autorizacao de delegacao missao da floresta do crepusculo iii
219984	autorizacao de delegacao missao da floresta do crepusculo iv
219985	autorizacao de delegacao missao da floresta do crepusculo v
219986	autorizacao de delegacao missao da floresta do crepusculo vi
219987	autorizacao de delegacao missao da floresta do crepusculo vii
219988	autorizacao de delegacao missao da floresta do crepusculo viii
219989	autorizacao de delegacao missao da floresta do crepusculo ix
219990	autorizacao de delegacao missao da floresta do crepusculo x
219991	autorizacao de delegacao missao da floresta do crepusculo xi
219992	autorizacao de delegacao missao da floresta do crepusculo xii
219993	autorizacao de delegacao missao da floresta do crepusculo xiii
219994	autorizacao de delegacao missao da floresta do crepusculo xiv
219995	autorizacao de delegacao missao da floresta do crepusculo xv
219996	autorizacao de delegacao missao da floresta do crepusculo xvi
219997	autorizacao de delegacao missao da floresta do crepusculo xvii
219998	autorizacao de delegacao missao da floresta do crepusculo xviii
219999	incursoes pesadelares missao do vale gris i
220000	incursoes pesadelares missao do vale gris ii
220001	incursoes pesadelares missao do vale gris iii
220002	incursoes pesadelares missao do vale gris iv
220003	incursoes pesadelares missao do vale gris v
220004	incursoes pesadelares missao do vale gris vi
220005	incursoes pesadelares missao do vale gris vii
220006	incursoes pesadelares missao do vale gris viii
220007	incursoes pesadelares missao do vale gris ix
220008	incursoes pesadelares missao do vale gris x
220009	incursoes pesadelares missao do vale gris xi
220010	incursoes pesadelares missao do vale gris xii
220011	incursoes pesadelares missao do vale gris xiii
220012	incursoes pesadelares missao do vale gris xiv
220013	incursoes pesadelares missao do vale gris xv
220014	incursoes pesadelares missao do vale gris xvi
220015	incursoes pesadelares missao do vale gris xvii
220016	incursoes pesadelares missao do vale gris xviii
220017	incursoes pesadelares missao das terras agrestes i
220018	incursoes pesadelares missao das terras agrestes ii
220019	incursoes pesadelares missao das terras agrestes iii
220020	incursoes pesadelares missao das terras agrestes iv
220021	incursoes pesadelares missao das terras agrestes v
220022	incursoes pesadelares missao das terras agrestes vi
220023	incursoes pesadelares missao das terras agrestes vii
220024	incursoes pesadelares missao das terras agrestes viii
220025	incursoes pesadelares missao das terras agrestes ix
220026	incursoes pesadelares missao das terras agrestes x
220027	incursoes pesadelares missao das terras agrestes xi
220028	incursoes pesadelares missao das terras agrestes xii
220029	incursoes pesadelares missao das terras agrestes xiii
220030	incursoes pesadelares missao das terras agrestes xiv
220031	incursoes pesadelares missao das terras agrestes xv
220032	incursoes pesadelares missao das terras agrestes xvi
220033	incursoes pesadelares missao das terras agrestes xvii
220034	incursoes pesadelares missao das terras agrestes xviii
220035	incursoes pesadelares missao de feralas i
220036	incursoes pesadelares missao de feralas ii
220037	incursoes pesadelares missao de feralas iii
220038	incursoes pesadelares missao de feralas iv
220039	incursoes pesadelares missao de feralas v
220040	incursoes pesadelares missao de feralas vi
220041	incursoes pesadelares missao de feralas vii
220042	incursoes pesadelares missao de feralas viii
220043	incursoes pesadelares missao de feralas ix
220044	incursoes pesadelares missao de feralas x
220045	incursoes pesadelares missao de feralas xi
220046	incursoes pesadelares missao de feralas xii
220047	incursoes pesadelares missao de feralas xiii
220048	incursoes pesadelares missao de feralas xiv
220049	incursoes pesadelares missao de feralas xv
220050	incursoes pesadelares missao de feralas xvi
220051	incursoes pesadelares missao de feralas xvii
220052	incursoes pesadelares missao de feralas xviii
220053	autorizacao de delegacao missao do vale gris i
220054	autorizacao de delegacao missao do vale gris ii
220055	autorizacao de delegacao missao do vale gris iii
220056	autorizacao de delegacao missao do vale gris iv
220057	autorizacao de delegacao missao do vale gris v
220058	autorizacao de delegacao missao do vale gris vi
220059	autorizacao de delegacao missao do vale gris vii
220060	autorizacao de delegacao missao do vale gris viii
220061	autorizacao de delegacao missao do vale gris ix
220062	autorizacao de delegacao missao do vale gris x
220063	autorizacao de delegacao missao do vale gris xi
220064	autorizacao de delegacao missao do vale gris xii
220065	autorizacao de delegacao missao do vale gris xiii
220066	autorizacao de delegacao missao do vale gris xiv
220067	autorizacao de delegacao missao do vale gris xv
220068	autorizacao de delegacao missao do vale gris xvi
220069	autorizacao de delegacao missao do vale gris xvii
220070	autorizacao de delegacao missao do vale gris xviii
220071	autorizacao de delegacao missao das terras agrestes i
220072	autorizacao de delegacao missao das terras agrestes ii
220073	autorizacao de delegacao missao das terras agrestes iii
220074	autorizacao de delegacao missao das terras agrestes iv
220075	autorizacao de delegacao missao das terras agrestes v
220076	autorizacao de delegacao missao das terras agrestes vi
220077	autorizacao de delegacao missao das terras agrestes vii
220078	autorizacao de delegacao missao das terras agrestes viii
220079	autorizacao de delegacao missao das terras agrestes ix
220080	autorizacao de delegacao missao das terras agrestes x
220081	autorizacao de delegacao missao das terras agrestes xi
220082	autorizacao de delegacao missao das terras agrestes xii
220083	autorizacao de delegacao missao das terras agrestes xiii
220084	autorizacao de delegacao missao das terras agrestes xiv
220085	autorizacao de delegacao missao das terras agrestes xv
220086	autorizacao de delegacao missao das terras agrestes xvi
220087	autorizacao de delegacao missao das terras agrestes xvii
220088	autorizacao de delegacao missao das terras agrestes xviii
220089	autorizacao de delegacao missao de feralas i
220090	autorizacao de delegacao missao de feralas ii
220091	autorizacao de delegacao missao de feralas iii
220092	autorizacao de delegacao missao de feralas iv
220093	autorizacao de delegacao missao de feralas v
220094	autorizacao de delegacao missao de feralas vi
220095	autorizacao de delegacao missao de feralas vii
220096	autorizacao de delegacao missao de feralas viii
220097	autorizacao de delegacao missao de feralas ix
220098	autorizacao de delegacao missao de feralas x
220099	autorizacao de delegacao missao de feralas xi
220100	autorizacao de delegacao missao de feralas xii
220101	autorizacao de delegacao missao de feralas xiii
220102	autorizacao de delegacao missao de feralas xiv
220103	autorizacao de delegacao missao de feralas xv
220104	autorizacao de delegacao missao de feralas xvi
220105	autorizacao de delegacao missao de feralas xvii
220106	autorizacao de delegacao missao de feralas xviii
220164	runa do gladiador
220165	runa da ira
220166	nucleo infernal ardente
220167	po de tumulo cintilante
220168	cerveja candente com tripla fermentacao
220169	simbolo de fe
220173	parassonia
220213	sangue vital vil
220214	elo de corrente infernal
220216	laco infernal
220217	runa do voraz
220345	feiticaria sanguinea
220346	lendas dos sabios das mares
220347	o liminar e o arcano
220348	etiqueta cotidiana
220349	desenho forjado em pedra
220350	jornadas venenosas
220351	sapta do ar turva
220352	a mente metalica
220353	codice do conjurador
220360	runa de eflorescencia
220375	fragmento de ar
220379	anotacoes de xama rasgadas
220446	tesouro sobrenatural
220510	essencia elemental
220511	grande elmo do pesadelo
220512	capacete de aco dourado imaculado
220514	visor de penas verdejantes
220515	capacete esmeralda encantado
220516	visor esquecido de talho
220518	chapeu empoeirado de ba ham
220519	cocar com penas do vodu
220521	cocar do ritualista hakkari
220522	coroa do apanhador de almas
220523	capelina dos exilados
220525	fragmento de ar chamejante
220526	processador n u c l e o g 7 coberto de lodo
220527	dragonas do berserker atal ai
220528	omoplatas do guarda caca atal ai
220529	espaldares do fanatismo
220530	vontade do guerreiro atal ai
220531	flor roxa ondulante
220532	espaldares atal ai reforcados
220533	peitoral atal ai reforjado
220534	abraco da serpente do vento eterno
220535	vestimentas do profeta atal ai
220536	pulsos do curandeiro atal ai
220537	bracadeiras aguanegra do sonhador
220538	bracadeiras escamalodo amaldicoadas
220539	bandos de guerra do sacrificio
220540	protetores de mao cheios de corrupcao
220541	punhos de placa cheios de doenca
220542	manoplas d agua suja poluidas
220543	luvas de malha em escamas esmeralda
220544	garras de linfalume
220545	luvas do lutador fetido
220546	maos do atormentado
220547	luvas do profeta atal ai caido
220548	luvas do bagateiro atal ai
220549	correia albagulha
220550	cintel do saqueador do templo
220551	faixa do sonho esmeralda do devoto
220552	cinta de dor
220553	cinto do adorador renegado
220554	elo de presas de atal alarion
220555	cinturao de escama de serpente atal ai
220556	kilt do profeta atal ai caido
220557	sarongue escameolo amaldicoado
220558	perneiras do assassino atal ai
220559	perneiras de escama de dragao revitalizadas
220560	coxotes conchaprata
220561	pisantes troll tenazes
220562	grevas de batalha injetadas de sangue
220563	botas do xama de sangue atal ai
220564	botas coleantes restauradas
220565	botas do andanevoa etereas
220566	garra em brasa
220567	picante ensanguentado
220568	armachado do explorador do templo
220569	martelo da ira virulento
220570	manto dos pesadelos
220571	arco longo ferroante
220572	repetidor rapido de rinzo
220573	arco de caca do espreitador do medo
220574	dente de eranicos afiado
220575	devorador dos malditos
220576	machado do carrasco atal ai
220577	poder do loa sangrento
220578	punho dos renegados
220579	bastao de mojo do mandingueiro
220580	loucura do avatar
220581	espancador de cobra
220582	pranto do dragao
220583	lamina do ignobil abjeto
220584	lamina do sopro de fogo
220585	unha ma degradada
220586	hubris a marcadora de bandidos
220587	adaga do sonho do sacrificio
220588	presa de garra de naja
220589	golpeador de serpente
220590	pinaculo da adoracao hakkari
220591	bastao restaurador de mirran
220594	foice do sonho
220595	cajado focal do pesadelo
220596	bastao divinatorio antigo
220597	pedra de draco do emissario do sonho
220598	pedra de draco do emissario do pesadelo
220599	pedra de draco do profeta de sangue
220600	brasao da preeminencia
220601	guarda do mandingueiro hakkari
220602	meio casco da tartaruga do esgoto
220603	bastao de corrosao irreversivel
220604	trofeu do pesadelo
220605	incunabulo do sacrilegio
220606	idolo do sonho
220607	totem da ancestralidade atormentada
220608	clamide de pelepluma
220609	clamide do ocaso
220610	runa de destreza mental
220611	capa de bagata de hukkah
220612	runa de mar revolto
220613	runa de eco ribombante
220614	runa de choque estatico
220615	manto de pele de pantera
220616	runa de sobrecarga
220617	runa de pandemia
220618	runa de aura de imolacao
220619	cerimonia do sangue atal ai
220620	cranio da serpente alada
220621	cristal de ressonancia do pesadelo
220622	olho do dragao perfeitamente preservado
220623	medalhao perdido de jin do
220624	patua valoroso manchado de sangue
220625	resiliencia dos exilados
220626	anel garradraca do berserker
220627	anel garradraca do espreitador
220628	anel garradraca do emissario
220629	anel garradraca do profeta de sangue
220630	anel garradraca do jaganata
220632	medalhao de ritual de sangue atal ai
220633	distintivo de ritual de sangue atal ai
220634	patua de ritual de sangue atal ai
220635	pedregulho encantado de atal alarion
220636	icone de sangue atal ai
220637	ficha de ritual atal ai
220638	vareta de bagata heterodoxa
220639	inanimador de lledra
220642	armadura de placa do martir banido
220643	guarda pernas de placa do martir banido
220648	botas de placa do martir banido
220649	heranca de merithra
220650	guarda peito do profeta obcecado
220651	guarda pernas do profeta obcecado
220652	botas ornamentadas do profeta obcecado
220653	guarda peito do berserker uivante
220654	coxotes do berserker uivante
220656	botas de batalha do berserker uivante
220657	cota do berserker ostracizado
220658	coxotes do berserker ostracizado
220659	grevas encadeadas do berserker ostracizado
220660	camisa encadeada do devoto rejeitado
220661	guarda pernas do devoto rejeitado
220662	botas de escama do devoto rejeitado
220663	perneiras do tece espiritos corrompido
220664	escarpes do tece espiritos corrompido
220665	peitoral do tece espiritos corrompido
220666	malha de aneis do cacador terrivel
220667	chausses do cacador terrivel
220668	grevas do cacador terrivel
220669	gibao do profeta exilado
220670	sapatilhas do profeta exilado
220671	calca de couro do profeta exilado
220672	arnes do adorador perdido
220673	perneiras do adorador perdido
220674	lamina furtiva aviltada
220675	botinas do adorador perdido
220676	tunica corrompida por sangue
220677	botas corrompidas por sangue
220678	calca corrompida por sangue
220679	perneiras do profeta malevolente
220680	colete do profeta malevolente
220681	sandalias do profeta malevolente
220682	runa dos desenfreados
220683	colete do profeta benevolente
220684	perneiras do profeta benevolente
220685	sandalias do profeta benevolente
220686	ruina do chefe tribal
220687	runa do raptor
220688	manto dos pesadelos inerte
220689	avambracos energizados pelo caos
220738	placa d ombros do pavor
220739	brafoneiras perniciosas
220740	guarda ombros do semeador do medo
220741	brafoneiras encadeadas guinchantes
220742	espaldares guinchantes
220743	guarda ombros encadeados cacofonico
220744	manto da corrente uivante
220745	membrana da neurose sombria
220747	manto da paranoia
220748	ombreiras da obsessao
220749	dragonas da insanidade
220750	brafoneiras da mente fraturada
220751	ombreiras do demente
220754	runa do vendaval
220775	cupom de troca de engenharia
220778	calcas do guarda de sangue coagulado
220779	tunica do guarda de sangue coagulado
220780	botas do guarda de sangue coagulado
220781	perneiras do profeta do pesadelo
220783	vestimenta do profeta do pesadelo
220784	sandalias do profeta do pesadelo
220791	runa do gato da selva
220792	pergaminho da recomposicao espacial
220794	cota de placa do cavaleiro
220795	brafoneiras de placa do tenente cavaleiro
220796	brafoneiras de placa do guarda de sangue
220797	perneiras de placa do cavaleiro
220798	perneiras de placa do guarda petreo
220799	grevas de placa do sargento mor
220800	grevas de placa do primeiro sargento
220801	armadura de placa do guarda petreo
220803	elmo de placa do guarda de sangue
220804	elmo de placa do tenente cavaleiro
220806	manoplas de placa do primeiro sargento
220807	manoplas de placa do primeiro sargento
220808	brafoneiras imbuidas do tenente cavaleiro
220809	perneiras imbuidas do cavaleiro
220810	capacete imbuido do tenente cavaleiro
220811	grevas imbuidas do primeiro sargento
220812	manoplas imbuidas do primeiro sargento
220813	armadura imbuida do cavaleiro
220814	botas lamelares do primeiro sargento
220815	guarda peito lamelar do cavaleiro
220816	coxotes lamelares do cavaleiro
220817	manoplas lamelares do primeiro sargento
220818	brafoneiras lamelares do tenente cavaleiro
220819	elmo lamelar do tenente cavaleiro
220820	capacete de malha do guarda de sangue
220821	capacete encadeado do guarda de sangue
220822	capacete encadeado do tenente cavaleiro
220823	palas de malha do guarda de sangue
220824	palas encadeadas do guarda de sangue
220825	palas encadeadas do tenente cavaleiro
220826	armaduras de malha do guarda petreo
220827	armadura encadeada do guarda petreo
220828	armadura encadeada do cavaleiro
220829	manoplas encadeadas do sargento mor
220830	manoplas encadeadas do primeiro sargento
220831	manoplas de malha do primeiro sargento
220832	coxotes encadeados do cavaleiro
220833	coxotes encadeados do guarda petreo
220834	coxotes de malha do guarda petreo
220835	escarpes de malha do primeiro sargento
220836	escarpes encadeados do primeiro sargento
220837	escarpes encadeados do sargento mor
220838	peito d armas inscrito do guarda petreo
220839	coxotes inscritos do guarda petreo
220840	escarpes inscritos do primeiro sargento
220841	ombreiras inscritas do guarda de sangue
220842	morriao inscrito do guarda de sangue
220843	manoplas inscritas do primeiro sargento
220844	peitoral pulsante do guarda petreo
220845	manoplas pulsantes do primeiro sargento
220846	grevas pulsantes do primeiro sargento
220847	coxotes pulsantes do guarda petreo
220848	capacete pulsante do guarda de sangue
220849	omoplatas pulsantes do guarda de sangue
220850	bandana de couro do tenente cavaleiro
220851	bandana de couro do guarda de sangue
220852	omoplatas de couro do tenente cavaleiro
220853	omoplatas de couro do guarda de sangue
220854	armadura de couro do cavaleiro
220855	armadura de couro do guarda petreo
220856	manoplas de couro do sargento mor
220857	manoplas de couro do primeiro sargento
220858	calcas de couro do cavaleiro
220859	calcas de couro do guarda petreo
220860	botas de couro do sargento mor
220861	botas de couro do primeiro sargento
220862	botas de couro crepitante do sargento mor
220863	botas de couro crepitante do primeiro sargento
220864	perneiras de couro crepitante do cavaleiro
220865	perneiras de couro crepitante do guarda petreo
220866	manoplas de couro crepitante do sargento mor
220867	manoplas de couro crepitante do primeiro sargento
220868	tunica de couro crepitante do cavaleiro
220869	tunica de couro crepitante do guarda petreo
220870	espaldares de couro crepitante do tenente cavaleiro
220871	espaldares de couro crepitante do guarda de sangue
220872	capacete de couro crepitante do tenente cavaleiro
220873	capacete de couro crepitante do guarda de sangue
220874	elmo de couro restaurado do tenente cavaleiro
220875	elmo de couro restaurado do guarda de sangue
220876	espaldares de couro restaurado do tenente cavaleiro
220877	espaldares de couro restaurado do guarda de sangue
220878	gibao de couro restaurado do cavaleiro
220879	gibao de couro restaurado do guarda petreo
220880	luvas de couro restaurado do sargento mor
220881	luvas de couro restaurado do primeiro sargento
220882	perneiras de couro restaurado do cavaleiro
220883	perneiras de couro restaurado do guarda petreo
220884	botas de couro restaurado do sargento mor
220885	botas de couro restaurado do primeiro sargento
220886	colete de medotrama do cavaleiro
220887	dragonas de medotrama do tenente cavaleiro
220888	perneiras de medotrama do cavaleiro
220889	chapeu de medotrama do tenente cavaleiro
220890	luvas de medotrama do sargento mor
220891	botas de medotrama do sargento mor
220892	armadura de cetim do cavaleiro
220893	perneiras de cetim do cavaleiro
220894	ombreiras de cetim do tenente cavaleiro
220895	botas de cetim do sargento mor
220896	murca de cetim do tenente cavaleiro
220897	luvas de cetim do sargento mor
220898	luvas de cetim do primeiro sargento
220899	murca de cetim do guarda de sangue
220900	botas de cetim do primeiro sargento
220901	ombreiras de cetim do guarda de sangue
220902	perneiras de cetim do guarda petreo
220903	armadura de cetim do guarda petreo
220904	colete de medotrama do guarda petreo
220905	dragonas de medotrama do guarda de sangue
220906	perneiras de medotrama do guarda petreo
220907	chapeu de medotrama do guarda de sangue
220908	luvas de medotrama do primeiro sargento
220909	botas de medotrama do primeiro sargento
220912	martelo de geodo
220913	runa da demolicao
220914	martelo de geodo quebrado
220915	idolo do tropego enraivecido
220916	chifre de estegodon pisatroante
220917	caixa de pigmento escarlate
220918	suprimentos escondidos ensopado de marisco inframina
220919	suprimentos escondidos sopa de pinoturno
220920	suprimentos escondidos files macios de lobo
220921	suprimentos escondidos bandagens grossas de magitrama
220922	suprimentos escondidos ervassol
220923	suprimentos escondidos folhas de sonho
220924	suprimentos escondidos barras de veraprata
220925	suprimentos escondidos barras de torio
220926	suprimentos escondidos couro rustico
220927	suprimentos escondidos pelego grosso
220928	suprimentos escondidos barras de torio encantado
220929	suprimentos escondidos pocoes superiores de mana
220930	suprimentos escondidos pocoes elevadas de cura
220931	suprimentos escondidos bombas de alto explosivo
220932	suprimentos escondidos granadas de torio
220933	suprimentos escondidos rifles de torio
220934	suprimentos escondidos coifas de mithril
220935	suprimentos escondidos cintos de torio
220936	suprimentos escondidos manoplas veraprata
220937	suprimentos escondidos kits de armadura rustica
220938	suprimentos escondidos bracadeiras de couro malefico
220939	suprimentos escondidos bracadeiras de couro runico
220940	suprimentos escondidos bandanas de magitrama pretas
220941	suprimentos escondidos cintos de runatrama
220942	suprimentos escondidos camisas de smoking
220964	avambracos energizados pelo caos descarregados
220965	machadao escamorte
221008	remessa de suprimentos
221009	remessa de suprimentos
221010	remessa de suprimentos
221017	registros de keldara
221018	kit de remedios de campo
221019	amostra de satiridea
221020	runa da deusa da lua
221021	semente do pesadelo
221024	frasco dos pesadelos sempiternos
221025	avambracos do evocador energizados pelo caos
221026	avambracos do matador energizados pelo caos
221027	avambracos do protetor energizados pelo caos
221028	signo encantado sonhos vivos
221030	mojo de magia proibida atal ai
221191	pedra onirica
221192	diario de sonhos
221193	anel esmeralda
221196	mojo de guerra atal ai
221199	tintura de satiridea
221256	braco direito do obliterador
221257	braco esquerdo do obliterador
221258	pe direito do obliterador
221259	pe esquerdo do obliterador
221260	cabeca do obliterador
221261	trago do sussurro selvagem
221262	oferenda selvagem
221267	runa do sedento de sangue
221271	as de selvas
221272	baralho de selvas
221273	dois de selvas
221274	tres de selvas
221275	quatro de selvas
221276	cinco de selvas
221277	seis de selvas
221278	sete de selvas
221279	oito de selvas
221280	baralho de pestes
221281	as de peste
221282	dois de peste
221283	tres de peste
221284	quatro de peste
221285	cinco de peste
221286	seis de peste
221287	sete de peste
221288	oito de peste
221289	baralho de dunas
221290	as de dunas
221291	dois de dunas
221292	tres de dunas
221293	quatro de dunas
221294	cinco de dunas
221295	seis de dunas
221296	sete de dunas
221297	oito de dunas
221298	as de pesadelos
221299	baralho de pesadelos
221300	dois de pesadelos
221301	tres de pesadelos
221302	quatro de pesadelos
221303	cinco de pesadelos
221304	seis de pesadelos
221305	sete de pesadelos
221306	oito de pesadelos
221307	carta de negraluna decomposicao
221308	carta de negraluna exuberancia
221309	carta de negraluna tempestade de areia
221310	carta de negraluna tormento
221311	mojo da vida atal ai
221312	frasco de mojo atal ai
221313	frasco de mojo pesadelar
221314	aviso de procura se
221315	gerador de arco iris
221316	uniforme que exige postura de premo
221317	meridistal de feralas
221318	meridistal de azshara
221319	meridistal da rocha negra
221320	meridistal das terras agrestes
221321	sinete de poder atal ai
221322	sinete de mojo atal ai
221323	sinete de serenidade atal ai
221324	chave de umbraforja quebradica
221325	carga explosiva x plode facil
221326	coracao de cervo sagrado
221327	diagrama raio gnomico encolhedor
221328	diagrama oculos gnomicos
221329	diagrama projetor gnomico redomatico
221330	diagrama cinto gnomico de prevencao de ferimentos
221331	diagrama botas foguete gnomicas
221332	diagrama frango de batalha gnomico
221333	diagrama casquete gnomico de controle mental
221334	diagrama raio gnomico da morte
221335	diagrama capacete de operario goblinico
221336	diagrama capacete de mineracao goblinico
221337	diagrama morteiro goblinico
221338	diagrama carga sapadora goblinica
221339	diagrama botas foguete goblinicas
221340	diagrama distribuidor de bombas goblinico
221341	diagrama o bombao
221342	diagrama pistola dragonica goblinica
221343	diagrama capacete foguete goblinico
221344	grimorio pessoal
221345	sangue corrompido de eranicos
221346	escapula do avatar caido
221347	sapta do fogo turva
221348	sapta da agua turva
221349	sapta da terra turva
221350	anotacoes de xama calcinadas
221351	anotacoes de xama encharcadas
221352	anotacoes de xama manchadas
221353	fragmento de fogo
221354	fragmento de agua
221355	fragmento de terra
221356	fragmento de fogo chamejante
221357	fragmento de agua chamejante
221358	fragmento de terra chamejante
221359	pena de feruja imaculada
221360	papiro farraki
221361	resina de zukk ash
221362	flanela de limpar arma
221363	escapula do avatar caido
221364	moeda do massacre de cobre
221365	moeda do massacre de prata
221366	moeda do massacre de ouro
221367	algibeira de moedas do massacre de cobre
221368	algibeira de moedas do massacre de prata
221369	dreno do pesadelo
221370	medalhao precioso
221371	bolsa de moedas do sequestrador
221372	bolsa de moedas retalhada
221374	angustia do sonho
221376	elmo do sonho esmeralda
221377	coxotes do sonho esmeralda
221378	manoplas do sonho esmeralda
221379	escarpes do sonho esmeralda
221380	peitoral do sonho esmeralda
221381	brafoneiras do sonho esmeralda
221382	loriga incrustada de esmeraldas
221383	protetores de mao incrustados de esmeraldas
221384	capacete incrustado de esmeraldas
221385	coxotes incrustados de esmeraldas
221386	espaldares incrustados de esmeraldas
221387	botas de placa incrustadas de esmeraldas
221388	perneiras de malha de escamas esmeralda
221389	manoplas de malha de escamas esmeralda
221390	peitoral de malha de escamas esmeralda
221391	capacete de malha de escamas esmeralda
221392	omoplatas de malha de escamas esmeralda
221393	botas de malha de escamas esmeralda
221394	botas cobertas de esmeraldas
221395	peitoral coberto de esmeraldas
221396	manoplas cobertas de esmeraldas
221397	capacete coberto de esmeraldas
221398	perneiras cobertas de esmeraldas
221399	omoplatas cobertas de esmeraldas
221400	omoplatas encadeadas esmeralda
221401	perneiras encadeadas esmeralda
221402	capacete encadeado esmeralda
221403	manoplas encadeadas esmeralda
221404	peitoral encadeado esmeralda
221405	botas encadeadas esmeralda
221406	colete de couro esmeralda
221407	luvas de couro esmeralda
221408	elmo de couro esmeralda
221409	escarpes de couro esmeralda
221410	calcas de couro esmeralda
221411	omoplatas de couro esmeralda
221412	luvas do guarda sonhos esmeralda
221413	elmo do guarda sonhos esmeralda
221414	calcas do guarda sonhos esmeralda
221415	botas do guarda sonhos esmeralda
221416	omoplatas do guarda sonhos esmeralda
221417	bau do guarda sonhos esmeralda
221418	rugido de agamaggan
221419	colete do vigia esmeralda
221420	botas do vigia esmeralda
221421	luvas do vigia esmeralda
221422	elmo do vigia esmeralda
221423	perneiras do vigia esmeralda
221424	omoplatas do vigia esmeralda
221425	diadema encantado esmeralda
221426	botas encantadas esmeralda
221427	luvas encantadas esmeralda
221428	runa do jogo sujo
221429	calcas encantadas esmeralda
221430	vestes encantadas esmeralda
221431	omoplatas encantadas esmeralda
221432	dragonas trancadas esmeralda
221433	runa da concentracao
221434	vestes trancadas esmeralda
221435	calcas trancadas esmeralda
221436	luvas trancadas esmeralda
221437	diadema trancado esmeralda
221438	botas trancadas esmeralda
221439	armadura do sono esmeralda
221440	rugido do sonho
221441	guardiao do sonho
221442	rugido do guardiao
221443	rugido do bosque
221444	duriao da selva
221445	runa do fogo focalizado
221446	martelo do ritualista
221447	grimorio de sangreluna do ritualista
221448	talisma do bosque corrompido
221450	arco do lutador do fosso gurubashi
221451	besta sanguissedenta
221452	elo arcano com foco em sangue
221453	elo de sangue fervente
221454	elo de sangue glacial
221455	reverencia da luz sangrenta
221456	sabre sanguineo eclipsado
221457	incunabulo de destruicao draconica
221458	elo da vitoria sombrio
221459	selo do sacrificado
221460	punhal de ataque pelas costas gurubashi
221461	runa da chacina
221462	espada da velocidade ensanguentada
221463	boneca vodu ancestral
221464	totem da precisao abrasadora
221465	arrebentador corrompido
221466	aro do sangue ardente
221467	olho de sangreluna
221468	muralha dos sussurros
221469	lanca farpada do cacador de cabecas
221470	esmeralda onirica
221471	bau dos guardioes esmeralda
221473	runa do vigia
221474	essencia acorrentada de eranicos
221475	essencia de eranicos
221480	anotacoes de feiticos armadura derretida
221481	epifania niilista
221482	runa de suplicio
221483	runa de queimadura
221484	vareta de bagata de mandingueiro
221487	anotacoes de feiticos protecao avancada
221488	epifania resoluta
221489	runa da vinganca
221490	runa da contracorrente
221491	bolsa caninegro
221497	chave velha
221498	lancheira robusta
221499	runa do guarda vil
221510	runa do cavaleiro
221511	runa do protetor
221512	runa da vivacidade
221513	runa do vigor
221514	runa do poder de fogo
221515	runa da detonacao
221516	runa da energia primeva
221517	runa de derramamento de sangue
221518	sussurro
221519	orbe de mannoroc
221544	ovo de corvo da tormenta
221545	anotacoes de bruxo decifradas
221547	anotacoes de bruxo codificadas
221549	codigo errante
221780	cetro da princesa theradras
221781	elmo de vanguarda
221782	elmo do exilio
221783	espaldares do mantenedor da lei
221785	vestimenta cenariana
221971	chifre de jurassonho
221972	fogo da pira onirica
221973	presa de cacador de sonhos
221974	colar temivel totem
221975	cajado patabua quebrado
221976	cajado da natureza adoecida
221978	alma do explorador
221979	profecia do inverno verdejante
221980	profecia do caos desperto
221981	profecia da tribo perdida
222952	frasco dos sonhos inquietos
222962	sabedoria de hyjal
223073	palas de malha do tenente cavaleiro
223074	coxotes de malha do cavaleiro
223075	capacete de malha do tenente cavaleiro
223076	manoplas de malha do primeiro sargento
223077	escarpes de malha do primeiro sargento
223078	armadura de malha do cavaleiro
223147	anotacoes de feiticos seta incendiaria
223148	tesouro sobrenatural
223149	tesouro sobrenatural
223150	tesouro sobrenatural
223151	tesouro sobrenatural
223160	arbusto baratinho
223161	caixote de suprimentos vazio
223162	capanga de mensageiro pratica
223163	formula pergaminho da recomposicao espacial
223164	capucho da curiosidade
223167	casquete da iniciativa
223168	fragmento do nucleo do mundo
223169	casquete da tenacidade
223171	pergaminho de geomancia
223172	corrente da tenacidade
223173	cordao do geomante
223174	botas do geomante
223175	manto do geomante
223177	bandana do geomante
223178	bracadeiras do geomante
223180	luvas do geomante
223181	espaldares do geomante
223182	calcas do geomante
223183	veste do geomante
223186	expedidor de suprimentos
223192	cordao do indomado
223193	coroa do tece sonhos
223194	elo da natureza selvagem
223195	amplidao da fera
223196	grevas do teocida
223197	defesa da natureza
223198	modas karkun
223214	zila gular
223215	orah raka
223216	rakkan archim
223217	rakkas lek
223218	tor kieldaz
223219	munhequeiras de tecido vil
223221	munhequeiras de couro vil
223222	munhequeiras de malha vil
223237	ombreiras de tecido vil
223238	ombreiras de couro vil
223239	omoplatas de malha vil
223240	capuz de tecido vil
223241	chapeu de couro vil
223242	coifa de couro vil
223248	perneiras de tecido vil
223249	perneiras de couro vil
223250	perneiras de malha vil
223251	perneiras de placa vil
223256	vestes de tecido vil
223261	peitoral de couro vil
223262	peitoral de malha vil
223263	peitoral de placa vil
223283	comenda manchada de sangue
223288	runa do martelo
223323	camisa
223324	perneiras do andarilho das chuvas
223325	peitoral de hakkari
223326	mortalha hakkari
223327	marca de hakkar
223328	diadema explodegema
223329	punhal de forca vital
223330	olho pulsante
223331	olho pulsante
223332	olho vibrante
223333	olho agourento
223334	olho brilhante
223335	olho gosmento
223336	olho penetrante
223337	olho ardente
223518	punhal de aragonita
223519	olho de theradras
223520	espada focal do inventor
223521	dragonas putrigarra
223522	elmo da montanha
223523	pedra nuvem
223524	punho de pedra
223525	cocar do adivinho
223526	sul thraze a acoitadora
223527	presa de gahz rilla
223528	armadura de escama de gahz rilla
223529	peitoral azarado
223530	kilt azarado
223531	brafoneiras sinistronas
223532	amuleto de sangue vital
223533	cajado do nomade do deserto
223534	guantes de jumanza
223535	vestimenta tribal do grimlok
223536	impeto de grimlok
223537	bracadeiras de placa craniana
223538	baculo lenhoso
223539	esfera encantada
223540	arco do mestre de matilha
223541	coracao de lasca preciosa
223542	rifle megatiro
223543	sandalias de vinhaputrida
223544	espaldares de metalreles
223545	broquel modernaco de bugitranca
223648	flecha imbuida em sonho
223912	pocao de purificacao
223913	pocao elevada de cura
223914	pocao maior de cura
223962	tornozeleira do espreitareia
223963	abraco de lycan
223964	lamina da escuridao eterna
223980	perneiras de escama ignea
223981	vestes do vagachamas
223982	rifle do mestre de matilha
223983	lamina do mediador
223984	luvas de teiasseda
223985	elo ciclopico
223986	capa podretumba
223987	omoplatas de courotala
224004	anel esmeralda
224005	anel esmeralda
224006	anel esmeralda
224122	devorador do sonho
224279	terrestris
224280	suserano defensor das revoadas dragonicas
224281	gla sir
224282	rae lar
224409	golpeador de serpente
224806	sintonizador de portal da legiao
224836	tesouro sobrenatural
224848	tesouro sobrenatural
224849	tesouro sobrenatural
224850	tesouro sobrenatural
224851	tesouro sobrenatural
224893	sintonizador de portais sobrecarregado
224912	sintonizador de sintonizador de portais
225675	nucleo obsidiano fuliginoso
225676	nucleo obsidiano derretido
225686	runa da dizimacao
225687	runa da armadura infernal
225688	runa da marca do caos
225689	anotacoes de feiticos salva arcana
225690	anotacoes de feiticos orbe congelado
225691	anotacoes de feiticos superaquecimento
225740	runa da compostura
225838	icone voltaico
225893	fim das eras
225914	runa do espirito aprisionado
225929	estilhaco de alma pestilento
225938	anotacoes de feiticos rasgadas
225939	anotacoes de feiticos rasgadas
225940	anotacoes de feiticos rasgadas
225941	anotacoes de feiticos rasgadas
225942	carne estragada de porco
225943	naco de carne rancoso
225954	anotacoes de feiticos calcinadas
225955	runa do desenvolto
226122	trompa de dalton
226201	lamina do escudeiro cuteberto
226207	eco de anastari
226208	eco de barthilas
226209	eco de dathrohan
226210	eco de maleki
226211	eco de nerub enkan
226212	eco de ramstein
226213	eco de rivendare
226214	eco de gualter
226252	runa do guerrilheiro
226374	veneno oculto i
226394	manual do veneno atrofico
226395	manual do veneno entorpecente
226396	manual do veneno oculto
226397	manual do veneno sebaceo
226401	tratado do coracao de leao
226402	revelacao da furia xamanistica
226403	manual do gancho de acougue
226404	real da inframina desgastado
226405	caixote de suprimentos da inframina danificado
226406	runa de especializacao em espada
226407	runa de especializacao em machado
226408	runa de especializacao em maca
226409	runa de especializacao em adaga
226410	runa de especializacao em arma de longo alcance
226411	runa de especializacao em arma de punho
226412	runa de especializacao em arma de longo alcance
226413	runa de especializacao arcana
226414	runa de especializacao em fogo
226415	runa de especializacao gelida
226416	runa de especializacao em natureza
226417	runa de especializacao em sombra
226418	runa de especializacao sagrada
226419	runa de especializacao em combate feral
226420	busto ricamente confeccionado
226421	placeholder_ashbringer_questitem_01
226440	cinto do matador noturno
226441	luvas do matador noturno
226442	braceletes do matador noturno
226443	botas do matador noturno
226444	ombreiras do matador noturno
226445	calcas do matador noturno
226446	elmo do matador noturno
226447	peito d armas do matador noturno
226472	jarra de sombras de stratholme
226473	corselete do matador noturno
226474	cinta do matador noturno
226475	protetores de mao do matador noturno
226476	bracadeiras do matador noturno
226477	tabis do matador noturno
226478	brafoneiras do matador noturno
226479	guarda pernas do matador noturno
226480	capuz do matador noturno
226484	bracadeiras do poder
226485	cinto do poder
226486	manoplas do poder
226487	escarpes do poder
226488	elmo do poder
226489	peitoral do poder
226490	coxotes do poder
226491	placa d ombros do poder
226492	brafoneiras do poder
226493	perneiras do poder
226494	cota do poder
226495	maxilar do poder
226496	botinas do poder
226497	maos do poder
226498	faixa do poder
226499	guarda bracos do poder
226500	amuleto da chama draconica lascado
226523	trompa de dalton
226526	tranqueira detonada
226527	palas do espreita gigantes
226528	luvas do espreita gigantes
226529	cinto do espreita gigantes
226530	bracadeiras do espreita gigantes
226531	botas do espreita gigantes
226532	perneiras do espreita gigantes
226533	capacete do espreita gigantes
226534	peitoral do espreita gigantes
226535	malha de aneis do espreita gigantes
226536	socapa do espreita gigantes
226537	perneiras encadeadas do espreita gigantes
226538	escarpes do espreita gigantes
226540	protetores de mao do espreita gigantes
226541	munhequeiras do espreita gigantes
226542	cinturao do espreita gigantes
226543	brafoneiras do espreita gigantes
226545	trompa de dalton
226546	sonar do deserto
226547	calcas vilcordias
226548	vestes vilcordias
226549	chifres vilcordios
226550	ombreiras vilcordias
226551	cinto vilcordio
226552	luvas vilcordias
226553	bracadeiras vilcordias
226554	sapatilhas vilcordias
226555	cinto do arcanista
226556	luvas do arcanista
226557	botas do arcanista
226558	braceletes do arcanista
226559	vestes do arcanista
226560	dragonas do arcanista
226561	perneiras do arcanista
226562	coroa do arcanista
226563	farpela do arcanista
226564	diadema do arcanista
226565	calcas do arcanista
226566	omoplatas do arcanista
226567	munhecas do arcanista
226568	sandalias do arcanista
226569	protetores de mao do arcanista
226570	cordao do arcanista
226571	botas da profecia
226572	luvas da profecia
226573	diadema da profecia
226574	calcas da profecia
226575	vestes da profecia
226576	dragonas da profecia
226577	cinturao da profecia
226578	avambracos da profecia
226579	munhecas da profecia
226580	cinto da profecia
226581	ombreiras da profecia
226582	farpela da profecia
226583	perneiras da profecia
226584	coroa da profecia
226585	maos da profecia
226586	sandalias da profecia
226587	runa do bombardeio
226588	espaldares do mantenedor da lei
226589	bracadeiras do mantenedor da lei
226590	elmo do mantenedor da lei
226591	manoplas do mantenedor da lei
226592	cinto do mantenedor da lei
226593	botas do mantenedor da lei
226594	coxotes do mantenedor da lei
226595	couraca do mantenedor da lei
226596	embraces de guerra do mantenedor da lei
226597	cinturao do mantenedor da lei
226598	perneiras do mantenedor da lei
226599	coroa do mantenedor da lei
226600	guantes do mantenedor da lei
226601	botas de batalha do mantenedor da lei
226602	peitoral do mantenedor da lei
226603	avambracos do mantenedor da lei
226604	cinto de batalha do mantenedor da lei
226605	brafoneiras do mantenedor da lei
226606	guarda pernas do mantenedor da lei
226607	cimeira do mantenedor da lei
226608	protetores de mao do mantenedor da lei
226609	escarpes do mantenedor da lei
226610	guarda peito do mantenedor da lei
226611	palas terrafuria
226612	capacete terrafuria
226613	botas terrafuria
226614	guarda pernas terrafuria
226615	manoplas terrafuria
226616	cinto terrafuria
226617	vestimenta terrafuria
226618	bracadeiras terrafuria
226619	cota anilhada terrafuria
226620	chancas terrafuria
226621	maos terrafuria
226622	visor terrafuria
226623	perneiras terrafuria
226624	dragonas terrafuria
226625	cordao terrafuria
226626	pulseiras terrafuria
226627	malha de escamas terrafuria
226628	escarpes terrafuria
226629	protetores de mao terrafuria
226630	grande elmo terrafuria
226631	perneiras em escamas terrafuria
226632	brafoneiras terrafuria
226633	cinta terrafuria
226634	munhequeiras terrafuria
226635	malha de aneis terrafuria
226636	botas de batalha terrafuria
226637	guantes terrafuria
226638	bacinete terrafuria
226639	perneiras encadeadas terrafuria
226640	espaldares terrafuria
226641	cinturao terrafuria
226642	braceletes terrafuria
226644	espaldares cenarianos
226645	botas cenarianas
226646	perneiras cenarianas
226647	elmo cenariano
226648	luvas cenarianas
226649	bracadeiras cenarianas
226650	cinto cenariano
226651	calcas cenarianas
226652	sandalias cenarianas
226653	manto cenariano
226654	manoplas cenarianas
226655	pulsos cenarianos
226656	amplexo cenariano
226657	cordao cenariano
226658	galhada cenariana
226659	trompas cenarianas
226660	cinturao cenariano
226661	tunica cenariana
226662	embraces cenarianos
226663	botinas cenarianas
226664	punhos cenarianos
226665	omoplatas cenarianas
226666	calcotes cenarianos
226667	cinta cenariana
226668	munhequeiras cenarianas
226669	guantes cenarianos
226670	coroa cenariana
226671	guarda pernas cenarianos
226673	chancas cenarianas
226674	brafoneiras cenarianas
226675	armadura cenariana
226678	premonicao e antecipacao de combate
226679	percepcoes do errante atemporal
226680	runa do primeiro guerreiro
226694	runa de especializacao de defesa
226698	rosqueta ortoparafusada
226699	flange parolada grapetada em latao
226700	tunica da arte sombria
226701	cinto da arte sombria
226702	luvas da arte sombria
226703	botas da arte sombria
226704	bracadeiras da arte sombria
226705	calcas da arte sombria
226706	espaldares da arte sombria
226707	capuz da arte sombria
226708	capucho do coracao selvagem
226709	kilt do coracao selvagem
226710	dragonas do coracao selvagem
226711	luvas do coracao selvagem
226712	cinto do coracao selvagem
226713	botas do coracao selvagem
226714	bracadeiras do coracao selvagem
226715	colete do coracao selvagem
226716	dragonas do espreitador de feras
226717	braceletes do espreitador de feras
226718	cinto do espreitador de feras
226719	calcas do espreitador de feras
226720	casquete do espreitador de feras
226721	luvas do espreitador de feras
226722	botas do espreitador de feras
226723	tunica do espreitador de feras
226724	cinto do magister
226725	braceletes do magister
226726	dragonas do magister
226727	perneiras do magister
226728	coroa do magister
226729	vestes do magister
226730	botas do magister
226731	luvas do magister
226732	cinto da forja de luz
226733	elmo da forja de luz
226734	peitoral da forja de luz
226735	espaldares da forja de luz
226736	coxotes da forja de luz
226737	manoplas da forja de luz
226738	botas da forja de luz
226739	bracadeiras da forja de luz
226740	luvas do devoto
226741	dragonas do devoto
226742	bracadeiras do devoto
226743	sandalias do devoto
226744	cinto do devoto
226745	veste do devoto
226746	coroa do devoto
226747	saia do devoto
226748	manoplas dos elementos
226749	colete dos elementos
226750	kilt dos elementos
226751	braceletes dos elementos
226752	botas dos elementos
226753	brafoneiras dos elementos
226754	cordao dos elementos
226755	coifa dos elementos
226756	dragonas de brumedo
226757	veste de brumedo
226758	guarda bracos de brumedo
226759	bracadeiras de brumedo
226760	perneiras de brumedo
226761	cinto de brumedo
226762	mascara de brumedo
226763	sandalias de brumedo
226764	botas do valor
226765	cinto do valor
226766	bracadeiras do valor
226767	coxotes do valor
226768	espaldares do valor
226769	elmo do valor
226770	peitoral do valor
226771	manoplas do valor
226772	faixa do coracao feral
226773	capucho do coracao feral
226774	galochas do coracao feral
226775	munhequeiras do coracao feral
226776	colete do coracao feral
226777	maos do coracao feral
226778	espaldares do coracao feral
226779	kilt do coracao feral
226780	cordao do coracao feral
226781	sandalias do coracao feral
226782	braceletes do coracao feral
226783	abraco do coracao feral
226784	manoplas do coracao feral
226785	dragonas do coracao feral
226786	cocar do coracao feral
226787	calcas do coracao feral
226788	embraces do coracao feral
226789	cinturao do coracao feral
226790	palas do coracao feral
226791	calcotes do coracao feral
226792	casquete do coracao feral
226793	punhos do coracao feral
226794	chancas do coracao feral
226795	tunica do coracao feral
226796	munhequeiras do coracao feral
226797	cinta do coracao feral
226798	brafoneiras do coracao feral
226799	guarda pernas do coracao feral
226801	viseira do coracao feral
226802	guantes do coracao feral
226803	botinas do coracao feral
226804	couraca do coracao feral
226815	pulsos do coracao feral
226816	cintura do coracao feral
226817	omoplatas do coracao feral
226818	pernas do coracao feral
226819	elmo do coracao feral
226820	luvas do coracao feral
226821	botas do coracao feral
226822	peitoral do coracao feral
226825	tunica do manto negro
226826	espaldares do manto negro
226827	calcas do manto negro
226828	guantes do manto negro
226829	casquete do manto negro
226830	bracadeiras do manto negro
226831	pisantes do manto negro
226832	cinto do manto negro
226835	munhequeiras do manto negro
226836	cinta do manto negro
226837	brafoneiras do manto negro
226838	guarda pernas do manto negro
226840	protetores de mao do manto negro
226841	viseira do manto negro
226842	botinas do manto negro
226843	armadura do manto negro
226845	pulsos do manto negro
226846	cintura do manto negro
226847	omoplatas do manto negro
226848	pernas do manto negro
226849	elmo do manto negro
226850	luvas do manto negro
226851	botas do manto negro
226852	bau do manto negro
226856	acelerador de flutuacao guiado
226857	botas de batalha do heroismo
226858	espaldares do heroismo
226859	coxotes do heroismo
226860	coroa do heroismo
226861	manoplas do heroismo
226862	peitoral do heroismo
226863	bracadeiras do heroismo
226864	cinto do heroismo
226865	munhequeiras do heroismo
226866	cinta do heroismo
226867	brafoneiras do heroismo
226868	guarda pernas do heroismo
226869	viseira do heroismo
226870	protetores de mao do heroismo
226871	escarpes do heroismo
226872	couraca do heroismo
226873	pulsos do heroismo
226874	cintura do heroismo
226875	omoplatas do heroismo
226876	pernas do heroismo
226877	elmo do heroismo
226878	luvas do heroismo
226879	botas do heroismo
226880	peitoral do heroismo
226881	botinas do senhor das feras
226882	calcas do senhor das feras
226883	manoplas do senhor das feras
226884	dragonas do senhor das feras
226885	braceletes do senhor das feras
226886	tunica do senhor das feras
226887	casquete do senhor das feras
226888	cinto do senhor das feras
226889	bracadeiras do senhor das feras
226890	banda do senhor das feras
226891	brafoneiras do senhor das feras
226892	perneiras do senhor das feras
226893	coifa do senhor das feras
226894	punhos do senhor das feras
226895	grevas do senhor das feras
226896	corrente do senhor das feras
226897	pulsos do senhor das feras
226898	cintura do senhor das feras
226899	omoplatas do senhor das feras
226900	pernas do senhor das feras
226901	elmo do senhor das feras
226902	luvas do senhor das feras
226903	botas do senhor das feras
226904	torso do senhor das feras
226905	cinto brumorte
226906	veste brumorte
226907	bracadeiras brumorte
226908	sandalias brumorte
226909	mascara brumorte
226910	perneiras brumorte
226911	guarda bracos brumorte
226912	dragonas brumorte
226913	braceletes brumorte
226914	cordao brumorte
226915	palas brumorte
226916	calcas brumorte
226917	capuz brumorte
226918	agarres brumorte
226919	botinas brumorte
226920	abraco brumorte
226921	pulsos brumorte
226922	cintura brumorte
226923	omoplatas brumorte
226924	pernas brumorte
226925	elmo brumorte
226926	luvas brumorte
226927	botas brumorte
226928	torso brumorte
226929	bracadeiras do feiticeiro
226930	manoplas do feiticeiro
226931	sandalias do feiticeiro
226932	vestes do feiticeiro
226933	perneiras do feiticeiro
226934	cinto do feiticeiro
226935	coroa do feiticeiro
226936	dragonas do feiticeiro
226937	pulsos do feiticeiro
226938	cintura do feiticeiro
226939	omoplatas do feiticeiro
226940	pernas do feiticeiro
226941	elmo do feiticeiro
226942	luvas do feiticeiro
226943	botas do feiticeiro
226944	torso do feiticeiro
226945	veste do virtuoso
226946	saia do virtuoso
226947	coroa do virtuoso
226948	cinto do virtuoso
226949	bracadeiras do virtuoso
226950	luvetes do virtuoso
226951	dragonas do virtuoso
226952	sandalias do virtuoso
226953	munhequeiras do virtuoso
226954	cordao do virtuoso
226955	palas do virtuoso
226956	perneiras do virtuoso
226957	capucho do virtuoso
226958	maos do virtuoso
226959	sapatilhas do virtuoso
226960	brial do virtuoso
226961	pulsos do virtuoso
226962	cintura do virtuoso
226963	omoplatas do virtuoso
226964	pernas do virtuoso
226965	elmo do virtuoso
226966	luvas do virtuoso
226967	botas do virtuoso
226968	torso do virtuoso
226969	espaldares da forja da alma
226970	bracadeiras da forja da alma
226971	cinto da forja da alma
226972	coxotes da forja da alma
226973	peitoral da forja da alma
226974	coturnos da forja da alma
226975	manoplas da forja da alma
226976	grande elmo da forja da alma
226977	braceletes da forja da alma
226978	cordao da forja da alma
226979	palas da forja da alma
226980	perneiras da forja da alma
226981	coroa da forja da alma
226982	punhos da forja da alma
226983	botinas da forja da alma
226984	abraco da forja da alma
226985	munhequeiras da forja da alma
226986	cinta da forja da alma
226987	brafoneiras da forja da alma
226988	guarda pernas da forja da alma
226989	viseira da forja da alma
226990	protetores de mao da forja da alma
226991	escarpes da forja da alma
226992	couraca da forja da alma
226993	pulsos da forja da alma
226994	cintura da forja da alma
226995	ombros da forja da alma
226996	pernas da forja da alma
226997	elmo da forja das almas
226998	luvas da forja da alma
226999	botas da forja da alma
227000	torso da forja da alma
227001	braceletes dos cinco trovoes
227002	coifa dos cinco trovoes
227003	brafoneiras dos cinco trovoes
227004	colete dos cinco trovoes
227005	kilt dos cinco trovoes
227006	manoplas dos cinco trovoes
227007	sapatilhas dos cinco trovoes
227008	cordao dos cinco trovoes
227009	bracadeiras dos cinco trovoes
227010	faixa dos cinco trovoes
227011	dragonas dos cinco trovoes
227012	perneiras dos cinco trovoes
227013	coroa dos cinco trovoes
227014	agarres dos cinco trovoes
227015	grevas dos cinco trovoes
227016	tunica dos cinco trovoes
227017	embraces dos cinco trovoes
227018	cinturao dos cinco trovoes
227019	espaldares dos cinco trovoes
227020	coxotes dos cinco trovoes
227021	face dos cinco trovoes
227022	punhos dos cinco trovoes
227023	botinas dos cinco trovoes
227024	corrente dos cinco trovoes
227025	munhequeiras dos cinco trovoes
227026	cinta dos cinco trovoes
227027	guarda ombros dos cinco trovoes
227028	guarda pernas dos cinco trovoes
227029	bacinete dos cinco trovoes
227030	protetores de mao dos cinco trovoes
227031	escarpes dos cinco trovoes
227032	couraca dos cinco trovoes
227033	pulsos dos cinco trovoes
227034	cintura dos cinco trovoes
227035	omoplatas dos cinco trovoes
227036	pernas dos cinco trovoes
227037	elmo dos cinco trovoes
227038	luvas dos cinco trovoes
227039	botas dos cinco trovoes
227040	torso dos cinco trovoes
227041	bisturi da sombra do flagelo
227042	omoplatas de placa do campeao
227043	elmo de placa do campeao
227044	elmo de placa do tenente comandante
227045	omoplatas de placa do tenente comandante
227046	cota de placa do capitao cavaleiro
227047	perneiras de placa do capitao cavaleiro
227048	perneiras de placa do legionario
227049	cota de placa do legionario
227050	manoplas de placa do guarda de sangue
227051	grevas de placa do guarda de sangue
227052	grevas de placa do tenente cavaleiro
227053	manoplas de placa do tenente cavaleiro
227054	omoplatas de couro do tenente comandante
227055	elmo de couro do tenente comandante
227056	omoplatas de couro do campeao
227057	elmo de couro do campeao
227058	peito d armas de couro do capitao cavaleiro
227059	guarda pernas de couro do legionario
227060	peito d armas de couro do legionario
227061	guarda pernas de couro do capitao cavaleiro
227062	chancas de couro do guarda de sangue
227063	guantes de couro do guarda de sangue
227064	chancas de couro do tenente cavaleiro
227065	guantes de couro do tenente cavaleiro
227066	elmo encadeado do tenente comandante
227067	elmo encadeado do campeao
227068	omoplatas encadeadas do tenente comandante
227069	omoplatas encadeadas do campeao
227070	cota encadeada do capitao cavaleiro
227071	cota encadeada do legionario
227072	guarda pernas encadeadas do capitao cavaleiro
227073	guarda pernas encadeados do legionario
227074	grevas encadeadas do guarda de sangue
227075	luvas encadeadas do guarda de sangue
227076	grevas encadeadas do tenente cavaleiro
227077	munhequeiras encadeadas do tenente cavaleiro
227078	brafoneiras encadeadas do campeao
227079	coxotes encadeados do legionario
227080	grande elmo encadeado do campeao
227081	guantes encadeados do guarda de sangue
227082	escarpes encadeados do guarda de sangue
227083	armadura encadeada do legionario
227084	brafoneiras encadeadas do tenente comandante
227085	coxotes encadeados do capitao cavaleiro
227086	grande elmo encadeado do tenente comandante
227087	guantes encadeados do tenente cavaleiro
227088	escarpes encadeados do tenente cavaleiro
227089	armadura encadeada do capitao cavaleiro
227090	capucho de medotrama do campeao
227091	espaldares de medotrama do tenente comandante
227092	espaldares de medotrama do campeao
227093	capucho de medotrama do tenente comandante
227094	tunica de medotrama do legionario
227095	guarda pernas de medotrama do capitao cavaleiro
227096	tunica de medotrama do capitao cavaleiro
227097	guarda pernas de medotrama do legionario
227098	chancas de medotrama do guarda de sangue
227099	mitenes de medotrama do guarda de sangue
227100	mitenes de medotrama do tenente cavaleiro
227101	chancas de couro do tenente cavaleiro
227102	dragonas de seda do tenente comandante
227103	capucho de seda do tenente comandante
227104	dragonas de seda do campeao
227105	capucho de seda do campeao
227106	tunica de seda do legionario
227107	guarda pernas de seda do legionario
227108	tunica de seda do capitao cavaleiro
227109	guarda pernas de seda do capitao cavaleiro
227110	chancas de seda do guarda de sangue
227111	mitenes de seda do guarda de sangue
227112	chancas de seda do tenente cavaleiro
227113	mitenes de seda do tenente cavaleiro
227114	manoplas de seda do tenente cavaleiro
227115	manoplas de seda do guarda de sangue
227116	luvas de seda do tenente cavaleiro
227117	luvas de seda do guarda de sangue
227118	capuz de cetim do campeao
227119	dragonas de cetim do tenente comandante
227120	dragonas de cetim do campeao
227121	capuz de cetim do tenente comandante
227122	tunica de cetim do capitao cavaleiro
227123	guarda pernas de cetim do legionario
227124	tunica de cetim do legionario
227125	guarda pernas de cetim do capitao cavaleiro
227126	mitenes de cetim do guarda de sangue
227127	chancas de cetim do guarda de sangue
227128	mitenes de cetim do tenente cavaleiro
227129	chancas de cetim do tenente cavaleiro
227130	palas de cetim do campeao
227131	perneiras de cetim do legionario
227132	coroa de cetim do campeao
227133	guantes de cetim do guarda de sangue
227134	botinas de cetim do guarda de sangue
227135	veste de cetim do legionario
227136	palas de cetim do tenente comandante
227137	perneiras de cetim do capitao cavaleiro
227138	coroa de cetim do tenente comandante
227139	guantes de cetim do tenente cavaleiro
227140	botinas de cetim do tenente cavaleiro
227141	veste de cetim do capitao cavaleiro
227142	peitoral lamelar do capitao cavaleiro
227143	perneiras lamelares do capitao cavaleiro
227144	cimeira lamelar do tenente comandante
227145	omoplatas lamelares do tenente comandante
227146	escarpes lamelares do tenente cavaleiro
227147	manoplas lamelares do tenente cavaleiro
227148	brafoneiras lamelares do tenente comandante
227149	capacete lamelar do tenente comandante
227150	guarda pernas lamelares do capitao cavaleiro
227151	guarda peito lamelar do capitao cavaleiro
227152	luvas lamelares do tenente cavaleiro
227153	grevas lamelares do tenente cavaleiro
227154	brafoneiras de malha do campeao
227155	cimeira de malha do campeao
227156	guarda pernas de malha do legionario
227157	cota de malha do legionario
227158	grevas de malha do guarda de sangue
227159	luvas de malha do guarda de sangue
227160	espaldares de malha do campeao
227161	perneiras de malha do legionario
227162	elmo de malha do campeao
227163	manoplas de malha do guarda de sangue
227164	escarpes de malha do guarda de sangue
227165	peitoral de malha do legionario
227166	palas de malha do campeao
227167	calcas de malha do legionario
227168	morriao de malha do campeao
227169	luvas de malha do guarda de sangue
227170	botas de malha do guarda de sangue
227171	couraca de malha do legionario
227172	omoplatas de couro de dragao do tenente comandante
227173	cimeira de couro de dragao do tenente comandante
227174	cimeira de couro de dragao do campeao
227175	omoplatas de couro de dragao do campeao
227176	peito d armas de couro de dragao do capitao cavaleiro
227177	perneiras de couro de dragao do legionario
227178	perneiras de couro de dragao do capitao cavaleiro
227179	peito d armas de couro de dragao do legionario
227180	guantes de couro de dragao do guarda de sangue
227181	botinas de couro de dragao do guarda de sangue
227182	botinas de couro de dragao do tenente cavaleiro
227183	guantes de couro de dragao do tenente cavaleiro
227184	espaldares de couro de dragao do campeao
227185	calcas de couro de dragao do legionario
227186	elmo de couro de dragao do campeao
227187	luvas de couro de dragao do guarda de sangue
227188	botas de couro de dragao do guarda de sangue
227189	armadura de couro de dragao do legionario
227190	espaldares de couro de dragao do tenente comandante
227191	calcas de couro de dragao do capitao cavaleiro
227192	elmo de couro de dragao do tenente comandante
227193	luvas de couro de dragao do tenente cavaleiro
227194	botas de couro de dragao do tenente cavaleiro
227195	armadura de couro de dragao do capitao cavaleiro
227196	tunica de couro de dragao do capitao cavaleiro
227197	grevas de couro de dragao do tenente cavaleiro
227198	manopla de couro de dragao do tenente cavaleiro
227199	bacinete de couro de dragao do tenente comandante
227200	guarda pernas de couro de dragao do capitao cavaleiro
227201	brafoneiras de couro de dragao do tenente comandante
227202	tunica de couro de dragao do legionario
227203	grevas de couro de dragao do guarda de sangue
227204	manoplas de couro de dragao do guarda de sangue
227205	elmo de couro de dragao do campeao
227206	guarda pernas de couro de dragao do legionario
227207	brafoneiras de couro de dragao do campeao
227279	aro do magister
227280	criacao das sombras
227282	anel da neblina funesta
227284	elo da fera
227285	dinamica estrutural do fluxo
227286	rum rumsey aquecido com creme
227337	conjunto de luvas e cinto felino
227338	conjunto de luvas e cinto astral
227339	conjunto de luvas e cinto do guardiao
227340	conjunto de luvas e cinto do reparador
227341	conjunto de luvas e cinto do perseguidor
227342	conjunto de luvas e cinto do espreitador
227343	conjunto de luvas e cinto misericordioso
227344	conjunto de luvas e cinto radiante
227345	conjunto luvas e cinto divino
227346	conjunto de luvas e cinto da aurora
227347	conjunto de luvas e cinto crepuscular
227348	conjunto de luvas e cinto da empolgacao
227349	conjunto de luvas e cinto da batalha
227350	conjunto de luvas e cinto do alivio
227351	conjunto de luvas e cinto da erupcao
227352	conjunto de luvas e cinto do impacto
227353	conjunto de luvas e cinto da determinacao
227354	conjunto de luvas e cinto corrompido
227355	conjunto de luvas e cinto perverso
227356	conjunto de luvas e cinto imovel
227357	conjunto de luvas e cinto imbativel
227359	conjunto de botas pernas e omoplatas felino
227360	conjunto de botas pernas e omoplatas astral
227361	conjunto de botas pernas e omoplatas do guardiao
227365	conjunto de botas pernas e omoplatas do reparador
227366	conjunto de botas pernas e omoplatas do perseguidor
227367	conjunto de botas pernas e omoplatas do espreitador
227368	conjunto de botas pernas e omoplatas misericordiosas
227369	conjunto de botas pernas e omoplatas radiante
227370	conjunto de botas pernas e omoplatas divino
227371	conjunto de botas pernas e omoplatas da aurora
227372	conjunto de botas pernas e omoplatas crepuscular
227373	conjunto de botas pernas e omoplatas da empolgacao
227374	conjunto de botas pernas e omoplatas da batalha
227375	conjunto de botas pernas e omoplatas do alivio
227376	conjunto de botas pernas e omoplatas da erupcao
227377	conjunto de botas pernas e omoplatas do impacto
227378	conjunto de botas pernas e omoplatas da determinacao
227379	conjunto de botas pernas e omoplatas corrompido
227380	conjunto de botas pernas e omoplatas perverso
227381	conjunto de botas pernas e omoplatas imovel
227382	conjunto de botas pernas e omoplatas imbativel
227383	conjunto de elmo e peito d armas felino
227384	conjunto de elmo e peito d armas astral
227385	conjunto de elmo e peito d armas do guardiao
227387	conjunto de elmo e peito d armas do reparador
227388	conjunto de elmo e peito d armas do perseguidor
227389	conjunto de elmo e peito d armas do espreitador
227390	conjunto de elmo e peito d armas misericordioso
227391	conjunto de elmo e peito d armas radiante
227392	conjunto de elmo e peito d armas divino
227393	conjunto de elmo e peito d armas da aurora
227394	conjunto de elmo e peito d armas do crepusculo
227395	conjunto de elmo e peito d armas da empolgacao
227396	conjunto de elmo e peito d armas da batalha
227397	conjunto de elmo e peito d armas do alivio
227398	conjunto de elmo e peito d armas da erupcao
227399	conjunto de elmo e peito d armas do impacto
227400	conjunto de elmo e peito d armas da determinacao
227401	conjunto de elmo e peito d armas corrompido
227402	conjunto de elmo e peito d armas perverso
227403	conjunto de elmo e peito d armas imovel
227404	conjunto de elmo e peito d armas imbativel
227444	idolo da cacadora
227451	signo de envio
227454	argola das mares
227455	brisa oceanica
227456	runa da tempestade carmesim
227530	cinto incandescente
227531	braceletes incandescentes
227532	capuz incandescente
227533	luvas incandescente
227534	perneiras incandescentes
227535	veste incandescente
227536	botas incandescentes
227537	ombreiras incandescentes
227549	retalho de pergaminho
227552	pergaminho retalhado
227658	nota de devoto da sombra
227683	sulfuras a mao de ragnaros
227684	martelo de sulfuron
227685	bisturi da sombra modificado
227686	martelo de guerra ornado
227687	dente de ouro favorito de orthas
227688	uivo sangrento
227689	armadura de placa parcialmente digerida
227690	pedra runica necrotica
227691	lamina de hanna
227724	comenda manchada de sangue
227727	instrucoes martelo de sulfuron
227728	olho de sulfuras
227730	contrato da irmandade do torio
227743	nucleo de forca obsidiano
227745	heranca de familia
227746	runa da arvore do mundo
227747	registros de familia
227748	diario do sobrevivente
227749	runa da estrela cadente
227750	braceletes de escama derretida
227751	cinto de escama derretida
227752	omoplatas de escama derretida
227754	perneiras de escama derretida
227755	elmo de escama derretida
227756	luvas de escama derretida
227757	botas de escama derretida
227758	peitoral de escama derretida
227759	luvas do nucleo calcinado
227760	braceletes do nucleo calcinado
227761	cinto do nucleo calcinado
227762	ombreiras do nucleo calcinado
227763	perneiras do nucleo calcinado
227764	elmo do nucleo calcinado
227765	botas do nucleo calcinado
227766	peitoral do nucleo calcinado
227767	drusa de ignolita
227768	sumonirico
227796	pergaminho darnassiano misterioso
227797	pergaminho darnassiano decifrado
227801	brasa das terras do fogo
227802	monstro tocha
227803	arnes de urso de guerra atroz
227804	bermuda de urso de guerra atroz
227805	ferocidade dos presamatos
227807	cinto denso dos presamatos
227808	dragonas dos presamatos rusticas
227809	soqueiras dos presamatos cravejadas
227810	botas dos presamatos densas
227811	defensor dos presamatos
227812	bolsa medicinal de pelurso
227813	agua benta de stratholme potavel
227814	cinturao da aurora radiante
227815	botinas da aurora de qualidade
227816	botas argenteas de elite
227817	luvas da aurora radiantes
227818	dragonas douradas da aurora chamejantes
227819	dragonas flamejantes da aurora abencoadas
227820	bracadeiras ferro negro temperadas
227821	elmo derretido tocado pela chama
227822	botas de cao do nucleo espessas
227823	luvas do nucleo flamifero de qualidade
227824	elmo ferro negro temperado
227825	destruidor ferro negro derretido
227826	aniquilador ferro negro das chamas
227827	cinturao encadeado derretido
227828	cinto do andarilho da lava
227829	botas de escama de dragao negro endurecida
227830	dragonas do nucleo flamifero de qualidade
227831	veste do nucleo flamifero de qualidade
227832	anistia negra temperada
227833	glaive da furia obsidiana
227834	omoplatas encadeadas derretidas
227835	manoplas ferro negro temperadas
227836	perneiras ferro negro temperadas
227837	cinto do cao do nucleo espesso
227838	manoplas cromaticas rutilantes
227839	perneiras do nucleo flamifero de qualidade
227840	guarda negra implacavel
227841	botas ferro negro temperadas
227842	punho de ebano
227843	ocaso aniquilador
227844	bolsa de runatrama reforcada em couro
227845	retalhador de arcanita refinada
227847	perneiras de democerne
227848	manoplas de democerne
227849	rifle de atirador de elite do nucleo de fogo
227850	lamina do sabio do arquimago
227851	peitoral de escama de dragao negro endurecida
227852	perneiras de escama de dragao negro endurecida
227853	omoplatas de escama de dragao negro endurecida
227854	manto cambiante primoroso
227857	profanacao
227858	martelo dos deuses selvagens
227859	omoplatas d alvorada cintilantes
227860	colete de lunatrama incandescente
227861	veste de lunatrama incandescente
227862	botas de lunatrama incandescente
227863	diadema de lunatrama incandescente
227864	perneiras de lunatrama incandescente
227865	manoplas de placa abrasadoras da tecnica oculta
227866	omoplatas vulcanicas magistrais
227867	perneiras vulcanicas magistrais
227868	peitoral vulcanico magistral
227869	manto cromatico brilhante
227870	manoplas da tormenta
227871	peitoral ferro negro temperado
227872	cimeira do grande chefe
227873	omoplatas de escama de dragao azul polida
227874	perneiras de escama de dragao azul polida
227875	peitoral de escama de dragao azul polida
227876	malha invencivel
227877	molde perneiras de escama de dragao verde viva
227878	manoplas de escama de dragao verde viva
227879	peitoral de escama de dragao verde viva
227880	martelo de batalha encantado com primor
227881	tranquilidade
227882	cinturao da percepcao arcana
227883	avambracos do voo veloz
227884	acerta peito mortal
227885	manoplas da fortaleza maior
227886	martelo magistral da tempestade do piloto aereo
227887	guardafria endurecida
227888	omoplatas de elite argenteas
227895	molde dragonas douradas da aurora
227896	molde botas argenteas
227897	molde omoplatas argenteas
227898	molde peitoral de escama de dragao azul polida
227899	molde omoplatas de escama de dragao azul polida
227900	molde perneiras de escama de dragao verde viva
227901	instrucoes peitoral ferro negro temperado
227902	molde peitoral de escama de dragao negro endurecida
227903	molde perneiras de escama de dragao negro endurecida
227904	molde omoplatas de escama de dragao negro endurecida
227905	instrucoes martelo magistral da tempestade do piloto aereo
227906	molde peitoral vulcanico magistral
227907	molde omoplatas vulcanicas magistrais
227908	molde perneiras vulcanicas magistrais
227909	instrucoes manoplas de placa abrasadoras da tecnica oculta
227910	molde manto cromatico brilhante
227911	cabeca do laceral mao negra
227912	divindade aplicada
227914	glandula pineal de feruja
227915	dominio do duque
227921	runa de facas
227922	runa do espadachim
227923	botinas d agua
227924	frasco incomum
227925	sinalizador de hidraxis
227926	coroacao hidraxiana
227927	juramento do mar
227928	chave da caixa de ferramentas
227930	chave do cofre
227931	pacote escondido
227932	pe de cabra enferrujado
227934	ira chamejante
227935	martelo do thane caido
227936	anel de diplomata
227937	caixa quebra cabeca
227938	estilhaco de luz
227939	estilhaco de luz
227940	espada do grao general
227941	ceifa almas
227947	brafoneiras para golem
227948	machado de batalha de forjaversa
227952	cota encadeada do gladiador selvagem
227955	elmo do gladiador selvagem
227956	peitoral causamortis
227957	grevas do gladiador selvagem
227958	fantasmalha
227959	coxotes do guardiao eterno
227960	colosso inexpugnavel
227961	guantes do gladiador selvagem
227962	espinho igneo
227963	lamina gravada em sangue
227964	kilt luminar
227965	botas pluriarranque
227967	folego renovado
227970	capa da salamandra de fogo
227971	punhos derretidos
227972	explosao de conhecimento
227973	circulo de fogo
227974	martelo de litomagma
227978	pedra magmus
227980	vestes da coroa real
227981	retaliador deimoforja
227982	baculo guia da sabedoria
227983	selo de ferro negro
227984	cetro real de thaurissan
227985	a capa nova do imperador
227986	munhequeiras do renome
227987	faixa da grande cacada
227988	joia da coroa
227990	mao da injustica
227991	inimigo de ferro
227992	escarpes do cavaleiro da morte
227993	cabo de ebano de marduque
227994	cajado atacaveira
227996	arco de ossos antigos
227997	espada da familia barov
227998	botas de malha sangrenta
227999	escarpes ossomorte
228000	guarda peito ossomorte
228001	omoplatas feitas de pedra
228002	cinturao ossomorte
228003	guarda pernas de malha sangrenta
228004	grevas assolaventos
228005	amarra de andros
228006	manoplas ossomorte
228007	corta gargulas
228008	guarda pernas ossomorte
228009	botas necropilas
228010	dragonas necropilas
228011	braceletes necropilos
228012	cota de malha sangrenta
228013	veste necropila
228014	cinto de malha sangrenta
228015	gadanhorror
228016	anel fracamente irisado
228017	calcas cranio fumegante
228018	perneiras necropilas
228019	coracao do demonio
228020	manoplas de malha sangrenta
228021	bruxilamina
228022	dever do diretor
228023	abraco de aline
228024	presa silente
228025	peitoral da lapide
228026	lamina de bosquenero
228027	decepador gelamina
228028	lamina de necromancia
228029	machado de guerra da lapide
228030	machado malicioso
228031	luvas nerumbra
228032	elmo de elo osseo
228033	martelo do poder divino
228034	mitenes tremelicantes
228036	garras da morte
228037	broquel range ossos
228038	calcas de tramaferrea
228039	tomo enfeiticado
228040	perneiras vultear
228041	perneiras placa da ira
228042	cinta de detencao
228044	perneiras da voragem
228045	anel necromantico
228046	anel da dominacao de dom mauricio
228047	anel do amalgama
228050	arco do satiro
228051	bastao de canalizacao quel dorei
228052	corta onda
228053	elmo fervente
228054	talisma da tempestade
228055	guarda peito energizado
228056	facao do diabo
228057	anel de potencia demoniaca
228058	espaldares de ferro volumosos
228059	omoplatas do vigia do covil
228060	manto heliotropico
228061	luvas fagulhantes
228062	capuz perceptivo
228063	vinculo de lenhatorta
228064	escudo do observador
228065	espaldares ciclonicos
228066	luvas de tramaferrea
228067	pingente de mago anciao
228068	cinto do trombadinha
228069	coxotes reforcados sobrenaturais
228070	cota forjada pelos ogros
228074	maos da tentacao
228075	lanca do destino
228076	anel de fogo ardente
228077	galho onirico
228078	calice amaldicoado
228079	manto de folhas
228080	anel de resina
228081	toxigermen germinante
228082	machado dos brado guerreiro
228083	coracao arboreo crepuscular
228084	extintor de incendio miniaturizado
228085	elo da legiao refaseado
228086	lamina de retalhador remanufaturada
228087	fita de moebius supercarregada de prata
228088	plaquinhas de identificacao do operador de retalhadores
228089	espreitaluna entalhado em madeira
228090	adaga ritual cenariana
228091	botas espinhentas
228092	manto druidico
228093	o coracao das trevas
228094	lamina do senhor do medo
228100	clamide do senhor do fogo
228101	pelego do beemote
228102	clamide do senescal
228103	grevas do nathrezim
228104	vestes de eluna
228105	nucleo de chama inextinguivel
228106	escudo da vida e morte
228107	arco longo da cacadora caida
228108	sombra do uivo sangrento
228109	guarda pernas do sacrificio
228111	mascara do assassino de deuses
228112	brial do pesadelo
228113	abraco gelido
228114	instrucoes retalhador de arcanita refinada
228117	instrucoes campeao de arcanita refinada
228118	instrucoes manoplas da fortaleza maior
228119	molde manoplas de democerne
228120	molde perneiras de democerne
228121	molde bolsa de runatrama reforcada em couro
228122	o nucleo derretido
228123	epifania jubilante
228124	epifania onirica
228125	campeao de arcanita refinada
228126	epifania aperitiva
228127	munhequeiras da instabilidade
228128	martelo da bigorna negra
228129	cranio da chama sombria
228130	protecao altruista
228131	protecao altruista
228132	batata de morto vivo
228133	magma ou lava
228134	atlas de kalimdor setentrional
228135	um estudo da luz
228136	cabum
228137	coracao de golemagg
228138	o cavaleiro e a senhora
228139	punho do devoto do fogo
228140	flagelo ameaca morta viva ou sociedade incompreendida
228141	introducao a necromancia
228142	terra e fogo
228143	espada de chama sombria
228144	anotacao estranha
228145	garra direita de magmadar
228146	garra esquerda de magmadar
228147	chifre de magmadar
228160	arauto da fe
228162	trapaca
228163	broche da prolemadre
228165	zagaia do mata dragoes
228166	chave da cidade
228168	polidor goblinico
228169	ajustador de atitude
228170	remo improvisado dos mares do sul
228171	porta moedas de kezan
228172	protecao de ilusao caninegro
228173	incunabulo do consagrado
228174	incunabulo do devoto
228175	incunabulo da diligencia sagrada
228176	totem do trovao
228177	totem do fogo em furia
228178	totem da vitalidade terrena
228179	totem das planicies
228180	idolo do enxame
228181	idolo do sangramento felino
228182	idolo do sangramento urso
228183	idolo do bosque
228184	varal goblinico
228185	garrafa quebrada de goblino noir
228186	alianca de casamento abandonada
228187	varinha dos mares do sul
228188	grampo de cabelo de prestor
228189	dadiva de gob
228190	conhecimento dos presamatos
228191	rochedo derretido cintilante
228214	monstro maca 2m forca incontrolavel
228222	manual de bravura de azeroth
228227	scroll of overwhelming power
228229	lamina afiada obsidiana
228230	martelo dos titas refinado
228239	veste do poder volatil
228240	coxotes do ardilante
228242	anel pesado de ferro negro
228243	anel do feitico poderoso
228244	perneiras da tempestade de mana
228245	calcas de escama de salamandra
228246	munhequeiras da estabilidade
228247	gargantilha do esclarecimento
228248	treme terra
228249	medalhao do poder estavel
228250	instrucoes manoplas da fortaleza maior
228251	molde manoplas de escama de dragao verde vivas
228252	marca do atirador
228253	escarpes do pisabrasa
228254	botas temperadas no magma
228255	talisma do poder efemero
228256	cordao da ignicao de mana
228257	luvas velhas de couro do nucleo
228258	espaldares da terra profunda
228259	grimorio runico de fogo
228260	manoplas da guarda ignea
228261	anel do golpe presto
228262	choque carmesim
228263	punhal do feiticeiro
228264	martelo petraura
228265	lamina da brutalidade
228266	disco do perfurador
228267	rasgatripas
228268	selo do arquimago
228269	magespada lazulicanto
228270	lanca pipoco
228271	cajado de dominancia
228272	golpe sombrio
228273	golpeforte
228274	elo da cauterizacao
228275	grevas forjadas no nucleo
228276	molde manto cambiante feito com maestria
228277	dente de cao magma
228278	draga de lava com isolamento hipertermico
228279	omoplatas da guarda de fogo
228280	manto a prova de fogo
228281	luvas da chama hipnotica
228282	faixa dos segredos sussurrados
228283	espaldares do crescimento silvestre
228284	munhequeiras do voo constante
228285	elmo do vivificador
228286	anel de accuria
228287	elo de sulfuras
228288	gume rasgaosso
228289	gargantilha do senhor do fogo
228290	manto envolto em brumas
228291	coroa da destruicao
228292	capa de sangue de dragao
228293	essencia da chama pura
228294	defensor de malistar
228295	cinturao da ofensiva
228296	lamina da perdicao
228297	estilhaco da chama
228298	estilhaco da escama
228299	ceifa espinhaco
228301	molde avambracos do voo veloz
228303	molde veste de lunatrama incandescente
228304	diagrama rifle de atirador de elite do nucleo de fogo
228305	instrucoes martelo dos titas refinado
228306	instrucoes profanacao
228307	instrucoes acerta peito mortal
228308	instrucoes tranquilidade
228309	molde peitoral de escama de dragao verde vivo
228310	instrucoes guardafria endurecida
228311	instrucoes martelo de batalha encantado com primor
228312	instrucoes malha invencivel
228313	instrucoes manoplas da tormenta
228314	instrucoes cimeira do grande chefe
228315	instrucoes lamina do sabio do arquimago
228316	molde colete de lunatrama incandescente
228317	molde diadema de lunatrama incandescente
228318	molde perneiras de lunatrama incandescente
228319	molde cinturao da percepcao arcana
228323	moeda da chacina de cobre
228324	moeda da chacina de ouro
228325	moeda da chacina de prata
228326	algibeira de moedas da chacina de cobre
228327	algibeira de moedas da chacina de prata
228332	lok delar baculo dos guardioes antigos
228334	rhok delar arco longo dos guardioes antigos
228335	bencao
228336	anatema
228340	cinturao de gelo que nao derrete
228345	perneiras da supremacia arcana
228347	tufao
228349	garra esquerda de eskhandar
228350	garra direita de eskhandar
228351	manoplas de couro da perdicao
228352	perneiras infusas em vileza
228353	jaula craniana infernal
228354	medalhao de ardenfuria
228355	cinto esfolado de demonarca
228356	guardiao do selo ambar
228357	bracadeiras luz negra
228359	elo da entropia
228360	pelagem de eskhandar
228381	ruptura do gelo
228382	presa dos misticos
228383	capa pujante
228384	sapatos ceganeve
228385	coroa adornada de cristais
228389	clamide de bencao
228397	demolidor empireo
228410	terroraco do destruidor
228432	apito da fera
228459	lamina afiada obsidiana
228460	ceifa espinhaco
228461	gume rasgaosso
228462	martelo petraura
228463	treme terra
228464	selo real de eldre thalas
228465	selo real de eldre thalas
228466	selo real de eldre thalas
228467	selo real de eldre thalas
228468	perneiras de liquen emaranhado
228469	anel elfico manchado
228470	perneiras de luaprata
228471	quebra pedra
228472	adaga de distracao
228473	malho inexoravel
228474	veste da onda mental
228475	dragonas diabolicas
228476	cinto ornado do arquimago
228477	molde cinto ornado do arquimago
228478	lamina barbara
228479	perneiras da destruicao
228480	coroa do rei ogro
228484	bastao dos magos ogros
228486	perdicao do arvoroso
228498	terroraco do destruidor
228500	mascara do imperdoavel
228501	blusa ornicanto
228502	flautim do fogo flamejante
228503	tanga do menestrel saracoteante
228504	cinturao do arco iris
228505	manto do tribunal real
228506	lamina da brutalidade
228508	martelo da bigorna negra
228511	lamina da perdicao
228513	avambracos do sadico
228514	galochas do timmy
228515	laco da violencia
228516	pacificador
228517	magespada lazulicanto
228518	manilhas do magistrado
228519	marca do atirador
228520	dragonas roubalmas
228521	mitenes de renda sombria
228522	obus portatil do gualter
228523	fura bloqueio
228524	o selo do chefe do correio
228525	a tunica do chefe do correio
228527	as calcas do chefe do correio
228528	a bandana do chefe do correio
228529	as botinas do chefe do correio
228530	guarda pernas de placa quitinoso
228531	faixa de thuzadin
228532	bracadeiras de morlune
228533	colar de concha iridescente
228534	perneiras do cao pestilento
228535	machadinha corta osso
228536	estrela de mystaria
228537	manoplas dracorias
228538	marca de rivendare
228539	livro dos mortos
228540	coroa da tirania
228541	dadiva dos magos elficos
228542	aniquilador forjacranio
228543	lamina runica do barao rivendare
228544	martelo do grande cruzado
228545	elmo do grao cruzado
228546	mortalha dos nathrezim
228547	veste de tramaferrea
228548	cetro da concentracao interminavel
228551	tunica da lua crescente
228552	manoplas de destreza
228553	elmo do carrasco
228554	luvas de pele de demonio
228555	lamina fase
228556	avental do acougueiro
228557	botas de batalha dardejantes
228558	manilhas funereas
228559	corvonegro
228561	manoplas miracerta
228562	espaldares com runas demoniacas
228563	globo de d sak
228564	botas do vigia da torre ogra
228565	anel do mago
228566	tiara do fogo estelar
228567	cinturao do cinzelador
228568	manoplas backorianas
228570	punho de omokk
228571	peitoral do rei xama
228572	guarda bracos de cernecupreo
228573	cospeconha
228574	talisma da evasao
228575	bracadeiras garracortante
228576	olho de queimateia
228577	manoplas douradas
228578	faixa plumafina
228579	cinturao cristalizado
228583	omoplatas golpecerto
228584	talisma furiarrubra
228585	marca do senhor dos dragoes
228586	cravija
228587	cajado do refugio
228588	garras do gatuno
228589	coracao da escama
228590	dragonas do fendevidente
228591	protetor rumbarbo
228592	presa da aranha de cristal
228593	botas do dancarino dos ventos
228594	botas de precisao do kayser
228595	cinturao do atirador perito
228596	cinto de tramaferrea
228597	botas de tramaferrea
228598	bracadeiras de tramaferrea
228599	coracao de wyrmthalak
228600	quebra queixo
228601	foice implacavel
228602	pisa chamas
228603	serra maldita do mao negra
228604	olho de laceral
228605	ombreiras de espetosso
228606	lamina negra de shahram
228615	tesouro sobrenatural
228650	guarda pernas do mestre guerreiro
228651	braceleiras belinato
228652	guardiao tribal de dal rend
228653	encargo sagrado de dal rend
228659	baculo antigo cinzelado com runas
228660	perneiras do mestre de espadas
228661	guarda pernas de tristam
228662	guarda bracos de brumanegra
228663	manto de sangreluna
228664	capa do tecegelo
228666	salgueiro intruso
228667	elo tecemagoa
228669	dente de gnarr
228670	cinturao de brigam
228672	cinturao artesanal do mestre ferreiro
228675	elo da ruminacao
228676	cinturao torrente feral
228677	turbante do tecencantos
228678	emblema draconico infuso
228679	quel serrar
228680	compendio do abate de dragoes de nostro
228681	capucho de tramaferrea
228682	cajado de comando do senhor valthalak
228683	elo runico da bruxaria
228684	pingente da celeridade
228685	pingente de dente de onyxia
228686	talisma de sangue de onyxia
228687	sinete do mata dragoes
228688	cabeca da onyxia
228689	cabeca da onyxia
228690	a luz e como ativa la
228691	garona um estudo sobre furtividade e traicao
228692	codice de defesa
228693	livro de receitas do arcanista
228695	lamina elfica lisa e cega
228696	lamina ancestral incandescente
228697	lamina ancestral temperada
228699	anel do logro demoniaco
228700	dragonas de tramaferrea
228701	dente de cao magma
228702	disco do perfurador
228703	sapatilhas petralgida
228704	capuz de couro esfarrapado
228722	mao da justica
228746	mecanostruz verde fluorescente
228747	redeas do gato de sabre dourado
228748	apito do raptor sanguineo mosqueado
228749	lasca de nordrassil
228757	adagavil
228759	coleira de eskhandar
228797	grimorio de armadura vil
228912	chave do deposito de artefatos
228922	cajado de dominancia
228924	botas ferro negro temperadas
228925	botas ferro negro temperadas
228926	botas ferro negro temperadas
228927	botas ferro negro temperadas
228928	botas ferro negro temperadas
228929	botas ferro negro temperadas
228955	grimorio antigo da pedra angular
228978	signo encantado aguas abundantes
228979	signo encantado aguas abundantes
228980	revestimento de escudo condutivo
228981	formula revestimento de escudo condutivo
228982	formula encantamento de lei da natureza escudo
228992	mochila de pelego da onyxia
228993	molde bolsa sem fundo
228994	bolsa sem fundo
229008	formula encantamento maior de resistencia ao fogo manto
229009	formula encantamento maior de resistencia a natureza manto
229055	seda aranasi puida
229056	pedaco de pedra pomes
229057	mercadorias apreendidas
229352	descobertas da inteligencia
229362	chave do armazem
229372	rasgatripas
229373	arauto da fe
229374	punho do devoto do fogo
229376	punhal do feiticeiro
229377	garra esquerda de magmadar
229378	garra direita de magmadar
229379	garra direita de eskhandar
229380	golpe sombrio
229381	golpeforte
229382	draga de lava com isolamento hipertermico
229415	suprimentos de sobrevivencia
229416	pelo quentinho
229749	portadora da verdade
229806	portadora da verdade
229894	esmeralda onirica
229897	pergaminho criar sinete chamariz
229906	escama de bronze maculado
229909	cajado da ordem
229910	foice do caos
229911	comedor de sonhos de caius
229964	casco do lorde demonio
229965	o olho de az olgothal
229966	torque do punho de prata
229971	cajado do inferno
229972	cajado da geada
230002	finalizador mortal
230018	fragmentos do orbe de mannoroc
230224	tormentaria lamina sagrada do perseguidor dos ventos
230237	gema arcana infusa
230238	o livro preto
230239	luvas da rapida evolucao
230240	dragonas do conciliabulo do asa negra
230241	quebra espinha
230242	a lamina indomavel
230243	gema do pensapresto
230244	signo do metamorfo
230245	pingente do dragao caido
230246	elmo da raiva infinita
230247	lamina dendragonia
230248	protetor de escama de dragao vermelho
230249	gema da vivificacao
230250	totem peconhento
230251	brafoneiras de couraca preta
230252	bracadeiras da precisao arcana
230253	furapeito
230254	maladath lamina runica da revoada negra
230255	cinto de couro de dragao retesado
230256	brafoneiras de garra de draco
230257	anel de rocha negra
230269	gema rejuvenescedora
230270	cajado de foco da asa sombria
230271	cutelo de garra de draco
230272	pergaminhos de luz cegante
230273	cristal de alinhamento natural
230274	veste freixo preto
230275	amarra do fogorja
230276	garra do draco preto
230277	manto do fogorja
230278	guarda pernas do cruzado caido
230279	guarda pernas articulados do primalista
230280	egide de preservacao
230281	elo da concentracao forcada
230282	talisma de presa de draco
230723	luvas da chama ebanea
230725	baluarte abencoado de malfurion
230726	carabina bafo de dragao
230733	mortalha do pensamento puro
230734	circulo da forca aplicada
230735	perneiras de tecebrasa
230736	escaravelho iminente de styleen
230737	toque do dragao
230738	arauto do sofrimento
230739	garra da angelista
230740	ombreiras de couro de dragao retesado
230741	botas cromaticas
230742	luvas de couro de dragao retesado
230743	geta cintilante
230744	manto tecido com elementio
230745	cinturao do cruzado caido
230746	perneiras carregadas
230747	espada temperada cromaticamente
230751	obi ninja
230794	garra de cromaggus
230800	cinta articulada do primalista
230801	ashjre thul besta da punicao
230802	baluarte reforcado de elementio
230804	manto do senhor da prole
230805	botas da chama sombria
230806	elo de therazane
230808	anel do discernimento de archimtiros
230810	lagrima de neltharion
230811	elo de elementio puro
230812	mish undare diadema do esfolador mental
230813	cajado da chama sombria
230818	ashkandi montante da irmandade
230837	crul shorukh beira do caos
230838	lok amir il romathis
230839	anel do mestre mata dragoes
230840	medalhao do mestre mata dragoes
230841	orbe do mestre mata dragoes
230842	manto do poder draconico
230843	botas do pensamento puro
230844	marreta draconica
230845	gume da perdicao
230846	elo do dominio sombrio
230847	coletador de essencias
230848	gibao entrelacado das sombras
230849	botas da nevasca do ringo
230854	anel de servidao
230855	selo do berserker gurubashi
230856	cinto do poder libertado
230857	mascara ensanguentada
230858	manto dos adoradores hakkari
230859	luvas do atormentado
230860	poder da tribo
230861	manoplas sacrificais
230862	turbante zulian
230863	cetro ritual zulian
230864	cota runica manchada de sangue
230865	presas de venoxis
230866	pisantes banhados em sangue
230867	anel de zanzil
230868	martelo de pedra zulian
230903	pergaminho essencia do fogo
230904	pergaminho eassenic od ofog
230908	essencia do fogo imbuida
230909	essencia do fogo esgotada
230911	esmagador da jeklik
230912	espaldares do animista
230913	talisma de opalina da jeklik
230914	botas do pacificador
230915	anel do primalista
230916	botas da furia dos mares
230917	vestes rituais esvoacantes
230918	toque da mar li
230919	grevas manchadas de sangue
230920	olho da mar li
230921	anel de jin
230922	talisma de protecao
230923	botas do traidor
230925	soqueira do thekal
230926	perneiras do pacificador
230927	guarda pernas rituais
230928	perneiras da furia dos mares
230929	selo de jin
230930	fatiador zulian
230934	soqueira da arlokk
230939	proposito de arlokk
230941	bastao azarento da arlokk
230942	grevas banhadas em sangue
230943	anel de onix do lorde supremo
230944	bolsa de pelego de pantera
230946	pergaminho eassenic od elgo
230947	pergaminho essencia do gelo
230948	essencia do gelo imbuida
230949	essencia do gelo esgotada
230984	cajado da ordem incompleto
230989	defensor do sangrelorde
230991	alabarda de punicao
230992	lamina de guerra dos hakkari
230993	ferrao do mandokir
230994	perneiras do animista
230995	manoplas banhadas em sangue
230996	brafoneiras banhadas em sangue
230997	kilt tinto de sangue
230998	manto do loa hakkari
230999	anel carmesim do lorde supremo
231000	selo do primalista
231001	selo de zanzil
231002	martelo de jin do
231003	mau olhado de jin do
231004	julgamento de jin do
231005	saco de sortilegios de jin do
231006	botas do animista
231007	coifa manchada de sangue
231008	coxotes manchados de sangue
231009	perneiras banhadas em sangue
231010	manoplas banhadas em sangue
231011	luvas tingidas de sangue
231012	abraco do lorde supremo
231013	mantel do bagateiro
231014	tapa olho de escama de lagarto
231015	mascara de sarja
231016	exterminador de peixes de nat pagle
231023	munhequeiras da ira
231024	cinta da ira
231025	brafoneiras da ira
231026	guarda pernas da ira
231027	viseira da ira
231028	protetores de mao da ira
231029	escarpes da ira
231030	couraca da ira
231031	bracadeiras da ira
231032	cinto da ira
231033	omoplatas da ira
231034	coxotes da ira
231035	elmo da ira
231036	manoplas da ira
231037	grevas da ira
231038	peitoral da ira
231039	espaldares dentessangue
231040	peito d armas dentessangue
231041	botas dentessangue
231042	luvas dentessangue
231043	capuz dentessangue
231044	calcas dentessangue
231045	cinto dentessangue
231046	bracadeiras dentessangue
231047	ombreiras dentessangue
231048	couraca dentessangue
231049	pisantes dentessangue
231050	protetores de mao dentessangue
231051	capucho dentessangue
231052	guarda pernas dentessangue
231053	cinta dentessangue
231054	munhequeiras dentessangue
231055	bracadeiras do espreita dragao
231056	cinto do espreita dragao
231057	espaldares do espreita dragao
231058	guarda pernas do espreita dragao
231059	elmo do espreita dragao
231060	manoplas do espreita dragao
231061	grevas do espreita dragao
231062	peitoral do espreita dragao
231063	avambracos do espreita dragao
231065	cinturao do espreita dragao
231066	brafoneiras do espreita dragao
231067	calcas do espreita dragao
231068	morriao do espreita dragao
231069	guantes do espreita dragao
231070	escarpes do espreita dragao
231071	armadura do espreita dragao
231072	botas da nemesis
231073	luvas da nemesis
231074	casquete da nemesis
231075	perneiras da nemesis
231076	vestes da nemesis
231077	espaldares da nemesis
231078	cinto da nemesis
231079	bracadeiras da nemesis
231090	botinas da nemesis
231091	protetores de mao da nemesis
231092	capucho da nemesis
231093	calcas da nemesis
231095	induto da nemesis
231096	ombreiras da nemesis
231097	cordao da nemesis
231098	munhequeiras da nemesis
231100	cinto do vento etereo
231101	botas do vento etereo
231102	luvas do vento etereo
231103	coroa do vento etereo
231104	calcas do vento etereo
231105	vestes do vento etereo
231106	dragonas do vento etereo
231107	bracadeiras do vento etereo
231108	faixa do vento etereo
231109	sapatilhas do vento etereo
231110	luvetes do vento etereo
231111	mascara do vento etereo
231112	perneiras do vento etereo
231113	vestimenta do vento etereo
231114	omoplatas do vento etereo
231115	munhequeiras do vento etereo
231155	botas da transcendencia
231156	protetores de mao da transcendencia
231157	halo da transcendencia
231158	perneiras da transcendencia
231159	vestes da transcendencia
231160	brafoneiras da transcendencia
231161	cinto da transcendencia
231162	bracadeiras da transcendencia
231165	botinas da transcendencia
231166	luvas da transcendencia
231167	coroa da transcendencia
231168	calcas da transcendencia
231169	induto da transcendencia
231170	dragonas da transcendencia
231171	cordao da transcendencia
231172	bracadeiras da transcendencia
231174	bracadeiras do julgamento
231175	cinto do julgamento
231176	espaldares do julgamento
231177	coxotes do julgamento
231178	coroa do julgamento
231179	manoplas do julgamento
231180	escarpes do julgamento
231181	peitoral do julgamento
231182	avambracos do julgamento
231183	cinta do julgamento
231184	brafoneiras do julgamento
231185	guarda pernas de mao do julgamento
231186	grande elmo do julgamento
231187	couraca do julgamento
231188	protetores de mao do julgamento
231189	grevas do julgamento
231190	bracadeiras do julgamento
231191	cinturao do julgamento
231192	dragonas do julgamento
231193	saiote de placas do julgamento
231194	elmo do julgamento
231195	luvas do julgamento
231196	botinas do julgamento
231197	corselete do julgamento
231198	manoplas das dez tempestades
231199	bracadeiras das dez tempestades
231200	cinto das dez tempestades
231201	palas das dez tempestades
231202	coxotes das dez tempestades
231203	capacete das dez tempestades
231204	grevas das dez tempestades
231205	peitoral das dez tempestades
231206	protetores de mao das dez tempestades
231207	munhequeiras das dez tempestades
231208	cinta das dez tempestades
231209	brafoneiras das dez tempestades
231210	guarda pernas das dez tempestades
231211	viseira das dez tempestades
231212	escarpes das dez tempestades
231213	couraca das dez tempestades
231214	luvas das dez tempestades
231215	braceletes das dez tempestades
231216	cordao das dez tempestades
231217	dragonas das dez tempestades
231218	kilt das dez tempestades
231219	cocar das dez tempestades
231220	botas das dez tempestades
231221	abraco das dez tempestades
231222	guantes das dez tempestades
231223	avambracos das dez tempestades
231224	cinturao das dez tempestades
231225	espaldares das dez tempestades
231226	perneiras das dez tempestades
231227	coroa das dez tempestades
231228	botinas das dez tempestades
231229	armadura das dez tempestades
231230	couraca tempesfuria
231231	botas tempesfuria
231232	protetores de mao tempesfuria
231233	mantel tempesfuria
231234	guarda pernas tempesfuria
231235	brafoneiras tempesfuria
231236	cinto tempesfuria
231237	bracadeiras tempesfuria
231238	armadura tempesfuria
231239	botinas tempesfuria
231240	manoplas tempesfuria
231241	cocar tempesfuria
231242	perneiras tempesfuria
231243	espaldares tempesfuria
231244	cinta tempesfuria
231245	munhequeiras tempesfuria
231246	couros tempesfuria
231247	sandalias tempesfuria
231248	luvetes tempesfuria
231249	galhadura tempesfuria
231250	kilt tempesfuria
231251	dragonas tempesfuria
231252	cordao tempesfuria
231253	braceletes tempesfuria
231254	colete tempesfuria
231255	pisoteadores tempesfuria
231256	guantes tempesfuria
231257	capucho tempesfuria
231258	calcotes tempesfuria
231259	ombreiras tempesfuria
231260	faixa tempesfuria
231261	munhequeiras tempesfuria
231271	carretel quebrado do nat pagle
231272	arpao de tigule
231273	buril do gri lek
231274	triturador do gri lek
231275	vingador ardenfuria
231276	o destruidor de pensamentos
231277	forcado da loucura
231278	arco de caca azarento
231279	aticador de vuxulai
231280	patua natural de vuxulai
231281	patua espiritual de vuxulai
231282	patua de magia gelada de hazza rah
231283	patua de protecao de hazza rah
231284	patua destruidor de hazza rah
231285	patua valoroso de gri lek
231286	patua do poder de gri lek
231287	patua ardiloso de renataki
231288	patua devastador de renataki
231289	egide do deus sangrento
231293	antigo matador de homens hakkari
231296	chama sangue
231298	pergaminho da recomposicao espacial inferior
231299	coxotes banhados em sangue
231300	manto da consumicao
231301	presas dos sem rosto
231302	destruidor gurubashi de anoes
231303	manoplas do pacificador
231304	pergaminho cacoperoimos selapcia orferini
231305	manoplas da furia dos mares
231306	colar do corruptor de almas
231307	olho de hakkar
231308	toque do caos
231309	lamina de guerra dos hakkari
231315	zin rokh a destruidora de mundos
231316	alga encantada dos mares do sul imaculada
231317	tunica do haruspice zandalar
231318	cinto do haruspice zandalar
231319	bracadeiras do haruspice zandalar
231320	ira da voragem
231321	dragonas do predador zandalar
231322	cinto do predador zandalar
231323	bracadeiras do predador zandalar
231324	joia de jakaro
231325	dragonas do ilusionista zandalar
231326	bracelete do ilusionista zandalar
231327	veste do ilusionista zandalar
231328	marca do heroi
231329	peitoral do livre pensador zandalar
231330	cinto do livre pensador zandalar
231331	bracadeiras do livre pensador zandalar
231332	olho que tudo ve de zuldazar
231333	dragonas do confessor zandalar
231334	cinturao do confessor zandalar
231335	bracadeiras do confessor zandalar
231336	talisma zandalariano de dominio das sombras
231337	tunica do lunatico zandalar
231338	dragonas do lunatico zandalar
231339	bracadeiras do lunatico zandalar
231340	visao imaculada de voduria
231341	cota do augure zandalar
231342	cinto do augure zandalar
231343	bracadeiras do augure zandalar
231346	macula irrefreavel de kezan
231347	bracadeiras do demoniaco zandalar
231348	veste do demoniaco zandalar
231349	dragonas do demoniaco zandalar
231350	raiva de mugamba
231351	bracadeiras do vindicante zandalar
231352	cinto do vindicante zandalar
231353	peitoral do vindicante zandalar
231354	caricia do animista
231355	equilibrio do animista
231357	furia do animista
231358	rugido do animista
231359	chamado do falcao
231361	selo do sincretista
231362	signo do sincretista
231363	brasao do sincretista
231364	emblema do sincretista
231366	aura profetica
231367	maldicao profetica
231368	abraco da morte
231370	avanco da morte
231371	abraco do voduzeiro
231372	mortalha do voduzeiro
231373	patua do voduzeiro
231375	vigilancia do voduzeiro
231376	mandinga azarenta
231377	maldicao azarenta
231378	disco dourado cintilante
231379	presenca de poder
231381	presenca da bravura
231382	casulo de renascimento
231383	presenca de visao
231384	furia do falcao
231385	simulacro da alma dragonica
231386	escama de dragao negro impecavel
231387	ira da tempestade espadim santificado do perseguidor de vendavais
231452	sangue do arauto da luz
231460	quebraplanos de azgaloth
231466	codice do bruxo asa negra
231509	tomo de cassandra
231512	idolo hakkari primevo
231513	sangue de gri lek
231514	dente de renataki
231515	juba de vuxulai
231516	fio dos sonhos de hazza rah
231517	boneca vodu perfurada
231518	boneca vodu perfurada
231519	boneca vodu perfurada
231520	boneca vodu perfurada
231521	boneca vodu perfurada
231522	boneca vodu perfurada
231523	boneca vodu perfurada
231524	boneca vodu perfurada
231525	boneca vodu perfurada
231530	armadura de placa do senhor da guerra
231531	botas de placa do general
231532	manoplas de placa do general
231533	perneiras de placa do general
231534	omoplatas de placa do senhor da guerra
231535	bacinete de placa do senhor da guerra
231536	armadura de placa do marechal de campo
231537	guarda ombros de placa do marechal de campo
231538	elmo de placa do marechal de campo
231539	botas de placa do marechal
231540	guarda pernas de placa do marechal
231541	manoplas de placa do marechal
231543	peito d armas de couro do marechal de campo
231544	guantes de couro do marechal
231545	mascara de couro do marechal de campo
231546	guarda pes de couro do marechal
231547	palas de couro do marechal de campo
231548	perneiras de couro do marechal
231549	peitoral de couro do senhor da guerra
231551	espaldares de couro do senhor da guerra
231552	botinas de couro do general
231553	elmo de couro do senhor da guerra
231554	guarda pernas de couro do general
231555	luvas de couro do general
231557	brafoneiras encadeadas do marechal de campo
231558	coxotes encadeados do marechal
231560	guantes encadeados do marechal
231561	escarpes encadeados do marechal
231562	grande elmo encadeado do marechal de campo
231563	armadura encadeada do marechal de campo
231564	escarpes encadeados do general
231565	brafoneiras encadeadas do senhor da guerra
231566	armadura encadeada do senhor da guerra
231567	coxotes encadeados do general
231568	grande elmo encadeado do senhor da guerra
231569	guantes encadeados do general
231570	grevas encadeadas do general
231571	elmo encadeado do senhor da guerra
231572	omoplatas encadeadas do senhor da guerra
231573	cota encadeada do senhor da guerra
231574	guarda pernas encadeados do general
231575	luvas antiderrapantes encadeadas do general
231576	omoplatas encadeadas do marechal de campo
231577	guarda pernas encadeados do marechal
231578	luvas antiderrapantes encadeadas do marechal
231579	grevas encadeadas do marechal
231580	elmo encadeado do marechal de campo
231581	cota encadeada do marechal de campo
231582	veste de medotrama do marechal de campo
231583	omoplatas de medotrama do marechal de campo
231584	diadema do marechal de campo
231585	botas de medotrama do marechal
231586	luvas de medotrama do marechal
231587	perneiras de medotrama do marechal
231588	calcas de medotrama do general
231589	luvas de medotrama do general
231590	capuz de medotrama do senhor da guerra
231591	veste de medotrama do senhor da guerra
231592	dragonas de medotrama do senhor da guerra
231593	botas de medotrama do general
231594	sobreveste de seda do senhor da guerra
231595	calcas de seda do general
231596	traje de seda do senhor da guerra
231597	botas de seda do general
231598	luvas de seda do general
231599	manoplas de seda do general
231600	mitenes de seda do general
231601	capucho de seda do senhor da guerra
231602	espaldares de seda do marechal de campo
231603	vestimenta de seda do marechal de campo
231604	coroa do marechal de campo
231605	perneiras de seda do marechal
231606	palmilhas de seda do marechal
231607	luvas de seda do marechal
231608	manoplas de seda do marechal
231609	mitenes de seda do marechal
231610	botinas de cetim do general
231611	palas de cetim do senhor da guerra
231612	vestes de cetim do senhor da guerra
231613	guantes de cetim do general
231614	perneiras de cetim do general
231615	coroa de cetim do senhor da guerra
231616	coroa de cetim do marechal de campo
231617	guantes de cetim do marechal
231618	veste de cetim do marechal de campo
231619	perneiras de cetim do marechal
231620	botinas de cetim do marechal
231621	palas de cetim do marechal de campo
231622	capuz de cetim do marechal de campo
231623	mitenes de cetim do marechal
231624	tunica de cetim do marechal de campo
231626	guarda pernas de cetim do marechal
231627	chancas de cetim do marechal
231628	dragonas de cetim do marechal de campo
231630	chancas de cetim do general
231631	dragonas de cetim do senhor da guerra
231632	tunica de cetim do senhor da guerra
231633	mitenes de cetim do general
231634	guarda pernas de cetim do general
231635	capuz de cetim do senhor da guerra
231639	guarda pernas lamelares do marechal
231640	capacete lamelar do marechal de campo
231641	guarda peito lamelar do marechal de campo
231642	bolsa de herborismo do vigilante
231643	luvas lamelares do marechal
231644	bolsa de encantamento do vigilante
231645	brafoneiras lamelares do marechal de campo
231646	grevas lamelares do marechal
231647	perneiras lamelares do marechal
231648	cimeira lamelar do marechal de campo
231649	peitoral lamelar do marechal de campo
231650	manoplas lamelares do marechal
231651	omoplatas lamelares do marechal de campo
231652	escarpes lamelares do marechal
231653	cota de malha do senhor da guerra
231654	brafoneiras de malha do senhor da guerra
231655	luvas antiderrapantes de malha do general
231656	grevas de malha do general
231657	cimeira de malha do senhor da guerra
231658	guarda pernas de malha do general
231659	espaldares de malha do senhor da guerra
231660	manoplas de malha do general
231661	escarpes de malha do general
231662	peitoral de malha do senhor da guerra
231663	elmo de malha do senhor da guerra
231664	perneiras de malha do general
231665	palas de malha do senhor da guerra
231666	luvas de malha do general
231667	botas de malha do general
231668	couraca de malha do senhor da guerra
231669	morriao de malha do senhor da guerra
231670	calcas de malha do general
231671	grevas de couro de dragao do general
231672	brafoneiras de couro de dragao do senhor da guerra
231673	guarda pernas de couro de dragao do general
231674	tunica de couro de dragao do senhor da guerra
231675	cocar de couro de dragao do senhor da guerra
231676	manoplas de couro de dragao do general
231677	luvas de couro de dragao do general
231678	elmo de couro de dragao do senhor da guerra
231679	armadura de couro de dragao do senhor da guerra
231680	calcas de couro de dragao do general
231681	espaldares de couro de dragao do senhor da guerra
231682	botas de couro de dragao do general
231683	botinas de couro de dragao do general
231684	omoplatas de couro de dragao do senhor da guerra
231685	perneiras de couro de dragao do general
231686	peito d armas de couro de dragao do senhor da guerra
231687	cimeira de couro de dragao do senhor da guerra
231688	guantes de couro de dragao do general
231689	cimeira de couro de dragao do marechal de campo
231690	peito d armas de couro de dragao do marechal de campo
231691	perneiras de couro de dragao do marechal
231692	botinas de couro de dragao do marechal
231693	omoplatas de couro de dragao do marechal de campo
231694	guantes de couro de dragao do marechal
231695	elmo de couro de dragao do marechal de campo
231696	armadura de couro de dragao do marechal de campo
231697	calcas de couro de dragao do marechal
231698	botas de couro de dragao do marechal
231699	espaldares de couro de dragao do marechal de campo
231700	luvas de couro de dragao do marechal
231701	cocar de couro de dragao do marechal de campo
231702	tunica de couro de dragao do marechal de campo
231703	guarda pernas de couro de dragao do marechal
231704	grevas de couro de dragao do marechal
231705	brafoneiras de couro de dragao do marechal de campo
231706	manoplas de couro de dragao do marechal
231707	braceletes draconianos
231708	cinto draconiano
231709	ombreiras draconianas
231710	perneiras draconianas
231711	capuz draconiano
231712	luvas draconianas
231713	botas draconianas
231714	veste draconiana
231715	braceletes primevos
231716	cinto primevo
231717	ombreiras primevas
231718	perneiras primevas
231719	elmo primevo
231720	luvas primevas
231721	botas primevas
231722	foice do caos esgotada
231723	bau primevo
231724	braceletes antigos
231725	cinto antigo
231726	ombreiras antigas
231727	perneiras antigas
231728	elmo antigo
231729	luvas antigas
231730	botas antigas
231731	bau antigo
231732	suprimentos suspeitos
231752	t3 monstro espada alianca de 2m
231753	consolo da muralha celeste
231754	francelho
231755	peregrino
231777	membro de qiraji cristalizado
231778	agua da fonte montanhosa
231779	ira de wray
231780	tomo de conjurar agua viii
231781	alma do trovao
231782	coroa do sucessor
231783	clamide do senhor do vento
231784	celula de raios
231785	ecos da traicao
231789	signo do guardiao
231792	alma de diabrura
231793	foice do caos esgotada diabrura
231794	foice do caos esgotada caos
231795	foice do caos esgotada enfeiticamento
231796	foice do caos esgotada devoracao
231797	alma do caos
231798	alma de enfeiticamento
231799	alma de devoracao
231800	alma de des altek
231803	talisma da conspiracao do prestor
231806	flecha calcinante
231807	tiro calcinante
231811	incunabulo da estupefacao
231814	coracao cromatico
231815	lancelesto
231817	golpe de vento
231823	glaive de geddon
231828	runa de especializacao em meditacao
231829	runa de especializacao em cura
231836	pergaminho da recomposicao espacial chamejante
231837	entalhe sombrio
231841	sangue do arauto da luz
231842	baculo de nandieb
231843	primeiro fragmento de signo
231844	segundo fragmento de signo
231845	terceiro fragmento de signo
231846	buril do gri lek
231847	triturador do gri lek
231848	exterminador de peixes de nat pagle
231849	arpao de tigule
231850	proposito de arlokk
231851	soqueira da arlokk
231852	destruidor gurubashi de anoes
231853	lamina de guerra dos hakkari
231854	zin rokh a destruidora de mundos
231855	presas dos sem rosto
231856	antigo matador de homens hakkari
231857	toque do caos
231858	chama sangue
231859	martelo de jin do
231860	julgamento de jin do
231861	esmagador da jeklik
231862	vingador ardenfuria
231863	destruidora de pensamentos
231864	forcado da loucura
231865	cetro ritual zulian
231866	toque da mar li
231867	defensor do sangrelorde
231868	ferrao do mandokir
231869	lamina de guerra dos hakkari
231870	alabarda de punicao
231871	aticador de vuxulai
231872	arco de caca azarento
231873	martelo de pedra zulian
231874	presas de venoxis
231875	soqueira do thekal
231876	fatiador zulian
231882	recibo do dispositivo de supressao
231885	gelido lamento
231890	terrestris
231891	tratado do falcao
231901	portador da verdade
231902	amuleto de aida
231903	pedaco de tecido rasgado
231904	trompa maculada
231909	luz estelar cristalizada
231910	coracao de azgaloth
231911	sinete do general da legiao
231912	lamina do abismo
231913	olho do observador
231995	escoria de elementio endurecida
231996	gobmogrificador supercarregado
232018	lamina latente beijada pelo vento
232079	braceletes tempesfuria
232080	cordao tempesfuria
232081	dragonas tempesfuria
232082	kilt tempesfuria
232083	galhadura tempesfuria
232084	luvetes tempesfuria
232085	sandalias tempesfuria
232086	couros tempesfuria
232087	bracadeiras tempesfuria
232088	cinto tempesfuria
232089	brafoneiras tempesfuria
232090	guarda pernas tempesfuria
232091	mantel tempesfuria
232092	protetores de mao tempesfuria
232093	botas tempesfuria
232094	couraca tempesfuria
232095	munhequeiras tempesfuria
232096	faixa tempesfuria
232097	ombreiras tempesfuria
232098	calcotes tempesfuria
232099	capucho tempesfuria
232100	guantes tempesfuria
232101	pisoteadores tempesfuria
232102	colete tempesfuria
232103	munhequeiras tempesfuria
232104	cinta tempesfuria
232105	espaldares tempesfuria
232106	perneiras tempesfuria
232107	cocar tempesfuria
232108	manoplas tempesfuria
232109	botinas tempesfuria
232110	armadura tempesfuria
232111	avambracos do espreita dragao
232112	cinturao do espreita dragao
232113	brafoneiras do espreita dragao
232114	calcas do espreita dragao
232115	morriao do espreita dragao
232116	guantes do espreita dragao
232117	escarpes do espreita dragao
232118	armadura do espreita dragao
232119	bracadeiras do espreita dragao
232120	cinto do espreita dragao
232121	espaldares do espreita dragao
232122	guarda pernas do espreita dragao
232123	elmo do espreita dragao
232124	manoplas do espreita dragao
232125	grevas do espreita dragao
232126	peitoral do espreita dragao
232127	bracadeiras do vento etereo
232128	cinto do vento etereo
232129	dragonas do vento etereo
232130	calcas do vento etereo
232131	coroa do vento etereo
232132	luvas do vento etereo
232133	botas do vento etereo
232134	vestes do vento etereo
232135	munhequeiras do vento etereo
232136	faixa do vento etereo
232137	omoplatas do vento etereo
232138	perneiras do vento etereo
232139	mascara do vento etereo
232140	luvetes do vento etereo
232141	sapatilhas do vento etereo
232142	vestimenta do vento etereo
232143	bracadeiras do julgamento
232144	cinto do julgamento
232145	espaldares do julgamento
232146	coxotes do julgamento
232147	coroa do julgamento
232148	manoplas do julgamento
232149	escarpes do julgamento
232150	peitoral do julgamento
232151	bracadeiras do julgamento
232152	cinturao do julgamento
232153	dragonas do julgamento
232154	saiote de placas do julgamento
232155	elmo do julgamento
232156	luvas do julgamento
232157	botinas do julgamento
232158	corselete do julgamento
232159	avambracos do julgamento
232160	cinta do julgamento
232161	brafoneiras do julgamento
232162	guarda pernas de mao do julgamento
232163	grande elmo do julgamento
232164	protetores de mao do julgamento
232165	grevas do julgamento
232166	couraca do julgamento
232167	bracadeiras da transcendencia
232168	cordao da transcendencia
232169	dragonas da transcendencia
232170	calcas da transcendencia
232171	coroa da transcendencia
232172	luvas da transcendencia
232173	botinas da transcendencia
232174	induto da transcendencia
232175	bracadeiras da transcendencia
232176	cinto da transcendencia
232177	brafoneiras da transcendencia
232178	perneiras da transcendencia
232179	halo da transcendencia
232180	protetores de mao da transcendencia
232181	botas da transcendencia
232182	vestes da transcendencia
232183	bracadeiras dentessangue
232184	cinto dentessangue
232185	espaldares dentessangue
232186	calcas dentessangue
232187	capuz dentessangue
232188	luvas dentessangue
232189	botas dentessangue
232190	peito d armas dentessangue
232191	munhequeiras dentessangue
232192	cinta dentessangue
232193	ombreiras dentessangue
232194	guarda pernas dentessangue
232195	capucho dentessangue
232196	protetores de mao dentessangue
232197	pisantes dentessangue
232198	couraca dentessangue
232199	braceletes das dez tempestades
232200	cordao das dez tempestades
232201	dragonas das dez tempestades
232202	kilt das dez tempestades
232203	cocar das dez tempestades
232204	luvas das dez tempestades
232205	botas das dez tempestades
232206	abraco das dez tempestades
232207	bracadeiras das dez tempestades
232208	cinto das dez tempestades
232209	palas das dez tempestades
232210	coxotes das dez tempestades
232211	capacete das dez tempestades
232212	manoplas das dez tempestades
232213	grevas das dez tempestades
232214	peitoral das dez tempestades
232215	avambracos das dez tempestades
232216	cinturao das dez tempestades
232217	espaldares das dez tempestades
232218	perneiras das dez tempestades
232219	coroa das dez tempestades
232220	guantes das dez tempestades
232221	botinas das dez tempestades
232222	armadura das dez tempestades
232223	munhequeiras das dez tempestades
232224	cinta das dez tempestades
232225	brafoneiras das dez tempestades
232226	guarda pernas das dez tempestades
232227	viseira das dez tempestades
232228	protetores de mao das dez tempestades
232229	escarpes das dez tempestades
232230	couraca das dez tempestades
232231	bracadeiras da nemesis
232232	cinto da nemesis
232233	espaldares da nemesis
232234	perneiras da nemesis
232235	casquete da nemesis
232236	luvas da nemesis
232237	botas da nemesis
232238	vestes da nemesis
232239	munhequeiras da nemesis
232240	cordao da nemesis
232241	ombreiras da nemesis
232242	calcas da nemesis
232243	capucho da nemesis
232244	protetores de mao da nemesis
232245	botinas da nemesis
232246	induto da nemesis
232247	bracadeiras da ira
232248	cinto da ira
232249	omoplatas da ira
232250	coxotes da ira
232251	elmo da ira
232252	manoplas da ira
232253	grevas da ira
232254	peitoral da ira
232255	munhequeiras da ira
232256	cinta da ira
232257	brafoneiras da ira
232258	guarda pernas da ira
232259	viseira da ira
232260	protetores de mao da ira
232261	escarpes da ira
232262	couraca da ira
232299	defensor zulian
232309	conduto da alma de renataki
232310	conduto da alma de renataki
232311	manto de pele de tigre zulian
232312	sangue do arauto da luz
232324	apito de passaro
232344	vick s vip pass
232357	vingador draconico
232358	relicario vazio
232373	olho de sulfuras refinado
232389	incunabulo da abundancia
232390	idolo de concentracao celestial
232391	idolo de concentracao felina
232392	totem de trovao incansavel
232409	totem dos elementos
232414	lamina dragodonte
232416	totem de fluxo astral
232419	totem de correntes condutoras
232420	incunabulo da ira
232421	incunabulo da vinganca
232423	idolo da nutricao
232424	idolo da crueldade
232433	bandagem densa de runatrama
232434	manual bandagem densa de runatrama
232436	caldo de garrumbra
232437	receita caldo de garrumbra
232438	vermelhao defumado
232443	receita vermelhao defumado
232454	emblema dos deuses selvagens
232455	emblema da desonra
232456	emblema do olho violeta
232457	emblema do nucleo
232458	runa do santuario aprimorado
232459	runa da cortina de fogo
232460	runa do deslocamento
232461	runa do desespero
232462	runa do poder purificador
232549	instrucoes de logistica vi
232550	ashkandi montante da irmandade
232551	marreta draconica
232552	lok amir il romathis
232555	crul shorukh beira do caos
232556	cajado da chama sombria
232557	garra de cromaggus
232558	espada temperada cromaticamente
232559	arauto do sofrimento
232561	garra do draco preto
232562	cutelo de garra de draco
232563	cajado de foco da asa sombria
232564	maladath lamina runica da revoada negra
232565	lamina dendragonia
232566	a lamina indomavel
232567	quebra espinha
232576	vingador draconico
232577	gume da perdicao
232606	ashjre thul besta da punicao
232607	furapeito
232608	carabina bafo de dragao
232610	formula brilhotrolico magnifico
232611	brilhotrolico magnifico
232652	zila amanemodas
233197	manual de treino argenteo
233198	trompa da aurora
233200	semente de flor da cancao
233201	globo cintilante
233206	bigorna do feitor
233208	bola 8 magica defeituosa
233209	caldeirao de aguardente
233211	concha espiritual
233213	magnetita ancestral
233215	armadilha de areia explosiva
233216	raio gelomatico
233217	incenso do escavador
233226	corda zandalariana ancestral
233250	galho antigo
233351	cristal ressonante qiraji verde claro
233352	cristal ressonante qiraji azul escuro
233353	cristal ressonante qiraji azul claro
233356	cristal ressonante qiraji laranja
233357	cristal ressonante qiraji crepuscular
233358	tanque silitideo domado
233362	carapaca do deus antigo
233363	carapaca do deus antigo
233364	pele do deus antigo
233365	visceras intactas
233367	peritonio intacto
233368	entranhas intactas
233369	braceletes qiraji de dominancia
233370	braceletes do comando qiraji
233371	braceletes qiraji de soberania
233372	grevas do conquistador
233373	peitoral do conquistador
233374	guarda pernas do conquistador
233375	coroa do conquistador
233376	espaldares do conquistador
233377	palmilhas do arauto da ruina
233378	calcas do arauto da ruina
233379	dragonas do arauto da ruina
233380	vestes do arauto da ruina
233381	diadema do arauto da ruina
233382	perneiras do tempestario
233383	brafoneiras do tempestario
233384	guarda pes do tempestario
233385	diadema do tempestario
233386	cota do tempestario
233387	espaldares do causamortis
233388	elmo do causamortis
233389	colete do causamortis
233390	perneiras do causamortis
233391	botas do causamortis
233392	palmilhas do oraculo
233393	tiara do oraculo
233394	dragonas do oraculo
233395	vestimenta do oraculo
233396	calcas do oraculo
233397	peitoral do vingador
233398	coroa do vingador
233399	grevas do vingador
233400	guarda pernas do vingador
233401	brafoneiras do vingador
233402	vestes enigmaticas
233403	ombreiras enigmaticas
233404	diadema enigmatico
233405	botas enigmaticas
233406	perneiras enigmaticas
233407	guarda pes do atirador
233408	perneiras do atirador
233409	brafoneiras do atirador
233410	diadema do atirador
233411	cota do atirador
233412	elmo da genese
233413	ombreiras da genese
233414	botas da genese
233415	colete da genese
233416	calcas da genese
233417	maca da vida interminavel
233418	manto da vida interminavel
233419	anel da vida interminavel
233420	manto do caminho oculto
233421	foice do caminho oculto
233422	sinete do caminho oculto
233423	lamina dos segredos obscuros
233424	clamide dos segredos obscuros
233425	anel dos segredos obscuros
233426	lamina da justica eterna
233427	capa da justica eterna
233428	anel da justica eterna
233429	martelete da sabedoria infinita
233430	mortalha da sabedoria infinita
233431	anel da sabedoria infinita
233432	manto das sombras veladas
233433	adaga das sombras veladas
233434	anel das sombras veladas
233435	martelo da tempestade iminente
233436	manto da tempestade iminente
233437	anel da tempestade iminente
233438	mortalha dos nomes proibidos
233439	cris dos nomes proibidos
233440	anel dos nomes proibidos
233441	clamide da forca obstinada
233442	foice da forca obstinada
233443	sinete da forca obstinada
233490	campeao de obsidiana
233491	aniquilador obsidiano
233492	loriga aguilamina
233496	omoplatas da barragem
233502	amuleto da protecao putrida
233503	pingente do guardiao qiraji
233504	manto do odio concentrado
233505	perneiras da imersao
233506	munhequeiras em escamas do besouro
233507	anel do enxame de pensamentos
233509	cajado dos profetas qiraji
233514	botas da vontade resoluta
233515	martelo de ji zhi
233516	peitoral da aniquilacao
233517	botas da profecia cumprida
233518	botas do profeta caido
233519	capa da trindade
233520	vestes do triunvirato
233521	dragonas ternarias
233522	mascara do devorador
233523	cinturao triade
233524	toque da angelista
233559	luvas de ebru
233560	manoplas gosmentas
233561	botas do heroi caido
233562	patua da angelista
233563	dragonas do poder frenico
233564	manoplas cobertas de bile
233565	anel das trevas de ukko
233566	dragonas da furia do deserto
233567	dragonas da cruzada do deserto
233568	colete da execucao rapida
233569	anel do devorado
233570	escaravelho petrificado
233571	varinha da nobreza qiraji
233572	colar da pureza
233573	botas reconstruidas
233574	perneiras do enxame ulceroso
233575	vestes da guarda de batalha
233576	garra silitidea
233577	cinto de escamas qiraji grosso
233578	elmo da vinha assustadora
233579	luvas da coacao
233580	distintivo dos guarda enxames
233581	poder de sartura
233582	manoplas da determinacao inabalavel
233583	coxotes da luz fulgurante
233584	perneiras em escamas da furia qiraji
233585	antiga estripadora qiraji
233586	mandibula do aniquilador arenoso
233587	gargantilha farpada
233588	manto dos segredos nao revelados
233589	fetiche do aniquilador arenoso
233590	botas do escavador de colmeias
233591	couraca de carapaca silitidea
233592	dragonas da revanche perversa
233593	brafoneiras do implacavel
233594	vestes do santo guardiao
233595	perneiras em escamas do aniquilador arenoso
233596	incunabulo de purificacao
233597	totem da vida
233598	perneiras cobertas de visco
233599	femur silitideo afiado
233600	anel da furia qiraji
233601	broche do escaravelho
233602	idolo da saude
233603	manoplas do campeao integro
233604	manoplas de kalimdor
233605	aguilhao de huhuran
233606	manto da colmeia dourada
233607	luvas do messias
233608	manoplas de casca de vespa
233609	anel do martir
233610	munhequeiras do profanador de colmeias
233611	botas da epifania
233612	bracadeiras qiraji da execucao
233613	luvas devastadoras de vek lor
233614	cinto real qiraji
233615	anel do imperador vek lor
233616	cetro real de vek lor
233617	braceletes da redencao real
233618	luvas do templo oculto
233619	cinto regenerador de vek nilash
233620	amuleto de vek nilash
233621	revanche de kalimdor
233622	garra do imperador caido
233623	cinto do imperador caido
233624	chapeu perdido de dom rigoberto
233625	bracadeiras do escavador
233626	larva do grande verme
233627	jom gabbar
233628	a carapaca do escavador
233629	bloqueador de escamas de verme
233630	manto dos devorados
233631	manoplas da tempestade negra
233632	cinturao do deus antigo
233633	cordao de cintura do olho furtivo
233634	aguilhao da morte
233635	cinto da agonia sem fim
233636	cetro do falso profeta
233637	manoplas da aniquilacao
233638	anel do assassino de deuses
233639	tentaculo derrotado de c thun
233640	gume negro da insanidade
233641	manto da clareza
233642	marca de c thun
233643	martelo de guerra dos anubisath
233644	vestes da ascensao real
233645	luvas do imortal
233646	luvas da profecia cumprida
233647	neretzek o sanguinario
233648	anel do caos de ritssyn
233649	fragmento da estrela caida
233651	corselete do conquistador
233652	escarpes do conquistador
233653	elmo do conquistador
233654	escarcela do conquistador
233658	brafoneiras do conquistador
233659	couraca do causamortis
233660	botinas do causamortis
233661	visor do causamortis
233662	calcas do causamortis
233663	brafoneiras do causamortis
233664	cota anilhada do atirador
233665	botinas do atirador
233666	visor do atirador
233667	coxotes encadeados do atirador
233668	espaldares do atirador
233669	cimeira do arauto da ruina
233670	induto do arauto da ruina
233671	ombreiras do arauto da ruina
233672	calcas do arauto da ruina
233673	botinas do arauto da ruina
233674	calcas enigmaticas
233675	sapatilhas enigmaticas
233676	coroa enigmatica
233677	dragonas enigmaticas
233678	induto enigmatico
233679	perneiras do oraculo
233680	vestes do oraculo
233681	ombreiras do oraculo
233682	coroa do oraculo
233683	sapatilhas do oraculo
233684	dragonas do vingador
233685	calcas de placa do vingador
233686	botinas do vingador
233687	elmo do vingador
233688	corselete do vingador
233689	espaldares do vingador
233690	escarcelas do vingador
233691	escarpes do vingador
233692	elmo do vingador
233693	couraca do vingador
233694	couraca do tempestario
233695	viseira do tempestario
233696	escarpes do tempestario
233697	espaldares do tempestario
233698	coxotes do tempestario
233699	peitoral do tempestario
233700	coroa do tempestario
233701	botinas do tempestario
233702	dragonas do tempestario
233703	perneiras encadeadas do tempestario
233704	peitoral do tempestario
233705	cocar do tempestario
233706	grevas do tempestario
233707	palas do tempestario
233708	perneiras de malha do tempestario
233709	capucho da genese
233710	calcas de couro da genese
233711	armadura da genese
233712	pisoteadores da genese
233713	espaldares da genese
233714	perneiras da genese
233715	couros da genese
233716	botinas da genese
233717	dragonas da genese
233718	diadema da genese
233719	calcoes da genese
233720	couraca da genese
233721	grevas da genese
233722	brafoneiras da genese
233723	mascara da genese
233724	cinturao de placa endurecido em batalha
233725	cinturao de placa endurecido em batalha
233726	guarda bracos de placa endurecido em batalha
233727	guarda bracos de placa endurecido em batalha
233728	insignia incrustada de sangue
233729	gargantilha incrustada de sangue
233730	talisma incrustado de sangue
233731	amuleto incrustado de sangue
233732	colar incrustado de sangue
233733	anel incrustado de sangue
233734	circulo incrustado de sangue
233735	aro incrustado de sangue
233736	elo incrustado de sangue
233737	manto incrustado de sangue
233738	capa incrustada de sangue
233739	clamide incrustada de sangue
233740	mortalha incrustada de sangue
233741	cinto lamelar endurecido em batalha
233742	guarda bracos lamelar endurecido em batalha
233743	munhequeiras lamelares endurecidas em batalha
233744	cordao lamelar endurecido em batalha
233745	cintel de malha endurecido em batalha
233746	cordao de malha endurecido em batalha
233747	cinto de malha endurecido em batalha
233748	bracadeiras de malha endurecidas em batalha
233749	munhequeiras de malha endurecidas em batalha
233750	avambracos de malha endurecidos em batalha
233751	cinturao encadeado endurecido em batalha
233752	cinturao encadeado endurecido em batalha
233753	cinto encadeado endurecido em batalha
233754	cinto encadeado endurecido em batalha
233755	munhequeiras encadeadas endurecidas em batalha
233756	munhequeiras encadeadas endurecidas em batalha
233757	bracadeiras encadeadas endurecidas em batalha
233758	bracadeiras encadeadas endurecidas em batalha
233759	bracadeiras de couro de dragao endurecidas em batalha
233760	bracadeiras de couro de dragao endurecidas em batalha
233761	cinto de couro de dragao endurecido em batalha
233762	cinto de couro de dragao endurecido em batalha
233763	cinta de couro de dragao endurecida em batalha
233764	cinta de couro de dragao endurecida em batalha
233765	cordao de couro de dragao endurecido em batalha
233766	cordao de couro de dragao endurecido em batalha
233767	munhequeiras de couro de dragao endurecidas em batalha
233768	munhequeiras de couro de dragao endurecidas em batalha
233769	embraces de couro de dragao endurecidos em batalha
233770	embraces de couro de dragao endurecidos em batalha
233771	cinturao de couro endurecido em batalha
233772	cinturao de couro endurecido em batalha
233773	pulseiras de couro endurecidas em batalha
233774	pulseiras de couro endurecidas em batalha
233775	manilhas de seda endurecidas em batalha
233776	manilhas de seda endurecidas em batalha
233777	faixa de seda endurecida em batalha
233778	faixa de seda endurecida em batalha
233779	bracadeiras de cetim endurecidas em batalha
233780	bracadeiras de cetim endurecidas em batalha
233781	munhequeiras de cetim endurecidas em batalha
233782	munhequeiras de cetim endurecidas em batalha
233783	faixa de cetim endurecida em batalha
233784	faixa de cetim endurecida em batalha
233785	cilha de cetim endurecida em batalha
233786	cilha de cetim endurecida em batalha
233787	manilhas de medotrama endurecidas em batalha
233788	manilhas de medotrama endurecidas em batalha
233789	cinto de medotrama endurecido em batalha
233790	cinto de medotrama endurecido em batalha
233791	moeda de cobre incrustada de sangue
233793	placa d ombros aguilamina
233795	jaula craniana aguilamina
233796	destruidor obsidiano
233797	martelo da tempestade obsidiano
233798	lamina do sabio obsidiana
233801	defensor obsidiano
233802	kit de armadura de quitina chamejante
233803	kit de armadura de quitina afiada
233804	ombreiras de espinheira brava
233808	capucho de espinheira brava
233813	couros de espinheira brava
233826	capucho vampirico
233833	xale vampirico
233837	veste vampirica
233956	lenco de seda qiraji
233958	capa de seda qiraji
233959	manto de seda qiraji
233960	clamide de seda qiraji
233962	frasco de loucura
233964	frasco de conhecimento ancestral
233965	frasco dos deuses antigos
233966	frasco de tristeza sem fim
233967	elixir do texugo melifero
233968	elixir do lorde mago
233969	elixir do ladoferreo
233977	elixir de diligencia
233984	megabomba arcana
233985	o fumigador
233986	bomba obsidiana
233987	gerador v1b3 b04
233988	disco de forca reativa ajustado
233990	pedracelere
233991	lagrima da sonhadora
233992	magnetita da retaliacao
233993	cronometro encantado
233994	broche incrustado de rubis
233995	pergaminho ira do enxame
233996	repelente encantado
233997	formula encantamento de atributos vivos torso
233998	formula encantamento de poder sagrado luvas
233999	formula encantamento de poder arcano luvas
234000	tomo encantado de oracoes
234001	totem encantado
234002	cogumelo encantado
234003	barra de torio infusa em obsidiana
234004	pedra de amolar obsidiana
234005	po explosivo obsidiano
234006	quitina de silitideo monstruosa
234007	quitina de silitideo farpada
234008	seda qiraji
234009	rolo de seda qiraji
234010	bile de verme da areia
234011	peconha de espreitador qiraji
234012	cardo de colmeia
234016	anel sinete da revoada bronze
234017	anel sinete da revoada bronze
234018	anel sinete da revoada bronze
234019	anel sinete da revoada bronze
234020	anel sinete da revoada bronze
234021	anel sinete da revoada bronze
234022	anel sinete da revoada bronze
234023	anel sinete da revoada bronze
234024	anel sinete da revoada bronze
234025	anel sinete da revoada bronze
234026	anel sinete da revoada bronze
234027	anel sinete da revoada bronze
234028	anel sinete da revoada bronze
234029	anel sinete da revoada bronze
234030	anel sinete da revoada bronze
234031	anel sinete da revoada bronze
234032	anel sinete da revoada bronze
234033	anel sinete da revoada bronze
234034	anel sinete da revoada bronze
234035	anel sinete da revoada bronze
234061	adaga sacrifical qiraji
234062	vestimenta das areias cambiantes
234063	cinto do aniquilador arenoso
234064	cinto da inquisicao
234065	munhequeiras do aniquilador arenoso
234066	luvas de casca silitidea reforcada
234067	a degola homens qiraji
234068	botas da vanguarda
234069	botas do general qiraji
234070	bracadeiras do comando qiraji
234071	coxotes do comando qiraji
234072	cinturao do vento sul
234073	turbante sopravento
234075	manoplas do impassivel
234076	garra da concentracao furiosa
234077	couraca silitidea grossa
234078	guarda ombros quitinosos
234079	manto do salvador
234080	olho de moam
234081	manoplas do vento sul
234082	dragonas de maz nadir
234083	anel da furia
234084	elmo do vento sul
234085	instrucoes garra negra do destruidor
234086	garra negra do destruidor
234087	perneiras em escamas obsidianas
234088	coxotes do destruidor
234089	fragmento do cranio de buru
234090	luvas do enxame
234091	manoplas em escamas viscosas
234092	fetiche de espinhos quitinosos
234093	galochas da areia movedica
234094	bracadeiras em escamas do engolidor
234095	pisantes de visgo
234096	arco do tendao estirado
234097	aguilhao de ayamiss
234098	botas do protetor do deserto
234099	botas das areias abrasadoras
234100	elmo do recrescimento
234101	anel dos ventos do deserto
234102	manoplas do silitideo em escamas
234103	bracadeiras da brutalidade
234104	besta da ruina iminente
234105	manoplas da vida nova
234106	luvas da sabedoria negra
234107	elmo da dominacao
234108	perneiras da nevasca negra
234109	dragonas dos horusath
234110	cinturao de ossirian
234111	omoplatas de pedra runica
234112	martelo polido com areia
234113	manto da tempestade de areia
234114	grilhoes do imaculado
234115	cajado das ruinas
234116	furia do enxame esquecido
234117	botinas do nomade errante
234118	martelete da autoridade qiraji
234119	tentaculo do fortalecimento
234120	elmo do vingador sagrado
234121	lancador encouracado silitideo
234122	a cris perdida de zedd
234123	coifa da furia elemental
234124	guia de veneno oculto ii
234129	perneiras engastadas com onix
234130	amuleto de anteparo sombrio
234132	colar de dente de draco
234133	botas labutadoras
234134	turbante gnomico do poder psiquico
234135	elo das profundezas congelantes
234136	vestes da agua negra
234137	presa de korialstrasz
234138	lamento dos cantonegro
234139	legado dos cristacorvo
234141	espada runica do vermelho
234142	elixir nublacuca sem fundo
234143	globo do logro
234144	incensorio do falso profeta
234145	bijuteria hakkari incrustada de sangue
234146	grevas inscritas com acido
234147	perneiras antigas corroidas
234148	munhequeiras de osso de dragao
234149	bracadeiras draguilhao
234150	luvas do poder ilusorio
234151	manto verde de peledrago
234152	martelo da furia bestial
234153	cajado do crescimento descontrolado
234154	pedra do transe
234155	anel sinete de malfurion
234156	botas do pantano sem fim
234157	diadema dos sonhos inquietos
234158	colar dracordio
234159	besta de pau ferro polido
234160	anel do vivo morto
234161	cinto do brejo negro
234162	braceleiras da casca preta
234163	calcas do coracao negro
234164	casquete do crescimento anormal
234165	manoplas da luz rutilante
234166	guarda pes malignos
234167	botas do medo
234168	sapatilhas do mendicante
234169	faixa rasgamentes
234170	lamina de pesadelo
234171	brafoneiras sinistras de couro
234172	esmeralda dendragonia
234173	perneiras do demente
234174	brafoneiras inscritas com acido
234175	cristal de hibernacao
234176	carta de negraluna heroismo
234177	carta de negraluna dragao azul
234178	carta de negraluna voragem
234179	carta de negraluna espiral eterea
234180	sinalizador temporal
234181	diario de sectario do crepusculo
234198	anel sinete da revoada bronze
234199	anel sinete da revoada bronze
234200	anel sinete da revoada bronze
234201	anel sinete da revoada bronze
234202	anel sinete da revoada bronze
234220	instrucoes jaula craniana aguilamina
234221	instrucoes placa d ombros aguilamina
234222	instrucoes loriga aguilamina
234223	instrucoes aniquilador obsidiano
234224	instrucoes campeao obsidiano
234225	instrucoes destruidor obsidiano
234226	instrucoes martelo da tempestade obsidiano
234227	instrucoes lamina do sabio obsidiana
234228	instrucoes defensor obsidiano
234235	molde kit de armadura de quitina chamejante
234236	molde kit de armadura de quitina afiada
234237	molde capucho de espinheira brava
234238	molde ombreiras de espinheira brava
234239	molde couros de espinheira brava
234240	molde capucho vampirico
234241	molde xale vampirico
234242	molde veste vampirica
234244	molde lenco de seda qiraji
234249	molde capa de seda qiraji
234250	molde manto de seda qiraji
234251	molde clamide de seda qiraji
234252	receita frasco de tristeza sem fim
234253	receita frasco de conhecimento ancestral
234255	receita frasco dos deuses antigos
234256	receita frasco de loucura
234257	receita elixir do texugo melifero
234258	receita elixir do lorde mago
234259	receita elixir do ladoferreo
234260	receita elixir de diligencia
234261	diagrama megabomba arcana
234262	diagrama o fumigador
234263	diagrama bomba obsidiana
234264	diagrama gerador v1b3 b04
234265	diagrama disco de forca reativa ajustado
234266	formula pedracelere
234267	formula lagrima da sonhadora
234268	formula magnetita da retaliacao
234269	formula cronometro encantado
234270	formula broche incrustado de rubis
234271	formula pergaminho ira do enxame
234272	formula repelente encantado
234275	formula tomo encantado de oracoes
234276	formula totem encantado
234277	formula cogumelo encantado
234278	manual fundir barra de torio infusa em obsidiana
234279	instrucoes pedra de amolar obsidiana
234280	diagrama po explosivo obsidiano
234288	cinto vinaferro
234289	instrucoes cinto vinaferro
234290	luvas vinaferro
234291	instrucoes luvas vinaferro
234292	peitoral vinaferro
234293	instrucoes peitoral vinaferro
234294	bracadeiras espreitareia
234295	molde bracadeiras espreitareia
234296	manoplas espreitareia
234297	molde manoplas espreitareia
234298	peitoral espreitareia
234299	molde peitoral espreitareia
234300	bracadeiras cospefogo
234301	molde bracadeiras cospefogo
234302	manoplas cospefogo
234303	molde manoplas cospefogo
234304	peitoral cospefogo
234305	molde peitoral cospefogo
234306	cinto de sarca
234307	molde cinto de sarca
234308	botas de sarca
234309	molde botas de sarca
234310	elmo de sarca
234311	molde elmo de sarca
234312	omoplatas silvestres
234314	molde omoplatas silvestres
234315	coroa silvestre
234316	molde coroa silvestre
234317	colete silvestre
234318	molde colete silvestre
234319	cinto pesado de obsidiana
234320	instrucoes cinto pesado de obsidiana
234321	cinto leve de obsidiana
234322	instrucoes cinto leve de obsidiana
234324	peitoral de escama de sonhos
234325	molde peitoral de escama de sonhos
234428	acerta peito obsidiano
234429	instrucoes acerta peito obsidiano
234434	espingarda obsidiana
234435	diagrama espingarda obsidiana
234436	anel sinete da revoada bronze
234437	anel sinete da revoada bronze
234438	anel sinete da revoada bronze
234439	anel sinete da revoada bronze
234440	anel sinete da revoada bronze
234444	veneno oculto ii
234445	molde rolo de seda qiraji
234447	bastao de transformacao da buba
234458	instrucoes escudo serrilhado obsidiano
234459	escudo serrilhado obsidiano
234460	tunica de malha de obsidiana
234461	instrucoes tunica de malha de obsidiana
234462	golpe terreno
234463	ira de cenarius
234464	bastao de bolhas da buba
234465	redeas do tigre espectral veloz
234467	bastao dos dragoes da buba
234468	idolo de poder ursino
234469	idolo de ferocidade felina
234474	idolo da ira sideral
234475	incunabulo do exorcista
234476	incunabulo de santidade
234477	incunabulo da retidao
234478	totem de ataques tempestuosos
234479	totem de fluxo magmatico
234480	totem de trovao piroclastico
234481	molde kilt de escama de sonhos
234482	kilt de escama de sonhos
234483	molde bracadeiras de escama de sonhos
234484	bracadeiras de escama de sonhos
234485	luvetes de escama de sonhos
234486	molde luvetes de escama de sonhos
234487	visor de escama de sonhos
234488	instrucoes visor de escama de sonhos
234542	montante do sumo senhor da guerra
234543	machado de batalha do sumo senhor da guerra
234545	pulverizador do sumo senhor da guerra
234546	destruidor do sumo senhor da guerra
234547	dessangrador do sumo senhor da guerra
234548	aticador de porcos do sumo senhor da guerra
234549	cajado de guerra do sumo senhor da guerra
234550	lamina enfeiticada do sumo senhor da guerra
234551	maca de batalha do sumo senhor da guerra
234552	lamina do sumo senhor da guerra
234553	gumepresto do sumo senhor da guerra
234554	cutelo do sumo senhor da guerra
234555	porrete do sumo senhor da guerra
234556	navalha do sumo senhor da guerra
234557	garra direita do sumo senhor da guerra
234558	garra esquerda do sumo senhor da guerra
234559	arco recurvo do sumo senhor da guerra
234560	besta do sumo senhor da guerra
234561	abre alas do sumo senhor da guerra
234562	muralha de escudos do sumo senhor da guerra
234563	tomo de destruicao do sumo senhor da guerra
234564	tomo de recomposicao do sumo senhor da guerra
234565	espadao do grao marechal
234566	talho do grao marechal
234567	martelo de batalha do grao marechal
234568	demolidor do grao marechal
234569	glaive do grao marechal
234570	arma de haste do grao marechal
234571	baculo do grao marechal
234574	magespada do grao marechal
234576	martelo de guerra do grao marechal
234578	espada longa do grao marechal
234579	lamina celere do grao marechal
234580	machado de mao do grao marechal
234581	castigador do grao marechal
234582	punhal do grao marechal
234583	lamina destra do grao marechal
234584	lamina sinistra do grao marechal
234585	disparo certeiro do grao marechal
234586	besta de repeticao do grao marechal
234587	canhao de mao do grao marechal
234588	egide do grao marechal
234589	tomo de poder do grao marechal
234590	tomo de restauracao do grao marechal
234614	emblema tocado pelo caos
234650	antiga estripadora qiraji
234747	punho de cenarius
234748	bracadeiras rochafunda
234749	orbe terramansa
234760	bracadeiras rochafuria
234761	poder de cenarius
234779	dadiva da terra
234780	elo do poder terrano
234782	colete do poder terreno
234785	luvas do poder terrano
234786	anel da ira terrana
234788	manto de trama terrena
234792	fatiadora de corvoforte
234793	lanceta do engrenofaca
234797	aticador pau de trovao
234798	arruinus prime
234799	repetidor de recarga de fahrad
234800	martelo de cultivo da simone
234801	amuleto do deus caido
234802	manto do deus caido
234803	anel do deus caido
234804	machado de guerra qiraji abencoado
234805	mosquete qiraji abencoado
234806	pugio qiraji abencoado
234807	baluarte qiraji abencoado
234808	cajado qiraji abencoado do acolito
234809	cajado qiraji abencoado do augure
234810	martelo de guerra qiraji abencoado
234811	patua das areias cambiantes
234812	amuleto das areias cambiantes
234813	gargantilha das areias cambiantes
234814	pingente das areias cambiantes
234960	redeas do tigre incrustado de sangue
234961	apito do raptor incrustado de sangue
234962	vestimenta marchetada de jade
234963	coxotes com estranhos entalhes
234964	anel sinete da revoada bronze
234965	anel sinete da revoada bronze
234966	anel sinete da revoada bronze
234967	anel sinete da revoada bronze
234968	anel sinete da revoada bronze
234974	cajado dos profetas qiraji
234975	martelo de ji zhi
234976	varinha da nobreza qiraji
234977	garra silitidea
234978	mandibula do aniquilador arenoso
234979	femur silitideo afiado
234980	aguilhao de huhuran
234981	revanche de kalimdor
234983	larva do grande verme
234984	aguilhao da morte
234985	gume negro da insanidade
234986	martelo de guerra dos anubisath
234987	neretzek o sanguinario
234989	adaga sacrifical qiraji
234990	a degola homens qiraji
234991	arco do tendao estirado
234992	aguilhao de ayamiss
234993	besta da ruina iminente
234994	martelo polido com areia
234995	cajado das ruinas
234996	martelete da autoridade qiraji
234997	lancador encouracado silitideo
234998	a cris perdida de zedd
234999	martelo de guerra qiraji abencoado
235000	cajado qiraji abencoado do augure
235001	cajado qiraji abencoado do acolito
235002	pugio qiraji abencoado
235003	machado de guerra qiraji abencoado
235004	mosquete qiraji abencoado
235005	foice da forca obstinada
235006	adaga das sombras veladas
235007	foice do caminho oculto
235008	cris dos nomes proibidos
235009	martelo da tempestade iminente
235010	martelete da sabedoria infinita
235011	lamina da justica eterna
235012	maca da vida interminavel
235013	lamina dos segredos obscuros
235014	cetro do falso profeta
235039	instrucoes peitoral grosso de obsidiana
235040	peitoral grosso de obsidiana
235045	paramentos imperiais qirajis
235046	armamentos imperiais qirajis
235047	luvas do profeta caido
235048	cabeca de ossirian o intocado
235049	objeto mergulhado em pesadelos
235133	formula incunabulo da retidao
235134	formula incunabulo do exorcista
235135	formula incunabulo de santidade
235136	formula totem de trovao piroclastico
235137	formula totem de ataques tempestuosos
235138	formula totem de fluxo magmatico
235139	formula idolo da ira sideral
235140	formula idolo de ferocidade felina
235141	formula idolo de poder ursino
235142	moeda de prata incrustada de sangue
235143	moeda de ouro incrustada de sangue
235144	algibeira de moedas de cobre incrustadas de sangue
235145	algibeira de moedas de prata incrustadas de sangue
235275	baralho de portais
235276	baralho de elementais
235277	baralho de generais
235278	baralho de feras
235282	tentaculo do fortalecimento
235473	barricada do grao marechal
235474	barricada do sumo senhor da guerra
235476	talhador do sumo senhor da guerra
235477	racha osso do sumo senhor da guerra
235478	estoque do sumo senhor da guerra
235479	estoque do grao marechal
235480	racha osso do grao marechal
235481	talhador do grao marechal
235497	tisana das areias
235511	cristal ressonante qiraji amarelo impecavel
235512	cristal ressonante qiraji verde impecavel
235513	cristal ressonante qiraji azul impecavel
235514	cristal ressonante qiraji vermelho impecavel
235517	tocha
235526	formula encantamento de poder magico bracadeiras
235528	formula encantamento de agilidade bracadeiras
235529	mira obsidiana
235530	diagrama mira obsidiana
235597	anotacoes de feiticos congelamento profundo
235598	anotacoes de feiticos veias gelidas
235599	anotacoes de feiticos anomalia temporal
235600	runa da tempestade divina
235601	runas do fanatismo
235602	runa do martelo do integro
235603	runa da vinganca integra
235604	runa do escudo de retidao
235605	runa de choque e admiracao
235785	chave de jaula do vento morto
235786	badulaque de karazhan
235787	galho de pau ferro ancestral
235788	fogo fatuo entusiasmado
235789	chama da vida
235790	ticao encantado
235825	tisana das areias
235852	algibeira violeta
235867	retalho de pergaminho
235868	baluarte da ira
235869	capucho do senhorio
235870	elmo range ossos
235871	elmo da morte agarradora
235872	embraces do espreitador
235873	guardioes da cripta
235874	mitenes do sectario
235875	luvas do coveiro
235876	protetores de mao do pecador
235877	manoplas do fanatico
235878	cinto malefico
235879	elos ligeiros
235880	solas do indigente
235881	botinas temidas
235882	passos estaladores
235883	tropeco do mergulhador de poco
235884	sinete espectral
235885	anel fantasmagorico
235886	fecho de kaigy
235887	gargantilha de barian
235888	panclavao
235889	bastao de servical
235890	agulha de tece sombras
235891	boa e velha
235892	espinha do cavaleiro sombrio
235893	grimorio sombrio
235894	obito do agourento
236002	lista de componentes
236005	peitoral couracado
236006	coxotes couracados
236007	capacete couracado
236008	brafoneiras couracadas
236009	escarpes couracados
236010	manoplas couracadas
236011	cinta couracada
236012	bracadeiras couracadas
236013	anel couracado
236014	corselete couracado
236015	escarcelas couracadas
236016	chifres couracados
236017	omoplatas couracadas
236018	grevas couracadas
236019	guantes couracados
236020	cinto couracado
236021	pulsos couracados
236022	elo couracado
236023	peitoral ceifa ossos
236024	coxotes ceifa ossos
236025	capacete ceifa ossos
236026	brafoneiras ceifa ossos
236027	escarpes ceifa ossos
236028	manoplas ceifa ossos
236029	cinta ceifa ossos
236030	bracadeiras ceifa ossos
236031	anel ceifa ossos
236032	cinto ceifa ossos
236033	botinas ceifa ossos
236034	elo ceifa ossos
236035	dragonas ceifa ossos
236036	perneiras ceifa ossos
236037	mascara ceifa ossos
236038	garras ceifa ossos
236039	couraca ceifa ossos
236040	munhequeiras ceifa ossos
236041	anel criptalante
236042	munhequeiras criptalantes
236043	tunica criptalante
236044	espaldares criptalantes
236045	guarda pernas criptalantes
236046	bacinete criptalante
236047	protetores de mao criptalantes
236048	cinturao criptalante
236049	botas criptalantes
236050	avambracos criptalantes
236051	cinto criptalante
236052	brafoneiras criptalantes
236053	perneiras criptalantes
236054	visor criptalante
236055	manoplas criptalantes
236056	elo criptalante
236057	grevas criptalantes
236058	peitoral criptalante
236059	sandalias do coracao pestilento
236060	perneiras do coracao pestilento
236061	braceletes do coracao pestilento
236062	veste do coracao pestilento
236063	luvas do coracao pestilento
236064	diadema do coracao pestilento
236065	ombreiras do coracao pestilento
236066	cinto do coracao pestilento
236067	anel do coracao pestilento
236068	munhequeiras do coracao pestilento
236069	cinta do coracao pestilento
236070	dragonas do coracao pestilento
236071	calcas do coracao pestilento
236072	coroa do coracao pestilento
236073	protetores de mao do coracao pestilento
236074	aro do coracao pestilento
236075	botas do coracao pestilento
236076	indumentaria do coracao pestilento
236077	braceletes de fogofrio
236078	cinto de fogofrio
236079	perneiras de fogofrio
236080	sandalias de fogofrio
236081	veste de fogofrio
236082	luvas de fogofrio
236083	diadema de fogofrio
236084	ombreiras de fogofrio
236085	anel de fogofrio
236087	munhecas de fogofrio
236088	cinta de fogofrio
236089	dragonas de fogofrio
236090	calcas de fogofrio
236091	capuz de fogofrio
236092	luvetes de fogofrio
236093	elo fogofrio
236094	botas de fogofrio
236095	trajes de fogofrio
236097	veste da fe
236098	cinto da fe
236099	sandalias da fe
236100	braceletes da fe
236101	perneiras da fe
236102	ombreiras da fe
236103	diadema da fe
236104	luvas da fe
236105	anel da fe
236106	pulsos da fe
236107	cinturao da fe
236108	comando de arlote
236109	calcas da fe
236110	coroa da fe
236111	maos da fe
236112	elo da fe
236113	botas da fe
236114	trajes da fe
236115	tunica da redencao
236116	anel da redencao
236117	bacinete da redencao
236118	protetores de mao da redencao
236119	munhequeiras da redencao
236120	cinturao da redencao
236121	guarda pernas da redencao
236122	espaldares da redencao
236123	botas da redencao
236124	avambracos da redencao
236125	cinto da redencao
236126	placa d ombros da redencao
236127	perneiras da redencao
236128	capacete da redencao
236129	luvas da redencao
236130	elo da redencao
236131	grevas da redencao
236132	peitoral da redencao
236133	bracadeiras da redencao
236134	cinta da redencao
236135	brafoneiras da redencao
236136	coxotes da redencao
236137	coroa da redencao
236138	manoplas da redencao
236139	aro da redencao
236140	escarpes da redencao
236141	couraca da redencao
236142	protetores de mao quebraterra
236143	guarda pernas quebraterra
236144	bacinete quebraterra
236145	espaldares quebraterra
236146	botas quebraterra
236147	tunica quebraterra
236148	cinturao quebraterra
236149	munhequeiras quebraterra
236150	anel quebraterra
236151	braceletes quebraterra
236152	cordao quebraterra
236153	dragonas quebraterra
236154	kilt quebraterra
236155	coroa quebraterra
236156	luvetes quebraterra
236157	elo quebraterra
236158	grevas quebraterra
236159	abraco quebraterra
236160	bracadeiras quebraterra
236162	cinta quebraterra
236163	brafoneiras quebraterra
236164	coxotes quebraterra
236165	viseira quebraterra
236166	luvas quebraterra
236167	aro quebraterra
236168	escarpes quebraterra
236169	couraca quebraterra
236170	avambracos quebraterra
236171	cinto quebraterra
236172	palas quebraterra
236173	perneiras quebraterra
236174	capacete quebraterra
236175	guantes quebraterra
236176	sinete quebraterra
236177	botinas quebraterra
236179	armadura quebraterra
236182	bacinete andassonho
236183	munhequeiras andassonho
236184	protetores de mao andassonho
236185	botas andassonho
236186	tunica andassonho
236187	cinturao andassonho
236188	guarda pernas andassonho
236189	espaldares andassonho
236190	anel andassonho
236192	braceletes andassonho
236193	cordao andassonho
236194	dragonas andassonho
236195	kilt andassonho
236196	capuz andassonho
236197	luvetes andassonho
236198	elo andassonho
236199	sandalias andassonho
236200	couros andassonho
236201	bracadeiras andassonho
236202	cinta andassonho
236203	brafoneiras andassonho
236204	perneiras andassonho
236205	adereco de cabeca andassonho
236206	manoplas andassonho
236207	aro andassonho
236208	escarpes andassonho
236209	armadura andassonho
236210	munhequeiras andassonho
236211	faixa andassonho
236212	ombreiras andassonho
236213	calcas andassonho
236214	capucho andassonho
236215	guantes andassonho
236216	sinete andassonho
236217	pisoteadores andassonho
236218	colete andassonho
236219	emissario da destruicao
236220	traje do necro cavaleiro
236221	braco perdido do servo
236222	tunica de pele de carnical
236223	anel da chama eterna
236224	broquel estigio
236225	cinturao da furia elemental
236226	brafoneiras da furia elemental
236227	cinto do grande cruzado
236228	espaldares do grande cruzado
236229	perneiras do grande cruzado
236230	perneiras de furia elemental
236231	peitoral profanado
236232	cinta profanada
236233	manoplas profanadas
236234	escarpes profanados
236235	bracadeiras profanadas
236236	capacete profanado
236237	brafoneiras profanadas
236238	coxotes profanados
236239	sandalias profanadas
236240	ombreiras profanadas
236241	diadema profanado
236242	veste profanada
236243	luvas profanadas
236244	cinto profanado
236245	braceletes profanados
236246	perneiras profanadas
236247	munhequeiras profanadas
236248	botas profanadas
236249	bacinete profanado
236250	protetores de mao profanados
236251	tunica profanada
236252	cinturao profanado
236253	guarda pernas profanado
236254	espaldares profanados
236255	munhequeiras da vinganca
236256	toque de gelo
236257	gema de nerubis
236258	manto de seda de carnifice da cripta
236259	elo das preces nao atendidas
236260	brafoneiras da perdicao gelida
236261	pingente de pedra da malicia
236262	espaldares polares
236263	remorso da viuva
236264	o abraco da viuva
236265	lamina espectral
236266	pingente dos nomes esquecidos
236267	veste tecida com cristais
236268	beijo da aranha
236269	presa de maexxna
236270	machadinha de osso partido
236271	incunabulo da luz
236272	manto do flagelo
236273	anel do inevitavel
236274	elo de granizo
236275	coracao frigido de noth
236276	totem da agua corrente
236277	colar da necropsia
236278	diadema glacial
236279	chapeu do preceptor
236280	coxotes da chacina
236281	coifa de escama gelada
236282	reflexao de repugnaz
236283	anel do fervor espiritual
236284	cajado sulfureo
236285	o olho de nerub
236286	elo das forcas sobrenaturais
236287	ruptura
236288	o portador da peste
236289	manto de sutura
236290	varinha do destino
236291	elo de reanimacao
236292	bruma da meia noite
236293	injetor de toxinas
236294	espaldares de escama gelada
236295	dragonas glaciais
236296	oferta da morte
236297	o fim dos sonhos
236298	dragonas cobertas de geada
236299	espadao do poder profano
236300	coleira perdida do gluth
236301	mao consumida do poder
236302	olho da diminuicao
236303	perneiras da polaridade
236304	condrios de placas da abominacao
236305	cajado do crepusculo
236306	o castigador
236307	veu do eclipse
236308	idolo da longevidade
236309	cinturao do mentor
236310	varinha dos mortos sussurrantes
236311	sinete do defensor caido
236312	iblis lamina do serafim caido
236313	bracadeiras do ceifador de almas
236314	botas do deslocamento
236315	capacete polar
236316	coleira do sadico
236317	vis era a estripadora
236318	selo do maldito
236319	perneiras do apocalipse
236320	cordialidade do perdao
236321	malho do cruzado redimido
236322	cordao das almas
236323	resiliencia do flagelo
236324	poder do flagelo
236325	fortitude do flagelo
236326	poder do flagelo
236327	manto da necropole
236328	olho esquerdo do sapphiron
236329	olho dos mortos
236330	olho direito do sapphiron
236331	a essencia contida de sapphiron
236333	mortalha de dominio
236334	escudo do matador
236335	brafoneiras do implacavel
236336	a face da morte
236337	glifo de deflexao
236338	garra da serpe gelida
236339	gressil o despertar da decadencia
236340	poder de menethil
236341	o frio voraz
236342	talisma da ebulicao de tempesfuria
236343	queda do monarca
236344	escravizador nerubiano
236345	gema dos inocentes encurralados
236346	cacador de almas
236347	escudo da condenacao
236348	martelo de espiral eterea
236349	dedo do destino
236350	o filacterio de kel thuzad
236351	marca do campeao
236352	marca do campeao
236354	selo da aurora do aspirante
236355	selo da aurora do iniciado
236356	selo da aurora do escudeiro
236357	selo da aurora do cavaleiro
236358	selo da aurora do templario
236360	selo da aurora do campeao
236361	selo da aurora da vanguarda
236362	selo da aurora do cruzado
236363	selo da aurora do comandante
236364	selo da aurora do grao lorde
236374	selo da aurora do comandante
236375	selo da aurora do grao lorde
236376	selo da aurora do cruzado
236378	selo da aurora da vanguarda
236379	selo da aurora do campeao
236380	selo da aurora do templario
236382	selo da aurora do cavaleiro
236383	selo da aurora do escudeiro
236384	selo da aurora do iniciado
236385	selo da aurora do aspirante
236386	selo da aurora do grao lorde
236388	selo da aurora do comandante
236389	selo da aurora do cruzado
236390	selo da aurora da vanguarda
236391	selo da aurora do campeao
236392	selo da aurora do templario
236393	selo da aurora do cavaleiro
236394	selo da aurora do escudeiro
236395	selo da aurora do iniciado
236396	selo da aurora do aspirante
236397	vestigio de bravura
236398	atiesh grande cajado do guardiao
236399	atiesh grande cajado do guardiao
236400	atiesh grande cajado do guardiao
236401	atiesh grande cajado do guardiao
236414	caixote de suprimentos da inframina danificado
236417	alma do estrategista
236418	alma do veterano de guerra
236419	alma do preditor de batalhas
236420	alma do sanguinario
236421	alma do tita
236422	alma do destruidor
236423	alma do ata morte
236424	alma do sanguinista
236425	alma do bloqueador imaculado
236426	alma do selvagem
236427	alma da hostilidade
236428	alma do defletor
236429	alma do vingador
236430	alma do incessante
236431	alma do arauto do trovao
236432	alma da sentinela
236433	alma do canhoto
236434	alma do gladiador
236435	alma do tremor secundario
236436	alma do evasivo
236437	alma do toxicologista
236438	alma do carrasco
236439	alma do oportunista
236440	alma do acougueiro
236441	alma do fantasma
236442	alma do biltre
236443	alma do cacador de emocoes
236444	alma do sabio da estocada
236445	alma do espreitador
236446	alma do eficiente
236447	alma do malabarista de facas
236448	alma do mestre das sombras
236449	alma do equilibrista
236450	alma do brigao de prontidao
236451	alma do faixa preta
236452	alma do esgrimista
236453	alma do espadachim
236454	alma do sedento de sangue
236455	alma do transfusor
236456	alma do refinado
236457	alma do dizimador
236458	alma do arauto da podridao
236459	alma do malevolente
236460	alma do sombramante
236461	alma do emissario do caos
236462	alma do incendiario
236463	alma do pastor infernal
236464	alma do lorde demonio
236465	alma do exorcista demoniaco
236466	alma do aflito
236467	alma do flamespectro
236468	alma do devorador de carne
236469	alma do abissal
236470	alma do caosnato
236471	alma da lamina umbratica
236472	alma do ritualista
236473	alma do dissemina dor
236474	alma do enganador
236475	alma do rapinante
236476	alma do atirador de elite
236477	alma do cacador de perigo
236478	alma do alternador
236479	alma do toxinologista
236480	alma do cacador de recompensas
236481	alma do atirador truqueiro
236482	alma do tratador de feras
236483	alma do mestre dos caes
236484	alma do domador alfa
236485	alma do guarda caca
236487	alma do retaliador
236488	alma dos ecos
236489	alma do acoitador letal
236490	alma do cineticista
236491	alma do estrategista
236492	alma do golpeador mortal
236493	alma do curador apressado
236494	alma do refinado
236495	alma do celebrante
236496	alma do fiel
236497	alma do fortuito
236498	alma do ressonante
236499	alma do devoto
236500	alma do arcebispo
236501	alma do penitente
236502	alma do guardiao de almas
236503	alma do andarilho do crepusculo
236504	alma do rompe mentes
236505	alma do causamortis
236506	alma da fonte espiritual
236507	alma do zelote
236508	alma do profanador inabalavel
236509	alma do desdenhador
236510	alma do pestifero
236511	alma do reverberante
236512	alma do cronocurador
236513	alma do anseio temporal
236514	alma do precognitivo
236515	alma do arcanista
236516	alma do zelador eterno
236517	alma do mesmerizador
236518	alma do molda defesa
236519	alma das garras do inverno
236520	alma do criomante
236521	alma do conjurante
236522	alma do elementalista
236523	alma do armoreiro magico
236524	alma do archotius
236525	alma da convergencia ardente
236526	alma da chama perpetua
236527	alma do piromaniaco
236528	alma do incendiante
236529	alma do ateador
236530	alma do bloqueador imaculado
236531	alma do protetor da luz
236532	alma do defensor radiante
236533	alma do porta escudo
236534	alma do bastiao
236535	alma do julgador
236536	alma do blindado
236537	alma do guardiao
236538	alma do pacificador
236539	alma do refinado
236540	alma do exemplar
236541	alma do inquisidor
236542	alma do soberano
236543	alma do dominus
236544	alma do vindicante
236545	alma do altruista
236546	alma do juiz
236547	alma do porta selos
236548	alma do justicar
236549	alma do judicante
236550	alma do ascendente
236551	alma do retribuidor
236552	alma do excomungador
236553	alma do arauto da luz
236554	alma do exilado
236555	alma do templario
236556	alma do andarilho do vento
236557	alma do mestre do escudo
236558	alma do protetor totemico
236559	alma do amortecedor de choques
236560	alma do baluarte espiritual
236561	alma do arauto da voragem
236562	alma do andarilho da lava
236563	alma do verdadeiro alfa
236564	alma do guardiao de totem
236565	alma dos antecestrais
236566	alma do tece espiritos
236567	alma do andarilho da agua
236568	alma do domador de tempestades
236569	alma do vidente elemental
236570	alma do vitalista
236571	alma do anjo da cura
236572	alma do refinado
236573	alma do chefe
236574	alma do enfurecido
236575	alma do rompe procelas
236576	alma da tormenta
236577	alma do esmagador sismico
236578	alma do flamarauto
236579	alma do vulcao
236580	alma das chamas enraivecidas
236581	alma do mestre elemental
236582	alma do nativo
236583	alma do espirito guia
236584	alma do anciao
236585	alma dos elementos
236586	alma do sabio da lava
236587	alma do guardiao ancestral
236588	alma do corrompido
236589	alma da pata gentil
236590	alma do feroz
236591	alma do translocador
236592	alma do territorial
236593	alma da fera
236594	alma do lacerador
236595	alma do furioso
236596	alma do destrocador
236597	alma do inervador
236598	alma do alimentador
236599	alma do tranquilo
236600	alma do andassonho
236601	alma da mantenedora do bosque
236602	alma do sabio emplumado
236603	alma do vidente benevolente
236604	alma do tece vidas
236605	alma do iluminador
236606	alma dos instintos predatorios
236607	alma do estripador
236608	alma da garra
236609	alma do orgulhoso
236610	alma do barbaro
236611	alma do frenetico
236612	alma do dessangrador
236613	alma do guardiao dos espinhos
236614	alma do lunatico
236615	alma do arauto estelar
236616	alma da noite
236617	alma dos guardioes
236618	alma do irascivel
236619	alma do gracioso
236620	alma do ascendente astral
236621	alma do evocador de cometas
236622	alma da floresta
236623	alma de aptidao animalesca
236642	mitenes do reparador
236643	luvas do vigilante noturno
236644	protetores de mao do enlutado
236645	manoplas do brandeluz
236656	runa congelada
236657	galho apodrecido da buba
236658	trofeu espinhal da buba
236660	presa de troll da buba
236661	cossolete de irreverencia da buba
236662	redeas da guerra
236663	redeas da dominacao
236664	redeas da morte
236665	redeas da fome
236690	manto glacial
236692	luvas glaciais
236693	pulsos glaciais
236694	colete glacial
236695	peitoral da perdicao gelida
236696	bracadeiras da perdicao gelida
236697	manoplas da perdicao gelida
236698	bracadeiras de escama gelada
236699	peitoral de escama gelada
236700	manoplas de escama gelada
236701	bracadeiras polares
236702	tunica polar
236703	luvas polares
236704	pulsos gelidos
236705	luvas gelidas
236706	colete gelido
236707	tunica de matar mortos vivos
236708	peitoral de matar mortos vivos
236709	couraca de matar mortos vivos
236710	bracadeiras de matar mortos vivos
236711	munhequeiras de matar mortos vivos
236712	bracadeiras de matar mortos vivos
236713	mitenes de matar mortos vivos
236714	manoplas de matar mortos vivos
236715	protetores de mao de matar mortos vivos
236716	bracadeiras da purificacao de mortos vivos
236717	luvas da purificacao de mortos vivos
236718	veste da purificacao de mortos vivos
236719	bracadeiras da ablucao de mortos vivos
236720	luvas da ablucao de mortos vivos
236721	veste da ablucao de mortos vivos
236722	bracadeiras de protecao contra mortos vivos
236723	luvas de protecao contra mortos vivos
236724	veste de protecao contra mortos vivos
236725	munhecas da purificacao de mortos vivos
236726	mitenes da purificacao de mortos vivos
236727	tunica da purificacao de mortos vivos
236728	munhecas da ablucao de mortos vivos
236729	mitenes da ablucao de mortos vivos
236730	tunica da ablucao de mortos vivos
236731	munhecas de protecao contra mortos vivos
236732	mitenes de protecao contra mortos vivos
236733	tunica de protecao contra mortos vivos
236734	munhequeiras da purificacao de mortos vivos
236735	protetores de mao da purificacao de mortos vivos
236736	couraca da purificacao de mortos vivos
236737	munhequeiras de protecao contra mortos vivos
236738	protetores de mao de protecao contra mortos vivos
236739	couraca de protecao contra mortos vivos
236740	munhequeiras da ablucao de mortos vivos
236741	protetores de mao da ablucao de mortos vivos
236742	couraca da ablucao de mortos vivos
236743	bracadeiras da ablucao de mortos vivos
236744	manoplas da ablucao de mortos vivos
236745	peitoral da ablucao de mortos vivos
236746	bracadeiras de protecao contra mortos vivos
236747	manoplas de protecao contra mortos vivos
236748	peitoral de protecao contra mortos vivos
236750	coracao da ruina
236782	colar de sairuh
236786	coracao da ruina
236864	aljava de congelar alma
236869	bornal de municao de congelar alma
236871	sensores de censura sinistros
236872	diagrama sensores de censura sinistros
236878	reliquia misteriosa
236879	reliquia misteriosa
236880	reliquia misteriosa
237011	chave da ponte levadica
237020	insignia escarlate
237023	arbusto instantaneo
237024	ingresso para a opera
237037	carteira de socio do clube granfa
237041	tomo de sinalizador encantado
237143	ordens da comandante
237163	cranio do guerreiro antigo
237261	areia fina
237263	sacola de suprimentos
237275	capacete da perdicao gelida
237277	perneiras gelidas
237278	o purificador
237279	amuleto da aurora
237280	medalhao da aurora
237281	bracadeiras da esperanca
237282	braceleiras do subterfugio
237283	talisma da ascendencia
237284	sacola de suprimentos
237285	elo da resolucao
237286	elo da devocao
237287	ultimo recurso de verimonde
237288	elmo santificado de couro
237289	perneiras do cacador de pestes
237290	perneiras da perdicao gelida
237291	perneiras glaciais
237292	perneiras polares
237293	perneiras de escama gelada
237294	toque frio de ramaladni
237302	tabardo do enclave escarlate
237381	anel profanado
237386	caixote de suprimentos da inframina belicoso
237504	remessa de suprimentos
237512	lamina da inquisicao
237577	totem de poder profano
237773	palavra do degelo
237810	pedra de afiar consagrada balanceada
237814	guarda pernas lamelares da sentinela
237815	perneiras de seda da sentinela
237817	calcas de couro de lagarto da sentinela
237818	calcas de couro da sentinela
237819	perneiras encadeadas da sentinela
237820	perneiras de seda do pioneiro
237821	calcas de couro de lagarto do pioneiro
237822	calcas de couro do pioneiro
237823	perneiras de malha do pioneiro
237824	perneiras encadeadas do pioneiro
237825	guarda pernas de placa da sentinela
237826	guarda pernas de placa do pioneiro
238234	oleo abencoado de teurgo
238241	pedra de afiar consagrada
238264	capuz do augure escarlate
238265	dragonas do augure escarlate
238266	vestimentas do augure escarlate
238267	manilhas do augure escarlate
238268	luvetes do augure escarlate
238269	correia do augure escarlate
238270	perneiras do augure escarlate
238271	solas do augure escarlate
238272	bandana do infiltrador escarlate
238273	ombreiras do infiltrador escarlate
238274	colete do infiltrador escarlate
238275	bracadeiras do infiltrador escarlate
238276	luvas do infiltrador escarlate
238277	cinto do infiltrador escarlate
238278	calcotes do infiltrador escarlate
238279	sapatos do infiltrador escarlate
238280	coifa do guarda caca escarlate
238281	brafoneiras do guarda caca escarlate
238282	corrente do guarda caca escarlate
238283	munhequeiras do guarda caca escarlate
238284	protetores de mao do guarda caca escarlate
238285	fecho do guarda caca escarlate
238286	guarda pernas do guarda caca escarlate
238287	botas do guarda caca escarlate
238288	capacete do soldado escarlate
238289	espaldares do soldado escarlate
238290	guarda peito do soldado escarlate
238291	protetores do soldado escarlate
238292	guantes do soldado escarlate
238293	cinta do soldado escarlate
238294	coxotes do soldado escarlate
238295	pisoteadores do soldado escarlate
238298	molde capuz do augure escarlate
238299	molde dragonas do augure escarlate
238300	molde vestimentas do augure escarlate
238301	molde manilhas do augure escarlate
238302	molde luvetes do augure escarlate
238303	molde correia do augure escarlate
238304	molde perneiras do augure escarlate
238305	molde solas do augure escarlate
238306	molde bandana do infiltrador escarlate
238307	molde ombreiras do infiltrador escarlate
238308	molde colete do infiltrador escarlate
238309	molde bracadeiras do infiltrador escarlate
238310	molde luvas do infiltrador escarlate
238311	molde cinto do infiltrador escarlate
238312	molde calcotes do infiltrador escarlate
238313	molde sapatos do infiltrador escarlate
238314	molde coifa do guarda caca escarlate
238315	molde brafoneiras do guarda caca escarlate
238316	molde corrente do guarda caca escarlate
238317	molde munhequeiras do guarda caca escarlate
238318	molde protetores de mao do guarda caca escarlate
238319	molde fecho do guarda caca escarlate
238320	molde guarda pernas do guarda caca escarlate
238321	molde botas do guarda caca escarlate
238322	instrucoes capacete do soldado escarlate
238323	instrucoes espaldares do soldado escarlate
238324	instrucoes guarda peito do soldado escarlate
238325	instrucoes protetores do soldado escarlate
238326	instrucoes guantes do soldado escarlate
238327	instrucoes cinta do soldado escarlate
238328	instrucoes coxotes do soldado escarlate
238329	instrucoes pisoteadores do soldado escarlate
238348	o machado de decepar
238349	perneiras de pele de abominacao
238350	adaga focal de escarne
238351	a garra gelida
238352	gargantilha gelida de escarne
238353	dragonas da lady falther essa
238354	varinha da lady falther essa
238355	correntes do lich
238356	cintel de balzaphon
238357	cajado de balzaphon
238358	coxa do umbraxilos
238360	broquel do lorde umbraxilos
238361	lamina do lorde umbraxilos
238362	bracadeiras de recomposicao
238363	soqueira da sombra
238364	manto de revanchion
238637	bife de predador
238638	file de lombo
238639	omelete d alvorada
238641	rega bofe de pinamancha
238642	banquete de lagosta grandioso
238645	receita bife de predador
238646	receita file de lombo
238647	receita omelete d alvorada
238649	receita rega bofe de pinamancha
238650	receita banquete de lagosta grandioso
238681	bolsa empoeirada
238687	malho da ofensiva
238734	caixa de gambiarra teleporte
238735	caixa de gambiarra aceleracao nitrosa
238736	caixa de gambiarra deslocamento magnetico
238737	caixa de gambiarra
238781	transportador semisseguro nova avalon
238782	diagrama caixa de gambiarra
238783	diagrama caixa de gambiarra teleporte
238784	diagrama caixa de gambiarra aceleracao nitrosa
238785	diagrama caixa de gambiarra deslocamento magnetico
238786	diagrama gambiarra teleporte
238787	diagrama gambiarra aceleracao nitrosa
238788	diagrama gambiarra deslocamento magnetico
238789	diagrama transportador semisseguro nova avalon
238794	sobras pouco apetitosas
238811	maca suculenta
238830	telescopio de maca
238831	corda de maca
238899	peixes variados
238925	aljava escarlate
238926	bornal de municao escarlate
238927	molde aljava escarlate
238928	molde bornal de municao escarlate
238935	carne suavemente empesteada
238945	caladpedra
238960	caixote do intendente
238961	caladbolg
238985	caixote pesado
239010	punho da crematoria
239011	estilhaco de luz cristalizada
239012	farpa de luz cristalizada
239013	machado cristalino
239016	sais sagrados
239017	temperos requintados
239021	livro de receita da cassia
239060	vontade da montanha
239092	carta de convocacao canhestra
239097	chave da catedral
239117	calice do cruzado
239119	flecha sagrada
239147	mochila do cruzado
239148	bolsa alvorecente carmesim
239149	molde mochila do cruzado
239150	molde bolsa alvorecente carmesim
239159	s03 enclave escarlate escudo do capitao
239196	lamina forjada em luz arruinada
239197	lamina reforjada da crematoria
239215	emblema calcinado
239216	ferro forjado a luz
239218	anotacoes do moldapedra
239219	emblema da crematoria
239221	monstro espada1m basica
239222	diagrama arbusto instantaneo
239223	adereco domestico
239225	pena classuda
239246	lista de compras do teleco
239248	caixa de tralhas escarlate
239292	anotacoes do forjifice
239301	a crematoria corrompida
239302	cinto do uniforme escarlate
239316	rebimboca de triangulacao
239512	pulsos do rompe luz
239513	cinto do rompe luz
239514	guantes do rompe luz
239515	grevas do rompe luz
239516	ombreiras do rompe luz
239517	grande elmo do rompe luz
239518	escarcela do rompe luz
239519	corselete do rompe luz
239520	bracadeiras do rompe luz
239521	cinta do rompe luz
239522	manoplas do rompe luz
239523	escarpes do rompe luz
239524	brafoneiras do rompe luz
239525	capacete do rompe luz
239526	coxotes do rompe luz
239527	peitoral do rompe luz
239529	peitoral do espreitaurora
239530	grevas do espreitaurora
239531	manoplas do espreitaurora
239532	visor do espreitaurora
239533	perneiras do espreitaurora
239534	brafoneiras do espreitaurora
239535	cinto do espreitaurora
239536	avambracos do espreitaurora
239537	botas do espreitaurora
239538	cinturao do espreitaurora
239539	protetores de mao do espreitaurora
239540	bacinete do espreitaurora
239541	guarda pernas do espreitaurora
239542	espaldares do espreitaurora
239543	tunica do espreitaurora
239544	munhequeiras do espreitaurora
239547	munhequeiras da aparicao do ocaso
239548	couraca da aparicao do ocaso
239549	guantes da aparicao do ocaso
239550	mascara da aparicao do ocaso
239551	perneiras da aparicao do ocaso
239552	dragonas da aparicao do ocaso
239553	botinas da aparicao do ocaso
239554	cinto da aparicao do ocaso
239555	bracadeiras da aparicao do ocaso
239556	cinta da aparicao do ocaso
239557	manoplas da aparicao do ocaso
239558	escarpes da aparicao do ocaso
239559	brafoneiras da aparicao do ocaso
239560	capacete da aparicao do ocaso
239561	coxotes da aparicao do ocaso
239562	peitoral da aparicao do ocaso
239565	induto da revelacao
239572	botas da revelacao
239574	maos da revelacao
239575	coroa da revelacao
239577	calcas da revelacao
239581	dragonas da revelacao
239582	cinturao da revelacao
239583	pulsos da revelacao
239584	luvas de revelacao
239585	diadema da revelacao
239586	ombreiras da revelacao
239587	perneiras da revelacao
239588	braceletes da revelacao
239589	sandalias da revelacao
239590	cinto da revelacao
239591	veste da revelacao
239618	monstro espada 1m espada do vencedor alt
239688	monstro lanca 2m cavalaria escarlate lanca
239694	pacto da luz
239695	corcel escarlate
239696	punho da crematoria
239698	tecido alvorecente
239706	escarpes consagrados
239707	capacete consagrado
239708	brafoneiras consagradas
239709	coxotes consagrados
239710	sandalias consagradas
239712	ombreiras consagradas
239714	diadema consagrado
239715	veste consagrada
239716	luvas consagradas
239718	cinto consagrado
239719	braceletes consagrados
239721	perneiras consagradas
239722	munhequeiras consagradas
239726	botas consagradas
239729	bacinete consagrado
239730	protetores de mao consagrados
239731	tunica consagrada
239756	cinturao consagrado
239757	guarda pernas consagrados
239758	espaldares consagrados
239759	bracadeiras consagradas
239760	cinta consagrada
239761	peitoral consagrado
239762	manoplas consagradas
239764	folhamina carmesim
240018	manual de gambiarras do teleco
240020	guarda pernas da inquisicao
240021	espaldares da inquisicao
240022	botas da inquisicao
240023	avambracos da inquisicao
240024	cinto da inquisicao
240025	placa d ombros da inquisicao
240026	perneiras da inquisicao
240027	capacete da inquisicao
240028	luvas da inquisicao
240029	grevas da inquisicao
240030	peitoral da inquisicao
240031	bracadeiras da inquisicao
240032	cinta da inquisicao
240033	brafoneiras da inquisicao
240034	coxotes da inquisicao
240035	coroa da inquisicao
240036	manoplas da inquisicao
240037	escarpes da inquisicao
240038	couraca da inquisicao
240039	tunica da inquisicao
240040	bacinete da inquisicao
240041	protetores de mao da inquisicao
240042	munhequeiras da inquisicao
240043	cinturao da inquisicao
240044	munhecas firafolha
240045	cinta firafolha
240046	dragonas firafolha
240047	calcas firafolha
240048	capuz firafolha
240049	luvetes firafolha
240050	botas firafolha
240051	induto firafolha
240052	braceletes firafolha
240053	cinto firafolha
240054	ombreiras firafolha
240055	perneiras firafolha
240056	diadema firafolha
240057	luvas firafolha
240058	sandalias firafolha
240059	veste firafolha
240060	munhequeiras da vigia do caminho
240061	faixa da vigia do caminho
240062	ombreiras do vigia do caminho
240063	calcotes da vigia do caminho
240064	capucho da vigia do caminho
240065	guantes da vigia do caminho
240066	pisoteadores da vigia do caminho
240067	colete da vigia do caminho
240068	braceletes da vigia do caminho
240069	cordao da vigia do caminho
240070	dragonas da vigia do caminho
240071	kilt da vigia do caminho
240072	capuz da vigia do caminho
240073	contato da vigia do caminho
240074	sandalias da vigia do caminho
240075	couros da vigia do caminho
240076	bracadeiras da vigia do caminho
240077	cinta da vigia do caminho
240078	brafoneiras da vigia do caminho
240079	perneiras da vigia do caminho
240080	adereco da vigia do caminho
240081	manoplas da vigia do caminho
240082	escarpes da vigia do caminho
240083	armadura da vigia do caminho
240084	munhequeiras da vigia do caminho
240085	cinturao da vigia do caminho
240086	espaldares da vigia do caminho
240087	guarda pernas da vigia do caminho
240088	bacinete da vigia do caminho
240089	protetores de mao da vigia do caminho
240090	botas da vigia do caminho
240091	tunica da vigia do caminho
240092	tunica esmagalmas
240093	botas esmagalmas
240095	protetores de mao esmagalmas
240096	bacinete esmagalmas
240097	guarda pernas esmagalmas
240098	espaldares esmagalmas
240099	cinturao esmagalmas
240100	munhequeiras esmagalmas
240101	couraca esmagalmas
240102	escarpes esmagalmas
240103	luvas esmagalmas
240104	viseira esmagalmas
240105	coxotes esmagalmas
240106	brafoneiras esmagalmas
240107	cinta esmagalmas
240108	bracadeiras esmagalmas
240109	abraco esmagalmas
240110	grevas esmagalmas
240122	mitenes esmagalmas
240123	coroa esmagalmas
240124	kilt esmagalmas
240125	dragonas esmagalmas
240126	cordao esmagalmas
240127	braceletes esmagalmas
240128	armadura esmagalmas
240129	botinas esmagalmas
240130	guantes esmagalmas
240131	capacete esmagalmas
240132	cajado de teste
240134	perneiras esmagalmas
240135	palas esmagalmas
240136	cinto esmagalmas
240137	avambracos esmagalmas
240138	veste herege
240139	sandalias hereges
240140	luvas hereges
240141	capucho herege
240142	perneiras hereges
240143	ombreiras hereges
240144	cinto herege
240145	braceletes hereges
240146	induto herege
240147	protetores de mao hereges
240148	capuz herege
240149	calcas hereges
240150	dragonas hereges
240151	cinta herege
240152	munhequeiras hereges
240153	botas hereges
240174	solistra presa da primeira luz
240195	espada invisivel
240217	item de monstro cajado_2m_cravejado_a_02 vermelho
240742	monstro 1 m espada curta vermelho
240832	glandula nivofaciente
240835	caixote de suprimentos da clareira da lua
240836	apito de tessalia
240837	cordas do destino
240839	thal kituun a presenca oculta
240841	guarda do alto comandante
240842	arauto da podridao escarlate
240843	pistola abre batalha
240844	furador de putriss
240845	prototipo de ima
240846	sucata magnetica
240848	detritos de nordrassil
240849	cajado da clareira
240850	martelo punho da luz
240851	regicida
240852	cutelo carmesim
240853	ruina da rainha
240854	misericordia
240919	ravagane
240920	leogan
240921	esmagatoria escarlate
240922	engano
240923	duplicidade
240924	acha de armas da fera
240925	experimento 800m
240936	crematoria inerte
240945	fatia da torta de maca da cassia
240997	espora de fraga
240998	lamina soporifica
241001	queda de tyr
241002	resquicios da vermelha
241003	miragem bastao da ilusao
241004	enigma
241006	pinaculo do sacrificio
241008	condenacao
241011	grande cajado da lealdade
241012	varinha da reanimacao
241015	egide do bastiao escarlate
241017	desatino do demonio
241018	coracao nathrezim
241020	diario completo de putriss
241021	a luz
241022	manto d alvorada
241023	clamide da discordia
241024	capa do comandante escarlate
241025	bandeira do almirante alquebrado
241026	xale do cardeal
241027	guarda da protetora escudeira
241028	aro nathrezim
241029	elo de baelin
241030	anel da confraria de alvano
241031	promessa de bartolomeu
241032	anel da ressurreicao
241034	coracao de luz
241037	experimento abandonado
241038	didjeridu de sir dornel
241039	infusao de almas
241068	estandarte de estephanio
241069	gargantilha encadeada
241070	esperanca de herodes
241071	talisma do vigarista escarlate
241072	ampola de pus
241073	toque da luz
241074	elmo do cruzado vermelho
241075	elmo do destruidor em furia
241076	capucho do pacto
241077	chapeu do cardeal
241078	mortalha do embalsamado
241079	peso do mundo
241080	brafoneiras de herodes
241081	crematoria corrompida
241082	crematoria
241083	s03 enclave escarlate espada de 2m raide
241084	s03 scarlet enclave herod s sword normal
241085	s03 enclave escarlate espada de 1m
241086	escudo torreao escarlate
241087	cajado escarlate
241088	cajado escarlate
241089	adaga escarlate
241090	machado grande escarlate
241091	maca escarlate
241092	gume escarlate
241120	s03 scarlet enclave herod s sword molten
241121	adaga renascida
241122	faca renascida
241123	adaga renascida
241124	faca renascida
241128	pilha de porteflexes
241152	omoplatas forjaurora
241153	dragonas de doan
241154	dragonas pele de urso
241156	vestes pestilentas
241157	guarda peito escarlate
241158	corrente dos abandonados
241159	induto do monasterio
241160	malha de aneis vestida a aurora
241161	peitoral templario
241162	couros bencao do sol
241163	bracadeiras ardessol
241164	couros argenteos arranhados
241165	munhequeiras penitentes
241166	embraces listras d aurora
241167	grilhoes de prisioneiro
241168	guantes ardessol
241169	prototipo de aceleracao nitrosa
241170	protetores do enclave
241171	luvas das almas partidas
241172	manoplas trancadas de caldoran
241173	cingidouro do grao teurgo
241174	cinturao do campeao renascido
241175	cinto de ferramentas do torturador
241176	fim de diesalven
241177	kilt do arcanista escarlate
241178	placa da dor impavida
241179	perneiras da catastrofe
241180	perneiras de escama da luz
241181	perneiras encadeadas vestidas a aurora
241182	guarda pernas de placa templario
241183	trilha cinzas
241184	sandalias do salvador
241185	botas de treinamento de urso
241186	botas de malha polidas escarlates
241187	botinas belicas carmesins
241190	apito de passaro
241191	formula encantamento do grande cruzado arma
241195	formula encantamento de grande feiticeiro arma de 2m
241201	formula encantamento de grande feiticeiro arma
241212	cocoricanhao
241241	dobrao da sorte
241613	nao tem mais utilidade
241629	bala de canhao escarlate
241649	manoplas da guarda de eira dos montes
241650	pocao elevada descolorida de cura
241651	receita pocao elevada descolorida de cura
241652	coracao animal descorado
241653	lamina aquecida
241654	crematoria inerte
241655	pocao de cura mal manejada
241656	pocao de cura mal manejada
241657	lamina temperada
242018	coracao sangrento das terras pestilentas
242224	cesta de coracoes
242256	algibeira de bombas incendiarias
242257	amostra alquimica misteriosa
242258	anotacoes de pesquisa
242266	mundo das protecoes
242267	de arcanista a arquimago
242268	encantamento dado a um cruzado
242269	inteligencia do grande feiticeiro
242270	inteligencia do grande arcanista
242271	inteligencia do grande cruzado
242310	mao da justica renascida
242311	amuleto de leonid
242312	selo da familia bartolomeu
242313	diario do venerado
242314	cinzas do cruzado caido
242315	cinzas da arrogancia
242316	po do desafiador
242317	livro de oracoes profanado
242319	amostras da nova peste
242320	amostras da nova peste
242361	formula encantamento de grao inquisidor arma de 2m
242362	inteligencia do grao inquisidor
242363	quem o que onde quando e morra cinco chaves para a melhor inquisicao
242364	tendao de dragao da luz maduro
242365	asa de balnazzar
242366	destino inescapavel
242367	asa e corda
242425	diario rasgado pagina 1
242426	diario rasgado pagina 2
242427	diario de putriss
242428	diario rasgado pagina 3
242429	diario de putriss
242430	diario rasgado pagina 4
242431	diario rasgado pagina 5
242432	diario de putriss
242433	diario rasgado pagina 6
242434	diario de putriss
242435	diario de putriss
242436	diario de putriss
242465	fragmento do calice impelido
242793	canhao vil portatil
243010	crematoria corrompida
243064	cajado longo
243065	varinha quebrada
243177	brinquedo engenhoso
243198	mira de precisao aviaria
243229	pedra de regresso da aurora
243230	lamina forjada em luz arruinada
243345	cajado longo
244353	mira de precisao aviaria
244460	caladbolg
245675	chave da porta de dentro dos gordok
246055	guantes da inquisicao
246056	bracadeiras da inquisicao
246057	pisoteadores da inquisicao
246058	calcas de placa da inquisicao
246059	cordao da inquisicao
246060	corselete da inquisicao
246061	palas da inquisicao
246062	viseira da inquisicao
]==]
