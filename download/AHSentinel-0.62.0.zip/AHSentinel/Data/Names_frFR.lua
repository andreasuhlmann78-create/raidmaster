-- AHSentinel - Item-Namen (frFR), 22711 Items
-- Quelle: siehe Data/QUELLEN.txt. Automatisch erzeugt, nicht von Hand ändern.
AHAnalyzerPro_NameData = AHAnalyzerPro_NameData or {}
AHAnalyzerPro_NameData["frFR"] = [==[

25	Vieille épée courte
35	Vieux bâton
36	Vieille masse
37	Vieille hache
38	Chemise de recrue
39	Pantalon de recrue
40	Bottes de recrue
43	Bottes d'écuyer
44	Pantalon d'écuyer
45	Chemise d'écuyer
47	Bottes de détrousseur
48	Pantalon de détrousseur
49	Chemise de détrousseur
51	Bottes de néophyte
52	Pantalon de néophyte
53	Chemise de néophyte
55	Bottes d'apprenti
56	Robe d'apprenti
57	Robe d'acolyte
59	Chaussures d'acolyte
60	Tunique doublée
61	Pantalon nain en cuir
79	Chausses naines en tissu
80	Chaussures bordées de fourrure
85	Gilet en cuir sale
117	Viande séchée coriace
118	Potion de soins mineure
120	Pantalon de nervi
121	Bottes de nervi
127	Chemise de trappeur
129	Bottes robustes de trappeur
139	Pantalon de bagarreur
140	Bottes de bagarreur
147	Pantalon robuste de trappeur
148	Chemise robuste de trappeur
153	Kilt primitif
154	Mantelet primitif
159	Eau de source
182	Tête de Garrick
193	Gilet en étoffe rapiécée
194	Pantalon en étoffe rapiécé
195	Bottes en étoffe rapiécées
200	Gilet en étoffe épaisse
201	Pantalon en étoffe épaisse
202	Chaussures en étoffe épaisse
203	Gants en étoffe épaisse
209	Pantalon en cuir sale
210	Bottes en cuir sale
236	Armure en cuir traité
237	Pantalon en cuir traité
238	Bottes en cuir traité
239	Gants en cuir traité
285	Haubergeon d'écailles
286	Pantalon en écailles
287	Bottes en écailles
414	Dalaran piquant
422	Caprice des nains
537	Ecaille de Furie terne
555	Plumes de vautour
556	Bec de busard
647	Destin
710	Brassards de la milice du peuple
711	Gants en étoffe rapiécés
714	Gants en cuir sale
718	Gants en écailles
719	Gants d'éleveur de lapins
720	Gants de bagarreur
723	Foie de Broche-tripes
724	Tourte au foie de Broche-tripes
725	Patte de gnoll
727	Epée courte ébréchée
728	Recette : Ragoût de la marche de l'Ouest
729	Viande filandreuse de vautour
730	Oeil de murloc
731	Groin de Broche-tripes
732	Okra
733	Ragoût de la marche de l'Ouest
735	Médaillons de Rolf et Malakai
737	Eau de la source sacrée
738	Sac d’orge
739	Sac de maïs
740	Sac de seigle
742	Une branche de sycomore
743	Fagot de chêne
744	Flacon de botte de Thunderbrew
745	Documents du maréchal McBride
748	Bon pour une pièce d'armure de Stormwind
750	Viande de loup coriace
752	Masque rouge
753	Epée courte de Dragonmaw
754	Epée courte de vengeance
755	Bougie fondue
756	Pioche de tunnelier
763	Brassards couverts de glace
765	Feuillargent
766	Masse à ailettes
767	Grand bâton
768	Hache de bûcheron
769	Morceau de viande de sanglier
770	Croc pointu de crocilisque
771	Défense ébréchée de sanglier
772	Grande bougie
773	Poussière d'or
774	Malachite
776	Vendetta
777	Dent de Rôdeur
778	Pioche de kobold
779	Coquillage luisant
780	Aileron de murloc déchiré
781	Marteau en pierre de gnoll
782	Brassard peint de gnoll
783	Peau légère
785	Mage royal
787	Maquereau ombré
789	Marteau de guerre
790	Hache de forestier
791	Bâton des cendres
792	Sandales tricotées
793	Gants tricotés
794	Pantalon tricoté
795	Tunique tricotée
796	Bottes en cuir grossier
797	Gants en cuir grossier
798	Pantalon en cuir grossier
799	Gilet en cuir grossier
804	Grand sac bleu
805	Petite bourse rouge
809	Rasoir sanglant
810	Marteau du vent nordique
811	Hache des bois profonds
812	Bâton des bois luminescent
813	Rouage cassé
814	Flasque d'huile
816	Dague courte
818	Oeil de tigre
820	Trancheuse
821	Gilet rivepatte en cuir
826	Hache brutale de Rivepatte
827	Masse rivetée
828	Petite bourse bleue
829	Masque en cuir rouge
832	Ceinture de Défias en argent
833	Pierre de vie
835	Grand filet
837	Armure en toile renforcée
838	Pantalon en toile renforcée
839	Gants en toile renforcée
840	Chaussures en toile renforcée
841	Montre de Furlbrow
843	Bottes en cuir tanné
844	Gants en cuir tanné
845	Pantalon en cuir tanné
846	Pourpoint en cuir tanné
847	Cotte de mailles
848	Pantalon en mailles
849	Bottes en mailles
850	Gants en mailles
851	Coutelas
852	Masse
853	Hachette
854	Bâton
856	Sac bleu en cuir
857	Grand sac rouge
858	Potion de soins inférieure
859	Chemise élégante
860	Bottes de cavalier
862	Anneau runique
863	Faucheuse sombre
864	Epée longue des chevaliers
865	Masse plombée
866	Bâton de moine
867	Gants de puissance sacrée
868	Protectrice ardente
869	Epée longue éblouissante
870	Hache de guerre flamboyante
871	Rafaleuse
872	Fend-le-roc
873	Bâton de Jordan
875	Invocation de cheval bai
876	Vieille targe en bois
878	Petite filière
880	Bâton des horreurs
884	Côte de goule
885	Hache en métal noir
886	Epée courte en métal noir
887	Morceau de chair
888	Gants de bataille nagas
889	Une lettre poussiéreuse
890	Bâton maudit de l'enchanteur
892	Gants de sortilège gnoll
893	Croc de loup redoutable
895	Crâne de worgen
896	Croc de worgen
897	Brassards du loup enragé
899	Croc de Tisse-venin
901	Deptecated White Stallion Summoning (Mount)
910	Une vieille lettre
911	Branche de bois de fer
913	Grande épée ogre
914	Grande cotte d'anneaux ogre
915	Masque rouge en soie
916	Une page de journal déchirée
918	Sac en peau de déviant
920	Masse à pointes maléfique
921	Une vieille page de journal
922	Faux dace
923	Epée longue
924	Maillet
925	Fléau
926	Hache de bataille
927	Hache double
928	Grand bâton
929	Potion de soins
932	Sacoche de selle de palefroi corrompu
933	Grand sac à dos
934	Faucheuse de Stalvan
935	Epée de veilleur
936	Masse de minuit
937	Bâton noir en bois de Pénombre
938	Pages de journal maculées de boue
939	Une page de journal maculée de sang
940	Robe de perspicacité
942	Anneau de glace
943	Bâton de geôlier
944	Bâton de mage élémentaire
945	Epée des ténèbres
948	Epée de la nature
954	Parchemin de force
955	Parchemin d'intelligence
957	Cargaison de William
961	Herbe de soins
962	Tourte de panse de porc
966	Tome de Bouclier de givre
967	Tome de Gardien de givre
968	Tome de Trait de feu
973	Tome de Boule de feu II
974	Tome d'Armure de givre II
975	Tome d'Entraves de glace
976	Tome de Délivrance de la malédiction
980	Tome de Bouclier de givre II
981	Collier de Bernice
983	Echarpe rouge en lin
985	Tome de Déverrouillage de Khadgar
986	Tome d'Eclair de givre II
989	Tome de Nova de givre
992	Tome de Boule de feu III
994	Tome d'Armure de glace
997	Epée flamboyante de faiblesse
1002	Tome d'Invisibilité inférieure
1004	Tome d'Entraves de glace II
1006	Collier de cuivre
1008	Epée de taille
1009	Marteau compact
1010	Bâton court
1011	Hache tranchante
1013	Vis en fer
1015	Steak de loup
1017	Kébab de loup assaisonné
1019	Masque rouge en lin
1029	Tablette du totem du serpent
1030	Tablette de Volonté inflexible
1031	Tablette d'Eclair de lave
1032	Tablette de Totem d'agitation
1033	Tablette d'Annuler poison
1034	Tablette de Force permanente
1035	Tablette d'Appel des esprits
1036	Tablette d'Annuler maladie
1037	Tablette d'Eclair II
1038	Tablette de Restauration II
1041	Cor du loup noir
1048	Tablette de Bouclier de foudre II
1049	Tablette d'Expiation
1052	Tablette d'Armure spirituelle II
1053	Tablette d'Eclair de lave II
1057	Tablette de Restauration III
1058	Tablette d'Eclair III
1061	Tablette d'Annuler poison II
1063	Tablette d'Annuler maladie II
1072	Bouteille de tord-boyaux pleine
1074	Patte d'araignée
1075	Pendentif sombrepoil
1076	Anneau du renégat défias
1077	Anneau de mage défias
1080	Viande de condor coriace
1081	Chair croustillante d'araignée
1082	Goulash des Carmines
1083	Glyphe d'Azora
1084	Codex de Rénovation
1085	Codex de Vision télépathique
1086	Codex de Feu intérieur
1087	Codex de Mot de l’ombre : Douleur
1088	Codex de Rénovation II
1089	Codex d'Annuler maladie
1090	Codex de Résurrection
1091	Codex de Châtiment sacré II
1092	Codex de Soins inférieurs II
1093	Codex de Délivrance de la malédiction
1095	Codex de Dissipation de la magie
1096	Codex de Mot de l’ombre : Douleur II
1100	Codex de Châtiment sacré III
1101	Codex de Rénovation V
1102	Codex de Soins inférieurs III
1105	Codex de Rénovation VI
1108	Codex de Rénovation III
1109	Codex d'Emprise
1111	Codex de Sommeil
1112	Codex de Mot sacré : Robustesse II
1113	Pain invoqué
1114	Pain de seigle invoqué
1116	Anneau d'argent pur
1119	Esprits en bouteille
1121	Bottes du Lynx
1127	Sac de poudre noire
1129	Croc de goule
1130	Fiole de venin d'araignée
1131	Totem d'affliction
1132	Cor du loup des bois
1133	Cor du loup blanc
1134	Cor du loup gris
1136	Libram : Faveur divine II
1138	Libram : Faveur divine
1139	Libram : Epuration
1141	Libram : Lumière sacrée II
1144	Libram : Bouclier divin
1146	Libram : Résurrection
1149	Libram : Sceau de puissance II
1150	Libram : Purification
1151	Libram : Lumière sacrée III
1154	Ceinture de la milice du peuple
1155	Bâtonnet du somnanbule
1156	Anneau somptueux
1158	Solide masse en métal
1159	Bâton de la milice
1161	Epée courte de la milice
1164	Tome de Sam
1166	Targe ébréchée
1167	Petite targe
1168	Bouclier flamboyant
1169	Bouclier sombre
1171	Robe de confection
1172	Torche de Grayson
1173	Bottes usées
1175	Une dent en or
1176	Sels odorants
1177	Huile d'Olaf
1178	Roquette explosive
1179	Lait glacé
1180	Parchemin d'endurance
1181	Parchemin d'esprit
1182	Brassards cloutés de cuivre
1183	Garde-poignets élastiques
1187	Collier clouté
1189	Anneau de surveillant
1190	Cape de surveillant
1191	Sac de billes
1193	Targe cerclée
1194	Bâtarde
1195	Pelle de kobold
1196	Tabard
1197	Masse géante
1198	Claymore
1199	Pierre d'âme
1200	Grand bouclier en bois
1201	Ecu terne
1202	Pavois
1203	Egide de Stormwind
1204	La Tour verte
1205	Jus de melon
1206	Agate mousse
1207	Murphstar
1208	Lettre d'amour de Maybell
1210	Oeil ténébreux
1211	Harnais de guerre gnoll
1212	Bave de gnoll
1213	Brassards des gnolls
1214	Marteleur gnoll
1215	Ceinturon de maintien
1216	Brassards de givre
1217	Récompense inconnue
1218	Gourdin de guerre gnoll
1219	Machette des Carmines
1220	Couperet vif
1221	Ecaille ventrale de jeune dragon
1222	Dent cassée
1224	Grimoire de Détection des démons
1228	Grimoire d'Ebullition
1229	Grimoire de Création de Pierre d'âme
1231	Grimoire de Trait de l’ombre II
1232	Grimoire de Peau de démon II
1238	Grimoire de Peur
1239	Grimoire de Siphon de mana
1243	Grimoire de Trait de l’ombre III
1244	Grimoire d'Armure démoniaque
1245	Grimoire d'Immolation II
1246	Grimoire de Respiration démoniaque
1250	Grimoire de Détection d'Invisibilité inférieure
1251	Bandage en lin
1252	Note de Mamie Stonefield
1254	Pierre de feu inférieure
1256	Feuille de Varech cristallin
1257	Liqueur d'invisibilité
1259	JYoo test item
1260	Tête de Tharil'zun
1261	Orbe de minuit
1262	Tonneau de Tonnebière
1263	Incandescente
1264	Brise-crâne
1265	Dard de scorpion
1270	Cape finement tissée
1273	Cotte d'anneaux de la forêt
1274	Houblon
1275	Lorica d'adjoint
1276	Targe en acier trempé
1280	Chaperon enveloppant
1282	Camail en métal étincelant
1283	Note de Verner
1284	Caisse de fers à cheval
1287	Croc de tarentule géante
1288	Grande glande à venin
1292	Fendoir du Boucher
1293	La situation de Lakeshire
1294	La réponse du général
1296	Masse de Blackrock
1297	Robe de l'exhalombre
1299	Ceinture spirituelle inférieure
1300	Bâton spirituel inférieur
1302	Gants de dragonnet noir
1303	Gants d'ouvrier du pont
1304	Gants d'équitation
1306	Garde-poignets en crinière de loup
1307	Plan de route du Collecteur
1309	Boîte d'outils d'Oslow
1310	Pantalon de Smith
1314	Doigts de goule
1315	Collier de lis
1317	Bâton de racine durcie
1318	Découpeuse
1319	Anneau de volonté de fer
1322	Huile de foie de poisson
1325	Bouquet de jonquilles
1326	Poisson-lune sauté
1327	Note de Wiley
1328	Livre de Lucioles
1332	Livre de Guérison du poison
1334	Livre de Récupération II
1339	Livre de Sarments
1341	Livre d'Eclat lunaire
1349	Caisse d'Abercrombie
1351	Brassards d'osselets
1352	Mortier de crâne craquelé
1353	Rapport de Shaw
1355	Cape en peau de daim
1356	Recommandation - Forêt d'Elwynn
1357	Carte au trésor du capitaine Sander
1358	Un indice menant au trésor de Sander
1359	Gants marqués d'un lion
1360	Gantelets de Stormwind en mailles
1361	Un autre indice menant au trésor de Sander
1362	Le dernier indice menant au trésor de Sander
1364	Gilet rapiécé en cuir
1366	Pantalon rapiécé en cuir
1367	Bottes rapiécées en cuir
1368	Gants rapiécés en cuir
1369	Ceinture rapiécée en cuir
1370	Brassards rapiécés en cuir
1372	Cape déchirée
1374	Chaussures râpées
1376	Cape râpée
1377	Gants râpés
1378	Pantalon râpé
1380	Robe râpée
1381	Un message mystérieux
1382	Masse de pierre
1383	Tomahawk
1384	Lame terne
1386	Hache des chardons
1387	Pourfendeuse
1388	Bâton noueux
1389	Marteau de mine kobold
1391	Bâton mystique Rivepatte
1394	Gourdin de bois d'épave
1395	Pantalon d'apprenti
1396	Pantalon d'acolyte
1399	Bougie magique
1400	Insigne de Swiftfeather
1401	Feuille de Thé vert
1402	Soufre
1404	Charme des flots
1405	Bâton d'écume
1406	Lance incrustée de perles
1407	Demande d'aide de Solomon à la marche de l'Ouest
1408	Réponse de Stoutmantle à Solomon
1409	Demande d'aide de Solomon à Darkshire
1410	Réponse d'Ebonlocke à Solomon
1411	Vieux bâton usé
1412	Bâtarde rudimentaire
1413	Epée médiocre
1414	Masse craquelée
1415	Marteau de charpentier
1416	Hachette rouillée
1417	Hache de guerre oxydée
1418	Ceinture usée en cuir
1419	Bottes usées en cuir
1420	Brassards usés en cuir
1421	Cape usée en peau
1422	Gants usés en cuir
1423	Pantalon usé en cuir
1425	Gilet usé en cuir
1427	Bottes en patchwork
1429	Cape en patchwork
1430	Gants en patchwork
1431	Pantalon en patchwork
1433	Armure en patchwork
1434	Bâton de cire luminescent
1436	Culotte des frontaliers
1438	Bouclier de guerrier
1440	Casse-tête gnoll
1443	Amulette de Cainwyn
1445	Espauliers Blackrock
1446	Bottes Blackrock
1447	Anneau des sauveurs
1448	Gantelets Blackrock
1449	Anneau de canalisation mineure
1450	Potion de ferveur
1451	Fiole de suc de zombie
1453	Peigne spectral
1454	Hache du Massacreur
1455	Hache du champion Blackrock
1457	Masse sombrepoil
1458	Marteau sombrepoil
1459	Hachette sombrepoil
1460	Epée à deux mains sombrepoil
1461	Hache de guerre de tueur
1462	Anneau des ténèbres
1464	Serre de busard
1465	Fléau des tigres
1467	Poisson-lune
1468	Aileron de murloc
1469	Cimeterre d'Atun
1470	Sac en peau de murloc
1473	Bâton des rivières
1475	Petite glande à venin
1476	Patte d'araignée brisée
1477	Parchemin d'Agilité II
1478	Parchemin de Protection II
1479	Mitaines de Salma
1480	Marteau de la milice du peuple
1481	Griffe-sinistre
1482	Ombrecroc
1483	Ecraseur
1484	Bâton des ténèbres
1485	Fourche
1486	Veste d'écorce
1487	Pain noir invoqué
1488	Armure de vengeur
1489	Armure du voile funèbre
1490	Talisman de gardien
1491	Anneau de précision
1493	Cimeterre des maraudeurs
1495	Chaussures en calicot
1497	Cape en calicot
1498	Gants en calicot
1499	Pantalon en calicot
1501	Tunique en calicot
1502	Ceinture déformée en cuir
1503	Bottes déformées en cuir
1504	Brassards déformés en cuir
1505	Cape déformée
1506	Gants déformés en cuir
1507	Pantalon déformé en cuir
1509	Gilet déformé en cuir
1510	Marteau lourd
1511	Epée commune
1512	Hache de guerre rudimentaire
1513	Vieille épée longue
1514	Marteau de guerre rouillé
1515	Bâton en bois brut
1516	Hachette usée
1518	Peigne fantôme
1519	Oreille de Bloodscalp
1520	Sueur de troll
1521	Hache ogre
1522	Lance de chasseur de têtes
1523	Grand gourdin de pierre
1524	Défense de Skullsplitter
1528	Poignée d'avoine
1529	Jade
1532	Tête réduite
1534	Libram : Lumière sacrée IV
1536	Libram : Sceau de colère
1537	Sac de nourriture de la Vieille Blanchy
1539	Bâton noueux de l'Ermite
1547	Bouclier de la Foi
1554	Tome de Trait de givre III
1557	Targe des Mers
1559	Tome de Projectile des arcanes II
1560	Sandales branchie-bleue
1561	Robe de moissonneur
1566	Grande lame de la milice du peuple
1567	Tome de Déverrouillage de Khadgar II
1568	Tome d'Elémentaire d'eau
1571	Tome de Nova de givre II
1574	Tome de Gardien de feu
1588	Tablette d'Eclair de glace III
1589	Tablette d'Armure spirituelle III
1591	Tablette de Bouclier de foudre III
1596	Mèche de cheveux fantômes
1597	Tablette de Tempête de foudre
1598	Racine pourrie
1602	Faucille
1603	Tablette d'Appel des esprits II
1604	Epée chromatique
1607	Gardienne d'âme
1608	Masse Brise-tête
1613	Bâton de chasseur d'esprit
1619	Tablette de Tempête de foudre II
1623	Sacoche en peau de raptor
1624	Heaume skullsplitter
1625	Flamberge exquise
1630	Electro-lanterne cassée
1637	Lettre à Ello
1639	Hache dévorante
1640	Monstrueuse hache de guerre
1641	Codex de Mot de l’ombre : Douleur III
1645	Jus de baie lunaire
1648	Codex de Soins IV
1651	Codex de Mot sacré : Bouclier VI
1652	Solide boîte de repas
1656	Lettre traduite
1657	Codex de Résurrection II
1658	Codex de Mot de l’ombre : Douleur IV
1659	Gants d'ingénieur
1664	Bâtonnet de renforcement
1676	Codex de Sommeil II
1677	Broigne en écailles de drake
1678	Bottes ogre noires
1679	Massue Korg
1680	Tranche-tête
1681	Grimoire de Faiblesse
1685	Sac en peau de troll
1686	Moustache à poil dur
1687	Griffe rétractile
1688	Longue queue soyeuse
1696	Griffe de raptor
1697	Dent de raptor
1701	Griffe de basilic
1702	Epine dorsale intacte de basilic
1703	Queue de basilic de cristal
1705	Pierre de lune inférieure
1706	Eclats de Profondazur
1707	Brie de Stormwind
1708	Nectar sucré
1710	Potion de soins supérieure
1711	Parchemin d'Endurance II
1712	Parchemin d'Esprit II
1713	Ankh de vie
1714	Collier de Calisea
1715	Armure jazeran polie
1716	Robe des magi
1717	Tunique en mailles doublières
1718	Pantalon en cuir de basilic
1720	Bâton de la Nature
1721	Marteau de guerre viking
1722	Marteau de guerre fracasseur
1725	Grand sac à dos
1726	Lance en os empoisonnée
1727	Epée de putréfaction
1728	Epée flamboyante de Teebu
1729	Sacoche des Veilleurs
1730	Ceinture usée en mailles
1731	Bottes usées en mailles
1732	Brassards usés en mailles
1733	Cape usée
1734	Gants usés en mailles
1735	Pantalon usé en mailles
1737	Haubergeon usé
1738	Ceinture en mailles entrelacées
1739	Bottes en mailles entrelacées
1740	Brassards en mailles entrelacées
1741	Cape lacée
1742	Gants en mailles entrelacées
1743	Pantalon en mailles entrelacées
1744	Protège-épaules en mailles entrelacées
1745	Haubergeon entrelacé
1746	Ceinture en anneaux rivetés
1747	Bottes en anneaux rivetés
1748	Brassards en anneaux rivetés
1749	Cape en anneaux rivetés
1750	Gants en anneaux rivetés
1751	Pantalon en anneaux rivetés
1752	Protège-épaules en anneaux rivetés
1753	Lorica rivetée
1754	Ceinture en anneaux renforcés
1755	Bottes en anneaux renforcés
1756	Brassards en anneaux renforcés
1757	Cape en anneaux renforcés
1758	Gants en anneaux renforcés
1759	Pantalon en anneaux renforcés
1760	Protège-épaules en anneaux renforcés
1761	Lorica renforcée
1764	Chaussures en canevas
1766	Cape en canevas
1767	Gants en canevas
1768	Pantalon en canevas
1769	Protège-épaules en canevas
1770	Gilet en canevas
1772	Chaussures en brocart
1774	Cape en brocart
1775	Gants en brocart
1776	Pantalon en brocart
1777	Protège-épaules en brocart
1778	Gilet en brocart
1780	Sandales à couture croisée
1782	Cape à couture croisée
1783	Gants à couture croisée
1784	Pantalon à couture croisée
1785	Protège-épaules à couture croisée
1786	Gilet à couture croisée
1787	Ceinture raccommodée en cuir
1788	Bottes raccommodées en cuir
1789	Brassards raccommodés en cuir
1790	Cape raccommodée
1791	Gants raccommodés en cuir
1792	Pantalon raccommodé en cuir
1793	Protège-épaules raccommodés en cuir
1794	Pourpoint raccommodé en cuir
1795	Ceinture en cuir brut
1796	Bottes en cuir brut
1797	Brassards en cuir brut
1798	Cape en cuir brut
1799	Gants en cuir brut
1800	Pantalon en cuir brut
1801	Protège-épaules en cuir brut
1802	Tunique en cuir brut
1803	Ceinture en cuir armé
1804	Bottes en cuir armé
1805	Brassards en cuir armé
1806	Cape en cuir armé
1807	Gants en cuir armé
1808	Pantalon en cuir armé
1809	Protège-épaules en cuir armé
1810	Armure en cuir armé
1811	Claymore émoussée
1812	Hachette de guerre
1813	Bâton de guerre fendu
1814	Maillet endommagé
1815	Masse ornementale
1816	Hache déséquilibrée
1817	Epée courte militaire
1818	Claymore militaire
1819	Bêche de guerre
1820	Grand maillet en bois
1821	Epée profane
1822	Bâton de marche
1823	Gourdin fracassant
1824	Hache de guerre rutilante
1825	Grand fracasseur
1826	Brise-roc
1827	Fendoir à viande
1828	Hache de guerre du roc
1829	Coutelas court
1830	Bâtarde longue
1831	Bâton de guerre en chêne
1832	Pantalon de chance
1835	Ceinture en cuir sale
1836	Brassards en cuir sale
1839	Ceinture en cuir grossier
1840	Brassards en cuir grossier
1843	Ceinture en cuir tanné
1844	Brassards en cuir tanné
1845	Ceinture en mailles
1846	Brassards en mailles
1849	Ceinture en cuir traité
1850	Brassards en cuir traité
1851	Eau de purification
1852	Brassards en écailles
1853	Ceinture en écailles
1875	Plaque de Crispechardon
1877	Livre de Récupération III
1882	Livre d'Eclat lunaire III
1886	Livre d'Eclat lunaire II
1893	Piolet vengeur
1894	Carte du syndicat des mineurs
1913	Masse cloutée
1917	Dague ornée
1922	Fournitures pour Sven
1923	Sacoche de l'Ambassadeur
1925	Rapière défias
1926	Masse équilibrée
1927	Fendoir des Mortemines
1928	Bâton de mage défias
1929	Pantalon soyeux
1930	Cape de maçon
1931	Grande griffe de gnoll
1933	Bâton de conjuration
1934	Pantalon de maçon
1935	Lame de l'Assassin
1936	Tournevis gobelin
1937	Coutelas trancheur
1938	Marteau majeur
1939	Outre de rhum doux
1941	Tonneau de merlot
1942	Bouteille de tord-boyaux
1943	Jambières en mailles des gobelins
1944	Gants de ferronnier
1945	Gants de menuiserie
1946	Miroir de Marie
1951	Coutelas des Flots noirs
1955	Bottes en mailles Dragonmaw
1956	Ancien pendentif sombrepoil
1958	Fémur pétrifié
1959	Pioche en fer glacial
1962	Pendentif sombrepoil luminescent
1965	Gants du loup blanc
1968	Monocle d'ogre
1970	Baume de restauration
1971	Titre de propriété de Furlbrow
1972	Titre de propriété de la marche de l'Ouest
1973	Orbe de tromperie
1974	Brassards de projection mentale
1975	Ancienne Epée de Pysan
1976	Tape-dur
1977	Sac à 20 emplacements
1978	Gants griffe-de-loup
1979	Mur des morts
1980	Anneau ténébreux
1981	Pourpoint en mailles glaciale
1982	Lame noire
1986	Etripeuse
1987	Cocotte réparée de Krazek
1988	Gantelets de général de brigade
1990	Maillet lesté
1991	Pelle de puissance des gobelins
1992	Fétiche des marais
1993	Anneau de concentration
1994	Griffe d'ébène
1996	Anneau vaudou
1997	Robe en feutre pressé
1998	Bâton de canalisation Bloodscalp
2000	Archeus
2004	Journal de Grelin Whitebeard
2005	La première légende des trolls
2006	La deuxième légende des trolls
2007	La troisième légende des trolls
2008	La quatrième légende des trolls
2011	Sabre courbe
2013	Bâton de la crypte
2014	Epée en métal noir
2015	Hache de guerre en métal noir
2016	Cotte d'anneaux poussiéreuse
2017	Brassards luminescents en cuir
2018	Epée longue squelettique
2020	Griffeuse
2021	Bouclier Carapace vert
2024	Espadon
2025	Hache ébarbée
2026	Marteau en pierre
2027	Cimeterre
2028	Marteau
2029	Fendoir
2030	Bâton noueux
2032	Crispins de Gallan
2033	Bottes de l'Ambassadeur
2034	Robe d'érudition
2035	Lame des cieux noirs
2036	Gants de mine poussiéreux
2037	Bottes de tunnelier
2039	Anneau des plaines
2040	Protecteur troll
2041	Tunique de la marche de l'Ouest
2042	Bâton de la marche de l'Ouest
2043	Anneau des Esprits glacés
2044	Hache des Esprits glacés
2046	Kukri branchie-bleue
2047	Hache d'Anvilmar
2048	Marteau d'Anvilmar
2054	Hache trogg
2055	Petit marteau en bois
2056	Le marteau de velours
2057	Epée courte défias
2058	Maillet de Kazon
2059	Cape de factionnaire
2064	Gourdin trogg
2065	Lame mâcheroc
2066	Hachette mâcheroc
2067	Bâton des froideurs
2069	Gilet en peau d'ours noir
2070	Bleu de Darnassus
2072	Bâton des mages nains
2073	Hachette naine
2074	Epée courte endurcie
2075	Masse des prêtres
2077	Bâton de magicien
2078	Epée courte du nord
2079	Marteau de sergent
2080	Hache des collines
2082	Sacoche de Wizbang
2084	Epée bâtarde en acier noir
2085	Morceau de chair
2087	Carapace de clampant durcie
2088	Longue patte de clampant
2089	Dague Scrimshaw
2091	Poussière magique
2092	Dague usée
2098	Fusil à canon double
2099	Canon à main nain
2100	Espingole soigneusement calibrée
2101	Carquois léger
2102	Petite giberne
2105	Chemise de nervi
2108	Gilet frostmane en cuir
2109	Lorica frostmane
2110	Robe légère de fèvre-mage
2112	Pourpoint de bûcheron
2113	Note de Calor
2114	Robe neigeuse
2117	Chaussures en étoffe légère
2119	Gants en étoffe légère
2120	Pantalon en étoffe légère
2121	Jacque en étoffe légère
2122	Ceinture en cuir craquelé
2123	Bottes en cuir craquelé
2124	Brassards en cuir craquelé
2125	Gants en cuir craquelé
2126	Pantalon en cuir craquelé
2127	Gilet en cuir craquelé
2128	Claymore éraflée
2129	Grand bouclier rond
2130	Gourdin
2131	Epée courte
2132	Bâton court
2133	Petit bouclier
2134	Hache courte
2136	Eau purifiée invoquée
2137	Couteau tailladant
2138	Dague aiguisée
2139	Miséricorde
2140	Couteau trancheur
2141	Gilet en cuir bouilli
2142	Ceinture en cuir bouilli
2143	Bottes en cuir bouilli
2144	Brassards en cuir bouilli
2145	Gants en cuir bouilli
2146	Pantalon en cuir bouilli
2148	Ceinture en écailles polies
2149	Bottes en écailles polies
2150	Brassards en écailles polies
2151	Gants en écailles polies
2152	Jambières en écailles polies
2153	Broigne polie
2154	L'histoire de Morgan Ladimore
2156	Bottes matelassées
2158	Gants matelassés
2159	Pantalon matelassé
2160	Gambison
2161	Livre de la ferme de Sven
2162	Anneau de Sarah
2163	Lame des ténèbres
2164	Déchiqueteuse
2165	Couverture de la Vieille Blanchy
2166	Jambières de contremaître
2167	Gants de contremaître
2168	Bottes de contremaître
2169	Lame sifflante
2172	Ceinture rustique
2173	Vieille ceinture en cuir
2175	Hache de guerre sombrepoil
2186	Ceinture de tailleur
2187	Un tas de lettres
2188	Une lettre pour Grelin Whitebeard
2194	Marteau diamant
2195	Couteau d'Anvilmar
2203	Tranchoir de Brashclaw
2204	Broche de Brashclaw
2205	Crépusculaire
2207	Jambiya
2208	Poignard
2209	Kris
2210	Targe endommagée
2211	Grand bouclier endommagé
2212	Targe craquelée
2213	Grand bouclier usé
2214	Targe en bois
2215	Bouclier en bois
2216	Targe simple
2217	Bouclier rectangulaire
2218	Dague d'artisan
2219	Petit bouclier rond
2220	Bouclier carré
2221	Petite targe
2222	Pavois
2223	Plan de route du Collecteur
2224	Dague de la milice
2225	Couteau de cuisine
2226	Bâton des ogres-mages
2227	Grande hache de guerre ogre
2230	Gants de musculation
2231	Robe d'Inferno
2232	Bottes de Coureur sombre
2233	Jambières de Tisseur d'ombre
2234	Armure de marcheur nocturne
2235	Griffe de Brack
2236	Dard noir
2237	Pantalon raccommodé
2238	Pantalon de gavroche
2239	Anneau du Collecteur
2240	Cape robuste
2241	Cape de desperado
2243	Main d'Edward l'étrange
2244	Lame Krol
2245	Heaume de Narv
2246	Insigne de myrmidon
2249	Targe de la milice
2250	Gâteaux au crabe brun
2251	Patte d'araignée fondante
2252	Diverses fournitures gobelines
2254	Marteau Icepane
2256	Gourdin squelettique
2257	Bâton frostmane
2258	Epée courte frostmane
2259	Gourdin frostmane
2260	Hachette frostmane
2262	Marque de Kern
2263	Phytolame
2264	Mantelet des voleurs
2265	Hache brisepierre
2266	Dague brisepierre
2267	Masse brisepierre
2268	Lame brisepierre
2271	Bâton béni du Prophète
2273	Armure de guérillero
2274	Gants de sapeur
2276	Bottes des marais
2277	Pantalon des Nécromanciens
2278	Epaulettes de pisteur sylvestre
2280	Cane de Kam
2281	Hache Rodentia
2282	Epée courte Rodentia
2283	Ceinture en poil de rat
2284	Cape en poil de rat
2287	Cuissot
2288	Eau fraîche invoquée
2289	Parchemin de Force II
2290	Parchemin d'Intelligence II
2291	Kang le décapiteur
2292	Robe de nécrologue
2295	Grande défense de sanglier
2296	Groin de grand Broche-tripes
2299	Hache de guerre ardente
2300	Gilet en cuir estampé
2302	Bottes en cuir cousu main
2303	Pantalon en cuir cousu main
2304	Renfort d'armure léger
2307	Bottes élégantes en cuir
2308	Cape élégante en cuir
2309	Bottes en cuir estampé
2310	Cape en cuir estampé
2311	Pourpoint blanc en cuir
2312	Gants élégants en cuir
2313	Renfort d'armure moyen
2314	Armure en cuir raffermi
2315	Bottes noires en cuir
2316	Cape noire en cuir
2317	Tunique noire en cuir
2318	Cuir léger
2319	Cuir moyen
2320	Bobine de fil grossier
2321	Bobine de fil raffiné
2324	Décolorant
2325	Teinture noire
2326	Brassards de tisse-lierre
2327	Brassards solides en cuir
2361	Marteau détérioré
2362	Vieux bouclier en bois
2364	Gilet tissé
2366	Pantalon tissé
2367	Bottes tissées
2369	Gants tissés
2370	Harnais endommagé en cuir
2371	Ceinture endommagée en cuir
2372	Pantalon endommagé en cuir
2373	Bottes endommagées en cuir
2374	Brassards endommagés en cuir
2375	Gants endommagés en cuir
2376	Vieil écu
2377	Targe ronde
2378	Doigt de squelette
2379	Lorica ternie
2380	Ceinture en anneaux ternis
2381	Jambières en anneaux ternis
2382	Coeur de l'Embaumeur
2383	Bottes en anneaux ternis
2384	Brassards en anneaux ternis
2385	Gants en anneaux ternis
2386	Lorica rouillée
2387	Ceinture en anneaux rouillés
2388	Jambières en anneaux rouillés
2389	Bottes en anneaux rouillés
2390	Brassards en anneaux rouillés
2391	Gants en anneaux rouillés
2392	Cotte de mailles légère
2393	Ceinture en mailles légères
2394	Jambières en mailles légères
2395	Bottes en mailles légères
2396	Brassards en mailles légères
2397	Gants en mailles légères
2398	Cotte d'anneaux légère
2399	Ceinture en anneaux légers
2400	Jambières en anneaux légers
2401	Bottes en anneaux légers
2402	Brassards en anneaux légers
2403	Gants en anneaux légers
2406	Patron : Bottes élégantes en cuir
2407	Patron : Pourpoint blanc en cuir
2408	Patron : Gants élégants en cuir
2409	Patron : Tunique noire en cuir
2410	Torche fumante
2411	Bride d'étalon noir
2413	Palomino
2414	Bride de pinto
2415	Etalon blanc
2417	Lorica doublée
2418	Jambières en anneaux doublés
2419	Ceinture en anneaux doublés
2420	Bottes en anneaux doublés
2421	Brassards en anneaux doublés
2422	Gants en anneaux doublés
2423	Brigandine
2424	Ceinture brigandine
2425	Jambières brigandines
2426	Bottes brigandines
2427	Brassards brigandines
2428	Gants brigandines
2429	Gilet brun-roux
2431	Pantalon brun-roux
2432	Bottes brun-roux
2434	Gants brun-roux
2435	Gilet brodé
2437	Pantalon brodé
2438	Bottes brodées
2440	Gants brodés
2441	Targe annelée
2442	Targe renforcée
2443	Targe en métal
2444	Targe ornée
2445	Grand bouclier en métal
2446	Grand pavois
2447	Pacifique
2448	Pavois lourd
2449	Terrestrine
2450	Eglantine
2451	Ecu noble
2452	Chardonnier
2453	Doulourante
2454	Elixir de force du lion
2455	Potion de mana mineure
2456	Potion de régénération mineure
2457	Elixir d'Agilité mineure
2458	Elixir de Robustesse mineure
2459	Potion de rapidité
2460	Elixir of Tongues (NYI)
2463	Doublet en cuir clouté
2464	Ceinture en cuir clouté
2465	Pantalon en cuir clouté
2466	Fétiche Skullsplitter
2467	Bottes en cuir clouté
2468	Brassards en cuir clouté
2469	Gants en cuir clouté
2470	Gilet en cuir renforcé
2471	Ceinture en cuir renforcé
2472	Pantalon en cuir renforcé
2473	Bottes en cuir renforcé
2474	Brassards en cuir renforcé
2475	Gants en cuir renforcé
2476	Cuissot de basilic glacé
2477	Crâne de ravageur
2479	Hache large
2480	Grand gourdin
2481	Epée de péon
2482	Tomahawk inférieur
2483	Hache large grossière
2484	Petit couteau
2485	Gourdin fendu
2486	Grande masse en pierre
2487	Bâton d'acolyte
2488	Glaive
2489	Epée à deux mains
2490	Tomahawk
2491	Hache lourde
2492	Trique
2493	Maillet en bois
2494	Stylet
2495	Bâton de marche
2496	Epée courte d'écumeur
2497	Claymore rouillée
2498	Petit tomahawk
2499	Hache double
2500	Marteau léger
2501	Marteau de guerre en bois
2502	Dague éraflée
2503	Bâton court d'adepte
2504	Vieil arc court
2505	Arc court poli
2506	Arc courbe en bois de corne
2507	Arc courbe composite
2508	Vieux tromblon
2509	Tromblon orné
2510	Tromblon solide
2511	Espingole de chasseur
2512	Flèche grossière
2515	Flèche pointue
2516	Balle légère
2519	Balle lourde
2520	Epée large
2521	Flamberge
2522	Croissant
2523	Bullova
2524	Matraque
2525	Marteau de guerre
2526	Main gauche
2527	Bâton de combat
2528	Falchion
2529	Zweihander
2530	Francisque
2531	Grande hache
2532	Etoile du matin
2533	Maillet de guerre
2534	Rondache
2535	Bâton de guerre
2536	Dent de pierre de trogg
2545	Jambières en mailles de l'apprenti
2546	Ceinturon royal Frostmane
2547	Gants d'éleveur de sangliers
2548	Tonneau de Barleybrew Scalder
2549	Bâton des ombres
2553	Recette : Elixir d'Agilité mineure
2555	Recette : Potion de Rapidité
2556	Recette : Elixir des Langages
2560	Journal complet de la Tremblotte
2561	Tête de Chok'sul
2562	Bouquet de bégonias écarlates
2563	Poudre à l'odeur étrange
2564	Griffes de l'esprit elfique
2565	Bâtonnet de feu ardent
2566	Robe sacrificielle
2567	Lame de l'Evocateur
2568	Gilet marron en lin
2569	Bottes en lin
2570	Cape en lin
2571	Chausses de Viny
2572	Robe rouge en lin
2575	Chemise rouge en lin
2576	Chemise blanche en lin
2577	Chemise bleue en lin
2578	Gilet barbare en lin
2579	Chemise verte en lin
2580	Cape en lin renforcé
2581	Bandage épais en lin
2582	Gilet vert en laine
2583	Bottes en laine
2584	Cape en laine
2585	Robe grise en laine
2586	Robe de maître de jeu
2587	Chemise grise en laine
2589	Etoffe de lin
2590	Toile d'araignée des bois
2591	Etoffe trogg sale
2592	Etoffe de laine
2593	Flacon de Tawny de Hurlevent
2594	Cruche d’hydromiel nain
2595	Bidon de bourbon des terres Ingrates
2596	Outre de bière naine
2598	Patron : Robe rouge en lin
2601	Patron : Robe grise en laine
2604	Teinture rouge
2605	Teinture verte
2606	Venin de rôdeuse
2607	Cristal Mo'grosh
2608	Ambre gris de battrodon
2609	Colloïde de désamorçage
2610	Mixture de désamorçage
2611	Silex brut
2612	Robe sobre
2613	Robe à double couture
2614	Robe d'apprentissage
2615	Robe chromatique
2616	Robe chatoyante en soie
2617	Robe ardente
2618	Robe argentée
2619	Rapport de Grelin
2620	Voile des augures
2621	Capuche de nécromancie
2622	Coiffure tribale de Nimar
2623	Diadème sacré
2624	Coiffe de réflexion
2625	Statuette de Menethil
2628	Rapport de Senir
2629	Clé du coffre de l'Intrépide
2632	Dague courbe
2633	Remède tropical
2634	Extraits de fougère vénéneuse
2635	Ceinture en anneaux distendus
2636	Idole de pierre sculptée
2637	Rapport d'état d'Ironband
2639	Lettre de Merrin
2640	Equipement de mineur
2642	Bottes en anneaux distendus
2643	Brassards en anneaux distendus
2644	Cape en anneaux distendus
2645	Gants en anneaux distendus
2646	Pantalon en anneaux distendus
2648	Lorica distendue
2649	Ceinture en anneaux fins
2650	Bottes en anneaux fins
2651	Brassards en anneaux fins
2652	Cape en anneaux fins
2653	Gants en anneaux fins
2654	Pantalon en anneaux fins
2656	Lorica fine
2657	Sac en cuir rouge
2658	Fragment Ados
2659	Fragment Modr
2660	Fragment Golm
2661	Fragment Neru
2662	Carquois de Ribbly
2663	Cartouchière de Ribbly
2664	Croc de tisseuse
2665	Herbes aromatiques de Stormwind
2666	Tonneau de Thunder Ale
2667	Viande séchée de MacGrann
2668	Croc de battrodon
2669	Griffe de battrodon
2671	Peau de wendigo
2672	Viande de loup maigre
2673	Viande de coyote
2674	Chair de clampant
2675	Pince de clampant
2676	Chatoyante
2677	Côtes de sanglier
2678	Epices douces
2679	Viande de loup grillée
2680	Viande de loup épicée
2681	Viande de sanglier rôtie
2682	Pince de crabe farcie
2683	Beignet de crabe
2684	Steak de coyote
2685	Côtes de porc aux herbes
2686	Thunder Ale
2687	Côtes de porc séchées
2688	Noisette
2690	Ceinture à loquet
2691	Bottes de tailleur
2692	Epices fortes
2694	Jambières de colon
2696	Tonneau d'Evershine
2697	Recette : Tourte au foie de Broche-tripes
2698	Recette : Pince de crabe farcie
2699	Recette : Goulash des Carmines
2700	Recette : Côtes de porc aux herbes
2701	Recette : Kébab de loup assaisonné
2702	Lingot de sancteforge
2712	Caisse de lingots de sancteforge
2713	Tête du vieux Noiraud
2719	Petite clé en cuivre
2720	Note maculée de boue
2721	Voile sacré
2722	Bon pour du vin
2723	Bouteille de Dalaran noir
2724	Demande de tissu
2725	Les vertes collines de Strangleronce - Page 1
2728	Les vertes collines de Strangleronce - Page 4
2730	Les vertes collines de Strangleronce - Page 6
2732	Les vertes collines de Strangleronce - Page 8
2734	Les vertes collines de Strangleronce - Page 10
2735	Les vertes collines de Strangleronce - Page 11
2738	Les vertes collines de Strangleronce - Page 14
2740	Les vertes collines de Strangleronce - Page 16
2742	Les vertes collines de Strangleronce - Page 18
2744	Les vertes collines de Strangleronce - Page 20
2745	Les vertes collines de Strangleronce - Page 21
2748	Les vertes collines de Strangleronce - Page 24
2749	Les vertes collines de Strangleronce - Page 25
2750	Les vertes collines de Strangleronce - Page 26
2751	Les vertes collines de Strangleronce - Page 27
2754	Bâtarde ternie
2755	Les vertes collines de Strangleronce
2756	Les vertes collines de Strangleronce - Chapitre I
2757	Les vertes collines de Strangleronce - Chapitre II
2758	Les vertes collines de Strangleronce - Chapitre III
2759	Les vertes collines de Strangleronce - Chapitre IV
2760	Trousse de couture de Thurman
2763	Couteau de pêcheur
2764	Petite dague
2765	Couteau de chasse
2766	Stylet rapide
2770	Minerai de cuivre
2771	Minerai d'étain
2772	Minerai de fer
2773	Arc court craquelé
2774	Tromblon couvert de rouille
2775	Minerai d'argent
2776	Minerai d'or
2777	Arc court médiocre
2778	Tromblon bon marché
2779	Larme de Tilloa
2780	Arc de chasse léger
2781	Tromblon sale
2782	Arc courbe mal traité
2783	Tromblon de mauvaise qualité
2784	Racine de Musquash
2785	Arc à double courbure rigide
2786	Tromblon huilé
2787	Dague trogg
2788	Bière brune de la Griffe noire
2794	Un vieux livre d'histoire
2795	Livre : Les tensions du fer
2797	Coeur de Mokk
2798	Minerai de rethban
2799	Croc de gorille
2800	Robe noire en velours
2801	Lame d'Hanna
2802	Emblème flamboyant
2805	Cape en fourrure de yéti
2806	Paquet pour Stormpike
2807	Guillotine
2808	Torche des Flammes
2815	Fendoir courbe
2816	Sceptre de nécrorateur
2817	Tunique en cuir souple
2818	Pantalon en cuir étiré
2819	Dague croisée
2820	Chouette chronomètre
2821	Ecraseur Mo'grosh
2822	Cure-dent Mo'Grosh
2823	Ouvre-boîte Mo'grosh
2824	Ouragan
2825	Arc de Flèche de feu
2828	Cadavre de Nissa
2829	Cadavre de Gregor
2830	Cadavre de Thurman
2831	Cadavre de Devlin
2832	Recette du Ragoût de la marche de l'Ouest, par Verna
2833	Le Grimoire de la Liche
2834	Ichor d'embaumement
2835	Pierre brute
2836	Pierre grossière
2837	Lettre de Thurman
2838	Pierre lourde
2839	Une lettre pour Yvette
2840	Barre de cuivre
2841	Barre de bronze
2842	Barre d'argent
2843	Articulation sale
2844	Masse en cuivre
2845	Hache en cuivre
2846	Potiron de Tirisfal
2847	Epée courte en cuivre
2848	Masse en bronze
2849	Hache en bronze
2850	Epée courte en bronze
2851	Ceinture en anneaux de cuivre
2852	Pantalon en anneaux de cuivre
2853	Brassards en cuivre
2854	Brassards runiques en cuivre
2855	Griffe putride
2856	Clou en fer
2857	Ceinture runique en cuivre
2858	Sang de sombredogue
2859	Ecaille d'Aileron noir
2862	Pierre à aiguiser brute
2863	Pierre à aiguiser grossière
2864	Cuirasse runique en cuivre
2865	Jambières grossières en bronze
2866	Cuirasse grossière en bronze
2867	Brassards grossiers en bronze
2868	Brassards guillochés en bronze
2869	Cuirasse en bronze argenté
2870	Cuirasse en argent lumineux
2871	Pierre à aiguiser lourde
2872	Venin de Tisse-nuit vicieuse
2874	Une lettre qui n'a pas été envoyée.
2875	Anneau de la Croisade écarlate
2876	Peau de chauve-souris du crépuscule
2877	Claymore des combattants
2878	Hache d'os dentée
2879	Bâtonnet des antipodes
2880	Catalyseur léger
2881	Plans : Cuirasse runique en cuivre
2882	Plans : Epaulières en bronze argenté
2883	Plans : Poignard mortel en bronze
2885	Documents de la Croisade écarlate
2886	Côtes de sanglier des rochers
2887	Peau de loup déchirée
2888	Côtes de sanglier à la bière
2889	Recette : Côtes de sanglier à la bière
2890	Peau de sanglier déchirée
2891	Lettre pour l'architecte de la ville
2892	Poison mortel
2893	Poison mortel II
2894	Bière au malt Rhapsody
2895	Douleur progressive
2896	Angoisse progressive
2898	Plastron de montagnard
2899	Collier de wendigo
2900	Targe en pierre
2901	Pioche de mineur
2902	Cape de la foi
2903	Arc de chasse de Daryl
2904	Carabine de chasse de Daryl
2905	Cape en peau de chèvre
2906	Jambières en mailles de Darkshire
2907	Hache de bûcheron naine
2908	Aiguillon
2909	Foulard en laine rouge
2910	Bottes en or de la milice
2911	Ceinturon de Keller
2912	Griffe du Ténébromancien
2913	Mantelet de Gamn en soie
2915	Brise-glace de Taran
2916	Bouclier du lion d'or
2917	Anneau tranquille
2919	Relique des Anciens
2920	Relique sacrée
2921	Relique bénie
2922	Relique spirituelle
2923	Relique de Droiture
2924	Viande de crocilisque
2925	Peau de crocilisque
2926	Tête de Bazil Thredd
2927	Tourment progressif
2928	Poudre de délabrement
2929	Poussière tombale
2930	Essence de douleur
2932	Sarment du tourment
2933	Sceau de Wrynn
2934	Lanières de cuir déchirées
2939	Larme de crocilisque
2940	Patte d'ours sanglante
2941	Fer de prisonnier
2942	Coup de poing en fer
2943	Oeil de Paleth
2944	Oeil maudit de Paleth
2946	Dague de lancer équilibrée
2947	Petit couteau de lancer
2949	Bottes des marins
2950	Bâtonnet glacial
2951	Anneau du sous-bois
2953	Cape de maître du guet
2954	Pantalon de veilleur
2955	Chapeau de second
2956	Rapport sur les défias
2957	Gilet de compagnon
2958	Pantalon de compagnon
2959	Bottes de compagnon
2960	Gants de compagnon
2961	Gilet en cuir brûlé
2962	Jambières en cuir brûlé
2963	Bottes en cuir brûlé
2964	Gants en cuir brûlé
2965	Tunique de guerrier
2966	Pantalon de guerrier
2967	Bottes de guerrier
2968	Gants de guerrier
2969	Gilet de lieur de sort
2970	Pantalon de lieur de sort
2971	Bottes de lieur de sort
2972	Gants de lieur de sort
2973	Tunique de chasse
2974	Pantalon de chasse
2975	Bottes de chasse
2976	Gants de chasse
2977	Armure de vétéran
2978	Jambières de vétéran
2979	Bottes de vétéran
2980	Gants de vétéran
2981	Robe de prophète
2982	Pantalon de prophète
2983	Bottes de prophète
2984	Gants de prophète
2985	Cuirasse en cuir gravé
2986	Pantalon en cuir gravé
2987	Bottes en cuir gravé
2988	Gants en cuir gravé
2989	Tunique brunie
2990	Jambières brunies
2991	Bottes brunies
2992	Gants brunis
2996	Rouleau d'étoffe en lin
2997	Rouleau d'étoffe de laine
2998	Une simple boussole
2999	Outils de Steelgrill
3000	Carapace de la mère des couvées
3002	Relique de la Corne de Justice
3003	Relique de l'Oeil
3004	Relique des morts
3005	Relique de la Vérité
3006	Fragment de relique sacrée
3008	Cape en fourrure de wendigo
3010	Sable fin
3011	Coiffure de plumes
3012	Parchemin d'Agilité
3013	Parchemin de Protection
3014	Hache détériorée
3016	Grimoire de Gunther
3017	Ordres de Sevren
3018	Peau de Lupos
3019	Robe aristocratique
3020	Coiffe endurcie
3021	Arc de forestier
3022	Chausses branchie-bleue
3023	Tromblon de gros calibre
3024	BKP 2700 "Massacreur"
3025	BKP 42 "Ultra"
3026	Arc renforcé
3027	Arc courbe lourd
3028	Arc long
3030	Flèche rasoir
3033	Balle dure
3035	Potiron arrosé
3036	Arc court lourd
3037	Arc courbe souple
3039	Arc court en frêne
3040	Escopette de chasseur
3041	Tromblon "Oeil du mage"
3042	BKP petit calibre "Moineau"
3045	Bottes en écailles brillantes
3047	Gants en écailles brillantes
3048	Jambières en écailles brillantes
3049	Cuirasse en écailles brillantes
3053	Plastron d'Humbert
3055	Plastron sylvestre en cuir
3056	Pantalon sylvestre en cuir
3057	Bottes sylvestres en cuir
3058	Gants sylvestres en cuir
3065	Bottes éclatantes
3066	Gants éclatants
3067	Pantalon éclatant
3069	Robe éclatante
3070	Cape d'enseigne
3071	Hachette découpante
3072	Robe fumante
3073	Pantalon fumant
3074	Gants fumants
3075	Oeil de flamme
3076	Bottes fumantes
3078	Perce-coeur naga
3079	Carabine de Skorn
3080	Bougie de signal
3081	Gemme du Néant
3082	Crâne de Dargol
3083	Rouage de rééquilibrage
3084	Engrenage gyromécanique
3085	Tonneau de Shimmer Stout
3086	Bidon de Shimmer Stout
3087	Chope de Shimmer Stout
3088	Livre de Récupération IV
3089	Tome de Choc de flammes
3090	Tome d'Eclair de givre
3091	Tome d'Intelligence des arcanes II
3092	Tome de Choc de flammes II
3093	Tome de Choc de flammes II
3094	Tome de Trait de feu II
3095	Tome de Trait de feu III
3096	Tome du Chute de plumes
3097	Tome d'Invocation d'eau II
3098	Tome de Lenteur
3099	Tome d'Armure de glace II
3100	Tome de Blizzard II
3101	Tome de Nova de givre III
3102	Tome d'Intelligence des arcanes III
3103	Marteau des Frigères
3107	Couteau de lancer perçant
3108	Couteau de lancer lourd
3110	Oreille de Rat des tunnels
3111	Hache de lancer grossière
3113	Codex de Mot sacré : Bouclier
3114	Codex de Mot de l’ombre : Désarroi
3115	Codex de Rénovation IV
3116	Codex de Mot sacré : Bouclier II
3117	Journal d'Hildelve
3118	Codex de Soins supérieurs
3119	Codex de Mot sacré : Bouclier V
3120	Codex de Châtiment sacré IV
3121	Codex de Lévitation
3122	Codex de Mot sacré : Bouclier III
3123	Codex de Mot sacré : Robustesse III
3124	Codex de Feu intérieur III
3125	Tablette de Totem du serpent II
3126	Tablette d'Horion II
3127	Tablette d'Horion III
3129	Tablette d'Eclair IV
3130	Tablette de Restauration IV
3131	Hache de lancer équilibrée
3132	Tablette d'Eclair de lave IV
3133	Tablette de Totem de mana
3134	Grimoire de Malédiction de Mannoroth
3135	Hache de lancer aiguisée
3137	Hache de lancer mortelle
3138	Grimoire de Trait de l’ombre IV
3139	Grimoire d'Armure démoniaque II
3140	Grimoire d'Ebullition II
3141	Grimoire de Drain de vie
3142	Grimoire de Malédiction de Sargeras
3143	Grimoire d'Esprit ardent
3144	Grimoire d'Esprit ardent II
3146	Grimoire d'Esprit ardent III
3151	Haubergeon de sapeur
3152	Gants de pilotage
3153	Cape tachée d'huile
3154	Hache de Thelsamar
3155	Remède d'Arugal
3156	Bracelet de Glouton
3157	Bracelet de Ténébreux
3158	Brassards en peau brûlée
3160	Targe doublée de fer
3161	Robe du gardien
3162	Côtes ébréchées
3163	Crâne noirci
3164	Coeur de worg décoloré
3165	Potion de Quinn
3166	Cotte d'anneaux Coeur-de-fer
3167	Poil d'araignée épais
3168	Ecaille ébréchée
3169	Dent d'ours abîmée
3170	Grand croc d'ours
3171	Défense de sanglier cassée
3172	Tripes de sanglier
3173	Viande d'ours
3174	Ichor d'araignée
3175	Peau de dragon déchirée
3176	Petite griffe
3177	Petit croc
3179	Ecaille de dragon craquelée
3180	Ecaille de raptor tacheté
3181	Viande partiellement digérée
3182	Soie d'araignée
3183	Griffe galeuse
3184	Dague crochet
3185	Bâton d'acrobatie
3186	Epée viking
3187	Kris sacrificiel
3188	Claymore des coraux
3189	Coupe-bois
3190	Frappeur
3191	Hache de guerre du croissant
3192	Bâtarde courte
3193	Maillet en chêne
3194	Malice noire
3195	Hache de bataille barbare
3196	Bâtarde aiguisée
3197	Claymore tranche-pierre
3198	Marteau ravageur
3199	Pourfendeuse de guerre
3200	Brassards en cuir brûlé
3201	Hache de guerre barbare
3202	Brassards sylvestres en cuir
3203	Masse triangle
3204	Brassards des bois profonds
3205	Brassards en cuir gravé
3206	Epée à deux mains des écuyers
3207	Brassards de chasse
3208	Masse ronde
3209	Ancienne épée de guerre
3210	Hache de guerre brutale
3211	Brassards brunis
3212	Brassards en écailles brillantes
3213	Brassards de vétéran
3214	Brassards de guerrier
3216	Robe d’hiver chaude
3217	Ceinture de contremaître
3218	Chaîne de Bois-du-Bûcher
3220	Boudin
3222	Dague vicieuse
3223	Sceptre frostmane
3224	Brassards bordés d'argent
3225	Couteau taché de sang
3227	Bâton Plaie-de-nuit
3228	Menottes forcées
3229	Echarpe en soie de Tarentule
3230	Brassards du loup noir
3231	Espauliers de coupe-gorge
3233	Sac en peau de gnoll
3234	Anneau de Deliah
3235	Anneau de dédain
3236	Ichor de Poil-putride
3237	Echantillon d'ichor
3238	Les découvertes de Johaan
3239	Caillou brut
3240	Caillou grossier
3241	Caillou lourd
3248	Lettre traduite de l'Embaumeur
3249	Conjured test Item
3250	Parchemin de Bethor
3251	Potion de Bethor
3252	Rapport du Traqueur noir
3253	Coeur de vieil ours
3254	Sang du Grouillement
3255	Journal de Berard
3256	Mousse de Furtif du lac
3257	Mousse de Rampant du lac
3258	Tumeur durcie
3259	Peau de chauve-souris déchirée
3260	Robe écarlate d'initié
3261	Cape entoilée
3262	Marteau en bois vermoulu
3263	Pantalon entoilé
3264	Aile de chauve-souris du crépuscule
3265	Patte de charognard
3266	Bracelets écarlates
3267	Epée courte des Réprouvés
3268	Dague des Réprouvés
3269	Maillet des Réprouvés
3270	Gilet en lin
3272	Jambières en peau de zombie
3273	Haubergeon robuste
3274	Bottes en lin
3275	Gants en lin
3276	Targe de Garde noir
3277	Bâton du Bourreau
3278	Epée qui produit un effet dégâts de zone
3279	Bottes de bataille en anneaux
3280	Brassards de bataille en anneaux
3281	Gants de bataille en anneaux
3282	Pantalon de bataille en anneaux
3283	Tunique de bataille en anneaux
3284	Bottes tribales
3285	Brassards tribaux
3286	Gants tribaux
3287	Pantalon tribal
3288	Gilet tribal
3289	Bottes ancestrales
3290	Gants ancestraux
3291	Lainages ancestraux
3292	Tunique ancestrale
3293	Fendoir du mort
3294	Gourdin du mort
3295	Lame du mort
3296	Dague du mort
3297	Gangremousse
3299	Canine cassée
3300	Patte de lapin
3301	Canine pointue
3302	Bottes des eaux stagnantes
3303	Brassards des eaux stagnantes
3304	Gantelets des eaux stagnantes
3305	Jambières des eaux stagnantes
3306	Broigne des eaux stagnantes
3307	Bottes barbares en tissu
3308	Gants barbares en tissu
3309	Pantalon barbare
3310	Gilet barbare en tissu
3311	Bottines de cérémonie en cuir
3312	Brassards de cérémonie en cuir
3313	Harnais de cérémonie en cuir
3314	Gants de cérémonie en cuir
3315	Jambières de cérémonie en cuir
3316	Tête d'Alaric
3317	Une tête qui parle
3318	Cadavre d'Alaric
3319	Sabre court
3320	Echarpe d'ossomancien
3321	Bottines en fourrure grise
3322	Cape légère
3323	Brassards fantomatiques
3324	Mantelet fantomatique
3325	Hache de guerre Aileron noir
3327	Bâton d'Oracle Aileron noir
3328	Robe toile d'araignée
3329	Planche cloutée
3330	Haubert de Dargol
3331	Cape de Melrache
3332	Bottes de Perrine
3334	Pelle de fermier
3335	Balai de fermier
3336	Perce-chair
3337	Etendard de guerre Dragonmaw
3339	Combustible nain
3340	Minerai d'incendicite
3341	Gantelets de force d'ogre
3342	Chemise du capitaine Sander
3343	Sac de butin du capitaine Sander
3344	Echarpe du capitaine Sander
3345	Chapeau de sorcier en soie
3347	Lot de peaux de crocilisques
3348	Peau de crocilisque géant
3349	Sac de Sidonie
3352	Sac couvert de vase
3353	Pendentif marqué de runes
3354	Pendentif de Dalaran
3355	Aciérite sauvage
3356	Sang-royal
3357	Vietérule
3358	Moustache de Khadgar
3360	Fémur de Balafré
3363	Ceinture râpée
3365	Brassards râpés
3369	Tombeline
3370	Ceinture en patchwork
3371	Fiole vide
3372	Fiole plombée
3373	Brassards en patchwork
3374	Ceinture en calicot
3375	Brassards en calicot
3376	Ceinture en canevas
3377	Brassards en canevas
3378	Ceinture en brocart
3379	Brassards en brocart
3380	Ceinture à couture croisée
3381	Brassards à couture croisée
3382	Potion de sang de troll faible
3383	Elixir de Sagesse
3384	Potion de résistance à la magie mineure
3385	Potion de mana inférieure
3386	Elixir de résistance au poison
3387	Potion d'invulnérabilité limitée
3388	Potion de sang de troll forte
3389	Elixir de Défense
3390	Elixir d'Agilité inférieur
3391	Elixir de Force d'ogre
3392	Casque annelé
3393	Recette : Potion de résistance à la magie mineure
3394	Recette : Elixir de résistance au poison
3395	Recette : Potion d'invulnérabilité limitée
3396	Recette : Elixir d'Agilité inférieur
3397	Peau de jeune crocilisque
3399	Serre de vautour
3400	Epée longue Lucine
3401	Ecaille de crocilisque grossière
3402	Touffe de fourrure douce
3403	Défense de sanglier en ivoire
3404	Aile de busard
3405	Talisman de la griffe du Corbeau
3406	Plume noire
3407	Saphir des cieux
3408	Rune de nidification
3409	Croc de Sabre-de-nuit
3411	Plume de Hibou Strigid
3412	Soie d'araignée Tissebois
3413	Perforatrice
3414	Sceptre de guerre
3415	Bâton du moine
3416	Cotte d'anneaux du Martyr
3417	Claymore d'onyx
3418	Gangrenoix
3419	Rose rouge
3420	Rose noire
3421	Fleurs sauvages simples
3422	Belles fleurs sauvages
3423	Bouquet de roses blanches
3424	Bouquet de roses noires
3425	Baguette tressée
3426	Chemise jaune soutenu
3427	Chemise noire d'apparat
3428	Chemise grise classique
3429	Ceinture du gardien
3430	Carabine de précision
3431	Cuir clouté d'os
3434	Sable de léthargie
3435	Brassards en peau de zombie
3437	Ceinture à boucle
3438	Ankh de Résurrection
3439	Bottes en peau de zombie
3440	Brise-os
3442	Echarpe d'apprenti
3443	Tomahawk de cérémonie
3444	Gilet de laboureur
3445	Couteau de cérémonie
3446	Bâton de sombrebois
3447	Bottes du marcheur des cryptes
3448	Racine de Senggin
3449	Châle mystique
3450	Bouclier de Faerleia
3451	Décoction de lueur nocturne
3452	Bâtonnet de céranium
3453	Brassards capitonnés
3454	Bottes de reconnaissance
3455	Epée courte de Traqueur noir
3456	Sifflet de chien
3457	Pantalon estampillé
3458	Gantelets en mailles robustes
3460	Boisson spéciale de Johaan
3461	Grande robe de l'adjudicateur
3462	Ecorcheuse
3463	Etoile d'argent
3464	Flèche à plumes
3465	Balle explosive
3466	Catalyseur puissant
3467	Clé en fer terne
3468	Les découvertes de Renferrel
3469	Bottes en anneaux de cuivre
3470	Silex à aiguiser brut
3471	Lorica en cuivre
3472	Gantelets runiques en cuivre
3473	Pantalon runique en cuivre
3474	Gantelets ornementés en cuivre
3475	Cape des flammes
3476	Langue d'ours gris
3477	Ichor de Rampant
3478	Silex à aiguiser grossier
3480	Epaulières grossières en bronze
3481	Epaulières en bronze argenté
3482	Bottes en bronze argenté
3483	Gantelets en bronze argenté
3484	Bottes en fer émeraude
3485	Gantelets en fer émeraude
3486	Silex à aiguiser lourd
3487	Lourde épée large en cuivre
3488	Hache de guerre en cuivre
3489	Hache de guerre lourde
3490	Poignard mortel en bronze
3491	Masse lourde en bronze
3492	Puissant marteau en fer
3493	Carnassier
3495	Elixir de souffrance
3496	Sang de lion des montagnes
3497	Elixir de douleur
3498	Collier de Taretha
3499	Clé en or bruni
3502	Fleurs de fangemufle
3505	Chevalière d'Alterac
3506	Poudre de fangemufle
3508	Brouet de fangemufle
3509	Ecaille de Daguéchine
3510	Oeil d'Aileron déchiré
3511	Cape de la milice du peuple
3514	Crâne de Mor'Ladim
3515	Bâton d'Ataeric
3516	Tête de Lescovar
3517	Tonneau de Shindigger
3518	Lettre décodée
3520	Baril infecté
3521	Lettre astucieusement codée
3522	Cuirasse d'elfe de la nuit noire
3523	Unused Black Night Elf Pants
3524	Unused Black Night Elf Boots
3525	Unused Black Night Elf Bracers
3526	Gants d'elfe de la nuit noirs
3527	Cuirasse d'elfe de la nuit blanche
3528	Cuirasse rouge en cuir C03
3529	Casque noir d'elfe de la nuit
3530	Bandage en laine
3531	Bandage épais en laine
3532	Unused Red Leather C03 Pants
3533	Bottes en cuir rouge C03
3534	Unused Red Leather C03 Gloves
3535	Brassards en cuir rouge C03
3536	Bandeau de chasseur de démon
3537	Cuirasse noire en cuir D02
3538	Cuirasse grise en cuir D02
3539	Unused Black Leather D02 Pants
3540	Unused Gray Leather D02 Pants
3541	Bottes noires en cuir D02
3542	Bottes en cuir gris D02
3543	Unused Black Leather D02 Gloves
3544	Unused Gray Leather D02 Gloves
3545	Brassards noirs en cuir D02
3546	Brassards en cuir gris D02
3547	Cuirasse blanche en cuir D03
3548	Unused White Leather D03 Pants
3549	Unused White Leather D03 Gloves
3550	Tête de Targ
3551	Tête de Fouilleboue
3552	Tête de Glommus
3553	Tête de Mug'thol
3554	Couronne de Volonté
3555	Robe de Solomon
3556	Chapeau de mage d’effroi
3558	Robe de gardien des tourbières
3559	Gantelets de veilleur
3560	Mantelet d'honneur
3561	Poncho de résistance
3562	Ceinture de justification
3563	Pantalon de marin
3564	Chargement de fer
3565	Gants tachés de bière
3566	Armure de la plaie des raptors
3567	Canne à pêche naine
3569	Robe de vicaire
3570	Pilon fracasseur
3571	Fléau des troggs
3572	Epée courte de Daryl
3573	Carquois de chasse
3574	Giberne de chasse
3575	Barre de fer
3576	Barre d'étain
3577	Barre d'or
3578	Pantalon de moissonneur
3581	Couteau-scie
3582	Cape résistante à l'acide
3583	Ceinture défraîchie
3585	Tunique camouflée
3586	Fendeuse
3587	Ceinture brodée
3588	Brassards brodés
3589	Ceinture en toile renforcée
3590	Brassards en toile renforcée
3591	Ceinture matelassée
3592	Brassards matelassés
3593	Ceinture brun-roux
3594	Brassards brun-roux
3595	Ceinture en étoffe rapiécée
3596	Brassards en étoffe rapiécés
3597	Ceinture en étoffe épaisse
3598	Brassards en étoffe épaisse
3599	Ceinture en étoffe légère
3600	Brassards en étoffe légère
3601	Missive du Syndicat
3602	Ceinture tricotée
3603	Brassards tricotés
3604	Besace des Veilleurs
3605	Carquois des Veilleurs
3606	Ceinture tissée
3607	Brassards tissés
3608	Plans : Puissant marteau en fer
3609	Plans : Lorica en cuivre
3610	Plans : Gantelets ornementés en cuivre
3611	Plans : Bottes en fer émeraude
3612	Plans : Gantelets en fer émeraude
3613	Mains de Valdred
3614	Patte de Couineur
3615	Tête de Kurzen
3616	Vue de l'esprit
3617	Pendentif des ombres
3618	Tête d'Enfourneur
3619	Tabatière de Snellig
3620	Cadavre de Lillith
3621	Tête d'Ivar
3622	Essence de Cinglenuit
3623	Tête de Thule
3625	Tête de Nek'rosh
3626	Tête du baron Vardus
3627	Croc de Vagash
3628	Main de Dextren Ward
3629	Chevalière des Mistmantle
3630	Tête de Targorr
3631	Défense de Fouailleventre
3632	Patte de Fangore
3633	Tête de Gath'Ilzogg
3634	Tête de Grimson
3635	Patte d'Oeil-de-ver
3636	Ecaille du Vieux Troubloeil
3637	Tête de VanCleef
3638	Serre de Grondecroc
3639	Oreille de Balgaras
3640	Tête de Deepfury
3641	Brassards de compagnon
3642	Brassards ancestraux
3643	Brassards de lieur de sort
3644	Brassards barbares en tissu
3645	Crispins de prophète
3647	Brassards éclatants
3648	Targe de guerrier
3649	Targe tribale
3650	Bouclier de guerre
3651	Bouclier de vétéran
3652	Targe de chasse
3653	Targe de cérémonie
3654	Bouclier des eaux stagnantes
3655	Bouclier bruni
3656	Bouclier en écailles brillantes
3657	Registre municipal d'Hillsbrad
3658	Tome retrouvé
3659	Livre de cuir usé
3660	Tomes d'Alterac
3661	Bâton simple
3662	Steak de crocilisque
3663	Soupe aux ailerons de murloc
3664	Gombo de crocilisque
3665	Omelette au goût étrange
3666	Tourte d'araignée fondante
3667	Viande de crocilisque tendre
3668	Contrat de l'assassin
3669	Bave gélatineuse
3670	Grand os visqueux
3671	Crâne pourrissant
3672	Tête de Nagaz
3673	Flèche brisée
3674	Botte décomposée
3675	Torche consumée
3676	Ichor visqueux
3678	Recette : Steak de crocilisque
3679	Recette : Boudin
3680	Recette : Soupe aux ailerons de murloc
3681	Recette : Gombo de crocilisque
3682	Recette : Omelette au goût étrange
3683	Recette : Tourte d'araignée fondante
3684	Tiare de Perenolde
3685	Oeuf de raptor
3688	Pierre de sang ovale
3689	Pierre de sang marbrée
3690	Eclat de pierre de sang
3691	Coeur de pierre de sang
3692	Crâne d'humain d'Hillsbrad
3693	Epée d'Humbert
3701	Recommandation portant le sceau de Darthalia
3702	Vésicule biliaire d'ours
3703	Bière de Southshore
3704	Clé rouillée en fer
3706	Parchemin ensorcelé
3707	Parchemin de Nagaz
3708	Bâtonnet d'Helcular
3710	Bâtonnet d'Helcular
3711	Journal de recherche de Belamoore
3712	Viande de tortue
3713	Epices apaisantes
3714	Rune gravée usée
3715	Brassards de liaison de terre
3716	Tête de murloc
3717	Sac de têtes de murloc
3718	Documents d'annonce d'attaque
3719	Cape d'homme des collines
3720	Fourrure de yéti
3721	Rapport de Farren
3722	Peau de quasit
3723	Croc de quasit
3724	Griffe de quasit
3725	Corne de quasit
3726	Steak de grand ours
3727	Côtelettes de lion épicées
3728	Délicieux steak de lion
3729	Bisque de tortue apaisante
3730	Viande de grand ours
3731	Viande de lion
3732	Capuche simple
3733	Cotte d'anneaux de guerre orque
3734	Recette : Steak de grand ours
3735	Recette : Côtelettes de lion épicées
3736	Recette : Délicieux steak de lion
3737	Recette : Bisque de tortue apaisante
3738	Bâtonnet de brasseur
3739	Anneau du crâne
3740	Tranche-tête
3741	Bottes écrasantes
3742	Arc des pilleurs
3743	Targe de factionnaire
3744	Pendentif de pierre de sang
3745	Rune d'ouverture
3747	Echarpe de méditation
3748	Mantelet félin
3749	Cape de grand apothicaire
3750	Cuirasse côtelée
3751	Jambières des mercenaires
3752	Gilet de grunt
3753	Ceinturon de berger
3754	Gants de berger
3755	Eviscératrice
3758	Ceinture du Croisé
3759	Gants vitaux des sages
3760	Anneau d'Undercity
3761	Bouclier Tête de mort
3762	Ceinture du Bibliothécaire
3763	Targe lunaire
3764	Bottes Mantis
3765	Epauliers de brigand
3766	Plume de gryphon
3767	Fin parchemin
3769	Baguette brisée
3770	Côtelette de mouton
3771	Jarret de cochon sauvage
3772	Eau de source invoquée
3775	Poison affaiblissant
3776	Poison affaiblissant II
3777	Poudre léthargique
3778	Arc composite de sarcasme
3779	Hache de guerre impitoyable
3780	Mousquet à canon long
3781	Claymore large
3782	Grand gourdin de guerre
3783	Cimeterre léger
3784	Bâton en métal
3785	Hache funèbre
3786	Miséricorde rutilante
3787	Gourdin en pierre
3788	Relique du Cristal d'âme
3789	Relique de la Pierre de piété
3790	Parchemin relique consacré
3791	Relique de la Lumière
3792	Ceinture entrelacée
3793	Bottes entrelacées
3794	Brassards entrelacés
3795	Cape entrelacée
3796	Gants entrelacés
3797	Pantalon entrelacé
3798	Protège-épaules entrelacées
3799	Gilet entrelacé
3800	Ceinture en cuir durci
3801	Bottes en cuir durci
3802	Brassards en cuir durci
3803	Cape en cuir durci
3804	Gants en cuir durci
3805	Pantalon en cuir durci
3806	Protège-épaules en cuir durci
3807	Tunique en cuir durci
3808	Ceinture doublentine
3809	Bottes doublentines
3810	Brassards doublentins
3811	Cape à double couture
3812	Gants doublentins
3813	Pantalon doublentin
3814	Protège-épaules doublentins
3815	Haubergeon doublentin
3816	Ecu réfléchissant
3817	Targe renforcée
3818	Pâlerette
3819	Hivernale
3820	Etouffante
3821	Dorépine
3822	Noirâtre runique
3823	Potion d'Invisibilité inférieure
3824	Huile des ténèbres
3825	Elixir de Robustesse
3826	Potion de sang de troll hargneux
3827	Potion de mana
3828	Elixir de Détection d'Invisibilité inférieure
3829	Huile glaciale
3830	Recette : Elixir de Robustesse
3831	Recette : Potion de sang de troll hargneux
3832	Recette : Elixir de Détection d'Invisibilité inférieure
3833	Cape d'adepte
3834	Solide pantalon en toile
3835	Brassards en fer émeraude
3836	Heaume en fer émeraude
3837	Camail en écailles dorées
3838	Griffe d'Ombregueule
3839	Croc de tigresse en parfait état
3840	Epaulières en fer émeraude
3841	Epaulières en écailles dorées
3842	Jambières en fer émeraude
3843	Jambières en écailles dorées
3844	Haubert en fer émeraude
3845	Cuirasse en écailles dorées
3846	Bottes en acier poli
3847	Bottes en écailles dorées
3848	Grand couteau en bronze
3849	Epée courte en fer trempé
3850	Serpentine de jade
3851	Solide maillet en fer
3852	Destructeur en fer doré
3853	Epée d'acier lunaire
3854	Tigresse glaciale
3855	Gigantesque hache en fer
3856	Croissant des ombres
3857	Charbon
3858	Minerai de mithril
3859	Barre d'acier
3860	Barre de mithril
3861	Barre de noiracier
3862	Tendon d'ancien gorille
3863	Plume de Traqueur de la jungle
3864	Citrine
3866	Plans : Serpentine de jade
3867	Plans : Destructeur en fer doré
3868	Plans : Tigresse glaciale
3869	Plans : Croissant des ombres
3870	Plans : Epaulières en fer émeraude
3871	Plans : Epaulières en écailles dorées
3872	Plans : Jambières en écailles dorées
3873	Plans : Cuirasse en écailles dorées
3874	Plans : Bottes en acier poli
3875	Plans : Bottes en écailles dorées
3876	Croc de Bhag'thera
3877	Serre de Téthis
3879	Patte de Sin'Dall
3880	Tête de Bangalash
3882	Plume de busard
3889	Chapeau brun-roux
3890	Chapeau en cuir clouté
3891	Casque en anneaux doublés
3892	Chapeau brodé
3893	Coiffe en cuir renforcé
3894	Casque brigandine
3897	Oeil de Dizzy
3898	Titre du Bibliothécaire
3899	Légendes des Gurubashi, Volume 3
3900	Porto Pupellyverbos
3901	Défense de Bloodscalp
3902	Bâton aristocratique
3904	Tête de Gan'zulah
3905	Tête de Nezzliok
3906	Trophée Balia'mah
3907	Trophée Ziata'jai
3908	Trophée Zul'Mamwe
3909	Armure brisée d'Ana'thek
3910	Tabac à priser
3911	Eclat bleu vibrant
3912	Gemme d'âme
3913	Gemme d'âme capturée
3914	Sac à dos de compagnon
3915	Collier d'os sanglant
3916	Collier d'os brisés
3917	Cristal bleu chantant
3918	Eclat de cristal chantant
3919	Abats de Valbrume
3920	Cartes de la Voile sanglante
3921	Ordres de la Voile sanglante
3922	Paiement de Philippe le Chancelant
3923	Bracelets d'élémentaire d'eau
3924	Fléau de Maury
3925	Longue-vue dorée de Jon-Jon
3926	Grand anneau de Chucky
3927	Cheddar affiné
3928	Potion de soins excellente
3929	Butin de Maury
3930	Clé de Maury
3931	Croc d'araignée empoisonné
3932	Coffre de Smotts
3935	Coutelas de Smotts
3936	Ceinture en crochet
3937	Bottes en crochet
3938	Brassards en crochet
3939	Cape en crochet
3940	Gants en crochet
3941	Pantalon en crochet
3942	Protège-épaules en crochet
3943	Gilet en crochet
3944	Ceinture sergée
3945	Bottes sergées
3946	Brassards sergés
3947	Cape sergée
3948	Gants sergés
3949	Pantalon sergé
3950	Protège-épaules sergés
3951	Gilet sergé
3952	Ceinture maillée
3953	Bottes maillées
3954	Brassards maillés
3955	Cape maillée
3956	Gants maillés
3957	Pantalon maillé
3958	Mantelet maillé
3959	Armure maillée
3960	Sac de bracelets d'élémentaire d'eau
3961	Ceinture en cuir épais
3962	Bottes en cuir épais
3963	Brassards en cuir épais
3964	Cape épaisse
3965	Gants en cuir épais
3966	Pantalon en cuir épais
3967	Protège-épaules en cuir épais
3968	Tunique en cuir épais
3969	Ceinture en cuir lisse
3970	Bottes en cuir lisse
3971	Brassards en cuir lisse
3972	Cape lisse
3973	Gants en cuir lisse
3974	Pantalon en cuir lisse
3975	Protège-épaules en cuir lisse
3976	Armure en cuir lisse
3977	Ceinture en lanières de cuir
3978	Bottes en lanières de cuir
3979	Brassards en lanières de cuir
3980	Cape en lanières de cuir
3981	Gants en lanières de cuir
3982	Pantalon en lanières de cuir
3983	Protège-épaules en lanières de cuir
3984	Armure en lanières de cuir
3985	Echarpe à monogramme
3986	Pavois protecteur
3987	Pavois déflecteur
3988	Bouclier de plaques
3989	Targe de blocage
3990	Targe noble
3991	Targe doublée
3992	Ceinture en écailles laminées
3993	Bottes en écailles laminées
3994	Brassards en écailles laminées
3995	Cape en écailles laminées
3996	Gants en écailles laminées
3997	Pantalon en écailles laminées
3998	Protège-épaules en écailles laminées
3999	Broigne laminée
4000	Ceinture en anneaux doubliers
4001	Bottes en anneaux doubliers
4002	Brassards en anneaux doubliers
4003	Cape en anneaux doubliers
4004	Gants en anneaux doubliers
4005	Pantalon en anneaux doubliers
4006	Protège-épaules en anneaux doubliers
4007	Cotte en anneaux doubliers
4008	Ceinture en anneaux d'argent
4009	Bottes en anneaux d'argent
4010	Brassards en anneaux d'argent
4011	Cape en anneaux d'argent
4012	Gants en anneaux d'argent
4013	Pantalon en anneaux d'argent
4014	Protège-épaules en anneaux d'argent
4015	Cotte d'anneaux d'argent
4016	Mixture de Zanzil
4017	Epée courte tranchante
4018	Claymore affûtée
4019	Lourde hache en silex
4020	Hache de guerre brisante
4021	Masse fracassante
4022	Maillet fracassant
4023	Dague pointue
4024	Bâton de guerre lourd
4025	Arc long équilibré
4026	Mousquet de sentinelle
4027	Lame de Catelyn
4028	Tas de roseaux akiris
4029	Roseau akiris
4030	Relique sacrée de l'eau
4031	Relique du charme sacré
4032	Relique Marteau irradiant
4033	Halo de l'aube
4034	Pierre des Marées
4035	Robe brochée d'argent
4036	Crispins brochés d'argent
4037	Pantalon broché d'argent
4038	Robe nocturne
4039	Capuche nocturne
4040	Gants nocturnes
4041	Capuche de l'aurore
4042	Gants de l'aurore
4043	Brassards de l'aurore
4044	Pantalon de l'aurore
4045	Brassards de Longuebrume
4046	Pantalon de Longuebrume
4047	Bottes de Longuebrume
4048	Chapeau blasonné
4049	Brassards blasonnés
4050	Jambières blasonnées
4051	Bottes blasonnées
4052	Coiffe à insigne
4053	Grande peau de crocilisque des rivières
4054	Jambières à insigne
4055	Bottes à insigne
4056	Devinette de Cortello
4057	Corselet à insigne
4058	Cuirasse glyphée
4059	Brassards glyphés
4060	Jambières glyphés
4061	Brassards impériaux en cuir
4062	Pantalon impérial en cuir
4063	Gants impériaux en cuir
4064	Targe blasonnée
4065	Bouclier de combat
4066	Targe à insigne
4067	Targe glyphée
4068	Bouclier de général de brigade
4069	Targe forgenoire
4070	Ecu de jouteur
4071	Cuirasse en mailles rougeoyantes
4072	Gantelets en mailles rougeoyantes
4073	Jambières en mailles rougeoyantes
4074	Cotte de mailles de guerre
4075	Gantelets de guerre en mailles
4076	Bottes de guerre en mailles
4077	Protège-front de guerre en mailles
4078	Camail de général de brigade
4079	Jambières de général de brigade
4080	Camail forgenoire
4082	Cuirasse forgenoire
4083	Gantelets forgenoire
4084	Jambières forgenoire
4085	Cocotte ébréchée de Krazek
4086	Carabine foudroyante
4087	Arc de précision
4088	Lame d'effroi
4089	Tromblon ricochet
4090	Chope brise-crâne
4091	Dévoreuse
4092	Ecaille de basilic prismatique
4093	Grande queue de basilic
4094	Eclat de tablette
4096	Poil de gorille grossier
4097	Croc de gorille ébréché
4098	Une note soigneusement pliée
4099	Touffe de poils de gorille
4100	Note chiffonnée
4101	Note en morceaux
4102	Note déchirée
4103	Clé de chaîne
4104	Peau de Gueule d'acier
4105	Peau d'ancien crocilisque
4106	Cristal réduit
4107	Gants de chasseur de tigres
4108	Jambières du chasseur de panthères
4109	Bottes d'Excelsior
4110	Arc de maître-chasseur
4111	Carabine de maître-chasseur
4112	Collier du Grand chaman
4113	Couverture-médecine
4114	Cape de sombreflux
4115	Targe de Grom'gol
4116	Sabre Olmann
4117	Echarpe brûlante
4118	Anneau de nez de Poobah
4119	Tunique de chasseur de raptors
4120	Robe des eaux cristallines
4121	Gants ornementés
4122	Sceptre fracassant
4123	Espauliers en métal glacial
4124	Coiffe d'harmonie
4125	Orbe de tranquillité
4126	Fendoir de la guérilla
4127	Crache-mitraille
4128	Fatale
4129	Légendaire
4130	Boussole de Smotts
4131	Ceinture de corruption
4132	Brachiales darkspear
4133	Crispins darkspear
4134	Bâton mystique de Nimboya
4135	Anneau de pierre de sang
4136	Bottes darkspear
4137	Chaussures darkspear
4138	Tunique des Flots noirs
4139	Sandales du marcheur de la jungle
4140	Mantelet en feuille de palmier
4141	Tome d'Invocation de nourriture
4142	Tome de Métamorphose : Cochon
4143	Tome d'Invocation de nourriture II
4144	Tome de Métamorphose : Vache
4145	Tome d'Invocation de gemme de mana
4146	Tome de Métamorphose : Mouton
4147	Tome d'Invocation de nourriture III
4148	Tome de Contre-sort
4149	Tome de Bouclier de givre III
4150	Tome d'Invocation d'eau IV
4151	Tome d'Eclair de givre IV
4152	Tome d'Invocation de nourriture IV
4153	Tome de Projectiles des arcanes III
4154	Tome de Lenteur II
4155	Tome d'Elémentaire d'eau II
4157	Tome d'Atténuation de la magie
4158	Tome de Déverrouillage de Khadgar II
4159	Tome de Projectiles des arcanes
4160	Tome d'Invisibilité
4161	Tome de Boule de feu IV
4162	Tome de Transfert II
4164	Libram : Lumière sacrée V
4165	Libram : Lumière sacrée VI
4166	Libram : Sceau de protection
4167	Libram : Jugement
4168	Tablette de Totem d'enracinement
4169	Tablette de Volonté inflexible II
4170	Tablette de Rappel astral
4171	Tablette de Totem d'agitation III
4172	Tablette de Coup de tonnerre II
4173	Tablette d'Horion IV
4174	Tablette d'Horion V
4175	Tablette de Bouclier de foudre IV
4176	Tablette de Force permanente II
4177	Tablette de résistance à la Nature
4178	Tablette d'Eclair V
4179	Tablette de Restauration V
4180	Tablette de Forme éthérée II
4181	Tablette de Totem d'agitation IV
4182	Tablette de Volonté inflexible III
4183	Tablette de Totem de soins  V
4184	Tablette d'Eclair de lave V
4185	Tablette de Rappel astral (groupe)
4186	Tablette de résistance au Feu
4187	Tablette de Totem du serpent V
4188	Tablette de Totem d'invisibilité
4189	Tablette de Chaîne d'éclairs
4190	Armure de plumes
4194	Brassards de plumes
4195	Bottes de plumes
4196	Mantelet de plumes
4197	Ailettes de Berylline
4198	Grimoire de Captation d'âme
4199	Grimoire de Captation d'âme II
4200	Grimoire d'Immolation III
4201	Grimoire d'Oeil de Kilrogg
4202	Grimoire de Peur II
4203	Grimoire de Pestilence II
4204	Grimoire de Captation d'âme III
4205	Grimoire d'Immolation IV
4206	Grimoire de Malédiction de Sargeras II
4207	Grimoire de Malédiction d'Archimonde
4208	Grimoire d'Explosion mentale
4209	Grimoire de Gardien de l’ombre
4210	Grimoire de Création de pierre de sang inférieure
4211	Grimoire de Pestilence
4212	Grimoire de Malédiction de Mannoroth III
4213	Grimoire de Malédiction
4214	Grimoire de Drain de vie III
4215	Grimoire de Pluie de feu
4216	Grimoire de Gardien sacré
4217	Grimoire de Captation d'âme IV
4218	Grimoire de Création de pierre de sang
4219	Grimoire d'Esprit ardent IV
4220	Grimoire d'Ebullition III
4221	Grimoire de Détection de l'invisibilité
4223	Livre d'Abolir magie
4225	Livre de Sarments III
4226	Livre de Colère VI
4228	Livre d'Eclat lunaire IV
4230	Livre de Toucher guérisseur VI
4231	Peau légère traitée
4232	Peau moyenne
4233	Peau moyenne traitée
4234	Cuir lourd
4235	Peau lourde
4236	Peau lourde traitée
4237	Ceinture en cuir cousu main
4238	Sac en lin
4239	Gants en cuir estampé
4240	Sac en laine
4241	Sac vert en laine
4242	Pantalon en cuir estampé
4243	Tunique élégante en cuir
4244	Gilet d'homme des collines en cuir
4245	Petit sac en soie
4246	Ceinture élégante en cuir
4247	Gants d'homme des collines en cuir
4248	Gants noirs en cuir
4249	Ceinture noire en cuir
4250	Ceinture d'homme des collines
4251	Epaulières d'homme des collines
4252	Epaulières noires en cuir
4253	Gants en cuir raffermi
4254	Gants barbares
4255	Armure verte en cuir
4256	Armure de gardien
4257	Ceinture verte en cuir
4258	Ceinture de gardien
4259	Brassards verts en cuir
4260	Brassards de gardien en cuir
4261	Pantalon de Solliden
4262	Ceinture en cuir clouté de gemmes
4263	Bouclier militaire
4264	Ceinture barbare
4265	Renfort d'armure lourd
4266	Codex de Feu intérieur II
4267	Codex de Mot de l’ombre : Maladresse
4268	Codex de Soins II
4269	Codex de Prière de soins
4270	Codex de Soins III
4271	Codex de Châtiment sacré V
4272	Codex de Protection contre le Sacré
4273	Codex de soins
4274	Codex d'Esquive miraculeuse
4275	Codex de Dégénérescence mentale
4276	Codex de Mot de l’ombre : Maladresse II
4277	Codex de Mot de l’ombre : Désarroi II
4278	Minerai de pierre de sang inférieur
4279	Codex de Mot de l’ombre : Douleur V
4280	Codex de Mot sacré : Bouclier IV
4281	Codex de Protection contre l’ombre
4282	Codex de Dissiper magie II
4283	Codex de Sommeil III
4284	Codex de Châtiment sacré VI
4285	Codex de Mot sacré : Robustesse IV
4286	Codex de Prière de soins II
4287	Codex d'Annuler maladie II
4288	Codex de Délivrance de la malédiction II
4289	Sel
4290	Targe du brisquard
4291	Bobine de soie
4292	Patron : Sac vert en laine
4293	Patron : Gilet d'homme des collines en cuir
4294	Patron : Ceinture d'homme des collines
4296	Patron : Epaulières noires en cuir
4297	Patron : Gants barbare
4298	Patron : Ceinture du gardien
4299	Patron : Armure de gardien
4300	Patron : Brassards de gardien en cuir
4301	Patron : Ceinture barbare
4302	Petite dague verte
4303	Lobotomiseur
4304	Cuir épais
4305	Rouleau d'étoffe de soie
4306	Etoffe de soie
4307	Gants en lin épais
4308	Brassards verts en lin
4309	Culottes en lin cousu main
4310	Gants en laine épaisse
4311	Cape en laine épaisse
4312	Bottes en lin à semelle souple
4313	Bottes rouges en laine
4314	Epaulières à double couture en laine
4315	Epaulières renforcées en laine
4316	Pantalon en laine épaisse
4317	Pantalon du phénix
4318	Gants de méditation
4319	Gants azur en soie
4320	Bottes en soie d'araignée
4321	Mules en soie d'araignée
4322	Capuche d'enchanteur
4323	Chaperon des ombres
4324	Gilet azur en soie
4325	Bottes de l'enchanteur
4326	Longue cape en soie
4327	Cape glaciale
4328	Ceinture de l'araignée
4329	Ceinture de l'étoile
4330	Chemise rouge d'apparat
4331	Gants du phénix
4332	Chemise jaune éclatant
4333	Chemise noire en soie
4334	Chemise blanche habillée
4335	Riche chemise violette en soie
4336	Chemise noire de bretteur
4337	Soie d'araignée épaisse
4338	Etoffe de tisse-mage
4339	Rouleau de tisse-mage
4340	Teinture grise
4341	Teinture jaune
4342	Teinture pourpre
4343	Pantalon marron en lin
4344	Chemise marron en lin
4345	Patron : Bottes rouges en laine
4346	Patron : Cape en laine épaisse
4347	Patron : Epaulières renforcées en laine
4348	Patron : Gants du phénix
4349	Patron : Pantalon du phénix
4350	Patron : Mules en soie d'araignée
4351	Patron : Chaperon des ombres
4352	Patron : Bottes de l'enchanteur
4353	Patron : Ceinture de l'araignée
4354	Patron : Riche chemise violette en soie
4355	Patron : Cape glaciale
4356	Patron : Ceinture de l'étoile
4357	Poudre d'explosion basique
4358	Dynamite basique
4359	Poignée de boulons en cuivre
4360	Bombe grossière en cuivre
4361	Tube en cuivre
4362	Espingole grossière
4363	Modulateur en cuivre
4364	Poudre d'explosion grossière
4365	Dynamite grossière
4366	Leurre
4367	Petite charge d'hydroglycérine
4368	Lunettes de tigre volant
4369	Tromblon mortel
4370	Grande bombe en cuivre
4371	Tube en bronze
4372	Espingole amoureusement construite
4373	Lunettes des ombres
4374	Petite bombe en bronze
4375	Bidule bourdonnant en bronze
4376	Pare-flammes
4377	Poudre d'explosion majeure
4378	Dynamite puissante
4379	Fusil plaqué argent
4380	Grande bombe en bronze
4381	Recombobulateur mineur
4382	Structure en bronze
4383	Carabine vise-lune
4384	Mouton explosif
4385	Lunettes teintées vertes
4386	Pare-glace
4387	Contrefiche en fer
4388	Rayon discombobulateur
4389	Gyrochronatome
4390	Grenade en fer
4391	Kit de moissonneur compact
4392	Leurre perfectionné
4393	Monocle d'artisan
4394	Grande bombe en fer
4395	Mine gobeline
4396	Petit dragon mécanique
4397	Système d'occultation gnome
4398	Grande charge d'hydroglycérine
4399	Crosse en bois
4400	Crosse lourde
4401	Caisse d'Ecureuil mécanique
4402	Petit sac de flammes
4403	Mortier portable en bronze
4404	Contact en argent
4405	Lunette basique
4406	Lunette standard
4407	Lunette de précision
4408	Schéma : Ecureuil mécanique
4409	Schéma : Petite charge d'hydroglycérine
4410	Schéma : Lunettes des ombres
4411	Schéma : Pare-flammes
4412	Schéma : Carabine vise-lune
4413	Schéma : Rayon discombobulateur
4414	Schéma : Mortier portable en bronze
4415	Schéma : Monocle de l'artisan
4416	Schéma : Mine gobeline
4417	Schéma : Grande charge d'hydroglycérine
4419	Parchemin d'intelligence III
4421	Parchemin de Protection III
4422	Parchemin d'Endurance III
4424	Parchemin d'Esprit III
4425	Parchemin d'Agilité III
4426	Parchemin de force III
4428	Palpe d'araignée
4429	Ordres de Deepfury
4430	Talisman éthéré
4432	Lettre de Sully Balloo
4433	Enveloppe détrempée
4434	Pantalon d'épouvantail
4435	Poussières de Myzrael
4436	Echarpe incrustée de joyaux
4437	Bâton du canaliste
4438	Brassards du pugiliste
4439	Gourdin de contusions
4440	Glyphe de Strom
4441	Tord-boyaux de MacKreel
4443	Espauliers sinistres
4444	Bouclier de la défense noire
4445	Grave-chair
4446	Lame de venin noir
4447	Cape de nuit
4448	Carcasse de Naraxis
4449	Croc de Naraxis
4450	Fragment de glyphe
4453	Glyphe de Thoradin
4454	Serre de Vultros
4455	Harnais en peau de raptor
4456	Ceinture en peau de raptor
4457	Aile de busard grillée
4458	Glyphe d'Arathor
4459	Fragile os de dragon
4460	Palmure d'aile arrachée
4461	Peau de raptor
4462	Cape de pourrissement
4463	Collier bosselé de raptor
4464	Bottes de fracas
4465	Gantelets Poing-d'os
4466	Glyphe de Trollbane
4467	Glyphe d'Ignaeus
4468	Trol'kalar en fourreau
4469	Bâtonnet de l'ordre
4470	Bois simple
4471	Silex et amadou
4472	Parchemin de Myzrael
4473	Chaînes indicibles
4474	Arc de Ravenwood
4476	Robe du compagnon des bêtes
4477	Targe néfaste
4478	Jambières en écailles iridescentes
4479	Charme ardent
4480	Charme de tonnerre
4481	Charme armorié
4482	Documents scellés
4483	Clé ardente
4484	Clé armoriée
4485	Clé de tonnerre
4487	Cartes de la Folie de la Vierge
4488	Cartes de l'Esprit des Pins argentés
4489	Journal de la Folie de la Vierge
4490	Journal de l'Esprit des Pins argentés
4491	Lunettes de chasse aux gemmes
4492	Gemme elfique
4493	Gemmes elfiques
4494	Lettre scellée de Seahorn
4495	Amulette de pierre de sang
4496	Petite sacoche marron
4497	Sac lourd marron
4498	Sacoche marron en cuir
4499	Grand sac brun
4500	Sac à dos de voyageur
4502	Echantillon de gemme elfique
4503	Défense de Witherbark
4504	Cape de garde nain
4505	Pantalon des marécages
4506	Insigne de Stromgarde
4507	Bouclier du combattant des abîmes
4508	Armure souillée de sang
4509	Gants de loup de mer
4510	Orbe de pierre de sang souillé
4511	Marteau des Flots noirs
4512	Oeil de raptor des hautes-terres
4513	Coeur de raptor
4514	Requête de Sara Balloo
4515	Tête de Marez
4516	Tête d'Otto
4517	Tête de Falconcrest
4518	Fragment de parchemin déchiré
4519	Fragment de parchemin fripé
4520	Fragment de parchemin noirci
4521	Granit d'Alterac
4522	Bourse-médecine Witherbark
4524	Mémorial de Balloo
4525	Baguette d'invocation de Trelane
4526	Amulette de Griffe du raptor
4527	Agate azur
4528	Orbe de Tor'gan
4529	Agate enchantée
4530	Phylactère de Trelane
4531	Orbe de Trelane
4532	Agate de braise de Trelane
4533	Lettre scellée pour l'archimage Malin
4534	Brassards cerclés d'acier
4535	Anneau mémorial d'Ironforge
4536	Pomme rouge brillante
4537	Banane de Tel'Abim
4538	Pastèque claquevigne
4539	Pomme dorette
4540	Morceau de pain rassis
4541	Pain sorti du four
4542	Pain de maïs moelleux
4543	Coiffe en peau de drake blanc
4544	Pain épicé de Mulgore
4545	Brassards radieux en argent
4546	Appel du raptor
4547	Baguette gnome
4548	Marteau de guerre servomécanique
4549	Anneau de mer de feu
4550	Anneau de Coldwater
4551	Tête d'Or'Kalar
4552	Fragment de pierre lisse
4553	Morceau de pierre délabré
4554	Pierre polie brillante
4555	Epaisse queue écailleuse
4556	Fragment de carapace moucheté
4557	Glande de naphte
4558	Tonneau vide
4559	CHU's QUEST ITEM
4560	Cimeterre fin
4561	Tomahawk de scalp
4562	Hache mortelle
4563	Gourdin de Billy
4564	Gourdin clouté
4565	Dague simple
4566	Solide bâton de guerre
4567	Epée mercenaire
4568	Hache de grunt
4569	Marteau fidèle
4570	Maillet de bouleau
4571	Couteau de guerre
4575	Bâton d'homme-médecine
4576	Arc léger
4577	Fusil compact
4580	Croc de Dents de sabre
4581	Touffe de fourrure fine
4582	Queue fournie soyeuse
4583	Epaisse crinière
4584	Grande patte trophée
4585	Mandibule d'araignée visqueuse
4586	Peau lisse de raptor
4587	Plumes de raptor tribales
4588	Crâne de raptor en parfait état
4589	Longue plume élégante
4590	Bec jaune incurvé
4591	Oeil d'aigle
4592	Lutjan à longue mâchoire
4593	Poisson-chat moustachu
4594	Morue rochécaille
4595	Vin de Junglevine
4596	Potion de soins décolorée
4597	Recette : Potion de soins décolorée
4598	Canne à pêche gobeline
4599	Jambonneau traité
4600	Grog à la cerise
4601	Pain de banane doux
4602	Citrouille lunaire
4603	Jaune-queue tacheté cru
4604	Tête de champignon sylvestre
4605	Champignon à pois rouges
4606	Morilles spongieuses
4607	Délicieux humus des grottes
4608	Truffe noire brute
4609	Recette : Aile de busard grillée
4610	Urne de pierre gravée
4611	Perle bleue
4612	Coeur de drake noir
4613	Boîte noire corrodée
4614	Pendentif de Myzrael
4615	Liens de Cinglenoir
4616	Piolet porte-bonheur de Ryedol
4621	Bracelets de l'ambassadeur Infernus
4622	Note scellée au Conseiller Belgrum
4623	Potion de Bouclier de pierre inférieure
4624	Recette : Potion de Bouclier de pierre inférieure
4625	Fleur de feu
4626	Petit éclat de pierre
4627	Grand bloc de pierre
4628	Brassards de Liaison de pierre
4629	Caisse de fournitures
4630	Morceaux de métal
4631	Tablette de Ryun'eh
4632	Coffret orné en bronze
4633	Coffret lourd en bronze
4634	Coffret en fer
4635	Amulette de Hammertoe
4636	Solide coffret en fer
4637	Coffret d'acier
4638	Coffret d'acier renforcé
4639	Varech enchanté
4640	Signe de la Terre
4641	Main de Dagun
4643	Cape d'acier sinistre
4644	Le Coeur de l'héritage
4645	Entraves de Hematus
4646	Etoile de Xil'yeh
4647	Sommaire de Yagyin
4648	Glyphe du Marteau
4649	Note de Bonegrip
4650	Note de Bel'dugur
4652	Bouclier de Salbac
4653	Bottes en fer armé
4654	Mystérieux fossile
4655	Chair de palourde géante
4656	Petite citrouille
4658	Cape de guerrier
4659	Ceinturon de guerrier
4660	Bottes de marche
4661	Mantelet éclatant
4662	Cape de compagnon
4663	Ceinture de compagnon
4665	Cape brûlée
4666	Ceinture en cuir brûlé
4668	Cape de bataille en anneaux
4669	Ceinturon de bataille en anneaux
4671	Cape ancestrale
4672	Ceinture ancestrale
4674	Cape tribale
4675	Ceinture tribale
4676	Gantelets squelettiques
4677	Cape de vétéran
4678	Ceinturon de vétéran
4680	Cape des eaux stagnantes
4681	Ceinturon des eaux stagnantes
4683	Cape de lieur de sort
4684	Ceinture de lieur de sort
4686	Cape barbare en tissu
4687	Ceinture barbare en tissu
4689	Cape de chasse
4690	Ceinture de chasse
4692	Cape de cérémonie
4693	Ceinture de cérémonie en cuir
4694	Espauliers brunis
4695	Cape brunie
4696	Chope de Tidesippe de Lapidis
4697	Ceinturon bruni
4698	Mantelet de prophète
4699	Ceinture de prophète
4700	Spallières en cuir gravé
4701	Cape gravée
4702	Piolet de prospecteur
4703	Outils cassés
4705	Epauliers en écailles brillantes
4706	Cape en écailles brillantes
4707	Ceinturon en écailles brillantes
4708	Ceinture éclatante
4709	Mantelet sylvestre en cuir
4710	Cape forestière
4711	Cape rougeoyante
4712	Ceinturon en mailles rougeoyantes
4713	Cape brochée d'argent
4714	Echarpe brochée d'argent
4715	Cape blasonnée
4716	Cape de combat
4717	Ceinture de guerre en mailles
4718	Mantelet nocturne
4719	Cape nocturne
4720	Echarpe nocturne
4721	Mantelet à insigne
4722	Cape à insigne
4723	Pantalon d'Humbert
4724	Casque d'Humbert
4725	Espauliers de général de brigade
4726	Cape de général de brigade
4727	Ceinturon de général de brigade
4728	Epaulière de Twain
4729	Mantelet de l'aurore
4731	Epaulettes glyphées
4732	Cape glyphée
4733	Espauliers forgenoire
4734	Mantelet de Longuebrume
4735	Cape de Longuebrume
4736	Echarpe de Longuebrume
4737	Spallières impériales en cuir
4738	Ceinture impériale en cuir
4739	Viande de trotteur des plaines
4740	Plume de trotteur des plaines
4741	Jambières de cavalier de Stromgarde
4742	Peau de puma des montagnes
4743	Fragment de cristal palpitant
4744	Brassards runiques des arcanes
4745	Brassards de chevaucheur martial
4746	Robe d'auspice funeste
4747	Eau du puits de Stormbull
4748	Eau du puits de Redhorn
4749	Eau du puits Wildmane
4751	Serre de Furie-des-vents
4752	Plume azur
4753	Plume en bronze
4755	Cruche d'eau
4756	Peau de félin abîmée
4757	Coquilles d'oeuf brisées
4758	Patte de loup des prairies
4759	Serre de trotteur des plaines
4763	Arc incurvé de noirbois
4765	Epée large en émail
4766	Lame farouche
4767	Gants en étoffe cuivrée
4768	Gants d'adepte
4769	Plume de Rapace trophée
4770	Ceinture de Dos-hirsute
4771	Cape des moissons
4772	Cape chaude
4775	Bec craquelé
4776	Plume ébouriffée
4777	Maillet en bois de fer
4778	Lourde masse à pointes
4779	Dent de kodo terne
4780	Fragment de corne de kodo
4781	Gilet des murmures
4782	Robe du solstice
4783	Totem de Hawkwind
4784	Pierre morte
4785	Ceinture de soufre
4786	Ceinture de grand sage
4787	Poix ardente
4788	Bottes agiles
4789	Bottes d'écurie
4790	Cape d'Inferno
4791	Eau enchantée
4792	Cape spirituelle
4793	Cape sylvestre
4794	Brassards du loup
4795	Brassards de l'ours
4796	Brassards de la chouette
4797	Cape flamboyante
4798	Cape runique lourde
4799	Cape antique
4800	Pantalon en mailles de la puissance
4801	Griffes de Traqueur
4802	Griffes de puma
4803	Dent d'Alpha des prairies
4804	Coeur de loup des prairies
4805	Fémur de puma des basses plaines
4806	Ecaille de trotteur des plaines
4807	Gésier de Rapace
4808	Pierre de puits
4809	Pomme de pin
4810	Ailettes du rocher
4813	Petit collier en cuir
4814	Croc décoloré
4816	Jambières de légionnaire
4817	Claymore sacrée
4818	Epée du bourreau
4819	Ecritoire de Fizsprocket
4820	Targe de gardien
4821	Targe de l'ours
4822	Disque de la chouette
4823	Eau des Prophètes
4824	Hache de confusion
4825	Hache calleuse
4826	Hache de maraudeur
4827	Ceinture de sorcier
4828	Ceinture du vent nocturne
4829	Ceinture du rêveur
4830	Jambières du sabre
4831	Pantalon de traque
4832	Sarong mystique
4833	Epaulières glorieuses
4834	Documents de la KapitalRisk
4835	Epaulières de soldat d'élite
4836	Orbe ignifugé
4837	Force de la volonté
4838	Orbe de puissance
4840	Longue baïonnette
4841	Corne d'Arra'chea
4843	Pierre runique d'améthyste
4844	Pierre runique d'opale
4845	Pierre runique de diamant
4846	Rouage N°5
4847	Entraves des élémentaires de Lotwil
4848	Groin de sanglier de guerre
4849	Flanc de sanglier de guerre
4850	Plans d'attaque des Dos-hirsute
4851	Carte couverte de poussière
4852	Bombe éclairante
4854	Cape griffée par les démons
4855	Unused Cloth Shoulder A01 Gray
4856	Unused Cloth Shoulder A02 Yellow
4857	Unused Cloth Shoulder B01 Silver
4858	Unused Cloth Shoulder B02 Black
4859	Médaillon de la Lame ardente
4860	Ecaille de furie scintillante
4861	Tunique en plumes lustrées
4862	Queue de scorpide ouvrier
4863	Outils gnomes
4864	Crâne de Minshina
4865	Peau détruite
4866	Tête de Zalazane
4867	Patte de scorpide brisée
4869	Griffe de Fizzle
4870	Morceaux de canevas
4871	Collier brûlant
4872	Oeil de scorpide sec
4873	Bigorneaux secs durcis
4874	Arêtes propres
4875	Os visqueux
4876	Bottes en cuir sanglantes
4877	Tête de flèche en pierre
4878	Arc brisé taché de sang
4879	Carcasse de lapin écrasé
4880	Lance brisée
4881	Vieille enveloppe
4882	Clé de Benedict
4883	Ordres de l'amiral Proudmoore
4886	Glande à venin de queue-venin
4887	Oeil de makrura intact
4888	Mucus de clampant
4890	Oeuf de fouette-queue
4891	Amulette de Kron
4892	Fourrure de tigre de Durotar
4893	Canine de lion des savanes
4894	Rognon de trotteur des plaines
4895	Corne de lézard-tonnerre
4896	Foie de kodo
4897	Glande salivaire de faucon-tonnerre
4898	Glande d'éclair
4903	Oeil de l'ombre ardente
4904	Antidote du queue-venin
4905	Pince abîmée de Sarkoth
4906	Bottes de pluie
4907	Tunique forestière
4908	Brassards de nomade
4909	Jambières du chasseur de kodo
4910	Gants en anneaux peints
4911	Targe en écorce épaisse
4913	Ceinture en anneaux peints
4914	Gants détériorés en cuir
4915	Bottes souples en laine
4916	Gilet souple en laine
4917	Jambières détériorées en anneaux
4918	Sac de ravitaillement
4919	Ceinture souple en laine
4920	Cape détériorée
4921	Jambières poussiéreuses
4922	Lorica abîmée
4923	Hachette primitive
4924	Gourdin primitif
4925	Lame de main primitive
4926	Tonneau vide de Chen
4928	Garde-poignets de coureur des sables
4929	Armure de scorpide légère
4930	Sac en cuir fait main
4931	Arc en noyer
4932	Aile de la harpie
4933	Cape de combattant aguerri
4935	Grand ceinturon en métal
4936	Bottes empoussiérées
4937	Targe de charge
4938	Bâton de bois abîmé
4939	Solide bâtarde
4940	Poignes voilées
4941	Colle très collante
4942	Bottes en peau de tigre
4944	Cape cousue à la main
4945	Crâne au faible rougeoiement
4946	Bottes de légèreté
4947	Dague dentelée
4948	Masse hérissée
4949	Fendoir orc
4951	Ceinture du hurleur
4952	Stormstout
4953	Tête de Trogg
4954	Ceinture de nomade
4957	Vieille bourse
4958	Cape délavée
4959	Tomahawk de jet
4960	Bille d'éclair
4961	Bâton du gardien des rêves
4962	Gants rembourrés
4963	Cape de Thunderhorn
4964	Ecraseur gobelin
4965	Hache à main de Bloodhoof
4966	Tête de Mazzranache
4967	Bouclier tribal
4968	Harnais lié
4969	Manchettes fortifiées
4970	Jambières de kodo mal tannées
4971	Marteau de Skorn
4972	Bottes du grimpeur des collines
4973	Garde-poignets de chasseur des plaines
4974	Couteau de combat compact
4975	Targe de vigilance
4976	Kilt de Mistspray
4977	Epée de Trépas-d'Orgrim
4978	Marteau de Ryedol
4979	Brassards enchantés en étoffe de pierre
4980	Gants de prospecteur
4981	Sacoche d'Agmond
4982	Ceinture de prospecteur abîmée
4983	Destructeur de roc
4984	Crâne de malédiction imminente
4986	Pierre de puissance imparfaite
4987	Epée du capitaine nain
4988	Anneau ardent en obsidienne
4989	Robe de mage-dragon
4990	Poignets brûlés
4992	Lettre de recrutement
4995	Lettre de recrutement signée
4998	Anneau de sang
4999	Volonté d'Azora
5000	Bague de corail
5001	Anneau du coeur
5002	Talisman vert luminescent
5003	Médaillon de l'étoile de cristal
5004	Marque du Kirin Tor
5005	Pendentif d'Emberspark
5006	Journal de Khazgorm
5007	Bandeau d'épines
5008	Anneau de vif-argent
5009	Anneau d'influence mentale
5010	Anneau d'or gravé
5011	Anneau de Welken
5012	Spores fongiques
5013	Bulbe fertile
5014	Wrapping Paper (PT)
5015	Wrapped Item (PT)
5016	Pantalon de l'ouvrier
5017	Nitroglycérine
5018	Pulpe de bois
5019	Nitrate de sodium
5020	Clé du butin des Kolkar
5021	Bâton explosif de Gann
5022	Tête de Plaie-des-kodos
5023	Tête de Verog
5024	Fiole de glace
5025	Tête d'Hezrul
5026	Goudron de feu
5027	Spores fondues
5028	Sceptre du seigneur Sakrasis
5029	Talisman du seigneur naga
5030	Bracelets de centaure
5038	Larme des lunes
5040	Couteau de chasseur d'ombre
5042	Papier d'emballage à ruban rouge
5043	Cadeau au ruban rouge
5044	Cadeau au ruban bleu
5045	Cadeau du crâne
5046	Cadeau verrouillé
5047	Papier d'emballage au crâne
5048	Papier d'emballage à ruban bleu
5049	Feuille de fer verrouillée
5050	Clé de contact
5051	Rat fouisseur
5052	Rat fouisseur inconscient
5054	Samophlange
5055	Corne de raptor intacte
5056	Echantillon de racines
5057	Pastèque mûre
5058	Oeuf de silithide
5059	Griffe d'excavation
5060	Outils de voleur
5061	Argent volé
5062	Tête de raptor
5063	Défense de Kreenig Grondegroin
5064	Griffe d'Ensorçaile
5065	Anneau de lieutenant harpie
5066	Plante des crevasses
5067	Tête de Serena
5068	Graines séchées
5069	Baguette de feu
5071	Baguette de l'ombre
5072	Crâne de Lok
5073	Crâne de Nak
5074	Crâne de Kuz
5075	Joyau de sang
5076	Cargaison de bottes
5077	Lentille du télescope
5078	Médaille de Theramore
5079	Oeil de basilic Oeil-de-glace
5080	Livre de compte de Gazlowe
5081	Sac en peau de kodo
5082	Cuir fin de kodo
5083	Patron : Sac en peau de kodo
5084	Tête du baron de Longrivage
5085	Défense de huran Dos-hirsute
5086	Sabots de zhévra
5087	Bec de trotteur des plaines
5088	Manuel de la console de contrôle
5089	Clé de la console
5092	Baguette Tranchecrin carbonisée
5093	Poignard de Tranchecrin
5094	Bouclier Tranchecrin
5095	Thon arc-en-ciel
5096	Griffe de Rôdeur
5097	Emeraude oeil-de-chat
5098	Carapace de Gueule d'acier altérée
5099	Sabot de Lakota'mani
5100	Peau d'Echeyakee
5101	Croc d'Ishamuhale
5102	Epine caudale d'Owatanka
5103	Plume de Washte Pawne
5104	Coeur d'Isha Awak
5105	Cartouche explosive
5107	Chemise de matelot
5108	Cuir sombrefer
5109	Haillons brisepierre
5110	Robe de sorcier de Dalaran
5111	Cape de Rathorian
5112	Lame rituelle
5113	Marque du Syndicat
5114	Griffe abîmée
5115	Os brisé
5116	Longue plume de queue
5117	Plume vibrante
5118	Grande dent plate
5119	Fin cheveu flottant
5120	Long poil de queue
5121	Ecaille de kodo sale
5122	Epais poil de kodo
5123	Tête de flèche en acier
5124	Petite dent de raptor
5125	Ecaille chargée
5126	Connaissance : Déguisement de Défias
5127	Connaissance : Déguisement de Pirate des Mers du sud
5128	Peau de lézard dépouillée
5129	Connaissance : Déguisement de nain sombrefer
5130	Connaissance : Déguisement de sorcier de Dalaran
5131	Connaissance : déguisement de Brisepierre
5132	Connaissance : Déguisement du Syndicat
5133	Gésier suintant
5134	Petite patte en fourrure
5135	Fine griffe noire
5136	Oreille de fourrure déchirée
5137	Globe oculaire brillant
5138	Tête du moissonneur
5139	Livre d'Epines
5140	Poudre éclipsante
5141	Livre de Rétablissement
5142	Livre de Colère II
5143	Sang de lézard-tonnerre
5145	Livre de Toucher guérisseur II
5147	Livre de Sarments II
5148	Livre d'Epines II
5149	Livre de Colère III
5150	Livre de Toucher guérisseur III
5151	Livre de Colère IV
5152	Livre de Toucher guérisseur IV
5153	Livre de Marque du fauve IV
5154	Livre d'Epines III
5155	Livre de Marque du fauve II
5156	Livre de Colère V
5158	Livre de Tranquillité
5160	Livre de Toucher guérisseur V
5163	Livre de Marque du fauve III
5164	Ailes de faucon-tonnerre
5165	Plume solécaille
5166	Glande à venin Tissebois
5167	Oeuf d'araignée Tissebois
5168	Graine de sylvain
5169	Pousse de sylvain
5170	Tumeur moussue
5172	Capsule de léthargie
5173	Herbe mortelle
5174	Note de Neeru
5175	Totem de terre
5176	Totem de feu
5177	Totem d'eau
5178	Totem d'air
5179	Coeur moussu
5180	Collier d'harmonie
5181	Cape en soie frissonnante
5182	Lame des frissons
5183	Coeur d'hydre palpitant
5184	Fiole de cristal remplie
5185	Fiole de cristal
5186	Récipient à moitié plein
5187	Marteau de Rhahk'Zor
5188	Vase rempli
5189	Fruit luminescent
5190	Racines flamboyantes
5191	Lame de cruauté
5192	Lame du larron
5193	Cape de la confrérie
5194	Hache du sous-chef
5195	Gants tachetés d'or
5196	Hache de Smite
5197	Attendrisseur de Macaron
5198	Bâton à touiller de Macaron
5199	Pantalon de fusion
5200	Harpon de perforation
5201	Bâton de Pierrebraise
5202	Casaque de corsaire
5203	Griffe de Rôdeur des basses plaines
5204	Ceinture plumesang
5205	Racine éclose
5206	Racines d'agression
5207	Baguette opaque
5208	Baguette de fonte
5209	Baguette d'obscurité
5210	Baguette ardente
5211	Baguette de crépuscule
5212	Baguette flamboyante
5213	Baguette de brûlure
5214	Baguette d'Eventide
5215	Baguette de braise
5216	Baguette d'Umbral
5217	Coeur corrompu
5218	Coeur de sylvain purifié
5219	Ecorce gravée
5220	Croc de Pin-tordu
5221	Tête de Melenas
5223	Gemme de mana vide
5227	Bijou de mana vide
5229	Pierre de sang supérieure vide
5232	Pierre d'âme mineure
5233	Pierre de Relu
5234	Fossile de Flagongut
5235	Baguette de l'alchimiste
5236	Baguette de combustible
5237	Poison de distraction mentale
5238	Baguette de Pitchwood
5239	Baguette de Blackbone
5240	Baguette d'Illumination
5241	Bâton de flammes nain
5242	Baguette de cendres
5243	Crache-feu
5244	Baguette consacrée
5245	Baguette de l'invocateur
5246	Bâtonnet d'excavation
5247	Bâtonnet de désolation
5248	Baguette éclairante
5249	Branchette ardente
5250	Baguette carbonisée
5251	Fiole de divination
5252	Baguette de putréfaction
5253	Boute-feu gobelin
5254	Spallières robustes
5255	Tomahawk huran
5256	Vacarme de Kovork
5257	Pèlerine sombre
5263	Compresse de poche
5264	Bon pour une bière gratuite
5265	Bière coupée
5266	Oeil d'Adaegus
5267	Kriss écarlate
5268	Cuirasse de silithide craquelée
5269	Ichor de silithide
5270	Amanite phalloïde
5271	Pédoncule d'amanite
5272	Gribouillages déments
5273	Relique de Mathystra
5274	Mantelet rose
5275	Ceinturon de lien
5279	Eventreur de harpies
5299	Gants de la lune
5302	Targe en cobalt
5306	Bâton du cavalier céleste
5309	Mousquet de corsaire
5310	Culotte du loup de mer
5311	Bottes sanglées
5312	Gantelets à rivets
5313	Anneau de clan totémique
5314	Cape de chasseur de sanglier
5315	Garde-bras de bûcheron
5316	Tunique de nacrécorce
5317	Tunique de mousse sèche
5318	Hache de Zhovur
5319	Espauliers de fracas
5320	Bottes de lamelles matelassées
5321	Elégante épée courte
5322	Marteau de démolition
5323	Lanterne éternelle
5324	Marteau d'ingénieur
5325	Bouclier soudé
5326	Bâton de vision
5327	Pantalon graisseux d'artisan
5328	Ceinture sanglée
5329	Figurine de chat
5330	Relique de coupe elfique
5332	Figurine de chat luminescente
5334	Porto vieux de 99 ans
5335	Un sac de pièces
5336	Boucle d'oreille de grell
5337	Gants de randonnée
5338	Ancien sceau de pierre de lune
5339	Fleur de serpent
5340	Touille-chaudron
5341	Tunique couverte de spores
5342	Punch du raptor
5343	Cape d'aubergiste
5344	Hache à pointe
5345	Marteau en bois de fer
5346	Arc de bataille orc
5347	Baguette de pestilence
5348	Parchemin déchiré
5349	Muffin invoqué
5350	Eau invoquée
5351	Anneau du chasseur de primes
5352	Livre : Les puissances d'en-bas
5353	Message pour Elissa Starbreeze
5354	Lettre à Delgren
5355	Ceinturon de belluaire
5356	Bâtonnet de flétrissure
5357	Bouclier des vallons
5359	Manuscrit de Lorgalis
5360	Relique de bien-Né
5361	Cure-dents en arête de poisson
5362	Jouet pour chien
5363	Mouchoir plié
5364	Morceau de sel séché
5366	Gemme d'âme luminescente
5367	Outil en pierre primitif
5368	Portefeuille vide
5369	Os rongé
5370	Pelle grossière
5371	Morceau de corail
5373	Charme de chance
5374	Petite montre gousset
5375	Bâton piquant
5376	Miroir brisé
5377	Coquille Saint-Jacques
5379	Couteau de jet
5380	Lettre scellée pour Elissa
5381	Lettre scellée à Balthule
5382	Pendentif d'Anaya
5383	Tête d'Athrikus Narassin
5385	Patte de clampant
5386	Belle peau de traquelune
5387	Cape enchantée de traquelune
5388	Crâne de Ran Dent-rouge
5389	Totem furbolg corrompu
5390	Message de Fandral
5391	Terre rare
5392	Dague des chardons
5393	Bâton des chardons
5394	Gants d'entraînement d'archer
5395	Bouclier forestier
5396	Clé de la gorge des Vents brûlants
5397	Poudre à canon de défias
5398	Jambières de la canopée
5399	Bottes de pistage
5400	Sang de Cobrahn
5401	Sang de Pythas
5402	Sang d'Anacondra
5403	Sang de Serpentis
5404	Epaulières ophidiennes
5405	Cape drapée
5406	Pierre de sang mineure vide
5411	Totem de purification de Winterhoof
5412	Oeil de batteur
5413	Croc de traquelune
5414	Scalp vieilli
5415	Totem de purification de Thunderhorn
5416	Totem de purification de Wildmane
5419	Brassards farouches
5420	Armure de la Banshee
5421	Enchantement d'éclat flamboyant
5422	Jambières de Brambleweed
5423	Croc de Boahn
5424	Ancienne statuette
5425	Ceinturon en écailles runiques
5426	Baiser du serpent
5427	Montre gousset grossière
5428	Un livre de cuisine exotique
5429	Un joli caillou
5430	Bijoux de pacotille
5431	Flasque vide
5432	Pipe en noyer
5433	Poupée de chiffon
5435	Zirgouflex brillant
5437	Cheveu de Bathran
5439	Petit carquois
5440	Bouteille des maladies
5441	Petite sacoche de poudre
5442	Tête d'Arugal
5443	Targe plaquée or
5444	Cape de mineur
5445	Anneau de Zoram
5446	Bracelet élémentaire rompu
5447	Bracelet élémentaire endommagé
5448	Bracelet élémentaire cassé
5451	Bracelet élémentaire brisé
5455	Parchemin divin
5456	Parchemin de divination
5457	Griffe de Vaudou abîmée
5458	Ceinture de terrebois
5459	Hache de défenseur
5460	Jouvence d'Orendil
5461	Branche de Cénarius
5462	Bâtonnet de transformation de Dartol
5463	Gemme luminescente
5464	Hampe en fer
5465	Petite patte d'araignée
5466	Dard de scorpide
5467	Viande de kodo
5468	Chair tendre de Furie
5469	Viande de trotteur
5470	Queue de lézard-tonnerre
5471	Viande de cerf
5472	Kébab d'araignée kaldorei
5473	Surprise du scorpide
5474	Viande de kodo rôtie
5475	Clé en bois
5476	Filet de furie
5477	Brouet de trotteur
5478	Brouet de rat
5479	Queue de lézard croquante
5480	Venaison dégraissée
5481	Cornes de satyre
5482	Recette : Kébab d'araignée kaldorei
5483	Recette : Surprise du scorpide
5484	Recette : Viande de kodo rôtie
5485	Recette : Filet de furie
5486	Recette : Brouet de trotteur
5487	Recette : Brouet de rat
5488	Recette : Queue de lézard croquante
5489	Recette : Venaison dégraissée
5490	Tête d'Irequeue
5493	Larme d'Elune
5494	Poignée de poussière d'étoile
5498	Petite perle satinée
5500	Perle iridescente
5503	Chair de palourde
5504	Chair de palourde relevée
5505	Journal de Teronis
5506	Oeil perlé
5507	Longue-vue ornée
5508	Pierre de lune tombée
5509	Pierre de soins
5510	Pierre de soins supérieure
5511	Pierre de soins inférieure
5512	Pierre de soins mineure
5513	Jade de mana
5514	Agate de mana
5516	Croc de battrodon
5517	Petite clé en bronze
5518	Petite clé en fer
5519	Pommeau en fer
5520	Journal de Velinde
5521	Clé de Velinde
5522	Pierre de sort
5523	Petite palourde spiralée
5524	Palourde à coque épaisse
5525	Palourdes bouillies
5526	Soupe de palourdes
5527	Palourdes gobelines
5528	Recette : Soupe de palourdes
5529	Poussière tombale
5530	Poudre aveuglante
5533	Tome d'Ilkrud Magthrull
5534	Repas de Parker
5535	Compendium des Déchus
5536	Mythologie des Titans
5537	Tête de Sarilus Foulborne
5538	Anneau de mariage de Vorrel
5539	Lettre de recommandation
5540	Dague à perles
5541	Marteau iridescent
5542	Cape brodée de perles
5543	Plans : Marteau iridescent
5544	Crâne de Dal Griffesang
5547	Bâtonnet reconstitué
5565	Pierre infernale
5566	Ramure brisée
5567	Crochet d'argent
5568	Caillou lisse
5569	Algue
5570	Oeuf des mousses profondes
5571	Petite bourse noire
5572	Petite bourse verte
5573	Sac vert en cuir
5574	Sac blanc en cuir
5575	Grand sac vert
5576	Grand sac brun
5577	Plans : Brassards grossiers en bronze
5578	Plans : Cuirasse en bronze argenté
5579	Marteau de guerre de la milice
5580	Marteau de la milice
5581	Bâton de marche lisse
5582	Sève des Serres-Rocheuses
5583	Ecaille de dragon-faë
5584	Moustache crépusculaire
5585	Oeil de coursier
5586	Lame des chardons
5587	Gourdin de ronceterre
5588	Toxine de Lydon
5589	Gantelets couverts de mousse
5590	Brassards de corde
5591	Cape tachée de pluie
5592	Ceinturon d'entrave
5593	Targe des rochers
5594	Lettre à Jin'Zil
5595	Marteau de bois
5596	Arc d'Ashwood
5601	Sac d'oeuf éclos
5602	Toile d'araignée collante
5603	Sacoche de Wizbang
5604	Baguette elfique
5605	Serpette
5606	Gants de jardinage
5608	Capuche vivante
5609	Cordelière inébranlable
5610	Cape des terres venteuses
5611	Larme de douleur
5612	Crispins de lierre
5613	Bâton du purificateur
5614	Frappe du Séraphin
5615	Epée du bûcheron
5616	Etripeur
5617	Jambières du vagabond
5618	Cape d'éclaireur
5619	Fiole de jade
5620	Fiole de sang d'innocent
5621	Fiole de tourmaline
5622	Anneau du clergé
5623	Fiole d'améthyste
5624	Diadème de l'ordre
5626	Broie-crâne
5627	Lame de relique
5628	Note de Zamah
5629	Gants poing-de-marteau
5630	Gants du vent mordant
5631	Potion de Rage
5632	Potion de fuite irrépressible
5633	Potion de Grande rage
5634	Potion de libre action
5635	Griffe aiguisée
5636	Plume délicate
5637	Grand croc
5638	Brouillard toxique
5639	Fiole de jade remplie
5640	Recette : Potion de rage
5641	Recette : Potion de fuite irrépressible
5642	Recette : Potion de libre action
5643	Recette  : Potion de Grande rage
5644	Tome d'Invocation d'eau
5645	Fiole de tourmaline remplie
5646	Fiole d'eau bénite
5647	Tome de Transfert
5648	Tome d'Armure de givre III
5649	Tome de Blizzard
5650	Tome d'Invocation d'eau III
5654	Toxine instantanée
5655	Bride de jument alezane
5656	Bride de cheval bai
5657	Recette  : Toxine instantané
5658	Libram : Sceau de puissance
5659	Braises ardentes
5660	Libram : Sceau de piété
5661	Libram : Sceau de piété II
5662	Libram : Sceau de piété III
5663	Cor du loup rouge
5664	Shrapnel abîmé
5665	Cor du loup redoutable
5666	Libram : Sceau de colère II
5667	Libram : Sceau de sagesse II
5668	Cor du loup brun
5669	Débris de Diable de poussière
5670	Libram : Sceau de colère V
5671	Libram : Sceau de puissance III
5672	Libram : Exorcisme
5673	Libram : Exorcisme II
5674	Libram : Exorcisme III
5675	Ecailles de cristal
5676	Libram : Détection des morts-vivants
5677	Libram : Renvoi des morts-vivants
5678	Libram : Sceau de sacrifice
5679	Libram : Sceau de sagesse III
5680	Libram : Sceau de protection II
5681	Sève corrosive
5682	Libram : Renvoi des morts-vivants I
5683	Libram : Bouclier divin II
5684	Libram : Sceau de salut
5685	Libram : Rédemption
5686	Tête d'Ordanus
5687	Clé du gardien
5689	Clé du dormeur
5690	Clé des griffes
5691	Clé du refuge
5692	Détonateur à distance (Rouge)
5693	Détonateur à distance (Bleu)
5694	Explosifs NG-5 (Rouges)
5695	Explosifs NG-5 (Bleus)
5696	Tablette d'Horion
5697	Tablette de Totem de soins
5698	Tablette de Bouclier de foudre
5699	Tablette de Loup fantôme
5700	Tablette de Totem de soins II
5701	Tablette de Totem sentinelle
5702	Tablette de Totem d'agitation II
5703	Tablette de Coup de tonnerre
5704	Tablette de Respiration aquatique
5705	Tablette de Totem de soins III
5706	Tablette de Totem du serpent III
5707	Tablette de Double vue
5708	Tablette de Forme éthérée
5709	Tablette de Marche sur l'eau
5710	Tablette de Totem de soins IV
5711	Tablette de Loup fantôme II
5712	Tablette de Totem du serpent IV
5713	Tablette de Trait de tonnerre
5714	Tablette de Totem d'enracinement II
5715	Tablette de Tempête de foudre III
5716	Tablette de Restauration VI
5717	Lettres de la KapitalRisk
5718	Plans d'ingénieur de la KapitalRisk
5719	Grimoire de Drain de vie II
5720	Grimoire de Malédiction de Mannoroth II
5721	Grimoire de Création de Pierre de sort
5722	Grimoire de Siphon de mana II
5723	Grimoire de Malédiction de Sargeras III
5724	Grimoire de Malédiction des langages
5725	Grimoire de Pestilence III
5726	Grimoire de Création de pierre de sang supérieure
5727	Grimoire de Captation de mana
5728	Grimoire de Pluie de feu II
5729	Grimoire de Peur III
5730	Livre de Récupération
5731	Parchemin de messager
5732	NG-5
5733	Minerai non identifié
5734	Plan du Super-Découpeur 6000
5735	Enveloppe scellée
5736	Bras mécanique de Gerenzo
5737	Plans des opérations spéciales : Alpha & Bêta
5738	Sac des opérations spéciales
5739	Harnais barbare
5740	Fusée de feu d'artifice rouge
5741	Morceau de rocher
5742	Dague sertie
5743	Anneau prismatique
5744	Peau-pâle
5748	Arc long du centaure
5749	Hache scythe
5750	Ceinturon de chef de guerre
5751	Cape d'aile de toile
5752	Dard de wyverne
5753	Coiffure hérissée
5754	Médaillon de la meute
5755	Harnois d'onyx de déchiqueteur
5756	Lame de taille
5757	Trique de bois dur
5758	Coffret en mithril
5759	Coffret de thorium
5760	Coffret d'éternium
5761	Masse d'Anvilmar
5762	Sac rouge en lin
5763	Sac rouge en laine
5764	Sac vert en soie
5765	Sac noir en soie
5766	Robe de sorcier inférieur
5767	Robe violette
5768	Billet pour la course gnome
5769	Billet pour la course gobelin
5770	Robe d'Arcana
5771	Patron : Sac rouge en lin
5772	Patron : Sac rouge en laine
5773	Patron : Robe d'Arcana
5774	Patron : Sac vert en soie
5775	Patron : Sac noir en soie
5776	Canne de doyen
5777	Hache du brave
5778	Bâton de marche primitif
5779	Bâtarde des Réprouvés
5780	Ceinture en écailles de murloc
5781	Cuirasse en écailles de murloc
5782	Armure épaisse de murloc
5783	Brassards en écailles de murloc
5784	Ecailles de murloc visqueuses
5785	Ecailles de murloc épaisses
5786	Patron : Ceinture en écailles de murloc
5787	Patron : Cuirasse en écailles de murloc
5788	Patron : Armure épaisse de murloc
5789	Patron : Brassards en écailles de murloc
5790	Journal de Lonebrow
5791	Journal d'Henrig Lonebrow
5792	Médaillon de Trancheflanc
5793	Coeur de Trancheflanc
5794	Venin de scorpide acide
5795	Carapace de tortue durcie
5796	Nageoire incrustée
5797	Flocon d'Indurium
5798	Pièces de chariot explosif
5799	Commande de Kravel
5800	Pièces détachées de Kravel
5801	Guano du kraal
5802	Pièces de chariot fragiles
5803	Grain de poussière de rêve
5804	Rumeurs gobelines
5805	Coeur zélé
5806	Bière du sot
5807	Rapport sur la bière du sot
5808	Glande à venin d'Aile-fière
5809	Glande à venin de Haut-perchoir
5810	Carcasse fraîche
5811	Crinière de Gueule-glacée
5812	Robe des temps anciens
5813	Flamme d'Emil
5814	Armure du ruisseau
5815	Pierre glaciale
5816	Lumière d'Elune
5817	Arc Lunaris
5818	Baguette d'éclat lunaire
5819	Camail d'ensoleillement
5820	Mantelet des fées
5821	Bottes de Traqueur noir
5822	Gantelets du hallier
5823	Champignon venimeux
5824	Tablette de volonté
5825	Pendentif de Treshala
5826	Plan de Kravel
5827	Lettre de Fizzle Brassbolts
5829	Bec acéré
5830	Tête de Kenata
5831	Tête de Fardel
5832	Tête de Marcel
5833	Minerai d'Indurium
5834	Tabac de Mok'Morokk
5835	Tafia de Mok'Morokk
5836	Coffre de Mok'Morokk
5837	Côte de Broie-l'acier
5838	Parchemin de peau de kodo
5839	Page de journal
5840	Langue d'incendiaire
5841	Coeur d'incendiaire
5842	Echantillon de minerai brut
5843	Griffes de Grenka
5844	Fragments de Rok'Alim
5845	Flanchet de viande
5846	Note scellée de Korran
5847	Tête d'Aileron boueux
5848	Os creux de vautour
5849	Caisse de casques anti-accidents
5850	Note scellée de Belgrom
5851	Clé de Cozzle
5852	Plan de régulateur de fuel
5853	Carapace de silithide intacte
5854	Serre de silithide
5855	Coeur de silithide
5857	Boîte à surprises gnome
5858	Boîte à surprises gobeline
5859	Grenade à fragmentation
5860	Héritage des Aspects
5861	Naissance de la menace des morts-vivants
5862	Lance-hydroglycérine
5863	Charte de guilde
5864	Bélier gris
5865	Lance-hydroglycérine modifié
5866	Echantillon de minerai d'Indurium
5867	Fiole d'eau forte
5868	Fiole d'eau forte remplie
5869	Sabot fendu
5871	Grand sabot
5872	Bélier brun
5873	Bélier blanc
5874	Harnais : bélier noir
5875	Harnais : bélier bleu
5876	Racines de Feuillebleue
5877	Carapace de silithide craquelée
5878	Excellent tabac
5879	Pendentif du crépuscule
5880	Caisse percée
5881	Tête de Kelris
5882	Documents du capitaine
5883	Langue fourchue de Rochefange
5884	Oeil de Sombrebrume
5897	Manuel d'utilisateur de Sniffetarin
5916	Clé d'appareil gnome
5917	Rapport d'espion
5918	Tête d'orc défiant
5919	Bouclier en fer noirci
5936	Ceinture en peau d'animal
5937	Clé d'appareil gobelin
5938	Patte de clampant en parfait état
5939	Gants de couture
5940	Targe en os
5941	Pantalon d'écailles de cuivre
5942	Pendentif serti
5943	Brassards de la faille
5944	Grèves de la milice du peuple
5945	Dent de Mortebourbe
5946	Note scellée à Elling
5947	Registre des Défias
5948	Lettre à Jorgen
5949	Morceau de papier
5950	Insigne de Reethe
5951	Chiffon à poussière
5952	Souche de cerveau corrompu
5956	Marteau de forgeron
5957	Gilet en cuir cousu main
5958	Pantalon élégant en cuir
5959	Sac de venin acide
5960	Note scellée pour Backus
5961	Pantalon noir en cuir
5962	Pantalon de gardien
5963	Jambières barbares
5964	Epaulières barbares
5965	Cape de gardien
5966	Gants de gardien
5967	Ceinturon de noblesse
5968	Bottes robustes
5969	Cape de régent
5970	Gants du serpent
5971	Cape de plumes
5972	Patron : Pantalon élégant en cuir
5973	Patron : Jambières barbares
5974	Patron : Cape du gardien
5975	Ceinture de forban
5976	Tabard de guilde
5996	Elixir de Respiration aquatique
5997	Elixir de défense mineure
5998	Requête de Stormpike
6016	Echantillon de coeur de loup
6037	Barre de vrai-argent
6038	Ardeur de palourde géante
6039	Recette : Ardeur de palourde géante
6040	Brassards en écailles dorées
6041	Dragonne en acier
6042	Pointe de bouclier en fer
6043	Contrepoids en fer
6044	Plans : Pointe de bouclier en fer
6045	Plans : Contrepoids en fer
6046	Plans : Dragonne en acier
6047	Plans : Camail en écailles dorées
6048	Potion de protection contre l'Ombre
6049	Potion de protection contre le Feu
6050	Potion de protection contre le Givre
6051	Potion de protection contre le Sacré
6052	Potion de protection contre la Nature
6053	Recette : Potion de protection contre le Sacré
6054	Recette : Potion de protection contre l'Ombre
6055	Recette : Potion de protection contre le Feu
6056	Recette : Potion de protection contre le Givre
6057	Recette : Potion de protection contre la Nature
6058	Ceinture en cuir noirci
6059	Gilet de nomade
6060	Brassards en lin
6061	Brassards de grisepierre
6062	Brassards de corde épaisse
6063	Gantelets d'acier glacé
6064	Disques de platine miniature
6065	Essais de Khadgar sur la convergence dimensionnelle
6066	Tête du khan Dez'hepah
6067	Oreille de centaure
6068	Recette : Huile des ténèbres
6069	Viande grossièrement séchée
6070	Brassards en peau de loup
6071	Cristal de draenéthyste
6072	Tête du khan Jehn
6073	Tête du khan Shaka
6074	Embouchure de cor de guerre
6075	Rapport de Vimaire
6076	Pantalon moulant
6077	Fragment de clé des Maraudine
6078	Bouclier du lancier
6079	Charme brut
6080	Coeur de panthère des ombres
6081	Champignon de Boueux
6082	Tumeur d'Arpentefonds
6083	Larmes brisées
6084	Jambières de garde de Stormwind
6085	Tunique de fantassin
6086	Sérum de vérité de Faustin
6087	Chausses de la marche de l'Ouest
6089	Bière de Zraedus
6091	Caisse de pierres de puissance
6092	Bottes de dragonnet noir
6093	Concassorc
6094	Hache de perforation
6095	Bottes d'errance
6096	Chemise d'apprenti
6097	Chemise d'acolyte
6098	Robe de néophyte
6116	Robe d'apprenti
6117	Chemise d'écuyer
6118	Pantalon d'écuyer
6119	Robe de néophyte
6120	Chemise de recrue
6121	Pantalon de recrue
6122	Bottes de recrue
6123	Robe de novice
6124	Pantalon de novice
6125	Harnais de bagarreur
6126	Pantalon du trappeur
6127	Bottes du trappeur
6129	Robe d'acolyte
6130	Chemise du trappeur
6131	Pantalon du trappeur
6132	Libram : Sceau de sagesse
6133	Libram : Sceau de fureur
6134	Mantelet primitif
6135	Kilt primitif
6136	Chemise de nervi
6137	Pantalon de nervi
6138	Bottes de nervi
6139	Robe de novice
6140	Robe d'apprenti
6144	Robe de néophyte
6145	Pendentif de Clarice
6146	Bois flotté séché au soleil
6147	Vieille ceinture miteuse
6148	Bottes poussiéreuses
6149	Potion de mana supérieure
6150	Noeud en tissu râpé
6166	Mâchoire de coyote
6167	Rapport de Neeka
6168	Griffe de Mordeur Dents-de-scie
6169	Flanc de Dents-de-scie non préparé
6170	Composants pour les sorciers
6171	Gants d'éleveur de loups
6172	Fournitures perdues
6173	Bottes des neiges
6174	Epée aléatoire de Twain
6175	Artefact atal'ai
6176	Grand pavois nain
6177	Brassards en fer forgé
6178	Cargaison de Rempart-du-Néant
6179	Cape de corsaire
6180	Peau de Slark
6181	Fétiche d'Hakkar
6182	Torche faible
6183	Petite torche éteinte
6184	Patte de clampant monstrueux
6185	Châle de l'ours
6186	Découpeur de trogg
6187	Défenseur nain
6188	Ecrase-boue
6189	Epaulières en mailles solides
6190	Fragment de draenéthyste
6191	Bottes de Kimbra
6192	Tête du khan Hratha
6193	Artefacts atal'ai
6194	Désosseuse
6195	Armure rutilante
6196	Gourdin de Noboru
6197	Broigne en peau de croco du Loch
6198	Garde-poignets jurassiques
6199	Anneau de la veuve noire
6200	Ceinture de guerre de Garneg
6201	Bottes souples
6202	Mitaines blindées
6203	Bouclier des nervis
6204	Coiffure tribale worg
6205	Pelle
6206	Pioche
6207	PVP - Plans de la tour de la Horde
6208	PVP - Plans de la tour de l'Alliance
6209	PVP - Mine de la Horde
6210	PVP - Mine de l'Alliance
6211	Recette : Elixir de Force d'ogre
6212	Tête de Jammal'an
6214	Grand maillet en cuivre
6215	Bâton de combat équilibré
6216	Poudre mystique
6217	Bâtonnet en cuivre
6218	Bâtonnet runique en cuivre
6219	Clé plate
6220	Fragment de météore
6222	Formule : Imprégnation de plastron (Esprit mineur)
6223	Cimier de Darkshire
6226	Tablier sanglant
6238	Robe marron en lin
6239	Gilet rouge en lin
6240	Gilet bleu en lin
6241	Robe blanche en lin
6242	Robe bleue en lin
6243	Robe verte en laine
6244	ggggfg
6245	Sacoche de Karnitol
6246	Griffe de Fielfurie
6247	Corne de Fielfurie
6248	Venin scorpashi
6249	Peau de vieux kodo
6250	Cervelle de gangrechien
6251	Aile du Néant
6252	Sang de garde funeste
6253	Caisse de Leftwitch
6256	Canne à pêche
6257	Gésier de Roc
6258	Foie de Ferpoil
6259	Foie de Groddoc
6260	Teinture bleue
6261	Teinture orange
6262	Journal de Galen
6263	Salopette bleue
6264	Robe d'adepte supérieur
6265	Fragment d'âme
6266	Gilet de disciple
6267	Pantalon de disciple
6268	Tunique de pionnier
6269	Pantalon de pionnier
6270	Patron : Gilet bleu en lin
6271	Patron : Gilet rouge en lin
6272	Patron : Robe bleue en lin
6273	Patron : Robe verte en laine
6274	Patron : Salopette bleue
6275	Patron : Robe d'adepte supérieur
6276	Note moisie
6277	Papier moisi
6278	Parchemin moisi
6279	Lettre moisie
6280	Musty Missive
6281	Crâne de Cliquethorax
6282	Pantalon de rituel funéraire
6283	Le Livre d'Ur
6284	Runes d'invocation
6285	Grimoire d'Egalin
6286	Coeurs purs
6287	Fragment de tablette atal'ai
6288	Tablette atal'ai
6289	Lutjan à longue mâchoire cru
6290	Goujon brillant
6291	Goujon brillant cru
6292	Lutjan de 10 livres
6293	Sang séché de chauve-souris
6294	Lutjan de 12 livres
6295	Lutjan de 15 livres
6296	Poils de chauve-souris
6297	Vieux crâne
6298	Croc sanglant de chauve-souris
6299	Poisson maladif
6300	Fragment de peau
6301	Crâne du vieux Teamster
6302	Aile d'insecte délicate
6303	Maquereau ombré cru
6304	Page de journal humide (Jour 4)
6305	Page de journal humide (Jour 87)
6306	Page de journal humide (Jour 512)
6307	Message dans une bouteille
6308	Poisson-chat moustachu cru
6309	Poisson-chat de 17 livres
6310	Poisson-chat de 19 livres
6311	Poisson-chat de 22 livres
6312	Coeur de Dalin
6313	Coeur de Comar
6314	Cape de meneur de loups
6315	Arbalète à traits d'acier
6316	Délice de furie du loch
6317	Furie du loch crue
6318	Bâton d'Odo
6319	Ceinturon du guetteur aveugle
6320	Cimier de commandant
6321	Sceau de la famille d'Argelaine
6323	Sceptre du baron
6324	Robe d'Arugal
6325	Recette : Goujon brillant
6326	Recette : Maquereau ombré
6327	Le Pacificateur
6328	Recette : Lutjan à longue mâchoire
6329	Recette : Délice de furie du loch
6330	Recette : Poisson-chat moustachu
6331	Lame des lamentations
6332	Anneau à la perle noire
6333	Dague des piques
6335	Bottes grisonnante
6336	Tunique d'infanterie
6337	Jambières d'infanterie
6338	Bâtonnet en argent
6339	Bâtonnet runique en argent
6340	Peau de Fenrus
6341	Lanterne d'écurie sinistre
6342	Formule : Enchantement de plastron (Mana mineur)
6343	Formule : Imprégnation de plastron (Esprit)
6344	Formule : Enchantement de bracelets (Esprit mineur)
6345	Formule : Imprégnation de cape (Protection)
6346	Formule : Enchantement de plastron (Mana inférieur)
6347	Formule : Enchantement de bracelets (Force mineure)
6348	Formule : Enchantement d'arme (Tueur de bête mineur)
6349	Formule : Enchantement d'arme 2M (Intelligence inférieure)
6350	Bottes grossières en bronze
6351	Caisse endommagée
6352	Caisse détrempée
6353	Petit coffre
6354	Petit coffre verrouillé
6355	Coffre solide verrouillé
6356	Coffre endommagé
6357	Caisse scellée
6358	Bouche-noire huileux
6359	Lutjan de nagefeu
6360	Poisson aux écailles d'acier
6361	Thon arc-en-ciel cru
6362	Morue rochécaille crue
6363	Poisson-chat de 26 livres
6364	Poisson-chat de 32 livres
6365	Solide canne à pêche
6366	Canne à pêche de sombrebois
6367	Grande canne à pêche en fer
6368	Recette : Thon arc-en-ciel
6369	Recette : Morue rochécaille
6370	Huile de bouche-noire
6371	Huile de feu
6372	Potion de Nage rapide
6373	Elixir de Maîtrise du feu
6374	Poudre enchantée
6375	Formule : Enchantement de bracelet (Esprit inférieur)
6376	Formule : Bottes enchantées (Endurance mineure)
6377	Formule : Bottes enchantées (Agilité mineure)
6378	Cape de prophète
6379	Ceinture en cuir gravé
6380	Targe gravée
6381	Cape éclatante
6382	Ceinture sylvestre en cuir
6383	Targe sylvestre
6384	Chemise bleue d'apparat
6385	Chemise verte d'apparat
6386	Cuissards en mailles rougeoyantes
6387	Brassards en mailles rougeoyantes
6388	Espauliers en mailles rougeoyantes
6389	Camail en mailles rougeoyantes
6390	Patron : Chemise bleue d'apparat
6391	Patron : Chemise verte d'apparat
6392	Ceinture d'Arugal
6393	Gants brochés d'argent
6394	Bottes brochées d'argent
6395	Amict broché d'argent
6396	Plastron blasonné
6397	Gants blasonnés
6398	Ceinture blasonnée
6399	Epaulières blasonnées
6400	Bouclier rougeoyant
6401	Patron : Chemise noire en soie
6402	Jambières de guerre en mailles
6403	Garde-bras de guerre en mailles
6404	Spallières de guerre en mailles
6405	Pantalon nocturne
6406	Bottes nocturnes
6407	Protège-poignets nocturnes
6408	Gants à insigne
6409	Ceinture à insigne
6410	Brassards à insigne
6411	Armure de général de brigade
6412	Bottes de général de brigade
6413	Brassards de général de brigade
6414	Sceau de Sylvanas
6415	Robe de l'aurore
6416	Bottes de l'aurore
6417	Cape de l'aurore
6418	Echarpe de l'aurore
6419	Mitaines glyphées
6420	Bottes glyphées
6421	Ceinture glyphée
6422	Casque glyphé
6423	Grèves forgenoire
6424	Cape forgenoire
6425	Ceinturon forgenoire
6426	Brassards forgenoire
6427	Robe de Longuebrume
6428	Gants de Longuebrume
6429	Chapeau de sorcier de Longuebrume
6430	Cuirasse impériale en cuir
6431	Bottes impériales en cuir
6432	Cape impériale
6433	Casque impérial en cuir
6435	Gemme ardente canalisée
6436	Gemme ardente
6438	Bracelet élémentaire terne
6439	Bracelets brisés
6440	Brainlash
6441	Scalp de Traqueur des ténèbres
6442	Cristal d'oracle
6443	Peau de déviant
6444	Langue fourchue
6445	Peau de mue
6446	Sac en serpent
6447	Bouclier en écailles de tortue usé
6448	Dard
6449	Cape en écailles de lézard luminescentes
6450	Bandage en soie
6451	Bandage épais en soie
6452	Anti-venin
6453	Sérum anti-venin supérieur
6454	Manuel : Sérum anti-venin supérieur
6455	Vieille roue
6456	Gelée acide
6457	Mécanismes rouillés
6458	Poisson huileux
6459	Trotteurs sauvages
6460	Torsade de Cobrahn
6461	Ailettes visqueuses
6462	Caisse sûre
6463	Anneau des grandes profondeurs
6464	Essence de lamentation
6465	Robe du mocassin d'eau
6466	Cape en écailles de déviant
6467	Gants en écailles de déviant
6468	Ceinture en écailles de déviant
6469	Venimeux
6470	Ecaille de déviant
6471	Ecaille de déviant parfaite
6472	Vipère mortelle
6473	Armure du Croc
6474	Patron : Cape en écailles de déviant
6475	Patron : Gants en écailles de déviant
6476	Patron : Ceinture en écailles de déviant
6477	Echarpe de la prairie
6478	Ecrabouille-rat
6479	Pendentif de Malem
6480	Jambières luisantes de déviant
6481	Gantelets de Dagmire
6482	Bottes de marchefeu
6486	Ecaille roussie
6487	Tête de Vil quasit
6488	Tablette simple
6489	Parchemin passé
6490	Parchemin noir
6491	Parchemin rugueux
6492	Parchemin noirci
6493	Parchemin usé
6494	Parchemin griffonné
6495	Parchemin détrempé
6496	Parchemin détaillé
6497	Parchemin simple
6498	Cuir de kodo gravé
6499	Cuir de kodo gravé
6500	Cuir de kodo gravé
6501	Cuir de kodo gravé
6502	Broigne violette
6503	Robe bigarrée
6504	Lame ailée
6505	Bâton au croissant
6506	Bottes d'infanterie
6507	Brassards d'infanterie
6508	Cape d'infanterie
6509	Ceinture d'infanterie
6510	Gantelets d'infanterie
6511	Robe de compagnon
6512	Robe de disciple
6513	Echarpe de disciple
6514	Cape de disciple
6515	Gants de disciple
6516	Parchemin d'invocation de diablotin
6517	Ceinture de pionnier
6518	Bottes de pionnier
6519	Brassards de pionnier
6520	Cape de pionnier
6521	Gants de pionnier
6522	Poisson déviant
6523	Harnais à boucle
6524	Harnais en cuir clouté
6525	Harnais de grunt
6526	Harnais de combat
6527	Robe ancestrale
6528	Robe de lieur de sort
6529	Verroterie brillante
6530	Asticots
6531	Robe barbare en tissu
6532	Verroterie
6533	Attracteur de poissons aquadynamique
6534	Barres d'acier forgé
6535	Tablette de Verga
6536	Gilet du saule
6537	Bottes du saule
6538	Robe du saule
6539	Ceinture du saule
6540	Pantalon du saule
6541	Gants du saule
6542	Cape du saule
6543	Brassards du saule
6544	Parchemin d'invocation de marcheur du Vide
6545	Armure de soldat
6546	Jambières de soldat
6547	Gantelets de soldat
6548	Ceinturon de soldat
6549	Cape de soldat
6550	Garde-poignets de soldat
6551	Bottes de soldat
6552	Tunique de barde
6553	Pantalon de barde
6554	Gants de barde
6555	Cape de barde
6556	Brassards de barde
6557	Bottes de barde
6558	Ceinture de barde
6559	Targe de barde
6560	Bouclier de soldat
6561	Gambison de prophète
6562	Bottes chatoyantes
6563	Brassards chatoyants
6564	Cape chatoyante
6565	Gants chatoyants
6566	Amict chatoyant
6567	Armure chatoyante
6568	Pantalon chatoyant
6569	Robe chatoyante
6570	Echarpe chatoyante
6571	Targe de l'éclaireur
6572	Bouclier de défenseur
6573	Bottes de défenseur
6574	Brassards de défenseur
6575	Cape de défenseur
6576	Ceinturon de défenseur
6577	Gantelets de défenseur
6578	Jambières de défenseur
6579	Spallières de défenseur
6580	Tunique de défenseur
6581	Ceinture de l'éclaireur
6582	Bottes de l'éclaireur
6583	Brassards de l'éclaireur
6584	Tunique de l'éclaireur
6585	Cape de l'éclaireur
6586	Gants de l'éclaireur
6587	Pantalon de l'éclaireur
6588	Spallières de l'éclaireur
6589	Anneau viridien
6590	Bottes de forgeguerre
6591	Garde-poignets de forgeguerre
6592	Armure de forgeguerre
6593	Cape de forgeguerre
6594	Ceinturon de forgeguerre
6595	Gantelets de forgeguerre
6596	Cuissards de forgeguerre
6597	Garde-épaules de forgeguerre
6598	Targe de derviche
6599	Bouclier de forgeguerre
6600	Ceinture de derviche
6601	Bottes de derviche
6602	Brassards de derviche
6603	Tunique de derviche
6604	Cape de derviche
6605	Gants de derviche
6607	Jambières de derviche
6608	Armure éclatante
6609	Défroque de sage
6610	Robe de sage
6611	Echarpe de sage
6612	Bottes de sage
6613	Brassards de sage
6614	Cape de sage
6615	Gants de sage
6616	Pantalon de sage
6617	Mantelet de sage
6619	Manuel : La voie de la défense
6620	Parchemin élaboré
6621	Manuel de provocation
6622	Epée de zèle
6623	Parchemin d'invocation de succube
6624	Breuvage de Ken'zigla
6625	Pendentif de poussière
6626	Pendentif de Dogran
6627	Cuirasse d'écailles du mutant
6628	Serres du corbeau
6629	Cape des spores
6630	Targe de Seedcloud
6631	Racine vivante
6632	Cape d'écailles-faë
6633	Hachoir du boucher
6634	Baume rituel
6635	Sapta de terre
6636	Sapta de feu
6637	Sapta d'eau
6638	Sapta d'air
6640	Sabot de traqueur corrompu
6641	Lame de hantise
6642	Armure fantôme
6643	Sardine boursouflée
6644	Maquereau boursouflé
6645	Lutjan boursouflé
6646	Thon boursouflé
6647	Poisson-chat boursouflé
6648	Parchemin de Totem Peau de pierre
6649	Parchemin de Totem incendiaire
6650	Parchemin de Totem guérisseur
6651	Bouteille de vin brisée
6652	Bourse de réactifs
6653	Torche de la flamme dormante
6654	Torche de la flamme éternelle
6655	Braise rougeoyante
6656	Quartz brut
6657	Délice de déviant
6658	Spécimen de collier
6659	Pantalon du scarabée
6660	Dague de Julie
6661	Recette : Délice de déviant
6662	Elixir de Taille de géant
6663	Recette : Elixir de Taille de géant
6664	Mantelet vaudou
6665	Brassards maléficiés
6666	Bottes de boueux
6667	Cape d'ingénieur
6668	Bottes du conscrit
6669	Anneau sacré
6670	Armure de la panthère
6671	Jambières du molosse
6672	Schéma : Bombe éclairante
6675	Brassards trempés
6676	Targe du connétable
6677	Baguette de sortilèges
6678	Anneau de grâce elfique
6679	Perce-fer
6681	Fleur d'épines
6682	Robe de nécrorateur
6684	Bâton de commandement de Sniffetarin
6685	Mantelet de nécrorateur
6686	Heaume du phacochère
6687	Démembreur
6688	Coiffure de Whisperwind
6689	Bâton d'esprit du vent
6690	Jambières de Ferine
6691	Croc de swinetusk
6692	Hache à crocs
6693	Anneau d'Agamaggan
6694	Coeur d'Agamaggan
6695	Amulette stygienne en os
6696	Arc du Traqueur nocturne
6697	Mantelet d'aile de vampire
6698	Pierre de Pierce
6707	Pierre de Lapidis
6708	Pierre de Goodman
6709	Gilet Lueur-de-lune
6710	Patron : Gilet Lueur-de-lune
6711	Pierre de Kurtz
6712	Serrure d'entraînement
6713	Pantalon déchiré
6714	Dynamite Ev-Lan
6715	Défibrillateur abîmé
6716	Schéma : Dynamite Ev-Lan
6717	Rouage électrique
6718	Electropeller
6719	Ceinture des vents
6720	Coiffure de chasseur d'esprit
6721	Pansière de Kor
6722	Maniques bestiales
6723	Médaille de courage
6724	Pierre de Backus
6725	Targe marbrée
6726	Ceinture de sécurité personnalisée de Razzeric
6727	Gants de course de Razzeric
6728	Pierre de Brownell
6729	Boute-feu de Fizzle
6730	Cotte d'anneaux d'Ironforge
6731	Cuirasse d'Ironforge
6732	Gants de mécanicien gnome
6733	Gantelets d'Ironforge
6734	Plans : Cotte d'anneaux d'Ironforge
6735	Plans : Cuirasse d'Ironforge
6736	Plans : Gantelets d'Ironforge
6737	Pantalon des feuilles sèches
6738	Croissant sanglant
6739	Visée du rôdeur
6740	Echarpe azur
6741	Epée de guerre orque
6742	Ceinturon Poing-de-pierre
6743	Anneau de soutien
6744	Gants de Kapelan
6745	Cape de vélocité
6746	Targe de basalte
6747	Espauliers de massacreur
6748	Anneau du singe
6749	Anneau du tigre
6750	Arceau du serpent
6751	Châle de deuil
6752	Bottes du lancier
6753	Charme de plume
6754	Grande bourse
6755	Un petit coffre de gemmes
6756	Boîte de bijoux
6757	Chevalière de Jaina
6766	Flayed Demon Skin (old2)
6767	Pendentif de Tyranis
6773	Cotte d'anneaux de maraudeur gelkis
6774	Doigt d'Uthek
6775	Tome de divinité
6776	Tome de valeur
6777	Tome de piété
6778	Tome de justice
6779	Tome de noblesse
6780	Echarpe lilas
6781	Tasse de Bartleby
6782	Plaque du maréchal Haggard
6783	Clé de Dent-Morte
6784	Garde-mains à fermoir
6785	Puissance du Vide
6786	Jupe simple
6787	Robe blanche en laine
6788	Ceinture de chasseur de Magram
6789	Couverture de cérémonie centaure
6790	Anneau de calme
6791	Bottes d'Hellion
6792	Espauliers sanguins
6793	Brassards d'Auric
6794	Gantelets flamme-tempête
6795	Chemise blanche de bretteur
6796	Chemise rouge de bretteur
6797	Pique-oeil
6798	Haquebute explosive
6799	Tête de Vejrek
6800	Minerai d'Umbral
6801	Tablier baroque
6802	Epée de malédiction
6803	Canne du Prophète
6804	Marteau de Windstorm
6805	Corne de Vorlus
6806	Flamme dansante
6807	Brouet de cuisses de grenouille
6808	Minerai d'Elunite
6809	Médaillon d'Elura
6810	Foulard de Surena
6811	Oeil de poisson aquadynamique
6812	Caisse d'Elunite
6826	Ecaille brillante
6827	Boîte de fournitures
6828	Targe du visionnaire
6829	Epée de sérénité
6830	Mordos
6831	Menace noire
6832	Cape du chancre
6833	Chemise blanche de smoking
6834	Smoking noir
6835	Pantalon de smoking noir
6836	Chaussures habillées
6837	Robe de mariage
6838	Croc d'araignée brûlé
6839	Corne carbonisée
6840	Corne galvanisée
6841	Fiole de Phlogiston
6842	Instructions de Furen
6843	Barrique de Scalder
6844	Sang ardent
6845	Roc ardent
6846	Script défias
6847	Script sombrefer
6848	Corail torride
6849	Coquille brûlée par le soleil
6850	Scalp Bloodscalp
6851	Essence d'exil
6852	Oeil éternel
6866	Symbole de vie
6887	Jaune-queue tacheté
6888	Oeufs aux herbes
6889	Petit oeuf
6890	Viande d'ours fumée
6891	Recette : Oeufs aux herbes
6892	Recette : Viande d'ours fumée
6893	Clé d'atelier
6894	Coeur de tourbillon
6895	Marteau de forge de Jordan
6897	Manuel : La voie du berserker
6898	Orbe de Soran'ruk
6899	Orbe de Warlock 35
6900	Robe sanglante dorée enchantée
6901	Cape luminescente du batteur
6902	Poignets de Serra'kis
6903	Pantalon du rêveur
6904	Morsure de Serra'kis
6905	Hache des récifs
6906	Poings d'algues
6907	Armure de la tortue
6908	Lien de Ghamoo-ra
6909	Frappe de l'Hydre
6910	Pantalon de sangsue
6911	Cordelière de mousse
6912	Coeur du bois
6913	Noyau du coeur du bois
6914	Fragment de Soran'ruk
6915	Grand fragment de Soran'ruk
6916	Tome de divinité
6926	Notes de Furen
6927	Oreille du Grand Will
6928	Echarpe de pierre de sang
6929	Parchemin de Bath'rah
6930	Bâtonnet de canalisation
6931	Tome moisi
6947	Poison instantané
6948	Pierre de foyer
6949	Poison instantané II
6950	Poison instantané III
6951	Poison de distraction mentale II
6952	Fourrure d'ours épaisse
6953	Poing de Verigan
6966	Hache d'Elunite
6967	Epée d'Elunite
6968	Marteau d'Elunite
6969	Dague d'Elunite
6970	Faveur de Furen
6971	Camail en acier trempé
6972	Haubert en acier trempé
6973	Jambières en acier trempé
6974	Gantelets en acier trempé
6975	Hache de tourbillon
6976	Marteau de tourbillon
6977	Epée de tourbillon
6978	Hache d'Umbral
6979	Hache de Haggard
6980	Dague de Haggard
6981	Dague d'Umbral
6982	Masse d'Umbral
6983	Marteau d'Haggard
6984	Epée d'Umbral
6985	Epée de Haggard
6986	Lotus cramoisi
6987	Ecaille de poisson
6988	Parchemin d'invocation de Chasseur corrompu
6989	Fiole de sang de Fielfurie
6990	Pierre d'Infernal inférieure
6991	Charbon ardent
6992	Cargaison de minerai de Jordan
6993	Cargaison de minerai raffiné de Jordan
6994	Bois de chêne de blanchepierre
6995	Gemme de Kor corrompue
6996	Notes sur les armes de Jordan
6997	Manuscrit en lambeaux
6998	Bottes de la nimbe
6999	Tome de la Cabale
7000	Ceinturon de coeur du bois
7001	Sceptre du tombeau
7002	Targe arctique
7003	Pinces de hanneton
7004	Cape de prélat
7005	Couteau à dépecer
7006	Tome recomposé
7007	Grand butin de Backus
7026	Ceinture en lin
7027	Bottes des ténèbres
7046	Pantalon azur en soie
7047	Mains des ténèbres
7048	Chaperon azur en soie
7049	Gants de vraie foi
7050	Bandeau en soie
7051	Gilet terrestre
7052	Ceinture azur en soie
7053	Cape azur en soie
7054	Robe de puissance
7055	Ceinture cramoisie en soie
7056	Cape cramoisie en soie
7057	Epaulières vertes en soie
7058	Gilet cramoisi en soie
7059	Epaulières cramoisies en soie
7060	Epaulières azur
7061	Ceinture terrestre en soie
7062	Culotte cramoisie en soie
7063	Robe cramoisie en soie
7064	Gants cramoisis en soie
7065	Armure verte en soie
7067	Terre élémentaire
7068	Feu élémentaire
7069	Air élémentaire
7070	Eau élémentaire
7071	Boucle en fer
7072	Ecaille de naga
7073	Croc brisé
7074	Griffes émoussées
7075	Noyau de terre
7076	Essence de terre
7077	Coeur de feu
7078	Essence de feu
7079	Globe d'eau
7080	Essence d'eau
7081	Souffle de vent
7082	Essence d'air
7083	Gemme de Kor purifiée
7084	Patron : Epaulières cramoisies en soie
7085	Patron : Epaulières d'azur
7086	Patron : Ceinture terrestre en soie
7087	Patron : Cape cramoisie en soie
7088	Patron : Robe cramoisie en soie
7089	Patron : Cape azur en soie
7090	Patron : Armure verte en soie
7091	Patron : Gants de vraie foi
7092	Patron : Mains des ténèbres
7093	Patron : Bottes des ténèbres
7094	Branche de bois
7095	Bottes des tourbières
7096	Plume arrachée
7097	Viande de mollet
7098	Défense brisée
7099	Pinces endommagées
7100	Ichor gluant
7101	Oeil de bestiole
7106	Gants du zodiaque
7107	Ceinture des étoiles
7108	Bouclier d'infanterie
7109	Targe de pionnier
7110	Armure brochée d'argent
7111	Armure nocturne
7112	Armure de l'aurore
7113	Armure de Longuebrume
7114	Patron : Gants azur en soie
7115	Hache de l'héritier
7116	Dague de l'héritier
7117	Marteau de l'héritier
7118	Epée de l'héritier
7119	Antenne mobile
7120	Bouclier de Ruga
7126	Lingot de fer cendré
7127	Azurite en poudre
7128	Sabot fendu de satyre
7129	Gantelets de brutalité
7130	Camail de brutalité
7131	Tibia de Dragonmaw
7132	Jambières de brutalité
7133	Haubert de brutalité
7134	Solide tibia de Dragonmaw
7135	Tibia de Dragonmaw cassé
7146	La Clé écarlate
7148	Défibrillateur gobelin
7166	Dague en cuivre
7170	Epée aléatoire de Twain
7187	Bottes de VanCleef
7188	Bouclier de garde de Stormwind
7189	Bottes-fusées gobelines
7190	Bottes-fusée brûlées
7191	Câble avec fusible
7192	Schéma : Bottes-fusées gobelines
7206	Echantillon d'eau du lac Miroir
7207	Flasque de Jennea
7208	Clé de Tazan
7209	Sacoche de Tazan
7226	Bidulotron de youplala
7227	Gueules-de-loup de Balnir
7228	Glace à la fraise d’Aguilor
7229	Broigne d'explorateur
7230	Puissant marteau de Smite
7231	Lettre d'introduction d'Astor
7247	Caisse de coffres de stockage
7249	Gemme chargée de la faille
7266	Traité d'Ur sur la Magie des Ombres
7267	Soie d'araignée en parfait état
7268	Echantillon d'eau de Xavian
7269	Flasque de Deino
7270	Cheveu de Soeur rieuse
7271	Défense d'ivoire sans défaut
7272	Roncier de foudre
7273	Bâton totem de Witherbark
7274	Rituels du Pouvoir
7275	Les parchemins d'Agamaggan
7276	Cape en cuir cousu main
7277	Brassards en cuir cousu main
7278	Carquois en cuir léger
7279	Petite giberne en cuir
7280	Pantalon en cuir robuste
7281	Brassards en cuir léger
7282	Pantalon en cuir léger
7283	Cape de dragonnet noir
7284	Gants en cuir de dragonnet rouge
7285	Gants d'agilité en cuir
7286	Ecaille de dragonnet noir
7287	Ecaille de dragonnet rouge
7288	Patron : Pantalon en cuir robuste
7289	Patron : Cape de dragonnet noir
7290	Patron : Gants en cuir de dragonnet rouge
7291	Orbe infernal
7292	Coffre de stockage rempli
7293	Gemme de mana de Dalaran
7294	Grand Livre d’Andron
7295	Journal des messages de Tazan
7296	Torche éteinte
7297	Fléau de Morbent
7298	Lame de malice
7306	Tête de Fenwick
7307	Ver mangeur de chair
7308	Chants de manifestation
7309	Rapport de situation de Dalaran
7326	Hache de Thun'grim
7327	Dague de Thun'grim
7328	Masse de Thun'grim
7329	Epée de Thun'grim
7330	Targe d'infiltrateur
7331	Bouclier de la phalange
7332	Armure régalienne
7333	Sifflet de surveillant
7334	Robe efflorescente
7335	Tunique du grizzly
7336	Cotte d'anneaux forestière
7337	Le Rocher
7338	Anneau changeant
7339	Anneau à minuscule diamant
7340	Solitaire sans défaut
7341	Anneau cubique de Zirconia
7342	Anneau d'argent de Piffeny
7343	Clé de Bingles
7344	Torche de la sainte flamme
7345	Tournevis de Bingles
7346	Marteau de Bingles
7347	Contre-rouage de Bingles
7348	Gants de fabricant d'arcs
7349	Gants d'herboriste
7350	Brassards de disciple
7351	Bottes de disciple
7352	Epaulières terrestres en cuir
7353	Gambison de doyen
7354	Bottes de doyen
7355	Brassards de doyen
7356	Cape de doyen
7357	Chapeau de doyen
7358	Gants de chapardeur
7359	Gants terrestres lourds
7360	Patron : Gants noirs en cuir
7361	Patron : Gants d'herboriste
7362	Patron : Epaulières terrestres en cuir
7363	Patron : Gants de chapardeur
7364	Patron : Gants terrestres lourds
7365	Indicateur Gnoam
7366	Gants de doyen
7367	Mantelet de doyen
7368	Pantalon de doyen
7369	Robe de doyen
7370	Echarpe de doyen
7371	Carquois lourd
7372	Giberne en cuir lourd
7373	Jambières en cuir mat
7374	Armure en cuir mat
7375	Armure de dragonnet vert
7376	Capsuleur soufflant de Bingles
7377	Cape de givre en cuir
7378	Brassards mats
7386	Brassards de dragonnet vert
7387	Ceinture matte
7388	Clé crâne
7389	Livre de comptes de la KapitalRisk
7390	Bottes mattes
7391	Bottes de rapidité
7392	Ecaille de dragonnet vert
7406	Corde d'infiltrateur
7407	Armure d'infiltrateur
7408	Epaulières d'infiltrateur
7409	Bottes d'infiltrateur
7410	Brassards d'infiltrateur
7411	Cape d'infiltrateur
7412	Gants d'infiltrateur
7413	Coiffe d'infiltrateur
7414	Pantalon d'infiltrateur
7415	Spallières de derviche
7416	Brassards de la phalange
7417	Bottes de la phalange
7418	Cuirasse de la phalange
7419	Cape de la phalange
7420	Protège-front de la phalange
7421	Gantelets de la phalange
7422	Ceinturon de la phalange
7423	Jambières de la phalange
7424	Spallières de la phalange
7425	Tête de Cyrik
7426	Anneau céruléen
7427	Talisman céruléen
7428	Peau de félin des ombres
7429	Armure du crépuscule
7430	Robe du crépuscule
7431	Pantalon du crépuscule
7432	Capuche du crépuscule
7433	Gants du crépuscule
7434	Bottes du crépuscule
7435	Mantelet du crépuscule
7436	Cape du crépuscule
7437	Crispins du crépuscule
7438	Ceinture du crépuscule
7439	Harnais de sentinelle
7440	Pantalon de sentinelle
7441	Coiffe de sentinelle
7442	Clé de Gyromast
7443	Gants de sentinelle
7444	Bottes de sentinelle
7445	Epaulières de sentinelle
7446	Cape de sentinelle
7447	Brassards de sentinelle
7448	Ceinturon de sentinelle
7449	Patron : Jambières en cuir mat
7450	Patron : Armure de dragonnet vert
7451	Patron : Brassards de dragonnet vert
7452	Patron : Bottes mattes
7453	Patron : Bottes de rapidité
7454	Cuirasse de chevalier
7455	Cuissards de chevalier
7456	Protège-front de chevalier
7457	Gantelets de chevalier
7458	Bottes de chevalier
7459	Espauliers de chevalier
7460	Cape de chevalier
7461	Brassards de chevalier
7462	Ceinturon de chevalier
7463	Targe de sentinelle
7464	Glyphes d'invocation
7465	Cimier de chevalier
7466	Anneau vermeil
7467	Collier vermeil
7468	Robe régalienne
7469	Jambières régaliennes
7470	Chapeau de sorcier régalien
7471	Gants régaliens
7472	Bottes régaliennes
7473	Mantelet régalien
7474	Cape régalienne
7475	Crispins régaliens
7476	Echarpe régalienne
7477	Tunique de forestier
7478	Jambières de forestier
7479	Casque de forestier
7480	Gants de forestier
7481	Bottes de forestier
7482	Epaulières de forestier
7483	Cape de forestier
7484	Garde-poignets de forestier
7485	Corde de forestier
7486	Cuirasse de capitaine
7487	Jambières de capitaine
7488	Diadème de capitaine
7489	Gantelets de capitaine
7490	Bottes de capitaine
7491	Garde-épaules de capitaine
7492	Cape de capitaine
7493	Brassards de capitaine
7494	Sangle de capitaine
7495	Targe de capitaine
7496	Bouclier de guerre en plaques
7497	Anneau d'ivoire
7498	Clé supérieure de Gelkak
7499	Clé médiane de Gelkak
7500	Clé inférieure de Gelkak
7506	Télécommande universelle gnome
7507	Orbe des arcanes
7508	Orbe de Ley
7509	Robe en tisse-mana
7510	Robe du feu-sorcier mineur
7511	Robe du noeud astral
7512	Robe du Néant
7513	Baguette de Ragefire
7514	Baguette d'Icefury
7515	Orbe céleste
7516	Instructions de Tabetha
7517	Tunique de tulle
7518	Robe de tulle
7519	Pantalon de tulle
7520	Couvre-chef de tulle
7521	Gants de tulle
7522	Bottes de tulle
7523	Protège-épaules de tulle
7524	Cape de tulle
7525	Brassards de tulle
7526	Ceinture de tulle
7527	Plastron de cabaliste
7528	Jambières de cabaliste
7529	Casque de cabaliste
7530	Gants de cabaliste
7531	Bottes de cabaliste
7532	Spallières de cabaliste
7533	Cape de cabaliste
7534	Brassards de cabaliste
7535	Ceinture de cabaliste
7536	Pavois de champion
7537	Bouclier gothique
7538	Armure de champion
7539	Jambières de champion
7540	Heaume de champion
7541	Gantelets de champion
7542	Grèves de champion
7543	Espauliers de champion
7544	Cape de champion
7545	Brassards de champion
7546	Ceinturon de champion
7547	Anneau d'onyx
7548	Foulard d'onyx
7549	Baiser des fées
7550	Honneur du guerrier
7551	Talisman tressé d'opaline
7552	Serre de l'épervier
7553	Anneau de la licorne
7554	Branche de saule
7555	Etoile régalienne
7556	Orbe du crépuscule
7557	Bâtonnet de tulle
7558	Douve chatoyante
7559	Canne runique
7560	Schéma : Télécommande universelle gnome
7561	Schéma : Défibrillateur gobelin
7566	Epée de la famille Agamand
7567	Hache de la famille Agamand
7568	Dague de la famille Agamand
7569	Masse de la famille Agamand
7586	Espoir de Tharnariun
7587	Instructions de Thun'grim
7606	Gantelets polaires
7607	Baguette en martre
7608	Chope ornée de prophète
7609	Bâton d'ambre de doyen
7610	Sphère de l'aurore
7611	Bâton de Longuebrume
7613	Patron : Armure verte en cuir
7626	Ballot de fourrures
7627	Livraison de Dolanaar
7628	Lettre
7629	Fardeau d'Ukor
7646	Caisse de ravitaillement de l'auberge
7666	Collier brisé
7667	Fiole de divination de Talvash
7668	Journal maculé de sang
7669	Rubis de collier brisé
7670	Saphir de collier brisé
7671	Topaze de collier brisé
7672	Source d'énergie du collier brisé
7673	Collier d'amélioration de Talvash
7674	Livraison pour Mathias
7675	Programme d'embarquement des Défias
7676	Thé de chardon
7678	Recette : Thé de chardon
7679	Croc de chauve-souris de Shrike
7680	Ecaille de basilic Jadéchine
7681	Fragment de golem d'obsidienne
7682	Tisonnier de torture
7683	Coup de poing sanglant en laiton
7684	Mantelet de mage de sang
7685	Orbe du Prophète oublié
7686	Oeil d'Echine-de-fer
7687	Poing d'Echine-de-fer
7688	Thorax d'Echine-de-fer
7689	Aube morbide
7690	Cestes d'ébène
7691	Voile embaumé
7708	Baguette de nécromancie
7709	Jambières flétries
7710	Bâton d'entraînement de Loksey
7711	Robe de Doan
7712	Mantelet de Doan
7713	Bâtonnet d'illusion
7714	Lame hypnotique
7715	Rapport d'Onin
7716	Collier brisé
7717	Ravageuse
7718	Epaulière d'Herod
7719	Heaume du berserker enragé
7720	Chapeau de Whitemane
7721	Main de la droiture
7722	Amulette de Triune
7723	Puissance de Mograine
7724	Gantelets de divinité
7726	Egide du commandant écarlate
7727	Espauliers de veilleur
7728	Robe de tromperie
7729	Mousquet Chesterfall
7730	Ecraseur de cobalt
7731	Talisman de Ghostshard
7733	Bâton de la préhistoire
7734	Sac des six démons
7735	Rose de Jannok
7736	Gourdin de combat
7737	Journal de Sethir
7738	Gants vert sapin
7739	Cape de bûcheron
7740	Médaillon de Gni'kiv
7741	La Hampe de Tsol
7742	Schéma : Système d'occultation gnome
7746	Recommandation de la Ligue des explorateurs
7747	Vil Protecteur
7748	Targe de Forcestone
7749	Orbe Oméga
7750	Mantelet de malédiction
7751	Bottes de Vorrel
7752	Coupe-rêve
7753	Etripeur
7754	Bottes de messager
7755	Epaulières de silex
7756	Gants de dressage de chien
7757	Bâton de Windweaver
7758	Kriss acéré
7759	Plastron d'archon
7760	Kilt de chef de guerre
7761	Tranchant d'acier
7766	Outre marron vide
7767	Outre bleue vide
7768	Outre rouge vide
7769	Outre marron remplie
7770	Outre bleue remplie
7771	Outre rouge remplie
7786	Casse-tête
7787	Gardien resplendissant
7806	Sucette
7807	Barre de chocolat
7808	Carré de chocolat
7809	Robe de Pâques
7810	Fiole d'eau pure
7811	Restes d'eau pure
7812	Bracelets de manifestation corrompue
7813	Eclat d'eau
7846	Croc de coyote des rochers
7847	Gésier de busard
7848	Fragment d'élémentaire de roche
7866	Récipient thaumaturgique vide
7867	Récipient de sang du dragon
7868	Thieven' Kit
7869	Coffret de Lucius
7870	Coffret thaumartugique
7871	Gage de voleur
7872	Outils de voleur rouillés
7886	Journal non traduit
7887	Les gemmes et le collier récupérés
7888	Collier d'amélioration de Jarkal
7906	Cornes de Nez'ra
7907	Certificat des voleurs
7908	Journal de Klaven Mortwake
7909	Aigue-marine
7910	Rubis étoilé
7911	Minerai de vrai-argent
7912	Pierre solide
7913	Epaulières barbares en fer
7914	Cuirasse barbare en fer
7915	Casque barbare en fer
7916	Bottes barbares en fer
7917	Gants barbares en fer
7918	Epaulières lourdes en mithril
7919	Gantelets lourds en mithril
7920	Jambières en écailles de mithril
7921	Jambières lourdes en mithril
7922	Heaume en plaques d'acier
7923	Clé de la tour défias
7924	Brassards en écailles de mithril
7925	Gants en écailles de mithril
7926	Jambières ornées en mithril
7927	Gants ornés en mithril
7928	Epaulières ornées en mithril
7929	Jambières de guerre orques
7930	Cuirasse lourde en mithril
7931	Camail en mithril
7932	Epaulières en écailles de mithril
7933	Bottes lourdes en mithril
7934	Heaume lourd en mithril
7935	Cuirasse ornée en mithril
7936	Bottes ornées en mithril
7937	Heaume orné en mithril
7938	Gantelets en vrai-argent
7939	Cuirasse en vrai-argent
7941	Hache lourde en mithril
7942	Hache lumineuse bleue
7943	Lame corrompue en mithril
7944	Rapière éblouissante en mithril
7945	Grande masse noire
7946	Marteau runique en mithril
7947	Kriss d'ébène
7948	Ceinturon de Thero-shan
7949	Jambières de Thero-shan
7950	Armure de Thero-shan
7951	Mains de Thero-shan
7952	Bottes de Thero-shan
7953	Masque de Thero-shan
7954	Le Briseur
7955	Claymore en cuivre
7956	Marteau de guerre en bronze
7957	Epée de guerre en bronze
7958	Hache de guerre en bronze
7959	Corruptrice
7960	Championne en vrai-argent
7961	Lame fantôme
7963	Cuirasse en acier
7964	Pierre à aiguiser solide
7965	Caillou solide
7966	Silex à aiguiser solide
7967	Pointe de bouclier en mithril
7968	Trésor des Mers du sud
7969	Eperons en mithril
7970	B.G.A.C.
7971	Perle noire
7972	Ichor de non-mort
7973	Palourde à large bouche
7974	Chair de palourde piquante
7975	Plans : Jambières lourdes en mithril
7976	Plans : Pointe de bouclier en mithril
7977	Plans : Gantelets en écailles de mithril
7978	Plans : Epaulières barbares en fer
7979	Plans : Cuirasse barbare en fer
7980	Plans : Casque barbare en fer
7981	Plans : Bottes barbares en fer
7982	Plans : Gants barbares en fer
7983	Plans : Jambières ornées en mithril
7984	Plans : Gants ornés en mithril
7985	Plans : Epaulières ornées en mithril
7986	Plans : Cuirasse ornée en mithril
7987	Plans : Heaume orné en mithril
7988	Plans : Bottes ornées en mithril
7989	Plans : Eperons en mithril
7990	Plans : Heaume lourd en mithril
7991	Plans : Epaulières en écailles de mithril
7992	Plans : Hache lumineuse bleue
7993	Plans : Rapière éblouissante en mithril
7994	Plans : Jambières de guerre orques
7995	Plans : Brassards en écailles de mithril
7996	Chapeau de pêcheur usé
7997	Masque rouge de Défias
8006	Le Ziggler
8007	Citrine de mana
8008	Rubis de mana
8009	Pierre de puissance Dentrium
8026	Trésor de la famille Garrett
8027	Trésor de Krom Stoutarm
8028	Plans : Marteau runique en mithril
8029	Plans : Lame corrompue en mithril
8030	Plans : Kriss d'ébène
8046	Journal de Kearnen
8047	Champignon magenta
8048	Capturêve d'émeraude
8049	Collier Pin-tordu
8050	Joyau de Tallonkai
8051	Lance-fusée
8052	Pierre de puissance An'Alleum
8053	Source d'énergie en obsidienne
8066	Sifflet de Fizzule
8067	Balle légère fabriquée
8068	Balle lourde fabriquée
8069	Balle dure fabriquée
8070	Bon de récompense
8071	Bâton ardent
8072	Clé de la tour de Silixiz
8073	Cache de mixture altérée de Zanzil
8074	Tête de Gallywix
8075	Pain de route invoqué
8076	Pain au lait invoqué
8077	Eau minérale invoquée
8078	Eau pétillante invoquée
8079	Eau cristalline invoquée
8080	Plastron en plaques légères
8081	Ceinture en plaques légères
8082	Bottes en plaques légères
8083	Brassards en plaques légères
8084	Gantelets en plaques légères
8085	Jambières en plaques légères
8086	Protège-épaules en plaques légères
8087	Echantillon de la mixture altérée de Zanzil
8088	Ceinture de plates
8089	Bottes de plates
8090	Brassards de plates
8091	Gants de plates
8092	Heaume de plates
8093	Jambières de plates
8094	Armure de plates
8095	Huile d'Hinott
8106	Armure hivernale
8107	Bottes hivernales
8108	Brassards hivernaux
8109	Cape hivernale
8110	Gants hivernaux
8111	Mantelet hivernal
8112	Pantalon hivernal
8113	Robe hivernale
8114	Echarpe hivernale
8115	Capuche hivernale
8116	Ceinture héraldique
8117	Bottes héraldiques
8118	Brassards héraldiques
8119	Cuirasse héraldique
8120	Cape héraldique
8121	Gants héraldiques
8122	Couvre-chef héraldique
8123	Jambières héraldiques
8124	Spallières héraldiques
8125	Brassards de myrmidon
8126	Cuirasse de myrmidon
8127	Cape de myrmidon
8128	Gantelets de myrmidon
8129	Ceinturon de myrmidon
8130	Bottes de myrmidon
8131	Heaume de myrmidon
8132	Jambières de myrmidon
8133	Espauliers de myrmidon
8134	Bouclier de myrmidon
8135	Bouclier chromite
8136	Tumeur gargantuesque
8137	Brassards chromites
8138	Pansière chromite
8139	Gantelets chromites
8140	Ceinturon chromite
8141	Jambières chromites
8142	Barbute chromite
8143	Cuissards chromites
8144	Espauliers chromites
8146	Serre cruelle
8147	Petite clé en cuivre
8148	Petite clé en argent
8149	Charme vaudou
8150	Sel de Fonderoc
8151	Flacon de mojo
8152	Flacon de grand mojo
8153	Sauvageonne
8154	Ecaille de scorpide
8155	Sacrifice de Sathrah
8156	Garde-poignets de jouteur
8157	Pansière de jouteur
8158	Gantelets de jouteur
8159	Ceinturon de jouteur
8160	Jambières de jouteur
8161	Visière de jouteur
8162	Cuissards de jouteur
8163	Espauliers de jouteur
8165	Ecaille de dragon usée
8167	Ecaille de tortue
8168	Plume noire
8169	Peau épaisse
8170	Cuir robuste
8171	Peau robuste
8172	Peau épaisse traitée
8173	Renfort d'armure épais
8174	Chapeau de cuir confortable
8175	Tunique de la nuit
8176	Bandeau de la nuit
8177	Epée d'entraînement
8178	Epée d'entraînement
8179	Arc de cadet
8180	Arc de chasse
8181	Carabine de chasse
8182	Carabine à plomb
8183	Arc de précision
8184	Boute-flammes
8185	Jambières en écailles de tortue
8186	Baguette redoutable
8187	Gants en écailles de tortue
8188	Fusil explosif
8189	Cuirasse en écailles de tortue
8190	Epée Hanzo
8191	Casque en écailles de tortue
8192	Epaulières de la nuit
8193	Pantalon de la nuit
8194	Casse-noisettes gobelin
8195	Cape de la nuit
8196	Cimeterre d'ébène
8197	Bottes de la nuit
8198	Brassards en écailles de tortue
8199	Trancheuse de guerre
8200	Robe du grand vaudou
8201	Masque du grand vaudou
8202	Pantalon du grand vaudou
8203	Cuirasse armée du scorpide
8204	Gants armés du scorpide
8205	Brassards armés du scorpide
8206	Jambières armées du scorpide
8207	Epaulières armées du scorpide
8208	Casque armé du scorpide
8209	Bottes armées du scorpide
8210	Epaulières en cuir sauvage
8211	Gilet en cuir sauvage
8212	Jambières en cuir sauvage
8213	Bottes en cuir sauvage
8214	Casque en cuir sauvage
8215	Cape en cuir sauvage
8216	Cape du grand vaudou
8217	Carquois de tir rapide
8218	Giberne en cuir épais
8223	Lame du basilic
8224	Eventreur silithide
8225	Epée de corruption
8226	La Bouchère
8243	Scoubiscuits
8244	Sphère de draenéthyste sans défaut
8245	Tunique impériale rouge
8246	Bottes impériales rouges
8247	Brassards impériaux rouges
8248	Cape impériale rouge
8249	Gants impériaux rouges
8250	Mantelet impérial rouge
8251	Pantalon impérial rouge
8252	Robe impériale rouge
8253	Echarpe impériale rouge
8254	Diadème impérial rouge
8255	Ceinturon en peau de serpent
8256	Bottes en peau de serpent
8257	Brassards en peau de serpent
8258	Armure en peau de serpent
8259	Cape en peau de serpent
8260	Gants en peau de serpent
8261	Casque en peau de serpent
8262	Jambières en peau de serpent
8263	Spallières en peau de serpent
8264	Bracelets de Fort-Ebène
8265	Armure de Fort-Ebène
8266	Cape de Fort-Ebène
8267	Gantelets de Fort-Ebène
8268	Ceinturon de Fort-Ebène
8269	Bottes de Fort-Ebène
8270	Heaume de Fort-Ebène
8271	Jambières de Fort-Ebène
8272	Garde-poignets de Fort-Ebène
8273	Garde-poignets valeureux
8274	Corselet valeureux
8275	Targe de Fort-Ebène
8276	Gantelets valeureux
8277	Ceinturon valeureux
8278	Jambières valeureuses
8279	Heaume valeureux
8280	Cuissards valeureux
8281	Espauliers valeureux
8282	Bouclier valeureux
8283	Armure des arcanes
8284	Bottes des arcanes
8285	Poignets des arcanes
8286	Cape des arcanes
8287	Gants des arcanes
8288	Ailettes des arcanes
8289	Jambières des arcanes
8290	Robe des arcanes
8291	Echarpe des arcanes
8292	Couvre-chef des arcanes
8293	Ceinture de voyageur
8294	Bottes de voyageur
8295	Brassards de voyageur
8296	Pourpoint de voyageur
8297	Cape de voyageur
8298	Gants de voyageur
8299	Casque de voyageur
8300	Jambières de voyageur
8301	Spallières de voyageur
8302	Brassards de héros
8303	Cuirasse de héros
8304	Cape de héros
8305	Gantelets de héros
8306	Ceinture de héros
8307	Bottes de héros
8308	Bandeau de héros
8309	Jambières de héros
8310	Espauliers de héros
8311	Protège-bras d'albâtre en plaques
8312	Cuirasse d'albâtre
8313	Targe de héros
8314	Gantelets d'albâtre en plaques
8315	Ceinturon d'albâtre en plaques
8316	Bottes d'albâtre en plaques
8317	Heaume d'albâtre en plaques
8318	Jambières d'albâtre en plaques
8319	Espauliers d'albâtre en plaques
8320	Bouclier d'albâtre
8343	Bobine de soie lourde
8344	Filières d'argent
8345	Casque tête-de-loup
8346	Gantelets de la mer
8347	Gantelets en écailles de dragon
8348	Casque de feu
8349	Cuirasse de plumes
8350	L'anneau unique
8363	Charme vaudou des chamans
8364	Truite tête-mithril
8365	Truite tête-mithril crue
8366	Truite ballonnée
8367	Cuirasse en écailles de dragon
8368	Peau de loup épaisse
8383	Lettre simple
8384	Patron : Chapeau de cuir confortable
8385	Patron : Gants en écailles de tortue
8386	Patron : Robe du grand vaudou
8387	Patron : Masque du grand vaudou
8388	Patron : Cape de la nuit
8389	Patron : Pantalon du grand vaudou
8390	Patron : Cape du grand vaudou
8391	Joues de Raillecroc
8392	Poumon de sanglier éclaté
8393	Pince de scorpok
8394	Cerveau de basilic
8395	Patron : Cuirasse armée du scorpide
8396	Gésier de vautour
8397	Patron : Brassards armés du scorpide
8398	Patron : Gants armés du scorpide
8399	Patron : Bottes armées du scorpide
8400	Patron : Epaulières armées du scorpide
8401	Patron : Jambières armées du scorpide
8402	Patron : Casque armé du scorpide
8403	Patron : Epaulières en cuir sauvage
8404	Patron : Gilet en cuir sauvage
8405	Patron : Casque en cuir sauvage
8406	Patron : Bottes en cuir sauvage
8407	Patron : Jambières en cuir sauvage
8408	Patron : Cape en cuir sauvage
8409	Patron : Epaulières de la nuit
8410	R.O.I.D.S.
8411	Cocktail de jus de poumon
8412	Poudre de scorpok terrestre
8423	Potion de cortex cérébral
8424	Gomme de gésier
8425	Fiente de perroquet
8426	Grande plume ébouriffée
8427	Carcasse de rat mutilée
8428	Glande de rosée remplie
8429	Glande de rosée éclatée
8430	Glande de rosée vide
8431	Bobine de fil de soie chartreuse
8432	Eau de Mixilpixil
8443	Ornement Gahz'ridian
8444	Clé du bourreau
8463	Ordres du chef de guerre
8483	Outre de Bat-le-désert
8484	Paquet de la Co. des eaux Gadgetzan
8485	Panier à chat (Bombay)
8486	Panier à chat (Cornouailles)
8487	Panier à chat (tigré orange)
8488	Panier à chat (tigré argent)
8489	Panier à chat (chaton blanc)
8490	Panier à chat (Siamois)
8491	Panier à chat (tigré noir)
8492	Cage de perroquet (Macaw ailes vertes)
8493	Tonneau de Weegli
8494	Cage de perroquet (Macaw jacinthe)
8495	Cage de perroquet (Sénégal)
8496	Cage de perroquet (Cockatiel)
8497	Caisse de lapin (patte-blanche)
8498	Minuscule jeune dragonnet d'émeraude
8499	Minuscule jeune dragonnet cramoisi
8500	Grande chouette cornue
8501	Chouette-faucon
8502	Boîte-surprise en bronze
8503	Boîte-surprise lourde en bronze
8504	Boîte-surprise en fer
8505	Boîte-surprise lourde en fer
8506	Boîte-surprise en mithril
8507	Boîte-surprise lourde en mithril
8508	Grand aileron
8523	Trousse d'analyse de terrain
8524	Source d'énergie modèle 4711-FTZ
8525	Commande de Zinge
8526	Tragan violet
8527	Trousse d'analyse de terrain verrouillée
8528	Poudre violette
8529	Elixir Noggenfogger
8543	Champignon sous-marin
8544	Bandage en tisse-mage
8545	Bandage épais en tisse-mage
8546	Puissants sels odorants
8547	Formule : Puissants sels odorants
8548	Bâtonnet divino-matic
8563	Mécanotrotteur rouge
8564	Oeuf d'hippogryphe
8583	Corne du cheval squelette
8584	Fiole de sourcier vide
8585	Fiole de sourcier pleine
8586	Sifflet de raptor rouge tacheté
8587	Morceaux d'insecte Centipaar
8588	Sifflet de raptor émeraude
8589	Ancien sifflet de raptor ivoire
8590	Ancien sifflet de raptor obsidienne
8591	Sifflet de raptor turquoise
8592	Sifflet de raptor violet
8593	Equipement d'analyse de Scrimshank
8594	Rapport d'analyse d'insecte
8595	Mécanotrotteur bleu
8603	Rosée des chardonniers
8623	Balise de détresse OOX-17/TN
8624	Cierge magique rouge
8625	Cierge magique blanc
8626	Cierge magique bleu
8627	Rênes de sabre-de-nuit
8628	Rênes de sabre-de-nuit tacheté
8629	Rênes de sabre-de-nuit rayé
8630	Rênes de tigre du Bengale
8631	Rênes de sabre-de-givre rayé
8632	Rênes de sabre-de-givre tacheté
8633	Rênes de léopard
8643	Oeuf extraordinaire
8644	Bel oeuf
8645	Oeuf ordinaire
8646	Oeuf pourri
8647	Caisse d'oeufs
8663	Insigne en mithril
8683	Pomme fraîche de Clara
8684	Houle au miel des Hinterlands
8685	Livraison de Houle de Dran
8686	Pendentif en mithril
8687	Description scellée du visiteur de Thredd
8703	Chevalière d'expertise
8704	Balise de détresse OOX-09/HL
8705	Balise de détresse OOX-22/FE
8707	Ecaille électrique de Gahz'rilla
8708	Marteau d'expertise
8723	Tête de Caliph Dard-de-scorpide
8724	Secret de Rin'ji
8743	Livre de Marque du fauve
8744	Livre de Colère
8745	Livre de Toucher guérisseur
8746	Capuche entrelacée
8747	Casque en cuir durci
8748	Camail doublentin
8749	Chapeau en crochet
8750	Casque en cuir épais
8751	Camail en anneaux doubliers
8752	Diadème en écailles laminées
8753	Casque en cuir lisse
8754	Capuche sergée
8755	Heaume en plaques légères
8756	Livre de Rétablissement II
8757	Livre de Feu stellaire
8758	Livre de Délivrance de la malédiction
8759	Livre de Rétablissement III
8760	Livre d'Abolir poison
8761	Livre de Feu stellaire II
8762	Livre de Récupération V
8763	Livre d'Eclat lunaire V
8764	Livre de Lucioles II
8765	Livre de Rétablissement IV
8766	Soupe de rosée matinale
8768	Livre de Feu stellaire III
8769	Livre d'Epines IV
8770	Livre d'Eclat lunaire VI
8771	Livre de Récupération VI
8772	Livre de Rétablissement V
8773	Livre de Sarments V
8774	Livre de Toucher guérisseur VII
8775	Livre de Tranquillité II
8776	Livre de Marque du fauve
8777	Livre d'Eclat lunaire IX
8778	Livre de Récupération VII
8779	Livre de Lucioles III
8780	Livre de Feu stellaire V
8781	Livre de Rétablissement VII
8782	Livre d'Epines V
8783	Livre de Toucher guérisseur IX
8784	Livre de Colère VII
8785	Livre de Récupération IX
8786	Livre de Tranquillité III
8787	Livre d'Apaiser les animaux
8788	Livre d'Apaiser les animaux II
8789	Livre d'Apaiser les animaux III
8790	Livre de Lucioles IV
8791	Livre de Rétablissement VIII
8792	Livre d'Epines VI
8793	Livre de Colère VIII
8794	Livre de Toucher guérisseur X
8795	Livre de Sarments VI
8796	Livre d'Eclat lunaire X
8797	Livre de Récupération X
8798	Livre de Feu stellaire VI
8799	Livre de Marque du fauve VII
8800	Livre de Rétablissement IX
8801	Livre de Tranquillité IV
8802	Tome d'Intelligence des arcanes
8803	Tome de Boule de feu
8804	Tome d'Explosion des arcanes
8805	Tome de Détection de la magie
8806	Tome de Délivrance de la malédiction inférieure
8807	Tome d'Amplification de la magie
8808	Tome de Bouclier de mana
8809	Tome de Sommeil
8810	Tome de Sommeil II
8811	Tome de Brûlure
8812	Tome d'Explosion des arcanes II
8813	Tome d'Atténuation de la magie II
8814	Tome de Boule de feu V
8815	Tome de Cône de froid
8816	Tome d'Eclair de givre V
8818	Tome de Bouclier de mana II
8819	Tome de Brûlure II
8820	Tome de Gardien de feu II
8821	Tome d'Amplification de la magie II
8822	Tome d'Explosion des arcanes III
8823	Tome de Trait de feu IV
8824	Tome de Boule de feu VI
8825	Tome de Gardien de givre III
8826	Tome de Projectiles des arcanes IV
8827	Elixir de Marche sur l'eau
8828	Tome d'Eclair de givre VI
8829	Tome de Cône de froid II
8830	Tome de Brûlure III
8831	Lotus pourpre
8832	Tome de Blizzard II
8833	Tome de Bouclier de mana III
8834	Tome d'Atténuation de la magie III
8835	Tome de Boule de feu VII
8836	Larmes d'Arthas
8837	Tome d'Explosion des arcanes V
8838	Soleillette
8839	Aveuglette
8840	Tome of Conjure Mana Gem II
8841	Tome de Trait de feu V
8842	Tome d'Eclair de givre VII
8843	Tome de Gardien de feu III
8844	Tome de Sommeil III
8845	Champignon fantôme
8846	Gromsang
8847	Tome de Brûlure V
8848	Tome de Choc de flammes IV
8849	Tome de Projectiles des arcanes V
8850	Tome d'Invocation d'eau V
8851	Tome de Boule de feu VIII
8852	Tome d'Intelligence des arcanes IV
8853	Tome d'Invocation de nourriture V
8854	Tome de Cône de froid III
8855	Tome d'Amplification de la magie III
8856	Tome d'Eclair de givre VIII
8857	Tome de Blizzard IV
8858	Tome de Bouclier de mana IV
8859	Tome de Trait de feu VI
8860	Tome de Boule de feu IX
8861	Tome d'Invoquer Gemme de mana III
8862	Tome de Projectiles des arcanes VI
8863	Tome d'Atténuation de la magie IV
8864	Tome de Choc de flammes V
8865	Tome d'Armure de glace II
8866	Tome de Cône de froid IV
8867	Tome d'Eclair de givre IX
8868	Tome d'Invocation d'eau VI
8869	Tome de Gardien de feu IV
8870	Tome d'Invisibilité supérieure
8871	Tome d'Invocation de nourriture VI
8872	Tome de Blizzard V
8873	Tome de Bouclier de mana V
8874	Tome de Brûlure VI
8875	Tome de Gardien de givre IV
8876	Tome de Gardien de givre II
8877	Tome de Boule de feu X
8878	Tome de Trait de feu VII
8879	Tome de Nova de givre IV
8880	Tome d'Explosion des arcanes VI
8881	Tome de Déverrouillage de Khadgar
8882	Tome d'Amplification de la magie IV
8883	Tome d'Intelligence des arcanes V
8884	Tome d'Eclair de givre X
8885	Tome de Projectiles des arcanes VII
8886	Tome de Choc de flammes VI
8887	Tome de Brûlure VII
8888	Tome de Cône de froid V
8889	Tome of Conjure Mana Gem IV
8890	Tome de Boule de feu XI
8891	Tome d'Armure de glace IV
8892	Tome d'Invocation d'eau VII
8893	Tome de Sommeil IV
8894	Tome d'Atténuation de la magie V
8895	Tome de Blizzard VI
8896	Tome de Bouclier de mana VI
8897	Tome de Gardien de feu V
8898	Tome d'Explosion des arcanes IV
8899	Tome de Brûlure IV
8900	Livre de Sarments IV
8901	Livre de Toucher guérisseur VIII
8902	Livre de Marque du fauve
8903	Livre d'Eclat lunaire VII
8904	Livre d'Eclat lunaire VIII
8905	Livre de Rétablissement VI
8906	Livre de Récupération VIII
8907	Livre de Feu stellaire IV
8909	Libram : Frappe sacrée II
8910	Libram : Imposition des mains
8911	Libram : Poing de la Justice
8912	Libram : Inquisition
8913	Libram : Frappe sacrée III
8914	Libram : Inquisition II
8915	Libram : Frappe sacrée IV
8916	Libram : Poing de la Justice II
8917	Libram : Imposition des mains II
8918	Libram : Sceau de protection II
8919	Libram : Frappe sacrée V
8920	Libram : Inquisition III
8921	Libram : Poing de la Justice III
8922	Libram : Frappe sacrée VI
8923	Essence d'agonie
8924	Poussière de détérioration
8925	Fiole de cristal
8926	Poison instantané IV
8927	Poison instantané V
8928	Poison instantané VI
8929	Libram : Exorcisme IV
8930	Libram : Sceau de piété IV
8931	Libram : Inquisition IV
8932	Emmental d'Alterac
8933	Libram : Lumière sacrée VI
8934	Libram : Frappe sacrée VII
8935	Libram : Jugement II
8936	Libram : Sceau de colère II
8937	Libram : Imposition des mains III
8938	Libram : Renvoi des morts-vivants III
8939	Libram : Exorcisme V
8940	Libram : Poing de la Justice IV
8941	Libram : Lumière sacrée VIII
8942	Libram : Sceau de piété V
8943	Libram : Frappe sacrée VIII
8944	Libram : Inquisition V
8945	Libram : Jugement III
8947	Libram : Exorcisme VI
8948	Cèpe des rois séché
8949	Elixir d'Agilité
8950	Tarte aux cerises maison
8951	Elixir de défense supérieure
8952	Poulet rôti
8953	Bananes frites
8954	Codex de Mot sacré : Robustesse
8955	Codex d'Oubli
8956	Huile d'immolation
8957	Flétan épineux
8958	Codex d'Attaque mentale
8959	Flétan épineux cru
8960	Codex de Guérison des maladies
8961	Codex de Cri psychique
8962	Codex d'Attaque mentale II
8963	Codex d'Apaisement
8964	Codex de Soins rapides
8965	Codex d'Oubli II
8966	Codex d'Entraves des morts-vivants
8967	Codex d'Attaque mentale III
8968	Codex de Brûlure de mana
8969	Codex de Soins rapides II
8971	Codex de Cri psychique II
8972	Codex d'Attaque mentale IV
8973	Peau de yéti épaisse
8974	Codex de Contrôle mental
8975	Codex d'Oubli III
8976	Codex d'Abolir maladie
8977	Codex de Brûlure de mana II
8978	Codex de Soins rapides III
8980	Codex d'Attaque mentale V
8981	Codex d'Apaisement II
8983	Codex de Soins rapides IV
8984	Poison mortel III
8985	Poison mortel IV
8986	Codex d'Entraves des morts-vivants II
8987	Codex de Protection contre le Sacré II
8988	Codex de Brûlure de mana III
8989	Codex d'Oubli IV
8990	Codex d'Attaque mentale VI
8991	Codex de Feu intérieur IV
8992	Codex de Cri psychique III
8993	Codex de Protection contre l’ombre II
8994	Codex de Mot de l’ombre : Douleur VI
8995	Codex de Mot sacré : Bouclier VII
8996	Codex de Résurrection II
8997	Codex de Contrôle mental II
8998	Codex de Vision télépathique II
8999	Codex de Soins rapides V
9000	Codex de Rénovation VI
9001	Codex de Soins supérieurs II
9002	Codex d'Attaque mentale VII
9003	Codex de Châtiment sacré VI
9004	Codex de Mot sacré : Robustesse V
9005	Codex de Brûlure de mana IV
9006	Codex de Mot sacré : Bouclier VIII
9007	Codex d'Oubli V
9008	Codex de Prière de soins II
9009	Codex de Feu intérieur V
9010	Codex de Soins rapides VI
9011	Codex de Mot de l’ombre : Douleur VII
9012	Codex de Rénovation VIII
9013	Codex de Soins supérieurs III
9014	Codex d'Apaisement III
9015	Codex d'Attaque mentale VIII
9016	Codex de Châtiment sacré VIII
9017	Codex de Protection contre le Sacré III
9018	Codex de Mot sacré : Bouclier IX
9019	Codex de Rénovation IX
9020	Codex de Cri psychique IV
9021	Codex de Brûlure de mana V
9022	Codex de Soins rapides VII
9023	Codex de Protection contre l’ombre III
9024	Codex de Contrôle mental III
9025	Codex de Soins supérieurs IV
9026	Codex de Résurrection IV
9027	Codex d'Attaque mentale IX
9028	Codex de Mot de l’ombre : Douleur VIII
9029	Codex d'Oubli VI
9030	Potion de restauration
9031	Codex d'Entraves des morts-vivants III
9032	Codex de Prière de soins IV
9033	Codex de Feu intérieur VI
9034	Codex de Mot sacré : Robustesse VI
9035	Codex de Mot sacré : Bouclier X
9036	Potion de résistance à la magie
9037	Tablette d'Arme Croque-roc
9039	Tablette d'Horion de terre
9040	Tablette de Vague de soins II
9041	Tablette de Totem de lien terrestre
9043	Tablette de Totem Griffe de pierre
9044	Tablette d'Horion de terre II
9046	Tablette de Totem de Force de la Terre
9047	Tablette d'Horion de flammes
9048	Tablette de Renaissance
9049	Tablette de Totem Nova de feu
9050	Tablette de Vague de soins III
9051	Tablette d'Horion de terre III
9052	Tablette de Totem Peau de pierre II
9053	Tablette d'Arme Croque-roc II
9054	Tablette d'Horion de flammes II
9055	Tablette de Totem Griffe de pierre II
9056	Tablette de Vague de soins IV
9057	Tablette d'Arme de givre
9058	Tablette d'Horion de givre
9059	Tablette de Langue de feu
9060	Cylindre damasquiné en mithril
9061	Carburant de fusée des gobelins
9062	Tablette de Guérison des maladies
9063	Tablette de Totem de Purification du poison
9064	Tablette de Langue de feu II
9065	Tablette de Totem Nova de feu II
9066	Tablette de Totem de résistance au Givre
9067	Tablette de Totem de Force de la Terre II
9068	Tablette de Totem Peau de pierre III
9069	Tablette d'Horion de terre IV
9070	Tablette de Vague de soins V
9071	Tablette de Totem de mana
9072	Tablette de Totem Langue de feu
9073	Tablette d'arme furie-des-vents
9074	Tablette d'Horion de flammes III
9075	Tablette de Totem de résistance au Feu
9076	Tablette de Totem de Magma
9077	Tablette de Totem Griffe de pierre III
9078	Tablette de Totem de Glèbe
9079	Tablette d'Horion de foudre
9080	Tablette de Totem de résistance à la Nature
9081	Tablette de Totem guérisseur II
9082	Tablette d'Arme Croque-roc III
9083	Tablette de Totem incendiaire III
9084	Tablette de Totem Furie-des-vents
9085	Tablette de Totem Nova de feu III
9086	Tablette de Vague de soins VI
9087	Tablette d'Expiation II
9088	Don d'Arthas
9089	Tablette d'Horion de givre II
9090	Tablette d'Arme de givre II
9091	Tablette de Totem Peau de pierre IV
9092	Tablette de Totem sentinelle
9093	Tablette de Totem de mana II
9094	Tablette de Langue de feu III
9095	Tablette d'Horion de terre V
9096	Tablette de Totem de Purification des maladies
9097	Tablette de Totem de Magma II
9098	Tablette de Totem de Force de la Terre III
9099	Tablette de Totem Griffe de pierre IV
9100	Tablette de Bouclier de foudre V
9101	Tablette d'arme furie-des-vents II
9102	Tablette de Chaîne d'éclairs II
9103	Tablette de Totem guérisseur III
9104	Tablette de Totem incendiaire IV
9105	Tablette de Vague de soins VII
9123	Tablette d'Eclair VI
9124	Tablette d'Horion de foudre II
9125	Tablette de Totem de Grâce aérienne
9126	Tablette de Totem Langue de feu II
9127	Tablette de Totem de résistance au Feu II
9128	Tablette de Totem Nova de feu IV
9129	Tablette d'Arme Croque-roc IV
9130	Tablette de Totem de résistance à la Nature II
9131	Tablette de Totem Peau de pierre V
9132	Tablette d'Eclair de lave VI
9133	Tablette de Salve de guérison II
9134	Tablette de Totem Furie-des-vents II
9135	Tablette d'Horion de givre III
9136	Tablette de Totem de mana III
9137	Tablette de Bouclier de foudre VI
9138	Tablette de Totem de Magma III
9139	Tablette d'Arme de givre III
9140	Tablette de Chaîne d'éclairs III
9141	Tablette de Totem Griffe de pierre V
9142	Tablette d'Horion de terre VI
9143	Tablette de Vague de soins VIII
9144	Potion de sauvageonne
9145	Tablette d'Eclair VII
9146	Tablette de Totem incendiaire V
9147	Tablette de Totem guérisseur IV
9148	Tablette de Langue de feu IV
9149	Pierre philosophale
9150	Tablette de Totem de Force de la Terre IV
9151	Tablette d'Horion de flammes V
9152	Tablette de Totem Nova de feu V
9153	Plan de plateforme
9154	Elixir de détection des morts-vivants
9155	Elixir des arcanes
9156	Tablette d'Eclair de lave VII
9157	Tablette de Salve de guérison III
9158	Tablette de Totem de résistance au Givre III
9159	Tablette d'Horion de foudre III
9160	Tablette d'arme furie-des-vents III
9161	Tablette de Totem Peau de pierre VI
9162	Tablette de Bouclier de foudre VII
9164	Tablette de Totem de Grâce aérienne II
9165	Tablette de Totem Langue de feu III
9166	Tablette de Totem de mana IV
9167	Tablette de Chaîne d'éclairs IV
9168	Tablette de Vague de soins IX
9169	Tablette d'Eclair VIII
9170	Tablette de Totem de résistance au Feu III
9171	Tablette de Totem de Magma IV
9172	Potion d'invisibilité
9173	Transpondeur gobelin
9174	Tablette d'Horion de givre IV
9175	Tablette d'Arme Croque-roc V
9176	Tablette de Totem Griffe de pierre VI
9177	Tablette d'Horion de terre VII
9178	Tablette de Totem de résistance à la Nature III
9179	Elixir d'Intelligence supérieure
9180	Tablette de Totem Furie-des-vents III
9181	Tablette de Totem guérisseur V
9182	Tablette de Totem incendiaire VI
9183	Tablette de Salve de guérison
9184	Tablette d'Horion de flammes IV
9185	Tablette de Totem de résistance au Givre II
9186	Poison de distraction mentale III
9187	Elixir d'Agilité supérieure
9188	Tablette de Totem incendiaire II
9189	Cloche de Shay
9190	Grimoire d'Immolation
9191	Grimoire de Malédiction de faiblesse
9192	Grimoire de Corruption
9193	Grimoire de Connexion
9194	Grimoire de Malédiction d'agonie
9195	Grimoire de Siphon d'âme
9197	Elixir de Vision de rêve
9198	Grimoire de Captation de vie
9199	Grimoire de Malédiction de témérité
9200	Grimoire de Malédiction de faiblesse II
9201	Grimoire de Corruption II
9202	Grimoire de Connexion II
9203	Grimoire du Rituel d'invocation
9204	Grimoire de Captation de vie II
9205	Grimoire de Malédiction d'agonie II
9206	Elixir des géants
9207	Grimoire de Créer Pierre de sang II
9208	Grimoire de Siphon d'âme II
9209	Grimoire de Malédiction de faiblesse III
9210	Teinture fantôme
9211	Grimoire de Malédiction de témérité II
9212	Grimoire de Trait de l’ombre V
9214	Grimoire d'Inferno
9215	Grimoire de Captation de vie III
9216	Grimoire de Corruption III
9217	Grimoire de Connexion III
9218	Grimoire d'Asservir démon
9219	Grimoire de Flammes infernales
9221	Grimoire de Malédiction d'agonie III
9222	Grimoire de Malédiction des éléments
9223	Grimoire de Malédiction de faiblesse IV
9224	Elixir de Tueur de démons
9225	Grimoire de Trait de l’ombre VI
9226	Grimoire de Captation de vie IV
9227	Grimoire de Siphon d'âme III
9228	Grimoire de Créer Pierre de sang III
9229	Grimoire de Siphon de vie IV
9230	Grimoire de Malédiction de témérité III
9231	Grimoire de Corruption IV
9233	Elixir de Détection des démons
9234	Tiare des abysses
9235	Lettre de Pratt
9236	Lettre de Jangdor
9237	Crinière de gnoll Griffebois
9238	Carapace de scarabée intacte
9240	Marteau de Zul'Farrak
9241	Maillet sacré
9242	Tablette antique
9243	Coeur flétri
9244	Chargement de Stoley
9245	Bouteille de Stoley
9246	Tête de Barbe-en-feu
9247	Ecaille de naga Hainecrête
9248	Relique mystérieuse
9249	Clé du capitaine
9250	Horaires du navire
9251	Fragment supérieur de la carte
9252	Fragment inférieur de la carte
9253	Fragment central de la carte
9254	Carte au trésor de Cuergo
9255	Essence Lahassa
9256	Essence Imbel
9257	Essence Samha
9258	Essence Byltan
9259	Collier tribal troll
9260	Rhum explosif
9261	Minerai de plomb
9262	Vitriol noir
9263	Bâton de Troyas
9264	Elixir de Puissance de l'ombre
9265	Trésor caché de Cuergo
9266	Plans de bataille des Griffebois
9275	Clé de Cuergo
9276	Coffre de pirate
9277	Mémoire de Techbot
9278	Cerveau mécanique
9279	Carte perforée blanche
9280	Carte perforée jaune
9281	Carte perforée rouge
9282	Carte perforée bleue
9283	Flasque plombée vide
9284	Flasque plombée lourde remplie
9285	Protège-bras de guerre en plaques
9286	Armure de plaques de guerre
9287	Gantelets de guerre en plaques
9288	Ceinturon de guerre en plaques
9289	Bottes de guerre en plaques
9290	Heaume de guerre en plaques
9291	Jambières de guerre en plaques
9292	Espauliers de guerre en plaques
9293	Recette : Potion de résistance à la magie
9294	Recette : Potion de sauvageonne
9295	Recette : Potion d'invisibilité
9296	Recette : Don d'Arthas
9297	Recette : Elixir de Vision de rêve
9298	Recette : Elixir des géants
9299	Combinaison du coffre de Thermaplugg
9300	Recette : Elixir de Tueur de démons
9301	Recette : Elixir de Puissance de l'ombre
9302	Recette : Teinture fantôme
9303	Recette : Pierre philosophale
9304	Recette : Transmutation du fer en or
9305	Recette : Transmutation du mithril en vrai-argent
9306	Bâton d'Equinex
9307	Une Pierre étincelante
9308	Objet sali
9309	Entrailles mécaniques de robot
9311	Imprimerie par défaut
9312	Fusée bleue
9313	Fusée verte
9314	Bouquet rouge
9315	Fusée "rose jaune"
9316	Carte perforée prismatique
9317	Fusée bleu blanc rouge
9318	Fusée rouge
9319	Pique de Nimboya préparée
9320	Crâne de Witherbark
9321	Bouteille de venin
9322	Glande à venin intacte
9323	Parchemin de Gadrin
9324	Venin de Shadra
9325	Un petit Bâton
9326	Anneau sali
9327	Carte d'accès aux données niveau DELTA
9328	Le Preneur d'images FX
9329	Une courte note
9330	Photo de Gammerita
9331	Feralas : une histoire
9332	Bandages incrustés
9333	Collier d'argent terni
9334	Pot craquelé
9335	Gourdin brisé en obsidienne
9336	Défense de troll plaquée or
9355	Boucle d'oreille
9356	Une jambe de bois
9357	Un squelette de perroquet
9358	Un bandeau de tête
9359	Lampe des mers du Sud
9360	Or de Cuergo
9361	Or de Cuergo avec un ver
9362	Anneau d'or brillant
9363	Paquet-cadeau du Décapeur
9364	Flasque plombée lourde
9365	Matière radioactive à haut potentiel
9366	Gantelets en écailles dorées
9367	Plans : Gantelets en écailles dorées
9368	Chevalière de Jer'kai
9369	Aile iridescente de fée fléchetteuse
9370	Parchemin Gordunni
9371	Orbe Gordunni
9372	Sul'thraze la Flagellante
9375	Casque de mineur d'or expert
9378	Hache de mine de Shovelphlange
9379	Sang'thraze le Déflecteur
9380	Jang'thraze le Protecteur
9381	Bâtonnet terrestre
9382	Bottes solides du mineur
9383	Fendeuse en obsidienne
9384	Kriss cavepierre
9385	Protectrice archaïque
9386	Torche d'excavateur
9387	Bottes de Revelosh
9388	Garde-bras de Revelosh
9389	Spallières de Revelosh
9390	Gants de Revelosh
9391	La Tunneleuse
9392	Lame recuite
9393	Balise d'espoir
9394	Casque viking à cornes
9395	Anciens gants
9396	Cuissards du coffre
9397	Cape d'énergie
9398	Bottes de course usées
9399	Flèche de précision
9400	Arc court de Baelog
9401	Sabre nordique
9402	Kilt terrestre
9403	Bouclier viking endommagé
9404	Bouclier polyvalent d'Olaf
9405	Ceinturon de force de golem
9406	Fers du vent des cimes
9407	Pantalon Stoneweaver
9408	Bâton ferré
9409	Brassards d'Ironaya
9410	Poings de la combe
9411	Espauliers Rockshard
9412	Crache-flammes de Galgann
9413	Frappe-roche
9414	Jambières en cuir huilé
9415	Habit tribal de Grimlok
9416	Pique de Grimlok
9417	Amulette archaïque
9418	Déchireuse
9419	Marteau de feu de Galgann
9420	Casque colonial d'aventurier
9421	Pierre de soins majeure
9422	Fusil-crotale ombreforge
9423	Fracasse-vite
9424	Epée Ginn-su
9425	Pendule de damnation
9426	Arc monolithique
9427	Brise-os cavepierre
9428	Poignets déterrés
9429	Casque de mineur de fond
9430	Spallières d'un autre temps
9431	Fez pontifical
9432	Brassards du crâne en plaques
9433	Couvre-bras oubliés
9434	Grande tenue élémentaire
9435	Gantelets d'os réticulés
9436	Colis de Faranell
9437	Echantillon de basilic non testé
9438	Echantillon de scorpide acceptable
9439	Echantillon de hyène non testé
9440	Echantillon de basilic acceptable
9441	Echantillon de hyène acceptable
9442	Echantillon de scorpide non testé
9443	Echantillon de monstre utilisé
9444	Bouclier processeur de Techbot
9445	Pattes de Grubbis
9446	Jambe de l'électrocuteur
9447	Boulon de l'électrocuteur
9448	Chiffon graisseux de mécano-tank
9449	Roueur manuel
9450	Bottes d'opération gnomebot
9451	Eau bouillonnante
9452	Hydrocane
9453	Vengeresse empoisonnée
9454	Botillons acides
9455	Crispins d'émissaire
9456	Crache-verre
9457	Sceptre diplomatique royal
9458	Noyau central de Thermaplugg
9459	Bras gauche de Thermojoncteur
9460	Corne de Totem sinistre
9461	Boulon chargé
9462	Caisse de cornes de Totem sinistre
9463	Cobalt Gordunni
9465	Surpiolet 5000
9466	Pelle d'Orwin
9467	Croc de Gahz'rilla
9468	Plume de Bec-tranchant
9469	Broigne de Gahz'rilla
9470	Masque du grand mojo
9471	Médaillon de Nekrum
9472	Clé de Maléficia
9473	Peau porte-guigne
9474	Kilt porte-guigne
9475	Pique diabolique
9476	Grands méchants espauliers
9477	Massacreur du chef
9478	Refendeuse
9479	Etreinte du lycan
9480	Arrache-yeux
9481	Le Minotaure
9482	Canne du sorcier-docteur
9483	Incinérateur flamboyant
9484	Jambières Spellshock
9485	Vibrolame
9486	Hache de guerre renforcée
9487	Super-fusil high-tech
9488	Marteau oscillant
9489	Glacificateur gyromatique
9490	Trancheuse bidulotronique
9491	Gants de l'as des as
9492	Réactivateur de gigaflux électromagnétique
9507	Caisse soigneusement empaquetée
9508	Salopette de mécabâtisseur
9509	Jambières pétrolifères
9510	Botillons des cavernes
9511	Scalpel de Saigneur
9512	Cape de métal-noir
9513	Bâton de Ley
9514	Bâton des arcanes
9515	Tunique du Néant
9516	Chemisette du noeud astral
9517	Bâton céleste
9518	Presse-boue
9519	Bottes de Durtfeet
9520	Tueuse muette
9521	Tranche-tête
9522	Cercle de pierres alimenté
9523	Agent durcissant troll
9527	Bâtonnet d'altération
9528	Coeur noir d'Edana
9529	Kit d'équipement de guerrier interne N25
9530	Cor de Serrehaine
9531	Espauliers de schiste précieux
9532	Kit d'équipement de Guerrier interne N30
9533	Anneau de la fraternité des maçons
9534	Couvre-chef de la guilde des ingénieurs
9535	Brassards soudés
9536	Mantelet Aile-de-fée
9537	Boîte soigneusement empaquetée
9538	Anneau d'or de Talvash
9539	Boîte de rations
9540	Boîte de sorts
9541	Boîte de fournitures
9542	Lettre simple
9543	Rune simple
9544	Note de service simple
9545	Sceau simple
9546	Parchemin simple
9547	Note simple
9548	Lettre bénie
9550	Rune codée
9551	Sceau codé
9552	Note runique
9553	Parchemin gravé
9554	Tablette codée
9555	Lettre codée
9556	Rune bénie
9557	Sceau béni
9558	Note de service codée
9559	Parchemin codé
9560	Parchemin codé
9561	Tablette bénie
9562	Tablette runique
9563	Rune consacrée
9564	Tablette gravée
9565	Note gravée
9566	Rune gravée
9567	Sceau gravé
9568	Parchemin runique
9569	Parchemin béni
9570	Lettre consacrée
9571	Lettre glyphée
9572	<UNUSED> Glyphic Rune
9573	Note de service glyphée
9574	Parchemin glyphé
9575	Tablette glyphée
9576	Lettre contaminée
9577	Note de service contaminée
9578	Rouleau contaminé
9579	Parchemin contaminé
9580	Sceau verdoyant
9581	Note verdoyante
9587	Sac spirituel
9588	Anneau d'or de Nogg
9589	Minerais incrustés
9590	Bûches fendues
9591	Tendon résistant
9592	Fragments métalliques
9593	Tréant miniaturisé
9594	Indomptable miniaturisé
9595	Hippogryphe miniaturisé
9596	Dragon féérique miniaturisé
9597	Géant des montagnes miniaturisé
9598	Robe du dormeur
9599	Jambières en mailles d'écorce
9600	Chausses lacées
9601	Bottes fourrées
9602	Lame Brushwood
9603	Bâton Gritroot
9604	Marteau du mécanicien
9605	Cape de réparateur
9606	Récipient de tréant miniaturisé
9607	Bastion de Stormwind
9608	Outil de désarmement de Shoni
9609	Mitaines de Shilly
9618	Récipient d'Indomptable miniaturisé
9619	Récipient d'hippogryphe miniaturisé
9620	Récipient de dragon féérique miniaturisé
9621	Récipient de géant des montagnes miniaturisé
9622	Anneau Reedknot
9623	Robe civinade
9624	Chausses du coureur
9625	Jambières à double renfort
9626	Pourfendeuse naine
9627	Lanterne de la Ligue des Explorateurs
9628	Poche d'herbes de Neeru
9629	Une tête réduite
9630	Bottes artisanales de Pratt
9631	Gants artisanaux de Pratt
9632	Gants artisanaux de Jangdor
9633	Bottes artisanales de Jangdor
9634	Gants de manipulation habile
9635	Cape de maître apothicaire
9636	Echarpe de bretteur
9637	Bottes Shinkicker
9638	Crispins chéloniens
9639	La main d'Antu'sul
9640	Poignes de fer
9641	Amulette vampire
9642	Anneau de la grande tortue
9643	Déflecteur optomatique
9644	Minuteur thermostatique
9645	Bottes d'inventeur gnome
9646	Bottes engloutissantes gnomes
9647	Expérience de vol ratée
9648	Serviette en cotte de mailles
9649	Habit de faveur royale
9650	Plastron de la garde d'honneur
9651	Marteau-tempête des chevaucheurs de gryphon
9652	Jambières des chevaucheurs de gryphon
9653	Lunettes de sprinter
9654	Bâton de flamboyance
9655	Anneau de concentration
9656	Poignes de granit
9657	Cordelière de la charmille
9658	Bottes des Maharishi
9660	Cape d'astronome
9661	Barrière naturelle
9662	Bottes Rushridge
9663	Plastron du cavalier de l'aube
9664	Casque de sentinelle
9665	Gants du cimier ailé
9666	Ceinturon Forte-corne
9678	Castagneur de Tok'kar
9679	Découpeur de Tok'kar
9680	Perforeuse de Tok'kar
9681	Pattes de roi clampant grillées
9682	Ceinture du cuistot en cuir
9683	Force du tréant
9684	Force de l'hippogryphe
9685	Volonté du géant des montagnes
9686	Esprit du dragon féérique
9687	Ceinture de lutteur
9698	Gants de clairvoyance
9699	Cape de la garnison
9703	Cape brûlée
9704	Gants de voleur de bétail
9705	Lacet de Tharg
9706	Bouclier de Tharg
9718	Lame des héros reforgée
9719	Lame des héros brisée
9738	Gemme de Cobrahn
9739	Gemme d'Anacondra
9740	Gemme de Pythas
9741	Gemme de Serpentis
9742	Corde simple
9743	Chaussures simples
9744	Poignets simples
9745	Cape simple
9746	Gants simples
9747	Pantalon simple
9748	Robe simple
9749	Chemisette simple
9750	Echarpe de gitan
9751	Sandales de gitan
9752	Poignets de gitan
9753	Targe de gitan
9754	Cape de gitan
9755	Gants de gitan
9756	Pantalon de gitan
9757	Tunique de gitan
9758	Ceinture de cadet
9759	Bottes de cadet
9760	Brassards de cadet
9761	Cape de cadet
9762	Gantelets de cadet
9763	Jambières de cadet
9764	Bouclier de cadet
9765	Broigne de cadet
9766	Echarpe en tisse-vert
9767	Sandales en tisse-vert
9768	Brassards en tisse-vert
9769	Branche en tisse-vert
9770	Cape en tisse-vert
9771	Gants en tisse-vert
9772	Pantalon en tisse-vert
9773	Robe en tisse-vert
9774	Gilet en tisse-vert
9775	Cordelière de bandit
9776	Bottes de bandit
9777	Brassards de bandit
9778	Targe de bandit
9779	Cape de bandit
9780	Gants de bandit
9781	Pantalon de bandit
9782	Harnais de bandit
9783	Plastron d'écumeur
9784	Bottes d'écumeur
9785	Brassards d'écumeur
9786	Cape d'écumeur
9787	Gantelets d'écumeur
9788	Ceinture d'écumeur
9789	Cuissards d'écumeur
9790	Bouclier d'écumeur
9791	Tunique en étoffe de lierre tressé
9792	Bottes en étoffe de lierre tressé
9793	Bracelets en étoffe de lierre tressé
9794	Cape en étoffe de lierre tressé
9795	Gants en étoffe de lierre tressé
9796	Mantelet en étoffe de lierre tressé
9797	Pantalon en étoffe de lierre tressé
9798	Robe en étoffe de lierre tressé
9799	Echarpe en étoffe de lierre tressé
9800	Orbe sylvestre
9801	Ceinture excellente
9802	Bottes excellente
9803	Brassards excellents
9804	Targe excellente
9805	Cape excellente
9806	Gants excellents
9807	Epaulières excellentes
9808	Jambières excellentes
9809	Tunique excellente
9810	Bottes fortifiées
9811	Brassards fortifiés
9812	Cape fortifiée
9813	Gantelets fortifiés
9814	Ceinture fortifiée
9815	Jambières fortifiées
9816	Bouclier fortifié
9817	Spallières fortifiées
9818	Cotte d'anneaux fortifiée
9819	Tunique solide
9820	Bottes solides
9821	Brassards solides
9822	Cape solide
9823	Gants solides
9824	Epaulières solides
9825	Pantalon solide
9826	Robe solide
9827	Ceinture en cuir écaillé
9828	Bottes en cuir écaillé
9829	Brassards en cuir écaillé
9830	Bouclier écaillé
9831	Cape en cuir écaillé
9832	Gants en cuir écaillé
9833	Jambières en cuir écaillé
9834	Epaulières en cuir écaillé
9835	Tunique en cuir écaillé
9836	Armure cerclée
9837	Brassards cerclés
9838	Cape cerclée
9839	Gantelets cerclés
9840	Ceinturon cerclé
9841	Jambières cerclées
9842	Espauliers cerclés
9843	Bouclier cerclé
9844	Gilet d'invocateur
9845	Chaussures d'invocateur
9846	Brassards d'invocateur
9847	Cape d'invocateur
9848	Gants d'invocateur
9849	Chaperon d'invocateur
9850	Mantelet d'invocateur
9851	Chausses d'invocateur
9852	Robe d'invocateur
9853	Cordelière d'invocateur
9854	Pourpoint d'archer
9855	Ceinture d'archer
9856	Bottes d'archer
9857	Brassards d'archer
9858	Targe d'archer
9859	Coiffe d'archer
9860	Cape d'archer
9861	Gants d'archer
9862	Pantalon d'archer
9863	Protège-épaules d'archer
9864	Bottes de renégat
9865	Brassards de renégat
9866	Corselet de renégat
9867	Cape de renégat
9868	Gantelets de renégat
9869	Ceinture de renégat
9870	Diadème de renégat
9871	Jambières de renégat
9872	Espauliers de renégat
9873	Bouclier de renégat
9874	Drapé de sorcier
9875	Echarpe de sorcier
9876	Mules de sorcier
9877	Cape de sorcier
9878	Chapeau de sorcier
9879	Bracelets de sorcier
9880	Gants de sorcier
9881	Mantelet de sorcier
9882	Sphère de sorcier
9883	Pantalon de sorcier
9884	Robe de sorcier
9885	Bottes de veneur
9886	Poignets de veneur
9887	Armure de veneur
9889	Bandeau de veneur
9890	Cape de veneur
9891	Ceinture de veneur
9892	Gants de veneur
9893	Jambières de veneur
9894	Epaulières de veneur
9895	Bottes jazeran
9896	Brassards jazeran
9897	Corselet jazeran
9898	Cape jazeran
9899	Bouclier jazeran
9900	Gantelets jazeran
9901	Ceinture jazeran
9902	Casque jazeran
9903	Jambières jazeran
9904	Espauliers jazeran
9905	Chemisette royale
9906	Echarpe royale
9907	Bottes royales
9908	Cape royale
9909	Poignets royaux
9910	Gants royaux
9911	Pantalon royal
9912	Amict royal
9913	Robe royale
9914	Sceptre royal
9915	Bandeau royal
9916	Ceinture de pisteur
9917	Bottes de pisteur
9918	Pavois brigadier
9919	Cape de pisteur
9920	Gants de pisteur
9921	Bandeau de pisteur
9922	Jambières de pisteur
9923	Protège-épaules de pisteur
9924	Tunique de pisteur
9925	Garde-poignets de pisteur
9926	Bottes de la brigade
9927	Brassards de la brigade
9928	Cuirasse de la brigade
9929	Cape de la brigade
9930	Gantelets de la brigade
9931	Ceinturon de la brigade
9932	Diadème de la brigade
9933	Jambières de la brigade
9934	Espauliers de la brigade
9935	Bouclier en plaques estampées
9936	Bottes d'abjurateur
9937	Poignets d'abjurateur
9938	Cape d'abjurateur
9939	Gants d'abjurateur
9940	Cagoule d'abjurateur
9941	Mantelet d'abjurateur
9942	Pantalon d'abjurateur
9943	Robe d'abjurateur
9944	Cristal d'abjurateur
9945	Echarpe d'abjurateur
9946	Tunique d'abjurateur
9947	Ceinture de chef
9948	Bottes de chef
9949	Brassards de chef
9950	Cuirasse de chef
9951	Cape de chef
9952	Gants de chef
9953	Coiffure de chef
9954	Jambières de chef
9955	Epaulières de chef
9956	Brassards de belliciste
9957	Plastron de belliciste
9958	Targe de belliciste
9959	Cape de belliciste
9960	Gantelets de belliciste
9961	Ceinture de belliciste
9962	Bottes de belliciste
9963	Diadème de belliciste
9964	Jambières de belliciste
9965	Espauliers de belliciste
9966	Armure de plaques estampée
9967	Gantelets en plaques estampées
9968	Ceinturon en plaques estampées
9969	Heaume en plaques estampées
9970	Jambières en plaques estampées
9971	Espauliers en plaques estampées
9972	Brassards en plaques estampées
9973	Bottes en plaques estampées
9974	Bouclier de suzerain
9978	Détecteur Gahz'ridian
9998	Gilet noir en tisse-mage
9999	Pantalon noir en tisse-mage
10000	Corne de Margol
10001	Robe noire en tisse-mage
10002	Pantalon en tisse-ombre
10003	Gants noirs en tisse-mage
10004	Robe en tisse-ombre
10005	Corne gigantesque de Margol
10007	Gilet rouge en tisse-mage
10008	Masque blanc de bandit
10009	Pantalon rouge en tisse-mage
10010	Pantalon en étoffe-tempête
10011	Gants en étoffe-tempête
10018	Gants rouges en tisse-mage
10019	Gants en tisse-rêve
10020	Gilet en étoffe-tempête
10021	Gilet en tisse-rêve
10022	Titre de propriété
10023	Gants en tisse-ombre
10024	Bandeau noir en tisse-mage
10025	Masque en tisse-ombre
10026	Bottes noires en tisse-mage
10027	Epaulières noires en tisse-mage
10028	Epaulières en tisse-ombre
10029	Epaulières rouges en tisse-mage
10030	Bicorne d'amiral
10031	Bottes en tisse-ombre
10032	Bandeau en étoffe-tempête
10033	Bandeau rouge en tisse-mage
10034	Chemise de smoking
10035	Pantalon de smoking
10036	Veste de smoking
10038	Epaulières en étoffe-tempête
10039	Bottes en étoffe-tempête
10040	Robe blanche de mariée
10041	Diadème en tisse-rêve
10042	Robe en étoffe cendrée
10043	Chausses pieuses
10044	Bottes en étoffe cendrée
10045	Pantalon en lin écru
10046	Bottes en lin écru
10047	Kilt simple
10048	Kilt coloré
10049	Lame du diaboliste
10050	Sac en tisse-mage
10051	Sac rouge en tisse-mage
10052	Chemise orange martiale
10053	Robe noire simple
10054	Chemise lavande en tisse-mage
10055	Chemise rose en tisse-mage
10056	Chemise orange en tisse-mage
10057	Tunique tissée de crépuscule
10058	Sandales tissées de crépuscule
10059	Brassards tissés de crépuscule
10060	Cape tissée de crépuscule
10061	Turban tissé de crépuscule
10062	Gants tissés de crépuscule
10063	Amict tissé de crépuscule
10064	Pantalon tissé de crépuscule
10065	Robe tissée de crépuscule
10066	Echarpe tissée de crépuscule
10067	Sangle pieuse
10068	Bottes pieuses
10069	Brassards pieux
10070	Armure pieuse
10071	Cape pieuse
10072	Gants pieux
10073	Casque pieux
10074	Jambières pieuses
10075	Spallières pieuses
10076	Garde-bras de seigneur
10077	Cuirasse de seigneur
10078	Cimier de seigneur
10079	Cape de seigneur
10080	Gantelets de seigneur
10081	Ceinturon de seigneur
10082	Bottes de seigneur
10083	Couronne de seigneur
10084	Cuissards de seigneur
10085	Espauliers de seigneur
10086	Armure de plaques gothique
10087	Gantelets gothiques en plaques
10088	Ceinturon gothique en plaques
10089	Bottes gothiques
10090	Heaume gothique en plaques
10091	Jambières gothiques en plaques
10092	Spallières gothiques en plaques
10093	Déflecteur de revenant
10094	Protège-bras gothiques en plaques
10095	Bottes de conseiller
10096	Crispins de conseiller
10097	Diadème de conseiller
10098	Cape de conseiller
10099	Gants de conseiller
10100	Epaulières de conseiller
10101	Pantalon de conseiller
10102	Robe de conseiller
10103	Echarpe de conseiller
10104	Tunique de conseiller
10105	Armure d'errance
10106	Bottes d'errance
10107	Brassards d'errance
10108	Cape d'errance
10109	Ceinture d'errance
10110	Gants d'errance
10111	Chapeau d'errance
10112	Jambières d'errance
10113	Epaulières d'errance
10118	Cuirasse ornée
10119	Grèves ornées
10120	Cape ornée
10121	Gantelets ornés
10122	Ceinturon orné
10123	Diadème orné
10124	Jambières ornées
10125	Espauliers ornés
10126	Brassards ornés
10127	Brassards de revenant
10128	Pansière de revenant
10129	Gantelets de revenant
10130	Ceinturon de revenant
10131	Bottes de revenant
10132	Heaume de revenant
10133	Jambières de revenant
10134	Epaulières de revenant
10135	Tunique de grand conseiller
10136	Brassards de grand conseiller
10137	Bottes de grand conseiller
10138	Cape de grand conseiller
10139	Diadème de grand conseiller
10140	Gants de grand conseiller
10141	Pantalon de grand conseiller
10142	Mantelet de grand conseiller
10143	Robe de grand conseiller
10144	Echarpe de grand conseiller
10145	Ceinturon de la puissance
10146	Bottes de la puissance
10147	Brachiales de la puissance
10148	Cape de la puissance
10149	Gantelets de la puissance
10150	Casque de la puissance
10151	Tunique de puissance
10152	Jambières de la puissance
10153	Spallières de la puissance
10154	Ceinturon mercurien
10155	Bottes mercuriennes
10156	Brassards mercuriens
10157	Cuirasse mercurienne
10158	Garde mercurienne
10159	Cape mercurienne
10160	Diadème mercurien
10161	Gantelets mercuriens
10162	Cuissards mercuriens
10163	Espauliers mercuriens
10164	Pansière de templier
10165	Gantelets de templier
10166	Ceinturon de templier
10167	Bottes de templier
10168	Couronne de templier
10169	Jambières de templier
10170	Espauliers de templier
10171	Brassards de templier
10172	Mantelet mystique
10173	Brassards mystiques
10174	Cape mystique
10175	Turban mystique
10176	Gants mystiques
10177	Jambières mystiques
10178	Robe mystique
10179	Bottes mystiques
10180	Ceinture mystique
10181	Armure mystique
10182	Cuirasse de bretteur
10183	Bottes de bretteur
10184	Brassards de bretteur
10185	Cape de bretteur
10186	Gants de bretteur
10187	Couvre-oeil de bretteur
10188	Jambières de bretteur
10189	Protège-épaules de bretteur
10190	Ceinture de bretteur
10191	Garde-bras de croisé
10192	Bottes de croisé
10193	Armure de croisé
10194	Cape de croisé
10195	Bouclier de croisé
10196	Gantelets de croisé
10197	Ceinture de croisé
10198	Heaume de croisé
10199	Jambières de croisé
10200	Espauliers de croisé
10201	Jambières de suzerain
10202	Protège-bras de suzerain
10203	Pansière de suzerain
10204	Bouclier lamellaire lourd
10205	Gantelets de suzerain
10206	Ceinturon de suzerain
10207	Couronne de suzerain
10208	Cuissards de suzerain
10209	Spallières de suzerain
10210	Mantelet élégant
10211	Bottes élégantes
10212	Cape élégante
10213	Brassards élégants
10214	Gants élégants
10215	Robe élégante
10216	Ceinture élégante
10217	Jambières élégantes
10218	Tunique élégante
10219	Diadème élégant
10220	Tunique de la belladone
10221	Ceinturon de belladone
10222	Bottes de la belladone
10223	Garde-bras de la belladone
10224	Cape de la belladone
10225	Gants de la belladone
10226	Protège-front de la belladone
10227	Jambières de la belladone
10228	Spallières de la belladone
10229	Brassards ciselés
10230	Cuirasse ciselée
10231	Cape ciselée
10232	Gantelets ciselés
10233	Ceinturon ciselé
10234	Bottes ciselées
10235	Heaume ciselé
10236	Jambières ciselées
10237	Espauliers ciselés
10238	Bottes lamellaires lourdes
10239	Protège-bras lamellaires lourds
10240	Plastron lamellaire lourd
10241	Heaume lamellaire lourd
10242	Gantelets lamellaires lourds
10243	Ceinturon lamellaire lourd
10244	Jambières lamellaires lourdes
10245	Espauliers lamellaires lourds
10246	Gilet de maître
10247	Bottes de maître
10248	Brassards de maître
10249	Cape de maître
10250	Chapeau de maître
10251	Gants de maître
10252	Jambières de maître
10253	Mantelet de maître
10254	Robe de maître
10255	Ceinture de maître
10256	Brassards d'aventurier
10257	Bottes d'aventurier
10258	Cape d'aventurier
10259	Ceinture d'aventurier
10260	Gants d'aventurier
10261	Bandeau d'aventurier
10262	Jambières d'aventurier
10263	Epaulières d'aventurier
10264	Tunique d'aventurier
10265	Brassards ouvragés
10266	Cuirasse ouvragée
10267	Cape ouvragée
10268	Gantelets ouvragés
10269	Ceinturon ouvragé
10270	Bottes ouvragées
10271	Bouclier ouvragé
10272	Diadème ouvragé
10273	Jambières ouvragées
10274	Espauliers ouvragés
10275	Cuirasse d'émeraude
10276	Sandales d'émeraude
10277	Gantelets d'émeraude
10278	Ceinturon d'émeraude
10279	Heaume d'émeraude
10280	Jambières d'émeraude
10281	Espauliers d'émeraude
10282	Protège-bras d'émeraude
10283	Echantillons de coeur de loup
10285	Soie des ténèbres
10286	Coeur de fauve
10287	Mantelet en tisse-vert
10288	Diadème de sage
10289	Chapeau solide
10290	Teinture rose
10298	Anneau de Gnomeregan
10299	Amulette de Gnomeregan
10300	Patron : Gilet rouge en tisse-mage
10301	Patron : Masque blanc de bandit
10302	Patron : Pantalon rouge en tisse-mage
10303	Patron : Pantalon en étoffe-tempête
10304	Patron : Gants en étoffe-tempête
10305	Parchemin de Protection IV
10306	Parchemin d'Esprit IV
10307	Parchemin d'Endurance IV
10308	Parchemin d'Intelligence IV
10309	Parchemin d'Agilité IV
10310	Parchemin de Force IV
10311	Patron : Chemise orange martiale
10312	Patron : Gants rouges en tisse-mage
10313	Patron : Gilet en étoffe-tempête
10314	Patron : Chemise lavande en tisse-mage
10315	Patron : Epaulières rouges en tisse-mage
10316	Patron : Kilt coloré
10317	Patron : Chemise rose en tisse-mage
10318	Patron : Bicorne d'amiral
10319	Patron : Bandeau en étoffe-tempête
10320	Patron : Bandeau rouge en tisse-mage
10321	Patron : Chemise de smoking
10322	Patron : Epaulières en étoffe-tempête
10323	Patron : Pantalon de smoking
10324	Patron : Bottes en étoffe-tempête
10325	Patron : Robe blanche de mariée
10326	Patron : Veste de smoking
10327	Corne d'Echeyakee
10328	Plastron écarlate
10329	Ceinture écarlate
10330	Jambières écarlates
10331	Gantelets écarlates
10332	Bottes écarlates
10333	Garde-poignets de la Croisade écarlate
10338	Carcasse de zhévra fraîche
10358	Brassards de Duracin
10359	Bottes perdurantes
10360	Cobra noir
10361	Serpent brun
10362	Bouclier orné
10363	Pavois ciselé
10364	Bouclier de templier
10365	Bouclier d'émeraude
10366	Garde démoniaque
10367	Bouclier d'Hypérion
10368	Armure imprégnée en plaques
10369	Gantelets imprégnés en plaques
10370	Ceinturon imprégné en plaques
10371	Bottes imprégnées en plaques
10372	Heaume imprégné en plaques
10373	Jambières imprégnées en plaques
10374	Espauliers imprégnés en plaques
10375	Protège-bras imprégnés en plaques
10376	Bottes de commandant
10377	Protège-bras de commandant
10378	Armure de commandant
10379	Heaume de commandant
10380	Gantelets de commandant
10381	Ceinturon de commandant
10382	Jambières de commandant
10383	Espauliers de commandant
10384	Armure d'Hypérion
10385	Bottes d'Hypérion
10386	Gantelets d'Hypérion
10387	Ceinturon d'Hypérion
10388	Heaume d'Hypérion
10389	Cuissards d'Hypérion
10390	Espauliers d'Hypérion
10391	Protège-bras d'Hypérion
10392	Serpent cramoisi
10393	Cafard
10394	Sifflet de chien de prairie
10398	Poulet mécanique
10399	Armure défias noircie
10400	Jambières défias noircies
10401	Gants défias noircis
10402	Bottes défias noircies
10403	Ceinture défias noircie
10404	Ceinture solide
10405	Epaulières de bandit
10406	Bandeau en cuir écaillé
10407	Protège-épaules d'écumeur
10408	Casque cerclé
10409	Bottes cerclées
10410	Jambières du Croc
10411	Bottes du Croc
10412	Ceinture du Croc
10413	Gants du Croc
10414	Echantillon de carapace de Gueule d'acier
10418	Insigne rougeoyant en mithril
10420	Crâne du Porte-froid
10421	Haubergeon grossier en cuivre
10423	Jambières en bronze argenté
10424	Plans : Jambières en bronze argenté
10438	Boîte de Felix
10439	Thé brûlant de Durnan
10440	Chope de Nori
10441	Eclat luminescent
10442	Artefact mystérieux
10443	Lettre roussie
10444	Lance-fusée standard
10445	Trousse de dessin
10446	Coeur d'Obsidion
10447	Tête de Lathoric le Noir
10450	Plume d'hippogryphe sans défaut
10454	Essence d'Eranikus
10455	Essence d'Eranikus enchaînée
10456	Une bourse rebondie
10457	Coquille d'Escargot de mer vide
10458	Prière à Elune
10459	Tête du chef Brochaigu Mantépine
10460	Sang hakkari
10461	Brassards des ténèbres
10462	Ceinture des ténèbres
10463	Patron : Masque en tisse-ombre
10464	Bâton de commandement
10465	Oeuf d'Hakkar
10466	Cercle de pierres atal'ai
10467	Sacoche du marchand
10478	Gemme de mana de Roland
10479	Sacoche de marchand de Kovic
10498	Micro-ajusteur gyromatique
10499	Lunettes d'oeil brillant
10500	Lunettes de feu
10501	Lunettes d'oeil de chat
10502	Lunettes de fortification des sorts
10503	Lunettes roses
10504	Lentille verte
10505	Poudre noire solide
10506	Casque de scaphandrier
10507	Dynamite solide
10508	Tromblon en mithril
10509	Coeur des flammes
10510	Carabine de gros calibre en mithril
10511	Huile de golem
10512	Balles perçantes en mithril
10513	Balle gyroscopique en mithril
10514	Bombe explosive en mithril
10515	Torche de vindicte
10518	Cape parachute
10538	Tablette de Beth'Amara
10539	Tablette de Jin'yael
10540	Tablette de Markri
10541	Tablette de Sael'hai
10542	Casque de mineur gobelin
10543	Casque de chantier gobelin
10544	Maillet des chardons
10545	Lunettes gnomes
10546	Lunette mortelle
10547	Couteau des campeurs
10548	Lunette de sniper
10549	Pantalon de Rancher
10550	Mitaines en laine
10551	Dague plaquée en thorium
10552	Symbole de Ragnaros
10553	Gilet de contremaître
10554	Pantalon de contremaître
10556	Cercle de pierres
10558	Batterie en or
10559	Tube en mithril
10560	Déclencheur instable
10561	Caisse en mithril
10562	Bombe explosive
10563	Reproduction : Rune de Beth'Amara
10564	Reproduction : Rune de Jin'yael
10565	Reproduction : Rune de Markri
10566	Reproduction : Rune de Sael'hai
10567	Lance-épine
10569	Trésor du Vol noir
10570	Massacreuse
10571	Gourdin d'ébène
10572	Fragment glacial
10573	Flagelle-os
10574	Voile mortuaire
10575	Cuir de dragon noir
10576	Petit dragon mécanique en mithril
10577	Mortier des gobelins
10578	Bottes des penseurs
10579	Flèche explosive
10580	Boîte à "Boum" des gobelins
10581	Habit de la tête de mort
10582	Coureuses des fougères
10583	Harnais huran
10584	Poings de la bourrasque
10585	Radio gobeline
10586	Le Mastoc
10587	Distributeur de bombes des gobelins
10588	Heaume-fusée gobelin
10589	Pierre de voeu des dragons d'Ysera
10590	Boîte noire corrodée
10592	Elixir d'oeil de chat
10593	Fragment de draenéthyste imparfait
10595	Kum'isha's Junk
10597	Tête du magus Rimtori
10598	Tête ensanglantée d'Hetaera
10599	Tête battue d'Hetaera
10600	Tête meurtrie d'Hetaera
10601	Schéma : Lunettes d'oeil brillant
10602	Schéma : Lunette mortelle
10603	Schéma : Lunettes d'oeil de chat
10604	Schéma : Carabine de gros calibre en mithril
10605	Schéma : Lunettes de fortification des sorts
10606	Schéma : Cape parachute
10607	Schéma : Casque de scaphandrier
10608	Schéma : Lunette de sniper
10609	Schéma : Petit dragon mécanique en mithril
10610	Sang d'Hetaera
10620	Minerai de thorium
10621	Parchemin runique
10622	Drapeau de Kadrak
10623	Morsure glaciale
10624	Arc pénétrant
10625	Lame furtive
10626	Marteau-rageur
10627	Bâton de Rictus
10628	Mortifiante
10629	Bottes de Mistwalker
10630	Auréole du voleur d'âme
10631	Gantelets des eaux troubles
10632	Brassards d'écailles gluantes
10633	Jambières Silvershell
10634	Anneau de l'oeil spirituel
10635	Jambières en anneaux peints
10636	Gants de nomade
10637	Gants de brasseur
10638	Longue cape drapée
10639	Champignon jacinthe
10640	Ichor d'araignée Tissebois
10641	Lys pétale de lune
10642	Antidote d'Iverron
10643	Lettre scellée pour Ag'tor
10644	Recette : Carburant de fusée des gobelins
10645	Rayon mortel gnome
10646	Charge de sapeur gobelin
10647	Encre d'ingénieur
10648	Parchemin vierge
10649	Eclat de cauchemar
10650	Peau de huran infesté
10651	Cristal de focalisation des arcanes craquelé
10652	Volonté du géant des montagnes
10653	Bottes Trailblazer
10654	Gants en jute tressée
10655	Chausses en jonc tressé
10656	Haubergeon d'écorce
10657	Mantelet de Talbar
10658	Bottines Quagmire
10659	Éclat des Sabots-Fendus
10660	Première tablette Mosh'aru
10661	Deuxième tablette Mosh'Aru
10662	Oeuf d'Hakkar rempli
10663	Essence d'Hakkar
10664	Une note pour le magus Rimtori
10678	Note de Magatha
10679	Note d'Andron
10680	Note de Jes'rimon
10681	Note de Xylem
10682	Pierre de voeu de Belnistrasz
10683	Sac de l'explorateur
10684	Parachute colossal
10686	Egide de guerre
10687	Fiole vide marquée N°1
10688	Fiole vide marquée N°2
10689	Fiole vide marquée N°3
10690	Fiole vide marquée N°4
10691	Fiole pleine marquée N°1
10692	Fiole pleine marquée N°2
10693	Fiole pleine marquée N°3
10694	Fiole pleine marquée N°4
10695	Boîte de fioles vides
10696	Epée Felbane en azsharite enchanté
10697	Dague Felbane en azsharite enchanté
10698	Bâton Felbane en azsharite enchanté
10699	Ronce de Yeh'kinya
10700	Bottes Encarmine
10701	Bottes de Zua'tec
10702	Enormes bottes d'ogre
10703	Dague démoniaque
10704	Bâton Chillnail
10705	Protège-poignets du saule épineux
10706	Ceinturon de la nuit
10707	Bottes des forgeurs
10708	Orbe Crânesort
10709	Orbe funéraire
10710	Anneau Dragonclaw
10711	Collier du sang de dragon
10712	Elixir de Cuely
10713	Plans : Cylindre damasquiné en mithril
10714	Azsharite cristallisée
10715	Lunette de Kim'Jael
10716	Rayon réducteur gnome
10717	Boussole de Kim'Jael
10718	Wizzlegoober de Kim'Jael
10719	Alarme mobile
10720	Lance-filet automatique gnome
10721	Ceinture de prévention gnome
10722	Poulet farci de Kim'Jael
10723	Petite radio gnome
10724	Bottes-fusées gnomes
10725	Coq de combat gnome
10726	Coiffe de contrôle mental gnome
10727	Fusil-dragon des gobelins
10728	Patron : Chemise noire de bretteur
10738	Chargement pour Galvan
10739	Anneau de robustesse
10740	Cuissards de centurion
10741	Casque de Lordrec
10742	Jambières des dragons
10743	Protège-front drakefeu
10744	Hache du drake d'ébène
10745	Epaulières Kaylari
10746	Protège-bras d'acier runique
10747	Echarpe de professeur
10748	Bottes des errants
10749	Heaume de l'Avant-garde
10750	Miséricorde de force vitale
10751	Diadème suprême
10752	Coffre incrusté d'émeraudes
10753	Amulette de Grol
10754	Amulette de Sevine
10755	Amulette d'Allistarj
10757	Amulette du Souilleur
10758	X'calibhure
10759	Corne brisée du Souilleur
10760	Poings du pourceau
10761	Dague de Coldrage
10762	Robe de la liche
10763	Barbute en glace-acier
10764	Armure de Froidemort
10765	Doigts-d'os
10766	Bâton ténébreux
10767	Bouclier du sanglier sauvage
10768	Ceinture de champion sanglier
10769	Oeil luminescent de Mordresh
10770	Crâne sans vie de Mordresh
10771	Echarpe de mage mortel
10772	Fendoir de Glouton
10773	Urne hakkari
10774	Epaulières Fleur-de-peau
10775	Carapace de Tuten'kash
10776	Cape d'araignée soyeuse
10777	Gants d'arachnide
10778	Collier de sanctuaire
10779	Sang de démon
10780	Marque d'Hakkar
10781	Cuirasse hakkari
10782	Voile hakkari
10783	Spallières atal'ai
10784	Cuirasse atal'ai
10785	Jambières atal'ai
10786	Bottes atal'ai
10787	Gants atal'ai
10788	Ceinturon atal'ai
10789	Manuel d'ingénierie
10790	Carte de membre des ingénieurs gnomes
10791	Carte de membre des ingénieurs gobelins
10792	Voeu du secret de Nixx
10793	Voeu du secret Overspark
10794	Voeu du secret d'Oglethorpe
10795	Anneau griffe-drake
10796	Pierre de drake
10797	Souffle-feu
10798	Anneau d'Atal'alarion
10799	Trucideuse
10800	Brassards des eaux sombres
10801	Bottes Slitherscale
10802	Cape d'Aile-voile
10803	Lame du Misérable
10804	Fracasseuse des damnés
10805	Déchireuse des morts
10806	Habit du prophète atal'ai
10807	Kilt du prophète atal'ai
10808	Gants du prophète atal'ai
10818	Parchemin de Yeh'kinya
10819	Plume d'Indomptable
10820	Ceinture Jackseed
10821	Cape de semeur
10822	Jeune dragonnet sombre
10823	Epée du triomphe
10824	Talisman de luisambre
10826	Bâton du savoir
10827	Tunique de géomètre
10828	Griffe redoutable
10829	Oeil de dragon
10830	Grenade à fragmentation M73
10831	Orbe corrompu
10832	Manuel du propriétaire du gangrechien traqueur
10833	Cornes d'Eranikus
10834	Kit de Gangrechien traqueur
10835	Ecusson de suprématie
10836	Bâtonnet de corrosion
10837	Dent d'Eranikus
10838	Masse d'Hakkar
10839	Note cristallisée
10840	Note cristallisée
10841	Thé de dorépine
10842	Sarong Windscale
10843	Cape Peau-de-plume
10844	Bâton d'Hakkar
10845	Etreinte du guerrier
10846	Bottes de sanguin
10847	Appel du dragon
10858	Plans : Solide maillet en fer
10918	Poison douloureux
10919	Gants d'apothicaire
10920	Poison douloureux II
10921	Poison douloureux III
10922	Poison douloureux IV
10938	Essence de magie inférieure
10939	Essence de magie supérieure
10940	Poussière étrange
10958	Collier d'Hilary
10959	Sac en peau de démon
10978	Petit éclat scintillant
10998	Essence astrale inférieure
10999	Souillefer
11000	Clé ombreforge
11018	Humus d'Un'Goro
11020	Sacoche de printemps
11022	Pochette de graines de Tharlendis
11023	Coq d'Ancona
11024	Jardinières de printemps
11026	Boîte à Grenouille sylvestre
11027	Boîte à Grenouille forestière
11038	Formule : Enchantement d'arme 2M (Esprit inférieur)
11039	Formule : Enchantement de cape (Agilité mineure)
11040	Fibre d'aurore
11058	Anneau de nez de Sha'ni
11078	Clé du coffret à relique
11079	Tête coupée de Gor'tesh
11080	Tête coupée de Gor'tesh
11081	Formule : Enchantement de bouclier (Protection inférieure)
11082	Essence astrale supérieure
11083	Poussière d'âme
11084	Gros éclat scintillant
11085	Clé du coffret du client du mois
11086	Jang'thraze le Protecteur
11098	Formule : Enchantement de cape (Résistance aux ténèbres inférieure)
11099	Minerai de sombrefer
11101	Formule : Enchantement de bracelets (Force inférieure)
11102	Oeuf non-éclos de Fée fléchetteuse
11103	Bonne graine
11104	Grande boussole
11105	Carte enroulée
11106	Clé à tête de lion
11107	Un petit paquet
11108	Photographie terne
11109	Nourriture spéciale pour poulet
11110	Oeuf de poule
11111	Oeuf brisé de Fée fléchetteuse
11112	Equipement de recherche
11113	Caisse de nourriture
11114	Os de dinosaure
11115	Clé du coffre secret
11116	Un journal abîmé
11118	Pierre archaïque
11119	Récolte de Milly
11120	Marteau de Belgrom
11121	Tulwar des eaux sombres
11122	Carotte et bâton
11123	Jambières de cavalier de la pluie
11124	Heaume d'exil
11125	Manifeste des vendanges
11126	Tablette de Kurniya
11127	Fournitures de récupération
11128	Bâtonnet doré
11129	Essence des éléments
11130	Bâtonnet runique en or
11131	Echantillon de paroi de la ruche
11133	Epée d'entraînement de Linken
11134	Essence mystique inférieure
11135	Essence mystique supérieure
11136	Epée trempée de Linken
11137	Poussière de vision
11138	Petit éclat luminescent
11139	Gros éclat luminescent
11140	Clé de la prison
11141	Appât
11142	Samophlange cassé
11143	Rondelle de métal
11144	Bâtonnet en vrai-argent
11145	Bâtonnet runique en vrai-argent
11146	Samophlange cassé
11147	Couverture du manuel du Samophlange
11148	Page du manuel du Samophlange
11149	Manuel du Samophlange
11150	Formule : Enchantement de gants (Minage)
11151	Formule : Enchantement de gants (Herboristerie)
11152	Formule : Enchantement de gants (Pêche)
11162	Epée excellente de Linken
11163	Formule : Enchantement de bracelets (Déviation inférieure)
11164	Formule : Enchantement d'arme (Tueur de bête inférieur)
11165	Formule : Enchantement d'arme (Tueur d'élémentaire inférieur)
11166	Formule : Enchantement de gants (Dépeçage)
11167	Formule : Enchantement de bottes (Esprit inférieur)
11168	Formule : Enchantement de bouclier (Blocage inférieur)
11169	Livre d'Aquor
11171	Gangrefer
11172	Griffes argentées
11173	Coeur d'Arbrefer
11174	Essence du néant inférieure
11175	Essence du néant supérieure
11176	Poussière de rêve
11177	Petit éclat irradiant
11178	Gros éclat irradiant
11179	Flamme dorée
11184	Cristal de puissance bleu
11185	Cristal de puissance vert
11186	Cristal de puissance rouge
11187	Brassards en tiges entrelacées
11188	Cristal de puissance jaune
11189	Robe forestière
11190	Gants de Viny
11191	Bottes de fermier
11192	Gants de tailleur
11193	Cuirasse des vents brûlants
11194	Haubert en écailles prismatiques
11195	Pansière de guerre
11196	Médaillon d'explosion mentale
11197	Clé du gardien noir
11198	Rune d'évasion
11199	Bouclier d'ingénieur 1
11200	Bouclier d'ingénieur 2
11201	Bouclier d'ingénieur 3
11202	Formule : Enchantement de bouclier (Endurance)
11203	Formule : Enchantement de gants (Minage avancé)
11204	Formule : Enchantement de bracelets (Esprit supérieur)
11205	Formule : Enchantement de gants (Herboristerie avancée)
11206	Formule : Enchantement de cape (Agilité inférieure)
11207	Formule : Enchantement d'arme (Arme flamboyante)
11208	Formule : Enchantement d'arme (Tueur de démon)
11222	Tête de Krom'zar
11223	Formule : Enchantement de bracelets (Déviation)
11224	Formule : Enchantement de bouclier (Résistance au givre)
11225	Formule : Enchantement de bracelets (Endurance supérieure)
11226	Formule : Enchantement de gants (Equitation)
11227	Morceau de la bannière de Krom'zar
11228	Cuir de dragon frénétique
11229	Ceinturon en écailles luisantes
11230	Essence féerique enchâssée
11231	Cuir de dragon noir altéré
11242	Evoroot
11243	Elixir de Videre
11262	Orbe de Lorica
11263	Baguette de force du Néant
11265	Maillet de Cragwood
11266	Fragment d'élémentaire fracturé
11267	Echantillon de Fragment d'élémentaire
11268	Tête d'Argelmach
11269	Noyau d'élémentaire intact
11270	Promesse écrite de Nixx
11282	Promesse écrite d'Oglethorpe
11283	Promesse écrite d'Overspark
11284	Balles de précision
11285	Flèche barbelée
11286	Chaînes en thorium
11287	Baguette magique inférieure
11288	Baguette magique supérieure
11289	Baguette mystique inférieure
11290	Baguette mystique supérieure
11291	Bois d'étoile
11302	Force d'Uther
11303	Bon arc court
11304	Bon arc long
11305	Arc court dense
11306	Arc long solide
11307	Arc long de puissance
11308	Arc court sylvestre
11309	Le Coeur de la montagne
11310	Mantelet de prophète des flammes
11311	Cape en écailles de braise
11312	Recette perdue de la Thunderbrew
11313	Tête de Ribbly
11315	Pousse de Pétale-de-sang
11316	Pétale-de-sang
11318	Brume atal'ai
11319	Baguette déchargée
11320	Baguette Pétale-de-sang
11324	Sac de l'explorateur
11325	Chope de bière sombrefer
11362	Carquois moyen
11363	Sacoche moyenne de poudre
11364	Tabard de Stormwind
11366	Lettre d'Helendis Riverhorn
11367	Demande d'aide de Solomon à Bolvar
11368	Décret de Bolvar
11370	Minerai de sombrefer
11371	Barre de sombrefer
11382	Sang de la montagne
11384	Dents de basilic cassées
11385	Ecaille de basilic
11386	Oeil spongieux de basilic
11387	Coeur de basilic
11388	Venin de basilic
11389	Peau de basilic étincelante
11390	Croc brisé de chauve-souris
11391	Aile de chauve-souris épineuse
11392	Griffe brisée de chauve-souris
11393	Petit crâne de chauve-souris
11394	Coeur de chauve-souris
11395	Oreille de chauve-souris
11402	Peau lustrée de chauve-souris
11403	Grand croc de chauve-souris
11404	Oeil de chauve-souris maléfique
11405	Veine d'argent de géant
11406	Carcasse pourrie d'ours
11407	Peau d'ours déchirée
11408	Mâchoire d'ours
11409	Flanc d'ours
11410	Griffe d'ours sauvage
11411	Grand os d'ours
11412	Fiole de Nagmara
11413	Fiole de Nagmara remplie
11414	Crinière grisonnante
11415	Mélange de baies
11416	Cage thoracique délicate
11417	Aile douce
11418	Os creux d'aile
11419	Oeuf mystérieux non-éclos
11420	Outil élégant d'écriture
11422	Cadeau de réinscription des Ingénieurs gobelins
11423	Cadeau de réinscription des Ingénieurs gnomes
11442	Trousse d'adjoint de Stormwind
11444	Sanglier du Sinistre dévoreur
11445	Flûte des anciens
11446	Une note chiffonnée
11462	Couteau de rebut
11463	Vieux colis
11464	Les informations égarées du maréchal Windsor
11465	Les informations égarées du maréchal Windsor
11466	Rapport de Raschal
11467	Médaillon de Blackrock
11468	Sacoche sombrefer
11469	Brassards de bandelettes sanglantes
11470	Transcription de la tablette
11471	Oeuf fragile de Fée fléchetteuse
11472	Flanc de Traqueur Crins-d'argent
11473	Enigmatron-PX83
11474	Oeuf de Fée fléchetteuse
11475	Cape tachée de vin
11476	Peau d'U'cha
11477	Griffe blanche de ravasaure
11478	Peau de gorille d'Un'Goro
11479	Peau de Marteleur d'Un'Goro
11480	Peau de Foudroyeur d'Un'Goro
11482	Manuel d'utilisateur de Pylône de cristal
11502	Epaulières de connaissance en cuir
11503	Ambre de sang
11504	Morceau de carcasse d'un battrodon
11507	Peau de hyène tachetée
11508	Mules de maître de jeu
11509	Glande de phéromone de ravasaure
11510	Tête de Lar'korwi
11511	Balise cénarienne
11512	Morceau de peau contaminée
11513	Vitriol contaminé
11514	Gangrimpante
11515	Fragment d'âme corrompue
11516	Baume végétal cénarien
11522	Totem en argent d'Aquementas
11562	Cristal de restauration
11563	Cristal de concentration
11564	Cristal de protection
11565	Cristal de réduction
11566	Cristal d'explosion
11567	Cristal de rétribution
11568	Sacoche de Torwa
11569	Viande de battrodon préservée
11570	Echantillon de phéromone préservé
11582	Salve infernale
11583	Pomme de cactus
11584	Surprise aux pommes de cactus
11590	Trousse de réparation mécanique
11602	Clé du Sinistre dévoreur
11603	Découpeur vicieux
11604	Harnois en sombrefer
11605	Epaulières en sombrefer
11606	Cotte de mailles en sombrefer
11607	Découpeuse en sombrefer
11608	Pulvériseur en sombrefer
11609	Cuir de dragon noir altéré
11610	Plans : Pulvériseur en sombrefer
11611	Plans : Découpeuse en sombrefer
11612	Plans : Harnois en sombrefer
11614	Plans : Cotte de mailles en sombrefer
11615	Plans : Epaulières en sombrefer
11617	Fournitures d'Eridan
11622	Arcanum inférieur de rumination
11623	Cape de l'esprit follet
11624	Amict d'illumination
11625	Sphère des Exaltés
11626	Cape du voile noir
11627	Bottes de sagacité
11628	Arc du chef de meute
11629	Carabine de maître-chien
11630	Balles de roche
11631	Bouclier de garde renforcée
11632	Epaulières du terril
11633	Carapace croc-d'épeire
11634	Gants arachnéens
11635	Croc arachnéen
11642	Arcanum inférieur de constitution
11643	Arcanum inférieur de ténacité
11644	Arcanum inférieur de résistance
11645	Arcanum inférieur de voracité
11646	Arcanum inférieur de voracité
11647	Arcanum inférieur de voracité
11648	Arcanum inférieur de voracité
11649	Arcanum inférieur de voracité
11662	Echarpe de Ban'thok
11665	Poings de l'ogre prophète
11668	Flûte de Xavaric
11669	Anneau des grandes arcanes
11674	Lien maudit Jadefeu
11675	Bottes ténébreuses
11677	Cape de la tombe putride
11678	Carapace d'Anub'shiah
11679	Garde-bras rubiconds
11682	Fiole d'Eridan
11684	Hostefer
11685	Epaulières de peau éclissée
11686	Ceinturon de furie bestiale
11702	Trancheuse de Grison
11703	Ceinturon de renforcement
11722	Spallières en drégénite
11723	Flamberge de Goodsteel
11724	Paquet en retard de livraison
11725	Patte cristalline solide
11726	Cotte d'anneaux de gladiateur sauvage
11727	Livre de Goodsteel
11728	Jambières de gladiateur sauvage
11729	Heaume de gladiateur sauvage
11730	Poignes de gladiateur sauvage
11731	Bottes de gladiateur sauvage
11732	Libram de rumination
11733	Libram de constitution
11734	Libram de ténacité
11735	Couvre-oeil du Forcené
11736	Libram de résistance
11737	Libram de voracité
11742	Sac à dos de voyageur
11743	Poing de roc
11744	Poing de sang
11745	Poings de la Phalange
11746	Heaume du crâne de golem
11747	Robe de marcheur des flammes
11748	Caducée de Pyric
11749	Jambières ardentes
11750	Bâton de pyromancien
11751	Essence ardente
11752	Sang noir du Tourmenté
11753	Oeil de Kajal
11754	Diamant noir
11755	Collier de Verek
11764	Brachiales en peau cendrée
11765	Garde-poignets en pyromailles
11766	Crispins de tisse-flammes
11767	Garde-bras en plaques de braise
11768	Brassards d'incendicite
11782	Mantelet boréal
11783	Ceinturon d'acier glacé
11784	Lame de l'arbitre
11785	Bouclier du Golem de roche
11786	Pierre de la Terre
11787	Bottes Shalehusk
11802	Jambières de force volcanique
11803	Force du magma
11804	Gourde de Spraggle
11805	Marteau de rubidium
11807	Echarpe du coeur ardent
11808	Cercle de flammes
11809	Courroux des flammes
11810	Force de volonté
11811	Coeur fumant de la montagne
11812	Cape de la salamandre de feu
11813	Formule : Coeur fumant de la montagne
11814	Poings de la fournaise
11815	Main de justice
11816	Hache de guerre de Forgehargne
11817	Epée du seigneur général
11818	Clé des toilettes de Grimesilt
11819	Second souffle
11820	Armure décorée royale
11821	Jambières d'acrobate
11822	Bottes de concentration
11823	Kilt d'illumination
11824	Anneau des Cyclopes
11825	Bombinette
11826	Petit fumant
11827	Schéma : Petit fumant
11828	Schéma : Bombinette
11829	Cendres d'Un'Goro
11830	Ecaille étoilée de dimeurtrodon
11831	Ecaille étoilée de pterreurdactyle
11832	Bijou de connaissance
11833	Appât de Reine Gorishi
11834	Goudron ultra collant
11835	Cerveau de Reine Gorishi
11837	Glande olfactive Gorishi
11839	Monocle d'architecte en chef
11840	Chemise de maître bâtisseur
11841	Pantalon du grand concepteur
11842	Mantelet de géomètre en chef
11843	Reçu bancaire
11844	Rapport de Pestlezugg sur Un'Goro
11845	Sac en cuir fait main
11846	Bière spéciale de Wizbang
11847	Cape endommagée
11848	Ceinture en lin
11849	Brassards rouillés
11850	Cape courte de chauve-souris du crépuscule
11851	Tunique de charognard
11852	Jambières du vagabond
11853	Bottes de randonnée
11854	Tournevis Samophlange
11855	Clé de Tork
11856	Lame de cérémonie elfique
11857	Bâtonnet sanctifié
11858	Cape de briscard
11859	Orbe de jadelune
11860	Bâtonnet d'éclair chargé
11861	Ceinturon de représailles
11862	Anneau d'os blanc
11863	Griffes d'os blanc
11864	Lance d'os blanc
11865	Bottes de rancune
11866	Ceinture de Nagmara
11867	Gantelets exaspérants
11868	Anneau d'apnée
11869	Anneau de Sha'ni
11870	Orbe d'oubli
11871	Spallières de Snarkshaw
11872	Bottes d'Eschewal
11873	Cape des brumes éthérées
11874	Mantelet des nuages
11875	Brassards de la brise
11876	Tunique de rôdeur des plaines
11882	Jambières de voltigeur
11883	Une sacoche surprise
11884	Amict lunaires
11885	Torche ombreforge
11886	Message urgent
11887	Cache du Cercle cénarien
11888	Gants de recherche de Quintis
11889	Espauliers en écorce de fer
11902	Epée de maîtrise de Linken
11903	Panier à chat (chaton corrompu)
11904	Esprit d'Aquamentas
11905	Boomerang de Linken
11906	Fracasse-bêtes
11907	Tranche-bêtes
11908	Bottes de fouilles de l'Archéologue
11909	Ceinture d'outils d'excavateur
11910	Jambières enchâssées
11911	Jambières de la canopée
11912	Caisse de pots de Limon vides
11913	Casque de Clayridge
11914	Pot de Limon maudit vide
11915	Bouclier de Shizzle
11916	Culasse de Shizzle
11917	Chiffon à tuyères de Shizzle
11918	Gants de Grotslab
11919	Bottes de Cragplate
11920	Faux d’âme en peine
11921	Géante impétueuse
11922	Lame ensanglantée
11923	Marteau de béatitude
11924	Robe de la couronne royale
11925	Voile fantomatique
11926	Cuirasse de dispensateur de mort
11927	Jambières du Gardien éternel
11928	Sceptre royal de Thaurissan
11929	Jambières du spectre frappeur
11930	La cape neuve de l'Empereur
11931	Vengeresse d'effroi
11932	Bâton guide de sagesse
11933	Joyau impérial
11934	Sceau de l'Empereur
11935	Pierre de Magmus
11936	Ceinture de chasseur de reliques
11937	Gros sac de pièces
11938	Sac de gemmes
11939	Bracelets étincelants
11940	Collier brillant
11941	Faux documents
11942	Documents légaux
11943	Titre de propriété du viaduc de Thandol
11944	Petit butin sombrefer
11945	Anneau en sombrefer
11946	Collier d'opale rougeoyante
11947	Pot de Limon maudit rempli
11948	Pot de Limon corrompu vide
11949	Pot de Limon corrompu rempli
11950	Baies de fleur-de-vent
11951	Tubercule de navetille
11952	Souffle de dragon nocturne
11953	Pot d'échantillon pur vide
11954	Pot d'échantillon pur plein
11955	Sacoche de pots à Limon vides
11962	Bracelets de prisonnier
11963	Spallières de pénitence
11964	Masse de frappe rapide
11965	Anneau de quartz
11966	Petit sac de pièces
11967	Anneau de zircon
11968	Anneau d'ambre
11969	Anneau de jacinthe
11970	Anneau de spinel
11971	Anneau d'améthyste
11972	Anneau de carnélian
11973	Anneau d'hématite
11974	Anneau d'aigue-marine
11975	Anneau de topaze
11976	Anneau de sardonyx
11977	Anneau serpentin
11978	Anneau de jaspe
11979	Cercle de péridot
11980	Anneau d'opale
11981	Anneau de plomb
11982	Anneau viridien
11983	Anneau chromé
11984	Anneau de cobalt
11985	Anneau céruléen
11986	Anneau de thallium
11987	Anneau d'iridium
11988	Anneau de tellure
11989	Anneau de vanadium
11990	Anneau de sélénium
11991	Anneau de vif-argent
11992	Anneau vermeil
11993	Anneau de terre
11994	Bague de corail
11995	Anneau d'ivoire
11996	Anneau basaltique
11997	Anneau de pierre verte
11998	Anneau fusant
11999	Anneau de magnétite
12000	Tranche-tailleuse
12001	Anneau d'onyx
12002	Anneau marbré
12003	Bière brune naine
12004	Anneau en obsidienne
12005	Anneau granitique
12006	Anneau des steppes
12007	Anneau des clairières
12008	Anneau des savanes
12009	Anneau de la toundra
12010	Anneau de la fange
12011	Anneau des forêts
12012	Anneau des marais
12013	Anneau du désert
12014	Anneau arctique
12015	Anneau lacustre
12016	Anneau de la jungle
12017	Anneau prismatique
12018	Heaume de conservateur
12019	Talisman céruléen
12020	Pendentif de thallium
12021	Bottillons renforcés
12022	Collier d'iridium
12023	Collier de tellure
12024	Talisman de vanadium
12025	Collier de sélénium
12026	Pendentif de vif-argent
12027	Collier vermeil
12028	Collier basaltique
12029	Talisman de pierre verte
12030	Collier fusant
12031	Collier de magnétite
12032	Pendentif d'onyx
12033	Bijoux de la famille Thaurissan
12034	Collier marbré
12035	Pendentif en obsidienne
12036	Collier granitique
12037	Viande mystère
12038	Sceau de Lagrave
12039	Collier de la toundra
12040	Pendentif forestier
12041	Jambières de Windshear
12042	Collier des marais
12043	Collier du désert
12044	Pendentif arctique
12045	Pendentif lacustre
12046	Collier de la jungle
12047	Collier spectral
12048	Pendentif prismatique
12049	Armure d'acier éclissé
12050	Bottes de la brume
12051	Gantelets en laiton
12052	Anneau de la lune
12053	Anneau de pierre volcanique
12054	Anneau des démons
12055	Anneau de poussière d'étoile
12056	Anneau céleste
12057	Anneau draconien
12058	Anneau d'os démoniaque
12059	Médaillon du Conquérant
12060	Note de Shindrell
12061	Lame de rétorsion
12062	Dague de maîtrise
12064	Chaperon de maître de jeu
12065	Gardien des éléments
12066	Cape peau-de-schiste
12082	Spallières en peau de wyrm
12083	Echarpe valconienne
12102	Anneau aristocratique
12103	Etoile de Mystaria
12104	Tunique d'épines tavelées
12105	Jambières de fierté
12106	Cuirasse peau-de-roche
12107	Jambières chuchotantes
12108	Broigne basaltique
12109	Amict de lune azur
12110	Drapé de pluviomancien
12111	Gantelets volcaniques
12112	Brassards de démon des cryptes
12113	Cape de l'hélionaute
12114	Gants crépusculaires
12115	Etreinte loyale
12122	Camelote de Kum'isha
12143	Clé de Dragonspine
12144	Oeufilloscope
12162	Plans : Epée courte en fer trempé
12163	Plans : Epée d'acier lunaire
12164	Plans : Gigantesque hache en fer
12184	Chair de raptor
12185	Bicorne d'amiral de la Voile sanglante
12190	Potion de sommeil sans rêve
12191	Coffret de l'Aube argentée
12192	Coffret du Voile de brume
12202	Viande de tigre
12203	Viande de loup rouge
12204	Viande de kodo épaisse
12205	Viande d'araignée blanche
12206	Viande de crabe tendre
12207	Oeuf géant
12208	Viande de loup tendre
12209	Steak de loup
12210	Rôti de raptor
12211	Côtes de loup épicées
12212	Ragoût de la jungle
12213	Tourte surprise
12214	Ragoût mystère
12215	Ragoût épais de kodo
12216	Chili de crabe épicé
12217	Chili de souffle de dragon
12218	Omelette monstrueuse
12219	Sceau d'ascension non décoré
12220	Bracelets élémentaires intacts
12223	Aile de chauve-souris charnue
12224	Aile de chauve-souris croustillante
12225	Canne à pêche de la famille Blump
12226	Recette : Aile de chauve-souris croustillante
12227	Recette : Steak de loup
12228	Recette : Rôti de raptor
12229	Recette : Côtes de loup épicées
12230	Echantillon de Limon de Gangrebois
12231	Recette : Ragoût de la jungle
12232	Recette : Tourte surprise
12233	Recette : Ragoût mystère
12234	Echantillon corrompu de Gangrebois
12235	Echantillon de Limon d'Un'Goro
12236	Echantillon pur d'Un'Goro
12237	Belle chair de crabe
12238	Mérou de Sombrivage
12239	Recette : Chili de souffle de dragon
12240	Recette : Ragoût épais de kodo
12241	Oeuf de dragon collecté
12242	Os de créature marine
12243	Griffe flamboyante
12247	Couteau à lame large
12248	Miséricorde audacieuse
12249	Hache impitoyable
12250	Hache de minuit
12251	Grand bâton
12252	Bâton de protection
12253	Cape rouge brillante
12254	Cape bien huilée
12255	Jambières pâles
12256	Jambières en étoffe cendrée
12257	Ceinture lourde abimée
12258	Ceinture à boucle serpentine
12259	Dague d'acier luisante
12260	Lame dorée flamboyante
12261	Plans : Lame dorée flamboyante
12262	Cage de jeune worg vide
12263	Jeune worg en cage
12264	Caisse de worg
12282	Hache de guerre usée
12283	Essence de Rejeton
12284	Draco-Incarcinatrix 900
12286	Prototype d'Oeufilloscope
12287	Module collectronique
12288	Limon corrompu en boîte
12289	Restes de tortue de mer
12291	Echantillon de Limon mélangé
12292	Boîte aux marques étranges
12293	Fil d'or fin
12295	Jambières de la milice du peuple
12296	Eclat de la milice du peuple
12299	Gants toilés
12300	Orbe d'énergie draconique
12301	Clé de la cage en bambou
12302	Rênes de sabre-de-givre
12303	Rênes de sabre-de-nuit
12323	Sceau d'ascension brut
12324	Sceau d'ascension forgé
12325	Rênes de léopard
12326	Rênes de tigre à dents de sabre fauve
12327	Rênes de tigre à dents de sabre doré
12330	Cor du loup rouge
12334	Eclats cognegivre
12335	Gemme de Smolderthorn
12336	Gemme de Pierre-du-pic
12337	Gemme de Bloodaxe
12339	Cadeau de Vaelan
12341	Echantillon de fruit des Noirbois
12342	Echantillon de céréales des Noirbois
12343	Echantillon de noix des Noirbois
12344	Sceau d'ascension
12345	Affaires de Bijou
12346	Bol de purification vide
12347	Bol de purification rempli
12349	Prélèvement de la Bondissante
12350	Tube de prélèvement vide
12351	Cor du loup arctique
12352	Fermoir de Doomrigger
12353	Bride d'étalon blanc
12354	Bride de palomino
12355	Talisman de corruption
12356	Oeuf de wyverne de Haut-perchoir
12358	Tablette de Darkstone
12359	Barre de thorium
12360	Barre d'arcanite
12361	Saphir bleu
12363	Cristal des arcanes
12364	Énorme émeraude
12365	Pierre dense
12366	Fourrure épaisse de yéti
12367	Corne de yéti en parfait état
12368	Gambit de l’aube
12369	Sceptre de Vectus
12382	Clé de la ville
12383	Plume de Chouettard lunaire
12384	Cache de Mau'ari
12402	Oeuf antique
12404	Pierre à aiguiser dense
12405	Armure en thorium
12406	Ceinture en thorium
12408	Brassards en thorium
12409	Bottes en thorium
12410	Heaume en thorium
12411	Troisième Tablette Mosh'aru
12412	Quatrième Tablette Mosh'aru
12414	Jambières en thorium
12415	Cuirasse radieuse
12416	Ceinture radieuse
12417	Diadème radieux
12418	Gantelets radieux
12419	Bottes radieuses
12420	Jambières radieuses
12422	Pansière impériale
12424	Ceinture impériale en plaques
12425	Brassards impériaux en plaques
12426	Bottes impériales en plaques
12427	Heaume impérial en plaques
12428	Epaulières impériales en plaques
12429	Jambières impériales en plaques
12430	E'ko de sabre-de-givre
12431	E'ko des Tombe-hiver
12432	E'ko de Croc acéré
12433	E'ko d'Indomptable
12434	E'ko de Noroît
12435	E'ko de Chardon de glace
12436	E'ko de Cognegivre
12437	Caisse de Ridgewell
12438	Lettre de Tinkee
12440	Magic Knucklebone (DND)
12442	Charm Pouch (DND)
12443	Knucklebone Pouch (DND)
12444	Corne intacte de Noroît
12445	Paquet de Felnok
12446	Mousquet d'Anvilmar
12447	Arc des chardons
12448	Carabine de chasse légère
12449	Arc primitif
12450	Rafale de Juju
12451	Pouvoir de Juju
12455	Braise de Juju
12457	Frisson de Juju
12458	Fourberie de Juju
12459	Fuite de Juju
12460	Puissance de Juju
12462	Etreinte du serpent des vents
12463	Boucher drakecroc
12464	Serres du Sang igné
12465	Drapé crépusculaire
12466	Corde Cime-de-l'aube
12467	Oeuf étrange
12468	Baguette de Chilton
12469	Mutilateur
12470	Protège-chevilles de traqueuse des sables
12471	Cane du marcheur du désert
12472	Thermomètre de Krakle
12522	Gants de vol de Bingles
12524	Amulette de la plume bleue
12525	Fournitures de Jaron
12527	Brise-côtes
12528	Marteau du Juge
12529	Caisse de Couveuse
12530	Oeuf d'araignée du pic
12531	Aiguille flamboyante
12532	Aiguille du sculpte-pierre
12533	Pique de fortune
12534	Tête d'Omokk
12535	Droit-fil de Forge-ruine
12542	Habit du bûcher funéraire
12543	Pierre chantante d'Ironforge
12544	Résolution de Thrall
12545	Oeil d'Orgrimmar
12546	Crispins aristocratiques
12547	Poigne de Mar Alom
12548	Volonté de Magni
12549	Tuméfiante
12550	Menottes de golem runiques
12551	Cape du bouclier de pierre
12552	Houppelande coupe-braise
12553	Bottes du marcheur vif
12554	Gants du héraut exalté
12555	Bottes du chasseur de guerre
12556	Bottes de la grande prêtresse
12557	Spallières d'acier ébène
12558	Collier de plumes bleues
12562	Importants documents Blackrock
12563	Ordres du seigneur de guerre Goretooth
12564	Engagement d'assassin
12565	Panier à chaton de Winna
12566	Flacon renforcé
12567	Flacon rempli
12582	Keris de Zul'Serak
12583	Massacreuse Blackhand
12584	Epée longue de connétable
12585	Médaillon de Stormwind
12586	Glande à venin immature
12587	Oeil de Rend
12588	Epaulières de pics d'os
12589	Echarpe de Dustfeather
12590	Trucidante
12592	Lame noire de Shahram
12602	Déflecteur draconien
12603	Tunique de l'étreinte nocturne
12604	Tiare du feu des étoiles
12605	Ecrâneur serpent
12606	Ceinturon cristallisé
12607	Ecaille chromatique brillante
12608	Tablier de boucher
12609	Echarpe de vision polychromatique
12610	Epaulières runiques en plaques
12611	Bottes runiques en plaques
12612	Heaume runique en plaques
12613	Cuirasse runique
12614	Jambières runiques en plaques
12615	Tunique en mailles sauvages
12616	Bottes en mailles sauvages
12617	Epaulières en mailles sauvages
12618	Cuirasse en thorium enchanté
12619	Jambières en thorium enchanté
12620	Heaume en thorium enchanté
12621	Fourche démoniaque
12622	Viande de Croc acéré
12623	Viande de Noroît
12624	Cotte de mailles Ronce-sauvage
12625	Epaulières du point du jour
12626	Crispins funéraires
12627	Déplaceur temporel
12628	Cuirasse démoniaque
12630	Tête de Rend Blackhand
12631	Gantelets en plaques de feu
12632	Gantelets tempêtes
12633	Heaume d'âme blanche
12634	Ceinturon de ciseleur
12635	Parchemin simple
12636	Heaume du grand chef
12637	Gantelets de Backusarian
12638	Montre d'Andorhal
12639	Gantelets de la forteresse
12640	Heaume Coeur-de-lion
12641	Cotte de mailles invulnérable
12642	Orbe infernal purifié
12643	Caillou dense
12644	Silex à aiguiser dense
12645	Pointe de bouclier en thorium
12646	Emeraude d'Infus
12647	Rubis de Felhas
12648	Esprit de gangrechien emprisonné
12649	Esprit infernal emprisonné
12650	Atténuateur en phase
12651	Corbeau noir
12652	Rapport de reconnaissance de Bijou
12653	Arracheur
12654	Tir maudit
12655	Barre de thorium enchanté
12662	Rune démoniaque
12663	Branche de chêne glyphée
12682	Plans : Armure en thorium
12683	Plans : Ceinture en thorium
12684	Plans : Brassards en thorium
12685	Plans : Ceinture radieuse
12687	Plans : Epaulières impériales en plaques
12688	Plans : Ceinture impériale en plaques
12689	Plans : Cuirasse radieuse
12690	Plans : Bracelets impériaux en plaques
12691	Plans : Cotte de mailles de Ronce-sauvage
12692	Plans : Pointe de bouclier en thorium
12693	Plans : Bottes en thorium
12694	Plans : Heaume en thorium
12695	Plans : Gantelets radieux
12696	Plans : Cuirasse démoniaque
12697	Plans : Bottes radieuses
12698	Plans : Epaulières du point du jour
12699	Plans : Gantelets en plaques de feu
12700	Plans : Bottes impériales en plaques
12701	Plans : Heaume impérial en plaques
12702	Plans : Diadème radieux
12703	Plans : Gantelets tempêtes
12704	Plans : Jambières en thorium
12705	Plans : Pansière impériale
12706	Plans : Epaulières runiques en plaques
12707	Plans : Bottes runiques en plaques
12708	Caisses de ravitaillement de la Croisée
12709	Dépeceuse de Pépin
12710	Morceau de chair de la Bête luminescent
12711	Plans : Heaume d'âme blanche
12712	Mojo de Warosh
12713	Plans : Jambières radieuses
12714	Plans : Heaume runique en plaques
12715	Plans : Jambières impériales en plaques
12716	Plans : Heaume du grand chef
12717	Plans : Heaume Coeur-de-lion
12718	Plans : Cuirasse runique
12719	Plans : Jambières runiques en plaques
12720	Plans : Gantelets de la forteresse
12721	Demi-charme porte-bonheur
12722	Autre demi-charme porte-bonheur
12723	Charme porte-bonheur
12724	Colis de Janice
12725	Plans : Heaume en thorium enchanté
12726	Plans : Jambières en thorium enchanté
12727	Plans : Cuirasse en thorium enchanté
12728	Plans : Cotte de mailles invulnérable
12730	Parchemin de Warosh
12731	Peau de la Bête en parfait état
12732	Agave d’incendia
12733	Viande de sabre-de-givre sacrée
12734	Fil écarlate enchanté
12735	Couture d'Abomination effilochée
12736	Liquide d’embaumement de Murmegivre
12737	Herbe des ténèbres
12738	Clé des toilettes de Dalson
12739	Clé du cabinet de Dalson
12740	Cinquième tablette Mosh'aru
12741	Sixième tablette Mosh'aru
12752	Coiffe du savant écarlate
12753	Peau des ombres
12756	Jambières d'Arcana
12757	Cuirasse carnassière
12762	Secret des plans
12763	Fruit du néant Un'Goro
12764	Epée de guerre en thorium
12765	Note secrète n°1
12766	Note secrète n°2
12768	Note secrète n°3
12769	Bois morne taillé
12770	Renseignements de Bijou
12771	Flacon d'eau de feu vide
12772	Marteau damasquiné en thorium
12773	Hachette ornée en thorium
12774	Courroux de l'aube
12775	Grande hache en thorium
12776	Marteau de guerre enchanté
12777	Rapière flamboyante
12778	Coffre de documents
12779	Lame runique
12780	Ordres du général Drakkisath
12781	Sérénité
12782	Corruption
12783	Crève-coeur
12784	Déchireuse en arcanite
12785	Poudre d'incendia
12790	Championne en arcanite
12791	Tesson du tavernier
12792	Marteau volcanique
12793	Tunique de mixologue
12794	Marteau-tempête ouvragé
12795	Serre de sang
12796	Marteau des Titans
12797	Gardienne de givre
12798	Annihilateur
12799	Grande opale
12800	Diamant d'Azeroth
12802	Lance noire
12803	Essence de vie
12804	Mojo puissant
12805	Orbe de feu
12806	Plastron couvert de runes inachevé
12807	Bannière du Fléau
12808	Essence de non-mort
12809	Pierre de gardien
12810	Cuir enchanté
12811	Orbe de piété
12812	Gantelets en plaques inachevés
12813	Flacon de Vase mystérieuse
12814	Flammes en bouteille
12815	Torche-balise
12816	Plans : Epée de guerre en thorium
12817	Plans : Bois morne taillé
12818	Plans : Marteau damasquiné en thorium
12819	Plans : Hachette ornée en thorium
12820	Eau de feu des Tombe-hiver
12821	Plans : Courroux de l'aube
12822	Gouttelette d'Horreur toxique
12823	Plans : Grande hache en thorium
12824	Plans : Marteau de guerre enchanté
12825	Plans : Rapière flamboyante
12826	Plans : Lame runique
12827	Plans : Sérénité
12828	Plans : Marteau volcanique
12829	Caisse des Tombe-hiver
12830	Plans : Corruption
12831	Plans : Serre de sang
12832	Plans : Lance noire
12833	Plans : Marteau des Titans
12834	Plans : Championne en arcanite
12835	Plans : Annihilateur
12836	Plans : Gardienne de givre
12837	Plans : Marteau-tempête ouvragé
12838	Plans : Déchireuse en arcanite
12839	Plans : Crève-coeur
12840	Pierre du Fléau des serviteurs
12841	Pierre du Fléau des envahisseurs
12842	Journal mal écrit
12843	Pierre du Fléau des corrupteurs
12844	Marque de valeur de l'Aube d'argent
12845	Médaillon de foi
12846	Brevet de l'Aube d'argent
12847	Pique tachée d'âme
12848	Pique tachée de sang
12849	Sac embrassé par un démon
12871	Carapace chromatique
12884	Sabot d'Arnak
12885	Poupée de Pamela
12886	Tête de la poupée de Pamela
12887	Flanc gauche de la poupée de Pamela
12888	Flanc droit de la poupée de Pamela
12891	Pique de Jaron
12894	Alliance de Joseph
12895	Cuirasse du vol chromatique
12896	Fragment de la première relique
12897	Fragment de la deuxième relique
12898	Fragment de la troisième relique
12899	Fragment de la quatrième relique
12900	Annales de Darrowshire
12903	Jambières des duellistes chromatiques
12904	Chapeau pandit super spécial de Shawn
12905	Cape du feu de brousse
12906	Eau de Puits de lune purifiée
12907	Eau de Puits de lune corrompue
12922	Gourde vide
12923	Ecaille d'Awbee
12924	Bougie de rituel
12925	Peau de serpent d'Arikara
12926	Anneau enflammé
12927	Epaulières de précision
12928	Yéti mécanique d'Umi
12929	Talisman Emberfury
12930	Pipeau de bruyère
12935	Jambières du Chef de guerre
12936	Bracières du champ d'honneur
12938	Sang des héros
12939	Gardienne tribale de Dal'Rend
12940	Charge sacrée de Dal'Rend
12942	Clé de la cage des panthères
12945	Cuissardes des duellistes chromatiques
12946	Hypercapaciteur bidulotron
12947	Anneau audacieux d'Alex
12952	Crâne de Gyth
12953	Camail de Dragoneye
12954	Libram de Davil
12955	Bouclier de Redpath
12956	Crâne d'Horgus
12957	Epée brisée de Marduk
12958	Recette : Transmutation d'arcanite
12960	Coiffure de plumes tribale
12963	Jambières de maître-lames
12964	Jambières de Tristam
12965	Jambières des voiles spirituels
12966	Garde-bras de la brume noire
12967	Cape de la lune sanguine
12968	Cape de tisseur de givre
12969	Masse suintante
12970	Harnois de cérémonie de général
12973	Boulet de canon écarlate
12974	Pourfendeuse noire
12975	Hache de prospecteur
12976	Lame Ironpatch
12977	Gants poing-de-mage
12978	Ceinture des tempêtes
12979	Cape coupe-feu
12982	Bottillons en mailles d'argent
12983	Gourdin Rakzur
12984	Arcanien
12985	Anneau de défense
12987	Jambières des ombres
12988	Tunique de vision stellaire
12989	Pique des Gargouilles
12990	Lacératrice
12992	Lame brûlante
12994	Gantelets de Thorbia
12996	Anneau de purification
12997	Bouclier rougeoyant
12998	Mantelet de magicien
12999	Poignets aile-de-drake
13000	Bâton des grandes arcanes
13001	Anneau de damoiselle
13002	Pendentif de dame Alizabeth
13003	Hache de guerre du Seigneur Alexander
13004	Torche d'Austen
13005	Couverture d'Amy
13006	Masse de McGowan
13007	Cape des flammes magiques
13008	Pantalon de Dalewind
13009	Peau du roi des vaches
13010	Jambières des rêveurs
13011	Ceinture bordée d'argent
13012	Brassards de Yorgen
13013	Mantelet d'ancien sorcier
13014	Hache de Rin'ji
13015	Serathil
13016	Ensanglante
13017	Hache de guerre pieuse
13018	Fendoir de l'Exécuteur
13019	Arc court des harpies
13020	Arc de frappe céleste
13021	Aiguilloneur
13022	Arc long d'Aile-gryphon
13023	Arc long d'Eaglehorn
13024	Ecraseur de Beazel
13025	Masse de mort-bois
13026	Lumière des cieux
13027	Briseur d'os
13028	Marteau des songes
13029	Cristal d'Umbral
13030	Os de basilic
13031	Orbe de Mistmantle
13032	Epée de corruption
13033	Lame zélée
13034	Rapière vivace
13035	Tranche-serpent
13036	Lame des assassins
13037	Dardeur cristallin
13038	Féroce
13039	Fendeuse de crâne
13040	Perce-coeur
13041	Lame de gardien
13042	Epée du Magistrat
13043	Lame des Titans
13044	Pourfendeuse de démons
13045	Marteau visqueux
13046	Frappeuse de Blanchard
13047	Branche de l'Arbre-monde
13048	Menaceur
13049	Claymore du décanat
13051	Fureur sorcière
13052	Trancheuse martiale
13053	Jugement dernier
13054	Découpeuse sinistre
13055	Mâche-les-os
13056	Excitante
13057	Pique sanglante
13058	Pointe de Khoo
13059	Courrouçante
13060	Aiguillon
13062	Bâton du tonnerre
13063	Météorique
13064	Boute-flammes de Jaina
13065	Baguette d'Allistarj
13066	Spallières de tueur de wyrm
13067	Armure hydralique
13068	Jambières en obsidienne
13070	Bottes en écailles de Saphiron
13071	Poings d'Hakoo en plaques
13072	Gantelets poigne-de-pierre
13073	Casque de Mugthol
13074	Jambières du golem
13075	Jambières de l’Aile redoutable
13076	Brassards de tueur de géant
13077	Ceinturon d'Uther
13079	Bouclier de Thorsen
13080	Caresse de la Veuve
13081	Bouclier des forts
13082	Targe des montagnes
13083	Ecu de la famille Garrett
13084	Collier du Kaléidoscope
13085	Collier de l'horizon
13086	Rênes de sabre-de-givre de Berceau-de-l'Hiver
13087	Amulette des fiers
13088	Charme de Gazlowe
13089	Pendentif de Skibi
13090	Plastron de l'élu
13091	Médaillon du connétable Morris
13093	Anneau de force spirituelle
13094	Le ferret de la reine
13095	Anneau d'assaut
13096	Anneau du Hiérophante
13097	Anneau foudroyant
13098	Anneau de puissance mortelle
13099	Sandales du lapin blanc
13100	Bottes de Furen
13101	Bottes de course lupine
13102	Grâce de Cassandre
13103	Ailettes de l'Araignée venimeuse
13105	Ceinture de Sutarn
13106	Bracelets magiques luminescents
13107	Crispins du magicrâne
13108	Manteau de frappe du tigre
13109	Cape de la flamme noire
13110	Harnais de peur lupine
13111	Sandales des insurgés
13112	Casque ailé
13113	Coiffure de Feathermoon
13114	Jambières du Fléau des trolls
13115	Mantelet de berger
13116	Spallières de l'invisible
13117	Echarpe d'Ogron
13118	Echarpe serpentine
13119	Brassards de kodo enchantés
13120	Brassards de Deepfury
13121	Aile du jeune dragonnet
13122	Cape du fantôme noir
13123	Armure de marcherêve
13124	Bottes en écailles de ravasaure
13125	Bottes en mailles elfiques
13126	Gantelets de guerroyeur
13127	Couronne du Froid destructeur
13128	Heaume de Bergg
13129	Jambières Crins-de-feu
13130	Jambières de Windrunner
13131	Mantelet de nacrétoile
13132	Epaulières squelettiques
13133	Epaulettes drakefeu
13134	Ceinture du gladiateur
13135	Garde-bras seigneuriaux
13136	Sarbacane du petit Timmy
13137	Tisseur de fer
13138	L'Extincteur
13139	Perce-boyau
13140	Clé rouge sang
13141	Dent de Gnarr
13142	Ceinturon de Brigam
13143	Marque du seigneur dragon
13144	Ceinture de sérénité
13145	Enorme ceinture ogre
13146	Fusil lance-obus
13148	Congélatrice
13149	Tome d'invocation Eldarathian Vol. 1
13151	Les études Mystiques d'Hor'ank
13152	L'histoire sans conclusion
13153	Tom de Mal'cin Vorail
13154	Etudes des arcanes de Jael'marin
13155	Crâne résonant
13156	Cristal mystique
13157	Crâne fétide
13158	Paroles du Grand Chef
13159	Poussière d'os
13161	Bâton du refuge
13162	Griffes de rapineur
13163	Grande fossoyeuse
13164	Coeur de l'Ecaille
13166	Epaulières Claque-feu
13167	Poing d'Omokk
13168	Harnois du roi-chaman
13169	Jambières des grands esprits
13170	Pantalon du voile céleste
13171	Briquet de Smokey
13172	Tabac de Grimm
13173	Hache volante
13174	Echantillon de chair pestiférée
13175	Arc de Voone
13176	Donnée du Fléau
13177	Talisman d'évasion
13178	Anneau de rosette
13179	Garde-bras coeur-d'airain
13180	Eau sacrée de Stratholme
13181	Gants en peau de démon
13182	Lame phasique
13183	Crachevenin
13184	Manicles frôle-chute
13185	Mantelet du prophète démembré
13186	Bouteille d'échantillon du Champ de Felstone vide
13187	Bouteille des larmes de Dalson vide
13188	Bouteille vide du Repaire putride
13189	Bouteille vide de la Flétrissure de Gahrron
13190	Bouteille du Champ de Felstone remplie
13191	Bouteille des Larmes de Dalson remplie
13192	Bouteille du Repaire putride remplie
13193	Bouteille de la Flétrissure de Gahrron remplie
13194	Clé du chaudron du Champ de Felstone
13195	Clé du chaudron des Larmes de Dalson
13196	Clé du chaudron de la Flétrissure de Gahrron
13197	Clé du chaudron du Repaire putride
13198	Ecraseur de Hurd
13199	Manchettes de Cassecrête
13202	Annales complètes de Darrowshire
13203	Cape d'éveil aux armes
13204	Bashguuder
13205	Protecteur de Rhombeard
13206	Jambières du tondeur de loups
13207	Tête du Seigneur des ténèbres Fel'dan
13208	Garde-bras du hurleur pâle
13209	Sceau de l'Aube
13210	Bottes du loup terrifiant
13211	Brassards griffes-tranchantes
13212	Collier clouté d'Halycon
13213	Oeil de Couveuse
13216	Couronne du pénitent
13217	Anneau du pénitent
13218	Croc de l'araignée de cristal
13223	Sacoche du Messager de Stratholme
13243	Défenseur de l'Aube d'argent
13244	Gantelets dorés
13245	Carapace de Kresh
13246	Vengeresse d'argent
13247	Coffre de l'Intendant Zigris
13248	Arquebuse à chevrotines
13249	Croisé d'argent
13250	Tête de Balnazzar
13251	Tête du baron Rivendare
13252	Ceinturon de funambule
13253	Mains de puissance
13254	Bouclier astral
13255	Gantelets du trait précis
13257	Spallières de runes démoniaques
13258	Gantelets en peau-mâchefer
13259	Bottes nervurées
13260	Bottes de danseur du vent
13261	Globe de D'sak
13262	Porte-cendres
13282	Bottes des prophètes
13283	Anneau de magus
13284	Bottes de guerre agile
13285	Tranchoir rochenoire
13286	Transperçante
13287	Patron : Harnais en peau de raptor
13288	Patron : Ceinture en peau de raptor
13289	Libérateur d'Egan
13302	Clé de la boîte à lettres de l'allée du Marché
13303	Clé de la boîte à lettres de la place des Croisés
13304	Clé de la boîte à lettres de l'allée du Festival
13305	Clé de la boîte à lettres de la place des Anciens
13306	Clé de la boîte à lettres de la place du Roi
13307	Clé de la boîte à lettres d’Ezra Grimm
13308	Schéma : Pare-glace
13309	Schéma : Espingole amoureusement construite
13310	Schéma : Lunette de précision
13311	Schéma : Petit dragon mécanique
13313	Textes sacrés des Bien-nés
13314	Etreinte d'Alanna
13317	Sifflet de raptor ivoire
13320	Catalyseur des arcanes
13321	Mécanotrotteur vert
13322	Mécanotrotteur brut
13323	Mécanotrotteur violet
13324	Mécanotrotteur rouge & bleu
13325	Mécanotrotteur vert fluorescent
13326	Mécanotrotteur blanc Mod A
13327	Mécanotrotteur bleu clair Mod A
13328	Bélier noir
13329	Bélier de givre
13330	Sac de radis de Derek
13331	Cheval squelette rouge
13332	Cheval squelette bleu
13333	Cheval squelette bai
13334	Cheval de guerre squelette vert
13335	Rênes de destrier de la mort
13340	Cape du baron noir
13342	Familier poisson
13343	Familier pierre
13344	Gantelets dracoriens
13345	Sceau de Rivendare
13346	Robe de l'exalté
13347	Cristal de Zin-Malor
13348	Fléau démoniaque
13349	Sceptre de l'Impie
13350	Insigne de la Garde noire
13351	Tablier du Forgeur de marteaux cramoisi
13352	Pierre du serpent de Vosh'gajin
13353	Livre des morts
13354	Résonateur ectoplasmique
13356	Intensificateur somatique
13357	Agitateur osseux
13358	Epaulières Langue-de-wyrm
13359	Heaume de tyrannie
13360	Don des magi elfes
13361	Déchireuse de Stratholme
13362	Lettre du front
13363	Proclamation municipale
13364	Publicité d’Ezra Grimm
13365	Convocation au conseil municipal
13366	Jouet ingénieux
13367	Cadeau emballé
13368	Lacéreuse
13369	Bottines des esprits enflammés
13370	Focalisateur vitré
13371	Père des flammes
13372	Cravache d'esclavagiste
13373	Anneau de chair
13374	Mantelet de voleur d'âme
13375	Ecu de vindicte
13376	Cape du tribunal royal
13377	Boulets de canon miniatures
13378	Chemisette de l'oiseau chanteur
13379	Piccolo des feux ardents
13380	Obusier portatif de Willey
13381	Bottes de maître canonnier
13382	Messager du boulet de canon
13383	Jambières du ménestrel
13384	Ceinturon arc-en-ciel
13385	Tome de connaissance
13386	Cape d'archiviste
13387	Ceinturon de prévoyance
13388	Tunique du maître de poste
13389	Pantalon du maître de poste
13390	Bandeau du maître de poste
13391	Bottes du maître de poste
13392	Sceau du maître de poste
13393	Broyeur de Malown
13394	Etreinte glaciale de Krân
13395	Griffes d'osselets de Krân
13396	Idole glaciale de Krân
13397	Cape de la gargouille peau-de-pierre
13398	Bottes du Hurleur
13399	Serre de dilacération
13400	Protège-bras du sadique
13401	La main cruelle de Timmy
13402	Galoshe de Timmy
13403	Collet de Noirsang
13404	Masque du Condamné
13405	Epaulières de hurleur Plaie-de-nuit
13408	Brise-âme
13409	Brassards des larmes
13422	Anguille pierre-écaille
13423	Huile de pierre-écaille
13442	Potion de rage puissante
13443	Potion de mana excellente
13444	Potion de mana majeure
13445	Elixir de défense excellente
13446	Potion de soins majeure
13447	Elixir des Sages
13448	Titre de propriété de Caer Darrow
13450	Titre de propriété de Southshore
13451	Titre de propriété de Moulin-de-Tarren
13452	Elixir de la Mangouste
13453	Elixir de Force de brute
13454	Elixir des arcanes supérieur
13455	Potion de Bouclier de pierre supérieure
13456	Potion de protection contre le Givre supérieure
13457	Potion de protection contre le Feu supérieure
13458	Potion de protection contre la Nature supérieure
13459	Potion de protection contre l'Ombre supérieure
13460	Potion de protection contre le Sacré supérieure
13461	Potion de protection contre les Arcanes supérieure
13462	Potion de purification
13463	Feuillerêve
13464	Sansam doré
13465	Sauge-argent des montagnes
13466	Fleur de peste
13467	Calot de glace
13468	Lotus noir
13469	Tête de Weldon Barov
13470	Tête d'Alexi Barov
13471	Titre de propriété de Brill
13473	Porte-bonheur de Felstone
13474	Fusil du fermier Dalson
13475	Alliance de la famille Dalson
13476	Recette : Potion de rage puissante
13477	Recette : Potion de mana excellente
13478	Recette : Elixir de Défense excellente
13479	Recette : Elixir des Sages
13480	Recette : Potion de Soins majeure
13481	Recette : Elixir de Force de brute
13482	Recette : Transmutation de l'Air en Feu
13483	Recette : Transmutation du Feu en Terre
13484	Recette : Transmutation de la Terre en Eau
13485	Recette : Transmutation de l'Eau en Air
13486	Recette : Transmutation du Non-mort en Eau
13487	Recette : Transmutation de l'Eau en Non-mort
13488	Recette : Transmutation de la Vie en Terre
13489	Recette : Transmutation de la Terre en Vie
13490	Recette : Potion de Bouclier de pierre supérieure
13491	Recette : Elixir de la Mangouste
13492	Recette : Potion de Purification
13493	Recette : Elixir des arcanes supérieur
13494	Recette : Potion de protection contre le Feu supérieure
13495	Recette : Potion de protection contre le Givre supérieure
13496	Recette : Potion de protection contre la Nature supérieure
13497	Recette : Potion de protection contre les Arcanes supérieure
13498	Jambières de maître forgeron
13499	Recette : Potion de protection contre l'Ombre supérieure
13500	Recette : Potion de protection contre le Sacré supérieure
13501	Recette : Potion de mana majeure
13502	Ceinturon de maître forgeron
13503	Pierre des alchimistes
13505	Lame runique du baron Rivendare
13506	Flacon de pétrification
13507	Rapport du garde-falaise Longhorn
13508	Oeil d'Arachnida
13509	Etreinte de prévoyance
13510	Flacon des Titans
13511	Flacon de sagesse distillée
13512	Flacon de pouvoir suprême
13513	Flacon de résistance chromatique
13514	Complainte de la Banshee
13515	Eclairs de Ramstein
13517	Recette : Pierre des alchimistes
13518	Recette : Flacon de pétrification
13519	Recette : Flacon des Titans
13520	Recette : Flacon de sagesse distillée
13521	Recette : Flacon de pouvoir suprême
13522	Recette : Flacon de résistance chromatique
13523	Sang des innocents
13524	Crâne des ténèbres ardentes
13525	Doigts du sombre lien
13526	Ceinturon ardent
13527	Jambières des flammes
13528	Brassards du vide ténébreux
13529	Carcasse de Nerub'enkan
13530	Bottines de Fangdrip
13531	Jambières des cryptes
13532	Griffes de la sombre fileuse
13533	Espauliers décorés d'eaux-fortes
13534	Doigt de Banshee
13535	Cafetan fantomatique de la Main froide
13536	Corne de l'éveil
13537	Brassards glace-cuir
13538	Epaulettes du hurlevent
13539	Toucher de la banshee
13542	Boîte démoniaque
13544	Essence spectrale
13545	Crustacé
13546	Ventre-rouge
13562	Cadavre de Trey Lightforge
13582	Laisse de zergling
13583	Collier de panda
13584	Pierre de Diablo
13585	Livre du souvenir
13602	Pierre de sort supérieure
13603	Pierre de sort majeure
13624	Souvenir lié
13626	Tête humaine de Ras Murmegivre
13699	Pierre de feu
13700	Pierre de feu supérieure
13701	Pierre de feu majeure
13702	Herbe maléfique
13703	Os de kodo
13704	Clé squelette
13724	Biscuit enrichi en manne
13725	Sac des horreurs de Krastinov
13752	Souvenir lié
13754	Barracuda luisant cru
13755	Calmar hivernal
13756	Perche estivale crue
13757	Anguille électrique
13758	Rouget cru
13759	Lutjan nagenuit cru
13760	Saumon solécaille cru
13761	Oeufs congelés
13810	Fruit solaire béni
13811	Collier de l'Aube
13812	Anneau de l'Aube
13813	Jus de Fruit solaire béni
13815	Une rune
13816	Epée longue fine
13817	Grande épée effilée
13818	Hache dentelée
13819	Hache de guerre équilibrée
13820	Masse récalcitrante
13821	Maillet massif
13822	Dague d'épines
13823	Bâton de guerre massacreur
13824	Arc long recourbé
13825	Mousquet chargé
13842	Matin automnal/hivernal
13843	Après-midi automnal/hivernal
13844	Soirée automnale/hivernale
13845	Nuit automnale/hivernale
13846	Matin printanier/estival
13847	Après-midi printanier/estival
13848	Soirée printanière/estivale
13849	Nuit printannière/estivale
13850	Munitions de Rumbleshot
13851	Côtes de loup épicées
13852	Les ordres du Grand croisé
13853	Chair de Ver putride
13856	Ceinture en étoffe runique
13857	Tunique en étoffe runique
13858	Robe en étoffe runique
13860	Cape en étoffe runique
13863	Gants en étoffe runique
13864	Bottes en étoffe runique
13865	Pantalon en étoffe runique
13866	Bandeau en étoffe runique
13867	Epaulières en étoffe runique
13868	Robe tisse-givre
13869	Tunique tisse-givre
13870	Gants tisse-givre
13871	Pantalon tisse-givre
13872	Fagot de bois
13873	Clé de la Chambre des visions
13874	Caisse lourde
13875	Coffre à fermetures en fer
13876	Mérou de 40 livres
13877	Mérou de 47 livres
13878	Mérou de 53 livres
13879	Mérou de 59 livres
13880	Mérou de 68 livres
13881	Rouget boursouflé
13882	Rouget de 42 livres
13883	Rouget de 45 livres
13884	Rouget de 49 livres
13885	Rouget de 34 livres
13886	Rouget de 37 livres
13887	Rouget de 52 livres
13888	Homard Pince-noire
13889	Saumon Blanchécaille cru
13890	Poisson cuirassé
13891	Saumon boursouflé
13892	Kombobulateur Kodo
13893	Grand barracuda cru
13895	Dangui de cérémonie
13896	Hanbok nuptial vert foncé
13897	Hanbok traditionnel blanc
13898	Dangui royal
13899	Hanbok traditionnel rouge
13900	Hanbok nuptial vert
13901	Saumon de 15 livres
13902	Saumon de 18 livres
13903	Saumon de 22 livres
13904	Saumon de 25 livres
13905	Saumon de 29 livres
13906	Saumon de 32 livres
13907	Homard de 7 livres
13908	Homard de 9 livres
13909	Homard de 12 livres
13910	Homard de 15 livres
13911	Homard de 19 livres
13912	Homard de 21 livres
13913	Homard de 22 livres
13914	Barracuda de 70 livres
13915	Barracuda de 85 livres
13916	Barracuda de 92 livres
13917	Barracuda de 103 livres
13918	Coffre à fermetures renforcées
13920	Ecaille de dragon luisante
13926	Perle dorée
13927	Barracuda luisant cuit
13928	Calmar grillé
13929	Perche fumée
13930	Filet de rouget
13931	Soupe de lutjan nagenuit
13932	Saumon solécaille poché
13933	Ragoût de homard
13934	Steak de barracuda
13935	Pain de saumon
13937	Charge du maître
13938	Stylet d'os
13939	Recette : Jaune-queue tacheté
13940	Recette : Barracuda luisant cuit
13941	Recette : Filet de rouget
13942	Recette : Calmar grillé
13943	Recette : Perche fumée
13944	Cuirasse de la pierre tombale
13945	Recette : Soupe de lutjan nagenuit
13946	Recette : Saumon solécaille poché
13947	Recette : Ragoût de homard
13948	Recette : Steak de barracuda
13949	Recette : Pain de saumon
13950	Lanière de détention
13951	Protège-bras de vigueur
13952	Trancheuse glaciale
13953	Silencieuse
13954	Bottes verdoyantes
13955	Epaulières de forme-pierre
13956	Etreinte d'Andros
13957	Tranche-gargouilles
13958	Menottes de Wyrmthalak
13959	Corset d'Omokk
13960	Coeur du démon
13961	Muselière d'Halycon
13962	Bande de Vosh'gajin
13963	Poignes de fer de Voone
13964	Dague sorcière
13965	Plaque de Blackhand
13966	Marque de tyrannie
13967	Bottes du Déchirevent
13968	Oeil de la Bête
13969	Bracières en faisceaux renforcés
13982	Lame de guerre de Caer Darrow
13983	Hache de guerre de la pierre tombale
13984	Darrowspike
13986	Couronne de Caer Darrow
14002	Protecteur du Darrowshire
14022	Cloche des Barov
14023	Cloche des Barov
14024	Serre d'effroi
14025	Ceinture de mystique
14042	Gilet en étoffe cendrée
14043	Gants en étoffe cendrée
14044	Cape en étoffe cendrée
14045	Pantalon en étoffe cendrée
14046	Sac en étoffe runique
14047	Etoffe runique
14048	Rouleau d'étoffe runique
14062	Monture kodo
14083	Bâton de Tyrande
14086	Sandales perlées
14087	Crispins perlées
14088	Cape perlée
14089	Gants perlés
14090	Pantalon perlé
14091	Robe perlée
14093	Corde perlée
14094	Vareuse perlée
14095	Poignets indigènes
14096	Gilet indigène
14097	Pantalon indigène
14098	Cape indigène
14099	Echarpe indigène
14100	Robe en étoffe lumineuse
14101	Gants en étoffe lumineuse
14102	Protège-mains indigènes
14103	Cape en étoffe lumineuse
14104	Pantalon en étoffe lumineuse
14106	Robe en gangrétoffe
14107	Pantalon en gangrétoffe
14108	Bottes en gangrétoffe
14109	Robe indigène
14110	Sandales indigènes
14111	Chaperon en gangrétoffe
14112	Epaulières en gangrétoffe
14113	Echarpe aborigène
14114	Bottes aborigènes
14115	Poignets aborigènes
14116	Cape aborigène
14117	Gants aborigènes
14119	Jambières aborigènes
14120	Robe aborigène
14121	Gilet aborigène
14122	Poignets rituels
14123	Cape rituelle
14124	Gants rituels
14125	Jambières rituelles
14126	Amict rituel
14127	Voile rituel
14128	Robe en tisse-sorcier
14129	Sandales rituelles
14130	Turban en tisse-sorcier
14131	Ceinture rituelle
14132	Jambières en tisse-sorcier
14133	Tunique rituelle
14134	Cape de feu
14136	Robe de la nuit hivernale
14137	Jambières en étoffe lunaire
14138	Gilet en étoffe lunaire
14139	Epaulières en étoffe lunaire
14140	Diadème en étoffe lunaire
14141	Gilet en tisse-fantôme
14142	Gants en tisse-fantôme
14143	Ceinture en tisse-fantôme
14144	Pantalon en tisse-fantôme
14145	Lame corrompue maudite
14146	Gants de maîtrise magique
14147	Brassards cavernicoles
14148	Crispins cristallins
14149	Cape souterraine
14150	Robe d'évocation
14151	Lame chantante
14152	Robe de l'archimage
14153	Robe du Vide
14154	Habit de vraie foi
14155	Sac en étoffe lunaire
14156	Sac sans fond
14157	Mantelet païen
14158	Gilet païen
14159	Sandales païennes
14160	Poignets païens
14161	Cape païenne
14162	Mitaines païennes
14163	Cafetan païen
14164	Ceinture païenne
14165	Jambières païennes
14166	Brassards de boucanier
14167	Cape de boucanier
14168	Gants de boucanier
14169	Protège-épaules aborigènes
14170	Mantelet de boucanier
14171	Pantalon de boucanier
14172	Robe de boucanier
14173	Corde de boucanier
14174	Bottes de boucanier
14175	Chemise de boucanier
14176	Bottes de gardien
14177	Crispins de gardien
14178	Chapeau de gardien
14179	Cape de guetteur
14180	Pourpoint de gardien
14181	Protège-mains de gardien
14182	Mantelet de gardien
14183	Jambières de gardien
14184	Robe de gardien
14185	Cordelière de gardien
14186	Mantelet d'invocateur de pluie
14187	Crispins d'invocateur de pluie
14188	Cape d'invocateur de pluie
14189	Capuche d'invocateur de pluie
14190	Gilet d'invocateur de pluie
14191	Mitaines d'invocateur de pluie
14192	Robe d'invocateur de pluie
14193	Pantalon d'invocateur de pluie
14194	Corde d'invocateur de pluie
14195	Bottes d'invocateur de pluie
14196	Sandales crin-de-chardon
14197	Poignets crin-de-chardon
14198	Cape crin-de-chardon
14199	Gants crin-de-chardon
14200	Capuche crin-de-chardon
14201	Mantelet crin-de-chardon
14202	Pourpoint crin-de-chardon
14203	Pantalon crin-de-chardon
14204	Robe crin-de-chardon
14205	Ceinture crin-de-chardon
14206	Bracelets vitaux
14207	Jambières vitales
14208	Bandeau vital
14209	Echarpe vitale
14210	Cape vitale
14211	Protège-mains vitaux
14212	Epaulières vitales
14213	Grande tenue vitale
14214	Bottes vitales
14215	Tunique vitale
14216	Pourpoint de géomancien
14217	Corde de géomancien
14218	Bottes de géomancien
14219	Cape de géomancien
14220	Bandeau de géomancien
14221	Brassards de géomancien
14222	Gants de géomancien
14223	Spallières de géomancien
14224	Pantalon de géomancien
14225	Cafetan de géomancien
14226	Bracelets de braise-soie
14227	Soie d'araignée toilacier
14228	Cerclet de braise-soie
14229	Cape de braise-soie
14230	Tunique de braise-soie
14231	Mitaines de braise-soie
14232	Mantelet de braise-soie
14233	Jambières de braise-soie
14234	Robe de braise-soie
14235	Corde de braise-soie
14236	Bottes de braise-soie
14237	Armure de Sombrebrume
14238	Bottes de Sombrebrume
14239	Cape de Sombrebrume
14240	Poignets de Sombrebrume
14241	Garde-mains de Sombrebrume
14242	Pantalon de Sombrebrume
14243	Mantelet de Sombrebrume
14244	Cafetan de Sombrebrume
14245	Ceinturon de Sombrebrume
14246	Chapeau de sorcier de Sombrebrume
14247	Mantelet lunaire
14248	Manchettes lunaires
14249	Gilet lunaire
14250	Mules lunaires
14251	Cape lunaire
14252	Cerclet lunaire
14253	Protège-mains lunaires
14254	Grande tenue lunaire
14255	Ceinture lunaire
14256	Gangrétoffe
14257	Jambières lunaires
14258	Corde tissée de sang
14259	Bottes tissées de sang
14260	Brassards tissés de sang
14261	Cape tissée de sang
14262	Mitaines tissées de sang
14263	Masque tissé de sang
14264	Braies tissées de sang
14265	Cafetan tissé de sang
14266	Ailettes tissées de sang
14267	Pourpoint tissé de sang
14268	Crispins de Gaïa
14269	Mules de Gaïa
14270	Cape de Gaïa
14271	Diadème de Gaïa
14272	Protège-mains de Gaïa
14273	Amict de Gaïa
14274	Jambières de Gaïa
14275	Grande tenue de Gaïa
14276	Ceinture de Gaïa
14277	Tunique de Gaïa
14278	Mantelet opulent
14279	Brassards opulents
14280	Cape opulente
14281	Couronne opulente
14282	Gants opulents
14283	Jambières opulentes
14284	Robe opulente
14285	Bottes opulentes
14286	Ceinture opulente
14287	Tunique opulente
14288	Armure arachnéenne
14289	Ceinturon arachnéen
14290	Bottes arachnéennes
14291	Bracelets arachnéens
14292	Cape arachnéenne
14293	Diadème arachnéen
14294	Gants arachnéens
14295	Jambières arachnéennes
14296	Espauliers arachnéens
14297	Robe arachnéenne
14298	Spallières d'ossomancien
14299	Bottes d'ossomancien
14300	Cape d'ossomancien
14301	Manchettes d'ossomancien
14302	Gants d'ossomancien
14303	Voile d'ossomancien
14304	Ceinture d'ossomancien
14305	Sarong d'ossomancien
14306	Gilet d'ossomancien
14307	Couronne d'ossomancien
14308	Tunique céleste
14309	Ceinture céleste
14310	Mules célestes
14311	Manchettes célestes
14312	Couronne céleste
14313	Cape céleste
14314	Protège-mains célestes
14315	Kilt céleste
14316	Espauliers célestes
14317	Robe céleste en soie
14318	Tunique resplendissante
14319	Bottes resplendissantes
14320	Bracelets resplendissants
14321	Cape resplendissante
14322	Diadème resplendissant
14323	Gantelets resplendissants
14324	Sarong resplendissant
14325	Epaulettes resplendissantes
14326	Robe resplendissante
14327	Ceinture resplendissante
14328	Corselet éternel
14329	Bottes éternelles
14330	Manchettes éternelles
14331	Cape éternelle
14332	Couronne éternelle
14333	Gants éternels
14334	Sarong éternel
14335	Spallières éternelles
14336	Cafetan éternel
14337	Corde éternelle
14338	Tube d'eau vide
14339	Tube d'eau du Puits de lune
14340	Robe de la liche glaciale
14341	Fil runique
14342	Etoffe lunaire
14343	Petit éclat brillant
14344	Grand éclat brillant
14364	Mules de mystique
14365	Cape de mystique
14366	Bracelets de mystique
14367	Gants de mystique
14368	Protège-épaules de mystique
14369	Vareuse de mystique
14370	Pantalon de mystique
14371	Robe de mystique
14372	Armure sanguine
14373	Ceinture sanguine
14374	Sandales sanguines
14375	Crispins sanguins
14376	Cape sanguine
14377	Protège-mains sanguins
14378	Mantelet sanguin
14379	Pantalon sanguin
14380	Robe sanguine
14381	Sacoche du Totem sinistre
14382	Tunique endurante
14383	Brassards endurants
14384	Bottes endurantes
14385	Cape endurante
14386	Chapeau endurant
14387	Gants endurants
14388	Jambières endurantes
14389	Protège-épaules endurants
14390	Ceinture endurante
14391	Epée endurante
14392	Bâton endurant
14393	Bouclier endurant
14394	Arc endurant
14395	Sorts des Ombres
14396	Incantations du Néant
14397	Mantelet résistant
14398	Tunique résistante
14399	Bottes résistantes
14400	Cape résistante
14401	Capuche résistante
14402	Poignets résistants
14403	Manicles résistantes
14404	Jambières résistantes
14405	Robe résistante
14406	Corde résistante
14407	Gilet en étoffe de pierre
14408	Bottes en étoffe de pierre
14409	Cape en étoffe de pierre
14410	Diadème en étoffe de pierre
14411	Gants en étoffe de pierre
14412	Epaulettes en étoffe de pierre
14413	Robe en étoffe de pierre
14414	Ceinture en étoffe de pierre
14415	Haut-de-chausse en étoffe de pierre
14416	Manchettes en étoffe de pierre
14417	Tunique en soie de sable
14418	Bottes en soie de sable
14419	Brassards en soie de sable
14420	Cape en soie de sable
14421	Diadème en soie de sable
14422	Gants en soie de sable
14423	Protège-épaules en soie de sable
14424	Jambières en soie de sable
14425	Cafetan en soie de sable
14426	Ceinturon en soie de sable
14427	Vareuse chasse-vent
14428	Bottes chasse-vent
14429	Crispins chasse-vent
14430	Cape chasse-vent
14431	Garde-mains chasse-vent
14432	Amict chasse-vent
14433	Pantalon chasse-vent
14434	Robe chasse-vent
14435	Cordelière chasse-vent
14436	Cerclet chasse-vent
14437	Gilet du voile vénéneux
14438	Bottes du voile vénéneux
14439	Garde-bras du voile vénéneux
14440	Cape du voile vénéneux
14441	Masque du voile vénéneux
14442	Mitaines du voile vénéneux
14443	Mantelet du voile vénéneux
14444	Jambières du voile vénéneux
14445	Robe du voile vénéneux en soie
14446	Ceinture du voile vénéneux
14447	Bottes de bien-né
14448	Bracelets de bien-né
14449	Couronne de bien-né
14450	Cape de bien-né
14451	Gants de bien-né
14452	Espauliers de bien-né
14453	Robe de bien-né
14454	Corde de bien-né
14455	Gambison de bien-né
14456	Gilet élunarien
14457	Crispins élunariens
14458	Bottes élunariennes
14459	Cape élunarienne
14460	Diadème élunarien
14461	Manicles élunariennes
14462	Sarong élunarien
14463	Spallières élunariennes
14464	Robe élunarienne en soie
14465	Ceinture élunarienne
14466	Patron : Tunique tisse-givre
14467	Patron : Robe tisse-givre
14468	Patron : Sac en étoffe runique
14469	Patron : Robe en étoffe runique
14470	Patron : Tunique en étoffe runique
14471	Patron : Gilet en étoffe cendrée
14472	Patron : Cape en étoffe runique
14473	Patron : Ceinture en tisse-fantôme
14474	Patron : Gants tisse-givre
14476	Patron : Gants en étoffe cendrée
14477	Patron : Gants en tisse-fantôme
14478	Patron : Robe en étoffe lumineuse
14479	Patron : Gants en étoffe lumineuse
14480	Patron : Gilet en tisse-fantôme
14481	Patron : Gants en étoffe runique
14482	Patron : Cape en étoffe cendrée
14483	Patron : Pantalon en gangrétoffe
14484	Patron : Cape en étoffe lumineuse
14485	Patron : Jambières en tisse-sorcier
14486	Patron : Cape de Feu
14487	Marteau Os-transis
14488	Patron : Bottes en étoffe runique
14489	Patron : Pantalon tisse-givre
14490	Patron : Pantalon en étoffe cendrée
14491	Patron : Pantalon en étoffe runique
14492	Patron : Bottes en gangrétoffe
14493	Patron : Robe de la nuit hivernale
14494	Patron : Pantalon en étoffe lumineuse
14495	Patron : Pantalon en tisse-fantôme
14496	Patron : Chaperon en gangrétoffe
14497	Patron : Jambières en étoffe lunaire
14498	Patron : Bandeau en étoffe runique
14499	Patron : Sac en étoffe lunaire
14500	Patron : Robe en tisse-sorcier
14501	Patron : Gilet en étoffe lunaire
14502	Ceinturon de givre
14503	Etreinte de la Mort
14504	Patron : Epaulières en étoffe runique
14505	Patron : Turban en tisse-sorcier
14506	Patron : Robe en gangrétoffe
14507	Patron : Epaulières en étoffe lunaire
14508	Patron : Epaulières en gangrétoffe
14509	Patron : Diadème en étoffe lunaire
14510	Patron : Sac sans fond
14511	Patron : Gants de maîtrise magique
14512	Patron : Habit de vraie foi
14513	Patron : Robe de l'archimage
14514	Patron : Robe du Vide
14522	Jambières du maelstrom
14523	Pioche démoniaque
14525	Gantelets de l'étreinte osseuse
14526	Patron : Etoffe lunaire
14528	Targe de Cliquethorax
14529	Bandage en étoffe runique
14530	Bandage épais en étoffe runique
14531	Brise-crâne de l'effroi
14536	Haubert treillissé en os
14537	Grèves Corpselight
14538	Mantelet du marchemort
14539	Casque d'anneaux d'os
14540	Coeur de Taragaman l'Affameur
14541	Epée de la famille Barov
14542	Caisse de Kravel
14543	Gants sombre-ombrage
14544	Insigne de lieutenant
14545	Jambières du fléau spectral
14546	Corne de kodo de Roon
14547	Main d'Iruxos
14548	Spallières royales
14549	Bottes d'esquive
14550	Garde-bras plaie-des-lames
14551	Garde-mains du maître des tranchants
14552	Espauliers de la prison
14553	Echarpe de miséricorde
14554	Jambières du Gardien des nuages
14555	Rasoir solaire d'Alcor
14557	La Corne du lion de Stormwind
14558	Pendentif de dame Maye
14559	Echarpe de prospecteur
14560	Bottes de prospecteur
14561	Crispins de prospecteur
14562	Plastron de prospecteur
14563	Cape de prospecteur
14564	Mitaines de prospecteur
14565	Plaid de prospecteur
14566	Ailettes de prospecteur
14567	Ceinture de rêche-écorce
14568	Bottes de rêche-écorce
14569	Manchettes de rêche-écorce
14570	Chemisette de rêche-écorce
14571	Cape de rêche-écorce
14572	Gants de rêche-écorce
14573	Amict de rêche-écorce
14574	Haut-de-chausses de rêche-écorce
14576	Poignée d'ébène de Marduk
14577	Braies Skullsmoke
14578	Corde de Dokebi
14579	Bottes de Dokebi
14580	Brassards de Dokebi
14581	Corselet de Dokebi
14582	Cape de Dokebi
14583	Gants de Dokebi
14584	Chapeau de Dokebi
14585	Jambières de Dokebi
14587	Mantelet de Dokebi
14588	Corde oeil-de-faucon
14589	Chaussures oeil-de-faucon
14590	Brassards oeil-de-faucon
14591	Casque oeil-de-faucon
14592	Tunique oeil-de-faucon
14593	Cape oeil-de-faucon
14594	Gants oeil-de-faucon
14595	Hauts-de-chausses oeil-de-faucon
14596	Epaulettes oeil-de-faucon
14598	Baudrier de geôlier
14599	Chausses de geôlier
14600	Protège-poignets de geôlier
14601	Harnais de geôlier
14602	Cape de geôlier
14603	Mantelet de geôlier
14604	Chapeau de sorcier de geôlier
14605	Pantalon de geôlier
14606	Gants de geôlier
14607	Targe oeil-de-faucon
14608	Targe de Dokebi
14610	Scarabée d'Araj
14611	Haubert en mailles sanglantes
14612	Jambières en mailles sanglantes
14613	Marteau de Taelan
14614	Ceinture en mailles sanglantes
14615	Gantelets en mailles sanglantes
14616	Bottes en mailles sanglantes
14617	Chemise du scieur d'os
14619	Fragments de squelette
14620	Ceinturon des ossements
14621	Bottes des ossements
14622	Gantelets des ossements
14623	Jambières des ossements
14624	Pansière des ossements
14625	Symbole de l’honneur perdu
14626	Robe nécropile
14627	Patron : Chemise jaune vif
14628	Fragments de squelette imprégnés
14629	Crispins nécropile
14630	Patron : Capuche d'enchanteur
14631	Bottes nécropile
14632	Jambières nécropile
14633	Mantelet nécropile
14634	Recette : Huile glaciale
14635	Patron : Ceinture en cuir cloutée de gemmes
14636	Ceinture cadavérique
14637	Armure cadavérique
14638	Jambières cadavériques
14639	Schéma : Recombobulateur mineur
14640	Gants cadavériques
14641	Chausses cadavériques
14644	Moule de clé squelette
14645	Clé squelette inachevée
14646	Bon-cadeau (Northshire)
14647	Bon-cadeau (Vallée des Frigères)
14648	Bon-cadeau (Sombrevallon)
14649	Bon-cadeau (Vallée des épreuves)
14650	Bon-cadeau (Camp Narache)
14651	Bon-cadeau (Le Glas)
14652	Echarpe scorpashi
14653	Mules scorpashi
14654	Protège-poignets scorpashi
14655	Cuirasse scorpashi
14656	Cape scorpashi
14657	Gants scorpashi
14658	Calot scorpashi
14659	Jambières scorpashi
14660	Protège-épaules scorpashi
14661	Corde de vigilant
14662	Sabots de vigilant
14663	Manchettes de vigilant
14664	Armure de vigilant
14665	Cape de vigilant
14666	Gants de vigilant
14667	Cimier de vigilant
14668	Pantalon de vigilant
14669	Mantelet de vigilant
14670	Armure du seigneur de la harde
14671	Bottes du seigneur de la harde
14672	Poignets du seigneur de la harde
14673	Cape du seigneur de la harde
14674	Ceinturon du seigneur de la harde
14675	Gants du seigneur de la harde
14676	Auréole du seigneur de la harde
14677	Braies du seigneur de la harde
14678	Espauliers du seigneur de la harde
14679	De l'amour et de la famille
14680	Gilet indomptable
14681	Bottes indomptables
14682	Garde-bras indomptables
14683	Cape indomptable
14684	Ceinture indomptable
14685	Gantelets indomptables
14686	Casque indomptable
14687	Jambières indomptables
14688	Epaulettes indomptables
14722	Bottines aux peintures de guerre
14723	Manchettes aux peintures de guerre
14724	Cape aux peintures de guerre
14725	Baudrier aux peintures de guerre
14726	Gants aux peintures de guerre
14727	Jambières aux peintures de guerre
14728	Protège-épaules aux peintures de guerre
14729	Bouclier aux peintures de guerre
14730	Plastron aux peintures de guerre
14742	Bottes massives
14743	Poignets massifs
14744	Corselet massif
14745	Cape massive
14746	Ceinture massive
14747	Gantelets massifs
14748	Jambières massives
14749	Spallières massives
14750	Crispins de tueur
14751	Surcot de tueur
14752	Cape de tueur
14753	Casque de tueur
14754	Gants de tueur
14755	Echarpe de tueur
14756	Mules de tueur
14757	Braies de tueur
14758	Protège-épaules de tueur
14759	Brassards endurcis
14760	Cuirasse endurcie
14761	Ceinture endurcie
14762	Bottes endurcies
14763	Cape endurcie
14764	Gantelets endurcis
14765	Diadème endurci
14766	Jambières endurcies
14767	Espauliers endurcis
14768	Armure de ravageur
14769	Sandales de ravageur
14770	Garde-bras de ravageur
14771	Cape de ravageur
14772	Protège-mains de ravageur
14773	Corde de ravageur
14774	Couronne de ravageur
14775	Pantalon de ravageur
14776	Mantelet de ravageur
14777	Bouclier de ravageur
14778	Manchettes de khan
14779	Plastron de khan
14780	Targe de khan
14781	Cape de khan
14782	Gants de khan
14783	Ceinture de khan
14784	Grèves de khan
14785	Heaume de khan
14786	Jambières de khan
14787	Mantelet de khan
14788	Garde-bras de protecteur
14789	Cuirasse de protecteur
14790	Targe de protecteur
14791	Cape de protecteur
14792	Gantelets de protecteur
14793	Baudrier de protecteur
14794	Protège-chevilles de protecteur
14795	Heaume de protecteur
14796	Jambières de protecteur
14797	Ailettes de protecteur
14798	Cuirasse sanguinaire
14799	Bottes sanguinaires
14800	Targe sanguinaire
14801	Cape sanguinaire
14802	Gantelets sanguinaires
14803	Ceinture sanguinaire
14804	Casque sanguinaire
14805	Haut-de-chausses sanguinaires
14806	Epaulettes sanguinaires
14807	Bracelets sanguinaires
14808	Ceinture de choc martial
14809	Bottes de choc martial
14810	Brachiales de choc martial
14811	Corselet de choc martial
14812	Targe de choc martial
14813	Cape de choc martial
14814	Camail de choc martial
14815	Gantelets de choc martial
14816	Jambières de choc martial
14817	Protège-épaules de choc martial
14821	Cuirasse symbolique
14825	Ecu symbolique
14826	Gantelets symboliques
14827	Ceinture symbolique
14828	Bottes symboliques
14829	Jambières symboliques
14830	Espauliers symboliques
14831	Couronne symbolique
14832	Protège-bras symboliques
14833	Gantelets de tyran
14834	Garde-bras de tyran
14835	Plastron de tyran
14838	Ceinture de tyran
14839	Bottes de tyran
14840	Jambières de tyran
14841	Epaulettes de tyran
14842	Bouclier de tyran
14843	Heaume de tyran
14844	Corselet solécaille
14846	Gantelets solécaille
14847	Ceinture solécaille
14848	Bottes solécaille
14849	Heaume solécaille
14850	Jambières solécaille
14851	Spallières solécaille
14852	Bouclier solécaille
14853	Garde-poignets solécaille
14854	Cuirasse de l'avant-garde
14855	Gantelets de l'avant-garde
14856	Ceinturon de l'avant-garde
14857	Sandales de l'avant-garde
14858	Coiffure de l'avant-garde
14859	Jambières de l'avant-garde
14860	Espauliers de l'avant-garde
14861	Protège-bras de l'avant-garde
14862	Cuirasse de chef de guerre
14863	Gantelets de chef de guerre
14864	Ceinture de chef de guerre
14865	Bottes de chef de guerre
14866	Couronne de chef de guerre
14867	Jambières de chef de guerre
14868	Epaulières de chef de guerre
14869	Brassards de chef de guerre
14872	Don de Tirion
14894	Racine de lis
14895	Surcot du sel gemme
14896	Bottes du sel gemme
14897	Gantelets du sel gemme
14898	Ceinturon du sel gemme
14899	Heaume du sel gemme
14900	Jambières du sel gemme
14901	Protège-épaules du sel gemme
14902	Bouclier du sel gemme
14903	Brachiales du sel gemme
14904	Cuirasse brutale
14905	Gantelets brutaux
14906	Ceinture brutale
14907	Heaume brutal
14908	Jambières brutales
14909	Epaulières brutales
14910	Garde-bras brutaux
14911	Bottes brutales
14912	Bouclier brutal
14913	Bottes de jade
14914	Brassards de jade
14915	Cuirasse de jade
14916	Bouclier de jade
14917	Gantelets de jade
14918	Ceinture de jade
14919	Diadème de jade
14920	Jambières de jade
14921	Epaulettes de jade
14922	Sandales nobles
14923	Garde-bras nobles
14924	Cuirasse noble
14925	Heaume noble
14926	Gantelets nobles
14927	Ceinture noble
14928	Jambières nobles
14929	Protège-épaules nobles
14930	Bouclier noble
14931	Armure héroïque
14932	Bottes héroïques
14933	Gantelets héroïques
14934	Ceinturon héroïque
14935	Heaume héroïque
14936	Jambières héroïques
14937	Espauliers héroïques
14938	Brassards héroïques
14939	Corselet de porteguerre
14940	Bottes de porteguerre
14941	Brachiales de porteguerre
14942	Gantelets de porteguerre
14943	Ceinture de porteguerre
14944	Couronne de porteguerre
14945	Jambières de porteguerre
14946	Spallières de porteguerre
14947	Bouclier de porteguerre
14948	Plastron de forge-sang
14949	Gantelets de forge-sang
14950	Ceinture de forge-sang
14951	Bottes de forge-sang
14952	Heaume de forge-sang
14953	Jambières de forge-sang
14954	Bouclier de forge-sang
14955	Protège-épaules de forge-sang
14956	Manchettes de forge-sang
14957	Bottes de grand chef
14958	Armure de grand chef
14959	Gantelets de grand chef
14960	Ceinture de grand chef
14961	Couronne de grand chef
14962	Jambières de grand chef
14963	Espauliers de grand chef
14964	Bouclier de grand chef
14965	Manchettes de grand chef
14966	Cuirasse glorieuse
14967	Gantelets glorieux
14968	Ceinture glorieuse
14969	Coiffure glorieuse
14970	Jambières glorieuses
14971	Protège-épaules glorieux
14972	Bottes glorieuses
14973	Bouclier glorieux
14974	Manchettes glorieuses
14975	Harnais d'exalté
14976	Gantelets d'exalté
14977	Ceinturon d'exalté
14978	Bottes d'exalté
14979	Heaume d'exalté
14980	Jambières d'exalté
14981	Epaulettes d'exalté
14982	Bouclier d'exalté
14983	Brachiales d'exalté
15002	Pique de Nimboya
15003	Ceinture primordiale
15004	Bottes primordiales
15005	Poignets primordiaux
15006	Targe primordiale
15007	Cape primordiale
15008	Mitaines primordiales
15009	Jambières primordiales
15010	Harnais primordial
15011	Corde lupine
15012	Mules lupines
15013	Crispins lupins
15014	Targe lupine
15015	Cape lupine
15016	Protège-mains lupins
15017	Jambières lupines
15018	Gilet lupine
15019	Mantelet lupin
15042	Pot de Termites vide
15043	Termites des Maleterres
15044	Tonneau de termites des Maleterres
15045	Cuirasse en écailles de dragon vert
15046	Jambières en écailles de dragon vert
15047	Cuirasse en écailles de dragon rouge
15048	Cuirasse en écailles de dragon bleu
15049	Epaulières en écailles de dragon bleu
15050	Cuirasse en écailles de dragon noir
15051	Epaulières en écailles de dragon noir
15052	Jambières en écailles de dragon noir
15053	Cuirasse volcanique
15054	Jambières volcaniques
15055	Epaulières volcaniques
15056	Armure tempétueuse
15057	Pantalon tempétueux
15058	Epaulières tempétueuses
15059	Cuirasse vivante
15060	Jambières vivantes
15061	Epaulières vivantes
15062	Jambières diablosaures
15063	Gantelets diablosaures
15064	Harnais de l'ours de guerre
15065	Jambières de l'ours de guerre
15066	Cuirasse en plumacier
15067	Epaulières en plumacier
15068	Tunique de sabre-de-givre
15069	Jambières de sabre-de-givre
15070	Gants de sabre-de-givre
15071	Bottes de sabre-de-givre
15072	Jambières chimériques
15073	Bottes chimériques
15074	Gants chimériques
15075	Gilet chimérique
15076	Broigne en écailles de scorpide épaisses
15077	Brassards en écailles de scorpide épaisses
15078	Gantelets en écailles de scorpide épaisses
15079	Jambières en écailles de scorpide épaisses
15080	Casque en écailles de scorpide épaisses
15081	Epaulières en écailles de scorpide épaisses
15082	Ceinture en écailles de scorpide épaisses
15083	Gantelets corrompus en cuir
15084	Brassards corrompus en cuir
15085	Armure corrompue en cuir
15086	Bandeau corrompu en cuir
15087	Pantalon corrompu en cuir
15088	Ceinture corrompue en cuir
15090	Armure runique en cuir
15091	Gantelets runiques en cuir
15092	Brassards runiques en cuir
15093	Ceinture runique en cuir
15094	Bandeau runique en cuir
15095	Pantalon runique en cuir
15096	Epaulières runiques en cuir
15102	Echantillon testé d'Un'Goro
15103	Echantillon testé corrompu
15104	Bottes des ailés
15105	Bâton de Noh'Orahil
15106	Bâton de Dar'Orahil
15107	Orbe de Noh'Orahil
15108	Orbe de Dar'Orahil
15109	Bâton de Soran'ruk
15110	Ceinture rigide
15111	Mocassins rigides
15112	Bracelets rigides
15113	Targe rigide
15114	Cape rigide
15115	Gants rigides
15116	Epaulières rigides
15117	Jambières rigides
15118	Tunique rigide
15119	Pantalon de bien-né
15120	Ceinturon inusable
15121	Bottes inusables
15122	Brassards inusables
15123	Targe inusable
15124	Cape inusable
15125	Gants inusables
15126	Jambières inusables
15127	Epaulières inusables
15128	Tunique inusable
15129	Casque inusable
15130	Harnais de coupe-gorge
15131	Bottes de coupe-gorge
15132	Garde-bras de coupe-gorge
15133	Targe de coupe-gorge
15134	Casque de coupe-gorge
15135	Cape de coupe-gorge
15136	Ceinture de coupe-gorge
15137	Mitaines de coupe-gorge
15138	Cape en écailles d'Onyxia
15139	Pantalon de coupe-gorge
15140	Mantelet de coupe-gorge
15141	Cuirasse en écailles d'Onyxia
15142	Bottes d'âme errante
15143	Manchettes d'âme errante
15144	Haillons d'âme errante
15145	Targe d'âme errante
15146	Couronne d'âme errante
15147	Cape d'âme errante
15148	Ceinture d'âme errante
15149	Gants d'âme errante
15150	Ailettes d'âme errante
15151	Jambières d'âme errante
15152	Chaussures de noctambule
15153	Cape de noctambule
15154	Echarpe de noctambule
15155	Gants de noctambule
15156	Chapeau de noctambule
15157	Jambières de noctambule
15158	Protège-épaules de noctambule
15159	Tunique de noctambule
15160	Protège-poignets de noctambule
15161	Ceinture imposante
15162	Bottes imposantes
15163	Brassards imposants
15164	Gilet imposant
15165	Cape imposante
15166	Gants imposants
15167	Bandeau imposant
15168	Pantalon imposant
15169	Epaulières imposantes
15170	Armure toute-puissante
15171	Bottes toutes-puissantes
15172	Poignets tout-puissants
15173	Cape toute-puissante
15174	Gants tout-puissants
15175	Casque tout-puissant
15176	Pantalon tout-puissant
15177	Epaulières toutes-puissantes
15178	Ceinture toute-puissante
15179	Gambison prétorien
15180	Ceinturon prétorien
15181	Bottes prétoriennes
15182	Protège-poignets prétoriens
15183	Cape prétorienne
15184	Gants prétoriens
15185	Coiffe prétorienne
15186	Jambières prétoriennes
15187	Espauliers prétoriens
15188	Garde-bras grandioses
15189	Bottes grandioses
15190	Cape grandiose
15191	Ceinture grandiose
15192	Gantelets grandioses
15193	Couronne grandiose
15194	Jambières grandioses
15195	Cuirasse grandiose
15196	Tabard de soldat
15197	Tabard d'éclaireur
15198	Couleurs de chevalier
15199	Héraut du Garde de pierre
15200	Insigne de sergent-chef
15202	Jambières de gardien de fauves
15203	Jambières de Guststorm
15204	Baguette en pierre de lune
15205	Carabine œil-de-chouette
15206	Bâton Jadefinger
15207	Bouclier de renforcement
15208	Poussière de lune cénarienne
15209	Ensemble de reliques
15210	Epée courte d'écumeur
15211	Epée courte militante
15212	Epée large des guerriers
15213	Epée des mercenaires
15214	Lame noble
15215	Falchion furieux
15216	Epée runique
15217	Lame veuve
15218	Epée de cristal
15219	Lame dimensionnelle
15220	Sabre de guerre
15221	Epée de guerre sainte
15222	Marteau clouté
15223	Marteau dentelé
15224	Ecrasante
15225	Marteau séquoia
15226	Gourdin géant
15227	Massue cloutée
15228	Masse écrasante
15229	Marteau béni
15230	Fendeuse crénelée
15231	Hachette trancheuse
15232	Fendoir tranchant
15233	Hache sauvage
15234	Faux supérieure
15235	Hache en croissant
15236	Fendoir lunaire
15237	Hache ankou
15238	Hache de seigneur de guerre
15239	Hache Felstone
15240	Griffe du démon
15241	Couteau de combat
15242	Stylet affûté
15243	Kris mortel
15244	Lame rasoir
15245	Dague vorpale
15246	Lame démoniaque
15247	Dague d'hémorragie
15248	Claymore resplendissante
15249	Zweihander polie
15250	Flamberge rougeoyante
15251	Epée frappe-tête
15252	Epée éléphantesque
15253	Lame tranche-tête
15254	Espadon noir
15255	Flamberge galante
15256	Epée du massacre
15257	Lacéreuse
15258	Lame de guerre divine
15259	Marteau de guerre lourd
15260	Marteau en pierre
15261	Branche de séquoia
15262	Maillet supérieur
15263	Maillet royal
15264	Fracasse-dos
15265	Douloureuse
15266	Maillet féroce
15267	Brutaliseur
15268	Hache double
15269	Hache de guerre massive
15270	Hache de guerre gigantesque
15271	Hache de guerre colossale
15272	Hache effilée
15273	Porte-mort
15274	Bâton de divination
15275	Bâton de thaumaturge
15276	Long bâton de magus
15277	Kodo gris
15278	Bâton du solstice
15279	Baguette ivoire
15280	Main de sorcier
15281	Bâtonnet de l'étoile luminescente
15282	Doigt du dragon
15283	Baguette lunaire
15284	Grand arc martial
15285	Arc long d'archer
15286	Arc long en séquoia
15287	Arc du Croisé
15288	Arc Blasthorn
15289	Arc de grande frappe
15290	Kodo brun
15291	Arc foudroyant
15292	Kodo vert
15293	Kodo bleu
15294	Arc de siège
15295	Arc flamboyant
15296	Arc oeil-de-faucon
15297	Brassards du grizzly
15298	Targe du grizzly
15299	Cape du grizzly
15300	Gants du grizzly
15301	Mules du grizzly
15302	Ceinture du grizzly
15303	Pantalon du grizzly
15304	Harnais du grizzly
15305	Chaussures farouches
15306	Manchettes farouches
15307	Targe farouche
15308	Corde farouche
15309	Cape farouche
15310	Gants farouches
15311	Harnais farouche
15312	Jambières farouches
15313	Protège-épaules farouches
15314	Liasse de reliques
15322	Fusil à canon lisse
15323	Fusil à percussion
15324	Carabine brûle-flanc
15325	Arquebuse de tireur d'élite
15326	Hache de lancer resplendissante
15327	Dague de lancer corrompue
15328	Clé de Joseph
15329	Ceinture de muletier
15330	Bottes de muletier
15331	Protège-poignets de muletier
15332	Targe de muletier
15333	Cape de muletier
15334	Gants de muletier
15335	Epée courte de Briarsteel
15336	Jambières de muletier
15337	Vareuse de muletier
15338	Mantelet de muletier
15339	Chapeau de guide
15340	Cape de guide
15341	Bottes de guide
15342	Garde de guide
15343	Gants de guide
15344	Pantalon de guide
15345	Protège-épaules de guide
15346	Gilet de guide
15347	Ceinture de guide
15348	Brassards de guide
15349	Ceinture de chasseur de têtes
15350	Mules de chasseur de têtes
15351	Poignets de chasseur de têtes
15352	Targe de chasseur de têtes
15353	Coiffe de chasseur de têtes
15354	Cape de chasseur de têtes
15355	Mitaines de chasseur de têtes
15356	Harnais de chasseur de têtes
15357	Spallières de chasseur de têtes
15358	Jambières de chasseur de têtes
15359	Gilet d'entourloupeur
15360	Manchettes d'entourloupeur
15361	Echarpe d'entourloupeur
15362	Bottes d'entourloupeur
15363	Coiffure d'entourloupeur
15364	Cape d'entourloupeur
15365	Protège-mains d'entourloupeur
15366	Jambières d'entourloupeur
15367	Bouclier d'entourloupeur
15368	Espauliers d'entourloupeur
15369	Ceinture de chevaucheur de loup
15370	Bottes de chevaucheur de loup
15371	Cape de chevaucheur de loup
15372	Gants de chevaucheur de loup
15373	Coiffure de chevaucheur de loup
15374	Jambières de chevaucheur de loup
15375	Protège-épaules de chevaucheur de loup
15376	Gambison de chevaucheur de loup
15377	Protège-poignets de chevaucheur de loup
15378	Ceinture Grifferage
15379	Bottes Grifferage
15380	Brassards Grifferage
15381	Corselet Grifferage
15382	Cape Grifferage
15383	Gants Grifferage
15384	Coiffure Grifferage
15385	Jambières Grifferage
15386	Protège-épaules Grifferage
15387	Bracelets Jadefeu
15388	Ceinture Jadefeu
15389	Sandales Jadefeu
15390	Corselet Jadefeu
15391	Coiffe Jadefeu
15392	Cape Jadefeu
15393	Gants Jadefeu
15394	Pantalon Jadefeu
15395	Epaulettes Jadefeu
15396	Dague de Curvewood
15397	Bâton d'Oakthrush
15398	Bottes des mareyeurs
15399	Ceinture d'herbe-sèche
15400	Brassards de coquillage
15401	Gants goutte-de-puits
15402	Gantelets du collet
15403	Brassards de la dorsale
15404	Ceinturon des brisants
15405	Gants d'écailleur
15406	Bottes crustacéennes
15407	Peau robuste traitée
15408	Ecaille de scorpide épaisse
15409	Sel de Fonderoc raffiné
15410	Ecaille d'Onyxia
15411	Marque de Fordring
15412	Ecaille de dragon vert
15413	Cuirasse ornée en adamantium
15414	Ecaille de dragon rouge
15415	Ecaille de dragon bleu
15416	Ecaille de dragon noir
15417	Cuir de diablosaure
15418	Marteau en platine chatoyant
15419	Cuir d'ours de guerre
15420	Plumacier
15421	Voile de l'exil
15422	Cuir de sabre-de-givre
15423	Cuir de chimère
15424	Hache d'Orgrimmar
15425	Brassards sans pareils
15426	Bottes sans pareilles
15427	Cape sans pareille
15428	Ceinture sans pareille
15429	Gants sans pareils
15430	Bandeau sans pareil
15431	Jambières sans pareilles
15432	Epaulières sans pareilles
15433	Armure sans pareille
15434	Echarpe suprême
15435	Chaussures suprêmes
15436	Brassards suprêmes
15437	Cape suprême
15438	Gants suprêmes
15439	Couronne suprême
15440	Jambières suprêmes
15441	Epaulières suprêmes
15442	Cuirasse suprême
15443	Kris d'Orgrimmar
15444	Bâton d'Orgrimmar
15445	Marteau d'Orgrimmar
15446	Trousse d'adjoint de Stormwind
15447	Pourriture vivante
15448	Pourriture coagulée
15449	Pantalon fantomatique
15450	Jambières des vasières
15451	Jambières des Gargouilles
15452	Brassards de plumes perlées
15453	Brassards de la savane
15454	Mortier et pilon
15455	Robe Poussière-d'automne
15456	Jambières du pas léger
15457	Epaulières du désert
15458	Bottes de la toundra
15459	Garde-poignets de dur-labeur
15461	Bottes du pas rapide
15462	Brassards du terreau
15463	Gants du trotteur solitaire
15464	Marteau brutal
15465	Baguette du dard
15466	Bouclier résonnant
15467	Anneau de la Ligue des Inventeurs
15468	Drapé chantevent
15469	Cordelière Windsong
15470	Jambières du Garde des plaines
15471	Armure de peau coriace
15472	Ceinture du destrier
15473	Bottes du destrier
15474	Manchettes du destrier
15475	Cape du destrier
15476	Protège-mains du destrier
15477	Pantalon du destrier
15478	Bouclier du destrier
15479	Armure du destrier
15480	Ceinturon de guerre déchiré
15481	Bottes de guerre déchirées
15482	Poignets de guerre déchirés
15483	Cape de guerre déchirée
15484	Manicles de guerre déchirées
15485	Pantalon de guerre déchiré
15486	Bouclier de guerre déchiré
15487	Tunique de guerre déchirée
15488	Surcot maculé de sang
15489	Sandales maculées de sang
15490	Cape maculée de sang
15491	Gants maculés de sang
15492	Echarpe maculée de sang
15493	Pantalon maculé de sang
15494	Bouclier maculé de sang
15495	Protège-poignets maculés de sang
15496	Protège-épaules maculées de sang
15497	Corde d'estafette
15498	Mules d'estafette
15499	Crispins d'estafette
15500	Corselet d'estafette
15501	Cape d'estafette
15502	Gants d'estafette
15503	Jambières d'estafette
15504	Bouclier d'estafette
15505	Espauliers d'estafette
15506	Bottes de grunt
15507	Brassards de grunt
15508	Cape de grunt
15509	Protège-mains de grunt
15510	Ceinture de grunt
15511	Jambières de grunt
15512	Bouclier de grunt
15513	Espauliers de grunt
15514	Plastron de grunt
15515	Ceinture en anneaux cloutés
15516	Mules en anneaux cloutés
15517	Protège-poignets en anneaux cloutés
15518	Cuirasse en anneaux clouté
15519	Cape en anneaux cloutés
15520	Gantelets en anneaux cloutés
15521	Jambières en anneaux cloutés
15522	Bouclier en anneaux cloutés
15523	Protège-épaules en anneaux cloutés
15524	Surcot de factionnaire
15525	Mules de factionnaire
15526	Pèlerine de factionnaire
15527	Gants de factionnaire
15528	Echarpe de factionnaire
15529	Jambières de factionnaire
15530	Bouclier de factionnaire
15531	Garde-épaules de factionnaire
15532	Brachiales de factionnaire
15533	Coiffure de factionnaire
15534	Bottes corrompues en anneaux
15535	Brassards corrompus en anneaux
15536	Plastron corrompu en anneaux
15537	Cape corrompue en anneaux
15538	Gantelets corrompus en anneaux
15539	Baudrier corrompu en anneaux
15540	Casque corrompu en anneaux
15541	Jambières corrompues en anneaux
15542	Protège-épaules corrompus en anneaux
15543	Bouclier corrompu en anneaux
15544	Sandales en écailles épaisses
15545	Bracelets en écailles épaisses
15546	Cuirasse en écailles épaisses
15547	Cape en écailles épaisses
15548	Gantelets en écailles épaisses
15549	Ceinture en écailles épaisses
15550	Couronne en écailles épaisses
15551	Jambières en écailles épaisses
15552	Bouclier en écailles épaisses
15553	Protège-épaules en écailles épaisses
15554	Ceinturon de pilleur
15555	Bottes de pilleur
15556	Brassards de pilleur
15557	Corselet de pilleur
15558	Couronne de pilleur
15559	Cape de pilleur
15560	Gants de pilleur
15561	Jambières de pilleur
15562	Espauliers de pilleur
15563	Bouclier de pilleur
15564	Renfort d'armure robuste
15565	Bottes de maraudeur
15566	Brassards de maraudeur
15567	Tunique de maraudeur
15568	Cape de maraudeur
15569	Ecu de maraudeur
15570	Gantelets de maraudeur
15571	Ceinture de maraudeur
15572	Diadème de maraudeur
15573	Jambières de maraudeur
15574	Protège-épaules de maraudeur
15575	Ceinture de nacrétoile
15576	Sandales de nacrétoile
15577	Brassards de nacrétoile
15578	Cuirasse de nacrétoile
15579	Cape de nacrétoile
15580	Camail de nacrétoile
15581	Gantelets de nacrétoile
15582	Jambières de nacrétoile
15583	Protège-épaules de nacrétoile
15584	Bouclier de nacrétoile
15585	Poignes de Pardoc
15586	Fleur à croissance rapide
15587	Ceinturon de Ringtail
15588	Ceinture d'acier armé
15589	Bottes inébranlables
15590	Bracelets inébranlables
15591	Cuirasse inébranlable
15592	Targe inébranlable
15593	Cerclet inébranlable
15594	Cape inébranlable
15595	Gants inébranlables
15596	Jambières inébranlables
15597	Epaulières inébranlables
15598	Ceinturon inébranlable
15599	Jambières des anciens
15600	Protège-bras anciens
15601	Plastron des anciens
15602	Couronne des anciens
15603	Cape des anciens
15604	Bouclier des anciens
15605	Gantelets anciens
15606	Ceinture des anciens
15607	Jambières des anciens
15608	Espauliers des anciens
15609	Armure de mailles d'os
15610	Brassards de mailles d'os
15611	Cape de mailles d'os
15612	Gantelets de mailles d'os
15613	Ceinture de mailles d'os
15614	Sandales de mailles d'os
15615	Heaume de mailles d'os
15616	Jambières de mailles d'os
15617	Epaulettes de mailles d'os
15618	Pavois de mailles d'os
15619	Ceinture du gryphon en mailles
15620	Bracelets du gryphon en mailles
15621	Targe du gryphon en mailles
15622	Cuirasse du gryphon en mailles
15623	Couronne du gryphon en mailles
15624	Cape du gryphon
15625	Gantelets du gryphon en mailles
15626	Bottes du gryphon en mailles
15627	Jambières du gryphon en mailles
15628	Espauliers du gryphon en mailles
15629	Brassards formidables
15630	Sandales formidables
15631	Plastron formidable
15632	Cape formidable
15633	Ecu formidable
15634	Diadème formidable
15635	Gantelets formidables
15636	Ceinture formidable
15637	Jambières formidables
15638	Protège-épaules formidables
15639	Brassards en cuiracier
15640	Cuirasse en cuiracier
15641	Ceinture en cuiracier
15642	Jambières en cuiracier
15643	Cape en cuiracier
15644	Gantelets en cuiracier
15645	Heaume en cuiracier
15646	Jambières en cuiracier
15647	Espauliers en cuiracier
15648	Bouclier en cuiracier
15649	Brassards impitoyables
15650	Surcot impitoyable
15651	Couronne impitoyable
15652	Cape impitoyable
15653	Gantelets impitoyables
15654	Ceinture impitoyable
15655	Jambières impitoyables
15656	Epaulettes impitoyables
15657	Bouclier impitoyable
15658	Bottes impénétrables
15659	Manchettes impénétrables
15660	Cuirasse impénétrable
15661	Cape impénétrable
15662	Gantelets impénétrables
15663	Ceinture impénétrable
15664	Heaume impénétrable
15665	Jambières impénétrables
15666	Espauliers impénétrables
15667	Pavois impénétrable
15668	Brassards magnifiques
15669	Cuirasse magnifique
15670	Heaume magnifique
15671	Cape magnifique
15672	Gantelets magnifiques
15673	Ceinture magnifique
15674	Bottes magnifiques
15675	Garde magnifique
15676	Jambières magnifiques
15677	Epaulières magnifiques
15678	Sandales triomphantes
15679	Brassards triomphants
15680	Plastron triomphant
15681	Cape triomphante
15682	Gantelets triomphants
15683	Ceinturon triomphant
15684	Heaume triomphant
15685	Jambières triomphantes
15686	Protège-épaules triomphants
15687	Bouclier triomphant
15688	Haricots magiques
15689	Anneau des marchands
15690	Collier en os de kodo
15691	Pétoire de flanqueur
15692	Marqueur de kodo
15693	Grandes épaulières
15694	Bottes impitoyables
15695	Bouclier riveté
15696	Tome en pièces
15697	Bottes de voleur de kodo
15698	Spallières de renforcement
15699	Petit paquet marron emballé
15702	Anneau des chimistes
15703	Blouse de chimiste
15704	Médaille des chasseurs
15705	Epée Tidecrest
15706	Dague de poursuite
15707	Echarpe de Brantwood
15708	Gants en cuir chancreux
15709	Ceinturon de Gearforge
15710	Poussière lunaire cénarienne
15722	Gourde de Spraggle
15723	Thé sucré
15724	Patron : Brassards en écailles de scorpide épaisses
15725	Patron : Gantelets corrompus en cuir
15726	Patron : Cuirasse en écailles de dragon vert
15727	Patron : Broigne en écailles de scorpide épaisses
15728	Patron : Brassards corrompus en cuir
15729	Patron : Gants chimériques
15730	Patron : Cuirasse en écailles de dragon rouge
15731	Patron : Gantelets runiques en cuir
15732	Patron : Jambières volcaniques
15733	Patron : Jambières en écailles de dragon vert
15734	Patron : Epaulières vivantes
15735	Patron : Epaulières en plumacier
15736	Complexe spécial de Smokey
15737	Patron : Bottes chimériques
15738	Patron : Gantelets en écailles de scorpide épaisses
15739	Patron : Brassards runiques en cuir
15740	Patron : Bottes de sabre-de-givre
15741	Patron : Pantalon tempétueux
15742	Patron : Harnais de l'ours de guerre
15743	Patron : Ceinture en écailles de scorpide épaisses
15744	Patron : Bandeau corrompu en cuir
15745	Patron : Ceinture runique en cuir
15746	Patron : Jambières chimériques
15747	Patron : Jambières de sabre-de-givre
15748	Patron : Jambières en écailles de scorpide épaisses
15749	Patron : Cuirasse volcanique
15750	Sceptre de lumière
15751	Patron : Cuirasse en écailles de dragon bleu
15752	Patron : Jambières vivantes
15753	Patron : Armure tempétueuse
15754	Patron : Jambières de l'ours de guerre
15755	Patron : Gilet chimérique
15756	Patron : Bandeau runique en cuir
15757	Patron : Pantalon corrompu en cuir
15758	Patron : Gantelets diablosaures
15759	Patron : Cuirasse en écailles de dragon noir
15760	Patron : Cuirasse en plumacier
15761	Patron : Gants de sabre-de-givre
15762	Patron : Heaume en écailles de scorpide épaisses
15763	Patron : Epaulières en écailles de dragon bleu
15764	Patron : Epaulières tempétueuses
15765	Patron : Pantalon runique en cuir
15766	Gemme du serpent
15767	Clé d'Hameya
15768	Patron : Ceinture corrompue en cuir
15769	Patron : Cape en écailles d'Onyxia
15770	Patron : Epaulières en écailles de dragon noir
15771	Patron : Cuirasse vivante
15772	Patron : Jambières diablosaures
15773	Patron : Armure corrompue en cuir
15774	Patron : Epaulières en écailles de scorpide épaisses
15775	Patron : Epaulières volcaniques
15776	Patron : Armure runique en cuir
15777	Patron : Epaulières runiques en cuir
15778	Yéti mécanique
15779	Patron : Tunique de sabre-de-givre
15780	Patron : Cuirasse en écailles d'Onyxia
15781	Patron : Jambières en écailles de dragon noir
15782	Lame de bestiaire
15783	Dague du chasseur de bête
15784	Mantelet de la brise cristalline
15785	Tête de Zaeldarr
15786	Pourpoint de veine-fougère
15787	Haubert du saule
15788	Rapport de Long-guet
15789	Cape du fleuve profond
15790	Etudes sur la langue des Esprits
15791	Echarpe turquoise
15792	Spallières du laboureur
15793	Un os rongé
15794	Jambières ogres déchirées
15795	Gantelets de la brume émeraude
15796	Brassards d'écume
15797	Plates de bras scintillantes
15798	Dents d'ogre ébréchées
15799	Médaille de valeur héroïque
15800	Epée courte intrépide
15801	Epée courte vaillante
15802	Bottes en étoffe lunaire
15803	Livre des Anciens
15804	Drapé cerise
15805	Rose de Pénélope
15806	Chanson de Mirah
15807	Arbalète légère
15808	Belle arbalète légère
15809	Arbalète lourde
15810	Lance courte
15811	Lance lourde
15812	Amict de l'orchidée
15813	Ceinture tressée d'or
15814	Pourfendeuse d'Hameya
15815	Cape d'Hameya
15822	Spallières en peau d'ombre
15823	Gantelets brique-d'acier
15824	Robe d'Astoria
15825	Pourpoint bec-de-corbin
15826	Remède pour animaux
15827	Cuirasse d'écailles de jade
15842	Fiole d'échantillon du Pic de Brume-funeste vide
15843	Fiole d'échantillon du Pic de Brume-funeste remplie
15844	Fiole d'échantillon des Chutes de la Bondissante vide
15845	Fiole d'échantillon des Chutes de la Bondissante remplie
15846	Tamis à sel
15847	Registre de Quel'Thalas
15848	Caisse d'aimants fantômes
15849	Fantôm-o-plasme
15850	Touffe de fourrure de Crépuscaile
15851	Champignon lunaire
15852	Corne de kodo
15853	Arrachevent
15854	Bâton des esprits dansants
15855	Anneau de protection
15856	Talisman de grande lumière
15857	Baguette de résistance magique
15858	Gants de Librevent
15859	Ceinturon de l'escale
15860	Garde-bras de frappe aveugle
15861	Bottes de Swiftfoot
15862	Foudroyante
15863	Sceptre des tombes
15864	Brassards du condor
15865	Targe d'Anchorhold
15866	Sac médecine de voile-poussière
15867	Charme prismatique
15868	Les ordres du Grand croisé
15869	Passe-partout en argent
15870	Passe-partout en or
15871	Passe-partout en vrai-argent
15872	Passe-partout en arcanite
15873	Chope sans fin de John le Loqueteux
15874	Palourde
15875	Pomme pourrie
15876	Coffre de Nathanos
15877	Colifichet du sanctuaire
15878	Clé d'argent de Rackmore
15879	Griffe du Seigneur Ror
15880	Tête de Ramstein Grandgosier
15881	Clé d'or de Rackmore
15882	Demi-pendentif d'endurance aquatique
15883	Demi-pendentif d'agilité aquatique
15884	Livre de compte d'Augustus
15885	Pendentif du lion de mer
15886	Phylactère de Timolain
15887	Garde héroïque
15890	Bouclier de l'avant-garde
15891	Bouclier massif
15892	Bouclier de tueur
15893	Targe de prospecteur
15894	Targe de rêche-écorce
15895	Targe brûlée
15902	Un sac miraculeux
15903	Griffe de droitier
15904	Lame de droitier
15905	Coup de poing de droitier en laiton
15906	Coup de poing de gaucher en laiton
15907	Griffe de gaucher
15908	Bâtonnet de domptage
15909	Lame de gaucher
15911	Bâtonnet de domptage
15912	Orbe de boucanier
15913	Bâtonnet de domptage
15914	Bâtonnet de domptage
15915	Bâtonnet de domptage
15916	Bâtonnet de domptage
15917	Bâtonnet de domptage
15918	Sphère d'invocateur
15919	Bâtonnet de domptage
15920	Bâtonnet de domptage
15921	Bâtonnet de domptage
15922	Bâtonnet de domptage
15923	Bâtonnet de domptage
15924	Chair de praire
15925	Bâton de compagnon
15926	Orbe de lieur de sort
15927	Sphère éclatante
15928	Bâtonnet broché d'argent
15929	Orbe nocturne
15930	Sceptre impérial rouge
15931	Etoile des arcanes
15932	Chope de disciple
15933	Branche simple
15934	Bâton de sage
15935	Bâtonnet solide
15936	Branche tissée de crépuscule
15937	Sphère hivernale
15938	Orbe mystique
15939	Sceptre de conseiller
15940	Sceptre élégant
15941	Sceptre de grand conseiller
15942	Bâtonnet de maître
15943	Bouclier imprégné
15944	Orbe ancestral
15945	Baguette runique
15946	Sphère de mystique
15947	Etoile sanguine
15962	Bâtonnet du satyre
15963	Branche étoffe-de-pierre
15964	Etoile Sable-soie
15965	Orbe chasse-vent
15966	Orbe du voile vénéneux
15967	Etoile de bien-né
15968	Sphère élunarienne
15969	Orbe perlé
15970	Branche indigène
15971	Bâtonnet aborigène
15972	Chope rituelle
15973	Etoile de gardien
15974	Bâtonnet païen
15975	Sceptre d'invocateur de pluie
15976	Branche crin-de-chardon
15977	Orbe vital
15978	Bâtonnet de géomancien
15979	Bâton de braise-soie
15980	Orbe de Sombrebrume
15981	Sphère lunaire
15982	Bâtonnet tissé de sang
15983	Sceptre de Gaïa
15984	Sceptre opulent
15985	Branche arachnéenne
15986	Etoile d'ossomancien
15987	Orbe astral
15988	Orbe resplendissant
15989	Bâtonnet éternel
15990	Bouclier endurci
15991	Bouclier de chef de guerre
15992	Poudre d'explosion dense
15993	Grenade en thorium
15994	Rouage en thorium
15995	Carabine en thorium
15996	Crapaud mécanique
15997	Obus en thorium
15998	Note de Lewis
15999	Lunettes de concentration extrême
16000	Tube en thorium
16001	Insigne du SI:7 (Fredo)
16002	Insigne du SI:7 (Turyen)
16003	Insigne du SI:7 (Rutger)
16004	Carabine en sombrefer
16005	Bombe en sombrefer
16006	Convertisseur d'arcanite délicat
16007	Carabine en arcanite sans défaut
16008	Lunettes de maître ingénieur
16009	Modulateur d'amplification vocale
16022	Petit dragon en arcanite
16023	Leurre ouvragé
16026	PVP Plate Helm Alliance
16027	PVP Plate Breastplate Alliance
16028	PVP Plate Legplates Alliance
16029	PVP Plate Gauntlets Alliance
16030	PVP Plate Boots Alliance
16031	PVP Plate Shoulder Alliance
16033	PVP Plate Wrist Alliance
16034	PVP Plate Cloak Alliance
16035	PVP Cloth Helm Horde
16036	PVP Cloth Robe Horde
16037	PVP Cloth Legs Horde
16038	PVP Cloth Shoulder Horde
16039	Lame chantante de Ta'Kierthan
16040	Bombe des arcanes
16041	Schéma : Grenade en thorium
16042	Schéma : Rouages en thorium
16043	Schéma : Carabine en thorium
16044	Schéma : Crapaud mécanique
16045	Schéma : Lunettes de concentration extrême
16046	Schéma : Leurre ouvragé
16047	Schéma : Tube en thorium
16048	Schéma : Carabine en sombrefer
16049	Schéma : Bombe en sombrefer
16050	Schéma : Convertisseur d'arcanite délicat
16051	Schéma : Obus en thorium
16052	Schéma : Modulateur d'amplification vocale
16053	Schéma : Lunettes de maître ingénieur
16054	Schéma : Petit dragon en arcanite
16055	Schéma : Bombe des arcanes
16056	Schéma : Carabine en arcanite sans défaut
16057	Sac de l'explorateur
16058	Sceau de Fordring
16059	Chemise marron classique
16060	Chemise blanche classique
16072	Livre de cuisine pour expert
16073	Livre de cuisine pour artisan
16082	Artisan pêcheur - La voie de l'appât
16083	Expert pêcheur - Vous et la perche
16084	Expert en premiers soins - Sous les pansements
16085	Artisan en premiers soins - Se soigner seul
16110	Recette : Omelette monstrueuse
16111	Recette : Chili de crabe épicé
16112	Manuel : Bandage épais en soie
16113	Manuel : Bandage en tisse-mage
16114	Masse de contremaître
16115	Caisse d'Osric
16166	Soupe de haricots
16167	Friandise versicolore
16168	Pêche céleste
16169	Gâteau de riz sauvage
16170	Mandu vapeur
16171	Shinsollo
16189	Lettre de réserve de Maggran
16190	Cadavre de Déchiqueteuse Rougefurie
16191	Miroir orné
16192	Croc de Besseleth
16202	Essence éternelle inférieure
16203	Essence éternelle supérieure
16204	Poudre d'illusion
16205	Graine de Gaea
16206	Bâtonnet en arcanite
16207	Bâtonnet runique en arcanite
16208	Graines de Gaea enchantées
16209	Ordre de Podrig
16210	Caisse de Gordon
16214	Formule : Enchantement de bracelets (Intelligence supérieure)
16215	Formule : Enchantement de bottes (Endurance supérieure)
16216	Formule : Enchantement de cape (Résistance supérieure)
16217	Formule : Enchantement de bouclier (Endurance supérieure)
16218	Formule : Enchantement de bracelets (Esprit excellent)
16219	Formule : Enchantement de gants (Agilité supérieure)
16220	Formule : Enchantement de bottes (Esprit)
16221	Formule : Enchantement de plastron (Santé majeure)
16222	Formule : Enchantement de bouclier (Esprit excellent)
16223	Formule : Enchantement d'arme (Frisson glacial)
16224	Formule : Enchantement de cape (Défense excellent)
16242	Formule : Enchantement de plastron (Mana majeur)
16243	Formule : Bâtonnet runique en arcanite
16244	Formule : Enchantement de gants (Force supérieure)
16245	Formule : Enchantement de bottes (Agilité supérieure)
16246	Formule : Enchantement de bracelet (Force excellente)
16247	Formule : Enchantement d'arme 2M - Impact excellent
16248	Formule : Enchantement d'arme (Impie)
16249	Formule : Enchantement d'arme 2M (Intelligence majeure)
16250	Formule : Enchantement d'arme (Frappe excellente)
16251	Formule : Enchantement de bracelets (Endurance excellente)
16252	Formule : Enchantement d'arme (Croisé)
16253	Formule : Enchantement de plastron (Caractéristiques supérieures)
16254	Formule : Enchantement d'arme (Vol de vie)
16255	Formule : Enchantement d'arme 2M (Esprit majeur)
16262	Collection de Nessa
16263	Réponse de Laird
16282	Tas de peaux
16283	Marchandises en cuir d'Ahanu
16302	Grimoire d'Eclair de feu (rang 2)
16303	Patte d'Ursangous
16304	Tête de Shadumbra
16305	Griffe de Serres-tranchantes
16306	Chair de Zargh
16307	Lettre de Gryshka
16308	Pied-de-biche de la Crête du nord
16309	Amulette drakefeu
16310	Liste de Brock
16311	Pioche d'honneur
16312	Incendrites
16313	Coffre de Felix
16314	Seau de boulons de Felix
16315	Cape du Sergent-major
16316	Grimoire d'Eclair de feu (rang 3)
16317	Grimoire d'Eclair de feu (rang 4)
16318	Grimoire d'Eclair de feu (rang 5)
16319	Grimoire d'Eclair de feu (rang 6)
16320	Grimoire d'Eclair de feu (rang 7)
16321	Grimoire de Pacte de sang (rang 1)
16322	Grimoire de Pacte de sang (rang 2)
16323	Grimoire de Pacte de sang (rang 3)
16324	Grimoire de Pacte de sang (rang 4)
16325	Grimoire de Pacte de sang (rang 5)
16326	Grimoire de Bouclier de feu (rang 1)
16327	Grimoire de Bouclier de feu (rang 2)
16328	Grimoire de Bouclier de feu (rang 3)
16329	Grimoire de Bouclier de feu (rang 4)
16330	Grimoire de Bouclier de feu (rang 5)
16331	Grimoire de Changement de phase
16332	Pioche de Thazz'ril
16333	Cadavre de Samuel
16335	Insigne de sergent-chef
16336	Cape du Sergent-major
16337	Cape du Sergent-major
16338	Palefroi de chevalier-lieutenant
16339	Palefroi de commandant
16341	Cape de sergent
16342	Pèlerine de sergent
16343	Monture de garde de sang
16344	Monture de lieutenant-général
16345	Lame de grand seigneur de guerre
16346	Grimoire de Tourment (rang 2)
16347	Grimoire de Tourment (rang 3)
16348	Grimoire de Tourment (rang 4)
16349	Grimoire de Tourment (rang 5)
16350	Grimoire de Tourment (rang 6)
16351	Grimoire de Sacrifice (rang 1)
16352	Grimoire de Sacrifice (rang 2)
16353	Grimoire de Sacrifice (rang 3)
16354	Grimoire de Sacrifice (rang 4)
16355	Grimoire de Sacrifice (rang 5)
16356	Grimoire de Sacrifice (rang 6)
16357	Grimoire de Consumer l’ombre (rang 1)
16358	Grimoire de Consumer l’ombre (rang 2)
16359	Grimoire de Consumer l’ombre (rang 3)
16360	Grimoire de Consumer l’ombre (rang 4)
16361	Grimoire de Consumer l’ombre (rang 5)
16362	Grimoire de Consumer l’ombre (rang 6)
16363	Grimoire de Souffrance (rang 1)
16364	Grimoire de Souffrance (rang 2)
16365	Grimoire de Souffrance (rang 3)
16366	Grimoire de Souffrance (rang 4)
16367	Ceinture de chevalier-capitaine en soie
16368	Grimoire de Fouet de la douleur (rang 2)
16369	Bottes de chevalier-lieutenant en soie
16370	Bracelets de chevalier-capitaine en soie
16371	Grimoire de Fouet de la douleur (rang 3)
16372	Grimoire de Fouet de la douleur (rang 4)
16373	Grimoire de Fouet de la douleur (rang 5)
16374	Grimoire de Fouet de la douleur (rang 6)
16375	Grimoire de Baiser apaisant (rang 1)
16376	Grimoire de Baiser apaisant (rang 2)
16377	Grimoire de Baiser apaisant (rang 3)
16378	Grimoire de Baiser apaisant (rang 4)
16379	Grimoire de Séduction
16380	Grimoire d'Invisibilité inférieure
16381	Grimoire de Festin magique (rang 2)
16382	Grimoire de Festin magique (rang 3)
16383	Grimoire de Festin magique (rang 4)
16384	Grimoire de Corruption sanguine (rang 1)
16385	Grimoire de Corruption sanguine (rang 2)
16386	Grimoire de Corruption sanguine (rang 3)
16387	Grimoire de Corruption sanguine (rang 4)
16388	Grimoire de Verrou magique (rang 1)
16389	Grimoire de Verrou magique (rang 2)
16390	Grimoire de Paranoïa
16391	Gants de chevalier-lieutenant en soie
16392	Bottes de chevalier-lieutenant en cuir
16393	Bottes de chevalier-lieutenant en peau de dragon
16394	Bracelets de chevalier-capitaine en cuir
16395	Bracelets de chevalier-capitaine en peau de dragon
16396	Gantelets de chevalier-lieutenant en cuir
16397	Gants de chevalier-lieutenant en peau de dragon
16398	Ceinture de chevalier-capitaine en cuir
16399	Ceinture de chevalier-capitaine en peau de dragon
16400	Ceinture de chevalier-capitaine en chaînes
16401	Bottes de chevalier-lieutenant en anneaux
16402	Brassards de chevalier-capitaine en chaînes
16403	Gantelets de chevalier-lieutenant en anneaux
16404	Bracelets de chevalier-capitaine en plaques
16405	Bottes de chevalier-lieutenant en plaques
16406	Gantelets de chevalier-lieutenant en plaques
16407	Ceinture de chevalier-capitaine en plaques
16408	Globe d'eau souillée
16409	Sandales lamellaires de chevalier-lieutenant
16410	Gantelets lamellaires de chevalier-lieutenant
16411	Ceinture lamellaire de chevalier-capitaine
16412	Bracelets lamellaires de chevalier-capitaine
16413	Grande tenue de chevalier-capitaine en soie
16414	Pantalon de chevalier-capitaine en soie
16415	Spallières de lieutenant-commandant en soie
16416	Couronne de lieutenant-commandant
16417	Armure de chevalier-capitaine en cuir
16418	Cagoule de lieutenant-commandant en cuir
16419	Jambières de chevalier-capitaine en cuir
16420	Spallières de lieutenant-commandant en cuir
16421	Tunique de chevalier-capitaine en peau de dragon
16422	Jambières de chevalier-capitaine en peau de dragon
16423	Epaulettes de lieutenant-commandant en peau de dragon
16424	Voile de lieutenant-commandant en peau de dragon
16425	Haubert de chevalier-capitaine en anneaux
16426	Jambières de chevalier-capitaine en anneaux
16427	Espauliers de lieutenant-commandant en anneaux
16428	Casque de lieutenant-commandant en anneaux
16429	Casque de lieutenant-commandant en plaques
16430	Corselet de chevalier-capitaine en plaques
16431	Jambières de chevalier-capitaine en plaques
16432	Espauliers de lieutenant-commandant en plaques
16433	Cuirasse lamellaire de chevalier-capitaine
16434	Casque lamellaire de lieutenant-commandant
16435	Jambières lamellaires de chevalier-capitaine
16436	Epaulières lamellaires de lieutenant-commandant
16437	Bottes de maréchal en soie
16438	Bracelets de maréchal en soie
16439	Ceinture de maréchal en soie
16440	Gants de maréchal en soie
16441	Cerclet de grand maréchal
16442	Jambières de maréchal en soie
16443	Habit de grand maréchal en soie
16444	Spallières de grand maréchal en soie
16445	Bracelets en peau de dragon de maréchal
16446	Bottes de maréchal en cuir
16447	Ceinture de maréchal en peau de dragon
16448	Gantelets de maréchal en peau de dragon
16449	Spallières de grand maréchal en peau de dragon
16450	Jambières de maréchal en peau de dragon
16451	Heaume de grand maréchal en peau de dragon
16452	Cuirasse de grand maréchal en peau de dragon
16453	Plastron de grand maréchal en cuir
16454	Manicles de maréchal en cuir
16455	Masque de grand maréchal en cuir
16456	Jambières de maréchal en cuir
16457	Epaulettes de grand maréchal en cuir
16458	Ceinture de maréchal en cuir
16459	Bottes de maréchal en peau de dragon
16460	Brassards de maréchal en cuir
16461	Bracelets de maréchal en chaînes
16462	Bottes de maréchal en anneaux
16463	Poignes de maréchal en anneaux
16464	Ceinture de maréchal en chaînes
16465	Casque de grand maréchal en anneaux
16466	Cuirasse de grand maréchal en anneaux
16467	Jambières de maréchal en anneaux
16468	Spallières de grand maréchal en anneaux
16469	Brassards lamellaires de maréchal
16470	Ceinture lamellaire de maréchal
16471	Gants lamellaires de maréchal
16472	Bottes lamellaires de maréchal
16473	Pansière lamellaire de grand maréchal
16474	Casque lamellaire de grand maréchal
16475	Jambières lamellaires de maréchal
16476	Espauliers lamellaires de grand maréchal
16477	Armure de plaques de grand maréchal
16478	Casque de grand maréchal en plaques
16479	Jambières de maréchal en plaques
16480	Garde-épaules de grand maréchal en plaques
16481	Bracelets de maréchal en plaques
16482	Ceinture de maréchal en plaques
16483	Bottes de maréchal en plaques
16484	Gantelets de maréchal en plaques
16485	Bottines de garde de sang en soie
16486	Crispins d'adjudant en soie
16487	Gants de garde de sang en soie
16488	Ceinture de légionnaire en soie
16489	Chaperon de champion en soie
16490	Pantalon de légionnaire en soie
16491	Robe de légionnaire en soie
16492	Protège-épaules de champion en soie
16493	Brassards de légionnaire en peau de dragon
16494	Bottes de garde de sang en peau de dragon
16495	Ceinture de légionnaire en peau de dragon
16496	Gantelets de champion en peau de dragon
16497	Garde-bras d'adjudant en cuir
16498	Bottes de garde de sang en cuir
16499	Cestes de garde de sang en cuir
16500	Ceinture de légionnaire en cuir
16501	Spallières de champion en peau de dragon
16502	Pantalon de légionnaire en peau de dragon
16503	Casque de champion en peau de dragon
16504	Cuirasse de légionnaire en peau de dragon
16505	Haubert de légionnaire en cuir
16506	Casque de champion en cuir
16507	Mantelet de champion en cuir
16508	Jambières de légionnaire en cuir
16509	Bottes de garde de sang en plaques
16510	Gants de garde de sang en plaques
16511	Ceinture de légionnaire en plaques
16512	Bracelets de légionnaire en plaques
16513	Armure de plaques de légionnaire
16514	Heaume de champion en plaques
16515	Jambières de légionnaire en plaques
16516	Espauliers de champion en plaques
16517	Bracelets de légionnaire en chaînes
16518	Bottes de garde de sang en mailles
16519	Poignes de garde de sang en mailles
16520	Ceinture de légionnaire en mailles
16521	Heaume de champion en mailles
16522	Plastron de légionnaire en mailles
16523	Jambières de légionnaire en mailles
16524	Epaulières de champion en mailles
16525	Cuirasse de légionnaire en anneaux
16526	Heaume de champion en anneaux
16527	Jambières de légionnaire en anneaux
16528	Espauliers de champion en anneaux
16529	Ceinture de légionnaire en chaînes
16530	Gantelets de garde de sang en anneaux
16531	Bottes de garde de sang en anneaux
16532	Garde-poignets d'adjudant en mailles
16533	Capuche de seigneur de guerre en soie
16534	Pantalon de général en soie
16535	Grande tenue de seigneur de guerre en soie
16536	Amict de seigneur de guerre en soie
16537	Ceinture de général en soie
16538	Bracelets de général en soie
16539	Bottes de général en soie
16540	Garde-mains de général en soie
16541	Armure de plaques de seigneur de guerre
16542	Heaume de seigneur de guerre en plaques
16543	Jambières de général en plaques
16544	Epaulières de seigneur de guerre en plaques
16545	Bottes de général en plaques
16546	Brassards de général en plaques
16547	Ceinture de général en plaques
16548	Gantelets de général en plaques
16549	Haubert de seigneur de guerre en peau de dragon
16550	Casque de seigneur de guerre en peau de dragon
16551	Epaulettes de seigneur de guerre en peau de dragon
16552	Jambières de général en peau de dragon
16553	Bracelets de général en peau de dragon
16554	Bottes de général en peau de dragon
16555	Gants de général en peau de dragon
16556	Ceinture de général en peau de dragon
16557	Ceinture de général en cuir
16558	Bottes de général en cuir
16559	Bracelets de général en cuir
16560	Mitaines de général en cuir
16561	Casque de seigneur de guerre en cuir
16562	Spallières de seigneur de guerre en cuir
16563	Cuirasse de seigneur de guerre en cuir
16564	Jambières de général en cuir
16565	Plastron de seigneur de guerre en anneaux
16566	Heaume de seigneur de guerre en anneaux
16567	Jambières de général en anneaux
16568	Epaulières de seigneur de guerre en anneaux
16569	Solerets de général en anneaux
16570	Bracelets de général en chaînes
16571	Gants de général en anneaux
16572	Ceinture de général en chaînes
16573	Bottes de général en mailles
16574	Gantelets de général en mailles
16575	Ceinture de général en mailles
16576	Bracelets de général en mailles
16577	Armure de seigneur de guerre en mailles
16578	Heaume de seigneur de guerre en mailles
16579	Jambières de général en mailles
16580	Spallières de seigneur de guerre en mailles
16581	Cristal de résonite
16583	Figurine démoniaque
16602	Charme troll
16603	Cristal de résonite enchanté
16604	Robe lunaire d'Elune
16605	Robe de moine de la lumière
16606	Robe juju maléfique
16607	Robe sacrificielle d'acolyte
16608	Ceinture du Verseau
16622	Thornflinger
16623	Médaillon d'opaline
16642	Manuel d'utilisation du Déchiqueteur - Chapitre 1
16643	Manuel d'utilisation du Déchiqueteur - Chapitre 2
16644	Manuel d'utilisation du Déchiqueteur - Chapitre 3
16645	Manuel d'utilisation du Déchiqueteur - Page 1
16646	Manuel d'utilisation du Déchiqueteur - Page 2
16647	Manuel d'utilisation du Déchiqueteur - Page 3
16648	Manuel d'utilisation du Déchiqueteur - Page 4
16649	Manuel d'utilisation du Déchiqueteur - Page 5
16650	Manuel d'utilisation du Déchiqueteur - Page 6
16651	Manuel d'utilisation du Déchiqueteur - Page 7
16652	Manuel d'utilisation du Déchiqueteur - Page 8
16653	Manuel d'utilisation du Déchiqueteur - Page 9
16654	Manuel d'utilisation du Déchiqueteur - Page 10
16655	Manuel d'utilisation du Déchiqueteur - Page 11
16656	Manuel d'utilisation du Déchiqueteur - Page 12
16658	Cape de chasseur de fauves
16659	Ceinture d'équilibriste
16660	Bouclier de Driftmire
16661	Cape du saule souple
16662	Fragment de l'Oeil de dragon
16663	Sang du Champion des dragons noirs
16664	Brassards ornés
16665	Tome de Tir tranquillisant
16666	Haubergeon des éléments
16667	Coiffe des éléments
16668	Kilt des éléments
16669	Espauliers des éléments
16670	Bottes des éléments
16671	Manchettes des éléments
16672	Gantelets des éléments
16673	Corde des éléments
16674	Tunique de bestiaire
16675	Bottes de bestiaire
16676	Gants de bestiaire
16677	Coiffe de bestiaire
16678	Pantalon de bestiaire
16679	Mantelet de bestiaire
16680	Ceinture de bestiaire
16681	Manchettes de bestiaire
16682	Bottes de magistère
16683	Manchettes de magistère
16684	Gants de magistère
16685	Ceinture de magistère
16686	Collerette de magistère
16687	Jambières de magistère
16688	Robe de magistère
16689	Mantelet de magistère
16690	Robe de dévot
16691	Sandales de dévot
16692	Gants de dévot
16693	Collerette de dévot
16694	Pantalon de dévot
16695	Mantelet de dévot
16696	Ceinture de dévot
16697	Brassards de dévot
16698	Masque de Brume-funeste
16699	Jambières de Brume-funeste
16700	Robe de Brume-funeste
16701	Mantelet de Brume-funeste
16702	Ceinture de Brume-funeste
16703	Brassards de Brume-funeste
16704	Sandales de Brume-funeste
16705	Protège-mains de Brume-funeste
16706	Gilet du Coeur-sauvage
16707	Cagoule Sombreruse
16708	Spallières Sombreruse
16709	Pantalon Sombreruse
16710	Brassards Sombreruse
16711	Bottes Sombreruse
16712	Gants Sombreruse
16713	Ceinture Sombreruse
16714	Brassards du Coeur-sauvage
16715	Bottes du Coeur-sauvage
16716	Ceinture du Coeur-sauvage
16717	Gants du Coeur-sauvage
16718	Spallières du Coeur-sauvage
16719	Kilt du Coeur-sauvage
16720	Coiffe du Coeur-sauvage
16721	Tunique Sombreruse
16722	Brassards de Sancteforge
16723	Ceinture de Sancteforge
16724	Gantelets de Sancteforge
16725	Bottes de Sancteforge
16726	Cuirasse de Sancteforge
16727	Casque de Sancteforge
16728	Jambières de Sancteforge
16729	Spallières de Sancteforge
16730	Cuirasse de vaillance
16731	Casque de vaillance
16732	Jambières de vaillance
16733	Spallières de vaillance
16734	Bottes de vaillance
16735	Brassards de vaillance
16736	Ceinture de vaillance
16737	Gantelets de vaillance
16738	Gants de sèchegraine
16739	Mantelet en bois d'acacia
16740	Gants de manipulation du Déchiqueteur
16741	Protège-mains huilés
16742	Lames du clan Warsong
16743	Corde de bûcheron
16744	Huile des Warsong
16745	Cargaison de haches Warsong
16746	Rapport du clan Warsong
16747	Verrou cassé
16748	Doublure matelassée
16762	Noyau de la Brasse
16763	Mise à jour du Messager Warsong
16764	Mise à jour de l'Eclaireur Warsong
16765	Mise à jour du Voltigeur Warsong
16766	Soupe de palourdes d'Undermine
16767	Recette : Soupe de palourdes d'Undermine
16768	Sac-médecine furbolg
16769	Totem-médecine furbolg
16782	Globe d'eau étrange
16783	Liasse de rapports
16784	Saphir d'Aku'Mai
16786	Oeil de draconide noir
16787	Amulette de subversion draconique
16788	Roue du capitaine Rackmore
16789	Barre du capitaine Rackmore
16790	Note humide
16791	Crispins flot-de-soie
16792	Gourdin géant
16793	Epaulières d'Arcmetal
16794	Garde-poignets poigne-d'acier
16795	Couronne d'arcaniste
16796	Jambières d'arcaniste
16797	Mantelet d'arcaniste
16798	Robe d'arcaniste
16799	Manchettes d'arcaniste
16800	Bottes d'arcaniste
16801	Gants d'arcaniste
16802	Ceinture d'arcaniste
16803	Mules de Gangrecoeur
16804	Brassards de Gangrecoeur
16805	Gants de Gangrecoeur
16806	Ceinture de Gangrecoeur
16807	Protège-épaules de Gangrecoeur
16808	Cornes de Gangrecoeur
16809	Robe de Gangrecoeur
16810	Pantalon de Gangrecoeur
16811	Bottes de prophétie
16812	Gants de prophétie
16813	Collerette de prophétie
16814	Pantalon de prophétie
16815	Robe de prophétie
16816	Mantelet de prophétie
16817	Ceinturon de prophétie
16818	Ceinture de Vent du néant
16819	Protège-bras de prophétie
16820	Plastron du tueur de la nuit
16821	Couvre-chef du tueur de la nuit
16822	Pantalon du tueur de la nuit
16823	Protège-épaules du tueur de la nuit
16824	Bottes du tueur de la nuit
16825	Bracelets du tueur de la nuit
16826	Gants du tueur de la nuit
16827	Ceinture du tueur de la nuit
16828	Ceinture cénarienne
16829	Bottes cénariennes
16830	Brassards cénariens
16831	Gants cénariens
16832	Spallières Rougecroc
16833	Habit cénarien
16834	Casque cénarien
16835	Jambières cénariennes
16836	Spallières cénariennes
16837	Bottes Rageterre
16838	Ceinture Rageterre
16839	Gantelets Rageterre
16840	Brassards Rageterre
16841	Habit Rageterre
16842	Casque Rageterre
16843	Jambières Rageterre
16844	Epaulettes Rageterre
16845	Cuirasse de traqueur de géant
16846	Casque de traqueur de géant
16847	Jambières de traqueur de géant
16848	Epaulettes de traqueur de géant
16849	Bottes de traqueur de géant
16850	Brassards de traqueur de géant
16851	Ceinture de traqueur de géant
16852	Gants de traqueur de géant
16853	Corselet judiciaire
16854	Heaume judiciaire
16855	Jambières judiciaires
16856	Spallières judiciaires
16857	Brassards judiciaires
16858	Ceinture judiciaire
16859	Bottes judiciaires
16860	Gantelets judiciaires
16861	Brassards de puissance
16862	Sandales de puissance
16863	Gantelets de puissance
16864	Ceinture de puissance
16865	Cuirasse de puissance
16866	Casque de puissance
16867	Jambières de puissance
16868	Espauliers de puissance
16869	Le crâne de Clairvoyant
16870	Le crâne de Somnus
16871	Le crâne de Chronalis
16872	Le crâne d'Axtroz
16873	Gants en fourrure tressée
16882	Coffret endommagé
16883	Coffret usé
16884	Coffret solide
16885	Coffret lourd
16886	Sabre des hors-la-loi
16887	Doigt de la sorcière
16888	Amulette drakefeu terne
16889	Bâton de marche poli
16890	Coutelas de Slatemetal
16891	Epée courte de Claystone
16892	Pierre d'âme inférieure
16893	Pierre d'âme
16894	Bâtonnet en cristal transparent
16895	Pierre d'âme supérieure
16896	Pierre d'âme majeure
16897	Robe de Stormrage
16898	Bottes de Stormrage
16899	Garde-mains de Stormrage
16900	Couvre-chef de Stormrage
16901	Jambières de Stormrage
16902	Espauliers de Stormrage
16903	Ceinture de Stormrage
16904	Brassards de Stormrage
16905	Plastron Rougecroc
16906	Bottes Rougecroc
16907	Gants Rougecroc
16908	Cagoule Rougecroc
16909	Pantalon Rougecroc
16910	Ceinture Rougecroc
16911	Brassards Rougecroc
16912	Bottes de Vent du néant
16913	Gants de Vent du néant
16914	Couronne de Vent du néant
16915	Pantalon de Vent du néant
16916	Robe de Vent du néant
16917	Mantelet de Vent du néant
16918	Manchettes de Vent du néant
16919	Bottes de transcendance
16920	Garde-mains de transcendance
16921	Auréole de transcendance
16922	Jambières de transcendance
16923	Robe de transcendance
16924	Espauliers de transcendance
16925	Ceinture de transcendance
16926	Manchettes de transcendance
16927	Bottes de Némésis
16928	Gants de Némésis
16929	Crâne de Némésis
16930	Jambières de Némésis
16931	Robe de Némésis
16932	Spallières de Némésis
16933	Ceinture de Némésis
16934	Brassards de Némésis
16935	Brassards de traqueur de dragon
16936	Ceinture de traqueur de dragon
16937	Spallières de traqueur de dragon
16938	Jambières de traqueur de dragon
16939	Casque de traqueur de dragon
16940	Gantelets de traqueur de dragon
16941	Bottes de traqueur de dragon
16942	Cuirasse de traqueur de dragon
16943	Brassards des dix tempêtes
16944	Ceinture des dix tempêtes
16945	Epaulettes des dix tempêtes
16946	Jambières des dix tempêtes
16947	Casque des dix tempêtes
16948	Gantelets des dix tempêtes
16949	Bottes des dix tempêtes
16950	Cuirasse des dix tempêtes
16951	Manchettes du jugement
16952	Ceinture du jugement
16953	Spallières du jugement
16954	Jambières du jugement
16955	Couronne du jugement
16956	Gantelets du jugement
16957	Sandales du jugement
16958	Cuirasse du jugement
16959	Bracelets de courroux
16960	Baudrier de courroux
16961	Espauliers de courroux
16962	Jambières de courroux
16963	Heaume de courroux
16964	Gantelets de courroux
16965	Sandales de courroux
16966	Cuirasse de courroux
16967	Ahi de Feralas
16968	Frappeur Sar'theris
16969	Sailfin bleu de la Côte sauvage
16970	Mahi Mahi de Brumejonc
16971	Surprise de palourdes
16972	Bannière de Karang
16973	Fiole d'eau redoutable
16974	Fiole d'eau vide
16975	Echarpe warsong
16976	Totem de Murgut
16977	Bottes Warsong
16978	Gantelets Warsong
16979	Gants Coeur-de-braise
16980	Mantelet Coeur-de-braise
16981	Brassards de Barbe-huante
16982	Bottes du Magma
16983	Casque de la fournaise
16984	Bottes en écailles de dragon noir
16985	Bottes de Cherchevent
16986	Gants du Pic de sable
16987	Ceinture d'hurleur
16988	Epaulières en anneaux de feu
16989	Ceinturon en anneaux de feu
16990	Cape des fées
16991	Bandage de Triage
16992	Lanceur explosif de Smokey
16993	Tire-flammes de Smokey
16994	Gants de Crépuscaile
16995	Mantelet de Crépuscaile
16996	Arc Gorewood
16997	Tempétueuse
16998	Protecteur sacré
16999	Sceau royal d'Alexis
17000	Anneau de l’âme en peine
17001	Cercle élémentaire
17002	Cracheur d'ichor
17003	Marteau de Skullstone
17004	Guide de Sarah
17005	Tunique de rustre
17006	Jambières en cobalt
17007	Gantelets arrache-pierre
17008	Petit parchemin
17009	Tête de l'Ambassadeur Malcin
17010	Noyau de feu
17011	Noyau de lave
17012	Cuir du Magma
17013	Jambières en sombrefer
17014	Brassards en sombrefer
17015	Déchireur en sombrefer
17016	Destructeur en sombrefer
17017	Patron : Mantelet Coeur-de-braise
17018	Patron : Gants Coeur-de-braise
17019	Poussière des arcanes
17020	Poudre des arcanes
17021	Baies sauvages
17022	Patron : Bottes du Magma
17023	Patron : Casque de la fournaise
17024	Racine sauvage
17025	Patron : Bottes en écailles de dragon noir
17026	Ronceterre sauvage
17027	Bougie parfumée
17028	Bougie sanctifiée
17029	Bougie sacrée
17030	Ankh
17031	Rune de téléportation
17032	Rune des portails
17033	Symbole de divinité
17034	Graine d'érable
17035	Graine de strangleronce
17036	Graine de frêne
17037	Graine de charme
17038	Graine de bois de fer
17039	Casse-tête
17042	Crache-clous
17043	Robe de zélote
17044	Volonté du Martyr
17045	Sang du Martyr
17046	Eventreuse
17047	Amict luminescent
17048	Rhum de Rumsey
17049	Plans : Ceinturon en anneaux de feu
17050	Robe impériale de Chan
17051	Plans : Brassards en sombrefer
17052	Plans : Jambières en sombrefer
17053	Plans : Epaulières en anneaux de feu
17054	Pitié de Joonho
17055	Fracasseur de Changuk
17056	Plume légère
17057	Ecailles de poisson brillantes
17058	Huile de poisson
17059	Plans : Déchireur en sombrefer
17060	Plans : Destructeur en sombrefer
17061	Ombre de Junon
17062	Recette : Truite tête-mithril
17063	Anneau de Précisia
17064	Eclat de l'Ecaille
17065	Médaillon de Puissance inébranlable
17066	Disque Drillborer
17067	Ancien Grimoire de Cornerstone
17068	Porte-mort
17069	Marque du Frappeur
17070	Croc des mystiques
17071	Déchireur de Gutgore
17072	Lance-grenaille explosif
17073	Trembleterre
17074	Frappe-ténèbres
17075	Vis'kag le Saigneur
17076	Fléau de Bonereaver
17077	Ecraseur cramoisi
17078	Drapé de Saphiron
17082	Fragment de la Flamme
17102	Cape du Voile de brume
17103	Magelame de Chante-azur
17104	Arrache-moelle
17105	Marteau d'Aurastone
17106	Défenseur de Malistar
17107	Cape sang-de-dragon
17108	Marque de Déviation
17109	Collier d'illumination
17110	Sceau de l'archimagus
17111	Médaillon Blazefury
17112	Démolisseur empyréen
17113	Gardien d'Amberseal
17114	Eclat phylactère d'Araj
17115	Jeton de l'écureuil
17116	Jeton de l'écureuil
17117	Pipeau du dératiseur
17118	Carton de viande mystère
17119	Kébab de Rat des profondeurs
17124	Emblème du Syndicat
17125	Sceau de Ravenholdt
17126	Lettre élégante
17142	Eclat du Souilleur
17182	Sulfuras, Main de Ragnaros
17183	Targe abîmée
17184	Petit bouclier
17185	Targe ronde
17186	Petite targe
17187	Targe cerclée
17188	Targe annelée
17189	Targe en métal
17190	Targe ornée
17191	Sceptre de Celebras
17192	Targe renforcée
17193	Marteau en sulfuron
17194	Epices spéciales
17195	Gui artificiel
17196	Eau de vie spéciale
17197	Biscuit de pain d'épice
17198	Lait de poule
17199	Lait de poule tourné
17200	Recette : Biscuit de pain d'épice
17201	Recette : Lait de poule
17202	Boule de neige
17203	Lingot de sulfuron
17204	Oeil de Sulfuras
17222	Saucisse d'araignée
17223	Tonitruante
17224	Lunette d'observation
17242	Clé du coffre de Salem
17262	Clé de James
17302	Paquet cadeau à ruban bleu
17303	Papier d'emballage à ruban bleu
17304	Papier d'emballage à ruban vert
17305	Paquet cadeau à ruban vert
17306	Sang de soldat stormpike
17307	Papier d'emballage à ruban violet
17308	Paquet cadeau à ruban violet
17309	Bracelets discordants
17310	Aspect de Neptulon
17322	Oeil du Prophète ardent
17323	Balise de Mulverick
17324	Balise de Guse
17325	Balise de Jeztor
17326	Chair de soldat stormpike
17327	Chair de lieutenant stormpike
17328	Chair de commandant stormpike
17329	Main de Lucifron
17330	Main de Sulfuron
17331	Main de Gehennas
17332	Main de Shazzrah
17333	Quintessence aquatique
17344	Sucre d'orge
17345	Bave de silithide
17346	Objet silithide incrusté
17347	Traqueur du Syndicat (MURP)
17348	Breuvage de soins majeur
17349	Breuvage de soins excellent
17351	Breuvage de mana majeur
17352	Breuvage de mana excellent
17353	Ordres d'assaut de Stormpike
17354	Oeil qui-voit-tout de Maître Ryson
17355	Lettre de Rabine
17362	Balise de Ryson
17363	Balise de Ryson
17364	Lunette d'observation
17384	Déchiqueteur portable de Zinfizzlex
17402	Bière du Grandpère Hiver
17403	Mousseux de Gentepression
17404	Bière mélangée
17405	Thé du jardin vert
17406	Roue de fromage de fête
17407	Tourte à la viande maison de Graccu
17408	Brochette de Boeuf épicé
17409	Fragment de cristal incrusté
17410	Déchiqueteur portatif de Zinfizzlex
17411	Scie à vapeur
17413	Codex : Prière de Robustesse
17414	Codex : Prière de Robustesse II
17422	Morceaux d'armures
17423	Cristal de tempête
17442	Ordres d'assaut du clan Frostwolf
17502	Médaille de soldat frostwolf
17503	Médaille de lieutenant frostwolf
17504	Médaille de commandant frostwolf
17505	Balise d'Ichman
17506	Balise de Vipore
17507	Balise de Slidore
17508	Targe de Forcestone
17522	Fournitures de Gouffrefer
17523	Drapé de Smokey
17542	Fournitures de Froide-dent
17562	Bottes de chevalier-lieutenant en tisse-effroi
17563	Bracelets de chevalier-capitaine en tissu-effroi
17564	Gants de chevalier-lieutenant en tisse-effroi
17565	Ceinture de chevalier-capitaine en tissu-effroi
17566	Protège-front de lieutenant-commandant
17567	Jambières de chevalier-capitaine en tisse-effroi
17568	Robe de chevalier-capitaine en tisse-effroi
17569	Mantelet de lieutenant-commandant en tisse-effroi
17570	Chaperon de champion en tisse-effroi
17571	Jambières de légionnaire en tisse-effroi
17572	Robe de légionnaire en tisse-effroi
17573	Epaulières de champion en tisse-effroi
17574	Ceinture de légionnaire en tissu-effroi
17575	Bracelets de légionnaire en tissu-effroi
17576	Bottes de garde de sang en tisse-effroi
17577	Gants de garde de sang en tisse-effroi
17578	Couronne de grand maréchal
17579	Jambières de maréchal en tisse-effroi
17580	Epaulières de grand maréchal en tisse-effroi
17581	Robe de grand maréchal en tisse-effroi
17582	Bracelets de maréchal en tissu-effroi
17583	Bottes de maréchal en tisse-effroi
17584	Gants de maréchal en tisse-effroi
17585	Ceinture de maréchal en tissu-effroi
17586	Bottes de général en tisse-effroi
17587	Bracelets de général en tissu-effroi
17588	Gants de général en tisse-effroi
17589	Ceinture de général en tissu-effroi
17590	Mantelet de seigneur de guerre en tisse-effroi
17591	Chaperon de seigneur de guerre en tisse-effroi
17592	Robe de seigneur de guerre en tisse-effroi
17593	Pantalon de général en tisse-effroi
17594	Bottes de chevalier-lieutenant en satin
17595	Bracelets de chevalier-capitaine en satin
17596	Gants de chevalier-lieutenant en satin
17597	Ceinture de chevalier-capitaine en satin
17598	Diadème de lieutenant-commandant
17599	Jambières de chevalier-capitaine en satin
17600	Robe de chevalier-capitaine en satin
17601	Amict de lieutenant-commandant en satin
17602	Coiffure de grand maréchal
17603	Pantalon de maréchal en satin
17604	Mantelet de grand maréchal en satin
17605	Habit de grand maréchal en satin
17606	Bracelets de maréchal en satin
17607	Sandales de maréchal en satin
17608	Gants de maréchal en satin
17609	Ceinture de maréchal en satin
17610	Capuche de champion en satin
17611	Pantalon de légionnaire en satin
17612	Habit de légionnaire en satin
17613	Protège-épaules de champion en satin
17614	Ceinture de légionnaire en satin
17615	Bracelets de légionnaire en satin
17616	Bottes de garde de sang en satin
17617	Gants de garde de sang en satin
17618	Bottes de général en satin
17619	Bracelets de général en satin
17620	Gants de général en satin
17621	Ceinture de général en satin
17622	Mantelet de seigneur de guerre en satin
17623	Capuche de seigneur de guerre en satin
17624	Robe de seigneur de guerre en satin
17625	Jambières de général en satin
17626	Muselière de loup des glaces
17642	Peau de bélier d'Alterac
17643	Peau de loup des glaces
17662	Friandises volées
17682	Livre : Don du fauve
17683	Livre : Don du fauve II
17684	Gravure de cristal théradrique
17685	Echantillon de Gourmandises Fumebois
17686	Arc de maître-chasseur
17687	Carabine de maître-chasseur
17688	Bottes de la jungle
17689	Collier de dressage stormpike
17690	Insigne Frostwolf grade 1
17691	Insigne Stormpike grade 1
17692	Anneau de la corne
17693	Fiole céruléenne renforcée
17694	Anneau du poing
17695	Mantelet noisette
17696	Fiole céruléenne remplie
17702	Bâtonnet de Celebras
17703	Diamant de Celebras
17704	Lame de l'hiver
17705	Lame de Thrash
17706	Plans : Lame de l'hiver
17707	Coeur d'éclat de gemme
17708	Elixir de Puissance du givre
17709	Recette : Elixir de Puissance du givre
17710	Miséricorde de calcinite
17711	Jambières élémentaires de Rockridge
17712	Déguisement pour le Voile d'hiver
17713	Anneau de noirepierre
17714	Brassards de la princesse de pierre
17715	Oeil de Theradras
17716	MaîtreNeige 9000
17717	Carabine Mégatir
17718	Targe Hypertech de Gizlock
17719	Epée focale de l'Inventeur
17720	Schéma : MaîtreNeige 9000
17721	Gants du Grandpère
17722	Patron : Gants du Grandpère
17723	Chemise verte de fête
17724	Patron : Chemise verte de fête
17725	Formule : Enchantement d'arme (Puissance de l'hiver)
17726	Cadeau spécial des Gourmandises Fumebois
17727	Paquet-cadeau de Gourmandises Fumebois
17728	Bottes en écailles de crocilisque albinos
17730	Hache Gatorbite
17731	Parchemin de Celebras
17732	Mantelet de Grippe-charogne
17733	Poing de pierre
17734	Heaume de la montagne
17735	La fête du Voile d'hiver
17736	Gantelets poigne-de-roc
17737	Pierre des nuages
17738	Griffe de Celebras
17739	Drapé de gardien du bosquet
17740	Coiffure de devin
17741	Etreinte de la nature
17742	Armure mycosienne
17743	Bâtonnet de résurgence
17744	Coeur de Noxxion
17745	Fusil nuisible
17746	Menottes de Noxxion
17747	Racine de Tranchefouet
17748	Sandales de Vinerot
17749	Spallières de peau végétale
17750	Ceinturon de chlororésille
17751	Jambières de Brusslehide
17752	Fouet des satyres
17753	Visée des Gardiens verdoyants
17754	Jambières des Entourloupeurs infernaux
17755	Echarpe en crin de satyre
17756	Fragment Ombréclat
17757	Amulette des esprits
17758	Amulette d'union
17759	Marque de résolution
17760	Graine de vie
17761	Gemme du premier khan
17762	Gemme du deuxième khan
17763	Gemme du troisième khan
17764	Gemme du quatrième khan
17765	Gemme du cinquième khan
17766	Sceptre de la princesse Theradras
17767	Couvre-chef d'efflorescence
17768	Anneau Woodseed
17769	Spallières d'armoise
17770	Gantelets griffebranche
17771	Barre d'élémentium
17772	Pendentif Ombréclat zélé
17773	Pendentif Ombréclat prodigieux
17774	Marque de l'Elu
17775	Robe de sagacité
17776	Casque de Vif-anneau
17777	Cotte d'anneaux implacable
17778	Ceinturon d'armoise
17779	Espauliers du colosse de pierre
17780	Lame des ténèbres éternelles
17781	Les instructions du Paria
17782	Talisman de l'éclat de lien
17783	Talisman du fragment de lien
17822	Cartes frostwolf
17823	Plans de bataille stormpike
17849	Bannière stormpike
17850	Bannière frostwolf
17900	Insigne Stormpike grade 2
17901	Insigne Stormpike grade 3
17902	Insigne Stormpike grade 4
17903	Insigne Stormpike grade 5
17904	Insigne Stormpike grade 6
17905	Insigne Frostwolf grade 2
17906	Insigne Frostwolf grade 3
17907	Insigne Frostwolf grade 4
17908	Insigne Frostwolf grade 5
17909	Insigne Frostwolf grade 6
17922	Armure en fourrure de lion
17943	Poing de pierre
17962	Sac de gemmes bleu
17963	Sac de gemmes vert
17964	Sac de gemmes gris
17965	Sac de gemmes jaune
17966	Sac à dos en cuir d'Onyxia
17967	Ecaille d'Onyxia raffinée
17968	Ecaille d'Onyxia chargée
17969	Sac de gemmes rouge
17982	Noyau de Ragnaros
18022	Sceau royal d'Alexis
18023	Pendentif en rubis de sang
18042	Flèches à pointe de thorium
18043	Bottes du mineur de charbon
18044	Chope d'Hurley
18045	Steak de loup tendre
18046	Recette : Steak de loup tendre
18047	Marcheflammes
18048	Marteau du maître-forgeron
18082	Canne de Zum'rah
18083	Poignes de Jumanza
18102	Bottes de monteur de dragon
18103	Anneau de rumination
18104	Ceinturon de sauvagerie
18142	Tête coupée d'elfe de la nuit
18143	Touffe de cheveux de gnome
18144	Bout d'os humain
18145	Sabot de tauren
18146	Mojo de troll darkspear
18147	Coeur de Réprouvé
18148	Crâne de Korrak
18149	Rune de rappel
18150	Rune de rappel
18151	Fiole d'améthyste remplie
18152	Fiole d'améthyste
18153	Gemme Moro'gai rouge
18154	Papier à lettre Blizzard
18155	Gemme Moro'gai bleue
18156	Gemme Moro'gai verte
18157	Gemme Moro'gai noire
18158	Gemme Moro'gai dorée
18159	Gemme Moro'gai blanche
18160	Recette : Thé de chardon
18168	Disque de force réactif
18169	Mantelet de l'Aube de flammes
18170	Mantelet de l'Aube de givre
18171	Mantelet de l'Aube des arcanes
18172	Mantelet de l'Aube de la nature
18173	Mantelet de l'Aube de l'ombre
18182	Mantelet de l'Aube chromatique
18202	Griffe gauche d'Eskhandar
18203	Griffe droite d'Eskhandar
18204	Fourrure d'Eskhandar
18205	Collier d'Eskhandar
18206	Colonne vertébrale de nain
18207	Dent d'orc
18208	Drapé de bénédiction
18209	Bougie chargée
18222	Vigne épineuse
18223	Pétale dentelé
18224	Racine flagellante
18225	Chaussures de course usées
18226	Un pacte scellé
18227	Tétine étêtée
18228	Portrait dédicacé d’Aguilor
18229	"Guide de la pêche extrême" par Nat Pagle
18230	Bouton "J'ai gagné" cassé
18231	Maillot de corps
18232	Robot réparateur 74A
18233	Mouchoir mouillé de larmes
18234	Document de Carabine Imports
18235	Schéma : Robot réparateur 74A
18236	Jouet à mâcher gordok
18237	Mâchoire de mastiff
18238	Gants en peau d'ombre
18239	Patron : Gants en peau d'ombre
18240	Tanin ogre
18241	Bride de palefroi de guerre noir
18242	Rênes de tigre de guerre noir
18243	Trotteur de bataille noir
18244	Bélier de guerre noir
18245	Cor du loup de guerre noir
18246	Sifflet du raptor de guerre noir
18247	Kodo de guerre noir
18248	Cheval de guerre squelette rouge
18249	Clé en croissant
18250	Clé des menottes gordok
18251	Renfort d'armure du Magma
18252	Patron : Renfort d'armure du Magma
18253	Potion de régénération majeure
18254	Courante-surprise
18255	Racine de Courante
18256	Fiole imprégnée
18257	Recette : Potion de régénération majeure
18258	Tenue d'ogre gordok
18259	Formule : Enchantement d'arme (Puissance de sort)
18260	Formule : Enchantement d'arme (Pouvoir de guérison)
18261	Livre des Incantations
18262	Pierre à aiguiser élémentaire
18263	Couvre-bras Coeur-de-braise
18264	Plans : Pierre à aiguiser élémentaire
18265	Patron : Couvre-bras Coeur-de-braise
18266	Clé de la cour des Gordok
18267	Recette : Courante-surprise
18268	Clé de la porte intérieure des Gordok
18269	Grog vert gordok
18282	Carabine de tireur d'élite endurci
18283	Hyperviseur Biznicks 247 x 128
18284	Bière-massue de Kreeg
18285	Eclat de mana cristallisé
18286	Fragment de mana condensé
18287	Bourbe
18288	Eau-de-feu de mélasse
18289	Collier d’épines barbelées
18290	Schéma : Hyperviseur Biznicks 247 x 128
18291	Schéma : Disque de force réactif
18292	Schéma : Carabine de tireur d'élite endurci
18294	Elixir de Respiration aquatique supérieure
18295	Bottes de phase
18296	Poignets de tireur d'élite
18297	Graine d'épineux
18298	Jambières débridées
18299	Essence d'Hydrogénos
18300	Nectar d'Hyjal
18301	Baguette de Lethtendris
18302	Anneau de Vigueur
18303	Targe d'agilité
18304	Cotte de mailles verteracine
18305	Jambière des brisants
18306	Gants de la brume ombreuse
18307	Chaussures de la marée
18308	Chapeau astucieux
18309	Gants de restauration
18310	Machette démoniaque
18311	Bâtonnet de canalisation de Quel'dorai
18312	Pansière énergétique
18313	Casque de vigilance
18314	Anneau de fourberie démoniaque
18315	Anneau de puissance démoniaque
18316	Colifichet en obsidienne
18317	Talisman de tempête
18318	Grèves miséricordieuses
18319	Camail fervent
18320	Spallières coeur-de-démon
18321	Bâtonnet énergétique
18322	Bottes de la gouttière
18323	Arc du satyre
18324	Tranchevague
18325	Cagoule en gangrecuir
18326	Gantelets-rasoirs
18327	Corde de vigne-fouet
18328	Cape d'ombrebois
18329	Arcanum de rapidité
18330	Arcanum de focalisation
18331	Arcanum de protection
18332	Libram de rapidité
18333	Libram de focalisation
18334	Libram de protection
18335	Diamant noir parfait
18336	Gantelet de puissance gordok
18337	Brassards orphiques
18338	Baguette de puissance arcanique
18339	Cape de l'Eidolon
18340	Talisman de l'Eidolon
18341	Echarpe Quel'dorai
18342	Garde de Quel'dorai
18343	Anneau pétrifié
18344	Gantelets d'écorcepierre
18345	Anneau murmurant
18346	Pantalon élimé
18347	Hache bien équilibrée
18348	Quel'Serrar
18349	Gantelets de précision
18350	Cape d'amplification
18351	Brassards magiquement scellés
18352	Bouclier d'écorce pétrifiée
18353	Bâton de fleur-pierre
18354	Collier de Pimgib
18355	Collier de Ferra
18356	Garona : une étude en discrétion et en trahison
18357	Le codex de défense
18358	Les recettes de l’arcaniste
18359	La lumière et comment l'altérer
18360	Contrôler les ombres
18361	La plus grande race de chasseurs
18362	Sainte Bolognaise : Ce que la lumière ne vous dit pas
18363	Le Horion de givre et vous
18364	Le Rêve d'Emeraude
18365	Une copie très fatiguée du "Guide de la pêche extrême", de Nat Pagle
18366	Garde-mains gordoks
18367	Gantelets gordoks
18368	Gants gordoks
18369	Protège-mains gordoks
18370	Charme de vigilance
18371	Talisman d'ouvresprit
18372	Lame de la Nouvelle lune
18373	Pansière de tranquillité
18374	Epaulières ardentes
18375	Brassards de l'éclipse
18376	Masse usée
18377	Gants de tir rapide
18378	Jambières de Lune-d'argent
18379	Grèves odieuses
18380	Jambières indicibles
18381	Pendentif de mauvais oeil
18382	Cape fluctuante
18383	Gantelets imprégnés de force
18384	Spallières gravées à la bile
18385	Robe de la nuit éternelle
18386	Pantalon du Padre
18387	Gants d'étincelles
18388	Brisepierre
18389	Cape du cosmos
18390	Jambières d'Enchevêtre
18391	Corde de pédoncule
18392	Dague de distraction
18393	Cordon de Crochebois
18394	Garde-poignets de Hurledémon
18395	Anneau de flamme émeraude
18396	Découpe-esprit
18397	Pendentif d'ancien magus
18398	Anneau des flots
18399	Brise de l'océan
18400	Anneau de pierre vivante
18401	Le guide de Nostro du tueur de dragons
18402	Anneau de cristal luminescent
18403	Chevalière du tueur de dragon
18404	Pendentif en dent d'Onyxia
18405	Ceinture de l'archimage
18406	Talisman de sang d'Onyxia
18407	Gants en gangrétoffe
18408	Gants d'Inferno
18409	Gants en étoffe lunaire
18410	Epée du coureur
18411	Bottes de vivacité
18412	Fragment du Magma
18413	Cape de sauvegarde
18414	Patron : Ceinture de l'archimage
18415	Patron : Gants en gangrétoffe
18416	Patron : gants d'Inferno
18417	Patron : Gants en étoffe lunaire
18418	Patron : Cape de sauvegarde
18420	Broie-les-os
18421	Casque des taillis
18422	Tête d'Onyxia
18423	Tête d'Onyxia
18424	Bottes de carex
18425	Chope de Kreeg
18426	Filet de Lethtendris
18427	Cape de sergent
18428	Insigne de sergent-chef
18429	Brassards d'adjudant en plaques
18430	Brassards d'adjudant en plaques
18432	Garde-poignets d'adjudant en mailles
18434	Garde-bras d'adjudant en cuir de dragon
18435	Garde-bras d'adjudant en cuir
18436	Garde-bras d'adjudant en cuir de dragon
18437	Crispins d'adjudant en soie
18438	Marque de sergent
18440	Pèlerine de sergent
18441	Pèlerine de sergent
18442	Insigne de sergent-chef
18443	Insigne de sergent-chef
18444	Insigne de sergent-chef
18445	Garde-poignets de sergent-major en plaques
18447	Garde-poignets de sergent-major en plaques
18448	Garde-bras de sergent-major en mailles
18449	Garde-bras de sergent-major en mailles
18450	Robe de combustion
18451	Ceinture en peau de hyène
18452	Brachiales de sergent-major en cuir
18453	Brachiales de sergent-major en cuir
18454	Brachiales de sergent-major en cuir de dragon
18455	Brachiales de sergent-major en cuir de dragon
18456	Crispins de sergent-major en soie
18457	Crispins de sergent-major en soie
18458	Garde-bras quelconques
18459	Garde-poignets galants
18460	Canon à main de base
18461	Cape de sergent
18462	Poing d'os dentelé
18463	Canif ogre
18464	Anneau de nez gordok
18465	Sceau royal d'Eldre'Thalas
18466	Sceau royal d'Eldre'Thalas
18467	Sceau royal d'Eldre'Thalas
18468	Sceau royal d'Eldre'Thalas
18469	Sceau royal d'Eldre'Thalas
18470	Sceau royal d'Eldre'Thalas
18471	Sceau royal d'Eldre'Thalas
18472	Sceau royal d'Eldre'Thalas
18473	Sceau royal d'Eldre'Thalas
18475	Ceinture bizarrement magique
18476	Bottes boueuses
18477	Jambières velues
18478	Pourpoint en peau de hyène
18479	Casque du scorpide putride
18480	Heaume du scarabée en plaques
18481	Masse brise-crâne
18482	Lanceur de cure-dents ogre
18483	Baguette de canalisation de mana
18484	Lame de Cho'Rush
18485	Bouclier de l'Observateur
18486	Robe en étoffe lunaire
18487	Patron : Robe en étoffe lunaire
18488	Lame ancienne chauffée
18489	Lame ancienne brute
18490	Chaperon de perspicacité
18491	Tisse-savoir
18492	Lame ancienne trempée
18493	Spallières volumineuses en fer
18494	Epaulières du gardien de l'antre
18495	Cape du bastion
18496	Cape héliotrope
18497	Garde-poignets sublimes
18498	Tranchehaies
18499	Bouclier de la barrière
18500	Anneau elfique terni
18501	Fragment de gangrevigne
18502	Vouge monstrueuse
18503	Pansière de Kromcrush
18504	Ceinturon de clairvoyance
18505	Ceinture de l'agresseur
18506	Bottes de la mangouste
18507	Bottes de la Pleine lune
18508	Brassards de vol rapide
18509	Cape chromatique
18510	Peau du Fauve
18511	Cape changeante
18512	Acide de larve
18513	Une lame elfique inachevée
18514	Patron : Ceinturon de clairvoyance
18515	Patron : Bottes de la mangouste
18516	Patron : Brassards de vol rapide
18517	Patron : Cape chromatique
18518	Patron : Peau du Fauve
18519	Patron : Cape changeante
18520	Lame barbare
18521	Bottes en métal sales
18522	Anneau du roi ogre
18523	Pierre étincelante
18524	Jambières de destruction
18525	Brassards de prospérité
18526	Couronne du roi des ogres
18527	Gantelets d'harmonie
18528	Spallières de cyclone
18529	Ceinturon élémentaire en plaques
18530	Haubert ogre
18531	Maillet inflexible
18532	Robe de vague mentale
18533	Brassards de puissance gordok
18534	Bâtonnet des ogres magi
18535	Bouclier de Milli
18536	Lexique de Milli
18537	Magnétite de contre-attaque
18538	Fléau du tréant
18539	Reliquaire de pureté
18540	Reliquaire de pureté scellé
18541	Cape surpuissante
18542	Typhon
18543	Anneau d'Entropie
18544	Gantelets de cuir funeste
18545	Jambières de suprématie arcanique
18546	Cervelière infernale
18547	Ceinturon de glace éternelle
18562	Minerai d'élémentium
18563	Liens du Cherchevent
18564	Liens du Cherchevent
18567	Catalyseur élémentaire
18582	Les Lames Jumelles d'Azzinoth
18583	Glaive de guerre d'Azzinoth (droit)
18584	Glaive de guerre d'Azzinoth (gauche)
18585	Anneau d'allégeance
18586	Anneau de Lonetree
18587	Défibrillateurs gobelins XL
18588	Dynamite Ev-Lan II
18590	Sang de bêtes enragées
18591	Caisse de sang
18592	Plans : Marteau en sulfuron
18594	Puissante charge d'hydroglycérine
18595	Opale de sang
18597	Sifflet d'orphelin orc
18598	Sifflet d'orphelin humain
18600	Tome d'Illumination des arcanes
18601	Prison de cristal luminescente
18602	Tome du Sacrifice
18603	Sang de satyre
18604	Larmes de l'Hederine
18605	Garde funeste emprisonné
18606	Etendard de bataille de l'Alliance
18607	Etendard de bataille de la Horde
18608	Bénédiction
18609	Anathème
18610	Machette effilée
18611	Jambières de Pin-tordu
18612	Bottes en mailles sanglantes
18622	Gangressence parfaite (Jaedenar)
18623	Gangressence parfaite (Porte des ténèbres)
18624	Gangressence parfaite (Azshara)
18625	Noyau infernal de Kroshius
18626	Gangrefeu
18627	Gong de Dethmoora
18628	Contrat de la Confrérie du Thorium
18629	Magnétite noire
18630	Flambeau du Jugement dernier
18631	Altérateur de vrai-argent
18632	Caramel de Ruisselune
18633	Sucette amère de Styleen
18634	Réflectoglace gyrogivre
18635	Barre aux noisettes de Bellara
18636	Défibrillateur abîmé XL
18637	Recombobulateur majeur
18638	Réflectoflamme hyper-radiant
18639	Réflectombre ultra-flash
18640	Caillou rigolo
18641	Dynamite dense
18642	Autographe de Jaina
18643	Empreinte de sabot de Cairne
18645	Robot d'alarme gnome
18646	L'Oeil de la divinité
18647	Schéma : Fusée rouge
18648	Schéma : Fusée verte
18649	Schéma : Fusée bleue
18650	Schéma : Dynamite Ev-Lan II
18651	Schéma : Altérateur de vrai-argent
18652	Schéma : Réflectoglace gyrogivre
18653	Schéma : Défibrillateur gobelin XL
18654	Schéma : Robot d'alarme gnome
18655	Schéma : Recombobulateur majeur
18656	Schéma : Puissante charge d'hydroglycérine
18657	Schéma : Réflectoflamme hyper-radiant
18658	Schéma : Réflectombre ultra-flash
18659	Eclat de Nordrassil
18660	Agrandisseur de monde
18661	Schéma : Agrandisseur de monde
18662	Balle en cuir lourd
18663	Bocal de J'eevee
18664	Un traité sur les grades
18665	L'Oeil de l'ombre
18670	Glyphes de Xoroth
18671	Sceptre du baron Charr
18672	Braise d'élémentaire
18673	Peau pierreuse d'Avalanchion
18674	Anneau de pierre durcie
18675	Grades de la Horde & de l'Alliance
18676	Echarpe du Déchirevent
18677	Cape du zéphyr
18678	Collier gelé de Tempestria
18679	Anneau glacial
18680	Arc d'os des Anciens
18681	Châle funéraire
18682	Jambières en peau de goule
18683	Marteau des vêpres
18684	Anneau légèrement opalescent
18686	Epaulières de golem d'os
18687	Poussière d'étoile xorothienne
18688	Diablotin en bouteille
18689	Cape fantasmatique
18690	Jambières d’âme en peine en plaques
18691	Pendentif du Noir conseiller
18692	Solerets de chevalier de la mort
18693	Protège-mains fébriles
18694	Grèves de mailles des ténèbres
18695	Tome envoûté
18696	Bouclier aux runes complexes
18697	Mules de froidepierre
18698	Cagoule rapiécé en cuir
18699	Spallières de la tombe glaciale
18700	Brassards maléfiques
18701	Anneau d'innervation
18702	Ceinture des Consacrés
18703	Feuille ancienne pétrifiée
18704	Tendon de dragon bleu adulte
18705	Tendon de dragon noir adulte
18706	Maître de l'arène
18707	Bâton runique gravé des Anciens
18708	Ecorce pétrifiée
18709	Garde-poignets de l'arène
18710	Brassards de l'arène
18711	Poignets de l'arène
18712	Protège-bras de l'arène
18713	Rhok'delar, arc long des Gardiens anciens
18714	Feuille d'Ancien cousue de tendons
18715	Lok'delar, bâton des Gardiens anciens
18716	Bottes couvertes de cendres
18717	Marteau du Grand croisé
18718	Heaume du Grand croisé
18719	Le Coeur du traître
18720	Voile du Nathrezim
18721	Ceinturon du barrage
18722	Poignes de mort
18723	Chaîne de cou animée
18724	Tendon de dragon noir enchanté
18725	Conciliateur
18726	Crispins de magistrat
18727	Chapeau de feutre cramoisi
18728	Héritage d'Anastari
18729	Arc strident
18730	Protège-mains lacés de ténèbres
18731	Patron : Balle en cuir lourd
18734	Cape de la lune blafarde
18735	Bottines de Maleki
18736	Jambières du chien pestiféré
18737	Hachette tranche-os
18738	Arbalète en écaille centrale de carapace
18739	Cuissards en plaques chitineuses
18740	Echarpe de Thuzadin
18741	Brassards de Morlune
18742	Garde-épaules de la milice de Stratholme
18743	Cape gracieuse
18744	Gants en fourrure de chauve-souris pestiférée
18745	Jambières en tissu sacré
18746	Clairvoyant
18749	Âme déchue du destrier
18752	Encensoir d'exorcisme
18753	Caparaçon en arcanite
18754	Brassards corrompus durcis
18755	Bâton à feu xorothien
18756	Protecteur de Gardeffroi
18757	Mantelet diabolique
18758	Lame de spectre
18759	Hache malveillante
18760	Anneau nécromantique
18761	Toucher d'oubli
18762	Eclat de la Flamme verte
18766	Rênes de sabre-de-givre rapide
18767	Rênes de sabre-de-brume rapide
18768	Rênes de sabre-de-l'aube rapide
18769	Les plates en thorium enchanté
18770	Les plates en thorium enchanté
18771	Les plates en thorium enchanté
18772	Mécanotrotteur vert rapide
18773	Mécanotrotteur blanc rapide
18774	Mécanotrotteur jaune rapide
18775	Fourrage enrichi en manne
18776	Palomino rapide
18777	Palefroi bai rapide
18778	Palefroi blanc rapide
18779	Moitié inférieure de La Forge d'armure pour les experts : volume I
18780	Moitié supérieure de La Forge d'armure pour les experts : volume I
18781	Moitié inférieure de La Forge d'armure pour les experts : volume II
18782	Moitié supérieure de La Forge d'armure pour les experts : volume II
18783	Moitié inférieure de La Forge d'armure pour les experts : volume III
18784	Moitié supérieure de La Forge d'armure pour les experts : volume III
18785	Bélier blanc rapide
18786	Bélier brun rapide
18787	Bélier gris rapide
18788	Raptor bleu rapide
18789	Raptor vert olive rapide
18790	Raptor orange rapide
18791	Cheval de guerre squelette violet
18792	Caparaçon en arcanite béni
18793	Grand kodo blanc
18794	Grand kodo brun
18795	Grand kodo gris
18796	Cor du loup brun rapide
18797	Cor du loup des bois rapide
18798	Cor du loup gris rapide
18799	Âme rachetée du destrier
18802	Potion des ténèbres
18803	Drague-lave à isolation hyperthermique
18804	Sacoche du seigneur Grayson
18805	Dent de chien du magma
18806	Grèves du Coeur du Magma
18807	Casque du pouvoir latent
18808	Gants de la flamme hypnotique
18809	Echarpe des secrets murmurés
18810	Spallières de croissance sauvage
18811	Cape ignifugée
18812	Garde-poignets de vrai vol
18813	Anneau de lien
18814	Collier du Seigneur du Feu
18815	Essence de la Flamme pure
18816	Lame de la perdition
18817	Couronne de destruction
18818	Instructions de Mor'zul
18819	Encensoir d'exorcisme de Rohan
18820	Talisman de pouvoir éphémère
18821	Anneau de frappe rapide
18822	Lame à tranchant d'obsidienne
18823	Vieux gants en cuir du Magma
18824	Bottes durcies dans le magma
18825	Egide de connétable
18826	Pavois de grand seigneur de guerre
18827	Hachette de connétable
18828	Fendoir de grand seigneur de guerre
18829	Spallières de la Terre profonde
18830	Découpeuse de connétable
18831	Hache de bataille de grand seigneur de guerre
18832	Lame de brutalité
18833	Viseur de connétable
18834	Insigne de la Horde
18835	Arc courbe de grand seigneur de guerre
18836	Arme à répétition de connétable
18837	Arbalète de grand seigneur de guerre
18838	Miséricorde de connétable
18839	Potion de soins de combat
18840	Rasoir de grand seigneur de guerre
18841	Potion de mana de combat
18842	Bâton de domination
18843	Lame de connétable (main droite)
18844	Griffe droite de grand seigneur de guerre
18845	Insigne de la Horde
18846	Insigne de la Horde
18847	Lame de connétable (main gauche)
18848	Griffe gauche de grand seigneur de guerre
18849	Insigne de la Horde
18850	Insigne de la Horde
18851	Insigne de la Horde
18852	Insigne de la Horde
18853	Insigne de la Horde
18854	Insigne de l'Alliance
18855	Canon à main de connétable
18856	Insigne de l'Alliance
18857	Insigne de l'Alliance
18858	Insigne de l'Alliance
18859	Insigne de l'Alliance
18860	Balayeur de rue de grand seigneur de guerre
18861	Cuissards d'Attise-flammes
18862	Insigne de l'Alliance
18863	Insigne de l'Alliance
18864	Insigne de l'Alliance
18865	Punisseur de connétable
18866	Massue de grand seigneur de guerre
18867	Marteau d'armes de connétable
18868	Pulvériseur de seigneur de guerre
18869	Vouge de connétable
18870	Casque du donneur de vie
18871	Aiguillon de grand seigneur de guerre
18872	Jambières de Tempête de mana
18873	Bâton de connétable
18874	Bâton de guerre de grand seigneur de guerre
18875	Pantalon en écailles de salamandre
18876	Claymore de connétable
18877	Grande épée de grand seigneur de guerre
18878	Dague ensorceleuse
18879	Anneau épais en sombrefer
18880	Tête de Ravassombre
18902	Rênes de sabre-tempête rapide
18904	Ultra-réducteur de Zorbin
18922	Plans secrets : Flux embrasé
18942	Flux embrasé
18943	Oreiller sombrefer
18944	Ecaille d'Incendosaure
18945	Résidu de sombrefer
18946	Tête du surveillant Maltorius
18947	Peau de yéti Griffe féroce
18948	Brassards barbares
18949	Patron : Brassards barbares
18950	Oreiller de Pillaclencher
18951	Oreiller d'atterrissage d'Evonice
18952	Tête de Simona
18953	Tête de Klinfran
18954	Tête de Solenor
18955	Tête d'Artorius
18956	Résidus de miniaturisation
18957	Lame des broussailles
18958	Noyau d'élémentaire d'eau
18959	Tuyère de forge
18960	Longue-vue de guetteur
18961	Carapace de Zukk'ash
18962	Glandes de Fouet-cuisant
18963	Oeuf de tortue albinos
18964	Oeuf de tortue caouanne
18965	Oeuf de tortue imbriquée
18966	Oeuf de tortue lyre
18967	Oeuf de tortue olivâtre
18969	Peau de yéti en parfait état
18972	Peau de yéti parfaite
18984	Déchiquetteur dimensionnel - Long-guet
18986	Transporteur ultra-sécurisé : Gadgetzan
18987	Instructions de Blackhand
19002	Tête de Nefarian
19003	Tête de Nefarian
19004	Pierre de soins mineure
19005	Pierre de soins mineure
19006	Pierre de soins inférieure
19007	Pierre de soins inférieure
19008	Pierre de soins
19009	Pierre de soins
19010	Pierre de soins supérieure
19011	Pierre de soins supérieure
19012	Pierre de soins majeure
19013	Pierre de soins majeure
19016	Calice de la renaissance
19017	Essence du Seigneur du feu
19018	Lame du baiser du vent dormante
19019	Lame-tonnerre, épée bénie du Cherchevent
19020	Rapport sur les  Zukk'ash du camp Mojache
19022	FC-5000 de Nat Pagle, pêcheur de l'extrême
19023	Le meilleur appât de Katoom
19024	Grand maître de l'arène
19025	Plume de Seigneur du ciel
19026	Feu d'artifice "Explosion serpentine"
19027	Schéma : Feu d'artifice "Explosion serpentine"
19028	Robe de soirée
19029	Cor du hurleur Frostwolf
19030	Destrier de bataille stormpike
19031	Tabard de bataille frostwolf
19032	Tabard de bataille stormpike
19033	Outils perdus de Slagtree
19034	Repas de Lard
19035	Panier de pique-nique spécial de Lard
19036	Message final pour les Wildhammer
19037	Spallières du pic d'Emeraude
19038	Anneau de subtilité
19039	Chapeau imperméable de Zorbin
19040	Méga-trancheur de Zorbin
19041	Tunique artisanale de Pratt
19042	Tunique artisanale de Jangdor
19043	Ceinture épaisse grumegueule
19044	Pouvoir des Grumegueules
19045	Etendard de bataille stormpike
19046	Etendard de bataille frostwolf
19047	Sagesse des Grumegueules
19048	Bottes lourdes grumegueule
19049	Batailleurs grumegueules
19050	Mantelet des Grumegueules
19051	Ceinturon de l'Aube
19052	Demi-bottes de l'aube
19054	Red Dragon Orb
19055	Green Dragon Orb
19056	Bottes de l'Aube d'argent
19057	Gants de l'Aube
19058	Mantelet doré de l'Aube
19059	Epaulières de l'Aube d'argent
19060	Ration enrichie du goulet des Warsong
19061	Ration de fer du goulet des Warsong
19062	Ration de campagne du goulet des Warsong
19064	Clé des menottes
19065	Cercle d'émeraude
19066	Bandage en étoffe runique du goulet des Warsong
19067	Bandage en tisse-mage du goulet des Warsong
19068	Bandage en soie du goulet des Warsong
19069	Crâne du veneur Malkhor
19070	Os du veneur Malkhor
19071	Calice de sang corrompu
19083	Cape de légionnaire frostwolf
19084	Cape de soldat stormpike
19085	Cape de conseiller frostwolf
19086	Cape de sage stormpike
19087	Ceinture de plaques frostwolf
19088	Ceinture de mailles frostwolf
19089	Ceinture de cuir Frostwolf
19090	Ceinture de tissu frostwolf
19091	Ceinturon stormpike en plaques
19092	Ceinturon stormpike en mailles
19093	Ceinturon stormpike en cuir
19094	Ceinturon stormpike en tissu
19095	Pendentif de légionnaire frostwolf
19096	Pendentif de conseiller frostwolf
19097	Pendentif de soldat stormpike
19098	Pendentif de sage stormpike
19099	Lame glaciale
19100	Dague électrifiée
19101	Bâton blanchi
19102	Bâton crépitant
19103	Frimaire
19104	Marteau Stormpike
19105	Turban de runes de givre
19106	Lance de glace barbelée
19107	Sanguinaire
19108	Baguette du froid mordant
19109	Anneau des racines profondes
19110	Lame forgée à froid
19111	Epaulettes Winteraxe
19112	Protège-bras d'acier glacé
19113	Brassards en cuir de yéti
19114	Arc des Hautes-terres
19115	Flacon de mojo sylvestre
19116	Protège-mains vertefeuille
19117	Cuissards de plaques de bois laquées
19118	Souffle de la Nature
19119	Gants en cuir de chouettard
19120	Rune de capitaine de la garde
19121	Cape des bois profonds
19123	Protège-mains calorifères
19124	Jambières de plaques mâchefer
19125	Ceinturon de mailles calcinées
19126	Gantelets de plaques mâchefer
19127	Tunique carbonisée en cuir
19128	Haubergeon calciné
19129	Robe brasillante
19130	Morsure de froid
19131	Chaussures brûleglace
19132	Couronne ornée d'un cristal
19133	Jambières corrompues
19134	Ceinture de garde funeste écorché
19135	Brassards de lumière noire
19136	Corde de mana enflammé
19137	Ceinturon d'assaut
19138	Anneau de Sulfuras
19139	Epaulières de garde du feu
19140	Anneau de cautérisation
19141	Chiffon
19142	Grimoire de runes de feu
19143	Gantelets de garde des flammes
19144	Solerets du Marcheflammes
19145	Robe du pouvoir volatil
19146	Garde-poignets de stabilité
19147	Anneau de puissance de sort
19148	Heaume en sombrefer
19149	Ceinture de lave
19150	Paquetage de base de sentinelle
19151	Paquetage ordinaire de sentinelle
19152	Paquetage amélioré de sentinelle
19153	Paquetage amélioré de voltigeur
19154	Paquetage de base de voltigeur
19155	Paquetage ordinaire de voltigeur
19156	Robe Coeur-de-braise
19157	Gantelets chromatiques
19159	Collier de lierre tressé
19160	Tabard du vainqueur de l'affrontement
19162	Ceinture du Magma
19163	Ceinture de la fournaise
19164	Gantelets en sombrefer
19165	Jambières Coeur-de-braise
19166	Amnistie noire
19167	Fureur noire
19168	Garde noire
19169	Crépuscule
19170	Main d'ébène
19182	Bon de la foire de Sombrelune
19183	Sable de sablier
19202	Plans : Ceinture épaisse grumegueule
19203	Plans : Ceinturon de l'Aube
19204	Plans : Bottes lourdes grumegueules
19205	Plans : Gants de l'Aube
19206	Plans : Heaume en sombrefer
19207	Plans : Gantelets en sombrefer
19208	Plans : Amnistie noire
19209	Plans : Fureur noire
19210	Plans : Main d'ébène
19211	Plans : Garde noire
19212	Plans : Crépuscule
19213	Talisman de vaillance d'Aile-argent
19215	Patron : Sagesse des Grumegueules
19216	Patron : Bottes de l'Aube d'argent
19217	Patron : Epaulières de l'Aube d'argent
19218	Patron : Mantelet des Grumegueules
19219	Patron : Robe Coeur-de-braise
19220	Patron : Jambières Coeur-de-braise
19221	Réserve spéciale de Sombrelune
19222	Bière bon marché
19223	Casse-croûte de Sombrelune
19224	Ailes de poulet pimentées
19225	Confiserie grillée
19227	As de Fauves
19228	Suite de fauves
19229	Prédiction de Sayge n°1
19230	Deux de Fauves
19231	Trois de Fauves
19232	Quatre de Fauves
19233	Cinq de Fauves
19234	Six de Fauves
19235	Sept de Fauves
19236	Huit de Fauves
19237	Prédiction de Sayge n°19
19238	Prédiction de Sayge n°3
19239	Prédiction de Sayge n°4
19240	Prédiction de Sayge n°5
19241	Prédiction de Sayge n°6
19242	Prédiction de Sayge n°7
19243	Prédiction de Sayge n°8
19244	Prédiction de Sayge n°9
19245	Prédiction de Sayge n°10
19246	Prédiction de Sayge n°11
19247	Prédiction de Sayge n°12
19248	Prédiction de Sayge n°13
19249	Prédiction de Sayge n°14
19250	Prédiction de Sayge n°15
19251	Prédiction de Sayge n°16
19252	Prédiction de Sayge n°18
19253	Prédiction de Sayge n°17
19254	Prédiction de Sayge n°21
19255	Prédiction de Sayge n°22
19256	Prédiction de Sayge n°2
19257	Suite de Seigneurs de guerre
19258	As de Seigneurs de guerre
19259	Deux de Seigneurs de guerre
19260	Trois de Seigneurs de guerre
19261	Quatre de Seigneurs de guerre
19262	Cinq de Seigneurs de guerre
19263	Six de Seigneurs de guerre
19264	Sept de Seigneurs de guerre
19265	Huit de Seigneurs de guerre
19266	Prédiction de Sayge n°20
19267	Suite d'Elémentaires
19268	As d'Elémentaires
19269	Deux d'Elémentaires
19270	Trois d'Elémentaires
19271	Quatre d'Elémentaires
19272	Cinq d'Elémentaires
19273	Six d'Elémentaires
19274	Sept d'Elémentaires
19275	Huit d'Elémentaires
19276	As de Portails
19277	Suite de Portails
19278	Deux de Portails
19279	Trois de Portails
19280	Quatre de Portails
19281	Cinq de Portails
19282	Six de Portails
19283	Sept de Portails
19284	Huit de Portails
19287	Carte de Sombrelune : Héroïsme
19288	Carte de Sombrelune : Dragon bleu
19289	Carte de Sombrelune : Maelström
19290	Carte de Sombrelune : Néant distordu
19291	Boîte de rangement de Sombrelune
19292	Mouton du mois dernier
19293	Mouton de l'an dernier
19295	Fleur de Sombrelune
19296	Lot de Sombrelune (supérieur)
19297	Lot de Sombrelune (inférieur)
19298	Lot de Sombrelune (mineur)
19299	Boisson gazeuse de la foire
19300	Bouteille d'eau de Berceau-de-l'Hiver
19301	Biscuit enrichi en manne d'Alterac
19302	Anneau de Sombrelune
19303	Collier de Sombrelune
19304	Boeuf séché épicé
19305	Pied de kodo mariné
19306	Grenouille croustillante
19307	Bandage épais en étoffe runique d'Alterac
19308	Tome de domination des arcanes
19309	Tome de force d'ombre
19310	Tome du Seigneur de glace
19311	Tome de l'arcane ardente
19312	Lei du Donneur de vie
19315	Toucher de Therazane
19316	Flèche de glace
19317	Balle de glace
19318	Bouteille d'eau de source d'Alterac
19319	Carquois en cuir de harpie
19320	Cartouchière en peau de gnoll
19321	L'Objet inébranlable
19322	Marque d'honneur Warsong
19323	La Force irrésistible
19324	Le Lobotomiseur
19325	Anneau de Don Julio
19326	Patron : Pouvoir des Grumegueules
19327	Patron : Batailleurs grumegueules
19328	Patron : Demi-bottes de l'aube
19329	Patron : Mantelet doré de l'Aube
19330	Patron : Ceinture de lave
19331	Patron : Gantelets chromatiques
19332	Patron : Ceinture du Magma
19333	Patron : Ceinture de la fournaise
19334	La lame indomptée
19335	Brise-échine
19336	Gemme imprégnée d'arcanes
19337	Le Livre noir
19338	Coupon pour des bons gratuits
19339	Gemme de vivacité d'esprit
19340	Rune de transformation
19341	Gemme donneuse de vie
19342	Totem venimeux
19343	Parchemin de lumière aveuglante
19344	Cristal d'alignement sur la nature
19345	Egide de préservation
19346	Lame croc-de-dragon
19347	Griffe de Chromaggus
19348	Protecteur en écailles de dragon rouge
19349	Bouclier en élémentium renforcé
19350	Frappe-coeur
19351	Maladath, lame runique du Vol noir
19352	Epée trempée chromatiquement
19353	Fendoir griffe-de-drake
19354	Vengeresse draconique
19355	Bâton focalisateur de l'Aile de l'ombre
19356	Bâton de la Flamme d'ombre
19357	Prophète de malheur
19358	Maillet draconique
19360	Lok'amir il Romathis
19361	Ashjre'thul, arbalète de châtiment
19362	Trancheuse du destin
19363	Crul'shorukh, Trancheuse du chaos
19364	Ashkandi, Grande épée de la Confrérie
19365	Griffe du drake noir
19366	Orbe du Maître-tueur de dragon
19367	Toucher du dragon
19368	Canon à main Souffle-de-dragon
19369	Gants de l'évolution rapide
19370	Mantelet de la cabale de l'Aile noire
19371	Pendentif du dragon déchu
19372	Heaume de la rage infinie
19373	Espauliers de rejeton noir
19374	Brassards de précision des arcanes
19375	Mish'undare, coiffure du flagelleur mental
19376	Bague de rétorsion d'Archimtiros
19377	Talisman de perfidie de Prestor
19378	Cape du seigneur des couvées
19379	Larme de Neltharion
19380	Chaîne de Therazane
19381	Bottes de la Flamme d'ombre
19382	Anneau d'élémentium pur
19383	Médaillon du Maître-tueur de dragon
19384	Bague du Maître-tueur de dragon
19385	Jambières surpuissantes
19386	Cape brochée d'élémentium
19387	Bottes chromatiques
19388	Torsade d'Angelista
19389	Protège-épaules en cuir de dragon tendu
19390	Gants en cuir de dragon tendu
19391	Geta chatoyantes
19392	Ceinturon du croisé déchu
19393	Sangle rivetée de Primaliste
19394	Espauliers griffe-de-drake
19395	Gemme de récupération
19396	Ceinture en cuir de dragon tendu
19397	Bague de Blackrock
19398	Cape gueule-de-feu
19399	Robe de cendre noire
19400	Etreinte Gueule-de-feu
19401	Cuissards rivetés de Primaliste
19402	Cuissards du croisé déchu
19403	Anneau de Concentration forcée
19405	Rempart béni de Malfurion
19406	Talisman croc-de-drake
19407	Gants de la flamme d'ébène
19422	Prédiction de la foire de Sombrelune
19423	Prédiction de Sayge n°23
19424	Prédiction de Sayge n°24
19425	Coffre mystérieux
19426	Orbe de Sombrelune
19430	Voile de la pensée pure
19431	Scarabée d'obstruction de Styleen
19432	Cercle de la force appliquée
19433	Jambières en tisse-braise
19434	Anneau de sombre domination
19435	Récolteur d'essence
19436	Cape de puissance draconique
19437	Bottes de la pensée pure
19438	Bottes de blizzard de Ringo
19439	Pourpoint d'ombre entrelacé
19440	Anti-venin puissant
19441	Enorme glande à venin
19442	Formule : Anti-venin puissant
19443	Prédiction de Sayge n°25
19444	Formule : Enchantement d'arme (Force)
19445	Formule : Enchantement d'arme (Agilité)
19446	Formule : Enchantement de bracelets (Régénération de mana)
19447	Formule : Enchantement de bracelets (Soin)
19448	Formule : Enchantement d'arme (Esprit renforcé)
19449	Formule : Enchantement d'arme (Intelligence renforcée)
19450	Mini-maison de jubelin
19451	Prédiction de Sayge n°26
19452	Prédiction de Sayge n°27
19453	Prédiction de Sayge n°28
19454	Prédiction de Sayge n°29
19462	Oeuf de jubelin
19482	Peau de lapin de LeCraft
19483	Peler l'oignon
19484	L'artichaut Frostwolf
19491	Amulette de la Sombrelune
19505	Tabard de bataille Warsong
19506	Tabard de bataille Aile-argent
19507	Châle d'inquisiteur
19508	Brassards en cuir marqué
19509	Bottes poussiéreuses en mailles
19510	Anneau de légionnaire
19511	Anneau de légionnaire
19512	Anneau de légionnaire
19513	Anneau de légionnaire
19514	Anneau de protecteur
19515	Anneau de protecteur
19516	Anneau de protecteur
19517	Anneau de protecteur
19518	Bague de conseiller
19519	Bague de conseiller
19520	Bague de conseiller
19521	Bague de conseiller
19522	Bague de gardien du savoir
19523	Bague de gardien du savoir
19524	Bague de gardien du savoir
19525	Bague de gardien du savoir
19526	Cape de soigneur de bataille
19527	Cape de soigneur de bataille
19528	Cape de soigneur de bataille
19529	Cape de soigneur de bataille
19530	Cape de conservateur
19531	Cape de conservateur
19532	Cape de conservateur
19533	Cape de conservateur
19534	Médaillon d'éclaireur
19535	Médaillon d'éclaireur
19536	Médaillon d'éclaireur
19537	Médaillon d'éclaireur
19538	Médaillon de sentinelle
19539	Médaillon de sentinelle
19540	Médaillon de sentinelle
19541	Médaillon de sentinelle
19542	Lame d'éclaireur
19543	Lame d'éclaireur
19544	Lame d'éclaireur
19545	Lame d'éclaireur
19546	Lame de sentinelle
19547	Lame de sentinelle
19548	Lame de sentinelle
19549	Lame de sentinelle
19550	Epée de légionnaire
19551	Epée de légionnaire
19552	Epée de légionnaire
19553	Epée de légionnaire
19554	Epée de protecteur
19555	Epée de protecteur
19556	Epée de protecteur
19557	Epée de protecteur
19558	Arc de voltigeur
19559	Arc de voltigeur
19560	Arc de voltigeur
19561	Arc de voltigeur
19562	Arc d'estafette
19563	Arc d'estafette
19564	Arc d'estafette
19565	Arc d'estafette
19566	Bâton noueux de conseiller
19567	Bâton noueux de conseiller
19568	Bâton noueux de conseiller
19569	Bâton noueux de conseiller
19570	Bâton de gardien du savoir
19571	Bâton de gardien du savoir
19572	Bâton de gardien du savoir
19573	Bâton de gardien du savoir
19574	Force de Mugamba
19575	Force de Mugamba
19576	Force de Mugamba
19577	Rage de Mugamba
19578	Brassards de berserker
19579	Marque du païen
19580	Brassards de berserker
19581	Brassards de berserker
19582	Garde-poignets de messager du vent
19583	Garde-poignets de messager du vent
19584	Garde-poignets de messager du vent
19585	Marque du païen
19586	Marque du païen
19587	Brassards de traqueuse sylvestre
19588	Marque de héros
19589	Brassards de traqueuse sylvestre
19590	Brassards de traqueuse sylvestre
19591	L'Oeil de Zuldazar
19592	L'Oeil de Zuldazar
19593	L'Oeil de Zuldazar
19594	L'Oeil omnivoyant de Zuldazar
19595	Manchettes de dryade
19596	Manchettes de dryade
19597	Manchettes de dryade
19598	Caillou de Kajaro
19599	Caillou de Kajaro
19600	Caillou de Kajaro
19601	Joyau de Kajaro
19602	Souillure de Kezan
19603	Souillure de Kezan
19604	Souillure de Kezan
19605	Souillure irrésistible de Kezan
19606	Vision de Voodress
19607	Vision de Voodress
19608	Vision de Voodress
19609	Vision limpide de Voodress
19610	Varech enchanté des Mers du sud
19611	Varech enchanté des Mers du sud
19612	Varech enchanté des Mers du sud
19613	Varech enchanté des Mers du sud en parfait état
19614	Talisman de l'ombre zandalarien
19615	Talisman de l'ombre zandalarien
19616	Talisman de l'ombre zandalarien
19617	Talisman de maîtrise de l'ombre zandalarien
19618	Vrille du maelström
19619	Vrille du maelström
19620	Vrille du maelström
19621	Courroux du maelström
19642	iCoke Prize Voucher
19682	Gilet en vignesang
19683	Jambières  en vignesang
19684	Bottes en vignesang
19685	Pourpoint en peau de chauve-souris primordiale
19686	Gants en peau de chauve-souris primordiale
19687	Brassards en peau de chauve-souris primordiale
19688	Cuirasse du tigre-sang
19689	Epaulières du tigre-sang
19690	Cuirasse d'âmesang
19691	Epaulières d'âmesang
19692	Gantelets d'âmesang
19693	Cuirasse de ténébrâme
19694	Jambières de ténébrâme
19695	Epaulières de ténébrâme
19696	Pain de la moisson
19697	Don de la moisson
19698	Pièce zulienne
19699	Pièce Razzashi
19700	Pièce hakkari
19701	Pièce Gurubashi
19702	Pièce Vilebranch
19703	Pièce Witherbark
19704	Pièce Sandfury
19705	Pièce Skullsplitter
19706	Pièce Bloodscalp
19707	Bijou hakkari rouge
19708	Bijou hakkari bleu
19709	Bijou hakkari jaune
19710	Bijou hakkari orange
19711	Bijou hakkari vert
19712	Bijou hakkari violet
19713	Bijou hakkari bronze
19714	Bijou hakkari argenté
19715	Bijou hakkari doré
19716	Manchettes primordiales hakkari
19717	Brachiales primordiales hakkari
19718	Etançon primordial hakkari
19719	Ceinturon primordial hakkari
19720	Echarpe primordiale hakkari
19721	Châle primordial hakkari
19722	Tabard primordial hakkari
19723	Casaque primordiale hakkari
19724	Egide primordiale hakkari
19725	Caisse de ressources d'Arathi
19726	Vignesang
19727	Faucille de sang
19764	Patron : Gilet en vignesang
19765	Patron : Jambières  en vignesang
19766	Patron : Bottes en vignesang
19767	Cuir de chauve-souris primordiale
19768	Cuir de tigre primordial
19769	Patron : Pourpoint en peau de chauve-souris primordiale
19770	Patron : Gants en peau de chauve-souris primordiale
19771	Patron : Brassards en peau de chauve-souris primordiale
19772	Patron : Cuirasse du tigre-sang
19773	Patron : Epaulières du tigre-sang
19774	Âmarite
19775	Sac azur scellé
19776	Plans : Cuirasse d'âmesang
19777	Plans : Epaulières d'âmesang
19778	Plans : Gantelets d'âmesang
19779	Plans : Cuirasse de ténébrâme
19780	Plans : Jambières de ténébrâme
19781	Plans : Epaulières de ténébrâme
19782	Présence de la puissance
19783	Signe du syncrétiste
19784	Caresse de la Mort
19785	Appel de l'épervier
19786	Etreinte vigilante du vaudouisan
19787	Présence de la vision
19788	Maléfice porte-guigne
19789	Aura prophétique
19790	Caresse de l'animiste
19802	Coeur d'Hakkar
19803	Tassergal à dos rayé
19804	Rascasse pâle
19805	Scalaire de Keefer
19806	Talang dezien
19807	Courbine
19808	Morwong rocailleux
19812	Rune de l'Aube
19813	Poupée vaudou percée
19814	Poupée vaudou percée
19815	Poupée vaudou percée
19816	Poupée vaudou percée
19817	Poupée vaudou percée
19818	Poupée vaudou percée
19819	Poupée vaudou percée
19820	Poupée vaudou percée
19821	Poupée vaudou percée
19822	Cuirasse de redresseur de torts zandalar
19823	Ceinture de redresseur de torts zandalar
19824	Garde-bras de redresseur de torts zandalar
19825	Cuirasse de libre-penseur zandalar
19826	Ceinture de libre-penseur zandalar
19827	Garde-bras de libre-penseur zandalar
19828	Haubert d'augure zandalar
19829	Ceinture d'augure zandalar
19830	Brassards d'augure zandalar
19831	Mantelet de prédateur zandalar
19832	Ceinture de prédateur zandalar
19833	Brassards de prédateur zandalar
19834	Tunique d'insensé zandalar
19835	Mantelet d'insensé zandalar
19836	Brassards d'insensé zandalar
19838	Tunique d'haruspice zandalar
19839	Ceinture d'haruspice zandalar
19840	Brassards d'haruspice zandalar
19841	Mantelet de confesseur zandalar
19842	Cordon de confesseur zandalar
19843	Couvre-bras de confesseur zandalar
19845	Mantelet d'illusionniste zandalar
19846	Couvre-bras d'illusionniste zandalar
19848	Couvre-bras de démoniaque zandalar
19849	Mantelet de démoniaque zandalar
19850	Offrande à Uther
19851	Offrande à Grom
19852	Ancienne massacreuse hakkari
19853	Destructeur de nains gurubashi
19854	Zin'rokh, Destructeur de mondes
19855	Cuissards imprégnés de sang
19856	L'Oeil d'Hakkar
19857	Cape de consomption
19858	Marque d'honneur zandalar
19859	Croc du Sans-Visage
19861	Larme de Chaos
19862	Egide du Dieu sanglant
19863	Sceau de primaliste
19864	Cherche-sang
19865	Lame de guerre des Hakkari
19866	Lame de guerre des Hakkari
19867	Défenseur du Seigneur sanglant
19869	Poignes inondées de sang
19870	Cape de loa hakkari
19871	Talisman de protection
19872	Raptor razzashi rapide
19873	Anneau cramoisi du suzerain
19874	Hallebarde de châtiment
19875	Coiffe tachée de sang
19876	Collier du Corrupteur d'âmes
19877	Jambières d'animiste
19878	Espauliers imprégnés de sang
19880	Collection de têtes de Gurubashi
19881	Tête du canaliste
19882	Tête du maléficieur
19883	Corde sacrée
19884	Jugement de Jin'do
19885	Mauvais oeil de Jin'do
19886	Couvre-chef du maléficieur
19887	Cuissards tachés de sang
19888	Etreinte de suzerain
19889	Jambières inondées de sang
19890	Maléficieur de Jin'do
19891	Sac de sales tours de Jin'do
19892	Bottes d'animiste
19893	Sceau de Zanzil
19894	Gantelets imprégnés de sang
19895	Kilt teinté de sang
19896	Poing de Thekal
19897	Bottes du traître
19898	Sceau de Jin
19899	Cuissards ritualistes
19900	Hache de pierre zulienne
19901	Hachoir zulien
19902	Tigre zulien rapide
19903	Croc de Venoxis
19904	Haubert runique taché de sang
19905	Anneau de Zanzil
19906	Bottes inondées de sang
19907	Cape zulienne en peau de tigre
19908	Sceptre de châtiment
19909	Volonté d'Arlokk
19910	Etreinte d'Arlokk
19911	Coeur d'herbe-fouet
19912	Anneau d'onyx du suzerain
19913	Grèves imprégnées de sang
19914	Sac en peau de panthère
19915	Défenseur zulien
19918	Ecraseur de Jeklik
19919	Grèves tachées de sang
19920	Anneau de primaliste
19921	Trancheuse zulienne
19922	Bâton porte-guigne d'Arlokk
19923	Talisman d'opaline de Jeklik
19925	Anneau de Jin
19927	Toucher de Mar'li
19928	Spallières d'animiste
19929	Gants teintés de sang
19930	Oeil de Mar'li
19931	Folie mojo des Gurubashi
19933	Sang de scorpide luminescent
19934	Grande griffe de scorpide
19935	Glande à venin vide
19936	Carapace de scorpide desséchée
19937	Petite griffe de scorpide
19938	Patte de scorpide épaisse
19939	Sang de Gri'lek
19940	Dent de Renataki
19941	Crinière de Wushoolay
19942	Fragment de rêve d'Hazza'rah
19943	Mojo écrasant
19944	Exterminateur de poisson de Nat Pagle
19945	Couvre-œil en écailles de lézard
19946	Harpon d'Aguilor
19947	Moulinet cassé de Nat Pagle
19948	Insigne de héros zandalarien
19949	Médaillon de héros zandalarien
19950	Charme de héros zandalarien
19951	Charme de puissance de Gri'lek
19952	Charme de courage de Gri'lek
19953	Charme des bêtes de Renataki
19954	Charme de supercherie de Renataki
19955	Charme de nature de Wushoolay
19956	Charme-esprits de Wushoolay
19957	Charme de destruction d'Hazza'rah
19958	Charme de soin d'Hazza'rah
19959	Charme de magie d'Hazza'rah
19960	Miel cristallisé
19961	Broyeur de Gri'lek
19962	Découpeur de Gri'lek
19963	Fourche de la folie
19964	Conducteur d'âme de Renataki
19965	Tisonnier de Wushoolay
19967	Flétrisseur de pensée
19968	Expiatrice ardente
19969	Bottes de pêche extrême de Nat Pagle
19970	Canne à pêche en arcanite
19971	Ligne de pêche à toute épreuve en éternium
19972	Chapeau du pêcheur chanceux
19973	Mètre ruban de Nat
19974	Appât au Puant de vase
19975	Puant de vase zulien
19978	Concours de pêche !
19979	Hameçon du maître pêcheur
19982	Drapé de chauve-souris du crépuscule
19984	Masque d'ébène
19986	Couvre-oeil de pirate
19989	Tome des ombres dévorantes
19990	Chapelet béni
19991	Oeil de diablosaure
19992	Dent de diablosaure
19993	Arc de chasse porte-guigne
19994	Fruit de la moisson
19995	Sanglier de la moisson
19996	Poisson de la moisson
19997	Nectar de la moisson
19998	Lentille en vignesang
19999	Lunettes en vignesang
20000	Schéma : Lunettes en vignesang
20001	Schéma : Lentille en vignesang
20002	Potion de sommeil sans rêve supérieure
20003	Griffes de diablosaure
20004	Potion de sang de troll majeure
20005	Griffes de diablosaure
20006	Cercle d'Espoir
20007	Potion Magesang
20008	Potion de vive action
20009	Pour la Lumière !
20010	Le Cri de la Horde
20011	Recette : Potion Magesang
20012	Recette : Sommeil sans rêve supérieur
20013	Recette : Potion de vive action
20014	Recette : Potion de sang de troll majeure
20015	Plumes d'Ancien raptor
20016	Crâne trophée de raptor
20017	Ramure de coursier parfaite
20018	Peau de grizzly de la griffe colérique
20019	Dent de Morphaz
20020	Lot de marchandises
20021	Boucle d'oreille de pirate en or
20022	Clé azur
20023	Fragment codé
20024	Canal biliaire putride
20025	Sang de Morphaz
20026	Chair en décomposition
20027	Glande de coursier en bonne santé
20028	Poussière lumineuse
20029	Corail enchanté
20030	Familier rocher
20031	Mangue d'essence
20032	Robe rituelle flottante
20033	Robe de démoniaque zandalar
20034	Robe d'illusionniste zandalar
20035	Pointe glaciale
20036	Rubis de feu
20037	Pendentif de cristal arcanique
20038	Aiguillon de Mandokir
20039	Bottes en sombrefer
20040	Plans : Bottes en sombrefer
20041	Ceinturon des Hautes-terres en plaques
20042	Ceinturon des Hautes-terres lamellaire
20043	Ceinturon des Hautes-terres en anneaux
20044	Ceinturon des Hautes-terres en mailles
20045	Ceinturon des Hautes-terres en cuir
20046	Ceinturon des Hautes-terres en cuir de lézard
20047	Ceinturon des Hautes-terres en tissu
20048	Grèves des Hautes-terres en plaques
20049	Grèves des Hautes-terres lamellaires
20050	Grèves des Hautes-terres en anneaux
20051	Grèves des Hautes-terres en mailles
20052	Bottes des Hautes-terres en cuir
20053	Bottes des Hautes-terres en cuir de lézard
20054	Bottes des Hautes-terres en tissu
20055	Espauliers des Hautes-terres en anneaux
20056	Espauliers des Hautes-terres en mailles
20057	Spallières des Hautes-terres en plaques
20058	Spallière des Hautes-terres lamellaire
20059	Epaulières des Hautes-terres en cuir
20060	Epaulières des Hautes-terres en cuir de lézard
20061	Epaulettes des Hautes-terres
20062	Ration enrichie du bassin d'Arathi
20063	Ration de campagne du bassin d'Arathi
20064	Ration de fer du bassin d'Arathi
20065	Bandage en tisse-mage du bassin d'Arathi
20066	Bandage en étoffe runique du bassin d'Arathi
20067	Bandage en soie du bassin d'Arathi
20068	Cape de garde noir
20069	Bâton d'écorcefer
20070	Griffe du sage
20071	Talisman d'Arathor
20072	Talisman du Profanateur
20073	Cape de la garde d'honneur
20074	Ragoût épais de crocilisque
20075	Recette : Ragoût épais de crocilisque
20076	Cachet de mojo zandalar
20077	Cachet de puissance zandalar
20078	Cachet de sérénité zandalar
20079	Esprit de Zanza
20080	Brillance de Zanza
20081	Rapidité de Zanza
20082	Bâton de malheur
20083	Epieu de chasse
20084	Filet de chasse
20085	Fragment d'arcane
20086	Couteau de lancer du crépuscule d'acier
20087	Ecailles de vandale des flots
20088	Ceinturon des Hautes-terres en anneaux
20089	Ceinturon des Hautes-terres en anneaux
20090	Ceinturon des Hautes-terres en anneaux
20091	Grèves des Hautes-terres en anneaux
20092	Grèves des Hautes-terres en anneaux
20093	Grèves des Hautes-terres en anneaux
20094	Bottes des Hautes-terres en tissu
20095	Bottes des Hautes-terres en tissu
20096	Bottes des Hautes-terres en tissu
20097	Ceinturon des Hautes-terres en tissu
20098	Ceinturon des Hautes-terres en tissu
20099	Ceinturon des Hautes-terres en tissu
20100	Bottes des Hautes-terres en cuir de lézard
20101	Bottes des Hautes-terres en cuir de lézard
20102	Bottes des Hautes-terres en cuir de lézard
20103	Ceinturon des Hautes-terres en cuir de lézard
20104	Ceinturon des Hautes-terres en cuir de lézard
20105	Ceinturon des Hautes-terres en cuir de lézard
20106	Ceinturon des Hautes-terres lamellaire
20107	Ceinturon des Hautes-terres lamellaire
20108	Ceinturon des Hautes-terres lamellaire
20109	Grèves des Hautes-terres lamellaires
20110	Grèves des Hautes-terres lamellaires
20111	Grèves des Hautes-terres lamellaires
20112	Bottes des Hautes-terres en cuir
20113	Bottes des Hautes-terres en cuir
20114	Bottes des Hautes-terres en cuir
20115	Ceinturon des Hautes-terres en cuir
20116	Ceinturon des Hautes-terres en cuir
20117	Ceinturon des Hautes-terres en cuir
20118	Ceinturon des Hautes-terres en mailles
20119	Ceinturon des Hautes-terres en mailles
20120	Ceinturon des Hautes-terres en mailles
20121	Grèves des Hautes-terres en mailles
20122	Grèves des Hautes-terres en mailles
20123	Grèves des Hautes-terres en mailles
20124	Ceinturon des Hautes-terres en plaques
20125	Ceinturon des Hautes-terres en plaques
20126	Ceinturon des Hautes-terres en plaques
20127	Grèves des Hautes-terres en plaques
20128	Grèves des Hautes-terres en plaques
20129	Grèves des Hautes-terres en plaques
20130	Flacon de diamant
20131	Tabard de bataille des Profanateurs
20132	Tabard de bataille d'Arathor
20134	Casque Fureur-du-ciel
20150	Ceinturon de Profanateur en anneaux
20151	Ceinturon de Profanateur en anneaux
20152	Ceinturon de Profanateur en anneaux
20153	Ceinturon de Profanateur en anneaux
20154	Grèves de Profanateur en anneaux
20155	Grèves de Profanateur en anneaux
20156	Grèves de Profanateur en anneaux
20157	Grèves de Profanateur en anneaux
20158	Espauliers de Profanateur en anneaux
20159	Bottes de Profanateur en tissu
20160	Bottes de Profanateur en tissu
20161	Bottes de Profanateur en tissu
20162	Bottes de Profanateur en tissu
20163	Ceinturon de Profanateur en tissu
20164	Ceinturon de Profanateur en tissu
20165	Ceinturon de Profanateur en tissu
20166	Ceinturon de Profanateur en tissu
20167	Bottes de Profanateur en cuir de lézard
20168	Bottes de Profanateur en cuir de lézard
20169	Bottes de Profanateur en cuir de lézard
20170	Bottes de Profanateur en cuir de lézard
20171	Ceinturon de Profanateur en cuir de lézard
20172	Ceinturon de Profanateur en cuir de lézard
20173	Ceinturon de Profanateur en cuir de lézard
20174	Ceinturon de Profanateur en cuir de lézard
20175	Epaulières de Profanateur en cuir de lézard
20176	Epaulettes de Profanateur
20177	Ceinturon lamellaire de Profanateur
20178	Ceinturon de Profanateur lamellaire
20179	Ceinturon lamellaire de Profanateur
20180	Ceinturon de Profanateur lamellaire
20181	Grèves de Profanateur lamellaires
20182	Grèves de Profanateur lamellaires
20183	Grèves de Profanateur lamellaires
20184	Spallière de Profanateur lamellaire
20185	Grèves de Profanateur lamellaires
20186	Bottes de Profanateur en cuir
20187	Bottes de Profanateur en cuir
20188	Bottes de Profanateur en cuir
20189	Bottes de Profanateur en cuir
20190	Ceinturon de Profanateur en cuir
20191	Ceinturon de Profanateur en cuir
20192	Ceinturon de Profanateur en cuir
20193	Ceinturon de Profanateur en cuir
20194	Epaulières de Profanateur en cuir
20195	Ceinturon de Profanateur en mailles
20196	Ceinturon de Profanateur en mailles
20197	Ceinturon de Profanateur en mailles
20198	Ceinturon de Profanateur en mailles
20199	Grèves de Profanateur en mailles
20200	Grèves de Profanateur en mailles
20201	Grèves de Profanateur en mailles
20202	Grèves de Profanateur en mailles
20203	Espauliers de Profanateur en mailles
20204	Ceinturon de Profanateur en plaques
20205	Ceinturon de Profanateur en plaques
20206	Ceinturon de Profanateur en plaques
20207	Ceinturon de Profanateur en plaques
20208	Grèves de Profanateur en plaques
20209	Grèves de Profanateur en plaques
20210	Grèves de Profanateur en plaques
20211	Grèves de Profanateur en plaques
20212	Spallières de Profanateur en plaques
20213	Ceinture de têtes rétrécies
20214	Croc de l'esprit
20215	Ceinture de têtes réduites
20216	Ceinture de têtes préservées
20217	Ceinture de têtes minuscules
20218	Cape hakkari terne
20219	Cape hakkari rapiécée
20220	Bâton d'écorcefer
20221	Monture fabuleuse
20222	Ration enrichie de profanateur
20223	Ration de campagne de profanateur
20224	Ration de fer de profanateur
20225	Ration enrichie des Hautes-terres
20226	Ration de campagne des Hautes-terres
20227	Ration de fer des Hautes-terres
20228	Paquetage amélioré de Profanateur
20229	Paquetage de base de Profanateur
20230	Paquetage ordinaire de Profanateur
20231	Paquetage amélioré d'Arathor
20232	Bandage en tisse-mage de profanateur
20233	Paquetage de base d'Arathor
20234	Bandage en étoffe runique de profanateur
20235	Bandage en soie de profanateur
20236	Paquetage ordinaire d'Arathor
20237	Bandage en tisse-mage des Hautes-terres
20243	Bandage en étoffe runique des Hautes-terres
20244	Bandage en soie des Hautes-terres
20253	Patron : Harnais de l'ours de guerre
20254	Patron : Jambières de l'ours de guerre
20255	Bottes de marche silencieuse
20256	Ruban de sacrifice du goulet des Warsong
20257	Gantelets Furie-des-mers
20258	Bâton de cérémonie zulien
20259	Gants en peau de panthère des ombres
20260	Jambières Furie-des-mers
20261	Ceinture en peau de panthère des ombres
20262	Bottes Furie-des-mers
20263	Heaume Gurubashi
20264	Gantelets de garde-paix
20265	Bottes de garde-paix
20266	Jambières de garde-paix
20295	Jambières en écailles de dragon bleu
20296	Gantelets en écailles de dragon vert
20310	Peau de démon écorché
20337	Tête de gnome sur une pique
20367	Equipement de chasse
20368	Arc de fermeté quelconque
20369	Poings en azurite
20371	Oeuf de murloc bleu
20373	Dard de scorpide Cinglepierre
20374	Dard de pinceur Cinglepierre
20375	Dard d'écorcheur Cinglepierre
20376	Croc de Glisseuse du sable
20377	Croc de traqueuse des rochers
20378	Fragment de la Tablette du crépuscule
20379	Sacoche de Noggle
20380	Cuirasse de rêvécaille
20381	Rêvécaille
20382	Patron : Cuirasse de rêvécaille
20383	Tête du seigneur des couvées Lashlayer
20384	Fragment de carapace de silithide
20385	Pince de Poigne-de-mort
20387	Paquet de boules puantes des Réprouvés
20388	Sucette
20389	Bonbons
20390	Barre de chocolat
20391	Masque de gnome fragile (H)
20392	Masque de gnome fragile (F)
20393	Sac de friandises
20394	Lexique du crépuscule - Chapitre 1
20395	Lexique du crépuscule - Chapitre 2
20396	Lexique du crépuscule - Chapitre 3
20397	Pirate
20398	Ninja
20399	Gnome lépreux
20400	Sac citrouille
20401	Tablette du crépuscule réparée
20402	Agent de Nozdormu
20403	Mandataire de Nozdormu
20404	Texte du crépuscule crypté
20405	Transcription décodée de la tablette
20406	Mantelet de sectateur du crépuscule
20407	Robe de sectateur du crépuscule
20408	Capuche de sectateur du crépuscule
20409	Fantôme
20410	Chauve-souris
20411	Squelette
20413	Aléatoire
20414	Feu follet
20415	La Guerre des sables changeants
20416	Blason de signal : Feu
20418	Blason de signal : Tonnerre
20419	Blason de signal : Pierre
20420	Blason de signal : Eau
20422	Médaillon de statut de sectateur du crépuscule
20423	Griffe de scorpide sableuse
20424	Chair de ver des sables
20425	Bâton noueux de conseiller
20426	Bague de conseiller
20427	Cape de soigneur de bataille
20428	Cape de conservateur
20429	Anneau de légionnaire
20430	Epée de légionnaire
20431	Bague de gardien du savoir
20432	Chevalière de signal : Feu
20433	Chevalière de signal : Tonnerre
20434	Bâton de gardien du savoir
20435	Chevalière de signal : Pierre
20436	Chevalière de signal : Eau
20437	Arc de voltigeur
20438	Arc d'estafette
20439	Anneau de protecteur
20440	Epée de protecteur
20441	Lame d'éclaireur
20442	Médaillon d'éclaireur
20443	Lame de Sentinelle
20444	Médaillon de Sentinelle
20447	Sceptre de signal : Feu
20448	Sceptre de signal : Tonnerre
20449	Sceptre de signal : Pierre
20450	Sceptre de signal : Eau
20451	Anneau d'autorité de sectateur du crépuscule
20452	Boulettes fumées du désert
20453	Trousse de transcription du géologue
20454	Reproduction de la Ruche'Zora
20455	Reproduction de la Ruche'Ashi
20456	Reproduction de la Ruche'Regal
20457	Cerveau de silithide de la Ruche'Ashi
20458	Cerveau de silithide de la Ruche'Zora
20459	Cerveau de silithide de la Ruche'Regal
20460	Lettre perdue de Brann Bronzebeard
20461	Lettre perdue de Brann Bronzebeard
20462	Médaillon de la Sanssaint
20463	Prisme cristallin orné de glyphes
20464	Glyphes d'appel
20465	Mécanisme de déverrouillage du cristal
20466	Chevalière de Vyral
20467	Page de recette déchirée
20469	Articles du Vrai Croyant décodés
20475	Gemme d'âme
20476	Brassards de traqueuse des sables
20477	Gantelets de traqueuse des sables
20478	Cuirasse de traqueuse des sables
20479	Cuirasse de crache-feu
20480	Gantelets de crache-feu
20481	Brassards de crache-feu
20485	Sceau du duc
20487	Lok'delar, bâton des Gardiens anciens DEP
20488	Rhok'delar, arc long des Gardiens anciens DEP
20489	Couronne du conseil
20490	Bonbon à la menthe d'Ironforge
20491	Bonbon à la menthe d'Undercity
20492	Nougat de Stormwind
20493	Nougat d'Orgrimmar
20494	Boule de gomme de Gnomeregan
20495	Boule de gomme de Darkspear
20496	Massepain de Darnassus
20497	Massepain de Thunder Bluff
20498	Chitine de silithide
20499	Chitine brisée de silithide
20500	Carapace légère de silithide
20501	Carapace lourde de silithide
20502	Bouclier d'écorcefer
20503	Esprit de l'eau amoureux
20504	Lame de Sancteforge
20505	Chevalière chevaleresque
20506	Patron : Brassards de crache-feu
20507	Patron : Gantelets de crache-feu
20508	Patron : Cuirasse de crache-feu
20509	Patron : Brassards de traqueuse des sables
20510	Patron : Gantelets de traqueuse des sables
20511	Patron : Cuirasse de traqueuse des sables
20512	Orbe sanctifié
20513	Blason abyssal
20514	Chevalière abyssale
20515	Sceptre abyssal
20516	Pomme d'amour
20517	Epaulières d'acier-rasoir
20518	Parchemin : Création d'un blason de signal
20519	Chapeau de pirate des Mers du sud
20520	Rune ténébreuse
20521	Visière de fureur
20522	Bâton farouche
20524	Jambières ombrepoil
20525	Glyphe terrestre
20526	Parchemin : Création d'un blason de signal
20527	Parchemin : Création d'un blason de signal
20528	Parchemin : Création d'un blason de signal
20530	Robe de servitude
20531	Parchemin : Création d'une chevalière de signal
20532	Parchemin : Création d'une chevalière de signal
20533	Parchemin : Création d'une chevalière de signal
20534	Eclat abyssal
20535	Parchemin : Création d'une chevalière de signal
20536	Moissonneuse d'âmes
20537	Bottes runiques ténébreuses
20538	Jambières runiques ténébreuses
20539	Ceinture runique ténébreuse
20540	Parchemin : Création d'un sceptre de signal
20541	Texte du crépuscule décodé
20542	Parchemin : Création d'un sceptre de signal
20543	Parchemin : Création d'un sceptre de signal
20544	Parchemin : Création d'un sceptre de signal
20545	Texte du crépuscule décodé
20546	Patron: Jambières runiques ténébreuses
20547	Patron: Bottes runiques ténébreuses
20548	Patron : Ceinture runique ténébreuse
20549	Gantelets de sombrerune
20550	Cuirasse de sombrerune
20551	Heaume de sombrerune
20552	Texte du crépuscule décodé
20553	Plans : Gantelets de sombrerune
20554	Plans : Cuirasse de sombrerune
20555	Plans : Heaume de sombrerune
20556	Bâton sauvage
20557	Bonbon à la citrouille de la Sanssaint
20558	Marque d'honneur du goulet des Warsong
20559	Marque d'honneur du bassin d'Arathi
20560	Marque d'honneur de la vallée d'Alterac
20561	Masque de nain fragile
20562	Masque de naine fragile
20563	Masque d'elfe de la nuit fragile (F)
20564	Masque d'elfe de la nuit fragile (H)
20565	Masque d'humaine fragile
20566	Masque d'humain fragile
20567	Masque de trollesse fragile
20568	Masque de troll fragile
20569	Masque d'orque fragile
20570	Masque d'orc fragile
20571	Masque de taurène fragile
20572	Masque de tauren fragile
20573	Masque de mort-vivant fragile
20574	Masque de morte-vivante fragile
20575	Tunique de dragonnet noir
20576	Patron : Tunique de dragonnet noir
20577	Lame de cauchemar
20578	Croc-de-dragon émeraude
20579	Cape en peau de dragon vert
20580	Marteau de fureur bestiale
20581	Bâton de croissance luxuriante
20582	Pierre de transe
20583	Masque de naine solide
20584	Masque de gnome solide (F)
20585	Masque d'humaine solide
20586	Masque d'elfe de la nuit solide (F)
20587	Masque d'orque solide
20588	Masque de taurène solide
20589	Masque de trollesse solide
20590	Masque de morte-vivante solide
20591	Masque de nain solide
20592	Masque de gnome solide (H)
20593	Masque d'humain solide
20594	Masque d'elfe de la nuit solide (H)
20595	Masque d'orc solide
20596	Masque de tauren solide
20597	Masque de troll solide
20598	Masque de mort-vivant solide
20599	Arbalète en bois de fer poli
20600	Chevalière de Malfurion
20601	Besace de butin
20602	Coffre de butin
20603	Sac de butin
20604	Nettoyeur de boules puantes
20605	Oeufs pourris
20606	Plume vaudou ambre
20607	Plume vaudou bleue
20608	Plume vaudou verte
20609	Plumes vaudou
20610	Oeil d'araignée injecté de sang
20611	Griffe noire épaisse
20612	Pierre du Fléau inerte
20613	Bois pourri
20614	Essence de Vénéneuse
20615	Couvre-bras aiguillon-de-dragon
20616	Garde-poignets os-de-dragon
20617	Jambières anciennes corrodées
20618	Gantelets de la puissance illusoire
20619	Grèves gravées à l'acide
20620	Pierre de pouvoir sacrée
20621	Bottes de la lande infinie
20622	Collier coeur-de-dragon
20623	Diadème des rêves troublés
20624	Anneau des non-vivants
20625	Ceinture de la tourbière sombre
20626	Protège-poignets d'écorce noire
20627	Pantalon du coeur noir
20628	Coiffe de croissance déviante
20629	Bottillons malveillants
20630	Gantelets de la lumière étincelante
20631	Chaussons malveillants
20632	Anneau de la déchirure d'esprit
20633	Spallières contre-nature en cuir
20634	Bottes d'effroi
20635	Habit enchassé de jade
20636	Cristal d'hibernation
20637	Espauliers gravés à l'acide
20638	Jambières de l'esprit dément
20639	Cuissards ornés de glyphes étranges
20640	Seau de tête des Mers du sud
20641	Bottes mojo des Mers du sud
20642	Tunique noble antique
20643	Coiffe de réserviste d'Undercity
20644	Objet noyé dans les cauchemars
20645	Murmure de la nature
20646	Marque de trotteur des sables
20647	Dague en cristal noir
20648	Marteau forgé à froid
20649	Pendentif du prisme solaire
20650	Gantelets du vent du désert
20651	Oeuf de murloc orange
20652	Mules abyssales en tissu
20653	Gantelets abyssaux en plaques
20654	Bâton de guerre d'améthyste
20655	Protège-mains abyssaux en tissu
20656	Solerets abyssaux en mailles
20657	Stylet à pointe de cristal
20658	Bottes abyssales en cuir
20659	Garde-mains abyssaux en mailles
20660	Vouge tranche-pierre
20661	Gants abyssaux en cuir
20662	Grèves abyssales en plaques
20663	Arc de frappe pénétrante
20664	Echarpe abyssale en tissu
20665	Jambières abyssales en cuir
20666	Marteau de guerre à tête d'acier
20667	Ceinture abyssale en cuir
20668	Cuissards abyssaux en mailles
20669	Claymore de Darkstone
20670	Etreinte abyssale en mailles
20671	Cuissards abyssaux en plaques
20672	Baguette de cristal étincelant
20673	Ceinturon abyssal en plaques
20674	Pantalon abyssal en tissu
20675	Déchiqueteur d'âme
20676	Texte du crépuscule décodé
20677	Texte du crépuscule décodé
20678	Texte du crépuscule décodé
20679	Texte du crépuscule décodé
20680	Espauliers abyssaux en mailles
20681	Brassards abyssaux en cuir
20682	Anneau de focalisation élémentaire
20683	Epaulettes abyssales en plaques
20684	Garde-bras abyssaux en mailles
20685	Collier du front de mer
20686	Amict abyssal en tissu
20687	Protège-bras abyssaux en plaques
20688	Garde terrestre
20689	Epaulières abyssales en cuir
20690	Protège-poignets abyssaux en tissu
20691	Cape des Cisailles
20692	Anneau multicolore
20693	Cape lestée
20694	Orbe noir luminescent
20695	Collier de guerre abyssal
20696	Maillet à pointes de cristal
20697	Cape brochée de cristal
20698	Lame d'harmonisation élémentaire
20699	Cuissards de réserviste cénariens
20700	Cuissards de réserviste cénariens
20701	Cuissots de réserviste cénariens
20702	Cuissots de réserviste cénariens
20703	Jambières de réserviste cénariennes
20704	Jambières de réserviste cénariennes
20705	Pantalon de réserviste cénarien
20706	Pantalon de réserviste cénarien
20707	Pantalon de réserviste cénarien
20708	Malle soigneusement scellée
20709	Rhum doux de Rumsey
20710	Grèves incrustées de cristaux
20711	Grèves revêtues de cristaux
20712	Gantelets de la marche aride
20713	Gantelets de traqueur du désert
20714	Bottes de tempête de sable
20715	Bottes d'arpenteur de dunes
20716	Gants en peau de ver des sables
20717	Gants de la fleur du désert
20720	Lame du noir murmure
20721	Anneau du sectateur
20722	Lance-balles en cristal
20723	Pioche loyale de Brann
20724	Bâton noirbois corrompu
20725	Cristal de nexus
20726	Formule : Enchantement de gants (Menace)
20727	Formule : Enchantement de gants (Puissance de l'ombre)
20728	Formule : Enchantement de gants (Puissance du givre)
20729	Formule : Enchantement de gants (Puissance du feu)
20730	Formule : Enchantement de gants (Pouvoir de guérison)
20731	Formule : Enchantement de gants - Agilité excellente
20732	Formule : Enchantement de cape (Résistance au feu supérieure)
20733	Formule : Enchantement de cape (Résistance à la nature supérieure)
20734	Formule : Enchantement de cape (Camouflage)
20735	Formule : Enchantement de cape (Discrétion)
20736	Formule : Enchantement de cape (Esquive)
20737	Pierre du Magma roussie
20741	Totem rituel mort-bois
20742	Totem rituel tombe-hiver
20744	Huile de sorcier mineure
20745	Huile de mana mineure
20746	Huile de sorcier inférieure
20747	Huile de mana inférieure
20748	Huile de mana brillante
20749	Huile de sorcier brillante
20750	Huile de sorcier
20752	Formule : Huile de mana mineure
20753	Formule : Huile de sorcier inférieure
20754	Formule : Huile de mana inférieure
20755	Formule : Huile de sorcier
20756	Formule : Huile de sorcier brillante
20757	Formule : Huile de mana brillante
20758	Formule : Huile de sorcier mineure
20761	Recette : Transmutation du feu élémentaire
20763	Arme brisée
20766	Sac visqueux
20767	Sac couvert de crasse
20768	Sac vaseux
20769	Suinteux dégoûtant
20770	Ichor vert bouillonnant
20800	Badge cénarien de logistique
20801	Badge cénarien de tactique
20802	Badge cénarien de combat
20803	Ordres de bataille du Crépuscule
20805	Affectation logistique complémentaire
20806	Briefing logistique X
20807	Briefing logistique I
20808	Affectation de combat
20809	Affectation tactique
20810	Ordre de mission signé
20814	Dague de jet du maître
20834	Longue-vue ornée XT
20844	Poison mortel V
20858	Scarabée de pierre
20859	Scarabée d'or
20860	Scarabée d'argent
20861	Scarabée en bronze
20862	Scarabée de cristal
20863	Scarabée d'argile
20864	Scarabée d'os
20865	Scarabée d'ivoire
20866	Idole azur
20867	Idole d'onyx
20868	Idole brillante
20869	Idole d'ambre
20870	Idole de jaspe
20871	Idole en obsidienne
20872	Idole vermillon
20873	Idole d'albâtre
20874	Idole du soleil
20875	Idole de la nuit
20876	Idole de la mort
20877	Idole du sage
20878	Idole de la renaissance
20879	Idole de la vie
20881	Idole de la lutte
20882	Idole de la guerre
20883	Joyau qiraji orné de glyphes
20884	Anneau de magistrat qiraji
20885	Drapé martial qiraji
20886	Manche à pointes qiraji
20887	Joyau qiraji ciselé
20888	Anneau de cérémonie qiraji
20889	Drapé royal qiraji
20890	Manche orné qiraji
20908	Feu d'artifice du festival de Nian
20926	Diadème de Vek'nilash
20927	Peau intacte d'Ouro
20928	Manchettes de commandement qiraji
20929	Carapace du Dieu très ancien
20930	Diadème de Vek'lor
20931	Peau du Grand ver des sables
20932	Manchettes de domination qiraji
20933	Carcasse du Dieu très ancien
20936	Joyau qiraji béni
20937	Joyau qiraji enchassé
20939	Briefing logistique II
20940	Briefing logistique III
20941	Briefing de combat XII
20942	Briefing de combat III
20943	Briefing tactique X
20944	Briefing tactique IX
20945	Briefing tactique II
20946	Briefing tactique III
20947	Briefing tactique IV
20948	Briefing tactique V
20949	Grand livre magique
20951	Lunettes de divination de Narain
21023	Pyro-côtelettes de chimaerok à la Dirge
21024	Filet de chimaerok
21025	Recette : Pyro-côtelettes de chimaerok à la Dirge
21027	Carcasse de Lakmaeran
21028	Poulet de 500 livres
21029	Demande de rançon
21030	Tourte au kimchi de Darnassus
21031	Kimchi de chou
21032	Lettre d'amour de Meridith
21033	Kimchi de radis
21037	Carte grossière
21038	Boule de neige durcie
21039	Turban de Narain
21040	Robe de Narain
21041	Sac d'or
21042	Panoplie spéciale de Narain
21043	Enveloppe mystérieuse
21071	Sagerelle crue
21072	Sagerelle fumée
21099	Recette : Sagerelle fumée
21100	Pièce des ancêtres
21103	Le draconique pour les nuls
21104	Le draconique pour les nuls
21105	Le draconique pour les nuls
21106	Le draconique pour les nuls
21107	Le draconique pour les nuls
21108	Le draconique pour les nuls
21109	Le draconique pour les nuls
21110	Le draconique pour les nuls
21111	Le draconique pour les nuls : volume II
21112	Reliure magique
21113	Malle étanche
21114	Rhum brun de Rumsey
21115	Talisman de profanateur
21116	Talisman de profanateur
21117	Talisman d'Arathor
21118	Talisman d'Arathor
21119	Talisman d'Arathor
21120	Talisman de profanateur
21126	Aiguillon de la mort
21128	Bâton des prophètes qiraji
21130	Journal de Weavil
21131	Affectation de combat complémentaire
21132	Affectation logistique
21133	Affectation tactique complémentaire
21134	Sombre doloire de la démence
21135	Hache de lancer de l'assassin
21136	Bouée en arcanite
21137	Fragment de sceptre bleu
21138	Fragment de sceptre rouge
21139	Fragment de sceptre vert
21140	Reçu de l'hôtel des ventes
21141	Fragment de sceptre rouge détruit
21142	Note trouvée sur le bureau du seigneur Victor Nefarius
21143	Ordre de mission non signé
21144	Torche d'invocation de démon
21145	Essence de Xandivious
21146	Fragment de la corruption du Cauchemar
21147	Fragment de la corruption du Cauchemar
21148	Fragment de la corruption du Cauchemar
21149	Fragment de la corruption du Cauchemar
21150	Malle cerclée de fer
21151	Rhum de Rumsey label noir
21152	La Corruption du cauchemar
21153	Grande sagerelle crue
21154	Robe de fête
21155	Offrande de paix grumegueule
21156	Sac de scarabées
21157	Robe de fête verte
21158	Rapport de reconnaissance de la Ruche'Zora
21159	Ordres de reconnaissance de la Ruche'Zora
21160	Rapport de reconnaissance de la Ruche'Regal
21161	Rapport de reconnaissance de la Ruche'Ashi
21162	Bouche-noire huileux boursouflé
21163	Nagefeu boursouflé
21164	Morue rochécaille boursouflée
21165	Briefing tactique VI
21166	Briefing tactique VII
21167	Briefing tactique VIII
21168	Bébé requin
21171	Chope de fête remplie
21173	Chope de fête vide
21174	Chope de fête vide
21175	Le Sceptre des Sables changeants
21176	Cristal de résonance qiraji noir
21177	Symbole des rois
21178	Gants de puissance terrestre
21179	Anneau du courroux terrestre
21180	Choc de terre
21181	Grâce de la Terre
21182	Anneau de puissance terrestre
21183	Gilet de puissance de la terre
21184	Brassards de Fonderoc
21185	Orbe calme-terre
21186	Brassards Furie-du-roc
21187	Cape en tisse-terre
21188	Poing de Cénarius
21189	Puissance de Cénarius
21190	Courroux de Cénarius
21191	Cadeau soigneusement emballé
21193	Sac de D'Sak
21194	Grand sac de D'Sak
21195	Sactastique de D'Sak
21196	Chevalière du Vol de bronze
21197	Chevalière du Vol de bronze
21198	Chevalière du Vol de bronze
21199	Chevalière du Vol de bronze
21200	Chevalière du Vol de bronze
21201	Chevalière du Vol de bronze
21202	Chevalière du Vol de bronze
21203	Chevalière du Vol de bronze
21204	Chevalière du Vol de bronze
21205	Chevalière du Vol de bronze
21206	Chevalière du Vol de bronze
21207	Chevalière du Vol de bronze
21208	Chevalière du Vol de bronze
21209	Chevalière du Vol de bronze
21210	Chevalière du Vol de bronze
21211	Bourse de poudre de renne
21212	Houx frais
21213	Houx préservé
21214	Tome d'Eclair de givre XI
21215	Gâteau aux fruits secs de Graccu
21216	Cadeau extra-spécial des Gourmandises Fumebois
21217	Délice de sagerelle
21218	Cristal de résonance qiraji bleu
21219	Recette : Délice de sagerelle
21220	Tête d'Ossirian l'Intouché
21221	Oeil de C'Thun
21222	Chitine cuirassée
21223	Pierre noire
21224	Fragment d'armure ancienne
21225	Carcasse de silithide lourde
21226	Pierre runique
21227	Crâne d'ancien héros
21228	Malle cerclée de mithril
21229	Insigne de seigneur qiraji
21230	Ancien artefact qiraji
21232	Armes impériales qiraji
21235	Rôti du Voile d'hiver
21236	Pain du Voile d'hiver
21237	Tenue de parade impériale qiraji
21240	Bonbon du Voile d'hiver
21241	Lait de poule du Voile d'hiver
21242	Hache de guerre qiraji bénie
21243	Barracuda boursouflé
21244	Pugio qiraji béni
21245	Briefing tactique I
21246	Briefing de combat I
21247	Briefing de combat II
21248	Briefing de combat IV
21249	Briefing de combat V
21250	Briefing de combat VI
21251	Briefing de combat VII
21252	Briefing de combat VIII
21253	Briefing de combat IX
21254	Biscuit du Voile d'hiver
21255	Briefing de combat X
21256	Briefing de combat XI
21257	Briefing logistique IV
21258	Briefing logistique IV
21259	Briefing logistique V
21260	Briefing logistique VI
21261	Briefing logistique VI
21262	Briefing logistique VIII
21263	Briefing logistique VII
21264	Briefing logistique VII
21265	Briefing logistique IX
21266	Affectation logistique
21267	Coupe de "santé"
21268	Marteau de guerre qiraji béni
21269	Pavois qiraji béni
21270	Cadeau secoué doucement
21271	Cadeau secoué doucement
21272	Mousquet qiraji béni
21273	Bâton d'acolyte qiraji béni
21275	Bâton d'augure qiraji béni
21277	Yéti mécanique paisible
21278	Gants tempétueux
21279	Tome de Boule de feu XII
21280	Tome de Projectile des arcanes VIII
21281	Grimoire de Trait de l'ombre X
21282	Grimoire d'immolation VIII
21283	Grimoire de Corruption VII
21284	Codex de Soins supérieurs V
21285	Codex de Rénovation X
21287	Codex de Prière de soins V
21288	Libram : Bénédiction de sagesse VI
21289	Libram : Bénédiction de puissance VII
21290	Libram : Lumière sacrée IX
21291	Tablette de Vague de soins X
21292	Tablette de Totem de force de la terre V
21293	Tablette de Totem de grâce aérienne III
21294	Livre de Toucher guérisseur XI
21295	Livre de Feu stellaire VII
21296	Livre de Récupération XI
21297	Manuel de Frappe héroïque IX
21298	Manuel de Cri de guerre VII
21299	Manuel de Vengeance VI
21300	Recueil : Attaque sournoise IX
21301	Boîte à assistant vert
21302	Recueil : Poison mortel V
21303	Recueil : Feinte V
21304	Guide : Flèches multiples V
21305	Boîte à assistant rouge
21306	Guide : Morsure du serpent IX
21307	Guide : Aspect du faucon VII
21308	Clochette tintinnabulante
21309	Boîte de bonhomme de neige
21310	Cadeau à l'emballage multicolore
21311	Gilet de gardien de la terre
21312	Ceinture du protecteur
21313	Petit sac de D'Sak
21314	Lettres et notes sur Metzen
21315	Sacoche Fumebois
21316	Jambières de l'ursa
21317	Casque du guide
21318	Gants de gardien de la terre
21319	Gants du guide
21320	Haubergeon du protecteur
21321	Cristal de résonance qiraji rouge
21322	Etreinte d'ursa
21323	Cristal de résonance qiraji vert
21324	Cristal de résonance qiraji jaune
21325	Grinche mécanique
21326	Défenseur des Grumegueules
21327	Cadeau tic-taquant
21328	Baguette de liesse festive
21329	Couronne du Conquérant
21330	Spallières du Conquérant
21331	Cuirasse du Conquérant
21332	Cuissards du Conquérant
21333	Grèves du Conquérant
21334	Robe d'implorateur funeste
21335	Mantelet d'implorateur funeste
21336	Pantalon d'implorateur funeste
21337	Diadème d'implorateur funeste
21338	Bottines d'implorateur funeste
21340	Bourse d'âme
21341	Sac en gangrétoffe
21342	Sac en gangrétoffe du Magma
21343	Robe de l'énigme
21344	Bottes de l'énigme
21345	Protège-épaules de l'énigme
21346	Jambières de l'énigme
21347	Diadème de l'énigme
21348	Tiare de l'oracle
21349	Bottines de l'oracle
21350	Mantelet de l'oracle
21351	Habit de l'oracle
21352	Pantalon de l'oracle
21353	Casque de la genèse
21354	Protège-épaules de la genèse
21355	Bottes de la genèse
21356	Pantalon de la genèse
21357	Gilet de la genèse
21358	Patron : Bourse d'âme
21359	Bottes de dispensateur de mort
21360	Casque de dispensateur de mort
21361	Spallières de dispensateur de mort
21362	Jambières de dispensateur de mort
21363	Cadeau de fête
21364	Gilet de dispensateur de mort
21365	Bottes du Frappeur
21366	Diadème du Frappeur
21367	Espauliers du Frappeur
21368	Jambières du Frappeur
21369	Patron : Sac en gangrétoffe
21370	Haubert du Frappeur
21371	Patron : Sac en gangrétoffe du Magma
21372	Diadème d'implorateur de tempête
21373	Bottes d'implorateur de tempête
21374	Haubert d'implorateur de tempête
21375	Jambières d'implorateur de tempête
21376	Espauliers d'implorateur de tempête
21377	Coiffure de plumes mort-bois
21378	Briefing logistique I
21379	Briefing logistique II
21380	Briefing logistique III
21381	Briefing logistique IX
21382	Briefing logistique V
21383	Perles d'esprit tombe-hiver
21384	Briefing logistique VIII
21385	Briefing logistique X
21386	Affectation logistique complémentaire
21387	Couronne du Vengeur
21388	Grèves du Vengeur
21389	Cuirasse du Vengeur
21390	Cuissards du Vengeur
21391	Espauliers du Vengeur
21392	Faucille de force inflexible
21393	Chevalière de force inflexible
21394	Drapé de force inflexible
21395	Lame de justice éternelle
21396	Anneau de justice éternelle
21397	Cape de justice éternelle
21398	Marteau de la tempête imminente
21399	Anneau de la tempête imminente
21400	Cape de la tempête imminente
21401	Faux du sentier invisible
21402	Chevalière du sentier invisible
21403	Cape du sentier invisible
21404	Dague des ombres voilées
21405	Anneau des ombres voilées
21406	Cape des ombres voilées
21407	Masse de vie interminable
21408	Anneau de vie interminable
21409	Cape de vie interminable
21410	Marteau de sagesse infinie
21411	Anneau de sagesse infinie
21412	Voile de sagesse infinie
21413	Lame des secrets scellés
21414	Anneau des secrets scellés
21415	Drapé des secrets scellés
21416	Kriss des noms inexprimés
21417	Anneau des noms inexprimés
21418	Voile des noms inexprimés
21436	Chevalière de mérite de l'Alliance
21438	Chevalière de mérite de la Horde
21452	Bâton des ruines
21453	Mantelet de l'Horusath
21454	Epaulières de pierre runique
21455	Casque de Sudevent
21456	Cape de tempête de sable
21457	Brassards de brutalité
21458	Gantelets de nouvelle vie
21459	Arbalète de destin imminent
21460	Heaume de domination
21461	Jambières du blizzard noir
21462	Gants de la sombre sagesse
21463	Manchettes d'Ossirian
21464	Menottes de l'Intouché
21466	Aiguillon d'Ayamiss
21467	Corselet silithide épais
21468	Mantelet de Maz'Nadir
21469	Gantelets de Sudevent
21470	Cape du sauveur
21471	Serre de concentration furieuse
21472	Turban terrevent
21473	Oeil de Moam
21474	Garde-épaules chitineux
21475	Cuissards du Destructeur
21476	Jambières en écailles d'obsidienne
21477	Anneau de fureur
21478	Arc du boyau tendu
21479	Gantelets de l'Inébranlable
21480	Gantelets d'écailles silithide
21481	Bottes du protecteur du désert
21482	Bottes des sables brûlants
21483	Anneau des vents du désert
21484	Casque de rétablissement
21485	Fragment du crâne de Buru
21486	Gants de l'essaim
21487	Gantelets d'écailles visqueux
21488	Fétiche d'épines chitineuses
21489	Cuissardes des sables mouvants
21490	Ecrase-gelées
21491	Brassards d'écailles du Grandgosier
21492	Massacreuse des Qiraji
21493	Bottes de l'avant-garde
21494	Torsade de Sudevent
21495	Cuissards du commandement qiraji
21496	Brassards de commandement qiraji
21497	Bottes du général qiraji
21498	Dague sacrificielle qiraji
21499	Habit des Sables changeants
21500	Ceinture de l'inquisition
21501	Gants en cuir de silithide raffermi
21502	Garde-poignets de ravageur des sables
21503	Ceinture du ravageur des sables
21504	Charme des Sables changeants
21505	Foulard des Sables changeants
21506	Pendentif des Sables changeants
21507	Amulette des Sables changeants
21508	Marque de Cénarius
21509	Fournitures de l'effort de guerre d'Ahn'Qiraj
21510	Fournitures de l'effort de guerre d'Ahn'Qiraj
21511	Fournitures de l'effort de guerre d'Ahn'Qiraj
21512	Fournitures de l'effort de guerre d'Ahn'Qiraj
21513	Fournitures de l'effort de guerre d'Ahn'Qiraj
21514	Briefing logistique XI
21515	Marque de Remulos
21517	Turban gnome de puissance psychique
21519	Gui
21520	Héritage de Ravencrest
21521	Epée runique du Rouge
21522	Douleur de Shadowsong
21523	Croc de Korialstrasz
21524	Chapeau d'hiver rouge
21525	Chapeau d'hiver vert
21526	Anneau des profondeurs glacées
21527	Robe des eaux sombres
21528	Sac de butin colossal
21529	Amulette de bouclier contre l'ombre
21530	Jambières enchâssées d'onyx
21531	Collier en dents de drake
21532	Bottes de manœuvre
21533	Carcasse du colosse de Zora
21534	Carcasse du colosse d'Ashi
21535	Carcasse du colosse de Regal
21536	Pierre d'Elune
21537	Raviolis de fête
21538	Robe de fête rose
21539	Robe de fête violette
21540	Lanterne d'Elune
21541	Habit de fête noir
21542	Habit de fête
21543	Habit de fête turquoise
21544	Habit de fête bleu
21545	Marchandises des Gourmandises Fumebois
21546	Elixir de maîtrise du feu supérieure
21547	Recette : Elixir de maîtrise du feu supérieure
21548	Patron : Gants tempétueux
21552	Jaune-queue rayé
21557	Petite comète rouge
21558	Petite comète bleue
21559	Petite comète verte
21560	Petite comète violette
21561	Petite comète blanche
21562	Petite comète jaune
21563	Anneau de Don Rodrigue
21565	Rune de perfection
21566	Rune de perfection
21567	Rune de devoir
21568	Rune de devoir
21569	Lanceur de fusée
21570	Lanceur de chapelets
21571	Chapelet de comètes bleues
21574	Chapelet de comètes vertes
21575	Chapelet de comètes violettes
21576	Chapelet de comètes rouges
21577	Chapelet de comètes blanche
21578	Chapelet de comètes jaunes
21579	Tentacule de C'Thun vaincu
21581	Gantelets d'annihilation
21582	Torsade  du Dieu très ancien
21583	Cape de clarté
21584	Brassards de rétorsion éternelle
21585	Gantelets du sombre orage
21586	Ceinture d'agonie sans fin
21587	Garde-poignets de punition
21588	Garde-poignets de fureur élémentaire
21589	Grande comète bleue
21590	Grande comète verte
21591	Grande comète violette
21592	Grande comète rouge
21593	Grande comète blanche
21594	Brassards du fils déchu
21595	Grande comète jaune
21596	Anneau du tueur de dieu
21597	Sceptre royal de Vek'lor
21598	Ceinture royale qiraji
21599	Gants de dévastation de Vek'lor
21600	Bottes de l'épiphanie
21601	Anneau de l'empereur Vek'lor
21602	Brassards d'exécution quiraji
21603	Baguette de noblesse qiraji
21604	Bracelets de rédemption royale
21605	Gants du temple caché
21606	Ceinture de l'empereur déchu
21607	Torsade de l'empereur déchu
21608	Amulette de Vek'nilash
21609	Ceinture régénérante de Vek'nilash
21610	Bouclier en écailles de ver
21611	Brassards de fouisseur
21612	Marteleurs en écailles de ver
21613	Bottes en peau de ver
21614	Protecteur en peau de ver
21615	Chapeau égaré de Don Rigoberto
21616	Aiguillon d'Huhuran
21617	Gantelets en peau de guêpe
21618	Garde-poignets de profanateur de ruche
21619	Gants du messie
21620	Anneau du martyr
21621	Cape de la Ruche d'or
21622	Fémur de silithide aiguisé
21623	Gantelets du champion vertueux
21624	Gantelets de Kalimdor
21625	Broche scarabée
21626	Jambières couvertes de vase
21627	Cape des secrets inexprimables
21635	Guisarme du ravageur des sables
21639	Espauliers de l'Implacable
21640	Sac de feux d'artifice de la fête lunaire
21645	Bottes de tunnelière de la ruche
21647	Fétiche du ravageur des sables
21648	Bottes recomposées
21650	Ancien éventreur qiraji
21651	Jambières de ravageur des sables en écailles
21652	Corselet en carapace de silithide
21663	Robe du saint gardien
21664	Collier barbelé
21665	Mantelet de vengeance cruelle
21666	Pouvoir de Sartura
21667	Cuissards de lumière flamboyante
21668	Jambières de fureur qiraji en écailles
21669	Casque des lianes rampantes
21670	Insigne de garde-essaim
21671	Robe du garde de guerre
21672	Gants de coercition
21673	Griffe de silithide
21674	Gantelets de détermination inébranlable
21675	Ceinture qiraji en peau épaisse
21676	Jambières de l'essaim purulent
21677	Anneau de fureur qiraji
21678	Collier de pureté
21679	Vengeance de Kalimdor
21680	Gilet d'exécution rapide
21681	Anneau du dévoré
21682	Gantelets couverts de bile
21683	Mantelet de la croisade du désert
21684	Mantelet de la fureur du désert
21685	Scarabée pétrifié
21686	Mantelet de la puissance phrénique
21687	Anneau de ténèbres d'Ukko
21688	Bottes du héros déchu
21689	Gants d'Ebru
21690	Charme d'Angelista
21691	Gantelets éclaboussés de vase
21692	Ceinture de la triade
21693	Semblance du dévoreur
21694	Mantelet ternaire
21695	Toucher d'Angelista
21696	Robe du triumvirat
21697	Cape de la trinité
21698	Jambières d'immersion
21699	Epaulières du barrage
21700	Pendentif du gardien qiraji
21701	Cape de concentré de haine
21702	Amulette de vile sauvegarde
21703	Marteau de Ji'zhi
21704	Bottes de la prophétie rédemptrice
21705	Bottes du prophète déchu
21706	Bottes de la volonté inexorable
21707	Anneau de pensée foisonnante
21708	Garde-poignets en écailles de hanneton
21709	Anneau du dieu déchu
21710	Cape du dieu déchu
21711	Invitation à la fête lunaire
21712	Amulette du dieu déchu
21713	Chandelle d'Elune
21714	Chapelet de grandes comètes bleues
21715	Marteau poli au sable
21716	Chapelet de grandes comètes vertes
21717	Chapelet de grandes comètes violettes
21718	Chapelet de grandes comètes rouges
21719	Chapelet de grandes comètes blanches
21720	Chapelet de grandes comètes jaunes
21721	Lueur de la lune
21722	Patron : Robe de fête
21723	Patron : Habit de fête
21724	Schéma : Petite comète bleue
21725	Schéma : Petite comète verte
21726	Schéma : Petite comète rouge
21727	Schéma : Grande comète bleue
21728	Schéma : Grande comète verte
21729	Schéma : Grande comète rouge
21730	Schéma : Chapelet de comètes bleues
21731	Schéma : Chapelet de comètes vertes
21732	Schéma : Chapelet de comètes rouges
21733	Schéma : Chapelet de grandes comètes bleues
21734	Schéma : Chapelet de grandes comètes vertes
21735	Schéma : Chapelet de grandes comètes rouges
21736	Rênes de gryphon de monte
21737	Schéma : Lanceur de chapelets
21738	Schéma : Lanceur de fusées
21740	Recettes des petites comètes
21741	Recettes de chapelet de comètes
21742	Recettes de grandes comètes
21743	Recettes de chapelet de grandes comètes
21744	Chapelet de comètes porte-bonheur
21745	Pierre de lune des anciens
21746	Enveloppe rouge porte-bonheur
21747	Pétards de fête
21749	Briefing de combat I
21750	Briefing de combat II
21751	Briefing tactique III
21761	Clé de coffre de scarabées
21762	Clé de coffre de scarabées supérieur
21800	Lanceur silithide à carapace
21801	Antennes revigorantes
21802	Le kriss perdu de Zedd
21803	Casque du vengeur sacré
21804	Coiffe de fureur élémentaire
21805	Espauliers en obsidienne polie
21806	Marteau d'autorité qiraji
21809	Fureur de l'essaim oublié
21810	Bottes du nomade errant
21812	Boîte de chocolats
21813	Sachet de bonbons
21814	Plastron d'annihilation
21815	Gage d'amour
21816	Coeur en sucre
21817	Coeur en sucre
21818	Coeur en sucre
21819	Coeur en sucre
21820	Coeur en sucre
21821	Coeur en sucre
21822	Coeur en sucre
21823	Coeur en sucre
21829	Flacon de parfum
21830	Papier d'emballage vide
21831	Cadeau enveloppé
21833	Eau de Cologne
21836	Anneau du chaos de Rytssin
21837	Marteau de guerre d'anubisath
21838	Atours d'ascension royale
21839	Sceptre du faux prophète
21856	Neretzek, le Buveur de sang
21888	Gants de l'immortel
21889	Gants de la prophétie rachetée
21890	Gants du prophète déchu
21891	Fragment de l'étoile tombée
21920	Lettre froissée
21921	Note soigneusement calligraphiée
21925	Lettre immaculée
21926	Note légèrement froissée
21928	Echantillon de sang de Berceau-de-l'Hiver
21935	Ectoplasme stable
21936	Ectoplasme glacé
21937	Ectoplasme brûlé
21938	Coeur de magma
21939	Bâtonnet élémentaire de corruption
21946	Alambic ectoplasmique
21960	Sculpture sur bois
21975	Serment d'adoration : Stormwind
21979	Cadeau d'adoration : Darnassus
21980	Cadeau d'adoration : Ironforge
21981	Cadeau d'adoration : Stormwind
21982	Perle de guerre ogre
21983	Bannière de provocation incomplète
21984	Morceau gauche de l'amulette du seigneur Valthalak
21985	Récipient de sang scellé
21986	Bannière de provocation
21987	Incendicite d'Incendius
21988	Braise du prophète ardent
21989	Cendres de Cendres
21994	Ceinture d'héroïsme
21995	Bottes d'héroïsme
21996	Brassards d'héroïsme
21997	Cuirasse d'héroïsme
21998	Gantelets d'héroïsme
21999	Casque d'héroïsme
22000	Cuissards d'héroïsme
22001	Spallières d'héroïsme
22002	Ceinture Sombremante
22003	Bottes Sombremante
22004	Brassards Sombremante
22005	Coiffe Sombremante
22006	Gants Sombremante
22007	Pantalon Sombremante
22008	Spallières Sombremante
22009	Tunique Sombremante
22010	Ceinture de belluaire
22011	Manchettes de belluaire
22013	Coiffe de belluaire
22014	Brasero béni
22015	Gants de belluaire
22016	Mantelet de belluaire
22017	Pantalon de belluaire
22046	Morceau droit de l'amulette du seigneur Valthalak
22047	Morceau supérieur de l'amulette du seigneur Valthalak
22048	Amulette du seigneur Valthalak
22049	Brasero de signal
22050	Brasero de signal
22051	Brasero de signal
22052	Brasero de signal
22056	Brasero de signal
22057	Brasero d'invocation
22058	Papier à lettres de la St-Valentin
22059	Carte de la St-Valentin
22060	Tunique de belluaire
22061	Bottes de belluaire
22062	Ceinture du sorcier
22063	Manchettes du sorcier
22064	Bottes du sorcier
22065	Couronne du sorcier
22066	Gants du sorcier
22067	Jambières du sorcier
22068	Mantelet du sorcier
22069	Robe du sorcier
22070	Ceinture Mortebrume
22071	Brassards Mortebrume
22072	Jambières Mortebrume
22073	Mantelet Mortebrume
22074	Masque Mortebrume
22075	Robe Mortebrume
22076	Sandales Mortebrume
22077	Protège-mains Mortebrume
22078	Ceinture vertueuse
22079	Brassards vertueux
22080	Couronne vertueuse
22081	Gants vertueux
22082	Mantelet vertueux
22083	Robe vertueuse
22084	Sandales vertueuses
22085	Jupe vertueuse
22086	Ceinture d'Âmeforge
22087	Bottes d'Âmeforge
22088	Brassards d'Âmeforge
22089	Cuirasse d'Âmeforge
22090	Gantelets d'Âmeforge
22091	Casque d'Âmeforge
22092	Cuissards d'Âmeforge
22093	Spallières d'Âmeforge
22094	Varech de sang
22095	Manchettes des Cinq tonnerres
22096	Bottes des Cinq tonnerres
22097	Coiffe des Cinq tonnerres
22098	Corde des Cinq tonnerres
22099	Gantelets des cinq tonnerres
22100	Kilt des Cinq tonnerres
22101	Espauliers des Cinq tonnerres
22102	Gilet des Cinq tonnerres
22106	Ceinture Cœur-Farouche
22107	Bottes Cœur-Farouche
22108	Brassards Cœur-Farouche
22109	Capuche Cœur-Farouche
22110	Gants Cœur-Farouche
22111	Kilt Cœur-Farouche
22112	Spallières Cœur-Farouche
22113	Gilet Cœur-Farouche
22114	Oeuf de murloc rose
22115	Révélateur de fantômes extradimensionnel
22117	Serment de loyauté : Stormwind
22119	Serment de loyauté : Ironforge
22120	Serment de loyauté : Darnassus
22121	Serment de loyauté : Undercity
22122	Serment de loyauté : Thunder Bluff
22123	Serment de loyauté : Orgrimmar
22130	Symbole d'amour
22131	Assortiment de cadeaux de Stormwind
22132	Assortiment de cadeaux d'Ironforge
22133	Assortiment de cadeaux de Darnassus
22134	Assortiment de cadeaux d'Undercity
22135	Assortiment de cadeaux de Thunder Bluff
22136	Assortiment de cadeaux d'Orgrimmar
22137	Sacoche d'Ysida
22138	Brassards blackrock
22139	Médaillon d'Ysida
22140	Carte de sentinelle
22141	Carte de garde d'Ironforge
22142	Carte de grunt
22143	Carte de garde de Stormwind
22144	Carte de gardien des Hauts
22145	Carte de garde moisie
22149	Perles de mojo ogre
22150	Perles de puissance ogre
22151	Eau bénite d'Anthion
22152	Sacoche d'Anthion
22154	Serment d'adoration : Ironforge
22155	Serment d'adoration : Darnassus
22156	Serment d'adoration : Orgrimmar
22157	Serment d'adoration :  Undercity
22158	Serment d'adoration :  Thunder Bluff
22159	Serment d'amitié :  Darnassus
22160	Serment d'amitié : Ironforge
22161	Serment d'amitié : Orgrimmar
22162	Serment d'amitié : Thunder Bluff
22163	Serment d'amitié : Undercity
22164	Cadeau d'adoration : Orgrimmar
22165	Cadeau d'adoration : Thunder Bluff
22166	Cadeau d'adoration : Undercity
22167	Cadeau d'amitié : Darnassus
22168	Cadeau d'amitié : Ironforge
22169	Cadeau d'amitié : Orgrimmar
22170	Cadeau d'amitié : Stormwind
22171	Cadeau d'amitié : Thunder Bluff
22172	Cadeau d'amitié : Undercity
22173	Bière artisanale naine
22174	Poème romantique
22175	Tartelette sortie du four
22176	Pain artisanal
22177	Fleurs fraîchement cueillies
22178	Serment d'amitié : Stormwind
22191	Tunique de mailles en obsidienne
22192	Elixir d'esquive de varech de sang
22193	Elixir de résistance de varech de sang
22194	Emprise noire du Destructeur
22195	Ceinture légère en obsidienne
22196	Cuirasse épaisse en obsidienne
22197	Ceinture lourde en obsidienne
22198	Bouclier dentelé en obsidienne
22200	Flèche en argent
22201	Reliquaire de pureté
22202	Petit éclat d'obsidienne
22203	Grand éclat d'obsidienne
22204	Bracelets de renom
22205	Liens d'acier noir
22206	Bouquet de roses rouges
22207	Echarpe de la Grande chasse
22208	Marteau en pierre de lave
22209	Plans : Ceinture lourde en obsidienne
22212	Espauliers de golem ajustés
22214	Plans : Ceinture légère en obsidienne
22216	Glande à venin de Venoxis
22217	Glande à venin de Kurinnaxx
22218	Poignée de pétales de rose
22219	Plans : Bouclier dentelé en obsidienne
22220	Plans : Emprise noire du Destructeur
22221	Plans : Tunique de mailles en obsidienne
22222	Plans : Cuirasse épaisse en obsidienne
22223	Protège-tête de contremaître
22224	Essence de spectre railleur
22225	Capuche en peau de dragon
22226	Restes druidiques
22227	Relique de Brise-stellaire
22228	Epée brillante de fanatisme
22229	Cendres d'âme de banni
22230	Peau Gueule-d'horreur
22231	Bottes de précision de Kayser
22232	Ceinturon de tireur d'élite
22233	Cantine de Zigris
22234	Mantelet de l'espoir perdu
22235	Flèche en vrai-argent
22236	Délice au lait
22237	Désir noir
22238	Fondant aux myrtilles
22239	Douce surprise
22240	Grèves du désespoir cinglant
22241	Espauliers du Sombre gardien
22242	Laisse de Verek
22243	Petite bourse d'âme
22244	Boîte d'âmes
22245	Chaussures encroûtées de suie
22246	Bourse enchantée en tisse-mage
22247	Bottes de guérisseur miraculeux
22248	Sac enchanté en étoffe runique
22249	Grand sac d'enchantement
22250	Bourse d'herbes
22251	Sac d'herbes cénarien
22252	Sacoche de Cénarius
22253	Tome des Egarés
22254	Baguette de lumière éternelle
22255	Anneau forgé dans le magma
22256	Protège-mains sculpte-mana
22257	Anneau souillé de sang
22258	Philtre d'amour
22259	Bracelet d'amitié non distribué
22260	Bracelet d'amitié
22261	Tourtereau
22262	Assortiment de cadeaux de l'Alliance
22263	Assortiment de cadeaux de la Horde
22264	Lettre écrite avec soin
22265	Lettre pleine d'amour
22266	Epine de feu
22267	Turban de tisse-sort
22268	Emblème draconique imprégné
22269	Cape de rôdeur des ombres
22270	Bottes de tranchée
22271	Jambières de magie frénétique
22272	Etreinte de la forêt
22273	Chaperon d'ombrelune
22274	Fourrure grisonnante
22275	Bottes Mousse-de-feu
22276	Superbe robe rouge
22277	Habit de soirée rouge
22278	Superbe robe bleue
22279	Superbe robe noire
22280	Superbe robe violette
22281	Habit de soirée bleu
22282	Habit de soirée violet
22283	Sac de pain artisanal
22284	Monceau de cartes
22285	Assortiment de serments de Stormwind
22286	Assortiment de serments d'Ironforge
22287	Ballot de cartes
22288	Caisse de bière artisanale
22289	Pile de cartes
22290	Assortiment de serments de Darnassus
22291	Boîte de sculptures sur bois
22292	Boîte de tartelettes
22293	Paquet de cartes
22294	Assortiment de serments d'Orgrimmar
22295	Sac de cartes
22296	Panier de fleurs
22297	Assortiment de serments de Thunder Bluff
22298	Recueil de poèmes romantiques
22299	Liasse de cartes
22300	Assortiment de serments d'Undercity
22301	Robe Tisse-fer
22302	Capuche Tisse-fer
22303	Pantalon Tisse-fer
22304	Gants Tisse-fer
22305	Mantelet Tisse-fer
22306	Ceinture Tisse-fer
22307	Patron : Bourse enchantée en tisse-mage
22308	Patron : Sac enchanté en étoffe runique
22309	Patron : Grand sac d'enchantement
22310	Patron : Sac d'herbes cénarien
22311	Bottes Tisse-fer
22312	Patron : Sacoche de Cénarius
22313	Brassards Tisse-fer
22314	Harpon de veneur
22315	Marteau de revitalisation
22317	Coup de poing en laiton du Gaucher
22318	Arc long de Malgen
22319	Tome de droit divin
22320	Marchandises premier choix de Mux
22321	Coeur de Wyrmthalak
22322	Le Bourre-pif
22324	Kimchi d'hiver
22325	Ceinture de l'Entourloupeur
22326	Anneau d'amalgame
22327	Amulette du Racheté
22328	Cuissards de vigilance
22329	Sceptre de focalisation interminable
22330	Voile de la maîtrise des arcanes
22331	Anneau du héros inébranlable
22332	Lame de nécromancie
22333	Marteau de puissance divine
22334	Anneau de guérison
22335	Bâton de commandement du seigneur Valthalak
22336	Egide draconien de la légion
22337	Voile de domination
22338	Cendre volcanique
22339	Anneau runique de sorcellerie
22340	Pendentif de célérité
22342	Jambières de tourment
22343	Garde-mains de sauvagerie
22344	Mode d'emploi du brasero d'invocation
22345	Totem de renaissance
22347	Arbalète à répétition de Fahrad
22348	Mortulus prime
22349	Cuirasse désacralisée
22350	Tunique désacralisée
22351	Robe désacralisée
22352	Cuissots désacralisés
22353	Heaume désacralisé
22354	Espauliers désacralisés
22355	Brassards désacralisées
22356	Sangle désacralisée
22357	Gantelets désacralisés
22358	Solerets désacralisés
22359	Cuissards désacralisés
22360	Couvre-chef désacralisé
22361	Spallières désacralisées
22362	Protège-poignets désacralisés
22363	Ceinturon désacralisé
22364	Garde-mains désacralisés
22365	Bottes désacralisées
22366	Jambières désacralisées
22367	Diadème désacralisé
22368	Protège-épaules désacralisés
22369	Manchettes désacralisées
22370	Ceinture désacralisée
22371	Gants désacralisés
22372	Sandales désacralisées
22373	Débris d'armure en cuir
22374	Débris d'armure en mailles
22375	Débris d'armure en plaques
22376	Débris d'armure en tissu
22377	Le tisonnier de Thunderwood
22378	Trancheur de Ravenholdt
22379	Kriss de Shivsprocket
22380	Marteau de culture de Simona
22381	Echantillon de venin de Silithus
22382	Récipient de venin scellé
22383	Lame feuille-de-saule
22384	Eloquente
22385	Jambières titanesques
22386	Head of Instructor Razuvious DEP
22387	Coeur d'Anub'Rekhan
22388	Plans : Jambières titanesques
22389	Plans : Lame feuille-de-saule
22390	Plans : Eloquente
22392	Formule : Enchantd'arme 2M - Agilité
22393	Codex : Prière de protection contre l'Ombre
22394	Bâton de métanoïa
22395	Totem de rage
22396	Totem de vie
22397	Idole de férocité
22398	Idole de récupération
22399	Idole de santé
22400	Libram de vérité
22401	Libram d'espoir
22402	Libram de grâce
22403	Collier de coquillages nacrés
22404	Gratte-dos de Willey
22405	Mantelet de la Croisade écarlate
22406	Rédemption
22407	Casque de la nouvelle lune
22408	Baguette de mauvais mojo de Ritssyn
22409	Tunique du croissant de lune
22410	Gantelets d'adresse
22411	Heaume de l'Exécuteur
22412	Mantelet de Thuzadin
22416	Cuirasse de cuirassier
22417	Cuissards de cuirassier
22418	Casque de cuirassier
22419	Espauliers de cuirassier
22420	Solerets de cuirassier
22421	Gantelets de cuirassier
22422	Sangle de cuirassier
22423	Brassards de cuirassier
22424	Protège-poignets de rédemption
22425	Tunique de rédemption
22426	Garde-mains de rédemption
22427	Cuissards de rédemption
22428	Couvre-chef de rédemption
22429	Spallières de rédemption
22430	Bottes de rédemption
22431	Ceinturon de rédemption
22432	Aiguillon de diablosaure
22433	Anneau de domination de Don Mauricio
22434	Chapeau de sang
22435	Dard de Gorishi
22436	Tunique de traqueur des cryptes
22437	Cuissards de traqueur des cryptes
22438	Couvre-chef de traqueur des cryptes
22439	Spallières de traqueur des cryptes
22440	Bottes de traqueur des cryptes
22441	Garde-mains de traqueur des cryptes
22442	Ceinturon de traqueur des cryptes
22443	Protège-poignets de traqueur des cryptes
22444	Liane putride
22458	Bâton d'ombrelune
22464	Tunique de Brise-terre
22465	Kilt de Brise-terre
22466	Couvre-chef de Brise-terre
22467	Spallières de Brise-terre
22468	Bottes de Brise-terre
22469	Garde-mains de Brise-terre
22470	Ceinturon de Brise-terre
22471	Protège-poignets de Brise-terre
22472	Bottes de férocité
22476	Cuirasse de la faucheuse d'os
22477	Cuissots de la faucheuse d'os
22478	Casque de la faucheuse d'os
22479	Espauliers de la faucheuse d'os
22480	Solerets de la faucheuse d'os
22481	Gantelets de la faucheuse d'os
22482	Sangle de la faucheuse d'os
22483	Brassards de la faucheuse d'os
22484	Rune nécrotique
22488	Tunique de marcherêve
22489	Cuissards de marcherêve
22490	Couvre-chef de marcherêve
22491	Spallières de marcherêve
22492	Bottes de marcherêve
22493	Garde-mains de marcherêve
22494	Ceinturon de marcherêve
22495	Protège-poignets de marcherêve
22496	Robe de givrefeu
22497	Jambières de givrefeu
22498	Diadème de givrefeu
22499	Protège-épaules de givrefeu
22500	Sandales de givrefeu
22501	Gants de givrefeu
22502	Ceinture de givrefeu
22503	Manchettes de givrefeu
22504	Robe de pestecoeur
22505	Jambières de pestecoeur
22506	Diadème de pestecoeur
22507	Protège-épaules de pestecoeur
22508	Sandales de pestecoeur
22509	Gants de pestecoeur
22510	Ceinture de pestecoeur
22511	Manchettes de pestecoeur
22512	Robe de foi
22513	Jambières de foi
22514	Diadème de foi
22515	Protège-épaules de foi
22516	Sandales de foi
22517	Gants de foi
22518	Ceinture de foi
22519	Manchettes de foi
22520	Le phylactère of Kel'Thuzad
22523	Insigne de l'Aube
22524	Insigne de la Croisade
22525	Morceaux de démon des cryptes
22526	Fragments d'os
22527	Noyau des éléments
22528	Morceaux de sombrefer
22529	Palme sauvage
22568	Commission d'artisan scellée
22589	Atiesh, grand bâton du Gardien
22593	Sauf-conduit
22595	Annonce de l'appel aux armes
22600	Commission d'artisan - Cailloux denses
22601	Commission d'artisan - Pansières impériales
22602	Commission d'artisan - Marteaux volcaniques
22603	Commission d'artisan - Grandes haches en thorium
22604	Commission d'artisan - Diadèmes radieux
22605	Commission d'artisan - Bandeaux corrompus en cuir
22606	Commission d'artisan - Renforts d'armure robustes
22607	Commission d'artisan - Ceintures corrompues en cuir
22608	Commission d'artisan - Pantalons runiques en cuir
22609	Commission d'artisan - Pantalons en étoffe lumineuse
22610	Commission d'artisan - Bottes en étoffe runique
22611	Commission d'artisan - Sacs en étoffe runique
22612	Commission d'artisan - Robes en étoffe runique
22613	Commission d'artisan - Charges de sapeur gobelin
22614	Commission d'artisan - Grenades en thorium
22615	Commission d'artisan - Coqs de combat gnome
22616	Commission d'artisan - Tubes en thorium
22617	Commission d'artisan - Potions de mana majeures
22618	Commission d'artisan - Potions de soins majeures
22619	Commission d'artisan - Potions de protection contre le Givre supérieures
22620	Commission d'artisan - Potions de protection contre les Arcanes supérieures
22621	Commission d'artisan - Flacon de pétrification
22622	Commission d'artisan - Anguilles pierre-écaille
22623	Commission d'artisan - Poissons cuirassés
22624	Commission d'artisan - Anguilles électriques
22625	Commission d'artisan - Pains de saumon
22626	Commission d'artisan - Courante-surprise
22630	Atiesh, grand bâton du Gardien
22631	Atiesh, grand bâton du Gardien
22632	Atiesh, grand bâton du Gardien
22635	Garde sauvage
22636	Garde-glace
22637	Idole primordiale hakkari
22638	Ombregarde
22648	Dossier sur la Ruche'Ashi
22649	Dossier sur la Ruche'Regal
22650	Dossier sur la Ruche'Zora
22651	Jambières de voltigeur en plaques
22652	Gilet glaciaire
22654	Gants glaciaires
22655	Poignets glaciaires
22656	Le Purificateur
22657	Amulette de l'Aube
22658	Cape glaciaire
22659	Médaillon de l'Aube
22660	Etreinte de Gaïa
22661	Tunique polaire
22662	Gants polaires
22663	Brassards polaires
22664	Cuirasse glacécaille
22665	Brassards glacécaille
22666	Gantelets glacécaille
22667	Brassards d'espoir
22668	Brassards de subterfuge
22669	Cuirasse plaie-de-glace
22670	Gantelets plaie-de-glace
22671	Brassards plaie-de-glace
22672	Cuissards de sentinelle en plaques
22673	Jambières de voltigeur en anneaux
22676	Jambières de voltigeur en mailles
22678	Talisman d'ascendance
22679	Sac de fournitures
22680	Bague de résolution
22681	Bague de piété
22682	Rune de givre
22683	Patron : Etreinte de Gaïa
22684	Patron : Gants glaciaires
22685	Patron : Cape glaciaire
22686	Patron : Gilet glaciaire
22687	Patron : Poignets glaciaires
22688	Dernière chance de Verimonde
22689	Casque sanctifié en cuir
22690	Jambières du chassepeste
22691	Porte-cendres corrompue
22692	Patron : Tunique polaire
22694	Patron : Gants polaires
22695	Patron : Brassards polaires
22696	Patron : Cuirasse glacécaille
22697	Patron : Gantelets glacécaille
22698	Patron : Brassards glacécaille
22699	Jambières plaie-de-glace
22700	Jambières glaciaires
22701	Jambières polaires
22702	Jambières glacécaille
22703	Plans : Cuirasse plaie-de-glace
22704	Plans : Gantelets plaie-de-glace
22705	Plans : Brassards plaie-de-glace
22707	Etreinte de glace de Ramaladni
22708	Destin de Ramaladni
22711	Cape des adorateurs hakkari
22712	Puissance de la tribu
22713	Sceptre des rites zuliens
22714	Gantelets sacrificiels
22715	Gants du tourmenté
22716	Ceinture du pouvoir vierge
22718	Masque inondé de sang
22719	Recueil d'Omarion
22720	Coiffure zulienne
22721	Bague de servitude
22722	Sceau du berserker gurubashi
22723	Lettre du gardien des registres
22725	Bague de Cenarius
22726	Fragment d'Atiesh
22727	Hampe d'Atiesh
22728	Commande de chariotte à vapeur
22729	Schéma : Commande de chariotte à vapeur
22730	Corde de pédoncule cintrée
22731	Cape du Dévoré
22732	Marque de C'Thun
22733	Tête d'Atiesh
22734	Talon d'Atiesh
22736	Andonisus, la Faucheuse d'âmes
22737	Atiesh, grand bâton du Gardien
22739	Tome de métamorphose : Tortue
22740	Pantalon de voltigeur en cuir
22741	Pantalon de voltigeur en peau de lézard
22742	Chemise de la Voile sanglante
22743	Echarpe de la Voile sanglante
22744	Bottes de la Voile sanglante
22745	Pantalon de la Voile sanglante
22746	Uniforme de boucanier
22747	Jambière de voltigeur en soie
22748	Jambières de sentinelle en anneaux
22749	Pantalon de sentinelle en cuir
22750	Pantalon de sentinelle en peau de lézard
22752	Jambières de sentinelle en soie
22753	Cuissards de sentinelle lamellaires
22754	Quintessence éternelle
22756	Gilet sylvestre
22757	Couronne sylvestre
22758	Epaulières sylvestres
22759	Casque de la ronceraie
22760	Bottes de la ronceraie
22761	Ceinture de la ronceraie
22762	Cuirasse de vignefer
22763	Gants de vignefer
22764	Ceinture de vignefer
22765	Missive moisie
22766	Plans : Cuirasse de vignefer
22767	Plans : Gants de vignefer
22768	Plans : Ceinture de vignefer
22769	Patron : Ceinture de la ronceraie
22770	Patron : Bottes de la ronceraie
22771	Patron : Casque de la ronceraie
22772	Patron : Epaulières sylvestres
22773	Patron : Couronne sylvestre
22774	Patron : Gilet sylvestre
22780	Œuf de murloc blanc
22781	Collier d'ours polaire
22798	Puissance de Menethil
22799	Cherche-âme
22800	Bâton de soufre
22801	Pic du crépuscule
22802	Détrôneuse
22803	Rosée du crépuscule
22804	Croc de Maexxna
22806	Remords de la veuve
22807	Lame en peine
22808	Fustigatrice
22809	Maillet du croisé racheté
22810	Injecteur de toxines
22811	Cordâme
22812	Esclavagiste nérubien
22813	Claymore de puissance impie
22815	Cisailleuse
22816	Hachette de l'os brisé
22818	Le Porte-peste
22819	Bouclier de condamnation
22820	Baguette des Parques
22821	Doigt du destin
22822	iCoke Prize Voucher
22843	Grèves de garde de sang en anneaux
22852	Bottines de garde de sang en peau de dragon
22855	Brodequins de garde de sang en tisse-effroi
22856	Brodequins de garde de sang en cuir
22857	Grèves de garde de sang en mailles
22858	Grèves de garde de sang en plaques
22859	Brodequins de garde de sang en satin
22860	Brodequins de garde de sang en soie
22862	Cestes de garde de sang en anneaux
22863	Poignes de garde de sang en peau de dragon
22864	Poignes de garde de sang en cuir
22865	Protège-mains de garde de sang en tisse-effroi
22867	Cestes de garde de sang en mailles
22868	Gantelets de garde de sang en plaques
22869	Protège-mains de garde de sang en satin
22870	Protège-mains de garde de sang en soie
22872	Armure de légionnaire en plaques
22873	Jambières de légionnaire en plaques
22874	Haubert de légionnaire en anneaux
22875	Cuissards de légionnaire en anneaux
22876	Haubert de légionnaire en mailles
22877	Plastron de légionnaire en peau de dragon
22878	Jambières de légionnaire en peau de dragon
22879	Plastron de légionnaire en cuir
22880	Cuissards de légionnaire en cuir
22881	Cuissards de légionnaire en tisse-effroi
22882	Cuissards de légionnaire en satin
22883	Cuissards de légionnaire en soie
22884	Tunique de légionnaire en tisse-effroi
22885	Tunique de légionnaire en satin
22886	Tunique de légionnaire en soie
22887	Cuissards de légionnaire en mailles
22890	Tome de Gardien de givre V
22891	Grimoire de Gardien de l'ombre IV
22892	Pierre nécrotique pâle
22895	Roulés à la cannelle invoqués
22897	Tome d'Invocation de nourriture VII
22930	Une enveloppe tachée de sang
22932	Une lettre déchirée
22935	Larme de givre
22936	Garde-poignets de vengeance
22937	Gemme de Nérubis
22938	Cape en soie de démon des cryptes
22939	Bague des prières inexaucées
22940	Espauliers plaie-de-glace
22941	Protège-épaules polaires
22942	L'Etreinte de la veuve
22943	Pendentif de la pierre pernicieuse
22944	Une missive froissée
22945	Une note détériorée
22946	Une page abîmée
22947	Pendentif des noms oubliés
22948	Un document taché
22949	Cristal nécrotique fêlé
22950	Cristal nécrotique voilé
22954	Baiser de l'araignée
22960	Cape de suture
22961	Bague de réanimation
22967	Spallières glacécaille
22968	Mantelet glacial
22970	Une enveloppe tachée de sang
22972	Une note détériorée
22973	Une missive froissée
22974	Une page abîmée
22975	Un document taché
22977	Une lettre déchirée
22981	Collier perdu de Gluth
22983	Mantelet couvert de gel
22988	La fin des rêves
22994	Main de pouvoir digérée
22999	Tabard de l'Aube d'argent
23000	Thorax d'abomination blindé
23001	Oeil de diminution
23002	Boîte à tortue
23004	Idole de longévité
23005	Totem de l'eau courante
23006	Libram de lumière
23007	Collier de porcelet
23008	Rapport de recherches scellé
23009	Baguette de la mort murmurante
23010	Rapport de recherches scellé
23011	Rapport de recherches scellé
23012	Rapport de recherches scellé
23013	Rapport de recherches scellé
23014	Iblis, lame du Séraphin déchu
23015	Cage à rat
23016	Rapport de recherches scellé
23017	Voile de l'éclipse
23018	Chevalière du défenseur déchu
23019	Heaume plaie-de-glace
23020	Casque polaire
23021	Manchettes du moissonneur d'âmes
23022	Récompense du bougon
23023	Torque de sadique
23024	Ordre de mission préparé
23025	Sceau des damnés
23027	Cordialité du pardon
23028	Bague du grêlon
23029	Coeur frigide de Noth
23030	Cape du Fléau
23031	Bague de l'inévitable
23032	Coiffure glaciale
23033	Camail glacécaille
23034	Nax PH Crit Plate Shoulders
23035	Chapeau de précepteur
23036	Collier de nécropsie
23037	Anneau de ferveur spirituelle
23038	Bague des forces contre-nature
23039	L'oeil de Nérub
23040	Glyphe de déviation
23041	Blason de tueur
23042	Reflet d'Horreb
23043	Le Visage de la mort
23044	Présage funeste
23045	Voile d'assujettissement
23046	L'essence contenue de Saphiron
23047	Oeil du mort
23048	Oeil droit de Saphiron
23049	Oeil gauche de Saphiron
23050	Cape de la nécropole
23053	Talisman bouillonnant de Stormrage
23054	Gressil, Aube de la ruine
23055	Mot de dégel
23056	Marteau du Néant distordu
23057	Gemme des innocents enchaînés
23058	Collier de canalisation de vie
23059	Anneau du cuirassier
23060	Anneau de la faucheuse d'os
23061	Anneau de foi
23062	Anneau de givrefeu
23063	Anneau de pestecoeur
23064	Anneau de marcherêve
23065	Anneau de Brise-terre
23066	Anneau de rédemption
23067	Anneau de traqueur des cryptes
23068	Cuissots de carnage
23069	Atours de nécrochevalier
23070	Jambières de polarité
23071	Jambières de l'Apocalypse
23072	Poings de l'Implacable
23073	Bottes de déplacement
23075	Pacte de la mort
23078	Gantelets de tueur de mort-vivant
23081	Protège-mains de tueur de mort-vivant
23082	Garde-mains de tueur de mort-vivant
23083	Flamme captive
23084	Gants de purification des morts-vivants
23085	Robe de purification des morts-vivants
23087	Cuirasse de tueur de mort-vivant
23088	Corselet de tueur de mort-vivant
23089	Tunique de tueur de mort-vivant
23090	Brassards de tueur de mort-vivant
23091	Brassards de purification des morts-vivants
23092	Garde-poignets de tueur de mort-vivant
23093	Bandelettes de tueur de mort-vivant
23122	Pierre à aiguiser consacrée
23123	Huile de sorcier bénite
23124	Bâton de Balzaphon
23125	Chaînes de la liche
23126	Baudrier de Balzaphon
23127	Cape de Revanchion
23128	L'Etreinte de l'ombre
23129	Brassards de guérison
23132	Lame du seigneur Noirbois
23139	Targe du seigneur Noirbois
23156	Fémur de Noirbois
23160	Pain de l'amitié
23161	Citronnade fraîchement pressée
23162	Très grand sac
23163	Performer's Wand
23164	Bubbly Beverage
23168	Dague focale de Scorn
23169	Sautoir glacé de Scorn
23170	L'Etreinte glaciale
23171	Tranchelard
23172	Refreshing Red Apple
23173	Jambières en peau d'abomination
23175	Tasty Summer Treat
23176	Fizzy Energy Drink
23177	Doigt de dame Falther'ess
23178	Mantelet de dame Falther'ess
23179	Flamme d'Orgrimmar
23180	Flamme de Thunder Bluff
23181	Flamme d'Undercity
23182	Flamme de Stormwind
23183	Flamme d'Ironforge
23184	Flamme de Darnassus
23192	Tabard de la Croisade écarlate
23193	Rênes de palefroi squelettique
23194	Marque de l'Aube inférieure
23195	Marque de l'Aube
23196	Marque de l'Aube supérieure
23197	Idole de la lune
23198	Idole de brutalité
23199	Totem de l'orage
23200	Totem de soutien
23201	Libram de divinité
23203	Libram de ferveur
23206	Marque du champion
23207	Marque du champion
23211	S'morc grillé
23215	Sac d'ingrédients de s'morc
23219	Ceinturon du mentor
23220	Robe de toile cristalline
23221	Servobras égaré
23224	Summer Gift Package
23226	Tunique en peau de goule
23227	iCoke Gift Box Voucher
23237	Anneau de la flamme éternelle
23238	Targe stygienne
23242	Griffe du wyrm de givre
23243	Epaulières de champion en plaques
23244	Casque de champion en plaques
23246	Bière de fête flamboyante
23247	Fleur ardente
23250	Coquille prismatique
23251	Casque de champion en anneaux
23252	Epaulières de champion en anneaux
23253	Protège-front de champion en peau de dragon
23254	Epaulières de champion en peau de dragon
23255	Capuche de champion en tisse-effroi
23256	Spallières de champion en tisse-effroi
23257	Casque de champion en cuir
23258	Epaulières de champion en cuir
23259	Protège-front de champion en mailles
23260	Espauliers de champion en mailles
23261	Chaperon de champion en satin
23262	Mantelet de champion en satin
23263	Capuche de champion en soie
23264	Mantelet de champion en soie
23272	Cuirasse lamellaire de chevalier-capitaine
23273	Jambières lamellaires de chevalier-capitaine
23274	Gantelets lamellaires de chevalier-capitaine
23275	Solerets lamellaires de chevalier-capitaine
23276	Protège-front lamellaire de lieutenant-commandant
23277	Epaulières lamellaires de lieutenant-commandant
23278	Grèves de chevalier-lieutenant en anneaux
23279	Cestes de chevalier-lieutenant en anneaux
23280	Poignes de chevalier-lieutenant en peau de dragon
23281	Bottines de chevalier-lieutenant en peau de dragon
23282	Protège-mains de chevalier-lieutenant en tisse-effroi
23283	Brodequins de chevalier-lieutenant en tisse-effroi
23284	Poignes de chevalier-lieutenant en cuir
23285	Brodequins de chevalier-lieutenant en cuir
23286	Gantelets de chevalier-lieutenant en plaques
23287	Grèves de chevalier-lieutenant en plaques
23288	Protège-mains de chevalier-lieutenant en satin
23289	Brodequins de chevalier-lieutenant en satin
23290	Protège-mains de chevalier-lieutenant en soie
23291	Brodequins de chevalier-lieutenant en soie
23292	Haubert de chevalier-capitaine en anneaux
23293	Cuissards de chevalier-capitaine en anneaux
23294	Plastron de chevalier-capitaine en peau de dragon
23295	Jambières de chevalier-capitaine en peau de dragon
23296	Cuissards de chevalier-capitaine en tisse-effroi
23297	Tunique de chevalier-capitaine en tisse-effroi
23298	Plastron de chevalier-capitaine en cuir
23299	Cuissards de chevalier-capitaine en cuir
23300	Haubert de chevalier-capitaine en plaques
23301	Jambières de chevalier-capitaine en plaques
23302	Cuissards de chevalier-capitaine en satin
23303	Tunique de chevalier-capitaine en satin
23304	Cuissards de chevalier-capitaine en soie
23305	Tunique de chevalier-capitaine en soie
23306	Casque de lieutenant-commandant en anneaux
23307	Epaulières de lieutenant-commandant en anneaux
23308	Protège-front de lieutenant-commandant en peau de dragon
23309	Epaulières de lieutenant-commandant en peau de dragon
23310	Capuche de lieutenant-commandant en tisse-effroi
23311	Spallières de lieutenant-commandant en tisse-effroi
23312	Casque de lieutenant-commandant en cuir
23313	Epaulières de lieutenant-commandant en cuir
23314	Heaume de lieutenant-commandant en plaques
23315	Epaulières de lieutenant-commandant en plaques
23316	Chaperon de lieutenant-commandant en satin
23317	Mantelet de lieutenant-commandant en satin
23318	Capuche de lieutenant-commandant en soie
23319	Mantelet de lieutenant-commandant en soie
23320	Tablette d'Horion de flammes VI
23323	Couronne de la fête du Feu
23324	Mantelet de la fête du Feu
23326	Saucisse du solstice d'été
23327	Petit pain grillé
23360	Tête de l'instructeur Razuvious
23379	Brassards cendrés
23435	Tarte au sureau
23451	Magelame de connétable
23452	Tome de puissance de connétable
23453	Tome de restauration de connétable
23454	Marteau de guerre de connétable
23455	Démolisseur de connétable
23456	Vivelame de connétable
23464	Masse d'armes de grand seigneur de guerre
23465	Destructeur de grand seigneur de guerre
23466	Sorcelame de grand seigneur de guerre
23467	Prestelame de seigneur de guerre
23468	Tome de destruction de grand seigneur de guerre
23469	Tome de guérison de grand seigneur
23545	Puissance du Fléau
23547	Résistance du Fléau
23548	Pouvoir du Fléau
23549	Robustesse du Fléau
23557	Larve du Grand ver
23558	La Carapace du fouisseur
23570	Jom Gabbar
23577	Le Froid dévorant
23578	McWeaksauce allégée
23579	McWeaksauce classique
23656	Objet de test promotion
23663	Ceinturon de furie élémentaire
23664	Espauliers de furie élémentaire
23665	Jambières de furie élémentaire
23666	Ceinture du Grand croisé
23667	Spallières du Grand croisé
23668	Jambières du Grand croisé
23683	Pastille de pétale de cristal pour la gorge
23684	Bandage imprégné de cristaux
23689	Manuel : Bandage imprégné de cristaux
23690	Recette : Pastille de pétale cristal pour la gorge
23705	Tabard de flammes
23709	Tabard de givre
23710	Tabard d'Upperdeck n°3
23712	Bébé tigre blanc
23713	Jeune hippogrpyhe
23714	Feu d'artifice violet perpétuel
23715	Cocktail de jus de poumon permanent
23716	Idole d'ogre sculptée
23718	Poudre de scorpok terrestre permanente
23719	Potion de cortex cérébral permanente
23720	Tortue de monte
23721	Gomme de gésier permanente
23722	R.O.I.D.S. permanent
23794	Brillance de Zanza permanente
23795	Esprit de Zanza permanent
23796	Rapidité de Zanza permanente
24071	Dague quelconque
24101	Livre de Morsure féroce V
24102	Manuel d'Eviscération IX
24222	Le Surin d'Ombrepas
24231	Tabac à priser grossier
24232	Noeud miteux
24281	Os sculpté en ivoire
24282	Journal d'un voleur
24283	Un fusil antique
122270	Jeton WoW
122284	Jeton WoW
172070	Paquetage du service client
180089	Collier de panda
184937	Déplaceur de chronochance
184938	Déplaceur de chronochance surchargé
189419	Fire Resist Plate Gear
189420	Fire Resist Plate Gear
189421	Fire Resist Leather Gear
189426	Raid Consumables
189427	More Raid Consumables
190179	Cœur d’Avelina
190180	Cœur d’Isaac
190181	Cœurs des amoureux
190186	Figurine en bois
190187	Écharpe flétrie
190232	Écharpe flétrie
190307	Torche éteinte
190308	Torche ardente
190309	Figurine en bois
190325	Monstre – fouet d’incube masse à une main
191204	Pierre de mort inférieure
191249	Pierre de mort supérieure
191267	Rune de téléportation : antichambre
191268	Orbe de corruption
191272	Bâtonnet de nécromancie
191280	Amas de spores fongiques
191288	Rune de téléportation : antre du Wyrm de givre
191292	Dague rituelle
191312	Phylactère de secours
191313	Masque funéraire
191414	Relique squelette
191458	Phylactère brisé
191459	Rune de bonne fortune
191477	Barre d’attache squelettique
191480	Palefroi squelettique
191481	Tabard de Maîtrise
191550	Livre des pierres de mort : masque funéraire
191605	Livre des pierres de mort : rune de téléportation I
191606	Livre des pierres de mort : orbe de corruption
191607	Livre des pierres de mort : relique squelette
191608	Livre des pierres de mort : bâtonnet de nécromancie
191609	Livre des pierres de mort : amas de spores fongiques
191610	Livre des pierres de mort : dague rituelle
191611	Livre des pierres de mort : phylactère de secours
191612	Livre des pierres de mort : rune de téléportation II
191613	Livre des pierres de mort : rune de bonne fortune
191614	Livre des pierres de mort : barre d’attache squelettique
191656	Essence de la mort
191660	Éclairs de Thaddius
191661	Croc d’araignée monstrueux
191664	Livre des pierres de mort : éclairs de Thaddius
191666	Livre des pierres de mort : croc d’araignée monstrueux
202251	Sac de friandises pour animaux
202254	Brassards de redirection
202256	Pistolet orné de corsaire
202641	Cahier recouvert de boue
203723	Note de Cutty
203726	Rune de Cutty
203745	Notes de sort : Javelot de glace
203746	Notes de sort : Flamme vivante
203747	Notes de sort : Doigts de givre
203748	Notes de sort : Incandescence
203749	Notes de sort : Illumination
203750	Carte au trésor d’Elwyn
203751	Notes de sort : ALEEV DJEG LTACO
203752	Notes de sort : VALAFM EVNTMIE
203753	Notes de sort : GDDOT EG IEVSIR
203754	Archimage Antonidas : L’autobiographie intégrale
203755	Journal de recherche de l’archimage Théocritus
203756	Page 1 des notes d’apprenti Azora
203784	Morceau supérieur droit de carte
203785	Morceau supérieur gauche de carte
203786	Morceau inférieur droit de carte
203787	Morceau inférieur gauche de carte
203960	Page 2 des notes d’apprenti Azora
203961	Page 3 des notes d’apprenti Azora
203962	Page 4 des notes d’apprenti Azora
203990	Idole de mutilation
203991	Rune de Tireur rapide
203992	Rune de supercherie
203993	Rune de Massacre
203994	Rune de Breuvage mortel
204174	Rune de précision
204270	Noyau de la Brasse
204441	Rune de Frénésie sanglante
204476	Tête de Kobold coupée
204477	Tête de Murloc coupée
204478	Tête de Gnoll coupée
204688	Premier fragment de rune de chasseurs de monstres
204689	Deuxième fragment de rune de chasseurs de monstres
204690	Troisième fragment de rune de chasseurs de monstres
204703	Rune de Dévastation
204716	Rune d’assaut frénétique
204795	Rune de Frappe des ténèbres
204804	Bracelets des Hydraxiens
204806	Rune d’Ivresse de la victoire
204807	Lame des profondeurs
204809	Rune de tonnerre furieux
204864	Notes d’apprenti Azora
204905	Tome inquiétant
204906	Sang de gnoll
204907	Mâchoire de loup
204910	Monstre – Trident, Naga (Or)
204912	Rune de Grâce
205019	Fragment d’âme impure
205020	Fragment d’âme pure
205022	Rune de Siphon d’âme
205181	Artéfact non identifié
205182	Artéfact déchargé
205183	Artéfact alimenté par la corruption
205184	Note d’acolyte
205215	Rune de Tactiques
205218	Libram de découverte
205228	Rune de Trait du chaos
205230	Rune cauchemardesque
205364	Fourre-tout d’acolyte
205420	Libram de jugement
205683	Rune de Réprimandes
205685	Rune d’Égide
205863	Libram corrompu
205864	Note calcinée
205897	Rune de Lumière divine
205905	Souvenir d’un champion dévoué
205932	Prophétie de la chute d’un roi
205940	Souvenir d’un noir dessein
205942	Épiphanie chimérique
205943	Prophétie d’une citadelle profanée
205944	Épiphanie réciproque
205945	Souvenir d’un sauveur en captivité
205946	Souvenir de la trahison d’un dirigeant
205947	Prophétie d’une citadelle profanée
205948	Épiphanie anodine
205949	Épiphanie multiple
205950	Épiphanie ténébreuse
205951	Souvenir d’un acolyte tourmenté
205952	Souvenir d’un monde brisé
205953	Prophétie d’un vœu brisé
205961	Viande d’oiseau de Mulgore
205979	Rune de Contournement
205995	Musc de chien de prairie
206032	Rune de Découpe
206155	Rune de visée
206157	Charge d’hydroglycérine excavatrice
206159	Déguisement de la KapitalRisk
206168	Rune de la chimère
206169	Rune de Tir explosif
206170	Cône de Furie-des-vents
206175	Onguent de pin
206176	Mortier et pilon
206177	Beurre de pignons de pin
206264	Rune d’Inspiration
206344	Ensemble de couteaux
206345	Morceaux de poissons
206376	Icône de barricade
206381	Icône dyadique
206382	Icône de tempête
206383	Icône lithique
206384	Icône astrale
206385	Icône clastique
206386	Icône galvanique
206387	Icône kajarique
206388	Icône sulfureuse
206389	Icône de soufre
206390	Icône ichthyane
206391	Icône syzygique
206466	Couronne de prairie
206469	Fleur de prairie
206954	Idole de la rage ursine
206963	Rune de potentiel naturel
206966	Bulbe de satyrienne
206970	Rune de vie
206975	Clé de l’entrepôt d’artéfact
206985	Écho de l’alpha
206989	Rune du soleil
206992	Rune de Coup de crâne
206994	Tête de huran coupée
206995	Tête de harpie coupée
207062	Tête de centaure coupée
207098	Note de Ba’so
207106	Morceau inférieur gauche de carte
207107	Morceau inférieur droit de carte
207108	Morceau supérieur gauche de carte
207109	Morceau supérieur droit de carte
207110	Carte au trésor de Durotar
207590	Viande de cochon de Durotar
207631	Phéromone d’aspic
207731	Tome inquiétant
207732	Patte de makrura
207733	Crâne de Kul Tiras
207972	Les leçons de Ta’zo
207973	Mâchoire de molosse
207974	Tome inquiétant
207975	Tête de chauve-souris coupée
208005	Clé du coffret à reliques Agamand
208007	Clé de cache de l’épave
208034	Carte au trésor de Tirisfal
208035	Morceau supérieur droit de carte
208036	Morceau supérieur gauche de carte
208037	Morceau inférieur droit de carte
208038	Morceau inférieur gauche de carte
208085	Chevalière de lieutenant écarlate
208086	Note de service écarlate urgente falsifiée
208139	Tome inquiétant
208140	Sang de wendigo
208158	Cœur de trogg en parfait état
208159	Tête de troll coupée
208160	Patte sectionnée de wendigo
208180	Musc de lapin
208183	Notes de l’apothicaire
208185	L’abécédaire métaphysique de l’apothicaire
208192	Viande de cochon de Dun Morogh
208196	Anneau Moa’kin
208205	Note de Ratnoir
208213	Morceau supérieur droit de carte
208215	Morceau supérieur gauche de carte
208218	Morceau inférieur droit de carte
208219	Morceau inférieur gauche de carte
208220	Carte au trésor de Dun Morogh
208222	Revancharde de vieux garde
208223	Fourre-tout d’acolyte
208224	Note d’acolyte
208414	Idole lunaire
208425	Vestige archaïque brillant
208484	Lumière du soleil
208601	Morceau supérieur droit de carte
208602	Morceau supérieur gauche de carte
208603	Morceau inférieur droit de carte
208604	Morceau inférieur gauche de carte
208605	Carte au trésor de Teldrassil
208607	Musc de daim
208608	Viande d’oiseau de Teldrassil
208609	Fleur de la clairière
208610	Tête de chouette coupée
208611	Tête de tigre coupée
208612	Tête d’araignée coupée
208682	Œuf abandonné de gueule d’acier
208687	Rune de Lacérer
208689	Idole féroce
208701	Rune de Maîtrise des bêtes
208739	Bannière de guerre de la Horde
208741	Rune de Rage infinie
208743	Âme de cupidité
208744	Rune des Traits d’ombre
208749	Clé de cache pin-tordu
208750	Rune de Canalisation
208753	Notes de sort : Régénération
208754	Notes de sort : NIGÉO NÉRÉRAT
208758	Rune de terre
208760	Couronne de la clairière
208764	Rune de l’esprit
208765	Main secourable
208766	Main secourable
208767	Rune de guérison
208768	Boîte d’allumettes de boucanier
208771	Rune de Danse des lames
208772	Rune de Coup de sabre
208773	Harpon de pêche
208777	Rune de tir de précision
208778	Rune de Frappe rapide
208799	Notes de sort : Bombe vivante
208800	Baxtan : Sur les magies destructrices
208823	Pièce à offrandes
208828	Souvenir d’un vœu brisé
208833	Tarte malveillante
208838	Coffret Sombrefer
208843	Totem de bataille
208847	Géode en forme de crâne
208848	Géode en forme de crâne fêlé
208849	Libram des bénédictions
208851	Libram de justice
208853	Notes de sort : Gel mental
208854	Notes de sort mâchonnées
208855	Appât de thon arc-en-ciel
208860	Rumi de Gnomeregan : Le recueil d’œuvres
209027	Bonbons pour crabes
209028	Notes de sort : ABOTM BEIVEVN
209029	Message d’Émilie
209030	Clé de la réserve d’équipement
209031	Enveloppe discrète
209041	Graines de citrouille magique
209042	Farine d’os de poisson
209043	Échantillon de terre fertile
209045	Âme de la mer
209047	Harpon noueux
209056	Pièces détachées de moissonneur
209057	Prototype de moteur
209058	Noyau élémentaire
209059	Cuissot de broche-tripes
209418	Armure adamantine de la tortue
209420	Plaie des branchies
209421	Corde d’Aquanis
209422	Sautoir de marée haute
209423	Écharpe flottante
209424	Coquille barrière en plaque
209432	Cordelière de Ghamoo-ra
209436	Morsure ébréchée de Serra’kis
209523	Cape chatoyante du batteur
209524	Bandages de Serra’kis
209525	Tulwar affûté des eaux sombres
209526	Tulwar des eaux sombres EXPÉRIMENTAL
209527	Gantelets de bataille nagas
209534	Arbaleste azshari
209559	Canne de marche du sage du Crépuscule
209560	Marteau du jugement pieux
209561	Perche du somnambule ancien
209562	Frappe létale de l’hydre
209563	Déchire-cœur naga
209564	Trident de gardien
209565	Anneau des profondeurs
209566	Jambières du fidèle
209567	Hache des récifs coralliens
209568	Gantelets d’algues
209569	Bottes hautes en peau de Murloc
209570	Tome de la connaissance des cavernes
209571	Lumière morte
209572	Armure en cuir noir bouilli
209573	Flèche courroucée
209574	Doctrines abandonnées de la Main d’argent
209575	Icône en bois flotté taillé
209576	Champignon d’ouverture d’esprit
209577	Poing du fauve
209578	Poignets luminescents en cuir
209579	Tonnerre fracassant
209580	Coups de vent
209581	Solerets de la Main d’argent
209590	Globe d’eau fêlé
209608	Passe-partout du capitaine
209611	Insigne de l’Alliance
209612	Insigne de l’Alliance
209613	Insigne de l’Alliance
209614	Insigne de l’Alliance
209615	Insigne de l’Alliance
209616	Insigne de l’Alliance
209617	Insigne de l’Alliance
209618	Insigne de l’Alliance
209619	Insigne de la Horde
209620	Insigne de la Horde
209621	Insigne de la Horde
209622	Insigne de la Horde
209623	Insigne de la Horde
209624	Insigne de la Horde
209625	Insigne de la Horde
209626	Insigne de la Horde
209667	Jambières du rêveur
209668	Chevalière du seigneur du Crépuscule
209669	Chaussures d’invocatrice du Crépuscule
209670	Brodequins en peau
209671	Robe d’invocatrice du Crépuscule
209672	Mitaines blindées noires
209673	Amulette fétiche luminescente
209674	Embrasement du phénix
209675	Tunique en poils de palourde
209676	Garde-épaules des profondeurs écrasantes
209677	Boucle des courants rapides
209678	Mantelet du pourfendeur de batteur
209679	Protège-épaules de novice azshari
209680	Écharpe imperméable
209681	Œuf de Murloc noir
209682	Chaperon solide
209683	Châle d’invocatrice du Crépuscule
209684	Pantalon de sangsue d’âme
209685	Cordelière de mousse ancienne
209686	Collier d’os dentelé
209687	Cuirasse en peau d’hydre
209688	Tromblon de Bael Modan
209689	Godillots en carapace de crabe
209690	Coiffe en noirécaille
209691	Couteau de jet vampirique
209692	Espauliers de sentinelle
209693	Perle de Brassenoire parfaite
209694	Dague rituelle de Brassenoire
209748	Orbe d’Althalaxx
209778	Sel d’invocateur
209779	Granule de Mannoroth
209800	Fragments d’orbe
209816	Fétiche de Malice
209817	Broche de marcheur du Vide
209818	Croissant touché par le soleil
209819	Baguette d’apprivoisement de wyverne
209820	Sautoir du linceul noir
209821	Anneau d’Ombrevue
209822	Force de conviction
209823	Chevalière de Fauves
209824	Protège-épaules chatoyant
209825	Sautoir de la gouttelette
209828	Espauliers de température négative
209830	Arbaleste en cuiracier
209836	Orbe d’Althalaxx
209838	Cristal hypnotique
209840	Baguette noueuse de magie sauvage
209841	Essence de magie sauvage
209843	Almanach de Nar’thalas vol. 74
209844	Abrégé de Dalaran vol. 23
209845	Envoûtements et glamours
209846	Secrets des Rêveurs
209847	Manuel des systèmes arcaniques
209848	Parchemins de Goaz
209849	Crimes contre l’anatomie
209850	Runes des rois-sorciers
209851	Fureur de la terre
209852	Rune d’Ordre de tuer
209872	Casque du tueur de dragon
209873	Bouclier du tueur de dragon
209874	Lance du tueur de dragon
210015	Rune de Coup déchaîné
210026	Symbole de la troisième chouette
210043	Symbole de la deuxième chouette
210044	Symbole de la première chouette
210045	Sombrefeuille
210053	Patte de loup redoutable
210055	Ossements d’Humain d’Hillsbrad
210056	Teinture de réveil de la mort
210080	Offrande vaudou
210137	Rune de croissance sauvage
210138	Munition de Sombrefer
210146	Turbochargeur de déchiqueteur
210147	Unité d’autorecyclage de déchiqueteur
210177	Ataeric : À propos des curiosités des arcanes
210178	Schéma : unité d’autorecyclage de déchiqueteur
210179	Notes de sort : ILMEGAI SARRBES
210183	Corne de Xelthos
210186	Charge perforante
210187	Commande de la KapitalRisk
210188	Commande déchiquetée
210195	Idole déséquilibrée
210209	Clé jumelle
210210	Certificat du fondateur des Industries de défense Grisœuvre
210212	Demi-clé du frère
210213	Demi-clé de la sœur
210229	Idole de mutilation
210250	Anneau d’or ciselé
210251	Anneau d’argent ciselé
210252	Runes du surin
210253	Totem putride
210322	Rune de venin
210323	Combinaison du coffre
210329	Carte au trésor d’Hillsbrad
210330	Bon tuyau
210410	Appât à mordeuse d’eau douce
210499	Champifond
210500	Rune des étoiles
210534	Idole du fauve
210568	Phylactère décrépit
210569	Rune de Flagellation
210573	Rune de Rage dévorante
210589	Écho des ancêtres
210596	Rune de Frappes de cobra
210653	Rune de Main gauche
210654	Notes de sort : Remonter le temps
210655	Notes de sort : MPERORENT LS ETME
210665	Particule de rage torrentielle
210667	Particule de rage infernale
210668	Particule de rage sismique
210696	Plaie de la pourriture
210708	Élixir des regrets accumulés
210709	Recette : élixir des regrets accumulés
210712	Élixir de clairvoyance
210713	Âme torturée
210724	Bâton de Hirzek
210741	Roueur automatique
210746	Rune de Bouclier de terre
210763	Branche d’Altek
210765	Orbe de Des
210771	Fournitures égarées : barres de cuivre
210772	Cargaison d’approvisionnement : barres de cuivre
210773	Mantelet de la Deuxième guerre
210779	Plans : mantelet de la Deuxième guerre
210781	Bandages du phénix
210794	Cuirasse changeante en argent
210795	Bottes en soie d’araignée extraplanaires
210811	Rune de Fureur primordiale
210817	Rune de survie
210818	Rune du Loup solitaire
210820	Rune de Sacrifice
210822	Épiphanie harmonieuse
210823	Rune de Spécialisation Ambidextrie
210824	Rune du pacte
210825	Rune de Porteguerre
210953	Œil de Bhossca
210955	Uniforme d’initié écarlate
210963	Clé de clairvoyant
210966	Sang de la Légion
210967	Message confidentiel
210968	Clé du reliquaire
210979	Rune de Pas de l’ombre
210980	Rune de transformation
211205	Rune de Pourfendeur de cobras
211247	Patron : Bandages du phénix
211263	Corselet du jugement
211269	Dessin primitif
211301	Rune de Perce-faille
211315	Fournitures égarées : cuirs légers
211316	Fournitures égarées : pacifiques
211317	Fournitures égarées : feuillargents
211318	Fournitures égarées : potions de soins mineures
211319	Fournitures égarées : épées courtes en cuivre
211320	Fournitures égarées : pantalons runiques en cuivre
211321	Fournitures égarées : baguettes magiques inférieures
211322	Fournitures égarées : huiles de sorcier mineures
211323	Fournitures égarées : bombes grossières en cuivre
211324	Fournitures égarées : espingoles grossières
211325	Fournitures égarées : ceintures cousues main en cuir
211326	Fournitures égarées : gilets en cuir estampé
211327	Fournitures égarées : pantalons marron en lin
211328	Fournitures égarées : robes marron en lin
211329	Fournitures égarées : œufs aux herbes
211330	Fournitures égarées : viandes de loup épicées
211331	Fournitures égarées : goujons brillants
211332	Fournitures égarées : bandages épais en lin
211365	Cargaison d’approvisionnement
211367	Cargaison d’approvisionnement
211368	Cargaison d’approvisionnement
211382	Petite sacoche de coursier
211384	Sac de coursier robuste
211385	Rune de Propagation du serpent
211386	Notes de sort : Éruption d’arcanes
211387	Rune de Guide de lumière
211390	Rune de Taquinerie
211391	Rune de Pluie guérisseuse
211392	Rune d’Affliction éternelle
211393	Rune de Fureur obsessionnelle
211419	Poignée d’écailles changeantes
211420	Talisman d’écailles changeantes
211421	La boîte
211422	Tesson du Vide
211423	Gants en cuir touché par le Vide
211427	Réceptacle d’âme
211443	Lame de rage
211444	Cape d’invocateur
211445	Arc à double courbure barbare
211447	Cargaison d’armes
211448	Contrat d’approvisionnement signé
211449	Perle du vide de vengeur
211450	Perle du vide d’invocatrice
211451	Perle du vide d’acolyte
211452	Perle de Brassenoire parfaite
211454	Globe d’eau étrange
211455	Mitaines blindées glissantes
211456	Dague du sacrifice consenti
211457	Ceinturon de défenseur du Crépuscule
211458	Tome de sauvegarde d’ombre
211460	Targe arctique antique
211461	Sceptre de la pierre tombale gravé
211462	Anneau de soutien perpétuel
211463	Pinces de hanneton cliquetantes
211464	Cape de prélat usée
211465	Bottes du nimbus de clairvoyance
211466	Ceinturon de cœur du bois de soigneuse
211467	Anneau du poing de fer
211468	Mantelet noisette élimé
211471	Clé de la Bondissante
211472	Libram de bannissement
211476	Rune de l’Éveil du feu
211477	Rune d’Incinérer
211482	Offrande Briselance
211487	Explosifs de démolition
211488	Rune du vengeur
211490	Prophétie des mille lumières
211491	Sac sans fond en peau de Murloc
211492	Sacoche de Kelris
211498	Sabre-de-nuit sentinelle de recrue
211499	Loup voltigeur de recrue
211500	Bandeau résistant en étoffe
211501	Corselet de puissance
211502	Gantelets en cuir touché par le Vide
211504	Cotte d’anneaux de vengeur du Crépuscule
211505	Heaume de vengeur du Crépuscule
211506	Bottes de vengeur du Crépuscule
211507	Capuche d’élémentaliste du Crépuscule
211508	Souliers d’élémentaliste du Crépuscule
211509	Robe d’élémentaliste du Crépuscule
211510	Capuche de pourfendeur du Crépuscule
211511	Souliers de pourfendeur du Crépuscule
211512	Tunique de pourfendeur du Crépuscule
211514	Notes de sorts : Régénération de masse
211527	Sac de couchage douillet
211528	Sombre clairvoyance
211530	Prophétie de la ville ensorcelée
211531	Prophétie des sept visiteurs
211534	Clairvoyance primordiale
211691	Notes de sorts : Déflagration des arcanes
211777	Manuscrit naga
211779	Charme de compréhension
211780	Parchemin : KWYJIBO
211784	Parchemin : WUBBA WUBBA
211785	Parchemin : FIGERF
211786	Parchemin : CHAP BALK WELLES
211787	Parchemin : LOWER PING WHOMEVER
211789	Artémis Col
211799	Sac de marchandises volées
211800	Parchemin de réintégration
211809	Manuel de compréhension
211813	Charme de sentinelle d’Aile-argent
211814	Marque de voltigeur warsong
211815	Hymne de bataille d’Aile-argent
211816	Tambour de bataille warsong
211818	Globe d’eau étrange
211819	Fournitures égarées : barres de bronze
211820	Fournitures égarées : barres d’argent
211821	Fournitures égarées : cuir moyen
211822	Fournitures égarées : doulourantes
211823	Fournitures égarées : chardonniers
211824	Fournitures égarées : potions de mana inférieures
211825	Fournitures égarées : bottes grossières en bronze
211826	Fournitures égarées : passe-partout en argent
211827	Fournitures égarées : bâtonnets runiques en argent
211828	Fournitures égarées : huile de mana mineure
211829	Fournitures égarées : petites bombes en bronze
211830	Fournitures égarées : longues-vues ornées
211831	Fournitures égarées : capes noires en cuir
211832	Fournitures égarées : épaulières d’homme des collines
211833	Fournitures égarées : chemises grises en laine
211834	Fournitures égarées : capes brodées de perles
211835	Fournitures égarées : sagerelles fumées
211836	Fournitures égarées : viande d’ours fumée
211837	Fournitures égarées : palourdes gobelines
211838	Fournitures égarées : bandages épais en laine
211839	Cargaison d’approvisionnement
211840	Cargaison d’approvisionnement
211841	Cargaison d’approvisionnement
211842	Coiffe de réflexion rapiécée de Rakkamar
211843	Masque de dédain
211845	Pierre à aiguiser de Brassenoire
211846	Plans : pierre à aiguiser de Brassenoire
211848	Huile de mana de Brassenoire
211849	Formule : huile de mana de Brassenoire
211852	Protège-mains d’eau souillée
211853	Parchemin : VOCE WELL
211854	Parchemin : OMIT KESA
211855	Parchemin : STHENIC LUNATE
211856	Camail résistant en mailles
211857	Masque résistant en cuir
211933	Fournitures égarées : pierre brute
211934	Fournitures égarées : potions de soin
211935	Fournitures égarées : élixir de maîtrise du feu
211940	Gardienne tribale d’Ecks’av
211941	Yari de marche-vent
211944	Karma de Tojara
211953	Parchemin de récupération arcanique I
211954	Parchemin de précision des arcanes I
211955	Parchemin de protection arcanique : feu I
211956	Parchemin de protection arcanique : givre I
211957	Parchemin de pouvoir des Arcanes I
212160	Déplaceur de chronochance
212225	Réceptacle d’âme infini
212230	Schéma : réceptacle d’âme
212548	Rune d’éclipse
212549	Rune de trappeur
212551	Rune de Guerre
212552	Épiphanie psychosophique
212559	Rune de Lame empoisonnée
212560	Rune d’Éveil ancestral
212561	Rune de Ténèbres enflammées
212562	Rune de Rage guérisseuse
212568	Trophée tête-de-loup
212580	Bâton de gardien du savoir
212581	Arc d’estafette
212582	Épée de protecteur
212583	Lame de sentinelle
212584	Bâton noueux de conseiller
212585	Arc de voltigeur
212586	Épée de légionnaire
212587	Lame d’éclaireur
212588	Gants d’approvisionnement
212589	Bottines de coursier
212590	Sangle de soutien
212748	Note en lambeaux
212994	Manchettes du chasseur de tempêtes
212996	Manchettes de mande-foudre
212997	Manchettes de mande-flots
213074	Rune de nourrissement
213086	Rune de la tempête
213087	Cape de sergent
213088	Cape de sergent
213090	Rune de synergie
213093	Rune de puissance
213094	Rune de Nova de feu
213096	Rune de leurres
213098	Rune d’Évocation
213100	Rune de Savoir interdit
213101	Rune d’ombreflamme
213102	Rune de méchanceté
213103	Rune de Vague de sang
213104	Rune de Précision impitoyable
213105	Shawarmageddon
213109	Rune de Rage concentrée
213110	Rune de la commandante
213111	Rune d’intervention
213112	Notes de sort : Barrage de projectiles
213117	Rune de berserk
213118	Rune du roi de la jungle
213119	Rune d’instinct
213120	Rune de la rêveuse
213121	Houx préservé
213122	Rune de tir assuré
213123	Rune d’exposition
213124	Rune de combat rapproché
213125	Rune de Revigoration
213126	Rune de ferrailleuse
213127	Notes de sort : ATTERRIT GIVORS
213128	Rune de piété
213129	Rune d’Étreinte de la Lumière
213130	Rune d’imprégnations
213131	Rune de boucliers saints
213132	Rune du gardien
213136	Rune de subtilité
213137	Rune de l’assaillant
213138	Rune de gaucher
213139	Rune de l’assassin
213140	Prophétie de chemin accéléré
213141	Rune d’espoir
213142	Prophétie de malveillance captive
213143	Épiphanie apocryphe
213144	Épiphanie lumineuse
213165	Les basilics : faut-il avoir peur de se faire pétrifier ?
213168	Pièce sanglante en cuivre
213169	Pièce sanglante en argent
213170	Pièce sanglante en or
213278	Garde-mains de maestro des marrons
213279	Calot réfléchissant
213280	Visioscope de tir d’élite
213281	Réactivateur d’hyperflux électromagnétique
213282	Engrenage d’innovation en surcharge
213283	Engrenage de déflagration en surcharge
213284	Engrenage de dévastation en surcharge
213285	Manchettes tachées d’huile de Lev
213286	Aiguille de l’électrocuteur
213287	Hexécrou de l’électrocuteur
213288	Gantelets crasseux de Grubbis
213289	Hydrobâton
213290	Godillots acides
213291	Vengeresse toxique II
213292	Tranchoir bidulotronique
213293	Super-fusil high-tech mod. VII
213294	Solerets des Basses-Cavernes
213295	Vibrolame ultrasonique
213296	Coupe-tête superchargé
213297	Pulvéri-marteau oscillant
213298	Salopette de mécabâtisseur
213299	Pantalon pétrolifère
213300	Gants d’as du pilotage
213301	Mantelet synthétique
213302	Mantelet de négociation rusée
213303	Spallières paratonnerres
213304	Espauliers de tuerie de Troggs
213305	Plaques d’épaule usinées en alliage
213306	Couverture d’ingéniosité
213307	Drapé de démantèlement
213308	Prototype de cape parachute
213309	Cape d’invention
213310	Haut brillant hyperconducteur
213311	Robe hyperconductrice
213312	Tablier isolé
213313	Corselet isolé
213314	Mailles électromantiques
213315	Haut-de-mailles électromantique
213316	Cuirasse de D.A.N.G.E.R.
213317	Stabilisateurs de visée expérimentaux
213318	Bracelets ornés en sombrefer
213319	Gants du machiniste
213320	Doigts de précision des arcanes
213321	Ceinture de décoction volatile
213322	Baudrier d’arnaque
213323	Corde de la terre profonde
213324	Corde cintrée électromagnétique
213325	Ceinturon de sombre vision
213326	Ceinturon de récupération
213327	Ceinture du Trogg berserker
213328	Culotte hyperconductrice
213329	Jupe hyperconductrice
213330	Cuissards de D.A.N.G.E.R.
213331	Jambières isolées
213332	Garde-jambes isolés
213333	Haut-de-chausse électromantique
213334	Gambison électromantique
213335	Bottes de D.A.N.G.E.R.
213336	Brodequins hyperconducteurs
213337	Sandales hyperconductrices
213338	Bottes isolantes électromantiques
213339	Solerets isolants électromantiques
213340	Bottes d’opération des gnomebots
213341	Bottes de travail isolées
213342	Galoches isolées
213343	Écusson de justice
213344	Torque d’agent de la paix de Gnomeregan
213345	Pendentif à piston
213346	Pendentif de retour au foyer
213347	Chambre de combustion miniature
213348	Expérience gyromatique 420b
213349	Flacon de pilules de gniode
213350	Noyau durci de Wirdal
213351	Grand bouclier irradié
213352	Grâce de soigne-pignon
213353	Bâton de défibrillation
213354	Bâton du génie du mal
213355	Aiguillon de Falco
213356	Pétoire personnalisée de Thermojoncteur
213369	Cuir faiblement luminescent
213370	Lanières de cuir irradiées
213371	Caisse de solution de gniode contaminée
213372	Gniode isolant
213373	Ferraille réfléchissante
213376	Plaques en vrai-argent faiblement radioactif
213378	Microfilament instable
213379	Arcano-filament hyperconducteur
213381	Pile de rouages ternis
213383	Rouages polis en vrai-argent
213390	Mur de rouages en vrai-argent
213391	Gantelets en mithril électrifiés INUTILISÉS
213407	Herbe à chat
213408	Macro-ajusteur gyromatique
213409	Déchiqueteur arcanique de Mekkatorque
213410	Bidulame rougeoyante
213411	Boute-feu inextinguible d’Izzleflick
213412	Bouclier de sécurité diélectrique
213413	Protège-épaules généreusement matelassés
213414	Echarpe de répare-méca
213415	Couvre-bras de bricoleuse
213416	Fendoir à propulsion de Thermojoncteur
213417	Camail en filament de vrai-argent
213418	Annelets en vrai-argent soudés
213419	Manuel de réparation 9-60
213421	Note roussie
213426	Bâtonnet d’éclair ogre
213427	Objet recyclé sali
213442	Griffe du maître des rouages
213443	Cadeau tic-taquant
213452	Rune du Sacré inerte
213513	Libram de délivrance
213526	Cuissot hybride
213527	Mélange d’épices du contrebandier
213528	Bière embaumée
213529	Venin visqueux
213542	Le Nécro-Gnomicon
213543	Parchemin : BONHOMME
213544	Parchemin : ZOO ET DU KAFÊ
213545	Parchemin : CHUTE D’AGUERRI
213546	Parchemin : TAGADAAA
213547	Parchemin : ELLUQE PÉÉE
213548	Parchemin de passage liminal
213549	Parchemin de pêche arcanique
213550	Parchemin de métamorphose : melon étrange
213551	Parchemin de déplacement contrôlé
213552	Larme de Theradras
213553	Larme de Theradras
213554	Fiole d’eau cristalline
213558	Baume élémentaire
213559	Levier de vitesse de mécanotrotteur
213560	Silencieux de mécanotrotteur
213563	Guide de terrain
213564	Parchemin d’évocation mineure
213565	Kit d’entomologiste novice
213583	Sculpture en soufre
213594	Idole de moquerie
213599	Vision troublante
213632	Notes de sort partielles
213633	Notes de sort partielles
213634	Notes de sort partielles
213641	Caisse de recyclage de Gnomeregan
213701	Plume de harpie puissante
213709	Croc de serpent-nuage
213735	Processeur N.O.Y.A.U G-7 en état neuf
213736	Processeur N.O.Y.A.U G-7 rouillé
213737	Offrande à l’esprit du vent
214435	Clé de cage à puma
215111	Monocle gneuro-lié en arcano-filament
215114	Camail hyperconducteur en écailles lumineux
215115	Feuille d’or hyperconductrice
215129	Formule : Enchantement d’arme (Démantèlement)
215138	Formule : Enchantement de plastron (Électrocution vengeresse)
215141	Cachet enchanté : innovation
215149	Patron : Monocle gneuro-lié en arcano-filament
215152	Patron : Capuche gneuro-liée luminescente
215153	Schéma : Mur de rouages en vrai-argent
215155	Plan : Casque anti-interférences trempé
215156	Schéma : Feuille d’or hyperconductrice
215162	Potion de régénération faiblement irradiée
215163	Recette : Potion de régénération faiblement irradiée
215166	Capuche gneuro-liée luminescente
215257	Parchemin de compréhension
215365	Mantelet d’invocatrice
215366	Corde d’invocatrice
215367	Patron : Cuir faiblement luminescent
215368	Patron : Arcano-filament hyperconducteur
215369	Patron : Corde d’invocatrice
215370	Patron : Mantelet d’invocatrice
215371	Charme de Jani
215373	Marteau d’entraînement de la Main d’argent
215374	Épée ancestrale
215375	Bâton de tacticienne
215376	Masse de croisé
215377	Robe irradiée
215378	Bottes irradiées
215379	Chausses irradiées
215380	Ceinture de levage assistée
215381	Chaperon de canalisation gneuro-conducteur
215382	Chaperon antiradiation en écailles
215383	Plans : Cage cérébrale en vrai-argent réfléchissant
215384	Plans : Plaques en vrai-argent faiblement radioactif
215385	Fournitures égarées : barres d’or
215386	Fournitures égarées : barres de mithril
215387	Fournitures égarées : peau lourde
215388	Fournitures égarées : cuir épais
215389	Fournitures égarées : pâlerette
215390	Fournitures égarées : moustache de Khadgar
215391	Fournitures égarées : hivernale
215392	Fournitures égarées : lotus pourpre
215393	Fournitures égarées : potions de soins supérieures
215394	Fournitures égarées : potions de bouclier de pierre inférieures
215395	Fournitures égarées : élixirs d’agilité
215396	Fournitures égarées : élixirs de défense supérieure
215397	Fournitures égarées : haches massives en fer
215398	Fournitures égarées : brassards en fer émeraude
215399	Fournitures égarées : gantelets lourds en mithril
215400	Fournitures égarées : silex à aiguiser solides
215401	Fournitures égarées : kits de moissonneur compact
215402	Fournitures égarées : grandes bombes en fer
215403	Fournitures égarées : lunettes mortelles
215404	Fournitures égarées : tromblons en mithril
215405	Fournitures égarées : bottes-fusées gnomes
215406	Fournitures égarées : mortiers gobelins
215407	Fournitures égarées : épaulières barbares
215408	Fournitures égarées : gants du gardien
215409	Fournitures égarées : brassards en écailles de tortue
215410	Fournitures égarées : ceintures mates
215411	Fournitures égarées : capes de givre en cuir
215412	Fournitures égarées : gants en peau d’ombre
215413	Fournitures égarées : chemises blanches habillées
215414	Fournitures égarées : culottes cramoisies en soie
215415	Fournitures égarées : riches chemises violettes en soie
215416	Fournitures égarées : masques blancs de bandit
215417	Fournitures égarées : bisque de tortue apaisante
215418	Fournitures égarées : saucisses d’araignée
215419	Fournitures égarées : bandages épais en soie
215420	Fournitures égarées : morue rochécaille
215421	Fournitures égarées : huile de feu
215422	Patron : Camail hyperconducteur en écailles lumineux
215423	Patron : Chaperon de canalisation gneuro-conducteur
215424	Patron : Chaperon antiradiation en écailles
215425	Écho du marécage
215426	Écho du cimetière
215427	Écho d’Arathi
215428	Écho de Theramore
215429	Schéma : Rouages polis en vrai-argent
215430	Retombée de Gnomeregan
215431	Schéma : Bombe à radiations puissante
215432	Schéma : Bombe à radiations Ev-Lan
215433	Recette : Gniode isolant
215434	INUTILISÉ
215435	Libram de bénédiction
215436	Totem de flamme revigorante
215437	Transfigurateur de trogg 3000
215441	Marteau brisé
215443	Fragments d’orbe fracassé
215444	Monstre - Masse - Tuyaux éventrés
215449	Rapetisseur de monde
215450	Projet Tabard (Aidan)
215456	Message roussi
215458	Message joint
215459	Message joint
215460	Message joint
215461	Poulet d’attaque domestiqué
215468	Ordres du grand croisé
215683	Géomancie : une montagne de puissance
215815	Les bases de la magie défensive
215816	Un tissage de mensonges : mythes et légendes démystifiés
215817	Les démons et vous
215820	Les Momies : le guide des morts-vivants répugnants
215822	RwlRwlRwlRwl !
215824	Le soin des familiers démoniaques pour les pas doués
216484	Bottes de guerres foudreforgées
216485	Cuirasse foudreforgée
216486	Cuissards foudreforgés
216490	Idole de colère
216491	Cargaison de bois de Strangleronce
216492	Sifflet de raptor tacheté de sang
216494	Changeur de monde fantaisiste d’Aragriar
216495	Ecraseur sanguin
216496	Brise-tête sanguin
216497	Exsanguinar
216498	Grimoire sanguin enchanté
216499	Ecraseur écorce-sang
216500	Talisman du bosquet sang-lié
216501	Barrière de tempête de sang
216502	Totem de guerre Tempête de sang
216503	Bijou de tempête de sang
216504	Sabre de l’éclipse de la Lumière sanglante
216505	Radiance du croisé de la Lumière sanglante
216506	Tranchant du vengeur de la Lumière sanglante
216507	Sang-sceau umbral
216508	Anneau tourne-sang infernal
216509	Essence de pacte infernal
216510	Cercle de résonance sanguine
216511	Sceau de braise-sang
216512	Boucle des veines transies
216513	Talisman tigre-sang
216514	Carquois sanguin
216515	Giberne sanguine
216516	Arc fouette-sang
216517	Sanctuaire sanguin
216518	Sceau d’engagement sanglant
216519	Anneau d’ombre sanguine
216520	Lame de moissang
216521	Frappeurs sanguins véloces
216522	Stylet taché de sang
216523	Clé de la cage rouillée
216570	Rênes de tigre à dents de sabre doré
216606	Rune de maîtrise à deux mains
216607	Offrande de lumière sanglante
216608	Réflecteurs de rayons radieux
216610	Ordres du grand croisé
216615	Balise de la tempête de sang ancestrale
216616	Clé de cage de la base
216617	Uniforme de combat de Kurzen
216618	Récompense du capitaine Aransas
216619	Mélange étudiant
216620	Cape de pourriture sanguine
216621	Drapé détrempé de sang
216622	Cape coagulée
216623	Cape d’hémostase
216633	Montant hydraulique en vrai-argent
216634	Fusible en cartouche GG12-082
216635	Noyau du Vide épuisé
216636	Noyau du Vide chargé
216637	Un tas de pièces aléatoires
216645	Granule de ténèbres
216646	Caisse mystère de Ziri
216661	Anneau sali
216662	Anneau d’or brillant
216673	Anneau d’or brillant de Talvash
216674	Anneau d’or brillant de Nogg
216675	Robe civinade en parfait état
216676	Pantalon du coureur agile
216678	Jambières à triple renfort
216679	Outil de démantèlement de Shoni
216680	Mitaines de Shilly
216698	Brachiales de sergent-major en cuir de dragon
216699	Garde-bras de sergent-major en mailles
216700	Brachiales de sergent-major en cuir
216701	Garde-poignets de sergent-major en plaques
216702	Crispins de sergent-major en soie
216703	Garde-poignets d’adjudant en mailles
216704	Garde-bras d’adjudant en cuir de dragon
216705	Brassards d’adjudant en plaques
216706	Garde-bras d’adjudant en cuir
216707	Crispins d’adjudant en soie
216738	Manuel de Redirection
216740	Tome d’intelligence étendue
216744	Parchemin de robustesse augmentée
216745	Parchemin d’ombrefiel
216746	Manuel du cri de commandement
216747	Grimoire de moisson d’âme
216748	Grimoire du portail d’invocation
216764	Pamphlet de fauverie accentuée
216767	Pamphlet de résurrection
216769	Révélation de projection totémique
216770	Traité sur l’aspect de la vipère
216771	Pamphlet de restauration améliorée
216879	Parchemin troll mystérieux
216880	Parchemin troll déchiffré
216884	Lame sanguinaire
216914	Mérite terni
216918	Bottes de Gangrecœur
216919	Écharpe de Gangrecœur
216920	Manchettes de Gangrecœur
216921	Poignes de Gangrecœur
216922	Couronne de Gangrecœur
216923	Jambières de Gangrecœur
216924	Étreinte de Gangrecœur
216925	Mantelet de Gangrecœur
216938	Insigne supérieur de l’Alliance
216939	Insigne supérieur de la Horde
216941	Cachet d’Ariden
216945	Relique de Dalaran curieuse
216946	Relique de Dalaran scintillante
216947	Relique de Dalaran bourdonnante
216948	Relique de Dalaran étrange
216949	Relique de Dalaran lourde
216950	Relique de Dalaran inquiétante
216951	Relique de Dalaran glissante
216956	Lettre déchirée
216971	Sacoche de pièces sanglantes en cuivre
216972	Sacoche de pièces sanglantes en argent
217005	Cape de réparateur
217006	Marteau de mécanicien
217007	Bottes vidées d’énergie
217008	Pansière vidée d’énergie
217009	Jambières vidées d’énergie
217014	Sac de fournitures
217017	Concours de pêche !
217161	Notes de sort : ÉFULCIRE AGRIVEDE
217244	Patron : Robe cramoisie en soie
217245	Robe cramoisie en soie
217246	Gilet noir en tisse-mage
217247	Jambières noires en tisse-mage
217248	Ceinture terrestre en soie
217249	Patron : Ceinture terrestre en soie
217250	Épaulières cramoisies en soie
217251	Patron : Épaulières cramoisies en soie
217252	Longue cape en soie
217253	Bottes de l’enchanteur
217254	Patron : Bottes de l’enchanteur
217255	Ceinture cramoisie en soie
217256	Gilet terrestre
217257	Capuche d’enchanteur
217258	Patron : Capuche d’enchanteur
217259	Masque du grand vaudou
217260	Patron : Masque du grand vaudou
217261	Robe du grand vaudou
217262	Patron : Robe du grand vaudou
217263	Brassards de gardien en cuir
217264	Patron : Brassards de gardien en cuir
217265	Ceinture de gardien
217266	Patron : Ceinture de gardien
217267	Pantalon de gardien
217268	Cuirasse en écailles de tortue
217270	Gants en écailles de tortue
217271	Patron : Gants en écailles de tortue
217273	Gantelets en écailles dorées
217274	Plans : Gantelets en écailles dorées
217275	Bottes en écailles dorées
217276	Plans : Bottes en écailles dorées
217277	Cuirasse en écailles dorées
217278	Plans : Cuirasse en écailles dorées
217279	Camail en écailles dorées
217280	Plans : Camail en écailles dorées
217281	Épée large en acier lunaire
217282	Plans : Épée large en acier lunaire
217283	Épaulières en écailles dorées
217284	Plans : Épaulières en écailles dorées
217285	Jambières en écailles dorées
217286	Plans : Jambières en écailles dorées
217287	Baguette mystique supérieure
217288	Robe de la liche
217289	Armure de Froidemort
217290	Œil luminescent de Mordresh
217291	Crâne sans vie de Mordresh
217292	Écharpe de mage mortel
217293	Cape d’araignée soyeuse
217294	Voile embaumé
217295	Baguette nécrotique
217296	Talisman d’éclat fantôme
217297	Robe de Doan
217298	Mantelet de Doan
217299	Perche illusoire
217300	Chapeau de Blanchetête
217301	Amulette de Triune
217302	Puissance de Mograine
217303	Jambières Tissepierre
217304	Gants de Revelosh
217305	Garde-bras de Revelosh
217306	Bottes de Revelosh
217307	Spallières de Revelosh
217308	Cachet enchanté : innovation
217314	Carabine vise-lune
217315	Arc précis
217336	Monstre – incube – fouet masse à une main
217337	Cargaison d’approvisionnement
217338	Cargaison d’approvisionnement
217339	Cargaison d’approvisionnement
217345	Poison sébacé
217346	Poison ankylosant
217347	Poison atrophiant
217350	Notes d’ingénierie de Thermojoncteur
217351	Notes d’ingénierie de Thermojoncteur
217398	Elixir des arcanes inférieur
217399	Recette : élixir des arcanes inférieur
217495	Parchemin de cryo-détonation
217496	Parchemin de la lame
217497	Épée de Narpas
217609	Talisman de Kazdor
217693	Potion d’invisibilité
217704	Houlette ferrée
217717	Emblème vide
217718	Emblème de magie du sang
217719	Essence de magie du sang
217720	Offrande de chair
217721	Offrande d’os
217727	Sceau des morts
217736	Rune de la coterie
217737	Talisman modifié
219021	Sac de livraison pesant
219022	Anneau de transporteuse
219023	Anneau de clerc
219024	Anneau de messagerie
219135	Pendentif de curiosité
219136	Pendentif de ténacité
219137	Pendentif d’initiative
219147	Rune de Grâce
219223	Furie du maître-lame
219326	Graine du renouveau
219343	Capuche de filou
219345	Lasso infernal
219399	Mousse des cauchemars
219401	Minerai de fer froid
219402	Écaille de dragon touchée par le rêve
219404	Faux d’ombre
219405	Texte de l’ogre magi
219406	Œuf de dragon vert non éclos
219414	Coquilles d’œufs brisées
219444	Oniracine
219445	Poussière de pyrite
219446	Écaille de dragon imprégnée du rêve
219447	Œuf de dragon touché par le rêve
219448	Moteur onirique
219449	Prophétie d’Azshara
219454	Lotus stellaire
219486	Minerai d’astrargent
219487	Coquille stellaire
219488	Œuf de dragon touché par les étoiles
219490	Relique d’Elune
219491	Perle onirique
219514	Racine lunaire
219515	Pierre de lune supérieure
219517	Écaille de dragon lunaire
219518	Diatribe de harpie
219519	Notes du gardien fou
219520	Œuf de dragon lueur-de-lune
219526	Exposé de mission : bois de la Pénombre
219759	Rapport de terrain de Charla
219770	Rapport de terrain de Gemeron
219771	Rapport de terrain de Thandros
219772	Rapport de terrain de Fallia
219773	Exposé de mission : Ashenvale
219774	Exposé de mission : Hinterlands
219775	Exposé de mission : Feralas
219776	Rapport de surveillance : tertre des ogres Vul’Gol
219778	Rapport de surveillance : verger Pourrissant
219803	Rapport de surveillance : ferme des Yorgen
219918	Missive sanglante
219924	Rapport de surveillance : Chant des forêts
219925	Rapport de surveillance : Satyrnaar
219926	Rapport de surveillance : camp de bûcherons Warsong
219927	Gage d’émeraude
219928	Rapport de surveillance : Agol’watha
219929	Missive sanglante
219930	Missive sanglante
219935	Lame de Kajind
219937	Rapport de surveillance : Shaol’watha
219938	Rapport de surveillance : rocher de l’Affût
219957	Rapport de surveillance : Oneiros
219958	Rapport de surveillance : Colosses jumeaux
219959	Rapport de surveillance : ruines de Vent-du-Corbeau
219962	Incursions de cauchemar : bois de la Pénombre, mission I
219963	Autorisation d’embauche : bois de la Pénombre, mission I
219965	Autorisation d’embauche : bois de la Pénombre, mission II
219966	Incursions de cauchemar : bois de la Pénombre, mission II
219967	Incursions de cauchemar : bois de la Pénombre, mission III
219968	Incursions de cauchemar : bois de la Pénombre, mission IV
219969	Incursions de cauchemar : bois de la Pénombre, mission V
219970	Incursions de cauchemar : bois de la Pénombre, mission VI
219971	Incursions de cauchemar : bois de la Pénombre, mission VII
219972	Incursions de cauchemar : bois de la Pénombre, mission VIII
219973	Incursions de cauchemar : bois de la Pénombre, mission IX
219974	Incursions de cauchemar : bois de la Pénombre, mission X
219975	Incursions de cauchemar : bois de la Pénombre, mission XI
219976	Incursions de cauchemar : bois de la Pénombre, mission XII
219977	Incursions de cauchemar : bois de la Pénombre, mission XIII
219978	Incursions de cauchemar : bois de la Pénombre, mission XIV
219979	Incursions de cauchemar : bois de la Pénombre, mission XV
219980	Incursions de cauchemar : bois de la Pénombre, mission XVI
219981	Incursions de cauchemar : bois de la Pénombre, mission XVII
219982	Incursions de cauchemar : bois de la Pénombre, mission XVIII
219983	Autorisation d’embauche : bois de la Pénombre, mission III
219984	Autorisation d’embauche : bois de la Pénombre, mission IV
219985	Autorisation d’embauche : bois de la Pénombre, mission V
219986	Autorisation d’embauche : bois de la Pénombre, mission VI
219987	Autorisation d’embauche : bois de la Pénombre, mission VII
219988	Autorisation d’embauche : bois de la Pénombre, mission VIII
219989	Autorisation d’embauche : bois de la Pénombre, mission IX
219990	Autorisation d’embauche : bois de la Pénombre, mission X
219991	Autorisation d’embauche : bois de la Pénombre, mission XI
219992	Autorisation d’embauche : bois de la Pénombre, mission XII
219993	Autorisation d’embauche : bois de la Pénombre, mission XIII
219994	Autorisation d’embauche : bois de la Pénombre, mission XIV
219995	Autorisation d’embauche : bois de la Pénombre, mission XV
219996	Autorisation d’embauche : bois de la Pénombre, mission XVI
219997	Autorisation d’embauche : bois de la Pénombre, mission XVII
219998	Autorisation d’embauche : bois de la Pénombre, mission XVIII
219999	Incursions de cauchemar : Ashenvale, mission I
220000	Incursions de cauchemar : Ashenvale, mission II
220001	Incursions de cauchemar : Ashenvale, mission III
220002	Incursions de cauchemar : Ashenvale, mission IV
220003	Incursions de cauchemar : Ashenvale, mission V
220004	Incursions de cauchemar : Ashenvale, mission VI
220005	Incursions de cauchemar : Ashenvale, mission VII
220006	Incursions de cauchemar : Ashenvale, mission VIII
220007	Incursions de cauchemar : Ashenvale, mission IX
220008	Incursions de cauchemar : Ashenvale, mission X
220009	Incursions de cauchemar : Ashenvale, mission XI
220010	Incursions de cauchemar : Ashenvale, mission XII
220011	Incursions de cauchemar : Ashenvale, mission XIII
220012	Incursions de cauchemar : Ashenvale, mission XIV
220013	Incursions de cauchemar : Ashenvale, mission XV
220014	Incursions de cauchemar : Ashenvale, mission XVI
220015	Incursions de cauchemar : Ashenvale, mission XVII
220016	Incursions de cauchemar : Ashenvale, mission XVIII
220017	Incursions de cauchemar : Hinterlands, mission I
220018	Incursions de cauchemar : Hinterlands, mission II
220019	Incursions de cauchemar : Hinterlands, mission III
220020	Incursions de cauchemar : Hinterlands, mission IV
220021	Incursions de cauchemar : Hinterlands, mission V
220022	Incursions de cauchemar : Hinterlands, mission VI
220023	Incursions de cauchemar : Hinterlands, mission VII
220024	Incursions de cauchemar : Hinterlands, mission VIII
220025	Incursions de cauchemar : Hinterlands, mission IX
220026	Incursions de cauchemar : Hinterlands, mission X
220027	Incursions de cauchemar : Hinterlands, mission XI
220028	Incursions de cauchemar : Hinterlands, mission XII
220029	Incursions de cauchemar : Hinterlands, mission XIII
220030	Incursions de cauchemar : Hinterlands, mission XIV
220031	Incursions de cauchemar : Hinterlands, mission XV
220032	Incursions de cauchemar : Hinterlands, mission XVI
220033	Incursions de cauchemar : Hinterlands, mission XVII
220034	Incursions de cauchemar : Hinterlands, mission XVIII
220035	Incursions de cauchemar : Feralas, mission I
220036	Incursions de cauchemar : Feralas, mission II
220037	Incursions de cauchemar : Feralas, mission III
220038	Incursions de cauchemar : Feralas, mission IV
220039	Incursions de cauchemar : Feralas, mission V
220040	Incursions de cauchemar : Feralas, mission VI
220041	Incursions de cauchemar : Feralas, mission VII
220042	Incursions de cauchemar : Feralas, mission VIII
220043	Incursions de cauchemar : Feralas, mission IX
220044	Incursions de cauchemar : Feralas, mission X
220045	Incursions de cauchemar : Feralas, mission XI
220046	Incursions de cauchemar : Feralas, mission XII
220047	Incursions de cauchemar : Feralas, mission XIII
220048	Incursions de cauchemar : Feralas, mission XIV
220049	Incursions de cauchemar : Feralas, mission XV
220050	Incursions de cauchemar : Feralas, mission XVI
220051	Incursions de cauchemar : Feralas, mission XVII
220052	Incursions de cauchemar : Feralas, mission XVIII
220053	Autorisation d’embauche : Ashenvale, mission I
220054	Autorisation d’embauche : Ashenvale, mission II
220055	Autorisation d’embauche : Ashenvale, mission III
220056	Autorisation d’embauche : Ashenvale, mission IV
220057	Autorisation d’embauche : Ashenvale, mission V
220058	Autorisation d’embauche : Ashenvale, mission VI
220059	Autorisation d’embauche : Ashenvale, mission VII
220060	Autorisation d’embauche : Ashenvale, mission VIII
220061	Autorisation d’embauche : Ashenvale, mission IX
220062	Autorisation d’embauche : Ashenvale, mission X
220063	Autorisation d’embauche : Ashenvale, mission XI
220064	Autorisation d’embauche : Ashenvale, mission XII
220065	Autorisation d’embauche : Ashenvale, mission XIII
220066	Autorisation d’embauche : Ashenvale, mission XIV
220067	Autorisation d’embauche : Ashenvale, mission XV
220068	Autorisation d’embauche : Ashenvale, mission XVI
220069	Autorisation d’embauche : Ashenvale, mission XVII
220070	Autorisation d’embauche : Ashenvale, mission XVIII
220071	Autorisation d’embauche : Hinterlands, mission I
220072	Autorisation d’embauche : Hinterlands, mission II
220073	Autorisation d’embauche : Hinterlands, mission III
220074	Autorisation d’embauche : Hinterlands, mission IV
220075	Autorisation d’embauche : Hinterlands, mission V
220076	Autorisation d’embauche : Hinterlands, mission VI
220077	Autorisation d’embauche : Hinterlands, mission VII
220078	Autorisation d’embauche : Hinterlands, mission VIII
220079	Autorisation d’embauche : Hinterlands, mission IX
220080	Autorisation d’embauche : Hinterlands, mission X
220081	Autorisation d’embauche : Hinterlands, mission XI
220082	Autorisation d’embauche : Hinterlands, mission XII
220083	Autorisation d’embauche : Hinterlands, mission XIII
220084	Autorisation d’embauche : Hinterlands, mission XIV
220085	Autorisation d’embauche : Hinterlands, mission XV
220086	Autorisation d’embauche : Hinterlands, mission XVI
220087	Autorisation d’embauche : Hinterlands, mission XVII
220088	Autorisation d’embauche : Hinterlands, mission XVIII
220089	Autorisation d’embauche : Feralas, mission I
220090	Autorisation d’embauche : Feralas, mission II
220091	Autorisation d’embauche : Feralas, mission III
220092	Autorisation d’embauche : Feralas, mission IV
220093	Autorisation d’embauche : Feralas, mission V
220094	Autorisation d’embauche : Feralas, mission VI
220095	Autorisation d’embauche : Feralas, mission VII
220096	Autorisation d’embauche : Feralas, mission VIII
220097	Autorisation d’embauche : Feralas, mission IX
220098	Autorisation d’embauche : Feralas, mission X
220099	Autorisation d’embauche : Feralas, mission XI
220100	Autorisation d’embauche : Feralas, mission XII
220101	Autorisation d’embauche : Feralas, mission XIII
220102	Autorisation d’embauche : Feralas, mission XIV
220103	Autorisation d’embauche : Feralas, mission XV
220104	Autorisation d’embauche : Feralas, mission XVI
220105	Autorisation d’embauche : Feralas, mission XVII
220106	Autorisation d’embauche : Feralas, mission XVIII
220164	Rune du gladiateur
220165	Rune de colère
220166	Noyau infernal ardent
220167	Poussière de tombeau chatoyante
220168	Bière blonde de lave triple
220169	Symbole de foi
220173	Parasomnie
220213	Sang-de-vie gangrené
220214	Mailles infernales
220216	Lasso infernal
220217	Rune du Vorace
220345	Sorcellerie sanguine
220346	Légendes des Eaugures
220347	Le liminal et l’arcane
220348	Étiquette quotidienne
220349	Plan de Formepierre
220350	Voyages venimeux
220351	Sapta d’air trouble
220352	Un esprit métallique
220353	Codex d’adjurateur
220360	Rune d’efflorescence
220375	Fragment d’air
220379	Notes de chaman déchirées
220446	Trésor venu d’ailleurs
220510	Essence élémentaire
220511	Grand heaume du Cauchemar
220512	Casque impeccable en acier doré
220514	Visière de plumes verdoyantes
220515	Casque émeraude enchanté
220516	Visière oubliée de balafreur
220518	Chapeau poussiéreux de Ba’ham
220519	Coiffure vaudou ornée de plumes
220521	Coiffure de ritualiste hakkari
220522	Couronne du voleur d’âme
220523	Visage de l’exilé
220525	Fragment d’air luminescent
220526	Processeur N.O.Y.A.U G-7 couvert de vase
220527	Mantelet de berserker atal’ai
220528	Épaulières de chasseur atal’ai
220529	Spallières de fanatisme
220530	Volonté du guerrier atal’ai
220531	Fleur violette ondulante
220532	Spallières renforcées atal’ai
220533	Cuirasse reforgée atal’ai
220534	Étreinte éternelle du serpent des vents
220535	Vêtements du prophète atal’ai
220536	Poignets d’homme-médecine atal’ai
220537	Brassards des eaux sombres du rêveur
220538	Brassards d’écailles gluantes maudits
220539	Poignets de guerre de sacrifice
220540	Garde-mains chargés de corruption
220541	Poings malades en plaques
220542	Gantelets des eaux troubles polluées
220543	Gants en écailles émeraude
220544	Serres d’explosion sanglante
220545	Gants nauséabonds de combattant
220546	Mains du tourmenté
220547	Gants du prophète atal’ai déchu
220548	Gants de maléficieur atal’ai
220549	Sangle Cime-de-l’aube
220550	Baudrier de pilleur de temple
220551	Écharpe du Rêve d’émeraude de fidèle
220552	Sangle de souffrance
220553	Ceinture de l’adorateur réprouvé
220554	Ceinture en défense d’Atal’alarion
220555	Ceinturon atal’ai en écailles de serpent
220556	Kilt du prophète atal’ai déchu
220557	Sarong en écailles du vent maudit
220558	Jambières d’assassin atal’ai
220559	Jambières en écailles de drake revitalisées
220560	Cuissards coque-d’argent
220561	Demi-bottes de troll tenace
220562	Grèves de guerre injectées de sang
220563	Bottes du chaman de sang atal’ai
220564	Bottes ondulécaille restaurées
220565	Bottes éthériennes de Marche-brume
220566	Griffe fumeuse
220567	Épieu ensanglanté
220568	Hache-fusil d’explorateur de temple
220569	Marteau-rageur caustique
220570	Mantelet des cauchemars
220571	Arc long cinglant
220572	Arbalète à répétition rapide de Rinzo
220573	Arc de chasse de traqueffroi
220574	Dent aiguisée d’Eranikus
220575	Dévoreuse des damnés
220576	Hache de bourreau atal’ai
220577	Puissance du Loa du sang
220578	Poing des Réprouvés
220579	Bâton de mojo du féticheur
220580	Folie de l’avatar
220581	Maillotin du serpent
220582	Cri du dragon
220583	Lame infâme du misérable
220584	Lame souffle-de-flamme
220585	Clou redoutable dégradé
220586	Hubris, la marqueuse de bandits
220587	Dague sacrificielle onirique
220588	Griffe en croc de cobra
220589	Cogneur du serpent
220590	Bâton d’adoration hakkari
220591	Bâtonnet de restauration de Mijan
220594	Faux du Rêve
220595	Bâton focalisateur de cauchemar
220596	Bâtonnet de divination ancien
220597	Pierre de drake du héraut du Rêve
220598	Pierre de drake du héraut du Cauchemar
220599	Pierre de drake du prophète de sang
220600	Écu de prééminence
220601	Garde de féticheur hakkari
220602	Demi-carapace de tortue d’égout
220603	Bâtonnet de corrosion irréversible
220604	Trophée de cauchemar
220605	Libram de sacrilège
220606	Idole du Rêve
220607	Totem de l’ascendance tourmentée
220608	Drapé peau-de-plume
220609	Drapé de crépuscule
220610	Rune de dextérité mentale
220611	Cape de maléfice d’Hukku
220612	Rune de raz-de-marée
220613	Rune de tonnerre grondant
220614	Rune de horion statique
220615	Cape en peau de panthère
220616	Rune de surcharge
220617	Rune de pandémie
220618	Rune d’aura d’immolation
220619	Cérémonie du sang atal’ai
220620	Crâne de serpent des vents
220621	Cristal de résonance de cauchemar
220622	Œil de dragon parfaitement préservé
220623	Médaillon perdu de Jin’do
220624	Charme de courage taché de sang
220625	Résilience de l’exilé
220626	Bague griffe-de-drake du berserker
220627	Bague griffe-de-drake du traqueur
220628	Bague griffe-de-drake du héraut
220629	Bague griffe-de-drake du prophète de sang
220630	Bague griffe-de-drake du mastodonte
220632	Médaillon de rituel de sang atal’ai
220633	Insigne de rituel de sang atal’ai
220634	Charme de rituel de sang atal’ai
220635	Rocher enchanté d’Atal’alarion
220636	Icône du sang atal’ai
220637	Jeton de rituel atal’ai
220638	Bâtonnet à maléfice hétérodoxe
220639	Inanimateur de Lledra
220642	Armure de martyr banni en plaques
220643	Garde-jambes de martyr banni en plaques
220648	Bottes de martyr banni en plaques
220649	Héritage de Merithra
220650	Pansière de prophète obsédé
220651	Garde-jambes de prophète obsédé
220652	Bottes ornées de prophète obsédé
220653	Pansière de berserker gémissant
220654	Cuissards de berserker gémissant
220656	Bottes de guerre de berserker gémissant
220657	Haubert de berserker ostracisé
220658	Cuissards de berserker ostracisé
220659	Grèves de berserker ostracisé en anneaux
220660	Haut-de-mailles de fidèle rejeté
220661	Garde-jambes de fidèle rejeté
220662	Bottes de fidèle rejeté en écailles
220663	Jambières de tisse-esprit corrompu
220664	Solerets de tisse-esprit corrompu
220665	Cuirasse de tisse-esprit corrompu
220666	Cotte de mailles de chasseur de l’effroi
220667	Chausses de chasseur de l’effroi
220668	Grèves de chasseur de l’effroi
220669	Pourpoint de prophète exilé
220670	Mules de prophète exilé
220671	Pantalon de prophète exilé en cuir
220672	Harnais d’adorateur perdu
220673	Jambières d’adorateur perdu
220674	Lame furtive dégradée
220675	Bottines d’adorateur perdu
220676	Tunique corrompue par le sang
220677	Bottes corrompues par le sang
220678	Pantalon corrompu par le sang
220679	Jambières de prophète malveillant
220680	Gilet de prophète malveillant
220681	Sandales de prophète malveillant
220682	Rune du débridé
220683	Gilet de prophète bienveillant
220684	Jambières de prophète bienveillant
220685	Sandales de prophète bienveillant
220686	Fléau de chef
220687	Rune du raptor
220688	Mantelet des cauchemars inerte
220689	Protège-bras alimentés par le Vide
220738	Plaques d’épaule d’effroi
220739	Espauliers maléfiques
220740	Garde-épaules d’épouvantement
220741	Espauliers hurlants en anneaux
220742	Spallières hurleuses
220743	Garde-épaules cacophoniques en anneaux
220744	Mantelet gémissant en anneaux
220745	Membrane de sombre névrose
220747	Mantelet de paranoïa
220748	Protège-épaules d’obsession
220749	Mantelet de la démence
220750	Espauliers d’esprit fracturé
220751	Protège-épaules des dérangés
220754	Rune de la tempête de vent
220775	Billet d’échange d’ingénierie
220778	Pantalon coagulé de garde de sang
220779	Tunique coagulée de garde de sang
220780	Bottes coagulées de garde de sang
220781	Jambières de prophète du Cauchemar
220783	Habits de prophète du Cauchemar
220784	Sandales de prophète du Cauchemar
220791	Rune du félin de la jungle
220792	Parchemin de guérison spatiale
220794	Haubert de chevalier en plaques
220795	Espauliers de chevalier-lieutenant en plaques
220796	Espauliers de garde de sang en plaques
220797	Jambières de chevalier en plaques
220798	Jambières du garde de pierre en plaques
220799	Grèves de sergent-major en plaques
220800	Grèves d’adjudant en plaques
220801	Armure du garde de pierre en plaques
220803	Heaume de garde de sang en plaques
220804	Heaume de chevalier-lieutenant en plaques
220806	Gantelets de sergent-major en plaques
220807	Gantelets d’adjudant en plaques
220808	Espauliers imprégnés de chevalier-lieutenant
220809	Jambières imprégnées de chevalier
220810	Casque imprégné de chevalier-lieutenant
220811	Grèves imprégnées de sergent-major
220812	Gantelets imprégnés de sergent-major
220813	Armure imprégnée de chevalier
220814	Bottes lamellaires de sergent-major
220815	Pansière lamellaire de chevalier
220816	Cuissards lamellaires de chevalier
220817	Gantelets lamellaires de sergent-major
220818	Espauliers lamellaires de chevalier-lieutenant
220819	Heaume lamellaire de chevalier-lieutenant
220820	Casque de garde de sang en mailles
220821	Casque de garde de sang en anneaux
220822	Casque de chevalier-lieutenant en anneaux
220823	Épaulettes de garde de sang en mailles
220824	Épaulettes de garde de sang en anneaux
220825	Épaulettes de chevalier-lieutenant en anneaux
220826	Armure du garde de pierre en mailles
220827	Armure du garde de pierre en anneaux
220828	Armure de chevalier en anneaux
220829	Gantelets de sergent-major en anneaux
220830	Gantelets d’adjudant en anneaux
220831	Gantelets d’adjudant en mailles
220832	Cuissards de chevalier en anneaux
220833	Cuissards du garde de pierre en anneaux
220834	Cuissards du garde de pierre en mailles
220835	Solerets d’adjudant en mailles
220836	Solerets d’adjudant en anneaux
220837	Solerets de sergent-major en anneaux
220838	Plastron gravé du garde de pierre
220839	Cuissards gravés du garde de pierre
220840	Solerets gravés d’adjudant
220841	Protège-épaules gravés de garde de sang
220842	Calot gravé de garde de sang
220843	Gantelets gravés d’adjudant
220844	Cuirasse vibrante du garde de pierre
220845	Gantelets vibrants d’adjudant
220846	Grèves vibrantes d’adjudant
220847	Cuissards vibrants du garde de pierre
220848	Casque vibrant de garde de sang
220849	Épaulières vibrantes de garde de sang
220850	Bandeau de chevalier-lieutenant en cuir
220851	Bandeau de garde de sang en cuir
220852	Épaulières de chevalier-lieutenant en cuir
220853	Épaulières de garde de sang en cuir
220854	Armure de chevalier en cuir
220855	Armure du garde de pierre en cuir
220856	Gantelets de sergent-major en cuir
220857	Gantelets d’adjudant en cuir
220858	Pantalon de chevalier en cuir
220859	Pantalon du garde de pierre en cuir
220860	Bottes de sergent-major en cuir
220861	Bottes d’adjudant en cuir
220862	Bottes de sergent-major en cuir crépitant
220863	Bottes d’adjudant en cuir crépitant
220864	Jambières de chevalier en cuir crépitant
220865	Jambières du garde de pierre en cuir crépitant
220866	Gantelets de sergent-major en cuir crépitant
220867	Gantelets d’adjudant en cuir crépitant
220868	Tunique de chevalier en cuir crépitant
220869	Tunique du garde de pierre en cuir crépitant
220870	Spallières de chevalier-lieutenant en cuir crépitant
220871	Spallières de garde de sang en cuir crépitant
220872	Casque de chevalier-lieutenant en cuir crépitant
220873	Casque de garde de sang en cuir crépitant
220874	Heaume de chevalier-lieutenant en cuir restauré
220875	Heaume de garde de sang en cuir restauré
220876	Spallières de chevalier-lieutenant en cuir restauré
220877	Spallières de garde de sang en cuir restauré
220878	Pourpoint de chevalier en cuir restauré
220879	Pourpoint du garde de pierre en cuir restauré
220880	Gants de sergent-major en cuir restauré
220881	Gants d’adjudant en cuir restauré
220882	Jambières de chevalier en cuir restauré
220883	Jambières du garde de pierre en cuir restauré
220884	Bottes de sergent-major en cuir restauré
220885	Bottes d’adjudant en cuir restauré
220886	Gilet de chevalier en tisse-effroi
220887	Mantelet de chevalier-lieutenant en tisse-effroi
220888	Jambières de chevalier en tisse-effroi
220889	Chapeau de chevalier-lieutenant en tisse-effroi
220890	Gants de sergent-major en tisse-effroi
220891	Bottes de sergent-major en tisse-effroi
220892	Armure de chevalier en satin
220893	Jambières de chevalier en satin
220894	Ailettes de chevalier-lieutenant en satin
220895	Bottes de sergent-major en satin
220896	Couvre-chef de chevalier-lieutenant en satin
220897	Gants de sergent-major en satin
220898	Gants d’adjudant en satin
220899	Couvre-chef de garde de sang en satin
220900	Bottes d’adjudant en satin
220901	Ailettes de garde de sang en satin
220902	Jambières du garde de pierre en satin
220903	Armure du garde de pierre en satin
220904	Gilet du garde de pierre en tisse-effroi
220905	Mantelet de garde de sang en tisse-effroi
220906	Jambières du garde de pierre en tisse-effroi
220907	Chapeau de garde de sang en tisse-effroi
220908	Gants d’adjudant en tisse-effroi
220909	Bottes d’adjudant en tisse-effroi
220912	Marteau de la géode
220913	Rune de démolition
220914	Marteau de la géode brisé
220915	Idole du traînard enragé
220916	Corne de stégodon grondeterre
220917	Caisse de teinture écarlate
220918	Fournitures égarées : soupes de palourdes de Terremine
220919	Fournitures égarées : soupes de lutjan nagenuit
220920	Fournitures égarées : steaks de loup tendres
220921	Fournitures égarées : bandages épais en tisse-mage
220922	Fournitures égarées : soleillettes
220923	Fournitures égarées : feuillerêves
220924	Fournitures égarées : barres de vrai-argent
220925	Fournitures égarées : barres de thorium
220926	Fournitures égarées : cuirs robustes
220927	Fournitures égarées : peau épaisse
220928	Fournitures égarées : barres de thorium enchanté
220929	Fournitures égarées : potions de mana excellentes
220930	Fournitures égarées : potions de soins majeures
220931	Fournitures égarées : bombes explosives
220932	Fournitures égarées : grenades en thorium
220933	Fournitures égarées : carabines en thorium
220934	Fournitures égarées : camails en mithril
220935	Fournitures égarées : ceintures en thorium
220936	Fournitures égarées : gantelets en vrai-argent
220937	Fournitures égarées : renforts d’armure robustes
220938	Fournitures égarées : brassards corrompus en cuir
220939	Fournitures égarées : brassards runiques en cuir
220940	Fournitures égarées : bandeaux noirs en tisse-mage
220941	Fournitures égarées : ceintures en étoffe runique
220942	Fournitures égarées : chemises de smoking
220964	Protège-bras alimentés par le Vide déchargés
220965	Bardiche plaiedécaille
221008	Cargaison d’approvisionnement
221009	Cargaison d’approvisionnement
221010	Cargaison d’approvisionnement
221017	Journal de Keldara
221018	Trousse de secours de terrain
221019	Échantillon de satyrienne
221020	Rune de la déesse de la lune
221021	Graine de cauchemardelle
221024	Flasque de cauchemars éternels
221025	Protège-bras d’invocatrice alimentés par le Vide
221026	Protège-bras de tueur alimentés par le Vide
221027	Protège-bras de protecteur alimentés par le Vide
221028	Cachet enchanté : rêves vivants
221030	Mojo de magie interdite atal’ai
221191	Pierre onirique
221192	Journal des rêves
221193	Anneau d’émeraude
221196	Mojo de guerre atal’ai
221199	Teinture de satyrienne
221256	Bras droit de l’Oblitérateur
221257	Bras gauche de l’Oblitérateur
221258	Pied droit de l’Oblitérateur
221259	Pied gauche de l’Oblitérateur
221260	Tête de l’Oblitérateur
221261	Breuvage de murmure sauvage
221262	Offrande sauvage
221267	Rune du sanguinaire
221271	As de Nature
221272	Cartes de Nature
221273	Deux de Nature
221274	Trois de Nature
221275	Quatre de Nature
221276	Cinq de Nature
221277	Six de Nature
221278	Sept de Nature
221279	Huit de Nature
221280	Cartes de Plaies
221281	As de Plaies
221282	Deux de Plaies
221283	Trois de Plaies
221284	Quatre de Plaies
221285	Cinq de Plaies
221286	Six de Plaies
221287	Sept de Plaies
221288	Huit de Plaies
221289	Cartes de Dunes
221290	As de Dunes
221291	Deux de Dunes
221292	Trois de Dunes
221293	Quatre de Dunes
221294	Cinq de Dunes
221295	Six de Dunes
221296	Sept de Dunes
221297	Huit de Dunes
221298	As de Cauchemar
221299	Cartes de Cauchemar
221300	Deux de Cauchemar
221301	Trois de Cauchemar
221302	Quatre de Cauchemar
221303	Cinq de Cauchemar
221304	Six de Cauchemar
221305	Sept de Cauchemar
221306	Huit de Cauchemar
221307	Carte de Sombrelune : Décomposition
221308	Carte de Sombrelune : Surcroissance
221309	Carte de Sombrelune : Tempête de sable
221310	Carte de Sombrelune : Tourment
221311	Mojo de vie atal’ai
221312	Flacon de mojo atal’ai
221313	Flacon de mojo cauchemardesque
221314	Avis de recherche
221315	Générateur d’arc-en-ciel
221316	Uniforme exigeant de Premo
221317	Cristaux telluriques de Feralas
221318	Cristaux telluriques d’Azshara
221319	Cristaux telluriques de Blackrock
221320	Cristaux telluriques des Hinterlands
221321	Signet de puissance atal’ai
221322	Signet de mojo atal’ai
221323	Signet de sérénité atal’ai
221324	Clé ombreforge fragile
221325	Charge explosive Desctructop
221326	Cœur de cerf sacré
221327	Schéma : Rayon réducteur gnome
221328	Schéma : Lunettes gnomes
221329	Schéma : Lance-filet automatique gnome
221330	Schéma : Ceinture de prévention gnome
221331	Schéma : Bottes-fusées gobelines
221332	Schéma : Coq de combat gnome
221333	Schéma : Coiffe de contrôle mental gnome
221334	Schéma : Rayon mortel gnome
221335	Schéma : Casque de chantier gobelin
221336	Schéma : Casque de mineur gobelin
221337	Schéma : Mortier gobelin
221338	Schéma : Charge de sapeur gobelin
221339	Schéma : Bottes-fusées gobelines
221340	Schéma : Distributeur de bombes gobelines
221341	Schéma : Le Mastoc
221342	Schéma : Fusil à dragon gobelin
221343	Schéma : Casque-fusées gobelin
221344	Grimoire personnel
221345	Sang corrompu d’Eranikus
221346	Scapula de l’avatar déchu
221347	Sapta de feu trouble
221348	Sapta d’eau trouble
221349	Sapta de terre trouble
221350	Notes de chaman brûlées
221351	Notes de chaman trempées
221352	Notes de chaman barbouillées
221353	Fragment de feu
221354	Fragment d’eau
221355	Fragment de terre
221356	Fragment de feu luminescent
221357	Fragment d’eau luminescent
221358	Fragment de terre luminescent
221359	Plume de chouettard en parfait état
221360	Papyrus farraki
221361	Résine de Zukk’ash
221362	Chiffon de nettoyage d’armes
221363	Scapula de l’avatar déchu
221364	Pièce du massacre en cuivre
221365	Pièce du massacre en argent
221366	Pièce du massacre en or
221367	Sacoche de pièces du massacre en cuivre
221368	Sacoche de pièces du massacre en argent
221369	Siphon cauchemardesque
221370	Médaillon précieux
221371	Bourse de kidnappeur
221372	Bourse abîmée
221374	Angoisse du Rêve
221376	Heaume du Rêve d’émeraude
221377	Cuissards du Rêve d’émeraude
221378	Gantelets du Rêve d’émeraude
221379	Solerets du Rêve d’émeraude
221380	Cuirasse du Rêve d’émeraude
221381	Espauliers du Rêve d’émeraude
221382	Harnois de bataille incrusté émeraude
221383	Garde-mains incrustés émeraude
221384	Casque incrusté émeraude
221385	Cuissards incrustés émeraude
221386	Spallières incrustées émeraude
221387	Bottes en plaques incrustées émeraude
221388	Jambières en écailles émeraude
221389	Gantelets en écailles émeraude
221390	Cuirasse en écailles émeraude
221391	Casque en écailles émeraude
221392	Épaulières en écailles émeraude
221393	Bottes en écailles émeraude
221394	Bottes lestées émeraude
221395	Cuirasse lestée émeraude
221396	Gantelets lestés émeraude
221397	Casque lesté émeraude
221398	Jambières lestées émeraude
221399	Épaulières lestées émeraude
221400	Épaulières en anneaux émeraude
221401	Jambières en anneaux émeraude
221402	Casque en anneaux émeraude
221403	Gantelets en anneaux émeraude
221404	Cuirasse en anneaux émeraude
221405	Bottes en anneaux émeraude
221406	Gilet en cuir émeraude
221407	Gants en cuir émeraude
221408	Heaume en cuir émeraude
221409	Solerets en cuir émeraude
221410	Pantalon en cuir émeraude
221411	Épaulières en cuir émeraude
221412	Gants de Garde-rêve émeraude
221413	Heaume de Garde-rêve émeraude
221414	Pantalon de Garde-rêve émeraude
221415	Bottes de Garde-rêve émeraude
221416	Épaulières de Garde-rêve émeraude
221417	Torse de Garde-rêve émeraude
221418	Rugissement d’agamaggan
221419	Gilet du guetteur émeraude
221420	Bottes du guetteur émeraude
221421	Gants du guetteur émeraude
221422	Casque du guetteur émeraude
221423	Jambières du guetteur émeraude
221424	Épaulières du guetteur émeraude
221425	Diadème enchanté émeraude
221426	Bottes enchantées émeraude
221427	Gants enchantés émeraude
221428	Rune de Coup bas
221429	Pantalon enchanté émeraude
221430	Robe enchantée émeraude
221431	Épaulières enchantées émeraude
221432	Mantelet tissé émeraude
221433	Rune de focalisation
221434	Robe tissée émeraude
221435	Pantalon tissé émeraude
221436	Gants tissés émeraude
221437	Diadème tissé émeraude
221438	Bottes tissées émeraude
221439	Armure du sommeil d’émeraude
221440	Rugissement du Rêve
221441	Gardienne du Rêve
221442	Rugissement du Gardien
221443	Rugissement du bosquet
221444	Durian de la jungle
221445	Rune de feu focalisé
221446	Marteau de ritualiste
221447	Grimoire de ritualiste de Lune sanguine
221448	Talisman du bosquet corrompu
221450	Arc de combattant de la fosse gurubashi
221451	Arbalète assoiffée de sang
221452	Bague arcanique focusanguine
221453	Bague de sang frémissant
221454	Bague de sang glaciaire
221455	Révérence de lumière sanglante
221456	Sabre de l’éclipse sanguin
221457	Libram de destruction draconienne
221458	Bague de victoire ténébreuse
221459	Sceau des sacrifiés
221460	Traître gurubashi
221461	Rune de carnage
221462	Épée de vitesse ensanglantée
221463	Poupée vaudou antique
221464	Totem de précision ardente
221465	Porte-choc corrompu
221466	Jonc de sang ardent
221467	Œil de la lune sanguine
221468	Mur de murmures
221469	Lance barbelée de chasseur de têtes
221470	Émeraude de rêve
221471	Coffre des gardiens d’émeraude
221473	Rune du guetteur
221474	Essence d’Eranikus enchaînée
221475	Essence d’Eranikus
221480	Notes de sort : Armure de la fournaise
221481	Épiphanie nihiliste
221482	Rune d’affliction
221483	Rune de brûlure
221484	Bâton de maléfice de féticheur
221487	Notes de sort : Protection avancée
221488	Épiphanie résolue
221489	Rune de vengeance
221490	Rune de remous
221491	Sac crocs-d’ombre
221497	Vieille clé
221498	Solide boîte à repas
221499	Rune du gangregarde
221510	Rune du chevalier
221511	Rune du protecteur
221512	Rune d’empressement
221513	Rune de puissance
221514	Rune de maîtrise du Feu
221515	Rune de détonation
221516	Rune d’énergie primale
221517	Rune de l’effusion de sang
221518	Murmure
221519	Orbe de Mannoroc
221544	Œuf du corbeau des tempêtes
221545	Notes de démoniste décodées
221547	Notes de démoniste codées
221549	Formule Bat-le-désert
221780	Sceptre de la princesse Theradras
221781	Heaume de l’avant-garde
221782	Heaume d’exil
221783	Spallières judiciaires
221785	Habit cénarien
221971	Corne du serment onirique
221972	Feu pyronirique
221973	Croc de Chasse-rêves
221974	Collier Totem-sinistre
221975	Bâton Griffebois brisé
221976	Bâton de nature malade
221978	Âme d’explorateur
221979	Prophétie de l’hiver verdoyant
221980	Prophétie du chaos éveillé
221981	Prophétie de la tribu perdue
222952	Flacon des rêves troublés
222962	Sagesse d’Hyjal
223073	Épaulettes de chevalier-lieutenant en mailles
223074	Cuissards de chevalier en mailles
223075	Casque de chevalier-lieutenant en mailles
223076	Gantelets de sergent-major en mailles
223077	Solerets de sergent-major en mailles
223078	Armure de chevalier en mailles
223147	Notes de sort : Trait de bûcher
223148	Trésor venu d’ailleurs
223149	Trésor venu d’ailleurs
223150	Trésor venu d’ailleurs
223151	Trésor venu d’ailleurs
223160	Buisson des affaires
223161	Caisse de fournitures vide
223162	Havresac de livraison pratique
223163	Formule : parchemin de guérison spatiale
223164	Capuche de curiosité
223167	Coiffe d’initiative
223168	Fragment du noyau du monde
223169	Coiffe de ténacité
223171	Parchemin de géomancie
223172	Anneaux de ténacité
223173	Corde de géomancien
223174	Bottes de géomancien
223175	Cape de géomancien
223177	Bandeau de géomancien
223178	Brassards de géomancien
223180	Gants de géomancien
223181	Spallières de géomancien
223182	Chausses de géomancien
223183	Cafetan de géomancien
223186	Facilitateur de ravitaillement
223192	Corde de l’indompté
223193	Couronne du tisse-rêves
223194	Bague des étendues sauvages
223195	Ampleur de la bête
223196	Grèves de déicide
223197	Défenseur des étendues sauvages
223198	Modas Karkun
223214	Zila Gular
223215	Orah Raka
223216	Rakkan Archim
223217	Rakkas Lek
223218	Tor Kieldaz
223219	Protège-poignets en gangrétoffe
223221	Protège-poignets en gangrecuir
223222	Protège-poignets en gangremailles
223237	Protège-épaules en gangrétoffe
223238	Protège-épaules en gangrecuir
223239	Épaulières en gangremaille
223240	Chaperon en gangrétoffe
223241	Chapeau en gangrecuir
223242	Camail en gangremailles
223248	Jambières en gangrétoffe
223249	Jambières en gangrecuir
223250	Jambières en gangremailles
223251	Jambières en gangreplaques
223256	Robe en gangrétoffe
223261	Plastron en gangrecuir
223262	Plastron en gangremaille
223263	Plastron en gangreplaque
223283	Recommandation tachée de sang
223288	Rune du marteau
223323	Chemise
223324	Jambières de cavalier de la pluie
223325	Cuirasse hakkari
223326	Voile hakkari
223327	Marque d’Hakkar
223328	Diadème suprême
223329	Miséricorde de force vitale
223330	Œil palpitant
223331	Œil palpitant
223332	Œil vibrant
223333	Œil torve
223334	Œil luminescent
223335	Œil suintant
223336	Œil perçant
223337	Œil brûlant
223518	Miséricorde de calcinite
223519	Œil de Theradras
223520	Epée focale d’inventeur
223521	Mantelet de Grippe-charogne
223522	Heaume de la montagne
223523	Pierre des nuages
223524	Poing de pierre
223525	Coiffure de devin
223526	Sul’thraze la Flagellante
223527	Croc de Gahz’rilla
223528	Broigne de Gahz’rilla
223529	Peau porte-guigne
223530	Kilt porte-guigne
223531	Grands méchants espauliers
223532	Amulette sang-de-vie
223533	Canne du marcheur du désert
223534	Poignes de Jumanza
223535	Habit tribal de Grimelok
223536	Devoir de Grimelok
223537	Brassards du crâne en plaques
223538	Bâton d’embrasement
223539	Sphère des Exaltés
223540	Arc de maître-chien
223541	Cœur d’éclat de gemme
223542	Carabine mégatir
223543	Sandales de Vinerot
223544	Spallières en drégénite
223545	Targe hypertech de Kadenaz
223648	Flèche imprégnée de rêve
223912	Potion de purification
223913	Potion de soins majeure
223914	Potion de soins supérieure
223962	Guêtres de traqueuse des sables
223963	Étreinte du lycan
223964	Lame des ténèbres éternelles
223980	Jambières ardentes
223981	Robe de marcheur des flammes
223982	Carabine de maître-chien
223983	Lame de médiateur
223984	Gants arachnéens
223985	Bague cyclopéenne
223986	Cape de la tombe putride
223987	Épaulières de peau éclissée
224004	Anneau d’émeraude
224005	Anneau d’émeraude
224006	Anneau d’émeraude
224122	Mangeur de rêves
224279	Terrestris
224280	Suzerain, défenseur des Vols draconiques
224281	Gla’sir
224282	Rae’lar
224409	Cogneur du serpent
224806	Harmonisateur de portail de la Légion
224836	Trésor venu d’ailleurs
224848	Trésor venu d’ailleurs
224849	Trésor venu d’ailleurs
224850	Trésor venu d’ailleurs
224851	Trésor venu d’ailleurs
224893	Harmonisateur de portail surchargé
224912	Harmonisateur d’harmonisateur de portail
225675	Noyau d’obsidienne couvert de suie
225676	Noyau d’obsidienne en fusion
225686	Rune de Décimation
225687	Rune d’Armure infernale
225688	Rune de Marque du chaos
225689	Notes de sort : Barrage des arcanes
225690	Notes de sort : Orbe gelé
225691	Notes de sort : Surchauffe
225740	Rune de constance
225838	Icône voltaïque
225893	Fin d’une époque
225914	Rune d’esprit lié
225929	Fragment d’âme pestiférée
225938	Notes de sort déchirées
225939	Notes de sort déchirées
225940	Notes de sort déchirées
225941	Notes de sort déchirées
225942	Viande de sanglier contaminée
225943	Morceau de chair rance
225954	Notes de sort calcinées
225955	Rune d’ingéniosité
226122	Corne de Dalton
226201	Épée de l’écuyer Cuthbert
226207	Écho d’Anastari
226208	Écho de Barthilas
226209	Écho de Dathrohan
226210	Écho de Maleki
226211	Écho de Nerub’enkan
226212	Écho d’Ymiron
226213	Écho de Vaillefendre
226214	Écho de Willey
226252	Rune de guérilla
226374	Poison occulte I
226394	Manuel de Poison atrophiant
226395	Manuel de Poison ankylosant
226396	Manuel de Poison occulte
226397	Manuel de Poison sébacé
226401	Traité sur Cœur de lion
226402	Révélation de Rage du chaman
226403	Recueil : Crochet à viande
226404	Réal de Terremine terni
226405	Caisse de fournitures de Terremine endommagée
226406	Rune de Spécialisation Épée
226407	Rune de Spécialisation Hache
226408	Rune de Spécialisation Masse
226409	Rune de Spécialisation Dague
226410	Rune de Spécialisation Armes à distance
226411	Rune de Spécialisation Armes de pugilat
226412	Rune de Spécialisation Armes d’hast
226413	Rune de Spécialisation Arcanes
226414	Rune de Spécialisation Feu
226415	Rune de Spécialisation Givre
226416	Rune de Spécialisation Nature
226417	Rune de Spécialisation Ombre
226418	Rune de Spécialisation Sacré
226419	Rune de Spécialisation Combat farouche
226420	Buste finement sculpté
226421	PLACEHOLDER_ASHBRINGER_QUESTITEM_01
226440	Ceinture du tueur de la nuit
226441	Gants du tueur de la nuit
226442	Bracelets du tueur de la nuit
226443	Bottes du tueur de la nuit
226444	Protège-épaules du tueur de la nuit
226445	Pantalon du tueur de la nuit
226446	Couvre-chef du tueur de la nuit
226447	Plastron du tueur de la nuit
226472	Bocal d’ombres de Stratholme
226473	Thorax du tueur de la nuit
226474	Sangle du tueur de la nuit
226475	Garde-mains du tueur de la nuit
226476	Brassards du tueur de la nuit
226477	Tabi du tueur de la nuit
226478	Espauliers du tueur de la nuit
226479	Garde-jambes du tueur de la nuit
226480	Capuche du tueur de la nuit
226484	Brassards de puissance
226485	Ceinture de puissance
226486	Gantelets de puissance
226487	Solerets de puissance
226488	Heaume de puissance
226489	Cuirasse de puissance
226490	Cuissards de puissance
226491	Plaques d’épaule de puissance
226492	Espauliers de puissance
226493	Jambières de puissance
226494	Haubert de puissance
226495	Mâchoires de puissance
226496	Bottines de puissance
226497	Mains de puissance
226498	Écharpe de puissance
226499	Garde-bras de puissance
226500	Amulette drakefeu ébréchée
226523	Corne de Dalton
226526	Gadget cassé
226527	Épaulettes de traqueur de géant
226528	Gants de traqueur de géant
226529	Ceinture de traqueur de géant
226530	Brassards de traqueur de géant
226531	Bottes de traqueur de géant
226532	Jambières de traqueur de géant
226533	Casque de traqueur de géant
226534	Cuirasse de traqueur de géant
226535	Cotte de mailles de traqueur de géant
226536	Semblance de traqueur de géant
226537	Jambières de traqueur de géant en anneaux
226538	Solerets de traqueur de géant
226540	Garde-mains de traqueur de géant
226541	Garde-poignets de traqueur de géant
226542	Ceinturon de traqueur de géant
226543	Espauliers de traqueur de géant
226545	Corne de Dalton
226546	Sonar du désert
226547	Pantalon de Gangrecœur
226548	Robe de Gangrecœur
226549	Cornes de Gangrecœur
226550	Protège-épaules de Gangrecœur
226551	Ceinture de Gangrecœur
226552	Gants de Gangrecœur
226553	Brassards de Gangrecœur
226554	Mules de Gangrecœur
226555	Ceinture d’arcaniste
226556	Gants d’arcaniste
226557	Bottes d’arcaniste
226558	Manchettes d’arcaniste
226559	Robe d’arcaniste
226560	Mantelet d’arcaniste
226561	Jambières d’arcaniste
226562	Couronne d’arcaniste
226563	Vêtement d’arcaniste
226564	Coiffure d’arcaniste
226565	Pantalon d’arcaniste
226566	Épaulières d’arcaniste
226567	Bandelettes d’arcaniste
226568	Sandales d’arcaniste
226569	Garde-mains d’arcaniste
226570	Corde d’arcaniste
226571	Bottes de prophétie
226572	Gants de prophétie
226573	Collerette de prophétie
226574	Pantalon de prophétie
226575	Robe de prophétie
226576	Mantelet de prophétie
226577	Ceinturon de prophétie
226578	Protège-bras de prophétie
226579	Bandelettes de prophétie
226580	Ceinture de prophétie
226581	Protège-épaules de prophétie
226582	Vêtement de prophétie
226583	Jambières de prophétie
226584	Couronne de prophétie
226585	Mains de prophétie
226586	Sandales de prophétie
226587	Rune de bombardement
226588	Spallières judiciaires
226589	Brassards judiciaires
226590	Heaume judiciaire
226591	Gantelets judiciaires
226592	Ceinture judiciaire
226593	Bottes judiciaires
226594	Cuissards judiciaires
226595	Corselet judiciaire
226596	Poignets de guerre judiciaires
226597	Ceinturon judiciaires
226598	Jambières judiciaires
226599	Couronne judiciaire
226600	Poignes judiciaires
226601	Bottes de guerre judiciaires
226602	Cuirasse judiciaire
226603	Protège-bras judiciaires
226604	Ceinture de bataille judiciaire
226605	Espauliers judiciaires
226606	Garde-jambes judiciaires
226607	Protège-front judiciaire
226608	Garde-mains judiciaires
226609	Solerets judiciaires
226610	Pansière judiciaire
226611	Épaulettes Rageterre
226612	Casque Rageterre
226613	Bottes Rageterre
226614	Garde-jambes Rageterre
226615	Gantelets Rageterre
226616	Ceinture Rageterre
226617	Habit Rageterre
226618	Brassards Rageterre
226619	Cotte de mailles annelée Rageterre
226620	Brodequins Rageterre
226621	Mains Rageterre
226622	Visière Rageterre
226623	Jambières Rageterre
226624	Mantelet Rageterre
226625	Corde Rageterre
226626	Protège-poignets Rageterre
226627	Cotte d’écailles Rageterre
226628	Solerets Rageterre
226629	Garde-mains Rageterre
226630	Grand heaume Rageterre
226631	Jambières Rageterre en écailles
226632	Espauliers Rageterre
226633	Sangle Rageterre
226634	Garde-poignets Rageterre
226635	Cotte de mailles Rageterre
226636	Bottes de guerre Rageterre
226637	Poignes Rageterre
226638	Chapel Rageterre
226639	Jambières Rageterre en anneaux
226640	Épaulettes Rageterre
226641	Ceinturon Rageterre
226642	Manchettes Rageterre
226644	Spallières cénariennes
226645	Bottes cénariennes
226646	Jambières cénariennes
226647	Casque cénarien
226648	Gants cénariens
226649	Brassards cénariens
226650	Ceinture cénarienne
226651	Pantalon cénarien
226652	Sandales cénariennes
226653	Mantelet cénarien
226654	Gantelets cénariens
226655	Poignées cénariennes
226656	Étreinte cénarienne
226657	Corde cénarienne
226658	Bois cénariens
226659	Cornes cénariennes
226660	Ceinturon cénarien
226661	Tunique cénarienne
226662	Poignets cénariens
226663	Bottines cénariennes
226664	Poings cénariens
226665	Épaulières cénariennes
226666	Chausses cénariennes
226667	Sangle cénarienne
226668	Garde-poignets cénariens
226669	Poignes cénariennes
226670	Couronne cénarienne
226671	Garde-jambes cénariens
226673	Brodequins cénariens
226674	Espauliers cénariens
226675	Armure cénarienne
226678	Prémonition et Prévoyance du combat
226679	Intuition du vagabond intemporel
226680	Rune du premier guerrier
226694	Rune de Spécialisation Défense
226698	Bougies à disposition verticales
226699	Pan de protection thermique en airain
226700	Tunique Sombreruse
226701	Ceinture Sombreruse
226702	Gants Sombreruse
226703	Bottes Sombreruse
226704	Brassards Sombreruse
226705	Pantalon Sombreruse
226706	Spallières Sombreruse
226707	Cagoule Sombreruse
226708	Capuche du Cœur-sauvage
226709	Kilt du Cœur-sauvage
226710	Spallières du Cœur-sauvage
226711	Gants du Cœur-sauvage
226712	Ceinture du Cœur-sauvage
226713	Bottes du Cœur-sauvage
226714	Brassards du Cœur-sauvage
226715	Gilet du Cœur-sauvage
226716	Mantelet de bestiaire
226717	Manchettes de bestiaire
226718	Ceinture de bestiaire
226719	Pantalon de bestiaire
226720	Coiffe de bestiaire
226721	Gants de bestiaire
226722	Bottes de bestiaire
226723	Tunique de bestiaire
226724	Ceinture de magistère
226725	Manchettes de magistère
226726	Mantelet de magistère
226727	Jambières de magistère
226728	Couronne de magistère
226729	Robe de magistère
226730	Bottes de magistère
226731	Gants de magistère
226732	Ceinture de Sancteforge
226733	Casque de Sancteforge
226734	Cuirasse de Sancteforge
226735	Spallières de Sancteforge
226736	Cuissards de Sancteforge
226737	Gantelets de Sancteforge
226738	Bottes de Sancteforge
226739	Brassards de Sancteforge
226740	Gants de dévot
226741	Mantelet de dévot
226742	Brassards de dévot
226743	Sandales de dévot
226744	Ceinture de dévot
226745	Robe de dévot
226746	Couronne de dévot
226747	Jupe de dévot
226748	Gantelets des éléments
226749	Haubergeon des éléments
226750	Kilt des éléments
226751	Manchettes des éléments
226752	Bottes des éléments
226753	Espauliers des éléments
226754	Corde des éléments
226755	Coiffe des éléments
226756	Mantelet de Brume-funeste
226757	Robe de Brume-funeste
226758	Protège-mains de Brume-funeste
226759	Brassards de Brume-funeste
226760	Jambières de Brume-funeste
226761	Ceinture de Brume-funeste
226762	Masque de Brume-funeste
226763	Sandales de Brume-funeste
226764	Bottes de vaillance
226765	Ceinture de vaillance
226766	Brassards de vaillance
226767	Cuissards de vaillance
226768	Spallières de vaillance
226769	Casque de vaillance
226770	Cuirasse de vaillance
226771	Gantelets de vaillance
226772	Écharpe Cœur-Farouche
226773	Capuche Cœur-Farouche
226774	Galoches Cœur-Farouche
226775	Couvre-bras Cœur-Farouche
226776	Gilet Cœur-Farouche
226777	Mains Cœur-Farouche
226778	Spallières Cœur-Farouche
226779	Kilt Cœur-Farouche
226780	Corde Cœur-Farouche
226781	Sandales Cœur-Farouche
226782	Manchettes Cœur-Farouche
226783	Étreinte Cœur-Farouche
226784	Gantelets Cœur-Farouche
226785	Mantelet Cœur-Farouche
226786	Coiffure Cœur-Farouche
226787	Pantalon Cœur-Farouche
226788	Poignets Cœur-Farouche
226789	Ceinturon Cœur-Farouche
226790	Épaulettes Cœur-Farouche
226791	Chausses Cœur-Farouche
226792	Coiffe Cœur-Farouche
226793	Poings Cœur-Farouche
226794	Brodequins Cœur-Farouche
226795	Tunique Cœur-Farouche
226796	Garde-poignets Cœur-Farouche
226797	Sangle Cœur-Farouche
226798	Espauliers Cœur-Farouche
226799	Garde-jambes Cœur-Farouche
226801	Ventaille Cœur-Farouche
226802	Poignes Cœur-Farouche
226803	Bottines Cœur-Farouche
226804	Armure Cœur-Farouche
226815	Poignées Cœur-Farouche
226816	Ceinture Cœur-Farouche
226817	Épaulières Cœur-Farouche
226818	Jambières Cœur-Farouche
226819	Casque Cœur-Farouche
226820	Gants Cœur-Farouche
226821	Bottes Cœur-Farouche
226822	Plastron Cœur-Farouche
226825	Tunique Sombremante
226826	Spallières Sombremante
226827	Pantalon Sombremante
226828	Poignes Sombremante
226829	Coiffe Sombremante
226830	Brassards Sombremante
226831	Souliers Sombremante
226832	Ceinture Sombremante
226835	Garde-poignets Sombremante
226836	Sangle Sombremante
226837	Espauliers Sombremante
226838	Garde-jambes Sombremante
226840	Garde-mains Sombremante
226841	Ventaille Sombremante
226842	Bottines Sombremante
226843	Armure Sombremante
226845	Poignets Sombremante
226846	Ceinturon Sombremante
226847	Épaulières Sombremante
226848	Jambières Sombremante
226849	Casque Sombremante
226850	Gants Sombremante
226851	Bottes Sombremante
226852	Plastron Sombremante
226856	Accélérateur de flottaison guidée
226857	Bottes de guerre d’héroïsme
226858	Spallières d’héroïsme
226859	Cuissards d’héroïsme
226860	Couronne d’héroïsme
226861	Gantelets d’héroïsme
226862	Cuirasse d’héroïsme
226863	Brassards d’héroïsme
226864	Ceinture d’héroïsme
226865	Garde-poignets d’héroïsme
226866	Sangle d’héroïsme
226867	Espauliers d’héroïsme
226868	Garde-jambes d’héroïsme
226869	Ventaille d’héroïsme
226870	Garde-mains d’héroïsme
226871	Solerets d’héroïsme
226872	Corselet d’héroïsme
226873	Poignets d’héroïsme
226874	Taille d’héroïsme
226875	Épaules d’héroïsme
226876	Jambes d’héroïsme
226877	Heaume d’héroïsme
226878	Gants d’héroïsme
226879	Bottes d’héroïsme
226880	Torse d’héroïsme
226881	Bottines de belluaire
226882	Pantalon de belluaire
226883	Gantelets de belluaire
226884	Mantelet de belluaire
226885	Manchettes de belluaire
226886	Tunique de belluaire
226887	Coiffe de belluaire
226888	Ceinture de belluaire
226889	Brassards de belluaire
226890	Baudrier de belluaire
226891	Espauliers de belluaire
226892	Jambières de belluaire
226893	Camail de belluaire
226894	Poignets de belluaire
226895	Grèves de belluaire
226896	Chaîne de belluaire
226897	Poignets de belluaire
226898	Taille de belluaire
226899	Épaules de belluaire
226900	Jambes de belluaire
226901	Heaume de belluaire
226902	Gants de belluaire
226903	Bottes de belluaire
226904	Torse de belluaire
226905	Ceinture Mortebrume
226906	Robe Mortebrume
226907	Brassards Mortebrume
226908	Sandales Mortebrume
226909	Masque Mortebrume
226910	Jambières Mortebrume
226911	Protège-mains Mortebrume
226912	Mantelet Mortebrume
226913	Manchettes Mortebrume
226914	Corde Mortebrume
226915	Épaulettes Mortebrume
226916	Pantalon Mortebrume
226917	Chaperon Mortebrume
226918	Poignes Mortebrume
226919	Bottines Mortebrume
226920	Étreinte Mortebrume
226921	Poignets Mortebrume
226922	Taille Mortebrume
226923	Épaules Mortebrume
226924	Jambes Mortebrume
226925	Heaume Mortebrume
226926	Gants Mortebrume
226927	Bottes Mortebrume
226928	Torse Mortebrume
226929	Manchettes du sorcier
226930	Gantelets du sorcier
226931	Sandales du sorcier
226932	Robe du sorcier
226933	Jambières du sorcier
226934	Ceinture du sorcier
226935	Couronne du sorcier
226936	Mantelet du sorcier
226937	Poignets du sorcier
226938	Taille du sorcier
226939	Épaules du sorcier
226940	Jambes du sorcier
226941	Heaume du sorcier
226942	Gants du sorcier
226943	Bottes du sorcier
226944	Torse du sorcier
226945	Robe vertueuse
226946	Jupe vertueuse
226947	Couronne vertueuse
226948	Ceinture vertueuse
226949	Brassards vertueux
226950	Mitaines vertueuses
226951	Mantelet vertueux
226952	Sandales vertueuses
226953	Couvre-bras vertueux
226954	Corde vertueuse
226955	Épaulettes vertueuses
226956	Jambières vertueuses
226957	Capuche vertueuse
226958	Mains vertueuses
226959	Mules vertueuses
226960	Robe vertueuse
226961	Poignets vertueux
226962	Taille vertueuse
226963	Épaules vertueuses
226964	Jambes vertueuses
226965	Heaume vertueux
226966	Gants vertueux
226967	Bottes vertueuses
226968	Torse vertueux
226969	Spallières d’Âmeforge
226970	Brassards d’Âmeforge
226971	Ceinture d’Âmeforge
226972	Cuissards d’Âmeforge
226973	Cuirasse d’Âmeforge
226974	Bottes de guerre d’Âmeforge
226975	Gantelets d’Âmeforge
226976	Grand heaume d’Âmeforge
226977	Manchettes d’Âmeforge
226978	Corde d’Âmeforge
226979	Épaulettes d’Âmeforge
226980	Jambières d’Âmeforge
226981	Couronne d’Âmeforge
226982	Poings d’Âmeforge
226983	Bottines d’Âmeforge
226984	Étreinte d’Âmeforge
226985	Garde-poignets d’Âmeforge
226986	Sangle d’Âmeforge
226987	Espauliers d’Âmeforge
226988	Garde-jambes d’Âmeforge
226989	Ventaille d’Âmeforge
226990	Garde-mains d’Âmeforge
226991	Solerets d’Âmeforge
226992	Corselet d’Âmeforge
226993	Poignets d’Âmeforge
226994	Taille d’Âmeforge
226995	Épaules d’Âmeforge
226996	Jambes d’Âmeforge
226997	Heaume d’Âmeforge
226998	Gants d’Âmeforge
226999	Bottes d’Âmeforge
227000	Torse d’Âmeforge
227001	Manchettes des Cinq tonnerres
227002	Coiffe des Cinq tonnerres
227003	Espauliers des Cinq tonnerres
227004	Gilet des Cinq tonnerres
227005	Kilt des Cinq tonnerres
227006	Gantelets des Cinq tonnerres
227007	Mules des Cinq tonnerres
227008	Corde des Cinq tonnerres
227009	Brassards des Cinq tonnerres
227010	Écharpe des Cinq tonnerres
227011	Mantelet des Cinq tonnerres
227012	Jambières des Cinq tonnerres
227013	Couronne des Cinq tonnerres
227014	Emprise des Cinq tonnerres
227015	Grèves des Cinq tonnerres
227016	Tunique des Cinq tonnerres
227017	Poignets des Cinq tonnerres
227018	Ceinturon des Cinq tonnerres
227019	Spallières des Cinq tonnerres
227020	Cuissards des Cinq tonnerres
227021	Visage des Cinq tonnerres
227022	Poings des Cinq tonnerres
227023	Bottines des Cinq tonnerres
227024	Anneaux des Cinq tonnerres
227025	Garde-poignets des Cinq tonnerres
227026	Sangle des Cinq tonnerres
227027	Garde-épaules des Cinq tonnerres
227028	Garde-jambes des Cinq tonnerres
227029	Coiffure des Cinq tonnerres
227030	Garde-mains des Cinq tonnerres
227031	Solerets des Cinq tonnerres
227032	Corselet des Cinq tonnerres
227033	Poignets des Cinq tonnerres
227034	Taille des Cinq tonnerres
227035	Épaules des cinq tonnerres
227036	Jambes des Cinq tonnerres
227037	Heaume des Cinq tonnerres
227038	Gants des Cinq tonnerres
227039	Bottes des Cinq tonnerres
227040	Torse des Cinq tonnerres
227041	Scalpel d’ombre du Fléau
227042	Épaulières de champion en plaques
227043	Casque de champion en plaques
227044	Heaume de lieutenant-commandant en plaques
227045	Épaulières de lieutenant-commandant en plaques
227046	Haubert de chevalier-capitaine en plaques
227047	Jambières de chevalier-capitaine en plaques
227048	Jambières de légionnaire en plaques
227049	Haubert de légionnaire en plaques
227050	Gantelets de garde de sang en plaques
227051	Grèves de garde de sang en plaques
227052	Grèves de chevalier-lieutenant en plaques
227053	Gantelets de chevalier-lieutenant en plaques
227054	Épaulières de lieutenant-commandant en cuir
227055	Casque de lieutenant-commandant en cuir
227056	Épaulières de champion en cuir
227057	Heaume de champion en cuir
227058	Plastron de chevalier-capitaine en cuir
227059	Garde-jambes de légionnaire en cuir
227060	Plastron de légionnaire en cuir
227061	Garde-jambes de chevalier-capitaine en cuir
227062	Brodequins de garde de sang en cuir
227063	Poignes de garde de sang en cuir
227064	Brodequins de chevalier-lieutenant en cuir
227065	Poignes de chevalier-lieutenant en cuir
227066	Heaume de lieutenant-commandant en anneaux
227067	Casque de champion en anneaux
227068	Épaulières de lieutenant-commandant en anneaux
227069	Épaulières de champion en anneaux
227070	Haubert de chevalier-capitaine en anneaux
227071	Haubert de légionnaire en anneaux
227072	Garde-jambes de chevalier-capitaine en anneaux
227073	Garde-jambes de légionnaire en anneaux
227074	Grèves de garde de sang en anneaux
227075	Cestes de garde de sang en anneaux
227076	Grèves de chevalier-lieutenant en anneaux
227077	Cestes de chevalier-lieutenant en anneaux
227078	Espauliers de champion en anneaux
227079	Cuissards de légionnaire en anneaux
227080	Grand heaume de champion en anneaux
227081	Poignes de garde de sang en anneaux
227082	Gantelets de garde de sang en anneaux
227083	Armure de légionnaire en anneaux
227084	Espauliers de lieutenant-commandant en anneaux
227085	Cuissards de chevalier-capitaine en anneaux
227086	Grand heaume de lieutenant-commandant en anneaux
227087	Poignes de chevalier-lieutenant en anneaux
227088	Solerets de chevalier-lieutenant en anneaux
227089	Armure de chevalier-capitaine en anneaux
227090	Capuche de champion en tisse-effroi
227091	Spallières de lieutenant-commandant en tisse-effroi
227092	Spallières de champion en tisse-effroi
227093	Capuche de lieutenant-commandant en tisse-effroi
227094	Tunique de légionnaire en tisse-effroi
227095	Garde-jambes de chevalier-capitaine en tisse-effroi
227096	Tunique de chevalier-capitaine en tisse-effroi
227097	Garde-jambes de légionnaire en tisse-effroi
227098	Brodequins de garde de sang en tisse-effroi
227099	Protège-mains de garde de sang en tisse-effroi
227100	Protège-mains de chevalier-lieutenant en tisse-effroi
227101	Brodequins de chevalier-lieutenant en tisse-effroi
227102	Mantelet de lieutenant-commandant en soie
227103	Capuche de lieutenant-commandant en soie
227104	Mantelet de champion en soie
227105	Capuche de champion en soie
227106	Tunique de légionnaire en soie
227107	Garde-jambes de légionnaire en soie
227108	Tunique de chevalier-capitaine en soie
227109	Garde-jambes de chevalier-capitaine en soie
227110	Brodequins de garde de sang en soie
227111	Protège-mains de garde de sang en soie
227112	Brodequins de chevalier-lieutenant en soie
227113	Protège-mains de chevalier-lieutenant en soie
227114	Gantelets de chevalier-lieutenant en soie
227115	Gantelets de garde de sang en soie
227116	Gants de chevalier-lieutenant en soie
227117	Gants de garde de sang en soie
227118	Chaperon de champion en satin
227119	Mantelet de lieutenant-commandant en satin
227120	Mantelet de champion en satin
227121	Chaperon de lieutenant-commandant en satin
227122	Tunique de chevalier-capitaine en satin
227123	Garde-jambes de légionnaire en satin
227124	Tunique de légionnaire en satin
227125	Garde-jambes de chevalier-capitaine en satin
227126	Protège-mains de garde de sang en satin
227127	Brodequins de garde de sang en satin
227128	Protège-mains de chevalier-lieutenant en satin
227129	Brodequins de chevalier-lieutenant en satin
227130	Épaulettes de champion en satin
227131	Jambières de légionnaire en satin
227132	Couronne de champion en satin
227133	Poignes de garde de sang en satin
227134	Bottines de garde de sang en satin
227135	Robe de légionnaire en satin
227136	Épaulettes de lieutenant-commandant en satin
227137	Jambières de chevalier-capitaine en satin
227138	Couronne de lieutenant-commandant en satin
227139	Poignes de chevalier-lieutenant en satin
227140	Bottines de chevalier-lieutenant en satin
227141	Robe de chevalier-capitaine en satin
227142	Cuirasse lamellaire de chevalier-capitaine
227143	Jambières lamellaires de chevalier-capitaine
227144	Protège-front lamellaire de lieutenant-commandant
227145	Épaulières lamellaires de lieutenant-commandant
227146	Solerets lamellaires de chevalier-lieutenant
227147	Gantelets lamellaires de chevalier-lieutenant
227148	Espauliers lamellaires de lieutenant-commandant
227149	Casque lamellaire de lieutenant-commandant
227150	Garde-jambes lamellaires de chevalier-capitaine
227151	Pansière lamellaire de chevalier-capitaine
227152	Gants lamellaires de chevalier-lieutenant en plaques
227153	Grèves lamellaires de chevalier-lieutenant en plaques
227154	Espauliers de champion en mailles
227155	Protège-front de champion en mailles
227156	Garde-jambes de légionnaire en mailles
227157	Haubert de légionnaire en mailles
227158	Grèves de garde de sang en mailles
227159	Cestes de garde de sang en mailles
227160	Spallières de champion en mailles
227161	Jambières de légionnaire en mailles
227162	Heaume de champion en mailles
227163	Gantelets de garde de sang en mailles
227164	Solerets de garde de sang en mailles
227165	Cuirasse de légionnaire en mailles
227166	Épaulettes de champion en mailles
227167	Pantalon de légionnaire en mailles
227168	Calot de champion en mailles
227169	Gants de garde de sang en mailles
227170	Bottes de garde de sang en mailles
227171	Corselet de légionnaire en mailles
227172	Épaulières de lieutenant-commandant en peau de dragon
227173	Protège-front de lieutenant-commandant en peau de dragon
227174	Protège-front de champion en peau de dragon
227175	Épaulières de champion en peau de dragon
227176	Plastron de chevalier-capitaine en peau de dragon
227177	Jambières de légionnaire en peau de dragon
227178	Jambières de chevalier-capitaine en peau de dragon
227179	Plastron de légionnaire en peau de dragon
227180	Poignes de garde de sang en peau de dragon
227181	Bottines de garde de sang en peau de dragon
227182	Bottines de chevalier-lieutenant en peau de dragon
227183	Poignes de chevalier-lieutenant en peau de dragon
227184	Spallières de champion en peau de dragon
227185	Pantalon de légionnaire en peau de dragon
227186	Heaume de champion en peau de dragon
227187	Gants de garde de sang en peau de dragon
227188	Bottes de garde de sang en peau de dragon
227189	Armure de légionnaire en peau de dragon
227190	Spallières de lieutenant-commandant en peau de dragon
227191	Pantalon de chevalier-capitaine en peau de dragon
227192	Heaume de lieutenant-commandant en peau de dragon
227193	Gants de chevalier-lieutenant en peau de dragon
227194	Bottes de chevalier-lieutenant en peau de dragon
227195	Armure de chevalier-capitaine en peau de dragon
227196	Tunique de chevalier-capitaine en peau de dragon
227197	Grèves de chevalier-lieutenant en peau de dragon
227198	Gantelets de chevalier-lieutenant en peau de dragon
227199	Coiffure de lieutenant-commandant en peau de dragon
227200	Garde-jambes de chevalier-capitaine en peau de dragon
227201	Espauliers de lieutenant-commandant en peau de dragon
227202	Tunique de légionnaire en peau de dragon
227203	Grèves de garde de sang en peau de dragon
227204	Gantelets de champion en peau de dragon
227205	Coiffure de champion en peau de dragon
227206	Garde-jambes de légionnaire en peau de dragon
227207	Espauliers de champion en peau de dragon
227279	Jonc du magistère
227280	Art des ombres
227282	Anneau de la brume redoutée
227284	Bague de la bête
227285	Dynamiques structurelles du flux
227286	Rhum de Rumsey chaud à la crème
227337	Ensemble gants et ceinture félins
227338	Ensemble gants et ceinture astraux
227339	Ensemble gants et ceinture du gardien
227340	Ensemble gants et ceinture du soigneur
227341	Ensemble gants et ceinture de poursuivant
227342	Ensemble gants et ceinture de rôdeur
227343	Ensemble gants et ceinture miséricordieux
227344	Ensemble gants et ceinture radieux
227345	Ensemble gants et ceinture de la volonté divine
227346	Ensemble gants et ceinture de l’aube
227347	Ensemble gants et ceinture du crépuscule
227348	Ensemble gants et ceinture du frisson
227349	Ensemble gants et ceinture de bataille
227350	Ensemble gants et ceinture du soulagement
227351	Ensemble gants et ceinture d’éruption
227352	Ensemble gants et ceinture d’impact
227353	Ensemble gants et ceinture de résolution
227354	Ensemble gants et ceinture corrompus
227355	Ensemble gants et ceinture pernicieux
227356	Ensemble gants et ceinture inamovibles
227357	Ensemble gants et ceinture irrésistibles
227359	Ensemble bottes, jambes et épaules félines
227360	Ensemble bottes, jambes et épaules astrales
227361	Ensemble bottes, jambes et épaules du gardien
227365	Ensemble bottes, jambes et épaules du soigneur
227366	Ensemble bottes, jambes et épaules de poursuivant
227367	Ensemble bottes, jambes et épaules de rôdeur
227368	Ensemble bottes, jambes et épaules miséricordieuses
227369	Ensemble bottes, jambes et épaules radieuses
227370	Ensemble bottes, jambes et épaules de la volonté divine
227371	Ensemble bottes, jambes et épaules de l’aube
227372	Ensemble bottes, jambes et épaules du crépuscule
227373	Ensemble bottes, jambes et épaules du frisson
227374	Ensemble bottes, jambes et épaules de bataille
227375	Ensemble bottes, jambes et épaules du soulagement
227376	Ensemble bottes, jambes et épaules de l’éruption
227377	Ensemble bottes, jambes et épaules de l’impact
227378	Ensemble bottes, jambes et épaules de résolution
227379	Ensemble bottes, jambes et épaules corrompues
227380	Ensemble bottes, jambes et épaules pernicieuses
227381	Ensemble bottes, jambes et épaules inamovibles
227382	Ensemble bottes, jambes et épaules irrésistibles
227383	Ensemble heaume et plastron félins
227384	Ensemble heaume et plastron astraux
227385	Ensemble heaume et plastron du gardien
227387	Ensemble heaume et plastron du soigneur
227388	Ensemble heaume et plastron de poursuivant
227389	Ensemble heaume et plastron de rôdeur
227390	Ensemble heaume et plastron miséricordieux
227391	Ensemble heaume et plastron radieux
227392	Ensemble heaume et plastron de la volonté divine
227393	Ensemble heaume et plastron de l’aube
227394	Ensemble heaume et plastron du crépuscule
227395	Ensemble heaume et plastron du frisson
227396	Ensemble heaume et plastron de bataille
227397	Ensemble heaume et plastron du soulagement
227398	Ensemble heaume et plastron d’éruption
227399	Ensemble heaume et plastron d’impact
227400	Ensemble heaume et plastron de résolution
227401	Ensemble heaume et plastron corrompus
227402	Ensemble heaume et plastron pernicieux
227403	Ensemble heaume et plastron inamovibles
227404	Ensemble heaume et plastron irrésistibles
227444	Idole de la chasseresse
227451	Cachet d’émission
227454	Jonc des flots
227455	Brise de l’océan
227456	Rune de Tempête cramoisie
227530	Ceinture incandescente
227531	Manchettes incandescentes
227532	Chaperon incandescent
227533	Gants incandescents
227534	Jambières incandescentes
227535	Robe incandescente
227536	Bottes incandescentes
227537	Protège-épaules incandescents
227549	Fragment de parchemin
227552	Parchemin déchiqueté
227658	Note lige d’ombre
227683	Sulfuras, Main de Ragnaros
227684	Marteau en sulfuron
227685	Scalpel d’ombre modifié
227686	Marteau de guerre orné
227687	Dent en or préférée d’Orthas
227688	Hurlesang
227689	Armure de plaque partiellement digérée
227690	Pierre runique nécrotique
227691	Lame d’Hanna
227724	Recommandation tachée de sang
227727	Plans : Marteau en sulfuron
227728	Œil de Sulfuras
227730	Contrat de la Confrérie du Thorium
227743	Noyau énergétique en obsidienne
227745	Bijou de famille
227746	Rune de l’Arbre-monde
227747	Archives de famille
227748	Journal de survivant
227749	Rune de l’étoile filante
227750	Manchettes en écailles en fusion
227751	Ceinture en écailles en fusion
227752	Épaulières en écailles en fusion
227754	Jambières en écailles en fusion
227755	Heaume en écailles en fusion
227756	Gants en écailles en fusion
227757	Bottes en écailles en fusion
227758	Plastron en écailles en fusion
227759	Gants du noyau incendié
227760	Manchettes du noyau incendié
227761	Ceinture du noyau incendié
227762	Protège-épaules du noyau incendié
227763	Jambières du noyau incendié
227764	Heaume du noyau incendié
227765	Bottes du noyau incendié
227766	Plastron du noyau incendié
227767	Bloc de pierre à feu
227768	Jus de rêve
227796	Parchemin darnassien mystérieux
227797	Parchemin darnassien déchiffré
227801	Braise des terres de Feu
227802	Monstre - Torche
227803	Harnais de l’ours de guerre redoutable
227804	Haut-de-chausses de l’ours de guerre redoutable
227805	Férocité des Grumegueules
227807	Ceinture dense grumegueule
227808	Mantelet robuste des Grumegueules
227809	Batailleurs grumegueules cloutés
227810	Bottes denses grumegueules
227811	Défenseur des Grumegueules
227812	Sac-médecine furbolg
227813	Eau sacrée potable de Stratholme
227814	Ceinturon de l’Aube radieux
227815	Bottines de l’aube raffinées
227816	Bottes de soldat d’élite d’argent
227817	Gants de l’Aube radieux
227818	Mantelet de l’Aube luisant
227819	Mantelet de l’Aube de flammes bénies
227820	Brassards en sombrefer trempés
227821	Heaume léché par les flammes en fusion
227822	Bottes du Magma épaisses
227823	Gants Cœur-de-braise raffinés
227824	Heaume en sombrefer trempé
227825	Destructeur en sombrefer fondu
227826	Déchireuse en sombrefer
227827	Ceinturon en anneaux en fusion
227828	Ceinture de marche-lave
227829	Bottes en écailles de dragon noir durcies
227830	Mantelet Coeur-de-braise raffiné
227831	Robe Coeur-de-braise raffinée
227832	Amnistie noire trempée
227833	Glaive de fureur d’obsidienne
227834	Épaulières en anneaux en fusion
227835	Gantelets en sombrefer trempé
227836	Jambières en sombrefer trempé
227837	Ceinture du Magma épaisse
227838	Gantelets chromatiques brillants
227839	Jambières Cœur-de-braise raffinées
227840	Garde noire implacable
227841	Bottes en sombrefer trempé
227842	Poing d’ébène
227843	Crépuscule faucheur
227844	Sac en étoffe runique renforcé de cuir
227845	Faucheuse en arcanite raffinée
227847	Jambières diablocœur
227848	Gantelets diablocœur
227849	Fusil de précision du noyau enflammé
227850	Lame feuille-de-saule de l’archimagus
227851	Cuirasse en écailles de dragon noir durcies
227852	Jambières en écailles de dragon noir durcies
227853	Épaulières en écailles de dragon noir durcies
227854	Cape changeante ouvragée
227857	Violation
227858	Marteau des Dieux sauvages
227859	Épaulières du point du jour chatoyantes
227860	Gilet en étoffe lunaire incandescent
227861	Robe en étoffe lunaire incandescente
227862	Bottes en étoffe lunaire incandescentes
227863	Diadème en étoffe lunaire incandescent
227864	Jambières en étoffe lunaire incandescentes
227865	Gantelets en plaques de feu de la technique cachée
227866	Épaulières volcaniques ouvragées
227867	Jambières volcaniques ouvragées
227868	Cuirasse volcanique ouvragée
227869	Cape chromatique brillante
227870	Gantelets de la tempête
227871	Plaque de sombrefer trempé
227872	Cimier de guerre du grand chef
227873	Épaulières en écailles de dragon bleu affûtées
227874	Jambières en écailles de dragon bleu affûtées
227875	Cuirasse en écailles de dragon bleu affûtées
227876	Maille invincible
227877	Jambières en écailles de dragon vert vivantes
227878	Gantelets en écailles de dragon vert vivantes
227879	Cuirasse en écailles de dragon vert vivantes
227880	Marteau d’armes subtilement enchanté
227881	Tranquillité
227882	Ceinturon de clairvoyance des arcanes
227883	Protège-bras de vol rapide
227884	Crève-cœur mortel
227885	Gantelets de forteresse majeure
227886	Marteau-tempête ouvragé de vol dynamique
227887	Garde de givre durcie
227888	Épaulières de soldat d’élite d’argent
227895	Patron : Mantelet doré de l’Aube
227896	Patron : Bottes de l’Aube d’argent
227897	Patron : Épaulières de l’Aube d’argent
227898	Patron : Cuirasse en écailles de dragon bleu affûtées
227899	Patron : Épaulières en écailles de dragon bleu affûtées
227900	Patron : Jambières en écailles de dragon vert vivantes
227901	Plans : Harnois en sombrefer trempé
227902	Patron : Cuirasse en écailles de dragon noir durcies
227903	Patron : Jambières en écailles de dragon noir durcies
227904	Patron : Épaulières en écailles de dragon noir durcies
227905	Plans : Marteau-tempête ouvragé de vol dynamique
227906	Patron : Cuirasse volcanique ouvragée
227907	Patron : Épaulières volcaniques ouvragées
227908	Patron : Jambières volcaniques ouvragées
227909	Plans : Gantelets en plaques de feu de la technique cachée
227910	Patron : Cape chromatique brillante
227911	Tête de Rend Main-noire
227912	Divinité appliquée
227914	Épiphyse de chouettard
227915	Domaine du duc
227921	Rune de couteaux
227922	Rune de bretteur
227923	Bottines d’eau
227924	Flacon insolite
227925	Balise d’Hydraxis
227926	Couronnement hydraxien
227927	Serment de la mer
227928	Clé de boîte à outils
227930	Clé de cassette
227931	Paquet caché
227932	Pied-de-biche rouillé
227934	Courroux des flammes
227935	Marteau du thane déchu
227936	Anneau diplomatique
227937	Boîte casse-tête
227938	Fragment de lumière
227939	Fragment de lumière
227940	Épée du seigneur général
227941	Faux d’âme en peine
227947	Espauliers de golem ajustés
227948	Hache d’armes de Forgehargne
227952	Cotte d’anneaux de gladiateur sauvage
227955	Heaume de gladiateur sauvage
227956	Cuirasse de dispensateur de mort
227957	Grèves de gladiateur sauvage
227958	Voile fantomatique
227959	Cuissards du gardien éternel
227960	Géante impétueuse
227961	Poignes de gladiateur sauvage
227962	Épine de braise
227963	Lame gravée au sang
227964	Kilt d’illumination
227965	Bottes de concentration
227967	Second souffle
227970	Cape de la salamandre de feu
227971	Poings de la fournaise
227972	Bijou de connaissance
227973	Cercle de flammes
227974	Marteau en pierre de lave
227978	Pierre de Magmus
227980	Robe de la couronne royale
227981	Revancharde forgeffroi
227982	Bâton-guide de sagesse
227983	Cachet sombrefer
227984	Sceptre royal de Thaurissan
227985	La cape neuve de l’empereur
227986	Garde-poignets de renom
227987	Écharpe de la Grande chasse
227988	Joyau impérial
227990	Main d’injustice
227991	Hostefer
227992	Solerets de chevalier de la mort
227993	Poignée d’ébène de Marduk
227994	Hampe Crâne-effroi
227996	Arc ancien en os
227997	Épée de la famille Barov
227998	Bottes en mailles sanglantes
227999	Solerets des ossements
228000	Pansière des ossements
228001	Épaulières de forme-pierre
228002	Ceinturon des ossements
228003	Garde-jambes en mailles sanglantes
228004	Grèves du Déchirevent
228005	Étreinte d’Andros
228006	Gantelets des ossements
228007	Tranche-gargouilles
228008	Garde-jambes des ossements
228009	Bottes nécropile
228010	Mantelet nécropile
228011	Crispins nécropile
228012	Haubert en mailles sanglantes
228013	Robe nécropile
228014	Ceinture en mailles sanglantes
228015	Serre d’effroi
228016	Anneau légèrement opalescent
228017	Pantalon fumecrâne
228018	Jambières nécropile
228019	Cœur du démon
228020	Gantelets en mailles sanglantes
228021	Lame sorcière
228022	Devoir du maître
228023	Étreinte d’Alanna
228024	Croc silencieux
228025	Cuirasse de la pierre tombale
228026	Lame des Noirbois
228027	Trancheuse glacelame
228028	Lame de nécromancie
228029	Hache de guerre de la pierre tombale
228030	Hache malveillante
228031	Gants sombre-ombrage
228032	Casque d’anneaux d’os
228033	Marteau de puissance divine
228034	Protège-mains fébriles
228036	Étreinte de la mort
228037	Targe de Cliquethorax
228038	Pantalon Tisse-fer
228039	Tome envoûté
228040	Jambières du fléau spectral
228041	Jambières d’âme en peine en plaques
228042	Lanière de détention
228044	Jambières du maelström
228045	Bague nécromantique
228046	Bague de domination de don Mauricio
228047	Bague d’amalgame
228050	Arc de satyre
228051	Perche de canalisation quel’dorai
228052	Tranche-vague
228053	Camail fervent
228054	Talisman de la tempête
228055	Pansière énergisée
228056	Machette fielleuse
228057	Anneau de puissance démoniaque
228058	Spallières volumineuses en fer
228059	Épaulières du gardien de l’antre
228060	Cape héliotrope
228061	Gants d’étincelles
228062	Chaperon de perspicacité
228063	Lien de Crochebois
228064	Bouclier de l’observateur
228065	Spallières de cyclone
228066	Gants Tisse-fer
228067	Pendentif d’ancien magus
228068	Ceinture de l’agresseur
228069	Cuissards indicibles
228070	Haubert ogre
228074	Mains de la tentation
228075	Lance de la destinée
228076	Anneau de feu enflammé
228077	Branchonirique
228078	Calice maudit
228079	Cape de feuilles
228080	Jonc de résine
228081	Graine de poison germée
228082	Hache warsong
228083	Cœur d’arbre de la tombée du jour
228084	Extincteur miniature
228085	Bande de la légion déphasée
228086	Lame de déchiqueteur reconvertie
228087	Möbius d’argent surchargé
228088	Plaques d’opérateur de déchiqueteur
228089	Traquelune en bois gravé
228090	Dague rituelle cénarienne
228091	Bottes épineuses
228092	Mantelet druidique
228093	Le cœur noir des ténèbres
228094	Lame de seigneur de l’effroi
228100	Drapé du seigneur du feu
228101	Peau du béhémoth
228102	Drapé de majordome
228103	Grèves de Nathrezim
228104	Robes d’Élune
228105	Cœur de flamme semperardent
228106	Bouclier de vie et de mort
228107	Arc long de la chasseresse déchue
228108	Ombre d’Hurlesang
228109	Garde-jambes de sacrifice
228111	Masque du tueur de dieu
228112	Robe de cauchemar
228113	Froide étreinte
228114	Plans : Faucheuse en arcanite raffinée
228117	Plans : Championne en arcanite raffinée
228118	Plans : Gantelets de forteresse majeure
228119	Patron : Gantelets diablocœur
228120	Patron : Jambières diablocœur
228121	Patron : Sac en étoffe runique renforcé de cuir
228122	Le Cœur du Magma
228123	Épiphanie jubilatoire
228124	Épiphanie onirique
228125	Championne en arcanite raffinée
228126	Épiphanie apéritive
228127	Garde-poignets d’instabilité
228128	Marteau de l’Enclume noire
228129	Crâne d’ombreflamme
228130	Gardien altruiste
228131	Gardien altruiste
228132	Pommes de terre mortes-vivantes
228133	Magma ou lave ?
228134	Le guide complet du nord de Kalimdor
228135	Étude de la Lumière
228136	Badaboum !
228137	Cœur de Golemagg
228138	La Dame et le Chevalier
228139	Poing des Liges du feu
228140	Le Fléau : menace morte-vivante ou phénomène incompris ?
228141	La nécromancie pour les nuls
228142	Terre et feu
228143	Épée d’ombreflamme
228144	Note étrange
228145	Griffe droite de Magmadar
228146	Griffe gauche de Magmadar
228147	Corne de Magmadar
228160	Porte-foi
228162	Tromperie
228163	Broche de la mère des couvées
228165	Javelot du tueur de dragon
228166	Clé de la ville
228168	Use-rouage gobeline
228169	La correctrice d’attitude
228170	Aviron de fortune des mers du Sud
228171	Transporteur de fonds de Kezan
228172	Gardien d’illusion crocs-d’ombre
228173	Libram du consacré
228174	Libram du dévoué
228175	Libram de la sainte rapidité
228176	Totem du tonnerre
228177	Totem du feu enragé
228178	Totem de vitalité terrestre
228179	Totem des plaines
228180	Idole de l’essaim
228181	Idole d’exsanguination (félin)
228182	Idole d’exsanguination (ours)
228183	Idole du bosquet
228184	Corde à linge gobeline
228185	Bouteille cassée de Goblino Noir
228186	Alliance abandonnée
228187	Bâton des mers du Sud
228188	Épingle à cheveux de Prestor
228189	Cadeau de Gob
228190	Connaissance des Grumegueules
228191	Minerai en fusion chatoyant
228214	Monstre - Masse2M, Force irrésistible
228222	Manuel de vaillance d’Azeroth
228227	Scroll of Overwhelming Power
228229	Lame à tranchant d’obsidienne
228230	Marteau des titans raffiné
228239	Robe du pouvoir volatil
228240	Cuissards d’attise-flammes
228242	Anneau épais en sombrefer
228243	Anneau de puissance des sorts
228244	Jambières de tempête de mana
228245	Pantalon en écailles de salamandre
228246	Garde-poignets de stabilité
228247	Sautoir d’illumination
228248	Trembleterre
228249	Médaillon de puissance inébranlable
228250	Plans : Gantelets de forteresse majeure
228251	Patron : Gantelets en écailles de dragon vert vivantes
228252	Marque du Frappeur
228253	Solerets du Marcheflammes
228254	Bottes durcies dans le magma
228255	Talisman de puissance éphémère
228256	Corde de mana enflammé
228257	Vieux gants en cuir du Magma
228258	Spallières de la Terre profonde
228259	Grimoire de runes de feu
228260	Gantelets de garde des flammes
228261	Anneau de frappe rapide
228262	Abrutisseur cramoisi
228263	Dague ensorceleuse
228264	Marteau en pierre d’aura
228265	Lame de brutalité
228266	Disque taraudeur
228267	Éventreur sanguinolent
228268	Sceau de l’archimagus
228269	Magelame chante-azur
228270	Lanceur de grenaille explosive
228271	Bâton de domination
228272	Frappe-ténèbres
228273	Frappe-tonnerre
228274	Bague de cautérisation
228275	Grèves du Cœur du Magma
228276	Patron : Cape changeante ouvragée
228277	Dent de chien du magma
228278	Drague-lave à isolation hyperthermique
228279	Épaulières de garde du feu
228280	Cape ignifugée
228281	Gants de la flamme hypnotique
228282	Écharpe des secrets murmurés
228283	Spallières de croissance sauvage
228284	Garde-poignets de vrai vol
228285	Heaume du donneur de vie
228286	Bague de Précisia
228287	Bague de Sulfuras
228288	Tranchant dilacérateur
228289	Sautoir du seigneur du feu
228290	Cape du voile de brume
228291	Couronne de destruction
228292	Cape sang-de-dragon
228293	Essence de la Flamme pure
228294	Défenseur de Malistar
228295	Ceinturon d’assaut
228296	Lame de la perdition
228297	Fragment de la Flamme
228298	Éclat de l’écaille
228299	Faucheuse spinale
228301	Patron : Protège-bras de vol rapide
228303	Patron : Robe en étoffe lunaire incandescente
228304	Schéma : Fusil de précision du noyau enflammé
228305	Plans : Marteau des titans raffiné
228306	Plans : Violation
228307	Plans : Crève-cœur mortel
228308	Plans : Tranquillité
228309	Patron : Cuirasse en écailles de dragon vert vivantes
228310	Plans : Garde de givre durcie
228311	Plans : Marteau d’armes subtilement enchanté
228312	Plans : Maille invincible
228313	Plans : Gantelets de la tempête
228314	Plans : Cimier de guerre du grand chef
228315	Plans : Lame feuille-de-saule de l’archimagus
228316	Patron : Gilet en étoffe lunaire incandescent
228317	Patron : Diadème en étoffe lunaire incandescent
228318	Patron : Jambières en étoffe lunaire incandescentes
228319	Patron : Ceinturon de clairvoyance des arcanes
228323	Pièce du carnage en cuivre
228324	Pièce du carnage en or
228325	Pièce du carnage en argent
228326	Sacoche de pièces du carnage en cuivre
228327	Sacoche de pièces du carnage en argent
228332	Lok’delar, bâton des Gardiens anciens
228334	Rhok’delar, arc long des Gardiens anciens
228335	Bénédiction
228336	Anathème
228340	Ceinturon de glace éternelle
228345	Jambières de suprématie arcanique
228347	Typhon
228349	Griffe gauche d’Eskhandar
228350	Griffe droite d’Eskhandar
228351	Gantelets de cuir funeste
228352	Jambières gangrenées imprégnées
228353	Cervelière infernale
228354	Médaillon Brasefurie
228355	Ceinture de garde funeste écorché
228356	Gardien du sceau ambré
228357	Brassards de lumière noire
228359	Anneau d’entropie
228360	Fourrure d’Eskhandar
228381	Morsure du froid
228382	Croc des mystiques
228383	Cape surpuissante
228384	Chaussures brûleglace
228385	Couronne ornée d’un cristal
228389	Drapé de bénédiction
228397	Démolisseur empyréen
228410	Lame-d’effroi du Destructeur
228432	Sifflet de la Bête
228459	Lame à tranchant d’obsidienne
228460	Faucheuse spinale
228461	Tranchant dilacérateur
228462	Marteau en pierre d’aura
228463	Trembleterre
228464	Sceau royal d’Eldre’Thalas
228465	Sceau royal d’Eldre’Thalas
228466	Sceau royal d’Eldre’Thalas
228467	Sceau royal d’Eldre’Thalas
228468	Jambières d’Enchevêtre
228469	Anneau elfique terni
228470	Jambières de Lune-d’argent
228471	Fracasse-pierre
228472	Dague de distraction
228473	Maillet inflexible
228474	Robe de vague mentale
228475	Mantelet diabolique
228476	Ceinture brodée de l’archimage
228477	Patron : Ceinture brodée de l’archimage
228478	Lame barbare
228479	Jambières de destruction
228480	Couronne du roi des ogres
228484	Perche des ogres magi
228486	Plaie-du-tréant
228498	Lame-d’effroi du Destructeur
228500	Masque du condamné
228501	Chemisette de l’oiseau chanteur
228502	Piccolo des feux ardents
228503	Jambières du ménestrel
228504	Ceinturon arc-en-ciel
228505	Cape du tribunal royal
228506	Lame de brutalité
228508	Marteau de l’Enclume noire
228511	Lame de la perdition
228513	Protège-bras du sadique
228514	Galoches de Timmy
228515	Collet de Noirsang
228516	Conciliateur
228517	Magelame chante-azur
228518	Crispins de magistrat
228519	Marque du Frappeur
228520	Mantelet de voleur d’âme
228521	Protège-mains lacés de ténèbres
228522	Obusier portatif de Willey
228523	Messager du boulet de canon
228524	Sceau du maître de poste
228525	Tunique du maître de poste
228527	Chausses du maître de poste
228528	Bandeau du maître de poste
228529	Bottines du maître de poste
228530	Garde-jambes en plaques chitineuses
228531	Echarpe de Thuzadin
228532	Brassards de Morlune
228533	Collier de coquillages nacrés
228534	Jambières du chien pestiféré
228535	Hachette tranche-os
228536	Etoile de Mystaria
228537	Gantelets dracoriens
228538	Sceau de Vaillefendre
228539	Livre des morts
228540	Heaume de tyrannie
228541	Don des magi elfes
228542	Déchireuse de Stratholme
228543	Lame runique du baron Vaillefendre
228544	Marteau du Grand croisé
228545	Heaume du grand croisé
228546	Voile du nathrezim
228547	Robe Tisse-fer
228548	Sceptre de focalisation interminable
228551	Tunique du croissant de lune
228552	Gantelets d’adresse
228553	Heaume de l’exécuteur
228554	Gants en peau de démon
228555	Lame de phase
228556	Tablier de boucher
228557	Bottes de guerre agiles
228558	Crispins funéraires
228559	Corbeau noir
228561	Gantelets du trait précis
228562	Spallières de runes démoniaques
228563	Globe de D’sak
228564	Bottes des prophètes
228565	Anneau de magus
228566	Tiare de feu stellaire
228567	Ceinturon de ciseleur
228568	Gantelets de Backusarian
228570	Poing d’Omokk
228571	Harnois du roi-chaman
228572	Garde-bras coeur-d’airain
228573	Crache-venin
228574	Talisman d’évasion
228575	Brassards griffes-tranchantes
228576	Oeil de Couveuse
228577	Gantelets dorés
228578	Echarpe de Pennepoussière
228579	Ceinturon cristallisé
228583	Epaulières de juste frappe
228584	Talisman braise-furie
228585	Marque du seigneur-dragon
228586	Pique glaciale
228587	Bâton de Trindehavre
228588	Griffes de rapineur
228589	Cœur de l’écaille
228590	Mantelet du prophète démembré
228591	Protecteur de Rhombeard
228592	Croc de l’araignée de cristal
228593	Bottes de danseur du vent
228594	Bottes de précision de Kayser
228595	Ceinturon de tireur d’élite
228596	Ceinture Tisse-fer
228597	Bottes Tisse-fer
228598	Brassards Tisse-fer
228599	Cœur de Wyrmthalak
228600	Le Bourre-pif
228601	Faux implacable
228602	Brodequins des flammes
228603	Dolescie de Main-noire
228604	Oeil de Rend
228605	Epaulières de pics d’os
228606	Lame noire de Shahram
228615	Trésor venu d’ailleurs
228650	Garde-jambes de chef de guerre
228651	Bracières du champ d’honneur
228652	Gardienne tribale de Dal’Rend
228653	Devoir sacré de Dal’Rend
228659	Bâton runique gravé des anciens
228660	Jambières de maître-lame
228661	Garde-jambes de Tristam
228662	Garde-bras de la brume noire
228663	Cape de la lune sanguine
228664	Cape de tisseur de givre
228666	Batte suintante
228667	Bague tisse-douleur
228669	Dent de Gnarr
228670	Ceinturon de Brigam
228672	Ceinturon de maître forgeron
228675	Bague de rumination
228676	Ceinturon de sauvagerie
228677	Turban en tisse-sort
228678	Emblème draconique imprégné
228679	Quel’Serrar
228680	Le guide de Nostro du tueur de dragons
228681	Capuche Tisse-fer
228682	Bâton de commandement du seigneur Valthalak
228683	Bague runique de sorcellerie
228684	Pendentif de célérité
228685	Pendentif en dent d’Onyxia
228686	Talisman de sang d’Onyxia
228687	Chevalière du tueur de dragon
228688	Tête d’Onyxia
228689	Tête d’Onyxia
228690	La lumière et comment l’altérer
228691	Garona : une étude en discrétion et en trahison
228692	Le codex de défense
228693	Les recettes de l’arcaniste
228695	Une lame elfique inachevée
228696	Lame ancienne chauffée
228697	Lame ancienne trempée
228699	Anneau de fourberie démoniaque
228700	Mantelet Tisse-fer
228701	Dent de chien du magma
228702	Disque taraudeur
228703	Mules de froidepierre
228704	Cagoule rapiécée en cuir
228722	Main de justice
228746	Mécanotrotteur vert fluo
228747	Rênes de tigre à dents de sabre doré
228748	Sifflet de raptor tacheté de sang
228749	Éclat de Nordrassil
228757	Frappeur gangrené
228759	Torque d’Eskhandar
228797	Grimoire de Gangrarmure
228912	Clé de l’entrepôt de l’Artéfact
228922	Bâton de domination
228924	Bottes en sombrefer trempé
228925	Bottes en sombrefer trempé
228926	Bottes en sombrefer trempé
228927	Bottes en sombrefer trempé
228928	Bottes en sombrefer trempé
228929	Bottes en sombrefer trempé
228955	Grimoire antique de la pierre angulaire
228978	Cachet enchanté : eaux courantes
228979	Cachet enchanté : eaux courantes
228980	Revêtement de bouclier conducteur
228981	Formule : Revêtement de bouclier conducteur
228982	Formule : Enchantement de bouclier (Loi de la nature)
228992	Sac à dos en cuir d’Onyxia
228993	Patron : Sac sans fond
228994	Sac sans fond
229008	Formule : Enchantement de cape (Résistance au Feu supérieure)
229009	Formule : Enchantement de cape (Résistance à la Nature supérieure)
229055	Soie aranasi râpée
229056	Fragment de pierre ponce
229057	Marchandises saisies
229352	Informations recueillies
229362	Clé de l’entrepôt
229372	Éventreur sanguinolent
229373	Porte-foi
229374	Poing des Liges du feu
229376	Dague ensorceleuse
229377	Griffe gauche de Magmadar
229378	Griffe droite de Magmadar
229379	Griffe droite d’Eskhandar
229380	Frappe-ténèbres
229381	Frappe-tonnerre
229382	Drague-lave à isolation hyperthermique
229415	Fournitures de survie
229416	Fourrure chaude
229749	Porte-Vérité
229806	Porte-Vérité
229894	Émeraude de rêve
229897	Parchemin : Création d’une chevalière de signal
229906	Écaille de bronze ternie
229909	Bâton de l’ordre
229910	Faux du Chaos
229911	Mangeur de rêves de Caius
229964	Sabot de seigneur démon
229965	L’œil d’Az’olgothal
229966	Torque de la Main d’argent
229971	Bâton infernal
229972	Bâton du givre
230002	Miséricorde mortelle
230018	Fragments d’orbe de Mannoroc
230224	Lame-tonnerre, épée bénie du Cherchevent
230237	Gemme imprégnée d’arcanes
230238	Le Livre noir
230239	Gants de l’évolution rapide
230240	Mantelet de la cabale de l’Aile noire
230241	Brise-échine
230242	La Lame indomptée
230243	Gemme de vivacité d’esprit
230244	Cachet de changeforme
230245	Pendentif du dragon déchu
230246	Heaume de la rage infinie
230247	Lame croc-de-dragon
230248	Protecteur en écailles de dragon rouge
230249	Gemme donneuse de vie
230250	Totem venimeux
230251	Espauliers de rejeton noir
230252	Brassards de précision des arcanes
230253	Frappe-cœur
230254	Maladath, lame runique du Vol noir
230255	Ceinture en cuir de dragon tendu
230256	Espauliers griffe-de-drake
230257	Anneau de Blackrock
230269	Gemme de récupération
230270	Bâton focalisateur de l’Aile de l’ombre
230271	Fendoir griffe-de-drake
230272	Parchemin de lumière aveuglante
230273	Cristal d’alignement sur la nature
230274	Robe de cendre noire
230275	Étreinte de Gueule-de-feu
230276	Griffe du drake noir
230277	Cape de Gueule-de-feu
230278	Garde-jambes du croisé déchu
230279	Garde-jambes rivetés de primaliste
230280	Égide de préservation
230281	Bague de concentration forcée
230282	Talisman croc-de-drake
230723	Gants de la flamme d’ébène
230725	Rempart béni de Malfurion
230726	Canon à main Souffle-de-dragon
230733	Voile de la pensée pure
230734	Cercle de la force appliquée
230735	Jambières en tisse-braise
230736	Scarabée d’obstruction de Styleen
230737	Toucher du dragon
230738	Prophète de malheur
230739	Torsade d’Angelista
230740	Protège-épaules en cuir de dragon tendu
230741	Bottes chromatiques
230742	Gants en cuir de dragon tendu
230743	Geta chatoyantes
230744	Cape brochée d’élémentium
230745	Ceinturon du croisé déchu
230746	Jambières investies
230747	Épée trempée chromatiquement
230751	Obi de ninja
230794	Griffe de Chromaggus
230800	Sangle rivetée de primaliste
230801	Ashjre’thul, l’Arbalète de châtiment
230802	Rempart en élémentium renforcé
230804	Cape du seigneur des couvées
230805	Bottes de la flamme d’ombre
230806	Chaîne de Therazane
230808	Bague de rétorsion d’Archimtiros
230810	Larme de Neltharion
230811	Bague d’élémentium pur
230812	Mish’undare, coiffure du flagelleur mental
230813	Bâton de la flamme d’ombre
230818	Ashkandi, estramaçon de la Confrérie
230837	Crul’shorukh, le tranchant du chaos
230838	Lok’amir il Romathis
230839	Bague du Maître-tueur de dragon
230840	Médaillon du Maître-tueur de dragon
230841	Orbe du Maître-tueur de dragon
230842	Cape de puissance draconique
230843	Bottes de la pensée pure
230844	Maillet draconique
230845	Tranchant du destin
230846	Bague de sombre domination
230847	Récolteur d’essence
230848	Pourpoint d’ombre entrelacé
230849	Bottes de blizzard de Ringo
230854	Bague de servitude
230855	Sceau du berserker gurubashi
230856	Ceinture du pouvoir vierge
230857	Masque inondé de sang
230858	Cape des adorateurs hakkari
230859	Gants du tourmenté
230860	Puissance de la tribu
230861	Gantelets sacrificiels
230862	Coiffure zulienne
230863	Sceptre des rites zuliens
230864	Haubert runique taché de sang
230865	Croc de Venoxis
230866	Souliers inondés de sang
230867	Bague de Zanzil
230868	Hache zulienne en pierre
230903	Parchemin : essence de feu
230904	Parchemin : SEENECS ED UEF
230908	Essence de feu imprégnée
230909	Essence de feu épuisée
230911	Écraseur de Jeklik
230912	Spallières d’animiste
230913	Talisman d’opaline de Jeklik
230914	Bottes de garde-paix
230915	Bague de primaliste
230916	Bottes Furie-des-mers
230917	Robe rituelle flottante
230918	Toucher de Mar’li
230919	Grèves tachées de sang
230920	Œil de Mar’li
230921	Bague de Jin
230922	Talisman de protection
230923	Bottes de traître
230925	Emprise de Thekal
230926	Jambières de garde-paix
230927	Garde-jambes ritualistes
230928	Jambières Furie-des-mers
230929	Sceau de Jin
230930	Tranchoir zulien
230934	Emprise d’Arlokk
230939	Volonté d’Arlokk
230941	Bâton porte-guigne d’Arlokk
230942	Grèves imprégnées de sang
230943	Bague d’onyx de suzerain
230944	Sac en peau de panthère
230946	Parchemin : SEENECS ED VIREG
230947	Parchemin : essence de givre
230948	Essence de givre imprégnée
230949	Essence de givre épuisée
230984	Bâton de l’ordre incomplet
230989	Défenseur du seigneur sanglant
230991	Hallebarde de châtiment
230992	Lame de guerre des Hakkari
230993	Dard de Mandokir
230994	Jambières d’animiste
230995	Poignes inondées de sang
230996	Espauliers imprégnés de sang
230997	Kilt teinté de sang
230998	Cape de loa hakkari
230999	Bague de suzerain cramoisie
231000	Sceau de primaliste
231001	Sceau de Zanzil
231002	Maléficieur de Jin’do
231003	Mauvais œil de Jin’do
231004	Jugement de Jin’do
231005	Sac de sales tours de Jin’do
231006	Bottes d’animiste
231007	Coiffe tachée de sang
231008	Cuissards tachés de sang
231009	Jambières inondées de sang
231010	Gantelets imprégnés de sang
231011	Gants teintés de sang
231012	Étreinte de suzerain
231013	Couvre-chef du maléficieur
231014	Couvre-œil en écailles de lézard
231015	Masque sergé
231016	Exterminateur de poisson de Nat Pagle
231023	Garde-poignets de courroux
231024	Sangle de courroux
231025	Espauliers de courroux
231026	Garde-jambes de courroux
231027	Ventaille de courroux
231028	Garde-mains de courroux
231029	Solerets de courroux
231030	Corselet de courroux
231031	Brassards de courroux
231032	Ceinture de courroux
231033	Épaulières de courroux
231034	Cuissards de courroux
231035	Heaume de courroux
231036	Gantelets de courroux
231037	Grèves de courroux
231038	Cuirasse de courroux
231039	Spallières Croc-de-sang
231040	Plastron Croc-de-sang
231041	Bottes Croc-de-sang
231042	Gants Croc-de-sang
231043	Cagoule Croc-de-sang
231044	Pantalon Croc-de-sang
231045	Ceinture Croc-de-sang
231046	Brassards Croc-de-sang
231047	Protège-épaules de mage de sang
231048	Corselet Croc-de-sang
231049	Souliers Croc-de-sang
231050	Garde-mains Croc-de-sang
231051	Capuche Croc-de-sang
231052	Garde-jambes Croc-de-sang
231053	Sangle Croc-de-sang
231054	Garde-poignets Croc-de-sang
231055	Brassards de traqueur de dragon
231056	Ceinture de traqueur de dragon
231057	Spallières de traqueur de dragon
231058	Garde-jambes de traqueur de dragon
231059	Casque de traqueur de dragon
231060	Gantelets de traqueur de dragon
231061	Grèves de traqueur de dragon
231062	Cuirasse de traqueur de dragon
231063	Protège-bras de traqueur de dragon
231065	Ceinturon de traqueur de dragon
231066	Espauliers de traqueur de dragon
231067	Pantalon de traqueur de dragon
231068	Calot de traqueur de dragon
231069	Poignes de traqueur de dragon
231070	Solerets de traqueur de dragon
231071	Armure de traqueur de dragon
231072	Bottes de Némésis
231073	Gants de Némésis
231074	Calot de Némésis
231075	Jambières de Némésis
231076	Robe de Némésis
231077	Spallières de Némésis
231078	Ceinture de Némésis
231079	Brassards de Némésis
231090	Bottines de Némésis
231091	Garde-mains de Némésis
231092	Capuche de Némésis
231093	Pantalon de Némésis
231095	Atours de Némésis
231096	Protège-épaules de Némésis
231097	Corde de Némésis
231098	Couvre-bras de Némésis
231100	Ceinture de vent du Néant
231101	Bottes de vent du Néant
231102	Gants de vent du Néant
231103	Couronne de vent du Néant
231104	Pantalon de vent du Néant
231105	Robe de vent du Néant
231106	Mantelet de vent du Néant
231107	Manchettes de vent du Néant
231108	Écharpe de vent du Néant
231109	Mules de vent du Néant
231110	Mitaines de vent du Néant
231111	Masque de vent du Néant
231112	Jambières de vent du Néant
231113	Habits de vent du Néant
231114	Épaulières de vent du Néant
231115	Couvre-bras de vent du Néant
231155	Bottes de transcendance
231156	Garde-mains de transcendance
231157	Auréole de transcendance
231158	Jambières de transcendance
231159	Robe de transcendance
231160	Espauliers de transcendance
231161	Ceinture de transcendance
231162	Manchettes de transcendance
231165	Bottines de transcendance
231166	Gants de transcendance
231167	Couronne de transcendance
231168	Pantalon de transcendance
231169	Atours de transcendance
231170	Mantelet de transcendance
231171	Corde de transcendance
231172	Brassards de transcendance
231174	Manchettes du jugement
231175	Ceinture du jugement
231176	Spallières du jugement
231177	Cuissards du jugement
231178	Couronne du jugement
231179	Gantelets du jugement
231180	Solerets du jugement
231181	Cuirasse du jugement
231182	Protège-bras du jugement
231183	Sangle du jugement
231184	Espauliers du jugement
231185	Garde-jambes du jugement
231186	Grand heaume du jugement
231187	Corselet du jugement
231188	Garde-mains du jugement
231189	Grèves du jugement
231190	Brassards du jugement
231191	Ceinturon du jugement
231192	Mantelet du jugement
231193	Jupe en plaques du jugement
231194	Heaume du jugement
231195	Gants du jugement
231196	Bottines du jugement
231197	Cuirasse du jugement
231198	Gantelets des dix tempêtes
231199	Brassards des dix tempêtes
231200	Ceinture des dix tempêtes
231201	Épaulettes des dix tempêtes
231202	Cuissards des dix tempêtes
231203	Casque des dix tempêtes
231204	Grèves des dix tempêtes
231205	Cuirasse des dix tempêtes
231206	Garde-mains des dix tempêtes
231207	Garde-poignets des dix tempêtes
231208	Sangle des dix tempêtes
231209	Espauliers des dix tempêtes
231210	Garde-jambes des dix tempêtes
231211	Ventaille des dix tempêtes
231212	Solerets des dix tempêtes
231213	Corselet des dix tempêtes
231214	Gants des dix tempêtes
231215	Manchettes des dix tempêtes
231216	Corde des dix tempêtes
231217	Mantelet des dix tempêtes
231218	Kilt des dix tempêtes
231219	Coiffure des dix tempêtes
231220	Bottes des dix tempêtes
231221	Caresse des dix tempêtes
231222	Poignes des dix tempêtes
231223	Protège-bras des dix tempêtes
231224	Ceinturon des dix tempêtes
231225	Spallières des dix tempêtes
231226	Jambières des dix tempêtes
231227	Couronne des dix tempêtes
231228	Bottines des dix tempêtes
231229	Armure des dix tempêtes
231230	Corselet de Hurlorage
231231	Bottes de Hurlorage
231232	Garde-mains de Hurlorage
231233	Couvre-chef de Hurlorage
231234	Garde-jambes de Hurlorage
231235	Espauliers de Hurlorage
231236	Ceinture de Hurlorage
231237	Brassards de Hurlorage
231238	Armure de Hurlorage
231239	Bottines de Hurlorage
231240	Gantelets de Hurlorage
231241	Coiffure de Hurlorage
231242	Jambières de Hurlorage
231243	Spallières de Hurlorage
231244	Sangle de Hurlorage
231245	Garde-poignets de Hurlorage
231246	Cuirs de Hurlorage
231247	Sandales de Hurlorage
231248	Mitaines de Hurlorage
231249	Ramure de Hurlorage
231250	Kilt de Hurlorage
231251	Mantelet de Hurlorage
231252	Corde de Hurlorage
231253	Manchettes de Hurlorage
231254	Gilet de Hurlorage
231255	Croquenots de Hurlorage
231256	Poignes de Hurlorage
231257	Capuche de Hurlorage
231258	Chausses de Hurlorage
231259	Protège-épaules de Hurlorage
231260	Écharpe de Hurlorage
231261	Couvre-bras de Hurlorage
231271	Moulinet cassé de Nat Pagle
231272	Harpon d’Aguilor
231273	Découpeur de Gri’lek
231274	Broyeur de Gri’lek
231275	Expiatrice de Brasefurie
231276	Flétrisseur de pensée
231277	Fourche de la folie
231278	Arc de chasse porte-guigne
231279	Tisonnier de Wushoolay
231280	Charme de nature de Wushoolay
231281	Charme-esprits de Wushoolay
231282	Charme de magie glacée d’Hazza’rah
231283	Charme de protection d’Hazza’rah
231284	Charme de destruction d’Hazza’rah
231285	Charme de courage de Gri’lek
231286	Charme de puissance de Gri’lek
231287	Charme de supercherie de Renataki
231288	Charme de ravage de Renataki
231289	Égide du Dieu sanglant
231293	Ancienne tueuse-d’homme hakkari
231296	Mande-sang
231298	Parchemin de guérison spatiale mineure
231299	Cuissards imprégnés de sang
231300	Cape de consomption
231301	Croc du sans-visage
231302	Destructeur de nains gurubashi
231303	Gantelets de garde-paix
231304	Parchemin : NOGRIÉSU ESAPILATE ERUMINE
231305	Gantelets Furie-des-mers
231306	Collier du Corrupteur d’âmes
231307	L’Œil d’Hakkar
231308	Larme de Chaos
231309	Lame de guerre des Hakkari
231315	Zin’rokh, le Destructeur de mondes
231316	Varech enchanté des mers du Sud en parfait état
231317	Tunique d’haruspice zandalar
231318	Ceinture d’haruspice zandalar
231319	Brassards d’haruspice zandalar
231320	Courroux du maelström
231321	Mantelet de prédateur zandalar
231322	Ceinture de prédateur zandalar
231323	Brassards de prédateur zandalar
231324	Joyau du Kajaro
231325	Mantelet d’illusionniste zandalar
231326	Couvre-bras d’illusionniste zandalar
231327	Robe d’illusionniste zandalar
231328	Marque de héros
231329	Cuirasse de libre-penseur zandalar
231330	Ceinture de libre-penseur zandalar
231331	Garde-bras de libre-penseur zandalar
231332	L’Œil omnivoyant de Zuldazar
231333	Mantelet de confesseur zandalar
231334	Lien de confesseur zandalar
231335	Couvre-bras de confesseur zandalar
231336	Talisman de maîtrise de l’ombre zandalarien
231337	Tunique d’insensé zandalar
231338	Mantelet d’insensé zandalar
231339	Brassards d’insensé zandalar
231340	Vision limpide de Voodress
231341	Haubert d’augure zandalar
231342	Ceinture d’augure zandalar
231343	Brassards d’augure zandalar
231346	Souillure irrésistible de Kezan
231347	Couvre-bras de démoniaque zandalar
231348	Robe de démoniaque zandalar
231349	Mantelet de démoniaque zandalar
231350	Rage de Mugamba
231351	Garde-bras de redresseur de torts zandalar
231352	Ceinture de redresseur de torts zandalar
231353	Cuirasse de redresseur de torts zandalar
231354	Caresse de l’animiste
231355	Équilibre de l’animiste
231357	Fureur de l’animiste
231358	Rugissement de l’animiste
231359	Appel de l’épervier
231361	Sceau du syncrétiste
231362	Cachet du syncrétiste
231363	Écu du syncrétiste
231364	Emblème du syncrétiste
231366	Aura prophétique
231367	Malédiction prophétique
231368	Caresse de la mort
231370	Avancée de la mort
231371	Caresse du vaudouisan
231372	Linceul du vaudouisan
231373	Charme du vaudouisan
231375	Vigilance du vaudouisan
231376	Maléfice porte-guigne
231377	Malédiction vaudou
231378	Disque doré chatoyant
231379	Présence de la puissance
231381	Présence de la vaillance
231382	Calice de la renaissance
231383	Présence de la vision
231384	Fureur de l’épervier
231385	Simulacre de l’Âme des dragons
231386	Écaille de dragon noir sans défaut
231387	Rage-Tempête, sabre sanctifié du Chasse-Bourrasque
231452	Sang du Porteur de Lumière
231460	Brise-plan d’Azgaloth
231466	Codex de démoniste de l’Aile noire
231509	Tome de Cassandre
231512	Idole primordiale hakkari
231513	Sang de Gri’lek
231514	Dent de Renataki
231515	Crinière de Wushoolay
231516	Fragment de rêve d’Hazza’rah
231517	Poupée vaudou percée
231518	Poupée vaudou percée
231519	Poupée vaudou percée
231520	Poupée vaudou percée
231521	Poupée vaudou percée
231522	Poupée vaudou percée
231523	Poupée vaudou percée
231524	Poupée vaudou percée
231525	Poupée vaudou percée
231530	Armure de plaques de seigneur de guerre
231531	Bottes de général en plaques
231532	Gantelets de général en plaques
231533	Jambières de général en plaques
231534	Épaulières de seigneur de guerre en plaques
231535	Chapel de seigneur de guerre en plaques
231536	Armure de plaques de grand maréchal
231537	Garde-épaules de grand maréchal en plaques
231538	Casque de grand maréchal en plaques
231539	Bottes de maréchal en plaques
231540	Garde-jambes de maréchal en plaques
231541	Gantelets de maréchal en plaques
231543	Plastron de grand maréchal en cuir
231544	Manicles de maréchal en cuir
231545	Masque de grand maréchal en cuir
231546	Protège-tibias de maréchal en cuir
231547	Épaulettes de grand maréchal en cuir
231548	Jambières de maréchal en cuir
231549	Cuirasse de seigneur de guerre en cuir
231551	Spallières de seigneur de guerre en cuir
231552	Bottines de général en cuir
231553	Casque de seigneur de guerre en cuir
231554	Garde-jambes de général en cuir
231555	Mitaines de général en cuir
231557	Espauliers de grand maréchal en anneaux
231558	Cuissards de maréchal en anneaux
231560	Poignes de maréchal en anneaux
231561	Solerets de maréchal en anneaux
231562	Grand heaume de grand maréchal en anneaux
231563	Cotte d’anneaux de grand maréchal
231564	Solerets de général en anneaux
231565	Espauliers de seigneur de guerre en anneaux
231566	Cotte d’anneaux de seigneur de guerre
231567	Cuissards de général en anneaux
231568	Grand heaume de seigneur de guerre en anneaux
231569	Poignes de général en anneaux
231570	Grèves de général en anneaux
231571	Casque de seigneur de guerre en anneaux
231572	Épaulières de seigneur de guerre en anneaux
231573	Haubert de seigneur de guerre en anneaux
231574	Garde-jambes de général en anneaux
231575	Cestes de général en anneaux
231576	Épaulières de grand maréchal en anneaux
231577	Garde-jambes de maréchal en anneaux
231578	Cestes de maréchal en anneaux
231579	Grèves de maréchal en anneaux
231580	Casque de grand maréchal en anneaux
231581	Haubert de grand maréchal en anneaux
231582	Robe de grand maréchal en tisse-effroi
231583	Épaulières de grand maréchal en tisse-effroi
231584	Couronne de grand maréchal
231585	Bottes de maréchal en tisse-effroi
231586	Gants de maréchal en tisse-effroi
231587	Jambières de maréchal en tisse-effroi
231588	Pantalon de général en tisse-effroi
231589	Gants de général en tisse-effroi
231590	Chaperon de seigneur de guerre en tisse-effroi
231591	Robe de seigneur de guerre en tisse-effroi
231592	Mantelet de seigneur de guerre en tisse-effroi
231593	Bottes de général en tisse-effroi
231594	Amict de seigneur de guerre en soie
231595	Chausses de général en soie
231596	Grande tenue de seigneur de guerre en soie
231597	Bottes de général en soie
231598	Gants de général en soie
231599	Gantelets de général en soie
231600	Garde-mains de général en soie
231601	Capuche de seigneur de guerre en soie
231602	Spallières de grand maréchal en soie
231603	Habits de grand maréchal en soie
231604	Cerclet de grand maréchal
231605	Jambières de maréchal en soie
231606	Bottillons de maréchal en soie
231607	Gants de maréchal en soie
231608	Gantelets de maréchal en soie
231609	Garde-mains de maréchal en soie
231610	Bottines de général en satin
231611	Épaulettes de seigneur de guerre en satin
231612	Robe de seigneur de guerre en satin
231613	Poignes de général en satin
231614	Jambières de général en satin
231615	Couronne de seigneur de guerre en satin
231616	Couronne de grand maréchal en satin
231617	Poignes de maréchal en satin
231618	Robe de grand maréchal en satin
231619	Jambières de maréchal en satin
231620	Bottines de maréchal en satin
231621	Épaulettes de grand maréchal en satin
231622	Chaperon de grand maréchal en satin
231623	Protège-mains de maréchal en satin
231624	Tunique de grand maréchal en satin
231626	Garde-jambes de maréchal en satin
231627	Brodequins de maréchal en satin
231628	Mantelet de grand maréchal en satin
231630	Brodequins de général en satin
231631	Mantelet de seigneur de guerre en satin
231632	Tunique de seigneur de guerre en satin
231633	Protège-mains de général en satin
231634	Garde-jambes de général en satin
231635	Chaperon de seigneur de guerre en satin
231639	Garde-jambes lamellaires de maréchal
231640	Casque lamellaire de grand maréchal
231641	Pansière lamellaire de grand maréchal
231642	Sac d’herbes de geôlier
231643	Gants lamellaires de maréchal
231644	Sac d’enchantement de geôlier
231645	Espauliers lamellaires de grand maréchal
231646	Grèves lamellaires de maréchal
231647	Jambières lamellaires de maréchal
231648	Protège-front lamellaire de grand maréchal
231649	Cuirasse lamellaire de grand maréchal
231650	Gantelets lamellaires de maréchal
231651	Épaulières lamellaires de grand maréchal
231652	Solerets lamellaires de maréchal
231653	Haubert de seigneur de guerre en mailles
231654	Espauliers de seigneur de guerre en mailles
231655	Cestes de général en mailles
231656	Grèves de général en mailles
231657	Protège-front de seigneur de guerre en mailles
231658	Garde-jambes de général en mailles
231659	Spallières de seigneur de guerre en mailles
231660	Gantelets de général en mailles
231661	Solerets de général en mailles
231662	Cuirasse de seigneur de guerre en mailles
231663	Heaume de seigneur de guerre en mailles
231664	Jambières de général en mailles
231665	Épaulettes de seigneur de guerre en mailles
231666	Gants de général en mailles
231667	Bottes de général en mailles
231668	Corselet de seigneur de guerre en mailles
231669	Calot de seigneur de guerre en mailles
231670	Pantalon de général en mailles
231671	Grèves de général en peau de dragon
231672	Espauliers de seigneur de guerre en peau de dragon
231673	Garde-jambes de général en peau de dragon
231674	Tunique de seigneur de guerre en peau de dragon
231675	Coiffure de seigneur de guerre en peau de dragon
231676	Gantelets de général en peau de dragon
231677	Gants de général en peau de dragon
231678	Casque de seigneur de guerre en peau de dragon
231679	Armure de seigneur de guerre en peau de dragon
231680	Pantalon de général en peau de dragon
231681	Spallières de seigneur de guerre en peau de dragon
231682	Bottes de général en peau de dragon
231683	Bottines de général en peau de dragon
231684	Épaulières de seigneur de guerre en peau de dragon
231685	Jambières de général en peau de dragon
231686	Plastron de seigneur de guerre en peau de dragon
231687	Protège-front de seigneur de guerre en peau de dragon
231688	Poignes de général en peau de dragon
231689	Protège-front de grand maréchal en peau de dragon
231690	Plastron de grand maréchal en peau de dragon
231691	Jambières de maréchal en peau de dragon
231692	Bottines de maréchal en peau de dragon
231693	Épaulières de grand maréchal en peau de dragon
231694	Poignes de maréchal en peau de dragon
231695	Heaume de grand maréchal en peau de dragon
231696	Armure de grand maréchal en peau de dragon
231697	Pantalon de maréchal en peau de dragon
231698	Bottes de maréchal en peau de dragon
231699	Spallières de grand maréchal en peau de dragon
231700	Gants de maréchal en peau de dragon
231701	Coiffure de grand maréchal en peau de dragon
231702	Tunique de grand maréchal en peau de dragon
231703	Garde-jambes de maréchal en peau de dragon
231704	Grèves de maréchal en peau de dragon
231705	Espauliers de grand maréchal en peau de dragon
231706	Gantelets de maréchal en peau de dragon
231707	Manchettes draconiennes
231708	Ceinture draconienne
231709	Protège-épaules draconiens
231710	Jambières draconiennes
231711	Chaperon draconien
231712	Gants draconiens
231713	Bottes draconiennes
231714	Robe draconienne
231715	Manchettes primitives
231716	Ceinture primitive
231717	Protège-épaules primitifs
231718	Jambières primitives
231719	Casque primitif
231720	Gants primitifs
231721	Bottes primitives
231722	Faux du Chaos épuisée
231723	Cuirasse primitive
231724	Manchettes anciennes
231725	Ceinture ancienne
231726	Protège-épaules anciens
231727	Jambières anciennes
231728	Heaume ancien
231729	Gants anciens
231730	Bottes anciennes
231731	Cuirasse ancienne
231732	Fournitures suspectes
231752	S03 – Monstre – Épée, 2m Alliance
231753	Réconfort de Mur-Céleste
231754	Crécerelle
231755	Faucon pèlerin
231777	Membre qiraji cristallisé
231778	Eau de source des montagnes
231779	Courroux de Wray
231780	Tome d’Invocation d’eau VIII
231781	Âme du tonnerre
231782	Couronne du successeur
231783	Drapé du seigneur des Vents
231784	Cellule de foudre
231785	Échos de trahison
231789	Cachet du gardien
231792	Âme de malice
231793	Faux du Chaos épuisée (malice)
231794	Faux du Chaos épuisée (Vide)
231795	Faux du Chaos épuisée (ensorcellement)
231796	Faux du Chaos épuisée (dévoreur)
231797	Âme du Vide
231798	Âme d’ensorcellement
231799	Âme de dévoreur
231800	Âme de Des’Altek
231803	Talisman de perfidie de Prestor
231806	Flèche de feu
231807	Tir incendiaire
231811	Libram d’admiration
231814	Cœur chromatique
231815	Scindéclair
231817	Frappe-vent
231823	Glaive de Geddon
231828	Rune de Spécialisation en méditation
231829	Rune de Spécialisation en soins
231836	Parchemin de guérison spatiale lumineux
231837	Sculpture de l’ombre
231841	Sang du Porteur de Lumière
231842	Bâton de Nandieb
231843	Premier fragment de cachet
231844	Deuxième fragment de cachet
231845	Troisième fragment de cachet
231846	Découpeur de Gri’lek
231847	Broyeur de Gri’lek
231848	Exterminateur de poisson de Nat Pagle
231849	Harpon d’Aguilor
231850	Volonté d’Arlokk
231851	Emprise d’Arlokk
231852	Destructeur de nains gurubashi
231853	Lame de guerre des Hakkari
231854	Zin’rokh, le Destructeur de mondes
231855	Croc du sans-visage
231856	Ancienne tueuse-d’homme hakkari
231857	Larme de Chaos
231858	Mande-sang
231859	Maléficieur de Jin’do
231860	Jugement de Jin’do
231861	Écraseur de Jeklik
231862	Expiatrice de Brasefurie
231863	Flétrisseur de pensée
231864	Fourche de la folie
231865	Sceptre des rites zuliens
231866	Toucher de Mar’li
231867	Défenseur du seigneur sanglant
231868	Dard de Mandokir
231869	Lame de guerre des Hakkari
231870	Hallebarde de châtiment
231871	Tisonnier de Wushoolay
231872	Arc de chasse porte-guigne
231873	Hache zulienne en pierre
231874	Croc de Venoxis
231875	Emprise de Thekal
231876	Tranchoir zulien
231882	Reçu de l’engin de suppression
231885	Deuillegivre
231890	Terrestris
231891	Traité de l’épervier
231901	Porte-Vérité
231902	Amulette d’Ada
231903	Morceau d’étoffe déchirée
231904	Cor terni
231909	Lumière stellaire cristallisée
231910	Cœur d’Azgaloth
231911	Chevalière du général de la Légion
231912	Lame de la fosse
231913	Œil de l’observateur
231995	Scorie d’élémentium durcie
231996	Gobmogrificateur surchargé
232018	Lame du baiser du vent dormante
232079	Manchettes de Hurlorage
232080	Corde de Hurlorage
232081	Mantelet de Hurlorage
232082	Kilt de Hurlorage
232083	Ramure de Hurlorage
232084	Mitaines de Hurlorage
232085	Sandales de Hurlorage
232086	Cuirs de Hurlorage
232087	Brassards de Hurlorage
232088	Ceinture de Hurlorage
232089	Espauliers de Hurlorage
232090	Garde-jambes de Hurlorage
232091	Couvre-chef de Hurlorage
232092	Garde-mains de Hurlorage
232093	Bottes de Hurlorage
232094	Corselet de Hurlorage
232095	Couvre-bras de Hurlorage
232096	Écharpe de Hurlorage
232097	Protège-épaules de Hurlorage
232098	Chausses de Hurlorage
232099	Capuche de Hurlorage
232100	Poignes de Hurlorage
232101	Croquenots de Hurlorage
232102	Gilet de Hurlorage
232103	Garde-poignets de Hurlorage
232104	Sangle de Hurlorage
232105	Spallières de Hurlorage
232106	Jambières de Hurlorage
232107	Coiffure de Hurlorage
232108	Gantelets de Hurlorage
232109	Bottines de Hurlorage
232110	Armure de Hurlorage
232111	Protège-bras de traqueur de dragon
232112	Ceinturon de traqueur de dragon
232113	Espauliers de traqueur de dragon
232114	Pantalon de traqueur de dragon
232115	Calot de traqueur de dragon
232116	Poignes de traqueur de dragon
232117	Solerets de traqueur de dragon
232118	Armure de traqueur de dragon
232119	Brassards de traqueur de dragon
232120	Ceinture de traqueur de dragon
232121	Spallières de traqueur de dragon
232122	Garde-jambes de traqueur de dragon
232123	Casque de traqueur de dragon
232124	Gantelets de traqueur de dragon
232125	Grèves de traqueur de dragon
232126	Cuirasse de traqueur de dragon
232127	Manchettes de vent du Néant
232128	Ceinture de vent du Néant
232129	Mantelet de vent du Néant
232130	Pantalon de vent du Néant
232131	Couronne de vent du Néant
232132	Gants de vent du Néant
232133	Bottes de vent du Néant
232134	Robe de vent du Néant
232135	Couvre-bras de vent du Néant
232136	Écharpe de vent du Néant
232137	Épaulières de vent du Néant
232138	Jambières de vent du Néant
232139	Masque de vent du Néant
232140	Mitaines de vent du Néant
232141	Mules de vent du Néant
232142	Habits de vent du Néant
232143	Manchettes du jugement
232144	Ceinture du jugement
232145	Spallières du jugement
232146	Cuissards du jugement
232147	Couronne du jugement
232148	Gantelets du jugement
232149	Solerets du jugement
232150	Cuirasse du jugement
232151	Brassards du jugement
232152	Ceinturon du jugement
232153	Mantelet du jugement
232154	Jupe en plaques du jugement
232155	Heaume du jugement
232156	Gants du jugement
232157	Bottines du jugement
232158	Cuirasse du jugement
232159	Protège-bras du jugement
232160	Sangle du jugement
232161	Espauliers du jugement
232162	Garde-jambes du jugement
232163	Grand heaume du jugement
232164	Garde-mains du jugement
232165	Grèves du jugement
232166	Corselet du jugement
232167	Brassards de transcendance
232168	Corde de transcendance
232169	Mantelet de transcendance
232170	Pantalon de transcendance
232171	Couronne de transcendance
232172	Gants de transcendance
232173	Bottines de transcendance
232174	Atours de transcendance
232175	Manchettes de transcendance
232176	Ceinture de transcendance
232177	Espauliers de transcendance
232178	Jambières de transcendance
232179	Auréole de transcendance
232180	Garde-mains de transcendance
232181	Bottes de transcendance
232182	Robe de transcendance
232183	Brassards Croc-de-sang
232184	Ceinture Croc-de-sang
232185	Spallières Croc-de-sang
232186	Pantalon Croc-de-sang
232187	Cagoule Croc-de-sang
232188	Gants Croc-de-sang
232189	Bottes Croc-de-sang
232190	Plastron Croc-de-sang
232191	Garde-poignets Croc-de-sang
232192	Sangle Croc-de-sang
232193	Protège-épaules de mage de sang
232194	Garde-jambes Croc-de-sang
232195	Capuche Croc-de-sang
232196	Garde-mains Croc-de-sang
232197	Souliers Croc-de-sang
232198	Corselet Croc-de-sang
232199	Manchettes des dix tempêtes
232200	Corde des dix tempêtes
232201	Mantelet des dix tempêtes
232202	Kilt des dix tempêtes
232203	Coiffure des dix tempêtes
232204	Gants des dix tempêtes
232205	Bottes des dix tempêtes
232206	Caresse des dix tempêtes
232207	Brassards des dix tempêtes
232208	Ceinture des dix tempêtes
232209	Épaulettes des dix tempêtes
232210	Cuissards des dix tempêtes
232211	Casque des dix tempêtes
232212	Gantelets des dix tempêtes
232213	Grèves des dix tempêtes
232214	Cuirasse des dix tempêtes
232215	Protège-bras des dix tempêtes
232216	Ceinturon des dix tempêtes
232217	Spallières des dix tempêtes
232218	Jambières des dix tempêtes
232219	Couronne des dix tempêtes
232220	Poignes des dix tempêtes
232221	Bottines des dix tempêtes
232222	Armure des dix tempêtes
232223	Garde-poignets des dix tempêtes
232224	Sangle des dix tempêtes
232225	Espauliers des dix tempêtes
232226	Garde-jambes des dix tempêtes
232227	Ventaille des dix tempêtes
232228	Garde-mains des dix tempêtes
232229	Solerets des dix tempêtes
232230	Corselet des dix tempêtes
232231	Brassards de Némésis
232232	Ceinture de Némésis
232233	Spallières de Némésis
232234	Jambières de Némésis
232235	Calot de Némésis
232236	Gants de Némésis
232237	Bottes de Némésis
232238	Robe de Némésis
232239	Couvre-bras de Némésis
232240	Corde de Némésis
232241	Protège-épaules de Némésis
232242	Pantalon de Némésis
232243	Capuche de Némésis
232244	Garde-mains de Némésis
232245	Bottines de Némésis
232246	Atours de Némésis
232247	Brassards de courroux
232248	Ceinture de courroux
232249	Épaulières de courroux
232250	Cuissards de courroux
232251	Heaume de courroux
232252	Gantelets de courroux
232253	Grèves de courroux
232254	Cuirasse de courroux
232255	Garde-poignets de courroux
232256	Sangle de courroux
232257	Espauliers de courroux
232258	Garde-jambes de courroux
232259	Ventaille de courroux
232260	Garde-mains de courroux
232261	Solerets de courroux
232262	Corselet de courroux
232299	Défenseur zulien
232309	Conducteur d’âme de Renataki
232310	Conducteur d’âme de Renataki
232311	Cape zulienne en peau de tigre
232312	Sang du Porteur de Lumière
232324	Appeau à oiseau
232344	Vick's VIP Pass
232357	Vengeresse draconique
232358	Reliquaire vide
232373	Œil de Sulfuras raffiné
232389	Libram d’abondance
232390	Idole de focalisation céleste
232391	Idole de focalisation féline
232392	Totem du tonnerre implacable
232409	Totem des éléments
232414	Lame dent-de-dragon
232416	Totem du flux astral
232419	Totem des courants conducteurs
232420	Libram de colère
232421	Libram de vengeance
232423	Idole nourricière
232424	Idole de cruauté
232433	Bandage épais en étoffe runique
232434	Manuel : bandage épais en étoffe runique
232436	Bisque de Pince-noire
232437	Recette : bisque de Pince-noire
232438	Rouget fumé
232443	Recette : rouget fumé
232454	Emblème des dieux sauvages
232455	Emblème de déshonneur
232456	Emblème de l’Œil pourpre
232457	Emblème du cœur du monde
232458	Rune de Sanctuaire amélioré
232459	Rune de Retour de flamme
232460	Rune de Déplacement
232461	Rune de Désespoir
232462	Rune de Puissance purifiante
232549	Briefing logistique VI
232550	Ashkandi, estramaçon de la Confrérie
232551	Maillet draconique
232552	Lok’amir il Romathis
232555	Crul’shorukh, le tranchant du chaos
232556	Bâton de la flamme d’ombre
232557	Griffe de Chromaggus
232558	Épée trempée chromatiquement
232559	Prophète de malheur
232561	Griffe du drake noir
232562	Fendoir griffe-de-drake
232563	Bâton focalisateur de l’Aile de l’ombre
232564	Maladath, lame runique du Vol noir
232565	Lame croc-de-dragon
232566	La Lame indomptée
232567	Brise-échine
232576	Vengeresse draconique
232577	Tranchant du destin
232606	Ashjre’thul, l’Arbalète de châtiment
232607	Frappe-cœur
232608	Canon à main Souffle-de-dragon
232610	Formule : encaustique troll magnifique
232611	Encaustique troll magnifique
232652	Zila Amanemodas
233197	Manuel d’entraînement d’argent
233198	Cor de l’Aube
233200	Graine de fleur-de-chant
233201	Globe chatoyant
233206	Enclume de surveillant
233208	Boule magique « défectueuse »
233209	Chaudron d’eau de feu
233211	Conque spirituelle
233213	Magnétite antique
233215	Piège de sable explosif
233216	Rayon givromatique
233217	Encens de tunnelier
233226	Corde zandalari antique
233250	Branche ancienne
233351	Cristal de résonance qiraji vert clair
233352	Cristal de résonance qiraji bleu foncé
233353	Cristal de résonance qiraji bleu clair
233356	Cristal de résonance qiraji orange
233357	Cristal de résonance qiraji du crépuscule
233358	Char d’assaut silithide apprivoisé
233362	Carcasse du Dieu très ancien
233363	Carapace du Dieu très ancien
233364	Peau du Dieu très ancien
233365	Viscères intacts
233367	Péritoine intact
233368	Entrailles intactes
233369	Manchettes de domination qiraji
233370	Manchettes de commandement qiraji
233371	Manchettes de souveraineté qiraji
233372	Grèves du Conquérant
233373	Cuirasse du Conquérant
233374	Cuissards du Conquérant
233375	Couronne du Conquérant
233376	Spallières du Conquérant
233377	Bottines d’implorateur funeste
233378	Pantalon d’implorateur funeste
233379	Mantelet d’implorateur funeste
233380	Robe d’implorateur funeste
233381	Diadème d’implorateur funeste
233382	Jambières d’implorateur de tempête
233383	Espauliers d’implorateur de tempête
233384	Bottes d’implorateur de tempête
233385	Diadème d’implorateur de tempête
233386	Haubert d’implorateur de tempête
233387	Spallières de dispensateur de mort
233388	Casque de dispensateur de mort
233389	Gilet de dispensateur de mort
233390	Jambières de dispensateur de mort
233391	Bottes de dispensateur de mort
233392	Bottines de l’oracle
233393	Tiare de l’oracle
233394	Mantelet de l’oracle
233395	Habit de l’oracle
233396	Pantalon de l’oracle
233397	Cuirasse du Vengeur
233398	Couronne du Vengeur
233399	Grèves du Vengeur
233400	Cuissards du Vengeur
233401	Espauliers du Vengeur
233402	Robe de l’énigme
233403	Protège-épaules de l’énigme
233404	Diadème de l’énigme
233405	Bottes de l’énigme
233406	Jambières de l’énigme
233407	Bottes du Frappeur
233408	Jambières du Frappeur
233409	Espauliers du Frappeur
233410	Diadème du Frappeur
233411	Haubert du Frappeur
233412	Casque de la genèse
233413	Protège-épaules de la genèse
233414	Bottes de la genèse
233415	Gilet de la genèse
233416	Pantalon de la genèse
233417	Masse de vie interminable
233418	Cape de vie interminable
233419	Anneau de vie interminable
233420	Cape du sentier invisible
233421	Faux du sentier invisible
233422	Chevalière du sentier invisible
233423	Lame des secrets scellés
233424	Drapé des secrets scellés
233425	Anneau des secrets scellés
233426	Lame de justice éternelle
233427	Cape de justice éternelle
233428	Anneau de justice éternelle
233429	Marteau de sagesse infinie
233430	Voile de sagesse infinie
233431	Anneau de sagesse infinie
233432	Cape des ombres voilées
233433	Dague des ombres voilées
233434	Anneau des ombres voilées
233435	Marteau de la tempête imminente
233436	Cape de la tempête imminente
233437	Anneau de la tempête imminente
233438	Voile des noms inexprimés
233439	Kriss des noms inexprimés
233440	Anneau des noms inexprimés
233441	Drapé de force inflexible
233442	Faucille de force inflexible
233443	Chevalière de force inflexible
233490	Championne en obsidienne
233491	Saccageur en obsidienne
233492	Harnois de bataille d’épaules de Tranchépic
233496	Épaulières du barrage
233502	Amulette de vile sauvegarde
233503	Pendentif du gardien qiraji
233504	Cape de concentré de haine
233505	Jambières d’immersion
233506	Garde-poignets en écailles de hanneton
233507	Anneau de pensée foisonnante
233509	Bâton des prophètes qiraji
233514	Bottes de la volonté inexorable
233515	Marteau de Ji’zhi
233516	Plastron d’annihilation
233517	Bottes de la prophétie rédemptrice
233518	Bottes du prophète déchu
233519	Cape de la trinité
233520	Robe du triumvirat
233521	Mantelet ternaire
233522	Semblance du dévoreur
233523	Ceinture de la triade
233524	Toucher d’Angelista
233559	Gants d’Ebru
233560	Gantelets éclaboussés de vase
233561	Bottes du héros déchu
233562	Charme d’Angelista
233563	Mantelet de la puissance phrénique
233564	Gantelets couverts de bile
233565	Anneau de ténèbres d’Ukko
233566	Mantelet de la fureur du désert
233567	Mantelet de la croisade du désert
233568	Gilet d’exécution rapide
233569	Anneau du dévoré
233570	Scarabée pétrifié
233571	Baguette de noblesse qiraji
233572	Collier de pureté
233573	Bottes recomposées
233574	Jambières de l’essaim purulent
233575	Robe du garde de guerre
233576	Griffe de silithide
233577	Ceinture qiraji en peau épaisse
233578	Casque des lianes rampantes
233579	Gants de coercition
233580	Insigne de garde-essaim
233581	Pouvoir de Sartura
233582	Gantelets de détermination inébranlable
233583	Cuissards de lumière flamboyante
233584	Jambières de fureur qiraji en écailles
233585	Ancien éventreur qiraji
233586	Mâchoire du ravageur des sables
233587	Collier barbelé
233588	Cape des secrets inexprimables
233589	Fétiche du ravageur des sables
233590	Bottes de tunnelière de la ruche
233591	Corselet en carapace de silithide
233592	Mantelet de vengeance cruelle
233593	Espauliers de l’Implacable
233594	Robe du saint gardien
233595	Jambières de ravageur des sables en écailles
233596	Libram de purification
233597	Totem de vie
233598	Jambières couvertes de vase
233599	Fémur de silithide aiguisé
233600	Anneau de fureur qiraji
233601	Broche scarabée
233602	Idole de santé
233603	Gantelets du champion vertueux
233604	Gantelets de Kalimdor
233605	Aiguillon d’Huhuran
233606	Cape de la Ruche d’or
233607	Gants du messie
233608	Gantelets en peau de guêpe
233609	Anneau du martyr
233610	Garde-poignets de profanateur de ruche
233611	Bottes de l’épiphanie
233612	Brassards d’exécution qiraji
233613	Gants de dévastation de Vek’lor
233614	Ceinture royale qiraji
233615	Anneau de l’empereur Vek’lor
233616	Sceptre royal de Vek’lor
233617	Bracelets de rédemption royale
233618	Gants du temple caché
233619	Ceinture régénérante de Vek’nilash
233620	Amulette de Vek’nilash
233621	Vengeance de Kalimdor
233622	Torsade de l’empereur déchu
233623	Ceinture de l’empereur déchu
233624	Chapeau égaré de Don Rigoberto
233625	Brassards de fouisseur
233626	Larve du Grand ver
233627	Jom Gabbar
233628	La Carapace du fouisseur
233629	Bouclier en écailles de ver
233630	Cape du dévoré
233631	Gantelets du sombre orage
233632	Torsade du Dieu très ancien
233633	Corde de pédoncule cintrée
233634	Dard de la mort
233635	Ceinture d’agonie sans fin
233636	Sceptre du faux prophète
233637	Gantelets d’annihilation
233638	Anneau du tueur de dieu
233639	Tentacule de C’Thun vaincu
233640	Sombre tranchante de la démence
233641	Cape de clarté
233642	Marque de C’Thun
233643	Marteau de guerre d’anubisath
233644	Atours d’ascension royale
233645	Gants de l’immortel
233646	Gants de la prophétie rachetée
233647	Neretzek, le Buveur de sang
233648	Anneau du chaos de Rytssin
233649	Fragment de l’étoile tombée
233651	Thorax du Conquérant
233652	Solerets du Conquérant
233653	Heaume du Conquérant
233654	Tassettes du Conquérant
233658	Espauliers du Conquérant
233659	Corselet de dispensateur de mort
233660	Bottines de dispensateur de mort
233661	Visière de dispensateur de mort
233662	Pantalon de dispensateur de mort
233663	Espauliers de dispensateur de mort
233664	Cotte de mailles annelées du Frappeur
233665	Bottines du Frappeur
233666	Visière du Frappeur
233667	Cuissards du Frappeur en anneaux
233668	Spallières du Frappeur
233669	Protège-front d’implorateur funeste
233670	Atours d’implorateur funeste
233671	Protège-épaules d’implorateur funeste
233672	Chausses d’implorateur funeste
233673	Bottillons d’implorateur funeste
233674	Pantalon de l’énigme
233675	Mules de l’énigme
233676	Cercle de l’énigme
233677	Mantelet de l’énigme
233678	Atours de l’énigme
233679	Jambières de l’oracle
233680	Robe de l’oracle
233681	Protège-épaules de l’oracle
233682	Couronne de l’oracle
233683	Mules de l’oracle
233684	Mantelet du Vengeur
233685	Pantalon en plaques du Vengeur
233686	Bottines du Vengeur
233687	Heaume du Vengeur
233688	Thorax du Vengeur
233689	Spallières du Vengeur
233690	Tassettes du Vengeur
233691	Solerets du Vengeur
233692	Grand heaume du Vengeur
233693	Corselet du Vengeur
233694	Corselet d’implorateur de tempête
233695	Ventaille d’implorateur de tempête
233696	Solerets d’implorateur de tempête
233697	Spallières d’implorateur de tempête
233698	Cuissards d’implorateur de tempête
233699	Cuirasse d’implorateur de tempête
233700	Couronne d’implorateur de tempête
233701	Bottines d’implorateur de tempête
233702	Mantelet d’implorateur de tempête
233703	Jambières d’implorateur de tempête en anneaux
233704	Étreinte d’implorateur de tempête en mailles
233705	Coiffure d’implorateur de tempête en mailles
233706	Grèves d’implorateur de tempête en mailles
233707	Épaulettes d’implorateur de tempête en mailles
233708	Jambières d’implorateur de tempête en mailles
233709	Capuche de la genèse
233710	Pantalon en cuir de la genèse
233711	Armure de la genèse
233712	Croquenots de la genèse
233713	Spallières de la genèse
233714	Jambières de la genèse
233715	Armure en cuir de la genèse
233716	Bottines de la genèse
233717	Mantelet de la genèse
233718	Coiffure de la genèse
233719	Braies de la genèse
233720	Corselet de la genèse
233721	Grèves de la genèse
233722	Espauliers de la genèse
233723	Masque de la genèse
233724	Ceinturon en plaques aguerri
233725	Ceinturon en plaques aguerri
233726	Garde-bras en plaques aguerris
233727	Garde-bras en plaques aguerris
233728	Insigne couvert de sang
233729	Sautoir couvert de sang
233730	Talisman couvert de sang
233731	Amulette couverte de sang
233732	Collier couvert de sang
233733	Anneau couvert de sang
233734	Cercle couvert de sang
233735	Jonc couvert de sang
233736	Bague couverte de sang
233737	Cape couverte de sang
233738	Pèlerine couverte de sang
233739	Drapé couvert de sang
233740	Linceul couvert de sang
233741	Ceinture lamellaire aguerrie
233742	Garde-bras lamellaires aguerris
233743	Poignets lamellaires aguerris
233744	Corde lamellaire aguerrie
233745	Baudrier en mailles aguerri
233746	Corde en mailles aguerrie
233747	Ceinture en mailles aguerrie
233748	Brassards en mailles aguerris
233749	Protège-bras en mailles aguerris
233750	Protège-bras en mailles aguerris
233751	Ceinturon en anneaux aguerri
233752	Ceinturon en anneaux aguerri
233753	Ceinture en anneaux aguerrie
233754	Ceinture en anneaux aguerrie
233755	Garde-poignets en anneaux aguerris
233756	Garde-poignets en anneaux aguerris
233757	Brassards en anneaux aguerris
233758	Brassards en anneaux aguerris
233759	Brassards en peau de dragon aguerris
233760	Brassards en peau de dragon aguerris
233761	Ceinture en peau de dragon aguerrie
233762	Ceinture en peau de dragon aguerrie
233763	Sangle en peau de dragon aguerrie
233764	Sangle en peau de dragon aguerrie
233765	Corde en peau de dragon aguerrie
233766	Corde en peau de dragon aguerrie
233767	Poignets en peau de dragon aguerris
233768	Poignets en peau de dragon aguerris
233769	Bracières en peau de dragon aguerries
233770	Bracières en peau de dragon aguerries
233771	Ceinturon en cuir aguerri
233772	Ceinturon en cuir aguerri
233773	Brachiales en cuir aguerries
233774	Brachiales en cuir aguerries
233775	Crispins en soie aguerris
233776	Crispins en soie aguerris
233777	Écharpe en soie aguerrie
233778	Écharpe en soie aguerrie
233779	Brassards en satin aguerris
233780	Brassards en satin aguerris
233781	Poignets en satin aguerris
233782	Poignets en satin aguerris
233783	Écharpe en satin aguerrie
233784	Écharpe en satin aguerrie
233785	Cordelière en satin aguerrie
233786	Cordelière en satin aguerrie
233787	Crispins en tisse-effroi aguerris
233788	Crispins en tisse-effroi aguerris
233789	Ceinture en tisse-effroi aguerrie
233790	Ceinture en tisse-effroi aguerrie
233791	Pièce de cuivre couverte de sang
233793	Plaques d’épaules de Tranchépic
233795	Cervelière de Tranchépic
233796	Destructeur d’obsidienne
233797	Marteau-tempête d’obsidienne
233798	Lame feuille-de-saule d’obsidienne
233801	Défenseur d’obsidienne
233802	Renfort d’armure en chitine luminescente
233803	Renfort d’armure en chitine affûtée
233804	Protège-épaules de Roncerasoir
233808	Capuche de Roncerasoir
233813	Armure en cuir de Roncerasoir
233826	Capuche vampirique
233833	Châle vampirique
233837	Robe vampirique
233956	Écharpe en soie qiraji
233958	Pèlerine en soie qiraji
233959	Cape en soie qiraji
233960	Drapé en soie qiraji
233962	Flacon de folie
233964	Flacon de savoir antique
233965	Flacon des Dieux très anciens
233966	Flacon de chagrin inflexible
233967	Élixir du ratel
233968	Élixir du seigneur-mage
233969	Élixir du cuirassé
233977	Élixir d’empressement
233984	Mégabombe des arcanes
233985	Le Fumigateur
233986	Bombe d’obsidienne
233987	Générateur 80NN-V18
233988	Disque de force réactif syntonisé
233990	Pierre de vitesse
233991	Larme de la Rêveuse
233992	Magnétite de vengeance
233993	Chronomètre enchanté
233994	Broche incrustée de rubis
233995	Parchemin : Courroux de l’essaim
233996	Répulsif enchanté
233997	Formule : Enchantement de plastron (Caractéristiques vivantes)
233998	Formule : Enchantement de gants (Puissance sacrée)
233999	Formule : Enchantement de gants (Pouvoir des arcanes)
234000	Tome de prière enchanté
234001	Totem enchanté
234002	Champignon enchanté
234003	Barre de thorium imprégnée d’obsidienne
234004	Silex à aiguiser d’obsidienne
234005	Poudre explosive d’obsidienne
234006	Chitine monstrueuse de silithide
234007	Chitine épineuse de silithide
234008	Soie qiraji
234009	Rouleau de soie qiraji
234010	Bile de ver des sables ancien
234011	Venin de traqueur qiraji
234012	Chardon de ruche
234016	Chevalière du Vol de bronze
234017	Chevalière du Vol de bronze
234018	Chevalière du Vol de bronze
234019	Chevalière du Vol de bronze
234020	Chevalière du Vol de bronze
234021	Chevalière du Vol de bronze
234022	Chevalière du Vol de bronze
234023	Chevalière du Vol de bronze
234024	Chevalière du Vol de bronze
234025	Chevalière du Vol de bronze
234026	Chevalière du Vol de bronze
234027	Chevalière du Vol de bronze
234028	Chevalière du Vol de bronze
234029	Chevalière du Vol de bronze
234030	Chevalière du Vol de bronze
234031	Chevalière du Vol de bronze
234032	Chevalière du Vol de bronze
234033	Chevalière du Vol de bronze
234034	Chevalière du Vol de bronze
234035	Chevalière du Vol de bronze
234061	Dague sacrificielle qiraji
234062	Habit des Sables changeants
234063	Ceinture du ravageur des sables
234064	Ceinture de l’inquisition
234065	Garde-poignets de ravageur des sables
234066	Gants en cuir de silithide raffermi
234067	Massacreuse des Qiraji
234068	Bottes de l’avant-garde
234069	Bottes du général qiraji
234070	Brassards de commandement qiraji
234071	Cuissards du commandement qiraji
234072	Torsade de Sudevent
234073	Turban terrevent
234075	Gantelets de l’Inébranlable
234076	Serre de concentration furieuse
234077	Corselet silithide épais
234078	Garde-épaules chitineux
234079	Cape du sauveur
234080	Œil de Moam
234081	Gantelets de Sudevent
234082	Mantelet de Maz’Nadir
234083	Anneau de fureur
234084	Casque de Sudevent
234085	Plans : emprise noire du Destructeur
234086	Emprise noire du Destructeur
234087	Jambières en écailles d’obsidienne
234088	Cuissards du Destructeur
234089	Fragment du crâne de Buru
234090	Gants de l’essaim
234091	Gantelets d’écailles visqueux
234092	Fétiche d’épines chitineuses
234093	Cuissardes des sables mouvants
234094	Brassards d’écailles du Grandgosier
234095	Écrase-gelées
234096	Arc du boyau tendu
234097	Aiguillon d’Ayamiss
234098	Bottes du protecteur du désert
234099	Bottes des sables brûlants
234100	Casque de rétablissement
234101	Anneau des vents du désert
234102	Gantelets d’écailles silithides
234103	Brassards de brutalité
234104	Arbalète de destin imminent
234105	Gantelets de nouvelle vie
234106	Gants de la sombre sagesse
234107	Heaume de domination
234108	Jambières du blizzard noir
234109	Mantelet de l’Horusath
234110	Manchettes d’Ossirian
234111	Épaulières de pierre runique
234112	Marteau poli au sable
234113	Cape de tempête de sable
234114	Menottes de l’Intouché
234115	Bâton des ruines
234116	Fureur de l’essaim oublié
234117	Bottes du nomade errant
234118	Marteau d’autorité qiraji
234119	Antennes revigorantes
234120	Casque du vengeur sacré
234121	Lanceur silithide à carapace
234122	Le kriss perdu de Zedd
234123	Coiffe de fureur élémentaire
234124	Recueil : Poison occulte II
234129	Jambières enchâssées d’onyx
234130	Amulette de bouclier contre l’ombre
234132	Collier en dents de drake
234133	Bottes de manœuvre
234134	Turban gnome de puissance psychique
234135	Anneau des profondeurs glacées
234136	Robe des eaux sombres
234137	Croc de Korialstrasz
234138	Douleur de Shadowsong
234139	Héritage de Ravencrest
234141	Épée runique du Rouge
234142	Élixir Noggenfogger inépuisable
234143	Globe de tromperie
234144	Encensoir du faux prophète
234145	Bijou hakkari couvert de sang
234146	Grèves gravées à l’acide
234147	Jambières anciennes corrodées
234148	Garde-poignets os-de-dragon
234149	Couvre-bras aiguillon-de-dragon
234150	Gantelets de la puissance illusoire
234151	Cape en peau de dragon vert
234152	Marteau de fureur bestiale
234153	Bâton de croissance luxuriante
234154	Pierre de transe
234155	Chevalière de Malfurion
234156	Bottes de la lande infinie
234157	Diadème des rêves troublés
234158	Collier cœur-de-dragon
234159	Arbalète en bois de fer poli
234160	Anneau des non-vivants
234161	Ceinture de la tourbière sombre
234162	Protège-poignets d’écorce noire
234163	Pantalon du cœur noir
234164	Coiffe de croissance déviante
234165	Gantelets de la lumière étincelante
234166	Bottillons malveillants
234167	Bottes d’effroi
234168	Chaussons malveillants
234169	Anneau de la déchirure d’esprit
234170	Lame de cauchemar
234171	Spallières contre-nature en cuir
234172	Croc-de-dragon émeraude
234173	Jambières de l’esprit dément
234174	Espauliers gravés à l’acide
234175	Cristal d’hibernation
234176	Carte de Sombrelune : Héroïsme
234177	Carte de Sombrelune : Dragon bleu
234178	Carte de Sombrelune : Maelström
234179	Carte de Sombrelune : Néant distordu
234180	Fusée temporelle
234181	Journal de sectateur du crépuscule
234198	Chevalière du Vol de bronze
234199	Chevalière du Vol de bronze
234200	Chevalière du Vol de bronze
234201	Chevalière du Vol de bronze
234202	Chevalière du Vol de bronze
234220	Plans : Cervelière de Tranchépic
234221	Plans : Plaques d’épaules de Tranchépic
234222	Plans : Harnois de bataille d’épaules de Tranchépic
234223	Plans : Saccageur en obsidienne
234224	Plans : Championne en obsidienne
234225	Plans : Destructeur d’obsidienne
234226	Plans : Marteau-tempête d’obsidienne
234227	Plans : Lame feuille-de-saule d’obsidienne
234228	Plans : Défenseur d’obsidienne
234235	Patron : Renfort d’armure en chitine luminescente
234236	Patron : Renfort d’armure en chitine affûtée
234237	Patron : Capuche de Roncerasoir
234238	Patron : Protège-épaules de Roncerasoir
234239	Patron : Armure en cuir de Roncerasoir
234240	Patron : Capuche vampirique
234241	Patron : Châle vampirique
234242	Patron : Robe vampirique
234244	Patron : Écharpe en soie qiraji
234249	Patron : Pèlerine en soie qiraji
234250	Patron : Cape en soie qiraji
234251	Patron : Drapé en soie qiraji
234252	Recette : flacon de chagrin inflexible
234253	Recette : flacon de savoir antique
234255	Recette : flacon des Dieux très anciens
234256	Recette : flacon de folie
234257	Recette : Élixir du ratel
234258	Recette : Élixir du seigneur-mage
234259	Recette : Élixir du cuirassé
234260	Recette : Élixir d’empressement
234261	Schéma : Mégabombe des arcanes
234262	Schéma : Le Fumigateur
234263	Schéma : Bombe en obsidienne
234264	Schéma : Générateur 80NN-V18
234265	Schéma : Disque de force réactif syntonisé
234266	Formule : Pierre de vitesse
234267	Formule : Larme de la Rêveuse
234268	Formule : Magnétite de vengeance
234269	Formule : Chronomètre enchanté
234270	Formule : Broche incrustée de rubis
234271	Formule de parchemin : Courroux de l’essaim
234272	Formule : Répulsif enchanté
234275	Formule : Tome de prière enchanté
234276	Formule : Totem enchanté
234277	Formule : Champignon enchanté
234278	Manuel : Barre de thorium imprégnée d’obsidienne
234279	Plans : Silex à aiguiser d’obsidienne
234280	Schéma : Poudre explosive d’obsidienne
234288	Ceinture de vignefer
234289	Plans : Ceinture de vignefer
234290	Gants de vignefer
234291	Plans : Gants de vignefer
234292	Cuirasse de vignefer
234293	Plans : Cuirasse de vignefer
234294	Brassards de traqueuse des sables
234295	Patron : Brassards de traqueuse des sables
234296	Gantelets de traqueuse des sables
234297	Patron : Gantelets de traqueuse des sables
234298	Cuirasse de traqueuse des sables
234299	Patron : Cuirasse de traqueuse des sables
234300	Brassards de crache-feu
234301	Patron : Brassards de crache-feu
234302	Gantelets de crache-feu
234303	Patron : Gantelets de crache-feu
234304	Cuirasse de crache-feu
234305	Patron : Cuirasse de crache-feu
234306	Ceinture de la ronceraie
234307	Patron : Ceinture de la ronceraie
234308	Bottes de la ronceraie
234309	Patron : Bottes de la ronceraie
234310	Casque de la ronceraie
234311	Patron : Casque de la ronceraie
234312	Épaulières sylvestres
234314	Patron : Épaulières sylvestres
234315	Couronne sylvestre
234316	Patron : Couronne sylvestre
234317	Gilet sylvestre
234318	Patron : Gilet sylvestre
234319	Ceinture lourde en obsidienne
234320	Plans : Ceinture lourde en obsidienne
234321	Ceinture légère en obsidienne
234322	Plans : Ceinture légère en obsidienne
234324	Cuirasse de rêvécaille
234325	Patron : Cuirasse de rêvécaille
234428	Crève-cœur en obsidienne
234429	Plans : Crève-cœur en obsidienne
234434	Fusil en obsidienne
234435	Schéma : Fusil en obsidienne
234436	Chevalière du Vol de bronze
234437	Chevalière du Vol de bronze
234438	Chevalière du Vol de bronze
234439	Chevalière du Vol de bronze
234440	Chevalière du Vol de bronze
234444	Poison occulte II
234445	Patron : Rouleau de soie qiraji
234447	Bâtonnet de transformation de Bubulle
234458	Plans : Bouclier dentelé en obsidienne
234459	Bouclier dentelé en obsidienne
234460	Tunique de mailles en obsidienne
234461	Plans : Tunique de mailles en obsidienne
234462	Choc de terre
234463	Courroux de Cénarius
234464	Bâtonnet des bulles de Bubulle
234465	Rênes de tigre spectral rapide
234467	Bâtonnet des Dragons de Bubulle
234468	Idole de la puissance ursine
234469	Idole de férocité féline
234474	Idole de courroux sidéréel
234475	Libram de l’exorciste
234476	Libram de sainteté
234477	Libram de piété
234478	Totem de frappes tonitruantes
234479	Totem de magma libéré
234480	Totem de tonnerre pyroclastique
234481	Patron : Kilt de rêvécaille
234482	Kilt de rêvécaille
234483	Patron : Brassards de rêvécaille
234484	Brassards de rêvécaille
234485	Mitaines de rêvécaille
234486	Patron : Mitaines de rêvécaille
234487	Visière de rêvécaille
234488	Plans : Visière de rêvécaille
234542	Grande épée de grand seigneur de guerre
234543	Hache de bataille de grand seigneur de guerre
234545	Pulvériseur de grand seigneur de guerre
234546	Destructeur de grand seigneur de guerre
234547	Aiguillon de grand seigneur de guerre
234548	Aiguillade de grand seigneur de guerre
234549	Bâton de guerre de grand seigneur de guerre
234550	Sorcelame de grand seigneur de guerre
234551	Masse d’armes de grand seigneur de guerre
234552	Lame de grand seigneur de guerre
234553	Prestelame de grand seigneur de guerre
234554	Fendoir de grand seigneur de guerre
234555	Massue de grand seigneur de guerre
234556	Rasoir de grand seigneur de guerre
234557	Griffe droite de grand seigneur de guerre
234558	Griffe gauche de grand seigneur de guerre
234559	Arc courbe de grand seigneur de guerre
234560	Arbalète de grand seigneur de guerre
234561	Balayeur de rue de grand seigneur de guerre
234562	Pavois de grand seigneur de guerre
234563	Tome de destruction de grand seigneur de guerre
234564	Tome de guérison de grand seigneur de guerre
234565	Claymore de connétable
234566	Découpeuse de connétable
234567	Marteau d’armes de connétable
234568	Démolisseur de connétable
234569	Vouge de connétable
234570	Arme à répétition de connétable
234571	Bâton de connétable
234574	Magelame de connétable
234576	Marteau de guerre de connétable
234578	Épée longue de connétable
234579	Vivelame de connétable
234580	Hachette de connétable
234581	Punisseur de connétable
234582	Miséricorde de connétable
234583	Lame de connétable (main droite)
234584	Lame de connétable (main gauche)
234585	Viseur de connétable
234586	Arme à répétition de connétable
234587	Canon à main de connétable
234588	Égide de connétable
234589	Tome de puissance de connétable
234590	Tome de restauration de connétable
234614	Emblème touché par le Vide
234650	Ancien éventreur qiraji
234747	Poing de Cénarius
234748	Brassards de Fonderoc
234749	Orbe calme-terre
234760	Brassards Furie-du-roc
234761	Puissance de Cénarius
234779	Grâce de la Terre
234780	Anneau de puissance terrestre
234782	Gilet de puissance de la terre
234785	Gants de puissance terrestre
234786	Anneau du courroux terrestre
234788	Cape en tisse-terre
234792	Trancheur de Ravenholdt
234793	Kriss de Shivsprocket
234797	Le tisonnier de Thunderwood
234798	Mortulus prime
234799	Arbalète à répétition de Fahrad
234800	Marteau de culture de Simona
234801	Amulette du dieu déchu
234802	Cape du dieu déchu
234803	Anneau du dieu déchu
234804	Hache de guerre qiraji bénie
234805	Mousquet qiraji béni
234806	Pugio qiraji béni
234807	Pavois qiraji béni
234808	Bâton d’acolyte qiraji béni
234809	Bâton d’augure qiraji béni
234810	Marteau de guerre qiraji béni
234811	Charme des Sables changeants
234812	Amulette des Sables changeants
234813	Foulard des Sables changeants
234814	Pendentif des Sables changeants
234960	Rênes de tigre couvert de sang
234961	Sifflet de raptor couvert de sang
234962	Habit enchâssé de jade
234963	Cuissards ornés de glyphes étranges
234964	Chevalière du Vol de bronze
234965	Chevalière du Vol de bronze
234966	Chevalière du Vol de bronze
234967	Chevalière du Vol de bronze
234968	Chevalière du Vol de bronze
234974	Bâton des prophètes qiraji
234975	Marteau de Ji’zhi
234976	Baguette de noblesse qiraji
234977	Griffe de silithide
234978	Mâchoire du ravageur des sables
234979	Fémur de silithide aiguisé
234980	Aiguillon d’Huhuran
234981	Vengeance de Kalimdor
234983	Larve du Grand ver
234984	Dard de la mort
234985	Sombre tranchante de la démence
234986	Marteau de guerre d’anubisath
234987	Neretzek, le Buveur de sang
234989	Dague sacrificielle qiraji
234990	Massacreuse des Qiraji
234991	Arc du boyau tendu
234992	Aiguillon d’Ayamiss
234993	Arbalète de destin imminent
234994	Marteau poli au sable
234995	Bâton des ruines
234996	Marteau d’autorité qiraji
234997	Lanceur silithide à carapace
234998	Le kriss perdu de Zedd
234999	Marteau de guerre qiraji béni
235000	Bâton d’augure qiraji béni
235001	Bâton d’acolyte qiraji béni
235002	Pugio qiraji béni
235003	Hache de guerre qiraji bénie
235004	Mousquet qiraji béni
235005	Faucille de force inflexible
235006	Dague des ombres voilées
235007	Faux du sentier invisible
235008	Kriss des noms inexprimés
235009	Marteau de la tempête imminente
235010	Marteau de sagesse infinie
235011	Lame de justice éternelle
235012	Masse de vie interminable
235013	Lame des secrets scellés
235014	Sceptre du faux prophète
235039	Plans : cuirasse épaisse en obsidienne
235040	Cuirasse épaisse en obsidienne
235045	Tenue de parade impériale qiraji
235046	Armes impériales qiraji
235047	Gants du prophète déchu
235048	Tête d’Ossirian l’Intouché
235049	Objet noyé dans les cauchemars
235133	Formule : libram de piété
235134	Formule : libram de l’exorciste
235135	Formule : libram de sainteté
235136	Formule : totem de tonnerre pyroclastique
235137	Formule : totem de frappes tonitruantes
235138	Formule : totem de magma libéré
235139	Formule : idole de courroux sidéral
235140	Formule : idole de férocité féline
235141	Formule : idole de la puissance ursine
235142	Pièce d’argent couverte de sang
235143	Pièce d’or couverte de sang
235144	Sacoche de pièces de cuivre couvertes de sang.
235145	Sacoche de pièces d’argent couvertes de sang
235275	Suite de Portails
235276	Suite d’Élémentaires
235277	Suite de Seigneurs de guerre
235278	Suite de Fauves
235282	Antennes revigorantes
235473	Barricade de connétable
235474	Barricade de grand seigneur de guerre
235476	Trancheuse de grand seigneur de guerre
235477	Brise-os de grand seigneur de guerre
235478	Kriss de grand seigneur de guerre
235479	Kriss de connétable
235480	Brise-os de connétable
235481	Trancheuse de connétable
235497	Philtre des sables
235511	Cristal de résonance qiraji jaune sans défaut
235512	Cristal de résonance qiraji vert sans défaut
235513	Cristal de résonance qiraji bleu sans défaut
235514	Cristal de résonance qiraji rouge sans défaut
235517	Torche
235526	Formule : Enchantement de brassards (Puissance de sort)
235528	Formule : Enchantement de brassards (Agilité)
235529	Lunette en obsidienne
235530	Schéma : Lunette en obsidienne
235597	Notes de sort : Congélation
235598	Notes de sort : Veines glaciales
235599	Notes de sort : Anomalie temporelle
235600	Rune de Tempête divine
235601	Rune de Fanatisme
235602	Rune de Marteau du vertueux
235603	Rune de Vengeance vertueuse
235604	Rune de Bouclier de piété
235605	Rune de Choc et effroi
235785	« Clé » de cage de Deuillevent
235786	Bibelot de Karazhan
235787	Branche de bois de fer ancestral
235788	Feu follet enthousiaste
235789	Flamme de vie
235790	Tison enchanté
235825	Philtre des sables
235852	Sacoche pourpre
235867	Fragment de parchemin
235868	Rempart de courroux
235869	Capuche du maître
235870	Heaume en anneaux cliquetants
235871	Heaume de mort préhensile
235872	Poignets de traqueur
235873	Manchettes des cryptes
235874	Protège-mains d’adepte
235875	Gants de fossoyeur
235876	Garde-mains de pécheur
235877	Gantelets de fanatique
235878	Ceinture maléfique
235879	Liens lestes
235880	Semelles frustes
235881	Arpenteurs redoutés
235882	Solerets cliquetants
235883	Bottillons lestés de puits
235884	Chevalière spectrale
235885	Anneau ignoble
235886	Fermoir de Kaigy
235887	Sautoir de Barian
235888	Matraqueuse
235889	Bâton de combat de serviteur
235890	Alène de tisseur d’ombre
235891	Pelle d’antan
235892	Échine de cavalier noir
235893	Grimoire lié à l’ombre
235894	Trépas d’auspice funeste
236002	Liste de composants
236005	Cuirasse de cuirassier
236006	Cuissards de cuirassier
236007	Casque de cuirassier
236008	Espauliers de cuirassier
236009	Solerets de cuirassier
236010	Gantelets de cuirassier
236011	Sangle de cuirassier
236012	Brassards de cuirassier
236013	Anneau du cuirassier
236014	Thorax de cuirassier
236015	Tassettes de cuirassier
236016	Cornes de cuirassier
236017	Épaules de cuirassier
236018	Grèves de cuirassier
236019	Poignes de cuirassier
236020	Ceinture de cuirassier
236021	Poignets de cuirassier
236022	Bague du cuirassier
236023	Cuirasse de la faucheuse d’os
236024	Cuissards de la faucheuse d’os
236025	Casque de la faucheuse d’os
236026	Espauliers de la faucheuse d’os
236027	Solerets de la faucheuse d’os
236028	Gantelets de la faucheuse d’os
236029	Sangle de la faucheuse d’os
236030	Brassards de la faucheuse d’os
236031	Anneau de la faucheuse d’os
236032	Ceinture de la faucheuse d’os
236033	Bottines de la faucheuse d’os
236034	Bague de la faucheuse d’os
236035	Mantelet de la faucheuse d’os
236036	Jambières de la faucheuse d’os
236037	Masque de la faucheuse d’os
236038	Poignes de la faucheuse d’os
236039	Corselet de la faucheuse d’os
236040	Garde-poignets de la faucheuse d’os
236041	Anneau de traqueur des cryptes
236042	Protège-poignets de traqueur des cryptes
236043	Tunique de traqueur des cryptes
236044	Spallières de traqueur des cryptes
236045	Cuissards de traqueur des cryptes
236046	Couvre-chef de traqueur des cryptes
236047	Garde-mains de traqueur des cryptes
236048	Ceinturon de traqueur des cryptes
236049	Bottes de traqueur des cryptes
236050	Protège-bras de traqueur des cryptes
236051	Ceinture de traqueur des cryptes
236052	Espauliers de traqueur des cryptes
236053	Jambières de traqueur des cryptes
236054	Visière de traqueur des cryptes
236055	Gantelets de traqueur des cryptes
236056	Bague de traqueur des cryptes
236057	Grèves de traqueur des cryptes
236058	Cuirasse de traqueur des cryptes
236059	Sandales de pestecœur
236060	Jambières de pestecœur
236061	Manchettes de pestecœur
236062	Robe de pestecœur
236063	Gants de pestecœur
236064	Diadème de pestecœur
236065	Protège-épaules de pestecœur
236066	Ceinture de pestecœur
236067	Anneau de pestecœur
236068	Garde-poignets de pestecœur
236069	Sangle de pestecœur
236070	Mantelet de pestecœur
236071	Pantalon de pestecœur
236072	Couronne de pestecœur
236073	Garde-mains de pestecœur
236074	Jonc de pestecœur
236075	Bottes de pestecœur
236076	Atours de pestecœur
236077	Manchettes de givrefeu
236078	Ceinture de givrefeu
236079	Jambières de givrefeu
236080	Sandales de givrefeu
236081	Robe de givrefeu
236082	Gants de givrefeu
236083	Diadème de givrefeu
236084	Protège-épaules de givrefeu
236085	Anneau de givrefeu
236087	Bandelettes de givrefeu
236088	Sangle de givrefeu
236089	Mantelet de givrefeu
236090	Pantalon de givrefeu
236091	Chaperon de givrefeu
236092	Mitaines de givrefeu
236093	Bague de givrefeu
236094	Bottes de givrefeu
236095	Atours de givrefeu
236097	Robe de foi
236098	Ceinture de foi
236099	Sandales de foi
236100	Manchettes de foi
236101	Jambières de foi
236102	Protège-épaules de foi
236103	Diadème de foi
236104	Gants de foi
236105	Anneau de foi
236106	Poignets de foi
236107	Ceinturon de foi
236108	Mantelet de foi
236109	Pantalon de foi
236110	Couronne de foi
236111	Mains de foi
236112	Bague de foi
236113	Bottes de foi
236114	Atours de foi
236115	Tunique de rédemption
236116	Anneau de rédemption
236117	Couvre-chef de rédemption
236118	Garde-mains de rédemption
236119	Protège-poignets de rédemption
236120	Ceinturon de rédemption
236121	Cuissards de rédemption
236122	Spallières de rédemption
236123	Bottes de rédemption
236124	Protège-bras de rédemption
236125	Ceinture de rédemption
236126	Plaques d’épaule de rédemption
236127	Jambières de rédemption
236128	Casque de rédemption
236129	Gants de rédemption
236130	Bague de rédemption
236131	Grèves de rédemption
236132	Cuirasse de rédemption
236133	Brassards de rédemption
236134	Sangle de rédemption
236135	Espauliers de rédemption
236136	Cuissards de rédemption
236137	Couronne de rédemption
236138	Gantelets de rédemption
236139	Jonc de rédemption
236140	Solerets de rédemption
236141	Corselet de rédemption
236142	Garde-mains de Brise-terre
236143	Garde-jambes de Brise-terre
236144	Couvre-chef de Brise-terre
236145	Spallières de Brise-terre
236146	Bottes de Brise-terre
236147	Tunique de Brise-terre
236148	Ceinturon de Brise-terre
236149	Protège-poignets de Brise-terre
236150	Anneau de Brise-terre
236151	Manchettes de Brise-terre
236152	Corde de Brise-terre
236153	Mantelet de Brise-terre
236154	Kilt de Brise-terre
236155	Couronne de Brise-Terre
236156	Mitaines de Brise-terre
236157	Bague de Brise-terre
236158	Grèves de Brise-terre
236159	Étreinte de Brise-terre
236160	Brassards de Brise-terre
236162	Sangle de Brise-terre
236163	Espauliers de Brise-terre
236164	Cuissards de Brise-terre
236165	Ventaille de Brise-terre
236166	Gants de Brise-terre
236167	Jonc de Brise-terre
236168	Solerets de Brise-terre
236169	Corselet de Brise-terre
236170	Protège-bras de Brise-terre
236171	Ceinture de Brise-terre
236172	Épaulettes de Brise-terre
236173	Jambières de Brise-terre
236174	Casque de Brise-terre
236175	Poignes de Brise-terre
236176	Chevalière de Brise-terre
236177	Bottines de Brise-terre
236179	Armure de Brise-terre
236182	Couvre-chef de marcherêve
236183	Protège-poignets de marcherêve
236184	Garde-mains de marcherêve
236185	Bottes de marcherêve
236186	Tunique de marcherêve
236187	Ceinturon de marcherêve
236188	Cuissards de marcherêve
236189	Spallières de marcherêve
236190	Anneau de marcherêve
236192	Manchettes de marcherêve
236193	Corde de marcherêve
236194	Mantelet de marcherêve
236195	Kilt de marcherêve
236196	Chaperon de marcherêve
236197	Mitaines de marcherêve
236198	Bague de marcherêve
236199	Sandales de marcherêve
236200	Cuirs de marcherêve
236201	Brassards de marcherêve
236202	Sangle de marcherêve
236203	Espauliers de marcherêve
236204	Jambières de marcherêve
236205	Coiffe de marcherêve
236206	Gantelets de marcherêve
236207	Jonc de marcherêve
236208	Solerets de marcherêve
236209	Armure de marcherêve
236210	Couvre-bras de marcherêve
236211	Écharpe de marcherêve
236212	Protège-épaules de marcherêve
236213	Chausses de marcherêve
236214	Capuche de marcherêve
236215	Poignes de marcherêve
236216	Chevalière de marcherêve
236217	Croquenots de marcherêve
236218	Gilet de marcherêve
236219	Présage funeste
236220	Atours de nécrochevalier
236221	Servobras égaré
236222	Tunique en peau de goule
236223	Anneau de la flamme éternelle
236224	Targe stygienne
236225	Ceinturon de fureur élémentaire
236226	Espauliers de fureur élémentaire
236227	Ceinture du grand croisé
236228	Spallières du grand croisé
236229	Jambières du grand croisé
236230	Jambières de fureur élémentaire
236231	Cuirasse désacralisée
236232	Sangle désacralisée
236233	Gantelets désacralisés
236234	Solerets désacralisés
236235	Brassards désacralisés
236236	Heaume désacralisé
236237	Espauliers désacralisés
236238	Cuissots désacralisés
236239	Sandales désacralisées
236240	Protège-épaules désacralisés
236241	Diadème désacralisé
236242	Robe désacralisée
236243	Gants désacralisés
236244	Ceinture désacralisée
236245	Manchettes désacralisées
236246	Jambières désacralisées
236247	Protège-poignets désacralisés
236248	Bottes désacralisées
236249	Couvre-chef désacralisé
236250	Garde-mains désacralisés
236251	Tunique désacralisée
236252	Ceinturon désacralisé
236253	Cuissards désacralisés
236254	Spallières désacralisées
236255	Garde-poignets de vengeance
236256	Larme de givre
236257	Gemme de Nérubis
236258	Cape en soie de démon des cryptes
236259	Bague des prières inexaucées
236260	Espauliers plaie-de-glace
236261	Pendentif de la pierre pernicieuse
236262	Protège-épaules polaires
236263	Remords de la veuve
236264	L’Étreinte de la veuve
236265	Lame en peine
236266	Pendentif des noms oubliés
236267	Robe de toile cristalline
236268	Baiser de l’araignée
236269	Croc de Maexxna
236270	Hachette de l’os brisé
236271	Libram de lumière
236272	Cape du Fléau
236273	Bague de l’inévitable
236274	Bague du grêlon
236275	Cœur frigide de Noth
236276	Totem de l’eau courante
236277	Collier de nécropsie
236278	Coiffure glaciale
236279	Chapeau de précepteur
236280	Cuissards de carnage
236281	Camail glacécaille
236282	Reflet d’Horreb
236283	Anneau de ferveur spirituelle
236284	Bâton de soufre
236285	L’œil de Nérub
236286	Bague des forces contre-nature
236287	Cisailleuse
236288	Le Porte-peste
236289	Cape de suture
236290	Baguette des Parques
236291	Bague de réanimation
236292	Rosée du crépuscule
236293	Injecteur de toxines
236294	Spallières glacécaille
236295	Mantelet glacial
236296	Pacte de la mort
236297	La fin des rêves
236298	Mantelet couvert de gel
236299	Claymore de puissance impie
236300	Collier perdu de Gluth
236301	Main de pouvoir digérée
236302	Œil de diminution
236303	Jambières de polarité
236304	Thorax d’abomination blindé
236305	Pic du crépuscule
236306	Fustigatrice
236307	Voile de l’éclipse
236308	Idole de longévité
236309	Ceinturon du mentor
236310	Baguette de la mort murmurante
236311	Chevalière du défenseur déchu
236312	Iblis, lame du séraphin déchu
236313	Manchettes du moissonneur d’âmes
236314	Bottes de déplacement
236315	Casque polaire
236316	Torque de sadique
236317	Vis’era l’Étripeuse
236318	Sceau des damnés
236319	Jambières de l’Apocalypse
236320	Cordialité du pardon
236321	Maillet du croisé racheté
236322	Cordâme
236323	Résistance du Fléau
236324	Puissance du Fléau
236325	Robustesse du Fléau
236326	Pouvoir du Fléau
236327	Cape de la nécropole
236328	Œil gauche de Saphiron
236329	Œil du mort
236330	Œil droit de Saphiron
236331	L’essence contenue de Saphiron
236333	Voile d’assujettissement
236334	Blason de tueur
236335	Poings de l’Implacable
236336	Le Visage de la mort
236337	Glyphe de déviation
236338	Griffe du wyrm de givre
236339	Gressil, Aube de la ruine
236340	Puissance de Menethil
236341	Le Froid dévorant
236342	Talisman bouillonnant de Stormrage
236343	Détrôneuse
236344	Esclavagiste nérubien
236345	Gemme des innocents enchaînés
236346	Cherche-âme
236347	Bouclier de condamnation
236348	Marteau du Néant distordu
236349	Doigt du destin
236350	Le phylactère de Kel’Thuzad
236351	Marque de champion
236352	Marque de champion
236354	Sceau de l’Aube d’aspirant
236355	Sceau de l’Aube d’initié
236356	Sceau de l’Aube d’écuyer
236357	Sceau de l’Aube de chevalier
236358	Sceau de l’Aube de templier
236360	Sceau de l’Aube de champion
236361	Sceau de l’Aube de l’avant-garde
236362	Sceau de l’Aube de croisé
236363	Sceau de l’Aube de commandant
236364	Sceau de l’Aube de généralissime
236374	Sceau de l’Aube de commandant
236375	Sceau de l’Aube de généralissime
236376	Sceau de l’Aube de croisé
236378	Sceau de l’Aube de l’avant-garde
236379	Sceau de l’Aube de champion
236380	Sceau de l’Aube de templier
236382	Sceau de l’Aube de chevalier
236383	Sceau de l’Aube d’écuyer
236384	Sceau de l’Aube d’initié
236385	Sceau de l’Aube d’aspirant
236386	Sceau de l’Aube de généralissime
236388	Sceau de l’Aube de commandant
236389	Sceau de l’Aube de croisé
236390	Sceau de l’Aube de l’avant-garde
236391	Sceau de l’Aube de champion
236392	Sceau de l’Aube de templier
236393	Sceau de l’Aube de chevalier
236394	Sceau de l’Aube d’écuyer
236395	Sceau de l’Aube d’initié
236396	Sceau de l’Aube d’aspirant
236397	Vestiges de valeur
236398	Atiesh, grand bâton du Gardien
236399	Atiesh, grand bâton du Gardien
236400	Atiesh, grand bâton du Gardien
236401	Atiesh, grand bâton du Gardien
236414	Caisse de fournitures de Terremine endommagée
236417	Âme de tactique
236418	Âme d’ancien combattant
236419	Âme de prédiction de combat
236420	Âme de sanguinaire
236421	Âme de titan
236422	Âme de destruction
236423	Âme de lien par la mort
236424	Âme de sanguinité
236425	Âme de blocage parfait
236426	Âme de sauvagerie
236427	Âme d’inimitié
236428	Âme de déflexion
236429	Âme de revanche
236430	Âme d’assaut incessant
236431	Âme de portefoudre
236432	Âme de sentinelle
236433	Âme de gaucher
236434	Âme de gladiateur
236435	Âme des répliques
236436	Âme d’évitement
236437	Âme de toxicologue
236438	Âme d’exécution
236439	Âme d’opportuniste
236440	Âme de boucherie
236441	Âme de fantôme
236442	Âme de vaurien
236443	Âme des sensations fortes
236444	Âme de scientifique du coutelas
236445	Âme de la traque
236446	Âme d’efficacité
236447	Âme de jongleur de couteau
236448	Âme de maîtrise des ombres
236449	Âme d’équilibriste
236450	Âme de préparation à la bagarre
236451	Âme de ceinture noire
236452	Âme de fourgue
236453	Âme de bretteur
236454	Âme de soif de sang
236455	Âme de transfusion
236456	Âme de raffinement
236457	Âme de décimation
236458	Âme de putrescence
236459	Âme de malveillance
236460	Âme de ténébromancie
236461	Âme de messager du chaos
236462	Âme d’incendiaire
236463	Âme de berger infernal
236464	Âme de seigneur démoniaque
236465	Âme d’exorcisme démoniaque
236466	Âme de souffrance
236467	Âme de flamme spectrale
236468	Âme de dévorechair
236469	Âme de l’abysse
236470	Âme d’engeance du Vide
236471	Âme de lame ombreuse
236472	Âme de ritualiste
236473	Âme d’épandage de douleur
236474	Âme de duperie
236475	Âme de chercheproie
236476	Âme de tir de précision
236477	Âme de harcèlement périlleux
236478	Âme d’alternateur
236479	Âme de toxinologue
236480	Âme de chasseur de primes
236481	Âme de tir d’adresse
236482	Âme de soins des bêtes
236483	Âme de maîtrise des molosses
236484	Âme de domptage des alphas
236485	Âme de vénerie
236487	Âme de représailles
236488	Âme des échos
236489	Âme de flagellation mortelle
236490	Âme de cinétiste
236491	Âme de stratège
236492	Âme de frappe létale
236493	Âme de prompte guérison
236494	Âme de raffinement
236495	Âme de noces
236496	Âme de fidélité
236497	Âme de bon augure
236498	Âme de résonance
236499	Âme de dévotion
236500	Âme d’archevêque
236501	Âme de pénitence
236502	Âme de garde des âmes
236503	Âme d’arpenteur du crépuscule
236504	Âme de brise-esprits
236505	Âme de dispensateur de mort
236506	Âme des fonts des esprits
236507	Âme de zélote
236508	Âme de profanateur inébranlable
236509	Âme de contemption
236510	Âme de porte-peste
236511	Âme de réverbération
236512	Âme de chronosoins
236513	Âme d’aspiration temporelle
236514	Âme de précognition
236515	Âme d’arcaniste
236516	Âme de responsabilité éternelle
236517	Âme de lien de sorts
236518	Âme de taille-charme
236519	Âme d’emprise de l’hiver
236520	Âme de cryomancie
236521	Âme d’évocation
236522	Âme d’élémentaliste
236523	Âme d’armurerie magique
236524	Âme de boutefeu
236525	Âme de convergence embrasée
236526	Âme de brasier perpétuel
236527	Âme de pyromanie
236528	Âme d’ignition
236529	Âme d’embrasement
236530	Âme de blocage parfait
236531	Âme de gardelumière
236532	Âme de défense radieuse
236533	Âme de porte-bouclier
236534	Âme de bastion
236535	Âme de rétribution
236536	Âme de cuirassé
236537	Âme de la garde
236538	Âme de garde-paix
236539	Âme de raffinement
236540	Âme d’exemple
236541	Âme d’inquisition
236542	Âme du souverain
236543	Âme de dominus
236544	Âme de vindication
236545	Âme d’altruisme
236546	Âme d’arbitre
236547	Âme de porte-sceaux
236548	Âme de justicier
236549	Âme de judicature
236550	Âme d’ascendance
236551	Âme de vindicte
236552	Âme d’excommunication
236553	Âme du Porteur de Lumière
236554	Âme de l’exil
236555	Âme de templier
236556	Âme de marche-vent
236557	Âme de maîtrise du bouclier
236558	Âme de protection totémique
236559	Âme d’absorption des chocs
236560	Âme de rempart spirituel
236561	Âme de porteur de Maelström
236562	Âme de marche-lave
236563	Âme d’alpha véritable
236564	Âme de garde-totem
236565	Âme des ancêtres
236566	Âme de tisse-esprit
236567	Âme de marche-vagues
236568	Âme de soins des tempêtes
236569	Âme de prophétie élémentaire
236570	Âme de vitaliste
236571	Âme de soignesprit
236572	Âme de raffinement
236573	Âme de chef
236574	Âme de fureur chargée
236575	Âme de brise-tempête
236576	Âme de la tempête
236577	Âme de fracas sismique
236578	Âme de porte-flamme
236579	Âme de volcan
236580	Âme de la flamme violente
236581	Âme de maîtrise élémentaire
236582	Âme de tribu
236583	Âme de guide spirituel
236584	Âme de l’ancien
236585	Âme des éléments
236586	Âme de sage de lave
236587	Âme de garde ancestral
236588	Âme de corruption
236589	Âme de la patte douce
236590	Âme de férocité
236591	Âme de métamorphose
236592	Âme de territoire
236593	Âme de bête
236594	Âme de lacération
236595	Âme de furie
236596	Âme de mutilation
236597	Âme d’innervation
236598	Âme de nourrice
236599	Âme de tranquillité
236600	Âme de marcherêve
236601	Âme de sylvenier du Bosquet
236602	Âme de sage à plumes
236603	Âme de bienveillance prophétique
236604	Âme de tisse-vie
236605	Âme d’illumination
236606	Âme des instincts prédateurs
236607	Âme de déchirure
236608	Âme de la griffe
236609	Âme de l’orgueil
236610	Âme de barbarie
236611	Âme de frénésie
236612	Âme d’exsanguination
236613	Âme de garde-ronces
236614	Âme de lunatique
236615	Âme de mande-étoiles
236616	Âme de la nuit
236617	Âme des gardiens
236618	Âme du courroux
236619	Âme de grâce
236620	Âme d’ascendance astrale
236621	Âme de mande-comète
236622	Âme de la forêt
236623	Âme d’expertise animaliste
236642	Protège-mains de soigneur
236643	Gants du veilleur de nuit
236644	Garde-mains de deuil
236645	Gantelets de luminomancie
236656	Rune de givre
236657	Branche pourrie de Bubulle
236658	Trophée vertébral de Bubulle
236660	Défense de Troll de Bubulle
236661	Cage thoracique de gaillardise de Bubulle
236662	Rênes de Guerre
236663	Rênes de Conquête
236664	Rênes de Mort
236665	Rênes de Famine
236690	Cape glaciaire
236692	Gants glaciaires
236693	Poignets glaciaires
236694	Gilet glaciaire
236695	Cuirasse plaie-de-glace
236696	Brassards plaie-de-glace
236697	Gantelets plaie-de-glace
236698	Brassards glacécaille
236699	Cuirasse glacécaille
236700	Gantelets glacécaille
236701	Brassards polaires
236702	Tunique polaire
236703	Gants polaires
236704	Poignets givrés
236705	Gants givrés
236706	Gilet givré
236707	Tunique de tueur de morts-vivants
236708	Cuirasse de tueur de morts-vivants
236709	Corselet de tueur de morts-vivants
236710	Garde-poignets de tueur de morts-vivants
236711	Bandelettes de tueur de morts-vivants
236712	Brassards de tueur de morts-vivants
236713	Protège-mains de tueur de morts-vivants
236714	Gantelets de tueur de morts-vivants
236715	Garde-mains de tueur de morts-vivants
236716	Brassards de purification des morts-vivants
236717	Gants de purification des morts-vivants
236718	Robe de purification des morts-vivants
236719	Brassards de purification des morts-vivants
236720	Gants de purification des morts-vivants
236721	Robe de purification des morts-vivants
236722	Brassards de protection contre les morts-vivants
236723	Gants de protection contre les morts-vivants
236724	Robe de protection contre les morts-vivants
236725	Bandelettes de purgation des morts-vivants
236726	Protège-mains de purgation des morts-vivants
236727	Tunique de purification des morts-vivants
236728	Bandelettes de purification des morts-vivants
236729	Protège-mains de purification des morts-vivants
236730	Tunique de purification des morts-vivants
236731	Bandelettes de protection contre les morts-vivants
236732	Protège-mains de protection contre les morts-vivants
236733	Tunique de protection contre les morts-vivants
236734	Garde-poignets de purgation des morts-vivants
236735	Garde-mains de purgation des morts-vivants
236736	Corselet de purgation des morts-vivants
236737	Garde-poignets de protection contre les morts-vivants
236738	Garde-mains de protection contre les morts-vivants
236739	Corselet de protection contre les morts-vivants
236740	Garde-poignets de purification des morts-vivants
236741	Garde-mains de purification des morts-vivants
236742	Corselet de purification des morts-vivants
236743	Brassards de purification des morts-vivants
236744	Gantelets de purification des morts-vivants
236745	Cuirasse de purification des morts-vivants
236746	Brassards de protection contre les morts-vivants
236747	Gantelets de protection contre les morts-vivants
236748	Cuirasse de protection contre les morts-vivants
236750	Cœur du Destin funeste
236782	Collier de Sairuh
236786	Cœur du Destin funeste
236864	Carquois d’âme de givre
236869	Giberne d’âme de givre
236871	Senseur à censeur navrant
236872	Schéma : senseur à censeur navrant
236878	Relique mystérieuse
236879	Relique mystérieuse
236880	Relique mystérieuse
237011	Clé de la herse
237020	Insigne écarlate
237023	Arbuste improvisé
237024	Place d’opéra
237037	Carte de membre du club de la Haute
237041	Tome de fusée éclairante enchantée
237143	Ordres de la commandante
237163	Crâne d’ancien héros
237261	Sable fin
237263	Sac de fournitures
237275	Heaume plaie-de-glace
237277	Jambières givrées
237278	Le Purificateur
237279	Amulette de l’Aube
237280	Médaillon de l’Aube
237281	Brassards d’espoir
237282	Brassards de subterfuge
237283	Talisman d’ascendance
237284	Sac de fournitures
237285	Bague de résolution
237286	Bague de piété
237287	Dernière chance de Verimonde
237288	Heaume en cuir sanctifié
237289	Jambières du chassepeste
237290	Jambières plaie-de-glace
237291	Jambières glaciaires
237292	Jambières polaires
237293	Jambières glacécaille
237294	Étreinte de glace de Ramaladni
237302	Tabard de l’enclave Écarlate
237381	Anneau désacralisé
237386	Caisse de fournitures de Terremine marquée par la guerre
237504	Cargaison d’approvisionnement
237512	Lame de l’inquisition
237577	Totem de puissance impie
237773	Mot de dégel
237810	Pierre à aiguiser consacrée lestée
237814	Cuissards de sentinelle lamellaires
237815	Jambières de sentinelle en soie
237817	Pantalon de sentinelle en peau de lézard
237818	Pantalon de sentinelle en cuir
237819	Jambières de sentinelle en anneaux
237820	Jambière de voltigeur en soie
237821	Pantalon de voltigeur en peau de lézard
237822	Pantalon de voltigeur en cuir
237823	Jambières de voltigeur en mailles
237824	Jambières de voltigeur en anneaux
237825	Cuissards de sentinelle en plaques
237826	Jambières de voltigeur en plaques
238234	Huile de sorcier bénite
238241	Pierre à aiguiser consacrée
238264	Chaperon d’augure écarlate
238265	Mantelet d’augure écarlate
238266	Vêtements d’augure écarlate
238267	Crispins d’augure écarlate
238268	Mitaines d’augure écarlate
238269	Attache d’augure écarlate
238270	Jambières d’augure écarlate
238271	Semelles d’augure écarlate
238272	Bandana d’infiltrateur écarlate
238273	Protège-épaules d’infiltrateur écarlate
238274	Gilet d’infiltrateur écarlate
238275	Brassards d’infiltrateur écarlate
238276	Gants d’infiltrateur écarlate
238277	Ceinture d’infiltrateur écarlate
238278	Chausses d’infiltrateur écarlate
238279	Chaussures d’infiltrateur écarlate
238280	Camail de chasseur écarlate
238281	Espauliers de chasseur écarlate
238282	Chaîne de chasseur écarlate
238283	Garde-poignets de chasseur écarlate
238284	Garde-mains de chasseur écarlate.
238285	Fermoir de chasseur écarlate
238286	Garde-jambes de chasseur écarlate
238287	Bottes de chasseur écarlate
238288	Casque de soldat écarlate
238289	Spallières de soldat écarlate
238290	Pansière de soldat écarlate
238291	Protecteurs de soldat écarlate
238292	Poignes de soldat écarlate
238293	Sangle de soldat écarlate
238294	Cuissards de soldat écarlate
238295	Croquenots de soldat écarlate
238298	Patron : chaperon d’augure écarlate
238299	Patron : mantelet d’augure écarlate
238300	Patron : vêtements d’augure écarlate
238301	Patron : crispins d’augure écarlate
238302	Patron : mitaines d’augure écarlate
238303	Patron : attache d’augure écarlate
238304	Patron : jambières d’augure écarlate
238305	Patron : semelles d’augure écarlate
238306	Patron : bandana d’infiltrateur écarlate
238307	Patron : protège-épaules d’infiltrateur écarlate
238308	Patron : gilet d’infiltrateur écarlate
238309	Patron : brassards d’infiltrateur écarlate
238310	Patron : gants d’infiltrateur écarlate
238311	Patron : ceinture d’infiltrateur écarlate
238312	Patron : chausses d’infiltrateur écarlate
238313	Patron : chaussures d’infiltrateur écarlate
238314	Patron : camail de chasseur écarlate
238315	Patron : espauliers de chasseur écarlate
238316	Patron : chaîne de chasseur écarlate
238317	Patron : garde-poignets de chasseur écarlate
238318	Patron : garde-mains de chasseur écarlate.
238319	Patron : fermoir de chasseur écarlate
238320	Patron : garde-jambes de chasseur écarlate
238321	Patron : bottes de chasseur écarlate
238322	Plans : casque de soldat écarlate
238323	Plans : spallières de soldat écarlate
238324	Plans : pansière de soldat écarlate
238325	Plans : protecteurs de soldat écarlate
238326	Plans : poignes de soldat écarlate
238327	Plans : sangle de soldat écarlate
238328	Plans : cuissards de soldat écarlate
238329	Plans : croquenots de soldat écarlate
238348	Hache sectionneuse
238349	Jambières en peau d’abomination
238350	Dague focale de Scorn
238351	L’Étreinte glaciale
238352	Sautoir glacé de Scorn
238353	Mantelet de dame Falther’ess
238354	Doigt de dame Falther’ess
238355	Chaînes de la liche
238356	Baudrier de Balzaphon
238357	Bâton de Balzaphon
238358	Fémur de Noirbois
238360	Targe du seigneur Noirbois
238361	Lame du seigneur Noirbois
238362	Brassards de guérison
238363	L’Étreinte de l’ombre
238364	Cape de Revanchion
238637	Steak de rôdeur
238638	Filet de flanc
238639	Omelette du Lever de soleil
238641	Festin de loche à taches claires
238642	Grand banquet de homard
238645	Recette : steak de rôdeur
238646	Recette : filet de flanc
238647	Recette : omelette du Lever de soleil
238649	Recette : festin de loche à taches claires
238650	Recette : grand banquet de homard
238681	Sac poussiéreux
238687	Maillet de l’Assaut
238734	Boîte bricolée : téléporteur
238735	Boîte bricolée : nitro-survolteurs
238736	Boîte bricolée : déplacement magnétique
238737	Boîte bricolée
238781	Transporteur semi-sécurisé : Nouvelle-Avalon
238782	Schéma : boîte bricolée
238783	Schéma : boîte bricolée : téléporteur
238784	Schéma : boîte bricolée : nitro-survolteurs
238785	Schéma : boîte bricolée : déplacement magnétique
238786	Schéma : bricolage : téléporteur
238787	Schéma : bricolage : nitro-survolteurs
238788	Schéma : bricolage : déplacement magnétique
238789	Schéma : transporteur semi-sécurisé – Nouvelle-Avalon
238794	Restes peu ragoûtants
238811	Pomme juteuse
238830	Téléscopomme
238831	Corde de pommes
238899	Assortiment de poissons
238925	Carquois écarlate
238926	Giberne écarlate
238927	Patron : carquois écarlate
238928	Patron : giberne écarlate
238935	Viande légèrement contaminée
238945	Caladroche
238960	Caisse de l’intendant
238961	Caladbolg
238985	Caisse lourde
239010	Garde de Porte-cendres
239011	Éclat de lumière cristallisée
239012	Fragment de lumière cristallisée
239013	Hache cristalline
239016	Sels sacrés
239017	Épices exquises
239021	Livre de recettes de Carrie
239060	La volonté de la montagne
239092	Annonce affreusement ampoulée
239097	Clé de la cathédrale
239117	Calice des Croisés
239119	Flèche sacrée
239123	Monstre – BOW_1H_STANDARD_C_01 – Rouge
239147	Sac à dos de croisade
239148	Sac en étoffe de l’Aube cramoisie
239149	Patron : sac à dos de croisade
239150	Patron : sac en étoffe de l’Aube cramoisie
239159	S03 – Enclave Écarlate – Bouclier de capitaine
239196	Lame de Sancteforge détruite
239197	Lame reforgée du Porte-Cendres
239215	Emblème calciné
239216	Fer de sancteforge
239218	Notes du sculpte-pierre
239219	Emblème de Porte-cendres
239222	Schéma : arbuste improvisé
239223	Décor de maison
239225	Plume élégante
239246	Liste de courses de Foiramorce
239248	Coffret écarlate
239292	Notes de Forgewright
239301	Porte-cendres corrompue
239302	Ceinture d’uniforme écarlate
239316	Samophlange de triangulation
239512	Poignets de brise-lumière
239513	Ceinture de brise-lumière
239514	Poignes de brise-lumière
239515	Grèves de brise-lumière
239516	Épaulières de brise-lumière
239517	Grand heaume de brise-lumière
239518	Tassettes de brise-lumière
239519	Thorax de brise-lumière
239520	Brassards de brise-lumière
239521	Sangle de brise-lumière
239522	Gantelets de brise-lumière
239523	Solerets de brise-lumière
239524	Espauliers de brise-lumière
239525	Casque de brise-lumière
239526	Cuissards de brise-lumière
239527	Cuirasse de brise-lumière
239529	Cuirasse de Traquelaube
239530	Grèves de Traquelaube
239531	Gantelets de Traquelaube
239532	Visière de Traquelaube
239533	Jambières de Traquelaube
239534	Espauliers de Traquelaube
239535	Ceinture de Traquelaube
239536	Protège-bras de Traquelaube
239537	Bottes de Traquelaube
239538	Ceinturon de Traquelaube
239539	Garde-mains de Traquelaube
239540	Chapel de Traquelaube
239541	Garde-jambes de Traquelaube
239542	Spallières de Traquelaube
239543	Tunique de Traquelaube
239544	Garde-poignets de Traquelaube
239547	Garde-poignets de l’âme en vêpres
239548	Corselet de l’âme en vêpres
239549	Poignes de l’âme en vêpres
239550	Masque de l’âme en vêpres
239551	Jambières de l’âme en vêpres
239552	Mantelet de l’âme en vêpres
239553	Bottines de l’âme en vêpres
239554	Ceinture de l’âme en vêpres
239555	Brassards de l’âme en vêpres
239556	Sangle de l’âme en vêpres
239557	Gantelets de l’âme en vêpres
239558	Solerets de l’âme en vêpres
239559	Espauliers de l’âme en vêpres
239560	Casque de l’âme en vêpres
239561	Cuissards de l’âme en vêpres
239562	Cuirasse de l’âme en vêpres
239565	Atours de révélation
239572	Bottes de révélation
239574	Mains de révélation
239575	Couronne de révélation
239577	Pantalon de révélation
239581	Mantelet de révélation
239582	Ceinturon de révélation
239583	Poignets de révélation
239584	Gants de révélation
239585	Diadème de révélation
239586	Protège-épaules de révélation
239587	Jambières de révélation
239588	Manchettes de révélation
239589	Sandales de révélation
239590	Ceinture de révélation
239591	Robe de révélation
239618	Monstre – Épée 1M – Épée de vainqueur (Alt)
239688	Monstre – Lance 2M – Cavalier écarlate – Lance
239694	Pacte de la Lumière
239695	Palefroi écarlate
239696	Garde de Porte-Cendres
239698	Tissu en étoffe de l’Aube
239706	Solerets consacrés
239707	Casque consacré
239708	Espauliers consacrés
239709	Cuissards consacrés
239710	Sandales consacrées
239712	Protège-épaules consacrés
239714	Diadème consacré
239715	Robe consacrée
239716	Gants consacrés
239718	Ceinture consacrée
239719	Manchettes consacrées
239721	Jambières consacrées
239722	Garde-poignets consacrés
239726	Bottes consacrées
239729	Chapel consacré
239730	Garde-mains consacrés
239731	Tunique consacrée
239756	Ceinturon consacré
239757	Garde-jambes consacrés
239758	Spallières consacrées
239759	Brassards consacrés
239760	Sangle consacrée
239761	Cuirasse consacrée
239762	Gantelets consacrés
239764	Feuillelame cramoisie
240018	Manuel de bricolage de Foiramorce
240020	Garde-jambes d’inquisition
240021	Spallières d’inquisition
240022	Bottes d’inquisition
240023	Protège-bras d’inquisition
240024	Ceinture d’inquisition
240025	Plaques d’épaule d’inquisition
240026	Jambières d’inquisition
240027	Casque d’inquisition
240028	Gants d’inquisition
240029	Grèves d’inquisition
240030	Cuirasse d’inquisition
240031	Brassards d’inquisition
240032	Sangle d’inquisition
240033	Espauliers d’inquisition
240034	Cuissards d’inquisition
240035	Couronne d’inquisition
240036	Gantelets d’inquisition
240037	Solerets d’inquisition
240038	Corselet d’immolation
240039	Tunique d’inquisition
240040	Chapel d’inquisition
240041	Garde-mains d’inquisition
240042	Garde-poignets d’inquisition
240043	Ceinturon d’inquisition
240044	Bandelettes de Fireleaf
240045	Sangle de Fireleaf
240046	Mantelet de Fireleaf
240047	Pantalon de Fireleaf
240048	Chaperon de Fireleaf
240049	Mitaines de Fireleaf
240050	Bottes de Fireleaf
240051	Atours de Fireleaf
240052	Manchettes de Fireleaf
240053	Ceinture de Fireleaf
240054	Protège-épaules de Fireleaf
240055	Jambières de Fireleaf
240056	Diadème de Fireleaf
240057	Gants de Fireleaf
240058	Sandales de Fireleaf
240059	Robe de Fireleaf
240060	Couvre-bras de garde des chemins
240061	Écharpe de garde des chemins
240062	Protège-épaules de garde des chemins
240063	Chausses de garde des chemins
240064	Capuche de garde des chemins
240065	Poignes de garde des chemins
240066	Croquenots de garde des chemins
240067	Gilet de garde des chemins
240068	Manchettes de garde des chemins
240069	Corde de garde des chemins
240070	Mantelet de garde des chemins
240071	Kilt de garde des chemins
240072	Chaperon de garde des chemins
240073	Mitaines de garde des chemins
240074	Sandales de garde des chemins
240075	Cuirs de garde des chemins
240076	Brassards de garde des chemins
240077	Sangle de garde des chemins
240078	Espauliers de garde des chemins
240079	Jambières de garde des chemins
240080	Coiffe de garde des chemins
240081	Gantelets de garde des chemins
240082	Solerets de garde des chemins
240083	Armure de garde des chemins
240084	Garde-poignets de garde des chemins
240085	Ceinturon de garde des chemins
240086	Spallières de garde des chemins
240087	Garde-jambes de garde des chemins
240088	Chapel de garde des chemins
240089	Garde-mains de garde des chemins
240090	Bottes de garde des chemins
240091	Tunique de garde des chemins
240092	Tunique d’écraseur d’âme
240093	Bottes d’écraseur d’âme
240095	Garde-mains d’écraseur d’âme
240096	Chapel d’écraseur d’âme
240097	Garde-jambes d’écraseur d’âme
240098	Spallières d’écraseur d’âme
240099	Ceinturon d’écraseur d’âme
240100	Garde-poignets d’écraseur d’âme
240101	Corselet d’écraseur d’âme
240102	Solerets d’écraseur d’âme
240103	Gants d’écraseur d’âme
240104	Ventaille d’écraseur d’âme
240105	Cuissards d’écraseur d’âme
240106	Espauliers d’écraseur d’âme
240107	Sangle d’écraseur d’âme
240108	Brassards d’écraseur d’âme
240109	Étreinte d’écraseur d’âme
240110	Grèves d’écraseur d’âme
240122	Mitaines d’écraseur d’âme
240123	Couronne d’écraseur d’âme
240124	Kilt d’écraseur d’âme
240125	Mantelet d’écraseur d’âme
240126	Corde d’écraseur d’âme
240127	Manchettes d’écraseur d’âme
240128	Armure d’écraseur d’âme
240129	Bottines d’écraseur d’âme
240130	Poignes d’écraseur d’âme
240131	Casque d’écraseur d’âme
240132	Bâton de test
240134	Jambières d’écraseur d’âme
240135	Épaulettes d’écraseur d’âme
240136	Ceinture d’écraseur d’âme
240137	Protège-bras d’écraseur d’âme
240138	Robe hérétique
240139	Sandales hérétiques
240140	Gants hérétiques
240141	Capuche hérétique
240142	Jambières hérétiques
240143	Protège-épaules hérétiques
240144	Ceinture hérétique
240145	Manchettes hérétiques
240146	Atours hérétiques
240147	Garde-mains hérétiques
240148	Chaperon hérétique
240149	Pantalon hérétique
240150	Mantelet hérétique
240151	Sangle hérétique
240152	Garde-poignets hérétiques
240153	Bottes hérétiques
240174	Solistra, Croc de la première lueur
240195	Épée invisible
240217	Objet de monstre – Stave_2H_Jeweled_A_02 – Rouge
240742	Monstre – 1m, épée courte, rouge
240832	Glande nivifasciente
240835	Caisse de ravitaillement de Reflet-de-Lune
240836	Sifflet de Thisalee
240837	Cordes du destin
240839	Thal’kituun, l’Invité invisible
240841	Garde de la grande commandante
240842	Putrescent écarlate
240843	Pistolet de départ
240844	Tison de Putrescin
240845	Prototype d’aimant
240846	Ferraille magnétique
240848	Détritus de Nordrassil
240849	Bâton de la clairière
240850	Marteau lumepoing
240851	Régicide
240852	Fendoir cramoisi
240853	Réginicide
240854	Pitié
240919	Ravagane
240920	Léogan
240921	Porte-choc écarlate
240922	Tromperie
240923	Duplicité
240924	Arme d’hast de la Bête
240936	Porte-Cendres inerte
240945	Pointe de tarte aux pommes de Carrie
240997	Éperon de Fratley
240998	Lame soporifique
241001	Trépas de Tyr
241002	Vestiges du Rouge
241003	Mirage, bâtonnet d’illusion
241004	Dilemme
241006	Cime de sacrifice
241008	Condamnation
241011	Grand bâton de fidélité
241012	Baguette de réanimation
241015	Égide du Bastion écarlate
241017	Folie des démons
241018	Cœur nathrezim
241020	Journal complété de Putrescin
241021	La Lumière
241022	Cape du point du jour
241023	Drapé de l’infâme
241024	Pèlerine du commandant écarlate
241025	Drapeau de l’amiral brisé
241026	Châle de cardinal
241027	Garde du bouclier protecteur
241028	Jonc nathrezim
241029	Bague de Baelin
241030	Anneau de fraternité de Mason
241031	Promesses de Barthalomew
241032	Anneau de résurrection
241034	Cœur de lumière
241037	Expérience abandonnée
241038	Didjeridou de sire Dornel
241039	Infusion d’âmes
241068	Étendard de Stiltz
241069	Chaîne asphyxiante
241070	Espoir d’Hérode
241071	Talisman du vaurien écarlate
241072	Flacon de pus
241073	Toucher de lumière
241074	Heaume de la Croisade rouge
241075	Heaume du destructeur déchaîné
241076	Capuche congréganiste
241077	Mitre de cardinal
241078	Voile de l’embaumé
241079	Le poids du monde
241080	Espauliers de Hérode
241081	Porte-Cendres corrompue
241082	Porte-Cendres
241083	S03 – Enclave Écarlate – Épée 2m Raid
241084	S03 – Enclave Écarlate – Épée d’Herod – Normale
241085	S03 – Enclave Écarlate – Épée 1m
241086	Grand bouclier écarlate
241087	Bâton écarlate
241088	Bâton écarlate
241089	Dague écarlate
241090	Bardiche écarlate
241091	Masse écarlate
241092	Lame écarlate
241120	S03 – Enclave Écarlate – Épée d’Herod – Fusion
241121	Dague ressuscitée
241122	Couteau ressuscité
241123	Dague ressuscitée
241124	Couteau ressuscité
241128	Tas de portiporteurs
241152	Épaulières forgées par l’aube
241153	Mantelet de Doan
241154	Mantelet en peau-d’ours
241156	Robes chancreuses
241157	Pansière écarlate
241158	Chaîne de l’abandonné
241159	Atours de monastère
241160	Cotte de mailles usée par l’aube
241161	Cuirasse de templier
241162	Cuirs bénis par le soleil
241163	Brassards d’ensoleillement
241164	Cuirs d’Argent au rebut
241165	Couvre-bras de pénitence
241166	Bandes rayées par l’aube
241167	Menottes de prisonnier
241168	Poignes d’ensoleillement
241169	Prototype de nitro-survolteurs
241170	Protecteurs de l’enclave
241171	Gants des âmes évanouies
241172	Gantelets verrouillés de Caldoran
241173	Couvre-taille du haut sorcier
241174	Ceinturon du champion ressuscité
241175	Ceinture à outils de tortionnaire
241176	Trépas de Diesalven
241177	Kilt de l’arcaniste écarlate
241178	Plaque de douleur infrangible
241179	Jambières de la catastrophe
241180	Jambières en lumécailles
241181	Jambières usées par l’aube en anneaux
241182	Garde-jambes de templier en plaques
241183	Marchecendres
241184	Sandales du salut
241185	Bottes de dressage d’ours
241186	Bottes en mailles écarlates polies
241187	Bottines de guerre cramoisies
241190	Appeau à oiseau
241191	Formule : enchantement d’arme (Grand croisé)
241195	Formule : enchantement d’arme à deux mains (Grand arcaniste)
241201	Formule : enchantement d’arme (Grand sorcier)
241212	Canon gloussant
241241	Doublon porte-bonheur
241613	Inutilisé
241629	Boulet de canon écarlate
241649	Gantelets de la garde d’Hillsbrad
241650	Potion de soins majeure décolorée
241651	Recette : potion de soins majeure décolorée
241652	Cœur de bête décoloré
241653	Lame chauffée
241654	Porte-Cendres inerte
241655	Potion de soins manipulée sans soin
241656	Potion de soins manipulée sans soin
241657	Lame trempée
242018	Cœur sanglant des Maleterres
242224	Panier de cœurs
242256	Sacoche de bombes incendiaires
242257	Échantillon alchimique mystérieux
242258	Notes de recherche
242266	Protections de pros
242267	D’arcaniste à archimage
242268	Donnez un enchantement à un Croisé…
242269	Brillance du Grand sorcier
242270	Brillance du Grand arcaniste
242271	Brillance du Grand croisé
242310	Main de la justice renaissante
242311	Charme de Leonid
242312	Sceau de la famille Barthalomew
242313	Journal du Révéré
242314	Cendres de la Croisade déchue
242315	Cendres d’arrogance
242316	Poussière du rebelle
242317	Livre de prières profané
242319	Nouveaux échantillons de peste
242320	Nouveaux échantillons de peste
242361	Formule : enchantement d’arme à deux mains (Grand Inquisiteur)
242362	Brillance du Grand Inquisiteur
242363	Qui, quoi, où, quand et au bûcher ! Les cinq clés d’une inquisition réussie
242364	Tendon de dragon de lumière adulte
242365	Aile de Balnazzar
242366	Destin inexorable
242367	Aile et corde
242425	Page de journal arrachée – Page 1
242426	Page de journal arrachée – Page 2
242427	Journal de Putrescin
242428	Page de journal arrachée – Page 3
242429	Journal de Putrescin
242430	Page de journal arrachée – Page 4
242431	Page de journal arrachée – Page 5
242432	Journal de Putrescin
242433	Page de journal arrachée – Page 6
242434	Journal de Putrescin
242435	Journal de Putrescin
242436	Journal de Putrescin
242465	Fragment de calice chahuté
242793	Canon portable
243010	Porte-Cendres corrompue
243064	Grand bâton
243065	Baguette brisée
243177	Jouet ingénieux
243198	Lunette de précision avicole
243229	Pierre de foyer de l’Aube
243230	Lame sancteforge détruite
243345	Grand bâton
244353	Lunette de précision avicole
244460	Caladbolg
245675	Clé de la porte intérieure des Gordok
246055	Poignes d’inquisition
246056	Bracières d’inquisition
246057	Croquenots d’inquisition
246058	Pantalon de plaques d’inquisition
246059	Corde d’inquisition
246060	Cuirasse d’inquisition
246061	Épaulettes d’inquisition
246062	Ventaille d’inquisition
]==]
