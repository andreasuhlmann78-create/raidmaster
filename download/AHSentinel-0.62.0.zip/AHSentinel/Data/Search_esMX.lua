-- AHSentinel - Suchindex (esMX), aus Names_esMX.lua erzeugt. Nicht von Hand ändern.
AHAnalyzerPro_NameSearch = AHAnalyzerPro_NameSearch or {}
AHAnalyzerPro_NameSearch["esMX"] = [==[

25	espada corta desgastada
35	baston doblado
36	maza desgastada
37	hacha desgastada
38	camisa de recluta
39	pantalones de recluta
40	botas de recluta
43	botas de escudero
44	pantalones de escudero
45	camisa de escudero
47	zapatos de asaltante de caminos
48	pantalones de asaltante de caminos
49	camisa de asaltante de caminos
51	botas de neofito
52	pantalones de neofito
53	camisa de neofito
55	botas de aprendiz
56	toga de aprendiz
57	toga de acolito
59	zapatos de acolito
60	guerrera a capas
61	pantalones de cuero enano
79	calzones de pano enano
80	zapatos de pelaje suave
85	jubon de cuero sucio
117	cecina dura
118	pocion de sanacion menor
120	pantalones de maton
121	botas de maton
127	camisa de trampero
129	botas de trampero bastas
139	pantalones de camorrista
140	botas de camorrista
147	pantalones de trampero bastos
148	camisa de trampero basta
153	falda primitiva
154	cubretorso primitivo
159	agua de manantial refrescante
182	cabeza de garrick
193	jubon de pano andrajoso
194	pantalones de pano andrajoso
195	botas de pano andrajoso
200	jubon de pano grueso
201	pantalones de pano grueso
202	zapatos de pano grueso
203	guantes de pano grueso
209	pantalones de cuero sucios
210	botas de cuero sucias
236	armadura de cuero curado
237	pantalones de cuero curado
238	botas de cuero curado
239	guantes de cuero curado
285	jubon de malla de escamas
286	pantalones de malla de escamas
287	botas de malla de escamas
414	pincho de dalaran
422	queso enano
537	escama frenesi mate
555	plumas de buitre ferreas
556	pico de aguila ratonera
647	destino
710	brazales de la milicia popular
711	guantes de pano andrajoso
714	guantes de cuero sucios
718	guantes de malla de escamas
719	guantes de cuidador de conejos
720	guantes de camorrista
723	higado de dentosangre
724	pastel de higado de dentosangre
725	garra gnoll
727	espada corta despuntada
728	receta estofado de los paramos de poniente
729	carne fibrosa de buitre
730	ojo de murloc
731	morro de dentosangre
732	okra
733	estofado de los paramos de poniente
735	medallones de rolf y malakai
737	agua de manantial sagrado
738	saco de cebada
739	saco de maiz
740	saco de centeno
742	una rama de sicomoro
743	monton de roble carbonizado
744	petaca de cebatruenos
745	documentos del alguacil mcbride
748	marcador de armaduras de ventormenta
750	carne de lobo dura
752	panuelo de arpillera roja
753	espada corta faucedraco
754	espada corta de venganza
755	vela derretida
756	pico de tunel
763	brazales cubiertos de hielo
765	hojaplata
766	maza rebordeada
767	baston largo bo
768	hacha de lenador
769	trozo de carne de jabali
770	diente de crocolisco puntiagudo
771	colmillo de jabali astillado
772	vela grande
773	polvo de oro
774	malaquita
776	vendetta
777	diente de merodeador
778	pico de excavacion de kobold
779	concha lustrosa
780	aletas de murloc rotas
781	martillo gnoll de piedra
782	banda gnoll pintada
783	pellejo ligero
785	marregal
787	caballa de piel escurridiza
789	martillo de batalla recio
790	hacha de silvicultor
791	baston nudoso de fresno
792	sandalias tricotadas
793	guantes tricotados
794	pantalones tricotados
795	guerrera tricotada
796	botas de cuero ferreo
797	guantes de cuero ferreo
798	pantalones de cuero ferreo
799	jubon de cuero ferreo
804	costal azul grande
805	faltriquera roja pequena
809	cuchilla de sangre
810	martillo del viento del norte
811	hacha del bosque profundo
812	baston madera brillante resplandeciente
813	pinon roto
814	frasco de aceite
816	hoja de mano pequena
818	ojo de tigre
820	hoja cercenadora
821	jubon de cuero zarparrio
826	hacha zarparrio tosca
827	porra maligna
828	faltriquera azul pequena
829	panuelo de cuero rojo
832	cinturon de plata defias
833	piedra de vida
835	red de cuerda grande
837	armadura de tejido pesado
838	pantalones de tejido pesado
839	guantes de tejido pesado
840	zapatos de tejido pesado
841	reloj de bolsillo de cejade
843	botas de cuero curtido
844	guantes de cuero curtido
845	pantalones de cuero curtido
846	chaleco de cuero curtido
847	armadura de malla de anillas
848	pantalones de malla de anillas
849	botas de malla de anillas
850	guantes de malla de anillas
851	alfanje
852	maza
853	hachuela
854	baston de intendente
856	bolsa de cuero azul
857	costal rojo grande
858	pocion de sanacion inferior
859	camisa de pano refinado
860	botas de hidalgo
862	anillo runico
863	segadora penumbra
864	tizona de caballero
865	maza plomiza
866	baston de monje
867	guantes de poderio sagrado
868	custodiador candente
869	tizona deslumbrante
870	hacha de guerra ignea
871	hacha aluvion
872	cercenarrocas
873	baston de jordan
875	invocacion de caballo marron
876	rodela de madera desgastada
878	hilera del tamano de un puno
880	baston de horrores
884	costilla de necrofago
885	hacha de metal negro
886	espada corta de metal negro
887	kilo de carne
888	guantes de batalla naga
889	una carta polvorienta sin enviar
890	baston de corista retorcido
892	guantes de lanzamiento gnoll
893	colmillo de lobo temible
895	calavera de huargen
896	colmillo de huargen
897	brazales de lobo demente
899	colmillo de telarana venenosa
901	deptecated white stallion summoning mount
910	una carta sin entregar
911	rama de arbol de maderaferrea
913	espada de ogro enorme
914	armadura de anillas de ogro grande
915	panuelo de seda rojo
916	una pagina de diario rota
918	talega de pellejo descarriado
920	maza con pinchos maligna
921	una pagina de diario borrada
922	dalle dacio
923	tizona
924	gran maza
925	mayal
926	hacha de batalla
927	hacha doble
928	baston largo
929	pocion de sanacion
932	alforjas de corcel vil
933	mochila grande
934	segadora de stalvan
935	espada corta de guardia nocturno
936	maza de medianoche
937	baston negro del bosque del ocaso
938	paginas de diario embarrado
939	una pagina de un diario manchada de sangre
940	togas de perspicacia
942	sortija helada
943	baston de celador
944	baston de mago elemental
945	espada de las sombras
948	espada naturaleza
954	pergamino de fuerza
955	pergamino de intelecto
957	envio de william
961	hierba de sanacion
962	pastel de tripa de cerdo
966	escrito sobre escudo contra escarcha
967	escrito sobre resguardo contra la escarcha
968	escrito sobre explosion de fuego
973	escrito sobre bola de fuego ii
974	escrito sobre armadura de escarcha ii
975	escrito sobre cadenas de hielo
976	escrito sobre eliminar maldicion
980	escrito sobre escudo contra escarcha ii
981	collar de bernice
983	fajin de lino rojo
985	escrito sobre liberacion de khadgar
986	escrito sobre descarga de escarcha ii
989	escrito sobre nova de escarcha
992	escrito sobre bola de fuego iii
994	escrito sobre armadura de hielo
997	espada entorpecedora de fuego
1002	escrito sobre invisibilidad inferior
1004	escrito sobre cadenas de hielo ii
1006	collera de laton
1008	espada bien usada
1009	martillo compacto
1010	baston corto nudoso
1011	hacha afilada
1013	remache de hierro
1015	costillar de lobo magro
1017	kebab de lobo sazonado
1019	panuelo de lino rojo
1029	tablilla de totem serpiente
1030	tablilla de voluntad ferrea
1031	tablilla de explosion de arrabio
1032	tablilla de totem agitador
1033	tablilla de veneno de anulacion
1034	tablilla de fuerza eterna
1035	tablilla de llamar a espiritu
1036	tablilla de enfermedad de anulacion
1037	tablilla de descarga de relampagos ii
1038	tablilla de restauracion ii
1041	cuerno del lobo negro
1048	tablilla de escudo de relampagos ii
1049	tablilla de purgar
1052	tablilla de armadura de espiritu ii
1053	tablilla de explosion de arrabio ii
1057	tablilla de restauracion iii
1058	tablilla de descarga de relampagos iii
1061	tablilla de veneno de anulacion ii
1063	tablilla de enfermedad de anulacion ii
1072	luna llena
1074	punta de pata de arana dura
1075	colgante pielsombra
1076	anillo de renegado defias
1077	anillo magico defias
1080	carne de condor dura
1081	carne de arana crujiente
1082	estofado crestagrana
1083	glifo de azora
1084	codice de renovar
1085	codice de vision mental
1086	codice de fuego interno
1087	codice de palabra de las sombras dolor
1088	codice de renovar ii
1089	codice de enfermedad de anulacion
1090	codice de resurreccion
1091	codice de punicion sagrada ii
1092	codice de curacion inferior ii
1093	codice de eliminar maldicion
1095	codice de disipar magia
1096	codice de palabra de las sombras dolor ii
1100	codice de punicion sagrada iii
1101	codice de renovar v
1102	codice de curacion inferior iii
1105	codice de renovar vi
1108	codice de renovar iii
1109	codice de dominacion
1111	codice de dormir
1112	codice de palabra sagrada entereza ii
1113	pan magico
1114	pan de centeno magico
1116	anillo de plata pura
1119	licor embotellado
1121	patas de lince
1127	carga cegadora
1129	colmillo de necrofago
1130	vial de veneno de arana
1131	totem de castigo
1132	cuerno del lobo gris
1133	cuerno del lobo invernal
1134	cuerno del lobo grisaceo
1136	tratado favor divino ii
1138	tratado favor divino
1139	tratado limpieza
1141	tratado luz sagrada ii
1144	tratado escudo divino
1146	tratado resurreccion
1149	tratado sello de poderio ii
1150	tratado purificar
1151	tratado luz sagrada iii
1154	cinturon de la milicia popular
1155	vara del insomne
1156	anillo con una piedra magnifica
1158	garrote de metal solido
1159	lanza larga de intendente de milicia
1161	espada corta de milicia
1164	escrito de sam
1166	rodela abollada
1167	tarja pequena
1168	escudo llamacraneos
1169	escudo de craneo negro
1171	toga bien cosida
1172	antorcha de grisillo
1173	botas deterioradas
1175	un diente de oro
1176	sales aromaticas
1177	aceite de olaf
1178	cohete explosivo
1179	leche fria como el hielo
1180	pergamino de aguante
1181	pergamino de espiritu
1182	brazales de tachas de laton
1183	guardamunecas elasticos
1187	collera con pinchos
1189	anillo de sobrestante
1190	capa de sobrestante
1191	bolsa de canicas
1193	rodela a rayas
1194	espada bastarda
1195	pala de mineria de kobold
1196	tabar
1197	maza gigante
1198	mandoble
1199	piedra de alma cargada
1200	escudo de madera grande
1201	escudo romboide mate
1202	escudo de pared
1203	egida de ventormenta
1204	la torre verde
1205	zumo de melon
1206	agata musgosa
1207	murfestar
1208	carta de amor de maybell
1210	gema de las sombras
1211	arnes de guerra gnoll
1212	gapo gnoll
1213	brazales afines a los gnoll
1214	castigador gnoll
1215	faja de sujecion
1216	brazales escarchados
1217	recompensa desconocida
1218	garrote de guerra gnoll pesado
1219	machete crestagrana
1220	hacha lupina
1221	escama de vientre de cria
1222	diente partido
1224	grimorio captar demonios
1228	grimorio hervor de sangre
1229	grimorio crear piedra de alma
1231	grimorio descarga de las sombras ii
1232	grimorio piel de demonio ii
1238	grimorio miedo
1239	grimorio de succion de mana
1243	grimorio descarga de las sombras iii
1244	grimorio armadura demoniaca
1245	grimorio inmolar ii
1246	grimorio aliento demoniaco
1250	grimorio detectar invisibilidad inferior
1251	venda de lino
1252	nota de la abuela pedregosa
1254	piedra de fuego inferior
1256	hoja de alga de cristal
1257	licor de invisibilidad
1259	jyoo test item
1260	cabeza de tharil zun
1261	orbe de medianoche
1262	barril de cerveza cebatruenos
1263	rebanasesos
1264	azotacabezas
1265	puya de escorpion
1270	capa tejida con cuidado
1273	cota de malla de bosque
1274	lupulos
1275	abrigo de anillas de diputado
1276	rodela endurecida con fuego
1280	caperuza invisible
1282	almofar de metal brillante
1283	nota de verner
1284	cajon de herraduras
1287	colmillo de tarantula gigante
1288	glandula de veneno grande
1292	cuchilla de carnicero
1293	el estado de villa del lago
1294	la respuesta del general
1296	maza roca negra
1297	togas del taumaturgo umbrio
1299	cinturon de la espiral inferior
1300	baston de la espiral inferior
1302	guantes de cria negra
1303	guantes de puente
1304	guantes de jinete
1306	guardamunecas crin de lobo
1307	planificacion de recogida de oro
1309	caja de herramientas de olento
1310	calzas de smith
1314	dedos de necrofago
1315	lei de lirios
1317	baston de raiz endurecido
1318	espetadora de la noche
1319	anillo de voluntad ferrea
1322	aceite de higado de pescado
1325	ramo de narcisos
1326	pezsol salteado
1327	nota de wiley
1328	libro sobre fuego feerico
1332	libro sobre veneno de cura
1334	libro sobre rejuvenecimiento ii
1339	libro sobre raices enredadoras
1341	libro sobre fuego lunar
1349	cajon de abercrombie
1351	brazales de falanges
1352	mortero de craneo rajado
1353	informe de shaw
1355	manteo de piel de ciervo
1356	mencion de honor bosque de elwynn
1357	mapa del tesoro del capitan sander
1358	una pista del tesoro de sander
1359	guantes con estampado de leon
1360	guantes de anillas de ventormenta
1361	otra pista del tesoro de sander
1362	pista final del tesoro de sander
1364	jubon de cuero harapiento
1366	pantalones de cuero harapiento
1367	botas de cuero harapiento
1368	guantes de cuero harapiento
1369	cinturon de cuero harapiento
1370	brazales de cuero harapiento
1372	capa harapienta
1374	zapatos deshilachados
1376	capa deshilachada
1377	guantes deshilachados
1378	pantalones deshilachados
1380	toga deshilachada
1381	un mensaje misterioso
1382	maza de roca
1383	tomahawk de piedra
1384	hoja mate
1386	hacha cardoleno
1387	diente de necrofago
1388	baston retorcido
1389	marra de mineria de kobold
1391	baston mistico zarparrio
1394	garrote de madera a la deriva
1395	pantalones de aprendiz
1396	pantalones de acolito
1399	vela magica
1400	muestra plumapresto
1401	hoja de te verde
1402	azufre
1404	talisman de la marea
1405	baston de escupitajo
1406	lanza taraceada con perlas
1407	peticion a los paramos de poniente de solomon
1408	respuesta a solomon de mantorrecio
1409	peticion a villa oscura de solomon
1410	respuesta de cerranegro a solomon
1411	baston seco
1412	espada bastarda rudimentaria
1413	espada debil
1414	almadena rajada
1415	marra de carpintero
1416	hacha herrumbrada
1417	hacha de batalla golpeada
1418	cinturon de cuero desgastado
1419	botas de cuero desgastadas
1420	brazales de cuero desgastados
1421	capa de pellejo desgastada
1422	guantes de cuero desgastados
1423	pantalones de cuero desgastados
1425	jubon de cuero desgastado
1427	zapatos de retales
1429	capa de retales
1430	guantes de retales
1431	pantalones de retales
1433	armadura de retales
1434	palo de cera resplandeciente
1436	calzones de frontera
1438	escudo de guerrero
1440	azotador de calavera gnoll
1443	amuleto de cainwyn enjoyado
1445	espaldares roca negra
1446	botas roca negra
1447	anillo de salvadores
1448	guanteletes roca negra
1449	anillo de mediacion menor
1450	pocion de fervor
1451	botella zumo de zombi
1453	peine espectral
1454	hacha del despota
1455	hacha de campeon roca negra
1457	maza pielsombra
1458	gran maza pielsombra
1459	arrancabelleras pielsombra
1460	espada de dos manos pielsombra
1461	hacha de batalla de destripador
1462	anillo de las sombras
1464	garfa de aguila ratonera
1465	aterratigres
1467	pez luna moteado
1468	aleta de murloc
1469	cimitarra de sincronizacion
1470	bolsa de piel de murloc
1473	baston ribera
1475	glandula de veneno pequena
1476	extremidad de arana partida
1477	pergamino de agilidad ii
1478	pergamino de proteccion ii
1479	mitones de salma
1480	puno de la milicia popular
1481	zarpadura
1482	colmillo oscuro
1483	machacacaras
1484	baculo de brujeria
1485	horquilla
1486	chaqueta de corteza de arbol
1487	pan integral de centeno magico
1488	armadura del vengador
1489	armadura de embozo luminiscente
1490	dije guardian
1491	anillo de precision
1493	cimitarra de merodeador pesada
1495	zapatos de percal
1497	capa de percal
1498	guantes de percal
1499	pantalones de percal
1501	guerrera de percal
1502	cinturon de cuero combado
1503	botas de cuero combadas
1504	brazales de cuero combados
1505	capa combada
1506	guantes de cuero combados
1507	pantalones de cuero combados
1509	jubon de cuero combado
1510	martillo pesado
1511	espada de plebeyo
1512	hacha de batalla rudimentaria
1513	espada magna vieja
1514	martillo de guerra herrumbrado
1515	baston de madera ferrea
1516	hachuela desgastada
1518	peine de fantasma
1519	oreja sangrapellejo
1520	sudor trol
1521	hacha de serreria de ogro
1522	lanza de rebanacabezas
1523	garrote de piedra enorme
1524	colmillo machacacraneos
1528	punado de avena
1529	jade
1532	cabeza reducida
1534	tratado luz sagrada iv
1536	tratado sello de colera
1537	faltriquera de la vieja blanchy
1539	baston nudoso de ermitano
1547	escudo de la fe
1554	escrito sobre descarga de escarcha iii
1557	rodela de los mares
1559	escrito sobre misiles arcanos ii
1560	sandalias de branquiazul
1561	toga de cosechador
1566	filo de la milicia popular
1567	escrito sobre liberacion de khadgar ii
1568	escrito sobre elemental de agua
1571	escrito sobre nova de escarcha ii
1574	escrito sobre resguardo contra el fuego
1588	tablilla de explosion de arrabio iii
1589	tablilla de armadura de espiritu iii
1591	tablilla de escudo de relampagos iii
1596	hilo de cabello de fantasma
1597	tablilla de tormenta de relampagos
1598	flor podrida
1602	hacha hoz
1603	tablilla de llamar a espiritu ii
1604	espada cromatica
1607	guardian de almas
1608	maza trituracraneos
1613	baston cazador de espiritus
1619	tablilla de tormenta de relampagos ii
1623	faltriquera de piel de raptor
1624	yelmo machacacraneos
1625	flamberge exquisita
1630	electrolinterna rota
1637	carta para ello
1639	hacha rictus
1640	hacha de guerra monstruosa
1641	codice de palabra de las sombras dolor iii
1645	zumo de baya lunar
1648	codice de sanar iv
1651	codice de palabra sagrada escudo vi
1652	caja de comida robusta
1656	carta traducida
1657	codice de resurreccion ii
1658	codice de palabra de las sombras dolor iv
1659	guantes de ingenieria
1664	vara de fuerza de hechizo
1676	codice de dormir ii
1677	jubon de escamas de draco
1678	chanclos de ogro negros
1679	bate de korg
1680	loncheacabezas
1681	grimorio entorpecer
1685	bolsa de pellejo de trol
1686	bigote de cerdas
1687	garra retractil
1688	cola blanda larga
1696	garfa de raptor curva
1697	diente de raptor cortante
1701	garra de basilisco curva
1702	espina de basilisco intacta
1703	columna de basilisco de cristal
1705	piedra lunar inferior
1706	fragmentos de hondoazur
1707	brie de ventormenta
1708	nectar dulce
1710	pocion de sanacion superior
1711	pergamino de aguante ii
1712	pergamino de espiritu ii
1713	ankh de vida
1714	collar de calisea
1715	armadura de brigandina pulida
1716	toga del magi
1717	guerrera de doble vinculo
1718	pantalones de pellejo de basilisco
1720	baston lenomarana
1721	martillo de guerra vikingo
1722	almadena piedra de espinas
1725	morral grande
1726	lanza de hueso con punta envenenada
1727	espada de descomposicion
1728	tizona llameante de teebu
1729	saco de armas de la guardia nocturna
1730	cinturon de malla desgastado
1731	botas de malla desgastadas
1732	brazales de malla desgastados
1733	capa desgastada
1734	guantes de malla desgastados
1735	pantalones de malla desgastados
1737	jubon de malla desgastado
1738	cinturon de malla con encaje
1739	botas de malla con encaje
1740	brazales de malla con encaje
1741	capa con encaje
1742	guantes de malla con encaje
1743	pantalones de malla con encaje
1744	hombreras de malla con encaje
1745	jubon de malla con encaje
1746	cinturon de eslabones
1747	botas de eslabones
1748	brazales de eslabones
1749	capa de eslabones
1750	guantes de eslabones
1751	pantalones de eslabones
1752	hombreras de eslabones
1753	jubon de eslabones
1754	cinturon de anillas reforzado
1755	botas de anillas reforzadas
1756	brazales de anillas reforzados
1757	capa de anillas reforzada
1758	guantes de anillas reforzados
1759	pantalones de anillas reforzados
1760	hombreras de anillas reforzadas
1761	jubon de anillas reforzado
1764	zapatos de retal
1766	capa de retal
1767	guantes de retal
1768	pantalones de retal
1769	hombreras de retal
1770	jubon de retal
1772	zapatos brocados
1774	capa brocada
1775	guantes brocados
1776	pantalones brocados
1777	hombreras brocadas
1778	jubon brocado
1780	sandalias a punto de cruz
1782	capa a punto de cruz
1783	guantes a punto de cruz
1784	pantalones a punto de cruz
1785	hombreras a punto de cruz
1786	jubon a punto de cruz
1787	cinturon de cuero con remiendos
1788	botas de cuero con remiendos
1789	brazales de cuero con remiendos
1790	capa con remiendos
1791	guantes de cuero con remiendos
1792	pantalones de cuero con remiendos
1793	hombreras de cuero con remiendos
1794	chaleco de cuero con remiendos
1795	cinturon de pellejo crudo
1796	botas de pellejo crudo
1797	brazales de pellejo crudo
1798	capa de pellejo crudo
1799	guantes de pellejo crudo
1800	pantalones de pellejo crudo
1801	hombreras de pellejo crudo
1802	guerrera de pellejo crudo
1803	cinturon de cuero fuerte
1804	botas de cuero fuerte
1805	brazales de cuero fuerte
1806	capa dura
1807	guantes de cuero fuerte
1808	pantalones de cuero fuerte
1809	hombreras de cuero fuerte
1810	armadura de cuero fuerte
1811	mandoble desafilado
1812	hacha de batalla de mango corto
1813	lanza larga astillada
1814	marra maltrecha
1815	maza ornamentada
1816	hacha mal equilibrada
1817	espada corta de serie
1818	mandoble estandar
1819	gubia
1820	gran maza de madera
1821	espada combada
1822	cachava de cedro
1823	cayada de cachiporrazo
1824	hacha de guerra lustrosa
1825	cachiporra grande
1826	gran maza de roca
1827	cuchilla de carne
1828	hacha de guerra de piedra
1829	alfanje corto
1830	espada bastarda larga
1831	baston de guerra de roble
1832	calzas de la suerte
1835	cinturon de cuero sucio
1836	brazales de cuero sucios
1839	cinturon de cuero ferreo
1840	brazales de cuero ferreo
1843	cinturon de cuero curtido
1844	brazales de cuero curtido
1845	cinturon de malla de anillas
1846	brazales de malla de anillas
1849	cinturon de cuero curado
1850	brazales de cuero curado
1851	agua de limpieza
1852	brazales de malla de escamas
1853	cinturon de malla de escamas
1875	distintivo de cardortiga
1877	libro sobre rejuvenecimiento iii
1882	libro sobre fuego lunar iii
1886	libro sobre fuego lunar ii
1893	revancha de minero
1894	tarjeta del sindicato minero
1913	porra con tachuelas
1917	daga enjoyada
1922	suministros para sven
1923	cartera de embajador
1925	estoque defias
1926	zapa pesada
1927	cuchilla de las minas de la muerte
1928	baston magico defias
1929	calzas de seda
1930	capa de albanil
1931	garra de gnoll enorme
1933	baston de creacion
1934	calzas de albanil
1935	hoja de asesino
1936	destornillador goblin
1937	sierra zumbido
1938	marra bloque
1939	odre de ron dulce
1941	tonel de merlot
1942	botella de licor
1943	leotardos de malla goblin
1944	guantes para trabajar el hierro
1945	guantes para trabajar la madera
1946	espejo de mary
1951	alfanje aguasnegras
1955	botas de anillas de faucedraco
1956	colgante pielsombra descolorido
1958	tibia petrificada
1959	pico de hierro frio
1962	colgante de pielsombra resplandeciente
1965	guantes de lobo blanco
1968	monoculo de ogro
1970	balsamo restablecedor
1971	escrituras de cejade
1972	escrituras de los paramos de poniente
1973	orbe de engano
1974	brazales de punzada mental
1975	espada magna vieja de pysan
1976	martillo de escoria
1977	bolsa con 20 casillas
1978	guantes de garra de lobo
1979	muro de los muertos
1980	sortija del submundo
1981	chaleco de malla de hielo
1982	hoja de la noche
1986	sacatripas
1987	olla de krazek arreglada
1988	guanteletes de brigadier
1990	gran maza de grava
1991	pala de energia goblin
1992	fetiche pantano fresco
1993	anillo de mente de ogro
1994	espetadora garra de ebano
1996	sortija vudu
1997	toga sentida
1998	baston de mediacion sangrapellejo
2000	archeus
2004	diario de grelin barbablanca
2005	la primera leyenda trol
2006	la segunda leyenda trol
2007	la tercera leyenda trol
2008	la cuarta leyenda trol
2011	sable retorcido
2013	baston de hueso de cripta
2014	espada magna de metal negro
2015	hacha de guerra de metal negro
2016	armadura de anillas polvorientas
2017	brazales de cuero resplandecientes
2018	tizona esqueletica
2020	hoja colmillo hueco
2021	escudo de caparazon verde
2024	espadon
2025	hacha barbada
2026	martillo de roca
2027	cimitarra
2028	martillo
2029	cuchilla
2030	baston nudoso
2032	punos de galante
2033	botas de embajador
2034	togas de erudito
2035	espada del cielo nocturno
2036	guantes de mineria polvorientos
2037	botas de tunelador
2039	anillo de las llanuras
2040	prospector trol
2041	guerrera de los paramos de poniente
2042	baston de los paramos de poniente
2043	anillo de espiritus melancolicos
2044	hacha curva de espiritus melancolicos
2046	kukri de branquiazul
2047	hacha de mano yunquemar
2048	martillo yunquemar
2054	hacha de mano trogg
2055	martillo de madera pequeno
2056	el martillo de terciopelo
2057	espada corta con agujeros defias
2058	gran maza de kazon
2059	capa de avizor
2064	garrote trogg
2065	hoja comepiedras
2066	hachuela calavera
2067	baston bocado helado
2069	jubon de pellejo de oso negro
2070	queso azul de darnassus
2072	cetro de mago enano
2073	hachuela enana
2074	hoja corta solida
2075	maza de sacerdote
2077	baston de mago
2078	espada corta septentrional
2079	martillo de guerra de sargento
2080	hacha natocolina
2082	zurron de zumbang
2084	espada bastarda de acero oscuro
2085	trozo de carne
2087	caparazon duro de reptador
2088	extremidad de reptador largo
2089	daga para tallar
2091	polvo magico
2092	daga desgastada
2098	escopeta de doble canon
2099	culebrina enana
2100	bocarda calibrada milimetricamente
2101	carcaj ligero
2102	faltriquera de municion pequena
2105	camisa de maton
2108	jubon de cuero peloescarcha
2109	jubon de anillas peloescarcha
2110	toga ligera de mago
2112	chaleco de lenador
2113	nota de calor
2114	toga nevada
2117	zapatos de pano fino
2119	guantes de pano fino
2120	pantalones de pano fino
2121	armadura de pano fino
2122	cinturon de cuero rajado
2123	botas de cuero rajado
2124	brazales de cuero rajado
2125	guantes de cuero rajado
2126	pantalones de cuero rajado
2127	jubon de cuero rajado
2128	mandoble aranado
2129	escudo redondo grande
2130	garrote
2131	espada corta
2132	baston corto
2133	escudo pequeno
2134	hacha de mano
2136	agua purificada magica
2137	cuchillo para tallar
2138	abrecartas afilado
2139	puntilla
2140	trinchante
2141	jubon de cuero hervido
2142	cinturon de cuero hervido
2143	botas de cuero hervido
2144	brazales de cuero hervido
2145	guantes de cuero hervido
2146	pantalones de cuero hervido
2148	cinturon de escama pulida
2149	botas de escama pulida
2150	brazales de escama pulida
2151	guantes de escama pulida
2152	leotardos de escama pulida
2153	jubon de escama pulida
2154	la historia de morgan ladimor
2156	botas acolchadas
2158	guantes acolchados
2159	pantalones acolchados
2160	armadura acolchada
2161	libro sobre la granja de sven
2162	anillo de sarah
2163	hoja de las sombras
2164	destripador
2165	manta de la vieja blanchy
2166	leotardos de supervisor
2167	guantes de supervisor
2168	botas de supervisor
2169	hoja timbre
2172	cinturon rustico
2173	cinturon de cuero viejo
2175	hacha de batalla pielsombra
2186	cinturon de modisto
2187	un fajo de cartas
2188	una carta para grelin barbablanca
2194	martillo de diamante
2195	cuchillo yunquemar
2203	trituradora de garravil
2204	ensartadora de garravil
2205	anochecedor
2207	jambiya
2208	punal
2209	kris
2210	rodela maltrecha
2211	escudo grande doblado
2212	rodela rajada
2213	escudo grande desgastado
2214	rodela de madera
2215	escudo de madera
2216	rodela simple
2217	escudo rectangular
2218	daga de artesano
2219	escudo redondo pequeno
2220	caja escudo
2221	tarja
2222	escudo paves
2223	la lista del coleccionista
2224	daga de milicia
2225	cuchillo de cocina afilado
2226	baston de ogro mago
2227	hacha de guerra de ogro pesada
2230	guantes de mole
2231	toga inferno
2232	botas con runas oscuras
2233	leotardos de tejedora de las sombras
2234	armadura de caminante nocturno
2235	garra de brack
2236	colmillo negro
2237	pantalones con remiendos
2238	pantalones de urchin
2239	el anillo del coleccionista
2240	manteo basto
2241	manteo de forajido
2243	mano de edward el extrano
2244	hoja krol
2245	yelmo de narv
2246	sello de mirmidon
2249	rodela de milicia
2250	pasteles de cangrejo oscuro
2251	pata pegajosa de arana
2252	suministros goblin variados
2254	martillo de guerra de cristal de hielo
2256	garrote esqueletico
2257	baston peloescarcha
2258	espada corta peloescarcha
2259	garrote peloescarcha
2260	hacha de mano peloescarcha
2262	marca de kern
2263	fitohoja
2264	manto de ladrones
2265	hacha rompecantos
2266	daga rompecantos
2267	maza rompecantos
2268	espada rompecantos
2271	baston del vidente bendito
2273	armadura de guerrilla
2274	guantes de zapador
2276	botas caminalodo
2277	leotardos de nigromante
2278	cubrehombros de rastreador de bosque
2280	cachava de kam
2281	hacha de silex rodentia
2282	espada corta rodentia
2283	cinturon de pano de rata
2284	capa de pano de rata
2287	anca de carne
2288	agua dulce magica
2289	pergamino de fuerza ii
2290	pergamino de intelecto ii
2291	kang el decapitador
2292	togas de necrologia
2295	colmillo de jabali grande
2296	morro de gran dentosangre
2299	hacha de guerra ardiente
2300	jubon de cuero estampado
2302	botas de cuero cosidas a mano
2303	pantalones de cuero cosidos a mano
2304	refuerzo para armadura ligero
2307	botas de cuero refinado
2308	capa de cuero refinado
2309	botas de cuero estampado
2310	capa de cuero estampado
2311	chaleco de cuero blanco
2312	guantes de cuero refinado
2313	refuerzo para armadura medio
2314	armadura de cuero fortalecido
2315	botas de cuero oscuro
2316	capa de cuero oscuro
2317	guerrera de cuero oscuro
2318	cuero ligero
2319	cuero medio
2320	hilo burdo
2321	hilo refinado
2324	lejia
2325	tinte negro
2326	brazales tejidos con hiedra
2327	brazales de cuero robusto
2361	martillo desgastado por la batalla
2362	escudo de madera desgastado
2364	jubon tejido
2366	pantalones tejidos
2367	botas tupidas
2369	guantes tejidos
2370	arnes de cuero maltrecho
2371	cinturon de cuero maltrecho
2372	pantalones de cuero maltrechos
2373	botas de cuero maltrechas
2374	brazales de cuero maltrechos
2375	guantes de cuero maltrechos
2376	escudo romboide desgastado
2377	rodela redonda
2378	dedo esqueletico
2379	jubon de anillas deslustradas
2380	cinturon de anillas deslustradas
2381	leotardos de anillas deslustradas
2382	el corazon del embalsamador
2383	botas de anillas deslustradas
2384	brazales de anillas deslustradas
2385	guantes de anillas deslustradas
2386	jubon de anillas oxidado
2387	cinturon de anillas oxidado
2388	leotardos de anillas oxidados
2389	botas de anillas oxidadas
2390	brazales de anillas oxidados
2391	guantes de anillas oxidados
2392	armadura de malla ligera
2393	cinturon de malla ligera
2394	leotardos de malla ligera
2395	botas de malla ligera
2396	brazales de malla ligera
2397	guantes de malla ligera
2398	armadura de anillas ligeras
2399	cinturon de anillas ligeras
2400	leotardos de anillas ligeras
2401	botas de anillas ligeras
2402	brazales de anillas ligeras
2403	guantes de anillas ligeras
2406	patron botas de cuero refinado
2407	patron chaleco de cuero blanco
2408	patron guantes de cuero refinado
2409	patron guerrera de cuero oscuro
2410	antorcha humeante
2411	brida de semental negro
2413	palomino
2414	brida de pinto
2415	semental blanco
2417	jubon de anillas aumentado
2418	leotardos de anillas aumentados
2419	cinturon de anillas aumentado
2420	botas de anillas aumentadas
2421	brazales de anillas aumentadas
2422	guantes de anillas aumentados
2423	jubon brigandina
2424	cinturon brigandina
2425	leotardos brigandina
2426	botas brigandina
2427	brazales brigandina
2428	guantes brigandina
2429	jubon rojizo
2431	pantalones rojizos
2432	botas rojizas
2434	guantes rojizos
2435	armadura bordada
2437	pantalones bordados
2438	botas bordadas
2440	guantes bordados
2441	rodela ensortijada
2442	tarja reforzada
2443	rodela de metal
2444	rodela ornamentada
2445	escudo de metal grande
2446	escudo oblongo
2447	flor de paz
2448	paves pesado
2449	raiz de tierra
2450	brezospina
2451	escudo romboide con emblema
2452	cardopresto
2453	hierba cardenal
2454	elixir de fuerza de leon
2455	pocion de mana menor
2456	pocion de rejuvenecimiento menor
2457	elixir de agilidad menor
2458	elixir de entereza menor
2459	pocion de presteza
2460	elixir of tongues nyi
2463	jubon con tachuelas
2464	cinturon con tachuelas
2465	pantalones con tachuelas
2466	fetiche machacacraneos
2467	botas con tachuelas
2468	brazales con tachuelas
2469	guantes con tachuelas
2470	jubon de cuero reforzado
2471	cinturon de cuero reforzado
2472	pantalones de cuero reforzado
2473	botas de cuero reforzado
2474	brazales de cuero reforzado
2475	guantes de cuero reforzado
2476	anca de basilisco fria
2477	calavera de devastador
2479	hacha ancha
2480	garrote grande
2481	espada de peon
2482	tomahawk inferior
2483	hacha ancha ferrea
2484	cuchillo pequeno
2485	tablero astillado
2486	maza de piedra grande
2487	baston de acolito
2488	gladius
2489	espada de dos manos
2490	tomahawk
2491	hacha grande
2492	cayada
2493	marra de madera
2494	estilete
2495	cachava
2496	espada corta de asaltante
2497	mandoble oxidado
2498	tomahawk pequeno
2499	hacha de doble filo
2500	martillo ligero
2501	martillo de guerra de madera
2502	daga rayada
2503	baston corto de adepto
2504	arco corto desgastado
2505	arco corto pulido
2506	arco corvo de madera de cuerno
2507	arco corvo laminado
2508	trabuco viejo
2509	trabuco ornamentado
2510	trabuco solido
2511	bocarda de cazador
2512	flecha ferrea
2514	depricated sharp arrow
2515	flecha afilada
2516	perdigon ligero
2519	perdigon pesado
2520	espada ancha
2521	flamberge
2522	hacha curva
2523	bullova
2524	clava
2525	martillo de guerra
2526	daga de guardamano
2527	baston de batalla
2528	bracamarte
2529	montante
2530	francisca
2531	gran hacha
2532	estrella de la manana
2533	gran maza de guerra
2534	rondel
2535	baston de guerra
2536	diente de trogg de piedra
2545	leotardos de anillas maleables
2546	faja peloescarcha real
2547	guantes de cuidador de jabalies
2548	barrica de brebaje de cebadiz
2549	baston de la sombra
2553	receta elixir de agilidad menor
2555	receta pocion de presteza
2556	receta elixir de lenguas
2560	diario completo de alterio
2561	cabeza de chok sul
2562	ramo de begonas escarlata
2563	particulas con olor extrano
2564	garras de espiritu elficas
2565	vara de fuego de arrabio
2566	togas de sacrificio
2567	hoja de evocador
2568	jubon de lino marron
2569	botas de lino
2570	capa de lino
2571	envolturas de parra
2572	toga de lino roja
2575	camisa de lino roja
2576	camisa de lino blanca
2577	camisa de lino azul
2578	jubon de lino barbarico
2579	camisa de lino verde
2580	manteo de lino reforzado
2581	venda de lino gruesa
2582	jubon de lana verde
2583	botas de lana
2584	manteo de lana
2585	toga de lana gris
2586	toga de maestro de juego
2587	camisa de lana gris
2589	pano de lino
2590	telarana de arana del bosque
2591	pano trogg sucio
2592	pano de lana
2593	frasco de cerveza leonada de ventormenta
2594	cantaro de hidromiel enano
2595	jarra de bourbon de las tierras inhospitas
2596	odre de cerveza enana
2598	patron toga de lino rojo
2601	patron toga de lana gris
2604	tinte rojo
2605	tinte verde
2606	veneno de rondador
2607	cristal mo grosh
2608	ambar gris de trillanodonte
2609	coloide desactivador
2610	mezcla neutralizadora
2611	silex rudimentario
2612	toga lisa
2613	togas con doble pespunte
2614	toga de aprendizaje
2615	toga cromatica
2616	togas de seda fulgurante
2617	togas ardientes
2618	togas vestidas de plata
2619	informe de grelin
2620	embozo augural
2621	capucha de nigromancia
2622	ornato tribal de nimar
2623	diadema sagrada
2624	almete de meditacion
2625	estatuilla de menethil
2628	informe de senir
2629	llave de caja fuerte de el intrepido
2632	daga curva
2633	pocima de la selva
2634	extracto de helecho venenoso
2635	cinturon de anillas sueltas
2636	idolo de piedra grabado
2637	informe del avance de vetaferro
2639	carta de merrin
2640	equipamiento de minero
2642	botas de anillas sueltas
2643	brazales de anillas sueltas
2644	capa de anillas sueltas
2645	guantes de anillas sueltas
2646	pantalones de anillas sueltas
2648	jubon de anillas sueltas
2649	cinturon de anillas endeble
2650	botas de anillas endebles
2651	brazales de anillas endebles
2652	capa de anillas endeble
2653	guantes de anillas endebles
2654	pantalones de anillas endebles
2656	jubon de anillas endeble
2657	bolsa de cuero rojo
2658	trozo ados
2659	trozo modr
2660	trozo golm
2661	trozo neru
2662	carcaj de ribbly
2663	bandolera de ribbly
2664	colmillo de hilador
2665	hierbas aromaticas de ventormenta
2666	barrica de cerveza del trueno
2667	carnes curadas de macgrann
2668	diente de trillanodonte
2669	garra de trillanodonte
2671	crin de wendigo
2672	carne de lobo fibrosa
2673	carne de coyote
2674	carne de reptador
2675	garra de reptador
2676	cardaluz
2677	costillas de jabali
2678	especias suaves
2679	carne de lobo carbonizada
2680	carne de lobo especiada
2681	carne de jabali asada
2682	pinza de cangrejo cocida
2683	pastel de cangrejo
2684	filete de coyote
2685	costillas de cerdo suculentas
2686	cerveza del trueno
2687	costillas de cerdo secas
2688	nuez de ardilla
2690	cinturon con pasador
2691	botas de modisto
2692	especias picantes
2694	leotardos de colono
2696	tonel de tajada
2697	receta pastel de higado de dentosangre
2698	receta pinza de cangrejo cocida
2699	receta estofado crestagrana
2700	receta costillas de cerdo suculentas
2701	receta kebab de lobo sazonado
2702	lingote forjaluz
2712	cajon de lingotes de forjaluz
2713	cabeza del viejo tiznado
2719	llave de laton pequena
2720	nota con barro
2721	embozo sagrado
2722	cupon de vino
2723	botella de dalaran noir
2724	solicitud de pano
2725	las verdes colinas de tuercespina pagina 1
2728	las verdes colinas de tuercespina pagina 4
2730	las verdes colinas de tuercespina pagina 6
2732	las verdes colinas de tuercespina pagina 8
2734	las verdes colinas de tuercespina pagina 10
2735	las verdes colinas de tuercespina pagina 11
2738	las verdes colinas de tuercespina pagina 14
2740	las verdes colinas de tuercespina pagina 16
2742	las verdes colinas de tuercespina pagina 18
2744	las verdes colinas de tuercespina pagina 20
2745	las verdes colinas de tuercespina pagina 21
2748	las verdes colinas de tuercespina pagina 24
2749	las verdes colinas de tuercespina pagina 25
2750	las verdes colinas de tuercespina pagina 26
2751	las verdes colinas de tuercespina pagina 27
2754	espada bastarda deslustrada
2755	las verdes colinas de tuercespina
2756	las verdes colinas de tuercespina capitulo i
2757	las verdes colinas de tuercespina capitulo ii
2758	las verdes colinas de tuercespina capitulo iii
2759	las verdes colinas de tuercespina capitulo iv
2760	costurero de thurman
2763	cuchillo de pescador
2764	daga pequena
2765	cuchillo de caza
2766	estilete diestro
2770	mena de cobre
2771	mena de estano
2772	mena de hierro
2773	arco corto rajado
2774	trabuco cubierto de herrumbre
2775	mena de plata
2776	mena de oro
2777	arco corto debil
2778	trabuco barato
2779	lagrima de tilloa
2780	arco de caza ligero
2781	trabuco sucio
2782	arco corvo maltratado
2783	trabuco de pesima calidad
2784	zibetica
2785	arco corvo tieso
2786	trabuco engrasado
2787	daga trogg
2788	cerveza zarpanegra
2794	un viejo libro de historia
2795	libro tensiones del hierro
2797	corazon de mokk
2798	mena de rethban
2799	colmillo de gorila
2800	togas de terciopelo negro
2801	hoja de hanna
2802	emblema llameante
2805	capa de pelaje de yeti
2806	paquete para pico tormenta
2807	hacha guillotina
2808	antorcha de llama
2815	destripadora con hojas curvas
2816	cetro del portavoz de la muerte
2817	guerrera de cuero suave
2818	calzas de cuero elasticas
2819	daga cruzada
2820	cronometro ingenioso
2821	pasapures mo grosh
2822	mondadientes mo grosh
2823	abrelatas mo grosh
2824	huracan
2825	arco para flechas abrasadoras
2828	restos de nissa
2829	restos de gregor
2830	restos de thurman
2831	restos de devlin
2832	receta del estofado de los paramos de poniente de verna
2833	el libro de hechizos del exanime
2834	icor embalsamante
2835	piedra ferrea
2836	piedra burda
2837	carta de thurman
2838	piedra pesada
2839	una carta para yvette
2840	barra de cobre
2841	barra de bronce
2842	barra de plata
2843	nudillos sucios
2844	maza de cobre
2845	hacha de cobre
2846	calabaza de tirisfal
2847	espada corta de cobre
2848	maza de bronce
2849	hacha de bronce
2850	espada corta de bronce
2851	cinturon de anillas de cobre
2852	pantalones de anillas de cobre
2853	brazales de cobre
2854	brazales runicos de cobre
2855	garra podrida
2856	pica de hierro
2857	cinturon runico de cobre
2858	sangre de can oscuro
2859	escama anca vil
2862	piedra de afilar ferrea
2863	piedra de afilar burda
2864	coraza runica de cobre
2865	leotardos de bronce ferreos
2866	loriga de bronce ferrea
2867	brazales de bronce ferreos
2868	brazales de bronce estampados
2869	coraza de bronce banada en plata
2870	coraza de plata resplandeciente
2871	piedra de afilar pesada
2872	veneno de arana nocturacnida sanosa
2874	una carta sin enviar
2875	anillo con la insignia escarlata
2876	pelambre de murciumbrio
2877	mandoble de combatiente
2878	hacha de hueso barbada
2879	vara antipoda
2880	flujo debil
2881	diseno coraza runica de cobre
2882	diseno sobrehombros de bronce banados en plata
2883	diseno punal de bronce mortal
2885	documentos de la cruzada escarlata
2886	costilla de jabali del risco
2887	pelambre de lobo estropeada
2888	costillas de jabali a la cerveza
2889	receta costillas de jabali a la cerveza
2890	pelambre de jabali estropeada
2891	carta para el arquitecto de la ciudad
2892	veneno mortal
2893	veneno mortal ii
2894	malta rapsodica
2895	dolor espeluznante
2896	angustia espeluznante
2898	pechera de montaraz
2899	collera wendigo
2900	rodela de piedra
2901	pico de minero
2902	capa de la fe
2903	arco de caza de daryl
2904	rifle de caza de daryl
2905	capa de pelaje de cabra
2906	leotardos de malla villa oscura
2907	corta arboles enana
2908	espada espinada
2909	panuelo de lana roja
2910	botas de milicia de oro
2911	faja de keller
2912	garra del sombramantico
2913	manto de gamn de seda
2915	rompehielo taran
2916	escudo de leon de oro
2917	anillo tranquilo
2919	reliquia de los antiguos
2920	reliquia sacra
2921	reliquia bendita
2922	reliquia de espiritu
2923	reliquia de rectitud
2924	carne de crocolisco
2925	piel de crocolisco
2926	cabeza de bazil thredd
2927	tormento espeluznante
2928	polvo de decadencia
2929	podredumbre de tumba
2930	esencia de dolor
2932	vina tormenta
2933	sello de wrynn
2934	restos de cuero estropeado
2939	lagrima de crocolisco
2940	pata de oso sangrienta
2941	corvo de prision
2942	nudillos de hierro
2943	ojo de paleth
2944	ojo maldito de paleth
2946	daga arrojadiza equilibrada
2947	cuchillo arrojadizo pequeno
2949	botas de marinero
2950	vara carambano
2951	anillo de truenedera
2953	capa de maestro vigia
2954	bombachos de guardia nocturno
2955	sombrero de contramaestre
2956	informe sobre la hermandad defias
2957	jubon de oficial
2958	pantalones de oficial
2959	botas de oficial
2960	guantes de oficial
2961	jubon de cuero quemado
2962	calzones de cuero quemado
2963	botas de cuero quemado
2964	guantes de cuero quemado
2965	guerrera de guerrero
2966	pantalones de guerrero
2967	botas de guerrero
2968	guantes de guerrero
2969	jubon vinculahechizo
2970	pantalones vinculahechizo
2971	botas vinculahechizo
2972	guantes vinculahechizo
2973	guerrera de caza
2974	pantalones de caza
2975	botas de caza
2976	guantes de caza
2977	armadura de veterano
2978	leotardos de veterano
2979	botas de veterano
2980	guantes de veterano
2981	toga de vidente
2982	pantalones de vidente
2983	botas de vidente
2984	guantes de vidente
2985	coraza de cuero grabado
2986	pantalones de cuero grabado
2987	botas de cuero grabado
2988	guantes de cuero grabado
2989	guerrera brunida
2990	leotardos brunidos
2991	botas brunidas
2992	guantes brunidos
2996	madeja de pano de lino
2997	madeja de pano de lana
2998	una sencilla brujula
2999	herramientas de brasacerada
3000	caparazon de madre de linaje
3002	cuerno de justicia de reliquia
3003	reliquia del ojo
3004	reliquia de los muertos
3005	reliquia de verdad
3006	fragmento de reliquia sagrada
3008	capa de pelaje wendigo
3010	arena fina
3011	ornato de plumas
3012	pergamino de agilidad
3013	pergamino de proteccion
3014	hacha desgastada por la batalla
3016	libro de hechizos de gunther
3017	ordenes de sevren
3018	pellejo de lupos
3019	toga de noble
3020	almete duradero
3021	arco de forestal
3022	calzones de branquiazul
3023	trabuco pesado grande
3024	bkp 2700 despota
3025	bkp 42 ultra
3026	arco reforzado
3027	arco corvo pesado
3028	arco largo
3029	depricated whipwood arrow
3030	flecha navaja
3031	depricated razor arrow
3033	perdigon solido
3035	calabaza envenenada
3036	arco corto pesado
3037	arco corvo ligero
3039	arco de fresno corto
3040	avancarga de cazador
3041	trabuco ojo de mago
3042	bkp gorrion de bajo calibre
3045	botas de escamas luminiscentes
3047	guantes de escamas luminiscentes
3048	musleras de escamas luminiscentes
3049	coraza de escamas luminiscentes
3053	pechera de humbert
3055	pechera de cuero de bosque
3056	pantalones de cuero de bosque
3057	botas de cuero de bosque
3058	guantes de cuero de bosque
3065	botas brillantes
3066	guantes brillantes
3067	pantalones brillantes
3069	toga brillante
3070	capa insignia
3071	hachuela de artillero
3072	toga humeante
3073	pantalones humeantes
3074	guantes humeantes
3075	ojo de llama
3076	botas humeantes
3078	troceacorazones naga
3079	rifle de skorn
3080	vela de senalizacion
3081	gema abisal
3082	calavera de dargol
3083	pinon de estabilizacion
3084	engranaje giromecanico
3085	barrica de cerveza negra brillante
3086	tonel de cerveza negra brillante
3087	jarra de cerveza brillante
3088	libro sobre rejuvenecimiento iv
3089	escrito sobre fogonazo
3090	escrito sobre descarga de escarcha
3091	escrito sobre intelecto arcano ii
3092	escrito sobre fogonazo iii
3093	escrito sobre fogonazo ii
3094	escrito sobre explosion de fuego ii
3095	escrito sobre explosion de fuego iii
3096	escrito sobre caida de pluma
3097	escrito sobre crear agua ii
3098	escrito sobre lentitud
3099	escrito sobre armadura de hielo ii
3100	escrito sobre ventisca ii
3101	escrito sobre nova de escarcha iii
3102	escrito sobre intelecto arcano iii
3103	martillo crestanevada
3107	cuchillo arrojadizo cortante
3108	daga arrojadiza pesada
3110	oreja de rata de tunel
3111	hacha arrojadiza rudimentaria
3113	codice de palabra sagrada escudo
3114	codice de palabra de las sombras ofuscar
3115	codice de renovar iv
3116	codice de palabra sagrada escudo ii
3117	diario de hildelve
3118	codice de sanacion superior
3119	codice de palabra sagrada escudo v
3120	codice de punicion sagrada iv
3121	codice de levitar
3122	codice de palabra sagrada escudo iii
3123	codice de palabra sagrada entereza iii
3124	codice de fuego interno iii
3125	tablilla de totem serpiente ii
3126	tablilla de choque ii
3127	tablilla de choque iii
3129	tablilla de descarga de relampagos iv
3130	tablilla de restauracion iv
3131	hacha arrojadiza pesada
3132	tablilla de explosion de arrabio iv
3133	tablilla de totem de mana
3134	grimorio maldicion de mannoroth
3135	hacha arrojadiza afilada
3137	hacha arrojadiza mortal
3138	grimorio descarga de las sombras iv
3139	grimorio armadura demoniaca ii
3140	grimorio hervor de sangre ii
3141	grimorio drenaje de vida
3142	grimorio maldicion de sargeras
3143	grimorio espiritu ardiente
3144	grimorio espiritu ardiente ii
3146	grimorio espiritu ardiente iii
3151	jubon de brigada de asedio
3152	guantes de buceo
3153	capa manchada de aceite
3154	hacha de thelsamar
3155	remedio de arugal
3156	grillete de gloton
3157	grillete de almanegra
3158	brazales de pellejo quemados
3160	rodela de placas de hierro
3161	toga del vigilante
3162	costilla con cortes
3163	calavera ennegrecida
3164	corazon de huargo descolorido
3165	pocion de quinn
3166	cota de malla coracero
3167	cerda de arana espesa
3168	escama astillada
3169	diente de oso astillado
3170	diente de oso grande
3171	colmillo de jabali roto
3172	intestinos de jabali
3173	carne de oso
3174	icor de arana
3175	pellejo de dragon estropeado
3176	garra pequena
3177	colmillo diminuto
3179	muda de piel de dragon rajada
3180	escama de raptor con motas
3181	carne parcialmente digerida
3182	seda de arana
3183	garra sarnosa
3184	daga gancho
3185	baston acrobatico
3186	espada vikinga
3187	kris de sacrificio
3188	mandoble de coral
3189	talador
3190	palo para golpear
3191	hacha de guerra arqueada
3192	espada bastarda corta
3193	marra de roble
3194	malicia negra
3195	hacha de batalla barbarica
3196	espada bastarda afilada
3197	mandoble cortapiedras
3198	martillo de paliza
3199	destripador de batalla
3200	brazales de cuero quemado
3201	hacha de guerra barbara
3202	brazales de cuero de bosque
3203	maza triangular densa
3204	brazales lenoprofundo
3205	brazales de cuero grabado
3206	montante de hidalgo
3207	brazales de caza
3208	martillo porrazo
3209	espada de guerra antigua
3210	hacha de guerra brutal
3211	brazales brunidos
3212	brazales de escamas luminiscentes
3213	brazales de veterano
3214	brazales de guerrero
3216	toga de invierno calida
3217	cinturon de supervisor
3218	grillete de pirolena
3220	morcilla
3222	daga maligna
3223	cetro peloescarcha
3224	brazales forrados con plata
3225	cuchillo manchado de sangre
3227	baston de nocturno
3228	esposas forzadas
3229	fajin de seda de tarantula
3230	brazales de lobo negro
3231	espaldares degollador
3233	saco de pellejo gnoll
3234	anillo de deliah
3235	anillo de desden
3236	icor de putrepellejo
3237	muestra de icor
3238	hallazgos de johaan
3239	contrapeso ferreo
3240	contrapeso burdo
3241	contrapeso pesado
3248	carta traducida de el embalsamador
3249	conjured test item
3250	pergamino de bethor
3251	pocion de bethor
3252	informe de mortacechador
3253	corazon de oso grisaceo
3254	sangre de celeracnida
3255	diario de berard
3256	moho de vagador del lago
3257	moho de trepador del lago
3258	tumor endurecido
3259	pellejo de murcielago estropeado
3260	togas de iniciado escarlata
3261	capa palmeada
3262	martillo de madera podrido
3263	pantalones palmeados
3264	ala de murciumbrio
3265	garra de carronero
3266	banda escarlata
3267	espada corta de los renegados
3268	daga de los renegados
3269	gran maza de los renegados
3270	jubon de lienzo
3272	leotardos de piel de zombi
3273	jubon de malla basta
3274	botas de lienzo
3275	guantes de lienzo
3276	rodela de guardia de la muerte
3277	baston de verdugo
3278	espada de dano de proc aura
3279	botas de anillas de batalla
3280	brazales de anillas de batalla
3281	guantes de anillas de batalla
3282	pantalones de anillas de batalla
3283	guerrera de anillas de batalla
3284	botas tribales
3285	brazales tribales
3286	guantes tribales
3287	pantalones tribales
3288	jubon tribal
3289	botas ancestrales
3290	guantes ancestrales
3291	prendas de lana ancestrales
3292	guerrera ancestral
3293	cuchilla de muerto
3294	garrote de muerto
3295	hoja de muerto
3296	daga de muerto
3297	musgovil
3299	canino fracturado
3300	pata de conejo
3301	canino afilado
3302	botas de agua estancada
3303	brazales de agua estancada
3304	guanteletes de agua estancada
3305	leotardos de agua estancada
3306	jubon de agua estancada
3307	botas de pano barbarico
3308	guantes de pano barbarico
3309	taparrabos barbarico
3310	jubon de pano barbarico
3311	tobilleras de cuero ceremonial
3312	brazales de cuero ceremonial
3313	arnes de cuero ceremonial
3314	guantes de cuero ceremonial
3315	taparrabos de cuero ceremonial
3316	cabeza de alaric
3317	una cabeza que habla
3318	restos de alaric
3319	sable corto
3320	fajin tirahuesos
3321	botitas de pelaje gris
3322	capa menuda
3323	brazales fantasmales
3324	manto fantasmal
3325	hacha de batalla anca vil
3327	baston de oraculo anca vil
3328	toga de tela de arana
3329	tabla de madera con pinchos
3330	camisote de dargol
3331	manteo de melrache
3332	botas de perrine
3334	pala de granjero
3335	escoba de granjero
3336	taladro de carne
3337	estandarte de guerra faucedraco
3339	yesca enana
3340	mena de incendicita
3341	guanteletes de fuerza de ogro
3342	camisa del capitan sander
3343	bolsa de botin del capitan sander
3344	fajin del capitan sander
3345	sombrero de zahori de seda
3347	fardo de pieles de crocolisco
3348	piel de crocolisco gigante
3349	bolsa de shida
3352	bolsa cubierta de moco
3353	colgante con runas grabadas
3354	colgante de dalaran
3355	acerita salvaje
3356	sangrerregia
3357	vidarraiz
3358	mostacho de khadgar
3360	femur de puntos
3363	cinturon deshilachado
3365	brazales deshilachados
3369	musgo de tumba
3370	cinturon de retales
3371	vial vacio
3372	vial emplomado
3373	brazales de retales
3374	cinturon de percal
3375	brazales de percal
3376	cinturon de retal
3377	brazales de retal
3378	cinturon brocado
3379	brazales brocados
3380	cinturon a punto de cruz
3381	brazales a punto de cruz
3382	pocion de sangre de trol debil
3383	elixir de sabiduria
3384	pocion de resistencia a la magia menor
3385	pocion de mana inferior
3386	elixir de resistencia al veneno
3387	pocion de invulnerabilidad limitada
3388	pocion de sangre de trol fuerte
3389	elixir de defensa
3390	elixir de agilidad inferior
3391	elixir de fuerza de ogro
3392	yelmo ensortijado
3393	receta pocion de resistencia a la magia menor
3394	receta elixir de resistencia al veneno
3395	receta pocion de invulnerabilidad limitada
3396	receta elixir de agilidad inferior
3397	piel de crocolisco joven
3399	garfa de buitre
3400	tizona lucine
3401	escama de crocolisco ferrea
3402	parche de pelaje suave
3403	cuerno de jabali de marfil
3404	ala de aguila ratonera
3405	dije de garra del cuervo
3406	canon de pluma negra
3407	zafiro de cielo
3408	runa de nidal
3409	colmillo de sable de la noche
3411	pluma de lechuza estrigida
3412	seda de arana tejemadera
3413	pico maldito
3414	cetro con emblema
3415	baston del fraile
3416	cota de malla de martir
3417	mandoble de onice
3418	bellota vil
3419	rosa roja
3420	rosa negra
3421	flores silvestres simples
3422	flores silvestres preciosas
3423	ramo de rosas blancas
3424	ramo de rosas negras
3425	varita tejida
3426	camisa amarilla chillon
3427	camisa negra con estilo
3428	camisa gris comun
3429	cinturon de guardia
3430	rifle de francotirador
3431	cuero con huesos
3434	arena de sueno
3435	brazales de piel de zombi
3437	cinturon con broche
3438	ankh de resurreccion
3439	botas de piel de zombi
3440	partehuesos
3442	fajin de aprendiz
3443	tomahawk ceremonial
3444	jubon de vastago
3445	cuchillo ceremonial
3446	baston lenoscuro
3447	botas de caminacriptas
3448	raiz de senggin
3449	chal mistico
3450	escudo de faerleia
3451	brebaje resplandor nocturno
3452	vara ceranium
3453	brazales guateados
3454	botas de reconocimiento
3455	espada corta de mortacechador
3456	silbato para perros
3457	calzas estampadas
3458	guantes de malla basta
3460	bebida especial de johaan
3461	gran toga del adjudicador
3462	golpe de garfa
3463	estrella de plata
3464	flecha de plumas
3465	proyectil explosivo
3466	flujo concentrado
3467	llave de hierro mate
3468	descubrimiento de renferrel
3469	botas de anillas de cobre
3470	piedra de pulir ferrea
3471	jubon de anillas de cobre
3472	guanteletes runicos de cobre
3473	pantalones runicos de cobre
3474	guanteletes de cobre con gemas
3475	capa de llamas
3476	lengua de oso gris
3477	icor de trepador
3478	piedra de pulir burda
3480	sobrehombros de bronce ferreos
3481	sobrehombros de bronce banados en plata
3482	botas de bronce banadas en plata
3483	guanteletes de bronce banados en plata
3484	botas de hierro verdes
3485	guanteletes de hierro verdes
3486	piedra de pulir pesada
3487	espada ancha de cobre pesada
3488	hacha de batalla de cobre
3489	gran hacha de guerra
3490	punal de bronce mortal
3491	maza de bronce pesada
3492	martillo de hierro poderoso
3493	fin de raptor
3495	elixir de sufrimiento
3496	sangre de leon de montana
3497	elixir de dolor
3498	collar de taretha
3499	llave de oro brunida
3502	flores morrobarro
3505	sello de alterac
3506	compuesto morrobarro
3508	mezcla morrobarro
3509	escama espinadaga
3510	ojo de aleta rasgado
3511	capa de la milicia popular
3514	calavera de mor ladim
3515	baston de ataeric
3516	cabeza de lescovar
3517	barril de cerveza machacacanillas
3518	carta descifrada
3520	barril contaminado
3521	carta cifrada con ingenio
3522	coraza negro de elfo de la noche
3523	pantalones de elfo de la noche sin usar
3524	botas de elfo de la noche sin usar
3525	brazales de elfo de la noche sin usar
3526	guantes negros de elfo de la noche
3527	coraza de elfo de la noche blanca
3528	coraza de cuero rojo c03
3529	yelmo negro de elfos de la noche
3530	venda de lana
3531	venda de lana gruesa
3532	unused red leather c03 pants
3533	botas de cuero rojo c03
3534	unused red leather c03 gloves
3535	brazales de cuero rojo c03
3536	venda de cazademonios
3537	d02 coraza de cuero negro
3538	coraza de cuero gris d02
3539	unused black leather d02 pants
3540	unused gray leather d02 pants
3541	d02 botas de cuero negras
3542	botas de cuero gris d02
3543	unused black leather d02 gloves
3544	unused gray leather d02 gloves
3545	d02 brazales de cuero negros
3546	brazales de cuero gris d02
3547	coraza de cuero blanco d03
3548	unused white leather d03 pants
3549	unused white leather d03 gloves
3550	cabeza de targ
3551	cabeza de rastrazo
3552	cabeza de glommus
3553	cabeza de jarra thol
3554	corona de voluntad
3555	toga de solomon
3556	sombrero de mago aterrador
3557	tabardo de tripas sin usar
3558	toga de guardia de pantano
3559	guanteletes de guardia nocturno
3560	manto de honor
3561	poncho resistente
3562	cinturon de vindicacion
3563	bombachos de navegante
3564	envio de hierro
3565	guantes manchados de cerveza
3566	armadura aterraptor
3567	cana de pescar enana
3569	toga de vicario
3570	mano de mortero de huesos
3571	golpeador trogg
3572	espada corta de daryl
3573	carcaj de caza
3574	saco de municion de caza
3575	barra de hierro
3576	barra de estano
3577	barra de oro
3578	pantalones de cosechador
3581	cuchillo dentado
3582	capa antiacido
3583	cinturon deteriorado
3585	guerrera de camuflaje
3586	partetroncos
3587	cinturon bordado
3588	brazales bordados
3589	cinturon de tejido pesado
3590	brazales de tejido pesado
3591	cinturon acolchado
3592	brazales acolchados
3593	cinturon rojizo
3594	brazales rojizos
3595	cinturon de pano andrajoso
3596	brazales de pano andrajoso
3597	cinturon de pano grueso
3598	brazales de pano grueso
3599	cinturon de pano fino
3600	brazales de pano fino
3601	misiva de la hermandad
3602	cinturon tricotado
3603	brazales tricotados
3604	bandolera de la guardia nocturna
3605	carcaj de la guardia nocturna
3606	cinturon tejido
3607	brazales tejidos
3608	diseno martillo de hierro poderoso
3609	diseno jubon de anillas de cobre
3610	diseno guanteletes de cobre con gemas
3611	diseno botas de hierro verdes
3612	diseno guanteletes de hierro verdes
3613	manos de valdred
3614	zarpa de ululante
3615	cabeza de kurzen
3616	ojo de la mente
3617	colgante de las sombras
3618	cabeza de engullidor
3619	tabaquera de snellig
3620	restos de lillith
3621	cabeza de ivar
3622	esencia de latipesadilla
3623	cabeza de thule
3625	cabeza de nek rosh
3626	cabeza del baron vardus
3627	colmillo de vagash
3628	mano de dextren ward
3629	anillo de la familia mantoniebla
3630	cabeza de targorr
3631	colmillo de panzallena
3632	pata de fangore
3633	cabeza de gath ilzogg
3634	cabeza de grimson
3635	garra de ojo de cresa
3636	escama de viejo ojosombrio
3637	cabeza de vancleef
3638	garfa de sarldente
3639	oreja de balgaras
3640	cabeza de furiahonda
3641	brazales de oficial
3642	brazales ancestrales
3643	brazales vinculahechizo
3644	brazales de pano barbarico
3645	punos de vidente
3647	brazales brillantes
3648	rodela de guerrero
3649	rodela tribal
3650	escudo de batalla
3651	escudo de veterano
3652	rodela de caza
3653	rodela ceremonial
3654	escudo de agua estancada
3655	escudo brunido
3656	escudo de escamas luminiscentes
3657	registro de trabalomas
3658	escrito recuperado
3659	libro de cuero desgastado
3660	escritos sobre alterac
3661	baston artesanal
3662	filete de crocolisco
3663	sopa de aleta de murloc
3664	potaje de crocolisco
3665	tortilla con un sabor curioso
3666	pastel de arana pegajosa
3667	carne de crocolisco tierna
3668	contrato de asesino
3669	baba gelatinosa
3670	hueso viscoso grande
3671	calavera inerte
3672	cabeza de nagaz
3673	flecha partida
3674	bota descompuesta
3675	antorcha totalmente quemada
3676	icor baboso
3678	receta filete de crocolisco
3679	receta morcilla
3680	receta sopa de aleta de murloc
3681	receta potaje de crocolisco
3682	receta tortilla con un sabor curioso
3683	receta pastel de arana pegajosa
3684	tiara perenolde
3685	huevo de raptor
3688	ovalo de sangrita
3689	canica de sangrita
3690	fragmento de sangrita
3691	cuna de sangrita
3692	craneo humano de trabalomas
3693	espada de humbert
3701	mencion de honor lacrada de darthalia
3702	vejiga de bilis de oso
3703	cerveza de costasur
3704	llave de hierro oxidada
3706	papiro hechizado
3707	papiro de nagaz
3708	vara de helcular
3710	vara de helcular
3711	cuaderno de investigacion de belamoore
3712	carne de tortuga
3713	especias calmantes
3714	muestra de piedra desgastada
3715	brazales de vinculo de tierra
3716	cabeza de murloc
3717	saco de cabezas de murloc
3718	documentos de planificacion
3719	capa de montanero
3720	piel de yeti
3721	informe de farren
3722	pellejo conocido
3723	colmillo conocido
3724	garra conocida
3725	cuerno conocido
3726	chuleta de oso grande
3727	chuletillas de leon picantes
3728	filete de leon sabroso
3729	sopa de tortuga reconfortante
3730	carne de oso grande
3731	carne de leon
3732	cogulla
3733	cota de malla de guerra orca
3734	receta chuleta de oso grande
3735	receta chuletillas de leon picantes
3736	receta filete de leon sabroso
3737	receta sopa de tortuga reconfortante
3738	vara de cervecero
3739	anillo calavera
3740	espada decapitadora
3741	botas de pisoton
3742	arco de saqueo
3743	rodela de avizor
3744	colgante de sangrita
3745	runa de apertura
3747	fajin de meditacion
3748	manto felino
3749	capa de gran boticario
3750	coraza de canale
3751	leotardos de mercenario
3752	jubon de bruto
3753	faja de pastor
3754	guantes de pastor
3755	destripapeces
3758	cinturon cruzado
3759	guantes aislantes de sabio
3760	sortija de entranas
3761	escudo calavera
3762	cartera de bibliotecario
3763	rodela lunar
3764	botas de mantis
3765	espaldares de salteador
3766	pluma de grifo
3767	papiro refinado
3769	varita rota
3770	pata de cordero
3771	pata de marrano salvaje
3772	agua de manantial magica
3775	veneno entorpecedor
3776	veneno entorpecedor ii
3777	raiz de letargo
3778	arco compuesto tenso
3779	hacha de guerra pesada
3780	mosquete de canon largo
3781	mandoble ancho
3782	garrote de guerra grande
3783	cimitarra ligera
3784	baculo de metal
3785	hacha cortante
3786	puntilla lustrosa
3787	garrote de piedra
3788	reliquia de cristal de alma
3789	piedra reliquia de piedad
3790	papiro de reliquia consagrada
3791	reliquia de la luz
3792	cinturon entrelazado
3793	botas entrelazadas
3794	brazales entrelazados
3795	capa entrelazada
3796	guantes entrelazados
3797	pantalones entrelazados
3798	hombreras entrelazadas
3799	jubon entrelazado
3800	cinturon de cuero endurecido
3801	botas de cuero endurecido
3802	brazales de cuero endurecido
3803	capa endurecida
3804	guantes de cuero endurecido
3805	pantalones de cuero endurecido
3806	hombreras de cuero endurecido
3807	guerrera de cuero endurecido
3808	cinturon de malla doble
3809	botas de malla doble
3810	brazales de malla doble
3811	capa con doble pespunte
3812	guantes de malla doble
3813	pantalones de malla doble
3814	hombreras de malla doble
3815	jubon de malla doble
3816	calentador reflectante
3817	rodela reforzada
3818	palida
3819	invernalia
3820	alga estranguladora
3821	espina de oro
3822	hoja oscura runica
3823	pocion de invisibilidad inferior
3824	aceite de las sombras
3825	elixir de entereza
3826	pocion de sangre de trol poderosa
3827	pocion de mana
3828	elixir de deteccion de invisibilidad inferior
3829	aceite de escarcha
3830	receta elixir de entereza
3831	receta pocion de sangre de trol poderosa
3832	receta elixir de deteccion de invisibilidad inferior
3833	capa de adepto
3834	calzas de pano robusto
3835	brazales de hierro verdes
3836	yelmo de hierro verde
3837	almofar de escamas doradas
3838	garra faucesombria
3839	colmillo de tigresa pristino
3840	sobrehombros de hierro verdes
3841	sobrehombros de escamas doradas
3842	leotardos de hierro verdes
3843	leotardos de escamas doradas
3844	camisote de hierro verde
3845	loriga de escamas doradas
3846	botas de acero pulido
3847	botas de escamas doradas
3848	cuchillo de bronce grande
3849	espada corta de hierro endurecido
3850	hoja serpentina de jade
3851	gran maza de hierro solido
3852	destructora de hierro dorado
3853	espada ancha de acero lunar
3854	hoja tigre de escarcha
3855	hacha de hierro macizo
3856	hacha curva de las sombras
3857	carbon
3858	mena de mitril
3859	barra de acero
3860	barra de mitril
3861	barra de acero negro
3862	tendon de gorila mayor
3863	pluma de acechador de la selva
3864	citrino
3866	diseno hoja serpentina de jade
3867	diseno destructora de hierro dorado
3868	diseno hoja tigre de escarcha
3869	diseno hacha curva de las sombras
3870	diseno sobrehombros de hierro verdes
3871	diseno sobrehombros de escamas doradas
3872	diseno leotardos de escamas doradas
3873	diseno loriga de escamas doradas
3874	diseno botas de acero pulido
3875	diseno botas de escamas doradas
3876	colmillo de bhag thera
3877	garfa de tethis
3879	garra de sin dall
3880	cabeza de bangalash
3882	pluma de aguila ratonera
3889	sombrero rojizo
3890	sombrero con tachuelas
3891	yelmo de anillas aumentado
3892	sombrero bordado
3893	gorro de cuero reforzado
3894	yelmo brigandina
3897	ojo de dizzy
3898	caligrafia de biblioteca
3899	leyendas de los gurubashi volumen 3
3900	oporto pupellyverbos
3901	colmillo sangrapellejo
3902	baston de nobles
3904	cabeza de gan zulah
3905	cabeza de nezzliok
3906	trofeo de balia mah
3907	trofeo de ziata jai
3908	trofeo de zul mamwe
3909	armadura de ana thek rota
3910	pizca de tabaco
3911	fragmento azul pulsante
3912	gema de alma
3913	gema de alma llena
3914	mochila de oficial
3915	collar de huesos sangrientos
3916	collar de hueso partido
3917	cristal canto azul
3918	fragmento de cristal canto
3919	menudillos de velo de bruma
3920	cartas de navegacion de los velasangre
3921	ordenes de los velasangre
3922	pago del tremulo
3923	brazales de elemental de agua
3924	pata de palo de maury
3925	catalejo dorado de jon jon
3926	anillo enorme de chucky
3927	queso cheddar curado bueno
3928	pocion de sanacion excelente
3929	botin de maury
3930	llave de maury
3931	colmillo de arana envenenado
3932	cofre de smotts
3935	alfanje de smotts
3936	cinturon de ganchillo
3937	botas de ganchillo
3938	brazales de ganchillo
3939	capa de ganchillo
3940	guantes de ganchillo
3941	pantalones de ganchillo
3942	hombreras de ganchillo
3943	jubon de ganchillo
3944	cinturon de sarga
3945	botas de sarga
3946	brazales de sarga
3947	capa de sarga
3948	guantes de sarga
3949	pantalones de sarga
3950	hombreras de sarga
3951	jubon de sarga
3952	cinturon de malla
3953	botas de malla
3954	brazales de malla
3955	capa de malla
3956	guantes de malla
3957	pantalones de malla
3958	manto de malla
3959	armadura de malla
3960	bolsa de brazales de elementales de agua
3961	cinturon de cuero grueso
3962	botas de cuero grueso
3963	brazales de cuero grueso
3964	capa gruesa
3965	guantes de cuero grueso
3966	pantalones de cuero grueso
3967	hombreras de cuero grueso
3968	guerrera de cuero grueso
3969	cinturon de cuero liso
3970	botas de cuero liso
3971	brazales de cuero liso
3972	capa lisa
3973	guantes de cuero liso
3974	pantalones de cuero liso
3975	hombreras de cuero liso
3976	armadura de cuero liso
3977	cinturon con correas
3978	botas con correas
3979	brazales con correas
3980	capa con correas
3981	guantes con correas
3982	pantalones con correas
3983	hombreras con correas
3984	armadura con correas
3985	fajin con monogramas
3986	paves protector
3987	torre deflectora
3988	escudo de pared de placa
3989	tarja de bloqueo
3990	rodela con emblema
3991	rodela de placas
3992	cinturon de escamas laminadas
3993	botas de escamas laminadas
3994	brazales de escamas laminadas
3995	capa de escamas laminadas
3996	guantes de escamas laminadas
3997	pantalones de escamas laminadas
3998	hombreras de escamas laminadas
3999	armadura de escamas laminadas
4000	cinturon de anillas superpuestas
4001	botas de anillas superpuestas
4002	brazales de anillas superpuestas
4003	capa de anillas superpuestas
4004	guantes de anillas superpuestas
4005	pantalones de anillas superpuestas
4006	hombreras de anillas superpuestas
4007	armadura de anillas superpuestas
4008	cinturon de anillas extraordinarias
4009	botas de anillas extraordinarias
4010	brazales de anillas extraordinarias
4011	capa de anillas extraordinarias
4012	guantes de anillas extraordinarias
4013	pantalones de anillas extraordinarias
4014	hombreras de anillas extraordinarias
4015	armadura de anillas extraordinarias
4016	mezcla de zanzil
4017	espada corta afilada
4018	mandoble afilado
4019	hacha de silex pesada
4020	hacha de batalla seccionadora
4021	maza contundente
4022	gran maza aplastante
4023	daga puntiaguda refinada
4024	baston de guerra pesado
4025	arco largo equilibrado
4026	mosquete de centinela
4027	hoja de catelyn
4028	fardo de canas akiris
4029	junco akiris
4030	agua de reliquia sagrada
4031	talisman de reliquia sacralizado
4032	martillo de reliquia radiante
4033	resplandor del alba
4034	piedra de las mareas
4035	toga de hilo de plata
4036	punos de hilo de plata
4037	pantalones de hilo de plata
4038	toga cielo nocturno
4039	capucha cielo nocturno
4040	guantes cielo nocturno
4041	capucha aurora
4042	guantes aurora
4043	brazales aurora
4044	pantalones aurora
4045	brazales escapabruma
4046	pantalones escapabruma
4047	botas escapabruma
4048	sombrero blasonado
4049	brazales blasonados
4050	leotardos blasonados
4051	botas blasonadas
4052	gorro de insignia
4053	piel de crocolisco fluvial
4054	leotardos de insignia
4055	botas de insignia
4056	el enigma de cortello
4057	coselete de insignia
4058	coraza con inscripciones
4059	brazales con inscripciones
4060	leotardos con inscripciones
4061	brazales de cuero imperiales
4062	pantalones de cuero imperiales
4063	guantes de cuero imperiales
4064	rodela blasonada
4065	escudo de combate
4066	rodela de insignia
4067	rodela con inscripciones
4068	escudo de brigadier
4069	rodela forjanegra
4070	blason de ajustador
4071	coraza de malla de luz tremula
4072	guanteletes de malla de luz tremula
4073	grebas de malla de luz tremula
4074	armadura de combate de malla
4075	guanteletes de combate de malla
4076	botas de combate de malla
4077	protegecabezas de combate de malla
4078	almofar de brigadier
4079	leotardos de brigadier
4080	capucha forjanegra
4082	coraza forjanegra
4083	guanteletes forjanegra
4084	leotardos forjanegra
4085	olla mecanica de krazek
4086	rifle cegador
4087	arco de tiro real
4088	hoja terrorifica
4089	trabuco rompebloques
4090	jarra o dano
4091	creaviudas
4092	escama de basilisco centelleante
4093	cola de basilisco grande
4094	fragmento de tablilla
4095	deprecate snare kit
4096	pelo de gorila burdo
4097	diente de gorila astillado
4098	nota doblada con cuidado
4099	mechon de pelo de gorila
4100	nota arrugada
4101	nota rasgada
4102	nota rota
4103	llave de grillete
4104	piel de crocolisco quijaforte
4105	piel de crocolisco mayor
4106	cristal caido
4107	guantes de cazador de tigres
4108	leotardos de cazador de panteras
4109	botas excelsior
4110	arco de maestro cazador
4111	rifle de maestro cazador
4112	gargantilla del alto chaman
4113	manto medicinal
4114	manteo marea oscura
4115	rodela grom gol
4116	olmann sewar
4117	fajin agostador
4118	pendiente para la nariz de poobah
4119	guerrera de cazador de raptores
4120	toga de aguas cristalinas
4121	guantes con gemas
4122	cetro de corredor de apuestas
4123	espaldares de metal escarchados
4124	almete de armonia
4125	orbe tranquilo
4126	cuchilla de guerrilla
4127	lanzatralla
4128	pala de plata
4129	placa de coleccion
4130	brujula de smotts
4131	cinturon de corrupcion
4132	braquiales lanza negra
4133	punos lanza negra
4134	baston mistico de nimboya
4135	sortija de hueso de sangre
4136	botas lanza negra
4137	zapatos lanza negra
4138	guerrera aguasnegras
4139	sandalias para la selva
4140	manto de fronda de palmera
4141	escrito sobre crear comida
4142	escrito sobre polimorfismo cerdo
4143	escrito sobre crear comida ii
4144	escrito sobre polimorfismo vaca
4145	escrito sobre crear gema de mana
4146	escrito sobre polimorfia oveja
4147	escrito sobre crear comida iii
4148	escrito sobre contrahechizo
4149	escrito sobre escudo contra escarcha iii
4150	escrito sobre crear agua iv
4151	escrito sobre descarga de escarcha iv
4152	escrito sobre crear comida iv
4153	escrito sobre misiles arcanos iii
4154	escrito sobre lentitud ii
4155	escrito sobre elemental de agua ii
4157	escrito sobre atenuar magia
4158	escrito sobre liberacion de khadgar iii
4159	escrito sobre misiles arcanos
4160	escrito sobre invisibilidad
4161	escrito sobre bola de fuego iv
4162	escrito sobre traslacion ii
4164	tratado luz sagrada v
4165	tratado luz sagrada vi
4166	tratado sello de proteccion
4167	tratado sentencia
4168	tablilla de totem enredador
4169	tablilla de voluntad ferrea ii
4170	tablilla de regreso astral
4171	tablilla de totem agitador iii
4172	tablilla de atronar ii
4173	tablilla de choque iv
4174	tablilla de choque v
4175	tablilla de escudo de relampagos iv
4176	tablilla de fuerza eterna ii
4177	tablilla de resistencia a la naturaleza
4178	tablilla de descarga de relampagos v
4179	tablilla de restauracion v
4180	tablilla de forma eterea ii
4181	tablilla de totem agitador iv
4182	tablilla de voluntad ferrea iii
4183	tablilla de totem sanador v
4184	tablilla de explosion de arrabio v
4185	tablilla de regreso astral en grupo
4186	tablilla de resistencia al fuego
4187	tablilla de totem serpiente v
4188	tablilla de totem de invisibilidad
4189	tablilla de cadena de relampagos
4190	armadura de plumas
4191	leotardos con plumas sin usar
4192	guanteletes con plumas sin usar
4194	brazales de plumas
4195	botas de plumas
4196	manto de plumas
4197	protectores de berilo
4198	grimorio cauce de almas
4199	grimorio cauce de almas ii
4200	grimorio inmolar iii
4201	grimorio ojo de kilrogg
4202	grimorio miedo ii
4203	grimorio pestilencia ii
4204	grimorio cauce de almas iii
4205	grimorio inmolar iv
4206	grimorio maldicion de sargeras ii
4207	grimorio maldicion de archimonde
4208	grimorio bomba mental
4209	grimorio resguardo contra las sombras
4210	grimorio crear sangrita inferior
4211	grimorio pestilencia
4212	grimorio maldicion de mannoroth iii
4213	grimorio fatalidad
4214	grimorio drenaje de vida iii
4215	grimorio lluvia de fuego
4216	grimorio resguardo contra lo sagrado
4217	grimorio cauce de almas iv
4218	grimorio crear sangrita
4219	grimorio espiritu ardiente iv
4220	grimorio hervor de sangre iii
4221	grimorio detectar invisibilidad
4223	libro sobre suprimir magia
4225	libro sobre raices enredadoras iii
4226	libro sobre colera vi
4228	libro sobre fuego lunar iv
4230	libro sobre toque de sanacion vi
4231	pellejo ligero curtido
4232	pellejo medio
4233	pellejo medio curtido
4234	cuero pesado
4235	pellejo pesado
4236	pellejo pesado curtido
4237	cinturon de cuero cosido a mano
4238	bolsa de lino
4239	guantes de cuero estampado
4240	bolsa de lana
4241	bolsa de lana verde
4242	pantalones de cuero estampado
4243	guerrera de cuero refinado
4244	jubon de cuero de montanero
4245	talega de seda pequena
4246	cinturon de cuero refinado
4247	guantes de cuero de montanero
4248	guantes de cuero oscuro
4249	cinturon de cuero oscuro
4250	cinturon de montanero
4251	sobrehombros de montanero
4252	sobrehombros de cuero oscuro
4253	guantes de cuero fortalecido
4254	guantes barbaricos
4255	armadura de cuero verde
4256	armadura de guardian
4257	cinturon de cuero verde
4258	cinturon de guardian
4259	brazales de cuero verdes
4260	brazales de cuero de guardian
4261	calzas de solliden
4262	cinturon de cuero con gemas incrustadas
4263	escudo de venta estandar
4264	cinturon barbarico
4265	refuerzo para armadura pesado
4266	codice de fuego interno ii
4267	codice de palabra de las sombras fracaso
4268	codice de sanar ii
4269	codice de rezo de sanacion
4270	codice de sanar iii
4271	codice de punicion sagrada v
4272	codice de proteccion contra lo sagrado
4273	codice de sanar
4274	codice de escape divino
4275	codice de putrefaccion mental
4276	codice de palabra de las sombras fracaso ii
4277	codice de palabra de las sombras ofuscar ii
4278	mena de sangrita inferior
4279	codice de palabra de las sombras dolor v
4280	codice de palabra sagrada escudo iv
4281	codice de proteccion contra las sombras
4282	codice de disipar magia ii
4283	codice de dormir iii
4284	codice de punicion sagrada vi
4285	codice de palabra sagrada entereza iv
4286	codice de rezo de sanacion ii
4287	codice de enfermedad de anulacion ii
4288	codice de eliminar maldicion ii
4289	sal
4290	cuenco de polvo
4291	hilo de seda
4292	patron bolsa de lana verde
4293	patron jubon de cuero de montanero
4294	patron cinturon de montanero
4296	patron sobrehombros de cuero oscuro
4297	patron guantes barbaricos
4298	patron cinturon de guardian
4299	patron armadura de guardian
4300	patron brazales de cuero de guardian
4301	patron cinturon barbarico
4302	daga verde pequena
4303	aplastacraneano
4304	cuero grueso
4305	madeja de pano de seda
4306	pano de seda
4307	guantes de lino gruesos
4308	brazales de lino verdes
4309	calzones de lino cosidos a mano
4310	guantes de lana gruesos
4311	capa de lana gruesa
4312	botas de lino de suela suave
4313	botas de lana roja
4314	sobrehombros de lana con doble pespunte
4315	sobrehombros de lana reforzada
4316	pantalones de lana gruesos
4317	pantalones fenix
4318	guantes de meditacion
4319	guantes de seda azur
4320	botas de seda de arana
4321	zapatillas de seda de arana
4322	capucha de encantador
4323	caperuza de las sombras
4324	jubon de seda azur
4325	botas del encantador
4326	capa larga de seda
4327	capa helada
4328	cinturon de arana
4329	cinturon de estrella
4330	camisa roja con estilo
4331	guantes fenix
4332	camisa amarillo brillante
4333	camisa de seda oscura
4334	camisa blanca formal
4335	camisa de seda morada viva
4336	camisa de espadachin negra
4337	seda de arana espesa
4338	pano de tejido magico
4339	madeja de tejido magico
4340	tinte gris
4341	tinte amarillo
4342	tinte morado
4343	pantalones de lino marrones
4344	camisa de lino marron
4345	patron botas de lana roja
4346	patron capa de lana gruesa
4347	patron sobrehombros de lana reforzada
4348	patron guantes fenix
4349	patron pantalones fenix
4350	patron zapatillas de seda de arana
4351	patron caperuza de las sombras
4352	patron botas del encantador
4353	patron cinturon de arana
4354	patron camisa de seda morada viva
4355	patron capa helada
4356	patron cinturon de estrella
4357	polvora ferrea
4358	dinamita ferrea
4359	punado de tornillos de cobre
4360	bomba de cobre ferrea
4361	tubo de cobre
4362	bocarda ferrea
4363	modulador de cobre
4364	polvora burda
4365	dinamita burda
4366	muneco diana
4367	carga de seforio pequena
4368	gafas de tigre volador
4369	trabuco mortal
4370	bomba grande de cobre
4371	tubo de bronce
4372	bocarda fabricada con amor
4373	gafas de las sombras
4374	bomba de bronce pequena
4375	cacharros zumbones de bronce
4376	deflector de llamas
4377	polvora potente
4378	dinamita potente
4379	escopeta de chapa de plata
4380	bomba de bronce grande
4381	recombobulador menor
4382	marco de bronce
4383	rifle de vista lunar
4384	oveja explosiva
4385	gafas tintadas de verde
4386	deflector de hielo
4387	tornapunta de hierro
4388	rayo descombobulador
4389	girocronatomo
4390	granada de hierro
4391	juego de segador de la cosecha compacto
4392	muneco diana avanzado
4393	monoculo de artesano
4394	bomba de hierro grande
4395	mina terrestre goblin
4396	dragonizo mecanico
4397	aparato de invisibilidad gnomico
4398	carga de seforio grande
4399	pila de madera
4400	surtido pesado
4401	caja de ardilla mecanica
4402	glandula de llamas pequena
4403	mortero de bronce portatil
4404	contacto de plata
4405	mira rudimentaria
4406	mira estandar
4407	mira de precision
4408	esquema ardilla mecanica
4409	esquema carga de seforio pequena
4410	esquema gafas de las sombras
4411	esquema deflector de llamas
4412	esquema rifle de vista lunar
4413	esquema rayo descombobulador
4414	esquema mortero de bronce portatil
4415	esquema monoculo de artesano
4416	esquema mina terrestre goblin
4417	esquema carga de seforio grande
4419	pergamino de intelecto iii
4421	pergamino de proteccion iii
4422	pergamino de aguante iii
4424	pergamino de espiritu iii
4425	pergamino de agilidad iii
4426	pergamino de fuerza iii
4428	pulpa de arana
4429	ordenes furiahonda
4430	dije etereo
4432	carta de sully balloo
4433	sobre estropeado por el agua
4434	calzas de espantapajaros
4435	mota de myzrael
4436	fajin taraceado con joyas
4437	baston de canalizador
4438	brazales de pugilista
4439	garrote moreton
4440	sigilo de strom
4441	licor de mackreel
4443	espaldares macabros
4444	escudo de coraza negra
4445	punzon de carne
4446	hoja veneno negro
4447	capa de la noche
4448	coraza de naraxis
4449	colmillo de naraxis
4450	trozo de sigilo
4453	sigilo de thoradin
4454	garfa de vultros
4455	arnes de pellejo de raptor
4456	cinturon de pellejo de raptor
4457	ala de aguila ratonera a la parrilla
4458	sigilo de arathor
4459	hueso de dragon fragil
4460	ala rasgada
4461	pellejo de raptor
4462	capa de putrefaccion
4463	collera de cuentas de raptor
4464	botas de paliza
4465	guanteletes de puno oseo
4466	sigilo de aterratrols
4467	sigilo de ignaeus
4468	trol kalar enfundada
4469	vara del orden
4470	madera simple
4471	silex y yesca
4472	pergamino de myzrael
4473	grilletes tetricos
4474	arco de madera de cuervo
4476	toga de caminabestias
4477	rodela nefaria
4478	leotardos de escamas iridiscentes
4479	talisman ardiente
4480	talisman del trueno
4481	talisman blasonado
4482	carpeta sellada
4483	llave ardiente
4484	llave blasonada
4485	llave del trueno
4487	cartas de navegacion de el capricho
4488	carta de navegacion del espiritu de argenteos
4489	cuaderno de bitacora de el capricho
4490	cuaderno de bitacora del espiritu de argenteos
4491	gafas de caza de gemas
4492	gema elfica
4493	gemas elficas
4494	carta lacrada de cuernomarino
4495	amuleto de sangrita
4496	faltriquera marron pequena
4497	bolsa marron pesada
4498	cartera de cuero marron
4499	saco marron enorme
4500	mochila de viajero
4502	muestra de gema elfica
4503	colmillo secacorteza
4504	capa de guardia enano
4505	calzas tierra pantanosa
4506	distintivo de stromgarde
4507	escudo de luchador de fosa
4508	armadura tintada de sangre
4509	guantes de lobo marino
4510	orbe de sangrita contaminada
4511	martillo de agua negra
4512	ojo de raptor de las tierras altas
4513	corazon de raptor
4514	peticion de sara balloo
4515	cabeza de marez
4516	cabeza de otto
4517	cabeza de falconcrest
4518	trozo de pergamino roto
4519	trozo de pergamino arrugado
4520	trozo de pergamino chamuscado
4521	granito de alterac
4522	faltriquera de medicinas secacorteza
4524	monumento a balloo
4525	varita de invocacion de trelane
4526	amuleto de garfa de raptor
4527	agata azur
4528	orbe de tor gan
4529	agata encantada
4530	filacteria de trelane
4531	orbe de trelane
4532	agata de ascuas de trelane
4533	carta lacrada para el archimago malin
4534	brazales con cierre de acero
4535	anillo de recuerdo de forjaz
4536	manzana roja lustrosa
4537	banana tel abim
4538	sandia vinarrota
4539	manzana de corteza de oro
4540	mendrugo de pan duro
4541	pan recien horneado
4542	pan de maiz humedo
4543	gorro de piel de draco blanco
4544	pan de especias de mulgore
4545	brazales de plata radiantes
4546	llamada del raptor
4547	irradiador gnomico
4548	almadena servomecanica
4549	sortija de fuego marino
4550	anillo aguafria
4551	cabeza de or kalar
4552	trozo de piedra lisa
4553	trozo de piedra dentado
4554	piedra pulida lustrosa
4555	cola escamosa espesa
4556	fragmento de caparazon moteado
4557	glandula ignea
4558	barrica vacia
4559	chu s quest item
4560	cimitarra fina
4561	tomahawk arrancacabelleras
4562	hacha severa
4563	garrote reforzado
4564	garrote con pinchos
4565	daga simple
4566	lanza larga robusta
4567	espada de condotiero
4568	hacha de bruto
4569	martillo acerrimo
4570	gran maza de madera de abedul
4571	cuchillo de guerra
4575	baston medicinal
4576	arco ligero
4577	escopeta compacta
4580	colmillo de dientes de sable
4581	parche de pelaje refinado
4582	cola tupida suave
4583	melena espesa
4584	pata de trofeo grande
4585	mandibula de arana chorreando
4586	piel de raptor lisa
4587	plumas de raptor tribal
4588	calavera de raptor pristino
4589	pluma elegante larga
4590	pico amarillo curvo
4591	ojo de aguila
4592	pargo de lodo boquilargo
4593	siluro mostacherizo
4594	bacalao piedrescama
4595	vino de vid de jungla
4596	pocion de sanacion descolorida
4597	receta pocion de sanacion descolorida
4598	cana de pescar goblin
4599	filete de jamon curado
4600	grog de cereza
4601	pan de platano tierno
4602	calabaza de cosecha lunar
4603	serviola moteada cruda
4604	champinon de bosque
4605	champinon con motas rojas
4606	colmenilla esponjosa
4607	moho de cueva delicado
4608	trufa negra cruda
4609	receta ala de aguila ratonera a la parrilla
4610	urna de piedra grabada
4611	perla azul
4612	corazon de draco negro
4613	caja negra corroida
4614	colgante de myzrael
4615	ataduras de latigoscuro
4616	pico de la suerte de ryedol
4621	brazal del embajador infernus
4622	nota lacrada para el consejero belgrum
4623	pocion de escudo de piedra inferior
4624	receta pocion de escudo de piedra inferior
4625	flor de fuego
4626	fragmento de piedra pequeno
4627	losa de piedra grande
4628	brazales de vinculo de roca
4629	cajon de suministros
4630	chatarra
4631	tablilla de ryun eh
4632	arcon de bronce ornamentado
4633	arcon de bronce pesado
4634	arcon de hierro
4635	amuleto de piemartillo
4636	arcon de hierro fuerte
4637	arcon de acero
4638	arcon de acero reforzado
4639	alga marina encantada
4640	signo de la tierra
4641	mano de dagun
4643	manteo de acero rictus
4644	el corazon heredado
4645	cadenas de hematus
4646	estrella de xil yeh
4647	compendio de yagyin
4648	sigilo del martillo
4649	nota de agarrahueso
4650	nota de bel dugur
4652	escudo salbac
4653	botas con talon de acero
4654	fosil misterioso
4655	carne de almeja gigante
4656	calabaza pequena
4658	capa de guerrero
4659	faja de guerrero
4660	botas para caminar
4661	manto brillante
4662	capa de oficial
4663	cinturon de oficial
4665	capa quemada
4666	cinturon de cuero quemado
4668	capa de anillas de batalla
4669	faja de anillas de batalla
4671	capa ancestral
4672	cinturon ancestral
4674	capa tribal
4675	cinturon tribal
4676	guanteletes esqueleticos
4677	capa de veterano
4678	faja de veterano
4680	capa de agua estancada
4681	faja de agua estancada
4683	capa vinculahechizo
4684	cinturon vinculahechizo
4686	capa de pano barbarico
4687	cinturon de pano barbarico
4689	capa de caza
4690	cinturon de caza
4692	capa ceremonial
4693	cinturon de cuero ceremonial
4694	espaldares brunidos
4695	capa brunida
4696	pichel de la lapida de tidesippe
4697	faja brunida
4698	manto de vidente
4699	cinturon de vidente
4700	bufas de cuero grabado
4701	capa grabada
4702	pico de prospector
4703	herramientas rotas
4705	espaldares de escamas luminiscentes
4706	capa de escamas luminiscentes
4707	faja de escamas luminiscentes
4708	cinturon brillante
4709	manto de cuero de bosque
4710	capa de bosque
4711	capa de luz tremula
4712	faja de malla de luz tremula
4713	capa de hilo de plata
4714	fajin de hilo de plata
4715	capa blasonada
4716	capa de combate
4717	cinturon de combate de malla
4718	manto cielo nocturno
4719	capa cielo nocturno
4720	fajin cielo nocturno
4721	manto de insignia
4722	capa de insignia
4723	pantalones de humbert
4724	yelmo de humbert
4725	espaldares de brigadier
4726	capa de brigadier
4727	faja de brigadier
4728	sobrehombro de oposti
4729	manto aurora
4731	cubrehombros con inscripciones
4732	capa con inscripciones
4733	espaldares forjanegra
4734	manto escapabruma
4735	capa escapabruma
4736	fajin escapabruma
4737	bufas de cuero imperiales
4738	cinturon de cuero imperial
4739	carne de zancudo de llanura
4740	pluma de zancudo de llanura
4741	leotardos de caballeria de stromgarde
4742	pelambre de puma montes
4743	fragmento cristalino pulsante
4744	brazales runicos arcanos
4745	brazales de jinete de guerra
4746	toga de orador del sino
4747	agua de poza de ventoro
4748	agua de poza de cuerno rojo
4749	agua del pozo ferocrin
4751	garfa de furia del viento
4752	pluma azur
4753	pluma de bronce
4755	jarra de agua
4756	pelambre de gato estropeada
4757	cascaras de huevo rotas
4758	garra de lobo de pradera
4759	garfa de zancudo de llanura
4763	arco corvo bosque negro
4765	espada ancha esmaltada
4766	hoja feral
4767	guantes de pano de cobre
4768	guantes de adepto
4769	penola trofeo de aguilon
4770	cinturon erizapuas
4771	capa de la cosecha
4772	capa calida
4775	pico roto
4776	pluma erizada
4777	gran maza de maderaferrea
4778	maza con pinchos pesada
4779	diente de kodo mate
4780	trozo de cuerno de kodo
4781	jubon susurrante
4782	toga de solsticio
4783	totem de viento de halcon
4784	piedra inerte
4785	cinturon de azufre
4786	cinturon de hombre sabio
4787	brea ardiente
4788	botas de agilidad
4789	botas de establo
4790	capa inferno
4791	agua encantada
4792	capa espiritu
4793	capa nemorosa
4794	brazales de lobo
4795	brazales de oso
4796	brazales de buho
4797	capa ignea
4798	capa runica gruesa
4799	capa anticuada
4800	pantalones de anillas poderosos
4801	garras de acechador
4802	garras de puma de las estepas
4803	diente de alfa de pradera
4804	corazon de lobo de pradera
4805	femur de puma de las estepas
4806	escama de zancudo de llanura
4807	molleja de aguilon
4808	piedra de pozo
4809	bellota ambar
4810	protectores de roca
4813	collera de cuero pequena
4814	colmillo descolorido
4816	leotardos de legionario
4817	mandoble bendito
4818	espada de verdugo
4819	sujetapapeles de saltatuercas
4820	rodela de guardian
4821	rodela de oso
4822	disco de buho
4823	agua de los videntes
4824	hacha borrosa
4825	hacha callosa
4826	hacha de maleante
4827	cinturon zahori
4828	cinturon de viento nocturno
4829	cinturon de sonador
4830	leotardos de dientes de sable
4831	pantalones de acecho
4832	sarong mistico
4833	sobrehombros gloriosos
4834	documentos de ventura y cia
4835	sobrehombros de elite
4836	orbe a prueba de fuego
4837	fuerza de voluntad
4838	orbe de poder
4840	bayoneta
4841	cuerno de arra chea
4843	piedra runica de amatista
4844	piedra runica de opalo
4845	piedra runica de diamante
4846	pinon del n º 5
4847	grilletes de vinculo elemental de lotwil
4848	hocico de jabaguerrero
4849	costillar de jabaguerrero
4850	planes de ataque erizapuas
4851	mapa manchado
4852	bomba cegadora
4854	capa con marca de demonio
4855	unused cloth shoulder a01 gray
4856	unused cloth shoulder a02 yellow
4857	unused cloth shoulder b01 silver
4858	unused cloth shoulder b02 black
4859	medallon del filo ardiente
4860	escama de furia reluciente
4861	guerrera de plumas impoluta
4862	cola de escorpido obrero
4863	herramientas gnomicas
4864	calavera de minshina
4865	pelambre estropeada
4866	cabeza de zalazane
4867	pata de escorpido rota
4869	garra de fizzle
4870	trozos de retal
4871	collar abrasador
4872	ojo de escorpido seco
4873	percebe seco y duro
4874	raspa limpia
4875	hueso baboso
4876	botas de cuero sangrientas
4877	punta de flecha de piedra
4878	arco roto manchado de sangre
4879	cadaver de conejo aplastado
4880	lanza rota
4881	sobre viejo
4882	llave de benedict
4883	ordenes del almirante valiente
4886	glandula de veneno de venocola
4887	ojo de makrura intacto
4888	mucosidad de reptador
4890	huevo de colazote
4891	amuleto de kron
4892	pelaje de tigre de durotar
4893	colmillo de leon de sabana
4894	rinon de zancudo de llanura
4895	cuerno de truenagarto
4896	higado de kodo
4897	glandula salivaria de halcon trueno
4898	glandula relampagueante
4903	ojo de la sombra ardiente
4904	antidoto venocola
4905	garra destrozada de sarkoth
4906	botas de caminante de lluvia
4907	guerrera de los bosques
4908	brazales nomadas
4909	leotardos de cazador kodo
4910	guantes de anillas pintados
4911	rodela de corteza gruesa
4913	cinturon de anillas pintado
4914	guantes de cuero desgastados por la batalla
4915	botas de lana suave
4916	jubon de lana suave
4917	leotardos de anillas desgastados por la batalla
4918	saco de suministros
4919	cinturon de lana suave
4920	manteo desgastado por la batalla
4921	leotardos cubiertos de polvo
4922	jubon de anillas dentadas
4923	hachuela primitiva
4924	garrote primitivo
4925	hoja de mano primitiva
4926	barril vacio de chen
4928	guardamunecas correarenas
4929	armadura de escorpido ligera
4930	bolsa de cuero hecha a mano
4931	arco corto de nogal
4932	cortaalas de arpia
4933	capa de luchador avezado
4935	faja ancha metalica
4936	botas llenas de barro
4937	rodela de carga
4938	baston de madera manchado
4939	espada bastarda firme
4940	mandiletes velados
4941	pegamento muy pegajoso
4942	botas de pellejo de tigre
4944	capa cosida a mano
4945	calavera con resplandor tenue
4946	botas de peso ligero
4947	daga dentada
4948	maza hiriente
4949	cuchilla de orco
4951	cinturon de chivato
4952	cerveza de trueno
4953	brebaje trogg
4954	cinturon nomada
4957	bolsa de dinero vieja
4958	capa estropeada por el sol
4959	tomahawk arrojadizo
4960	perdigon cegador
4961	baston de vigia de los suenos
4962	guantes con doble capa
4963	capa tronacuerno
4964	machacagoblins
4965	hacha de mano pezuna de sangre
4966	cabeza de mazzranache
4967	escudo de guerrero tribal
4968	arnes reforzado
4969	ataduras reforzadas
4970	leotardos de kodo sin rematar
4971	martillo de skorn
4972	botas de abiscorredor
4973	guardamunecas de cazador de las llanuras
4974	cuchillo de lucha compacto
4975	rodela de vigilante
4976	falda rocio de niebla
4977	espada de sentencia
4978	martillo de ryedol
4979	brazales de pano de piedra encantados
4980	guantes de prospector
4981	faltriquera de cinturon de agmond
4982	cinturon de prospector rasgado
4983	pulverizador de rocas
4984	craneo de fatalidad inminente
4986	piedra de energia con imperfecciones
4987	espada de capitan enano
4988	sortija de obsidiana ardiente
4989	toga de dragon mago
4990	braciles agostados
4992	carta de reclutamiento
4995	carta de reclutamiento firmada
4998	anillo de sangre
4999	voluntad de azora
5000	sortija de coral
5001	anillo de corazon
5002	dije verde resplandeciente
5003	medallon de fuego estelar de cristal
5004	marca del kirin tor
5005	colgante de chispa de ascuas
5006	diario de khazgorm
5007	sortija de espinas
5008	anillo de mercurio
5009	anillo de dominacion mental
5010	anillo de oro grabado
5011	anillo welken
5012	esporas de hongos
5013	bulbo fertil
5014	wrapping paper pt
5015	wrapped item pt
5016	calzas de artesano
5017	nitroglicerina
5018	pulpa de madera
5019	nitrato sodico
5020	llave del botin de kolkar
5021	palo explosivo de gann
5022	cabeza de aterrakodos
5023	cabeza de verog
5024	vial escarchado
5025	cabeza de hezrul
5026	alquitran
5027	esporas devueltas
5028	cetro de lord sakrasis
5029	dije del senor de los nagas
5030	brazales centauro
5038	lagrima de las lunas
5040	cuchillo de cazador de las sombras
5042	papel para envolver con lazo rojo
5043	obsequio con lazo rojo
5044	obsequio con lazo azul
5045	calavera obsequio
5046	regalo cerrado
5047	papel para envolver de calaveras
5048	papel para envolver con lazo azul
5049	lamina de hierro con autocierre
5050	llave de ignicion
5051	rata de madriguera
5052	rata de madriguera inconsciente
5054	churumbele
5055	cuerno de raptor intacto
5056	muestra de raiz
5057	sandia madura
5058	huevo de silitido
5059	garra de excavacion
5060	herramientas de ladron
5061	plata robada
5062	cabeza de raptor
5063	colmillo de kreenig grunucico
5064	garra de alabruja
5065	anillo de teniente arpia
5066	planta de fisura
5067	cabeza de serena
5068	semillas secas
5069	varita de fuego
5071	varita de las sombras
5072	calavera de lok
5073	calavera de nak
5074	calavera de kuz
5075	esquirla de sangre
5076	envio de botas
5077	lentes telescopicas
5078	medalla de theramore
5079	ojo de basilisco frio
5080	libro de contabilidad de gazlowe
5081	bolsa de pellejo de kodo
5082	cuero fino de kodo
5083	patron bolsa de pellejo de kodo
5084	cabeza del baron longavera
5085	colmillo de jabaespin erizapuas
5086	pezunas de zhebra
5087	pico de zancudo de llanura
5088	manual de instrucciones de la consola de control
5089	llave de la consola
5092	varita crines de acero carbonizada
5093	punal crines de acero
5094	escudo de guerra crines de acero
5095	atun blanco arco iris
5096	garras de merodeador
5097	esmeralda ojo de gato
5098	caparazon de quijaforte alterado
5099	pezuna de lakota mani
5100	pellejo de echeyakee
5101	colmillo de ishamuhale
5102	punta de cola de owatanka
5103	pluma de washte pawne
5104	corazon de isha awak
5105	cartucho explosivo
5107	camisa de manoberta
5108	cuero hierro negro
5109	trapos rompecantos
5110	toga de zahori dalaran
5111	manteo de rathorian
5112	hoja de ritual
5113	marca de la hermandad
5114	garfa cortada
5115	hueso de la suerte partido
5116	pluma de cola larga
5117	pendola vibrante
5118	diente plano grande
5119	pelo suelto refinado
5120	pelo de cola larga
5121	escama de kodo sucia
5122	pelo de kodo grueso
5123	punta de flecha de acero
5124	diente de raptor pequeno
5125	escama cargada
5126	conocimiento disfraz de defias
5127	conocimiento disfraz de pirata de los mares del sur
5128	muda de piel de lagarto
5129	conocimiento disfraz de enano hierro negro
5130	conocimiento disfraz de zahori de dalaran
5131	conocimiento disfraz de rompecantos
5132	conocimiento disfraz de hermandad
5133	mollejas humedas
5134	garra peluda pequena
5135	garra negra fina
5136	oreja peluda rasgada
5137	ojo brillante
5138	cabeza de cosechador
5139	libro sobre espinas
5140	polvora cegadora
5141	libro sobre recrecimiento
5142	libro sobre colera ii
5143	sangre de truenagarto
5145	libro sobre toque de sanacion ii
5147	libro sobre raices enredadoras ii
5148	libro sobre espinas ii
5149	libro sobre colera iii
5150	libro sobre toque de sanacion iii
5151	libro sobre colera iv
5152	libro sobre toque de sanacion iv
5153	libro sobre marca de lo salvaje iv
5154	libro sobre espinas iii
5155	libro sobre marca de lo salvaje ii
5156	libro sobre colera v
5158	libro sobre tranquilidad
5160	libro sobre toque de sanacion v
5163	libro sobre marca de lo salvaje iii
5164	alas de halcon trueno
5165	pluma de solescama
5166	glandula venenosa de tejemadera
5167	huevo de tejemadera
5168	semilla de brezomadera
5169	brote de brezomadera
5170	tumor musgoso
5172	capsula de la muerte
5173	muerteflor
5174	nota de neeru
5175	totem de tierra
5176	totem de fuego
5177	totem de agua
5178	totem de aire
5179	corazon musgoso
5180	collar de armonia
5181	manteo de seda vibrante
5182	hoja escalofrio
5183	corazon de hidra pulsante
5184	ampolla de cristal llena
5185	ampolla de cristal
5186	vasija parcialmente llena
5187	martillo de rhahk zor
5188	vasija llena
5189	fruta resplandeciente
5190	fronda fulgurante
5191	pua cruel
5192	espada de ladron
5193	manteo de la hermandad
5194	hacha de capataz
5195	guantes con motas de oro
5196	espetadora de acometida
5197	rodillo de cocinitas
5198	vara para remover de cocinitas
5199	pantalones de fundicion
5200	arpon para empalar
5201	baston de piedra ignea
5202	sobrecamisa de corsario
5203	garra de merodeador de las estepas
5204	cinturon sangrepluma
5205	fronda crecida
5206	raiz de cienaga
5207	varita opaca
5208	varita humeante
5209	varita luminiscente
5210	varita ardiente
5211	varita alba
5212	varita llameante
5213	varita agostadora
5214	varita de manto de la noche
5215	varita de ascuas
5216	varita umbria
5217	corazon maculo
5218	corazon de brezomadera pulcleris
5219	corteza grabada
5220	colmillo tuercepinos
5221	cabeza de melenas
5223	gema de mana vacia
5227	joya de mana vacia
5229	sangrita superior vacia
5232	piedra de alma menor
5233	piedra de relu
5234	fosil de gargavino
5235	varita de alquimista
5236	varita de combustible
5237	veneno de aturdimiento mental
5238	varita de madera
5239	varita de hueso negro
5240	varita antorcha
5241	palo de fuego enano
5242	varita de ceniza
5243	escupellamas
5244	varita sacralizada consagrada
5245	varita de invocador
5246	vara de excavacion
5247	vara de pena
5248	varita cegadora
5249	esquirla ardiente
5250	varita carbonizada
5251	ampolla de adivinacion
5252	varita de descomposicion
5253	encendedor goblin
5254	bufas bastas
5255	tomahawk jabaespin
5256	sonajero de kovork
5257	manteo con caperuza oscuro
5263	gasa de bolsillo
5264	muestra de cerveza de obsequio
5265	cerveza aguada
5266	ojo de adaegus
5267	kris escarlata
5268	cascara de silitido rajada
5269	icor de silitido
5270	oronja verde
5271	boleto rudo
5272	garabatos incomprensibles
5273	reliquia de mathystra
5274	manto rosa
5275	faja de vinculo
5279	desollador de arpia
5299	guantes de la luna
5302	rodela de cobalto
5306	baston de jinete del viento
5309	mosquete de soldado
5310	calzones de lobo marino
5311	botas con hebillas
5312	guanteletes ribeteados
5313	anillo totemico del clan
5314	manteo de cazador de jabalies
5315	guardabrazos de madera
5316	guerrera de malla de corteza
5317	guerrera de moho seco
5318	hacha zhovur
5319	espaldares azotadores
5320	botas de laminas acolchadas
5321	espada corta elegante
5322	martillo de demolicion
5323	linterna eterna
5324	martillo de ingeniero
5325	escudo de soldadura
5326	bordon flamigero
5327	pantalones de manitas grasientos
5328	cinturon cinchado
5329	figurilla de gato
5330	reliquia de copa elfica
5332	figurilla de gato resplandeciente
5334	oporto con 99 anos de antiguedad
5335	un costal de monedas
5336	pendiente grell
5337	guantes caminante
5338	sello de piedra lunar antiguo
5339	reptilia
5340	cucharon de caldera
5341	guerrera cubierta de esporas
5342	ponche de raptor
5343	capa de posadero
5344	hacha puntiaguda
5345	martillo madera de piedra
5346	arco de batalla de orco
5347	varita pestilente
5348	papiro desgastado
5349	magdalena magica
5350	agua magica
5351	anillo de cazarrecompensas
5352	libro los poderes inferiores
5353	mensaje para elissa brisaestelar
5354	carta para delgren
5355	faja de maestro de bestias
5356	vara para marcar
5357	escudo del valle
5359	manuscrito de lorgalis
5360	reliquia de altonato
5361	raspa mondadientes
5362	mordedor
5363	panuelo doblado
5364	lenguetazo de sal seca
5366	gema de alma resplandeciente
5367	instrumento de roca primitivo
5368	monedero vacio
5369	hueso mordisqueado
5370	cuchara doblada
5371	trozo de coral
5373	talisman de la suerte
5374	reloj de bolsillo pequeno
5375	palito para rascarse
5376	espejo roto
5377	concha de vieira
5379	cuchillo de bota
5380	carta lacrada para elissa
5381	carta lacrada para balthule
5382	colgante de anaia
5383	cabeza de athrikus narassin
5385	pata de reptador
5386	pelambre de acechalunas refinada
5387	capa de acechalunas encantada
5388	calavera de ran sangradientes
5389	totem de furbolg corrupto
5390	mensaje de fandral
5391	tierra rara
5392	daga cardoleno
5393	baston cardoleno
5394	guantes de entrenamiento en tiro con arco
5395	escudo de los bosques
5396	llave de la garganta de fuego
5397	polvora de los defias
5398	leotardos canope
5399	botas de rastreo
5400	sangre de cobrahn
5401	sangre de pythas
5402	sangre de anacondra
5403	sangre de serpentis
5404	sobrehombros de serpiente
5405	capa envuelta
5406	sangrita menor vacia
5411	totem de limpieza pezuna invernal
5412	ojo de trillador
5413	colmillo de acechalunas
5414	cuero cabelludo grisaceo
5415	totem de limpieza tronacuerno
5416	totem de limpieza ferocrin
5419	brazales ferales
5420	armadura de alma en pena
5421	encantamiento llamarada ignea
5422	leotardos zarza
5423	colmillo de boahn
5424	estatuilla antigua
5425	faja de escamas runicas
5426	beso de serpiente
5427	reloj de bolsillo rudimentario
5428	un libro de cocina exotico
5429	una bonita roca
5430	adorno intrincado
5431	petaca vacia
5432	pipa de nogal
5433	muneca harapienta
5435	peine lustroso
5437	cabello de bathran
5439	carcaj pequeno
5440	botella de enfermedad
5441	faltriquera de polvora pequena
5442	cabeza de arugal
5443	rodela con placas de oro
5444	manteo de minero
5445	anillo de zoram
5446	brazal elemental roto
5447	brazal elemental danado
5448	brazal elemental fracturado
5451	brazal elemental aplastado
5455	pergamino descifrado
5456	pergamino de adivinacion
5457	garra de vudu cortada
5458	cinturon tierraleno
5459	hacha defensora
5460	cura de orendil
5461	rama de cenarius
5462	vara de transformacion de dartol
5463	gema resplandeciente
5464	asta de hierro
5465	pata de arana pequena
5466	aguijon de escorpido
5467	carne de kodo
5468	carne de frenesi tierna
5469	carne de zancudo
5470	cola de truenagarto
5471	carne de venado
5472	kebab de arana kaldorei
5473	sorpresa de escorpido
5474	carne de kodo asada
5475	llave de madera
5476	filete de pez furia
5477	estofado de zancudo
5478	estofado de ratas de madriguera
5479	cola de lagarto crujiente
5480	venado magro
5481	cuernos de satiro
5482	receta kebab de arana kaldorei
5483	receta sorpresa de escorpido
5484	receta carne de kodo asada
5485	receta filete de pez furia
5486	receta estofado de zancudo
5487	receta estofado de ratas de madriguera
5488	receta cola de lagarto crujiente
5489	receta venado magro
5490	cabeza de colafuria
5493	lagrima de elune
5494	punado de polvo estelar
5498	perla lustrosa pequena
5500	perla iridiscente
5503	carne de almeja
5504	carne de almeja acida
5505	diario de teronis
5506	ojo acechador redondo
5507	catalejo ornamentado
5508	piedra lunar caida
5509	piedra de salud
5510	piedra de salud superior
5511	piedra de salud inferior
5512	piedra de salud menor
5513	jade de mana
5514	agata de mana
5516	colmillo de trillanodonte
5517	llave pequena de bronce
5518	pequena llave de hierro
5519	pomo de hierro
5520	diario de velinde
5521	llave de velinde
5522	piedra de hechizo
5523	percebe pequeno
5524	almeja gruesa
5525	almejas hervidas
5526	sopa de almejas
5527	almejas picantes a la goblin
5528	receta sopa de almejas
5529	polvo de tumba
5530	particulas cegadoras
5533	escrito de ilkrud magthrull
5534	almuerzo de parker
5535	compendio de los caidos
5536	mitologia de los titanes
5537	cabeza de sarilus fuenteviciosa
5538	alianza de vorrel
5539	carta de recomendacion
5540	daga con empunadura de perla
5541	martillo iridiscente
5542	capa con broche de perlas
5543	diseno martillo iridiscente
5544	calavera de dal zarpasangrante
5547	vara reconstruida
5565	piedra infernal
5566	asta rota
5567	gancho de plata
5568	guijarro liso
5569	algas
5570	huevo de musgondo
5571	faltriquera negra pequena
5572	faltriquera verde pequena
5573	bolsa de cuero verde
5574	bolsa de cuero blanco
5575	costal verde grande
5576	costal marron grande
5577	diseno brazales de bronce ferreos
5578	diseno coraza de bronce banada en plata
5579	martillo de guerra de milicia
5580	martillo de milicia
5581	baston de apoyo liso
5582	savia del espolon
5583	escama de dragon hada
5584	mostacho crepuscular
5585	ojo de trotador
5586	espada cardoleno
5587	garrote de raiz de espinas
5588	toxina de lydon
5589	guanteletes cubiertos de musgo
5590	brazales de cordon
5591	manteo chispeado
5592	faja apretada
5593	rodela de risco
5594	carta para jin zil
5595	martillo de matorral
5596	arco de fresno
5601	glandula de huevo eclosionado
5602	tela de arana pegajosa
5603	zurron de zumbang
5604	varita elfica
5605	cuchillo de poda
5606	guantes de jardineria
5608	capucha viva
5609	cincho de determinacion ferrea
5610	capa de entranas
5611	lagrima de dolor
5612	punos de hiedra
5613	baston del purificador
5614	golpe de seraph
5615	espada de lenador
5616	desgarrantranas
5617	leotardos de vagabundo
5618	capa de explorador
5619	ampolla de jade
5620	vial de sangre inocente
5621	ampolla de turmalina
5622	anillo de clero
5623	ampolla de amatista
5624	aro de la orden
5626	astillacalaveras
5627	hoja reliquia
5628	nota de zamah
5629	guantes de punomartillo
5630	guantes de pano de viento
5631	pocion de ira
5632	pocion de huida cobarde
5633	pocion de gran ira
5634	pocion de accion libre
5635	garra afilada
5636	pluma delicada
5637	colmillo grande
5638	niebla toxica
5639	ampolla de jade llena
5640	receta pocion de ira
5641	receta pocion de huida cobarde
5642	receta pocion de accion libre
5643	receta pocion de gran ira
5644	escrito sobre crear agua
5645	ampolla de turmalina llena
5646	vial de agua bendita
5647	escrito sobre traslacion
5648	escrito sobre armadura de escarcha iii
5649	escrito sobre ventisca
5650	escrito sobre crear agua iii
5654	toxina instantanea
5655	brida de yegua zaina
5656	brida de caballo marron
5657	receta toxina instantanea
5658	tratado sello de poderio
5659	ascuas humeantes
5660	tratado sello de rectitud
5661	tratado sello de rectitud ii
5662	tratado sello de rectitud iii
5663	cuerno del lobo rojo
5664	metralla corroida
5665	cuerno del lobo temible
5666	tratado sello de colera ii
5667	tratado sello de sabiduria ii
5668	cuerno del lobo marron
5669	restos de diablo de polvo
5670	tratado sello de colera iv
5671	tratado sello de poderio iii
5672	tratado exorcismo
5673	tratado exorcismo ii
5674	tratado exorcismo iii
5675	escamas cristalizadas
5676	tratado captar no muertos
5677	tratado ahuyentar no muertos
5678	tratado lacre de sacrificio
5679	tratado sello de sabiduria iii
5680	tratado sello de proteccion ii
5681	savia corrosiva
5682	tratado ahuyentar no muertos ii
5683	tratado escudo divino ii
5684	tratado sello de salvacion
5685	tratado redencion
5686	cabeza de ordanus
5687	llave del guardian
5689	llave de durmiente
5690	llave garra
5691	llave de la carretilla
5692	detonador a distancia rojo
5693	detonador a distancia azul
5694	explosivos ng 5 rojo
5695	explosivos ng 5 azul
5696	tablilla de choque
5697	tablilla de totem sanador
5698	tablilla de escudo de relampagos
5699	tablilla de lobo fantasmal
5700	tablilla de totem sanador ii
5701	tablilla de totem avizor
5702	tablilla de totem agitador ii
5703	tablilla de atronar
5704	tablilla de respiracion acuatica
5705	tablilla de totem sanador iii
5706	tablilla de totem serpiente iii
5707	tablilla de vision lejana
5708	tablilla de forma eterea
5709	tablilla de caminar sobre el agua
5710	tablilla de totem sanador iv
5711	tablilla de lobo fantasmal ii
5712	tablilla de totem serpiente iv
5713	tablilla de descarga de truenos
5714	tablilla de totem enredador ii
5715	tablilla de tormenta de relampagos iii
5716	tablilla de restauracion vi
5717	cartas de ventura y cia
5718	planos de ingenieria de ventura y cia
5719	grimorio drenaje de vida ii
5720	grimorio maldicion de mannoroth ii
5721	grimorio crear piedra de hechizo
5722	grimorio de succion de mana ii
5723	grimorio maldicion de sargeras iii
5724	grimorio maldicion de lenguas
5725	grimorio pestilencia iii
5726	grimorio crear sangrita superior
5727	grimorio cauce de mana
5728	grimorio lluvia de fuego ii
5729	grimorio miedo iii
5730	libro sobre rejuvenecimiento
5731	pergamino de mensaje
5732	ng 5
5733	mena sin identificar
5734	planos de la super segadora 6000
5735	sobre lacrado
5736	brazo mecanico de gerenzo
5737	disenos de camaleon alfa y beta
5738	talega camaleon
5739	arnes barbarico
5740	cohete de fuegos artificiales rojos
5741	trozo de roca
5742	daga de gemas
5743	anillo de piedra prismatica
5744	desollador palido
5748	arco largo centauro
5749	hacha guadana
5750	faja de jefe de guerra
5751	capa telarana
5752	punta de cola de dracoleon
5753	corona alborotada
5754	medallon de jauria de lobos
5755	placa trituradora de onice
5756	hoja tajante
5757	cayada de madera dura
5758	arcon de mitril
5759	arcon de torio
5760	arcon de eternio
5761	almadena yunquemar
5762	bolsa de lino roja
5763	bolsa de lana roja
5764	talega de seda verde
5765	talega de seda negra
5766	toga de zahori inferior
5767	togas violeta
5768	entrada a las carreras gnomas
5769	entrada a las carreras goblin
5770	togas de arcana
5771	patron bolsa de lino roja
5772	patron bolsa de lana roja
5773	patron togas de arcana
5774	patron talega de seda verde
5775	patron talega de seda negra
5776	baston de anciano
5777	hacha de valiente
5778	cachava primitiva
5779	espada bastarda de los renegados
5780	cinturon de escamas de murloc
5781	coraza de escamas de murloc
5782	armadura murloc gruesa
5783	brazales de escamas de murloc
5784	escama de murloc babosa
5785	escama murloc gruesa
5786	patron cinturon de escamas de murloc
5787	patron coraza de escamas de murloc
5788	patron armadura murloc gruesa
5789	patron brazales de escamas de murloc
5790	diario de soliceja
5791	diario de henrig soliceja
5792	medallon de filonavaja
5793	corazon de filonavaja
5794	veneno de escorpido salado
5795	caparazon de tortuga endurecido
5796	aleta dorsal taraceada
5797	lamina de indurio
5798	piezas de coche cohete
5799	pedido de piezas de kravel
5800	piezas de kravel
5801	guano del horado
5802	piezas de coches delicadas
5803	pizca de polvo onirico
5804	rumores goblin
5805	corazon de fanatismo
5806	cerveza de tontos
5807	informe de cerveza de tontos
5808	glandula de veneno de alaorgullo
5809	glandula de veneno de nido alto
5810	cadaver reciente
5811	crin de faucehielo
5812	togas de antiguedad
5813	ensena de emil
5814	armadura riachuelo
5815	piedra glacial
5816	luz de elune
5817	arco lunaris
5818	varita de destello lunar
5819	almofar llamarada sol
5820	manto feerico
5821	botas del acechador oscuro
5822	guanteletes de seto
5823	champinon venenoso
5824	tablilla de voluntad
5825	colgante de treshala
5826	esquema de kravel
5827	carta de fizzle pernolaton
5829	pico afilado
5830	cabeza de kenata
5831	cabeza de fardel
5832	cabeza de marcel
5833	mena de indurio
5834	barril de tabaco de mok morokk
5835	grog de mok morokk
5836	caja fuerte de mok morokk
5837	costilla de metaleador
5838	pergamino de piel de kodo
5839	pagina de diario
5840	lengua abrasadora
5841	corazon abrasador
5842	muestra bruta de mena
5843	garra de grenka
5844	trozo de rok alim
5845	costillar de carne
5846	nota lacrada de korran
5847	cabeza de ancalodo
5848	hueso hueco de buitre
5849	cajon de cascos de choque
5850	nota lacrada de belgrom
5851	llave de cozzle
5852	planos de regulador de combustible
5853	caparazon de silitido intacto
5854	garfa de silitido
5855	corazon de silitido
5857	caja con premio gnomo
5858	caja con premio goblin
5859	granada de fiesta
5860	legado de los aspectos
5861	comienzos de la amenaza de los no muertos
5862	propulsor de seforio
5863	estatutos de hermandad
5864	carnero gris
5865	propulsor de seforio modificado
5866	muestra de mena de indurio
5867	ampolla con grabados
5868	ampolla con grabados llena
5869	pezuna hendida
5871	pezuna grande
5872	carnero marron
5873	carnero blanco
5874	arnes carnero negro
5875	arnes carnero azul
5876	tuberculo hojazul
5877	caparazon de silitido rajado
5878	tabaco superior
5879	colgante crepuscular
5880	cajon con agujeros
5881	cabeza de kelris
5882	documentos del capitan
5883	lengua fangorroca bifida
5884	ojo de niebla negra sin reventar
5897	manual de propietario de husmeador
5916	llave de camara gnoma
5917	informe de espia
5918	cabeza de orco desafiante
5919	escudo de hierro ennegrecido
5936	cinturon de piel de animal
5937	llave de camara goblin
5938	pata de reptador pristina
5939	guantes de costura
5940	rodela de huesos
5941	pantalones de escamas de laton
5942	colgante enjoyado
5943	brazales falla
5944	grebas de la milicia popular
5945	diente de lodomuerto
5946	nota lacrada para elling
5947	certificado defias
5948	carta para jorgen
5949	tira de papel
5950	distintivo de reethe
5951	toallita humeda
5952	bulbo raquideo corrupto
5956	martillo de herrero
5957	jubon de cuero cosido a mano
5958	pantalones de cuero refinado
5959	glandula de veneno acido
5960	nota lacrada para el vigia backus
5961	pantalones de cuero oscuro
5962	pantalones de guardian
5963	leotardos barbaricos
5964	sobrehombros barbaricos
5965	capa de guardian
5966	guantes de guardian
5967	faja de nobleza
5968	botas bastas
5969	capa de regente
5970	guantes de serpiente
5971	manteo de plumas
5972	patron pantalones de cuero refinado
5973	patron leotardos barbaricos
5974	patron capa de guardian
5975	cinturon de rufian
5976	tabardo de hermandad
5996	elixir de respiracion acuatica
5997	elixir de defensa menor
5998	pedido de pico tormenta
6016	muestra de corazon de lobo
6037	barra de veraplata
6038	almeja gigante a la brasa
6039	receta almeja gigante a la brasa
6040	brazales de escamas doradas
6041	cadena de acero
6042	punta de escudo de hierro
6043	contrapeso de hierro
6044	diseno escudo con punta de hierro
6045	diseno contrapeso de hierro
6046	diseno cadena de acero
6047	diseno almofar de escamas doradas
6048	pocion de proteccion contra las sombras
6049	pocion de proteccion contra el fuego
6050	pocion de proteccion contra la escarcha
6051	pocion de proteccion contra lo sagrado
6052	pocion de proteccion contra la naturaleza
6053	receta pocion de proteccion contra lo sagrado
6054	receta pocion de proteccion contra las sombras
6055	receta pocion de proteccion contra el fuego
6056	receta pocion de proteccion contra la escarcha
6057	receta pocion de proteccion contra la naturaleza
6058	cinturon de cuero ennegrecido
6059	jubon nomada
6060	brazales de lienzo
6061	brazales de piedra gris
6062	brazales de cordon pesados
6063	guanteletes de acero frio
6064	discos de platino en miniatura
6065	ensayos de khadgar sobre convergencia dimensional
6066	cabeza de khan dez hepah
6067	oreja de centauro
6068	receta aceite de las sombras
6069	carne secada de forma rudimentaria
6070	brazales de piel de lobo
6071	cristal draenetista
6072	cabeza de khan jehn
6073	cabeza de khan shaka
6074	boquilla de cuerno de guerra
6075	informe de vimes
6076	pantalones estrechos
6077	trozo de llave maraudine
6078	escudo de piquero
6079	talisman rudimentario
6080	corazon de pantera de las sombras
6081	hongos del senor del lodo
6082	tumor zancaprofunda
6083	lagrimas rotas
6084	leotardos de guardia de ventormenta
6085	guerrera de lacayo
6086	suero de la verdad de faustin
6087	botarga de los paramos de poniente
6089	brebaje de zraedus
6091	cajon de piedras de energia
6092	botas de cria negra
6093	triturador orco
6094	hacha penetrante
6095	botas deambulantes
6096	camisa de aprendiz
6097	camisa de acolito
6098	toga de neofito
6116	toga de aprendiz
6117	camisa de escudero
6118	pantalones de escudero
6119	toga de neofito
6120	camisa de recluta
6121	pantalones de recluta
6122	botas de recluta
6123	toga de novicio
6124	pantalones de novicio
6125	arnes de camorrista
6126	pantalones de trampero
6127	botas de trampero
6129	toga de acolito
6130	camisa de trampero
6131	pantalones de trampero
6132	tratado sello de sabiduria
6133	tratado sello de furia
6134	cubretorso primitivo
6135	falda primitiva
6136	camisa de maton
6137	pantalones de maton
6138	botas de maton
6139	toga de novicio
6140	toga de aprendiz
6144	toga de neofito
6145	colgante de clarice
6146	madera a la deriva desecada
6147	cinturon viejo de rata
6148	botas cubiertas de telarana
6149	pocion de mana superior
6150	un nudo deshilachado
6166	mandibula de coyote
6167	informe de neeka
6168	garra de sacudidor denteserra
6169	costillar de denteserra sin preparar
6170	componentes de zahori
6171	guantes de cuidador de lobos
6172	provisiones extraviadas
6173	botas de nieve
6174	espada aleatoria de oposti
6175	artefacto atal ai
6176	escudo oblongo enano
6177	brazales de hierro forjado
6178	envio a nethergarde
6179	manteo de soldado
6180	piel de eslarc
6181	fetiche de hakkar
6182	antorcha poco iluminada
6183	antorcha pobre sin encender
6184	pata de reptador monstruoso
6185	chal de oso
6186	cercenadora trogg
6187	defensor enano
6188	apisonadoras de barro
6189	sobrehombros de anillas durables
6190	fragmento draenetista
6191	botas kimbra
6192	cabeza de khan hratha
6193	fardo de artefactos atal ai
6194	segadora para barricas
6195	armadura encerada
6196	cayada de noboru
6197	jubon de pellejo de crocolisco
6198	guardamunecas jurasicos
6199	sortija de viuda negra
6200	cinturon de guerra de gameg
6201	botas agiles
6202	guantes sin dedos
6203	escudo maton
6204	yelmo de huargo tribal
6205	pala para escarbar
6206	punzon
6207	jcj disenos de torre de la horda
6208	jcj disenos de torre de la alianza
6209	jcj certificado de mina de la horda
6210	jcj certificado de mina de la alianza
6211	receta elixir de fuerza de ogro
6212	cabeza de jammal an
6214	gran maza de cobre pesada
6215	palo de lucha equilibrado
6216	particulas misticas
6217	vara de cobre
6218	vara runica de cobre
6219	llave de tuerca arcoluz
6220	fragmento de meteorito
6222	formula imbuir pechera espiritu menor
6223	blason de villa oscura
6226	mandil sangriento
6238	toga de lino marron
6239	jubon de lino rojo
6240	jubon de lino azul
6241	toga de lino blanca
6242	toga de lino azul
6243	toga de lana verde
6244	ggggfg
6245	cartera de karnitol
6246	garra de odio feroz
6247	cuerno de odio feroz
6248	veneno scorpashi
6249	pellejo de kodo envejecido
6250	cerebro de can manafago
6251	ala abisal
6252	sangre de guardiavil
6253	paquete de zurdibrujo
6256	cana de pescar
6257	mollejas de roc
6258	higado de cueracero
6259	higado de groddoc
6260	tinte azul
6261	tinte naranja
6262	diario de galen
6263	mono azul
6264	toga de adepto superior
6265	fragmento de alma
6266	jubon de discipulo
6267	pantalones de discipulo
6268	guerrera de pionero
6269	calzas de pionero
6270	patron jubon de lino azul
6271	patron jubon de lino rojo
6272	patron toga de lino azul
6273	patron toga de lana verde
6274	patron mono azul
6275	patron toga de adepto superior
6276	nota mohosa
6277	papiro mohoso
6278	pergamino mohoso
6279	carta mohosa
6280	misiva mohosa
6281	calavera armadosea
6282	calzas de entierro sacro
6283	el libro de ur
6284	runas de invocacion
6285	grimorio egalin
6286	corazones puros
6287	trozo de tablilla atal ai
6288	tablilla atal ai
6289	pargo de lodo boquilargo crudo
6290	pececito luminoso
6291	pececito luminoso crudo
6292	pargo de lodo de 5 kilos
6293	sangre de murcielago seca
6294	pargo de lodo de 6 kilos
6295	pargo de lodo de 7 kilos
6296	parche de crin de murcielago
6297	calavera vieja
6298	colmillo de murcielago sangriento
6299	pescado con mala pinta
6300	trozo de coraza
6301	calavera de camionero vieja
6302	ala de insecto delicada
6303	caballa de piel escurridiza cruda
6304	pagina de diario mojada dia 4
6305	pagina de diario mojada dia 87
6306	pagina de diario mojada dia 512
6307	mensaje en una botella
6308	siluro mostacherizo crudo
6309	siluro de 8 kilos
6310	siluro de 10 kilos
6311	siluro de 12 kilos
6312	corazon de dalin
6313	corazon de comar
6314	manteo de maestro de lobos
6315	ballesta de flechas de acero
6316	delicia de furia del loch modan
6317	furia del loch modan crudo
6318	baston de ley de odo
6319	faja del cegato
6320	blason de comandante
6321	sello familiar de filargenta
6323	cetro del baron
6324	togas de arugal
6325	receta pececito luminoso
6326	receta caballa de piel escurridiza
6327	el pacificador
6328	receta pargo de lodo boquilargo
6329	receta delicia de furia de loch modan
6330	receta siluro mostacherizo
6331	hoja aullante
6332	anillo de perla negra
6333	daga azote de pinchos
6335	botas grisaceas
6336	guerrera de infanteria
6337	leotardos de infanteria
6338	vara de plata
6339	vara runica de plata
6340	pellejo de fenrus
6341	lampara de establo siniestra
6342	formula encantar pechera mana menor
6343	formula imbuir pechera espiritu
6344	formula encantar brazales espiritu menor
6345	formula imbuir capa proteccion
6346	formula encantar pechera mana inferior
6347	formula encantar brazales fuerza menor
6348	formula encantar arma destripadora de bestias menor
6349	formula encantar arma de 2m intelecto inferior
6350	botas de bronce ferreas
6351	cajon abollado
6352	cajon estropeado por el agua
6353	cofre pequeno
6354	cofre cerrado pequeno
6355	cofre cerrado robusto
6356	cofre maltrecho
6357	cajon sellado
6358	bocanegra graso
6359	pargo de fuego
6360	pez de escamas de acero
6361	atun blanco arco iris crudo
6362	bacalao piedrescama crudo
6363	siluro de 14 kilos
6364	siluro de 16 kilos
6365	cana de pescar fuerte
6366	cana de pescar lenoscuro
6367	cana de pescar de hierro grande
6368	receta atun blanco arco iris
6369	receta bacalao piedrescama
6370	aceite de bocanegra
6371	aceite de fuego
6372	pocion de velocidad de nado
6373	elixir de poder de fuego
6374	particulas encantadas
6375	formula encantar brazales espiritu inferior
6376	formula encantar botas aguante menor
6377	formula encantar botas agilidad menor
6378	manteo de vidente
6379	cinturon de cuero grabado
6380	rodela grabada
6381	capa brillante
6382	cinturon de cuero de bosque
6383	rodela de bosque
6384	camisa azul con estilo
6385	camisa verde con estilo
6386	musleras de malla de luz tremula
6387	brazales de malla de luz tremula
6388	espaldares de malla de luz tremula
6389	almofar de malla de luz tremula
6390	patron camisa azul con estilo
6391	patron camisa verde con estilo
6392	cinturon de arugal
6393	guantes de hilo de plata
6394	botas de hilo de plata
6395	amito de hilo de plata
6396	pechera blasonada
6397	guantes blasonados
6398	cinturon blasonado
6399	sobrehombros blasonados
6400	escudo de luz tremula
6401	patron camisa de seda oscura
6402	leotardos de combate de malla
6403	guardabrazos de combate de malla
6404	bufas de combate de malla
6405	calzas cielo nocturno
6406	botas cielo nocturno
6407	munequeras cielo nocturno
6408	guantes de insignia
6409	cinturon de insignia
6410	brazales de insignia
6411	armadura de brigadier
6412	botas de brigadier
6413	brazales de brigadier
6414	sello de sylvanas
6415	toga aurora
6416	botas aurora
6417	capa aurora
6418	fajin aurora
6419	mitones con inscripciones
6420	botas con inscripciones
6421	cinturon con inscripciones
6422	yelmo con inscripciones
6423	grebas forjanegra
6424	manteo forjanegra
6425	faja forjanegra
6426	brazales forjanegra
6427	toga escapabruma
6428	guantes escapabruma
6429	sombrero de zahori escapabruma
6430	coraza de cuero imperial
6431	botas de cuero imperiales
6432	capa imperial
6433	yelmo de cuero imperial
6435	gema ardiente imbuida
6436	gema ardiente
6438	brazal elemental mate
6439	brazal de vinculo roto
6440	latigo cerebral
6441	cabellera acechasombras
6442	cristal del oraculo
6443	pellejo descarriado
6444	lengua bifida
6445	muda de piel fragil
6446	bolsa de piel de culebra
6447	escudo de caparazon de tortuga desgastado
6448	punta de cola
6449	capa de escamas de lagarto resplandeciente
6450	venda de seda
6451	venda de seda gruesa
6452	contraveneno
6453	contraveneno fuerte
6454	manual contraveneno fuerte
6455	rueda de carro vieja
6456	baba acida
6457	piezas de ingenieria oxidadas
6458	pescado cubierto de aceite
6459	botines indomitos
6460	garra de cobrahn
6461	hombreras taraceadas con babosas
6462	cajon seguro
6463	anillo de fantasma profundo
6464	esencia de lamentos
6465	toga del mocasin
6466	capa de escamas descarriadas
6467	guantes de escamas descarriadas
6468	cinturon de escamas descarriadas
6469	golpe venenoso
6470	escama descarriada
6471	escama descarriada perfecta
6472	vibora hiriente
6473	armadura del colmillo
6474	patron capa de escamas descarriadas
6475	patron guantes de escamas descarriadas
6476	patron cinturon de escamas descarriadas
6477	fajin de pradera
6478	apisonadoras de ratas
6479	colgante malem
6480	leotardos descarriados escurridizos
6481	guanteletes de damire
6482	botas de caminafuego
6486	escama chamuscada
6487	cabeza de familiar vil
6488	tablilla simple
6489	papiro deteriorado
6490	papiro oscuro
6491	papiro pesado
6492	papiro tiznado
6493	papiro andrajoso
6494	papiro garabateado
6495	papiro estropeado
6496	papiro detallado
6497	papiro simple
6498	cuero de kodo grabado
6499	cuero de kodo grabado
6500	cuero de kodo grabado
6501	cuero de kodo grabado
6502	armadura de escamas violeta
6503	togas de arlequin
6504	espada de ala
6505	baston creciente
6506	botas de infanteria
6507	brazales de infanteria
6508	capa de infanteria
6509	cinturon de infanteria
6510	guanteletes de infanteria
6511	toga de oficial
6512	toga de discipulo
6513	fajin de discipulo
6514	capa de discipulo
6515	guantes de discipulo
6516	pergamino para invocar diablillos
6517	cinturon de pionero
6518	botas de pionero
6519	brazales de pionero
6520	capa de pionero
6521	guantes de pionero
6522	pez descarriado
6523	arnes con hebillas
6524	arnes de cuero con tachuelas
6525	arnes de bruto
6526	arnes de batalla
6527	toga ancestral
6528	toga vinculahechizo
6529	adorno lustroso
6530	reptadores nocturnos
6531	toga de pano barbarico
6532	adornos brillantes
6533	atraepeces acuadinamico
6534	barras de acero forjado
6535	tablilla de vergua
6536	jubon de sauce
6537	botas de sauce
6538	toga de sauce
6539	cinturon de sauce
6540	pantalones de sauce
6541	guantes de sauce
6542	manteo de sauce
6543	brazales de sauce
6544	pergamino de invocacion de abisario
6545	armadura de soldado
6546	leotardos de soldado
6547	guanteletes de soldado
6548	faja de soldado
6549	capa de soldado
6550	guardamunecas de soldado
6551	botas de soldado
6552	guerrera de bardo
6553	calzas de bardo
6554	guantes de bardo
6555	capa de bardo
6556	brazales de bardo
6557	botas de bardo
6558	cinturon de bardo
6559	rodela de bardo
6560	escudo de soldado
6561	armadura acolchada de vidente
6562	botas fulgurantes
6563	brazales fulgurantes
6564	capa fulgurante
6565	guantes fulgurantes
6566	amito fulgurante
6567	armadura fulgurante
6568	calzas fulgurantes
6569	toga fulgurante
6570	fajin fulgurante
6571	rodela de exploracion
6572	escudo defensor
6573	botas defensoras
6574	brazales defensores
6575	capa defensora
6576	faja defensora
6577	guanteletes defensores
6578	leotardos defensores
6579	bufas defensoras
6580	guerrera del defensor
6581	cinturon de exploracion
6582	botas de exploracion
6583	brazales de exploracion
6584	guerrera de exploracion
6585	capa de exploracion
6586	guantes de exploracion
6587	calzas de exploracion
6588	bufas de exploracion
6589	sortija viridiana
6590	botas forjabatalla
6591	guardamunecas forjabatalla
6592	armadura forjabatalla
6593	capa forjabatalla
6594	faja forjabatalla
6595	guanteletes forjabatalla
6596	musleras forjabatalla
6597	guardahombros forjabatalla
6598	rodela derviche
6599	escudo forjabatalla
6600	cinturon derviche
6601	botas derviche
6602	brazales derviche
6603	guerrera derviche
6604	manteo derviche
6605	guantes derviche
6607	leotardos derviche
6608	armadura brillante
6609	pano de sabio
6610	toga de sabio
6611	fajin de sabio
6612	botas de sabio
6613	brazales de sabio
6614	capa de sabio
6615	guantes de sabio
6616	pantalones de sabio
6617	manto de sabio
6619	manual el camino de la defensa
6620	papiro elaborado
6621	manual de provocacion
6622	espada de fanatismo
6623	pergamino para invocar a sucubo
6624	jarabe de ken zigla
6625	colgante cubierto de tierra
6626	colgante de dogran
6627	coraza de escama mutante
6628	garras del cuervo
6629	manteo esporidio
6630	rodela de nube de semillas
6631	raiz viva
6632	capa de escama fey
6633	cercenadora de carnicero
6634	unguento de ritual
6635	sapta de tierra
6636	sapta de fuego
6637	sapta de agua
6638	sapta de aire
6640	pezuna de acechador vil
6641	hoja inquietante
6642	armadura fantasma
6643	pececito hinchado
6644	caballa hinchada
6645	pargo de lodo hinchado
6646	atun hinchado
6647	siluro hinchado
6648	pergamino de totem piel de piedra
6649	pergamino de totem abrasador
6650	pergamino de totem corriente de sanacion
6651	botella de vino rota
6652	faltriquera de componentes
6653	antorcha de la llama latente
6654	antorcha de la llama eterna
6655	ascua resplandeciente
6656	cuarzo en bruto
6657	delicia de pez descarriado sabrosa
6658	collar de muestra
6659	calzas escarabajo
6660	daga de julie
6661	receta delicia de pez descarriado sabrosa
6662	elixir de crecimiento gigante
6663	receta elixir de crecimiento gigante
6664	manto vudu
6665	brazales embrujados
6666	botas deslizantes
6667	capa de ingeniero
6668	botas de dibujante
6669	sortija sacra
6670	armadura de pantera
6671	leotardos de gigante
6672	esquema bomba cegadora
6675	brazales templados
6676	rodela de agente
6677	varita de artesano de hechizos
6678	sortija de gracia elfica
6679	perforador de armaduras
6681	pincho de espinas
6682	togas del portavoz de la muerte
6684	vara de mando de husmeador
6685	manto del portavoz de la muerte
6686	yelmo con colmillo
6687	creacadaveres
6688	ornato susurravientos
6689	baston de espiritu del viento
6690	leotardos de ferine
6691	corvo de colmillosucio
6692	espetadora en punta
6693	garra de agamaggan
6694	corazon de agamaggan
6695	amuleto de hueso estigio
6696	arco de acechador nocturno
6697	manto de ala de murcielago
6698	piedra de pierce
6707	piedra de lapidis
6708	piedra de buenhombre
6709	jubon resplandor lunar
6710	patron jubon resplandor lunar
6711	piedra de kurtz
6712	cerradura de practicas
6713	pantalones rasgados
6714	dinamita para tontos
6715	desfibriladores estropeados
6716	esquema dinamita para tontos
6717	mecanismo electrico
6718	electromuelle
6719	cinturon natoviento
6720	ornato de espiritu cazador
6721	peto de kor
6722	esposas bestiales
6723	medalla de coraje
6724	piedra de backus
6725	rodela de marmol
6726	cinturon personalizado de razzeric
6727	mandiletes de competicion de razzeric
6728	piedra de brownell
6729	encendedor vigoroso de fizzle
6730	cota de malla de forjaz
6731	coraza de forjaz
6732	guantes de mecanico gnomico
6733	guanteletes de forjaz
6734	diseno cadena de forjaz
6735	diseno coraza de forjaz
6736	diseno guanteletes de forjaz
6737	pantalones de hojas secas
6738	hacha curva sangrante
6739	objetivo de abiscorredor
6740	fajin azur
6741	espada de guerra orca
6742	faja puno de piedra
6743	anillo de apoyo
6744	guantes de kapelan
6745	manteo correpresto
6746	rodela de basalto
6747	espaldares despota
6748	anillo de mono
6749	sortija de tigre
6750	aro de culebra
6751	chal de luto
6752	botas de lancero
6753	talisman de plumas
6754	monedero grande
6755	un pequeno contenedor de gemas
6756	joyero
6757	sello de jaina
6766	flayed demon skin old2
6767	colgante de tyranis
6773	cota de malla de maleante gelkis
6774	dedo de uthek
6775	escrito sobre divinidad
6776	escrito sobre valor
6777	escrito sobre rectitud
6778	escrito sobre justicia
6779	escrito sobre nobleza
6780	fajin lila
6781	jarra de bartleby
6782	distintivo del mariscal haggard
6783	llave de dentomuerto
6784	manoplas con abrazaderas
6785	poderes del vacio
6786	vestido sencillo
6787	vestido de lana blanco
6788	cinturon de cazador magram
6789	manta ceremonial de centauro
6790	anillo de calma
6791	botas de demonio
6792	espaldares sanguinos
6793	brazales auricos
6794	guanteletes tempesfuego
6795	camisa de espadachin blanca
6796	camisa de espadachin roja
6797	saltaojos
6798	arcabuz explosivo
6799	cabeza de vejrek
6800	mena umbria
6801	mandil barroco
6802	espada de augurio
6803	cana profetica
6804	martillo tormenta de viento
6805	cuerno de vorlus
6806	llama danzarina
6807	estofado de anca de rana
6808	mena de elunita
6809	medallon de elura
6810	gargantilla de surena
6811	lente de pez acuadinamica
6812	caja de elunita
6826	escama luminosa
6827	caja de suministros
6828	rodela visionaria
6829	espada de serenidad
6830	masticahuesos
6831	amenaza negra
6832	capa de anublo
6833	camisa de esmoquin blanca
6834	esmoquin negro
6835	pantalones de esmoquin negro
6836	zapatos para vestido
6837	vestido de boda
6838	colmillo de arana agostado
6839	cuerno carbonizado
6840	cuerno galvanizado
6841	vial de flogisto
6842	instrucciones de furen
6843	tonel de brebaje
6844	sangre ardiente
6845	roca ardiente
6846	misiva defias
6847	misiva hierro negro
6848	coral abrasador
6849	cascara asolada
6850	cabellera sangrapellejo
6851	esencia del exilio
6852	ojo eterno
6866	simbolo de la vida
6887	serviola moteada
6888	huevo a las finas hierbas
6889	huevo pequeno
6890	carne de oso ahumada
6891	receta huevo a las finas hierbas
6892	receta carne de oso ahumada
6893	llave de taller
6894	corazon de espiralico
6895	martillo de herreria de jordan
6897	manual camino del rabioso
6898	orbe de soran ruk
6899	orbe de brujo 35
6900	toga de sangre dorada encantada
6901	manteo de trillador resplandeciente
6902	braciles de serra kis
6903	pantalones de sonador de mirada
6904	mordisco de serra kis
6905	hacha arrecife
6906	punos de algas
6907	armadura tortuga
6908	vinculo de ghamoo ra
6909	golpe de la hidra
6910	pantalones de sanguijuela
6911	cincho musgoso
6912	duramen
6913	nucleo de duramen
6914	trozo soran ruk
6915	trozo de soran ruk grande
6916	escrito sobre divinidad
6926	notas de furen
6927	oreja de will el grande
6928	gargantilla de sangrita
6929	papiro de bath rah
6930	vara de mediacion
6931	escrito mohoso
6947	veneno instantaneo
6948	piedra de hogar
6949	veneno instantaneo ii
6950	veneno instantaneo iii
6951	veneno de aturdimiento mental ii
6952	pelaje de oso grueso
6953	puno de verigan
6966	hacha elunita
6967	espada elunita
6968	martillo elunita
6969	daga elunita
6970	favor de furen
6971	almofar endurecido con fuego
6972	camisote endurecido con fuego
6973	leotardos endurecidos con fuego
6974	guanteletes endurecidos con fuego
6975	hacha espiralica
6976	martillo de guerra espiralico
6977	espada espiralica
6978	hacha umbria
6979	hacha de haggard
6980	daga de haggard
6981	daga umbria
6982	maza umbria
6983	martillo de haggard
6984	espada umbria
6985	espada de haggard
6986	loto carmesi
6987	escama de pescado
6988	pergamino para invocar manafagos
6989	vial de sangre de odio feroz
6990	piedra infernal inferior
6991	carbon humeante
6992	envio de mena de jordan
6993	envio de mena refinada de jordan
6994	madera de roble de piedrablanca
6995	gema kor corrupta
6996	apuntes sobre armas de jordan
6997	manuscrito andrajoso
6998	botas nimbus
6999	libro del conciliabulo
7000	faja de duramen
7001	cetro de lapida
7002	rodela artica
7003	broches de alfazaques
7004	manteo de prelacion
7005	cuchillo para desollar
7006	escrito reconstruido
7007	equipamiento de elite de backus
7026	cinturon de lino
7027	botas de oscuridad
7046	pantalones de seda azur
7047	manos de oscuridad
7048	caperuza de seda azur
7049	guantes de fe verdadera
7050	cinta de seda
7051	jubon terraneo
7052	cinturon de seda azur
7053	capa de seda azur
7054	toga de poder
7055	cinturon de seda carmesi
7056	capa de seda carmesi
7057	sobrehombros de seda verdes
7058	jubon de seda carmesi
7059	sobrehombros de seda carmesies
7060	sobrehombros azur
7061	cinturon de seda terranea
7062	bombachos de seda carmesies
7063	toga de seda carmesi
7064	guantes de seda carmesies
7065	armadura de seda verde
7067	tierra elemental
7068	fuego elemental
7069	aire elemental
7070	agua elemental
7071	hebilla de hierro
7072	escama naga
7073	colmillo roto
7074	garra astillada
7075	nucleo de tierra
7076	esencia de tierra
7077	corazon de fuego
7078	esencia de fuego
7079	globo de agua
7080	esencia de agua
7081	aliento de viento
7082	esencia de aire
7083	gema kor purificada
7084	patron sobrehombros de seda carmesies
7085	patron sobrehombros azur
7086	patron cinturon de seda terranea
7087	patron capa de seda carmesi
7088	patron toga de seda carmesi
7089	patron capa de seda azur
7090	patron armadura de seda verde
7091	patron guantes de fe verdadera
7092	patron manos de oscuridad
7093	patron botas de oscuridad
7094	rama de madera a la deriva
7095	botas de cienaga
7096	pluma arrancada
7097	carne de pata
7098	colmillo astillado
7099	pinza cortada
7100	icor pegajoso
7101	ojo de insecto
7106	guantes del zodiaco
7107	cinturon de las estrellas
7108	escudo de infanteria
7109	rodela de pionero
7110	armadura de hilo de plata
7111	armadura cielo nocturno
7112	armadura aurora
7113	armadura escapabruma
7114	patron guantes de seda azur
7115	hacha reliquia
7116	daga reliquia
7117	martillo reliquia
7118	espada reliquia
7119	antena agitada
7120	bastion de ruga
7126	lingote de hierro humeante
7127	azurita en polvo
7128	pezuna de satiro sin rajar
7129	guanteletes brutales
7130	yelmo brutal
7131	tibia de faucedraco
7132	musleras brutales
7133	camisote brutal
7134	tibia de faucedraco robusta
7135	tibia de faucedraco rota
7146	la llave escarlata
7148	desfibriladores goblin
7166	daga de cobre
7170	espada aleatoria de oposti foo
7187	botas de vancleef
7188	escudo de guardia de ventormenta
7189	botas cohete goblin
7190	botas cohete agostadas
7191	cableado de fusibles
7192	esquema botas cohete goblin
7206	muestra de agua del lago espejo
7207	frasco de jennea
7208	llave de tazan
7209	cartera de tazan
7226	trastonitor maguitronic
7227	bocas de dragon de balnir
7228	helado de fresa de tigule
7229	jubon de expedicionario
7230	martillo poderoso de acometida
7231	carta de presentacion de astor
7247	cofre de arcas de contencion
7249	gema cargada de la falla
7266	tratado de ur sobre la magia de las sombras
7267	seda pristina de arana
7268	muestra de agua xavian
7269	frasco de deino
7270	cabello de la hermana sonriente
7271	colmillo de marfil impecable
7272	zarza electrificada
7273	palo totemico secacorteza
7274	rituales de poder
7275	los pergaminos de agamaggan
7276	capa de cuero cosida a mano
7277	brazales de cuero cosidos a mano
7278	carcaj de cuero ligero
7279	faltriquera de municion de cuero pequena
7280	pantalones de cuero basto
7281	brazales de cuero ligero
7282	pantalones de cuero ligero
7283	capa de cria negra
7284	guantes de cria roja
7285	guantes de cuero livianos
7286	escama de cria negra
7287	escama de cria roja
7288	patron pantalones de cuero basto
7289	patron capa de cria negra
7290	patron guantes de cria roja
7291	orbe infernal
7292	arca de contencion llena
7293	gema de mana de dalaran
7294	libro de contabilidad de andron
7295	cuaderno de tazan
7296	antorcha apagada
7297	pesadilla de morbent
7298	hoja de astucia
7306	cabeza de fenwick
7307	gusano carnivoro
7308	canto de manifestacion
7309	informe de estado de dalaran
7326	hacha de thun grim
7327	daga de thun grim
7328	maza de thun grim
7329	espada de thun grim
7330	rodela de infiltrado
7331	escudo falange
7332	armadura regia
7333	silbato de sobrestante
7334	toga de floracion
7335	guerrera de oso pardo
7336	cota de malla de madera salvaje
7337	la roca
7338	anillo de animo
7339	anillo con diamante minusculo
7340	solitario de diamante impecable
7341	anillo con cubo de circonio
7342	sortija de plata de piffeny
7343	llave inglesa de bingles
7344	antorcha de la llama sagrada
7345	destornillador de bingles
7346	martillo de bingles
7347	inversor de pinon de bingles
7348	guantes de flechero
7349	guantes de herborista
7350	brazales de discipulo
7351	botas de discipulo
7352	sobrehombros de cuero terraneo
7353	armadura acolchada de anciano
7354	botas de anciano
7355	brazales de anciano
7356	capa de anciano
7357	sombrero de anciano
7358	guantes de ratero
7359	guantes terraneos gruesos
7360	patron guantes de cuero oscuro
7361	patron guantes de herborista
7362	patron sobrehombros de cuero terraneo
7363	patron guantes de ratero
7364	patron guantes terraneos gruesos
7365	dentrituradora goblin
7366	guantes de anciano
7367	manto de anciano
7368	pantalones de anciano
7369	toga de anciano
7370	fajin de anciano
7371	carcaj pesado
7372	faltriquera para municion de cuero pesado
7373	leotardos de cuero oscurecido
7374	armadura de cuero oscurecido
7375	armadura de cria verde
7376	cartucho de bingles
7377	capa de cuero de escarcha
7378	brazales oscurecidos
7386	brazales de cria verde
7387	cinturon oscurecido
7388	llave calavera
7389	libro de contabilidad de ventura y cia
7390	botas oscurecidas
7391	botas prestas
7392	escama de cria verde
7406	cordon de infiltrado
7407	armadura de infiltrado
7408	sobrehombros de infiltrado
7409	botas de infiltrado
7410	brazales de infiltrado
7411	capa de espia
7412	guantes de infiltrado
7413	gorro de infiltrado
7414	pantalones de infiltrado
7415	bufas derviche
7416	brazales falange
7417	botas falange
7418	coraza falange
7419	capa falange
7420	protegecabezas falange
7421	guanteletes falange
7422	faja falange
7423	leotardos falange
7424	bufas falange
7425	cabeza de cyrik
7426	anillo ceruleo
7427	dije ceruleo
7428	pellejo de gato de las sombras
7429	armadura crepuscular
7430	toga crepuscular
7431	pantalones crepusculares
7432	capucha crepuscular
7433	guantes crepusculares
7434	botas crepusculares
7435	manto crepuscular
7436	manteo crepuscular
7437	punos crepusculares
7438	cinturon crepuscular
7439	coraza de centinela
7440	calzas de centinela
7441	gorro de centinela
7442	llave de gyromast
7443	guantes de centinela
7444	botas de centinela
7445	sobrehombros de centinela
7446	capa de centinela
7447	brazales de centinela
7448	faja de centinela
7449	patron leotardos de cuero oscurecido
7450	patron armadura de cria verde
7451	patron brazales de cria verde
7452	patron botas oscurecidas
7453	patron botas prestas
7454	coraza de caballero
7455	musleras de caballero
7456	protegecabezas de caballero
7457	guanteletes de caballero
7458	botas de caballero
7459	espaldares de caballero
7460	capa de caballero
7461	brazales de caballero
7462	faja de caballero
7463	rodela de centinela
7464	glifos de invocacion
7465	blason de caballero
7466	sortija bermellon
7467	collar bermellon
7468	toga regia
7469	leotardos regios
7470	sombrero de zahori regio
7471	guantes regios
7472	botas regias
7473	manto regio
7474	capa regia
7475	punos regios
7476	fajin regio
7477	guerrera de forestal
7478	leotardos de forestal
7479	yelmo de forestal
7480	guantes de forestal
7481	botas de forestal
7482	sobrehombros de forestal
7483	capa de forestal
7484	guardamunecas de forestal
7485	cordon de forestal
7486	coraza de capitan
7487	leotardos de capitan
7488	aro de capitan
7489	guanteletes de capitan
7490	botas de capitan
7491	guardahombros de capitan
7492	capa de capitan
7493	brazales de capitan
7494	guardarrenes de capitan
7495	rodela de capitan
7496	escudo de placas de campo
7497	sortija de marfil
7498	parte superior de la llave de gelkak
7499	mitad de la llave de gelkak
7500	parte inferior de la llave de gelkak
7506	mando universal gnomico
7507	orbe arcano
7508	orbe ley
7509	toga tejemana
7510	togas de fuego de hechizo inferior
7511	toga de nudos astral
7512	toga de encaje abisal
7513	varita ira ardiente
7514	varita furia de hielo
7515	orbe celestial
7516	instrucciones de tabetha
7517	guerrera delicada
7518	toga delicada
7519	pantalones delicados
7520	celada delicada
7521	guantes delicados
7522	botas delicadas
7523	hombreras delicadas
7524	manteo delicado
7525	brazales delicados
7526	cinturon delicado
7527	pechera de cabalista
7528	leotardos de cabalista
7529	yelmo de cabalista
7530	guantes de cabalista
7531	botas de cabalista
7532	bufas de cabalista
7533	capa de cabalista
7534	brazales de cabalista
7535	cinturon de cabalista
7536	escudo de pared de campeon
7537	escudo gotico
7538	armadura de campeon
7539	leotardos de campeon
7540	casco de campeon
7541	guanteletes de campeon
7542	grebas de campeon
7543	espaldares de campeon
7544	manteo de campeon
7545	brazales de campeon
7546	faja de campeon
7547	anillo de onice
7548	gargantilla de onice
7549	abrazo de hada
7550	honor de guerrero
7551	dije opalino entrelazado
7552	percha de halcon
7553	sortija del unicornio
7554	rama de sauce
7555	estrella regia
7556	orbe crepuscular
7557	vara delicada
7558	baculo fulgurante
7559	cana runica
7560	esquema mando universal gnomico
7561	esquema desfibriladores goblin
7566	espada de la familia de agamand
7567	hacha de la familia de agamand
7568	daga de la familia de agamand
7569	maza de la familia de agamand
7586	esperanza de tharnariun
7587	instrucciones de thun grim
7606	guanteletes polares
7607	varita de dientes de sable
7608	jarra de vidente de gran calidad
7609	baculo de ambar de anciano
7610	esfera aurora
7611	baculo escapabruma
7613	patron armadura de cuero verde
7626	fardo de pelajes
7627	paquete de dolanaar
7628	carta anodina
7629	carga de ukor
7646	cajon de suministros del meson
7666	collar destrozado
7667	ampolla de vision de talvash
7668	diario manchado de sangre
7669	rubi del collar destrozado
7670	zafiro del collar destrozado
7671	topacio del collar destrozado
7672	fuente de alimentacion del collar destrozado
7673	collar de mejoria de talvash
7674	envio a mathias
7675	calendario de envios defias
7676	te de cardo
7678	receta te de cardo
7679	colmillo de alcaudocielago
7680	escama de basilisco dorsaljade
7681	fragmento de golem de obsidiana
7682	atizador de tortura
7683	nudillos de laton sangrientos
7684	manto de mago sangriento
7685	orbe del vidente olvidado
7686	ojo de dorsacerado
7687	puno de dorsacerado
7688	caja toracica de dorsacerado
7689	amanecer morbido
7690	torno de ebano
7691	embozo embalsamado
7708	varita necrotica
7709	leotardos contagiados
7710	varita de entrenamiento de loksey
7711	toga de doan
7712	manto de doan
7713	vara ilusionaria
7714	hoja hipnotica
7715	informe de onin
7716	collar destrozado
7717	devastador
7718	sobrehombro de herod
7719	yelmo de rabioso enfurecido
7720	sombrero de melenablanca
7721	mano de rectitud
7722	amuleto triune
7723	poderio de mograine
7724	guanteletes de divinidad
7726	egida del comandante escarlata
7727	espaldares de velador
7728	togas de cautivador
7729	mosquete chesterfall
7730	triturador de cobalto
7731	dije de fragmento fantasmal
7733	baston de prehistoria
7734	bolsa de seis demonios
7735	rosa de jannok
7736	garrote de lucha
7737	diario de sethir
7738	guantes siempreverde
7739	manteo de madera
7740	medallon de gni kiv
7741	el baston de tsol
7742	esquema aparato de invisibilidad gnomico
7746	mencion de honor de la liga de expedicionarios
7747	protector vil
7748	rodela piedra de fuerza
7749	orbe omega
7750	manto de tragedia
7751	botas de vorrel
7752	destripador de suenos
7753	derramasangre
7754	botas de presagista
7755	sobrehombros pedernal
7756	guantes de adiestramiento de perros
7757	baston tejevientos
7758	chafarote despiadado
7759	pechera de arconte
7760	falda de jefe de guerra
7761	espetadora garra de acero
7766	odre de agua marron vacio
7767	odre de agua azul vacio
7768	odre de agua rojo vacio
7769	odre de agua marron lleno
7770	odre de agua azul lleno
7771	odre de agua rojo lleno
7786	partecabezas
7787	guardian rutilante
7806	chupachus
7807	chocolatina
7808	onza de chocolate
7809	vestido de pascua
7810	vial de agua pura
7811	gotas que quedan del agua mas pura
7812	brazales de manifestacion corrupta
7813	fragmento de agua
7846	colmillo de coyote del risco
7847	molleja de aguila ratonera
7848	fragmento de elemental de roca
7866	vasija de taumaturgia vacia
7867	vasija de sangre de dragon
7868	thieven kit
7869	arcon de lucius
7870	arcon de vasijas de taumaturgia
7871	muestra de robo
7872	utiles de ladron herrumbrados
7886	diario sin traducir
7887	collar y gema recuperados
7888	collar de mejora de jarkal
7906	cuernos de nez ra
7907	certificado de rateria
7908	diario de klaven mortoalerta
7909	aguamarina
7910	rubi estrella
7911	mena de veraplata
7912	piedra solida
7913	sobrehombros barbaricos de hierro
7914	coraza barbarica de hierro
7915	yelmo barbarico de hierro
7916	botas barbaricas de hierro
7917	guantes barbaricos de hierro
7918	sobrehombros de mitril pesado
7919	guanteletes de mitril pesado
7920	pantalones de escamas de mitril
7921	pantalones de mitril pesado
7922	yelmo de placas de acero
7923	llave de la torre defias
7924	brazales de escamas de mitril
7925	guantes de escamas de mitril
7926	pantalones de mitril ornamentado
7927	guantes de mitril ornamentado
7928	sobrehombros de mitril ornamentado
7929	leotardos de guerra orcos
7930	coraza de mitril pesado
7931	almofar de mitril
7932	sobrehombros de escamas de mitril
7933	botas de mitril pesado
7934	yelmo de mitril pesado
7935	coraza de mitril ornamentado
7936	botas de mitril ornamentado
7937	yelmo de mitril ornamentado
7938	guanteletes de veraplata
7939	coraza de veraplata
7941	hacha de mitril pesado
7942	hacha azul relumbrante
7943	espada de mitril maligna
7944	estoque de mitril deslumbrante
7945	maza negra grande
7946	martillo runico de mitril
7947	chafarote de ebano
7948	faja de thero shan
7949	leotardos de thero shan
7950	armadura de thero shan
7951	manos de thero shan
7952	botas de thero shan
7953	mascara de thero shan
7954	el despedazador
7955	mandoble de cobre
7956	martillo de guerra de bronce
7957	espada magna de bronce
7958	hacha de batalla de bronce
7959	anublo
7960	campeon de veraplata
7961	hoja fantasma
7963	coraza de acero
7964	piedra de afilar solida
7965	contrapeso solido
7966	piedra de pulir solida
7967	punta de escudo de mitril
7968	tesoro de los mares del sur
7969	espuelas de mitril
7970	g e a q
7971	perla negra
7972	icor de no muerto
7973	almeja de boca grande
7974	carne de almeja sabrosa
7975	diseno pantalones de mitril pesado
7976	diseno punta de escudo de mitril
7977	diseno guantes de escamas de mitril
7978	diseno sobrehombros barbaricos de hierro
7979	diseno coraza barbarica de hierro
7980	diseno yelmo barbarico de hierro
7981	diseno botas barbaricas de hierro
7982	diseno guantes barbaricos de hierro
7983	diseno pantalones de mitril ornamentado
7984	diseno guantes de mitril ornamentado
7985	diseno sobrehombros de mitril ornamentado
7986	diseno coraza de mitril ornamentado
7987	diseno yelmo de mitril ornamentado
7988	diseno botas de mitril ornamentado
7989	diseno espuelas de mitril
7990	diseno yelmo de mitril pesado
7991	diseno sobrehombros de escamas de mitril
7992	diseno hacha azul relumbrante
7993	diseno estoque de mitril deslumbrante
7994	diseno leotardos de guerra orcos
7995	diseno brazales de escamas de mitril
7996	sombrero de pesca desgastado
7997	mascara de defias roja
8006	el cachetero
8007	citrino de mana
8008	rubi de mana
8009	piedra de energia de dentrio
8026	tesoro de la familia garrett
8027	tesoro de krom brazorrecio
8028	diseno martillo runico de mitril
8029	diseno hoja de mitril maligna
8030	diseno chafarote de ebano
8046	diario de kearnen
8047	seta magenta
8048	atrapasuenos esmeralda
8049	collar tuercepinos
8050	joya de tallonkai
8051	pistola de bengalas
8052	piedra de energia an alleum
8053	fuente de poder obsidiana
8066	silbato de fizzule
8067	proyectil artesanal ligero
8068	proyectil artesanal pesado
8069	proyectil artesanal solido
8070	vale de recompensa
8071	palo de fritura
8072	llave de la torre de silixiz
8073	carretilla de mezcla modificada de zanzil
8074	cabeza de gallywix
8075	pan de masa fermentada magica
8076	bollo dulce magico
8077	agua mineral magica
8078	agua con gas magica
8079	agua cristalina magica
8080	pechera de placas ligeras
8081	cinturon de placas ligeras
8082	botas de placas ligeras
8083	brazales de placas ligeras
8084	guantes de placas ligeras
8085	pantalones de placas ligeras
8086	hombreras de placas ligeras
8087	muestra de mezcla alterada de zanzil
8088	cinturon de malla de placas
8089	botas de malla de placas
8090	brazales de malla de placas
8091	guantes de malla de placas
8092	yelmo de malla de placas
8093	leotardos de malla de placas
8094	armadura de malla de placas
8095	aceite de hinott
8106	armadura invernal
8107	botas invernales
8108	brazales invernales
8109	capa invernal
8110	guantes invernales
8111	manto invernal
8112	pantalones invernales
8113	toga invernal
8114	fajin invernal
8115	capucha invernal
8116	cinturon heraldico
8117	botas heraldicas
8118	brazales heraldicos
8119	coraza heraldica
8120	capa heraldica
8121	guantes heraldicos
8122	celada heraldica
8123	leotardos heraldicos
8124	bufas heraldicas
8125	brazales de mirmidon
8126	coraza de mirmidon
8127	manteo de mirmidon
8128	guanteletes de mirmidon
8129	faja de mirmidon
8130	grebas de mirmidon
8131	yelmo de mirmidon
8132	leotardos de mirmidon
8133	espaldares de mirmidon
8134	defensor de mirmidon
8135	escudo de cromita
8136	tumor gigantesco
8137	brazales de cromita
8138	peto de cromita
8139	guanteletes de cromita
8140	faja de cromita
8141	grebas de cromita
8142	barbuta de cromita
8143	quijotes de cromita
8144	espaldares de cromita
8146	garra maligna
8147	llave pequena de cobre
8148	llave de plata diminuta
8149	talisman vudu
8150	sal de roca
8151	frasco de mojo
8152	frasco de gran mojo
8153	atriplex salvaje
8154	escama de escorpido
8155	sacrificio de sathrah
8156	guardamunecas de ajustador
8157	peto de ajustador
8158	guanteletes de ajustador
8159	faja de ajustador
8160	grebas de ajustador
8161	visor de ajustador
8162	quijotes de ajustador
8163	espaldares de ajustador
8165	dragontina desgastada
8167	escama de tortuga
8168	pluma negro azabache
8169	pellejo grueso
8170	cuero basto
8171	pellejo basto
8172	pellejo grueso curtido
8173	refuerzo para armadura grueso
8174	sombrero de cuero comodo
8175	guerrera nochefugaz
8176	cinta nochefugaz
8177	espada de practicas
8178	espada de instruccion
8179	arco de cadete
8180	arco de caza
8181	rifle de caza
8182	rifle de perdigones
8183	arco de precision
8184	encendedor
8185	leotardos de escamas de tortuga
8186	varita funesta
8187	guantes de escamas de tortuga
8188	escopeta explosiva
8189	coraza de escamas de tortuga
8190	espada hanzo
8191	yelmo de escamas de tortuga
8192	sobrehombros nochefugaz
8193	pantalones nochefugaz
8194	cascanueces goblin
8195	capa nochefugaz
8196	cimitarra de ebano
8197	botas nochefugaz
8198	brazales de escamas de tortuga
8199	destructora de campo de batalla
8200	toga de gran vudu
8201	mascara de gran vudu
8202	pantalones de gran vudu
8203	coraza de escorpido resistente
8204	guantes de escorpido resistentes
8205	brazales de escorpido resistentes
8206	leotardos de escorpido resistentes
8207	sobrehombros de escorpido resistentes
8208	yelmo de escorpido resistente
8209	botas de escorpido resistentes
8210	sobrehombros de cuero salvaje
8211	jubon de cuero salvaje
8212	leotardos de cuero salvaje
8213	botas de cuero salvaje
8214	casco de cuero salvaje
8215	capa de cuero salvaje
8216	capa de gran vudu
8217	carcaj rapido
8218	faltriquera de municion de cuero grueso
8223	hoja del basilisco
8224	destripador de silitido
8225	perforadora corrupta
8226	el carnicero
8243	chucheria de scooby
8244	esfera draenetista perfecta
8245	guerrera imperial roja
8246	botas rojas imperiales
8247	brazales rojos imperiales
8248	capa roja imperial
8249	guantes rojos imperiales
8250	manto rojo imperial
8251	pantalones rojos imperiales
8252	toga imperial roja
8253	fajin imperial rojo
8254	aro rojo imperial
8255	faja de piel de serpiente
8256	botas de piel de serpiente
8257	brazales de piel de serpiente
8258	armadura de piel de serpiente
8259	capa de piel de serpiente
8260	guantes de piel de serpiente
8261	yelmo de piel de serpiente
8262	leotardos de piel de serpiente
8263	bufas de piel de serpiente
8264	guardamunecas fuerte ebano
8265	armadura fuerte ebano
8266	capa fuerte ebano
8267	guanteletes fuerte ebano
8268	faja fuerte ebano
8269	botas fuerte ebano
8270	casco fuerte ebano
8271	leotardos fuerte ebano
8272	hombreras fuerte ebano
8273	guardamunecas valerosos
8274	coselete valeroso
8275	rodela fuerte ebano
8276	guanteletes valerosos
8277	faja valerosa
8278	grebas valerosas
8279	yelmo valeroso
8280	musleras valerosas
8281	espaldares valerosos
8282	escudo valeroso
8283	armadura arcana
8284	botas arcanas
8285	braciles arcanos
8286	capa arcana
8287	guantes arcanos
8288	protectores arcanos
8289	leotardos arcanos
8290	toga arcana
8291	fajin arcano
8292	sombrero arcano
8293	cinturon de viajero
8294	botas de viajero
8295	brazales de viajero
8296	chaleco de viajero
8297	capa de viajero
8298	guantes de viajero
8299	yelmo de viajero
8300	leotardos de viajero
8301	bufas de viajero
8302	brazales de heroe
8303	coraza de heroe
8304	manteo de heroe
8305	guanteletes de heroe
8306	cinturon de heroe
8307	botas de heroe
8308	banda de heroe
8309	leotardos de heroe
8310	espaldares de heroe
8311	avambrazos de placas de alabastro
8312	coraza de alabastro
8313	rodela de heroe
8314	guanteletes de placas de alabastro
8315	faja de placas de alabastro
8316	grebas de placas de alabastro
8317	casco de placas de alabastro
8318	leotardos de placas de alabastro
8319	espaldares de placas de alabastro
8320	escudo de alabastro
8343	hilo de seda grueso
8344	hileras de plata
8345	yelmo cabeza de lobo
8346	guanteletes del mar
8347	guanteletes de dragontina
8348	yelmo de fuego
8349	coraza de plumas
8350	el anillo 1
8363	talisman de vudu chaman
8364	trucha cabeza de mitril
8365	trucha cabeza de mitril cruda
8366	trucha hinchada
8367	coraza de dragontina
8368	pellejo de lobo grueso
8383	carta lisa
8384	patron sombrero de cuero comodo
8385	patron guantes de escamas de tortuga
8386	patron toga de gran vudu
8387	patron mascara de gran vudu
8388	patron capa nochefugaz
8389	patron pantalones de gran vudu
8390	patron capa de gran vudu
8391	papada de hiena risitas
8392	pulmon de jabali maldito
8393	pinza de scorpok
8394	cerebro de basilisco
8395	patron coraza de escorpido resistente
8396	molleja de buitre
8397	patron brazales de escorpido resistentes
8398	patron guantes de escorpido resistentes
8399	patron botas de escorpido resistentes
8400	patron sobrehombros de escorpido resistentes
8401	patron leotardos de escorpido resistentes
8402	patron yelmo de escorpido resistente
8403	patron sobrehombros de cuero salvaje
8404	patron jubon de cuero salvaje
8405	patron casco de cuero salvaje
8406	patron botas de cuero salvaje
8407	patron leotardos de cuero salvaje
8408	patron capa de cuero salvaje
8409	patron sobrehombros nochefugaz
8410	ifrdhr
8411	coctel de zumo de pulmon
8412	polvo de scorpok machacado
8423	compuesto de cortex cerebral
8424	chicle de mollejas
8425	restos de loro
8426	pluma erizada grande
8427	cadaver de rata mutilada
8428	glandula cargada de rocio
8429	glandula perforada
8430	glandula de rocio vacia
8431	bobina de hilo de seda verde pistacho
8432	agua de mixilpixil
8443	adorno de gahz rilo
8444	llave de verdugo
8463	ordenes del jefe de guerra
8483	faltriquera de agua de vagayermos
8484	botiquin de la compania de aguas de gadgetzan
8485	jaula para gatos bombay
8486	jaula para gatos rex cornualles
8487	jaula para gatos atigrado naranja
8488	jaula para gatos atigrado plateado
8489	jaula para gatos gatito blanco
8490	jaula para gatos siames
8491	jaula para gatos atigrado negro
8492	jaula de loro papagayo rojo
8493	barrica de weegli
8494	jaula de loro papagayo azul
8495	jaula de loro senegal
8496	jaula de loro carolina
8497	cajon de conejos pataneve
8498	vastago esmeralda diminuto
8499	vastago carmesi diminuto
8500	buho comun
8501	lechuza gavilana
8502	caja de loteria de bronce
8503	caja de loteria de bronce pesada
8504	caja de loteria de hierro
8505	caja de loteria de hierro pesado
8506	caja de loteria de mitril
8507	caja de loteria de mitril pesado
8508	aleta grande
8523	equipo de prueba de campo
8524	fuente de alimentacion modelo 4711 ftz
8525	orden de compra de zinge
8526	tragano violeta
8527	equipo de prueba de campo sellado
8528	particulas violeta
8529	elixir de tragonublo
8543	hongos subacuaticos
8544	venda de tejido magico
8545	venda de tejido magico gruesa
8546	sales aromaticas potentes
8547	formula sales aromaticas potentes
8548	vara divinomatica
8563	mecazancudo rojo
8564	huevo de hipogrifo
8583	cuerno de la montura esqueletica
8584	pipeta de muestras abierta
8585	pipeta de muestras cerrada
8586	silbato del raptor rojo jaspeado
8587	trozos de insecto centipaar
8588	silbato del raptor esmeralda
8589	silbato viejo de raptor marfil
8590	silbato viejo de raptor obsidiana
8591	silbato del raptor turquesa
8592	silbato del raptor violeta
8593	equipo de analisis de patagolpe
8594	informe del analisis del insecto
8595	mecazancudo azul
8603	rocio cardizal
8623	localizador de emergencia oox 17 tn
8624	bengala roja
8625	bengala blanca
8626	bengala azul
8627	riendas del sable de la noche
8628	riendas del sable de la noche moteado
8629	riendas del sable de la noche rayado
8630	riendas del tigre de bengala
8631	riendas del sable de hielo rayado
8632	riendas del sable de hielo moteado
8633	riendas del leopardo
8643	huevo extraordinario
8644	huevo de primera
8645	huevo normal
8646	huevo estropeado
8647	cajon de huevos
8663	insignia de mitril
8683	manzana fresca de clara
8684	calimocho dulce de las tierras del interior
8685	entrega de calimocho de dran
8686	colgante de mitril
8687	descripcion del visitante de thredd lacrada
8703	sello de pericia
8704	localizador de emergencia oox 09 ti
8705	localizador de emergencia oox 22 fe
8707	escama electrificada de gahz rilla
8708	martillo de pericia
8723	cabeza del califa escorpijon
8724	secreto de rin ji
8743	libro sobre marca de lo salvaje
8744	libro sobre colera
8745	libro sobre toque de sanacion
8746	capucha entrelazada
8747	gorro de cuero endurecido
8748	almofar de malla doble
8749	sombrero de ganchillo
8750	casquete de cuero grueso
8751	almofar superpuesto
8752	aro de escamas laminadas
8753	casco de cuero liso
8754	casquete de sarga
8755	casco de placas ligeras
8756	libro sobre recrecimiento ii
8757	libro sobre fuego estelar
8758	libro sobre eliminar maldicion
8759	libro sobre recrecimiento iii
8760	libro sobre suprimir veneno
8761	libro sobre fuego estelar ii
8762	libro sobre rejuvenecimiento v
8763	libro sobre fuego lunar v
8764	libro sobre fuego feerico ii
8765	libro sobre recrecimiento iv
8766	rocio de gloria matinal
8768	libro sobre fuego estelar iii
8769	libro sobre espinas iv
8770	libro sobre fuego lunar vi
8771	libro sobre rejuvenecimiento vi
8772	libro sobre recrecimiento v
8773	libro sobre raices enredadoras v
8774	libro sobre toque de sanacion vii
8775	libro sobre tranquilidad ii
8776	libro sobre marca de lo salvaje vi
8777	libro sobre fuego lunar ix
8778	libro sobre rejuvenecimiento vii
8779	libro sobre fuego feerico iii
8780	libro sobre fuego estelar v
8781	libro sobre recrecimiento vii
8782	libro sobre espinas v
8783	libro sobre toque de sanacion ix
8784	libro sobre colera vii
8785	libro sobre rejuvenecimiento ix
8786	libro sobre tranquilidad iii
8787	libro sobre calma de animales
8788	libro sobre calma de animales ii
8789	libro sobre calma de animales iii
8790	libro sobre fuego feerico iv
8791	libro sobre recrecimiento viii
8792	libro sobre espinas vi
8793	libro sobre colera viii
8794	libro sobre toque de sanacion x
8795	libro sobre raices enredadoras vi
8796	libro sobre fuego lunar x
8797	libro sobre rejuvenecimiento x
8798	libro sobre fuego estelar vi
8799	libro sobre marca de lo salvaje vii
8800	libro sobre recrecimiento ix
8801	libro sobre tranquilidad iv
8802	escrito sobre intelecto arcano
8803	escrito sobre bola de fuego
8804	escrito sobre deflagracion arcana
8805	escrito sobre detectar magia
8806	escrito sobre eliminar maldicion inferior
8807	escrito sobre amplificar magia
8808	escrito sobre escudo de mana
8809	escrito sobre sueno
8810	escrito sobre sueno ii
8811	escrito sobre agostar
8812	escrito sobre deflagracion arcana ii
8813	escrito sobre atenuar magia ii
8814	escrito sobre bola de fuego v
8815	escrito sobre cono de frio
8816	escrito sobre descarga de escarcha v
8818	escrito sobre escudo de mana ii
8819	escrito sobre agostar ii
8820	escrito sobre resguardo contra el fuego ii
8821	escrito sobre amplificar magia ii
8822	escrito sobre deflagracion arcana iii
8823	escrito sobre explosion de fuego iv
8824	escrito sobre bola de fuego vi
8825	escrito sobre resguardo contra la escarcha iii
8826	escrito sobre misiles arcanos iv
8827	elixir de caminar sobre el agua
8828	escrito sobre descarga de escarcha vi
8829	escrito sobre cono de frio ii
8830	escrito sobre agostar iii
8831	loto cardeno
8832	escrito sobre ventisca iii
8833	escrito sobre escudo de mana iii
8834	escrito sobre atenuar magia iii
8835	escrito sobre bola de fuego vii
8836	lagrimas de arthas
8837	escrito sobre deflagracion arcana v
8838	solea
8839	carolina
8840	escrito sobre crear gema de mana ii
8841	escrito sobre explosion de fuego v
8842	escrito sobre descarga de escarcha vii
8843	escrito sobre resguardo contra el fuego iii
8844	escrito sobre sueno iii
8845	champinon fantasma
8846	gromsanguina
8847	escrito sobre agostar v
8848	escrito sobre fogonazo iv
8849	escrito sobre misiles arcanos v
8850	escrito sobre crear agua v
8851	escrito sobre bola de fuego viii
8852	escrito sobre intelecto arcano iv
8853	escrito sobre crear comida v
8854	escrito sobre cono de frio iii
8855	escrito sobre amplificar magia iii
8856	escrito sobre descarga de escarcha viii
8857	escrito sobre ventisca iv
8858	escrito sobre escudo de mana iv
8859	escrito sobre explosion de fuego vi
8860	escrito sobre bola de fuego ix
8861	escrito sobre crear gema de mana iii
8862	escrito sobre misiles arcanos vi
8863	escrito sobre atenuar magia iv
8864	escrito sobre fogonazo v
8865	escrito sobre armadura de hielo iii
8866	escrito sobre cono de frio iv
8867	escrito sobre descarga de escarcha ix
8868	escrito sobre crear agua vi
8869	escrito sobre resguardo contra el fuego iv
8870	escrito sobre invisibilidad superior
8871	escrito sobre crear comida vi
8872	escrito sobre ventisca v
8873	escrito sobre escudo de mana v
8874	escrito sobre agostar vi
8875	escrito sobre resguardo contra la escarcha iv
8876	escrito sobre resguardo contra la escarcha ii
8877	escrito sobre bola de fuego x
8878	escrito sobre explosion de fuego vii
8879	escrito sobre nova de escarcha iv
8880	escrito sobre deflagracion arcana vi
8881	escrito sobre liberacion de khadgar iv
8882	escrito sobre amplificar magia iv
8883	escrito sobre intelecto arcano v
8884	escrito sobre descarga de escarcha x
8885	escrito sobre misiles arcanos vii
8886	escrito sobre fogonazo vi
8887	escrito sobre agostar vii
8888	escrito sobre cono de frio v
8889	escrito sobre crear gema de mana iv
8890	escrito sobre bola de fuego xi
8891	escrito sobre armadura de hielo iv
8892	escrito sobre crear agua vii
8893	escrito sobre sueno iv
8894	escrito sobre atenuar magia v
8895	escrito sobre ventisca vi
8896	escrito sobre escudo de mana vi
8897	escrito sobre resguardo contra el fuego v
8898	escrito sobre deflagracion arcana iv
8899	escrito sobre agostar iv
8900	libro sobre raices enredadoras iv
8901	libro sobre toque de sanacion viii
8902	libro sobre marca de lo salvaje v
8903	libro sobre fuego lunar vii
8904	libro sobre fuego lunar viii
8905	libro sobre recrecimiento vi
8906	libro sobre rejuvenecimiento viii
8907	libro sobre fuego estelar iv
8909	tratado golpe sagrado ii
8910	tratado imposicion de manos
8911	tratado puno de justicia
8912	tratado golpe de cruzado
8913	tratado golpe sagrado iii
8914	tratado golpe de cruzado ii
8915	tratado golpe sagrado iv
8916	tratado puno de justicia ii
8917	tratado imposicion de manos ii
8918	tratado sello de proteccion iii
8919	tratado golpe sagrado v
8920	tratado golpe de cruzado iii
8921	tratado puno de justicia iii
8922	tratado golpe sagrado vi
8923	esencia de agonia
8924	polvo de deterioro
8925	vial de cristal
8926	veneno instantaneo iv
8927	veneno instantaneo v
8928	veneno instantaneo vi
8929	tratado exorcismo iv
8930	tratado sello de rectitud iv
8931	tratado golpe de cruzado iv
8932	queso curado de alterac
8933	tratado luz sagrada vii
8934	tratado golpe sagrado vii
8935	tratado sentencia ii
8936	tratado sello de colera iii
8937	tratado imposicion de manos iii
8938	tratado ahuyentar no muertos iii
8939	tratado exorcismo v
8940	tratado puno de justicia iv
8941	tratado luz sagrada viii
8942	tratado sello de rectitud v
8943	tratado golpe sagrado viii
8944	tratado golpe de cruzado v
8945	tratado sentencia iii
8947	tratado exorcismo vi
8948	boletus edulis seco
8949	elixir de agilidad
8950	tarta de cerezas casera
8951	elixir de defensa superior
8952	codorniz asada
8953	platano frito
8954	codice de palabra sagrada entereza
8955	codice de desvanecerse
8956	aceite de inmolacion
8957	mero espinoso
8958	codice de explosion mental
8959	mero espinoso crudo
8960	codice de curar enfermedad
8961	codice de alarido psiquico
8962	codice de explosion mental ii
8963	codice de calma mental
8964	codice de sanacion relampago
8965	codice de desvanecerse ii
8966	codice de encadenar no muerto
8967	codice de explosion mental iii
8968	codice de quemar mana
8969	codice de sanacion relampago ii
8971	codice de alarido psiquico ii
8972	codice de explosion mental iv
8973	pellejo de yeti grueso
8974	codice de control mental
8975	codice de desvanecerse iii
8976	codice de suprimir enfermedad
8977	codice de quemar mana ii
8978	codice de sanacion relampago iii
8980	codice de explosion mental v
8981	codice de calma mental ii
8983	codice de sanacion relampago iv
8984	veneno mortal iii
8985	veneno mortal iv
8986	codice de encadenar no muerto ii
8987	codice de proteccion contra lo sagrado ii
8988	codice de quemar mana iii
8989	codice de desvanecerse iv
8990	codice de explosion mental vi
8991	codice de fuego interno iv
8992	codice de alarido psiquico iii
8993	codice de proteccion contra las sombras ii
8994	codice de palabra de las sombras dolor vi
8995	codice de palabra sagrada escudo vii
8996	codice de resurreccion iii
8997	codice de control mental ii
8998	codice de vision mental ii
8999	codice de sanacion relampago v
9000	codice de renovar vii
9001	codice de sanacion superior ii
9002	codice de explosion mental vii
9003	codice de punicion sagrada vii
9004	codice de palabra sagrada entereza v
9005	codice de quemar mana iv
9006	codice de palabra sagrada escudo viii
9007	codice de desvanecerse v
9008	codice de rezo de sanacion iii
9009	codice de fuego interno v
9010	codice de sanacion relampago vi
9011	codice de palabra de las sombras dolor vii
9012	codice de renovar viii
9013	codice de sanacion superior iii
9014	codice de calma mental iii
9015	codice de explosion mental viii
9016	codice de punicion sagrada viii
9017	codice de proteccion contra lo sagrado iii
9018	codice de palabra sagrada escudo ix
9019	codice de renovar ix
9020	codice de alarido psiquico iv
9021	codice de quemar mana v
9022	codice de sanacion relampago vii
9023	codice de proteccion contra las sombras iii
9024	codice de control mental iii
9025	codice de sanacion superior iv
9026	codice de resurreccion iv
9027	codice de explosion mental ix
9028	codice de palabra de las sombras dolor viii
9029	codice de desvanecerse vi
9030	pocion restauradora
9031	codice de encadenar no muerto iii
9032	codice de rezo de sanacion iv
9033	codice de fuego interno vi
9034	codice de palabra sagrada entereza vi
9035	codice de palabra sagrada escudo x
9036	pocion de resistencia a la magia
9037	tablilla de arma de muerdepiedras
9039	tablilla de choque de tierra
9040	tablilla de ola de sanacion ii
9041	tablilla de totem nexo terrestre
9043	tablilla de totem garra de piedra
9044	tablilla de choque de tierra ii
9046	tablilla de totem fuerza de la tierra
9047	tablilla de choque de llamas
9048	tablilla de renacer
9049	tablilla de totem nova de fuego
9050	tablilla de ola de sanacion iii
9051	tablilla de choque de tierra iii
9052	tablilla de totem piel de piedra ii
9053	tablilla de arma de muerdepiedras ii
9054	tablilla de choque de llamas ii
9055	tablilla de totem garra de piedra ii
9056	tablilla de ola de sanacion iv
9057	tablilla de arma estigma de escarcha
9058	tablilla de choque de escarcha
9059	tablilla de arma lengua de fuego
9060	cilindro de mitril taraceado
9061	combustible de cohete goblin
9062	tablilla de curar enfermedad
9063	tablilla de totem contraveneno
9064	tablilla de arma lengua de fuego ii
9065	tablilla de totem nova de fuego ii
9066	tablilla de totem de resistencia a la escarcha
9067	tablilla de totem fuerza de la tierra ii
9068	tablilla de totem piel de piedra iii
9069	tablilla de choque de tierra iv
9070	tablilla de ola de sanacion v
9071	tablilla de totem fuente de mana
9072	tablilla de totem lengua de fuego
9073	tablilla de arma viento furioso
9074	tablilla de choque de llamas iii
9075	tablilla de totem de resistencia al fuego
9076	tablilla de totem de magma
9077	tablilla de totem garra de piedra iii
9078	tablilla de totem derribador
9079	tablilla de choque de relampagos
9080	tablilla de totem de resistencia a la naturaleza
9081	tablilla de totem corriente de sanacion ii
9082	tablilla de arma de muerdepiedras iii
9083	tablilla de totem abrasador iii
9084	tablilla de totem viento furioso
9085	tablilla de totem nova de fuego iii
9086	tablilla de ola de sanacion vi
9087	tablilla de purgar ii
9088	ofrenda de arthas
9089	tablilla de choque de escarcha ii
9090	tablilla de arma estigma de escarcha ii
9091	tablilla de totem piel de piedra iv
9092	tablilla de totem avizor
9093	tablilla de totem fuente de mana ii
9094	tablilla de arma lengua de fuego iii
9095	tablilla de choque de tierra v
9096	tablilla de totem de limpieza de enfermedades
9097	tablilla de totem de magma ii
9098	tablilla de totem fuerza de la tierra iii
9099	tablilla de totem garra de piedra iv
9100	tablilla de escudo de relampagos v
9101	tablilla de arma viento furioso ii
9102	tablilla de cadena de relampagos ii
9103	tablilla de totem corriente de sanacion iii
9104	tablilla de totem abrasador iv
9105	tablilla de ola de sanacion vii
9123	tablilla de descarga de relampagos vi
9124	tablilla de choque de relampagos ii
9125	tablilla de totem gracia del aire
9126	tablilla de totem lengua de fuego ii
9127	tablilla de totem de resistencia al fuego ii
9128	tablilla de totem nova de fuego iv
9129	tablilla de arma de muerdepiedras iv
9130	tablilla de totem de resistencia a la naturaleza ii
9131	tablilla de totem piel de piedra v
9132	tablilla de explosion de arrabio vi
9133	tablilla de sanacion en cadena ii
9134	tablilla de totem viento furioso ii
9135	tablilla de choque de escarcha iii
9136	tablilla de totem fuente de mana iii
9137	tablilla de escudo de relampagos vi
9138	tablilla de totem de magma iii
9139	tablilla de arma estigma de escarcha iii
9140	tablilla de cadena de relampagos iii
9141	tablilla de totem garra de piedra v
9142	tablilla de choque de tierra vi
9143	tablilla de ola de sanacion viii
9144	pocion de atriplex salvaje
9145	tablilla de descarga de relampagos vii
9146	tablilla de totem abrasador v
9147	tablilla de totem corriente de sanacion iv
9148	tablilla de arma lengua de fuego iv
9149	piedra filosofal
9150	tablilla de totem fuerza de la tierra iv
9151	tablilla de choque de llamas v
9152	tablilla de totem nova de fuego v
9153	planos de la plataforma
9154	elixir de deteccion de no muertos
9155	elixir arcano
9156	tablilla de explosion de arrabio vii
9157	tablilla de sanacion en cadena iii
9158	tablilla de totem de resistencia a la escarcha iii
9159	tablilla de choque de relampagos iii
9160	tablilla de arma viento furioso iii
9161	tablilla de totem piel de piedra vi
9162	tablilla de escudo de relampagos vii
9164	tablilla de totem gracia del aire ii
9165	tablilla de totem lengua de fuego iii
9166	tablilla de totem fuente de mana iv
9167	tablilla de cadena de relampagos iv
9168	tablilla de ola de sanacion ix
9169	tablilla de descarga de relampagos viii
9170	tablilla de totem de resistencia al fuego iii
9171	tablilla de totem de magma iv
9172	pocion de invisibilidad
9173	transpondedor goblin
9174	tablilla de choque de escarcha iv
9175	tablilla de arma de muerdepiedras v
9176	tablilla de totem garra de piedra vi
9177	tablilla de choque de tierra vii
9178	tablilla de totem de resistencia a la naturaleza iii
9179	elixir de intelecto superior
9180	tablilla de totem viento furioso iii
9181	tablilla de totem corriente de sanacion v
9182	tablilla de totem abrasador vi
9183	tablilla de sanacion en cadena
9184	tablilla de choque de llamas iv
9185	tablilla de totem de resistencia a la escarcha ii
9186	veneno de aturdimiento mental iii
9187	elixir de agilidad superior
9188	tablilla de totem abrasador ii
9189	campana de shay
9190	grimorio inmolar
9191	grimorio maldicion de debilidad
9192	grimorio corrupcion
9193	grimorio transfusion de vida
9194	grimorio maldicion de agonia
9195	grimorio drenar alma
9197	elixir de vision onirica
9198	grimorio cauce de salud
9199	grimorio maldicion de temeridad
9200	grimorio maldicion de debilidad ii
9201	grimorio corrupcion ii
9202	grimorio transfusion de vida ii
9203	grimorio ritual de invocacion
9204	grimorio cauce de salud ii
9205	grimorio maldicion de agonia ii
9206	elixir de gigantes
9207	grimorio crear sangrita ii
9208	grimorio drenar alma ii
9209	grimorio maldicion de debilidad iii
9210	tinte fantasmal
9211	grimorio maldicion de temeridad ii
9212	grimorio descarga de las sombras v
9214	grimorio inferno
9215	grimorio cauce de salud iii
9216	grimorio corrupcion iii
9217	grimorio transfusion de vida iii
9218	grimorio esclavizar demonio
9219	grimorio llamas infernales
9221	grimorio maldicion de agonia iii
9222	grimorio maldicion de los elementos
9223	grimorio maldicion de debilidad iv
9224	elixir de matanza de demonios
9225	grimorio descarga de las sombras vi
9226	grimorio cauce de salud iv
9227	grimorio drenar alma iii
9228	grimorio crear sangrita iii
9229	grimorio drenaje de vida iv
9230	grimorio maldicion de temeridad iii
9231	grimorio corrupcion iv
9233	elixir de deteccion de demonios
9234	tiara de las profundidades
9235	carta de pratt
9236	carta de jangdor
9237	cabellera de gnoll zarpalena
9238	caparazon de escarabajo sin rajar
9240	marra de zul farrak
9241	marra sacra
9242	tablilla antigua
9243	corazon marchito
9244	envio de stoley
9245	botella de stoley
9246	cabeza de barbafuego
9247	escama naga crestafuria
9248	reliquia misteriosa
9249	llave de capitan
9250	ruta de navegacion
9251	fragmento superior del mapa
9252	trozo inferior de mapa
9253	trozo de mapa del medio
9254	mapa del tesoro de cuergo
9255	esencia lahassa
9256	esencia imbel
9257	esencia samha
9258	esencia byltan
9259	collar tribal trol
9260	ron volatil
9261	mena de plomo
9262	vitriolo negro
9263	baculo de troyas
9264	elixir de poder de las sombras
9265	tesoro escondido de cuergo
9266	planes de batalla de zarpalena
9275	llave de cuergo
9276	baul de pirata
9277	procesador de memoria central de tecnobot
9278	esencia artificial
9279	tarjeta perforada blanca
9280	tarjeta perforada amarilla
9281	tarjeta perforada roja
9282	tarjeta perforada azul
9283	ampolla de plomo vacia
9284	ampolla de plomo llena
9285	avambrazos de placas de campo
9286	armadura de placas de campo
9287	guanteletes de placas de campo
9288	faja de placas de campo
9289	botas de placas de campo
9290	casco de placas de campo
9291	leotardos de placas de campo
9292	espaldares de placas de campo
9293	receta pocion de resistencia a la magia
9294	receta pocion de atriplex salvaje
9295	receta pocion de invisibilidad
9296	receta ofrenda de arthas
9297	receta elixir de vision onirica
9298	receta elixir de gigantes
9299	combinacion de la caja fuerte de termochufe
9300	receta elixir de matanza de demonios
9301	receta elixir de poder de las sombras
9302	receta tinte fantasmal
9303	receta piedra filosofal
9304	receta transmutar hierro a oro
9305	receta transmutar mitril a veraplata
9306	baculo de equinex
9307	una piedra chispeante
9308	objeto con mugre incrustada
9309	entranas robomecanicas
9311	papel y sobres para cartas estandar
9312	fuegos artificiales azules
9313	fuegos artificiales verdes
9314	fuegos artificiales con destellos rojos
9315	fuegos artificiales amarillos y rosas
9316	tarjeta perforada centelleante
9317	fuegos artificiales rojos blancos y azules
9318	fuegos artificiales rojos
9319	pica cargada de nimboya
9320	craneo secacorteza
9321	botella de veneno
9322	glandula de veneno intacta
9323	papiro de gadrin
9324	veneno de shadra
9325	un pequeno baculo
9326	anillo con mugre incrustada
9327	tarjeta de acceso de nivel de seguridad delta
9328	superinstantanea fx
9329	una nota corta
9330	instantanea de gammerita
9331	feralas una historia
9332	vendas con costra
9333	collar de plata deslustrada
9334	ceramica rajada
9335	garrote de obsidiana roto
9336	colmillo con funda de oro trol
9355	pendiente de aro
9356	una pata de palo
9357	un esqueleto de loro
9358	un trapo para la cabeza
9359	farol de los mares del sur
9360	oro de cuergo
9361	oro de cuergo con gusano
9362	anillo de oro luminoso
9363	caja envuelta del destellamatic
9364	ampolla de plomo pesada
9365	restos radiactivos de gran potencia
9366	guanteletes de escamas doradas
9367	diseno guanteletes de escamas doradas
9368	sello de jer kai
9369	ala de duende dardo iridiscente
9370	pergamino gordunni
9371	orbe gordunni
9372	sul thraze la azotadora
9375	casco para expertos buscadores de oro
9378	hacha de minero de palatiro
9379	sang thraze la deflectora
9380	jang thraze la protectora
9381	vara terranea
9382	botas de minero pisoteador
9383	cuchilla de obsidiana
9384	chafarote rutacanto
9385	defensor arcaico
9386	ensena de excavador
9387	botas de revelosh
9388	guardabrazos de revelosh
9389	bufas de revelosh
9390	guantes de revelosh
9391	el paleador
9392	hoja templada
9393	luz de esperanza
9394	casco vikingo con cuernos
9395	guantes de los antiguos
9396	musleras de la cripta
9397	capa de energia
9398	botas de carrera desgastadas
9399	flecha de precision
9400	arco corto de baelog
9401	corvo largo nordico
9402	falda portaterra
9403	escudo vikingo maltrecho
9404	escudo polivalente de olaf
9405	faja de fuerza golem
9406	grillete viento de la cumbre
9407	leotardos tejepiedra
9408	cachiporra de hierro
9409	brazales de hierraya
9410	punos de risco
9411	espaldares de fragmento de roca
9412	lanzafuego de galgann
9413	el machacador de rocas
9414	leotardos de piel engrasada
9415	vestimentas tribales de grimlok
9416	carga de grimlok
9417	trozo arcadico
9418	destripapiedras
9419	martillo de fuego de galgann
9420	salacot de aventurero
9421	piedra de salud sublime
9422	maestro de rodeos de forjatiniebla
9423	el martillo neumatico
9424	espada de ginn su
9425	pendulo de fatalidad
9426	arco monolitico
9427	rompehuesos rutacanto
9428	braciles desenterradas
9429	casco de minero de las profundidades
9430	bufas de una epoca remota
9431	fez papal
9432	brazales placacraneos
9433	brazaletes olvidados
9434	vestimenta elemental
9435	guanteletes de hueso reticulado
9436	talega de faranell
9437	muestra de basilisco sin estudiar
9438	muestra de escorpido aceptable
9439	muestra de hiena sin estudiar
9440	muestra de basilisco aceptable
9441	muestra de hiena aceptable
9442	muestra de escorpido sin estudiar
9443	muestra de monstruo utilizada
9444	microprocesador de tecnobot
9445	garras grubbis
9446	pata de electrocutor
9447	perno de electrocutor
9448	trapo grasiento de tanque arana
9449	moledora manual de muchedumbre
9450	botas de gnomobot
9451	agua burbujeante
9452	hidrocana
9453	desfacedor toxico
9454	botos acidos
9455	punos de emisario
9456	lanzacristales
9457	cetro diplomatico real
9458	nucleo central de termochufe
9459	brazo izquierdo de termochufe
9460	cuerno de totem siniestro
9461	material cargado
9462	cajon de cuernos de totem siniestro
9463	cobalto gordunni
9465	maestro excavador 5000
9466	pala de orwin
9467	colmillo de gahz rilla
9468	pluma de picoafilado
9469	armadura de escamas de gahz rilla
9470	mascara de mojo malo
9471	medallon de nekrum
9472	llave de hexx
9473	piel hudu maldita
9474	falda hudu maldita
9475	picador diabolico
9476	espaldares malos grandes
9477	el gorila del jefe
9478	sierra
9479	abrazo del licantropo
9480	arrancaojos
9481	el minotauro
9482	vara de medico brujo
9483	incinerador
9484	leotardos de choque de hechizo
9485	vibrofilo
9486	hacha de batalla de carga superior
9487	superpistola de alta tecnologia
9488	martillo de poder oscilador
9489	hielera giromatica
9490	megacortadora gizmotron
9491	guantes de piloto celebre
9492	reactivador de gigaflujo electromagnetico
9507	cajon cuidadosamente embalado
9508	mono de mecanico
9509	leotardos de petroleo
9510	chapines cueva honda
9511	escalpelo de flebotomista
9512	manteo de metal negro
9513	baston ley
9514	baston arcano
9515	guerrera de encaje abisal
9516	tunica de nudos astral
9517	baculo celestial
9518	trituradores de barro
9519	apisonadoras piesucios
9520	cazador silencioso
9521	machacacraneos
9522	circulo de piedras energizado
9523	temple trol
9527	vara de tramoyista de hechizos
9528	corazon oscuro de edana
9529	juego de equipo de guerrero interno n25
9530	cuerno de garfaodio
9531	espaldares de pizarra
9532	juego de equipo de guerrero interno n30
9533	anillo de fraternidad masona
9534	sombrero de hermandad de ingeniero
9535	brazales soldados con fuego
9536	manto alas de hada
9537	caja bien envuelta
9538	anillo de oro de talvash
9539	caja de raciones
9540	caja de hechizos
9541	caja de regalitos
9542	carta simple
9543	runa simple
9544	memorandum simple
9545	sigilo simple
9546	pergamino simple
9547	nota simple
9548	carta sacralizada
9550	runa codificada
9551	sigilo cifrado
9552	nota con runas grabadas
9553	papiro con grabados
9554	tablilla encriptada
9555	carta cifrada
9556	runa sacralizada
9557	sigilo sacralizado
9558	memorandum encriptado
9559	pergamino codificado
9560	papiro encriptado
9561	tablilla sacralizada
9562	tablilla con runas grabadas
9563	runa consagrada
9564	tablilla con grabados
9565	nota con grabados
9566	runa con grabados
9567	sigilo con grabados
9568	papiro con runas grabadas
9569	pergamino sacralizado
9570	carta consagrada
9571	carta glifica
9572	<unused> glyphic rune
9573	memorandum glifico
9574	pergamino glifico
9575	tablilla glifica
9576	carta manchada
9577	memorandum corrupto
9578	pergamino corrupto
9579	papiro corrupto
9580	sigilo verdeante
9581	nota verdeante
9587	saco de pelambre descongelada
9588	anillo de oro de nogg
9589	minerales taraceados
9590	tronco astillado
9591	tendon resistente
9592	trozos metalicos
9593	muisek de antarbol
9594	muisek de lechucico salvaje
9595	muisek de hipogrifo
9596	muisek de dragon feerico
9597	muisek de gigante montes
9598	togas para dormir
9599	leotardos de malla de corteza
9600	pantalones con encaje
9601	botas forradas
9602	hoja lenomaleza
9603	baston de raiz de arena
9604	martillo de mecanico
9605	manteo de mecanico
9606	vasija de muisek de antarbol
9607	bastion de ventormenta
9608	herramienta de desarme de shoni
9609	mitones llamativos
9618	vasija de muisek de lechucico
9619	vasija de muisek de hipogrifo
9620	vasija de muisek de dragon feerico
9621	vasija de muisek de gigante montes
9622	anillo nudo de junco
9623	togas civinad
9624	peto de corredor
9625	leotardos duales reforzados
9626	carga de enano
9627	estrella polar de la liga de expedicionarios
9628	faltriquera de hierbas de neeru
9629	una cabeza reducida
9630	botas hechas a mano de pratt
9631	guantes hechos a mano de pratt
9632	guantes hechos a mano de jangdor
9633	botas hechas a mano de jangdor
9634	guantes aptos para la carga
9635	manteo de maestro boticario
9636	fajin de espadachin
9637	botas lustrosas
9638	punos quelonidos
9639	la mano de antu sul
9640	mandiletes de mana
9641	amuleto sangrevida
9642	sortija de la gran tortuga
9643	deflector optomatico
9644	temporizador de huevos termostatico
9645	botas de inventor gnomico
9646	aparato de hundimiento gnomico
9647	experimento volador fallido
9648	felpa de tela metalica
9649	vestimentas de alto rango real
9650	pechera protectora de honor
9651	martillo de tormenta de jinete de grifos
9652	leotardos de jinete de grifos
9653	gafas de rapidin
9654	esquirla de piedra de hito
9655	aro de semillas
9656	mandiletes de granito
9657	cincho seto
9658	botas del maharishi
9660	capa de mirada estelar
9661	barrera natural
9662	botas crestarrapida
9663	pechera de jinete del alba
9664	guarda de centinela
9665	guantes crestala
9666	faja de cuerno fuerte
9678	azotador murloc de tok kar
9679	trituradora murloc de tok kar
9680	faca murloc de tok kar
9681	patas de rey reptador a la parrilla
9682	cinturon de cuero de jefe
9683	fuerza del antarbol
9684	fuerza del hipogrifo
9685	voluntad del gigante montes
9686	espiritu del dragon feerico
9687	cinturon de forcejeador
9698	guantes de perspicacia
9699	capa de cuartel
9703	manteo agostado
9704	guantes de cuatrero
9705	cordones de tharg
9706	disco de tharg
9718	hoja de heroes reforjada
9719	hoja de heroes rota
9738	gema de cobrah
9739	gema de anacondra
9740	gema de pythas
9741	gema de serpentis
9742	cordon simple
9743	botas simples
9744	braciles simples
9745	manteo simple
9746	guantes simples
9747	calzones simples
9748	toga simple
9749	blusa simple
9750	fajin de cingaro
9751	sandalias de cingaro
9752	braciles de cingaro
9753	rodela de cingaro
9754	capa de cingaro
9755	guantes de cingaro
9756	calzas de cingaro
9757	guerrera de cingaro
9758	cinturon de cadete
9759	botas de cadete
9760	brazales de cadete
9761	capa de cadete
9762	guanteletes de cadete
9763	leotardos de cadete
9764	escudo de cadete
9765	jubon de cadete
9766	fajin de tejido verde
9767	botas de tejido verde
9768	brazales de tejido verde
9769	rama de tejido verde
9770	capa de tejido verde
9771	guantes de tejido verde
9772	leotardos de tejido verde
9773	toga de tejido verde
9774	jubon de tejido verde
9775	cincho de bandido
9776	botas de bandido
9777	brazales de bandido
9778	rodela de bandido
9779	capa de bandido
9780	guantes de bandido
9781	pantalones de bandido
9782	chaleco de bandido
9783	pechera de asaltante
9784	botas de asaltante
9785	brazales de asaltante
9786	capa de asaltante
9787	guanteletes de asaltante
9788	cinturon de asaltante
9789	musleras de asaltante
9790	escudo de asaltante
9791	guerrera de pano de hiedra
9792	botas de pano de hiedra
9793	pulseras de pano de hiedra
9794	capa de pano de hiedra
9795	guantes de pano de hiedra
9796	manto de pano de hiedra
9797	pantalones de pano de hiedra
9798	toga de pano de hiedra
9799	fajin de pano de hiedra
9800	orbe de hiedra
9801	cinturon excelente
9802	botas excelente
9803	brazales excelente
9804	rodela excelente
9805	capa excelente
9806	guantes excelentes
9807	sobrehombros excelentes
9808	leotardos excelentes
9809	guerrera excelente
9810	botas reforzadas
9811	brazales reforzados
9812	capa reforzada
9813	guanteletes reforzados
9814	cinturon reforzado
9815	leotardos reforzados
9816	escudo reforzado
9817	bufas reforzadas
9818	cota de malla reforzada
9819	guerrera durable
9820	botas durables
9821	brazales durables
9822	manteo durable
9823	guantes durables
9824	sobrehombros durable
9825	pantalones durables
9826	toga durable
9827	cinturon de cuero escamado
9828	botas de cuero escamado
9829	brazales de cuero escamado
9830	escudo escamado
9831	capa escamada
9832	guantes de cuero escamado
9833	leotardos de cuero escamado
9834	sobrehombros de cuero escamado
9835	guerrera de cuero escamado
9836	armadura a rayas
9837	brazales a rayas
9838	capa a rayas
9839	guanteletes a rayas
9840	faja a rayas
9841	leotardos a rayas
9842	espaldares a rayas
9843	escudo a rayas
9844	jubon de implorador
9845	zapatos de implorador
9846	brazales de implorador
9847	capa de implorador
9848	guantes de implorador
9849	caperuza de implorador
9850	manto de implorador
9851	calzones de implorador
9852	toga de implorador
9853	cincho de implorador
9854	chaleco de arquero
9855	cinturon de arquero
9856	botas de arquero
9857	brazales de arquero
9858	rodela de arquero
9859	gorro de arquero
9860	capa de arquero
9861	guantes de arquero
9862	calzas de arquero
9863	hombreras de arquero
9864	botas de renegado
9865	brazales de renegado
9866	coselete de renegado
9867	capa de renegado
9868	guanteletes de renegado
9869	cinturon de renegado
9870	aro de renegado
9871	leotardos de renegado
9872	espaldares de renegado
9873	escudo de renegado
9874	manton hechicero
9875	fajin hechicero
9876	zapatillas hechicero
9877	capa hechicero
9878	sombrero hechicero
9879	pulseras hechicero
9880	guantes hechicero
9881	manto hechicero
9882	esfera hechicero
9883	pantalones hechicero
9884	toga hechicero
9885	botas de cazador
9886	braciles de cazador
9887	armadura de cazador
9889	almete de cazador
9890	manteo de cazador
9891	cinturon de cazador
9892	guantes de cazador
9893	leotardos de cazador
9894	sobrehombros de cazador
9895	botas de brigandina
9896	brazales de brigandina
9897	coselete de brigandina
9898	capa de brigandina
9899	escudo de brigandina
9900	guanteletes de brigandina
9901	cinturon de brigandina
9902	yelmo de brigandina
9903	leotardos de brigandina
9904	espaldares de brigandina
9905	blusa real
9906	fajin real
9907	botas reales
9908	manteo real
9909	braciles reales
9910	guantes reales
9911	calzas reales
9912	amito real
9913	toga real
9914	cetro real
9915	cinta real
9916	cinturon de rastreador
9917	botas de rastreador
9918	defensor brigada
9919	capa de rastreador
9920	guantes de rastreador
9921	cinta de rastreador
9922	leotardos de rastreador
9923	hombreras de rastreador
9924	guerrera de rastreador
9925	guardamunecas de rastreador
9926	botas brigada
9927	brazales brigada
9928	coraza brigada
9929	capa brigada
9930	guanteletes brigada
9931	faja brigada
9932	aro brigada
9933	leotardos brigada
9934	espaldares brigada
9935	escudo de placas estampadas
9936	botas de lego
9937	braciles de lego
9938	capa de lego
9939	guantes de lego
9940	caperuza de lego
9941	manto de lego
9942	pantalones de lego
9943	toga de lego
9944	cristal de lego
9945	fajin de lego
9946	guerrera de lego
9947	cinturon de cabecilla
9948	botas de cabecilla
9949	brazales de cabecilla
9950	coraza de cabecilla
9951	capa de cabecilla
9952	guantes de cabecilla
9953	ornato de cabecilla
9954	leotardos de cabecilla
9955	sobrehombros de cabecilla
9956	brazales de belicista
9957	pechera de belicista
9958	rodela de belicista
9959	capa de belicista
9960	guanteletes de belicista
9961	cinturon de belicista
9962	grebas de belicista
9963	aro de belicista
9964	leotardos de belicista
9965	espaldares de belicista
9966	armadura de placas estampadas
9967	guanteletes de placas estampadas
9968	faja de placas estampadas
9969	casco de placas estampadas
9970	leotardos de placas estampadas
9971	espaldares de placas estampadas
9972	brazales de placas estampadas
9973	botas de placas estampadas
9974	escudo de senor supremo
9978	detector de gahz rilo
9998	jubon de tejido magico negro
9999	leotardos de tejido magico negros
10000	cuerno de margol
10001	toga de tejido magico negra
10002	pantalones de tejido de sombra
10003	guantes de tejido magico negros
10004	toga de tejido de sombra
10005	cuerno gigante de margol
10007	jubon de tejido magico rojo
10008	mascara de bandido blanca
10009	pantalones de tejido magico rojos
10010	pantalones de pano tormentoso
10011	guantes de pano tormentoso
10018	guantes de tejido magico rojos
10019	guantes de tejido onirico
10020	jubon de pano tormentoso
10021	jubon de tejido onirico
10022	certificado de autenticidad
10023	guantes de tejido de sombra
10024	cinta de tejido magico negra
10025	mascara de tejido de sombra
10026	botas de tejido magico negras
10027	sobrehombros de tejido magico negros
10028	sobrehombros de tejido de sombra
10029	sobrehombros de tejido magico rojos
10030	sombrero de almirante
10031	botas de tejido de sombra
10032	cinta de pano tormentoso
10033	cinta de tejido magico roja
10034	camisa de esmoquin
10035	pantalones de esmoquin
10036	chaqueta de esmoquin
10038	sobrehombros de pano tormentoso
10039	botas de pano tormentoso
10040	vestido de boda blanco
10041	diadema de tejido onirico
10042	toga de pano cenizo
10043	ataduras piadosas
10044	botas de pano cenizo
10045	pantalones de lino sencillos
10046	botas de lino sencillas
10047	falda sencilla
10048	falda de colores
10049	hoja de diabolista
10050	bolsa de tejido magico
10051	bolsa de tejido magico roja
10052	camisa marcial naranja
10053	vestido negro sencillo
10054	camisa de tejido magico lavanda
10055	camisa de tejido magico rosa
10056	camisa de tejido magico naranja
10057	guerrera tejeocaso
10058	botas tejeocaso
10059	brazales tejeocaso
10060	manteo tejeocaso
10061	turbante tejeocaso
10062	guantes tejeocaso
10063	amito tejeocaso
10064	pantalones tejeocaso
10065	toga tejeocaso
10066	fajin tejeocaso
10067	guardarrenes rectos
10068	botas rectas
10069	brazales rectos
10070	armadura recta
10071	capa recta
10072	guantes rectos
10073	casco recto
10074	leotardos rectos
10075	bufas rectas
10076	guardabrazos de lord
10077	coraza de lord
10078	blason de lord
10079	manteo de lord
10080	guanteletes de lord
10081	faja de lord
10082	botas de lord
10083	corona de lord
10084	musleras de lord
10085	espaldares de lord
10086	armadura de placas goticas
10087	guanteletes de placas goticas
10088	faja de placas goticas
10089	escarpes goticos
10090	casco de placas goticas
10091	leotardos de placas goticas
10092	bufas de placas goticas
10093	deflector de aparecido
10094	avambrazos de placas goticas
10095	botas de concejal
10096	punos de concejal
10097	aro de concejal
10098	capa de concejal
10099	guantes de concejal
10100	sobrehombros de concejal
10101	pantalones de concejal
10102	togas de concejal
10103	fajin de concejal
10104	guerrera de concejal
10105	armadura de errante
10106	botas de errante
10107	brazales de errante
10108	capa de errante
10109	cinturon de errante
10110	guantes de errante
10111	sombrero de errante
10112	leotardos de errante
10113	sobrehombros de errante
10118	coraza ornamentada
10119	grebas ornamentadas
10120	capa ornamentada
10121	guanteletes ornamentados
10122	faja ornamentada
10123	aro ornamentado
10124	musleras ornamentadas
10125	espaldares ornamentados
10126	brazales ornamentados
10127	brazales de aparecido
10128	peto de aparecido
10129	guanteletes de aparecido
10130	faja de aparecido
10131	botas de aparecido
10132	casco de aparecido
10133	leotardos de aparecido
10134	sobrehombros de aparecido
10135	guerrera de consejero mayor
10136	brazales de consejero mayor
10137	botas de consejero mayor
10138	capa de consejero mayor
10139	aro de consejero mayor
10140	guantes de consejero mayor
10141	pantalones de consejero mayor
10142	manto de consejero mayor
10143	toga de consejero mayor
10144	fajin de consejero mayor
10145	faja poderosa
10146	botas poderosas
10147	braquiales poderosos
10148	capa poderosa
10149	guanteletes poderosos
10150	casco poderoso
10151	guerrera poderosa
10152	leotardos poderosos
10153	bufas poderosas
10154	faja mercurica
10155	grebas mercuricas
10156	brazales mercuricos
10157	coraza mercurica
10158	guarda mercurica
10159	capa mercurica
10160	aro mercurico
10161	guanteletes mercuricos
10162	musleras mercuricas
10163	espaldares mercuricos
10164	peto de templario
10165	guanteletes de templario
10166	faja de templario
10167	botas de templario
10168	corona de templario
10169	quijotes de templario
10170	espaldares de templario
10171	brazales de templario
10172	manto mistico
10173	brazales misticos
10174	manteo mistico
10175	turbante mistico
10176	guantes misticos
10177	leotardos misticos
10178	toga mistica
10179	botas misticas
10180	cinturon mistico
10181	armadura mistica
10182	coraza de espadachin
10183	botas de espadachin
10184	brazales de espadachin
10185	manteo de espadachin
10186	guantes de espadachin
10187	parche de espadachin
10188	leotardos de espadachin
10189	hombreras de espadachin
10190	cinturon de espadachin
10191	guardabrazos de cruzado
10192	botas de cruzado
10193	armadura de cruzado
10194	capa de cruzado
10195	escudo de cruzado
10196	guanteletes de cruzado
10197	cinturon de cruzado
10198	yelmo de cruzado
10199	leotardos de cruzado
10200	espaldares de cruzado
10201	grebas de senor supremo
10202	avambrazos de senor supremo
10203	peto de senor supremo
10204	escudo de laminas grueso
10205	guanteletes de senor supremo
10206	faja de senor supremo
10207	corona de senor supremo
10208	quijotes de senor supremo
10209	bufas de senor supremo
10210	manto elegante
10211	botas elegantes
10212	capa elegante
10213	brazales elegantes
10214	guantes elegantes
10215	togas elegantes
10216	cinturon elegante
10217	leotardos elegantes
10218	guerrera elegante
10219	aro elegante
10220	guerrera sombranoche
10221	faja sombranoche
10222	botas sombranoche
10223	guardabrazos sombranoche
10224	capa sombranoche
10225	guantes sombranoche
10226	tiara sombranoche
10227	leotardos sombranoche
10228	bufas sombranoche
10229	brazales grabados
10230	coraza grabada
10231	manteo grabado
10232	guanteletes grabados
10233	faja grabada
10234	botas grabadas
10235	yelmo grabado
10236	leotardos grabados
10237	espaldares grabados
10238	botas de laminas pesadas
10239	avambrazos de laminas pesados
10240	pechera de laminas pesada
10241	yelmo de laminas pesado
10242	guanteletes de laminas pesados
10243	faja de laminas pesada
10244	leotardos de laminas pesados
10245	espaldares de laminas pesados
10246	jubon de maestro
10247	botas de maestro
10248	brazales de maestro
10249	capa de maestro
10250	sombrero de maestro
10251	guantes de maestro
10252	leotardos de maestro
10253	manto de maestro
10254	toga de maestro
10255	cinturon de maestro
10256	brazales de aventurero
10257	botas de aventurero
10258	manteo de aventurero
10259	cinturon de aventurero
10260	guantes de aventurero
10261	panuelo de aventurero
10262	musleras de aventurero
10263	sobrehombros de aventurero
10264	guerrera de aventurero
10265	brazales magistrales
10266	coraza magistral
10267	manteo magistral
10268	guanteletes magistrales
10269	faja magistral
10270	botas magistrales
10271	escudo magistral
10272	aro magistral
10273	quijotes magistrales
10274	espaldares magistrales
10275	coraza esmeralda
10276	escarpes esmeralda
10277	guanteletes esmeralda
10278	faja esmeralda
10279	yelmo esmeralda
10280	quijotes esmeralda
10281	espaldares esmeralda
10282	avambrazos esmeralda
10283	muestras de corazon de lobo
10285	seda de las sombras
10286	corazon de fiera
10287	manto de tejido verde
10288	aro de sabio
10289	sombrero durable
10290	tinte rosa
10298	sortija de gnomeregan
10299	amuleto de gnomeregan
10300	patron jubon de tejido magico rojo
10301	patron mascara de bandido blanca
10302	patron pantalones de tejido magico rojos
10303	patron pantalones de pano tormentoso
10304	patron guantes de pano tormentoso
10305	pergamino de proteccion iv
10306	pergamino de espiritu iv
10307	pergamino de aguante iv
10308	pergamino de intelecto iv
10309	pergamino de agilidad iv
10310	pergamino de fuerza iv
10311	patron camisa marcial naranja
10312	patron guantes de tejido magico rojos
10313	patron jubon de pano tormentoso
10314	patron camisa de tejido magico lavanda
10315	patron sobrehombros de tejido magico rojos
10316	patron falda de colores
10317	patron camisa de tejido magico rosa
10318	patron sombrero de almirante
10319	patron cinta de pano tormentoso
10320	patron cinta de tejido magico roja
10321	patron camisa de esmoquin
10322	patron sobrehombros de pano tormentoso
10323	patron pantalones de esmoquin
10324	patron botas de pano tormentoso
10325	patron vestido de boda blanco
10326	patron chaqueta de esmoquin
10327	cuerno de echeyakee
10328	pechera escarlata
10329	cinturon escarlata
10330	leotardos escarlata
10331	guanteletes escarlata
10332	botas escarlata
10333	guardamunecas escarlata
10338	cadaver reciente de zhebra
10358	brazales de duracin
10359	botas perpetuas
10360	culebra reina negra
10361	culebra marron
10362	escudo ornamentado
10363	pared grabada
10364	escudo de templario
10365	escudo esmeralda
10366	guarda de demonio
10367	escudo hiperion
10368	armadura de placas imbuida
10369	guanteletes de placas imbuidos
10370	faja de placas imbuida
10371	grebas de placas imbuidas
10372	casco de placas imbuido
10373	leotardos de placas imbuidos
10374	espaldares de placas imbuidos
10375	avambrazos de placas imbuidos
10376	botas de comandante
10377	avambrazos de comandante
10378	armadura de comandante
10379	yelmo de comandante
10380	guanteletes de comandante
10381	faja de comandante
10382	leotardos de comandante
10383	espaldares de comandante
10384	armadura hiperion
10385	grebas hiperion
10386	guanteletes hiperion
10387	faja hiperion
10388	yelmo hiperion
10389	quijotes hiperion
10390	espaldares hiperion
10391	avambrazos hiperion
10392	culebra carmesi
10393	cucaracha
10394	silbato de perro de la pradera
10398	gallina mecanica
10399	armadura ennegrecida defias
10400	leotardos ennegrecidos defias
10401	guantes ennegrecidos defias
10402	botas ennegrecidas defias
10403	cinturon ennegrecido defias
10404	cinturon durable
10405	sobrehombros de bandido
10406	cinta de cuero escamado
10407	hombreras de asaltante
10408	yelmo a rayas
10409	botas a rayas
10410	leotardos del colmillo
10411	escarpines del colmillo
10412	cinturon del colmillo
10413	guantes del colmillo
10414	concha de muestra de quijaforte
10418	insignia de mitril de luz tremula
10420	craneo del gelido
10421	jubon de cobre ferreo
10423	leotardos de bronce banados en plata
10424	diseno leotardos de bronce banados en plata
10438	caja de felix
10439	infusion de albaza hirviendo de durnan
10440	taza de nori
10441	fragmento resplandeciente
10442	artefacto misterioso
10443	carta chamuscada
10444	pistola de bengalas de venta estandar
10445	material para dibujar
10446	corazon de obsidion
10447	cabeza de lathoric el negro
10450	pluma de hipogrifo sin estropear
10454	esencia de eranikus
10455	esencia encadenada de eranikus
10456	un monedero abultado
10457	caparazon de caracol marino vacio
10458	rezo a elune
10459	cabeza del jefe cornapunta mantospina
10460	sangre hakkari
10461	brazales enigmaticos
10462	cinturon enigmatico
10463	patron mascara de tejido de sombra
10464	baston de mando
10465	huevo de hakkar
10466	circulo de piedras atal ai
10467	cartera de comerciante
10478	gema de mana de roland
10479	cartera comercial de kovic
10498	microajustador giromatico
10499	gafas ojo brillante
10500	gafas de fuego
10501	ultragafas ojo de gato
10502	gafas de poder con hechizos xtremo
10503	gafas tintadas de rosa
10504	lente verde
10505	polvora solida
10506	casco de inmersion
10507	dinamita solida
10508	trabuco de mitril
10509	corazon de llama
10510	rifle de gran calibre de mitril
10511	aceite golem
10512	balas de mitril de gran impacto
10513	girotiro de mitril
10514	bomba de fragmentacion de mitril
10515	antorcha de reprension
10518	capa paracaidas
10538	tablilla de beth amara
10539	tablilla de jin yael
10540	tablilla de markri
10541	tablilla de sael hai
10542	casco de minero goblin
10543	casco de albanil goblin
10544	gran maza cardoleno
10545	gafas gnomicas
10546	mira mortal
10547	cuchillo de acampada
10548	mira de francotirador
10549	calzas de ranchero
10550	mitones de lana
10551	daga banada en torio
10552	simbolo de ragnaros
10553	jubon de supervisor
10554	pantalones de supervisor
10556	circulo de piedra
10558	nucleo de poder de oro
10559	tubo de mitril
10560	activador inestable
10561	envoltura de mitril
10562	bomba altamente explosiva
10563	calco runa de beth amara
10564	calco runa de jin yael
10565	calco runa de markri
10566	calco runa de sael hai
10567	lanzapuas
10569	tesoro oculto del vuelo negro
10570	destripahombres
10571	garrote de hueso de ebano
10572	fragmento helado
10573	atizahuesos
10574	sudario
10575	muda de piel de vuelo negro
10576	dragonizo mecanico de mitril
10577	mortero goblin
10578	botas lanzapensamientos
10579	flecha explosiva
10580	caja goblin bum
10581	vestimenta cabeza de la muerte
10582	botines de brezo
10583	arnes contra pinchos
10584	punos tempesviento
10585	radio goblin
10586	la grande
10587	dispensador de bombas goblin
10588	casco de cohete goblin
10589	piedra de juramento del vuelo de ysera
10590	caja negra con agujeros
10592	elixir de ojo de gato
10593	trozo draenetista imperfecto
10595	kum isha s junk
10597	cabeza de magus rimtori
10598	cabeza ensangrentada de hetaera
10599	cabeza golpeada de hetaera
10600	cabeza amoratada de hetaera
10601	esquema gafas ojo brillante
10602	esquema mira mortal
10603	esquema ultragafas ojo de gato
10604	esquema rifle de gran calibre de mitril
10605	esquema gafas de poder con hechizos xtremo
10606	esquema capa paracaidas
10607	esquema casco de inmersion
10608	esquema mira de francotirador
10609	esquema dragonizo mecanico de mitril
10610	sangre de hetaera
10620	mena de torio
10621	pergamino runico
10622	bandera de kadrak
10623	bocado de invierno
10624	arco hiriente
10625	espada de sigilo
10626	martillo de ira
10627	cachiporra del perro rictus
10628	arremetida mortal
10629	botas de caminaniebla
10630	halo de cazador de almas
10631	guanteletes aguasucia
10632	brazales de escama de babosa
10633	leotardos conchaplata
10634	circulo del ojo de la mente
10635	leotardos de anillas pintados
10636	guantes nomadas
10637	guantes de cervecero
10638	manteo de caida larga
10639	champinon jacinto
10640	icor tejemadera
10641	lirio alunado
10642	antidoto de iverron
10643	carta lacrada para ag tor
10644	receta combustible de cohete goblin
10645	rayo mortal gnomico
10646	carga de zapador goblin
10647	tinta de ingeniero
10648	papiro en blanco
10649	fragmento de pesadilla
10650	melena de jabaespin infestada de peste
10651	cristal de enfoque arcano rajado
10652	voluntad del gigante montes
10653	botas traillamarada
10654	guantes de trenza de yute
10655	calzones de curruca
10656	jubon de malla de corteza
10657	manto talbar
10658	galochas del lodazal
10659	fragmento de los pezuna quebrada
10660	primera tablilla mosh aru
10661	segunda tablilla mosh aru
10662	huevo de hakkar relleno
10663	esencia de hakkar
10664	una nota para magus rimtori
10678	nota de magatha
10679	nota de andron
10680	nota de jes rimon
10681	nota de xylem
10682	piedra de juramento de belnistrasz
10683	morral de expedicionario
10684	paracaidas colosal
10686	egida de batalla
10687	vial vacio etiquetado como n º 1
10688	vial vacio etiquetado como n º 2
10689	vial vacio etiquetado como n º 3
10690	vial vacio etiquetado como n º 4
10691	vial lleno etiquetado como n º 1
10692	vial lleno etiquetado como n º 2
10693	vial lleno etiquetado como n º 3
10694	vial lleno etiquetado como n º 4
10695	caja de viales vacios
10696	espada aterravil de azsharita encantada
10697	daga aterravil de azsharita encantada
10698	baston aterravil de azsharita encantado
10699	zarza de yeh kinya
10700	botas encarmine
10701	botas de zua tec
10702	botas de ogro enigma
10703	pincho endemoniado
10704	astilla unafria
10705	braciles de abeto y sauce
10706	faja de escama nocturna
10707	grebas de forjador de acero
10708	orbe de hechizo de calavera
10709	orbe de piropiedra
10710	anillo garra de dragon
10711	collar de sangre de dragon
10712	elixir de cuely
10713	diseno cilindro de mitril taraceado
10714	azsharita cristalizada
10715	mira de kim jael
10716	rayo reductor gnomico
10717	brujula de kim jael
10718	cachivache de kim jael
10719	alarma movil
10720	proyector redomatico gnomico
10721	cinturon de prevencion de dano gnomico
10722	pollo relleno de kim jael
10723	radio gnomica
10724	botas cohete gnomicas
10725	gallo de batalla gnomico
10726	gorro de control mental gnomico
10727	escopeta dragon goblin
10728	patron camisa de espadachin negra
10738	envio a galvan
10739	anillo de entereza
10740	quijotes de centurion
10741	casco de lordrec
10742	leotardos de vuelo
10743	protegecabezas pirodraco
10744	hacha del draco ebano
10745	sobrehombros kaylari
10746	avambrazos de acero runico
10747	fajin de maestro
10748	botas del placer errante
10749	yelmo de guardia vengador
10750	puntilla de fuerza de vida
10751	aro rafaga de gemas
10752	cofre taraceado esmeralda
10753	amuleto de grol
10754	amuleto de sevine
10755	amuleto de allistarj
10757	resguardo del rapinador
10758	x jalibur
10759	cuerno de rapinador cortado
10760	punos de puerco
10761	daga ira helada
10762	togas del exanime
10763	barbuta de metal de hielo
10764	armadura friomortal
10765	dedos de hueso
10766	rama de podredumbre de peste
10767	guarda de jabali indomito
10768	cinturon de campeon de jabali
10769	ojo resplandeciente de mordresh
10770	calavera inerte mordresh
10771	fajin de mago de la muerte
10772	cuchilla de gloton
10773	urna hakkari
10774	sobrehombros de pellejo
10775	caparazon de tuten kash
10776	manteo de arana sedosa
10777	guantes de arana
10778	collar de santuario
10779	sangre de demonio
10780	marca de hakkar
10781	coraza hakkari
10782	embozo hakkari
10783	bufas atal ai
10784	coraza atal ai
10785	leotardos atal ai
10786	botas atal ai
10787	guantes atal ai
10788	faja atal ai
10789	manual de disciplinas de ingenieria
10790	tarjeta de miembro del club de ingenieria gnomica
10791	tarjeta de miembro del club de ingenieria goblin
10792	compromiso de secreto perpetuo de nixx
10793	compromiso de secreto perpetuo de sobrechispa
10794	compromiso de secreto perpetuo de oglethorpe
10795	sortija de garra de draco
10796	piedra draco
10797	sopla fuego
10798	anillo de colmillo de atal alarion
10799	cabeza de pincho
10800	brazales aguaoscura
10801	botas de escamas humedas
10802	capa velo alado
10803	hoja de los desdichados
10804	puno del condenado
10805	comedor de muertos
10806	vestimentas del profeta atal ai
10807	falda del profeta atal ai
10808	guantes del profeta atal ai
10818	pergamino de yeh kinya
10819	pluma de lechucico salvaje
10820	cinturon de siembra
10821	capa de sembrador
10822	vastago oscuro
10823	espada del vencedor
10824	dije resplandor de ambar
10826	baston de conocimiento
10827	guerrera de perito
10828	una funesta
10829	ojo de dragon
10830	granada de fragmentacion m73
10831	orbe vil
10832	manual de rastreador vil
10833	cuernos de eranikus
10834	equipo de rastreador can manafago
10835	blason de supremacia
10836	vara de corrosion
10837	diente de eranikus
10838	poderio de hakkar
10839	nota cristalizada
10840	nota cristalizada
10841	te de espina de oro
10842	sarong de escamas de viento
10843	manteo piel emplumada
10844	aguja de hakkar
10845	abrazo de guerrero
10846	grebas tirosangre
10847	llamada del dragon
10858	diseno gran maza de hierro solido
10918	veneno hiriente
10919	guantes de boticario
10920	veneno hiriente ii
10921	veneno hiriente iii
10922	veneno hiriente iv
10938	esencia magica inferior
10939	esencia magica superior
10940	polvo extrano
10958	collar de hilary
10959	saco de pellejo de demonio
10978	fragmento de luz tremula pequeno
10998	esencia astral inferior
10999	ferrovil
11000	llave de forjatiniebla
11018	tierra de un goro
11020	faltriquera de siempreverde
11022	paquete de semillas tharlendris
11023	pollo de ancona
11024	semillero de siempreverde
11026	carcasa de rana de arbol
11027	caja de rana de bosque
11038	formula encantar arma de 2m espiritu inferior
11039	formula encantar capa agilidad menor
11040	managrana
11058	aro de la nariz de sha ni
11078	llave del arca de reliquias
11079	cabeza cortada de gor tesh
11080	cabeza cortada de gor tesh
11081	formula encantar escudo proteccion inferior
11082	esencia astral superior
11083	polvo de alma
11084	fragmento con luz tremula grande
11085	llave del arca del cliente del mes
11086	jang thraze la protectora
11098	formula encantar capa resistencia a las sombras inferior
11099	mena de hierro negro
11101	formula encantar brazales fuerza inferior
11102	huevo sin abrir de duende dardo
11103	vale para semillas
11104	brujula grande
11105	papiro de mapa enrollado
11106	llave con cabeza de leon
11107	un paquetito
11108	fotografia descolorida
11109	comida para pollos especial
11110	huevo de gallina
11111	huevo roto de duende dardo
11112	equipo de investigacion
11113	cajon de comestibles
11114	hueso de dinosaurio
11115	llave de caja fuerte secreta
11116	un diario destrozado
11118	piedra arcadica
11119	cosecha de milly
11120	martillo de belgrom
11121	talwar aguaoscura
11122	zanahoria pinchada en un palo
11123	leotardos de zancalluvia
11124	yelmo de exilio
11125	informe de la vendimia
11126	tablilla de kurniya
11127	mercancias extraviadas
11128	vara dorada
11129	esencia de los elementos
11130	vara runica de oro
11131	muestra de pared de colmena
11132	vial de raspadura sin usar
11133	espada de entrenamiento de linken
11134	esencia mistica inferior
11135	esencia mistica superior
11136	espada templada de linken
11137	polvo de vision
11138	fragmento resplandeciente pequeno
11139	fragmento resplandeciente grande
11140	llave de celda de prision
11141	cebo
11142	churumbele roto
11143	engranaje
11144	vara de veraplata
11145	vara runica de veraplata
11146	churumbele roto y maltrecho
11147	cubierta del manual del churumbele
11148	pagina del manual del churumbele
11149	manual del churumbele
11150	formula encantar guantes mineria
11151	formula encantar guantes herboristeria
11152	formula encantar guantes pesca
11162	espada de excelencia de linken
11163	formula encantar brazal desvio inferior
11164	formula encantar arma destripadora de bestias inferior
11165	formula encantar arma mataelementales inferior
11166	formula encantar guantes desuello
11167	formula encantar botas espiritu inferior
11168	formula encantar escudo bloqueo inferior
11169	libro de aquor
11171	hierro vil
11172	garras de plata
11173	corazon de troncoferro
11174	esencia abisal inferior
11175	esencia abisal superior
11176	polvo onirico
11177	fragmento radiante pequeno
11178	fragmento radiante grande
11179	llama dorada
11184	cristal de poder azul
11185	cristal de poder verde
11186	cristal de poder rojo
11187	brazales de tallo
11188	cristal de poder amarillo
11189	togas de los bosques
11190	guantes de parra
11191	botas de granjero
11192	guantes de modisto
11193	coraza viento abrasador
11194	camisote de escama prismatica
11195	peto forjado por la guerra
11196	medallon de rafaga mental
11197	llave de guarda oscuro
11198	runa de escape
11199	escudo de ingeniero 1
11200	escudo de ingeniero 2
11201	escudo de ingeniero 3
11202	formula encantar escudo aguante
11203	formula encantar guantes mineria avanzada
11204	formula encantar brazales espiritu superior
11205	formula encantar guantes herboristeria avanzada
11206	formula encantar capa agilidad inferior
11207	formula encantar arma arma ignea
11208	formula encantar arma matanza de demonios
11222	cabeza de krom zar
11223	formula encantar brazal desvio
11224	formula encantar escudo resistencia a la escarcha
11225	formula encantar brazales aguante superior
11226	formula encantar guantes equitacion
11227	trozo del estandarte de krom zar
11228	muda de piel de vuelo demente
11229	faja de escamas brillantes
11230	esencia ignea encerrada
11231	muda de piel de vuelo negro alterada
11242	raiz del mal
11243	elixir de videre
11262	orbe de lorica
11263	varita de fuerza abisal
11265	gran maza de riscoleno
11266	fragmento elemental fracturado
11267	muestra de fragmento elemental
11268	cabeza de argelmach
11269	nucleo de elemental intacto
11270	compromiso firmado de nixx
11282	compromiso firmado de oglethorpe
11283	compromiso de secreto perpetuo firmado de sobrechispa
11284	balas de precision
11285	flecha dentada
11286	grilletes de torio
11287	varita magica inferior
11288	varita magica superior
11289	varita mistica inferior
11290	varita mistica superior
11291	madera de estrella
11302	fuerza de uther
11303	arco corto refinado
11304	arco largo refinado
11305	arco corto denso
11306	arco corvo solido
11307	arco largo macizo
11308	arco corto nemoroso
11309	el corazon de la montana
11310	manto de vidente de llamas
11311	manteo de escamas de ascuas
11312	receta de cebatruenos perdida
11313	cabeza de ribbly
11315	brote sangrepetalo
11316	sangrepetalo
11318	calima atal ai
11319	controlador descargado
11320	liquidador de sangrepetalos
11324	morral de expedicionario
11325	jarra de cerveza hierro negro
11362	carcaj medio
11363	faltriquera de polvora media
11364	tabardo de ventormenta
11366	carta de helendis rivacuerno
11367	peticion de solomon para bolvar
11368	decreto de bolvar
11370	mena de hierro negro
11371	barra de hierro negro
11382	sangre de la montana
11384	diente de basilisco partido
11385	escama de basilisco
11386	ojo de basilisco fangoso
11387	corazon de basilisco
11388	veneno de basilisco
11389	piel de basilisco fulgurante
11390	colmillo de murcielago partido
11391	ala de murcielago con puas
11392	garra de murcielago cortada
11393	calavera de murcielago pequeno
11394	corazon de murcielago
11395	oreja de murcielago
11402	pelambre de murcielago impoluta
11403	colmillo de murcielago grande
11404	ojo de murcielago maligno
11405	veta gigante de plata
11406	cadaver de oso en descomposicion
11407	pelambre de oso rasgada
11408	mandibula de oso
11409	costillar de oso
11410	garra de oso indomito
11411	hueso de oso grande
11412	vial de nagmara
11413	vial de nagmara lleno
11414	melena grisacea
11415	bayas variadas
11416	caja toracica delicada
11417	ala emplumada
11418	hueso hueco de ala
11419	huevo sin abrir misterioso
11420	utensilio de escritura elegante
11422	obsequio de renovacion de ingeniero goblin
11423	obsequio de renovacion de ingeniero gnomo
11442	juego de diputado de ventormenta
11444	jabali tragapenas
11445	flauta de los antiguos
11446	una nota arrugada
11462	cuchillo desechado
11463	paquete sin entregar
11464	informacion perdida del mariscal windsor
11465	informacion perdida del mariscal windsor
11466	informe de raschal
11467	medallon roca negra
11468	rinonera hierro negro
11469	brazales de bandasangre
11470	trascripcion de tablilla
11471	huevo de duende dardo fragil
11472	costillar de acechador melenargenta
11473	px83 enigmatron
11474	huevo de duende dardo
11475	capa manchada de vino
11476	pelambre de u cha
11477	garra blanca de ravasaurio
11478	pelambre de gorila de un goro
11479	pelambre de vapuleador de un goro
11480	pelambre de tronador de un goro
11482	manual de instrucciones de la torre de cristal
11502	sobrehombros de piel de conocimiento
11503	ambar de sangre
11504	trozo de trillanodonte muerto
11507	pelambre de hiena moteada
11508	zapatillas de maestro de juego
11509	glandula de feromonas de ravasaurio
11510	cabeza de lar korwi
11511	antorcha cenarion
11512	parche de piel contaminada
11513	vitriolo corrupto
11514	trepadora vil
11515	fragmento de alma corrupto
11516	balsamo de planta cenarion
11522	totem de plata de aquamentas
11562	cristal de restauracion
11563	fuerza de cristal
11564	resguardo de cristal
11565	reduccion de cristal
11566	carga de cristal
11567	aguja de cristal
11568	faltriquera de torwa
11569	carne de trillanodonte en conserva
11570	mezcla de feromonas en conserva
11582	balsamo vil
11583	manzana de cactus
11584	sorpresa de manzana de cactus
11590	equipo de reparacion mecanica
11602	llave de tragapenas
11603	cercenadora desgarravil
11604	placa hierro negro
11605	sobrehombros hierro negro
11606	malla hierro negro
11607	taladora hierro negro
11608	pulverizador hierro negro
11609	muda de piel de vuelo negro alterada
11610	diseno pulverizador hierro negro
11611	diseno taladora hierro negro
11612	diseno placa hierro negro
11614	diseno malla hierro negro
11615	diseno sobrehombros hierro negro
11617	provisiones de eridan
11622	arcanum de reflexion inferior
11623	manteo de lanzaduendes
11624	amito duro
11625	esfera embrujada
11626	manteo de velo negro
11627	grebas de pie de flota
11628	arco del maestro de canes
11629	rifle del maestro de canes
11630	perdigones de roca
11631	guarda petravalva
11632	sobrehombros escoria terrea
11633	caparazon colmillo de arana
11634	guantes de tela de seda
11635	faca gancho
11642	arcanum de constitucion inferior
11643	arcanum de tenacidad inferior
11644	arcanum de temple inferior
11645	arcanum de voracidad inferior
11646	arcanum de voracidad inferior
11647	arcanum de voracidad inferior
11648	arcanum de voracidad inferior
11649	arcanum de voracidad inferior
11662	fajin ban thok
11665	punos de vigia ogro
11668	flauta de xavaric
11669	anillo de gran poder
11674	lazo vil de fuego de jade
11675	botas sombra demoniaca
11677	manteo de podredumbre de tumba
11678	caparazon de anub shiah
11679	guardabrazos rubicundos
11682	vial de eridan
11684	ferromazo
11685	sobrehombros de pellejo escindido
11686	faja de furia bestial
11702	desollador de grisez
11703	faja muro de piedra
11722	bufas de posometal
11723	flameberge equilibrado de buenacero
11724	paquete con retraso
11725	pata de cristal solido
11726	cota de malla de gladiador indomito
11727	libro de contabilidad de buenacero
11728	leotardos de gladiador indomito
11729	yelmo de gladiador indomito
11730	mandiletes de gladiador indomito
11731	grebas de gladiador indomito
11732	tratado sobre reflexion
11733	tratado sobre constitucion
11734	tratado sobre tenacidad
11735	parche furia ardiente
11736	tratado sobre resistencia
11737	tratado sobre voracidad
11742	morral de caminante
11743	puno de penasco
11744	punosangre
11745	punos de falange
11746	yelmo calavera golem
11747	togas de zancudo flamigero
11748	caduceo pirico
11749	leotardos de escamas abrasadoras
11750	baculo de astillas
11751	esencia ardiente
11752	sangre negra de los atormentados
11753	ojo de kajal
11754	diamante negro
11755	collera de verek
11764	braquiales de pellejo de ceniza
11765	guardamunecas de piromalla
11766	punos de tejido flamigero
11767	guardabrazos de placas de ascuas
11768	brazales incendiarios
11782	manto boreal
11783	faja de acero frio
11784	hoja de mediador
11785	baluarte golem de roca
11786	piedra de la tierra
11787	botas de esquisto
11802	leotardos de cresta de lava
11803	fuerza de magma
11804	cantimplora de spraggle
11805	martillo de rubidio
11807	fajin del corazon ardiente
11808	circulo de la llama
11809	colera de llamas
11810	fuerza de voluntad
11811	corazon humeante de la montana
11812	manteo de la salamandra de fuego
11813	formula corazon humeante de la montana
11814	punos de arrabio
11815	mano de la justicia
11816	hacha de batalla de forjainquina
11817	espada de lord general
11818	llave de la letrina de limugre
11819	segundo aliento
11820	armadura decorada real
11821	leotardos de conflicto de guerra
11822	botas omnitiro
11823	falda luminaria
11824	sortija ciclopea
11825	bombita
11826	humillo
11827	esquema humillo
11828	esquema bombita
11829	cenizas de un goro
11830	escama de diemetradon palmeada
11831	escama de pterrordactilo palmeada
11832	rafaga de conocimiento
11833	cebo de la reina gorishi
11834	alquitran muy pegajoso
11835	cerebro de la reina gorishi
11837	glandula secretora de olor gorishi
11839	monoculo de arquitecto jefe
11840	camisa de maestro constructor
11841	bombachos de disenador senior
11842	manto de perito jefe
11843	vale bancario
11844	informe de un goro de morterozugg
11845	bolsa de cuero hecha a mano
11846	brebaje especial de zumbang
11847	capa maltrecha
11848	cinturon de lienzo
11849	brazales de metal oxidados
11850	manteo corto de murciumbrio
11851	guerrera de carronero
11852	leotardos de trashumante
11853	botas de senderismo
11854	destornillador de churumbele
11855	llave inglesa de tork
11856	hoja elfica ceremonial
11857	vara santificada
11858	manteo de batalla dura
11859	orbe luna de jade
11860	vara relampago cargada
11861	faja de represalia
11862	sortija de hueso blanca
11863	trituradora de hueso blanca
11864	lanza de hueso blanca
11865	botas de rencor
11866	cinturon de castigo de nagmara
11867	guanteletes enloquecedores
11868	sortija de apnea
11869	sortija de sha ni
11870	orbe de olvido
11871	bufas de ladino
11872	grebas de rehuida
11873	manteo de niebla eterea
11874	manto de las nubes
11875	brazales de la brisa
11876	guerrera de acechador de las llanuras
11882	leotardos de escolta
11883	una rinonera deslucida
11884	amito luz lunar
11885	antorcha de forjatiniebla
11886	mensaje urgente
11887	carretilla del circulo cenarion
11888	guantes de investigacion de quintis
11889	espaldares de cortezaferrea
11902	espada de maestria de linken
11903	jaula para gatos gatito corrupto
11904	espiritu de aquamentas
11905	bumeran de linken
11906	machacabestias
11907	destripadora de bestias
11908	botas de cantera de arqueologo
11909	cinturon de herramientas de excavador
11910	musleras con joyas
11911	leotardos de copa de arbol
11912	paquete de contenedores de moco vacios
11913	yelmo de clayridge
11914	tarro de moco maldito vacio
11915	frenalloviznas de shizzle
11916	bozal de shizzle
11917	escamondador de shizzle
11918	guantes de gruta
11919	grebas de placas de risco
11920	guadana de anima
11921	gigante impasible
11922	hoja con grabados de sangre
11923	el martillo de gracia
11924	togas de la corona real
11925	embozo fantasmal
11926	coraza de mortifero
11927	quijotes del guardian eterno
11928	cetro real de thaurissan
11929	leotardos de espectro inquietante
11930	el nuevo manteo del emperador
11931	vengador forjaterrible
11932	baculo de sabiduria orientador
11933	joya imperial
11934	sello de emperador
11935	piedra magmus
11936	cinturon de cazador de reliquias
11937	saco de monedas gordo
11938	saco de gemas
11939	pulsera lustrosa
11940	collar brillante
11941	documentos falsos
11942	documentos legales
11943	escritura del puente thandol
11944	botitas de bebe hierro negro
11945	anillo hierro negro
11946	collar de opalo de fuego
11947	tarro lleno de moco maldito
11948	tarro de moco corrupto vacio
11949	tarro de moco corrupto lleno
11950	bayas de flor de viento
11951	tuberculo de blancoria
11952	aliento de dragon nocturno
11953	tarro de muestras puras vacio
11954	tarro de muestra pura lleno
11955	bolsa de contenedores de lodo vacios
11962	esposas
11963	bufas de penitencia
11964	cayada golpepresto
11965	anillo de cuarzo
11966	saco de monedas pequeno
11967	sortija de circon
11968	aro ambar
11969	circulo de jacinto
11970	anillo de espinela
11971	sortija de amatista
11972	anillo carneliano
11973	eslabon de hematites
11974	anillo de aguamarina
11975	anillo de topacio
11976	hueso sardonyx
11977	aro serpentino
11978	eslabon de jaspe
11979	circulo de peridoto
11980	anillo opalo
11981	sortija de plomo
11982	sortija viridiana
11983	anillo de cromo
11984	anillo de cobalto
11985	anillo ceruleo
11986	aro de talio
11987	circulo iridio
11988	sortija de telurio
11989	anillo de vanadio
11990	anillo de selenio
11991	anillo de mercurio
11992	sortija bermellon
11993	anillo de terracota
11994	sortija de coral
11995	sortija de marfil
11996	anillo de basalto
11997	circulo de piedra verde
11998	aro de azabache
11999	aro de magnetita
12000	cuchilla de extremidad
12001	anillo de onice
12002	circulo de marmol
12003	cerveza negra enana
12004	sortija de obsidiana
12005	anillo de granito
12006	anillo de prado
12007	anillo de pradera
12008	anillo de sabana
12009	anillo tundra
12010	anillo de pantano
12011	aro de bosque
12012	anillo de marisma
12013	anillo del desierto
12014	anillo artico
12015	anillo del pantano
12016	anillo de la selva
12017	sortija centelleante
12018	yelmo de conservador
12019	dije ceruleo
12020	gargantilla de talio
12021	escarpes de escudo de placas
12022	cadena iridio
12023	collar de telurio
12024	dije de vanadio
12025	cadena de selenio
12026	colgante de mercurio
12027	collar bermellon
12028	collar de basalto
12029	dije de piedra verde
12030	cadena de azabache
12031	collar de magnetita
12032	gargantilla de onice
12033	joyas de familia thaurissan
12034	collar de marmol
12035	colgante de obsidiana
12036	collar de granito
12037	carne misteriosa
12038	sello de lagrave
12039	collar tundra
12040	colgante de bosque
12041	leotardos cortaviento
12042	cadena de mar li
12043	gargantilla del desierto
12044	colgante artico
12045	colgante del pantano
12046	collar de la selva
12047	collar espectral
12048	colgante centelleante
12049	armadura de acero seccionador
12050	botas de calima
12051	guanteletes de laton
12052	anillo de la luna
12053	anillo de roca volcanica
12054	sortija de demonio
12055	sortija de polvo de estrellas
12056	anillo de los cielos
12057	sortija de dragontina
12058	anillo de hueso demoniaco
12059	medallon de conquistador
12060	nota de shindrell
12061	hoja de juicio
12062	hoja apta para la lucha
12064	caperuza de maestro de juego
12065	resguardo contra los elementos
12066	manteo piel de esquisto
12082	bufas de pellejo de vermis
12083	fajin valconiano
12102	anillo del aristocrata
12103	estrella de mystaria
12104	guerrera espinapinta
12105	leotardos de malla de orgullo
12106	coraza de piel de roca
12107	leotardos de seda susurradora
12108	armadura de escamas de basalto
12109	amito de luna azur
12110	manton de lanzalluvias
12111	guanteletes de placas de lava
12112	brazales de demonio de cripta
12113	manteo nacido del sol
12114	guantes ocaso
12115	agarre de adepto
12122	basura de kum isha
12143	llave de espinazo de dragon
12144	ovosciloscopio
12162	diseno espada corta de hierro endurecido
12163	diseno espada ancha de acero lunar
12164	diseno hacha de hierro macizo
12184	carne de raptor
12185	sombrero de almirante velasangre
12190	pocion de letargo sin suenos
12191	arcon del amanecer de plata
12192	arcon del halo de bruma
12202	carne de tigre
12203	carne de lobo rojo
12204	carne de kodo pesada
12205	carne de arana blanca
12206	carne de cangrejo tierna
12207	huevo gigante
12208	carne de lobo tierna
12209	filete de lobo magro
12210	raptor asado
12211	costillas de lobo especiadas
12212	estofado de la selva
12213	sorpresa de carrona
12214	estofado misterioso
12215	estofado de kodo pesado
12216	chili de cangrejo especiado
12217	aji aliento de dragon
12218	tortilla gigante
12219	sello de ascension sin adornar
12220	brazal elemental intacto
12223	ala de murcielago carnosa
12224	ala de murcielago crujiente
12225	cana de pescar de la familia blump
12226	receta ala de murcielago crujiente
12227	receta filete de lobo magro
12228	receta raptor asado
12229	receta costillas de lobo picantes
12230	muestra de babosa de frondavil
12231	receta estofado de la selva
12232	receta sorpresa de carrona
12233	receta estofado misterioso
12234	muestra de frondavil corrupta
12235	muestra de babosa de un goro
12236	muestra de un goro pura
12237	trozos de cangrejo de gran calidad
12238	mero de costa oscura
12239	receta aji aliento de dragon
12240	receta estofado de kodo pesado
12241	huevo de dragon recogido
12242	huesos de criatura marina
12243	garra humeante
12247	cuchillo de hoja ancha
12248	puntilla temeraria
12249	hacha despiadada
12250	hacha de medianoche
12251	palo grande
12252	baston de proteccion
12253	capa roja luminosa
12254	capa bien aceitada
12255	leotardos palidos
12256	leotardos de pano cenizo
12257	cinturon con muchas marcas
12258	cinturon de pinza de serpiente
12259	daga de acero destellante
12260	hoja dorada abrasadora
12261	diseno hoja dorada abrasadora
12262	jaula de cachorro de huargo vacia
12263	cachorro de huargo enjaulado
12264	transportador de huargos
12282	hacha de batalla desgastada
12283	esencia de cria
12284	draco incarcinatrix 900
12286	prototipo de ovosciloscopio
12287	modulo colectronico
12288	moco corrupto encerrado
12289	restos de tortuga marina
12291	muestra de moco fusionado
12292	caja con simbolos extranos
12293	hilo de oro refinado
12295	leotardos de la milicia popular
12296	chispa de la milicia popular
12299	guantes de red
12300	orbe de energia draconica
12301	llave de jaula de bambu
12302	riendas del sable de hielo
12303	riendas del sable de la noche
12323	sello de ascension sin forjar
12324	sello de ascension forjado
12325	riendas del leopardo primigenio
12326	riendas del dientes de sable leonado
12327	riendas del dientes de sable dorado
12330	cuerno del lobo rojo
12334	esquirlas de machacahielo
12335	gema de espina ahumada
12336	gema de cumbrerroca
12337	gema de hacha de sangre
12339	obsequio de vaelan
12341	muestra de fruta bosque negro
12342	muestra de grano bosque negro
12343	muestra de nuez bosque negro
12344	sello de ascension
12345	pertenencias de bijou
12346	cuenco de purificacion vacio
12347	cuenco de purificacion lleno
12349	muestra del rio fonroca
12350	tubo de ensayo vacio
12351	cuerno del lobo artico
12352	broche de equipasino
12353	brida de semental blanco
12354	brida de palomino
12355	dije de corrupcion
12356	huevo de dracoleon de nido alto
12358	tablilla de rocanegra
12359	barra de torio
12360	barra de arcanita
12361	zafiro azul
12363	cristal arcano
12364	esmeralda enorme
12365	piedra densa
12366	pelaje de yeti grueso
12367	cuerno pristino de yeti
12368	gambito del alba
12369	cetro de vectus
12382	llave de la ciudad
12383	pluma lunadon
12384	alijo de mau ari
12402	huevo antiguo
12404	piedra de afilar densa
12405	armadura de torio
12406	cinturon de torio
12408	brazales de torio
12409	botas de torio
12410	yelmo de torio
12411	tercera tablilla mosh aru
12412	cuarta tablilla mosh aru
12414	leotardos de torio
12415	coraza radiante
12416	cinturon radiante
12417	aro radiante
12418	guantes radiantes
12419	botas radiantes
12420	leotardos radiantes
12422	peto de placas imperiales
12424	cinturon de placas imperiales
12425	brazales de placas imperiales
12426	botas de placas imperiales
12427	yelmo de placas imperiales
12428	sobrehombros de placas imperiales
12429	leotardos de placas imperiales
12430	e ko de sable de hielo
12431	e ko nevada
12432	e ko dentoesquirla
12433	e ko de lechucico salvaje
12434	e ko orvallo
12435	e ko de los cardo nevado
12436	e ko de los machacahielo
12437	caja de bonacresta
12438	carta de tinkee
12440	magic knucklebone dnd
12442	charm pouch dnd
12443	knucklebone pouch dnd
12444	cuerno de quimera orvallo
12445	talega de felnok
12446	mosquete yunquemar
12447	arco cardoleno
12448	rifle de caza ligero
12449	arco primitivo
12450	aluvion juju
12451	poder juju
12455	ascua juju
12457	escalofrio juju
12458	astucia juju
12459	escape juju
12460	poderio juju
12462	abrazo de la serpiente alada
12463	cuchillo carnicero de colmillo de draco
12464	garfas de las llamas de sangre
12465	manton ocaso
12466	cordon de espiral del alba
12467	huevo extrano
12468	varita chilton
12469	mutilador
12470	tobilleras acecharenas
12471	baston de caminadesiertos
12472	termometro de krakle
12522	guantes voladores de bingles
12524	amuleto de plumas azules
12525	suministros de jaron
12527	partecostillas
12528	el mazo del juez
12529	jaula de telabrasada
12530	huevo de arana de la cumbre
12531	aguja abrasadora
12532	aguja del tallapiedras
12533	pica ferrea
12534	cabeza de omokk
12535	regla de forja maldita
12542	vestimentas de pira funeraria
12543	piedracanto de forjaz
12544	resolucion de thrall
12545	ojo de orgrimmar
12546	punos de aristocrata
12547	mandilete de mar alom
12549	cajasesos
12550	grilletes runicos de golems
12551	capa escudo de piedra
12552	herreruelo aterrabojas
12553	botas caminapresto
12554	manos del heraldo exaltado
12555	grebas belicutor
12556	botas de suma sacerdotisa
12557	bufas de acero de ebano
12558	collar de plumas azules
12562	importantes documentos de roca negra
12563	orden del senor de la guerra dientegore
12564	nota de asesinato
12565	transportador de gatitos de winna
12566	frasquito endurecido
12567	frasquito lleno
12582	kris de zul serak
12583	sierra de fatalidad de puno negro
12584	tizona de gran mariscal
12585	medallon de ventormenta
12586	glandula de veneno inmadura
12587	ojo de rend
12588	sobrehombros de huesopua
12589	fajin pluma de polvo
12590	daga vil
12592	hoja negra de shahram
12602	deflector draconiano
12603	guerrera de la noche
12604	tiara de fuego estelar
12605	calaverador serpentino
12606	faja cristalizada
12607	escamas cromaticas luminosas
12608	delantal de carnicero
12609	atadura de vision policromatica
12610	sobrehombros runicos de placas
12611	botas runicas de placas
12612	yelmo de placas runicas
12613	coraza runica
12614	leotardos de placas runicas
12615	guerrera de malla indomita
12616	botas de malla indomita
12617	sobrehombros de malla indomita
12618	coraza de torio encantado
12619	leotardos de torio encantado
12620	yelmo de torio encantado
12621	horqueta de demonio
12622	carne dentoesquirla
12623	carne de orvallo
12624	malla espina salvaje
12625	sobrehombros albar
12626	punos de funeral
12627	desplazador temporal
12628	coraza de demonio forjada
12630	cabeza de rend puno negro
12631	guanteletes de placas igneas
12632	guanteletes de tormenta
12633	yelmo almablanca
12634	faja de cincelador
12635	papiro simple
12636	yelmo del gran jefe
12637	guanteletes de backus
12638	reloj de andorhal
12639	guanteletes bastion
12640	yelmo corazon de leon
12641	malla invulnerable
12642	orbe infernal limpio
12643	contrapeso denso
12644	piedra de pulir densa
12645	punta de escudo de torio
12646	esmeralda infus
12647	rubi de felhas
12648	espiritu de can manafago encarcelado
12649	espiritu infernal encarcelado
12650	atenuador armonizado
12651	cuervo negro
12652	informe de reconocimiento de bijou
12653	garfio desgarrador
12654	tiro maldito
12655	barra de torio encantado
12662	runa demoniaca
12663	rama de roble con inscripciones
12682	diseno armadura de torio
12683	diseno cinturon de torio
12684	diseno brazales de torio
12685	diseno cinturon radiante
12687	diseno sobrehombros de placas imperiales
12688	diseno cinturon de placas imperiales
12689	diseno coraza radiante
12690	diseno brazales de placas imperiales
12691	diseno malla espina salvaje
12692	diseno punta de escudo de torio
12693	diseno botas de torio
12694	diseno yelmo de torio
12695	diseno guantes radiantes
12696	diseno coraza de demonio forjada
12697	diseno botas radiantes
12698	diseno sobrehombros albar
12699	diseno guanteletes de placas igneas
12700	diseno botas de placas imperiales
12701	diseno yelmo de placas imperiales
12702	diseno aro radiante
12703	diseno guanteletes de tormenta
12704	diseno leotardos de torio
12705	diseno peto de placas imperiales
12706	diseno sobrehombros runicos de placas
12707	diseno botas runicas de placas
12708	cajon de suministros de el cruce
12709	despellejador de pip
12710	trozo resplandeciente de carne de la bestia
12711	diseno yelmo almablanca
12712	mojo de warosh
12713	diseno leotardos radiantes
12714	diseno yelmo de placas runicas
12715	diseno leotardos de placas imperiales
12716	diseno yelmo del gran jefe
12717	diseno yelmo corazon de leon
12718	diseno coraza runica
12719	diseno leotardos de placas runicas
12720	diseno guanteletes bastion
12721	medio talisman de buena suerte
12722	otro medio talisman de buena suerte
12723	talisman de buena suerte
12724	paquete de janice
12725	diseno yelmo de torio encantado
12726	diseno leotardos de torio encantado
12727	diseno coraza de torio encantado
12728	diseno malla invulnerable
12730	pergamino de warosh
12731	pellejo de la bestia pristino
12732	pita incendiaria
12733	carne de sable de hielo sacra
12734	hilo escarlata encantado
12735	costuras desgarradas de abominacion
12736	liquido de embalsamar de murmuhielo
12737	hierba luminiscente
12738	llave de la letrina de dalson
12739	llave del armario de dalson
12740	quinta tablilla mosh aru
12741	sexta tablilla mosh aru
12752	almete del sabio escarlata
12753	piel de sombra
12756	leotardos de arcana
12757	coraza sed de sangre
12762	secreto de disenos
12763	fruta de eter de un goro
12764	espada magna de torio
12765	nota secreta n º 1
12766	nota secreta n º 2
12768	nota secreta n º 3
12769	talladora de picomadera
12770	informacion de bijou
12771	frasco vacio de aguardiente
12772	martillo de torio taraceado
12773	hacha de mano de torio ornamentada
12774	filo del alba
12775	hacha de batalla de torio enorme
12776	martillo de batalla encantado
12777	estoque llameante
12778	cofre de documentos
12779	filo runico
12780	orden del general drakkisath
12781	serenidad
12782	corrupcion
12783	buscacorazones
12784	segadora de arcanita
12785	polvo de incendiaria
12790	campeona de arcanita
12791	casco de camarero
12792	martillo volcanico
12793	guerrera de mixologo
12794	martillo de tormenta magistral
12795	garfa sangrienta
12796	martillo de los titanes
12797	guardia de escarcha
12798	aniquiladora
12799	opalo grande
12800	diamante de azeroth
12802	lanza negra
12803	esencia viva
12804	mojo potente
12805	orbe de fuego
12806	coraza cubierta de runas sin forjar
12807	estandarte de la plaga
12808	esencia de no muerto
12809	piedra guardian
12810	cuero encantado
12811	orbe recto
12812	guanteletes de placas sin templar
12813	frasco de baba misteriosa
12814	fuego en botella
12815	antorcha de aviso
12816	diseno espada magna de torio
12817	diseno talladora de picomadera
12818	diseno martillo de torio taraceado
12819	diseno hacha de mano de torio ornamentada
12820	aguardiente nevada
12821	diseno filo del alba
12822	gotita de horror toxico
12823	diseno hacha de batalla de torio enorme
12824	diseno martillo de batalla encantado
12825	diseno estoque llameante
12826	diseno filo runico
12827	diseno serenidad
12828	diseno martillo volcanico
12829	cajon de nevada
12830	diseno corrupcion
12831	diseno garfa sangrienta
12832	diseno lanza negra
12833	diseno martillo de los titanes
12834	diseno campeona de arcanita
12835	diseno aniquiladora
12836	diseno guardia de escarcha
12837	diseno martillo de tormenta magistral
12838	diseno segadora de arcanita
12839	diseno buscacorazones
12840	piedra de la plaga del esbirro
12841	piedra de la plaga del invasor
12842	registro escrito de forma rudimentaria
12843	piedra de la plaga del corruptor
12844	muestra de valor de el alba argenta
12845	medallon de fe
12846	comision de el alba argenta
12847	pica manchada de alma
12848	pica manchada de sangre
12849	saco besado por demonio
12871	caparazon cromatico
12884	pezuna de arnak
12885	muneca de pamela
12886	cabeza de la muneca de pamela
12887	parte izquierda de la muneca de pamela
12888	parte derecha de la muneca de pamela
12891	pico de jaron
12894	alianza de joseph
12895	coraza del vuelo cromatico
12896	primer trozo de reliquia
12897	segundo trozo de reliquia
12898	tercer trozo de reliquia
12899	cuarto trozo de reliquia
12900	cronicas de villa darrow
12903	musleras del desafiante cromatico
12904	sombrero superespecial suami de shawn
12905	manteo de fuego salvaje
12906	agua de la poza de la luna purificada
12907	agua de la poza de la luna corrupta
12922	cantimplora vacia
12923	escama de awbee
12924	vela de ritual
12925	piel de serpiente de arikara
12926	sortija flamigera
12927	sobrehombros golpevero
12928	yeti mecanico de umi
12929	dije furia de ascuas
12930	junco maderahelecho
12935	musleras de maestro de guerra
12936	ajorcas belinato
12938	sangre de heroes
12939	guardian tribal de dal rend
12940	carga sagrada de dal rend
12942	llave de la jaula de pantera
12945	quijotes del desafiante cromatico
12946	hipercondensador
12947	anillo de audacia de alex
12952	calavera de gyth
12953	almofar ojo de dragon
12954	tratado de davil
12955	escudo de rutagrana
12956	craneo de horgus
12957	espada destrozada de marduk
12958	receta transmutar arcanita
12960	plumas de guerra tribales
12963	leotardos de maestro del acero
12964	musleras de tristam
12965	leotardos de embozo de espiritus
12966	guardabrazos de bruma negra
12967	capa luna de sangre
12968	manteo de tejescarcha
12969	sauce lloron
12970	placa ceremonial de general
12973	bala de canon escarlata
12974	el caballero negro
12975	hacha de prospector
12976	hoja parchierro
12977	guantes de puno del mago
12978	cinturon de extiendetormentas
12979	capa aterra fuego
12982	guardapies forrados con plata
12983	garrote rakzur
12984	clamacielos
12985	anillo de defensa
12987	calzones tejeoscuro
12988	guerrera de vista estelar
12989	mordisco de gargola
12990	filo de cuchilla
12992	hoja abrasadora
12994	guanteletes de thorbia
12996	sortija de purificacion
12997	blason barbarroja
12998	manto de mago
12999	braciles ala de draco
13000	baston de hale fuegomago
13001	circulo de doncella
13002	colgante de lady alizabeth
13003	hacha de batalla de lord alexander
13004	antorcha de austen
13005	manta de amy
13006	maza de mcgowan
13007	capa de llama de mago
13008	calzas de valdeviento
13009	pellejo del rey vacuno
13010	musleras cantasuenos
13011	cinturon forrado con plata
13012	brazales yorgen
13013	manto de zahori anciano
13014	hacha de rin ji
13015	serathil
13016	mutiladora
13017	hacha de batalla de asesino infernal
13018	cuchilla de verdugo
13019	arco corto de garra de arpia
13020	arco de artillero del cielo
13021	enhebraagujas
13022	arco largo de ala de grifo
13023	arco largo de cuerno de aguila
13024	azotador de beazel
13025	almadena muertobosque
13026	luz del cielo
13027	cascahuesos
13028	martillo piedra sangre
13029	cristal umbrio
13030	hueso de basilisco
13031	orbe de mantoniebla
13032	espada de corrupcion
13033	espada de zelote
13034	estoque aceroveloz
13035	cercenaserpientes
13036	hoja de asesinato
13037	aguijon pino de cristal
13038	vientopresto
13039	ballesta atraviesa calaveras
13040	ballesta certera
13041	hoja de guardian
13042	espada del magistrado
13043	hoja de los titanes
13044	destripademonios
13045	martillo viscoso
13046	maza de blanchard
13047	ramita del arbol del mundo
13048	mazo amenazante
13049	mandoble de decano
13051	furia de bruja
13052	belicista
13053	portador de fatalidad
13054	segador implacable
13055	mascahuesos
13056	asediador demente
13057	pico de sangre
13058	punta de khoo
13059	cuervo de piedra
13060	el taladro
13062	truenedera
13063	tumbaestrellas
13064	prendefuegos de jaina
13065	varita de allistarj
13066	bufas de destripador de vermis
13067	armadura aliento de hidra
13068	grebas de obsidiana
13070	botas de escama de sapphiron
13071	puno de hakoo con placas
13072	guanteletes de piedra
13073	yelmo de jarrathol
13074	leotardos de fragmentos goblin
13075	musleras alafunesta
13076	brazales de destripador gigante
13077	faja de uther
13079	escudo de thorsen
13080	garra de viuda
13081	escudo calaverance
13082	rodela de ladera
13083	blason de la familia garrett
13084	cadena caleidoscopica
13085	gargantilla horizonte
13086	riendas del sable de hielo de cuna del invierno
13087	gargantilla orgullo de rio
13088	talisman de gazlowe
13089	colgante de skibi
13090	coraza de los elegidos
13091	medallon del gran mariscal morris
13093	anillo de ascua encendida
13094	la joya de la reina
13095	sortija de asalto
13096	sortija de hierofante
13097	anillo de frente de acero
13098	sortija tejedano
13099	mocasines de la liebre blanca
13100	botas de furen
13101	zapatos correlobos
13102	gracia de cassandra
13103	hombrera de arana venenosa
13105	anillo de sutarn
13106	pulseras magicas resplandecientes
13107	punos de calavera magica
13108	manto de golpe de tigre
13109	manteo de llama negra
13110	arnes miedo lobo
13111	sandalias del insurgente
13112	yelmo alado
13113	ornato plumaluna
13114	leotardos aterratrols
13115	manto de esquilador de ovejas
13116	bufas de lo oculto
13117	fajin de ogron
13118	fajin serpentino
13119	brazales de kodo encantados
13120	brazales furiahonda
13121	ala del vastago
13122	manteo de fantasma oscuro
13123	armadura caminasuenos
13124	botas de escamas de ravasaurio
13125	botas de anillas elficas
13126	guanteletes belillama
13127	corona de atracador de hielo
13128	yelmo de gran bergg
13129	leotardos pirocabello
13130	musleras de brisaveloz
13131	manto de brillavalva
13132	sobrehombros esqueleticas
13133	cubrehombros pirodraco
13134	cinturon del gladiador
13135	guardabrazos senoriales
13136	lanzaguisantes del pequeno timmy
13137	tejehierro
13138	el silenciador
13139	rompentranas
13140	llave roja de sangre
13141	diente de gnarr
13142	faja de brigam
13143	marca del senor de los dragones
13144	cinturon de serenidad
13145	cinturon de ogro enigma
13146	escopeta lanza caparazones
13148	congeladora
13149	escrito sobre invocacion de eldarath vol 1
13151	los estudios misticos de hor ank
13152	la historia sin conclusion
13153	escrito de mal cin vorail
13154	estudios de jael marin de lo arcano
13155	calavera resonadora
13156	cristal mistico
13157	calavera fetida
13158	palabras del gran jefe
13159	polvo de huesos
13161	baston de refugio
13162	garras de reiver
13163	guadana incansable
13164	corazon de la escama
13166	sobrehombros embate
13167	puno de omokk
13168	torso del rey chaman
13169	leotardos de aterracrines
13170	leotardos de embozo celestial
13171	mechero de smokey
13172	tabaco de calidad de grimm
13173	hacha arrojadiza de hoja voladora
13174	muestra de carne apestada
13175	arco tirante de voone
13176	informacion sobre la plaga
13177	dije de evasion
13178	circulo rosado
13179	guardabrazos cuorobronce
13180	agua bendita de stratholme
13181	guantes de piel de demonio
13182	hoja fase
13183	escupeveneno
13184	luas de lagrimas
13185	manto de hendevidente
13186	botella vacia del campo de piedramacula
13187	botella del llanto de dalson vacia
13188	botella vacia de el tormento
13189	botella vacia de la gangrena de gahrron
13190	botella rellena del campo de piedramacula
13191	botella del llanto de dalson llena
13192	botella llena de el tormento
13193	botella llena de la gangrena de gahrron
13194	llave de la caldera del campo de piedramacula
13195	llave de la caldera del llanto de dalson
13196	llave de la caldera de la gangrena de gahrron
13197	llave de caldera rondada de el tormento
13198	machacador
13199	ataduras aplastacrestas
13202	cronicas ampliadas de villa darrow
13203	capa de estela
13204	maza de bashguud
13205	protector rhombeard
13206	leotardos de pelo de lobo
13207	cabeza de senor de las sombras fel dan
13208	guardabrazos aullador palido
13209	sello del alba
13210	escarpines de lobo aterrador
13211	brazales garraja
13212	collera de pinchos de halycon
13213	ojo de telabrasada
13216	corona del penitente
13217	sortija del penitente
13218	colmillo de la arana de cristal
13223	faltriquera de mensajero de stratholme
13243	defensor argenta
13244	guanteletes dorados
13245	caparazon de kresh
13246	vengador argenta
13247	baul del intendente zigris
13248	tiro de rafaga de arcabuz
13249	cruzado argenta
13250	cabeza de balnazzar
13251	cabeza de baron osahendido
13252	faja correnubes
13253	manos de poder
13254	guarda astral
13255	guanteletes de objetivo real
13257	bufas con runas demoniacas
13258	guanteletes de pellejo de escoria
13259	guardapies de costillas de acero
13260	botas de bailavientos
13261	globo de d sak
13262	crematoria
13282	botas de vigia de torre ogro
13283	anillo de mago
13284	botas de batalla dardopresto
13285	la cercenadora de roca negra
13286	puafilada
13287	patron arnes de pellejo de raptor
13288	patron cinturon de pellejo de raptor
13289	libertador de egan
13302	llave del buzon de la fila del mercado
13303	llave del buzon de la plaza de los cruzados
13304	llave del buzon de la calle del festival
13305	llave del buzon de la plaza de los ancianos
13306	llave del buzon de la plaza del rey
13307	llave del buzon de ezra grimm
13308	esquema deflector de hielo
13309	esquema bocarda fabricada con amor
13310	esquema mira de precision
13311	esquema dragonizo mecanico
13313	sagradas escrituras de los altonato
13314	abrazo de alanna
13317	silbato del raptor marfil
13320	acelerador arcano
13321	mecazancudo verde
13322	mecazancudo sin pintar
13323	mecazancudo morado
13324	mecazancudo rojo y azul
13325	mecazancudo verde fosforito
13326	mecazancudo blanco modelo a
13327	mecazancudo azul hielo modelo a
13328	carnero negro
13329	carnero de escarcha
13330	bolsa de rabanos de derek
13331	caballo esqueletico rojo
13332	caballo esqueletico azul
13333	caballo esqueletico marron
13334	caballo de guerra esqueletico verde
13335	riendas de destrero de la muerte
13340	manteo del baron negro
13342	pez mascota
13343	piedra mascota
13344	guanteletes draconianos
13345	sello de osahendido
13346	togas del exaltado
13347	cristal de zin malor
13348	corte de demonio
13349	cetro de los profanos
13350	insignia de la guardia negra
13351	delantal del forjamartillos carmesi
13352	piedra culebra de vosh gajin
13353	libro de los muertos
13354	resonador ectoplasmico
13356	intensificador somatico
13357	agitador oseo
13358	sobrehombros lenguavermis
13359	corona de tirania
13360	ofrenda del magi elfico
13361	espetadora forjacraneos
13362	carta del frente
13363	proclamacion municipal
13364	anuncio de ezra grimm
13365	aviso de consejo de la ciudad
13366	juguete ingenioso
13367	obsequio envuelto
13368	trizahuesos
13369	zancos de fuego
13370	enfocador vitreo
13371	llama paternal
13372	cachava del explotador
13373	sortija de carne
13374	manto de ladron de almas
13375	blason de reprension
13376	capa de tribunal real
13377	balas de canon en miniatura
13378	blusa ruisenor
13379	flautin de la llama flameante
13380	obus portatil de willey
13381	botas de maestro canonero
13382	mensajero bola de canon
13383	prendas de lana de juglar saltarin
13384	faja arco iris
13385	escrito sobre conocimiento
13386	manteo de archivista
13387	faja de prevision
13388	guerrera de jefe de correos
13389	calzas de jefe de correos
13390	banda de jefe de correos
13391	botines de jefe de correos
13392	sello de jefe de correos
13393	embate de gassol
13394	abrazo frio de skul
13395	garras de skul
13396	toque espantoso de skul
13397	manteo de gargola piel de piedra
13398	botas del aullador
13399	garfas de gargola trituradas
13400	avambrazos del sadico
13401	la mano cruel de timmy
13402	galochas de timmy
13403	lazo de grimagore
13404	mascara del imperdonable
13405	espaldares penumbria dolido
13408	quebrador de almas
13409	brazales lagrima
13422	anguila escama petrea
13423	aceite de escama petrea
13442	pocion de ira poderosa
13443	pocion de mana excelente
13444	pocion de mana sublime
13445	elixir de defensa excelente
13446	pocion de sanacion sublime
13447	elixir de los sabios
13448	las escrituras de castel darrow
13450	las escrituras de costasur
13451	las escrituras de molino tarren
13452	elixir de la mangosta
13453	elixir de fuerza bruta
13454	elixir arcano superior
13455	pocion de escudo de piedra superior
13456	pocion de proteccion contra la escarcha superior
13457	pocion de proteccion contra el fuego superior
13458	pocion de proteccion contra la naturaleza superior
13459	pocion de proteccion contra las sombras superior
13460	pocion de proteccion contra lo sagrado superior
13461	pocion de proteccion contra lo arcano superior
13462	pocion de purificacion
13463	hojasueno
13464	sansam dorado
13465	salviargenta de montana
13466	flor de plaga
13467	setelo
13468	loto negro
13469	cabeza de weldon barov
13470	cabeza de alexi barov
13471	las escrituras de remol
13473	talisman de buena suerte de piedra macula
13474	escopeta del granjero dalson
13475	alianza de la familia dalson
13476	receta pocion de ira poderosa
13477	receta pocion de mana excelente
13478	receta elixir de defensa excelente
13479	receta elixir de los sabios
13480	receta pocion de sanacion sublime
13481	receta elixir de fuerza bruta
13482	receta transmutar aire en fuego
13483	receta transmutar fuego a tierra
13484	receta transmutar tierra a agua
13485	receta transmutar agua a aire
13486	receta transmutar no muerto a agua
13487	receta transmutar agua a no muerto
13488	receta transmutar vida a tierra
13489	receta transmutar tierra a vida
13490	receta pocion de escudo de piedra superior
13491	receta elixir de la mangosta
13492	receta pocion de purificacion
13493	receta elixir arcano superior
13494	receta pocion de proteccion contra el fuego superior
13495	receta pocion de proteccion contra la escarcha superior
13496	receta pocion de proteccion contra la naturaleza superior
13497	receta pocion de proteccion contra lo arcano superior
13498	leotardos artesanales de maestro herrero
13499	receta pocion de proteccion contra las sombras superior
13500	receta pocion de proteccion contra lo sagrado superior
13501	receta pocion de mana sublime
13502	faja artesanal de maestro herrero
13503	piedra de alquimista
13505	hojarruna del baron osahendido
13506	frasco de petrificacion
13507	informe de vigiarrisco cuernolargo
13508	ojo de arachnida
13509	agarre de prevision
13510	frasco de los titanes
13511	frasco de sabiduria destilada
13512	frasco de poder supremo
13513	frasco de resistencia cromatica
13514	lamento de alma en pena
13515	descargas de relampagos de ramstein
13517	receta piedra de alquimista
13518	receta frasco de petrificacion
13519	receta frasco de los titanes
13520	receta frasco de sabiduria destilada
13521	receta frasco de poder supremo
13522	receta frasco de resistencia cromatica
13523	sangre inocente
13524	craneo de las sombras ardientes
13525	dedos de presotenebra
13526	faja marcada por las llamas
13527	grebas de corredor de lava
13528	brazales del vacio crepusculares
13529	coraza de nerub enkan
13530	zapatillas para correr gota colmillo
13531	leotardos de acechador de la cripta
13532	garras de giraoscuro
13533	espaldares grabados con acido
13534	dedo de alma en pena
13535	sobrevesta de fantasma tactofrio
13536	cuerno de despertar
13537	brazales pellejofrio
13538	espaldares de gritaviento
13539	toque de alma en pena
13542	caja de demonio
13544	esencia espectral
13545	marisco
13546	panzasangre
13562	restos de trey forjaluz
13582	correa zerguezno
13583	collera de panda
13584	piedra de diablo
13585	libro de los recuerdos
13602	piedra de hechizo superior
13603	piedra de hechizo sublime
13624	libro de memorias del alma
13626	cabeza humana de ras murmuhielo
13699	piedra de fuego
13700	piedra de fuego superior
13701	piedra de fuego sublime
13702	apocaliseas
13703	hueso de kodo
13704	llave esqueleto
13724	galleta enriquecida con mana
13725	bolsa de los horrores de krastinov
13752	libro de memorias del alma
13754	vigorpez lustroso crudo
13755	calamar de invierno
13756	lubina cruda
13757	anguila relampago
13758	branquirrojo crudo
13759	pargo nocturno crudo
13760	salmon escama de sol crudo
13761	huevos congelados
13810	fruta del sol bendita
13811	collar del alba
13812	anillo del alba
13813	zumo de fruta del sol bendita
13815	una runa
13816	tizona refinada
13817	espada magna estrecha
13818	hacha dentada
13819	hacha de guerra equilibrada
13820	maza de peso
13821	gran maza enorme
13822	daga con pinchos
13823	baston de guerra recio
13824	arco largo corvo
13825	mosquete primordial
13842	manana de otono invierno
13843	tarde de otono invierno
13844	tarde noche de otono invierno
13845	noche de otono invierno
13846	manana de primavera verano
13847	mediodia de primavera verano
13848	tarde de primavera verano
13849	noche de primavera verano
13850	municion de estruendo
13851	costillas de lobo picantes
13852	orden del gran cruzado
13853	trozo de carne de gusano carronero
13856	cinturon de pano runico
13857	guerrera de pano runico
13858	toga de pano runico
13860	capa de pano runico
13863	guantes de pano runico
13864	botas de pano runico
13865	pantalones de pano runico
13866	cinta de pano runico
13867	sobrehombros de pano runico
13868	toga de tejido de escarcha
13869	guerrera de tejido de escarcha
13870	guantes de tejido de escarcha
13871	pantalones de tejido de escarcha
13872	fardo de madera
13873	llave de la sala de vision
13874	cajon pesado
13875	cofre reforzado con hierro cerrado
13876	mero de 20 kilos
13877	mero de 23 kilos
13878	mero de 26 kilos
13879	mero de 27 kilos
13880	mero de 24 kilos
13881	branquirrojo hinchado
13882	branquirrojo de 21 kilos
13883	branquirrojo de 22 kilos
13884	branquirrojo de 24 kilos
13885	branquirrojo de 17 kilos
13886	branquirrojo de 18 kilos
13887	branquirrojo de 25 kilos
13888	langosta pinza oscura
13889	salmon escama blanca crudo
13890	pez coraza de placas
13891	salmon hinchado
13892	kombobulador kodo
13893	vigorpez crudo grande
13895	dangui formal
13896	hanbok de boda verde oscuro
13897	hanbok tradicional blanco
13898	dangui real
13899	hanbok tradicional rojo
13900	hanbok de boda verde
13901	salmon de 7 kilos
13902	salmon de 9 kilos
13903	salmon de 12 kilos
13904	salmon de 13 kilos
13905	salmon de 15 kilos
13906	salmon de 16 kilos
13907	langosta de 3 kilos
13908	langosta de 4 kilos
13909	langosta de 6 kilos
13910	langosta de 7 kilos
13911	langosta de 10 kilos
13912	langosta de 11 kilos
13913	langosta de 12 kilos
13914	vigorpez de 35 kilos
13915	vigorpez de 42 kilos
13916	vigorpez de 46 kilos
13917	vigorpez de 51 kilos
13918	cofre cerrado reforzado
13920	escama de dragon sana
13926	perla de oro
13927	vigorpez lustroso cocido
13928	calamar a la parrilla
13929	lubina ahumada picante
13930	filete de branquirrojo
13931	sopa de pargo nocturno
13932	salmon solescama pochado
13933	estofado de langosta
13934	filete de vigorpez
13935	salmon al horno
13937	carga de rector
13938	pluma amarrahuesos
13939	receta serviola moteada
13940	receta vigorpez lustroso cocido
13941	receta filete de branquirrojo
13942	receta calamar a la parrilla
13943	receta lubina ahumada picante
13944	coraza de lapida
13945	receta sopa de pargo nocturno
13946	receta salmon escama de sol pochado
13947	receta estofado de langosta
13948	receta filete de vigorpez
13949	receta salmon al horno
13950	cinta de detencion
13951	avambrazos de acerovigor
13952	rebanadora de hoja de hielo
13953	colmillo silencioso
13954	escarpines verdeantes
13955	sobrehombros con forma de piedra
13956	agarre de andros
13957	rebanadoras de gargolas
13958	grilletes vermiothalak
13959	limitador de circunferencia de omokk
13960	corazon del maligno
13961	bozal de halycon
13962	cenidor de vosh gajin
13963	mandiletes de mana de voone
13964	espada de bruja
13965	amplitud de puno negro
13966	marca de tirania
13967	grebas atracavientos
13968	ojo de la bestia
13969	ajorcas de guardia amenazante
13982	hoja de guerra de castel darrow
13983	hacha de guerra de lapida
13984	pico darrow
13986	corona de castel darrow
14002	guarda fuerte de villa darrow
14022	llamador de campesino barov
14023	llamador de campesino barov
14024	garfa de miedo
14025	cinturon de mistico
14042	jubon de pano cenizo
14043	guantes de pano cenizo
14044	capa de pano cenizo
14045	pantalones de pano cenizo
14046	bolsa de pano runico
14047	pano runico
14048	madeja de pano runico
14062	montura de kodo
14083	bastion de tyrande
14086	botas perladas
14087	punos perlados
14088	capa perlada
14089	guantes perlados
14090	calzones perlados
14091	toga perlada
14093	cordon perlado
14094	sobrevesta perlada
14095	braciles nativos
14096	jubon nativo
14097	pantalones nativos
14098	capa nativa
14099	fajin nativo
14100	toga de pano brillante
14101	guantes de pano brillante
14102	manijas nativas
14103	capa de pano brillante
14104	pantalones de pano brillante
14106	toga de tela vil
14107	pantalones de tela vil
14108	botas de tela vil
14109	toga nativa
14110	botas nativas
14111	caperuza de tela vil
14112	sobrehombros de tela vil
14113	fajin aborigen
14114	borceguies aborigenes
14115	braciles aborigenes
14116	manteo aborigen
14117	guantes aborigenes
14119	taparrabos aborigen
14120	toga aborigen
14121	jubon aborigen
14122	braciles de ritual
14123	manteo de ritual
14124	guantes de ritual
14125	leotardos de ritual
14126	amito de ritual
14127	embozo de ritual
14128	toga de tejido zahori
14129	sandalias de ritual
14130	turbante de tejido zahori
14131	cinturon de ritual
14132	leotardos de tejido zahori
14133	guerrera de ritual
14134	capa de fuego
14136	toga de noche invernal
14137	leotardos de tela lunar
14138	jubon de tela lunar
14139	sobrehombros de tela lunar
14140	aro de tela lunar
14141	jubon de tejido fantasmal
14142	guantes de tejido fantasmal
14143	cinturon de tejido fantasmal
14144	pantalones de tejido fantasmal
14145	hoja macula maldita
14146	guantes de maestria en hechizos
14147	brazales de morador de cuevas
14148	punos cristalinos
14149	manteo subterraneo
14150	toga de evocacion
14151	hoja de canto
14152	toga del archimago
14153	toga del vacio
14154	vestimentas de fe verdadera
14155	bolsa de tela lunar
14156	bolsa sin fondo
14157	manto pagano
14158	jubon pagano
14159	botas paganas
14160	braciles paganos
14161	manteo pagano
14162	mitones paganos
14163	almillas paganas
14164	cinturon pagano
14165	calzones paganos
14166	brazales de bucanero
14167	manteo de bucanero
14168	guantes de bucanero
14169	hombreras aborigenes
14170	manto de bucanero
14171	pantalones de bucanero
14172	togas de bucanero
14173	cordon de bucanero
14174	botas de bucanero
14175	jubon de bucanero
14176	botas de vigia
14177	punos de vigia
14178	almete de vigia
14179	manteo de vigia
14180	chaleco de vigia
14181	manijas de vigia
14182	manto de vigia
14183	leotardos de vigia
14184	togas de vigia
14185	cincho de vigia
14186	manto clamalluvias
14187	punos clamalluvias
14188	capa clamalluvias
14189	almete clamalluvias
14190	jubon clamalluvias
14191	mitones clamalluvias
14192	togas clamalluvias
14193	pantalones clamalluvias
14194	cordon clamalluvias
14195	botas clamalluvias
14196	sandalias piel de cardo
14197	braciles piel de cardo
14198	capa piel de cardo
14199	guantes piel de cardo
14200	almete piel de cardo
14201	manto piel de cardo
14202	chaleco piel de cardo
14203	pantalones piel de cardo
14204	toga piel de cardo
14205	cinturon piel de cardo
14206	pulseras vitales
14207	leotardos vitales
14208	cinta vital
14209	fajin vital
14210	manteo vital
14211	manijas vitales
14212	sobrehombros vitales
14213	vestiduras vitales
14214	botas vitales
14215	guerrera vital
14216	chaleco de geomantico
14217	cordon de geomantico
14218	botas de geomantico
14219	capa de geomantico
14220	almete de geomantico
14221	brazales de geomantico
14222	guantes de geomantico
14223	bufas de geomantico
14224	calzas de geomantico
14225	sobrevesta de geomantico
14226	pulseras de seda de ascuas
14227	seda de arana tejehierro
14228	nimbo de seda de ascuas
14229	capa de seda de ascuas
14230	guerrera de seda de ascuas
14231	mitones de seda de ascuas
14232	manto de seda de ascuas
14233	leotardos de seda de ascuas
14234	togas de seda de ascuas
14235	cordon de seda de ascuas
14236	botas de seda de ascuas
14237	armadura niebla negra
14238	botas niebla negra
14239	manteo niebla negra
14240	braciles niebla negra
14241	manoplas niebla negra
14242	pantalones niebla negra
14243	manto niebla negra
14244	sobrevesta niebla negra
14245	faja niebla negra
14246	sombrero de zahori niebla negra
14247	manto lunar
14248	ataduras lunares
14249	jubon lunar
14250	zapatillas lunares
14251	capa lunar
14252	nimbo lunar
14253	manijas lunares
14254	vestimenta lunar
14255	cinturon lunar
14256	tela vil
14257	leotardos lunares
14258	cordon de tejido de sangre
14259	botas de tejido de sangre
14260	brazales de tejido de sangre
14261	capa de tejido de sangre
14262	mitones de tejido de sangre
14263	mascara de tejido de sangre
14264	pantalones de tejido de sangre
14265	sobrevesta de tejido de sangre
14266	protectores de tejido de sangre
14267	chaleco de tejido de sangre
14268	punos de gaia
14269	zapatillas de gaia
14270	capa de gaia
14271	aro de gaia
14272	manijas de gaia
14273	amito de gaia
14274	leotardos de gaia
14275	vestimenta de gaia
14276	cinturon de gaia
14277	guerrera de gaia
14278	manto opulento
14279	brazales opulentos
14280	manteo opulento
14281	corona opulenta
14282	guantes opulentos
14283	leotardos opulentos
14284	togas opulentas
14285	botas opulentas
14286	cinturon opulento
14287	guerrera opulenta
14288	armadura aracnida
14289	faja aracnida
14290	escarpines aracnidos
14291	pulseras aracnidas
14292	manteo aracnido
14293	aro aracnido
14294	guantes aracnidos
14295	musleras aracnidas
14296	espaldares aracnidos
14297	togas aracnidas
14298	bufas de tirahuesos
14299	botas de tirahuesos
14300	manteo de tirahuesos
14301	ataduras de tirahuesos
14302	guantes de tirahuesos
14303	embozo de tirahuesos
14304	cinturon de tirahuesos
14305	sarong de tirahuesos
14306	jubon de tirahuesos
14307	corona de tirahuesos
14308	guerrera celestial
14309	cinturon celestial
14310	zapatillas celestiales
14311	ataduras celestiales
14312	corona celestial
14313	manteo celestial
14314	manijas celestiales
14315	falda celestial
14316	espaldares celestiales
14317	togas de seda celestiales
14318	guerrera rutilante
14319	botas rutilantes
14320	pulseras rutilantes
14321	capa rutilante
14322	aro rutilante
14323	guanteletes rutilantes
14324	sarong rutilante
14325	cubrehombros rutilantes
14326	togas rutilantes
14327	cinturon rutilante
14328	coselete eterno
14329	botas eternas
14330	ataduras eternas
14331	capa eterna
14332	corona eterna
14333	guantes eternos
14334	sarong eterno
14335	bufas eternas
14336	sobrevesta eterna
14337	cordon eterno
14338	tubo de agua vacio
14339	tubo de agua de la poza de la luna
14340	togas de exanime heladas
14341	hilo runico
14342	tela lunar
14343	fragmento luminoso pequeno
14344	fragmento luminoso grande
14364	zapatillas de mistico
14365	manteo de mistico
14366	pulseras de mistico
14367	guantes de mistico
14368	hombreras de mistico
14369	atadura de mistico
14370	prendas de lana de mistico
14371	toga de mistico
14372	armadura sanguina
14373	cinturon sanguino
14374	sandalias sanguinas
14375	punos sanguinos
14376	manteo sanguino
14377	manijas sanguinas
14378	manto sanguino
14379	calzas sanguinas
14380	toga sanguina
14381	cartera de totem siniestro
14382	pechera durabilidad
14383	brazales durabilidad
14384	botas durabilidad
14385	capa durabilidad
14386	sombrero durabilidad
14387	guantes durabilidad
14388	leotardos durabilidad
14389	hombreras durabilidad
14390	cinturon de durabilidad
14391	espada durabilidad
14392	baston durabilidad
14393	escudo durabilidad
14394	arco durabilidad
14395	hechizos de las sombras
14396	encantamientos desde el infierno
14397	manto resistente
14398	guerrera resistente
14399	botas resistentes
14400	manteo resistente
14401	almete resistente
14402	braciles resistentes
14403	luas resistentes
14404	leotardos resistentes
14405	toga resistente
14406	cordon resistente
14407	jubon de pano de piedra
14408	botas de pano de piedra
14409	manteo de pano de piedra
14410	aro de pano de piedra
14411	guantes de pano de piedra
14412	cubrehombros de pano de piedra
14413	toga de pano de piedra
14414	cinturon de pano de piedra
14415	calzones de pano de piedra
14416	ataduras de pano de piedra
14417	guerrera sedarena
14418	botas sedarena
14419	brazales sedarena
14420	manteo sedarena
14421	aro sedarena
14422	guantes sedarena
14423	hombreras sedarena
14424	ataduras sedarena
14425	sobrevesta sedarena
14426	faja sedarena
14427	sobrevesta cazavientos
14428	escarpines cazavientos
14429	punos cazavientos
14430	capa cazavientos
14431	manoplas cazavientos
14432	amito cazavientos
14433	cazavientos prendas de lana
14434	togas cazavientos
14435	cincho cazavientos
14436	nimbo cazavientos
14437	jubon de embozo de veneno
14438	botas de embozo de veneno
14439	guardabrazos de embozo de veneno
14440	manteo de embozo de veneno
14441	mascara de embozo de veneno
14442	mitones de embozo de veneno
14443	manto de embozo de veneno
14444	leotardos de embozo de veneno
14445	togas de seda de embozo de veneno
14446	cinturon de embozo de veneno
14447	escarpines de altonato
14448	pulseras de altonato
14449	corona de altonato
14450	capa de altonato
14451	guantes de altonato
14452	espaldares de altonato
14453	togas de altonato
14454	cordon de altonato
14455	armadura de altonato acolchada
14456	jubon elunarita
14457	punos elunaritas
14458	botas elunaritas
14459	capa elunarita
14460	diadema elunarita
14461	luas elunaritas
14462	sarong elunarita
14463	bufas elunaritas
14464	togas de seda elunaritas
14465	cinturon elunarita
14466	patron guerrera de tejido de escarcha
14467	patron toga de tejido de escarcha
14468	patron bolsa de pano runico
14469	patron toga de pano runico
14470	patron guerrera de pano runico
14471	patron jubon de pano cenizo
14472	patron capa de pano runico
14473	patron cinturon de tejido fantasmal
14474	patron guantes de tejido de escarcha
14476	patron guantes de pano cenizo
14477	patron guantes de tejido fantasmal
14478	patron toga de pano brillante
14479	patron guantes de pano brillante
14480	patron jubon de tejido fantasmal
14481	patron guantes de pano runico
14482	patron capa de pano cenizo
14483	patron pantalones de tela vil
14484	patron capa de pano brillante
14485	patron leotardos de tejido zahori
14486	patron capa de fuego
14487	martillo hielahuesos
14488	patron botas de pano runico
14489	patron pantalones de tejido de escarcha
14490	patron pantalones de pano cenizo
14491	patron pantalones de pano runico
14492	patron botas de tela vil
14493	patron toga de noche invernal
14494	patron pantalones de pano brillante
14495	patron pantalones de tejido fantasmal
14496	patron caperuza de tela vil
14497	patron leotardos de tela lunar
14498	patron cinta de pano runico
14499	patron bolsa de tela lunar
14500	patron toga de tejido zahori
14501	patron jubon de tela lunar
14502	faja mordedura de escarcha
14503	agarre de la muerte
14504	patron sobrehombros de pano runico
14505	patron turbante de tejido zahori
14506	patron toga de tela vil
14507	patron sobrehombros de tela lunar
14508	patron sobrehombros de tela vil
14509	patron aro de tela lunar
14510	patron bolsa sin fondo
14511	patron guantes de maestria en hechizos
14512	patron vestimentas de fe verdadera
14513	patron toga del archimago
14514	patron toga del vacio
14522	leotardos de la voragine
14523	pico de demonio
14525	guanteletes de huesos apretados
14526	patron tela lunar
14528	rodela armadosea
14529	venda de pano runico
14530	venda de pano runico gruesa
14531	baston de calamiedo
14536	camisote con huesos
14537	grebas de luz de cadaver
14538	manto caminamuerte
14539	yelmo de hueso
14540	corazon de taragaman el hambriento
14541	espada de la familia barovia
14542	cajon de kravel
14543	guantes sombra oscura
14544	insignia de teniente
14545	leotardos de fantasma
14546	cuerno de kodo de roon
14547	mano de iruxos
14548	bufas reales
14549	botas de evasion
14550	guardabrazos aterraespadas
14551	manoplas del maestro de filos
14552	espaldares de mazmorras
14553	fajin de piedad
14554	quijotes guardanubes
14555	navaja solar de alcor
14557	el cuerno de leon de ventormenta
14558	colgante de lady maye
14559	fajin de prospector
14560	botas de prospector
14561	punos de prospector
14562	pechera de prospector
14563	capa de prospector
14564	mitones de prospector
14565	prendas de lana de prospector
14566	hombreras de prospector
14567	cinturon erizacorteza
14568	botas erizacorteza
14569	ataduras erizacorteza
14570	blusa erizacorteza
14571	manteo erizacorteza
14572	guantes erizacorteza
14573	amito erizacorteza
14574	calzones erizacorteza
14576	empunadura de ebano de marduk
14577	pantalones humo de calavera
14578	cordon dokebi
14579	botas dokebi
14580	brazales dokebi
14581	coselete dokebi
14582	manteo dokebi
14583	guantes dokebi
14584	sombrero dokebi
14585	leotardos dokebi
14587	manto dokebi
14588	cordon de ojo de halcon
14589	botas de ojo de halcon
14590	brazales de ojo de halcon
14591	gorro de ojo de halcon
14592	guerrera de ojo de halcon
14593	capa de ojo de halcon
14594	guantes de ojo de halcon
14595	calzones de ojo de halcon
14596	cubrehombros de ojo de halcon
14598	pretina de celador
14599	escarpines de celador
14600	braciles de celador
14601	sobrevesta de celador
14602	capa de celador
14603	manto de celador
14604	sombrero de zahori de celador
14605	prendas de lana de celador
14606	guantes de celador
14607	rodela de ojo de halcon
14608	rodela dokebi
14610	escarabeo de araj
14611	camisote mallasangre
14612	musleras mallasangre
14613	martillo de taelan
14614	cinturon mallasangre
14615	guanteletes mallasangre
14616	botas mallasangre
14617	camisa de matasanos
14619	trozos esqueleticos
14620	faja de hueso de muerto
14621	escarpes de hueso de muerto
14622	guanteletes de hueso de muerto
14623	musleras de hueso de muerto
14624	peto de hueso de muerto
14625	simbolo de honor perdido
14626	toga necropila
14627	patron camisa amarillo brillante
14628	trozos esqueleticos imbuidos
14629	punos necropilos
14630	patron capucha de encantador
14631	botas necropilas
14632	leotardos necropilos
14633	manto necropilo
14634	receta aceite de escarcha
14635	patron cinturon de cuero con gemas incrustadas
14636	cinturon de cadaver
14637	armadura de cadaver
14638	leotardos de cadaver
14639	esquema recombobulador menor
14640	guantes de cadaver
14641	botos de cadaver
14644	molde para llave esqueleto
14645	llave esqueleto sin terminar
14646	vale de regalo de villanorte
14647	vale de regalo de valle de crestanevada
14648	vale de regalo de canada umbria
14649	vale de regalo de valle de los retos
14650	vale de regalo de campamento narache
14651	vale de regalo de camposanto
14652	fajin scorpashi
14653	zapatillas scorpashi
14654	braciles scorpashi
14655	coraza scorpashi
14656	manteo scorpashi
14657	guantes scorpashi
14658	capacete scorpashi
14659	leotardos scorpashi
14660	hombreras scorpashi
14661	cordon de vigilante
14662	pezunas de vigilante
14663	ataduras de vigilante
14664	armadura de vigilante
14665	capa de vigilante
14666	guantes de vigilante
14667	corona de vigilante
14668	prendas de lana de vigilante
14669	manto de vigilante
14670	armadura de senor orgulloso
14671	botas de senor orgulloso
14672	braciles de senor orgulloso
14673	manteo de senor orgulloso
14674	faja de senor orgulloso
14675	guantes de senor orgulloso
14676	halo de senor orgulloso
14677	pantalones de senor orgulloso
14678	espaldares de senor orgulloso
14679	del amor y la familia
14680	jubon de indomito
14681	botas de indomito
14682	guardabrazos de indomito
14683	capa de indomito
14684	cinturon de indomito
14685	guanteletes de indomito
14686	ornato de indomito
14687	leotardos de indomito
14688	cubrehombros de indomito
14722	tobilleras de pintura de guerra
14723	ataduras de pintura de guerra
14724	capa de pintura de guerra
14725	pretina de pintura de guerra
14726	guantes de pintura de guerra
14727	musleras de pintura de guerra
14728	hombreras de pintura de guerra
14729	escudo de pintura de guerra
14730	pechera de pintura de guerra
14742	botas descomunales
14743	braciles descomunales
14744	coselete descomunal
14745	capa descomunal
14746	cinturon descomunal
14747	guanteletes descomunales
14748	leotardos descomunales
14749	bufas descomunales
14750	punos de destripador
14751	sobrevesta de destripador
14752	manteo de destripador
14753	capacete de destripador
14754	guantes de destripador
14755	fajin de destripador
14756	zapatillas de destripador
14757	pantalones de destripador
14758	hombreras de destripador
14759	brazales duraderos
14760	coraza duradera
14761	cinturon duradero
14762	botas duraderas
14763	manteo duradero
14764	guanteletes duraderos
14765	aro duradero
14766	calzones duraderos
14767	espaldares duraderos
14768	armadura de devastador
14769	sandalias de devastador
14770	guardabrazos de devastador
14771	capa de devastador
14772	manijas de devastador
14773	cordon de devastador
14774	corona de devastador
14775	prendas de lana de devastador
14776	manto de devastador
14777	escudo de devastador
14778	ataduras de kan
14779	pechera de kan
14780	rodela de kan
14781	capa de kan
14782	guantes de kan
14783	cinturon de kan
14784	grebas de kan
14785	casco de kan
14786	musleras de kan
14787	manto de kan
14788	guardabrazos protectores
14789	coraza protectora
14790	rodela protectora
14791	manteo protector
14792	guanteletes protectores
14793	pretina protectora
14794	guardatobillos
14795	yelmo protector
14796	musleras protectoras
14797	hombreras protectoras
14798	coraza ansia de sangre
14799	botas ansia de sangre
14800	rodela ansia de sangre
14801	manteo ansia de sangre
14802	guanteletes ansia de sangre
14803	cinturon ansia de sangre
14804	yelmo ansia de sangre
14805	calzones ansia de sangre
14806	cubrehombros ansia de sangre
14807	pulseras ansia de sangre
14808	cinturon golpe de guerra
14809	escarpes golpe de guerra
14810	braquiales golpe de guerra
14811	coselete golpe de guerra
14812	rodela golpe de guerra
14813	manteo golpe de guerra
14814	casco golpe de guerra
14815	guanteletes golpe de guerra
14816	musleras golpe de guerra
14817	hombreras golpe de guerra
14821	coraza simbolica
14825	blason simbolico
14826	guanteletes simbolicos
14827	cinturon simbolico
14828	grebas simbolicas
14829	quijotes simbolicos
14830	espaldares simbolicos
14831	corona simbolica
14832	avambrazos simbolicos
14833	guanteletes de tirano
14834	guardabrazos de tirano
14835	pechera de tirano
14838	cinturon de tirano
14839	grebas de tirano
14840	quijotes de tirano
14841	cubrehombros de tirano
14842	escudo de tirano
14843	yelmo de tirano
14844	coselete de solescama
14846	guanteletes de solescama
14847	cinturon de solescama
14848	escarpes de solescama
14849	casco de solescama
14850	quijotes de solescama
14851	bufas de solescama
14852	escudo de solescama
14853	guardamunecas de solescama
14854	coraza soldado de caballeria
14855	guanteletes soldado de caballeria
14856	faja soldado de caballeria
14857	escarpes soldado de caballeria
14858	ornato soldado de caballeria
14859	quijotes soldado de caballeria
14860	espaldares soldado de caballeria
14861	avambrazos soldado de caballeria
14862	coraza de lider de guerra
14863	guanteletes de lider de guerra
14864	cinturon de lider de guerra
14865	grebas de lider de guerra
14866	corona de lider de guerra
14867	leotardos de lider de guerra
14868	sobrehombros de lider de guerra
14869	brazales de lider de guerra
14872	obsequio de tirion
14894	raiz de lirio
14895	sobrevesta piedra de sal
14896	escarpes piedra de sal
14897	guanteletes piedra de sal
14898	faja piedra de sal
14899	yelmo piedra de sal
14900	quijotes piedra de sal
14901	hombreras piedra de sal
14902	escudo piedra de sal
14903	braquiales piedra de sal
14904	coraza tosca
14905	guanteletes toscos
14906	cinturon tosco
14907	casco tosco
14908	musleras toscas
14909	sobrehombros toscos
14910	guardabrazos tosco
14911	botas toscas
14912	escudo tosco
14913	grebas de jade
14914	brazales de jade
14915	coraza de jade
14916	deflector de jade
14917	guanteletes de jade
14918	cinturon de jade
14919	aro de jade
14920	quijotes de jade
14921	cubrehombros de jade
14922	escarpes magnanimos
14923	guardabrazos magnanimos
14924	coraza magnanima
14925	yelmo magnanimo
14926	guanteletes magnanimos
14927	cinturon magnanimo
14928	musleras magnanimas
14929	hombreras magnanimas
14930	escudo magnanimo
14931	armadura heroica
14932	grebas heroicas
14933	guanteletes heroicos
14934	faja heroica
14935	capacete heroico
14936	quijotes heroicos
14937	espaldares heroicos
14938	brazales heroicos
14939	coselete de batallador
14940	escarpes de batallador
14941	braquiales de batallador
14942	guanteletes de batallador
14943	cinturon de batallador
14944	corona de batallador
14945	musleras de batallador
14946	bufas de batallador
14947	escudo de batallador
14948	pechera forjada con sangre
14949	guanteletes forjados con sangre
14950	cinturon forjado con sangre
14951	escarpes forjados con sangre
14952	casco forjado con sangre
14953	quijotes forjados con sangre
14954	escudo forjado con sangre
14955	hombreras forjadas con sangre
14956	ataduras forjadas con sangre
14957	escarpes de gran jefe
14958	armadura de gran jefe
14959	guanteletes de gran jefe
14960	cinturon de gran jefe
14961	corona de gran jefe
14962	musleras de gran jefe
14963	espaldares de gran jefe
14964	escudo de gran jefe
14965	ataduras de gran jefe
14966	coraza gloriosa
14967	guanteletes gloriosos
14968	cinturon glorioso
14969	ornato glorioso
14970	quijotes gloriosos
14971	hombreras gloriosas
14972	escarpes gloriosos
14973	escudo glorioso
14974	ataduras gloriosas
14975	arnes exaltado
14976	guanteletes exaltados
14977	faja exaltada
14978	escarpes exaltados
14979	casco exaltado
14980	quijotes exaltados
14981	cubrehombros exaltados
14982	escudo exaltado
14983	braquiales exaltados
15002	pica de nimboya
15003	cinturon primigenio
15004	botas primigenias
15005	braciles primigenios
15006	rodela primigenia
15007	manteo primigenio
15008	mitones primigenios
15009	leotardos primigenios
15010	sobrevesta primigenia
15011	cordon lupino
15012	zapatillas lupinas
15013	punos lupinos
15014	rodela lupina
15015	capa lupina
15016	manijas lupinas
15017	leotardos lupinos
15018	jubon lupino
15019	manto lupino
15042	tarro de termitas vacio
15043	termitas de las tierras de la peste
15044	barrica de termitas de las tierras de la peste
15045	coraza de dragontina verde
15046	leotardos de dragontina verde
15047	coraza de dragontina roja
15048	coraza de dragontina azul
15049	sobrehombros de dragontina azul
15050	coraza de dragontina negra
15051	sobrehombros de dragontina negra
15052	leotardos de dragontina negra
15053	coraza volcanica
15054	leotardos volcanicos
15055	sobrehombros volcanicos
15056	armadura de embozo de tormenta
15057	pantalones de embozo de tormenta
15058	sobrehombros de embozo de tormenta
15059	coraza viva
15060	leotardos vivos
15061	sobrehombros vivos
15062	leotardos de demosaurio
15063	guanteletes de demosaurio
15064	arnes de oso de guerra
15065	prendas de lana de oso de guerra
15066	coraza plumahierro
15067	sobrehombros plumahierro
15068	guerrera de sable de hielo
15069	leotardos de sable de hielo
15070	guantes de sable de hielo
15071	botas de sable de hielo
15072	leotardos quimericos
15073	botas quimericas
15074	guantes quimericos
15075	jubon quimerico
15076	jubon de escorpido pesado
15077	brazales de escorpido pesados
15078	guantelete de escorpido pesado
15079	leotardos de escorpido pesados
15080	yelmo de escorpido pesado
15081	sobrehombros de escorpido pesados
15082	cinturon de escorpido pesado
15083	guanteletes de cuero maligno
15084	brazales de cuero maligno
15085	armadura de cuero maligno
15086	cinta de cuero maligno
15087	pantalones de cuero maligno
15088	cinturon de cuero maligno
15090	armadura de cuero runico
15091	guanteletes de cuero runico
15092	brazales de cuero runico
15093	cinturon de cuero runico
15094	cinta de cuero runico
15095	pantalones de cuero runico
15096	sobrehombros de cuero runico
15102	muestra examinada de un goro
15103	muestra examinada corrupta
15104	botas portaalas
15105	baston de noh orahil
15106	baston de dar orahil
15107	orbe de noh orahil
15108	orbe de dar orahil
15109	baston de soran ruk
15110	cinturon rigido
15111	mocasines rigidos
15112	pulseras rigidas
15113	rodela rigida
15114	manteo rigido
15115	guantes rigidos
15116	sobrehombros rigidos
15117	leotardos rigidos
15118	guerrera rigida
15119	pantalones de altonato
15120	faja robusta
15121	botas robustas
15122	brazales robustos
15123	rodela robusta
15124	capa robusta
15125	guantes robustos
15126	leotardos robustos
15127	sobrehombros robustos
15128	guerrera robusta
15129	yelmo robusto
15130	jubon de degollador
15131	botas de degollador
15132	guardabrazos de degollador
15133	rodela de degollador
15134	sombrero de degollador
15135	manteo de degollador
15136	cinturon de degollador
15137	mitones de degollador
15138	capa de escamas de onyxia
15139	pantalones de degollador
15140	manto de degollador
15141	coraza de escamas de onyxia
15142	botas pie fantasmal
15143	ataduras pie fantasmal
15144	harapos pie fantasmal
15145	rodela pie fantasmal
15146	gorro pie fantasmal
15147	capa pie fantasmal
15148	cinturon pie fantasmal
15149	guantes pie fantasmal
15150	refuerzo pie fantasmal
15151	musleras pie fantasmal
15152	botas nocturnas
15153	capa nocturna
15154	fajin nocturno
15155	guantes nocturnos
15156	sombrero nocturno
15157	leotardos nocturnos
15158	hombreras nocturnas
15159	guerrera nocturna
15160	braciles nocturnas
15161	cinturon imponente
15162	botas imponentes
15163	brazales imponentes
15164	jubon imponente
15165	manteo imponente
15166	guantes imponentes
15167	panuelo imponente
15168	pantalones imponentes
15169	sobrehombros imponentes
15170	armadura pujante
15171	botas pujantes
15172	braciles pujantes
15173	manteo pujante
15174	guantes pujantes
15175	casco pujante
15176	pantalones pujantes
15177	sobrehombros pujantes
15178	cinturon pujante
15179	armadura acolchada pretoriana
15180	faja de pretoriano
15181	botas de pretoriano
15182	braciles pretorianas
15183	capa de pretoriano
15184	guantes de pretoriano
15185	almofar de pretoriano
15186	leotardos de pretoriano
15187	espaldares pretorianos
15188	guardabrazos grandiosos
15189	botas grandiosas
15190	capa grandiosa
15191	cinturon grandioso
15192	guanteletes grandiosos
15193	corona grandiosa
15194	musleras grandiosas
15195	coraza grandiosa
15196	tabardo de soldado
15197	tabardo de explorador
15198	colores de caballero
15199	heraldo de guardia de piedra
15200	insignia de capataz primero
15202	leotardos de protector salvaje
15203	musleras de tormenta de entranas
15204	varita de piedra lunar
15205	rifle con vista de buho
15206	bordon de fuego de jade
15207	escudo de acero
15208	polvo de luna cenarion
15209	fardo de reliquias
15210	espada corta de asaltante
15211	espada corta de militante
15212	espada ancha de luchador
15213	hoja de mercenario
15214	tizon de nobles
15215	bracamarte furioso
15216	runaespada
15217	espada de viuda
15218	espada de cristal
15219	hoja dimensional
15220	sable de belivil
15221	espada de guerra sagrada
15222	garrote con puas
15223	estrella dentada
15224	machacabatallas
15225	martillo de secuoya
15226	garrote gigante
15227	cachiporra con punta de diamante
15228	meteorito mortal
15229	martillo ventobendito
15230	cuchilla de pena
15231	hachuela seccionadora
15232	cuchilla para picar
15233	hacha indomita
15234	guadana superior
15235	filo curvo
15236	cuchilla de la luna
15237	cosechacadaveres
15238	hacha de senor de la guerra
15239	espetadora de piedra macula
15240	garra de demonio
15241	cuchillo de batalla
15242	estilete punzante
15243	kris mortal
15244	hoja de navaja
15245	daga vorpal
15246	hoja de demonio
15247	daga de golpe de sangre
15248	mandoble reluciente
15249	montante pulido
15250	flamberge de luz tremula
15251	espada golpecabeza
15252	espada con colmillo
15253	hoja decapitadora
15254	espadon oscuro
15255	flamberge de galante
15256	espada de masacre
15257	hoja espinilla
15258	hoja de guerra divina
15259	martillo de batalla pesado
15260	martillo de piedra
15261	rama de secuoya
15262	gran maza superior
15263	marra real
15264	partedorsales
15265	castigador
15266	destructor fiero
15267	martillo tosco
15268	hacha de dos filos
15269	hacha de batalla maciza
15270	hacha de guerra gigante
15271	gran hacha colosal
15272	hacha cuchilla
15273	golpeamuerte
15274	baston largo de adivino
15275	baston de taumaturgo
15276	baston largo de mago
15277	kodo gris
15278	baston de solsticio
15279	varita de marfil
15280	mano de zahori
15281	vara resplandor astral
15282	dedo de dragon
15283	varita lunar
15284	arco de batalla largo
15285	arco largo de arquero
15286	arco largo de madera roja
15287	arco de cruzado
15288	arco tiroespina
15289	arco arcogolpe
15290	kodo marron
15291	taladro de arpia
15292	kodo verde
15293	kodo azulado
15294	arco de asedio
15295	arco de fuego de pinchos
15296	arco de ojo de halcon
15297	brazales de oso pardo
15298	rodela de oso pardo
15299	manteo de oso pardo
15300	guantes de oso pardo
15301	zapatillas de oso pardo
15302	cinturon de oso pardo
15303	pantalones de oso pardo
15304	chaleco de oso pardo
15305	botas ferales
15306	ataduras ferales
15307	rodela feral
15308	cordon feral
15309	capa feral
15310	guantes ferales
15311	arnes feral
15312	leotardos ferales
15313	hombreras ferales
15314	monton de reliquias
15322	pistola de anima lisa
15323	pistola de percusion
15324	rifle quemado
15325	arcabuz certero
15326	hacha arrojadiza reluciente
15327	daga arrojadiza maligna
15328	llave de joseph
15329	cinturon de retador
15330	botas de retador
15331	braciles de retador
15332	rodela de retador
15333	capa de retador
15334	guantes de retador
15335	espada corta de acero brezo
15336	leotardos de retador
15337	sobrevesta de retador
15338	manto de retador
15339	gorro de abrecaminos
15340	capa de abrecaminos
15341	escarpines de abrecaminos
15342	guarda de abrecaminos
15343	guantes de abrecaminos
15344	pantalones de abrecaminos
15345	hombreras de abrecaminos
15346	jubon de abrecaminos
15347	cinturon de abrecaminos
15348	brazales de abrecaminos
15349	cinturon de rebanacabezas
15350	zapatillas de rebanacabezas
15351	braciles de rebanacabezas
15352	rodela de rebanacabezas
15353	gorro de rebanacabezas
15354	capa de rebanacabezas
15355	mitones de rebanacabezas
15356	armadura de rebanacabezas
15357	bufas de rebanacabezas
15358	prendas de lana de rebanacabezas
15359	jubon de timador
15360	ataduras de timador
15361	fajin de timador
15362	botas de timador
15363	ornato de timador
15364	capa de timador
15365	manijas de timador
15366	leotardos de timador
15367	protector de timador
15368	espaldares de timador
15369	cinturon de caballero lobo
15370	botas de caballero lobo
15371	capa de caballero lobo
15372	guantes de caballero lobo
15373	tiara de caballero lobo
15374	leotardos de caballero lobo
15375	hombreras de caballero lobo
15376	armadura acolchada de caballero lobo
15377	braciles de caballero lobo
15378	cinturon garrafuria
15379	botas garrafuria
15380	brazales garrafuria
15381	coselete garrafuria
15382	capa garrafuria
15383	guantes garrafuria
15384	yelmo garrafuria
15385	leotardos garrafuria
15386	hombreras garrafuria
15387	pulseras de fuego de jade
15388	cinturon de fuego de jade
15389	escarpes de fuego de jade
15390	coselete de fuego de jade
15391	gorro de fuego de jade
15392	capa de fuego de jade
15393	guantes de fuego de jade
15394	pantalones de fuego de jade
15395	cubrehombros de fuego de jade
15396	daga de madera curva
15397	baston de roble
15398	botas de peinarenas
15399	cinturon de algas secas
15400	brazales de concha de almeja
15401	guantes de gota de pozo
15402	guanteletes de noosegrip
15403	brazales cresta
15404	faja arrecife
15405	guantes de criba
15406	botas crustaceo
15407	pellejo basto curtido
15408	escama de escorpido gruesa
15409	sal de roca refinada
15410	escama de onyxia
15411	marca de vadin
15412	dragontina verde
15413	coraza de adamantio ornamentado
15414	dragontina roja
15415	dragontina azul
15416	dragontina negra
15417	cuero de demosaurio
15418	martillo de guerra de platino fulgurante
15419	cuero de oso de guerra
15420	plumahierro
15421	embozo del exilio
15422	cuero de sable de hielo
15423	cuero quimerico
15424	hacha de orgrimmar
15425	brazales incomparables
15426	botas incomparables
15427	capa incomparable
15428	cinturon incomparable
15429	guantes incomparables
15430	cinta incomparable
15431	leotardos incomparables
15432	sobrehombros incomparables
15433	armadura incomparable
15434	fajin supremo
15435	botas supremas
15436	brazales supremos
15437	manteo supremo
15438	guantes supremos
15439	corona suprema
15440	leotardos supremos
15441	sobrehombros supremos
15442	coraza suprema
15443	kris de orgrimmar
15444	baston de orgrimmar
15445	martillo de orgrimmar
15446	juego de diputado de ventormenta
15447	putrefaccion viva
15448	putrefaccion coagulada
15449	calzas espantosas
15450	leotardos de cenagal
15451	leotardos gargola
15452	brazales de cuentas emplumadas
15453	brazales de sabana
15454	mortero y majadero
15455	togas guardapolvo
15456	leotardos de paso ligero
15457	sobrehombros del desierto
15458	botas tundra
15459	guardamunecas tanidos rictus
15461	botas con tacon ligero
15462	brazales de marga
15463	guantes de zancudo palido
15464	martillo de tosco
15465	varita de picadura
15466	escudo tintineante
15467	anillo de la liga de los inventores
15468	manton son del viento
15469	cincho son del viento
15470	leotardos de guardia de las llanuras
15471	armadura pellejomusculo
15472	cinturon de cargador
15473	botas de cargador
15474	ataduras de cargador
15475	capa de cargador
15476	manijas de cargador
15477	pantalones de cargador
15478	escudo de cargador
15479	armadura de cargador
15480	restos de faja
15481	restos de grebas
15482	restos de braciles
15483	restos de manteo
15484	restos de luas
15485	restos de pantalones
15486	restos de escudo
15487	restos de guerrera
15488	sobrevesta salpicada de sangre
15489	escarpes salpicados de sangre
15490	capa salpicada de sangre
15491	guantes salpicados de sangre
15492	fajin salpicado de sangre
15493	taparrabos salpicado de sangre
15494	escudo salpicado de sangre
15495	braciles salpicados de sangre
15496	hombreras salpicadas de sangre
15497	cordon de avanzado
15498	zapatillas de avanzado
15499	punos de avanzado
15500	coselete de avanzado
15501	capa de avanzado
15502	guantes de avanzado
15503	musleras de avanzado
15504	escudo de avanzado
15505	espaldares de avanzado
15506	tobilleras de bruto
15507	brazales de bruto
15508	manteo de bruto
15509	manijas de bruto
15510	cinturon de bruto
15511	musleras de bruto
15512	escudo de bruto
15513	espaldares de bruto
15514	pechera de bruto
15515	cinturon de anillas con pinchos
15516	zapatillas de anillas con pinchos
15517	braciles de anillas con pinchos
15518	coraza de anillas con pinchos
15519	capa de anillas con pinchos
15520	guanteletes de anillas con pinchos
15521	leotardos de anillas con pinchos
15522	escudo de anillas con pinchos
15523	hombreras de anillas con pinchos
15524	sobrevesta de avizor
15525	zapatillas de avizor
15526	manteo de avizor
15527	guantes de avizor
15528	fajin de avizor
15529	leotardos de avizor
15530	escudo de avizor
15531	guardahombros de avizor
15532	braquiales de avizor
15533	ornato de avizor
15534	botas de anillas malignas
15535	brazales de anillas malignos
15536	pechera de anillas maligna
15537	capa de anillas maligna
15538	guanteletes de anillas malignos
15539	pretina de anillas maligna
15540	casco de anillas maligno
15541	musleras de anillas malignas
15542	hombreras de anillas malignas
15543	escudo de anillas maligno
15544	escarpes de escamas gruesas
15545	pulseras de escamas gruesas
15546	coraza de escamas gruesas
15547	capa de escamas gruesas
15548	guanteletes de escamas gruesas
15549	cinturon de escama gruesa
15550	corona de escamas gruesas
15551	musleras de escamas gruesas
15552	escudo de escamas gruesas
15553	hombreras de escamas gruesas
15554	faja de saqueador
15555	botas de saqueador
15556	brazales de saqueador
15557	coselete de saqueador
15558	corona de saqueador
15559	capa de saqueador
15560	guantes de saqueador
15561	leotardos de saqueador
15562	espaldares de saqueador
15563	escudo de saqueador
15564	refuerzo para armadura basto
15565	botas de maleante
15566	brazales de maleante
15567	guerrera de maleante
15568	capa de maleante
15569	blason de maleante
15570	guanteletes de maleante
15571	cinturon de maleante
15572	aro de maleante
15573	leotardos de maleante
15574	hombreras de maleante
15575	cinturon de brillavalva
15576	escarpes de brillavalva
15577	brazales de brillavalva
15578	coraza de brillavalva
15579	capa de brillavalva
15580	felpa de brillavalva
15581	guanteletes de brillavalva
15582	musleras de brillavalva
15583	hombreras de brillavalva
15584	escudo de brillavalva
15585	mandiletes pardoc
15586	flor de rapido crecimiento
15587	faja colaro
15588	cinturon con brazales de acero
15589	apisonadoras de determinacion ferrea
15590	pulseras de determinacion ferrea
15591	coraza de determinacion ferrea
15592	rodela de determinacion ferrea
15593	nimbo de determinacion ferrea
15594	capa de determinacion ferrea
15595	guantes de determinacion ferrea
15596	quijotes de determinacion ferrea
15597	sobrehombros de determinacion ferrea
15598	faja de determinacion ferrea
15599	grebas antiguas
15600	avambrazos antiguos
15601	pechera antigua
15602	corona antigua
15603	capa antigua
15604	defensor antiguo
15605	guanteletes antiguos
15606	cinturon antiguo
15607	musleras antiguas
15608	espaldares antiguos
15609	armadura de vinculo de huesos
15610	brazales de vinculo de huesos
15611	manteo de vinculo de huesos
15612	guanteletes de vinculo de huesos
15613	cinturon de vinculo de huesos
15614	escarpes de vinculo de huesos
15615	casco de vinculo de huesos
15616	quijotes de vinculo de huesos
15617	cubrehombros de vinculo de huesos
15618	escudo de pared de vinculo de huesos
15619	cinturon de malla de grifo
15620	pulseras de malla de grifo
15621	rodela de malla de grifo
15622	coraza de malla de grifo
15623	corona de malla de grifo
15624	capa de grifo
15625	guanteletes de malla de grifo
15626	grebas de malla de grifo
15627	musleras de malla de grifo
15628	espaldares de malla de grifo
15629	brazales formidables
15630	escarpes formidables
15631	pechera formidable
15632	manteo formidable
15633	blason formidable
15634	aro formidable
15635	guanteletes formidables
15636	cinturon formidable
15637	musleras formidables
15638	hombreras formidables
15639	brazales de pielferrea
15640	coraza de pielferrea
15641	cinturon de pielferrea
15642	grebas de pielferrea
15643	capa de pielferrea
15644	guanteletes de pielferrea
15645	casco de pielferrea
15646	musleras de pielferrea
15647	espaldares de pielferrea
15648	escudo de pielferrea
15649	brazales despiadados
15650	sobrevesta despiadada
15651	corona despiadada
15652	capa despiadada
15653	guanteletes despiadados
15654	cinturon despiadado
15655	musleras despiadadas
15656	cubrehombros despiadados
15657	escudo despiadado
15658	escarpes impenetrables
15659	ataduras impenetrables
15660	coraza impenetrable
15661	capa impenetrable
15662	guanteletes impenetrables
15663	cinturon impenetrable
15664	casco impenetrable
15665	musleras impenetrables
15666	espaldares impenetrables
15667	muro impenetrable
15668	brazales magnificos
15669	coraza magnifica
15670	casco magnifico
15671	capa magnifica
15672	guanteletes magnificos
15673	cinturon magnifico
15674	grebas magnificas
15675	guardia magnifico
15676	leotardos magnificos
15677	sobrehombros magnificos
15678	escarpes triunfantes
15679	brazales triunfantes
15680	pechera triunfante
15681	capa triunfante
15682	guanteletes triunfantes
15683	faja triunfante
15684	capacete triunfante
15685	quijotes triunfantes
15686	hombreras triunfantes
15687	escudo triunfante
15688	judias magicas
15689	anillo de comerciante
15690	collar de huesos de kodo
15691	pistolero shottie
15692	marcador de kodos
15693	sobrehombros grandiosos
15694	grebas despiadadas
15695	escudo circular con tachuelas
15696	escrito estropeado
15697	botas de cuatrero kodo
15698	bufas de rina
15699	paquete con envoltorio marron pequeno
15702	anillo de quimico
15703	guardapolvo de quimico
15704	medalla insignia de cazador
15705	espada crestamarea
15706	hoja de rastreador de caza
15707	fajin barnaleno
15708	guantes de cuero de anublo
15709	faja de forjaengranaje
15710	polvo de luna cenarion
15722	cantimplora de spraggle
15723	te con azucar
15724	patron brazales de escorpido gruesos
15725	patron guanteletes de cuero maligno
15726	patron coraza de dragontina verde
15727	patron jubon de escorpido grueso
15728	patron brazales de cuero maligno
15729	patron guantes quimericos
15730	patron coraza de dragontina roja
15731	patron guanteletes de cuero runico
15732	patron leotardos volcanicos
15733	patron leotardos de dragontina verde
15734	patron sobrehombros vivos
15735	patron sobrehombros plumahierro
15736	compuesto especial de smokey
15737	patron botas quimericas
15738	patron guanteletes de escorpido gruesos
15739	patron brazales de cuero runico
15740	patron botas de sable de hielo
15741	patron pantalones de embozo de tormenta
15742	patron arnes de oso de guerra
15743	patron cinturon de escorpido grueso
15744	patron cinta de cuero maligno
15745	patron cinturon de cuero runico
15746	patron leotardos quimericos
15747	patron leotardos de sable de hielo
15748	patron leotardos de escorpido gruesos
15749	patron coraza volcanica
15750	cetro de luz
15751	patron coraza de dragontina azul
15752	patron leotardos vivos
15753	patron armadura de embozo de tormenta
15754	patron prendas de lana de oso de guerra
15755	patron jubon quimerico
15756	patron cinta de cuero runico
15757	patron pantalones de cuero maligno
15758	patron guanteletes de demosaurio
15759	patron coraza de dragontina negra
15760	patron coraza plumahierro
15761	patron guantes de sable de hielo
15762	patron yelmo de escorpido grueso
15763	patron sobrehombros de dragontina azul
15764	patron sobrehombros de embozo de tormenta
15765	patron pantalones de cuero runico
15766	gema de la serpiente
15767	llave de hameya
15768	patron cinturon de cuero maligno
15769	patron capa de escamas de onyxia
15770	patron sobrehombros de dragontina negra
15771	patron coraza viva
15772	patron leotardos de demosaurio
15773	patron armadura de cuero maligno
15774	patron sobrehombros de escorpido gruesos
15775	patron sobrehombros volcanicos
15776	patron armadura de cuero runico
15777	patron sobrehombros de cuero runico
15778	yeti mecanico
15779	patron guerrera de sable de hielo
15780	patron coraza de escamas de onyxia
15781	patron leotardos de dragontina negra
15782	hoja de acechabestias
15783	daga cazabestias
15784	manto de brisa de cristal
15785	cabeza de zaeldarr
15786	chaleco pulso helecho
15787	camisote a rayas de sauce
15788	informe de vista eterna
15789	capa rio profundo
15790	estudios sobre la comunicacion con los espiritus
15791	fajin turquesa
15792	bufas de madera surcada
15793	un hueso roido
15794	taparrabos rasgado ogro
15795	guanteletes de bruma esmeralda
15796	brazales de espuma marina
15797	avambrazos fulgentes
15798	diente de ogro astillado
15799	medalla de honor heroico
15800	espada corta de intrepido
15801	espada corta valerosa
15802	botas de tela lunar
15803	libro de los ancestros
15804	manton color guinda
15805	rosa de penelope
15806	cancion de mirah
15807	ballesta ligera
15808	ballesta ligera refinada
15809	ballesta pesada
15810	lanza corta
15811	lanza pesada
15812	amito orquidea
15813	cinturon de oro
15814	destripador de hameya
15815	capa de hameya
15822	bufas sombradermas
15823	guanteletes de ladrillo de acero
15824	togas de astoria
15825	chaleco de calador
15826	balsamo animal curativo
15827	coraza de luna de jade
15842	muestrario de cima caligine vacia
15843	muestrario de cima caligine lleno
15844	muestra vacia de salto de fonroca
15845	muestrario del salto de fonroca lleno
15846	salero
15847	registro de quel thalas
15848	cajon de imanes fantasmales
15849	ectoplasma
15850	parche de pelaje de alaocaso
15851	hongo lunar
15852	cuerno de kodo
15853	segadora de viento
15854	esquirla danzante
15855	anillo de proteccion
15856	dije arcoluz
15857	sucesor aterramagos
15858	guantes viento libre
15859	faja de poste marino
15860	guardabrazos golpeguino
15861	botines piepresto
15862	cuchilla de carga
15863	cetro solemne
15864	brazales de condor
15865	rodela garrancla
15866	bolsa de remedio polvo de velo
15867	talisman prismatico
15868	orden del gran cruzado
15869	llave esqueleto de plata
15870	llave esqueleto dorada
15871	llave esqueleto de veraplata
15872	llave esqueleto de arcanita
15873	copa interminable de john andrajoso
15874	almeja blanda
15875	manzana podrida
15876	cofre de nathanos
15877	adorno de altar
15878	llave de plata masatormento
15879	garra de senor supremo ror
15880	cabeza de ramstein el empachador
15881	llave de oro de masatormento
15882	medio colgante de resistencia acuatica
15883	medio colgante de agilidad acuatica
15884	libro de entradas de augustus
15885	colgante del leon marino
15886	filacteria de timolain
15887	guarda heroica
15890	escudo soldado de caballeria
15891	escudo descomunal
15892	escudo de destripador
15893	rodela de prospector
15894	rodela erizacorteza
15895	rodela quemada
15902	una bolsa de sorpresas
15903	garra para diestros
15904	hojas para diestros
15905	nudillos de laton para diestros
15906	nudillos de laton para zurdos
15907	garra para la mano izquierda
15908	fusta de doma
15909	hojas para zurdos
15911	fusta de doma
15912	orbe de bucanero
15913	fusta de doma
15914	fusta de doma
15915	fusta de doma
15916	fusta de doma
15917	fusta de doma
15918	esfera de implorador
15919	fusta de doma
15920	fusta de doma
15921	fusta de doma
15922	fusta de doma
15923	fusta de doma
15924	carne de almeja blanda
15925	baculo de oficial
15926	orbe vinculahechizo
15927	esfera brillante
15928	vara de hilo de plata
15929	orbe cielo nocturno
15930	cetro imperial rojo
15931	estrella arcana
15932	jarra de discipulo
15933	rama simple
15934	baculo de sabio
15935	vara durable
15936	rama tejeocaso
15937	esfera invernal
15938	orbe mistico
15939	cetro de concejal
15940	cetro elegante
15941	centro de consejero mayor
15942	vara de maestro
15943	escudo imbuido
15944	orbe ancestral
15945	baculo runico
15946	esfera de mistico
15947	estrella sanguina
15962	vara de satiro
15963	rama de pano de piedra
15964	estrella sedarena
15965	orbe cazavientos
15966	orbe de embozo de veneno
15967	estrella de altonato
15968	esfera elunarita
15969	orbe perlado
15970	rama nativa
15971	vara aborigen
15972	jarra de ritual
15973	estrella de vigia
15974	vara pagana
15975	cetro clamalluvias
15976	rama piel de cardo
15977	orbe vital
15978	vara de geomantico
15979	baculo de seda de ascuas
15980	orbe niebla negra
15981	esfera lunar
15982	vara de tejido de sangre
15983	cetro de gaia
15984	cetro opulento
15985	rama aracnida
15986	estrella de tirahuesos
15987	orbe astral
15988	orbe rutilante
15989	vara eterna
15990	escudo duradero
15991	escudo de lider de guerra
15992	polvora densa
15993	granada de torio
15994	trasto de torio
15995	rifle de torio
15996	sapo mecanico casi vivo
15997	proyectiles de torio
15998	nota de lewis
15999	gafas de poder con hechizos xtremo plus
16000	tubo de torio
16001	insignia iv 7 fredo
16002	insignia iv 7 turyen
16003	insignia iv 7 rutger
16004	rifle hierro negro
16005	bomba hierro negro
16006	conversor de arcanita delicado
16007	rifle de arcanita impecable
16008	gafas de maestro ingeniero
16009	modulador de amplificacion de voz
16022	dragonizo de arcanita
16023	muneco diana magistral
16026	pvp plate helm alliance
16027	pvp plate breastplate alliance
16028	pvp plate legplates alliance
16029	pvp plate gauntlets alliance
16030	pvp plate boots alliance
16031	pvp plate shoulder alliance
16033	pvp plate wrist alliance
16034	pvp plate cloak alliance
16035	pvp cloth helm horde
16036	pvp cloth robe horde
16037	pvp cloth legs horde
16038	pvp cloth shoulder horde
16039	filoson ta kierthan
16040	bomba arcana
16041	esquema granada de torio
16042	esquema trasto de torio
16043	esquema rifle de torio
16044	esquema sapo mecanico casi vivo
16045	esquema gafas de poder con hechizos xtremo plus
16046	esquema muneco diana magistral
16047	esquema tubo de torio
16048	esquema rifle hierro negro
16049	esquema bomba hierro negro
16050	esquema conversor de arcanita delicado
16051	esquema proyectiles de torio
16052	esquema modulador de amplificacion de voz
16053	esquema gafas de maestro ingeniero
16054	esquema dragonizo de arcanita
16055	esquema bomba arcana
16056	esquema rifle de arcanita impecable
16057	morral de expedicionario
16058	sello de vadin
16059	camisa marron comun
16060	camisa blanca comun
16072	libro de cocina para expertos
16073	libro de cocina de artesano
16082	pesca de artesano el truco de los senuelos
16083	pesca para expertos la lubina y tu
16084	primeros auxilios para expertos entre vendas
16085	artesano de primeros auxilios curate tu mismo
16110	receta tortilla gigante
16111	receta chili de cangrejo especiado
16112	manual venda de seda gruesa
16113	manual venda de tejido magico
16114	porra de supervisor
16115	cajon de osric
16166	sopa de judias
16167	obsequio versicolor
16168	melocoton del cielo
16169	pastel de arroz salvaje
16170	mandu al vapor
16171	shinsollo
16189	dorso de la carta de maggran
16190	restos de desgarradora furia sangrienta
16191	espejo ornamentado
16192	colmillo de besseleth
16202	esencia eterna inferior
16203	esencia eterna superior
16204	polvo de ilusion
16205	semilla de gaia
16206	vara de arcanita
16207	vara runica de arcanita
16208	semillas de gaia encantadas
16209	orden de podrig
16210	cajon de gordok
16214	formula encantar brazales intelecto superior
16215	formula encantar botas aguante superior
16216	formula encantar capa resistencia superior
16217	formula encantar escudo aguante superior
16218	formula encantar brazales espiritu excelente
16219	formula encantar guantes agilidad superior
16220	formula encantar botas espiritu
16221	formula encantar pechera salud sublime
16222	formula encantar escudo espiritu excelente
16223	formula encantar arma escalofrio gelido
16224	formula encantar capa defensa excelente
16242	formula encantar pechera mana sublime
16243	formula vara runica de arcanita
16244	formula encantar guantes fuerza superior
16245	formula encantar botas agilidad superior
16246	formula encantar brazales fuerza excelente
16247	formula encantar arma de 2m impacto excelente
16248	formula encantar arma profano
16249	formula encantar arma de 2m intelecto sublime
16250	formula encantar arma golpes excelentes
16251	formula encantar brazales aguante excelente
16252	formula encantar arma cruzado
16253	formula encantar pechera estadisticas superiores
16254	formula encantar arma robo de vida
16255	formula encantar arma de 2m espiritu sublime
16262	coleccion de nessa
16263	respuesta de laird
16282	fardo de pellejos
16283	articulos de cuero de ahanu
16302	grimorio descarga de fuego rango 2
16303	pata de ursangous
16304	cabeza de shadumbra
16305	garfa de garrafilada
16306	carne de zargh
16307	carta de gryshka
16308	palanqueta de crestanorte
16309	amuleto pirodraco
16310	lista de brock
16311	picos honorarios
16312	incendritas
16313	cofre de felix
16314	cubo de tornillos de felix
16315	manteo de alferez
16316	grimorio descarga de fuego rango 3
16317	grimorio descarga de fuego rango 4
16318	grimorio descarga de fuego rango 5
16319	grimorio descarga de fuego rango 6
16320	grimorio descarga de fuego rango 7
16321	grimorio pacto de sangre rango 1
16322	grimorio pacto de sangre rango 2
16323	grimorio pacto de sangre rango 3
16324	grimorio pacto de sangre rango 4
16325	grimorio pacto de sangre rango 5
16326	grimorio escudo de fuego rango 1
16327	grimorio escudo de fuego rango 2
16328	grimorio escudo de fuego rango 3
16329	grimorio escudo de fuego rango 4
16330	grimorio escudo de fuego rango 5
16331	grimorio cambio de fase
16332	pico de thazz ril
16333	restos de samuel
16335	insignia de capataz primero
16336	manteo de alferez
16337	manteo de alferez
16338	corcel de teniente caballero
16339	corcel de comandante
16341	capa de sargento
16342	manteo de sargento
16343	montura de guardia de sangre
16344	montura de teniente general
16345	hoja de gran senor de la guerra
16346	grimorio tormento rango 2
16347	grimorio tormento rango 3
16348	grimorio tormento rango 4
16349	grimorio tormento rango 5
16350	grimorio tormento rango 6
16351	grimorio sacrificio rango 1
16352	grimorio sacrificio rango 2
16353	grimorio sacrificio rango 3
16354	grimorio sacrificio rango 4
16355	grimorio sacrificio rango 5
16356	grimorio sacrificio rango 6
16357	grimorio consumir sombras rango 1
16358	grimorio consumir sombras rango 2
16359	grimorio consumir sombras rango 3
16360	grimorio consumir sombras rango 4
16361	grimorio consumir sombras rango 5
16362	grimorio consumir sombras rango 6
16363	grimorio sufrimiento rango 1
16364	grimorio sufrimiento rango 2
16365	grimorio sufrimiento rango 3
16366	grimorio sufrimiento rango 4
16367	fajin de seda de capitan caballero
16368	grimorio latigazo doloroso rango 2
16369	botas de seda de teniente caballero
16370	punos de seda de capitan caballero
16371	grimorio latigazo doloroso rango 3
16372	grimorio latigazo doloroso rango 4
16373	grimorio latigazo doloroso rango 5
16374	grimorio latigazo doloroso rango 6
16375	grimorio beso calmante rango 1
16376	grimorio beso calmante rango 2
16377	grimorio beso calmante rango 3
16378	grimorio beso calmante rango 4
16379	grimorio seduccion
16380	grimorio invisibilidad inferior
16381	grimorio devorar magia rango 2
16382	grimorio devorar magia rango 3
16383	grimorio devorar magia rango 4
16384	grimorio sangre macula rango 1
16385	grimorio sangre macula rango 2
16386	grimorio sangre macula rango 3
16387	grimorio sangre macula rango 4
16388	grimorio bloqueo de hechizo rango 1
16389	grimorio bloqueo de hechizo rango 2
16390	grimorio paranoia
16391	guantes de seda de teniente caballero
16392	botas de cuero de teniente caballero
16393	borceguies de pellejo de dragon de teniente caballero
16394	brazales de cuero de capitan caballero
16395	braquiales de pellejo de dragon de capitan caballero
16396	guanteletes de cuero de teniente caballero
16397	guantes de pellejo de dragon de teniente caballero
16398	cinturon de cuero de capitan caballero
16399	faja de pellejo de dragon de capitan caballero
16400	faja de anillas de capitan caballero
16401	botas de anillas de teniente caballero
16402	guardamunecas de anillas de capitan caballero
16403	guanteletes de anillas de teniente caballero
16404	guardamunecas de placas de capitan caballero
16405	botas de placas de teniente caballero
16406	guanteletes de placas de teniente caballero
16407	faja de placas de capitan caballero
16408	globo de agua contaminada
16409	escarpes de laminas de teniente caballero
16410	guanteletes de laminas de teniente caballero
16411	cincho de laminas de capitan caballero
16412	braquiales de laminas de capitan caballero
16413	vestimenta de seda de capitan caballero
16414	leotardos de seda de capitan caballero
16415	bufas de seda de teniente coronel
16416	corona de teniente coronel
16417	armadura de cuero de capitan caballero
16418	velo de cuero de teniente coronel
16419	musleras de cuero de capitan caballero
16420	bufas de cuero de teniente coronel
16421	guerrera de pellejo de dragon de capitan caballero
16422	leotardos de pellejo de dragon de capitan caballero
16423	cubrehombros de pellejo de dragon de teniente coronel
16424	embozo de pellejo de dragon de teniente coronel
16425	camisote de anillas de capitan caballero
16426	leotardos de anillas de capitan caballero
16427	espaldares de anillas de teniente coronel
16428	casco de anillas de teniente coronel
16429	yelmo de placas de teniente coronel
16430	coselete de placas de capitan caballero
16431	leotardos de placas de capitan caballero
16432	espaldares de placas de teniente coronel
16433	coraza de laminas de capitan caballero
16434	protegecabezas de laminas de teniente coronel
16435	leotardos de laminas de capitan caballero
16436	sobrehombros de laminas de teniente coronel
16437	borceguies de seda de mariscal
16438	brazales de seda de mariscal
16439	fajin de seda de mariscal
16440	guantes de seda de mariscal
16441	nimbo de mariscal de campo
16442	leotardos de seda de mariscal
16443	vestimentas de seda de mariscal de campo
16444	bufas de seda de mariscal de campo
16445	brazales de pellejo de dragon de mariscal
16446	guardapies de cuero de mariscal
16447	guardarrenes de pellejo de dragon de mariscal
16448	guanteletes de pellejo de dragon de mariscal
16449	bufas de pellejo de dragon de mariscal de campo
16450	musleras de pellejo de dragon de mariscal
16451	casco de pellejo de dragon de mariscal de campo
16452	coraza de pellejo de dragon de mariscal de campo
16453	pechera de cuero de mariscal de campo
16454	luas de cuero de mariscal
16455	mascara de cuero de mariscal de campo
16456	leotardos de cuero de mariscal
16457	cubrehombros de cuero de mariscal de campo
16458	cincho de cuero de mariscal
16459	botas de pellejo de dragon de mariscal
16460	braquiales de cuero de mariscal
16461	brazales de anillas de mariscal
16462	botas de anillas de mariscal
16463	mandiletes de anillas de mariscal
16464	faja de anillas de mariscal
16465	yelmo de anillas de mariscal de campo
16466	coraza de anillas de mariscal de campo
16467	musleras de anillas de mariscal
16468	bufas de anillas de mariscal de campo
16469	guardabrazos de laminas de mariscal
16470	cinturon de laminas de mariscal
16471	guantes de laminas de mariscal
16472	botas de laminas de mariscal
16473	peto de laminas de mariscal de campo
16474	visera de laminas de mariscal de campo
16475	quijotes de laminas de mariscal
16476	espaldares de laminas de mariscal de campo
16477	armadura de placas de mariscal de campo
16478	yelmo de placas de mariscal de campo
16479	musleras de placas de mariscal
16480	guardahombros de placas de mariscal de campo
16481	brazales de placas de mariscal
16482	faja de placas de mariscal
16483	botas de placas de mariscal
16484	guanteletes de placas de mariscal
16485	borceguies de seda de guardia de sangre
16486	punos de seda de gran capataz
16487	guantes de seda de guardia de sangre
16488	cinturon de seda de legionario
16489	caperuza de seda de campeon
16490	pantalones de seda de legionario
16491	togas de seda de legionario
16492	hombreras de seda de campeon
16493	guardabrazos de pellejo de dragon de legionario
16494	botas de pellejo de dragon de guardia de sangre
16495	pretina de pellejo de dragon de legionario
16496	guanteletes de pellejo de dragon de guardia de sangre
16497	guardabrazos de cuero de gran capataz
16498	botines de cuero de guardia de sangre
16499	abrazaderas de cuero de guardia de sangre
16500	faja de cuero de legionario
16501	bufas de pellejo de dragon de campeon
16502	calzas de pellejo de dragon de legionario
16503	yelmo de pellejo de dragon de campeon
16504	coraza de pellejo de dragon de legionario
16505	camisote de cuero de legionario
16506	protegecabezas de cuero de campeon
16507	manto de cuero de campeon
16508	leotardos de cuero de legionario
16509	botas de placas de guardia de sangre
16510	guantes de placas de guardia de sangre
16511	cincho de placas de legionario
16512	brazales de placas del legionario
16513	armadura de placas de legionario
16514	protegecabezas de placas de campeon
16515	musleras de placas de legionario
16516	espaldares de placas de campeon
16517	brazales de anillas de legionario
16518	botos de malla de guardia de sangre
16519	mandiletes de malla de guardia de sangre
16520	cincho de malla de legionario
16521	yelmo de malla de campeon
16522	pechera de malla de legionario
16523	leotardos de malla de legionario
16524	sobrehombros de malla de campeon
16525	coraza de anillas de legionario
16526	protegecabezas de anillas de campeon
16527	leotardos de anillas de legionario
16528	espaldares de anillas de campeon
16529	faja de anillas de legionario
16530	guanteletes de anillas de guardia de sangre
16531	botas de anillas de guardia de sangre
16532	guardamunecas de malla de gran capataz
16533	capucha de seda de senor de la guerra
16534	calzas de seda de general
16535	vestimenta de seda de senor de la guerra
16536	amito de seda de senor de la guerra
16537	fajin de seda de general
16538	punos de seda de general
16539	botas de seda de general
16540	manoplas de seda de general
16541	armadura de placas de senor de la guerra
16542	celada de placas de senor de la guerra
16543	leotardos de placas de general
16544	sobrehombros de placas de senor de la guerra
16545	botas de placas de general
16546	guardabrazos de placas de general
16547	faja de placas de general
16548	guanteletes de placas de general
16549	camisote de pellejo de dragon de senor de la guerra
16550	casco de pellejo de dragon de senor de la guerra
16551	cubrehombros de pellejo de dragon de senor de la guerra
16552	leotardos de pellejo de dragon de general
16553	brazales de pellejo de dragon de general
16554	botas de pellejo de dragon de general
16555	guantes de pellejo de dragon de general
16556	cinturon de pellejo de dragon de general
16557	faja de cuero de general
16558	botines de cuero de general
16559	braquiales de cuero de general
16560	mitones de cuero de general
16561	yelmo de cuero de senor de la guerra
16562	bufas de cuero de senor de la guerra
16563	coraza de cuero de senor de la guerra
16564	musleras de cuero de general
16565	pechera de anillas de senor de la guerra
16566	casco de anillas de senor de la guerra
16567	musleras de anillas de general
16568	sobrehombros de anillas de senor de la guerra
16569	escarpes de anillas de general
16570	guardamunecas de anillas de general
16571	guantes de anillas de general
16572	faja de anillas de general
16573	botas de malla de general
16574	guanteletes de malla de general
16575	pretina de malla de general
16576	brazales de malla de general
16577	armadura de malla de senor de la guerra
16578	yelmo de senor de la guerra
16579	leotardos de malla de general
16580	bufas de malla de senor de la guerra
16581	cristal de resonita
16583	figurilla demoniaca
16602	talisman trol
16603	cristal de resonita encantado
16604	togas lunares de elune
16605	togas de la luz de fraile
16606	togas de maleficio juju
16607	togas de sacrificio de acolito
16608	cinturon acuario
16622	lanzaespinas
16623	medallon opalino
16642	manual de instrucciones de trituradora capitulo 1
16643	manual de instrucciones de trituradora capitulo 2
16644	manual de instrucciones de trituradora capitulo 3
16645	manual de instrucciones de trituradora pagina 1
16646	manual de instrucciones de trituradora pagina 2
16647	manual de instrucciones de trituradora pagina 3
16648	manual de instrucciones de trituradora pagina 4
16649	manual de instrucciones de trituradora pagina 5
16650	manual de instrucciones de trituradora pagina 6
16651	manual de instrucciones de trituradora pagina 7
16652	manual de instrucciones de trituradora pagina 8
16653	manual de instrucciones de trituradora pagina 9
16654	manual de instrucciones de trituradora pagina 10
16655	manual de instrucciones de trituradora pagina 11
16656	manual de instrucciones de trituradora pagina 12
16658	capa de cazador salvaje
16659	cinturon de equilibrista
16660	escudo lodo acumulado
16661	manteo de sauce suave
16662	fragmento del ojo del dragon
16663	sangre de dragon negro campeon
16664	brazales ornamentados
16665	escrito sobre disparo tranquilizante
16666	jubon de elementos
16667	almofar de elementos
16668	falda de elementos
16669	espaldares de elementos
16670	botas de elementos
16671	ataduras de elementos
16672	guanteletes de elementos
16673	cordon de elementos
16674	guerrera de acechabestias
16675	botas de acechabestias
16676	guantes de acechabestias
16677	almete de acechabestias
16678	pantalones de acechabestias
16679	manto de acechabestias
16680	cinturon de acechabestias
16681	ataduras de acechabestias
16682	botas de magister
16683	ataduras de magister
16684	guantes de magister
16685	cinturon de magister
16686	corona de magister
16687	leotardos de magister
16688	togas de magister
16689	manto de magister
16690	toga de devoto
16691	sandalias de devoto
16692	guantes de devoto
16693	corona de devoto
16694	saya de devoto
16695	manto de devoto
16696	cinturon de devoto
16697	brazales de devoto
16698	mascara caligine
16699	leotardos caligine
16700	toga caligine
16701	manto caligine
16702	cinturon caligine
16703	brazales caligine
16704	sandalias caligine
16705	brazaletes caligine
16706	jubon corazon salvaje
16707	almete arte sombrio
16708	bufas arte sombrio
16709	pantalones arte sombrio
16710	brazales arte sombrio
16711	botas arte sombrio
16712	guantes arte sombrio
16713	cinturon arte sombrio
16714	brazales corazon salvaje
16715	botas corazon salvaje
16716	cinturon corazon salvaje
16717	guantes corazon salvaje
16718	bufas corazon salvaje
16719	falda corazon salvaje
16720	capucha corazon salvaje
16721	guerrera arte sombrio
16722	brazales forjaluz
16723	cinturon forjaluz
16724	guanteletes forjaluz
16725	botas forjaluz
16726	coraza forjaluz
16727	yelmo forjaluz
16728	quijotes forjaluz
16729	bufas forjaluz
16730	coraza de valor
16731	yelmo de valor
16732	quijotes de valor
16733	bufas de valor
16734	botas de valor
16735	brazales de valor
16736	cinturon de valor
16737	guanteletes de valor
16738	guantes de semilla marchita
16739	manto de madera basta
16740	guantes de manejo de trituradora
16741	manijas de aceite
16742	espadas dentadas grito de guerra
16743	cuerda
16744	aceite grito de guerra
16745	envio de hachas de los grito de guerra
16746	informe grito de guerra
16747	candado roto
16748	forro acolchado
16762	nucleo de las profundidades
16763	novedades de corredor grito de guerra
16764	novedades de explorador grito de guerra
16765	novedades de escolta grito de guerra
16766	sopa de almejas de minahonda
16767	receta sopa de almejas de minahonda
16768	faltriquera de medicinas furbolg
16769	totem de medicina furbolg
16782	globo de agua extrano
16783	fardo de informes
16784	zafiro de aku mai
16786	ojo de dragauro negro
16787	amuleto de subversion draconica
16788	timon del capitan masatormento
16789	cana del timon del capitan masatormento
16790	nota mojada
16791	punos corrientes de seda
16792	garrote gigante
16793	sobrehombros arcometal
16794	guardamunecas para empunaduras de acero
16795	corona arcanista
16796	leotardos arcanistas
16797	manto arcanista
16798	togas arcanistas
16799	ataduras arcanistas
16800	botas arcanistas
16801	guantes arcanistas
16802	cinturon de arcanista
16803	zapatillas corazon vil
16804	brazales corazon vil
16805	guantes corazon vil
16806	cinturon corazon vil
16807	hombreras corazon vil
16808	cuernos corazon vil
16809	togas corazon vil
16810	pantalones corazon vil
16811	botas de profecia
16812	guantes de profecia
16813	aro de profecia
16814	pantalones de profecia
16815	togas de profecia
16816	manto de profecia
16817	faja de profecia
16818	cinturon viento abisal
16819	avambrazos de profecia
16820	pechera de destripador nocturno
16821	casquete de destripador nocturno
16822	pantalones de destripador nocturno
16823	hombreras de destripador nocturno
16824	botas de destripador nocturno
16825	pulseras de destripador nocturno
16826	guantes de destripador nocturno
16827	cinturon de destripador nocturno
16828	cinturon cenarion
16829	botas cenarion
16830	brazales cenarion
16831	guantes cenarion
16832	bufas colmillo de sangre
16833	vestimentas cenarion
16834	yelmo cenarion
16835	leotardos cenarion
16836	bufas cenarion
16837	botas furia terrenal
16838	cinturon furia terrenal
16839	guanteletes furia terrenal
16840	brazales furia terrenal
16841	vestimentas furia terrenal
16842	casco furia terrenal
16843	musleras furia terrenal
16844	cubrehombros furia terrenal
16845	coraza de acechagigantes
16846	casco de acechagigantes
16847	leotardos de acechagigantes
16848	cubrehombros de acechagigantes
16849	botas de acechagigantes
16850	brazales de acechagigantes
16851	cinturon de acechagigantes
16852	guantes de acechagigantes
16853	coselete de justiciero
16854	yelmo de justiciero
16855	quijotes de justiciero
16856	bufas de justiciero
16857	brazales de justiciero
16858	cinturon de justiciero
16859	botas de justiciero
16860	guanteletes de justiciero
16861	brazales de poderio
16862	escarpes de poderio
16863	guanteletes de poderio
16864	cinturon de poderio
16865	coraza de poderio
16866	yelmo de poderio
16867	quijotes de poderio
16868	espaldares de poderio
16869	el craneo de aruspice
16870	el craneo de somnus
16871	el craneo de chronalis
16872	el craneo de axtroz
16873	guantes de pelaje trenzado
16882	caja de trastos maltrecha
16883	caja de trastos desgastada
16884	caja de trastos robusta
16885	caja de trastos pesada
16886	sable de forajido
16887	dedo de bruja
16888	amuleto pirodraco apagado
16889	baston de apoyo pulido
16890	alfanje de metal de pizarra
16891	espada corta de arcilla
16892	piedra de alma inferior
16893	piedra de alma
16894	vara de cristal claro
16895	piedra de alma superior
16896	piedra de alma sublime
16897	coselete de tempestira
16898	botas de tempestira
16899	manoplas de tempestira
16900	casquete de tempestira
16901	musleras de tempestira
16902	espaldares de tempestira
16903	cinturon de tempestira
16904	brazales de tempestira
16905	pechera colmillo de sangre
16906	botas colmillo de sangre
16907	guantes colmillo de sangre
16908	caperuza colmillo de sangre
16909	pantalones colmillo de sangre
16910	cinturon colmillo de sangre
16911	brazales colmillo de sangre
16912	botas viento abisal
16913	guantes viento abisal
16914	corona viento abisal
16915	pantalones viento abisal
16916	togas viento abisal
16917	manto viento abisal
16918	ataduras viento abisal
16919	botas de trascendencia
16920	manoplas de trascendencia
16921	halo de trascendencia
16922	leotardos de trascendencia
16923	togas de trascendencia
16924	espaldares de trascendencia
16925	cinturon de trascendencia
16926	ataduras de trascendencia
16927	botas de la nemesis
16928	guantes de la nemesis
16929	capacete de la nemesis
16930	leotardos de la nemesis
16931	togas de la nemesis
16932	bufas de la nemesis
16933	cinturon de la nemesis
16934	brazales de la nemesis
16935	brazales de acechadragon
16936	cinturon de acechadragon
16937	bufas de acechadragon
16938	musleras de acechadragon
16939	yelmo de acechadragon
16940	guanteletes de acechadragon
16941	grebas de acechadragon
16942	coraza de acechadragon
16943	brazales de diez tormentas
16944	cinturon de diez tormentas
16945	cubrehombros de diez tormentas
16946	quijotes de diez tormentas
16947	casco de diez tormentas
16948	guanteletes de diez tormentas
16949	grebas de diez tormentas
16950	coraza de diez tormentas
16951	ataduras de sentencia
16952	cinturon de sentencia
16953	bufas de sentencia
16954	quijotes de sentencia
16955	corona de sentencia
16956	guanteletes de sentencia
16957	escarpes de sentencia
16958	coraza de sentencia
16959	pulseras de colera
16960	pretina de colera
16961	espaldares de colera
16962	quijotes de colera
16963	yelmo de colera
16964	guanteletes de colera
16965	escarpes de colera
16966	coraza de colera
16967	ahi de feralas
16968	artillero sar theris
16969	latipinia azul de la costa salvaje
16970	mahi mahi juncobruma
16971	sorpresa de almejate
16972	estandarte de karang
16973	vial de agua funesta
16974	vial de agua vacio
16975	fajin grito de guerra
16976	totem de murgut
16977	botas grito de guerra
16978	guanteletes grito de guerra
16979	guantes bengala del nucleo
16980	manto bengala del nucleo
16981	brazales de barba de buho
16982	botas de can del nucleo
16983	yelmo de arrabio
16984	botas de dragontina negra
16985	botas del hijo del viento
16986	guantes cumbre de arena
16987	cinturon de estridador
16988	sobrehombros de anillas igneas
16989	faja de anillas igneas
16990	capa de duendecillo
16991	venda de seleccion
16992	lanzaexplosivos de smokey
16993	pistola de fuego de smokey
16994	guantes alaocaso
16995	manto alaocaso
16996	arco de madera gore
16997	habitante de tempestira
16998	protector sacro
16999	sello real de alexis
17000	sortija de la aparicion
17001	circulo elemental
17002	escupeicor
17003	martillo calapetra
17004	guia de sara
17005	guerrera de guardia grosero
17006	musleras de cobalto
17007	guanteletes de creapiedras
17008	pergamino pequeno
17009	cabeza del embajador malcin
17010	nucleo igneo
17011	nucleo de lava
17012	cuero del nucleo
17013	leotardos hierro negro
17014	brazales hierro negro
17015	espetadora hierro negro
17016	destructora hierro negro
17017	patron manto bengala del nucleo
17018	patron guantes bengala del nucleo
17019	polvo arcano
17020	particulas arcanas
17021	frutos silvestres
17022	patron botas de can del nucleo
17023	patron yelmo de arrabio
17024	raiz salvaje
17025	patron botas de dragontina negra
17026	raiz de espina salvaje
17027	vela con aroma
17028	vela sagrada
17029	vela sacra
17030	ankh
17031	runa de teletransporte
17032	runa de portales
17033	simbolo de divinidad
17034	semillas de arce
17035	semilla tuercespina
17036	semilla de fresno
17037	semillas de carpinus
17038	semilla de maderaferrea
17039	partecalaveras
17042	escupeunas
17043	toga de zelote
17044	voluntad del martir
17045	sangre del martir
17046	hoja de entranas
17047	amito luminiscente
17048	ron rumsey
17049	diseno faja de anillas igneas
17050	togas imperiales de chan
17051	diseno brazales hierro negro
17052	diseno leotardos hierro negro
17053	diseno sobrehombros de anillas igneas
17054	piedad de joonho
17055	machacachanguk
17056	pluma ligera
17057	escamas de pez lustrosas
17058	aceite de pescado
17059	diseno espetadora hierro negro
17060	diseno destructora hierro negro
17061	sombra de juno
17062	receta trucha cabeza de mitril
17063	sortija de accuria
17064	fragmento de la escama
17065	medallon del poderio ferreo
17066	disco de horadador
17067	grimorio piedra angular antigua
17068	libramorte
17069	marca de asediador
17070	colmillo de los misticos
17071	destripadora
17072	lanzador tiroexplosion
17073	sacudetierra
17074	tenebrosa
17075	vis kag el flebotomista
17076	filo del espetahuesos
17077	aplastador carmesi
17078	manton de sapphiron
17082	fragmento de la llama
17102	embozo de la niebla envolvente
17103	hoja magica de cantoazur
17104	segadora espinal
17105	martillo de piedra de aura
17106	defensor de malistar
17107	manteo de sangre de dragon
17108	marca de desvio
17109	gargantilla de iluminacion
17110	sello del archimago
17111	medallon furia abrasadora
17112	demoledor empireo
17113	guardian del sello ambar
17114	trozo de filacteria de araj
17115	muestra de ardilla
17116	muestra de ardilla
17117	flauta cazarratas
17118	envase de carne misteriosa
17119	kebab de rata del subterraneo
17124	emblema de la hermandad
17125	sello de ravenholdt
17126	carta elegante
17142	fragmento del rapinador
17182	sulfuras mano de ragnaros
17183	rodela abollada
17184	escudo pequeno
17185	rodela redonda
17186	tarja pequena
17187	rodela a rayas
17188	rodela ensortijada
17189	rodela de metal
17190	rodela ornamentada
17191	cetro de celebras
17192	tarja reforzada
17193	martillo de sulfuron
17194	especias festivas
17195	muerdago falso
17196	licor de fiestas
17197	galleta de jengibre
17198	ponche de huevo
17199	ponche de huevo estropeado
17200	receta galleta de jengibre
17201	receta ponche de huevo
17202	bola de nieve
17203	lingote de sulfuron
17204	ojo de sulfuras
17222	salchicha de arana
17223	tronadora
17224	mira de vision
17242	llave del cofre de salem
17262	llave de james
17302	obsequio festivo con lazo azul
17303	papel para envolver con lazo azul
17304	papel para envolver con lazos verdes
17305	obsequio festivo con lazo verde
17306	sangre de soldado pico tormenta
17307	papel de envolver con lazos morados
17308	obsequio festivo con lazo morado
17309	brazales discordantes
17310	aspecto de neptulon
17322	ojo del brasadivino
17323	senal de mulverick
17324	senal de guse
17325	senal de jeztor
17326	carne de soldado pico tormenta
17327	carne de teniente pico tormenta
17328	carne de comandante pico tormenta
17329	mano de lucifron
17330	mano de sulfuron
17331	mano de gehennas
17332	mano de shazzrah
17333	quintaesencia de agua
17344	cana de caramelo
17345	baba de silitido
17346	objeto silitido taraceado
17347	controlador de miembros de la hermandad murp
17348	jarabe de sanacion sublime
17349	jarabe de sanacion excelente
17351	jarabe de mana sublime
17352	jarabe de mana excelente
17353	ordenes de asalto pico tormenta
17354	el ojo que todo lo ve del maestro ryson
17355	carta de rabine
17362	senal de ryson
17363	senal de ryson
17364	mira de vision
17384	unidad trituradora portatil de zinfizzlex
17402	cerveza del padre invierno
17403	licor burbujeante de bonvapor
17404	cuenco de chocolate caliente
17405	te de jardin verde
17406	rueda de queso de vacaciones
17407	pastel de carne casero de graccu
17408	ternera picante
17409	trozo de cristal taraceado
17410	unidad trituradora portatil de zinfizzlex
17411	sierra de vapor
17413	codice rezo de entereza
17414	codice rezo de entereza ii
17422	trocitos de armadura
17423	cristal de tormenta
17442	ordenes de asalto lobo gelido
17502	medalla de soldado lobo gelido
17503	medalla de teniente lobo gelido
17504	medalla de comandante lobo gelido
17505	senal de ichman
17506	senal de vipore
17507	senal de slidore
17508	rodela piedra de fuerza
17522	suministros de ferrohondo
17523	manton de smokey
17542	suministros de dentefrio
17562	botas de tejido de tinieblas de teniente caballero
17563	brazales de tejido de tinieblas de capitan caballero
17564	guantes de tejido de tinieblas de teniente caballero
17565	cinturon de tejido de tinieblas de capitan caballero
17566	protegecabezas de teniente coronel
17567	leotardos de tejido de tinieblas de capitan caballero
17568	toga de tejido de tinieblas de capitan caballero
17569	manto de tejido de tinieblas de teniente coronel
17570	caperuza de tejido de tinieblas de campeon
17571	leotardos de tejido de tinieblas de legionario
17572	toga de tejido de tinieblas de legionario
17573	sobrehombros de tejido de tinieblas de campeon
17574	cinturon de tejido de tinieblas de legionario
17575	brazales de tejido de tinieblas de legionario
17576	botas de tejido de tinieblas de guardia de sangre
17577	guantes de tejido de tinieblas de guardia de sangre
17578	corona de mariscal de campo
17579	leotardos de tejido de tinieblas de mariscal
17580	sobrehombros de tejido de tinieblas de mariscal de campo
17581	toga de tejido de tinieblas de mariscal de campo
17582	punos de tejido de tinieblas de mariscal
17583	botas de tejido de tinieblas de mariscal
17584	guantes de tejido de tinieblas de mariscal
17585	fajin de tejido de tinieblas de mariscal
17586	botas de tejido de tinieblas de general
17587	brazales de tejido de tinieblas de general
17588	guantes de tejido de tinieblas de general
17589	cinturon de tejido de tinieblas de general
17590	manto de tejido de tinieblas de senor de la guerra
17591	caperuza de tejido de tinieblas de senor de la guerra
17592	toga de tejido de tinieblas de senor de la guerra
17593	pantalones de tejido de tinieblas de general
17594	botas de saten de teniente caballero
17595	punos de saten de capitan caballero
17596	guantes de saten de teniente caballero
17597	cordon de saten de capitan caballero
17598	diadema de teniente coronel
17599	leotardos de saten de capitan caballero
17600	togas de saten de capitan caballero
17601	amito de saten de teniente coronel
17602	ornato de mariscal de campo
17603	pantalones de saten de mariscal
17604	manto de saten de mariscal de campo
17605	vestimentas de saten de mariscal de campo
17606	brazales de saten de mariscal
17607	botas de saten de mariscal
17608	guantes de saten de mariscal
17609	fajin de saten de mariscal
17610	capucha de saten de campeon
17611	calzas de saten de legionario
17612	vestimentas de saten de legionario
17613	hombreras de saten de campeon
17614	fajin de saten de legionario
17615	punos de saten de legionario
17616	botas de saten de guardia de sangre
17617	guantes de saten de guardia de sangre
17618	botas de saten de general
17619	brazales de saten de general
17620	guantes de saten de general
17621	cincho de saten de general
17622	manto de saten de senor de la guerra
17623	capucha de saten de senor de la guerra
17624	togas de saten de senor de la guerra
17625	leotardos de saten de general
17626	bozal lobo gelido
17642	pellejo de carnero de alterac
17643	pellejo lobo gelido
17662	dulces robados
17682	libro don de lo salvaje
17683	libro don de lo salvaje ii
17684	tallas de cristal teradrico
17685	muestra de pastos de bosquehumeante
17686	arco de maestro cazador
17687	rifle de maestro cazador
17688	botas de la selva
17689	collera de entrenamiento pico tormenta
17690	insignia lobo gelido rango 1
17691	insignia pico tormenta rango 1
17692	anillo de cuerno
17693	vial ceruleo cubierto
17694	sortija del puno
17695	manto de castano
17696	vial ceruleo lleno
17702	vara de celebras
17703	diamante de celebras
17704	filo del invierno
17705	zumbaespada
17706	diseno filo del invierno
17707	fragmento de gemas
17708	elixir de poder de escarcha
17709	receta elixir de poder de escarcha
17710	puntilla de calcinita
17711	leotardos de crestarroca elemental
17712	disfraz completo del festival de invierno
17713	anillo de piedra negra
17714	brazales de la princesa de piedra
17715	ojo de theradras
17716	senor de las nieves 9000
17717	rifle megatiro
17718	rodela hipertecnica de gizlock
17719	espada focal de inventor
17720	esquema senor de las nieves 9000
17721	guantes del padre invierno
17722	patron guantes del padre invierno
17723	camisa festiva verde
17724	patron camisa festiva verde
17725	formula encantar arma poderio del invierno
17726	obsequio especial de pastos de bosquehumeante
17727	caja con obsequio de pastos de bosquehumeante
17728	botas de escama de cocodrilo albino
17730	hacha bocaiman
17731	pergamino de celebras
17732	manto de escamapodrida
17733	puno de piedra
17734	yelmo de la montana
17735	el festin del festival de invierno
17736	guanteletes de agarre de roca
17737	piedra nube
17738	garra de celebras
17739	manton de guardia de la arboleda
17740	ornato de veritas
17741	abrazo de la naturaleza
17742	armadura de embozo fungal
17743	vara de resurgimiento
17744	corazon de noxxion
17745	lanzaponzona
17746	grilletes de noxxion
17747	raiz de latisable
17748	botas de vina putrida
17749	bufas de fitopiel
17750	faja de clororrejilla
17751	leotardos de pelabrusels
17752	latigo de satiro
17753	objetivo del vigilante verdeante
17754	leotardos de timador infernal
17755	fajin de crin de satiro
17756	trozo de fragmento oscuro
17757	amuleto de los espiritus
17758	amuleto de unidad
17759	marca de resolucion
17760	semilla de vida
17761	gema del primer kahn
17762	gema del segundo kahn
17763	gema del tercer kahn
17764	gema del cuarto kahn
17765	gema del quinto kahn
17766	cetro de la princesa theradras
17767	celada brotasangre
17768	aro de semillalena
17769	bufas de arbusto
17770	guanteletes ramazarza
17771	barra de elementium
17772	colgante de fragmento oscuro entusiasta
17773	colgante de fragmento de sombras prodigioso
17774	marca del elegido
17775	togas de sagacidad
17776	yelmo de argollas de duende
17777	cota de malla incansable
17778	faja de arbusto
17779	espaldares de mole de piedra
17780	hoja de oscuridad eterna
17781	las instrucciones del paria
17782	fragmento de dije de vinculo
17783	trozo de dije de vinculo
17822	mapas lobo gelido
17823	planes de batalla pico tormenta
17849	estandarte pico tormenta
17850	estandarte lobo gelido
17900	insignia pico tormenta rango 2
17901	insignia pico tormenta rango 3
17902	insignia pico tormenta rango 4
17903	insignia pico tormenta rango 5
17904	insignia pico tormenta rango 6
17905	insignia lobo gelido rango 2
17906	insignia lobo gelido rango 3
17907	insignia lobo gelido rango 4
17908	insignia lobo gelido rango 5
17909	insignia lobo gelido rango 6
17922	armadura de pellejo de leon
17943	puno de piedra
17962	saco de gemas azules
17963	saco de gemas verde
17964	saco de gemas gris
17965	saco de gemas amarillo
17966	mochila de pellejo de onyxia
17967	escama de onyxia refinada
17968	escama de onyxia cargada
17969	saco de gemas rojo
17982	nucleo de ragnaros
18022	sello real de alexis
18023	colgante de rubi de sangre
18042	espada con punta de torio
18043	botas de minero de carbon
18044	pichel de hurley
18045	chuleta de lobo tierno
18046	receta chuleta de lobo tierno
18047	botos de llamas
18048	martillo de maestro forjador
18082	vara de irritacion de zum rah
18083	mandiletes jumanza
18102	botas de jinete de dragon
18103	sortija de reflexion
18104	faja ola feral
18142	cabeza decapitada de elfo de la noche
18143	mechon de pelo de gnomo
18144	astilla de hueso humano
18145	pezuna tauren
18146	mojo de trol lanza negra
18147	corazon de los renegados
18148	craneo de korrak
18149	runa de regreso
18150	runa de regreso
18151	ampolla de amatista llena
18152	ampolla de amatista
18153	gema moro gan roja
18154	papel y sobres para cartas de blizzard
18155	gema moro gan azul
18156	gema moro gan verde
18157	gema moro gan negra
18158	gema moro gan de oro
18159	gema moro gan blanca
18160	receta te de cardo
18168	disco reactivo a la fuerza
18169	manto del alba flamigero
18170	manto del alba de escarcha
18171	manto del alba arcano
18172	manto del alba de naturaleza
18173	manto del alba de las sombras
18182	manto del alba cromatico
18202	garra izquierda de eskhandar
18203	garra derecha de eskhandar
18204	pelambre de eskhandar
18205	collar de eskhandar
18206	espinazo de enano
18207	diente orco
18208	manton de oracion
18209	bujia energizada
18222	vid espinosa
18223	petalo dentado
18224	raiz de azotador
18225	zapatos de carrera desgastados
18226	un pacto sellado
18227	pacificador sin sustancia
18228	foto autografiada de tigule
18229	guia de pesca extrema de nat pagle
18230	boton g a n o roto
18231	camiseta sin mangas
18232	robot de reparacion de campo 74a
18233	panuelo manchado de lagrimas
18234	documento de importaciones bocarda
18235	esquema robot de reparacion de campo 74a
18236	muneco masticado de gordok
18237	mandibula de mastin
18238	guantes sombradermos
18239	patron guantes sombradermos
18240	tanino de ogro
18241	brida de corcel de guerra negro
18242	riendas del tigre de guerra negro
18243	zancudo de batalla negro
18244	carnero de guerra negro
18245	cuerno de lobo de guerra negro
18246	silbato del raptor de guerra negro
18247	kodo de guerra negro
18248	caballo de guerra esqueletico rojo
18249	llave creciente
18250	llave de los grilletes de gordok
18251	refuerzo para armadura del nucleo
18252	patron refuerzo para armadura del nucleo
18253	pocion de rejuvenecimiento sublime
18254	sorpresa de tuberculo runtun
18255	tuberculo runtun
18256	vial imbuido
18257	receta pocion de rejuvenecimiento sublime
18258	disfraz de ogro gordok
18259	formula encantar arma poder de hechizos
18260	formula encantar arma poder de sanacion
18261	libro de conjuros
18262	piedra de afilar elemental
18263	brazaletes bengala del nucleo
18264	diseno piedra de afilar elemental
18265	patron brazaletes bengala del nucleo
18266	llave de patio de gordok
18267	receta sorpresa de tuberculo runtun
18268	llave de puerta interior de gordok
18269	grog verde de gordok
18282	rifle de tirador del nucleo
18283	acurascopio 247x128 de biznicks
18284	cerveza negra de kreeg
18285	fragmento de mana cristalizado
18286	trozo de mana condensado
18287	siempreturbio
18288	aguardiente de melaza
18289	collar de espino con puas
18290	esquema acurascopio 247x128 de biznicks
18291	esquema disco reactivo de fuerza
18292	esquema rifle de tirador del nucleo
18294	elixir de respiracion acuatica superior
18295	botas de fase
18296	braciles de tirador
18297	semilla de espinacula
18298	leotardos irrefrenables
18299	esencia de hidromilecio
18300	nectar de hyjal
18301	varita de lethtendris
18302	sortija de vigor
18303	rodela liviana
18304	malla raiz verde
18305	musleras arrecife
18306	guantes de niebla enigmatica
18307	botas de corriente
18308	sombrero ingenioso
18309	guantes de restauracion
18310	machete endemoniado
18311	vara de mediacion quel dorei
18312	peto energizado
18313	yelmo de conciencia
18314	anillo de astucia demoniaca
18315	anillo de potencia demoniaca
18316	adorno de obsidiana
18317	dije de tempestad
18318	grebas clementes
18319	yelmo ferviente
18320	bufas de corazon de demonio
18321	vara energetica
18322	botas del canalon
18323	arco de satiro
18324	cortaolas
18325	almete pellejo vil
18326	guanteletes navaja
18327	cordon de parral
18328	capa maderaoscura
18329	arcanum de rapidez
18330	arcanum de enfoque
18331	arcanum de proteccion
18332	tratado sobre rapidez
18333	tratado sobre enfoque
18334	tratado sobre proteccion
18335	diamante negro pristino
18336	guante del poderio de gordok
18337	brazales orficos
18338	varita de potencia arcana
18339	capa de eidolon
18340	dije de eidolon
18341	fajin quel dorei
18342	guarda quel dorei
18343	sortija petrificada
18344	guanteletes cortezapiedra
18345	anillo murmurante
18346	calzas sin hilos
18347	hacha bien equilibrada
18348	quel serrar
18349	guanteletes de precision
18350	capa amplificadora
18351	brazales sellados magicamente
18352	escudo de corteza petrificada
18353	baston de piedra floreada
18354	collera de pimgib
18355	collera de ferra
18356	garona un estudio sobre el sigilo y la traicion
18357	codice de defensa
18358	el libro de cocina del arcanista
18359	la luz y como alterarla
18360	sombras acechadoras
18361	la mejor raza de cazadores
18362	sagrada bologna lo que la luz nunca te dira
18363	el choque de escarcha y tu
18364	el sueno esmeralda
18365	una copia bien leida de pesca arriesgada con nat pagle
18366	manoplas de gordok
18367	guanteletes de gordok
18368	guantes de gordok
18369	manijas de gordok
18370	talisman de vigilancia
18371	dije de lectura mental
18372	hoja de la luna nueva
18373	peto de tranquilidad
18374	sobrehombros marcado por las llamas
18375	brazales del eclipse
18376	maza gastada
18377	guantes rapidos
18378	leotardos lunargenta
18379	grebas odiosas
18380	quijotes reforzados tetricos
18381	colgante de ojo malvado
18382	capa oscilante
18383	guanteletes imbuidos de fuerza
18384	bufas con grabados de bilis
18385	toga de noche perpetua
18386	calzas de padre
18387	guantes chispa brillante
18388	machacapiedras
18389	capa del cosmos
18390	leotardos mohomarana
18391	cordon acecha ojos
18392	daga de distraccion
18393	brazal alabeo
18394	guardamunecas de grito de demonio
18395	anillo de llama esmeralda
18396	tallador de mentes
18397	colgante de mago anciano
18398	aro de la marea
18399	brisa del mar
18400	anillo de piedra viva
18401	compendio de matar dragones de nostro
18402	anillo de cristal resplandeciente
18403	sello de matadragones
18404	colgante de diente de onyxia
18405	cinturon del archimago
18406	dije de sangre de onyxia
18407	guantes de tela vil
18408	guantes inferno
18409	guantes de tela lunar
18410	espada de esprinter
18411	botas de soltura
18412	trozo del nucleo
18413	capa de amparo
18414	patron cinturon del archimago
18415	patron guantes de tela vil
18416	patron guantes inferno
18417	patron guantes de tela lunar
18418	patron capa de amparo
18420	aplastahuesos
18421	yelmo provinciano
18422	cabeza de onyxia
18423	cabeza de onyxia
18424	botas de juncia
18425	jarra de kreeg
18426	membrana de lethtendris
18427	capa de sargento
18428	insignia de capataz primero
18429	brazales de placas de gran capataz
18430	brazales de placas de gran capataz
18432	guardamunecas de malla de gran capataz
18434	guardabrazos de pellejo de dragon de gran capataz
18435	guardabrazos de cuero de gran capataz
18436	guardabrazos de pellejo de dragon de gran capataz
18437	punos de seda de gran capataz
18438	marca de sargento
18440	manteo de sargento
18441	manteo de sargento
18442	insignia de sargento primero
18443	insignia de sargento primero
18444	insignia de sargento primero
18445	guardamunecas de placas de alferez
18447	guardamunecas de placas de alferez
18448	guardabrazos de anillas de alferez
18449	guardabrazos de anillas de alferez
18450	toga de combustion
18451	cinturon de pellejo de hiena
18452	braquiales de cuero de alferez
18453	braquiales de cuero de alferez
18454	braquiales de pellejo de dragon de alferez
18455	braquiales de pellejo de dragon de alferez
18456	punos de seda de alferez
18457	punos de seda de alferez
18458	guardabrazos modestos
18459	guardamunecas de galante
18460	culebrina poco sofisticada
18461	capa de sargento
18462	puno de hueso dentado
18463	cuchillo de bolsillo de ogro
18464	pendiente para la nariz de gordok
18465	sello real de eldre thalas
18466	sello real de eldre thalas
18467	sello real de eldre thalas
18468	sello real de eldre thalas
18469	sello real de eldre thalas
18470	sello real de eldre thalas
18471	sello real de eldre thalas
18472	sello real de eldre thalas
18473	sello real de eldre thalas
18475	cinturon magico curioso
18476	botas manchadas de barro
18477	leotardos peludos
18478	chaleco de pellejo de hiena
18479	yelmo de escorpido carronero
18480	yelmo de placas escarabajo
18481	maza aplastacalaveras
18482	lanzamondadientes de ogro
18483	varita de mediacion de mana
18484	hoja de cho rush
18485	escudo de observador
18486	toga de tela lunar
18487	patron toga de tela lunar
18488	hoja antigua caliente
18489	hoja antigua sin templar
18490	caperuza de perspicacia
18491	hilador de conocimiento
18492	espada antigua tratada
18493	bufas de hierro grandes
18494	sobrehombros de vigia de cubil
18495	capa de reducto
18496	capa de heliotropo
18497	guardamunecas sublimes
18498	podadora
18499	escudo barrera
18500	anillo elfico deslustrado
18501	fragmento de gangrevid
18502	guja monstruosa
18503	peto de kromcrush
18504	faja de perspicacia
18505	cinturon de asaltante
18506	botas de mangosta
18507	botas de la luna llena
18508	brazales de vuelo presto
18509	capa cromatica
18510	capa de fiera
18511	capa ondeante
18512	acido de larva
18513	una hoja elfica desafilada
18514	patron faja de perspicacia
18515	patron botas de mangosta
18516	patron brazales de vuelo presto
18517	patron capa cromatica
18518	patron capa de fiera
18519	patron capa ondeante
18520	hoja atroz
18521	botas de metal mugrientas
18522	sortija del rey ogro
18523	piedra con resplandor brillante
18524	leotardos de destruccion
18525	brazales de prosperidad
18526	corona del rey ogro
18527	guanteletes armoniosos
18528	bufas de ciclon
18529	faja de placas elementales
18530	camisote forjado de ogro
18531	gran maza implacable
18532	toga de oleada de mente
18533	brazales de poder de gordok
18534	vara de los magi ogros
18535	escudo de milli
18536	lexicon de milli
18537	magnetita de contraataque
18538	aterrantarboles
18539	relicario de pureza
18540	relicario de pureza sellado
18541	manteo enjundioso
18542	tifon
18543	anillo de entropia
18544	guanteletes de pellejo maldito
18545	leotardos de supremacia arcana
18546	jaula de cabeza infernal
18547	faja de hielo sin derretir
18562	mena de elementium
18563	ataduras del hijo del viento
18564	ataduras del hijo del viento
18567	flujo elemental
18582	las hojas gemelas de azzinoth
18583	guja de guerra de azzinoth derecha
18584	guja de guerra de azzinoth izquierda
18585	sortija de lealtad
18586	circulo de arbol solitario
18587	desfibriladores goblin xl
18588	dinamita para tontos ii
18590	sangre de bestia enfurecida
18591	caja de sangre
18592	diseno martillo de sulfuron
18594	carga de seforio potente
18595	opalo de sangre
18597	silbato de huerfano orco
18598	silbato de huerfano humano
18600	escrito sobre luminosidad arcana
18601	prision de cristal resplandeciente
18602	escrito sobre sacrificio
18603	sangre de satiro
18604	lagrimas de los hederine
18605	guardia apocaliptico encarcelado
18606	confalon de batalla de la alianza
18607	confalon de batalla de la horda
18608	oracion
18609	anatema
18610	machete cortante
18611	leotardos tuercepinos
18612	botas de anillas sangrientas
18622	esencia vil impecable jaedenar
18623	esencia vil impecable portal oscuro
18624	esencia vil impecable azshara
18625	nucleo infernal de kroshius
18626	fuego vil
18627	gong de dethmoora
18628	contrato de la hermandad del torio
18629	magnetita negra
18630	llama del dia del juicio final
18631	transformador de veraplata
18632	caramelo de los disturbios de arroyo de la luna
18633	piruleta de styleen
18634	reflector de hielo girohielo
18635	barrita de nueces de bellara
18636	desfibriladores xl estropeados
18637	recombobulador sublime
18638	reflector de llamas hiperradiante
18639	reflector de las sombras ultradeslumbrante
18640	roca de diversion
18641	dinamita densa
18642	autografo de jaina
18643	marca de la pezuna de cairne
18645	roboalarma gnomico
18646	el ojo de divinidad
18647	esquema fuegos artificiales rojos
18648	esquema fuegos artificiales verdes
18649	esquema fuegos artificiales azules
18650	esquema dinamita para tontos ii
18651	esquema transformador de veraplata
18652	esquema reflector de hielo girohielo
18653	esquema desfibriladores goblin xl
18654	esquema roboalarma gnomico
18655	esquema recombobulador sublime
18656	esquema carga de seforio potente
18657	esquema reflector de llamas hiperradiante
18658	esquema reflector de las sombras ultradeslumbrante
18659	astilla de nordrassil
18660	amplificador de mundo
18661	esquema amplificador de mundo
18662	bola de cuero pesado
18663	tarro de j eevee
18664	un tratado sobre rangos militares
18665	el ojo de la sombra
18670	glifos xorothianos
18671	cetro del baron charr
18672	elemental de ascuas
18673	pellejo pedregoso de avalanchion
18674	sortija de piedra endurecida
18675	rangos militares de la horda y la alianza
18676	fajin del atracavientos
18677	capa cefiro
18678	collar helado de tempestria
18679	anillo gelido
18680	arco de hueso antiguo
18681	chal de entierro
18682	leotardos de piel de necrofago
18683	martillo de la vispera
18684	anillo opalescente oscuro
18686	sobrehombros de golem de huesos
18687	polvo estelar xorothiano
18688	diablillo en un tarro
18689	capa fantasmal
18690	leotardos de placas de anima
18691	colgante de consejero oscuro
18692	escarpes de caballero de la muerte
18693	manijas escalofrio
18694	grebas de malla enigmaticas
18695	escrito vinculado
18696	escudo runico con un intrincado adorno
18697	zapatillas de piedrafria
18698	caperuza de cuero andrajoso
18699	bufas de tumba heladas
18700	brazales maleficos
18701	sortija de estimulacion
18702	cinturon de la ordenacion
18703	hoja petrificada vieja
18704	tendon de dragon azul maduro
18705	tendon de dragon negro maduro
18706	maestro de arena
18707	baculo con grabados de runas antiguas
18708	corteza petrificada
18709	guardamunecas de arena
18710	brazales de arena
18711	braciles de arena
18712	avambrazos de arena
18713	rhok delar arco largo de los guardianes ancianos
18714	carcaj antiguo cosido con tendon
18715	lok delar baculo de los guardianes ancianos
18716	botas cubiertas de ceniza
18717	martillo del gran cruzado
18718	yelmo del gran cruzado
18719	el corazon del traidor
18720	embozo de nathrezim
18721	faja de bombardeo
18722	mandiletes de la muerte
18723	collar de anillas animado
18724	tendon de dragon negro encantado
18725	pacificador
18726	punos de magistrado
18727	sombrero de fieltro carmesi
18728	reliquia de anastari
18729	arco chirrido
18730	manijas con encaje enigmaticas
18731	patron bola de cuero pesado
18734	capa de luna palida
18735	borceguies de maleki
18736	leotardos de can de peste
18737	hachuela rebanadora de huesos
18738	ballesta de caparazon espinoso
18739	musleras de placas de quitina
18740	fajin thuzadin
18741	brazal de morlune
18742	guardahombros de la milicia de stratholme
18743	manteo lujoso
18744	guantes de pelaje de murcipeste
18745	leotardos de pano sacro
18746	cristal de adivinacion
18747	prueba de propiedades de objeto
18749	alma perdida de cargador
18752	incensario de exorcismo
18753	gualdrapa de arcanita
18754	brazales viles endurecidos
18755	palo de fuego xorothiano
18756	protector del guardia del terror
18757	manto diabolico
18758	espada de espectro
18759	hacha maliciosa
18760	sortija nigromantica
18761	toque de olvido
18762	fragmento de la llama verde
18766	riendas del sable de hielo presto
18767	riendas del sable de la niebla presto
18768	riendas del sable del alba presto
18769	malla de placas de torio encantado
18770	malla de placas de torio encantado
18771	malla de placas de torio encantado
18772	mecazancudo verde presto
18773	mecazancudo blanco presto
18774	mecazancudo amarillo presto
18775	alimento para caballos enriquecido con mana
18776	palomino presto
18777	corcel marron presto
18778	corcel blanco presto
18779	mitad inferior de forja de armaduras avanzada volumen i
18780	mitad superior de forja de armaduras avanzada volumen i
18781	mitad inferior de forja de armaduras avanzada volumen ii
18782	mitad superior de forja de armaduras avanzada volumen ii
18783	mitad inferior de forja de armaduras avanzada volumen iii
18784	mitad superior de forja de armaduras avanzada volumen iii
18785	carnero blanco presto
18786	carnero marron presto
18787	carnero gris presto
18788	raptor azul presto
18789	raptor oliva presto
18790	raptor naranja presto
18791	caballo de guerra esqueletico morado
18792	gualdrapa de arcanita bendita
18793	gran kodo blanco
18794	gran kodo marron
18795	gran kodo gris
18796	cuerno de lobo marron presto
18797	cuerno del lobo gris presto
18798	cuerno del lobo grisaceo presto
18799	alma redimida de cargador
18802	pocion enigmatica
18803	draga de lava hipertermicamente aislada
18804	cartera de lord grisillo
18805	diente de can del nucleo
18806	grebas forjadas del nucleo
18807	yelmo de poder latente
18808	guantes de la llama hipnotica
18809	fajin de los secretos susurrados
18810	bufas de crecimiento salvaje
18811	capa a prueba de fuego
18812	guardamunecas de autentico vuelo
18813	anillo de vinculo
18814	gargantilla del senor del fuego
18815	esencia de la llama pura
18816	hoja de perdicion
18817	corona de destruccion
18818	instrucciones de mor zul
18819	incensario de exorcismo de rohan
18820	dije de poder efimero
18821	anillo de golpe rapido
18822	hoja afilada de obsidiana
18823	guantes viejos de cuero del nucleo
18824	botas templadas de magma
18825	egida de gran mariscal
18826	escudo muro de gran senor de la guerra
18827	hacha de mano de gran mariscal
18828	cuchilla de gran senor de la guerra
18829	bufas del interior de la tierra
18830	taladora de gran mariscal
18831	hacha de batalla de gran senor de la guerra
18832	hoja de brutalidad
18833	disparo certero de gran mariscal
18834	insignia de la horda
18835	arco corvo de gran senor de la guerra
18836	ballesta de repeticion de gran mariscal
18837	ballesta de gran senor de la guerra
18838	puntilla de gran mariscal
18839	pocion de sanacion de combate
18840	navaja de gran senor de la guerra
18841	pocion de mana de combate
18842	baston de dominancia
18843	hoja de mano derecha de gran mariscal
18844	garra derecha de gran senor de la guerra
18845	insignia de la horda
18846	insignia de la horda
18847	hoja de mano izquierda de gran mariscal
18848	garra izquierda de gran senor de la guerra
18849	insignia de la horda
18850	insignia de la horda
18851	insignia de la horda
18852	insignia de la horda
18853	insignia de la horda
18854	insignia de la alianza
18855	culebrina de gran mariscal
18856	insignia de la alianza
18857	insignia de la alianza
18858	insignia de la alianza
18859	insignia de la alianza
18860	barrecaminos de gran senor de la guerra
18861	quijotes de despiertallamas
18862	insignia de la alianza
18863	insignia de la alianza
18864	insignia de la alianza
18865	castigadora de gran mariscal
18866	cachiporra de gran senor de la guerra
18867	martillo de batalla de gran mariscal
18868	pulverizador de gran senor de la guerra
18869	guja de gran mariscal
18870	yelmo del dador de vida
18871	pica de jabalies de gran senor de la guerra
18872	leotardos de tormenta de mana
18873	baculo de gran mariscal
18874	baston de guerra de gran senor de la guerra
18875	pantalones de escamas de salamandra
18876	mandoble de gran mariscal
18877	espada magna de gran senor de la guerra
18878	daga de hechicero
18879	anillo pesado de hierro negro
18880	cabeza de atracoscuro
18902	riendas del sable de la tempestad presto
18904	ultra reductor de zorbin
18922	disenos secretos flujo igneo
18942	flujo igneo
18943	almohada hierro negro
18944	escama de incendosaurio
18945	residuo de hierro negro
18946	cabeza del sobrestante maltorius
18947	pellejo de yeti cicatriz de rabia
18948	brazales barbaricos
18949	patron brazales barbaricos
18950	almohada de la ayudante de camara pilaprieta
18951	pilar de aterrizaje de evonice
18952	cabeza de simone
18953	cabeza de klinfran
18954	cabeza de solenor
18955	cabeza de artorius
18956	residuo de miniaturizacion
18957	hoja lenomaleza
18958	nucleo de elemental de agua
18959	tobera de herreria
18960	catalejo de oteador
18961	caparazon zukk ash
18962	glandulas de latigador con aguijon
18963	huevo de tortuga albino
18964	huevo de tortuga lenobeza
18965	huevo de tortuga alconil
18966	huevo de tortuga cuerospalda
18967	huevo de tortuga oliva
18969	pellejo de yeti pristino
18972	pellejo de yeti perfecto
18984	desgarrador dimensional vista eterna
18986	transportador ultraseguro gadgetzan
18987	orden de puno negro
19002	cabeza de nefarian
19003	cabeza de nefarian
19004	piedra de salud menor
19005	piedra de salud menor
19006	piedra de salud inferior
19007	piedra de salud inferior
19008	piedra de salud
19009	piedra de salud
19010	piedra de salud superior
19011	piedra de salud superior
19012	piedra de salud sublime
19013	piedra de salud sublime
19016	vasija de renacer
19017	esencia del senor del fuego
19018	hoja besada por el viento durmiente
19019	trueno furioso espada bendita del hijo del viento
19020	informe del campamento mojache zukk ash
19022	pescador extremo de nat pagle fc 5000
19023	cebo mas preciado de katoom
19024	gran maestro de arena
19025	pendola de senor del cielo
19026	fuegos artificiales serpenteantes
19027	esquema fuegos artificiales serpenteantes
19028	vestido elegante
19029	cuerno del aullador lobo gelido
19030	carnero de batalla pico tormenta
19031	tabardo de batalla lobo gelido
19032	tabardo de batalla pico tormenta
19033	herramientas perdidas de esco
19034	almuerzo de lard
19035	cesta de merienda especial de lard
19036	mensaje final a martillo salvaje
19037	bufas de pico esmeralda
19038	anillo de sutileza
19039	sombrero resistente al agua de zorbin
19040	megacercenadora de zorbin
19041	guerrera hecha a mano de pratt
19042	guerrera hecha a mano de jangdor
19043	cinturon fauces de madera pesado
19044	poderio de los fauces de madera
19045	confalon de batalla pico tormenta
19046	confalon de batalla lobo gelido
19047	sabiduria de los fauces de madera
19048	botas fauces de madera pesadas
19049	guantes de cuero fauces de madera
19050	manto de los fauces de madera
19051	faja del alba
19052	botines del alba
19054	red dragon orb
19055	green dragon orb
19056	botas argenta
19057	guantes del alba
19058	manto del alba dorado
19059	sobrehombros argenta
19060	racion enriquecida de la garganta grito de guerra
19061	racion de hierro de la garganta grito de guerra
19062	racion de campo de la garganta grito de guerra
19064	llave de grillete
19065	circulo esmeralda
19066	venda de pano runico de la garganta grito de guerra
19067	venda de tejido magico de la garganta grito de guerra
19068	venda de seda de la garganta grito de guerra
19069	calavera del cazador malkhor
19070	huesos del cazador malkhor
19071	vasija de sangre corrupta
19083	capa de legionario lobo gelido
19084	capa de soldado pico tormenta
19085	capa de consejero lobo gelido
19086	capa de sabio pico tormenta
19087	cinturon de placas lobo gelido
19088	cinturon de malla lobo gelido
19089	cinturon de cuero lobo gelido
19090	cinturon de pano lobo gelido
19091	faja de placas pico tormenta
19092	faja de malla pico tormenta
19093	faja de cuero pico tormenta
19094	faja de pano pico tormenta
19095	colgante de legionario lobo gelido
19096	colgante de consejero lobo gelido
19097	colgante de soldado pico tormenta
19098	colgante de sabio pico tormenta
19099	hoja glacial
19100	daga electrificada
19101	baston de tormenta de nieve
19102	baston resonante
19103	mordisquielo
19104	martillo golpe de tormenta
19105	ornato de runas de escarcha
19106	lanza con puas de hielo
19107	buscasangre
19108	varita de frio cortante
19109	anillo raices profundas
19110	hoja forjada en frio
19111	cubrehombros de hacha invernal
19112	avambrazos de acero congelados
19113	brazales de pellejo de yeti
19114	arco de tierra alta
19115	frasco de mojo del bosque
19116	manijas hojaverde
19117	quijotes de placas de madera lacadas
19118	aliento de la naturaleza
19119	guantes de pellejo de lechubestia
19120	runa del capitan de la guardia
19121	capa del bosque profundo
19123	manijas siempre calidas
19124	leotardos de placas de escoria
19125	faja de malla chamuscada
19126	guanteletes de placas de escoria
19127	guerrera de cuero carbonizada
19128	jubon de malla chamuscado
19129	toga resplandor eterno
19130	mordedura de frio
19131	botas cieganieve
19132	corona adornada con cristales
19133	leotardos vil imbuidos
19134	cinturon de piel de guardia apocaliptico
19135	brazal de luz negra
19136	cordon de ignicion de mana
19137	faja de acometida
19138	sortija de sulfuras
19139	sobrehombros de guardia de fuego
19140	sortija de cauterizacion
19141	lufa
19142	grimorio runico de fuego
19143	guanteletes de guardia de llamas
19144	escarpes del caminante sobre llamas
19145	toga de poder volatil
19146	guardamunecas de estabilidad
19147	anillo de poder con hechizos
19148	yelmo hierro negro
19149	cinturon de lava
19150	botiquin basico de centinela
19151	botiquin normal de centinela
19152	botiquin avanzado de centinela
19153	botiquin avanzado de escolta
19154	botiquin basico de escolta
19155	botiquin normal de escolta
19156	toga bengala del nucleo
19157	guanteletes cromaticos
19159	collar de hiedra trenzada
19160	tabardo de ganador de concurso
19162	cinturon de can del nucleo
19163	cinturon de arrabio
19164	guanteletes hierro negro
19165	leotardos bengala del nucleo
19166	amnistia negra
19167	furianegra
19168	guardanegra
19169	ocaso
19170	mano de ebano
19182	vale de la feria de la luna negra
19183	arena de reloj de arena
19202	diseno cinturon fauces de madera pesado
19203	diseno faja del alba
19204	diseno botas fauces de madera pesadas
19205	diseno guantes del alba
19206	diseno yelmo hierro negro
19207	diseno guanteletes hierro negro
19208	diseno amnistia negra
19209	diseno furianegra
19210	diseno mano de ebano
19211	diseno guardanegra
19212	diseno ocaso
19213	dije de merito ala de plata
19215	patron sabiduria de los fauces de madera
19216	patron botas argenta
19217	patron sobrehombros argenta
19218	patron manto de los fauces de madera
19219	patron toga bengala del nucleo
19220	patron leotardos bengala del nucleo
19221	gran reserva de la luna negra
19222	cerveza barata
19223	perrito de la luna negra
19224	alitas super picantes
19225	chocolatina frita
19227	as de bestias
19228	baraja de bestias
19229	fortuna de sayge n º 1
19230	dos de bestias
19231	tres de bestias
19232	cuatro de bestias
19233	cinco de bestias
19234	seis de bestias
19235	siete de bestias
19236	ocho de bestias
19237	fortuna de sayge n º 19
19238	fortuna de sayge n º 3
19239	fortuna de sayge n º 4
19240	fortuna de sayge n º 5
19241	fortuna de sayge n º 6
19242	fortuna de sayge n º 7
19243	fortuna de sayge n º 8
19244	fortuna de sayge n º 9
19245	fortuna de sayge n º 10
19246	fortuna de sayge n º 11
19247	fortuna de sayge n º 12
19248	fortuna de sayge n º 13
19249	fortuna de sayge n º 14
19250	fortuna de sayge n º 15
19251	fortuna de sayge n º 16
19252	fortuna de sayge n º 18
19253	fortuna de sayge n º 17
19254	fortuna de sayge n º 21
19255	fortuna de sayge n º 22
19256	fortuna de sayge n º 2
19257	baraja de senores de la guerra
19258	as de senores de la guerra
19259	dos de senores de la guerra
19260	tres de senores de la guerra
19261	cuatro de senores de la guerra
19262	cinco de senores de la guerra
19263	seis de senores de la guerra
19264	siete de senores de la guerra
19265	ocho de senores de la guerra
19266	fortuna de sayge n º 20
19267	baraja de elementales
19268	as de elementales
19269	dos de elementales
19270	tres de elementales
19271	cuatro de elementales
19272	cinco de elementales
19273	seis de elementales
19274	siete de elementales
19275	ocho de elementales
19276	as de portales
19277	baraja de portales
19278	dos de portales
19279	tres de portales
19280	cuatro de portales
19281	cinco de portales
19282	seis de portales
19283	siete de portales
19284	ocho de portales
19287	naipe de la luna negra heroismo
19288	naipe de la luna negra dragon azul
19289	naipe de la luna negra la voragine
19290	naipe de la luna negra el vacio abisal
19291	caja de almacenamiento de la luna negra
19292	anojo del mes pasado
19293	anojo del ano pasado
19295	flor de la luna negra
19296	lote superior de la luna negra
19297	lote inferior de la luna negra
19298	lote menor de la luna negra
19299	bebida de feria con burbujas
19300	agua de cuna del invierno embotellada
19301	galleta de mana de alterac
19302	anillo de la luna negra
19303	collar de la luna negra
19304	cecina de ternera picante
19305	pie de kodo en vinagre
19306	rana crujiente
19307	venda de pano runico gruesa de alterac
19308	escrito sobre dominacion arcana
19309	escrito sobre fuerza de las sombras
19310	escrito del senor del hielo
19311	escrito sobre arcana ignea
19312	leu del vivificador
19315	toque de therazane
19316	flecha con hielo
19317	bala con hielo
19318	agua de manantial de alterac embotellada
19319	carcaj de pellejo de arpia
19320	bandolera de piel de gnoll
19321	el objeto inamovible
19322	marca de honor grito de guerra
19323	la fuerza imparable
19324	el lobotomizador
19325	sortija de don julio
19326	patron poderio de los fauces de madera
19327	patron guantes de cuero fauces de madera
19328	patron botines del alba
19329	patron manto del alba dorado
19330	patron cinturon de lava
19331	patron guanteletes cromaticos
19332	patron cinturon de can del nucleo
19333	patron cinturon de arrabio
19334	la espada indomable
19335	machacapuas
19336	gema arcana imbuida
19337	el libro negro
19338	vale de entrada gratuita
19339	gema de estimulo mental
19340	runa de metamorfosis
19341	gema dadora de vida
19342	totem venenoso
19343	pergaminos de luz cegadora
19344	cristal de alineacion natural
19345	egida de preservacion
19346	hoja colmillo dragon
19347	garra de chromaggus
19348	protector de dragontina roja
19349	baluarte reforzado de elementium
19350	apuntacorazones
19351	maladath hoja runica del vuelo negro
19352	espada templada cromaticamente
19353	cuchilla de garfa de draco
19354	vengador draconico
19355	baston de enfoque de alasombra
19356	baston de la llama de las sombras
19357	heraldo de tragedia
19358	gran maza draconica
19360	lok amir il romathis
19361	ashjre thul ballesta de paliza
19362	filo de la fatalidad
19363	crul shorukh filo del caos
19364	ashkandi espada magna de la hermandad
19365	garra del draco negro
19366	orbe de maestro matadragones
19367	toque de dragon
19368	culebrina aliento de dragon
19369	guantes de evolucion rapida
19370	manto del conciliabulo alanegra
19371	colgante del dragon caido
19372	yelmo de ira infinita
19373	espaldares de linaje negro
19374	brazales de precision arcana
19375	mish undare aro del despelleja almas
19376	anillo de juicio de archimtiros
19377	dije de connivencia de prestor
19378	capa del senor del linaje
19379	lagrima de neltharion
19380	eslabon de therazane
19381	botas de la llama de las sombras
19382	sortija de elementium puro
19383	medallon de maestro matadragones
19384	anillo de maestro matadragones
19385	leotardos potenciados
19386	capa tejida con elementium
19387	botas cromaticas
19388	garra de angelista
19389	hombreras de pellejo de dragon tirante
19390	guantes de pellejo de dragon tirante
19391	geta fulgurante
19392	faja del cruzado caido
19393	guardarrenes enlazados de primalista
19394	espaldares de garfa de draco
19395	gema rejuvenecedora
19396	cinturon de pellejo de dragon tirante
19397	anillo de roca negra
19398	capa de faucefogo
19399	toga de ceniza negra
19400	agarre de faucefogo
19401	musleras enlazadas de primalista
19402	musleras del cruzado caido
19403	sortija de concentracion forzada
19405	baluarte bendito de malfurion
19406	dije de colmillo de draco
19407	guantes de llamas de ebano
19422	fortuna de la feria de la luna negra
19423	fortuna de sayge n º 23
19424	fortuna de sayge n º 24
19425	arcon misterioso
19426	orbe de la luna negra
19430	embozo de pensamiento puro
19431	escarabajo trabador de styleen
19432	circulo de fuerza aplicada
19433	leotardos de tejido de ascuas
19434	sortija del dominio oscuro
19435	recolector de esencia
19436	capa de poderio draconico
19437	botas de pensamiento puro
19438	botas de ventisca de ringo
19439	chaleco de las sombras entrelazado
19440	contraveneno potente
19441	glandula de veneno enorme
19442	formula contraveneno potente
19443	fortuna de sayge n º 25
19444	formula encantar arma fuerza
19445	formula encantar arma agilidad
19446	formula encantar brazales regeneracion de mana
19447	formula encantar brazal sanacion
19448	formula encantar arma espiritu poderoso
19449	formula encantar arma intelecto poderoso
19450	una casita de jubling
19451	fortuna de sayge n º 26
19452	fortuna de sayge n º 27
19453	fortuna de sayge n º 28
19454	fortuna de sayge n º 29
19462	huevo sin abrir de jubling
19482	pelambre de conejo l artesano
19483	pelar la cebolla
19484	la alcachofa lobo gelido
19491	amuleto de la luna negra
19505	tabardo de batalla grito de guerra
19506	tabardo de batalla ala de plata
19507	chal de inquisidor
19508	brazales de cuero marcado
19509	botas de malla polvorientas
19510	sortija de legionario
19511	sortija de legionario
19512	sortija de legionario
19513	sortija de legionario
19514	sortija de protector
19515	sortija de protector
19516	sortija de protector
19517	sortija de protector
19518	anillo de consejero
19519	anillo de consejero
19520	anillo de consejero
19521	anillo de consejero
19522	anillo del tradicionalista
19523	anillo del tradicionalista
19524	anillo del tradicionalista
19525	anillo del tradicionalista
19526	capa de curador de batalla
19527	capa de curador de batalla
19528	capa de curador de batalla
19529	capa de curador de batalla
19530	manteo de custodio
19531	manteo de custodio
19532	manteo de custodio
19533	manteo de custodio
19534	medallon de explorador
19535	medallon de explorador
19536	medallon de explorador
19537	medallon de explorador
19538	medallon de centinela
19539	medallon de centinela
19540	medallon de centinela
19541	medallon de centinela
19542	hoja de explorador
19543	hoja de explorador
19544	hoja de explorador
19545	hoja de explorador
19546	hoja de centinela
19547	hoja de centinela
19548	hoja de centinela
19549	hoja de centinela
19550	espada de legionario
19551	espada de legionario
19552	espada de legionario
19553	espada de legionario
19554	espada de protector
19555	espada de protector
19556	espada de protector
19557	espada de protector
19558	arco de escolta
19559	arco de escolta
19560	arco de escolta
19561	arco de escolta
19562	arco de avanzado
19563	arco de avanzado
19564	arco de avanzado
19565	arco de avanzado
19566	baston nudoso de consejero
19567	baston nudoso de consejero
19568	baston nudoso de consejero
19569	baston nudoso de consejero
19570	baston del tradicionalista
19571	baston del tradicionalista
19572	baston del tradicionalista
19573	baston del tradicionalista
19574	fuerza de mugamba
19575	fuerza de mugamba
19576	fuerza de mugamba
19577	ira de mugamba
19578	brazales de rabioso
19579	ensena de pagano
19580	brazales de rabioso
19581	brazales de rabioso
19582	guardamunecas de soplaviento
19583	guardamunecas de soplaviento
19584	guardamunecas de soplaviento
19585	ensena de pagano
19586	ensena de pagano
19587	brazales de acechador del bosque
19588	ensena de heroe
19589	brazales de acechador del bosque
19590	brazales de acechador del bosque
19591	el ojo de zuldazar
19592	el ojo de zuldazar
19593	el ojo de zuldazar
19594	el ojo que todo lo ve de zuldazar
19595	ataduras de muneca de la driade
19596	ataduras de muneca de la driade
19597	ataduras de muneca de la driade
19598	guijarro de kajaro
19599	guijarro de kajaro
19600	guijarro de kajaro
19601	joya de kajaro
19602	mancha de kezan
19603	mancha de kezan
19604	mancha de kezan
19605	mancha imparable de kezan
19606	vision de voodress
19607	vision de voodress
19608	vision de voodress
19609	vision inmaculada de voodress
19610	alga de los mares del sur encantada
19611	alga de los mares del sur encantada
19612	alga de los mares del sur encantada
19613	alga de los mares del sur encantada pristina
19614	dije zandalar de las sombras
19615	dije zandalar de las sombras
19616	dije zandalar de las sombras
19617	dije zandalar de maestria de las sombras
19618	zarcillo de la voragine
19619	zarcillo de la voragine
19620	zarcillo de la voragine
19621	colera de la voragine
19642	icoke prize voucher
19682	jubon vid de sangre
19683	leotardos vid de sangre
19684	botas vid de sangre
19685	chaleco de piel de murcielago primigenio
19686	guantes de piel de murcielago primigenio
19687	brazales de piel de murcielago primigenio
19688	coraza de tigre de sangre
19689	sobrehombros de tigre de sangre
19690	coraza de alma de sangre
19691	sobrehombros de alma de sangre
19692	guanteletes de alma de sangre
19693	coraza almanegra
19694	leotardos almanegra
19695	sobrehombros almanegra
19696	pan de la cosecha
19697	recompensa de la cosecha
19698	moneda zulian
19699	moneda razzashi
19700	moneda hakkari
19701	moneda gurubashi
19702	moneda vilrama
19703	moneda secacorteza
19704	moneda furiarena
19705	moneda machacacraneos
19706	moneda sangrapellejo
19707	presea hakkari roja
19708	presea hakkari azul
19709	presea hakkari amarilla
19710	presea hakkari naranja
19711	presea hakkari verde
19712	presea hakkari morada
19713	presea hakkari de bronce
19714	presea hakkari de plata
19715	presea hakkari de oro
19716	ataduras hakkari primigenias
19717	cabestrillo hakkari primigenio
19718	puntal hakkari primigenio
19719	faja hakkari primigenia
19720	fajin hakkari primigenio
19721	chal hakkari primigenio
19722	tabardo hakkari primigenio
19723	casaca hakkari primigenia
19724	egida hakkari primigenia
19725	cajon de recursos de arathi
19726	vid de sangre
19727	guadana de sangre
19764	patron jubon vid de sangre
19765	patron leotardos vid de sangre
19766	patron botas vid de sangre
19767	cuero de murcielago primigenio
19768	cuero de tigre primigenio
19769	patron chaleco de piel de murcielago primigenio
19770	patron guantes de piel de murcielago primigenio
19771	patron brazales de piel de murcielago primigenio
19772	patron coraza de tigre de sangre
19773	patron sobrehombros de tigre de sangre
19774	almarita
19775	bolsa azur sellada
19776	diseno coraza de alma de sangre
19777	diseno sobrehombros de alma de sangre
19778	diseno guanteletes de alma de sangre
19779	diseno coraza almanegra
19780	diseno leotardos almanegra
19781	diseno sobrehombros almanegra
19782	presencia de poderio
19783	sigilo de sincretista
19784	abrazo de la muerte
19785	llamada del falcon
19786	abrazo del vigilante de vodouisant
19787	presencia de vista
19788	maleficio hudu
19789	aura profetica
19790	caricia del animista
19802	corazon de hakkar
19803	corredor a rayas azules de brownell
19804	pez demonio palido
19805	pez angel de keefer
19806	pez reina de dezian
19807	pezrico moteado
19808	potenpez pielroca
19812	runa del alba
19813	muneco de vudu agujereado
19814	muneco de vudu agujereado
19815	muneco de vudu agujereado
19816	muneco de vudu agujereado
19817	muneco de vudu agujereado
19818	muneco de vudu agujereado
19819	muneco de vudu agujereado
19820	muneco de vudu agujereado
19821	muneco de vudu agujereado
19822	coraza de vindicador zandalar
19823	cinturon de vindicador zandalar
19824	guardabrazos de vindicador zandalar
19825	coraza de librepensador zandalar
19826	cinturon de librepensador zandalar
19827	guardabrazos de librepensador zandalar
19828	camisote de augur zandalar
19829	cinturon de augur zandalar
19830	brazales de augur zandalar
19831	manto de depredador zandalar
19832	cinturon de depredador zandalar
19833	brazales de depredador zandalar
19834	guerrera de sinconcierto zandalar
19835	manto de sinconcierto zandalar
19836	brazales de sinconcierto zandalar
19838	guerrera de haruspex zandalar
19839	cinturon de haruspex zandalar
19840	brazales de haruspex zandalar
19841	manto de confesor zandalar
19842	ataduras de confesor zandalar
19843	brazaletes de confesor zandalar
19845	manto de ilusionista zandalar
19846	brazaletes de ilusionista zandalar
19848	brazaletes de endemoniado zandalar
19849	manto de endemoniado zandalar
19850	tributo a uther
19851	tributo a grom
19852	destripahombres hakkari antiguo
19853	destructora de enanos gurubashi
19854	zin rokh destructora de mundos
19855	quijotes empapados de sangre
19856	el ojo de hakkar
19857	capa de consumo
19858	muestra de honor zandalar
19859	colmillo del ignoto
19861	toque del caos
19862	egida del dios de la sangre
19863	sello de primalista
19864	llamasangre
19865	hoja de guerra de los hakkari
19866	hoja de guerra de los hakkari
19867	defensor del senor de la sangre
19869	mandiletes empapados de sangre
19870	capa loa hakkari
19871	dije de proteccion
19872	raptor razzashi presto
19873	sortija carmesi de senor supremo
19874	alabarda de golpeo
19875	almofar manchado de sangre
19876	collar de corruptor de alma
19877	leotardos de animista
19878	espaldares empapados de sangre
19880	coleccion de cabezas gurubashi
19881	cabeza de canalizador
19882	la cabeza de aojador
19883	cordon sacro
19884	sentencia de jin do
19885	ojo maligno de jin do
19886	el casquete de aojador
19887	quijotes manchados de sangre
19888	abrazo de senor supremo
19889	leotardos empapados de sangre
19890	brujo de jin do
19891	bolsa de mal aguero de jin do
19892	botas de animista
19893	sello de zanzil
19894	guanteletes empapados de sangre
19895	falda tintada de sangre
19896	agarre de thekal
19897	botas de traidor
19898	sello de jin
19899	musleras de ritual
19900	hacha de piedra zulian
19901	cercenadora zulian
19902	tigre zulian presto
19903	colmillo de venoxis
19904	camisote runico manchado de sangre
19905	sortija de zanzil
19906	escarpines empapados de sangre
19907	capa de pellejo de tigre zulian
19908	cetro de acometida
19909	voluntad de arlokk
19910	agarre de arlokk
19911	corazon de hierbal
19912	sortija de onice de senor supremo
19913	grebas empapadas de sangre
19914	saco de pellejo de pantera
19915	defensor zulian
19918	triturador de jeklik
19919	grebas manchadas de sangre
19920	sortija de primalista
19921	rebanadora zulian
19922	palo hudu de arlokk
19923	dije opalo de jeklik
19925	sortija de jin
19927	toque de mar li
19928	bufas de animista
19929	guantes tintados de sangre
19930	ojo de mar li
19931	locura de mojo gurubashi
19933	sangre de escorpido resplandeciente
19934	garra de escorpido grande
19935	glandula de veneno vacia
19936	caparazon de escorpido seco
19937	garra de escorpido pequena
19938	pata de escorpido pesada
19939	sangre de gri lek
19940	diente de renataki
19941	melena de wushoolay
19942	hilo de sueno de hazza rah
19943	mojo macizo
19944	ejecutor de peces de nat pagle
19945	parche para ojo de escamas de lagarto
19946	arpon de tigule
19947	carrete roto de nat pagle
19948	distintivo de heroe zandalar
19949	medallon de heroe zandalar
19950	talisman de heroe zandalar
19951	talisman de poderio de gri lek
19952	talisman de valor de gri lek
19953	talisman de bestias de renataki
19954	talisman de artimanas de renataki
19955	talisman de naturaleza de wushoolay
19956	talisman de espiritus de wushoolay
19957	talisman de destruccion de hazza rah
19958	talisman de sanacion de hazza rah
19959	talisman de magia de hazza rah
19960	miel cristalizada
19961	molinillo de gri lek
19962	punzon de gri lek
19963	horquilla de locura
19964	conducto de alma de renataki
19965	atizador de wushoolay
19967	entorpecedor
19968	castigador igneo
19969	botas de pescador extremo de nat pagle
19970	cana de pescar de arcanita
19971	sedal de eternio de alta calidad
19972	sombrero de pesca de la suerte
19973	cinta metrica de nat
19974	cebo de fangoapestoso
19975	fangoapestoso zulian
19978	¡torneo de pesca
19979	anzuelo de maestro pescador
19982	manton de murciumbrio
19984	mascara de ebano
19986	parche de pirata
19989	escrito sobre sombras devoradoras
19990	cuentas de rezo benditas
19991	ojo de demosaurio
19992	diente de demosaurio
19993	arco de caza hudu
19994	fruta de la cosecha
19995	jabali de la cosecha
19996	pez de la cosecha
19997	nectar de la cosecha
19998	lente vid de sangre
19999	gafas vid de sangre
20000	esquema gafas vid de sangre
20001	esquema lente vid de sangre
20002	pocion de letargo sin suenos superior
20003	garras de demosaurio
20004	pocion de sangre de trol sublime
20005	garras de demosaurio
20006	circulo de esperanza
20007	pocion de sangre de mago
20008	pocion de accion viva
20009	¡por la luz
20010	el grito infernal de la horda
20011	receta pocion de sangre de mago
20012	receta letargo sin suenos superior
20013	receta pocion de accion viva
20014	receta pocion de sangre de trol sublime
20015	plumas de raptor viejo
20016	calavera trofeo de raptor
20017	cornamenta perfecta de trotador
20018	pellejo de pardo zarpira
20019	diente de morphaz
20020	fardo de bienes
20021	pendiente pirata de oro
20022	llave azur
20023	trozo codificado
20024	conducto de bilis putrefacto
20025	sangre de morphaz
20026	carne en descomposicion
20027	glandula de trotador sano
20028	polvo relumbrante
20029	coral encantado
20030	roca mascota
20031	mango de esencia
20032	togas de ritual sueltas
20033	toga de endemoniado zandalar
20034	toga de ilusionista zandalar
20035	punta glacial
20036	rubi de fuego
20037	colgante de cristal arcano
20038	aguijon de mandokir
20039	botas hierro negro
20040	diseno botas hierro negro
20041	faja de placas de montanes
20042	faja de laminas de montanes
20043	faja de anillas de montanes
20044	faja de malla de montanes
20045	faja de cuero de montanes
20046	faja de pellejo de lagarto de montanes
20047	faja de pano de montanes
20048	grebas de placas de montanes
20049	grebas de laminas de montanes
20050	grebas de anillas de montanes
20051	grebas de malla de montanes
20052	botas de cuero de montanes
20053	botas de pellejo de lagarto de montanes
20054	botas de pano de montanes
20055	espaldares de anillas de montanes
20056	espaldares de malla de montanes
20057	bufas de placas de montanes
20058	bufas de laminas de montanes
20059	sobrehombros de cuero de montanes
20060	sobrehombros de pellejo de lagarto de montanes
20061	cubrehombros de montanes
20062	racion enriquecida de la cuenca de arathi
20063	racion de campo de la cuenca de arathi
20064	racion de hierro de la cuenca de arathi
20065	venda de tejido magico de la cuenca de arathi
20066	venda de pano runico de la cuenca de arathi
20067	venda de seda de la cuenca de arathi
20068	capa de guardia de la muerte
20069	baston cortezaferrea
20070	garra sabia
20071	dije de arathor
20072	dije de rapinador
20073	capa de guardia de honor
20074	estofado de crocolisco pesado
20075	receta estofado de crocolisco pesado
20076	sello zandalar de mojo
20077	sello zandalar de poderio
20078	sello zandalar de serenidad
20079	espiritu de zanza
20080	brillo de zanza
20081	presteza de zanza
20082	baculo de afliccion
20083	lanza de caza
20084	red de caza
20085	fragmento arcano
20086	cuchillo arrojadizo de acero crepuscular
20087	escamas de descarnador marino
20088	faja de anillas de montanes
20089	faja de anillas de montanes
20090	faja de anillas de montanes
20091	grebas de anillas de montanes
20092	grebas de anillas de montanes
20093	grebas de anillas de montanes
20094	botas de pano de montanes
20095	botas de pano de montanes
20096	botas de pano de montanes
20097	faja de pano de montanes
20098	faja de pano de montanes
20099	faja de pano de montanes
20100	botas de pellejo de lagarto de montanes
20101	botas de pellejo de lagarto de montanes
20102	botas de pellejo de lagarto de montanes
20103	faja de pellejo de lagarto de montanes
20104	faja de pellejo de lagarto de montanes
20105	faja de pellejo de lagarto de montanes
20106	faja de laminas de montanes
20107	faja de laminas de montanes
20108	faja de laminas de montanes
20109	grebas de laminas de montanes
20110	grebas de laminas de montanes
20111	grebas de laminas de montanes
20112	botas de cuero de montanes
20113	botas de cuero de montanes
20114	botas de cuero de montanes
20115	faja de cuero de montanes
20116	faja de cuero de montanes
20117	faja de cuero de montanes
20118	faja de malla de montanes
20119	faja de malla de montanes
20120	faja de malla de montanes
20121	grebas de malla de montanes
20122	grebas de malla de montanes
20123	grebas de malla de montanes
20124	faja de placas de montanes
20125	faja de placas de montanes
20126	faja de placas de montanes
20127	grebas de placas de montanes
20128	grebas de placas de montanes
20129	grebas de placas de montanes
20130	frasco de diamante
20131	tabardo de batalla de los rapinadores
20132	tabardo de batalla de arathor
20134	yelmo furia del cielo
20150	faja de anillas de rapinador
20151	faja de anillas de rapinador
20152	faja de anillas de rapinador
20153	faja de anillas de rapinador
20154	grebas de anillas de rapinador
20155	grebas de anillas de rapinador
20156	grebas de anillas de rapinador
20157	grebas de anillas de rapinador
20158	espaldares de anillas de rapinador
20159	botas de pano de rapinador
20160	botas de pano de rapinador
20161	botas de pano de rapinador
20162	botas de pano de rapinador
20163	faja de pano de rapinador
20164	faja de pano de rapinador
20165	faja de pano de rapinador
20166	faja de pano de rapinador
20167	botas de pellejo de lagarto de rapinador
20168	botas de pellejo de lagarto de rapinador
20169	botas de pellejo de lagarto de rapinador
20170	botas de pellejo de lagarto de rapinador
20171	faja de pellejo de lagarto de rapinador
20172	faja de pellejo de lagarto de rapinador
20173	faja de pellejo de lagarto de rapinador
20174	faja de pellejo de lagarto de rapinador
20175	sobrehombros de pellejo de lagarto de rapinador
20176	cubrehombros de rapinador
20177	faja de laminas de rapinador
20178	faja de laminas de rapinador
20179	faja de laminas de rapinador
20180	faja de laminas de rapinador
20181	grebas de laminas de rapinador
20182	grebas de laminas de rapinador
20183	grebas de laminas de rapinador
20184	bufas de laminas de rapinador
20185	grebas de laminas de rapinador
20186	botas de cuero de rapinador
20187	botas de cuero de rapinador
20188	botas de cuero de rapinador
20189	botas de cuero de rapinador
20190	faja de cuero de rapinador
20191	faja de cuero de rapinador
20192	faja de cuero de rapinador
20193	faja de cuero de rapinador
20194	sobrehombros de cuero de rapinador
20195	faja de malla de rapinador
20196	faja de malla de rapinador
20197	faja de malla de rapinador
20198	faja de malla de rapinador
20199	grebas de malla de rapinador
20200	grebas de malla de rapinador
20201	grebas de malla de rapinador
20202	grebas de malla de rapinador
20203	espaldares de malla de rapinador
20204	faja de placas de rapinador
20205	faja de placas de rapinador
20206	faja de placas de rapinador
20207	faja de placas de rapinador
20208	grebas de placas de rapinador
20209	grebas de placas de rapinador
20210	grebas de placas de rapinador
20211	grebas de placas de rapinador
20212	bufas de placas de rapinador
20213	cinturon de cabezas encogidas
20214	colmillo mental
20215	cinturon de cabezas secas
20216	cinturon de cabezas conservadas
20217	cinturon de cabezas diminutas
20218	capa hakkari descolorida
20219	manteo hakkari andrajoso
20220	baston cortezaferrea
20221	corcel fabuloso
20222	racion enriquecida de rapinador
20223	racion de campo de rapinador
20224	racion de hierro de rapinador
20225	racion enriquecida de montanes
20226	racion de campo de montanes
20227	racion de hierro de montanes
20228	botiquin avanzado de rapinador
20229	botiquin basico de rapinador
20230	botiquin normal de rapinador
20231	botiquin avanzado de arathor
20232	venda de tejido magico de rapinador
20233	botiquin basico de arathor
20234	venda de pano runico de rapinador
20235	venda de seda de rapinador
20236	botiquin normal de arathor
20237	venda de tejido magico de montanes
20243	venda de pano runico de montanes
20244	venda de seda de montanes
20253	patron arnes de oso de guerra
20254	patron prendas de lana de oso de guerra
20255	botas caminasusurro
20256	lazo de sacrificio de la garganta grito de guerra
20257	guanteletes de furia marina
20258	baston ceremonial zulian
20259	guantes de pellejo de pantera de las sombras
20260	leotardos de furia marina
20261	cinturon de pellejo de pantera de las sombras
20262	botas de furia marina
20263	yelmo gurubashi
20264	guanteletes de pacificador
20265	botas de pacificador
20266	leotardos de pacificador
20295	leotardos de dragontina azul
20296	guanteletes de dragontina verde
20310	piel de demonio despellejada
20337	cabeza de gnomo en un palo
20367	equipo de caza
20368	arco anodino de serenidad
20369	punos azurita
20371	huevo murloc azul
20373	aguijon de escorpido latipiedra
20374	aguijon de tenazario latipiedra
20375	aguijon de despellejador latipiedra
20376	colmillo de aracnido de arena
20377	colmillo de acecharrocas
20378	fragmentos de tablilla crepuscular
20379	cartera de noggle
20380	coraza de escamas oniricas
20381	escama onirica
20382	patron coraza de escamas oniricas
20383	cabeza del senor de linaje capazote
20384	trozo de caparazon de silitido
20385	pinza de pinzamorten
20387	traca de bombas fetidas de renegados
20388	chupachus
20389	trigo de caramelo
20390	chocolatina
20391	mascara de gnomo endeble
20392	mascara de gnoma endeble
20393	bolsa de premios
20394	lexicon crepuscular capitulo 1
20395	lexicon crepuscular capitulo 2
20396	lexicon crepuscular capitulo 3
20397	varita sacralizada pirata
20398	varita sacralizada ninja
20399	varita sacralizada gnomo paria
20400	bolsa de calabazas
20401	tablilla crepuscular restaurada
20402	agente de nozdormu
20403	poder de nozdormu
20404	texto crepuscular codificado
20405	trascripcion de tablilla decodificada
20406	manto de cultor crepuscular
20407	toga de cultor crepuscular
20408	capucha de cultor crepuscular
20409	varita sacralizada fantasma
20410	varita sacralizada murcielago
20411	varita sacralizada esqueleto
20413	varita sacralizada aleatorio
20414	varita sacralizada fuego fatuo
20415	la guerra del mar de dunas
20416	blason de senalizacion fuego
20418	blason de senalizacion trueno
20419	blason de senalizacion piedra
20420	blason de senalizacion agua
20422	medallon de estatus de cultor crepuscular
20423	garra de escorpido arenoso
20424	carne de gusano de arena
20425	baston nudoso de consejero
20426	anillo de consejero
20427	capa de curador de batalla
20428	manteo de custodio
20429	sortija de legionario
20430	espada de legionario
20431	anillo del tradicionalista
20432	sello de senalizacion fuego
20433	sello de senalizacion trueno
20434	baston del tradicionalista
20435	sello de senalizacion piedra
20436	sello de senalizacion agua
20437	arco de escolta
20438	arco de avanzado
20439	sortija de protector
20440	espada de protector
20441	hoja de explorador
20442	medallon de explorador
20443	hoja de centinela
20444	medallon de centinela
20447	cetro de senalizacion fuego
20448	cetro de senalizacion trueno
20449	cetro de senalizacion piedra
20450	cetro de senalizacion agua
20451	anillo de nobleza de cultor crepuscular
20452	albondigas del desierto ahumadas
20453	estuche de trascripcion de geologo
20454	calco de colmen zora
20455	calco de colmen ashi
20456	calco de colmen regal
20457	cerebro silitido de colmen ashi
20458	cerebro silitido de colmen zora
20459	cerebro silitido de colmen regal
20460	carta perdida de brann barbabronce
20461	carta perdida de brann barbabronce
20462	medallon de halloween
20463	prisma de cristal con inscripciones
20464	glifos de llamamiento
20465	mecanismo de liberacion de cristal
20466	sello de vyral
20467	pagina de receta rota
20469	recortes de el creyente verdadero descifrados
20475	gema de alma
20476	brazales acecharenas
20477	guanteletes acecharenas
20478	coraza acecharenas
20479	coraza escupefuego
20480	guanteletes escupefuego
20481	brazales escupefuego
20485	sello del duque
20487	lok delar baculo de los guardianes ancianos dep
20488	rhok delar arco de los guardianes ancianos dep
20489	corona del consejo
20490	menta de forjaz
20491	menta de entranas
20492	turron de ventormenta
20493	almendrados de orgrimmar
20494	gominola de gnomeregan
20495	gominola lanza negra
20496	mazapan de darnassus
20497	mazapanes de cima del trueno
20498	quitina de silitido
20499	quitina de escorpido rota
20500	caparazon de silitido ligero
20501	caparazon de silitido pesado
20502	escudo cortezaferrea
20503	espiritu de agua enamorado
20504	hoja forjada con luz
20505	sello caballeresco
20506	patron brazales escupefuego
20507	patron guanteletes escupefuego
20508	patron coraza escupefuego
20509	patron brazales acecharenas
20510	patron guanteletes acecharenas
20511	patron coraza acecharenas
20512	orbe santificado
20513	blason abisal
20514	sello abisal
20515	cetro abisal
20516	manzana de halloween
20517	sobrehombros acero afilado
20518	pergamino crear blason de senalizacion
20519	sombrero de pirata de los mares del sur
20520	runa oscura
20521	visor de furia
20522	baston feral
20524	leotardos pielsombra
20525	sigilo terraneo
20526	pergamino crear blason de senalizacion
20527	pergamino crear blason de senalizacion
20528	pergamino crear blason de senalizacion
20530	togas de servidumbre
20531	pergamino crear sello de senalizacion
20532	pergamino crear sello de senalizacion
20533	pergamino crear sello de senalizacion
20534	fragmento abisal
20535	pergamino crear sello de senalizacion
20536	cosechador de almas
20537	botas runicas estigias
20538	leotardos runicos estigios
20539	cinturon runico estigio
20540	pergamino crear cetro de senalizacion
20541	texto descifrado crepuscular
20542	pergamino crear cetro de senalizacion
20543	pergamino crear cetro de senalizacion
20544	pergamino crear cetro de senalizacion
20545	texto descifrado crepuscular
20546	patron leotardos runicos estigios
20547	patron botas runicas estigias
20548	patron cinturon runico estigio
20549	guanteletes runaoscura
20550	coraza runaoscura
20551	yelmo runaoscura
20552	texto descifrado crepuscular
20553	diseno guanteletes runaoscura
20554	diseno coraza runaoscura
20555	diseno yelmo runaoscura
20556	baston salvaje
20557	golosinas de calabaza de halloween
20558	marca de honor de la garganta grito de guerra
20559	marca de honor de la cuenca de arathi
20560	marca de honor del valle de alterac
20561	mascara de enano endeble
20562	mascara de enana endeble
20563	mascara de elfa de la noche endeble
20564	mascara de elfo de la noche endeble
20565	mascara de humana endeble
20566	mascara de humano endeble
20567	mascara de trol hembra endeble
20568	mascara de trol macho endeble
20569	mascara de orco hembra endeble
20570	mascara de orco endeble
20571	mascara de tauren hembra endeble
20572	mascara de tauren macho endeble
20573	mascara de no muerto endeble
20574	mascara de no muerta endeble
20575	guerrera de cria negra
20576	patron guerrera de cria negra
20577	hoja pesadilla
20578	colmillo dragon esmeralda
20579	capa de piel de dragon verde
20580	martillo de furia bestial
20581	baston de crecimiento desenfrenado
20582	piedra de trance
20583	mascara de enana robusta
20584	mascara de gnomo hembra robusta
20585	mascara de mujer robusta
20586	mascara de elfa de la noche robusta
20587	mascara de orco hembra robusta
20588	mascara de tauren hembra robusta
20589	mascara de trol hembra robusta
20590	mascara de no muerta robusta
20591	mascara de enano robusta
20592	mascara de gnomo robusta
20593	mascara de hombre robusta
20594	mascara de elfo de la noche robusta
20595	mascara de orco robusta
20596	mascara de tauren robusta
20597	mascara de trol robusta
20598	mascara de no muerto robusta
20599	ballesta de maderaferrea pulida
20600	sello de malfurion
20601	saco de botin
20602	cofre de residuos
20603	bolsa de botin
20604	limpiador de bomba fetida
20605	huevos podridos
20606	pluma vudu ambar
20607	pluma vudu azul
20608	pluma vudu verde
20609	plumas vudu
20610	ojo de arana tirosangre
20611	garra negra gruesa
20612	piedra de la plaga inerte
20613	madera putrefacta
20614	esencia de veneno de sangre
20615	brazaletes de espuelas de dragon
20616	guardamunecas de hueso de dragon
20617	antiguos leotardos corroidos
20618	guantes de poder ilusorio
20619	grebas con inscripciones de acido
20620	piedra de poderio sagrada
20621	botas de la llanura eterna
20622	collar de corazon de dragon
20623	aro de suenos inquietos
20624	anillo del inerte
20625	cinturon de la cienaga oscura
20626	braciles de corteza negra
20627	pantalones de corazon oscuro
20628	almete crecimiento descarriado
20629	guardapies malignos
20630	guanteletes de la luz brillante
20631	zapatillas de mendigo
20632	sortija de lagrima mental
20633	bufas de cuero artificial
20634	botas de miedo
20635	vestimentas decoradas con jade
20636	cristal de hibernacion
20637	espaldares con inscripciones de acido
20638	leotardos de la mente demente
20639	quijotes con extranas inscripciones
20640	cubo de cabezas de los mares del sur
20641	botas de mojo de los mares del sur
20642	guerrera de noble anticuada
20643	gorro de reservista de entranas
20644	objeto envuelto en pesadillas
20645	susurro de la naturaleza
20646	marca de correarenas
20647	daga de cristal negro
20648	martillo forjado en frio
20649	colgante prisma de sol
20650	guanteletes del viento del desierto
20651	huevo murloc naranja
20652	zapatillas de pano abisal
20653	guanteletes de placas abisales
20654	baston de guerra amatista
20655	manijas de pano abisal
20656	escarpes de malla abisal
20657	estilete con punta de cristal
20658	botas de cuero abisal
20659	manoplas de malla abisal
20660	guja cortapiedras
20661	guantes de cuero abisal
20662	grebas de placas abisales
20663	arco tiro profundo
20664	fajin de pano abisal
20665	leotardos de cuero abisal
20666	martillo de guerra de acero endurecido
20667	cinturon de cuero abisal
20668	musleras de malla abisal
20669	mandoble rocanegra
20670	agarre de malla abisal
20671	quijotes de placas abisales
20672	varita de cristal chispeante
20673	faja de placas abisales
20674	pantalones de pano abisal
20675	creador de almas
20676	texto descifrado crepuscular
20677	texto descifrado crepuscular
20678	texto descifrado crepuscular
20679	texto descifrado crepuscular
20680	espaldares de malla abisal
20681	brazales de cuero abisal
20682	sortija de enfoque elemental
20683	cubrehombros de placas abisales
20684	guardabrazos de cuero abisal
20685	collar rompeolas
20686	amito de pano abisal
20687	avambrazos de placas abisales
20688	guarda terranea
20689	sobrehombros de cuero abisal
20690	braciles de pano abisal
20691	manteo cortaviento
20692	sortija multicolor
20693	capa pesada
20694	orbe negro resplandeciente
20695	cuentas de guerra abisales
20696	gran maza de cristal con pinchos
20697	manteo tejido cristalino
20698	hoja elemental armonizada
20699	quijotes de reservista cenarion
20700	quijotes de reservista cenarion
20701	musleras de reservista cenarion
20702	musleras de reservista cenarion
20703	leotardos de reservista cenarion
20704	leotardos de reservista cenarion
20705	pantalones de reservista cenarion
20706	pantalones de reservista cenarion
20707	pantalones de reservista cenarion
20708	valija bien sellada
20709	ron rumsey blanco
20710	grebas taraceadas con cristal
20711	grebas con lineas de cristal
20712	guanteletes de transitayermos
20713	guanteletes de acechadesiertos
20714	botas tormenta de arena
20715	botas de acechadunas
20716	guantes de piel de gusano de arena
20717	guantes flor del desierto
20720	hoja susurro oscuro
20721	sortija del cultor
20722	lanzababosa de cristal
20723	pico de confianza de brann
20724	baston del bosque negro corrupto
20725	cristal nexo
20726	formula encantar guantes amenaza
20727	formula encantar guantes poder de las sombras
20728	formula encantar guantes poder de escarcha
20729	formula encantar guantes poder de fuego
20730	formula encantar guantes poder de sanacion
20731	formula encantar guantes agilidad excelente
20732	formula encantar capa resistencia al fuego superior
20733	formula encantar capa resistencia a la naturaleza superior
20734	formula encantar capa sigilo
20735	formula encantar capa sutileza
20736	formula encantar capa esquivar
20737	piedra nuclearia chamuscada
20741	totem de ritual muertobosque
20742	totem de ritual nevada
20744	aceite de zahori menor
20745	aceite de mana menor
20746	aceite de zahori inferior
20747	aceite de mana inferior
20748	aceite de mana luminoso
20749	aceite de zahori luminoso
20750	aceite de zahori
20752	formula aceite de mana menor
20753	formula aceite de zahori inferior
20754	formula aceite de mana inferior
20755	formula aceite de zahori
20756	formula aceite de zahori luminoso
20757	formula aceite de mana luminoso
20758	formula aceite de zahori menor
20761	receta transmutar fuego elemental
20763	arma rota
20766	bolsa babosa
20767	bolsa cubierta de suciedad
20768	bolsa de mocos
20769	moquillo desagradable
20770	icor verde burbujeante
20800	distintivo de logistica cenarion
20801	distintivo de tactica cenarion
20802	distintivo de combate cenarion
20803	ordenes de batalla crepusculares
20805	seguimiento del encargo de logistica
20806	informe de tareas logisticas x
20807	informe de tareas logisticas i
20808	encargo de combate
20809	encargo de tactica
20810	documentacion de instruccion de campo firmada
20814	daga arrojadiza del maestro
20834	catalejo xt ornamentado
20844	veneno mortal v
20858	escarabajo de piedra
20859	escarabajo de oro
20860	escarabajo de plata
20861	escarabajo de bronce
20862	escarabajo de cristal
20863	escarabajo de terracota
20864	escarabajo de hueso
20865	escarabajo de marfil
20866	idolo azur
20867	idolo de onice
20868	idolo luminiscente
20869	idolo de ambar
20870	idolo de jaspe
20871	idolo de obsidiana
20872	idolo bermellon
20873	idolo de alabastro
20874	idolo del sol
20875	idolo de la noche
20876	idolo de muerte
20877	idolo del sabio
20878	idolo de renacer
20879	idolo de la vida
20881	idolo de la disputa
20882	idolo de la guerra
20883	joya qiraji con inscripciones
20884	anillo qiraji magistral
20885	manton qiraji marcial
20886	puno con pinchos qiraji
20887	joya qiraji grabada
20888	anillo ceremonial qiraji
20889	manton qiraji regio
20890	empunadura qiraji ornamentada
20908	fuegos artificiales del festival de nian
20926	aro de vek nilash
20927	pellejo intacto de ouro
20928	ataduras de mando qiraji
20929	caparazon del dios antiguo
20930	diadema de vek lor
20931	piel del gran gusano de arena
20932	ataduras de dominancia qiraji
20933	coraza del dios antiguo
20936	joya qiraji bendita
20937	joya qiraji encerrada
20939	informe de tareas logisticas ii
20940	informe de tareas logisticas iii
20941	informe de tareas de combate xii
20942	informe de tareas de combate iii
20943	instrucciones de la mision tactica x
20944	instrucciones de la mision tactica ix
20945	instrucciones de la mision tactica ii
20946	instrucciones de la mision tactica iii
20947	instrucciones de la mision tactica iv
20948	instrucciones de la mision tactica v
20949	libro de contabilidad magico
20951	gafas de vision de narain
21023	fabulosas chuletillas de quimerok de dirge
21024	solomillo de quimerok
21025	receta fabulosas chuletillas de quimerok de dirge
21027	cadaver de lakmaeran
21028	pollo de 500 kilos
21029	carta de rescate
21030	tarta de kimchi de darnassus
21031	kimchi de repollo
21032	carta de amor de meridith
21033	rabano kimchi
21037	mapa rudimentario
21038	bola de nieve prieta
21039	turbante de narain
21040	toga de narain
21041	bolsa de oro
21042	equipo especial de narain
21043	sobre misterioso
21071	sabiola cruda
21072	sabiola ahumada
21099	receta sabiola ahumada
21100	moneda de linaje
21103	draconico para torpes
21104	draconico para torpes
21105	draconico para torpes
21106	draconico para torpes
21107	draconico para torpes
21108	draconico para torpes
21109	draconico para torpes
21110	draconico para torpes
21111	draconico para torpes volumen ii
21112	encuadernacion de libro magico
21113	valija hermetica
21114	ron rumsey dorado
21115	dije de rapinador
21116	dije de rapinador
21117	dije de arathor
21118	dije de arathor
21119	dije de arathor
21120	dije de rapinador
21126	aguijon de la muerte
21128	baston de los profetas qiraji
21130	diario de weavil
21131	seguimiento del encargo de combate
21132	encargo de logistica
21133	seguimiento del encargo tactico
21134	filo oscuro de la locura
21135	hacha arrojadiza de asesino
21136	boya de arcanita
21137	fragmento de cetro azul
21138	fragmento de cetro rojo
21139	fragmento de cetro verde
21140	papel y sobres para cartas de subasta
21141	fragmento de cetro rojo destruido
21142	de la mesa de lord victor nefarius
21143	documentacion de instruccion de campo sin firmar
21144	antorcha para invocar demonios
21145	esencia de xandivious
21146	fragmento de corrupcion de pesadilla
21147	fragmento de corrupcion de pesadilla
21148	fragmento de corrupcion de pesadilla
21149	fragmento de corrupcion de pesadilla
21150	valija reforzada con hierro
21151	ron rumsey etiqueta negra
21152	la corrupcion de pesadilla
21153	sabiola cruda superior
21154	vestido de fiesta
21155	ofrenda de paz de los fauces de madera
21156	bolsa escarabajo
21157	vestido de fiesta verde
21158	informe de exploracion de colmen zora
21159	ordenes de explorador de colmen zora
21160	informe de exploracion de colmen regal
21161	informe de exploracion de colmen ashi
21162	bocanegra graso hinchado
21163	pargo de fuego hinchado
21164	bacalao piedrescama hinchado
21165	instrucciones de la mision tactica vi
21166	instrucciones de la mision tactica vii
21167	instrucciones de la mision tactica viii
21168	cria de tiburon
21171	jarra festiva llena
21173	jarra festiva vacia
21174	jarra festiva vacia
21175	el cetro del mar de dunas
21176	cristal resonador negro qiraji
21177	simbolo de reyes
21178	guantes de poder de la tierra
21179	sortija de colera de tierra
21180	golpe de tierra
21181	gracia de la tierra
21182	sortija de poder terraneo
21183	jubon poder terrenal
21184	brazales de roca profunda
21185	orbe calmaterra
21186	brazales de furia de roca
21187	capa de tejido de tierra
21188	puno de cenarius
21189	poderio de cenarius
21190	colera de cenarius
21191	presente envuelto con cuidado
21193	saco de el saco
21194	saco grande de el saco
21195	sactastico de el saco
21196	sello del vuelo bronce
21197	sello del vuelo bronce
21198	sello del vuelo bronce
21199	sello del vuelo bronce
21200	sello del vuelo bronce
21201	sello del vuelo bronce
21202	sello del vuelo bronce
21203	sello del vuelo bronce
21204	sello del vuelo bronce
21205	sello del vuelo bronce
21206	sello del vuelo bronce
21207	sello del vuelo bronce
21208	sello del vuelo bronce
21209	sello del vuelo bronce
21210	sello del vuelo bronce
21211	faltriquera de polvo de reno
21212	acebo fresco
21213	acebo en conserva
21214	escrito sobre descarga de escarcha xi
21215	pastel de macedonia y carne de graccu
21216	obsequio megaespecial de pastos de bosquehumeante
21217	delicia de sabiola
21218	cristal resonador qiraji azul
21219	receta delicia de sabiola
21220	cabeza de osirio el sinmarcas
21221	ojo de c thun
21222	quitina blindada
21223	piedra negra
21224	trozo de armadura antigua
21225	coraza pesada de silitido
21226	piedra runica
21227	craneo de heroe antiguo
21228	valija reforzada con mitril
21229	insignia de senor qiraji
21230	artefacto qiraji antiguo
21232	armamentos imperiales qiraji
21235	asado del festival de invierno
21236	pan del festival de invierno
21237	atavio imperial qiraji
21240	dulce de festival de invierno
21241	ponche de huevo del festival de invierno
21242	hacha de guerra qiraji bendita
21243	vigorpez hinchado
21244	pugio qiraji bendito
21245	instrucciones de la mision tactica i
21246	informe de tareas de combate i
21247	informe de tareas de combate ii
21248	informe de tareas de combate iv
21249	informe de tareas de combate v
21250	informe de tareas de combate vi
21251	informe de tareas de combate vii
21252	informe de tareas de combate viii
21253	informe de tareas de combate ix
21254	galleta de festival de invierno
21255	informe de tareas de combate x
21256	informe de tareas de combate xi
21257	informe de tareas logisticas iv
21258	informe de tareas logisticas iv
21259	informe de tareas logisticas v
21260	informe de tareas logisticas vi
21261	informe de tareas logisticas vi
21262	informe de tareas logisticas viii
21263	informe de tareas logisticas vii
21264	informe de tareas logisticas vii
21265	informe de tareas logisticas ix
21266	encargo de logistica
21267	caliz de brindis
21268	martillo de guerra qiraji bendito
21269	baluarte qiraji bendito
21270	obsequio ligeramente agitado
21271	obsequio ligeramente agitado
21272	mosquete qiraji bendito
21273	baston de acolito qiraji bendito
21275	baston de augur qiraji bendito
21277	yeti mecanico tranquilo
21278	guantes de embozo de tormenta
21279	escrito sobre bola de fuego xii
21280	escrito sobre misiles arcanos viii
21281	grimorio descarga de las sombras x
21282	grimorio inmolar viii
21283	grimorio corrupcion vii
21284	codice de sanacion superior v
21285	codice de renovar x
21287	codice de rezo de sanacion v
21288	tratado bendicion de sabiduria vi
21289	tratado bendicion de poderio vii
21290	tratado luz sagrada ix
21291	tablilla de ola de sanacion x
21292	tablilla de totem fuerza de la tierra v
21293	tablilla de totem gracia del aire iii
21294	libro sobre toque de sanacion xi
21295	libro sobre fuego estelar vii
21296	libro sobre rejuvenecimiento xi
21297	manual de golpe heroico ix
21298	manual de grito de batalla vii
21299	manual de revancha vi
21300	vademecum de punalada ix
21301	caja de ayudante verde
21302	vademecum de veneno mortal v
21303	vademecum de amago v
21304	guia multidisparo v
21305	caja de ayudante roja
21306	guia picadura de serpiente ix
21307	guia aspecto del halcon vii
21308	campanita alegre
21309	equipo de muneco de nieve
21310	presente con envoltorio alegre
21311	jubon del guardian de la tierra
21312	cinturon del vigia del cubil
21313	bolsa pequena de el saco
21314	cartas y notas de metzen
21315	cartera de bosquehumeante
21316	leotardos de ursa
21317	yelmo del abrecaminos
21318	guantes del guardian de la tierra
21319	guantes del abrecaminos
21320	jubon del vigia del cubil
21321	cristal resonador qiraji rojo
21322	abrazo de ursa
21323	cristal resonador qiraji verde
21324	cristal resonador qiraji amarillo
21325	grinch mecanico
21326	defensor de los fauces de madera
21327	presente que hace tic tac
21328	varita de felicidad del recreo
21329	corona de conquistador
21330	bufas de conquistador
21331	coraza de conquistador
21332	musleras de conquistador
21333	grebas de conquistador
21334	togas de clamacondenas
21335	manto de clamacondenas
21336	calzas de clamacondenas
21337	aro de clamacondenas
21338	borceguies de clamacondenas
21340	faltriquera de almas
21341	bolsa de tela vil
21342	bolsa de tela vil del nucleo
21343	togas enigma
21344	botas enigma
21345	hombreras enigma
21346	leotardos enigma
21347	aro enigma
21348	tiara del oraculo
21349	borceguies del oraculo
21350	manto del oraculo
21351	vestimentas del oraculo
21352	calzas del oraculo
21353	yelmo genesis
21354	hombreras genesis
21355	botas genesis
21356	calzas genesis
21357	jubon genesis
21358	patron faltriquera de almas
21359	botas de mortifero
21360	yelmo de mortifero
21361	bufas de mortifero
21362	leotardos de mortifero
21363	obsequio festivo
21364	jubon de mortifero
21365	guardapies de asediador
21366	diadema de asediador
21367	espaldares de asediador
21368	leotardos de asediador
21369	patron bolsa de tela vil
21370	camisote de asediador
21371	patron bolsa de tela vil del nucleo
21372	diadema de clamatormentas
21373	guardapies de clamatormentas
21374	camisote de clamatormentas
21375	leotardos de clamatormentas
21376	espaldares de clamatormentas
21377	pluma de penacho de muertobosque
21378	informe de tareas logisticas i
21379	informe de tareas logisticas ii
21380	informe de tareas logisticas iii
21381	informe de tareas logisticas ix
21382	informe de tareas logisticas v
21383	cuentas de espiritu nevada
21384	informe de tareas logisticas viii
21385	informe de tareas logisticas x
21386	seguimiento del encargo de logistica
21387	corona del vengador
21388	grebas del vengador
21389	coraza del vengador
21390	musleras del vengador
21391	espaldares del vengador
21392	hoz de fuerza implacable
21393	sello de fuerza implacable
21394	manton de fuerza implacable
21395	hoja de justicia eterna
21396	anillo de justicia eterna
21397	manteo de justicia eterna
21398	martillo de la tormenta inminente
21399	anillo de la tormenta inminente
21400	capa de la tormenta inminente
21401	guadana de la senda oculta
21402	sello de la senda oculta
21403	capa de la senda oculta
21404	daga de las sombras ocultas
21405	sortija de las sombras ocultas
21406	capa de las sombras ocultas
21407	maza de vida inagotable
21408	sortija de vida inagotable
21409	capa de vida inagotable
21410	mazo de sabiduria infinita
21411	anillo de sabiduria infinita
21412	embozo de sabiduria infinita
21413	hoja de secretos oscuros
21414	sortija de secretos oscuros
21415	manton de secretos oscuros
21416	kris de los nombres prohibidos
21417	anillo de los nombres prohibidos
21418	embozo de los nombres prohibidos
21436	sello de mencion de honor de la alianza
21438	sello de mencion de honor de la horda
21452	baston de las ruinas
21453	manto de los horusath
21454	sobrehombros de piedra runica
21455	yelmo viento del sur
21456	capa tormenta de arena
21457	brazales de brutalidad
21458	guanteletes de nueva vida
21459	ballesta de fatalidad inminente
21460	yelmo de dominacion
21461	leotardos de la ventisca negra
21462	guantes de sabiduria oscura
21463	brazal de osirio
21464	grilletes del sinmarcas
21466	aguijon de ayamiss
21467	coselete de silitido grueso
21468	manto de maz nadir
21469	guanteletes de viento del sur
21470	capa del salvador
21471	garfa de concentracion de furia
21472	turbante viento polvoriento
21473	ojo de moam
21474	guardahombros de quitina
21475	quijotes del destructor
21476	leotardos escamados de obsidiana
21477	anillo de furia
21478	arco de tendon tenso
21479	guanteletes del inamovible
21480	guanteletes de silitido escamados
21481	botas del protector del desierto
21482	botas de las arenas igneas
21483	anillo de los vientos del desierto
21484	yelmo de recrecimiento
21485	trozo de la calavera de buru
21486	guantes del enjambre
21487	guanteletes escamados babosos
21488	fetiche de pinchos de quitina
21489	botas de arenas movedizas
21490	chanclos para babosas
21491	brazales escamados del gloton
21492	destripahombres de los qiraji
21493	botas de la soldado de caballeria
21494	garra viento del sur
21495	quijotes del comando qiraji
21496	brazales de orden qiraji
21497	botas del general qiraji
21498	daga qiraji de sacrificios
21499	vestimentas del mar de dunas
21500	cinturon de la inquisicion
21501	guantes de pellejo de silitido fortalecido
21502	guardamunecas de atracador de arena
21503	cinturon del atracador de arena
21504	talisman del mar de dunas
21505	gargantilla del mar de dunas
21506	colgante del mar de dunas
21507	amuleto del mar de dunas
21508	marca de cenarius
21509	suministros del esfuerzo de guerra de ahn qiraj
21510	suministros del esfuerzo de guerra de ahn qiraj
21511	suministros del esfuerzo de guerra de ahn qiraj
21512	suministros del esfuerzo de guerra de ahn qiraj
21513	suministros del esfuerzo de guerra de ahn qiraj
21514	informe de tareas logisticas xi
21515	marca de remulos
21517	turbante de poderio psiquico gnomico
21519	muerdago
21520	legado de cresta cuervo
21521	espada runica de los rojos
21522	pena de cantosombrio
21523	colmillo de korialstrasz
21524	sombrero de invierno rojo
21525	sombrero de invierno verde
21526	sortija de prolavades heladas
21527	togas aguaoscura
21528	bolsa de botin colosal
21529	amuleto de escudo de las sombras
21530	leotardos incrustados de onice
21531	collar de dientes de draco
21532	botas de esclavo
21533	coraza del coloso de zora
21534	coraza del coloso de ashi
21535	coraza del coloso de regal
21536	piedra elunarita
21537	albondigas festivas
21538	vestido de fiesta rosa
21539	vestido de fiesta morado
21540	farol de elune
21541	traje pantalon de fiesta negro
21542	traje de fiesta
21543	traje pantalon de fiesta verde azulado
21544	traje pantalon de fiesta azul
21545	provisiones de bosquehumeante
21546	elixir de poder de fuego superior
21547	receta elixir de poder de fuego superior
21548	patron guantes de embozo de tormenta
21552	serviola a rayas
21557	cohete rojo pequeno
21558	cohete azul pequeno
21559	cohete verde pequeno
21560	cohete morado pequeno
21561	cohete blanco pequeno
21562	cohete amarillo pequeno
21563	sortija de don rodrigo
21565	runa de perfeccion
21566	runa de perfeccion
21567	runa de deber
21568	runa de deber
21569	lanzador de fuegos artificiales
21570	lanzatracas
21571	traca de cohetes azules
21574	traca de cohetes verdes
21575	traca de cohetes morados
21576	traca de cohetes rojos
21577	traca de cohetes blancos
21578	traca de cohetes amarillos
21579	tentaculo derrotado de c thun
21581	guanteletes de aniquilacion
21582	garra del dios antiguo
21583	capa de claridad
21584	brazales de juicio eterno
21585	guanteletes de tormenta oscura
21586	cinturon de agonia interminable
21587	guardamunecas de castigo
21588	guardamunecas de furia elemental
21589	cohete azul grande
21590	cohete verde grande
21591	cohete morado grande
21592	cohete rojo grande
21593	cohete blanco grande
21594	brazales del hijo caido
21595	cohete amarillo grande
21596	anillo del destripadioses
21597	cetro real de vek lor
21598	cinturon qiraji real
21599	guantes de devastacion de vek lor
21600	botas de epifania
21601	anillo del emperador vek lor
21602	brazales qiraji de ejecucion
21603	varita de nobleza qiraji
21604	pulseras de redencion real
21605	guantes del templo oculto
21606	cinturon del emperador caido
21607	garra del emperador caido
21608	amuleto de vek nilash
21609	cinturon regenerador de vek nilash
21610	bloqueador de escamas de gusano
21611	brazales de escarbador
21612	apisonadoras de escamas de gusano
21613	botas de pellejo de gusano
21614	protector de pellejo de gusano
21615	sombrero perdido de don rigoberto
21616	aguijon de huhuran
21617	guanteletes de pellejo de avispa
21618	guardamunecas de colmena rapinador
21619	guantes del mesias
21620	anillo del martir
21621	capa de la colmena dorada
21622	femur de silitido afilado
21623	guanteletes de campeon recto
21624	guanteletes de kalimdor
21625	broche escarabajo
21626	leotardos cubiertos de baba
21627	capa de los secretos ocultos
21635	pua del atracador de arena
21639	espaldares del inflexible
21640	paquete de fuegos artificiales del festival lunar
21645	botas de tunelador de colmena
21647	fetiche del atracador de arena
21648	botas recompuestas
21650	destripador qiraji antiguo
21651	leotardos escamados de atracador de arena
21652	coselete caparazon de silitido
21663	togas del santo guardian
21664	gargantilla de puas
21665	manto de la revancha horrenda
21666	poderio de sartura
21667	quijotes de luz llameantes
21668	leotardos escamados de furia qiraji
21669	yelmo parra reptadora
21670	distintivo del guardaenjambres
21671	togas del guardia de batalla
21672	guantes de aplicacion
21673	garra de silitido
21674	guanteletes de determinacion ferrea
21675	cinturon de pellejo qiraji grueso
21676	leotardos del enjambre ulceroso
21677	anillo de furia qiraji
21678	collar de pureza
21679	revancha de kalimdor
21680	jubon de ejecucion presto
21681	anillo de los devorados
21682	guanteletes cubiertos de bilis
21683	manto de la cruzada del desierto
21684	manto de la furia del desierto
21685	escarabajo petrificado
21686	manto de poder frenico
21687	anillo de oscuridad de ukko
21688	botas del heroe caido
21689	guantes de ebru
21690	talisman de angelista
21691	guanteletes de moco
21692	faja de triada
21693	apariencia del devorador
21694	manto ternario
21695	toque de angelista
21696	togas del triunvirato
21697	manteo de la trinidad
21698	leotardos de inmersion
21699	sobrehombros de bombardeo
21700	colgante del guardian qiraji
21701	capa de odio concentrado
21702	amuleto de guarda del mal
21703	martillo de ji zhi
21704	botas de la profecia cumplida
21705	botas del profeta caido
21706	botas de la voluntad inquebrantable
21707	anillo de enjambre de pensamientos
21708	guardamunecas escamados de alfazaques
21709	anillo del dios caido
21710	capa del dios caido
21711	invitacion al festival lunar
21712	amuleto del dios caido
21713	vela de elune
21714	traca de cohetes azules grandes
21715	martillo pulido con arena
21716	traca de cohetes verdes grandes
21717	traca de cohetes morados grandes
21718	traca de cohetes rojos grandes
21719	traca de cohetes blancos grandes
21720	traca de cohetes amarillos grandes
21721	resplandor lunar
21722	patron vestido de fiesta
21723	patron traje de fiesta
21724	esquema cohete azul pequeno
21725	esquema cohete verde pequeno
21726	esquema cohete rojo pequeno
21727	esquema cohete azul grande
21728	esquema cohete verde grande
21729	esquema cohete rojo grande
21730	esquema traca de cohetes azules
21731	esquema traca de cohetes verdes
21732	esquema traca de cohetes rojos
21733	esquema traca de cohetes azules grandes
21734	esquema traca de cohetes verdes grandes
21735	esquema traca de cohetes rojos grandes
21736	riendas de grifo de montar
21737	esquema lanzatracas
21738	esquema lanzador de fuegos artificiales
21740	recetas de cohetes pequenos
21741	recetas de tracas de cohetes
21742	recetas de cohetes grandes
21743	recetas de tracas de cohetes grandes
21744	traca de cohetes de la suerte
21745	piedra lunar de anciano
21746	sobre rojo de la suerte
21747	petardo festivo
21749	informe de tareas de combate i
21750	informe de tareas de combate ii
21751	instrucciones de la mision tactica iii
21761	llave del arca del escarabajo
21762	llave del arca del escarabajo superior
21800	lanzacoraza de silitido
21801	antena de tonificacion
21802	el kris perdido de zedd
21803	yelmo del vengador sagrado
21804	almofar de furia elemental
21805	espaldares de obsidiana pulidos
21806	mazo de autoridad qiraji
21809	furia del enjambre olvidado
21810	botines de nomada errante
21812	caja de bombones
21813	bolsa de caramelos
21814	coraza de aniquilacion
21815	prueba de amor
21816	corazon de caramelo
21817	corazon de caramelo
21818	corazon de caramelo
21819	corazon de caramelo
21820	corazon de caramelo
21821	corazon de caramelo
21822	corazon de caramelo
21823	corazon de caramelo
21829	botella de perfume
21830	envoltorio vacio
21831	obsequio con envoltorio
21833	botella de colonia
21836	anillo de caos de ritssyn
21837	martillo de guerra anubisath
21838	atuendo de ascension real
21839	cetro del falso profeta
21856	neretzek la sedienta de sangre
21888	guantes del inmortal
21889	guantes de la profecia redimida
21890	guantes del profeta caido
21891	fragmento de la estrella caida
21920	carta arrugada
21921	nota escrita con pluma con cuidado
21925	carta inmaculada
21926	nota ligeramente arrugada
21928	muestra de sangre de cuna del invierno
21935	ectoplasma estable
21936	ectoplasma congelado
21937	ectoplasma agostado
21938	nucleo de arrabio
21939	vara elemental vil
21946	destilador ectoplasmico
21960	talla de madera
21975	juramento de adoracion ventormenta
21979	ofrenda de adoracion darnassus
21980	ofrenda de adoracion forjaz
21981	ofrenda de adoracion ventormenta
21982	abalorios de guerra de ogro
21983	estandarte de provocacion incompleto
21984	parte izquierda del amuleto de lord valthalak
21985	contenedor de sangre sellado
21986	estandarte de provocacion
21987	incendicita de lord incendius
21988	ascua del brasadivino
21989	rescoldo de las brasas
21994	cinturon de heroismo
21995	botas de heroismo
21996	brazales de heroismo
21997	coraza de heroismo
21998	guanteletes de heroismo
21999	yelmo de heroismo
22000	quijotes de heroismo
22001	bufas de heroismo
22002	cinturon mantoscuro
22003	botas mantoscuro
22004	brazales mantoscuro
22005	almete mantoscuro
22006	guantes mantoscuro
22007	pantalones mantoscuro
22008	bufas mantoscuro
22009	guerrera mantoscuro
22010	cinturon de maestro de bestias
22011	ataduras de maestro de bestias
22013	almete de maestro de bestias
22014	blandon sacralizado
22015	guantes de maestro de bestias
22016	manto de maestro de bestias
22017	pantalones de maestro de bestias
22046	parte derecha del amuleto lord valthalak
22047	parte superior del amuleto de lord valthalak
22048	amuleto de lord valthalak
22049	blandon de senalizacion
22050	blandon de senalizacion
22051	blandon de senalizacion
22052	blandon de senalizacion
22056	blandon de senalizacion
22057	blandon de invocacion
22058	papel y sobres para cartas de san valentin
22059	tarjeta de san valentin
22060	guerrera de maestro de bestias
22061	botas de maestro de bestias
22062	cinturon de hechicero
22063	ataduras de hechicero
22064	botas de hechicero
22065	corona de hechicero
22066	guantes de hechicero
22067	leotardos de hechicero
22068	manto de hechicero
22069	togas de hechicero
22070	cinturon brumamorta
22071	brazales brumamorta
22072	leotardos brumamorta
22073	manto brumamorta
22074	mascara brumamorta
22075	toga brumamorta
22076	sandalias brumamorta
22077	brazaletes brumamorta
22078	cinturon del virtuoso
22079	brazales del virtuoso
22080	corona del virtuoso
22081	guantes del virtuoso
22082	manto del virtuoso
22083	toga del virtuoso
22084	zapatos del virtuoso
22085	saya del virtuoso
22086	cinturon forjaalma
22087	botas forjaalma
22088	brazales forjaalma
22089	coraza forjaalma
22090	guanteletes forjaalma
22091	yelmo forjaalma
22092	quijotes forjaalma
22093	bufas forjaalma
22094	alga de sangre
22095	ataduras de los cinco truenos
22096	botas de los cinco truenos
22097	almofar de los cinco truenos
22098	cordon de los cinco truenos
22099	guanteletes de los cinco truenos
22100	falda de los cinco truenos
22101	espaldares de los cinco truenos
22102	jubon de los cinco truenos
22106	cinturon cuoroferal
22107	botas cuoroferal
22108	brazales cuoroferal
22109	capucha cuoroferal
22110	guantes cuoroferal
22111	falda cuoroferal
22112	bufas cuoroferal
22113	jubon cuoroferal
22114	huevo murloc rosa
22115	detector de fantasmas extradimensional
22117	juramento de lealtad ventormenta
22119	juramento de lealtad forjaz
22120	juramento de lealtad darnassus
22121	juramento de lealtad entranas
22122	juramento de lealtad cima del trueno
22123	juramento de lealtad orgrimmar
22130	simbolo de amor
22131	coleccion de obsequios de ventormenta
22132	coleccion de obsequios de forjaz
22133	coleccion de obsequios de darnassus
22134	coleccion de obsequios de entranas
22135	coleccion de obsequios de cima del trueno
22136	coleccion de obsequios de orgrimmar
22137	cartera de ysida
22138	brazal roca negra
22139	guardapelo de ysida
22140	tarjeta de centinela
22141	tarjeta de guardia de forjaz
22142	tarjeta de bruto
22143	tarjeta de guardia de ventormenta
22144	tarjeta de vigia de la cima
22145	tarjeta mohosa de guardian
22149	cuentas de mojo de ogro
22150	cuentas de poderio de ogro
22151	agua bendita de anthion
22152	faltriquera de anthion
22154	juramento de adoracion forjaz
22155	juramento de adoracion darnassus
22156	juramento de adoracion orgrimmar
22157	juramento de adoracion entranas
22158	juramento de adoracion cima del trueno
22159	juramento de amistad darnassus
22160	juramento de amistad forjaz
22161	juramento de amistad orgrimmar
22162	juramento de amistad cima del trueno
22163	juramento de amistad entranas
22164	ofrenda de adoracion orgrimmar
22165	ofrenda de adoracion cima del trueno
22166	ofrenda de adoracion entranas
22167	ofrenda de amistad darnassus
22168	ofrenda de amistad forjaz
22169	ofrenda de amistad orgrimmar
22170	ofrenda de amistad ventormenta
22171	ofrenda de amistad cima del trueno
22172	ofrenda de amistad entranas
22173	cerveza casera enana
22174	poema romantico
22175	tarta recien horneada
22176	pan casero
22177	flores recien cogidas
22178	juramento de amistad ventormenta
22191	guerrera de malla de obsidiana
22192	elixir de esquivez de alga de sangre
22193	elixir de resistencia de alga de sangre
22194	garra negra del destructor
22195	cinturon de obsidiana ligero
22196	coraza gruesa de obsidiana
22197	cinturon de obsidiana pesado
22198	escudo dentado de obsidiana
22200	flecha con astil de plata
22201	relicario de pureza
22202	fragmento de obsidiana pequeno
22203	fragmento de obsidiana grande
22204	guardamunecas de renombre
22205	ataduras de acero negro
22206	ramo de rosas rojas
22207	fajin del gran cazador
22208	martillo de piedra de lava
22209	diseno cinturon de obsidiana pesado
22212	espaldares a medida golem
22214	diseno cinturon de obsidiana ligero
22216	glandula de veneno de venoxis
22217	glandula de veneno de kurinnaxx
22218	punado de petalos de rosa
22219	diseno escudo dentado de obsidiana
22220	diseno garra negra del destructor
22221	diseno guerrera de malla de obsidiana
22222	diseno coraza gruesa de obsidiana
22223	protector de cabeza de supervisor
22224	esencia de espectro bufon
22225	capucha de piel de dragon
22226	restos druidas
22227	reliquia de aldea brisaestelar
22228	espada luminosa de zelote
22229	cenizas de alma del desterrado
22230	pellejo morromiedo
22231	botas de precision de kayser
22232	faja de tirador
22233	baul de zigris
22234	manto de esperanza perdida
22235	flecha con astil de veraplata
22236	delicia de leche
22237	deseo oscuro
22238	crema de frutos cremosa
22239	dulce sorpresa
22240	grebas de desesperacion fulminante
22241	espaldares de depositario oscuro
22242	correa de verek
22243	faltriquera de almas pequena
22244	caja de almas
22245	calzado taraceado con hollin
22246	faltriquera de tejido magico encantada
22247	botas de curador de fe
22248	bolsa de pano runico encantada
22249	bolsa de encantamiento grande
22250	faltriquera de hierbas
22251	bolsa de hierbas cenarion
22252	cartera de cenarius
22253	escrito de los perdidos
22254	varita de luz eterna
22255	sortija forjada de magma
22256	manijas para moldear mana
22257	sortija de coagulo de sangre
22258	pocion de amor
22259	pulsera de amistad no depositada
22260	pulsera de la amistad
22261	loco de amor
22262	coleccion de obsequios de la alianza
22263	coleccion de obsequios de la horda
22264	carta escrita con cuidado
22265	carta escrita con amor
22266	erupcion de espinas
22267	turbante de tejido de hechizos
22268	emblema draconico imbuido
22269	capa de merodeador de las sombras
22270	botas de atrincheramiento
22271	leotardos de magia frenetica
22272	abrazo del bosque
22273	caperuza sombra lunar
22274	pelambre grisacea
22275	botas musgo de fuego
22276	vestido rojo precioso
22277	traje de noche rojo
22278	vestido azul precioso
22279	vestido negro precioso
22280	vestido morado precioso
22281	traje de noche azul
22282	traje de noche morado
22283	saco de pan casero
22284	fardo de tarjetas
22285	coleccion de juramentos de ventormenta
22286	coleccion de juramentos de forjaz
22287	caja de tarjetas
22288	caja de cerveza casera
22289	monton de tarjetas
22290	coleccion de juramentos de darnassus
22291	caja de talla de madera
22292	caja de tartas recientes
22293	paquete de tarjetas
22294	coleccion de juramentos de orgrimmar
22295	cartera de tarjetas
22296	cesta de flores
22297	coleccion de juramentos de cima del trueno
22298	libro de poemas romanticos
22299	fajo de tarjetas
22300	coleccion de juramentos de entranas
22301	toga de tejido de hierro
22302	capucha de tejido de hierro
22303	pantalones de tejido de hierro
22304	guantes de tejido de hierro
22305	manto de tejido de hierro
22306	cinturon de tejido de hierro
22307	patron faltriquera de tejido magico encantada
22308	patron bolsa de pano runico encantada
22309	patron bolsa de encantamiento grande
22310	patron bolsa de hierbas cenarion
22311	botas de tejido de hierro
22312	patron cartera de cenarius
22313	brazales de tejido de hierro
22314	arpon de cazador
22315	martillo de revitalizacion
22317	nudillos de laton de zurdito
22318	arco largo de malgen
22319	escrito sobre derecho divino
22320	viveres de calidad de mux
22321	corazon de vermisthalak
22322	el rompe mandibulas
22324	kimchi de invierno
22325	cinturon del timador
22326	sortija de amalgama
22327	amuleto de los redimidos
22328	quijotes de vigilancia
22329	cetro de enfoque interminable
22330	embozo de maestria arcana
22331	sortija del heroe ferreo
22332	hoja de nigromancia
22333	martillo de poderio divino
22334	sortija de alivio
22335	baston de mando de lord valthalak
22336	egida draconiana de la legion
22337	embozo de dominacion
22338	ceniza volcanica
22339	sortija runica de hechiceria
22340	colgante de celeridad
22342	leotardos de tormento
22343	manoplas de ferocidad
22344	blandon de invocacion manual
22345	totem de renacer
22347	ballesta de repeticion de recarga de fahrad
22348	prima de condemulus
22349	coraza profanada
22350	guerrera profanada
22351	toga profanada
22352	quijotes profanados
22353	casco profanado
22354	espaldares profanados
22355	brazales profanados
22356	guardarrenes profanados
22357	guanteletes profanados
22358	escarpes profanados
22359	musleras profanadas
22360	celada profanada
22361	bufas profanadas
22362	guardamunecas profanados
22363	faja profanada
22364	manoplas profanadas
22365	botas profanadas
22366	leotardos profanados
22367	aro profanado
22368	hombreras profanadas
22369	ataduras profanadas
22370	cinturon profanado
22371	guantes profanados
22372	botines profanados
22373	restos de cuero
22374	restos de malla
22375	restos de coraza
22376	restos de ropa
22377	el atizador truenedera
22378	cercenadora ravenholdt
22379	chafarote de shivsprocket
22380	martillo de cultivo de simone
22381	muestra de veneno de silithus
22382	contenedor de veneno sellado
22383	hoja sabia
22384	persuasor
22385	leotardos titanicos
22386	head of instructor razuvious dep
22387	corazon de anub rekhan
22388	diseno leotardos titanicos
22389	diseno hoja sabia
22390	diseno persuasor
22392	formula encantar arma de 2m agilidad
22393	codice rezo de proteccion contra las sombras
22394	baston de metanoia
22395	totem de ira
22396	totem de vida
22397	idolo de ferocidad
22398	idolo de rejuvenecimiento
22399	idolo de salud
22400	tratado sobre verdad
22401	tratado sobre esperanza
22402	tratado sobre gracia
22403	collar de caparazones nacarados
22404	rascaespalda de willey
22405	manto de la cruzada escarlata
22406	redencion
22407	yelmo de la luna nueva
22408	varita de mojo maligno de ritssyn
22409	guerrera de la media luna
22410	guanteletes de ardid
22411	yelmo del verdugo
22412	manto thuzadin
22416	coraza acorator
22417	quijotes acorator
22418	casco acorator
22419	espaldares acorator
22420	escarpes acorator
22421	guanteletes acorator
22422	guardarrenes acorator
22423	brazales acorator
22424	guardamunecas de redencion
22425	guerrera de redencion
22426	manoplas de redencion
22427	musleras de redencion
22428	celada de redencion
22429	bufas de redencion
22430	botas de redencion
22431	faja de redencion
22432	pua de demosaurio
22433	sortija de dominacion de don mauricio
22434	champinon de sangre
22435	aguijon gorishi
22436	guerrera de acechacriptas
22437	musleras de acechacriptas
22438	celada de acechacriptas
22439	bufas de acechacriptas
22440	botas de acechacriptas
22441	manoplas de acechacriptas
22442	faja de acechacriptas
22443	guardamunecas de acechacriptas
22444	vid putrida
22458	baculo sombra lunar
22464	guerrera rompeterra
22465	musleras rompeterra
22466	celada rompeterra
22467	bufas rompeterra
22468	botas rompeterra
22469	manoplas rompeterra
22470	faja rompeterra
22471	guardamunecas rompeterra
22472	botas de ferocidad
22476	coraza segahuesos
22477	quijotes segahuesos
22478	casco segahuesos
22479	espaldares segahuesos
22480	escarpes segahuesos
22481	guanteletes segahuesos
22482	guardarrenes segahuesos
22483	brazales segahuesos
22484	runa necrotica
22488	guerrera caminasuenos
22489	musleras caminasuenos
22490	celada caminasuenos
22491	bufas caminasuenos
22492	botas caminasuenos
22493	manoplas caminasuenos
22494	faja caminasuenos
22495	guardamunecas caminasuenos
22496	toga de fuego de escarcha
22497	leotardos de fuego de escarcha
22498	aro de fuego de escarcha
22499	hombreras de fuego de escarcha
22500	botines de fuego de escarcha
22501	guantes de fuego de escarcha
22502	cinturon de fuego de escarcha
22503	ataduras de fuego de escarcha
22504	toga corazon de peste
22505	leotardos corazon de peste
22506	aro corazon de peste
22507	hombreras corazon de peste
22508	botines corazon de peste
22509	guantes corazon de peste
22510	cinturon corazon de peste
22511	ataduras corazon de peste
22512	toga de fe
22513	leotardos de fe
22514	aro de fe
22515	hombreras de fe
22516	sandalias de fe
22517	guantes de fe
22518	cinturon de fe
22519	ataduras de fe
22520	la filacteria de kel thuzad
22523	insignia de el alba
22524	insignia de la cruzada
22525	trozos de maligno de cripta
22526	trozos de huesos
22527	nucleo de elementos
22528	fragmentos de hierro negro
22529	hojas salvajes
22568	libranza de artesano lacrada
22589	atiesh gran baculo del guardian
22593	libranza de salvoconducto
22595	anuncio del llamamiento a las armas
22600	libranza del artesano contrapeso denso
22601	libranza del artesano peto de placas imperiales
22602	libranza del artesano martillo volcanico
22603	libranza del artesano hacha de batalla de torio enorme
22604	libranza del artesano aro radiante
22605	libranza del artesano cinta de cuero maligno
22606	libranza del artesano refuerzo para armadura basto
22607	libranza del artesano cinturon de cuero maligno
22608	libranza del artesano pantalones de cuero runico
22609	libranza del artesano pantalones de pano brillante
22610	libranza del artesano botas de pano runico
22611	libranza del artesano bolsa de pano runico
22612	libranza del artesano toga de pano runico
22613	libranza del artesano carga de zapador goblin
22614	libranza del artesano granada de torio
22615	libranza del artesano gallo de batalla gnomico
22616	libranza del artesano tubo de torio
22617	libranza del artesano pocion de mana sublime
22618	libranza del artesano pocion de sanacion sublime
22619	libranza del artesano pocion de proteccion contra la escarcha superior
22620	libranza del artesano pocion de proteccion contra lo arcano superior
22621	libranza del artesano frasco de petrificacion
22622	libranza del artesano anguila escama petrea
22623	libranza del artesano pez coraza de placas
22624	libranza del artesano anguila relampago
22625	libranza del artesano salmon al horno
22626	libranza del artesano sorpresa de tuberculo runtun
22630	atiesh gran baculo del guardian
22631	atiesh gran baculo del guardian
22632	atiesh gran baculo del guardian
22635	guardia salvaje
22636	guardiahielo
22637	idolo hakkari primigenio
22638	guardasombras
22648	informe sobre colmen ashi
22649	informe colmen regal
22650	informe sobre colmen zora
22651	musleras de placas de escolta
22652	jubon glacial
22654	guantes glaciales
22655	munequeras glaciales
22656	el purificador
22657	amuleto del alba
22658	capa glacial
22659	medallon del alba
22660	abrazo de gaia
22661	guerrera polar
22662	guantes polares
22663	brazales polares
22664	coraza de escamas heladas
22665	brazales de escamas heladas
22666	guanteletes de escamas heladas
22667	brazales de esperanza
22668	brazales de subterfugio
22669	coraza deliriohelado
22670	guanteletes deliriohelado
22671	brazales deliriohelado
22672	musleras de placas de centinela
22673	leotardos de anillas de escolta
22676	leotardos de malla de escolta
22678	dije de ascendiente
22679	bolsa de suministros
22680	sortija de resolucion
22681	sortija de piedad
22682	runa congelada
22683	patron abrazo de gaia
22684	patron guantes glaciales
22685	patron capa glacial
22686	patron jubon glacial
22687	patron munequeras glaciales
22688	ultimo recurso de verimonde
22689	yelmo de cuero santificado
22690	leotardos del cazador de peste
22691	crematoria corrupta
22692	patron guerrera polar
22694	patron guantes polares
22695	patron brazales polares
22696	patron coraza de escamas heladas
22697	patron guanteletes de escamas heladas
22698	patron brazales de escamas heladas
22699	leotardos deliriohelado
22700	leotardos glaciales
22701	leotardos polares
22702	leotardos de escamas heladas
22703	diseno coraza deliriohelado
22704	diseno guanteletes deliriohelado
22705	diseno brazales deliriohelado
22707	garra helada de ramaladni
22708	destino de ramaladni
22711	capa de los adoradores hakkari
22712	poderio de la tribu
22713	cetro zulian de ritos
22714	guanteletes de sacrificio
22715	guantes del atormentado
22716	cinturon de poder sin explotar
22718	mascara empapada de sangre
22719	vademecum de omarion
22720	ornato zulian
22721	sortija de servidumbre
22722	sello de rabioso gurubashi
22723	una carta del guardian de los pergaminos
22725	sortija de cenarius
22726	astilla de atiesh
22727	armazon de atiesh
22728	mando de tonque de vapor
22729	esquema mando de tonque de vapor
22730	cordon cinturon acecha ojos
22731	capa de los devorados
22732	marca de c thun
22733	cabeza del baculo atiesh
22734	base de atiesh
22736	andonisus segador de almas
22737	atiesh gran baculo del guardian
22739	escrito sobre polimorfia tortuga
22740	pantalones de cuero de escolta
22741	pantalones de pellejo de lagarto de escolta
22742	camisa velasangre
22743	fajin velasangre
22744	botas velasangre
22745	pantalones velasangre
22746	uniforme de bucanero
22747	leotardos de seda de escolta
22748	leotardos de anillas de centinela
22749	pantalones de cuero de centinela
22750	pantalones de pellejo de lagarto
22752	leotardos de seda de centinela
22753	musleras de laminas de centinela
22754	quintaesencia eterna
22756	jubon nemoroso
22757	corona nemorosa
22758	sobrehombros nemorosos
22759	yelmo zarzal
22760	botas zarzal
22761	cinturon zarzal
22762	coraza parraferrea
22763	guantes parraferrea
22764	cinturon parraferrea
22765	carta enmohecida
22766	diseno coraza parraferrea
22767	diseno guantes parraferrea
22768	diseno cinturon parraferrea
22769	patron cinturon zarzal
22770	patron botas zarzal
22771	patron yelmo zarzal
22772	patron sobrehombros nemorosos
22773	patron corona nemorosa
22774	patron jubon nemoroso
22780	huevo de murloc blanco
22781	collera de oso polar
22798	poderio de menethil
22799	buscador de almas
22800	baston de azufre
22801	aguja crepuscular
22802	caida del rey
22803	bruma de medianoche
22804	colmillo de maexxna
22806	remordimiento de viuda
22807	espada de anima
22808	el castigador
22809	gran maza del cruzado redimido
22810	inyector toxico
22811	hilo de alma
22812	esclavizador nerubiano
22813	mandoble de poderio profano
22815	division
22816	hachuela de hueso partido
22818	el portador de peste
22819	escudo de condena
22820	varita de fortunas
22821	dedo condena
22822	icoke prize voucher
22843	grebas de anillas de guardia de sangre
22852	botines de pellejo de dragon de guardia de sangre
22855	botos de tejido de tinieblas de guardia de sangre
22856	botos de cuero de guardia de sangre
22857	grebas de malla de guardia de sangre
22858	grebas de placas de guardia de sangre
22859	botos de saten de guardia de sangre
22860	botos de seda de guardia de sangre
22862	abrazaderas de anillas de guardia de sangre
22863	mandiletes de pellejo de dragon de guardia de sangre
22864	mandiletes de cuero de guardia de sangre
22865	manijas de tejido de tinieblas de guardia de sangre
22867	abrazaderas de malla de guardia de sangre
22868	guanteletes de placas de guardia de sangre
22869	manijas de saten de guardia de sangre
22870	manijas de seda de guardia de sangre
22872	camisote de placas de legionario
22873	leotardos de placas de legionario
22874	camisote de anillas de legionario
22875	musleras de anillas de legionario
22876	camisote de malla de legionario
22877	pechera de pellejo de dragon de legionario
22878	leotardos de pellejo de dragon de legionario
22879	pechera de cuero de legionario
22880	musleras de cuero de legionario
22881	musleras de tejido de tinieblas de legionario
22882	musleras de saten de legionario
22883	musleras de seda de legionario
22884	guerrera de tejido de tinieblas de legionario
22885	guerrera de saten de legionario
22886	guerrera de seda de legionario
22887	musleras de malla de legionario
22890	escrito sobre resguardo contra la escarcha v
22891	grimorio resguardo contra las sombras iv
22892	piedra necrotica oscura
22895	rollito de canela magico
22897	escrito sobre crear comida vii
22930	un sobre manchado de sangre
22932	una carta rota
22935	toque de escarcha
22936	guardamunecas de venganza
22937	gema de nerubis
22938	capa de seda de demonio de cripta
22939	sortija de plegarias sin respuesta
22940	espaldares deliriohelado
22941	hombreras polares
22942	el abrazo de la viuda
22943	colgante de piedra malicia
22944	una misiva arrugada
22945	una nota con tono de agobio
22946	una pagina hecha jirones
22947	colgante de nombres olvidados
22948	un documento manchado
22949	cristal necrotico rajado
22950	cristal necrotico tenue
22954	beso de la arana
22960	capa de sutura
22961	sortija de reanimacion
22967	bufas de escamas heladas
22968	manto glacial
22970	un sobre manchado de sangre
22972	una nota con tono de agobio
22973	una misiva arrugada
22974	una pagina hecha jirones
22975	un documento manchado
22977	una carta rota
22981	collera perdida de gluth
22983	manto cubierto de escarcha
22988	el fin de los suenos
22994	compendio de mano de poder
22999	tabardo de el alba argenta
23000	caja toracica de abominacion con placas
23001	ojo de disminucion
23002	carcasa de tortuga
23004	idolo de longevidad
23005	totem de agua corriente
23006	tratado sobre luz
23007	collera de cochinillo
23008	informe de investigacion lacrado
23009	varita de la muerte susurrante
23010	informe de investigacion lacrado
23011	informe de investigacion lacrado
23012	informe de investigacion lacrado
23013	informe de investigacion lacrado
23014	iblis hoja del serafin caido
23015	jaula de ratas
23016	informe de investigacion lacrado
23017	velo de eclipse
23018	sello del defensor caido
23019	casco deliriohelado
23020	casco polar
23021	las ataduras del cosechador de almas
23022	pago de cascarrabias
23023	collar de sadico
23024	documentacion de instruccion de campo lista
23025	sello del condenado
23027	calor de perdon
23028	sortija de granizo
23029	corazon gelido de noth
23030	capa de la plaga
23031	sortija de lo inevitable
23032	ornato glacial
23033	almofar de escamas heladas
23034	nax ph crit plate shoulders
23035	sombrero de preceptor
23036	collar de necropsia
23037	anillo de fervor espiritual
23038	sortija de fuerzas antinaturales
23039	el ojo de nerub
23040	glifo de desvio
23041	blason de destripador
23042	reflejo de loatheb
23043	la cara de la muerte
23044	presagista de la fatalidad
23045	embozo de dominio
23046	la esencia contenida de sapphiron
23047	ojo de los muertos
23048	ojo derecho de sapphiron
23049	ojo izquierdo de sapphiron
23050	capa de la necropolis
23053	dije iracundo de tempestira
23054	gressil alba de la ruina
23055	palabra de deshielo
23056	martillo de el vacio abisal
23057	gema de inocentes atrapados
23058	collar de mediacion de vida
23059	anillo de acorator
23060	anillo segahuesos
23061	anillo de fe
23062	anillo de fuego de escarcha
23063	anillo corazon de peste
23064	anillo del caminasuenos
23065	anillo del apocaliptico
23066	anillo de redencion
23067	anillo de acechacriptas
23068	quijotes de matanza
23069	atuendo de necrocaballero
23070	leotardos de polaridad
23071	leotardos de apocalipsis
23072	punos del inflexible
23073	botas de desplazamiento
23075	acuerdo con la muerte
23078	guanteletes de matanza de no muertos
23081	manijas de matanza de no muertos
23082	manoplas de matanza de no muerto
23083	llama presa
23084	guantes de eliminacion de no muertos
23085	toga de eliminacion de no muertos
23087	coraza de matanza de no muertos
23088	coselete de matanza de no muertos
23089	guerrera de matanza de no muertos
23090	brazales de matanza de no muertos
23091	brazales de eliminacion de no muertos
23092	guardamunecas de matanza de no muertos
23093	cubremunecas de matanza de no muertos
23122	piedra de afilar consagrada
23123	aceite de zahori bendito
23124	baston de balzaphon
23125	cadenas del exanime
23126	pretina de balzaphon
23127	capa de revanchion
23128	la garra de las sombras
23129	brazales de alivio
23132	hoja de lord bosque negro
23139	rodela de lord bosque negro
23156	muslo de bosque negro
23160	pan de la amistad
23161	limonada fresca
23162	una bolsa muy grande
23163	performer s wand
23164	bubbly beverage
23168	daga focal de desden
23169	gargantilla helada de desden
23170	la garra helada
23171	el hacha de extirpacion
23172	refreshing red apple
23173	leotardos de piel de abominacion
23175	tasty summer treat
23176	fizzy energy drink
23177	dedo de lady falther ess
23178	manto de lady falther ess
23179	llama de orgrimmar
23180	llama de cima del trueno
23181	llama de entranas
23182	llama de ventormenta
23183	llama de forjaz
23184	llama de darnassus
23192	tabardo de la cruzada escarlata
23193	riendas de corcel esqueletico
23194	marca del alba inferior
23195	marca del alba
23196	marca del alba superior
23197	idolo de la luna
23198	idolo de brutalidad
23199	totem de la tormenta
23200	totem de apoyo
23201	tratado sobre divinidad
23203	tratado sobre fervor
23206	marca del campeon
23207	marca del campeon
23211	esmorc tostado
23215	bolsa de ingredientes esmorc
23219	faja del mentor
23220	toga tejida con cristal
23221	servobrazo mal colocado
23224	summer gift package
23226	guerrera de piel de necrofago
23227	icoke gift box voucher
23237	anillo de la llama eterna
23238	rodela estigia
23242	garra de vermis de escarcha
23243	sobrehombros de placas de campeon
23244	yelmo de placas de campeon
23246	brebaje festivo igneo
23247	flores ardientes
23250	concha centelleante
23251	yelmo de anillas de campeon
23252	sobrehombros de anillas de campeon
23253	protegecabezas de pellejo de dragon de campeon
23254	sobrehombros de pellejo de dragon de campeon
23255	capucha de tejido de tinieblas de campeon
23256	bufas de tejido de tinieblas de campeon
23257	yelmo de cuero de campeon
23258	sobrehombros de cuero de campeon
23259	protegecabezas de malla de campeon
23260	espaldares de malla de campeon
23261	caperuza de saten de campeon
23262	manto de saten de campeon
23263	capucha de seda de campeon
23264	manto de seda de campeon
23272	coraza de laminas de capitan caballero
23273	leotardos de laminas de capitan caballero
23274	guanteletes de laminas de teniente caballero
23275	escarpes de laminas de teniente caballero
23276	protegecabezas de laminas de teniente coronel
23277	sobrehombros de laminas de teniente coronel
23278	grebas de anillas de teniente caballero
23279	abrazaderas de anillas de teniente caballero
23280	mandiletes de pellejo de dragon de teniente caballero
23281	botines de pellejo de dragon de teniente caballero
23282	manijas de tejido de tinieblas de teniente caballero
23283	botos de tejido de tinieblas de teniente caballero
23284	mandiletes de cuero de teniente caballero
23285	botos de cuero de teniente caballero
23286	guanteletes de placas de teniente caballero
23287	grebas de placas de teniente caballero
23288	manijas de saten de teniente caballero
23289	botos de saten de teniente caballero
23290	manijas de seda de teniente caballero
23291	botos de seda de teniente caballero
23292	camisote de anillas de capitan caballero
23293	musleras de anillas de capitan caballero
23294	pechera de pellejo de dragon de capitan caballero
23295	leotardos de pellejo de dragon de capitan caballero
23296	musleras de tejido de tinieblas de capitan caballero
23297	guerrera de tejido de tinieblas de capitan caballero
23298	pechera de cuero de capitan caballero
23299	musleras de cuero de capitan caballero
23300	camisote de placas de capitan caballero
23301	leotardos de placas de capitan caballero
23302	musleras de saten de capitan caballero
23303	guerrera de saten de capitan caballero
23304	musleras de seda de capitan caballero
23305	guerrera de seda de capitan caballero
23306	yelmo de anillas de teniente coronel
23307	sobrehombros de anillas de teniente coronel
23308	protegecabezas de pellejo de dragon de teniente coronel
23309	sobrehombros de pellejo de dragon de teniente coronel
23310	capucha de tejido de tinieblas de teniente coronel
23311	bufas de tejido de tinieblas de teniente coronel
23312	yelmo de cuero de teniente coronel
23313	sobrehombros de cuero de teniente coronel
23314	yelmo de placas de teniente coronel
23315	sobrehombros de placas de teniente coronel
23316	caperuza de saten de teniente coronel
23317	manto de saten de teniente coronel
23318	capucha de seda de teniente coronel
23319	manto de seda de teniente coronel
23320	tablilla de choque de llamas vi
23323	corona del festival del fuego
23324	manto del festival del fuego
23326	salchicha de solsticio de verano
23327	pan tostado
23360	cabeza de instructor razuvious
23379	brazales de ceniza
23435	tarta de bayas de sauco
23451	hoja de mago de gran mariscal
23452	escrito sobre poder del gran mariscal
23453	escrito sobre restauracion del gran mariscal
23454	martillo de guerra de gran mariscal
23455	demoledor de gran mariscal
23456	hoja presta de gran mariscal
23464	maza de batalla de gran senor de la guerra
23465	destructora de gran senor de la guerra
23466	hoja de hechizo de gran senor de la guerra
23467	hoja rauda de gran senor de la guerra
23468	escrito sobre destruccion del gran senor de la guerra
23469	escrito sobre alivio del gran senor de la guerra
23545	poder de la plaga
23547	temple de la plaga
23548	poderio de la plaga
23549	entereza de la plaga
23557	larva del gran gusano
23558	la coraza del perforador
23570	jom gabbar
23577	el frio voraz
23578	dieta macsalsafloja
23579	el clasico macsalsafloja
23663	faja de la furia elemental
23664	espaldares de la furia elemental
23665	leotardos de la furia elemental
23666	cinturon del gran cruzado
23667	bufas del gran cruzado
23668	leotardos del gran cruzado
23683	pastilla para la garganta copo de cristal
23684	venda de cristal imbuido
23689	manual venda de cristal imbuido
23690	receta pastilla para la garganta copo de cristal
23705	tabardo de las llamas
23709	tabardo de escarcha
23710	tabardo de upperdeck n º 3
23712	cachorro de tigre blanco
23713	prole de hipogrifo
23714	fuegos artificiales morados perpetuos
23715	coctel de zumo de pulmon perpetuo
23716	idolo de ogro tallado
23718	polvo de scorpok machacado permanente
23719	compuesto de cortex cerebral permanente
23720	tortuga de montar
23721	chicle permanente de mollejas
23722	ifrdhr permanente
23794	brillo permanente de zanza
23795	espiritu permanente de zanza
23796	presteza permanente de zanza
24071	daga insulsa
24101	libro de mordedura feroz v
24102	manual de eviscerar ix
24222	el apunalador de sombrapies
24231	rape burdo
24232	nudo gastado
24281	hueso tallado de marfil
24282	diario de un picaro
24283	un arma solariega
122270	ficha de wow
122284	ficha de wow
172070	botiquin de atencion al cliente
180089	collera de panda
184937	desplazador de cronobeneficios
184938	desplazador de cronobeneficios supercargado
189419	fire resist plate gear
189420	fire resist plate gear
189421	fire resist leather gear
189426	raid consumables
189427	more raid consumables
190179	corazon de avelina
190180	corazon de isaac
190181	corazon de los amantes
190186	figurilla de madera
190187	bufanda desgastada
190232	bufanda desgastada
190307	antorcha apagada
190308	antorcha ardiente
190309	figurilla de madera
191204	piedra de muerte inferior
191249	piedra de muerte superior
191267	runa de teletransporte antecamara
191268	orbe de corrupcion
191272	vara de nigromancia
191280	cumulo de esporas fungicas
191288	runa de teletransporte guarida de vermis de escarcha
191292	daga ritual
191312	filacteria infalible
191313	mascara de muerte
191414	artefacto esqueletico
191458	filacteria destrozada
191459	runa de fortuna
191477	palenque esqueletico
191480	corcel esqueletico
191481	tabardo de maestria
191550	libro de piedras de muerte mascara de muerte
191605	libro de piedras de muerte runa de teletransporte i
191606	libro de piedras de muerte orbe de corrupcion
191607	libro de piedras de muerte artefacto esqueletico
191608	libro de piedras de muerte vara de nigromancia
191609	libro de piedras de muerte cumulo de esporas fungicas
191610	libro de piedras de muerte daga ritual
191611	libro de piedras de muerte filacteria infalible
191612	libro de piedras de muerte runa de teletransporte ii
191613	libro de piedras de muerte runa de fortuna
191614	libro de piedras de muerte palenque esqueletico
191656	esencia de la muerte
191660	descargas de relampagos de thaddius
191661	colmillo de arana monstruoso
191664	libro de piedras de muerte descargas de relampagos de thaddius
191666	libro de piedras de muerte colmillo de arana monstruoso
202251	bolsa de golosinas para mascotas
202254	brazales de reorientacion
202256	pistola ornamentada de corsario
202641	cuaderno cubierto de barro
203723	nota de navajin
203726	runa de navajin
203745	notas de hechizo lanza de hielo
203746	notas de hechizo llama viva
203747	notas de hechizo dedos de escarcha
203748	notas de hechizo incendio
203749	notas de hechizo esclarecimiento
203750	mapa del tesoro de elwynn
203751	notas de hechizo alzo en hielad
203752	notas de hechizo malva vali
203753	notas de hechizo dascac heded seor
203754	archimago antonidas la autobiografia completa
203755	diario de investigacion del archimago theocritus
203756	nota de aprendiz de azora pagina 1
203784	trozo superior derecho de mapa
203785	trozo superior izquierdo de mapa
203786	trozo inferior derecho de mapa
203787	trozo inferior izquierdo de mapa
203960	nota de aprendiz de azora pagina 2
203961	nota de aprendiz de azora pagina 3
203962	nota de aprendiz de azora pagina 4
203990	runa de mutilacion
203991	runa de desenfunde rapido
203992	runa de artimana
203993	runa de masacre
203994	runa de brebaje letal
204174	runa de precision
204270	nucleo de las profundidades
204441	runa de frenesi sangriento
204476	cabeza de kobold cortada
204477	cabeza de murloc cortada
204478	cabeza de gnoll cortada
204688	primer fragmento de runa de cazador de monstruos
204689	segundo fragmento de runa de cazador de monstruos
204690	tercer fragmento de runa de cazador de monstruos
204703	runa de devastar
204716	runa de asalto frenetico
204795	runa de golpesombra
204804	brazaletes de hydraxis
204806	runa de ataque de la victoria
204807	espada de las profundidades
204809	runa de rayo furioso
204864	nota de aprendiz de azora
204905	escrito ominoso
204906	sangre de gnoll
204907	mandibula de lobo
204912	runa de gracia
205019	fragmento de alma contaminado
205020	fragmento de alma pura
205022	runa de succion de alma
205181	artefacto sin identificar
205182	artefacto sin energia
205183	artefacto alimentado con energia vil
205184	nota de acolito
205215	runa de tacticas
205218	tratado sobre descubrimiento
205228	runa de descarga de caos
205230	runa de posesion
205364	morral de acolito
205420	tratado sobre sentencia
205683	runa de reprimenda
205685	runa de egida
205863	tratado corrupto
205864	nota chamuscada
205897	runa de luz divina
205905	recuerdo de un campeon devoto
205932	profecia de la muerte de un rey
205940	recuerdo de un proposito oscuro
205942	epifania quimerica
205943	profecia de una ciudadela profanada
205944	epifania reciproca
205945	recuerdo de un salvador encerrado
205946	recuerdo de la traicion de un lider
205947	profecia de una ciudadela profanada
205948	epifania anodina
205949	epifania multiple
205950	epifania tenebrosa
205951	recuerdo de un acolito atribulado
205952	recuerdo de un mundo devastado
205953	profecia de juramento roto
205961	carne de ave de mulgore
205979	runa de flanqueo
205995	almizcle de perro de la pradera
206032	runa de cuchillada
206155	runa de punteria
206157	carga minera de seforio
206159	disfraz de ventura y cia
206168	runa de quimera
206169	runa de disparo explosivo
206170	cono de viento furioso
206175	balsamo de pino
206176	mortero y majadero
206177	mantequilla de pinones
206264	runa de inspiracion
206344	conjunto de cuchillos
206345	trozos de pescado
206376	icono de baluarte
206381	icono diadico
206382	icono de tempestad
206383	icono litico
206384	icono astral
206385	icono clastico
206386	icono galvanico
206387	icono kajarico
206388	icono sulfurico
206389	icono de azufre
206390	icono ictineo
206391	icono de syzygic
206466	corona de la pradera
206469	flor de la pradera
206954	idolo de colera osuna
206963	runa de potencial natural
206966	bulbo de herbasatiro
206970	runa de vida
206975	llave del deposito de artefactos
206985	eco del alfa
206989	runa del sol
206992	runa de testarazo
206994	cabeza de jabaespin cortada
206995	cabeza de arpia cortada
207062	cabeza de centauro cortada
207098	nota de ba so
207106	trozo inferior izquierdo de mapa
207107	trozo inferior derecho de mapa
207108	trozo superior izquierdo de mapa
207109	trozo superior derecho de mapa
207110	mapa del tesoro de durotar
207590	carne de cerdo de durotar
207631	feromona de viboris
207731	escrito ominoso
207732	pata de makrura
207733	craneo kultirano
207972	las ensenanzas de ta zo
207973	hueso de mandibula de sabueso
207974	escrito ominoso
207975	cabeza de murcielago cortada
208005	llave de cofre de reliquias de agamand
208007	llave de alijo de naufragio
208034	mapa del tesoro de tirisfal
208035	trozo superior derecho de mapa
208036	trozo superior izquierdo de mapa
208037	trozo inferior derecho de mapa
208038	trozo inferior izquierdo de mapa
208085	sello de teniente escarlata
208086	memorandum escarlata falsificado
208139	escrito ominoso
208140	sangre de wendigo
208158	corazon de trogg pristino
208159	cabeza de trol cortada
208160	pata de wendigo cortada
208180	almizcle de conejo
208183	notas de boticario
208185	el manual de la metafisica del boticario
208192	carne de cerdo de dun morogh
208196	sortija moa kin
208205	nota de ratanegra
208213	trozo superior derecho de mapa
208215	trozo superior izquierdo de mapa
208218	trozo inferior derecho de mapa
208219	trozo inferior izquierdo de mapa
208220	mapa del tesoro de dun morogh
208222	vindicadora del viejo guardia
208223	morral de acolito
208224	nota de acolito
208414	idolo lunar
208425	vestigio arcaico brillante
208484	luz solar
208601	trozo superior derecho de mapa
208602	trozo superior izquierdo de mapa
208603	trozo inferior derecho de mapa
208604	trozo inferior izquierdo de mapa
208605	mapa del tesoro de teldrassil
208607	almizcle de ciervo
208608	carne de ave de teldrassil
208609	flor del prado
208610	cabeza de buho cortada
208611	cabeza de tigre cortada
208612	cabeza de arana cortada
208682	huevo de quijaforte abandonado
208687	runa de lacerar
208689	idolo feroz
208701	runa de maestria de bestias
208739	estandarte de guerra de la horda
208741	runa de ira infinita
208743	alma de codicia
208744	runa de descargas de las sombras
208749	llave de alijo tuercepinos
208750	runa de mediacion
208753	notas de hechizo regeneracion
208754	notas de hechizo range cerneio
208758	runa terranea
208760	corona del prado
208764	runa de la mente
208765	mano servicial
208766	mano servicial
208767	runa de alivio
208768	caja de fosforos de bucanero
208771	runa de danza de hojas
208772	runa de sablazo
208773	arpon de pesca
208777	runa del francotirador
208778	runa de golpe rapido
208799	notas de hechizo bomba viva
208800	baxtan tratado de magias destructivas
208823	moneda de ofrenda
208828	recuerdo de un juramento roto
208833	pastel malevolo
208838	arcon de hierro negro
208843	totem de batalla
208847	geoda con forma de craneo
208848	geoda con forma de craneo partida
208849	tratado sobre bendiciones
208851	tratado sobre justicia
208853	notas de hechizo congelacion cerebral
208854	notas de hechizo masticadas
208855	carnada de atun blanco arco iris
208860	rumi de gnomeregan obras completas
209027	bocados de cangrejo
209028	notas de hechizo ovma bivab
209029	mensaje de emily
209030	llave de alijo con equipamiento
209031	sobre discreto
209041	semillas de calabaza magica
209042	harina de hueso de pescado
209043	muestra de tierra fertil
209045	alma del mar
209047	arpon nudoso
209056	piezas de repuesto de segador
209057	prototipo de motor
209058	nucleo elemental
209059	anca de dentosangre
209418	armadura tortuga adamantina
209420	azotebranquias
209421	cordon de aquanis
209422	gargantilla de marea alta
209423	bufanda ondeante
209424	barrera de placas de caparazon
209432	cincho de ghamoo ra
209436	diente roto de serra kis
209523	manteo de trillador fulgurante
209524	ataduras de serra kis
209525	talwar aguaoscura afilado
209527	guanteletes de batalla naga
209534	arbalesta azshari
209559	cachava de sabio del crepusculo
209560	martillo de sentencia recta
209561	vara del insomne ancestral
209562	golpe mortal de la hidra
209563	desgarracorazones naga
209564	tridente de guardian
209565	sortija de lugares profundos
209566	leotardos de los fieles
209567	hacha de arrecife de corales
209568	guanteletes de algas
209569	botas altas de pellejo de murloc
209570	tomo de conocimiento de la caverna
209571	luz mortecina
209572	cueros hervidos negros
209573	aguja colerica
209574	doctrina descartada de la mano de plata
209575	icono de madera a la deriva tallada
209576	champinon expandementes
209577	puno de lo salvaje
209578	bandas de cuero resplandecientes
209579	trueno aplastante
209580	racha de viento
209581	escarpes de la mano de plata
209590	globo de agua rajado
209608	llave esqueleto del capitan
209611	insignia de la alianza
209612	insignia de la alianza
209613	insignia de la alianza
209614	insignia de la alianza
209615	insignia de la alianza
209616	insignia de la alianza
209617	insignia de la alianza
209618	insignia de la alianza
209619	insignia de la horda
209620	insignia de la horda
209621	insignia de la horda
209622	insignia de la horda
209623	insignia de la horda
209624	insignia de la horda
209625	insignia de la horda
209626	insignia de la horda
209667	leotardos de sonador de mirada
209668	sello del senor crepuscular
209669	zapatos de invocador crepuscular
209670	pisapieles
209671	togas de invocador crepuscular
209672	guantes sin dedos negros
209673	amuleto de fetiche brillante
209674	encendedora de fenix
209675	guerrera hiloalmeja
209676	guardahombros de profundidades aplastantes
209677	aro de corrientes prestas
209678	manto del asesino de trilladores
209679	hombreras de novato azshari
209680	bufanda impermeable
209681	huevo de murloc negro
209682	capucha robusta
209683	chal de invocador crepuscular
209684	pantalones de robaalmas
209685	cincho musgoso ancestral
209686	collar de hueso dentado
209687	loriga de pellejo de hidra
209688	trabuco de bael modan
209689	botas de pesca de caparazon de cangrejo
209690	almofar sombriescamas
209691	cuchillo de bota vampirico
209692	espaldares de centinela
209693	perla brazanegra perfecta
209694	daga ritual brazanegra
209748	orbe de althalaxx
209778	sal de invocador
209779	mota de mannoroth
209800	fragmentos de orbe
209816	fetiche de travesuras
209817	broche de abisario
209818	media luna tocada por el sol
209819	varita de adiestracion de dracoleones
209820	gargantilla de sudario negra
209821	anillo de vision sombria
209822	fuerza de proposito
209823	sello de bestias
209824	hombreras fulgurantes
209825	gargantilla de gotas
209828	espaldares bajo cero
209830	arbalesta pielferrea
209836	orbe de althalaxx
209838	cristal hipnotico
209840	varita de magia silvestre nudosa
209841	esencia de magia salvaje
209843	almanaque de nar thalas vol 74
209844	el compendio de dalaran vol 23
209845	hechizos y encantamientos
209846	secretos de los sonadores
209847	manual de sistemas arcanicos
209848	pergaminos goaz
209849	crimenes contra la anatomia
209850	runa de los reyes hechiceros
209851	furia de la tierra
209852	runa de matar
209872	yelmo de matadragones
209873	escudo de matadragones
209874	lanza de matadragones
210015	runa de arremetida enfurecida
210026	simbolo del tercer buho
210043	simbolo del segundo buho
210044	simbolo del primer buho
210045	sombrahoja
210053	pata de lobo temible
210055	huesos de humano de trabalomas
210056	tintura de muerte andante
210080	ofrenda vudu
210137	runa de crecimiento salvaje
210138	artilleria hierro negro
210146	turbocargador de trituradora
210147	unidad de autorreciclaje de trituradora
210177	ataeric tratado de curiosidades arcanas
210178	esquema unidad de autorreciclaje de trituradora
210179	notas de hechizo ilmegai sarrbes
210183	cuerno de xelthos
210186	carga destructora
210187	pedido de ventura y cia
210188	pedido desgarrado
210195	idolo desequilibrado
210209	llave gemela
210210	certificado de fundador de industrias defensivas grizzwerks
210212	media llave de hermano
210213	media llave de hermana
210229	runa de mutilacion
210250	anillo de oro con inscripcion
210251	anillo de plata con inscripcion
210252	runa de puyazo
210253	totem de podredumbre
210322	runa de veneno
210323	combinacion de caja fuerte
210329	mapa del tesoro de trabalomas
210330	informacion valiosa
210410	cebo de mordedor de agua fresca
210499	champinon de pantano
210500	runa de las estrellas
210534	idolo de las fieras
210568	filacteria decrepita
210569	runa de flagelacion
210573	runa de ira acuciante
210589	eco de los ancestros
210596	runa de golpes de cobra
210653	runa de guardamano
210654	notas de hechizo retroceder el tiempo
210655	notas de hechizo merlonecteor perdiete
210665	mota de ira torrencial
210667	mota de ira infernal
210668	mota de ira sismica
210696	azote de podredumbre
210708	elixir de remordimientos fusionados
210709	receta elixir de remordimientos fusionados
210712	elixir de conocimiento
210713	alma torturada
210724	baston de hirzek
210741	moledora automatica de muchedumbre
210746	runa de escudo de tierra
210763	rama de altek
210765	orbe de des
210771	suministros faltantes barras de cobre
210772	cargamento de suministros barras de cobre
210773	manto de la segunda guerra
210779	diseno manto de la segunda guerra
210781	ataduras de fenix
210794	coraza de plata cambiante
210795	botas de seda de arana extrabidimensionales
210811	runa de furia primordial
210817	runa de supervivencia
210818	runa de lobo solitario
210820	runa de sacrificio
210822	epifania armoniosa
210823	runa de especializacion en doble empunadura
210824	runa del pacto
210825	runa del belisario
210953	ojo de bhossca
210955	uniforme de iniciado escarlata
210963	llave del aruspice
210966	sangre de la legion
210967	mensaje confidencial
210968	llave de relicario
210979	runa de paso de las sombras
210980	runa de metamorfosis
211205	runa de matacobras
211247	patron ataduras de fenix
211263	coselete de sentencia
211269	ilustracion primitiva
211301	runa de exponer debilidad
211315	suministros faltantes cuero ligero
211316	suministros faltantes flor de paz
211317	suministros faltantes hojaplata
211318	suministros faltantes pociones de sanacion menores
211319	suministros faltantes espadas cortas de cobre
211320	suministros faltantes pantalones runicos de cobre
211321	suministros faltantes varitas magicas inferiores
211322	suministros faltantes aceite de zahori menor
211323	suministros faltantes bombas de cobre ferreas
211324	suministros faltantes bocardas ferreas
211325	suministros faltantes cinturones de cuero cosidos a mano
211326	suministros faltantes jubon de cuero estampado
211327	suministros faltantes pantalones de lino marrones
211328	suministros faltantes togas de lino marrones
211329	suministros faltantes huevos a las finas hierbas
211330	suministros faltantes carne de lobo especiada
211331	suministros faltantes pececito luminoso
211332	suministros faltantes vendas de lino gruesas
211365	cargamento de suministros
211367	cargamento de suministros
211368	cargamento de suministros
211382	bolsa de cartero pequena
211384	bolsa de cartero resistente
211385	runa de propagacion serpentina
211386	notas de hechizos oleada arcana
211387	runa de luz de conocimiento
211390	runa de heridas superficiales
211391	runa de lluvia de sanacion
211392	runa de afliccion eterna
211393	runa de furia enfilada
211419	monton de escamas cambiantes
211420	dije de escamas cambiantes
211421	la caja
211422	fragmento del vacio
211423	guantes de cuero tocados por el vacio
211427	recipiente de alma
211443	hoja de ira
211444	capa de invocador
211445	arco recurvo barbaro
211447	cargamento de armas
211448	contrato de compra firmado
211449	perla del vacio de vengador
211450	perla del vacio de invocador
211451	perla del vacio de acolito
211452	perla brazanegra perfecta
211454	globo de agua extrano
211455	guantes sin dedos habiles
211456	daga de sacrificio voluntario
211457	faja de defensor del crepusculo
211458	escrito de amparo contra las sombras
211460	rodela artica ancestral
211461	cetro de lapida grabada
211462	anillo de apoyo eterno
211463	broches de alfazaque estridente
211464	manteo de prelacion usado
211465	botas nimbus de perspicacia
211466	faja de duramen del amable
211467	sortija del puno de hierro
211468	manto de castano raido
211471	llave fonroca
211472	tratado sobre destierro
211476	runa de estela de fuego
211477	runa de incineracion
211482	ofrenda rompelanzas
211487	explosivos para demoliciones
211488	runa de vengador
211490	profecia de las mil luces
211491	bolsa de piel de murloc sin fondo
211492	cartera de kelris
211498	sable de la noche de las centinelas de aprendiz
211499	lobo escolta de aprendiz
211500	cinta de tela resiliente
211501	coselete de poder
211502	guanteletes de cuero tocados por el vacio
211504	anillas de vengador crepuscular
211505	yelmo de vengador crepuscular
211506	botas de vengador crepuscular
211507	capucha de elementalista crepuscular
211508	escarpines de elementalista crepuscular
211509	toga de elementalista crepuscular
211510	capucha de destripador crepuscular
211511	escarpines de destripador crepuscular
211512	guerrera de destripador crepuscular
211514	notas de hechizo regeneracion en masa
211527	bolsa de dormir acogedora
211528	perspicacia oscura
211530	profecia de una ciudad cautivada
211531	profecia de los siete visitantes
211534	perspicacia primigenia
211691	notas de hechizo explosion arcana
211777	manuscrito naga
211779	talisman de comprension
211780	pergamino kwyjibo
211784	pergamino wubba wubba
211785	pergamino cwal
211786	scroll chap balk welles
211787	pergamino menos marca cualquiera
211789	capucha de artemisa
211799	saco de bienes robados
211800	pergamino de reintegracion
211809	manual de comprension
211813	talisman de centinela ala de plata
211814	marca de escolta grito de guerra
211815	himno de batalla ala de plata
211816	tambor de batalla grito de guerra
211818	globo de agua extrano
211819	suministros faltantes barras de bronce
211820	suministros faltantes barras de plata
211821	suministros faltantes cuero medio
211822	suministros faltantes hierba cardenal
211823	suministros faltantes cardopresto
211824	suministros faltantes pociones de mana inferiores
211825	suministros faltantes botas de bronce ferreas
211826	suministros faltantes llaves esqueleto de plata
211827	suministros faltantes varas runicas de plata
211828	suministros faltantes aceite de mana menor
211829	suministros faltantes bombas de bronce pequenas
211830	suministros faltantes catalejos ornamentados
211831	suministros faltantes capas de cuero oscuro
211832	suministros faltantes sobrehombros de montanero
211833	suministros faltantes camisas de lana gris
211834	suministros faltantes capa con broche de perlas
211835	suministros faltantes sabiola ahumada
211836	suministros faltantes carne de oso ahumada
211837	suministros faltantes almejas picantes a la goblin
211838	suministros faltantes vendas de lana gruesas
211839	cargamento de suministros
211840	cargamento de suministros
211841	cargamento de suministros
211842	gorro de pensar raido de rakkamar
211843	mascara de desden
211845	piedra de afilar brazanegra
211846	diseno piedra de afilar brazanegra
211848	aceite de mana brazanegra
211849	formula aceite de mana brazanegra
211852	manijas de agua contaminada
211853	pergamino voce well
211854	pergamino omit kesa
211855	pergamino sthenic lunate
211856	almofar de malla resiliente
211857	mascara de cuero resiliente
211933	suministros faltantes piedra ferrea
211934	suministros faltantes pociones de sanacion
211935	suministros faltantes elixir de poder de fuego
211940	guardian tribal de ecks av
211941	yari de viajero del viento
211944	karma de tojara
211953	pergamino de recuperacion arcana i
211954	pergamino de precision arcana i
211955	pergamino de proteccion arcana fuego i
211956	pergamino de proteccion arcana escarcha i
211957	pergamino de poder arcano i
212160	desplazador de cronobeneficios
212225	recipiente de alma inagotable
212230	esquema recipiente de alma
212548	runa de eclipse
212549	runa de trampero
212551	runa de la guerra
212552	epifania psicosofica
212559	runa de la hoja envenenada
212560	runa de despertar ancestral
212561	runa de oscuridad ardiente
212562	runa de ira curativa
212568	trofeo de cabeza de lobo
212580	baston del tradicionalista
212581	arco de avanzado
212582	espada de protector
212583	hoja de centinela
212584	baston nudoso de consejero
212585	arco de escolta
212586	espada de legionario
212587	hoja de explorador
212588	guantes de proveedor
212589	botines de mensajero
212590	correa de seguridad
212748	nota raida
212994	ataduras de trotatormentas
212996	ataduras de clamarelampagos
212997	ataduras de clamamareas
213074	runa de revitalizacion
213086	runa de la tormenta
213087	capa de sargento
213088	capa de sargento
213090	runa de sinergia
213093	runa de poder
213094	runa de nova de fuego
213096	runa de senuelos
213098	runa de invocacion
213100	runa de conocimiento prohibido
213101	runa de llamas de las sombras
213102	runa de perversidad
213103	runa de oleada de sangre
213104	runa de precision brutal
213105	shawarmagedon
213109	runa de ira concentrada
213110	runa del comandante
213111	runa de intervencion
213112	notas de hechizo tromba de misiles
213117	runa de rabia
213118	runa del rey de la selva
213119	runa de instinto
213120	runa del sonador
213121	acebo en conserva
213122	runa de disparo firme
213123	runa de exposicion
213124	runa de combate cuerpo a cuerpo
213125	runa de vigorizacion
213126	runa del desguazador
213127	notas de hechizo deroeb ofnacriora
213128	runa de piedad
213129	runa de abrazo de la luz
213130	runa de infusiones
213131	runa de escudos sacros
213132	runa de custodio
213136	runa de sutileza
213137	runa de atacante
213138	runa de pata izquierda
213139	runa de asesino
213140	profecia de la senda acelerada
213141	runa de esperanza
213142	profecia de maldad aprisionada
213143	epifania apocrifa
213144	epifania luminosa
213165	los basiliscos y el infundado miedo a la petrificacion
213168	moneda de sangre de cobre
213169	moneda de sangre de plata
213170	moneda de sangre de oro
213278	manoplas de maestro de golpes
213279	capacete reflectivo
213280	visor de tirador
213281	reactivador de hiperflujo electromagnetico
213282	equipo de innovacion hipercargado
213283	equipo de conflagracion hipercargado
213284	equipo de devastacion hipercargado
213285	ataduras manchadas con aceite de lev
213286	aguja de electrocutor
213287	hexatuerca de electrocutor
213288	guanteletes grasosos de grubbis
213289	hidrobaston
213290	botas acidas
213291	desfacedor toxico ii
213292	gigacortadora gizmotron
213293	superpistola de alta tecnologia mk vii
213294	escarpes cueva honda
213295	vibrofilo ultrasonico
213296	loncheacabezas supercargada
213297	martillo explosivo oscilante
213298	mono de mecanico
213299	pantalones de petroleo
213300	guantes del mejor piloto
213301	manto sintetico
213302	manto del negociador astuto
213303	bufas de pararrayos
213304	espaldares de matatroggs
213305	hombreras de aleacion mecanizada
213306	cobertura de ingenuidad
213307	manton de desmantelamiento
213308	prototipo de capa paracaidas
213309	capa de invencion
213310	camisa resplandeciente hiperconductiva
213311	toga hiperconductiva
213312	mandil aislado
213313	coselete aislado
213314	malla de anillas electromantica
213315	camisa de anillas electromantica
213316	coraza p e l i g r o
213317	estabilizadores de punteria experimentales
213318	brazaletes hierro negro ornamentados
213319	guantes de maquinista
213320	dedos de precision arcana
213321	cinturon de brebaje volatil
213322	pretina de embuste
213323	cordon de del interior de la tierra
213324	correa electromagnetica
213325	faja de vision nocturna
213326	faja de recuperacion
213327	cinturon del rabioso trogg
213328	bombachos hiperconductivos
213329	falda hiperconductiva
213330	quijotes p e l i g r o
213331	leotardos aislados
213332	musleras aisladas
213333	botarga electromantica
213334	chaqueton electromantico
213335	botas p e l i g r o
213336	botos hiperconductivos
213337	sandalias hiperconductivas
213338	botas de aislamiento electromantico
213339	escarpes de aislamiento electromantico
213340	botas de operadores de gnomobots
213341	botas de trabajo aisladas
213342	galochas aisladas
213343	insignia de justicia
213344	torque de oficial de paz de gnomeregan
213345	colgante de piston
213346	colgante de regreso a casa
213347	camara de combustion miniaturizada
213348	experimento giromatico 420b
213349	botella de pildoras de gniodino
213350	nucleo endurecido de perdal
213351	escudo paves irradiado
213352	gracia del reparador de equipo
213353	baston desfibrilador
213354	baston del genio malvado
213355	aguijon de falco
213356	desintegrador personalizado de termochufe
213369	cuero con resplandor tenue
213370	restos de cuero irradiado
213371	cajon de solucion de gniodino maculada
213372	gniodino aislante
213373	chatarra reflectiva
213376	placas de veraplata de bajo fondo
213378	microfilamento inestable
213379	arcanofilamento hiperconductivo
213381	pila de engranajes deslustrados
213383	engranajes de veraplata pulidos
213390	murotuerca de veraplata giratorio
213407	hierba gatera
213408	macroajustador giromatico
213409	arcanotrituradora de mekkatorque
213410	dagartilugio destellante
213411	chispero inextinguible de fulguizzle
213412	escudo de seguridad dielectrico
213413	hombreras muy acolchadas
213414	fajin de ensalmador de mecas
213415	cubremunecas de manitas
213416	cuchilla cohete de termochufe
213417	almofar de filamento de veraplata
213418	arandelas soldadas de veraplata
213419	manual de reparacion 9 60
213421	nota incinerada
213426	pararrayos de ogro
213427	reciclaje con mugre incrustada
213442	garra de maestro de engranajes
213443	presente que hace tic tac
213452	runa sagrada inerte
213513	tratado sobre salvacion
213526	anca hibrida
213527	mezcla de especias de contrabandista
213528	brebaje fresco
213529	toxina viscosa
213542	el necro gnomicon
213543	pergamino queonda
213544	pergamino ezfoo katasi
213545	pergamino topse altomiagu
213546	pergamino cucamonga
213547	pergamino qeusapeda
213548	pergamino de pasaje liminal
213549	pergamino de pesca arcana
213550	pergamino de polimorfia melon extrano
213551	pergamino de desplazamiento controlado
213552	lagrima de theradras
213553	lagrima de theradras
213554	vial de agua cristalina
213558	balsamo elemental
213559	palanca de cambios de mecazancudo
213560	silenciador de mecazancudos
213563	guia de campo
213564	pergamino de evocacion menor
213565	kit inicial para entomologia
213583	tallado de azufre
213594	idolo del molesto
213599	vision angustiante
213632	notas parciales de hechizo
213633	notas parciales de hechizo
213634	notas parciales de hechizo
213641	caja de reciclaje de gnomeregan
213701	pluma de arpia fuerte
213709	colmillo de serpiente nubosa
213735	procesador de n u c l e o g 7 pristino
213736	procesador de n u c l e o g 7 corroido
213737	ofrenda al espiritu de viento
214435	llave de jaula de pumas
215111	monoculo de arcanfilamento gneurovinculado
215114	almofar de escamas brillantes hiperconductivo
215115	envoltura dorada hiperconductiva
215129	formula encantar arma desguarnecer
215138	formula encantar pechera reprentizador
215141	sigilo encantado innovacion
215149	patron monoculo de arcanofilamento gneurovinculado
215152	patron capucha gneurovinculada con resplandor
215153	esquema murotuerca de veraplata giratorio
215155	diseno yelmo anulainterferencias templado
215156	esquema envoltura dorada hiperconductiva
215162	pocion de rejuvenecimiento levemente irradiada
215163	receta pocion de rejuvenecimiento levemente irradiada
215166	capucha gneurovinculada con resplandor
215257	pergamino de comprension
215365	manto de invocador
215366	cordon de invocador
215367	patron cuero con resplandor tenue
215368	patron arcanofilamento hiperconductivo
215369	patron cordon de invocador
215370	patron manto de invocador
215371	talisman de jani
215373	martillo de entrenamiento de la mano de plata
215374	espada ancestral
215375	baston de la estratega
215376	maza de cruzado
215377	toga irradiada
215378	botas irradiadas
215379	calzas irradiadas
215380	faja para levantar peso asistida electricamente
215381	caperuza de canalizador gneuroconductiva
215382	caperuza de escamas resistente a la radiacion
215383	diseno cajasesos de veraplata reflectiva
215384	diseno placas de veraplata de bajo fondo
215385	suministros faltantes barras de oro
215386	suministros faltantes barras de mitril
215387	suministros faltantes pellejo pesado
215388	suministros faltantes cuero grueso
215389	suministros faltantes palida
215390	suministros faltantes mostacho de khadgar
215391	suministros faltantes invernalia
215392	suministros faltantes lotos cardenos
215393	suministros faltantes pociones de sanacion superior
215394	suministros faltantes pociones de escudo de piedra inferior
215395	suministros faltantes elixires de agilidad
215396	suministros faltantes elixires de defensa superior
215397	suministros faltantes hachas de hierro macizo
215398	suministros faltantes brazales de hierro verdes
215399	suministros faltantes guanteletes de mitril pesado
215400	suministros faltantes piedras de pulir solidas
215401	suministros faltantes juegos de segador de la cosecha compactos
215402	suministros faltantes bombas de hierro grandes
215403	suministros faltantes miras mortales
215404	suministros faltantes trabucos de mitril
215405	suministros faltantes botas cohete gnomicas
215406	suministros faltantes morteros goblin
215407	suministros faltantes sobrehombros barbaricos
215408	suministros faltantes guantes de guardian
215409	suministros faltantes brazales de escamas de tortuga
215410	suministros faltantes cinturones oscurecidos
215411	suministros faltantes capas de cuero de escarcha
215412	suministros faltantes guantes sombradermos
215413	suministros faltantes camisas blancas formales
215414	suministros faltantes bombachos de seda carmesies
215415	suministros faltantes camisas de seda morada viva
215416	suministros faltantes mascaras de bandido blancas
215417	suministros faltantes sopa de tortuga reconfortante
215418	suministros faltantes salchichas de arana
215419	suministros faltantes vendas de seda gruesas
215420	suministros faltantes bacalao piedrescama
215421	suministros faltantes aceite de fuego
215422	patron almofar de escamas brillantes hiperconductivo
215423	patron caperuza de canalizador gneuroconductiva
215424	patron caperuza de escamas resistente a la radiacion
215425	eco del pantano
215426	eco del cementerio
215427	eco de arathi
215428	eco de theramore
215429	esquema engranajes de veraplata pulidos
215430	residuos radioactivos de gnomeregan
215431	esquema bomba de radiacion de alto rendimiento
215432	esquema bomba de radiacion para tontos
215433	receta gniodino aislante
215435	tratado sobre oracion
215436	totem de llama vigorizante
215437	transfigurador trogg 3000
215441	martillo roto
215443	fragmento de orbe destrozado
215444	monstruo maza tuberias rotas
215449	encogemundos
215450	proyecto de tabardo aidan
215456	mensaje calcinado
215458	mensaje cerrado
215459	mensaje cerrado
215460	mensaje cerrado
215461	pollo de ataque domesticado
215468	ordenes del gran cruzado
215683	geomancia de rocas y verdades
215815	magia defensiva i
215816	una red de mentiras toda la verdad sobre los mitos y las leyendas
215817	los demonios y tu
215820	momias una guia de los no muertos mas espantosos
215822	¡rwlrwlrwlrwl
215824	guia de cuidado de mascotas demoniacas para el ludita comun
216484	botas de batalla impactojorfadas
216485	coraza impactoforjada
216486	quijotes impactoforjados
216490	idolo de la colera
216491	cargamento de lena de tuercespina
216492	silbato del raptor sanguino jaspeado
216494	tuercemundos extravagante de aragriar
216495	trituradora sanguina
216496	trituracraneos sanguina
216497	desangrado
216498	grimorio sanguino encantado
216499	trituradora sangrecorteza
216500	talisman arboreo con juramento de sangre
216501	barrera tormenta de sangre
216502	totem de guerra tormenta de sangre
216503	joya tormenta de sangre
216504	sable luz de sangre eclipsado
216505	radiancia de cruzado luz de sangre
216506	filo de vengador luz de sangre
216507	sello de sangre umbrio
216508	sortija espiral de sangre infernal
216509	esencia de pacto infernal
216510	circulo de sangre resonante
216511	sello de sangrefuego
216512	aro de venas heladas
216513	talisman de tigre sangriento
216514	carcaj sanguino
216515	faltriquera de municion sanguina
216516	arco lazo sangriento
216517	santuario sanguino
216518	sello de alianza de sangre
216519	sortija sombra sanguina
216520	cuchilla cosechasangre
216521	aporreadores rapidos sanguinos
216522	estilete salpicado de sangre
216523	llave de jaula oxidada
216570	riendas del dientes de sable dorado
216606	runa de maestria en dos manos
216607	ofrenda de luz sanguinea
216608	reflectores de rayos radiantes
216610	ordenes del gran cruzado
216615	faro de tormenta de sangre ancestral
216616	llave de jaula de la base
216617	uniforme de luchador de kurzen
216618	recompensa de la capitana aransas
216619	vianda de estudiante
216620	capa de podrisangre
216621	manton empapado de sangre
216622	capa coagulada
216623	manteo de hemostasis
216633	tornapunta de veraplata hidraulica
216634	fusible gg12 082
216635	nucleo del vacio gastado
216636	nucleo del vacio cargado
216637	una pila de piezas aleatorias
216645	mota de oscuridad
216646	cajon misterioso de ziri
216661	anillo con mugre incrustada
216662	anillo de oro luminoso
216673	anillo de oro luminoso de talvash
216674	anillo de oro luminoso de nogg
216675	togas civinad pristinas
216676	peto de corredor veloz
216678	leotardos triples reforzados
216679	herramienta de desmantelamiento de shoni
216680	manoplas llamativas
216698	braquiales de pellejo de dragon de alferez
216699	guardabrazos de anillas de alferez
216700	braquiales de cuero de alferez
216701	guardamunecas de placas de alferez
216702	punos de seda de alferez
216703	guardamunecas de malla de gran capataz
216704	guardabrazos de pellejo de dragon de gran capataz
216705	brazales de placas de gran capataz
216706	guardabrazos de cuero de gran capataz
216707	punos de seda de gran capataz
216738	manual de redirigir
216740	tomo de intelecto expandido
216744	pergamino de entereza aumentada
216745	pergamino de maligno de las sombras
216746	vademecum de grito de orden
216747	grimorio de cosecha de almas
216748	grimorio de portal de invocacion
216764	panfleto de salvajismo dominante
216767	panfleto de revivir
216769	revelacion de proyeccion totemica
216770	tratado sobre aspecto de la vibora
216771	panfleto de restauracion mejorada
216879	pergamino trol misterioso
216880	pergamino trol descifrado
216884	hoja sedienta de sangre
216914	mencion deslustrada
216918	botas corazon vil
216919	fajin corazon vil
216920	ataduras corazon vil
216921	mandiletes corazon vil
216922	corona corazon vil
216923	leotardos corazon vil
216924	abrazo corazon vil
216925	manto corazon vil
216938	insignia de la alianza superior
216939	insignia de la horda superior
216941	sigilo de ariden
216945	reliquia de dalaran curiosa
216946	reliquia de dalaran resplandeciente
216947	reliquia de dalaran zumbante
216948	reliquia de dalaran vieja
216949	reliquia de dalaran pesada
216950	reliquia de dalaran espeluznante
216951	reliquia de dalaran resbaladiza
216956	carta rota
216971	cartera de monedas de sangre de cobre
216972	cartera de monedas de sangre de plata
217005	manteo de mecanico
217006	martillo de mecanico
217007	botas sin poder
217008	pechera sin poder
217009	piernas sin poder
217014	bolsa de suministros
217017	¡torneo de pesca
217161	notas de hechizo pargesco ria drofide
217244	patron toga de seda carmesi
217245	toga de seda carmesi
217246	jubon de tejido magico negro
217247	leotardos de tejido magico negros
217248	cinturon de seda terranea
217249	patron cinturon de seda terranea
217250	sobrehombros de seda carmesies
217251	patron sobrehombros de seda carmesies
217252	capa larga de seda
217253	botas del encantador
217254	patron botas del encantador
217255	cinturon de seda carmesi
217256	jubon terraneo
217257	capucha de encantador
217258	patron capucha de encantador
217259	mascara de gran vudu
217260	patron mascara de gran vudu
217261	toga de gran vudu
217262	patron toga de gran vudu
217263	brazales de cuero de guardian
217264	patron brazales de cuero de guardian
217265	cinturon de guardian
217266	patron cinturon de guardian
217267	pantalones de guardian
217268	coraza de escamas de tortuga
217270	guantes de escamas de tortuga
217271	patron guantes de escamas de tortuga
217273	guanteletes de escamas doradas
217274	diseno guanteletes de escamas doradas
217275	botas de escamas doradas
217276	diseno botas de escamas doradas
217277	loriga de escamas doradas
217278	diseno loriga de escamas doradas
217279	almofar de escamas doradas
217280	diseno almofar de escamas doradas
217281	espada ancha de acero lunar
217282	diseno espada ancha de acero lunar
217283	sobrehombros de escamas doradas
217284	diseno sobrehombros de escamas doradas
217285	leotardos de escamas doradas
217286	diseno leotardos de escamas doradas
217287	varita mistica superior
217288	togas del exanime
217289	armadura friomortal
217290	ojo resplandeciente de mordresh
217291	calavera inerte mordresh
217292	fajin de mago de la muerte
217293	manteo de arana sedosa
217294	embozo embalsamado
217295	varita necrotica
217296	dije de fragmento fantasmal
217297	toga de doan
217298	manto de doan
217299	vara ilusionaria
217300	sombrero de melenablanca
217301	amuleto triune
217302	poderio de mograine
217303	leotardos tejepiedra
217304	guantes de revelosh
217305	guardabrazos de revelosh
217306	botas de revelosh
217307	bufas de revelosh
217308	sigilo encantado innovacion
217314	rifle de vista lunar
217315	arco de precision
217337	cargamento de suministros
217338	cargamento de suministros
217339	cargamento de suministros
217345	veneno sebaceo
217346	veneno entumecedor
217347	veneno atrofico
217350	notas de ingenieria de termochufe
217351	notas de ingenieria de termochufe
217398	elixir arcano inferior
217399	receta elixir arcano inferior
217495	pergamino de crioexplosion
217496	pergamino de la hoja
217497	espada de narpas
217609	talisman de kazdor
217693	pocion de invisibilidad
217704	cachiporra de hierro
217717	emblema hueco
217718	emblema de magia de sangre
217719	esencia de magia de sangre
217720	ofrenda de carne
217721	ofrenda de hueso
217727	resguardo de los muertos
217736	runa del conventiculo
217737	talisman modificado
219021	paquete de mensajeria pesado
219022	anillo de transportista
219023	anillo de empleado
219024	anillo de mensajero
219135	colgante de curiosidad
219136	colgante de tenacidad
219137	colgante de iniciativa
219147	runa de gracia
219223	furia del maestro del acero
219326	semilla de renovacion
219343	capucha de ratero
219345	lazo infernal
219399	musgo de pesadilla
219401	mena de hierro fria
219402	dragontina de toque onirico
219404	umbriguadana
219405	texto de ogro mago
219406	huevo de dragon verde sin eclosionar
219414	cascaras de huevo rotas
219444	raiz onirica
219445	polvo de oro de tontos
219446	dragontina de infusion onirica
219447	huevo de dragon tocado por el sueno
219448	maquina de los suenos
219449	profecia de azshara
219454	loto estelar
219486	mena de platastral
219487	astrocaparazon
219488	huevo de dragon astroungido
219490	reliquia elunar
219491	perla onirica
219514	lunarraiz
219515	piedra lunar grande
219517	escama de dragon lunar
219518	diatriba de arpia
219519	notas del protector demente
219520	huevo de dragon de resplandor lunar
219526	informe de mision bosque del ocaso
219759	informe de campo de carla
219770	informe de campo de vernon
219771	informe de campo de thandros
219772	informe de campo de fallia
219773	informe de mision vallefresno
219774	informe de mision tierras del interior
219775	informe de mision feralas
219776	informe de inteligencia tumulo de vul gol
219778	informe de inteligencia el vergel putrido
219803	informe de inteligencia hacienda yorgen
219918	misiva sangrienta
219924	informe de inteligencia cancion del bosque
219925	informe de inteligencia satyrnaar
219926	informe de inteligencia aserradero grito de guerra
219927	esquirla esmeralda
219928	informe de inteligencia agol watha
219929	misiva sangrienta
219930	misiva sangrienta
219935	hoja de kajind
219937	informe de inteligencia shaol watha
219938	informe de inteligencia roca oculta
219957	informe de inteligencia oneiros
219958	informe de inteligencia los dos colosos
219959	informe de inteligencia ruinas de viento azabache
219962	incursiones de pesadilla mision i del bosque del ocaso
219963	autorizacion de designacion mision i de bosque del ocaso
219965	autorizacion de designacion mision ii de bosque del ocaso
219966	incursiones de pesadilla mision ii del bosque del ocaso
219967	incursiones de pesadilla mision iii del bosque del ocaso
219968	incursiones de pesadilla mision iv del bosque del ocaso
219969	incursiones de pesadilla mision v del bosque del ocaso
219970	incursiones de pesadilla mision vi del bosque del ocaso
219971	incursiones de pesadilla mision vii del bosque del ocaso
219972	incursiones de pesadilla mision viii del bosque del ocaso
219973	incursiones de pesadilla mision ix del bosque del ocaso
219974	incursiones de pesadilla mision x del bosque del ocaso
219975	incursiones de pesadilla mision xi del bosque del ocaso
219976	incursiones de pesadilla mision xii del bosque del ocaso
219977	incursiones de pesadilla mision xiii del bosque del ocaso
219978	incursiones de pesadilla mision xiv del bosque del ocaso
219979	incursiones de pesadilla mision xv del bosque del ocaso
219980	incursiones de pesadilla mision xvi del bosque del ocaso
219981	incursiones de pesadilla mision xvii del bosque del ocaso
219982	incursiones de pesadilla mision xviii del bosque del ocaso
219983	autorizacion de designacion mision iii de bosque del ocaso
219984	autorizacion de designacion mision iv de bosque del ocaso
219985	autorizacion de designacion mision v de bosque del ocaso
219986	autorizacion de designacion mision vi de bosque del ocaso
219987	autorizacion de designacion mision vii de bosque del ocaso
219988	autorizacion de designacion mision viii de bosque del ocaso
219989	autorizacion de designacion mision ix de bosque del ocaso
219990	autorizacion de designacion mision x de bosque del ocaso
219991	autorizacion de designacion mision xi de bosque del ocaso
219992	autorizacion de designacion mision xii de bosque del ocaso
219993	autorizacion de designacion mision xiii de bosque del ocaso
219994	autorizacion de designacion mision xiv de bosque del ocaso
219995	autorizacion de designacion mision xv de bosque del ocaso
219996	autorizacion de designacion mision xvi de bosque del ocaso
219997	autorizacion de designacion mision xvii de bosque del ocaso
219998	autorizacion de designacion mision xviii de bosque del ocaso
219999	incursiones de pesadilla mision i de vallefresno
220000	incursiones de pesadilla mision ii de vallefresno
220001	incursiones de pesadilla mision iii de vallefresno
220002	incursiones de pesadilla mision iv de vallefresno
220003	incursiones de pesadilla mision v de vallefresno
220004	incursiones de pesadilla mision vi de vallefresno
220005	incursiones de pesadilla mision vii de vallefresno
220006	incursiones de pesadilla mision viii de vallefresno
220007	incursiones de pesadilla mision ix de vallefresno
220008	incursiones de pesadilla mision x de vallefresno
220009	incursiones de pesadilla mision xi de vallefresno
220010	incursiones de pesadilla mision xii de vallefresno
220011	incursiones de pesadilla mision xiii de vallefresno
220012	incursiones de pesadilla mision xiv de vallefresno
220013	incursiones de pesadilla mision xv de vallefresno
220014	incursiones de pesadilla mision xvi de vallefresno
220015	incursiones de pesadilla mision xvii de vallefresno
220016	incursiones de pesadilla mision xviii de vallefresno
220017	incursiones de pesadilla mision i de las tierras del interior
220018	incursiones de pesadilla mision ii de las tierras del interior
220019	incursiones de pesadilla mision iii de las tierras del interior
220020	incursiones de pesadilla mision iv de las tierras del interior
220021	incursiones de pesadilla mision v de las tierras del interior
220022	incursiones de pesadilla mision vi de las tierras del interior
220023	incursiones de pesadilla mision vii de las tierras del interior
220024	incursiones de pesadilla mision viii de las tierras del interior
220025	incursiones de pesadilla mision ix de las tierras del interior
220026	incursiones de pesadilla mision x de las tierras del interior
220027	incursiones de pesadilla mision xi de las tierras del interior
220028	incursiones de pesadilla mision xii de las tierras del interior
220029	incursiones de pesadilla mision xiii de las tierras del interior
220030	incursiones de pesadilla mision xiv de las tierras del interior
220031	incursiones de pesadilla mision xv de las tierras del interior
220032	incursiones de pesadilla mision xvi de las tierras del interior
220033	incursiones de pesadilla mision xvii de las tierras del interior
220034	incursiones de pesadilla mision xviii de las tierras del interior
220035	incursiones de pesadilla mision i de feralas
220036	incursiones de pesadilla mision ii de feralas
220037	incursiones de pesadilla mision iii de feralas
220038	incursiones de pesadilla mision iv de feralas
220039	incursiones de pesadilla mision v de feralas
220040	incursiones de pesadilla mision vi de feralas
220041	incursiones de pesadilla mision vii de feralas
220042	incursiones de pesadilla mision viii de feralas
220043	incursiones de pesadilla mision ix de feralas
220044	incursiones de pesadilla mision x de feralas
220045	incursiones de pesadilla mision xi de feralas
220046	incursiones de pesadilla mision xii de feralas
220047	incursiones de pesadilla mision xiii de feralas
220048	incursiones de pesadilla mision de feralas xiv
220049	incursiones de pesadilla mision de feralas xv
220050	incursiones de pesadilla mision de feralas xvi
220051	incursiones de pesadilla mision de feralas xvii
220052	incursiones de pesadilla mision de feralas xviii
220053	autorizacion de designacion mision i de vallefresno
220054	autorizacion de designacion mision ii de vallefresno
220055	autorizacion de designacion mision iii de vallefresno
220056	autorizacion de designacion mision iv de vallefresno
220057	autorizacion de designacion mision v de vallefresno
220058	autorizacion de designacion mision vi de vallefresno
220059	autorizacion de designacion mision vii de vallefresno
220060	autorizacion de designacion mision viii de vallefresno
220061	autorizacion de designacion mision ix de vallefresno
220062	autorizacion de designacion mision x de vallefresno
220063	autorizacion de designacion mision xi de vallefresno
220064	autorizacion de designacion mision xii de vallefresno
220065	autorizacion de designacion mision xiii de vallefresno
220066	autorizacion de designacion mision xiv de vallefresno
220067	autorizacion de designacion mision xv de vallefresno
220068	autorizacion de designacion mision xvi de vallefresno
220069	autorizacion de designacion mision xvii de vallefresno
220070	autorizacion de designacion mision xviii de vallefresno
220071	autorizacion de designacion mision i de las tierras del interior
220072	autorizacion de designacion mision ii de las tierras del interior
220073	autorizacion de designacion mision iii de las tierras del interior
220074	autorizacion de designacion mision iv de las tierras del interior
220075	autorizacion de designacion mision v de las tierras del interior
220076	autorizacion de designacion mision vi de las tierras del interior
220077	autorizacion de designacion mision vii de las tierras del interior
220078	autorizacion de designacion mision viii de las tierras del interior
220079	autorizacion de designacion mision ix de las tierras del interior
220080	autorizacion de designacion mision x de las tierras del interior
220081	autorizacion de designacion mision xi de las tierras del interior
220082	autorizacion de designacion mision xii de las tierras del interior
220083	autorizacion de designacion mision xiii de las tierras del interior
220084	autorizacion de designacion mision xiv de las tierras del interior
220085	autorizacion de designacion mision xv de las tierras del interior
220086	autorizacion de designacion mision xvi de las tierras del interior
220087	autorizacion de designacion mision xvii de las tierras del interior
220088	autorizacion de designacion mision xviii de las tierras del interior
220089	autorizacion de designacion mision i de feralas
220090	autorizacion de designacion mision ii de feralas
220091	autorizacion de designacion mision iii de feralas
220092	autorizacion de designacion mision iv de feralas
220093	autorizacion de designacion mision v de feralas
220094	autorizacion de designacion mision vi de feralas
220095	autorizacion de designacion mision vii de feralas
220096	autorizacion de designacion mision viii de feralas
220097	autorizacion de designacion mision ix de feralas
220098	autorizacion de designacion mision x de feralas
220099	autorizacion de designacion mision xi de feralas
220100	autorizacion de designacion mision xii de feralas
220101	autorizacion de designacion mision xiii de feralas
220102	autorizacion de designacion mision xiv de feralas
220103	autorizacion de designacion mision xv de feralas
220104	autorizacion de designacion mision xvi de feralas
220105	autorizacion de designacion mision xvii de feralas
220106	autorizacion de designacion mision xviii de feralas
220164	runa del gladiador
220165	runa de colera
220166	nucleo infernal ardiente
220167	polvo de sepultura resplandeciente
220168	cerveza fundida de triple filtrado
220169	simbolo de fe
220173	parasomnia
220213	sangrevida vil
220214	eslabon infernal
220216	lazo infernal
220217	runa del voraz
220345	hechiceria sanguina
220346	leyendas de los maresabios
220347	lo liminal y lo arcano
220348	etiqueta para el dia a dia
220349	diseno trabajado en piedra
220350	travesias venenosas
220351	sapta de aire de murky
220352	mente metalica
220353	codice del conjurador
220360	runa de floracion
220375	fragmento de aire
220379	notas de chaman rasgadas
220446	tesoro sobrenatural
220510	esencia elemental
220511	gran yelmo de la pesadilla
220512	casco de acero aureo inmaculado
220514	visor de plumas verdeante
220515	casco esmeralda encantado
220516	visor olvidado de gasher
220518	sombrero polvoriento de ba ham
220519	ornato emplumado vudu
220521	ornato de ritualista hakkari
220522	corona atrapadora de almas
220523	rostro de los exiliados
220525	fragmento de aire resplandeciente
220526	procesador de n u c l e o g 7 cubierto de fango
220527	manto de rabioso atal ai
220528	sobrehombros de cazador atal ai
220529	bufas de fanatismo
220530	voluntad del guerrero atal ai
220531	flor purpura ondulante
220532	bufas atal ai reforzadas
220533	coraza atal ai reforjada
220534	abrazo eterno de la serpiente alada
220535	prendas de profeta atal ai
220536	munequeras de auxiliador atal ai
220537	brazales aguaoscura de sonador
220538	brazales de escama de babosa malditos
220539	brazales de guerra de sacrificio
220540	manoplas cargadas de corrupcion
220541	punos de placas libres de enfermedades
220542	guanteletes aguasucia contaminados
220543	guantes de malla de escamas esmeralda
220544	garfas de pirosangre
220545	guantes de combatiente hediondos
220546	manos de los atormentados
220547	guantes del profeta atal ai caido
220548	guantes de aojador atal ai
220549	correa de espiral del alba
220550	pretina de despojador de templos
220551	fajin del sueno esmeralda de devoto
220552	guardarrenes de dolor
220553	cinturon del adorador renegado
220554	sortija de colmillo de atal alarion
220555	faja de escamas de serpiente atal ai
220556	falda del profeta atal ai caido
220557	sarong de escamas de viento maldito
220558	leotardos de asesino atal ai
220559	leotardos de escamas de draco revitalizadas
220560	quijotes de caparazon plateado
220561	chanclos de trol tenaz
220562	grebas de batalla de tirosangre
220563	botas del chaman de sangre atal ai
220564	botas de escamas humedas restauradas
220565	botas de caminaniebla etereas
220566	zarpa abrasadora
220567	cabeza de pincho ensangrentada
220568	hacha pistola de explorador de templo
220569	martillo de ira abrasador
220570	manto de pesadillas
220571	arco largo punzante
220572	repetidor rapido de rinzo
220573	arco de caza de acechador nefasto
220574	diente de eranikus afilado
220575	devorador de los condenados
220576	hacha del ejecutor atal ai
220577	poderio del loa de la sangre
220578	puno de los renegados
220579	palo de mojo de medico brujo
220580	locura del avatar
220581	machacaserpientes
220582	grito de dragon
220583	hoja de los desdichados vil
220584	hoja de aliento de llamas
220585	una funesta degradada
220586	arrogancia la marcabandidos
220587	daga del sueno de sacrificio
220588	garra de colmillo de cobra
220589	golpeador de serpiente
220590	aguja de adoracion hakkari
220591	vara restauradora de mijan
220594	guadana del sueno
220595	baston de foco de pesadilla
220596	vara adivinatoria antigua
220597	piedra draco de emisario del sueno
220598	piedra draco emisario de pesadilla
220599	piedra draco de profeta de sangre
220600	emblema de preeminencia
220601	protector de medica bruja hakkari
220602	medio caparazon de tortuga de alcantarilla
220603	vara de corrosion irreversible
220604	trofeo de pesadilla
220605	tratado sobre sacrilegio
220606	idolo del sueno
220607	totem de linaje atormentado
220608	manton de piel emplumada
220609	manton del ocaso
220610	runa de mana mental
220611	manteo de maleficio de hukku
220612	runa de maremotos
220613	runa de trueno ensordecedor
220614	runa de choque estatico
220615	capa de piel de pantera
220616	runa de sobrecarga
220617	runa de pandemia
220618	runa de aura de inmolacion
220619	ceremonia de sangre atal ai
220620	calavera de serpiente alada
220621	cristal de resonancia de pesadilla
220622	ojo de dragon perfectamente preservado
220623	guardapelo perdido de jin do
220624	talisman de valor manchado de sangre
220625	resiliencia de los exiliados
220626	sortija de garra de draco de rabioso
220627	sortija de garra de draco de acechador
220628	sortija de garra de draco de emisario
220629	sortija de garra de draco de profeta de sangre
220630	sortija de garra de draco de gigante
220632	medallon de ritual de sangre atal ai
220633	insignia de ritual de sangre atal ai
220634	talisman de ritual de sangre atal ai
220635	roca encantada de atal alarion
220636	icono de sangre atal ai
220637	ficha de ritual atal ai
220638	palo de maleficios poco ortodoxo
220639	inanimator de lledra
220642	armadura de placas de martir expulsado
220643	musleras de placas de martir expulsado
220648	botas de placas de martir expulsado
220649	herencia de merithra
220650	peto de profeta obsesionado
220651	musleras de profeta obsesionado
220652	botas ornamentadas de profeta obsesionado
220653	peto de rabioso quejumbroso
220654	quijotes de rabioso quejumbroso
220656	botas de batalla de rabioso quejumbroso
220657	camisote de rabioso desterrado
220658	quijotes de rabioso desterrado
220659	grebas de anillas de rabioso desterrado
220660	camisa de anillas de devoto marginado
220661	musleras de devoto marginado
220662	botas de escamas de devoto marginado
220663	leotardos de tejespiritus corrupto
220664	escarpes de tejespiritus corrupto
220665	coraza de tejespiritus corrupto
220666	malla de anillas de cazador aterrador
220667	botarga de cazador aterrador
220668	grebas de cazador aterrador
220669	chaleco de profeta exiliado
220670	zapatillas de profeta exiliado
220671	pantalones de cuero de profeta exiliado
220672	arnes de adorador perdido
220673	leotardos de adorador perdido
220674	espada sigilosa estropeada
220675	botines de adorador perdido
220676	guerrera corrupta con sangre
220677	botas corruptas con sangre
220678	pantalones corruptos con sangre
220679	leotardos de profeta malevolo
220680	jubon de profeta malevolo
220681	sandalias de profeta malevolo
220682	runa del desbocado
220683	jubon de profeta benevolo
220684	leotardos de profeta benevolo
220685	sandalias de profeta benevolo
220686	azote del cabecilla
220687	runa del raptor
220688	manto de pesadillas inerte
220689	avambrazos potenciados por el vacio
220738	hombreras de pavor
220739	espaldares torvos
220740	guardahombros aterrorizadores
220741	espaldares de anillas vociferantes
220742	bufas chillonas
220743	guardahombros de anillas cacofonos
220744	manto de anillas gemebundo
220745	membrana de neurosis oscura
220747	manto de paranoia
220748	hombreras de obsesion
220749	manto de demencia
220750	espaldares de mente fracturada
220751	hombreras del trastornado
220754	runa de la tormenta de viento
220775	ticket de intercambio de ingenieria
220778	pantalones de guardia de sangre coagulada
220779	guerrera de guardia de sangre coagulada
220780	botas de guardia de sangre coagulada
220781	leotardos de profeta de pesadilla
220783	vestimentas de profeta de pesadilla
220784	sandalias de profeta de pesadilla
220791	runa del felino selvatico
220792	pergamino de reparacion espacial
220794	camisote de placas de caballero
220795	espaldares de placas de teniente caballero
220796	espaldares de placas de guardia de sangre
220797	leotardos de placas de caballero
220798	leotardos de placas de guardia de piedra
220799	grebas de placas de alferez
220800	grebas de placas de gran capataz
220801	armadura de placas de guardia de piedra
220803	yelmo de placas de guardia de sangre
220804	yelmo de placas de teniente caballero
220806	guanteletes de placas de alferez
220807	guanteletes de placas de gran capataz
220808	espaldares imbuidos de teniente caballero
220809	leotardos imbuidos de caballero
220810	yelmo imbuido de teniente caballero
220811	grebas imbuidas de alferez
220812	guanteletes imbuidos de alferez
220813	armadura imbuida de caballero
220814	botas de laminas de alferez
220815	peto de laminas de caballero
220816	quijotes de laminas de caballero
220817	guanteletes de laminas de alferez
220818	espaldares de laminas de teniente caballero
220819	yelmo de laminas de teniente caballero
220820	yelmo de malla de guardia de sangre
220821	yelmo de anillas de guardia de sangre
220822	yelmo de anillas de teniente caballero
220823	cubrehombros de malla de guardia de sangre
220824	cubrehombros de anillas de guardia de sangre
220825	cubrehombros de anillas de teniente caballero
220826	armadura de malla de guardia de piedra
220827	armadura de anillas de guardia de piedra
220828	armadura de anillas de caballero
220829	guanteletes de anillas de alferez
220830	guanteletes de anillas de gran capataz
220831	guanteletes de malla de gran capataz
220832	quijotes de anillas de caballero
220833	quijotes de anillas de guardia de piedra
220834	quijotes de malla de guardia de piedra
220835	escarpes de malla de gran capataz
220836	escarpes de anillas de gran capataz
220837	escarpes de anillas de alferez
220838	pechera con inscripciones de guardia de piedra
220839	quijotes con inscripciones de guardia de piedra
220840	escarpes con inscripciones de gran capataz
220841	hombreras con inscripciones de guardia de sangre
220842	escutelaria con inscripciones de guardia de sangre
220843	guanteletes con inscripciones de gran capataz
220844	coraza pulsante de guardia de piedra
220845	guanteletes pulsantes de gran capataz
220846	grebas pulsantes de gran capataz
220847	quijotes pulsantes de guardia de piedra
220848	yelmo pulsante de guardia de sangre
220849	sobrehombros pulsantes de guardia de sangre
220850	cinta de cuero de teniente caballero
220851	cinta de cuero de guardia de sangre
220852	sobrehombros de cuero de teniente caballero
220853	sobrehombros de cuero de guardia de sangre
220854	armadura de cuero de caballero
220855	armadura de cuero de guardia de piedra
220856	guanteletes de cuero de alferez
220857	guanteletes de cuero de gran capataz
220858	pantalones de cuero de caballero
220859	pantalones de cuero de guardia de piedra
220860	botas de cuero de alferez
220861	botas de cuero de gran capataz
220862	botas de cuero arrugadas de alferez
220863	botas de cuero arrugadas de gran capataz
220864	leotardos de cuero arrugados de caballero
220865	leotardos de cuero arrugados de guardia de piedra
220866	guanteletes de cuero arrugados de alferez
220867	guanteletes de cuero arrugados de gran capataz
220868	guerrera de cuero arrugada de caballero
220869	guerrera de cuero arrugada de guardia de piedra
220870	bufas de cuero arrugado de teniente caballero
220871	bufas de cuero arrugado de guardia de sangre
220872	yelmo de cuero arrugado de teniente caballero
220873	yelmo de cuero arrugado de guardia de sangre
220874	yelmo de cuero restaurado de teniente caballero
220875	yelmo de cuero restaurado de guardia de sangre
220876	bufas de cuero restauradas de teniente caballero
220877	bufas de cuero restauradas de guardia de sangre
220878	chaleco de cuero restaurado de caballero
220879	chaleco de cuero restaurado de guardia de piedra
220880	guantes de cuero restaurados de alferez
220881	guantes de cuero restaurados de gran capataz
220882	leotardos de cuero restaurados de caballero
220883	leotardos de cuero restaurados de guardia de piedra
220884	botas de cuero restauradas de alferez
220885	botas de cuero restauradas de gran capataz
220886	jubon de tejido de tinieblas de caballero
220887	manto de tejido de tinieblas de teniente caballero
220888	leotardos de tejido de tinieblas de caballero
220889	sombrero de tejido de tinieblas de teniente caballero
220890	guantes de tejido de tinieblas de alferez
220891	botas de tejido de tinieblas de alferez
220892	armadura de saten de caballero
220893	leotardos de saten de caballero
220894	hombreras de saten de teniente caballero
220895	botas de saten de alferez
220896	casquete de saten de teniente caballero
220897	guantes de saten de alferez
220898	guantes de saten de gran capataz
220899	casquete de saten de guardia de sangre
220900	botas de saten de gran capataz
220901	hombreras de saten de guardia de sangre
220902	leotardos de saten de guardia de piedra
220903	armadura de saten de guardia de piedra
220904	jubon de tejido de tinieblas de guardia de piedra
220905	manto de tejido de tinieblas de guardia de sangre
220906	leotardos de tejido de tinieblas de guardia de piedra
220907	sombrero de tejido de tinieblas de guardia de sangre
220908	guantes de tejido de tinieblas de gran capataz
220909	botas de tejido de tinieblas de gran capataz
220912	martillo de geodas
220913	runa de demolicion
220914	martillo de geodas roto
220915	idolo del arrastrapies colerico
220916	cuerno de estegodon silenciatruenos
220917	caja de tinte escarlata
220918	suministros faltantes sopa de almejas de minahonda
220919	suministros faltantes sopa de pargo nocturno
220920	suministros faltantes chuletas de lobo tiernas
220921	suministros faltantes vendas de tejido magico gruesas
220922	suministros faltantes solea
220923	suministros faltantes hojasueno
220924	suministros faltantes barras de veraplata
220925	suministros faltantes barras de torio
220926	suministros faltantes cuero basto
220927	suministros faltantes pellejo grueso
220928	suministros faltantes barras de torio encantado
220929	suministros faltantes pociones de mana excelentes
220930	suministros faltantes pociones de sanacion sublime
220931	suministros faltantes bombas altamente explosivas
220932	suministros faltantes granadas de torio
220933	suministros faltantes rifles de torio
220934	suministros faltantes almofares de mitril
220935	suministros faltantes cinturones de torio
220936	suministros faltantes guanteletes de veraplata
220937	suministros faltantes refuerzos para armadura bastos
220938	suministros faltantes brazales de cuero maligno
220939	suministros faltantes brazales de cuero runico
220940	suministros faltantes cintas de tejido magico negra
220941	suministros faltantes cinturones de pano runico
220942	suministros faltantes camisas de esmoquin
220964	avambrazos potenciados por el vacio descargados
220965	gran hacha de horrocrusto
221008	cargamento de suministros
221009	cargamento de suministros
221010	cargamento de suministros
221017	registro de keldara
221018	botiquin de campo
221019	muestra de herbasatiro
221020	runa de la diosa lunar
221021	semilla de pesadilla
221024	frasco de pesadillas perpetuas
221025	avambrazos de invocador potenciados por el vacio
221026	avambrazos de destripador potenciados por el vacio
221027	avambrazos de protector potenciados por el vacio
221028	sigilo encantado suenos vivos
221030	mojo atal ai de magia prohibida
221191	piedra onirica
221192	diario de suenos
221193	anillo de esmeralda
221196	mojo atal ai de guerra
221199	tintura de herbasatiro
221256	brazo derecho del desintegrador
221257	brazo izquierdo del desintegrador
221258	pie derecho del desintegrador
221259	pie izquierdo del desintegrador
221260	cabeza del desintegrador
221261	jarabe de susurro salvaje
221262	ofrenda salvaje
221267	runa de los sanguinarios
221271	as de naturaleza
221272	baraja de naturaleza
221273	dos de naturaleza
221274	tres de naturaleza
221275	cuatro de naturaleza
221276	cinco de naturaleza
221277	seis de naturaleza
221278	siete de naturaleza
221279	ocho de naturaleza
221280	baraja de plagas
221281	as de plagas
221282	dos de plagas
221283	tres de plagas
221284	cuatro de plagas
221285	cinco de plagas
221286	seis de plagas
221287	siete de plagas
221288	ocho de plagas
221289	baraja de dunas
221290	as de dunas
221291	dos de dunas
221292	tres de dunas
221293	cuatro de dunas
221294	cinco de dunas
221295	seis de dunas
221296	siete de dunas
221297	ocho de dunas
221298	as de pesadillas
221299	baraja de pesadillas
221300	dos de pesadillas
221301	tres de pesadillas
221302	cuatro de pesadillas
221303	cinco de pesadillas
221304	seis de pesadillas
221305	siete de pesadillas
221306	ocho de pesadillas
221307	naipe de la luna negra descomposicion
221308	naipe de la luna negra sobrecrecimiento
221309	naipe de la luna negra tormenta de arena
221310	naipe de la luna negra tormento
221311	mojo atal ai de vida
221312	frasco de mojo atal ai
221313	frasco de mojo de pesadilla
221314	cartel de se busca
221315	generador de arcoiris
221316	uniforme exclusivo de premo
221317	leycrist de feralas
221318	leycrist de azshara
221319	leycrist de roca negra
221320	leycrist de las tierras del interior
221321	sello atal ai de poderio
221322	sello atal ai de mojo
221323	sello atal ai de serenidad
221324	llave forjatiniebla fragil
221325	carga explosiva para tontos
221326	corazon de venado sagrado
221327	esquema rayo reductor gnomico
221328	esquema gafas gnomicas
221329	esquema proyector redomatico gnomico
221330	esquema cinturon de prevencion de dano gnomico
221331	esquema botas cohete gnomicas
221332	esquema gallo de batalla gnomico
221333	esquema gorro de control mental gnomico
221334	esquema rayo mortal gnomico
221335	esquema casco de albanil goblin
221336	esquema casco de minero goblin
221337	esquema mortero goblin
221338	esquema carga de zapador goblin
221339	esquema botas cohete goblin
221340	esquema dispensador de bombas goblin
221341	esquema el grande
221342	esquema escopeta dragon goblin
221343	esquema casco cohete goblin
221344	libro de hechizos personal
221345	sangre corrupta de eranikus
221346	omoplato del avatar caido
221347	sapta de fuego turbia
221348	sapta de agua turbia
221349	sapta de tierra turbia
221350	notas de chaman chamuscadas
221351	notas de chaman empapadas
221352	notas de chaman borroneadas
221353	fragmento de fuego
221354	fragmento de agua
221355	fragmento de tierra
221356	fragmento de fuego resplandeciente
221357	fragmento de agua resplandeciente
221358	fragmento de tierra resplandeciente
221359	pluma de lechubestia pristina
221360	papiro farraki
221361	resina de zukk ash
221362	pano para limpiar armas
221363	omoplato del avatar caido
221364	moneda de masacre de cobre
221365	moneda de masacre de plata
221366	moneda de masacre de oro
221367	cartera de monedas de masacre de cobre
221368	cartera de monedas de masacre de plata
221369	succion de pesadilla
221370	medallon precioso
221371	monedero de secuestrador
221372	monedero destrozado
221374	angustia del sueno
221376	yelmo del sueno esmeralda
221377	quijotes del sueno esmeralda
221378	guanteletes del sueno esmeralda
221379	escarpes del sueno esmeralda
221380	coraza del sueno esmeralda
221381	espaldares del sueno esmeralda
221382	placa de batalla taraceada esmeralda
221383	manoplas taraceadas esmeralda
221384	casco taraceado esmeralda
221385	quijotes taraceados esmeralda
221386	bufas taraceadas esmeralda
221387	botas de placas taraceadas esmeralda
221388	leotardos de malla de escamas esmeralda
221389	guanteletes de malla de escamas esmeralda
221390	coraza de malla de escamas esmeralda
221391	casco de malla de escamas esmeralda
221392	sobrehombros de malla de escamas esmeralda
221393	botas de malla de escamas esmeralda
221394	botas cargadas de esmeraldas
221395	coraza cargada de esmeraldas
221396	guanteletes cargados de esmeraldas
221397	casco cargado de esmeraldas
221398	leotardos cargados de esmeraldas
221399	sobrehombros cargados de esmeraldas
221400	sobrehombros de anillas esmeralda
221401	leotardos de anillas esmeralda
221402	casco de anillas esmeralda
221403	guanteletes de anillas esmeralda
221404	coraza de anillas esmeralda
221405	botas de anillas esmeralda
221406	jubon de cuero esmeralda
221407	guantes de cuero esmeralda
221408	yelmo de cuero esmeralda
221409	escarpes de cuero esmeralda
221410	pantalones de cuero esmeralda
221411	sobrehombros de cuero esmeralda
221412	guantes de guardian de los suenos esmeralda
221413	yelmo de guardian de los suenos esmeralda
221414	pantalones de guardian de los suenos esmeralda
221415	botas de guardian de los suenos esmeralda
221416	sobrehombros de guardian de los suenos esmeralda
221417	pechera de guardian de los suenos esmeralda
221418	rugido de agamaggan
221419	jubon de vigia esmeralda
221420	botas de vigia esmeralda
221421	guantes de vigia esmeralda
221422	yelmo de vigia esmeralda
221423	leotardos de vigia esmeralda
221424	sobrehombros de vigia esmeralda
221425	diadema encantada esmeralda
221426	botas encantadas esmeralda
221427	guantes encantados esmeralda
221428	runa de juego sucio
221429	pantalones encantados esmeralda
221430	togas encantadas esmeralda
221431	sobrehombros encantados esmeralda
221432	manto tejido esmeralda
221433	runa de enfoque
221434	togas tejidas esmeralda
221435	pantalones tejidos esmeralda
221436	guantes tejidos esmeralda
221437	diadema tejida esmeralda
221438	botas tejidas esmeralda
221439	armadura del letargo esmeralda
221440	rugido del sueno
221441	celador del sueno
221442	rugido del guardian
221443	rugido de la arboleda
221444	durian de jungla
221445	runa de fuego enfocado
221446	martillo de ritualista
221447	grimorio de ritualista de la luna de sangre
221448	talisman de la arboleda corrupta
221450	arco de luchador de fosa gurubashi
221451	ballesta de sed de sangre
221452	sortija arcana de concentracion sanguina
221453	sortija de sangre hirviente
221454	sortija de sangre glacial
221455	reverencia de luz de sangre
221456	sable sanguino eclipsado
221457	tratado sobre destruccion draconica
221458	sortija de victoria sombria
221459	sello de los sacrificados
221460	apunaladora gurubashi
221461	runa de carniceria
221462	espada de velocidad sangrienta
221463	muneco de vudu ancestral
221464	totem de precision ignea
221465	aplastatoria corrupta
221466	aro de sangre ardiente
221467	ojo de la luna de sangre
221468	muro de susurros
221469	lanza con puas de rebanacabezas
221470	esmeralda onirica
221471	cofre de los celadores esmeralda
221473	runa de velador
221474	esencia encadenada de eranikus
221475	esencia de eranikus
221480	notas de hechizo armadura de arrabio
221481	epifania nihilista
221482	runa de afliccion
221483	runa de quemar
221484	palo de maleficios de medico brujo
221487	notas de hechizo resguardo avanzado
221488	runa de epifania
221489	runa de venganza
221490	runa de mareas vivas
221491	bolsa diente oscuro
221497	llave vieja
221498	caja de comida robusta
221499	runa del guardia vil
221510	runa del caballero
221511	runa del protector
221512	runa de prontitud
221513	runa de potencia
221514	runa de poder de fuego
221515	runa de detonacion
221516	runa de energia primigenia
221517	runa de masacre
221518	susurro
221519	orbe mannoroc
221544	huevo de cuervo tormentoso
221545	notas de brujo descifradas
221547	notas de brujo en clave
221549	codice de vagayermos
221780	cetro de la princesa theradras
221781	yelmo de guardia vengador
221782	yelmo de exilio
221783	bufas de justiciero
221785	vestimentas cenarion
221971	cuerno de jurasuenos
221972	fuego de diablillo oniripira
221973	colmillo de cazasuenos
221974	collar totem siniestro
221975	baston de zarpalena roto
221976	baston de naturaleza enfermiza
221978	alma de expedicionario
221979	profecia del invierno glauco
221980	profecia del caos desatado
221981	profecia de la tribu perdida
222952	frasco de suenos inquietos
222962	sabiduria de hyjal
223073	cubrehombros de malla de teniente caballero
223074	quijotes de malla de caballero
223075	yelmo de malla de teniente caballero
223076	guanteletes de malla de alferez
223077	escarpes de malla de alferez
223078	armadura de malla de caballero
223147	notas de hechizo descarga de fuego fardo
223148	tesoro sobrenatural
223149	tesoro sobrenatural
223150	tesoro sobrenatural
223151	tesoro sobrenatural
223160	arbusto de negociacion
223161	cajon de suministros vacio
223162	escarcela de mensajero practica
223163	formula pergamino de reparacion espacial
223164	capucha de curiosidad
223167	gorro de iniciativa
223168	fragmento de nucleo del mundo
223169	gorro de tenacidad
223171	pergamino de geomancia
223172	cadena de tenacidad
223173	cordon de geomantico
223174	botas de geomantico
223175	capa de geomantico
223177	almete de geomantico
223178	brazales de geomantico
223180	guantes de geomantico
223181	bufas de geomantico
223182	calzas de geomantico
223183	sobrevesta de geomantico
223186	expedidor de suministros
223192	cordon del indomable
223193	corona del tejesuenos
223194	sortija de lo salvaje
223195	amplitud de la bestia
223196	grebas del destripadioses
223197	defensor de lo salvaje
223198	modas karkun
223214	zila gular
223215	orah raka
223216	rakkan archim
223217	rakkas lek
223218	tor kieldaz
223219	braciles de pano vil
223221	braciles de cuero vil
223222	braciles de malla vil
223237	hombreras de pano vil
223238	hombreras de cuero vil
223239	sobrehombros de malla vil
223240	capucha de pano vil
223241	sombrero de cuero vil
223242	almofar de malla vil
223248	piernas de pano vil
223249	piernas de cuero vil
223250	piernas de malla vil
223251	piernas de placas viles
223256	togas de pano vil
223261	peto de cuero vil
223262	peto de malla vil
223263	peto de placas viles
223283	mencion manchada de sangre
223288	runa del martillo
223323	camisa
223324	leotardos de zancalluvia
223325	coraza hakkari
223326	embozo hakkari
223327	marca de hakkar
223328	aro rafaga de gemas
223329	puntilla de fuerza de vida
223330	ojo pulsante
223331	ojo pulsante
223332	ojo vibrante
223333	ojo siniestro
223334	ojo resplandeciente
223335	ojo supurante
223336	ojo perforador
223337	ojo ardiente
223518	puntilla de calcinita
223519	ojo de theradras
223520	espada focal de inventor
223521	manto de escamapodrida
223522	yelmo de la montana
223523	piedra nube
223524	puno de piedra
223525	ornato de veritas
223526	sul thraze la azotadora
223527	colmillo de gahz rilla
223528	armadura de escamas de gahz rilla
223529	piel hudu maldita
223530	falda hudu maldita
223531	espaldares malos grandes
223532	amuleto sangrevida
223533	baston de caminadesiertos
223534	mandiletes jumanza
223535	vestimentas tribales de grimlok
223536	carga de grimlok
223537	brazales placacraneos
223538	baculo de astillas
223539	esfera embrujada
223540	arco del maestro de canes
223541	fragmento de gemas
223542	rifle megatiro
223543	botas de vina putrida
223544	bufas de posometal
223545	rodela hipertecnica de gizlock
223648	flecha onirica
223912	pocion de purificacion
223913	pocion de sanacion sublime
223914	pocion de sanacion superior
223962	tobilleras acecharenas
223963	abrazo del licantropo
223964	hoja de oscuridad eterna
223980	leotardos de escamas abrasadoras
223981	togas de zancudo flamigero
223982	rifle del maestro de canes
223983	hoja de mediador
223984	guantes de tela de seda
223985	sortija ciclopea
223986	manteo de podredumbre de tumba
223987	sobrehombros de pellejo escindido
224004	anillo de esmeralda
224005	anillo de esmeralda
224006	anillo de esmeralda
224122	comesuenos
224279	terrestris
224280	soberania defensor de los vuelos
224281	gla sir
224282	rae lar
224409	golpeador de serpiente
224806	ajustador del portal de la legion
224836	tesoro sobrenatural
224848	tesoro sobrenatural
224849	tesoro sobrenatural
224850	tesoro sobrenatural
224851	tesoro sobrenatural
224893	ajustador de portales sobrecargado
224912	ajustador de ajustador de portales
225675	nucleo obsidiano tiznado
225676	nucleo obsidiano fundido
225686	runa de exterminacion
225687	runa de armadura infernal
225688	runa de marca del caos
225689	notas de hechizo tromba arcana
225690	notas de hechizo orbe congelado
225691	notas de hechizo recalentamiento
225740	runa de compostura
225838	icono voltaico
225893	fin de epoca
225914	runa del espiritu vinculado
225929	fragmento de alma apestado
225938	notas de hechizo rotas
225939	notas de hechizo rotas
225940	notas de hechizo rotas
225941	notas de hechizo rotas
225942	carne de jabali contaminada
225943	pedazo de carne rancio
225954	notas de hechizo chamuscadas
225955	runa de ingenio
226122	cuerno de dalton
226201	espada del escudero cuthbert
226207	eco de anastari
226208	eco de barthilas
226209	eco de dathrohan
226210	eco de maleki
226211	eco de nerub enkan
226212	eco de ramstein
226213	eco de osahendido
226214	eco de willey
226252	runa de la guerrilla
226374	veneno oculto i
226394	manual de veneno atrofico
226395	manual de veneno entumecedor
226396	manual de veneno oculto
226397	manual de veneno sebaceo
226401	tratado sobre corazon del leon
226402	revelacion de ira del chaman
226403	vademecum de gancho
226404	real de minahonda deslustrado
226405	cajon de suministros de minahonda danado
226406	runa de especializacion en espadas
226407	runa de especializacion en hachas
226408	runa de especializacion en mazas
226409	runa de especializacion en dagas
226410	runa de especializacion en armas a distancia
226411	runa de especializacion en armas de puno
226412	runa de especializacion en armas de asta
226413	runa de especializacion en lo arcano
226414	runa de especializacion en fuego
226415	runa de especializacion en escarcha
226416	runa de especializacion en naturaleza
226417	runa de especializacion en las sombras
226418	runa de especializacion sagrada
226419	runa de especializacion en combate feral
226420	busto esculpido con delicadeza
226421	placeholder_ashbringer_questitem_01
226440	cinturon de destripador nocturno
226441	guantes de destripador nocturno
226442	pulseras de destripador nocturno
226443	botas de destripador nocturno
226444	hombreras de destripador nocturno
226445	pantalones de destripador nocturno
226446	casquete de destripador nocturno
226447	pechera de destripador nocturno
226472	frasco de sombras de stratholme
226473	loriga de destripador nocturno
226474	guardarrenes de destripador nocturno
226475	manoplas de destripador nocturno
226476	brazales de destripador nocturno
226477	tabi de destripador nocturno
226478	espaldares de destripador nocturno
226479	musleras de destripador nocturno
226480	capucha de destripador nocturno
226484	brazales de poderio
226485	cinturon de poderio
226486	guanteletes de poderio
226487	escarpes de poderio
226488	yelmo de poderio
226489	coraza de poderio
226490	quijotes de poderio
226491	hombreras de poderio
226492	espaldares de poderio
226493	leotardos de poderio
226494	camisote de poderio
226495	fauces de poderio
226496	botines de poderio
226497	manos de poderio
226498	fajin de poderio
226499	guardabrazos de poderio
226500	amuleto pirodraco astillado
226523	cuerno de dalton
226526	artilugio destrozado
226527	cubrehombros de acechagigantes
226528	guantes de acechagigantes
226529	cinturon de acechagigantes
226530	brazales de acechagigantes
226531	botas de acechagigantes
226532	leotardos de acechagigantes
226533	casco de acechagigantes
226534	coraza de acechagigantes
226535	malla de anillas de acechagigantes
226536	apariencia de acechagigantes
226537	leotardos de anillas de acechagigantes
226538	escarpes de acechagigantes
226540	manoplas de acechagigantes
226541	guardamunecas de acechagigantes
226542	faja de acechagigantes
226543	espaldares de acechagigantes
226545	cuerno de dalton
226546	sonar de desierto
226547	pantalones corazon vil
226548	togas corazon vil
226549	cuernos corazon vil
226550	hombreras corazon vil
226551	cinturon corazon vil
226552	guantes corazon vil
226553	brazales corazon vil
226554	zapatillas corazon vil
226555	cinturon de arcanista
226556	guantes arcanistas
226557	botas arcanistas
226558	ataduras arcanistas
226559	togas arcanistas
226560	manto arcanista
226561	leotardos arcanistas
226562	corona arcanista
226563	prendas arcanistas
226564	ornato arcanista
226565	pantalones arcanistas
226566	sobrehombros arcanistas
226567	cubremunecas arcanistas
226568	sandalias arcanistas
226569	manoplas arcanistas
226570	cordon arcanista
226571	botas de profecia
226572	guantes de profecia
226573	diadema de profecia
226574	pantalones de profecia
226575	togas de profecia
226576	manto de profecia
226577	faja de profecia
226578	avambrazos de profecia
226579	cubremunecas de profecia
226580	cinturon de profecia
226581	hombreras de profecia
226582	prendas de profecia
226583	leotardos de profecia
226584	corona de profecia
226585	manos de profecia
226586	sandalias de profecia
226587	runa de acorazamiento
226588	bufas de justiciero
226589	brazales de justiciero
226590	yelmo de justiciero
226591	guanteletes de justiciero
226592	cinturon de justiciero
226593	botas de justiciero
226594	quijotes de justiciero
226595	coselete de justiciero
226596	brazales de guerra de justiciero
226597	faja de justiciero
226598	leotardos de justiciero
226599	corona de justiciero
226600	mandiletes de justiciero
226601	botas de batalla de justiciero
226602	coraza de justiciero
226603	avambrazos de justiciero
226604	cinturon de batalla de justiciero
226605	espaldares de justiciero
226606	musleras de justiciero
226607	protegecabezas de justiciero
226608	manoplas de justiciero
226609	escarpes de justiciero
226610	peto de justiciero
226611	cubrehombros furia terrenal
226612	casco furia terrenal
226613	botas furia terrenal
226614	musleras furia terrenal
226615	guanteletes furia terrenal
226616	cinturon furia terrenal
226617	vestimentas furia terrenal
226618	brazales furia terrenal
226619	cota guarnecida furia terrenal
226620	botos furia terrenal
226621	manos furia terrenal
226622	visor furia terrenal
226623	leotardos furia terrenal
226624	manto furia terrenal
226625	cordon furia terrenal
226626	braciles furia terrenal
226627	malla de escamas furia terrenal
226628	escarpes furia terrenal
226629	manoplas furia terrenal
226630	gran yelmo furia terrenal
226631	leotardos escamados furia terrenal
226632	espaldares furia terrenal
226633	guardarrenes furia terrenal
226634	guardamunecas furia terrenal
226635	malla de anillas furia terrenal
226636	botas de batalla furia terrenal
226637	mandiletes furia terrenal
226638	celada furia terrenal
226639	leotardos de malla furia terrenal
226640	bufas furia terrenal
226641	faja furia terrenal
226642	ataduras furia terrenal
226644	bufas cenarion
226645	botas cenarion
226646	leotardos cenarion
226647	yelmo cenarion
226648	guantes cenarion
226649	brazales cenarion
226650	cinturon cenarion
226651	pantalones cenarion
226652	sandalias cenarion
226653	manto cenarion
226654	guanteletes cenarion
226655	munequeras cenarion
226656	abrazo cenarion
226657	cordon cenarion
226658	astas cenarion
226659	cuernos cenarion
226660	faja cenarion
226661	guerrera cenarion
226662	braciles cenarion
226663	botines cenarion
226664	punos cenarion
226665	sobrehombros cenarion
226666	calzas cenarion
226667	guardarrenes cenarion
226668	guardamunecas cenarion
226669	mandiletes cenarion
226670	corona cenarion
226671	musleras cenarion
226673	botos cenarion
226674	espaldares cenarion
226675	armadura cenarion
226678	premonicion y vision de combate
226679	perspectivas de errante atemporal
226680	runa del primer guerrero
226694	runa de especializacion en defensa
226698	amoplador vertical exterior compuesto
226699	rendijas de niquel con inserciones latonadas
226700	guerrera arte sombrio
226701	cinturon arte sombrio
226702	guantes arte sombrio
226703	botas arte sombrio
226704	brazales arte sombrio
226705	pantalones arte sombrio
226706	bufas arte sombrio
226707	almete arte sombrio
226708	capucha corazon salvaje
226709	falda corazon salvaje
226710	bufas corazon salvaje
226711	guantes corazon salvaje
226712	cinturon corazon salvaje
226713	botas corazon salvaje
226714	brazales corazon salvaje
226715	jubon corazon salvaje
226716	manto de acechabestias
226717	ataduras de acechabestias
226718	cinturon de acechabestias
226719	pantalones de acechabestias
226720	almete de acechabestias
226721	guantes de acechabestias
226722	botas de acechabestias
226723	guerrera de acechabestias
226724	cinturon de magister
226725	ataduras de magister
226726	manto de magister
226727	leotardos de magister
226728	corona de magister
226729	togas de magister
226730	botas de magister
226731	guantes de magister
226732	cinturon forjaluz
226733	yelmo forjaluz
226734	coraza forjaluz
226735	bufas forjaluz
226736	quijotes forjaluz
226737	guanteletes forjaluz
226738	botas forjaluz
226739	brazales forjaluz
226740	guantes de devoto
226741	manto de devoto
226742	brazales de devoto
226743	sandalias de devoto
226744	cinturon de devoto
226745	toga de devoto
226746	corona de devoto
226747	saya de devoto
226748	guanteletes de elementos
226749	jubon de elementos
226750	falda de elementos
226751	ataduras de elementos
226752	botas de elementos
226753	espaldares de elementos
226754	cordon de elementos
226755	almofar de elementos
226756	manto caligine
226757	toga caligine
226758	brazaletes caligine
226759	brazales caligine
226760	leotardos caligine
226761	cinturon caligine
226762	mascara caligine
226763	sandalias caligine
226764	botas de valor
226765	cinturon de valor
226766	brazales de valor
226767	quijotes de valor
226768	bufas de valor
226769	yelmo de valor
226770	coraza de valor
226771	guanteletes de valor
226772	fajin cuoroferal
226773	capucha cuoroferal
226774	galochas cuoroferal
226775	brazaletes cuoroferal
226776	jubon cuoroferal
226777	manos cuoroferal
226778	bufas cuoroferal
226779	falda cuoroferal
226780	cordon cuoroferal
226781	sandalias cuoroferal
226782	ataduras cuoroferal
226783	abrazo cuoroferal
226784	guanteletes cuoroferal
226785	manto cuoroferal
226786	ornato cuoroferal
226787	pantalones cuoroferal
226788	braciles cuoroferal
226789	faja cuoroferal
226790	cubrehombros cuoroferal
226791	calzas cuoroferal
226792	almete cuoroferal
226793	punos cuoroferal
226794	botos cuoroferal
226795	guerrera cuoroferal
226796	guardamunecas cuoroferal
226797	guardarrenes cuoroferal
226798	espaldares cuoroferal
226799	musleras cuoroferal
226801	visera cuoroferal
226802	empunaduras cuoroferal
226803	botines cuoroferal
226804	armadura cuoroferal
226815	munequeras cuoroferal
226816	cintura cuoroferal
226817	sobrehombros cuoroferal
226818	piernas cuoroferal
226819	yelmo cuoroferal
226820	guantes cuoroferal
226821	botas cuoroferal
226822	pecho cuoroferal
226825	guerrera mantoscuro
226826	bufas mantoscuro
226827	pantalones mantoscuro
226828	empunaduras mantoscuro
226829	almete mantoscuro
226830	brazales mantoscuro
226831	escarpines mantoscuro
226832	cinturon mantoscuro
226835	guardamunecas mantoscuro
226836	guardarrenes mantoscuro
226837	espaldares mantoscuro
226838	musleras mantoscuro
226840	manoplas mantoscuro
226841	visera mantoscuro
226842	botines mantoscuro
226843	armadura mantoscuro
226845	munequeras mantoscuro
226846	cintura mantoscuro
226847	sobrehombros mantoscuro
226848	piernas mantoscuro
226849	yelmo mantoscuro
226850	guantes mantoscuro
226851	botas mantoscuro
226852	pecho mantoscuro
226856	acelerante de flotabilidad guiada
226857	botas de batalla de heroismo
226858	bufas de heroismo
226859	quijotes de heroismo
226860	corona de heroismo
226861	guanteletes de heroismo
226862	coraza de heroismo
226863	brazales de heroismo
226864	cinturon de heroismo
226865	guardamunecas de heroismo
226866	guardarrenes de heroismo
226867	espaldares de heroismo
226868	musleras de heroismo
226869	visera de heroismo
226870	manoplas de heroismo
226871	escarpes de heroismo
226872	coselete de heroismo
226873	munequeras de heroismo
226874	cintura de heroismo
226875	sobrehombros de heroismo
226876	piernas de heroismo
226877	yelmo de heroismo
226878	guantes de heroismo
226879	botas de heroismo
226880	pecho de heroismo
226881	botines de maestro de bestias
226882	pantalones de maestro de bestias
226883	guanteletes de maestro de bestias
226884	manto de maestro de bestias
226885	ataduras de maestro de bestias
226886	guerrera de maestro de bestias
226887	almete de maestro de bestias
226888	cinturon de maestro de bestias
226889	brazales de maestro de bestias
226890	ajustador de maestro de bestias
226891	espaldares de maestro de bestias
226892	leotardos de maestro de bestias
226893	almofar de maestro de bestias
226894	punos de maestro de bestias
226895	grebas de maestro de bestias
226896	cadena de maestro de bestias
226897	munequeras de maestro de bestias
226898	cintura de maestro de bestias
226899	sobrehombros de maestro de bestias
226900	piernas de maestro de bestias
226901	yelmo de maestro de bestias
226902	guantes de maestro de bestias
226903	botas de maestro de bestias
226904	pecho de maestro de bestias
226905	cinturon brumamorta
226906	toga brumamorta
226907	brazales brumamorta
226908	sandalias brumamorta
226909	mascara brumamorta
226910	leotardos brumamorta
226911	sobrevestes brumamorta
226912	manto brumamorta
226913	ataduras brumamorta
226914	cordon brumamorta
226915	cubrehombros brumamorta
226916	pantalones brumamorta
226917	caperuza brumamorta
226918	agarres brumamorta
226919	botines brumamorta
226920	abrazo de brumamorta
226921	munequeras brumamorta
226922	cintura brumamorta
226923	sobrehombros brumamorta
226924	piernas brumamorta
226925	yelmo brumamorta
226926	guantes brumamorta
226927	botas brumamorta
226928	pecho brumamorta
226929	ataduras de hechicero
226930	guanteletes de hechicero
226931	sandalias de hechicero
226932	togas de hechicero
226933	leotardos de hechicero
226934	cinturon de hechicero
226935	corona de hechicero
226936	manto de hechicero
226937	munequeras del hechicero
226938	cintura de hechicero
226939	sobrehombros de hechicero
226940	piernas de hechicero
226941	yelmo de hechicero
226942	guantes de hechicero
226943	botas de hechicero
226944	pecho de hechicero
226945	toga del virtuoso
226946	falda del virtuoso
226947	corona del virtuoso
226948	cinturon del virtuoso
226949	brazales del virtuoso
226950	mitones del virtuoso
226951	manto del virtuoso
226952	sandalias del virtuoso
226953	sobrevestes del virtuoso
226954	cordon del virtuoso
226955	cubrehombros del virtuoso
226956	leotardos del virtuoso
226957	capucha del virtuoso
226958	manos del virtuoso
226959	zapatillas del virtuoso
226960	vestido del virtuoso
226961	munequeras del virtuoso
226962	cintura del virtuoso
226963	sobrehombros del virtuoso
226964	piernas del virtuoso
226965	yelmo del virtuoso
226966	guantes del virtuoso
226967	botas del virtuoso
226968	pecho del virtuoso
226969	bufas forjaalma
226970	brazales forjaalma
226971	cinturon forjaalma
226972	quijotes forjaalma
226973	coraza forjaalma
226974	botas de guerra forjaalma
226975	guanteletes forjaalma
226976	gran yelmo forjaalma
226977	ataduras forjaalma
226978	cordon forjaalma
226979	cubrehombros forjaalma
226980	leotardos forjaalma
226981	corona forjaalma
226982	punos forjaalma
226983	botines forjaalma
226984	abrazo forjaalma
226985	guardamunecas forjaalma
226986	guardarrenes forjaalma
226987	espaldares forjaalma
226988	musleras forjaalma
226989	visera forjaalma
226990	manoplas forjaalma
226991	escarpes forjaalma
226992	coseletes forjaalma
226993	munequeras forjaalma
226994	cintura forjaalma
226995	sobrehombros forjaalma
226996	piernas forjaalma
226997	yelmo forjaalma
226998	guantes forjaalma
226999	botas forjaalma
227000	pecho forjaalma
227001	ataduras de los cinco truenos
227002	almofar de los cinco truenos
227003	espaldares de los cinco truenos
227004	jubon de los cinco truenos
227005	falda de los cinco truenos
227006	guanteletes de los cinco truenos
227007	zapatillas de los cinco truenos
227008	cordon de los cinco truenos
227009	brazales de los cinco truenos
227010	fajin de los cinco truenos
227011	manto de los cinco truenos
227012	leotardos de los cinco truenos
227013	corona de los cinco truenos
227014	agarre de los cinco truenos
227015	grebas de los cinco truenos
227016	guerrera de los cinco truenos
227017	braciles de los cinco truenos
227018	faja de los cinco truenos
227019	bufas de los cinco truenos
227020	quijotes de los cinco truenos
227021	cara de los cinco truenos
227022	punos de los cinco truenos
227023	botines de los cinco truenos
227024	cadena de los cinco truenos
227025	guardamunecas de los cinco truenos
227026	guardarrenes de los cinco truenos
227027	guardahombros de los cinco truenos
227028	musleras de los cinco truenos
227029	celada de los cinco truenos
227030	guardamanos de los cinco truenos
227031	escarpes de los cinco truenos
227032	coselete de los cinco truenos
227033	munequeras de los cinco truenos
227034	cintura de los cinco truenos
227035	sobrehombros de los cinco truenos
227036	piernas de los cinco truenos
227037	yelmo de los cinco truenos
227038	guantes de los cinco truenos
227039	botas de los cinco truenos
227040	pecho de los cinco truenos
227041	escalpelo sombrio de plaga
227042	sobrehombros de placas de campeon
227043	yelmo de placas de campeon
227044	yelmo de placas de teniente coronel
227045	sobrehombros de placas de teniente coronel
227046	camisote de placas de capitan caballero
227047	leotardos de placas de capitan caballero
227048	leotardos de placas de legionario
227049	camisote de placas de legionario
227050	guanteletes de placas de guardia de sangre
227051	grebas de placas de guardia de sangre
227052	grebas de placas de teniente caballero
227053	guanteletes de placas de teniente caballero
227054	sobrehombros de cuero de teniente coronel
227055	yelmo de cuero de teniente coronel
227056	sobrehombros de cuero de campeon
227057	yelmo de cuero de campeon
227058	pechera de cuero de capitan caballero
227059	musleras de cuero de legionario
227060	pechera de cuero de legionario
227061	musleras de cuero de capitan caballero
227062	botos de cuero de guardia de sangre
227063	mandiletes de cuero de guardia de sangre
227064	botos de cuero de teniente caballero
227065	mandiletes de cuero de teniente caballero
227066	yelmo de anillas de teniente coronel
227067	yelmo de anillas de campeon
227068	sobrehombros de anillas de teniente coronel
227069	sobrehombros de anillas de campeon
227070	camisote de anillas de capitan caballero
227071	camisote de anillas de legionario
227072	musleras de anillas de capitan caballero
227073	musleras de anillas de legionario
227074	grebas de anillas de guardia de sangre
227075	abrazaderas de anillas de guardia de sangre
227076	grebas de anillas de teniente caballero
227077	abrazaderas de anillas de teniente caballero
227078	espaldares de anillas de campeon
227079	quijotes de anillas de legionario
227080	gran yelmo de anillas de campeon
227081	mandiletes de anillas de guardia de sangre
227082	escarpes de anillas de guardia de sangre
227083	armadura de anillas de legionario
227084	espaldares de anillas de teniente coronel
227085	quijotes de anillas de capitan caballero
227086	gran yelmo de anillas de teniente coronel
227087	mandiletes de anillas de teniente caballero
227088	escarpes de anillas de teniente caballero
227089	armadura de anillas de capitan caballero
227090	capucha de tejido de tinieblas de campeon
227091	bufas de tejido de tinieblas de teniente coronel
227092	bufas de tejido de tinieblas de campeon
227093	capucha de tejido de tinieblas de teniente coronel
227094	guerrera de tejido de tinieblas de legionario
227095	musleras de tejido de tinieblas de capitan caballero
227096	guerrera de tejido de tinieblas de capitan caballero
227097	musleras de tejido de tinieblas de legionario
227098	botos de tejido de tinieblas de guardia de sangre
227099	manijas de tejido de tinieblas de guardia de sangre
227100	manijas de tejido de tinieblas de teniente caballero
227101	botos de tejido de tinieblas de teniente caballero
227102	manto de seda de teniente coronel
227103	capucha de seda de teniente coronel
227104	manto de seda de campeon
227105	capucha de seda de campeon
227106	guerrera de seda de legionario
227107	musleras de seda de legionario
227108	guerrera de seda de capitan caballero
227109	musleras de seda de capitan caballero
227110	botos de seda de guardia de sangre
227111	manijas de seda de guardia de sangre
227112	botos de seda de teniente caballero
227113	manijas de seda de teniente caballero
227114	guanteletes de seda de teniente caballero
227115	guanteletes de seda de guardia de sangre
227116	guantes de seda de teniente caballero
227117	guantes de seda de guardia de sangre
227118	caperuza de saten de campeon
227119	manto de saten de teniente coronel
227120	manto de saten de campeon
227121	caperuza de saten de teniente coronel
227122	guerrera de saten de capitan caballero
227123	musleras de saten de legionario
227124	guerrera de saten de legionario
227125	musleras de saten de capitan caballero
227126	manijas de saten de guardia de sangre
227127	botos de saten de guardia de sangre
227128	manijas de saten de teniente caballero
227129	botos de saten de teniente caballero
227130	cubrehombros de saten de campeon
227131	leotardos de saten de legionario
227132	corona de saten de campeon
227133	mandiletes de saten de guardia de sangre
227134	botines de saten de guardia de sangre
227135	toga de saten de legionario
227136	cubrehombros de saten de teniente coronel
227137	leotardos de saten de capitan caballero
227138	corona de saten de teniente coronel
227139	mandiletes de saten de teniente caballero
227140	botines de saten de teniente caballero
227141	toga de saten de capitan caballero
227142	coraza de laminas de capitan caballero
227143	leotardos de laminas de capitan caballero
227144	protegecabezas de laminas de teniente coronel
227145	sobrehombros de laminas de teniente coronel
227146	escarpes de laminas de teniente caballero
227147	guanteletes de laminas de teniente caballero
227148	espaldares de laminas de teniente coronel
227149	casco de laminas de teniente coronel
227150	musleras de laminas de capitan caballero
227151	peto de laminas de capitan caballero
227152	guantes de laminas de teniente caballero
227153	grebas de laminas de teniente caballero
227154	espaldares de malla de campeon
227155	protegecabezas de malla de campeon
227156	musleras de malla de legionario
227157	camisote de malla de legionario
227158	grebas de malla de guardia de sangre
227159	abrazaderas de malla de guardia de sangre
227160	bufas de malla de campeon
227161	leotardos de malla de legionario
227162	yelmo de malla de campeon
227163	guanteletes de malla de guardia de sangre
227164	escarpes de malla de guardia de sangre
227165	coraza de malla de legionario
227166	cubrehombros de malla de campeon
227167	pantalones de malla de legionario
227168	escutelaria de malla de campeon
227169	guantes de malla de guardia de sangre
227170	botas de malla de guardia de sangre
227171	coselete de malla de legionario
227172	sobrehombros de pellejo de dragon de teniente coronel
227173	protegecabezas de pellejo de dragon de teniente coronel
227174	protegecabezas de pellejo de dragon de campeon
227175	sobrehombros de pellejo de dragon de campeon
227176	pechera de pellejo de dragon de capitan caballero
227177	leotardos de pellejo de dragon de legionario
227178	leotardos de pellejo de dragon de capitan caballero
227179	pechera de pellejo de dragon de legionario
227180	mandiletes de pellejo de dragon de guardia de sangre
227181	botines de pellejo de dragon de guardia de sangre
227182	botines de pellejo de dragon de teniente caballero
227183	mandiletes de pellejo de dragon de teniente caballero
227184	bufas de pellejo de dragon de campeon
227185	pantalones de pellejo de dragon de legionario
227186	yelmo de pellejo de dragon de campeon
227187	guantes de pellejo de dragon de guardia de sangre
227188	botas de pellejo de dragon de guardia de sangre
227189	armadura de pellejo de dragon de legionario
227190	bufas de pellejo de dragon de teniente coronel
227191	pantalones de pellejo de dragon de capitan caballero
227192	yelmo de pellejo de dragon de teniente coronel
227193	guantes de pellejo de dragon de teniente caballero
227194	botas de pellejo de dragon de teniente caballero
227195	armadura de pellejo de dragon de capitan caballero
227196	guerrera de pellejo de dragon de capitan caballero
227197	grebas de pellejo de dragon de teniente caballero
227198	guanteletes de pellejo de dragon de teniente caballero
227199	ornato de pellejo de dragon de teniente coronel
227200	musleras de pellejo de dragon de capitan caballero
227201	espaldares de pellejo de dragon de teniente coronel
227202	guerrera de pellejo de dragon de legionario
227203	grebas de pellejo de dragon de guardia de sangre
227204	guanteletes de pellejo de dragon de guardia de sangre
227205	ornato de pellejo de dragon de campeon
227206	musleras de pellejo de dragon de legionario
227207	espaldares de pellejo de dragon de campeon
227279	aro de magister
227280	artesania de las sombras
227282	anillo de niebla temida
227284	banda de la bestia
227285	flujo de dinamica estructural
227286	ron rumsey tibio con crema
227337	conjunto de cinturon y guantes felinos
227338	conjunto de cinturon y guantes astrales
227339	conjunto de guantes y cinturon de guardian
227340	conjunto de guantes y cinturon de ensalmador
227341	conjunto de guantes y cinturon de perseguidor
227342	conjunto de guantes y cinturon de merodeador
227343	conjunto de guantes y cinturon de clemente
227344	conjunto de cinturon y guantes radiantes
227345	conjunto de cinturon y guantes de voluntad divina
227346	conjunto de guantes y cinturon del alba
227347	conjunto de cinturon y guantes crepusculares
227348	conjunto de guantes y cinturon de entusiasmo
227349	conjunto de guantes y cinturon de batalla
227350	conjunto de guantes y cinturon de alivio
227351	conjunto de guantes y cinturon de erupcion
227352	conjunto de guantes y cinturon de impacto
227353	conjunto de guantes y cinturon de resolucion
227354	conjunto de guantes y cinturon corruptos
227355	conjunto de guantes y cinturon malignos
227356	conjunto de guantes y cinturon inamovibles
227357	conjunto de guantes y cinturon imparables
227359	conjunto de botas piernas y sobrehombros felinos
227360	conjunto de botas piernas y hombros astrales
227361	conjunto de botas piernas y sobrehombros de guardian
227365	conjunto de botas piernas y sobrehombros de ensalmador
227366	conjunto de botas piernas y sobrehombros de perseguidor
227367	conjunto de botas piernas y sobrehombros de merodeador
227368	conjunto de botas piernas y hombros clementes
227369	conjunto de botas piernas y hombros radiantes
227370	conjunto de botas piernas y hombros de voluntad divina
227371	conjunto de botas piernas y hombros del alba
227372	conjunto de botas piernas y hombros crepusculares
227373	conjunto de botas piernas y sobrehombros de entusiasmo
227374	conjunto de botas piernas y sobrehombros de batalla
227375	conjunto de botas piernas y sobrehombros de alivio
227376	conjunto de botas piernas y sobrehombros de erupcion
227377	conjunto de botas piernas y sobrehombros de impacto
227378	conjunto de botas piernas y sobrehombros de resolucion
227379	conjunto de botas piernas y sobrehombros corruptos
227380	conjunto de botas piernas y hombros malignos
227381	conjunto de botas piernas y sobrehombros inamovibles
227382	conjunto de botas piernas y sobrehombros imparables
227383	conjunto de yelmo y pechera felinos
227384	conjunto de yelmo y pechera astrales
227385	conjunto de yelmo y pechera de guardian
227387	conjunto de yelmo y pechera de ensalmador
227388	conjunto de yelmo y pechera de perseguidor
227389	conjunto de yelmo y pechera de merodeador
227390	conjunto de yelmo y pechera clementes
227391	conjunto de yelmo y pechera radiantes
227392	conjunto de yelmo y pechera de voluntad divina
227393	conjunto de yelmo y pechera del alba
227394	conjunto de yelmo y pechera crepusculares
227395	conjunto de yelmo y pechera de entusiasmo
227396	conjunto de yelmo y pechera de batalla
227397	conjunto de yelmo y pechera de alivio
227398	conjunto de yelmo y pechera de erupcion
227399	conjunto de yelmo y pechera de impacto
227400	conjunto de yelmo y pechera de resolucion
227401	conjunto de yelmo y pechera corruptos
227402	conjunto de yelmo y pechera malignos
227403	conjunto de yelmo y pechera inamovibles
227404	conjunto de yelmo y pechera imparables
227444	idolo de la cazadora
227451	sigilo de envio
227454	aro de la marea
227455	brisa del oceano
227456	runa de la tempestad carmesi
227530	cinturon incandescente
227531	ataduras incandescentes
227532	capucha incandescente
227533	guantes incandescentes
227534	leotardos incandescentes
227535	toga incandescente
227536	botas incandescentes
227537	hombreras incandescentes
227549	trozo de papiro
227552	papiro desgarrado
227658	nota de sombra jurada
227683	sulfuras mano de ragnaros
227684	martillo de sulfuron
227685	escalpelo sombrio modificado
227686	martillo de guerra ornamentado
227687	diente de oro favorito de lorthas
227688	aullavisceras
227689	armadura de placas parcialmente digerida
227690	piedra runica necrotica
227691	hoja de hanna
227724	mencion manchada de sangre
227727	diseno martillo de sulfuron
227728	ojo de sulfuras
227730	contrato de la hermandad del torio
227743	nucleo de poder obsidiano
227745	reliquia familiar
227746	runa del arbol del mundo
227747	registros familiares
227748	diario de un superviviente
227749	runa de la estrella fugaz
227750	ataduras escamadas fundidas
227751	cinturon escamado fundido
227752	sobrehombros escamados fundidos
227754	leotardos escamados fundidos
227755	yelmo escamado fundido
227756	guantes escamados fundidos
227757	botas escamadas fundidas
227758	pechera escamada fundida
227759	guantes de nucleo agostado
227760	ataduras de nucleo agostado
227761	cinturon de nucleo agostado
227762	sobrehombros de nucleo agostado
227763	leotardos de nucleo agostado
227764	yelmo de nucleo agostado
227765	botas de nucleo agostado
227766	pechera de nucleo agostado
227767	cumulo de fuegopiedra
227768	jugo de suenos
227796	pergamino darnassiano misterioso
227797	pergamino darnassiano descifrado
227801	ascua de las tierras de fuego
227802	monstruo antorcha
227803	arnes de oso de guerra temible
227804	prendas de lana de oso de guerra temible
227805	ferocidad de los fauces de madera
227807	cinturon fauces de madera denso
227808	manto de los fauces de madera basto
227809	aporreadores fauces de madera con tachuelas
227810	botas fauces de madera densas
227811	defensor de los fauces de madera
227812	faltriquera de medicinas furbolg
227813	agua bendita potable de stratholme
227814	faja del alba radiante
227815	botines del alba finos
227816	botas de elite argenta
227817	guantes del alba radiantes
227818	manto del alba resplandeciente
227819	manto del alba flamigero bendecido
227820	brazales hierro negro templados
227821	yelmo de arrabio besollama
227822	botas de can del nucleo gruesas
227823	guantes bengala del nucleo finos
227824	yelmo hierro negro templado
227825	destructora hierro negro fundida
227826	atracadora de llamas hierro negro
227827	faja de anillas fundidas
227828	cinturon de lava
227829	botas de dragontina negra endurecida
227830	manto bengala del nucleo fino
227831	toga bengala del nucleo fina
227832	amnistia negra templada
227833	guja de furia obsidiana
227834	sobrehombros de anillas fundidas
227835	guanteletes hierro negro templados
227836	leotardos hierro negro templados
227837	cinturon de can del nucleo grueso
227838	guanteletes cromaticos brillantes
227839	leotardos bengala del nucleo finos
227840	guardanegra implacable
227841	botas hierro negro templadas
227842	puno de ebano
227843	ocaso descuartizador
227844	bolsa de pano runico reforzada con cuero
227845	segadora de arcanita refinada
227847	leotardos de nucleo demoniaco
227848	guanteletes de nucleo demoniaco
227849	rifle de tirador certero de nucleo igneo
227850	hoja sabia del archimago
227851	coraza de dragontina negra endurecida
227852	leotardos de dragontina negra endurecida
227853	sobrehombros de dragontina negra endurecida
227854	capa ondeante de maestro de oficios
227857	profanacion
227858	martillo de los dioses salvajes
227859	sobrehombros albar resplandecientes
227860	jubon de tela lunar incandescente
227861	toga de tela lunar incandescente
227862	botas de tela lunar incandescente
227863	diadema de tela lunar incandescente
227864	leotardos de tela lunar incandescentes
227865	guanteletes de placas igneas de la tecnica oculta
227866	sobrehombros volcanicos magistrales
227867	leotardos volcanicos magistrales
227868	coraza volcanica magistral
227869	capa cromatica luminosa
227870	guanteletes de tempestad
227871	placa hierro negro templada
227872	cresta de guerra del gran jefe
227873	sobrehombros de dragontina azul filosa
227874	leotardos de dragontina azul filosa
227875	coraza de dragontina azul filosa
227876	malla invencible
227877	leotardos de dragontina verde viva
227878	guanteletes de dragontina verde viva
227879	coraza de dragontina verde viva
227880	martillo de batalla con encantamiento delicado
227881	tranquilidad
227882	faja de perspicacia arcana
227883	avambrazos de vuelo presto
227884	buscacorazones mortal
227885	guanteletes de mayor aferramiento
227886	martillo de tormenta magistral de jinete celestial
227887	guardia de escarcha endurecido
227888	sobrehombros de elite argenta
227895	patron manto del alba dorado
227896	patron botas argenta
227897	patron sobrehombros argenta
227898	patron coraza de dragontina azul filosa
227899	patron sobrehombros de dragontina azul filosa
227900	patron leotardos de dragontina verde viva
227901	diseno placa hierro negro templada
227902	patron coraza de dragontina negra endurecida
227903	patron leotardos de dragontina negra endurecida
227904	patron sobrehombros de dragontina negra endurecida
227905	diseno martillo de tormenta magistral de jinete celestial
227906	patron coraza volcanica magistral
227907	patron sobrehombros volcanicos magistrales
227908	patron leotardos volcanicos magistrales
227909	diseno guanteletes de placas igneas de la tecnica oculta
227910	patron capa cromatica luminosa
227911	cabeza de rend puno negro
227912	divinidad aplicada
227914	glandula pineal de lechubestia
227915	dominio del duque
227921	runa de cuchillos
227922	runa del espadachin
227923	botines de agua
227924	frasco inusual
227925	faro de hydraxis
227926	coronacion de hydraxis
227927	juramento del mar
227928	llave de caja de herramientas
227930	llave de caja fuerte
227931	fardo oculto
227932	palanqueta oxidada
227934	colera de llamas
227935	martillo de senor feudal caido
227936	anillo de diplomatico
227937	caja enigmatica
227938	fragmento de luz
227939	fragmento de luz
227940	espada de lord general
227941	guadana de anima
227947	espaldares a medida golem
227948	hacha de batalla de forjainquina
227952	cota de malla de gladiador indomito
227955	yelmo de gladiador indomito
227956	coraza de mortifero
227957	grebas de gladiador indomito
227958	embozo fantasmal
227959	quijotes del guardian eterno
227960	gigante impasible
227961	mandiletes de gladiador indomito
227962	erupcion de espinas
227963	hoja con grabados de sangre
227964	falda luminaria
227965	botas omnitiro
227967	segundo aliento
227970	manteo de la salamandra de fuego
227971	punos de arrabio
227972	rafaga de conocimiento
227973	circulo de la llama
227974	martillo de piedra de lava
227978	piedra magmus
227980	togas de la corona real
227981	vengador forjaterrible
227982	baculo de sabiduria orientador
227983	sello hierro negro
227984	cetro real de thaurissan
227985	el nuevo manteo del emperador
227986	guardamunecas de renombre
227987	fajin del gran cazador
227988	joya imperial
227990	mano de la injusticia
227991	ferromazo
227992	escarpes de caballero de la muerte
227993	empunadura de ebano de marduk
227994	baston de calamiedo
227996	arco de hueso antiguo
227997	espada de la familia barovia
227998	botas mallasangre
227999	escarpes de hueso de muerto
228000	peto de hueso de muerto
228001	sobrehombros con forma de piedra
228002	faja de hueso de muerto
228003	musleras mallasangre
228004	grebas atracavientos
228005	agarre de andros
228006	guanteletes de hueso de muerto
228007	rebanadoras de gargolas
228008	musleras de hueso de muerto
228009	botas necropilas
228010	manto necropilo
228011	punos necropilos
228012	camisote mallasangre
228013	toga necropila
228014	cinturon mallasangre
228015	garfa de miedo
228016	anillo opalescente oscuro
228017	pantalones humo de calavera
228018	leotardos necropilos
228019	corazon del maligno
228020	guanteletes mallasangre
228021	espada de bruja
228022	carga de rector
228023	abrazo de alanna
228024	colmillo silencioso
228025	coraza de lapida
228026	espada de bosque negro
228027	rebanadora de hoja de hielo
228028	hoja de nigromancia
228029	hacha de guerra de lapida
228030	hacha maliciosa
228031	guantes sombra oscura
228032	yelmo de hueso
228033	martillo de poderio divino
228034	manijas escalofrio
228036	agarre de la muerte
228037	rodela armadosea
228038	pantalones de tejido de hierro
228039	escrito vinculado
228040	leotardos de fantasma
228041	leotardos de placas de anima
228042	cinta de detencion
228044	leotardos de la voragine
228045	sortija nigromantica
228046	sortija de dominacion de don mauricio
228047	sortija de amalgama
228050	arco de satiro
228051	vara de mediacion quel dorei
228052	cortaolas
228053	yelmo ferviente
228054	dije de tempestad
228055	peto energizado
228056	machete endemoniado
228057	anillo de potencia demoniaca
228058	bufas de hierro grandes
228059	sobrehombros de vigia de cubil
228060	capa de heliotropo
228061	guantes chispa brillante
228062	caperuza de perspicacia
228063	brazal alabeo
228064	escudo de observador
228065	bufas de ciclon
228066	guantes de tejido de hierro
228067	colgante de mago anciano
228068	cinturon de asaltante
228069	quijotes reforzados tetricos
228070	camisote forjado de ogro
228074	manos de la tentacion
228075	lanza del destino
228076	anillo de fuego ardiente
228077	rama onirica
228078	caliz maldito
228079	manton de hojas
228080	aro de resina
228081	semilla venenosa germinada
228082	hacha grito de guerra
228083	corazon de arbol crepuscular
228084	extintor miniaturizado
228085	sortija de la legion con cambio de fase
228086	hoja trituradora modificada
228087	moebius de plata supercargada
228088	placa identificatoria de operador de trituradora
228089	acechalunas tallado en madera
228090	daga ritual de cenarion
228091	botas espinosas
228092	manto druidico
228093	corazon oscuro de la penumbra
228094	hoja del senor del terror
228100	manton del senor del fuego
228101	pellejo del behemoth
228102	manton de mayordomo
228103	grebas de nathrezim
228104	togas de elune
228105	nucleo de llama eterna
228106	escudo de vida y muerte
228107	arco largo de cazadora caida
228108	sombra de aullavisceras
228109	musleras de sacrificio
228111	mascara del destripadioses
228112	toga de pesadilla
228113	abrazo frio
228114	diseno segadora de arcanita refinada
228117	diseno campeona de arcanita refinada
228118	diseno guanteletes de mayor aferramiento
228119	patron guanteletes de nucleo demoniaco
228120	patron leotardos de nucleo demoniaco
228121	patron bolsa de pano runico reforzada con cuero
228122	el nucleo de magma
228123	epifania jubilosa
228124	epifania onirica
228125	campeona de arcanita refinada
228126	epifania aperitiva
228127	guardamunecas de inestabilidad
228128	martillo del yunquenegro
228129	craneo de llama de las sombras
228130	resguardo altruista
228131	resguardo altruista
228132	papas no muertas
228133	¿magma o lava
228134	norte de kalimdor una guia exhaustiva
228135	un estudio de la luz
228136	¡ka bum
228137	corazon de golemagg
228138	el caballero y la dama
228139	puno de los jurafuegos
228140	la plaga ¿amenaza de no muertos o incomprendidos
228141	nigromancia basica
228142	tierra y fuego
228143	espada de llama de las sombras
228144	nota extrana
228145	garra derecha de magmadar
228146	garra izquierda de magmadar
228147	cuerno de magmadar
228160	infundidora de fe
228162	engano
228163	broche de la madre del linaje
228165	jabalina de matadragones
228166	llave de la ciudad
228168	mueleengranajes goblin
228169	la ajustadora de actitud
228170	remo improvisado de los mares del sur
228171	portamonedas de kezan
228172	resguardo de ilusion diente oscuro
228173	tratado sobre los consagrados
228174	tratado sobre los devotos
228175	tratado sobre prontitud sagrada
228176	totem de trueno
228177	totem de fuego embravecido
228178	totem de vitalidad terranea
228179	totem de las llanuras
228180	idolo del enjambre
228181	idolo de desangramiento felino
228182	idolo de desangramiento oso
228183	idolo de la arboleda
228184	cuerda para la ropa goblin
228185	botella rota de goblino noir
228186	alianza abandonada
228187	vara del mar del sur
228188	horquilla de prestor
228189	ofrenda de gob
228190	conocimiento de los fauces de madera
228191	mineral fundido resplandeciente
228214	monstruo maza 2m fuerza imparable
228222	vademecum de valor de azeroth
228227	scroll of overwhelming power
228229	hoja afilada de obsidiana
228230	martillo de los titanes refinado
228239	toga de poder volatil
228240	quijotes de despiertallamas
228242	anillo pesado de hierro negro
228243	anillo de poder con hechizos
228244	leotardos de tormenta de mana
228245	pantalones de escamas de salamandra
228246	guardamunecas de estabilidad
228247	gargantilla de iluminacion
228248	sacudetierra
228249	medallon del poderio ferreo
228250	diseno guanteletes de mayor aferramiento
228251	patron guanteletes de dragontina verde viva
228252	marca de asediador
228253	escarpes del caminante sobre llamas
228254	botas templadas de magma
228255	dije de poder efimero
228256	cordon de ignicion de mana
228257	guantes viejos de cuero del nucleo
228258	bufas del interior de la tierra
228259	grimorio runico de fuego
228260	guanteletes de guardia de llamas
228261	anillo de golpe rapido
228262	aplastador carmesi
228263	daga de hechicero
228264	martillo de piedra de aura
228265	hoja de brutalidad
228266	disco de horadador
228267	destripadora
228268	sello del archimago
228269	hoja magica de cantoazur
228270	lanzador tiroexplosion
228271	baston de dominancia
228272	tenebrosa
228273	tronadora
228274	sortija de cauterizacion
228275	grebas forjadas del nucleo
228276	patron capa ondeante de maestro de oficios
228277	diente de can del nucleo
228278	draga de lava hipertermicamente aislada
228279	sobrehombros de guardia de fuego
228280	capa a prueba de fuego
228281	guantes de la llama hipnotica
228282	fajin de los secretos susurrados
228283	bufas de crecimiento salvaje
228284	guardamunecas de autentico vuelo
228285	yelmo del dador de vida
228286	sortija de accuria
228287	sortija de sulfuras
228288	filo del espetahuesos
228289	gargantilla del senor del fuego
228290	embozo de la niebla envolvente
228291	corona de destruccion
228292	manteo de sangre de dragon
228293	esencia de la llama pura
228294	defensor de malistar
228295	faja de acometida
228296	hoja de perdicion
228297	fragmento de la llama
228298	fragmento de la escama
228299	segadora espinal
228301	patron avambrazos de vuelo presto
228303	patron toga de tela lunar incandescente
228304	esquema rifle de tirador certero de nucleo igneo
228305	diseno martillo de los titanes refinado
228306	diseno profanacion
228307	diseno buscacorazones mortal
228308	diseno tranquilidad
228309	patron coraza de dragontina verde viva
228310	diseno guarda de escarcha endurecida
228311	diseno martillo de batalla con encantamiento delicado
228312	diseno malla invencible
228313	diseno guanteletes de tempestad
228314	diseno cresta de guerra del gran jefe
228315	diseno hoja sabia del archimago
228316	patron jubon de tela lunar incandescente
228317	patron diadema de tela lunar incandescente
228318	patron leotardos de tela lunar incandescente
228319	patron faja de perspicacia arcana
228323	moneda de matanza de cobre
228324	moneda de matanza de oro
228325	moneda de matanza de plata
228326	cartera de monedas de matanza de cobre
228327	cartera de monedas de matanza de plata
228332	lok delar baculo de los guardianes ancianos
228334	rhok delar arco largo de los guardianes ancianos
228335	oracion
228336	anatema
228340	faja de hielo sin derretir
228345	leotardos de supremacia arcana
228347	tifon
228349	garra izquierda de eskhandar
228350	garra derecha de eskhandar
228351	guanteletes de pellejo maldito
228352	leotardos vil imbuidos
228353	jaula de cabeza infernal
228354	medallon furia abrasadora
228355	cinturon de piel de guardia apocaliptico
228356	guardian del sello ambar
228357	brazal de luz negra
228359	anillo de entropia
228360	pelambre de eskhandar
228381	mordedura de frio
228382	colmillo de los misticos
228383	manteo enjundioso
228384	botas cieganieve
228385	corona adornada con cristales
228389	manton de oracion
228397	demoledor empireo
228410	hoja terrorifica del destructor
228432	silbato de la bestia
228459	hoja afilada de obsidiana
228460	segadora espinal
228461	filo del espetahuesos
228462	martillo de piedra de aura
228463	sacudetierra
228464	sello real de eldre thalas
228465	sello real de eldre thalas
228466	sello real de eldre thalas
228467	sello real de eldre thalas
228468	leotardos mohomarana
228469	anillo elfico deslustrado
228470	leotardos lunargenta
228471	machacapiedras
228472	daga de distraccion
228473	gran maza implacable
228474	toga de oleada de mente
228475	manto diabolico
228476	cinturon del archimago bordado
228477	patron cinturon del archimago bordado
228478	hoja atroz
228479	leotardos de destruccion
228480	corona del rey ogro
228484	vara de los magi ogros
228486	aterrantarboles
228498	hoja terrorifica del destructor
228500	mascara del imperdonable
228501	blusa ruisenor
228502	flautin de la llama flameante
228503	prendas de lana de juglar saltarin
228504	faja arco iris
228505	capa de tribunal real
228506	hoja de brutalidad
228508	martillo del yunquenegro
228511	hoja de perdicion
228513	avambrazos del sadico
228514	galochas de timmy
228515	lazo de grimagore
228516	pacificador
228517	hoja magica de cantoazur
228518	punos de magistrado
228519	marca de asediador
228520	manto de ladron de almas
228521	manijas con encaje enigmaticas
228522	obus portatil de willey
228523	mensajero bola de canon
228524	sello de jefe de correos
228525	guerrera de jefe de correos
228527	calzas de jefe de correos
228528	banda de jefe de correos
228529	botines de jefe de correos
228530	musleras de placas de quitina
228531	fajin thuzadin
228532	brazal de morlune
228533	collar de caparazones nacarados
228534	leotardos de can de peste
228535	hachuela rebanadora de huesos
228536	estrella de mystaria
228537	guanteletes draconianos
228538	sello de osahendido
228539	libro de los muertos
228540	corona de tirania
228541	ofrenda del magi elfico
228542	espetadora forjacraneos
228543	hojarruna del baron osahendido
228544	martillo del gran cruzado
228545	yelmo del gran cruzado
228546	embozo de nathrezim
228547	toga de tejido de hierro
228548	cetro de enfoque interminable
228551	guerrera de la media luna
228552	guanteletes de ardid
228553	yelmo del verdugo
228554	guantes de piel de demonio
228555	hoja fase
228556	delantal de carnicero
228557	botas de batalla dardopresto
228558	punos de funeral
228559	cuervo negro
228561	guanteletes de objetivo real
228562	bufas con runas demoniacas
228563	globo de d sak
228564	botas de vigia de torre ogro
228565	anillo de mago
228566	tiara de fuego estelar
228567	faja de cincelador
228568	guanteletes de backus
228570	puno de omokk
228571	torso del rey chaman
228572	guardabrazos cuorobronce
228573	escupeveneno
228574	dije de evasion
228575	brazales garraja
228576	ojo de telabrasada
228577	guanteletes dorados
228578	fajin pluma de polvo
228579	faja cristalizada
228583	sobrehombros golpevero
228584	dije furia de ascuas
228585	marca del senor de los dragones
228586	congeladora
228587	baston de refugio
228588	garras de reiver
228589	corazon de la escama
228590	manto de hendevidente
228591	protector rhombeard
228592	colmillo de la arana de cristal
228593	botas de bailavientos
228594	botas de precision de kayser
228595	faja de tirador
228596	cinturon de tejido de hierro
228597	botas de tejido de hierro
228598	brazales de tejido de hierro
228599	corazon de vermisthalak
228600	el rompe mandibulas
228601	guadana incansable
228602	botos de llamas
228603	sierra de fatalidad de puno negro
228604	ojo de rend
228605	sobrehombros de huesopua
228606	hoja negra de shahram
228607	monstruo espada 2m basica
228615	tesoro sobrenatural
228650	musleras de maestro de guerra
228651	ajorcas belinato
228652	guardian tribal de dal rend
228653	carga sagrada de dal rend
228659	baculo con grabados de runas antiguas
228660	leotardos de maestro del acero
228661	musleras de tristam
228662	guardabrazos de bruma negra
228663	capa luna de sangre
228664	manteo de tejescarcha
228666	sauce lloron
228667	sortija tejedano
228669	diente de gnarr
228670	faja de brigam
228672	faja artesanal de maestro herrero
228675	sortija de reflexion
228676	faja ola feral
228677	turbante de tejido de hechizos
228678	emblema draconico imbuido
228679	quel serrar
228680	compendio de matar dragones de nostro
228681	capucha de tejido de hierro
228682	baston de mando de lord valthalak
228683	sortija runica de hechiceria
228684	colgante de celeridad
228685	colgante de diente de onyxia
228686	dije de sangre de onyxia
228687	sello de matadragones
228688	cabeza de onyxia
228689	cabeza de onyxia
228690	la luz y como alterarla
228691	garona un estudio sobre el sigilo y la traicion
228692	codice de defensa
228693	el libro de cocina del arcanista
228695	una hoja elfica desafilada
228696	hoja antigua caliente
228697	espada antigua tratada
228699	anillo de astucia demoniaca
228700	manto de tejido de hierro
228701	diente de can del nucleo
228702	disco de horadador
228703	zapatillas de piedrafria
228704	caperuza de cuero andrajoso
228722	mano de la justicia
228746	mecazancudo verde fosforito
228747	riendas del dientes de sable dorado
228748	silbato del raptor sanguino jaspeado
228749	astilla de nordrassil
228757	daga vil
228759	collar de eskhandar
228797	grimorio de armadura vil
228912	llave del deposito de artefactos
228922	baston de dominancia
228924	botas hierro negro templadas
228925	botas hierro negro templadas
228926	botas hierro negro templadas
228927	botas hierro negro templadas
228928	botas hierro negro templadas
228929	botas hierro negro templadas
228955	grimorio piedra angular antigua
228978	sigilo encantado aguas fluidas
228979	sigilo encantado aguas fluidas
228980	recubrimiento de escudo conductor
228981	formula recubrimiento de escudo conductor
228982	formula encantar escudo ley de la naturaleza
228992	mochila de pellejo de onyxia
228993	patron bolsa sin fondo
228994	bolsa sin fondo
229008	formula encantar capa resistencia al fuego superior
229009	formula encantar capa resistencia a la naturaleza superior
229055	seda aranasi deshilachada
229056	trozo de piedra pomez
229057	mercancias incautadas
229352	hallazgos de inteligencia
229362	llave de almacen
229372	destripadora
229373	infundidora de fe
229374	puno de los jurafuegos
229376	daga de hechicero
229377	garra izquierda de magmadar
229378	garra derecha de magmadar
229379	garra derecha de eskhandar
229380	tenebrosa
229381	tronadora
229382	draga de lava hipertermicamente aislada
229415	suministros de supervivencia
229416	pelaje calido
229749	faro de verdad
229806	faro de verdad
229894	esmeralda onirica
229897	pergamino crear sello de senalizacion
229906	escama de bronce deslustrada
229909	baston del orden
229910	guadana del caos
229911	comesuenos de caius
229964	pezuna del senor demoniaco
229965	el ojo de az olgothal
229966	torque de la mano de plata
229971	baston de inferno
229972	baston de helada blanca
230002	rematadora letal
230018	fragmentos de orbe de mannoroc
230224	trueno furioso espada bendita del hijo del viento
230237	gema arcana imbuida
230238	el libro negro
230239	guantes de evolucion rapida
230240	manto del conciliabulo alanegra
230241	machacapuas
230242	la espada indomable
230243	gema de estimulo mental
230244	sigilo de cambiaformas
230245	colgante del dragon caido
230246	yelmo de ira infinita
230247	hoja colmillo dragon
230248	protector de dragontina roja
230249	gema dadora de vida
230250	totem venenoso
230251	espaldares de linaje negro
230252	brazales de precision arcana
230253	apuntacorazones
230254	maladath hoja runica del vuelo negro
230255	cinturon de pellejo de dragon tirante
230256	espaldares de garfa de draco
230257	anillo de roca negra
230269	gema rejuvenecedora
230270	baston de enfoque de alasombra
230271	cuchilla de garfa de draco
230272	pergaminos de luz cegadora
230273	cristal de alineacion natural
230274	toga de ceniza negra
230275	agarre de faucefogo
230276	garra del draco negro
230277	capa de faucefogo
230278	musleras del cruzado caido
230279	musleras enlazadas de primalista
230280	egida de preservacion
230281	sortija de concentracion forzada
230282	dije de colmillo de draco
230723	guantes de llamas de ebano
230725	baluarte bendito de malfurion
230726	culebrina aliento de dragon
230733	embozo de pensamiento puro
230734	circulo de fuerza aplicada
230735	leotardos de tejido de ascuas
230736	escarabajo trabador de styleen
230737	toque de dragon
230738	heraldo de tragedia
230739	garra de angelista
230740	hombreras de pellejo de dragon tirante
230741	botas cromaticas
230742	guantes de pellejo de dragon tirante
230743	geta fulgurante
230744	capa tejida con elementium
230745	faja del cruzado caido
230746	leotardos potenciados
230747	espada templada cromaticamente
230751	obi de ninja
230794	garra de chromaggus
230800	guardarrenes enlazados de primalista
230801	ashjre thul ballesta de paliza
230802	baluarte reforzado de elementium
230804	capa del senor del linaje
230805	botas de la llama de las sombras
230806	eslabon de therazane
230808	anillo de juicio de archimtiros
230810	lagrima de neltharion
230811	sortija de elementium puro
230812	mish undare aro del despelleja almas
230813	baston de la llama de las sombras
230818	ashkandi espada magna de la hermandad
230837	crul shorukh filo del caos
230838	lok amir il romathis
230839	anillo de maestro matadragones
230840	medallon de maestro matadragones
230841	orbe de maestro matadragones
230842	capa de poderio draconico
230843	botas de pensamiento puro
230844	gran maza draconica
230845	filo de la fatalidad
230846	sortija del dominio oscuro
230847	recolector de esencia
230848	chaleco de las sombras entrelazado
230849	botas de ventisca de ringo
230854	sortija de servidumbre
230855	sello de rabioso gurubashi
230856	cinturon de poder sin explotar
230857	mascara empapada de sangre
230858	capa de los adoradores hakkari
230859	guantes del atormentado
230860	poderio de la tribu
230861	guanteletes de sacrificio
230862	ornato zulian
230863	cetro zulian de ritos
230864	camisote runico manchado de sangre
230865	colmillo de venoxis
230866	escarpines empapados de sangre
230867	sortija de zanzil
230868	hacha de piedra zulian
230903	pergamino esencia de fuego
230904	pergamino ciaenes ed ufoge
230908	esencia de fuego imbuida
230909	esencia de fuego agotada
230911	triturador de jeklik
230912	bufas de animista
230913	dije opalo de jeklik
230914	botas de pacificador
230915	sortija de primalista
230916	botas de furia marina
230917	togas de ritual sueltas
230918	toque de mar li
230919	grebas manchadas de sangre
230920	ojo de mar li
230921	sortija de jin
230922	dije de proteccion
230923	botas de traidor
230925	agarre de thekal
230926	leotardos de pacificador
230927	musleras de ritual
230928	leotardos de furia marina
230929	sello de jin
230930	cercenadora zulian
230934	agarre de arlokk
230939	voluntad de arlokk
230941	palo hudu de arlokk
230942	grebas empapadas de sangre
230943	sortija de onice de senor supremo
230944	saco de pellejo de pantera
230946	pergamino aieesnc ed sacearch
230947	pergamino esencia de escarcha
230948	esencia de escarcha imbuida
230949	esencia de escarcha agotada
230984	baston del orden incompleto
230989	defensor del senor de la sangre
230991	alabarda de golpeo
230992	hoja de guerra de los hakkari
230993	aguijon de mandokir
230994	leotardos de animista
230995	mandiletes empapados de sangre
230996	espaldares empapados de sangre
230997	falda tintada de sangre
230998	capa loa hakkari
230999	sortija carmesi de senor supremo
231000	sello de primalista
231001	sello de zanzil
231002	brujo de jin do
231003	ojo maligno de jin do
231004	sentencia de jin do
231005	bolsa de mal aguero de jin do
231006	botas de animista
231007	almofar manchado de sangre
231008	quijotes manchados de sangre
231009	leotardos empapados de sangre
231010	guanteletes empapados de sangre
231011	guantes tintados de sangre
231012	abrazo de senor supremo
231013	el casquete de aojador
231014	parche para ojo de escamas de lagarto
231015	mascara de sarga
231016	ejecutor de pescado de nat pagle
231023	guardamunecas de colera
231024	guardarrenes de colera
231025	espaldares de colera
231026	musleras de colera
231027	visera de colera
231028	manoplas de colera
231029	escarpes de colera
231030	coselete de colera
231031	brazales de colera
231032	cinturon de colera
231033	sobrehombros de colera
231034	quijotes de colera
231035	yelmo de colera
231036	guanteletes de colera
231037	grebas de colera
231038	coraza de colera
231039	bufas colmillo de sangre
231040	pechera colmillo de sangre
231041	botas colmillo de sangre
231042	guantes colmillo de sangre
231043	caperuza colmillo de sangre
231044	pantalones colmillo de sangre
231045	cinturon colmillo de sangre
231046	brazales colmillo de sangre
231047	hombreras colmillo de sangre
231048	coselete colmillo de sangre
231049	escarpines colmillo de sangre
231050	manoplas colmillo de sangre
231051	capucha colmillo de sangre
231052	musleras colmillo de sangre
231053	guardarrenes colmillo de sangre
231054	guardamunecas colmillo de sangre
231055	brazales de acechadragon
231056	cinturon de acechadragon
231057	bufas de acechadragon
231058	musleras de acechadragon
231059	yelmo de acechadragon
231060	guanteletes de acechadragon
231061	grebas de acechadragon
231062	coraza de acechadragon
231063	avambrazos de acechadragon
231065	faja de acechadragon
231066	espaldares de acechadragon
231067	pantalones de acechadragon
231068	escutelaria de acechadragon
231069	mandiletes de acechadragon
231070	escarpes de acechadragon
231071	armadura de acechadragon
231072	botas de la nemesis
231073	guantes de la nemesis
231074	capacete de la nemesis
231075	leotardos de la nemesis
231076	togas de la nemesis
231077	bufas de la nemesis
231078	cinturon de la nemesis
231079	brazales de la nemesis
231090	botines de la nemesis
231091	manoplas de la nemesis
231092	capucha de la nemesis
231093	pantalones de la nemesis
231095	atuendo de la nemesis
231096	hombreras de la nemesis
231097	cordon de la nemesis
231098	sobrevestes de la nemesis
231100	cinturon viento abisal
231101	botas viento abisal
231102	guantes viento abisal
231103	corona viento abisal
231104	pantalones viento abisal
231105	togas viento abisal
231106	manto viento abisal
231107	ataduras viento abisal
231108	fajin viento abisal
231109	zapatillas viento abisal
231110	mitones viento abisal
231111	mascara viento abisal
231112	leotardos viento abisal
231113	vestimentas viento abisal
231114	sobrehombros viento abisal
231115	sobrevestes viento abisal
231155	botas de trascendencia
231156	manoplas de trascendencia
231157	halo de trascendencia
231158	leotardos de trascendencia
231159	togas de trascendencia
231160	espaldares de trascendencia
231161	cinturon de trascendencia
231162	ataduras de trascendencia
231165	botines de trascendencia
231166	guantes de trascendencia
231167	corona de trascendencia
231168	pantalones de trascendencia
231169	atuendo de trascendencia
231170	manto de trascendencia
231171	cordon de trascendencia
231172	brazales de trascendencia
231174	ataduras de sentencia
231175	cinturon de sentencia
231176	bufas de sentencia
231177	quijotes de sentencia
231178	corona de sentencia
231179	guanteletes de sentencia
231180	escarpes de sentencia
231181	coraza de sentencia
231182	avambrazos de sentencia
231183	guardarrenes de sentencia
231184	espaldares de sentencia
231185	musleras de sentencia
231186	gran yelmo de sentencia
231187	coselete de sentencia
231188	manoplas de sentencia
231189	grebas de sentencia
231190	brazales de sentencia
231191	faja de sentencia
231192	manto de sentencia
231193	saya de placas de sentencia
231194	yelmo de sentencia
231195	guantes de sentencia
231196	botines de sentencia
231197	loriga de sentencia
231198	guanteletes de diez tormentas
231199	brazales de diez tormentas
231200	cinturon de diez tormentas
231201	cubrehombros de diez tormentas
231202	quijotes de diez tormentas
231203	casco de diez tormentas
231204	grebas de diez tormentas
231205	coraza de diez tormentas
231206	manoplas de diez tormentas
231207	guardamunecas de diez tormentas
231208	guardarrenes de diez tormentas
231209	espaldares de diez tormentas
231210	musleras de diez tormentas
231211	visera de diez tormentas
231212	escarpes de diez tormentas
231213	coselete de diez tormentas
231214	guantes de diez tormentas
231215	ataduras de diez tormentas
231216	cordon de diez tormentas
231217	manto de diez tormentas
231218	falda de diez tormentas
231219	ornato de diez tormentas
231220	botas de diez tormentas
231221	abrazo de diez tormentas
231222	mandiletes de diez tormentas
231223	avambrazos de diez tormentas
231224	faja de diez tormentas
231225	bufas de diez tormentas
231226	leotardos de diez tormentas
231227	corona de diez tormentas
231228	botines de diez tormentas
231229	armadura de diez tormentas
231230	coselete de tempestira
231231	botas de tempestira
231232	manoplas de tempestira
231233	casquete de tempestira
231234	musleras de tempestira
231235	espaldares de tempestira
231236	cinturon de tempestira
231237	brazales de tempestira
231238	armadura de tempestira
231239	botines de tempestira
231240	guanteletes de tempestira
231241	ornato de tempestira
231242	leotardos de tempestira
231243	bufas de tempestira
231244	guardarrenes de tempestira
231245	guardamunecas de tempestira
231246	cueros de tempestira
231247	sandalias de tempestira
231248	mitones de tempestira
231249	cornamenta de tempestira
231250	falda de tempestira
231251	manto de tempestira
231252	cordon de tempestira
231253	ataduras de tempestira
231254	jubon de tempestira
231255	apisonadoras de tempestira
231256	mandiletes de tempestira
231257	capucha de tempestira
231258	calzas de tempestira
231259	hombreras de tempestira
231260	fajin de tempestira
231261	sobrevestes de tempestira
231271	carrete roto de nat pagle
231272	arpon de tigule
231273	punzon de gri lek
231274	molinillo de gri lek
231275	castigador de furia abrasadora
231276	entorpecedor
231277	horquilla de locura
231278	arco de caza hudu
231279	atizador de wushoolay
231280	talisman de naturaleza de wushoolay
231281	talisman de espiritus de wushoolay
231282	talisman de magia gelida de hazza rah
231283	talisman de proteccion de hazza rah
231284	talisman de destruccion de hazza rah
231285	talisman de valor de gri lek
231286	talisman de poderio de gri lek
231287	talisman de artimanas de renataki
231288	talisman de devastacion de renataki
231289	egida del dios de la sangre
231293	destripahombres hakkari antiguo
231296	llamasangre
231298	pergamino de reparacion espacial menor
231299	quijotes empapados de sangre
231300	capa de consumo
231301	colmillo del ignoto
231302	destructora de enanos gurubashi
231303	guanteletes de pacificador
231304	pergamino ceprraaion laesapci norem
231305	guanteletes de furia marina
231306	collar de corruptor de alma
231307	el ojo de hakkar
231308	toque del caos
231309	hoja de guerra de los hakkari
231315	zin rokh destructora de mundos
231316	algas de los mares del sur encantadas pristinas
231317	guerrera de haruspex zandalar
231318	cinturon de haruspex zandalar
231319	brazales de haruspex zandalar
231320	colera de la voragine
231321	manto de depredador zandalar
231322	cinturon de depredador zandalar
231323	brazales de depredador zandalar
231324	joya de kajaro
231325	manto de ilusionista zandalar
231326	brazaletes de ilusionista zandalar
231327	toga de ilusionista zandalar
231328	ensena de heroe
231329	coraza de librepensador zandalar
231330	cinturon de librepensador zandalar
231331	guardabrazos de librepensador zandalar
231332	el ojo que todo lo ve de zuldazar
231333	manto de confesor zandalar
231334	ataduras de confesor zandalar
231335	brazaletes de confesor zandalar
231336	dije zandalar de maestria de las sombras
231337	guerrera de sinconcierto zandalar
231338	manto de sinconcierto zandalar
231339	brazales de sinconcierto zandalar
231340	vision inmaculada de voodress
231341	camisote de augur zandalar
231342	cinturon de augur zandalar
231343	brazales de augur zandalar
231346	mancha imparable de kezan
231347	brazaletes de endemoniado zandalar
231348	toga de endemoniado zandalar
231349	manto de endemoniado zandalar
231350	ira de mugamba
231351	guardabrazos de vindicador zandalar
231352	cinturon de vindicador zandalar
231353	coraza de vindicador zandalar
231354	caricia de animista
231355	equilibrio de animista
231357	furia de animista
231358	rugido de animista
231359	llamada del falcon
231361	sello de sincretista
231362	sigilo de sincretista
231363	blason de sincretista
231364	emblema de sincretista
231366	aura profetica
231367	maldicion profetica
231368	abrazo de la muerte
231370	avance de la muerte
231371	abrazo de vodouisant
231372	sudario de vodouisant
231373	encanto de vodouisant
231375	vigilancia de vodouisant
231376	maleficio hudu
231377	maldicion hudu
231378	disco dorado resplandeciente
231379	presencia de poderio
231381	presencia de valor
231382	vasija de renacer
231383	presencia de vista
231384	furia del halcon
231385	simulacro del alma de dragon
231386	dragontina negra impecable
231387	tormentira hoja corta santificada del buscarafagas
231452	sangre del iluminado
231460	rompeplanos de azgaloth
231466	codice de brujo alanegra
231509	tomo de cassandra
231512	idolo hakkari primigenio
231513	sangre de gri lek
231514	diente de renataki
231515	melena de wushoolay
231516	hilo de sueno de hazza rah
231517	muneco de vudu agujereado
231518	muneco de vudu agujereado
231519	muneco de vudu agujereado
231520	muneco de vudu agujereado
231521	muneco de vudu agujereado
231522	muneco de vudu agujereado
231523	muneco de vudu agujereado
231524	muneco de vudu agujereado
231525	muneco de vudu agujereado
231530	armadura de placas de senor de la guerra
231531	botas de placas de general
231532	guanteletes de placas de general
231533	leotardos de placas de general
231534	sobrehombros de placas de senor de la guerra
231535	celada de placas de senor de la guerra
231536	armadura de placas de mariscal de campo
231537	guardahombros de placas de mariscal de campo
231538	yelmo de placas de mariscal de campo
231539	botas de placas de mariscal
231540	musleras de placas de mariscal
231541	guanteletes de placas de mariscal
231543	pechera de cuero de mariscal de campo
231544	luas de cuero de mariscal
231545	mascara de cuero de mariscal de campo
231546	guardapies de cuero de mariscal
231547	cubrehombros de cuero de mariscal de campo
231548	leotardos de cuero de mariscal
231549	coraza de cuero de senor de la guerra
231551	bufas de cuero de senor de la guerra
231552	botines de cuero de general
231553	yelmo de cuero de senor de la guerra
231554	musleras de cuero de general
231555	mitones de cuero de general
231557	espaldares de anillas de mariscal de campo
231558	quijotes de anillas de mariscal
231560	mandiletes de anillas de mariscal
231561	escarpes de anillas de mariscal
231562	gran yelmo de anillas de mariscal de campo
231563	armadura de anillas de mariscal de campo
231564	escarpes de anillas de general
231565	espaldares de anillas de senor de la guerra
231566	armadura de anillas de senor de la guerra
231567	quijotes de anillas de general
231568	gran yelmo de anillas de senor de la guerra
231569	mandiletes de anillas de general
231570	grebas de anillas de general
231571	yelmo de anillas de senor de la guerra
231572	sobrehombros de anillas de senor de la guerra
231573	camisote de anillas de senor de la guerra
231574	musleras de anillas de general
231575	abrazaderas de anillas de general
231576	sobrehombros de anillas de mariscal de campo
231577	musleras de anillas de mariscal
231578	abrazaderas de anillas de mariscal
231579	grebas de anillas de mariscal
231580	yelmo de anillas de mariscal de campo
231581	camisote de anillas de mariscal de campo
231582	toga de tejido de tinieblas de mariscal de campo
231583	sobrehombros de tejido de tinieblas de mariscal de campo
231584	corona de mariscal de campo
231585	botas de tejido de tinieblas de mariscal
231586	guantes de tejido de tinieblas de mariscal
231587	leotardos de tejido de tinieblas de mariscal
231588	pantalones de tejido de tinieblas de general
231589	guantes de tejido de tinieblas de general
231590	caperuza de tejido de tinieblas de senor de la guerra
231591	toga de tejido de tinieblas de senor de la guerra
231592	manto de tejido de tinieblas de senor de la guerra
231593	botas de tejido de tinieblas de general
231594	amito de seda de senor de la guerra
231595	calzas de seda de general
231596	vestimenta de seda de senor de la guerra
231597	botas de seda de general
231598	guantes de seda de general
231599	guanteletes de seda de general
231600	manijas de seda de general
231601	capucha de seda de senor de la guerra
231602	bufas de seda de mariscal de campo
231603	vestimentas de seda de mariscal de campo
231604	nimbo de mariscal de campo
231605	leotardos de seda de mariscal
231606	borceguies de seda de mariscal
231607	guantes de seda de mariscal
231608	guanteletes de seda de mariscal
231609	manijas de seda de mariscal
231610	botines de saten de general
231611	cubrehombros de saten de senor de la guerra
231612	togas de saten de senor de la guerra
231613	mandiletes de saten de general
231614	leotardos de saten de general
231615	corona de saten de senor de la guerra
231616	corona de saten de mariscal de campo
231617	mandiletes de saten de mariscal
231618	toga de saten de mariscal de campo
231619	leotardos de saten de mariscal
231620	botines de saten de mariscal
231621	cubrehombros de saten de mariscal de campo
231622	caperuza de saten de mariscal de campo
231623	manijas de saten de mariscal
231624	guerrera de saten de mariscal de campo
231626	musleras de saten de mariscal
231627	botos de saten de mariscal
231628	manto de saten de mariscal de campo
231630	botos de saten de general
231631	manto de saten de senor de la guerra
231632	guerrera de saten de senor de la guerra
231633	manijas de saten de general
231634	musleras de saten de general
231635	capucha de saten de senor de la guerra
231639	musleras de laminas de mariscal
231640	casco de laminas de mariscal de campo
231641	peto de laminas de mariscal de campo
231642	bolsa de hierbas de celador
231643	guantes de laminas de mariscal
231644	bolsa de encantamiento de celador
231645	espaldares de laminas de mariscal de campo
231646	grebas de laminas de mariscal
231647	leotardos de laminas de mariscal
231648	protegecabezas de laminas de mariscal de campo
231649	coraza de laminas de mariscal de campo
231650	guanteletes de laminas de mariscal
231651	sobrehombros de laminas de mariscal de campo
231652	escarpes de laminas de mariscal
231653	camisote de malla de senor de la guerra
231654	espaldares de malla de senor de la guerra
231655	abrazaderas de malla de general
231656	grebas de malla de general
231657	protegecabezas de malla de senor de la guerra
231658	musleras de malla de general
231659	bufas de malla de senor de la guerra
231660	guanteletes de malla de general
231661	escarpes de malla de general
231662	coraza de malla de senor de la guerra
231663	yelmo de malla de senor de la guerra
231664	leotardos de malla de general
231665	cubrehombros de malla de senor de la guerra
231666	guantes de malla de general
231667	botas de malla de general
231668	coselete de malla de senor de la guerra
231669	escutelaria de malla de senor de la guerra
231670	pantalones de malla de general
231671	grebas de pellejo de dragon de general
231672	espaldares de pellejo de dragon de senor de la guerra
231673	musleras de pellejo de dragon de general
231674	guerrera de pellejo de dragon de senor de la guerra
231675	ornato de pellejo de dragon de senor de la guerra
231676	guanteletes de pellejo de dragon de general
231677	guantes de pellejo de dragon de general
231678	yelmo de pellejo de dragon de senor de la guerra
231679	armadura de pellejo de dragon de senor de la guerra
231680	pantalones de pellejo de dragon de general
231681	bufas de pellejo de dragon de senor de la guerra
231682	botas de pellejo de dragon de general
231683	botines de pellejo de dragon de general
231684	sobrehombros de pellejo de dragon de senor de la guerra
231685	leotardos de pellejo de dragon de general
231686	pechera de pellejo de dragon de senor de la guerra
231687	protegecabezas de pellejo de dragon de senor de la guerra
231688	mandiletes de pellejo de dragon de general
231689	protegecabezas de pellejo de dragon de mariscal de campo
231690	pechera de pellejo de dragon de mariscal de campo
231691	leotardos de pellejo de dragon de mariscal
231692	botines de pellejo de dragon de mariscal
231693	sobrehombros de pellejo de dragon de mariscal de campo
231694	mandiletes de pellejo de dragon de mariscal
231695	yelmo de pellejo de dragon de mariscal de campo
231696	armadura de pellejo de dragon de mariscal de campo
231697	pantalones de pellejo de dragon de mariscal
231698	botas de pellejo de dragon de mariscal
231699	bufas de pellejo de dragon de mariscal de campo
231700	guantes de pellejo de dragon de mariscal
231701	ornato de pellejo de dragon de mariscal de campo
231702	guerrera de pellejo de dragon de mariscal de campo
231703	musleras de pellejo de dragon de mariscal
231704	grebas de pellejo de dragon de mariscal
231705	espaldares de pellejo de dragon de mariscal de campo
231706	guanteletes de pellejo de dragon de mariscal
231707	ataduras draconianas
231708	cinturon draconiano
231709	hombreras draconianas
231710	leotardos draconianos
231711	caperuza draconiana
231712	guantes draconianos
231713	botas draconianas
231714	toga draconiana
231715	ataduras primitivas
231716	cinturon primitivo
231717	hombreras primitivas
231718	leotardos primitivos
231719	yelmo primitivo
231720	guantes primitivos
231721	botas primitivas
231722	guadana del caos agotada
231723	cofre primitivo
231724	ataduras antiguas
231725	cinturon antiguo
231726	hombreras antiguas
231727	leotardos antiguos
231728	yelmo antiguo
231729	guantes antiguos
231730	botas antiguas
231731	cofre antiguo
231732	suministros sospechosos
231752	s03 monster sword 2h alliance
231753	consuelo de muro celeste
231754	cernicalo
231755	peregrino
231777	extremidad de qiraji cristalizada
231778	agua de manantial de montana
231779	colera de wray
231780	escrito sobre crear agua viii
231781	alma de trueno
231782	corona del sucesor
231783	manton del senor del viento
231784	celda de relampago
231785	ecos de la traicion
231789	sigilo del vigilante
231792	alma de travesuras
231793	guadana del caos agotada travesuras
231794	guadana del caos agotada vacio
231795	guadana del caos agotada encantamiento
231796	guadana del caos agotada devoracion
231797	alma del vacio
231798	alma de encantamiento
231799	alma de devoracion
231800	alma de des altek
231803	dije de connivencia de prestor
231806	flecha abrasadora
231807	disparo ardoroso
231811	tratado sobre asombro
231814	corazon cromatico
231815	desgarrauda
231817	cortavientos
231823	guja de geddon
231828	runa de especializacion de meditacion
231829	runa de especializacion de sanacion
231836	pergamino resplandeciente de reparacion espacial
231837	tallado de las sombras
231841	sangre del iluminado
231842	baculo de nandieb
231843	primer trozo de sigilo
231844	segundo trozo de sigilo
231845	tercer trozo de sigilo
231846	punzon de gri lek
231847	molinillo de gri lek
231848	ejecutor de peces de nat pagle
231849	arpon de tigule
231850	voluntad de arlokk
231851	agarre de arlokk
231852	destructora de enanos gurubashi
231853	hoja de guerra de los hakkari
231854	zin rokh destructora de mundos
231855	colmillo del ignoto
231856	destripahombres hakkari antiguo
231857	toque del caos
231858	llamasangre
231859	brujo de jin do
231860	sentencia de jin do
231861	triturador de jeklik
231862	castigador de furia abrasadora
231863	entorpecedor
231864	horquilla de locura
231865	cetro zulian de ritos
231866	toque de mar li
231867	defensor del senor de la sangre
231868	aguijon de mandokir
231869	hoja de guerra de los hakkari
231870	alabarda de golpeo
231871	atizador de wushoolay
231872	arco de caza hudu
231873	hacha de piedra zulian
231874	colmillo de venoxis
231875	agarre de thekal
231876	cercenadora zulian
231882	recibo de aparato de supresion
231885	agonia de escarcha
231890	terrestris
231891	tratado del falcon
231901	faro de verdad
231902	amuleto de ada
231903	retazo de tela rasgada
231904	cuerno deslustrado
231909	luz estelar cristalizada
231910	corazon de azgaloth
231911	sello de general de la legion
231912	hoja del foso
231913	ojo del observador
231995	escoria de elementium endurecido
231996	goblificador suprcargado
232018	hoja besada por el viento durmiente
232079	ataduras de tempestira
232080	cordon de tempestira
232081	manto de tempestira
232082	falda de tempestira
232083	cornamenta de tempestira
232084	mitones de tempestira
232085	sandalias de tempestira
232086	cueros de tempestira
232087	brazales de tempestira
232088	cinturon de tempestira
232089	espaldares de tempestira
232090	musleras de tempestira
232091	casquete de tempestira
232092	manoplas de tempestira
232093	botas de tempestira
232094	coselete de tempestira
232095	sobrevestes de tempestira
232096	fajin de tempestira
232097	hombreras de tempestira
232098	calzas de tempestira
232099	capucha de tempestira
232100	mandiletes de tempestira
232101	apisonadoras de tempestira
232102	jubon de tempestira
232103	guardamunecas de tempestira
232104	guardarrenes de tempestira
232105	bufas de tempestira
232106	leotardos de tempestira
232107	ornato de tempestira
232108	guanteletes de tempestira
232109	botines de tempestira
232110	armadura de tempestira
232111	avambrazos de acechadragon
232112	faja de acechadragon
232113	espaldares de acechadragon
232114	pantalones de acechadragon
232115	escutelaria de acechadragon
232116	mandiletes de acechadragon
232117	escarpes de acechadragon
232118	armadura de acechadragon
232119	brazales de acechadragon
232120	cinturon de acechadragon
232121	bufas de acechadragon
232122	musleras de acechadragon
232123	yelmo de acechadragon
232124	guanteletes de acechadragon
232125	grebas de acechadragon
232126	coraza de acechadragon
232127	ataduras viento abisal
232128	cinturon viento abisal
232129	manto viento abisal
232130	pantalones viento abisal
232131	corona viento abisal
232132	guantes viento abisal
232133	botas viento abisal
232134	togas viento abisal
232135	sobrevestes viento abisal
232136	fajin viento abisal
232137	sobrehombros viento abisal
232138	leotardos viento abisal
232139	mascara viento abisal
232140	mitones viento abisal
232141	zapatillas viento abisal
232142	vestimentas viento abisal
232143	ataduras de sentencia
232144	cinturon de sentencia
232145	bufas de sentencia
232146	quijotes de sentencia
232147	corona de sentencia
232148	guanteletes de sentencia
232149	escarpes de sentencia
232150	coraza de sentencia
232151	brazales de sentencia
232152	faja de sentencia
232153	manto de sentencia
232154	saya de placas de sentencia
232155	yelmo de sentencia
232156	guantes de sentencia
232157	botines de sentencia
232158	loriga de sentencia
232159	avambrazos de sentencia
232160	guardarrenes de sentencia
232161	espaldares de sentencia
232162	musleras de sentencia
232163	gran yelmo de sentencia
232164	manoplas de sentencia
232165	grebas de sentencia
232166	coselete de sentencia
232167	brazales de trascendencia
232168	cordon de trascendencia
232169	manto de trascendencia
232170	pantalones de trascendencia
232171	corona de trascendencia
232172	guantes de trascendencia
232173	botines de trascendencia
232174	atuendo de trascendencia
232175	ataduras de trascendencia
232176	cinturon de trascendencia
232177	espaldares de trascendencia
232178	leotardos de trascendencia
232179	halo de trascendencia
232180	manoplas de trascendencia
232181	botas de trascendencia
232182	togas de trascendencia
232183	brazales colmillo de sangre
232184	cinturon colmillo de sangre
232185	bufas colmillo de sangre
232186	pantalones colmillo de sangre
232187	caperuza colmillo de sangre
232188	guantes colmillo de sangre
232189	botas colmillo de sangre
232190	pechera colmillo de sangre
232191	guardamunecas colmillo de sangre
232192	guardarrenes colmillo de sangre
232193	hombreras colmillo de sangre
232194	musleras colmillo de sangre
232195	capucha colmillo de sangre
232196	manoplas colmillo de sangre
232197	escarpines colmillo de sangre
232198	coselete colmillo de sangre
232199	ataduras de diez tormentas
232200	cordon de diez tormentas
232201	manto de diez tormentas
232202	falda de diez tormentas
232203	ornato de diez tormentas
232204	guantes de diez tormentas
232205	botas de diez tormentas
232206	abrazo de diez tormentas
232207	brazales de diez tormentas
232208	cinturon de diez tormentas
232209	cubrehombros de diez tormentas
232210	quijotes de diez tormentas
232211	casco de diez tormentas
232212	guanteletes de diez tormentas
232213	grebas de diez tormentas
232214	coraza de diez tormentas
232215	avambrazos de diez tormentas
232216	faja de diez tormentas
232217	bufas de diez tormentas
232218	leotardos de diez tormentas
232219	corona de diez tormentas
232220	mandiletes de diez tormentas
232221	botines de diez tormentas
232222	armadura de diez tormentas
232223	guardamunecas de diez tormentas
232224	guardarrenes de diez tormentas
232225	espaldares de diez tormentas
232226	musleras de diez tormentas
232227	visera de diez tormentas
232228	manoplas de diez tormentas
232229	escarpes de diez tormentas
232230	coselete de diez tormentas
232231	brazales de la nemesis
232232	cinturon de la nemesis
232233	bufas de la nemesis
232234	leotardos de la nemesis
232235	capacete de la nemesis
232236	guantes de la nemesis
232237	botas de la nemesis
232238	togas de la nemesis
232239	sobrevestes de la nemesis
232240	cordon de la nemesis
232241	hombreras de la nemesis
232242	pantalones de la nemesis
232243	capucha de la nemesis
232244	manoplas de la nemesis
232245	botines de la nemesis
232246	atuendo de la nemesis
232247	brazales de colera
232248	cinturon de colera
232249	sobrehombros de colera
232250	quijotes de colera
232251	yelmo de colera
232252	guanteletes de colera
232253	grebas de colera
232254	coraza de colera
232255	guardamunecas de colera
232256	guardarrenes de colera
232257	espaldares de colera
232258	musleras de colera
232259	visera de colera
232260	manoplas de colera
232261	escarpes de colera
232262	coselete de colera
232299	defensor zulian
232309	conducto de alma de renataki
232310	conducto de alma de renataki
232311	capa de pellejo de tigre zulian
232312	sangre del iluminado
232324	silbato de aves
232344	vick s vip pass
232357	vengador draconico
232358	relicario vacio
232373	ojo de sulfuras refinado
232389	tratado sobre abundancia
232390	idolo de enfoque celestial
232391	idolo de enfoque felino
232392	totem de trueno implacable
232409	totem de los elementos
232414	sable dracodente
232416	totem de flujo astral
232419	totem de corrientes conductoras
232420	tratado sobre colera
232421	tratado sobre revancha
232423	idolo de nutricion
232424	idolo de crueldad
232433	venda de pano runico denso
232434	manual venda de pano runico denso
232436	sopa de pinza oscura
232437	receta sopa de pinza oscura
232438	branquirrojo ahumado
232443	receta branquirrojo ahumado
232454	emblema de los dioses salvajes
232455	emblema de deshonor
232456	emblema de el ojo violeta
232457	emblema de nucleo de mundo
232458	runa de santuario mejorado
232459	runa de explosion de humo
232460	runa de desplazamiento
232461	runa de desesperacion
232462	runa de poder purificador
232549	informe de tareas logisticas vi
232550	ashkandi espada magna de la hermandad
232551	gran maza draconica
232552	lok amir il romathis
232555	crul shorukh filo del caos
232556	baston de la llama de las sombras
232557	garra de chromaggus
232558	espada templada cromaticamente
232559	heraldo de tragedia
232561	garra del draco negro
232562	cuchilla de garfa de draco
232563	baston de enfoque de alasombra
232564	maladath hoja runica del vuelo negro
232565	hoja colmillo dragon
232566	la espada indomable
232567	machacapuas
232576	vengador draconico
232577	filo de la fatalidad
232606	ashjre thul ballesta de paliza
232607	apuntacorazones
232608	culebrina aliento de dragon
232610	formula lustre trol magnifico
232611	lustre trol magnifico
232652	zila amanemodas
233197	manual de entrenamiento argenta
233198	cuerno del alba
233200	semilla cantaflor
233201	globo fulgurante
233206	yunque de sobrestante
233208	bola 8 magica defectuosa
233209	caldero de aguardiente
233211	caracola espiritual
233213	magnetita antigua
233215	trampa de arena explosiva
233216	rayo congelamatico
233217	incienso de tunelador
233226	antigua cuerda zandalariana
233250	rama antigua
233351	cristal resonador qiraji verde claro
233352	cristal resonador qiraji azul oscuro
233353	cristal resonador qiraji celeste
233356	cristal resonador qiraji naranja
233357	cristal resonador qiraji crepuscular
233358	tanque silitido domado
233362	coraza del dios antiguo
233363	caparazon del dios antiguo
233364	piel del dios antiguo
233365	visceras intactas
233367	peritoneo intacto
233368	entranas intactas
233369	ataduras de dominancia qiraji
233370	ataduras de mando qiraji
233371	ataduras de soberania qiraji
233372	grebas de conquistador
233373	coraza de conquistador
233374	musleras de conquistador
233375	corona de conquistador
233376	bufas de conquistador
233377	borceguies de clamacondenas
233378	calzas de clamacondenas
233379	manto clamacondenas
233380	togas de clamacondenas
233381	aro de clamacondenas
233382	leotardos de clamatormentas
233383	espaldares de clamatormentas
233384	guardapies de clamatormentas
233385	diadema de clamatormentas
233386	camisote de clamatormentas
233387	bufas de mortifero
233388	yelmo de mortifero
233389	jubon de mortifero
233390	leotardos de mortifero
233391	botas de mortifero
233392	borceguies del oraculo
233393	tiara del oraculo
233394	manto del oraculo
233395	vestimentas del oraculo
233396	calzas del oraculo
233397	coraza del vengador
233398	corona del vengador
233399	grebas del vengador
233400	musleras del vengador
233401	espaldares del vengador
233402	togas enigma
233403	hombreras enigma
233404	aro enigma
233405	botas enigma
233406	leotardos enigma
233407	guardapies de asediador
233408	leotardos de asediador
233409	espaldares de asediador
233410	diadema de asediador
233411	camisote de asediador
233412	yelmo genesis
233413	hombreras genesis
233414	botas genesis
233415	jubon genesis
233416	calzas genesis
233417	maza de vida inagotable
233418	capa de vida inagotable
233419	sortija de vida inagotable
233420	capa de la senda oculta
233421	guadana de la senda oculta
233422	sello de la senda oculta
233423	hoja de secretos oscuros
233424	manton de secretos oscuros
233425	sortija de secretos oscuros
233426	hoja de justicia eterna
233427	manteo de justicia eterna
233428	anillo de justicia eterna
233429	mazo de sabiduria infinita
233430	embozo de sabiduria infinita
233431	anillo de sabiduria infinita
233432	capa de las sombras ocultas
233433	daga de las sombras ocultas
233434	sortija de las sombras ocultas
233435	martillo de la tormenta inminente
233436	capa de la tormenta inminente
233437	anillo de la tormenta inminente
233438	embozo de los nombres prohibidos
233439	kris de los nombres prohibidos
233440	anillo de los nombres prohibidos
233441	manton de fuerza implacable
233442	hoz de fuerza implacable
233443	sello de fuerza implacable
233490	adalid de obsidiana
233491	atracadora de obsidiana
233492	placa de batalla filoespina
233496	sobrehombros de bombardeo
233502	amuleto de guarda del mal
233503	colgante del guardian qiraji
233504	capa de odio concentrado
233505	leotardos de inmersion
233506	guardamunecas escamados de alfazaques
233507	anillo de enjambre de pensamientos
233509	baston de los profetas qiraji
233514	botas de la voluntad inquebrantable
233515	martillo de ji zhi
233516	coraza de aniquilacion
233517	botas de la profecia cumplida
233518	botas del profeta caido
233519	manteo de la trinidad
233520	togas del triunvirato
233521	manto ternario
233522	apariencia del devorador
233523	faja de triada
233524	toque de angelista
233559	guantes de ebru
233560	guanteletes de moco
233561	botas del heroe caido
233562	talisman de angelista
233563	manto de poder frenico
233564	guanteletes cubiertos de bilis
233565	anillo de oscuridad de ukko
233566	manto de la furia del desierto
233567	manto de la cruzada del desierto
233568	jubon de ejecucion presto
233569	anillo de los devorados
233570	escarabajo petrificado
233571	varita de nobleza qiraji
233572	collar de pureza
233573	botas recompuestas
233574	leotardos del enjambre ulceroso
233575	togas del guardia de batalla
233576	garra de silitido
233577	cinturon de pellejo qiraji grueso
233578	yelmo parra reptadora
233579	guantes de aplicacion
233580	distintivo del guardaenjambres
233581	poderio de sartura
233582	guanteletes de determinacion ferrea
233583	quijotes de luz llameantes
233584	leotardos escamados de furia qiraji
233585	destripador qiraji antiguo
233586	mandibula del atracador de arena
233587	gargantilla de puas
233588	capa de los secretos ocultos
233589	fetiche del atracador de arena
233590	botas de tunelador de colmena
233591	coselete caparazon de silitido
233592	manto de la revancha horrenda
233593	espaldares del inflexible
233594	togas del santo guardian
233595	leotardos escamados de atracador de arena
233596	tratado sobre purificacion
233597	totem de vida
233598	leotardos cubiertos de baba
233599	femur de silitido afilado
233600	anillo de furia qiraji
233601	broche escarabajo
233602	idolo de salud
233603	guanteletes de campeon recto
233604	guanteletes de kalimdor
233605	aguijon de huhuran
233606	capa de la colmena dorada
233607	guantes del mesias
233608	guanteletes de pellejo de avispa
233609	anillo del martir
233610	guardamunecas de colmena rapinador
233611	botas de epifania
233612	brazales qiraji de ejecucion
233613	guantes de devastacion de vek lor
233614	cinturon qiraji real
233615	anillo del emperador vek lor
233616	cetro real de vek lor
233617	pulseras de redencion real
233618	guantes del templo oculto
233619	cinturon regenerador de vek nilash
233620	amuleto de vek nilash
233621	revancha de kalimdor
233622	garra del emperador caido
233623	cinturon del emperador caido
233624	sombrero perdido de don rigoberto
233625	brazales de escarbador
233626	larva del gran gusano
233627	jom gabbar
233628	la coraza del perforador
233629	bloqueador de escamas de gusano
233630	capa de los devorados
233631	guanteletes de tormenta oscura
233632	garra del dios antiguo
233633	cordon cinturon acecha ojos
233634	aguijon de la muerte
233635	cinturon de agonia interminable
233636	cetro del falso profeta
233637	guanteletes de aniquilacion
233638	anillo del destripadioses
233639	tentaculo derrotado de c thun
233640	filo oscuro de la locura
233641	capa de claridad
233642	marca de c thun
233643	martillo de guerra anubisath
233644	atuendo de ascension real
233645	guantes del inmortal
233646	guantes de la profecia redimida
233647	neretzek la sedienta de sangre
233648	anillo de caos de ritssyn
233649	fragmento de la estrella caida
233651	loriga de conquistador
233652	escarpes de conquistador
233653	yelmo de conquistador
233654	escarcelas de conquistador
233658	espaldares de conquistador
233659	coselete de mortifero
233660	botines de mortifero
233661	visor de mortifero
233662	pantalones de mortifero
233663	espaldares de mortifero
233664	cota guarnecida de asediador
233665	botines de asediador
233666	visor de asediador
233667	quijotes de anillas de asediador
233668	bufas de asediador
233669	protegecabezas de clamacondenas
233670	atuendo de clamacondenas
233671	hombreras de clamacondenas
233672	pantalones de clamacondenas
233673	botines de clamacondenas
233674	pantalones enigma
233675	zapatillas enigma
233676	diadema enigma
233677	manto enigma
233678	atuendo enigma
233679	leotardos del oraculo
233680	togas del oraculo
233681	hombreras del oraculo
233682	corona del oraculo
233683	zapatillas del oraculo
233684	manto del vengador
233685	pantalones de placas del vengador
233686	botines del vengador
233687	yelmo del vengador
233688	loriga del vengador
233689	bufas del vengador
233690	escarcelas del vengador
233691	escarpes del vengador
233692	gran yelmo del vengador
233693	coselete del vengador
233694	coselete de clamatormentas
233695	visera de clamatormentas
233696	escarpes de clamatormentas
233697	bufas de clamatormentas
233698	quijotes de clamatormentas
233699	coraza de clamatormentas
233700	corona de clamatormentas
233701	botines de clamatormentas
233702	manto de clamatormentas
233703	leotardos de anillas de clamatormentas
233704	abrazo de clamatormentas
233705	ornato de clamatormentas
233706	grebas de clamatormentas
233707	cubrehombros de clamatormentas
233708	leotardos de malla de clamatormentas
233709	capucha genesis
233710	pantalones de cuero genesis
233711	armadura genesis
233712	apisonadoras genesis
233713	bufas genesis
233714	leotardos genesis
233715	cueros genesis
233716	botines genesis
233717	manto genesis
233718	ornato genesis
233719	calzones genesis
233720	coselete genesis
233721	grebas genesis
233722	espaldares genesis
233723	mascara genesis
233724	faja de placas aguerrida
233725	faja de placas aguerrida
233726	guardabrazos de placas aguerridos
233727	guardabrazos de placas aguerridos
233728	insignia cubierta de sangre
233729	gargantilla cubierta de sangre
233730	talisman cubierto de sangre
233731	amuleto cubierto de sangre
233732	collar cubierto de sangre
233733	anillo cubierto de sangre
233734	circulo cubierto de sangre
233735	aro cubierto de sangre
233736	sortija cubierta de sangre
233737	capa cubierta de sangre
233738	manteo cubierto de sangre
233739	manton cubierto de sangre
233740	embozo cubierto de sangre
233741	cinturon de laminas aguerrido
233742	guardabrazos de laminas aguerridos
233743	munequeras de laminas aguerridas
233744	cordon de laminas aguerrido
233745	pretina de malla aguerrida
233746	cordon de malla aguerrido
233747	cinturon de malla aguerrido
233748	brazales de malla aguerridos
233749	guardamunecas de malla aguerridos
233750	avambrazos de malla aguerridos
233751	faja de anillas aguerrida
233752	faja de anillas aguerrida
233753	cinturon de anillas aguerrido
233754	cinturon de anillas aguerrido
233755	guardamunecas de anillas aguerridos
233756	guardamunecas de anillas aguerridos
233757	brazales de anillas aguerridos
233758	brazales de anillas aguerridos
233759	brazales de pellejo de dragon aguerridos
233760	brazales de pellejo de dragon aguerridos
233761	cinturon de pellejo de dragon aguerrido
233762	cinturon de pellejo de dragon aguerrido
233763	guardarrenes de pellejo de dragon aguerrido
233764	guardarrenes de pellejo de dragon aguerrido
233765	cordon de pellejo de dragon aguerrido
233766	cordon de pellejo de dragon aguerrido
233767	munequeras de pellejo de dragon aguerridas
233768	munequeras de pellejo de dragon aguerridas
233769	bandas de pellejo de dragon aguerridas
233770	bandas de pellejo de dragon aguerridas
233771	faja de cuero aguerrida
233772	faja de cuero aguerrida
233773	braquiales de cuero aguerridos
233774	braquiales de cuero aguerridos
233775	punos de seda aguerridos
233776	punos de seda aguerridos
233777	fajin de seda aguerrido
233778	fajin de seda aguerrido
233779	brazales de saten aguerridos
233780	brazales de saten aguerridos
233781	munequeras de saten aguerridas
233782	munequeras de saten aguerridas
233783	fajin de saten aguerrido
233784	fajin de saten aguerrido
233785	cincha de saten aguerrida
233786	cincha de saten aguerrida
233787	punos de tejido de tinieblas aguerridos
233788	punos de tejido de tinieblas aguerridos
233789	cinturon de tejido de tinieblas aguerrido
233790	cinturon de tejido de tinieblas aguerrido
233791	moneda de cobre cubierta de sangre
233793	hombreras de placas filoespina
233795	jaula de cabeza filoespina
233796	destructora de obsidiana
233797	martillo de tormenta de obsidiana
233798	hoja sabia de obsidiana
233801	defensora de obsidiana
233802	refuerzo para armadura de quitina resplandeciente
233803	refuerzo para armadura de quitina afilada
233804	hombreras zarzafilo
233808	capucha zarzafilo
233813	cueros zarzafilo
233826	capucha vampirica
233833	chal vampirico
233837	toga vampirica
233956	bufanda de seda qiraji
233958	manteo de seda qiraji
233959	capa de seda qiraji
233960	manton de seda qiraji
233962	frasco de locura
233964	frasco de conocimiento antiguo
233965	frasco de los dioses antiguos
233966	frasco de pena implacable
233967	elixir del tejon mielero
233968	elixir del senor de la magia
233969	elixir de los ladoferreo
233977	elixir de prontitud
233984	megabomba arcana
233985	el fumigador
233986	bomba de obsidiana
233987	generador bu3n 4 0nd4
233988	disco reactivo a la fuerza mejorado
233990	piedra de velocidad
233991	lagrima de la sonadora
233992	magnetita de represalia
233993	cronometro encantado
233994	broche con rubi incrustado
233995	pergamino colera del enjambre
233996	repelente encantado
233997	formula encantar pechera estadisticas de vida
233998	formula encantar guantes poder sagrado
233999	formula encantar guantes poder arcano
234000	tomo de rezo encantado
234001	totem encantado
234002	champinon encantado
234003	barra de torio de infusion obsidiana
234004	piedra de pulir de obsidiana
234005	polvora densa de obsidiana
234006	quitina de silitido monstruosa
234007	quitina de silitido con puas
234008	seda qiraji
234009	madeja de seda qiraji
234010	bilis de gusano de arena antiguo
234011	veneno de acechador qiraji
234012	cardo de colmena
234016	sello del vuelo bronce
234017	sello del vuelo bronce
234018	sello del vuelo bronce
234019	sello del vuelo bronce
234020	sello del vuelo bronce
234021	sello del vuelo bronce
234022	sello del vuelo bronce
234023	sello del vuelo bronce
234024	sello del vuelo bronce
234025	sello del vuelo bronce
234026	sello del vuelo bronce
234027	sello del vuelo bronce
234028	sello del vuelo bronce
234029	sello del vuelo bronce
234030	sello del vuelo bronce
234031	sello del vuelo bronce
234032	sello del vuelo bronce
234033	sello del vuelo bronce
234034	sello del vuelo bronce
234035	sello del vuelo bronce
234061	daga qiraji de sacrificios
234062	vestimentas del mar de dunas
234063	cinturon del atracador de arena
234064	cinturon de la inquisicion
234065	guardamunecas de atracador de arena
234066	guantes de pellejo de silitido fortalecido
234067	destripahombres de los qiraji
234068	botas de la soldado de caballeria
234069	botas del general qiraji
234070	brazales de orden qiraji
234071	quijotes del comando qiraji
234072	garra viento del sur
234073	turbante viento polvoriento
234075	guanteletes del inamovible
234076	garfa de concentracion de furia
234077	coselete de silitido grueso
234078	guardahombros de quitina
234079	capa del salvador
234080	ojo de moam
234081	guanteletes de viento del sur
234082	manto de maz nadir
234083	anillo de furia
234084	yelmo viento del sur
234085	diseno garra negra del destructor
234086	garra negra del destructor
234087	leotardos escamados de obsidiana
234088	quijotes del destructor
234089	trozo de la calavera de buru
234090	guantes del enjambre
234091	guanteletes escamados babosos
234092	fetiche de pinchos de quitina
234093	botas de arenas movedizas
234094	brazales escamados del gloton
234095	chanclos para babosas
234096	arco de tendon tenso
234097	aguijon de ayamiss
234098	botas del protector del desierto
234099	botas de las arenas igneas
234100	yelmo de recrecimiento
234101	anillo de los vientos del desierto
234102	guanteletes de silitido escamados
234103	brazales de brutalidad
234104	ballesta de fatalidad inminente
234105	guanteletes de nueva vida
234106	guantes de sabiduria oscura
234107	yelmo de dominacion
234108	leotardos de la ventisca negra
234109	manto de los horusath
234110	brazal de osirio
234111	sobrehombros de piedra runica
234112	martillo pulido con arena
234113	capa tormenta de arena
234114	grilletes del sinmarcas
234115	baston de las ruinas
234116	furia del enjambre olvidado
234117	botines de nomada errante
234118	mazo de autoridad qiraji
234119	antena de tonificacion
234120	yelmo del vengador sagrado
234121	lanzacoraza de silitido
234122	el kris perdido de zedd
234123	almofar de furia elemental
234124	vademecum de veneno oculto ii
234129	leotardos incrustados de onice
234130	amuleto de escudo de las sombras
234132	collar de dientes de draco
234133	botas de esclavo
234134	turbante de poderio psiquico gnomico
234135	sortija de prolavades heladas
234136	togas aguaoscura
234137	colmillo de korialstrasz
234138	pena de cantosombrio
234139	legado de cresta cuervo
234141	espada runica de los rojos
234142	elixir sin fondo de tragonublo
234143	globo de engano
234144	incensario del falso profeta
234145	presea hakkari cubierta de sangre
234146	grebas con inscripciones de acido
234147	antiguos leotardos corroidos
234148	guardamunecas de hueso de dragon
234149	brazaletes de espuelas de dragon
234150	guantes de poder ilusorio
234151	capa de piel de dragon verde
234152	martillo de furia bestial
234153	baston de crecimiento desenfrenado
234154	piedra de trance
234155	sello de malfurion
234156	botas de la llanura eterna
234157	aro de suenos inquietos
234158	collar de corazon de dragon
234159	ballesta de maderaferrea pulida
234160	anillo del inerte
234161	cinturon de la cienaga oscura
234162	braciles de corteza negra
234163	pantalones de corazon oscuro
234164	almete crecimiento descarriado
234165	guanteletes de la luz brillante
234166	guardapies malignos
234167	botas de miedo
234168	zapatillas de mendigo
234169	sortija de lagrima mental
234170	hoja pesadilla
234171	bufas de cuero artificial
234172	colmillo dragon esmeralda
234173	leotardos de la mente demente
234174	espaldares con inscripciones de acido
234175	cristal de hibernacion
234176	naipe de la luna negra heroismo
234177	naipe de la luna negra dragon azul
234178	naipe de la luna negra la voragine
234179	naipe de la luna negra el vacio abisal
234180	bengala temporal
234181	diario de cultor crepuscular
234198	sello del vuelo bronce
234199	sello del vuelo bronce
234200	sello del vuelo bronce
234201	sello del vuelo bronce
234202	sello del vuelo bronce
234220	diseno jaula de cabeza filoespina
234221	diseno hombreras de placas filoespina
234222	diseno placa de batalla filoespina
234223	diseno atracadora de obsidiana
234224	diseno adalid de obsidiana
234225	diseno destructora de obsidiana
234226	diseno martillo de tormenta de obsidiana
234227	diseno hoja sabia de obsidiana
234228	diseno defensora de obsidiana
234235	patron refuerzo para armadura de quitina resplandeciente
234236	patron refuerzo para armadura de quitina afilada
234237	patron capucha zarzafilo
234238	patron hombreras zarzafilo
234239	patron cueros zarzafilo
234240	patron capucha vampirica
234241	patron chal vampirico
234242	patron toga vampirica
234244	patron bufanda de seda qiraji
234249	patron manteo de seda qiraji
234250	patron capa de seda qiraji
234251	patron manton de seda qiraji
234252	receta frasco de pena implacable
234253	receta frasco de conocimiento antiguo
234255	receta frasco de los dioses antiguos
234256	receta frasco de locura
234257	receta elixir del tejon mielero
234258	receta elixir del senor de la magia
234259	receta elixir de los ladoferreo
234260	receta elixir de prontitud
234261	esquema megabomba arcana
234262	esquema el fumigador
234263	esquema bomba de obsidiana
234264	esquema generador bu3n 4 0nd4
234265	esquema disco reactivo a la fuerza mejorado
234266	formula piedra de velocidad
234267	formula lagrima de la sonadora
234268	formula magnetita de represalia
234269	formula cronometro encantado
234270	formula broche con rubi incrustado
234271	formula pergamino colera del enjambre
234272	formula repelente encantado
234275	formula tomo de rezo encantado
234276	formula totem encantado
234277	formula champinon encantado
234278	manual barra de torio fundida con infusion de obsidiana
234279	diseno piedra de pulir de obsidiana
234280	esquema polvora densa de obsidiana
234288	cinturon parraferrea
234289	diseno cinturon parraferrea
234290	guantes parraferrea
234291	diseno guantes parraferrea
234292	coraza parraferrea
234293	diseno coraza parraferrea
234294	brazales acecharenas
234295	patron brazales acecharenas
234296	guanteletes acecharenas
234297	patron guanteletes acecharenas
234298	coraza acecharenas
234299	patron coraza acecharenas
234300	brazales escupefuego
234301	patron brazales escupefuego
234302	guanteletes escupefuego
234303	patron guanteletes escupefuego
234304	coraza escupefuego
234305	patron coraza escupefuego
234306	cinturon zarzal
234307	patron cinturon zarzal
234308	botas zarzal
234309	patron botas zarzal
234310	yelmo zarzal
234311	patron yelmo zarzal
234312	sobrehombros nemorosos
234314	patron sobrehombros nemorosos
234315	corona nemorosa
234316	patron corona nemorosa
234317	jubon nemoroso
234318	patron jubon nemoroso
234319	cinturon de obsidiana pesado
234320	diseno cinturon de obsidiana pesado
234321	cinturon de obsidiana ligero
234322	diseno cinturon de obsidiana ligero
234324	coraza de escamas oniricas
234325	patron coraza de escamas oniricas
234428	buscacorazones de obsidiana
234429	diseno buscacorazones de obsidiana
234434	escopeta de obsidiana
234435	esquema escopeta de obsidiana
234436	sello del vuelo bronce
234437	sello del vuelo bronce
234438	sello del vuelo bronce
234439	sello del vuelo bronce
234440	sello del vuelo bronce
234444	veneno oculto ii
234445	patron madeja de seda qiraji
234447	vara de transformacion de burbujas
234458	diseno escudo dentado de obsidiana
234459	escudo dentado de obsidiana
234460	guerrera de malla de obsidiana
234461	diseno guerrera de malla de obsidiana
234462	golpe de tierra
234463	colera de cenarius
234464	vara de burbujas de burbujas
234465	riendas del tigre espectral presto
234467	vara de dragones de burbujas
234468	idolo de poder osuno
234469	idolo de ferocidad felina
234474	idolo de ira sideral
234475	tratado sobre el exorcista
234476	tratado sobre santidad
234477	tratado sobre rectitud
234478	totem de los golpes estruendosos
234479	totem de magma fluido
234480	totem de trueno piroclastico
234481	patron falda de escamas oniricas
234482	falda de escamas oniricas
234483	patron brazales de escamas oniricas
234484	brazales de escamas oniricas
234485	mitones de escamas oniricas
234486	patron mitones de escamas oniricas
234487	visor de escamas oniricas
234488	diseno visor de escamas oniricas
234542	espada magna de gran senor de la guerra
234543	hacha de batalla de gran senor de la guerra
234545	pulverizador de gran senor de la guerra
234546	destructora de gran senor de la guerra
234547	pica de jabalies de gran senor de la guerra
234548	atizador de jabalies de gran senor de la guerra
234549	baston de guerra de gran senor de la guerra
234550	hoja de hechizo de gran senor de la guerra
234551	maza de batalla de gran senor de la guerra
234552	hoja de gran senor de la guerra
234553	hoja rauda de gran senor de la guerra
234554	cuchilla de gran senor de la guerra
234555	cachiporra de gran senor de la guerra
234556	navaja de gran senor de la guerra
234557	garra derecha de gran senor de la guerra
234558	garra izquierda de gran senor de la guerra
234559	arco corvo de gran senor de la guerra
234560	ballesta de gran senor de la guerra
234561	barrecaminos de gran senor de la guerra
234562	escudo muro de gran senor de la guerra
234563	escrito sobre destruccion de gran senor de la guerra
234564	escrito sobre alivio de gran senor de la guerra
234565	mandoble de gran mariscal
234566	taladora de gran mariscal
234567	martillo de batalla de gran mariscal
234568	demoledor de gran mariscal
234569	guja de gran mariscal
234570	arma de asta de gran mariscal
234571	baculo de gran mariscal
234574	hoja de mago de gran mariscal
234576	martillo de guerra de gran mariscal
234578	tizona de gran mariscal
234579	hoja presta de gran mariscal
234580	hacha de mano de gran mariscal
234581	castigadora de gran mariscal
234582	puntilla de gran mariscal
234583	hoja de mano derecha de gran mariscal
234584	hoja de mano izquierda de gran mariscal
234585	disparo certero de gran mariscal
234586	ballesta de repeticion de gran mariscal
234587	culebrina de gran mariscal
234588	egida de gran mariscal
234589	escrito sobre poder de gran mariscal
234590	escrito sobre restauracion de gran mariscal
234614	emblema tocado por el vacio
234650	destripador qiraji antiguo
234747	puno de cenarius
234748	brazales de roca profunda
234749	orbe calmaterra
234760	brazales de furia de roca
234761	poderio de cenarius
234779	gracia de la tierra
234780	sortija de poder terraneo
234782	jubon poder terrenal
234785	guantes de poder de la tierra
234786	sortija de colera de tierra
234788	capa de tejido de tierra
234792	cercenadora ravenholdt
234793	chafarote de shivsprocket
234797	el atizador truenedera
234798	prima de condemulus
234799	ballesta de repeticion de recarga de fahrad
234800	martillo de cultivo de simone
234801	amuleto del dios caido
234802	capa del dios caido
234803	anillo del dios caido
234804	hacha de guerra qiraji bendita
234805	mosquete qiraji bendito
234806	pugio qiraji bendito
234807	baluarte qiraji bendito
234808	baston de acolito qiraji bendito
234809	baston de augur qiraji bendito
234810	martillo de guerra qiraji bendito
234811	talisman del mar de dunas
234812	amuleto del mar de dunas
234813	gargantilla del mar de dunas
234814	colgante del mar de dunas
234960	riendas del tigre cubierto de sangre
234961	silbato del raptor cubierto de sangre
234962	vestimentas decoradas con jade
234963	quijotes con extranas inscripciones
234964	sello del vuelo bronce
234965	sello del vuelo bronce
234966	sello del vuelo bronce
234967	sello del vuelo bronce
234968	sello del vuelo bronce
234974	baston de los profetas qiraji
234975	martillo de ji zhi
234976	varita de nobleza qiraji
234977	garra de silitido
234978	mandibula del atracador de arena
234979	femur de silitido afilado
234980	aguijon de huhuran
234981	revancha de kalimdor
234983	larva del gran gusano
234984	aguijon de la muerte
234985	filo oscuro de la locura
234986	martillo de guerra anubisath
234987	neretzek la sedienta de sangre
234989	daga qiraji de sacrificios
234990	destripahombres de los qiraji
234991	arco de tendon tenso
234992	aguijon de ayamiss
234993	ballesta de fatalidad inminente
234994	martillo pulido con arena
234995	baston de las ruinas
234996	mazo de autoridad qiraji
234997	lanzacoraza de silitido
234998	el kris perdido de zedd
234999	martillo de guerra qiraji bendito
235000	baston de augur qiraji bendito
235001	baston de acolito qiraji bendito
235002	pugio qiraji bendito
235003	hacha de guerra qiraji bendita
235004	mosquete qiraji bendito
235005	hoz de fuerza implacable
235006	daga de las sombras ocultas
235007	guadana de la senda oculta
235008	kris de los nombres prohibidos
235009	martillo de la tormenta inminente
235010	mazo de sabiduria infinita
235011	hoja de justicia eterna
235012	maza de vida inagotable
235013	hoja de secretos oscuros
235014	cetro del falso profeta
235039	diseno coraza gruesa de obsidiana
235040	coraza gruesa de obsidiana
235045	atavio imperial qiraji
235046	armamentos imperiales qiraji
235047	guantes del profeta caido
235048	cabeza de osirio el sinmarcas
235049	objeto envuelto en pesadillas
235133	formula tratado sobre rectitud
235134	formula tratado sobre el exorcista
235135	formula tratado sobre santidad
235136	formula totem de trueno piroclastico
235137	formula totem de los golpes estruendosos
235138	formula totem de magma fluido
235139	formula idolo de ira sideral
235140	formula idolo de ferocidad felina
235141	formula idolo de poder osuno
235142	moneda de plata cubierta de sangre
235143	moneda de oro cubierta de sangre
235144	cartera de monedas de cobre cubiertas de sangre
235145	cartera de monedas de plata cubiertas de sangre
235275	baraja de portales
235276	baraja de elementales
235277	baraja de senores de la guerra
235278	baraja de bestias
235282	antena de tonificacion
235473	barricada de gran mariscal
235474	barricada de gran senor de la guerra
235476	rebanadora de gran senor de la guerra
235477	partehuesos de gran senor de la guerra
235478	chafarote de gran senor de la guerra
235479	chafarote de gran mariscal
235480	partehuesos de gran mariscal
235481	rebanadora de gran mariscal
235497	jarabe de las arenas
235511	cristal resonador qiraji amarillo impecable
235512	cristal resonador qiraji verde impecable
235513	cristal resonador qiraji azul impecable
235514	cristal resonador qiraji rojo impecable
235517	antorcha
235526	formula encantar brazales poder de hechizos
235528	formula encantar brazales agilidad
235529	mira de obsidiana
235530	esquema mira de obsidiana
235597	notas de hechizo congelacion profunda
235598	notas de hechizo venas heladas
235599	notas de hechizo anomalia temporal
235600	runa de tormenta divina
235601	runa de fanatismo
235602	runa de martillo del honrado
235603	runa de venganza recta
235604	runa de escudo de rectitud
235605	runa de choque y terror
235785	llave de jaula de paso de la muerte
235786	curiosidad de karazhan
235787	rama de maderaferrea antigua
235788	fuego fatuo entusiasta
235789	llama de la vida
235790	marca de fuego encantada
235825	jarabe de las arenas
235852	cartera violeta
235867	trozo de papiro
235868	baluarte de ira
235869	la capucha del maestro
235870	yelmo de anillas ruidosas
235871	yelmo de la muerte cenido
235872	braciles de acechador
235873	esposas de la cripta
235874	manijas de cultista
235875	guantes de cavatumbas
235876	manoplas de pecador
235877	guanteletes de fanatico
235878	cinturon malefico
235879	anillas agiles
235880	suelas indigentes
235881	botines aterradores
235882	pasos traqueteantes
235883	escarpin de explorapozos
235884	sello espectral
235885	anillo espantoso
235886	broche de kaigy
235887	gargantilla de barian
235888	garrote aporreador
235889	cayado de sirviente
235890	aguja de tejesombras
235891	vieja confiable
235892	columna de jinete oscuro
235893	grimorio vinculasombras
235894	obito del orador del sino
236002	lista de componentes
236005	coraza acorator
236006	quijotes acorator
236007	casco acorator
236008	espaldares acorator
236009	escarpes acorator
236010	guanteletes acorator
236011	guardarrenes acorator
236012	brazales acorator
236013	anillo del acorator
236014	loriga acorator
236015	escarcelas acorator
236016	cuernos acorator
236017	sobrehombros acorator
236018	grebas acorator
236019	mandiletes acorator
236020	cinturon acorator
236021	munequeras acorator
236022	sortija del acorator
236023	coraza segahuesos
236024	quijotes segahuesos
236025	casco segahuesos
236026	espaldares segahuesos
236027	escarpes segahuesos
236028	guanteletes segahuesos
236029	guardarrenes segahuesos
236030	brazales segahuesos
236031	anillo segahuesos
236032	cinturon segahuesos
236033	botines segahuesos
236034	sortija segahuesos
236035	manto segahuesos
236036	leotardos segahuesos
236037	mascara segahuesos
236038	mandiletes segahuesos
236039	coselete segahuesos
236040	guardamunecas segahuesos
236041	anillo de acechacriptas
236042	guardamunecas de acechacriptas
236043	guerrera de acechacriptas
236044	bufas de acechacriptas
236045	musleras de acechacriptas
236046	celada de acechacriptas
236047	manoplas de acechacriptas
236048	faja de acechacriptas
236049	botas de acechacriptas
236050	avambrazos de acechacriptas
236051	cinturon de acechacriptas
236052	espaldares de acechacriptas
236053	leotardos de acechacriptas
236054	visor de acechacriptas
236055	guanteletes de acechacriptas
236056	sortija de acechacriptas
236057	grebas de acechacriptas
236058	coraza de acechacriptas
236059	botines corazon de peste
236060	leotardos corazon de peste
236061	ataduras corazon de peste
236062	toga corazon de peste
236063	guantes corazon de peste
236064	aro corazon de peste
236065	hombreras corazon de peste
236066	cinturon corazon de peste
236067	anillo corazon de peste
236068	guardamunecas corazon de peste
236069	guardarrenes corazon de peste
236070	manto corazon de peste
236071	pantalones corazon de peste
236072	corona corazon de peste
236073	manoplas corazon de peste
236074	aro corazon de peste
236075	botas corazon de peste
236076	atuendo corazon de peste
236077	ataduras de fuego de escarcha
236078	cinturon de fuego de escarcha
236079	leotardos de fuego de escarcha
236080	botines de fuego de escarcha
236081	toga de fuego de escarcha
236082	guantes de fuego de escarcha
236083	aro de fuego de escarcha
236084	hombreras de fuego de escarcha
236085	anillo de fuego de escarcha
236087	cubremunecas de fuego de escarcha
236088	guardarrenes de fuego de escarcha
236089	manto de fuego de escarcha
236090	pantalones de fuego de escarcha
236091	caperuza de fuego de escarcha
236092	mitones de fuego de escarcha
236093	sortija de fuego de escarcha
236094	botas de fuego de escarcha
236095	atuendo de fuego de escarcha
236097	toga de fe
236098	cinturon de fe
236099	sandalias de fe
236100	ataduras de fe
236101	leotardos de fe
236102	hombreras de fe
236103	diadema de fe
236104	guantes de fe
236105	anillo de fe
236106	munequeras de fe
236107	faja de fe
236108	manto de fe
236109	pantalones de fe
236110	corona de fe
236111	manos de fe
236112	sortija de fe
236113	botas de fe
236114	atuendo de fe
236115	guerrera de redencion
236116	anillo de redencion
236117	celada de redencion
236118	manoplas de redencion
236119	guardamunecas de redencion
236120	faja de redencion
236121	musleras de redencion
236122	bufas de redencion
236123	botas de redencion
236124	avambrazos de redencion
236125	cinturon de redencion
236126	hombreras de placas de redencion
236127	leotardos de redencion
236128	yelmo de redencion
236129	guantes de redencion
236130	sortija de redencion
236131	grebas de redencion
236132	coraza de redencion
236133	brazales de redencion
236134	guardarrenes de redencion
236135	espaldares de redencion
236136	quijotes de redencion
236137	corona de redencion
236138	guanteletes de redencion
236139	aro de redencion
236140	escarpes de redencion
236141	coselete de redencion
236142	manoplas rompeterra
236143	musleras rompeterra
236144	celada rompeterra
236145	bufas rompeterra
236146	botas rompeterra
236147	guerrera rompeterra
236148	faja rompeterra
236149	guardamunecas rompeterra
236150	anillo del trizaterrador
236151	ataduras rompeterra
236152	cordon rompeterra
236153	manto rompeterra
236154	falda rompeterra
236155	corona rompeterra
236156	mitones rompeterra
236157	sortija del trizaterrador
236158	grebas rompeterra
236159	abrazo rompeterra
236160	brazales rompeterra
236162	guardarrenes rompeterra
236163	espaldares rompeterra
236164	quijotes rompeterra
236165	visera rompeterra
236166	guantes rompeterra
236167	aro del trizaterrador
236168	escarpes rompeterra
236169	coselete rompeterra
236170	avambrazos rompeterra
236171	cinturon rompeterra
236172	cubrehombros rompeterra
236173	leotardos rompeterra
236174	casco rompeterra
236175	mandiletes rompeterra
236176	sello del trizaterrador
236177	botines rompeterra
236179	armadura rompeterra
236182	celada caminasuenos
236183	guardamunecas caminasuenos
236184	manoplas caminasuenos
236185	botas caminasuenos
236186	guerrera caminasuenos
236187	faja caminasuenos
236188	musleras caminasuenos
236189	bufas caminasuenos
236190	anillo del caminasuenos
236192	ataduras caminasuenos
236193	cordon caminasuenos
236194	manto caminasuenos
236195	falda caminasuenos
236196	caperuza caminasuenos
236197	mitones caminasuenos
236198	sortija del caminasuenos
236199	sandalias caminasuenos
236200	cueros caminasuenos
236201	brazales caminasuenos
236202	guardarrenes caminasuenos
236203	espaldares caminasuenos
236204	leotardos caminasuenos
236205	ornato caminasuenos
236206	guanteletes caminasuenos
236207	aro del caminasuenos
236208	escarpes caminasuenos
236209	armadura caminasuenos
236210	sobrevestes caminasuenos
236211	fajin caminasuenos
236212	hombreras caminasuenos
236213	calzas caminasuenos
236214	capucha caminasuenos
236215	mandiletes caminasuenos
236216	sello del caminasuenos
236217	apisonadoras caminasuenos
236218	jubon caminasuenos
236219	presagista de la fatalidad
236220	atuendo de necrocaballero
236221	servobrazo mal colocado
236222	guerrera de piel de necrofago
236223	anillo de la llama eterna
236224	rodela estigia
236225	faja de la furia elemental
236226	espaldares de la furia elemental
236227	cinturon del gran cruzado
236228	bufas del gran cruzado
236229	leotardos del gran cruzado
236230	leotardos de la furia elemental
236231	coraza profanada
236232	guardarrenes profanados
236233	guanteletes profanados
236234	escarpes profanados
236235	brazales profanados
236236	casco profanado
236237	espaldares profanados
236238	quijotes profanados
236239	botines profanados
236240	hombreras profanadas
236241	diadema profanada
236242	toga profanada
236243	guantes profanados
236244	cinturon profanado
236245	ataduras profanadas
236246	leotardos profanados
236247	guardamunecas profanados
236248	botas profanadas
236249	celada profanada
236250	manoplas profanadas
236251	guerrera profanada
236252	faja profanada
236253	musleras profanadas
236254	bufas profanadas
236255	guardamunecas de venganza
236256	toque de escarcha
236257	gema de nerubis
236258	capa de seda de demonio de cripta
236259	sortija de plegarias sin respuesta
236260	espaldares deliriohelado
236261	colgante de piedra malicia
236262	hombreras polares
236263	remordimiento de viuda
236264	el abrazo de la viuda
236265	espada de anima
236266	colgante de nombres olvidados
236267	toga tejida con cristal
236268	beso de la arana
236269	colmillo de maexxna
236270	hachuela de hueso partido
236271	tratado sobre luz
236272	capa de la plaga
236273	sortija de lo inevitable
236274	sortija de granizo
236275	corazon gelido de noth
236276	totem de agua corriente
236277	collar de necropsia
236278	ornato glacial
236279	sombrero de preceptor
236280	quijotes de matanza
236281	almofar de escamas heladas
236282	reflejo de loatheb
236283	anillo de fervor espiritual
236284	baston de azufre
236285	el ojo de nerub
236286	sortija de fuerzas antinaturales
236287	division
236288	el portador de peste
236289	capa de sutura
236290	varita de fortunas
236291	sortija de reanimacion
236292	bruma de medianoche
236293	inyector toxico
236294	bufas de escamas heladas
236295	manto glacial
236296	acuerdo con la muerte
236297	el fin de los suenos
236298	manto cubierto de escarcha
236299	mandoble de poderio profano
236300	collera perdida de gluth
236301	compendio de mano de poder
236302	ojo de disminucion
236303	leotardos de polaridad
236304	caja toracica de abominacion con placas
236305	aguja crepuscular
236306	el castigador
236307	velo de eclipse
236308	idolo de longevidad
236309	faja del mentor
236310	varita de la muerte susurrante
236311	sello del defensor caido
236312	iblis hoja del serafin caido
236313	las ataduras del cosechador de almas
236314	botas de desplazamiento
236315	casco polar
236316	collar de sadico
236317	vis era la sacatripas
236318	sello del condenado
236319	leotardos de apocalipsis
236320	calor de perdon
236321	gran maza del cruzado redimido
236322	hilo de alma
236323	temple de la plaga
236324	poder de la plaga
236325	entereza de la plaga
236326	poderio de la plaga
236327	capa de la necropolis
236328	ojo izquierdo de sapphiron
236329	ojo de los muertos
236330	ojo derecho de sapphiron
236331	la esencia contenida de sapphiron
236333	embozo de dominio
236334	blason de destripador
236335	punos del inflexible
236336	la cara de la muerte
236337	glifo de desvio
236338	garra de vermis de escarcha
236339	gressil alba de la ruina
236340	poderio de menethil
236341	el frio voraz
236342	dije iracundo de tempestira
236343	caida del rey
236344	esclavizador nerubiano
236345	gema de inocentes atrapados
236346	buscador de almas
236347	escudo de condena
236348	martillo de el vacio abisal
236349	dedo condena
236350	la filacteria de kel thuzad
236351	marca del campeon
236352	marca del campeon
236354	sello del alba de aspirante
236355	sello del alba de iniciado
236356	sello del alba de escudero
236357	sello del alba de caballero
236358	sello del alba de templario
236360	sello del alba de campeon
236361	sello del alba de vanguardia
236362	sello del alba de cruzado
236363	sello del alba de comandante
236364	sello del alba de alto senor
236374	sello del alba de comandante
236375	sello del alba de alto senor
236376	sello del alba de cruzado
236378	sello del alba de vanguardia
236379	sello del alba de campeon
236380	sello del alba de templario
236382	sello del alba de caballero
236383	sello del alba de escudero
236384	sello del alba de iniciado
236385	sello del alba de aspirante
236386	sello del alba de alto senor
236388	sello del alba de comandante
236389	sello del alba de cruzado
236390	sello del alba de vanguardia
236391	sello del alba de campeon
236392	sello del alba de templario
236393	sello del alba de caballero
236394	sello del alba de escudero
236395	sello del alba de iniciado
236396	sello del alba de aspirante
236397	restos de valor
236398	atiesh gran baculo del guardian
236399	atiesh gran baculo del guardian
236400	atiesh gran baculo del guardian
236401	atiesh gran baculo del guardian
236414	cajon de suministros de minahonda danado
236417	alma del tactico
236418	alma del veterano de guerra
236419	alma del augur de batalla
236420	alma del buscasangre
236421	alma del titan
236422	alma del destructor
236423	alma del lazomortal
236424	alma del sanguinista
236425	alma del bloqueador pristino
236426	alma del salvaje
236427	alma de animosidad
236428	alma del deflector
236429	alma de revancha
236430	alma del incesante
236431	alma del portatruenos
236432	alma del centinela
236433	alma del zurdo
236434	alma del gladiador
236435	alma de la replica
236436	alma del evasivo
236437	alma del toxicologo
236438	alma del verdugo
236439	alma del oportunista
236440	alma del carnicero
236441	alma del fantasma
236442	alma del ladronzuelo
236443	alma del amante de la adrenalina
236444	alma del experto en puyazos
236445	alma del acechador
236446	alma del eficiente
236447	alma del malabarista de cuchillos
236448	alma del maestro de las sombras
236449	alma del equilibrista
236450	alma del camorrista fogueado
236451	alma del cinturon negro
236452	alma del esgrimista
236453	alma del espadachin
236454	alma del sanguinario
236455	alma del transfusionista
236456	alma del refinamiento
236457	alma del exterminador
236458	alma del putrefaccionista
236459	alma del malevolo
236460	alma del sombramante
236461	alma del heraldo del caos
236462	alma del incendiario
236463	alma del pastor infernal
236464	alma del senor demoniaco
236465	alma del exorcista demoniaco
236466	alma del adolorido
236467	alma del anima flamigera
236468	alma del devoracarnes
236469	alma del abisal
236470	alma del natovacio
236471	alma de la hoja umbria
236472	alma del ritualista
236473	alma del propagador de dolor
236474	alma del lider del engano
236475	alma del buscapresas
236476	alma del tirador certero
236477	alma del asaltante agresivo
236478	alma del alternador
236479	alma del toxinologo
236480	alma del cazarrecompensas
236481	alma del as del gatillo
236482	alma del protector de bestias
236483	alma del maestro de canes
236484	alma del domador alfa
236485	alma del montero
236487	alma del retaliador
236488	alma de ecos
236489	alma del azotador letal
236490	alma del cinetico
236491	alma del estratega
236492	alma del golpeador mortal
236493	alma del sanador subito
236494	alma del refinamiento
236495	alma del oficiante
236496	alma del fiel
236497	alma de serendipia
236498	alma del resonante
236499	alma del devoto
236500	alma del arzobispo
236501	alma del penitente
236502	alma del guardian del alma
236503	alma del errante crepuscular
236504	alma del rompementes
236505	alma del mortifero
236506	alma de la fuente espiritual
236507	alma del zelote
236508	alma del profanador implacable
236509	alma del desdenoso
236510	alma del pesteador
236511	alma del reverberante
236512	alma del cronosanador
236513	alma del anhelo temporal
236514	alma del precognoscente
236515	alma del arcanista
236516	alma del cuidador eterno
236517	alma del conjurante
236518	alma del resguardador
236519	alma del abrazo invernal
236520	alma del criomante
236521	alma del evocador
236522	alma del elementalista
236523	alma del armero magico
236524	alma del reavivador
236525	alma de la convergencia ardiente
236526	alma de la llamarada perpetua
236527	alma del piromano
236528	alma del encendedor
236529	alma de la antorcha
236530	alma del bloqueador pristino
236531	alma del guardian de luz
236532	alma del defensor radiante
236533	alma del portaescudos
236534	alma del bastion
236535	alma del expiador
236536	alma del acorazado
236537	alma del guardian
236538	alma del pacificador
236539	alma del refinamiento
236540	alma del ejemplar
236541	alma del inquisidor
236542	alma de soberania
236543	alma del investido
236544	alma del vindicador
236545	alma del altruista
236546	alma del arbitro
236547	alma del portador de sellos
236548	alma del justicar
236549	alma del juez
236550	alma del ascendiente
236551	alma del desquite
236552	alma del excomulgador
236553	alma del iluminado
236554	alma del exilio
236555	alma del templario
236556	alma del viajero del viento
236557	alma del amo del escudo
236558	alma del protector totemico
236559	alma del aplacachoques
236560	alma del baluarte espiritual
236561	alma del empunavoragine
236562	alma del zancalavas
236563	alma del alfa verdadero
236564	alma del guardian de totems
236565	alma de los ancestros
236566	alma del tejespiritus
236567	alma del zancaaguas
236568	alma del velatormentas
236569	alma del vidente elemental
236570	alma del vitalista
236571	alma del sanador espiritual
236572	alma del refinamiento
236573	alma del jefe
236574	alma de carga furiosa
236575	alma del rompetormentas
236576	alma de la tempestad
236577	alma del destructor sismico
236578	alma del clamallamas
236579	alma del volcan
236580	alma de la llama furibunda
236581	alma del maestro elemental
236582	alma del tribal
236583	alma del guia espiritual
236584	alma del ancestro
236585	alma de los elementos
236586	alma del sabio de lava
236587	alma del guardian ancestral
236588	alma del corrupto
236589	alma de pata suave
236590	alma del feroz
236591	alma del cambiaformas
236592	alma del territorial
236593	alma de la bestia
236594	alma del lacerador
236595	alma del furioso
236596	alma del destrozador
236597	alma del estimulador
236598	alma de la fuente de nutricion
236599	alma del sosiego
236600	alma del caminasuenos
236601	alma del cuidador de arboleda
236602	alma del sabio emplumado
236603	alma del vidente benevolente
236604	alma del tejevidas
236605	alma del iluminador
236606	alma de instintos depredadores
236607	alma del destripador
236608	alma de la zarpa
236609	alma de la manada imponente
236610	alma del barbarico
236611	alma del frenetico
236612	alma del desangrador
236613	alma del guardian de espinas
236614	alma del lunatico
236615	alma del llamaestrellas
236616	alma de la noche
236617	alma de los protectores
236618	alma del colerico
236619	alma de gracia salvaje
236620	alma del ascendiente astral
236621	alma del llamacometas
236622	alma del bosque
236623	alma de pericia animal
236642	manijas de ensalmador
236643	guantes de vigia de la noche
236644	manoplas de doliente
236645	guanteletes de esgrimidor de la luz
236656	runa congelada
236657	rama podrida de burbujas
236658	espina de trofeo de burbujas
236660	colmillo trol de burbujas
236661	caja toracica de ribaldy de burbujas
236662	riendas de guerra
236663	riendas de conquista
236664	riendas de muerte
236665	riendas de hambre
236690	capa glacial
236692	guantes glaciales
236693	munequeras glaciales
236694	jubon glacial
236695	coraza deliriohelado
236696	brazales deliriohelado
236697	guanteletes deliriohelado
236698	brazales de escamas heladas
236699	coraza de escamas heladas
236700	guanteletes de escamas heladas
236701	brazales polares
236702	guerrera polar
236703	guantes polares
236704	munequeras escarchadas
236705	guantes escarchados
236706	jubon escarchado
236707	guerrera de matanza de no muertos
236708	coraza de matanza de no muertos
236709	coselete de matanza de no muertos
236710	guardamunecas de matanza de no muertos
236711	cubremunecas de matanza de no muertos
236712	brazales de matanza de no muertos
236713	manijas de matanza de no muertos
236714	guanteletes de matanza de no muertos
236715	manoplas de matanza de no muertos
236716	brazales de eliminacion de no muertos
236717	guantes de eliminacion de no muertos
236718	toga de eliminacion de no muertos
236719	brazales de purificacion de no muertos
236720	guantes de purificacion de no muertos
236721	toga de purificacion de no muertos
236722	brazales de resguardo de no muertos
236723	guantes de resguardo de no muertos
236724	toga de resguardo de no muertos
236725	cubremunecas de eliminacion de no muertos
236726	manijas de eliminacion de no muertos
236727	guerrera de eliminacion de no muertos
236728	cubremunecas de purificacion de no muertos
236729	manijas de purificacion de no muertos
236730	guerrera de purificacion de no muertos
236731	cubremunecas de resguardo de no muertos
236732	manijas de resguardo de no muertos
236733	guerrera de resguardo de no muertos
236734	guardamunecas de eliminacion de no muertos
236735	manoplas de eliminacion de no muertos
236736	coselete de eliminacion de no muertos
236737	guardamunecas de resguardo de no muertos
236738	manoplas de resguardo de no muertos
236739	coselete de resguardo de no muertos
236740	guardamunecas de purificacion de no muertos
236741	manoplas de purificacion de no muertos
236742	coselete de purificacion de no muertos
236743	brazales de purificacion de no muertos
236744	guanteletes de purificacion de no muertos
236745	coraza de purificacion de no muertos
236746	brazales de resguardo de no muertos
236747	guanteletes de resguardo de no muertos
236748	coraza de resguardo de no muertos
236750	corazon de fatalidad
236782	collar de sairuh
236786	corazon de fatalidad
236864	carcaj de escarcha de alma
236869	faltriquera de municion de escarcha de alma
236871	sensores de censura espeluznantes
236872	esquema sensores de censura espeluznantes
236878	reliquia misteriosa
236879	reliquia misteriosa
236880	reliquia misteriosa
237011	llave de compuerta
237020	insignia escarlata
237023	arbusto falso
237024	boleto de la opera
237037	tarjeta de miembro del club alcurnia
237041	tomo de llamarada encantada
237143	ordenes de la comandante
237163	craneo de heroe antiguo
237261	arena fina
237263	bolsa de suministros
237275	casco deliriohelado
237277	leotardos escarchados
237278	el purificador
237279	amuleto del alba
237280	medallon del alba
237281	brazales de esperanza
237282	brazales de subterfugio
237283	dije de ascendiente
237284	bolsa de suministros
237285	sortija de resolucion
237286	sortija de piedad
237287	ultimo recurso de verimonde
237288	yelmo de cuero santificado
237289	leotardos del cazador de peste
237290	leotardos deliriohelado
237291	leotardos glaciales
237292	leotardos polares
237293	leotardos de escamas heladas
237294	garra helada de ramaladni
237302	tabardo de el enclave escarlata
237381	anillo profanado
237386	cajon de suministros de minahonda asolado por la guerra
237504	cargamento de suministros
237512	espada de inquisicion
237577	totem de poderio profano
237773	palabra de deshielo
237810	piedra de afilar consagrada equilibrada
237814	musleras de laminas de centinela
237815	leotardos de seda de centinela
237817	pantalones de pellejo de lagarto
237818	pantalones de cuero de centinela
237819	leotardos de anillas de centinela
237820	leotardos de seda de escolta
237821	pantalones de pellejo de lagarto de escolta
237822	pantalones de cuero de escolta
237823	leotardos de malla de escolta
237824	leotardos de anillas de escolta
237825	musleras de placas de centinela
237826	musleras de placas de escolta
238234	aceite de zahori bendito
238241	piedra de afilar consagrada
238264	caperuza de augur escarlata
238265	manto de augur escarlata
238266	vestimentas de augur escarlata
238267	punos de augur escarlata
238268	mitones de augur escarlata
238269	correa de augur escarlata
238270	leotardos de augur escarlata
238271	suelas de augur escarlata
238272	panuelo de infiltrado escarlata
238273	hombreras de infiltrado escarlata
238274	jubon de infiltrado escarlata
238275	brazales de infiltrado escarlata
238276	guantes de infiltrado escarlata
238277	cinturon de infiltrado escarlata
238278	calzas de infiltrado escarlata
238279	zapatos de infiltrado escarlata
238280	almofar de montero escarlata
238281	espaldares de montero escarlata
238282	anillas de montero escarlata
238283	guardamunecas de montero escarlata
238284	manoplas de montero escarlata
238285	cinto de montero escarlata
238286	musleras de montero escarlata
238287	botas de montero escarlata
238288	yelmo de soldado escarlata
238289	bufas de soldado escarlata
238290	peto de soldado escarlata
238291	protectores de soldado escarlata
238292	mandiletes de soldado escarlata
238293	guardarrenes de soldado escarlata
238294	quijotes de soldado escarlata
238295	apisonadoras de soldado escarlata
238298	patron caperuza de augur escarlata
238299	patron manto de augur escarlata
238300	patron vestimentas de augur escarlata
238301	patron punos de augur escarlata
238302	patron mitones de augur escarlata
238303	patron correa de augur escarlata
238304	patron leotardos de augur escarlata
238305	patron suelas de augur escarlata
238306	patron panuelo de infiltrado escarlata
238307	patron hombreras de infiltrado escarlata
238308	patron jubon de infiltrado escarlata
238309	patron brazales de infiltrado escarlata
238310	patron guantes de infiltrado escarlata
238311	patron cinturon de infiltrado escarlata
238312	patron calzas de infiltrado escarlata
238313	patron zapatos de infiltrado escarlata
238314	patron almofar de montero escarlata
238315	patron espaldares de montero escarlata
238316	patron anillas de montero escarlata
238317	patron guardamunecas de montero escarlata
238318	patron manoplas de montero escarlata
238319	patron cinto de montero escarlata
238320	patron musleras de montero escarlata
238321	patron botas de montero escarlata
238322	diseno yelmo de soldado escarlata
238323	diseno bufas de soldado escarlata
238324	diseno peto de soldado escarlata
238325	diseno protectores de soldado escarlata
238326	diseno mandiletes de soldado escarlata
238327	diseno guardarrenes de soldado escarlata
238328	diseno quijotes de soldado escarlata
238329	diseno apisonadoras de soldado escarlata
238348	el hacha de extirpacion
238349	leotardos de piel de abominacion
238350	daga focal de desden
238351	la garra helada
238352	gargantilla helada de desden
238353	manto de lady falther ess
238354	dedo de lady falther ess
238355	cadenas del exanime
238356	pretina de balzaphon
238357	baston de balzaphon
238358	muslo de bosque negro
238360	rodela de lord bosque negro
238361	hoja de lord bosque negro
238362	brazales de alivio
238363	la garra de las sombras
238364	capa de revanchion
238637	filete de merodeador
238638	filete de lomo
238639	omelette madrugador
238641	festin de motaletas
238642	gran banquete de langostas
238645	receta filete de merodeador
238646	receta filete de lomo
238647	receta omelette madrugador
238649	receta festin de motaletas
238650	receta gran banquete de langostas
238681	bolsa polvorienta
238687	maza de embate
238734	caja de artilugios teletransporte
238735	caja de artilugios nitropropulsores
238736	caja de artilugios desplazamiento magnetico
238737	caja de artilugios
238781	transportador semiseguro nuevo avalon
238782	esquema caja de artilugios
238783	esquema caja de artilugios teletransporte
238784	esquema caja de artilugios nitropropulsores
238785	esquema caja de artilugios desplazamiento magnetico
238786	esquema artilugio teletransporte
238787	esquema artilugio nitropropulsores
238788	esquema artilugio desplazamiento magnetico
238789	esquema transportador semiseguro nuevo avalon
238794	sobras poco apetitosas
238811	manzana jugosa
238830	catalejo de manzanas
238831	cuerda de manzanas
238899	surtido de peces
238925	carcaj escarlata
238926	faltriquera de municion escarlata
238927	patron carcaj escarlata
238928	patron faltriquera de municion escarlata
238935	carne ligeramente putrefacta
238945	caladroca
238960	cajon del intendente
238961	caladbolg
238985	cajon pesado
239010	empunadura de la crematoria
239011	fragmento de luz cristalizada
239012	astilla de luz cristalizada
239013	hacha cristalina
239016	sales sagradas
239017	especias exquisitas
239021	libro de cocina de carrie
239060	voluntad de la montana
239092	sello postal peculiarmente en prosa
239097	llave de la catedral
239117	caliz de cruzado
239119	flecha sagrada
239147	morral de cruzado
239148	bolsa tejida en alba carmesi
239149	patron morral de cruzado
239150	patron bolsa tejida en alba carmesi
239159	s03 scarlet enclave captains shield
239196	hoja forjada con luz arruinada
239197	hoja reforjada de la crematoria
239215	emblema carbonizado
239216	hierro templeluz
239218	notas de tallapiedras
239219	emblema de la crematoria
239222	esquema arbusto falso
239223	casa de utileria
239225	pluma elegante
239246	lista de compras de fundefusibles
239248	caja de trastos escarlata
239292	notas de forjador
239301	crematoria corrupta
239302	cinturon de uniforme escarlata
239316	churumbele de triangulacion
239512	munequeras de rompeluz
239513	cinturon de rompeluz
239514	mandiletes de rompeluz
239515	grebas de rompeluz
239516	sobrehombros de rompeluz
239517	gran yelmo de rompeluz
239518	escarcelas de rompeluz
239519	loriga de rompeluz
239520	brazales de rompeluz
239521	guardarrenes de rompeluz
239522	guanteletes de rompeluz
239523	escarpes de rompeluz
239524	espaldares de rompeluz
239525	yelmo de rompeluz
239526	quijotes de rompeluz
239527	coraza de rompeluz
239529	coraza de acechaalba
239530	grebas de achechaalba
239531	guanteletes de acechaalba
239532	visor de acechaalba
239533	leotardos de acechaalba
239534	espaldares de acechaalba
239535	cinturon acechaalba
239536	avambrazos de acechaalba
239537	botas de acechaalba
239538	faja de acechaalba
239539	manoplas de acechaalba
239540	celada de acechaalba
239541	musleras de acechaalba
239542	bufas de acechaalba
239543	guerrera de acechaalba
239544	guardamunecas de acechaalba
239547	guardamunecas de anima crepuscular
239548	coselete de anima crepuscular
239549	mandiletes de anima crepuscular
239550	mascara de anima crepuscular
239551	leotardos de anima crepuscular
239552	manto de anima crepuscular
239553	botines de anima crepuscular
239554	cinturon de anima crepuscular
239555	brazales de anima crepuscular
239556	guardarrenes de anima crepuscular
239557	guanteletes de anima crepuscular
239558	escarpes de anima crepuscular
239559	espaldares de anima crepuscular
239560	yelmo de anima crepuscular
239561	quijotes de anima crepuscular
239562	coraza de anima crepuscular
239565	atuendo de revelacion
239572	botas de revelacion
239574	manos de revelacion
239575	corona de revelacion
239577	pantalones de revelacion
239581	manto de revelacion
239582	faja de revelacion
239583	munequeras de revelacion
239584	guantes de revelacion
239585	diadema de revelacion
239586	hombreras de revelacion
239587	leotardos de revelacion
239588	ataduras de revelacion
239589	sandalias de revelacion
239590	cinturon de revelacion
239591	toga de revelacion
239694	pacto de luz
239695	corcel escarlata
239696	empunadura de la crematoria
239698	tela tejida en alba
239706	escarpes consagrados
239707	casco consagrado
239708	espaldares consagrados
239709	quijotes consagrados
239710	sandalias consagradas
239712	hombreras consagradas
239714	aro consagrado
239715	toga consagrada
239716	guantes consagrados
239718	cinturon consagrado
239719	ataduras consagradas
239721	leotardos consagrados
239722	guardamunecas consagradas
239726	botas consagradas
239729	celada consagrada
239730	manoplas consagradas
239731	guerrera consagrada
239756	faja consagrada
239757	musleras consagradas
239758	bufas consagradas
239759	brazales consagrados
239760	guardarrenes consagrado
239761	coraza consagrada
239762	guanteletes consagrados
239764	filohoja carmesi
240018	manual de artilugios de fundefusibles
240020	musleras de inquisicion
240021	bufas de inquisicion
240022	botas de inquisicion
240023	avambrazos de inquisicion
240024	cinturon de inquisicion
240025	hombreras de inquisicion
240026	leotardos de inquisicion
240027	casco de inquisicion
240028	guantes de inquisicion
240029	grebas de inquisicion
240030	coraza de inquisicion
240031	brazales de inquisicion
240032	guardarrenes de inquisicion
240033	espaldares de inquisicion
240034	quijotes de inquisicion
240035	corona de inquisicion
240036	guanteletes de inquisicion
240037	escarpes de inquisicion
240038	coselete de inquisicion
240039	guerrera de inquisicion
240040	celada de inquisicion
240041	manoplas de inquisicion
240042	guardamunecas de inquisicion
240043	faja de inquisicion
240044	cubremunecas de hojafuego
240045	guardarrenes de hojafuego
240046	manto de hojafuego
240047	pantalones de hojafuego
240048	caperuza de hojafuego
240049	mitones de hojafuego
240050	botas de hojafuego
240051	atuendo de hojafuego
240052	ataduras de hojafuego
240053	cinturon de hojafuego
240054	hombreras de hojafuego
240055	leotardos de hojafuego
240056	aro de hojafuego
240057	guantes de hojafuego
240058	sandalias de hojafuego
240059	toga de hojafuego
240060	brazaletes de oteador
240061	fajin de oteador
240062	hombreras de oteador
240063	calzas de oteador
240064	capucha de oteador
240065	mandiletes de oteador
240066	apisonadoras de oteador
240067	jubon de oteador
240068	ataduras de oteador
240069	cordon de oteador
240070	manto de oteador
240071	falda de oteador
240072	caperuza de oteador
240073	mitones de oteador
240074	sandalias de oteador
240075	cueros de oteador
240076	brazales de oteador
240077	guardarrenes de oteador
240078	espaldares de oteador
240079	leotardos de oteador
240080	ornato de oteador
240081	guanteletes de oteador
240082	escarpes de oteador
240083	armadura de oteador
240084	guardamunecas de oteador
240085	faja de oteador
240086	bufas de oteador
240087	musleras de oteador
240088	celada de oteador
240089	manoplas de oteador
240090	botas de oteador
240091	guerrera de oteador
240092	guerrera de aplastaalmas
240093	botas de aplastaalmas
240095	manoplas de aplastaalmas
240096	celada de aplastaalmas
240097	musleras de aplastaalmas
240098	bufas de aplastaalmas
240099	faja de aplastaalmas
240100	guardamunecas de aplastaalmas
240101	coselete de aplastaalmas
240102	escarpes de aplastaalmas
240103	guantes de aplastaalmas
240104	visera de aplastaalmas
240105	quijotes de aplastaalmas
240106	espaldares de aplastaalmas
240107	guardarrenes de aplastaalmas
240108	brazales de aplastaalmas
240109	abrazo de aplastaalmas
240110	grebas de aplastaalmas
240122	mitones de aplastaalmas
240123	corona de aplastaalmas
240124	falda de aplastaalmas
240125	manto de aplastaalmas
240126	cordon de aplastaalmas
240127	ataduras de aplastaalmas
240128	armadura de aplastaalmas
240129	botines de aplastaalmas
240130	mandiletes de aplastaalmas
240131	casco de aplastaalmas
240132	baston de prueba
240134	leotardos de aplastaalmas
240135	cubrehombros de aplastaalmas
240136	cinturon de aplastaalmas
240137	avambrazos de aplastaalmas
240138	toga heretica
240139	sandalias hereticas
240140	guantes hereticos
240141	capucha heretica
240142	leotardos hereticos
240143	hombreras hereticas
240144	cinturon heretico
240145	ataduras hereticas
240146	atuendo heretico
240147	manoplas hereticas
240148	caperuza heretica
240149	pantalones hereticos
240150	manto heretico
240151	guardarrenes heretico
240152	guardamunecas hereticos
240153	botas hereticas
240174	solistra colmillo del alba
240195	espada invisible
240832	glandula nivifaciente
240835	cajon de suministros de claro de la luna
240836	silbato de thisalee
240837	hilos del destino
240839	thal kituun el huesped invisible
240841	guarda de la alta comandante
240842	putrefaccionista escarlata
240843	pistola de salida
240844	atizador de putress
240845	iman prototipo
240846	chatarra magnetica
240848	detrito de nordrassil
240849	baston del claro
240850	martillo punoluz
240851	regicidio
240852	cuchilla carmesi
240853	caida de la reina
240854	clemencia
240919	devastalabrys
240920	leogan
240921	aplastatoria escarlata
240922	engano
240923	duplicidad
240924	arma de asta de la bestia
240925	experimento k48um
240936	crematoria inerte
240945	porcion del pastel de manzana de carrie
240997	espuela de fratley
240998	hoja soporifera
241001	la caida de tyr
241002	restos del rojo
241003	espejismo vara de ilusion
241004	enigma
241006	aguja de sacrificio
241008	condenacion
241011	gran baston de lealtad
241012	varita de reanimacion
241015	egida del bastion escarlata
241017	locura de demonio
241018	corazon nathrezim
241020	diario completo de putress
241021	la luz
241022	capa de albar
241023	manton del cruel
241024	manteo de comandante escarlata
241025	bandera del almirante roto
241026	chal de cardenal
241027	guarda de celador escudado
241028	aro nathrezim
241029	sortija de baelin
241030	anillo de fraternidad de mason
241031	promesa de barthalomew
241032	anillo de resurreccion
241034	corazon de luz
241037	experimento abandonado
241038	didyeridu de sir dornel
241039	infusion de almas
241068	confalon de stiltz
241069	cadena de estrangulamiento
241070	esperanza de herod
241071	talisman del ladronzuelo escarlata
241072	vial de pus
241073	toque de la luz
241074	casco de la cruzada roja
241075	yelmo de destructor iracundo
241076	capucha del pacto
241077	sombrero de cardenal
241078	embozo del embalsamado
241079	peso del mundo
241080	espaldar de herod
241081	crematoria corrupta
241082	crematoria
241083	s03 scarlet enclave sword 2h raid
241084	s03 scarlet enclave herod s sword normal
241085	s03 scarlet enclave sword 1h
241086	escudo paves escarlata
241087	baston escarlata
241088	baston escarlata
241089	daga escarlata
241090	gran hacha escarlata
241091	maza escarlata
241092	filo escarlata
241120	s03 scarlet enclave herod s sword molten
241121	daga renacida
241122	cuchillo renacido
241123	daga renacida
241124	cuchillo renacido
241128	pila de portransportadores
241152	sobrehombros forjados por el alba
241153	manto de doan
241154	manto de piel de oso
241156	togas contaminadas
241157	peto escarlata
241158	cadenas del abandonado
241159	atuendo de monasterio
241160	malla de anillas desgastada por el alba
241161	coraza de templario
241162	cuero bendecido por el sol
241163	brazales llamarada sol
241164	cuero argenta desechado
241165	sobrevestes de penitente
241166	bracibles sinalba
241167	grilletes de prisionero
241168	mandiletes llamarada sol
241169	prototipo de nitropropulsores
241170	protectores del enclave
241171	guantes de almas de difuntos
241172	guanteletes vinculados de caldoran
241173	cinta de alto zahori
241174	faja del campeon renacido
241175	cinturon de herramientas de torturador
241176	deceso de diesalven
241177	falda del arcanista escarlata
241178	placas de dolor fiel
241179	leotardos de la catastrofe
241180	leotardos de escamas ligeras
241181	leotardos de anillas desgastados por el alba
241182	musleras de placas de templario
241183	caminacenizas
241184	sandalias de salvador
241185	botas de entrenamiento de osos
241186	botas de malla escarlata pulidas
241187	botas de guerra carmesi
241190	silbato de aves
241191	formula encantar arma gran cruzado
241195	formula encantar arma 2m gran arcanista
241201	formula encantar arma gran hechicero
241212	canon cacareador
241241	doblon de la suerte
241613	ya no se usa
241629	bala de canon escarlata
241649	guanteletes de la guardia de trabalomas
241650	pocion de sanacion sublime descolorida
241651	receta pocion de sanacion sublime descolorida
241652	corazon de bestia descolorido
241653	hoja caliente
241654	crematoria inerte
241655	pocion de sanacion maltratada
241656	pocion de sanacion maltratada
241657	espada templada
242018	corazon sangrante de las tierras de la peste
242224	cesta de corazones
242256	cartera de bombas incendiarias
242257	muestra alquimica misteriosa
242258	notas de investigacion
242266	los mil y un resguardos
242267	de arcanista a archimago
242268	si le das un encantamiento a un cruzado
242269	brillantez del gran hechicero
242270	brillantez del gran arcanista
242271	brillantez del gran cruzado
242310	mano de la justicia renacida
242311	amuleto de leonid
242312	sello de la familia barthalomew
242313	diario de los venerados
242314	cenicilla del cruzado caido
242315	cenizas de arrogancia
242316	polvo de los insolentes
242317	libro de oraciones profanado
242319	nuevas muestras de plaga
242320	nuevas muestras de plaga
242361	formula encantar arma 2m gran inquisidor
242362	brillantez del gran inquisidor
242363	¡quien como donde cuando y muere las cinco claves de una buena inquisicion
242364	tendon de dragon luminoso maduro
242365	ala de balnazzar
242366	destino ineludible
242367	ala y cuerda
242425	pagina de diario arrancada pagina 1
242426	pagina de diario arrancada pagina 2
242427	diario de putress
242428	pagina de diario arrancada pagina 3
242429	diario de putress
242430	pagina de diario arrancada pagina 4
242431	pagina de diario arrancada pagina 5
242432	diario de putress
242433	pagina de diario arrancada pagina 6
242434	diario de putress
242435	diario de putress
242436	diario de putress
242465	fragmento de caliz roto
242793	canon portatil
243010	crematoria corrupta
243064	baston largo
243065	varita rota
243177	juguete ingenioso
243198	mira de precision para aves de corral
243229	piedra de hogar del alba
243230	hoja forjada con luz arruinada
243345	baston largo
244353	mira de precision para aves de corral
244460	caladbolg
245675	llave de puerta interior de gordok
246055	mandiletes de inquisicion
246056	ajorcas de inquisicion
246057	apisonadoras de inquisicion
246058	pantalones de placas de inquisicion
246059	cordon de inquisicion
246060	loriga de inquisicion
246061	cubrehombros de inquisicion
246062	visera de inquisicion
]==]
