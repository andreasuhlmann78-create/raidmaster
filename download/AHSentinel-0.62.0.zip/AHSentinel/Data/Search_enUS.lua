-- AHSentinel - Suchindex (enUS), aus Names_enUS.lua erzeugt. Nicht von Hand ändern.
AHAnalyzerPro_NameSearch = AHAnalyzerPro_NameSearch or {}
AHAnalyzerPro_NameSearch["enUS"] = [==[

25	worn shortsword
35	bent staff
36	worn mace
37	worn axe
38	recruit s shirt
39	recruit s pants
40	recruit s boots
43	squire s boots
44	squire s pants
45	squire s shirt
47	footpad s shoes
48	footpad s pants
49	footpad s shirt
51	neophyte s boots
52	neophyte s pants
53	neophyte s shirt
55	apprentice s boots
56	apprentice s robe
57	acolyte s robe
59	acolyte s shoes
60	layered tunic
61	dwarven leather pants
79	dwarven cloth britches
80	soft fur lined shoes
85	dirty leather vest
117	tough jerky
118	minor healing potion
120	thug pants
121	thug boots
127	trapper s shirt
129	rugged trapper s boots
139	brawler s pants
140	brawler s boots
147	rugged trapper s pants
148	rugged trapper s shirt
153	primitive kilt
154	primitive mantle
159	refreshing spring water
182	garrick s head
193	tattered cloth vest
194	tattered cloth pants
195	tattered cloth boots
200	thick cloth vest
201	thick cloth pants
202	thick cloth shoes
203	thick cloth gloves
209	dirty leather pants
210	dirty leather boots
236	cured leather armor
237	cured leather pants
238	cured leather boots
239	cured leather gloves
285	scalemail vest
286	scalemail pants
287	scalemail boots
414	dalaran sharp
422	dwarven mild
537	dull frenzy scale
555	rough vulture feathers
556	buzzard beak
647	destiny
710	bracers of the people s militia
711	tattered cloth gloves
714	dirty leather gloves
718	scalemail gloves
719	rabbit handler gloves
720	brawler gloves
723	goretusk liver
724	goretusk liver pie
725	gnoll paw
727	notched shortsword
728	recipe westfall stew
729	stringy vulture meat
730	murloc eye
731	goretusk snout
732	okra
733	westfall stew
735	rolf and malakai s medallions
737	holy spring water
738	sack of barley
739	sack of corn
740	sack of rye
742	a sycamore branch
743	bundle of charred oak
744	thunderbrew s boot flask
745	marshal mcbride s documents
748	stormwind armor marker
750	tough wolf meat
752	red burlap bandana
753	dragonmaw shortsword
754	shortsword of vengeance
755	melted candle
756	tunnel pick
763	ice covered bracers
765	silverleaf
766	flanged mace
767	long bo staff
768	lumberjack axe
769	chunk of boar meat
770	pointy crocolisk tooth
771	chipped boar tusk
772	large candle
773	gold dust
774	malachite
776	vendetta
777	prowler teeth
778	kobold excavation pick
779	shiny seashell
780	torn murloc fin
781	stone gnoll hammer
782	painted gnoll armband
783	light hide
785	mageroyal
787	slitherskin mackerel
789	stout battlehammer
790	forester s axe
791	gnarled ash staff
792	knitted sandals
793	knitted gloves
794	knitted pants
795	knitted tunic
796	rough leather boots
797	rough leather gloves
798	rough leather pants
799	rough leather vest
804	large blue sack
805	small red pouch
809	bloodrazor
810	hammer of the northern wind
811	axe of the deep woods
812	glowing brightwood staff
813	broken cog
814	flask of oil
816	small hand blade
818	tigerseye
820	slicer blade
821	riverpaw leather vest
826	brutish riverpaw axe
827	wicked blackjack
828	small blue pouch
829	red leather bandana
832	silver defias belt
833	lifestone
835	large rope net
837	heavy weave armor
838	heavy weave pants
839	heavy weave gloves
840	heavy weave shoes
841	furlbrow s pocket watch
843	tanned leather boots
844	tanned leather gloves
845	tanned leather pants
846	tanned leather jerkin
847	chainmail armor
848	chainmail pants
849	chainmail boots
850	chainmail gloves
851	cutlass
852	mace
853	hatchet
854	quarter staff
856	blue leather bag
857	large red sack
858	lesser healing potion
859	fine cloth shirt
860	cavalier s boots
862	runed ring
863	gloom reaper
864	knightly longsword
865	leaden mace
866	monk s staff
867	gloves of holy might
868	ardent custodian
869	dazzling longsword
870	fiery war axe
871	flurry axe
872	rockslicer
873	staff of jordan
875	brown horse summoning
876	worn wooden buckler
878	fist sized spinneret
880	staff of horrors
884	ghoul rib
885	black metal axe
886	black metal shortsword
887	pound of flesh
888	naga battle gloves
889	a dusty unsent letter
890	twisted chanter s staff
892	gnoll casting gloves
893	dire wolf fang
895	worgen skull
896	worgen fang
897	madwolf bracers
899	venom web fang
910	an undelivered letter
911	ironwood treebranch
913	huge ogre sword
914	large ogre chain armor
915	red silk bandana
916	a torn journal page
918	deviate hide pack
920	wicked spiked mace
921	a faded journal page
922	dacian falx
923	longsword
924	maul
925	flail
926	battle axe
927	double axe
928	long staff
929	healing potion
932	fel steed saddlebags
933	large rucksack
934	stalvan s reaper
935	night watch shortsword
936	midnight mace
937	black duskwood staff
938	muddy journal pages
939	a bloodstained journal page
940	robes of insight
942	freezing band
943	warden staff
944	elemental mage staff
945	shadow sword
948	nature sword
954	scroll of strength
955	scroll of intellect
957	william s shipment
961	healing herb
962	pork belly pie
981	bernice s necklace
983	red linen sash
1006	brass collar
1008	well used sword
1009	compact hammer
1010	gnarled short staff
1011	sharp axe
1013	iron rivet
1015	lean wolf flank
1017	seasoned wolf kabob
1019	red linen bandana
1041	horn of the black wolf
1074	hard spider leg tip
1075	shadowhide pendant
1076	defias renegade ring
1077	defias mage ring
1080	tough condor meat
1081	crisp spider meat
1082	redridge goulash
1083	glyph of azora
1113	conjured bread
1114	conjured rye
1116	ring of pure silver
1121	feet of the lynx
1127	flash bundle
1129	ghoul fang
1130	vial of spider venom
1131	totem of infliction
1132	horn of the timber wolf
1133	horn of the winter wolf
1134	horn of the gray wolf
1154	belt of the people s militia
1155	rod of the sleepwalker
1156	lavishly jeweled ring
1158	solid metal club
1159	militia quarterstaff
1161	militia shortsword
1164	sam s tome
1166	dented buckler
1167	small targe
1168	skullflame shield
1169	blackskull shield
1171	well stitched robe
1172	grayson s torch
1173	weather worn boots
1175	a gold tooth
1177	oil of olaf
1178	explosive rocket
1179	ice cold milk
1180	scroll of stamina
1181	scroll of spirit
1182	brass studded bracers
1183	elastic wristguards
1187	spiked collar
1189	overseer s ring
1190	overseer s cloak
1191	bag of marbles
1193	banded buckler
1194	bastard sword
1195	kobold mining shovel
1196	tabar
1197	giant mace
1198	claymore
1200	large wooden shield
1201	dull heater shield
1202	wall shield
1203	aegis of stormwind
1204	the green tower
1205	melon juice
1206	moss agate
1207	murphstar
1208	maybell s love letter
1210	shadowgem
1211	gnoll war harness
1212	gnoll spittle
1213	gnoll kindred bracers
1214	gnoll punisher
1215	support girdle
1216	frost bracers
1217	unknown reward
1218	heavy gnoll war club
1219	redridge machete
1220	lupine axe
1221	underbelly whelp scale
1222	broken tooth
1251	linen bandage
1252	gramma stonefield s note
1254	lesser firestone
1256	crystal kelp frond
1257	invisibility liquor
1260	tharil zun s head
1261	midnight orb
1262	keg of thunderbrew lager
1263	brain hacker
1264	headbasher
1265	scorpion sting
1270	finely woven cloak
1273	forest chain
1274	hops
1275	deputy chain coat
1276	fire hardened buckler
1280	cloaked hood
1282	sparkmetal coif
1283	verner s note
1284	crate of horseshoes
1287	giant tarantula fang
1288	large venom sac
1292	butcher s cleaver
1293	the state of lakeshire
1294	the general s response
1296	blackrock mace
1297	robes of the shadowcaster
1299	lesser belt of the spire
1300	lesser staff of the spire
1302	black whelp gloves
1303	bridgeworker s gloves
1304	riding gloves
1306	wolfmane wristguards
1307	gold pickup schedule
1309	oslow s toolbox
1310	smith s trousers
1314	ghoul fingers
1315	lei of lilies
1317	hardened root staff
1318	night reaver
1319	ring of iron will
1322	fishliver oil
1325	daffodil bouquet
1326	sauteed sunfish
1327	wiley s note
1349	abercrombie s crate
1351	fingerbone bracers
1352	cracked skull mortar
1353	shaw s report
1355	buckskin cape
1356	commendation elwynn forest
1357	captain sander s treasure map
1358	a clue to sander s treasure
1359	lion stamped gloves
1360	stormwind chain gloves
1361	another clue to sander s treasure
1362	final clue to sander s treasure
1364	ragged leather vest
1366	ragged leather pants
1367	ragged leather boots
1368	ragged leather gloves
1369	ragged leather belt
1370	ragged leather bracers
1372	ragged cloak
1374	frayed shoes
1376	frayed cloak
1377	frayed gloves
1378	frayed pants
1380	frayed robe
1381	a mysterious message
1382	rock mace
1383	stone tomahawk
1384	dull blade
1386	thistlewood axe
1387	ghoulfang
1388	crooked staff
1389	kobold mining mallet
1391	riverpaw mystic staff
1394	driftwood club
1395	apprentice s pants
1396	acolyte s pants
1399	magic candle
1401	green tea leaf
1404	tidal charm
1405	foamspittle staff
1406	pearl encrusted spear
1407	solomon s plea to westfall
1408	stoutmantle s response to solomon
1409	solomon s plea to darkshire
1410	ebonlocke s response to solomon
1411	withered staff
1412	crude bastard sword
1413	feeble sword
1414	cracked sledge
1415	carpenter s mallet
1416	rusty hatchet
1417	beaten battle axe
1418	worn leather belt
1419	worn leather boots
1420	worn leather bracers
1421	worn hide cloak
1422	worn leather gloves
1423	worn leather pants
1425	worn leather vest
1427	patchwork shoes
1429	patchwork cloak
1430	patchwork gloves
1431	patchwork pants
1433	patchwork armor
1434	glowing wax stick
1436	frontier britches
1438	warrior s shield
1440	gnoll skull basher
1443	jeweled amulet of cainwyn
1445	blackrock pauldrons
1446	blackrock boots
1447	ring of saviors
1448	blackrock gauntlets
1449	minor channeling ring
1450	potion of fervor
1451	bottle of zombie juice
1453	spectral comb
1454	axe of the enforcer
1455	blackrock champion s axe
1457	shadowhide mace
1458	shadowhide maul
1459	shadowhide scalper
1460	shadowhide two handed sword
1461	slayer s battle axe
1462	ring of the shadow
1464	buzzard talon
1465	tigerbane
1467	spotted sunfish
1468	murloc fin
1469	scimitar of atun
1470	murloc skin bag
1473	riverside staff
1475	small venom sac
1476	snapped spider limb
1477	scroll of agility ii
1478	scroll of protection ii
1479	salma s oven mitts
1480	fist of the people s militia
1481	grimclaw
1482	shadowfang
1483	face smasher
1484	witching stave
1485	pitchfork
1486	tree bark jacket
1487	conjured pumpernickel
1488	avenger s armor
1489	gloomshroud armor
1490	guardian talisman
1491	ring of precision
1493	heavy marauder scimitar
1495	calico shoes
1497	calico cloak
1498	calico gloves
1499	calico pants
1501	calico tunic
1502	warped leather belt
1503	warped leather boots
1504	warped leather bracers
1505	warped cloak
1506	warped leather gloves
1507	warped leather pants
1509	warped leather vest
1510	heavy hammer
1511	commoner s sword
1512	crude battle axe
1513	old greatsword
1514	rusty warhammer
1515	rough wooden staff
1516	worn hatchet
1518	ghost hair comb
1519	bloodscalp ear
1520	troll sweat
1521	lumbering ogre axe
1522	headhunting spear
1523	huge stone club
1524	skullsplitter tusk
1528	handful of oats
1529	jade
1532	shrunken head
1537	old blanchy s feed pouch
1539	gnarled hermit s staff
1547	shield of the faith
1557	buckler of the seas
1560	bluegill sandals
1561	harvester s robe
1566	edge of the people s militia
1596	ghost hair thread
1598	rot blossom
1602	sickle axe
1604	chromatic sword
1607	soulkeeper
1608	skullcrusher mace
1613	spiritchaser staff
1624	skullsplitter helm
1625	exquisite flamberge
1630	broken electro lantern
1637	letter to ello
1639	grinning axe
1640	monstrous war axe
1645	moonberry juice
1652	sturdy lunchbox
1656	translated letter
1659	engineering gloves
1664	spellforce rod
1677	drake scale vest
1678	black ogre kickers
1679	korg bat
1680	headchopper
1685	troll hide bag
1686	bristly whisker
1687	retractable claw
1688	long soft tail
1696	curved raptor talon
1697	keen raptor tooth
1701	curved basilisk claw
1702	intact basilisk spine
1703	crystal basilisk spine
1705	lesser moonstone
1706	azuredeep shards
1707	stormwind brie
1708	sweet nectar
1710	greater healing potion
1711	scroll of stamina ii
1712	scroll of spirit ii
1713	ankh of life
1714	necklace of calisea
1715	polished jazeraint armor
1716	robe of the magi
1717	double link tunic
1718	basilisk hide pants
1720	tanglewood staff
1721	viking warhammer
1722	thornstone sledgehammer
1725	large knapsack
1726	poison tipped bone spear
1727	sword of decay
1728	teebu s blazing longsword
1729	gunnysack of the night watch
1730	worn mail belt
1731	worn mail boots
1732	worn mail bracers
1733	worn cloak
1734	worn mail gloves
1735	worn mail pants
1737	worn mail vest
1738	laced mail belt
1739	laced mail boots
1740	laced mail bracers
1741	laced cloak
1742	laced mail gloves
1743	laced mail pants
1744	laced mail shoulderpads
1745	laced mail vest
1746	linked chain belt
1747	linked chain boots
1748	linked chain bracers
1749	linked chain cloak
1750	linked chain gloves
1751	linked chain pants
1752	linked chain shoulderpads
1753	linked chain vest
1754	reinforced chain belt
1755	reinforced chain boots
1756	reinforced chain bracers
1757	reinforced chain cloak
1758	reinforced chain gloves
1759	reinforced chain pants
1760	reinforced chain shoulderpads
1761	reinforced chain vest
1764	canvas shoes
1766	canvas cloak
1767	canvas gloves
1768	canvas pants
1769	canvas shoulderpads
1770	canvas vest
1772	brocade shoes
1774	brocade cloak
1775	brocade gloves
1776	brocade pants
1777	brocade shoulderpads
1778	brocade vest
1780	cross stitched sandals
1782	cross stitched cloak
1783	cross stitched gloves
1784	cross stitched pants
1785	cross stitched shoulderpads
1786	cross stitched vest
1787	patched leather belt
1788	patched leather boots
1789	patched leather bracers
1790	patched cloak
1791	patched leather gloves
1792	patched leather pants
1793	patched leather shoulderpads
1794	patched leather jerkin
1795	rawhide belt
1796	rawhide boots
1797	rawhide bracers
1798	rawhide cloak
1799	rawhide gloves
1800	rawhide pants
1801	rawhide shoulderpads
1802	rawhide tunic
1803	tough leather belt
1804	tough leather boots
1805	tough leather bracers
1806	tough cloak
1807	tough leather gloves
1808	tough leather pants
1809	tough leather shoulderpads
1810	tough leather armor
1811	blunt claymore
1812	short handled battle axe
1813	chipped quarterstaff
1814	battered mallet
1815	ornamental mace
1816	unbalanced axe
1817	stock shortsword
1818	standard claymore
1819	gouging pick
1820	wooden maul
1821	warped blade
1822	cedar walking stick
1823	bludgeoning cudgel
1824	shiny war axe
1825	bulky bludgeon
1826	rock maul
1827	meat cleaver
1828	stone war axe
1829	short cutlass
1830	long bastard sword
1831	oaken war staff
1832	lucky trousers
1835	dirty leather belt
1836	dirty leather bracers
1839	rough leather belt
1840	rough leather bracers
1843	tanned leather belt
1844	tanned leather bracers
1845	chainmail belt
1846	chainmail bracers
1849	cured leather belt
1850	cured leather bracers
1851	cleansing water
1852	scalemail bracers
1853	scalemail belt
1875	thistlenettle s badge
1893	miner s revenge
1894	miners union card
1913	studded blackjack
1917	jeweled dagger
1922	supplies for sven
1923	ambassador s satchel
1925	defias rapier
1926	weighted sap
1927	deadmines cleaver
1928	defias mage staff
1929	silk threaded trousers
1930	stonemason cloak
1931	huge gnoll claw
1933	staff of conjuring
1934	stonemason trousers
1935	assassin s blade
1936	goblin screwdriver
1937	buzz saw
1938	block mallet
1939	skin of sweet rum
1941	cask of merlot
1942	bottle of moonshine
1943	goblin mail leggings
1944	metalworking gloves
1945	woodworking gloves
1946	mary s looking glass
1951	blackwater cutlass
1955	dragonmaw chain boots
1956	faded shadowhide pendant
1958	petrified shinbone
1959	cold iron pick
1962	glowing shadowhide pendant
1965	white wolf gloves
1968	ogre s monocle
1970	restoring balm
1971	furlbrow s deed
1972	westfall deed
1973	orb of deception
1974	mindthrust bracers
1975	pysan s old greatsword
1976	slaghammer
1978	wolfclaw gloves
1979	wall of the dead
1980	underworld band
1981	icemail jerkin
1982	nightblade
1986	gutrender
1987	krazek s fixed pot
1988	chief brigadier gauntlets
1990	ballast maul
1991	goblin power shovel
1992	swampchill fetish
1993	ogremind ring
1994	ebonclaw reaver
1996	voodoo band
1997	pressed felt robe
1998	bloodscalp channeling staff
2000	archeus
2004	grelin whitebeard s journal
2005	the first troll legend
2006	the second troll legend
2007	the third troll legend
2008	the fourth troll legend
2011	twisted sabre
2013	cryptbone staff
2014	black metal greatsword
2015	black metal war axe
2016	dusty chain armor
2017	glowing leather bracers
2018	skeletal longsword
2020	hollowfang blade
2021	green carapace shield
2024	espadon
2025	bearded axe
2026	rock hammer
2027	scimitar
2028	hammer
2029	cleaver
2030	gnarled staff
2032	gallan cuffs
2033	ambassador s boots
2034	scholarly robes
2035	sword of the night sky
2036	dusty mining gloves
2037	tunneler s boots
2039	plains ring
2040	troll protector
2041	tunic of westfall
2042	staff of westfall
2043	ring of forlorn spirits
2044	crescent of forlorn spirits
2046	bluegill kukri
2047	anvilmar hand axe
2048	anvilmar hammer
2054	trogg hand axe
2055	small wooden hammer
2056	the velvet hammer
2057	pitted defias shortsword
2058	kazon s maul
2059	sentry cloak
2064	trogg club
2065	rockjaw blade
2066	skull hatchet
2067	frostbit staff
2069	black bear hide vest
2070	darnassian bleu
2072	dwarven magestaff
2073	dwarven hatchet
2074	solid shortblade
2075	priest s mace
2077	magician staff
2078	northern shortsword
2079	sergeant s warhammer
2080	hillborne axe
2082	wizbang s gunnysack
2084	darksteel bastard sword
2085	chunk of flesh
2087	hard crawler carapace
2088	long crawler limb
2089	scrimshaw dagger
2091	magic dust
2092	worn dagger
2098	double barreled shotgun
2099	dwarven hand cannon
2100	precisely calibrated boomstick
2101	light quiver
2102	small ammo pouch
2105	thug shirt
2108	frostmane leather vest
2109	frostmane chain vest
2110	light magesmith robe
2112	lumberjack jerkin
2113	calor s note
2114	snowy robe
2117	thin cloth shoes
2119	thin cloth gloves
2120	thin cloth pants
2121	thin cloth armor
2122	cracked leather belt
2123	cracked leather boots
2124	cracked leather bracers
2125	cracked leather gloves
2126	cracked leather pants
2127	cracked leather vest
2129	large round shield
2130	club
2131	shortsword
2132	short staff
2133	small shield
2134	hand axe
2136	conjured purified water
2137	whittling knife
2138	sharpened letter opener
2139	dirk
2140	carving knife
2141	cuirboulli vest
2142	cuirboulli belt
2143	cuirboulli boots
2144	cuirboulli bracers
2145	cuirboulli gloves
2146	cuirboulli pants
2148	polished scale belt
2149	polished scale boots
2150	polished scale bracers
2151	polished scale gloves
2152	polished scale leggings
2153	polished scale vest
2154	the story of morgan ladimore
2156	padded boots
2158	padded gloves
2159	padded pants
2160	padded armor
2161	book from sven s farm
2162	sarah s ring
2163	shadowblade
2164	gut ripper
2165	old blanchy s blanket
2166	foreman s leggings
2167	foreman s gloves
2168	foreman s boots
2169	buzzer blade
2172	rustic belt
2173	old leather belt
2175	shadowhide battle axe
2186	outfitter belt
2187	a stack of letters
2188	a letter to grelin whitebeard
2194	diamond hammer
2195	anvilmar knife
2203	brashclaw s chopper
2204	brashclaw s skewer
2205	duskbringer
2207	jambiya
2208	poniard
2209	kris
2210	battered buckler
2211	bent large shield
2212	cracked buckler
2213	worn large shield
2214	wooden buckler
2215	wooden shield
2216	simple buckler
2217	rectangular shield
2218	craftsman s dagger
2219	small round shield
2220	box shield
2221	targe shield
2222	tower shield
2223	the collector s schedule
2224	militia dagger
2225	sharp kitchen knife
2226	ogremage staff
2227	heavy ogre war axe
2230	gloves of brawn
2231	inferno robe
2232	dark runner boots
2233	shadow weaver leggings
2234	nightwalker armor
2235	brackclaw
2236	blackfang
2237	patched pants
2238	urchin s pants
2239	the collector s ring
2240	rugged cape
2241	desperado cape
2243	hand of edward the odd
2244	krol blade
2245	helm of narv
2246	myrmidon s signet
2249	militia buckler
2250	dusky crab cakes
2251	gooey spider leg
2252	miscellaneous goblin supplies
2254	icepane warhammer
2256	skeletal club
2257	frostmane staff
2258	frostmane shortsword
2259	frostmane club
2260	frostmane hand axe
2262	mark of kern
2263	phytoblade
2264	mantle of thieves
2265	stonesplinter axe
2266	stonesplinter dagger
2267	stonesplinter mace
2268	stonesplinter blade
2271	staff of the blessed seer
2273	guerrilla armor
2274	sapper s gloves
2276	swampwalker boots
2277	necromancer leggings
2278	forest tracker epaulets
2280	kam s walking stick
2281	rodentia flint axe
2282	rodentia shortsword
2283	rat cloth belt
2284	rat cloth cloak
2287	haunch of meat
2288	conjured fresh water
2289	scroll of strength ii
2290	scroll of intellect ii
2291	kang the decapitator
2292	necrology robes
2295	large boar tusk
2296	great goretusk snout
2299	burning war axe
2300	embossed leather vest
2302	handstitched leather boots
2303	handstitched leather pants
2304	light armor kit
2307	fine leather boots
2308	fine leather cloak
2309	embossed leather boots
2310	embossed leather cloak
2311	white leather jerkin
2312	fine leather gloves
2313	medium armor kit
2314	toughened leather armor
2315	dark leather boots
2316	dark leather cloak
2317	dark leather tunic
2318	light leather
2319	medium leather
2320	coarse thread
2321	fine thread
2324	bleach
2325	black dye
2326	ivy weave bracers
2327	sturdy leather bracers
2361	battleworn hammer
2362	worn wooden shield
2364	woven vest
2366	woven pants
2367	woven boots
2369	woven gloves
2370	battered leather harness
2371	battered leather belt
2372	battered leather pants
2373	battered leather boots
2374	battered leather bracers
2375	battered leather gloves
2376	worn heater shield
2377	round buckler
2378	skeleton finger
2379	tarnished chain vest
2380	tarnished chain belt
2381	tarnished chain leggings
2382	the embalmer s heart
2383	tarnished chain boots
2384	tarnished chain bracers
2385	tarnished chain gloves
2386	rusted chain vest
2387	rusted chain belt
2388	rusted chain leggings
2389	rusted chain boots
2390	rusted chain bracers
2391	rusted chain gloves
2392	light mail armor
2393	light mail belt
2394	light mail leggings
2395	light mail boots
2396	light mail bracers
2397	light mail gloves
2398	light chain armor
2399	light chain belt
2400	light chain leggings
2401	light chain boots
2402	light chain bracers
2403	light chain gloves
2406	pattern fine leather boots
2407	pattern white leather jerkin
2408	pattern fine leather gloves
2409	pattern dark leather tunic
2410	smoky torch
2411	black stallion bridle
2414	pinto bridle
2417	augmented chain vest
2418	augmented chain leggings
2419	augmented chain belt
2420	augmented chain boots
2421	augmented chain bracers
2422	augmented chain gloves
2423	brigandine vest
2424	brigandine belt
2425	brigandine leggings
2426	brigandine boots
2427	brigandine bracers
2428	brigandine gloves
2429	russet vest
2431	russet pants
2432	russet boots
2434	russet gloves
2435	embroidered armor
2437	embroidered pants
2438	embroidered boots
2440	embroidered gloves
2441	ringed buckler
2442	reinforced targe
2443	metal buckler
2444	ornate buckler
2445	large metal shield
2446	kite shield
2447	peacebloom
2448	heavy pavise
2449	earthroot
2450	briarthorn
2451	crested heater shield
2452	swiftthistle
2453	bruiseweed
2454	elixir of lion s strength
2455	minor mana potion
2456	minor rejuvenation potion
2457	elixir of minor agility
2458	elixir of minor fortitude
2459	swiftness potion
2463	studded doublet
2464	studded belt
2465	studded pants
2466	skullsplitter fetish
2467	studded boots
2468	studded bracers
2469	studded gloves
2470	reinforced leather vest
2471	reinforced leather belt
2472	reinforced leather pants
2473	reinforced leather boots
2474	reinforced leather bracers
2475	reinforced leather gloves
2476	chilled basilisk haunch
2477	ravager s skull
2479	broad axe
2480	large club
2488	gladius
2489	two handed sword
2490	tomahawk
2491	large axe
2492	cudgel
2493	wooden mallet
2494	stiletto
2495	walking stick
2499	double bladed axe
2504	worn shortbow
2505	polished shortbow
2506	hornwood recurve bow
2507	laminated recurve bow
2508	old blunderbuss
2509	ornate blunderbuss
2510	solid blunderbuss
2511	hunter s boomstick
2512	rough arrow
2515	sharp arrow
2516	light shot
2519	heavy shot
2520	broadsword
2521	flamberge
2522	crescent axe
2523	bullova
2524	truncheon
2525	war hammer
2526	main gauche
2527	battle staff
2528	falchion
2529	zweihander
2530	francisca
2531	great axe
2532	morning star
2533	war maul
2534	rondel
2535	war staff
2536	trogg stone tooth
2545	malleable chain leggings
2546	royal frostmane girdle
2547	boar handler gloves
2548	barrel of barleybrew scalder
2549	staff of the shade
2553	recipe elixir of minor agility
2555	recipe swiftness potion
2556	recipe elixir of tongues
2560	jitters completed journal
2561	chok sul s head
2562	bouquet of scarlet begonias
2563	strange smelling powder
2564	elven spirit claws
2565	rod of molten fire
2566	sacrificial robes
2567	evocator s blade
2568	brown linen vest
2569	linen boots
2570	linen cloak
2571	viny wrappings
2572	red linen robe
2575	red linen shirt
2576	white linen shirt
2577	blue linen shirt
2578	barbaric linen vest
2579	green linen shirt
2580	reinforced linen cape
2581	heavy linen bandage
2582	green woolen vest
2583	woolen boots
2584	woolen cape
2585	gray woolen robe
2586	gamemaster s robe
2587	gray woolen shirt
2589	linen cloth
2590	forest spider webbing
2591	dirty trogg cloth
2592	wool cloth
2593	flask of port
2594	flagon of mead
2595	jug of bourbon
2596	skin of dwarven stout
2598	pattern red linen robe
2601	pattern gray woolen robe
2604	red dye
2605	green dye
2606	lurker venom
2607	mo grosh crystal
2608	threshadon ambergris
2609	disarming colloid
2610	disarming mixture
2611	crude flint
2612	plain robe
2613	double stitched robes
2614	robe of apprenticeship
2615	chromatic robe
2616	shimmering silk robes
2617	burning robes
2618	silver dress robes
2619	grelin s report
2620	augural shroud
2621	cowl of necromancy
2622	nimar s tribal headdress
2623	holy diadem
2624	thinking cap
2625	menethil statuette
2628	senir s report
2629	intrepid strongbox key
2632	curved dagger
2633	jungle remedy
2634	venom fern extract
2635	loose chain belt
2636	carved stone idol
2637	ironband s progress report
2639	merrin s letter
2640	miners gear
2642	loose chain boots
2643	loose chain bracers
2644	loose chain cloak
2645	loose chain gloves
2646	loose chain pants
2648	loose chain vest
2649	flimsy chain belt
2650	flimsy chain boots
2651	flimsy chain bracers
2652	flimsy chain cloak
2653	flimsy chain gloves
2654	flimsy chain pants
2656	flimsy chain vest
2657	red leather bag
2658	ados fragment
2659	modr fragment
2660	golm fragment
2661	neru fragment
2662	ribbly s quiver
2663	ribbly s bandolier
2664	spinner fang
2665	stormwind seasoning herbs
2666	barrel of thunder ale
2667	macgrann s dried meats
2668	threshadon tooth
2669	threshadon claw
2671	wendigo mane
2672	stringy wolf meat
2673	coyote meat
2674	crawler meat
2675	crawler claw
2676	shimmerweed
2677	boar ribs
2678	mild spices
2679	charred wolf meat
2680	spiced wolf meat
2681	roasted boar meat
2682	cooked crab claw
2683	crab cake
2684	coyote steak
2685	succulent pork ribs
2686	thunder ale
2687	dry pork ribs
2688	squirrel nut
2690	latched belt
2691	outfitter boots
2692	hot spices
2694	settler s leggings
2696	cask of evershine
2697	recipe goretusk liver pie
2698	recipe cooked crab claw
2699	recipe redridge goulash
2700	recipe succulent pork ribs
2701	recipe seasoned wolf kabob
2702	lightforge ingot
2712	crate of lightforge ingots
2713	ol sooty s head
2719	small brass key
2720	muddy note
2721	holy shroud
2722	wine ticket
2723	bottle of pinot noir
2724	cloth request
2725	green hills of stranglethorn page 1
2728	green hills of stranglethorn page 4
2730	green hills of stranglethorn page 6
2732	green hills of stranglethorn page 8
2734	green hills of stranglethorn page 10
2735	green hills of stranglethorn page 11
2738	green hills of stranglethorn page 14
2740	green hills of stranglethorn page 16
2742	green hills of stranglethorn page 18
2744	green hills of stranglethorn page 20
2745	green hills of stranglethorn page 21
2748	green hills of stranglethorn page 24
2749	green hills of stranglethorn page 25
2750	green hills of stranglethorn page 26
2751	green hills of stranglethorn page 27
2754	tarnished bastard sword
2755	green hills of stranglethorn
2756	green hills of stranglethorn chapter i
2757	green hills of stranglethorn chapter ii
2758	green hills of stranglethorn chapter iii
2759	green hills of stranglethorn chapter iv
2760	thurman s sewing kit
2763	fisherman knife
2764	small dagger
2765	hunting knife
2766	deft stiletto
2770	copper ore
2771	tin ore
2772	iron ore
2773	cracked shortbow
2774	rust covered blunderbuss
2775	silver ore
2776	gold ore
2777	feeble shortbow
2778	cheap blunderbuss
2779	tear of tilloa
2780	light hunting bow
2781	dirty blunderbuss
2782	mishandled recurve bow
2783	shoddy blunderbuss
2784	musquash root
2785	stiff recurve bow
2786	oiled blunderbuss
2787	trogg dagger
2788	black claw stout
2794	an old history book
2795	book stresses of iron
2797	heart of mokk
2798	rethban ore
2799	gorilla fang
2800	black velvet robes
2801	blade of hanna
2802	blazing emblem
2805	yeti fur cloak
2806	package for stormpike
2807	guillotine axe
2815	curve bladed ripper
2816	death speaker scepter
2817	soft leather tunic
2818	stretched leather trousers
2819	cross dagger
2820	nifty stopwatch
2821	mo grosh masher
2822	mo grosh toothpick
2823	mo grosh can opener
2824	hurricane
2825	bow of searing arrows
2828	nissa s remains
2829	gregor s remains
2830	thurman s remains
2831	devlin s remains
2832	verna s westfall stew recipe
2833	the lich s spellbook
2834	embalming ichor
2835	rough stone
2836	coarse stone
2837	thurman s letter
2838	heavy stone
2839	a letter to yvette
2840	copper bar
2841	bronze bar
2842	silver bar
2843	dirty knucklebones
2844	copper mace
2845	copper axe
2846	tirisfal pumpkin
2847	copper shortsword
2848	bronze mace
2849	bronze axe
2850	bronze shortsword
2851	copper chain belt
2852	copper chain pants
2853	copper bracers
2854	runed copper bracers
2855	putrid claw
2856	iron pike
2857	runed copper belt
2858	darkhound blood
2859	vile fin scale
2862	rough sharpening stone
2863	coarse sharpening stone
2864	runed copper breastplate
2865	rough bronze leggings
2866	rough bronze cuirass
2867	rough bronze bracers
2868	patterned bronze bracers
2869	silvered bronze breastplate
2870	shining silver breastplate
2871	heavy sharpening stone
2872	vicious night web spider venom
2874	an unsent letter
2875	scarlet insignia ring
2876	duskbat pelt
2877	combatant claymore
2878	bearded boneaxe
2879	antipodean rod
2880	weak flux
2881	plans runed copper breastplate
2882	plans silvered bronze shoulders
2883	plans deadly bronze poniard
2885	scarlet crusade documents
2886	crag boar rib
2888	beer basted boar ribs
2889	recipe beer basted boar ribs
2891	letter to the city architect
2892	deadly poison
2893	deadly poison ii
2894	rhapsody malt
2895	creeping pain
2896	creeping anguish
2898	mountaineer chestpiece
2899	wendigo collar
2900	stone buckler
2901	mining pick
2902	cloak of the faith
2903	daryl s hunting bow
2904	daryl s hunting rifle
2905	goat fur cloak
2906	darkshire mail leggings
2907	dwarven tree chopper
2908	thornblade
2909	red wool bandana
2910	gold militia boots
2911	keller s girdle
2912	claw of the shadowmancer
2913	silk mantle of gamn
2915	taran icebreaker
2916	gold lion shield
2917	tranquil ring
2924	crocolisk meat
2925	crocolisk skin
2926	head of bazil thredd
2927	creeping torment
2928	dust of decay
2930	essence of pain
2931	maiden s anguish
2933	seal of wrynn
2934	ruined leather scraps
2939	crocolisk tear
2940	bloody bear paw
2941	prison shank
2942	iron knuckles
2943	eye of paleth
2944	cursed eye of paleth
2946	balanced throwing dagger
2947	small throwing knife
2949	mariner boots
2950	icicle rod
2951	ring of the underwood
2953	watch master s cloak
2954	night watch pantaloons
2955	first mate hat
2956	report on the defias brotherhood
2957	journeyman s vest
2958	journeyman s pants
2959	journeyman s boots
2960	journeyman s gloves
2961	burnt leather vest
2962	burnt leather breeches
2963	burnt leather boots
2964	burnt leather gloves
2965	warrior s tunic
2966	warrior s pants
2967	warrior s boots
2968	warrior s gloves
2969	spellbinder vest
2970	spellbinder pants
2971	spellbinder boots
2972	spellbinder gloves
2973	hunting tunic
2974	hunting pants
2975	hunting boots
2976	hunting gloves
2977	veteran armor
2978	veteran leggings
2979	veteran boots
2980	veteran gloves
2981	seer s robe
2982	seer s pants
2983	seer s boots
2984	seer s gloves
2985	inscribed leather breastplate
2986	inscribed leather pants
2987	inscribed leather boots
2988	inscribed leather gloves
2989	burnished tunic
2990	burnished leggings
2991	burnished boots
2992	burnished gloves
2996	bolt of linen cloth
2997	bolt of woolen cloth
2998	a simple compass
2999	steelgrill s tools
3000	brood mother carapace
3008	wendigo fur cloak
3010	fine sand
3011	feathered headdress
3012	scroll of agility
3013	scroll of protection
3014	battleworn axe
3016	gunther s spellbook
3017	sevren s orders
3018	hide of lupos
3019	noble s robe
3020	enduring cap
3021	ranger bow
3022	bluegill breeches
3023	large bore blunderbuss
3024	bkp 2700 enforcer
3025	bkp 42 ultra
3026	reinforced bow
3027	heavy recurve bow
3028	longbow
3030	razor arrow
3033	solid shot
3034	glyphed breastplate
3035	laced pumpkin
3036	heavy shortbow
3037	whipwood recurve bow
3039	short ash bow
3040	hunter s muzzle loader
3041	mage eye blunderbuss
3042	bkp sparrow smallbore
3045	lambent scale boots
3047	lambent scale gloves
3048	lambent scale legguards
3049	lambent scale breastplate
3053	humbert s chestpiece
3055	forest leather chestpiece
3056	forest leather pants
3057	forest leather boots
3058	forest leather gloves
3065	bright boots
3066	bright gloves
3067	bright pants
3069	bright robe
3070	ensign cloak
3071	striking hatchet
3072	smoldering robe
3073	smoldering pants
3074	smoldering gloves
3075	eye of flame
3076	smoldering boots
3078	naga heartpiercer
3079	skorn s rifle
3080	candle of beckoning
3081	nether gem
3082	dargol s skull
3083	restabilization cog
3084	gyromechanic gear
3085	barrel of shimmer stout
3086	cask of shimmer stout
3087	mug of shimmer stout
3103	coldridge hammer
3107	keen throwing knife
3108	heavy throwing dagger
3110	tunnel rat ear
3111	crude throwing axe
3117	hildelve s journal
3131	weighted throwing axe
3135	sharp throwing axe
3137	deadly throwing axe
3148	work shirt
3151	siege brigade vest
3152	driving gloves
3153	oil stained cloak
3154	thelsamar axe
3155	remedy of arugal
3156	glutton shackle
3157	darksoul shackle
3158	burnt hide bracers
3160	ironplate buckler
3161	robe of the keeper
3162	notched rib
3163	blackened skull
3164	discolored worg heart
3165	quinn s potion
3166	ironheart chain
3167	thick spider hair
3168	chipped scale
3169	chipped bear tooth
3170	large bear tooth
3171	broken boar tusk
3172	boar intestines
3173	bear meat
3174	spider ichor
3175	ruined dragonhide
3176	small claw
3177	tiny fang
3179	cracked dragon molting
3180	flecked raptor scale
3181	partially digested meat
3182	spider s silk
3183	mangy claw
3184	hook dagger
3185	acrobatic staff
3186	viking sword
3187	sacrificial kris
3188	coral claymore
3189	wood chopper
3190	beatstick
3191	arced war axe
3192	short bastard sword
3193	oak mallet
3194	black malice
3195	barbaric battle axe
3196	edged bastard sword
3197	stonecutter claymore
3198	battering hammer
3199	battle slayer
3200	burnt leather bracers
3201	barbarian war axe
3202	forest leather bracers
3203	dense triangle mace
3204	deepwood bracers
3205	inscribed leather bracers
3206	cavalier two hander
3207	hunting bracers
3208	conk hammer
3209	ancient war sword
3210	brutal war axe
3211	burnished bracers
3212	lambent scale bracers
3213	veteran bracers
3214	warrior s bracers
3216	warm winter robe
3217	foreman belt
3218	pyrewood shackle
3220	blood sausage
3222	wicked dagger
3223	frostmane scepter
3224	silver lined bracers
3225	bloodstained knife
3227	nightbane staff
3228	jimmied handcuffs
3229	tarantula silk sash
3230	black wolf bracers
3231	cutthroat pauldrons
3233	gnoll hide sack
3234	deliah s ring
3235	ring of scorn
3236	rot hide ichor
3237	sample ichor
3238	johaan s findings
3239	rough weightstone
3240	coarse weightstone
3241	heavy weightstone
3248	translated letter from the embalmer
3250	bethor s scroll
3251	bethor s potion
3252	deathstalker report
3253	grizzled bear heart
3254	skittering blood
3255	berard s journal
3256	lake skulker moss
3257	lake creeper moss
3258	hardened tumor
3260	scarlet initiate robes
3261	webbed cloak
3262	putrid wooden hammer
3263	webbed pants
3264	duskbat wing
3265	scavenger paw
3266	scarlet armband
3267	forsaken shortsword
3268	forsaken dagger
3269	forsaken maul
3270	flax vest
3272	zombie skin leggings
3273	rugged mail vest
3274	flax boots
3275	flax gloves
3276	deathguard buckler
3277	executor staff
3278	aura proc damage sword
3279	battle chain boots
3280	battle chain bracers
3281	battle chain gloves
3282	battle chain pants
3283	battle chain tunic
3284	tribal boots
3285	tribal bracers
3286	tribal gloves
3287	tribal pants
3288	tribal vest
3289	ancestral boots
3290	ancestral gloves
3291	ancestral woollies
3292	ancestral tunic
3293	deadman cleaver
3294	deadman club
3295	deadman blade
3296	deadman dagger
3297	fel moss
3299	fractured canine
3300	rabbit s foot
3301	sharp canine
3302	brackwater boots
3303	brackwater bracers
3304	brackwater gauntlets
3305	brackwater leggings
3306	brackwater vest
3307	barbaric cloth boots
3308	barbaric cloth gloves
3309	barbaric loincloth
3310	barbaric cloth vest
3311	ceremonial leather ankleguards
3312	ceremonial leather bracers
3313	ceremonial leather harness
3314	ceremonial leather gloves
3315	ceremonial leather loincloth
3316	alaric s head
3317	a talking head
3318	alaric s remains
3319	short sabre
3321	gray fur booties
3322	wispy cloak
3323	ghostly bracers
3324	ghostly mantle
3325	vile fin battle axe
3327	vile fin oracle staff
3328	spider web robe
3329	spiked wooden plank
3330	dargol s hauberk
3331	melrache s cape
3332	perrine s boots
3334	farmer s shovel
3335	farmer s broom
3336	flesh piercer
3337	dragonmaw war banner
3339	dwarven tinder
3340	incendicite ore
3341	gauntlets of ogre strength
3342	captain sander s shirt
3343	captain sander s booty bag
3344	captain sander s sash
3345	silk wizard hat
3347	bundle of crocolisk skins
3348	giant crocolisk skin
3349	sida s bag
3352	ooze covered bag
3353	rune inscribed pendant
3354	dalaran pendant
3355	wild steelbloom
3356	kingsblood
3357	liferoot
3358	khadgar s whisker
3360	stitches femur
3363	frayed belt
3365	frayed bracers
3369	grave moss
3370	patchwork belt
3371	empty vial
3372	leaded vial
3373	patchwork bracers
3374	calico belt
3375	calico bracers
3376	canvas belt
3377	canvas bracers
3378	brocade belt
3379	brocade bracers
3380	cross stitched belt
3381	cross stitched bracers
3382	weak troll s blood potion
3383	elixir of wisdom
3384	minor magic resistance potion
3385	lesser mana potion
3386	elixir of poison resistance
3387	limited invulnerability potion
3388	strong troll s blood potion
3389	elixir of defense
3390	elixir of lesser agility
3391	elixir of ogre s strength
3392	ringed helm
3393	recipe minor magic resistance potion
3394	recipe elixir of poison resistance
3395	recipe limited invulnerability potion
3396	recipe elixir of lesser agility
3397	young crocolisk skin
3399	vulture talon
3400	lucine longsword
3401	rough crocolisk scale
3402	soft patch of fur
3403	ivory boar tusk
3404	buzzard wing
3405	raven claw talisman
3406	black feather quill
3407	sapphire of sky
3408	rune of nesting
3409	nightsaber fang
3411	strigid owl feather
3412	webwood spider silk
3413	doomspike
3414	crested scepter
3415	staff of the friar
3416	martyr s chain
3417	onyx claymore
3418	fel cone
3419	red rose
3420	black rose
3421	simple wildflowers
3422	beautiful wildflowers
3423	bouquet of white roses
3424	bouquet of black roses
3425	woven wand
3426	bold yellow shirt
3427	stylish black shirt
3428	common gray shirt
3429	guardsman belt
3430	sniper rifle
3431	bone studded leather
3434	slumber sand
3435	zombie skin bracers
3437	clasped belt
3439	zombie skin boots
3440	bonecracker
3442	apprentice sash
3443	ceremonial tomahawk
3444	tiller s vest
3445	ceremonial knife
3446	darkwood staff
3447	cryptwalker boots
3448	senggin root
3449	mystic shawl
3450	faerleia s shield
3451	nightglow concoction
3452	ceranium rod
3453	quilted bracers
3454	reconnaissance boots
3455	deathstalker shortsword
3456	dog whistle
3457	stamped trousers
3458	rugged mail gloves
3460	johaan s special drink
3461	high robe of the adjudicator
3462	talonstrike
3463	silver star
3464	feathered arrow
3465	exploding shot
3466	strong flux
3467	dull iron key
3468	renferrel s findings
3469	copper chain boots
3470	rough grinding stone
3471	copper chain vest
3472	runed copper gauntlets
3473	runed copper pants
3474	gemmed copper gauntlets
3475	cloak of flames
3476	gray bear tongue
3477	creeper ichor
3478	coarse grinding stone
3480	rough bronze shoulders
3481	silvered bronze shoulders
3482	silvered bronze boots
3483	silvered bronze gauntlets
3484	green iron boots
3485	green iron gauntlets
3486	heavy grinding stone
3487	heavy copper broadsword
3488	copper battle axe
3489	thick war axe
3490	deadly bronze poniard
3491	heavy bronze mace
3492	mighty iron hammer
3493	raptor s end
3495	elixir of suffering
3496	mountain lion blood
3497	elixir of pain
3498	taretha s necklace
3499	burnished gold key
3502	mudsnout blossoms
3505	alterac signet ring
3506	mudsnout composite
3508	mudsnout mixture
3509	daggerspine scale
3510	torn fin eye
3511	cloak of the people s militia
3514	mor ladim s skull
3515	ataeric s staff
3516	lescovar s head
3517	keg of shindigger stout
3518	decrypted letter
3520	tainted keg
3521	cleverly encrypted letter
3530	wool bandage
3531	heavy wool bandage
3535	red leather c03 bracers
3545	black leather d02 bracers
3550	targ s head
3551	muckrake s head
3552	glommus s head
3553	mug thol s head
3554	crown of will
3555	robe of solomon
3556	dread mage hat
3558	fen keeper robe
3559	night watch gauntlets
3560	mantle of honor
3561	resilient poncho
3562	belt of vindication
3563	seafarer s pantaloons
3564	shipment of iron
3565	beerstained gloves
3566	raptorbane armor
3567	dwarven fishing pole
3569	vicar s robe
3570	bonegrinding pestle
3571	trogg beater
3572	daryl s shortsword
3573	hunting quiver
3574	hunting ammo sack
3575	iron bar
3576	tin bar
3577	gold bar
3578	harvester s pants
3581	serrated knife
3582	acidproof cloak
3583	weathered belt
3585	camouflaged tunic
3586	logsplitter
3587	embroidered belt
3588	embroidered bracers
3589	heavy weave belt
3590	heavy weave bracers
3591	padded belt
3592	padded bracers
3593	russet belt
3594	russet bracers
3595	tattered cloth belt
3596	tattered cloth bracers
3597	thick cloth belt
3598	thick cloth bracers
3599	thin cloth belt
3600	thin cloth bracers
3601	syndicate missive
3602	knitted belt
3603	knitted bracers
3604	bandolier of the night watch
3605	quiver of the night watch
3606	woven belt
3607	woven bracers
3608	plans mighty iron hammer
3609	plans copper chain vest
3610	plans gemmed copper gauntlets
3611	plans green iron boots
3612	plans green iron gauntlets
3613	valdred s hands
3614	yowler s paw
3615	kurzen s head
3616	mind s eye
3617	pendant of shadow
3618	gobbler s head
3619	snellig s snuffbox
3620	lillith s remains
3621	ivar s head
3622	essence of nightlash
3623	thule s head
3625	nek rosh s head
3626	head of baron vardus
3627	fang of vagash
3628	hand of dextren ward
3629	mistmantle family ring
3630	head of targorr
3631	bellygrub s tusk
3632	fangore s paw
3633	head of gath ilzogg
3634	head of grimson
3635	maggot eye s paw
3636	scale of old murk eye
3637	head of vancleef
3638	sarltooth s talon
3639	ear of balgaras
3640	head of deepfury
3641	journeyman s bracers
3642	ancestral bracers
3643	spellbinder bracers
3644	barbaric cloth bracers
3645	seer s cuffs
3647	bright bracers
3649	tribal buckler
3650	battle shield
3651	veteran shield
3652	hunting buckler
3653	ceremonial buckler
3654	brackwater shield
3655	burnished shield
3656	lambent scale shield
3657	hillsbrad town registry
3658	recovered tome
3659	worn leather book
3660	tomes of alterac
3661	handcrafted staff
3662	crocolisk steak
3663	murloc fin soup
3664	crocolisk gumbo
3665	curiously tasty omelet
3666	gooey spider cake
3667	tender crocolisk meat
3668	assassin s contract
3669	gelatinous goo
3670	large slimy bone
3671	lifeless skull
3672	head of nagaz
3673	broken arrow
3674	decomposed boot
3676	slimy ichor
3678	recipe crocolisk steak
3679	recipe blood sausage
3680	recipe murloc fin soup
3681	recipe crocolisk gumbo
3682	recipe curiously tasty omelet
3683	recipe gooey spider cake
3684	perenolde tiara
3685	raptor egg
3688	bloodstone oval
3689	bloodstone marble
3690	bloodstone shard
3691	bloodstone wedge
3692	hillsbrad human skull
3693	humbert s sword
3701	darthalia s sealed commendation
3702	bear gall bladder
3703	southshore stout
3704	rusted iron key
3706	ensorcelled parchment
3707	nagaz parchment
3708	helcular s rod
3710	rod of helcular
3711	belamoore s research journal
3712	turtle meat
3713	soothing spices
3714	worn stone token
3715	bracers of earth binding
3716	murloc head
3717	sack of murloc heads
3718	foreboding plans
3719	hillman s cloak
3720	yeti fur
3721	farren s report
3722	familiar hide
3723	familiar fang
3724	familiar claw
3725	familiar horn
3726	big bear steak
3727	hot lion chops
3728	tasty lion steak
3729	soothing turtle bisque
3730	big bear meat
3731	lion meat
3732	hooded cowl
3733	orcish war chain
3734	recipe big bear steak
3735	recipe hot lion chops
3736	recipe tasty lion steak
3737	recipe soothing turtle bisque
3738	brewing rod
3739	skull ring
3740	decapitating sword
3741	stomping boots
3742	bow of plunder
3743	sentry buckler
3744	bloodstone pendant
3745	rune of opening
3747	meditative sash
3748	feline mantle
3749	high apothecary cloak
3750	ribbed breastplate
3751	mercenary leggings
3752	grunt vest
3753	shepherd s girdle
3754	shepherd s gloves
3755	fish gutter
3758	crusader belt
3759	insulated sage gloves
3760	band of the undercity
3761	deadskull shield
3763	lunar buckler
3764	mantis boots
3765	brigand s pauldrons
3766	gryphon feather quill
3767	fine parchment
3769	broken wand
3770	mutton chop
3771	wild hog shank
3772	conjured spring water
3775	crippling poison
3776	crippling poison ii
3777	lethargy root
3778	taut compound bow
3779	hefty war axe
3780	long barreled musket
3781	broad claymore
3782	large war club
3783	light scimitar
3784	metal stave
3785	keen axe
3786	shiny dirk
3787	stone club
3792	interlaced belt
3793	interlaced boots
3794	interlaced bracers
3795	interlaced cloak
3796	interlaced gloves
3797	interlaced pants
3798	interlaced shoulderpads
3799	interlaced vest
3800	hardened leather belt
3801	hardened leather boots
3802	hardened leather bracers
3803	hardened cloak
3804	hardened leather gloves
3805	hardened leather pants
3806	hardened leather shoulderpads
3807	hardened leather tunic
3808	double mail belt
3809	double mail boots
3810	double mail bracers
3811	double stitched cloak
3812	double mail gloves
3813	double mail pants
3814	double mail shoulderpads
3815	double mail vest
3816	reflective heater
3817	reinforced buckler
3818	fadeleaf
3819	wintersbite
3820	stranglekelp
3821	goldthorn
3822	runic darkblade
3823	lesser invisibility potion
3824	shadow oil
3825	elixir of fortitude
3826	mighty troll s blood potion
3827	mana potion
3828	elixir of detect lesser invisibility
3829	frost oil
3830	recipe elixir of fortitude
3831	recipe mighty troll s blood potion
3832	recipe elixir of detect lesser invisibility
3833	adept s cloak
3834	sturdy cloth trousers
3835	green iron bracers
3836	green iron helm
3837	golden scale coif
3838	shadowmaw claw
3839	pristine tigress fang
3840	green iron shoulders
3841	golden scale shoulders
3842	green iron leggings
3843	golden scale leggings
3844	green iron hauberk
3845	golden scale cuirass
3846	polished steel boots
3847	golden scale boots
3848	big bronze knife
3849	hardened iron shortsword
3850	jade serpentblade
3851	solid iron maul
3852	golden iron destroyer
3853	moonsteel broadsword
3854	frost tiger blade
3855	massive iron axe
3856	shadow crescent axe
3857	coal
3858	mithril ore
3859	steel bar
3860	mithril bar
3861	blacksteel bar
3862	aged gorilla sinew
3863	jungle stalker feather
3864	citrine
3866	plans jade serpentblade
3867	plans golden iron destroyer
3868	plans frost tiger blade
3869	plans shadow crescent axe
3870	plans green iron shoulders
3871	plans golden scale shoulders
3872	plans golden scale leggings
3873	plans golden scale cuirass
3874	plans polished steel boots
3875	plans golden scale boots
3876	fang of bhag thera
3877	talon of tethis
3879	paw of sin dall
3880	head of bangalash
3882	buzzard feather
3889	russet hat
3890	studded hat
3891	augmented chain helm
3892	embroidered hat
3893	reinforced leather cap
3894	brigandine helm
3897	dizzy s eye
3898	library scrip
3899	legends of the gurubashi volume 3
3900	pupellyverbos port
3901	bloodscalp tusk
3902	staff of nobles
3904	gan zulah s head
3905	nezzliok s head
3906	balia mah trophy
3907	ziata jai trophy
3908	zul mamwe trophy
3909	broken armor of ana thek
3910	snuff
3911	pulsing blue shard
3912	soul gem
3913	filled soul gem
3914	journeyman s backpack
3915	bloody bone necklace
3916	split bone necklace
3917	singing blue crystal
3918	singing crystal shard
3919	mistvale giblets
3920	bloodsail charts
3921	bloodsail orders
3922	shaky s payment
3923	water elemental bracers
3924	maury s clubbed foot
3925	jon jon s golden spyglass
3926	chucky s huge ring
3927	fine aged cheddar
3928	superior healing potion
3929	maury s loot
3930	maury s key
3931	poisoned spider fang
3932	smotts chest
3935	smotts cutlass
3936	crochet belt
3937	crochet boots
3938	crochet bracers
3939	crochet cloak
3940	crochet gloves
3941	crochet pants
3942	crochet shoulderpads
3943	crochet vest
3944	twill belt
3945	twill boots
3946	twill bracers
3947	twill cloak
3948	twill gloves
3949	twill pants
3950	twill shoulderpads
3951	twill vest
3952	mesh belt
3953	mesh boots
3954	mesh bracers
3955	mesh cloak
3956	mesh gloves
3957	mesh pants
3958	mesh mantle
3959	mesh armor
3960	bag of water elemental bracers
3961	thick leather belt
3962	thick leather boots
3963	thick leather bracers
3964	thick cloak
3965	thick leather gloves
3966	thick leather pants
3967	thick leather shoulderpads
3968	thick leather tunic
3969	smooth leather belt
3970	smooth leather boots
3971	smooth leather bracers
3972	smooth cloak
3973	smooth leather gloves
3974	smooth leather pants
3975	smooth leather shoulderpads
3976	smooth leather armor
3977	strapped belt
3978	strapped boots
3979	strapped bracers
3980	strapped cloak
3981	strapped gloves
3982	strapped pants
3983	strapped shoulderpads
3984	strapped armor
3985	monogrammed sash
3986	protective pavise
3987	deflecting tower
3988	plate wall shield
3989	blocking targe
3990	crested buckler
3991	plated buckler
3992	laminated scale belt
3993	laminated scale boots
3994	laminated scale bracers
3995	laminated scale cloak
3996	laminated scale gloves
3997	laminated scale pants
3998	laminated scale shoulderpads
3999	laminated scale armor
4000	overlinked chain belt
4001	overlinked chain boots
4002	overlinked chain bracers
4003	overlinked chain cloak
4004	overlinked chain gloves
4005	overlinked chain pants
4006	overlinked chain shoulderpads
4007	overlinked chain armor
4008	sterling chain belt
4009	sterling chain boots
4010	sterling chain bracers
4011	sterling chain cloak
4012	sterling chain gloves
4013	sterling chain pants
4014	sterling chain shoulderpads
4015	sterling chain armor
4016	zanzil s mixture
4017	sharp shortsword
4018	whetted claymore
4019	heavy flint axe
4020	splintering battle axe
4021	blunting mace
4022	crushing maul
4023	fine pointed dagger
4024	heavy war staff
4025	balanced long bow
4026	sentinel musket
4027	catelyn s blade
4028	bundle of akiris reeds
4029	akiris reed
4034	stone of the tides
4035	silver thread robe
4036	silver thread cuffs
4037	silver thread pants
4038	nightsky robe
4039	nightsky cowl
4040	nightsky gloves
4041	aurora cowl
4042	aurora gloves
4043	aurora bracers
4044	aurora pants
4045	mistscape bracers
4046	mistscape pants
4047	mistscape boots
4048	emblazoned hat
4049	emblazoned bracers
4050	emblazoned leggings
4051	emblazoned boots
4052	insignia cap
4053	large river crocolisk skin
4054	insignia leggings
4055	insignia boots
4056	cortello s riddle
4057	insignia chestguard
4058	glyphed breastplate
4059	glyphed bracers
4060	glyphed leggings
4061	imperial leather bracers
4062	imperial leather pants
4063	imperial leather gloves
4064	emblazoned buckler
4065	combat shield
4066	insignia buckler
4067	glyphed buckler
4068	chief brigadier shield
4069	blackforge buckler
4070	jouster s crest
4071	glimmering mail breastplate
4072	glimmering mail gauntlets
4073	glimmering mail greaves
4074	mail combat armor
4075	mail combat gauntlets
4076	mail combat boots
4077	mail combat headguard
4078	chief brigadier coif
4079	chief brigadier leggings
4080	blackforge cowl
4082	blackforge breastplate
4083	blackforge gauntlets
4084	blackforge leggings
4085	krazek s crock pot
4086	flash rifle
4087	trueshot bow
4088	dreadblade
4089	ricochet blunderbuss
4090	mug o hurt
4091	widowmaker
4092	prismatic basilisk scale
4093	large basilisk tail
4094	tablet shard
4096	coarse gorilla hair
4097	chipped gorilla tooth
4098	carefully folded note
4099	tuft of gorilla hair
4100	crumpled note
4101	ripped note
4102	torn note
4103	shackle key
4104	snapjaw crocolisk skin
4105	elder crocolisk skin
4106	tumbled crystal
4107	tiger hunter gloves
4108	panther hunter leggings
4109	excelsior boots
4110	master hunter s bow
4111	master hunter s rifle
4112	choker of the high shaman
4113	medicine blanket
4114	darktide cape
4115	grom gol buckler
4116	olmann sewar
4117	scorching sash
4118	poobah s nose ring
4119	raptor hunter tunic
4120	robe of crystal waters
4121	gemmed gloves
4122	bookmaker s scepter
4123	frost metal pauldrons
4124	cap of harmony
4125	tranquil orb
4126	guerrilla cleaver
4127	shrapnel blaster
4128	silver spade
4129	collection plate
4130	smotts compass
4131	belt of corruption
4132	darkspear armsplints
4133	darkspear cuffs
4134	nimboya s mystical staff
4135	bloodbone band
4136	darkspear boots
4137	darkspear shoes
4138	blackwater tunic
4139	junglewalker sandals
4140	palm frond mantle
4190	feathered armor
4194	feathered bracers
4195	feathered boots
4197	berylline pads
4213	grimoire of doom
4231	cured light hide
4232	medium hide
4233	cured medium hide
4234	heavy leather
4235	heavy hide
4236	cured heavy hide
4237	handstitched leather belt
4238	linen bag
4239	embossed leather gloves
4240	woolen bag
4241	green woolen bag
4242	embossed leather pants
4243	fine leather tunic
4244	hillman s leather vest
4245	small silk pack
4246	fine leather belt
4247	hillman s leather gloves
4248	dark leather gloves
4249	dark leather belt
4250	hillman s belt
4251	hillman s shoulders
4252	dark leather shoulders
4253	toughened leather gloves
4254	barbaric gloves
4255	green leather armor
4256	guardian armor
4257	green leather belt
4258	guardian belt
4259	green leather bracers
4260	guardian leather bracers
4261	solliden s trousers
4262	gem studded leather belt
4263	standard issue shield
4264	barbaric belt
4265	heavy armor kit
4278	lesser bloodstone ore
4289	salt
4290	dust bowl
4291	silken thread
4292	pattern green woolen bag
4293	pattern hillman s leather vest
4294	pattern hillman s belt
4296	pattern dark leather shoulders
4297	pattern barbaric gloves
4298	pattern guardian belt
4299	pattern guardian armor
4300	pattern guardian leather bracers
4301	pattern barbaric belt
4302	small green dagger
4303	cranial thumper
4304	thick leather
4305	bolt of silk cloth
4306	silk cloth
4307	heavy linen gloves
4308	green linen bracers
4309	handstitched linen britches
4310	heavy woolen gloves
4311	heavy woolen cloak
4312	soft soled linen boots
4313	red woolen boots
4314	double stitched woolen shoulders
4315	reinforced woolen shoulders
4316	heavy woolen pants
4317	phoenix pants
4318	gloves of meditation
4319	azure silk gloves
4320	spidersilk boots
4321	spider silk slippers
4322	enchanter s cowl
4323	shadow hood
4324	azure silk vest
4325	boots of the enchanter
4326	long silken cloak
4327	icy cloak
4328	spider belt
4329	star belt
4330	stylish red shirt
4331	phoenix gloves
4332	bright yellow shirt
4333	dark silk shirt
4334	formal white shirt
4335	rich purple silk shirt
4336	black swashbuckler s shirt
4337	thick spider s silk
4338	mageweave cloth
4339	bolt of mageweave
4340	gray dye
4341	yellow dye
4342	purple dye
4343	brown linen pants
4344	brown linen shirt
4345	pattern red woolen boots
4346	pattern heavy woolen cloak
4347	pattern reinforced woolen shoulders
4348	pattern phoenix gloves
4349	pattern phoenix pants
4350	pattern spider silk slippers
4351	pattern shadow hood
4352	pattern boots of the enchanter
4353	pattern spider belt
4354	pattern rich purple silk shirt
4355	pattern icy cloak
4356	pattern star belt
4357	rough blasting powder
4358	rough dynamite
4359	handful of copper bolts
4360	rough copper bomb
4361	copper tube
4362	rough boomstick
4363	copper modulator
4364	coarse blasting powder
4365	coarse dynamite
4366	target dummy
4367	small seaforium charge
4368	flying tiger goggles
4369	deadly blunderbuss
4370	large copper bomb
4371	bronze tube
4372	lovingly crafted boomstick
4373	shadow goggles
4374	small bronze bomb
4375	whirring bronze gizmo
4376	flame deflector
4377	heavy blasting powder
4378	heavy dynamite
4379	silver plated shotgun
4380	big bronze bomb
4381	minor recombobulator
4382	bronze framework
4383	moonsight rifle
4384	explosive sheep
4385	green tinted goggles
4386	ice deflector
4387	iron strut
4388	discombobulator ray
4389	gyrochronatom
4390	iron grenade
4391	compact harvest reaper kit
4392	advanced target dummy
4393	craftsman s monocle
4394	big iron bomb
4395	goblin land mine
4396	mechanical dragonling
4397	gnomish cloaking device
4398	large seaforium charge
4399	wooden stock
4400	heavy stock
4401	mechanical squirrel box
4402	small flame sac
4403	portable bronze mortar
4404	silver contact
4405	crude scope
4406	standard scope
4407	accurate scope
4408	schematic mechanical squirrel
4409	schematic small seaforium charge
4410	schematic shadow goggles
4411	schematic flame deflector
4412	schematic moonsight rifle
4413	schematic discombobulator ray
4414	schematic portable bronze mortar
4415	schematic craftsman s monocle
4416	schematic goblin land mine
4417	schematic large seaforium charge
4419	scroll of intellect iii
4421	scroll of protection iii
4422	scroll of stamina iii
4424	scroll of spirit iii
4425	scroll of agility iii
4426	scroll of strength iii
4428	spider palp
4429	deepfury s orders
4430	ethereal talisman
4432	sully balloo s letter
4433	waterlogged envelope
4434	scarecrow trousers
4435	mote of myzrael
4436	jewel encrusted sash
4437	channeler s staff
4438	pugilist bracers
4439	bruiser club
4440	sigil of strom
4441	mackreel s moonshine
4443	grim pauldrons
4444	black husk shield
4445	flesh carver
4446	blackvenom blade
4447	cloak of night
4448	husk of naraxis
4449	naraxis fang
4450	sigil fragment
4453	sigil of thoradin
4454	talon of vultros
4455	raptor hide harness
4456	raptor hide belt
4457	barbecued buzzard wing
4458	sigil of arathor
4459	brittle dragon bone
4460	ripped wing webbing
4461	raptor hide
4462	cloak of rot
4463	beaded raptor collar
4464	trouncing boots
4465	bonefist gauntlets
4466	sigil of trollbane
4467	sigil of ignaeus
4468	sheathed trol kalar
4469	rod of order
4470	simple wood
4471	flint and tinder
4472	scroll of myzrael
4473	eldritch shackles
4474	ravenwood bow
4476	beastwalker robe
4477	nefarious buckler
4478	iridescent scale leggings
4479	burning charm
4480	thundering charm
4481	cresting charm
4482	sealed folder
4483	burning key
4484	cresting key
4485	thundering key
4487	maiden s folly charts
4488	spirit of silverpine charts
4489	maiden s folly log
4490	spirit of silverpine log
4491	goggles of gem hunting
4492	elven gem
4493	elven gems
4494	seahorn s sealed letter
4495	bloodstone amulet
4496	small brown pouch
4497	heavy brown bag
4498	brown leather satchel
4499	huge brown sack
4500	traveler s backpack
4502	sample elven gem
4503	witherbark tusk
4504	dwarven guard cloak
4505	swampland trousers
4506	stromgarde badge
4507	pit fighter s shield
4508	blood tinged armor
4509	seawolf gloves
4510	befouled bloodstone orb
4511	black water hammer
4512	highland raptor eye
4513	raptor heart
4514	sara balloo s plea
4515	marez s head
4516	otto s head
4517	falconcrest s head
4518	torn scroll fragment
4519	crumpled scroll fragment
4520	singed scroll fragment
4521	alterac granite
4522	witherbark medicine pouch
4524	balloo s memorial
4525	trelane s wand of invocation
4526	raptor talon amulet
4527	azure agate
4528	tor gan s orb
4529	enchanted agate
4530	trelane s phylactery
4531	trelane s orb
4532	trelane s ember agate
4533	sealed letter to archmage malin
4534	steel clasped bracers
4535	ironforge memorial ring
4536	shiny red apple
4537	tel abim banana
4538	snapvine watermelon
4539	goldenbark apple
4540	tough hunk of bread
4541	freshly baked bread
4542	moist cornbread
4543	white drakeskin cap
4544	mulgore spice bread
4545	radiant silver bracers
4546	call of the raptor
4547	gnomish zapper
4548	servomechanic sledgehammer
4549	seafire band
4550	coldwater ring
4551	or kalar s head
4552	smooth stone chip
4553	jagged piece of stone
4554	shiny polished stone
4555	thick scaly tail
4556	speckled shell fragment
4557	fiery gland
4558	empty barrel
4560	fine scimitar
4561	scalping tomahawk
4562	severing axe
4563	billy club
4564	spiked club
4565	simple dagger
4566	sturdy quarterstaff
4567	merc sword
4568	grunt axe
4569	staunch hammer
4570	birchwood maul
4571	war knife
4575	medicine staff
4576	light bow
4577	compact shotgun
4580	sabertooth fang
4581	patch of fine fur
4582	soft bushy tail
4583	thick furry mane
4584	large trophy paw
4585	dripping spider mandible
4586	smooth raptor skin
4587	tribal raptor feathers
4588	pristine raptor skull
4589	long elegant feather
4590	curved yellow bill
4591	eagle eye
4592	longjaw mud snapper
4593	bristle whisker catfish
4594	rockscale cod
4595	junglevine wine
4596	discolored healing potion
4597	recipe discolored healing potion
4598	goblin fishing pole
4599	cured ham steak
4600	cherry grog
4601	soft banana bread
4602	moon harvest pumpkin
4603	raw spotted yellowtail
4604	forest mushroom cap
4605	red speckled mushroom
4606	spongy morel
4607	delicious cave mold
4608	raw black truffle
4609	recipe barbecued buzzard wing
4610	carved stone urn
4611	blue pearl
4612	black drake s heart
4613	corroded black box
4614	pendant of myzrael
4615	blacklash s bindings
4616	ryedol s lucky pick
4621	ambassador infernus bracer
4622	sealed note to advisor belgrum
4623	lesser stoneshield potion
4624	recipe lesser stoneshield potion
4625	firebloom
4626	small stone shard
4627	large stone slab
4628	bracers of rock binding
4629	supply crate
4630	scrap metal
4631	tablet of ryun eh
4632	ornate bronze lockbox
4633	heavy bronze lockbox
4634	iron lockbox
4635	hammertoe s amulet
4636	strong iron lockbox
4637	steel lockbox
4638	reinforced steel lockbox
4639	enchanted sea kelp
4640	sign of the earth
4641	hand of dagun
4643	grimsteel cape
4644	the legacy heart
4645	chains of hematus
4646	star of xil yeh
4647	yagyin s digest
4648	sigil of the hammer
4649	bonegrip s note
4650	bel dugur s note
4652	salbac shield
4653	ironheel boots
4654	mysterious fossil
4655	giant clam meat
4656	small pumpkin
4658	warrior s cloak
4659	warrior s girdle
4660	walking boots
4661	bright mantle
4662	journeyman s cloak
4663	journeyman s belt
4665	burnt cloak
4666	burnt leather belt
4668	battle chain cloak
4669	battle chain girdle
4671	ancestral cloak
4672	ancestral belt
4674	tribal cloak
4675	tribal belt
4676	skeletal gauntlets
4677	veteran cloak
4678	veteran girdle
4680	brackwater cloak
4681	brackwater girdle
4683	spellbinder cloak
4684	spellbinder belt
4686	barbaric cloth cloak
4687	barbaric cloth belt
4689	hunting cloak
4690	hunting belt
4692	ceremonial cloak
4693	ceremonial leather belt
4694	burnished pauldrons
4695	burnished cloak
4696	lapidis tankard of tidesippe
4697	burnished girdle
4698	seer s mantle
4699	seer s belt
4700	inscribed leather spaulders
4701	inscribed cloak
4702	prospector s pick
4703	broken tools
4705	lambent scale pauldrons
4706	lambent scale cloak
4707	lambent scale girdle
4708	bright belt
4709	forest leather mantle
4710	forest cloak
4711	glimmering cloak
4712	glimmering mail girdle
4713	silver thread cloak
4714	silver thread sash
4715	emblazoned cloak
4716	combat cloak
4717	mail combat belt
4718	nightsky mantle
4719	nightsky cloak
4720	nightsky sash
4721	insignia mantle
4722	insignia cloak
4723	humbert s pants
4724	humbert s helm
4725	chief brigadier pauldrons
4726	chief brigadier cloak
4727	chief brigadier girdle
4728	twain s shoulder
4729	aurora mantle
4731	glyphed epaulets
4732	glyphed cloak
4733	blackforge pauldrons
4734	mistscape mantle
4735	mistscape cloak
4736	mistscape sash
4737	imperial leather spaulders
4738	imperial leather belt
4739	plainstrider meat
4740	plainstrider feather
4741	stromgarde cavalry leggings
4742	mountain cougar pelt
4743	pulsating crystalline shard
4744	arcane runed bracers
4745	war rider bracers
4746	doomsayer s robe
4747	stormbull well water
4748	redhorn well water
4749	wildmane well water
4751	windfury talon
4752	azure feather
4753	bronze feather
4755	water pitcher
4757	cracked egg shells
4758	prairie wolf paw
4759	plainstrider talon
4765	enamelled broadsword
4766	feral blade
4767	coppercloth gloves
4768	adept s gloves
4769	trophy swoop quill
4770	bristleback belt
4771	harvest cloak
4772	warm cloak
4775	cracked bill
4776	ruffled feather
4777	ironwood maul
4778	heavy spiked mace
4779	dull kodo tooth
4780	kodo horn fragment
4781	whispering vest
4782	solstice robe
4783	totem of hawkwind
4784	lifeless stone
4785	brimstone belt
4786	wise man s belt
4787	burning pitch
4788	agile boots
4789	stable boots
4790	inferno cloak
4791	enchanted water
4792	spirit cloak
4793	sylvan cloak
4794	wolf bracers
4795	bear bracers
4796	owl bracers
4797	fiery cloak
4798	heavy runed cloak
4799	antiquated cloak
4800	mighty chain pants
4801	stalker claws
4802	cougar claws
4803	prairie alpha tooth
4804	prairie wolf heart
4805	flatland cougar femur
4806	plainstrider scale
4807	swoop gizzard
4808	well stone
4809	ambercorn
4810	boulder pads
4813	small leather collar
4814	discolored fang
4816	legionnaire s leggings
4817	blessed claymore
4818	executioner s sword
4819	fizsprocket s clipboard
4820	guardian buckler
4821	bear buckler
4822	owl s disk
4823	water of the seers
4824	blurred axe
4825	callous axe
4826	marauder axe
4827	wizard s belt
4828	nightwind belt
4829	dreamer s belt
4830	saber leggings
4831	stalking pants
4832	mystic sarong
4833	glorious shoulders
4834	venture co documents
4835	elite shoulders
4836	fireproof orb
4837	strength of will
4838	orb of power
4840	long bayonet
4841	horn of arra chea
4843	amethyst runestone
4844	opal runestone
4845	diamond runestone
4846	cog #5
4847	lotwil s shackles of elemental binding
4848	battleboar snout
4849	battleboar flank
4850	bristleback attack plans
4851	dirt stained map
4852	flash bomb
4854	demon scarred cloak
4859	burning blade medallion
4860	glistening frenzy scale
4861	sleek feathered tunic
4862	scorpid worker tail
4863	gnomish tools
4864	minshina s skull
4865	ruined pelt
4866	zalazane s head
4867	broken scorpid leg
4869	fizzle s claw
4870	canvas scraps
4871	searing collar
4872	dry scorpid eye
4873	dry hardened barnacle
4874	clean fishbones
4875	slimy bone
4876	bloody leather boot
4877	stone arrowhead
4878	broken bloodstained bow
4879	squashed rabbit carcass
4880	broken spear
4881	aged envelope
4882	benedict s key
4883	admiral proudmoore s orders
4886	venomtail poison sac
4887	intact makrura eye
4888	crawler mucus
4890	taillasher egg
4891	kron s amulet
4892	durotar tiger fur
4893	savannah lion tusk
4894	plainstrider kidney
4895	thunder lizard horn
4896	kodo liver
4897	thunderhawk saliva gland
4898	lightning gland
4903	eye of burning shadow
4904	venomtail antidote
4905	sarkoth s mangled claw
4906	rainwalker boots
4907	woodland tunic
4908	nomadic bracers
4909	kodo hunter s leggings
4910	painted chain gloves
4911	thick bark buckler
4913	painted chain belt
4914	battleworn leather gloves
4915	soft wool boots
4916	soft wool vest
4917	battleworn chain leggings
4918	sack of supplies
4919	soft wool belt
4920	battleworn cape
4921	dust covered leggings
4922	jagged chain vest
4923	primitive hatchet
4924	primitive club
4925	primitive hand blade
4926	chen s empty keg
4928	sandrunner wristguards
4929	light scorpid armor
4931	hickory shortbow
4932	harpy wing clipper
4933	seasoned fighter s cloak
4935	wide metal girdle
4936	dirt trodden boots
4937	charging buckler
4938	blemished wooden staff
4939	steady bastard sword
4940	veiled grips
4941	really sticky glue
4942	tiger hide boots
4944	handsewn cloak
4945	faintly glowing skull
4946	lightweight boots
4947	jagged dagger
4948	stinging mace
4949	orcish cleaver
4951	squealer s belt
4952	stormstout
4953	trogg ale
4954	nomadic belt
4957	old moneybag
4958	sun beaten cloak
4960	flash pellet
4961	dreamwatcher staff
4962	double layered gloves
4963	thunderhorn cloak
4964	goblin smasher
4967	tribal warrior s shield
4968	bound harness
4969	fortified bindings
4970	rough hewn kodo leggings
4971	skorn s hammer
4972	cliff runner boots
4973	plains hunter wristguards
4974	compact fighting knife
4975	vigilant buckler
4976	mistspray kilt
4977	sword of hammerfall
4978	ryedol s hammer
4979	enchanted stonecloth bracers
4980	prospector gloves
4982	ripped prospector belt
4983	rock pulverizer
4984	skull of impending doom
4986	flawed power stone
4987	dwarf captain s sword
4988	burning obsidian band
4989	mage dragon robe
4990	scorched bands
4992	recruitment letter
4995	signed recruitment letter
4998	blood ring
4999	azora s will
5001	heart ring
5002	glowing green talisman
5003	crystal starfire medallion
5004	mark of the kirin tor
5005	emberspark pendant
5006	khazgorm s journal
5007	band of thorns
5009	mindbender loop
5010	inscribed gold ring
5011	welken ring
5012	fungal spores
5013	fertile bulb
5016	artisan s trousers
5017	nitroglycerin
5018	wood pulp
5019	sodium nitrate
5020	kolkar booty key
5021	explosive stick of gann
5022	barak s head
5023	verog s head
5025	hezrul s head
5026	fire tar
5027	rendered spores
5028	lord sakrasis scepter
5029	talisman of the naga lord
5030	centaur bracers
5038	tear of the moons
5040	shadow hunter knife
5042	red ribboned wrapping paper
5043	red ribboned gift
5044	blue ribboned gift
5045	skull gift
5048	blue ribboned wrapping paper
5049	self locking ironpaper
5050	ignition key
5051	dig rat
5052	unconscious dig rat
5054	samophlange
5055	intact raptor horn
5056	root sample
5057	ripe watermelon
5058	silithid egg
5059	digging claw
5060	thieves tools
5061	stolen silver
5062	raptor head
5063	kreenig snarlsnout s tusk
5064	witchwing talon
5065	harpy lieutenant ring
5066	fissure plant
5067	serena s head
5068	dried seeds
5069	fire wand
5071	shadow wand
5072	lok s skull
5073	nak s skull
5074	kuz s skull
5075	blood shard
5076	shipment of boots
5077	telescopic lens
5078	theramore medal
5079	cold basilisk eye
5080	gazlowe s ledger
5081	kodo hide bag
5082	thin kodo leather
5083	pattern kodo hide bag
5084	baron longshore s head
5085	bristleback quilboar tusk
5086	zhevra hooves
5087	plainstrider beak
5088	control console operating manual
5089	console key
5092	charred razormane wand
5093	razormane backstabber
5094	razormane war shield
5095	rainbow fin albacore
5096	prowler claws
5097	cats eye emerald
5098	altered snapjaw shell
5099	hoof of lakota mani
5100	echeyakee s hide
5101	ishamuhale s fang
5102	owatanka s tailspike
5103	washte pawne s feather
5104	heart of isha awak
5105	explosive shell
5107	deckhand s shirt
5109	stonesplinter rags
5110	dalaran wizard s robe
5111	rathorian s cape
5112	ritual blade
5113	mark of the syndicate
5114	severed talon
5115	broken wishbone
5116	long tail feather
5117	vibrant plume
5118	large flat tooth
5119	fine loose hair
5120	long tail hair
5121	dirty kodo scale
5122	thick kodo hair
5123	steel arrowhead
5124	small raptor tooth
5125	charged scale
5126	knowledge defias disguise
5127	knowledge south seas pirate disguise
5128	shed lizard skin
5129	knowledge dark iron dwarf disguise
5130	knowledge dalaran wizard disguise
5131	knowledge stonesplinter disguise
5132	knowledge syndicate disguise
5133	seeping gizzard
5134	small furry paw
5135	thin black claw
5136	torn furry ear
5137	bright eyeball
5138	harvester s head
5140	flash powder
5143	thunder lizard blood
5164	thunderhawk wings
5165	sunscale feather
5166	webwood venom sac
5167	webwood egg
5168	timberling seed
5169	timberling sprout
5170	mossy tumor
5173	deathweed
5174	note from neeru
5175	earth totem
5176	fire totem
5177	water totem
5178	air totem
5179	moss twined heart
5180	necklace of harmony
5181	vibrant silk cape
5182	shiver blade
5183	pulsating hydra heart
5184	filled crystal phial
5185	crystal phial
5186	partially filled vessel
5187	rhahk zor s hammer
5188	filled vessel
5189	glowing fruit
5190	shimmering frond
5191	cruel barb
5192	thief s blade
5193	cape of the brotherhood
5194	taskmaster axe
5195	gold flecked gloves
5196	smite s reaver
5197	cookie s tenderizer
5198	cookie s stirring rod
5199	smelting pants
5200	impaling harpoon
5201	emberstone staff
5202	corsair s overshirt
5203	flatland prowler claw
5204	bloodfeather belt
5205	sprouted frond
5206	bogling root
5207	opaque wand
5208	smoldering wand
5209	gloom wand
5210	burning wand
5211	dusk wand
5212	blazing wand
5213	scorching wand
5214	wand of eventide
5215	ember wand
5216	umbral wand
5217	tainted heart
5218	cleansed timberling heart
5219	inscribed bark
5220	gnarlpine fang
5221	melenas head
5223	empty mana gem
5229	handstitched leather bracers
5232	minor soulstone
5233	stone of relu
5234	flagongut s fossil
5236	combustible wand
5237	mind numbing poison
5238	pitchwood wand
5239	blackbone wand
5240	torchlight wand
5241	dwarven flamestick
5242	cinder wand
5243	firebelcher
5244	consecrated wand
5245	summoner s wand
5246	excavation rod
5247	rod of sorrow
5248	flash wand
5249	burning sliver
5250	charred wand
5251	phial of scrying
5252	wand of decay
5253	goblin igniter
5254	rugged spaulders
5255	quilboar tomahawk
5256	kovork s rattle
5257	dark hooded cape
5263	pocket lint
5264	complimentary beer token
5266	eye of adaegus
5267	scarlet kris
5268	cracked silithid shell
5269	silithid ichor
5270	death cap
5271	scaber stalk
5272	insane scribbles
5273	mathystra relic
5274	rose mantle
5275	binding girdle
5279	harpy skinner
5299	gloves of the moon
5302	cobalt buckler
5306	wind rider staff
5309	privateer musket
5310	sea dog britches
5311	buckled boots
5312	riveted gauntlets
5313	totemic clan ring
5314	boar hunter s cape
5315	timberland armguards
5316	barkshell tunic
5317	dry moss tunic
5318	zhovur axe
5319	bashing pauldrons
5320	padded lamellar boots
5321	elegant shortsword
5322	demolition hammer
5323	everglow lantern
5324	engineer s hammer
5325	welding shield
5326	flaring baton
5327	greasy tinker s pants
5328	cinched belt
5329	cat figurine
5330	elven cup relic
5332	glowing cat figurine
5335	a sack of coins
5336	grell earring
5337	wayfaring gloves
5338	ancient moonstone seal
5339	serpentbloom
5340	cauldron stirrer
5341	spore covered tunic
5342	raptor punch
5343	barkeeper s cloak
5344	pointed axe
5345	stonewood hammer
5346	orcish battle bow
5347	pestilent wand
5348	worn parchment
5349	conjured muffin
5350	conjured water
5351	bounty hunter s ring
5352	book the powers below
5353	message for elissa starbreeze
5354	letter to delgren
5355	beastmaster s girdle
5356	branding rod
5357	ward of the vale
5359	lorgalis manuscript
5360	highborne relic
5361	fishbone toothpick
5362	chew toy
5363	folded handkerchief
5364	dry salt lick
5366	glowing soul gem
5367	primitive rock tool
5368	empty wallet
5369	gnawed bone
5370	bent spoon
5371	piece of coral
5373	lucky charm
5374	small pocket watch
5375	scratching stick
5376	broken mirror
5377	scallop shell
5379	boot knife
5380	sealed letter to elissa
5381	sealed letter to balthule
5382	anaya s pendant
5383	athrikus narassin s head
5385	crawler leg
5386	fine moonstalker pelt
5387	enchanted moonstalker cloak
5388	ran bloodtooth s skull
5389	corrupted furbolg totem
5390	fandral s message
5391	rare earth
5392	thistlewood dagger
5393	thistlewood staff
5394	archery training gloves
5395	woodland shield
5396	key to searing gorge
5397	defias gunpowder
5398	canopy leggings
5399	tracking boots
5404	serpent s shoulders
5405	draped cloak
5406	empty minor bloodstone
5411	winterhoof cleansing totem
5412	thresher eye
5413	moonstalker fang
5414	grizzled scalp
5415	thunderhorn cleansing totem
5416	wildmane cleansing totem
5419	feral bracers
5420	banshee armor
5421	fiery blaze enchantment
5422	brambleweed leggings
5423	boahn s fang
5424	ancient statuette
5425	runescale girdle
5426	serpent s kiss
5427	crude pocket watch
5428	an exotic cookbook
5429	a pretty rock
5430	intricate bauble
5431	empty hip flask
5432	hickory pipe
5433	rag doll
5435	shiny dinglehopper
5437	bathran s hair
5439	small quiver
5440	bottle of disease
5441	small shot pouch
5442	head of arugal
5443	gold plated buckler
5444	miner s cape
5445	ring of zoram
5446	broken elemental bracer
5447	damaged elemental bracer
5448	fractured elemental bracer
5451	crushed elemental bracer
5455	divined scroll
5456	divining scroll
5457	severed voodoo claw
5458	dirtwood belt
5459	defender axe
5460	orendil s cure
5461	branch of cenarius
5462	dartol s rod of transformation
5463	glowing gem
5464	iron shaft
5465	small spider leg
5466	scorpid stinger
5467	kodo meat
5468	soft frenzy flesh
5469	strider meat
5470	thunder lizard tail
5471	stag meat
5472	kaldorei spider kabob
5473	scorpid surprise
5474	roasted kodo meat
5475	wooden key
5476	fillet of frenzy
5477	strider stew
5478	dig rat stew
5479	crispy lizard tail
5480	lean venison
5481	satyr horns
5482	recipe kaldorei spider kabob
5483	recipe scorpid surprise
5484	recipe roasted kodo meat
5485	recipe fillet of frenzy
5486	recipe strider stew
5487	recipe dig rat stew
5488	recipe crispy lizard tail
5489	recipe lean venison
5490	wrathtail head
5493	elune s tear
5494	handful of stardust
5498	small lustrous pearl
5500	iridescent pearl
5503	clam meat
5504	tangy clam meat
5505	teronis journal
5506	beady eye stalk
5507	ornate spyglass
5508	fallen moonstone
5509	healthstone
5510	greater healthstone
5511	lesser healthstone
5512	minor healthstone
5513	mana jade
5514	mana agate
5516	threshadon fang
5517	tiny bronze key
5518	tiny iron key
5519	iron pommel
5520	velinde s journal
5521	velinde s key
5522	spellstone
5523	small barnacled clam
5524	thick shelled clam
5525	boiled clams
5526	clam chowder
5527	goblin deviled clams
5528	recipe clam chowder
5529	tomb dust
5530	blinding powder
5533	ilkrud magthrull s tome
5534	parker s lunch
5535	compendium of the fallen
5536	mythology of the titans
5537	sarilus foulborne s head
5538	vorrel s wedding ring
5539	letter of commendation
5540	pearl handled dagger
5541	iridescent hammer
5542	pearl clasped cloak
5543	plans iridescent hammer
5544	dal bloodclaw s skull
5547	reconstructed rod
5565	infernal stone
5566	broken antler
5567	silver hook
5568	smooth pebble
5569	seaweed
5570	deepmoss egg
5571	small black pouch
5572	small green pouch
5573	green leather bag
5574	white leather bag
5575	large green sack
5576	large brown sack
5577	plans rough bronze bracers
5578	plans silvered bronze breastplate
5579	militia warhammer
5580	militia hammer
5581	smooth walking staff
5582	stonetalon sap
5583	fey dragon scale
5584	twilight whisker
5585	courser eye
5586	thistlewood blade
5587	thornroot club
5588	lydon s toxin
5589	moss covered gauntlets
5590	cord bracers
5591	rain spotted cape
5592	shackled girdle
5593	crag buckler
5594	letter to jin zil
5595	thicket hammer
5596	ashwood bow
5601	hatched egg sac
5602	sticky spider webbing
5604	elven wand
5605	pruning knife
5606	gardening gloves
5608	living cowl
5609	steadfast cinch
5610	gustweald cloak
5611	tear of grief
5612	ivy cuffs
5613	staff of the purifier
5614	seraph s strike
5615	woodsman sword
5616	gutwrencher
5617	vagabond leggings
5618	scout s cloak
5619	jade phial
5620	vial of innocent blood
5621	tourmaline phial
5622	clergy ring
5623	amethyst phial
5624	circlet of the order
5626	skullchipper
5627	relic blade
5628	zamah s note
5629	hammerfist gloves
5630	windfelt gloves
5631	rage potion
5633	great rage potion
5634	free action potion
5635	sharp claw
5636	delicate feather
5637	large fang
5638	toxic fogger
5639	filled jade phial
5640	recipe rage potion
5641	recipe cowardly flight potion
5642	recipe free action potion
5643	recipe great rage potion
5645	filled tourmaline phial
5646	vial of blessed water
5654	instant toxin
5655	chestnut mare bridle
5656	brown horse bridle
5657	recipe instant toxin
5659	smoldering embers
5664	corroded shrapnel
5665	horn of the dire wolf
5668	horn of the brown wolf
5669	dust devil debris
5675	crystalized scales
5681	corrosive sap
5686	ordanus head
5687	gatekeeper s key
5689	sleepers key
5690	claw key
5691	barrow key
5692	remote detonator red
5693	remote detonator blue
5694	ng 5 explosives red
5695	ng 5 explosives blue
5717	venture co letters
5718	venture co engineering plans
5731	scroll of messaging
5732	ng 5
5733	unidentified ore
5734	super reaper 6000 blueprints
5735	sealed envelope
5736	gerenzo s mechanical arm
5737	covert ops plans alpha & beta
5738	covert ops pack
5739	barbaric harness
5740	red fireworks rocket
5741	rock chip
5742	gemstone dagger
5743	prismstone ring
5744	pale skinner
5748	centaur longbow
5749	scythe axe
5750	warchief s girdle
5751	webwing cloak
5752	wyvern tailspike
5753	ruffled chaplet
5754	wolfpack medallion
5755	onyx shredder plate
5756	sliverblade
5757	hardwood cudgel
5758	mithril lockbox
5759	thorium lockbox
5760	eternium lockbox
5761	anvilmar sledge
5762	red linen bag
5763	red woolen bag
5764	green silk pack
5765	black silk pack
5766	lesser wizard s robe
5767	violet robes
5768	gnome race ticket
5769	goblin race ticket
5770	robes of arcana
5771	pattern red linen bag
5772	pattern red woolen bag
5773	pattern robes of arcana
5774	pattern green silk pack
5775	pattern black silk pack
5776	elder s cane
5777	brave s axe
5778	primitive walking stick
5779	forsaken bastard sword
5780	murloc scale belt
5781	murloc scale breastplate
5782	thick murloc armor
5783	murloc scale bracers
5784	slimy murloc scale
5785	thick murloc scale
5786	pattern murloc scale belt
5787	pattern murloc scale breastplate
5788	pattern thick murloc armor
5789	pattern murloc scale bracers
5790	lonebrow s journal
5791	henrig lonebrow s journal
5792	razorflank s medallion
5793	razorflank s heart
5794	salty scorpid venom
5795	hardened tortoise shell
5796	encrusted tail fin
5797	indurium flake
5798	rocket car parts
5799	kravel s parts order
5800	kravel s parts
5801	kraul guano
5802	delicate car parts
5803	speck of dream dust
5804	goblin rumors
5805	heart of zeal
5806	fool s stout
5807	fool s stout report
5808	pridewing venom sac
5809	highperch venom sac
5810	fresh carcass
5811	frostmaw s mane
5812	robes of antiquity
5813	emil s brand
5814	snapbrook armor
5815	glacial stone
5816	light of elune
5817	lunaris bow
5818	moonbeam wand
5819	sunblaze coif
5820	faerie mantle
5821	darkstalker boots
5822	hedgeseed gauntlets
5824	tablet of will
5825	treshala s pendant
5826	kravel s scheme
5827	fizzle brassbolts letter
5829	razor sharp beak
5830	kenata s head
5831	fardel s head
5832	marcel s head
5833	indurium ore
5834	mok morokk s snuff
5835	mok morokk s grog
5836	mok morokk s strongbox
5837	steelsnap s rib
5838	kodo skin scroll
5839	journal page
5840	searing tongue
5841	searing heart
5842	unrefined ore sample
5843	grenka s claw
5844	fragments of rok alim
5845	flank of meat
5846	korran s sealed note
5847	mirefin head
5848	hollow vulture bone
5849	crate of crash helmets
5850	belgrom s sealed note
5851	cozzle s key
5852	fuel regulator blueprints
5853	intact silithid carapace
5854	silithid talon
5855	silithid heart
5857	gnome prize box
5858	goblin prize box
5859	party grenade
5860	legacy of the aspects
5861	beginnings of the undead threat
5862	seaforium booster
5863	guild charter
5864	gray ram
5865	modified seaforium booster
5866	sample of indurium ore
5867	etched phial
5868	filled etched phial
5869	cloven hoof
5871	large hoof
5872	brown ram
5873	white ram
5874	harness black ram
5875	harness blue ram
5876	blueleaf tuber
5877	cracked silithid carapace
5878	super snuff
5879	twilight pendant
5880	crate with holes
5881	head of kelris
5882	captain s documents
5883	forked mudrock tongue
5884	unpopped darkmist eye
5897	snufflenose owner s manual
5916	gnome camera key
5917	spy s report
5918	defiant orc head
5919	blackened iron shield
5936	animal skin belt
5937	goblin camera key
5938	pristine crawler leg
5939	sewing gloves
5940	bone buckler
5941	brass scale pants
5942	jeweled pendant
5943	rift bracers
5944	greaves of the people s militia
5945	deadmire s tooth
5946	sealed note to elling
5947	defias docket
5948	letter to jorgen
5949	scrap of paper
5950	reethe s badge
5951	moist towelette
5952	corrupted brain stem
5956	blacksmith hammer
5957	handstitched leather vest
5958	fine leather pants
5959	acidic venom sac
5960	sealed note to watcher backus
5961	dark leather pants
5962	guardian pants
5963	barbaric leggings
5964	barbaric shoulders
5965	guardian cloak
5966	guardian gloves
5967	girdle of nobility
5968	rugged boots
5969	regent s cloak
5970	serpent gloves
5971	feathered cape
5972	pattern fine leather pants
5973	pattern barbaric leggings
5974	pattern guardian cloak
5975	ruffian belt
5976	guild tabard
5996	elixir of water breathing
5997	elixir of minor defense
5998	stormpike s request
6016	wolf heart sample
6037	truesilver bar
6038	giant clam scorcho
6039	recipe giant clam scorcho
6040	golden scale bracers
6041	steel weapon chain
6042	iron shield spike
6043	iron counterweight
6044	plans iron shield spike
6045	plans iron counterweight
6046	plans steel weapon chain
6047	plans golden scale coif
6048	shadow protection potion
6049	fire protection potion
6050	frost protection potion
6051	holy protection potion
6052	nature protection potion
6053	recipe holy protection potion
6054	recipe shadow protection potion
6055	recipe fire protection potion
6056	recipe frost protection potion
6057	recipe nature protection potion
6058	blackened leather belt
6059	nomadic vest
6060	flax bracers
6061	graystone bracers
6062	heavy cord bracers
6063	cold steel gauntlets
6064	miniature platinum discs
6065	khadgar s essays on dimensional convergence
6066	khan dez hepah s head
6067	centaur ear
6068	recipe shadow oil
6069	crudely dried meat
6070	wolfskin bracers
6071	draenethyst crystal
6072	khan jehn s head
6073	khan shaka s head
6074	war horn mouthpiece
6075	vimes s report
6076	tapered pants
6077	maraudine key fragment
6078	pikeman shield
6079	crude charm
6080	shadow panther heart
6081	mire lord fungus
6082	deepstrider tumor
6083	broken tears
6084	stormwind guard leggings
6085	footman tunic
6086	faustin s truth serum
6087	chausses of westfall
6089	zraedus s brew
6091	crate of power stones
6092	black whelp boots
6093	orc crusher
6094	piercing axe
6095	wandering boots
6096	apprentice s shirt
6097	acolyte s shirt
6098	neophyte s robe
6116	apprentice s robe
6117	squire s shirt
6118	squire s pants
6119	neophyte s robe
6120	recruit s shirt
6121	recruit s pants
6122	recruit s boots
6123	novice s robe
6124	novice s pants
6125	brawler s harness
6126	trapper s pants
6127	trapper s boots
6129	acolyte s robe
6134	primitive mantle
6135	primitive kilt
6136	thug shirt
6137	thug pants
6138	thug boots
6139	novice s robe
6140	apprentice s robe
6144	neophyte s robe
6145	clarice s pendant
6146	sundried driftwood
6147	ratty old belt
6148	web covered boots
6149	greater mana potion
6150	a frayed knot
6166	coyote jawbone
6167	neeka s report
6168	sawtooth snapper claw
6169	unprepared sawtooth flank
6170	wizards reagents
6171	wolf handler gloves
6172	lost supplies
6173	snow boots
6174	twain random sword
6175	atal ai artifact
6176	dwarven kite shield
6177	ironwrought bracers
6178	shipment to nethergarde
6179	privateer s cape
6180	slarkskin
6181	fetish of hakkar
6182	dim torch
6183	unlit poor torch
6184	monstrous crawler leg
6185	bear shawl
6186	trogg slicer
6187	dwarven defender
6188	mud stompers
6189	durable chain shoulders
6190	draenethyst shard
6191	kimbra boots
6192	khan hratha s head
6193	bundle of atal ai artifacts
6194	barreling reaper
6195	wax polished armor
6196	noboru s cudgel
6197	loch croc hide vest
6198	jurassic wristguards
6199	black widow band
6200	garneg s war belt
6201	lithe boots
6202	fingerless gloves
6203	thuggish shield
6204	tribal worg helm
6205	burrowing shovel
6206	rock chipper
6207	pvp horde tower plans
6208	pvp alliance tower plans
6209	pvp horde mine deed
6210	pvp alliance mine deed
6211	recipe elixir of ogre s strength
6212	head of jammal an
6214	heavy copper maul
6215	balanced fighting stick
6217	copper rod
6218	runed copper rod
6219	arclight spanner
6220	meteor shard
6223	crest of darkshire
6226	bloody apron
6238	brown linen robe
6239	red linen vest
6240	blue linen vest
6241	white linen robe
6242	blue linen robe
6243	green woolen robe
6245	karnitol s satchel
6246	hatefury claw
6247	hatefury horn
6248	scorpashi venom
6249	aged kodo hide
6250	felhound brain
6251	nether wing
6252	doomwarder blood
6253	leftwitch s package
6256	fishing pole
6257	roc gizzard
6258	ironfur liver
6259	groddoc liver
6260	blue dye
6261	orange dye
6262	galen s journal
6263	blue overalls
6264	greater adept s robe
6265	soul shard
6266	disciple s vest
6267	disciple s pants
6268	pioneer tunic
6269	pioneer trousers
6270	pattern blue linen vest
6271	pattern red linen vest
6272	pattern blue linen robe
6273	pattern green woolen robe
6274	pattern blue overalls
6275	pattern greater adept s robe
6276	musty note
6277	musty parchment
6278	musty scroll
6279	musty letter
6280	musty missive
6281	rattlecage skull
6282	sacred burial trousers
6283	the book of ur
6284	runes of summoning
6285	egalin s grimoire
6286	pure hearts
6287	atal ai tablet fragment
6288	atal ai tablet
6289	raw longjaw mud snapper
6290	brilliant smallfish
6291	raw brilliant smallfish
6293	dried bat blood
6296	patch of bat hair
6297	old skull
6298	bloody bat fang
6299	sickly looking fish
6300	husk fragment
6301	old teamster s skull
6302	delicate insect wing
6303	raw slitherskin mackerel
6304	damp diary page day 4
6305	damp diary page day 87
6306	damp diary page day 512
6307	message in a bottle
6308	raw bristle whisker catfish
6312	dalin s heart
6313	comar s heart
6314	wolfmaster cape
6315	steelarrow crossbow
6316	loch frenzy delight
6317	raw loch frenzy
6318	odo s ley staff
6319	girdle of the blindwatcher
6320	commander s crest
6321	silverlaine s family seal
6323	baron s scepter
6324	robes of arugal
6325	recipe brilliant smallfish
6326	recipe slitherskin mackerel
6327	the pacifier
6328	recipe longjaw mud snapper
6329	recipe loch frenzy delight
6330	recipe bristle whisker catfish
6331	howling blade
6332	black pearl ring
6333	spikelash dagger
6335	grizzled boots
6336	infantry tunic
6337	infantry leggings
6338	silver rod
6339	runed silver rod
6340	fenrus hide
6341	eerie stable lantern
6342	formula enchant chest minor mana
6344	formula enchant bracer minor spirit
6346	formula enchant chest lesser mana
6347	formula enchant bracer minor strength
6348	formula enchant weapon minor beastslayer
6349	formula enchant 2h weapon lesser intellect
6350	rough bronze boots
6351	dented crate
6352	waterlogged crate
6353	small chest
6354	small locked chest
6355	sturdy locked chest
6356	battered chest
6357	sealed crate
6358	oily blackmouth
6359	firefin snapper
6360	steelscale crushfish
6361	raw rainbow fin albacore
6362	raw rockscale cod
6365	strong fishing pole
6366	darkwood fishing pole
6367	big iron fishing pole
6368	recipe rainbow fin albacore
6369	recipe rockscale cod
6370	blackmouth oil
6371	fire oil
6372	swim speed potion
6373	elixir of firepower
6374	enchanted powder
6375	formula enchant bracer lesser spirit
6377	formula enchant boots minor agility
6378	seer s cape
6379	inscribed leather belt
6380	inscribed buckler
6381	bright cloak
6382	forest leather belt
6383	forest buckler
6384	stylish blue shirt
6385	stylish green shirt
6386	glimmering mail legguards
6387	glimmering mail bracers
6388	glimmering mail pauldrons
6389	glimmering mail coif
6390	pattern stylish blue shirt
6391	pattern stylish green shirt
6392	belt of arugal
6393	silver thread gloves
6394	silver thread boots
6395	silver thread amice
6396	emblazoned chestpiece
6397	emblazoned gloves
6398	emblazoned belt
6399	emblazoned shoulders
6400	glimmering shield
6401	pattern dark silk shirt
6402	mail combat leggings
6403	mail combat armguards
6404	mail combat spaulders
6405	nightsky trousers
6406	nightsky boots
6407	nightsky wristbands
6408	insignia gloves
6409	insignia belt
6410	insignia bracers
6411	chief brigadier armor
6412	chief brigadier boots
6413	chief brigadier bracers
6414	seal of sylvanas
6415	aurora robe
6416	aurora boots
6417	aurora cloak
6418	aurora sash
6419	glyphed mitts
6420	glyphed boots
6421	glyphed belt
6422	glyphed helm
6423	blackforge greaves
6424	blackforge cape
6425	blackforge girdle
6426	blackforge bracers
6427	mistscape robe
6428	mistscape gloves
6429	mistscape wizard hat
6430	imperial leather breastplate
6431	imperial leather boots
6432	imperial cloak
6433	imperial leather helm
6435	infused burning gem
6436	burning gem
6438	dull elemental bracer
6439	broken binding bracer
6440	brainlash
6441	shadowstalker scalp
6442	oracle crystal
6443	deviate hide
6444	forked tongue
6445	brittle molting
6446	snakeskin bag
6447	worn turtle shell shield
6448	tail spike
6449	glowing lizardscale cloak
6450	silk bandage
6451	heavy silk bandage
6452	anti venom
6453	strong anti venom
6454	manual strong anti venom
6455	old wagonwheel
6456	acidic slime
6457	rusted engineering parts
6458	oil covered fish
6459	savage trodders
6460	cobrahn s grasp
6461	slime encrusted pads
6462	secure crate
6463	deep fathom ring
6464	wailing essence
6465	robe of the moccasin
6466	deviate scale cloak
6467	deviate scale gloves
6468	deviate scale belt
6469	venomstrike
6470	deviate scale
6471	perfect deviate scale
6472	stinging viper
6473	armor of the fang
6474	pattern deviate scale cloak
6475	pattern deviate scale gloves
6476	pattern deviate scale belt
6477	grassland sash
6478	rat stompers
6479	malem pendant
6480	slick deviate leggings
6481	dagmire gauntlets
6482	firewalker boots
6486	singed scale
6487	vile familiar head
6488	simple tablet
6489	weatherworn parchment
6490	dark parchment
6491	heavy parchment
6492	sooty parchment
6493	tattered parchment
6494	scrawled parchment
6495	weatherbeaten parchment
6496	detailed parchment
6498	inscribed kodo leather
6499	inscribed kodo leather
6500	inscribed kodo leather
6501	inscribed kodo leather
6502	violet scale armor
6503	harlequin robes
6504	wingblade
6505	crescent staff
6506	infantry boots
6507	infantry bracers
6508	infantry cloak
6509	infantry belt
6510	infantry gauntlets
6511	journeyman s robe
6512	disciple s robe
6513	disciple s sash
6514	disciple s cloak
6515	disciple s gloves
6516	imp summoning scroll
6517	pioneer belt
6518	pioneer boots
6519	pioneer bracers
6520	pioneer cloak
6521	pioneer gloves
6522	deviate fish
6523	buckled harness
6524	studded leather harness
6525	grunt s harness
6526	battle harness
6527	ancestral robe
6528	spellbinder robe
6529	shiny bauble
6530	nightcrawlers
6531	barbaric cloth robe
6532	bright baubles
6533	aquadynamic fish attractor
6534	forged steel bars
6535	tablet of verga
6536	willow vest
6537	willow boots
6538	willow robe
6539	willow belt
6540	willow pants
6541	willow gloves
6542	willow cape
6543	willow bracers
6544	voidwalker summoning scroll
6545	soldier s armor
6546	soldier s leggings
6547	soldier s gauntlets
6548	soldier s girdle
6549	soldier s cloak
6550	soldier s wristguards
6551	soldier s boots
6552	bard s tunic
6553	bard s trousers
6554	bard s gloves
6555	bard s cloak
6556	bard s bracers
6557	bard s boots
6558	bard s belt
6559	bard s buckler
6560	soldier s shield
6561	seer s padded armor
6562	shimmering boots
6563	shimmering bracers
6564	shimmering cloak
6565	shimmering gloves
6566	shimmering amice
6567	shimmering armor
6568	shimmering trousers
6569	shimmering robe
6570	shimmering sash
6571	scouting buckler
6572	defender shield
6573	defender boots
6574	defender bracers
6575	defender cloak
6576	defender girdle
6577	defender gauntlets
6578	defender leggings
6579	defender spaulders
6580	defender tunic
6581	scouting belt
6582	scouting boots
6583	scouting bracers
6584	scouting tunic
6585	scouting cloak
6586	scouting gloves
6587	scouting trousers
6588	scouting spaulders
6590	battleforge boots
6591	battleforge wristguards
6592	battleforge armor
6593	battleforge cloak
6594	battleforge girdle
6595	battleforge gauntlets
6596	battleforge legguards
6597	battleforge shoulderguards
6598	dervish buckler
6599	battleforge shield
6600	dervish belt
6601	dervish boots
6602	dervish bracers
6603	dervish tunic
6604	dervish cape
6605	dervish gloves
6607	dervish leggings
6608	bright armor
6609	sage s cloth
6610	sage s robe
6611	sage s sash
6612	sage s boots
6613	sage s bracers
6614	sage s cloak
6615	sage s gloves
6616	sage s pants
6617	sage s mantle
6620	elaborate parchment
6622	sword of zeal
6623	succubus summoning scroll
6624	ken zigla s draught
6625	dirt caked pendant
6626	dogran s pendant
6627	mutant scale breastplate
6628	raven s claws
6629	sporid cape
6630	seedcloud buckler
6631	living root
6632	feyscale cloak
6633	butcher s slicer
6634	ritual salve
6635	earth sapta
6636	fire sapta
6637	water sapta
6638	air sapta
6640	felstalker hoof
6641	haunting blade
6642	phantom armor
6643	bloated smallfish
6645	bloated mud snapper
6647	bloated catfish
6648	stoneskin totem scroll
6649	searing totem scroll
6650	healing stream totem scroll
6651	broken wine bottle
6652	reagent pouch
6653	torch of the dormant flame
6654	torch of the eternal flame
6655	glowing ember
6656	rough quartz
6657	savory deviate delight
6658	example collar
6659	scarab trousers
6660	julie s dagger
6661	recipe savory deviate delight
6662	elixir of giant growth
6663	recipe elixir of giant growth
6664	voodoo mantle
6665	hexed bracers
6666	dredge boots
6667	engineer s cloak
6668	draftsman boots
6669	sacred band
6670	panther armor
6671	juggernaut leggings
6672	schematic flash bomb
6675	tempered bracers
6676	constable buckler
6677	spellcrafter wand
6678	band of elven grace
6679	armor piercer
6681	thornspike
6682	death speaker robes
6684	snufflenose command stick
6685	death speaker mantle
6686	tusken helm
6687	corpsemaker
6688	whisperwind headdress
6689	wind spirit staff
6690	ferine leggings
6691	swinetusk shank
6692	pronged reaver
6693	agamaggan s clutch
6694	heart of agamaggan
6695	stygian bone amulet
6696	nightstalker bow
6697	batwing mantle
6709	moonglow vest
6710	pattern moonglow vest
6712	practice lock
6713	ripped pants
6714	ez thro dynamite
6715	ruined jumper cables
6716	schematic ez thro dynamite
6717	gaffer jack
6718	electropeller
6719	windborne belt
6720	spirit hunter headdress
6721	chestplate of kor
6722	beastial manacles
6723	medal of courage
6725	marbled buckler
6726	razzeric s customized seatbelt
6727	razzeric s racing grips
6729	fizzle s zippy lighter
6730	ironforge chain
6731	ironforge breastplate
6732	gnomish mechanic s gloves
6733	ironforge gauntlets
6734	plans ironforge chain
6735	plans ironforge breastplate
6736	plans ironforge gauntlets
6737	dryleaf pants
6738	bleeding crescent
6739	cliffrunner s aim
6740	azure sash
6741	orcish war sword
6742	stonefist girdle
6743	sustaining ring
6744	gloves of kapelan
6745	swiftrunner cape
6746	basalt buckler
6747	enforcer pauldrons
6748	monkey ring
6749	tiger band
6750	snake hoop
6751	mourning shawl
6752	lancer boots
6753	feather charm
6755	a small container of gems
6756	jewelry box
6757	jaina s signet ring
6766	flayed demon skin old2
6767	tyranis pendant
6773	gelkis marauder chain
6774	uthek s finger
6775	tome of divinity
6776	tome of valor
6777	tome of righteousness
6778	tome of justice
6779	tome of nobility
6780	lilac sash
6781	bartleby s mug
6782	marshal haggard s badge
6783	dead tooth s key
6784	braced handguards
6785	powers of the void
6786	simple dress
6787	white woolen dress
6788	magram hunter s belt
6789	ceremonial centaur blanket
6790	ring of calm
6791	hellion boots
6792	sanguine pauldrons
6793	auric bracers
6794	stormfire gauntlets
6795	white swashbuckler s shirt
6796	red swashbuckler s shirt
6797	eyepoker
6798	blasting hackbut
6799	vejrek s head
6800	umbral ore
6801	baroque apron
6802	sword of omen
6803	prophetic cane
6804	windstorm hammer
6805	horn of vorlus
6806	dancing flame
6807	frog leg stew
6808	elunite ore
6809	elura s medallion
6810	surena s choker
6811	aquadynamic fish lens
6812	case of elunite
6826	brilliant scale
6827	box of supplies
6828	visionary buckler
6829	sword of serenity
6830	bonebiter
6831	black menace
6832	cloak of blight
6833	white tuxedo shirt
6834	black tuxedo
6835	black tuxedo pants
6836	dress shoes
6838	scorched spider fang
6839	charred horn
6840	galvanized horn
6841	vial of phlogiston
6842	furen s instructions
6843	cask of scalder
6844	burning blood
6845	burning rock
6846	defias script
6847	dark iron script
6848	searing coral
6849	sunscorched shell
6850	bloodscalp scalp
6851	essence of the exile
6852	eternal eye
6866	symbol of life
6887	spotted yellowtail
6888	herb baked egg
6889	small egg
6890	smoked bear meat
6891	recipe herb baked egg
6892	recipe smoked bear meat
6893	workshop key
6894	whirlwind heart
6895	jordan s smithing hammer
6898	orb of soran ruk
6900	enchanted gold bloodrobe
6901	glowing thresher cape
6902	bands of serra kis
6903	gaze dreamer pants
6904	bite of serra kis
6905	reef axe
6906	algae fists
6907	tortoise armor
6908	ghamoo ra s bind
6909	strike of the hydra
6910	leech pants
6911	moss cinch
6912	heartswood
6913	heartswood core
6914	soran ruk fragment
6915	large soran ruk fragment
6916	tome of divinity
6926	furen s notes
6927	big will s ear
6928	bloodstone choker
6929	bath rah s parchment
6930	rod of channeling
6931	moldy tome
6947	instant poison
6948	hearthstone
6949	instant poison ii
6950	instant poison iii
6951	mind numbing poison ii
6952	thick bear fur
6953	verigan s fist
6966	elunite axe
6967	elunite sword
6968	elunite hammer
6969	elunite dagger
6970	furen s favor
6971	fire hardened coif
6972	fire hardened hauberk
6973	fire hardened leggings
6974	fire hardened gauntlets
6975	whirlwind axe
6976	whirlwind warhammer
6977	whirlwind sword
6978	umbral axe
6979	haggard s axe
6980	haggard s dagger
6981	umbral dagger
6982	umbral mace
6983	haggard s hammer
6984	umbral sword
6985	haggard s sword
6986	crimson lotus
6987	fish scale
6988	felhunter summoning scroll
6989	vial of hatefury blood
6990	lesser infernal stone
6991	smoldering coal
6992	jordan s ore shipment
6993	jordan s refined ore shipment
6994	whitestone oak lumber
6995	corrupted kor gem
6996	jordan s weapon notes
6997	tattered manuscript
6998	nimbus boots
6999	tome of the cabal
7000	heartwood girdle
7001	gravestone scepter
7002	arctic buckler
7003	beetle clasps
7004	prelacy cape
7005	skinning knife
7006	reconstructed tome
7007	backus phat lewt
7026	linen belt
7027	boots of darkness
7046	azure silk pants
7047	hands of darkness
7048	azure silk hood
7049	truefaith gloves
7050	silk headband
7051	earthen vest
7052	azure silk belt
7053	azure silk cloak
7054	robe of power
7055	crimson silk belt
7056	crimson silk cloak
7057	green silken shoulders
7058	crimson silk vest
7059	crimson silk shoulders
7060	azure shoulders
7061	earthen silk belt
7062	crimson silk pantaloons
7063	crimson silk robe
7064	crimson silk gloves
7065	green silk armor
7067	elemental earth
7068	elemental fire
7069	elemental air
7070	elemental water
7071	iron buckle
7072	naga scale
7073	broken fang
7074	chipped claw
7075	core of earth
7076	essence of earth
7077	heart of fire
7078	essence of fire
7079	globe of water
7080	essence of water
7081	breath of wind
7082	essence of air
7083	purified kor gem
7084	pattern crimson silk shoulders
7085	pattern azure shoulders
7086	pattern earthen silk belt
7087	pattern crimson silk cloak
7088	pattern crimson silk robe
7089	pattern azure silk cloak
7090	pattern green silk armor
7091	pattern truefaith gloves
7092	pattern hands of darkness
7093	pattern boots of darkness
7094	driftwood branch
7095	bog boots
7096	plucked feather
7097	leg meat
7098	splintered tusk
7099	severed pincer
7100	sticky ichor
7101	bug eye
7106	zodiac gloves
7107	belt of the stars
7108	infantry shield
7109	pioneer buckler
7110	silver thread armor
7111	nightsky armor
7112	aurora armor
7113	mistscape armor
7114	pattern azure silk gloves
7115	heirloom axe
7116	heirloom dagger
7117	heirloom hammer
7118	heirloom sword
7119	twitching antenna
7120	ruga s bulwark
7126	smoky iron ingot
7127	powdered azurite
7128	uncloven satyr hoof
7129	brutal gauntlets
7130	brutal helm
7131	dragonmaw shinbone
7132	brutal legguards
7133	brutal hauberk
7134	sturdy dragonmaw shinbone
7135	broken dragonmaw shinbone
7146	the scarlet key
7148	goblin jumper cables
7166	copper dagger
7170	twain random sword foo
7188	stormwind guard shield
7189	goblin rocket boots
7190	scorched rocket boots
7191	fused wiring
7192	schematic goblin rocket boots
7206	mirror lake water sample
7207	jennea s flask
7208	tazan s key
7209	tazan s satchel
7226	mage tastic gizmonitor
7227	balnir snapdragons
7228	tigule and foror s strawberry ice cream
7229	explorer s vest
7230	smite s mighty hammer
7231	astor s letter of introduction
7247	chest of containment coffers
7249	charged rift gem
7266	ur s treatise on shadow magic
7267	pristine spider silk
7268	xavian water sample
7269	deino s flask
7270	laughing sister s hair
7271	flawless ivory tusk
7272	bolt charged bramble
7273	witherbark totem stick
7274	rituals of power
7275	the agamaggan scrolls
7276	handstitched leather cloak
7277	handstitched leather bracers
7278	light leather quiver
7279	small leather ammo pouch
7280	rugged leather pants
7281	light leather bracers
7282	light leather pants
7283	black whelp cloak
7284	red whelp gloves
7285	nimble leather gloves
7286	black whelp scale
7287	red whelp scale
7288	pattern rugged leather pants
7289	pattern black whelp cloak
7290	pattern red whelp gloves
7291	infernal orb
7292	filled containment coffer
7293	dalaran mana gem
7294	andron s ledger
7295	tazan s logbook
7296	extinguished torch
7297	morbent s bane
7298	blade of cunning
7306	fenwick s head
7307	flesh eating worm
7308	cantation of manifestation
7309	dalaran status report
7326	thun grim s axe
7327	thun grim s dagger
7328	thun grim s mace
7329	thun grim s sword
7330	infiltrator buckler
7331	phalanx shield
7332	regal armor
7333	overseer s whistle
7334	efflorescent robe
7335	grizzly tunic
7336	wildwood chain
7337	the rock
7338	mood ring
7339	miniscule diamond ring
7340	flawless diamond solitaire
7341	cubic zirconia ring
7342	silver piffeny band
7343	bingles wrench
7344	torch of holy flame
7345	bingles screwdriver
7346	bingles hammer
7347	bingles cog inverter
7348	fletcher s gloves
7349	herbalist s gloves
7350	disciple s bracers
7351	disciple s boots
7352	earthen leather shoulders
7353	elder s padded armor
7354	elder s boots
7355	elder s bracers
7356	elder s cloak
7357	elder s hat
7358	pilferer s gloves
7359	heavy earthen gloves
7360	pattern dark leather gloves
7361	pattern herbalist s gloves
7362	pattern earthen leather shoulders
7363	pattern pilferer s gloves
7364	pattern heavy earthen gloves
7365	gnoam sprecklesprocket
7366	elder s gloves
7367	elder s mantle
7368	elder s pants
7369	elder s robe
7370	elder s sash
7371	heavy quiver
7372	heavy leather ammo pouch
7373	dusky leather leggings
7374	dusky leather armor
7375	green whelp armor
7376	bingles blastencapper
7377	frost leather cloak
7378	dusky bracers
7386	green whelp bracers
7387	dusky belt
7388	skull key
7389	venture co ledger
7390	dusky boots
7391	swift boots
7392	green whelp scale
7406	infiltrator cord
7407	infiltrator armor
7408	infiltrator shoulders
7409	infiltrator boots
7410	infiltrator bracers
7411	infiltrator cloak
7412	infiltrator gloves
7413	infiltrator cap
7414	infiltrator pants
7415	dervish spaulders
7416	phalanx bracers
7417	phalanx boots
7418	phalanx breastplate
7419	phalanx cloak
7420	phalanx headguard
7421	phalanx gauntlets
7422	phalanx girdle
7423	phalanx leggings
7424	phalanx spaulders
7425	cyrik s head
7428	shadowcat hide
7429	twilight armor
7430	twilight robe
7431	twilight pants
7432	twilight cowl
7433	twilight gloves
7434	twilight boots
7435	twilight mantle
7436	twilight cape
7437	twilight cuffs
7438	twilight belt
7439	sentinel breastplate
7440	sentinel trousers
7441	sentinel cap
7442	gyromast s key
7443	sentinel gloves
7444	sentinel boots
7445	sentinel shoulders
7446	sentinel cloak
7447	sentinel bracers
7448	sentinel girdle
7449	pattern dusky leather leggings
7450	pattern green whelp armor
7451	pattern green whelp bracers
7452	pattern dusky boots
7453	pattern swift boots
7454	knight s breastplate
7455	knight s legguards
7456	knight s headguard
7457	knight s gauntlets
7458	knight s boots
7459	knight s pauldrons
7460	knight s cloak
7461	knight s bracers
7462	knight s girdle
7463	sentinel buckler
7464	glyphs of summoning
7465	knight s crest
7468	regal robe
7469	regal leggings
7470	regal wizard hat
7471	regal gloves
7472	regal boots
7473	regal mantle
7474	regal cloak
7475	regal cuffs
7476	regal sash
7477	ranger tunic
7478	ranger leggings
7479	ranger helm
7480	ranger gloves
7481	ranger boots
7482	ranger shoulders
7483	ranger cloak
7484	ranger wristguards
7485	ranger cord
7486	captain s breastplate
7487	captain s leggings
7488	captain s circlet
7489	captain s gauntlets
7490	captain s boots
7491	captain s shoulderguards
7492	captain s cloak
7493	captain s bracers
7494	captain s waistguard
7495	captain s buckler
7496	field plate shield
7498	top of gelkak s key
7499	middle of gelkak s key
7500	bottom of gelkak s key
7506	gnomish universal remote
7507	arcane orb
7508	ley orb
7509	manaweave robe
7510	lesser spellfire robes
7511	astral knot robe
7512	nether lace robe
7513	ragefire wand
7514	icefury wand
7515	celestial orb
7516	tabetha s instructions
7517	gossamer tunic
7518	gossamer robe
7519	gossamer pants
7520	gossamer headpiece
7521	gossamer gloves
7522	gossamer boots
7523	gossamer shoulderpads
7524	gossamer cape
7525	gossamer bracers
7526	gossamer belt
7527	cabalist chestpiece
7528	cabalist leggings
7529	cabalist helm
7530	cabalist gloves
7531	cabalist boots
7532	cabalist spaulders
7533	cabalist cloak
7534	cabalist bracers
7535	cabalist belt
7536	champion s wall shield
7537	gothic shield
7538	champion s armor
7539	champion s leggings
7540	champion s helmet
7541	champion s gauntlets
7542	champion s greaves
7543	champion s pauldrons
7544	champion s cape
7545	champion s bracers
7546	champion s girdle
7549	fairy s embrace
7550	warrior s honor
7551	entwined opaline talisman
7552	falcon s hook
7553	band of the unicorn
7554	willow branch
7555	regal star
7556	twilight orb
7557	gossamer rod
7558	shimmering stave
7559	runic cane
7560	schematic gnomish universal remote
7561	schematic goblin jumper cables
7566	agamand family sword
7567	agamand family axe
7568	agamand family dagger
7569	agamand family mace
7586	tharnariun s hope
7587	thun grim s instructions
7606	polar gauntlets
7607	sable wand
7608	seer s fine stein
7609	elder s amber stave
7610	aurora sphere
7611	mistscape stave
7613	pattern green leather armor
7626	bundle of furs
7627	dolanaar delivery
7628	nondescript letter
7629	ukor s burden
7646	crate of inn supplies
7666	shattered necklace
7667	talvash s phial of scrying
7668	bloodstained journal
7669	shattered necklace ruby
7670	shattered necklace sapphire
7671	shattered necklace topaz
7672	shattered necklace power source
7673	talvash s enhancing necklace
7674	delivery to mathias
7675	defias shipping schedule
7676	thistle tea
7678	recipe thistle tea
7679	shrike bat fang
7680	jadespine basilisk scale
7682	torturing poker
7683	bloody brass knuckles
7684	bloodmage mantle
7685	orb of the forgotten seer
7686	ironspine s eye
7687	ironspine s fist
7688	ironspine s ribcage
7689	morbid dawn
7690	ebon vise
7691	embalmed shroud
7708	necrotic wand
7709	blighted leggings
7710	loksey s training stick
7711	robe of doan
7712	mantle of doan
7713	illusionary rod
7714	hypnotic blade
7715	onin s report
7717	ravager
7718	herod s shoulder
7719	raging berserker s helm
7720	whitemane s chapeau
7721	hand of righteousness
7722	triune amulet
7723	mograine s might
7724	gauntlets of divinity
7726	aegis of the scarlet commander
7727	watchman pauldrons
7728	beguiler robes
7729	chesterfall musket
7730	cobalt crusher
7731	ghostshard talisman
7733	staff of prehistoria
7734	six demon bag
7735	jannok s rose
7736	fight club
7737	sethir s journal
7738	evergreen gloves
7739	timberland cape
7740	gni kiv medallion
7741	the shaft of tsol
7742	schematic gnomish cloaking device
7746	explorers league commendation
7747	vile protector
7748	forcestone buckler
7749	omega orb
7750	mantle of woe
7751	vorrel s boots
7752	dreamslayer
7753	bloodspiller
7754	harbinger boots
7755	flintrock shoulders
7756	dog training gloves
7757	windweaver staff
7758	ruthless shiv
7759	archon chestpiece
7760	warchief kilt
7761	steelclaw reaver
7766	empty brown waterskin
7767	empty blue waterskin
7768	empty red waterskin
7769	filled brown waterskin
7770	filled blue waterskin
7771	filled red waterskin
7786	headsplitter
7787	resplendent guardian
7806	lollipop
7807	candy bar
7808	chocolate square
7809	easter dress
7810	vial of purest water
7811	remaining drops of purest water
7812	corrupt manifestation s bracers
7813	shard of water
7846	crag coyote fang
7847	buzzard gizzard
7848	rock elemental shard
7866	empty thaumaturgy vessel
7867	vessel of dragon s blood
7869	lucius s lockbox
7870	thaumaturgy vessel lockbox
7871	token of thievery
7872	rusty thieves tools
7886	untranslated journal
7887	necklace and gem salvage
7888	jarkal s enhancing necklace
7906	horns of nez ra
7907	certificate of thievery
7908	klaven mortwake s journal
7909	aquamarine
7910	star ruby
7911	truesilver ore
7912	solid stone
7913	barbaric iron shoulders
7914	barbaric iron breastplate
7915	barbaric iron helm
7916	barbaric iron boots
7917	barbaric iron gloves
7918	heavy mithril shoulder
7919	heavy mithril gauntlet
7920	mithril scale pants
7921	heavy mithril pants
7922	steel plate helm
7923	defias tower key
7924	mithril scale bracers
7925	mithril scale gloves
7926	ornate mithril pants
7927	ornate mithril gloves
7928	ornate mithril shoulder
7929	orcish war leggings
7930	heavy mithril breastplate
7931	mithril coif
7932	mithril scale shoulders
7933	heavy mithril boots
7934	heavy mithril helm
7935	ornate mithril breastplate
7936	ornate mithril boots
7937	ornate mithril helm
7938	truesilver gauntlets
7939	truesilver breastplate
7941	heavy mithril axe
7942	blue glittering axe
7943	wicked mithril blade
7944	dazzling mithril rapier
7945	big black mace
7946	runed mithril hammer
7947	ebon shiv
7954	the shatterer
7955	copper claymore
7956	bronze warhammer
7957	bronze greatsword
7958	bronze battle axe
7959	blight
7960	truesilver champion
7961	phantom blade
7963	steel breastplate
7964	solid sharpening stone
7965	solid weightstone
7966	solid grinding stone
7967	mithril shield spike
7968	southsea treasure
7969	mithril spurs
7970	e c a c
7971	black pearl
7972	ichor of undeath
7973	big mouth clam
7974	zesty clam meat
7975	plans heavy mithril pants
7976	plans mithril shield spike
7977	plans mithril scale gloves
7978	plans barbaric iron shoulders
7979	plans barbaric iron breastplate
7980	plans barbaric iron helm
7981	plans barbaric iron boots
7982	plans barbaric iron gloves
7983	plans ornate mithril pants
7984	plans ornate mithril gloves
7985	plans ornate mithril shoulder
7986	plans ornate mithril breastplate
7987	plans ornate mithril helm
7988	plans ornate mithril boots
7989	plans mithril spurs
7990	plans heavy mithril helm
7991	plans mithril scale shoulders
7992	plans blue glittering axe
7993	plans dazzling mithril rapier
7994	plans orcish war leggings
7995	plans mithril scale bracers
7996	lucky fishing hat
7997	red defias mask
8006	the ziggler
8007	mana citrine
8008	mana ruby
8009	dentrium power stone
8026	garrett family treasure
8027	krom stoutarm s treasure
8028	plans runed mithril hammer
8029	plans wicked mithril blade
8030	plans ebon shiv
8046	kearnen s journal
8047	magenta fungus cap
8048	emerald dreamcatcher
8049	gnarlpine necklace
8050	tallonkai s jewel
8051	flare gun
8052	an alleum power stone
8053	obsidian power source
8066	fizzule s whistle
8067	crafted light shot
8068	crafted heavy shot
8069	crafted solid shot
8070	reward voucher
8071	sizzle stick
8072	silixiz s tower key
8073	cache of zanzil s altered mixture
8074	gallywix s head
8075	conjured sourdough
8076	conjured sweet roll
8077	conjured mineral water
8078	conjured sparkling water
8079	conjured crystal water
8080	light plate chestpiece
8081	light plate belt
8082	light plate boots
8083	light plate bracers
8084	light plate gloves
8085	light plate pants
8086	light plate shoulderpads
8087	sample of zanzil s altered mixture
8088	platemail belt
8089	platemail boots
8090	platemail bracers
8091	platemail gloves
8092	platemail helm
8093	platemail leggings
8094	platemail armor
8095	hinott s oil
8106	hibernal armor
8107	hibernal boots
8108	hibernal bracers
8109	hibernal cloak
8110	hibernal gloves
8111	hibernal mantle
8112	hibernal pants
8113	hibernal robe
8114	hibernal sash
8115	hibernal cowl
8116	heraldic belt
8117	heraldic boots
8118	heraldic bracers
8119	heraldic breastplate
8120	heraldic cloak
8121	heraldic gloves
8122	heraldic headpiece
8123	heraldic leggings
8124	heraldic spaulders
8125	myrmidon s bracers
8126	myrmidon s breastplate
8127	myrmidon s cape
8128	myrmidon s gauntlets
8129	myrmidon s girdle
8130	myrmidon s greaves
8131	myrmidon s helm
8132	myrmidon s leggings
8133	myrmidon s pauldrons
8134	myrmidon s defender
8135	chromite shield
8136	gargantuan tumor
8137	chromite bracers
8138	chromite chestplate
8139	chromite gauntlets
8140	chromite girdle
8141	chromite greaves
8142	chromite barbute
8143	chromite legplates
8144	chromite pauldrons
8146	wicked claw
8147	tiny copper key
8148	tiny silver key
8149	voodoo charm
8150	deeprock salt
8151	flask of mojo
8152	flask of big mojo
8153	wildvine
8154	scorpid scale
8155	sathrah s sacrifice
8156	jouster s wristguards
8157	jouster s chestplate
8158	jouster s gauntlets
8159	jouster s girdle
8160	jouster s greaves
8161	jouster s visor
8162	jouster s legplates
8163	jouster s pauldrons
8165	worn dragonscale
8167	turtle scale
8168	jet black feather
8169	thick hide
8170	rugged leather
8171	rugged hide
8172	cured thick hide
8173	thick armor kit
8174	comfortable leather hat
8175	nightscape tunic
8176	nightscape headband
8177	practice sword
8178	training sword
8179	cadet s bow
8180	hunting bow
8181	hunting rifle
8182	pellet rifle
8183	precision bow
8184	firestarter
8185	turtle scale leggings
8186	dire wand
8187	turtle scale gloves
8188	explosive shotgun
8189	turtle scale breastplate
8190	hanzo sword
8191	turtle scale helm
8192	nightscape shoulders
8193	nightscape pants
8194	goblin nutcracker
8195	nightscape cloak
8196	ebon scimitar
8197	nightscape boots
8198	turtle scale bracers
8199	battlefield destroyer
8200	big voodoo robe
8201	big voodoo mask
8202	big voodoo pants
8203	tough scorpid breastplate
8204	tough scorpid gloves
8205	tough scorpid bracers
8206	tough scorpid leggings
8207	tough scorpid shoulders
8208	tough scorpid helm
8209	tough scorpid boots
8210	wild leather shoulders
8211	wild leather vest
8212	wild leather leggings
8213	wild leather boots
8214	wild leather helmet
8215	wild leather cloak
8216	big voodoo cloak
8217	quickdraw quiver
8218	thick leather ammo pouch
8223	blade of the basilisk
8224	silithid ripper
8225	tainted pierce
8226	the butcher
8243	scooby snack
8244	flawless draenethyst sphere
8245	imperial red tunic
8246	imperial red boots
8247	imperial red bracers
8248	imperial red cloak
8249	imperial red gloves
8250	imperial red mantle
8251	imperial red pants
8252	imperial red robe
8253	imperial red sash
8254	imperial red circlet
8255	serpentskin girdle
8256	serpentskin boots
8257	serpentskin bracers
8258	serpentskin armor
8259	serpentskin cloak
8260	serpentskin gloves
8261	serpentskin helm
8262	serpentskin leggings
8263	serpentskin spaulders
8264	ebonhold wristguards
8265	ebonhold armor
8266	ebonhold cloak
8267	ebonhold gauntlets
8268	ebonhold girdle
8269	ebonhold boots
8270	ebonhold helmet
8271	ebonhold leggings
8272	ebonhold shoulderpads
8273	valorous wristguards
8274	valorous chestguard
8275	ebonhold buckler
8276	valorous gauntlets
8277	valorous girdle
8278	valorous greaves
8279	valorous helm
8280	valorous legguards
8281	valorous pauldrons
8282	valorous shield
8283	arcane armor
8284	arcane boots
8285	arcane bands
8286	arcane cloak
8287	arcane gloves
8288	arcane pads
8289	arcane leggings
8290	arcane robe
8291	arcane sash
8292	arcane cover
8293	traveler s belt
8294	traveler s boots
8295	traveler s bracers
8296	traveler s jerkin
8297	traveler s cloak
8298	traveler s gloves
8299	traveler s helm
8300	traveler s leggings
8301	traveler s spaulders
8302	hero s bracers
8303	hero s breastplate
8304	hero s cape
8305	hero s gauntlets
8306	hero s belt
8307	hero s boots
8308	hero s band
8309	hero s leggings
8310	hero s pauldrons
8311	alabaster plate vambraces
8312	alabaster breastplate
8313	hero s buckler
8314	alabaster plate gauntlets
8315	alabaster plate girdle
8316	alabaster plate greaves
8317	alabaster plate helmet
8318	alabaster plate leggings
8319	alabaster plate pauldrons
8320	alabaster shield
8343	heavy silken thread
8344	silvery spinnerets
8345	wolfshead helm
8346	gauntlets of the sea
8347	dragonscale gauntlets
8348	helm of fire
8349	feathered breastplate
8350	the 1 ring
8363	shaman voodoo charm
8364	mithril head trout
8365	raw mithril head trout
8366	bloated trout
8367	dragonscale breastplate
8368	thick wolfhide
8383	plain letter
8384	pattern comfortable leather hat
8385	pattern turtle scale gloves
8386	pattern big voodoo robe
8387	pattern big voodoo mask
8388	pattern nightscape cloak
8389	pattern big voodoo pants
8390	pattern big voodoo cloak
8391	snickerfang jowl
8392	blasted boar lung
8393	scorpok pincer
8394	basilisk brain
8395	pattern tough scorpid breastplate
8396	vulture gizzard
8397	pattern tough scorpid bracers
8398	pattern tough scorpid gloves
8399	pattern tough scorpid boots
8400	pattern tough scorpid shoulders
8401	pattern tough scorpid leggings
8402	pattern tough scorpid helm
8403	pattern wild leather shoulders
8404	pattern wild leather vest
8405	pattern wild leather helmet
8406	pattern wild leather boots
8407	pattern wild leather leggings
8408	pattern wild leather cloak
8409	pattern nightscape shoulders
8410	r o i d s
8411	lung juice cocktail
8412	ground scorpok assay
8423	cerebral cortex compound
8424	gizzard gum
8425	parrot droppings
8426	large ruffled feather
8427	mutilated rat carcass
8428	laden dew gland
8429	punctured dew gland
8430	empty dew gland
8431	spool of light chartreuse silk thread
8432	eau de mixilpixil
8443	gahz ridian ornament
8444	executioner s key
8463	warchief s orders
8483	wastewander water pouch
8484	gadgetzan water co care package
8485	cat carrier bombay
8486	cat carrier cornish rex
8487	cat carrier orange tabby
8488	cat carrier silver tabby
8489	cat carrier white kitten
8490	cat carrier siamese
8491	cat carrier black tabby
8492	parrot cage green wing macaw
8493	weegli s barrel
8494	parrot cage hyacinth macaw
8495	parrot cage senegal
8496	parrot cage cockatiel
8497	rabbit crate snowshoe
8498	tiny emerald whelpling
8499	tiny crimson whelpling
8500	great horned owl
8501	hawk owl
8502	bronze lotterybox
8503	heavy bronze lotterybox
8504	iron lotterybox
8505	heavy iron lotterybox
8506	mithril lotterybox
8507	heavy mithril lotterybox
8508	large fin
8523	field testing kit
8524	model 4711 ftz power source
8525	zinge s purchase order
8526	violet tragan
8527	sealed field testing kit
8528	violet powder
8529	noggenfogger elixir
8544	mageweave bandage
8545	heavy mageweave bandage
8548	divino matic rod
8563	red mechanostrider
8564	hippogryph egg
8583	horn of the skeletal mount
8584	untapped dowsing widget
8585	tapped dowsing widget
8586	whistle of the mottled red raptor
8587	centipaar insect parts
8588	whistle of the emerald raptor
8591	whistle of the turquoise raptor
8592	whistle of the violet raptor
8593	scrimshank s surveying gear
8594	insect analysis report
8595	blue mechanostrider
8603	thistleshrub dew
8623	oox 17 tn distress beacon
8624	red sparkler
8625	white sparkler
8626	blue sparkler
8628	reins of the spotted nightsaber
8629	reins of the striped nightsaber
8630	reins of the bengal tiger
8631	reins of the striped frostsaber
8632	reins of the spotted frostsaber
8633	reins of the leopard
8643	extraordinary egg
8644	fine egg
8645	ordinary egg
8646	bad egg
8647	egg crate
8663	mithril insignia
8683	clara s fresh apple
8684	hinterlands honey ripple
8685	dran s ripple delivery
8686	mithril pendant
8687	sealed description of thredd s visitor
8703	signet of expertise
8704	oox 09 hl distress beacon
8705	oox 22 fe distress beacon
8707	gahz rilla s electrified scale
8708	hammer of expertise
8723	caliph scorpidsting s head
8724	rin ji s secret
8746	interlaced cowl
8747	hardened leather helm
8748	double mail coif
8749	crochet hat
8750	thick leather hat
8751	overlinked coif
8752	laminated scale circlet
8753	smooth leather helmet
8754	twill cover
8755	light plate helmet
8766	morning glory dew
8827	elixir of water walking
8831	purple lotus
8836	arthas tears
8838	sungrass
8839	blindweed
8845	ghost mushroom
8846	gromsblood
8923	essence of agony
8924	dust of deterioration
8925	crystal vial
8926	instant poison iv
8927	instant poison v
8928	instant poison vi
8932	alterac swiss
8948	dried king bolete
8949	elixir of agility
8950	homemade cherry pie
8951	elixir of greater defense
8952	roasted quail
8953	deep fried plantains
8956	oil of immolation
8957	spinefin halibut
8959	raw spinefin halibut
8964	codex of flash heal
8973	thick yeti hide
8984	deadly poison iii
8985	deadly poison iv
9030	restorative potion
9036	magic resistance potion
9060	inlaid mithril cylinder
9061	goblin rocket fuel
9088	gift of arthas
9144	wildvine potion
9149	philosopher s stone
9153	rig blueprints
9154	elixir of detect undead
9155	arcane elixir
9172	invisibility potion
9173	goblin transponder
9179	elixir of greater intellect
9186	mind numbing poison iii
9187	elixir of greater agility
9189	shay s bell
9197	elixir of dream vision
9206	elixir of giants
9210	ghost dye
9214	grimoire of inferno
9224	elixir of demonslaying
9233	elixir of detect demon
9234	tiara of the deep
9235	pratt s letter
9236	jangdor s letter
9237	woodpaw gnoll mane
9238	uncracked scarab shell
9240	mallet of zul farrak
9241	sacred mallet
9242	ancient tablet
9243	shriveled heart
9244	stoley s shipment
9245	stoley s bottle
9246	firebeard s head
9247	hatecrest naga scale
9248	mysterious relic
9249	captain s key
9250	ship schedule
9251	upper map fragment
9252	lower map fragment
9253	middle map fragment
9254	cuergo s treasure map
9255	lahassa essence
9256	imbel essence
9257	samha essence
9258	byltan essence
9259	troll tribal necklace
9260	volatile rum
9261	lead ore
9262	black vitriol
9263	troyas stave
9264	elixir of shadow power
9265	cuergo s hidden treasure
9266	woodpaw battle plans
9275	cuergo s key
9276	pirate s footlocker
9277	techbot s memory core
9278	essential artificial
9279	white punch card
9280	yellow punch card
9281	red punch card
9282	blue punch card
9283	empty leaden collection phial
9284	full leaden collection phial
9285	field plate vambraces
9286	field plate armor
9287	field plate gauntlets
9288	field plate girdle
9289	field plate boots
9290	field plate helmet
9291	field plate leggings
9292	field plate pauldrons
9293	recipe magic resistance potion
9294	recipe wildvine potion
9295	recipe invisibility potion
9296	recipe gift of arthas
9297	recipe elixir of dream vision
9298	recipe elixir of giants
9299	thermaplugg s safe combination
9300	recipe elixir of demonslaying
9301	recipe elixir of shadow power
9302	recipe ghost dye
9303	recipe philosopher s stone
9304	recipe transmute iron to gold
9305	recipe transmute mithril to truesilver
9306	stave of equinex
9307	a sparkling stone
9308	grime encrusted object
9309	robo mechanical guts
9311	default stationery
9312	blue firework
9313	green firework
9314	red streaks firework
9315	yellow rose firework
9316	prismatic punch card
9317	red white and blue firework
9318	red firework
9319	nimboya s laden pike
9320	witherbark skull
9321	venom bottle
9322	undamaged venom sac
9323	gadrin s parchment
9324	shadra s venom
9325	a small stave
9326	grime encrusted ring
9327	security delta data access card
9328	super snapper fx
9329	a short note
9330	snapshot of gammerita
9331	feralas a history
9332	crusted bandages
9333	tarnished silver necklace
9334	cracked pottery
9335	broken obsidian club
9336	gold capped troll tusk
9355	hoop earring
9356	a wooden leg
9357	a parrot skeleton
9358	a head rag
9359	wirt s third leg
9360	cuergo s gold
9361	cuergo s gold with worm
9362	brilliant gold ring
9363	sparklematic wrapped box
9364	heavy leaden collection phial
9365	high potency radioactive fallout
9366	golden scale gauntlets
9367	plans golden scale gauntlets
9368	jer kai s signet ring
9369	iridescent sprite darter wing
9370	gordunni scroll
9371	gordunni orb
9372	sul thraze the lasher
9375	expert goldminer s helmet
9378	shovelphlange s mining axe
9379	sang thraze the deflector
9381	earthen rod
9382	tromping miner s boots
9383	obsidian cleaver
9384	stonevault shiv
9385	archaic defender
9386	excavator s brand
9387	revelosh s boots
9388	revelosh s armguards
9389	revelosh s spaulders
9390	revelosh s gloves
9391	the shoveler
9392	annealed blade
9393	beacon of hope
9394	horned viking helmet
9395	gloves of old
9396	legguards of the vault
9397	energy cloak
9398	worn running boots
9399	precision arrow
9400	baelog s shortbow
9401	nordic longshank
9402	earthborn kilt
9403	battered viking shield
9404	olaf s all purpose shield
9405	girdle of golem strength
9406	spirewind fetter
9407	stoneweaver leggings
9408	ironshod bludgeon
9409	ironaya s bracers
9410	cragfists
9411	rockshard pauldrons
9412	galgann s fireblaster
9413	the rockpounder
9414	oilskin leggings
9415	grimlok s tribal vestments
9416	grimlok s charge
9418	stoneslayer
9419	galgann s firehammer
9420	adventurer s pith helmet
9421	major healthstone
9422	shadowforge bushmaster
9423	the jackhammer
9424	ginn su sword
9425	pendulum of doom
9426	monolithic bow
9427	stonevault bonebreaker
9428	unearthed bands
9429	miner s hat of the deep
9430	spaulders of a lost age
9431	papal fez
9432	skullplate bracers
9433	forgotten wraps
9434	elemental raiment
9435	reticulated bone gauntlets
9436	faranell s parcel
9437	untested basilisk sample
9438	acceptable scorpid sample
9439	untested hyena sample
9440	acceptable basilisk sample
9441	acceptable hyena sample
9442	untested scorpid sample
9443	used monster sample
9444	techbot cpu shell
9445	grubbis paws
9446	electrocutioner leg
9447	electrocutioner lagnut
9448	spidertank oilrag
9449	manual crowd pummeler
9450	gnomebot operating boots
9451	bubbling water
9452	hydrocane
9453	toxic revenger
9454	acidic walkers
9455	emissary cuffs
9456	glass shooter
9457	royal diplomatic scepter
9458	thermaplugg s central core
9459	thermaplugg s left arm
9460	grimtotem horn
9461	charged gear
9462	crate of grimtotem horns
9463	gordunni cobalt
9465	digmaster 5000
9466	orwin s shovel
9467	gahz rilla fang
9468	sharpbeak s feather
9469	gahz rilla scale armor
9470	bad mojo mask
9471	nekrum s medallion
9472	hexx s key
9473	jinxed hoodoo skin
9474	jinxed hoodoo kilt
9475	diabolic skiver
9476	big bad pauldrons
9477	the chief s enforcer
9478	ripsaw
9479	embrace of the lycan
9480	eyegouger
9481	the minotaur
9482	witch doctor s cane
9483	flaming incinerator
9484	spellshock leggings
9485	vibroblade
9486	supercharger battle axe
9487	hi tech supergun
9488	oscillating power hammer
9489	gyromatic icemaker
9490	gizmotron megachopper
9491	hotshot pilot s gloves
9492	electromagnetic gigaflux reactivator
9507	a carefully packed crate
9508	mechbuilder s overalls
9509	petrolspill leggings
9510	caverndeep trudgers
9511	bloodletter scalpel
9512	blackmetal cape
9513	ley staff
9514	arcane staff
9515	nether lace tunic
9516	astral knot blouse
9517	celestial stave
9518	mud s crushers
9519	durtfeet stompers
9520	silent hunter
9521	skullsplitter
9522	energized stone circle
9523	troll temper
9527	spellshifter rod
9528	edana s dark heart
9529	internal warrior equipment kit l25
9530	horn of hatetalon
9531	gemshale pauldrons
9532	internal warrior equipment kit l30
9533	masons fraternity ring
9534	engineer s guild headpiece
9535	fire welded bracers
9536	fairywing mantle
9537	neatly wrapped box
9538	talvash s gold ring
9539	box of rations
9540	box of spells
9541	box of goodies
9542	simple letter
9543	simple rune
9544	simple memorandum
9545	simple sigil
9546	simple scroll
9547	simple note
9548	hallowed letter
9550	encrypted rune
9551	encrypted sigil
9552	rune inscribed note
9553	etched parchment
9554	encrypted tablet
9555	encrypted letter
9556	hallowed rune
9557	hallowed sigil
9558	encrypted memorandum
9559	encrypted scroll
9560	encrypted parchment
9561	hallowed tablet
9562	rune inscribed tablet
9563	consecrated rune
9564	etched tablet
9565	etched note
9566	etched rune
9567	etched sigil
9568	rune inscribed parchment
9569	hallowed scroll
9570	consecrated letter
9571	glyphic letter
9572	glyphic rune
9573	glyphic memorandum
9574	glyphic scroll
9575	glyphic tablet
9576	tainted letter
9577	tainted memorandum
9578	tainted scroll
9579	tainted parchment
9580	verdant sigil
9581	verdant note
9587	thawpelt sack
9588	nogg s gold ring
9589	encrusted minerals
9590	splintered log
9591	resilient sinew
9592	metallic fragments
9593	treant muisek
9594	wildkin muisek
9595	hippogryph muisek
9596	faerie dragon muisek
9597	mountain giant muisek
9598	sleeping robes
9599	barkmail leggings
9600	lace pants
9601	cushioned boots
9602	brushwood blade
9603	gritroot staff
9604	mechanic s pipehammer
9605	repairman s cape
9606	treant muisek vessel
9607	bastion of stormwind
9608	shoni s disarming tool
9609	shilly mitts
9618	wildkin muisek vessel
9619	hippogryph muisek vessel
9620	faerie dragon muisek vessel
9621	mountain giant muisek vessel
9622	reedknot ring
9623	civinad robes
9624	triprunner dungarees
9625	dual reinforced leggings
9626	dwarven charge
9627	explorer s league lodestar
9628	neeru s herb pouch
9629	a shrunken head
9630	pratt s handcrafted boots
9631	pratt s handcrafted gloves
9632	jangdor s handcrafted gloves
9633	jangdor s handcrafted boots
9634	skilled handling gloves
9635	master apothecary cape
9636	swashbuckler sash
9637	shinkicker boots
9638	chelonian cuffs
9639	the hand of antu sul
9640	vice grips
9641	lifeblood amulet
9642	band of the great tortoise
9643	optomatic deflector
9644	thermotastic egg timer
9645	gnomish inventor boots
9646	gnomish water sinking device
9647	failed flying experiment
9648	chainlink towel
9649	royal highmark vestments
9650	honorguard chestpiece
9651	gryphon rider s stormhammer
9652	gryphon rider s leggings
9653	speedy racer goggles
9654	cairnstone sliver
9655	seedtime hoop
9656	granite grips
9657	vinehedge cinch
9658	boots of the maharishi
9660	stargazer cloak
9661	earthclasp barrier
9662	rushridge boots
9663	dawnrider s chestpiece
9664	sentinel s guard
9665	wingcrest gloves
9666	stronghorn girdle
9678	tok kar s murloc basher
9679	tok kar s murloc chopper
9680	tok kar s murloc shanker
9681	grilled king crawler legs
9682	leather chef s belt
9683	strength of the treant
9684	force of the hippogryph
9686	spirit of the faerie dragon
9687	grappler s belt
9698	gloves of insight
9699	garrison cloak
9703	scorched cape
9704	rustler gloves
9705	tharg s shoelace
9706	tharg s disk
9718	reforged blade of heroes
9719	broken blade of heroes
9738	gem of cobrahn
9739	gem of anacondra
9740	gem of pythas
9741	gem of serpentis
9742	simple cord
9743	simple shoes
9744	simple bands
9745	simple cape
9746	simple gloves
9747	simple britches
9748	simple robe
9749	simple blouse
9750	gypsy sash
9751	gypsy sandals
9752	gypsy bands
9753	gypsy buckler
9754	gypsy cloak
9755	gypsy gloves
9756	gypsy trousers
9757	gypsy tunic
9758	cadet belt
9759	cadet boots
9760	cadet bracers
9761	cadet cloak
9762	cadet gauntlets
9763	cadet leggings
9764	cadet shield
9765	cadet vest
9766	greenweave sash
9767	greenweave sandals
9768	greenweave bracers
9769	greenweave branch
9770	greenweave cloak
9771	greenweave gloves
9772	greenweave leggings
9773	greenweave robe
9774	greenweave vest
9775	bandit cinch
9776	bandit boots
9777	bandit bracers
9778	bandit buckler
9779	bandit cloak
9780	bandit gloves
9781	bandit pants
9782	bandit jerkin
9783	raider s chestpiece
9784	raider s boots
9785	raider s bracers
9786	raider s cloak
9787	raider s gauntlets
9788	raider s belt
9789	raider s legguards
9790	raider s shield
9791	ivycloth tunic
9792	ivycloth boots
9793	ivycloth bracelets
9794	ivycloth cloak
9795	ivycloth gloves
9796	ivycloth mantle
9797	ivycloth pants
9798	ivycloth robe
9799	ivycloth sash
9800	ivy orb
9801	superior belt
9802	superior boots
9803	superior bracers
9804	superior buckler
9805	superior cloak
9806	superior gloves
9807	superior shoulders
9808	superior leggings
9809	superior tunic
9810	fortified boots
9811	fortified bracers
9812	fortified cloak
9813	fortified gauntlets
9814	fortified belt
9815	fortified leggings
9816	fortified shield
9817	fortified spaulders
9818	fortified chain
9819	durable tunic
9820	durable boots
9821	durable bracers
9822	durable cape
9823	durable gloves
9824	durable shoulders
9825	durable pants
9826	durable robe
9827	scaled leather belt
9828	scaled leather boots
9829	scaled leather bracers
9830	scaled shield
9831	scaled cloak
9832	scaled leather gloves
9833	scaled leather leggings
9834	scaled leather shoulders
9835	scaled leather tunic
9836	banded armor
9837	banded bracers
9838	banded cloak
9839	banded gauntlets
9840	banded girdle
9841	banded leggings
9842	banded pauldrons
9843	banded shield
9844	conjurer s vest
9845	conjurer s shoes
9846	conjurer s bracers
9847	conjurer s cloak
9848	conjurer s gloves
9849	conjurer s hood
9850	conjurer s mantle
9851	conjurer s breeches
9852	conjurer s robe
9853	conjurer s cinch
9854	archer s jerkin
9855	archer s belt
9856	archer s boots
9857	archer s bracers
9858	archer s buckler
9859	archer s cap
9860	archer s cloak
9861	archer s gloves
9862	archer s trousers
9863	archer s shoulderpads
9864	renegade boots
9865	renegade bracers
9866	renegade chestguard
9867	renegade cloak
9868	renegade gauntlets
9869	renegade belt
9870	renegade circlet
9871	renegade leggings
9872	renegade pauldrons
9873	renegade shield
9874	sorcerer drape
9875	sorcerer sash
9876	sorcerer slippers
9877	sorcerer cloak
9878	sorcerer hat
9879	sorcerer bracelets
9880	sorcerer gloves
9881	sorcerer mantle
9882	sorcerer sphere
9883	sorcerer pants
9884	sorcerer robe
9885	huntsman s boots
9886	huntsman s bands
9887	huntsman s armor
9889	huntsman s cap
9890	huntsman s cape
9891	huntsman s belt
9892	huntsman s gloves
9893	huntsman s leggings
9894	huntsman s shoulders
9895	jazeraint boots
9896	jazeraint bracers
9897	jazeraint chestguard
9898	jazeraint cloak
9899	jazeraint shield
9900	jazeraint gauntlets
9901	jazeraint belt
9902	jazeraint helm
9903	jazeraint leggings
9904	jazeraint pauldrons
9905	royal blouse
9906	royal sash
9907	royal boots
9908	royal cape
9909	royal bands
9910	royal gloves
9911	royal trousers
9912	royal amice
9913	royal gown
9914	royal scepter
9915	royal headband
9916	tracker s belt
9917	tracker s boots
9918	brigade defender
9919	tracker s cloak
9920	tracker s gloves
9921	tracker s headband
9922	tracker s leggings
9923	tracker s shoulderpads
9924	tracker s tunic
9925	tracker s wristguards
9926	brigade boots
9927	brigade bracers
9928	brigade breastplate
9929	brigade cloak
9930	brigade gauntlets
9931	brigade girdle
9932	brigade circlet
9933	brigade leggings
9934	brigade pauldrons
9935	embossed plate shield
9936	abjurer s boots
9937	abjurer s bands
9938	abjurer s cloak
9939	abjurer s gloves
9940	abjurer s hood
9941	abjurer s mantle
9942	abjurer s pants
9943	abjurer s robe
9944	abjurer s crystal
9945	abjurer s sash
9946	abjurer s tunic
9947	chieftain s belt
9948	chieftain s boots
9949	chieftain s bracers
9950	chieftain s breastplate
9951	chieftain s cloak
9952	chieftain s gloves
9953	chieftain s headdress
9954	chieftain s leggings
9955	chieftain s shoulders
9956	warmonger s bracers
9957	warmonger s chestpiece
9958	warmonger s buckler
9959	warmonger s cloak
9960	warmonger s gauntlets
9961	warmonger s belt
9962	warmonger s greaves
9963	warmonger s circlet
9964	warmonger s leggings
9965	warmonger s pauldrons
9966	embossed plate armor
9967	embossed plate gauntlets
9968	embossed plate girdle
9969	embossed plate helmet
9970	embossed plate leggings
9971	embossed plate pauldrons
9972	embossed plate bracers
9973	embossed plate boots
9974	overlord s shield
9978	gahz ridian detector
9998	black mageweave vest
9999	black mageweave leggings
10000	margol s horn
10001	black mageweave robe
10002	shadoweave pants
10003	black mageweave gloves
10004	shadoweave robe
10005	margol s gigantic horn
10007	red mageweave vest
10008	white bandit mask
10009	red mageweave pants
10010	stormcloth pants
10011	stormcloth gloves
10018	red mageweave gloves
10019	dreamweave gloves
10020	stormcloth vest
10021	dreamweave vest
10022	proof of deed
10023	shadoweave gloves
10024	black mageweave headband
10025	shadoweave mask
10026	black mageweave boots
10027	black mageweave shoulders
10028	shadoweave shoulders
10029	red mageweave shoulders
10030	admiral s hat
10031	shadoweave boots
10032	stormcloth headband
10033	red mageweave headband
10034	tuxedo shirt
10035	tuxedo pants
10036	tuxedo jacket
10038	stormcloth shoulders
10039	stormcloth boots
10040	white wedding dress
10041	dreamweave circlet
10042	cindercloth robe
10043	pious legwraps
10044	cindercloth boots
10045	simple linen pants
10046	simple linen boots
10047	simple kilt
10048	colorful kilt
10050	mageweave bag
10051	red mageweave bag
10052	orange martial shirt
10053	simple black dress
10054	lavender mageweave shirt
10055	pink mageweave shirt
10056	orange mageweave shirt
10057	duskwoven tunic
10058	duskwoven sandals
10059	duskwoven bracers
10060	duskwoven cape
10061	duskwoven turban
10062	duskwoven gloves
10063	duskwoven amice
10064	duskwoven pants
10065	duskwoven robe
10066	duskwoven sash
10067	righteous waistguard
10068	righteous boots
10069	righteous bracers
10070	righteous armor
10071	righteous cloak
10072	righteous gloves
10073	righteous helmet
10074	righteous leggings
10075	righteous spaulders
10076	lord s armguards
10077	lord s breastplate
10078	lord s crest
10079	lord s cape
10080	lord s gauntlets
10081	lord s girdle
10082	lord s boots
10083	lord s crown
10084	lord s legguards
10085	lord s pauldrons
10086	gothic plate armor
10087	gothic plate gauntlets
10088	gothic plate girdle
10089	gothic sabatons
10090	gothic plate helmet
10091	gothic plate leggings
10092	gothic plate spaulders
10093	revenant deflector
10094	gothic plate vambraces
10095	councillor s boots
10096	councillor s cuffs
10097	councillor s circlet
10098	councillor s cloak
10099	councillor s gloves
10100	councillor s shoulders
10101	councillor s pants
10102	councillor s robes
10103	councillor s sash
10104	councillor s tunic
10105	wanderer s armor
10106	wanderer s boots
10107	wanderer s bracers
10108	wanderer s cloak
10109	wanderer s belt
10110	wanderer s gloves
10111	wanderer s hat
10112	wanderer s leggings
10113	wanderer s shoulders
10118	ornate breastplate
10119	ornate greaves
10120	ornate cloak
10121	ornate gauntlets
10122	ornate girdle
10123	ornate circlet
10124	ornate legguards
10125	ornate pauldrons
10126	ornate bracers
10127	revenant bracers
10128	revenant chestplate
10129	revenant gauntlets
10130	revenant girdle
10131	revenant boots
10132	revenant helmet
10133	revenant leggings
10134	revenant shoulders
10135	high councillor s tunic
10136	high councillor s bracers
10137	high councillor s boots
10138	high councillor s cloak
10139	high councillor s circlet
10140	high councillor s gloves
10141	high councillor s pants
10142	high councillor s mantle
10143	high councillor s robe
10144	high councillor s sash
10145	mighty girdle
10146	mighty boots
10147	mighty armsplints
10148	mighty cloak
10149	mighty gauntlets
10150	mighty helmet
10151	mighty tunic
10152	mighty leggings
10153	mighty spaulders
10154	mercurial girdle
10155	mercurial greaves
10156	mercurial bracers
10157	mercurial breastplate
10158	mercurial guard
10159	mercurial cloak
10160	mercurial circlet
10161	mercurial gauntlets
10162	mercurial legguards
10163	mercurial pauldrons
10164	templar chestplate
10165	templar gauntlets
10166	templar girdle
10167	templar boots
10168	templar crown
10169	templar legplates
10170	templar pauldrons
10171	templar bracers
10172	mystical mantle
10173	mystical bracers
10174	mystical cape
10175	mystical headwrap
10176	mystical gloves
10177	mystical leggings
10178	mystical robe
10179	mystical boots
10180	mystical belt
10181	mystical armor
10182	swashbuckler s breastplate
10183	swashbuckler s boots
10184	swashbuckler s bracers
10185	swashbuckler s cape
10186	swashbuckler s gloves
10187	swashbuckler s eyepatch
10188	swashbuckler s leggings
10189	swashbuckler s shoulderpads
10190	swashbuckler s belt
10191	crusader s armguards
10192	crusader s boots
10193	crusader s armor
10194	crusader s cloak
10195	crusader s shield
10196	crusader s gauntlets
10197	crusader s belt
10198	crusader s helm
10199	crusader s leggings
10200	crusader s pauldrons
10201	overlord s greaves
10202	overlord s vambraces
10203	overlord s chestplate
10204	heavy lamellar shield
10205	overlord s gauntlets
10206	overlord s girdle
10207	overlord s crown
10208	overlord s legplates
10209	overlord s spaulders
10210	elegant mantle
10211	elegant boots
10212	elegant cloak
10213	elegant bracers
10214	elegant gloves
10215	elegant robes
10216	elegant belt
10217	elegant leggings
10218	elegant tunic
10219	elegant circlet
10220	nightshade tunic
10221	nightshade girdle
10222	nightshade boots
10223	nightshade armguards
10224	nightshade cloak
10225	nightshade gloves
10226	nightshade helmet
10227	nightshade leggings
10228	nightshade spaulders
10229	engraved bracers
10230	engraved breastplate
10231	engraved cape
10232	engraved gauntlets
10233	engraved girdle
10234	engraved boots
10235	engraved helm
10236	engraved leggings
10237	engraved pauldrons
10238	heavy lamellar boots
10239	heavy lamellar vambraces
10240	heavy lamellar chestpiece
10241	heavy lamellar helm
10242	heavy lamellar gauntlets
10243	heavy lamellar girdle
10244	heavy lamellar leggings
10245	heavy lamellar pauldrons
10246	master s vest
10247	master s boots
10248	master s bracers
10249	master s cloak
10250	master s hat
10251	master s gloves
10252	master s leggings
10253	master s mantle
10254	master s robe
10255	master s belt
10256	adventurer s bracers
10257	adventurer s boots
10258	adventurer s cape
10259	adventurer s belt
10260	adventurer s gloves
10261	adventurer s bandana
10262	adventurer s legguards
10263	adventurer s shoulders
10264	adventurer s tunic
10265	masterwork bracers
10266	masterwork breastplate
10267	masterwork cape
10268	masterwork gauntlets
10269	masterwork girdle
10270	masterwork boots
10271	masterwork shield
10272	masterwork circlet
10273	masterwork legplates
10274	masterwork pauldrons
10275	emerald breastplate
10276	emerald sabatons
10277	emerald gauntlets
10278	emerald girdle
10279	emerald helm
10280	emerald legplates
10281	emerald pauldrons
10282	emerald vambraces
10283	wolf heart samples
10285	shadow silk
10286	heart of the wild
10287	greenweave mantle
10288	sage s circlet
10289	durable hat
10290	pink dye
10298	gnomeregan band
10299	gnomeregan amulet
10300	pattern red mageweave vest
10301	pattern white bandit mask
10302	pattern red mageweave pants
10303	pattern stormcloth pants
10304	pattern stormcloth gloves
10305	scroll of protection iv
10306	scroll of spirit iv
10307	scroll of stamina iv
10308	scroll of intellect iv
10309	scroll of agility iv
10310	scroll of strength iv
10311	pattern orange martial shirt
10312	pattern red mageweave gloves
10313	pattern stormcloth vest
10314	pattern lavender mageweave shirt
10315	pattern red mageweave shoulders
10316	pattern colorful kilt
10317	pattern pink mageweave shirt
10318	pattern admiral s hat
10319	pattern stormcloth headband
10320	pattern red mageweave headband
10321	pattern tuxedo shirt
10322	pattern stormcloth shoulders
10323	pattern tuxedo pants
10324	pattern stormcloth boots
10325	pattern white wedding dress
10326	pattern tuxedo jacket
10327	horn of echeyakee
10328	scarlet chestpiece
10329	scarlet belt
10330	scarlet leggings
10331	scarlet gauntlets
10332	scarlet boots
10333	scarlet wristguards
10338	fresh zhevra carcass
10358	duracin bracers
10359	everlast boots
10360	black kingsnake
10361	brown snake
10362	ornate shield
10363	engraved wall
10364	templar shield
10365	emerald shield
10366	demon guard
10367	hyperion shield
10368	imbued plate armor
10369	imbued plate gauntlets
10370	imbued plate girdle
10371	imbued plate greaves
10372	imbued plate helmet
10373	imbued plate leggings
10374	imbued plate pauldrons
10375	imbued plate vambraces
10376	commander s boots
10377	commander s vambraces
10378	commander s armor
10379	commander s helm
10380	commander s gauntlets
10381	commander s girdle
10382	commander s leggings
10383	commander s pauldrons
10384	hyperion armor
10385	hyperion greaves
10386	hyperion gauntlets
10387	hyperion girdle
10388	hyperion helm
10389	hyperion legplates
10390	hyperion pauldrons
10391	hyperion vambraces
10392	crimson snake
10393	cockroach
10394	prairie dog whistle
10398	mechanical chicken
10399	blackened defias armor
10400	blackened defias leggings
10401	blackened defias gloves
10402	blackened defias boots
10403	blackened defias belt
10404	durable belt
10405	bandit shoulders
10406	scaled leather headband
10407	raider s shoulderpads
10408	banded helm
10409	banded boots
10410	leggings of the fang
10411	footpads of the fang
10412	belt of the fang
10413	gloves of the fang
10414	sample snapjaw shell
10418	glimmering mithril insignia
10420	skull of the coldbringer
10421	rough copper vest
10423	silvered bronze leggings
10424	plans silvered bronze leggings
10438	felix s box
10439	durnan s scalding mornbrew
10440	nori s mug
10441	glowing shard
10442	mysterious artifact
10443	singed letter
10444	standard issue flare gun
10445	drawing kit
10446	heart of obsidion
10447	head of lathoric the black
10450	undamaged hippogryph feather
10454	essence of eranikus
10455	chained essence of eranikus
10456	a bulging coin purse
10457	empty sea snail shell
10458	prayer to elune
10459	chief sharptusk thornmantle s head
10460	hakkari blood
10461	shadowy bracers
10462	shadowy belt
10463	pattern shadoweave mask
10464	staff of command
10465	egg of hakkar
10466	atal ai stone circle
10467	trader s satchel
10478	roland s mana gem
10479	kovic s trading satchel
10498	gyromatic micro adjustor
10499	bright eye goggles
10500	fire goggles
10501	catseye ultra goggles
10502	spellpower goggles xtreme
10503	rose colored goggles
10504	green lens
10505	solid blasting powder
10506	deepdive helmet
10507	solid dynamite
10508	mithril blunderbuss
10509	heart of flame
10510	mithril heavy bore rifle
10511	golem oil
10512	hi impact mithril slugs
10513	mithril gyro shot
10514	mithril frag bomb
10515	torch of retribution
10518	parachute cloak
10538	tablet of beth amara
10539	tablet of jin yael
10540	tablet of markri
10541	tablet of sael hai
10542	goblin mining helmet
10543	goblin construction helmet
10544	thistlewood maul
10545	gnomish goggles
10546	deadly scope
10547	camping knife
10548	sniper scope
10549	rancher s trousers
10550	wooly mittens
10551	thorium plated dagger
10552	symbol of ragnaros
10553	foreman vest
10554	foreman pants
10556	stone circle
10558	gold power core
10559	mithril tube
10560	unstable trigger
10561	mithril casing
10562	hi explosive bomb
10563	rubbing rune of beth amara
10564	rubbing rune of jin yael
10565	rubbing rune of markri
10566	rubbing rune of sael hai
10567	quillshooter
10569	hoard of the black dragonflight
10570	manslayer
10571	ebony boneclub
10572	freezing shard
10573	boneslasher
10574	corpseshroud
10575	black dragonflight molt
10576	mithril mechanical dragonling
10577	goblin mortar
10578	thoughtcast boots
10579	explosive arrow
10580	goblin boom box
10581	death s head vestment
10582	briar tredders
10583	quillward harness
10584	stormgale fists
10585	goblin radio
10586	the big one
10587	goblin bomb dispenser
10588	goblin rocket helmet
10589	oathstone of ysera s dragonflight
10590	pocked black box
10592	catseye elixir
10593	imperfect draenethyst fragment
10597	head of magus rimtori
10598	hetaera s bloodied head
10599	hetaera s beaten head
10600	hetaera s bruised head
10601	schematic bright eye goggles
10602	schematic deadly scope
10603	schematic catseye ultra goggles
10604	schematic mithril heavy bore rifle
10605	schematic spellpower goggles xtreme
10606	schematic parachute cloak
10607	schematic deepdive helmet
10608	schematic sniper scope
10609	schematic mithril mechanical dragonling
10610	hetaera s blood
10620	thorium ore
10621	runed scroll
10622	kadrak s flag
10623	winter s bite
10624	stinging bow
10625	stealthblade
10626	ragehammer
10627	bludgeon of the grinning dog
10628	deathblow
10629	mistwalker boots
10630	soulcatcher halo
10631	murkwater gauntlets
10632	slimescale bracers
10633	silvershell leggings
10634	mindseye circle
10635	painted chain leggings
10636	nomadic gloves
10637	brewer s gloves
10638	long draping cape
10639	hyacinth mushroom
10640	webwood ichor
10641	moonpetal lily
10642	iverron s antidote
10643	sealed letter to ag tor
10644	recipe goblin rocket fuel
10645	gnomish death ray
10646	goblin sapper charge
10647	engineer s ink
10648	blank parchment
10649	nightmare shard
10651	cracked arcane focusing crystal
10652	will of the mountain giant
10653	trailblazer boots
10654	jutebraid gloves
10655	sedgeweed britches
10656	barkmail vest
10657	talbar mantle
10658	quagmire galoshes
10659	shard of afrasa
10660	first mosh aru tablet
10661	second mosh aru tablet
10662	filled egg of hakkar
10663	essence of hakkar
10664	a note to magus rimtori
10678	magatha s note
10679	andron s note
10680	jes rimon s note
10681	xylem s note
10682	belnistrasz s oathstone
10684	colossal parachute
10686	aegis of battle
10687	empty vial labeled #1
10688	empty vial labeled #2
10689	empty vial labeled #3
10690	empty vial labeled #4
10691	filled vial labeled #1
10692	filled vial labeled #2
10693	filled vial labeled #3
10694	filled vial labeled #4
10695	box of empty vials
10696	enchanted azsharite felbane sword
10697	enchanted azsharite felbane dagger
10698	enchanted azsharite felbane staff
10699	yeh kinya s bramble
10700	encarmine boots
10701	boots of zua tec
10702	enormous ogre boots
10703	fiendish skiv
10704	chillnail splinter
10705	firwillow wristbands
10706	nightscale girdle
10707	steelsmith greaves
10708	skullspell orb
10709	pyrestone orb
10710	dragonclaw ring
10711	dragon s blood necklace
10712	cuely s elixir
10713	plans inlaid mithril cylinder
10714	crystallized azsharite
10715	kim jael s scope
10716	gnomish shrink ray
10717	kim jael s compass
10718	kim jael s wizzlegoober
10719	mobile alarm
10720	gnomish net o matic projector
10721	gnomish harm prevention belt
10722	kim jael s stuffed chicken
10723	gnomish ham radio
10724	gnomish rocket boots
10725	gnomish battle chicken
10726	gnomish mind control cap
10727	goblin dragon gun
10728	pattern black swashbuckler s shirt
10738	shipment to galvan
10739	ring of fortitude
10740	centurion legplates
10741	lordrec helmet
10742	dragonflight leggings
10743	drakefire headguard
10744	axe of the ebon drake
10745	kaylari shoulders
10746	runesteel vambraces
10747	teacher s sash
10748	wanderlust boots
10749	avenguard helm
10750	lifeforce dirk
10751	gemburst circlet
10752	emerald encrusted chest
10753	amulet of grol
10754	amulet of sevine
10755	amulet of allistarj
10757	ward of the defiler
10758	x caliboar
10759	severed horn of the defiler
10760	swine fists
10761	coldrage dagger
10762	robes of the lich
10763	icemetal barbute
10764	deathchill armor
10765	bonefingers
10766	plaguerot sprig
10767	savage boar s guard
10768	boar champion s belt
10769	glowing eye of mordresh
10770	mordresh s lifeless skull
10771	deathmage sash
10772	glutton s cleaver
10773	hakkari urn
10774	fleshhide shoulders
10775	carapace of tuten kash
10776	silky spider cape
10777	arachnid gloves
10778	necklace of sanctuary
10779	demon s blood
10780	mark of hakkar
10781	hakkari breastplate
10782	hakkari shroud
10783	atal ai spaulders
10784	atal ai breastplate
10785	atal ai leggings
10786	atal ai boots
10787	atal ai gloves
10788	atal ai girdle
10789	manual of engineering disciplines
10790	gnome engineer membership card
10791	goblin engineer membership card
10792	nixx s pledge of secrecy
10793	overspark s pledge of secrecy
10794	oglethorpe s pledge of secrecy
10795	drakeclaw band
10796	drakestone
10797	firebreather
10798	atal alarion s tusk ring
10799	headspike
10800	darkwater bracers
10801	slitherscale boots
10802	wingveil cloak
10803	blade of the wretched
10804	fist of the damned
10805	eater of the dead
10806	vestments of the atal ai prophet
10807	kilt of the atal ai prophet
10808	gloves of the atal ai prophet
10818	yeh kinya s scroll
10819	wildkin feather
10820	jackseed belt
10821	sower s cloak
10822	dark whelpling
10823	vanquisher s sword
10824	amberglow talisman
10826	staff of lore
10827	surveyor s tunic
10828	dire nail
10829	dragon s eye
10830	m73 frag grenade
10831	fel orb
10832	fel tracker owner s manual
10833	horns of eranikus
10834	felhound tracker kit
10835	crest of supremacy
10836	rod of corrosion
10837	tooth of eranikus
10838	might of hakkar
10839	crystallized note
10840	crystallized note
10841	goldthorn tea
10842	windscale sarong
10843	featherskin cape
10844	spire of hakkar
10845	warrior s embrace
10846	bloodshot greaves
10847	dragon s call
10858	plans solid iron maul
10918	wound poison
10919	apothecary gloves
10920	wound poison ii
10921	wound poison iii
10922	wound poison iv
10938	lesser magic essence
10939	greater magic essence
10940	strange dust
10958	hilary s necklace
10959	demon hide sack
10978	small glimmering shard
10998	lesser astral essence
10999	ironfel
11000	shadowforge key
11018	un goro soil
11020	evergreen pouch
11022	packet of tharlendris seeds
11023	ancona chicken
11024	evergreen herb casing
11026	tree frog box
11027	wood frog box
11038	formula enchant 2h weapon lesser spirit
11039	formula enchant cloak minor agility
11040	morrowgrain
11058	sha ni s nose ring
11078	relic coffer key
11079	gor tesh s lopped off head
11080	gor tesh s lopped off head
11081	formula enchant shield lesser protection
11082	greater astral essence
11083	soul dust
11084	large glimmering shard
11085	customer of the month coffer key
11086	jang thraze the protector
11098	formula enchant cloak lesser shadow resistance
11101	formula enchant bracer lesser strength
11102	unhatched sprite darter egg
11103	seed voucher
11104	large compass
11105	curled map parchment
11106	lion headed key
11107	a small pack
11108	faded photograph
11109	special chicken feed
11110	chicken egg
11111	broken sprite darter egg
11112	research equipment
11113	crate of foodstuffs
11114	dinosaur bone
11115	secret safe key
11116	a mangled journal
11118	archaedic stone
11119	milly s harvest
11120	belgrom s hammer
11121	darkwater talwar
11122	carrot on a stick
11123	rainstrider leggings
11124	helm of exile
11125	grape manifest
11126	tablet of kurniya
11127	scavenged goods
11128	golden rod
11129	essence of the elements
11130	runed golden rod
11131	hive wall sample
11132	unused scraping vial
11133	linken s training sword
11134	lesser mystic essence
11135	greater mystic essence
11136	linken s tempered sword
11137	vision dust
11138	small glowing shard
11139	large glowing shard
11140	prison cell key
11141	bait
11142	broken samophlange
11143	nugget slug
11144	truesilver rod
11145	runed truesilver rod
11146	broken and battered samophlange
11147	samophlange manual cover
11148	samophlange manual page
11149	samophlange manual
11150	formula enchant gloves mining
11151	formula enchant gloves herbalism
11152	formula enchant gloves fishing
11162	linken s superior sword
11163	formula enchant bracer lesser deflection
11164	formula enchant weapon lesser beastslayer
11165	formula enchant weapon lesser elemental slayer
11166	formula enchant gloves skinning
11167	formula enchant boots lesser spirit
11168	formula enchant shield lesser block
11169	book of aquor
11171	fel iron
11172	silvery claws
11173	irontree heart
11174	lesser nether essence
11175	greater nether essence
11176	dream dust
11177	small radiant shard
11178	large radiant shard
11179	golden flame
11184	blue power crystal
11185	green power crystal
11186	red power crystal
11187	stemleaf bracers
11188	yellow power crystal
11189	woodland robes
11190	viny gloves
11191	farmer s boots
11192	outfitter gloves
11193	blazewind breastplate
11194	prismscale hauberk
11195	warforged chestplate
11196	mindburst medallion
11197	dark keeper key
11198	rune of escape
11199	engineer s shield 1
11200	engineer s shield 2
11201	engineer s shield 3
11202	formula enchant shield stamina
11203	formula enchant gloves advanced mining
11204	formula enchant bracer greater spirit
11205	formula enchant gloves advanced herbalism
11206	formula enchant cloak lesser agility
11207	formula enchant weapon fiery weapon
11208	formula enchant weapon demonslaying
11222	head of krom zar
11223	formula enchant bracer deflection
11224	formula enchant shield frost resistance
11225	formula enchant bracer greater stamina
11226	formula enchant gloves riding skill
11227	piece of krom zar s banner
11228	frenzied dragonflight molt
11229	brightscale girdle
11230	encased fiery essence
11231	altered black dragonflight molt
11242	evoroot
11243	videre elixir
11262	orb of lorica
11263	nether force wand
11265	cragwood maul
11266	fractured elemental shard
11267	elemental shard sample
11268	head of argelmach
11269	intact elemental core
11270	nixx s signed pledge
11282	oglethorpe s signed pledge
11283	overspark s signed pledge
11284	accurate slugs
11285	jagged arrow
11286	thorium shackles
11287	lesser magic wand
11288	greater magic wand
11289	lesser mystic wand
11290	greater mystic wand
11291	star wood
11302	uther s strength
11303	fine shortbow
11304	fine longbow
11305	dense shortbow
11306	sturdy recurve
11307	massive longbow
11308	sylvan shortbow
11309	the heart of the mountain
11310	flameseer mantle
11311	emberscale cape
11312	lost thunderbrew recipe
11313	ribbly s head
11315	bloodpetal sprout
11316	bloodpetal
11318	atal ai haze
11319	unloaded zapper
11320	bloodpetal zapper
11324	explorer s knapsack
11325	dark iron ale mug
11362	medium quiver
11363	medium shot pouch
11364	tabard of stormwind
11366	helendis riverhorn s letter
11367	solomon s plea to bolvar
11368	bolvar s decree
11370	dark iron ore
11371	dark iron bar
11382	blood of the mountain
11384	broken basilisk teeth
11385	basilisk scale
11386	squishy basilisk eye
11387	basilisk heart
11388	basilisk venom
11389	shimmering basilisk skin
11390	broken bat fang
11391	spined bat wing
11392	severed bat claw
11393	small bat skull
11394	bat heart
11395	bat ear
11402	sleek bat pelt
11403	large bat fang
11404	evil bat eye
11405	giant silver vein
11406	rotting bear carcass
11407	torn bear pelt
11408	bear jaw
11409	bear flank
11410	savage bear claw
11411	large bear bone
11412	nagmara s vial
11413	nagmara s filled vial
11414	grizzled mane
11415	mixed berries
11416	delicate ribcage
11417	feathery wing
11418	hollow wing bone
11419	mysterious unhatched egg
11420	elegant writing tool
11422	goblin engineer s renewal gift
11423	gnome engineer s renewal gift
11444	grim guzzler boar
11445	flute of the ancients
11446	a crumpled up note
11462	discarded knife
11463	undelivered parcel
11464	marshal windsor s lost information
11465	marshal windsor s lost information
11466	raschal s report
11467	blackrock medallion
11468	dark iron fanny pack
11469	bloodband bracers
11470	tablet transcript
11471	fragile sprite darter egg
11472	silvermane stalker flank
11473	px83 enigmatron
11474	sprite darter egg
11475	wine stained cloak
11476	u cha s pelt
11477	white ravasaur claw
11478	un goro gorilla pelt
11479	un goro stomper pelt
11480	un goro thunderer pelt
11482	crystal pylon user s manual
11502	loreskin shoulders
11503	blood amber
11504	piece of threshadon carcass
11507	spotted hyena pelt
11508	gamemaster s slippers
11509	ravasaur pheromone gland
11510	lar korwi s head
11511	cenarion beacon
11512	patch of tainted skin
11513	tainted vitriol
11514	fel creep
11515	corrupted soul shard
11516	cenarion plant salve
11522	silver totem of aquementas
11562	crystal restore
11563	crystal force
11564	crystal ward
11565	crystal yield
11566	crystal charge
11567	crystal spire
11568	torwa s pouch
11569	preserved threshadon meat
11570	preserved pheromone mixture
11582	fel salve
11583	cactus apple
11584	cactus apple surprise
11590	mechanical repair kit
11602	grim guzzler key
11603	vilerend slicer
11604	dark iron plate
11605	dark iron shoulders
11606	dark iron mail
11607	dark iron sunderer
11608	dark iron pulverizer
11609	altered black dragonflight molt
11610	plans dark iron pulverizer
11611	plans dark iron sunderer
11612	plans dark iron plate
11614	plans dark iron mail
11615	plans dark iron shoulders
11617	eridan s supplies
11622	lesser arcanum of rumination
11623	spritecaster cape
11624	kentic amice
11625	enthralled sphere
11626	blackveil cape
11627	fleetfoot greaves
11628	houndmaster s bow
11629	houndmaster s rifle
11630	rockshard pellets
11631	stoneshell guard
11632	earthslag shoulders
11633	spiderfang carapace
11634	silkweb gloves
11635	hookfang shanker
11642	lesser arcanum of constitution
11643	lesser arcanum of tenacity
11644	lesser arcanum of resilience
11645	lesser arcanum of voracity
11646	lesser arcanum of voracity
11647	lesser arcanum of voracity
11648	lesser arcanum of voracity
11649	lesser arcanum of voracity
11662	ban thok sash
11665	ogreseer fists
11668	flute of xavaric
11669	naglering
11674	jadefire felbind
11675	shadefiend boots
11677	graverot cape
11678	carapace of anub shiah
11679	rubicund armguards
11682	eridan s vial
11684	ironfoe
11685	splinthide shoulders
11686	girdle of beastial fury
11702	grizzle s skinner
11703	stonewall girdle
11722	dregmetal spaulders
11723	goodsteel s balanced flameberge
11724	overdue package
11725	solid crystal leg shaft
11726	savage gladiator chain
11727	goodsteel ledger
11728	savage gladiator leggings
11729	savage gladiator helm
11730	savage gladiator grips
11731	savage gladiator greaves
11732	libram of rumination
11733	libram of constitution
11734	libram of tenacity
11735	ragefury eyepatch
11736	libram of resilience
11737	libram of voracity
11742	wayfarer s knapsack
11743	rockfist
11744	bloodfist
11745	fists of phalanx
11746	golem skull helm
11747	flamestrider robes
11748	pyric caduceus
11749	searingscale leggings
11750	kindling stave
11751	burning essence
11752	black blood of the tormented
11753	eye of kajal
11754	black diamond
11755	verek s collar
11764	cinderhide armsplints
11765	pyremail wristguards
11766	flameweave cuffs
11767	emberplate armguards
11768	incendic bracers
11782	boreal mantle
11783	chillsteel girdle
11784	arbiter s blade
11785	rock golem bulwark
11786	stone of the earth
11787	shalehusk boots
11802	lavacrest leggings
11803	force of magma
11804	spraggle s canteen
11805	rubidium hammer
11807	sash of the burning heart
11808	circle of flame
11809	flame wrath
11810	force of will
11811	smoking heart of the mountain
11812	cape of the fire salamander
11813	formula smoking heart of the mountain
11814	molten fists
11815	hand of justice
11816	angerforge s battle axe
11817	lord general s sword
11818	grimesilt outhouse key
11819	second wind
11820	royal decorated armor
11821	warstrife leggings
11822	omnicast boots
11823	luminary kilt
11824	cyclopean band
11825	pet bombling
11826	lil smoky
11827	schematic lil smoky
11828	schematic pet bombling
11829	un goro ash
11830	webbed diemetradon scale
11831	webbed pterrordax scale
11832	burst of knowledge
11833	gorishi queen lure
11834	super sticky tar
11835	gorishi queen brain
11837	gorishi scent gland
11839	chief architect s monocle
11840	master builder s shirt
11841	senior designer s pantaloons
11842	lead surveyor s mantle
11843	bank voucher
11844	pestlezugg s un goro report
11845	handmade leather bag
11846	wizbang s special brew
11847	battered cloak
11848	flax belt
11849	rustmetal bracers
11850	short duskbat cape
11851	scavenger tunic
11852	roamer s leggings
11853	rambling boots
11854	samophlange screwdriver
11855	tork wrench
11856	ceremonial elven blade
11857	sanctimonial rod
11858	battlehard cape
11859	jademoon orb
11860	charged lightning rod
11861	girdle of reprisal
11862	white bone band
11863	white bone shredder
11864	white bone spear
11865	rancor boots
11866	nagmara s whipping belt
11867	maddening gauntlets
11868	choking band
11869	sha ni s ring
11870	oblivion orb
11871	snarkshaw spaulders
11872	eschewal greaves
11873	ethereal mist cape
11874	clouddrift mantle
11875	breezecloud bracers
11876	plainstalker tunic
11882	outrider leggings
11883	a dingy fanny pack
11884	moonlit amice
11885	shadowforge torch
11886	urgent message
11887	cenarion circle cache
11888	quintis research gloves
11889	bark iron pauldrons
11902	linken s sword of mastery
11903	cat carrier corrupted kitten
11904	spirit of aquementas
11905	linken s boomerang
11906	beastsmasher
11907	beastslayer
11908	archaeologist s quarry boots
11909	excavator s utility belt
11910	bejeweled legguards
11911	treetop leggings
11912	package of empty ooze containers
11913	clayridge helm
11914	empty cursed ooze jar
11915	shizzle s drizzle blocker
11916	shizzle s muzzle
11917	shizzle s nozzle wiper
11918	grotslab gloves
11919	cragplate greaves
11920	wraith scythe
11921	impervious giant
11922	blood etched blade
11923	the hammer of grace
11924	robes of the royal crown
11925	ghostshroud
11926	deathdealer breastplate
11927	legplates of the eternal guardian
11928	thaurissan s royal scepter
11929	haunting specter leggings
11930	the emperor s new cape
11931	dreadforge retaliator
11932	guiding stave of wisdom
11933	imperial jewel
11934	emperor s seal
11935	magmus stone
11936	relic hunter belt
11937	fat sack of coins
11938	sack of gems
11939	shiny bracelet
11940	sparkly necklace
11941	false documents
11942	legal documents
11943	deed to thandol span
11944	dark iron baby booties
11945	dark iron ring
11946	fire opal necklace
11947	filled cursed ooze jar
11948	empty tainted ooze jar
11949	filled tainted ooze jar
11950	windblossom berries
11951	whipper root tuber
11952	night dragon s breath
11953	empty pure sample jar
11954	filled pure sample jar
11955	bag of empty ooze containers
11962	manacle cuffs
11963	penance spaulders
11964	swiftstrike cudgel
11965	quartz ring
11966	small sack of coins
11967	zircon band
11968	amber hoop
11969	jacinth circle
11970	spinel ring
11971	amethyst band
11972	carnelian loop
11973	hematite link
11974	aquamarine ring
11975	topaz ring
11976	sardonyx knuckle
11977	serpentine loop
11978	jasper link
11979	peridot circle
11980	opal ring
11981	lead band
11982	viridian band
11983	chrome ring
11984	cobalt ring
11985	cerulean ring
11986	thallium hoop
11987	iridium circle
11988	tellurium band
11989	vanadium loop
11990	selenium loop
11991	quicksilver ring
11992	vermilion band
11993	clay ring
11994	coral band
11995	ivory band
11996	basalt ring
11997	greenstone circle
11998	jet loop
11999	lodestone hoop
12000	limb cleaver
12001	onyx ring
12002	marble circle
12003	dark dwarven lager
12004	obsidian band
12005	granite ring
12006	meadow ring
12007	prairie ring
12008	savannah ring
12009	tundra ring
12010	fen ring
12011	forest hoop
12012	marsh ring
12013	desert ring
12014	arctic ring
12015	swamp ring
12016	jungle ring
12017	prismatic band
12018	conservator helm
12019	cerulean talisman
12020	thallium choker
12021	shieldplate sabatons
12022	iridium chain
12023	tellurium necklace
12024	vanadium talisman
12025	selenium chain
12026	quicksilver pendant
12027	vermilion necklace
12028	basalt necklace
12029	greenstone talisman
12030	jet chain
12031	lodestone necklace
12032	onyx choker
12033	thaurissan family jewels
12034	marble necklace
12035	obsidian pendant
12036	granite necklace
12037	mystery meat
12038	lagrave s seal
12039	tundra necklace
12040	forest pendant
12041	windshear leggings
12042	marsh chain
12043	desert choker
12044	arctic pendant
12045	swamp pendant
12046	jungle necklace
12047	spectral necklace
12048	prismatic pendant
12049	splintsteel armor
12050	hazecover boots
12051	brazen gauntlets
12052	ring of the moon
12053	volcanic rock ring
12054	demon band
12055	stardust band
12056	ring of the heavens
12057	dragonscale band
12058	demonic bone ring
12059	conqueror s medallion
12060	shindrell s note
12061	blade of reckoning
12062	skilled fighting blade
12064	gamemaster hood
12065	ward of the elements
12066	shaleskin cape
12082	wyrmhide spaulders
12083	valconian sash
12102	ring of the aristocrat
12103	star of mystaria
12104	brindlethorn tunic
12105	pridemail leggings
12106	boulderskin breastplate
12107	whispersilk leggings
12108	basaltscale armor
12109	azure moon amice
12110	raincaster drape
12111	lavaplate gauntlets
12112	crypt demon bracers
12113	sunborne cape
12114	nightfall gloves
12115	stalwart clutch
12122	kum isha s junk
12143	dragonspine key
12144	eggscilloscope
12162	plans hardened iron shortsword
12163	plans moonsteel broadsword
12164	plans massive iron axe
12184	raptor flesh
12185	bloodsail admiral s hat
12190	dreamless sleep potion
12191	silver dawning s lockbox
12192	mist veil s lockbox
12202	tiger meat
12203	red wolf meat
12204	heavy kodo meat
12205	white spider meat
12206	tender crab meat
12207	giant egg
12208	tender wolf meat
12209	lean wolf steak
12210	roast raptor
12211	spiced wolf ribs
12212	jungle stew
12213	carrion surprise
12214	mystery stew
12215	heavy kodo stew
12216	spiced chili crab
12217	dragonbreath chili
12219	unadorned seal of ascension
12220	intact elemental bracer
12223	meaty bat wing
12224	crispy bat wing
12225	blump family fishing pole
12226	recipe crispy bat wing
12227	recipe lean wolf steak
12228	recipe roast raptor
12229	recipe hot wolf ribs
12230	felwood slime sample
12231	recipe jungle stew
12232	recipe carrion surprise
12233	recipe mystery stew
12234	corrupted felwood sample
12235	un goro slime sample
12236	pure un goro sample
12237	fine crab chunks
12238	darkshore grouper
12239	recipe dragonbreath chili
12240	recipe heavy kodo stew
12241	collected dragon egg
12242	sea creature bones
12243	smoldering claw
12247	broad bladed knife
12248	daring dirk
12249	merciless axe
12250	midnight axe
12251	big stick
12252	staff of protection
12253	brilliant red cloak
12254	well oiled cloak
12255	pale leggings
12256	cindercloth leggings
12257	heavy notched belt
12258	serpent clasp belt
12259	glinting steel dagger
12260	searing golden blade
12261	plans searing golden blade
12262	empty worg pup cage
12263	caged worg pup
12264	worg carrier
12282	worn battleaxe
12283	broodling essence
12284	draco incarcinatrix 900
12286	eggscilloscope prototype
12287	collectronic module
12288	encased corrupt ooze
12289	sea turtle remains
12291	merged ooze sample
12292	strangely marked box
12293	fine gold thread
12295	leggings of the people s militia
12296	spark of the people s militia
12299	netted gloves
12300	orb of draconic energy
12301	bamboo cage key
12302	reins of the frostsaber
12303	reins of the nightsaber
12323	unforged seal of ascension
12324	forged seal of ascension
12325	reins of the primal leopard
12326	reins of the tawny sabercat
12327	reins of the golden sabercat
12330	horn of the red wolf
12334	frostmaul shards
12335	gemstone of smolderthorn
12336	gemstone of spirestone
12337	gemstone of bloodaxe
12339	vaelan s gift
12341	blackwood fruit sample
12342	blackwood grain sample
12343	blackwood nut sample
12344	seal of ascension
12345	bijou s belongings
12346	empty cleansing bowl
12347	filled cleansing bowl
12349	cliffspring river sample
12350	empty sampling tube
12351	horn of the arctic wolf
12352	doomrigger s clasp
12353	white stallion bridle
12354	palomino bridle
12355	talisman of corruption
12356	highperch wyvern egg
12358	darkstone tablet
12359	thorium bar
12360	arcanite bar
12361	blue sapphire
12363	arcane crystal
12364	huge emerald
12365	dense stone
12366	thick yeti fur
12367	pristine yeti horn
12368	dawn s gambit
12369	scepter of vectus
12382	key to the city
12383	moontouched feather
12384	cache of mau ari
12400	the judge s gavel
12402	ancient egg
12404	dense sharpening stone
12405	thorium armor
12406	thorium belt
12408	thorium bracers
12409	thorium boots
12410	thorium helm
12411	third mosh aru tablet
12412	fourth mosh aru tablet
12414	thorium leggings
12415	radiant breastplate
12416	radiant belt
12417	radiant circlet
12418	radiant gloves
12419	radiant boots
12420	radiant leggings
12422	imperial plate chest
12424	imperial plate belt
12425	imperial plate bracers
12426	imperial plate boots
12427	imperial plate helm
12428	imperial plate shoulders
12429	imperial plate leggings
12430	frostsaber e ko
12431	winterfall e ko
12432	shardtooth e ko
12433	wildkin e ko
12434	chillwind e ko
12435	ice thistle e ko
12436	frostmaul e ko
12437	ridgewell s crate
12438	tinkee s letter
12444	uncracked chillwind horn
12445	felnok s package
12446	anvilmar musket
12447	thistlewood bow
12448	light hunting rifle
12449	primitive bow
12450	juju flurry
12451	juju power
12455	juju ember
12457	juju chill
12458	juju guile
12459	juju escape
12460	juju might
12462	embrace of the wind serpent
12463	drakefang butcher
12464	bloodfire talons
12465	nightfall drape
12466	dawnspire cord
12467	alien egg
12468	chilton wand
12469	mutilator
12470	sandstalker ankleguards
12471	desertwalker cane
12472	krakle s thermometer
12522	bingles flying gloves
12524	blue feathered amulet
12525	jaron s supplies
12527	ribsplitter
12528	the judge s gavel
12529	smolderweb carrier
12530	spire spider egg
12531	searing needle
12532	spire of the stoneshaper
12533	roughshod pike
12534	omokk s head
12535	doomforged straightedge
12542	funeral pyre vestment
12543	songstone of ironforge
12544	thrall s resolve
12545	eye of orgrimmar
12546	aristocratic cuffs
12547	mar alom s grip
12548	magni s will
12549	braincage
12550	runed golem shackles
12551	stoneshield cloak
12552	blisterbane wrap
12553	swiftwalker boots
12554	hands of the exalted herald
12555	battlechaser s greaves
12556	high priestess boots
12557	ebonsteel spaulders
12558	blue feathered necklace
12562	important blackrock documents
12563	warlord goretooth s command
12564	assassination note
12565	winna s kitten carrier
12566	hardened flasket
12567	filled flasket
12582	keris of zul serak
12583	blackhand doomsaw
12584	grand marshal s longsword
12585	stormwind medallion
12586	immature venom sac
12587	eye of rend
12588	bonespike shoulder
12589	dustfeather sash
12590	felstriker
12592	blackblade of shahram
12602	draconian deflector
12603	nightbrace tunic
12604	starfire tiara
12605	serpentine skuller
12606	crystallized girdle
12607	brilliant chromatic scale
12608	butcher s apron
12609	polychromatic visionwrap
12610	runic plate shoulders
12611	runic plate boots
12612	runic plate helm
12613	runic breastplate
12614	runic plate leggings
12615	savage mail tunic
12616	savage mail boots
12617	savage mail shoulders
12618	enchanted thorium breastplate
12619	enchanted thorium leggings
12620	enchanted thorium helm
12621	demonfork
12622	shardtooth meat
12623	chillwind meat
12624	wildthorn mail
12625	dawnbringer shoulders
12626	funeral cuffs
12627	temporal displacer
12628	demon forged breastplate
12630	head of rend blackhand
12631	fiery plate gauntlets
12632	storm gauntlets
12633	whitesoul helm
12634	chiselbrand girdle
12635	simple parchment
12636	helm of the great chief
12637	backusarian gauntlets
12638	andorhal watch
12639	stronghold gauntlets
12640	lionheart helm
12641	invulnerable mail
12642	cleansed infernal orb
12643	dense weightstone
12644	dense grinding stone
12645	thorium shield spike
12646	infus emerald
12647	felhas ruby
12648	imprisoned felhound spirit
12649	imprisoned infernal spirit
12650	attuned dampener
12651	blackcrow
12652	bijou s reconnaissance report
12653	riphook
12654	doomshot
12655	enchanted thorium bar
12662	demonic rune
12663	glyphed oaken branch
12682	plans thorium armor
12683	plans thorium belt
12684	plans thorium bracers
12685	plans radiant belt
12687	plans imperial plate shoulders
12688	plans imperial plate belt
12689	plans radiant breastplate
12690	plans imperial plate bracers
12691	plans wildthorn mail
12692	plans thorium shield spike
12693	plans thorium boots
12694	plans thorium helm
12695	plans radiant gloves
12696	plans demon forged breastplate
12697	plans radiant boots
12698	plans dawnbringer shoulders
12699	plans fiery plate gauntlets
12700	plans imperial plate boots
12701	plans imperial plate helm
12702	plans radiant circlet
12703	plans storm gauntlets
12704	plans thorium leggings
12705	plans imperial plate chest
12706	plans runic plate shoulders
12707	plans runic plate boots
12708	crossroads supply crates
12709	finkle s skinner
12710	glowing hunk of the beast s flesh
12711	plans whitesoul helm
12712	warosh s mojo
12713	plans radiant leggings
12714	plans runic plate helm
12715	plans imperial plate leggings
12716	plans helm of the great chief
12717	plans lionheart helm
12718	plans runic breastplate
12719	plans runic plate leggings
12720	plans stronghold gauntlets
12721	good luck half charm
12722	good luck other half charm
12723	good luck charm
12724	janice s parcel
12725	plans enchanted thorium helm
12726	plans enchanted thorium leggings
12727	plans enchanted thorium breastplate
12728	plans invulnerable mail
12730	warosh s scroll
12731	pristine hide of the beast
12732	incendia agave
12733	sacred frostsaber meat
12734	enchanted scarlet thread
12735	frayed abomination stitching
12736	frostwhisper s embalming fluid
12737	gloom weed
12738	dalson outhouse key
12739	dalson cabinet key
12740	fifth mosh aru tablet
12741	sixth mosh aru tablet
12752	cap of the scarlet savant
12753	skin of shadow
12756	leggings of arcana
12757	breastplate of bloodthirst
12762	secrecy of plans
12763	un goro etherfruit
12764	thorium greatsword
12765	secret note #1
12766	secret note #2
12768	secret note #3
12769	bleakwood hew
12770	bijou s information
12771	empty firewater flask
12772	inlaid thorium hammer
12773	ornate thorium handaxe
12774	dawn s edge
12775	huge thorium battleaxe
12776	enchanted battlehammer
12777	blazing rapier
12778	document chest
12779	rune edge
12780	general drakkisath s command
12781	serenity
12782	corruption
12783	heartseeker
12784	arcanite reaper
12785	incendia powder
12790	arcanite champion
12791	barman shanker
12792	volcanic hammer
12793	mixologist s tunic
12794	masterwork stormhammer
12795	blood talon
12796	hammer of the titans
12797	frostguard
12798	annihilator
12799	large opal
12800	azerothian diamond
12802	darkspear
12803	living essence
12804	powerful mojo
12805	orb of fire
12806	unforged rune covered breastplate
12807	scourge banner
12808	essence of undeath
12809	guardian stone
12810	enchanted leather
12811	righteous orb
12812	unfired plate gauntlets
12813	flask of mystery goo
12814	flame in a bottle
12815	beacon torch
12816	plans thorium greatsword
12817	plans bleakwood hew
12818	plans inlaid thorium hammer
12819	plans ornate thorium handaxe
12820	winterfall firewater
12821	plans dawn s edge
12822	toxic horror droplet
12823	plans huge thorium battleaxe
12824	plans enchanted battlehammer
12825	plans blazing rapier
12826	plans rune edge
12827	plans serenity
12828	plans volcanic hammer
12829	winterfall crate
12830	plans corruption
12831	plans blood talon
12832	plans darkspear
12833	plans hammer of the titans
12834	plans arcanite champion
12835	plans annihilator
12836	plans frostguard
12837	plans masterwork stormhammer
12838	plans arcanite reaper
12839	plans heartseeker
12840	minion s scourgestone
12841	invader s scourgestone
12842	crudely written log
12843	corruptor s scourgestone
12844	argent dawn valor token
12845	medallion of faith
12846	argent dawn commission
12847	soul stained pike
12848	blood stained pike
12849	demon kissed sack
12871	chromatic carapace
12884	arnak s hoof
12885	pamela s doll
12886	pamela s doll s head
12887	pamela s doll s left side
12888	pamela s doll s right side
12891	jaron s pick
12894	joseph s wedding ring
12895	breastplate of the chromatic flight
12896	first relic fragment
12897	second relic fragment
12898	third relic fragment
12899	fourth relic fragment
12900	annals of darrowshire
12903	legguards of the chromatic defier
12904	shawn s super special swami hat
12905	wildfire cape
12906	purified moonwell water
12907	corrupt moonwell water
12922	empty canteen
12923	awbee s scale
12924	ritual candle
12925	arikara serpent skin
12926	flaming band
12927	truestrike shoulders
12928	umi s mechanical yeti
12929	emberfury talisman
12930	briarwood reed
12935	warmaster legguards
12936	battleborn armbraces
12938	blood of heroes
12939	dal rend s tribal guardian
12940	dal rend s sacred charge
12942	panther cage key
12945	legplates of the chromatic defier
12946	hypercapacitor gizmo
12947	alex s ring of audacity
12952	gyth s skull
12953	dragoneye coif
12954	davil s libram
12955	redpath s shield
12956	skull of horgus
12957	shattered sword of marduk
12958	recipe transmute arcanite
12960	tribal war feathers
12963	blademaster leggings
12964	tristam legguards
12965	spiritshroud leggings
12966	blackmist armguards
12967	bloodmoon cloak
12968	frostweaver cape
12969	seeping willow
12973	scarlet cannonball
12974	the black knight
12975	prospector axe
12976	ironpatch blade
12977	magefist gloves
12978	stormbringer belt
12979	firebane cloak
12982	silver linked footguards
12983	rakzur club
12984	skycaller
12985	ring of defense
12987	darkweave breeches
12988	starsight tunic
12989	gargoyle s bite
12990	razor s edge
12992	searing blade
12994	thorbia s gauntlets
12996	band of purification
12997	redbeard crest
12998	magician s mantle
12999	drakewing bands
13000	staff of hale magefire
13001	maiden s circle
13002	lady alizabeth s pendant
13003	lord alexander s battle axe
13004	torch of austen
13005	amy s blanket
13006	mass of mcgowan
13007	mageflame cloak
13008	dalewind trousers
13009	cow king s hide
13010	dreamsinger legguards
13011	silver lined belt
13012	yorgen bracers
13013	elder wizard s mantle
13014	axe of rin ji
13015	serathil
13016	killmaim
13017	hellslayer battle axe
13018	executioner s cleaver
13019	harpyclaw short bow
13020	skystriker bow
13021	needle threader
13022	gryphonwing long bow
13023	eaglehorn long bow
13024	beazel s basher
13025	deadwood sledge
13026	heaven s light
13027	bonesnapper
13028	bludstone hammer
13029	umbral crystal
13030	basilisk bone
13031	orb of mistmantle
13032	sword of corruption
13033	zealot blade
13034	speedsteel rapier
13035	serpent slicer
13036	assassination blade
13037	crystalpine stinger
13038	swiftwind
13039	skull splitting crossbow
13040	heartseeking crossbow
13041	guardian blade
13042	sword of the magistrate
13043	blade of the titans
13044	demonslayer
13045	viscous hammer
13046	blanchard s stout
13047	twig of the world tree
13048	looming gavel
13049	deanship claymore
13051	witchfury
13052	warmonger
13053	doombringer
13054	grim reaper
13055	bonechewer
13056	frenzied striker
13057	bloodpike
13058	khoo s point
13059	stoneraven
13060	the needler
13062	thunderwood
13063	starfaller
13064	jaina s firestarter
13065	wand of allistarj
13066	wyrmslayer spaulders
13067	hydralick armor
13068	obsidian greaves
13070	sapphiron s scale boots
13071	plated fist of hakoo
13072	stonegrip gauntlets
13073	mugthol s helm
13074	golem shard leggings
13075	direwing legguards
13076	giantslayer bracers
13077	girdle of uther
13079	shield of thorsen
13080	widow s clutch
13081	skullance shield
13082	mountainside buckler
13083	garrett family crest
13084	kaleidoscope chain
13085	horizon choker
13086	reins of the winterspring frostsaber
13087	river pride choker
13088	gazlowe s charm
13089	skibi s pendant
13090	breastplate of the chosen
13091	medallion of grand marshal morris
13093	blush ember ring
13094	the queen s jewel
13095	assault band
13096	band of the hierophant
13097	thunderbrow ring
13098	painweaver band
13099	moccasins of the white hare
13100	furen s boots
13101	wolfrunner shoes
13102	cassandra s grace
13103	pads of the venom spider
13105	sutarn s ring
13106	glowing magical bracelets
13107	magiskull cuffs
13108	tigerstrike mantle
13109	blackflame cape
13110	wolffear harness
13111	sandals of the insurgent
13112	winged helm
13113	feathermoon headdress
13114	troll s bane leggings
13115	sheepshear mantle
13116	spaulders of the unseen
13117	ogron s sash
13118	serpentine sash
13119	enchanted kodo bracers
13120	deepfury bracers
13121	wing of the whelpling
13122	dark phantom cape
13123	dreamwalker armor
13124	ravasaur scale boots
13125	elven chain boots
13126	battlecaller gauntlets
13127	frostreaver crown
13128	high bergg helm
13129	firemane leggings
13130	windrunner legguards
13131	sparkleshell mantle
13132	skeletal shoulders
13133	drakesfire epaulets
13134	belt of the gladiator
13135	lordly armguards
13136	lil timmy s peashooter
13137	ironweaver
13138	the silencer
13139	guttbuster
13140	blood red key
13141	tooth of gnarr
13142	brigam girdle
13143	mark of the dragon lord
13144	serenity belt
13145	enormous ogre belt
13146	shell launcher shotgun
13148	chillpike
13149	eldarathian tome of summoning vol 1
13151	the mystic studies of hor ank
13152	the story with no conclusion
13153	tome of mal cin vorail
13154	jael marin s studies of the arcane
13155	resonating skull
13156	mystic crystal
13157	fetid skull
13158	words of the high chief
13159	bone dust
13161	trindlehaven staff
13162	reiver claws
13163	relentless scythe
13164	heart of the scale
13166	slamshot shoulders
13167	fist of omokk
13168	plate of the shaman king
13169	tressermane leggings
13170	skyshroud leggings
13171	smokey s lighter
13172	siabi s premium tobacco
13173	flightblade throwing axe
13174	plagued flesh sample
13175	voone s twitchbow
13176	scourge data
13177	talisman of evasion
13178	rosewine circle
13179	brazecore armguards
13180	stratholme holy water
13181	demonskin gloves
13182	phase blade
13183	venomspitter
13184	fallbrush handgrips
13185	sunderseer mantle
13186	empty felstone field bottle
13187	empty dalson s tears bottle
13188	empty writhing haunt bottle
13189	empty gahrron s withering bottle
13190	filled felstone field bottle
13191	filled dalson s tears bottle
13192	filled writhing haunt bottle
13193	filled gahrron s withering bottle
13194	felstone field cauldron key
13195	dalson s tears cauldron key
13196	gahrron s withering cauldron key
13197	writhing haunt cauldron key
13198	hurd smasher
13199	crushridge bindings
13202	extended annals of darrowshire
13203	armswake cloak
13204	bashguuder
13205	rhombeard protector
13206	wolfshear leggings
13207	shadow lord fel dan s head
13208	bleak howler armguards
13209	seal of the dawn
13210	pads of the dread wolf
13211	slashclaw bracers
13212	halycon s spiked collar
13213	smolderweb s eye
13216	crown of the penitent
13217	band of the penitent
13218	fang of the crystal spider
13223	stratholme courier s pouch
13243	argent defender
13244	gilded gauntlets
13245	kresh s back
13246	argent avenger
13247	quartermaster zigris footlocker
13248	burstshot harquebus
13249	argent crusader
13250	head of balnazzar
13251	head of baron rivendare
13252	cloudrunner girdle
13253	hands of power
13254	astral guard
13255	trueaim gauntlets
13257	demonic runed spaulders
13258	slaghide gauntlets
13259	ribsteel footguards
13260	wind dancer boots
13261	globe of d sak
13262	ashbringer
13282	ogreseer tower boots
13283	magus ring
13284	swiftdart battleboots
13285	the nicker
13286	rivenspike
13287	pattern raptor hide harness
13288	pattern raptor hide belt
13289	egan s blaster
13302	market row postbox key
13303	crusaders square postbox key
13304	festival lane postbox key
13305	elders square postbox key
13306	king s square postbox key
13307	fras siabi s postbox key
13308	schematic ice deflector
13309	schematic lovingly crafted boomstick
13310	schematic accurate scope
13311	schematic mechanical dragonling
13313	sacred highborne writings
13314	alanna s embrace
13317	whistle of the ivory raptor
13320	arcane quickener
13321	green mechanostrider
13322	unpainted mechanostrider
13323	purple mechanostrider
13324	red and blue mechanostrider
13325	fluorescent green mechanostrider
13326	white mechanostrider mod a
13327	icy blue mechanostrider mod a
13328	black ram
13329	frost ram
13330	derek s radish bag
13331	red skeletal horse
13332	blue skeletal horse
13333	brown skeletal horse
13334	green skeletal warhorse
13335	deathcharger s reins
13340	cape of the black baron
13342	pet fish
13343	pet stone
13344	dracorian gauntlets
13345	seal of rivendare
13346	robes of the exalted
13347	crystal of zin malor
13348	demonshear
13349	scepter of the unholy
13350	insignia of the black guard
13351	crimson hammersmith s apron
13352	vosh gajin s snakestone
13353	book of the dead
13354	ectoplasmic resonator
13356	somatic intensifier
13357	osseous agitator
13358	wyrmtongue shoulders
13359	crown of tyranny
13360	gift of the elven magi
13361	skullforge reaver
13362	letter from the front
13363	municipal proclamation
13364	fras siabi s advertisement
13365	town meeting notice
13366	ingenious toy
13367	wrapped gift
13368	bonescraper
13369	fire striders
13370	vitreous focuser
13371	father flame
13372	slavedriver s cane
13373	band of flesh
13374	soulstealer mantle
13375	crest of retribution
13376	royal tribunal cloak
13377	miniature cannon balls
13378	songbird blouse
13379	piccolo of the flaming fire
13380	willey s portable howitzer
13381	master cannoneer boots
13382	cannonball runner
13383	woollies of the prancing minstrel
13384	rainbow girdle
13385	tome of knowledge
13386	archivist cape
13387	foresight girdle
13388	the postmaster s tunic
13389	the postmaster s trousers
13390	the postmaster s band
13391	the postmaster s treads
13392	the postmaster s seal
13393	malown s slam
13394	skul s cold embrace
13395	skul s fingerbone claws
13396	skul s ghastly touch
13397	stoneskin gargoyle cape
13398	boots of the shrieker
13399	gargoyle shredder talons
13400	vambraces of the sadist
13401	the cruel hand of timmy
13402	timmy s galoshes
13403	grimgore noose
13404	mask of the unforgiven
13405	wailing nightbane pauldrons
13408	soul breaker
13409	tearfall bracers
13422	stonescale eel
13423	stonescale oil
13442	mighty rage potion
13443	superior mana potion
13444	major mana potion
13445	elixir of superior defense
13446	major healing potion
13447	elixir of the sages
13448	the deed to caer darrow
13450	the deed to southshore
13451	the deed to tarren mill
13452	elixir of the mongoose
13453	elixir of brute force
13454	greater arcane elixir
13455	greater stoneshield potion
13456	greater frost protection potion
13457	greater fire protection potion
13458	greater nature protection potion
13459	greater shadow protection potion
13460	greater holy protection potion
13461	greater arcane protection potion
13462	purification potion
13463	dreamfoil
13464	golden sansam
13465	mountain silversage
13466	plaguebloom
13467	icecap
13468	black lotus
13469	head of weldon barov
13470	head of alexi barov
13471	the deed to brill
13473	felstone good luck charm
13474	farmer dalson s shotgun
13475	dalson family wedding ring
13476	recipe mighty rage potion
13477	recipe superior mana potion
13478	recipe elixir of superior defense
13479	recipe elixir of the sages
13480	recipe major healing potion
13481	recipe elixir of brute force
13482	recipe transmute air to fire
13483	recipe transmute fire to earth
13484	recipe transmute earth to water
13485	recipe transmute water to air
13486	recipe transmute undeath to water
13487	recipe transmute water to undeath
13488	recipe transmute life to earth
13489	recipe transmute earth to life
13490	recipe greater stoneshield potion
13491	recipe elixir of the mongoose
13492	recipe purification potion
13493	recipe greater arcane elixir
13494	recipe greater fire protection potion
13495	recipe greater frost protection potion
13496	recipe greater nature protection potion
13497	recipe greater arcane protection potion
13498	handcrafted mastersmith leggings
13499	recipe greater shadow protection potion
13500	recipe greater holy protection potion
13501	recipe major mana potion
13502	handcrafted mastersmith girdle
13503	alchemist s stone
13505	runeblade of baron rivendare
13506	flask of petrification
13507	cliffwatcher longhorn report
13508	eye of arachnida
13509	clutch of foresight
13510	flask of the titans
13511	flask of distilled wisdom
13512	flask of supreme power
13513	flask of chromatic resistance
13514	wail of the banshee
13515	ramstein s lightning bolts
13517	recipe alchemist s stone
13518	recipe flask of petrification
13519	recipe flask of the titans
13520	recipe flask of distilled wisdom
13521	recipe flask of supreme power
13522	recipe flask of chromatic resistance
13523	blood of innocents
13524	skull of burning shadows
13525	darkbind fingers
13526	flamescarred girdle
13527	lavawalker greaves
13528	twilight void bracers
13529	husk of nerub enkan
13530	fangdrip runners
13531	crypt stalker leggings
13532	darkspinner claws
13533	acid etched pauldrons
13534	banshee finger
13535	coldtouch phantom wraps
13536	horn of awakening
13537	chillhide bracers
13538	windshrieker pauldrons
13539	banshee s touch
13542	demon box
13544	spectral essence
13545	shellfish
13546	bloodbelly fish
13562	remains of trey lightforge
13582	zergling leash
13583	panda collar
13584	diablo stone
13585	keepsake of remembrance
13602	greater spellstone
13603	major spellstone
13624	soulbound keepsake
13626	human head of ras frostwhisper
13699	firestone
13700	greater firestone
13701	major firestone
13702	doom weed
13703	kodo bone
13704	skeleton key
13724	enriched manna biscuit
13725	krastinov s bag of horrors
13752	soulbound keepsake
13754	raw glossy mightfish
13755	winter squid
13756	raw summer bass
13757	lightning eel
13758	raw redgill
13759	raw nightfin snapper
13760	raw sunscale salmon
13761	frozen eggs
13810	blessed sunfruit
13811	necklace of the dawn
13812	ring of the dawn
13813	blessed sunfruit juice
13815	some rune
13816	fine longsword
13817	tapered greatsword
13818	jagged axe
13819	balanced war axe
13820	clout mace
13821	bulky maul
13822	spiked dagger
13823	stout war staff
13824	recurve long bow
13825	primed musket
13850	rumbleshot s ammo
13851	hot wolf ribs
13852	the grand crusader s command
13853	slab of carrion worm meat
13856	runecloth belt
13857	runecloth tunic
13858	runecloth robe
13860	runecloth cloak
13863	runecloth gloves
13864	runecloth boots
13865	runecloth pants
13866	runecloth headband
13867	runecloth shoulders
13868	frostweave robe
13869	frostweave tunic
13870	frostweave gloves
13871	frostweave pants
13872	bundle of wood
13873	viewing room key
13874	heavy crate
13875	ironbound locked chest
13881	bloated redgill
13888	darkclaw lobster
13889	raw whitescale salmon
13890	plated armorfish
13891	bloated salmon
13892	kodo kombobulator
13893	large raw mightfish
13895	formal dangui
13896	dark green wedding hanbok
13897	white traditional hanbok
13898	royal dangui
13899	red traditional hanbok
13900	green wedding hanbok
13918	reinforced locked chest
13920	healthy dragon scale
13926	golden pearl
13927	cooked glossy mightfish
13928	grilled squid
13929	hot smoked bass
13930	filet of redgill
13931	nightfin soup
13932	poached sunscale salmon
13933	lobster stew
13934	mightfish steak
13935	baked salmon
13937	headmaster s charge
13938	bonecreeper stylus
13939	recipe spotted yellowtail
13940	recipe cooked glossy mightfish
13941	recipe filet of redgill
13942	recipe grilled squid
13943	recipe hot smoked bass
13944	tombstone breastplate
13945	recipe nightfin soup
13946	recipe poached sunscale salmon
13947	recipe lobster stew
13948	recipe mightfish steak
13949	recipe baked salmon
13950	detention strap
13951	vigorsteel vambraces
13952	iceblade hacker
13953	silent fang
13954	verdant footpads
13955	stoneform shoulders
13956	clutch of andros
13957	gargoyle slashers
13958	wyrmthalak s shackles
13959	omokk s girth restrainer
13960	heart of the fiend
13961	halycon s muzzle
13962	vosh gajin s strand
13963	voone s vice grips
13964	witchblade
13965	blackhand s breadth
13966	mark of tyranny
13967	windreaver greaves
13968	eye of the beast
13969	loomguard armbraces
13982	warblade of caer darrow
13983	gravestone war axe
13984	darrowspike
13986	crown of caer darrow
14002	darrowshire strongguard
14022	barov peasant caller
14023	barov peasant caller
14024	frightalon
14025	mystic s belt
14042	cindercloth vest
14043	cindercloth gloves
14044	cindercloth cloak
14045	cindercloth pants
14046	runecloth bag
14047	runecloth
14048	bolt of runecloth
14062	kodo mount
14086	beaded sandals
14087	beaded cuffs
14088	beaded cloak
14089	beaded gloves
14090	beaded britches
14091	beaded robe
14093	beaded cord
14094	beaded wraps
14095	native bands
14096	native vest
14097	native pants
14098	native cloak
14099	native sash
14100	brightcloth robe
14101	brightcloth gloves
14102	native handwraps
14103	brightcloth cloak
14104	brightcloth pants
14106	felcloth robe
14107	felcloth pants
14108	felcloth boots
14109	native robe
14110	native sandals
14111	felcloth hood
14112	felcloth shoulders
14113	aboriginal sash
14114	aboriginal footwraps
14115	aboriginal bands
14116	aboriginal cape
14117	aboriginal gloves
14119	aboriginal loincloth
14120	aboriginal robe
14121	aboriginal vest
14122	ritual bands
14123	ritual cape
14124	ritual gloves
14125	ritual leggings
14126	ritual amice
14127	ritual shroud
14128	wizardweave robe
14129	ritual sandals
14130	wizardweave turban
14131	ritual belt
14132	wizardweave leggings
14133	ritual tunic
14134	cloak of fire
14136	robe of winter night
14137	mooncloth leggings
14138	mooncloth vest
14139	mooncloth shoulders
14140	mooncloth circlet
14141	ghostweave vest
14142	ghostweave gloves
14143	ghostweave belt
14144	ghostweave pants
14145	cursed felblade
14146	gloves of spell mastery
14147	cavedweller bracers
14148	crystalline cuffs
14149	subterranean cape
14150	robe of evocation
14151	chanting blade
14152	robe of the archmage
14153	robe of the void
14154	truefaith vestments
14155	mooncloth bag
14156	bottomless bag
14157	pagan mantle
14158	pagan vest
14159	pagan shoes
14160	pagan bands
14161	pagan cape
14162	pagan mitts
14163	pagan wraps
14164	pagan belt
14165	pagan britches
14166	buccaneer s bracers
14167	buccaneer s cape
14168	buccaneer s gloves
14169	aboriginal shoulder pads
14170	buccaneer s mantle
14171	buccaneer s pants
14172	buccaneer s robes
14173	buccaneer s cord
14174	buccaneer s boots
14175	buccaneer s vest
14176	watcher s boots
14177	watcher s cuffs
14178	watcher s cap
14179	watcher s cape
14180	watcher s jerkin
14181	watcher s handwraps
14182	watcher s mantle
14183	watcher s leggings
14184	watcher s robes
14185	watcher s cinch
14186	raincaller mantle
14187	raincaller cuffs
14188	raincaller cloak
14189	raincaller cap
14190	raincaller vest
14191	raincaller mitts
14192	raincaller robes
14193	raincaller pants
14194	raincaller cord
14195	raincaller boots
14196	thistlefur sandals
14197	thistlefur bands
14198	thistlefur cloak
14199	thistlefur gloves
14200	thistlefur cap
14201	thistlefur mantle
14202	thistlefur jerkin
14203	thistlefur pants
14204	thistlefur robe
14205	thistlefur belt
14206	vital bracelets
14207	vital leggings
14208	vital headband
14209	vital sash
14210	vital cape
14211	vital handwraps
14212	vital shoulders
14213	vital raiment
14214	vital boots
14215	vital tunic
14216	geomancer s jerkin
14217	geomancer s cord
14218	geomancer s boots
14219	geomancer s cloak
14220	geomancer s cap
14221	geomancer s bracers
14222	geomancer s gloves
14223	geomancer s spaulders
14224	geomancer s trousers
14225	geomancer s wraps
14226	embersilk bracelets
14227	ironweb spider silk
14228	embersilk coronet
14229	embersilk cloak
14230	embersilk tunic
14231	embersilk mitts
14232	embersilk mantle
14233	embersilk leggings
14234	embersilk robes
14235	embersilk cord
14236	embersilk boots
14237	darkmist armor
14238	darkmist boots
14239	darkmist cape
14240	darkmist bands
14241	darkmist handguards
14242	darkmist pants
14243	darkmist mantle
14244	darkmist wraps
14245	darkmist girdle
14246	darkmist wizard hat
14247	lunar mantle
14248	lunar bindings
14249	lunar vest
14250	lunar slippers
14251	lunar cloak
14252	lunar coronet
14253	lunar handwraps
14254	lunar raiment
14255	lunar belt
14256	felcloth
14257	lunar leggings
14258	bloodwoven cord
14259	bloodwoven boots
14260	bloodwoven bracers
14261	bloodwoven cloak
14262	bloodwoven mitts
14263	bloodwoven mask
14264	bloodwoven pants
14265	bloodwoven wraps
14266	bloodwoven pads
14267	bloodwoven jerkin
14268	gaea s cuffs
14269	gaea s slippers
14270	gaea s cloak
14271	gaea s circlet
14272	gaea s handwraps
14273	gaea s amice
14274	gaea s leggings
14275	gaea s raiment
14276	gaea s belt
14277	gaea s tunic
14278	opulent mantle
14279	opulent bracers
14280	opulent cape
14281	opulent crown
14282	opulent gloves
14283	opulent leggings
14284	opulent robes
14285	opulent boots
14286	opulent belt
14287	opulent tunic
14288	arachnidian armor
14289	arachnidian girdle
14290	arachnidian footpads
14291	arachnidian bracelets
14292	arachnidian cape
14293	arachnidian circlet
14294	arachnidian gloves
14295	arachnidian legguards
14296	arachnidian pauldrons
14297	arachnidian robes
14298	bonecaster s spaulders
14299	bonecaster s boots
14300	bonecaster s cape
14301	bonecaster s bindings
14302	bonecaster s gloves
14303	bonecaster s shroud
14304	bonecaster s belt
14305	bonecaster s sarong
14306	bonecaster s vest
14307	bonecaster s crown
14308	celestial tunic
14309	celestial belt
14310	celestial slippers
14311	celestial bindings
14312	celestial crown
14313	celestial cape
14314	celestial handwraps
14315	celestial kilt
14316	celestial pauldrons
14317	celestial silk robes
14318	resplendent tunic
14319	resplendent boots
14320	resplendent bracelets
14321	resplendent cloak
14322	resplendent circlet
14323	resplendent gauntlets
14324	resplendent sarong
14325	resplendent epaulets
14326	resplendent robes
14327	resplendent belt
14328	eternal chestguard
14329	eternal boots
14330	eternal bindings
14331	eternal cloak
14332	eternal crown
14333	eternal gloves
14334	eternal sarong
14335	eternal spaulders
14336	eternal wraps
14337	eternal cord
14338	empty water tube
14339	moonwell water tube
14340	freezing lich robes
14341	rune thread
14342	mooncloth
14343	small brilliant shard
14344	large brilliant shard
14364	mystic s slippers
14365	mystic s cape
14366	mystic s bracelets
14367	mystic s gloves
14368	mystic s shoulder pads
14369	mystic s wrap
14370	mystic s woolies
14371	mystic s robe
14372	sanguine armor
14373	sanguine belt
14374	sanguine sandals
14375	sanguine cuffs
14376	sanguine cape
14377	sanguine handwraps
14378	sanguine mantle
14379	sanguine trousers
14380	sanguine robe
14381	grimtotem satchel
14395	spells of shadow
14396	incantations from the nether
14397	resilient mantle
14398	resilient tunic
14399	resilient boots
14400	resilient cape
14401	resilient cap
14402	resilient bands
14403	resilient handgrips
14404	resilient leggings
14405	resilient robe
14406	resilient cord
14407	stonecloth vest
14408	stonecloth boots
14409	stonecloth cape
14410	stonecloth circlet
14411	stonecloth gloves
14412	stonecloth epaulets
14413	stonecloth robe
14414	stonecloth belt
14415	stonecloth britches
14416	stonecloth bindings
14417	silksand tunic
14418	silksand boots
14419	silksand bracers
14420	silksand cape
14421	silksand circlet
14422	silksand gloves
14423	silksand shoulder pads
14424	silksand legwraps
14425	silksand wraps
14426	silksand girdle
14427	windchaser wraps
14428	windchaser footpads
14429	windchaser cuffs
14430	windchaser cloak
14431	windchaser handguards
14432	windchaser amice
14433	windchaser woolies
14434	windchaser robes
14435	windchaser cinch
14436	windchaser coronet
14437	venomshroud vest
14438	venomshroud boots
14439	venomshroud armguards
14440	venomshroud cape
14441	venomshroud mask
14442	venomshroud mitts
14443	venomshroud mantle
14444	venomshroud leggings
14445	venomshroud silk robes
14446	venomshroud belt
14447	highborne footpads
14448	highborne bracelets
14449	highborne crown
14450	highborne cloak
14451	highborne gloves
14452	highborne pauldrons
14453	highborne robes
14454	highborne cord
14455	highborne padded armor
14456	elunarian vest
14457	elunarian cuffs
14458	elunarian boots
14459	elunarian cloak
14460	elunarian diadem
14461	elunarian handgrips
14462	elunarian sarong
14463	elunarian spaulders
14464	elunarian silk robes
14465	elunarian belt
14466	pattern frostweave tunic
14467	pattern frostweave robe
14468	pattern runecloth bag
14469	pattern runecloth robe
14470	pattern runecloth tunic
14471	pattern cindercloth vest
14472	pattern runecloth cloak
14473	pattern ghostweave belt
14474	pattern frostweave gloves
14476	pattern cindercloth gloves
14477	pattern ghostweave gloves
14478	pattern brightcloth robe
14479	pattern brightcloth gloves
14480	pattern ghostweave vest
14481	pattern runecloth gloves
14482	pattern cindercloth cloak
14483	pattern felcloth pants
14484	pattern brightcloth cloak
14485	pattern wizardweave leggings
14486	pattern cloak of fire
14487	bonechill hammer
14488	pattern runecloth boots
14489	pattern frostweave pants
14490	pattern cindercloth pants
14491	pattern runecloth pants
14492	pattern felcloth boots
14493	pattern robe of winter night
14494	pattern brightcloth pants
14495	pattern ghostweave pants
14496	pattern felcloth hood
14497	pattern mooncloth leggings
14498	pattern runecloth headband
14499	pattern mooncloth bag
14500	pattern wizardweave robe
14501	pattern mooncloth vest
14502	frostbite girdle
14503	death s clutch
14504	pattern runecloth shoulders
14505	pattern wizardweave turban
14506	pattern felcloth robe
14507	pattern mooncloth shoulders
14508	pattern felcloth shoulders
14509	pattern mooncloth circlet
14510	pattern bottomless bag
14511	pattern gloves of spell mastery
14512	pattern truefaith vestments
14513	pattern robe of the archmage
14514	pattern robe of the void
14522	maelstrom leggings
14523	demon pick
14525	boneclenched gauntlets
14526	pattern mooncloth
14528	rattlecage buckler
14529	runecloth bandage
14530	heavy runecloth bandage
14531	frightskull shaft
14536	bonebrace hauberk
14537	corpselight greaves
14538	deadwalker mantle
14539	bone ring helm
14540	taragaman the hungerer s heart
14541	barovian family sword
14542	kravel s crate
14543	darkshade gloves
14544	lieutenant s insignia
14545	ghostloom leggings
14546	roon s kodo horn
14547	hand of iruxos
14548	royal cap spaulders
14549	boots of avoidance
14550	bladebane armguards
14551	edgemaster s handguards
14552	stockade pauldrons
14553	sash of mercy
14554	cloudkeeper legplates
14555	alcor s sunrazor
14557	the lion horn of stormwind
14558	lady maye s pendant
14559	prospector s sash
14560	prospector s boots
14561	prospector s cuffs
14562	prospector s chestpiece
14563	prospector s cloak
14564	prospector s mitts
14565	prospector s woolies
14566	prospector s pads
14567	bristlebark belt
14568	bristlebark boots
14569	bristlebark bindings
14570	bristlebark blouse
14571	bristlebark cape
14572	bristlebark gloves
14573	bristlebark amice
14574	bristlebark britches
14576	ebon hilt of marduk
14577	skullsmoke pants
14578	dokebi cord
14579	dokebi boots
14580	dokebi bracers
14581	dokebi chestguard
14582	dokebi cape
14583	dokebi gloves
14584	dokebi hat
14585	dokebi leggings
14587	dokebi mantle
14588	hawkeye s cord
14589	hawkeye s shoes
14590	hawkeye s bracers
14591	hawkeye s helm
14592	hawkeye s tunic
14593	hawkeye s cloak
14594	hawkeye s gloves
14595	hawkeye s breeches
14596	hawkeye s epaulets
14598	warden s waistband
14599	warden s footpads
14600	warden s wristbands
14601	warden s wraps
14602	warden s cloak
14603	warden s mantle
14604	warden s wizard hat
14605	warden s woolies
14606	warden s gloves
14607	hawkeye s buckler
14608	dokebi buckler
14610	araj s scarab
14611	bloodmail hauberk
14612	bloodmail legguards
14613	taelan s hammer
14614	bloodmail belt
14615	bloodmail gauntlets
14616	bloodmail boots
14617	sawbones shirt
14619	skeletal fragments
14620	deathbone girdle
14621	deathbone sabatons
14622	deathbone gauntlets
14623	deathbone legguards
14624	deathbone chestplate
14625	symbol of lost honor
14626	necropile robe
14627	pattern bright yellow shirt
14628	imbued skeletal fragments
14629	necropile cuffs
14630	pattern enchanter s cowl
14631	necropile boots
14632	necropile leggings
14633	necropile mantle
14634	recipe frost oil
14635	pattern gem studded leather belt
14636	cadaverous belt
14637	cadaverous armor
14638	cadaverous leggings
14639	schematic minor recombobulator
14640	cadaverous gloves
14641	cadaverous walkers
14644	skeleton key mold
14645	unfinished skeleton key
14646	northshire gift voucher
14647	coldridge valley gift voucher
14648	shadowglen gift voucher
14649	valley of trials gift voucher
14650	camp narache gift voucher
14651	deathknell gift voucher
14652	scorpashi sash
14653	scorpashi slippers
14654	scorpashi wristbands
14655	scorpashi breastplate
14656	scorpashi cape
14657	scorpashi gloves
14658	scorpashi skullcap
14659	scorpashi leggings
14660	scorpashi shoulder pads
14661	keeper s cord
14662	keeper s hooves
14663	keeper s bindings
14664	keeper s armor
14665	keeper s cloak
14666	keeper s gloves
14667	keeper s wreath
14668	keeper s woolies
14669	keeper s mantle
14670	pridelord armor
14671	pridelord boots
14672	pridelord bands
14673	pridelord cape
14674	pridelord girdle
14675	pridelord gloves
14676	pridelord halo
14677	pridelord pants
14678	pridelord pauldrons
14679	of love and family
14680	indomitable vest
14681	indomitable boots
14682	indomitable armguards
14683	indomitable cloak
14684	indomitable belt
14685	indomitable gauntlets
14686	indomitable headdress
14687	indomitable leggings
14688	indomitable epaulets
14722	war paint anklewraps
14723	war paint bindings
14724	war paint cloak
14725	war paint waistband
14726	war paint gloves
14727	war paint legguards
14728	war paint shoulder pads
14729	war paint shield
14730	war paint chestpiece
14742	hulking boots
14743	hulking bands
14744	hulking chestguard
14745	hulking cloak
14746	hulking belt
14747	hulking gauntlets
14748	hulking leggings
14749	hulking spaulders
14750	slayer s cuffs
14751	slayer s surcoat
14752	slayer s cape
14753	slayer s skullcap
14754	slayer s gloves
14755	slayer s sash
14756	slayer s slippers
14757	slayer s pants
14758	slayer s shoulder pads
14759	enduring bracers
14760	enduring breastplate
14761	enduring belt
14762	enduring boots
14763	enduring cape
14764	enduring gauntlets
14765	enduring circlet
14766	enduring breeches
14767	enduring pauldrons
14768	ravager s armor
14769	ravager s sandals
14770	ravager s armguards
14771	ravager s cloak
14772	ravager s handwraps
14773	ravager s cord
14774	ravager s crown
14775	ravager s woolies
14776	ravager s mantle
14777	ravager s shield
14778	khan s bindings
14779	khan s chestpiece
14780	khan s buckler
14781	khan s cloak
14782	khan s gloves
14783	khan s belt
14784	khan s greaves
14785	khan s helmet
14786	khan s legguards
14787	khan s mantle
14788	protector armguards
14789	protector breastplate
14790	protector buckler
14791	protector cape
14792	protector gauntlets
14793	protector waistband
14794	protector ankleguards
14795	protector helm
14796	protector legguards
14797	protector pads
14798	bloodlust breastplate
14799	bloodlust boots
14800	bloodlust buckler
14801	bloodlust cape
14802	bloodlust gauntlets
14803	bloodlust belt
14804	bloodlust helm
14805	bloodlust britches
14806	bloodlust epaulets
14807	bloodlust bracelets
14808	warstrike belt
14809	warstrike sabatons
14810	warstrike armsplints
14811	warstrike chestguard
14812	warstrike buckler
14813	warstrike cape
14814	warstrike helmet
14815	warstrike gauntlets
14816	warstrike legguards
14817	warstrike shoulder pads
14821	symbolic breastplate
14825	symbolic crest
14826	symbolic gauntlets
14827	symbolic belt
14828	symbolic greaves
14829	symbolic legplates
14830	symbolic pauldrons
14831	symbolic crown
14832	symbolic vambraces
14833	tyrant s gauntlets
14834	tyrant s armguards
14835	tyrant s chestpiece
14838	tyrant s belt
14839	tyrant s greaves
14840	tyrant s legplates
14841	tyrant s epaulets
14842	tyrant s shield
14843	tyrant s helm
14844	sunscale chestguard
14846	sunscale gauntlets
14847	sunscale belt
14848	sunscale sabatons
14849	sunscale helmet
14850	sunscale legplates
14851	sunscale spaulders
14852	sunscale shield
14853	sunscale wristguards
14854	vanguard breastplate
14855	vanguard gauntlets
14856	vanguard girdle
14857	vanguard sabatons
14858	vanguard headdress
14859	vanguard legplates
14860	vanguard pauldrons
14861	vanguard vambraces
14862	warleader s breastplate
14863	warleader s gauntlets
14864	warleader s belt
14865	warleader s greaves
14866	warleader s crown
14867	warleader s leggings
14868	warleader s shoulders
14869	warleader s bracers
14872	tirion s gift
14894	lily root
14895	saltstone surcoat
14896	saltstone sabatons
14897	saltstone gauntlets
14898	saltstone girdle
14899	saltstone helm
14900	saltstone legplates
14901	saltstone shoulder pads
14902	saltstone shield
14903	saltstone armsplints
14904	brutish breastplate
14905	brutish gauntlets
14906	brutish belt
14907	brutish helmet
14908	brutish legguards
14909	brutish shoulders
14910	brutish armguards
14911	brutish boots
14912	brutish shield
14913	jade greaves
14914	jade bracers
14915	jade breastplate
14916	jade deflector
14917	jade gauntlets
14918	jade belt
14919	jade circlet
14920	jade legplates
14921	jade epaulets
14922	lofty sabatons
14923	lofty armguards
14924	lofty breastplate
14925	lofty helm
14926	lofty gauntlets
14927	lofty belt
14928	lofty legguards
14929	lofty shoulder pads
14930	lofty shield
14931	heroic armor
14932	heroic greaves
14933	heroic gauntlets
14934	heroic girdle
14935	heroic skullcap
14936	heroic legplates
14937	heroic pauldrons
14938	heroic bracers
14939	warbringer s chestguard
14940	warbringer s sabatons
14941	warbringer s armsplints
14942	warbringer s gauntlets
14943	warbringer s belt
14944	warbringer s crown
14945	warbringer s legguards
14946	warbringer s spaulders
14947	warbringer s shield
14948	bloodforged chestpiece
14949	bloodforged gauntlets
14950	bloodforged belt
14951	bloodforged sabatons
14952	bloodforged helmet
14953	bloodforged legplates
14954	bloodforged shield
14955	bloodforged shoulder pads
14956	bloodforged bindings
14957	high chief s sabatons
14958	high chief s armor
14959	high chief s gauntlets
14960	high chief s belt
14961	high chief s crown
14962	high chief s legguards
14963	high chief s pauldrons
14964	high chief s shield
14965	high chief s bindings
14966	glorious breastplate
14967	glorious gauntlets
14968	glorious belt
14969	glorious headdress
14970	glorious legplates
14971	glorious shoulder pads
14972	glorious sabatons
14973	glorious shield
14974	glorious bindings
14975	exalted harness
14976	exalted gauntlets
14977	exalted girdle
14978	exalted sabatons
14979	exalted helmet
14980	exalted legplates
14981	exalted epaulets
14982	exalted shield
14983	exalted armsplints
15002	nimboya s pike
15003	primal belt
15004	primal boots
15005	primal bands
15006	primal buckler
15007	primal cape
15008	primal mitts
15009	primal leggings
15010	primal wraps
15011	lupine cord
15012	lupine slippers
15013	lupine cuffs
15014	lupine buckler
15015	lupine cloak
15016	lupine handwraps
15017	lupine leggings
15018	lupine vest
15019	lupine mantle
15042	empty termite jar
15043	plagueland termites
15044	barrel of plagueland termites
15045	green dragonscale breastplate
15046	green dragonscale leggings
15047	red dragonscale breastplate
15048	blue dragonscale breastplate
15049	blue dragonscale shoulders
15050	black dragonscale breastplate
15051	black dragonscale shoulders
15052	black dragonscale leggings
15053	volcanic breastplate
15054	volcanic leggings
15055	volcanic shoulders
15056	stormshroud armor
15057	stormshroud pants
15058	stormshroud shoulders
15059	living breastplate
15060	living leggings
15061	living shoulders
15062	devilsaur leggings
15063	devilsaur gauntlets
15064	warbear harness
15065	warbear woolies
15066	ironfeather breastplate
15067	ironfeather shoulders
15068	frostsaber tunic
15069	frostsaber leggings
15070	frostsaber gloves
15071	frostsaber boots
15072	chimeric leggings
15073	chimeric boots
15074	chimeric gloves
15075	chimeric vest
15076	heavy scorpid vest
15077	heavy scorpid bracers
15078	heavy scorpid gauntlet
15079	heavy scorpid leggings
15080	heavy scorpid helm
15081	heavy scorpid shoulders
15082	heavy scorpid belt
15083	wicked leather gauntlets
15084	wicked leather bracers
15085	wicked leather armor
15086	wicked leather headband
15087	wicked leather pants
15088	wicked leather belt
15090	runic leather armor
15091	runic leather gauntlets
15092	runic leather bracers
15093	runic leather belt
15094	runic leather headband
15095	runic leather pants
15096	runic leather shoulders
15102	un goro tested sample
15103	corrupt tested sample
15104	wingborne boots
15105	staff of noh orahil
15106	staff of dar orahil
15107	orb of noh orahil
15108	orb of dar orahil
15109	staff of soran ruk
15110	rigid belt
15111	rigid moccasins
15112	rigid bracelets
15113	rigid buckler
15114	rigid cape
15115	rigid gloves
15116	rigid shoulders
15117	rigid leggings
15118	rigid tunic
15119	highborne pants
15120	robust girdle
15121	robust boots
15122	robust bracers
15123	robust buckler
15124	robust cloak
15125	robust gloves
15126	robust leggings
15127	robust shoulders
15128	robust tunic
15129	robust helm
15130	cutthroat s vest
15131	cutthroat s boots
15132	cutthroat s armguards
15133	cutthroat s buckler
15134	cutthroat s hat
15135	cutthroat s cape
15136	cutthroat s belt
15137	cutthroat s mitts
15138	onyxia scale cloak
15139	cutthroat s pants
15140	cutthroat s mantle
15142	ghostwalker boots
15143	ghostwalker bindings
15144	ghostwalker rags
15145	ghostwalker buckler
15146	ghostwalker crown
15147	ghostwalker cloak
15148	ghostwalker belt
15149	ghostwalker gloves
15150	ghostwalker pads
15151	ghostwalker legguards
15152	nocturnal shoes
15153	nocturnal cloak
15154	nocturnal sash
15155	nocturnal gloves
15156	nocturnal cap
15157	nocturnal leggings
15158	nocturnal shoulder pads
15159	nocturnal tunic
15160	nocturnal wristbands
15161	imposing belt
15162	imposing boots
15163	imposing bracers
15164	imposing vest
15165	imposing cape
15166	imposing gloves
15167	imposing bandana
15168	imposing pants
15169	imposing shoulders
15170	potent armor
15171	potent boots
15172	potent bands
15173	potent cape
15174	potent gloves
15175	potent helmet
15176	potent pants
15177	potent shoulders
15178	potent belt
15179	praetorian padded armor
15180	praetorian girdle
15181	praetorian boots
15182	praetorian wristbands
15183	praetorian cloak
15184	praetorian gloves
15185	praetorian coif
15186	praetorian leggings
15187	praetorian pauldrons
15188	grand armguards
15189	grand boots
15190	grand cloak
15191	grand belt
15192	grand gauntlets
15193	grand crown
15194	grand legguards
15195	grand breastplate
15196	private s tabard
15197	scout s tabard
15198	knight s colors
15199	stone guard s herald
15200	senior sergeant s insignia
15202	wildkeeper leggings
15203	guststorm legguards
15204	moonstone wand
15205	owlsight rifle
15206	jadefinger baton
15207	steelcap shield
15208	cenarion moondust
15209	relic bundle
15210	raider shortsword
15211	militant shortsword
15212	fighter broadsword
15213	mercenary blade
15214	nobles brand
15215	furious falchion
15216	rune sword
15217	widow blade
15218	crystal sword
15219	dimensional blade
15220	battlefell sabre
15221	holy war sword
15222	barbed club
15223	jagged star
15224	battlesmasher
15225	sequoia hammer
15226	giant club
15227	diamond tip bludgeon
15228	smashing star
15229	blesswind hammer
15230	ridge cleaver
15231	splitting hatchet
15232	hacking cleaver
15233	savage axe
15234	greater scythe
15235	crescent edge
15236	moon cleaver
15237	corpse harvester
15238	warlord s axe
15239	felstone reaver
15240	demon s claw
15241	battle knife
15242	honed stiletto
15243	deadly kris
15244	razor blade
15245	vorpal dagger
15246	demon blade
15247	bloodstrike dagger
15248	gleaming claymore
15249	polished zweihander
15250	glimmering flamberge
15251	headstriker sword
15252	tusker sword
15253	beheading blade
15254	dark espadon
15255	gallant flamberge
15256	massacre sword
15257	shin blade
15258	divine warblade
15259	hefty battlehammer
15260	stone hammer
15261	sequoia branch
15262	greater maul
15263	royal mallet
15264	backbreaker
15265	painbringer
15266	fierce mauler
15267	brutehammer
15268	twin bladed axe
15269	massive battle axe
15270	gigantic war axe
15271	colossal great axe
15272	razor axe
15273	death striker
15274	diviner long staff
15275	thaumaturgist staff
15276	magus long staff
15277	gray kodo
15278	solstice staff
15279	ivory wand
15280	wizard s hand
15281	glowstar rod
15282	dragon finger
15283	lunar wand
15284	long battle bow
15285	archer s longbow
15286	long redwood bow
15287	crusader bow
15288	blasthorn bow
15289	archstrike bow
15290	brown kodo
15291	harpy needler
15292	green kodo
15293	teal kodo
15294	siege bow
15295	quillfire bow
15296	hawkeye bow
15297	grizzly bracers
15298	grizzly buckler
15299	grizzly cape
15300	grizzly gloves
15301	grizzly slippers
15302	grizzly belt
15303	grizzly pants
15304	grizzly jerkin
15305	feral shoes
15306	feral bindings
15307	feral buckler
15308	feral cord
15309	feral cloak
15310	feral gloves
15311	feral harness
15312	feral leggings
15313	feral shoulder pads
15314	bundle of relics
15322	smoothbore gun
15323	percussion shotgun
15324	burnside rifle
15325	sharpshooter harquebus
15326	gleaming throwing axe
15327	wicked throwing dagger
15328	joseph s key
15329	wrangler s belt
15330	wrangler s boots
15331	wrangler s wristbands
15332	wrangler s buckler
15333	wrangler s cloak
15334	wrangler s gloves
15335	briarsteel shortsword
15336	wrangler s leggings
15337	wrangler s wraps
15338	wrangler s mantle
15339	pathfinder hat
15340	pathfinder cloak
15341	pathfinder footpads
15342	pathfinder guard
15343	pathfinder gloves
15344	pathfinder pants
15345	pathfinder shoulder pads
15346	pathfinder vest
15347	pathfinder belt
15348	pathfinder bracers
15349	headhunter s belt
15350	headhunter s slippers
15351	headhunter s bands
15352	headhunter s buckler
15353	headhunter s headdress
15354	headhunter s cloak
15355	headhunter s mitts
15356	headhunter s armor
15357	headhunter s spaulders
15358	headhunter s woolies
15359	trickster s vest
15360	trickster s bindings
15361	trickster s sash
15362	trickster s boots
15363	trickster s headdress
15364	trickster s cloak
15365	trickster s handwraps
15366	trickster s leggings
15367	trickster s protector
15368	trickster s pauldrons
15369	wolf rider s belt
15370	wolf rider s boots
15371	wolf rider s cloak
15372	wolf rider s gloves
15373	wolf rider s headgear
15374	wolf rider s leggings
15375	wolf rider s shoulder pads
15376	wolf rider s padded armor
15377	wolf rider s wristbands
15378	rageclaw belt
15379	rageclaw boots
15380	rageclaw bracers
15381	rageclaw chestguard
15382	rageclaw cloak
15383	rageclaw gloves
15384	rageclaw helm
15385	rageclaw leggings
15386	rageclaw shoulder pads
15387	jadefire bracelets
15388	jadefire belt
15389	jadefire sabatons
15390	jadefire chestguard
15391	jadefire cap
15392	jadefire cloak
15393	jadefire gloves
15394	jadefire pants
15395	jadefire epaulets
15396	curvewood dagger
15397	oakthrush staff
15398	sandcomber boots
15399	dryweed belt
15400	clamshell bracers
15401	welldrip gloves
15402	noosegrip gauntlets
15403	ridgeback bracers
15404	breakwater girdle
15405	shucking gloves
15406	crustacean boots
15407	cured rugged hide
15408	heavy scorpid scale
15409	refined deeprock salt
15410	scale of onyxia
15411	mark of fordring
15412	green dragonscale
15413	ornate adamantium breastplate
15414	red dragonscale
15415	blue dragonscale
15416	black dragonscale
15417	devilsaur leather
15418	shimmering platinum warhammer
15419	warbear leather
15420	ironfeather
15421	shroud of the exile
15422	frostsaber leather
15423	chimera leather
15424	axe of orgrimmar
15425	peerless bracers
15426	peerless boots
15427	peerless cloak
15428	peerless belt
15429	peerless gloves
15430	peerless headband
15431	peerless leggings
15432	peerless shoulders
15433	peerless armor
15434	supreme sash
15435	supreme shoes
15436	supreme bracers
15437	supreme cape
15438	supreme gloves
15439	supreme crown
15440	supreme leggings
15441	supreme shoulders
15442	supreme breastplate
15443	kris of orgrimmar
15444	staff of orgrimmar
15445	hammer of orgrimmar
15446	stormwind deputy kit
15447	living rot
15448	coagulated rot
15449	ghastly trousers
15450	dredgemire leggings
15451	gargoyle leggings
15452	featherbead bracers
15453	savannah bracers
15454	mortar and pestle
15455	dustfall robes
15456	lightstep leggings
15457	desert shoulders
15458	tundra boots
15459	grimtoll wristguards
15461	lightheel boots
15462	loamflake bracers
15463	palestrider gloves
15464	brute hammer
15465	stingshot wand
15466	clink shield
15467	inventor s league ring
15468	windsong drape
15469	windsong cinch
15470	plainsguard leggings
15471	brawnhide armor
15472	charger s belt
15473	charger s boots
15474	charger s bindings
15475	charger s cloak
15476	charger s handwraps
15477	charger s pants
15478	charger s shield
15479	charger s armor
15480	war torn girdle
15481	war torn greaves
15482	war torn bands
15483	war torn cape
15484	war torn handgrips
15485	war torn pants
15486	war torn shield
15487	war torn tunic
15488	bloodspattered surcoat
15489	bloodspattered sabatons
15490	bloodspattered cloak
15491	bloodspattered gloves
15492	bloodspattered sash
15493	bloodspattered loincloth
15494	bloodspattered shield
15495	bloodspattered wristbands
15496	bloodspattered shoulder pads
15497	outrunner s cord
15498	outrunner s slippers
15499	outrunner s cuffs
15500	outrunner s chestguard
15501	outrunner s cloak
15502	outrunner s gloves
15503	outrunner s legguards
15504	outrunner s shield
15505	outrunner s pauldrons
15506	grunt s anklewraps
15507	grunt s bracers
15508	grunt s cape
15509	grunt s handwraps
15510	grunt s belt
15511	grunt s legguards
15512	grunt s shield
15513	grunt s pauldrons
15514	grunt s chestpiece
15515	spiked chain belt
15516	spiked chain slippers
15517	spiked chain wristbands
15518	spiked chain breastplate
15519	spiked chain cloak
15520	spiked chain gauntlets
15521	spiked chain leggings
15522	spiked chain shield
15523	spiked chain shoulder pads
15524	sentry s surcoat
15525	sentry s slippers
15526	sentry s cape
15527	sentry s gloves
15528	sentry s sash
15529	sentry s leggings
15530	sentry s shield
15531	sentry s shoulderguards
15532	sentry s armsplints
15533	sentry s headdress
15534	wicked chain boots
15535	wicked chain bracers
15536	wicked chain chestpiece
15537	wicked chain cloak
15538	wicked chain gauntlets
15539	wicked chain waistband
15540	wicked chain helmet
15541	wicked chain legguards
15542	wicked chain shoulder pads
15543	wicked chain shield
15544	thick scale sabatons
15545	thick scale bracelets
15546	thick scale breastplate
15547	thick scale cloak
15548	thick scale gauntlets
15549	thick scale belt
15550	thick scale crown
15551	thick scale legguards
15552	thick scale shield
15553	thick scale shoulder pads
15554	pillager s girdle
15555	pillager s boots
15556	pillager s bracers
15557	pillager s chestguard
15558	pillager s crown
15559	pillager s cloak
15560	pillager s gloves
15561	pillager s leggings
15562	pillager s pauldrons
15563	pillager s shield
15564	rugged armor kit
15565	marauder s boots
15566	marauder s bracers
15567	marauder s tunic
15568	marauder s cloak
15569	marauder s crest
15570	marauder s gauntlets
15571	marauder s belt
15572	marauder s circlet
15573	marauder s leggings
15574	marauder s shoulder pads
15575	sparkleshell belt
15576	sparkleshell sabatons
15577	sparkleshell bracers
15578	sparkleshell breastplate
15579	sparkleshell cloak
15580	sparkleshell headwrap
15581	sparkleshell gauntlets
15582	sparkleshell legguards
15583	sparkleshell shoulder pads
15584	sparkleshell shield
15585	pardoc grips
15586	fast growing flower
15587	ringtail girdle
15588	bracesteel belt
15589	steadfast stompers
15590	steadfast bracelets
15591	steadfast breastplate
15592	steadfast buckler
15593	steadfast coronet
15594	steadfast cloak
15595	steadfast gloves
15596	steadfast legplates
15597	steadfast shoulders
15598	steadfast girdle
15599	ancient greaves
15600	ancient vambraces
15601	ancient chestpiece
15602	ancient crown
15603	ancient cloak
15604	ancient defender
15605	ancient gauntlets
15606	ancient belt
15607	ancient legguards
15608	ancient pauldrons
15609	bonelink armor
15610	bonelink bracers
15611	bonelink cape
15612	bonelink gauntlets
15613	bonelink belt
15614	bonelink sabatons
15615	bonelink helmet
15616	bonelink legplates
15617	bonelink epaulets
15618	bonelink wall shield
15619	gryphon mail belt
15620	gryphon mail bracelets
15621	gryphon mail buckler
15622	gryphon mail breastplate
15623	gryphon mail crown
15624	gryphon cloak
15625	gryphon mail gauntlets
15626	gryphon mail greaves
15627	gryphon mail legguards
15628	gryphon mail pauldrons
15629	formidable bracers
15630	formidable sabatons
15631	formidable chestpiece
15632	formidable cape
15633	formidable crest
15634	formidable circlet
15635	formidable gauntlets
15636	formidable belt
15637	formidable legguards
15638	formidable shoulder pads
15639	ironhide bracers
15640	ironhide breastplate
15641	ironhide belt
15642	ironhide greaves
15643	ironhide cloak
15644	ironhide gauntlets
15645	ironhide helmet
15646	ironhide legguards
15647	ironhide pauldrons
15648	ironhide shield
15649	merciless bracers
15650	merciless surcoat
15651	merciless crown
15652	merciless cloak
15653	merciless gauntlets
15654	merciless belt
15655	merciless legguards
15656	merciless epaulets
15657	merciless shield
15658	impenetrable sabatons
15659	impenetrable bindings
15660	impenetrable breastplate
15661	impenetrable cloak
15662	impenetrable gauntlets
15663	impenetrable belt
15664	impenetrable helmet
15665	impenetrable legguards
15666	impenetrable pauldrons
15667	impenetrable wall
15668	magnificent bracers
15669	magnificent breastplate
15670	magnificent helmet
15671	magnificent cloak
15672	magnificent gauntlets
15673	magnificent belt
15674	magnificent greaves
15675	magnificent guard
15676	magnificent leggings
15677	magnificent shoulders
15678	triumphant sabatons
15679	triumphant bracers
15680	triumphant chestpiece
15681	triumphant cloak
15682	triumphant gauntlets
15683	triumphant girdle
15684	triumphant skullcap
15685	triumphant legplates
15686	triumphant shoulder pads
15687	triumphant shield
15688	magic beans
15689	trader s ring
15690	kodobone necklace
15691	sidegunner shottie
15692	kodo brander
15693	grand shoulders
15694	merciless greaves
15695	studded ring shield
15696	ruined tome
15697	kodo rustler boots
15698	wrangling spaulders
15699	small brown wrapped package
15702	chemist s ring
15703	chemist s smock
15704	hunter s insignia medal
15705	tidecrest blade
15706	hunt tracker blade
15707	brantwood sash
15708	blight leather gloves
15709	gearforge girdle
15710	cenarion lunardust
15722	spraggle s canteen
15723	tea with sugar
15724	pattern heavy scorpid bracers
15725	pattern wicked leather gauntlets
15726	pattern green dragonscale breastplate
15727	pattern heavy scorpid vest
15728	pattern wicked leather bracers
15729	pattern chimeric gloves
15730	pattern red dragonscale breastplate
15731	pattern runic leather gauntlets
15732	pattern volcanic leggings
15733	pattern green dragonscale leggings
15734	pattern living shoulders
15735	pattern ironfeather shoulders
15736	smokey s special compound
15737	pattern chimeric boots
15738	pattern heavy scorpid gauntlets
15739	pattern runic leather bracers
15740	pattern frostsaber boots
15741	pattern stormshroud pants
15742	pattern warbear harness
15743	pattern heavy scorpid belt
15744	pattern wicked leather headband
15745	pattern runic leather belt
15746	pattern chimeric leggings
15747	pattern frostsaber leggings
15748	pattern heavy scorpid leggings
15749	pattern volcanic breastplate
15750	sceptre of light
15751	pattern blue dragonscale breastplate
15752	pattern living leggings
15753	pattern stormshroud armor
15754	pattern warbear woolies
15755	pattern chimeric vest
15756	pattern runic leather headband
15757	pattern wicked leather pants
15758	pattern devilsaur gauntlets
15759	pattern black dragonscale breastplate
15760	pattern ironfeather breastplate
15761	pattern frostsaber gloves
15762	pattern heavy scorpid helm
15763	pattern blue dragonscale shoulders
15764	pattern stormshroud shoulders
15765	pattern runic leather pants
15766	gem of the serpent
15767	hameya s key
15768	pattern wicked leather belt
15769	pattern onyxia scale cloak
15770	pattern black dragonscale shoulders
15771	pattern living breastplate
15772	pattern devilsaur leggings
15773	pattern wicked leather armor
15774	pattern heavy scorpid shoulders
15775	pattern volcanic shoulders
15776	pattern runic leather armor
15777	pattern runic leather shoulders
15778	mechanical yeti
15779	pattern frostsaber tunic
15781	pattern black dragonscale leggings
15782	beaststalker blade
15783	beasthunter dagger
15784	crystal breeze mantle
15785	zaeldarr s head
15786	fernpulse jerkin
15787	willow band hauberk
15788	everlook report
15789	deep river cloak
15790	studies in spirit speaking
15791	turquoise sash
15792	plow wood spaulders
15793	a chewed bone
15794	ripped ogre loincloth
15795	emerald mist gauntlets
15796	seaspray bracers
15797	shining armplates
15798	chipped ogre teeth
15799	heroic commendation medal
15800	intrepid shortsword
15801	valiant shortsword
15802	mooncloth boots
15803	book of the ancients
15804	cerise drape
15805	penelope s rose
15806	mirah s song
15807	light crossbow
15808	fine light crossbow
15809	heavy crossbow
15810	short spear
15811	heavy spear
15812	orchid amice
15813	gold link belt
15814	hameya s slayer
15815	hameya s cloak
15822	shadowskin spaulders
15823	bricksteel gauntlets
15824	astoria robes
15825	traphook jerkin
15826	curative animal salve
15827	jadescale breastplate
15842	empty dreadmist peak sampler
15843	filled dreadmist peak sampler
15844	empty cliffspring falls sampler
15845	filled cliffspring falls sampler
15846	salt shaker
15847	quel thalas registry
15848	crate of ghost magnets
15849	ghost o plasm
15850	patch of duskwing s fur
15851	lunar fungus
15852	kodo horn
15853	windreaper
15854	dancing sliver
15855	ring of protection
15856	archlight talisman
15857	magebane scion
15858	freewind gloves
15859	seapost girdle
15860	blinkstrike armguards
15861	swiftfoot treads
15862	blitzcleaver
15863	grave scepter
15864	condor bracers
15865	anchorhold buckler
15866	veildust medicine bag
15867	prismcharm
15868	the grand crusader s command
15869	silver skeleton key
15870	golden skeleton key
15871	truesilver skeleton key
15872	arcanite skeleton key
15873	ragged john s neverending cup
15874	soft shelled clam
15875	rotten apple
15876	nathanos chest
15877	shrine bauble
15878	rackmore s silver key
15879	overlord ror s claw
15880	head of ramstein the gorger
15881	rackmore s golden key
15882	half pendant of aquatic endurance
15883	half pendant of aquatic agility
15884	augustus receipt book
15885	pendant of the sea lion
15886	timolain s phylactery
15887	heroic guard
15890	vanguard shield
15891	hulking shield
15892	slayer s shield
15893	prospector s buckler
15894	bristlebark buckler
15895	burnt buckler
15902	a crazy grab bag
15903	right handed claw
15904	right handed blades
15905	right handed brass knuckles
15906	left handed brass knuckles
15907	left handed claw
15908	taming rod
15909	left handed blades
15911	taming rod
15912	buccaneer s orb
15913	taming rod
15914	taming rod
15915	taming rod
15916	taming rod
15917	taming rod
15918	conjurer s sphere
15919	taming rod
15920	taming rod
15921	taming rod
15922	taming rod
15923	taming rod
15924	soft shelled clam meat
15925	journeyman s stave
15926	spellbinder orb
15927	bright sphere
15928	silver thread rod
15929	nightsky orb
15930	imperial red scepter
15931	arcane star
15932	disciple s stein
15933	simple branch
15934	sage s stave
15935	durable rod
15936	duskwoven branch
15937	hibernal sphere
15938	mystical orb
15939	councillor s scepter
15940	elegant scepter
15941	high councillor s scepter
15942	master s rod
15943	imbued shield
15944	ancestral orb
15945	runic stave
15946	mystic s sphere
15947	sanguine star
15962	satyr s rod
15963	stonecloth branch
15964	silksand star
15965	windchaser orb
15966	venomshroud orb
15967	highborne star
15968	elunarian sphere
15969	beaded orb
15970	native branch
15971	aboriginal rod
15972	ritual stein
15973	watcher s star
15974	pagan rod
15975	raincaller scepter
15976	thistlefur branch
15977	vital orb
15978	geomancer s rod
15979	embersilk stave
15980	darkmist orb
15981	lunar sphere
15982	bloodwoven rod
15983	gaea s scepter
15984	opulent scepter
15985	arachnidian branch
15986	bonecaster s star
15987	astral orb
15988	resplendent orb
15989	eternal rod
15990	enduring shield
15991	warleader s shield
15992	dense blasting powder
15993	thorium grenade
15994	thorium widget
15995	thorium rifle
15996	lifelike mechanical toad
15997	thorium shells
15998	lewis note
15999	spellpower goggles xtreme plus
16000	thorium tube
16001	si 7 insignia fredo
16002	si 7 insignia turyen
16003	si 7 insignia rutger
16004	dark iron rifle
16005	dark iron bomb
16006	delicate arcanite converter
16007	flawless arcanite rifle
16008	master engineer s goggles
16009	voice amplification modulator
16022	arcanite dragonling
16023	masterwork target dummy
16039	ta kierthan songblade
16040	arcane bomb
16041	schematic thorium grenade
16042	schematic thorium widget
16043	schematic thorium rifle
16044	schematic lifelike mechanical toad
16045	schematic spellpower goggles xtreme plus
16046	schematic masterwork target dummy
16047	schematic thorium tube
16048	schematic dark iron rifle
16049	schematic dark iron bomb
16050	schematic delicate arcanite converter
16051	schematic thorium shells
16052	schematic voice amplification modulator
16053	schematic master engineer s goggles
16054	schematic arcanite dragonling
16055	schematic arcane bomb
16056	schematic flawless arcanite rifle
16057	explorer s knapsack
16058	fordring s seal
16059	common brown shirt
16060	common white shirt
16072	expert cookbook
16073	artisan cookbook
16082	artisan fishing the way of the lure
16083	expert fishing the bass and you
16084	expert first aid under wraps
16085	artisan first aid heal thyself
16110	recipe monster omelet
16111	recipe spiced chili crab
16112	manual heavy silk bandage
16113	manual mageweave bandage
16114	foreman s blackjack
16115	osric s crate
16166	bean soup
16167	versicolor treat
16168	heaven peach
16169	wild ricecake
16170	steamed mandu
16171	shinsollo
16189	maggran s reserve letter
16190	bloodfury ripper s remains
16191	ornate mirror
16192	besseleth s fang
16202	lesser eternal essence
16203	greater eternal essence
16204	illusion dust
16205	gaea seed
16206	arcanite rod
16207	runed arcanite rod
16208	enchanted gaea seeds
16209	podrig s order
16210	gordon s crate
16214	formula enchant bracer greater intellect
16215	formula enchant boots greater stamina
16216	formula enchant cloak greater resistance
16217	formula enchant shield greater stamina
16218	formula enchant bracer superior spirit
16219	formula enchant gloves greater agility
16220	formula enchant boots spirit
16221	formula enchant chest major health
16222	formula enchant shield superior spirit
16223	formula enchant weapon icy chill
16224	formula enchant cloak superior defense
16242	formula enchant chest major mana
16243	formula runed arcanite rod
16244	formula enchant gloves greater strength
16245	formula enchant boots greater agility
16246	formula enchant bracer superior strength
16247	formula enchant 2h weapon superior impact
16248	formula enchant weapon unholy
16249	formula enchant 2h weapon major intellect
16250	formula enchant weapon superior striking
16251	formula enchant bracer superior stamina
16252	formula enchant weapon crusader
16253	formula enchant chest greater stats
16254	formula enchant weapon lifestealing
16255	formula enchant 2h weapon major spirit
16262	nessa s collection
16263	laird s response
16282	bundle of hides
16283	ahanu s leather goods
16302	grimoire of firebolt rank 2
16303	ursangous s paw
16304	shadumbra s head
16305	sharptalon s claw
16306	zargh s meats
16307	gryshka s letter
16308	northridge crowbar
16309	drakefire amulet
16310	brock s list
16311	honorary picks
16312	incendrites
16313	felix s chest
16314	felix s bucket of bolts
16316	grimoire of firebolt rank 3
16317	grimoire of firebolt rank 4
16318	grimoire of firebolt rank 5
16319	grimoire of firebolt rank 6
16320	grimoire of firebolt rank 7
16321	grimoire of blood pact rank 1
16322	grimoire of blood pact rank 2
16323	grimoire of blood pact rank 3
16324	grimoire of blood pact rank 4
16325	grimoire of blood pact rank 5
16326	grimoire of fire shield rank 1
16327	grimoire of fire shield rank 2
16328	grimoire of fire shield rank 3
16329	grimoire of fire shield rank 4
16330	grimoire of fire shield rank 5
16331	grimoire of phase shift
16332	thazz ril s pick
16333	samuel s remains
16335	senior sergeant s insignia
16338	knight lieutenant s steed
16339	commander s steed
16341	sergeant s cloak
16342	sergeant s cape
16343	blood guard s mount
16344	zzunusedlieutenant general s mount
16345	high warlord s blade
16346	grimoire of torment rank 2
16347	grimoire of torment rank 3
16348	grimoire of torment rank 4
16349	grimoire of torment rank 5
16350	grimoire of torment rank 6
16351	grimoire of sacrifice rank 1
16352	grimoire of sacrifice rank 2
16353	grimoire of sacrifice rank 3
16354	grimoire of sacrifice rank 4
16355	grimoire of sacrifice rank 5
16356	grimoire of sacrifice rank 6
16357	grimoire of consume shadows rank 1
16358	grimoire of consume shadows rank 2
16359	grimoire of consume shadows rank 3
16360	grimoire of consume shadows rank 4
16361	grimoire of consume shadows rank 5
16362	grimoire of consume shadows rank 6
16363	grimoire of suffering rank 1
16364	grimoire of suffering rank 2
16365	grimoire of suffering rank 3
16366	grimoire of suffering rank 4
16368	grimoire of lash of pain rank 2
16369	knight lieutenant s silk boots
16371	grimoire of lash of pain rank 3
16372	grimoire of lash of pain rank 4
16373	grimoire of lash of pain rank 5
16374	grimoire of lash of pain rank 6
16375	grimoire of soothing kiss rank 1
16376	grimoire of soothing kiss rank 2
16377	grimoire of soothing kiss rank 3
16378	grimoire of soothing kiss rank 4
16379	grimoire of seduction
16380	grimoire of lesser invisibility
16381	grimoire of devour magic rank 2
16382	grimoire of devour magic rank 3
16383	grimoire of devour magic rank 4
16384	grimoire of tainted blood rank 1
16385	grimoire of tainted blood rank 2
16386	grimoire of tainted blood rank 3
16387	grimoire of tainted blood rank 4
16388	grimoire of spell lock rank 1
16389	grimoire of spell lock rank 2
16390	grimoire of paranoia
16391	knight lieutenant s silk gloves
16392	knight lieutenant s leather boots
16393	knight lieutenant s dragonhide footwraps
16396	knight lieutenant s leather gauntlets
16397	knight lieutenant s dragonhide gloves
16401	knight lieutenant s chain boots
16403	knight lieutenant s chain gauntlets
16405	knight lieutenant s plate boots
16406	knight lieutenant s plate gauntlets
16408	befouled water globe
16409	knight lieutenant s lamellar sabatons
16410	knight lieutenant s lamellar gauntlets
16413	knight captain s silk raiment
16414	knight captain s silk leggings
16415	lieutenant commander s silk spaulders
16416	lieutenant commander s crown
16417	knight captain s leather armor
16418	lieutenant commander s leather veil
16419	knight captain s leather legguards
16420	lieutenant commander s leather spaulders
16421	knight captain s dragonhide tunic
16422	knight captain s dragonhide leggings
16423	lieutenant commander s dragonhide epaulets
16424	lieutenant commander s dragonhide shroud
16425	knight captain s chain hauberk
16426	knight captain s chain leggings
16427	lieutenant commander s chain pauldrons
16428	lieutenant commander s chain helmet
16429	lieutenant commander s plate helm
16430	knight captain s plate chestguard
16431	knight captain s plate leggings
16432	lieutenant commander s plate pauldrons
16433	knight captain s lamellar breastplate
16434	lieutenant commander s lamellar headguard
16435	knight captain s lamellar leggings
16436	lieutenant commander s lamellar shoulders
16437	marshal s silk footwraps
16440	marshal s silk gloves
16441	field marshal s coronet
16442	marshal s silk leggings
16443	field marshal s silk vestments
16444	field marshal s silk spaulders
16446	marshal s leather footguards
16448	marshal s dragonhide gauntlets
16449	field marshal s dragonhide spaulders
16450	marshal s dragonhide legguards
16451	field marshal s dragonhide helmet
16452	field marshal s dragonhide breastplate
16453	field marshal s leather chestpiece
16454	marshal s leather handgrips
16455	field marshal s leather mask
16456	marshal s leather leggings
16457	field marshal s leather epaulets
16459	marshal s dragonhide boots
16462	marshal s chain boots
16463	marshal s chain grips
16465	field marshal s chain helm
16466	field marshal s chain breastplate
16467	marshal s chain legguards
16468	field marshal s chain spaulders
16471	marshal s lamellar gloves
16472	marshal s lamellar boots
16473	field marshal s lamellar chestplate
16474	field marshal s lamellar faceguard
16475	marshal s lamellar legplates
16476	field marshal s lamellar pauldrons
16477	field marshal s plate armor
16478	field marshal s plate helm
16479	marshal s plate legguards
16480	field marshal s plate shoulderguards
16483	marshal s plate boots
16484	marshal s plate gauntlets
16485	blood guard s silk footwraps
16486	first sergeant s silk cuffs
16487	blood guard s silk gloves
16489	champion s silk hood
16490	legionnaire s silk pants
16491	legionnaire s silk robes
16492	champion s silk shoulderpads
16494	blood guard s dragonhide boots
16496	blood guard s dragonhide gauntlets
16497	first sergeant s leather armguards
16498	blood guard s leather treads
16499	blood guard s leather vices
16501	champion s dragonhide spaulders
16502	legionnaire s dragonhide trousers
16503	champion s dragonhide helm
16504	legionnaire s dragonhide breastplate
16505	legionnaire s leather hauberk
16506	champion s leather headguard
16507	champion s leather mantle
16508	legionnaire s leather leggings
16509	blood guard s plate boots
16510	blood guard s plate gloves
16513	legionnaire s plate armor
16514	champion s plate headguard
16515	legionnaire s plate legguards
16516	champion s plate pauldrons
16518	blood guard s mail walkers
16519	blood guard s mail grips
16521	champion s mail helm
16522	legionnaire s mail chestpiece
16523	legionnaire s mail leggings
16524	champion s mail shoulders
16525	legionnaire s chain breastplate
16526	champion s chain headguard
16527	legionnaire s chain leggings
16528	champion s chain pauldrons
16530	blood guard s chain gauntlets
16531	blood guard s chain boots
16532	first sergeant s mail wristguards
16533	warlord s silk cowl
16534	general s silk trousers
16535	warlord s silk raiment
16536	warlord s silk amice
16539	general s silk boots
16540	general s silk handguards
16541	warlord s plate armor
16542	warlord s plate headpiece
16543	general s plate leggings
16544	warlord s plate shoulders
16545	general s plate boots
16548	general s plate gauntlets
16549	warlord s dragonhide hauberk
16550	warlord s dragonhide helmet
16551	warlord s dragonhide epaulets
16552	general s dragonhide leggings
16554	general s dragonhide boots
16555	general s dragonhide gloves
16558	general s leather treads
16560	general s leather mitts
16561	warlord s leather helm
16562	warlord s leather spaulders
16563	warlord s leather breastplate
16564	general s leather legguards
16565	warlord s chain chestpiece
16566	warlord s chain helmet
16567	general s chain legguards
16568	warlord s chain shoulders
16569	general s chain boots
16571	general s chain gloves
16573	general s mail boots
16574	general s mail gauntlets
16577	warlord s mail armor
16578	warlord s mail helm
16579	general s mail leggings
16580	warlord s mail spaulders
16581	resonite crystal
16583	demonic figurine
16602	troll charm
16603	enchanted resonite crystal
16604	moon robes of elune
16605	friar s robes of the light
16606	juju hex robes
16607	acolyte s sacrificial robes
16608	aquarius belt
16622	thornflinger
16623	opaline medallion
16642	shredder operating manual chapter 1
16643	shredder operating manual chapter 2
16644	shredder operating manual chapter 3
16645	shredder operating manual page 1
16646	shredder operating manual page 2
16647	shredder operating manual page 3
16648	shredder operating manual page 4
16649	shredder operating manual page 5
16650	shredder operating manual page 6
16651	shredder operating manual page 7
16652	shredder operating manual page 8
16653	shredder operating manual page 9
16654	shredder operating manual page 10
16655	shredder operating manual page 11
16656	shredder operating manual page 12
16658	wildhunter cloak
16659	deftkin belt
16660	driftmire shield
16661	soft willow cape
16662	fragment of the dragon s eye
16663	blood of the black dragon champion
16665	tome of tranquilizing shot
16666	vest of elements
16667	coif of elements
16668	kilt of elements
16669	pauldrons of elements
16670	boots of elements
16671	bindings of elements
16672	gauntlets of elements
16673	cord of elements
16674	beaststalker s tunic
16675	beaststalker s boots
16676	beaststalker s gloves
16677	beaststalker s cap
16678	beaststalker s pants
16679	beaststalker s mantle
16680	beaststalker s belt
16681	beaststalker s bindings
16682	magister s boots
16683	magister s bindings
16684	magister s gloves
16685	magister s belt
16686	magister s crown
16687	magister s leggings
16688	magister s robes
16689	magister s mantle
16690	devout robe
16691	devout sandals
16692	devout gloves
16693	devout crown
16694	devout skirt
16695	devout mantle
16696	devout belt
16697	devout bracers
16698	dreadmist mask
16699	dreadmist leggings
16700	dreadmist robe
16701	dreadmist mantle
16702	dreadmist belt
16703	dreadmist bracers
16704	dreadmist sandals
16705	dreadmist wraps
16706	wildheart vest
16707	shadowcraft cap
16708	shadowcraft spaulders
16709	shadowcraft pants
16710	shadowcraft bracers
16711	shadowcraft boots
16712	shadowcraft gloves
16713	shadowcraft belt
16714	wildheart bracers
16715	wildheart boots
16716	wildheart belt
16717	wildheart gloves
16718	wildheart spaulders
16719	wildheart kilt
16720	wildheart cowl
16721	shadowcraft tunic
16722	lightforge bracers
16723	lightforge belt
16724	lightforge gauntlets
16725	lightforge boots
16726	lightforge breastplate
16727	lightforge helm
16728	lightforge legplates
16729	lightforge spaulders
16730	breastplate of valor
16731	helm of valor
16732	legplates of valor
16733	spaulders of valor
16734	boots of valor
16735	bracers of valor
16736	belt of valor
16737	gauntlets of valor
16738	witherseed gloves
16739	rugwood mantle
16740	shredder operating gloves
16741	oilrag handwraps
16742	warsong saw blades
16743	logging rope
16744	warsong oil
16745	warsong axe shipment
16746	warsong report
16747	broken lock
16748	padded lining
16762	fathom core
16763	warsong runner update
16764	warsong scout update
16765	warsong outrider update
16766	undermine clam chowder
16767	recipe undermine clam chowder
16768	furbolg medicine pouch
16769	furbolg medicine totem
16782	strange water globe
16783	bundle of reports
16784	sapphire of aku mai
16785	rexxar s testament
16786	black dragonspawn eye
16787	amulet of draconic subversion
16788	captain rackmore s wheel
16789	captain rackmore s tiller
16790	damp note
16791	silkstream cuffs
16793	arcmetal shoulders
16794	gripsteel wristguards
16795	arcanist crown
16796	arcanist leggings
16797	arcanist mantle
16798	arcanist robes
16799	arcanist bindings
16800	arcanist boots
16801	arcanist gloves
16802	arcanist belt
16803	felheart slippers
16804	felheart bracers
16805	felheart gloves
16806	felheart belt
16807	felheart shoulder pads
16808	felheart horns
16809	felheart robes
16810	felheart pants
16811	boots of prophecy
16812	gloves of prophecy
16813	circlet of prophecy
16814	pants of prophecy
16815	robes of prophecy
16816	mantle of prophecy
16817	girdle of prophecy
16818	netherwind belt
16819	vambraces of prophecy
16820	nightslayer chestpiece
16821	nightslayer cover
16822	nightslayer pants
16823	nightslayer shoulder pads
16824	nightslayer boots
16825	nightslayer bracelets
16826	nightslayer gloves
16827	nightslayer belt
16828	cenarion belt
16829	cenarion boots
16830	cenarion bracers
16831	cenarion gloves
16832	bloodfang spaulders
16833	cenarion vestments
16834	cenarion helm
16835	cenarion leggings
16836	cenarion spaulders
16837	earthfury boots
16838	earthfury belt
16839	earthfury gauntlets
16840	earthfury bracers
16841	earthfury vestments
16842	earthfury helmet
16843	earthfury legguards
16844	earthfury epaulets
16845	giantstalker s breastplate
16846	giantstalker s helmet
16847	giantstalker s leggings
16848	giantstalker s epaulets
16849	giantstalker s boots
16850	giantstalker s bracers
16851	giantstalker s belt
16852	giantstalker s gloves
16853	lawbringer chestguard
16854	lawbringer helm
16855	lawbringer legplates
16856	lawbringer spaulders
16857	lawbringer bracers
16858	lawbringer belt
16859	lawbringer boots
16860	lawbringer gauntlets
16861	bracers of might
16862	sabatons of might
16863	gauntlets of might
16864	belt of might
16865	breastplate of might
16866	helm of might
16867	legplates of might
16868	pauldrons of might
16869	the skull of scryer
16870	the skull of somnus
16871	the skull of chronalis
16872	the skull of axtroz
16873	braidfur gloves
16882	battered junkbox
16883	worn junkbox
16884	sturdy junkbox
16885	heavy junkbox
16886	outlaw sabre
16887	witch s finger
16888	dull drakefire amulet
16889	polished walking staff
16890	slatemetal cutlass
16891	claystone shortsword
16892	lesser soulstone
16893	soulstone
16894	clear crystal rod
16895	greater soulstone
16896	major soulstone
16897	stormrage chestguard
16898	stormrage boots
16899	stormrage handguards
16900	stormrage cover
16901	stormrage legguards
16902	stormrage pauldrons
16903	stormrage belt
16904	stormrage bracers
16905	bloodfang chestpiece
16906	bloodfang boots
16907	bloodfang gloves
16908	bloodfang hood
16909	bloodfang pants
16910	bloodfang belt
16911	bloodfang bracers
16912	netherwind boots
16913	netherwind gloves
16914	netherwind crown
16915	netherwind pants
16916	netherwind robes
16917	netherwind mantle
16918	netherwind bindings
16919	boots of transcendence
16920	handguards of transcendence
16921	halo of transcendence
16922	leggings of transcendence
16923	robes of transcendence
16924	pauldrons of transcendence
16925	belt of transcendence
16926	bindings of transcendence
16927	nemesis boots
16928	nemesis gloves
16929	nemesis skullcap
16930	nemesis leggings
16931	nemesis robes
16932	nemesis spaulders
16933	nemesis belt
16934	nemesis bracers
16935	dragonstalker s bracers
16936	dragonstalker s belt
16937	dragonstalker s spaulders
16938	dragonstalker s legguards
16939	dragonstalker s helm
16940	dragonstalker s gauntlets
16941	dragonstalker s greaves
16942	dragonstalker s breastplate
16943	bracers of ten storms
16944	belt of ten storms
16945	epaulets of ten storms
16946	legplates of ten storms
16947	helmet of ten storms
16948	gauntlets of ten storms
16949	greaves of ten storms
16950	breastplate of ten storms
16951	judgement bindings
16952	judgement belt
16953	judgement spaulders
16954	judgement legplates
16955	judgement crown
16956	judgement gauntlets
16957	judgement sabatons
16958	judgement breastplate
16959	bracelets of wrath
16960	waistband of wrath
16961	pauldrons of wrath
16962	legplates of wrath
16963	helm of wrath
16964	gauntlets of wrath
16965	sabatons of wrath
16966	breastplate of wrath
16967	feralas ahi
16968	sar theris striker
16969	savage coast blue sailfin
16970	misty reed mahi mahi
16971	clamlette surprise
16972	karang s banner
16973	vial of dire water
16974	empty water vial
16975	warsong sash
16976	murgut s totem
16977	warsong boots
16978	warsong gauntlets
16979	flarecore gloves
16980	flarecore mantle
16981	owlbeard bracers
16982	corehound boots
16983	molten helm
16984	black dragonscale boots
16985	windseeker boots
16986	sandspire gloves
16987	screecher belt
16988	fiery chain shoulders
16989	fiery chain girdle
16990	spritekin cloak
16991	triage bandage
16992	smokey s explosive launcher
16993	smokey s fireshooter
16994	duskwing gloves
16995	duskwing mantle
16996	gorewood bow
16997	stormrager
16998	sacred protector
16999	royal seal of alexis
17000	band of the wraith
17001	elemental circle
17002	ichor spitter
17003	skullstone hammer
17004	sarah s guide
17005	boorguard tunic
17006	cobalt legguards
17007	stonerender gauntlets
17008	small scroll
17009	ambassador malcin s head
17010	fiery core
17011	lava core
17012	core leather
17013	dark iron leggings
17014	dark iron bracers
17015	dark iron reaver
17016	dark iron destroyer
17017	pattern flarecore mantle
17018	pattern flarecore gloves
17019	arcane dust
17020	arcane powder
17021	wild berries
17022	pattern corehound boots
17023	pattern molten helm
17024	wild root
17025	pattern black dragonscale boots
17026	wild thornroot
17027	scented candle
17028	holy candle
17029	sacred candle
17030	ankh
17031	rune of teleportation
17032	rune of portals
17033	symbol of divinity
17034	maple seed
17035	stranglethorn seed
17036	ashwood seed
17037	hornbeam seed
17038	ironwood seed
17039	skullbreaker
17042	nail spitter
17043	zealot s robe
17044	will of the martyr
17045	blood of the martyr
17046	gutterblade
17047	luminescent amice
17048	rumsey rum
17049	plans fiery chain girdle
17050	chan s imperial robes
17051	plans dark iron bracers
17052	plans dark iron leggings
17053	plans fiery chain shoulders
17054	joonho s mercy
17055	changuk smasher
17056	light feather
17057	shiny fish scales
17058	fish oil
17059	plans dark iron reaver
17060	plans dark iron destroyer
17061	juno s shadow
17062	recipe mithril head trout
17063	band of accuria
17064	shard of the scale
17065	medallion of steadfast might
17066	drillborer disk
17067	ancient cornerstone grimoire
17068	deathbringer
17069	striker s mark
17070	fang of the mystics
17071	gutgore ripper
17072	blastershot launcher
17073	earthshaker
17074	shadowstrike
17075	vis kag the bloodletter
17076	bonereaver s edge
17077	crimson shocker
17078	sapphiron drape
17082	shard of the flame
17102	cloak of the shrouded mists
17103	azuresong mageblade
17104	spinal reaper
17105	aurastone hammer
17106	malistar s defender
17107	dragon s blood cape
17109	choker of enlightenment
17110	seal of the archmagus
17111	blazefury medallion
17112	empyrean demolisher
17113	amberseal keeper
17114	araj s phylactery shard
17115	squirrel token
17116	squirrel token
17117	rat catcher s flute
17118	carton of mystery meat
17119	deeprun rat kabob
17124	syndicate emblem
17125	seal of ravenholdt
17126	elegant letter
17182	sulfuras hand of ragnaros
17183	dented buckler
17184	small shield
17185	round buckler
17186	small targe
17187	banded buckler
17188	ringed buckler
17189	metal buckler
17190	ornate buckler
17191	scepter of celebras
17192	reinforced targe
17193	sulfuron hammer
17194	holiday spices
17195	fake mistletoe
17196	holiday spirits
17197	gingerbread cookie
17198	egg nog
17199	bad egg nog
17200	recipe gingerbread cookie
17201	recipe egg nog
17202	snowball
17203	sulfuron ingot
17204	eye of sulfuras
17222	spider sausage
17223	thunderstrike
17224	scrying scope
17242	key to salem s chest
17262	james key
17302	blue ribboned holiday gift
17303	blue ribboned wrapping paper
17304	green ribboned wrapping paper
17305	green ribboned holiday gift
17306	stormpike soldier s blood
17307	purple ribboned wrapping paper
17308	purple ribboned holiday gift
17309	discordant bracers
17310	aspect of neptulon
17322	eye of the emberseer
17323	mulverick s beacon
17324	guse s beacon
17325	jeztor s beacon
17326	stormpike soldier s flesh
17327	stormpike lieutenant s flesh
17328	stormpike commander s flesh
17329	hand of lucifron
17330	hand of sulfuron
17331	hand of gehennas
17332	hand of shazzrah
17333	aqual quintessence
17344	candy cane
17345	silithid goo
17346	encrusted silithid object
17347	syndicate man tracker murp
17348	major healing draught
17349	superior healing draught
17351	major mana draught
17352	superior mana draught
17353	stormpike assault orders
17354	master ryson s all seeing eye
17355	rabine s letter
17362	ryson s beacon
17363	ryson s beacon
17364	scrying scope
17384	zinfizzlex s portable shredder unit
17402	greatfather s winter ale
17403	steamwheedle fizzy spirits
17404	blended bean brew
17405	green garden tea
17406	holiday cheesewheel
17407	graccu s homemade meat pie
17408	spicy beefstick
17409	encrusted crystal fragment
17410	zinfizzlex s portable shredder unit
17411	steamsaw
17413	codex prayer of fortitude
17414	codex prayer of fortitude ii
17422	armor scraps
17423	storm crystal
17442	frostwolf assault orders
17502	frostwolf soldier s medal
17503	frostwolf lieutenant s medal
17504	frostwolf commander s medal
17505	ichman s beacon
17506	vipore s beacon
17507	slidore s beacon
17508	forcestone buckler
17522	irondeep supplies
17523	smokey s drape
17542	coldtooth supplies
17562	knight lieutenant s dreadweave boots
17564	knight lieutenant s dreadweave gloves
17566	lieutenant commander s headguard
17567	knight captain s dreadweave leggings
17568	knight captain s dreadweave robe
17569	lieutenant commander s dreadweave mantle
17570	champion s dreadweave hood
17571	legionnaire s dreadweave leggings
17572	legionnaire s dreadweave robe
17573	champion s dreadweave shoulders
17576	blood guard s dreadweave boots
17577	blood guard s dreadweave gloves
17578	field marshal s coronal
17579	marshal s dreadweave leggings
17580	field marshal s dreadweave shoulders
17581	field marshal s dreadweave robe
17583	marshal s dreadweave boots
17584	marshal s dreadweave gloves
17586	general s dreadweave boots
17588	general s dreadweave gloves
17590	warlord s dreadweave mantle
17591	warlord s dreadweave hood
17592	warlord s dreadweave robe
17593	general s dreadweave pants
17594	knight lieutenant s satin boots
17596	knight lieutenant s satin gloves
17598	lieutenant commander s diadem
17599	knight captain s satin leggings
17600	knight captain s satin robes
17601	lieutenant commander s satin amice
17602	field marshal s headdress
17603	marshal s satin pants
17604	field marshal s satin mantle
17605	field marshal s satin vestments
17607	marshal s satin sandals
17608	marshal s satin gloves
17610	champion s satin cowl
17611	legionnaire s satin trousers
17612	legionnaire s satin vestments
17613	champion s satin shoulderpads
17616	blood guard s satin boots
17617	blood guard s satin gloves
17618	general s satin boots
17620	general s satin gloves
17622	warlord s satin mantle
17623	warlord s satin cowl
17624	warlord s satin robes
17625	general s satin leggings
17626	frostwolf muzzle
17642	alterac ram hide
17643	frostwolf hide
17662	stolen treats
17682	book gift of the wild
17683	book gift of the wild ii
17684	theradric crystal carving
17685	smokywood pastures sampler
17686	master hunter s bow
17687	master hunter s rifle
17688	jungle boots
17689	stormpike training collar
17690	frostwolf insignia rank 1
17691	stormpike insignia rank 1
17692	horn ring
17693	coated cerulean vial
17694	band of the fist
17695	chestnut mantle
17696	filled cerulean vial
17702	celebrian rod
17703	celebrian diamond
17704	edge of winter
17705	thrash blade
17706	plans edge of winter
17707	gemshard heart
17708	elixir of frost power
17709	recipe elixir of frost power
17710	charstone dirk
17711	elemental rockridge leggings
17712	winter veil disguise kit
17713	blackstone ring
17714	bracers of the stone princess
17715	eye of theradras
17716	snowmaster 9000
17717	megashot rifle
17718	gizlock s hypertech buckler
17719	inventor s focal sword
17720	schematic snowmaster 9000
17721	gloves of the greatfather
17722	pattern gloves of the greatfather
17723	green holiday shirt
17724	pattern green holiday shirt
17725	formula enchant weapon winter s might
17726	smokywood pastures special gift
17727	smokywood pastures gift pack
17728	albino crocscale boots
17730	gatorbite axe
17731	scroll of celebras
17732	rotgrip mantle
17733	fist of stone
17734	helm of the mountain
17735	the feast of winter veil
17736	rockgrip gauntlets
17737	cloud stone
17738	claw of celebras
17739	grovekeeper s drape
17740	soothsayer s headdress
17741	nature s embrace
17742	fungus shroud armor
17743	resurgence rod
17744	heart of noxxion
17745	noxious shooter
17746	noxxion s shackles
17747	razorlash root
17748	vinerot sandals
17749	phytoskin spaulders
17750	chloromesh girdle
17751	brusslehide leggings
17752	satyr s lash
17753	verdant keeper s aim
17754	infernal trickster leggings
17755	satyrmane sash
17756	shadowshard fragment
17757	amulet of spirits
17758	amulet of union
17759	mark of resolution
17760	seed of life
17761	gem of the first khan
17762	gem of the second kahn
17763	gem of the third kahn
17764	gem of the fourth kahn
17765	gem of the fifth kahn
17766	princess theradras scepter
17767	bloomsprout headpiece
17768	woodseed hoop
17770	branchclaw gauntlets
17771	elementium bar
17772	zealous shadowshard pendant
17773	prodigious shadowshard pendant
17774	mark of the chosen
17775	acumen robes
17776	sprightring helm
17777	relentless chain
17778	sagebrush girdle
17779	hulkstone pauldrons
17780	blade of eternal darkness
17781	the pariah s instructions
17782	talisman of binding shard
17822	frostwolf maps
17823	stormpike battle plans
17849	stormpike banner
17850	frostwolf banner
17900	stormpike insignia rank 2
17901	stormpike insignia rank 3
17902	stormpike insignia rank 4
17903	stormpike insignia rank 5
17904	stormpike insignia rank 6
17905	frostwolf insignia rank 2
17906	frostwolf insignia rank 3
17907	frostwolf insignia rank 4
17908	frostwolf insignia rank 5
17909	frostwolf insignia rank 6
17922	lionfur armor
17943	fist of stone
17962	blue sack of gems
17963	green sack of gems
17964	gray sack of gems
17965	yellow sack of gems
17966	onyxia hide backpack
17968	charged scale of onyxia
17969	red sack of gems
17982	ragnaros core
18000	tough jerky
18001	tough hunk of bread
18005	refreshing spring water
18022	royal seal of alexis
18042	thorium headed arrow
18043	coal miner boots
18044	hurley s tankard
18045	tender wolf steak
18046	recipe tender wolf steak
18047	flame walkers
18048	mastersmith s hammer
18082	zum rah s vexing cane
18083	jumanza grips
18102	dragonrider boots
18103	band of rumination
18104	feralsurge girdle
18142	severed night elf head
18143	tuft of gnome hair
18144	human bone chip
18145	tauren hoof
18146	darkspear troll mojo
18147	forsaken heart
18148	skull of korrak
18149	rune of recall
18150	rune of recall
18151	filled amethyst phial
18152	amethyst phial
18153	red moro gai gem
18154	blizzard stationery
18155	blue moro gai gem
18156	green moro gai gem
18157	black moro gai gem
18158	gold moro gai gem
18159	white moro gai gem
18160	recipe thistle tea
18168	force reactive disk
18169	flame mantle of the dawn
18170	frost mantle of the dawn
18171	arcane mantle of the dawn
18172	nature mantle of the dawn
18173	shadow mantle of the dawn
18182	chromatic mantle of the dawn
18202	eskhandar s left claw
18203	eskhandar s right claw
18204	eskhandar s pelt
18205	eskhandar s collar
18206	dwarf spine
18207	orc tooth
18208	drape of benediction
18209	energized sparkplug
18222	thorny vine
18223	serrated petal
18224	lasher root
18225	worn running shoes
18226	a sealed pact
18227	nubless pacifier
18228	autographed picture of foror & tigule
18229	nat pagle s guide to extreme anglin
18230	broken i w i n button
18231	sleeveless t shirt
18232	field repair bot 74a
18233	tear stained handkerchief
18234	document from boomstick imports
18235	schematic field repair bot 74a
18236	gordok chew toy
18237	mastiff jawbone
18238	shadowskin gloves
18239	pattern shadowskin gloves
18240	ogre tannin
18241	black war steed bridle
18242	reins of the black war tiger
18243	black battlestrider
18244	black war ram
18245	horn of the black war wolf
18246	whistle of the black war raptor
18247	black war kodo
18248	red skeletal warhorse
18249	crescent key
18250	gordok shackle key
18251	core armor kit
18252	pattern core armor kit
18253	major rejuvenation potion
18254	runn tum tuber surprise
18255	runn tum tuber
18256	imbued vial
18257	recipe major rejuvenation potion
18258	gordok ogre suit
18259	formula enchant weapon spell power
18260	formula enchant weapon healing power
18261	book of incantations
18262	elemental sharpening stone
18263	flarecore wraps
18264	plans elemental sharpening stone
18265	pattern flarecore wraps
18266	gordok courtyard key
18267	recipe runn tum tuber surprise
18268	gordok inner door key
18269	gordok green grog
18282	core marksman rifle
18283	biznicks 247x128 accurascope
18284	kreeg s stout beatdown
18285	crystallized mana shard
18286	condensed mana fragment
18287	evermurky
18288	molasses firewater
18289	barbed thorn necklace
18290	schematic biznicks 247x128 accurascope
18291	schematic force reactive disk
18292	schematic core marksman rifle
18294	elixir of greater water breathing
18295	phasing boots
18296	marksman bands
18297	thornling seed
18298	unbridled leggings
18299	hydrospawn essence
18300	hyjal nectar
18301	lethtendris s wand
18302	band of vigor
18305	breakwater legguards
18306	gloves of shadowy mist
18307	riptide shoes
18308	clever hat
18309	gloves of restoration
18310	fiendish machete
18311	quel dorai channeling rod
18312	energized chestplate
18313	helm of awareness
18314	ring of demonic guile
18315	ring of demonic potency
18317	tempest talisman
18318	merciful greaves
18319	fervent helm
18321	energetic rod
18322	waterspout boots
18323	satyr s bow
18324	waveslicer
18325	felhide cap
18326	razor gauntlets
18327	whipvine cord
18328	shadewood cloak
18329	arcanum of rapidity
18330	arcanum of focus
18331	arcanum of protection
18332	libram of rapidity
18333	libram of focus
18334	libram of protection
18335	pristine black diamond
18336	gauntlet of gordok might
18337	orphic bracers
18338	wand of arcane potency
18339	eidolon cloak
18340	eidolon talisman
18343	petrified band
18344	stonebark gauntlets
18345	murmuring ring
18346	threadbare trousers
18347	well balanced axe
18348	quel serrar
18349	gauntlets of accuracy
18350	amplifying cloak
18351	magically sealed bracers
18352	petrified bark shield
18353	stoneflower staff
18354	pimgib s collar
18356	garona a study on stealth and treachery
18357	codex of defense
18358	the arcanist s cookbook
18359	the light and how to swing it
18360	harnessing shadows
18361	the greatest race of hunters
18362	holy bologna what the light won t tell you
18363	frost shock and you
18364	the emerald dream
18365	a thoroughly read copy of nat pagle s extreme anglin
18366	gordok s handguards
18367	gordok s gauntlets
18368	gordok s gloves
18369	gordok s handwraps
18370	vigilance charm
18371	mindtap talisman
18372	blade of the new moon
18373	chestplate of tranquility
18374	flamescarred shoulders
18375	bracers of the eclipse
18376	timeworn mace
18377	quickdraw gloves
18378	silvermoon leggings
18379	odious greaves
18380	eldritch reinforced legplates
18381	evil eye pendant
18382	fluctuating cloak
18383	force imbued gauntlets
18384	bile etched spaulders
18385	robe of everlasting night
18386	padre s trousers
18387	brightspark gloves
18388	stoneshatter
18389	cloak of the cosmos
18390	tanglemoss leggings
18391	eyestalk cord
18392	distracting dagger
18393	warpwood binding
18394	demon howl wristguards
18395	emerald flame ring
18396	mind carver
18397	elder magus pendant
18398	tidal loop
18399	ocean s breeze
18400	ring of living stone
18401	foror s compendium of dragon slaying
18402	glowing crystal ring
18403	dragonslayer s signet
18404	onyxia tooth pendant
18405	belt of the archmage
18406	onyxia blood talisman
18407	felcloth gloves
18408	inferno gloves
18409	mooncloth gloves
18410	sprinter s sword
18411	spry boots
18412	core fragment
18413	cloak of warding
18414	pattern belt of the archmage
18415	pattern felcloth gloves
18416	pattern inferno gloves
18417	pattern mooncloth gloves
18418	pattern cloak of warding
18420	bonecrusher
18421	backwood helm
18422	head of onyxia
18423	head of onyxia
18424	sedge boots
18425	kreeg s mug
18426	lethtendris s web
18427	sergeant s cloak
18428	senior sergeant s insignia
18429	first sergeant s plate bracers
18430	first sergeant s plate bracers
18432	first sergeant s mail wristguards
18434	first sergeant s dragonhide armguards
18435	first sergeant s leather armguards
18436	first sergeant s dragonhide armguards
18437	first sergeant s silk cuffs
18438	sergeant s mark
18440	sergeant s cape
18441	sergeant s cape
18442	master sergeant s insignia
18443	master sergeant s insignia
18444	master sergeant s insignia
18445	sergeant major s plate wristguards
18447	sergeant major s plate wristguards
18448	sergeant major s chain armguards
18449	sergeant major s chain armguards
18450	robe of combustion
18451	hyena hide belt
18452	sergeant major s leather armsplints
18453	sergeant major s leather armsplints
18454	sergeant major s dragonhide armsplints
18455	sergeant major s dragonhide armsplints
18456	sergeant major s silk cuffs
18457	sergeant major s silk cuffs
18458	modest armguards
18459	gallant s wristguards
18460	unsophisticated hand cannon
18461	sergeant s cloak
18462	jagged bone fist
18463	ogre pocket knife
18464	gordok nose ring
18465	royal seal of eldre thalas
18466	royal seal of eldre thalas
18467	royal seal of eldre thalas
18468	royal seal of eldre thalas
18469	royal seal of eldre thalas
18470	royal seal of eldre thalas
18471	royal seal of eldre thalas
18472	royal seal of eldre thalas
18473	royal seal of eldre thalas
18475	oddly magical belt
18476	mud stained boots
18477	shaggy leggings
18478	hyena hide jerkin
18479	carrion scorpid helm
18480	scarab plate helm
18481	skullcracking mace
18482	ogre toothpick shooter
18483	mana channeling wand
18484	cho rush s blade
18485	observer s shield
18486	mooncloth robe
18487	pattern mooncloth robe
18488	heated ancient blade
18489	unfired ancient blade
18490	insightful hood
18491	lorespinner
18492	treated ancient blade
18493	bulky iron spaulders
18494	denwatcher s shoulders
18495	redoubt cloak
18496	heliotrope cloak
18497	sublime wristguards
18498	hedgecutter
18499	barrier shield
18500	tarnished elven ring
18501	felvine shard
18502	monstrous glaive
18503	kromcrush s chestplate
18504	girdle of insight
18505	mugger s belt
18506	mongoose boots
18507	boots of the full moon
18508	swift flight bracers
18509	chromatic cloak
18510	hide of the wild
18511	shifting cloak
18512	larval acid
18513	a dull and flat elven blade
18514	pattern girdle of insight
18515	pattern mongoose boots
18516	pattern swift flight bracers
18517	pattern chromatic cloak
18518	pattern hide of the wild
18519	pattern shifting cloak
18520	barbarous blade
18521	grimy metal boots
18522	band of the ogre king
18523	brightly glowing stone
18524	leggings of destruction
18525	bracers of prosperity
18526	crown of the ogre king
18527	harmonious gauntlets
18528	cyclone spaulders
18529	elemental plate girdle
18530	ogre forged hauberk
18531	unyielding maul
18532	mindsurge robe
18533	gordok bracers of power
18534	rod of the ogre magi
18535	milli s shield
18536	milli s lexicon
18537	counterattack lodestone
18538	treant s bane
18539	reliquary of purity
18540	sealed reliquary of purity
18541	puissant cape
18542	typhoon
18543	ring of entropy
18544	doomhide gauntlets
18545	leggings of arcane supremacy
18546	infernal headcage
18547	unmelting ice girdle
18562	elementium ore
18563	bindings of the windseeker
18564	bindings of the windseeker
18565	vessel of rebirth
18566	essence of the firelord
18567	elemental flux
18582	the twin blades of azzinoth
18583	warglaive of azzinoth right
18584	warglaive of azzinoth left
18585	band of allegiance
18586	lonetree s circle
18587	goblin jumper cables xl
18588	ez thro dynamite ii
18590	raging beast s blood
18591	case of blood
18592	plans sulfuron hammer
18594	powerful seaforium charge
18595	blood opal
18597	orcish orphan whistle
18598	human orphan whistle
18600	tome of arcane brilliance
18601	glowing crystal prison
18602	tome of sacrifice
18603	satyr blood
18604	tears of the hederine
18605	imprisoned doomguard
18606	alliance battle standard
18607	horde battle standard
18608	benediction
18609	anathema
18610	keen machete
18611	gnarlpine leggings
18612	bloody chain boots
18622	flawless fel essence jaedenar
18623	flawless fel essence dark portal
18624	flawless fel essence azshara
18625	kroshius infernal core
18626	fel fire
18627	gong of dethmoora
18628	thorium brotherhood contract
18629	black lodestone
18630	doomsday flare
18631	truesilver transformer
18632	moonbrook riot taffy
18633	styleen s sour suckerpop
18634	gyrofreeze ice reflector
18635	bellara s nutterbar
18636	ruined jumper cables xl
18637	major recombobulator
18638	hyper radiant flame reflector
18639	ultra flash shadow reflector
18640	happy fun rock
18641	dense dynamite
18642	jaina s autograph
18643	cairne s hoofprint
18645	alarm o bot
18646	the eye of divinity
18647	schematic red firework
18648	schematic green firework
18649	schematic blue firework
18650	schematic ez thro dynamite ii
18651	schematic truesilver transformer
18652	schematic gyrofreeze ice reflector
18653	schematic goblin jumper cables xl
18654	schematic gnomish alarm o bot
18655	schematic major recombobulator
18656	schematic powerful seaforium charge
18657	schematic hyper radiant flame reflector
18658	schematic ultra flash shadow reflector
18659	splinter of nordrassil
18660	world enlarger
18661	schematic world enlarger
18662	heavy leather ball
18663	j eevee s jar
18664	a treatise on military ranks
18665	the eye of shadow
18670	xorothian glyphs
18671	baron charr s sceptre
18672	elemental ember
18673	avalanchion s stony hide
18674	hardened stone band
18675	military ranks of the horde & alliance
18676	sash of the windreaver
18677	zephyr cloak
18678	tempestria s frozen necklace
18679	frigid ring
18680	ancient bone bow
18681	burial shawl
18682	ghoul skin leggings
18683	hammer of the vesper
18684	dimly opalescent ring
18686	bone golem shoulders
18687	xorothian stardust
18688	imp in a jar
18689	phantasmal cloak
18690	wraithplate leggings
18691	dark advisor s pendant
18692	death knight sabatons
18693	shivery handwraps
18694	shadowy mail greaves
18695	spellbound tome
18696	intricately runed shield
18697	coldstone slippers
18698	tattered leather hood
18699	icy tomb spaulders
18700	malefic bracers
18701	innervating band
18702	belt of the ordained
18703	ancient petrified leaf
18704	mature blue dragon sinew
18705	mature black dragon sinew
18706	arena master
18707	ancient rune etched stave
18708	petrified bark
18709	arena wristguards
18710	arena bracers
18711	arena bands
18712	arena vambraces
18713	rhok delar longbow of the ancient keepers
18714	ancient sinew wrapped lamina
18715	lok delar stave of the ancient keepers
18716	ash covered boots
18717	hammer of the grand crusader
18718	grand crusader s helm
18719	the traitor s heart
18720	shroud of the nathrezim
18721	barrage girdle
18722	death grips
18723	animated chain necklace
18724	enchanted black dragon sinew
18725	peacemaker
18726	magistrate s cuffs
18727	crimson felt hat
18728	anastari heirloom
18729	screeching bow
18730	shadowy laced handwraps
18731	pattern heavy leather ball
18734	pale moon cloak
18735	maleki s footwraps
18736	plaguehound leggings
18737	bone slicing hatchet
18738	carapace spine crossbow
18739	chitinous plate legguards
18740	thuzadin sash
18741	morlune s bracer
18742	stratholme militia shoulderguard
18743	gracious cape
18744	plaguebat fur gloves
18745	sacred cloth leggings
18746	divination scryer
18749	charger s lost soul
18752	exorcism censer
18753	arcanite barding
18754	fel hardened bracers
18755	xorothian firestick
18756	dreadguard s protector
18757	diabolic mantle
18758	specter s blade
18759	malicious axe
18760	necromantic band
18761	oblivion s touch
18762	shard of the green flame
18766	reins of the swift frostsaber
18767	reins of the swift mistsaber
18768	reins of the swift dawnsaber
18769	enchanted thorium platemail
18770	enchanted thorium platemail
18771	enchanted thorium platemail
18772	swift green mechanostrider
18773	swift white mechanostrider
18774	swift yellow mechanostrider
18775	manna enriched horse feed
18776	swift palomino
18777	swift brown steed
18778	swift white steed
18779	bottom half of advanced armorsmithing volume i
18780	top half of advanced armorsmithing volume i
18781	bottom half of advanced armorsmithing volume ii
18782	top half of advanced armorsmithing volume ii
18783	bottom half of advanced armorsmithing volume iii
18784	top half of advanced armorsmithing volume iii
18785	swift white ram
18786	swift brown ram
18787	swift gray ram
18788	swift blue raptor
18789	swift olive raptor
18790	swift orange raptor
18791	purple skeletal warhorse
18792	blessed arcanite barding
18793	great white kodo
18794	great brown kodo
18795	great gray kodo
18796	horn of the swift brown wolf
18797	horn of the swift timber wolf
18798	horn of the swift gray wolf
18799	charger s redeemed soul
18802	shadowy potion
18803	finkle s lava dredger
18804	lord grayson s satchel
18805	core hound tooth
18806	core forged greaves
18807	helm of latent power
18808	gloves of the hypnotic flame
18809	sash of whispered secrets
18810	wild growth spaulders
18811	fireproof cloak
18812	wristguards of true flight
18813	ring of binding
18814	choker of the fire lord
18815	essence of the pure flame
18816	perdition s blade
18817	crown of destruction
18818	mor zul s instructions
18819	rohan s exorcism censer
18820	talisman of ephemeral power
18821	quick strike ring
18822	obsidian edged blade
18823	aged core leather gloves
18824	magma tempered boots
18825	grand marshal s aegis
18826	high warlord s shield wall
18827	grand marshal s handaxe
18828	high warlord s cleaver
18829	deep earth spaulders
18830	grand marshal s sunderer
18831	high warlord s battle axe
18832	brutality blade
18833	grand marshal s bullseye
18834	insignia of the horde
18835	high warlord s recurve
18836	grand marshal s repeater
18837	high warlord s crossbow
18838	grand marshal s dirk
18839	combat healing potion
18840	high warlord s razor
18841	combat mana potion
18842	staff of dominance
18843	grand marshal s right hand blade
18844	high warlord s right claw
18845	insignia of the horde
18846	insignia of the horde
18847	grand marshal s left hand blade
18848	high warlord s left claw
18849	insignia of the horde
18850	insignia of the horde
18851	insignia of the horde
18852	insignia of the horde
18853	insignia of the horde
18854	insignia of the alliance
18855	grand marshal s hand cannon
18856	insignia of the alliance
18857	insignia of the alliance
18858	insignia of the alliance
18859	insignia of the alliance
18860	high warlord s street sweeper
18861	flamewaker legplates
18862	insignia of the alliance
18863	insignia of the alliance
18864	insignia of the alliance
18865	grand marshal s punisher
18866	high warlord s bludgeon
18867	grand marshal s battle hammer
18868	high warlord s pulverizer
18869	grand marshal s glaive
18870	helm of the lifegiver
18871	high warlord s pig sticker
18872	manastorm leggings
18873	grand marshal s stave
18874	high warlord s war staff
18875	salamander scale pants
18876	grand marshal s claymore
18877	high warlord s greatsword
18878	sorcerous dagger
18879	heavy dark iron ring
18880	darkreaver s head
18902	reins of the swift stormsaber
18904	zorbin s ultra shrinker
18922	secret plans fiery flux
18942	fiery flux
18943	dark iron pillow
18944	incendosaur scale
18945	dark iron residue
18946	head of overseer maltorius
18947	rage scar yeti hide
18948	barbaric bracers
18949	pattern barbaric bracers
18950	chambermaid pillaclencher s pillow
18951	evonice s landin pilla
18952	simone s head
18953	klinfran s head
18954	solenor s head
18955	artorius s head
18956	miniaturization residue
18957	brushwood blade
18958	water elemental core
18959	smithing tuyere
18960	lookout s spyglass
18961	zukk ash carapace
18962	stinglasher s glands
18963	turtle egg albino
18964	turtle egg loggerhead
18965	turtle egg hawksbill
18966	turtle egg leatherback
18967	turtle egg olive
18969	pristine yeti hide
18970	ring of critical testing 2
18972	perfect yeti hide
18984	dimensional ripper everlook
18986	ultrasafe transporter gadgetzan
18987	blackhand s command
19002	head of nefarian
19003	head of nefarian
19004	minor healthstone
19005	minor healthstone
19006	lesser healthstone
19007	lesser healthstone
19008	healthstone
19009	healthstone
19010	greater healthstone
19011	greater healthstone
19012	major healthstone
19013	major healthstone
19016	vessel of rebirth
19017	essence of the firelord
19018	dormant wind kissed blade
19019	thunderfury blessed blade of the windseeker
19020	camp mojache zukk ash report
19022	nat pagle s extreme angler fc 5000
19023	katoom s best lure
19024	arena grand master
19025	skylord plume
19026	snake burst firework
19027	schematic snake burst firework
19028	elegant dress
19029	horn of the frostwolf howler
19030	stormpike battle charger
19031	frostwolf battle tabard
19032	stormpike battle tabard
19033	slagtree s lost tools
19034	lard s lunch
19035	lard s special picnic basket
19036	final message to the wildhammer
19037	emerald peak spaulders
19038	ring of subtlety
19039	zorbin s water resistant hat
19040	zorbin s mega slicer
19041	pratt s handcrafted tunic
19042	jangdor s handcrafted tunic
19043	heavy timbermaw belt
19044	might of the timbermaw
19045	stormpike battle standard
19046	frostwolf battle standard
19047	wisdom of the timbermaw
19048	heavy timbermaw boots
19049	timbermaw brawlers
19050	mantle of the timbermaw
19051	girdle of the dawn
19052	dawn treaders
19054	red dragon orb
19055	green dragon orb
19056	argent boots
19057	gloves of the dawn
19058	golden mantle of the dawn
19059	argent shoulders
19060	warsong gulch enriched ration
19061	warsong gulch iron ration
19062	warsong gulch field ration
19064	shackle key
19066	warsong gulch runecloth bandage
19067	warsong gulch mageweave bandage
19068	warsong gulch silk bandage
19069	huntsman malkhor s skull
19070	huntsman malkhor s bones
19071	vessel of tainted blood
19083	frostwolf legionnaire s cloak
19084	stormpike soldier s cloak
19085	frostwolf advisor s cloak
19086	stormpike sage s cloak
19087	frostwolf plate belt
19088	frostwolf mail belt
19089	frostwolf leather belt
19090	frostwolf cloth belt
19091	stormpike plate girdle
19092	stormpike mail girdle
19093	stormpike leather girdle
19094	stormpike cloth girdle
19095	frostwolf legionnaire s pendant
19096	frostwolf advisor s pendant
19097	stormpike soldier s pendant
19098	stormpike sage s pendant
19099	glacial blade
19100	electrified dagger
19101	whiteout staff
19102	crackling staff
19103	frostbite
19104	stormstrike hammer
19105	frost runed headdress
19106	ice barbed spear
19107	bloodseeker
19108	wand of biting cold
19109	deep rooted ring
19110	cold forged blade
19111	winteraxe epaulets
19112	frozen steel vambraces
19113	yeti hide bracers
19114	highland bow
19115	flask of forest mojo
19116	greenleaf handwraps
19117	laquered wooden plate legplates
19118	nature s breath
19119	owlbeast hide gloves
19120	rune of the guard captain
19121	deep woodlands cloak
19123	everwarm handwraps
19124	slagplate leggings
19125	seared mail girdle
19126	slagplate gauntlets
19127	charred leather tunic
19128	seared mail vest
19130	cold snap
19131	snowblind shoes
19132	crystal adorned crown
19133	fel infused leggings
19134	flayed doomguard belt
19135	blacklight bracer
19136	mana igniting cord
19137	onslaught girdle
19138	band of sulfuras
19139	fireguard shoulders
19140	cauterizing band
19141	luffa
19142	fire runed grimoire
19143	flameguard gauntlets
19144	sabatons of the flamewalker
19145	robe of volatile power
19146	wristguards of stability
19147	ring of spell power
19148	dark iron helm
19149	lava belt
19150	sentinel basic care package
19151	sentinel standard care package
19152	sentinel advanced care package
19153	outrider advanced care package
19154	outrider basic care package
19155	outrider standard care package
19156	flarecore robe
19157	chromatic gauntlets
19159	woven ivy necklace
19160	contest winner s tabard
19162	corehound belt
19163	molten belt
19164	dark iron gauntlets
19165	flarecore leggings
19166	black amnesty
19167	blackfury
19168	blackguard
19169	nightfall
19170	ebon hand
19182	darkmoon faire prize ticket
19183	hourglass sand
19202	plans heavy timbermaw belt
19203	plans girdle of the dawn
19204	plans heavy timbermaw boots
19205	plans gloves of the dawn
19206	plans dark iron helm
19207	plans dark iron gauntlets
19208	plans black amnesty
19209	plans blackfury
19210	plans ebon hand
19211	plans blackguard
19212	plans nightfall
19213	silverwing talisman of merit
19215	pattern wisdom of the timbermaw
19216	pattern argent boots
19217	pattern argent shoulders
19218	pattern mantle of the timbermaw
19219	pattern flarecore robe
19220	pattern flarecore leggings
19221	darkmoon special reserve
19222	cheap beer
19223	darkmoon dog
19224	red hot wings
19225	deep fried candybar
19227	ace of beasts
19228	beasts deck
19229	sayge s fortune #1
19230	two of beasts
19231	three of beasts
19232	four of beasts
19233	five of beasts
19234	six of beasts
19235	seven of beasts
19236	eight of beasts
19237	sayge s fortune #19
19238	sayge s fortune #3
19239	sayge s fortune #4
19240	sayge s fortune #5
19241	sayge s fortune #6
19242	sayge s fortune #7
19243	sayge s fortune #8
19244	sayge s fortune #9
19245	sayge s fortune #10
19246	sayge s fortune #11
19247	sayge s fortune #12
19248	sayge s fortune #13
19249	sayge s fortune #14
19250	sayge s fortune #15
19251	sayge s fortune #16
19252	sayge s fortune #18
19253	sayge s fortune #17
19254	sayge s fortune #21
19255	sayge s fortune #22
19256	sayge s fortune #2
19257	warlords deck
19258	ace of warlords
19259	two of warlords
19260	three of warlords
19261	four of warlords
19262	five of warlords
19263	six of warlords
19264	seven of warlords
19265	eight of warlords
19266	sayge s fortune #20
19267	elementals deck
19268	ace of elementals
19269	two of elementals
19270	three of elementals
19271	four of elementals
19272	five of elementals
19273	six of elementals
19274	seven of elementals
19275	eight of elementals
19276	ace of portals
19277	portals deck
19278	two of portals
19279	three of portals
19280	four of portals
19281	five of portals
19282	six of portals
19283	seven of portals
19284	eight of portals
19287	darkmoon card heroism
19288	darkmoon card blue dragon
19289	darkmoon card maelstrom
19290	darkmoon card twisting nether
19291	darkmoon storage box
19292	last month s mutton
19293	last year s mutton
19295	darkmoon flower
19296	greater darkmoon prize
19297	lesser darkmoon prize
19298	minor darkmoon prize
19299	fizzy faire drink
19300	bottled winterspring water
19301	alterac manna biscuit
19302	darkmoon ring
19303	darkmoon necklace
19304	spiced beef jerky
19305	pickled kodo foot
19306	crunchy frog
19307	alterac heavy runecloth bandage
19308	tome of arcane domination
19309	tome of shadow force
19310	tome of the ice lord
19311	tome of fiery arcana
19312	lei of the lifegiver
19315	therazane s touch
19316	ice threaded arrow
19317	ice threaded bullet
19318	bottled alterac spring water
19319	harpy hide quiver
19320	gnoll skin bandolier
19321	the immovable object
19322	warsong mark of honor
19323	the unstoppable force
19324	the lobotomizer
19325	don julio s band
19326	pattern might of the timbermaw
19327	pattern timbermaw brawlers
19328	pattern dawn treaders
19329	pattern golden mantle of the dawn
19330	pattern lava belt
19331	pattern chromatic gauntlets
19332	pattern corehound belt
19333	pattern molten belt
19334	the untamed blade
19335	spineshatter
19336	arcane infused gem
19337	the black book
19338	free ticket voucher
19339	mind quickening gem
19340	rune of metamorphosis
19341	lifegiving gem
19342	venomous totem
19343	scrolls of blinding light
19344	natural alignment crystal
19345	aegis of preservation
19346	dragonfang blade
19347	claw of chromaggus
19348	red dragonscale protector
19349	elementium reinforced bulwark
19350	heartstriker
19351	maladath runed blade of the black flight
19352	chromatically tempered sword
19353	drake talon cleaver
19354	draconic avenger
19355	shadow wing focus staff
19356	staff of the shadow flame
19357	herald of woe
19358	draconic maul
19360	lok amir il romathis
19361	ashjre thul crossbow of smiting
19362	doom s edge
19363	crul shorukh edge of chaos
19364	ashkandi greatsword of the brotherhood
19365	claw of the black drake
19366	master dragonslayer s orb
19367	dragon s touch
19368	dragonbreath hand cannon
19369	gloves of rapid evolution
19370	mantle of the blackwing cabal
19371	pendant of the fallen dragon
19372	helm of endless rage
19373	black brood pauldrons
19374	bracers of arcane accuracy
19375	mish undare circlet of the mind flayer
19376	archimtiros ring of reckoning
19377	prestor s talisman of connivery
19378	cloak of the brood lord
19379	neltharion s tear
19380	therazane s link
19381	boots of the shadow flame
19382	pure elementium band
19383	master dragonslayer s medallion
19384	master dragonslayer s ring
19385	empowered leggings
19386	elementium threaded cloak
19387	chromatic boots
19388	angelista s grasp
19389	taut dragonhide shoulderpads
19390	taut dragonhide gloves
19391	shimmering geta
19392	girdle of the fallen crusader
19393	primalist s linked waistguard
19394	drake talon pauldrons
19395	rejuvenating gem
19396	taut dragonhide belt
19397	ring of blackrock
19398	cloak of firemaw
19399	black ash robe
19400	firemaw s clutch
19401	primalist s linked legguards
19402	legguards of the fallen crusader
19403	band of forced concentration
19405	malfurion s blessed bulwark
19406	drake fang talisman
19407	ebony flame gloves
19422	darkmoon faire fortune
19423	sayge s fortune #23
19424	sayge s fortune #24
19425	mysterious lockbox
19426	orb of the darkmoon
19430	shroud of pure thought
19431	styleen s impeding scarab
19432	circle of applied force
19433	emberweave leggings
19434	band of dark dominion
19435	essence gatherer
19436	cloak of draconic might
19437	boots of pure thought
19438	ringo s blizzard boots
19439	interlaced shadow jerkin
19440	powerful anti venom
19441	huge venom sac
19442	formula powerful anti venom
19443	sayge s fortune #25
19444	formula enchant weapon strength
19445	formula enchant weapon agility
19446	formula enchant bracer mana regeneration
19447	formula enchant bracer healing
19448	formula enchant weapon mighty spirit
19449	formula enchant weapon mighty intellect
19450	a jubling s tiny home
19451	sayge s fortune #26
19452	sayge s fortune #27
19453	sayge s fortune #28
19454	sayge s fortune #29
19462	unhatched jubling egg
19482	lecraft rabbit pelt
19483	peeling the onion
19484	the frostwolf artichoke
19491	amulet of the darkmoon
19505	warsong battle tabard
19506	silverwing battle tabard
19507	inquisitor s shawl
19508	branded leather bracers
19509	dusty mail boots
19510	legionnaire s band
19511	legionnaire s band
19512	legionnaire s band
19513	legionnaire s band
19514	protector s band
19515	protector s band
19516	protector s band
19517	protector s band
19518	advisor s ring
19519	advisor s ring
19520	advisor s ring
19521	advisor s ring
19522	lorekeeper s ring
19523	lorekeeper s ring
19524	lorekeeper s ring
19525	lorekeeper s ring
19526	battle healer s cloak
19527	battle healer s cloak
19528	battle healer s cloak
19529	battle healer s cloak
19530	caretaker s cape
19531	caretaker s cape
19532	caretaker s cape
19533	caretaker s cape
19534	scout s medallion
19535	scout s medallion
19536	scout s medallion
19537	scout s medallion
19538	sentinel s medallion
19539	sentinel s medallion
19540	sentinel s medallion
19541	sentinel s medallion
19542	scout s blade
19543	scout s blade
19544	scout s blade
19545	scout s blade
19546	sentinel s blade
19547	sentinel s blade
19548	sentinel s blade
19549	sentinel s blade
19550	legionnaire s sword
19551	legionnaire s sword
19552	legionnaire s sword
19553	legionnaire s sword
19554	protector s sword
19555	protector s sword
19556	protector s sword
19557	protector s sword
19558	outrider s bow
19559	outrider s bow
19560	outrider s bow
19561	outrider s bow
19562	outrunner s bow
19563	outrunner s bow
19564	outrunner s bow
19565	outrunner s bow
19566	advisor s gnarled staff
19567	advisor s gnarled staff
19568	advisor s gnarled staff
19569	advisor s gnarled staff
19570	lorekeeper s staff
19571	lorekeeper s staff
19572	lorekeeper s staff
19573	lorekeeper s staff
19574	strength of mugamba
19575	strength of mugamba
19576	strength of mugamba
19577	rage of mugamba
19578	berserker bracers
19579	heathen s brand
19580	berserker bracers
19581	berserker bracers
19582	windtalker s wristguards
19583	windtalker s wristguards
19584	windtalker s wristguards
19585	heathen s brand
19586	heathen s brand
19587	forest stalker s bracers
19588	hero s brand
19589	forest stalker s bracers
19590	forest stalker s bracers
19591	the eye of zuldazar
19592	the eye of zuldazar
19593	the eye of zuldazar
19594	the all seeing eye of zuldazar
19595	dryad s wrist bindings
19596	dryad s wrist bindings
19597	dryad s wrist bindings
19598	pebble of kajaro
19599	pebble of kajaro
19600	pebble of kajaro
19601	jewel of kajaro
19602	kezan s taint
19603	kezan s taint
19604	kezan s taint
19605	kezan s unstoppable taint
19606	vision of voodress
19607	vision of voodress
19608	vision of voodress
19609	unmarred vision of voodress
19610	enchanted south seas kelp
19611	enchanted south seas kelp
19612	enchanted south seas kelp
19613	pristine enchanted south seas kelp
19614	zandalarian shadow talisman
19615	zandalarian shadow talisman
19616	zandalarian shadow talisman
19617	zandalarian shadow mastery talisman
19618	maelstrom s tendril
19619	maelstrom s tendril
19620	maelstrom s tendril
19621	maelstrom s wrath
19642	icoke prize voucher
19682	bloodvine vest
19683	bloodvine leggings
19684	bloodvine boots
19685	primal batskin jerkin
19686	primal batskin gloves
19687	primal batskin bracers
19688	blood tiger breastplate
19689	blood tiger shoulders
19690	bloodsoul breastplate
19691	bloodsoul shoulders
19692	bloodsoul gauntlets
19693	darksoul breastplate
19694	darksoul leggings
19695	darksoul shoulders
19696	harvest bread
19697	bounty of the harvest
19698	zulian coin
19699	razzashi coin
19700	hakkari coin
19701	gurubashi coin
19702	vilebranch coin
19703	witherbark coin
19704	sandfury coin
19705	skullsplitter coin
19706	bloodscalp coin
19707	red hakkari bijou
19708	blue hakkari bijou
19709	yellow hakkari bijou
19710	orange hakkari bijou
19711	green hakkari bijou
19712	purple hakkari bijou
19713	bronze hakkari bijou
19714	silver hakkari bijou
19715	gold hakkari bijou
19716	primal hakkari bindings
19717	primal hakkari armsplint
19718	primal hakkari stanchion
19719	primal hakkari girdle
19720	primal hakkari sash
19721	primal hakkari shawl
19722	primal hakkari tabard
19723	primal hakkari kossack
19724	primal hakkari aegis
19725	arathi resource crate
19726	bloodvine
19727	blood scythe
19760	overlord s embrace
19764	pattern bloodvine vest
19765	pattern bloodvine leggings
19766	pattern bloodvine boots
19767	primal bat leather
19768	primal tiger leather
19769	pattern primal batskin jerkin
19770	pattern primal batskin gloves
19771	pattern primal batskin bracers
19772	pattern blood tiger breastplate
19773	pattern blood tiger shoulders
19774	souldarite
19775	sealed azure bag
19776	plans bloodsoul breastplate
19777	plans bloodsoul shoulders
19778	plans bloodsoul gauntlets
19779	plans darksoul breastplate
19780	plans darksoul leggings
19781	plans darksoul shoulders
19782	presence of might
19783	syncretist s sigil
19784	death s embrace
19785	falcon s call
19786	vodouisant s vigilant embrace
19787	presence of sight
19788	hoodoo hex
19789	prophetic aura
19790	animist s caress
19802	heart of hakkar
19803	brownell s blue striped racer
19804	pale ghoulfish
19805	keefer s angelfish
19806	dezian queenfish
19807	speckled tastyfish
19808	rockhide strongfish
19812	rune of the dawn
19813	punctured voodoo doll
19814	punctured voodoo doll
19815	punctured voodoo doll
19816	punctured voodoo doll
19817	punctured voodoo doll
19818	punctured voodoo doll
19819	punctured voodoo doll
19820	punctured voodoo doll
19821	punctured voodoo doll
19822	zandalar vindicator s breastplate
19823	zandalar vindicator s belt
19824	zandalar vindicator s armguards
19825	zandalar freethinker s breastplate
19826	zandalar freethinker s belt
19827	zandalar freethinker s armguards
19828	zandalar augur s hauberk
19829	zandalar augur s belt
19830	zandalar augur s bracers
19831	zandalar predator s mantle
19832	zandalar predator s belt
19833	zandalar predator s bracers
19834	zandalar madcap s tunic
19835	zandalar madcap s mantle
19836	zandalar madcap s bracers
19838	zandalar haruspex s tunic
19839	zandalar haruspex s belt
19840	zandalar haruspex s bracers
19841	zandalar confessor s mantle
19842	zandalar confessor s bindings
19843	zandalar confessor s wraps
19845	zandalar illusionist s mantle
19846	zandalar illusionist s wraps
19848	zandalar demoniac s wraps
19849	zandalar demoniac s mantle
19850	uther s tribute
19851	grom s tribute
19852	ancient hakkari manslayer
19853	gurubashi dwarf destroyer
19854	zin rokh destroyer of worlds
19855	bloodsoaked legplates
19856	the eye of hakkar
19857	cloak of consumption
19858	zandalar honor token
19859	fang of the faceless
19861	touch of chaos
19862	aegis of the blood god
19863	primalist s seal
19864	bloodcaller
19865	warblade of the hakkari
19866	warblade of the hakkari
19867	bloodlord s defender
19869	blooddrenched grips
19870	hakkari loa cloak
19871	talisman of protection
19872	swift razzashi raptor
19873	overlord s crimson band
19874	halberd of smiting
19875	bloodstained coif
19876	soul corrupter s necklace
19877	animist s leggings
19878	bloodsoaked pauldrons
19879	alex s test beatdown staff
19880	gurubashi head collection
19881	channeler s head
19882	the hexxer s head
19883	sacred cord
19884	jin do s judgement
19885	jin do s evil eye
19886	the hexxer s cover
19887	bloodstained legplates
19888	overlord s embrace
19889	blooddrenched leggings
19890	jin do s hexxer
19891	jin do s bag of whammies
19892	animist s boots
19893	zanzil s seal
19894	bloodsoaked gauntlets
19895	bloodtinged kilt
19896	thekal s grasp
19897	betrayer s boots
19898	seal of jin
19899	ritualistic legguards
19900	zulian stone axe
19901	zulian slicer
19902	swift zulian tiger
19903	fang of venoxis
19904	runed bloodstained hauberk
19905	zanzil s band
19906	blooddrenched footpads
19907	zulian tigerhide cloak
19908	sceptre of smiting
19909	will of arlokk
19910	arlokk s grasp
19911	whipweed heart
19912	overlord s onyx band
19913	bloodsoaked greaves
19914	panther hide sack
19915	zulian defender
19918	jeklik s crusher
19919	bloodstained greaves
19920	primalist s band
19921	zulian hacker
19922	arlokk s hoodoo stick
19923	jeklik s opaline talisman
19925	band of jin
19927	mar li s touch
19928	animist s spaulders
19929	bloodtinged gloves
19930	mar li s eye
19931	gurubashi mojo madness
19933	glowing scorpid blood
19934	large scorpid claw
19935	empty venom sac
19936	dried scorpid carapace
19937	small scorpid claw
19938	heavy scorpid leg
19939	gri lek s blood
19940	renataki s tooth
19941	wushoolay s mane
19942	hazza rah s dream thread
19943	massive mojo
19944	nat pagle s fish terminator
19945	foror s eyepatch
19946	tigule s harpoon
19947	nat pagle s broken reel
19948	zandalarian hero badge
19949	zandalarian hero medallion
19950	zandalarian hero charm
19951	gri lek s charm of might
19952	gri lek s charm of valor
19953	renataki s charm of beasts
19954	renataki s charm of trickery
19955	wushoolay s charm of nature
19956	wushoolay s charm of spirits
19957	hazza rah s charm of destruction
19958	hazza rah s charm of healing
19959	hazza rah s charm of magic
19960	crystalized honey
19961	gri lek s grinder
19962	gri lek s carver
19963	pitchfork of madness
19964	renataki s soul conduit
19965	wushoolay s poker
19967	thoughtblighter
19968	fiery retributer
19969	nat pagle s extreme anglin boots
19970	arcanite fishing pole
19971	high test eternium fishing line
19972	lucky fishing hat
19973	nat s measuring tape
19974	mudskunk lure
19975	zulian mudskunk
19978	fishing tournament
19979	hook of the master angler
19982	duskbat drape
19984	ebon mask
19990	blessed prayer beads
19991	devilsaur eye
19992	devilsaur tooth
19993	hoodoo hunting bow
19994	harvest fruit
19995	harvest boar
19996	harvest fish
19997	harvest nectar
19998	bloodvine lens
19999	bloodvine goggles
20000	schematic bloodvine goggles
20001	schematic bloodvine lens
20002	greater dreamless sleep potion
20004	major troll s blood potion
20006	circle of hope
20007	mageblood potion
20008	living action potion
20009	for the light
20010	the horde s hellscream
20011	recipe mageblood potion
20012	recipe greater dreamless sleep
20013	recipe living action potion
20014	recipe major troll s blood potion
20015	elder raptor feathers
20016	trophy raptor skull
20017	perfect courser antler
20018	angerclaw grizzly hide
20019	tooth of morphaz
20020	bundle of goods
20021	gold pirate earring
20022	azure key
20023	encoded fragment
20024	putrid bile duct
20025	blood of morphaz
20026	rotting flesh
20027	healthy courser gland
20028	glittering dust
20029	enchanted coral
20030	pet rock
20031	essence mango
20032	flowing ritual robes
20033	zandalar demoniac s robe
20034	zandalar illusionist s robe
20035	glacial spike
20036	fire ruby
20037	arcane crystal pendant
20038	mandokir s sting
20039	dark iron boots
20040	plans dark iron boots
20041	highlander s plate girdle
20042	highlander s lamellar girdle
20043	highlander s chain girdle
20044	highlander s mail girdle
20045	highlander s leather girdle
20046	highlander s lizardhide girdle
20047	highlander s cloth girdle
20048	highlander s plate greaves
20049	highlander s lamellar greaves
20050	highlander s chain greaves
20051	highlander s mail greaves
20052	highlander s leather boots
20053	highlander s lizardhide boots
20054	highlander s cloth boots
20055	highlander s chain pauldrons
20056	highlander s mail pauldrons
20057	highlander s plate spaulders
20058	highlander s lamellar spaulders
20059	highlander s leather shoulders
20060	highlander s lizardhide shoulders
20061	highlander s epaulets
20062	arathi basin enriched ration
20063	arathi basin field ration
20064	arathi basin iron ration
20065	arathi basin mageweave bandage
20066	arathi basin runecloth bandage
20067	arathi basin silk bandage
20068	deathguard s cloak
20069	ironbark staff
20070	sageclaw
20071	talisman of arathor
20072	defiler s talisman
20073	cloak of the honor guard
20074	heavy crocolisk stew
20075	recipe heavy crocolisk stew
20076	zandalar signet of mojo
20077	zandalar signet of might
20078	zandalar signet of serenity
20079	spirit of zanza
20080	sheen of zanza
20081	swiftness of zanza
20082	woestave
20083	hunting spear
20084	hunting net
20085	arcane shard
20086	dusksteel throwing knife
20087	wavethrasher scales
20088	highlander s chain girdle
20089	highlander s chain girdle
20090	highlander s chain girdle
20091	highlander s chain greaves
20092	highlander s chain greaves
20093	highlander s chain greaves
20094	highlander s cloth boots
20095	highlander s cloth boots
20096	highlander s cloth boots
20097	highlander s cloth girdle
20098	highlander s cloth girdle
20099	highlander s cloth girdle
20100	highlander s lizardhide boots
20101	highlander s lizardhide boots
20102	highlander s lizardhide boots
20103	highlander s lizardhide girdle
20104	highlander s lizardhide girdle
20105	highlander s lizardhide girdle
20106	highlander s lamellar girdle
20107	highlander s lamellar girdle
20108	highlander s lamellar girdle
20109	highlander s lamellar greaves
20110	highlander s lamellar greaves
20111	highlander s lamellar greaves
20112	highlander s leather boots
20113	highlander s leather boots
20114	highlander s leather boots
20115	highlander s leather girdle
20116	highlander s leather girdle
20117	highlander s leather girdle
20118	highlander s mail girdle
20119	highlander s mail girdle
20120	highlander s mail girdle
20121	highlander s mail greaves
20122	highlander s mail greaves
20123	highlander s mail greaves
20124	highlander s plate girdle
20125	highlander s plate girdle
20126	highlander s plate girdle
20127	highlander s plate greaves
20128	highlander s plate greaves
20129	highlander s plate greaves
20130	diamond flask
20131	battle tabard of the defilers
20132	arathor battle tabard
20134	skyfury helm
20150	defiler s chain girdle
20151	defiler s chain girdle
20152	defiler s chain girdle
20153	defiler s chain girdle
20154	defiler s chain greaves
20155	defiler s chain greaves
20156	defiler s chain greaves
20157	defiler s chain greaves
20158	defiler s chain pauldrons
20159	defiler s cloth boots
20160	defiler s cloth boots
20161	defiler s cloth boots
20162	defiler s cloth boots
20163	defiler s cloth girdle
20164	defiler s cloth girdle
20165	defiler s cloth girdle
20166	defiler s cloth girdle
20167	defiler s lizardhide boots
20168	defiler s lizardhide boots
20169	defiler s lizardhide boots
20170	defiler s lizardhide boots
20171	defiler s lizardhide girdle
20172	defiler s lizardhide girdle
20173	defiler s lizardhide girdle
20174	defiler s lizardhide girdle
20175	defiler s lizardhide shoulders
20176	defiler s epaulets
20177	defiler s lamellar girdle
20178	defiler s lamellar girdle
20179	defiler s lamellar girdle
20180	defiler s lamellar girdle
20181	defiler s lamellar greaves
20182	defiler s lamellar greaves
20183	defiler s lamellar greaves
20184	defiler s lamellar spaulders
20185	defiler s lamellar greaves
20186	defiler s leather boots
20187	defiler s leather boots
20188	defiler s leather boots
20189	defiler s leather boots
20190	defiler s leather girdle
20191	defiler s leather girdle
20192	defiler s leather girdle
20193	defiler s leather girdle
20194	defiler s leather shoulders
20195	defiler s mail girdle
20196	defiler s mail girdle
20197	defiler s mail girdle
20198	defiler s mail girdle
20199	defiler s mail greaves
20200	defiler s mail greaves
20201	defiler s mail greaves
20202	defiler s mail greaves
20203	defiler s mail pauldrons
20204	defiler s plate girdle
20205	defiler s plate girdle
20206	defiler s plate girdle
20207	defiler s plate girdle
20208	defiler s plate greaves
20209	defiler s plate greaves
20210	defiler s plate greaves
20211	defiler s plate greaves
20212	defiler s plate spaulders
20213	belt of shrunken heads
20214	mindfang
20215	belt of shriveled heads
20216	belt of preserved heads
20217	belt of tiny heads
20218	faded hakkari cloak
20219	tattered hakkari cape
20220	ironbark staff
20222	defiler s enriched ration
20223	defiler s field ration
20224	defiler s iron ration
20225	highlander s enriched ration
20226	highlander s field ration
20227	highlander s iron ration
20228	defiler s advanced care package
20229	defiler s basic care package
20230	defiler s standard care package
20231	arathor advanced care package
20232	defiler s mageweave bandage
20233	arathor basic care package
20234	defiler s runecloth bandage
20235	defiler s silk bandage
20236	arathor standard care package
20237	highlander s mageweave bandage
20243	highlander s runecloth bandage
20244	highlander s silk bandage
20253	pattern warbear harness
20254	pattern warbear woolies
20255	whisperwalk boots
20256	warsong gulch ribbon of sacrifice
20257	seafury gauntlets
20258	zulian ceremonial staff
20259	shadow panther hide gloves
20260	seafury leggings
20261	shadow panther hide belt
20262	seafury boots
20263	gurubashi helm
20264	peacekeeper gauntlets
20265	peacekeeper boots
20266	peacekeeper leggings
20295	blue dragonscale leggings
20296	green dragonscale gauntlets
20310	flayed demon skin
20337	gnome head on a stick
20367	hunting gear
20369	azurite fists
20371	blue murloc egg
20373	stonelash scorpid stinger
20374	stonelash pincer stinger
20375	stonelash flayer stinger
20376	sand skitterer fang
20377	rock stalker fang
20378	twilight tablet fragment
20379	noggle s satchel
20380	dreamscale breastplate
20381	dreamscale
20382	pattern dreamscale breastplate
20383	head of the broodlord lashlayer
20384	silithid carapace fragment
20385	deathclasp s pincer
20387	forsaken stink bomb cluster
20388	lollipop
20389	candy corn
20390	candy bar
20391	flimsy male gnome mask
20392	flimsy female gnome mask
20393	treat bag
20394	twilight lexicon chapter 1
20395	twilight lexicon chapter 2
20396	twilight lexicon chapter 3
20397	hallowed wand pirate
20398	hallowed wand ninja
20399	hallowed wand leper gnome
20400	pumpkin bag
20401	restored twilight tablet
20402	agent of nozdormu
20403	proxy of nozdormu
20404	encrypted twilight text
20405	decoded tablet transcription
20406	twilight cultist mantle
20407	twilight cultist robe
20408	twilight cultist cowl
20409	hallowed wand ghost
20410	hallowed wand bat
20411	hallowed wand skeleton
20413	hallowed wand random
20414	hallowed wand wisp
20415	the war of the shifting sands
20416	crest of beckoning fire
20418	crest of beckoning thunder
20419	crest of beckoning stone
20420	crest of beckoning water
20422	twilight cultist medallion of station
20423	sandy scorpid claw
20424	sandworm meat
20425	advisor s gnarled staff
20426	advisor s ring
20427	battle healer s cloak
20428	caretaker s cape
20429	legionnaire s band
20430	legionnaire s sword
20431	lorekeeper s ring
20432	signet of beckoning fire
20433	signet of beckoning thunder
20434	lorekeeper s staff
20435	signet of beckoning stone
20436	signet of beckoning water
20437	outrider s bow
20438	outrunner s bow
20439	protector s band
20440	protector s sword
20441	scout s blade
20442	scout s medallion
20443	sentinel s blade
20444	sentinel s medallion
20447	scepter of beckoning fire
20448	scepter of beckoning thunder
20449	scepter of beckoning stone
20450	scepter of beckoning water
20451	twilight cultist ring of lordship
20452	smoked desert dumplings
20453	geologist s transcription kit
20454	hive zora rubbing
20455	hive ashi rubbing
20456	hive regal rubbing
20457	hive ashi silithid brain
20458	hive zora silithid brain
20459	hive regal silithid brain
20461	brann bronzebeard s lost letter
20463	glyphed crystal prism
20464	glyphs of calling
20465	crystal unlocking mechanism
20466	vyral s signet ring
20467	torn recipe page
20469	decoded true believer clippings
20470	solanian s scrying orb
20471	scroll of scourge magic
20472	solanian s journal
20474	sunstrider book satchel
20475	adamantite arrow maker
20476	sandstalker bracers
20477	sandstalker gauntlets
20478	sandstalker breastplate
20479	spitfire breastplate
20480	spitfire gauntlets
20481	spitfire bracers
20482	arcane sliver
20483	tainted arcane sliver
20485	duke s seal
20487	lok delar stave of the ancient keepers dep
20488	rhok delar longbow of the ancient keepers dep
20489	crown of the council
20490	ironforge mint
20491	undercity mint
20492	stormwind nougat
20493	orgrimmar nougat
20494	gnomeregan gumdrop
20495	darkspear gumdrop
20496	darnassus marzipan
20497	thunder bluff marzipan
20498	silithid chitin
20499	broken silithid chitin
20500	light silithid carapace
20501	heavy silithid carapace
20503	enamored water spirit
20504	lightforged blade
20505	chivalrous signet
20506	pattern spitfire bracers
20507	pattern spitfire gauntlets
20508	pattern spitfire breastplate
20509	pattern sandstalker bracers
20510	pattern sandstalker gauntlets
20511	pattern sandstalker breastplate
20512	sanctified orb
20513	abyssal crest
20514	abyssal signet
20515	abyssal scepter
20516	bobbing apple
20517	razorsteel shoulders
20518	scroll create crest of beckoning
20519	southsea pirate hat
20520	dark rune
20521	fury visor
20522	feral staff
20525	earthen sigil
20526	scroll create crest of beckoning
20527	scroll create crest of beckoning
20528	scroll create crest of beckoning
20530	robes of servitude
20531	scroll create signet of beckoning
20532	scroll create signet of beckoning
20533	scroll create signet of beckoning
20534	abyss shard
20535	scroll create signet of beckoning
20536	soul harvester
20537	runed stygian boots
20538	runed stygian leggings
20539	runed stygian belt
20540	scroll create scepter of beckoning
20541	decoded twilight text
20542	scroll create scepter of beckoning
20543	scroll create scepter of beckoning
20544	scroll create scepter of beckoning
20545	decoded twilight text
20546	pattern runed stygian leggings
20547	pattern runed stygian boots
20548	pattern runed stygian belt
20549	darkrune gauntlets
20550	darkrune breastplate
20551	darkrune helm
20552	decoded twilight text
20553	plans darkrune gauntlets
20554	plans darkrune breastplate
20555	plans darkrune helm
20556	wildstaff
20557	hallow s end pumpkin treat
20558	warsong gulch mark of honor
20559	arathi basin mark of honor
20560	alterac valley mark of honor
20561	flimsy male dwarf mask
20562	flimsy female dwarf mask
20563	flimsy female nightelf mask
20564	flimsy male nightelf mask
20565	flimsy female human mask
20566	flimsy male human mask
20567	flimsy female troll mask
20568	flimsy male troll mask
20569	flimsy female orc mask
20570	flimsy male orc mask
20571	flimsy female tauren mask
20572	flimsy male tauren mask
20573	flimsy male undead mask
20574	flimsy female undead mask
20575	black whelp tunic
20576	pattern black whelp tunic
20577	nightmare blade
20578	emerald dragonfang
20579	green dragonskin cloak
20580	hammer of bestial fury
20581	staff of rampant growth
20582	trance stone
20583	sturdy female dwarf mask
20584	sturdy female gnome mask
20585	sturdy female human mask
20586	sturdy female night elf mask
20587	sturdy female orc mask
20588	sturdy female tauren mask
20589	sturdy female troll mask
20590	sturdy female undead mask
20591	sturdy male dwarf mask
20592	sturdy male gnome mask
20593	sturdy male human mask
20594	sturdy male night elf mask
20595	sturdy male orc mask
20596	sturdy male tauren mask
20597	sturdy male troll mask
20598	sturdy male undead mask
20599	polished ironwood crossbow
20600	malfurion s signet ring
20601	sack of spoils
20602	chest of spoils
20603	bag of spoils
20604	stink bomb cleaner
20605	rotten eggs
20606	amber voodoo feather
20607	blue voodoo feather
20608	green voodoo feather
20609	voodoo feathers
20610	bloodshot spider eye
20611	thick black claw
20612	inert scourgestone
20613	rotting wood
20614	bloodvenom essence
20615	dragonspur wraps
20616	dragonbone wristguards
20617	ancient corroded leggings
20618	gloves of delusional power
20619	acid inscribed greaves
20620	holy mightstone
20621	boots of the endless moor
20622	dragonheart necklace
20623	circlet of restless dreams
20624	ring of the unliving
20625	belt of the dark bog
20626	black bark wristbands
20627	dark heart pants
20628	deviate growth cap
20629	malignant footguards
20630	gauntlets of the shining light
20631	mendicant s slippers
20632	mindtear band
20633	unnatural leather spaulders
20634	boots of fright
20635	jade inlaid vestments
20636	hibernation crystal
20637	acid inscribed pauldrons
20638	leggings of the demented mind
20639	strangely glyphed legplates
20640	southsea head bucket
20641	southsea mojo boots
20642	antiquated nobleman s tunic
20643	undercity reservist s cap
20644	nightmare engulfed object
20645	nature s whisper
20646	sandstrider s mark
20647	black crystal dagger
20648	cold forged hammer
20649	sunprism pendant
20650	desert wind gauntlets
20651	orange murloc egg
20652	abyssal cloth slippers
20653	abyssal plate gauntlets
20654	amethyst war staff
20655	abyssal cloth handwraps
20656	abyssal mail sabatons
20657	crystal tipped stiletto
20658	abyssal leather boots
20659	abyssal mail handguards
20660	stonecutting glaive
20661	abyssal leather gloves
20662	abyssal plate greaves
20663	deep strike bow
20664	abyssal cloth sash
20665	abyssal leather leggings
20666	hardened steel warhammer
20667	abyssal leather belt
20668	abyssal mail legguards
20669	darkstone claymore
20670	abyssal mail clutch
20671	abyssal plate legplates
20672	sparkling crystal wand
20673	abyssal plate girdle
20674	abyssal cloth pants
20675	soulrender
20676	decoded twilight text
20677	decoded twilight text
20678	decoded twilight text
20679	decoded twilight text
20680	abyssal mail pauldrons
20681	abyssal leather bracers
20682	elemental focus band
20683	abyssal plate epaulets
20684	abyssal mail armguards
20685	wavefront necklace
20686	abyssal cloth amice
20687	abyssal plate vambraces
20688	earthen guard
20689	abyssal leather shoulders
20690	abyssal cloth wristbands
20691	windshear cape
20692	multicolored band
20693	weighted cloak
20694	glowing black orb
20695	abyssal war beads
20696	crystal spiked maul
20697	crystalline threaded cape
20698	elemental attuned blade
20699	cenarion reservist s legplates
20700	cenarion reservist s legplates
20701	cenarion reservist s legguards
20702	cenarion reservist s legguards
20703	cenarion reservist s leggings
20704	cenarion reservist s leggings
20705	cenarion reservist s pants
20706	cenarion reservist s pants
20707	cenarion reservist s pants
20708	tightly sealed trunk
20709	rumsey rum light
20710	crystal encrusted greaves
20711	crystal lined greaves
20712	wastewalker s gauntlets
20713	desertstalkers s gauntlets
20714	sandstorm boots
20715	dunestalker s boots
20716	sandworm skin gloves
20717	desert bloom gloves
20720	dark whisper blade
20721	band of the cultist
20722	crystal slugthrower
20723	brann s trusty pick
20724	corrupted blackwood staff
20725	nexus crystal
20726	formula enchant gloves threat
20727	formula enchant gloves shadow power
20728	formula enchant gloves frost power
20729	formula enchant gloves fire power
20730	formula enchant gloves healing power
20731	formula enchant gloves superior agility
20732	formula enchant cloak greater fire resistance
20733	formula enchant cloak greater nature resistance
20734	formula enchant cloak stealth
20735	formula enchant cloak subtlety
20736	formula enchant cloak dodge
20737	singed corestone
20741	deadwood ritual totem
20742	winterfall ritual totem
20744	minor wizard oil
20745	minor mana oil
20746	lesser wizard oil
20747	lesser mana oil
20748	brilliant mana oil
20749	brilliant wizard oil
20750	wizard oil
20752	formula minor mana oil
20753	formula lesser wizard oil
20754	formula lesser mana oil
20755	formula wizard oil
20756	formula brilliant wizard oil
20757	formula brilliant mana oil
20758	formula minor wizard oil
20761	recipe transmute elemental fire
20763	broken weapon
20766	slimy bag
20767	scum covered bag
20768	oozing bag
20769	disgusting oozeling
20770	bubbling green ichor
20800	cenarion logistics badge
20801	cenarion tactical badge
20802	cenarion combat badge
20803	twilight battle orders
20805	followup logistics assignment
20806	logistics task briefing x
20807	logistics task briefing i
20808	combat assignment
20809	tactical assignment
20810	signed field duty papers
20814	broken master s throwing dagger
20834	ornate spyglass xt
20844	deadly poison v
20858	stone scarab
20859	gold scarab
20860	silver scarab
20861	bronze scarab
20862	crystal scarab
20863	clay scarab
20864	bone scarab
20865	ivory scarab
20866	azure idol
20867	onyx idol
20868	lambent idol
20869	amber idol
20870	jasper idol
20871	obsidian idol
20872	vermillion idol
20873	alabaster idol
20874	idol of the sun
20875	idol of night
20876	idol of death
20877	idol of the sage
20878	idol of rebirth
20879	idol of life
20881	idol of strife
20882	idol of war
20883	qiraji glyphed jewel
20884	qiraji magisterial ring
20885	qiraji martial drape
20886	qiraji spiked hilt
20887	qiraji engraved jewel
20888	qiraji ceremonial ring
20889	qiraji regal drape
20890	qiraji ornate hilt
20908	festival of nian firework
20926	vek nilash s circlet
20927	ouro s intact hide
20928	qiraji bindings of command
20929	carapace of the old god
20930	vek lor s diadem
20931	skin of the great sandworm
20932	qiraji bindings of dominance
20933	husk of the old god
20936	qiraji blessed jewel
20937	qiraji encased jewel
20939	logistics task briefing ii
20940	logistics task briefing iii
20941	combat task briefing xii
20942	combat task briefing iii
20943	tactical task briefing x
20944	tactical task briefing ix
20945	tactical task briefing ii
20946	tactical task briefing iii
20947	tactical task briefing iv
20948	tactical task briefing v
20949	magical ledger
20951	narain s scrying goggles
21023	dirge s kickin chimaerok chops
21024	chimaerok tenderloin
21025	recipe dirge s kickin chimaerok chops
21027	lakmaeran s carcass
21029	ransom letter
21030	darnassus kimchi pie
21031	cabbage kimchi
21032	meridith s love letter
21033	radish kimchi
21037	crude map
21038	hardpacked snowball
21039	narain s turban
21040	narain s robe
21041	bag of gold
21042	narain s special kit
21043	mysterious envelope
21071	raw sagefish
21072	smoked sagefish
21099	recipe smoked sagefish
21100	coin of ancestry
21103	draconic for dummies
21104	draconic for dummies
21105	draconic for dummies
21106	draconic for dummies
21107	draconic for dummies
21108	draconic for dummies
21109	draconic for dummies
21110	draconic for dummies
21111	draconic for dummies volume ii
21112	magical book binding
21113	watertight trunk
21114	rumsey rum dark
21115	defiler s talisman
21116	defiler s talisman
21117	talisman of arathor
21118	talisman of arathor
21119	talisman of arathor
21120	defiler s talisman
21126	death s sting
21128	staff of the qiraji prophets
21130	diary of weavil
21131	followup combat assignment
21132	logistics assignment
21133	followup tactical assignment
21134	dark edge of insanity
21135	broken assassin s throwing axe
21136	arcanite buoy
21137	blue scepter shard
21138	red scepter shard
21139	green scepter shard
21140	auction stationery
21141	destroyed red scepter shard
21142	from the desk of lord victor nefarius
21143	unsigned field duty papers
21144	demon summoning torch
21145	essence of xandivious
21146	fragment of the nightmare s corruption
21147	fragment of the nightmare s corruption
21148	fragment of the nightmare s corruption
21149	fragment of the nightmare s corruption
21150	iron bound trunk
21151	rumsey rum black label
21152	the nightmare s corruption
21153	raw greater sagefish
21154	festival dress
21155	timbermaw offering of peace
21156	scarab bag
21157	festive green dress
21158	hive zora scout report
21159	hive zora scout orders
21160	hive regal scout report
21161	hive ashi scout report
21162	bloated oily blackmouth
21163	bloated firefin
21164	bloated rockscale cod
21165	tactical task briefing vi
21166	tactical task briefing vii
21167	tactical task briefing viii
21168	baby shark
21171	filled festive mug
21173	empty festive mug
21174	empty festive mug
21175	the scepter of the shifting sands
21176	black qiraji resonating crystal
21177	symbol of kings
21178	gloves of earthen power
21179	band of earthen wrath
21180	earthstrike
21181	grace of earth
21182	band of earthen might
21183	earthpower vest
21184	deeprock bracers
21185	earthcalm orb
21186	rockfury bracers
21187	earthweave cloak
21188	fist of cenarius
21189	might of cenarius
21190	wrath of cenarius
21191	carefully wrapped present
21193	d sak s sack
21194	d sak s big sack
21195	d sak s sacktastic
21196	signet ring of the bronze dragonflight
21197	signet ring of the bronze dragonflight
21198	signet ring of the bronze dragonflight
21199	signet ring of the bronze dragonflight
21200	signet ring of the bronze dragonflight
21201	signet ring of the bronze dragonflight
21202	signet ring of the bronze dragonflight
21203	signet ring of the bronze dragonflight
21204	signet ring of the bronze dragonflight
21205	signet ring of the bronze dragonflight
21206	signet ring of the bronze dragonflight
21207	signet ring of the bronze dragonflight
21208	signet ring of the bronze dragonflight
21209	signet ring of the bronze dragonflight
21210	signet ring of the bronze dragonflight
21211	pouch of reindeer dust
21212	fresh holly
21213	preserved holly
21214	tome of frostbolt xi
21215	graccu s mince meat fruitcake
21216	smokywood pastures extra special gift
21217	sagefish delight
21218	blue qiraji resonating crystal
21219	recipe sagefish delight
21220	head of ossirian the unscarred
21221	eye of c thun
21222	armored chitin
21223	black stone
21224	ancient armor fragment
21225	heavy silithid husk
21226	runic stone
21227	ancient hero s skull
21228	mithril bound trunk
21229	qiraji lord s insignia
21230	ancient qiraji artifact
21232	imperial qiraji armaments
21235	winter veil roast
21236	winter veil loaf
21237	imperial qiraji regalia
21240	winter veil candy
21241	winter veil eggnog
21242	blessed qiraji war axe
21243	bloated mightfish
21244	blessed qiraji pugio
21245	tactical task briefing i
21246	combat task briefing i
21247	combat task briefing ii
21248	combat task briefing iv
21249	combat task briefing v
21250	combat task briefing vi
21251	combat task briefing vii
21252	combat task briefing viii
21253	combat task briefing ix
21254	winter veil cookie
21255	combat task briefing x
21256	combat task briefing xi
21257	logistics task briefing iv
21258	logistics task briefing iv
21259	logistics task briefing v
21260	logistics task briefing vi
21261	logistics task briefing vi
21262	logistics task briefing viii
21263	logistics task briefing vii
21264	logistics task briefing vii
21265	logistics task briefing ix
21266	logistics assignment
21267	toasting goblet
21268	blessed qiraji war hammer
21269	blessed qiraji bulwark
21270	gently shaken gift
21271	gently shaken gift
21272	blessed qiraji musket
21273	blessed qiraji acolyte staff
21275	blessed qiraji augur staff
21277	tranquil mechanical yeti
21278	stormshroud gloves
21279	tome of fireball xii
21280	tome of arcane missiles viii
21281	grimoire of shadow bolt x
21282	grimoire of immolate viii
21283	grimoire of corruption vii
21284	codex of greater heal v
21285	codex of renew x
21287	codex of prayer of healing v
21288	libram blessing of wisdom vi
21289	libram blessing of might vii
21290	libram holy light ix
21291	tablet of healing wave x
21292	tablet of strength of earth totem v
21293	tablet of grace of air totem iii
21294	book of healing touch xi
21295	book of starfire vii
21296	book of rejuvenation xi
21297	manual of heroic strike ix
21298	manual of battle shout vii
21299	manual of revenge vi
21300	handbook of backstab ix
21301	green helper box
21302	handbook of deadly poison v
21303	handbook of feint v
21304	guide multi shot v
21305	red helper box
21306	guide serpent sting ix
21307	guide aspect of the hawk vii
21308	jingling bell
21309	snowman kit
21310	gaily wrapped present
21311	earth warder s vest
21312	belt of the den watcher
21313	d sak s small bag
21314	metzen s letters and notes
21315	smokywood satchel
21316	leggings of the ursa
21317	helm of the pathfinder
21318	earth warder s gloves
21319	gloves of the pathfinder
21320	vest of the den watcher
21321	red qiraji resonating crystal
21322	ursa s embrace
21323	green qiraji resonating crystal
21324	yellow qiraji resonating crystal
21325	mechanical greench
21326	defender of the timbermaw
21327	ticking present
21328	wand of holiday cheer
21329	conqueror s crown
21330	conqueror s spaulders
21331	conqueror s breastplate
21332	conqueror s legguards
21333	conqueror s greaves
21334	doomcaller s robes
21335	doomcaller s mantle
21336	doomcaller s trousers
21337	doomcaller s circlet
21338	doomcaller s footwraps
21340	soul pouch
21341	felcloth bag
21342	core felcloth bag
21343	enigma robes
21344	enigma boots
21345	enigma shoulderpads
21346	enigma leggings
21347	enigma circlet
21348	tiara of the oracle
21349	footwraps of the oracle
21350	mantle of the oracle
21351	vestments of the oracle
21352	trousers of the oracle
21353	genesis helm
21354	genesis shoulderpads
21355	genesis boots
21356	genesis trousers
21357	genesis vest
21358	pattern soul pouch
21359	deathdealer s boots
21360	deathdealer s helm
21361	deathdealer s spaulders
21362	deathdealer s leggings
21363	festive gift
21364	deathdealer s vest
21365	striker s footguards
21366	striker s diadem
21367	striker s pauldrons
21368	striker s leggings
21369	pattern felcloth bag
21370	striker s hauberk
21371	pattern core felcloth bag
21372	stormcaller s diadem
21373	stormcaller s footguards
21374	stormcaller s hauberk
21375	stormcaller s leggings
21376	stormcaller s pauldrons
21377	deadwood headdress feather
21378	logistics task briefing i
21379	logistics task briefing ii
21380	logistics task briefing iii
21381	logistics task briefing ix
21382	logistics task briefing v
21383	winterfall spirit beads
21384	logistics task briefing viii
21385	logistics task briefing x
21386	followup logistics assignment
21387	avenger s crown
21388	avenger s greaves
21389	avenger s breastplate
21390	avenger s legguards
21391	avenger s pauldrons
21392	sickle of unyielding strength
21393	signet of unyielding strength
21394	drape of unyielding strength
21395	blade of eternal justice
21396	ring of eternal justice
21397	cape of eternal justice
21398	hammer of the gathering storm
21399	ring of the gathering storm
21400	cloak of the gathering storm
21401	scythe of the unseen path
21402	signet of the unseen path
21403	cloak of the unseen path
21404	dagger of veiled shadows
21405	band of veiled shadows
21406	cloak of veiled shadows
21407	mace of unending life
21408	band of unending life
21409	cloak of unending life
21410	gavel of infinite wisdom
21411	ring of infinite wisdom
21412	shroud of infinite wisdom
21413	blade of vaulted secrets
21414	band of vaulted secrets
21415	drape of vaulted secrets
21416	kris of unspoken names
21417	ring of unspoken names
21418	shroud of unspoken names
21436	alliance commendation signet
21438	horde commendation signet
21452	staff of the ruins
21453	mantle of the horusath
21454	runic stone shoulders
21455	southwind helm
21456	sandstorm cloak
21457	bracers of brutality
21458	gauntlets of new life
21459	crossbow of imminent doom
21460	helm of domination
21461	leggings of the black blizzard
21462	gloves of dark wisdom
21463	ossirian s binding
21464	shackles of the unscarred
21466	stinger of ayamiss
21467	thick silithid chestguard
21468	mantle of maz nadir
21469	gauntlets of southwind
21470	cloak of the savior
21471	talon of furious concentration
21472	dustwind turban
21473	eye of moam
21474	chitinous shoulderguards
21475	legplates of the destroyer
21476	obsidian scaled leggings
21477	ring of fury
21478	bow of taut sinew
21479	gauntlets of the immovable
21480	scaled silithid gauntlets
21481	boots of the desert protector
21482	boots of the fiery sands
21483	ring of the desert winds
21484	helm of regrowth
21485	buru s skull fragment
21486	gloves of the swarm
21487	slimy scaled gauntlets
21488	fetish of chitinous spikes
21489	quicksand waders
21490	slime kickers
21491	scaled bracers of the gorger
21492	manslayer of the qiraji
21493	boots of the vanguard
21494	southwind s grasp
21495	legplates of the qiraji command
21496	bracers of qiraji command
21497	boots of the qiraji general
21498	qiraji sacrificial dagger
21499	vestments of the shifting sands
21500	belt of the inquisition
21501	toughened silithid hide gloves
21502	sand reaver wristguards
21503	belt of the sand reaver
21504	charm of the shifting sands
21505	choker of the shifting sands
21506	pendant of the shifting sands
21507	amulet of the shifting sands
21508	mark of cenarius
21509	ahn qiraj war effort supplies
21510	ahn qiraj war effort supplies
21511	ahn qiraj war effort supplies
21512	ahn qiraj war effort supplies
21513	ahn qiraj war effort supplies
21514	logistics task briefing xi
21515	mark of remulos
21517	gnomish turban of psychic might
21519	mistletoe
21520	ravencrest s legacy
21521	runesword of the red
21522	shadowsong s sorrow
21523	fang of korialstrasz
21524	red winter hat
21525	green winter hat
21526	band of icy depths
21527	darkwater robes
21528	colossal bag of loot
21529	amulet of shadow shielding
21530	onyx embedded leggings
21531	drake tooth necklace
21532	drudge boots
21533	colossus of zora s husk
21534	colossus of ashi s husk
21535	colossus of regal s husk
21536	elune stone
21537	festival dumplings
21538	festive pink dress
21539	festive purple dress
21540	elune s lantern
21541	festive black pant suit
21542	festival suit
21543	festive teal pant suit
21544	festive blue pant suit
21545	smokywood supplies
21546	elixir of greater firepower
21547	recipe elixir of greater firepower
21548	pattern stormshroud gloves
21552	striped yellowtail
21557	small red rocket
21558	small blue rocket
21559	small green rocket
21560	small purple rocket
21561	small white rocket
21562	small yellow rocket
21563	don rodrigo s band
21565	rune of perfection
21566	rune of perfection
21567	rune of duty
21568	rune of duty
21569	firework launcher
21570	cluster launcher
21571	blue rocket cluster
21574	green rocket cluster
21575	purple rocket cluster
21576	red rocket cluster
21577	white rocket cluster
21578	yellow rocket cluster
21579	vanquished tentacle of c thun
21581	gauntlets of annihilation
21582	grasp of the old god
21583	cloak of clarity
21585	dark storm gauntlets
21586	belt of never ending agony
21587	wristguards of castigation
21589	large blue rocket
21590	large green rocket
21591	large purple rocket
21592	large red rocket
21593	large white rocket
21595	large yellow rocket
21596	ring of the godslayer
21597	royal scepter of vek lor
21598	royal qiraji belt
21599	vek lor s gloves of devastation
21600	boots of epiphany
21601	ring of emperor vek lor
21602	qiraji execution bracers
21603	wand of qiraji nobility
21604	bracelets of royal redemption
21605	gloves of the hidden temple
21606	belt of the fallen emperor
21607	grasp of the fallen emperor
21608	amulet of vek nilash
21609	regenerating belt of vek nilash
21610	wormscale blocker
21611	burrower bracers
21615	don rigoberto s lost hat
21616	huhuran s stinger
21617	wasphide gauntlets
21618	hive defiler wristguards
21619	gloves of the messiah
21620	ring of the martyr
21621	cloak of the golden hive
21622	sharpened silithid femur
21623	gauntlets of the righteous champion
21624	gauntlets of kalimdor
21625	scarab brooch
21626	slime coated leggings
21627	cloak of untold secrets
21635	barb of the sand reaver
21639	pauldrons of the unrelenting
21640	lunar festival fireworks pack
21645	hive tunneler s boots
21647	fetish of the sand reaver
21648	recomposed boots
21650	ancient qiraji ripper
21651	scaled sand reaver leggings
21652	silithid carapace chestguard
21663	robes of the guardian saint
21664	barbed choker
21665	mantle of wicked revenge
21666	sartura s might
21667	legplates of blazing light
21668	scaled leggings of qiraji fury
21669	creeping vine helm
21670	badge of the swarmguard
21671	robes of the battleguard
21672	gloves of enforcement
21673	silithid claw
21674	gauntlets of steadfast determination
21675	thick qirajihide belt
21676	leggings of the festering swarm
21677	ring of the qiraji fury
21678	necklace of purity
21679	kalimdor s revenge
21680	vest of swift execution
21681	ring of the devoured
21682	bile covered gauntlets
21683	mantle of the desert crusade
21684	mantle of the desert s fury
21685	petrified scarab
21686	mantle of phrenic power
21687	ukko s ring of darkness
21688	boots of the fallen hero
21689	gloves of ebru
21690	angelista s charm
21691	ooze ridden gauntlets
21692	triad girdle
21693	guise of the devourer
21694	ternary mantle
21695	angelista s touch
21696	robes of the triumvirate
21697	cape of the trinity
21698	leggings of immersion
21699	barrage shoulders
21700	pendant of the qiraji guardian
21701	cloak of concentrated hatred
21702	amulet of foul warding
21703	hammer of ji zhi
21704	boots of the redeemed prophecy
21705	boots of the fallen prophet
21706	boots of the unwavering will
21707	ring of swarming thought
21708	beetle scaled wristguards
21709	ring of the fallen god
21710	cloak of the fallen god
21711	lunar festival invitation
21712	amulet of the fallen god
21713	elune s candle
21714	large blue rocket cluster
21715	sand polished hammer
21716	large green rocket cluster
21717	large purple rocket cluster
21718	large red rocket cluster
21719	large white rocket cluster
21720	large yellow rocket cluster
21721	moonglow
21722	pattern festival dress
21723	pattern festive red pant suit
21724	schematic small blue rocket
21725	schematic small green rocket
21726	schematic small red rocket
21727	schematic large blue rocket
21728	schematic large green rocket
21729	schematic large red rocket
21730	schematic blue rocket cluster
21731	schematic green rocket cluster
21732	schematic red rocket cluster
21733	schematic large blue rocket cluster
21734	schematic large green rocket cluster
21735	schematic large red rocket cluster
21736	nether drake reins
21737	schematic cluster launcher
21738	schematic firework launcher
21740	small rocket recipes
21741	cluster rocket recipes
21742	large rocket recipes
21743	large cluster rocket recipes
21744	lucky rocket cluster
21745	elder s moonstone
21746	lucky red envelope
21747	festival firecracker
21749	combat task briefing i
21750	combat task briefing ii
21751	tactical task briefing iii
21761	scarab coffer key
21762	greater scarab coffer key
21800	silithid husked launcher
21801	antenna of invigoration
21802	the lost kris of zedd
21803	helm of the holy avenger
21804	coif of elemental fury
21805	polished obsidian pauldrons
21806	gavel of qiraji authority
21809	fury of the forgotten swarm
21810	treads of the wandering nomad
21812	box of chocolates
21813	bag of candies
21814	breastplate of annihilation
21815	love token
21816	heart candy
21817	heart candy
21818	heart candy
21819	heart candy
21820	heart candy
21821	heart candy
21822	heart candy
21823	heart candy
21829	perfume bottle
21830	empty wrapper
21831	wrappered gift
21833	cologne bottle
21836	ritssyn s ring of chaos
21837	anubisath warhammer
21838	garb of royal ascension
21839	scepter of the false prophet
21856	neretzek the blood drinker
21888	gloves of the immortal
21889	gloves of the redeemed prophecy
21890	gloves of the fallen prophet
21891	shard of the fallen star
21920	creased letter
21921	carefully penned note
21925	immaculate letter
21926	slightly creased note
21928	winterspring blood sample
21935	stable ectoplasm
21936	frozen ectoplasm
21937	scorched ectoplasm
21938	magma core
21939	fel elemental rod
21946	ectoplasmic distiller
21960	handmade woodcraft
21975	pledge of adoration stormwind
21979	gift of adoration darnassus
21980	gift of adoration ironforge
21981	gift of adoration stormwind
21982	ogre warbeads
21983	incomplete banner of provocation
21984	left piece of lord valthalak s amulet
21985	sealed blood container
21986	banner of provocation
21987	incendicite of incendius
21988	ember of emberseer
21989	cinder of cynders
21994	belt of heroism
21995	boots of heroism
21996	bracers of heroism
21997	breastplate of heroism
21998	gauntlets of heroism
21999	helm of heroism
22000	legplates of heroism
22001	spaulders of heroism
22002	darkmantle belt
22003	darkmantle boots
22004	darkmantle bracers
22005	darkmantle cap
22006	darkmantle gloves
22007	darkmantle pants
22008	darkmantle spaulders
22009	darkmantle tunic
22010	beastmaster s belt
22011	beastmaster s bindings
22013	beastmaster s cap
22014	hallowed brazier
22015	beastmaster s gloves
22016	beastmaster s mantle
22017	beastmaster s pants
22046	right piece of lord valthalak s amulet
22047	top piece of lord valthalak s amulet
22048	lord valthalak s amulet
22049	brazier of beckoning
22050	brazier of beckoning
22051	brazier of beckoning
22052	brazier of beckoning
22056	brazier of beckoning
22057	brazier of invocation
22058	valentine s day stationery
22059	valentine s day card
22060	beastmaster s tunic
22061	beastmaster s boots
22062	sorcerer s belt
22063	sorcerer s bindings
22064	sorcerer s boots
22065	sorcerer s crown
22066	sorcerer s gloves
22067	sorcerer s leggings
22068	sorcerer s mantle
22069	sorcerer s robes
22070	deathmist belt
22071	deathmist bracers
22072	deathmist leggings
22073	deathmist mantle
22074	deathmist mask
22075	deathmist robe
22076	deathmist sandals
22077	deathmist wraps
22078	virtuous belt
22079	virtuous bracers
22080	virtuous crown
22081	virtuous gloves
22082	virtuous mantle
22083	virtuous robe
22084	virtuous sandals
22085	virtuous skirt
22086	soulforge belt
22087	soulforge boots
22088	soulforge bracers
22089	soulforge breastplate
22090	soulforge gauntlets
22091	soulforge helm
22092	soulforge legplates
22093	soulforge spaulders
22094	bloodkelp
22095	bindings of the five thunders
22096	boots of the five thunders
22097	coif of the five thunders
22098	cord of the five thunders
22099	gauntlets of the five thunders
22100	kilt of the five thunders
22101	pauldrons of the five thunders
22102	vest of the five thunders
22106	feralheart belt
22107	feralheart boots
22108	feralheart bracers
22109	feralheart cowl
22110	feralheart gloves
22111	feralheart kilt
22112	feralheart spaulders
22113	feralheart vest
22114	pink murloc egg
22115	extra dimensional ghost revealer
22117	pledge of loyalty stormwind
22119	pledge of loyalty ironforge
22120	pledge of loyalty darnassus
22121	pledge of loyalty undercity
22122	pledge of loyalty thunder bluff
22123	pledge of loyalty orgrimmar
22130	symbol of love
22131	stormwind gift collection
22132	ironforge gift collection
22133	darnassus gift collection
22134	undercity gift collection
22135	thunder bluff gift collection
22136	orgrimmar gift collection
22137	ysida s satchel
22138	blackrock bracer
22139	ysida s locket
22140	sentinel s card
22141	ironforge guard s card
22142	grunt s card
22143	stormwind guard s card
22144	bluffwatcher s card
22145	guardian s moldy card
22149	beads of ogre mojo
22150	beads of ogre might
22151	anthion s holy water
22152	anthion s pouch
22154	pledge of adoration ironforge
22155	pledge of adoration darnassus
22156	pledge of adoration orgrimmar
22157	pledge of adoration undercity
22158	pledge of adoration thunder bluff
22159	pledge of friendship darnassus
22160	pledge of friendship ironforge
22161	pledge of friendship orgrimmar
22162	pledge of friendship thunder bluff
22163	pledge of friendship undercity
22164	gift of adoration orgrimmar
22165	gift of adoration thunder bluff
22166	gift of adoration undercity
22167	gift of friendship darnassus
22168	gift of friendship ironforge
22169	gift of friendship orgrimmar
22170	gift of friendship stormwind
22171	gift of friendship thunder bluff
22172	gift of friendship undercity
22173	dwarven homebrew
22174	romantic poem
22175	freshly baked pie
22176	homemade bread
22177	freshly picked flowers
22178	pledge of friendship stormwind
22191	obsidian mail tunic
22192	bloodkelp elixir of dodging
22193	bloodkelp elixir of resistance
22194	black grasp of the destroyer
22195	light obsidian belt
22196	thick obsidian breastplate
22197	heavy obsidian belt
22198	jagged obsidian shield
22200	silver shafted arrow
22201	reliquary of purity
22202	small obsidian shard
22203	large obsidian shard
22204	wristguards of renown
22205	black steel bindings
22206	bouquet of red roses
22207	sash of the grand hunt
22208	lavastone hammer
22209	plans heavy obsidian belt
22212	golem fitted pauldrons
22214	plans light obsidian belt
22216	venoxis s venom sac
22217	kurinnaxx s venom sac
22218	handful of rose petals
22219	plans jagged obsidian shield
22220	plans black grasp of the destroyer
22221	plans obsidian mail tunic
22222	plans thick obsidian breastplate
22223	foreman s head protector
22224	jeering spectre s essence
22225	dragonskin cowl
22226	druidical remains
22227	starbreeze village relic
22228	brilliant sword of zealotry
22229	soul ashes of the banished
22231	kayser s boots of precision
22232	marksman s girdle
22233	zigris footlocker
22234	mantle of lost hope
22235	truesilver shafted arrow
22236	buttermilk delight
22237	dark desire
22238	very berry cream
22239	sweet surprise
22240	greaves of withering despair
22241	dark warder s pauldrons
22242	verek s leash
22243	small soul pouch
22244	box of souls
22245	soot encrusted footwear
22246	enchanted mageweave pouch
22247	faith healer s boots
22248	enchanted runecloth bag
22249	big bag of enchantment
22250	herb pouch
22251	cenarion herb bag
22252	satchel of cenarius
22253	tome of the lost
22254	wand of eternal light
22255	magma forged band
22256	mana shaping handwraps
22257	bloodclot band
22258	love potion
22259	unbestowed friendship bracelet
22260	friendship bracelet
22261	love fool
22262	alliance gift collection
22263	horde gift collection
22264	carefully written letter
22265	lovingly composed letter
22266	flarethorn
22267	spellweaver s turban
22268	draconic infused emblem
22269	shadow prowler s cloak
22270	entrenching boots
22271	leggings of frenzied magic
22272	forest s embrace
22274	grizzled pelt
22275	firemoss boots
22276	lovely red dress
22277	red dinner suit
22278	lovely blue dress
22279	lovely black dress
22280	lovely purple dress
22281	blue dinner suit
22282	purple dinner suit
22283	sack of homemade bread
22284	bundle of cards
22285	stormwind pledge collection
22286	ironforge pledge collection
22287	parcel of cards
22288	case of homebrew
22289	stack of cards
22290	darnassus pledge collection
22291	box of woodcrafts
22292	box of fresh pies
22293	package of cards
22294	orgrimmar pledge collection
22295	satchel of cards
22296	basket of flowers
22297	thunder bluff pledge collection
22298	book of romantic poems
22299	sheaf of cards
22300	undercity pledge collection
22301	ironweave robe
22302	ironweave cowl
22303	ironweave pants
22304	ironweave gloves
22305	ironweave mantle
22306	ironweave belt
22307	pattern enchanted mageweave pouch
22308	pattern enchanted runecloth bag
22309	pattern big bag of enchantment
22310	pattern cenarion herb bag
22311	ironweave boots
22312	pattern satchel of cenarius
22313	ironweave bracers
22314	huntsman s harpoon
22315	hammer of revitalization
22317	lefty s brass knuckle
22318	malgen s long bow
22319	tome of divine right
22320	mux s quality goods
22321	heart of wyrmthalak
22322	the jaw breaker
22324	winter kimchi
22325	belt of the trickster
22326	amalgam s band
22327	amulet of the redeemed
22328	legplates of vigilance
22329	scepter of interminable focus
22330	shroud of arcane mastery
22331	band of the steadfast hero
22332	blade of necromancy
22333	hammer of divine might
22334	band of mending
22335	lord valthalak s staff of command
22336	draconian aegis of the legion
22337	shroud of domination
22338	volcanic ash
22339	rune band of wizardry
22340	pendant of celerity
22342	leggings of torment
22343	handguards of savagery
22344	brazier of invocation user s manual
22345	totem of rebirth
22347	fahrad s reloading repeater
22348	doomulus prime
22349	desecrated breastplate
22350	desecrated tunic
22351	desecrated robe
22352	desecrated legplates
22353	desecrated helmet
22354	desecrated pauldrons
22355	desecrated bracers
22356	desecrated waistguard
22357	desecrated gauntlets
22358	desecrated sabatons
22359	desecrated legguards
22360	desecrated headpiece
22361	desecrated spaulders
22362	desecrated wristguards
22363	desecrated girdle
22364	desecrated handguards
22365	desecrated boots
22366	desecrated leggings
22367	desecrated circlet
22368	desecrated shoulderpads
22369	desecrated bindings
22370	desecrated belt
22371	desecrated gloves
22372	desecrated sandals
22373	wartorn leather scrap
22374	wartorn chain scrap
22375	wartorn plate scrap
22376	wartorn cloth scrap
22377	the thunderwood poker
22378	ravenholdt slicer
22379	shivsprocket s shiv
22380	simone s cultivating hammer
22381	silithus venom sample
22382	sealed venom container
22383	sageblade
22384	persuader
22385	titanic leggings
22386	head of instructor razuvious dep
22387	heart of anub rekhan
22388	plans titanic leggings
22389	plans sageblade
22390	plans persuader
22392	formula enchant 2h weapon agility
22393	codex prayer of shadow protection
22394	staff of metanoia
22395	totem of rage
22396	totem of life
22397	idol of ferocity
22398	idol of rejuvenation
22399	idol of health
22400	libram of truth
22401	libram of hope
22402	libram of grace
22403	diana s pearl necklace
22404	willey s back scratcher
22405	mantle of the scarlet crusade
22406	redemption
22407	helm of the new moon
22408	ritssyn s wand of bad mojo
22409	tunic of the crescent moon
22410	gauntlets of deftness
22411	helm of the executioner
22412	thuzadin mantle
22416	dreadnaught breastplate
22417	dreadnaught legplates
22418	dreadnaught helmet
22419	dreadnaught pauldrons
22420	dreadnaught sabatons
22421	dreadnaught gauntlets
22422	dreadnaught waistguard
22423	dreadnaught bracers
22424	redemption wristguards
22425	redemption tunic
22426	redemption handguards
22427	redemption legguards
22428	redemption headpiece
22429	redemption spaulders
22430	redemption boots
22431	redemption girdle
22432	devilsaur barb
22433	don mauricio s band of domination
22434	bloodcap
22435	gorishi sting
22436	cryptstalker tunic
22437	cryptstalker legguards
22438	cryptstalker headpiece
22439	cryptstalker spaulders
22440	cryptstalker boots
22441	cryptstalker handguards
22442	cryptstalker girdle
22443	cryptstalker wristguards
22444	putrid vine
22458	moonshadow stave
22464	earthshatter tunic
22465	earthshatter legguards
22466	earthshatter headpiece
22467	earthshatter spaulders
22468	earthshatter boots
22469	earthshatter handguards
22470	earthshatter girdle
22471	earthshatter wristguards
22472	boots of ferocity
22476	bonescythe breastplate
22477	bonescythe legplates
22478	bonescythe helmet
22479	bonescythe pauldrons
22480	bonescythe sabatons
22481	bonescythe gauntlets
22482	bonescythe waistguard
22483	bonescythe bracers
22484	necrotic rune
22488	dreamwalker tunic
22489	dreamwalker legguards
22490	dreamwalker headpiece
22491	dreamwalker spaulders
22492	dreamwalker boots
22493	dreamwalker handguards
22494	dreamwalker girdle
22495	dreamwalker wristguards
22496	frostfire robe
22497	frostfire leggings
22498	frostfire circlet
22499	frostfire shoulderpads
22500	frostfire sandals
22501	frostfire gloves
22502	frostfire belt
22503	frostfire bindings
22504	plagueheart robe
22505	plagueheart leggings
22506	plagueheart circlet
22507	plagueheart shoulderpads
22508	plagueheart sandals
22509	plagueheart gloves
22510	plagueheart belt
22511	plagueheart bindings
22512	robe of faith
22513	leggings of faith
22514	circlet of faith
22515	shoulderpads of faith
22516	sandals of faith
22517	gloves of faith
22518	belt of faith
22519	bindings of faith
22520	the phylactery of kel thuzad
22523	insignia of the dawn
22524	insignia of the crusade
22525	crypt fiend parts
22526	bone fragments
22527	core of elements
22528	dark iron scraps
22529	savage frond
22568	sealed craftsman s writ
22589	atiesh greatstaff of the guardian
22593	writ of safe passage
22595	call to arms announcement
22600	craftsman s writ dense weightstone
22601	craftsman s writ imperial plate chest
22602	craftsman s writ volcanic hammer
22603	craftsman s writ huge thorium battleaxe
22604	craftsman s writ radiant circlet
22605	craftsman s writ wicked leather headband
22606	craftsman s writ rugged armor kit
22607	craftsman s writ wicked leather belt
22608	craftsman s writ runic leather pants
22609	craftsman s writ brightcloth pants
22610	craftsman s writ runecloth boots
22611	craftsman s writ runecloth bag
22612	craftsman s writ runecloth robe
22613	craftsman s writ goblin sapper charge
22614	craftsman s writ thorium grenade
22615	craftsman s writ gnomish battle chicken
22616	craftsman s writ thorium tube
22617	craftsman s writ major mana potion
22618	craftsman s writ major healing potion
22619	craftsman s writ greater frost protection potion
22620	craftsman s writ greater arcane protection potion
22621	craftsman s writ flask of petrification
22622	craftsman s writ stonescale eel
22623	craftsman s writ plated armorfish
22624	craftsman s writ lightning eel
22625	craftsman s writ baked salmon
22626	craftsman s writ runn tum tuber surprise
22630	atiesh greatstaff of the guardian
22631	atiesh greatstaff of the guardian
22632	atiesh greatstaff of the guardian
22635	savage guard
22636	ice guard
22637	primal hakkari idol
22638	shadow guard
22648	hive ashi dossier
22649	hive regal dossier
22650	hive zora dossier
22651	outrider s plate legguards
22652	glacial vest
22654	glacial gloves
22655	glacial wrists
22656	the purifier
22657	amulet of the dawn
22658	glacial cloak
22659	medallion of the dawn
22660	gaea s embrace
22661	polar tunic
22662	polar gloves
22663	polar bracers
22664	icy scale breastplate
22665	icy scale bracers
22666	icy scale gauntlets
22667	bracers of hope
22668	bracers of subterfuge
22669	icebane breastplate
22670	icebane gauntlets
22671	icebane bracers
22672	sentinel s plate legguards
22673	outrider s chain leggings
22676	outrider s mail leggings
22678	talisman of ascendance
22679	supply bag
22680	band of resolution
22681	band of piety
22682	frozen rune
22683	pattern gaea s embrace
22684	pattern glacial gloves
22685	pattern glacial cloak
22686	pattern glacial vest
22687	pattern glacial wrists
22688	verimonde s last resort
22689	sanctified leather helm
22690	leggings of the plague hunter
22691	corrupted ashbringer
22692	pattern polar tunic
22694	pattern polar gloves
22695	pattern polar bracers
22696	pattern icy scale breastplate
22697	pattern icy scale gauntlets
22698	pattern icy scale bracers
22699	icebane leggings
22700	glacial leggings
22701	polar leggings
22702	icy scale leggings
22703	plans icebane breastplate
22704	plans icebane gauntlets
22705	plans icebane bracers
22707	ramaladni s icy grasp
22708	fate of ramaladni
22711	cloak of the hakkari worshipers
22712	might of the tribe
22713	zulian scepter of rites
22714	sacrificial gauntlets
22715	gloves of the tormented
22716	belt of untapped power
22718	blooddrenched mask
22719	omarion s handbook
22720	zulian headdress
22721	band of servitude
22722	seal of the gurubashi berserker
22723	a letter from the keeper of the rolls
22725	band of cenarius
22726	splinter of atiesh
22727	frame of atiesh
22728	steam tonk controller
22729	schematic steam tonk controller
22730	eyestalk waist cord
22731	cloak of the devoured
22732	mark of c thun
22733	staff head of atiesh
22734	base of atiesh
22736	andonisus reaper of souls
22737	atiesh greatstaff of the guardian
22739	tome of polymorph turtle
22740	outrider s leather pants
22741	outrider s lizardhide pants
22742	bloodsail shirt
22743	bloodsail sash
22744	bloodsail boots
22745	bloodsail pants
22746	buccaneer s uniform
22747	outrider s silk leggings
22748	sentinel s chain leggings
22749	sentinel s leather pants
22750	sentinel s lizardhide pants
22752	sentinel s silk leggings
22753	sentinel s lamellar legguards
22754	eternal quintessence
22756	sylvan vest
22757	sylvan crown
22758	sylvan shoulders
22759	bramblewood helm
22760	bramblewood boots
22761	bramblewood belt
22762	ironvine breastplate
22763	ironvine gloves
22764	ironvine belt
22765	mildewed letter
22766	plans ironvine breastplate
22767	plans ironvine gloves
22768	plans ironvine belt
22769	pattern bramblewood belt
22770	pattern bramblewood boots
22771	pattern bramblewood helm
22772	pattern sylvan shoulders
22773	pattern sylvan crown
22774	pattern sylvan vest
22780	white murloc egg
22781	polar bear collar
22798	might of menethil
22799	soulseeker
22800	brimstone staff
22801	spire of twilight
22802	kingsfall
22803	midnight haze
22804	maexxna s fang
22806	widow s remorse
22807	wraith blade
22808	the castigator
22809	maul of the redeemed crusader
22810	toxin injector
22811	soulstring
22812	nerubian slavemaker
22813	claymore of unholy might
22815	severance
22816	hatchet of sundered bone
22818	the plague bearer
22819	shield of condemnation
22820	wand of fates
22821	doomfinger
22822	icoke prize voucher
22843	blood guard s chain greaves
22852	blood guard s dragonhide treads
22855	blood guard s dreadweave walkers
22856	blood guard s leather walkers
22857	blood guard s mail greaves
22858	blood guard s plate greaves
22859	blood guard s satin walkers
22860	blood guard s silk walkers
22862	blood guard s chain vices
22863	blood guard s dragonhide grips
22864	blood guard s leather grips
22865	blood guard s dreadweave handwraps
22867	blood guard s mail vices
22868	blood guard s plate gauntlets
22869	blood guard s satin handwraps
22870	blood guard s silk handwraps
22872	legionnaire s plate hauberk
22873	legionnaire s plate leggings
22874	legionnaire s chain hauberk
22875	legionnaire s chain legguards
22876	legionnaire s mail hauberk
22877	legionnaire s dragonhide chestpiece
22878	legionnaire s dragonhide leggings
22879	legionnaire s leather chestpiece
22880	legionnaire s leather legguards
22881	legionnaire s dreadweave legguards
22882	legionnaire s satin legguards
22883	legionnaire s silk legguards
22884	legionnaire s dreadweave tunic
22885	legionnaire s satin tunic
22886	legionnaire s silk tunic
22887	legionnaire s mail legguards
22890	tome of frost ward v
22891	grimoire of shadow ward iv
22892	dim necrotic stone
22895	conjured cinnamon roll
22897	tome of conjure food vii
22930	a bloodstained envelope
22932	a torn letter
22935	touch of frost
22936	wristguards of vengeance
22937	gem of nerubis
22938	cryptfiend silk cloak
22939	band of unanswered prayers
22940	icebane pauldrons
22941	polar shoulder pads
22942	the widow s embrace
22943	malice stone pendant
22944	a crumpled missive
22945	a careworn note
22946	a ragged page
22947	pendant of forgotten names
22948	a smudged document
22949	cracked necrotic crystal
22950	faint necrotic crystal
22954	kiss of the spider
22960	cloak of suturing
22961	band of reanimation
22967	icy scale spaulders
22968	glacial mantle
22970	a bloodstained envelope
22972	a careworn note
22973	a crumpled missive
22974	a ragged page
22975	a smudged document
22977	a torn letter
22981	gluth s missing collar
22983	rime covered mantle
22988	the end of dreams
22994	digested hand of power
22999	tabard of the argent dawn
23000	plated abomination ribcage
23001	eye of diminution
23002	turtle box
23004	idol of longevity
23005	totem of flowing water
23006	libram of light
23007	piglet s collar
23008	sealed research report
23009	wand of the whispering dead
23010	sealed research report
23011	sealed research report
23012	sealed research report
23013	sealed research report
23014	iblis blade of the fallen seraph
23015	rat cage
23016	sealed research report
23017	veil of eclipse
23018	signet of the fallen defender
23019	icebane helmet
23020	polar helmet
23021	the soul harvester s bindings
23022	curmudgeon s payoff
23023	sadist s collar
23024	prepared field duty papers
23025	seal of the damned
23027	warmth of forgiveness
23028	hailstone band
23029	noth s frigid heart
23030	cloak of the scourge
23031	band of the inevitable
23032	glacial headdress
23033	icy scale coif
23035	preceptor s hat
23036	necklace of necropsy
23037	ring of spiritual fervor
23038	band of unnatural forces
23039	the eye of nerub
23040	glyph of deflection
23041	slayer s crest
23042	loatheb s reflection
23043	the face of death
23044	harbinger of doom
23045	shroud of dominion
23046	the restrained essence of sapphiron
23047	eye of the dead
23048	sapphiron s right eye
23049	sapphiron s left eye
23050	cloak of the necropolis
23051	glaive of the defender
23053	stormrage s talisman of seething
23054	gressil dawn of ruin
23055	word of thawing
23056	hammer of the twisting nether
23057	gem of trapped innocents
23059	ring of the dreadnaught
23060	bonescythe ring
23061	ring of faith
23062	frostfire ring
23063	plagueheart ring
23064	ring of the dreamwalker
23065	ring of the earthshatterer
23066	ring of redemption
23067	ring of the cryptstalker
23068	legplates of carnage
23069	necro knight s garb
23070	leggings of polarity
23071	leggings of apocalypse
23072	fists of the unrelenting
23073	boots of displacement
23075	death s bargain
23078	gauntlets of undead slaying
23081	handwraps of undead slaying
23082	handguards of undead slaying
23083	captured flame
23084	gloves of undead cleansing
23085	robe of undead cleansing
23087	breastplate of undead slaying
23088	chestguard of undead slaying
23089	tunic of undead slaying
23090	bracers of undead slaying
23091	bracers of undead cleansing
23092	wristguards of undead slaying
23093	wristwraps of undead slaying
23122	consecrated sharpening stone
23123	blessed wizard oil
23124	staff of balzaphon
23125	chains of the lich
23126	waistband of balzaphon
23127	cloak of revanchion
23128	the shadow s grasp
23129	bracers of mending
23132	lord blackwood s blade
23139	lord blackwood s buckler
23156	blackwood s thigh
23160	friendship bread
23161	freshly squeezed lemonade
23163	performer s wand
23164	bubbly beverage
23168	scorn s focal dagger
23169	scorn s icy choker
23170	the frozen clutch
23171	the axe of severing
23172	refreshing red apple
23173	abomination skin leggings
23175	tasty summer treat
23176	fizzy energy drink
23177	lady falther ess finger
23178	mantle of lady falther ess
23179	flame of orgrimmar
23180	flame of thunder bluff
23181	flame of the undercity
23182	flame of stormwind
23183	flame of ironforge
23184	flame of darnassus
23192	tabard of the scarlet crusade
23193	naxxramas deathcharger reins
23194	lesser mark of the dawn
23195	mark of the dawn
23196	greater mark of the dawn
23197	idol of the moon
23198	idol of brutality
23199	totem of the storm
23200	totem of sustaining
23201	libram of divinity
23203	libram of fervor
23206	mark of the champion
23207	mark of the champion
23211	toasted smorc
23215	bag of smorc ingredients
23219	girdle of the mentor
23220	crystal webbed robe
23221	misplaced servo arm
23224	summer gift package
23226	ghoul skin tunic
23227	icoke gift box voucher
23237	ring of the eternal flame
23238	stygian buckler
23242	claw of the frost wyrm
23243	champion s plate shoulders
23244	champion s plate helm
23246	fiery festival brew
23247	burning blossom
23250	prismatic shell
23251	champion s chain helm
23252	champion s chain shoulders
23253	champion s dragonhide headguard
23254	champion s dragonhide shoulders
23255	champion s dreadweave cowl
23256	champion s dreadweave spaulders
23257	champion s leather helm
23258	champion s leather shoulders
23259	champion s mail headguard
23260	champion s mail pauldrons
23261	champion s satin hood
23262	champion s satin mantle
23263	champion s silk cowl
23264	champion s silk mantle
23272	knight captain s lamellar breastplate
23273	knight captain s lamellar leggings
23274	knight lieutenant s lamellar gauntlets
23275	knight lieutenant s lamellar sabatons
23276	lieutenant commander s lamellar headguard
23277	lieutenant commander s lamellar shoulders
23278	knight lieutenant s chain greaves
23279	knight lieutenant s chain vices
23280	knight lieutenant s dragonhide grips
23281	knight lieutenant s dragonhide treads
23282	knight lieutenant s dreadweave handwraps
23283	knight lieutenant s dreadweave walkers
23284	knight lieutenant s leather grips
23285	knight lieutenant s leather walkers
23286	knight lieutenant s plate gauntlets
23287	knight lieutenant s plate greaves
23288	knight lieutenant s satin handwraps
23289	knight lieutenant s satin walkers
23290	knight lieutenant s silk handwraps
23291	knight lieutenant s silk walkers
23292	knight captain s chain hauberk
23293	knight captain s chain legguards
23294	knight captain s dragonhide chestpiece
23295	knight captain s dragonhide leggings
23296	knight captain s dreadweave legguards
23297	knight captain s dreadweave tunic
23298	knight captain s leather chestpiece
23299	knight captain s leather legguards
23300	knight captain s plate hauberk
23301	knight captain s plate leggings
23302	knight captain s satin legguards
23303	knight captain s satin tunic
23304	knight captain s silk legguards
23305	knight captain s silk tunic
23306	lieutenant commander s chain helm
23307	lieutenant commander s chain shoulders
23308	lieutenant commander s dragonhide headguard
23309	lieutenant commander s dragonhide shoulders
23310	lieutenant commander s dreadweave cowl
23311	lieutenant commander s dreadweave spaulders
23312	lieutenant commander s leather helm
23313	lieutenant commander s leather shoulders
23314	lieutenant commander s plate helm
23315	lieutenant commander s plate shoulders
23316	lieutenant commander s satin hood
23317	lieutenant commander s satin mantle
23318	lieutenant commander s silk cowl
23319	lieutenant commander s silk mantle
23320	tablet of flame shock vi
23323	crown of the fire festival
23324	mantle of the fire festival
23326	midsummer sausage
23327	fire toasted bun
23360	head of instructor razuvious
23379	cinder bracers
23435	elderberry pie
23451	grand marshal s mageblade
23452	grand marshal s tome of power
23453	grand marshal s tome of restoration
23454	grand marshal s warhammer
23455	grand marshal s demolisher
23456	grand marshal s swiftblade
23464	high warlord s battle mace
23465	high warlord s destroyer
23466	high warlord s spellblade
23467	high warlord s quickblade
23468	high warlord s tome of destruction
23469	high warlord s tome of mending
23545	power of the scourge
23547	resilience of the scourge
23548	might of the scourge
23549	fortitude of the scourge
23557	larvae of the great worm
23558	the burrower s shell
23570	jom gabbar
23577	the hungering cold
23578	diet mcweaksauce
23579	the mcweaksauce classic
23663	girdle of elemental fury
23664	pauldrons of elemental fury
23665	leggings of elemental fury
23666	belt of the grand crusader
23667	spaulders of the grand crusader
23668	leggings of the grand crusader
23705	tabard of flame
23709	tabard of frost
23710	upperdeck tabard #3
23712	white tiger cub
23713	hippogryph hatchling
23714	perpetual purple firework
23715	permanent lung juice cocktail
23716	carved ogre idol
23718	permanent ground scorpok assay
23719	permanent cerebral cortex compound
23720	riding turtle
23721	permanent gizzard gum
23722	permanent r o i d s
23794	permanent sheen of zanza
23795	permanent spirit of zanza
23796	permanent swiftness of zanza
24101	book of ferocious bite v
24102	manual of eviscerate ix
24222	the shadowfoot stabber
24231	coarse snuff
24232	shabby knot
24281	carved ivory bone
24282	rogue s diary
24283	an antique gun
]==]
