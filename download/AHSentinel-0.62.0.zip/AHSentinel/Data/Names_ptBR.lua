-- AHSentinel - Item-Namen (ptBR), 22731 Items
-- Quelle: siehe Data/QUELLEN.txt. Automatisch erzeugt, nicht von Hand ändern.
AHAnalyzerPro_NameData = AHAnalyzerPro_NameData or {}
AHAnalyzerPro_NameData["ptBR"] = [==[

25	Espadim Usado
35	Cajado Curvado
36	Maça Gasta
37	Machado Usado
38	Camisa do Recruta
39	Calças do Recruta
40	Botas do Recruta
43	Botas do Escudeiro
44	Calças do Escudeiro
45	Camisa do Escudeiro
47	Sapatos do Salteador
48	Calças do Salteador
49	Camisa do Salteador
51	Botas do Neófito
52	Calças do Neófito
53	Camisa do Neófito
55	Botas do Aprendiz
56	Veste do Aprendiz
57	Veste do Acólito
59	Sapatos do Acólito
60	Túnica em Camadas
61	Calças de Couro Enânicas
79	Culotes Enânicos de Tecido
80	Sapatos Forrados de Pelame Macios
85	Colete de Couro Sujo
117	Carne-seca Dura
118	Poção Menor de Cura
120	Calças do Capanga
121	Botas do Meliante
127	Camisa do Coureador
129	Botas Rústicas do Coureador
139	Calças do Brigão
140	Botas do Brigão
147	Calças Grosseiras do Coureador
148	Camisa Grosseira do Coureador
153	Kilt Primitivo
154	Poncho Primitivo
159	Água Refrescante da Fonte
182	Cabeça do Garrick
193	Colete de Tecido Esfarrapado
194	Calças de Tecido Esfarrapado
195	Botas de Tecido Esfarrapado
200	Colete de Tecido Grosso
201	Calças de Tecido Grosso
202	Sapatos de Tecido Grosso
203	Luvas de Tecido Grosso
209	Calças de Couro Sujas
210	Botas de Couro Sujas
236	Armadura de Couro Curado
237	Calças de Couro Curado
238	Botas de Couro Curado
239	Luvas de Couro Curado
285	Colete de Malha em Escamas
286	Calças de Malha em Escamas
287	Botas de Malha em Escamas
414	Queijo Azedo de Dalaran
422	Queijo Enânico Suave
537	Escama Cega de Farnesim
555	Penas Ásperas de Abutre
556	Bico de Urubu
647	Destino
710	Braçadeiras da Milícia do Povo
711	Luvas de Tecido Esfarrapado
714	Luvas de Couro Sujas
718	Luvas de Malha em Escamas
719	Luvas do Tratador de Coelhos
720	Luvas do Brigão
723	Fígado de Goretusco
724	Empadão de Fígado de Goretusco
725	Pata de Gnoll
727	Espada Curta Chanfrada
728	Receita: Ensopado de Cerro Oeste
729	Acém de Abutre
730	Olho de Murloc
731	Focinho de Goretusco
732	Quiabo
733	Ensopado de Cerro Oeste
735	Medalhões de Rodolfo e Malaquias
737	Água da Fonte Abençoada
738	Saco de Cevada
739	Saco de Milho
740	Saco de Centeio
742	Um Galho de Plátano
743	Braçada de Carvalho Calcinado
744	Frasco de Bota do Cervaforte
745	Documentos do Major Belmonte
748	Vale-armadura de Ventobravo
750	Carne Dura de Lobo
752	Bandana de Lona Vermelha
753	Espada Curta Presa do Dragão
754	Espada Curta da Vingança
755	Vela Derretida
756	Picareta de Túnel
763	Braçadeiras Cobertas de Gelo
765	Folha-prata
766	Maça Bordejada
767	Cajado Bô Longo
768	Machado de Lenhador
769	Naco de Carne de Javali
770	Dente Pontudo de Crocolisco
771	Presa Lascada de Javali
772	Vela Grande
773	Pó de Ouro
774	Malaquita
776	Vendeta
777	Dentes de Lobo Tocaieiro
778	Picareta de Escavação Kobold
779	Concha Brilhante
780	Barbatana Rasgada de Murloc
781	Martelo de Pedra dos Gnolls
782	Braçadeiras Pintadas dos Gnolls
783	Pelego Leve
785	Magi-real
787	Cavala Deslizapele
789	Martelo de Batalha Corpulento
790	Machado do Mateiro
791	Cajado Fraxíneo Nodoso
792	Sandálias Tricotadas
793	Luvas Tricotadas
794	Calças Tricotadas
795	Túnica Tricotada
796	Botas de Couro Áspero
797	Luvas de Couro Áspero
798	Calças de Couro Grosseiro
799	Vestimenta de Couro Áspero
804	Saco Azul Grande
805	Bolsa Vermelha Pequena
809	Navalha Sangrenta
810	Martelo do Vento do Norte
811	Machado das Matas Profundas
812	Cajado Faiscante do Bosque Brilhante
813	Engrenagem Quebrada
814	Frasco de Óleo
816	Faquinha de Combate
818	Olho-de-tigre
820	Lâmina Fatiadora
821	Colete de Couro dos Pata Molhada
826	Machado Embrutecido dos Pata Molhada
827	Cassetete Malvado
828	Bolsa Azul Pequena
829	Bandana Vermelha de Couro
832	Cinto Prateado dos Défias
833	Pedra Vital
835	Rede Grande de Corda
837	Armadura de Trama Pesada
838	Calças de Trama Pesada
839	Luvas de Trama Pesada
840	Sapatos de Trama Pesada
841	Relógio de Bolso do Taturana
843	Botas de Couro Curtido
844	Luvas de Couro Curtido
845	Calças de Couro Curtido
846	Gibão de Couro Curtido
847	Armadura de Malha de Anéis
848	Calças de Malha de Anéis
849	Botas de Malha de Anéis
850	Luvas de Malha de Anéis
851	Alfanje
852	Maça
853	Machadinha
854	Cajado de Combate
856	Bolsa de Couro Azul
857	Saco Vermelho Grande
858	Poção Inferior de Cura
859	Camisa de Tecido de Qualidade
860	Botas do Fidalgo
862	Anel Rúnico
863	Semeia-pranto
864	Espada Longa Cavaleiresca
865	Maça de Chumbo
866	Cajado do Monge
867	Luvas do Poder Sagrado
868	Protetor Ardente
869	Espada Longa Ofuscante
870	Machado de Guerra Abrasador
871	Machado de Rajadas
872	Corta-pedra
873	Cajado de Jardel
875	Evocação de Cavalo Castanho
876	Broquel de Madeira Usado
878	Fiandeira do Tamanho da Mão
880	Cajado dos Horrores
884	Costela de Carniçal
885	Machado de Metal Preto
886	Espada Curta de Metal Preto
887	Quilo de Carne
888	Luvas Nagas de Batalha
889	Carta Não Enviada e Empoeirada
890	Cajado do Chantre Retorcido
892	Luvas Místicas de Gnoll
893	Presa de Lobo Hediondo
895	Crânio de Worgen
896	Presa de Worgen
897	Braçadeiras do Lobo Enfurecido
899	Presa de Teia Peçonhenta
901	Deptecated White Stallion Summoning (Mount)
910	Carta Não Entregue
911	Galho de Pau-ferro
913	Espada Ogra Enorme
914	Armadura Ogra Grande Encadeada
915	Bandana de Seda Vermelha
916	Página de Diário Rasgada
918	Mochila de Pelego Anormal
920	Maça Farpada Perversa
921	Página de Diário Esmaecida
922	Falx Dácia
923	Espada Longa
924	Malho
925	Mangual
926	Machado de Batalha
927	Machado Duplo
928	Cajado Longo
929	Poção de Cura
932	Alforje do Corcel Vil
933	Mochilão de Amarrar
934	Foice do Galvão
935	Espada Curta da Vigília Noturna
936	Maça da Meia-noite
937	Cajado Preto de Madeirumbra
938	Páginas de Diário Enlameadas
939	Página de Diário Manchada de Sangue
940	Vestes da Perspicácia
942	Elo Congelante
943	Cajado Guardião
944	Cajado Elemental do Mago
945	Espada Sombria
948	Espada da Natureza
954	Pergaminho de Força
955	Pergaminho do Intelecto
957	Carregamento do Guilherme
961	Erva Curativa
962	Torta de Barriga de Porco
966	Tomo do Escudo Gélido
967	Tomo de Proteção contra Gelo
968	Tomo de Impacto de Fogo
973	Tomo de Bola de Fogo II
974	Tomo de Armadura Gélida II
975	Tomo de Correntes de Gelo
976	Tomo de Remover Maldição
980	Tomo do Escudo Gélido II
981	Colar de Berenice
983	Faixa de Linho Vermelho
985	Tomo de Destravamento de Hadggar
986	Tomo de Seta de Gelo II
989	Tomo de Nova Congelante
992	Tomo de Bola de Fogo III
994	Tomo de Armadura de Gelo
997	Espada de Fogo Debilitante
1002	Tomo Inferior de Invisibilidade
1004	Tomo de Correntes de Gelo II
1006	Colar de Latão
1008	Espada Muito Usada
1009	Martelo Compacto
1010	Cajado Curto Nodoso
1011	Machado Afiado
1013	Rebite de Ferro
1015	Lombo de Lobo Magro
1017	Kebab Temperado de Lobo
1019	Bandana de Linho Vermelha
1029	Tabuleta de Totem Serpente
1030	Tabuleta da Vontade Obstinada
1031	Tabuleta de Impacto Derretido
1032	Tabuleta de Totem Agitador
1033	Tabuleta de Anular Veneno
1034	Tabuleta da Força Imortal
1035	Tabuleta de Invocar Espírito
1036	Tabuleta de Anular Doença
1037	Tabuleta de Raio II
1038	Tabuleta de Restauração II
1041	Trompa do Lobo Preto
1048	Tabuleta de Escudo de Raios II
1049	Tabuleta de Expurgar
1052	Tabuleta de Armadura Espiritual II
1053	Tabuleta de Impacto Derretido II
1057	Tabuleta de Restauração III
1058	Tabuleta de Raio III
1061	Tabuleta de Anular Veneno II
1063	Tabuleta de Anular Doença II
1072	Pinga Cara Cheia
1074	Ponta Dura de Perna de Aranha
1075	Pingente Umbrapele
1076	Anel de Renegado Défias
1077	Anel de Mago Défias
1080	Carne Dura de Condor
1081	Carne Crocante de Aranha
1082	Gulache de Cristarrubra
1083	Glifo de Azora
1084	Códice de Renovar
1085	Códice de Visão da Mente
1086	Códice de Fogo Interior
1087	Códice de Palavra Sombria: Dor
1088	Códice de Renovar II
1089	Códice de Anular Doença
1090	Códice de Ressurreição
1091	Códice de Punição Sagrada II
1092	Códice de Cura Inferior II
1093	Códice de Remover Maldição
1095	Códice de Dissipar Magia
1096	Códice de Palavra Sombria: Dor II
1100	Códice de Punição Sagrada III
1101	Códice de Renovar V
1102	Códice de Cura Inferior III
1105	Códice de Renovar VI
1108	Códice de Renovar III
1109	Códice de Dominar
1111	Códice de Sono
1112	Códice de Palavra Sagrada: Fortitude II
1113	Pão Conjurado
1114	Pão de Centeio Conjurado
1116	Anel de Prata Pura
1119	Garrafa de Destilado
1121	Pés do Lince
1127	Saco de Chamas
1129	Presa de Carniçal
1130	Ampola de Peçonha de Aranha
1131	Totem do Castigo
1132	Trompa do Lobo Silvestre
1133	Trompa do Lobo Hibernal
1134	Trompa do Lobo Cinza
1136	Incunábulo: Favorecimento Divino II
1138	Incunábulo: Favorecimento Divino
1139	Incunábulo: Purificação
1141	Incunábulo: Luz Sagrada II
1144	Incunábulo: Escudo Divino
1146	Incunábulo: Ressurreição
1149	Incunábulo: Selo do Poder II
1150	Incunábulo: Purificar
1151	Incunábulo: Luz Sagrada III
1154	Cinto da Milícia do Povo
1155	Bastão do Sonâmbulo
1156	Anel Carregado de Gemas
1158	Porrete de Metal Maciço
1159	Cajado de Milícia
1161	Espada Curta de Milícia
1164	Tomo de Sam
1166	Broquel Amassado
1167	Tarja Pequena
1168	Escudo do Crânio Flamejante
1169	Escudo Cranionegro
1171	Veste Bem-costurada
1172	Tocha do Calvino
1173	Botas Gastas
1175	Um Dente de Ouro
1176	Sais Aromáticos
1177	Óleo de Olaf
1178	Foguete Explosivo
1179	Leite Gelado
1180	Pergaminho do Vigor
1181	Pergaminho do Espírito
1182	Braçadeiras com Cravos de Latão
1183	Munhequeiras Elásticas
1187	Coleira Farpada
1189	Anel do Feitor
1190	Manto do Feitor
1191	Saco de Bolas de Gude
1193	Broquel Estriado
1194	Espada Bastarda
1195	Pá de Mineração Kobold
1196	Tabar
1197	Maça Gigante
1198	Espadão
1199	Pedra da Alma Carregada
1200	Escudo Grande de Madeira
1201	Escudo Brasonado Simples
1202	Muralha de Proteção
1203	Égide de Ventobravo
1204	A Torre Verde
1205	Suco de Melão
1206	Ágata Musgosa
1207	Maça Massa
1208	Carta de Amor de Mabel
1210	Tenebrita
1211	Arnês Gnoll de Guerra
1212	Saliva de Gnoll
1213	Braçadeiras Gnoll Gêmeas
1214	Castigador Gnoll
1215	Cinturão de Suporte
1216	Braçadeiras Gélidas
1217	Recompensa Desconhecida
1218	Clava de Guerra Gnoll Pesada
1219	Facão de Cristarrubra
1220	Machado Lupino
1221	Escama de Ventre de Dragonete
1222	Dente Quebrado
1224	Grimório de Detectar Demônios
1228	Grimório de Sangue Fervente
1229	Grimório de Criar Pedra da Alma
1231	Grimório de Seta Sombria II
1232	Grimório de Pele de Demônio II
1238	Grimório de Medo
1239	Grimório de Sugar Mana
1243	Grimório de Seta Sombria III
1244	Grimório de Armadura Demoníaca
1245	Grimório de Imolação II
1246	Grimório de Bafo Demoníaco
1250	Grimório de Detectar Invisibilidade Inferior
1251	Bandagem de Linho
1252	Bilhete da Vó Campedra
1254	Pedra de Fogo Inferior
1256	Folha de Cristalga
1257	Elixir de Invisibilidade
1259	JYoo test item
1260	Cabeça do Tharil'zun
1261	Orbe da Meia-noite
1262	Barrilete de Cervaforte
1263	Talha-mentes
1264	Afunda-cucas
1265	Picada do Escorpião
1270	Manto Finamente Tecido
1273	Corrente Florestal
1274	Lúpulo
1275	Cota Encadeada do Adjunto
1276	Broquel Endurecido pelo Fogo
1280	Manto com Capuz
1282	Coifa Brilho Metálico
1283	Bilhete de Vervo
1284	Caixote de Ferraduras
1287	Presa de Tarântula Gigante
1288	Vesícula de Peçonha Grande
1292	Cutelo do Açougueiro
1293	A Situação de Lago Plácido
1294	A Resposta do General
1296	Maça de Rocha Negra
1297	Vestes do Lança-sombras
1299	Cinto Inferior da Torre
1300	Cajado Inferior da Torre
1302	Luvas de Dragonete Negro
1303	Luvas de Operário da Ponte
1304	Luvas de Montaria
1306	Munhequeiras Lupogrenha
1307	Agenda de Coleta de Ouro
1309	Caixa de Ferramentas do Oslow
1310	Calças de Ferreiro
1314	Dedos de Carniçal
1315	Colar de Lírios
1317	Cajado de Raiz Densa
1318	Aniquilador Noturno
1319	Anel de Vontade Férrea
1322	Óleo de Fígado de Peixe
1325	Buquê de Narcisos
1326	Peixe-lua Refogado
1327	Bilhete do Wiley
1328	Livro de Fogo Feérico
1332	Livro de Curar Veneno
1334	Livro de Rejuvenescimento II
1339	Livro de Raízes Enredantes
1341	Livro de Fogo Lunar
1349	Caixote do Abercrombie
1351	Braçadeiras Osso-de-dedo
1352	Morteiro do Crânio Partido
1353	Relatório do Shaw
1355	Capa de Camurça
1356	Comenda – Floresta de Elwynn
1357	Mapa do Tesouro do Capitão Albernaz
1358	Pista para o Tesouro do Albernaz
1359	Luvas com Selo Leonino
1360	Luvas Encadeadas de Ventobravo
1361	Outra Pista para o Tesouro do Albernaz
1362	Pista Final para o Tesouro do Albernaz
1364	Colete de Couro Roto
1366	Calças de Couro Roto
1367	Botas de Couro Roto
1368	Luvas de Couro Roto
1369	Cinto de Couro Roto
1370	Braçadeiras de Couro Roto
1372	Manto Roto
1374	Sapatos Puídos
1376	Manto Puído
1377	Luvas Puídas
1378	Calças Puídas
1380	Veste Puída
1381	Uma Mensagem Misteriosa
1382	Maça de Rocha
1383	Machadinha Aborígene
1384	Lâmina Cega
1386	Machado de Pau-cardo
1387	Presa de Carniçal
1388	Cajado Torto
1389	Marreta de Mineração Kobold
1391	Cajado de Místico Pata Molhada
1394	Clava de Madeira Flutuante
1395	Calças do Aprendiz
1396	Calças do Acólito
1399	Vela Mágica
1400	Ficha de Penaveloz
1401	Folha de Chá Verde
1402	Súlfur
1404	Patuá das Marés
1405	Cajado Cospe-espuma
1406	Lança Incrustada de Pérolas
1407	Apelo de Salomão a Cerro Oeste
1408	Resposta de Mantoforte a Salomão
1409	Apelo de Salomão a Vila Sombria
1410	Resposta de Ebonlocke a Salomão
1411	Cajado Ressequido
1412	Espada Bastarda Grosseira
1413	Espada Débil
1414	Marreta Rachada
1415	Marreta de Carpinteiro
1416	Machadinha Enferrujada
1417	Machado de Batalha Gasto
1418	Cinto de Couro Desgastado
1419	Botas de Couro Desgastado
1420	Braçadeiras de Couro Desgastado
1421	Manto de Pelego Desgastado
1422	Luvas de Couro Desgastado
1423	Calças de Couro Desgastado
1425	Colete de Couro Desgastado
1427	Sapatos de Retalhos
1429	Manto de Retalhos
1430	Luvas de Retalhos
1431	Calças de Retalhos
1433	Armadura de Retalhos
1434	Palito de Cera Faiscante
1436	Culotes da Fronteira
1438	Escudo do Guerreiro
1440	Esmaga-crânio Gnoll
1443	Amuleto Incrustado de Cainwyn
1445	Brafoneiras de Rocha Negra
1446	Botas de Rocha Negra
1447	Anel dos Salvadores
1448	Manoplas de Rocha Negra
1449	Anel de Canalização Menor
1450	Poção de Fervor
1451	Garrafa de Suco de Zumbi
1453	Pente Espectral
1454	Machado do Impositor
1455	Machado do Campeão de Rocha Negra
1457	Maça Umbrapele
1458	Malho Umbrapele
1459	Escalpelador Umbrapele
1460	Espada de Duas Mãos Umbrapele
1461	Machado de Batalha do Matador
1462	Anel das Sombras
1464	Garra de Urubu
1465	Tigrazar
1467	Peixe-lua Malhado
1468	Barbatana de Murloc
1469	Cimitarra de Aton
1470	Bolsa de Pele de Murloc
1473	Cajado da Ribeira
1475	Vesícula Pequena de Peçonha
1476	Perna Quebrada de Aranha
1477	Pergaminho de Agilidade II
1478	Pergaminho de Proteção II
1479	Luvas Térmicas da Salma
1480	Punho da Milícia do Povo
1481	Garratroz
1482	Presa Negra
1483	Catxau
1484	Báculo de Bruxaria
1485	Forcado
1486	Jaqueta de Casca de Árvore
1487	Pão Preto Conjurado
1488	Armadura do Vingador
1489	Armadura Tristevéu
1490	Talismã do Guardião
1491	Anel da Precisão
1493	Cimitarra Espoliadora Pesada
1495	Sapatos de Calico
1497	Manto de Calico
1498	Luvas de Calico
1499	Calças de Calico
1501	Túnica de Calico
1502	Cinto de Couro Deformado
1503	Botas de Couro Deformado
1504	Braçadeiras de Couro Deformado
1505	Manto Deformado
1506	Luvas de Couro Deformado
1507	Calças de Couro Deformado
1509	Colete de Couro Deformado
1510	Martelo Pesado
1511	Espada do Plebeu
1512	Machado de Batalha Grosseiro
1513	Montante Velha
1514	Martelo de Guerra Enferrujado
1515	Cajado Rústico de Madeira
1516	Machadinha Desgastada
1518	Pente de Fantasma
1519	Orelha de Sanguescalpo
1520	Suor de Troll
1521	Machado de Lenhador do Ogro
1522	Lança do Caçador de Cabeças
1523	Grande Clava de Pedra
1524	Presa Rachacrânio
1528	Punhado de Aveia
1529	Jade
1532	Cabeça Encolhida
1534	Incunábulo: Luz Sagrada IV
1536	Incunábulo: Selo da Ira
1537	Comedouro da Velha Brancurinha
1539	Cajado Nodoso do Eremita
1547	Escudo da Fé
1554	Tomo de Seta de Gelo III
1557	Broquel dos Mares
1559	Tomo de Mísseis Arcanos II
1560	Sandálias dos Guelrazul
1561	Veste do Ceifador
1566	Gume da Milícia do Povo
1567	Tomo de Destravamento de Hadggar II
1568	Tomo de Elemental da Água
1571	Tomo de Nova Congelante II
1574	Tomo de Proteção contra Fogo
1588	Tabuleta de Impacto Derretido III
1589	Tabuleta de Armadura Espiritual III
1591	Tabuleta de Escudo de Raios III
1596	Linha de Cabelo de Fantasma
1597	Tabuleta de Tempestade de Raios
1598	Flores do Mal
1602	Machado Foice
1603	Tabuleta de Invocar Espírito II
1604	Espada Cromática
1607	Devoralmas
1608	Maça Quebra-crânios
1613	Cajado Caça-fantasmas
1619	Tabuleta de Tempestade de Raios II
1623	Bolsa de Pele de Raptor
1624	Elmo Rachacrânio
1625	Flamberge Excelente
1630	Eletrolanterna Quebrada
1637	Carta para Malaquias
1639	Machado Sarcástico
1640	Machado de Guerra Monstruoso
1641	Códice de Palavra Sombria: Dor III
1645	Suco de Lunamora
1648	Códice de Cura IV
1651	Códice de Palavra Sagrada: Escudo VI
1652	Lancheira Robusta
1656	Carta Traduzida
1657	Códice de Ressurreição II
1658	Códice de Palavra Sombria: Dor IV
1659	Luvas de Engenharia
1664	Bastão da Força Mística
1676	Códice de Sono II
1677	Colete de Escama de Draco
1678	Pisantes Pretos de Ogro
1679	Bastão Korg
1680	Cortacabeças
1681	Grimório de Aleijar
1685	Bolsa de Couro de Troll
1686	Pelo de Bigode Cerdoso
1687	Garra Retrátil
1688	Longa Cauda Macia
1696	Garra Curva de Raptor
1697	Dente Afiado de Raptor
1701	Garra Curva de Basilisco
1702	Espinha Intacta de Basilisco
1703	Costela de Basilisco de Cristal
1705	Pedra-da-lua Inferior
1706	Estilhaços Azul-profundo
1707	Brie de Ventobravo
1708	Néctar Doce
1710	Poção Maior de Cura
1711	Pergaminho do Vigor II
1712	Pergaminho do Espírito II
1713	Ankh da Vida
1714	Colar de Calíssea
1715	Armadura Jazerina Polida
1716	Veste dos Magos
1717	Túnica de Malha Dupla
1718	Calças de Pelego de Basilisco
1720	Cajado de Madeira-emaranhada
1721	Martelo de Guerra Viquingue
1722	Marrão Petracardo
1725	Mochila Grande
1726	Lança de Osso de Ponta Venenosa
1727	Espada da Decomposição
1728	Espada Longa Fulgurante do Teebu
1729	Saco de Aniagem da Vigília Noturna
1730	Cinto de Malha Desgastado
1731	Botas de Malha Desgastadas
1732	Braçadeiras de Malha Desgastadas
1733	Manto Desgastado
1734	Luvas de Malha Desgastadas
1735	Calças de Malha Desgastadas
1737	Colete de Malha Desgastado
1738	Cinto de Malha com Rendas
1739	Botas de Malha com Rendas
1740	Braçadeiras de Malha com Rendas
1741	Manto com Rendas
1742	Luvas de Malha com Rendas
1743	Calças de Malha com Rendas
1744	Ombreiras de Malha com Rendas
1745	Colete de Malha com Rendas
1746	Cinto de Malha Articulada
1747	Botas de Malha Articulada
1748	Braçadeiras de Malha Articulada
1749	Manto de Malha Articulada
1750	Luvas de Malha Articulada
1751	Calças de Malha Articulada
1752	Ombreiras de Malha Articulada
1753	Colete de Malha Articulada
1754	Cinto Encadeado Reforçado
1755	Botas Encadeadas Reforçadas
1756	Braçadeiras Encadeadas Reforçadas
1757	Manto Encadeado Reforçado
1758	Luvas Encadeadas Reforçadas
1759	Calças Encadeadas Reforçadas
1760	Ombreiras Encadeadas Reforçadas
1761	Colete Encadeado Reforçado
1764	Sapatos de Lona
1766	Manto de Lona
1767	Luvas de Lona
1768	Calças de Lona
1769	Ombreiras de Lona
1770	Colete de Lona
1772	Sapatos Brocados
1774	Manto Brocado
1775	Luvas Brocadas
1776	Calças Brocadas
1777	Ombreiras Brocadas
1778	Colete Brocado
1780	Sandálias em Ponto de Cruz
1782	Manto em Ponto de Cruz
1783	Luvas em Ponto de Cruz
1784	Calças em Ponto de Cruz
1785	Ombreiras em Ponto de Cruz
1786	Colete em Ponto de Cruz
1787	Cinto de Couro Remendado
1788	Botas de Couro Remendadas
1789	Braçadeiras de Couro Remendadas
1790	Manto Remendado
1791	Luvas de Couro Remendadas
1792	Calças de Couro Remendadas
1793	Ombreiras de Couro Remendadas
1794	Gibão de Couro Remendado
1795	Cinto de Couro Cru
1796	Botas de Couro Cru
1797	Braçadeiras de Couro Cru
1798	Manto de Couro Cru
1799	Luvas de Couro Cru
1800	Calças de Couro Cru
1801	Ombreiras de Couro Cru
1802	Túnica de Couro Cru
1803	Cinto de Couro Resistente
1804	Botas de Couro Resistente
1805	Braçadeiras de Couro Resistente
1806	Manto Resistente
1807	Luvas de Couro Resistente
1808	Calças de Couro Resistente
1809	Ombreiras de Couro Resistente
1810	Armadura de Couro Resistente
1811	Espadão Cego
1812	Machado de Batalha de Cabo Curto
1813	Bastão Lascado
1814	Marreta Desgastada
1815	Maça Ornamentada
1816	Machado Desequilibrado
1817	Espada Curta Comum
1818	Espadão Padrão
1819	Picareta de Mutilação
1820	Malho de Madeira
1821	Lâmina Deformada
1822	Bengala de Cedro
1823	Porrete Contundente
1824	Machado de Guerra Brilhante
1825	Marreta Grotesca
1826	Malho de Rocha
1827	Cutelo de Carne
1828	Machado de Guerra de Pedra
1829	Alfanje Curto
1830	Espada Bastarda Longa
1831	Cajado de Guerra de Carvalho
1832	Calças da Sorte
1835	Cinto de Couro Sujo
1836	Braçadeiras de Couro Sujas
1839	Cinto de Couro Áspero
1840	Braçadeiras de Couro Grosseiro
1843	Cinto de Couro Curtido
1844	Braçadeiras de Couro Curtido
1845	Cinto de Malha de Anéis
1846	Braçadeiras de Malha de Anéis
1849	Cinto de Couro Curado
1850	Braçadeiras de Couro Curado
1851	Água Purificante
1852	Braçadeiras de Malha de Escamas
1853	Cinto de Malha de Escamas
1875	Distintivo de Cardurtiga
1877	Livro de Rejuvenescimento III
1882	Livro de Fogo Lunar III
1886	Livro de Fogo Lunar II
1893	Revanche do Minerador
1894	Carteira do Sindicato dos Mineradores
1913	Cassetete com Pontas
1917	Adaga Ornamentada
1922	Suprimentos para Noel
1923	Algibeira do Embaixador
1925	Florete Défias
1926	Maça Gravosa
1927	Cutelo de Minas Mortas
1928	Cajado de Mago Défias
1929	Calçotes Cerzidos com Seda
1930	Manto do Alvanel
1931	Enorme Garra de Gnoll
1933	Cajado de Conjuração
1934	Calçotes do Alvanel
1935	Lâmina do Assassino
1936	Chave de Fenda Goblin
1937	Vibrasserra
1938	Marreta de Cepo
1939	Odre de Rum Doce
1941	Barril de Vinho Merlot
1942	Garrafa de Pinga
1943	Perneiras de Malha Goblínicas
1944	Luvas de Metalurgia
1945	Luvas do Madeireiro
1946	Espelho de Maria
1951	Alfanje Aguanegra
1955	Botas Encadeadas Presa do Dragão
1956	Pingente Umbrapele Esmaecido
1958	Tíbia Petrificada
1959	Picareta de Ferro Frio
1962	Pingente Umbrapele Faiscante
1965	Luvas do Lobo Branco
1968	Monóculo do Ogro
1970	Bálsamo Restaurador
1971	Escritura do Taturana
1972	Escritura de Cerro Oeste
1973	Orbe do Logro
1974	Braçadeiras do Impulso Mental
1975	Antiga Montante de Pysan
1976	Tira-da-mira
1977	Bolsa de 20 Espaços
1978	Luvas Lupigarras
1979	Muralha dos Mortos
1980	Elo do Submundo
1981	Gibão Malha de Gelo
1982	Lâmina Soturna
1986	Rasgatripa
1987	Caçarola Melhorada do Krazek
1988	Manoplas do Brigadeiro-chefe
1990	Malho Pesado
1991	Pá Movida a Goblin
1992	Fetiche Palustre
1993	Anel da Mente do Ogro
1994	Aniquilador Garra de Ébano
1996	Anel Vodu
1997	Veste de Feltro Prensado
1998	Cajado de Canalizador Sanguescalpo
2000	Arqué
2004	Diário de Grolin Barbabranca
2005	A Primeira Lenda Troll
2006	A Segunda Lenda Troll
2007	A Terceira Lenda Troll
2008	A Quarta Lenda Troll
2011	Sabre Retorcido
2013	Cajado Criptósseo
2014	Montante de Metal Preto
2015	Machado de Guerra de Metal Preto
2016	Armadura Encadeada Empoeirada
2017	Braçadeiras de Couro Faiscante
2018	Espada Longa Descarnada
2020	Lâmina da Presa Oca
2021	Escudo de Carapaça Verde
2024	Tarasca
2025	Machado Farpado
2026	Martelo de Rocha
2027	Cimitarra
2028	Martelo
2029	Cutelo
2030	Cajado Nodoso
2032	Manilhas Gallan
2033	Botas do Embaixador
2034	Vestes do Erudito
2035	Espada do Céu Noturno
2036	Luvas de Mineração Empoeiradas
2037	Botas do Escavador
2039	Anel das Planícies
2040	Guarda-troll
2041	Túnica do Cerro Oeste
2042	Cajado do Cerro Oeste
2043	Anel dos Espíritos Desamparados
2044	Crescente dos Espíritos Desamparados
2046	Kukri dos Guelrazul
2047	Machado Pequeno de Sidermar
2048	Martelo de Sidermar
2054	Machadinha Trogg
2055	Martelinho de Madeira
2056	O Martelo de Veludo
2057	Espada Curta Escalavrada Défias
2058	Marreta do Kazon
2059	Manto da Sentinela
2064	Clava Trogg
2065	Lâmina Pedraqueixo
2066	Machado de Crânios
2067	Cajado da Bola de Gelo
2069	Colete de Pelego de Urso Preto
2070	Queijo Roquefort Darnassiano
2072	Cajado Enânico do Mago
2073	Machadinha Enânica
2074	Espadim Maciço
2075	Maça do Sacerdote
2077	Cajado do Mágico
2078	Espada Curta do Norte
2079	Martelo de Guerra do Sargento
2080	Machado Montês
2082	Saco de Aniagem do Lhogolhó
2084	Espada Bastarda de Trevaço
2085	Naco de Carne
2087	Carapaça Dura de Rastejante
2088	Perna Longa de Rastejante
2089	Adaga do Entalhador
2091	Pó Mágico
2092	Punhal Usado
2098	Espingarda de Cano Duplo
2099	Canhão-de-mão Enânico
2100	Cano de Atirar Precisamente Calibrado
2101	Aljava Leve
2102	Bornal Pequeno para Munição
2105	Camisa do Capanga
2108	Colete de Couro Jubafria
2109	Colete Encadeado Jubafria
2110	Veste Leve de Magífice
2112	Gibão do Lenhador
2113	Bilhete do Petrônio
2114	Veste Nevada
2117	Sapatos de Tecido Fino
2119	Luvas de Tecido Fino
2120	Calças de Tecido Fino
2121	Armadura de Tecido Fino
2122	Cinto de Couro Rachado
2123	Botas de Couro Rachado
2124	Braçadeiras de Couro Rachado
2125	Luvas de Couro Rachado
2126	Calças de Couro Rachado
2127	Vestimenta de Couro Rachado
2128	Espadão Arranhado
2129	Escudo Grande Redondo
2130	Clava
2131	Espada Curta
2132	Cajado Curto
2133	Escudo Pequeno
2134	Machado Pequeno
2136	Água Purificada Conjurada
2137	Faca Talhadora
2138	Abridor de Cartas Afiado
2139	Punhal
2140	Faca de Entalhar
2141	Colete de Couro Cozido
2142	Cinto de Couro Cozido
2143	Botas de Couro Cozido
2144	Braçadeiras de Couro Cozido
2145	Luvas de Couro Cozido
2146	Calças de Couro Cozido
2148	Cinto de Escama Polida
2149	Botas de Escama Polida
2150	Braçadeiras de Escama Polida
2151	Luvas de Escama Polida
2152	Perneiras de Escama Polida
2153	Colete de Escama Polida
2154	A História de Morgan Ladimore
2156	Botas Acolchoadas
2158	Luvas Acolchoadas
2159	Calças Acolchoadas
2160	Armadura Acolchoada
2161	Livro da Fazenda de Noel
2162	Anel de Sarah
2163	Lâmina das Sombras
2164	Ranca-tripa
2165	Cobertor da Velha Brancurinha
2166	Perneiras do Capataz
2167	Luvas do Capataz
2168	Botas do Encarregado
2169	Lâmina-alarme
2172	Cinto Rústico
2173	Cinto de Couro Velho
2175	Machado de Batalha Umbrapele
2186	Cinto do Provedor
2187	Uma Pilha de Cartas
2188	Uma Carta para Grolin Barbabranca
2194	Martelo Diamante
2195	Faca de Sidermar
2203	Cutelo do Garrafina
2204	Espetinho do Garrafina
2205	Noctífera
2207	Jambiya
2208	Cotó
2209	Cris
2210	Broquel Desgastado
2211	Escudo Grande Amassado
2212	Broquel Rachado
2213	Escudo Grande Desgastado
2214	Broquel de Madeira
2215	Escudo de Madeira
2216	Broquel Simples
2217	Escudo Retangular
2218	Adaga do Artífice
2219	Broquel Pequeno
2220	Escudo de Tampa
2221	Escudo Tarja
2222	Escudo Torreão
2223	A Escala do Coletor
2224	Adaga de Milícia
2225	Faca de Cozinha Afiada
2226	Cajado do Ogro-mago
2227	Machado de Guerra Ôgrico Pesado
2230	Luvas da Força Muscular
2231	Veste Infernal
2232	Botas do Corretreva
2233	Perneiras Tece-sombras
2234	Armadura do Noctívago
2235	Garramente
2236	Presanegra
2237	Calças Remendadas
2238	Calças do Pivete
2239	O Anel do Coletor
2240	Capa Rústica
2241	Capa de Facínora
2243	Mão de Edward, o Excêntrico
2244	Lâmina Krol
2245	Elmo de Narv
2246	Sinete do Mirmidão
2249	Broquel da Milícia
2250	Bolinhos de Caranguejo Crepuscular
2251	Perna de Aranha Pegajosa
2252	Suprimentos Goblin Sortidos
2254	Martelo de Cristal de Gelo
2256	Clava Esquelética
2257	Cajado Jubafria
2258	Espada Curta Jubafria
2259	Clava Jubafria
2260	Machadinha Jubafria
2262	Marca de Kern
2263	Fitolâmina
2264	Dragonas dos Larápios
2265	Machado dos Lascapedra
2266	Adaga dos Lascapedra
2267	Maça dos Lascapedra
2268	Lâmina dos Lascapedra
2271	Cajado do Vidente Abençoado
2273	Armadura de Guerrilha
2274	Luvas do Sapador
2276	Botas do Andarilho do Pântano
2277	Perneiras do Necromante
2278	Palas do Rastreador
2280	Bengala do Kam
2281	Machado Duro Rodentia
2282	Espada Curta Rodentia
2283	Cinto de Tecido de Rato
2284	Manto de Tecido de Rato
2287	Pernil de Carne
2288	Água Doce Conjurada
2289	Pergaminho de Força II
2290	Pergaminho do Intelecto II
2291	Kang, o Decapitador
2292	Vestes da Necrologia
2295	Presa Grande de Javali
2296	Focinho do Grande Goretusco
2299	Machado de Guerra Incandescente
2300	Colete de Couro com Relevo
2302	Botas de Couro Feitas à Mão
2303	Calças de Couro Feitas à Mão
2304	Kit de Armadura Leve
2307	Botas de Couro de Qualidade
2308	Manto de Couro de Qualidade
2309	Botas de Couro com Relevo
2310	Manto de Couro com Relevo
2311	Gibão de Couro Branco
2312	Luvas de Couro de Qualidade
2313	Kit de Armadura Média
2314	Armadura de Couro Resistente
2315	Botas de Couro Escuro
2316	Manto de Couro Escuro
2317	Túnica de Couro Escuro
2318	Couro Leve
2319	Couro Médio
2320	Fio Grosso
2321	Fio Delicado
2324	Alvejante
2325	Pigmento Preto
2326	Braçadeiras de Hera Trançada
2327	Braçadeiras de Couro Resistente
2361	Martelo Gasto em Batalha
2362	Escudo de Madeira Usado
2364	Colete Trançado
2366	Calças Trançadas
2367	Botas Trançadas
2369	Luvas Trançadas
2370	Arnês de Couro Surrado
2371	Cinto de Couro Surrado
2372	Calças de Couro Surradas
2373	Botas de Couro Surradas
2374	Braçadeiras de Couro Surradas
2375	Luvas de Couro Surradas
2376	Escudo Brasonado Usado
2377	Broquel Redondo
2378	Dedo Descarnado
2379	Vestimenta Encadeada Manchada
2380	Cinto Encadeado Manchado
2381	Perneiras Encadeadas Manchadas
2382	Coração do Embalsamador
2383	Botas Encadeadas Manchadas
2384	Braçadeiras Encadeadas Manchadas
2385	Luvas Encadeadas Manchadas
2386	Colete Encadeado Enferrujado
2387	Cinto Encadeado Enferrujado
2388	Perneiras Encadeadas Enferrujadas
2389	Botas Encadeadas Enferrujadas
2390	Braçadeiras Encadeadas Enferrujadas
2391	Luvas Encadeadas Enferrujadas
2392	Armadura de Malha Leve
2393	Cinto de Malha Leve
2394	Perneiras de Malha Leve
2395	Botas de Malha Leve
2396	Braçadeiras de Malha Leve
2397	Luvas de Malha Leve
2398	Armadura Encadeada Leve
2399	Cinto Encadeado Leve
2400	Perneiras Encadeadas Leves
2401	Botas Encadeadas Leves
2402	Braçadeiras Encadeadas Leves
2403	Luvas Encadeadas Leves
2406	Molde: Botas de Couro de Qualidade
2407	Molde: Gibão de Couro Branco
2408	Molde: Luvas de Couro de Qualidade
2409	Molde: Túnica de Couro Escuro
2410	Tocha Fumacenta
2411	Rédea de Garanhão Preto
2413	Baio
2414	Bridão de Tobiano
2415	Garanhão Branco
2417	Colete Encadeado Aumentado
2418	Perneiras Encadeadas Aumentadas
2419	Cinto Encadeado Aumentado
2420	Botas Encadeadas Aumentadas
2421	Braçadeiras Encadeadas Aumentadas
2422	Luvas Encadeadas Aumentadas
2423	Colete de Brigandina
2424	Cinto de Brigandina
2425	Perneiras de Brigandina
2426	Botas de Brigandina
2427	Braçadeiras de Brigandina
2428	Luvas de Brigandina
2429	Colete de Burel
2431	Calças de Burel
2432	Botas de Burel
2434	Luvas de Burel
2435	Armadura Ornada
2437	Calças Ornadas
2438	Botas Ornadas
2440	Luvas Ornadas
2441	Broquel Circular
2442	Tarja Reforçada
2443	Broquel de Metal
2444	Broquel Ornado
2445	Escudo de Metal Grande
2446	Escudo Ogival
2447	Botão-da-paz
2448	Pavês Pesado
2449	Raiz-telúrica
2450	Cravespinho
2451	Escudo Brasonado Timbrado
2452	Cardo-veloz
2453	Ervamossa
2454	Elixir de Força de Leão
2455	Poção Menor de Mana
2456	Poção Menor de Rejuvenescimento
2457	Elixir de Agilidade Menor
2458	Elixir de Fortitude Menor
2459	Poção de Rapidez
2460	Elixir of Tongues (NYI)
2463	Gibão Cravejado
2464	Cinto Cravejado
2465	Calças Cravejadas
2466	Fetiche Rachacrânio
2467	Botas Cravejadas
2468	Braçadeiras Cravejadas
2469	Luvas Cravejadas
2470	Colete de Couro Reforçado
2471	Cinto de Couro Reforçado
2472	Calças de Couro Reforçado
2473	Botas de Couro Reforçado
2474	Braçadeiras de Couro Reforçado
2475	Luvas de Couro Reforçado
2476	Anca Fria de Basilisco
2477	Crânio do Assolador
2479	Machado Largo
2480	Clava Grande
2481	Espada de Peão
2482	Machadinha Inferior
2483	Machado Largo Rústico
2484	Faquinha
2485	Tábua Farpada
2486	Maça de Pedra Grande
2487	Cajado de Acólito
2488	Gládio
2489	Espada de Duas Mãos
2490	Machadinha
2491	Machado Largo
2492	Clava
2493	Marreta de Madeira
2494	Estilete
2495	Bengala
2496	Espada Curta do Saqueador
2497	Espadão Enferrujado
2498	Machadinha Pequena
2499	Machado de Duas Lâminas
2500	Martelo Leve
2501	Martelo de Guerra de Madeira
2502	Adaga Arranhada
2503	Cajado Curto de Adepto
2504	Arco Curto Usado
2505	Arco Curto Polido
2506	Arco Recurvo de Pau-de-chifre
2507	Arco Recurvo Laminado
2508	Bacamarte Velho
2509	Bacamarte Ornado
2510	Bacamarte Maciço
2511	Cano de Atirar do Caçador
2512	Flecha Rústica
2514	Depricated Sharp Arrow
2515	Flecha Afiada
2516	Munição Leve
2519	Munição Pesada
2520	Espada Larga
2521	Flamberge
2522	Machado Crescente
2523	Bullova
2524	Porrete
2525	Martelo de Guerra
2526	Adaga de Bloqueio
2527	Cajado de Batalha
2528	Alfanje
2529	Bihänder
2530	Frâncica
2531	Machado Grande
2532	Maça de Guerra
2533	Malho de Guerra
2534	Rondel
2535	Cajado de Guerra
2536	Dente de Pedra de Trogg
2545	Perneiras Encadeadas Maleáveis
2546	Cinturão Real Jubafria
2547	Luvas do Tratador de Javalis
2548	Barril de Grogue do Cervevada
2549	Cajado do Vulto
2553	Receita: Elixir de Agilidade Menor
2555	Receita: Poção de Rapidez
2556	Receita: Elixir de Línguas
2560	Diário Completo de Medrisco
2561	Cabeça de Chok'sul
2562	Buquê de Begônias Escarlate
2563	Pó com Cheiro Estranho
2564	Garras Élficas Espirituais
2565	Bastão de Fogo Derretido
2566	Vestes do Sacrifício
2567	Lâmina do  Invocador
2568	Colete Marrom de Linho
2569	Botas de Linho
2570	Manto de Linho
2571	Botas Vinosas
2572	Veste de Linho Vermelha
2575	Camisa Vermelha de Linho
2576	Camisa Branca de Linho
2577	Camisa de Linho Azul
2578	Colete de Linho Barbaresco
2579	Camisa Verde de Linho
2580	Capa Reforçada de Linho
2581	Bandagem de Linho Grossa
2582	Colete de Lã Verde
2583	Botas de Lã
2584	Capa de Lã
2585	Veste de Lã Cinza
2586	Veste do Mestre do Jogo
2587	Camisa de Lã Cinza
2589	Linho
2590	Teia de Aranha da Floresta
2591	Tecido Trogg Sujo
2592	Lã
2593	Frasco de Vinho do Porto de Ventobravo
2594	Jarra de Hidromel Enânico
2595	Jarra de Bourbon dos Ermos
2596	Odre de Stout Enânica
2598	Molde: Veste de Linho Vermelha
2601	Molde: Veste de Lã Cinza
2604	Pigmento Vermelho
2605	Pigmento Verde
2606	Peçonha de Tocaieiro
2607	Cristal Mo'grosh
2608	Âmbar-gris de Manguadonte
2609	Coloide de Desarme
2610	Mistura de Desarme
2611	Pederneira Grotesca
2612	Veste Simples
2613	Vestes de Costura Dupla
2614	Veste do Aprendizado
2615	Veste Cromática
2616	Vestes Cintilante de Seda
2617	Vestes Incandescentes
2618	Vestes Prateadas
2619	Relatório de Grolin
2620	Mortalha Profética
2621	Capucho de Necromancia
2622	Cocar Tribal de Nimar
2623	Diadema Sagrado
2624	Casquete do Pensamento
2625	Estatueta de Menethil
2628	Relatório de Senir
2629	Chave do Cofre do Intrépido
2632	Adaga Recurva
2633	Remédio da Mata
2634	Extrato de Samambaia Peçonhenta
2635	Cinto Folgado Encadeado
2636	Ídolo Esculpido em Pedra
2637	Relatório de Progresso de Bandaferro
2639	Carta de Marina
2640	Equipamento de Mineração
2642	Botas Folgadas Encadeadas
2643	Braçadeiras Folgadas Encadeadas
2644	Manto Folgado Encadeado
2645	Luvas Folgadas Encadeadas
2646	Calças Folgadas Encadeadas
2648	Colete Folgado Encadeado
2649	Cinto Frágil Encadeado
2650	Botas Frágeis Encadeadas
2651	Braçadeiras Frágeis Encadeadas
2652	Manto Frágil Encadeado
2653	Luvas Frágeis Encadeadas
2654	Calças Frágeis Encadeadas
2656	Colete Frágil Encadeado
2657	Bolsa de Couro Vermelha
2658	Fragmento de Ados
2659	Fragmento de Modr
2660	Fragmento de Golm
2661	Fragmento Neru
2662	Aljava do Ribas
2663	Bandoleira do Ribas
2664	Presa de Tecelã
2665	Tempero de Ventobravo
2666	Barril de Cerveja do Trovão
2667	Carne-seca do MacGrann
2668	Dente de Manguadonte
2669	Garra de Manguadonte
2671	Crina de Wendigo
2672	Acém de Lobo
2673	Carne de Coiote
2674	Carne de Rastejante
2675	Garra de Rastejante
2676	Tremulerva
2677	Costelinhas de Javali
2678	Temperos Suaves
2679	Carne Tostada de Lobo
2680	Carne Temperada de Lobo
2681	Carne Assada de Porco
2682	Pinça de Caranguejo Cozida
2683	Bolinho de Caranguejo
2684	Bife de Coiote
2685	Costelinhas Suínas Suculentas
2686	Cerveja do Trovão
2687	Costelinhas Suínas Ressecadas
2688	Noz de Esquilo
2690	Cinto com Aldrava
2691	Botas do Provedor
2692	Temperos Picantes
2694	Perneiras do Colonizador
2695	Monstro - Maça, Clava com Pontas
2696	Barril de Sempre-aceso
2697	Receita: Empadão de Fígado de Goretusco
2698	Receita: Pinça de Caranguejo Cozida
2699	Receita: Gulache de Cristarrubra
2700	Receita: Costelinhas Suínas Suculentas
2701	Receita: Kebab Temperado de Lobo
2702	Lingote da Forja de Luz
2712	Caixote de Lingotes de Forja de Luz
2713	Cabeça do Velho Fumaça
2719	Pequena Chave de Latão
2720	Bilhete Lamacento
2721	Mortalha Sagrada
2722	Vale-vinho
2723	Garrafa de Noir de Dalaran
2724	Pedido de Tecido
2725	Grande Espinhaço: Veredas – Página 1
2728	Grande Espinhaço: Veredas – Página 4
2730	Grande Espinhaço: Veredas – Página 6
2732	Grande Espinhaço: Veredas – Página 8
2734	Grande Espinhaço: Veredas – Página 10
2735	Grande Espinhaço: Veredas – Página 11
2738	Grande Espinhaço: Veredas – Página 14
2740	Grande Espinhaço: Veredas – Página 16
2742	Grande Espinhaço: Veredas – Página 18
2744	Grande Espinhaço: Veredas – Página 20
2745	Grande Espinhaço: Veredas – Página 21
2748	Grande Espinhaço: Veredas – Página 24
2749	Grande Espinhaço: Veredas – Página 25
2750	Grande Espinhaço: Veredas – Página 26
2751	Grande Espinhaço: Veredas – Página 27
2754	Espada Bastarda Manchada
2755	Grande Espinhaço: Veredas
2756	Grande Espinhaço: Veredas – Capítulo I
2757	Grande Espinhaço: Veredas – Capítulo II
2758	Grande Espinhaço: Veredas – Capítulo III
2759	Grande Espinhaço: Veredas – Capítulo IV
2760	Kit de Costura do Antônio
2763	Faca do Pescador
2764	Adaga Pequena
2765	Faca de Caça
2766	Estilete Hábil
2770	Minério de Cobre
2771	Minério de Estanho
2772	Minério de Ferro
2773	Arco Curto Rachado
2774	Bacamarte Coberto de Ferrugem
2775	Minério de Prata
2776	Minério de Ouro
2777	Arco Curto Débil
2778	Bacamarte Barato
2779	Lágrima de Tirsa
2780	Arco Leve de Caça
2781	Bacamarte Sujo
2782	Arco Recurvo Mal Manejado
2783	Bacamarte Fajuto
2784	Raiz Almiscarada
2785	Arco Recurvo Rígido
2786	Bacamarte Oleado
2787	Adaga Trogg
2788	Chope Garra Negra
2794	Um Velho Livro de História
2795	Livro: Fadigas do Ferro
2797	Coração de Mokk
2798	Minério Retibano
2799	Presa de Gorila
2800	Vestes de Veludo Preto
2801	Lâmina de Hanna
2802	Emblema Fulgurante
2805	Manto de Pele de Yeti
2806	Pacote para Lançatroz
2807	Machado Guilhotina
2808	Tocha de Chamas
2815	Estripador de Fio Curvo
2816	Cetro do Morta-voz
2817	Túnica de Couro Macio
2818	Calças de Couro Esticadas
2819	Adaga Transversal
2820	Cronômetro Bacana
2821	Triturador Mo'grosh
2822	Palito de Dente Mo'grosh
2823	Abridor de Lata Mo'grosh
2824	Furacão
2825	Arco das Flechas Calcinantes
2828	Restos Mortais de Nissa
2829	Restos Mortais de Gregor
2830	Restos Mortais de Timóteo
2831	Restos Mortais de Delmiro
2832	Receita de Ensopado do Cerro Oeste da Vera
2833	Grimório do Lich
2834	Linfa Embalsamadora
2835	Pedra Rústica
2836	Pedra Bruta
2837	Carta de Timóteo
2838	Pedra Pesada
2839	Uma Carta para Ivete
2840	Barra de Cobre
2841	Barra de Bronze
2842	Barra de Prata
2843	Nós dos Dedos Sujos
2844	Maça de Cobre
2845	Machado de Cobre
2846	Abóbora de Tirisfal
2847	Espada Curta de Cobre
2848	Maça de Bronze
2849	Machado de Bronze
2850	Espada Curta de Bronze
2851	Cinto Encadeado de Cobre
2852	Calças Encadeadas de Cobre
2853	Braçadeiras de Cobre
2854	Braçadeiras Rúnicas de Cobre
2855	Garra Pútrida
2856	Pique Férreo
2857	Cinto Rúnico de Cobre
2858	Sangue de Cão das Trevas
2859	Escama de Pinavil
2862	Pedra de Afiar Rústica
2863	Pedra de Afiar Grosseira
2864	Peitoral Rúnico de Cobre
2865	Perneiras Rústicas de Bronze
2866	Corselete Rústico de Bronze
2867	Braçadeiras Rústicas de Bronze
2868	Braçadeiras Decoradas de Bronze
2869	Peitoral de Bronze Prateado
2870	Peitoral de Prata Rutilante
2871	Pedra de Afiar Pesada
2872	Peçonha de Trevateia Malévola
2874	Carta Não Enviada
2875	Anel com Insígnia Escarlate
2876	Pelagem de Quiropúsculo
2877	Espadão do Combatente
2878	Machado Farpado de Osso
2879	Bastão Antípoda
2880	Catalisador Fraco
2881	Instruções: Peitoral Rúnico de Cobre
2882	Instruções: Omoplatas de Bronze Prateado
2883	Instruções: Punhal Mortal de Bronze
2885	Documentos da Cruzada Escarlate
2886	Costeleta de Rochetusco
2887	Pelagem de Lobo Arruinada
2888	Costelinhas de Javali na Cerveja
2889	Receita: Costelinhas de Javali na Cerveja
2890	Pelagem de Javali Arruinada
2891	Carta para o Arquiteto da Cidade
2892	Veneno Mortal
2893	Veneno Mortal II
2894	Malte Rapsódia
2895	Dor Gradativa
2896	Angústia Gradativa
2898	Peito d'Armas do Montanhista
2899	Faixa Wendigo
2900	Broquel de Pedra
2901	Picareta de Mineração
2902	Manto da Fé
2903	Arco de Caça de Daryl
2904	Rifle de Caça de Daryl
2905	Manto de Pele de Bode
2906	Perneiras de Malha de Vila Sombria
2907	Cortador de Árvore Enânico
2908	Lâmina Espinhosa
2909	Bandana Vermelha de Lã
2910	Botas Douradas de Milícia
2911	Cinturão de Keller
2912	Garra do Sombramante
2913	Dragonas Sedosas de Gamn
2915	Quebragelo Tarânico
2916	Escudo do Leão Dourado
2917	Anel Plácido
2919	Relíquia dos Anciões
2920	Relíquia Sagrada
2921	Relíquia Abençoada
2922	Relíquia do Espírito
2923	Relíquia da Retidão
2924	Carne de Crocolisco
2925	Pele de Crocolisco
2926	Cabeça de Basílio Taborda
2927	Tormento Gradativo
2928	Poeira da Decomposição
2929	Podridão da Tumba
2930	Essência da Dor
2932	Ramo do Tormento
2933	Selo de Wrynn
2934	Pedaços Arruinados de Couro
2939	Lágrima de Crocolisco
2940	Pata Ensanguentada de Urso
2941	Estoque de Presídio
2942	Soqueira de Ferro
2943	Olho de Paleth
2944	Olho Maldito de Paleth
2946	Adaga de Arremesso Equilibrada
2947	Faca de Arremesso Pequena
2949	Botas de Marinheiro
2950	Bastão do Pingente de Gelo
2951	Anel do Subráxilo
2953	Manto do Mestre Vigilante
2954	Pantalonas da Vigília Noturna
2955	Chapéu do Imediato
2956	Relatório sobre a Irmandade Défias
2957	Colete do Profissional
2958	Calças do Profissional
2959	Botas do Profissional
2960	Luvas do Profissional
2961	Colete de Couro Queimado
2962	Calções de Couro Queimado
2963	Botas de Couro Queimado
2964	Luvas de Couro Queimado
2965	Túnica do Guerreiro
2966	Calças do Guerreiro
2967	Botas do Guerreiro
2968	Luvas do Guerreiro
2969	Colete Mesmerizador
2970	Calças Mesmerizadoras
2971	Botas Mesmerizadoras
2972	Luvas Mesmerizadoras
2973	Túnica de Caça
2974	Calças de Caça
2975	Botas de Caça
2976	Luvas de Caça
2977	Armadura do Veterano
2978	Perneiras do Veterano
2979	Botas do Veterano
2980	Luvas do Veterano
2981	Veste do Vidente
2982	Calças do Vidente
2983	Botas do Vidente
2984	Luvas do Vidente
2985	Peitoral de Couro Inscrito
2986	Calças de Couro Inscritas
2987	Botas de Couro Inscritas
2988	Luvas de Couro Inscritas
2989	Túnica Lustrada
2990	Perneiras Lustradas
2991	Botas Lustradas
2992	Luvas Lustradas
2996	Peça de Linho
2997	Peça de Lã
2998	Uma Bússola Simples
2999	Ferramentas do Gradaço
3000	Carapaça da Grande Mãe
3002	Chifre-relíquia da Justiça
3003	Relíquia do Olho
3004	Relíquia dos Mortos
3005	Relíquia da Verdade
3006	Estilhaço de Relíquia Sagrada
3008	Manto de Pele de Wendigo
3010	Areia Fina
3011	Cocar com Penas
3012	Pergaminho de Agilidade
3013	Pergaminho de Proteção
3014	Machado Gasto em Batalha
3016	Grimório de Tertuliano
3017	Ordens de Sevren
3018	Pelego de Lupos
3019	Veste do Nobre
3020	Casquete Resistente
3021	Arco do Patrulheiro
3022	Calções dos Guelrazul
3023	Bacamarte de Calibre Largo
3024	Persuasor BKP 2700
3025	Ultra BKP 42
3026	Arco Reforçado
3027	Arco Recurvo Pesado
3028	Arco Longo
3029	Flecha de Pau-de-açoite
3030	Flecha Navalha
3031	Flecha Navalha
3033	Munição Maciça
3035	Abóbora Inoculada
3036	Arco Curto Pesado
3037	Arco Recurvo de Pau-de-açoite
3039	Arco Fraxíneo Curto
3040	Espingarda de Antecarga do Caçador
3041	Bacamarte "Olho de Mago"
3042	Pardal BKP de Calibre Pequeno
3045	Botas Bruxuleantes de Escama
3047	Luvas Bruxuleantes de Escama
3048	Guarda-pernas Bruxuleantes de Escama
3049	Peitoral Bruxuleante de Escama
3053	Peito d'Armas do Humberto
3055	Peito d'Armas de Couro da Floresta
3056	Calças de Couro da Floresta
3057	Botas de Couro da Floresta
3058	Luvas de Couro da Floresta
3065	Botas Brilhantes
3066	Luvas Brilhantes
3067	Calças Brilhantes
3069	Veste Brilhante
3070	Manto do Alferes
3071	Machadinha de Ataque
3072	Veste Fumegante
3073	Calças Fumegantes
3074	Luvas Fumegantes
3075	Olho da Chama
3076	Botas Fumegantes
3078	Fura-coração das Nagas
3079	Bacamarte de Skorn
3080	Vela de Sinalização
3081	Gema Etérea
3082	Crânio de Dargol
3083	Roda de Reestabilização
3084	Equipamento Giromecânico
3085	Barril de Cerveja Tremeluz
3086	Tonel de Cerveja Tremeluz
3087	Caneca de Cerveja Tremeluz
3088	Livro de Rejuvenescimento IV
3089	Tomo de Golpe Flamejante
3090	Tomo de Seta de Gelo
3091	Tomo de Intelecto Arcano II
3092	Tomo de Golpe Flamejante III
3093	Tomo de Golpe Flamejante II
3094	Tomo de Impacto de Fogo II
3095	Tomo de Impacto de Fogo III
3096	Tomo de Queda de Pluma
3097	Tomo de Conjurar Água II
3098	Tomo de Retardar
3099	Tomo de Armadura de Gelo II
3100	Tomo de Nevasca II
3101	Tomo de Nova Congelante III
3102	Tomo de Intelecto Arcano III
3103	Martelo de Cristálgida
3107	Faca de Arremesso Afiada
3108	Adaga de Arremesso Pesada
3110	Orelha de Ratatúnel
3111	Machado de Arremesso Rudimentar
3113	Códice de Palavra Sagrada: Escudo
3114	Códice de Palavra Sombria: Estontear
3115	Códice de Renovar IV
3116	Códice de Palavra Sagrada: Escudo II
3117	Diário de Hildelve
3118	Códice de Cura Maior
3119	Códice de Palavra Sagrada: Escudo V
3120	Códice de Punição Sagrada IV
3121	Códice de Levitar
3122	Códice de Palavra Sagrada: Escudo III
3123	Códice de Palavra Sagrada: Fortitude III
3124	Códice de Fogo Interior III
3125	Tabuleta de Totem Serpente II
3126	Tabuleta de Choque II
3127	Tabuleta de Choque III
3129	Tabuleta de Raio IV
3130	Tabuleta de Restauração IV
3131	Machado de Arremesso Pesado
3132	Tabuleta de Impacto Derretido IV
3133	Tabuleta de Totem de Mana
3134	Grimório de Maldição de Mannoroth
3135	Machado de Arremesso Afiado
3137	Machado de Arremesso Mortal
3138	Grimório de Seta Sombria IV
3139	Grimório de Armadura Demoníaca II
3140	Grimório de Sangue Fervente II
3141	Grimório de Drenar Vida
3142	Grimório de Maldição de Sargeras
3143	Grimório de Espírito Incandescente
3144	Grimório de Espírito Incandescente II
3146	Grimório de Espírito Incandescente III
3151	Colete da Brigada de Cerco
3152	Luvas para Dirigir
3153	Manto Manchado de Óleo
3154	Machado de Thelsamar
3155	Remédio de Arugal
3156	Grilhão de Glutão
3157	Grilhão Almanegra
3158	Braçadeiras de Pelego Queimado
3160	Broquel de Placas Férreas
3161	Veste do Guardião
3162	Costela Carcomida
3163	Crânio Enegrecido
3164	Coração Descolorido de Worg
3165	Poção de Quinn
3166	Corrente de Coração Férreo
3167	Pelo Grosso de Aranha
3168	Escama Lascada
3169	Dente Lascado de Urso
3170	Dente Grande de Urso
3171	Presa Quebrada de Javali
3172	Tripas de Javali
3173	Carne de Urso
3174	Linfa de Aranha
3175	Couro de Dragão Arruinado
3176	Garra Pequena
3177	Presinha
3179	Exúvia Dragônica Rachada
3180	Escama Sarapintada de Raptor
3181	Carne Parcialmente Digerida
3182	Seda da Aranha
3183	Pata Sarnenta
3184	Adaga Enganchadora
3185	Cajado Acrobático
3186	Espada Viking
3187	Cris Sacrificial
3188	Espadão Coral
3189	Cortalenha
3190	Porrete
3191	Machado de Guerra Recurvo
3192	Espada Bastarda Curta
3193	Marreta de Carvalho
3194	Malícia Negra
3195	Machado de Batalha Barbaresco
3196	Espada Bastarda Afiada
3197	Espadão Lapidante
3198	Martelo-aríete
3199	Belocida
3200	Braçadeiras de Couro Queimado
3201	Machado de Guerra Bárbaro
3202	Braçadeiras de Couro da Floresta
3203	Maça Triangular Densa
3204	Braçadeiras de Lenhafunda
3205	Braçadeiras de Couro Inscritas
3206	Espada de Mão Dupla do Fidalgo
3207	Braçadeiras de Caça
3208	Martelo Kabong
3209	Espada Bélica Antiga
3210	Machado de Guerra Brutal
3211	Braçadeiras Lustradas
3212	Braçadeiras Bruxuleantes de Escama
3213	Braçadeiras do Veterano
3214	Braçadeiras do Guerreiro
3216	Veste Grossa de Inverno
3217	Cinto do Encarregado
3218	Grilha de Lenhardente
3220	Chouriço
3222	Adaga Maléfica
3223	Cetro Jubafria
3224	Braçadeiras Forradas com Prata
3225	Faca Manchada de Sangue
3227	Cajado do Nocturno
3228	Grilhões Forçados
3229	Faixa de Seda de Tarântula
3230	Braçadeiras do Lobo Preto
3231	Brafoneiras Degoladoras
3233	Sacola de Pelego de Gnoll
3234	Anel de Deliah
3235	Anel do Escárnio
3236	Linfa de Putricouro
3237	Amostra de Linfa
3238	Achados de Joaquino
3239	Contrapeso Rústico
3240	Contrapeso Grosseiro
3241	Contrapeso Pesado
3248	Carta do Embalsamador Traduzida
3249	Conjured test Item
3250	Pergaminho de Boanerges
3251	Poção de Boanerges
3252	Relatório do Sicário
3253	Coração de Urso Cinzento
3254	Sangue de Pateante
3255	Diário de Berardo
3256	Musgo de Sorrateiro do Lago
3257	Musgo de Rastejante do Lago
3258	Tumor Endurecido
3259	Pelego de Morcego Arruinado
3260	Vestes do Iniciado Escarlate
3261	Manto Enredado
3262	Martelo de Madeira Podre
3263	Calças Enredadas
3264	Asa de Quiropúsculo
3265	Pata de Carniceiro
3266	Braçadeiras Escarlate
3267	Espada Curta dos Renegados
3268	Adaga dos Renegados
3269	Malho dos Renegados
3270	Colete de Linhão
3272	Perneiras de Pele de Zumbi
3273	Colete de Malha Rústico
3274	Botas de Linhão
3275	Luvas de Linhão
3276	Broquel do Necroguarda
3277	Cajado do Executor
3278	Aura de Proc de Espada de Dano
3279	Botas Encadeadas de Batalha
3280	Braçadeiras Encadeadas de Batalha
3281	Luvas Encadeadas de Batalha
3282	Calças Encadeadas de Batalha
3283	Túnica Encadeada de Batalha
3284	Botas Tribais
3285	Braçadeiras Tribais
3286	Luvas Tribais
3287	Calças Tribais
3288	Colete Tribal
3289	Botas Ancestrais
3290	Luvas Ancestrais
3291	Tanga do Ancestral
3292	Túnica Ancestral
3293	Cutelo do Defunto
3294	Clava do Defunto
3295	Lâmina do Defunto
3296	Adaga do Defunto
3297	Limo Vil
3299	Canino Fraturado
3300	Pata de Coelho
3301	Canino Afiado
3302	Botas Salobras
3303	Braçadeiras Salobras
3304	Manoplas Salobras
3305	Perneiras Salobras
3306	Colete Salobro
3307	Botas de Tecido Barbarescas
3308	Luvas de Tecido Barbarescas
3309	Tanga Barbaresca
3310	Colete de Tecido Barbaresco
3311	Tornozeleiras Cerimoniais de Couro
3312	Braçadeiras Cerimoniais de Couro
3313	Arnês Cerimonial de Couro
3314	Luvas Cerimoniais de Couro
3315	Tanga Cerimonial de Couro
3316	Cabeça de Alaric
3317	Uma Cabeça Falante
3318	Restos Mortais de Alaric
3319	Sabre Curto
3320	Faixa do Osteurgo
3321	Botinas de Pele Cinzas
3322	Manto Tênue
3323	Braçadeiras Fantasmagóricas
3324	Dragonas Fantasmagóricas
3325	Machado de Batalha de Pinavil
3327	Cajado de Oráculo de Pinavil
3328	Veste Teia de Aranha
3329	Prancha de Madeira com Pregos
3330	Cota de Dargol
3331	Capa de Metrache
3332	Botas de Perrine
3334	Pá do Fazendeiro
3335	Vassoura do Fazendeiro
3336	Fura-carne
3337	Estandarte de Guerra Presa do Dragão
3339	Isca de Pederneira Enânica
3340	Minério de Incendicita
3341	Manoplas da Força Ôgrica
3342	Camisa do Capitão Albernaz
3343	Saco de Butim do Capitão Albernaz
3344	Faixa do Capitão Albernaz
3345	Chapéu de Teurgo de Seda
3347	Pacote de Peles de Crocolisco
3348	Pele de Crocolisco Gigante
3349	Bolsa da Cida
3352	Bolsa Coberta de Gosma
3353	Pingente Inscrito em Runas
3354	Pingente de Dalaran
3355	Ácera-agreste
3356	Sangue-real
3357	Raiz-da-vida
3358	Bigode-de-hadggar
3360	Fêmur do Suturino
3363	Cinto Puído
3365	Braçadeiras Puídas
3369	Musgo de Tumba
3370	Cinto de Retalhos
3371	Ampola Vazia
3372	Ampola Chumbada
3373	Braçadeiras de Retalhos
3374	Cinto de Calico
3375	Braçadeiras de Calico
3376	Cinto de Lona
3377	Braçadeiras de Lona
3378	Cinto Brocado
3379	Braçadeiras Brocadas
3380	Cinto em Ponto de Cruz
3381	Braçadeiras em Ponto de Cruz
3382	Poção Fraca de Sangue de Troll
3383	Elixir de Sabedoria
3384	Poção Menor de Resistência à Magia
3385	Poção Inferior de Mana
3386	Elixir de Resistência a Veneno
3387	Poção de Invulnerabilidade Limitada
3388	Poção Forte de Sangue de Troll
3389	Elixir de Defesa
3390	Elixir de Agilidade Inferior
3391	Elixir de Força do Ogro
3392	Elmo de Elos
3393	Receita: Poção Menor de Resistência à Magia
3394	Receita: Elixir de Resistência a Veneno
3395	Receita: Poção de Invulnerabilidade Limitada
3396	Receita: Elixir de Agilidade Inferior
3397	Pele de Crocolisco Jovem
3399	Garra de Abutre
3400	Espada Lucina
3401	Escama Áspera de Crocolisco
3402	Tufo Macio de Pele
3403	Presa de Marfim de Javali
3404	Asa de Urubu
3405	Talismã de Garra de Corvo
3406	Cálamo de Pena Negra
3407	Safira do Céu
3408	Runa da Nidificação
3409	Presa de Sabre-da-noite
3411	Pena Estrígida de Coruja
3412	Seda de Aranha Lenhateia
3413	Estaca da Perdição
3414	Cetro Timbrado
3415	Cajado Monástico
3416	Correntes do Mártir
3417	Espadão de Ônix
3418	Pinha Vil
3419	Rosa Vermelha
3420	Rosa Negra
3421	Flores Silvestres Simples
3422	Belas Flores Silvestres
3423	Buquê de Rosas Brancas
3424	Buquê de Rosas Pretas
3425	Varinha Entretecida
3426	Camisa Amarelo-cheguei
3427	Camisa Preta Estilosa
3428	Camisa Cinza Comum
3429	Cinto do Guarda
3430	Rifle de Francoatirador
3431	Couro Cravejado com Ossos
3434	Areia do Sono
3435	Braçadeiras de Pele Zumbis
3437	Cinto Afivelado
3438	Ankh da Ressurreição
3439	Botas de Pele Zumbis
3440	Racha-osso
3442	Faixa de Aprendiz
3443	Machadinha Aborígine Cerimonial
3444	Colete do Lavrador
3445	Faca Cerimonial
3446	Cajado Lenhanegra
3447	Botas Andacripta
3448	Raiz de Senggin
3449	Xale Místico
3450	Escudo de Faerleia
3451	Beberagem do Brilho da Noite
3452	Bastão de Cerânio
3453	Braçadeiras Acolchoadas
3454	Botas de Reconhecimento
3455	Espada Curta do Sicário
3456	Apito de Cães
3457	Calças Estampadas
3458	Luvas Grosseiras de Malha
3460	Bebida Especial do Joaquino
3461	Grande Veste do Árbitro
3462	Lançagarra
3463	Estrela de Prata
3464	Flecha com Penas
3465	Tiro Detonador
3466	Catalisador Forte
3467	Chave de Ouro Desluzido
3468	Achados de Renferrel
3469	Botas Encadeadas de Cobre
3470	Pedra de Amolar Rústica
3471	Colete Encadeado de Cobre
3472	Manoplas Rúnicas de Cobre
3473	Calças Rúnicas de Cobre
3474	Manoplas de Cobre com Gemas
3475	Manto das Chamas
3476	Língua de Urso Cinzento
3477	Pus de Rastejante
3478	Pedra de Amolar Grosseira
3480	Omoplatas Rústicas de Bronze
3481	Omoplatas de Bronze Prateado
3482	Botas de Bronze Prateado
3483	Manoplas de Bronze Prateado
3484	Botas Verdes de Ferro
3485	Manoplas Verdes de Ferro
3486	Pedra de Amolar Pesada
3487	Espada Larga Pesada de Cobre
3488	Machado de Batalha de Cobre
3489	Machado de Guerra Grosso
3490	Punhal Mortal de Bronze
3491	Maça Pesada de Bronze
3492	Martelo Potente de Ferro
3493	Verdugo dos Raptors
3495	Elixir do Sofrimento
3496	Sangue de Leão da Montanha
3497	Elixir da Dor
3498	Colar de Taretha
3499	Chave de Ouro Lustroso
3502	Cogumelos Fuçalama
3505	Anel-sinete de Alterac
3506	Composto Fuçalama
3508	Mistura Fuçalama
3509	Escama de Espinhadaga
3510	Olho de Rancapina
3511	Manto da Milícia do Povo
3514	Crânio de Mor'Ladim
3515	Cajado de Ataeric
3516	Cabeça de Lescovar
3517	Barril de Stout do Festeiro
3518	Carta Decifrada
3520	Barril Estragado
3521	Carta Habilmente Cifrada
3522	Peitoral Preto de Elfo Noturno
3523	Calças Pretas de Elfo Noturno Não Usadas
3524	Botas Pretas de Elfo Noturno Não Usadas
3525	Braçadeiras Pretas de Elfo Noturno Não Usadas
3526	Luvas Pretas de Elfo Noturno
3527	Peitoral Branco de Elfo Noturno
3528	Peitoral C03 de Couro Vermelho
3529	Elmo Preto de Elfo Noturno
3530	Bandagem de Lã
3531	Bandagem Grossa de Lã
3532	Unused Red Leather C03 Pants
3533	Botas C03 de Couro Vermelho
3534	Unused Red Leather C03 Gloves
3535	Braçadeiras C03 de Couro Vermelho
3536	Venda do Caçador de Demônios
3537	Peitoral D02 de Couro Preto
3538	Peitoral D02 de Couro Cinza
3539	Unused Black Leather D02 Pants
3540	Unused Gray Leather D02 Pants
3541	Botas D02 de Couro Preto
3542	Botas D02 de Couro Cinza
3543	Unused Black Leather D02 Gloves
3544	Unused Gray Leather D02 Gloves
3545	Braçadeiras D02 de Couro Preto
3546	Braçadeiras D02 de Couro Cinza
3547	Peitoral D03 de Couro Branco
3548	Unused White Leather D03 Pants
3549	Unused White Leather D03 Gloves
3550	Cabeça do Targ
3551	Cabeça de Revirestrume
3552	Cabeça de Glommus
3553	Cabeça de Mug'thol
3554	Coroa da Vontade
3555	Veste de Salomão
3556	Chapéu de Mago do Horror
3557	Tabardo de Bucha Não Usado
3558	Veste do Protetor do Charco
3559	Manoplas da Vigília Noturna
3560	Dragonas da Honra
3561	Poncho Resiliente
3562	Cinto da Vindicação
3563	Pantalonas do Marinheiro
3564	Carregamento de Ferro
3565	Luvas Manchadas de Cerveja
3566	Armadura Arruina-raptor
3567	Vara de Pescar Enânica
3569	Veste do Vicário
3570	Pilão para Ossos
3571	Batedor Trogg
3572	Espada Curta de Daryl
3573	Aljava de Caça
3574	Saco de Munição de Caça
3575	Barra de Ferro
3576	Barra de Estanho
3577	Barra de Ouro
3578	Calças do Ceifador
3581	Faca Serrilhada
3582	Manto à Prova de Ácido
3583	Cinto Surrado
3585	Túnica Camuflada
3586	Rachalenha
3587	Cinto Ornado
3588	Braçadeiras Ornadas
3589	Cinto de Trama Pesada
3590	Braçadeiras de Trama Pesada
3591	Cinto Acolchoado
3592	Braçadeiras Acolchoadas
3593	Cinto de Burel
3594	Braçadeiras de Burel
3595	Cinto de Tecido Esfarrapado
3596	Braçadeiras de Tecido Esfarrapado
3597	Cinto de Tecido Grosso
3598	Braçadeiras de Tecido Grosso
3599	Cinto de Tecido Fino
3600	Braçadeiras de Tecido Fino
3601	Missiva da Camarilha
3602	Cinto Tricotado
3603	Braçadeiras Tricotadas
3604	Cartucheira da Vigília Noturna
3605	Aljava da Vigília Noturna
3606	Cinto Trançado
3607	Braçadeiras Trançadas
3608	Instruções: Martelo Potente de Ferro
3609	Instruções: Colete Encadeado de Cobre
3610	Instruções: Manoplas de Cobre com Gemas
3611	Instruções: Botas Verdes de Ferro
3612	Instruções: Manoplas Verdes de Ferro
3613	Mãos de Valdred
3614	Pata de Berrante
3615	Cabeça do Kurzen
3616	Olho da Mente
3617	Pingente das Sombras
3618	Cabeça de Comilão
3619	Caixa de Rapé do Expedito
3620	Restos Mortais de Lillith
3621	Cabeça de Ivar
3622	Essência de Vergasta
3623	Cabeça de Thule
3625	Cabeça do Nek'rosh
3626	Cabeça do Barão Vardus
3627	Presa de Ragash
3628	Mão de Flávio Lúcio
3629	Anel da Família Brumanto
3630	Cabeça de Targorr
3631	Presa de Ronquifuça
3632	Pata de Mordente
3633	Cabeça de Gath'Ilzogg
3634	Cabeça de Severo
3635	Pata do Olho de Verme
3636	Escama do Velho Olho-turvo
3637	Cabeça do VanCleef
3638	Garra do Sarilodonte
3639	Orelha do Balgaras
3640	Cabeça de Fundafúria
3641	Braçadeiras do Profissional
3642	Braçadeiras Ancestrais
3643	Braçadeiras Mesmerizadoras
3644	Braçadeiras de Tecido Barbarescas
3645	Manilhas do Vidente
3647	Braçadeiras Brilhantes
3648	Broquel do Guerreiro
3649	Broquel Tribal
3650	Escudo de Batalha
3651	Escudo do Veterano
3652	Broquel de Caça
3653	Broquel Cerimonial
3654	Escudo Salobro
3655	Escudo Lustrado
3656	Escudo Bruxuleante de Escama
3657	Cartório de Eira dos Montes
3658	Tomo Recuperado
3659	Livro de Couro Desgastado
3660	Tomos de Alterac
3661	Cajado Artesanal
3662	Bife de Crocolisco
3663	Sopa de Barbatana de Murloc
3664	Bobó de Crocolisco
3665	Omelete Curiosamente Saboroso
3666	Bolo de Aranha Pegajoso
3667	Carne Tenra de Crocolisco
3668	Contrato do Assassino
3669	Meleca Gelatinosa
3670	Osso Enlameado Grande
3671	Crânio Inerte
3672	Cabeça de Nagaz
3673	Flecha Quebrada
3674	Bota em Decomposição
3675	Tocha Extinta
3676	Linfa Viscosa
3678	Receita: Bife de Crocolisco
3679	Receita: Chouriço
3680	Receita: Sopa de Barbatana de Murloc
3681	Receita: Bobó de Crocolisco
3682	Receita: Omelete Curiosamente Saboroso
3683	Receita: Bolo de Aranha Pegajoso
3684	Tiara de Perenolde
3685	Ovo de Raptor
3688	Oval de Pedra-sangrenta
3689	Bola de Gude de Pedra-sangrenta
3690	Lasca de Pedra-sangrenta
3691	Cunha de Pedra-sangrenta
3692	Crânio Humano de Eira dos Montes
3693	Espada do Humberto
3701	Comenda Lacrada de Darthalia
3702	Vesícula Biliar de Urso
3703	Stout da Costa Sul
3704	Chave de Ferro Enferrujada
3706	Pergaminho Encantado
3707	Pergaminho de Nagaz
3708	Bastão de Helcolar
3710	Bastão de Helcolar
3711	Diário de Pesquisa de Belamore
3712	Carne de Tartaruga
3713	Temperos Reconfortantes
3714	Ficha de Pedra Gasta
3715	Braçadeiras do Vínculo à Terra
3716	Cabeça de Murloc
3717	Saco com Cabeças de Murloc
3718	Planos Agourentos
3719	Manto do Montanhista
3720	Pele de Yeti
3721	Relatório de Fárrio
3722	Pelego Conhecido
3723	Presa Conhecida
3724	Garra Conhecida
3725	Chifre Conhecido
3726	Filé de Ursão
3727	Costeletas Picantes de Leão
3728	Bife Saboroso de Leão
3729	Caldo Reconfortante de Tartaruga
3730	Carne de Ursão
3731	Carne de Leão
3732	Capa com Capucho
3733	Corrente Bélica Órquica
3734	Receita: Filé de Ursão
3735	Receita: Costeletas Picantes de Leão
3736	Receita: Bife Saboroso de Leão
3737	Receita: Caldo Reconfortante de Tartaruga
3738	Bastão do Processamento
3739	Anel de Crânio
3740	Espada Decapitante
3741	Botas da Pisadura
3742	Arco da Pilhagem
3743	Broquel da Sentinela
3744	Pingente de Pedra-sangrenta
3745	Runa de Abertura
3747	Faixa Meditativa
3748	Dragonas Felinas
3749	Manto da Grã-boticária
3750	Peitoral com Suportes
3751	Perneiras Mercenárias
3752	Colete do Bruto
3753	Cinturão do Pastor
3754	Luvas do Pastor
3755	Rasgador de Peixe
3758	Cinto do Cruzado
3759	Luvas Isolantes do Sábio
3760	Elo da Cidade Baixa
3761	Escudo Crânio-morto
3762	Algibeira do Bibliotecário
3763	Broquel Lunar
3764	Botas do Mantídeo
3765	Brafoneiras do Bandoleiro
3766	Cálamo de Pena de Grifo
3767	Pergaminho de Qualidade
3769	Varinha Quebrada
3770	Costela de Carneiro
3771	Pernil de Porco do Mato
3772	Água da Fonte Conjurada
3775	Veneno Debilitante
3776	Veneno Debilitante II
3777	Raiz da Letargia
3778	Arco Composto Firme
3779	Machado de Guerra Robusto
3780	Mosquete de Cano Longo
3781	Espadão Largo
3782	Grande Clava de Guerra
3783	Cimitarra Leve
3784	Báculo de Metal
3785	Machado Afiado
3786	Punhal Brilhante
3787	Clava de Pedra
3788	Relíquia do Cristal de Alma
3789	Pedra-relíquia da Devoção
3790	Pergaminho-relíquia Consagrado
3791	Relíquia da Luz
3792	Cinto Entrelaçado
3793	Botas Entrelaçadas
3794	Braçadeiras Entrelaçadas
3795	Manto Entrelaçado
3796	Luvas Entrelaçadas
3797	Calças Entrelaçadas
3798	Ombreiras Entrelaçadas
3799	Colete Entrelaçado
3800	Cinto de Couro Endurecido
3801	Botas de Couro Endurecido
3802	Braçadeiras de Couro Endurecido
3803	Manto Endurecido
3804	Luvas de Couro Endurecido
3805	Calças de Couro Endurecido
3806	Ombreiras de Couro Endurecido
3807	Túnica de Couro Endurecido
3808	Cinto de Malha Dupla
3809	Botas de Malha Dupla
3810	Braçadeiras de Malha Dupla
3811	Manto de Costura Dupla
3812	Luvas de Malha Dupla
3813	Calças de Malha Dupla
3814	Ombreiras de Malha Dupla
3815	Colete de Malha Dupla
3816	Escudo Refletor
3817	Broquel Reforçado
3818	Some-folha
3819	Boquinha-do-inverno
3820	Estrangulalga
3821	Espinheira-dourada
3822	Laminegra Rúnica
3823	Poção Inferior de Invisibilidade
3824	Óleo de Sombra
3825	Elixir de Fortitude
3826	Poção Potente de Sangue de Troll
3827	Poção de Mana
3828	Elixir de Detectar Invisibilidade Inferior
3829	Óleo Gélido
3830	Receita: Elixir de Fortitude
3831	Receita: Poção Potente de Sangue de Troll
3832	Receita: Elixir de Detectar Invisibilidade Inferior
3833	Manto do Adepto
3834	Calças de Tecido Resistente
3835	Braçadeiras Verdes de Ferro
3836	Elmo Verde de Ferro
3837	Coifa de Escama Dourada
3838	Garra de Umbragorja
3839	Presa Imaculada de Tigresa
3840	Omoplatas Verdes de Ferro
3841	Omoplatas de Escama Dourada
3842	Perneiras Verdes de Ferro
3843	Perneiras de Escama Dourada
3844	Cota Verde de Ferro
3845	Corselete de Escama Dourada
3846	Botas de Aço Polido
3847	Botas de Escama Dourada
3848	Faca Grande de Bronze
3849	Espada Curta de Ferro Temperado
3850	Espada Viperina de Jade
3851	Malho de Ferro Maciço
3852	Destruidor de Ferro Dourado
3853	Espada Larga de Lunaço
3854	Lâmina do Tigre de Gelo
3855	Machado Sólido de Ferro
3856	Machado Crescente das Sombras
3857	Carvão
3858	Minério de Mithril
3859	Barra de Aço
3860	Barra de Mithril
3861	Barra de Açonegro
3862	Tendão de Gorila Velho
3863	Pena de Espreitador da Selva
3864	Citrino
3866	Instruções: Espada Viperina de Jade
3867	Instruções: Destruidor de Ferro Dourado
3868	Instruções: Lâmina do Tigre de Gelo
3869	Instruções: Machado Crescente das Sombras
3870	Instruções: Omoplatas Verdes de Ferro
3871	Instruções: Omoplatas de Escama Dourada
3872	Instruções: Perneiras de Escama Dourada
3873	Instruções: Corselete de Escama Dourada
3874	Instruções: Botas de Aço Polido
3875	Instruções: Botas de Escama Dourada
3876	Presa de Bhag'thera
3877	Gadanho de Tethis
3879	Pata de Sin'Dall
3880	Cabeça de Bangalash
3882	Pena de Urubu
3889	Chapéu de Burel
3890	Chapéu Cravejado
3891	Elmo Encadeado Aumentado
3892	Chapéu Ornado
3893	Casquete de Couro Reforçado
3894	Elmo de Brigandina
3897	Olho do Dizzy
3898	Canhoto da Biblioteca
3899	Lendas dos Gurubashi, Volume 3
3900	Xerez de Pupellyverbos
3901	Presa de Sanguescalpo
3902	Cajado dos Nobres
3904	Cabeça de Gan'zulah
3905	Cabeça de Nezzliok
3906	Troféu de Balia'mah
3907	Troféu de Ziata'jai
3908	Troféu Zul'Mamwe
3909	Armadura Quebrada de Ana'thek
3910	Rapé
3911	Estilhaço Azul Pulsante
3912	Gema Anímica
3913	Joia de Alma Plena
3914	Mochila do Profissional
3915	Colar de Osso Ensanguentado
3916	Colar de Osso Partido
3917	Cristal Azul Canoro
3918	Estilhaço de Cristal Cantante
3919	Miúdos de Gorila do Vale da Névoa
3920	Cartas de Navegação da Vela Sangrenta
3921	Ordens da Vela Sangrenta
3922	Pagamento do Sacode
3923	Braçadeiras do Elemental da Água
3924	Pé-de-clava do Maury
3925	Luneta Dourada de Janjão
3926	Anel Enorme do Chucky
3927	Cheddar Bem Envelhecido
3928	Poção Superior de Cura
3929	Saque do Maury
3930	Chave de Maury
3931	Presa Envenenada de Aranha
3932	Baú do Smotts
3935	Alfanje de Smotts
3936	Cinto de Crochê
3937	Botas de Crochê
3938	Braçadeiras de Crochê
3939	Manto de Crochê
3940	Luvas de Crochê
3941	Calças de Crochê
3942	Ombreiras de Crochê
3943	Colete de Crochê
3944	Cinto de Sarja
3945	Botas de Sarja
3946	Braçadeiras de Sarja
3947	Manto de Sarja
3948	Luvas de Sarja
3949	Calças de Sarja
3950	Ombreiras de Sarja
3951	Colete de Sarja
3952	Cinto de Rede Metálica
3953	Botas de Rede Metálica
3954	Braçadeiras de Rede Metálica
3955	Manto de Rede Metálica
3956	Luvas de Rede Metálica
3957	Calças de Rede Metálica
3958	Dragonas de Rede Metálica
3959	Armadura de Rede Metálica
3960	Bolsa de Braçadeiras de Elementais da Água
3961	Cinto de Couro Grosso
3962	Botas de Couro Grosso
3963	Braçadeiras de Couro Grosso
3964	Manto Grosso
3965	Luvas de Couro Grosso
3966	Calças de Couro Grosso
3967	Ombreiras de Couro Grosso
3968	Túnica de Couro Grosso
3969	Cinto de Couro Liso
3970	Botas de Couro Liso
3971	Braçadeiras de Couro Liso
3972	Manto Liso
3973	Luvas de Couro Liso
3974	Calças de Couro Liso
3975	Ombreiras de Couro Liso
3976	Armadura de Couro Liso
3977	Cinto Enfaixado
3978	Botas Enfaixadas
3979	Braçadeiras Enfaixadas
3980	Manto Enfaixado
3981	Luvas Enfaixadas
3982	Calças Enfaixadas
3983	Ombreiras Enfaixadas
3984	Armadura Enfaixada
3985	Faixa com Monograma
3986	Pavês Protetor
3987	Torre Defletora
3988	Muralha de Proteção de Placa
3989	Tarja de Bloqueio
3990	Broquel Timbrado
3991	Broquel de Placas
3992	Cinto Laminado de Escama
3993	Botas Laminadas de Escama
3994	Braçadeiras Laminadas de Escama
3995	Manto Laminado de Escama
3996	Luvas Laminadas de Escama
3997	Calças Laminadas de Escama
3998	Ombreiras Laminadas de Escama
3999	Armadura Laminada de Escama
4000	Cinto de Malha Entretecida
4001	Botas de Malha Entretecida
4002	Braçadeiras de Malha Entretecida
4003	Manto de Malha Entretecida
4004	Luvas de Malha Entretecida
4005	Calças de Malha Entretecida
4006	Ombreiras de Malha Entretecida
4007	Armadura de Malha Entretecida
4008	Cinto Encadeado Excelente
4009	Botas Encadeadas Excelentes
4010	Braçadeiras Encadeadas Excelentes
4011	Manto Encadeado Excelente
4012	Luvas Encadeadas Excelentes
4013	Calças Encadeadas Excelentes
4014	Ombreiras Encadeadas Excelentes
4015	Armadura Encadeada Excelente
4016	Preparado de Zanzil
4017	Espada Curta Afiada
4018	Espadão Afiado
4019	Machado Duro de Sílex
4020	Machado de Batalha Estilhaçante
4021	Maça Rombuda
4022	Malho Esmagante
4023	Adaga Pontuda de Qualidade
4024	Cajado de Guerra Pesado
4025	Arco Longo Equilibrado
4026	Mosquete da Sentinela
4027	Lâmina de Catelyn
4028	Feixe de Junco de Akiris
4029	Junco de Akiris
4030	Água da Relíquia Sagrada
4031	Patuá da Relíquia Sagrada
4032	Martelo-relíquia Radiante
4033	Brilho da Aurora
4034	Pedra das Marés
4035	Veste de Fio de Prata
4036	Manilhas de Fio de Prata
4037	Calças de Fio de Prata
4038	Veste do Céu Noturno
4039	Capucho do Céu Noturno
4040	Luvas do Céu Noturno
4041	Capucho da Aurora
4042	Luvas da Aurora
4043	Braçadeiras da Aurora
4044	Calças da Aurora
4045	Braçadeiras Enevoadas
4046	Calças Enevoadas
4047	Botas Enevoadas
4048	Chapéu Brasonado
4049	Braçadeiras Brasonadas
4050	Perneiras Brasonadas
4051	Botas Brasonadas
4052	Casquete com Insígnia
4053	Pele de Crocolisco Grande do Rio
4054	Perneiras com Insígnia
4055	Botas com Insígnia
4056	Charada do Cortello
4057	Couraça com Insígnia
4058	Peitoral Glífico
4059	Braçadeiras Glíficas
4060	Perneiras Glíficas
4061	Braçadeiras Imperiais de Couro
4062	Calças Imperiais de Couro
4063	Luvas Imperiais de Couro
4064	Broquel Brasonado
4065	Escudo de Combate
4066	Broquel com Insígnia
4067	Broquel Glífico
4068	Escudo do Brigadeiro-chefe
4069	Broquel de Forja Negra
4070	Timbre do Justador
4071	Peitoral de Malha Furta-cor
4072	Manoplas de Malha Furta-cor
4073	Grevas de Malha Furta-cor
4074	Armadura de Combate de Malha
4075	Manoplas de Combate de Malha
4076	Botas de Combate de Malha
4077	Cimeira de Combate de Malha
4078	Touca do Brigadeiro-chefe
4079	Perneiras do Brigadeiro-chefe
4080	Capucho Forja Negra
4082	Peitoral Forja Negra
4083	Manoplas Forja Negra
4084	Perneiras Forja Negra
4085	Caçarola Meia-boca do Krazek
4086	Rifle Relâmpago
4087	Arco Tirocerto
4088	Terroraço
4089	Bacamarte Ricochete
4090	Caneca d'Aleijar
4091	Fazedor de Viúvas
4092	Escama Prismática de Basilisco
4093	Cauda Grande de Basilisco
4094	Estilhaço de Tabuleta
4095	Kit Deprecado de Armadilha
4096	Pelo Áspero de Gorila
4097	Dente Lascado de Gorila
4098	Bilhete Cuidadosamente Dobrado
4099	Tufo de Pelo de Gorila
4100	Bilhete Amarrotado
4101	Bilhete Rasgado
4102	Bilhete Rasgado
4103	Chave dos Grilhões
4104	Pele de Crocolisco Arapuca
4105	Pele de Crocolisco Ancião
4106	Cristal Rolado
4107	Luvas do Caçador de Tigres
4108	Perneiras do Caçador de Panteras
4109	Botas Excelsior
4110	Arco do Mestre Caçador
4111	Rifle do Mestre Caçador
4112	Gargantilha do Sumo Xamã
4113	Cobertor Medicinal
4114	Capa Ondanegra
4115	Broquel Grom'gol
4116	Diad'orin
4117	Cinta Causticante
4118	Argola de Nariz da Princesa Manda Chuva
4119	Túnica do Caçador de Raptor
4120	Veste das Águas Cristalinas
4121	Luvas de Pedraria
4122	Cetro do Contador
4123	Brafoneiras de Metal Gélido
4124	Casquete da Harmonia
4125	Orbe Sereno
4126	Cutelo de Guerrilha
4127	Trabuco de Estilhaços
4128	Pá de Prata
4129	Bandeja de Coleta
4130	Bússola de Smotts
4131	Cinto de Corrupção
4132	Talas Lançanegra
4133	Manilhas Lançanegra
4134	Cajado Místico de Nimboya
4135	Anel Osso Sangrento
4136	Botas Lançanegra
4137	Sapatos Lançanegra
4138	Túnica de Aguanegra
4139	Sandálias do Andarilho das Selvas
4140	Dragonas de Fronde de Palmeira
4141	Tomo de Conjurar Comida
4142	Tomo de Polimorfia: Porco
4143	Tomo de Conjurar Comida II
4144	Tomo de Polimorfia: Vaca
4145	Tomo de Conjurar Gema de Mana
4146	Tomo do Polimorfo: Ovelha
4147	Tomo de Conjurar Comida III
4148	Tomo de Contrafeitiço
4149	Tomo do Escudo Gélido III
4150	Tomo de Conjurar Água IV
4151	Tomo de Seta de Gelo IV
4152	Tomo de Conjurar Comida IV
4153	Tomo de Mísseis Arcanos III
4154	Tomo de Retardar II
4155	Tomo de Elemental da Água II
4157	Tomo de Atenuar Magia
4158	Tomo de Destravamento de Hadggar III
4159	Tomo de Mísseis Arcanos
4160	Tomo de Invisibilidade
4161	Tomo de Bola de Fogo IV
4162	Tomo de Lampejo II
4164	Incunábulo: Luz Sagrada V
4165	Incunábulo: Luz Sagrada VI
4166	Incunábulo: Selo da Proteção
4167	Incunábulo: Julgamento
4168	Tabuleta de Totem Enredante
4169	Tabuleta da Vontade Obstinada II
4170	Tabuleta de Revocação Astral
4171	Tabuleta de Totem Agitador II
4172	Tabuleta de Trovoada II
4173	Tabuleta de Choque IV
4174	Tabuleta de Choque V
4175	Tabuleta de Escudo de Raios IV
4176	Tabuleta da Força Imortal II
4177	Tabuleta de Resistência à Natureza
4178	Tabuleta de Raio V
4179	Tabuleta de Restauração V
4180	Tabuleta de Forma Etérea II
4181	Tabuleta de Totem Agitador IV
4182	Tabuleta da Vontade Obstinada III
4183	Tabuleta de Totem Curativo V
4184	Tabuleta de Impacto Derretido V
4185	Tabuleta de Revocação Astral em Grupo
4186	Tabuleta de Resistência ao Fogo
4187	Tabuleta de Totem Serpente V
4188	Tabuleta de Totem de Invisibilidade
4189	Tabuleta de Cadeia de Raios
4190	Armadura com Penas
4191	Perneiras com Penas Não Usadas
4192	Manoplas com Penas Não Usadas
4194	Braçadeiras com Penas
4195	Botas com Penas
4196	Dragonas Emplumadas
4197	Ombreiras Berílias
4198	Grimório de Funil de Alma
4199	Grimório de Funil de Alma II
4200	Grimório de Imolação III
4201	Grimório de Olho de Kilrogg
4202	Grimório de Medo II
4203	Grimório de Pestilência II
4204	Grimório de Funil de Alma III
4205	Grimório de Imolação IV
4206	Grimório de Maldição de Sargeras II
4207	Grimório de Maldição de Arquimonde
4208	Grimório de Bomba Psíquica
4209	Grimório de Proteção contra Sombras
4210	Grimório de Criar Pedra-sangrenta Inferior
4211	Grimório de Pestilência
4212	Grimório de Maldição de Mannoroth III
4213	Grimório de Perdição
4214	Grimório de Drenar Vida III
4215	Grimório de Chuva de Fogo
4216	Grimório de Proteção Sagrada
4217	Grimório de Funil de Alma IV
4218	Grimório de Criar Pedra-sangrenta
4219	Grimório de Espírito Incandescente IV
4220	Grimório de Sangue Fervente III
4221	Grimório de Detectar Invisibilidade
4223	Livro de Abolir Magia
4225	Livro de Raízes Enredantes III
4226	Livro de Ira VI
4228	Livro de Fogo Lunar IV
4230	Livro de Toque de Cura VI
4231	Pelego Leve Curado
4232	Pelego Médio
4233	Pelego Médio Curado
4234	Couro Pesado
4235	Pelego Pesado
4236	Pelego Pesado Curado
4237	Cinto de Couro Feito à Mão
4238	Bolsa de Linho
4239	Luvas de Couro com Relevo
4240	Bolsa de Lã
4241	Bolsa de Lã Verde
4242	Calças de Couro com Relevo
4243	Túnica de Couro de Qualidade
4244	Colete de Couro do Montanhista
4245	Mochila Pequena de Seda
4246	Cinto de Couro de Qualidade
4247	Luvas de Couro do Montanhista
4248	Luvas de Couro Escuro
4249	Cinto de Couro Escuro
4250	Cinto do Montanhista
4251	Omoplatas do Montanhista
4252	Omoplatas de Couro Escuro
4253	Luvas de Couro Resistente
4254	Luvas Barbarescas
4255	Armadura de Couro Verde
4256	Armadura do Guardião
4257	Cinto de Couro Verde
4258	Cinto do Guardião
4259	Braçadeiras de Couro Verde
4260	Braçadeiras de Couro do Guardião
4261	Calças de Solliden
4262	Cinto de Couro Rematado de Gemas
4263	Escudo Padrão
4264	Cinto Barbaresco
4265	Kit de Armadura Pesada
4266	Códice de Fogo Interior II
4267	Códice de Palavra Sombria: Deixar Escapar
4268	Códice de Cura II
4269	Códice de Prece de Cura
4270	Códice de Cura II
4271	Códice de Punição Sagrada V
4272	Códice de Proteção Sagrada
4273	Códice de Cura
4274	Códice de Fuga Divina
4275	Códice de Putrefação da Mente
4276	Códice de Palavra Sombria: Deixar Escapar II
4277	Códice de Palavra Sombria: Estontear II
4278	Minério de Pedra-sangrenta Inferior
4279	Códice de Palavra Sombria: Dor V
4280	Códice de Palavra Sagrada: Escudo IV
4281	Códice de Proteção Sombria
4282	Códice de Dissipar Magia II
4283	Códice de Sono III
4284	Códice de Punição Sagrada VI
4285	Códice de Palavra Sagrada: Fortitude IV
4286	Códice de Prece de Cura II
4287	Códice de Anular Doença II
4288	Códice de Remover Maldição II
4289	Sal
4290	Bacia de Poeira
4291	Fio de Seda
4292	Molde: Bolsa de Lã Verde
4293	Molde: Colete de Couro do Montanhista
4294	Molde: Cinto do Montanhista
4295	Molde: Luvas de Couro de Costura Dupla VELHO
4296	Molde: Omoplatas de Couro Escuro
4297	Molde: Luvas Barbarescas
4298	Molde: Cinto do Guardião
4299	Molde: Armadura do Guardião
4300	Molde: Braçadeiras de Couro do Guardião
4301	Molde: Cinto Barbaresco
4302	Adaga Verde Pequena
4303	Espancador Craniano
4304	Couro Grosso
4305	Peça de Seda
4306	Seda
4307	Luvas Pesadas de Linho
4308	Braçadeiras de Linho Verde
4309	Culotes de Linho Costurados à Mão
4310	Luvas Pesadas de Lã
4311	Manto Pesado de Lã
4312	Botas de Linho de Sola Macia
4313	Botas de Lã Vermelhas
4314	Omoplatas de Lã em Ponto Duplo
4315	Omoplatas Reforçadas de Linho
4316	Calças Pesadas de Lã
4317	Calças da Fênix
4318	Luvas de Meditação
4319	Luvas de Seda Lazúli
4320	Botas de Sedaracna
4321	Sapatilhas de Seda de Aranha
4322	Capucho do Encantador
4323	Capuz das Sombras
4324	Colete de Seda Lazúli
4325	Botas do Encantador
4326	Manto Longo Sedoso
4327	Manto Gelado
4328	Cinto da Aranha
4329	Cinto das Estrelas
4330	Camisa Vermelha Estilosa
4331	Luvas da Fênix
4332	Camisa Amarela Berrante
4333	Camisa de Seda Preta
4334	Camisa Branca Formal
4335	Camisa Luxuosa de Seda Roxa
4336	Camisa Preta do Espadachim
4337	Seda Grossa de Aranha
4338	Magitrama
4339	Peça de Magitrama
4340	Pigmento Cinza
4341	Pigmento Amarelo
4342	Pigmento Roxo
4343	Calças de Linho Marrom
4344	Camisa de Linho Marrom
4345	Molde: Botas de Lã Vermelhas
4346	Molde: Manto Pesado de Lã
4347	Molde: Omoplatas Reforçadas de Linho
4348	Molde: Luvas da Fênix
4349	Molde: Calças da Fênix
4350	Molde: Sapatilhas de Seda de Aranha
4351	Molde: Capuz das Sombras
4352	Molde: Botas do Encantador
4353	Molde: Cinto da Aranha
4354	Molde: Camisa Luxuosa de Seda Roxa
4355	Molde: Manto Gelado
4356	Molde: Cinto das Estrelas
4357	Pó Explosivo Grosseiro
4358	Dinamite Grosseira
4359	Punhado de Parafusos de Cobre
4360	Bomba Grosseira de Cobre
4361	Tubo de Cobre
4362	Cano de Atirar Rudimentar
4363	Modulador de Cobre
4364	Pó Explosivo Granuloso
4365	Dinamite Granulosa
4366	Boneco-alvo
4367	Carga Pequena de Cequatrum
4368	Óculos de Tigre Voador
4369	Bacamarte Mortal
4370	Bomba Grande de Cobre
4371	Tubo de Bronze
4372	Cano de Atirar Feito com Carinho
4373	Óculos Sombrios
4374	Bomba Pequena de Bronze
4375	Tranqueira Zumbidora de Bronze
4376	Defletor de Chamas
4377	Pó Explosivo Pesado
4378	Dinamite Pesada
4379	Espingarda Folheada a Prata
4380	Bomba Grande de Bronze
4381	Rebotocador Menor
4382	Estrutura de Bronze
4383	Rifle Miraluna
4384	Ovelha Explosiva
4385	Óculos Tintos de Verde
4386	Defletor de Gelo
4387	Escora de Ferro
4388	Raio Abotocador
4389	Giroscronatom
4390	Granada de Ferro
4391	Kit de Ceifa-colheitas Compacto
4392	Boneco-alvo Avançado
4393	Monóculo do Artífice
4394	Bomba Grande de Ferro
4395	Mina Terrestre Goblínica
4396	Dragonete Mecânico
4397	Dispositivo Ocultador Gnômico
4398	Carga Grande de Cequatrum
4399	Coronha de Madeira
4400	Coronha Pesada
4401	Caixa de Esquilo Mecânico
4402	Pequena Bolsa de Chamas
4403	Morteiro Portátil de Bronze
4404	Contato de Prata
4405	Mira Rudimentar
4406	Mira Padrão
4407	Mira de Precisão
4408	Diagrama: Esquilo Mecânico
4409	Diagrama: Carga Pequena de Cequatrum
4410	Diagrama: Óculos Sombrios
4411	Diagrama: Defletor de Chamas
4412	Diagrama: Rifle Miraluna
4413	Diagrama: Raio Abotocador
4414	Diagrama: Morteiro Portátil de Bronze
4415	Diagrama: Monóculo do Artífice
4416	Diagrama: Mina Terrestre Goblínica
4417	Diagrama: Carga Grande de Cequatrum
4419	Pergaminho do Intelecto III
4421	Pergaminho de Proteção III
4422	Pergaminho do Vigor III
4424	Pergaminho do Espírito III
4425	Pergaminho de Agilidade III
4426	Pergaminho de Força III
4428	Palpo de Aranha
4429	Ordens do Fundafúria
4430	Talismã Etéreo
4432	Carta de Floriano Caxias
4433	Envelope Ensopado
4434	Calças de Espantalho
4435	Partícula de Myzrael
4436	Faixa Incrustada de Joias
4437	Cajado do Canalizador
4438	Braçadeiras de Pugilista
4439	Clava do Bordoeiro
4440	Signo de Strom
4441	Pinga de Mackreel
4443	Brafoneiras Inflexíveis
4444	Escudo de Casca Preta
4445	Escava-carne
4446	Lâmina Peçonha Negra
4447	Manto da Noite
4448	Carapaça de Naraxis
4449	Presa de Naraxis
4450	Fragmento de Signo
4453	Signo de Thoradin
4454	Garra de Vultros
4455	Arnês de Pelego de Raptor
4456	Cinto de Pelego de Raptor
4457	Asa de Urubu Grelhada
4458	Signo de Arathor
4459	Osso Quebradiço de Dragão
4460	Cincha Alada Rasgada
4461	Pelego de Raptor
4462	Manto de Putrefação
4463	Colar de Contas de Raptor
4464	Botas Espancadoras
4465	Manoplas Punho de Osso
4466	Signo de Matatroll
4467	Signo de Ígnaeus
4468	Trol'kalar Embainhada
4469	Bastão de Ordem
4470	Madeira Simples
4471	Pederneira e Lenha
4472	Pergaminho de Myzrael
4473	Grilhões Sobrenaturais
4474	Arco de Madeira de Corvo
4476	Veste do Caminhante Ferino
4477	Broquel Nefasto
4478	Perneiras de Escama Iridescente
4479	Patuá Ardente
4480	Patuá Trovejante
4481	Patuá Pontudo
4482	Pasta Lacrada
4483	Chave Ardente
4484	Chave Troante
4485	Chave Trovejante
4487	Mapas da Extravagância da Donzela
4488	Mapas do Espírito de Pinhaprata
4489	Diário de Bordo da Extravagância da Donzela
4490	Diário de Bordo do Espírito de Pinhaprata
4491	Óculos para Caçar Gemas
4492	Gema Élfica
4493	Gemas Élficas
4494	Carta Lacrada do Chifre do Mar
4495	Amuleto de Pedra-sangrenta
4496	Bolsa Marrom Pequena
4497	Bolsa Marrom Pesada
4498	Bolsa de Couro Marrom
4499	Saco Marrom Enorme
4500	Mochila do Viajante
4502	Amostra de Gema Élfica
4503	Presa de Cascasseca
4504	Manto de Guarda Anão
4505	Calças das Terras Pantanosas
4506	Insígnia de Stromgarde
4507	Escudo do Lutador do Fosso
4508	Armadura Tingida de Sangue
4509	Luvas Lobo-do-mar
4510	Orbe de Pedra-sangrenta Conspurcado
4511	Martelo Água Negra
4512	Olho de Raptor do Planalto
4513	Coração de Raptor
4514	Apelo de Sara Caxias
4515	Cabeça de Marez
4516	Cabeça de Otto
4517	Cabeça de Falcocrista
4518	Fragmento de Pergaminho Rasgado
4519	Fragmento de Pergaminho Amassado
4520	Fragmento de Pergaminho Chamuscado
4521	Granito de Alterac
4522	Bolsa Medicinal de Cascasseca
4524	Memorial a Caxias
4525	Varinha de Evocação de Trelane
4526	Amuleto de Garra de Raptor
4527	Ágata Lazúli
4528	Orbe de Tor'gan
4529	Ágata Encantada
4530	Filactério de Trelane
4531	Orbe de Trelane
4532	Ágata-de-fogo de Trelane
4533	Carta Lacrada para o Arquimago Malin
4534	Braçadeiras com Fecho de Aço
4535	Anel Comemorativo de Altaforja
4536	Maçã Vermelha Brilhante
4537	Banana de Tel'Abim
4538	Melancia Estala-vinha
4539	Maçã Casca-dourada
4540	Naco de Pão Duro
4541	Pão Fresquinho
4542	Broa de Milho Molhadinha
4543	Casquete de Pele de Draco Branco
4544	Pão Condimentado de Mulgore
4545	Braçadeiras de Prata Radiante
4546	Chamado do Raptor
4547	Fulminador Gnômico
4548	Marrão Servomecânico
4549	Elo Fogo-do-mar
4550	Anel Água Fria
4551	Cabeça de Or'Kalar
4552	Lasca de Pedra Lisa
4553	Pedaço de Pedra Pontudo
4554	Pedra Polida Brilhosa
4555	Cauda Escamosa Grossa
4556	Pedaço de Concha Manchada
4557	Glândula Abrasadora
4558	Barril Vazio
4559	CHU's QUEST ITEM
4560	Cimitarra de Qualidade
4561	Machadinha de Escalpelamento
4562	Machado Decepante
4563	Clava do Billy
4564	Clava com Pontas
4565	Adaga Simples
4566	Bastão de Luta Resistente
4567	Espada Mercenária
4568	Machado do Recruta
4569	Martelo Leal
4570	Malho de Bétula
4571	Faca de Guerra
4575	Cajado Medicinal
4576	Arco Leve
4577	Espingarda Compacta
4580	Presa de Dente-de-sabre
4581	Tufo de Pele Fino
4582	Cauda Pompom Macia
4583	Juba Peluda Grossa
4584	Troféu de Pata Gigante
4585	Mandíbula de Aranha Babujante
4586	Pele Lisa de Raptor
4587	Penas de Raptor Tribal
4588	Crânio Impoluto de Raptor
4589	Pena Longa Elegante
4590	Bico Amarelo Curvado
4591	Olho de Águia
4592	Pargo-da-lama Bocalonga
4593	Bagre de Bigode Cerdoso
4594	Bacalhau Escama-de-pedra
4595	Vinho Selvavinha
4596	Poção Descolorida de Cura
4597	Receita: Poção Descolorida de Cura
4598	Vara Goblínica de Pesca
4599	Peça de Presunto Curado
4600	Grogue de Cereja
4601	Pão de Banana Macio
4602	Abóbora da Colheita Lunar
4603	Rabo-amarelo Mosqueado Cru
4604	Cogumelo da Floresta
4605	Cogumelo de Bolinhas Vermelhas
4606	Morel Esponjoso
4607	Mofo de Caverna Delicioso
4608	Trufa Preta Crua
4609	Receita: Asa de Urubu Grelhada
4610	Urna de Pedra com Gravuras
4611	Pérola Azul
4612	Coração de Draco Preto
4613	Caixa Preta Corroída
4614	Pingente de Myzrael
4615	Braçadeiras de Neraçoite
4616	Picareta da Sorte de Ryedol
4621	Braçadeira do Embaixador Infernus
4622	Bilhete Lacrado para o Conselheiro Belgrum
4623	Poção Inferior de Escudopétreo
4624	Receita: Poção de Escudopétreo Inferior
4625	Ignídea
4626	Estilhaço Pequeno de Pedra
4627	Laje Grande
4628	Braçadeiras de Liga de Pedra
4629	Caixote de Suprimentos
4630	Sucata
4631	Tabuleta de Ryun'eh
4632	Cofre de Bronze Ornado
4633	Cofre de Bronze Pesado
4634	Cofre de Ferro
4635	Amuleto do Pé-de-malho
4636	Cofre Robusto de Ferro
4637	Cofre de Aço
4638	Cofre de Aço Reforçado
4639	Alga Marinha Encantada
4640	Signo da Terra
4641	Mão de Dagun
4643	Capa de Aço Inexorável
4644	O Coração da Herança
4645	Grilhões de Hematus
4646	Estrela de Xil'yeh
4647	Compêndio de Yagyin
4648	Signo do Martelo
4649	Bilhete de Agarrosso
4650	Bilhete de Bel'dugur
4652	Escudo Salbac
4653	Botas Talão-de-ferro
4654	Fóssil Misterioso
4655	Carne de Marisco Gigante
4656	Abóbora Pequena
4658	Manto do Guerreiro
4659	Cinturão do Guerreiro
4660	Botas de Caminhada
4661	Dragonas Brilhantes
4662	Manto do Profissional
4663	Cinto do Profissional
4665	Manto Queimado
4666	Cinto de Couro Queimado
4668	Manto Encadeado de Batalha
4669	Cinturão Encadeado de Batalha
4671	Manto Ancestral
4672	Cinto Ancestral
4674	Manto Tribal
4675	Cinto Tribal
4676	Manoplas Esqueléticas
4677	Manto do Veterano
4678	Cinturão do Veterano
4680	Manto Salobro
4681	Cinturão Salobro
4683	Manto Mesmerizador
4684	Cinto Mesmerizador
4686	Manto de Tecido Barbaresco
4687	Cinto de Tecido Barbaresco
4689	Manto de Caça
4690	Cinto de Caça
4692	Manto Cerimonial
4693	Cinto Cerimonial de Couro
4694	Brafoneiras Lustradas
4695	Manto Lustrado
4696	Caneca Bebemares de Lápidis
4697	Cinturão Lustrado
4698	Dragonas do Vidente
4699	Cinto do Vidente
4700	Espaldares de Couro Inscritos
4701	Manto Inscrito
4702	Picareta do Prospector
4703	Ferramentas Quebradas
4705	Brafoneiras Bruxuleantes de Escama
4706	Manto Bruxuleante de Escama
4707	Cinturão Bruxuleante de Escama
4708	Cinto Brilhante
4709	Dragonas de Couro da Floresta
4710	Manto da Floresta
4711	Manto Furta-cor
4712	Cinturão de Malha Furta-cor
4713	Manto de Fio de Prata
4714	Faixa de Fio de Prata
4715	Manto Brasonado
4716	Manto de Combate
4717	Cinto de Combate de Malha
4718	Dragonas do Céu Noturno
4719	Manto do Céu Noturno
4720	Faixa do Céu Noturno
4721	Dragonas com Insígnia
4722	Manto com Insígnia
4723	Calças do Humberto
4724	Elmo do Humberto
4725	Brafoneiras do Brigadeiro-chefe
4726	Manto do Brigadeiro-chefe
4727	Cinturão do Brigadeiro-chefe
4728	Ombreiras do Toninho
4729	Dragonas da Aurora
4731	Palas Glíficas
4732	Manto Glífico
4733	Brafoneiras Forja Negra
4734	Dragonas Enevoadas
4735	Manto Enevoado
4736	Faixa Enevoada
4737	Espaldares Imperiais de Couro
4738	Cinto Imperial de Couro
4739	Carne de Pinote
4740	Pena de Pinote
4741	Perneiras de Cavalaria de Stromgarde
4742	Pelagem de Puma da Montanha
4743	Estilhaço Cristalino Pulsante
4744	Braçadeiras Arcanas com Runas
4745	Braçadeiras de Mantícora de Batalha
4746	Veste do Agourento
4747	Água do Poço Touro Tormenta
4748	Água do Poço Tromparrubra
4749	Água do Poço Juba Agreste
4751	Garra de Ventofúria
4752	Pena Lazúli
4753	Pena Bronze
4755	Jarra d'Água
4756	Pelagem de Gato Arruinada
4757	Casca Rachada de Ovo
4758	Pata de Lobo-da-pradaria
4759	Garra de Pinote
4763	Arco Recurvo de Bosquenero
4765	Espada Larga Esmaltada
4766	Lâmina Feral
4767	Luvas de Trama Cúprica
4768	Luvas do Adepto
4769	Troféu de Cálamo de Rapineiro
4770	Cinto de Costagulha
4771	Manto da Colheita
4772	Manto Cálido
4775	Bico Rachado
4776	Pena Eriçada
4777	Malho de Pau-ferro
4778	Maça Pesada com Pontas
4779	Dente Fosco de Kodo
4780	Fragmento de Chifre de Kodo
4781	Colete Sussurrante
4782	Veste do Solstício
4783	Totem do Vento do Falcão
4784	Pedra sem Vida
4785	Cinto Sulfúreo
4786	Cinto do Homem Sábio
4787	Piche Ardente
4788	Botas Ágeis
4789	Botas Estáveis
4790	Manto Infernal
4791	Água Encantada
4792	Manto dos Espíritos
4793	Manto Silvestre
4794	Braçadeiras do Lobo
4795	Braçadeiras do Urso
4796	Braçadeiras da Coruja
4797	Manto Ígneo
4798	Manto Rúnico Pesado
4799	Manto Antiquado
4800	Calças Encadeadas Potentes
4801	Garras de Espreitador
4802	Garras de Puma
4803	Dente de Lobo-da-pradaria Alfa
4804	Coração de Lobo-da-pradaria
4805	Fêmur de Puma das Estepes
4806	Escama de Pinote
4807	Moela de Rapineiro
4808	Pedra de Poço
4809	Pinhâmbar
4810	Ombreiras do Penedo
4813	Coleira de Couro Pequena
4814	Presa Descolorida
4816	Perneiras do Legionário
4817	Espadão Abençoado
4818	Espada do Carrasco
4819	Prancheta do Geringonça
4820	Broquel do Guardião
4821	Broquel do Urso
4822	Disco da Coruja
4823	Água dos Videntes
4824	Machado Sujo
4825	Machado Caloso
4826	Machado do Espoliador
4827	Cinto do Teurgo
4828	Cinto do Vento Noturno
4829	Cinto do Sonhador
4830	Perneiras do Sabre
4831	Calças de Espreitar
4832	Sarongue Místico
4833	Omoplatas Gloriosas
4834	Documentos da Empreendimentos S.A.
4835	Omoplatas de Elite
4836	Orbe à Prova de Fogo
4837	Força de Vontade
4838	Orbe do Poder
4840	Baioneta Longa
4841	Chifre de Arra'chea
4843	Pedra Rúnica de Ametista
4844	Pedra Rúnica de Opala
4845	Pedra Rúnica de Diamante
4846	Engrenagem Nº 5
4847	Grilhões de Laço Elemental do Lotwil
4848	Focinho de Javaliço
4849	Flanco de Javaliço
4850	Plano de Ataque dos Costagulha
4851	Mapa Sujo de Terra
4852	Bomba de Clarão
4854	Manto Marcado por Demônios
4855	Unused Cloth Shoulder A01 Gray
4856	Ombreira de Tecido Não Usada A02 Amarela
4857	Ombreira de Tecido Não Usada B01 Prata
4858	Ombreira de Tecido Não Usada A02 Preta
4859	Medalhão da Lâmina Ardente
4860	Escama Fúlgida de Farnesim
4861	Túnica de Plumas
4862	Cauda de Escorpídeo Operário
4863	Ferramentas Gnômicas
4864	Crânio de Minshina
4865	Pelagem Arruinada
4866	Cabeça do Zalazane
4867	Perna Quebrada de Escorpídeo
4869	Garra do Bulho
4870	Retalho de Lona
4871	Colar Calcinante
4872	Olho Seco de Escorpídeo
4873	Craca Dura e Seca
4874	Espinhas Limpas
4875	Osso Enlameado
4876	Botas de Couro Ensanguentadas
4877	Ponta de Flecha de Pedra
4878	Arco Quebrado Manchado de Sangue
4879	Carcaça de Coelho Esmagado
4880	Lança Quebrada
4881	Envelope Envelhecido
4882	Chave de Bento
4883	Ordens do Almirante Proudmore
4886	Vesícula de Veneno de Caudaçonha
4887	Olho de Makrura Intacto
4888	Muco de Rastejante
4890	Ovo de Açoitacauda
4891	Amuleto de Kron
4892	Pele de Tigre de Durotar
4893	Presa de Leão da Savana
4894	Rim de Pinote
4895	Cifre de Lagarto Trovejante
4896	Fígado de Kodo
4897	Glândula Salivar de Falcotrom
4898	Glândula Relampejante
4903	Olho da Sombra Ardente
4904	Antídoto para Caudaçonha
4905	Garra Mutilada de Sarkoth
4906	Botas do Pé d'Água
4907	Túnica do Bosque
4908	Braçadeiras Nômades
4909	Perneiras do Caçador de Kodos
4910	Luvas Encadeadas Pintadas
4911	Broquel de Casca Grossa
4913	Cinto Encadeado Pintado
4914	Luvas de Couro Desgastadas em Batalha
4915	Botas de Casimira
4916	Colete de Casimira
4917	Perneiras Encadeadas Desgastadas em Batalha
4918	Saco de Suprimentos
4919	Cinto de Casimira
4920	Capa Desgastada em Batalha
4921	Perneiras Empoeiradas
4922	Colete Encadeado Serrilhado
4923	Machadinha Primitiva
4924	Clava Primitiva
4925	Navalha Primitiva
4926	Barril Vazio do Chen
4928	Munhequeiras do Corredor da Areia
4929	Armadura Escorpídea Leve
4930	Bolsa de Couro Artesanal
4931	Arco Curto de Nogueira
4932	Corta-asa-de-harpia
4933	Manto do Lutador Experiente
4935	Cinturão Largo de Metal
4936	Botas Sujas de Barro
4937	Broquel de Carga
4938	Cajado de Madeira Manchado
4939	Espada Bastarda Firme
4940	Guantes Velados
4941	Cola Grudenta à Beça
4942	Botas de Pelego de Tigre
4944	Manto Costurado à Mão
4945	Crânio Levemente Faiscante
4946	Botas Leves
4947	Adaga Serrilhada
4948	Maça Pungente
4949	Cutelo Orc
4951	Cinto do Grunhido
4952	Malte do Trovão
4953	Cerveja Trogg
4954	Cinto Nômade
4957	Porta-moedas Velho
4958	Manto Insolado
4959	Machadinha de Arremesso
4960	Projétil Faiscante
4961	Cajado do Velador de Sonhos
4962	Luvas de Duas Camadas
4963	Manto Chifre Troante
4964	Esmaga-goblin
4965	Machado Pequeno Casco Sangrento
4966	Cabeça do Mazzranache
4967	Escudo do Guerreiro Tribal
4968	Arnês Atado
4969	Guarda-braços Reforçados
4970	Perneiras Rústicas de Kodo
4971	Martelo de Skorn
4972	Botas do Corremontes
4973	Munhequeiras do Caçador das Planícies
4974	Punhal de Combate
4975	Broquel Vigilante
4976	Kilt Brumaceiro
4977	Espada de Ruína do Martelo
4978	Martelo de Ryedol
4979	Braçadeiras de Panopétreo Encantadas
4980	Luvas de Prospector
4981	Bornal de Cinto de Agmundo
4982	Cinturão Rasgado de Prospector
4983	Pulverizador de Rochas
4984	Crânio do Destino Iminente
4986	Pedra do Poder Defeituosa
4987	Espada de Capitão dos Anões
4988	Elo Obsidiano Ardente
4989	Veste de Dragão-mago
4990	Embraces Calcinados
4992	Carta de Recrutamento
4995	Carta de Recrutamento Assinada
4998	Anel de Sangue
4999	Vontade de Azora
5000	Anel de Coral
5001	Anel do Coração
5002	Talismã Verde Faiscante
5003	Medalhão de Cristal do Fogo Estelar
5004	Marca do Kirin Tor
5005	Pingente Brasardente
5006	Diário de Khazgorm
5007	Anel de Espinhos
5008	Anel de Mercúrio
5009	Anel Pasmante
5010	Anel de Ouro Inscrito
5011	Anel Celeste
5012	Esporos de Fungos
5013	Bulbo Fértil
5014	Wrapping Paper (PT)
5015	Wrapped Item (PT)
5016	Calças do Artífice
5017	Nitroglicerina
5018	Polpa de Madeira
5019	Nitrato de Sódio
5020	Chave do Butim de Kolkar
5021	Banana de Dinamite de Gann
5022	Cabeça do Findekodo
5023	Cabeça do Verog
5024	Ampola Gélida
5025	Cabeça do Hezrul
5026	Piche Ígneo
5027	Esporos Entregues
5028	Cetro de Lorde Sakrasis
5029	Talismã do Lorde Naga
5030	Braçadeiras de Centauro
5038	Lágrima das Luas
5040	Faca de Caçador Sombrio
5042	Papel de Embrulho com Fita Vermelha
5043	Presente com Fita Vermelha
5044	Presente com Fita Azul
5045	Presente de Crânio
5046	Presente Fechado
5047	Papel de Embrulho de Caveira
5048	Papel de Embrulho com Fita Azul
5049	Papel-ferro Autotrancante
5050	Chave de Ignição
5051	Ratoupeira
5052	Ratoupeira Inconsciente
5054	Rebimboca
5055	Chifre Intacto de Raptor
5056	Amostra de Raiz
5057	Melancia Madura
5058	Ovo de Silitídeo
5059	Garra de Escavação
5060	Ferramentas de Ladrões
5061	Prata Roubada
5062	Cabeça de Raptor
5063	Presa de Kreenig Rosnento
5064	Garra de Asabruxa
5065	Anel de Tenente Harpia
5066	Planta da Fenda
5067	Cabeça da Serena
5068	Sementes Secas
5069	Varinha de Fogo
5071	Varinha Sombria
5072	Crânio de Lok
5073	Crânio de Nak
5074	Crânio de Kaz
5075	Estilhaço de Sangue
5076	Carregamento de Botas
5077	Lente Telescópica
5078	Medalha de Theramore
5079	Olho Frio de Basilisco
5080	Livro-caixa do Gasganete
5081	Bolsa de Pelego de Kodo
5082	Couro Fino de Kodo
5083	Molde: Bolsa de Pelego de Kodo
5084	Cabeça do Barão Longacosta
5085	Presa de Javatusco Costagulha
5086	Cascos de Zevra
5087	Bico de Pinote
5088	Manual de Operação do Console de Controle
5089	Chave do Painel
5092	Varinha de Crinavalha Carbonizada
5093	Punhal Crinavalha
5094	Escudo de Guerra Crinavalha
5095	Albacora Arco-íris
5096	Garras de Predador
5097	Esmeralda Olho-de-gato
5098	Casco Alterado de Mordelisca
5099	Casco de Lakota'mani
5100	Pelego de Echeyaki
5101	Presa de Ishamuhale
5102	Ponta da Cauda de Owatanka
5103	Pena de Anhan Guera
5104	Coração de Isha Awak
5105	Cápsula Explosiva
5107	Camisa de Marujo
5108	Couro Ferro Negro
5109	Farrapos dos Lascapedra
5110	Veste do Teurgo de Dalaran
5111	Capa do Rathorian
5112	Lâmina de Ritual
5113	Marca da Camarilha
5114	Garra Decepada
5115	Fúrcula Quebrada
5116	Pena Longa de Cauda
5117	Pluma Vibrante
5118	Dente Grande e Chato
5119	Cabelos Finos Soltos
5120	Pelo de Cauda Longo
5121	Escama Suja de Kodo
5122	Pelo Grosso de Kodo
5123	Ponta de Flecha de Aço
5124	Dente Pequeno de Raptor
5125	Escama Carregada
5126	Conhecimento: Disfarce Défias
5127	Conhecimento: Máscara de Pirata dos Mares do Sul
5128	Pele de Lagarto Caída
5129	Conhecimento: Disfarce de Anão Ferro Negro
5130	Conhecimento: Disfarce de Teurgo de Dalaran
5131	Conhecimento: Disfarce dos Lascapedra
5132	Conhecimento: Disfarce da Camarilha
5133	Moela Pingante
5134	Pequena Pata Peluda
5135	Garra Preta Fina
5136	Orelha Peluda Arrancada
5137	Globo Ocular Brilhante
5138	Cabeça do Segador
5139	Livro de Espinhos
5140	Pó de Clarão
5141	Livro de Recrescimento
5142	Livro de Ira II
5143	Sangue de Lagarto Trovejante
5145	Livro de Toque de Cura II
5147	Livro de Raízes Enredantes II
5148	Livro de Espinhos II
5149	Livro de Ira III
5150	Livro de Toque de Cura III
5151	Livro de Ira IV
5152	Livro de Toque de Cura IV
5153	Livro de Marca do Indomado IV
5154	Livro de Espinhos III
5155	Livro de Marca do Indomado II
5156	Livro de Ira V
5158	Livro de Tranquilidade
5160	Livro de Toque de Cura V
5163	Livro de Marca do Indomado III
5164	Asas de Falcotrom
5165	Pena de Helióscamo
5166	Vesícula de Peçonha de Lenhateia
5167	Ovo de Lenhateia
5168	Semente de Muscoide
5169	Broto de Muscoide
5170	Tumor Musguento
5172	Cápsula da Morte
5173	Vinha-da-morte
5174	Bilhete de Neeru
5175	Totem da Terra
5176	Totem do Fogo
5177	Totem da Água
5178	Totem do Ar
5179	Coração Enroscado em Musgo
5180	Colar da Harmonia
5181	Capa de Seda Vibrante
5182	Lâmina do Calafrio
5183	Coração Pulsante de Hidra
5184	Frasco de Cristal Cheio
5185	Frasco de Cristal
5186	Recipiente Parcialmente Cheio
5187	Martelo de Rhahk'Zor
5188	Recipiente Cheio
5189	Fruta Brilhante
5190	Fronde Cintilante
5191	Farpa Cruel
5192	Lâmina do Ladrão
5193	Capa da Irmandade
5194	Machado do Capataz
5195	Luvas Salpicadas de Ouro
5196	Aniquilador do Castiga
5197	Amaciante do Cuca
5198	Cajado Mexedor do Cuca
5199	Calças de Fundição
5200	Arpão de Empalamento
5201	Cajado da Pedra Incandescente
5202	Pulôver do Corsário
5203	Garra de Predador das Estepes
5204	Cinto Plumassangue
5205	Fronde Desenvolvida
5206	Raiz de Brejicola
5207	Varinha Opaca
5208	Varinha Fumegante
5209	Varinha Merencória
5210	Varinha Incandescente
5211	Varinha do Crepúsculo
5212	Varinha Fulgurante
5213	Varinha Calcinante
5214	Varinha do Entardecer
5215	Varinha Incandescente
5216	Varinha do Umbral
5217	Coração Maculado
5218	Coração Purificado de Muscoide
5219	Casca de Árvore Inscrita
5220	Presa de Masca-pinho
5221	Cabeça de Málinus
5223	Gema de Mana Vazia
5227	Joia de Mana Vazia
5229	Pedra-sangrenta Maior Vazia
5232	Pedra da Alma Menor
5233	Pedra de Relu
5234	Fóssil do Pançacheia
5235	Varinha do Alquimista
5236	Varinha Inflamável
5237	Veneno Entorpecente
5238	Varinha Resinada
5239	Varinha de Osso Preto
5240	Varinha de Luz da Tocha
5241	Vara-lume Enânica
5242	Varinha de Cinzas
5243	Arrota-fogos
5244	Varinha Consagrada
5245	Varinha do Evocador
5246	Bastão de Escavação
5247	Bastão da Tristeza
5248	Varinha Faiscante
5249	Lasca Ardente
5250	Varinha Carbonizada
5251	Frasco de Vidência
5252	Varinha de Apodrecimento
5253	Disparador Goblínico
5254	Espaldares Rústicos
5255	Machadinha Javatusca
5256	Chocalho do Kovork
5257	Capa com Capuz Escura
5259	Monstro - Arco, Vermelho
5263	Fiapo de Bolso
5264	Ficha de Cerveja Grátis
5265	Cerveja Aguada
5266	Olho de Adaegus
5267	Cris Escarlate
5268	Casca Rachada de Silitídeo
5269	Linfa Silitídea
5270	Cogumelo-cicuta
5271	Galho de Piolho
5272	Rabiscos Malucos
5273	Relíquia de Mathistra
5274	Dragonas Rosas
5275	Cinturão do Vínculo
5279	Esfolador de Harpia
5299	Luvas da Lua
5302	Broquel de Cobalto
5306	Cajado da Mantícora
5309	Mosquete do Corsário
5310	Culotes de Lobo-do-mar
5311	Botas com Fivelas
5312	Manoplas Rebitadas
5313	Anel do Clã Totêmico
5314	Capa do Caçador de Javalis
5315	Guarda-braços das Terras Florestais
5316	Túnica de Couraça Lenhosa
5317	Túnica de Musgo Seco
5318	Machado de Zhovur
5319	Brafoneiras Espancadoras
5320	Botas Lamelares Acolchoadas
5321	Espada Curta Elegante
5322	Martelo da Demolição
5323	Lanterna do Brilho Eterno
5324	Martelo do Engenheiro
5325	Escudo de Soldagem
5326	Bastão Ígneo
5327	Calças Graxentas do Faz-tudo
5328	Cinto Cingido
5329	Estatueta de Gato
5330	Relíquia de Taça Élfica
5332	Estatueta de Gato Faiscante
5334	Xerez de 99 Anos
5335	Saco de Moedas
5336	Brinco de Capeta
5337	Luvas da Jornada
5338	Selo Antigo de Pedra-da-lua
5339	Ofídea
5340	Mexedor de Caldeirão
5341	Túnica Coberta de Esporos
5342	Ponche de Raptor
5343	Manto de Taberneiro
5344	Machado Pontudo
5345	Martelo de Petralenha
5346	Arco de Batalha Órquico
5347	Varinha Pestilenta
5348	Pergaminho Gasto
5349	Muffin Conjurado
5350	Água Conjurada
5351	Anel do Caçador de Recompensas
5352	Livro: Os Poderes de Baixo
5353	Mensagem para Elissa Brisastral
5354	Carta para Dinis
5355	Cinturão do Senhor das Feras
5356	Bastão de Marcar
5357	Protetor do Vale
5359	Manuscrito de Lorgalis
5360	Relíquia dos Altaneiros
5361	Palito de Dente de Espinha de Peixe
5362	Brinquedinho de Morder
5363	Lenço Dobrado
5364	Pedra de Sal Seca
5366	Gema Anímica Faiscante
5367	Ferramenta Primitiva de Rocha
5368	Carteira Vazia
5369	Osso Roído
5370	Colher Torta
5371	Pedaço de Coral
5373	Patuá da Sorte
5374	Relógio de Bolso Pequeno
5375	Graveto para Coçar
5376	Espelho Quebrado
5377	Concha de Vieira
5379	Faca de Bota
5380	Carta Lacrada para Elissa
5381	Carta Lacrada para Balthule
5382	Pingente de Anaya
5383	Cabeça do Athrikus Narassin
5385	Pata de Rastejante
5386	Pelagem de Espreitaluna Fina
5387	Manto Encantado de Espreitaluna
5388	Crânio de Ran Dente Sangrento
5389	Totem de Pelurso Corrompido
5390	Mensagem de Fandral
5391	Terra Rara
5392	Adaga de Pau-cardo
5393	Cajado de Pau-cardo
5394	Luvas de Treinamento em Arco e Flecha
5395	Escudo do Bosque
5396	Chave da Garganta Abrasadora
5397	Pólvora Défias
5398	Perneiras das Frondes
5399	Botas de Rastrear
5400	Sangue de Cobrahn
5401	Sangue de Pítias
5402	Sangue de Sucurina
5403	Sangue de Serpentis
5404	Omoplatas da Serpente
5405	Manto Drapejado
5406	Pedra-sangrenta Menor Vazia
5411	Totem de Purificação Casco Invernal
5412	Olho de Mangual
5413	Presa de Espreitaluna
5414	Escalpo Grisalho
5415	Totem de Purificação Chifre Troante
5416	Totem de Purificação Juba Agreste
5419	Braçadeiras Ferais
5420	Armadura da Banshee
5421	Encantamento de Labareda Abrasadora
5422	Perneiras de Erva-espinho
5423	Presa de Jibohm
5424	Estatueta Ancestral
5425	Cinturão de Escama Rúnica
5426	Beijo da Serpente
5427	Relógio de Bolso Bruto
5428	Um Livro de Receitas Exótico
5429	Uma Pedra Bonitinha
5430	Quinquilharia Trabalhada
5431	Odre Vazio
5432	Cachimbo de Nogueira
5433	Boneca de Pano
5435	Bruguzumba Brilhante
5437	Cabelo-de-bathran
5439	Aljava Pequena
5440	Garrafa de Moléstia
5441	Bornal Pequeno para Projéteis
5442	Cabeça de Arugal
5443	Broquel de Placas de Ouro
5444	Capa do Minerador
5445	Anel de Zoram
5446	Braçadeira Elemental Quebrada
5447	Braçadeira Elemental Danificada
5448	Braçadeira Elemental Fraturada
5451	Braçadeira Elemental Esmagada
5455	Pergaminho Vaticinado
5456	Pergaminho Divinatório
5457	Garra de Vodu Partida
5458	Cinto Bosque de Terra
5459	Machado Defensor
5460	Cura de Orendil
5461	Ramo de Cenarius
5462	Bastão de Transformação de Dartol
5463	Gema Faiscante
5464	Haste de Ferro
5465	Perna Pequena de Aranha
5466	Aguilhão de Escorpídeo
5467	Carne de Kodo
5468	Carne Macia de Farnesim
5469	Carne de Moa
5470	Rabo de Lagarto Trovejante
5471	Carne de Cervo
5472	Kebab Kaldorei de Aranha
5473	Escondidinho de Escorpídeo
5474	Carne Assada de Kodo
5475	Chave de Madeira
5476	Filé de Farnesim
5477	Ensopado de Moa
5478	Ensopado de Ratoupeira
5479	Rabo de Lagarto Crocante
5480	Carne Magra de Caça
5481	Chifres de Sátiro
5482	Receita: Kebab Kaldorei de Aranha
5483	Receita: Escondidinho de Escorpídeo
5484	Receita: Carne Assada de Kodo
5485	Receita: Filé de Farnesim
5486	Receita: Ensopado de Moa
5487	Receita: Ensopado de Ratoupeira
5488	Receita: Rabo de Lagarto Crocante
5489	Receita: Carne Magra de Caça
5490	Cabeça de Iracauda
5493	Lágrima de Eluna
5494	Punhado de Poeira Estelar
5498	Perolinha Lustrosa
5500	Pérola Iridescente
5503	Carne de Marisco
5504	Carne de Marisco Pungente
5505	Diário de Teronis
5506	Talo de Olhinho Vil
5507	Luneta Ornada
5508	Pedra-da-lua Caída
5509	Pedra de Vida
5510	Pedra de Vida Maior
5511	Pedra de Vida Inferior
5512	Pedra de Vida Menor
5513	Jade de Mana
5514	Ágata de Mana
5516	Presa de Manguadonte
5517	Chavinha de Bronze
5518	Chavinha de Ferro
5519	Castão de Ferro
5520	Diário de Velinde
5521	Chave de Velinde
5522	Pedra Mágica
5523	Marisquinho com Cracas
5524	Marisco de Casca Grossa
5525	Mariscos Fervidos
5526	Ensopado de Marisco
5527	Marisco à la Goblin
5528	Receita: Ensopado de Marisco
5529	Poeira de Tumba
5530	Pó Cegante
5533	Tomo de Ilkrud Magthrull
5534	Almoço do Florestan
5535	Compêndio dos Caídos
5536	Mitologia dos Titãs
5537	Cabeça do Sarilus Malnato
5538	Aliança de Casamento de Vorrel
5539	Carta de Comenda
5540	Adaga com Cabo de Madrepérola
5541	Martelo Iridescente
5542	Manto com Fecho de Pérola
5543	Instruções: Martelo Iridescente
5544	Crânio de Dal Sangarra
5547	Bastão Reconstruído
5565	Pedra Infernal
5566	Galhada Quebrada
5567	Gancho de Prata
5568	Cascalho Liso
5569	Algas Marinhas
5570	Ovo de Aranha de Fundolimo
5571	Bolsa Preta Pequena
5572	Bolsa Verde Pequena
5573	Bolsa de Couro Verde
5574	Bolsa de Couro Branca
5575	Saco Verde Grande
5576	Saco Marrom Grande
5577	Instruções: Braçadeiras Rústicas de Bronze
5578	Instruções: Peitoral de Bronze Prateado
5579	Martelo de Guerra de Milícia
5580	Martelo de Milícia
5581	Cajado Liso de Viagem
5582	Seiva das Torres de Pedra
5583	Escama de Dragão Encantado
5584	Bigodes de Felino do Crepúsculo
5585	Olho de Corcel
5586	Lâmina de Pau-cardo
5587	Clava Raiz-espinhosa
5588	Toxina do Lindolfo
5589	Manoplas Cobertas de Musgo
5590	Braçadeiras de Cordão
5591	Capa Manchada de Chuva
5592	Cinturão Acorrentada
5593	Broquel Rochedo
5594	Carta para Jin'Zil
5595	Martelo da Mata
5596	Arco de Freixo
5601	Bolsa de Ovos Chocados
5602	Teia Grudenta de Aranha
5603	Saco de Aniagem do Lhogolhó
5604	Varinha Élfica
5605	Faca de Podar
5606	Luvas de Jardinagem
5608	Capucho Vivo
5609	Cilha Constante
5610	Manto da Rajada Florestal
5611	Lágrima de Luto
5612	Manilhas de Hera
5613	Cajado do Purificador
5614	Golpe de Seraph
5615	Espada do Mateiro
5616	Rancatripa
5617	Perneiras do Vagabundo
5618	Manto do Batedor
5619	Frasco de Jade
5620	Ampola de Sangue Inocente
5621	Frasco de Turmalina
5622	Anel do Clero
5623	Frasco de Ametista
5624	Diadema da Ordem
5626	Lasca-crânio
5627	Lâmina Rara
5628	Bilhete de Zamah
5629	Luvas de Punho de Martelo
5630	Luvas Toque de Vento
5631	Poção de Raiva
5632	Poção da Fuga Covarde
5633	Poção Grandiosa de Raiva
5634	Poção de Ação Desimpedida
5635	Garra Afiada
5636	Pena Delicada
5637	Presa Grande
5638	Vaporizador Tóxico
5639	Frasco de Jade Cheio
5640	Receita: Poção de Raiva
5641	Receita: Poção da Fuga Covarde
5642	Receita: Poção de Ação Desimpedida
5643	Receita: Poção Grandiosa de Raiva
5644	Tomo de Conjurar Água
5645	Frasco de Turmalina Cheio
5646	Ampola de Água Benta
5647	Tomo de Lampejo
5648	Tomo de Armadura Gélida III
5649	Tomo de Nevasca
5650	Tomo de Conjurar Água III
5654	Toxina Instantânea
5655	Rédea de Égua Alazã
5656	Rédea de Cavalo Castanho
5657	Receita: Toxina Instantânea
5658	Incunábulo: Selo do Poder
5659	Brasas Fumegantes
5660	Incunábulo: Selo da Retidão
5661	Incunábulo: Selo da Retidão II
5662	Incunábulo: Selo da Retidão III
5663	Trompa do Lobo Vermelho
5664	Estilhaços Corroídos
5665	Trompa do Lobo Hediondo
5666	Incunábulo: Selo da Ira II
5667	Incunábulo: Selo da Sabedoria II
5668	Trompa do Lobo Marrom
5669	Destroços do Redemoinho de Poeira
5670	Incunábulo: Selo da Ira IV
5671	Incunábulo: Selo do Poder III
5672	Incunábulo: Exorcismo
5673	Incunábulo: Exorcismo II
5674	Incunábulo: Exorcismo III
5675	Escamas Cristalizadas
5676	Incunábulo: Detectar Morto-vivo
5677	Incunábulo: Esconjurar Morto-vivo
5678	Incunábulo: Selo do Sacrifício
5679	Incunábulo: Selo da Sabedoria III
5680	Incunábulo: Selo da Proteção II
5681	Seiva Corrosiva
5682	Incunábulo: Esconjurar Morto-vivo II
5683	Incunábulo: Escudo Divino II
5684	Incunábulo: Selo da Salvação
5685	Incunábulo: Redenção
5686	Cabeça de Ornanos
5687	Chave do Guardião do Portal
5689	Chave do Adormecido
5690	Chave da Garra
5691	Chave da Ermida
5692	Detonador Remoto (Vermelho)
5693	Detonador Remoto (Azul)
5694	Explosivos NG-5 (Vermelho)
5695	Explosivos NG-5 (Azul)
5696	Tabuleta de Choque
5697	Tabuleta de Totem Curativo
5698	Tabuleta de Escudo de Raios
5699	Tabuleta de Lobo Fantasma
5700	Tabuleta de Totem Curativo II
5701	Tabuleta de Totem-sentinela
5702	Tabuleta de Totem Agitador II
5703	Tabuleta de Trovoada
5704	Tabuleta de Respiração Aquática
5705	Tabuleta de Totem Curativo III
5706	Tabuleta de Totem Serpente III
5707	Tabuleta de Visão Distante
5708	Tabuleta de Forma Etérea
5709	Tabuleta de Andar sobre a Água
5710	Tabuleta de Totem Curativo IV
5711	Tabuleta de Lobo Fantasma II
5712	Tabuleta de Totem Serpente IV
5713	Tabuleta de Seta Trovejante
5714	Tabuleta de Totem Enredante II
5715	Tabuleta de Tempestade de Raios III
5716	Tabuleta de Restauração VI
5717	Cartas da Empreendimentos S.A.
5718	Plano de Engenharia da Empreendimentos S.A.
5719	Grimório de Drenar Vida II
5720	Grimório de Maldição de Mannoroth II
5721	Grimório de Criar Pedra Mágica
5722	Grimório de Sugar Mana II
5723	Grimório de Maldição de Sargeras III
5724	Grimório de Maldição de Línguas
5725	Grimório de Pestilência III
5726	Grimório de Criar Pedra-sangrenta Maior
5727	Grimório de Funil de Mana
5728	Grimório de Chuva de Fogo II
5729	Grimório de Medo III
5730	Livro de Rejuvenescimento
5731	Pergaminho de Mensagem
5732	NG-5
5733	Minério Não Identificado
5734	Diagramas do Super Ceifador 6000
5735	Envelope Selado
5736	Braço Mecânico do Hanfritz
5737	Plano de Operações Secretas: Alfa & Beta
5738	Mochila de Operações Secretas
5739	Arnês Barbaresco
5740	Foguete de Fogos de Artifício Vermelhos
5741	Lasca de Rocha
5742	Adaga com Pedra Preciosa
5743	Anel de Pedraprisma
5744	Escalpelo Pálido
5748	Arco Longo de Centauro
5749	Machado-foice
5750	Cinturão do Chefe Guerreiro
5751	Manto de Teiasa
5752	Ponta de Cauda de Mantícora
5753	Camalha Eriçada
5754	Medalhão da Alcateia
5755	Peitoral de Ônix Retalhador
5756	Lâmina Talhada
5757	Clava de Madeira Dura
5758	Cofre de Mithril
5759	Cofre de Tório
5760	Cofre de Etérnio
5761	Marreta de Sidermar
5762	Bolsa de Linho Vermelha
5763	Bolsa de Lã Vermelha
5764	Mochila de Seda Verde
5765	Mochila de Seda Preta
5766	Veste Inferior do Teurgo
5767	Vestes Violeta
5768	Ingresso para a Corrida de Gnomos
5769	Ingresso para a Corrida de Goblins
5770	Vestes de Arcana
5771	Molde: Bolsa de Linho Vermelha
5772	Molde: Bolsa de Lã Vermelha
5773	Molde: Vestes de Arcana
5774	Molde: Mochila de Seda Verde
5775	Molde: Mochila de Seda Preta
5776	Bengala do Ancião
5777	Machado do Valente
5778	Bengala Primitiva
5779	Espada Bastarda dos Renegados
5780	Cinto de Escama de Murloc
5781	Peitoral de Escama de Murloc
5782	Armadura Grossa de Murloc
5783	Braçadeiras de Escama de Murloc
5784	Escama Viscosa de Murloc
5785	Escama Grossa de Murloc
5786	Molde: Cinto de Escama de Murloc
5787	Molde: Peitoral de Escama de Murloc
5788	Molde: Armadura Grossa de Murloc
5789	Molde: Braçadeiras de Escama de Murloc
5790	Diário do Monocelha
5791	Diário de Henrig Monocelha
5792	Medalhão da Talhaflanco
5793	Coração da Talhaflanco
5794	Peçonha Salgada de Escorpídeo
5795	Casco Endurecido de Tartaruga
5796	Barbatana de Cauda Incrustada
5797	Lâmina de Indúrio
5798	Peças de Carro-foguete
5799	Encomenda de Peças de Kravel
5800	Peças de Kravel
5801	Guano de Morcego
5802	Peças Frágeis de Carro
5803	Partícula de Pó Onírico
5804	Rumores Goblínicos
5805	Coração do Fanatismo
5806	Cerveja Escura do Tonto
5807	Relatório sobre Cerveja Escura do Tonto
5808	Vesícula de Peçonha de Asaltiva
5809	Vesícula de Peçonha de Alcândora
5810	Carcaça Fresca
5811	Juba de Bocarragelo
5812	Vestes da Antiguidade
5813	Marca de Emílio
5814	Armadura Riacho Estrondoso
5815	Pedra Glacial
5816	Luz de Eluna
5817	Arco Lunaris
5818	Varinha Raio Lunar
5819	Coifa Ardessol
5820	Dragonas Feéricas
5821	Botas do Espreita-treva
5822	Manoplas Semente-de-sebe
5823	Cogumelo Venenoso
5824	Tabuleta da Vontade
5825	Pingente de Treshala
5826	Plano de Kravel
5827	Carta de Xabu Latafuso
5829	Bico Afiadíssimo
5830	Cabeça de Kenata
5831	Cabeça de Fardel
5832	Cabeça de Marcel
5833	Minério de Indúrio
5834	Rapé de Mok'Morokk
5835	Beberagem de Mok'Morokk
5836	Cofre de Mok'Morokk
5837	Costela do Estalaço
5838	Pergaminho de Pele de Kodo
5839	Página de Diário
5840	Língua Calcinante
5841	Coração Calcinante
5842	Amostra Não Refinada de Minério
5843	Garra da Grenka
5844	Fragmentos de Rok'Alim
5845	Flanco de Carne
5846	Bilhete Selado de Korran
5847	Cabeça de Lamapina
5848	Osso Oco de Abutre
5849	Caixote de Capacetes de Proteção
5850	Bilhete Selado de Belgrom
5851	Chave do Cosella
5852	Esquemas do Regulador de Combustível
5853	Carapaça Intacta de Silitídeo
5854	Garra de Silitídeo
5855	Coração de Silitídeo
5857	Caixa de Prêmios de Gnomo
5858	Caixa de Prêmios de Goblin
5859	Granada de Festa
5860	Legado dos Aspectos
5861	Início da Ameaça dos Mortos-vivos
5862	Foguete de Cequatrum
5863	Contrato de Guilda
5864	Carneiro Cinza
5865	Foguete de Cequatrum Modificado
5866	Amostra de Minério de Indúrio
5867	Frasco Cinzelado
5868	Frasco Cinzelado Cheio
5869	Casco Fendido
5871	Casco Grande
5872	Carneiro Marrom
5873	Carneiro Branco
5874	Arnês: Carneiro Preto
5875	Arnês: Carneiro Azul
5876	Tubérculo Folhazul
5877	Carapaça Rachada de Silitídeo
5878	Super-rapé
5879	Pingente do Crepúsculo
5880	Caixote com Furos
5881	Cabeça de Kelris
5882	Documentos do Capitão
5883	Língua Bifurcada de Pedralama
5884	Olho Névoa Negra Inteiro
5897	Manual de Proprietário do Fungafuça
5916	Chave de Câmera Gnômica
5917	Relatório do Espião
5918	Cabeça de Orc Desafiante
5919	Escudo de Ferro Enegrecido
5936	Cinto de Pele de Animal
5937	Chave de Câmera Goblínica
5938	Pata Impecável de Rastejante
5939	Luvas de Costura
5940	Broquel de Osso
5941	Calças de Escama de Latão
5942	Pingente Adornado
5943	Braçadeiras da Fenda
5944	Grevas da Milícia do Povo
5945	Dente de Mortocharco
5946	Bilhete Lacrado para Eling
5947	Súmula Défias
5948	Carta a Jorge
5949	Pedaço de Papel
5950	Distintivo de Reethe
5951	Toalhinha Úmida
5952	Tronco Encefálico Corrompido
5956	Martelo de Ferreiro
5957	Colete de Couro Feito à Mão
5958	Calças de Couro de Qualidade
5959	Vesícula de Peçonha Ácida
5960	Bilhete Lacrado para o Vigia Backor
5961	Calças de Couro Escuro
5962	Calças do Guardião
5963	Perneiras Barbarescas
5964	Omoplatas Barbarescas
5965	Manto do Guardião
5966	Luvas do Guardião
5967	Cinturão de Nobreza
5968	Botas Rústicas
5969	Manto do Regente
5970	Luvas da Serpente
5971	Capa de Penas
5972	Molde: Calças de Couro de Qualidade
5973	Molde: Perneiras Barbarescas
5974	Molde: Manto do Guardião
5975	Cinto do Rufião
5976	Tabardo de Guilda
5996	Elixir de Respiração Aquática
5997	Elixir de Defesa Menor
5998	Pedido de Lançatroz
6016	Amostra de Coração de Lobo
6037	Barra de Veraprata
6038	Torresmo de Marisco Gigante
6039	Receita: Torresmo de Marisco Gigante
6040	Braçadeiras de Escama Dourada
6041	Corrente de Arma de Aço
6042	Espigão de Escudo de Ferro
6043	Contrapeso de Ferro
6044	Instruções: Espigão de Escudo de Ferro
6045	Instruções: Contrapeso de Ferro
6046	Instruções: Corrente de Arma de Aço
6047	Instruções: Coifa de Escama Dourada
6048	Poção de Proteção contra a Sombra
6049	Poção de Proteção contra o Fogo
6050	Poção de Proteção contra o Gelo
6051	Poção de Proteção contra o Sagrado
6052	Poção de Proteção contra a Natureza
6053	Receita: Poção de Proteção contra o Sagrado
6054	Receita: Poção de Proteção contra a Sombra
6055	Receita: Poção de Proteção contra o Fogo
6056	Receita: Poção de Proteção contra o Gelo
6057	Receita: Poção de Proteção contra a Natureza
6058	Cinto de Couro Enegrecido
6059	Colete Nômade
6060	Braçadeiras de Linhão
6061	Braçadeiras Pedragris
6062	Braçadeiras de Corda Grossa
6063	Manoplas de Aço Frio
6064	Discos de Platina Miniatura
6065	Ensaios de Hadggar sobre Convergência Dimensional
6066	Cabeça de Khan Dez'hepah
6067	Orelha de Centauro
6068	Receita: Óleo de Sombra
6069	Carne Mal Desidratada
6070	Braçadeiras de Pele de Lobo
6071	Cristal de Draenetista
6072	Cabeça de Khan Jehn
6073	Cabeça de Khan Shaka
6074	Boquilha da Corneta de Guerra
6075	Relatório de Valente
6076	Calças Afuniladas
6077	Fragmento de Chave dos Maraudinos
6078	Escudo do Piqueiro
6079	Patuá Grosseiro
6080	Coração de Pantera das Sombras
6081	Fungo do Senhor do Brejo
6082	Tumor Passofundo
6083	Lágrimas Partidas
6084	Perneiras da Guarda de Ventobravo
6085	Túnica de Soldado Raso
6086	Soro da Verdade do Faustino
6087	Calções do Cerro Oeste
6089	Cerveja de Zaerdus
6091	Caixote de Pedras de Poder
6092	Botas de Dragonete Negro
6093	Esmaga-orc
6094	Machado Perfurante
6095	Botas do Errante
6096	Camisa do Aprendiz
6097	Camisa do Acólito
6098	Veste do Neófito
6116	Veste do Aprendiz
6117	Camisa do Escudeiro
6118	Calças do Escudeiro
6119	Veste do Neófito
6120	Camisa do Recruta
6121	Calças do Recruta
6122	Botas do Recruta
6123	Veste do Noviço
6124	Calças do Noviço
6125	Arnês do Brigão
6126	Calças do Coureador
6127	Botas do Coureador
6129	Veste do Acólito
6130	Camisa do Coureador
6131	Calças do Coureador
6132	Incunábulo: Selo da Sabedoria
6133	Incunábulo: Selo da Fúria
6134	Poncho Primitivo
6135	Kilt Primitivo
6136	Camisa do Capanga
6137	Calças do Capanga
6138	Botas do Meliante
6139	Veste do Noviço
6140	Veste do Aprendiz
6144	Veste do Neófito
6145	Pingente da Clarice
6146	Madeira Flutuante Seca ao Sol
6147	Cinto Velho e Roto
6148	Botas Cobertas de Teia
6149	Poção Maior de Mana
6150	Um Nó Gasto
6166	Mandíbula de Coiote
6167	Relatório de Nika
6168	Garra de Tartalisca Dentesserra
6169	Anca Não Tratada de Dentesserra
6170	Reagentes do Teurgo
6171	Luvas do Tratador de Lobos
6172	Suprimentos Perdidos
6173	Botas de Neve
6174	Espada Aleatória do Twain
6175	Artefato Atal'ai
6176	Escudo Ogival Enânico
6177	Braçadeiras de Ferro Martelado
6178	Remessa para Etergarde
6179	Capa do Corsário
6180	Pelecapto
6181	Fetiche de Hakkar
6182	Tocha Apagadiça
6183	Tocha Inferior Apagada
6184	Perna de Rastejante Monstruoso
6185	Xale de Urso
6186	Fatiador Trogg
6187	Defensor Enânico
6188	Pisoteadores da Lama
6189	Omoplatas Encadeadas Duráveis
6190	Estilhaço de Draenetista
6191	Botas Kimbra
6192	Cabeça de Khan Hratha
6193	Saco de Artefatos Atal'ai
6194	Ceifadeira de Tanoeiro
6195	Armadura Polida com Cera
6196	Clava de Noboru
6197	Colete de Couro de Crocolisco Lacustre
6198	Munhequeiras Jurássicas
6199	Elo da Viúva Negra
6200	Cinto de Guerra do Garbeg
6201	Botas Flexíveis
6202	Luvas sem Dedos
6203	Escudo Velhaco
6204	Elmo Tribal Worg
6205	Pá Escavadora
6206	Lascador de Rocha
6207	JxJ - Planta da Torre da Horda
6208	JxJ - Planta da Torre da Aliança
6209	JxJ - Escritura de Mina da Horda
6210	JxJ - Escritura de Mina da Aliança
6211	Receita: Elixir de Força do Ogro
6212	Cabeça de Jammal'an
6214	Malho Pesado de Cobre
6215	Vara de Luta Balanceada
6216	Pólvora Mística
6217	Bastão de Cobre
6218	Bastão Rúnico de Cobre
6219	Chave de Arco Voltaico
6220	Estilhaço de Meteoro
6222	Fórmula: Encantamento Menor de Espírito - Torso
6223	Escudo de Vila Sombria
6226	Avental Ensanguentado
6232	Monstro - Item, Flor - Buquê Rosas
6233	Monstro - Item, Flor - Buquê Flores do Campo
6237	Monstro - Item, Flor - Buquê Rosas (Negras)
6238	Veste de Linho Marrom
6239	Colete de Linho Vermelho
6240	Colete de Linho Azul
6241	Veste de Linho Branca
6242	Veste de Linho Azul
6243	Veste de Lã Verde
6244	ggggfg
6245	Algibeira de Karnitol
6246	Garra Furiódio
6247	Chifre Furiódio
6248	Peçonha de Scorpachi
6249	Pelego Envelhecido de Kodo
6250	Cérebro de Canisvil
6251	Asa Etérea
6252	Sangue do Guardião da Ruína
6253	Encomenda de Sinismago
6256	Vara de Pescar
6257	Moela de Roca
6258	Fígado de Veloférreo
6259	Fígado de Groddoc
6260	Pigmento Azul
6261	Pigmento Laranja
6262	Diário de Galeno
6263	Jardineira Azul
6264	Veste do Grandioso Adepto
6265	Estilhaço de Alma
6266	Colete do Discípulo
6267	Calças do Discípulo
6268	Túnica do Pioneiro
6269	Calças do Pioneiro
6270	Molde: Colete de Linho Azul
6271	Molde: Colete de Linho Vermelho
6272	Molde: Veste de Linho Azul
6273	Molde: Veste de Lã Verde
6274	Molde: Jardineira Azul
6275	Molde: Veste do Grandioso Adepto
6276	Bilhete Mofado
6277	Pergaminho Mofado
6278	Pergaminho Mofado
6279	Carta Mofada
6280	Missiva Mofada
6281	Crânio de Range-ossos
6282	Calças do Sepultamento Sagrado
6283	O Livro de Ur
6284	Runas de Evocação
6285	Grimório de Egalin
6286	Corações Puros
6287	Fragmento de Tabuleta Atal'ai
6288	Tabuleta Atal'ai
6289	Pargo-da-lama Bocalonga Cru
6290	Peixinho Brilhante
6291	Peixinho Brilhante Cru
6292	Pargo-da-lama de 5 Quilos
6293	Sangue Seco de Morcego
6294	Pargo-da-lama de 6 Quilos
6295	Pargo-da-lama de 7 Quilos
6296	Tufo de Pelos de Morcego
6297	Crânio Velho
6298	Presa Ensanguentada de Morcego
6299	Peixe com Aparência Doentia
6300	Fragmento de Carcaça
6301	Crânio Velho do Condutor
6302	Asa Delicada de Inseto
6303	Cavala Deslizapele Crua
6304	Página Úmida de Diário (Dia 4)
6305	Página Úmida de Diário (Dia 87)
6306	Página Úmida de Diário (Dia 512)
6307	Mensagem na Garrafa
6308	Bagre de Bigode Cerdoso Cru
6309	Bagre de 8 Quilos
6310	Bagre de 9 Quilos
6311	Bagre de 11 Quilos
6312	Coração de Dalin
6313	Coração de Comar
6314	Capa do Mestre dos Lobos
6315	Besta Flechaço
6316	Delícia de Farnesim Lacustre
6317	Farnesim Lacustre Cru
6318	Cajado de Meridiano de Odo
6319	Cinturão do Vigia Cego
6320	Escudo do Comandante
6321	Selo da Família Silverlaine
6323	Cetro do Barão
6324	Vestes de Arugal
6325	Receita: Peixinho Brilhante
6326	Receita: Cavala Deslizapele
6327	O Pacificador
6328	Receita: Pargo-da-lama Bocalonga
6329	Receita: Delícia de Farnesim Lacustre
6330	Receita: Bagre de Bigode Cerdoso
6331	Lâmina Uivante
6332	Anel de Pérola Negra
6333	Adaga Açoitagulha
6335	Botas Cinzentas
6336	Túnica de Infantaria
6337	Perneiras de Infantaria
6338	Bastão de Prata
6339	Bastão Rúnico de Prata
6340	Pelego de Fenrus
6341	Lanterna Lúgubre de Estábulo
6342	Fórmula: Encantamento Menor de Mana - Torso
6343	Fórmula: Encantamento de Espírito - Torso
6344	Fórmula: Encantamento Menor de Espírito - Braçadeiras
6345	Fórmula: Encantamento de Proteção - Manto
6346	Fórmula: Encantamento Inferior de Mana - Torso
6347	Fórmula: Encantamento Menor de Força - Braçadeiras
6348	Fórmula: Encantamento Menor de Matador de Feras - Arma
6349	Fórmula: Encantamento Inferior de Intelecto - Arma de 2M
6350	Botas Rústicas de Bronze
6351	Caixote Amassado
6352	Caixote Encharcado
6353	Baú Pequeno
6354	Baú Pequeno Trancado
6355	Baú Resistente Trancado
6356	Baú Desgastado
6357	Caixote Selado
6358	Bocanera Oleoso
6359	Pargo Pinafogo
6360	Peixe-maça Escamaço
6361	Albacora Arco-íris Crua
6362	Bacalhau Escama-de-pedra Cru
6363	Bagre de 13 Quilos
6364	Bagre de 16 Quilos
6365	Vara de Pescar Forte
6366	Vara de Pescar Lenhanegra
6367	Grande Vara de Pescar de Ferro
6368	Receita: Albacora Arco-íris
6369	Receita: Bacalhau Escama-de-pedra
6370	Óleo de Bocanera
6371	Óleo Ígneo
6372	Poção de Velocidade de Nado
6373	Elixir de Poder de Fogo
6374	Pó Encantado
6375	Fórmula: Encantamento Inferior de Espírito - Braçadeiras
6376	Fórmula: Encantamento Menor de Vigor - Botas
6377	Fórmula: Encantamento Menor de Agilidade - Botas
6378	Capa do Vidente
6379	Cinto de Couro Inscrito
6380	Broquel Inscrito
6381	Manto Brilhante
6382	Cinto de Couro da Floresta
6383	Broquel da Floresta
6384	Camisa Azul Estilosa
6385	Camisa Verde Estilosa
6386	Guarda-pernas de Malha Luzentes
6387	Braçadeiras de Malha Luzentes
6388	Brafoneiras de Malha Luzentes
6389	Touca de Malha Luzente
6390	Molde: Camisa Azul Estilosa
6391	Molde: Camisa Verde Estilosa
6392	Cinto de Arugal
6393	Luvas de Fio de Prata
6394	Botas de Fio de Prata
6395	Sobreveste de Fio de Prata
6396	Peito d'Armas Brasonado
6397	Luvas Brasonadas
6398	Cinto Brasonado
6399	Omoplatas Brasonadas
6400	Escudo Luzente
6401	Molde: Camisa de Seda Preta
6402	Perneiras de Combate de Malha
6403	Guarda-braços de Combate de Malha
6404	Espaldares de Combate de Malha
6405	Calças do Céu Noturno
6406	Botas do Céu Noturno
6407	Munhequeiras do Céu Noturno
6408	Luvas com Insígnia
6409	Cinto com Insígnia
6410	Braçadeiras com Insígnia
6411	Armadura do Brigadeiro-chefe
6412	Botas do Brigadeiro-chefe
6413	Braçadeiras do Brigadeiro-chefe
6414	Selo de Sylvana
6415	Veste da Aurora
6416	Botas da Aurora
6417	Manto da Aurora
6418	Faixa da Aurora
6419	Luvas Glíficas
6420	Botas Glíficas
6421	Cinto Glífico
6422	Elmo Glífico
6423	Grevas Forja Negra
6424	Capa Forja Negra
6425	Cinturão Forja Negra
6426	Braçadeiras Forja Negra
6427	Veste Enevoada
6428	Luvas Enevoadas
6429	Chapéu de Teurgo Enevoado
6430	Peitoral Imperial de Couro
6431	Botas Imperiais de Couro
6432	Manto Imperial
6433	Elmo Imperial de Couro
6435	Gema Ardente Infusa
6436	Gema Ardente
6438	Braçadeira Elemental Fraca
6439	Braçadeira Atadora Quebrada
6440	Açoita-cérebro
6441	Escalpo de Assombrante
6442	Cristal de Oráculo
6443	Pelego Anormal
6444	Língua Bifurcada
6445	Exúvia Quebradiça
6446	Bolsa de Couro de Cobra
6447	Escudo Gasto de Casco de Tartaruga
6448	Espinho de Cauda
6449	Manto Faiscante de Escama de Lagarto
6450	Bandagem de Seda
6451	Bandagem Grossa de Seda
6452	Antipeçonha
6453	Antipeçonha Forte
6454	Manual: Antipeçonha Forte
6455	Roda Antiga de Vagão
6456	Visgo Ácido
6457	Peças de Engenharia Enferrujadas
6458	Peixe Coberto de Óleo
6459	Pisantes Selvagens
6460	Agarra de Cobrahn
6461	Ombreiras Incrustadas de Visgo
6462	Caixote Fechado
6463	Anel da Suma Profundeza
6464	Essência Ululante
6465	Veste de Caninana
6466	Manto de Escama Anormal
6467	Luvas de Escama Anormal
6468	Cinto de Escama Anormal
6469	Golpe Venenoso
6470	Escama Anormal
6471	Escama Anormal Perfeita
6472	Víbora Pungente
6473	Armadura da Presa
6474	Molde: Manto de Escama Anormal
6475	Molde: Luvas de Escama Anormal
6476	Molde: Cinto de Escama Anormal
6477	Faixa da Campina
6478	Pisoteadores Pisa-ratos
6479	Pingente de Malem
6480	Perneiras Anormais Lustrosas
6481	Manoplas Lamacentas
6482	Botas Andachama
6486	Escama Chamuscada
6487	Cabeça de Demônio Familiar Vil
6488	Tabuleta Simples
6489	Pergaminho Deteriorado
6490	Pergaminho Escuro
6491	Pergaminho Pesado
6492	Pergaminho Tisnado
6493	Pergaminho Esfarrapado
6494	Pergaminho Rabiscado
6495	Pergaminho Castigado pelo Tempo
6496	Pergaminho Detalhado
6497	Pergaminho Simples
6498	Couro de Kodo Inscrito
6499	Couro de Kodo Inscrito
6500	Couro de Kodo Inscrito
6501	Couro de Kodo Inscrito
6502	Armadura de Escama Violeta
6503	Vestes do Arlequim
6504	Laminasa
6505	Cajado Crescente
6506	Botas de Infantaria
6507	Braçadeiras de Infantaria
6508	Manto de Infantaria
6509	Cinto de Infantaria
6510	Manoplas de Infantaria
6511	Veste do Profissional
6512	Veste do Discípulo
6513	Faixa do Discípulo
6514	Manto do Discípulo
6515	Luvas do Discípulo
6516	Pergaminho de Evocar Diabrete
6517	Cinto do Pioneiro
6518	Botas do Pioneiro
6519	Braçadeiras do Pioneiro
6520	Manto do Pioneiro
6521	Luvas do Pioneiro
6522	Peixe Anormal
6523	Arnês Amassado
6524	Arnês de Couro Cravejado
6525	Arnês do Bruto
6526	Arnês de Batalha
6527	Veste Ancestral
6528	Veste do Mesmerizador
6529	Miçanga Brilhosa
6530	Reptantes
6531	Veste de Tecido Barbaresca
6532	Iscas Brilhantes
6533	Pega-peixes Aquadinâmico
6534	Barras de Aço Forjado
6535	Tabuleta de Verga
6536	Colete do Salgueiro
6537	Botas do Salgueiro
6538	Veste do Salgueiro
6539	Cinto do Salgueiro
6540	Calças do Salgueiro
6541	Luvas do Salgueiro
6542	Capa do Salgueiro
6543	Braçadeiras do Salgueiro
6544	Pergaminho de Evocar Emissário do Caos
6545	Armadura do Soldado
6546	Perneiras do Soldado
6547	Manoplas do Soldado
6548	Cinturão do Soldado
6549	Manto do Soldado
6550	Munhequeiras do Soldado
6551	Botas do Soldado
6552	Túnica do Bardo
6553	Calças do Bardo
6554	Luvas do Bardo
6555	Manto do Bardo
6556	Braçadeiras do Bardo
6557	Botas do Bardo
6558	Cinto do Bardo
6559	Broquel do Bardo
6560	Escudo do Soldado
6561	Armadura Acolchoada do Vidente
6562	Botas Cintilantes
6563	Braçadeiras Cintilantes
6564	Manto Cintilante
6565	Luvas Cintilantes
6566	Sobreveste Cintilante
6567	Armadura Cintilante
6568	Calças Cintilantes
6569	Veste Cintilante
6570	Faixa Cintilante
6571	Broquel de Observação
6572	Escudo do Defensor
6573	Botas de Defensor
6574	Braçadeiras de Defensor
6575	Manto do Defensor
6576	Cinturão do Defensor
6577	Manoplas do Defensor
6578	Perneiras do Defensor
6579	Espaldares do Defensor
6580	Túnica do Defensor
6581	Cinto de Observação
6582	Botas de Observação
6583	Braçadeiras de Observação
6584	Túnica de Observação
6585	Manto de Observação
6586	Luvas de Observação
6587	Calças de Observação
6588	Espaldares de Observação
6589	Anel Viridiano
6590	Botas Forja da Batalha
6591	Munhequeiras Forja da Batalha
6592	Armadura Forja da Batalha
6593	Manto Forja da Batalha
6594	Cinturão Forja da Batalha
6595	Manoplas Forja da Batalha
6596	Guarda-pernas Forja da Batalha
6597	Guarda-ombros Forja da Batalha
6598	Broquel do Dervixe
6599	Escudo Forja da Batalha
6600	Cinto do Dervixe
6601	Botas do Dervixe
6602	Braçadeiras do Dervixe
6603	Túnica do Dervixe
6604	Capa do Dervixe
6605	Luvas do Dervixe
6607	Perneiras do Dervixe
6608	Armadura Brilhante
6609	Traje do Sábio
6610	Veste do Sábio
6611	Faixa do Sábio
6612	Botas do Sábio
6613	Braçadeiras do Sábio
6614	Manto do Sábio
6615	Luvas do Sábio
6616	Calças do Sábio
6617	Dragonas do Sábio
6619	Manual: O Caminho da Defesa
6620	Pergaminho Elaborado
6621	Manual de Provocar
6622	Espada do Zelo
6623	Pergaminho de Evocar Súcubo
6624	Trago do Ken'zigla
6625	Pingente Coberto de Terra
6626	Pingente de Dogran
6627	Peitoral de Escamas Mutantes
6628	Gadanhos do Corvo
6629	Capa Esporífera
6630	Broquel da Nuvem de Sementes
6631	Raiz Viva
6632	Manto de Escama Encantada
6633	Fatiador do Açougueiro
6634	Unguento de Ritual
6635	Sapta da Terra
6636	Sapta do Fogo
6637	Sapta da Água
6638	Sapta do Ar
6640	Casco de Espreitador Vil
6641	Lâmina de Assombração
6642	Armadura Fantasma
6643	Peixinho Inchado
6644	Cavala Inchada
6645	Pargo-da-lama Inchado
6646	Albacora Inchada
6647	Bagre Inchado
6648	Pergaminho de Totem Litopele
6649	Pergaminho de Totem Calcinante
6650	Pergaminho de Totem de Torrente Curativa
6651	Garrafa de Vinho Quebrada
6652	Bornal de Reagentes
6653	Tocha da Chama Latente
6654	Tocha da Chama Eterna
6655	Brasa Faiscante
6656	Quartzo Grosseiro
6657	Delícia de Peixe Anormal
6658	Colar de Amostra
6659	Calças do Escaravelho
6660	Adaga de Julie
6661	Receita: Delícia de Peixe Anormal
6662	Elixir de Crescimento Gigantesco
6663	Receita: Elixir de Crescimento Gigantesco
6664	Dragonas Vodu
6665	Braçadeiras Bagateadas
6666	Botas de Mourejar
6667	Manto do Engenheiro
6668	Botas do Escrevente
6669	Anel Sagrado
6670	Armadura da Pantera
6671	Perneiras do Implacável
6672	Diagrama: Bomba de Clarão
6675	Braçadeiras Temperadas
6676	Broquel do Condestável
6677	Varinha de Feitiçaria
6678	Anel do Donaire Élfico
6679	Fura-armadura
6681	Punhal Espinhado
6682	Vestes do Morta-voz
6684	Bastão de Adestramento do Fungafuça
6685	Dragonas do Morta-voz
6686	Elmo com Presas
6687	Cria-cadáver
6688	Cocar Murmuréolo
6689	Cajado Espírito do Vento
6690	Perneiras Ferinas
6691	Adaga Presa-de-suíno
6692	Aniquilador Denteado
6693	Gancho de Agamaggan
6694	Coração de Agamaggan
6695	Amuleto de Osso Estígio
6696	Arco Espreitanoite
6697	Dragonas Quirópteras
6698	Pedra de Pierce
6707	Pedra de Lápidis
6708	Pedra de Bonhomme
6709	Colete Brilho da Lua
6710	Molde: Colete Brilho da Lua
6711	Pedra de Kurtz
6712	Fechadura de Exercício
6713	Calças Rasgadas
6714	Dinamite Taca-fácil
6715	Cabo de Chupeta Arruinado
6716	Diagrama: Dinamite Taca-fácil
6717	Deschanfrador
6718	Eletromola
6719	Cinto Pairavento
6720	Cocar do Caçador Espiritual
6721	Guarda-peito de Kor
6722	Algemas Bestiais
6723	Medalha de Bravura
6724	Pedra de Backor
6725	Broquel Marmóreo
6726	Cinto de Segurança Personalizado do Razzeric
6727	Luvas de Corrida do Razzeric
6728	Pedra do Rosado
6729	Isqueiro Zippy do Xabu
6730	Corrente de Altaforja
6731	Peitoral de Altaforja
6732	Luvas do Mecânico Gnômico
6733	Manoplas de Altaforja
6734	Instruções: Corrente de Altaforja
6735	Instruções: Peitoral de Altaforja
6736	Instruções: Manoplas de Altaforja
6737	Calças Folhasseca
6738	Crescente Sangrento
6739	Mira do Corredor do Despenhadeiro
6740	Faixa Lazúli
6741	Espada Bélica Órquica
6742	Cinturão Punhopétreo
6743	Anel do Encorajamento
6744	Luvas de Kapelan
6745	Capa do Correleve
6746	Broquel de Basalto
6747	Brafoneiras do Impositor
6748	Anel Símio
6749	Elo Tigrino
6750	Aro Ofídio
6751	Xale da Lamentação
6752	Botas Lanceiras
6753	Patuá de Penas
6754	Porta-moedas Grande
6755	Pequena Caixa de Gemas
6756	Porta-joias
6757	Anel-sinete de Jaina
6766	Flayed Demon Skin (old2)
6767	Pingente de Tyranis
6773	Corrente do Espoliador Gelkis
6774	Dedo de Uthek
6775	Tomo de Divindade
6776	Tomo de Valor
6777	Tomo de Retidão
6778	Tomo de Justiça
6779	Tomo de Nobreza
6780	Faixa Lilás
6781	Caneca do Bartolino
6782	Distintivo do Delegado Fadigas
6783	Chave do Dente-podre
6784	Protetores de Mão Reforçados
6785	Poderes do Caos
6786	Vestido Simples
6787	Vestido Branco de Lã
6788	Cinto do Caçador Magram
6789	Manta Cerimonial do Centauro
6790	Anel da Calma
6791	Botas do Desordeiro
6792	Brafoneiras Sanguíneas
6793	Braçadeiras Áuricas
6794	Manoplas do Fogo da Tempestade
6795	Camisa Branca do Espadachim
6796	Camisa Vermelha do Espadachim
6797	Fura-olhos
6798	Arcabuz Explosivo
6799	Cabeça de Vejrek
6800	Minério Umbrático
6801	Avental Barroco
6802	Espada do Agouro
6803	Bordão Profético
6804	Martelo Ventempesta
6805	Trompa de Vorlus
6806	Chama Dançante
6807	Ensopado de Perna de Sapo
6808	Minério de Elunita
6809	Medalhão de Elura
6810	Gargantilha de Surena
6811	Peixescópio Aquadinâmico
6812	Caixote de Elunita
6826	Escama Brilhante
6827	Caixa de Suprimentos
6828	Broquel do Visionário
6829	Espada da Serenidade
6830	Morde-ossos
6831	Ameaça Negra
6832	Manto Empesteado
6833	Camisa Branca de Smoking
6834	Smoking Preto
6835	Calça Preta de Smoking
6836	Sapatos Sociais
6837	Vestido de Noiva
6838	Presa de Aranha Calcinada
6839	Chifre Calcinado
6840	Chifre Galvanizado
6841	Ampola de Flogisto
6842	Instruções de Furen
6843	Barril de Grogue
6844	Sangue Ardente
6845	Pedra Ardente
6846	Carta de Défias
6847	Carta de Ferro Negro
6848	Coral Causticante
6849	Casca Queimada de Sol
6850	Escalpo de Sanguescalpo
6851	Essência dos Exilados
6852	Olho Eterno
6866	Símbolo da Vida
6887	Rabo-amarelo Mosqueado
6888	Ovo Assado com Ervas
6889	Ovo Pequeno
6890	Carne de Urso Defumada
6891	Receita: Ovo Assado com Ervas
6892	Receita: Carne de Urso Defumada
6893	Chave da Oficina
6894	Coração Rodopiante
6895	Martelo de Ferreiro de Jardel
6897	Manual: Caminho do Berserker
6898	Orbe de Soran'ruk
6899	Orbe de Bruxo 35
6900	Robessangre Dourado Encantado
6901	Capa do Trilhador Reluzente
6902	Embraces de Serra'kis
6903	Calças do Vislumbrador
6904	Dentada de Serra'kis
6905	Machado do Recife
6906	Punhos de Algas
6907	Armadura de Tartaruga
6908	Elo de Ghamoo-ra
6909	Golpe da Hidra
6910	Calças da Sanguessuga
6911	Cilha de Musgo
6912	Palocórdio
6913	Cerne de Palocórdio
6914	Fragmento de Soran'ruk
6915	Fragmento Grande de Soran'ruk
6916	Tomo de Divindade
6926	Notas de Furen
6927	Orelha do Grande Gui
6928	Gargantilha de Pedra-sangrenta
6929	Pergaminho de Bath'rah
6930	Bastão de Canalização
6931	Tomo Mofado
6947	Veneno Instantâneo
6948	Pedra de Regresso
6949	Veneno Instantâneo II
6950	Veneno Instantâneo III
6951	Veneno Entorpecente II
6952	Pele Grossa de Urso
6953	Punho de Verigan
6966	Machado de Elunita
6967	Espada de Elunita
6968	Martelo de Elunita
6969	Adaga de Elunita
6970	Benevolência de Furen
6971	Coifa Endurecida pelo Fogo
6972	Cota Endurecida pelo Fogo
6973	Perneiras Temperadas pelo Fogo
6974	Manoplas Endurecidas pelo Fogo
6975	Machado Redemoinho
6976	Martelo de Guerra Redemoinho
6977	Espada Redemoinho
6978	Machado Úmbreo
6979	Machado de Fadigas
6980	Adaga de Fadigas
6981	Adaga Úmbrea
6982	Maça Úmbrea
6983	Martelo do Fadigas
6984	Espada Úmbrea
6985	Espada de Fadigas
6986	Lótus Rubro
6987	Escama de Peixe
6988	Pergaminho de Evocar Caçador Vil
6989	Ampola de Sangue de Furiódio
6990	Pedra Infernal Menor
6991	Carvão Fumegante
6992	Carregamento de Minério do Jardel
6993	Carregamento de Minério Refinado do Jardel
6994	Madeira de Carvalho de Pedralva
6995	Gema Kor Corrompida
6996	Anotações do Jardel sobre Armas
6997	Manuscrito Rasgado
6998	Botas Nímbus
6999	Tomo do Conluio
7000	Cinturão de Alburno
7001	Cetro da Lápide
7002	Broquel Ártico
7003	Broches de Besouro
7004	Capa da Prelação
7005	Faca de Esfolamento
7006	Tomo Reformado
7007	Pilhagem Gorrda de Backor
7026	Cinto de Linho
7027	Botas da Escuridão
7046	Calças de Seda Lazúli
7047	Mãos das Trevas
7048	Capuz de Seda Lazúli
7049	Luvas da Fé Verdadeira
7050	Bandana de Seda
7051	Colete Terrano
7052	Cinto de Seda Lazúli
7053	Manto de Seda Lazúli
7054	Veste do Poder
7055	Cinto de Seda Carmesim
7056	Manto de Seda Carmesim
7057	Omoplatas de Seda Verde
7058	Colete de Seda Carmesim
7059	Omoplatas de Seda Carmesim
7060	Omoplatas Lazúli
7061	Cinto de Seda Terrano
7062	Pantalonas de Seda Carmesim
7063	Veste de Seda Carmesim
7064	Luvas de Seda Carmesim
7065	Armadura de Seda Verde
7067	Terra Elemental
7068	Fogo Elemental
7069	Ar Elemental
7070	Água Elemental
7071	Broquel de Ferro
7072	Escama de Naga
7073	Presa Quebrada
7074	Garra Lascada
7075	Núcleo da Terra
7076	Essência da Terra
7077	Coração de Fogo
7078	Essência do Fogo
7079	Globo de Água
7080	Essência da Água
7081	Sopro Eólico
7082	Essência do Ar
7083	Gema de Kor Purificada
7084	Molde: Omoplatas de Seda Carmesim
7085	Molde: Omoplatas Lazúli
7086	Molde: Cinto de Seda Terrano
7087	Molde: Manto de Seda Carmesim
7088	Molde: Veste de Seda Carmesim
7089	Molde: Manto de Seda Lazúli
7090	Molde: Armadura de Seda Verde
7091	Molde: Luvas da Fé Verdadeira
7092	Molde: Mãos das Trevas
7093	Molde: Botas da Escuridão
7094	Galho de Madeira Flutuante
7095	Botas do Brejo
7096	Pena Arrancada
7097	Carne de Coxa
7098	Presa Estilhaçada
7099	Tenaz Partida
7100	Linfa Grudenta
7101	Olho de Inseto
7106	Luvas do Zodíaco
7107	Cinturão Estelar
7108	Escudo de Infantaria
7109	Broquel do Pioneiro
7110	Armadura de Fio de Prata
7111	Armadura do Céu Noturno
7112	Armadura da Aurora
7113	Armadura Enevoada
7114	Molde: Luvas de Seda Lazúli
7115	Machado da Herança
7116	Adaga de Herança
7117	Martelo de Herança
7118	Espada de Herança
7119	Antena Agitada
7120	Baluarte do Ruga
7126	Lingote Fumegante de Ferro
7127	Azurita Pulverizada
7128	Casco Não Fendido de Sátiro
7129	Manoplas Brutais
7130	Elmo Brutal
7131	Tíbia de Presa do Dragão
7132	Guarda-pernas Brutais
7133	Cota Brutal
7134	Tíbia Firme de Presa do Dragão
7135	Tíbia Quebrada de Presa do Dragão
7146	A Chave Escarlate
7148	Cabo de Chupeta Goblínico
7166	Adaga de Cobre
7170	Espada aleatória do Twain FOO
7187	Botas de VanCleef
7188	Escudo da Guarda de Ventobravo
7189	Botas-foguete Goblínicas
7190	Botas-foguete Calcinadas
7191	Fiação com Fusível
7192	Diagrama: Botas-foguete Goblínicas
7206	Amostra de Água do Lago Espelhado
7207	Frasco de Jennea
7208	Chave de Tazan
7209	Algibeira de Tazan
7226	Treconitor Magostático
7227	Boca-de-leão de Balnir
7228	Sorvete de Morango de Tigule
7229	Colete do Explorador
7230	Martelo Potente do Castiga
7231	Carta de Apresentação do Astolfo
7247	Baú de Cofres de Contenção
7249	Gema Energizada da Fenda
7266	Tratado de Ur sobre Umbromancia
7267	Seda Pura de Aranha
7268	Amostra de Água Xaviana
7269	Frasco de Denya
7270	Cabelo da Irmã Risonha
7271	Presa de Mármore Impecável
7272	Morácea Carregada por Raio
7273	Vara Totêmica dos Cascasseca
7274	Rituais do Poder
7275	Os Pergaminhos Agamaggan
7276	Manto de Couro Feito à Mão
7277	Braçadeiras de Couro Feitas à Mão
7278	Aljava de Couro Leve
7279	Bornal de Munição Pequeno de Couro
7280	Calças de Couro Rústico
7281	Braçadeiras de Couro Leve
7282	Calças de Couro Leve
7283	Manto de Dragonete Negro
7284	Luvas de Dragonete Vermelho
7285	Luvas Ágeis de Couro
7286	Escama de Dragonete Negro
7287	Escama de Dragonete Vermelho
7288	Molde: Calças de Couro Rústico
7289	Molde: Manto de Dragonete Negro
7290	Molde: Luvas de Dragonete Vermelho
7291	Orbe Infernal
7292	Cofre de Contenção Cheio
7293	Gema de Mana de Dalaran
7294	Livro-caixa de Andron
7295	Caderno de Tazan
7296	Tocha Apagada
7297	Desgraça de Morbídio
7298	Lâmina da Astúcia
7306	Cabeça do Fenwick
7307	Verme Come-carne
7308	Cantochão da Manifestação
7309	Relatório Situacional de Dalaran
7326	Machado do Thun'grim
7327	Adaga do Thun'grim
7328	Maça do Thun'grim
7329	Espada do Thun'grim
7330	Broquel do Infiltrador
7331	Escudo da Falange
7332	Armadura Régia
7333	Apito do Supervisor
7334	Veste Florescente
7335	Túnica Gris
7336	Cota Encadeada Matagreste
7337	A Pedra
7338	Anel dos Sentimentos
7339	Anel com Diamante Minúsculo
7340	Diamante Solitário Impecável
7341	Anel de Zircônia Cúbica
7342	Anel de Prata da Agasterne
7343	Chave de Boca do Gomez
7344	Tocha da Chama Sagrada
7345	Chave de Fenda do Gomez
7346	Martelo do Gomez
7347	Inversor de Engrenagem do Gomez
7348	Luvas do Seteiro
7349	Luvas do Herborista
7350	Braçadeiras do Discípulo
7351	Botas do Discípulo
7352	Omoplatas Terranas de Couro
7353	Armadura Acolchoada do Ancião
7354	Botas do Ancião
7355	Braçadeiras do Ancião
7356	Manto do Ancião
7357	Chapéu do Ancião
7358	Luvas do Surrupiador
7359	Luvas Terranas Pesadas
7360	Molde: Luvas de Couro Escuro
7361	Molde: Luvas do Herborista
7362	Molde: Omoplatas Terranas de Couro
7363	Molde: Luvas do Surrupiador
7364	Molde: Luvas Terranas Pesadas
7365	Engrenotreco Gnomo
7366	Luvas do Ancião
7367	Dragonas do Ancião
7368	Calças do Ancião
7369	Veste do Ancião
7370	Faixa do Ancião
7371	Aljava Pesada
7372	Bornal de Munição de Couro Pesado
7373	Perneiras de Couro Crepuscular
7374	Armadura de Couro Crepuscular
7375	Armadura de Dragonete Verde
7376	Detona-cuca do Gomez
7377	Manto de Couro Gélido
7378	Braçadeiras Crepusculares
7386	Braçadeiras de Dragonete Verde
7387	Cinto Crepuscular
7388	Chave de Crânio
7389	Livro-caixa da Empreendimentos S.A.
7390	Botas Crepusculares
7391	Botas Velozes
7392	Escama de Dragonete Verde
7406	Cordão do Infiltrador
7407	Armadura do Infiltrador
7408	Omoplatas do Infiltrador
7409	Botas do Infiltrador
7410	Braçadeiras do Infiltrador
7411	Manto do Infiltrador
7412	Luvas do Infiltrador
7413	Casquete do Infiltrador
7414	Calças do Infiltrador
7415	Espaldares do Dervixe
7416	Braçadeiras da Falange
7417	Botas da Falange
7418	Peitoral da Falange
7419	Manto da Falange
7420	Cimeira da Falange
7421	Manoplas da Falange
7422	Cinturão da Falange
7423	Perneiras da Falange
7424	Espaldares da Falange
7425	Cabeça do Cyrik
7426	Anel Cerúleo
7427	Talismã Cerúleo
7428	Pelego de Gato das Sombras
7429	Armadura Crepuscular
7430	Veste Crepuscular
7431	Calças Crepusculares
7432	Capucho Crepuscular
7433	Luvas Crepusculares
7434	Botas Crepusculares
7435	Dragonas Crepusculares
7436	Capa Crepuscular
7437	Manilhas Crepusculares
7438	Cinto Crepuscular
7439	Peitoral da Sentinela
7440	Calças da Sentinela
7441	Casquete da Sentinela
7442	Chave de Giramastro
7443	Luvas da Sentinela
7444	Botas da Sentinela
7445	Omoplatas da Sentinela
7446	Manto da Sentinela
7447	Braçadeiras da Sentinela
7448	Cinturão da Sentinela
7449	Molde: Perneiras de Couro Crepuscular
7450	Molde: Armadura de Dragonete Verde
7451	Molde: Braçadeiras de Dragonete Verde
7452	Molde: Botas Crepusculares
7453	Molde: Botas Velozes
7454	Peitoral do Cavaleiro
7455	Guarda-pernas do Cavaleiro
7456	Cimeira do Cavaleiro
7457	Manoplas do Cavaleiro
7458	Botas do Cavaleiro
7459	Brafoneiras do Cavaleiro
7460	Manto do Cavaleiro
7461	Braçadeiras do Cavaleiro
7462	Cinturão do Cavaleiro
7463	Broquel da Sentinela
7464	Glifos de Evocação
7465	Timbre do Cavaleiro
7466	Anel de Cinábrio
7467	Colar de Cinábrio
7468	Veste Régia
7469	Perneiras Régias
7470	Chapéu de Teurgo Régio
7471	Luvas Régias
7472	Botas Régias
7473	Dragonas Régias
7474	Manto Régio
7475	Manilhas Régias
7476	Faixa Régia
7477	Túnica do Patrulheiro
7478	Perneiras do Patrulheiro
7479	Elmo do Patrulheiro
7480	Luvas do Patrulheiro
7481	Botas do Patrulheiro
7482	Omoplatas do Patrulheiro
7483	Manto do Patrulheiro
7484	Munhequeiras do Patrulheiro
7485	Cordão do Patrulheiro
7486	Peitoral do Capitão
7487	Perneiras do Capitão
7488	Diadema do Capitão
7489	Manoplas do Capitão
7490	Botas do Capitão
7491	Guarda-ombros do Capitão
7492	Manto do Capitão
7493	Braçadeiras do Capitão
7494	Cinta do Capitão
7495	Broquel do Capitão
7496	Escudo de Placa do Campo de Batalha
7497	Anel de Marfim
7498	Parte de Cima da Chave de Gelkak
7499	Parte do Meio da Chave de Gelkak
7500	Parte de Baixo da Chave de Gelkak
7506	Controle Remoto Universal Gnômico
7507	Orbe Arcano
7508	Orbe Meridiano
7509	Veste de Fios de Mana
7510	Vestes de Fogo Místico Inferior
7511	Veste do Nó Astral
7512	Veste de Renda Etérea
7513	Varinha Iraflama
7514	Varinha da Fúria Glacial
7515	Orbe Celestial
7516	Instruções de Tabetha
7517	Túnica de Teia Diáfana
7518	Veste de Teia Diáfana
7519	Calças de Teia Diáfana
7520	Bacinete de Teia Diáfana
7521	Luvas de Teia Diáfana
7522	Botas de Teia Diáfana
7523	Ombreiras de Teia Diáfana
7524	Capa de Teia Diáfana
7525	Braçadeiras de Teia Diáfana
7526	Cinto de Teia Diáfana
7527	Peito d'Armas Cabalístico
7528	Perneiras Cabalísticas
7529	Elmo Cabalístico
7530	Luvas Cabalísticas
7531	Botas Cabalísticas
7532	Espaldares Cabalísticos
7533	Manto Cabalístico
7534	Braçadeiras Cabalísticas
7535	Cinto Cabalístico
7536	Muralha de Proteção do Campeão
7537	Escudo Gótico
7538	Armadura do Campeão
7539	Perneiras do Campeão
7540	Capacete do Campeão
7541	Manoplas do Campeão
7542	Grevas do Campeão
7543	Brafoneiras do Campeão
7544	Capa do Campeão
7545	Braçadeiras do Campeão
7546	Cinturão do Campeão
7547	Anel de Ônix
7548	Gargantilha de Ônix
7549	Abraço da Fada
7550	Honra do Guerreiro
7551	Talismã Entrelaçado de Opalina
7552	Gancho do Falcão
7553	Anel do Unicórnio
7554	Ramo de Salgueiro
7555	Estrela Régia
7556	Orbe Crepuscular
7557	Bastão de Teia Diáfana
7558	Báculo Cintilante
7559	Bordão Rúnico
7560	Diagrama: Controle Remoto Universal Gnômico
7561	Diagrama: Cabo de Chupeta Goblínico
7566	Espada da Família Agamand
7567	Machado da Família Agamand
7568	Adaga da Família Agamand
7569	Maça da Família Agamand
7586	Esperança de Tharnariun
7587	Instruções de Thun'grim
7606	Manoplas Polares
7607	Varinha de Zibelina
7608	Caneco de Qualidade do Vidente
7609	Báculo Âmbar do Ancião
7610	Esfera da Aurora
7611	Báculo Enevoado
7613	Molde: Armadura de Couro Verde
7626	Trouxa de Peles
7627	Entrega para Dolanaar
7628	Carta Comum
7629	Fardo de Ulkor
7646	Caixote com Provisões para Estalagem
7666	Colar Estilhaçado
7667	Frasco de Vidência de Didiê
7668	Diário Manchado de Sangue
7669	Rubi do Colar Estilhaçado
7670	Safira do Colar Estilhaçado
7671	Topázio do Colar Estilhaçado
7672	Fonte de Força do Colar Estilhaçado
7673	Colar de Aprimoramento do Didiê
7674	Encomenda para Mathias
7675	Horário de Embarque de Défias
7676	Chá de Cardo
7678	Receita: Chá de Cardo
7679	Presa de Morcego Corvoide
7680	Escama de Basilisco Jadespinho
7681	Estilhaço de Golem de Obsidiana
7682	Atiçador de Tortura
7683	Soqueira Ensanguentada
7684	Dragonas do Mago Sangrento
7685	Orbe do Vidente Esquecido
7686	Olho do Espinha de Ferro
7687	Punho do Espinha de Ferro
7688	Caixa Torácica do Espinha de Ferro
7689	Aurora Mórbida
7690	Torno de Ébano
7691	Mortalha Embalsamada
7708	Varinha Necrótica
7709	Perneiras Empesteadas
7710	Vara de Treinamento do Lobato
7711	Veste de Doan
7712	Dragonas de Doan
7713	Bastão do Ilusionista
7714	Lâmina Hipnótica
7715	Relatório de Onin
7716	Colar Estilhaçado
7717	Assolador
7718	Ombreiras de Herodes
7719	Elmo do Berserker em Fúria
7720	Chapéu do Cristalba
7721	Mão da Retidão
7722	Amuleto Triuno
7723	Poder de Mograine
7724	Manoplas da Divindade
7726	Égide do Comandante Escarlate
7727	Brafoneiras do Vigia
7728	Vestes do Cativador
7729	Mosquete Chesterfall
7730	Esmagador de Cobalto
7731	Talismã do Fragmento Espectral
7733	Cajado da Pré-história
7734	Bolsa Seis Demônios
7735	Rosa de Jannok
7736	Clava da Luta
7737	Diário de Sethir
7738	Luvas Perenes
7739	Capa das Terras Florestais
7740	Medalhão de Gni'kiv
7741	O Bastão de Tsol
7742	Diagrama: Dispositivo Ocultador Gnômico
7746	Comenda da Liga de Exploradores
7747	Protetor Torpe
7748	Broquel Pedraforte
7749	Orbe Ômega
7750	Dragonas do Sofrimento
7751	Botas do Vorrel
7752	Destruidor de Sonhos
7753	Espirra-sangue
7754	Botas do Precursor
7755	Omoplatas Pedernais
7756	Luvas de Adestramento de Cães
7757	Cajado Teceventos
7758	Estoque Impiedoso
7759	Peito d'Armas do Arconte
7760	Kilt do Chefe Guerreiro
7761	Aniquilador Garra de Aço
7766	Odre Marrom Vazio
7767	Odre Azul Vazio
7768	Odre Vermelho Vazio
7769	Odre Marrom Cheio
7770	Odre Azul Cheio
7771	Odre Vermelho Cheio
7786	Rachacrânio
7787	Guardião Resplandecente
7806	Pirulito
7807	Barra de Chocolate
7808	Tablete de Chocolate
7809	Vestido de Páscoa
7810	Ampola da Mais Pura Água
7811	Gotas Restantes da Mais Pura Água
7812	Braçadeiras da Manifestação Corrupta
7813	Estilhaço de Água
7846	Presa de Coiote do Rochedo
7847	Moela de Urubu
7848	Estilhaço de Elemental da Rocha
7866	Recipiente de Taumaturgia Vazio
7867	Recipiente com Sangue de Dragão
7868	Thieven' Kit
7869	Baú do Lucius
7870	Cofre com Recipientes de Taumaturgia
7871	Símbolo de Ladroagem
7872	Ferramentas Enferrujadas de Ladrões
7886	Diário Não Traduzido
7887	Colar e Gema Recuperados
7888	Colar de Aprimoramento do Jarkal
7906	Chifres de Nez'Ra
7907	Certificado de Ladroagem
7908	Diário de Filipe Pinel
7909	Água-marinha
7910	Rubi-estrela
7911	Minério de Veraprata
7912	Pedra Maciça
7913	Omoplatas de Ferro Barbarescas
7914	Peitoral de Ferro Barbaresco
7915	Elmo de Ferro Barbaresco
7916	Botas de Ferro Barbarescas
7917	Luvas de Ferro Barbarescas
7918	Ombreiras Pesadas de Mithril
7919	Manoplas Pesadas de Mithril
7920	Calças de Escama de Mithril
7921	Calças Pesadas de Mithril
7922	Elmo de Placa de Aço
7923	Chave da Torre Défias
7924	Braçadeiras de Escama de Mithril
7925	Luvas de Escama de Mithril
7926	Calças Ornadas de Mithril
7927	Luvas Ornadas de Mithril
7928	Ombreiras Ornadas de Mithril
7929	Perneiras de Guerra Órquicas
7930	Peitoral Pesado de Mithril
7931	Coifa de Mithril
7932	Omoplatas de Escama de Mithril
7933	Botas Pesadas de Mithril
7934	Elmo Pesado de Mithril
7935	Peitoral Ornado de Mithril
7936	Botas Ornadas de Mithril
7937	Elmo Ornado de Mithril
7938	Manoplas Veraprata
7939	Peitoral Veraprata
7941	Machado Pesado de Mithril
7942	Machado Azul Reluzente
7943	Lâmina Maléfica de Mithril
7944	Florete Ofuscante de Mithril
7945	Grande Maça Preta
7946	Martelo de Mithril Rúnico
7947	Estoque de Ébano
7948	Cinturão de Thero-shan
7949	Perneiras de Thero-shan
7950	Armadura de Thero-shan
7951	Mãos de Thero-shan
7952	Botas de Thero-shan
7953	Máscara de Thero-shan
7954	O Despedaçador
7955	Espadão de Cobre
7956	Martelo de Guerra de Bronze
7957	Montante de Bronze
7958	Machado de Batalha de Bronze
7959	Praga
7960	Campeã de Veraprata
7961	Lâmina Fantasma
7963	Peitoral de Aço
7964	Pedra de Afiar Maciça
7965	Contrapeso Maciço
7966	Pedra de Amolar Maciça
7967	Espigão de Escudo de Mithril
7968	Tesouro dos Mares do Sul
7969	Esporas de Mithril
7970	B.E.C.A.
7971	Pérola Negra
7972	Linfa de Morte-viva
7973	Marisco Boca-grande
7974	Carne de Marisco Condimentada
7975	Instruções: Calças Pesadas de Mithril
7976	Instruções: Espigão de Escudo de Mithril
7977	Instruções: Luvas de Escama de Mithril
7978	Instruções: Omoplatas de Ferro Barbarescas
7979	Instruções: Peitoral de Ferro Barbaresco
7980	Instruções: Elmo de Ferro Barbaresco
7981	Instruções: Botas de Ferro Barbarescas
7982	Instruções: Luvas de Ferro Barbarescas
7983	Instruções: Calças Ornadas de Mithril
7984	Instruções: Luvas Ornadas de Mithril
7985	Instruções: Ombreiras Ornadas de Mithril
7986	Instruções: Peitoral Ornado de Mithril
7987	Instruções: Elmo Ornado de Mithril
7988	Instruções: Botas Ornadas de Mithril
7989	Instruções: Esporas de Mithril
7990	Instruções: Elmo Pesado de Mithril
7991	Instruções: Omoplatas de Escama de Mithril
7992	Instruções: Machado Azul Reluzente
7993	Instruções: Florete Ofuscante de Mithril
7994	Instruções: Perneiras de Guerra Órquicas
7995	Instruções: Braçadeiras de Escama de Mithril
7996	Chapéu de Pescaria Usado
7997	Máscara Vermelha Défias
8006	O Candiru
8007	Citrino de Mana
8008	Rubi de Mana
8009	Pedra de Energia de Dêntrio
8026	Tesouro da Família Garreta
8027	Tesouro do Krom Braçoforte
8028	Instruções: Martelo de Mithril Rúnico
8029	Instruções: Lâmina Maléfica de Mithril
8030	Instruções: Estoque de Ébano
8046	Diário de Marta
8047	Campânula de Fungo Magenta
8048	Apanhador de Sonhos de Esmeralda
8049	Colar de Masca-pinho
8050	Joia de Tallonkai
8051	Sinalizador
8052	Pedra de Energia de An'Alleum
8053	Fonte de Energia de Obsidiana
8066	Apito do Arruela
8067	Munição Leve Manufaturada
8068	Munição Pesada Manufaturada
8069	Chumbo Maciço Manufaturado
8070	Vale-recompensa
8071	Espeto de Churrasco
8072	Chave da Torre de Biela
8073	Esconderijo da Mistura Adulterada do Zanzil
8074	Cabeça do Gallywix
8075	Pão Azedo Conjurado
8076	Pão Doce Conjurado
8077	Água Mineral Conjurada
8078	Água Borbulhante Conjurada
8079	Água Cristalina Conjurada
8080	Peito d'Armas Leve de Placa
8081	Cinto Leve de Placa
8082	Botas Leves de Placa
8083	Braçadeiras Leves de Placa
8084	Luvas Leves de Placa
8085	Calças Leves de Placa
8086	Ombreiras Leves de Placa
8087	Amostra de Preparado Adulterado de Zanzil
8088	Cinto de Malha de Placa
8089	Botas de Malha de Placa
8090	Braçadeiras de Malha de Placa
8091	Luvas de Malha de Placa
8092	Elmo de Malha de Placa
8093	Perneiras de Malha de Placa
8094	Armadura de Malha de Placa
8095	Óleo do Hinoto
8106	Armadura Hibernal
8107	Botas Hibernais
8108	Braçadeiras Hibernais
8109	Manto Hibernal
8110	Luvas Hibernais
8111	Dragonas Hibernais
8112	Calças Hibernais
8113	Veste Hibernal
8114	Faixa Hibernal
8115	Capucho Hibernal
8116	Cinto Heráldico
8117	Botas Heráldicas
8118	Braçadeiras Heráldicas
8119	Peitoral Heráldico
8120	Manto Heráldico
8121	Luvas Heráldicas
8122	Bacinete Heráldico
8123	Perneiras Heráldicas
8124	Espaldares Heráldicos
8125	Braçadeiras do Mirmidão
8126	Peitoral do Mirmidão
8127	Capa do Mirmidão
8128	Manoplas do Mirmidão
8129	Cinturão do Mirmidão
8130	Grevas do Mirmidão
8131	Elmo do Mirmidão
8132	Perneiras do Mirmidão
8133	Brafoneiras do Mirmidão
8134	Defensor do Mirmidão
8135	Escudo de Cromita
8136	Tumor Gigantesco
8137	Braçadeiras de Cromita
8138	Guarda-peito de Cromita
8139	Manoplas de Cromita
8140	Cinturão de Cromita
8141	Grevas de Cromita
8142	Celada de Cromita
8143	Coxotes de Cromita
8144	Brafoneiras de Cromita
8146	Garra Maléfica
8147	Chavinha de Cobre
8148	Chavinha de Prata
8149	Patuá Vodu
8150	Sal Rochafunda
8151	Frasco de Mojo
8152	Frasco de Mojo Grande
8153	Vinha Selvagem
8154	Escama de Escorpídeo
8155	Sacrifício de Sathrah
8156	Munhequeiras do Justador
8157	Guarda-peito do Justador
8158	Manoplas do Justador
8159	Cinturão do Justador
8160	Grevas do Justador
8161	Viseira do Justador
8162	Coxotes do Justador
8163	Brafoneiras do Justador
8164	Papel de Carta de Teste
8165	Escama Gasta de Dragão
8167	Escama de Tartaruga
8168	Pena Azeviche
8169	Pelego Grosso
8170	Couro Rústico
8171	Pelego Rústico
8172	Pelego Grosso Curado
8173	Kit de Armadura Grossa
8174	Chapéu Confortável de Couro
8175	Túnica da Escapada Noturna
8176	Bandana da Escapada Noturna
8177	Espada de Exercício
8178	Espada de Treino
8179	Arco dos Cadetes
8180	Arco de Caça
8181	Rifle de Caça
8182	Rifle de Chumbinho
8183	Arco de Precisão
8184	Tacafogo
8185	Perneiras de Escama de Tartaruga
8186	Varinha Severa
8187	Luvas de Escama de Tartaruga
8188	Espingarda Explosiva
8189	Peitoral de Escama de Tartaruga
8190	Espada Hanzo
8191	Elmo de Escama de Tartaruga
8192	Omoplatas da Escapada Noturna
8193	Calças da Escapada Noturna
8194	Quebra-nozes Goblínico
8195	Manto da Escapada Noturna
8196	Cimitarra de Ébano
8197	Botas da Escapada Noturna
8198	Braçadeiras de Escama de Tartaruga
8199	Destruidor do Campo de Batalha
8200	Veste do Grande Vodu
8201	Máscara do Grande Vodu
8202	Calças do Grande Vodu
8203	Peitoral Escorpídeo Resistente
8204	Luvas Escorpídeas Resistentes
8205	Braçadeiras Escorpídeas Resistentes
8206	Perneiras Escorpídeas Resistentes
8207	Omoplatas Escorpídeas Resistentes
8208	Elmo Escorpídeo Resistente
8209	Botas Escorpídeas Resistentes
8210	Omoplatas de Couro Silvestre
8211	Colete de Couro Silvestre
8212	Perneiras de Couro Silvestre
8213	Botas de Couro Silvestre
8214	Capacete de Couro Silvestre
8215	Manto de Couro Silvestre
8216	Manto do Grande Vodu
8217	Aljava Saca-rápido
8218	Bornal para Munição de Couro Grosso
8223	Lâmina do Basilisco
8224	Estripador Silitídeo
8225	Florete Maldito
8226	O Carniceiro
8243	Biscoito do Scooby
8244	Esfera Impecável de Draenetista
8245	Túnica Imperial Vermelha
8246	Botas Imperiais Vermelhas
8247	Braçadeiras Imperiais Vermelhas
8248	Manto Imperial Vermelho
8249	Luvas Imperiais Vermelhas
8250	Dragonas Imperiais Vermelhas
8251	Calças Imperiais Vermelhas
8252	Veste Imperial Vermelha
8253	Faixa Imperial Vermelha
8254	Diadema Imperial Vermelho
8255	Cinturão de Couro de Serpente
8256	Botas de Couro de Serpente
8257	Braçadeiras de Couro de Serpente
8258	Armadura de Couro de Serpente
8259	Manto de Couro de Serpente
8260	Luvas de Couro de Serpente
8261	Elmo de Couro de Serpente
8262	Perneiras de Couro de Serpente
8263	Espaldares de Couro de Serpente
8264	Munhequeiras do Bastião de Ébano
8265	Armadura do Bastião de Ébano
8266	Manto do Bastião de Ébano
8267	Manoplas do Bastião de Ébano
8268	Cinturão do Bastião de Ébano
8269	Botas do Bastião de Ébano
8270	Capacete do Bastião de Ébano
8271	Perneiras do Bastião de Ébano
8272	Ombreiras do Bastião de Ébano
8273	Munhequeiras Valorosas
8274	Couraça Valorosa
8275	Broquel do Bastião de Ébano
8276	Manoplas Valorosas
8277	Cinturão Valoroso
8278	Grevas Valorosas
8279	Elmo Valoroso
8280	Guarda-pernas Valorosos
8281	Brafoneiras Valorosas
8282	Escudo Valoroso
8283	Armadura Arcana
8284	Botas Arcanas
8285	Embraces Arcanos
8286	Manto Arcano
8287	Luvas Arcanas
8288	Ombreiras Arcanas
8289	Perneiras Arcanas
8290	Veste Arcana
8291	Faixa Arcana
8292	Mantel Arcano
8293	Cinto do Viajante
8294	Botas do Viajante
8295	Braçadeiras do Viajante
8296	Gibão do Viajante
8297	Manto do Viajante
8298	Luvas do Viajante
8299	Elmo do Viajante
8300	Perneiras do Viajante
8301	Espaldares do Viajante
8302	Braçadeiras do Herói
8303	Peitoral do Herói
8304	Capa do Herói
8305	Manoplas do Herói
8306	Cinto do Herói
8307	Botas do Herói
8308	Elo do Herói
8309	Perneiras do Herói
8310	Brafoneiras do Herói
8311	Avambraços de Placa de Alabastro
8312	Peitoral de Alabastro
8313	Broquel do Herói
8314	Manoplas de Placa de Alabastro
8315	Cinturão de Placa de Alabastro
8316	Grevas de Placa de Alabastro
8317	Capacete de Placa de Alabastro
8318	Perneiras de Placa de Alabastro
8319	Brafoneiras de Placa de Alabastro
8320	Escudo de Alabastro
8343	Fio Grosso de Seda
8344	Fiandeiras Prateadas
8345	Elmo Cabeça de Lobo
8346	Manoplas do Mar
8347	Manoplas de Escama de Dragão
8348	Elmo de Fogo
8349	Peitoral Emplumado
8350	O 1 Anel
8363	Patuá Vodu de Xamã
8364	Truta Cabeça-de-mithril
8365	Truta Cabeça-de-mithril Crua
8366	Truta Inchada
8367	Peitoral de Escama de Dragão
8368	Lupelego Grosso
8383	Carta Simples
8384	Molde: Chapéu Confortável de Couro
8385	Molde: Luvas de Escama de Tartaruga
8386	Molde: Veste do Grande Vodu
8387	Molde: Máscara do Grande Vodu
8388	Molde: Manto da Escapada Noturna
8389	Molde: Calças do Grande Vodu
8390	Molde: Manto do Grande Vodu
8391	Mandíbula de Rasgarrindo
8392	Pulmão de Javali Destroçado
8393	Tenaz de Escórpode
8394	Cérebro de Basilisco
8395	Molde: Peitoral Escorpídeo Resistente
8396	Moela de Abutre
8397	Molde: Braçadeiras Escorpídeas Resistentes
8398	Molde: Luvas Escorpídeas Resistentes
8399	Molde: Botas Escorpídeas Resistentes
8400	Molde: Omoplatas Escorpídeas Resistentes
8401	Molde: Perneiras Escorpídeas Resistentes
8402	Molde: Elmo Escorpídeo Resistente
8403	Molde: Omoplatas de Couro Silvestre
8404	Molde: Colete de Couro Silvestre
8405	Molde: Capacete de Couro Silvestre
8406	Molde: Botas de Couro Silvestre
8407	Molde: Perneiras de Couro Silvestre
8408	Molde: Manto de Couro Silvestre
8409	Molde: Omoplatas da Escapada Noturna
8410	B.O.M.B.A.
8411	Coquetel de Sumo de Pulmão
8412	Amostra de Escórpode Macerado
8423	Composto de Córtex Cerebral
8424	Chiclete de Moela
8425	Titica de Papagaio
8426	Pena Grande Eriçada
8427	Carcaça Mutilada de Rato
8428	Glândula de Orvalho Cheia
8429	Glândula de Orvalho Perfurada
8430	Glândula de Orvalho Vazia
8431	Bobina de Seda Chartreuse Leve
8432	Colônia de Mixilpixil
8443	Ornamento de Gahz'ridian
8444	Chave do Carrasco
8463	Ordens do Chefe Guerreiro
8483	Bolsa de Água do Errante
8484	Pacote de Suprimentos da Cia. Águas de Geringontzan
8485	Transportador de Gato (Bombaim)
8486	Transportador de Gato (Cornish Rex)
8487	Transportador de Gato (Tigrado Laranja)
8488	Transportador de Gato (Tigrado Prateado)
8489	Transportador de Gato (Branco)
8490	Transportador de Gato (Siamês)
8491	Transportador de Gato (Tigrado Preto)
8492	Poleiro de Papagaio (Arara-da-asa-verde)
8493	Barrica do Weegli
8494	Poleiro de Papagaio (Arara-jacinto)
8495	Poleiro de Papagaio (Senegal)
8496	Poleiro de Papagaio (Cacatua)
8497	Caixote de Coelho (Nevinhal)
8498	Dragonetinho Esmeralda
8499	Dragonetinho Carmesim
8500	Grande Coruja com Chifres
8501	Falcoruja
8502	Caixa de Loteria de Bronze
8503	Caixa de Loteria de Bronze Pesada
8504	Caixa de Loteria de Ferro
8505	Caixa de Loteria de Ferro Pesada
8506	Caixa de Loteria de Mithril
8507	Caixa de Loteria de Mithril Pesada
8508	Barbatana Grande
8523	Kit de Teste de Campo
8524	Modelo 4711-KTC Fonte de Energia
8525	Ordem de Compra da Zilda
8526	Tragão Violeta
8527	Kit de Teste de Campo Lacrado
8528	Pó Violeta
8529	Elixir Nublacuca
8543	Cogumelo Subaquático
8544	Bandagem de Magitrama
8545	Bandagem Grossa de Magitrama
8546	Sais Aromáticos Poderosos
8547	Fórmula: Sais Aromáticos Poderosos
8548	Bastão Divinomático
8563	Mecanostruz Vermelho
8564	Ovo de Hipogrifo
8583	Trompa da Montaria Descarnada
8584	Treco de Coleta Vazio
8585	Treco de Coleta Cheio
8586	Apito do Raptor Vermelho Mosqueado
8587	Pedaços de Inseto Centiparte
8588	Apito do Raptor Esmeralda
8589	Apito Velho do Raptor Marfim
8590	Apito Velho do Raptor Obsidiano
8591	Apito do Raptor Turquesa
8592	Apito do Raptor Violeta
8593	Aparelho de Inspeção do Anilhacido
8594	Relatório de Análise de Insetos
8595	Mecanostruz Azul
8603	Orvalho Moitagulhas
8623	Transmissor de Emergência OOX-17/TN
8624	Faiscante Vermelho
8625	Faiscante Branco
8626	Faiscante Azul
8627	Rédeas do Sabre-da-noite
8628	Rédeas do Sabre-da-noite Malhado
8629	Rédeas do Sabre-da-noite Listrado
8630	Rédeas do Tigre de Bengala
8631	Rédeas do Sabre-de-gelo Listrado
8632	Rédeas do Sabre-de-gelo Malhado
8633	Rédeas do Leopardo
8643	Ovo Extraordinário
8644	Ovo Fecundo
8645	Ovo Comum
8646	Ovo Gorado
8647	Caixa de Ovos
8663	Insígnia de Mithril
8683	Maçã Fresca da Clara
8684	Suco Gami das Terras Agrestes
8685	Entrega de Suco Gami de Dran
8686	Pingente de Mithril
8687	Descrição do Visitante de Thredd Lacrada
8703	Sinete da Aptidão
8704	Transmissor de Emergência OOX-09/HL
8705	Transmissor de Emergência OOX-22/FE
8707	Escama Eletrificada de Gahz'rilla
8708	Martelo da Aptidão
8723	Cabeça do Califa Escorpicada
8724	Segredo de Rin'ji
8743	Livro de Marca do Indomado
8744	Livro de Ira
8745	Livro de Toque de Cura
8746	Capucho Entrelaçado
8747	Elmo de Couro Endurecido
8748	Coifa de Malha Dupla
8749	Chapéu de Crochê
8750	Chapéu de Couro Grosso
8751	Coifa Entretecida
8752	Diadema Laminado de Escama
8753	Capacete de Couro Liso
8754	Capuz de Sarja
8755	Capacete Leve de Placa
8756	Livro de Recrescimento II
8757	Livro de Fogo Estelar
8758	Livro de Remover Maldição
8759	Livro de Recrescimento III
8760	Livro de Abolir Veneno
8761	Livro de Fogo Estelar II
8762	Livro de Rejuvenescimento V
8763	Livro de Fogo Lunar V
8764	Livro de Fogo Feérico II
8765	Livro de Recrescimento IV
8766	Orvalho da Glória Matinal
8768	Livro de Fogo Estelar III
8769	Livro de Espinhos IV
8770	Livro de Fogo Lunar VI
8771	Livro de Rejuvenescimento VI
8772	Livro de Recrescimento V
8773	Livro de Raízes Enredantes V
8774	Livro de Toque de Cura VII
8775	Livro de Tranquilidade II
8776	Livro de Marca do Indomado VI
8777	Livro de Fogo Lunar IX
8778	Livro de Rejuvenescimento VII
8779	Livro de Fogo Feérico III
8780	Livro de Fogo Estelar V
8781	Livro de Recrescimento VII
8782	Livro de Espinhos V
8783	Livro de Toque de Cura IX
8784	Livro de Ira VII
8785	Livro de Rejuvenescimento IX
8786	Livro de Tranquilidade III
8787	Livro de Acalmar Animal
8788	Livro de Acalmar Animal II
8789	Livro de Acalmar Animal III
8790	Livro de Fogo Feérico IV
8791	Livro de Recrescimento VIII
8792	Livro de Espinhos VI
8793	Livro de Ira VIII
8794	Livro de Toque de Cura X
8795	Livro de Raízes Enredantes VI
8796	Livro de Fogo Lunar X
8797	Livro de Rejuvenescimento X
8798	Livro de Fogo Estelar VI
8799	Livro de Marca do Indomado VII
8800	Livro de Recrescimento IX
8801	Livro de Tranquilidade IV
8802	Tomo de Intelecto Arcano
8803	Tomo de Bola de Fogo
8804	Tomo de Explosão Arcana
8805	Tomo de Detectar Magia
8806	Tomo de Remover Maldição Inferior
8807	Tomo de Amplificar Magia
8808	Tomo de Escudo de Mana
8809	Tomo de Sono
8810	Tomo de Sono II
8811	Tomo de Calcinar
8812	Tomo de Explosão Arcana II
8813	Tomo de Atenuar Magia II
8814	Tomo de Bola de Fogo V
8815	Tomo de Cone de Frio
8816	Tomo de Seta de Gelo V
8818	Tomo de Escudo de Mana II
8819	Tomo de Calcinar II
8820	Tomo de Proteção contra Fogo II
8821	Tomo de Amplificar Magia II
8822	Tomo de Explosão Arcana III
8823	Tomo de Impacto de Fogo IV
8824	Tomo de Bola de Fogo VI
8825	Tomo de Proteção contra Gelo III
8826	Tomo de Mísseis Arcanos IV
8827	Elixir de Andar sobre a Água
8828	Tomo de Seta de Gelo VI
8829	Tomo de Cone de Frio II
8830	Tomo de Calcinar III
8831	Lótus Roxo
8832	Tomo de Nevasca III
8833	Tomo de Escudo de Mana III
8834	Tomo de Atenuar Magia III
8835	Tomo de Bola de Fogo VII
8836	Lágrimas-de-arthas
8837	Tomo de Explosão Arcana V
8838	Ervassol
8839	Ervacega
8840	Tomo de Conjurar Gema de Mana II
8841	Tomo de Impacto de Fogo V
8842	Tomo de Seta de Gelo VII
8843	Tomo de Proteção contra Fogo III
8844	Tomo de Sono III
8845	Cogumelo-fantasma
8846	Sangue-de-grom
8847	Tomo de Calcinar V
8848	Tomo de Golpe Flamejante IV
8849	Tomo de Mísseis Arcanos V
8850	Tomo de Conjurar Água V
8851	Tomo de Bola de Fogo VIII
8852	Tomo de Intelecto Arcano IV
8853	Tomo de Conjurar Comida V
8854	Tomo de Cone de Frio III
8855	Tomo de Amplificar Magia III
8856	Tomo de Seta de Gelo VIII
8857	Tomo de Nevasca IV
8858	Tomo de Escudo de Mana IV
8859	Tomo de Impacto de Fogo VI
8860	Tomo de Bola de Fogo IX
8861	Tomo de Conjurar Gema de Mana III
8862	Tomo de Mísseis Arcanos VI
8863	Tomo de Atenuar Magia IV
8864	Tomo de Golpe Flamejante V
8865	Tomo de Armadura de Gelo III
8866	Tomo de Cone de Frio IV
8867	Tomo de Seta de Gelo IX
8868	Tomo de Conjurar Água VI
8869	Tomo de Proteção contra Fogo IV
8870	Tomo Maior de Invisibilidade
8871	Tomo de Conjurar Comida VI
8872	Tomo de Nevasca V
8873	Tomo de Escudo de Mana V
8874	Tomo de Calcinar VI
8875	Tomo de Proteção contra Gelo IV
8876	Tomo de Proteção contra Gelo II
8877	Tomo de Bola de Fogo X
8878	Tomo de Impacto de Fogo VII
8879	Tomo de Nova Congelante IV
8880	Tomo de Explosão Arcana VI
8881	Tomo de Destravamento de Hadggar IV
8882	Tomo de Amplificar Magia IV
8883	Tomo de Intelecto Arcano V
8884	Tomo de Seta de Gelo X
8885	Tomo de Mísseis Arcanos VII
8886	Tomo de Golpe Flamejante VI
8887	Tomo de Calcinar VII
8888	Tomo de Cone de Frio V
8889	Tomo de Conjurar Gema de Mana IV
8890	Tomo de Bola de Fogo XI
8891	Tomo de Armadura de Gelo IV
8892	Tomo de Conjurar Água VII
8893	Tomo de Sono IV
8894	Tomo de Atenuar Magia V
8895	Tomo de Nevasca VI
8896	Tomo de Escudo de Mana VI
8897	Tomo de Proteção contra Fogo V
8898	Tomo de Explosão Arcana IV
8899	Tomo de Calcinar IV
8900	Livro de Raízes Enredantes IV
8901	Livro de Toque de Cura VIII
8902	Livro de Marca do Indomado V
8903	Livro de Fogo Lunar VII
8904	Livro de Fogo Lunar VIII
8905	Livro de Recrescimento VI
8906	Livro de Rejuvenescimento VIII
8907	Livro de Fogo Estelar IV
8909	Incunábulo: Golpe Sagrado II
8910	Incunábulo: Impor as Mãos
8911	Incunábulo: Punho da Justiça
8912	Incunábulo: Golpe do Cruzado
8913	Incunábulo: Golpe Sagrado III
8914	Incunábulo: Golpe do Cruzado II
8915	Incunábulo: Golpe Sagrado IV
8916	Incunábulo: Punho da Justiça II
8917	Incunábulo: Impor as Mãos II
8918	Incunábulo: Selo da Proteção III
8919	Incunábulo: Golpe Sagrado V
8920	Incunábulo: Golpe do Cruzado III
8921	Incunábulo: Punho da Justiça III
8922	Incunábulo: Golpe Sagrado VI
8923	Essência da Agonia
8924	Poeira da Deterioração
8925	Ampola de Cristal
8926	Veneno Instantâneo IV
8927	Veneno Instantâneo V
8928	Veneno Instantâneo VI
8929	Incunábulo: Exorcismo IV
8930	Incunábulo: Selo da Retidão IV
8931	Incunábulo: Golpe do Cruzado IV
8932	Queijo Furado de Alterac
8933	Incunábulo: Luz Sagrada VII
8934	Incunábulo: Golpe Sagrado VII
8935	Incunábulo: Julgamento II
8936	Incunábulo: Selo da Ira III
8937	Incunábulo: Impor as Mãos III
8938	Incunábulo: Esconjurar Morto-vivo III
8939	Incunábulo: Exorcismo V
8940	Incunábulo: Punho da Justiça IV
8941	Incunábulo: Luz Sagrada VIII
8942	Incunábulo: Selo da Retidão V
8943	Incunábulo: Golpe Sagrado VIII
8944	Incunábulo: Golpe do Cruzado V
8945	Incunábulo: Julgamento III
8947	Incunábulo: Exorcismo VI
8948	Boleto-rei Seco
8949	Elixir de Agilidade
8950	Torta de Cereja Caseira
8951	Elixir de Defesa Maior
8952	Codorna Assada
8953	Plátanos Fritos
8954	Códice de Palavra Sagrada: Fortitude
8955	Códice de Desvanecer
8956	Óleo de Imolação
8957	Halibute Espinhapina
8958	Códice de Impacto da Mente
8959	Halibute Espinhapina Cru
8960	Códice de Curar Doença
8961	Códice de Grito Psíquico
8962	Códice de Impacto da Mente II
8963	Códice de Reconforto Mental
8964	Códice de Cura Célere
8965	Códice de Desvanecer II
8966	Códice de Agrilhoar Morto-vivo
8967	Códice de Impacto da Mente III
8968	Códice de Exaurir Mana
8969	Códice de Cura Célere II
8971	Códice de Grito Psíquico II
8972	Códice de Impacto da Mente IV
8973	Pelego Grosso de Yeti
8974	Códice de Controle Mental
8975	Códice de Desvanecer III
8976	Códice de Abolir Doença
8977	Códice de Exaurir Mana II
8978	Códice de Cura Célere III
8980	Códice de Impacto da Mente V
8981	Códice de Reconforto Mental II
8983	Códice de Cura Célere IV
8984	Veneno Mortal III
8985	Veneno Mortal IV
8986	Códice de Agrilhoar Morto-vivo II
8987	Códice de Proteção Sagrada II
8988	Códice de Exaurir Mana III
8989	Códice de Desvanecer IV
8990	Códice de Impacto da Mente VI
8991	Códice de Fogo Interior IV
8992	Códice de Grito Psíquico III
8993	Códice de Proteção Sombria II
8994	Códice de Palavra Sombria: Dor VI
8995	Códice de Palavra Sagrada: Escudo VII
8996	Códice de Ressurreição III
8997	Códice de Controle Mental II
8998	Códice de Visão da Mente II
8999	Códice de Cura Célere V
9000	Códice de Renovar VII
9001	Códice de Cura Maior II
9002	Códice de Impacto da Mente VII
9003	Códice de Punição Sagrada VII
9004	Códice de Palavra Sagrada: Fortitude V
9005	Códice de Exaurir Mana IV
9006	Códice de Palavra Sagrada: Escudo VIII
9007	Códice de Desvanecer V
9008	Códice de Prece de Cura III
9009	Códice de Fogo Interior V
9010	Códice de Cura Célere VI
9011	Códice de Palavra Sombria: Dor VII
9012	Códice de Renovar VIII
9013	Códice de Cura Maior III
9014	Códice de Reconforto Mental III
9015	Códice de Impacto da Mente VIII
9016	Códice de Punição Sagrada VIII
9017	Códice de Proteção Sagrada III
9018	Códice de Palavra Sagrada: Escudo IX
9019	Códice de Renovar IX
9020	Códice de Grito Psíquico IV
9021	Códice de Exaurir Mana V
9022	Códice de Cura Célere VII
9023	Códice de Proteção Sombria III
9024	Códice de Controle Mental III
9025	Códice de Cura Maior IV
9026	Códice de Ressurreição IV
9027	Códice de Impacto da Mente IX
9028	Códice de Palavra Sombria: Dor VIII
9029	Códice de Desvanecer VI
9030	Poção de Restauração
9031	Códice de Agrilhoar Morto-vivo III
9032	Códice de Prece de Cura IV
9033	Códice de Fogo Interior VI
9034	Códice de Palavra Sagrada: Fortitude VI
9035	Códice de Palavra Sagrada: Escudo X
9036	Poção de Resistência à Magia
9037	Tabuleta de Arma Trinca-pedra
9039	Tabuleta de Choque Terreno
9040	Tabuleta de Onda Curativa II
9041	Tabuleta de Totem de Prisão Terrena
9043	Tabuleta de Totem da Garra de Pedra
9044	Tabuleta de Choque Terreno II
9046	Tabuleta de Totem da Força da Terra
9047	Tabuleta de Choque Flamejante
9048	Tabuleta de Renascimento
9049	Tabuleta de Totem de Nova de Fogo
9050	Tabuleta de Onda Curativa III
9051	Tabuleta de Choque Terreno III
9052	Tabuleta de Totem Litopele II
9053	Tabuleta de Arma Trinca-pedra II
9054	Tabuleta de Choque Flamejante II
9055	Tabuleta de Totem da Garra de Pedra II
9056	Tabuleta de Onda Curativa IV
9057	Tabuleta de Arma de Marca Gélida
9058	Tabuleta de Choque Gélido
9059	Tabuleta de Arma com Labaredas
9060	Cilindro Marchetado de Mithril
9061	Combustível de Foguete Goblínico
9062	Tabuleta de Curar Doença
9063	Tabuleta de Totem Antiveneno
9064	Tabuleta de Arma com Labaredas II
9065	Tabuleta de Totem de Nova de Fogo II
9066	Tabuleta de Totem de Resistência ao Gelo
9067	Tabuleta de Totem Força da Terra II
9068	Tabuleta de Totem Litopele III
9069	Tabuleta de Choque Terreno IV
9070	Tabuleta de Onda Curativa V
9071	Tabuleta de Totem de Fonte de Mana
9072	Tabuleta de Totem de Labaredas
9073	Tabuleta de Arma de Fúria dos Ventos
9074	Tabuleta de Choque Flamejante III
9075	Tabuleta de Totem de Resistência ao Fogo
9076	Tabuleta de Totem de Magma
9077	Tabuleta de Totem da Garra de Pedra III
9078	Tabuleta de Totem de Aterramento
9079	Tabuleta de Choque de Raio
9080	Tabuleta de Totem de Resistência à Natureza
9081	Tabuleta de Totem de Torrente Curativa II
9082	Tabuleta de Arma Trinca-pedra III
9083	Tabuleta de Totem Calcinante III
9084	Tabuleta de Totem de Fúria dos Ventos
9085	Tabuleta de Totem de Nova de Fogo III
9086	Tabuleta de Onda Curativa VI
9087	Tabuleta de Expurgar II
9088	Dádiva de Arthas
9089	Tabuleta de Choque Gélido II
9090	Tabuleta de Arma de Marca Gélida II
9091	Tabuleta de Totem Litopele IV
9092	Tabuleta de Totem-sentinela
9093	Tabuleta de Totem de Fonte de Mana II
9094	Tabuleta de Arma com Labaredas III
9095	Tabuleta de Choque Terreno V
9096	Tabuleta de Totem Antidoença
9097	Tabuleta de Totem de Magma II
9098	Tabuleta de Totem Força da Terra III
9099	Tabuleta de Totem da Garra de Pedra IV
9100	Tabuleta de Escudo de Raios V
9101	Tabuleta de Arma de Fúria dos Ventos II
9102	Tabuleta de Cadeia de Raios II
9103	Tabuleta de Totem de Torrente Curativa III
9104	Tabuleta de Totem Calcinante IV
9105	Tabuleta de Onda Curativa VII
9123	Tabuleta de Raio VI
9124	Tabuleta de Choque de Raio II
9125	Tabuleta de Totem da Graça do Ar
9126	Tabuleta de Totem de Labaredas II
9127	Tabuleta de Totem de Resistência ao Fogo II
9128	Tabuleta de Totem de Nova de Fogo IV
9129	Tabuleta de Arma Trinca-pedra IV
9130	Tabuleta de Totem de Resistência à Natureza II
9131	Tabuleta de Totem Litopele V
9132	Tabuleta de Impacto Derretido VI
9133	Tabuleta de Cura Encadeada II
9134	Tabuleta de Totem de Fúria dos Ventos II
9135	Tabuleta de Choque Gélido III
9136	Tabuleta de Totem de Fonte de Mana III
9137	Tabuleta de Escudo de Raios VI
9138	Tabuleta de Totem de Magma III
9139	Tabuleta de Arma de Marca Gélida III
9140	Tabuleta de Cadeia de Raios III
9141	Tabuleta de Totem da Garra de Pedra V
9142	Tabuleta de Choque Terreno VI
9143	Tabuleta de Onda Curativa VIII
9144	Poção de Vinha Selvagem
9145	Tabuleta de Raio VII
9146	Tabuleta de Totem Calcinante V
9147	Tabuleta de Totem de Torrente Curativa IV
9148	Tabuleta de Arma com Labaredas IV
9149	Pedra Filosofal
9150	Tabuleta de Totem Força da Terra IV
9151	Tabuleta de Choque Flamejante V
9152	Tabuleta de Totem de Nova de Fogo V
9153	Projeto de Mecatraje
9154	Elixir de Detecção de Mortos-vivos
9155	Elixir Arcano
9156	Tabuleta de Impacto Derretido VII
9157	Tabuleta de Cura Encadeada III
9158	Tabuleta de Totem de Resistência ao Gelo III
9159	Tabuleta de Choque de Raio III
9160	Tabuleta de Arma de Fúria dos Ventos III
9161	Tabuleta de Totem Litopele VI
9162	Tabuleta de Escudo de Raios VII
9164	Tabuleta de Totem da Graça do Ar II
9165	Tabuleta de Totem de Labaredas III
9166	Tabuleta de Totem de Fonte de Mana IV
9167	Tabuleta de Cadeia de Raios IV
9168	Tabuleta de Onda Curativa IX
9169	Tabuleta de Raio VIII
9170	Tabuleta de Totem de Resistência ao Fogo III
9171	Tabuleta de Totem de Magma IV
9172	Poção de Invisibilidade
9173	Transponder Goblínico
9174	Tabuleta de Choque Gélido IV
9175	Tabuleta de Arma Trinca-pedra V
9176	Tabuleta de Totem da Garra de Pedra VI
9177	Tabuleta de Choque Terreno VII
9178	Tabuleta de Totem de Resistência à Natureza III
9179	Elixir de Intelecto Maior
9180	Tabuleta de Totem de Fúria dos Ventos III
9181	Tabuleta de Totem de Torrente Curativa V
9182	Tabuleta de Totem Calcinante VI
9183	Tabuleta de Cura Encadeada
9184	Tabuleta de Choque Flamejante IV
9185	Tabuleta de Totem de Resistência ao Gelo II
9186	Veneno Entorpecente III
9187	Elixir de Agilidade Maior
9188	Tabuleta de Totem Calcinante II
9189	Sino de Shay
9190	Grimório de Imolação
9191	Grimório de Maldição da Fraqueza
9192	Grimório de Corrupção
9193	Grimório de Conversão de Vida
9194	Grimório de Maldição da Agonia
9195	Grimório de Drenar Alma
9197	Elixir de Visão de Sonhos
9198	Grimório de Funil de Vida
9199	Grimório de Maldição da Temeridade
9200	Grimório de Maldição da Fraqueza II
9201	Grimório de Corrupção II
9202	Grimório de Conversão de Vida II
9203	Grimório de Ritual de Evocação
9204	Grimório de Funil de Vida II
9205	Grimório de Maldição da Agonia II
9206	Elixir de Gigantes
9207	Grimório de Criar Pedra-sangrenta II
9208	Grimório de Drenar Alma II
9209	Grimório de Maldição da Fraqueza III
9210	Pigmento Fantasma
9211	Grimório de Maldição da Temeridade II
9212	Grimório de Seta Sombria V
9214	Grimório de Inferno
9215	Grimório de Funil de Vida III
9216	Grimório de Corrupção III
9217	Grimório de Conversão de Vida III
9218	Grimório de Escravizar Demônio
9219	Grimório de Fogo do Inferno
9221	Grimório de Maldição da Agonia III
9222	Grimório de Maldição dos Elementos
9223	Grimório de Maldição da Fraqueza IV
9224	Elixir de Demonicídio
9225	Grimório de Seta Sombria VI
9226	Grimório de Funil de Vida IV
9227	Grimório de Drenar Alma III
9228	Grimório de Criar Pedra-sangrenta III
9229	Grimório de Drenar Vida IV
9230	Grimório de Maldição da Temeridade III
9231	Grimório de Corrupção IV
9233	Elixir de Detecção de Demônios
9234	Tiara das Profundezas
9235	Carta de Pradal
9236	Carta de Jangdor
9237	Juba de Gnoll Patábua
9238	Couraça de Escaravelho Fechada
9240	Marreta de Zul'Farrak
9241	Marreta Sagrada
9242	Tabuleta Ancestral
9243	Coração Murcho
9244	Carregamento do Esmirno
9245	Garrafa do Esmirno
9246	Cabeça de Barbarruiva
9247	Escama de Naga Cristafúria
9248	Relíquia Misteriosa
9249	Chave do Capitão
9250	Horário do Navio
9251	Fragmento Superior do Mapa
9252	Fragmento Inferior do Mapa
9253	Fragmento Intermediário do Mapa
9254	Mapa do Tesouro do Cuergo
9255	Essência Lahassa
9256	Essência Imbel
9257	Essência Samha
9258	Essência Byltan
9259	Colar Tribal Troll
9260	Rum Volátil
9261	Minério de Chumbo
9262	Vitríolo Preto
9263	Báculo de Troyas
9264	Elixir de Poder Sombrio
9265	Tesouro Escondido do Cuergo
9266	Plano de Batalha de Patábua
9275	Chave do Cuergo
9276	Maleta do Pirata
9277	Núcleo de Memória do Tecnobô
9278	Artifício Essencial
9279	Cartão Perfurado Branco
9280	Cartão Perfurado Amarelo
9281	Cartão Perfurado Vermelho
9282	Cartão Perfurado Azul
9283	Coletor de Chumbo Vazio
9284	Coletor de Chumbo Cheio
9285	Avambraços de Placa do Campo de Batalha
9286	Armadura de Placa do Campo de Batalha
9287	Manoplas de Placa do Campo de Batalha
9288	Cinturão de Placa do Campo de Batalha
9289	Botas de Placa do Campo de Batalha
9290	Capacete de Placa do Campo de Batalha
9291	Perneiras de Placa do Campo de Batalha
9292	Brafoneiras de Placa do Campo de Batalha
9293	Receita: Poção de Resistência à Magia
9294	Receita: Poção de Vinha Selvagem
9295	Receita: Poção de Invisibilidade
9296	Receita: Dádiva de Arthas
9297	Receita: Elixir de Visão de Sonhos
9298	Receita: Elixir de Gigantes
9299	Combinação do Cofre do Termaplugue
9300	Receita: Elixir de Demonicídio
9301	Receita: Elixir de Poder Sombrio
9302	Receita: Pigmento Fantasma
9303	Receita: Pedra Filosofal
9304	Receita: Transmutar Ferro em Ouro
9305	Receita: Transmutar Mithril em Veraprata
9306	Báculo de Equinex
9307	Uma Pedra Rutilante
9308	Objeto Encardido
9309	Tripas Mecanobóticas
9311	Papel de Carta Padrão
9312	Fogos de Artifício Azuis
9313	Fogos de Artifício Verdes
9314	Fogos de Artifício de Centelhas Vermelhas
9315	Fogos de Artifício da Rosa Amarela
9316	Cartão Perfurado Prismático
9317	Fogos de Artifício Vermelho, Branco e Azul
9318	Fogos de Artifício Vermelhos
9319	Pique de Nimboya Repleto
9320	Crânio de Cascasseca
9321	Garrafa de Peçonha
9322	Vesícula de Peçonha Intacta
9323	Pergaminho de Gadrin
9324	Peçonha de Shadra
9325	Um Báculo Pequeno
9326	Anel Encardido
9327	Cartão de Segurança de Acesso Delta
9328	Superinstantânea FX
9329	Um Bilhete
9330	Foto de Gammerita
9331	Feralas: Uma História
9332	Bandagens Sujas
9333	Colar de Prata Manchada
9334	Potes Quebrados
9335	Taco de Obsidiana Quebrado
9336	Presa de Ouro do Troll
9355	Brinco de Argola
9356	Uma Perna de Pau
9357	Esqueleto de Papagaio
9358	Um Turbante
9359	Lâmpada dos Mares do Sul
9360	Cuergo Ouro
9361	Cuergo Ouro com Verme
9362	Anel de Ouro Brilhante
9363	Caixa da Brastematic
9364	Coletor de Chumbo Pesado
9365	Resíduo Radioativo de Alta Potência
9366	Manoplas de Escama Dourada
9367	Instruções: Manoplas de Escama Dourada
9368	Anel-sinete de Jer'kai
9369	Asa Iridescente de Dardejante
9370	Pergaminho Gordunni
9371	Orbe Gordunni
9372	Sul'thraze, a Açoitadora
9375	Elmo do Exímio Garimpeiro
9378	Machado de Mineração do Pá-de-flange
9379	Sang'thraze, a Defletora
9380	Jang'thraze, a Protetora
9381	Bastão Terrano
9382	Botas do Minerador Pisoteante
9383	Cutelo Obsidiano
9384	Estoque da Abóbada de Pedra
9385	Defensor Arcaico
9386	Marca do Escavador
9387	Botas do Revelosh
9388	Guarda-braços do Revelosh
9389	Espaldares do Revelosh
9390	Luvas do Revelosh
9391	O Padejador
9392	Lâmina Temperada
9393	Raio de Esperança
9394	Capacete Viking com Chifres
9395	Luvas dos Antigos
9396	Guarda-pernas da Abóbada
9397	Manto de Energia
9398	Botas de Corrida Gastas
9399	Flecha de Precisão
9400	Arco Curto de Baelog
9401	Cimitarra Nórdica
9402	Kilt Terreno
9403	Escudo Viking Surrado
9404	Escudo Versátil do Olaf
9405	Cinturão da Força do Golem
9406	Grilhão Pinavento
9407	Perneiras Tecepedra
9408	Porrete com Ferros
9409	Braçadeiras da Ferronaya
9410	Punhaços
9411	Brafoneiras Lascarrocha
9412	Pregafogo do Galgann
9413	O Socapedra
9414	Perneiras de Oleado
9415	Vestimenta Tribal do Grimlok
9416	Ímpeto de Grimlok
9417	Estilhaço Arcádico
9418	Matapedra
9419	Martelo de Fogo do Galgann
9420	Capacete do Vigor do Aventureiro
9421	Pedra de Vida Elevada
9422	Mateiro de Umbraforja
9423	A Britadeira
9424	Espada Ginn-Su
9425	Pêndulo da Perdição
9426	Arco Monolítico
9427	Quebraossos da Abóbada de Pedra
9428	Embraces Desenterrados
9429	Capacete de Minerador das Profundezas
9430	Espaldares da Era Perdida
9431	Tarbuche Papal
9432	Braçadeiras de Placa Craniana
9433	Bandagens Esquecidas
9434	Traje do Elemental
9435	Manoplas de Osso Reticulado
9436	Embrulho do Faranello
9437	Amostra Não Testada de Basilisco
9438	Amostra Aceitável de Escorpídeo
9439	Amostra Não Testada de Hiena
9440	Amostra Aceitável de Basilisco
9441	Amostra Aceitável de Hiena
9442	Amostra Não Testada de Escorpídeo
9443	Amostra Usada de Monstro
9444	Casco da Cpu do Tecnobô
9445	Patas de Grúdio
9446	Perna do Eletrocutor
9447	Porca do Eletrocutor
9448	Trapo Oleoso do Aracnotanque
9449	Espanca-gente Manual
9450	Botas de Operação do Gnomobô
9451	Água Borbulhante
9452	Hidrobengala
9453	Vingador Tóxico
9454	Chancas Ácidas
9455	Manilhas do Emissário
9456	Carabina de Vidro
9457	Cetro Diplomático Real
9458	Núcleo Central de Termaplugue
9459	Braço Esquerdo do Termaplugue
9460	Chifre de Temível Totem
9461	Engrenagem Carregada
9462	Caixa de Chifres Temível Totem
9463	Cobalto Gordunni
9465	Mestrescavadora 5000
9466	Pá de Orwin
9467	Presa de Gahz'rilla
9468	Pena de Bicoafiado
9469	Armadura de Escama de Gahz'rilla
9470	Máscara do Mojo Ruim
9471	Medalhão de Nekrum
9472	Chave de Bagata
9473	Peitoral Azarado
9474	Kilt Azarado
9475	Laminador Diabólico
9476	Brafoneiras Sinistronas
9477	A Garantia do Chefe
9478	Serrote
9479	Abraço de Lycan
9480	Rancazoio
9481	Minotauro
9482	Bengala do Mandingueiro
9483	Incinerador Flamejante
9484	Perneiras do Choque Místico
9485	Vibrolâmina
9486	Machado de Guerra Superataque
9487	Superarma Hi-Tech
9488	Martelo do Poder Oscilante
9489	Fazedor de Gelo Giromático
9490	Megafaca Trecotrônica
9491	Luvas do Piloto Gostosão
9492	Reativador do Gigafluxo Eletromagnético
9507	Caixote Cuidadosamente Embalado
9508	Macacão do Criador de Robôs
9509	Perneiras com Gasolina
9510	Botinas Furnafunda
9511	Escalpelo do Dessangrador
9512	Capa de Metal Preto
9513	Cajado Meridiano
9514	Cajado Arcano
9515	Túnica do Laço Etéreo
9516	Bata do Nó Astral
9517	Báculo Celestial
9518	Esmagadores de Lama
9519	Pisoteadores Pé-sujo
9520	Caçador Silencioso
9521	Rachacrânio
9522	Círculo de Pedra Energizado
9523	Têmpera de Troll
9527	Bastão Converte-feitiço
9528	Coração Sombrio de Edana
9529	Kit de Equipamento para Guerreiro Interno L25
9530	Chifre de Iragarra
9531	Brafoneiras de Xisto-gema
9532	Kit de Equipamento para Guerreiro Interno L30
9533	Anel da Confraria Maçom
9534	Bacinete da Guilda do Engenheiro
9535	Braçadeiras Soldadas
9536	Dragonas Asa-de-fada
9537	Caixa Bem Embrulhada
9538	Anel de Ouro do Didiê
9539	Caixa de Rações
9540	Caixa de Feitiços
9541	Caixa de Gostosuras
9542	Carta Simples
9543	Runa Simples
9544	Memorando Simples
9545	Selo Simples
9546	Pergaminho Simples
9547	Bilhete
9548	Carta Santificada
9550	Runa Cifrada
9551	Selo Cifrado
9552	Bilhete Inscrito em Runas
9553	Pergaminho Cinzelado
9554	Tabuleta Cifrada
9555	Carta Cifrada
9556	Runa Santificada
9557	Selo Sagrado
9558	Memorando Cifrado
9559	Pergaminho Cifrado
9560	Pergaminho Cifrado
9561	Tabuleta Consagrada
9562	Tabuleta Inscrita em Runas
9563	Runa Consagrada
9564	Tabuleta Cinzelada
9565	Bilhete Cinzelado
9566	Runa Cinzelada
9567	Selo Cinzelado
9568	Pergaminho Inscrito em Runas
9569	Pergaminho Consagrado
9570	Carta Consagrada
9571	Carta Glífica
9572	<UNUSED> Glyphic Rune
9573	Memorando Glífico
9574	Pergaminho Glífico
9575	Tabuleta Glífica
9576	Carta Conspurcada
9577	Memorando Maculado
9578	Pergaminho Conspurcado
9579	Pergaminho Conspurcado
9580	Selo Verdejante
9581	Bilhete Verdejante
9587	Saco de Degelocouro
9588	Anel de Ouro do Nogg
9589	Minerais Incrustados
9590	Pedaço de Lenha
9591	Tendão Resiliente
9592	Fragmentos Metálicos
9593	Muisec de Arvoroso
9594	Muisec de Coruscante
9595	Muisec de Hipogrifo
9596	Muisec de Dragoleta
9597	Muisec de Gigante da Montanha
9598	Vestes de Dormir
9599	Perneiras de Malha de Tronco
9600	Calças Galonadas
9601	Botas Almofadadas
9602	Lâmina Matagal
9603	Cajado Pardo
9604	Martelo do Mecânico
9605	Capa do Mecânico
9606	Recipiente de Muisec de Arvoroso
9607	Bastião de Ventobravo
9608	Ferramenta de Desarme da Shoni
9609	Luvas Bechil
9618	Recipiente de Muisec de Coruscante
9619	Recipiente de Muisec de Hipogrifo
9620	Recipiente de Muisec de Dragoleta
9621	Recipiente de Muisec de Gigante da Montanha
9622	Anel de Nó de Bambu
9623	Vestes de Civínada
9624	Culotes Corretrecho
9625	Perneiras Duplas Reforçadas
9626	Carga Enânica
9627	Estrela Guia da Liga dos Exploradores
9628	Bolsa de Herborismo de Neeru
9629	Cabeça Encolhida
9630	Botas Artesanais de Pradal
9631	Luvas Artesanais de Pradal
9632	Luvas Artesanais de Jangdor
9633	Botas Artesanais de Jangdor
9634	Luvas do Manejo Hábil
9635	Capa do Mestre Boticário
9636	Faixa do Valentão
9637	Botas Chuta-canela
9638	Manilhas Quelonianas
9639	A Mão de Antu'sul
9640	Manoplas Imorais
9641	Amuleto de Sangue Vital
9642	Elo da Grande Tartaruga
9643	Defletor Optomático
9644	Temporizador de Ovo Termostático
9645	Botas do Inventor Gnômico
9646	Dispositivo Gnômico de Afundamento
9647	Experimento Voador Fracassado
9648	Toalha de Cota de Malha
9649	Vestimenta da Altivez Real
9650	Peito d'Armas da Guarda Honorária
9651	Martelo da Tempestade do Cavalga-grifo
9652	Perneiras do Cavalga-grifo
9653	Óculos do Corredor Veloz
9654	Lasca de Pedra do Memorial
9655	Anel Época de Semear
9656	Manoplas de Granito
9657	Cilha Sebevideira
9658	Botas do Maharishi
9660	Manto do Contemplador das Estrelas
9661	Broquel Fechaterra
9662	Botas Serrapressa
9663	Peito d'Armas do Cavaleiro da Aurora
9664	Protetor da Sentinela
9665	Luvas Brasão Asa
9666	Cinturão Chifreforte
9678	Esmagador de Murloc de Tok'kar
9679	Cortador de Murloc do Tok'kar
9680	Perfurador de Murloc de Tok'kar
9681	Patas Grelhadas de Caranguejo-rei
9682	Cinto de Couro do Chef
9683	Força do Arvoroso
9684	Força do Hipogrifo
9685	Vontade do Gigante da Montanha
9686	Espírito de Dragoleta
9687	Cinto do Laçador
9698	Luvas da Perspicácia
9699	Manto da Guarnição
9703	Capa Calcinada
9704	Luvas do Larápio
9705	Cadarço de Tharg
9706	Disco de Tharg
9718	Lâmina dos Heróis Reforjada
9719	Lâmina dos Heróis Quebrada
9738	Gema de Cobrahn
9739	Gema de Sucurina
9740	Gema de Pítias
9741	Gema de Serpentis
9742	Cordão Simples
9743	Sapatos Simples
9744	Embraces Simples
9745	Capa Simples
9746	Luvas Simples
9747	Culotes Simples
9748	Veste Simples
9749	Blusa Simples
9750	Faixa Zíngara
9751	Sandálias Zíngaras
9752	Embraces Zíngaros
9753	Broquel Zíngaro
9754	Manto Zíngaro
9755	Luvas Zíngaras
9756	Calças Zíngaras
9757	Túnica Zíngara
9758	Cinto de Cadete
9759	Botas de Cadete
9760	Braçadeiras de Cadete
9761	Manto de Cadete
9762	Manoplas de Cadete
9763	Perneiras de Cadete
9764	Escudo de Cadete
9765	Colete de Cadete
9766	Faixa Teciverde
9767	Sandálias Teciverde
9768	Braçadeiras Teciverde
9769	Galho Teciverde
9770	Manto Teciverde
9771	Luvas Teciverde
9772	Perneiras Teciverde
9773	Veste Teciverde
9774	Colete Teciverde
9775	Cilha do Bandido
9776	Botas do Bandido
9777	Braçadeiras do Bandido
9778	Broquel do Bandido
9779	Manto do Bandido
9780	Luvas do Bandido
9781	Calças do Bandido
9782	Gibão do Bandido
9783	Peito d'Armas do Saqueador
9784	Botas do Saqueador
9785	Braçadeiras do Saqueador
9786	Manto do Saqueador
9787	Manoplas do Saqueador
9788	Cinto do Saqueador
9789	Guarda-pernas do Saqueador
9790	Escudo do Saqueador
9791	Túnica de Pano-de-hera
9792	Botas de Pano-de-hera
9793	Braceletes de Pano-de-hera
9794	Manto de Pano-de-hera
9795	Luvas de Pano-de-hera
9796	Dragonas de Pano-de-hera
9797	Calças de Pano-de-hera
9798	Veste de Pano-de-hera
9799	Faixa de Pano-de-hera
9800	Orbe Hera
9801	Cinto Superior
9802	Botas Superiores
9803	Braçadeiras Superiores
9804	Broquel Superior
9805	Manto Superior
9806	Luvas Superiores
9807	Omoplatas Superiores
9808	Perneiras Superiores
9809	Túnica Superior
9810	Botas Reforçadas
9811	Braçadeiras Reforçadas
9812	Manto Reforçado
9813	Manoplas Reforçadas
9814	Cinto Reforçado
9815	Perneiras Reforçadas
9816	Escudo Reforçado
9817	Espaldares Reforçados
9818	Corrente Reforçada
9819	Túnica Durável
9820	Botas Duráveis
9821	Braçadeiras Duráveis
9822	Capa Durável
9823	Luvas Duráveis
9824	Omoplatas Duráveis
9825	Calças Duráveis
9826	Veste Durável
9827	Cinto em Escamas de Couro
9828	Botas em Escamas de Couro
9829	Braçadeiras em Escamas de Couro
9830	Escudo em Escamas
9831	Manto em Escamas
9832	Luvas em Escamas de Couro
9833	Perneiras em Escamas de Couro
9834	Omoplatas em Escamas de Couro
9835	Túnica em Escamas de Couro
9836	Armadura Atada
9837	Braçadeiras Atadas
9838	Manto Atado
9839	Manoplas Atadas
9840	Cinturão Atado
9841	Perneiras Atadas
9842	Brafoneiras Atadas
9843	Escudo Atado
9844	Colete do Conjurador
9845	Sapatos do Conjurador
9846	Braçadeiras do Conjurador
9847	Manto do Conjurador
9848	Luvas do Conjurador
9849	Capuz do Conjurador
9850	Dragonas do Conjurador
9851	Calções do Conjurador
9852	Veste do Conjurador
9853	Cilha do Conjurador
9854	Gibão do Arqueiro
9855	Cinto do Arqueiro
9856	Botas do Arqueiro
9857	Braçadeiras do Arqueiro
9858	Broquel do Arqueiro
9859	Casquete do Arqueiro
9860	Manto do Arqueiro
9861	Luvas do Arqueiro
9862	Calças do Arqueiro
9863	Ombreiras do Arqueiro
9864	Botas do Renegado
9865	Braçadeiras do Renegado
9866	Couraça do Renegado
9867	Manto do Renegado
9868	Manoplas do Renegado
9869	Cinto do Renegado
9870	Diadema do Renegado
9871	Perneiras do Renegado
9872	Brafoneiras do Renegado
9873	Escudo do Renegado
9874	Clâmide Feiticeira
9875	Faixa Feiticeira
9876	Sapatilhas Feiticeiras
9877	Manto Feiticeiro
9878	Chapéu Feiticeiro
9879	Braceletes Feiticeiros
9880	Luvas Feiticeiras
9881	Dragonas Feiticeiras
9882	Esfera Feiticeira
9883	Calças Feiticeiras
9884	Veste Feiticeira
9885	Botas do Guarda-caça
9886	Embraces do Guarda-caça
9887	Armadura do Guarda-caça
9889	Casquete do Guarda-caça
9890	Capa do Guarda-caça
9891	Cinto do Guarda-caça
9892	Luvas do Guarda-caça
9893	Perneiras do Guarda-caça
9894	Omoplatas do Guarda-caça
9895	Botas Brigandinas
9896	Braçadeiras Brigandinas
9897	Couraça Brigandina
9898	Manto Brigandino
9899	Escudo Brigandino
9900	Manoplas Brigandinas
9901	Cinto Brigandino
9902	Elmo Brigandino
9903	Perneiras Brigandinas
9904	Brafoneiras Brigandinas
9905	Blusa Real
9906	Faixa Real
9907	Botas Reais
9908	Capa Real
9909	Embraces Reais
9910	Luvas Reais
9911	Calças Reais
9912	Sobreveste Real
9913	Toga Real
9914	Cetro Real
9915	Bandana Real
9916	Cinto do Rastreador
9917	Botas do Rastreador
9918	Defensor da Brigada
9919	Manto do Rastreador
9920	Luvas do Rastreador
9921	Bandana do Rastreador
9922	Perneiras do Rastreador
9923	Ombreiras do Rastreador
9924	Túnica do Rastreador
9925	Munhequeiras do Rastreador
9926	Botas da Brigada
9927	Braçadeiras da Brigada
9928	Peitoral da Brigada
9929	Manto da Brigada
9930	Manoplas da Brigada
9931	Cinturão da Brigada
9932	Diadema da Brigada
9933	Perneiras da Brigada
9934	Brafoneiras da Brigada
9935	Escudo de Placa em Alto Relevo
9936	Botas do Abjurador
9937	Embraces do Abjurador
9938	Manto do Abjurador
9939	Luvas do Abjurador
9940	Capuz do Abjurador
9941	Dragonas do Abjurador
9942	Calças do Abjurador
9943	Veste do Abjurador
9944	Cristal do Abjurador
9945	Faixa do Abjurador
9946	Túnica do Abjurador
9947	Cinto do Chefe Tribal
9948	Botas do Chefe Tribal
9949	Braçadeiras do Chefe Tribal
9950	Peitoral do Chefe Tribal
9951	Manto do Chefe Tribal
9952	Luvas do Chefe Tribal
9953	Cocar do Chefe Tribal
9954	Perneiras do Chefe Tribal
9955	Omoplatas do Chefe Tribal
9956	Braçadeiras do Fomentador de Guerra
9957	Peito d'Armas do Fomentador de Guerra
9958	Broquel do Fomentador de Guerra
9959	Manto do Fomentador de Guerra
9960	Manoplas do Fomentador de Guerra
9961	Cinto do Fomentador de Guerra
9962	Grevas do Fomentador de Guerra
9963	Diadema do Fomentador de Guerra
9964	Perneiras do Fomentador de Guerra
9965	Brafoneiras do Fomentador de Guerra
9966	Armadura de Placa em Alto Relevo
9967	Manoplas de Placa em Alto Relevo
9968	Cinturão de Placa em Alto Relevo
9969	Capacete de Placa em Alto Relevo
9970	Perneiras de Placa em Alto Relevo
9971	Brafoneiras de Placa em Alto Relevo
9972	Braçadeiras de Placa em Alto Relevo
9973	Botas de Placa em Alto Relevo
9974	Escudo do Lorde Supremo
9978	Detector de Gahz'ridian
9998	Colete de Magitrama Preta
9999	Perneiras de Magitrama Preta
10000	Chifre de Margol
10001	Veste de Magitrama Preta
10002	Calças de Umbratrama
10003	Luvas de Magitrama Pretas
10004	Veste de Umbratrama
10005	Chifre Gigante de Margol
10007	Colete de Magitrama Vermelho
10008	Máscara Branca do Bandido
10009	Calças de Magitrama Vermelhas
10010	Calças de Tempestrama
10011	Luvas de Tempestrama
10018	Luvas de Magitrama Vermelhas
10019	Luvas de Oniritrama
10020	Colete de Tempestrama
10021	Colete de Oniritrama
10022	Certificado de Realização
10023	Luvas de Umbratrama
10024	Bandana de Magitrama Preta
10025	Máscara de Umbratrama
10026	Botas de Magitrama Preta
10027	Omoplatas de Magitrama Pretas
10028	Omoplatas de Umbratrama
10029	Omoplatas de Magitrama Vermelhas
10030	Chapéu do Almirante
10031	Botas de Umbratrama
10032	Bandana de Tempestrama
10033	Bandana de Magitrama Vermelha
10034	Camisa de Smoking
10035	Calças de Smoking
10036	Paletó de Smoking
10038	Omoplatas de Tempestrama
10039	Botas de Tempestrama
10040	Vestido de Noiva Branco
10041	Diadema de Oniritrama
10042	Veste de Brasatrama
10043	Culotes Pios
10044	Botas de Brasatrama
10045	Calças Simples de Linho
10046	Botas Simples de Linho
10047	Kilt Simples
10048	Kilt Colorido
10049	Lâmina do Diabolista
10050	Bolsa de Magitrama
10051	Bolsa de Magitrama Vermelha
10052	Camisa Marcial Laranja
10053	Vestido Preto Simples
10054	Camisa de Magitrama Lavanda
10055	Camisa de Magitrama Rosa
10056	Camisa de Magitrama Laranja
10057	Túnica do Anoitecer
10058	Sandálias do Anoitecer
10059	Braçadeiras do Anoitecer
10060	Capa do Anoitecer
10061	Turbante do Anoitecer
10062	Luvas do Anoitecer
10063	Sobreveste do Anoitecer
10064	Calças do Anoitecer
10065	Veste do Anoitecer
10066	Faixa do Anoitecer
10067	Cinta Íntegra
10068	Botas Íntegras
10069	Braçadeiras Íntegras
10070	Armadura Íntegra
10071	Manto Íntegro
10072	Luvas Íntegras
10073	Capacete Íntegro
10074	Perneiras Íntegras
10075	Espaldares Íntegros
10076	Guarda-braços do Lorde
10077	Peitoral do Lorde
10078	Timbre do Lorde
10079	Capa do Lorde
10080	Manoplas do Lorde
10081	Cinturão do Lorde
10082	Botas do Lorde
10083	Coroa do Lorde
10084	Guarda-pernas do Lorde
10085	Brafoneiras do Lorde
10086	Armadura Gótica de Placa
10087	Manoplas Góticas de Placa
10088	Cinturão Gótico de Placa
10089	Escarpes Góticos
10090	Capacete Gótico de Placa
10091	Perneiras Góticas de Placa
10092	Espaldares Góticos de Placa
10093	Defletor do Elemental Vingativo
10094	Avambraços Góticos de Placa
10095	Botas do Conselheiro
10096	Manilhas do Conselheiro
10097	Diadema do Conselheiro
10098	Manto do Conselheiro
10099	Luvas do Conselheiro
10100	Omoplatas do Conselheiro
10101	Calças do Conselheiro
10102	Vestes do Conselheiro
10103	Faixa do Conselheiro
10104	Túnica do Conselheiro
10105	Armadura do Errante
10106	Botas do Errante
10107	Braçadeiras do Errante
10108	Manto do Errante
10109	Cinto do Errante
10110	Luvas do Errante
10111	Chapéu do Errante
10112	Perneiras do Errante
10113	Omoplatas do Errante
10118	Peitoral Ornado
10119	Grevas Ornadas
10120	Manto Ornado
10121	Manoplas Ornadas
10122	Cinturão Ornado
10123	Diadema Ornado
10124	Guarda-pernas Ornados
10125	Brafoneiras Ornadas
10126	Braçadeiras Ornadas
10127	Braçadeiras do Elemental Vingativo
10128	Guarda-peito do Elemental Vingativo
10129	Manoplas do Elemental Vingativo
10130	Cinturão do Elemental Vingativo
10131	Botas do Elemental Vingativo
10132	Capacete do Elemental Vingativo
10133	Perneiras do Elemental Vingativo
10134	Omoplatas do Elemental Vingativo
10135	Túnica do Alto-conselheiro
10136	Braçadeiras do Alto-conselheiro
10137	Botas do Alto-conselheiro
10138	Manto do Alto-conselheiro
10139	Diadema do Alto-conselheiro
10140	Luvas do Alto-conselheiro
10141	Calças do Alto-conselheiro
10142	Dragonas do Alto-conselheiro
10143	Veste do Alto-conselheiro
10144	Faixa do Alto-conselheiro
10145	Cinturão Poderoso
10146	Botas Poderosas
10147	Pulseiras Poderosas
10148	Manto Poderoso
10149	Manoplas Poderosas
10150	Capacete Poderoso
10151	Túnica Poderosa
10152	Perneiras Poderosas
10153	Espaldares Poderosos
10154	Cinturão Mercurial
10155	Grevas Mercuriais
10156	Braçadeiras Mercuriais
10157	Peitoral Mercurial
10158	Guarda Mercurial
10159	Manto Mercurial
10160	Diadema Mercurial
10161	Manoplas Mercuriais
10162	Guarda-pernas Mercuriais
10163	Brafoneiras Mercuriais
10164	Guarda-peito Templário
10165	Manoplas Templárias
10166	Cinturão Templário
10167	Botas Templárias
10168	Coroa Templária
10169	Coxotes Templários
10170	Brafoneiras Templárias
10171	Braçadeiras Templárias
10172	Dragonas Místicas
10173	Braçadeiras Místicas
10174	Capa Mística
10175	Turbante Místico
10176	Luvas Místicas
10177	Perneiras Místicas
10178	Veste Mística
10179	Botas Místicas
10180	Cinto Místico
10181	Armadura Mística
10182	Peitoral do Espadachim
10183	Botas do Espadachim
10184	Braçadeiras do Espadachim
10185	Capa do Espadachim
10186	Luvas do Espadachim
10187	Tapa-olho do Espadachim
10188	Perneiras do Espadachim
10189	Ombreiras do Espadachim
10190	Cinto do Espadachim
10191	Guarda-braços do Cruzado
10192	Botas do Cruzado
10193	Armadura do Cruzado
10194	Manto do Cruzado
10195	Escudo do Cruzado
10196	Manoplas do Cruzado
10197	Cinto do Cruzado
10198	Elmo do Cruzado
10199	Perneiras do Cruzado
10200	Brafoneiras do Cruzado
10201	Grevas do Lorde Supremo
10202	Avambraços do Lorde Supremo
10203	Guarda-peito do Lorde Supremo
10204	Escudo Lamelar Pesado
10205	Manoplas do Lorde Supremo
10206	Cinturão do Lorde Supremo
10207	Coroa do Lorde Supremo
10208	Coxotes do Lorde Supremo
10209	Espaldares do Lorde Supremo
10210	Dragonas Elegantes
10211	Botas Elegantes
10212	Manto Elegante
10213	Braçadeiras Elegantes
10214	Luvas Elegantes
10215	Vestes Elegantes
10216	Cinto Elegante
10217	Perneiras Elegantes
10218	Túnica Elegante
10219	Diadema Elegante
10220	Túnica de Erva-moura
10221	Cinturão de Erva-moura
10222	Botas de Erva-moura
10223	Guarda-braços de Erva-moura
10224	Manto de Erva-moura
10225	Luvas de Erva-moura
10226	Capacete de Erva-moura
10227	Perneiras de Erva-moura
10228	Espaldares de Erva-moura
10229	Braçadeiras Gravadas
10230	Peitoral Gravado
10231	Capa Gravada
10232	Manoplas Gravadas
10233	Cinturão Gravado
10234	Botas Gravadas
10235	Elmo Gravado
10236	Perneiras Gravadas
10237	Brafoneiras Gravadas
10238	Botas Lamelares Pesadas
10239	Avambraços Lamelares Pesados
10240	Peito d'Armas Lamelar Pesado
10241	Elmo Lamelar Pesado
10242	Manoplas Lamelares Pesadas
10243	Cinturão Lamelar Pesado
10244	Perneiras Lamelares Pesadas
10245	Brafoneiras Lamelares Pesadas
10246	Colete do Mestre
10247	Botas do Mestre
10248	Braçadeiras do Mestre
10249	Manto do Mestre
10250	Chapéu do Mestre
10251	Luvas do Mestre
10252	Perneiras do Mestre
10253	Dragonas do Mestre
10254	Veste do Mestre
10255	Cinto do Mestre
10256	Braçadeiras do Aventureiro
10257	Botas do Aventureiro
10258	Capa do Aventureiro
10259	Cinto do Aventureiro
10260	Luvas do Aventureiro
10261	Bandana do Aventureiro
10262	Guarda-pernas do Aventureiro
10263	Omoplatas do Aventureiro
10264	Túnica do Aventureiro
10265	Braçadeiras Magistrais
10266	Peitoral Magistral
10267	Capa Magistral
10268	Manoplas Magistrais
10269	Cinturão Magistral
10270	Botas Magistrais
10271	Escudo Magistral
10272	Diadema Magistral
10273	Coxotes Magistrais
10274	Brafoneiras Magistrais
10275	Peitoral Esmeralda
10276	Escarpes Esmeralda
10277	Manoplas Esmeralda
10278	Cinturão Esmeralda
10279	Elmo Esmeralda
10280	Coxotes Esmeralda
10281	Brafoneiras Esmeralda
10282	Avambraços Esmeralda
10283	Amostras de Coração de Lobo
10285	Seda Sombria
10286	Coração das Selvas
10287	Dragonas de Teciverde
10288	Diadema do Sábio
10289	Chapéu Durável
10290	Pigmento Cor-de-rosa
10298	Elo de Gnomeregan
10299	Amuleto de Gnomeregan
10300	Molde: Colete de Magitrama Vermelho
10301	Molde: Máscara Branca do Bandido
10302	Molde: Calças de Magitrama Vermelhas
10303	Molde: Calças de Tempestrama
10304	Molde: Luvas de Tempestrama
10305	Pergaminho de Proteção IV
10306	Pergaminho do Espírito IV
10307	Pergaminho do Vigor IV
10308	Pergaminho do Intelecto IV
10309	Pergaminho de Agilidade IV
10310	Pergaminho de Força IV
10311	Molde: Camisa Marcial Laranja
10312	Molde: Luvas de Magitrama Vermelhas
10313	Molde: Colete de Tempestrama
10314	Molde: Camisa de Magitrama Lavanda
10315	Molde: Omoplatas de Magitrama Vermelhas
10316	Molde: Kilt Colorido
10317	Molde: Camisa de Magitrama Rosa
10318	Molde: Chapéu do Almirante
10319	Molde: Bandana de Tempestrama
10320	Molde: Bandana de Magitrama Vermelha
10321	Molde: Camisa de Smoking
10322	Molde: Omoplatas de Tempestrama
10323	Molde: Calças de Smoking
10324	Molde: Botas de Tempestrama
10325	Molde: Vestido de Noiva Branco
10326	Molde: Paletó de Smoking
10327	Berrante de Echeyaki
10328	Peito d'Armas Escarlate
10329	Cinto Escarlate
10330	Perneiras Escarlate
10331	Manoplas Escarlate
10332	Botas Escarlate
10333	Munhequeiras Escarlate
10338	Carcaça Fresca de Zevra
10358	Braçadeiras de Duracin
10359	Botas Sempiternas
10360	Cobra-rei Preta
10361	Cobra Marrom
10362	Escudo Ornado
10363	Parede Gravada
10364	Escudo Templário
10365	Escudo Esmeralda
10366	Guarda Demoníaca
10367	Escudo Hyperion
10368	Armadura de Placa Imbuída
10369	Manoplas de Placa Imbuídas
10370	Cinturão de Placa Imbuído
10371	Grevas de Placa Imbuídas
10372	Capacete de Placa Imbuído
10373	Perneiras de Placa Imbuídas
10374	Brafoneiras de Placa Imbuídas
10375	Avambraços de Placa Imbuídos
10376	Botas do Comandante
10377	Avambraços do Comandante
10378	Armadura do Comandante
10379	Elmo do Comandante
10380	Manoplas do Comandante
10381	Cinturão do Comandante
10382	Perneiras do Comandante
10383	Brafoneiras do Comandante
10384	Armadura Hyperion
10385	Grevas Hyperion
10386	Manoplas Hyperion
10387	Cinturão Hyperion
10388	Elmo Hyperion
10389	Coxotes Hyperion
10390	Brafoneiras Hyperion
10391	Avambraços Hyperion
10392	Cobra Carmesim
10393	Barata
10394	Apito de Cão-da-pradaria
10398	Frango Mecânico
10399	Armadura Enegrecida dos Défias
10400	Perneiras Enegrecidas dos Défias
10401	Luvas Enegrecidas dos Défias
10402	Botas Enegrecidas dos Défias
10403	Cinto Enegrecido dos Défias
10404	Cinto Durável
10405	Omoplatas do Bandido
10406	Bandana em Escamas de Couro
10407	Ombreiras do Saqueador
10408	Elmo Atado
10409	Botas Atadas
10410	Perneiras da Presa
10411	Pisantes da Presa
10412	Cinto da Presa
10413	Luvas da Presa
10414	Amostra de Casco de Mordelisca
10418	Insígnia de Mithril Rutilante
10420	Crânio do Frigífero
10421	Colete de Cobre Grosseiro
10423	Perneiras de Bronze Prateado
10424	Instruções: Perneiras de Bronze Prateado
10438	Caixa do Félix
10439	Rabo-de-galo Escaldante de Durnan
10440	Caneca de Nóri
10441	Estilhaço Chamejante
10442	Artefato Misterioso
10443	Carta Chamuscada
10444	Pistola Sinalizadora Modelo Padrão
10445	Kit de Desenho
10446	Coração de Obsidião
10447	Cabeça de Latórico, o Negro
10450	Pena Intacta de Hipogrifo
10454	Essência de Erânicos
10455	Essência Acorrentada de Erânicos
10456	Algibeira Cheia de Moedas
10457	Concha Vazia de Caracol do Mar
10458	Oração a Eluna
10459	Cabeça do Chefe Presadura Mantospinho
10460	Sangue Hakkari
10461	Braceleiras Sombrias
10462	Cinto Sombrio
10463	Molde: Máscara de Umbratrama
10464	Cajado de Comando
10465	Ovo de Hakkar
10466	Círculo de Pedra Atal'ai
10467	Algibeira do Comerciante
10478	Gema de Mana do Jak
10479	Bolsa de Comércio de Kovic
10498	Micro-ajustador Giromático
10499	Óculos Brilho-do-olhar
10500	Óculos Ígneos
10501	Ultra-óculos Olho-de-gato
10502	Óculos de Poder Mágico Xtremo
10503	Óculos Cor-de-rosa
10504	Lente Verde
10505	Pó Explosivo Maciço
10506	Capacete das Profundezas
10507	Dinamite Maciça
10508	Bacamarte de Mithril
10509	Coração das Chamas
10510	Rifle de Mithril de Grosso Calibre
10511	Óleo de Golem
10512	Projéteis Mithrílicos de Alto Impacto
10513	Cartuchos Giroscópicos de Mithril
10514	Bomba de Fragmentação de Mithril
10515	Tocha da Retribuição
10518	Manto Paraquedas
10538	Tabuleta de Beth'Amara
10539	Tabuleta de Jin'yael
10540	Tabuleta de Markri
10541	Tabuleta de Sael'hai
10542	Capacete de Mineração Goblínico
10543	Capacete de Operário Goblínico
10544	Malho de Pau-cardo
10545	Óculos Gnômicos
10546	Mira Letal
10547	Faca Campeira
10548	Mira de Francoatirador
10549	Calças do Rancheiro
10550	Mitenes de Lã
10551	Punhal de Placas de Tório
10552	Símbolo de Ragnaros
10553	Colete do Encarregado
10554	Calças do Encarregado
10556	Círculo de Pedra
10558	Núcleo de Força de Ouro
10559	Tubo de Mithril
10560	Gatilho Instável
10561	Carcaça de Mithril
10562	Bomba de Alto-explosivo
10563	Decalque: Runa de Beth'Amara
10564	Decalque: Runa de Jin'yael
10565	Decalque: Runa de Markri
10566	Decalque: Runa de Sael'hai
10567	Lança-espinho
10569	Tesouro da Revoada Negra
10570	Homicida
10571	Clavosso de Ébano
10572	Estilha Congelante
10573	Açoita-osso
10574	Mortalha Cadavérica
10575	Muda de Pele da Revoada Negra
10576	Dragonete Mecânico de Mithril
10577	Morteiro Goblínico
10578	Botas Penseiras
10579	Flecha Explosiva
10580	Caixabum Goblínica
10581	Vestimenta da Cabeça da Morte
10582	Andejo do Urzal
10583	Arnês Afasta-espinho
10584	Punhos Ventempesta
10585	Rádio Goblínico
10586	O Bombão
10587	Distribuidor de Bombas Goblínico
10588	Capacete-foguete Goblínico
10589	Pedra do Juramento da Revoada de Ysera
10590	Caixa Preta Esburacada
10592	Elixir Olho de Gato
10593	Fragmento Imperfeito de Draenetista
10595	Kum'isha's Junk
10597	Cabeça da Maga Rimtori
10598	Cabeça Ensanguentada de Hetaera
10599	Cabeça Arrebentada de Hetaera
10600	Cabeça Ferida de Hetaera
10601	Diagrama: Óculos Brilho-do-olhar
10602	Diagrama: Mira Letal
10603	Diagrama: Ultra-óculos Olho-de-gato
10604	Diagrama: Rifle de Mithril de Grosso Calibre
10605	Diagrama: Óculos de Poder Mágico Xtremo
10606	Diagrama: Manto Paraquedas
10607	Diagrama: Capacete das Profundezas
10608	Diagrama: Mira de Francoatirador
10609	Diagrama: Dragonete Mecânico de Mithril
10610	Sangue de Hetaera
10620	Minério de Tório
10621	Pergaminho Rúnico
10622	Bandeira de Kadrak
10623	Mordida do Inverno
10624	Arco Ferroante
10625	Lâmina Furtiva
10626	Martelo da Ira
10627	Porrete do Cão Sorridente
10628	Golpe Mortal
10629	Botas do Andanévoa
10630	Halo Cata-almas
10631	Manoplas d'Água Suja
10632	Braçadeiras Escamalodo
10633	Perneiras Conchaprata
10634	Círculo do Olho da Mente
10635	Perneiras Encadeadas Pintadas
10636	Luvas Nômades
10637	Luvas do Cervejeiro
10638	Capa Drapejada Longa
10639	Cogumelo Jacinto
10640	Linfa de Lenhateia
10641	Lírio Lunapétala
10642	Antídoto de Iverron
10643	Carta Lacrada para Ag'tor
10644	Receita: Combustível de Foguete Goblínico
10645	Raio Gnômico da Morte
10646	Carga Sapadora Goblínica
10647	Tinta de Engenheiro
10648	Pergaminho em Branco
10649	Lasca de Pesadelo
10650	Juba de Javatusco Pestilento
10651	Cristal Arcano de Concentração Rachado
10652	Vontade do Gigante da Montanha
10653	Botas Abretrilhas
10654	Luvas de Trançajuta
10655	Culotes Semente de Junça
10656	Colete de Malha de Tronco
10657	Dragonas Barraltas
10658	Galochas do Atoleiro
10659	Estilhaço dos Cascos Fendidos
10660	Primeira Tabuleta Mosh'Aru
10661	Segunda Tabuleta Mosh'Aru
10662	Ovo de Hakkar Cheio
10663	Essência de Hakkar
10664	Um Bilhete para a Maga Rimtori
10678	Bilhete de Magatha
10679	Bilhete de Andron
10680	Bilhete de Sona'rima
10681	Bilhete de Tauriel
10682	Pedra do Juramento de Belnistrasz
10683	Mochila do Explorador
10684	Paraquedas Colossal
10686	Égide de Batalha
10687	Ampola Vazia Rotulada Nº 1
10688	Ampola Vazia Rotulada Nº 2
10689	Ampola Vazia Rotulada Nº 3
10690	Ampola Vazia Rotulada Nº 4
10691	Ampola Cheia Rotulada Nº 1
10692	Ampola Cheia Rotulada Nº 2
10693	Ampola Cheia Rotulada Nº 3
10694	Ampola Cheia Rotulada Nº 4
10695	Caixa de Ampolas Vazias
10696	Espada Destruição Vil de Azsharita Encantada
10697	Adaga Destruição Vil de Azsharita Encantada
10698	Cajado Destruição Vil de Azsharita Encantada
10699	Morácea de Yeh'Kinya
10700	Botas Encarnadas
10701	Botas de Zua'tec
10702	Botas Ôgricas Gigantescas
10703	Lâmina Bestial
10704	Estilhaçador Garrafria
10705	Munhequeiras do Salgueiro
10706	Cinturão Escama Noturna
10707	Grevas de Ferreiro de Aço
10708	Orbe do Feitiço Craniano
10709	Orbe de Lumepedra
10710	Anel Dragogarra
10711	Colar de Sangue de Dragão
10712	Elixir do Arnaldo
10713	Instruções: Cilindro Marchetado de Mithril
10714	Azsharita Cristalizada
10715	Telescópio do Kam'arawn
10716	Raio Gnômico Encolhedor
10717	Bússola do Kam'arawn
10718	Chinforímpola do Kam'arawn
10719	Alarme Móvel
10720	Projetor Gnômico Redomático
10721	Cinto Gnômico de Prevenção de Ferimentos
10722	Frango Recheado do Kam'arawn
10723	Radioamador Gnômico
10724	Botas-foguete Gnômicas
10725	Frango de Batalha Gnômico
10726	Casquete Gnômico de Controle Mental
10727	Pistola Dragônica Goblínica
10728	Molde: Camisa Preta do Espadachim
10738	Remessa para Galvan
10739	Anel da Fortitude
10740	Coxotes do Centurião
10741	Capacete de Lordrec
10742	Perneiras da Revoada
10743	Cimeira da Chama Dracônica
10744	Machado do Draco Ebâneo
10745	Omoplatas Kaylari
10746	Avambraços de Runaço
10747	Faixa do Professor
10748	Botas de Flanar
10749	Elmo de Vanguarda
10750	Punhal de Força Vital
10751	Diadema Explodegema
10752	Arca Incrustada de Esmeraldas
10753	Amuleto de Grol
10754	Amuleto de Sevine
10755	Amuleto de Allistarj
10757	Proteção do Profanador
10758	Javalibur
10759	Chifre Decepado de Profanador
10760	Punhos de Javali
10761	Adaga Fria-ira
10762	Vestes do Lich
10763	Celada Metal de Gelo
10764	Armadura Criomortis
10765	Falanges
10766	Varinha Praga Pútrida
10767	Guarda do Javali Selvagem
10768	Cinto do Campeão dos Javalis
10769	Olho Faiscante de Mordresh
10770	Crânio Inerte de Mordresh
10771	Faixa do Mago da Morte
10772	Cutelo do Glutão
10773	Urna Hakkari
10774	Omoplatas Couro-de-carne
10775	Carapaça de Tutan'kash
10776	Capa Seda-de-aranha
10777	Luvas Aracnídeas
10778	Colar do Santuário
10779	Sangue de Demônio
10780	Marca de Hakkar
10781	Peitoral de Hakkari
10782	Mortalha Hakkari
10783	Espaldares Atal'ai
10784	Peitoral Atal'ai
10785	Perneiras Atal'ai
10786	Botas Atal'ai
10787	Luvas Atal'ai
10788	Cinturão Atal'ai
10789	Manual das Disciplinas de Engenharia
10790	Cartão de Engenheiro Gnômico Associado
10791	Cartão de Engenheiro Goblínico Associado
10792	Pacto de Sigilo do Nixx
10793	Pacto de Sigilo do Superchispa
10794	Pacto de Sigilo do Olhatorto
10795	Anel Garradraca
10796	Pedra de Draco
10797	Soprafogo
10798	Anel da Presa de Atal'arion
10799	Picante
10800	Braçadeiras Aguanegra
10801	Botas Coleantes
10802	Manto Asavéu
10803	Lâmina do Ignóbil
10804	Punho dos Malditos
10805	Devoramortos
10806	Vestimenta do Profeta Atal'ai
10807	Kilt do Profeta Atal'ai
10808	Luvas do Profeta Atal'ai
10818	Pergaminho de Yeh'kinya
10819	Pena de Coruscante
10820	Cinto da Semeadura
10821	Manto do Semeador
10822	Dragonetinho Negro
10823	Espada do Vencedor
10824	Talismã de Brilhâmbar
10826	Cajado da Tradição
10827	Túnica do Topógrafo
10828	Unha Má
10829	Olho-do-dragão
10830	Granada de Fragmentação M73
10831	Orbe Vil
10832	Manual de Proprietário do Rastreador Vil
10833	Chifres de Erânicos
10834	Kit de Rastreador Canisvil
10835	Escudo da Supremacia
10836	Bastão de Corrosão
10837	Dente de Erânicos
10838	Poder do Hakkar
10839	Bilhete Cristalizado
10840	Bilhete Cristalizado
10841	Chá de Espinheira-dourada
10842	Sarongue Escaméolo
10843	Capa de Pelepluma
10844	Agulha de Hakkar
10845	Abraço do Guerreiro
10846	Grevas Injetadas de Sangue
10847	Chamado do Dragão
10858	Instruções: Malho de Ferro Maciço
10918	Veneno Ferino
10919	Luvas de Boticário
10920	Veneno Ferino II
10921	Veneno Ferino III
10922	Veneno Ferino IV
10938	Essência Mágica Inferior
10939	Essência Mágica Maior
10940	Pó Estranho
10958	Colar da Hilária
10959	Bolsa de Pelego de Demônio
10978	Estilhaço Luminoso Pequeno
10998	Essência Astral Inferior
10999	Ferrovil
11000	Chave de Umbraforja
11018	Solo de Un'Goro
11020	Bornal de Sempre-viva
11022	Pacote de Sementes de Tharlendris
11023	Galinha Ancona
11024	Caixa de Erva Sempre-viva
11026	Caixa de Sapo Arborícola
11027	Caixa de Sapo dos Bosques
11038	Fórmula: Encantamento Inferior de Espírito - Arma de 2M
11039	Fórmula: Encantamento Menor de Agilidade - Manto
11040	Grão-matinal
11058	Argola Nasal de Sha'ni
11078	Chave da Arca de Relíquias
11079	Cabeça Decepada do Gor'tesh
11080	Cabeça Decepada do Gor'tesh
11081	Fórmula: Encantamento Inferior de Proteção - Escudo
11082	Essência Astral Maior
11083	Pó d'Alma
11084	Estilhaço Luminoso Grande
11085	Chave do Cofre do Cliente do Mês
11086	Jang'thraze, a Protetora
11098	Fórmula: Encantamento Inferior de Resistência à Sombra - Manto
11099	Minério de Ferro Negro
11101	Fórmula: Encantamento Inferior de Força - Braçadeiras
11102	Ovo Choco de Dardejante
11103	Vale-sementes
11104	Bússola Grande
11105	Mapa em de Pergaminho Enrolado
11106	Chave de Cabeça de Leão
11107	Um Pacote Pequeno
11108	Fotografia Esmaecida
11109	Ração Especial de Galinha
11110	Ovo de Galinha
11111	Ovo Quebrado de Dardejante
11112	Equipamento de Pesquisa
11113	Caixote de Comestíveis
11114	Osso de Dinossauro
11115	Chave do Cofre Secreto
11116	Um Diário Destroçado
11118	Pedra Arcádica
11119	Colheita da Madel
11120	Martelo de Belgrom
11121	Talwar Aguanegra
11122	O Burro e a Cenoura
11123	Perneiras do Andarilho das Chuvas
11124	Elmo do Exílio
11125	Manifesto da Uva
11126	Tabuleta de Kurniya
11127	Material Reaproveitado
11128	Bastão Dourado
11129	Essência dos Elementos
11130	Bastão Rúnico Dourado
11131	Amostra de Parede de Colmeia
11132	Frasco para Amostra Vazio
11133	Espada de Treinamento de Linken
11134	Essência Mística Inferior
11135	Essência Mística Maior
11136	Espada Temperada de Linken
11137	Pó Visionário
11138	Estilhaço Faiscante Pequeno
11139	Estilhaço Faiscante Grande
11140	Chave de Cela da Prisão
11141	Isca
11142	Rebimboca Quebrada
11143	Chumbalheira
11144	Bastão de Veraprata
11145	Bastão Rúnico de Veraprata
11146	Rebimboca Quebrada e Surrada
11147	Capa do Manual da Rebimboca
11148	Página do Manual da Rebimboca
11149	Manual da Rebimboca
11150	Fórmula: Encantamento de Mineração - Luvas
11151	Fórmula: Encantamento de Herborismo - Luvas
11152	Fórmula: Encantamento de Pescaria - Luvas
11162	Espada Superior de Linken
11163	Fórmula: Encantamento Inferior de Deflexão - Braçadeiras
11164	Fórmula: Encantamento Inferior de Matador de Feras - Arma
11165	Fórmula: Encantamento Inferior de Matador de Elementais - Arma
11166	Fórmula: Encantamento de Esfolamento - Luvas
11167	Fórmula: Encantamento Inferior de Espírito - Botas
11168	Fórmula: Encantamento Inferior de Bloqueio - Escudo
11169	Livro de Aquor
11171	Ferrovil
11172	Garras Prateadas
11173	Coração de Ferrárbol
11174	Essência Etérea Inferior
11175	Essência Etérea Maior
11176	Pó Onírico
11177	Estilhaço Radiante Pequeno
11178	Estilhaço Radiante Grande
11179	Chama Dourada
11184	Cristal de Poder Azul
11185	Cristal de Poder Verde
11186	Cristal de Poder Vermelho
11187	Braçadeiras Folhaste
11188	Cristal de Poder Amarelo
11189	Vestes do Bosque
11190	Luvas Vinosas
11191	Botas do Fazendeiro
11192	Luvas do Provedor
11193	Peitoral Lufardente
11194	Cota de Escamaprisma
11195	Guarda-peito Forjado para Guerra
11196	Medalhão de Explosão Mental
11197	Chave do Guardião Sombrio
11198	Runa de Fuga
11199	Escudo 1 do Engenheiro
11200	Escudo 2 do Engenheiro
11201	Escudo 3 do Engenheiro
11202	Fórmula: Encantamento de Vigor - Escudo
11203	Fórmula: Encantamento de Mineração Avançada - Luvas
11204	Fórmula: Encantamento Maior de Espírito - Braçadeiras
11205	Fórmula: Encantamento de Herborismo Avançado - Luvas
11206	Fórmula: Encantamento Inferior de Agilidade - Manto
11207	Fórmula: Encantamento de Arma Ígnea - Arma
11208	Fórmula: Encantamento de Demonicídio - Arma
11222	Cabeça do Krom'zar
11223	Fórmula: Encantamento de Deflexão - Braçadeiras
11224	Fórmula: Encantamento de Resistência ao Gelo - Escudo
11225	Fórmula: Encantamento Maior de Vigor - Braçadeiras
11226	Fórmula: Encantamento de Perícia de Montaria - Luvas
11227	Pedaço do Estandarte de Krom'zar
11228	Muda de Pele de Revoada Frenética
11229	Cinturão Escama Brilhante
11230	Essência Abrasadora Aprisionada
11231	Muda de Pele Alterada da Revoada Negra
11242	Raiz do Mal
11243	Elixir Videre
11262	Orbe de Lórica
11263	Varinha da Força Etérea
11265	Malho de Madeira Densa
11266	Estilhaço Elemental Fraturado
11267	Amostra de Estilhaço Elemental
11268	Cabeça de Argelmach
11269	Núcleo de Elemental Intacto
11270	Pacto Assinado pelo Nixx
11282	Pacto Assinado pelo Olhatorto
11283	Pacto Assinado pelo Superchispa
11284	Balas de Precisão
11285	Flecha Serrilhada
11286	Grilhões de Tório
11287	Varinha Mágica Inferior
11288	Varinha Mágica Maior
11289	Varinha Mística Inferior
11290	Varinha Mística Maior
11291	Estrelenha
11302	Força de Uther
11303	Arco Curto de Qualidade
11304	Arco Longo de Qualidade
11305	Arco Curto Denso
11306	Arco Recurvo Robusto
11307	Arco Longo Maciço
11308	Arco Curto Silvestre
11309	O Coração da Montanha
11310	Dragonas do Videchamas
11311	Capa de Escamabrasa
11312	Receita Perdida de Cervaforte
11313	Cabeça do Ribas
11315	Broto de Pétala Sangrenta
11316	Pétala Sangrenta
11318	Bruma de Atal'ai
11319	Fulminadora Descarregada
11320	Fulminadora de Pétala Sangrenta
11321	Monstro - Espada2M, Horda Gigantesca
11324	Mochila do explorador
11325	Caneca de Cerveja Ferro Negro
11362	Aljava Média
11363	Bornal Médio para Projéteis
11364	Tabardo de Ventobravo
11366	Carta de Helendis Flumicórnio
11367	Apelo de Salomão a Bolvar
11368	Decreto de Bolvar
11370	Minério de Ferro Negro
11371	Barra de Ferro Negro
11382	Sangue-da-montanha
11384	Dentes Quebrados de Basilisco
11385	Escama de Basilisco
11386	Olho Esponjoso de Basilisco
11387	Coração de Basilisco
11388	Peçonha de Basilisco
11389	Pele Cintilante de Basilisco
11390	Presa Quebrada de Morcego
11391	Asa Espinhosa de Morcego
11392	Garra Decepada de Morcego
11393	Crânio Pequeno de Morcego
11394	Coração de Morcego
11395	Orelha de Morcego
11402	Pelagem Lustrosa de Morcego
11403	Presa Grande de Morcego
11404	Olho Maligno de Morcego
11405	Veio de Prata Gigante
11406	Carcaça Apodrecida de Urso
11407	Pelagem Rasgada de Urso
11408	Mandíbula de Urso
11409	Flanco de Urso
11410	Garra de Urso Selvagem
11411	Osso Grande de Urso
11412	Ampola da Nagmara
11413	Ampola da Nagmara Cheia
11414	Juba Grisalha
11415	Frutinhas Mistas
11416	Caixa Torácica Delicada
11417	Asa Penosa
11418	Osso Oco de Asa
11419	Ovo Choco Misterioso
11420	Pena Elegante de Caligrafia
11422	Brinde de Renovação do Engenheiro Goblínico
11423	Brinde de Renovação do Engenheiro Gnômico
11442	Kit de Subdelegado de Ventobravo
11444	Javali do Glutão Implacável
11445	Flauta dos Anciãos
11446	Bilhete Amassado
11462	Faca Descartada
11463	Pacote Extraviado
11464	Informações Perdidas do Marechal Vilasboas
11465	Informações Perdidas do Marechal Vilasboas
11466	Relatório do Patiphe
11467	Medalhão Rocha Negra
11468	Pochete Ferro Negro
11469	Braçadeiras Feixessangue
11470	Transcrição de Tabuleta
11471	Ovo Frágil de Dardejante
11472	Lombo de Espreitador Jubaprata
11473	PX83-Enigmatron
11474	Ovo de Dardejante
11475	Manto Manchado de Vinho
11476	Pelagem de U'cha
11477	Garra Branca de Ravassauro
11478	Pelagem de Gorila de Un'Goro
11479	Pelagem de Pisoteador de Un'Goro
11480	Pelagem de Trovejador de Un'Goro
11482	Manual do Usuário da Torre de Cristal
11502	Omoplatas Dermossapiens
11503	Âmbar de Sangue
11504	Pedaço de Carcaça de Manguadonte
11507	Pelagem Malhada de Hiena
11508	Sapatilhas do Mestre do Jogo
11509	Glândula de Feromônio de Ravassauro
11510	Cabeça do Lar'korwi
11511	Lampião Cenariano
11512	Retalho de Pele Maculada
11513	Vitríolo Maculado
11514	Fluido Malevo
11515	Estilhaço de Alma Corrompida
11516	Bálsamo Vegetal Cenariano
11522	Totem de Prata de Aquementas
11562	Restauração de Cristal
11563	Força de Cristal
11564	Proteção de Cristal
11565	Subjugação de Cristal
11566	Carga de Cristal
11567	Aguilhão de Cristal
11568	Bornal do Torwa
11569	Carne de Manguadonte em Conserva
11570	Mistura de Feromônios em Conserva
11582	Unguento Pérfido
11583	Sabra
11584	Surpresa de Sabra
11590	Kit de Reparos Mecânicos
11602	Chave do Glutão Implacável
11603	Fatiador Rasgavil
11604	Peitoral Ferro Negro
11605	Omoplatas Ferro Negro
11606	Cota de Malha Ferro Negro
11607	Talhador Ferro Negro
11608	Pulverizador Ferro Negro
11609	Muda de Pele Alterada da Revoada Negra
11610	Instruções: Pulverizador Ferro Negro
11611	Instruções: Talhador Ferro Negro
11612	Instruções: Peitoral Ferro Negro
11614	Instruções: Cota de Malha Ferro Negro
11615	Instruções: Omoplatas Ferro Negro
11617	Suprimentos de Eridan
11622	Arcano Inferior da Reflexão
11623	Capa Lança-quimera
11624	Sobreveste Magna
11625	Esfera Encantada
11626	Capa Véu Negro
11627	Grevas Papa-jardas
11628	Arco do Mestre de Matilha
11629	Rifle do Mestre de Matilha
11630	Projéteis Lascarrocha
11631	Guarda Litocasco
11632	Omoplatas dos Escombros
11633	Carapaça Aracnopresa
11634	Luvas de Teiasseda
11635	Estoque Gancho Mau
11642	Arcano Inferior da Constituição
11643	Arcano Inferior da Tenacidade
11644	Arcano Inferior da Resiliência
11645	Arcano Inferior da Voracidade
11646	Arcano Inferior da Voracidade
11647	Arcano Inferior da Voracidade
11648	Arcano Inferior da Voracidade
11649	Arcano Inferior da Voracidade
11662	Faixa Ban'thok
11665	Punhos do Ogro Vigia
11668	Flauta de Xavaric
11669	Grande Anel Arcano
11674	Ligavil de Flamejade
11675	Botas Umbradictas
11677	Capa Podretumba
11678	Carapaça de Anub'shiah
11679	Guarda-braços Rubicundos
11682	Ampola de Eridan
11684	Inimigo de Ferro
11685	Omoplatas de Courotala
11686	Cinturão da Fúria Bestial
11702	Esfolador do Grisalho
11703	Cinturão Muro-de-pedra
11722	Espaldares de Metalreles
11723	Flamberge Balanceada de Massoaço
11724	Pacote Atrasado
11725	Haste de Perna de Cristal Maciço
11726	Cota Encadeada do Gladiador Selvagem
11727	Livro de A. Massoaço
11728	Perneiras do Gladiador Selvagem
11729	Elmo do Gladiador Selvagem
11730	Guantes do Gladiador Selvagem
11731	Grevas do Gladiador Selvagem
11732	Incunábulo da Reflexão
11733	Incunábulo da Constituição
11734	Incunábulo da Tenacidade
11735	Tapa-olho da Cólera
11736	Incunábulo da Resiliência
11737	Incunábulo da Voracidade
11742	Mochila do Viajor
11743	Punho de Rocha
11744	Punho de Sangue
11745	Punhos do Falange
11746	Elmo Crânio de Golem
11747	Vestes do Vagachamas
11748	Caduceu Pírico
11749	Perneiras de Escama Ígnea
11750	Báculo Lenhoso
11751	Essência Flamejante
11752	Sangue Negro dos Atormentados
11753	Olho de Kajal
11754	Diamante Preto
11755	Colar de Verek
11764	Braceleiras de Courogris
11765	Munhequeiras de Piromalha
11766	Manilhas de Flamapano
11767	Guarda-braços de Placa Ígnea
11768	Braçadeiras Incandescentes
11782	Dragonas Boreais
11783	Cinturão Açogélido
11784	Lâmina do Mediador
11785	Baluarte do Golem de Rocha
11786	Pedra da Terra
11787	Botas Litocasca
11802	Perneiras de Cristalava
11803	Força de Magma
11804	Cantil da Espraga
11805	Martelo de Rubídio
11807	Faixa do Coração Ardente
11808	Círculo de Fogo
11809	Ira Chamejante
11810	Força de Vontade
11811	Coração Fumegante da Montanha
11812	Capa da Salamandra de Fogo
11813	Fórmula: Coração Fumegante da Montanha
11814	Punhos Derretidos
11815	Mão da Justiça
11816	Machado de Batalha de Forjaversa
11817	Espada do Grão-general
11818	Chave da Casinha de Pedrassuja
11819	Fôlego Renovado
11820	Armadura Real Adornada
11821	Perneiras da Discórdia
11822	Botas Pluriarranque
11823	Kilt Luminar
11824	Elo Ciclópico
11825	Bombinha de Estimação
11826	Fumacinho
11827	Diagrama: Fumacinho
11828	Diagrama: Bombinha de Estimação
11829	Cinza de Un'Goro
11830	Escama de Dimetrodonte Palmado
11831	Escama de Pterrordax Palmado
11832	Explosão de Conhecimento
11833	Isca para a Rainha Gorishi
11834	Piche Supergrudento
11835	Cérebro da Rainha Gorishi
11837	Glândula Odorífera Gorishi
11839	Monóculo do Arquiteto-chefe
11840	Camisa do Mestre Construtor
11841	Pantalonas do Projetista Sênior
11842	Dragonas do Topógrafo-mor
11843	Comprovante Bancário
11844	Relatório de Un'Goro do Almofarrista
11845	Bolsa de Couro Artesanal
11846	Beberagem Especial de Lhogolhó
11847	Manto Surrado
11848	Cinto de Linhão
11849	Braçadeiras de Metal Enferrujado
11850	Capa Curta do Quiropúsculo
11851	Túnica do Catador
11852	Perneiras do Errante
11853	Botas do Errante
11854	Chave de Fenda da Rebimboca
11855	Chave de Torque
11856	Lâmina Cerimonial Élfica
11857	Bastão Santimonial
11858	Capa da Batalha Árdua
11859	Orbe Lunajade
11860	Para-raios Carregado
11861	Cinturão da Reprimenda
11862	Anel de Osso Branco
11863	Retalhador de Osso Branco
11864	Lança de Osso Branco
11865	Botas do Rancor
11866	Cinto Enlaçado da Nagmara
11867	Manoplas da Insanidade
11868	Elo da Sufocação
11869	Anel de Sha'ni
11870	Orbe do Oblívio
11871	Espaldares do Madeirame
11872	Grevas de Evitação
11873	Capa da Névoa Etérea
11874	Dragonas Rachanuvem
11875	Braçadeira Nuvem Zéfira
11876	Túnica Espreitaprados
11882	Perneiras do Pioneiro
11883	Pochete Suja
11884	Sobreveste Luz do Luar
11885	Tocha de Umbraforja
11886	Mensagem Urgente
11887	Baú do Círculo Cenariano
11888	Luvas de Pesquisa do Quintis
11889	Brafoneiras de Cascaferro
11902	Espada da Maestria de Linken
11903	Transportador de Gato (Gatinho Corrompido)
11904	Espírito de Aquementas
11905	Bumerangue de Linken
11906	Esmagaferas
11907	Matador de Feras
11908	Botas de Escavação do Arqueólogo
11909	Cinto de Utilidades do Escavador
11910	Guarda-pernas Adornados
11911	Perneiras de Coparbórea
11912	Pacote de Recipientes Vazios de Gosma
11913	Elmo Cristargila
11914	Jarra de Gosma Amaldiçoada Vazia
11915	Bloqueador de Garoa do Chislo
11916	Focinheira do Chislo
11917	Limpa-focinho do Chislo
11918	Luvas Lajegrota
11919	Grevas de Placapenha
11920	Ceifa-almas
11921	Colosso Inexpugnável
11922	Lâmina Gravada em Sangue
11923	Martelo da Dádiva
11924	Vestes da Coroa Real
11925	Fantasmalha
11926	Peitoral Causamortis
11927	Coxotes do Guardião Eterno
11928	Cetro Real de Thaurissan
11929	Perneiras da Assombração
11930	A Capa Nova do Imperador
11931	Retaliador Deimoforja
11932	Báculo-guia da Sabedoria
11933	Joia da Coroa
11934	Selo do Imperador
11935	Pedra Magmus
11936	Cinto do Caçador de Relíquias
11937	Saco Gordo de Moedas
11938	Saco de Gemas
11939	Bracelete Reluzente
11940	Colar Cintilante
11941	Documentos Falsos
11942	Documentos Legais
11943	Escritura da Ponte Thandol
11944	Botinhas de Bebê Ferro Negro
11945	Anel Ferro Negro
11946	Colar de Opala-de-fogo
11947	Jarra de Gosma Amaldiçoada Cheia
11948	Jarra de Gosma Maculada Vazia
11949	Jarra de Gosma Maculada Cheia
11950	Amoras do Botão Selvagem
11951	Tubérculo de Raiz-açoite
11952	Sopro de Dragão Noturno
11953	Jarra de Amostra Pura Vazia
11954	Jarra de Amostra Pura Cheia
11955	Bolsa de Recipientes de Gosma Vazios
11962	Manilhas
11963	Espaldares da Penitência
11964	Clava Golpepresto
11965	Anel de Quartzo
11966	Saco de Moedas Pequeno
11967	Anel de Zircão
11968	Anel de Âmbar
11969	Círculo de Jacinto
11970	Anel de Espinélio
11971	Anel de Ametista
11972	Argola de Cornalina
11973	Anel de Hematita
11974	Anel de Água-marinha
11975	Anel de Topázio
11976	Anel de Sardônica
11977	Argola de Serpentina
11978	Anel de Jaspe
11979	Círculo de Peridoto
11980	Anel de Opala
11981	Anel de Chumbo
11982	Anel Viridiano
11983	Anel Cromado
11984	Anel de Cobalto
11985	Anel Cerúleo
11986	Aro de Tálio
11987	Círculo de Irídio
11988	Elo de Telúrio
11989	Argola de Vanádio
11990	Argola de Selênio
11991	Anel de Mercúrio
11992	Anel de Cinábrio
11993	Anel de Argila
11994	Anel de Coral
11995	Anel de Marfim
11996	Anel de Basalto
11997	Círculo de Clorastolita
11998	Argola de Azeviche
11999	Aro de Magnetita
12000	Decepador
12001	Anel de Ônix
12002	Círculo de Mármore
12003	Cerveja Escura dos Anões
12004	Anel Obsidiano
12005	Anel de Granito
12006	Anel do Prado
12007	Anel da Pradaria
12008	Anel da Savana
12009	Anel da Tundra
12010	Anel do Charco
12011	Aro da Floresta
12012	Anel do Pântano
12013	Anel do Deserto
12014	Anel Ártico
12015	Anel do Pantanal
12016	Anel da Selva
12017	Anel Prismático
12018	Elmo do Protetor
12019	Talismã Cerúleo
12020	Gargantilha de Tálio
12021	Escarpes de Blindaplaca
12022	Corrente de Irídio
12023	Colar de Telúrio
12024	Talismã de Vanádio
12025	Colar de Selênio
12026	Pingente de Mercúrio
12027	Colar de Cinábrio
12028	Colar de Basalto
12029	Talismã de Clorastolita
12030	Corrente de Azeviche
12031	Colar de Magnetita
12032	Gargantilha de Ônix
12033	Joias da Família Thaurissan
12034	Colar de Mármore
12035	Pingente Obsidiano
12036	Colar de Granito
12037	Carne Misteriosa
12038	Selo de Lagrave
12039	Colar da Tundra
12040	Pingente da Floresta
12041	Perneiras Cortavento
12042	Colar do Pântano
12043	Gargantilha do Deserto
12044	Pingente Ártico
12045	Pingente do Pantanal
12046	Colar da Selva
12047	Colar Espectral
12048	Pingente Prismático
12049	Peitoral Trinca-aço
12050	Botas Enevoadas
12051	Manoplas de Latão
12052	Anel da Lua
12053	Anel de Rocha Vulcânica
12054	Anel Demoníaco
12055	Anel de Poeira Estelar
12056	Anel dos Céus
12057	Anel de Escama de Dragão
12058	Anel de Osso Demoníaco
12059	Medalhão do Conquistador
12060	Bilhete de Shindrell
12061	Lâmina do Discernimento
12062	Lâmina da Aptidão Guerreira
12064	Capuz do Mestre do Jogo
12065	Protetor dos Elementos
12066	Capa de Xistocouro
12082	Espaldares de Couro de Serpe
12083	Faixa Valconiana
12102	Anel do Aristocrata
12103	Estrela de Mystaria
12104	Túnica Espinopétrea
12105	Perneiras de Malha Soberba
12106	Peitoral de Rochapele
12107	Perneiras de Murmusseda
12108	Armadura de Escama Basáltica
12109	Sobreveste da Lua Lazúli
12110	Clâmide Lançachuva
12111	Manoplas de Placamagma
12112	Braçadeiras do Demônio da Cripta
12113	Capa Helionata
12114	Luvas do Ocaso
12115	Amarra Impávida
12122	Sucata do Kum'isha
12143	Chave de Espinodrago
12144	Ovosciloscópio
12162	Instruções: Espada Curta de Ferro Temperado
12163	Instruções: Espada Larga de Lunaço
12164	Instruções: Machado Sólido de Ferro
12184	Carne de Raptor
12185	Chapéu do Almirante da Vela Sangrenta
12190	Poção do Sono sem Sonhos
12191	Baú do Aurora de Prata
12192	Baú do Véu das Brumas
12202	Carne de Tigre
12203	Carne Vermelha de Lobo
12204	Carne Gorda de Kodo
12205	Carne de Aranha Branca
12206	Carne Tenra de Caranguejo
12207	Ovo Gigantesco
12208	Carne Tenra de Lobo
12209	Filé de Lobo Magro
12210	Raptor Assado
12211	Costelinhas Temperadas de Lobo
12212	Ensopado da Selva
12213	Escondidinho de Carniceiro
12214	Ensopado Misterioso
12215	Ensopado Grosso de Kodo
12216	Chili Temperado de Caranguejo
12217	Chili Bafo de Dragão
12218	Omelete Monstro
12219	Selo da Ascensão sem Adorno
12220	Braçadeira Elemental Intacta
12223	Asa de Morcego Carnuda
12224	Asa de Morcego Crocante
12225	Vara de Pescar da Família Blump
12226	Receita: Asa de Morcego Crocante
12227	Receita: Filé de Lobo Magro
12228	Receita: Raptor Assado
12229	Receita: Costelinhas Picantes de Lobo
12230	Amostra de Visgo da Selva Maleva
12231	Receita: Ensopado da Selva
12232	Receita: Escondidinho de Carniceiro
12233	Receita: Ensopado Misterioso
12234	Amostra Corrompida da Selva Maleva
12235	Amostra de Visgo de Un'Goro
12236	Amostra Pura de Un'Goro
12237	Pedaços Delicados de Caranguejo
12238	Garoupa da Costa Negra
12239	Receita: Chili Bafo de Dragão
12240	Receita: Ensopado Grosso de Kodo
12241	Ovo de Dragão Recolhido
12242	Ossos de Criaturas Marinhas
12243	Garra Fumegante
12247	Faca de Lâmina Larga
12248	Punhal Audaz
12249	Machado Impiedoso
12250	Machado da Meia-noite
12251	Trocho
12252	Cajado da Proteção
12253	Manto Vermelho Brilhante
12254	Manto Bem Oleado
12255	Perneiras Pálidas
12256	Perneiras de Brasatrama
12257	Cinto Pesado Entalhado
12258	Cinto do Abraço da Serpente
12259	Adaga de Aço Irisado
12260	Lâmina Dourada Calcinante
12261	Instruções: Lâmina Dourada Calcinante
12262	Jaula Vazia de Filhote de Worg
12263	Filhote de Worg Enjaulado
12264	Jaula de Worg
12282	Machado de Batalha Usado
12283	Essência da Reprodução
12284	Draco-incarcinatrix 900
12286	Protótipo de Ovosciloscópio
12287	Módulo Colectrônico
12288	Gosma Corrupta Enfrascada
12289	Carcaça de Tartaruga Marinha
12291	Amostra de Gosma Amalgamada
12292	Caixa com Marcações Estranhas
12293	Fio de Ouro de Qualidade
12295	Perneiras da Milícia do Povo
12296	Centelha da Milícia do Povo
12299	Luvas de Rede
12300	Orbe de Energia Dracônica
12301	Chave da Gaiola de Bambu
12302	Rédeas do Sabre-de-gelo
12303	Rédeas do Sabre-da-noite
12323	Selo da Ascensão de Metal Bruto
12324	Selo Forjado da Ascensão
12325	Rédeas do Leopardo Primevo
12326	Rédeas do Gato-de-sabre Fulvo
12327	Rédeas do Gato-de-sabre Dourado
12330	Trompa do Lobo Vermelho
12334	Lascas de Friomalho
12335	Gema de Espinho Fúmeo
12336	Gema de Agulhapétrea
12337	Gema de Machado Sangrento
12339	Presente de Vaelan
12341	Amostra de Fruta Bosquenero
12342	Amostra de Grão Bosquenero
12343	Amostra de Castanha Bosquenero
12344	Selo da Ascensão
12345	Pertences de Biju
12346	Bacia de Limpeza Vazia
12347	Bacia de Limpeza Cheia
12349	Amostra do Rio Fontescarpa
12350	Tubo de Amostragem Vazio
12351	Trompa do Lobo Ártico
12352	Broche do Finitudo
12353	Rédea de Garanhão Branco
12354	Rédea de Baio
12355	Talismã de Corrupção
12356	Ovo de Mantícora de Alcândora
12358	Tabuleta de Pedranegra
12359	Barra de Tório
12360	Barra de Arcanita
12361	Safira Azul
12363	Cristal Arcano
12364	Esmeralda Enorme
12365	Pedra Densa
12366	Pele Grossa de Yeti
12367	Chifre Impoluto de Yeti
12368	Aposta da Aurora
12369	Cetro de Vectus
12382	Chave da Cidade
12383	Pena Lunamarca
12384	Provisões de Mau'Ari
12402	Ovo Velho
12404	Pedra de Afiar Densa
12405	Armadura de Tório
12406	Cinto de Tório
12408	Braçadeiras de Tório
12409	Botas de Tório
12410	Elmo de Tório
12411	Terceira Tabuleta Mosh'Aru
12412	Quarta Tabuleta Mosh'Aru
12414	Perneiras de Tório
12415	Peitoral Radiante
12416	Cinto Radiante
12417	Diadema Radiante
12418	Luvas Radiantes
12419	Botas Radiantes
12420	Perneiras Radiantes
12422	Torso de Placa Imperial
12424	Cinto de Placa Imperial
12425	Braçadeiras de Placa Imperial
12426	Botas de Placa Imperial
12427	Elmo de Placa Imperial
12428	Omoplatas de Placa Imperial
12429	Perneiras de Placa Imperial
12430	E'ko de Sabre-de-gelo
12431	E'ko de Invernoso
12432	E'ko de Dentilhaço
12433	E'ko de Coruscante
12434	E'ko de Ventogelante
12435	E'ko de Cardo de Gelo
12436	E'ko de Friomalho
12437	Caixote de Espargosa
12438	Carta de Vera
12440	Magic Knucklebone (DND)
12442	Charm Pouch (DND)
12443	Knucklebone Pouch (DND)
12444	Chifre Inteiriço de Quimera Ventogelante
12445	Pacote do Felnok
12446	Mosquete de Sidermar
12447	Arco de Pau-cardo
12448	Fuzil Leve de Caça
12449	Arco Primitivo
12450	Lufada Juju
12451	Poderio Juju
12452	Monstro - Escudo, Horda A02 Prata
12455	Brasa Juju
12457	Calafrio Juju
12458	Astúcia Juju
12459	Esquiva Juju
12460	Poder Juju
12462	Abraço da Serpente do Vento
12463	Açougueiro Dracopresa
12464	Garras Rubrofogo
12465	Clâmide do Ocaso
12466	Corda Albagulha
12467	Ovo Alienígena
12468	Varinha de Chilton
12469	Mutilador
12470	Tornozeleira do Espreitareia
12471	Cajado do Nômade do Deserto
12472	Termômetro do Gualter
12522	Luvas de Aviação do Gomez
12524	Amuleto de Penas Azuis
12525	Suprimentos do Jaron
12527	Rachacostela
12528	O Martelo do Juiz
12529	Jaula de Queimateia
12530	Ovo de Aranha do Pináculo
12531	Agulha Calcinante
12532	Aguilhão do Lapidador
12533	Pique da Brutalidade
12534	Cabeça do Omokk
12535	Gumeliso Forjamaldita
12542	Traje da Pira Funerária
12543	Pedra Cantante de Altaforja
12544	Determinação de Thrall
12545	Olho de Orgrimmar
12546	Manilhas Aristocráticas
12547	Guantes de Mar Alom
12548	Vontade de Magni
12549	Guarda-cérebro
12550	Grilhões Rúnicos de Golem
12551	Manto Escudopétreo
12552	Manta Balsâmica
12553	Botas Passopresto
12554	Mãos do Arauto Exaltado
12555	Grevas do Mavórcio
12556	Botas da Alta-sacerdotisa
12557	Espaldares de Açoébano
12558	Colar de Penas Azuis
12562	Documentos Importantes dos Rocha Negra
12563	Comando do Senhor da Guerra Trincador
12564	Bilhete de Assassinato
12565	Porta-gato da Winna
12566	Frasquinho Endurecido
12567	Frasquinho Cheio
12582	Keris de Zul'Serak
12583	Serra Maldita do Mão Negra
12584	Espada Longa do Grão-marechal
12585	Medalhão de Ventobravo
12586	Vesícula de Peçonha Imatura
12587	Olho de Laceral
12588	Ombreiras de Espetosso
12589	Faixa Plumafina
12590	Adagavil
12592	Lâmina Negra de Shahram
12602	Defletor Draconiano
12603	Túnica Elonoturno
12604	Tiara do Fogo Estelar
12605	Escalavrador Sinuoso
12606	Cinturão Cristalizado
12607	Escama Cromática Brilhante
12608	Avental do Açougueiro
12609	Veste de Visão Policromática
12610	Omoplatas de Placa Rúnica
12611	Botas de Placa Rúnica
12612	Elmo de Placa Rúnica
12613	Peitoral Rúnico
12614	Perneiras de Placa Rúnica
12615	Túnica Selvagem de Malha
12616	Botas Selvagens de Malha
12617	Omoplatas Selvagens de Malha
12618	Peitoral de Tório Encantado
12619	Perneiras de Tório Encantado
12620	Elmo de Tório Encantado
12621	Garfo do Demônio
12622	Carne de Dentilhaço
12623	Carne de Ventogelante
12624	Cota de Malha Cardagreste
12625	Omoplatas d'Alvorada
12626	Manilhas Funéreas
12627	Deslocador Temporal
12628	Peitoral Forjado pelo Demônio
12630	Cabeça do Laceral Mão Negra
12631	Manoplas de Placa Abrasadoras
12632	Manoplas da Tempestade
12633	Elmo da Alma Alva
12634	Cinturão do Cinzelador
12635	Pergaminho Simples
12636	Elmo do Grande Chefe
12637	Manoplas Backorianas
12638	Relógio de Andorhal
12639	Manoplas da Fortaleza
12640	Elmo Coração de Leão
12641	Cota de Malha Invulnerável
12642	Orbe Infernal Purificado
12643	Contrapeso Denso
12644	Pedra de Amolar Densa
12645	Espigão de Escudo de Tório
12646	Esmeralda Infusa
12647	Rubi de Felhas
12648	Espírito de Canisvil Aprisionado
12649	Espírito Infernal Aprisionado
12650	Amortecedor Ajustado
12651	Corvonegro
12652	Relatório de Reconhecimento de Biju
12653	Gancho Estripador
12654	Tiromaldito
12655	Barra de Tório Encantado
12662	Runa Demoníaca
12663	Galho de Carvalho com Glifos
12682	Instruções: Armadura de Tório
12683	Instruções: Cinto de Tório
12684	Instruções: Braçadeiras de Tório
12685	Instruções: Cinto Radiante
12687	Instruções: Omoplatas de Placa Imperial
12688	Instruções: Cinto de Placa Imperial
12689	Instruções: Peitoral Radiante
12690	Instruções: Braçadeiras de Placa Imperial
12691	Instruções: Cota de Malha Cardagreste
12692	Instruções: Espigão de Escudo de Tório
12693	Instruções: Botas de Tório
12694	Instruções: Elmo de Tório
12695	Instruções: Luvas Radiantes
12696	Instruções: Peitoral Forjado pelo Demônio
12697	Instruções: Botas Radiantes
12698	Instruções: Omoplatas d'Alvorada
12699	Instruções: Manoplas de Placa Abrasadoras
12700	Instruções: Botas de Placa Imperial
12701	Instruções: Elmo de Placa Imperial
12702	Instruções: Diadema Radiante
12703	Instruções: Manoplas da Tempestade
12704	Instruções: Perneiras de Tório
12705	Instruções: Torso de Placa Imperial
12706	Instruções: Omoplatas de Placa Rúnica
12707	Instruções: Botas de Placa Rúnica
12708	Caixote de Suprimentos da Encruzilhada
12709	Esfolador de Lépido
12710	Naco Brilhante de Carne da Besta
12711	Instruções: Elmo da Alma Alva
12712	Mojo do Warosh
12713	Instruções: Perneiras Radiantes
12714	Instruções: Elmo de Placa Rúnica
12715	Instruções: Perneiras de Placa Imperial
12716	Instruções: Elmo do Grande Chefe
12717	Instruções: Elmo Coração de Leão
12718	Instruções: Peitoral Rúnico
12719	Instruções: Perneiras de Placa Rúnica
12720	Instruções: Manoplas da Fortaleza
12721	Meio-pingente da Sorte
12722	Outra Metade do Pingente da Sorte
12723	Pingente da Sorte
12724	Embrulho da Janice
12725	Instruções: Elmo de Tório Encantado
12726	Instruções: Perneiras de Tório Encantado
12727	Instruções: Peitoral de Tório Encantado
12728	Instruções: Cota de Malha Invulnerável
12730	Pergaminho do Warosh
12731	Pelego Imaculado da Fera
12732	Agave Incendia
12733	Carne de Sabre-de-gelo Sagrado
12734	Fio Escarlate Encantado
12735	Sutura de Abominação Puída
12736	Fluido de Embalsamamento de Friomúrmuro
12737	Erva-do-emo
12738	Chave da Casinha dos Dalson
12739	Chave do Armário dos Dalson
12740	Quinta Tabuleta Mosh'Aru
12741	Sexta Tabuleta Mosh'Aru
12752	Casquete do Sábio Escarlate
12753	Pele de Sombra
12756	Perneiras do Arcanismo
12757	Peitoral da Sede de Sangue
12762	Sigilo dos Planos
12763	Eterfruta de Un'Goro
12764	Montante de Tório
12765	Bilhete Secreto Nº 1
12766	Bilhete Secreto Nº 2
12768	Bilhete Secreto Nº 3
12769	Desbasteiro de Lenhavil
12770	Informações de Biju
12771	Frasco Vazio de Aguardente
12772	Martelo Marchetado de Tório
12773	Machadinha Ornada de Tório
12774	Limiar da Aurora
12775	Machado de Batalha de Tório Enorme
12776	Martelo de Batalha Encantado
12777	Florete Fulgurante
12778	Baú de Documentos
12779	Gume Rúnico
12780	Comando do General Drakkisath
12781	Serenidade
12782	Corrupção
12783	Acerta-peito
12784	Retalhador de Arcanita
12785	Pó de Incendia
12789	Corneta de Uber Bônus (teste)
12790	Campeão de Arcanita
12791	Estoque do Taberneiro
12792	Martelo Vulcânico
12793	Túnica do Mixólogo
12794	Martelo Magistral da Tempestade
12795	Garra Sangrenta
12796	Martelo dos Titãs
12797	Guardafria
12798	Aniquilador
12799	Opala Grande
12800	Diamante Azerotiano
12802	Lançanegra
12803	Essência Viva
12804	Mojo Poderoso
12805	Orbe de Fogo
12806	Peitoral Rúnico de Metal Bruto
12807	Estandarte do Flagelo
12808	Essência de Morte-viva
12809	Pedra Guardiã
12810	Couro Encantado
12811	Orbe da Retidão
12812	Manoplas de Placa Crua
12813	Frasco de Meleca Misteriosa
12814	Chama Engarrafada
12815	Tocha Sinalizadora
12816	Instruções: Montante de Tório
12817	Instruções: Desbasteiro de Lenhavil
12818	Instruções: Martelo Marchetado de Tório
12819	Instruções: Machadinha Ornada de Tório
12820	Aguardente Invernosa
12821	Instruções: Limiar da Aurora
12822	Gotinha de Horror Tóxico
12823	Instruções: Machado de Batalha de Tório Enorme
12824	Instruções: Martelo de Batalha Encantado
12825	Instruções: Florete Fulgurante
12826	Instruções: Gume Rúnico
12827	Instruções: Serenidade
12828	Instruções: Martelo Vulcânico
12829	Caixote dos Invernosos
12830	Instruções: Corrupção
12831	Instruções: Garra Sangrenta
12832	Instruções: Lançanegra
12833	Instruções: Martelo dos Titãs
12834	Instruções: Campeão de Arcanita
12835	Instruções: Aniquilador
12836	Instruções: Guardafria
12837	Instruções: Martelo Magistral da Tempestade
12838	Instruções: Retalhador de Arcanita
12839	Instruções: Acerta-peito
12840	Pedra do Flagelo do Lacaio
12841	Pedra do Flagelo do Invasor
12842	Registro Escrito Grosseiramente
12843	Pedra do Flagelo do Corruptor
12844	Símbolo de Bravura da Aurora Argêntea
12845	Medalhão da Fé
12846	Ordem da Aurora Argêntea
12847	Pique Manchado de Almas
12848	Pique Manchado de Sangue
12849	Saco que o Diabo Beijou
12871	Carapaça Cromática
12884	Casco de Arnak
12885	Boneca de Pâmela
12886	Cabeça da Boneca de Pâmela
12887	Parte Esquerda da Boneca de Pâmela
12888	Parte Direita da Boneca de Pâmela
12891	Picareta do Jaron
12894	Anel de Casamento do Josefo
12895	Peitoral da Revoada Cromática
12896	Primeiro Fragmento de Relíquia
12897	Segundo Fragmento de Relíquia
12898	Terceiro Fragmento de Relíquia
12899	Quarto Fragmento de Relíquia
12900	Anais da Vila das Flechas
12903	Guarda-pernas do Desafiante Cromático
12904	Chapéu Swami Super Especial do Shawn
12905	Capa do Fogo Indômito
12906	Água Purificada do Poço Lunar
12907	Água Corrompida do Poço Lunar
12922	Cantil Vazio
12923	Escama do Awbee
12924	Vela Ritual
12925	Pele da Serpente Arikara
12926	Elo Flamejante
12927	Omoplatas Golpecerto
12928	Yeti Mecânico da Umi
12929	Talismã Furiarrubra
12930	Junco Rosabrava
12935	Guarda-pernas do Mestre Guerreiro
12936	Braceleiras Belinato
12938	Sangue dos Heróis
12939	Guardião Tribal de Dal'Rend
12940	Encargo Sagrado de Dal'Rend
12942	Chave da Jaula da Pantera
12945	Coxotes do Desafiante Cromático
12946	Dispositivo Hipercapacitador
12947	Anel da Audácia de Alex
12952	Crânio de Gyth
12953	Coifa Olho-de-dragão
12954	Incunábulo de Davil
12955	Escudo de Trilharrubra
12956	Crânio de Horgus
12957	Espada Estilhaçada de Marduk
12958	Receita: Transmutar Arcanita
12960	Penas de Guerra Tribais
12963	Perneiras do Mestre de Espadas
12964	Guarda-pernas de Tristam
12965	Perneiras de Mortalha Espectral
12966	Guarda-braços de Brumanegra
12967	Manto de Sangreluna
12968	Capa do Tecegelo
12969	Salgueiro Intruso
12970	Placa Cerimonial do General
12973	Bala de Canhão Escarlate
12974	O Cavaleiro Negro
12975	Machado do Prospector
12976	Lâmina Ferroque
12977	Luvas Punhomago
12978	Cinto Traztormenta
12979	Manto Fogazar
12982	Guarda-pés de Trama de Prata
12983	Clava Rakzur
12984	Clamacéus
12985	Anel de Defesa
12987	Calções de Trevatrama
12988	Túnica Astroptikon
12989	Mordida de Gárgula
12990	Fio da Navalha
12992	Lâmina Calcinante
12994	Manoplas de Tórbia
12996	Anel da Purificação
12997	Escudo Barbarruiva
12998	Dragonas do Mágico
12999	Embraces Dracoflama
13000	Cajado de Hale Flamagus
13001	Aro da Donzela
13002	Pingente da Lady Elizebeth
13003	Machado de Batalha do Lorde Alexandre
13004	Tocha de Austen
13005	Cobertor de Amy
13006	Marreta de Herrera
13007	Manto Flamago
13008	Calças Ventoval
13009	Pelego do Rei das Vacas
13010	Guarda-pernas Cantonírio
13011	Cinto Forrado de Prata
13012	Braçadeiras dos Figueira
13013	Dragonas do Teurgo Ancião
13014	Machado de Rin'ji
13015	Serathil
13016	Mataleija
13017	Machado de Batalha Infernocida
13018	Cutelo do Carrasco
13019	Arco Curto Garrarpia
13020	Arco Atacacéu
13021	Lançagulhas
13022	Arco Longo Asa de Grifo
13023	Arco Longo Hastáguia
13024	Esmagante de Beazel
13025	Marreta de Lenha Morta
13026	Luz do Paraíso
13027	Quebraossos
13028	Martelo Sanguipetrus
13029	Cristal do Umbral
13030	Osso de Basilisco
13031	Orbe Brumanto
13032	Espada da Corrupção
13033	Lâmina do Zelote
13034	Florete Aço-veloz
13035	Fatia-serpente
13036	Lâmina do Assassinato
13037	Aguilhante Cristalpinus
13038	Velozvento
13039	Besta Parte-crânio
13040	Besta Cordicrava
13041	Lâmina Guardiã
13042	Espada do Magistrado
13043	Lâmina dos Titãs
13044	Matademônios
13045	Martelo Viscoso
13046	Dureza de Blanchard
13047	Rama da Árvore do Mundo
13048	Martelete Assomante
13049	Espadão da Reitoria
13051	Bruxafúria
13052	Fomentador da Guerra
13053	Arauto da Ruína
13054	Anjo da Morte
13055	Mascaosso
13056	Golpeador Frenético
13057	Piquessangue
13058	Ponta de Khraa
13059	Petrocorvus
13060	O Alfinetador
13062	Pau-de-trovão
13063	Derruba-estrelas
13064	Incendiário de Jaina
13065	Varinha de Allistarj
13066	Espaldares do Mata-serpe
13067	Armadura Hidraliska
13068	Grevas Obsidianas
13070	Botas de Escama de Sapphiron
13071	Punho de Placas de Hakhan
13072	Manoplas Pegapétrea
13073	Elmo de Mugthol
13074	Perneiras do Estilhaço de Golem
13075	Guarda-pernas Cruelasa
13076	Braçadeiras do Mata-gigantes
13077	Cinturão de Uther
13079	Escudo de Turgo
13080	Ninho da Viúva
13081	Escudo Craniolança
13082	Broquel Montês
13083	Brasão da Família Garreta
13084	Corrente Caleidoscópica
13085	Gargantilha do Horizonte
13086	Rédeas do Sabre-de-gelo de Hibérnia
13087	Gargantilha do Rio Altivo
13088	Patuá do Gasganete
13089	Pingente de Skibi
13090	Peitoral dos Escolhidos
13091	Medalhão do Grão-marechal Morres
13093	Anel Brasa Viva
13094	A Joia da Rainha
13095	Anel de Assalto
13096	Anel do Hierofante
13097	Anel Frontrovão
13098	Elo Tecemágoa
13099	Mocassins da Lebre Branca
13100	Botas do Furen
13101	Sapatos Lupívelos
13102	Enfeite de Cassandra
13103	Espaldares da Aranha Peçonhenta
13105	Anel de Sutarn
13106	Braceletes Faiscantes Mágicos
13107	Manilhas Magicrânicas
13108	Dragonas Tigrataque
13109	Capa Neroflama
13110	Arnês Lupífobo
13111	Sandálias do Insurgente
13112	Elmo Alado
13113	Adorno Plumaluna
13114	Perneiras da Perdição do Troll
13115	Dragonas Tosavelo
13116	Espaldares do Oculto
13117	Faixa de Ogron
13118	Faixa Serpentina
13119	Braçadeiras Encantadas do Kodo
13120	Braçadeiras Fundafúria
13121	Asa do Dragonetinho
13122	Capa do Fantasma Obscuro
13123	Armadura Andassonho
13124	Botas de Escama de Ravassauro
13125	Botas Élficas Encadeadas
13126	Manoplas do Anunciador de Batalhas
13127	Coroa Friarrasa
13128	Elmo do Grão-bergg
13129	Perneiras Flamigrenha
13130	Guarda-pernas de Correventos
13131	Dragonas Quelobrilho
13132	Omoplatas Esqueléticas
13133	Palas Dracoflama
13134	Cinto do Gladiador
13135	Guarda-braços Senhoriais
13136	Cospe-fogo do Toninho
13137	Tramaférrea
13138	O Silenciador
13139	Furatripa
13140	Chave Vermelho Sangue
13141	Dente de Gnarr
13142	Cinturão de Brigam
13143	Marca do Senhor dos Dragões
13144	Cinto da Serenidade
13145	Cinto Enorme do Ogro
13146	Espingarda Cospe-bala
13148	Cravija
13149	Tomo Eldarathiano de Evocação Vol. 1
13151	Os Estudos Místicos de Hor'ank
13152	A História sem Conclusão
13153	Tomo de Mal'cin Vorail
13154	Estudos de Jael'marin sobre o Arcano
13155	Crânio Ressonante
13156	Cristal Místico
13157	Crânio Fétido
13158	Palavras do Chefe Supremo
13159	Farinha de Osso
13161	Cajado do Refúgio
13162	Garras do Gatuno
13163	Foice Implacável
13164	Coração da Escama
13166	Omoplatas do Embate
13167	Punho de Omokk
13168	Peitoral do Rei Xamã
13169	Perneiras Crinalonga
13170	Perneiras do Manto Celeste
13171	Isqueiro do Fumaça
13172	Tabaco da Lata do Carranca
13173	Machado de Arremesso Fialado
13174	Amostra de Carne Infectada
13175	Arco Retorcido de Voone
13176	Dados do Flagelo
13177	Talismã da Evasão
13178	Círculo Vermelho Vinho
13179	Guarda-braços de Cernecúpreo
13180	Água Benta de Stratholme
13181	Luvas de Pele de Demônio
13182	Lâmina Fase
13183	Cospeçonha
13184	Guantes de Lágrimas
13185	Dragonas do Fendevidente
13186	Garrafa do Campo Pedravil Vazia
13187	Garrafa para Lágrimas de Dalson Vazia
13188	Garrafa para Antro Repelente Vazia
13189	Garrafa da Aridez de Garrão Vazia
13190	Garrafa do Campo Pedravil Cheia
13191	Garrafa para Lágrimas de Dalson Cheia
13192	Garrafa para Antro Repelente Cheia
13193	Garrafa da Aridez de Garrão Cheia
13194	Chave do Caldeirão do Campo Pedravil
13195	Chave do Caldeirão das Lágrimas de Dalson
13196	Chave do Caldeirão da Aridez de Garrão
13197	Chave do Caldeirão do Antro Repelente
13198	Tequebro
13199	Braceletes Massacrista
13202	Anais Estendidos da Vila das Flechas
13203	Manto da Vigília
13204	Clavabam
13205	Protetor Rumbarbo
13206	Perneiras de Pelo de Lobo
13207	Cabeça do Lorde das Sombras Fel'Dan
13208	Guarda-braços do Uivo Arrepiante
13209	Selo da Aurora
13210	Ombreiras do Lobo Pavoroso
13211	Braçadeiras Garracortante
13212	Enforcador do Halycon
13213	Olho de Queimateia
13216	Coroa do Penitente
13217	Anel do Penitente
13218	Presa da Aranha de Cristal
13223	Bolsa do Mensageiro de Stratholme
13243	Defensor Argênteo
13244	Manoplas Douradas
13245	Casco do Cresh
13246	Vingadora Argêntea
13247	Baú do Intendente Zigris
13248	Arcabuz Escopeta
13249	Cruzado Argênteo
13250	Cabeça do Balnazzar
13251	Cabeça do Barão Rivendare
13252	Cinturão do Correnuvens
13253	Mãos do Poder
13254	Guarda Astral
13255	Manoplas Miracerta
13257	Espaldares com Runas Demoníacas
13258	Manoplas de Courescória
13259	Guarda-pés de Ripaço
13260	Botas do Dançarino dos Ventos
13261	Globo de D'sak
13262	A Crematória
13282	Botas do Vigia da Torre Ogra
13283	Anel do Mago
13284	Botas de Batalha Dardejantes
13285	O Fatiador de Rocha Negra
13286	Puatrífida
13287	Molde: Arnês de Pelego de Raptor
13288	Molde: Cinto de Pelego de Raptor
13289	Canhão de Ectoplasma do Egan
13302	Chave da Caixa Postal da Travessa do Comércio
13303	Chave da Caixa Postal da Praça dos Cruzados
13304	Chave da Caixa Postal da Alameda do Festival
13305	Chave da Caixa Postal da Praça dos Anciãos
13306	Chave da Caixa Postal da Praça do Rei
13307	Chave da Caixa Postal de Ezra Carranca
13308	Diagrama: Defletor de Gelo
13309	Diagrama: Cano de Atirar Feito com Carinho
13310	Diagrama: Mira de Precisão
13311	Diagrama: Dragonete Mecânico
13313	Escritos Sagrados dos Altaneiros
13314	Abraço de Aline
13317	Apito do Raptor Marfim
13320	Acelerador Arcano
13321	Mecanostruz Verde
13322	Mecanostruz sem Pintura
13323	Mecanostruz Roxo
13324	Mecanostruz Vermelho e Azul
13325	Mecanostruz Verde Fluorescente
13326	Mecanostruz Branco Modelo A
13327	Mecanostruz Azul-gelo Modelo A
13328	Carneiro Preto
13329	Carneiro do Gelo
13330	Saco de Rabanetes do Derek
13331	Cavalo Descarnado Vermelho
13332	Cavalo Descarnado Azul
13333	Cavalo Descarnado Castanho
13334	Cavalo de Guerra Descarnado Verde
13335	Rédeas do Corcel da Morte
13340	Capa do Barão Negro
13342	Peixe de Estimação
13343	Pedra de Estimação
13344	Manoplas Dracórias
13345	Marca de Rivendare
13346	Vestes dos Exaltados
13347	Cristal de Zin-Malor
13348	Gumedonho
13349	Cetro do Profano
13350	Insígnia da Guarda Negra
13351	Avental do Forjador de Martelos Carmesim
13352	Litofídia de Vosh'gajin
13353	Livro dos Mortos
13354	Ressonador Ectoplásmico
13356	Intensificador Somático
13357	Agitador Ósseo
13358	Omoplatas Língua de Serpe
13359	Coroa da Tirania
13360	Dádiva dos Magos Élficos
13361	Aniquilador Forjacrânio
13362	Carta do Front de Batalha
13363	Decreto Municipal
13364	Anúncio de Ezra Carranca
13365	Aviso de Reunião da Cidade
13366	Brinquedo Engenhoso
13367	Presente Embrulhado
13368	Raspa-ossos
13369	Botas de Fogo
13370	Focador Vítreo
13371	Chama Paternal
13372	Cajado do Feitor
13373	Anel de Carne
13374	Dragonas Roubalmas
13375	Escudo da Retribuição
13376	Manto do Tribunal Real
13377	Minibalas de Canhão
13378	Blusa Ornicanto
13379	Flautim do Fogo Flamejante
13380	Obus Portátil do Gualter
13381	Botas do Mestre Canhoneiro
13382	Fura-bloqueio
13383	Tanga do Menestrel Saracoteante
13384	Cinturão do Arco-íris
13385	Tomo de Conhecimento
13386	Capa do Arquivista
13387	Cinturão da Antecipação
13388	A Túnica do Chefe do Correio
13389	As Calças do Chefe do Correio
13390	A Bandana do Chefe do Correio
13391	As Botinas do Chefe do Correio
13392	O Selo do Chefe do Correio
13393	Marretão do Malone
13394	Abraço Frio de Kranio
13395	Garras de Osso de Kranio
13396	Toque Horrendo de Kranio
13397	Capa de Gárgula Litopele
13398	Botas do Guinchador
13399	Gadanhos Rasgárgula
13400	Avambraços do Sádico
13401	A Mão Cruel de Tico
13402	Galochas do Timmy
13403	Laço da Violência
13404	Máscara do Imperdoável
13405	Brafoneiras do Nocturno Uivante
13408	Quebra-alma
13409	Braçadeiras Lacrimais
13422	Enguia Petrescama
13423	Óleo de Petrescama
13442	Poção Potente de Raiva
13443	Poção Superior de Mana
13444	Poção Elevada de Mana
13445	Elixir de Defesa Superior
13446	Poção Elevada de Cura
13447	Elixir dos Sábios
13448	A Escritura de Castro das Flechas
13450	A Escritura de Costa Sul
13451	A Escritura da Serraria Tarren
13452	Elixir do Mangusto
13453	Elixir da Força Bruta
13454	Elixir Arcano Maior
13455	Poção Maior de Escudopétreo
13456	Poção Maior de Proteção contra o Gelo
13457	Poção Maior de Proteção contra o Fogo
13458	Poção Maior de Proteção contra a Natureza
13459	Poção Maior de Proteção contra a Sombra
13460	Poção Maior de Proteção contra o Sagrado
13461	Poção Maior de Proteção contra o Arcano
13462	Poção de Purificação
13463	Folha-de-sonho
13464	Sonsona-dourada
13465	Sálvia-prata-da-montanha
13466	Pragônia
13467	Chapéu-de-gelo
13468	Lótus Preto
13469	Cabeça de Weldon Barov
13470	Cabeça de Alexi Barov
13471	A Escritura de Montalvo
13473	Pingente da Sorte Pedravil
13474	Espingarda do Fazendeiro Dalson
13475	Anel de Casamento da Família Dalson
13476	Receita: Poção Potente de Raiva
13477	Receita: Poção Superior de Mana
13478	Receita: Elixir de Defesa Superior
13479	Receita: Elixir dos Sábios
13480	Receita: Poção Elevada de Cura
13481	Receita: Elixir da Força Bruta
13482	Receita: Transmutar Ar em Fogo
13483	Receita: Transmutar Fogo em Terra
13484	Receita: Transmutar Terra em Água
13485	Receita: Transmutar Água em Ar
13486	Receita: Transmutar Morte-viva em Água
13487	Receita: Transmutar Água em Morte-viva
13488	Receita: Transmutar Vida em Terra
13489	Receita: Transmutar Terra em Vida
13490	Receita: Poção de Escudopétreo Maior
13491	Receita: Elixir do Mangusto
13492	Receita: Poção de Purificação
13493	Receita: Elixir Arcano Maior
13494	Receita: Poção Maior de Proteção contra o Fogo
13495	Receita: Poção Maior de Proteção contra o Gelo
13496	Receita: Poção Maior de Proteção contra a Natureza
13497	Receita: Poção Maior de Proteção contra o Arcano
13498	Perneiras Artesanais do Mestre Ferreiro
13499	Receita: Poção Maior de Proteção contra a Sombra
13500	Receita: Poção Maior de Proteção contra o Sagrado
13501	Receita: Poção Elevada de Mana
13502	Cinturão Artesanal do Mestre Ferreiro
13503	Pedra dos Alquimistas
13505	Lâmina Rúnica do Barão Rivendare
13506	Frasco de Petrificação
13507	Relatório de Vigia do Rochedo Chifre Longo
13508	Olho de Aracnida
13509	Amarra da Antecipação
13510	Frasco dos Titãs
13511	Frasco de Sabedoria Destilada
13512	Frasco de Poder Supremo
13513	Frasco de Resistência Cromática
13514	Uivo da Banshee
13515	Parafusos Eletrificados de Ramstein
13517	Receita: Pedra dos Alquimistas
13518	Receita: Frasco de Petrificação
13519	Receita: Frasco dos Titãs
13520	Receita: Frasco de Sabedoria Destilada
13521	Receita: Frasco de Poder Supremo
13522	Receita: Frasco de Resistência Cromática
13523	Sangue dos Inocentes
13524	Crânio das Sombras Incandescentes
13525	Dedos da Conexão Malévola
13526	Cinturão Marcado de Fogo
13527	Grevas do Andarilho da Lava
13528	Braçadeiras do Vácuo do Crepúsculo
13529	Carcaça de Nerub'enkan
13530	Pisantes das Presas Pingantes
13531	Perneiras do Espreitador da Cripta
13532	Garras de Tecer Escuridão
13533	Brafoneiras Gravadas com Ácido
13534	Dedo de Banshee
13535	Vestes Fantasmagóricas do Toque Gélido
13536	Corneta do Despertar
13537	Braçadeiras Courálgidas
13538	Brafoneiras Guinchavento
13539	Toque da Banshee
13542	Caixa Demoníaca
13544	Essência Espectral
13545	Lagostim
13546	Peixe Pança-sangrenta
13562	Restos Mortais de Trey Forjaleve
13582	Correia do Zergnídeo
13583	Coleira do Panda
13584	Pedra do Diablo
13585	Livro de Recordações
13602	Pedra Mágica Maior
13603	Pedra Mágica Elevada
13624	Lembrança Vinculada
13626	Cabeça Humana de Ras Friomúrmuro
13699	Pedra de Fogo
13700	Pedra de Fogo Maior
13701	Pedra de Fogo Elevada
13702	Erva-do-demo
13703	Osso de Kodo
13704	Chave-mestra
13724	Biscoito de Maná Enriquecido
13725	Saco de Horrores de Krastinov
13752	Lembrança Vinculada
13754	Parrudo Lustroso Cru
13755	Lula Invernal
13756	Perca-verão Crua
13757	Enguia Elétrica
13758	Vermelhão Cru
13759	Pargo Pinoturno Cru
13760	Salmão Helióscamo Cru
13761	Ovos Congelados
13810	Frutassol Abençoada
13811	Colar da Aurora
13812	Anel da Aurora
13813	Suco de Frutassol Abençoada
13815	Essa Tal Runa
13816	Espada Longa de Qualidade
13817	Montante Afilada
13818	Machado Entalhado
13819	Machado de Guerra Equilibrado
13820	Maça de Pancada
13821	Malho Avantajado
13822	Adaga com Pontas
13823	Cajado de Guerra Resoluto
13824	Arco Longo Recurvo
13825	Mosquete Carregado
13842	Manhã de Outono/Inverno
13843	Tarde de Outono/Inverno
13844	Fim da Tarde de Outono/Inverno
13845	Noite de Outono/Inverno
13846	Manhã Primavera/Verão
13847	Tarde Primavera/Verão
13848	Fim da Tarde Primavera/Verão
13849	Noite Primavera/Verão
13850	Munição do Estremetiro
13851	Costelinhas Picantes de Lobo
13852	Ordens do Grão-cruzado
13853	Naco de Carne de Verme Carniceiro
13856	Cinto de Runatrama
13857	Túnica de Runatrama
13858	Veste de Runatrama
13860	Manto de Runatrama
13863	Luvas de Runatrama
13864	Botas de Runatrama
13865	Calças de Runatrama
13866	Bandana de Runatrama
13867	Omoplatas de Runatrama
13868	Veste de Friotrama
13869	Túnica de Friotrama
13870	Luvas de Friotrama
13871	Calças de Friotrama
13872	Feixe de Lenha
13873	Chave da Sala de Exibição
13874	Caixote Pesado
13875	Baú Lacrado com Ferro
13876	Garoupa de 20 Quilos
13877	Garoupa de 23 Quilos
13878	Garoupa de 26 Quilos
13879	Garoupa de 29 Quilos
13880	Garoupa de 34 Quilos
13881	Vermelhão Inchado
13882	Vermelhão de 21 Quilos
13883	Vermelhão de 23 Quilos
13884	Vermelhão de 24 Quilos
13885	Vermelhão de 17 Quilos
13886	Vermelhão de 18 Quilos
13887	Vermelhão de 26 Quilos
13888	Lagosta Pinçanegra
13889	Salmão Escama-branca Cru
13890	Peixe-armadura de Placas
13891	Salmão Inchado
13892	Kodoagrupandador
13893	Grande Parrudo Cru
13895	Dangui Formal
13896	Hanbok Verde-escuro de Casamento
13897	Hanbok Tradicional Branco
13898	Dangui Real
13899	Hanbok Tradicional Vermelho
13900	Hanbok Verde de Casamento
13901	Salmão de 7 Quilos
13902	Salmão de 9 Quilos
13903	Salmão de 11 Quilos
13904	Salmão de 13 Quilos
13905	Salmão de 15 Quilos
13906	Salmão de 16 Quilos
13907	Lagosta de 3 Quilos
13908	Lagosta de 4 Quilos
13909	Lagosta de 6 Quilos
13910	Lagosta de 7 Quilos
13911	Lagosta de 9 Quilos
13912	Lagosta de 10 Quilos
13913	Lagosta de 11 Quilos
13914	Parrudo de 35 Quilos
13915	Parrudo de 43 Quilos
13916	Parrudo de 46 Quilos
13917	Parrudo de 51 Quilos
13918	Baú Resistente Trancado
13920	Escama de Dragão Saudável
13926	Pérola Dourada
13927	Parrudo Lustroso Cozido
13928	Lula Grelhada
13929	Robalo Defumado Picante
13930	Filé de Vermelhão
13931	Sopa de Pinoturno
13932	Salmão Helióscamo Poché
13933	Ensopado de Lagosta
13934	Filé de Parrudo
13935	Salmão Assado
13937	Dever do Diretor
13938	Cálamo de Rastejossos
13939	Receita: Rabo-amarelo Mosqueado
13940	Receita: Parrudo Lustroso Cozido
13941	Receita: Filé de Vermelhão
13942	Receita: Lula Grelhada
13943	Receita: Robalo Defumado Picante
13944	Peitoral da Lápide
13945	Receita: Sopa de Pinoturno
13946	Receita: Salmão Helióscamo Poché
13947	Receita: Ensopado de Lagosta
13948	Receita: Filé de Parrudo
13949	Receita: Salmão Assado
13950	Cinta de Detenção
13951	Avambraços de Açoforte
13952	Decepador Gelâmina
13953	Presa Silente
13954	Pisantes Verdejantes
13955	Omoplatas Feitas de Pedra
13956	Amarra de Andros
13957	Corta-gárgulas
13958	Grilhões de Wyrmthalak
13959	Cilha do Omokk
13960	Coração do Demônio
13961	Focinheira do Halycon
13962	Cordão de Vosh'gajin
13963	Manoplas Imorais de Voone
13964	Bruxilâmina
13965	Amplitude do Mão Negra
13966	Marca da Tirania
13967	Grevas Assolaventos
13968	Olho da Fera
13969	Braceleiras Guarda-vulto
13982	Lâmina de Guerra de Castro das Flechas
13983	Machado de Guerra da Lápide
13984	Flechespeto
13986	Coroa do Castro das Flechas
14002	Guardaforte da Vila das Flechas
14022	Convocador de Serviçais de Barov
14023	Convocador de Serviçais de Barov
14024	Gadanhorror
14025	Cinto do Místico
14042	Colete de Brasatrama
14043	Luvas de Brasatrama
14044	Manto de Brasatrama
14045	Calças de Brasatrama
14046	Bolsa de Runatrama
14047	Runatrama
14048	Peça de Runatrama
14062	Kodo de Montaria
14083	Cajado de Tyrande
14086	Sandálias Enfeitadas
14087	Manilhas Enfeitadas
14088	Manto Enfeitado
14089	Luvas Enfeitadas
14090	Culotes Enfeitados
14091	Veste Enfeitada
14093	Cordão Enfeitado
14094	Colete Enfeitado
14095	Embraces Nativos
14096	Colete Nativo
14097	Calças Nativas
14098	Manto Nativo
14099	Faixa Nativa
14100	Veste de Lumetrama
14101	Luvas de Lumetrama
14102	Mitenes Nativas
14103	Manto de Lumetrama
14104	Calças de Lumetrama
14106	Veste de Tecido Vil
14107	Calças de Tecido Vil
14108	Botas de Tecido Vil
14109	Veste Nativa
14110	Sandálias Nativas
14111	Capuz de Tecido Vil
14112	Omoplatas de Tecido Vil
14113	Faixa Aborígene
14114	Palmilhas Aborígenes
14115	Embraces Aborígenes
14116	Capa Aborígene
14117	Luvas Aborígenes
14119	Tanga Aborígene
14120	Veste Aborígene
14121	Colete Aborígene
14122	Embraces Ritualistas
14123	Capa Ritual
14124	Luvas Rituais
14125	Perneiras Rituais
14126	Sobreveste Ritual
14127	Mortalha Ritual
14128	Veste de Bruxatrama
14129	Sandálias Rituais
14130	Turbante de Bruxatrama
14131	Cinto Ritual
14132	Perneiras de Bruxatrama
14133	Túnica Ritual
14134	Manto de Fogo
14136	Veste da Noite de Inverno
14137	Perneiras de Lunatrama
14138	Colete de Lunatrama
14139	Omoplatas de Lunatrama
14140	Diadema de Lunatrama
14141	Colete de Espectrama
14142	Luvas de Espectrama
14143	Cinto de Espectrama
14144	Calças de Espectrama
14145	Lâmina Vil Amaldiçoada
14146	Luvas de Maestria em Feitiçaria
14147	Braçadeiras Cavernícolas
14148	Manilhas Cristalinas
14149	Capa Subterrânea
14150	Veste de Evocação
14151	Lâmina Cantante
14152	Veste do Arquimago
14153	Veste do Caos
14154	Vestimenta da Fé Verdadeira
14155	Bolsa de Lunatrama
14156	Bolsa sem Fundo
14157	Dragonas Pagãs
14158	Colete Pagão
14159	Sapatos Pagãos
14160	Embraces Pagãos
14161	Capa Pagã
14162	Luvas Pagãs
14163	Veste Pagã
14164	Cinto Pagão
14165	Culotes Pagãos
14166	Braçadeiras do Bucaneiro
14167	Capa do Bucaneiro
14168	Luvas do Bucaneiro
14169	Ombreiras Aborígenes
14170	Dragonas do Bucaneiro
14171	Calças do Bucaneiro
14172	Vestes do Bucaneiro
14173	Cordão do Bucaneiro
14174	Botas do Bucaneiro
14175	Colete do Bucaneiro
14176	Botas do Vigia
14177	Manilhas do Vigia
14178	Chapéu Pontudo do Vigia
14179	Capa do Vigia
14180	Gibão do Vigia
14181	Mitenes do Vigia
14182	Dragonas do Vigia
14183	Perneiras do Vigia
14184	Vestes do Vigia
14185	Cinturão do Vigia
14186	Dragonas Clamachuva
14187	Manilhas Clamachuva
14188	Manto Clamachuva
14189	Capuz Clamachuva
14190	Colete Clamachuva
14191	Luvas Clamachuva
14192	Vestes Clamachuva
14193	Calças Clamachuva
14194	Cordão Clamachuva
14195	Botas Clamachuva
14196	Sandálias Pelocardo
14197	Embraces Pelocardo
14198	Manto Pelocardo
14199	Luvas Pelocardo
14200	Capuz Pelocardo
14201	Dragonas Pelocardo
14202	Gibão Pelocardo
14203	Calças Pelocardo
14204	Veste Pelocardo
14205	Cinto Pelocardo
14206	Braceletes Vitais
14207	Perneiras Vitais
14208	Bandana Vital
14209	Faixa Vital
14210	Capa Vital
14211	Mitenes Vitais
14212	Omoplatas Vitais
14213	Traje Vital
14214	Botas Vitais
14215	Túnica Vital
14216	Gibão do Geomante
14217	Cordão do Geomante
14218	Botas do Geomante
14219	Manto do Geomante
14220	Bandana do Geomante
14221	Braçadeiras do Geomante
14222	Luvas do Geomante
14223	Espaldares do Geomante
14224	Calças do Geomante
14225	Veste do Geomante
14226	Braceletes de Seribrasa
14227	Seda de Aranha Ferroteia
14228	Bandana de Seribrasa
14229	Manto de Seribrasa
14230	Túnica de Seribrasa
14231	Luvas de Seribrasa
14232	Dragonas de Seribrasa
14233	Perneiras de Seribrasa
14234	Vestes de Seribrasa
14235	Cordão de Seribrasa
14236	Botas de Seribrasa
14237	Armadura Névoa Negra
14238	Botas Névoa Negra
14239	Capa Névoa Negra
14240	Embraces Névoa Negra
14241	Protetores de Mão Névoa Negra
14242	Calças Névoa Negra
14243	Dragonas Névoa Negra
14244	Veste Névoa Negra
14245	Cinturão Névoa Negra
14246	Chapéu de Teurgo Névoa Negra
14247	Dragonas Lunares
14248	Braceletes Lunares
14249	Colete Lunar
14250	Sapatilhas Lunares
14251	Manto Lunar
14252	Diadema Lunar
14253	Mitenes Lunares
14254	Traje Lunar
14255	Cinto Lunar
14256	Tecido Vil
14257	Perneiras Lunares
14258	Cordão Tecido em Sangue
14259	Botas Tecidas em Sangue
14260	Braçadeiras Tecidas em Sangue
14261	Manto Tecido em Sangue
14262	Luvas Tecidas em Sangue
14263	Máscara Tecida em Sangue
14264	Calças Tecidas em Sangue
14265	Veste Tecida em Sangue
14266	Ombreiras Tecidas em Sangue
14267	Gibão Tecido em Sangue
14268	Manilhas de Gaia
14269	Sapatilhas de Gaia
14270	Manto de Gaia
14271	Diadema de Gaia
14272	Mitenes de Gaia
14273	Sobreveste de Gaia
14274	Perneiras de Gaia
14275	Traje de Gaia
14276	Cinto de Gaia
14277	Túnica de Gaia
14278	Dragonas Opulentas
14279	Braceleiras Opulentas
14280	Capa Opulenta
14281	Coroa Opulenta
14282	Luvas Opulentas
14283	Perneiras Opulentas
14284	Vestes Opulentas
14285	Botas Opulentas
14286	Cinto Opulento
14287	Túnica Opulenta
14288	Armadura Aracnoide
14289	Cinturão Aracnoide
14290	Pisantes Aracnoides
14291	Braceletes Aracnoides
14292	Capa Aracnoide
14293	Diadema Aracnoide
14294	Luvas Aracnoides
14295	Guarda-pernas Aracnoides
14296	Brafoneiras Aracnoides
14297	Vestes Aracnoides
14298	Espaldares do Osteurgo
14299	Botas do Osteurgo
14300	Capa do Osteurgo
14301	Braceletes do Osteurgo
14302	Luvas do Osteurgo
14303	Mortalha do Osteurgo
14304	Cinto do Osteurgo
14305	Sarongue do Osteurgo
14306	Colete do Osteurgo
14307	Coroa do Osteurgo
14308	Túnica Celestial
14309	Cinto Celestial
14310	Sapatilhas Celestiais
14311	Braçadeiras Celestiais
14312	Coroa Celestial
14313	Capa Celestial
14314	Mitenes Celestiais
14315	Kilt Celestial
14316	Brafoneiras Celestiais
14317	Vestes de Seda Celestiais
14318	Túnica Resplandecente
14319	Botas Resplandecentes
14320	Braceletes Resplandecentes
14321	Manto Resplandecente
14322	Diadema Resplandecente
14323	Manoplas Resplandecentes
14324	Sarongue Resplandecente
14325	Palas Resplandecentes
14326	Vestes Resplandecentes
14327	Cinto Resplandecente
14328	Couraça Eterna
14329	Botas Eternas
14330	Braçadeiras Eternas
14331	Manto Eterno
14332	Coroa Eterna
14333	Luvas Eternas
14334	Sarongue Eterno
14335	Espaldares Eternos
14336	Veste Eterna
14337	Cordão Eterno
14338	Tubo de Água Vazio
14339	Tubo de Água do Poço Lunar
14340	Vestes Gélidas de Lich
14341	Fio Rúnico
14342	Lunatrama
14343	Estilhaço Brilhante Pequeno
14344	Estilhaço Brilhante Grande
14364	Sapatilhas do Místico
14365	Capa do Místico
14366	Braceletes do Místico
14367	Luvas do Místico
14368	Ombreiras do Místico
14369	Colete do Místico
14370	Bermuda do Místico
14371	Veste do Místico
14372	Armadura Sanguínea
14373	Cinto Sanguíneo
14374	Sandálias Sanguíneas
14375	Manilhas Sanguíneas
14376	Capa Sanguínea
14377	Mitenes Sanguíneas
14378	Dragonas Sanguíneas
14379	Calças Sanguíneas
14380	Veste Sanguínea
14381	Algibeira do Temível Totem
14382	Peito d'Armas da Durabilidade
14383	Braçadeiras da Durabilidade
14384	Botas da Durabilidade
14385	Manto da Durabilidade
14386	Chapéu da Durabilidade
14387	Luvas da Durabilidade
14388	Perneiras da Durabilidade
14389	Ombreiras da Durabilidade
14390	Cinto da Durabilidade
14391	Espada da Durabilidade
14392	Cajado da Durabilidade
14393	Escudo da Durabilidade
14394	Arco da Durabilidade
14395	Feitiços da Sombra
14396	Encantamentos do Éter
14397	Dragonas Resilientes
14398	Túnica Resiliente
14399	Botas Resilientes
14400	Capa Resiliente
14401	Capuz Resiliente
14402	Embraces Resilientes
14403	Guantes Resilientes
14404	Perneiras Resilientes
14405	Veste Resiliente
14406	Cordão Resiliente
14407	Colete de Panopétreo
14408	Botas de Panopétreo
14409	Capa de Panopétreo
14410	Bandana de Panopétreo
14411	Luvas de Panopétreo
14412	Palas de Panopétreo
14413	Veste de Panopétreo
14414	Cinto de Panopétreo
14415	Culotes de Panopétreo
14416	Braçadeiras de Panopétreo
14417	Túnica Sedareia
14418	Botas Sedareia
14419	Braçadeiras Sedareia
14420	Capa Sedareia
14421	Bandana Sedareia
14422	Luvas Sedareia
14423	Ombreiras de Sedareia
14424	Culotes Sedareia
14425	Veste Sedareia
14426	Cinturão Sedareia
14427	Colete Seguevento
14428	Pisantes Seguevento
14429	Manilhas Seguevento
14430	Manto Seguevento
14431	Protetores de Mão Seguevento
14432	Sobreveste Seguevento
14433	Calças Seguevento
14434	Vestes Seguevento
14435	Cilha Seguevento
14436	Diadema Seguevento
14437	Colete Venomortalha
14438	Botas Venomortalha
14439	Guarda-braços Venomortalha
14440	Capa Venomortalha
14441	Máscara Venomortalha
14442	Luvas Venomortalha
14443	Dragonas Venomortalha
14444	Perneiras Venomortalha
14445	Vestes de Seda Venomortalha
14446	Cinto Venomortalha
14447	Pisantes Altaneiros
14448	Braceletes Altaneiros
14449	Coroa Altaneira
14450	Manto Altaneiro
14451	Luvas Altaneiras
14452	Brafoneiras Altaneiras
14453	Vestes Altaneiras
14454	Cordão dos Altaneiros
14455	Armadura Acolchoada Altaneira
14456	Colete Elunário
14457	Manilhas Elunárias
14458	Botas Elunárias
14459	Manto Elunário
14460	Diadema Elunário
14461	Guantes Elunários
14462	Sarongue Elunário
14463	Espaldares Elunários
14464	Vestes Elunárias de Seda
14465	Cinto Elunário
14466	Molde: Túnica de Friotrama
14467	Molde: Veste de Friotrama
14468	Molde: Bolsa de Runatrama
14469	Molde: Veste de Runatrama
14470	Molde: Túnica de Runatrama
14471	Molde: Colete de Brasatrama
14472	Molde: Manto de Runatrama
14473	Molde: Cinto de Espectrama
14474	Molde: Luvas de Friotrama
14476	Molde: Luvas de Brasatrama
14477	Molde: Luvas de Espectrama
14478	Molde: Veste de Lumetrama
14479	Molde: Luvas de Lumetrama
14480	Molde: Colete de Espectrama
14481	Molde: Luvas de Runatrama
14482	Molde: Manto de Brasatrama
14483	Molde: Calças de Tecido Vil
14484	Molde: Manto de Lumetrama
14485	Molde: Perneiras de Bruxatrama
14486	Molde: Manto de Fogo
14487	Martelo Friosso
14488	Molde: Botas de Runatrama
14489	Molde: Calças de Friotrama
14490	Molde: Calças de Brasatrama
14491	Molde: Calças de Runatrama
14492	Molde: Botas de Tecido Vil
14493	Molde: Veste da Noite de Inverno
14494	Molde: Calças de Lumetrama
14495	Molde: Calças de Espectrama
14496	Molde: Capuz de Tecido Vil
14497	Molde: Perneiras de Lunatrama
14498	Molde: Bandana de Runatrama
14499	Molde: Bolsa de Lunatrama
14500	Molde: Veste de Bruxatrama
14501	Molde: Colete de Lunatrama
14502	Cinturão Mandíbulas de Gelo
14503	Garras da Morte
14504	Molde: Omoplatas de Runatrama
14505	Molde: Turbante de Bruxatrama
14506	Molde: Veste de Tecido Vil
14507	Molde: Omoplatas de Lunatrama
14508	Molde: Omoplatas de Tecido Vil
14509	Molde: Diadema de Lunatrama
14510	Molde: Bolsa sem Fundo
14511	Molde: Luvas de Maestria em Feitiçaria
14512	Molde: Vestimenta da Fé Verdadeira
14513	Molde: Veste do Arquimago
14514	Molde: Veste do Caos
14522	Perneiras da Voragem
14523	Picareta do Diabo
14525	Manoplas Ossapertos
14526	Molde: Lunatrama
14528	Broquel Range-ossos
14529	Bandagem de Runatrama
14530	Bandagem Grossa de Runatrama
14531	Cajado Atacaveira
14536	Cota Ossabraços
14537	Grevas Cadaverinas
14538	Manto do Necrâmbulo
14539	Elmo de Elo Ósseo
14540	Coração de Taragaman, o Famélico
14541	Espada da Família Barov
14542	Caixote de Kravel
14543	Luvas Nerumbra
14544	Insígnia do Tenente
14545	Perneiras Vultear
14546	Chifre de Kodo de Roon
14547	Mão da Iruxos
14548	Espaldares Régios
14549	Botas de Evasão
14550	Guarda-braços Laminazar
14551	Protetores de Mão do Mestre Laminar
14552	Brafoneiras do Cárcere
14553	Faixa da Misericórdia
14554	Coxotes do Guardião Nebuloso
14555	Navalha Solar de Alcor
14557	Trombeta Leonina de Ventobravo
14558	Pingente da Lady Maye
14559	Faixa do Prospector
14560	Botas do Prospector
14561	Manilhas do Prospector
14562	Peito d'Armas do Prospector
14563	Manto do Prospector
14564	Luvas do Prospector
14565	Bermuda do Prospector
14566	Ombreiras do Prospector
14567	Cinto Felpado
14568	Botas Felpadas
14569	Braceletes Felpados
14570	Camisa Felpada
14571	Capa Felpada
14572	Luvas Felpadas
14573	Sobreveste Felpada
14574	Culotes Felpados
14576	Cabo de Ébano de Marduque
14577	Calças Crânio Fumegante
14578	Cordão Dokebi
14579	Botas Dokebi
14580	Braçadeiras Dokebi
14581	Couraça Dokebi
14582	Capa Dokebi
14583	Luvas Dokebi
14584	Chapéu Dokebi
14585	Perneiras Dokebi
14587	Dragonas Dokebi
14588	Cordão Olho de Falcão
14589	Sapatos Olho de Falcão
14590	Braçadeira Olho de Falcão
14591	Elmo Olho de Falcão
14592	Túnica Olho de Falcão
14593	Manto Olho de Falcão
14594	Luvas Olho de Falcão
14595	Calções Olho de Falcão
14596	Palas Olho de Falcão
14598	Cintel do Vigilante
14599	Pisantes do Vigilante
14600	Munhequeiras do Vigilante
14601	Colete do Vigilante
14602	Manto do Vigilante
14603	Dragonas do Vigilante
14604	Casquete do Vigilante
14605	Bermuda do Vigilante
14606	Luvas do Vigilante
14607	Broquel Olho de Falcão
14608	Broquel Dokebi
14610	Escaravelho de Araj
14611	Cota de Malha Sangrenta
14612	Guarda-pernas de Malha Sangrenta
14613	Martelo de Taelan
14614	Cinto de Malha Sangrenta
14615	Manoplas de Malha Sangrenta
14616	Botas de Malha Sangrenta
14617	Camisa do Amputador
14619	Fragmentos de Ossos
14620	Cinturão Ossomorte
14621	Escarpes Ossomorte
14622	Manoplas Ossomorte
14623	Guarda-pernas Ossomorte
14624	Guarda-peito Ossomorte
14625	Símbolo da Honra Perdida
14626	Veste Necrópila
14627	Molde: Camisa Amarela Berrante
14628	Fragmentos de Ossos Imbuídos
14629	Braceletes Necrópilos
14630	Molde: Capucho do Encantador
14631	Botas Necrópilas
14632	Perneiras Necrópilas
14633	Dragonas Necrópilas
14634	Receita: Óleo Gélido
14635	Molde: Cinto de Couro Rematado de Gemas
14636	Cinto Cadavérico
14637	Armadura Cadavérica
14638	Perneiras Cadavéricas
14639	Diagrama: Rebotocador Menor
14640	Luvas Cadavéricas
14641	Chancas Cadavéricas
14644	Molde de Chave-mestra
14645	Chave-mestra Inacabada
14646	Vale-brinde de Vila Norte
14647	Vale-brinde do Vale Cristálgida
14648	Vale-brinde de Umbravale
14649	Vale-brinde do Vale das Provações
14650	Vale-brinde da Aldeia Narache
14651	Vale-brinde de Plangemortis
14652	Faixa Scorpashi
14653	Sapatilhas Scorpashi
14654	Munhequeiras Scorpashi
14655	Peitoral Scorpashi
14656	Capa Scorpashi
14657	Luvas Scorpashi
14658	Casquete Scorpashi
14659	Perneiras Scorpashi
14660	Espaldares Scorpashi
14661	Cordão do Guardião
14662	Cascos do Guardião
14663	Braceletes do Guardião
14664	Armadura do Guardião
14665	Manto do Guardião
14666	Luvas do Guardião
14667	Capacete do Guardião
14668	Bermuda do Guardião
14669	Dragonas do Guardião
14670	Armadura Soberba
14671	Botas Soberbas
14672	Embraces Soberbos
14673	Capa Soberba
14674	Cinturão Soberbo
14675	Luvas Soberbas
14676	Halo Soberbo
14677	Calças Soberbas
14678	Brafoneiras Soberbas
14679	Do Amor e da Família
14680	Colete Indomável
14681	Botas Indomáveis
14682	Guarda-braços Indomáveis
14683	Manto Indomável
14684	Cinto Indomável
14685	Manoplas Indomáveis
14686	Capacete Indomável
14687	Perneiras Indomáveis
14688	Palas Indomáveis
14722	Tornozeleiras Pintadas para a Guerra
14723	Braçadeiras de Pintura de Guerra
14724	Manto de Pintura de Guerra
14725	Cintel de Pintura de Guerra
14726	Luvas de Pintura de Guerra
14727	Guarda-pernas de Pintura de Guerra
14728	Ombreiras de Pintura de Guerra
14729	Escudo de Pintura de Guerra
14730	Peito d'Armas de Pintura de Guerra
14742	Botas Grandiosas
14743	Embraces Grandiosos
14744	Couraça Grandiosa
14745	Manto Grandioso
14746	Cinto Grandioso
14747	Manoplas Grandiosas
14748	Perneiras Grandiosas
14749	Espaldares Grandiosos
14750	Manilhas do Matador
14751	Peitoral do Matador
14752	Capa do Matador
14753	Casquete do Matador
14754	Luvas do Matador
14755	Faixa do Matador
14756	Sapatilhas do Matador
14757	Calças do Matador
14758	Ombreiras do Matador
14759	Braçadeiras Resistentes
14760	Peitoral Resistente
14761	Cinto Resistente
14762	Botas Resistentes
14763	Capa Resistente
14764	Manoplas Resistentes
14765	Diadema Resistente
14766	Calções Resistentes
14767	Brafoneiras Resistentes
14768	Armadura do Assolador
14769	Sandálias do Assolador
14770	Guarda-braços do Assolador
14771	Manto do Assolador
14772	Mitenes do Assolador
14773	Cordão do Assolador
14774	Coroa do Assolador
14775	Bermuda do Assolador
14776	Dragonas do Assolador
14777	Escudo do Assolador
14778	Braceletes do Khan
14779	Peito d'Armas do Khan
14780	Broquel do Khan
14781	Manto do Khan
14782	Luvas do Khan
14783	Cinto do Khan
14784	Grevas do Khan
14785	Capacete do Khan
14786	Guarda-pernas do Khan
14787	Dragonas do Khan
14788	Guarda-braços Protetores
14789	Peitoral Protetor
14790	Broquel Protetor
14791	Capa Protetora
14792	Manoplas Protetoras
14793	Cintel Protetor
14794	Tornozeleiras Protetoras
14795	Elmo Protetor
14796	Guarda-pernas Protetores
14797	Ombreiras Protetoras
14798	Peitoral Sede de Sangue
14799	Botas Sede de Sangue
14800	Broquel Sede de Sangue
14801	Capa Sede de Sangue
14802	Manoplas Sede de Sangue
14803	Cinto Sede de Sangue
14804	Elmo Sede de Sangue
14805	Culotes Sede de Sangue
14806	Palas Sede de Sangue
14807	Braceletes Sede de Sangue
14808	Cinto Guerreador
14809	Escarpes Guerreadores
14810	Pulseiras Guerreadoras
14811	Couraça Guerreadora
14812	Broquel Guerreador
14813	Capa Guerreadora
14814	Coifa Guerreadora
14815	Manoplas Guerreadoras
14816	Guarda-pernas Guerreadores
14817	Ombreiras Guerreadoras
14821	Peitoral Simbólico
14825	Escudo Simbólico
14826	Manoplas Simbólicas
14827	Cinto Simbólico
14828	Grevas Simbólicas
14829	Coxotes Simbólicos
14830	Brafoneiras Simbólicas
14831	Coroa Simbólica
14832	Avambraços Simbólicos
14833	Manoplas do Tirano
14834	Guarda-braços do Tirano
14835	Peito d'Armas do Tirano
14838	Cinto do Tirano
14839	Grevas do Tirano
14840	Coxotes do Tirano
14841	Palas do Tirano
14842	Escudo do Tirano
14843	Elmo do Tirano
14844	Couraça de Helióscamo
14846	Manoplas de Helióscamo
14847	Cinto de Helióscamo
14848	Escarpes de Helióscamo
14849	Capacete de Helióscamo
14850	Coxotes de Helióscamo
14851	Espaldares de Helióscamo
14852	Escudo de Helióscamo
14853	Munhequeiras de Helióscamo
14854	Peitoral de Vanguarda
14855	Manoplas de Vanguarda
14856	Cinturão de Vanguarda
14857	Escarpes de Vanguarda
14858	Diadema de Vanguarda
14859	Coxotes de Vanguarda
14860	Brafoneiras de Vanguarda
14861	Avambraços de Vanguarda
14862	Peitoral do Líder Guerreiro
14863	Manoplas do Líder Guerreiro
14864	Cinto do Líder Guerreiro
14865	Grevas do Líder Guerreiro
14866	Coroa do Líder Guerreiro
14867	Perneiras do Líder Guerreiro
14868	Omoplatas do Líder Guerreiro
14869	Braçadeiras do Líder Guerreiro
14872	Dádiva de Tirion
14894	Raiz de Lírio
14895	Sobretudo Sal-gema
14896	Escarpes Sal-gema
14897	Manoplas Sal-gema
14898	Cinturão Sal-gema
14899	Elmo Sal-gema
14900	Coxotes Sal-gema
14901	Guarda-ombros Sal-gema
14902	Escudo Sal-gema
14903	Pulseiras Sal-gema
14904	Peitoral Brutal
14905	Manoplas Brutais
14906	Cinto Brutal
14907	Capacete Brutal
14908	Guarda-pernas Brutais
14909	Omoplatas Brutais
14910	Guarda-braços Brutais
14911	Botas Brutais
14912	Escudo Brutal
14913	Grevas Jade
14914	Braçadeiras Jade
14915	Peitoral Jade
14916	Defletor Jade
14917	Manoplas Jade
14918	Cinto Jade
14919	Diadema Jade
14920	Coxotes Jade
14921	Palas Jade
14922	Escarpes Soberbos
14923	Guarda-braços Soberbos
14924	Peitoral Soberbo
14925	Elmo Soberbo
14926	Manoplas Soberbas
14927	Cinto Soberbo
14928	Guarda-pernas Soberbas
14929	Guarda-ombros Soberbos
14930	Escudo Soberbo
14931	Armadura Heroica
14932	Grevas Heroicas
14933	Manoplas Heroicas
14934	Cinturão Heroico
14935	Elmo Heroico
14936	Coxotes Heroicos
14937	Brafoneiras Heroicas
14938	Braçadeiras Heroicas
14939	Couraça do Armipotente
14940	Escarpes do Armipotente
14941	Pulseiras do Armipotente
14942	Manoplas do Armipotente
14943	Cinto do Armipotente
14944	Coroa do Armipotente
14945	Guarda-pernas do Armipotente
14946	Espaldares do Armipotente
14947	Escudo do Armipotente
14948	Peito d'Armas Forjado em Sangue
14949	Manoplas Forjadas em Sangue
14950	Cinto Forjado em Sangue
14951	Escarpes Forjados em Sangue
14952	Capacete Forjado em Sangue
14953	Coxotes Forjados em Sangue
14954	Escudo Forjado em Sangue
14955	Proteção de Ombros Forjada em Sangue
14956	Braceletes Forjados em Sangue
14957	Escarpes do Chefe Supremo
14958	Armadura do Chefe Supremo
14959	Manoplas do Chefe Supremo
14960	Cinto do Chefe Supremo
14961	Coroa do Chefe Supremo
14962	Guarda-pernas do Chefe Supremo
14963	Brafoneiras do Chefe Supremo
14964	Escudo do Chefe Supremo
14965	Braçadeiras do Chefe Supremo
14966	Peitoral Glorioso
14967	Manoplas Gloriosas
14968	Cinto Glorioso
14969	Diadema Glorioso
14970	Coxotes Gloriosos
14971	Espaldares Gloriosos
14972	Escarpes Gloriosos
14973	Escudo Glorioso
14974	Braceletes Gloriosos
14975	Arnês Exaltado
14976	Manoplas Exaltadas
14977	Cinturão Exaltado
14978	Escarpes Exaltados
14979	Capacete Exaltado
14980	Coxotes Exaltados
14981	Palas Exaltadas
14982	Escudo Exaltado
14983	Pulseiras Exaltadas
15002	Pique de Nimboya
15003	Cinto Primevo
15004	Botas Primevas
15005	Embraces Primevos
15006	Broquel Primevo
15007	Capa Primeva
15008	Luvas Primevas
15009	Perneiras Primevas
15010	Veste Primeva
15011	Cordão Lupino
15012	Sapatilhas Lupinas
15013	Manilhas Lupinas
15014	Broquel Lupino
15015	Manto Lupino
15016	Mitenes Lupinas
15017	Perneiras Lupinas
15018	Colete Lupino
15019	Dragonas Lupinas
15042	Jarra de Cupins Vazia
15043	Cupins das Terras Pestilentas
15044	Barril de Cupins das Terras Pestilentas
15045	Peitoral de Escama de Dragão Verde
15046	Perneiras de Escama de Dragão Verde
15047	Peitoral de Escama de Dragão Vermelho
15048	Peitoral de Escama de Dragão Azul
15049	Omoplatas de Escama de Dragão Azul
15050	Peitoral de Escama de Dragão Negro
15051	Omoplatas de Escama de Dragão Negro
15052	Perneiras de Escama de Dragão Negro
15053	Peitoral Vulcânico
15054	Perneiras Vulcânicas
15055	Omoplatas Vulcânicas
15056	Armadura do Véu da Tempestade
15057	Calças do Véu da Tempestade
15058	Omoplatas do Véu da Tempestade
15059	Peitoral Vivo
15060	Perneiras Vivas
15061	Omoplatas Vivas
15062	Perneiras de Demossauro
15063	Manoplas de Demossauro
15064	Arnês de Urso de Guerra
15065	Bermuda de Urso de Guerra
15066	Peitoral de Penaférrea
15067	Omoplatas de Penaférrea
15068	Túnica Sabre-de-gelo
15069	Perneiras Sabre-de-gelo
15070	Luvas Sabre-de-gelo
15071	Botas Sabre-de-gelo
15072	Perneiras Quiméricas
15073	Botas Quiméricas
15074	Luvas Quiméricas
15075	Colete Quimérico
15076	Colete Escorpídeo Pesado
15077	Braçadeiras Escorpídeas Pesadas
15078	Manopla Escorpídea Pesada
15079	Perneiras Escorpídeas Pesadas
15080	Elmo Escorpídeo Pesado
15081	Omoplatas Escorpídeas Pesadas
15082	Cinto Escorpídeo Pesado
15083	Manoplas de Couro Maléfico
15084	Braçadeiras de Couro Maléfico
15085	Armadura de Couro Maléfico
15086	Bandana de Couro Maléfico
15087	Calças de Couro Maléfico
15088	Cinto de Couro Maléfico
15090	Armadura de Couro Rúnico
15091	Manoplas de Couro Rúnico
15092	Braçadeiras de Couro Rúnico
15093	Cinto de Couro Rúnico
15094	Bandana de Couro Rúnico
15095	Calças de Couro Rúnico
15096	Omoplatas de Couro Rúnico
15102	Amostra de Un'Goro Testada
15103	Amostra Testada Corrompida
15104	Botas Áleas
15105	Cajado de Noh'Orathil
15106	Cajado de Dar'Orathil
15107	Orbe de Nor'Orahil
15108	Orbe de Dar'Orathil
15109	Cajado de Soran'ruk
15110	Cinto Rígido
15111	Mocassins Rígidos
15112	Braceletes Rígidos
15113	Broquel Rígido
15114	Capa Rígida
15115	Luvas Rígidas
15116	Omoplatas Rígidas
15117	Perneiras Rígidas
15118	Túnica Rígida
15119	Calças Altaneiras
15120	Cinturão Robusto
15121	Botas Robustas
15122	Braçadeiras Robustas
15123	Broquel Robusto
15124	Manto Robusto
15125	Luvas Robustas
15126	Perneiras Robustas
15127	Omoplatas Robustas
15128	Túnica Robusta
15129	Elmo Robusto
15130	Colete do Degolador
15131	Botas do Degolador
15132	Guarda-braços do Degolador
15133	Broquel do Degolador
15134	Capacete do Degolador
15135	Capa do Degolador
15136	Cinto do Degolador
15137	Luvas do Degolador
15138	Manto de Escama da Onyxia
15139	Calças do Degolador
15140	Dragonas do Degolador
15141	Peitoral de Escama da Onyxia
15142	Botas do Andarilho Fantasma
15143	Braçadeiras do Andarilho Fantasma
15144	Trapos do Andarilho Fantasma
15145	Broquel do Andarilho Fantasma
15146	Coroa do Andarilho Fantasma
15147	Manto do Andarilho Fantasma
15148	Cinto do Andarilho Fantasma
15149	Luvas do Andarilho Fantasma
15150	Ombreiras do Andarilho Fantasma
15151	Guarda-pernas do Andarilho Fantasma
15152	Sapatos Noturnos
15153	Manto Noturno
15154	Faixa Noturna
15155	Luvas Noturnas
15156	Chapéu Noturno
15157	Perneiras Noturnas
15158	Ombreiras Noturnas
15159	Túnica Noturna
15160	Munhequeiras Noturnas
15161	Cinto Imponente
15162	Botas Imponentes
15163	Braçadeiras Imponentes
15164	Colete Imponente
15165	Capa Imponente
15166	Luvas Imponentes
15167	Bandana Imponente
15168	Calças Imponentes
15169	Omoplatas Imponentes
15170	Armadura Potente
15171	Botas Potentes
15172	Embraces Potentes
15173	Capa Potente
15174	Luvas Potentes
15175	Capacete Potente
15176	Calças Potentes
15177	Omoplatas Potentes
15178	Cinto Potente
15179	Armadura Acolchoada Pretoriana
15180	Cinturão Pretoriano
15181	Botas Pretorianas
15182	Munhequeiras Pretorianas
15183	Manto Pretoriano
15184	Luvas Pretorianas
15185	Coifa Pretoriana
15186	Perneiras Pretorianas
15187	Brafoneiras Pretorianas
15188	Guarda-braços Vultosos
15189	Botas Vultosas
15190	Manto Vultoso
15191	Cinto Vultoso
15192	Manoplas Vultosas
15193	Capacete Vultoso
15194	Guarda-pernas Vultosos
15195	Peitoral Vultoso
15196	Tabardo do Recruta
15197	Tabardo do Batedor
15198	Cores do Cavaleiro
15199	Arauto do Guarda Pétreo
15200	Insígnia do Primeiro-sargento
15202	Perneiras do Guardião Selvagem
15203	Guarda-pernas da Rajada Tempestiva
15204	Varinha de Pedra-da-lua
15205	Rifle de Visão de Coruja
15206	Bastão Dedo-de-jade
15207	Escudo Folheaço
15208	Poeira de Lua Cenariana
15209	Saco de Relíquias
15210	Espada Curta do Saqueador
15211	Espada Curta Militante
15212	Espada Larga do Lutador
15213	Lâmina Mercenária
15214	Espada dos Nobres
15215	Alfanje Furioso
15216	Espada Rúnica
15217	Lâmina da Viúva
15218	Espada de Cristal
15219	Lâmina Dimensional
15220	Sabre Tombatalha
15221	Espada da Sagrada Batalha
15222	Maça Espigada
15223	Estrela Entalhada
15224	Esmagalutas
15225	Martelo de Sequoia
15226	Clava Gigante
15227	Maça com Pontas de Diamante
15228	Esmagamassa
15229	Martelo Ventobento
15230	Cutelo Arpado
15231	Machadinha Rachante
15232	Cutelo Decepante
15233	Machado Selvagem
15234	Machado Grandioso
15235	Fio Crescente
15236	Cutelo da Lua
15237	Cata-cadáver
15238	Machado do Senhor da Guerra
15239	Aniquilador Pedravil
15240	Garra do Demônio
15241	Faca de Batalha
15242	Estilete Amolado
15243	Cris Mortal
15244	Laminavalha
15245	Adaga Vorpal
15246	Lâmina do Demônio
15247	Adaga Sangrataca
15248	Espadão Rebrilhante
15249	Bihänder Polida
15250	Flamberge Luminoso
15251	Espada Atacabeças
15252	Espada Colmilhã
15253	Lâmina Decapitante
15254	Espadão Sombrio
15255	Flamberge Pomposa
15256	Espada de Massacre
15257	Lâmina Shin
15258	Lâmina de Guerra Divina
15259	Martelo de Batalha Robusto
15260	Martelo de Pedra
15261	Galho de Sequoia
15262	Malho Grandioso
15263	Marreta Real
15264	Quebradorso
15265	Traztormento
15266	Malhador Tenaz
15267	Brutomalho
15268	Machado de Fio Duplo
15269	Machado de Batalha Maciço
15270	Machado de Guerra Gigante
15271	Machado Grande Colossal
15272	Barbeador de Macho
15273	Golpe da Morte
15274	Cajado Longo do Vidente
15275	Cajado do Taumaturgo
15276	Cajado Longo do Mago
15277	Kodo Cinza
15278	Cajado do Solstício
15279	Varinha de Marfim
15280	Mão do Teurgo
15281	Bastão Lumestela
15282	Dedo de Dragão
15283	Varinha Lunar
15284	Arco Longo de Batalha
15285	Arco Longo do Arqueiro
15286	Arco Longo de Sequoia
15287	Arco do Cruzado
15288	Arco Estalaste
15289	Arco Arcataque
15290	Kodo Marrom
15291	Agulhante da Harpia
15292	Kodo Verde
15293	Kodo Ardósia
15294	Arco de Cerco
15295	Arco Calamígneo
15296	Arco do Olho de Falcão
15297	Braçadeiras Pardas
15298	Broquel Pardo
15299	Capa Parda
15300	Luvas Pardas
15301	Sapatilhas Pardas
15302	Cinto Pardo
15303	Calças Pardas
15304	Gibão Pardo
15305	Sapatos Ferais
15306	Braceletes Ferais
15307	Broquel Feral
15308	Cordão Feral
15309	Manto Feral
15310	Luvas Ferais
15311	Arnês Feral
15312	Perneiras Ferais
15313	Ombreiras Ferais
15314	Coleção de Relíquias
15322	Espingarda de Cano Liso
15323	Espingarda de Percussão
15324	Rifle Ardelado
15325	Arcabuz do Atirador de Elite
15326	Machado de Arremesso Rebrilhante
15327	Adaga de Arremesso Maléfica
15328	Chave de Josefo
15329	Cinto do Boiadeiro
15330	Botas do Boiadeiro
15331	Munhequeiras do Boiadeiro
15332	Broquel do Boiadeiro
15333	Manto do Boiadeiro
15334	Luvas do Boiadeiro
15335	Espadim de Aço-torga
15336	Perneiras do Boiadeiro
15337	Colete do Boiadeiro
15338	Dragonas do Boiadeiro
15339	Casquete Desbravador
15340	Manto Desbravador
15341	Pisantes Desbravadores
15342	Protetor Desbravador
15343	Luvas Desbravadoras
15344	Calças Desbravadoras
15345	Ombreiras Desbravadoras
15346	Colete Desbravador
15347	Cinto Desbravador
15348	Braçadeiras Desbravadoras
15349	Cinto do Caçador de Cabeças
15350	Sapatilhas do Caçador de Cabeças
15351	Embraces do Caçador de Cabeças
15352	Broquel do Caçador de Cabeças
15353	Touca do Caçador de Cabeças
15354	Manto do Caçador de Cabeças
15355	Luvas do Caçador de Cabeças
15356	Armadura do Caçador de Cabeças
15357	Espaldares do Caçador de Cabeças
15358	Bermuda do Caçador de Cabeças
15359	Colete do Trapaceiro
15360	Braçadeiras do Trapaceiro
15361	Faixa do Trapaceiro
15362	Botas do Trapaceiro
15363	Cocar do Trapaceiro
15364	Manto do Trapaceiro
15365	Mitenes do Trapaceiro
15366	Perneiras do Trapaceiro
15367	Protetor do Trapaceiro
15368	Brafoneiras do Trapaceiro
15369	Cinto do Cavalga-lobo
15370	Botas do Cavalga-lobo
15371	Manto do Cavalga-lobo
15372	Luvas do Cavalga-lobo
15373	Cocar do Cavalga-lobo
15374	Perneiras do Cavalga-lobo
15375	Ombreiras do Cavalga-lobo
15376	Armadura Acolchoada do Cavalga-lobo
15377	Munhequeiras do Cavalga-lobo
15378	Cinto Patafúria
15379	Botas Patafúria
15380	Braçadeiras Patafúria
15381	Couraça Patafúria
15382	Manto Patafúria
15383	Luvas Patafúria
15384	Cocar Patafúria
15385	Perneiras Patafúria
15386	Guarda-ombros Patafúria
15387	Braceletes Flamejade
15388	Cinto Flamejade
15389	Escarpes Flamejade
15390	Couraça Flamejade
15391	Casquete Flamejade
15392	Manto Flamejade
15393	Luvas Flamejade
15394	Calças Flamejade
15395	Palas Flamejade
15396	Adaga de Madeira Curva
15397	Cajado de Tordo do Carvalho
15398	Botas do Rastelo de Areia
15399	Cinto de Erva Seca
15400	Braçadeiras de Conchas
15401	Luvas Mina d'Água
15402	Manoplas da Pegada Nodosa
15403	Braçadeiras da Costa Escarpada
15404	Cinturão Rompe-água
15405	Luvas de Debulha
15406	Botas Crustáceas
15407	Pelego Rústico Curado
15408	Escama Pesada de Escorpídeo
15409	Sal Rochafunda Refinado
15410	Escama da Onyxia
15411	Marca de Fordring
15412	Escama de Dragão Verde
15413	Peitoral Ornado de Adamântio
15414	Escama de Dragão Vermelho
15415	Escama de Dragão Azul
15416	Escama de Dragão Negro
15417	Couro de Demossauro
15418	Martelo de Guerra de Platina Cintilante
15419	Couro de Urso de Guerra
15420	Penaférrea
15421	Mortalha dos Exilados
15422	Couro Pedra Sabre
15423	Couro de Quimera
15424	Machado de Orgrimmar
15425	Braçadeiras Inigualáveis
15426	Botas Inigualáveis
15427	Manto Inigualável
15428	Cinto Inigualável
15429	Luvas Inigualáveis
15430	Bandana Inigualável
15431	Perneiras Inigualáveis
15432	Omoplatas Inigualáveis
15433	Armadura Inigualável
15434	Faixa Suprema
15435	Sapatos Supremos
15436	Braçadeiras Supremas
15437	Capa Suprema
15438	Luvas Supremas
15439	Coroa Suprema
15440	Perneiras Supremas
15441	Omoplatas Supremas
15442	Peitoral Supremo
15443	Cris de Orgrimmar
15444	Cajado de Orgrimmar
15445	Martelo de Orgrimmar
15446	Kit de Subdelegado de Ventobravo
15447	Putrefação Viva
15448	Putrefação Coagulada
15449	Calças Medonhas
15450	Perneiras Dragalodo
15451	Perneiras da Gárgula
15452	Braçadeiras Enfeitadas de Penas
15453	Braçadeiras da Savana
15454	Almofariz e Pilão
15455	Vestes Quedapó
15456	Perneiras Pé Ligeiro
15457	Omoplatas do Deserto
15458	Botas Túndricas
15459	Munhequeiras Sinisdobre
15461	Botas Saltoleve
15462	Braçadeiras Argilofloco
15463	Luvas do Andarilho Pálido
15464	Martelo Bruto
15465	Varinha Ferroada
15466	Escudo do Tinido
15467	Anel da Liga do Inventor
15468	Clâmide Cantéolo
15469	Cilha Cantéolo
15470	Perneiras do Guarda das Planícies
15471	Armadura Couroforte
15472	Cinto do Corcel
15473	Botas do Corcel
15474	Braçadeiras do Corcel
15475	Manto do Corcel
15476	Mitenes do Corcel
15477	Calças do Corcel
15478	Escudo do Corcel
15479	Armadura do Corcel
15480	Cinturão Rasgado em Combate
15481	Grevas Rasgadas em Combate
15482	Embraces Rasgados em Combate
15483	Capa Rasgada em Combate
15484	Luvas Rasgadas em Combate
15485	Calças Rasgadas em Combate
15486	Escudo Rasgado em Combate
15487	Túnica Rasgada em Combate
15488	Sobretudo Salpicado de Sangue
15489	Escarpes Salpicados de Sangue
15490	Manto Salpicado de Sangue
15491	Luvas Salpicadas de Sangue
15492	Faixa Salpicada de Sangue
15493	Tanga Salpicada de Sangue
15494	Escudo Salpicado de Sangue
15495	Munhequeiras Salpicadas de Sangue
15496	Ombreiras Salpicadas de Sangue
15497	Cordão do Vanguardeiro
15498	Sapatilhas do Vanguardeiro
15499	Manilhas do Vanguardeiro
15500	Couraça do Vanguardeiro
15501	Manto do Vanguardeiro
15502	Luvas do Vanguardeiro
15503	Guarda-pernas do Vanguardeiro
15504	Escudo do Vanguardeiro
15505	Brafoneiras do Vanguardeiro
15506	Tornozeleiras do Bruto
15507	Braçadeiras do Bruto
15508	Capa do Bruto
15509	Mitenes do Bruto
15510	Cinto do Bruto
15511	Guarda-pernas do Bruto
15512	Escudo do Bruto
15513	Brafoneiras do Bruto
15514	Peito d'Armas do Bruto
15515	Cinto de Malha Farpada
15516	Sapatilhas de Malha Farpada
15517	Munhequeiras de Malha Farpada
15518	Peitoral de Malha Farpada
15519	Manto de Malha Farpada
15520	Manoplas de Malha Farpada
15521	Perneiras de Malha Farpada
15522	Escudo de Malha Farpada
15523	Espaldares de Malha Farpada
15524	Sobretudo da Sentinela
15525	Sapatilhas da Sentinela
15526	Capa da Sentinela
15527	Luvas da Sentinela
15528	Faixa da Sentinela
15529	Perneiras da Sentinela
15530	Escudo da Sentinela
15531	Guarda-ombros da Sentinela
15532	Pulseiras da Sentinela
15533	Diadema da Sentinela
15534	Botas de Malha Perversas
15535	Braçadeiras Encadeadas Perversas
15536	Peito d'Armas Encadeado Perverso
15537	Manto Encadeado Perverso
15538	Manoplas Encadeadas Perversas
15539	Cintel Encadeado Perverso
15540	Capacete Encadeado Perverso
15541	Guarda-pernas Encadeadas Perversas
15542	Ombreiras Encadeadas Perversas
15543	Escudo Encadeado Perverso
15544	Escarpes de Escama Grossos
15545	Braceletes de Escama Grossos
15546	Peitoral de Escama Grosso
15547	Manto de Escama Grosso
15548	Manoplas de Escama Grossas
15549	Cinto de Escama Grosso
15550	Coroa de Escama Grossa
15551	Guarda-pernas de Escama Grossos
15552	Escudo de Escama Grosso
15553	Espaldares de Escamas Grossas
15554	Cinturão do Rapinante
15555	Botas do Rapinante
15556	Braçadeiras do Rapinante
15557	Couraça do Rapinante
15558	Coroa do Rapinante
15559	Manto do Rapinante
15560	Luvas do Rapinante
15561	Perneiras do Rapinante
15562	Brafoneiras do Rapinante
15563	Escudo do Rapinante
15564	Kit de Armadura Rústica
15565	Botas do Espoliador
15566	Braçadeiras do Espoliador
15567	Túnica do Espoliador
15568	Manto do Espoliador
15569	Escudo do Espoliador
15570	Manoplas do Espoliador
15571	Cinto do Espoliador
15572	Diadema do Espoliador
15573	Perneiras do Espoliador
15574	Ombreiras do Espoliador
15575	Cinto Conchalume
15576	Escarpes Conchalume
15577	Braçadeiras Conchalume
15578	Peitoral Conchalume
15579	Manto Conchalume
15580	Capuz Conchalume
15581	Manoplas Conchalume
15582	Guarda-pernas Conchalume
15583	Ombreiras Conchalume
15584	Escudo Conchalume
15585	Guantes Imorais
15586	Flor de Crescimento Rápido
15587	Cinturão do Marsupial
15588	Cinto de Aço Reforçado
15589	Pisoteadores Constantes
15590	Braceletes Constantes
15591	Peitoral Constante
15592	Broquel Constante
15593	Diadema Constante
15594	Manto Constante
15595	Luvas Constantes
15596	Coxotes Constantes
15597	Omoplatas Constantes
15598	Cinturão Constante
15599	Grevas Antigas
15600	Avambraços Antigos
15601	Peito d'Armas Antigo
15602	Coroa Antiga
15603	Manto Antigo
15604	Defensor Antigo
15605	Manoplas Antigas
15606	Cinto Antigo
15607	Guarda-pernas Antigos
15608	Brafoneiras Antigas
15609	Armadura de Osteocota
15610	Braçadeiras de Osteocota
15611	Capa de Osteocota
15612	Manoplas de Osteocota
15613	Cinto de Osteocota
15614	Escarpes de Osteocota
15615	Capacete de Osteocota
15616	Coxotes de Osteocota
15617	Palas de Osteocota
15618	Muralha de Proteção de Osteocota
15619	Cinto Grífico de Malha
15620	Braceletes Gríficos de Malha
15621	Broquel Grífico de Malha
15622	Peitoral Grífico de Malha
15623	Coroa Grífica de Malha
15624	Manto Grífico
15625	Manoplas Gríficas de Malha
15626	Grevas Gríficas de Malha
15627	Guarda-pernas Gríficos de Malha
15628	Brafoneiras Gríficas de Malha
15629	Braçadeiras Formidáveis
15630	Escarpes Formidáveis
15631	Peito d'Armas Formidável
15632	Capa Formidável
15633	Escudo Formidável
15634	Diadema Formidável
15635	Manoplas Formidáveis
15636	Cinto Formidável
15637	Guarda-pernas Formidáveis
15638	Espaldares Formidáveis
15639	Braçadeiras Couroférreas
15640	Peitoral Couroférreo
15641	Cinto Couroférreo
15642	Grevas Couroférreas
15643	Manto Couroférreo
15644	Manoplas Couroférreas
15645	Capacete Couroférreo
15646	Guarda-pernas Couroférreo
15647	Brafoneiras Couroférreas
15648	Escudo Couroférreo
15649	Braçadeiras Impiedosas
15650	Sobretudo Impiedoso
15651	Coroa Impiedosa
15652	Manto Impiedoso
15653	Manoplas Impiedosas
15654	Cinto Impiedoso
15655	Guarda-pernas Impiedosos
15656	Palas Impiedosas
15657	Escudo Impiedoso
15658	Escarpes Impenetráveis
15659	Braceletes Impenetráveis
15660	Peitoral Impenetrável
15661	Manto Impenetrável
15662	Manoplas Impenetráveis
15663	Cinto Impenetrável
15664	Capacete Impenetrável
15665	Guarda-pernas Impenetráveis
15666	Brafoneiras Impenetráveis
15667	Muro Impenetrável
15668	Braçadeiras Magníficas
15669	Peitoral Magnífico
15670	Capacete Magnífico
15671	Manto Magnífico
15672	Manoplas Magníficas
15673	Cinto Magnífico
15674	Grevas Magníficas
15675	Protetor Magnífico
15676	Perneiras Magníficas
15677	Omoplatas Magníficas
15678	Escarpes Triunfantes
15679	Braçadeiras Triunfantes
15680	Peito d'Armas Triunfante
15681	Manto Triunfante
15682	Manoplas Triunfantes
15683	Cinturão Triunfante
15684	Elmo Triunfante
15685	Coxotes Triunfantes
15686	Ombreiras Triunfantes
15687	Escudo Triunfante
15688	Feijões Mágicos
15689	Anel do Mercador
15690	Colar de Osso de Kodo
15691	Arcabuz do Artilheiro de Flanco
15692	Ferrete de Kodos
15693	Omoplatas Vultosas
15694	Grevas Impiedosas
15695	Escudo Anelar Rebitado
15696	Livro Estragado
15697	Botas do Ladrão de Kodo
15698	Espaldares Contendores
15699	Embrulho Pardo Pequeno
15702	Anel do Químico
15703	Guarda-pó do Químico
15704	Medalha da Insígnia do Caçador
15705	Lâmina Insígnia da Maré
15706	Lâmina Rastreadora de Caça
15707	Faixa Lenhabram
15708	Luvas de Couro Empesteadas
15709	Cinturão Forjadentada
15710	Pó Lunar Cenariano
15722	Cantil da Espraga
15723	Chá com Açúcar
15724	Molde: Braçadeiras Escorpídeas Pesadas
15725	Molde: Manoplas de Couro Maléfico
15726	Molde: Peitoral de Escama de Dragão Verde
15727	Molde: Colete Escorpídeo Pesado
15728	Molde: Braçadeiras de Couro Maléfico
15729	Molde: Luvas Quiméricas
15730	Molde: Peitoral de Escama de Dragão Vermelho
15731	Molde: Manoplas de Couro Rúnico
15732	Molde: Perneiras Vulcânicas
15733	Molde: Perneiras de Escama de Dragão Verde
15734	Molde: Omoplatas Vivas
15735	Molde: Omoplatas de Penaférrea
15736	Composto Químico Especial do Fumaça
15737	Molde: Botas Quiméricas
15738	Molde: Manoplas Escorpídeas Pesadas
15739	Molde: Braçadeiras de Couro Rúnico
15740	Molde: Botas Sabre-de-gelo
15741	Molde: Calças do Véu da Tempestade
15742	Molde: Arnês de Urso de Guerra
15743	Molde: Cinto Escorpídeo Pesado
15744	Molde: Bandana de Couro Maléfico
15745	Molde: Cinto de Couro Rúnico
15746	Molde: Perneiras Quiméricas
15747	Molde: Perneiras Sabre-de-gelo
15748	Molde: Perneiras Escorpídeas Pesadas
15749	Molde: Peitoral Vulcânico
15750	O Cetro de Luz
15751	Molde: Peitoral de Escama de Dragão Azul
15752	Molde: Perneiras Vivas
15753	Molde: Armadura do Véu da Tempestade
15754	Molde: Bermuda de Urso de Guerra
15755	Molde: Colete Quimérico
15756	Molde: Bandana de Couro Rúnico
15757	Molde: Calças de Couro Maléfico
15758	Molde: Manoplas de Demossauro
15759	Molde: Peitoral de Escama de Dragão Negro
15760	Molde: Peitoral de Penaférrea
15761	Molde: Luvas Sabre-de-gelo
15762	Molde: Elmo Escorpídeo Pesado
15763	Molde: Omoplatas de Escama de Dragão Azul
15764	Molde: Omoplatas do Véu da Tempestade
15765	Molde: Calças de Couro Rúnico
15766	Gema da Serpente
15767	Chave de Hameya
15768	Molde: Cinto de Couro Maléfico
15769	Molde: Manto de Escama da Onyxia
15770	Molde: Omoplatas de Escama de Dragão Negro
15771	Molde: Peitoral Vivo
15772	Molde: Perneiras de Demossauro
15773	Molde: Armadura de Couro Maléfico
15774	Molde: Omoplatas Escorpídeas Pesadas
15775	Molde: Omoplatas Vulcânicas
15776	Molde: Armadura de Couro Rúnico
15777	Molde: Omoplatas de Couro Rúnico
15778	Yeti Mecânico
15779	Molde: Túnica Sabre-de-gelo
15780	Molde: Peitoral de Escama da Onyxia
15781	Molde: Perneiras de Escama de Dragão Negro
15782	Lâmina do Espreitador de Feras
15783	Adaga do Caçador de Feras
15784	Dragonas da Brisa Cristalina
15785	Cabeça de Zaeldarr
15786	Gibão Pulso da Samambaia
15787	Cota de Tira de Salgueiro
15788	Relatório de Visteterna
15789	Manto do Rio Profundo
15790	Estudos sobre Comunicação com Espíritos
15791	Faixa Turquesa
15792	Espaldares de Madeira de Arado
15793	Um Osso Roído
15794	Tanga Rasgada de Ogro
15795	Manoplas da Névoa Esmeralda
15796	Braçadeiras Espuma-marinha
15797	Braçadeiras Rutilantes
15798	Dentes Lascados de Ogro
15799	Medalha da Comenda Heroica
15800	Espada Curta Intrépida
15801	Espada Curta Valente
15802	Botas de Lunatrama
15803	Livro dos Anciãos
15804	Clâmide de Cerise
15805	Rosa de Penélope
15806	Canção de Mirah
15807	Besta Leve
15808	Besta Leve de Qualidade
15809	Balestra
15810	Lança Curta
15811	Lança Pesada
15812	Sobreveste Orquídea
15813	Cinto de Elos de Ouro
15814	Espada de Hameya
15815	Manto de Hameya
15822	Espaldares de Couro Sombrio
15823	Manopla Tijolaço
15824	Vestes de Astória
15825	Gibão do Caçador
15826	Bálsamo Curativo para Animais
15827	Peitoral Escamajade
15842	Amostra Vazia do Morro de Brumedo
15843	Amostra Cheia do Morro de Brumedo
15844	Amostra Vazia das Quedas de Fontescarpa
15845	Amostra Cheia das Quedas de Fontescarpa
15846	Refinador de Sal
15847	Arquivos de Quel'Thalas
15848	Caixote de Ímãs Fantasmais
15849	Fantasmoplasma
15850	Tufo de Pele de Quiroscuro
15851	Fungo Lunar
15852	Chifre de Kodo
15853	Ceifavento
15854	Estilhaço Dançante
15855	Anel de Proteção
15856	Talismã Curvaluz
15857	Rebento Arruinamago
15858	Luvas Livrevento
15859	Cinturão do Postilhão
15860	Guarda-braços Infligidores
15861	Botinas de Sete Léguas
15862	Cutelo de Assalto
15863	Cetro Solene
15864	Braceletes do Condor
15865	Broquel Ancorote
15866	Bornal Medicinal de Povelo
15867	Talismã Prismático
15868	Ordens do Grão-cruzado
15869	Chave-mestra de Prata
15870	Chave-mestra Dourada
15871	Chave-mestra de Veraprata
15872	Chave-mestra de Arcanita
15873	Caneca Interminável do João Roto
15874	Marisco de Casca Mole
15875	Maçã Podre
15876	Baú de Nathanos
15877	Adorno de Altar
15878	Chave Prateada de Rodovalho
15879	Garra do Suserano Ror
15880	Cabeça de Ramstein, o Devorador
15881	Chave Dourada de Rodovalho
15882	Meio-pingente da Resistência Aquática
15883	Meio-pingente da Agilidade Aquática
15884	Livro-caixa do Augustus
15885	Pingente do Leão Marinho
15886	Filactério do Timolain
15887	Protetor Heroico
15890	Escudo de Vanguarda
15891	Escudo Grandioso
15892	Escudo do Matador
15893	Broquel do Prospector
15894	Broquel Felpado
15895	Broquel Queimado
15902	Caixa-surpresa do Augustus
15903	Garra de Destro
15904	Lâminas de Destro
15905	Soqueira de Destro
15906	Soqueira de Canhoto
15907	Garra de Canhoto
15908	Bastão de Adestramento
15909	Lâminas de Canhoto
15911	Bastão de Adestramento
15912	Orbe do Bucaneiro
15913	Bastão de Adestramento
15914	Bastão de Adestramento
15915	Bastão de Adestramento
15916	Bastão de Adestramento
15917	Bastão de Adestramento
15918	Esfera do Conjurador
15919	Bastão de Adestramento
15920	Bastão de Adestramento
15921	Bastão de Adestramento
15922	Bastão de Adestramento
15923	Bastão de Adestramento
15924	Carne de Marisco de Casca Mole
15925	Báculo do Profissional
15926	Orbe Mesmerizador
15927	Esfera Brilhante
15928	Bastão de Fio de Prata
15929	Orbe do Céu Noturno
15930	Cetro Imperial Vermelho
15931	Estrela Arcana
15932	Caneco do Discípulo
15933	Ramo Simples
15934	Báculo do Sábio
15935	Bastão Durável
15936	Ramo do Anoitecer
15937	Esfera Hibernal
15938	Orbe Místico
15939	Cetro do Conselheiro
15940	Cetro Elegante
15941	Cetro do Alto-conselheiro
15942	Bastão do Mestre
15943	Escudo Imbuído
15944	Orbe Ancestral
15945	Báculo Rúnico
15946	Esfera do Místico
15947	Estrela Sanguínea
15962	Bastão do Sátiro
15963	Galho de Panopétreo
15964	Estrela Sedareia
15965	Orbe Seguevento
15966	Orbe Venomortalha
15967	Estrela Altaneira
15968	Esfera Elunária
15969	Orbe Enfeitado
15970	Galho Nativo
15971	Bastão Aborígene
15972	Caneco Ritual
15973	Estrela do Atalaia
15974	Bastão Pagão
15975	Cetro Clamachuva
15976	Galho Pelocardo
15977	Orbe Vital
15978	Bastão do Geomante
15979	Báculo de Seribrasa
15980	Orbe Névoa Negra
15981	Esfera Lunar
15982	Bastão Tecido em Sangue
15983	Cetro de Gaia
15984	Cetro Opulento
15985	Vara Aracnoide
15986	Estrela do Osteurgo
15987	Orbe Astral
15988	Orbe Resplandecente
15989	Bastão Eterno
15990	Escudo Resistente
15991	Escudo do Líder Guerreiro
15992	Pó Explosivo Denso
15993	Granada de Tório
15994	Treco de Tório
15995	Rifle de Tório
15996	Sapo Mecânico Realista
15997	Cartuchos de Tório
15998	Bilhete do Ludovico
15999	Óculos de Poder Mágico Xtremo Plus
16000	Tubo de Tório
16001	Insígnia SI:7 (Fredo)
16002	Insígnia SI:7 (Turyen)
16003	Insígnia SI:7 (Rutger)
16004	Rifle de Ferro Negro
16005	Bomba de Ferro Negro
16006	Conversor Delicado de Arcanita
16007	Rifle Impecável de Arcanita
16008	Óculos do Mestre Engenheiro
16009	Modulador de Amplificação de Voz
16022	Dragonete de Arcanita
16023	Boneco-alvo Magistral
16026	PVP Plate Helm Alliance
16027	PVP Plate Breastplate Alliance
16028	PVP Plate Legplates Alliance
16029	PVP Plate Gauntlets Alliance
16030	PVP Plate Boots Alliance
16031	PVP Plate Shoulder Alliance
16033	PVP Plate Wrist Alliance
16034	PVP Plate Cloak Alliance
16035	PVP Cloth Helm Horde
16036	PVP Cloth Robe Horde
16037	PVP Cloth Legs Horde
16038	PVP Cloth Shoulder Horde
16039	Espada Cantante Ta'Kierthan
16040	Bomba Arcana
16041	Diagrama: Granada de Tório
16042	Diagrama: Treco de Tório
16043	Diagrama: Rifle de Tório
16044	Diagrama: Sapo Mecânico Realista
16045	Diagrama: Óculos de Poder Mágico Xtremo Plus
16046	Diagrama: Boneco-alvo Magistral
16047	Diagrama: Tubo de Tório
16048	Diagrama: Rifle de Ferro Negro
16049	Diagrama: Bomba de Ferro Negro
16050	Diagrama: Conversor Delicado de Arcanita
16051	Diagrama: Cartuchos de Tório
16052	Diagrama: Modulador de Amplificação de Voz
16053	Diagrama: Óculos do Mestre Engenheiro
16054	Diagrama: Dragonete de Arcanita
16055	Diagrama: Bomba Arcana
16056	Diagrama: Rifle Impecável de Arcanita
16057	Mochila do Explorador
16058	Selo de Fordring
16059	Camisa Marrom Comum
16060	Camisa Branca Comum
16072	Livro de Receitas de Perito
16073	Livro de Receitas de Artífice
16082	Pescador Artífice – O Caminho da Isca
16083	Pescador Perito – O Bagre e Você
16084	Socorrista Perito – Enfaixado
16085	Socorrista Artífice – Cura a Ti Mesmo
16110	Receita: Omelete Monstro
16111	Receita: Chili Temperado de Caranguejo
16112	Manual: Bandagem Grossa de Seda
16113	Manual: Bandagem de Magitrama
16114	Cassetete do Encarregado
16115	Caixote de Larso
16166	Sopa de Feijão
16167	Delícia Variegada
16168	Pêssego celestial
16169	Bolinho de Arroz Selvagem
16170	Mandu no Vapor
16171	Shinsollo
16189	Carta de Dispensa de Maggran
16190	Restos Mortais de Estripadora Furissangue
16191	Espelho Ornado
16192	Presa de Besseleth
16202	Essência Eterna Inferior
16203	Essência Eterna Maior
16204	Pó da Ilusão
16205	Semente de Gaia
16206	Bastão de Arcanita
16207	Bastão Rúnico de Arcanita
16208	Sementes Encantadas de Gaia
16209	Ordens do Rodrigo
16210	Caixote do Antônio
16214	Fórmula: Encantamento Maior de Intelecto - Braçadeiras
16215	Fórmula: Encantamento Maior de Vigor - Botas
16216	Fórmula: Encantamento Maior de Resistência - Manto
16217	Fórmula: Encantamento Maior de Vigor - Escudo
16218	Fórmula: Encantamento Superior de Espírito - Braçadeiras
16219	Fórmula: Encantamento Maior de Agilidade - Luvas
16220	Fórmula: Encantamento de Espírito - Botas
16221	Fórmula: Encantamento Elevado de Vida - Torso
16222	Fórmula: Encantamento Superior de Espírito - Escudo
16223	Fórmula: Encantamento do Arrepio Gélido - Arma
16224	Fórmula: Encantamento Superior de Defesa - Manto
16242	Fórmula: Encantamento Elevado de Mana - Torso
16243	Fórmula: Bastão Rúnico de Arcanita
16244	Fórmula: Encantamento Maior de Força - Luvas
16245	Fórmula: Encantamento Maior de Agilidade - Botas
16246	Fórmula: Encantamento Superior de Força - Braçadeiras
16247	Fórmula: Encantamento Superior de Impacto - Arma de 2M
16248	Fórmula: Encantamento Profano - Arma
16249	Fórmula: Encantamento Elevado de Intelecto - Arma de 2M
16250	Fórmula: Encantamento Superior de Ataque - Arma
16251	Fórmula: Encantamento Superior de Vigor - Braçadeiras
16252	Fórmula: Encantamento do Cruzado - Arma
16253	Fórmula: Encantamento Maior de Atributos - Torso
16254	Fórmula: Encantamento de Roubo de Vida - Arma
16255	Fórmula: Encantamento Elevado de Espírito - Arma de 2M
16262	Coleção de Nessa
16263	Resposta de Laird
16282	Pacote de Peles
16283	Artigos em Couro do Ahanu
16302	Grimório de Seta de Fogo (Grau 2)
16303	Pata de Ursangous
16304	Cabeça de Shadumbra
16305	Garra de Garraguda
16306	Carnes de Zargh
16307	Carta de Gryshka
16308	Pé-de-cabra de Beiranorte
16309	Amuleto da Chama Dracônica
16310	Lista de Brock
16311	Picaretas Honorárias
16312	Incenderitas
16313	Baú do Félix
16314	Balde de Parafusos do Félix
16315	Capa do Primeiro-sargento
16316	Grimório de Seta de Fogo (Grau 3)
16317	Grimório de Seta de Fogo (Grau 4)
16318	Grimório de Seta de Fogo (Grau 5)
16319	Grimório de Seta de Fogo (Grau 6)
16320	Grimório de Seta de Fogo (Grau 7)
16321	Grimório de Pacto de Sangue (Grau 1)
16322	Grimório de Pacto de Sangue (Grau 2)
16323	Grimório de Pacto de Sangue (Grau 3)
16324	Grimório de Pacto de Sangue (Grau 4)
16325	Grimório de Pacto de Sangue (Grau 5)
16326	Grimório de Escudo Ígneo (Grau 1)
16327	Grimório de Escudo Ígneo (Grau 2)
16328	Grimório de Escudo Ígneo (Grau 3)
16329	Grimório de Escudo Ígneo (Grau 4)
16330	Grimório de Escudo Ígneo (Grau 5)
16331	Grimório de Mudança de Fase
16332	Picareta de Thazz'ril
16333	Restos Mortais de Samuel
16335	Insígnia do Primeiro-sargento
16336	Capa do Primeiro-sargento
16337	Capa do Primeiro-sargento
16338	Corcel do Tenente-cavaleiro
16339	Corcel do Comandante
16341	Manto do Sargento
16342	Capa do Sargento
16343	Montaria do Guarda-de-sangue
16344	Montaria do Tenente-general
16345	Lâmina do Sumo Senhor da Guerra
16346	Grimório de Tormento (Grau 2)
16347	Grimório de Tormento (Grau 3)
16348	Grimório de Tormento (Grau 4)
16349	Grimório de Tormento (Grau 5)
16350	Grimório de Tormento (Grau 6)
16351	Grimório de Sacrificar (Grau 1)
16352	Grimório de Sacrificar (Grau 2)
16353	Grimório de Sacrificar (Grau 3)
16354	Grimório de Sacrificar (Grau 4)
16355	Grimório de Sacrificar (Grau 5)
16356	Grimório de Sacrificar (Grau 6)
16357	Grimório de Consumir Sombras (Grau 1)
16358	Grimório de Consumir Sombras (Grau 2)
16359	Grimório de Consumir Sombras (Grau 3)
16360	Grimório de Consumir Sombras (Grau 4)
16361	Grimório de Consumir Sombras (Grau 5)
16362	Grimório de Consumir Sombras (Grau 6)
16363	Grimório de Sofrimento (Grau 1)
16364	Grimório de Sofrimento (Grau 2)
16365	Grimório de Sofrimento (Grau 3)
16366	Grimório de Sofrimento (Grau 4)
16367	Faixa de Seda do Capitão-cavaleiro
16368	Grimório de Açoite da Dor (Grau 2)
16369	Botas de Seda do Tenente-cavaleiro
16370	Manilhas de Seda do Capitão-cavaleiro
16371	Grimório de Açoite da Dor (Grau 3)
16372	Grimório de Açoite da Dor (Grau 4)
16373	Grimório de Açoite da Dor (Grau 5)
16374	Grimório de Açoite da Dor (Grau 6)
16375	Grimório de Beijo Reconfortante (Grau 1)
16376	Grimório de Beijo Reconfortante (Grau 2)
16377	Grimório de Beijo Reconfortante (Grau 3)
16378	Grimório de Beijo Reconfortante (Grau 4)
16379	Grimório de Sedução
16380	Grimório de Invisibilidade Inferior
16381	Grimório de Devorar Magia (Grau 2)
16382	Grimório de Devorar Magia (Grau 3)
16383	Grimório de Devorar Magia (Grau 4)
16384	Grimório de Sangue Maculado (Grau 1)
16385	Grimório de Sangue Maculado (Grau 2)
16386	Grimório de Sangue Maculado (Grau 3)
16387	Grimório de Sangue Maculado (Grau 4)
16388	Grimório de Bloquear Feitiço (Grau 1)
16389	Grimório de Bloquear Feitiço (Grau 2)
16390	Grimório de Paranoia
16391	Luvas de Seda do Tenente-cavaleiro
16392	Botas de Couro do Tenente-cavaleiro
16393	Palmilhas de Couro de Dragão do Tenente-cavaleiro
16394	Braçadeiras de Couro do Capitão-cavaleiro
16395	Pulseiras de Couro de Dragão do Capitão-cavaleiro
16396	Manoplas de Couro do Tenente-cavaleiro
16397	Luvas de Couro de Dragão do Tenente-cavaleiro
16398	Cinto de Couro do Capitão-cavaleiro
16399	Cinturão de Couro de Dragão do Capitão-cavaleiro
16400	Cinturão Encadeado do Capitão-cavaleiro
16401	Botas Encadeadas do Tenente-cavaleiro
16402	Guarda-braços Encadeados do Capitão-cavaleiro
16403	Manoplas Encadeadas do Tenente-cavaleiro
16404	Munhequeiras de Placa do Capitão-cavaleiro
16405	Botas de Placa do Tenente-cavaleiro
16406	Manoplas de Placa do Tenente-cavaleiro
16407	Cinturão de Placa do Capitão-cavaleiro
16408	Globo d'Água Conspurcado
16409	Escarpes Lamelares do Tenente-cavaleiro
16410	Manoplas Lamelares do Tenente-cavaleiro
16411	Cilha Lamelar do Capitão-cavaleiro
16412	Pulseiras Lamelares do Capitão-cavaleiro
16413	Traje de Seda do Capitão-cavaleiro
16414	Perneiras de Seda do Capitão-cavaleiro
16415	Brafoneiras de Seda do Tenente-comandante
16416	Coroa do Tenente-comandante
16417	Armadura de Couro do Capitão-cavaleiro
16418	Máscara de Couro do Tenente-comandante
16419	Guarda-pernas de Couro do Capitão-cavaleiro
16420	Espaldares de Couro do Tenente-comandante
16421	Túnica de Couro de Dragão do Capitão-cavaleiro
16422	Perneiras de Couro de Dragão do Capitão-cavaleiro
16423	Palas de Couro de Dragão do Tenente-comandante
16424	Mortalha de Couro de Dragão do Tenente-comandante
16425	Cota Encadeada do Capitão-cavaleiro
16426	Perneiras Encadeadas do Capitão-cavaleiro
16427	Brafoneiras Encadeadas do Tenente-comandante
16428	Capacete Encadeado do Tenente-comandante
16429	Elmo de Placa do Tenente-comandante
16430	Couraça de Placa do Capitão-cavaleiro
16431	Perneiras de Placa do Capitão-cavaleiro
16432	Brafoneiras de Placa do Tenente-comandante
16433	Peitoral Lamelar do Capitão-cavaleiro
16434	Cimeira Lamelar do Tenente-comandante
16435	Perneiras Lamelares do Capitão-cavaleiro
16436	Omoplatas Lamelares do Tenente-comandante
16437	Palmilhas de Seda do Marechal
16438	Braçadeiras de Seda do Marechal
16439	Faixa de Seda do Marechal
16440	Luvas de Seda do Marechal
16441	Coroa do Marechal-de-campo
16442	Perneiras de Seda do Marechal
16443	Vestimenta de Seda do Marechal-de-campo
16444	Espaldares de Seda do Marechal-de-campo
16445	Braçadeiras de Couro de Dragão do Marechal
16446	Guarda-pés de Couro do Marechal
16447	Cinta de Couro de Dragão do Marechal
16448	Manoplas de Couro de Dragão do Marechal
16449	Espaldares de Couro de Dragão do Marechal-de-campo
16450	Guarda-pernas de Couro de Dragão do Marechal
16451	Capacete de Couro de Dragão do Marechal-de-campo
16452	Peitoral de Couro de Dragão do Marechal-de-campo
16453	Peito d'Armas de Couro do Marechal-de-campo
16454	Guantes de Couro do Marechal
16455	Máscara de Couro do Marechal-de-campo
16456	Perneiras de Couro do Marechal
16457	Palas de Couro do Marechal-de-campo
16458	Cilha de Couro do Marechal
16459	Botas de Couro de Dragão do Marechal
16460	Pulseiras de Couro do Marechal
16461	Braçadeiras Encadeadas do Marechal
16462	Botas Encadeadas do Marechal
16463	Guantes Encadeados do Marechal
16464	Cinturão Encadeado do Marechal
16465	Elmo Encadeado do Marechal-de-campo
16466	Peitoral Encadeado do Marechal-de-campo
16467	Guarda-pernas Encadeados do Marechal
16468	Espaldares Encadeados do Marechal-de-campo
16469	Guarda-braços Lamelares do Marechal
16470	Cinto Lamelar do Marechal
16471	Luvas Lamelares do Marechal
16472	Botas Lamelares do Marechal
16473	Guarda-peito Lamelar do Marechal-de-campo
16474	Viseira Lamelar do Marechal-de-campo
16475	Coxotes Lamelares do Marechal
16476	Brafoneiras Lamelares do Marechal-de-campo
16477	Armadura de Placa do Marechal-de-campo
16478	Elmo de Placa do Marechal-de-campo
16479	Guarda-pernas de Placa do Marechal
16480	Guarda-ombros de Placa do Marechal-de-campo
16481	Braçadeiras de Placa do Marechal
16482	Cinturão de Placa do Marechal
16483	Botas de Placa do Marechal
16484	Manoplas de Placa do Marechal
16485	Palmilhas de Seda do Guarda-de-sangue
16486	Manilhas de Seda do Primeiro-sargento
16487	Luvas de Seda do Guarda-de-sangue
16488	Cinto de Seda do Legionário
16489	Capuz de Seda do Campeão
16490	Calças de Seda do Legionário
16491	Vestes de Seda do Legionário
16492	Ombreiras de Seda do Campeão
16493	Guarda-braços de Couro de Dragão do Legionário
16494	Botas de Couro de Dragão do Guarda-de-sangue
16495	Cintel de Couro de Dragão do Legionário
16496	Manoplas de Couro de Dragão do Guarda-de-sangue
16497	Guarda-braços de Couro do Primeiro-sargento
16498	Botinas de Couro do Guarda-de-sangue
16499	Luvas de Couro do Guarda-de-sangue
16500	Cinturão de Couro do Legionário
16501	Espaldares de Couro de Dragão do Campeão
16502	Calças de Couro de Dragão do Legionário
16503	Elmo de Couro de Dragão do Campeão
16504	Peitoral de Couro de Dragão do Legionário
16505	Cota de Couro do Legionário
16506	Cimeira de Couro do Campeão
16507	Dragonas de Couro do Campeão
16508	Perneiras de Couro do Legionário
16509	Botas de Placa do Guarda-de-sangue
16510	Luvas de Placa do Guarda-de-sangue
16511	Cilha de Placa do Legionário
16512	Braçadeiras de Placa do Legionário
16513	Armadura de Placa do Legionário
16514	Cimeira de Placa do Campeão
16515	Guarda-pernas de Placa do Legionário
16516	Brafoneiras de Placa do Campeão
16517	Braçadeiras Encadeadas do Legionário
16518	Chancas de Malha do Guarda-de-sangue
16519	Guantes de Malha do Guarda-de-sangue
16520	Cilha de Malha do Legionário
16521	Elmo de Malha do Campeão
16522	Peito d'Armas de Malha do Legionário
16523	Perneiras de Malha do Legionário
16524	Omoplatas de Malha do Campeão
16525	Peitoral Encadeado do Legionário
16526	Cimeira Encadeada do Campeão
16527	Perneiras Encadeadas do Legionário
16528	Brafoneiras Encadeadas do Campeão
16529	Cinturão Encadeado do Legionário
16530	Manoplas Encadeadas do Guarda-de-sangue
16531	Botas Encadeadas do Guarda-de-sangue
16532	Munhequeiras de Malha do Primeiro-sargento
16533	Capucho de Seda do Senhor da Guerra
16534	Calças de Seda do General
16535	Traje de Seda do Senhor da Guerra
16536	Sobreveste de Seda do Senhor da Guerra
16537	Faixa de Seda do General
16538	Manilhas de Seda do General
16539	Botas de Seda do General
16540	Protetores de Mão de Seda do General
16541	Armadura de Placa do Senhor da Guerra
16542	Bacinete de Placa do Senhor da Guerra
16543	Perneiras de Placa do General
16544	Omoplatas de Placa do Senhor da Guerra
16545	Botas de Placa do General
16546	Guarda-braços de Placa do General
16547	Cinturão de Placa do General
16548	Manoplas de Placa do General
16549	Cota de Couro de Dragão do Senhor da Guerra
16550	Capacete de Couro de Dragão do Senhor da Guerra
16551	Palas de Couro de Dragão do Senhor da Guerra
16552	Perneiras de Couro de Dragão do General
16553	Braçadeiras de Couro de Dragão do General
16554	Botas de Couro de Dragão do General
16555	Luvas de Couro de Dragão do General
16556	Cinto de Couro de Dragão do General
16557	Cinturão de Couro do General
16558	Botinas de Couro do General
16559	Pulseiras de Couro do General
16560	Luvas de Couro do General
16561	Elmo de Couro do Senhor da Guerra
16562	Espaldares de Couro do Senhor da Guerra
16563	Peitoral de Couro do Senhor da Guerra
16564	Guarda-pernas de Couro do General
16565	Peito d'Armas Encadeado do Senhor da Guerra
16566	Capacete Encadeado do Senhor da Guerra
16567	Guarda-pernas Encadeados do General
16568	Omoplatas Encadeadas do Senhor da Guerra
16569	Escarpes Encadeados do General
16570	Munhequeiras Encadeadas do General
16571	Luvas Encadeadas do General
16572	Cinturão Encadeado do General
16573	Botas de Malha do General
16574	Manoplas de Malha do General
16575	Cintel de Malha do General
16576	Braçadeiras de Malha do General
16577	Armadura de Malha do Senhor da Guerra
16578	Elmo de Malha do Senhor da Guerra
16579	Perneiras de Malha do General
16580	Espaldares de Malha do Senhor da Guerra
16581	Cristal de Ressonita
16583	Estatueta Demoníaca
16602	Patuá Troll
16603	Cristal de Ressonita Encantado
16604	Vestes Lunares de Eluna
16605	Vestes de Luz do Frei
16606	Vestes Maléficas Juju
16607	Vestes de Sacrifício do Acólito
16608	Cinturão de Aquarius
16622	Taca-espinhos
16623	Medalhão de Opalina
16642	Manual de Operação do Retalhador - Capítulo 1
16643	Manual de Operação do Retalhador - Capítulo 2
16644	Manual de Operação do Retalhador - Capítulo 3
16645	Manual de Operação do Retalhador - Página 1
16646	Manual de Operação do Retalhador - Página 2
16647	Manual de Operação do Retalhador - Página 3
16648	Manual de Operação do Retalhador - Página 4
16649	Manual de Operação do Retalhador - Página 5
16650	Manual de Operação do Retalhador - Página 6
16651	Manual de Operação do Retalhador - Página 7
16652	Manual de Operação do Retalhador - Página 8
16653	Manual de Operação do Retalhador - Página 9
16654	Manual de Operação do Retalhador - Página 10
16655	Manual de Operação do Retalhador - Página 11
16656	Manual de Operação do Retalhador - Página 12
16658	Manto do Caçador Selvagem
16659	Cinto Hábil
16660	Escudo Lodo Flutuante
16661	Capa Macia do Salgueiro
16662	Fragmento do Olho do Dragão
16663	Sangue do Campeão dos Dragões Negros
16664	Braçadeiras Ornadas
16665	Tomo de Tiro Tranquilizante
16666	Colete dos Elementos
16667	Coifa dos Elementos
16668	Kilt dos Elementos
16669	Brafoneiras dos Elementos
16670	Botas dos Elementos
16671	Braceletes dos Elementos
16672	Manoplas dos Elementos
16673	Cordão dos Elementos
16674	Túnica do Espreitador de Feras
16675	Botas do Espreitador de Feras
16676	Luvas do Espreitador de Feras
16677	Casquete do Espreitador de Feras
16678	Calças do Espreitador de Feras
16679	Dragonas do Espreitador de Feras
16680	Cinto do Espreitador de Feras
16681	Braceletes do Espreitador de Feras
16682	Botas do Magíster
16683	Braceletes do Magíster
16684	Luvas do Magíster
16685	Cinto do Magíster
16686	Coroa do Magíster
16687	Perneiras do Magíster
16688	Vestes do Magíster
16689	Dragonas do Magíster
16690	Veste do Devoto
16691	Sandálias do Devoto
16692	Luvas do Devoto
16693	Coroa do Devoto
16694	Saia do Devoto
16695	Dragonas do Devoto
16696	Cinto do Devoto
16697	Braçadeiras do Devoto
16698	Máscara de Brumedo
16699	Perneiras de Brumedo
16700	Veste de Brumedo
16701	Dragonas de Brumedo
16702	Cinto de Brumedo
16703	Braçadeiras de Brumedo
16704	Sandálias de Brumedo
16705	Guarda-braços de Brumedo
16706	Colete do Coração Selvagem
16707	Capuz da Arte Sombria
16708	Espaldares da Arte Sombria
16709	Calças da Arte Sombria
16710	Braçadeiras da Arte Sombria
16711	Botas da Arte Sombria
16712	Luvas da Arte Sombria
16713	Cinto da Arte Sombria
16714	Braçadeiras do Coração Selvagem
16715	Botas do Coração Selvagem
16716	Cinto do Coração Selvagem
16717	Luvas do Coração Selvagem
16718	Dragonas do Coração Selvagem
16719	Kilt do Coração Selvagem
16720	Capucho do Coração Selvagem
16721	Túnica da Arte Sombria
16722	Braçadeiras da Forja de Luz
16723	Cinto da Forja de Luz
16724	Manoplas da Forja de Luz
16725	Botas da Forja de Luz
16726	Peitoral da Forja de Luz
16727	Elmo da Forja de Luz
16728	Coxotes da Forja de Luz
16729	Espaldares da Forja de Luz
16730	Peitoral do Valor
16731	Elmo do Valor
16732	Coxotes do Valor
16733	Espaldares do Valor
16734	Botas do Valor
16735	Braçadeiras do Valor
16736	Cinto do Valor
16737	Manoplas do Valor
16738	Luvas Murchagrão
16739	Dragonas Madeiroso
16740	Luvas para Operar Retalhadora
16741	Mitenes de Trapo Oleoso
16742	Lâminas Serrilhadas dos Brado Guerreiro
16743	Corda para Transportar Toras
16744	Óleo dos Brado Guerreiro
16745	Carregamento de Machados dos Brado Guerreiro
16746	Relatório dos Brado Guerreiro
16747	Tranca Quebrada
16748	Forro Acolchoado
16762	Núcleo das Profundezas
16763	Informe do Mensageiro do Brado Guerreiro
16764	Informe do Batedor do Brado Guerreiro
16765	Informe do Pioneiro do Brado Guerreiro
16766	Ensopado de Marisco Inframina
16767	Receita: Ensopado de Marisco Inframina
16768	Bolsa Medicinal de Pelurso
16769	Totem Medicinal de Pelurso
16782	Globo d'Água Estranho
16783	Monte de Relatórios
16784	Safira de Aku'Mai
16786	Olho de Dragomorfo Preto
16787	Amuleto de Subversão Dracônica
16788	Leme do Capitão Rodovalho
16789	Cana do Leme do Capitão Rodovalho
16790	Bilhete Úmido
16791	Manilhas da Torrente Sedosa
16792	Clava Gigante
16793	Omoplatas de Arquimetal
16794	Munhequeiras da Pegada Férrea
16795	Coroa do Arcanista
16796	Perneiras do Arcanista
16797	Dragonas do Arcanista
16798	Vestes do Arcanista
16799	Braceletes do Arcanista
16800	Botas do Arcanista
16801	Luvas do Arcanista
16802	Cinto do Arcanista
16803	Sapatilhas Vilcórdias
16804	Braçadeiras Vilcórdias
16805	Luvas Vilcórdias
16806	Cinto Vilcórdio
16807	Ombreiras Vilcórdias
16808	Chifres Vilcórdios
16809	Vestes Vilcórdias
16810	Calças Vilcórdias
16811	Botas da Profecia
16812	Luvas da Profecia
16813	Diadema da Profecia
16814	Calças da Profecia
16815	Vestes da Profecia
16816	Dragonas da Profecia
16817	Cinturão da Profecia
16818	Cinto do Vento Etéreo
16819	Avambraços da Profecia
16820	Peito d'Armas do Matador Noturno
16821	Elmo do Matador Noturno
16822	Calças do Matador Noturno
16823	Ombreiras do Matador Noturno
16824	Botas do Matador Noturno
16825	Braceletes do Matador Noturno
16826	Luvas do Matador Noturno
16827	Cinto do Matador Noturno
16828	Cinto Cenariano
16829	Botas Cenarianas
16830	Braçadeiras Cenarianas
16831	Luvas Cenarianas
16832	Espaldares Dentessangue
16833	Vestimenta Cenariana
16834	Elmo Cenariano
16835	Perneiras Cenarianas
16836	Espaldares Cenarianos
16837	Botas Terrafúria
16838	Cinto Terrafúria
16839	Manoplas Terrafúria
16840	Braçadeiras Terrafúria
16841	Vestimenta Terrafúria
16842	Capacete Terrafúria
16843	Guarda-pernas Terrafúria
16844	Palas Terrafúria
16845	Peitoral do Espreita-gigantes
16846	Capacete do Espreita-gigantes
16847	Perneiras do Espreita-gigantes
16848	Palas do Espreita-gigantes
16849	Botas do Espreita-gigantes
16850	Braçadeiras do Espreita-gigantes
16851	Cinto do Espreita-gigantes
16852	Luvas do Espreita-gigantes
16853	Couraça do Mantenedor da Lei
16854	Elmo do Mantenedor da Lei
16855	Coxotes do Mantenedor da Lei
16856	Espaldares do Mantenedor da Lei
16857	Braçadeiras do Mantenedor da Lei
16858	Cinto do Mantenedor da Lei
16859	Botas do Mantenedor da Lei
16860	Manoplas do Mantenedor da Lei
16861	Braçadeiras do Poder
16862	Escarpes do Poder
16863	Manoplas do Poder
16864	Cinto do Poder
16865	Peitoral do Poder
16866	Elmo do Poder
16867	Coxotes do Poder
16868	Brafoneiras do Poder
16869	Crânio de Áugure
16870	Crânio de Somnus
16871	Crânio de Chronalis
16872	Crânio de Axtroz
16873	Luvas de Tranças de Pele
16882	Caixa de Tralhas Desgastada
16883	Caixa de Tralhas Gasta
16884	Caixa de Tralhas Robusta
16885	Caixa de Tralhas Pesada
16886	Sabre do Fora da Lei
16887	Dedo de Bruxa
16888	Amuleto da Chama Dracônica Fraco
16889	Bengala Polida
16890	Alfanje de Ardósia
16891	Espada Curta de Argilito
16892	Pedra da Alma Inferior
16893	Pedra da Alma
16894	Bastão de Cristal Claro
16895	Pedra da Alma Maior
16896	Pedra da Alma Elevada
16897	Couraça Tempesfúria
16898	Botas Tempesfúria
16899	Protetores de Mão Tempesfúria
16900	Mantel Tempesfúria
16901	Guarda-pernas Tempesfúria
16902	Brafoneiras Tempesfúria
16903	Cinto Tempesfúria
16904	Braçadeiras Tempesfúria
16905	Peito d'Armas Dentessangue
16906	Botas Dentessangue
16907	Luvas Dentessangue
16908	Capuz Dentessangue
16909	Calças Dentessangue
16910	Cinto Dentessangue
16911	Braçadeiras Dentessangue
16912	Botas do Vento Etéreo
16913	Luvas do Vento Etéreo
16914	Coroa do Vento Etéreo
16915	Calças do Vento Etéreo
16916	Vestes do Vento Etéreo
16917	Dragonas do Vento Etéreo
16918	Braçadeiras do Vento Etéreo
16919	Botas da Transcendência
16920	Protetores de Mão da Transcendência
16921	Halo da Transcendência
16922	Perneiras da Transcendência
16923	Vestes da Transcendência
16924	Brafoneiras da Transcendência
16925	Cinto da Transcendência
16926	Braçadeiras da Transcendência
16927	Botas da Nêmesis
16928	Luvas da Nêmesis
16929	Casquete da Nêmesis
16930	Perneiras da Nêmesis
16931	Vestes da Nêmesis
16932	Espaldares da Nêmesis
16933	Cinto da Nêmesis
16934	Braçadeiras da Nêmesis
16935	Braçadeiras do Espreita-dragão
16936	Cinto do Espreita-dragão
16937	Espaldares do Espreita-dragão
16938	Guarda-pernas do Espreita-dragão
16939	Elmo do Espreita-dragão
16940	Manoplas do Espreita-dragão
16941	Grevas do Espreita-dragão
16942	Peitoral do Espreita-dragão
16943	Braçadeiras das Dez Tempestades
16944	Cinto das Dez Tempestades
16945	Palas das Dez Tempestades
16946	Coxotes das Dez Tempestades
16947	Capacete das Dez Tempestades
16948	Manoplas das Dez Tempestades
16949	Grevas das Dez Tempestades
16950	Peitoral das Dez Tempestades
16951	Braçadeiras do Julgamento
16952	Cinto do Julgamento
16953	Espaldares do Julgamento
16954	Coxotes do Julgamento
16955	Coroa do Julgamento
16956	Manoplas do Julgamento
16957	Escarpes do Julgamento
16958	Peitoral do Julgamento
16959	Braceleiras da Ira
16960	Cintel da Ira
16961	Brafoneiras da Ira
16962	Coxotes da Ira
16963	Elmo da Ira
16964	Manoplas da Ira
16965	Escarpes da Ira
16966	Peitoral da Ira
16967	Atum-amarelo-de-feralas
16968	Piranha-de-sar'theris
16969	Molinésia-azul-da-costa-selvagem
16970	Graçapé-brumalga
16971	Escondidinho Marisquete
16972	Estandarte de Karang
16973	Ampola de Água Hedionda
16974	Ampola Vazia de Água
16975	Faixa do Brado Guerreiro
16976	Totem de Murgut
16977	Botas do Brado Guerreiro
16978	Manoplas do Brado Guerreiro
16979	Luvas do Núcleo Flamífero
16980	Dragonas do Núcleo Flamífero
16981	Braçadeiras da Barba da Coruja
16982	Botas de Cão do Núcleo
16983	Elmo Derretido
16984	Botas de Escama de Dragão Negro
16985	Botas do Perseguidor dos Ventos
16986	Luvas das Agulhas Arenosas
16987	Cinto do Guinchador
16988	Omoplatas Encadeadas Abrasadoras
16989	Cinturão Encadeado Abrasador
16990	Manto das Fadas
16991	Bandagem de Triagem
16992	Lança-bombas do Fumaça
16993	Lança-fogo do Fumaça
16994	Luvas de Quiroscuro
16995	Dragonas de Quiroscuro
16996	Arco de Rubraplanta
16997	Tempestofúrio
16998	Protetor Sagrado
16999	Selo Real de Alexis
17000	Anel do Espectro
17001	Anel Elemental
17002	Cospeçonha
17003	Martelo Rochacrânio
17004	Guia de Sarah
17005	Túnica do Guarda Grosseiro
17006	Guarda-pernas de Cobalto
17007	Manoplas Racha-pedras
17008	Pergaminho Pequeno
17009	Cabeça do Embaixador Malcin
17010	Núcleo de Fogo
17011	Núcleo de Lava
17012	Couro do Núcleo
17013	Perneiras Ferro Negro
17014	Braçadeiras Ferro Negro
17015	Aniquilador Ferro Negro
17016	Destruidor Ferro Negro
17017	Molde: Dragonas do Núcleo Flamífero
17018	Molde: Luvas do Núcleo Flamífero
17019	Pó Arcano
17020	Pó Arcano
17021	Frutas do Bosque
17022	Molde: Botas de Cão do Núcleo
17023	Molde: Elmo Derretido
17024	Raiz Selvagem
17025	Molde: Botas de Escama de Dragão Negro
17026	Tuberspinho Selvagem
17027	Vela Aromática
17028	Vela Sagrada
17029	Vela Sacra
17030	Ankh
17031	Runa de Teleporte
17032	Runa de Portais
17033	Símbolo da Divindade
17034	Semente de Bordo
17035	Semente-do-espinhaço
17036	Semente de Freixo
17037	Semente de Álamo
17038	Semente de Pau-ferro
17039	Quebra-crânio
17042	Cospe-unha
17043	Veste do Zelote
17044	Vontade do Mártir
17045	Sangue do Mártir
17046	Rasga-sarjeta
17047	Sobreveste Luminescente
17048	Rum Rumsey
17049	Instruções: Cinturão Encadeado Abrasador
17050	Vestes Imperiais de Chan
17051	Instruções: Braçadeiras Ferro Negro
17052	Instruções: Perneiras Ferro Negro
17053	Instruções: Omoplatas Encadeadas Abrasadoras
17054	Clemência de Joonho
17055	Esmaga-changuk
17056	Pluma
17057	Escamas Brilhantes de Peixe
17058	Óleo de Peixe
17059	Instruções: Aniquilador Ferro Negro
17060	Instruções: Destruidor Ferro Negro
17061	Sombra de Juno
17062	Receita: Truta Cabeça-de-mithril
17063	Anel de Accuria
17064	Estilhaço da Escama
17065	Medalhão do Poder Estável
17066	Disco do Perfurador
17067	Grimório Antigo da Pedra Angular
17068	Mortífero
17069	Marca do Atirador
17070	Presa dos Místicos
17071	Rasgatripas
17072	Lança-pipoco
17073	Treme-terra
17074	Golpe Sombrio
17075	Vis'kag, o Dessangrador
17076	Gume Rasgaosso
17077	Choque Carmesim
17078	Clâmide de Sapphiron
17082	Estilhaço da Chama
17102	Manto Envolto em Brumas
17103	Magespada Lazulicanto
17104	Ceifa-espinhaço
17105	Martelo Petraura
17106	Defensor de Malistar
17107	Capa de Sangue de Dragão
17108	Marca de Deflexão
17109	Gargantilha do Esclarecimento
17110	Selo do Arquimago
17111	Medalhão de Ardenfúria
17112	Demolidor Empíreo
17113	Guardião do Selo Âmbar
17114	Fragmento de Filactério de Araj
17115	Emblema do Esquilo
17116	Emblema do Esquilo
17117	Flauta do Pegador de Ratos
17118	Caixa de Carne Duvidosa
17119	Kebab de Rato Correfundo
17124	Emblema da Camarilha
17125	Selo de Corvoforte
17126	Carta Elegante
17142	Estilhaço do Profanador
17182	Sulfuras, a Mão de Ragnaros
17183	Broquel Amassado
17184	Escudo Pequeno
17185	Broquel Redondo
17186	Tarja Pequena
17187	Broquel Estriado
17188	Broquel Circular
17189	Broquel de Metal
17190	Broquel Ornado
17191	Cetro de Celebras
17192	Tarja Reforçada
17193	Martelo de Sulfuron
17194	Temperos Festivos
17195	Visco Falso
17196	Bebidas de Fim de Ano
17197	Biscoito de Gengibre
17198	Gemada
17199	Gemada de Ovo Gorado
17200	Receita: Biscoito de Gengibre
17201	Receita: Gemada
17202	Bola de Neve
17203	Lingote de Sulfuron
17204	Olho de Sulfuras
17222	Linguiça de Aranha
17223	Golpeforte
17224	Mira de Vidência
17242	Chave do Baú de Salem
17262	Chave do Tiago
17302	Presente de Festas com Fita Azul
17303	Papel de Embrulho com Fita Azul
17304	Papel de Embrulho com Fita Verde
17305	Presente de Festas com Fita Verde
17306	Sangue do Soldado Lançatroz
17307	Papel de Embrulho com Fita Roxa
17308	Presente de Festas com Fita Roxa
17309	Braçadeiras Dissonantes
17310	Aspecto de Neptulon
17322	Olho do Mirabrasa
17323	Sinaleiro de Mulverick
17324	Sinaleiro de Guse
17325	Sinaleiro de Jeztor
17326	Carne do Soldado Lançatroz
17327	Carne do Tenente Lançatroz
17328	Carne do Comandante Lançatroz
17329	Mão de Lúcifron
17330	Mão de Sulfuron
17331	Mão de Geena
17332	Mão de Shazzrah
17333	Quintessência Aquática
17344	Bengalinha Doce
17345	Meleca de Silitídeo
17346	Objeto Silitídeo Incrustado
17347	Rastreador de Homem da Camarilha (MURP)
17348	Tisana de Cura Elevada
17349	Tisana de Cura Superior
17351	Tisana de Mana Elevada
17352	Tisana de Mana Superior
17353	Instruções de Ataque dos Lançatroz
17354	Olho-que-tudo-vê do Mestre Rúben
17355	Carta de Ravine
17362	Sinaleiro de Rúben
17363	Sinaleiro de Rúben
17364	Mira de Vidência
17384	Unidade Retalhadora Portátil do Borogodó
17402	Cerveja Invernal do Papai Inverno
17403	Drinque Borbulhante de Bondebico
17404	Bebida de Grãos Misturados
17405	Chá Verde de Jardim
17406	Roda de Queijo de Festa
17407	Bolo de Carne Caseiro do Gracco
17408	Salame Picante
17409	Fragmento Incrustado de Cristal
17410	Unidade Retalhadora Portátil do Borogodó
17411	Serra a Vapor
17413	Códice: Prece da Fortitude
17414	Códice: Prece da Fortitude II
17422	Sobras de Armadura
17423	Cristal de Tempestade
17442	Instruções de Ataque dos Lobo do Gelo
17502	Medalha do Soldado Lobo do Gelo
17503	Medalha do Tenente Lobo do Gelo
17504	Medalha do Comandante Lobo do Gelo
17505	Sinaleiro de Ichman
17506	Sinaleiro de Vipore
17507	Sinaleiro de Slidore
17508	Broquel Pedraforte
17522	Suprimentos dos Ferrofundo
17523	Clâmide do Fumaça
17542	Suprimentos de Dentefrio
17562	Botas de Medotrama do Tenente-cavaleiro
17563	Braçadeiras de Medotrama do Capitão-cavaleiro
17564	Luvas de Medotrama do Tenente-cavaleiro
17565	Cinto de Medotrama do Capitão-cavaleiro
17566	Cimeira do Tenente-comandante
17567	Perneiras de Medotrama do Capitão-cavaleiro
17568	Veste de Medotrama do Capitão-cavaleiro
17569	Dragonas de Medotrama do Tenente-comandante
17570	Capuz de Medotrama do Campeão
17571	Perneiras de Medotrama do Legionário
17572	Veste de Medotrama do Legionário
17573	Omoplatas de Medotrama do Campeão
17574	Cinto de Medotrama do Legionário
17575	Braçadeiras de Medotrama do Legionário
17576	Botas de Medotrama do Guarda-de-sangue
17577	Luvas de Medotrama do Guarda-de-sangue
17578	Diadema do Marechal-de-campo
17579	Perneiras de Medotrama do Marechal
17580	Omoplatas de Medotrama do Marechal-de-campo
17581	Veste de Medotrama do Marechal-de-campo
17582	Manilhas de Medotrama do Marechal
17583	Botas de Medotrama do Marechal
17584	Luvas de Medotrama do Marechal
17585	Faixa de Medotrama do Marechal
17586	Botas de Medotrama do General
17587	Braçadeiras de Medotrama do General
17588	Luvas de Medotrama do General
17589	Cinto de Medotrama do General
17590	Dragonas de Medotrama do Senhor da Guerra
17591	Capuz de Medotrama do Senhor da Guerra
17592	Veste de Medotrama do Senhor da Guerra
17593	Calças de Medotrama do General
17594	Botas de Cetim do Tenente-cavaleiro
17595	Manilhas de Cetim do Capitão-cavaleiro
17596	Luvas de Cetim do Tenente-cavaleiro
17597	Cordão de Cetim do Capitão-cavaleiro
17598	Diadema do Tenente-comandante
17599	Perneiras de Cetim do Capitão-cavaleiro
17600	Vestes de Cetim do Capitão-cavaleiro
17601	Sobreveste de Cetim do Tenente-comandante
17602	Elmo do Marechal-de-campo
17603	Calças de Cetim do Marechal
17604	Dragonas de Cetim do Marechal-de-campo
17605	Vestimenta de Cetim do Marechal-de-campo
17606	Braçadeiras de Cetim do Marechal
17607	Sandálias de Cetim do Marechal
17608	Luvas de Cetim do Marechal
17609	Faixa de Cetim do Marechal
17610	Capucho de Cetim do Campeão
17611	Calças de Cetim do Legionário
17612	Vestimenta de Cetim do Legionário
17613	Ombreiras de Cetim do Campeão
17614	Faixa de Cetim do Legionário
17615	Manilhas de Cetim do Legionário
17616	Botas de Cetim do Guarda-de-sangue
17617	Luvas de Cetim do Guarda-de-sangue
17618	Botas de Cetim do General
17619	Braçadeiras de Cetim do General
17620	Luvas de Cetim do General
17621	Cilha de Cetim do General
17622	Dragonas de Cetim do Senhor da Guerra
17623	Capucho de Cetim do Senhor da Guerra
17624	Vestes de Cetim do Senhor da Guerra
17625	Perneiras de Cetim do General
17626	Focinheira de Lobo do Gelo
17642	Pelego de Carneiro de Alterac
17643	Pelego dos Lobo do Gelo
17662	Gostosuras Roubadas
17682	Livro: Dádiva do Indomado
17683	Livro: Dádiva do Indomado II
17684	Entalhe de Cristal Terádrico
17685	Amostras da Fazenda Bosque Defumado
17686	Arco do Mestre Caçador
17687	Rifle do Mestre Caçador
17688	Botas da Selva
17689	Coleira de Treinamento de Lançatroz
17690	Insígnia Lobo do Gelo Grau 1
17691	Insígnia Lançatroz Grau 1
17692	Anel de Chifre
17693	Ampola Cerúlea Tampada
17694	Elo do Punho
17695	Dragonas Castanhas
17696	Ampola Cerúlea Cheia
17702	Bastão de Celebras
17703	Diamante de Celebras
17704	Limiar do Inverno
17705	Lâmina Cruel
17706	Instruções: Limiar do Inverno
17707	Coração de Lasca Preciosa
17708	Elixir de Poder Gélido
17709	Receita: Elixir de Poder Gélido
17710	Punhal de Aragonita
17711	Perneiras da Cordilheira Elemental
17712	Kit de Disfarce do Véu de Inverno
17713	Anel de Pedra Negra
17714	Braçadeiras da Princesa de Pedra
17715	Olho de Theradras
17716	Mestreneves 9000
17717	Rifle Megatiro
17718	Broquel Modernaço de Bugitranca
17719	Espada Focal do Inventor
17720	Diagrama: Mestreneves 9000
17721	Luvas do Grande Pai
17722	Molde: Luvas do Grande Pai
17723	Camisa Verde Festiva
17724	Molde: Camisa Verde Festiva
17725	Fórmula: Encantamento de Poder do Inverno - Arma
17726	Presente Especial da Fazenda Bosque Defumado
17727	Pacote de Presentes da Fazenda Bosque Defumado
17728	Botas de Escama de Crocodilo Albino
17730	Machado Dente de Crocodilo
17731	Pergaminho de Celebras
17732	Dragonas Putrigarra
17733	Punho de Pedra
17734	Elmo da Montanha
17735	A Festa do Véu de Inverno
17736	Manoplas de Pedra
17737	Pedra Nuvem
17738	Garra de Celebras
17739	Clâmide do Guardião do Bosque
17740	Cocar do Adivinho
17741	Abraço da Natureza
17742	Armadura de Cogumelo
17743	Bastão da Ressurgência
17744	Coração de Tóxxico
17745	Clavina Tóxica
17746	Grilhões de Tóxxico
17747	Raiz de Azorrague
17748	Sandálias de Vinhapútrida
17749	Espaldares de Fitocouro
17750	Cinturão de Clorofio
17751	Perneiras de Pelebroto
17752	Açoite do Sátiro
17753	Mira do Guardião Verdejante
17754	Perneiras do Trapaceiro Infernal
17755	Faixa de Crina de Sátiro
17756	Fragmento de Lascanegra
17757	Amuleto dos Espíritos
17758	Amuleto da União
17759	Marca da Determinação
17760	Semente da Vida
17761	Gema do Primeiro Khan
17762	Gema do Segundo Khan
17763	Gema do Terceiro Khan
17764	Gema do Quarto Khan
17765	Gema do Quinto Khan
17766	Cetro da Princesa Theradras
17767	Bacinete Brotoflorido
17768	Anel Semelenha
17769	Espaldares de Artemísia
17770	Manoplas da Garra Silvestre
17771	Barra de Elemêntio
17772	Pingente Zeloso Lascanegra
17773	Pingente Lascanegra do Prodígio
17774	Marca do Escolhido
17775	Vestes da Perspicácia
17776	Elmo de Eloduende
17777	Cota Encadeada Implacável
17778	Cinturão de Artemísia
17779	Brafoneiras de Pedramó
17780	Lâmina da Escuridão Eterna
17781	As Instruções do Pária
17782	Estilhaço do Talismã da União
17783	Fragmento do Talismã da União
17822	Mapas dos Lobo do Gelo
17823	Plano de Batalha dos Lançatroz
17849	Estandarte dos Lançatroz
17850	Estandarte dos Lobo do Gelo
17900	Insígnia Lançatroz Grau 2
17901	Insígnia Lançatroz Grau 3
17902	Insígnia Lançatroz Grau 4
17903	Insígnia Lançatroz Grau 5
17904	Insígnia Lançatroz Grau 6
17905	Insígnia Lobo do Gelo Grau 2
17906	Insígnia Lobo do Gelo Grau 3
17907	Insígnia Lobo do Gelo Grau 4
17908	Insígnia Lobo do Gelo Grau 5
17909	Insígnia Lobo do Gelo Grau 6
17922	Armadura de Pelame de Leão
17943	Punho de Pedra
17962	Saco Azul de Gemas
17963	Saco Verde de Gemas
17964	Saco Cinza de Gemas
17965	Saco Amarelo de Gemas
17966	Mochila de Pelego da Onyxia
17967	Escama da Onyxia Refinada
17968	Escama da Onyxia Carregada
17969	Saco Vermelho de Gemas
17982	Núcleo de Ragnaros
18022	Selo Real de Alexis
18023	Pingente de Rubi Sangue
18042	Flecha com Ponteira de Tório
18043	Botas do Minerador de Carvão
18044	Caneco do Hurley
18045	Filé Macio de Lobo
18046	Receita: Filé Macio de Lobo
18047	Pisa-chamas
18048	Martelo do Mestre Ferreiro
18082	Bengala Aperreante do Zum'rah
18083	Guantes de Jumanza
18102	Botas de Ginete do Dragão
18103	Elo da Ruminação
18104	Cinturão Torrente Feral
18142	Cabeça Decepada de Elfo Noturno
18143	Tufo de Cabelo de Gnomo
18144	Lasca de Osso Humano
18145	Casco de Tauren
18146	Mojo de Troll Lançanegra
18147	Coração Renegado
18148	Crânio de Korrak
18149	Runa de Revocação
18150	Runa de Revocação
18151	Frasco de Ametista Cheio
18152	Frasco de Ametista
18153	Gema Vermelha Moro'gai
18154	Timbre da Blizzard
18155	Gema Azul Moro'gai
18156	Gema Verde Moro'gai
18157	Gema Preta Moro'gai
18158	Gema Dourada Moro'gai
18159	Gema Branca Moro'gai
18160	Receita: Chá de Cardo
18168	Disco de Força Reativa
18169	Dragonas Flamejantes da Aurora
18170	Dragonas Gélidas da Aurora
18171	Dragonas Arcanas da Aurora
18172	Dragonas Naturais da Aurora
18173	Dragonas Sombrias da Aurora
18182	Dragonas Cromáticas da Aurora
18202	Garra Esquerda de Eskhandar
18203	Garra Direita de Eskhandar
18204	Pelagem de Eskhandar
18205	Coleira de Eskhandar
18206	Espinha de Anão
18207	Dente de Orc
18208	Clâmide de Bênção
18209	Vela de Ignição Energizada
18222	Cipó Espinhoso
18223	Pétala Serrilhada
18224	Raiz de Açoitadeira
18225	Sapatos de Corrida Usados
18226	Um Pacto Selado
18227	Chupeta Gasta
18228	Foto Autografada de Tigule
18229	Supremo Guia de Pesca do Nat Pagle
18230	Botão J.A.G.A.N.H.E.I. Quebrado
18231	Camiseta Sem Manga
18232	Robô de Reparos em Campo 74A
18233	Lenço Borrado de Lágrimas
18234	Documento da Importadora Pau-de-fogo
18235	Diagrama: Robô de Reparos em Campo 74A
18236	Brinquedinho de Morder dos Gordok
18237	Mandíbula de Mastim
18238	Luvas de Couro Sombrio
18239	Molde: Luvas de Couro Sombrio
18240	Tanino Ôgrico
18241	Bridão de Corcel de Guerra Preto
18242	Rédeas do Tigre de Guerra Preto
18243	Tanquestruz Preto
18244	Carneiro de Guerra Preto
18245	Trompa do Lobo de Guerra Preto
18246	Apito do Raptor de Guerra Preto
18247	Kodo de Guerra Preto
18248	Cavalo de Guerra Descarnado Vermelho
18249	Chave do Crescente
18250	Chave dos Grilhões dos Gordok
18251	Kit de Armadura do Núcleo
18252	Molde: Kit de Armadura do Núcleo
18253	Poção Elevada de Rejuvenescimento
18254	Escondidinho de Batata Rataplã
18255	Batata Rataplã
18256	Ampola Imbuída
18257	Receita: Poção Elevada de Rejuvenescimento
18258	Traje de Ogro Gordok
18259	Fórmula: Encantamento de Poder Mágico - Arma
18260	Fórmula: Encantamento de Poder de Cura - Arma
18261	Livro de Encantamentos
18262	Pedra de Afiar Elemental
18263	Braceletes do Núcleo Flamífero
18264	Instruções: Pedra de Afiar Elemental
18265	Molde: Braceletes do Núcleo Flamífero
18266	Chave do Pátio dos Gordok
18267	Receita: Escondidinho de Batata Rataplã
18268	Chave da Porta de Dentro dos Gordok
18269	Grogue Verde dos Gordok
18282	Rifle Nuclear de Atirador Perito
18283	Precisoscópio 247x128 Biznicks
18284	Engasga-gato do Kreeg
18285	Estilhaço de Mana Cristalizado
18286	Fragmento de Mana Condensado
18287	Amargosa
18288	Calibrina de Melaço
18289	Colar de Espinhos
18290	Diagrama: Precisoscópio 247x128 Biznicks
18291	Diagrama: Disco de Força Reativa
18292	Diagrama: Rifle Nuclear de Atirador Perito
18294	Elixir de Respiração Aquática Maior
18295	Botas Evanescentes
18296	Embraces do Atirador Perito
18297	Semente de Espinim
18298	Perneiras Desenfreadas
18299	Essência de Rebentágua
18300	Néctar de Hyjal
18301	Varinha de Letendris
18302	Elo de Vigor
18303	Broquel Ligeiro
18304	Malha de Raiz Verde
18305	Guarda-pernas Rompe-água
18306	Luvas das Brumas Lúgubres
18307	Sapatos do Rasgamar
18308	Chapéu Esperto
18309	Luvas de Restauração
18310	Facão do Diabo
18311	Bastão de Canalização Quel'dorai
18312	Guarda-peito Energizado
18313	Elmo de Atenção
18314	Anel do Logro Demoníaco
18315	Anel de Potência Demoníaca
18316	Adorno de Obsidiana
18317	Talismã da Tempestade
18318	Grevas Misericordiosas
18319	Elmo Fervente
18320	Espaldares do Coração Demoníaco
18321	Bastão Energético
18322	Botas da Tromba d'Água
18323	Arco do Sátiro
18324	Corta-onda
18325	Casquete de Couro Vil
18326	Manoplas-navalha
18327	Cordão de Vinhaçoite
18328	Manto do Bosque das Sombras
18329	Arcano de Rapidez
18330	Arcano de Concentração
18331	Arcano de Proteção
18332	Incunábulo de Rapidez
18333	Incunábulo de Concentração
18334	Incunábulo de Proteção
18335	Diamante Preto Límpido
18336	Manoplas do Poder de Gordok
18337	Braçadeiras Órficas
18338	Varinha de Potência Arcana
18339	Manto Eidolon
18340	Talismã Eidolon
18341	Faixa Quel'dorai
18342	Guarda Quel'Dorai
18343	Elo Petrificado
18344	Manoplas Litocasca
18345	Anel Murmurante
18346	Calças Surradas
18347	Machado Bem Equilibrado
18348	Quel'Serrar
18349	Manoplas de Precisão
18350	Manto Amplificador
18351	Braçadeiras Magicamente Seladas
18352	Escudo de Casca Petrificada
18353	Cajado de Florpétrea
18354	Colar do Diabretão
18355	Colar de Fera
18356	Garona: Um Estudo sobre Furtividade e Traição
18357	Códice de Defesa
18358	Livro de Receitas do Arcanista
18359	A Luz e Como Ativá-la
18360	Sombras Agrilhoantes
18361	A Grande Corrida dos Caçadores
18362	Caçarolas: O Que a Luz Não lhe Contará
18363	O Choque Gélido e Você
18364	Sonho Esmeralda
18365	Exemplar Lido até o Final de "A Pesca Radical de Nat Pagle"
18366	Protetores de Mão de Gordok
18367	Manoplas de Gordok
18368	Luvas de Gordok
18369	Mitenes de Gordok
18370	Patuá da Cautela
18371	Talismã Destrava-mentes
18372	Lâmina da Lua Nova
18373	Guarda-peito da Tranquilidade
18374	Omoplatas Chamuscadas
18375	Braçadeiras do Eclipse
18376	Maça Envelhecida
18377	Luvas do Saca-rápido
18378	Perneiras de Luaprata
18379	Grevas Detestáveis
18380	Coxotes Reforçados Sobrenaturais
18381	Pingente do Mau Olhado
18382	Manto de Flutuação
18383	Manoplas Imbuídas em Força
18384	Espaldares Gravados com Bile
18385	Veste da Noite sem Fim
18386	Calças do Padre
18387	Luvas Fagulhantes
18388	Quebra-pedra
18389	Manto do Cosmos
18390	Perneiras de Líquen Emaranhado
18391	Cordão do Olho Furtivo
18392	Adaga de Distração
18393	Vínculo de Lenhatorta
18394	Munhequeiras do Uivo Demoníaco
18395	Anel Flamejante de Esmeralda
18396	Entalhador de Mentes
18397	Pingente de Mago Ancião
18398	Argola das Marés
18399	Brisa Oceânica
18400	Anel da Pedra Viva
18401	Compêndio do Abate de Dragões de Nostro
18402	Anel de Cristal Faiscante
18403	Sinete do Mata-dragões
18404	Pingente de Dente de Onyxia
18405	Cinto do Arquimago
18406	Talismã de Sangue de Onyxia
18407	Luvas de Tecido Vil
18408	Luvas Inferno
18409	Luvas de Lunatrama
18410	Espada do Velocista
18411	Botas Vivazes
18412	Fragmento de Núcleo
18413	Manto de Proteção
18414	Molde: Cinto do Arquimago
18415	Molde: Luvas de Tecido Vil
18416	Molde: Luvas Inferno
18417	Molde: Luvas de Lunatrama
18418	Molde: Manto de Proteção
18420	Esmaga-ossos
18421	Elmo de Madeira da Costa
18422	Cabeça da Onyxia
18423	Cabeça da Onyxia
18424	Botas de Junco
18425	Caneco de Cerveja do Kreeg
18426	Teia de Letendris
18427	Manto do Sargento
18428	Insígnia do Primeiro-sargento
18429	Braçadeiras de Placa do Primeiro-sargento
18430	Braçadeiras de Placa do Primeiro-sargento
18432	Munhequeiras de Malha do Primeiro-sargento
18434	Guarda-braços de Couro de Dragão do Primeiro-sargento
18435	Guarda-braços de Couro do Primeiro-sargento
18436	Guarda-braços de Couro de Dragão do Primeiro-sargento
18437	Manilhas de Seda do Primeiro-sargento
18438	Insígnia de Sargento
18440	Capa do Sargento
18441	Capa do Sargento
18442	Insígnia do Sargento-mor
18443	Insígnia do Sargento-mor
18444	Insígnia do Sargento-mor
18445	Munhequeiras de Placa do Sargento-mor
18447	Munhequeiras de Placa do Sargento-mor
18448	Guarda-braços Encadeados do Sargento-mor
18449	Guarda-braços Encadeados do Sargento-mor
18450	Veste de Combustão
18451	Cinto de Pelego de Hiena
18452	Braçadeiras de Couro do Sargento-mor
18453	Braçadeiras de Couro do Sargento-mor
18454	Braçadeiras de Couro de Dragão do Sargento-mor
18455	Braçadeiras de Couro de Dragão do Sargento-mor
18456	Manilhas de Seda do Sargento-mor
18457	Manilhas de Seda do Sargento-mor
18458	Guarda-braços Discretos
18459	Munhequeiras do Nobre
18460	Bazuca Rudimentar
18461	Manto do Sargento
18462	Soqueira de Osso Serrilhada
18463	Punhal Ogro
18464	Anel Nasal dos Gorgok
18465	Selo Real de Eldre'Thalas
18466	Selo Real de Eldre'Thalas
18467	Selo Real de Eldre'Thalas
18468	Selo Real de Eldre'Thalas
18469	Selo Real de Eldre'Thalas
18470	Selo Real de Eldre'Thalas
18471	Selo Real de Eldre'Thalas
18472	Selo Real de Eldre'Thalas
18473	Selo Real de Eldre'Thalas
18475	Cinto Estranhamente Mágico
18476	Botas Manchadas de Lama
18477	Perneiras Felpadas
18478	Gibão de Pelego de Hiena
18479	Elmo do Escorpídeo Carniceiro
18480	Elmo de Placa do Escaravelho
18481	Maça Quebra-crânio
18482	Lançador Ogro de Palitos
18483	Varinha Canalizadora de Mana
18484	Lâmina de Ez'Magg
18485	Escudo do Observador
18486	Veste de Lunatrama
18487	Molde: Veste de Lunatrama
18488	Lâmina Ancestral Incandescente
18489	Lâmina Ancestral Virgem
18490	Capuz Perceptivo
18491	Espiral do Saber
18492	Lâmina Ancestral Temperada
18493	Espaldares de Ferro Volumosos
18494	Omoplatas do Vigia do Covil
18495	Manto do Reduto
18496	Manto Heliotrópico
18497	Munhequeiras Sublimes
18498	O Podador
18499	Escudo de Barreira
18500	Anel Élfico Manchado
18501	Lasca de Vinhavil
18502	Glaive Monstruosa
18503	Guarda-peito de Kebrapaw
18504	Cinturão da Percepção
18505	Cinto do Trombadinha
18506	Botas do Mangusto
18507	Botas da Lua Cheia
18508	Braçadeiras do Voo Veloz
18509	Manto Cromático
18510	Pelego da Natureza
18511	Manto Cambiante
18512	Ácido Larval
18513	Lâmina Élfica Lisa e Cega
18514	Molde: Cinturão da Percepção
18515	Molde: Botas do Mangusto
18516	Molde: Braçadeiras do Voo Veloz
18517	Molde: Manto Cromático
18518	Molde: Pelego da Natureza
18519	Molde: Manto Cambiante
18520	Lâmina Bárbara
18521	Botas de Metal Sujas
18522	Elo do Rei Ogro
18523	Pedra Cintilando Fulgurantemente
18524	Perneiras da Destruição
18525	Braçadeiras de Prosperidade
18526	Coroa do Rei Ogro
18527	Manoplas Harmoniosas
18528	Espaldares Ciclônicos
18529	Cinturão Elemental de Placa
18530	Cota Forjada pelos Ogros
18531	Malho Inexorável
18532	Veste da Onda Mental
18533	Braçadeiras de Poder dos Gordok
18534	Bastão dos Magos Ogros
18535	Escudo de Milli
18536	Léxico de Milli
18537	Magnetita de Contra-ataque
18538	Perdição do Arvoroso
18539	Relicário da Pureza
18540	Relicário da Pureza Selado
18541	Capa Pujante
18542	Tufão
18543	Elo da Entropia
18544	Manoplas de Couro da Perdição
18545	Perneiras da Supremacia Arcana
18546	Jaula Craniana Infernal
18547	Cinturão de Gelo que não Derrete
18562	Minério de Elemêntio
18563	Grilhões do Perseguidor dos Ventos
18564	Grilhões do Perseguidor dos Ventos
18567	Fluxo Elemental
18582	As Lâminas Gêmeas de Azzinoth
18583	Glaive de Guerra de Azzinoth (Direita)
18584	Glaive de Guerra de Azzinoth (Esquerda)
18585	Elo da Lealdade
18586	Círculo do Solárbol
18587	Cabo de Chupeta Goblínico XG
18588	Dinamite Taca-fácil II
18590	Sangue de Fera em Fúria
18591	Caixote de Sangue
18592	Instruções: Martelo de Sulfuron
18594	Carga Poderosa de Cequatrum
18595	Opala de Sangue
18597	Apito de Órfão Orc
18598	Apito de Órfão Humano
18600	Tomo de Inteligência Arcana
18601	Prisão de Cristal Faiscante
18602	Tomo do Sacrifício
18603	Sangue de Sátiro
18604	Lágrimas dos Hederine
18605	Demonarca Aprisionado
18606	Estandarte de Batalha da Aliança
18607	Estandarte de Batalha da Horda
18608	Bênção
18609	Anátema
18610	Facão Afiado
18611	Perneiras Masca-pinho
18612	Botas Encadeadas Ensanguentadas
18622	Essência Vil Impecável (Jaedenar)
18623	Essência Vil Impecável (Portal Negro)
18624	Essência Vil Impecável (Azshara)
18625	Âmago Infernal de Kroshius
18626	Fogo Vil
18627	Gongo de Defimura
18628	Contrato da Irmandade do Tório
18629	Magnetita Preta
18630	Feixe de Luz do Juízo Final
18631	Transformador Veraprata
18632	Puxa-puxa do Tumulto do Arroio da Lua
18633	Pirulito Azedo da Stilosa
18634	Refletor de Gelo Girogélido
18635	Barrinha da Bellara
18636	Cabo de Chupeta Arruinado XG
18637	Rebotocador Maior
18638	Refletor de Chamas Hiper-radiante
18639	Refletor de Sombras Ultrafulgurante
18640	Rocha Alegre e Divertida
18641	Dinamite Densa
18642	Autógrafo da Jaina
18643	Impressão do Casco de Caerne
18645	Alarmobô Gnômico
18646	O Olho da Divindade
18647	Diagrama: Fogos de Artifício Vermelhos
18648	Diagrama: Fogos de Artifício Verdes
18649	Diagrama: Fogos de Artifício Azuis
18650	Diagrama: Dinamite Taca-fácil II
18651	Diagrama: Transformador Veraprata
18652	Diagrama: Refletor de Gelo Girogélido
18653	Diagrama: Cabo de Chupeta Goblínico XG
18654	Diagrama: Alarmobô Gnômico
18655	Diagrama: Rebotocador Maior
18656	Diagrama: Carga Poderosa de Cequatrum
18657	Diagrama: Refletor de Chamas Hiper-radiante
18658	Diagrama: Refletor de Sombras Ultrafulgurante
18659	Lasca de Nordrassil
18660	Aumentador de Mundo
18661	Diagrama: Aumentador de Mundo
18662	Bola de Couro Pesado
18663	Jarra do Jivil
18664	Um Tratado sobre Patentes Militares
18665	A Visão das Sombras
18670	Glifos Zorothianos
18671	Cetro do Barão Charr
18672	Brasa Elemental
18673	Pelego Pétreo de Avalanchion
18674	Elo Endurecido de Pedra
18675	Patentes Militares da Horda e da Aliança
18676	Faixa do Teceventos
18677	Manto do Zéfiro
18678	Colar Congelado de Tempestria
18679	Anel Frígido
18680	Arco de Ossos Antigos
18681	Xale de Enterro
18682	Perneiras de Pele de Carniçal
18683	Martelo das Vésperas
18684	Anel Fracamente Irisado
18686	Omoplatas de Golem Ósseo
18687	Poeira Estelar Zorotiana
18688	Diabrete numa Jarra
18689	Manto Fantasmal
18690	Perneiras Placa da Ira
18691	Pingente do Conselheiro Sombrio
18692	Escarpes do Cavaleiro da Morte
18693	Mitenes Tremelicantes
18694	Grevas Sombrias de Malha
18695	Tomo Enfeitiçado
18696	Escudo com Runas Intricadas
18697	Sapatilhas Petrálgida
18698	Capuz de Couro Esfarrapado
18699	Espaldares da Tumba Gélida
18700	Braçadeiras Maléficas
18701	Elo Enervante
18702	Cinto do Ordenado
18703	Folha Antiga Petrificada
18704	Tendão de Dragão Azul Maduro
18705	Tendão de Dragão Negro Maduro
18706	Mestre da Arena
18707	Báculo Antigo Cinzelado com Runas
18708	Casca Petrificada
18709	Munhequeiras da Arena
18710	Braceleiras da Arena
18711	Embraces da Arena
18712	Avambraços da Arena
18713	Rhok'delar, Arco Longo dos Guardiões Antigos
18714	Lâmina Embrulhada de Tendão Antigo
18715	Lok'delar, Báculo dos Guardiões Antigos
18716	Botas Cobertas de Cinza
18717	Martelo do Grande Cruzado
18718	Elmo do Grão-cruzado
18719	O Coração do Traidor
18720	Mortalha dos Nathrezim
18721	Cinturão da Barragem
18722	Guantes da Morte
18723	Colar Encadeado Animado
18724	Tendão de Dragão Negro Encantado
18725	Pacificador
18726	Manilhas do Magistrado
18727	Chapéu de Feltro Carmesim
18728	Herança de Anastari
18729	Arco Guinchador
18730	Mitenes de Renda Sombria
18731	Molde: Bola de Couro Pesado
18734	Manto da Lua Pálida
18735	Palmilhas de Maleki
18736	Perneiras do Cão Pestilento
18737	Machadinha Corta-osso
18738	Besta de Espinha de Carapaça
18739	Guarda-pernas de Placa Quitinoso
18740	Faixa de Thuzadin
18741	Braçadeiras de Morlune
18742	Guarda-ombros da Milícia de Stratholme
18743	Capa Graciosa
18744	Luvas de Pele de Quiróprago
18745	Perneiras de Tecido Sagrado
18746	Cristal Divinatório
18749	Alma Perdida do Corcel
18752	Incensório de Exorcismo
18753	Barda de Arcanita
18754	Braçadeiras de Têmpera Vil
18755	Corcel Medonho Zorothiano
18756	Protetor do Deimoguarda
18757	Dragonas Diabólicas
18758	Lâmina do Espectro
18759	Machado Malicioso
18760	Anel Necromântico
18761	Toque do Oblívio
18762	Estilhaço da Chama Verde
18766	Rédeas do Sabre-de-gelo Veloz
18767	Rédeas do Sabre-das-brumas Veloz
18768	Rédeas do Sabre-da-aurora Veloz
18769	Malha de Placas de Tório Encantado
18770	Malha de Placas de Tório Encantado
18771	Malha de Placas de Tório Encantado
18772	Mecanostruz Verde Veloz
18773	Mecanostruz Branco Veloz
18774	Mecanostruz Amarelo Veloz
18775	Ração de Cavalo Enriquecida com Maná
18776	Baio Veloz
18777	Corcel Castanho Veloz
18778	Corcel Branco Veloz
18779	Metade Inferior de Forja Avançada de Armaduras: Volume I
18780	Metade Superior de Forja Avançada de Armaduras: Volume I
18781	Metade Inferior de Forja Avançada de Armaduras: Volume II
18782	Metade Superior de Forja Avançada de Armaduras: Volume II
18783	Metade Inferior de Forja Avançada de Armaduras: Volume III
18784	Metade Superior de Forja Avançada de Armaduras: Volume III
18785	Carneiro Branco Veloz
18786	Carneiro Marrom Veloz
18787	Carneiro Cinza Veloz
18788	Raptor Azul Veloz
18789	Raptor Oliva Veloz
18790	Raptor Laranja Veloz
18791	Cavalo de Guerra Descarnado Roxo
18792	Barda de Arcanita Abençoada
18793	Grande Kodo Branco
18794	Grande Kodo Marrom
18795	Grande Kodo Cinza
18796	Trompa do Lobo Marrom Veloz
18797	Trompa do Lobo Silvestre Veloz
18798	Trompa do Lobo Cinza Veloz
18799	Alma Redimida do Corcel
18802	Poção Sombria
18803	Draga de Lava com Isolamento Hipertérmico
18804	Algibeira de Lorde Grayson
18805	Dente de Cão-magma
18806	Grevas Forjadas no Núcleo
18807	Elmo do Poder Latente
18808	Luvas da Chama Hipnótica
18809	Faixa dos Segredos Sussurrados
18810	Espaldares do Crescimento Silvestre
18811	Manto à Prova de Fogo
18812	Munhequeiras do Voo Constante
18813	Anel do Vínculo
18814	Gargantilha do Senhor do Fogo
18815	Essência da Chama Pura
18816	Lâmina da Perdição
18817	Coroa da Destruição
18818	Instruções de Mor'zul
18819	Incensório de Exorcismo de Rohan
18820	Talismã do Poder Efêmero
18821	Anel do Golpe Presto
18822	Lâmina Afiada Obsidiana
18823	Luvas Velhas de Couro do Núcleo
18824	Botas Temperadas no Magma
18825	Égide do Grão-marechal
18826	Muralha de Escudos do Sumo Senhor da Guerra
18827	Machado de Mão do Grão-marechal
18828	Cutelo do Sumo Senhor da Guerra
18829	Espaldares da Terra Profunda
18830	Talho do Grão-marechal
18831	Machado de Batalha do Sumo Senhor da Guerra
18832	Lâmina da Brutalidade
18833	Disparo Certeiro do Grão-marechal
18834	Insígnia da Horda
18835	Arco Recurvo do Sumo Senhor da Guerra
18836	Besta de Repetição do Grão-marechal
18837	Besta do Sumo Senhor da Guerra
18838	Punhal do Grão-marechal
18839	Poção de Combate de Cura
18840	Navalha do Sumo Senhor da Guerra
18841	Poção de Combate de Mana
18842	Cajado de Dominância
18843	Lâmina Destra do Grão-marechal
18844	Garra Direita do Sumo Senhor da Guerra
18845	Insígnia da Horda
18846	Insígnia da Horda
18847	Lâmina Sinistra do Grão-marechal
18848	Garra Esquerda do Sumo Senhor da Guerra
18849	Insígnia da Horda
18850	Insígnia da Horda
18851	Insígnia da Horda
18852	Insígnia da Horda
18853	Insígnia da Horda
18854	Insígnia da Aliança
18855	Canhão de Mão do Grão-marechal
18856	Insígnia da Aliança
18857	Insígnia da Aliança
18858	Insígnia da Aliança
18859	Insígnia da Aliança
18860	Abre-alas do Sumo Senhor da Guerra
18861	Coxotes do Ardilante
18862	Insígnia da Aliança
18863	Insígnia da Aliança
18864	Insígnia da Aliança
18865	Castigador do Grão-marechal
18866	Porrete do Sumo Senhor da Guerra
18867	Martelo de Batalha do Grão-marechal
18868	Pulverizador do Sumo Senhor da Guerra
18869	Glaive do Grão-marechal
18870	Elmo do Vivificador
18871	Dessangrador do Sumo Senhor da Guerra
18872	Perneiras da Tempestade de Mana
18873	Báculo do Grão-marechal
18874	Cajado de Guerra do Sumo Senhor da Guerra
18875	Calças de Escama de Salamandra
18876	Espadão do Grão-marechal
18877	Montante do Sumo Senhor da Guerra
18878	Punhal do Feiticeiro
18879	Anel Pesado de Ferro Negro
18880	Cabeça de Noctilatrus
18902	Rédeas do Sabre-do-trovão Veloz
18904	Ultra-encolhedor de Zorbin
18922	Instruções Secretas: Fluxo Ígneo
18942	Fluxo Ígneo
18943	Travesseiro de Ferro Negro
18944	Escama de Incendossauro
18945	Resíduo de Ferro Negro
18946	Cabeça do Feitor Maltorius
18947	Pelego de Yeti Cortifúria
18948	Braçadeiras Barbarescas
18949	Molde: Braçadeiras Barbarescas
18950	Travesseiro da Camareira Alma Fada
18951	Travesseiro de Aterrissagem de Evonice
18952	Cabeça da Simone
18953	Cabeça do Klinfran
18954	Cabeça do Solenor
18955	Cabeça do Artorius
18956	Resíduo de Miniaturização
18957	Lâmina Matagal
18958	Âmago do Elemental de Água
18959	Alcaraviz de Ferraria
18960	Luneta do Espia
18961	Carapaça de Zukk'ash
18962	Glândulas de Cravaçoite
18963	Ovo de Tartaruga (Albina)
18964	Ovo de Tartaruga (Marítima)
18965	Ovo de Tartaruga (Falconil)
18966	Ovo de Tartaruga (De Couro)
18967	Ovo de Tartaruga (Verde-oliva)
18969	Pelego Imaculado de Yeti
18972	Pelego Perfeito de Yeti
18984	Estripador Dimensional - Visteterna
18986	Transportador Ultrasseguro: Geringontzan
18987	Comando do Mão Negra
19002	Cabeça de Nefarian
19003	Cabeça de Nefarian
19004	Pedra de Vida Menor
19005	Pedra de Vida Menor
19006	Pedra de Vida Inferior
19007	Pedra de Vida Inferior
19008	Pedra de Vida
19009	Pedra de Vida
19010	Pedra de Vida Maior
19011	Pedra de Vida Maior
19012	Pedra de Vida Elevada
19013	Pedra de Vida Elevada
19016	Casulo de Renascimento
19017	Essência do Senhor do Fogo
19018	Lâmina Latente Beijada pelo Vento
19019	Tormentária, Lâmina Sagrada do Perseguidor dos Ventos
19020	Relatório sobre Zukk'ash da Aldeia Mojache
19022	Vara de pescar suprema FC-5000 do Nat Pagle
19023	Melhor Isca de Katum
19024	Grande Mestre da Arena
19025	Pluma de Senhor Celeste
19026	Rojão Rabo-de-cobra
19027	Diagrama: Rojão Rabo-de-cobra
19028	Vestido Elegante
19029	Trompa de Uivador Lobo do Gelo
19030	Carneiro de Batalha Lançatroz
19031	Tabardo de Batalha dos Lobo do Gelo
19032	Tabardo de Batalha dos Lançatroz
19033	Ferramentas Perdidas de Escoriárvore
19034	Almoço do Banha
19035	Cesta de Piquenique Especial do Banha
19036	Mensagem Final para os Martelo Feroz
19037	Espaldares Pico da Esmeralda
19038	Anel da Sutileza
19039	Chapéu à Prova d'Água de Zorbin
19040	Mega-fatiador de Zorbin
19041	Túnica Artesanal de Pradal
19042	Túnica Artesanal de Jangdor
19043	Cinto Pesado dos Presamatos
19044	Poder dos Presamatos
19045	Estandarte de Batalha Lançatroz
19046	Estandarte de Batalha do Lobo do Gelo
19047	Sabedoria dos Presamatos
19048	Botas Pesadas dos Presamatos
19049	Soqueiras dos Presamatos
19050	Dragonas dos Presamatos
19051	Cinturão da Aurora
19052	Botinas da Aurora
19054	Red Dragon Orb
19055	Green Dragon Orb
19056	Botas Argênteas
19057	Luvas da Aurora
19058	Dragonas Douradas da Aurora
19059	Omoplatas Argênteas
19060	Ração Enriquecida da Ravina Brado Guerreiro
19061	Ração de Ferro da Ravina Brado Guerreiro
19062	Ração de Batalha da Ravina Brado Guerreiro
19064	Chave dos Grilhões
19065	Círculo Esmeraldino
19066	Bandagem de Runatrama da Ravina Brado Guerreiro
19067	Bandagem de Magitrama da Ravina Brado Guerreiro
19068	Bandagem de Seda da Ravina Brado Guerreiro
19069	Crânio do Guarda-caça Malkhor
19070	Ossos do Guarda-caça Malkhor
19071	Recipiente com Sangue Maculado
19083	Manto do Legionário Lobo do Gelo
19084	Manto do Soldado Lançatroz
19085	Manto do Conselheiro Lobo do Gelo
19086	Manto do Sábio Lançatroz
19087	Cinto de Placa dos Lobo do Gelo
19088	Cinto de Malha dos Lobo do Gelo
19089	Cinto de Couro dos Lobo do Gelo
19090	Cinto de Tecido dos Lobo do Gelo
19091	Cinturão de Placa Lançatroz
19092	Cinturão de Malha Lançatroz
19093	Cinturão de Couro Lançatroz
19094	Cinturão de Tecido Lançatroz
19095	Pingente do Legionário Lobo do Gelo
19096	Pingente do Conselheiro Lobo do Gelo
19097	Pingente do Soldado Lançatroz
19098	Pingente do Sábio Lançatroz
19099	Lâmina Glacial
19100	Adaga Eletrificada
19101	Cajado de Tormento Gélido
19102	Cajado Estalante
19103	Queimadura de Frio
19104	Martelo do Ataque da Tempestade
19105	Turbante de Geada Rúnica
19106	Lança Farpada de Gelo
19107	Sanguinário
19108	Varinha do Frio Penetrante
19109	Anel Bastante Enraizado
19110	Lâmina Forjada a Frio
19111	Palas de Invernacha
19112	Avambraços de Aço Congelado
19113	Braçadeiras de Pelego de Yeti
19114	Arco Montanhês
19115	Frasco de Mojo Florestal
19116	Mitenes Folhaverde
19117	Coxotes de Placa de Madeira Laqueada
19118	Alento da Natureza
19119	Luvas de Pelego de Feruja
19120	Runa do Capitão da Guarda
19121	Manto do Bosque Cerrado
19123	Mitenes Semprequentes
19124	Perneiras Plaquescória
19125	Cinturão Chamuscada de Malha
19126	Manoplas Plaquescória
19127	Túnica de Couro Esturricada
19128	Colete de Malha Chamuscado
19129	Veste Semprebrilha
19130	Ruptura do Gelo
19131	Sapatos Ceganeve
19132	Coroa Adornada de Cristais
19133	Perneiras Infusas em Vileza
19134	Cinto Esfolado de Demonarca
19135	Braçadeiras Luz Negra
19136	Cordão da Ignição de Mana
19137	Cinturão da Ofensiva
19138	Elo de Sulfuras
19139	Omoplatas da Guarda de Fogo
19140	Elo da Cauterização
19141	Bucha
19142	Grimório Rúnico de Fogo
19143	Manoplas da Guarda Ígnea
19144	Escarpes do Pisabrasa
19145	Veste do Poder Volátil
19146	Munhequeiras da Estabilidade
19147	Anel do Feitiço Poderoso
19148	Elmo Ferro Negro
19149	Cinto de Lava
19150	Kit de Sobrevivência Básico de Sentinela
19151	Kit de Sobrevivência Padrão de Sentinela
19152	Kit de Sobrevivência Avançado de Sentinela
19153	Kit de Sobrevivência Avançado de Pioneiro
19154	Kit de Sobrevivência Básico de Pioneiro
19155	Kit de Sobrevivência Padrão de Pioneiro
19156	Veste do Núcleo Flamífero
19157	Manoplas Cromáticas
19159	Colar de Hera Trançada
19160	Tabardo do Vencedor do Torneio
19162	Cinto do Cão do Núcleo
19163	Cinto Derretido
19164	Manoplas Ferro Negro
19165	Perneiras do Núcleo Flamífero
19166	Anistia Negra
19167	Fúria Negra
19168	Guarda Negra
19169	Martelo do Ocaso
19170	Mão de Ébano
19182	Cupom Premiado da Feira de Negraluna
19183	Areia de Ampulheta
19202	Instruções: Cinto Pesado dos Presamatos
19203	Instruções: Cinturão da Aurora
19204	Instruções: Botas Pesadas dos Presamatos
19205	Instruções: Luvas da Aurora
19206	Instruções: Elmo Ferro Negro
19207	Instruções: Manoplas Ferro Negro
19208	Instruções: Anistia Negra
19209	Instruções: Fúria Negra
19210	Instruções: Mão de Ébano
19211	Instruções: Guarda Negra
19212	Instruções: Martelo do Ocaso
19213	Talismã de Mérito da Asa de Prata
19215	Molde: Sabedoria dos Presamatos
19216	Molde: Botas Argênteas
19217	Molde: Omoplatas Argênteas
19218	Molde: Dragonas dos Presamatos
19219	Molde: Veste do Núcleo Flamífero
19220	Molde: Perneiras do Núcleo Flamífero
19221	Reserva Especial de Negraluna
19222	Cerveja Barata
19223	Salsichão de Negraluna
19224	Asinhas Apimentadas
19225	Caramelo Frito
19227	Ás de Feras
19228	Baralho de Feras
19229	Previsão do Malaby No. 1
19230	Dois de Feras
19231	Três de Feras
19232	Quatro de Feras
19233	Cinco de Feras
19234	Seis de Feras
19235	Sete de Feras
19236	Oito de Feras
19237	Previsão do Malaby No. 19
19238	Previsão do Malaby No. 3
19239	Previsão do Malaby No. 4
19240	Previsão do Malaby No. 5
19241	Previsão do Malaby No. 6
19242	Previsão do Malaby No. 7
19243	Previsão do Malaby No. 8
19244	Previsão do Malaby No. 9
19245	Previsão do Malaby No. 10
19246	Previsão do Malaby No. 11
19247	Previsão do Malaby No. 12
19248	Previsão do Malaby No. 13
19249	Previsão do Malaby No. 14
19250	Previsão do Malaby No. 15
19251	Previsão do Malaby No. 16
19252	Previsão do Malaby No. 18
19253	Previsão do Malaby No. 17
19254	Previsão do Malaby No. 21
19255	Previsão do Malaby No. 22
19256	Previsão do Malaby No. 2
19257	Baralho de Generais
19258	Ás de Generais
19259	Dois de Generais
19260	Três de Generais
19261	Quatro de Generais
19262	Cinco de Generais
19263	Seis de Generais
19264	Sete de Generais
19265	Oito de Generais
19266	Previsão do Malaby No. 20
19267	Baralho de Elementais
19268	Ás de Elementais
19269	Dois de Elementais
19270	Três de Elementais
19271	Quatro de Elementais
19272	Cinco de Elementais
19273	Seis de Elementais
19274	Sete de Elementais
19275	Oito de Elementais
19276	Ás de Portais
19277	Baralho de Portais
19278	Dois de Portais
19279	Três de Portais
19280	Quatro de Portais
19281	Cinco de Portais
19282	Seis de Portais
19283	Sete de Portais
19284	Oito de Portais
19287	Carta de Negraluna: Heroísmo
19288	Carta de Negraluna: Dragão Azul
19289	Carta de Negraluna: Voragem
19290	Carta de Negraluna: Espiral Etérea
19291	Caixote de Guardados de Negraluna
19292	Pernil de Carneiro do Mês Passado
19293	Pernil de Carneiro do Ano Passado
19295	Flor de Negraluna
19296	Prêmio Maior de Negraluna
19297	Prêmio Inferior de Negraluna
19298	Prêmio Menor de Negraluna
19299	Cara-Cola Espumante
19300	Água de Hibérnia Engarrafada
19301	Biscoito de Maná de Alterac
19302	Anel de Negraluna
19303	Colar de Negraluna
19304	Carne-seca Temperada
19305	Pé de Kodo em Conserva
19306	Rã Crocante
19307	Bandagem Grossa de Runatrama de Alterac
19308	Tomo de Dominação Arcana
19309	Tomo do Poder da Sombra
19310	Tomo do Senhor do Gelo
19311	Tomo de Arcano Abrasador
19312	Flores do Vivificador
19315	Toque de Therazane
19316	Flecha de Trama Gélida
19317	Bala de Trama Gélida
19318	Água Engarrafada da Fonte de Alterac
19319	Aljava de Pelego de Harpia
19320	Bandoleira de Pele de Gnoll
19321	O Objeto Inamovível
19322	Marca de Honra da Ravina Brado Guerreiro
19323	A Força Incontrolável
19324	O Lobotomizador
19325	Elo de Dom Julio
19326	Molde: Poder dos Presamatos
19327	Molde: Soqueiras dos Presamatos
19328	Molde: Botinas da Aurora
19329	Molde: Dragonas Douradas da Aurora
19330	Molde: Cinto de Lava
19331	Molde: Manoplas Cromáticas
19332	Molde: Cinto do Cão do Núcleo
19333	Molde: Cinto Derretido
19334	A Lâmina Indomável
19335	Quebra-espinha
19336	Gema Arcana Infusa
19337	O Livro Preto
19338	Vale-cupom
19339	Gema do Pensapresto
19340	Runa da Metamorfose
19341	Gema da Vivificação
19342	Totem Peçonhento
19343	Pergaminhos de Luz Cegante
19344	Cristal de Alinhamento Natural
19345	Égide de Preservação
19346	Lâmina Dendragônia
19347	Garra de Cromaggus
19348	Protetor de Escama de Dragão Vermelho
19349	Baluarte Reforçado de Elemêntio
19350	Furapeito
19351	Maladath, Lâmina Rúnica da Revoada Negra
19352	Espada Temperada Cromaticamente
19353	Cutelo de Garra de Draco
19354	Vingador Dracônico
19355	Cajado de Foco da Asa Sombria
19356	Cajado da Chama Sombria
19357	Arauto do Sofrimento
19358	Marreta Dracônica
19360	Lok'amir il Romathis
19361	Ashjre'thul, Besta da Punição
19362	Gume da Perdição
19363	Crul'shorukh, Beira do Caos
19364	Ashkandi, Montante da Irmandade
19365	Garra do Draco Preto
19366	Orbe do Mestre Mata-dragões
19367	Toque do Dragão
19368	Carabina Bafo de Dragão
19369	Luvas da Rápida Evolução
19370	Dragonas do Conciliábulo do Asa Negra
19371	Pingente do Dragão Caído
19372	Elmo do Raiva Infinita
19373	Brafoneiras de Couraça Preta
19374	Braçadeiras da Precisão Arcana
19375	Mish'undare, Diadema do Esfolador Mental
19376	Anel do Discernimento de Archimtiros
19377	Talismã da Conspiração do Prestor
19378	Manto do Senhor da Prole
19379	Lágrima de Neltharion
19380	Elo de Therazane
19381	Botas da Chama Sombria
19382	Elo de Elemêntio Puro
19383	Medalhão do Mestre Mata-dragões
19384	Anel do Mestre Mata-dragões
19385	Perneiras Carregadas
19386	Manto Tecido com Elemêntio
19387	Botas Cromáticas
19388	Garra da Angelista
19389	Ombreiras de Couro de Dragão Retesado
19390	Luvas de Couro de Dragão Retesado
19391	Geta Cintilante
19392	Cinturão do Cruzado Caído
19393	Cinta Articulada do Primalista
19394	Brafoneiras de Garra de Draco
19395	Gema Rejuvenescedora
19396	Cinto de Couro de Dragão Retesado
19397	Anel de Rocha Negra
19398	Manto do Fogorja
19399	Veste Freixo Preto
19400	Amarra do Fogorja
19401	Guarda-pernas Articulados do Primalista
19402	Guarda-pernas do Cruzado Caído
19403	Elo da Concentração Forçada
19405	Baluarte Abençoado de Malfurion
19406	Talismã de Presa de Draco
19407	Luvas da Chama Ebânea
19422	Sorte da Feira de Negraluna
19423	Previsão do Malaby No. 23
19424	Previsão do Malaby No. 24
19425	Arca Misteriosa
19426	Orbe de Negraluna
19430	Mortalha do Pensamento Puro
19431	Escaravelho Iminente de Styleen
19432	Círculo da Força Aplicada
19433	Perneiras de Tecebrasa
19434	Elo do Domínio Sombrio
19435	Coletador de Essências
19436	Manto do Poder Dracônico
19437	Botas do Pensamento Puro
19438	Botas da Nevasca do Ringo
19439	Gibão Entrelaçado das Sombras
19440	Antipeçonha Poderoso
19441	Vesícula de Peçonha Enorme
19442	Fórmula: Antipeçonha Poderoso
19443	Previsão do Malaby No. 25
19444	Fórmula: Encantamento de Força - Arma
19445	Fórmula: Encantamento de Agilidade – Arma
19446	Fórmula: Encantamento de Regeneração de Mana - Braçadeiras
19447	Fórmula: Encantamento de Cura - Braçadeiras
19448	Fórmula: Encantamento Potente de Espírito - Arma
19449	Fórmula: Encantamento Potente de Intelecto - Arma
19450	Casinha de Jublinho
19451	Previsão do Malaby No. 26
19452	Previsão do Malaby No. 27
19453	Previsão do Malaby No. 28
19454	Previsão do Malaby No. 29
19462	Ovo de Jublinho
19482	Pelagem de Coelho Bel'arte
19483	Descascando a Cebola
19484	Alcachofra do Lobo do Gelo
19491	Amuleto de Negraluna
19505	Tabardo de Batalha do Brado Guerreiro
19506	Tabardo de Batalha da Asa de Prata
19507	Ombreiras do Inquisidor
19508	Braçadeiras de Couro Marcado
19509	Botas de Malha Empoeiradas
19510	Elo do Legionário
19511	Elo do Legionário
19512	Elo do Legionário
19513	Elo do Legionário
19514	Elo do Protetor
19515	Elo do Protetor
19516	Elo do Protetor
19517	Elo do Protetor
19518	Anel do Conselheiro
19519	Anel do Conselheiro
19520	Anel do Conselheiro
19521	Anel do Conselheiro
19522	Anel do Erudito
19523	Anel do Erudito
19524	Anel do Erudito
19525	Anel do Erudito
19526	Manto do Curandeiro de Batalha
19527	Manto do Curandeiro de Batalha
19528	Manto do Curandeiro de Batalha
19529	Manto do Curandeiro de Batalha
19530	Capa do Zelador
19531	Capa do Zelador
19532	Capa do Zelador
19533	Capa do Zelador
19534	Medalhão do Batedor
19535	Medalhão do Batedor
19536	Medalhão do Batedor
19537	Medalhão do Batedor
19538	Medalhão da Sentinela
19539	Medalhão da Sentinela
19540	Medalhão da Sentinela
19541	Medalhão da Sentinela
19542	Lâmina do Batedor
19543	Lâmina do Batedor
19544	Lâmina do Batedor
19545	Lâmina do Batedor
19546	Lâmina da Sentinela
19547	Lâmina da Sentinela
19548	Lâmina da Sentinela
19549	Lâmina da Sentinela
19550	Espada do Legionário
19551	Espada do Legionário
19552	Espada do Legionário
19553	Espada do Legionário
19554	Espada do Protetor
19555	Espada do Protetor
19556	Espada do Protetor
19557	Espada do Protetor
19558	Arco do Pioneiro
19559	Arco do Pioneiro
19560	Arco do Pioneiro
19561	Arco do Pioneiro
19562	Arco do Vanguardeiro
19563	Arco do Vanguardeiro
19564	Arco do Vanguardeiro
19565	Arco do Vanguardeiro
19566	Cajado Nodoso do Conselheiro
19567	Cajado Nodoso do Conselheiro
19568	Cajado Nodoso do Conselheiro
19569	Cajado Nodoso do Conselheiro
19570	Cajado do Erudito
19571	Cajado do Erudito
19572	Cajado do Erudito
19573	Cajado do Erudito
19574	Força de Mugamba
19575	Força de Mugamba
19576	Força de Mugamba
19577	Raiva de Mugamba
19578	Braçadeiras do Berserker
19579	Marca do Pagão
19580	Braçadeiras do Berserker
19581	Braçadeiras do Berserker
19582	Munhequeiras da Voz-do-vento
19583	Munhequeiras da Voz-do-vento
19584	Munhequeiras da Voz-do-vento
19585	Marca do Pagão
19586	Marca do Pagão
19587	Braçadeiras do Espreitador Florestal
19588	Marca do Herói
19589	Braçadeiras do Espreitador Florestal
19590	Braçadeiras do Espreitador Florestal
19591	Olho de Zuldazar
19592	Olho de Zuldazar
19593	Olho de Zuldazar
19594	Olho-que-tudo-vê de Zuldazar
19595	Braçadeiras da Dríade
19596	Braçadeiras da Dríade
19597	Braçadeiras da Dríade
19598	Cascalho de Jakaro
19599	Cascalho de Jakaro
19600	Cascalho de Jakaro
19601	Joia de Jakaro
19602	Mácula de Kezan
19603	Mácula de Kezan
19604	Mácula de Kezan
19605	Mácula Irrefreável de Kezan
19606	Visão de Vodúria
19607	Visão de Vodúria
19608	Visão de Vodúria
19609	Visão Imaculada de Vodúria
19610	Alga Encantada dos Mares do Sul
19611	Alga Encantada dos Mares do Sul
19612	Alga Encantada dos Mares do Sul
19613	Alga Encantada dos Mares do Sul Imaculada
19614	Talismã Sombrio Zandalariano
19615	Talismã Sombrio Zandalariano
19616	Talismã Sombrio Zandalariano
19617	Talismã Zandalariano de Domínio das Sombras
19618	Gavinha da Voragem
19619	Gavinha da Voragem
19620	Gavinha da Voragem
19621	Ira da Voragem
19642	iCoke Prize Voucher
19682	Colete Vinassangre
19683	Perneiras Vinassangre
19684	Botas Vinassangre
19685	Gibão Primevo de Pele de Morcego
19686	Luvas Primevas de Pele de Morcego
19687	Braçadeiras Primevas de Pele de Morcego
19688	Peitoral do Tigre Sangrento
19689	Omoplatas do Tigre Sangrento
19690	Peitoral Almassangre
19691	Omoplatas Almassangre
19692	Manoplas Almassangre
19693	Peitoral Almanegra
19694	Perneiras Almanegra
19695	Omoplatas Almanegra
19696	Pão da Colheita
19697	Recompensa da Colheita
19698	Moeda Zulian
19699	Moeda Razzashi
19700	Moeda Hakkari
19701	Moeda Gurubashi
19702	Moeda Ramatorpe
19703	Moeda Cascasseca
19704	Moeda Zangareia
19705	Moeda Rachacrânio
19706	Moeda Sanguescalpo
19707	Joia Hakkari Vermelha
19708	Joia Hakkari Azul
19709	Joia Hakkari Amarela
19710	Joia Hakkari Laranja
19711	Joia Hakkari Verde
19712	Joia Hakkari Roxa
19713	Joia Hakkari Brônzea
19714	Joia Hakkari Prateada
19715	Joia Hakkari Dourada
19716	Braçadeiras Hakkari Primevas
19717	Tala Hakkari Primeva
19718	Pilar Hakkari Primevo
19719	Cinturão Hakkari Primevo
19720	Faixa Hakkari Primeva
19721	Xale Hakkari Primevo
19722	Tabardo Hakkari Primevo
19723	Gibão Hakkari Primevo
19724	Égide Hakkari Primeva
19725	Caixa de Recursos Arathi
19726	Vinassangre
19727	Foice Sangrenta
19764	Molde: Colete Vinassangre
19765	Molde: Perneiras Vinassangre
19766	Molde: Botas Vinassangre
19767	Couro de Morcego Primevo
19768	Couro de Tigre Primevo
19769	Molde: Gibão Primevo de Pele de Morcego
19770	Molde: Luvas Primevas de Pele de Morcego
19771	Molde: Braçadeiras Primevas de Pele de Morcego
19772	Molde: Peitoral do Tigre Sangrento
19773	Molde: Omoplatas do Tigre Sangrento
19774	Almalita
19775	Saco Lazúli Lacrado
19776	Instruções: Peitoral Almassangre
19777	Instruções: Omoplatas Almassangre
19778	Instruções: Manoplas Almassangre
19779	Instruções: Peitoral Almanegra
19780	Instruções: Perneiras Almanegra
19781	Instruções: Omoplatas Almanegra
19782	Presença de Poder
19783	Signo do Sincretista
19784	Abraço da Morte
19785	Chamado do Falcão
19786	Abraço Protetor do Voduzeiro
19787	Presença de Visão
19788	Mandinga Azarenta
19789	Aura Profética
19790	Carícia do Animista
19802	Coração de Hakkar
19803	Veloso-azul-listrado do Rosado
19804	Peixe-carniçal Pálido
19805	Acará-bandeira
19806	Peixe-rainha Deziano
19807	Papa-fina-pintado
19808	Maciste Litoderme
19812	Runa da Aurora
19813	Boneca Vodu Perfurada
19814	Boneca Vodu Perfurada
19815	Boneca Vodu Perfurada
19816	Boneca Vodu Perfurada
19817	Boneca Vodu Perfurada
19818	Boneca Vodu Perfurada
19819	Boneca Vodu Perfurada
19820	Boneca Vodu Perfurada
19821	Boneca Vodu Perfurada
19822	Peitoral do Vindicante Zandalar
19823	Cinto do Vindicante Zandalar
19824	Braçadeiras do Vindicante Zandalar
19825	Peitoral do Livre-pensador Zandalar
19826	Cinto do Livre-pensador Zandalar
19827	Braçadeiras do Livre-pensador Zandalar
19828	Cota do Áugure Zandalar
19829	Cinto do Áugure Zandalar
19830	Braçadeiras do Áugure Zandalar
19831	Dragonas do Predador Zandalar
19832	Cinto do Predador Zandalar
19833	Braçadeiras do Predador Zandalar
19834	Túnica do Lunático Zandalar
19835	Dragonas do Lunático Zandalar
19836	Braçadeiras do Lunático Zandalar
19838	Túnica do Harúspice Zandalar
19839	Cinto do Harúspice Zandalar
19840	Braçadeiras do Harúspice Zandalar
19841	Dragonas do Confessor Zandalar
19842	Cinturão do Confessor Zandalar
19843	Braçadeiras do Confessor Zandalar
19845	Dragonas do Ilusionista Zandalar
19846	Bracelete do Ilusionista Zandalar
19848	Braçadeiras do Demoníaco Zandalar
19849	Dragonas do Demoníaco Zandalar
19850	Tributo de Uther
19851	Tributo de Grom
19852	Antigo Matador de Homens Hakkari
19853	Destruidor Gurubashi de Anões
19854	Zin'rokh, a Destruidora de Mundos
19855	Coxotes Banhados em Sangue
19856	Olho de Hakkar
19857	Manto da Consumição
19858	Emblema Honorífico de Zandalar
19859	Presas dos Sem-rosto
19861	Toque do Caos
19862	Égide do Deus Sangrento
19863	Selo do Primalista
19864	Chama-sangue
19865	Lâmina de Guerra dos Hakkari
19866	Lâmina de Guerra dos Hakkari
19867	Defensor do Sangrelorde
19869	Manoplas Banhadas em Sangue
19870	Manto do Loa Hakkari
19871	Talismã de Proteção
19872	Raptor Razzashi Veloz
19873	Anel Carmesim do Lorde Supremo
19874	Alabarda de Punição
19875	Coifa Manchada de Sangue
19876	Colar do Corruptor de Almas
19877	Perneiras do Animista
19878	Brafoneiras Banhadas em Sangue
19880	Coleção de Cabeças de Gurubashi
19881	Cabeça do Canalizador
19882	Cabeça do Bagateiro
19883	Cordão Sagrado
19884	Julgamento de Jin'do
19885	Mau Olhado de Jin'do
19886	Mantel do Bagateiro
19887	Coxotes Manchados de Sangue
19888	Abraço do Lorde Supremo
19889	Perneiras Banhadas em Sangue
19890	Martelo de Jin'do
19891	Saco de Sortilégios de Jin'do
19892	Botas do Animista
19893	Selo de Zanzil
19894	Manoplas Banhadas em Sangue
19895	Kilt Tinto de Sangue
19896	Soqueira do Thekal
19897	Botas do Traidor
19898	Selo de Jin
19899	Guarda-pernas Rituais
19900	Martelo de Pedra Zulian
19901	Fatiador Zulian
19902	Tigre Zulian Veloz
19903	Presas de Venoxis
19904	Cota Rúnica Manchada de Sangue
19905	Anel de Zanzil
19906	Pisantes Banhados em Sangue
19907	Manto de Pele de Tigre Zulian
19908	Cetro de Punição
19909	Propósito de Arlokk
19910	Soqueira da Arlokk
19911	Coração Chicotalga
19912	Anel de Ônix do Lorde Supremo
19913	Grevas Banhadas em Sangue
19914	Bolsa de Pelego de Pantera
19915	Defensor Zulian
19918	Esmagador da Jeklik
19919	Grevas Manchadas de Sangue
19920	Anel do Primalista
19921	Machado Zulian
19922	Bastão Azarento da Arlokk
19923	Talismã de Opalina da Jeklik
19925	Anel de Jin
19927	Toque da Mar'li
19928	Espaldares do Animista
19929	Luvas Tingidas de Sangue
19930	Olho da Mar'li
19931	Insânia Mojo Gurubashi
19933	Sangue Luminescente de Escorpídeo
19934	Garra Grande de Escorpídeo
19935	Vesícula de Peçonha Vazia
19936	Carapaça Seca de Escorpídeo
19937	Garra Pequena de Escorpídeo
19938	Perna Pesada de Escorpídeo
19939	Sangue de Gri'lek
19940	Dente de Renataki
19941	Juba de Vuxulai
19942	Fio dos Sonhos de Hazza'rah
19943	Mega Mojo
19944	Exterminador de Peixes de Nat Pagle
19945	Tapa-olho de Escama de Lagarto
19946	Arpão de Tigule
19947	Carretel Quebrado do Nat Pagle
19948	Insígnia Heroica Zandalariana
19949	Medalhão Heroico Zandalariano
19950	Patuá Heroico Zandalariano
19951	Patuá do Poder de Gri'lek
19952	Patuá Valoroso de Gri'lek
19953	Patuá Bestial de Renataki
19954	Patuá Ardiloso de Renataki
19955	Patuá Natural de Vuxulai
19956	Patuá Espiritual de Vuxulai
19957	Patuá Destruidor de Hazza'rah
19958	Patuá Curativo de Hazza'rah
19959	Patuá Mágico de Hazza'rah
19960	Mel Cristalizado
19961	Triturador do Gri'lek
19962	Buril do Gri'lek
19963	Forcado da Loucura
19964	Conduto da Alma de Renataki
19965	Atiçador de Vuxulai
19967	O Destruidor de Pensamentos
19968	Vingador de Fogo
19969	Botas Radicais de Pesca de Nat Pagle
19970	Vara de Pescar de Arcanita
19971	Protótipo de Linha de Pesca de Etérnio
19972	Chapéu de Pescaria da Sorte
19973	Fita Métrica do Nat
19974	Isca para Gambalama
19975	Gambalama Zulian
19978	Campeonato de Pesca!
19979	Anzol do Pescador-mestre
19982	Clâmide Quiropúsculo
19984	Máscara de Ébano
19986	Tapa-olho de Pirata
19989	Tomo de Sombras Devoradoras
19990	Contas de Oração Abençoadas
19991	Olho de Demossauro
19992	Dente de Demossauro
19993	Arco de Caça Azarento
19994	Fruta da Colheita
19995	Javali da Colheita
19996	Peixe da Colheita
19997	Néctar da Colheita
19998	Lente Vinassangre
19999	Óculos Vinassangre
20000	Diagrama: Óculos Vinassangre
20001	Diagrama: Lente Vinassangre
20002	Poção Maior do Sono sem Sonhos
20003	Garras de Demossauro
20004	Poção Elevada de Sangue de Troll
20005	Garras de Demossauro
20006	Círculo de Esperança
20007	Poção de Sangue de Mago
20008	Poção de Ação Vivaz
20009	Pela Luz!
20010	O Grito Infernal da Horda
20011	Receita: Poção de Sangue de Mago
20012	Receita: Sonho sem Sonhos Maior
20013	Receita: Poção de Ação Vivaz
20014	Receita: Poção Elevada de Sangue de Troll
20015	Penas de Raptor Ancião
20016	Troféu de Crânio de Raptor
20017	Galhada Perfeita de Ginete
20018	Pelego de Urso-cinzento Garraivoso
20019	Dente de Morphaz
20020	Fardo de Mercadorias
20021	Brinco Pirata de Ouro
20022	Chave Lazúli
20023	Fragmento Codificado
20024	Ducto Biliar Pútrido
20025	Sangue de Morphaz
20026	Carne Putrefata
20027	Glândula de Ginete Saudável
20028	Pó Reluzente
20029	Coral Encantado
20030	Rocha de Estimação
20031	Mangaroma
20032	Vestes Rituais Esvoaçantes
20033	Veste do Demoníaco Zandalar
20034	Veste do Ilusionista Zandalar
20035	Punhal Glacial
20036	Rubi de Fogo
20037	Pingente de Cristal Arcano
20038	Ferrão do Mandokir
20039	Botas Ferro Negro
20040	Instruções: Botas Ferro Negro
20041	Cinturão de Placa do Highlander
20042	Cinturão Lamelar do Highlander
20043	Cinturão Encadeado do Highlander
20044	Cinturão de Malha das Terras Altas
20045	Cinturão de Couro do Highlander
20046	Cinturão de Couro de Lagarto do Highlander
20047	Cinturão de Tecido do Highlander
20048	Grevas de Placa do Highlander
20049	Grevas Lamelares do Highlander
20050	Grevas Encadeadas do Highlander
20051	Grevas de Malha das Terras Altas
20052	Botas de Couro do Highlander
20053	Botas de Couro de Lagarto do Highlander
20054	Botas de Tecido do Highlander
20055	Brafoneiras Encadeadas do Highlander
20056	Brafoneiras de Malha do Highlander
20057	Espaldares de Placa do Highlander
20058	Espaldares Lamelares do Highlander
20059	Omoplatas de Couro do Highlander
20060	Omoplatas de Couro de Lagarto do Highlander
20061	Palas do Highlander
20062	Ração Enriquecida da Bacia Arathi
20063	Ração de Campanha da Bacia Arathi
20064	Ração de Ferro da Bacia Arathi
20065	Bandagem de Magitrama da Bacia Arathi
20066	Bandagem de Runatrama da Bacia Arathi
20067	Bandagem de Seda da Bacia Arathi
20068	Manto do Necroguarda
20069	Cajado de Cascaferro
20070	Garrassábia
20071	Talismã de Arathor
20072	Talismã do Profanador
20073	Manto da Guarda de Honra
20074	Ensopado Grosso de Crocolisco
20075	Receita: Ensopado Grosso de Crocolisco
20076	Sinete Zandalar de Mojo
20077	Sinete Zandalar de Poder
20078	Sinete Zandalar de Serenidade
20079	Espírito de Zanza
20080	Reflexo de Zanza
20081	Rapidez de Zanza
20082	Vara do Padecimento
20083	Lança de Caça
20084	Rede de Caça
20085	Estilhaço Arcano
20086	Faca de Arremesso Crepúsculo de Aço
20087	Escamas de Fura-ondas
20088	Cinturão Encadeado do Highlander
20089	Cinturão Encadeado do Highlander
20090	Cinturão Encadeado do Highlander
20091	Grevas Encadeadas do Highlander
20092	Grevas Encadeadas do Highlander
20093	Grevas Encadeadas do Highlander
20094	Botas de Tecido do Highlander
20095	Botas de Tecido do Highlander
20096	Botas de Tecido do Highlander
20097	Cinturão de Tecido do Highlander
20098	Cinturão de Tecido do Highlander
20099	Cinturão de Tecido do Highlander
20100	Botas de Couro de Lagarto do Highlander
20101	Botas de Couro de Lagarto do Highlander
20102	Botas de Couro de Lagarto do Highlander
20103	Cinturão de Couro de Lagarto do Highlander
20104	Cinturão de Couro de Lagarto do Highlander
20105	Cinturão de Couro de Lagarto do Highlander
20106	Cinturão Lamelar do Highlander
20107	Cinturão Lamelar do Highlander
20108	Cinturão Lamelar do Highlander
20109	Grevas Lamelares do Highlander
20110	Grevas Lamelares do Highlander
20111	Grevas Lamelares do Highlander
20112	Botas de Couro do Highlander
20113	Botas de Couro do Highlander
20114	Botas de Couro do Highlander
20115	Cinturão de Couro do Highlander
20116	Cinturão de Couro do Highlander
20117	Cinturão de Couro do Highlander
20118	Cinturão de Malha das Terras Altas
20119	Cinturão de Malha das Terras Altas
20120	Cinturão de Malha das Terras Altas
20121	Grevas de Malha das Terras Altas
20122	Grevas de Malha das Terras Altas
20123	Grevas de Malha das Terras Altas
20124	Cinturão de Placa do Highlander
20125	Cinturão de Placa do Highlander
20126	Cinturão de Placa do Highlander
20127	Grevas de Placa do Highlander
20128	Grevas de Placa do Highlander
20129	Grevas de Placa do Highlander
20130	Frasco de Diamante
20131	Tabardo de Batalha dos Profanadores
20132	Tabardo de Batalha de Arathor
20134	Elmo de Fúria Celeste
20150	Cinturão de Malha do Profanador
20151	Cinturão de Malha do Profanador
20152	Cinturão de Malha do Profanador
20153	Cinturão de Malha do Profanador
20154	Grevas Encadeadas do Profanador
20155	Grevas Encadeadas do Profanador
20156	Grevas Encadeadas do Profanador
20157	Grevas Encadeadas do Profanador
20158	Brafoneiras Encadeadas do Profanador
20159	Botas de Tecido do Profanador
20160	Botas de Tecido do Profanador
20161	Botas de Tecido do Profanador
20162	Botas de Tecido do Profanador
20163	Cinturão de Tecido do Profanador
20164	Cinturão de Tecido do Profanador
20165	Cinturão de Tecido do Profanador
20166	Cinturão de Tecido do Profanador
20167	Botas de Couro de Lagarto do Profanador
20168	Botas de Couro de Lagarto do Profanador
20169	Botas de Couro de Lagarto do Profanador
20170	Botas de Couro de Lagarto do Profanador
20171	Cinturão de Couro de Lagarto do Profanador
20172	Cinturão de Couro de Lagarto do Profanador
20173	Cinturão de Couro de Lagarto do Profanador
20174	Cinturão de Couro de Lagarto do Profanador
20175	Omoplatas de Couro de Lagarto do Profanador
20176	Palas do Profanador
20177	Cinturão Lamelar do Profanador
20178	Cinturão Lamelar do Profanador
20179	Cinturão Lamelar do Profanador
20180	Cinturão Lamelar do Profanador
20181	Grevas Lamelares do Profanador
20182	Grevas Lamelares do Profanador
20183	Grevas Lamelares do Profanador
20184	Espaldares Lamelares do Profanador
20185	Grevas Lamelares do Profanador
20186	Botas de Couro do Profanador
20187	Botas de Couro do Profanador
20188	Botas de Couro do Profanador
20189	Botas de Couro do Profanador
20190	Cinturão de Couro do Profanador
20191	Cinturão de Couro do Profanador
20192	Cinturão de Couro do Profanador
20193	Cinturão de Couro do Profanador
20194	Omoplatas de Couro do Profanador
20195	Cinturão de Malha do Profanador
20196	Cinturão de Malha do Profanador
20197	Cinturão de Malha do Profanador
20198	Cinturão de Malha do Profanador
20199	Grevas de Malha do Profanador
20200	Grevas de Malha do Profanador
20201	Grevas de Malha do Profanador
20202	Grevas de Malha do Profanador
20203	Brafoneiras de Malha do Profanador
20204	Cinturão de Placa do Profanador
20205	Cinturão de Placa do Profanador
20206	Cinturão de Placa do Profanador
20207	Cinturão de Placa do Profanador
20208	Grevas de Placa do Profanador
20209	Grevas de Placa do Profanador
20210	Grevas de Placa do Profanador
20211	Grevas de Placa do Profanador
20212	Espaldares de Placa do Profanador
20213	Cinto de Cabeças Encolhidas
20214	Presa da Mente
20215	Cinto de Cabeças Enrugadas
20216	Cinto de Cabeças Preservadas
20217	Cinto de Minicabeças
20218	Manto Hakkari Desbotado
20219	Capa Hakkari Esfarrapada
20220	Cajado de Cascaferro
20221	Corcel Fabuloso
20222	Ração Enriquecida do Profanador
20223	Ração de Campanha do Profanador
20224	Ração de Ferro do Profanador
20225	Ração Enriquecida do Highlander
20226	Ração de Campanha do Highlander
20227	Ração de Ferro do Highlander
20228	Kit de Sobrevivência Avançado do Profanador
20229	Kit de Sobrevivência Básico do Profanador
20230	Kit de Sobrevivência Padrão do Profanador
20231	Kit de Sobrevivência Avançado de Arathor
20232	Bandagem de Magitrama do Profanador
20233	Kit de Sobrevivência Básico de Arathor
20234	Bandagem de Runatrama do Profanador
20235	Bandagem de Seda do Profanador
20236	Kit de Sobrevivência Padrão de Arathor
20237	Bandagem de Magitrama do Highlander
20243	Bandagem de Runatrama do Highlander
20244	Bandagem de Seda do Highlander
20253	Molde: Arnês de Urso de Guerra
20254	Molde: Bermuda de Urso de Guerra
20255	Botas Murmupasso
20256	Fita de Sacrifício da Ravina Brado Guerreiro
20257	Manoplas da Fúria dos Mares
20258	Cajado Cerimonial Zulian
20259	Luvas de Pelego de Pantera das Sombras
20260	Perneiras da Fúria dos Mares
20261	Cinto de Pelego de Pantera das Sombras
20262	Botas da Fúria dos Mares
20263	Elmo Gurubashi
20264	Manoplas do Pacificador
20265	Botas do Pacificador
20266	Perneiras do Pacificador
20295	Perneiras de Escama de Dragão Azul
20296	Manoplas de Escama de Dragão Verde
20310	Pele de Demônio Esfolada
20337	O Burro e a Cenoura
20367	Equipamento de Caça
20368	Arco Brando da Estabilidade
20369	Punhos de Azurita
20371	Ovo de Murloc Azul
20373	Aguilhão de Escorpídeo Petraçoite
20374	Aguilhão de Tenaz Petraçoite
20375	Aguilhão de Esfolador Petraçoite
20376	Presa de Rastejante da Areia
20377	Presa de Espreitadora de Rocha
20378	Fragmento de Tabuleta do Crepúsculo
20379	Algibeira do Noggel
20380	Peitoral de Escama de Sonhos
20381	Escama de Sonhos
20382	Molde: Peitoral de Escama de Sonhos
20383	Cabeça do Prolemestre Flagelador
20384	Fragmento de Carapaça Silitídea
20385	Tenaz da Agarramata
20387	Salva de Bombas Fedidas dos Renegados
20388	Pirulito
20389	Milho Doce
20390	Barra de Chocolate
20391	Máscara Frágil de Gnomo
20392	Máscara Frágil de Gnomida
20393	Bolsa de Gostosuras
20394	Dicionário do Crepúsculo – Capítulo 1
20395	Dicionário do Crepúsculo – Capítulo 2
20396	Dicionário do Crepúsculo – Capítulo 3
20397	Varinha Feiticeira - Pirata
20398	Varinha Feiticeira - Ninja
20399	Varinha Feiticeira - Gnomo Leproso
20400	Saco de Abóbora
20401	Tabuleta Restaurada do Crepúsculo
20402	Agente de Nozdormu
20403	Procurador de Nozdormu
20404	Texto Codificado do Crepúsculo
20405	Transcrição Decodificada da Tabuleta
20406	Dragonas de Sectário do Crepúsculo
20407	Veste de Sectário do Crepúsculo
20408	Capucho de Sectário do Crepúsculo
20409	Varinha Feiticeira - Fantasma
20410	Varinha Feiticeira - Morcego
20411	Varinha Feiticeira - Esqueleto
20413	Varinha Feiticeira - Aleatório
20414	Varinha Feiticeira – Fogo Fátuo
20415	A Guerra das Areias Cambiantes
20416	Escudo Chamariz: Fogo
20418	Escudo Chamariz: Trovão
20419	Brasão Chamariz: Pedra
20420	Escudo Chamariz: Água
20422	Medalhão de Posto do Sectário do Crepúsculo
20423	Pinça Arenosa de Escorpídeo
20424	Carne de Verme da Areia
20425	Cajado Nodoso do Conselheiro
20426	Anel do Conselheiro
20427	Manto do Curandeiro de Batalha
20428	Capa do Zelador
20429	Elo do Legionário
20430	Espada do Legionário
20431	Anel do Erudito
20432	Sinete Chamariz: Fogo
20433	Sinete Chamariz: Trovão
20434	Cajado do Erudito
20435	Sinete Chamariz: Pedra
20436	Sinete Chamariz: Água
20437	Arco do Pioneiro
20438	Arco do Vanguardeiro
20439	Elo do Protetor
20440	Espada do Protetor
20441	Lâmina do Batedor
20442	Medalhão do Batedor
20443	Lâmina da Sentinela
20444	Medalhão da Sentinela
20447	Cetro Chamariz: Fogo
20448	Cetro Chamariz: Trovão
20449	Cetro Chamariz: Pedra
20450	Cetro Chamariz: Água
20451	Anel de Suserania do Sectário do Crepúsculo
20452	Bolinhos Defumados do Deserto
20453	Kit de Transcrição do Geólogo
20454	Decalque de Colme'Zora
20455	Decalque de Colme'Ashi
20456	Decalque de Colme'Régia
20457	Cérebro de Silitídeo de Colme'Ashi
20458	Cérebro de Silitídeo de Colme'Zora
20459	Cérebro de Silitídeo de Colme'Régia
20460	Carta Perdida de Brann Barbabronze
20461	Carta Perdida de Brann Barbabronze
20462	Medalhão de Noturnália
20463	Prisma de Cristal com Glifos
20464	Glifos de Evocação
20465	Mecanismo de Destrancamento de Cristal
20466	Anel-sinete do Viral
20467	Página Rasgada de Receita
20469	Recortes Decodificados da 'Crente Fiel'
20475	Gema Anímica
20476	Braçadeiras Espreitareia
20477	Manoplas Espreitareia
20478	Peitoral Espreitareia
20479	Peitoral Cospefogo
20480	Manoplas Cospefogo
20481	Braçadeiras Cospefogo
20485	Selo do Duque
20487	Lok'delar, Báculo dos Guardiões Antigos DEP
20488	Rhok'delar, Arco Longo dos Guardiões Antigos DEP
20489	Coroa do Conselho
20490	Balinha de Altaforja
20491	Balinha da Cidade Baixa
20492	Nougat de Ventobravo
20493	Nougat de Orgrimmar
20494	Jujuba de Gnomeregan
20495	Jujuba Lançanegra
20496	Marzipã de Darnassus
20497	Marzipã do Penhasco do Trovão
20498	Quitina de Silitídeo
20499	Quitina Quebrada de Silitídeo
20500	Carapaça Leve de Silitídeo
20501	Carapaça Pesada de Silitídeo
20502	Escudo de Cascaferro
20503	Espírito de Água Enamorado
20504	Lâmina Forjada em Luz
20505	Sinete Cavalheiresco
20506	Molde: Braçadeiras Cospefogo
20507	Molde: Manoplas Cospefogo
20508	Molde: Peitoral Cospefogo
20509	Molde: Braçadeiras Espreitareia
20510	Molde: Manoplas Espreitareia
20511	Molde: Peitoral Espreitareia
20512	Orbe Santificado
20513	Escudo Abissal
20514	Sinete Abissal
20515	Cetro Abissal
20516	Maçã Flutuante
20517	Ombros de Navalhaço
20518	Pergaminho: Criar Escudo Chamariz
20519	Chapéu de Pirata dos Mares do Sul
20520	Runa Negra
20521	Viseira da Fúria
20522	Cajado Feral
20524	Perneiras Umbrapele
20525	Signo Terrano
20526	Pergaminho: Criar Escudo Chamariz
20527	Pergaminho: Criar Escudo Chamariz
20528	Pergaminho: Criar Escudo Chamariz
20530	Vestes da Sujeição
20531	Pergaminho: Criar Sinete Chamariz
20532	Pergaminho: Criar Sinete Chamariz
20533	Pergaminho: Criar Sinete Chamariz
20534	Fragmento do Abismo
20535	Pergaminho: Criar Sinete Chamariz
20536	Ceifalmas
20537	Botas Rúnicas Estígias
20538	Perneiras Rúnicas Estígias
20539	Cinto Rúnico Estígio
20540	Pergaminho: Criar Cetro Chamariz
20541	Texto Decodificado do Crepúsculo
20542	Pergaminho: Criar Cetro Chamariz
20543	Pergaminho: Criar Cetro Chamariz
20544	Pergaminho: Criar Cetro Chamariz
20545	Texto Decodificado do Crepúsculo
20546	Molde: Perneiras Rúnicas Estígias
20547	Molde: Botas Rúnicas Estígias
20548	Molde: Cinto Rúnico Estígio
20549	Manoplas Runanegra
20550	Peitoral Runanegra
20551	Elmo Runanegra
20552	Texto Decodificado do Crepúsculo
20553	Instruções: Manoplas Runanegra
20554	Instruções: Peitoral Runanegra
20555	Instruções: Elmo Runanegra
20556	Cajado Selvagem
20557	Gostosura de Abóbora da Noturnália
20558	Marca de Honra da Ravina Brado Guerreiro
20559	Marca de Honra da Bacia Arathi
20560	Marca de Honra do Vale Alterac
20561	Máscara Frágil de Anão
20562	Máscara Frágil de Anã
20563	Máscara Frágil de Elfa Noturna
20564	Máscara Frágil de Elfo Noturno
20565	Máscara Frágil de Humana
20566	Máscara Frágil de Humano
20567	Máscara Frágil de Trolesa
20568	Máscara Frágil de Troll
20569	Máscara Frágil de Orquisa
20570	Máscara Frágil de Orc
20571	Máscara Frágil de Taurena
20572	Máscara Frágil de Tauren
20573	Máscara Frágil de Morto-vivo
20574	Máscara Frágil de Morta-viva
20575	Túnica de Dragonete Negro
20576	Molde: Túnica de Dragonete Negro
20577	Lâmina de Pesadelo
20578	Esmeralda Dendragônia
20579	Manto Verde de Peledrago
20580	Martelo da Fúria Bestial
20581	Cajado do Crescimento Descontrolado
20582	Pedra do Transe
20583	Máscara Resistente de Anã
20584	Máscara Resistente de Gnomida
20585	Máscara Resistente de Humana
20586	Máscara Resistente de Elfa Noturna
20587	Máscara Resistente de Orquisa
20588	Máscara Resistente de Taurena
20589	Máscara Resistente de Trolesa
20590	Máscara Resistente de Morta-viva
20591	Máscara Resistente de Anão
20592	Máscara Resistente de Gnomo
20593	Máscara Resistente de Humano
20594	Máscara Resistente de Elfo Noturno
20595	Máscara Resistente de Orc
20596	Máscara Resistente de Tauren
20597	Máscara Resistente de Troll
20598	Máscara Resistente de Morto-vivo
20599	Besta de Pau-ferro Polido
20600	Anel-sinete de Malfurion
20601	Saca com Espólios
20602	Baú com Espólios
20603	Saco com Espólios
20604	Limpador de Bomba Fedida
20605	Ovos Podres
20606	Pena Vodu Âmbar
20607	Pena Vodu Azul
20608	Pena Vodu Verde
20609	Penas Vodu
20610	Olho Injetado de Aranha
20611	Garra Preta Maciça
20612	Pedra do Flagelo Inerte
20613	Madeira Podre
20614	Essência de Peçonha
20615	Braçadeiras Draguilhão
20616	Munhequeiras de Osso de Dragão
20617	Perneiras Antigas Corroídas
20618	Luvas do Poder Ilusório
20619	Grevas Inscritas com Ácido
20620	Megalito Sagrado
20621	Botas do Pântano sem Fim
20622	Colar Dracórdio
20623	Diadema dos Sonhos Inquietos
20624	Anel do Vivo-morto
20625	Cinto do Brejo Negro
20626	Braceleiras da Casca Preta
20627	Calças do Coração Negro
20628	Casquete do Crescimento Anormal
20629	Guarda-pés Malignos
20630	Manoplas da Luz Rutilante
20631	Sapatilhas do Mendicante
20632	Faixa Rasgamentes
20633	Brafoneiras Sinistras de Couro
20634	Botas do Medo
20635	Vestimenta Marchetada de Jade
20636	Cristal de Hibernação
20637	Brafoneiras Inscritas com Ácido
20638	Perneiras do Demente
20639	Coxotes com Estranhos Entalhes
20640	Balde Cefálico do Mar do Sul
20641	Botas do Mojo do Mar do Sul
20642	Túnica do Fidalgo Antiquado
20643	Casquete do Reservista da Cidade Baixa
20644	Objeto Mergulhado em Pesadelos
20645	Sussurro da Natureza
20646	Marca do Arenomoa
20647	Punhal de Cristal Preto
20648	Martelo Forjado a Frio
20649	Pingente Prismassol
20650	Manoplas do Vento do Deserto
20651	Ovo de Murloc Laranja
20652	Sapatilhas de Tecido Abissal
20653	Manoplas de Placa Abissal
20654	Cajado de Batalha Ametista
20655	Mitenes de Tecido Abissal
20656	Escarpes de Malha Abissal
20657	Estilete de Ponta de Cristal
20658	Botas de Couro Abissal
20659	Protetores de Mão de Malha Abissal
20660	Glaive Lapidadora
20661	Luvas de Couro Abissal
20662	Grevas de Placa Abissal
20663	Arco do Golpe Profundo
20664	Faixa de Tecido Abissal
20665	Perneiras de Couro Abissal
20666	Martelo de Guerra de Aço Temperado
20667	Cinto de Couro Abissal
20668	Guarda-pernas de Malha Abissal
20669	Espadão Pedranegra
20670	Amarra de Malha Abissal
20671	Coxotes de Placa Abissal
20672	Varinha de Cristal Rutilante
20673	Cinturão de Placa Abissal
20674	Calças de Tecido Abissal
20675	Rasgalmas
20676	Texto Decodificado do Crepúsculo
20677	Texto Decodificado do Crepúsculo
20678	Texto Decodificado do Crepúsculo
20679	Texto Decodificado do Crepúsculo
20680	Brafoneiras de Malha Abissal
20681	Braçadeiras de Couro Abissal
20682	Anel da Concentração Elemental
20683	Palas de Placa Abissal
20684	Guarda-braços de Malha Abissal
20685	Colar das Ondas
20686	Sobreveste de Tecido Abissal
20687	Avambraços de Placa Abissal
20688	Guarda Terrano
20689	Omoplatas de Couro Abissal
20690	Guarda-braços de Tecido Abissal
20691	Capa Cortavento
20692	Anel Multicolorido
20693	Manto Balanceado
20694	Orbe Negro Faiscante
20695	Contas de Guerra Abissais
20696	Malho Pontudo de Cristal
20697	Capa Bordada Cristalina
20698	Lâmina em Sintonia Elemental
20699	Coxotes do Reservista Cenariano
20700	Coxotes do Reservista Cenariano
20701	Guarda-pernas do Reservista Cenariano
20702	Guarda-pernas do Reservista Cenariano
20703	Perneiras do Reservista Cenariano
20704	Perneiras do Reservista Cenariano
20705	Calças do Reservista Cenariano
20706	Calças do Reservista Cenariano
20707	Calças do Reservista Cenariano
20708	Arca Hermeticamente Lacrada
20709	Rum Rumsey Carta Prata
20710	Grevas Incrustadas de Cristal
20711	Grevas Tauxiadas de Cristal
20712	Manoplas do Ermâmbulo
20713	Manoplas do Espreitadeserto
20714	Botas da Tempestade de Areia
20715	Botas do Espreitaduna
20716	Luvas de Pele de Verme da Areia
20717	Luvas Dioneia do Deserto
20720	Lâmina do Sussuro Negro
20721	Elo do Sectário
20722	Cospe-bala Cristalino
20723	Picareta Fiel do Brann
20724	Cajado Bosquenero Corrompido
20725	Cristal do Nexus
20726	Fórmula: Encantamento de Ameaça - Luvas
20727	Fórmula: Encantamento de Poder Sombrio - Luvas
20728	Fórmula: Encantamento de Poder Gélido - Luvas
20729	Fórmula: Encantamento de Poder Ígneo - Luvas
20730	Fórmula: Encantamento de Poder de Cura - Luvas
20731	Fórmula: Encantamento Superior de Agilidade - Luvas
20732	Fórmula: Encantamento Maior de Resistência ao Fogo - Manto
20733	Fórmula: Encantamento Maior de Resistência à Natureza - Manto
20734	Fórmula: Encantamento de Furtividade - Manto
20735	Fórmula: Encantamento de Sutileza - Manto
20736	Fórmula: Encantamento de Esquiva - Manto
20737	Pedra Nuclear Chamuscada
20741	Totem Ritual de Lenha Morta
20742	Totem Ritual Invernoso
20744	Óleo Menor de Teurgo
20745	Óleo Menor de Mana
20746	Óleo Inferior de Teurgo
20747	Óleo Inferior de Mana
20748	Óleo Brilhante de Mana
20749	Óleo Brilhante de Teurgo
20750	Óleo de Teurgo
20752	Fórmula: Óleo Menor de Mana
20753	Fórmula: Óleo Inferior de Teurgo
20754	Fórmula: Óleo Inferior de Mana
20755	Fórmula: Óleo de Teurgo
20756	Fórmula: Óleo Brilhante de Teurgo
20757	Fórmula: Óleo Brilhante de Mana
20758	Fórmula: Óleo Menor de Teurgo
20761	Receita: Transmutar Fogo Elemental
20763	Arma Quebrada
20766	Bolsa Gosmenta
20767	Sacola Coberta de Escuma
20768	Sacola Gosmenta
20769	Gosmícula Nojenta
20770	Linfa Verde Borbulhante
20800	Insígnia Logística Cenariana
20801	Insígnia Tática Cenariana
20802	Insígnia de Combate Cenariana
20803	Ordens de Batalha do Martelo do Crepúsculo
20805	Missão de Logística Continuada
20806	Instruções de Logística X
20807	Instruções de Logística I
20808	Missão de Combate
20809	Missão Tática
20810	Papéis Assinados de Serviço em Campanha
20814	Adaga de Arremesso do Mestre
20834	Luneta Ornada XT
20844	Veneno Mortal V
20858	Escaravelho de Pedra
20859	Escaravelho de Ouro
20860	Escaravelho de Prata
20861	Escaravelho de Bronze
20862	Escaravelho de Cristal
20863	Escaravelho de Barro
20864	Escaravelho de Osso
20865	Escaravelho de Marfim
20866	Ídolo Lazúli
20867	Ídolo Ônix
20868	Ídolo Bruxuleante
20869	Ídolo Âmbar
20870	Ídolo de Jaspe
20871	Ídolo Obsidiano
20872	Ídolo Vermelho
20873	Ídolo de Alabastro
20874	Ídolo do Sol
20875	Ídolo da Noite
20876	Ídolo da Morte
20877	Ídolo do Sábio
20878	Ídolo do Renascimento
20879	Ídolo da Vida
20881	Ídolo da Disputa
20882	Ídolo da Guerra
20883	Joia Qiraji com Glifos
20884	Anel Magistral Qiraji
20885	Clâmide Marcial Qiraji
20886	Punho de Pontas Qiraji
20887	Joia Gravada Qiraji
20888	Anel Cerimonial Qiraji
20889	Clâmide Régia Qiraji
20890	Punho Ornamentado Qiraji
20908	Fogo de Artifício do Festival de Nian
20926	Diadema de Vek'nilash
20927	Pelego Intacto de Ouroboros
20928	Braceletes Qiraji de Comando
20929	Carapaça do Deus Antigo
20930	Diadema de Vek'lor
20931	Pele do Grande Verme da Areia
20932	Braceletes Qiraji de Dominância
20933	Carapaça do Deus Antigo
20936	Joia Qiraji Abençoada
20937	Joia Incrustada Qiraji
20939	Instruções de Logística II
20940	Instruções de Logística III
20941	Instruções de Combate XII
20942	Instruções de Combate III
20943	Instruções Táticas X
20944	Instruções Táticas IX
20945	Instruções Táticas II
20946	Instruções Táticas III
20947	Instruções Táticas IV
20948	Instruções Táticas V
20949	Livro-caixa Mágico
20951	Óculos da Vidência de Narain
21023	Costeletas Sinistronas de Quiméroco do Funesto
21024	Lombo de Quiméroco
21025	Receita: Costeletas Sinistronas de Quiméroco do Funesto
21027	Carcaça de Lakmaeran
21028	Frango de 250 Quilos
21029	Pedido de Resgate
21030	Torta de Ragu de Darnassus
21031	Ragu de Repolho
21032	Carta de Amor de Meridith
21033	Ragu de Rabanete
21037	Mapa Rudimentar
21038	Bola de Neve Bem Compacta
21039	Turbante de Narain
21040	Veste de Narain
21041	Saco de Ouro
21042	Kit Especial de Narain
21043	Envelope Misterioso
21071	Sabichão Cru
21072	Sabichão Defumado
21099	Receita: Sabichão Defumado
21100	Moeda dos Ancestrais
21103	Dracônico para Leigos
21104	Dracônico para Leigos
21105	Dracônico para Leigos
21106	Dracônico para Leigos
21107	Dracônico para Leigos
21108	Dracônico para Leigos
21109	Dracônico para Leigos
21110	Dracônico para Leigos
21111	Dracônico para Leigos: Volume II
21112	Capa Mágica de Livros
21113	Arca à Prova d'Água
21114	Rum Rumsey Carta Ouro
21115	Talismã do Profanador
21116	Talismã do Profanador
21117	Talismã de Arathor
21118	Talismã de Arathor
21119	Talismã de Arathor
21120	Talismã do Profanador
21126	Aguilhão da Morte
21128	Cajado dos Profetas Qiraji
21130	Diário do Ívio
21131	Missão de Combate Continuada
21132	Missão de Logística
21133	Missão Tática Continuada
21134	Gume Negro da Insanidade
21135	Machado de Arremesso do Assassino
21136	Boia de Arcanita
21137	Estilhaço de Cetro Azul
21138	Estilhaço de Cetro Vermelho
21139	Estilhaço de Cetro Verde
21140	Papel Timbrado de Leilão
21141	Estilhaço de Cetro Vermelho Destruído
21142	Do Punho de Lorde Victor Nefarius
21143	Papéis em Branco de Serviço em Campanha
21144	Tocha de Evocação Demoníaca
21145	Essência de Shandivious
21146	Fragmento da Corrupção do Pesadelo
21147	Fragmento da Corrupção do Pesadelo
21148	Fragmento da Corrupção do Pesadelo
21149	Fragmento da Corrupção do Pesadelo
21150	Arca com Tiras de Ferro
21151	Rum Rumsey Carta Negra
21152	A Corrupção do Pesadelo
21153	Sabichão Maior Cru
21154	Vestido do Festival
21155	Oferenda de Paz dos Presamatos
21156	Bolsa do Escaravelho
21157	Vestido Festivo Verde
21158	Relatório do Batedor de Colme'Zora
21159	Ordens do Batedor de Colme'Zora
21160	Relatório do Batedor de Colme'Régia
21161	Relatório do Batedor de Colme'Ashi
21162	Bocanera Oleoso Inchado
21163	Pinafogo Inchado
21164	Bacalhau Escama-de-pedra Inchado
21165	Instruções Táticas VI
21166	Instruções Táticas VII
21167	Instruções Táticas VIII
21168	Tubarinho
21171	Caneca Festiva Cheia
21173	Caneca Festiva Vazia
21174	Caneca Festiva Vazia
21175	Cetro das Areias Cambiantes
21176	Cristal Ressonante Qiraji Preto
21177	Símbolo dos Reis
21178	Luvas do Poder Terrano
21179	Anel da Ira Terrana
21180	Golpe Terreno
21181	Dádiva da Terra
21182	Elo do Poder Terrano
21183	Colete do Poder Terreno
21184	Braçadeiras Rochafunda
21185	Orbe Terramansa
21186	Braçadeiras Rochafúria
21187	Manto de Trama Terrena
21188	Punho de Cenarius
21189	Poder de Cenarius
21190	Ira de Cenarius
21191	Presente Cuidadosamente Embrulhado
21193	Sacola de D'Sak
21194	Sacolão de D'Sak
21195	Sacotástico de D'Sak
21196	Anel-sinete da Revoada Bronze
21197	Anel-sinete da Revoada Bronze
21198	Anel-sinete da Revoada Bronze
21199	Anel-sinete da Revoada Bronze
21200	Anel-sinete da Revoada Bronze
21201	Anel-sinete da Revoada Bronze
21202	Anel-sinete da Revoada Bronze
21203	Anel-sinete da Revoada Bronze
21204	Anel-sinete da Revoada Bronze
21205	Anel-sinete da Revoada Bronze
21206	Anel-sinete da Revoada Bronze
21207	Anel-sinete da Revoada Bronze
21208	Anel-sinete da Revoada Bronze
21209	Anel-sinete da Revoada Bronze
21210	Anel-sinete da Revoada Bronze
21211	Bolsa de Pó de Rena
21212	Azevinho Fresco
21213	Azevinho Seco
21214	Tomo de Seta de Gelo XI
21215	Bolo de Frutas com Carne Moída do Gracco
21216	Presente Extra-especial da Fazenda Bosque Defumado
21217	Delícia de Sabichão
21218	Cristal Ressonante Qiraji Azul
21219	Receita: Delícia de Sabichão
21220	Cabeça de Ossirian, o Intocado
21221	Olho de C'Thun
21222	Quitina Encouraçada
21223	Pedra Negra
21224	Fragmento de Armadura Antiga
21225	Casca Silitídea Pesada
21226	Pedra Rúnica
21227	Crânio do Guerreiro Antigo
21228	Arca com Tiras de Mithril
21229	Insígnia do Lorde Qiraji
21230	Artefato Qiraji Antigo
21232	Armamentos Imperiais Qirajis
21235	Assado do Véu de Inverno
21236	Pão do Véu de Inverno
21237	Paramentos Imperiais Qirajis
21240	Doce do Véu de Inverno
21241	Batida de Ovo do Véu de Inverno
21242	Machado de Guerra Qiraji Abençoado
21243	Parrudo Inchado
21244	Pugio Qiraji Abençoado
21245	Instruções Táticas I
21246	Instruções de Combate I
21247	Instruções de Combate II
21248	Instruções de Combate IV
21249	Instruções de Combate V
21250	Instruções de Combate VI
21251	Instruções de Combate VII
21252	Instruções de Combate VIII
21253	Instruções de Combate IX
21254	Biscoito do Véu de Inverno
21255	Instruções de Combate X
21256	Instruções de Combate XI
21257	Instruções de Logística IV
21258	Instruções de Logística IV
21259	Instruções de Logística V
21260	Instruções de Logística VI
21261	Instruções de Logística VI
21262	Instruções de Logística VIII
21263	Instruções de Logística VII
21264	Instruções de Logística VII
21265	Instruções de Logística IX
21266	Missão de Logística
21267	Cálice de Brindar
21268	Martelo de Guerra Qiraji Abençoado
21269	Baluarte Qiraji Abençoado
21270	Presente Chacoalhado Gentilmente
21271	Presente Chacoalhado Gentilmente
21272	Mosquete Qiraji Abençoado
21273	Cajado Qiraji Abençoado do Acólito
21275	Cajado Qiraji Abençoado do Áugure
21277	Yeti Mecânico Pacato
21278	Luvas do Véu da Tempestade
21279	Tomo de Bola de Fogo XII
21280	Tomo de Mísseis Arcanos VIII
21281	Grimório de Seta Sombria X
21282	Grimório de Imolação VIII
21283	Grimório de Corrupção VII
21284	Códice de Cura Maior V
21285	Códice de Renovar IX
21287	Códice de Prece de Cura V
21288	Incunábulo: Bênção da Sabedoria VI
21289	Incunábulo: Bênção do Poder VII
21290	Incunábulo: Luz Sagrada IX
21291	Tabuleta de Onda Curativa X
21292	Tabuleta de Totem da Força da Terra V
21293	Tabuleta de Totem da Graça do Ar III
21294	Livro de Toque de Cura XI
21295	Livro de Fogo Estelar VII
21296	Livro de Rejuvenescimento XI
21297	Manual de Golpe Heroico IX
21298	Manual de Grito de Batalha VII
21299	Manual de Revanche VI
21300	Guia da Punhalada pelas Costas IX
21301	Caixa Ajudante Verde
21302	Guia de Veneno Mortal V
21303	Guia de Finta V
21304	Guia: Tiro Múltiplo V
21305	Caixa Ajudante Vermelha
21306	Guia: Picada de Serpente IX
21307	Guia: Aspecto do Falcão VII
21308	Sino Pequenino
21309	Kit de Boneco de Neve
21310	Presente Alegremente Embrulhado
21311	Colete do Guardador da Terra
21312	Cinto do Vigia do Covil
21313	Bolsinha de D'Sak
21314	Cartas e Anotações do Metzen
21315	Algibeira do Bosque Defumado
21316	Perneiras do Ursino
21317	Elmo do Desbravador
21318	Luvas do Guardador da Terra
21319	Luvas do Desbravador
21320	Colete do Vigia do Covil
21321	Cristal Ressonante Qiraji Vermelho
21322	Abraço do Ursino
21323	Cristal Ressonante Qiraji Verde
21324	Cristal Ressonante Qiraji Amarelo
21325	Greench Mecânico
21326	Defensor dos Presamatos
21327	Presente Tiquetaqueante
21328	Varinha de Alegria das Festas
21329	Coroa do Conquistador
21330	Espaldares do Conquistador
21331	Peitoral do Conquistador
21332	Guarda-pernas do Conquistador
21333	Grevas do Conquistador
21334	Vestes do Arauto da Ruína
21335	Dragonas do Arauto da Ruína
21336	Calças do Arauto da Ruína
21337	Diadema do Arauto da Ruína
21338	Palmilhas do Arauto da Ruína
21340	Bolsa de Almas
21341	Bolsa de Tecido Vil
21342	Bolsa Principal de Tecido Vil
21343	Vestes Enigmáticas
21344	Botas Enigmáticas
21345	Ombreiras Enigmáticas
21346	Perneiras Enigmáticas
21347	Diadema Enigmático
21348	Tiara do Oráculo
21349	Palmilhas do Oráculo
21350	Dragonas do Oráculo
21351	Vestimenta do Oráculo
21352	Calças do Oráculo
21353	Elmo da Gênese
21354	Ombreiras da Gênese
21355	Botas da Gênese
21356	Calças da Gênese
21357	Colete da Gênese
21358	Molde: Bolsa de Almas
21359	Botas do Causamortis
21360	Elmo do Causamortis
21361	Espaldares do Causamortis
21362	Perneiras do Causamortis
21363	Presente Festivo
21364	Colete do Causamortis
21365	Guarda-pés do Atirador
21366	Diadema do Atirador
21367	Brafoneiras do Atirador
21368	Perneiras do Atirador
21369	Molde: Bolsa de Tecido Vil
21370	Cota do Atirador
21371	Molde: Bolsa Principal de Tecido Vil
21372	Diadema do Tempestário
21373	Guarda-pés do Tempestário
21374	Cota do Tempestário
21375	Perneiras do Tempestário
21376	Brafoneiras do Tempestário
21377	Pena do Cocar de Lenha Morta
21378	Instruções de Logística I
21379	Instruções de Logística II
21380	Instruções de Logística III
21381	Instruções de Logística IX
21382	Instruções de Logística V
21383	Contas Espirituais de Invernoso
21384	Instruções de Logística VIII
21385	Instruções de Logística X
21386	Missão de Logística Continuada
21387	Coroa do Vingador
21388	Grevas do Vingador
21389	Peitoral do Vingador
21390	Guarda-pernas do Vingador
21391	Brafoneiras do Vingador
21392	Foice da Força Obstinada
21393	Sinete da Força Obstinada
21394	Clâmide da Força Obstinada
21395	Lâmina da Justiça Eterna
21396	Anel da Justiça Eterna
21397	Capa da Justiça Eterna
21398	Martelo da Tempestade Iminente
21399	Anel da Tempestade Iminente
21400	Manto da Tempestade Iminente
21401	Foice do Caminho Oculto
21402	Sinete do Caminho Oculto
21403	Manto do Caminho Oculto
21404	Adaga das Sombras Veladas
21405	Anel das Sombras Veladas
21406	Manto das Sombras Veladas
21407	Maça da Vida Interminável
21408	Anel da Vida Interminável
21409	Manto da Vida Interminável
21410	Martelete da Sabedoria Infinita
21411	Anel da Sabedoria Infinita
21412	Mortalha da Sabedoria Infinita
21413	Lâmina dos Segredos Obscuros
21414	Anel dos Segredos Obscuros
21415	Clâmide dos Segredos Obscuros
21416	Cris dos Nomes Proibidos
21417	Anel dos Nomes Proibidos
21418	Mortalha dos Nomes Proibidos
21436	Sinete de Comenda da Aliança
21438	Sinete de Comenda da Horda
21452	Cajado das Ruínas
21453	Dragonas dos Horusath
21454	Omoplatas de Pedra Rúnica
21455	Elmo do Vento Sul
21456	Manto da Tempestade de Areia
21457	Braçadeiras da Brutalidade
21458	Manoplas da Vida Nova
21459	Besta da Ruína Iminente
21460	Elmo da Dominação
21461	Perneiras da Nevasca Negra
21462	Luvas da Sabedoria Negra
21463	Cinturão de Ossirian
21464	Grilhões do Imaculado
21466	Aguilhão de Ayamiss
21467	Couraça Silitídea Grossa
21468	Dragonas de Maz'Nadir
21469	Manoplas do Vento Sul
21470	Manto do Salvador
21471	Garra da Concentração Furiosa
21472	Turbante Sopravento
21473	Olho de Moam
21474	Guarda-ombros Quitinosos
21475	Coxotes do Destruidor
21476	Perneiras em Escamas Obsidianas
21477	Anel da Fúria
21478	Arco do Tendão Estirado
21479	Manoplas do Impassível
21480	Manoplas do Silitídeo em Escamas
21481	Botas do Protetor do Deserto
21482	Botas das Areias Abrasadoras
21483	Anel dos Ventos do Deserto
21484	Elmo do Recrescimento
21485	Fragmento do Crânio de Buru
21486	Luvas do Enxame
21487	Manoplas em Escamas Viscosas
21488	Fetiche de Espinhos Quitinosos
21489	Galochas da Areia Movediça
21490	Pisantes de Visgo
21491	Braçadeiras em Escamas do Engolidor
21492	A Degola-homens Qiraji
21493	Botas da Vanguarda
21494	Cinturão do Vento Sul
21495	Coxotes do Comando Qiraji
21496	Braçadeiras do Comando Qiraji
21497	Botas do General Qiraji
21498	Adaga Sacrifical Qiraji
21499	Vestimenta das Areias Cambiantes
21500	Cinto da Inquisição
21501	Luvas de Casca Silitídea Reforçada
21502	Munhequeiras do Aniquilador Arenoso
21503	Cinto do Aniquilador Arenoso
21504	Patuá das Areias Cambiantes
21505	Gargantilha das Areias Cambiantes
21506	Pingente das Areias Cambiantes
21507	Amuleto das Areias Cambiantes
21508	Marca de Cenarius
21509	Suprimentos de Guerra em Ahn'Qiraj
21510	Suprimentos de Guerra em Ahn'Qiraj
21511	Suprimentos de Guerra em Ahn'Qiraj
21512	Suprimentos de Guerra em Ahn'Qiraj
21513	Suprimentos de Guerra em Ahn'Qiraj
21514	Instruções de Logística XI
21515	Marca de Remulos
21517	Turbante Gnômico do Poder Psíquico
21519	Visco
21520	Legado dos Cristacorvo
21521	Espada Rúnica do Vermelho
21522	Lamento dos Cantonegro
21523	Presa de Korialstrasz
21524	Chapéu Vermelho de Inverno
21525	Chapéu Verde de Inverno
21526	Elo das Profundezas Congelantes
21527	Vestes da Água Negra
21528	Sacola Colossal de Despojos
21529	Amuleto de Anteparo Sombrio
21530	Perneiras Engastadas com Ônix
21531	Colar de Dente de Draco
21532	Botas Labutadoras
21533	Carapaça do Colosso de Zora
21534	Carapaça do Colosso de Ashi
21535	Carapaça do Colosso de Régia
21536	Pedra de Eluna
21537	Bolinhos do Festival
21538	Vestido Festivo Rosa
21539	Vestido Festivo Roxo
21540	Lanterna de Eluna
21541	Conjunto Festivo Preto
21542	Roupa do Festival
21543	Conjunto Festivo Ardósia
21544	Conjunto Festivo Azul
21545	Suprimento do Bosque Defumado
21546	Elixir de Poder de Fogo Maior
21547	Receita: Elixir de Poder de Fogo Maior
21548	Molde: Luvas do Véu da Tempestade
21550	Monstro - Arco, Kaldorei
21552	Rabo-amarelo Listrado
21557	Foguete Vermelho Pequeno
21558	Foguete Azul Pequeno
21559	Foguete Verde Pequeno
21560	Foguete Roxo Pequeno
21561	Foguete Branco Pequeno
21562	Foguete Amarelo Pequeno
21563	Elo de Dom Rodrigo
21565	Runa da Perfeição
21566	Runa da Perfeição
21567	Runa do Dever
21568	Runa do Dever
21569	Lançador de Fogos de Artifício
21570	Lançador de Salva de Fogos de Artifício
21571	Salva de Foguetes Azuis
21574	Salva de Foguetes Verdes
21575	Salva de Foguetes Roxos
21576	Salva de Foguetes Vermelhos
21577	Salva de Foguetes Brancos
21578	Salva de Foguetes Amarelos
21579	Tentáculo Derrotado de C'Thun
21580	Monstro - Machado de 2M, Horda JxJ
21581	Manoplas da Aniquilação
21582	Cinturão do Deus Antigo
21583	Manto da Clareza
21584	Braçadeiras do Juízo Eterno
21585	Manoplas da Tempestade Negra
21586	Cinto da Agonia sem Fim
21587	Munhequeiras do Castigo
21588	Munhequeiras da Fúria Elemental
21589	Foguete Azul Grande
21590	Foguete Verde Grande
21591	Foguete Roxo Grande
21592	Foguete Vermelho Grande
21593	Foguete Branco Grande
21594	Braçadeiras do Filho Caído
21595	Foguete Amarelo Grande
21596	Anel do Assassino de Deuses
21597	Cetro Real de Vek'lor
21598	Cinto Real Qiraji
21599	Luvas Devastadoras de Vek'lor
21600	Botas da Epifania
21601	Anel do Imperador Vek'lor
21602	Braçadeiras Qiraji da Execução
21603	Varinha da Nobreza Qiraji
21604	Braceletes da Redenção Real
21605	Luvas do Templo Oculto
21606	Cinto do Imperador Caído
21607	Garra do Imperador Caído
21608	Amuleto de Vek'nilash
21609	Cinto Regenerador de Vek'nilash
21610	Bloqueador de Escamas de Verme
21611	Braçadeiras do Escavador
21612	Pisoteadores de Escamas de Verme
21613	Botas de Pele de Verme
21614	Protetor de Pele de Verme
21615	Chapéu Perdido de Dom Rigoberto
21616	Aguilhão de Huhuran
21617	Manoplas de Casca de Vespa
21618	Munhequeiras do Profanador de Colmeias
21619	Luvas do Messias
21620	Anel do Mártir
21621	Manto da Colmeia Dourada
21622	Fêmur Silitídeo Afiado
21623	Manoplas do Campeão Íntegro
21624	Manoplas de Kalimdor
21625	Broche do Escaravelho
21626	Perneiras Cobertas de Visco
21627	Manto dos Segredos Não Revelados
21635	Farpa do Aniquilador Arenoso
21639	Brafoneiras do Implacável
21640	Caixote de Fogos de Artifício do Festival da Lua
21645	Botas do Escavador de Colmeias
21647	Fetiche do Aniquilador Arenoso
21648	Botas Reconstruídas
21650	Antiga Estripadora Qiraji
21651	Perneiras em Escamas do Aniquilador Arenoso
21652	Couraça de Carapaça Silitídea
21663	Vestes do Santo Guardião
21664	Gargantilha Farpada
21665	Dragonas da Revanche Perversa
21666	Poder de Sartura
21667	Coxotes da Luz Fulgurante
21668	Perneiras em Escamas da Fúria Qiraji
21669	Elmo da Vinha Assustadora
21670	Distintivo dos Guarda-enxames
21671	Vestes da Guarda de Batalha
21672	Luvas da Coação
21673	Garra Silitídea
21674	Manoplas da Determinação Inabalável
21675	Cinto de Escamas Qiraji Grosso
21676	Perneiras do Enxame Ulceroso
21677	Anel da Fúria Qiraji
21678	Colar da Pureza
21679	Revanche de Kalimdor
21680	Colete da Execução Rápida
21681	Anel do Devorado
21682	Manoplas Cobertas de Bile
21683	Dragonas da Cruzada do Deserto
21684	Dragonas da Fúria do Deserto
21685	Escaravelho Petrificado
21686	Dragonas do Poder Frênico
21687	Anel das Trevas de Ukko
21688	Botas do Herói Caído
21689	Luvas de Ebru
21690	Patuá da Angelista
21691	Manoplas Gosmentas
21692	Cinturão Tríade
21693	Máscara do Devorador
21694	Dragonas Ternárias
21695	Toque da Angelista
21696	Vestes do Triunvirato
21697	Capa da Trindade
21698	Perneiras da Imersão
21699	Omoplatas da Barragem
21700	Pingente do Guardião Qiraji
21701	Manto do Ódio Concentrado
21702	Amuleto da Proteção Pútrida
21703	Martelo de Ji'zhi
21704	Botas da Profecia Cumprida
21705	Botas do Profeta Caído
21706	Botas da Vontade Resoluta
21707	Anel do Enxame de Pensamentos
21708	Munhequeiras em Escamas do Besouro
21709	Anel do Deus Caído
21710	Manto do Deus Caído
21711	Convite do Festival da Lua
21712	Amuleto do Deus Caído
21713	Vela de Eluna
21714	Grande Salva de Foguetes Azuis
21715	Martelo Polido com Areia
21716	Grande Salva de Foguetes Verdes
21717	Grande Salva de Foguetes Roxos
21718	Grande Salva de Foguetes Vermelhos
21719	Grande Salva de Foguetes Brancos
21720	Grande Salva de Foguetes Amarelos
21721	Brilho da Lua
21722	Molde: Vestido do Festival
21723	Molde: Roupa do Festival
21724	Diagrama: Foguete Azul Pequeno
21725	Diagrama: Foguete Verde Pequeno
21726	Diagrama: Foguete Vermelho Pequeno
21727	Diagrama: Foguete Azul Grande
21728	Diagrama: Foguete Verde Grande
21729	Diagrama: Foguete Vermelho Grande
21730	Diagrama: Salva de Foguetes Azuis
21731	Diagrama: Salva de Foguetes Verdes
21732	Diagrama: Salva de Foguetes Vermelhos
21733	Diagrama: Grande Salva de Foguetes Azuis
21734	Diagrama: Grande Salva de Foguetes Verdes
21735	Diagrama: Grande Salva de Foguetes Vermelhos
21736	Rédeas do Grifo de Montaria
21737	Diagrama: Lançador de Salva de Fogos de Artifício
21738	Diagrama: Lançador de Fogos de Artifício
21740	Receitas de Foguetes Pequenos
21741	Receitas de Foguetes de Salva
21742	Receitas de Foguetes Grandes
21743	Receitas de Foguetes de Salva Grande
21744	Salva de Foguetes da Sorte
21745	Pedra-da-lua do Ancião
21746	Envelope Vermelho da Sorte
21747	Bombinha do Festival
21749	Instruções de Combate I
21750	Instruções de Combate II
21751	Instruções Táticas III
21761	Chave da Arca do Escaravelho
21762	Chave Maior da Arca do Escaravelho
21800	Lançador Encouraçado Silitídeo
21801	Tentáculo do Fortalecimento
21802	A Cris Perdida de Zedd
21803	Elmo do Vingador Sagrado
21804	Coifa da Fúria Elemental
21805	Brafoneiras de Obsidiana Polida
21806	Martelete da Autoridade Qiraji
21809	Fúria do Enxame Esquecido
21810	Botinas do Nômade Errante
21812	Caixa de Bombons
21813	Saco de Balas
21814	Peitoral da Aniquilação
21815	Prova de Amor
21816	Coração Doce
21817	Coração Doce
21818	Coração Doce
21819	Coração Doce
21820	Coração Doce
21821	Coração Doce
21822	Coração Doce
21823	Coração Doce
21829	Frasco de Perfume
21830	Embrulho Vazio
21831	Presente Embrulhado
21833	Vidro de Colônia
21836	Anel do Caos de Ritssyn
21837	Martelo de Guerra dos Anubisath
21838	Vestes da Ascensão Real
21839	Cetro do Falso Profeta
21856	Neretzek, o Sanguinário
21888	Luvas do Imortal
21889	Luvas da Profecia Cumprida
21890	Luvas do Profeta Caído
21891	Fragmento da Estrela Caída
21920	Carta Vincada
21921	Bilhete Cuidadosamente Escrito
21925	Carta Imaculada
21926	Bilhete Levemente Vincado
21928	Amostra de Sangue de Hibérnia
21935	Ectoplasma Estável
21936	Ectoplasma Congelado
21937	Ectoplasma Chamuscado
21938	Núcleo de Magma
21939	Bastão de Elemental Vil
21946	Destilador Ectoplásmico
21960	Artigos de Madeira Feitos à Mão
21975	Jura de Adoração: Ventobravo
21979	Presente de Adoração: Darnassus
21980	Presente de Adoração: Altaforja
21981	Presente de Adoração: Ventobravo
21982	Colar de Guerra dos Ogros
21983	Estandarte Incompleto da Provocação
21984	Parte Esquerda do Amuleto do Lorde Valthalak
21985	Recipiente Lacrado de Sangue
21986	Estandarte da Provocação
21987	Incendicita de Incendius
21988	Brasa do Mirabrasa
21989	Cinza das Cinzas
21994	Cinto do Heroísmo
21995	Botas do Heroísmo
21996	Braçadeiras do Heroísmo
21997	Peitoral do Heroísmo
21998	Manoplas do Heroísmo
21999	Elmo do Heroísmo
22000	Coxotes do Heroísmo
22001	Espaldares do Heroísmo
22002	Cinto do Manto Negro
22003	Botas do Manto Negro
22004	Braçadeiras do Manto Negro
22005	Casquete do Manto Negro
22006	Luvas do Manto Negro
22007	Calças do Manto Negro
22008	Espaldares do Manto Negro
22009	Túnica do Manto Negro
22010	Cinto do Senhor das Feras
22011	Braceletes do Senhor das Feras
22013	Casquete do Senhor das Feras
22014	Braseiro Santificado
22015	Luvas do Senhor das Feras
22016	Dragonas do Senhor das Feras
22017	Calças do Senhor das Feras
22046	Parte Direita do Amuleto do Lorde Valthalak
22047	Parte Superior do Amuleto do Lorde Valthalak
22048	Amuleto do Lorde Valthalak
22049	Braseiro de Sinalização
22050	Braseiro de Sinalização
22051	Braseiro de Sinalização
22052	Braseiro de Sinalização
22056	Braseiro de Sinalização
22057	Braseiro de Invocação
22058	Papel de Carta de Dia dos Namorados
22059	Cartão de Dia dos Namorados
22060	Túnica do Senhor das Feras
22061	Botas do Senhor das Feras
22062	Cinto do Feiticeiro
22063	Braçadeiras do Feiticeiro
22064	Botas do Feiticeiro
22065	Coroa do Feiticeiro
22066	Luvas do Feiticeiro
22067	Perneiras do Feiticeiro
22068	Dragonas do Feiticeiro
22069	Vestes do Feiticeiro
22070	Cinto Brumorte
22071	Braçadeiras Brumorte
22072	Perneiras Brumorte
22073	Dragonas Brumorte
22074	Máscara Brumorte
22075	Veste Brumorte
22076	Sandálias Brumorte
22077	Guarda-braços Brumorte
22078	Cinto do Virtuoso
22079	Braçadeiras do Virtuoso
22080	Coroa do Virtuoso
22081	Luvas do Virtuoso
22082	Dragonas do Virtuoso
22083	Veste do Virtuoso
22084	Sandálias do Virtuoso
22085	Saia do Virtuoso
22086	Cinto da Forja da Alma
22087	Botas da Forja da Alma
22088	Braçadeiras da Forja da Alma
22089	Peitoral da Forja da Alma
22090	Manoplas da Forja da Alma
22091	Elmo da Forja das Almas
22092	Coxotes da Forja da Alma
22093	Espaldares da Forja da Alma
22094	Algassangue
22095	Braceletes dos Cinco Trovões
22096	Botas dos Cinco Trovões
22097	Coifa dos Cinco Trovões
22098	Cordão dos Cinco Trovões
22099	Manoplas dos Cinco Trovões
22100	Kilt dos Cinco Trovões
22101	Brafoneiras dos Cinco Trovões
22102	Colete dos Cinco Trovões
22106	Cinto do Coração Feral
22107	Botas do Coração Feral
22108	Braçadeiras do Coração Feral
22109	Capucho do Coração Feral
22110	Luvas do Coração Feral
22111	Kilt do Coração Feral
22112	Espaldares do Coração Feral
22113	Colete do Coração Feral
22114	Ovo de Murloc Rosa
22115	Revelador Extradimensional de Fantasmas
22117	Jura de Lealdade: Ventobravo
22119	Jura de Lealdade: Altaforja
22120	Jura de Lealdade: Darnassus
22121	Jura de Lealdade: Cidade Baixa
22122	Jura de Lealdade: Penhasco do Trovão
22123	Jura de Lealdade: Orgrimmar
22130	Símbolo do Amor
22131	Coleção de Presentes de Ventobravo
22132	Coleção de Presentes de Altaforja
22133	Coleção de Presentes de Darnassus
22134	Coleção de Presentes da Cidade Baixa
22135	Coleção de Presentes do Penhasco do Trovão
22136	Coleção de Presentes de Orgrimmar
22137	Algibeira de Ysida
22138	Bracelete de  Rocha Negra
22139	Medalhão de Ysida
22140	Cartão da Sentinela
22141	Cartão do Guarda de Altaforja
22142	Cartão do Bruto
22143	Cartão do Guarda de Ventobravo
22144	Cartão do Vigia do Penhasco
22145	Cartão Mofado do Guardião
22149	Contas de Mojo Ogro
22150	Contas de Poder Ogro
22151	Água Benta de Anthion
22152	Bornal do Anthion
22154	Jura de Adoração: Altaforja
22155	Jura de Adoração: Darnassus
22156	Jura de Adoração: Orgrimmar
22157	Jura de Adoração: Cidade Baixa
22158	Jura de Adoração: Penhasco do Trovão
22159	Jura de Amizade: Darnassus
22160	Jura de Amizade: Altaforja
22161	Jura de Amizade: Orgrimmar
22162	Jura de Amizade: Penhasco do Trovão
22163	Jura de Amizade: Cidade Baixa
22164	Presente de Adoração: Orgrimmar
22165	Presente de Adoração: Penhasco do Trovão
22166	Presente de Adoração: Cidade Baixa
22167	Presente de Amizade: Darnassus
22168	Presente de Amizade: Altaforja
22169	Presente de Amizade: Orgrimmar
22170	Presente de Amizade: Ventobravo
22171	Presente de Amizade: Penhasco do Trovão
22172	Presente de Amizade: Cidade Baixa
22173	Cerveja Caseira Enânica
22174	Poesia Romântica
22175	Torta Fresquinha
22176	Pão Caseiro
22177	Flores Recém-colhidas
22178	Jura de Amizade: Ventobravo
22191	Túnica de Malha de Obsidiana
22192	Elixir de Algassangue de Esquiva
22193	Elixir de Algassangue de Resistência
22194	Garra Negra do Destruidor
22195	Cinto Leve de Obsidiana
22196	Peitoral Grosso de Obsidiana
22197	Cinto Pesado de Obsidiana
22198	Escudo Serrilhado Obsidiano
22200	Flecha com Haste de Prata
22201	Relicário da Pureza
22202	Pequeno Estilhaço de Obsidiana
22203	Grande Estilhaço de Obsidiana
22204	Munhequeiras do Renome
22205	Braceletes de Aço Negro
22206	Buquê de Rosas Vermelhas
22207	Faixa da Grande Caçada
22208	Martelo de Litomagma
22209	Instruções: Cinto Pesado de Obsidiana
22212	Brafoneiras para Golem
22214	Instruções: Cinto Leve de Obsidiana
22216	Vesícula de Peçonha de Venoxis
22217	Vesícula de Peçonha de Kurinnaxx
22218	Punhado de Pétalas de Rosas
22219	Instruções: Escudo Serrilhado Obsidiano
22220	Instruções: Garra Negra do Destruidor
22221	Instruções: Túnica de Malha de Obsidiana
22222	Instruções: Peitoral Grosso de Obsidiana
22223	Protetor de Cabeça do Capataz
22224	Essência de Espírito Zombeteiro
22225	Capucho de Pele de Dragão
22226	Restos Mortais Druídicos
22227	Relíquia do Vilarejo Brisastral
22228	Espada Brilhante do Fanatismo
22229	Cinzas de Alma Banida
22230	Pelego Boquiaberto
22231	Botas de Precisão do Kayser
22232	Cinturão do Atirador Perito
22233	Baú do Zigris
22234	Dragonas das Esperanças Perdidas
22235	Flecha com Haste de Veraprata
22236	Delícia de Leitelho
22237	Desejo Negro
22238	Creme Absoluta Fruta
22239	Doce Surpresa
22240	Grevas do Desespero Paralisante
22241	Espaldares do Guardador Obscuro
22242	Coleira de Verek
22243	Bolsinho de Almas
22244	Caixa de Almas
22245	Calçados Coberto de Cinzas
22246	Saco de Magitrama Encantado
22247	Botas do Curandeiro da Fé
22248	Bolsa de Runatrama Encantada
22249	Grande Bolsa de Encantamentos
22250	Bolsa de Herborismo
22251	Bolsa de Herborismo Cenariana
22252	Algibeira de Cenarius
22253	Tomo dos Perdidos
22254	Varinha da Luz Eterna
22255	Elo Forjado em Magma
22256	Mitenes de Moldar Mana
22257	Elo de Sangue Coagulado
22258	Poção do Amor
22259	Bracelete da Amizade Não Concedida
22260	Bracelete da Amizade
22261	Tolo Apaixonado
22262	Coleção de Presentes da Aliança
22263	Coleção de Presentes da Horda
22264	Carta Cuidadosamente Escrita
22265	Carta Escrita com Amor
22266	Espinho Ígneo
22267	Turbante do Tecencantos
22268	Emblema Dracônico Infuso
22269	Manto do Predador das Sombras
22270	Botas de Trincheira
22271	Perneiras da Magia Desenfreada
22272	Abraço da Floresta
22273	Capuz Umbraluna
22274	Pelagem Cinzenta
22275	Botas Musgo de Fogo
22276	Vestido Vermelho Encantador
22277	Traje Esporte Fino Vermelho
22278	Vestido Azul Encantador
22279	Vestido Preto Encantador
22280	Vestido Roxo Encantador
22281	Traje Esporte Fino Azul
22282	Traje Esporte Fino Roxo
22283	Saco de Pão Caseiro
22284	Monte de Cartões
22285	Coleção de Juras a Ventobravo
22286	Coleção de Juras a Altaforja
22287	Embrulho de Cartões
22288	Engradado de Cerveja Caseira
22289	Pilha de Cartões
22290	Coleção de Juras a Darnassus
22291	Caixa de Artigos de Madeira
22292	Caixa com Tortas Fresquinhas
22293	Pacote de Cartões
22294	Coleção de Juras a Orgrimmar
22295	Mochila de Cartões
22296	Cesta de Flores
22297	Coleção de Juras a Penhasco do Trovão
22298	Livro de Poesias Românticas
22299	Braçada de Cartões
22300	Coleção de Juras à Cidade Baixa
22301	Veste de Tramaférrea
22302	Capucho de Tramaférrea
22303	Calças de Tramaférrea
22304	Luvas de Tramaférrea
22305	Dragonas de Tramaférrea
22306	Cinto de Tramaférrea
22307	Molde: Saco de Magitrama Encantado
22308	Molde: Bolsa de Runatrama Encantada
22309	Molde: Grande Bolsa de Encantamentos
22310	Molde: Bolsa de Herborismo Cenariana
22311	Botas de Tramaférrea
22312	Molde: Algibeira de Cenarius
22313	Braçadeiras de Tramaférrea
22314	Arpão do Guarda-caça
22315	Martelo da Revitalização
22317	Soqueira do Canhoto
22318	Arco Longo de Malgen
22319	Tomo do Direito Divino
22320	Mercadorias de Qualidade de Mux
22321	Coração de Wyrmthalak
22322	Quebra-queixo
22324	Ragu de Inverno
22325	Cinto do Trapaceiro
22326	Anel do Amálgama
22327	Amuleto do Redimido
22328	Coxotes da Vigilância
22329	Cetro da Concentração Interminável
22330	Mortalha do Mistério Arcano
22331	Anel do Herói Resoluto
22332	Lâmina de Necromancia
22333	Martelo do Poder Divino
22334	Anel da Recomposição
22335	Cajado de Comando do Senhor Valthalak
22336	Égide Draconiana da Legião
22337	Mortalha da Dominação
22338	Cinza Vulcânica
22339	Elo Rúnico da Bruxaria
22340	Pingente da Celeridade
22342	Perneiras do Tormento
22343	Protetores de Mão Selvagens
22344	Braseiro de Invocação: Manual do Usuário
22345	Totem de Renascimento
22347	Repetidor de Recarga de Fahrad
22348	Arruinus Prime
22349	Peitoral Profanado
22350	Túnica Profanada
22351	Veste Profanada
22352	Coxotes Profanados
22353	Capacete Profanado
22354	Brafoneiras Profanadas
22355	Braçadeiras Profanadas
22356	Cinta Profanada
22357	Manoplas Profanadas
22358	Escarpes Profanados
22359	Guarda-pernas Profanado
22360	Bacinete Profanado
22361	Espaldares Profanados
22362	Munhequeiras Profanadas
22363	Cinturão Profanado
22364	Protetores de Mão Profanados
22365	Botas Profanadas
22366	Perneiras Profanadas
22367	Diadema Profanado
22368	Ombreiras Profanadas
22369	Braceletes Profanados
22370	Cinto Profanado
22371	Luvas Profanadas
22372	Sandálias Profanadas
22373	Restos de Couro
22374	Restos de Cota de Malha
22375	Restos de Placas
22376	Restos de Tecido
22377	Atiçador Pau-de-trovão
22378	Fatiadora de Corvoforte
22379	Lanceta do Engrenofaca
22380	Martelo de Cultivo da Simone
22381	Amostra de Peçonha de Silithus
22382	Recipiente de Peçonha Lacrado
22383	Lâmina do Sábio
22384	Persuasor
22385	Perneiras Titânicas
22386	Head of Instructor Razuvious DEP
22387	Coração de Anub'Rekhan
22388	Instruções: Perneiras Titânicas
22389	Instruções: Lâmina do Sábio
22390	Instruções: Persuasor
22392	Fórmula: Encantamento de Agilidade – Arma de 2M
22393	Códice: Prece de Proteção Sombria
22394	Cajado da Metanoia
22395	Totem da Raiva
22396	Totem da Vida
22397	Ídolo da Ferocidade
22398	Ídolo de Rejuvenescimento
22399	Ídolo da Saúde
22400	Incunábulo da Verdade
22401	Incunábulo da Esperança
22402	Incunábulo da Graça
22403	Colar de Concha Iridescente
22404	Coça-costas do Gualter
22405	Manto da Cruzada Escarlate
22406	Redenção
22407	Elmo da Lua Nova
22408	Varinha de Mojo Ruim de Ritssyn
22409	Túnica da Lua Crescente
22410	Manoplas de Destreza
22411	Elmo do Carrasco
22412	Dragonas de Thuzadin
22416	Peitoral Couraçado
22417	Coxotes Couraçados
22418	Capacete Couraçado
22419	Brafoneiras Couraçadas
22420	Escarpes Couraçados
22421	Manoplas Couraçadas
22422	Cinta Couraçada
22423	Braçadeiras Couraçadas
22424	Munhequeiras da Redenção
22425	Túnica da Redenção
22426	Protetores de Mão da Redenção
22427	Guarda-pernas da Redenção
22428	Bacinete da Redenção
22429	Espaldares da Redenção
22430	Botas da Redenção
22431	Cinturão da Redenção
22432	Farpa para Demossauro
22433	Anel da Dominação de Dom Mauricio
22434	Cogumelo Vermelho
22435	Ferrão de Gorishi
22436	Túnica Criptalante
22437	Guarda-pernas Criptalantes
22438	Bacinete Criptalante
22439	Espaldares Criptalantes
22440	Botas Criptalantes
22441	Protetores de Mão Criptalantes
22442	Cinturão Criptalante
22443	Munhequeiras Criptalantes
22444	Trepadeira Pútrida
22458	Báculo Umbraluna
22464	Túnica Quebraterra
22465	Guarda-pernas Quebraterra
22466	Bacinete Quebraterra
22467	Espaldares Quebraterra
22468	Botas Quebraterra
22469	Protetores de Mão Quebraterra
22470	Cinturão Quebraterra
22471	Munhequeiras Quebraterra
22472	Botas de Ferocidade
22476	Peitoral Ceifa-ossos
22477	Coxotes Ceifa-ossos
22478	Capacete Ceifa-ossos
22479	Brafoneiras Ceifa-ossos
22480	Escarpes Ceifa-ossos
22481	Manoplas Ceifa-ossos
22482	Cinta Ceifa-ossos
22483	Braçadeiras Ceifa-ossos
22484	Runa Necrótica
22488	Túnica Andassonho
22489	Guarda-pernas Andassonho
22490	Bacinete Andassonho
22491	Espaldares Andassonho
22492	Botas Andassonho
22493	Protetores de Mão Andassonho
22494	Cinturão Andassonho
22495	Munhequeiras Andassonho
22496	Veste de Fogofrio
22497	Perneiras de Fogofrio
22498	Diadema de Fogofrio
22499	Ombreiras de Fogofrio
22500	Sandálias de Fogofrio
22501	Luvas de Fogofrio
22502	Cinto de Fogofrio
22503	Braceletes de Fogofrio
22504	Veste do Coração Pestilento
22505	Perneiras do Coração Pestilento
22506	Diadema do Coração Pestilento
22507	Ombreiras do Coração Pestilento
22508	Sandálias do Coração Pestilento
22509	Luvas do Coração Pestilento
22510	Cinto do Coração Pestilento
22511	Braceletes do Coração Pestilento
22512	Veste da Fé
22513	Perneiras da Fé
22514	Diadema da Fé
22515	Ombreiras da Fé
22516	Sandálias da Fé
22517	Luvas da Fé
22518	Cinto da Fé
22519	Braceletes da Fé
22520	O Filactério de Kel'Thuzad
22523	Insígnia da Aurora
22524	Insígnia da Cruzada
22525	Pedaços de Carnífice da Cripta
22526	Fragmentos de Osso
22527	Núcleo dos Elementos
22528	Sucata de Ferro Negro
22529	Fronde Selvagem
22568	Escritura do Artífice
22589	Atiesh, Grande Cajado do Guardião
22593	Salvo-conduto
22595	Anúncio do Chamado às Armas
22600	Escritura do Artífice – Contrapeso Denso
22601	Escritura do Artífice – Peitoral de Placa Imperial
22602	Escritura do Artífice – Martelo Vulcânico
22603	Escritura do Artífice – Machado de Batalha de Tório Enorme
22604	Escritura do Artífice – Diadema Radiante
22605	Escritura do Artífice – Bandana de Couro Maléfico
22606	Escritura do Artífice – Kit de Armadura Rústica
22607	Escritura do Artífice – Cinto de Couro Maléfico
22608	Escritura do Artífice – Calças de Couro Rúnico
22609	Escritura do Artífice – Calças de Lumetrama
22610	Escritura do Artífice – Botas de Runatrama
22611	Escritura do Artífice – Bolsa de Runatrama
22612	Escritura do Artífice – Veste de Runatrama
22613	Escritura do Artífice – Carga Sapadora Goblínica
22614	Escritura do Artífice – Granada de Tório
22615	Escritura do Artífice – Frango de Batalha Gnômico
22616	Escritura do Artífice – Tubo de Tório
22617	Escritura do Artífice – Poção Elevada de Mana
22618	Escritura do Artífice – Poção Elevada de Cura
22619	Escritura do Artífice – Poção Maior de Proteção contra o Gelo
22620	Escritura do Artífice – Poção Maior de Proteção contra o Arcano
22621	Escritura do Artesão - Frasco de Petrificação
22622	Escritura do Artífice – Enguia Petrescama
22623	Escritura do Artífice – Peixe-armadura de Placas
22624	Escritura do Artífice – Enguia Elétrica
22625	Escritura do Artífice – Salmão Assado
22626	Escritura do Artífice – Escondidinho de Batata Rataplã
22630	Atiesh, Grande Cajado do Guardião
22631	Atiesh, Grande Cajado do Guardião
22632	Atiesh, Grande Cajado do Guardião
22635	Guarda Selvagem
22636	Guardafria
22637	Ídolo Hakkari Primevo
22638	Guardassombra
22648	Dossiê de Colme'Ashi
22649	Dossiê de Colme'Régia
22650	Dossiê de Colme'Zora
22651	Guarda-pernas de Placa do Pioneiro
22652	Colete Glacial
22654	Luvas Glaciais
22655	Pulsos Glaciais
22656	O Purificador
22657	Amuleto da Aurora
22658	Manto Glacial
22659	Medalhão da Aurora
22660	Abraço de Gaia
22661	Túnica Polar
22662	Luvas Polares
22663	Braçadeiras Polares
22664	Peitoral de Escama Gelada
22665	Braçadeiras de Escama Gelada
22666	Manoplas de Escama Gelada
22667	Braçadeiras da Esperança
22668	Braceleiras do Subterfúgio
22669	Peitoral da Perdição Gélida
22670	Manoplas da Perdição Gélida
22671	Braçadeiras da Perdição Gélida
22672	Guarda-pernas de Placa da Sentinela
22673	Perneiras Encadeadas do Pioneiro
22676	Perneiras de Malha do Pioneiro
22678	Talismã da Ascendência
22679	Sacola de Suprimentos
22680	Elo da Resolução
22681	Elo da Devoção
22682	Runa Congelada
22683	Molde: Abraço de Gaia
22684	Molde: Luvas Glaciais
22685	Molde: Manto Glacial
22686	Molde: Colete Glacial
22687	Molde: Pulsos Glaciais
22688	Último Recurso de Verimonde
22689	Elmo Santificado de Couro
22690	Perneiras do Caçador de Pestes
22691	A Crematória Corrompida
22692	Molde: Túnica Polar
22694	Molde: Luvas Polares
22695	Molde: Braçadeiras Polares
22696	Molde: Peitoral de Escama Gelada
22697	Molde: Manoplas de Escama Gelada
22698	Molde: Braçadeiras de Escama Gelada
22699	Perneiras da Perdição Gélida
22700	Perneiras Glaciais
22701	Perneiras Polares
22702	Perneiras de Escama Gelada
22703	Instruções: Peitoral da Perdição Gélida
22704	Instruções: Manoplas da Perdição Gélida
22705	Instruções: Braçadeiras da Perdição Gélida
22707	Toque Frio de Ramaladni
22708	Destino de Ramaladni
22711	Manto dos Adoradores Hakkari
22712	Poder da Tribo
22713	Cetro Ritual Zulian
22714	Manoplas Sacrificais
22715	Luvas do Atormentado
22716	Cinto do Poder Libertado
22718	Máscara Ensanguentada
22719	Manual de Omarion
22720	Turbante Zulian
22721	Anel de Servidão
22722	Selo do Berserker Gurubashi
22723	Uma Carta do Guardião dos Pergaminhos
22725	Anel de Cenarius
22726	Lasca de Atiesh
22727	Cajado de Atiesh
22728	Controlador de Tonque a Vapor
22729	Diagrama: Controlador de Tonque a Vapor
22730	Cordão de Cintura do Olho Furtivo
22731	Manto dos Devorados
22732	Marca de C'Thun
22733	Ponta do Cajado de Atiesh
22734	Base de Atiesh
22736	Andonisus, Ceifador de Almas
22737	Atiesh, Grande Cajado do Guardião
22739	Tomo do Polimorfo: Tartaruga
22740	Calças de Couro do Pioneiro
22741	Calças de Couro de Lagarto do Pioneiro
22742	Camisa Vela Sangrenta
22743	Faixa Vela Sangrenta
22744	Botas Vela Sangrenta
22745	Calças Vela Sangrenta
22746	Uniforme de Bucaneiro
22747	Perneiras de Seda do Pioneiro
22748	Perneiras Encadeadas da Sentinela
22749	Calças de Couro da Sentinela
22750	Calças de Couro de Lagarto da Sentinela
22752	Perneiras de Seda da Sentinela
22753	Guarda-pernas Lamelares da Sentinela
22754	Quintessência Eterna
22756	Colete Silvestre
22757	Coroa Silvestre
22758	Omoplatas Silvestres
22759	Elmo de Sarça
22760	Botas de Sarça
22761	Cinto de Sarça
22762	Peitoral Vinaferro
22763	Luvas Vinaferro
22764	Cinto Vinaferro
22765	Carta Desbotada
22766	Instruções: Peitoral Vinaferro
22767	Instruções: Luvas Vinaferro
22768	Instruções: Cinto Vinaferro
22769	Molde: Cinto de Sarça
22770	Molde: Botas de Sarça
22771	Molde: Elmo de Sarça
22772	Molde: Omoplatas Silvestres
22773	Molde: Coroa Silvestre
22774	Molde: Colete Silvestre
22780	Ovo de Murloc Branco
22781	Coleira do Urso Polar
22798	Poder de Menethil
22799	Caçador de Almas
22800	Cajado Sulfúreo
22801	Cajado do Crepúsculo
22802	Queda do Monarca
22803	Bruma da Meia-noite
22804	Presa de Maexxna
22806	Remorso da Viúva
22807	Lâmina Espectral
22808	O Castigador
22809	Malho do Cruzado Redimido
22810	Injetor de Toxinas
22811	Cordão das Almas
22812	Escravizador Nerubiano
22813	Espadão do Poder Profano
22815	Ruptura
22816	Machadinha de Osso Partido
22818	O Portador da Peste
22819	Escudo da Condenação
22820	Varinha do Destino
22821	Dedo do Destino
22822	iCoke Prize Voucher
22843	Grevas Encadeadas do Guarda-de-sangue
22852	Botinas de Couro de Dragão do Guarda-de-sangue
22855	Chancas de Medotrama do Guarda-de-sangue
22856	Chancas de Couro do Guarda-de-sangue
22857	Grevas de Malha do Guarda-de-sangue
22858	Grevas de Placa do Guarda-de-sangue
22859	Chancas de Cetim do Guarda-de-sangue
22860	Chancas de Seda do Guarda-de-sangue
22862	Luvas Encadeadas do Guarda-de-sangue
22863	Guantes de Couro de Dragão do Guarda-de-sangue
22864	Guantes de Couro do Guarda-de-sangue
22865	Mitenes de Medotrama do Guarda-de-sangue
22867	Luvas de Malha do Guarda-de-sangue
22868	Manoplas de Placa do Guarda-de-sangue
22869	Mitenes de Cetim do Guarda-de-sangue
22870	Mitenes de Seda do Guarda-de-sangue
22872	Cota de Placa do Legionário
22873	Perneiras de Placa do Legionário
22874	Cota Encadeada do Legionário
22875	Guarda-pernas Encadeados do Legionário
22876	Cota de Malha do Legionário
22877	Peito d'Armas de Couro de Dragão do Legionário
22878	Perneiras de Couro de Dragão do Legionário
22879	Peito d'Armas de Couro do Legionário
22880	Guarda-pernas de Couro do Legionário
22881	Guarda-pernas de Medotrama do Legionário
22882	Guarda-pernas de Cetim do Legionário
22883	Guarda-pernas de Seda do Legionário
22884	Túnica de Medotrama do Legionário
22885	Túnica de Cetim do Legionário
22886	Túnica de Seda do Legionário
22887	Guarda-pernas de Malha do Legionário
22890	Tomo de Proteção contra Gelo V
22891	Grimório de Proteção contra Sombras IV
22892	Pedra Necrótica Opaca
22895	Rocambole de Canela Conjurado
22897	Tomo de Conjurar Comida VII
22930	Envelope Manchado de Sangue
22932	Carta Rasgada
22935	Toque de Gelo
22936	Munhequeiras da Vingança
22937	Gema de Nerúbis
22938	Manto de Seda de Carnífice da Cripta
22939	Elo das Preces Não Atendidas
22940	Brafoneiras da Perdição Gélida
22941	Espaldares Polares
22942	O Abraço da Viúva
22943	Pingente de Pedra da Malícia
22944	Missiva Amassada
22945	Bilhete Aflito
22946	Uma Página Desalinhada
22947	Pingente dos Nomes Esquecidos
22948	Um Documento Borrado
22949	Cristal Necrótico Rachado
22950	Cristal Necrótico Fugaz
22954	Beijo da Aranha
22960	Manto de Sutura
22961	Elo de Reanimação
22967	Espaldares de Escama Gelada
22968	Dragonas Glaciais
22970	Envelope Manchado de Sangue
22972	Bilhete Aflito
22973	Missiva Amassada
22974	Uma Página Desalinhada
22975	Um Documento Borrado
22977	Carta Rasgada
22981	Coleira Perdida do Gluth
22983	Dragonas Cobertas de Geada
22988	O Fim dos Sonhos
22994	Mão Consumida do Poder
22999	Tabardo da Aurora Argêntea
23000	Côndrios de Placas da Abominação
23001	Olho da Diminuição
23002	Caixa de Tartaruga
23004	Ídolo da Longevidade
23005	Totem da Água Corrente
23006	Incunábulo da Luz
23007	Coleira do Leitão
23008	Relatório de Pesquisa Lacrado
23009	Varinha dos Mortos Sussurrantes
23010	Relatório de Pesquisa Lacrado
23011	Relatório de Pesquisa Lacrado
23012	Relatório de Pesquisa Lacrado
23013	Relatório de Pesquisa Lacrado
23014	Iblis, Lâmina do Serafim Caído
23015	Jaula de Rato
23016	Relatório de Pesquisa Lacrado
23017	Véu do Eclipse
23018	Sinete do Defensor Caído
23019	Capacete da Perdição Gélida
23020	Capacete Polar
23021	Braçadeiras do Ceifador de Almas
23022	Recompensa do Rabugento
23023	Coleira do Sádico
23024	Papéis Preparados de Serviço em Campanha
23025	Selo do Maldito
23027	Cordialidade do Perdão
23028	Elo de Granizo
23029	Coração Frígido de Noth
23030	Manto do Flagelo
23031	Anel do Inevitável
23032	Diadema Glacial
23033	Coifa de Escama Gelada
23034	Nax PH Crit Plate Shoulders
23035	Chapéu do Preceptor
23036	Colar da Necropsia
23037	Anel do Fervor Espiritual
23038	Elo das Forças Sobrenaturais
23039	O Olho de Nerub
23040	Glifo de Deflexão
23041	Escudo do Matador
23042	Reflexão de Repugnaz
23043	A Face da Morte
23044	Emissário da Destruição
23045	Mortalha de Domínio
23046	A Essência Contida de Sapphiron
23047	Olho dos Mortos
23048	Olho Direito do Sapphiron
23049	Olho Esquerdo do Sapphiron
23050	Manto da Necrópole
23053	Talismã da Ebulição de Tempesfúria
23054	Gressil, o Despertar da Decadência
23055	Palavra do Degelo
23056	Martelo de Espiral Etérea
23057	Gema dos Inocentes Encurralados
23058	Colar da Canalização de Vida
23059	Anel Couraçado
23060	Anel Ceifa-ossos
23061	Anel da Fé
23062	Anel de Fogofrio
23063	Anel do Coração Pestilento
23064	Anel Andassonho
23065	Anel Quebraterra
23066	Anel da Redenção
23067	Anel Criptalante
23068	Coxotes da Chacina
23069	Traje do Necro-cavaleiro
23070	Perneiras da Polaridade
23071	Perneiras do Apocalipse
23072	Brafoneiras do Implacável
23073	Botas do Deslocamento
23075	Oferta da Morte
23078	Manoplas de Matar Mortos-vivos
23081	Mitenes de Matar Mortos-vivos
23082	Protetores de Mão de Matar Mortos-vivos
23083	Chama Capturada
23084	Luvas da Purificação de Mortos-vivos
23085	Veste da Purificação de Mortos-vivos
23087	Peitoral de Matar Mortos-vivos
23088	Couraça de Matar Mortos-vivos
23089	Túnica de Matar Mortos-vivos
23090	Braçadeiras de Matar Mortos-vivos
23091	Braçadeiras da Purificação de Mortos-vivos
23092	Braçadeiras de Matar Mortos-vivos
23093	Munhequeiras de Matar Mortos-vivos
23122	Pedra de Afiar Consagrada
23123	Óleo Abençoado de Teurgo
23124	Cajado de Balzaphon
23125	Correntes do Lich
23126	Cintel de Balzaphon
23127	Manto de Revanchion
23128	Soqueira da Sombra
23129	Braçadeiras de Recomposição
23132	Lâmina do Lorde Umbráxilos
23139	Broquel do Lorde Umbráxilos
23156	Coxa do Umbráxilos
23160	Pão da amizade
23161	Limonada Fresquinha
23162	Bolsa Grandona
23163	Performer's Wand
23164	Bubbly Beverage
23168	Adaga Focal de Escarne
23169	Gargantilha Gélida de Escarne
23170	A Garra Gélida
23171	O Machado de Decepar
23172	Refreshing Red Apple
23173	Perneiras de Pele de Abominação
23175	Tasty Summer Treat
23176	Fizzy Energy Drink
23177	Varinha da Lady Falther'essa
23178	Dragonas da Lady Falther'Ess
23179	Chama de Orgrimmar
23180	Chama do Penhasco do Trovão
23181	Chama da Cidade Baixa
23182	Chama de Ventobravo
23183	Chama de Altaforja
23184	Chama de Darnassus
23192	Tabardo da Cruzada Escarlate
23193	Rédeas do Corcel Descarnado
23194	Marca Inferior da Aurora
23195	Marca da Aurora
23196	Marca Maior da Aurora
23197	Ídolo da Lua
23198	Ídolo de Brutalidade
23199	Totem de Tempestade
23200	Totem de Sustentação
23201	Incunábulo da Divindade
23203	Incunábulo do Fervor
23206	Marca do Campeão
23207	Marca do Campeão
23211	Orcmellow Tostado
23215	Saco de Ingredientes de Orcmellow
23219	Cinturão do Mentor
23220	Veste Tecida com Cristais
23221	Braço Perdido do Servo
23224	Summer Gift Package
23226	Túnica de Pele de Carniçal
23227	iCoke Gift Box Voucher
23237	Anel da Chama Eterna
23238	Broquel Estígio
23242	Garra da Serpe Gélida
23243	Omoplatas de Placa do Campeão
23244	Elmo de Placa do Campeão
23246	Bebida Fogosa do Festival
23247	Flor de Fogo
23250	Concha Prismática
23251	Elmo Encadeado do Campeão
23252	Omoplatas Encadeadas do Campeão
23253	Cimeira de Couro de Dragão do Campeão
23254	Omoplatas de Couro de Dragão do Campeão
23255	Capucho de Medotrama do Campeão
23256	Espaldares de Medotrama do Campeão
23257	Elmo de Couro do Campeão
23258	Omoplatas de Couro do Campeão
23259	Cimeira de Malha do Campeão
23260	Brafoneiras de Malha do Campeão
23261	Capuz de Cetim do Campeão
23262	Dragonas de Cetim do Campeão
23263	Capucho de Seda do Campeão
23264	Dragonas de Seda do Campeão
23272	Peitoral Lamelar do Capitão-cavaleiro
23273	Perneiras Lamelares do Capitão-cavaleiro
23274	Manoplas Lamelares do Tenente-cavaleiro
23275	Escarpes Lamelares do Tenente-cavaleiro
23276	Cimeira Lamelar do Tenente-comandante
23277	Omoplatas Lamelares do Tenente-comandante
23278	Grevas Encadeadas do Tenente-cavaleiro
23279	Munhequeiras Encadeadas do Tenente-cavaleiro
23280	Guantes de Couro de Dragão do Tenente-cavaleiro
23281	Botinas de Couro de Dragão do Tenente-cavaleiro
23282	Mitenes de Medotrama do Tenente-cavaleiro
23283	Chancas de Couro do Tenente-cavaleiro
23284	Guantes de Couro do Tenente-cavaleiro
23285	Chancas de Couro do Tenente-cavaleiro
23286	Manoplas de Placa do Tenente-cavaleiro
23287	Grevas de Placa do Tenente-cavaleiro
23288	Mitenes de Cetim do Tenente-cavaleiro
23289	Chancas de Cetim do Tenente-cavaleiro
23290	Mitenes de Seda do Tenente-cavaleiro
23291	Chancas de Seda do Tenente-cavaleiro
23292	Cota Encadeada do Capitão-cavaleiro
23293	Guarda-pernas Encadeadas do Capitão-cavaleiro
23294	Peito d'Armas de Couro de Dragão do Capitão-cavaleiro
23295	Perneiras de Couro de Dragão do Capitão-cavaleiro
23296	Guarda-pernas de Medotrama do Capitão-cavaleiro
23297	Túnica de Medotrama do Capitão-cavaleiro
23298	Peito d'Armas de Couro do Capitão-cavaleiro
23299	Guarda-pernas de Couro do Capitão-cavaleiro
23300	Cota de Placa do Capitão-cavaleiro
23301	Perneiras de Placa do Capitão-cavaleiro
23302	Guarda-pernas de Cetim do Capitão-cavaleiro
23303	Túnica de Cetim do Capitão-cavaleiro
23304	Guarda-pernas de Seda do Capitão-cavaleiro
23305	Túnica de Seda do Capitão-cavaleiro
23306	Elmo Encadeado do Tenente-comandante
23307	Omoplatas Encadeadas do Tenente-comandante
23308	Cimeira de Couro de Dragão do Tenente-comandante
23309	Omoplatas de Couro de Dragão do Tenente-comandante
23310	Capucho de Medotrama do Tenente-comandante
23311	Espaldares de Medotrama do Tenente-comandante
23312	Elmo de Couro do Tenente-comandante
23313	Omoplatas de Couro do Tenente-comandante
23314	Elmo de Placa do Tenente-comandante
23315	Omoplatas de Placa do Tenente-comandante
23316	Capuz de Cetim do Tenente-comandante
23317	Dragonas de Cetim do Tenente-comandante
23318	Capucho de Seda do Tenente-comandante
23319	Dragonas de Seda do Tenente-comandante
23320	Tabuleta de Choque Flamejante VI
23323	Coroa do Festival do Fogo
23324	Dragonas do Festival do Fogo
23326	Linguiça do Solstício
23327	Pão Doce Tostado no Fogo
23360	Cabeça do Instrutor Razúvio
23379	Braceletes do Elemental de Brasas
23435	Torta de Sabugo
23451	Magespada do Grão-marechal
23452	Tomo de Poder do Grão-marechal
23453	Tomo de Restauração do Grão-marechal
23454	Martelo de Guerra do Grão-marechal
23455	Demolidor do Grão-marechal
23456	Lâmina Célere do Grão-marechal
23464	Maça de Batalha do Sumo Senhor da Guerra
23465	Destruidor do Sumo Senhor da Guerra
23466	Lâmina Enfeitiçada do Sumo Senhor da Guerra
23467	Gumepresto do Sumo Senhor da Guerra
23468	Tomo de Destruição do Sumo Senhor da Guerra
23469	Tomo de Recomposição do Sumo Senhor da Guerra
23545	Poder do Flagelo
23547	Resiliência do Flagelo
23548	Poder do Flagelo
23549	Fortitude do Flagelo
23557	Larva do Grande Verme
23558	A Carapaça do Escavador
23570	Jom Gabbar
23577	O Frio Voraz
23578	MacMolhofraco Dietético
23579	O Clássico MacMolhofraco
23656	Item de Teste Promocional
23663	Cinturão da Fúria Elemental
23664	Brafoneiras da Fúria Elemental
23665	Perneiras de Fúria Elemental
23666	Cinto do Grande Cruzado
23667	Espaldares do Grande Cruzado
23668	Perneiras do Grande Cruzado
23683	Pastilha de Lasca de Cristal
23684	Bandagem Infusa com Cristal
23689	Manual: Bandagem Infusa com Cristal
23690	Receita: Pastilha de Lasca de Cristal
23705	Tabardo das Chamas
23709	Tabardo de Gelo
23710	Tabardo Nº 3 do Convés Superior
23712	Cria de Tigre Branco
23713	Filhote de Hipogrifo
23714	Fogos de Artifício Roxos Perpétuos
23715	Coquetel de Sumo de Pulmão Permanente
23716	Ídolo de Ogro Entalhado
23718	Amostra de Escórpode Macerado Permanente
23719	Composto de Córtex Cerebral Permanente
23720	Tartaruga de Montaria
23721	Chiclete de Moela Permanente
23722	B.O.M.B.A. Permanente
23794	Reflexo de Zanza Inesgotável
23795	Espírito de Zanza Permanente
23796	Rapidez de Zanza Permanente
24071	Adaga Branda
24101	Livro de Mordida Feroz V
24102	Manual de Eviscerar IX
24222	O Apunhalador Pé-sombrio
24231	Rapé Ordinário
24232	Nó Ordinário
24281	Marfim Entalhado
24282	Diário do Ladino
24283	Pistola Antiga
122270	Ficha de WoW
122284	Ficha de WoW
172070	Pacote do Atendimento ao Cliente
180089	Coleira do Panda
184937	Deslocador Dádiva do Tempo
184938	Deslocador Dádiva do Tempo Supercarregado
189419	Fire Resist Plate Gear
189420	Fire Resist Plate Gear
189421	Fire Resist Leather Gear
189426	Raid Consumables
189427	More Raid Consumables
190179	Coração de Avelina
190180	Coração de Isaac
190181	Corações dos Amantes
190186	Estatueta de Madeira
190187	Lenço Fenecido
190232	Lenço Fenecido
190307	Tocha Apagada
190308	Tocha Acesa
190309	Estatueta de Madeira
190325	Monstro - Íncubo Chicote Maça - 1M
191204	Pedra Mortal Menor
191249	Pedra Mortal Maior
191267	Runa de Teleporte: Antecâmara
191268	Orbe da Corrupção
191272	Bastão da Necromancia
191280	Aglomerado de Esporos Fúngicos
191288	Runa de Teleporte: Covil da Serpe Gélida
191292	Adaga Ritualística
191312	Filactério Infalível
191313	Máscara da Morte
191414	Artefato Esqueletal
191458	Filactério Estilhaçado
191459	Runa da Fortuna
191477	Poste de Amarrar Esqueletal
191480	Corcel Descarnado
191481	Tabardo da Maestria
191550	Livro das Pedras Mortais: Máscara da Morte
191605	Livro das Pedras Mortais: Runa de Teleporte I
191606	Livro das Pedras Mortais: Orbe da Corrupção
191607	Livro das Pedras Mortais: Artefato Esqueletal
191608	Livro das Pedras Mortais: Bastão da Necromancia
191609	Livro das Pedras Mortais: Aglomerado de Esporos Fúngicos
191610	Livro das Pedras Mortais: Adaga Ritualística
191611	Livro das Pedras Mortais: Filactério Infalível
191612	Livro das Pedras Mortais: Runa de Teleporte II
191613	Livro das Pedras Mortais: Runa da Fortuna
191614	Livro das Pedras Mortais: Poste de Amarrar Esqueletal
191656	Essência da Morte
191660	Raios de Thaddius
191661	Presa de Aranha Monstruosa
191664	Livro das Pedras Mortais: Raios de Thaddius
191666	Livro das Pedras Mortais: Presa de Aranha Monstruosa
202251	Saco de Guloseimas para Ajudantes
202254	Braçadeiras do Redirecionamento
202256	Pistola Ornada do Corsário
202641	Caderno Coberto de Lama
203723	Bilhete do Picote
203726	Runa do Picote
203745	Anotações de Feitiços: Lança de Gelo
203746	Anotações de Feitiços: Chama Viva
203747	Anotações de Feitiços: Dedos Glaciais
203748	Anotações de Feitiços: Combustão
203749	Anotações de Feitiços: Esclarecimento
203750	Mapa do Tesouro de Elwynn
203751	Anotações de Feitiços: ALEG DEN AÇOL
203752	Anotações de Feitiços: VACMA IHAV
203753	Anotações de Feitiços: COLESDI DASGAI
203754	Arquimago Antônidas: A Biografia Completa
203755	Diário de Pesquisa do Arquimago Teócrito
203756	Notas do Aprendiz de Azora: Página 1
203784	Pedaço do Canto Direito Superior do Mapa
203785	Pedaço do Canto Esquerdo Superior do Mapa
203786	Pedaço do Canto Direito Inferior do Mapa
203787	Pedaço do Canto Esquerdo Inferior do Mapa
203960	Notas do Aprendiz de Azora: Página 2
203961	Notas do Aprendiz de Azora: Página 3
203962	Notas do Aprendiz de Azora: Página 4
203990	Runa da Mutilação
203991	Runa de Saque Rápido
203992	Runa dos Ardis
203993	Runa do Massacre
203994	Runa da Mistura Mortífera
204174	Runa da Precisão
204270	Núcleo das Profundezas
204441	Runa do Frenesi de Sangue
204476	Cabeça de Kobold Decepada
204477	Cabeça de Murloc Decepada
204478	Cabeça de Gnoll Decepada
204688	Primeiro Fragmento da Runa do Caçador de Monstros
204689	Segundo Fragmento da Runa do Caçador de Monstros
204690	Terceiro Fragmento da Runa do Caçador de Monstros
204703	Runa de Devastar
204716	Runa do Ataque Frenético
204795	Runa do Golpe Sombrio
204804	Braceletes Hidraxianos
204806	Runa do Ímpeto da Vitória
204807	Lâmina das Profundezas
204809	Runa do Trovão Furioso
204864	Notas do Aprendiz de Azora
204905	Tomo Agourento
204906	Sangue de Gnoll
204907	Mandíbula de Lobo
204910	Monstro - Tridente, Naga (Ouro)
204912	Runa da Graça
205019	Estilhaço de Alma Maculado
205020	Estilhaço de Alma Puro
205022	Runa do Sifão da Alma
205181	Artefato Não Identificado
205182	Artefato Sem Poderes
205183	Artefato Movido a Vileza
205184	Nota do Acólito
205215	Runa da Tática
205218	Incunábulo da Descoberta
205228	Runa da Seta do Caos
205230	Runa da Assombração
205364	Mochila do Acólito
205420	Incunábulo do Julgamento
205683	Runa de Repreensão
205685	Runa de Égide
205863	Incunábulo Corrompido
205864	Bilhete Calcinado
205897	Runa da Luz Divina
205905	Memória de um Campeão Devoto
205932	Profecia do Óbito de um Rei
205940	Memória de um Propósito Sombrio
205942	Epifania Quimérica
205943	Profecia de uma Cidadela Profanada
205944	Epifania Recíproca
205945	Memória de um Salvador Aprisionado
205946	Memória da Traição de um Líder
205947	Profecia de uma Cidadela Profanada
205948	Epifania Anódina
205949	Epifania Múltipla
205950	Epifania Tenebrosa
205951	Memória de um Acólito Conturbado
205952	Memória de um Mundo Despedaçado
205953	Profecia de um Voto Quebrado
205961	Carne de Pássaro de Mulgore
205979	Runa de Flanqueamento
205995	Almíscar de Cão-da-pradaria
206032	Runa de Trinchar
206155	Runa de Atirador de Precisão
206157	Carga de Mineração de Cequatrum
206159	Disfarce da Empreendimentos S.A.
206168	Runa da Quimera
206169	Runa de Tiro Explosivo
206170	Cone de Fúria dos Ventos
206175	Unguento de Pinhão
206176	Almofariz e Pilão
206177	Manteiga de Pinhão
206264	Runa de Inspiração
206344	Jogo de Facas
206345	Pedaços de Peixe
206376	Ícone do Baluarte
206381	Ícone Diádico
206382	Ícone Tempestuoso
206383	Ícone Lítico
206384	Ícone Astral
206385	Ícone Clástico
206386	Ícone Galvânico
206387	Ícone Kajárico
206388	Ícone Sulfúreo
206389	Ícone de Enxofre
206390	Ícone Íctio
206391	Ícone Sizígico
206466	Coroa da Pradaria
206469	Flor da Pradaria
206954	Ídolo de Raiva Ursina
206963	Runa do Potencial Natural
206966	Bulbo de Satirídea
206970	Runa da Vida
206975	Chave do Depósito de Artefatos
206985	Eco do Alfa
206989	Runa do Sol
206992	Runa de Esmagar Crânio
206994	Cabeça de Javatusco Decepada
206995	Cabeça de Harpia Decepada
207062	Cabeça de Centauro Decepada
207098	Bilhete de Ba'so
207106	Pedaço do Canto Esquerdo Inferior do Mapa
207107	Pedaço do Canto Direito Inferior do Mapa
207108	Pedaço do Canto Esquerdo Superior do Mapa
207109	Pedaço do Canto Direito Superior do Mapa
207110	Mapa do Tesouro de Durotar
207590	Carne de Porco de Durotar
207631	Feromônio de Áspide
207731	Tomo Agourento
207732	Perna de Makrura
207733	Crânio Kultireno
207972	As Lições de Ta'zo
207973	Mandíbula de Canaz
207974	Tomo Agourento
207975	Cabeça de Morcego Decepada
208005	Chave da Arca de Relíquias dos Agamand
208007	Chave do Baú do Naufrágio
208034	Mapa do Tesouro de Tirisfal
208035	Pedaço do Canto Direito Superior do Mapa
208036	Pedaço do Canto Esquerdo Superior do Mapa
208037	Pedaço do Canto Direito Inferior do Mapa
208038	Pedaço do Canto Esquerdo Inferior do Mapa
208085	Anel-sinete do Tenente Escarlate
208086	Memorando Escarlate Forjado
208139	Tomo Agourento
208140	Sangue de Wendigo
208158	Coração de Trogg Imaculado
208159	Cabeça de Troll Decepada
208160	Pata de Wendigo Decepada
208180	Almíscar de Coelho
208183	Notas de Boticário
208185	A Cartilha Metafísica do Boticário
208192	Carne de Porco de Dun Morogh
208196	Anel de Moa'kin
208205	Anotação de Raturno
208213	Pedaço do Canto Direito Superior do Mapa
208215	Pedaço do Canto Esquerdo Superior do Mapa
208218	Pedaço do Canto Direito Inferior do Mapa
208219	Pedaço do Canto Esquerdo Inferior do Mapa
208220	Mapa do Tesouro de Dun Morogh
208222	Retaliador da Velha Guarda
208223	Mochila do Acólito
208224	Nota do Acólito
208414	Ídolo Lunar
208425	Vestígio Arcaico Brilhoso
208484	Luz do Sol
208601	Pedaço do Canto Direito Superior do Mapa
208602	Pedaço do Canto Esquerdo Superior do Mapa
208603	Pedaço do Canto Direito Inferior do Mapa
208604	Pedaço do Canto Esquerdo Inferior do Mapa
208605	Mapa do Tesouro de Teldrassil
208607	Almíscar de Cervo
208608	Carne de Ave de Teldrassil
208609	Flor da Clareira
208610	Cabeça de Tigre Decepada
208611	Cabeça de Tigre Decepada
208612	Cabeça de Aranha Decepada
208682	Ovo de Mordelisca Abandonado
208687	Runa de Lacerar
208689	Ídolo Feroz
208701	Runa de Domínio das Feras
208739	Estandarte de Guerra da Horda
208741	Runa de Raiva Infinita
208743	Alma de Ganância
208744	Runa de Setas Sombrias
208749	Chave do Estoque de Masca-pinho
208750	Runa de Canalização
208753	Anotações de Feitiços: Regeneração
208754	Anotações de Feitiços: REÇÃO ERNAGE
208758	Runa Terrana
208760	Coroa da Clareira
208764	Runa da Mente
208765	Mão Amiga
208766	Mão Amiga
208767	Runa de Recomposição
208768	Caixa de Fósforos dos Bucaneiros
208771	Runa de Dança de Lâminas
208772	Runa de Talho de Sabre
208773	Arpão de Pesca
208777	Runa do Franco-atirador
208778	Runa de Golpe Rápido
208799	Anotações de Feitiços: Bomba Viva
208800	Baxtan: Sobre Magias Destrutivas
208823	Moeda de Oferenda
208828	Memória de um Voto Quebrado
208833	Torta Malevolente
208838	Cofre de Ferro Negro
208843	Totem de Batalha
208847	Geodo de Caveira
208848	Geodo de Caveira Rachado
208849	Incunábulo das Bênçãos
208851	Incunábulo de Justiça
208853	Anotações de feitiços: Congelamento Cerebral
208854	Anotações de Feitiços Mastigadas
208855	Isca de Albacora Arco-íris
208860	Rumi de Gnomeregan: Trabalhos Reunidos
209027	Petiscos de Caranguejo
209028	Anotações de Feitiços: IBAMB VOVA
209029	Mensagem de Emily
209030	Chave do Estoque de Equipamentos
209031	Envelope Discreto
209041	Sementes de Abóbora Mágicas
209042	Farinha de Osso de Peixe
209043	Amostra de Solo Fértil
209045	Alma do Mar
209047	Arpão Nodoso
209056	Peças Sobressalentes do Ceifador
209057	Protótipo de Engenho
209058	Núcleo de Elemental
209059	Pernil de Goretusco
209418	Armadura de Tartaruga Adamantina
209420	Bate-guelra
209421	Cordão de Aquanis
209422	Gargantilha de Maré Alta
209423	Lenço Esvoaçante
209424	Barreira de Placa de Carapaça
209432	Cilha de Ghamoo-ra
209436	Dentada de Serra'kis Lascada
209523	Capa do Trilhador Cintilante
209524	Amarras de Serra'kis
209525	Talwar Aguanegra Aprimorado
209527	Manoplas da Batalha das Nagas
209534	Arcobalista de Azshari
209559	Bengala do Sábio do Crepúsculo
209560	Julgamento do Martelo da Retidão
209561	Bastão do Sonâmbulo Ancestral
209562	Golpe da Hidra Mortal
209563	Rompe-coração das Nagas
209564	Tridente do Guardião
209565	Anel de Lugares Profundos
209566	Perneiras do Fiel
209567	Machado do Recife de Coral
209568	Manoplas de Algas
209569	Botas Altas de Pelego de Murloc
209570	Tomo da História da Caverna
209571	Luz Morta
209572	Couros Cozidos Pretos
209573	Pináculo Furioso
209574	Preceitos Descartados do Punho de Prata
209575	Ícone de Madeira Entalhada
209576	Cogumelo da Expansão Mental
209577	Punho do Indomado
209578	Embraces de Couro Faiscante
209579	Trovão Estrondoso
209580	Vento Tempestuoso
209581	Escarpes de Punho de Prata
209590	Globo d'Água Rachado
209608	Chave-mestra do Capitão
209611	Insígnia da Aliança
209612	Insígnia da Aliança
209613	Insígnia da Aliança
209614	Insígnia da Aliança
209615	Insígnia da Aliança
209616	Insígnia da Aliança
209617	Insígnia da Aliança
209618	Insígnia da Aliança
209619	Insígnia da Horda
209620	Insígnia da Horda
209621	Insígnia da Horda
209622	Insígnia da Horda
209623	Insígnia da Horda
209624	Insígnia da Horda
209625	Insígnia da Horda
209626	Insígnia da Horda
209667	Perneiras do Vislumbrador
209668	Sinete do Lorde do Crepúsculo
209669	Sapatos do Invocador do Crepúsculo
209670	Pisantes de Pele
209671	Vestes do Invocador do Crepúsculo
209672	Luvas sem Dedos Pretas
209673	Amuleto de Fetiche Chamejante
209674	Ignição da Fênix
209675	Túnica de Tramaconcha
209676	Guarda-ombros de Profundezas Esmagadoras
209677	Aro de Correntes Rápidas
209678	Manto do Assassino de Manguais
209679	Ombreiras da Noviça Azshari
209680	Lenço à Prova d'Água
209681	Ovo de Murloc Preto
209682	Capuz Resistente
209683	Xale do Invocador do Crepúsculo
209684	Calças da Sanguessuga de Alma
209685	Cilha de Musgo Antiga
209686	Colar de Osso Serrilhado
209687	Couraça de Pele de Hidra
209688	Bacamarte de Bael Modan
209689	Galochas de Cascoguejo
209690	Coifa de Trevescama
209691	Faca de Bota Vampírica
209692	Brafoneiras da Sentinela
209693	Pérola das Profundezas Negras Perfeita
209694	Adaga Ritual das Profundezas Negras
209748	Orbe de Althalaxx
209778	Sal do Evocador
209779	Partícula de Mannoroth
209800	Fragmentos de Orbe
209816	Fetiche de Traquinagem
209817	Broche do Emissário do Caos
209818	Crescente Tocado pelo Sol
209819	Varinha de Domar Mantícora
209820	Gargantilha de Mortalha Negra
209821	Anel do Mirante Negro
209822	Força do Propósito
209823	Sinete de Feras
209824	Ombreiras Cintilantes
209825	Gargantilha de Gotinha
209828	Brafoneiras Subzero
209830	Arcobalista de Couro de Ferro
209836	Orbe de Althalaxx
209838	Cristal Hipnótico
209840	Varinha Nodosa de Magia Selvagem
209841	Essência de Magia Selvagem
209843	Almanaque de Nar'thalas, Vol. 74
209844	O Resumo de Dalaran, Vol. 23
209845	Encantamentos e Glamours
209846	Segredos dos Sonhadores
209847	Manual de Sistemas Arcânicos
209848	Pergaminhos de Goaz
209849	Crimes contra a Anatomia
209850	Runas dos Reis Feiticeiros
209851	Fúria da Terra
209852	Runa de Comando para Matar
209872	Elmo do Mata-dragões
209873	Escudo do Mata-dragões
209874	Lança do Mata-dragões
210015	Runa de Golpe Furioso
210026	Símbolo da Terceira Coruja
210043	Símbolo da Segunda Coruja
210044	Símbolo da Primeira Coruja
210045	Folhumbra
210053	Pata de Lobo Hediondo
210055	Ossos Humanos de Eira dos Montes
210056	Tintura da Morte Desperta
210080	Oferenda Vodu
210137	Runa do Crescimento Silvestre
210138	Artilharia dos Ferro Negro
210146	Turbocompressor de Retalhador
210147	Unidade Retalhadora Autorrecuperável
210177	Ataeric: Sobre Curiosidades Arcanas
210178	Diagrama: Unidade Retalhadora Autorrecuperável
210179	Anotações de feitiços: VEDASI SI LESSAM
210183	Trompa de Xelthos
210186	Carga de Transposição
210187	Ordem de Serviço da Empreendimentos S.A.
210188	Ordem de Serviço Triturada
210195	Ídolo Desequilibrado
210209	Chave Gêmea
210210	Certificado de Fundação das Indústrias de Defesa Grizzútil
210212	Metade de Chave do Irmão
210213	Metade de Chave da Irmã
210229	Runa da Mutilação
210250	Anel de Ouro Gravado
210251	Anel de Prata Gravado
210252	Runa da Estocada
210253	Totem de Podridão
210322	Runa de Peçonha
210323	Combinação do Cofre
210329	Mapa do Tesouro de Eira dos Montes
210330	Dica Quente
210410	Isca de Tartalisca de Água Doce
210499	Charcomelo
210500	Runa das Estrelas
210534	Ídolo do Selvagem
210568	Filactério Decrépito
210569	Runa de Flagelação
210573	Runa de Raiva Debilitante
210589	Eco dos Antepassados
210596	Runa de Golpes de Naja
210653	Runa de Adaga de Bloqueio
210654	Anotações de Feitiços: Retroceder Tempo
210655	Anotações de Feitiços: DEPOMECTRE RETRO
210665	Grânulo de Raiva Torrencial
210667	Grânulo de Raiva Infernal
210668	Grânulo de Raiva Sísmica
210696	Ruína dos Pútridos
210708	Elixir do Arrependimento Coalescido
210709	Receita: Elixir do Arrependimento Coalescido
210712	Elixir da Percepção
210713	Alma Torturada
210724	Cajado de Hirzek
210741	Espanca-gente Automático
210746	Runa de Escudo da Terra
210763	Ramo de Altek
210765	Orbe de Des
210771	Suprimentos Escondidos: Barras de Cobre
210772	Carga de Suprimentos: Barras de Cobre
210773	Dragonas da Segunda Guerra
210779	Instruções: Dragonas da Segunda Guerra
210781	Braceletes da Fênix
210794	Peitoral de Prata Cambiante
210795	Botas de Sedaracna Extraplanares
210811	Runa da Fúria Primordial
210817	Runa da Sobrevivência
210818	Runa do Lobo Solitário
210820	Runa do Sacrifício
210822	Epifania Harmoniosa
210823	Runa de Especialização em Duas Armas
210824	Runa do Pacto
210825	Runa do Armipotente
210953	Olho de Bhossca
210955	Uniforme de Iniciado Escarlate
210963	Chave dos Áugures
210966	Sangue da Legião
210967	Mensagem Confidencial
210968	Chave do Relicário
210979	Runa do Passo Furtivo
210980	Runa da Metamorfose
211205	Runa do Exterminador de Najas
211247	Molde: Braceletes da Fênix
211263	Couraça do Julgamento
211269	Desenho Primitivo
211301	Runa de Expor Fraqueza
211315	Suprimentos Escondidos: Couro Leve
211316	Suprimentos Escondidos: Botão-da-paz
211317	Suprimentos Escondidos: Folha-prata
211318	Suprimentos Escondidos: Poções Menores de Cura
211319	Suprimentos Escondidos: Espadas Curtas de Cobre
211320	Suprimentos Escondidos: Calças Rúnicas de Cobre
211321	Suprimentos Escondidos: Varinhas Mágicas Inferiores
211322	Suprimentos Escondidos: Óleo Menor de Teurgo
211323	Suprimentos Escondidos: Bombas Grosseiras de Cobre
211324	Suprimentos Escondidos: Canos de Atirar Rudimentares
211325	Suprimentos Escondidos: Cinto de Couro Feito à Mão
211326	Suprimentos Escondidos: Colete de Couro com Relevo
211327	Suprimentos Escondidos: Calças de Linho Marrom
211328	Suprimentos Escondidos: Veste de Linho Marrom
211329	Suprimentos Escondidos: Ovo Assado com Ervas
211330	Suprimentos Escondidos: Carne Temperada de Lobo
211331	Suprimentos Escondidos: Peixinho Brilhante
211332	Suprimentos Escondidos: Bandagem de Linho Grossa
211365	Remessa de Suprimentos
211367	Remessa de Suprimentos
211368	Remessa de Suprimentos
211382	Algibeira de Mensageiro Pequena
211384	Bolsa de Mensageiro Resistente
211385	Runa de Espalhar de Serpente
211386	Anotações de Feitiços: Surto Arcano
211387	Runa de Luz Estupenda
211390	Runa de Provocação
211391	Runa de Chuva Curativa
211392	Runa de Agonia Eterna
211393	Runa de Fúria Obcecada
211419	Punhado de Escamas Cambiantes
211420	Talismã de Escama Cambiante
211421	A Caixa
211422	Estilhaço do Caos
211423	Luvas de Couro Tocadas pelo Caos
211427	Receptáculo de Alma
211443	Lâmina da Raiva
211444	Manto do Evocador
211445	Arco Recurvo Bárbaro
211447	Carregamento de Armas
211448	Contrato de Aquisição Assinado
211449	Pérola do Caos do Vingador
211450	Pérola do Caos do Invocador
211451	Pérola do Caos do Acólito
211452	Pérola das Profundezas Negras Perfeita
211454	Globo d'Água Estranho
211455	Luvas sem Dedos Elegantes
211456	Adaga do Sacrifício Voluntário
211457	Cinturão do Defensor do Crepúsculo
211458	Tomo de Proteção contra Sombra
211460	Broquel Ártico Ancestral
211461	Cetro da Lápide Inscrita
211462	Anel do Encorajamento Contínuo
211463	Broches de Besouro Tremelicantes
211464	Capa da Prelação Usada
211465	Botas Nímbus da Percepção
211466	Cinturão de Alburno do Conservador
211467	Aro do Punho de Ferro
211468	Dragonas Castanhas Puídas
211471	Chave Fontescarpa
211472	Incunábulo do Banimento
211476	Rastro das Runas do Fogo
211477	Runa de Incinerar
211482	Oferenda da Lança Partida
211487	Explosivos de Demolição
211488	Runa do Vingador
211490	Profecia de Milhares de Luzes
211491	Bolsa de Pele de Murloc sem Fundo
211492	Algibeira de Kelris
211498	Sabre-da-noite Sentinela do Aprendiz
211499	Lobo Pioneiro do Aprendiz
211500	Faixa de Tecido Resiliente
211501	Couraça do Poder
211502	Manoplas de Couro Tocadas pelo Caos
211504	Corrente do Vingador do Crepúsculo
211505	Elmo do Vingador do Crepúsculo
211506	Botas do Vingador do Crepúsculo
211507	Capucho do Elementalista do Crepúsculo
211508	Pisantes do Elementalista do Crepúsculo
211509	Veste do Elementalista do Crepúsculo
211510	Capucho do Matador do Crepúsculo
211511	Pisantes do Matador do Crepúsculo
211512	Túnica do Matador do Crepúsculo
211514	Anotações de feitiços: Regeneração em Massa
211527	Saco de Dormir Aconchegante
211528	Percepção Sombria
211530	Profecia de uma Cidade Escravizada
211531	Profecia dos Sete Visitantes
211534	Percepção Primeva
211691	Anotações de Feitiços: Impacto Arcano
211777	Manuscrito Naga
211779	Patuá da Compreensão
211780	Pergaminho: KWYJIBO
211784	Pergaminho: ADUBIDIBE
211785	Pergaminho: CWAL
211786	Pergaminho: CARA LUTA WELLES
211787	Pergaminho: PING MAIS BAIXO ALGUÉM
211789	Capucho de Artemis
211799	Saco de Mercadorias Roubadas
211800	Pergaminho da Reintegração
211809	Cartilha Introdutória
211813	Patuá de Sentinela da Asa de Prata
211814	Marca do Pioneiro do Brado Guerreiro
211815	Hino de Batalha da Asa de Prata
211816	Tambor de Batalha do Brado Guerreiro
211818	Globo d'Água Estranho
211819	Suprimentos Escondidos: Barras de Bronze
211820	Suprimentos Escondidos: Barras de Prata
211821	Suprimentos Escondidos: Couro Médio
211822	Suprimentos Escondidos: Ervamossa
211823	Suprimentos Escondidos: Cardo-veloz
211824	Suprimentos Escondidos: Poções Inferiores de Mana
211825	Suprimentos Escondidos: Botas Rústicas de Bronze
211826	Suprimentos Escondidos: Chaves-mestras de Prata
211827	Suprimentos Escondidos: Bastões Rúnicos de Prata
211828	Suprimentos Escondidos: Óleo Menor de Mana
211829	Suprimentos Escondidos: Bombas Pequenas de Bronze
211830	Suprimentos Escondidos: Luneta Ornada
211831	Suprimentos Escondidos: Manto de Couro Escuro
211832	Suprimentos Escondidos: Omoplatas do Montanhista
211833	Suprimentos Escondidos: Camisa de Lã Cinza
211834	Suprimentos Escondidos: Manto com Fecho de Pérola
211835	Suprimentos Escondidos: Sabichão Defumado
211836	Suprimentos Escondidos: Carne de Urso Defumada
211837	Suprimentos Escondidos: Marisco à la Goblin
211838	Suprimentos Escondidos: Bandagens Grossas de Lã
211839	Remessa de Suprimentos
211840	Remessa de Suprimentos
211841	Remessa de Suprimentos
211842	Casquete do Pensamento de Rakkamar
211843	Máscara do Escárnio
211845	Pedra de Afiar das Profundezas Negras
211846	Instruções: Pedra de Afiar das Profundezas Negras
211848	Óleo de Mana das Profundezas Negras
211849	Fórmula: Óleo de Mana das Profundezas Negras
211852	Mitenes da Água Poluída
211853	Pergaminho: POÇO VOCE
211854	Pergaminho: OMITIR KESA
211855	Pergaminho: LUAR VIGOROSO
211856	Coifa de Malha Resiliente
211857	Máscara de Couro Resiliente
211933	Suprimentos Escondidos: Pedra Rústica
211934	Suprimentos Escondidos: Poções de Cura
211935	Suprimentos Escondidos: Elixir de Poder de Fogo
211940	Guardião Tribal de Ecks'av
211941	Yari do Andavento
211944	Karma de Tojara
211953	Pergaminho da Recuperação Arcana I
211954	Pergaminho da Precisão Arcana I
211955	Pergaminho da Proteção contra o Arcano - Fogo I
211956	Pergaminho da Proteção contra o Arcano - Gelo I
211957	Pergaminho de Poder Arcano
212160	Deslocador Dádiva do Tempo
212225	Receptáculo de Alma Eterno
212230	Diagrama: Receptáculo de Alma
212548	Runa do Eclipse
212549	Runa do Coureador
212551	Runa da Guerra
212552	Epifania Psicosófica
212559	Runa de Lâmina Envenenada
212560	Runa do Despertar Ancestral
212561	Runa da Escuridão Sombria
212562	Runa de Raiva Curativa
212568	Troféu de Cabeça de Lobo
212580	Cajado do Erudito
212581	Arco do Vanguardeiro
212582	Espada do Protetor
212583	Lâmina da Sentinela
212584	Cajado Nodoso do Conselheiro
212585	Arco do Pioneiro
212586	Espada do Legionário
212587	Lâmina do Batedor
212588	Luvas do Fornecedor
212589	Botinas do Mensageiro
212590	Correia de Içamento
212748	Bilhete Desgastado
212994	Braceletes do Caça-temporal
212996	Braceletes do Traztrovão
212997	Braceletes do Chamaré
213074	Runa da Nutrição
213086	Runa da Tempestade
213087	Manto do Sargento
213088	Manto do Sargento
213090	Runa da Sinergia
213093	Runa de Poder
213094	Runa da Nova de Fogo
213096	Runa do Chamariz
213098	Runa da Invocação
213100	Runa do Conhecimento Proibido
213101	Runa das Chamas Sombrias
213102	Runa da Perversidade
213103	Runa da Rebentação de Sangue
213104	Runa da Precisão Implacável
213105	Xauarmagedom
213109	Runa da Raiva Concentrada
213110	Runa do Comandante
213111	Runa da Intervenção
213112	Anotações de Feitiços: Salva de Mísseis
213117	Runa de Berserk
213118	Runa do Rei da Selva
213119	Runa do Instinto
213120	Runa do Sonhador
213121	Azevinho Seco
213122	Runa do Tiro Firme
213123	Runa da Exposição
213124	Runa do Combate Corpo a Corpo
213125	Runa do Envigoramento
213126	Runa do Desmanchador
213127	Anotações de Feitiços: TCOESGIE LAOMDEÁG
213128	Runa da Piedade
213129	Runa do Abraço da Luz
213130	Runa das Infusões
213131	Runa dos Escudos Sagrados
213132	Runa do Guardião
213136	Runa do Subterfúgio
213137	Runa do Agressor
213138	Runa do Canhoto
213139	Runa do Assassino
213140	Profecia do Caminho Vivificado
213141	Runa da Esperança
213142	Profecia da Malícia Aprisionada
213143	Epifania Apócrifa
213144	Epifania Luminosa
213165	Basiliscos: Quem Tem Medo de Virar Pedra?
213168	Moeda de Cobre Sangrenta
213169	Moeda de Prata Sangrenta
213170	Moeda de Ouro Sangrenta
213278	Protetores de Mão do Maestro da Paulada
213279	Morrião Refletor
213280	Visor de Mira do Atirador Perito
213281	Reativador do Hiperfluxo Eletromagnético
213282	Máquina de Inovação Hipercarregada
213283	Máquina de Conflagração Hipercarregada
213284	Máquina de Devastação Hipercarregada
213285	Braceletes Manchados de Óleo de Lev
213286	Agulha do Eletrocutor
213287	Porca do Eletrocutor
213288	Manoplas Grudentas de Grúdio
213289	Hidrobáculo
213290	Galochas Ácidas
213291	Vingador Tóxico II
213292	Gigafaca Trecotrônica
213293	Superarma de Alta Tecnologia v7
213294	Escarpes de Furnafunda
213295	Vibrolâmina Ultrassônica
213296	Corta-cabeças Supercarregado
213297	Martelo Explosivo Oscilante
213298	Macacão do Criador de Robôs
213299	Calças Molhadas com Gasolina
213300	Luvas do Mestre do Combate
213301	Dragonas Sintéticas
213302	Dragonas do Negociador Astuto
213303	Espaldares Para-Raios
213304	Brafoneiras do Matador de Troggs
213305	Placa d'Ombros de Liga Usinada
213306	Murça da Inventividade
213307	Clâmide do Desmantelamento
213308	Protótipo de Manto Paraquedas
213309	Manto da Invenção
213310	Claramisa Hipercondutora
213311	Veste Hipercondutora
213312	Avental com Isolamento Térmico
213313	Couraça com Isolamento Térmico
213314	Malha de Anéis Eletromântica
213315	Camisa Encadeada Eletromântica
213316	Peitoral P.E.R.I.G.O.
213317	Estabilizadores de Mira Experimentais
213318	Bracelete Ornado de Ferro Negro
213319	Luvas do Maquinista
213320	Dedos da Precisão Arcana
213321	Cinto com Preparado Volátil
213322	Cintel da Crocodilagem
213323	Cordão da Terra Profunda
213324	Cinto de Corda Eletromagnético
213325	Cinturão da Visão no Escuro
213326	Cinturão da Reclamação
213327	Cinto do Berserker Trogg
213328	Pantalonas Hipercondutoras
213329	Saiote Hipercondutor
213330	Coxotes P.E.R.I.G.O.
213331	Perneiras com Isolamento Térmico
213332	Guarda-pernas com Isolamento Térmico
213333	Chausses Eletromânticos
213334	Perponte Eletromântico
213335	Botas P.E.R.I.G.O.
213336	Chancas Hipercondutoras
213337	Sandálias Hipercondutoras
213338	Botas de Aterramento Eletromânticas
213339	Escarpes de Aterramento Eletromânticos
213340	Botas de Operador de Gnomobô
213341	Botinas de Segurança com Isolamento Térmico
213342	Galochas com Isolamento Térmico
213343	Distintivo da Justiça
213344	Torque de Agente da Paz de Gnomeregan
213345	Pingente de Pistão
213346	Pingente do Regresso
213347	Câmara de Combustão Miniaturizada
213348	Experimento Giromático 420b
213349	Frasco de Pílulas de Gniodina
213350	Núcleo Endurecido de Wirdal
213351	Escudo-torreão Irradiado
213352	Graça do Remendogenheiro
213353	Cajado Desfribilador
213354	Cajado do Gênio do Mal
213355	Ferroada de Falco
213356	Canhão Personalizado de Termaplugue
213369	Couro Levemente Luminoso
213370	Pedaços Irradiados de Couro
213371	Caixote de Solução de Gniodina Maculada
213372	Gniodina com Isolamento Térmico
213373	Sucata Reflexiva
213376	Placas de Veraprata de Baixa Radioatividade
213378	Microfilamento Instável
213379	Arcanofilamento Hipercondutor
213381	Pilha de Engrenagens Manchadas
213383	Engrenagens de Veraprata Polidas
213390	Engrenomuralha de Veraprata Rodopiante
213391	Manoplas de Mithril Eletrificadas
213407	Erva-de-gato
213408	Macro-ajustador Giromático
213409	Retalhador Arcano do Mekkatorque
213410	Trecolâmina Reluzente
213411	Ignição Inextinguível de Izelflix
213412	Escudo de Segurança Dielétrico
213413	Ombreiras Generosamente Acolchoadas
213414	Faixa do Meca-reparador
213415	Braçadeiras do Faz-tudo
213416	Cutelo-foguete de Termaplugue
213417	Coifa de Filamentos de Veraprata
213418	Aneletes de Veraprata Soldados
213419	Manual de Reparo do 9-60
213421	Bilhete Chamuscado
213426	Para-raios Ôgrico
213427	Sucata Encardida
213442	Garra do Engrenomestre
213443	Presente Tiquetaqueante
213452	Runa Sagrada Dormente
213513	Incunábulo da Libertação
213526	Pernil Híbrido
213527	Mistura de Temperos do Contrabandista
213528	Cerveja Balsâmica
213529	Veneno Viscoso
213542	Necro-gnomicon
213543	Pergaminho: FALAÊ
213544	Pergaminho: DASTEFO RIÃTORLIM
213545	Pergaminho: TOSIM DOPOTAG
213546	Pergaminho: LALARAIÁ
213547	Pergaminho: DASPE AQUE
213548	Pergaminho de Passagem Liminar
213549	Pergaminho de Pesca Arcana
213550	Pergaminho de Polimorfia: Melão Estranho
213551	Pergaminho do Deslocamento Controlado
213552	Lágrima de Theradras
213553	Lágrima de Theradras
213554	Ampola de Água Cristalina
213558	Bálsamo Elemental
213559	Câmbio de Mecanostruz
213560	Silenciador de Mecanostruz
213563	Guia de Campo
213564	Pergaminho da Evocação Menor
213565	Kit Básico de Entomologia
213583	Entalhe com Enxofre
213594	Ídolo da Interpelação
213599	Visão Perturbadora
213632	Anotações de Feitiços Parciais
213633	Anotações de Feitiços Parciais
213634	Anotações de Feitiços Parciais
213641	Caixa de Sucata de Gnomeregan
213701	Pena Resistente de Harpia
213709	Presa de Serpente das Nuvens
213735	Processador N.U.C.L.E.O. G-7 Imaculado
213736	Processador N.U.C.L.E.O. G-7 Corroído
213737	Oferenda ao Espírito do Vento
214435	Chave de Jaula de Puma
215111	Monóculo Gneuroarticulado de Arcanofilamento
215114	Coifa de Escama Hipercondutora Luminescente
215115	Faixa de Ouro Hipercondutora
215129	Fórmula: Encantamento de Desmanche - Arma
215138	Fórmula: Encantamento de Re-talhação - Torso
215141	Signo Encantado: Inovação
215149	Molde: Monóculo Gneuroarticulado de Arcanofilamento
215152	Molde: Capucho Gneuroarticulado Luminescente
215153	Diagrama: Engrenomuralha de Veraprata Rodopiante
215155	Instruções: Elmo Temperado com Cancelamento de Interferências
215156	Diagrama: Faixa de Ouro Hipercondutora
215162	Poção de Rejuvenescimento Ligeiramente Irradiada
215163	Receita: Poção de Rejuvenescimento Ligeiramente Irradiada
215166	Capucho Gneuroarticulado Luminescente
215257	Pergaminho da Compreensão
215365	Dragonas do Invocador
215366	Cordão do Invocador
215367	Molde: Couro Levemente Luminescente
215368	Molde: Arcanofilamento Hipercondutor
215369	Molde: Cordão do Invocador
215370	Molde: Dragonas do Invocador
215371	Patuá de Jani
215373	Martelo de Treinamento do Punho de Prata
215374	Espada Ancestral
215375	Cajado Tático
215376	Maça do Cruzado
215377	Veste Irradiada
215378	Botas Irradiadas
215379	Calçotes Irradiados
215380	Cinto para Levantamento de Peso Assistido
215381	Capuz Gneurocondutor do Canalizador
215382	Capuz de Escamas com Resistência à Radiação
215383	Instruções: Guarda-cérebro de Veraprata Refletor
215384	Instruções: Placas de Veraprata de Baixa Radioatividade
215385	Suprimentos Escondidos: Barras de Ouro
215386	Suprimentos Escondidos: Barras de Mithril
215387	Suprimentos Escondidos: Pelego Pesado
215388	Suprimentos Escondidos: Couros Grossos
215389	Suprimentos Escondidos: Some-folha
215390	Suprimentos Escondidos: Bigode-de-hadggar
215391	Suprimentos Escondidos: Boquinha-do-inverno
215392	Suprimentos Escondidos: Lótus Roxo
215393	Suprimentos Escondidos: Poções Maiores de Cura
215394	Suprimentos Escondidos: Poções Inferiores de Escudopétreo
215395	Suprimentos Escondidos: Elixires de Agilidade
215396	Suprimentos Escondidos: Elixires de Defesa Maior
215397	Suprimentos Escondidos: Machados Sólidos de Ferro
215398	Suprimentos Escondidos: Braçadeiras Verdes de Ferro
215399	Suprimentos Escondidos: Manoplas Pesadas de Mithril
215400	Suprimentos Escondidos: Pedras de Amolar Maciças
215401	Suprimentos Escondidos: Kits de Ceifa-colheitas Compactos
215402	Suprimentos Escondidos: Bombas Grandes de Ferro
215403	Suprimentos Escondidos: Miras Letais
215404	Suprimentos Escondidos: Bacamarte de Mithril
215405	Suprimentos Escondidos: Botas-foguete Gnômicas
215406	Suprimentos Escondidos: Morteiros Goblínicos
215407	Suprimentos Escondidos: Omoplatas Barbarescas
215408	Suprimentos Escondidos: Luvas do Guardião
215409	Suprimentos Escondidos: Braçadeiras de Escama de Tartaruga
215410	Suprimentos Escondidos: Cintos Crepusculares
215411	Suprimentos Escondidos: Mantos de Couro Gélido
215412	Suprimentos Escondidos: Luvas de Couro Sombrio
215413	Suprimentos Escondidos: Camisas Brancas Formais
215414	Suprimentos Escondidos: Pantalonas de Seda Carmesim
215415	Suprimentos Escondidos: Camisas Luxuosas de Seda Roxa
215416	Suprimentos Escondidos: Máscaras Brancas do Bandido
215417	Suprimentos Escondidos: Caldo Reconfortante de Tartaruga
215418	Suprimentos Escondidos: Linguiças de Aranha
215419	Suprimentos Escondidos: Bandagens Grossas de Seda
215420	Suprimentos Escondidos: Bacalhau Escama-de-pedra
215421	Suprimentos Escondidos: Óleo Ígneo
215422	Molde: Coifa de Escama Hipercondutora Luminescente
215423	Molde: Capuz Gneurocondutor do Canalizador
215424	Molde: Capuz de Escamas com Resistência à Radiação
215425	Eco do Pântano
215426	Eco do Cemitério
215427	Eco de Arathi
215428	Eco de Theramore
215429	Diagrama: Engrenagens de Veraprata Polidas
215430	Precipitação de Gnomeregan
215431	Diagrama: Bomba Radioativa de Alta Potência
215432	Diagrama: Bomba Radioativa Taca-fácil
215433	Receita: Gniodina com Isolamento Térmico
215434	NÃO USADO
215435	Incunábulo da Bênção
215436	Totem da Chama Revigorante
215437	Transfigurador-trogg 3000
215441	Martelo Quebrado
215443	Fragmento de Orbe Estilhaçado
215444	Monstro - Maça - Canos Quebrados
215449	Encolhedor de Mundo
215450	Projeto de Tabardo (Aidan)
215456	Mensagem Chamuscada
215458	Mensagem Inclusa
215459	Mensagem Inclusa
215460	Mensagem Inclusa
215461	Galinha de Ataque Domesticada
215468	Ordens do Grande Cruzado
215683	Geomancia: A Verdade Nua e Crua
215815	Magia Defensiva Básica
215816	Uma Rede de Mentiras: Desmascarando Mitos e Lendas
215817	Demônios e Você
215820	Múmias: Um Guia para os Desagradáveis Mortos-vivos
215822	RwlRwlRwlRwl!
215824	Um Guia Ludita para Cuidar da sua Mascote Demoníaca
216484	Botas de Batalha Eletroforjadas
216485	Peitoral Eletroforjado
216486	Coxotes Eletroforjados
216490	Ídolo da Ira
216491	Carregamento de Madeira da Selva do Espinhaço
216492	Apito do Raptor Sanguíneo Mosqueado
216494	Distorcedor de Mundo Extravagante de Aragriar
216495	Esmagador Sanguíneo
216496	Quebra-crânios Sanguíneo
216497	Dessangre
216498	Grimório Sanguíneo Encantado
216499	Esmagador de Casca Sanguínea
216500	Talismã do Bosque com Elos de Sangue
216501	Barreira da Tempestade de Sangue
216502	Totem Bélico da Tempestade de Sangue
216503	Joia da Tempestade de Sangue
216504	Sabre da Luz Sangrenta Eclipsada
216505	Resplendor do Cruzado da Luz Sangrenta
216506	Lâmina do Vingador da Luz Sangrenta
216507	Selo de Sangue do Umbral
216508	Elo da Serpentina Sanguínea Infernal
216509	Essência do Pacto Infernal
216510	Círculo da Ressonância do Sangue
216511	Selo do Sangue
216512	Aro das Veias Geladas
216513	Talismã Sangue de Tigre
216514	Aljava Sanguínea
216515	Bornal de Munição Sanguínea
216516	Arco Sangraçoite
216517	Santuário Sanguíneo
216518	Selo do Pacto de Sangue
216519	Elo da Sombra Sanguínea
216520	Lâmina Ceifa-sangue
216521	Golpeadores Sanguíneos Velozes
216522	Estilete Respingado de Sangue
216523	Chave da Jaula Enferrujada
216570	Rédeas do Gato-de-sabre Dourado
216606	Runa de Maestria em Duas Mãos
216607	Oferenda de Luz Sangrenta
216608	Refletores de Raios Radiantes
216610	Ordens do Grande Cruzado
216615	Sinalizador da Tempestade de Sangue Ancestral
216616	Chave da Jaula Composta
216617	Uniforme do Combatente de Kurzen
216618	Recompensa da Capitã Aransas
216619	Ração de Estudante
216620	Manto Sanguipútrido
216621	Clâmide Banhada em Sangue
216622	Manto Coagulado
216623	Capa de Homeostase
216633	Escora de Veraprata Hidráulica
216634	Fusível de Cartucho GG12-082
216635	Núcleo de Caos Gasto
216636	Núcleo de Caos Carregado
216637	Pilha de Peças Aleatórias
216645	Partícula de Escuridão
216646	Caixote Misterioso de Ziri
216661	Anel Encardido
216662	Anel de Ouro Brilhante
216673	Anel de Ouro Brilhante de Didiê
216674	Anel de Ouro Brilhante de Nogg
216675	Vestes de Civínada Impecáveis
216676	Culotes Corretrecho Ágeis
216678	Perneiras Triplamente Reforçadas
216679	Ferramenta de Desmanche da Shoni
216680	Meias-Luvas Bechil
216698	Braçadeiras de Couro de Dragão do Sargento-mor
216699	Guarda-braços Encadeados do Sargento-mor
216700	Braçadeiras de Couro do Sargento-mor
216701	Munhequeiras de Placa do Sargento-mor
216702	Manilhas de Seda do Sargento-mor
216703	Munhequeiras de Malha do Primeiro-sargento
216704	Guarda-braços de Couro de Dragão do Primeiro-sargento
216705	Braçadeiras de Placa do Primeiro-sargento
216706	Guarda-braços de Couro do Primeiro-sargento
216707	Manilhas de Seda do Primeiro-sargento
216738	Manual de Redirecionamento
216740	Tomo do Intelecto Expandido
216744	Pergaminho da Fortitude Aumentada
216745	Pergaminho do Demônio das Sombras
216746	Manual do Brado de Comando
216747	Grimório da Colheita de Almas
216748	Grimório de Portal de Evocação
216764	Folheto de Indomabilidade Profunda
216767	Folheto de Reviver
216769	Revelação de Projeção Totêmica
216770	Tratado do Aspecto da Víbora
216771	Folheto de Restauração Aprimorada
216879	Pergaminho Trólico Misterioso
216880	Pergaminho Trólico Decifrado
216884	Lâmina Sanguissedenta
216914	Comenda Maculada
216918	Botas Vilcórdias
216919	Faixa Vilcórdia
216920	Braceletes Vilcórdios
216921	Guantes Vilcórdias
216922	Coroa Vilcórdia
216923	Perneiras Vilcórdias
216924	Abraço Vilcórdio
216925	Dragonas Vilcórdias
216938	Insígnia da Aliança Maior
216939	Insígnia da Horda Maior
216941	Signo de Ariden
216945	Relíquia de Dalaran Curiosa
216946	Relíquia de Dalaran Brilhante
216947	Relíquia de Dalaran Zunidora
216948	Relíquia de Dalaran Estranha
216949	Relíquia de Dalaran Pesada
216950	Relíquia de Dalaran Medonha
216951	Relíquia de Dalaran Escorregadia
216956	Carta Rasgada
216971	Algibeira de Moedas de Cobre Sangrentas
216972	Algibeira de Moedas de Prata Sangrentas
217005	Capa do Mecânico
217006	Martelo do Mecânico
217007	Botas Sem Bateria
217008	Peitoral Sem Bateria
217009	Perneiras Sem Bateria
217014	Sacola de Suprimentos
217017	Torneio de Pesca!
217161	Anotações de Feitiços: ETAF ED GOROIFROF
217244	Molde: Veste de Seda Carmesim
217245	Veste de Seda Carmesim
217246	Colete de Magitrama Preta
217247	Perneiras de Magitrama Preta
217248	Cinto de Seda Terrano
217249	Molde: Cinto de Seda Terrano
217250	Omoplatas de Seda Carmesim
217251	Molde: Omoplatas de Seda Carmesim
217252	Manto Longo Sedoso
217253	Botas do Encantador
217254	Molde: Botas do Encantador
217255	Cinto de Seda Carmesim
217256	Colete Terrano
217257	Capucho do Encantador
217258	Molde: Capucho do Encantador
217259	Máscara do Grande Vodu
217260	Molde: Máscara do Grande Vodu
217261	Veste do Grande Vodu
217262	Molde: Veste do Grande Vodu
217263	Braçadeiras de Couro do Guardião
217264	Molde: Braçadeiras de Couro do Guardião
217265	Cinto do Guardião
217266	Molde: Cinto do Guardião
217267	Calças do Guardião
217268	Peitoral de Escama de Tartaruga
217270	Luvas de Escama de Tartaruga
217271	Molde: Luvas de Escama de Tartaruga
217273	Manoplas de Escama Dourada
217274	Instruções: Manoplas de Escama Dourada
217275	Botas de Escama Dourada
217276	Instruções: Botas de Escama Dourada
217277	Corselete de Escama Dourada
217278	Instruções: Corselete de Escama Dourada
217279	Coifa de Escama Dourada
217280	Instruções: Coifa de Escama Dourada
217281	Espada Larga de Lunaço
217282	Instruções: Espada Larga de Lunaço
217283	Omoplatas de Escama Dourada
217284	Instruções: Omoplatas de Escama Dourada
217285	Perneiras de Escama Dourada
217286	Instruções: Perneiras de Escama Dourada
217287	Varinha Mística Maior
217288	Vestes do Lich
217289	Armadura Criomortis
217290	Olho Faiscante de Mordresh
217291	Crânio Inerte de Mordresh
217292	Faixa do Mago da Morte
217293	Capa Seda-de-aranha
217294	Mortalha Embalsamada
217295	Varinha Necrótica
217296	Talismã do Fragmento Espectral
217297	Veste de Doan
217298	Dragonas de Doan
217299	Bastão do Ilusionista
217300	Chapéu do Cristalba
217301	Amuleto Triuno
217302	Poder de Mograine
217303	Perneiras Tecepedra
217304	Luvas do Revelosh
217305	Guarda-braços do Revelosh
217306	Botas do Revelosh
217307	Espaldares do Revelosh
217308	Signo Encantado: Inovação
217314	Rifle Miraluna
217315	Arco de Precisão
217336	Monstro - Íncubo Chicote Maça - 1M
217337	Remessa de Suprimentos
217338	Remessa de Suprimentos
217339	Remessa de Suprimentos
217345	Veneno Sebáceo
217346	Veneno Entorpecente
217347	Veneno Atrófico
217350	Anotações de Engenharia de Termaplugue
217351	Anotações de Engenharia de Termaplugue
217398	Elixir Arcano Inferior
217399	Receita: Elixir Arcano Inferior
217495	Pergaminho de Crioimpacto
217496	Pergaminho da Lâmina
217497	Espada de Narpas
217609	Talismã de Kazdor
217693	Poção de Invisibilidade
217704	Porrete com Ferros
217717	Emblema Vazio
217718	Emblema da Magia de Sangue
217719	Essência de Magia de Sangue
217720	Oferenda de Carne
217721	Oferenda de Ossos
217727	Proteção dos Mortos
217736	Runa da Confraria
217737	Talismã Modificado
219021	Bolsa-carteiro Parruda
219022	Anel do Carregador
219023	Anel do Vendedor
219024	Anel do Mensageiro
219135	Pingente Interessante
219136	Pingente da Tenacidade
219137	Pingente da Iniciativa
219147	Runa da Graça
219223	Fúria do Mestre de Espadas
219326	Semente de Renovação
219343	Capucho do Mão-leve
219345	Laço Infernal
219399	Musgo do Pesadelo
219401	Minério de Ferro Frio
219402	Escama de Dragão Tocada pelo Sonho
219404	Foice das Sombras
219405	Texto de Magus Ogro
219406	Ovo de Dragão Verde Não Chocado
219414	Cascas de Ovo Estilhaçadas
219444	Raiz-de-sonho
219445	Pó de Ouro de Tolo
219446	Escama de Dragão Infusa pelo Sonho
219447	Ovo de Dragão Tocado pelo Sonho
219448	Motonírico
219449	Profecia Azshariana
219454	Lótus-estelar
219486	Minério de Silvestela
219487	Casco-de-estrela
219488	Ovo de Dragão Tocado pelas Estrelas
219490	Relíquia Elunar
219491	Pérola Onírica
219514	Raiz-da-lua
219515	Pedra-da-lua Maior
219517	Escama de Dragão Lunar
219518	Escrito das Harpias
219519	Anotações do Guardião Louco
219520	Ovo de Dragão do Brilho da Lua
219526	Instruções de Missão: Floresta do Crepúsculo
219759	Relatório de Campo de Charla
219770	Relatório de Campo de Gemeron
219771	Relatório de Campo de Thandros
219772	Relatório de Campo de Fallia
219773	Instruções de Missão: Vale Gris
219774	Instruções de Missão: Terras Agrestes
219775	Instruções de Missão: Feralas
219776	Relatório de Inteligência: Gruta de Vul'Gol
219778	Relatório de Inteligência: o Horto Pútrido
219803	Relatório de Inteligência: Fazenda dos Figueira
219918	Missiva Sangrenta
219924	Relatório de Inteligência: Cantilenda
219925	Relatório de Inteligência: Satyrnaar
219926	Relatório de Inteligência: Acampamento de Lenhadores Brado Guerreiro
219927	Estilha de Esmeralda
219928	Relatório de Inteligência: Agol'watha
219929	Missiva Sangrenta
219930	Missiva Sangrenta
219935	Lâmina de Kajind
219937	Relatório de Inteligência: Shaol'watha
219938	Relatório de Inteligência: Rocha Oculta
219957	Relatório de Inteligência: Oneiros
219958	Relatório de Inteligência: Colossos Gêmeos
219959	Relatório de Inteligência: Ruínas dos Ventos Corvejantes
219962	Incursões Pesadelares: Missão da Floresta do Crepúsculo I
219963	Autorização de Delegação: Missão da Floresta do Crepúsculo I
219965	Autorização de Delegação: Missão da Floresta do Crepúsculo II
219966	Incursões Pesadelares: Missão da Floresta do Crepúsculo II
219967	Incursões Pesadelares: Missão da Floresta do Crepúsculo III
219968	Incursões Pesadelares: Missão da Floresta do Crepúsculo IV
219969	Incursões Pesadelares: Missão da Floresta do Crepúsculo V
219970	Incursões Pesadelares: Missão da Floresta do Crepúsculo VI
219971	Incursões Pesadelares: Missão da Floresta do Crepúsculo VII
219972	Incursões Pesadelares: Missão da Floresta do Crepúsculo VIII
219973	Incursões Pesadelares: Missão da Floresta do Crepúsculo IX
219974	Incursões Pesadelares: Missão da Floresta do Crepúsculo X
219975	Incursões Pesadelares: Missão da Floresta do Crepúsculo XI
219976	Incursões Pesadelares: Missão da Floresta do Crepúsculo XII
219977	Incursões Pesadelares: Missão da Floresta do Crepúsculo XIII
219978	Incursões Pesadelares: Missão da Floresta do Crepúsculo XIV
219979	Incursões Pesadelares: Missão da Floresta do Crepúsculo XV
219980	Incursões Pesadelares: Missão da Floresta do Crepúsculo XVI
219981	Incursões Pesadelares: Missão da Floresta do Crepúsculo XVII
219982	Incursões Pesadelares: Missão da Floresta do Crepúsculo XVIII
219983	Autorização de Delegação: Missão da Floresta do Crepúsculo III
219984	Autorização de Delegação: Missão da Floresta do Crepúsculo IV
219985	Autorização de Delegação: Missão da Floresta do Crepúsculo V
219986	Autorização de Delegação: Missão da Floresta do Crepúsculo VI
219987	Autorização de Delegação: Missão da Floresta do Crepúsculo VII
219988	Autorização de Delegação: Missão da Floresta do Crepúsculo VIII
219989	Autorização de Delegação: Missão da Floresta do Crepúsculo IX
219990	Autorização de Delegação: Missão da Floresta do Crepúsculo X
219991	Autorização de Delegação: Missão da Floresta do Crepúsculo XI
219992	Autorização de Delegação: Missão da Floresta do Crepúsculo XII
219993	Autorização de Delegação: Missão da Floresta do Crepúsculo XIII
219994	Autorização de Delegação: Missão da Floresta do Crepúsculo XIV
219995	Autorização de Delegação: Missão da Floresta do Crepúsculo XV
219996	Autorização de Delegação: Missão da Floresta do Crepúsculo XVI
219997	Autorização de Delegação: Missão da Floresta do Crepúsculo XVII
219998	Autorização de Delegação: Missão da Floresta do Crepúsculo XVIII
219999	Incursões Pesadelares: Missão do Vale Gris I
220000	Incursões Pesadelares: Missão do Vale Gris II
220001	Incursões Pesadelares: Missão do Vale Gris III
220002	Incursões Pesadelares: Missão do Vale Gris IV
220003	Incursões Pesadelares: Missão do Vale Gris V
220004	Incursões Pesadelares: Missão do Vale Gris VI
220005	Incursões Pesadelares: Missão do Vale Gris VII
220006	Incursões Pesadelares: Missão do Vale Gris VIII
220007	Incursões Pesadelares: Missão do Vale Gris IX
220008	Incursões Pesadelares: Missão do Vale Gris X
220009	Incursões Pesadelares: Missão do Vale Gris XI
220010	Incursões Pesadelares: Missão do Vale Gris XII
220011	Incursões Pesadelares: Missão do Vale Gris XIII
220012	Incursões Pesadelares: Missão do Vale Gris XIV
220013	Incursões Pesadelares: Missão do Vale Gris XV
220014	Incursões Pesadelares: Missão do Vale Gris XVI
220015	Incursões Pesadelares: Missão do Vale Gris XVII
220016	Incursões Pesadelares: Missão do Vale Gris XVIII
220017	Incursões Pesadelares: Missão das Terras Agrestes I
220018	Incursões Pesadelares: Missão das Terras Agrestes II
220019	Incursões Pesadelares: Missão das Terras Agrestes III
220020	Incursões Pesadelares: Missão das Terras Agrestes IV
220021	Incursões Pesadelares: Missão das Terras Agrestes V
220022	Incursões Pesadelares: Missão das Terras Agrestes VI
220023	Incursões Pesadelares: Missão das Terras Agrestes VII
220024	Incursões Pesadelares: Missão das Terras Agrestes VIII
220025	Incursões Pesadelares: Missão das Terras Agrestes IX
220026	Incursões Pesadelares: Missão das Terras Agrestes X
220027	Incursões Pesadelares: Missão das Terras Agrestes XI
220028	Incursões Pesadelares: Missão das Terras Agrestes XII
220029	Incursões Pesadelares: Missão das Terras Agrestes XIII
220030	Incursões Pesadelares: Missão das Terras Agrestes XIV
220031	Incursões Pesadelares: Missão das Terras Agrestes XV
220032	Incursões Pesadelares: Missão das Terras Agrestes XVI
220033	Incursões Pesadelares: Missão das Terras Agrestes XVII
220034	Incursões Pesadelares: Missão das Terras Agrestes XVIII
220035	Incursões Pesadelares: Missão de Feralas I
220036	Incursões Pesadelares: Missão de Feralas II
220037	Incursões Pesadelares: Missão de Feralas III
220038	Incursões Pesadelares: Missão de Feralas IV
220039	Incursões Pesadelares: Missão de Feralas V
220040	Incursões Pesadelares: Missão de Feralas VI
220041	Incursões Pesadelares: Missão de Feralas VII
220042	Incursões Pesadelares: Missão de Feralas VIII
220043	Incursões Pesadelares: Missão de Feralas IX
220044	Incursões Pesadelares: Missão de Feralas X
220045	Incursões Pesadelares: Missão de Feralas XI
220046	Incursões Pesadelares: Missão de Feralas XII
220047	Incursões Pesadelares: Missão de Feralas XIII
220048	Incursões Pesadelares: Missão de Feralas XIV
220049	Incursões Pesadelares: Missão de Feralas XV
220050	Incursões Pesadelares: Missão de Feralas XVI
220051	Incursões Pesadelares: Missão de Feralas XVII
220052	Incursões Pesadelares: Missão de Feralas XVIII
220053	Autorização de Delegação: Missão do Vale Gris I
220054	Autorização de Delegação: Missão do Vale Gris II
220055	Autorização de Delegação: Missão do Vale Gris III
220056	Autorização de Delegação: Missão do Vale Gris IV
220057	Autorização de Delegação: Missão do Vale Gris V
220058	Autorização de Delegação: Missão do Vale Gris VI
220059	Autorização de Delegação: Missão do Vale Gris VII
220060	Autorização de Delegação: Missão do Vale Gris VIII
220061	Autorização de Delegação: Missão do Vale Gris IX
220062	Autorização de Delegação: Missão do Vale Gris X
220063	Autorização de Delegação: Missão do Vale Gris XI
220064	Autorização de Delegação: Missão do Vale Gris XII
220065	Autorização de Delegação: Missão do Vale Gris XIII
220066	Autorização de Delegação: Missão do Vale Gris XIV
220067	Autorização de Delegação: Missão do Vale Gris XV
220068	Autorização de Delegação: Missão do Vale Gris XVI
220069	Autorização de Delegação: Missão do Vale Gris XVII
220070	Autorização de Delegação: Missão do Vale Gris XVIII
220071	Autorização de Delegação: Missão das Terras Agrestes I
220072	Autorização de Delegação: Missão das Terras Agrestes II
220073	Autorização de Delegação: Missão das Terras Agrestes III
220074	Autorização de Delegação: Missão das Terras Agrestes IV
220075	Autorização de Delegação: Missão das Terras Agrestes V
220076	Autorização de Delegação: Missão das Terras Agrestes VI
220077	Autorização de Delegação: Missão das Terras Agrestes VII
220078	Autorização de Delegação: Missão das Terras Agrestes VIII
220079	Autorização de Delegação: Missão das Terras Agrestes IX
220080	Autorização de Delegação: Missão das Terras Agrestes X
220081	Autorização de Delegação: Missão das Terras Agrestes XI
220082	Autorização de Delegação: Missão das Terras Agrestes XII
220083	Autorização de Delegação: Missão das Terras Agrestes XIII
220084	Autorização de Delegação: Missão das Terras Agrestes XIV
220085	Autorização de Delegação: Missão das Terras Agrestes XV
220086	Autorização de Delegação: Missão das Terras Agrestes XVI
220087	Autorização de Delegação: Missão das Terras Agrestes XVII
220088	Autorização de Delegação: Missão das Terras Agrestes XVIII
220089	Autorização de Delegação: Missão de Feralas I
220090	Autorização de Delegação: Missão de Feralas II
220091	Autorização de Delegação: Missão de Feralas III
220092	Autorização de Delegação: Missão de Feralas IV
220093	Autorização de Delegação: Missão de Feralas V
220094	Autorização de Delegação: Missão de Feralas VI
220095	Autorização de Delegação: Missão de Feralas VII
220096	Autorização de Delegação: Missão de Feralas VIII
220097	Autorização de Delegação: Missão de Feralas IX
220098	Autorização de Delegação: Missão de Feralas X
220099	Autorização de Delegação: Missão de Feralas XI
220100	Autorização de Delegação: Missão de Feralas XII
220101	Autorização de Delegação: Missão de Feralas XIII
220102	Autorização de Delegação: Missão de Feralas XIV
220103	Autorização de Delegação: Missão de Feralas XV
220104	Autorização de Delegação: Missão de Feralas XVI
220105	Autorização de Delegação: Missão de Feralas XVII
220106	Autorização de Delegação: Missão de Feralas XVIII
220164	Runa do Gladiador
220165	Runa da Ira
220166	Núcleo Infernal Ardente
220167	Pó de Túmulo Cintilante
220168	Cerveja Candente com Tripla Fermentação
220169	Símbolo de Fé
220173	Parassonia
220213	Sangue Vital Vil
220214	Elo de Corrente Infernal
220216	Laço Infernal
220217	Runa do Voraz
220345	Feitiçaria Sanguínea
220346	Lendas dos Sábios das Marés
220347	O Liminar e o Arcano
220348	Etiqueta Cotidiana
220349	Desenho Forjado em Pedra
220350	Jornadas Venenosas
220351	Sapta do Ar Turva
220352	A Mente Metálica
220353	Códice do Conjurador
220360	Runa de Eflorescência
220375	Fragmento de Ar
220379	Anotações de Xamã Rasgadas
220446	Tesouro Sobrenatural
220510	Essência Elemental
220511	Grande Elmo do Pesadelo
220512	Capacete de Aço Dourado Imaculado
220514	Visor de Penas Verdejantes
220515	Capacete Esmeralda Encantado
220516	Visor Esquecido de Talho
220518	Chapéu Empoeirado de Ba'ham
220519	Cocar com Penas do Vodu
220521	Cocar do Ritualista Hakkari
220522	Coroa do Apanhador de Almas
220523	Capelina dos Exilados
220525	Fragmento de Ar Chamejante
220526	Processador N.U.C.L.E.O. G-7 Coberto de Lodo
220527	Dragonas do Berserker Atal'ai
220528	Omoplatas do Guarda-caça Atal'ai
220529	Espaldares do Fanatismo
220530	Vontade do Guerreiro Atal'ai
220531	Flor Roxa Ondulante
220532	Espaldares Atal'ai Reforçados
220533	Peitoral Atal'ai Reforjado
220534	Abraço da Serpente do Vento Eterno
220535	Vestimentas do Profeta Atal'ai
220536	Pulsos do Curandeiro Atal'ai
220537	Braçadeiras Aguanegra do Sonhador
220538	Braçadeiras Escamalodo Amaldiçoadas
220539	Bandos de Guerra do Sacrifício
220540	Protetores de Mão Cheios de Corrupção
220541	Punhos de Placa Cheios de Doença
220542	Manoplas d'Água Suja Poluídas
220543	Luvas de Malha em Escamas Esmeralda
220544	Garras de Linfalume
220545	Luvas do Lutador Fétido
220546	Mãos do Atormentado
220547	Luvas do Profeta Atal'ai Caído
220548	Luvas do Bagateiro Atal'ai
220549	Correia Albagulha
220550	Cintel do Saqueador do Templo
220551	Faixa do Sonho Esmeralda do Devoto
220552	Cinta de Dor
220553	Cinto do Adorador Renegado
220554	Elo de Presas de Atal'alarion
220555	Cinturão de Escama de Serpente Atal'ai
220556	Kilt do Profeta Atal'ai Caído
220557	Sarongue Escaméolo Amaldiçoado
220558	Perneiras do Assassino Atal'ai
220559	Perneiras de Escama de Dragão Revitalizadas
220560	Coxotes Conchaprata
220561	Pisantes Troll Tenazes
220562	Grevas de Batalha Injetadas de Sangue
220563	Botas do Xamã de Sangue Atal'ai
220564	Botas Coleantes Restauradas
220565	Botas do Andanévoa Etéreas
220566	Garra em Brasa
220567	Picante Ensanguentado
220568	Armachado do Explorador do Templo
220569	Martelo da Ira Virulento
220570	Manto dos Pesadelos
220571	Arco Longo Ferroante
220572	Repetidor Rápido de Rinzo
220573	Arco de Caça do Espreitador do Medo
220574	Dente de Erânicos Afiado
220575	Devorador dos Malditos
220576	Machado do Carrasco Atal'ai
220577	Poder do Loa Sangrento
220578	Punho dos Renegados
220579	Bastão de Mojo do Mandingueiro
220580	Loucura do Avatar
220581	Espancador de Cobra
220582	Pranto do Dragão
220583	Lâmina do Ignóbil Abjeto
220584	Lâmina do Sopro de Fogo
220585	Unha Má Degradada
220586	Húbris, a Marcadora de Bandidos
220587	Adaga do Sonho do Sacrifício
220588	Presa de Garra de Naja
220589	Golpeador de Serpente
220590	Pináculo da Adoração Hakkari
220591	Bastão Restaurador de Mirran
220594	Foice do Sonho
220595	Cajado Focal do Pesadelo
220596	Bastão Divinatório Antigo
220597	Pedra de Draco do Emissário do Sonho
220598	Pedra de Draco do Emissário do Pesadelo
220599	Pedra de Draco do Profeta de Sangue
220600	Brasão da Preeminência
220601	Guarda do Mandingueiro Hakkari
220602	Meio Casco da Tartaruga do Esgoto
220603	Bastão de Corrosão Irreversível
220604	Troféu do Pesadelo
220605	Incunábulo do Sacrilégio
220606	Ídolo do Sonho
220607	Totem da Ancestralidade Atormentada
220608	Clâmide de Pelepluma
220609	Clâmide do Ocaso
220610	Runa de Destreza Mental
220611	Capa de Bagata de Hukkah
220612	Runa de Mar Revolto
220613	Runa de Eco Ribombante
220614	Runa de Choque Estático
220615	Manto de Pele de Pantera
220616	Runa de Sobrecarga
220617	Runa de Pandemia
220618	Runa de Aura de Imolação
220619	Cerimônia do Sangue Atal'ai
220620	Crânio da Serpente Alada
220621	Cristal de Ressonância do Pesadelo
220622	Olho-do-dragão Perfeitamente Preservado
220623	Medalhão Perdido de Jin'do
220624	Patuá Valoroso Manchado de Sangue
220625	Resiliência dos Exilados
220626	Anel Garradraca do Berserker
220627	Anel Garradraca do Espreitador
220628	Anel Garradraca do Emissário
220629	Anel Garradraca do Profeta de Sangue
220630	Anel Garradraca do Jaganata
220632	Medalhão de Ritual de Sangue Atal'ai
220633	Distintivo de Ritual de Sangue Atal'ai
220634	Patuá de Ritual de Sangue Atal'ai
220635	Pedregulho Encantado de Atal'alarion
220636	Ícone de Sangue Atal'ai
220637	Ficha de Ritual Atal'ai
220638	Vareta de Bagata Heterodoxa
220639	Inanimador de Lledra
220642	Armadura de Placa do Mártir Banido
220643	Guarda-pernas de Placa do Mártir Banido
220648	Botas de Placa do Mártir Banido
220649	Herança de Merithra
220650	Guarda-peito do Profeta Obcecado
220651	Guarda-pernas do Profeta Obcecado
220652	Botas Ornamentadas do Profeta Obcecado
220653	Guarda-peito do Berserker Uivante
220654	Coxotes do Berserker Uivante
220656	Botas de Batalha do Berserker Uivante
220657	Cota do Berserker Ostracizado
220658	Coxotes do Berserker Ostracizado
220659	Grevas Encadeadas do Berserker Ostracizado
220660	Camisa Encadeada do Devoto Rejeitado
220661	Guarda-pernas do Devoto Rejeitado
220662	Botas de Escama do Devoto Rejeitado
220663	Perneiras do Tece-espíritos Corrompido
220664	Escarpes do Tece-espíritos Corrompido
220665	Peitoral do Tece-espíritos Corrompido
220666	Malha de Anéis do Caçador Terrível
220667	Chausses do Caçador Terrível
220668	Grevas do Caçador Terrível
220669	Gibão do Profeta Exilado
220670	Sapatilhas do Profeta Exilado
220671	Calça de Couro do Profeta Exilado
220672	Arnês do Adorador Perdido
220673	Perneiras do Adorador Perdido
220674	Lâmina Furtiva Aviltada
220675	Botinas do Adorador Perdido
220676	Túnica Corrompida por Sangue
220677	Botas Corrompidas por Sangue
220678	Calça Corrompida por Sangue
220679	Perneiras do Profeta Malevolente
220680	Colete do Profeta Malevolente
220681	Sandálias do Profeta Malevolente
220682	Runa dos Desenfreados
220683	Colete do Profeta Benevolente
220684	Perneiras do Profeta Benevolente
220685	Sandálias do Profeta Benevolente
220686	Ruína do Chefe Tribal
220687	Runa do Raptor
220688	Manto dos Pesadelos Inerte
220689	Avambraços Energizados pelo Caos
220738	Placa d'Ombros do Pavor
220739	Brafoneiras Perniciosas
220740	Guarda-ombros do Semeador do Medo
220741	Brafoneiras Encadeadas Guinchantes
220742	Espaldares Guinchantes
220743	Guarda-ombros Encadeados Cacofônico
220744	Manto da Corrente Uivante
220745	Membrana da Neurose Sombria
220747	Manto da Paranoia
220748	Ombreiras da Obsessão
220749	Dragonas da Insanidade
220750	Brafoneiras da Mente Fraturada
220751	Ombreiras do Demente
220754	Runa do Vendaval
220775	Cupom de Troca de Engenharia
220778	Calças do Guarda-de-sangue Coagulado
220779	Túnica do Guarda-de-sangue Coagulado
220780	Botas do Guarda-de-sangue Coagulado
220781	Perneiras do Profeta do Pesadelo
220783	Vestimenta do Profeta do Pesadelo
220784	Sandálias do Profeta do Pesadelo
220791	Runa do Gato da Selva
220792	Pergaminho da Recomposição Espacial
220794	Cota de Placa do Cavaleiro
220795	Brafoneiras de Placa do Tenente-cavaleiro
220796	Brafoneiras de Placa do Guarda-de-sangue
220797	Perneiras de Placa do Cavaleiro
220798	Perneiras de Placa do Guarda Pétreo
220799	Grevas de Placa do Sargento-mor
220800	Grevas de Placa do Primeiro-sargento
220801	Armadura de Placa do Guarda Pétreo
220803	Elmo de Placa do Guarda-de-sangue
220804	Elmo de Placa do Tenente-cavaleiro
220806	Manoplas de Placa do Primeiro-sargento
220807	Manoplas de Placa do Primeiro-sargento
220808	Brafoneiras Imbuídas do Tenente-cavaleiro
220809	Perneiras Imbuídas do Cavaleiro
220810	Capacete Imbuído do Tenente-cavaleiro
220811	Grevas Imbuídas do Primeiro-sargento
220812	Manoplas Imbuídas do Primeiro-sargento
220813	Armadura Imbuída do Cavaleiro
220814	Botas Lamelares do Primeiro-sargento
220815	Guarda-peito Lamelar do Cavaleiro
220816	Coxotes Lamelares do Cavaleiro
220817	Manoplas Lamelares do Primeiro-sargento
220818	Brafoneiras Lamelares do Tenente-cavaleiro
220819	Elmo Lamelar do Tenente-cavaleiro
220820	Capacete de Malha do Guarda-de-sangue
220821	Capacete Encadeado do Guarda-de-sangue
220822	Capacete Encadeado do Tenente-cavaleiro
220823	Palas de Malha do Guarda-de-sangue
220824	Palas Encadeadas do Guarda-de-sangue
220825	Palas Encadeadas do Tenente-cavaleiro
220826	Armaduras de Malha do Guarda Pétreo
220827	Armadura Encadeada do Guarda Pétreo
220828	Armadura Encadeada do Cavaleiro
220829	Manoplas Encadeadas do Sargento-mor
220830	Manoplas Encadeadas do Primeiro-sargento
220831	Manoplas de Malha do Primeiro-sargento
220832	Coxotes Encadeados do Cavaleiro
220833	Coxotes Encadeados do Guarda Pétreo
220834	Coxotes de Malha do Guarda Pétreo
220835	Escarpes de Malha do Primeiro-sargento
220836	Escarpes Encadeados do Primeiro-sargento
220837	Escarpes Encadeados do Sargento-mor
220838	Peito d'Armas Inscrito do Guarda Pétreo
220839	Coxotes Inscritos do Guarda Pétreo
220840	Escarpes Inscritos do Primeiro-sargento
220841	Ombreiras Inscritas do Guarda-de-sangue
220842	Morrião Inscrito do Guarda-de-sangue
220843	Manoplas Inscritas do Primeiro-sargento
220844	Peitoral Pulsante do Guarda Pétreo
220845	Manoplas Pulsantes do Primeiro-sargento
220846	Grevas Pulsantes do Primeiro-sargento
220847	Coxotes Pulsantes do Guarda Pétreo
220848	Capacete Pulsante do Guarda-de-sangue
220849	Omoplatas Pulsantes do Guarda-de-sangue
220850	Bandana de Couro do Tenente-cavaleiro
220851	Bandana de Couro do Guarda-de-sangue
220852	Omoplatas de Couro do Tenente-cavaleiro
220853	Omoplatas de Couro do Guarda-de-sangue
220854	Armadura de Couro do Cavaleiro
220855	Armadura de Couro do Guarda Pétreo
220856	Manoplas de Couro do Sargento-mor
220857	Manoplas de Couro do Primeiro-sargento
220858	Calças de Couro do Cavaleiro
220859	Calças de Couro do Guarda Pétreo
220860	Botas de Couro do Sargento-mor
220861	Botas de Couro do Primeiro-sargento
220862	Botas de Couro Crepitante do Sargento-mor
220863	Botas de Couro Crepitante do Primeiro-sargento
220864	Perneiras de Couro Crepitante do Cavaleiro
220865	Perneiras de Couro Crepitante do Guarda Pétreo
220866	Manoplas de Couro Crepitante do Sargento-mor
220867	Manoplas de Couro Crepitante do Primeiro-sargento
220868	Túnica de Couro Crepitante do Cavaleiro
220869	Túnica de Couro Crepitante do Guarda Pétreo
220870	Espaldares de Couro Crepitante do Tenente-cavaleiro
220871	Espaldares de Couro Crepitante do Guarda-de-sangue
220872	Capacete de Couro Crepitante do Tenente-cavaleiro
220873	Capacete de Couro Crepitante do Guarda-de-sangue
220874	Elmo de Couro Restaurado do Tenente-cavaleiro
220875	Elmo de Couro Restaurado do Guarda-de-sangue
220876	Espaldares de Couro Restaurado do Tenente-cavaleiro
220877	Espaldares de Couro Restaurado do Guarda-de-sangue
220878	Gibão de Couro Restaurado do Cavaleiro
220879	Gibão de Couro Restaurado do Guarda Pétreo
220880	Luvas de Couro Restaurado do Sargento-mor
220881	Luvas de Couro Restaurado do Primeiro-sargento
220882	Perneiras de Couro Restaurado do Cavaleiro
220883	Perneiras de Couro Restaurado do Guarda Pétreo
220884	Botas de Couro Restaurado do Sargento-mor
220885	Botas de Couro Restaurado do Primeiro-sargento
220886	Colete de Medotrama do Cavaleiro
220887	Dragonas de Medotrama do Tenente-cavaleiro
220888	Perneiras de Medotrama do Cavaleiro
220889	Chapéu de Medotrama do Tenente-cavaleiro
220890	Luvas de Medotrama do Sargento-mor
220891	Botas de Medotrama do Sargento-mor
220892	Armadura de Cetim do Cavaleiro
220893	Perneiras de Cetim do Cavaleiro
220894	Ombreiras de Cetim do Tenente-cavaleiro
220895	Botas de Cetim do Sargento-mor
220896	Murça de Cetim do Tenente-cavaleiro
220897	Luvas de Cetim do Sargento-mor
220898	Luvas de Cetim do Primeiro-sargento
220899	Murça de Cetim do Guarda-de-sangue
220900	Botas de Cetim do Primeiro-sargento
220901	Ombreiras de Cetim do Guarda-de-sangue
220902	Perneiras de Cetim do Guarda Pétreo
220903	Armadura de Cetim do Guarda Pétreo
220904	Colete de Medotrama do Guarda Pétreo
220905	Dragonas de Medotrama do Guarda-de-sangue
220906	Perneiras de Medotrama do Guarda Pétreo
220907	Chapéu de Medotrama do Guarda-de-sangue
220908	Luvas de Medotrama do Primeiro-sargento
220909	Botas de Medotrama do Primeiro-sargento
220912	Martelo de Geodo
220913	Runa da Demolição
220914	Martelo de Geodo Quebrado
220915	Ídolo do Trôpego Enraivecido
220916	Chifre de Estegodon Pisatroante
220917	Caixa de Pigmento Escarlate
220918	Suprimentos Escondidos: Ensopado de Marisco Inframina
220919	Suprimentos Escondidos: Sopa de Pinoturno
220920	Suprimentos Escondidos: Filés Macios de Lobo
220921	Suprimentos Escondidos: Bandagens Grossas de Magitrama
220922	Suprimentos Escondidos: Ervassol
220923	Suprimentos Escondidos: Folhas-de-sonho
220924	Suprimentos Escondidos: Barras de Veraprata
220925	Suprimentos Escondidos: Barras de Tório
220926	Suprimentos Escondidos: Couro Rústico
220927	Suprimentos Escondidos: Pelego Grosso
220928	Suprimentos Escondidos: Barras de Tório Encantado
220929	Suprimentos Escondidos: Poções Superiores de Mana
220930	Suprimentos Escondidos: Poções Elevadas de Cura
220931	Suprimentos Escondidos: Bombas de Alto-explosivo
220932	Suprimentos Escondidos: Granadas de Tório
220933	Suprimentos Escondidos: Rifles de Tório
220934	Suprimentos Escondidos: Coifas de Mithril
220935	Suprimentos Escondidos: Cintos de Tório
220936	Suprimentos Escondidos: Manoplas Veraprata
220937	Suprimentos Escondidos: Kits de Armadura Rústica
220938	Suprimentos Escondidos: Braçadeiras de Couro Maléfico
220939	Suprimentos Escondidos: Braçadeiras de Couro Rúnico
220940	Suprimentos Escondidos: Bandanas de Magitrama Pretas
220941	Suprimentos Escondidos: Cintos de Runatrama
220942	Suprimentos Escondidos: Camisas de Smoking
220964	Avambraços Energizados pelo Caos Descarregados
220965	Machadão Escamorte
221008	Remessa de Suprimentos
221009	Remessa de Suprimentos
221010	Remessa de Suprimentos
221017	Registros de Keldara
221018	Kit de Remédios de Campo
221019	Amostra de Satirídea
221020	Runa da Deusa da Lua
221021	Semente-do-pesadelo
221024	Frasco dos Pesadelos Sempiternos
221025	Avambraços do Evocador Energizados pelo Caos
221026	Avambraços do Matador Energizados pelo Caos
221027	Avambraços do Protetor Energizados pelo Caos
221028	Signo Encantado: Sonhos Vivos
221030	Mojo de Magia Proibida Atal'ai
221191	Pedra Onírica
221192	Diário de Sonhos
221193	Anel Esmeralda
221196	Mojo de Guerra Atal'ai
221199	Tintura de Satirídea
221256	Braço Direito do Obliterador
221257	Braço Esquerdo do Obliterador
221258	Pé Direito do Obliterador
221259	Pé Esquerdo do Obliterador
221260	Cabeça do Obliterador
221261	Trago do Sussurro Selvagem
221262	Oferenda Selvagem
221267	Runa do Sedento de Sangue
221271	Ás de Selvas
221272	Baralho de Selvas
221273	Dois de Selvas
221274	Três de Selvas
221275	Quatro de Selvas
221276	Cinco de Selvas
221277	Seis de Selvas
221278	Sete de Selvas
221279	Oito de Selvas
221280	Baralho de Pestes
221281	Ás de Peste
221282	Dois de Peste
221283	Três de Peste
221284	Quatro de Peste
221285	Cinco de Peste
221286	Seis de Peste
221287	Sete de Peste
221288	Oito de Peste
221289	Baralho de Dunas
221290	Ás de Dunas
221291	Dois de Dunas
221292	Três de Dunas
221293	Quatro de Dunas
221294	Cinco de Dunas
221295	Seis de Dunas
221296	Sete de Dunas
221297	Oito de Dunas
221298	Ás de Pesadelos
221299	Baralho de Pesadelos
221300	Dois de Pesadelos
221301	Três de Pesadelos
221302	Quatro de Pesadelos
221303	Cinco de Pesadelos
221304	Seis de Pesadelos
221305	Sete de Pesadelos
221306	Oito de Pesadelos
221307	Carta de Negraluna: Decomposição
221308	Carta de Negraluna: Exuberância
221309	Carta de Negraluna: Tempestade de Areia
221310	Carta de Negraluna: Tormento
221311	Mojo da Vida Atal'ai
221312	Frasco de Mojo Atal'ai
221313	Frasco de Mojo Pesadelar
221314	Aviso de Procura-se
221315	Gerador de Arco-íris
221316	Uniforme que Exige Postura de Premo
221317	Meridistal de Feralas
221318	Meridistal de Azshara
221319	Meridistal da Rocha Negra
221320	Meridistal das Terras Agrestes
221321	Sinete de Poder Atal'ai
221322	Sinete de Mojo Atal'ai
221323	Sinete de Serenidade Atal'ai
221324	Chave de Umbraforja Quebradiça
221325	Carga Explosiva X-Plode Fácil
221326	Coração de Cervo Sagrado
221327	Diagrama: Raio Gnômico Encolhedor
221328	Diagrama: Óculos Gnômicos
221329	Diagrama: Projetor Gnômico Redomático
221330	Diagrama: Cinto Gnômico de Prevenção de Ferimentos
221331	Diagrama: Botas-foguete Gnômicas
221332	Diagrama: Frango de Batalha Gnômico
221333	Diagrama: Casquete Gnômico de Controle Mental
221334	Diagrama: Raio Gnômico da Morte
221335	Diagrama: Capacete de Operário Goblínico
221336	Diagrama: Capacete de Mineração Goblínico
221337	Diagrama: Morteiro Goblínico
221338	Diagrama: Carga Sapadora Goblínica
221339	Diagrama: Botas-foguete Goblínicas
221340	Diagrama: Distribuidor de Bombas Goblínico
221341	Diagrama: O Bombão
221342	Diagrama: Pistola Dragônica Goblínica
221343	Diagrama: Capacete-foguete Goblínico
221344	Grimório Pessoal
221345	Sangue Corrompido de Erânicos
221346	Escápula do Avatar Caído
221347	Sapta do Fogo Turva
221348	Sapta da Água Turva
221349	Sapta da Terra Turva
221350	Anotações de Xamã Calcinadas
221351	Anotações de Xamã Encharcadas
221352	Anotações de Xamã Manchadas
221353	Fragmento de Fogo
221354	Fragmento de Água
221355	Fragmento de Terra
221356	Fragmento de Fogo Chamejante
221357	Fragmento de Água Chamejante
221358	Fragmento de Terra Chamejante
221359	Pena de Feruja Imaculada
221360	Papiro Farraki
221361	Resina de Zukk'ash
221362	Flanela de Limpar Arma
221363	Escápula do Avatar Caído
221364	Moeda do Massacre de Cobre
221365	Moeda do Massacre de Prata
221366	Moeda do Massacre de Ouro
221367	Algibeira de Moedas do Massacre de Cobre
221368	Algibeira de Moedas do Massacre de Prata
221369	Dreno do Pesadelo
221370	Medalhão Precioso
221371	Bolsa de Moedas do Sequestrador
221372	Bolsa de Moedas Retalhada
221374	Angústia do Sonho
221376	Elmo do Sonho Esmeralda
221377	Coxotes do Sonho Esmeralda
221378	Manoplas do Sonho Esmeralda
221379	Escarpes do Sonho Esmeralda
221380	Peitoral do Sonho Esmeralda
221381	Brafoneiras do Sonho Esmeralda
221382	Loriga Incrustada de Esmeraldas
221383	Protetores de Mão Incrustados de Esmeraldas
221384	Capacete Incrustado de Esmeraldas
221385	Coxotes Incrustados de Esmeraldas
221386	Espaldares Incrustados de Esmeraldas
221387	Botas de Placa Incrustadas de Esmeraldas
221388	Perneiras de Malha de Escamas Esmeralda
221389	Manoplas de Malha de Escamas Esmeralda
221390	Peitoral de Malha de Escamas Esmeralda
221391	Capacete de Malha de Escamas Esmeralda
221392	Omoplatas de Malha de Escamas Esmeralda
221393	Botas de Malha de Escamas Esmeralda
221394	Botas Cobertas de Esmeraldas
221395	Peitoral Coberto de Esmeraldas
221396	Manoplas Cobertas de Esmeraldas
221397	Capacete Coberto de Esmeraldas
221398	Perneiras Cobertas de Esmeraldas
221399	Omoplatas Cobertas de Esmeraldas
221400	Omoplatas Encadeadas Esmeralda
221401	Perneiras Encadeadas Esmeralda
221402	Capacete Encadeado Esmeralda
221403	Manoplas Encadeadas Esmeralda
221404	Peitoral Encadeado Esmeralda
221405	Botas Encadeadas Esmeralda
221406	Colete de Couro Esmeralda
221407	Luvas de Couro Esmeralda
221408	Elmo de Couro Esmeralda
221409	Escarpes de Couro Esmeralda
221410	Calças de Couro Esmeralda
221411	Omoplatas de Couro Esmeralda
221412	Luvas do Guarda-sonhos Esmeralda
221413	Elmo do Guarda-sonhos Esmeralda
221414	Calças do Guarda-sonhos Esmeralda
221415	Botas do Guarda-sonhos Esmeralda
221416	Omoplatas do Guarda-sonhos Esmeralda
221417	Baú do Guarda-sonhos Esmeralda
221418	Rugido de Agamaggan
221419	Colete do Vigia Esmeralda
221420	Botas do Vigia Esmeralda
221421	Luvas do Vigia Esmeralda
221422	Elmo do Vigia Esmeralda
221423	Perneiras do Vigia Esmeralda
221424	Omoplatas do Vigia Esmeralda
221425	Diadema Encantado Esmeralda
221426	Botas Encantadas Esmeralda
221427	Luvas Encantadas Esmeralda
221428	Runa do Jogo Sujo
221429	Calças Encantadas Esmeralda
221430	Vestes Encantadas Esmeralda
221431	Omoplatas Encantadas Esmeralda
221432	Dragonas Trançadas Esmeralda
221433	Runa da Concentração
221434	Vestes Trançadas Esmeralda
221435	Calças Trançadas Esmeralda
221436	Luvas Trançadas Esmeralda
221437	Diadema Trançado Esmeralda
221438	Botas Trançadas Esmeralda
221439	Armadura do Sono Esmeralda
221440	Rugido do Sonho
221441	Guardião do Sonho
221442	Rugido do Guardião
221443	Rugido do Bosque
221444	Durião da Selva
221445	Runa do Fogo Focalizado
221446	Martelo do Ritualista
221447	Grimório de Sangreluna do Ritualista
221448	Talismã do Bosque Corrompido
221450	Arco do Lutador do Fosso Gurubashi
221451	Besta Sanguissedenta
221452	Elo Arcano com Foco em Sangue
221453	Elo de Sangue Fervente
221454	Elo de Sangue Glacial
221455	Reverência da Luz Sangrenta
221456	Sabre Sanguíneo Eclipsado
221457	Incunábulo de Destruição Dracônica
221458	Elo da Vitória Sombrio
221459	Selo do Sacrificado
221460	Punhal de Ataque pelas Costas Gurubashi
221461	Runa da Chacina
221462	Espada da Velocidade Ensanguentada
221463	Boneca Vodu Ancestral
221464	Totem da Precisão Abrasadora
221465	Arrebentador Corrompido
221466	Aro do Sangue Ardente
221467	Olho de Sangreluna
221468	Muralha dos Sussurros
221469	Lança Farpada do Caçador de Cabeças
221470	Esmeralda Onírica
221471	Baú dos Guardiões Esmeralda
221473	Runa do Vigia
221474	Essência Acorrentada de Erânicos
221475	Essência de Erânicos
221480	Anotações de Feitiços: Armadura Derretida
221481	Epifania Niilista
221482	Runa de Suplício
221483	Runa de Queimadura
221484	Vareta de Bagata de Mandingueiro
221487	Anotações de Feitiços: Proteção Avançada
221488	Epifania Resoluta
221489	Runa da Vingança
221490	Runa da Contracorrente
221491	Bolsa Caninegro
221497	Chave Velha
221498	Lancheira Robusta
221499	Runa do Guarda Vil
221510	Runa do Cavaleiro
221511	Runa do Protetor
221512	Runa da Vivacidade
221513	Runa do Vigor
221514	Runa do Poder de Fogo
221515	Runa da Detonação
221516	Runa da Energia Primeva
221517	Runa de Derramamento de Sangue
221518	Sussurro
221519	Orbe de Mannoroc
221544	Ovo de Corvo da Tormenta
221545	Anotações de Bruxo Decifradas
221547	Anotações de Bruxo Codificadas
221549	Código Errante
221780	Cetro da Princesa Theradras
221781	Elmo de Vanguarda
221782	Elmo do Exílio
221783	Espaldares do Mantenedor da Lei
221785	Vestimenta Cenariana
221971	Chifre de Jurassonho
221972	Fogo da Pira Onírica
221973	Presa de Caçador de Sonhos
221974	Colar Temível Totem
221975	Cajado Patábua Quebrado
221976	Cajado da Natureza Adoecida
221978	Alma do Explorador
221979	Profecia do Inverno Verdejante
221980	Profecia do Caos Desperto
221981	Profecia da Tribo Perdida
222952	Frasco dos Sonhos Inquietos
222962	Sabedoria de Hyjal
223073	Palas de Malha do Tenente-cavaleiro
223074	Coxotes de Malha do Cavaleiro
223075	Capacete de Malha do Tenente-cavaleiro
223076	Manoplas de Malha do Primeiro-sargento
223077	Escarpes de Malha do Primeiro-sargento
223078	Armadura de Malha do Cavaleiro
223147	Anotações de Feitiços: Seta Incendiária
223148	Tesouro Sobrenatural
223149	Tesouro Sobrenatural
223150	Tesouro Sobrenatural
223151	Tesouro Sobrenatural
223160	Arbusto Baratinho
223161	Caixote de Suprimentos Vazio
223162	Capanga de Mensageiro Prática
223163	Fórmula: Pergaminho da Recomposição Espacial
223164	Capucho da Curiosidade
223167	Casquete da Iniciativa
223168	Fragmento do Núcleo do Mundo
223169	Casquete da Tenacidade
223171	Pergaminho de Geomancia
223172	Corrente da Tenacidade
223173	Cordão do Geomante
223174	Botas do Geomante
223175	Manto do Geomante
223177	Bandana do Geomante
223178	Braçadeiras do Geomante
223180	Luvas do Geomante
223181	Espaldares do Geomante
223182	Calças do Geomante
223183	Veste do Geomante
223186	Expedidor de Suprimentos
223192	Cordão do Indomado
223193	Coroa do Tece-sonhos
223194	Elo da Natureza Selvagem
223195	Amplidão da Fera
223196	Grevas do Teocida
223197	Defesa da Natureza
223198	Modas Karkun
223214	Zila Gular
223215	Orah Raka
223216	Rakkan Archim
223217	Rakkas Lek
223218	Tor Kieldaz
223219	Munhequeiras de Tecido Vil
223221	Munhequeiras de Couro Vil
223222	Munhequeiras de Malha Vil
223237	Ombreiras de Tecido Vil
223238	Ombreiras de Couro Vil
223239	Omoplatas de Malha Vil
223240	Capuz de Tecido Vil
223241	Chapéu de Couro Vil
223242	Coifa de Couro Vil
223248	Perneiras de Tecido Vil
223249	Perneiras de Couro Vil
223250	Perneiras de Malha Vil
223251	Perneiras de Placa Vil
223256	Vestes de Tecido Vil
223261	Peitoral de Couro Vil
223262	Peitoral de Malha Vil
223263	Peitoral de Placa Vil
223283	Comenda Manchada de Sangue
223288	Runa do Martelo
223323	Camisa
223324	Perneiras do Andarilho das Chuvas
223325	Peitoral de Hakkari
223326	Mortalha Hakkari
223327	Marca de Hakkar
223328	Diadema Explodegema
223329	Punhal de Força Vital
223330	Olho Pulsante
223331	Olho Pulsante
223332	Olho Vibrante
223333	Olho Agourento
223334	Olho Brilhante
223335	Olho Gosmento
223336	Olho Penetrante
223337	Olho Ardente
223518	Punhal de Aragonita
223519	Olho de Theradras
223520	Espada Focal do Inventor
223521	Dragonas Putrigarra
223522	Elmo da Montanha
223523	Pedra Nuvem
223524	Punho de Pedra
223525	Cocar do Adivinho
223526	Sul'thraze, a Açoitadora
223527	Presa de Gahz'rilla
223528	Armadura de Escama de Gahz'rilla
223529	Peitoral Azarado
223530	Kilt Azarado
223531	Brafoneiras Sinistronas
223532	Amuleto de Sangue Vital
223533	Cajado do Nômade do Deserto
223534	Guantes de Jumanza
223535	Vestimenta Tribal do Grimlok
223536	Ímpeto de Grimlok
223537	Braçadeiras de Placa Craniana
223538	Báculo Lenhoso
223539	Esfera Encantada
223540	Arco do Mestre de Matilha
223541	Coração de Lasca Preciosa
223542	Rifle Megatiro
223543	Sandálias de Vinhapútrida
223544	Espaldares de Metalreles
223545	Broquel Modernaço de Bugitranca
223648	Flecha imbuída em Sonho
223912	Poção de Purificação
223913	Poção Elevada de Cura
223914	Poção Maior de Cura
223962	Tornozeleira do Espreitareia
223963	Abraço de Lycan
223964	Lâmina da Escuridão Eterna
223980	Perneiras de Escama Ígnea
223981	Vestes do Vagachamas
223982	Rifle do Mestre de Matilha
223983	Lâmina do Mediador
223984	Luvas de Teiasseda
223985	Elo Ciclópico
223986	Capa Podretumba
223987	Omoplatas de Courotala
224004	Anel Esmeralda
224005	Anel Esmeralda
224006	Anel Esmeralda
224122	Devorador do Sonho
224279	Terrestris
224280	Suserano, Defensor das Revoadas Dragônicas
224281	Gla'sir
224282	Rae'lar
224409	Golpeador de Serpente
224806	Sintonizador de Portal da Legião
224836	Tesouro Sobrenatural
224848	Tesouro Sobrenatural
224849	Tesouro Sobrenatural
224850	Tesouro Sobrenatural
224851	Tesouro Sobrenatural
224893	Sintonizador de Portais Sobrecarregado
224912	Sintonizador de Sintonizador de Portais
225675	Núcleo Obsidiano Fuliginoso
225676	Núcleo Obsidiano Derretido
225686	Runa da Dizimação
225687	Runa da Armadura Infernal
225688	Runa da Marca do Caos
225689	Anotações de Feitiços: Salva Arcana
225690	Anotações de Feitiços: Orbe Congelado
225691	Anotações de Feitiços: Superaquecimento
225740	Runa da Compostura
225838	Ícone Voltaico
225893	Fim das Eras
225914	Runa do Espírito Aprisionado
225929	Estilhaço de Alma Pestilento
225938	Anotações de Feitiços Rasgadas
225939	Anotações de Feitiços Rasgadas
225940	Anotações de Feitiços Rasgadas
225941	Anotações de Feitiços Rasgadas
225942	Carne Estragada de Porco
225943	Naco de Carne Rançoso
225954	Anotações de Feitiços Calcinadas
225955	Runa do Desenvolto
226122	Trompa de Dalton
226201	Lâmina do Escudeiro Cuteberto
226207	Eco de Anastari
226208	Eco de Barthilas
226209	Eco de Dathrohan
226210	Eco de Maleki
226211	Eco de Nerub'enkan
226212	Eco de Ramstein
226213	Eco de Rivendare
226214	Eco de Gualter
226252	Runa do Guerrilheiro
226374	Veneno Oculto I
226394	Manual do Veneno Atrófico
226395	Manual do Veneno Entorpecente
226396	Manual do Veneno Oculto
226397	Manual do Veneno Sebáceo
226401	Tratado do Coração de Leão
226402	Revelação da Fúria Xamanística
226403	Manual do Gancho de Açougue
226404	Real da Inframina Desgastado
226405	Caixote de Suprimentos da Inframina Danificado
226406	Runa de Especialização em Espada
226407	Runa de Especialização em Machado
226408	Runa de Especialização em Maça
226409	Runa de Especialização em Adaga
226410	Runa de Especialização em Arma de Longo Alcance
226411	Runa de Especialização em Arma de Punho
226412	Runa de Especialização em Arma de Longo Alcance
226413	Runa de Especialização Arcana
226414	Runa de Especialização em Fogo
226415	Runa de Especialização Gélida
226416	Runa de Especialização em Natureza
226417	Runa de Especialização em Sombra
226418	Runa de Especialização Sagrada
226419	Runa de Especialização em Combate Feral
226420	Busto Ricamente Confeccionado
226421	PLACEHOLDER_ASHBRINGER_QUESTITEM_01
226440	Cinto do Matador Noturno
226441	Luvas do Matador Noturno
226442	Braceletes do Matador Noturno
226443	Botas do Matador Noturno
226444	Ombreiras do Matador Noturno
226445	Calças do Matador Noturno
226446	Elmo do Matador Noturno
226447	Peito d'Armas do Matador Noturno
226472	Jarra de Sombras de Stratholme
226473	Corselete do Matador Noturno
226474	Cinta do Matador Noturno
226475	Protetores de Mão do Matador Noturno
226476	Braçadeiras do Matador Noturno
226477	Tabis do Matador Noturno
226478	Brafoneiras do Matador Noturno
226479	Guarda-pernas do Matador Noturno
226480	Capuz do Matador Noturno
226484	Braçadeiras do Poder
226485	Cinto do Poder
226486	Manoplas do Poder
226487	Escarpes do Poder
226488	Elmo do Poder
226489	Peitoral do Poder
226490	Coxotes do Poder
226491	Placa d'Ombros do Poder
226492	Brafoneiras do Poder
226493	Perneiras do Poder
226494	Cota do Poder
226495	Maxilar do Poder
226496	Botinas do Poder
226497	Mãos do Poder
226498	Faixa do Poder
226499	Guarda-braços do Poder
226500	Amuleto da Chama Dracônica Lascado
226523	Trompa de Dalton
226526	Tranqueira Detonada
226527	Palas do Espreita-gigantes
226528	Luvas do Espreita-gigantes
226529	Cinto do Espreita-gigantes
226530	Braçadeiras do Espreita-gigantes
226531	Botas do Espreita-gigantes
226532	Perneiras do Espreita-gigantes
226533	Capacete do Espreita-gigantes
226534	Peitoral do Espreita-gigantes
226535	Malha de Anéis do Espreita-gigantes
226536	Socapa do Espreita-gigantes
226537	Perneiras Encadeadas do Espreita-gigantes
226538	Escarpes do Espreita-gigantes
226540	Protetores de Mão do Espreita-gigantes
226541	Munhequeiras do Espreita-gigantes
226542	Cinturão do Espreita-gigantes
226543	Brafoneiras do Espreita-gigantes
226545	Trompa de Dalton
226546	Sonar do Deserto
226547	Calças Vilcórdias
226548	Vestes Vilcórdias
226549	Chifres Vilcórdios
226550	Ombreiras Vilcórdias
226551	Cinto Vilcórdio
226552	Luvas Vilcórdias
226553	Braçadeiras Vilcórdias
226554	Sapatilhas Vilcórdias
226555	Cinto do Arcanista
226556	Luvas do Arcanista
226557	Botas do Arcanista
226558	Braceletes do Arcanista
226559	Vestes do Arcanista
226560	Dragonas do Arcanista
226561	Perneiras do Arcanista
226562	Coroa do Arcanista
226563	Farpela do Arcanista
226564	Diadema do Arcanista
226565	Calças do Arcanista
226566	Omoplatas do Arcanista
226567	Munhecas do Arcanista
226568	Sandálias do Arcanista
226569	Protetores de Mão do Arcanista
226570	Cordão do Arcanista
226571	Botas da Profecia
226572	Luvas da Profecia
226573	Diadema da Profecia
226574	Calças da Profecia
226575	Vestes da Profecia
226576	Dragonas da Profecia
226577	Cinturão da Profecia
226578	Avambraços da Profecia
226579	Munhecas da Profecia
226580	Cinto da Profecia
226581	Ombreiras da Profecia
226582	Farpela da Profecia
226583	Perneiras da Profecia
226584	Coroa da Profecia
226585	Mãos da Profecia
226586	Sandálias da Profecia
226587	Runa do Bombardeio
226588	Espaldares do Mantenedor da Lei
226589	Braçadeiras do Mantenedor da Lei
226590	Elmo do Mantenedor da Lei
226591	Manoplas do Mantenedor da Lei
226592	Cinto do Mantenedor da Lei
226593	Botas do Mantenedor da Lei
226594	Coxotes do Mantenedor da Lei
226595	Couraça do Mantenedor da Lei
226596	Embraces de Guerra do Mantenedor da Lei
226597	Cinturão do Mantenedor da Lei
226598	Perneiras do Mantenedor da Lei
226599	Coroa do Mantenedor da Lei
226600	Guantes do Mantenedor da Lei
226601	Botas de Batalha do Mantenedor da Lei
226602	Peitoral do Mantenedor da Lei
226603	Avambraços do Mantenedor da Lei
226604	Cinto de Batalha do Mantenedor da Lei
226605	Brafoneiras do Mantenedor da Lei
226606	Guarda-pernas do Mantenedor da Lei
226607	Cimeira do Mantenedor da Lei
226608	Protetores de Mão do Mantenedor da Lei
226609	Escarpes do Mantenedor da Lei
226610	Guarda-peito do Mantenedor da Lei
226611	Palas Terrafúria
226612	Capacete Terrafúria
226613	Botas Terrafúria
226614	Guarda-pernas Terrafúria
226615	Manoplas Terrafúria
226616	Cinto Terrafúria
226617	Vestimenta Terrafúria
226618	Braçadeiras Terrafúria
226619	Cota Anilhada Terrafúria
226620	Chancas Terrafúria
226621	Mãos Terrafúria
226622	Visor Terrafúria
226623	Perneiras Terrafúria
226624	Dragonas Terrafúria
226625	Cordão Terrafúria
226626	Pulseiras Terrafúria
226627	Malha de Escamas Terrafúria
226628	Escarpes Terrafúria
226629	Protetores de Mão Terrafúria
226630	Grande Elmo Terrafúria
226631	Perneiras em Escamas Terrafúria
226632	Brafoneiras Terrafúria
226633	Cinta Terrafúria
226634	Munhequeiras Terrafúria
226635	Malha de Anéis Terrafúria
226636	Botas de Batalha Terrafúria
226637	Guantes Terrafúria
226638	Bacinete Terrafúria
226639	Perneiras Encadeadas Terrafúria
226640	Espaldares Terrafúria
226641	Cinturão Terrafúria
226642	Braceletes Terrafúria
226644	Espaldares Cenarianos
226645	Botas Cenarianas
226646	Perneiras Cenarianas
226647	Elmo Cenariano
226648	Luvas Cenarianas
226649	Braçadeiras Cenarianas
226650	Cinto Cenariano
226651	Calças Cenarianas
226652	Sandálias Cenarianas
226653	Manto Cenariano
226654	Manoplas Cenarianas
226655	Pulsos Cenarianos
226656	Amplexo Cenariano
226657	Cordão Cenariano
226658	Galhada Cenariana
226659	Trompas Cenarianas
226660	Cinturão Cenariano
226661	Túnica Cenariana
226662	Embraces Cenarianos
226663	Botinas Cenarianas
226664	Punhos Cenarianos
226665	Omoplatas Cenarianas
226666	Calçotes Cenarianos
226667	Cinta Cenariana
226668	Munhequeiras Cenarianas
226669	Guantes Cenarianos
226670	Coroa Cenariana
226671	Guarda-pernas Cenarianos
226673	Chancas Cenarianas
226674	Brafoneiras Cenarianas
226675	Armadura Cenariana
226678	Premonição e Antecipação de Combate
226679	Percepções do Errante Atemporal
226680	Runa do Primeiro Guerreiro
226694	Runa de Especialização de Defesa
226698	Rosqueta Ortoparafusada
226699	Flange Parolada Grapetada em Latão
226700	Túnica da Arte Sombria
226701	Cinto da Arte Sombria
226702	Luvas da Arte Sombria
226703	Botas da Arte Sombria
226704	Braçadeiras da Arte Sombria
226705	Calças da Arte Sombria
226706	Espaldares da Arte Sombria
226707	Capuz da Arte Sombria
226708	Capucho do Coração Selvagem
226709	Kilt do Coração Selvagem
226710	Dragonas do Coração Selvagem
226711	Luvas do Coração Selvagem
226712	Cinto do Coração Selvagem
226713	Botas do Coração Selvagem
226714	Braçadeiras do Coração Selvagem
226715	Colete do Coração Selvagem
226716	Dragonas do Espreitador de Feras
226717	Braceletes do Espreitador de Feras
226718	Cinto do Espreitador de Feras
226719	Calças do Espreitador de Feras
226720	Casquete do Espreitador de Feras
226721	Luvas do Espreitador de Feras
226722	Botas do Espreitador de Feras
226723	Túnica do Espreitador de Feras
226724	Cinto do Magíster
226725	Braceletes do Magíster
226726	Dragonas do Magíster
226727	Perneiras do Magíster
226728	Coroa do Magíster
226729	Vestes do Magíster
226730	Botas do Magíster
226731	Luvas do Magíster
226732	Cinto da Forja de Luz
226733	Elmo da Forja de Luz
226734	Peitoral da Forja de Luz
226735	Espaldares da Forja de Luz
226736	Coxotes da Forja de Luz
226737	Manoplas da Forja de Luz
226738	Botas da Forja de Luz
226739	Braçadeiras da Forja de Luz
226740	Luvas do Devoto
226741	Dragonas do Devoto
226742	Braçadeiras do Devoto
226743	Sandálias do Devoto
226744	Cinto do Devoto
226745	Veste do Devoto
226746	Coroa do Devoto
226747	Saia do Devoto
226748	Manoplas dos Elementos
226749	Colete dos Elementos
226750	Kilt dos Elementos
226751	Braceletes dos Elementos
226752	Botas dos Elementos
226753	Brafoneiras dos Elementos
226754	Cordão dos Elementos
226755	Coifa dos Elementos
226756	Dragonas de Brumedo
226757	Veste de Brumedo
226758	Guarda-braços de Brumedo
226759	Braçadeiras de Brumedo
226760	Perneiras de Brumedo
226761	Cinto de Brumedo
226762	Máscara de Brumedo
226763	Sandálias de Brumedo
226764	Botas do Valor
226765	Cinto do Valor
226766	Braçadeiras do Valor
226767	Coxotes do Valor
226768	Espaldares do Valor
226769	Elmo do Valor
226770	Peitoral do Valor
226771	Manoplas do Valor
226772	Faixa do Coração Feral
226773	Capucho do Coração Feral
226774	Galochas do Coração Feral
226775	Munhequeiras do Coração Feral
226776	Colete do Coração Feral
226777	Mãos do Coração Feral
226778	Espaldares do Coração Feral
226779	Kilt do Coração Feral
226780	Cordão do Coração Feral
226781	Sandálias do Coração Feral
226782	Braceletes do Coração Feral
226783	Abraço do Coração Feral
226784	Manoplas do Coração Feral
226785	Dragonas do Coração Feral
226786	Cocar do Coração Feral
226787	Calças do Coração Feral
226788	Embraces do Coração Feral
226789	Cinturão do Coração Feral
226790	Palas do Coração Feral
226791	Calçotes do Coração Feral
226792	Casquete do Coração Feral
226793	Punhos do Coração Feral
226794	Chancas do Coração Feral
226795	Túnica do Coração Feral
226796	Munhequeiras do Coração Feral
226797	Cinta do Coração Feral
226798	Brafoneiras do Coração Feral
226799	Guarda-pernas do Coração Feral
226801	Viseira do Coração Feral
226802	Guantes do Coração Feral
226803	Botinas do Coração Feral
226804	Couraça do Coração Feral
226815	Pulsos do Coração Feral
226816	Cintura do Coração Feral
226817	Omoplatas do Coração Feral
226818	Pernas do Coração Feral
226819	Elmo do Coração Feral
226820	Luvas do Coração Feral
226821	Botas do Coração Feral
226822	Peitoral do Coração Feral
226825	Túnica do Manto Negro
226826	Espaldares do Manto Negro
226827	Calças do Manto Negro
226828	Guantes do Manto Negro
226829	Casquete do Manto Negro
226830	Braçadeiras do Manto Negro
226831	Pisantes do Manto Negro
226832	Cinto do Manto Negro
226835	Munhequeiras do Manto Negro
226836	Cinta do Manto Negro
226837	Brafoneiras do Manto Negro
226838	Guarda-pernas do Manto Negro
226840	Protetores de Mão do Manto Negro
226841	Viseira do Manto Negro
226842	Botinas do Manto Negro
226843	Armadura do Manto Negro
226845	Pulsos do Manto Negro
226846	Cintura do Manto Negro
226847	Omoplatas do Manto Negro
226848	Pernas do Manto Negro
226849	Elmo do Manto Negro
226850	Luvas do Manto Negro
226851	Botas do Manto Negro
226852	Baú do Manto Negro
226856	Acelerador de Flutuação Guiado
226857	Botas de Batalha do Heroísmo
226858	Espaldares do Heroísmo
226859	Coxotes do Heroísmo
226860	Coroa do Heroísmo
226861	Manoplas do Heroísmo
226862	Peitoral do Heroísmo
226863	Braçadeiras do Heroísmo
226864	Cinto do Heroísmo
226865	Munhequeiras do Heroísmo
226866	Cinta do Heroísmo
226867	Brafoneiras do Heroísmo
226868	Guarda-pernas do Heroísmo
226869	Viseira do Heroísmo
226870	Protetores de Mão do Heroísmo
226871	Escarpes do Heroísmo
226872	Couraça do Heroísmo
226873	Pulsos do Heroísmo
226874	Cintura do Heroísmo
226875	Omoplatas do Heroísmo
226876	Pernas do Heroísmo
226877	Elmo do Heroísmo
226878	Luvas do Heroísmo
226879	Botas do Heroísmo
226880	Peitoral do Heroísmo
226881	Botinas do Senhor das Feras
226882	Calças do Senhor das Feras
226883	Manoplas do Senhor das Feras
226884	Dragonas do Senhor das Feras
226885	Braceletes do Senhor das Feras
226886	Túnica do Senhor das Feras
226887	Casquete do Senhor das Feras
226888	Cinto do Senhor das Feras
226889	Braçadeiras do Senhor das Feras
226890	Banda do Senhor das Feras
226891	Brafoneiras do Senhor das Feras
226892	Perneiras do Senhor das Feras
226893	Coifa do Senhor das Feras
226894	Punhos do Senhor das Feras
226895	Grevas do Senhor das Feras
226896	Corrente do Senhor das Feras
226897	Pulsos do Senhor das Feras
226898	Cintura do Senhor das Feras
226899	Omoplatas do Senhor das Feras
226900	Pernas do Senhor das Feras
226901	Elmo do Senhor das Feras
226902	Luvas do Senhor das Feras
226903	Botas do Senhor das Feras
226904	Torso do Senhor das Feras
226905	Cinto Brumorte
226906	Veste Brumorte
226907	Braçadeiras Brumorte
226908	Sandálias Brumorte
226909	Máscara Brumorte
226910	Perneiras Brumorte
226911	Guarda-braços Brumorte
226912	Dragonas Brumorte
226913	Braceletes Brumorte
226914	Cordão Brumorte
226915	Palas Brumorte
226916	Calças Brumorte
226917	Capuz Brumorte
226918	Agarres Brumorte
226919	Botinas Brumorte
226920	Abraço Brumorte
226921	Pulsos Brumorte
226922	Cintura Brumorte
226923	Omoplatas Brumorte
226924	Pernas Brumorte
226925	Elmo Brumorte
226926	Luvas Brumorte
226927	Botas Brumorte
226928	Torso Brumorte
226929	Braçadeiras do Feiticeiro
226930	Manoplas do Feiticeiro
226931	Sandálias do Feiticeiro
226932	Vestes do Feiticeiro
226933	Perneiras do Feiticeiro
226934	Cinto do Feiticeiro
226935	Coroa do Feiticeiro
226936	Dragonas do Feiticeiro
226937	Pulsos do Feiticeiro
226938	Cintura do Feiticeiro
226939	Omoplatas do Feiticeiro
226940	Pernas do Feiticeiro
226941	Elmo do Feiticeiro
226942	Luvas do Feiticeiro
226943	Botas do Feiticeiro
226944	Torso do Feiticeiro
226945	Veste do Virtuoso
226946	Saia do Virtuoso
226947	Coroa do Virtuoso
226948	Cinto do Virtuoso
226949	Braçadeiras do Virtuoso
226950	Luvetes do Virtuoso
226951	Dragonas do Virtuoso
226952	Sandálias do Virtuoso
226953	Munhequeiras do Virtuoso
226954	Cordão do Virtuoso
226955	Palas do Virtuoso
226956	Perneiras do Virtuoso
226957	Capucho do Virtuoso
226958	Mãos do Virtuoso
226959	Sapatilhas do Virtuoso
226960	Brial do Virtuoso
226961	Pulsos do Virtuoso
226962	Cintura do Virtuoso
226963	Omoplatas do Virtuoso
226964	Pernas do Virtuoso
226965	Elmo do Virtuoso
226966	Luvas do Virtuoso
226967	Botas do Virtuoso
226968	Torso do Virtuoso
226969	Espaldares da Forja da Alma
226970	Braçadeiras da Forja da Alma
226971	Cinto da Forja da Alma
226972	Coxotes da Forja da Alma
226973	Peitoral da Forja da Alma
226974	Coturnos da Forja da Alma
226975	Manoplas da Forja da Alma
226976	Grande Elmo da Forja da Alma
226977	Braceletes da Forja da Alma
226978	Cordão da Forja da Alma
226979	Palas da Forja da Alma
226980	Perneiras da Forja da Alma
226981	Coroa da Forja da Alma
226982	Punhos da Forja da Alma
226983	Botinas da Forja da Alma
226984	Abraço da Forja da Alma
226985	Munhequeiras da Forja da Alma
226986	Cinta da Forja da Alma
226987	Brafoneiras da Forja da Alma
226988	Guarda-pernas da Forja da Alma
226989	Viseira da Forja da Alma
226990	Protetores de Mão da Forja da Alma
226991	Escarpes da Forja da Alma
226992	Couraça da Forja da Alma
226993	Pulsos da Forja da Alma
226994	Cintura da Forja da Alma
226995	Ombros da Forja da Alma
226996	Pernas da Forja da Alma
226997	Elmo da Forja das Almas
226998	Luvas da Forja da Alma
226999	Botas da Forja da Alma
227000	Torso da Forja da Alma
227001	Braceletes dos Cinco Trovões
227002	Coifa dos Cinco Trovões
227003	Brafoneiras dos Cinco Trovões
227004	Colete dos Cinco Trovões
227005	Kilt dos Cinco Trovões
227006	Manoplas dos Cinco Trovões
227007	Sapatilhas dos Cinco Trovões
227008	Cordão dos Cinco Trovões
227009	Braçadeiras dos Cinco Trovões
227010	Faixa dos Cinco Trovões
227011	Dragonas dos Cinco Trovões
227012	Perneiras dos Cinco Trovões
227013	Coroa dos Cinco Trovões
227014	Agarres dos Cinco Trovões
227015	Grevas dos Cinco Trovões
227016	Túnica dos Cinco Trovões
227017	Embraces dos Cinco Trovões
227018	Cinturão dos Cinco Trovões
227019	Espaldares dos Cinco Trovões
227020	Coxotes dos Cinco Trovões
227021	Face dos Cinco Trovões
227022	Punhos dos Cinco Trovões
227023	Botinas dos Cinco Trovões
227024	Corrente dos Cinco Trovões
227025	Munhequeiras dos Cinco Trovões
227026	Cinta dos Cinco Trovões
227027	Guarda-ombros dos Cinco Trovões
227028	Guarda-pernas dos Cinco Trovões
227029	Bacinete dos Cinco Trovões
227030	Protetores de Mão dos Cinco Trovões
227031	Escarpes dos Cinco Trovões
227032	Couraça dos Cinco Trovões
227033	Pulsos dos Cinco Trovões
227034	Cintura dos Cinco Trovões
227035	Omoplatas dos Cinco Trovões
227036	Pernas dos Cinco Trovões
227037	Elmo dos Cinco Trovões
227038	Luvas dos Cinco Trovões
227039	Botas dos Cinco Trovões
227040	Torso dos Cinco Trovões
227041	Bisturi da Sombra do Flagelo
227042	Omoplatas de Placa do Campeão
227043	Elmo de Placa do Campeão
227044	Elmo de Placa do Tenente-comandante
227045	Omoplatas de Placa do Tenente-comandante
227046	Cota de Placa do Capitão-cavaleiro
227047	Perneiras de Placa do Capitão-cavaleiro
227048	Perneiras de Placa do Legionário
227049	Cota de Placa do Legionário
227050	Manoplas de Placa do Guarda-de-sangue
227051	Grevas de Placa do Guarda-de-sangue
227052	Grevas de Placa do Tenente-cavaleiro
227053	Manoplas de Placa do Tenente-cavaleiro
227054	Omoplatas de Couro do Tenente-comandante
227055	Elmo de Couro do Tenente-comandante
227056	Omoplatas de Couro do Campeão
227057	Elmo de Couro do Campeão
227058	Peito d'Armas de Couro do Capitão-cavaleiro
227059	Guarda-pernas de Couro do Legionário
227060	Peito d'Armas de Couro do Legionário
227061	Guarda-pernas de Couro do Capitão-cavaleiro
227062	Chancas de Couro do Guarda-de-sangue
227063	Guantes de Couro do Guarda-de-sangue
227064	Chancas de Couro do Tenente-cavaleiro
227065	Guantes de Couro do Tenente-cavaleiro
227066	Elmo Encadeado do Tenente-comandante
227067	Elmo Encadeado do Campeão
227068	Omoplatas Encadeadas do Tenente-comandante
227069	Omoplatas Encadeadas do Campeão
227070	Cota Encadeada do Capitão-cavaleiro
227071	Cota Encadeada do Legionário
227072	Guarda-pernas Encadeadas do Capitão-cavaleiro
227073	Guarda-pernas Encadeados do Legionário
227074	Grevas Encadeadas do Guarda-de-sangue
227075	Luvas Encadeadas do Guarda-de-sangue
227076	Grevas Encadeadas do Tenente-cavaleiro
227077	Munhequeiras Encadeadas do Tenente-cavaleiro
227078	Brafoneiras Encadeadas do Campeão
227079	Coxotes Encadeados do Legionário
227080	Grande Elmo Encadeado do Campeão
227081	Guantes Encadeados do Guarda-de-sangue
227082	Escarpes Encadeados do Guarda-de-sangue
227083	Armadura Encadeada do Legionário
227084	Brafoneiras Encadeadas do Tenente-comandante
227085	Coxotes Encadeados do Capitão-cavaleiro
227086	Grande Elmo Encadeado do Tenente-comandante
227087	Guantes Encadeados do Tenente-cavaleiro
227088	Escarpes Encadeados do Tenente-cavaleiro
227089	Armadura Encadeada do Capitão-cavaleiro
227090	Capucho de Medotrama do Campeão
227091	Espaldares de Medotrama do Tenente-comandante
227092	Espaldares de Medotrama do Campeão
227093	Capucho de Medotrama do Tenente-comandante
227094	Túnica de Medotrama do Legionário
227095	Guarda-pernas de Medotrama do Capitão-cavaleiro
227096	Túnica de Medotrama do Capitão-cavaleiro
227097	Guarda-pernas de Medotrama do Legionário
227098	Chancas de Medotrama do Guarda-de-sangue
227099	Mitenes de Medotrama do Guarda-de-sangue
227100	Mitenes de Medotrama do Tenente-cavaleiro
227101	Chancas de Couro do Tenente-cavaleiro
227102	Dragonas de Seda do Tenente-comandante
227103	Capucho de Seda do Tenente-comandante
227104	Dragonas de Seda do Campeão
227105	Capucho de Seda do Campeão
227106	Túnica de Seda do Legionário
227107	Guarda-pernas de Seda do Legionário
227108	Túnica de Seda do Capitão-cavaleiro
227109	Guarda-pernas de Seda do Capitão-cavaleiro
227110	Chancas de Seda do Guarda-de-sangue
227111	Mitenes de Seda do Guarda-de-sangue
227112	Chancas de Seda do Tenente-cavaleiro
227113	Mitenes de Seda do Tenente-cavaleiro
227114	Manoplas de Seda do Tenente-cavaleiro
227115	Manoplas de Seda do Guarda-de-sangue
227116	Luvas de Seda do Tenente-cavaleiro
227117	Luvas de Seda do Guarda-de-sangue
227118	Capuz de Cetim do Campeão
227119	Dragonas de Cetim do Tenente-comandante
227120	Dragonas de Cetim do Campeão
227121	Capuz de Cetim do Tenente-comandante
227122	Túnica de Cetim do Capitão-cavaleiro
227123	Guarda-pernas de Cetim do Legionário
227124	Túnica de Cetim do Legionário
227125	Guarda-pernas de Cetim do Capitão-cavaleiro
227126	Mitenes de Cetim do Guarda-de-sangue
227127	Chancas de Cetim do Guarda-de-sangue
227128	Mitenes de Cetim do Tenente-cavaleiro
227129	Chancas de Cetim do Tenente-cavaleiro
227130	Palas de Cetim do Campeão
227131	Perneiras de Cetim do Legionário
227132	Coroa de Cetim do Campeão
227133	Guantes de Cetim do Guarda-de-sangue
227134	Botinas de Cetim do Guarda-de-sangue
227135	Veste de Cetim do Legionário
227136	Palas de Cetim do Tenente-comandante
227137	Perneiras de Cetim do Capitão-cavaleiro
227138	Coroa de Cetim do Tenente-comandante
227139	Guantes de Cetim do Tenente-cavaleiro
227140	Botinas de Cetim do Tenente-cavaleiro
227141	Veste de Cetim do Capitão-cavaleiro
227142	Peitoral Lamelar do Capitão-cavaleiro
227143	Perneiras Lamelares do Capitão-cavaleiro
227144	Cimeira Lamelar do Tenente-comandante
227145	Omoplatas Lamelares do Tenente-comandante
227146	Escarpes Lamelares do Tenente-cavaleiro
227147	Manoplas Lamelares do Tenente-cavaleiro
227148	Brafoneiras Lamelares do Tenente-comandante
227149	Capacete Lamelar do Tenente-comandante
227150	Guarda-pernas Lamelares do Capitão-cavaleiro
227151	Guarda-peito Lamelar do Capitão-cavaleiro
227152	Luvas Lamelares do Tenente-cavaleiro
227153	Grevas Lamelares do Tenente-cavaleiro
227154	Brafoneiras de Malha do Campeão
227155	Cimeira de Malha do Campeão
227156	Guarda-pernas de Malha do Legionário
227157	Cota de Malha do Legionário
227158	Grevas de Malha do Guarda-de-sangue
227159	Luvas de Malha do Guarda-de-sangue
227160	Espaldares de Malha do Campeão
227161	Perneiras de Malha do Legionário
227162	Elmo de Malha do Campeão
227163	Manoplas de Malha do Guarda-de-sangue
227164	Escarpes de Malha do Guarda-de-sangue
227165	Peitoral de Malha do Legionário
227166	Palas de Malha do Campeão
227167	Calças de Malha do Legionário
227168	Morrião de Malha do Campeão
227169	Luvas de Malha do Guarda-de-sangue
227170	Botas de Malha do Guarda-de-sangue
227171	Couraça de Malha do Legionário
227172	Omoplatas de Couro de Dragão do Tenente-comandante
227173	Cimeira de Couro de Dragão do Tenente-comandante
227174	Cimeira de Couro de Dragão do Campeão
227175	Omoplatas de Couro de Dragão do Campeão
227176	Peito d'Armas de Couro de Dragão do Capitão-cavaleiro
227177	Perneiras de Couro de Dragão do Legionário
227178	Perneiras de Couro de Dragão do Capitão-cavaleiro
227179	Peito d'Armas de Couro de Dragão do Legionário
227180	Guantes de Couro de Dragão do Guarda-de-sangue
227181	Botinas de Couro de Dragão do Guarda-de-sangue
227182	Botinas de Couro de Dragão do Tenente-cavaleiro
227183	Guantes de Couro de Dragão do Tenente-cavaleiro
227184	Espaldares de Couro de Dragão do Campeão
227185	Calças de Couro de Dragão do Legionário
227186	Elmo de Couro de Dragão do Campeão
227187	Luvas de Couro de Dragão do Guarda-de-sangue
227188	Botas de Couro de Dragão do Guarda-de-sangue
227189	Armadura de Couro de Dragão do Legionário
227190	Espaldares de Couro de Dragão do Tenente-comandante
227191	Calças de Couro de Dragão do Capitão-cavaleiro
227192	Elmo de Couro de Dragão do Tenente-comandante
227193	Luvas de Couro de Dragão do Tenente-cavaleiro
227194	Botas de Couro de Dragão do Tenente-cavaleiro
227195	Armadura de Couro de Dragão do Capitão-cavaleiro
227196	Túnica de Couro de Dragão do Capitão-cavaleiro
227197	Grevas de Couro de Dragão do Tenente-cavaleiro
227198	Manopla de Couro de Dragão do Tenente-cavaleiro
227199	Bacinete de Couro de Dragão do Tenente-comandante
227200	Guarda-pernas de Couro de Dragão do Capitão-cavaleiro
227201	Brafoneiras de Couro de Dragão do Tenente-comandante
227202	Túnica de Couro de Dragão do Legionário
227203	Grevas de Couro de Dragão do Guarda-de-sangue
227204	Manoplas de Couro de Dragão do Guarda-de-sangue
227205	Elmo de Couro de Dragão do Campeão
227206	Guarda-pernas de Couro de Dragão do Legionário
227207	Brafoneiras de Couro de Dragão do Campeão
227279	Aro do Magíster
227280	Criação das Sombras
227282	Anel da Neblina Funesta
227284	Elo da Fera
227285	Dinâmica Estrutural do Fluxo
227286	Rum Rumsey Aquecido com Creme
227337	Conjunto de Luvas e Cinto Felino
227338	Conjunto de Luvas e Cinto Astral
227339	Conjunto de Luvas e Cinto do Guardião
227340	Conjunto de Luvas e Cinto do Reparador
227341	Conjunto de Luvas e Cinto do Perseguidor
227342	Conjunto de Luvas e Cinto do Espreitador
227343	Conjunto de Luvas e Cinto Misericordioso
227344	Conjunto de Luvas e Cinto Radiante
227345	Conjunto Luvas e Cinto Divino
227346	Conjunto de Luvas e Cinto da Aurora
227347	Conjunto de Luvas e Cinto Crepuscular
227348	Conjunto de Luvas e Cinto da Empolgação
227349	Conjunto de Luvas e Cinto da Batalha
227350	Conjunto de Luvas e Cinto do Alívio
227351	Conjunto de Luvas e Cinto da Erupção
227352	Conjunto de Luvas e Cinto do Impacto
227353	Conjunto de Luvas e Cinto da Determinação
227354	Conjunto de Luvas e Cinto Corrompido
227355	Conjunto de Luvas e Cinto Perverso
227356	Conjunto de Luvas e Cinto Imóvel
227357	Conjunto de Luvas e Cinto Imbatível
227359	Conjunto de Botas, Pernas e Omoplatas Felino
227360	Conjunto de Botas, Pernas e Omoplatas Astral
227361	Conjunto de Botas, Pernas e Omoplatas do Guardião
227365	Conjunto de Botas, Pernas e Omoplatas do Reparador
227366	Conjunto de Botas, Pernas e Omoplatas do Perseguidor
227367	Conjunto de Botas, Pernas e Omoplatas do Espreitador
227368	Conjunto de Botas, Pernas e Omoplatas Misericordiosas
227369	Conjunto de Botas, Pernas e Omoplatas Radiante
227370	Conjunto de Botas, Pernas e Omoplatas Divino
227371	Conjunto de Botas, Pernas e Omoplatas da Aurora
227372	Conjunto de Botas, Pernas e Omoplatas Crepuscular
227373	Conjunto de Botas, Pernas e Omoplatas da Empolgação
227374	Conjunto de Botas, Pernas e Omoplatas da Batalha
227375	Conjunto de Botas, Pernas e Omoplatas do Alívio
227376	Conjunto de Botas, Pernas e Omoplatas da Erupção
227377	Conjunto de Botas, Pernas e Omoplatas do Impacto
227378	Conjunto de Botas, Pernas e Omoplatas da Determinação
227379	Conjunto de Botas, Pernas e Omoplatas Corrompido
227380	Conjunto de Botas, Pernas e Omoplatas Perverso
227381	Conjunto de Botas, Pernas e Omoplatas Imóvel
227382	Conjunto de Botas, Pernas e Omoplatas Imbatível
227383	Conjunto de Elmo e Peito d'Armas Felino
227384	Conjunto de Elmo e Peito d'Armas Astral
227385	Conjunto de Elmo e Peito d'Armas do Guardião
227387	Conjunto de Elmo e Peito d'Armas do Reparador
227388	Conjunto de Elmo e Peito d'Armas do Perseguidor
227389	Conjunto de Elmo e Peito d'Armas do Espreitador
227390	Conjunto de Elmo e Peito d'Armas Misericordioso
227391	Conjunto de Elmo e Peito d'Armas Radiante
227392	Conjunto de Elmo e Peito d'Armas Divino
227393	Conjunto de Elmo e Peito d'Armas da Aurora
227394	Conjunto de Elmo e Peito d'Armas do Crepúsculo
227395	Conjunto de Elmo e Peito d'Armas da Empolgação
227396	Conjunto de Elmo e Peito d'Armas da Batalha
227397	Conjunto de Elmo e Peito d'Armas do Alívio
227398	Conjunto de Elmo e Peito d'Armas da Erupção
227399	Conjunto de Elmo e Peito d'Armas do Impacto
227400	Conjunto de Elmo e Peito d'Armas da Determinação
227401	Conjunto de Elmo e Peito d'Armas Corrompido
227402	Conjunto de Elmo e Peito d'Armas Perverso
227403	Conjunto de Elmo e Peito d'Armas Imóvel
227404	Conjunto de Elmo e Peito d'Armas Imbatível
227444	Ídolo da Caçadora
227451	Signo de Envio
227454	Argola das Marés
227455	Brisa Oceânica
227456	Runa da Tempestade Carmesim
227530	Cinto Incandescente
227531	Braceletes Incandescentes
227532	Capuz Incandescente
227533	Luvas Incandescente
227534	Perneiras Incandescentes
227535	Veste Incandescente
227536	Botas Incandescentes
227537	Ombreiras Incandescentes
227549	Retalho de Pergaminho
227552	Pergaminho Retalhado
227658	Nota de Devoto da Sombra
227683	Sulfuras, a Mão de Ragnaros
227684	Martelo de Sulfuron
227685	Bisturi da Sombra Modificado
227686	Martelo de Guerra Ornado
227687	Dente de Ouro Favorito de Orthas
227688	Uivo Sangrento
227689	Armadura de Placa Parcialmente Digerida
227690	Pedra Rúnica Necrótica
227691	Lâmina de Hanna
227724	Comenda Manchada de Sangue
227727	Instruções: Martelo de Sulfuron
227728	Olho de Sulfuras
227730	Contrato da Irmandade do Tório
227743	Núcleo de Força Obsidiano
227745	Herança de Família
227746	Runa da Árvore do Mundo
227747	Registros de Família
227748	Diário do Sobrevivente
227749	Runa da Estrela Cadente
227750	Braceletes de Escama Derretida
227751	Cinto de Escama Derretida
227752	Omoplatas de Escama Derretida
227754	Perneiras de Escama Derretida
227755	Elmo de Escama Derretida
227756	Luvas de Escama Derretida
227757	Botas de Escama Derretida
227758	Peitoral de Escama Derretida
227759	Luvas do Núcleo Calcinado
227760	Braceletes do Núcleo Calcinado
227761	Cinto do Núcleo Calcinado
227762	Ombreiras do Núcleo Calcinado
227763	Perneiras do Núcleo Calcinado
227764	Elmo do Núcleo Calcinado
227765	Botas do Núcleo Calcinado
227766	Peitoral do Núcleo Calcinado
227767	Drusa de Ignolita
227768	Sumonírico
227796	Pergaminho Darnassiano Misterioso
227797	Pergaminho Darnassiano Decifrado
227801	Brasa das Terras do Fogo
227802	Monstro - Tocha
227803	Arnês de Urso de Guerra Atroz
227804	Bermuda de Urso de Guerra Atroz
227805	Ferocidade dos Presamatos
227807	Cinto Denso dos Presamatos
227808	Dragonas dos Presamatos Rústicas
227809	Soqueiras dos Presamatos Cravejadas
227810	Botas dos Presamatos Densas
227811	Defensor dos Presamatos
227812	Bolsa Medicinal de Pelurso
227813	Água Benta de Stratholme Potável
227814	Cinturão da Aurora Radiante
227815	Botinas da Aurora de Qualidade
227816	Botas Argênteas de Elite
227817	Luvas da Aurora Radiantes
227818	Dragonas Douradas da Aurora Chamejantes
227819	Dragonas Flamejantes da Aurora Abençoadas
227820	Braçadeiras Ferro Negro Temperadas
227821	Elmo Derretido Tocado pela Chama
227822	Botas de Cão do Núcleo Espessas
227823	Luvas do Núcleo Flamífero de Qualidade
227824	Elmo Ferro Negro Temperado
227825	Destruidor Ferro Negro Derretido
227826	Aniquilador Ferro Negro das Chamas
227827	Cinturão Encadeado Derretido
227828	Cinto do Andarilho da Lava
227829	Botas de Escama de Dragão Negro Endurecida
227830	Dragonas do Núcleo Flamífero de Qualidade
227831	Veste do Núcleo Flamífero de Qualidade
227832	Anistia Negra Temperada
227833	Glaive da Fúria Obsidiana
227834	Omoplatas Encadeadas Derretidas
227835	Manoplas Ferro Negro Temperadas
227836	Perneiras Ferro Negro Temperadas
227837	Cinto do Cão do Núcleo Espesso
227838	Manoplas Cromáticas Rutilantes
227839	Perneiras do Núcleo Flamífero de Qualidade
227840	Guarda Negra Implacável
227841	Botas Ferro Negro Temperadas
227842	Punho de Ébano
227843	Ocaso Aniquilador
227844	Bolsa de Runatrama Reforçada em Couro
227845	Retalhador de Arcanita Refinada
227847	Perneiras de Democerne
227848	Manoplas de Democerne
227849	Rifle de Atirador de Elite do Núcleo de Fogo
227850	Lâmina do Sábio do Arquimago
227851	Peitoral de Escama de Dragão Negro Endurecida
227852	Perneiras de Escama de Dragão Negro Endurecida
227853	Omoplatas de Escama de Dragão Negro Endurecida
227854	Manto Cambiante Primoroso
227857	Profanação
227858	Martelo dos Deuses Selvagens
227859	Omoplatas d'Alvorada Cintilantes
227860	Colete de Lunatrama Incandescente
227861	Veste de Lunatrama Incandescente
227862	Botas de Lunatrama Incandescente
227863	Diadema de Lunatrama Incandescente
227864	Perneiras de Lunatrama Incandescente
227865	Manoplas de Placa Abrasadoras da Técnica Oculta
227866	Omoplatas Vulcânicas Magistrais
227867	Perneiras Vulcânicas Magistrais
227868	Peitoral Vulcânico Magistral
227869	Manto Cromático Brilhante
227870	Manoplas da Tormenta
227871	Peitoral Ferro Negro Temperado
227872	Cimeira do Grande Chefe
227873	Omoplatas de Escama de Dragão Azul Polida
227874	Perneiras de Escama de Dragão Azul Polida
227875	Peitoral de Escama de Dragão Azul Polida
227876	Malha Invencível
227877	Molde: Perneiras de Escama de Dragão Verde Viva
227878	Manoplas de Escama de Dragão Verde Viva
227879	Peitoral de Escama de Dragão Verde Viva
227880	Martelo de Batalha Encantado com Primor
227881	Tranquilidade
227882	Cinturão da Percepção Arcana
227883	Avambraços do Voo Veloz
227884	Acerta-peito Mortal
227885	Manoplas da Fortaleza Maior
227886	Martelo Magistral da Tempestade do Piloto Aéreo
227887	Guardafria Endurecida
227888	Omoplatas de Elite Argênteas
227895	Molde: Dragonas Douradas da Aurora
227896	Molde: Botas Argênteas
227897	Molde: Omoplatas Argênteas
227898	Molde: Peitoral de Escama de Dragão Azul Polida
227899	Molde: Omoplatas de Escama de Dragão Azul Polida
227900	Molde: Perneiras de Escama de Dragão Verde Viva
227901	Instruções: Peitoral Ferro Negro Temperado
227902	Molde: Peitoral de Escama de Dragão Negro Endurecida
227903	Molde: Perneiras de Escama de Dragão Negro Endurecida
227904	Molde: Omoplatas de Escama de Dragão Negro Endurecida
227905	Instruções: Martelo Magistral da Tempestade do Piloto Aéreo
227906	Molde: Peitoral Vulcânico Magistral
227907	Molde: Omoplatas Vulcânicas Magistrais
227908	Molde: Perneiras Vulcânicas Magistrais
227909	Instruções: Manoplas de Placa Abrasadoras da Técnica Oculta
227910	Molde: Manto Cromático Brilhante
227911	Cabeça do Laceral Mão Negra
227912	Divindade Aplicada
227914	Glândula Pineal de Feruja
227915	Domínio do Duque
227921	Runa de Facas
227922	Runa do Espadachim
227923	Botinas d'Água
227924	Frasco Incomum
227925	Sinalizador de Hidráxis
227926	Coroação Hidraxiana
227927	Juramento do Mar
227928	Chave da Caixa de Ferramentas
227930	Chave do Cofre
227931	Pacote Escondido
227932	Pé-de-cabra Enferrujado
227934	Ira Chamejante
227935	Martelo do Thane Caído
227936	Anel de Diplomata
227937	Caixa Quebra-cabeça
227938	Estilhaço de Luz
227939	Estilhaço de Luz
227940	Espada do Grão-general
227941	Ceifa-almas
227947	Brafoneiras para Golem
227948	Machado de Batalha de Forjaversa
227952	Cota Encadeada do Gladiador Selvagem
227955	Elmo do Gladiador Selvagem
227956	Peitoral Causamortis
227957	Grevas do Gladiador Selvagem
227958	Fantasmalha
227959	Coxotes do Guardião Eterno
227960	Colosso Inexpugnável
227961	Guantes do Gladiador Selvagem
227962	Espinho Ígneo
227963	Lâmina Gravada em Sangue
227964	Kilt Luminar
227965	Botas Pluriarranque
227967	Fôlego Renovado
227970	Capa da Salamandra de Fogo
227971	Punhos Derretidos
227972	Explosão de Conhecimento
227973	Círculo de Fogo
227974	Martelo de Litomagma
227978	Pedra Magmus
227980	Vestes da Coroa Real
227981	Retaliador Deimoforja
227982	Báculo-guia da Sabedoria
227983	Selo de Ferro Negro
227984	Cetro Real de Thaurissan
227985	A Capa Nova do Imperador
227986	Munhequeiras do Renome
227987	Faixa da Grande Caçada
227988	Joia da Coroa
227990	Mão da Injustiça
227991	Inimigo de Ferro
227992	Escarpes do Cavaleiro da Morte
227993	Cabo de Ébano de Marduque
227994	Cajado Atacaveira
227996	Arco de Ossos Antigos
227997	Espada da Família Barov
227998	Botas de Malha Sangrenta
227999	Escarpes Ossomorte
228000	Guarda-peito Ossomorte
228001	Omoplatas Feitas de Pedra
228002	Cinturão Ossomorte
228003	Guarda-pernas de Malha Sangrenta
228004	Grevas Assolaventos
228005	Amarra de Andros
228006	Manoplas Ossomorte
228007	Corta-gárgulas
228008	Guarda-pernas Ossomorte
228009	Botas Necrópilas
228010	Dragonas Necrópilas
228011	Braceletes Necrópilos
228012	Cota de Malha Sangrenta
228013	Veste Necrópila
228014	Cinto de Malha Sangrenta
228015	Gadanhorror
228016	Anel Fracamente Irisado
228017	Calças Crânio Fumegante
228018	Perneiras Necrópilas
228019	Coração do Demônio
228020	Manoplas de Malha Sangrenta
228021	Bruxilâmina
228022	Dever do Diretor
228023	Abraço de Aline
228024	Presa Silente
228025	Peitoral da Lápide
228026	Lâmina de Bosquenero
228027	Decepador Gelâmina
228028	Lâmina de Necromancia
228029	Machado de Guerra da Lápide
228030	Machado Malicioso
228031	Luvas Nerumbra
228032	Elmo de Elo Ósseo
228033	Martelo do Poder Divino
228034	Mitenes Tremelicantes
228036	Garras da Morte
228037	Broquel Range-ossos
228038	Calças de Tramaférrea
228039	Tomo Enfeitiçado
228040	Perneiras Vultear
228041	Perneiras Placa da Ira
228042	Cinta de Detenção
228044	Perneiras da Voragem
228045	Anel Necromântico
228046	Anel da Dominação de Dom Mauricio
228047	Anel do Amálgama
228050	Arco do Sátiro
228051	Bastão de Canalização Quel'dorei
228052	Corta-onda
228053	Elmo Fervente
228054	Talismã da Tempestade
228055	Guarda-peito Energizado
228056	Facão do Diabo
228057	Anel de Potência Demoníaca
228058	Espaldares de Ferro Volumosos
228059	Omoplatas do Vigia do Covil
228060	Manto Heliotrópico
228061	Luvas Fagulhantes
228062	Capuz Perceptivo
228063	Vínculo de Lenhatorta
228064	Escudo do Observador
228065	Espaldares Ciclônicos
228066	Luvas de Tramaférrea
228067	Pingente de Mago Ancião
228068	Cinto do Trombadinha
228069	Coxotes Reforçados Sobrenaturais
228070	Cota Forjada pelos Ogros
228074	Mãos da Tentação
228075	Lança do Destino
228076	Anel de Fogo Ardente
228077	Galho Onírico
228078	Cálice Amaldiçoado
228079	Manto de Folhas
228080	Anel de Resina
228081	Toxigérmen Germinante
228082	Machado dos Brado Guerreiro
228083	Coração Arbóreo Crepuscular
228084	Extintor de Incêndio Miniaturizado
228085	Elo da Legião Refaseado
228086	Lâmina de Retalhador Remanufaturada
228087	Fita de Moebius Supercarregada de Prata
228088	Plaquinhas de Identificação do Operador de Retalhadores
228089	Espreitaluna Entalhado em Madeira
228090	Adaga Ritual Cenariana
228091	Botas Espinhentas
228092	Manto Druídico
228093	O Coração das Trevas
228094	Lâmina do Senhor do Medo
228100	Clâmide do Senhor do Fogo
228101	Pelego do Beemote
228102	Clâmide do Senescal
228103	Grevas do Nathrezim
228104	Vestes de Eluna
228105	Núcleo de Chama Inextinguível
228106	Escudo da Vida e Morte
228107	Arco Longo da Caçadora Caída
228108	Sombra do Uivo Sangrento
228109	Guarda-pernas do Sacrifício
228111	Máscara do Assassino de Deuses
228112	Brial do Pesadelo
228113	Abraço Gélido
228114	Instruções: Retalhador de Arcanita Refinada
228117	Instruções: Campeão de Arcanita Refinada
228118	Instruções: Manoplas da Fortaleza Maior
228119	Molde: Manoplas de Democerne
228120	Molde: Perneiras de Democerne
228121	Molde: Bolsa de Runatrama Reforçada em Couro
228122	O Núcleo Derretido
228123	Epifania Jubilante
228124	Epifania Onírica
228125	Campeão de Arcanita Refinada
228126	Epifania Aperitiva
228127	Munhequeiras da Instabilidade
228128	Martelo da Bigorna Negra
228129	Crânio da Chama Sombria
228130	Proteção Altruísta
228131	Proteção Altruísta
228132	Batata de morto-vivo
228133	Magma ou Lava?
228134	Atlas de Kalimdor Setentrional
228135	Um Estudo da Luz
228136	Cabum!
228137	Coração de Golemagg
228138	O Cavaleiro e a Senhora
228139	Punho do Devoto do Fogo
228140	Flagelo: ameaça morta-viva ou sociedade incompreendida?
228141	Introdução à Necromancia
228142	Terra e Fogo
228143	Espada de Chama Sombria
228144	Anotação Estranha
228145	Garra Direita de Magmadar
228146	Garra Esquerda de Magmadar
228147	Chifre de Magmadar
228160	Arauto da Fé
228162	Trapaça
228163	Broche da Prolemadre
228165	Zagaia do Mata-dragões
228166	Chave da Cidade
228168	Polidor Goblínico
228169	Ajustador de Atitude
228170	Remo Improvisado dos Mares do Sul
228171	Porta-moedas de Kezan
228172	Proteção de Ilusão Caninegro
228173	Incunábulo do Consagrado
228174	Incunábulo do Devoto
228175	Incunábulo da Diligência Sagrada
228176	Totem do Trovão
228177	Totem do Fogo em Fúria
228178	Totem da Vitalidade Terrena
228179	Totem das Planícies
228180	Ídolo do Enxame
228181	Ídolo do Sangramento (Felino)
228182	Ídolo do Sangramento (Urso)
228183	Ídolo do Bosque
228184	Varal Goblínico
228185	Garrafa Quebrada de Goblino Noir
228186	Aliança de Casamento Abandonada
228187	Varinha dos Mares do Sul
228188	Grampo de Cabelo de Prestor
228189	Dádiva de Gob
228190	Conhecimento dos Presamatos
228191	Rochedo Derretido Cintilante
228214	Monstro - Maça 2M, Força Incontrolável
228222	Manual de Bravura de Azeroth
228227	Scroll of Overwhelming Power
228229	Lâmina Afiada Obsidiana
228230	Martelo dos Titãs Refinado
228239	Veste do Poder Volátil
228240	Coxotes do Ardilante
228242	Anel Pesado de Ferro Negro
228243	Anel do Feitiço Poderoso
228244	Perneiras da Tempestade de Mana
228245	Calças de Escama de Salamandra
228246	Munhequeiras da Estabilidade
228247	Gargantilha do Esclarecimento
228248	Treme-terra
228249	Medalhão do Poder Estável
228250	Instruções: Manoplas da Fortaleza Maior
228251	Molde: Manoplas de Escama de Dragão Verde Vivas
228252	Marca do Atirador
228253	Escarpes do Pisabrasa
228254	Botas Temperadas no Magma
228255	Talismã do Poder Efêmero
228256	Cordão da Ignição de Mana
228257	Luvas Velhas de Couro do Núcleo
228258	Espaldares da Terra Profunda
228259	Grimório Rúnico de Fogo
228260	Manoplas da Guarda Ígnea
228261	Anel do Golpe Presto
228262	Choque Carmesim
228263	Punhal do Feiticeiro
228264	Martelo Petraura
228265	Lâmina da Brutalidade
228266	Disco do Perfurador
228267	Rasgatripas
228268	Selo do Arquimago
228269	Magespada Lazulicanto
228270	Lança-pipoco
228271	Cajado de Dominância
228272	Golpe Sombrio
228273	Golpeforte
228274	Elo da Cauterização
228275	Grevas Forjadas no Núcleo
228276	Molde: Manto Cambiante Feito com Maestria
228277	Dente de Cão-magma
228278	Draga de Lava com Isolamento Hipertérmico
228279	Omoplatas da Guarda de Fogo
228280	Manto à Prova de Fogo
228281	Luvas da Chama Hipnótica
228282	Faixa dos Segredos Sussurrados
228283	Espaldares do Crescimento Silvestre
228284	Munhequeiras do Voo Constante
228285	Elmo do Vivificador
228286	Anel de Accuria
228287	Elo de Sulfuras
228288	Gume Rasgaosso
228289	Gargantilha do Senhor do Fogo
228290	Manto Envolto em Brumas
228291	Coroa da Destruição
228292	Capa de Sangue de Dragão
228293	Essência da Chama Pura
228294	Defensor de Malistar
228295	Cinturão da Ofensiva
228296	Lâmina da Perdição
228297	Estilhaço da Chama
228298	Estilhaço da Escama
228299	Ceifa-espinhaço
228301	Molde: Avambraços do Voo Veloz
228303	Molde: Veste de Lunatrama Incandescente
228304	Diagrama: Rifle de Atirador de Elite do Núcleo de Fogo
228305	Instruções: Martelo dos Titãs Refinado
228306	Instruções: Profanação
228307	Instruções: Acerta-peito Mortal
228308	Instruções: Tranquilidade
228309	Molde: Peitoral de Escama de Dragão Verde Vivo
228310	Instruções: Guardafria Endurecida
228311	Instruções: Martelo de Batalha Encantado com Primor
228312	Instruções: Malha Invencível
228313	Instruções: Manoplas da Tormenta
228314	Instruções: Cimeira do Grande Chefe
228315	Instruções: Lâmina do Sábio do Arquimago
228316	Molde: Colete de Lunatrama Incandescente
228317	Molde: Diadema de Lunatrama Incandescente
228318	Molde: Perneiras de Lunatrama Incandescente
228319	Molde: Cinturão da Percepção Arcana
228323	Moeda da Chacina de Cobre
228324	Moeda da Chacina de Ouro
228325	Moeda da Chacina de Prata
228326	Algibeira de Moedas da Chacina de Cobre
228327	Algibeira de Moedas da Chacina de Prata
228332	Lok'delar, Báculo dos Guardiões Antigos
228334	Rhok'delar, Arco Longo dos Guardiões Antigos
228335	Bênção
228336	Anátema
228340	Cinturão de Gelo que não Derrete
228345	Perneiras da Supremacia Arcana
228347	Tufão
228349	Garra Esquerda de Eskhandar
228350	Garra Direita de Eskhandar
228351	Manoplas de Couro da Perdição
228352	Perneiras Infusas em Vileza
228353	Jaula Craniana Infernal
228354	Medalhão de Ardenfúria
228355	Cinto Esfolado de Demonarca
228356	Guardião do Selo Âmbar
228357	Braçadeiras Luz Negra
228359	Elo da Entropia
228360	Pelagem de Eskhandar
228381	Ruptura do Gelo
228382	Presa dos Místicos
228383	Capa Pujante
228384	Sapatos Ceganeve
228385	Coroa Adornada de Cristais
228389	Clâmide de Bênção
228397	Demolidor Empíreo
228410	Terroraço do Destruidor
228432	Apito da Fera
228459	Lâmina Afiada Obsidiana
228460	Ceifa-espinhaço
228461	Gume Rasgaosso
228462	Martelo Petraura
228463	Treme-terra
228464	Selo Real de Eldre'Thalas
228465	Selo Real de Eldre'Thalas
228466	Selo Real de Eldre'Thalas
228467	Selo Real de Eldre'Thalas
228468	Perneiras de Líquen Emaranhado
228469	Anel Élfico Manchado
228470	Perneiras de Luaprata
228471	Quebra-pedra
228472	Adaga de Distração
228473	Malho Inexorável
228474	Veste da Onda Mental
228475	Dragonas Diabólicas
228476	Cinto Ornado do Arquimago
228477	Molde: Cinto Ornado do Arquimago
228478	Lâmina Bárbara
228479	Perneiras da Destruição
228480	Coroa do Rei Ogro
228484	Bastão dos Magos Ogros
228486	Perdição do Arvoroso
228498	Terroraço do Destruidor
228500	Máscara do Imperdoável
228501	Blusa Ornicanto
228502	Flautim do Fogo Flamejante
228503	Tanga do Menestrel Saracoteante
228504	Cinturão do Arco-íris
228505	Manto do Tribunal Real
228506	Lâmina da Brutalidade
228508	Martelo da Bigorna Negra
228511	Lâmina da Perdição
228513	Avambraços do Sádico
228514	Galochas do Timmy
228515	Laço da Violência
228516	Pacificador
228517	Magespada Lazulicanto
228518	Manilhas do Magistrado
228519	Marca do Atirador
228520	Dragonas Roubalmas
228521	Mitenes de Renda Sombria
228522	Obus Portátil do Gualter
228523	Fura-bloqueio
228524	O Selo do Chefe do Correio
228525	A Túnica do Chefe do Correio
228527	As Calças do Chefe do Correio
228528	A Bandana do Chefe do Correio
228529	As Botinas do Chefe do Correio
228530	Guarda-pernas de Placa Quitinoso
228531	Faixa de Thuzadin
228532	Braçadeiras de Morlune
228533	Colar de Concha Iridescente
228534	Perneiras do Cão Pestilento
228535	Machadinha Corta-osso
228536	Estrela de Mystaria
228537	Manoplas Dracórias
228538	Marca de Rivendare
228539	Livro dos Mortos
228540	Coroa da Tirania
228541	Dádiva dos Magos Élficos
228542	Aniquilador Forjacrânio
228543	Lâmina Rúnica do Barão Rivendare
228544	Martelo do Grande Cruzado
228545	Elmo do Grão-cruzado
228546	Mortalha dos Nathrezim
228547	Veste de Tramaférrea
228548	Cetro da Concentração Interminável
228551	Túnica da Lua Crescente
228552	Manoplas de Destreza
228553	Elmo do Carrasco
228554	Luvas de Pele de Demônio
228555	Lâmina Fase
228556	Avental do Açougueiro
228557	Botas de Batalha Dardejantes
228558	Manilhas Funéreas
228559	Corvonegro
228561	Manoplas Miracerta
228562	Espaldares com Runas Demoníacas
228563	Globo de D'sak
228564	Botas do Vigia da Torre Ogra
228565	Anel do Mago
228566	Tiara do Fogo Estelar
228567	Cinturão do Cinzelador
228568	Manoplas Backorianas
228570	Punho de Omokk
228571	Peitoral do Rei Xamã
228572	Guarda-braços de Cernecúpreo
228573	Cospeçonha
228574	Talismã da Evasão
228575	Braçadeiras Garracortante
228576	Olho de Queimateia
228577	Manoplas Douradas
228578	Faixa Plumafina
228579	Cinturão Cristalizado
228583	Omoplatas Golpecerto
228584	Talismã Furiarrubra
228585	Marca do Senhor dos Dragões
228586	Cravija
228587	Cajado do Refúgio
228588	Garras do Gatuno
228589	Coração da Escama
228590	Dragonas do Fendevidente
228591	Protetor Rumbarbo
228592	Presa da Aranha de Cristal
228593	Botas do Dançarino dos Ventos
228594	Botas de Precisão do Kayser
228595	Cinturão do Atirador Perito
228596	Cinto de Tramaférrea
228597	Botas de Tramaférrea
228598	Braçadeiras de Tramaférrea
228599	Coração de Wyrmthalak
228600	Quebra-queixo
228601	Foice Implacável
228602	Pisa-chamas
228603	Serra Maldita do Mão Negra
228604	Olho de Laceral
228605	Ombreiras de Espetosso
228606	Lâmina Negra de Shahram
228615	Tesouro Sobrenatural
228650	Guarda-pernas do Mestre Guerreiro
228651	Braceleiras Belinato
228652	Guardião Tribal de Dal'Rend
228653	Encargo Sagrado de Dal'Rend
228659	Báculo Antigo Cinzelado com Runas
228660	Perneiras do Mestre de Espadas
228661	Guarda-pernas de Tristam
228662	Guarda-braços de Brumanegra
228663	Manto de Sangreluna
228664	Capa do Tecegelo
228666	Salgueiro Intruso
228667	Elo Tecemágoa
228669	Dente de Gnarr
228670	Cinturão de Brigam
228672	Cinturão Artesanal do Mestre Ferreiro
228675	Elo da Ruminação
228676	Cinturão Torrente Feral
228677	Turbante do Tecencantos
228678	Emblema Dracônico Infuso
228679	Quel'Serrar
228680	Compêndio do Abate de Dragões de Nostro
228681	Capucho de Tramaférrea
228682	Cajado de Comando do Senhor Valthalak
228683	Elo Rúnico da Bruxaria
228684	Pingente da Celeridade
228685	Pingente de Dente de Onyxia
228686	Talismã de Sangue de Onyxia
228687	Sinete do Mata-dragões
228688	Cabeça da Onyxia
228689	Cabeça da Onyxia
228690	A Luz e Como Ativá-la
228691	Garona: Um Estudo sobre Furtividade e Traição
228692	Códice de Defesa
228693	Livro de Receitas do Arcanista
228695	Lâmina Élfica Lisa e Cega
228696	Lâmina Ancestral Incandescente
228697	Lâmina Ancestral Temperada
228699	Anel do Logro Demoníaco
228700	Dragonas de Tramaférrea
228701	Dente de Cão-magma
228702	Disco do Perfurador
228703	Sapatilhas Petrálgida
228704	Capuz de Couro Esfarrapado
228722	Mão da Justiça
228746	Mecanostruz Verde Fluorescente
228747	Rédeas do Gato-de-sabre Dourado
228748	Apito do Raptor Sanguíneo Mosqueado
228749	Lasca de Nordrassil
228757	Adagavil
228759	Coleira de Eskhandar
228797	Grimório de Armadura Vil
228912	Chave do Depósito de Artefatos
228922	Cajado de Dominância
228924	Botas Ferro Negro Temperadas
228925	Botas Ferro Negro Temperadas
228926	Botas Ferro Negro Temperadas
228927	Botas Ferro Negro Temperadas
228928	Botas Ferro Negro Temperadas
228929	Botas Ferro Negro Temperadas
228955	Grimório Antigo da Pedra Angular
228978	Signo Encantado: Águas Abundantes
228979	Signo Encantado: Águas Abundantes
228980	Revestimento de Escudo Condutivo
228981	Fórmula: Revestimento de Escudo Condutivo
228982	Fórmula: Encantamento de Lei da Natureza - Escudo
228992	Mochila de Pelego da Onyxia
228993	Molde: Bolsa sem Fundo
228994	Bolsa sem Fundo
229008	Fórmula: Encantamento Maior de Resistência ao Fogo - Manto
229009	Fórmula: Encantamento Maior de Resistência à Natureza - Manto
229055	Seda Aranasi Puída
229056	Pedaço de Pedra-pomes
229057	Mercadorias Apreendidas
229352	Descobertas da Inteligência
229362	Chave do Armazém
229372	Rasgatripas
229373	Arauto da Fé
229374	Punho do Devoto do Fogo
229376	Punhal do Feiticeiro
229377	Garra Esquerda de Magmadar
229378	Garra Direita de Magmadar
229379	Garra Direita de Eskhandar
229380	Golpe Sombrio
229381	Golpeforte
229382	Draga de Lava com Isolamento Hipertérmico
229415	Suprimentos de Sobrevivência
229416	Pelo Quentinho
229749	Portadora da Verdade
229806	Portadora da Verdade
229894	Esmeralda Onírica
229897	Pergaminho: Criar Sinete Chamariz
229906	Escama de Bronze Maculado
229909	Cajado da Ordem
229910	Foice do Caos
229911	Comedor de Sonhos de Caius
229964	Casco do Lorde-Demônio
229965	O Olho de Az'olgothal
229966	Torque do Punho de Prata
229971	Cajado do Inferno
229972	Cajado da Geada
230002	Finalizador Mortal
230018	Fragmentos do Orbe de Mannoroc
230224	Tormentária, Lâmina Sagrada do Perseguidor dos Ventos
230237	Gema Arcana Infusa
230238	O Livro Preto
230239	Luvas da Rápida Evolução
230240	Dragonas do Conciliábulo do Asa Negra
230241	Quebra-espinha
230242	A Lâmina Indomável
230243	Gema do Pensapresto
230244	Signo do Metamorfo
230245	Pingente do Dragão Caído
230246	Elmo da Raiva Infinita
230247	Lâmina Dendragônia
230248	Protetor de Escama de Dragão Vermelho
230249	Gema da Vivificação
230250	Totem Peçonhento
230251	Brafoneiras de Couraça Preta
230252	Braçadeiras da Precisão Arcana
230253	Furapeito
230254	Maladath, Lâmina Rúnica da Revoada Negra
230255	Cinto de Couro de Dragão Retesado
230256	Brafoneiras de Garra de Draco
230257	Anel de Rocha Negra
230269	Gema Rejuvenescedora
230270	Cajado de Foco da Asa Sombria
230271	Cutelo de Garra de Draco
230272	Pergaminhos de Luz Cegante
230273	Cristal de Alinhamento Natural
230274	Veste Freixo Preto
230275	Amarra do Fogorja
230276	Garra do Draco Preto
230277	Manto do Fogorja
230278	Guarda-pernas do Cruzado Caído
230279	Guarda-pernas Articulados do Primalista
230280	Égide de Preservação
230281	Elo da Concentração Forçada
230282	Talismã de Presa de Draco
230723	Luvas da Chama Ebânea
230725	Baluarte Abençoado de Malfurion
230726	Carabina Bafo de Dragão
230733	Mortalha do Pensamento Puro
230734	Círculo da Força Aplicada
230735	Perneiras de Tecebrasa
230736	Escaravelho Iminente de Styleen
230737	Toque do Dragão
230738	Arauto do Sofrimento
230739	Garra da Angelista
230740	Ombreiras de Couro de Dragão Retesado
230741	Botas Cromáticas
230742	Luvas de Couro de Dragão Retesado
230743	Geta Cintilante
230744	Manto Tecido com Elemêntio
230745	Cinturão do Cruzado Caído
230746	Perneiras Carregadas
230747	Espada Temperada Cromaticamente
230751	Obi Ninja
230794	Garra de Cromaggus
230800	Cinta Articulada do Primalista
230801	Ashjre'thul, Besta da Punição
230802	Baluarte Reforçado de Elemêntio
230804	Manto do Senhor da Prole
230805	Botas da Chama Sombria
230806	Elo de Therazane
230808	Anel do Discernimento de Archimtiros
230810	Lágrima de Neltharion
230811	Elo de Elemêntio Puro
230812	Mish'undare, Diadema do Esfolador Mental
230813	Cajado da Chama Sombria
230818	Ashkandi, Montante da Irmandade
230837	Crul'shorukh, Beira do Caos
230838	Lok'amir il Romathis
230839	Anel do Mestre Mata-dragões
230840	Medalhão do Mestre Mata-dragões
230841	Orbe do Mestre Mata-dragões
230842	Manto do Poder Dracônico
230843	Botas do Pensamento Puro
230844	Marreta Dracônica
230845	Gume da Perdição
230846	Elo do Domínio Sombrio
230847	Coletador de Essências
230848	Gibão Entrelaçado das Sombras
230849	Botas da Nevasca do Ringo
230854	Anel de Servidão
230855	Selo do Berserker Gurubashi
230856	Cinto do Poder Libertado
230857	Máscara Ensanguentada
230858	Manto dos Adoradores Hakkari
230859	Luvas do Atormentado
230860	Poder da Tribo
230861	Manoplas Sacrificais
230862	Turbante Zulian
230863	Cetro Ritual Zulian
230864	Cota Rúnica Manchada de Sangue
230865	Presas de Venoxis
230866	Pisantes Banhados em Sangue
230867	Anel de Zanzil
230868	Martelo de Pedra Zulian
230903	Pergaminho: Essência do Fogo
230904	Pergaminho: ÊASSENIC OD OFOG
230908	Essência do Fogo Imbuída
230909	Essência do Fogo Esgotada
230911	Esmagador da Jeklik
230912	Espaldares do Animista
230913	Talismã de Opalina da Jeklik
230914	Botas do Pacificador
230915	Anel do Primalista
230916	Botas da Fúria dos Mares
230917	Vestes Rituais Esvoaçantes
230918	Toque da Mar'li
230919	Grevas Manchadas de Sangue
230920	Olho da Mar'li
230921	Anel de Jin
230922	Talismã de Proteção
230923	Botas do Traidor
230925	Soqueira do Thekal
230926	Perneiras do Pacificador
230927	Guarda-pernas Rituais
230928	Perneiras da Fúria dos Mares
230929	Selo de Jin
230930	Fatiador Zulian
230934	Soqueira da Arlokk
230939	Propósito de Arlokk
230941	Bastão Azarento da Arlokk
230942	Grevas Banhadas em Sangue
230943	Anel de Ônix do Lorde Supremo
230944	Bolsa de Pelego de Pantera
230946	Pergaminho: ÊASSENIC OD ELGO
230947	Pergaminho: Essência do Gelo
230948	Essência do Gelo Imbuída
230949	Essência do Gelo Esgotada
230984	Cajado da Ordem Incompleto
230989	Defensor do Sangrelorde
230991	Alabarda de Punição
230992	Lâmina de Guerra dos Hakkari
230993	Ferrão do Mandokir
230994	Perneiras do Animista
230995	Manoplas Banhadas em Sangue
230996	Brafoneiras Banhadas em Sangue
230997	Kilt Tinto de Sangue
230998	Manto do Loa Hakkari
230999	Anel Carmesim do Lorde Supremo
231000	Selo do Primalista
231001	Selo de Zanzil
231002	Martelo de Jin'do
231003	Mau Olhado de Jin'do
231004	Julgamento de Jin'do
231005	Saco de Sortilégios de Jin'do
231006	Botas do Animista
231007	Coifa Manchada de Sangue
231008	Coxotes Manchados de Sangue
231009	Perneiras Banhadas em Sangue
231010	Manoplas Banhadas em Sangue
231011	Luvas Tingidas de Sangue
231012	Abraço do Lorde Supremo
231013	Mantel do Bagateiro
231014	Tapa-olho de Escama de Lagarto
231015	Máscara de Sarja
231016	Exterminador de Peixes de Nat Pagle
231023	Munhequeiras da Ira
231024	Cinta da Ira
231025	Brafoneiras da Ira
231026	Guarda-pernas da Ira
231027	Viseira da Ira
231028	Protetores de Mão da Ira
231029	Escarpes da Ira
231030	Couraça da Ira
231031	Braçadeiras da Ira
231032	Cinto da Ira
231033	Omoplatas da Ira
231034	Coxotes da Ira
231035	Elmo da Ira
231036	Manoplas da Ira
231037	Grevas da Ira
231038	Peitoral da Ira
231039	Espaldares Dentessangue
231040	Peito d'Armas Dentessangue
231041	Botas Dentessangue
231042	Luvas Dentessangue
231043	Capuz Dentessangue
231044	Calças Dentessangue
231045	Cinto Dentessangue
231046	Braçadeiras Dentessangue
231047	Ombreiras Dentessangue
231048	Couraça Dentessangue
231049	Pisantes Dentessangue
231050	Protetores de Mão Dentessangue
231051	Capucho Dentessangue
231052	Guarda-pernas Dentessangue
231053	Cinta Dentessangue
231054	Munhequeiras Dentessangue
231055	Braçadeiras do Espreita-dragão
231056	Cinto do Espreita-dragão
231057	Espaldares do Espreita-dragão
231058	Guarda-pernas do Espreita-dragão
231059	Elmo do Espreita-dragão
231060	Manoplas do Espreita-dragão
231061	Grevas do Espreita-dragão
231062	Peitoral do Espreita-dragão
231063	Avambraços do Espreita-dragão
231065	Cinturão do Espreita-dragão
231066	Brafoneiras do Espreita-dragão
231067	Calças do Espreita-dragão
231068	Morrião do Espreita-dragão
231069	Guantes do Espreita-dragão
231070	Escarpes do Espreita-dragão
231071	Armadura do Espreita-dragão
231072	Botas da Nêmesis
231073	Luvas da Nêmesis
231074	Casquete da Nêmesis
231075	Perneiras da Nêmesis
231076	Vestes da Nêmesis
231077	Espaldares da Nêmesis
231078	Cinto da Nêmesis
231079	Braçadeiras da Nêmesis
231090	Botinas da Nêmesis
231091	Protetores de Mão da Nêmesis
231092	Capucho da Nêmesis
231093	Calças da Nêmesis
231095	Induto da Nêmesis
231096	Ombreiras da Nêmesis
231097	Cordão da Nêmesis
231098	Munhequeiras da Nêmesis
231100	Cinto do Vento Etéreo
231101	Botas do Vento Etéreo
231102	Luvas do Vento Etéreo
231103	Coroa do Vento Etéreo
231104	Calças do Vento Etéreo
231105	Vestes do Vento Etéreo
231106	Dragonas do Vento Etéreo
231107	Braçadeiras do Vento Etéreo
231108	Faixa do Vento Etéreo
231109	Sapatilhas do Vento Etéreo
231110	Luvetes do Vento Etéreo
231111	Máscara do Vento Etéreo
231112	Perneiras do Vento Etéreo
231113	Vestimenta do Vento Etéreo
231114	Omoplatas do Vento Etéreo
231115	Munhequeiras do Vento Etéreo
231155	Botas da Transcendência
231156	Protetores de Mão da Transcendência
231157	Halo da Transcendência
231158	Perneiras da Transcendência
231159	Vestes da Transcendência
231160	Brafoneiras da Transcendência
231161	Cinto da Transcendência
231162	Braçadeiras da Transcendência
231165	Botinas da Transcendência
231166	Luvas da Transcendência
231167	Coroa da Transcendência
231168	Calças da Transcendência
231169	Induto da Transcendência
231170	Dragonas da Transcendência
231171	Cordão da Transcendência
231172	Braçadeiras da Transcendência
231174	Braçadeiras do Julgamento
231175	Cinto do Julgamento
231176	Espaldares do Julgamento
231177	Coxotes do Julgamento
231178	Coroa do Julgamento
231179	Manoplas do Julgamento
231180	Escarpes do Julgamento
231181	Peitoral do Julgamento
231182	Avambraços do Julgamento
231183	Cinta do Julgamento
231184	Brafoneiras do Julgamento
231185	Guarda-pernas de Mão do Julgamento
231186	Grande Elmo do Julgamento
231187	Couraça do Julgamento
231188	Protetores de Mão do Julgamento
231189	Grevas do Julgamento
231190	Braçadeiras do Julgamento
231191	Cinturão do Julgamento
231192	Dragonas do Julgamento
231193	Saiote de Placas do Julgamento
231194	Elmo do Julgamento
231195	Luvas do Julgamento
231196	Botinas do Julgamento
231197	Corselete do Julgamento
231198	Manoplas das Dez Tempestades
231199	Braçadeiras das Dez Tempestades
231200	Cinto das Dez Tempestades
231201	Palas das Dez Tempestades
231202	Coxotes das Dez Tempestades
231203	Capacete das Dez Tempestades
231204	Grevas das Dez Tempestades
231205	Peitoral das Dez Tempestades
231206	Protetores de Mão das Dez Tempestades
231207	Munhequeiras das Dez Tempestades
231208	Cinta das Dez Tempestades
231209	Brafoneiras das Dez Tempestades
231210	Guarda-pernas das Dez Tempestades
231211	Viseira das Dez Tempestades
231212	Escarpes das Dez Tempestades
231213	Couraça das Dez Tempestades
231214	Luvas das Dez Tempestades
231215	Braceletes das Dez Tempestades
231216	Cordão das Dez Tempestades
231217	Dragonas das Dez Tempestades
231218	Kilt das Dez Tempestades
231219	Cocar das Dez Tempestades
231220	Botas das Dez Tempestades
231221	Abraço das Dez Tempestades
231222	Guantes das Dez Tempestades
231223	Avambraços das Dez Tempestades
231224	Cinturão das Dez Tempestades
231225	Espaldares das Dez Tempestades
231226	Perneiras das Dez Tempestades
231227	Coroa das Dez Tempestades
231228	Botinas das Dez Tempestades
231229	Armadura das Dez Tempestades
231230	Couraça Tempesfúria
231231	Botas Tempesfúria
231232	Protetores de Mão Tempesfúria
231233	Mantel Tempesfúria
231234	Guarda-pernas Tempesfúria
231235	Brafoneiras Tempesfúria
231236	Cinto Tempesfúria
231237	Braçadeiras Tempesfúria
231238	Armadura Tempesfúria
231239	Botinas Tempesfúria
231240	Manoplas Tempesfúria
231241	Cocar Tempesfúria
231242	Perneiras Tempesfúria
231243	Espaldares Tempesfúria
231244	Cinta Tempesfúria
231245	Munhequeiras Tempesfúria
231246	Couros Tempesfúria
231247	Sandálias Tempesfúria
231248	Luvetes Tempesfúria
231249	Galhadura Tempesfúria
231250	Kilt Tempesfúria
231251	Dragonas Tempesfúria
231252	Cordão Tempesfúria
231253	Braceletes Tempesfúria
231254	Colete Tempesfúria
231255	Pisoteadores Tempesfúria
231256	Guantes Tempesfúria
231257	Capucho Tempesfúria
231258	Calçotes Tempesfúria
231259	Ombreiras Tempesfúria
231260	Faixa Tempesfúria
231261	Munhequeiras Tempesfúria
231271	Carretel Quebrado do Nat Pagle
231272	Arpão de Tigule
231273	Buril do Gri'lek
231274	Triturador do Gri'lek
231275	Vingador Ardenfúria
231276	O Destruidor de Pensamentos
231277	Forcado da Loucura
231278	Arco de Caça Azarento
231279	Atiçador de Vuxulai
231280	Patuá Natural de Vuxulai
231281	Patuá Espiritual de Vuxulai
231282	Patuá de Magia Gelada de Hazza'rah
231283	Patuá de Proteção de Hazza'rah
231284	Patuá Destruidor de Hazza'rah
231285	Patuá Valoroso de Gri'lek
231286	Patuá do Poder de Gri'lek
231287	Patuá Ardiloso de Renataki
231288	Patuá Devastador de Renataki
231289	Égide do Deus Sangrento
231293	Antigo Matador de Homens Hakkari
231296	Chama-sangue
231298	Pergaminho da Recomposição Espacial Inferior
231299	Coxotes Banhados em Sangue
231300	Manto da Consumição
231301	Presas dos Sem-rosto
231302	Destruidor Gurubashi de Anões
231303	Manoplas do Pacificador
231304	Pergaminho: CAÇOPEROIMOS SELAPCIA ORFERINI
231305	Manoplas da Fúria dos Mares
231306	Colar do Corruptor de Almas
231307	Olho de Hakkar
231308	Toque do Caos
231309	Lâmina de Guerra dos Hakkari
231315	Zin'rokh, a Destruidora de Mundos
231316	Alga Encantada dos Mares do Sul Imaculada
231317	Túnica do Harúspice Zandalar
231318	Cinto do Harúspice Zandalar
231319	Braçadeiras do Harúspice Zandalar
231320	Ira da Voragem
231321	Dragonas do Predador Zandalar
231322	Cinto do Predador Zandalar
231323	Braçadeiras do Predador Zandalar
231324	Joia de Jakaro
231325	Dragonas do Ilusionista Zandalar
231326	Bracelete do Ilusionista Zandalar
231327	Veste do Ilusionista Zandalar
231328	Marca do Herói
231329	Peitoral do Livre-pensador Zandalar
231330	Cinto do Livre-pensador Zandalar
231331	Braçadeiras do Livre-pensador Zandalar
231332	Olho-que-tudo-vê de Zuldazar
231333	Dragonas do Confessor Zandalar
231334	Cinturão do Confessor Zandalar
231335	Braçadeiras do Confessor Zandalar
231336	Talismã Zandalariano de Domínio das Sombras
231337	Túnica do Lunático Zandalar
231338	Dragonas do Lunático Zandalar
231339	Braçadeiras do Lunático Zandalar
231340	Visão Imaculada de Vodúria
231341	Cota do Áugure Zandalar
231342	Cinto do Áugure Zandalar
231343	Braçadeiras do Áugure Zandalar
231346	Mácula Irrefreável de Kezan
231347	Braçadeiras do Demoníaco Zandalar
231348	Veste do Demoníaco Zandalar
231349	Dragonas do Demoníaco Zandalar
231350	Raiva de Mugamba
231351	Braçadeiras do Vindicante Zandalar
231352	Cinto do Vindicante Zandalar
231353	Peitoral do Vindicante Zandalar
231354	Carícia do Animista
231355	Equilíbrio do Animista
231357	Fúria do Animista
231358	Rugido do Animista
231359	Chamado do Falcão
231361	Selo do Sincretista
231362	Signo do Sincretista
231363	Brasão do Sincretista
231364	Emblema do Sincretista
231366	Aura Profética
231367	Maldição Profética
231368	Abraço da Morte
231370	Avanço da Morte
231371	Abraço do Voduzeiro
231372	Mortalha do Voduzeiro
231373	Patuá do Voduzeiro
231375	Vigilância do Voduzeiro
231376	Mandinga Azarenta
231377	Maldição Azarenta
231378	Disco Dourado Cintilante
231379	Presença de Poder
231381	Presença da Bravura
231382	Casulo de Renascimento
231383	Presença de Visão
231384	Fúria do Falcão
231385	Simulacro da Alma Dragônica
231386	Escama de Dragão Negro Impecável
231387	Ira-da-tempestade, Espadim Santificado do Perseguidor de Vendavais
231452	Sangue do Arauto da Luz
231460	Quebraplanos de Azgaloth
231466	Códice do Bruxo Asa Negra
231509	Tomo de Cassandra
231512	Ídolo Hakkari Primevo
231513	Sangue de Gri'lek
231514	Dente de Renataki
231515	Juba de Vuxulai
231516	Fio dos Sonhos de Hazza'rah
231517	Boneca Vodu Perfurada
231518	Boneca Vodu Perfurada
231519	Boneca Vodu Perfurada
231520	Boneca Vodu Perfurada
231521	Boneca Vodu Perfurada
231522	Boneca Vodu Perfurada
231523	Boneca Vodu Perfurada
231524	Boneca Vodu Perfurada
231525	Boneca Vodu Perfurada
231530	Armadura de Placa do Senhor da Guerra
231531	Botas de Placa do General
231532	Manoplas de Placa do General
231533	Perneiras de Placa do General
231534	Omoplatas de Placa do Senhor da Guerra
231535	Bacinete de Placa do Senhor da Guerra
231536	Armadura de Placa do Marechal-de-campo
231537	Guarda-ombros de Placa do Marechal-de-campo
231538	Elmo de Placa do Marechal-de-campo
231539	Botas de Placa do Marechal
231540	Guarda-pernas de Placa do Marechal
231541	Manoplas de Placa do Marechal
231543	Peito d'Armas de Couro do Marechal-de-campo
231544	Guantes de Couro do Marechal
231545	Máscara de Couro do Marechal-de-campo
231546	Guarda-pés de Couro do Marechal
231547	Palas de Couro do Marechal-de-campo
231548	Perneiras de Couro do Marechal
231549	Peitoral de Couro do Senhor da Guerra
231551	Espaldares de Couro do Senhor da Guerra
231552	Botinas de Couro do General
231553	Elmo de Couro do Senhor da Guerra
231554	Guarda-pernas de Couro do General
231555	Luvas de Couro do General
231557	Brafoneiras Encadeadas do Marechal-de-campo
231558	Coxotes Encadeados do Marechal
231560	Guantes Encadeados do Marechal
231561	Escarpes Encadeados do Marechal
231562	Grande Elmo Encadeado do Marechal-de-campo
231563	Armadura Encadeada do Marechal-de-campo
231564	Escarpes Encadeados do General
231565	Brafoneiras Encadeadas do Senhor da Guerra
231566	Armadura Encadeada do Senhor da Guerra
231567	Coxotes Encadeados do General
231568	Grande Elmo Encadeado do Senhor da Guerra
231569	Guantes Encadeados do General
231570	Grevas Encadeadas do General
231571	Elmo Encadeado do Senhor da Guerra
231572	Omoplatas Encadeadas do Senhor da Guerra
231573	Cota Encadeada do Senhor da Guerra
231574	Guarda-pernas Encadeados do General
231575	Luvas Antiderrapantes Encadeadas do General
231576	Omoplatas Encadeadas do Marechal-de-campo
231577	Guarda-pernas Encadeados do Marechal
231578	Luvas Antiderrapantes Encadeadas do Marechal
231579	Grevas Encadeadas do Marechal
231580	Elmo Encadeado do Marechal-de-campo
231581	Cota Encadeada do Marechal-de-campo
231582	Veste de Medotrama do Marechal-de-campo
231583	Omoplatas de Medotrama do Marechal-de-campo
231584	Diadema do Marechal-de-campo
231585	Botas de Medotrama do Marechal
231586	Luvas de Medotrama do Marechal
231587	Perneiras de Medotrama do Marechal
231588	Calças de Medotrama do General
231589	Luvas de Medotrama do General
231590	Capuz de Medotrama do Senhor da Guerra
231591	Veste de Medotrama do Senhor da Guerra
231592	Dragonas de Medotrama do Senhor da Guerra
231593	Botas de Medotrama do General
231594	Sobreveste de Seda do Senhor da Guerra
231595	Calças de Seda do General
231596	Traje de Seda do Senhor da Guerra
231597	Botas de Seda do General
231598	Luvas de Seda do General
231599	Manoplas de Seda do General
231600	Mitenes de Seda do General
231601	Capucho de Seda do Senhor da Guerra
231602	Espaldares de Seda do Marechal-de-campo
231603	Vestimenta de Seda do Marechal-de-campo
231604	Coroa do Marechal-de-campo
231605	Perneiras de Seda do Marechal
231606	Palmilhas de Seda do Marechal
231607	Luvas de Seda do Marechal
231608	Manoplas de Seda do Marechal
231609	Mitenes de Seda do Marechal
231610	Botinas de Cetim do General
231611	Palas de Cetim do Senhor da Guerra
231612	Vestes de Cetim do Senhor da Guerra
231613	Guantes de Cetim do General
231614	Perneiras de Cetim do General
231615	Coroa de Cetim do Senhor da Guerra
231616	Coroa de Cetim do Marechal-de-campo
231617	Guantes de Cetim do Marechal
231618	Veste de Cetim do Marechal-de-campo
231619	Perneiras de Cetim do Marechal
231620	Botinas de Cetim do Marechal
231621	Palas de Cetim do Marechal-de-campo
231622	Capuz de Cetim do Marechal-de-campo
231623	Mitenes de Cetim do Marechal
231624	Túnica de Cetim do Marechal-de-campo
231626	Guarda-pernas de Cetim do Marechal
231627	Chancas de Cetim do Marechal
231628	Dragonas de Cetim do Marechal-de-campo
231630	Chancas de Cetim do General
231631	Dragonas de Cetim do Senhor da Guerra
231632	Túnica de Cetim do Senhor da Guerra
231633	Mitenes de Cetim do General
231634	Guarda-pernas de Cetim do General
231635	Capuz de Cetim do Senhor da Guerra
231639	Guarda-pernas Lamelares do Marechal
231640	Capacete Lamelar do Marechal-de-campo
231641	Guarda-peito Lamelar do Marechal-de-campo
231642	Bolsa de Herborismo do Vigilante
231643	Luvas Lamelares do Marechal
231644	Bolsa de Encantamento do Vigilante
231645	Brafoneiras Lamelares do Marechal-de-campo
231646	Grevas Lamelares do Marechal
231647	Perneiras Lamelares do Marechal
231648	Cimeira Lamelar do Marechal-de-campo
231649	Peitoral Lamelar do Marechal-de-campo
231650	Manoplas Lamelares do Marechal
231651	Omoplatas Lamelares do Marechal-de-campo
231652	Escarpes Lamelares do Marechal
231653	Cota de Malha do Senhor da Guerra
231654	Brafoneiras de Malha do Senhor da Guerra
231655	Luvas Antiderrapantes de Malha do General
231656	Grevas de Malha do General
231657	Cimeira de Malha do Senhor da Guerra
231658	Guarda-pernas de Malha do General
231659	Espaldares de Malha do Senhor da Guerra
231660	Manoplas de Malha do General
231661	Escarpes de Malha do General
231662	Peitoral de Malha do Senhor da Guerra
231663	Elmo de Malha do Senhor da Guerra
231664	Perneiras de Malha do General
231665	Palas de Malha do Senhor da Guerra
231666	Luvas de Malha do General
231667	Botas de Malha do General
231668	Couraça de Malha do Senhor da Guerra
231669	Morrião de Malha do Senhor da Guerra
231670	Calças de Malha do General
231671	Grevas de Couro de Dragão do General
231672	Brafoneiras de Couro de Dragão do Senhor da Guerra
231673	Guarda-pernas de Couro de Dragão do General
231674	Túnica de Couro de Dragão do Senhor da Guerra
231675	Cocar de Couro de Dragão do Senhor da Guerra
231676	Manoplas de Couro de Dragão do General
231677	Luvas de Couro de Dragão do General
231678	Elmo de Couro de Dragão do Senhor da Guerra
231679	Armadura de Couro de Dragão do Senhor da Guerra
231680	Calças de Couro de Dragão do General
231681	Espaldares de Couro de Dragão do Senhor da Guerra
231682	Botas de Couro de Dragão do General
231683	Botinas de Couro de Dragão do General
231684	Omoplatas de Couro de Dragão do Senhor da Guerra
231685	Perneiras de Couro de Dragão do General
231686	Peito d'Armas de Couro de Dragão do Senhor da Guerra
231687	Cimeira de Couro de Dragão do Senhor da Guerra
231688	Guantes de Couro de Dragão do General
231689	Cimeira de Couro de Dragão do Marechal-de-campo
231690	Peito d'Armas de Couro de Dragão do Marechal-de-campo
231691	Perneiras de Couro de Dragão do Marechal
231692	Botinas de Couro de Dragão do Marechal
231693	Omoplatas de Couro de Dragão do Marechal-de-campo
231694	Guantes de Couro de Dragão do Marechal
231695	Elmo de Couro de Dragão do Marechal-de-campo
231696	Armadura de Couro de Dragão do Marechal-de-campo
231697	Calças de Couro de Dragão do Marechal
231698	Botas de Couro de Dragão do Marechal
231699	Espaldares de Couro de Dragão do Marechal-de-campo
231700	Luvas de Couro de Dragão do Marechal
231701	Cocar de Couro de Dragão do Marechal-de-campo
231702	Túnica de Couro de Dragão do Marechal-de-campo
231703	Guarda-pernas de Couro de Dragão do Marechal
231704	Grevas de Couro de Dragão do Marechal
231705	Brafoneiras de Couro de Dragão do Marechal-de-campo
231706	Manoplas de Couro de Dragão do Marechal
231707	Braceletes Draconianos
231708	Cinto Draconiano
231709	Ombreiras Draconianas
231710	Perneiras Draconianas
231711	Capuz Draconiano
231712	Luvas Draconianas
231713	Botas Draconianas
231714	Veste Draconiana
231715	Braceletes Primevos
231716	Cinto Primevo
231717	Ombreiras Primevas
231718	Perneiras Primevas
231719	Elmo Primevo
231720	Luvas Primevas
231721	Botas Primevas
231722	Foice do Caos Esgotada
231723	Baú Primevo
231724	Braceletes Antigos
231725	Cinto Antigo
231726	Ombreiras Antigas
231727	Perneiras Antigas
231728	Elmo Antigo
231729	Luvas Antigas
231730	Botas Antigas
231731	Baú Antigo
231732	Suprimentos Suspeitos
231752	T3 - Monstro - Espada, Aliança de 2M
231753	Consolo da Muralha Celeste
231754	Francelho
231755	Peregrino
231777	Membro de Qiraji Cristalizado
231778	Água da Fonte Montanhosa
231779	Ira de Wray
231780	Tomo de Conjurar Água VIII
231781	Alma do Trovão
231782	Coroa do Sucessor
231783	Clâmide do Senhor do Vento
231784	Célula de Raios
231785	Ecos da Traição
231789	Signo do Guardião
231792	Alma de Diabrura
231793	Foice do Caos Esgotada (Diabrura)
231794	Foice do Caos Esgotada (Caos)
231795	Foice do Caos Esgotada (Enfeitiçamento)
231796	Foice do Caos Esgotada (Devoração)
231797	Alma do Caos
231798	Alma de Enfeitiçamento
231799	Alma de Devoração
231800	Alma de Des'Altek
231803	Talismã da Conspiração do Prestor
231806	Flecha Calcinante
231807	Tiro Calcinante
231811	Incunábulo da Estupefação
231814	Coração Cromático
231815	Lancelesto
231817	Golpe de Vento
231823	Glaive de Geddon
231828	Runa de Especialização em Meditação
231829	Runa de Especialização em Cura
231836	Pergaminho da Recomposição Espacial Chamejante
231837	Entalhe Sombrio
231841	Sangue do Arauto da Luz
231842	Báculo de Nandieb
231843	Primeiro Fragmento de Signo
231844	Segundo Fragmento de Signo
231845	Terceiro Fragmento de Signo
231846	Buril do Gri'lek
231847	Triturador do Gri'lek
231848	Exterminador de Peixes de Nat Pagle
231849	Arpão de Tigule
231850	Propósito de Arlokk
231851	Soqueira da Arlokk
231852	Destruidor Gurubashi de Anões
231853	Lâmina de Guerra dos Hakkari
231854	Zin'rokh, a Destruidora de Mundos
231855	Presas dos Sem-rosto
231856	Antigo Matador de Homens Hakkari
231857	Toque do Caos
231858	Chama-sangue
231859	Martelo de Jin'do
231860	Julgamento de Jin'do
231861	Esmagador da Jeklik
231862	Vingador Ardenfúria
231863	Destruidora de Pensamentos
231864	Forcado da Loucura
231865	Cetro Ritual Zulian
231866	Toque da Mar'li
231867	Defensor do Sangrelorde
231868	Ferrão do Mandokir
231869	Lâmina de Guerra dos Hakkari
231870	Alabarda de Punição
231871	Atiçador de Vuxulai
231872	Arco de Caça Azarento
231873	Martelo de Pedra Zulian
231874	Presas de Venoxis
231875	Soqueira do Thekal
231876	Fatiador Zulian
231882	Recibo do Dispositivo de Supressão
231885	Gélido Lamento
231890	Terrestris
231891	Tratado do Falcão
231901	Portador da Verdade
231902	Amuleto de Aida
231903	Pedaço de Tecido Rasgado
231904	Trompa Maculada
231909	Luz Estelar Cristalizada
231910	Coração de Azgaloth
231911	Sinete do General da Legião
231912	Lâmina do Abismo
231913	Olho do Observador
231995	Escória de Elemêntio Endurecida
231996	Gobmogrificador Supercarregado
232018	Lâmina Latente Beijada pelo Vento
232079	Braceletes Tempesfúria
232080	Cordão Tempesfúria
232081	Dragonas Tempesfúria
232082	Kilt Tempesfúria
232083	Galhadura Tempesfúria
232084	Luvetes Tempesfúria
232085	Sandálias Tempesfúria
232086	Couros Tempesfúria
232087	Braçadeiras Tempesfúria
232088	Cinto Tempesfúria
232089	Brafoneiras Tempesfúria
232090	Guarda-pernas Tempesfúria
232091	Mantel Tempesfúria
232092	Protetores de Mão Tempesfúria
232093	Botas Tempesfúria
232094	Couraça Tempesfúria
232095	Munhequeiras Tempesfúria
232096	Faixa Tempesfúria
232097	Ombreiras Tempesfúria
232098	Calçotes Tempesfúria
232099	Capucho Tempesfúria
232100	Guantes Tempesfúria
232101	Pisoteadores Tempesfúria
232102	Colete Tempesfúria
232103	Munhequeiras Tempesfúria
232104	Cinta Tempesfúria
232105	Espaldares Tempesfúria
232106	Perneiras Tempesfúria
232107	Cocar Tempesfúria
232108	Manoplas Tempesfúria
232109	Botinas Tempesfúria
232110	Armadura Tempesfúria
232111	Avambraços do Espreita-dragão
232112	Cinturão do Espreita-dragão
232113	Brafoneiras do Espreita-dragão
232114	Calças do Espreita-dragão
232115	Morrião do Espreita-dragão
232116	Guantes do Espreita-dragão
232117	Escarpes do Espreita-dragão
232118	Armadura do Espreita-dragão
232119	Braçadeiras do Espreita-dragão
232120	Cinto do Espreita-dragão
232121	Espaldares do Espreita-dragão
232122	Guarda-pernas do Espreita-dragão
232123	Elmo do Espreita-dragão
232124	Manoplas do Espreita-dragão
232125	Grevas do Espreita-dragão
232126	Peitoral do Espreita-dragão
232127	Braçadeiras do Vento Etéreo
232128	Cinto do Vento Etéreo
232129	Dragonas do Vento Etéreo
232130	Calças do Vento Etéreo
232131	Coroa do Vento Etéreo
232132	Luvas do Vento Etéreo
232133	Botas do Vento Etéreo
232134	Vestes do Vento Etéreo
232135	Munhequeiras do Vento Etéreo
232136	Faixa do Vento Etéreo
232137	Omoplatas do Vento Etéreo
232138	Perneiras do Vento Etéreo
232139	Máscara do Vento Etéreo
232140	Luvetes do Vento Etéreo
232141	Sapatilhas do Vento Etéreo
232142	Vestimenta do Vento Etéreo
232143	Braçadeiras do Julgamento
232144	Cinto do Julgamento
232145	Espaldares do Julgamento
232146	Coxotes do Julgamento
232147	Coroa do Julgamento
232148	Manoplas do Julgamento
232149	Escarpes do Julgamento
232150	Peitoral do Julgamento
232151	Braçadeiras do Julgamento
232152	Cinturão do Julgamento
232153	Dragonas do Julgamento
232154	Saiote de Placas do Julgamento
232155	Elmo do Julgamento
232156	Luvas do Julgamento
232157	Botinas do Julgamento
232158	Corselete do Julgamento
232159	Avambraços do Julgamento
232160	Cinta do Julgamento
232161	Brafoneiras do Julgamento
232162	Guarda-pernas de Mão do Julgamento
232163	Grande Elmo do Julgamento
232164	Protetores de Mão do Julgamento
232165	Grevas do Julgamento
232166	Couraça do Julgamento
232167	Braçadeiras da Transcendência
232168	Cordão da Transcendência
232169	Dragonas da Transcendência
232170	Calças da Transcendência
232171	Coroa da Transcendência
232172	Luvas da Transcendência
232173	Botinas da Transcendência
232174	Induto da Transcendência
232175	Braçadeiras da Transcendência
232176	Cinto da Transcendência
232177	Brafoneiras da Transcendência
232178	Perneiras da Transcendência
232179	Halo da Transcendência
232180	Protetores de Mão da Transcendência
232181	Botas da Transcendência
232182	Vestes da Transcendência
232183	Braçadeiras Dentessangue
232184	Cinto Dentessangue
232185	Espaldares Dentessangue
232186	Calças Dentessangue
232187	Capuz Dentessangue
232188	Luvas Dentessangue
232189	Botas Dentessangue
232190	Peito d'Armas Dentessangue
232191	Munhequeiras Dentessangue
232192	Cinta Dentessangue
232193	Ombreiras Dentessangue
232194	Guarda-pernas Dentessangue
232195	Capucho Dentessangue
232196	Protetores de Mão Dentessangue
232197	Pisantes Dentessangue
232198	Couraça Dentessangue
232199	Braceletes das Dez Tempestades
232200	Cordão das Dez Tempestades
232201	Dragonas das Dez Tempestades
232202	Kilt das Dez Tempestades
232203	Cocar das Dez Tempestades
232204	Luvas das Dez Tempestades
232205	Botas das Dez Tempestades
232206	Abraço das Dez Tempestades
232207	Braçadeiras das Dez Tempestades
232208	Cinto das Dez Tempestades
232209	Palas das Dez Tempestades
232210	Coxotes das Dez Tempestades
232211	Capacete das Dez Tempestades
232212	Manoplas das Dez Tempestades
232213	Grevas das Dez Tempestades
232214	Peitoral das Dez Tempestades
232215	Avambraços das Dez Tempestades
232216	Cinturão das Dez Tempestades
232217	Espaldares das Dez Tempestades
232218	Perneiras das Dez Tempestades
232219	Coroa das Dez Tempestades
232220	Guantes das Dez Tempestades
232221	Botinas das Dez Tempestades
232222	Armadura das Dez Tempestades
232223	Munhequeiras das Dez Tempestades
232224	Cinta das Dez Tempestades
232225	Brafoneiras das Dez Tempestades
232226	Guarda-pernas das Dez Tempestades
232227	Viseira das Dez Tempestades
232228	Protetores de Mão das Dez Tempestades
232229	Escarpes das Dez Tempestades
232230	Couraça das Dez Tempestades
232231	Braçadeiras da Nêmesis
232232	Cinto da Nêmesis
232233	Espaldares da Nêmesis
232234	Perneiras da Nêmesis
232235	Casquete da Nêmesis
232236	Luvas da Nêmesis
232237	Botas da Nêmesis
232238	Vestes da Nêmesis
232239	Munhequeiras da Nêmesis
232240	Cordão da Nêmesis
232241	Ombreiras da Nêmesis
232242	Calças da Nêmesis
232243	Capucho da Nêmesis
232244	Protetores de Mão da Nêmesis
232245	Botinas da Nêmesis
232246	Induto da Nêmesis
232247	Braçadeiras da Ira
232248	Cinto da Ira
232249	Omoplatas da Ira
232250	Coxotes da Ira
232251	Elmo da Ira
232252	Manoplas da Ira
232253	Grevas da Ira
232254	Peitoral da Ira
232255	Munhequeiras da Ira
232256	Cinta da Ira
232257	Brafoneiras da Ira
232258	Guarda-pernas da Ira
232259	Viseira da Ira
232260	Protetores de Mão da Ira
232261	Escarpes da Ira
232262	Couraça da Ira
232299	Defensor Zulian
232309	Conduto da Alma de Renataki
232310	Conduto da Alma de Renataki
232311	Manto de Pele de Tigre Zulian
232312	Sangue do Arauto da Luz
232324	Apito de Pássaro
232344	Vick's VIP Pass
232357	Vingador Dracônico
232358	Relicário Vazio
232373	Olho de Sulfuras Refinado
232389	Incunábulo da Abundância
232390	Ídolo de Concentração Celestial
232391	Ídolo de Concentração Felina
232392	Totem de Trovão Incansável
232409	Totem dos Elementos
232414	Lâmina Dragodonte
232416	Totem de Fluxo Astral
232419	Totem de Correntes Condutoras
232420	Incunábulo da Ira
232421	Incunábulo da Vingança
232423	Ídolo da Nutrição
232424	Ídolo da Crueldade
232433	Bandagem Densa de Runatrama
232434	Manual: Bandagem Densa de Runatrama
232436	Caldo de Garrumbra
232437	Receita: Caldo de Garrumbra
232438	Vermelhão Defumado
232443	Receita: Vermelhão Defumado
232454	Emblema dos Deuses Selvagens
232455	Emblema da Desonra
232456	Emblema do Olho Violeta
232457	Emblema do Núcleo
232458	Runa do Santuário Aprimorado
232459	Runa da Cortina de Fogo
232460	Runa do Deslocamento
232461	Runa do Desespero
232462	Runa do Poder Purificador
232549	Instruções de Logística VI
232550	Ashkandi, Montante da Irmandade
232551	Marreta Dracônica
232552	Lok'amir il Romathis
232555	Crul'Shorukh, Beira do Caos
232556	Cajado da Chama Sombria
232557	Garra de Cromaggus
232558	Espada Temperada Cromaticamente
232559	Arauto do Sofrimento
232561	Garra do Draco Preto
232562	Cutelo de Garra de Draco
232563	Cajado de Foco da Asa Sombria
232564	Maladath, Lâmina Rúnica da Revoada Negra
232565	Lâmina Dendragônia
232566	A Lâmina Indomável
232567	Quebra-espinha
232576	Vingador Dracônico
232577	Gume da Perdição
232606	Ashjre'thul, Besta da Punição
232607	Furapeito
232608	Carabina Bafo de Dragão
232610	Fórmula: Brilhotrólico Magnífico
232611	Brilhotrólico Magnífico
232652	Zila Amanêmodas
233197	Manual de Treino Argênteo
233198	Trompa da Aurora
233200	Semente de Flor da Canção
233201	Globo Cintilante
233206	Bigorna do Feitor
233208	Bola 8 Mágica "Defeituosa"
233209	Caldeirão de Aguardente
233211	Concha Espiritual
233213	Magnetita Ancestral
233215	Armadilha de Areia Explosiva
233216	Raio Gelomático
233217	Incenso do Escavador
233226	Corda Zandalariana Ancestral
233250	Galho Antigo
233351	Cristal Ressonante Qiraji Verde-claro
233352	Cristal Ressonante Qiraji Azul-escuro
233353	Cristal Ressonante Qiraji Azul-claro
233356	Cristal Ressonante Qiraji Laranja
233357	Cristal Ressonante Qiraji Crepuscular
233358	Tanque Silitídeo Domado
233362	Carapaça do Deus Antigo
233363	Carapaça do Deus Antigo
233364	Pele do Deus Antigo
233365	Vísceras Intactas
233367	Peritônio Intacto
233368	Entranhas Intactas
233369	Braceletes Qiraji de Dominância
233370	Braceletes do Comando Qiraji
233371	Braceletes Qiraji de Soberania
233372	Grevas do Conquistador
233373	Peitoral do Conquistador
233374	Guarda-pernas do Conquistador
233375	Coroa do Conquistador
233376	Espaldares do Conquistador
233377	Palmilhas do Arauto da Ruína
233378	Calças do Arauto da Ruína
233379	Dragonas do Arauto da Ruína
233380	Vestes do Arauto da Ruína
233381	Diadema do Arauto da Ruína
233382	Perneiras do Tempestário
233383	Brafoneiras do Tempestário
233384	Guarda-pés do Tempestário
233385	Diadema do Tempestário
233386	Cota do Tempestário
233387	Espaldares do Causamortis
233388	Elmo do Causamortis
233389	Colete do Causamortis
233390	Perneiras do Causamortis
233391	Botas do Causamortis
233392	Palmilhas do Oráculo
233393	Tiara do Oráculo
233394	Dragonas do Oráculo
233395	Vestimenta do Oráculo
233396	Calças do Oráculo
233397	Peitoral do Vingador
233398	Coroa do Vingador
233399	Grevas do Vingador
233400	Guarda-pernas do Vingador
233401	Brafoneiras do Vingador
233402	Vestes Enigmáticas
233403	Ombreiras Enigmáticas
233404	Diadema Enigmático
233405	Botas Enigmáticas
233406	Perneiras Enigmáticas
233407	Guarda-pés do Atirador
233408	Perneiras do Atirador
233409	Brafoneiras do Atirador
233410	Diadema do Atirador
233411	Cota do Atirador
233412	Elmo da Gênese
233413	Ombreiras da Gênese
233414	Botas da Gênese
233415	Colete da Gênese
233416	Calças da Gênese
233417	Maça da Vida Interminável
233418	Manto da Vida Interminável
233419	Anel da Vida Interminável
233420	Manto do Caminho Oculto
233421	Foice do Caminho Oculto
233422	Sinete do Caminho Oculto
233423	Lâmina dos Segredos Obscuros
233424	Clâmide dos Segredos Obscuros
233425	Anel dos Segredos Obscuros
233426	Lâmina da Justiça Eterna
233427	Capa da Justiça Eterna
233428	Anel da Justiça Eterna
233429	Martelete da Sabedoria Infinita
233430	Mortalha da Sabedoria Infinita
233431	Anel da Sabedoria Infinita
233432	Manto das Sombras Veladas
233433	Adaga das Sombras Veladas
233434	Anel das Sombras Veladas
233435	Martelo da Tempestade Iminente
233436	Manto da Tempestade Iminente
233437	Anel da Tempestade Iminente
233438	Mortalha dos Nomes Proibidos
233439	Cris dos Nomes Proibidos
233440	Anel dos Nomes Proibidos
233441	Clâmide da Força Obstinada
233442	Foice da Força Obstinada
233443	Sinete da Força Obstinada
233490	Campeão de Obsidiana
233491	Aniquilador Obsidiano
233492	Loriga Aguilâmina
233496	Omoplatas da Barragem
233502	Amuleto da Proteção Pútrida
233503	Pingente do Guardião Qiraji
233504	Manto do Ódio Concentrado
233505	Perneiras da Imersão
233506	Munhequeiras em Escamas do Besouro
233507	Anel do Enxame de Pensamentos
233509	Cajado dos Profetas Qiraji
233514	Botas da Vontade Resoluta
233515	Martelo de Ji'zhi
233516	Peitoral da Aniquilação
233517	Botas da Profecia Cumprida
233518	Botas do Profeta Caído
233519	Capa da Trindade
233520	Vestes do Triunvirato
233521	Dragonas Ternárias
233522	Máscara do Devorador
233523	Cinturão Tríade
233524	Toque da Angelista
233559	Luvas de Ebru
233560	Manoplas Gosmentas
233561	Botas do Herói Caído
233562	Patuá da Angelista
233563	Dragonas do Poder Frênico
233564	Manoplas Cobertas de Bile
233565	Anel das Trevas de Ukko
233566	Dragonas da Fúria do Deserto
233567	Dragonas da Cruzada do Deserto
233568	Colete da Execução Rápida
233569	Anel do Devorado
233570	Escaravelho Petrificado
233571	Varinha da Nobreza Qiraji
233572	Colar da Pureza
233573	Botas Reconstruídas
233574	Perneiras do Enxame Ulceroso
233575	Vestes da Guarda de Batalha
233576	Garra Silitídea
233577	Cinto de Escamas Qiraji Grosso
233578	Elmo da Vinha Assustadora
233579	Luvas da Coação
233580	Distintivo dos Guarda-enxames
233581	Poder de Sartura
233582	Manoplas da Determinação Inabalável
233583	Coxotes da Luz Fulgurante
233584	Perneiras em Escamas da Fúria Qiraji
233585	Antiga Estripadora Qiraji
233586	Mandíbula do Aniquilador Arenoso
233587	Gargantilha Farpada
233588	Manto dos Segredos Não Revelados
233589	Fetiche do Aniquilador Arenoso
233590	Botas do Escavador de Colmeias
233591	Couraça de Carapaça Silitídea
233592	Dragonas da Revanche Perversa
233593	Brafoneiras do Implacável
233594	Vestes do Santo Guardião
233595	Perneiras em Escamas do Aniquilador Arenoso
233596	Incunábulo de Purificação
233597	Totem da Vida
233598	Perneiras Cobertas de Visco
233599	Fêmur Silitídeo Afiado
233600	Anel da Fúria Qiraji
233601	Broche do Escaravelho
233602	Ídolo da Saúde
233603	Manoplas do Campeão Íntegro
233604	Manoplas de Kalimdor
233605	Aguilhão de Huhuran
233606	Manto da Colmeia Dourada
233607	Luvas do Messias
233608	Manoplas de Casca de Vespa
233609	Anel do Mártir
233610	Munhequeiras do Profanador de Colmeias
233611	Botas da Epifania
233612	Braçadeiras Qiraji da Execução
233613	Luvas Devastadoras de Vek'lor
233614	Cinto Real Qiraji
233615	Anel do Imperador Vek'lor
233616	Cetro Real de Vek'lor
233617	Braceletes da Redenção Real
233618	Luvas do Templo Oculto
233619	Cinto Regenerador de Vek'nilash
233620	Amuleto de Vek'nilash
233621	Revanche de Kalimdor
233622	Garra do Imperador Caído
233623	Cinto do Imperador Caído
233624	Chapéu Perdido de Dom Rigoberto
233625	Braçadeiras do Escavador
233626	Larva do Grande Verme
233627	Jom Gabbar
233628	A Carapaça do Escavador
233629	Bloqueador de Escamas de Verme
233630	Manto dos Devorados
233631	Manoplas da Tempestade Negra
233632	Cinturão do Deus Antigo
233633	Cordão de Cintura do Olho Furtivo
233634	Aguilhão da Morte
233635	Cinto da Agonia sem Fim
233636	Cetro do Falso Profeta
233637	Manoplas da Aniquilação
233638	Anel do Assassino de Deuses
233639	Tentáculo Derrotado de C'Thun
233640	Gume Negro da Insanidade
233641	Manto da Clareza
233642	Marca de C'Thun
233643	Martelo de Guerra dos Anubisath
233644	Vestes da Ascensão Real
233645	Luvas do Imortal
233646	Luvas da Profecia Cumprida
233647	Neretzek, o Sanguinário
233648	Anel do Caos de Ritssyn
233649	Fragmento da Estrela Caída
233651	Corselete do Conquistador
233652	Escarpes do Conquistador
233653	Elmo do Conquistador
233654	Escarcela do Conquistador
233658	Brafoneiras do Conquistador
233659	Couraça do Causamortis
233660	Botinas do Causamortis
233661	Visor do Causamortis
233662	Calças do Causamortis
233663	Brafoneiras do Causamortis
233664	Cota Anilhada do Atirador
233665	Botinas do Atirador
233666	Visor do Atirador
233667	Coxotes Encadeados do Atirador
233668	Espaldares do Atirador
233669	Cimeira do Arauto da Ruína
233670	Induto do Arauto da Ruína
233671	Ombreiras do Arauto da Ruína
233672	Calças do Arauto da Ruína
233673	Botinas do Arauto da Ruína
233674	Calças Enigmáticas
233675	Sapatilhas Enigmáticas
233676	Coroa Enigmática
233677	Dragonas Enigmáticas
233678	Induto Enigmático
233679	Perneiras do Oráculo
233680	Vestes do Oráculo
233681	Ombreiras do Oráculo
233682	Coroa do Oráculo
233683	Sapatilhas do Oráculo
233684	Dragonas do Vingador
233685	Calças de Placa do Vingador
233686	Botinas do Vingador
233687	Elmo do Vingador
233688	Corselete do Vingador
233689	Espaldares do Vingador
233690	Escarcelas do Vingador
233691	Escarpes do Vingador
233692	Elmo do Vingador
233693	Couraça do Vingador
233694	Couraça do Tempestário
233695	Viseira do Tempestário
233696	Escarpes do Tempestário
233697	Espaldares do Tempestário
233698	Coxotes do Tempestário
233699	Peitoral do Tempestário
233700	Coroa do Tempestário
233701	Botinas do Tempestário
233702	Dragonas do Tempestário
233703	Perneiras Encadeadas do Tempestário
233704	Peitoral do Tempestário
233705	Cocar do Tempestário
233706	Grevas do Tempestário
233707	Palas do Tempestário
233708	Perneiras de Malha do Tempestário
233709	Capucho da Gênese
233710	Calças de Couro da Gênese
233711	Armadura da Gênese
233712	Pisoteadores da Gênese
233713	Espaldares da Gênese
233714	Perneiras da Gênese
233715	Couros da Gênese
233716	Botinas da Gênese
233717	Dragonas da Gênese
233718	Diadema da Gênese
233719	Calções da Gênese
233720	Couraça da Gênese
233721	Grevas da Gênese
233722	Brafoneiras da Gênese
233723	Máscara da Gênese
233724	Cinturão de Placa Endurecido em Batalha
233725	Cinturão de Placa Endurecido em Batalha
233726	Guarda-braços de Placa Endurecido em Batalha
233727	Guarda-braços de Placa Endurecido em Batalha
233728	Insígnia Incrustada de Sangue
233729	Gargantilha Incrustada de Sangue
233730	Talismã Incrustado de Sangue
233731	Amuleto Incrustado de Sangue
233732	Colar Incrustado de Sangue
233733	Anel Incrustado de Sangue
233734	Círculo Incrustado de Sangue
233735	Aro Incrustado de Sangue
233736	Elo Incrustado de Sangue
233737	Manto Incrustado de Sangue
233738	Capa Incrustada de Sangue
233739	Clâmide Incrustada de Sangue
233740	Mortalha Incrustada de Sangue
233741	Cinto Lamelar Endurecido em Batalha
233742	Guarda-braços Lamelar Endurecido em Batalha
233743	Munhequeiras Lamelares Endurecidas em Batalha
233744	Cordão Lamelar Endurecido em Batalha
233745	Cintel de Malha Endurecido em Batalha
233746	Cordão de Malha Endurecido em Batalha
233747	Cinto de Malha Endurecido em Batalha
233748	Braçadeiras de Malha Endurecidas em Batalha
233749	Munhequeiras de Malha Endurecidas em Batalha
233750	Avambraços de Malha Endurecidos em Batalha
233751	Cinturão Encadeado Endurecido em Batalha
233752	Cinturão Encadeado Endurecido em Batalha
233753	Cinto Encadeado Endurecido em Batalha
233754	Cinto Encadeado Endurecido em Batalha
233755	Munhequeiras Encadeadas Endurecidas em Batalha
233756	Munhequeiras Encadeadas Endurecidas em Batalha
233757	Braçadeiras Encadeadas Endurecidas em Batalha
233758	Braçadeiras Encadeadas Endurecidas em Batalha
233759	Braçadeiras de Couro de Dragão Endurecidas em Batalha
233760	Braçadeiras de Couro de Dragão Endurecidas em Batalha
233761	Cinto de Couro de Dragão Endurecido em Batalha
233762	Cinto de Couro de Dragão Endurecido em Batalha
233763	Cinta de Couro de Dragão Endurecida em Batalha
233764	Cinta de Couro de Dragão Endurecida em Batalha
233765	Cordão de Couro de Dragão Endurecido em Batalha
233766	Cordão de Couro de Dragão Endurecido em Batalha
233767	Munhequeiras de Couro de Dragão Endurecidas em Batalha
233768	Munhequeiras de Couro de Dragão Endurecidas em Batalha
233769	Embraces de Couro de Dragão Endurecidos em Batalha
233770	Embraces de Couro de Dragão Endurecidos em Batalha
233771	Cinturão de Couro Endurecido em Batalha
233772	Cinturão de Couro Endurecido em Batalha
233773	Pulseiras de Couro Endurecidas em Batalha
233774	Pulseiras de Couro Endurecidas em Batalha
233775	Manilhas de Seda Endurecidas em Batalha
233776	Manilhas de Seda Endurecidas em Batalha
233777	Faixa de Seda Endurecida em Batalha
233778	Faixa de Seda Endurecida em Batalha
233779	Braçadeiras de Cetim Endurecidas em Batalha
233780	Braçadeiras de Cetim Endurecidas em Batalha
233781	Munhequeiras de Cetim Endurecidas em Batalha
233782	Munhequeiras de Cetim Endurecidas em Batalha
233783	Faixa de Cetim Endurecida em Batalha
233784	Faixa de Cetim Endurecida em Batalha
233785	Cilha de Cetim Endurecida em Batalha
233786	Cilha de Cetim Endurecida em Batalha
233787	Manilhas de Medotrama Endurecidas em Batalha
233788	Manilhas de Medotrama Endurecidas em Batalha
233789	Cinto de Medotrama Endurecido em Batalha
233790	Cinto de Medotrama Endurecido em Batalha
233791	Moeda de Cobre Incrustada de Sangue
233793	Placa d'Ombros Aguilâmina
233795	Jaula Craniana Aguilâmina
233796	Destruidor Obsidiano
233797	Martelo da Tempestade Obsidiano
233798	Lâmina do Sábio Obsidiana
233801	Defensor Obsidiano
233802	Kit de Armadura de Quitina Chamejante
233803	Kit de Armadura de Quitina Afiada
233804	Ombreiras de Espinheira-brava
233808	Capucho de Espinheira-brava
233813	Couros de Espinheira-brava
233826	Capucho Vampírico
233833	Xale Vampírico
233837	Veste Vampírica
233956	Lenço de Seda Qiraji
233958	Capa de Seda Qiraji
233959	Manto de Seda Qiraji
233960	Clâmide de Seda Qiraji
233962	Frasco de Loucura
233964	Frasco de Conhecimento Ancestral
233965	Frasco dos Deuses Antigos
233966	Frasco de Tristeza sem Fim
233967	Elixir do Texugo Melífero
233968	Elixir do Lorde-mago
233969	Elixir do Ladoférreo
233977	Elixir de Diligência
233984	Megabomba Arcana
233985	O Fumigador
233986	Bomba Obsidiana
233987	Gerador V1B3-B04
233988	Disco de Força Reativa Ajustado
233990	Pedracélere
233991	Lágrima da Sonhadora
233992	Magnetita da Retaliação
233993	Cronômetro Encantado
233994	Broche Incrustado de Rubis
233995	Pergaminho: Ira do Enxame
233996	Repelente Encantado
233997	Fórmula: Encantamento de Atributos Vivos - Torso
233998	Fórmula: Encantamento de Poder Sagrado - Luvas
233999	Fórmula: Encantamento de Poder Arcano - Luvas
234000	Tomo Encantado de Orações
234001	Totem Encantado
234002	Cogumelo Encantado
234003	Barra de Tório Infusa em Obsidiana
234004	Pedra de Amolar Obsidiana
234005	Pó Explosivo Obsidiano
234006	Quitina de Silitídeo Monstruosa
234007	Quitina de Silitídeo Farpada
234008	Seda Qiraji
234009	Rolo de Seda Qiraji
234010	Bile de Verme da Areia
234011	Peçonha de Espreitador Qiraji
234012	Cardo de Colmeia
234016	Anel-sinete da Revoada Bronze
234017	Anel-sinete da Revoada Bronze
234018	Anel-sinete da Revoada Bronze
234019	Anel-sinete da Revoada Bronze
234020	Anel-sinete da Revoada Bronze
234021	Anel-sinete da Revoada Bronze
234022	Anel-sinete da Revoada Bronze
234023	Anel-sinete da Revoada Bronze
234024	Anel-sinete da Revoada Bronze
234025	Anel-sinete da Revoada Bronze
234026	Anel-sinete da Revoada Bronze
234027	Anel-sinete da Revoada Bronze
234028	Anel-sinete da Revoada Bronze
234029	Anel-sinete da Revoada Bronze
234030	Anel-sinete da Revoada Bronze
234031	Anel-sinete da Revoada Bronze
234032	Anel-sinete da Revoada Bronze
234033	Anel-sinete da Revoada Bronze
234034	Anel-sinete da Revoada Bronze
234035	Anel-sinete da Revoada Bronze
234061	Adaga Sacrifical Qiraji
234062	Vestimenta das Areias Cambiantes
234063	Cinto do Aniquilador Arenoso
234064	Cinto da Inquisição
234065	Munhequeiras do Aniquilador Arenoso
234066	Luvas de Casca Silitídea Reforçada
234067	A Degola-homens Qiraji
234068	Botas da Vanguarda
234069	Botas do General Qiraji
234070	Braçadeiras do Comando Qiraji
234071	Coxotes do Comando Qiraji
234072	Cinturão do Vento Sul
234073	Turbante Sopravento
234075	Manoplas do Impassível
234076	Garra da Concentração Furiosa
234077	Couraça Silitídea Grossa
234078	Guarda-ombros Quitinosos
234079	Manto do Salvador
234080	Olho de Moam
234081	Manoplas do Vento Sul
234082	Dragonas de Maz'Nadir
234083	Anel da Fúria
234084	Elmo do Vento Sul
234085	Instruções: Garra Negra do Destruidor
234086	Garra Negra do Destruidor
234087	Perneiras em Escamas Obsidianas
234088	Coxotes do Destruidor
234089	Fragmento do Crânio de Buru
234090	Luvas do Enxame
234091	Manoplas em Escamas Viscosas
234092	Fetiche de Espinhos Quitinosos
234093	Galochas da Areia Movediça
234094	Braçadeiras em Escamas do Engolidor
234095	Pisantes de Visgo
234096	Arco do Tendão Estirado
234097	Aguilhão de Ayamiss
234098	Botas do Protetor do Deserto
234099	Botas das Areias Abrasadoras
234100	Elmo do Recrescimento
234101	Anel dos Ventos do Deserto
234102	Manoplas do Silitídeo em Escamas
234103	Braçadeiras da Brutalidade
234104	Besta da Ruína Iminente
234105	Manoplas da Vida Nova
234106	Luvas da Sabedoria Negra
234107	Elmo da Dominação
234108	Perneiras da Nevasca Negra
234109	Dragonas dos Horusath
234110	Cinturão de Ossirian
234111	Omoplatas de Pedra Rúnica
234112	Martelo Polido com Areia
234113	Manto da Tempestade de Areia
234114	Grilhões do Imaculado
234115	Cajado das Ruínas
234116	Fúria do Enxame Esquecido
234117	Botinas do Nômade Errante
234118	Martelete da Autoridade Qiraji
234119	Tentáculo do Fortalecimento
234120	Elmo do Vingador Sagrado
234121	Lançador Encouraçado Silitídeo
234122	A Cris Perdida de Zedd
234123	Coifa da Fúria Elemental
234124	Guia de Veneno Oculto II
234129	Perneiras Engastadas com Ônix
234130	Amuleto de Anteparo Sombrio
234132	Colar de Dente de Draco
234133	Botas Labutadoras
234134	Turbante Gnômico do Poder Psíquico
234135	Elo das Profundezas Congelantes
234136	Vestes da Água Negra
234137	Presa de Korialstrasz
234138	Lamento dos Cantonegro
234139	Legado dos Cristacorvo
234141	Espada Rúnica do Vermelho
234142	Elixir Nublacuca sem Fundo
234143	Globo do Logro
234144	Incensório do Falso Profeta
234145	Bijuteria Hakkari Incrustada de Sangue
234146	Grevas Inscritas com Ácido
234147	Perneiras Antigas Corroídas
234148	Munhequeiras de Osso de Dragão
234149	Braçadeiras Draguilhão
234150	Luvas do Poder Ilusório
234151	Manto Verde de Peledrago
234152	Martelo da Fúria Bestial
234153	Cajado do Crescimento Descontrolado
234154	Pedra do Transe
234155	Anel-sinete de Malfurion
234156	Botas do Pântano sem Fim
234157	Diadema dos Sonhos Inquietos
234158	Colar Dracórdio
234159	Besta de Pau-ferro Polido
234160	Anel do Vivo-morto
234161	Cinto do Brejo Negro
234162	Braceleiras da Casca Preta
234163	Calças do Coração Negro
234164	Casquete do Crescimento Anormal
234165	Manoplas da Luz Rutilante
234166	Guarda-pés Malignos
234167	Botas do Medo
234168	Sapatilhas do Mendicante
234169	Faixa Rasgamentes
234170	Lâmina de Pesadelo
234171	Brafoneiras Sinistras de Couro
234172	Esmeralda Dendragônia
234173	Perneiras do Demente
234174	Brafoneiras Inscritas com Ácido
234175	Cristal de Hibernação
234176	Carta de Negraluna: Heroísmo
234177	Carta de Negraluna: Dragão Azul
234178	Carta de Negraluna: Voragem
234179	Carta de Negraluna: Espiral Etérea
234180	Sinalizador Temporal
234181	Diário de Sectário do Crepúsculo
234198	Anel-sinete da Revoada Bronze
234199	Anel-sinete da Revoada Bronze
234200	Anel-sinete da Revoada Bronze
234201	Anel-sinete da Revoada Bronze
234202	Anel-sinete da Revoada Bronze
234220	Instruções: Jaula Craniana Aguilâmina
234221	Instruções: Placa d'Ombros Aguilâmina
234222	Instruções: Loriga Aguilâmina
234223	Instruções: Aniquilador Obsidiano
234224	Instruções: Campeão Obsidiano
234225	Instruções: Destruidor Obsidiano
234226	Instruções: Martelo da Tempestade Obsidiano
234227	Instruções: Lâmina do Sábio Obsidiana
234228	Instruções: Defensor Obsidiano
234235	Molde: Kit de Armadura de Quitina Chamejante
234236	Molde: Kit de Armadura de Quitina Afiada
234237	Molde: Capucho de Espinheira-brava
234238	Molde: Ombreiras de Espinheira-brava
234239	Molde: Couros de Espinheira-brava
234240	Molde: Capucho Vampírico
234241	Molde: Xale Vampírico
234242	Molde: Veste Vampírica
234244	Molde: Lenço de Seda Qiraji
234249	Molde: Capa de Seda Qiraji
234250	Molde: Manto de Seda Qiraji
234251	Molde: Clâmide de Seda Qiraji
234252	Receita: Frasco de Tristeza sem Fim
234253	Receita: Frasco de Conhecimento Ancestral
234255	Receita: Frasco dos Deuses Antigos
234256	Receita: Frasco de Loucura
234257	Receita: Elixir do Texugo Melífero
234258	Receita: Elixir do Lorde-mago
234259	Receita: Elixir do Ladoférreo
234260	Receita: Elixir de Diligência
234261	Diagrama: Megabomba Arcana
234262	Diagrama: O Fumigador
234263	Diagrama: Bomba Obsidiana
234264	Diagrama: Gerador V1B3-B04
234265	Diagrama: Disco de Força Reativa Ajustado
234266	Fórmula: Pedracélere
234267	Fórmula: Lágrima da Sonhadora
234268	Fórmula: Magnetita da Retaliação
234269	Fórmula: Cronômetro Encantado
234270	Fórmula: Broche Incrustado de Rubis
234271	Fórmula: Pergaminho: Ira do Enxame
234272	Fórmula: Repelente Encantado
234275	Fórmula: Tomo Encantado de Orações
234276	Fórmula: Totem Encantado
234277	Fórmula: Cogumelo Encantado
234278	Manual: Fundir Barra de Tório Infusa em Obsidiana
234279	Instruções: Pedra de Amolar Obsidiana
234280	Diagrama: Pó Explosivo Obsidiano
234288	Cinto Vinaferro
234289	Instruções: Cinto Vinaferro
234290	Luvas Vinaferro
234291	Instruções: Luvas Vinaferro
234292	Peitoral Vinaferro
234293	Instruções: Peitoral Vinaferro
234294	Braçadeiras Espreitareia
234295	Molde: Braçadeiras Espreitareia
234296	Manoplas Espreitareia
234297	Molde: Manoplas Espreitareia
234298	Peitoral Espreitareia
234299	Molde: Peitoral Espreitareia
234300	Braçadeiras Cospefogo
234301	Molde: Braçadeiras Cospefogo
234302	Manoplas Cospefogo
234303	Molde: Manoplas Cospefogo
234304	Peitoral Cospefogo
234305	Molde: Peitoral Cospefogo
234306	Cinto de Sarça
234307	Molde: Cinto de Sarça
234308	Botas de Sarça
234309	Molde: Botas de Sarça
234310	Elmo de Sarça
234311	Molde: Elmo de Sarça
234312	Omoplatas Silvestres
234314	Molde: Omoplatas Silvestres
234315	Coroa Silvestre
234316	Molde: Coroa Silvestre
234317	Colete Silvestre
234318	Molde: Colete Silvestre
234319	Cinto Pesado de Obsidiana
234320	Instruções: Cinto Pesado de Obsidiana
234321	Cinto Leve de Obsidiana
234322	Instruções: Cinto Leve de Obsidiana
234324	Peitoral de Escama de Sonhos
234325	Molde: Peitoral de Escama de Sonhos
234428	Acerta-peito Obsidiano
234429	Instruções: Acerta-peito Obsidiano
234434	Espingarda Obsidiana
234435	Diagrama: Espingarda Obsidiana
234436	Anel-sinete da Revoada Bronze
234437	Anel-sinete da Revoada Bronze
234438	Anel-sinete da Revoada Bronze
234439	Anel-sinete da Revoada Bronze
234440	Anel-sinete da Revoada Bronze
234444	Veneno Oculto II
234445	Molde: Rolo de Seda Qiraji
234447	Bastão de Transformação da Buba
234458	Instruções: Escudo Serrilhado Obsidiano
234459	Escudo Serrilhado Obsidiano
234460	Túnica de Malha de Obsidiana
234461	Instruções: Túnica de Malha de Obsidiana
234462	Golpe Terreno
234463	Ira de Cenarius
234464	Bastão de Bolhas da Buba
234465	Rédeas do Tigre Espectral Veloz
234467	Bastão dos Dragões da Buba
234468	Ídolo de Poder Ursino
234469	Ídolo de Ferocidade Felina
234474	Ídolo da Ira Sideral
234475	Incunábulo do Exorcista
234476	Incunábulo de Santidade
234477	Incunábulo da Retidão
234478	Totem de Ataques Tempestuosos
234479	Totem de Fluxo Magmático
234480	Totem de Trovão Piroclástico
234481	Molde: Kilt de Escama de Sonhos
234482	Kilt de Escama de Sonhos
234483	Molde: Braçadeiras de Escama de Sonhos
234484	Braçadeiras de Escama de Sonhos
234485	Luvetes de Escama de Sonhos
234486	Molde: Luvetes de Escama de Sonhos
234487	Visor de Escama de Sonhos
234488	Instruções: Visor de Escama de Sonhos
234542	Montante do Sumo Senhor da Guerra
234543	Machado de Batalha do Sumo Senhor da Guerra
234545	Pulverizador do Sumo Senhor da Guerra
234546	Destruidor do Sumo Senhor da Guerra
234547	Dessangrador do Sumo Senhor da Guerra
234548	Atiçador de Porcos do Sumo Senhor da Guerra
234549	Cajado de Guerra do Sumo Senhor da Guerra
234550	Lâmina Enfeitiçada do Sumo Senhor da Guerra
234551	Maça de Batalha do Sumo Senhor da Guerra
234552	Lâmina do Sumo Senhor da Guerra
234553	Gumepresto do Sumo Senhor da Guerra
234554	Cutelo do Sumo Senhor da Guerra
234555	Porrete do Sumo Senhor da Guerra
234556	Navalha do Sumo Senhor da Guerra
234557	Garra Direita do Sumo Senhor da Guerra
234558	Garra Esquerda do Sumo Senhor da Guerra
234559	Arco Recurvo do Sumo Senhor da Guerra
234560	Besta do Sumo Senhor da Guerra
234561	Abre-alas do Sumo Senhor da Guerra
234562	Muralha de Escudos do Sumo Senhor da Guerra
234563	Tomo de Destruição do Sumo Senhor da Guerra
234564	Tomo de Recomposição do Sumo Senhor da Guerra
234565	Espadão do Grão-marechal
234566	Talho do Grão-marechal
234567	Martelo de Batalha do Grão-marechal
234568	Demolidor do Grão-marechal
234569	Glaive do Grão-marechal
234570	Arma de Haste do Grão-marechal
234571	Báculo do Grão-marechal
234574	Magespada do Grão-marechal
234576	Martelo de Guerra do Grão-marechal
234578	Espada Longa do Grão-marechal
234579	Lâmina Célere do Grão-marechal
234580	Machado de Mão do Grão-marechal
234581	Castigador do Grão-marechal
234582	Punhal do Grão-marechal
234583	Lâmina Destra do Grão-marechal
234584	Lâmina Sinistra do Grão-marechal
234585	Disparo Certeiro do Grão-marechal
234586	Besta de Repetição do Grão-marechal
234587	Canhão de Mão do Grão-marechal
234588	Égide do Grão-marechal
234589	Tomo de Poder do Grão-marechal
234590	Tomo de Restauração do Grão-marechal
234614	Emblema Tocado pelo Caos
234650	Antiga Estripadora Qiraji
234747	Punho de Cenarius
234748	Braçadeiras Rochafunda
234749	Orbe Terramansa
234760	Braçadeiras Rochafúria
234761	Poder de Cenarius
234779	Dádiva da Terra
234780	Elo do Poder Terrano
234782	Colete do Poder Terreno
234785	Luvas do Poder Terrano
234786	Anel da Ira Terrana
234788	Manto de Trama Terrena
234792	Fatiadora de Corvoforte
234793	Lanceta do Engrenofaca
234797	Atiçador Pau-de-trovão
234798	Arruinus Prime
234799	Repetidor de Recarga de Fahrad
234800	Martelo de Cultivo da Simone
234801	Amuleto do Deus Caído
234802	Manto do Deus Caído
234803	Anel do Deus Caído
234804	Machado de Guerra Qiraji Abençoado
234805	Mosquete Qiraji Abençoado
234806	Pugio Qiraji Abençoado
234807	Baluarte Qiraji Abençoado
234808	Cajado Qiraji Abençoado do Acólito
234809	Cajado Qiraji Abençoado do Áugure
234810	Martelo de Guerra Qiraji Abençoado
234811	Patuá das Areias Cambiantes
234812	Amuleto das Areias Cambiantes
234813	Gargantilha das Areias Cambiantes
234814	Pingente das Areias Cambiantes
234960	Rédeas do Tigre Incrustado de Sangue
234961	Apito do Raptor Incrustado de Sangue
234962	Vestimenta Marchetada de Jade
234963	Coxotes com Estranhos Entalhes
234964	Anel-sinete da Revoada Bronze
234965	Anel-sinete da Revoada Bronze
234966	Anel-sinete da Revoada Bronze
234967	Anel-sinete da Revoada Bronze
234968	Anel-sinete da Revoada Bronze
234974	Cajado dos Profetas Qiraji
234975	Martelo de Ji'zhi
234976	Varinha da Nobreza Qiraji
234977	Garra Silitídea
234978	Mandíbula do Aniquilador Arenoso
234979	Fêmur Silitídeo Afiado
234980	Aguilhão de Huhuran
234981	Revanche de Kalimdor
234983	Larva do Grande Verme
234984	Aguilhão da Morte
234985	Gume Negro da Insanidade
234986	Martelo de Guerra dos Anubisath
234987	Neretzek, o Sanguinário
234989	Adaga Sacrifical Qiraji
234990	A Degola-homens Qiraji
234991	Arco do Tendão Estirado
234992	Aguilhão de Ayamiss
234993	Besta da Ruína Iminente
234994	Martelo Polido com Areia
234995	Cajado das Ruínas
234996	Martelete da Autoridade Qiraji
234997	Lançador Encouraçado Silitídeo
234998	A Cris Perdida de Zedd
234999	Martelo de Guerra Qiraji Abençoado
235000	Cajado Qiraji Abençoado do Áugure
235001	Cajado Qiraji Abençoado do Acólito
235002	Pugio Qiraji Abençoado
235003	Machado de Guerra Qiraji Abençoado
235004	Mosquete Qiraji Abençoado
235005	Foice da Força Obstinada
235006	Adaga das Sombras Veladas
235007	Foice do Caminho Oculto
235008	Cris dos Nomes Proibidos
235009	Martelo da Tempestade Iminente
235010	Martelete da Sabedoria Infinita
235011	Lâmina da Justiça Eterna
235012	Maça da Vida Interminável
235013	Lâmina dos Segredos Obscuros
235014	Cetro do Falso Profeta
235039	Instruções: Peitoral Grosso de Obsidiana
235040	Peitoral Grosso de Obsidiana
235045	Paramentos Imperiais Qirajis
235046	Armamentos Imperiais Qirajis
235047	Luvas do Profeta Caído
235048	Cabeça de Ossirian, o Intocado
235049	Objeto Mergulhado em Pesadelos
235133	Fórmula: Incunábulo da Retidão
235134	Fórmula: Incunábulo do Exorcista
235135	Fórmula: Incunábulo de Santidade
235136	Fórmula: Totem de Trovão Piroclástico
235137	Fórmula: Totem de Ataques Tempestuosos
235138	Fórmula: Totem de Fluxo Magmático
235139	Fórmula: Ídolo da Ira Sideral
235140	Fórmula: Ídolo de Ferocidade Felina
235141	Fórmula: Ídolo de Poder Ursino
235142	Moeda de Prata Incrustada de Sangue
235143	Moeda de Ouro Incrustada de Sangue
235144	Algibeira de Moedas de Cobre Incrustadas de Sangue
235145	Algibeira de Moedas de Prata Incrustadas de Sangue
235275	Baralho de Portais
235276	Baralho de Elementais
235277	Baralho de Generais
235278	Baralho de Feras
235282	Tentáculo do Fortalecimento
235473	Barricada do Grão-Marechal
235474	Barricada do Sumo Senhor da Guerra
235476	Talhador do Sumo Senhor da Guerra
235477	Racha-osso do Sumo Senhor da Guerra
235478	Estoque do Sumo Senhor da Guerra
235479	Estoque do Grão-marechal
235480	Racha-osso do Grão-Marechal
235481	Talhador do Grão-Marechal
235497	Tisana das Areias
235511	Cristal Ressonante Qiraji Amarelo Impecável
235512	Cristal Ressonante Qiraji Verde Impecável
235513	Cristal Ressonante Qiraji Azul Impecável
235514	Cristal Ressonante Qiraji Vermelho Impecável
235517	Tocha
235526	Fórmula: Encantamento de Poder Mágico - Braçadeiras
235528	Fórmula: Encantamento de Agilidade - Braçadeiras
235529	Mira Obsidiana
235530	Diagrama: Mira Obsidiana
235597	Anotações de Feitiços: Congelamento Profundo
235598	Anotações de Feitiços: Veias Gélidas
235599	Anotações de Feitiços: Anomalia Temporal
235600	Runa da Tempestade Divina
235601	Runas do Fanatismo
235602	Runa do Martelo do Íntegro
235603	Runa da Vingança Íntegra
235604	Runa do Escudo de Retidão
235605	Runa de Choque e Admiração
235785	"Chave" de Jaula do Vento Morto
235786	Badulaque de Karazhan
235787	Galho de Pau-ferro Ancestral
235788	Fogo-fátuo Entusiasmado
235789	Chama da Vida
235790	Tição Encantado
235825	Tisana das Areias
235852	Algibeira Violeta
235867	Retalho de Pergaminho
235868	Baluarte da Ira
235869	Capucho do Senhorio
235870	Elmo Range-ossos
235871	Elmo da Morte Agarradora
235872	Embraces do Espreitador
235873	Guardiões da Cripta
235874	Mitenes do Sectário
235875	Luvas do Coveiro
235876	Protetores de Mão do Pecador
235877	Manoplas do Fanático
235878	Cinto Maléfico
235879	Elos Ligeiros
235880	Solas do Indigente
235881	Botinas Temidas
235882	Passos Estaladores
235883	Tropeço do Mergulhador de Poço
235884	Sinete Espectral
235885	Anel Fantasmagórico
235886	Fecho de Kaigy
235887	Gargantilha de Barian
235888	Panclavão
235889	Bastão de Serviçal
235890	Agulha de Tece-sombras
235891	Boa e Velha
235892	Espinha do Cavaleiro Sombrio
235893	Grimório Sombrio
235894	Óbito do Agourento
236002	Lista de Componentes
236005	Peitoral Couraçado
236006	Coxotes Couraçados
236007	Capacete Couraçado
236008	Brafoneiras Couraçadas
236009	Escarpes Couraçados
236010	Manoplas Couraçadas
236011	Cinta Couraçada
236012	Braçadeiras Couraçadas
236013	Anel Couraçado
236014	Corselete Couraçado
236015	Escarcelas Couraçadas
236016	Chifres Couraçados
236017	Omoplatas Couraçadas
236018	Grevas Couraçadas
236019	Guantes Couraçados
236020	Cinto Couraçado
236021	Pulsos Couraçados
236022	Elo Couraçado
236023	Peitoral Ceifa-ossos
236024	Coxotes Ceifa-ossos
236025	Capacete Ceifa-ossos
236026	Brafoneiras Ceifa-ossos
236027	Escarpes Ceifa-ossos
236028	Manoplas Ceifa-ossos
236029	Cinta Ceifa-ossos
236030	Braçadeiras Ceifa-ossos
236031	Anel Ceifa-ossos
236032	Cinto Ceifa-ossos
236033	Botinas Ceifa-ossos
236034	Elo Ceifa-ossos
236035	Dragonas Ceifa-ossos
236036	Perneiras Ceifa-ossos
236037	Máscara Ceifa-ossos
236038	Garras Ceifa-ossos
236039	Couraça Ceifa-ossos
236040	Munhequeiras Ceifa-ossos
236041	Anel Criptalante
236042	Munhequeiras Criptalantes
236043	Túnica Criptalante
236044	Espaldares Criptalantes
236045	Guarda-pernas Criptalantes
236046	Bacinete Criptalante
236047	Protetores de Mão Criptalantes
236048	Cinturão Criptalante
236049	Botas Criptalantes
236050	Avambraços Criptalantes
236051	Cinto Criptalante
236052	Brafoneiras Criptalantes
236053	Perneiras Criptalantes
236054	Visor Criptalante
236055	Manoplas Criptalantes
236056	Elo Criptalante
236057	Grevas Criptalantes
236058	Peitoral Criptalante
236059	Sandálias do Coração Pestilento
236060	Perneiras do Coração Pestilento
236061	Braceletes do Coração Pestilento
236062	Veste do Coração Pestilento
236063	Luvas do Coração Pestilento
236064	Diadema do Coração Pestilento
236065	Ombreiras do Coração Pestilento
236066	Cinto do Coração Pestilento
236067	Anel do Coração Pestilento
236068	Munhequeiras do Coração Pestilento
236069	Cinta do Coração Pestilento
236070	Dragonas do Coração Pestilento
236071	Calças do Coração Pestilento
236072	Coroa do Coração Pestilento
236073	Protetores de Mão do Coração Pestilento
236074	Aro do Coração Pestilento
236075	Botas do Coração Pestilento
236076	Indumentária do Coração Pestilento
236077	Braceletes de Fogofrio
236078	Cinto de Fogofrio
236079	Perneiras de Fogofrio
236080	Sandálias de Fogofrio
236081	Veste de Fogofrio
236082	Luvas de Fogofrio
236083	Diadema de Fogofrio
236084	Ombreiras de Fogofrio
236085	Anel de Fogofrio
236087	Munhecas de Fogofrio
236088	Cinta de Fogofrio
236089	Dragonas de Fogofrio
236090	Calças de Fogofrio
236091	Capuz de Fogofrio
236092	Luvetes de Fogofrio
236093	Elo Fogofrio
236094	Botas de Fogofrio
236095	Trajes de Fogofrio
236097	Veste da Fé
236098	Cinto da Fé
236099	Sandálias da Fé
236100	Braceletes da Fé
236101	Perneiras da Fé
236102	Ombreiras da Fé
236103	Diadema da Fé
236104	Luvas da Fé
236105	Anel da Fé
236106	Pulsos da Fé
236107	Cinturão da Fé
236108	Comando de Arlote
236109	Calças da Fé
236110	Coroa da Fé
236111	Mãos da Fé
236112	Elo da Fé
236113	Botas da Fé
236114	Trajes da Fé
236115	Túnica da Redenção
236116	Anel da Redenção
236117	Bacinete da Redenção
236118	Protetores de Mão da Redenção
236119	Munhequeiras da Redenção
236120	Cinturão da Redenção
236121	Guarda-pernas da Redenção
236122	Espaldares da Redenção
236123	Botas da Redenção
236124	Avambraços da Redenção
236125	Cinto da Redenção
236126	Placa d'Ombros da Redenção
236127	Perneiras da Redenção
236128	Capacete da Redenção
236129	Luvas da Redenção
236130	Elo da Redenção
236131	Grevas da Redenção
236132	Peitoral da Redenção
236133	Braçadeiras da Redenção
236134	Cinta da Redenção
236135	Brafoneiras da Redenção
236136	Coxotes da Redenção
236137	Coroa da Redenção
236138	Manoplas da Redenção
236139	Aro da Redenção
236140	Escarpes da Redenção
236141	Couraça da Redenção
236142	Protetores de Mão Quebraterra
236143	Guarda-pernas Quebraterra
236144	Bacinete Quebraterra
236145	Espaldares Quebraterra
236146	Botas Quebraterra
236147	Túnica Quebraterra
236148	Cinturão Quebraterra
236149	Munhequeiras Quebraterra
236150	Anel Quebraterra
236151	Braceletes Quebraterra
236152	Cordão Quebraterra
236153	Dragonas Quebraterra
236154	Kilt Quebraterra
236155	Coroa Quebraterra
236156	Luvetes Quebraterra
236157	Elo Quebraterra
236158	Grevas Quebraterra
236159	Abraço Quebraterra
236160	Braçadeiras Quebraterra
236162	Cinta Quebraterra
236163	Brafoneiras Quebraterra
236164	Coxotes Quebraterra
236165	Viseira Quebraterra
236166	Luvas Quebraterra
236167	Aro Quebraterra
236168	Escarpes Quebraterra
236169	Couraça Quebraterra
236170	Avambraços Quebraterra
236171	Cinto Quebraterra
236172	Palas Quebraterra
236173	Perneiras Quebraterra
236174	Capacete Quebraterra
236175	Guantes Quebraterra
236176	Sinete Quebraterra
236177	Botinas Quebraterra
236179	Armadura Quebraterra
236182	Bacinete Andassonho
236183	Munhequeiras Andassonho
236184	Protetores de Mão Andassonho
236185	Botas Andassonho
236186	Túnica Andassonho
236187	Cinturão Andassonho
236188	Guarda-pernas Andassonho
236189	Espaldares Andassonho
236190	Anel Andassonho
236192	Braceletes Andassonho
236193	Cordão Andassonho
236194	Dragonas Andassonho
236195	Kilt Andassonho
236196	Capuz Andassonho
236197	Luvetes Andassonho
236198	Elo Andassonho
236199	Sandálias Andassonho
236200	Couros Andassonho
236201	Braçadeiras Andassonho
236202	Cinta Andassonho
236203	Brafoneiras Andassonho
236204	Perneiras Andassonho
236205	Adereço de Cabeça Andassonho
236206	Manoplas Andassonho
236207	Aro Andassonho
236208	Escarpes Andassonho
236209	Armadura Andassonho
236210	Munhequeiras Andassonho
236211	Faixa Andassonho
236212	Ombreiras Andassonho
236213	Calças Andassonho
236214	Capucho Andassonho
236215	Guantes Andassonho
236216	Sinete Andassonho
236217	Pisoteadores Andassonho
236218	Colete Andassonho
236219	Emissário da Destruição
236220	Traje do Necro-cavaleiro
236221	Braço Perdido do Servo
236222	Túnica de Pele de Carniçal
236223	Anel da Chama Eterna
236224	Broquel Estígio
236225	Cinturão da Fúria Elemental
236226	Brafoneiras da Fúria Elemental
236227	Cinto do Grande Cruzado
236228	Espaldares do Grande Cruzado
236229	Perneiras do Grande Cruzado
236230	Perneiras de Fúria Elemental
236231	Peitoral Profanado
236232	Cinta Profanada
236233	Manoplas Profanadas
236234	Escarpes Profanados
236235	Braçadeiras Profanadas
236236	Capacete Profanado
236237	Brafoneiras Profanadas
236238	Coxotes Profanados
236239	Sandálias Profanadas
236240	Ombreiras Profanadas
236241	Diadema Profanado
236242	Veste Profanada
236243	Luvas Profanadas
236244	Cinto Profanado
236245	Braceletes Profanados
236246	Perneiras Profanadas
236247	Munhequeiras Profanadas
236248	Botas Profanadas
236249	Bacinete Profanado
236250	Protetores de Mão Profanados
236251	Túnica Profanada
236252	Cinturão Profanado
236253	Guarda-pernas Profanado
236254	Espaldares Profanados
236255	Munhequeiras da Vingança
236256	Toque de Gelo
236257	Gema de Nerúbis
236258	Manto de Seda de Carnífice da Cripta
236259	Elo das Preces Não Atendidas
236260	Brafoneiras da Perdição Gélida
236261	Pingente de Pedra da Malícia
236262	Espaldares Polares
236263	Remorso da Viúva
236264	O Abraço da Viúva
236265	Lâmina Espectral
236266	Pingente dos Nomes Esquecidos
236267	Veste Tecida com Cristais
236268	Beijo da Aranha
236269	Presa de Maexxna
236270	Machadinha de Osso Partido
236271	Incunábulo da Luz
236272	Manto do Flagelo
236273	Anel do Inevitável
236274	Elo de Granizo
236275	Coração Frígido de Noth
236276	Totem da Água Corrente
236277	Colar da Necropsia
236278	Diadema Glacial
236279	Chapéu do Preceptor
236280	Coxotes da Chacina
236281	Coifa de Escama Gelada
236282	Reflexão de Repugnaz
236283	Anel do Fervor Espiritual
236284	Cajado Sulfúreo
236285	O Olho de Nerub
236286	Elo das Forças Sobrenaturais
236287	Ruptura
236288	O Portador da Peste
236289	Manto de Sutura
236290	Varinha do Destino
236291	Elo de Reanimação
236292	Bruma da Meia-noite
236293	Injetor de Toxinas
236294	Espaldares de Escama Gelada
236295	Dragonas Glaciais
236296	Oferta da Morte
236297	O Fim dos Sonhos
236298	Dragonas Cobertas de Geada
236299	Espadão do Poder Profano
236300	Coleira Perdida do Gluth
236301	Mão Consumida do Poder
236302	Olho da Diminuição
236303	Perneiras da Polaridade
236304	Côndrios de Placas da Abominação
236305	Cajado do Crepúsculo
236306	O Castigador
236307	Véu do Eclipse
236308	Ídolo da Longevidade
236309	Cinturão do Mentor
236310	Varinha dos Mortos Sussurrantes
236311	Sinete do Defensor Caído
236312	Iblis, Lâmina do Serafim Caído
236313	Braçadeiras do Ceifador de Almas
236314	Botas do Deslocamento
236315	Capacete Polar
236316	Coleira do Sádico
236317	Vis'era, a Estripadora
236318	Selo do Maldito
236319	Perneiras do Apocalipse
236320	Cordialidade do Perdão
236321	Malho do Cruzado Redimido
236322	Cordão das Almas
236323	Resiliência do Flagelo
236324	Poder do Flagelo
236325	Fortitude do Flagelo
236326	Poder do Flagelo
236327	Manto da Necrópole
236328	Olho Esquerdo do Sapphiron
236329	Olho dos Mortos
236330	Olho Direito do Sapphiron
236331	A Essência Contida de Sapphiron
236333	Mortalha de Domínio
236334	Escudo do Matador
236335	Brafoneiras do Implacável
236336	A Face da Morte
236337	Glifo de Deflexão
236338	Garra da Serpe Gélida
236339	Gressil, o Despertar da Decadência
236340	Poder de Menethil
236341	O Frio Voraz
236342	Talismã da Ebulição de Tempesfúria
236343	Queda do Monarca
236344	Escravizador Nerubiano
236345	Gema dos Inocentes Encurralados
236346	Caçador de Almas
236347	Escudo da Condenação
236348	Martelo de Espiral Etérea
236349	Dedo do Destino
236350	O Filactério de Kel'Thuzad
236351	Marca do Campeão
236352	Marca do Campeão
236354	Selo da Aurora do Aspirante
236355	Selo da Aurora do Iniciado
236356	Selo da Aurora do Escudeiro
236357	Selo da Aurora do Cavaleiro
236358	Selo da Aurora do Templário
236360	Selo da Aurora do Campeão
236361	Selo da Aurora da Vanguarda
236362	Selo da Aurora do Cruzado
236363	Selo da Aurora do Comandante
236364	Selo da Aurora do Grão-lorde
236374	Selo da Aurora do Comandante
236375	Selo da Aurora do Grão-lorde
236376	Selo da Aurora do Cruzado
236378	Selo da Aurora da Vanguarda
236379	Selo da Aurora do Campeão
236380	Selo da Aurora do Templário
236382	Selo da Aurora do Cavaleiro
236383	Selo da Aurora do Escudeiro
236384	Selo da Aurora do Iniciado
236385	Selo da Aurora do Aspirante
236386	Selo da Aurora do Grão-lorde
236388	Selo da Aurora do Comandante
236389	Selo da Aurora do Cruzado
236390	Selo da Aurora da Vanguarda
236391	Selo da Aurora do Campeão
236392	Selo da Aurora do Templário
236393	Selo da Aurora do Cavaleiro
236394	Selo da Aurora do Escudeiro
236395	Selo da Aurora do Iniciado
236396	Selo da Aurora do Aspirante
236397	Vestígio de Bravura
236398	Atiesh, Grande Cajado do Guardião
236399	Atiesh, Grande Cajado do Guardião
236400	Atiesh, Grande Cajado do Guardião
236401	Atiesh, Grande Cajado do Guardião
236414	Caixote de Suprimentos da Inframina Danificado
236417	Alma do Estrategista
236418	Alma do Veterano de Guerra
236419	Alma do Preditor de Batalhas
236420	Alma do Sanguinário
236421	Alma do Titã
236422	Alma do Destruidor
236423	Alma do Ata-morte
236424	Alma do Sanguinista
236425	Alma do Bloqueador Imaculado
236426	Alma do Selvagem
236427	Alma da Hostilidade
236428	Alma do Defletor
236429	Alma do Vingador
236430	Alma do Incessante
236431	Alma do Arauto do Trovão
236432	Alma da Sentinela
236433	Alma do Canhoto
236434	Alma do Gladiador
236435	Alma do Tremor Secundário
236436	Alma do Evasivo
236437	Alma do Toxicologista
236438	Alma do Carrasco
236439	Alma do Oportunista
236440	Alma do Açougueiro
236441	Alma do Fantasma
236442	Alma do Biltre
236443	Alma do Caçador de Emoções
236444	Alma do Sábio da Estocada
236445	Alma do Espreitador
236446	Alma do Eficiente
236447	Alma do Malabarista de Facas
236448	Alma do Mestre das Sombras
236449	Alma do Equilibrista
236450	Alma do Brigão de Prontidão
236451	Alma do Faixa Preta
236452	Alma do Esgrimista
236453	Alma do Espadachim
236454	Alma do Sedento de Sangue
236455	Alma do Transfusor
236456	Alma do Refinado
236457	Alma do Dizimador
236458	Alma do Arauto da Podridão
236459	Alma do Malevolente
236460	Alma do Sombramante
236461	Alma do Emissário do Caos
236462	Alma do Incendiário
236463	Alma do Pastor Infernal
236464	Alma do Lorde-demônio
236465	Alma do Exorcista Demoníaco
236466	Alma do Aflito
236467	Alma do Flamespectro
236468	Alma do Devorador de Carne
236469	Alma do Abissal
236470	Alma do Caosnato
236471	Alma da Lâmina Umbrática
236472	Alma do Ritualista
236473	Alma do Dissemina-dor
236474	Alma do Enganador
236475	Alma do Rapinante
236476	Alma do Atirador de Elite
236477	Alma do Caçador de Perigo
236478	Alma do Alternador
236479	Alma do Toxinologista
236480	Alma do Caçador de Recompensas
236481	Alma do Atirador Truqueiro
236482	Alma do Tratador de Feras
236483	Alma do Mestre dos Cães
236484	Alma do Domador Alfa
236485	Alma do Guarda-caça
236487	Alma do Retaliador
236488	Alma dos Ecos
236489	Alma do Açoitador Letal
236490	Alma do Cineticista
236491	Alma do Estrategista
236492	Alma do Golpeador Mortal
236493	Alma do Curador Apressado
236494	Alma do Refinado
236495	Alma do Celebrante
236496	Alma do Fiel
236497	Alma do Fortuito
236498	Alma do Ressonante
236499	Alma do Devoto
236500	Alma do Arcebispo
236501	Alma do Penitente
236502	Alma do Guardião de Almas
236503	Alma do Andarilho do Crepúsculo
236504	Alma do Rompe-mentes
236505	Alma do Causamortis
236506	Alma da Fonte Espiritual
236507	Alma do Zelote
236508	Alma do Profanador Inabalável
236509	Alma do Desdenhador
236510	Alma do Pestífero
236511	Alma do Reverberante
236512	Alma do Cronocurador
236513	Alma do Anseio Temporal
236514	Alma do Precognitivo
236515	Alma do Arcanista
236516	Alma do Zelador Eterno
236517	Alma do Mesmerizador
236518	Alma do Molda-defesa
236519	Alma das Garras do Inverno
236520	Alma do Criomante
236521	Alma do Conjurante
236522	Alma do Elementalista
236523	Alma do Armoreiro Mágico
236524	Alma do Archótius
236525	Alma da Convergência Ardente
236526	Alma da Chama Perpétua
236527	Alma do Piromaníaco
236528	Alma do Incendiante
236529	Alma do Ateador
236530	Alma do Bloqueador Imaculado
236531	Alma do Protetor da Luz
236532	Alma do Defensor Radiante
236533	Alma do Porta-escudo
236534	Alma do Bastião
236535	Alma do Julgador
236536	Alma do Blindado
236537	Alma do Guardião
236538	Alma do Pacificador
236539	Alma do Refinado
236540	Alma do Exemplar
236541	Alma do Inquisidor
236542	Alma do Soberano
236543	Alma do Dominus
236544	Alma do Vindicante
236545	Alma do Altruísta
236546	Alma do Juiz
236547	Alma do Porta-selos
236548	Alma do Justicar
236549	Alma do Judicante
236550	Alma do Ascendente
236551	Alma do Retribuidor
236552	Alma do Excomungador
236553	Alma do Arauto da Luz
236554	Alma do Exilado
236555	Alma do Templário
236556	Alma do Andarilho do Vento
236557	Alma do Mestre do Escudo
236558	Alma do Protetor Totêmico
236559	Alma do Amortecedor de Choques
236560	Alma do Baluarte Espiritual
236561	Alma do Arauto da Voragem
236562	Alma do Andarilho da Lava
236563	Alma do Verdadeiro Alfa
236564	Alma do Guardião de Totem
236565	Alma dos Antecestrais
236566	Alma do Tece-espíritos
236567	Alma do Andarilho da Água
236568	Alma do Domador de Tempestades
236569	Alma do Vidente Elemental
236570	Alma do Vitalista
236571	Alma do Anjo da Cura
236572	Alma do Refinado
236573	Alma do Chefe
236574	Alma do Enfurecido
236575	Alma do Rompe-procelas
236576	Alma da Tormenta
236577	Alma do Esmagador Sísmico
236578	Alma do Flamarauto
236579	Alma do Vulcão
236580	Alma das Chamas Enraivecidas
236581	Alma do Mestre Elemental
236582	Alma do Nativo
236583	Alma do Espírito-guia
236584	Alma do Ancião
236585	Alma dos Elementos
236586	Alma do Sábio da Lava
236587	Alma do Guardião Ancestral
236588	Alma do Corrompido
236589	Alma da Pata Gentil
236590	Alma do Feroz
236591	Alma do Translocador
236592	Alma do Territorial
236593	Alma da Fera
236594	Alma do Lacerador
236595	Alma do Furioso
236596	Alma do Destroçador
236597	Alma do Inervador
236598	Alma do Alimentador
236599	Alma do Tranquilo
236600	Alma do Andassonho
236601	Alma da Mantenedora do Bosque
236602	Alma do Sábio Emplumado
236603	Alma do Vidente Benevolente
236604	Alma do Tece-vidas
236605	Alma do Iluminador
236606	Alma dos Instintos Predatórios
236607	Alma do Estripador
236608	Alma da Garra
236609	Alma do Orgulhoso
236610	Alma do Bárbaro
236611	Alma do Frenético
236612	Alma do Dessangrador
236613	Alma do Guardião dos Espinhos
236614	Alma do Lunático
236615	Alma do Arauto Estelar
236616	Alma da Noite
236617	Alma dos Guardiões
236618	Alma do Irascível
236619	Alma do Gracioso
236620	Alma do Ascendente Astral
236621	Alma do Evocador de Cometas
236622	Alma da Floresta
236623	Alma de Aptidão Animalesca
236642	Mitenes do Reparador
236643	Luvas do Vigilante Noturno
236644	Protetores de Mão do Enlutado
236645	Manoplas do Brandeluz
236656	Runa Congelada
236657	Galho Apodrecido da Buba
236658	Troféu Espinhal da Buba
236660	Presa de Troll da Buba
236661	Cossolete de Irreverência da Buba
236662	Rédeas da Guerra
236663	Rédeas da Dominação
236664	Rédeas da Morte
236665	Rédeas da Fome
236690	Manto Glacial
236692	Luvas Glaciais
236693	Pulsos Glaciais
236694	Colete Glacial
236695	Peitoral da Perdição Gélida
236696	Braçadeiras da Perdição Gélida
236697	Manoplas da Perdição Gélida
236698	Braçadeiras de Escama Gelada
236699	Peitoral de Escama Gelada
236700	Manoplas de Escama Gelada
236701	Braçadeiras Polares
236702	Túnica Polar
236703	Luvas Polares
236704	Pulsos Gélidos
236705	Luvas Gélidas
236706	Colete Gélido
236707	Túnica de Matar Mortos-vivos
236708	Peitoral de Matar Mortos-vivos
236709	Couraça de Matar Mortos-vivos
236710	Braçadeiras de Matar Mortos-vivos
236711	Munhequeiras de Matar Mortos-vivos
236712	Braçadeiras de Matar Mortos-vivos
236713	Mitenes de Matar Mortos-vivos
236714	Manoplas de Matar Mortos-vivos
236715	Protetores de Mão de Matar Mortos-vivos
236716	Braçadeiras da Purificação de Mortos-vivos
236717	Luvas da Purificação de Mortos-vivos
236718	Veste da Purificação de Mortos-vivos
236719	Braçadeiras da Ablução de Mortos-vivos
236720	Luvas da Ablução de Mortos-vivos
236721	Veste da Ablução de Mortos-vivos
236722	Braçadeiras de Proteção contra Mortos-vivos
236723	Luvas de Proteção contra Mortos-vivos
236724	Veste de Proteção contra Mortos-vivos
236725	Munhecas da Purificação de Mortos-vivos
236726	Mitenes da Purificação de Mortos-vivos
236727	Túnica da Purificação de Mortos-vivos
236728	Munhecas da Ablução de Mortos-vivos
236729	Mitenes da Ablução de Mortos-vivos
236730	Túnica da Ablução de Mortos-vivos
236731	Munhecas de Proteção contra Mortos-vivos
236732	Mitenes de Proteção contra Mortos-vivos
236733	Túnica de Proteção contra Mortos-vivos
236734	Munhequeiras da Purificação de Mortos-vivos
236735	Protetores de Mão da Purificação de Mortos-vivos
236736	Couraça da Purificação de Mortos-vivos
236737	Munhequeiras de Proteção contra Mortos-vivos
236738	Protetores de Mão de Proteção contra Mortos-vivos
236739	Couraça de Proteção contra Mortos-vivos
236740	Munhequeiras da Ablução de Mortos-vivos
236741	Protetores de Mão da Ablução de Mortos-vivos
236742	Couraça da Ablução de Mortos-vivos
236743	Braçadeiras da Ablução de Mortos-vivos
236744	Manoplas da Ablução de Mortos-vivos
236745	Peitoral da Ablução de Mortos-vivos
236746	Braçadeiras de Proteção contra Mortos-vivos
236747	Manoplas de Proteção contra Mortos-vivos
236748	Peitoral de Proteção contra Mortos-vivos
236750	Coração da Ruína
236782	Colar de Sairuh
236786	Coração da Ruína
236864	Aljava de Congelar Alma
236869	Bornal de Munição de Congelar Alma
236871	Sensores de Censura Sinistros
236872	Diagrama: Sensores de Censura Sinistros
236878	Relíquia Misteriosa
236879	Relíquia Misteriosa
236880	Relíquia Misteriosa
237011	Chave da Ponte Levadiça
237020	Insígnia Escarlate
237023	Arbusto Instantâneo
237024	Ingresso para a Ópera
237037	Carteira de Sócio do Clube Granfa
237041	Tomo de Sinalizador Encantado
237143	Ordens da Comandante
237163	Crânio do Guerreiro Antigo
237261	Areia Fina
237263	Sacola de Suprimentos
237275	Capacete da Perdição Gélida
237277	Perneiras Gélidas
237278	O Purificador
237279	Amuleto da Aurora
237280	Medalhão da Aurora
237281	Braçadeiras da Esperança
237282	Braceleiras do Subterfúgio
237283	Talismã da Ascendência
237284	Sacola de Suprimentos
237285	Elo da Resolução
237286	Elo da Devoção
237287	Último Recurso de Verimonde
237288	Elmo Santificado de Couro
237289	Perneiras do Caçador de Pestes
237290	Perneiras da Perdição Gélida
237291	Perneiras Glaciais
237292	Perneiras Polares
237293	Perneiras de Escama Gelada
237294	Toque Frio de Ramaladni
237302	Tabardo do Enclave Escarlate
237381	Anel Profanado
237386	Caixote de Suprimentos da Inframina Belicoso
237504	Remessa de Suprimentos
237512	Lâmina da Inquisição
237577	Totem de Poder Profano
237773	Palavra do Degelo
237810	Pedra de Afiar Consagrada Balanceada
237814	Guarda-pernas Lamelares da Sentinela
237815	Perneiras de Seda da Sentinela
237817	Calças de Couro de Lagarto da Sentinela
237818	Calças de Couro da Sentinela
237819	Perneiras Encadeadas da Sentinela
237820	Perneiras de Seda do Pioneiro
237821	Calças de Couro de Lagarto do Pioneiro
237822	Calças de Couro do Pioneiro
237823	Perneiras de Malha do Pioneiro
237824	Perneiras Encadeadas do Pioneiro
237825	Guarda-pernas de Placa da Sentinela
237826	Guarda-pernas de Placa do Pioneiro
238234	Óleo Abençoado de Teurgo
238241	Pedra de Afiar Consagrada
238264	Capuz do Áugure Escarlate
238265	Dragonas do Áugure Escarlate
238266	Vestimentas do Áugure Escarlate
238267	Manilhas do Áugure Escarlate
238268	Luvetes do Áugure Escarlate
238269	Correia do Áugure Escarlate
238270	Perneiras do Áugure Escarlate
238271	Solas do Áugure Escarlate
238272	Bandana do Infiltrador Escarlate
238273	Ombreiras do Infiltrador Escarlate
238274	Colete do Infiltrador Escarlate
238275	Braçadeiras do Infiltrador Escarlate
238276	Luvas do Infiltrador Escarlate
238277	Cinto do Infiltrador Escarlate
238278	Calçotes do Infiltrador Escarlate
238279	Sapatos do Infiltrador Escarlate
238280	Coifa do Guarda-caça Escarlate
238281	Brafoneiras do Guarda-caça Escarlate
238282	Corrente do Guarda-caça Escarlate
238283	Munhequeiras do Guarda-caça Escarlate
238284	Protetores de Mão do Guarda-caça Escarlate
238285	Fecho do Guarda-caça Escarlate
238286	Guarda-pernas do Guarda-caça Escarlate
238287	Botas do Guarda-caça Escarlate
238288	Capacete do Soldado Escarlate
238289	Espaldares do Soldado Escarlate
238290	Guarda-peito do Soldado Escarlate
238291	Protetores do Soldado Escarlate
238292	Guantes do Soldado Escarlate
238293	Cinta do Soldado Escarlate
238294	Coxotes do Soldado Escarlate
238295	Pisoteadores do Soldado Escarlate
238298	Molde: Capuz do Áugure Escarlate
238299	Molde: Dragonas do Áugure Escarlate
238300	Molde: Vestimentas do Áugure Escarlate
238301	Molde: Manilhas do Áugure Escarlate
238302	Molde: Luvetes do Áugure Escarlate
238303	Molde: Correia do Áugure Escarlate
238304	Molde: Perneiras do Áugure Escarlate
238305	Molde: Solas do Áugure Escarlate
238306	Molde: Bandana do Infiltrador Escarlate
238307	Molde: Ombreiras do Infiltrador Escarlate
238308	Molde: Colete do Infiltrador Escarlate
238309	Molde: Braçadeiras do Infiltrador Escarlate
238310	Molde: Luvas do Infiltrador Escarlate
238311	Molde: Cinto do Infiltrador Escarlate
238312	Molde: Calçotes do Infiltrador Escarlate
238313	Molde: Sapatos do Infiltrador Escarlate
238314	Molde: Coifa do Guarda-caça Escarlate
238315	Molde: Brafoneiras do Guarda-caça Escarlate
238316	Molde: Corrente do Guarda-caça Escarlate
238317	Molde: Munhequeiras do Guarda-caça Escarlate
238318	Molde: Protetores de Mão do Guarda-caça Escarlate
238319	Molde: Fecho do Guarda-caça Escarlate
238320	Molde: Guarda-pernas do Guarda-caça Escarlate
238321	Molde: Botas do Guarda-caça Escarlate
238322	Instruções: Capacete do Soldado Escarlate
238323	Instruções: Espaldares do Soldado Escarlate
238324	Instruções: Guarda-peito do Soldado Escarlate
238325	Instruções: Protetores do Soldado Escarlate
238326	Instruções: Guantes do Soldado Escarlate
238327	Instruções: Cinta do Soldado Escarlate
238328	Instruções: Coxotes do Soldado Escarlate
238329	Instruções: Pisoteadores do Soldado Escarlate
238348	O Machado de Decepar
238349	Perneiras de Pele de Abominação
238350	Adaga Focal de Escarne
238351	A Garra Gélida
238352	Gargantilha Gélida de Escarne
238353	Dragonas da Lady Falther'Essa
238354	Varinha da Lady Falther'essa
238355	Correntes do Lich
238356	Cintel de Balzaphon
238357	Cajado de Balzaphon
238358	Coxa do Umbráxilos
238360	Broquel do Lorde Umbráxilos
238361	Lâmina do Lorde Umbráxilos
238362	Braçadeiras de Recomposição
238363	Soqueira da Sombra
238364	Manto de Revanchion
238637	Bife de Predador
238638	Filé de Lombo
238639	Omelete d'Alvorada
238641	Rega-bofe de Pinamancha
238642	Banquete de Lagosta Grandioso
238645	Receita: Bife de Predador
238646	Receita: Filé de Lombo
238647	Receita: Omelete d'Alvorada
238649	Receita: Rega-bofe de Pinamancha
238650	Receita: Banquete de Lagosta Grandioso
238681	Bolsa Empoeirada
238687	Malho da Ofensiva
238734	Caixa de Gambiarra: Teleporte
238735	Caixa de Gambiarra: Aceleração Nitrosa
238736	Caixa de Gambiarra: Deslocamento Magnético
238737	Caixa de Gambiarra
238781	Transportador Semisseguro: Nova Avalon
238782	Diagrama: Caixa de Gambiarra
238783	Diagrama: Caixa de Gambiarra: Teleporte
238784	Diagrama: Caixa de Gambiarra: Aceleração Nitrosa
238785	Diagrama: Caixa de Gambiarra: Deslocamento Magnético
238786	Diagrama: Gambiarra: Teleporte
238787	Diagrama: Gambiarra: Aceleração Nitrosa
238788	Diagrama: Gambiarra: Deslocamento Magnético
238789	Diagrama: Transportador Semisseguro: Nova Avalon
238794	Sobras Pouco Apetitosas
238811	Maçã Suculenta
238830	Telescópio de Maçã
238831	Corda de Maçã
238899	Peixes Variados
238925	Aljava Escarlate
238926	Bornal de Munição Escarlate
238927	Molde: Aljava Escarlate
238928	Molde: Bornal de Munição Escarlate
238935	Carne Suavemente Empesteada
238945	Caladpedra
238960	Caixote do Intendente
238961	Caladbolg
238985	Caixote Pesado
239010	Punho da Crematória
239011	Estilhaço de Luz Cristalizada
239012	Farpa de Luz Cristalizada
239013	Machado Cristalino
239016	Sais Sagrados
239017	Temperos Requintados
239021	Livro de Receita da Cássia
239060	Vontade da Montanha
239092	Carta de Convocação Canhestra
239097	Chave da Catedral
239117	Cálice do Cruzado
239119	Flecha Sagrada
239147	Mochila do Cruzado
239148	Bolsa Alvorecente Carmesim
239149	Molde: Mochila do Cruzado
239150	Molde: Bolsa Alvorecente Carmesim
239159	S03 - Enclave Escarlate - Escudo do Capitão
239196	Lâmina Forjada em Luz Arruinada
239197	Lâmina Reforjada da Crematória
239215	Emblema Calcinado
239216	Ferro Forjado a Luz
239218	Anotações do Moldapedra
239219	Emblema da Crematória
239221	Monstro - Espada1M, Básica
239222	Diagrama: Arbusto Instantâneo
239223	Adereço Doméstico
239225	Pena Classuda
239246	Lista de Compras do Teleco
239248	Caixa de Tralhas Escarlate
239292	Anotações do Forjífice
239301	A Crematória Corrompida
239302	Cinto do Uniforme Escarlate
239316	Rebimboca de Triangulação
239512	Pulsos do Rompe-luz
239513	Cinto do Rompe-luz
239514	Guantes do Rompe-luz
239515	Grevas do Rompe-luz
239516	Ombreiras do Rompe-luz
239517	Grande Elmo do Rompe-luz
239518	Escarcela do Rompe-luz
239519	Corselete do Rompe-luz
239520	Braçadeiras do Rompe-luz
239521	Cinta do Rompe-luz
239522	Manoplas do Rompe-luz
239523	Escarpes do Rompe-luz
239524	Brafoneiras do Rompe-luz
239525	Capacete do Rompe-luz
239526	Coxotes do Rompe-luz
239527	Peitoral do Rompe-luz
239529	Peitoral do Espreitaurora
239530	Grevas do Espreitaurora
239531	Manoplas do Espreitaurora
239532	Visor do Espreitaurora
239533	Perneiras do Espreitaurora
239534	Brafoneiras do Espreitaurora
239535	Cinto do Espreitaurora
239536	Avambraços do Espreitaurora
239537	Botas do Espreitaurora
239538	Cinturão do Espreitaurora
239539	Protetores de Mão do Espreitaurora
239540	Bacinete do Espreitaurora
239541	Guarda-pernas do Espreitaurora
239542	Espaldares do Espreitaurora
239543	Túnica do Espreitaurora
239544	Munhequeiras do Espreitaurora
239547	Munhequeiras da Aparição do Ocaso
239548	Couraça da Aparição do Ocaso
239549	Guantes da Aparição do Ocaso
239550	Máscara da Aparição do Ocaso
239551	Perneiras da Aparição do Ocaso
239552	Dragonas da Aparição do Ocaso
239553	Botinas da Aparição do Ocaso
239554	Cinto da Aparição do Ocaso
239555	Braçadeiras da Aparição do Ocaso
239556	Cinta da Aparição do Ocaso
239557	Manoplas da Aparição do Ocaso
239558	Escarpes da Aparição do Ocaso
239559	Brafoneiras da Aparição do Ocaso
239560	Capacete da Aparição do Ocaso
239561	Coxotes da Aparição do Ocaso
239562	Peitoral da Aparição do Ocaso
239565	Induto da Revelação
239572	Botas da Revelação
239574	Mãos da Revelação
239575	Coroa da Revelação
239577	Calças da Revelação
239581	Dragonas da Revelação
239582	Cinturão da Revelação
239583	Pulsos da Revelação
239584	Luvas de Revelação
239585	Diadema da Revelação
239586	Ombreiras da Revelação
239587	Perneiras da Revelação
239588	Braceletes da Revelação
239589	Sandálias da Revelação
239590	Cinto da Revelação
239591	Veste da Revelação
239618	Monstro - Espada 1M - Espada do Vencedor (Alt)
239688	Monstro - Lança 2M - Cavalaria Escarlate - Lança
239694	Pacto da Luz
239695	Corcel Escarlate
239696	Punho da Crematória
239698	Tecido Alvorecente
239706	Escarpes Consagrados
239707	Capacete Consagrado
239708	Brafoneiras Consagradas
239709	Coxotes Consagrados
239710	Sandálias Consagradas
239712	Ombreiras Consagradas
239714	Diadema Consagrado
239715	Veste Consagrada
239716	Luvas Consagradas
239718	Cinto Consagrado
239719	Braceletes Consagrados
239721	Perneiras Consagradas
239722	Munhequeiras Consagradas
239726	Botas Consagradas
239729	Bacinete Consagrado
239730	Protetores de Mão Consagrados
239731	Túnica Consagrada
239756	Cinturão Consagrado
239757	Guarda-pernas Consagrados
239758	Espaldares Consagrados
239759	Braçadeiras Consagradas
239760	Cinta Consagrada
239761	Peitoral Consagrado
239762	Manoplas Consagradas
239764	Folhâmina Carmesim
240018	Manual de Gambiarras do Teleco
240020	Guarda-pernas da Inquisição
240021	Espaldares da Inquisição
240022	Botas da Inquisição
240023	Avambraços da Inquisição
240024	Cinto da Inquisição
240025	Placa d'Ombros da Inquisição
240026	Perneiras da Inquisição
240027	Capacete da Inquisição
240028	Luvas da Inquisição
240029	Grevas da Inquisição
240030	Peitoral da Inquisição
240031	Braçadeiras da Inquisição
240032	Cinta da Inquisição
240033	Brafoneiras da Inquisição
240034	Coxotes da Inquisição
240035	Coroa da Inquisição
240036	Manoplas da Inquisição
240037	Escarpes da Inquisição
240038	Couraça da Inquisição
240039	Túnica da Inquisição
240040	Bacinete da Inquisição
240041	Protetores de Mão da Inquisição
240042	Munhequeiras da Inquisição
240043	Cinturão da Inquisição
240044	Munhecas Firafolha
240045	Cinta Firafolha
240046	Dragonas Firafolha
240047	Calças Firafolha
240048	Capuz Firafolha
240049	Luvetes Firafolha
240050	Botas Firafolha
240051	Induto Firafolha
240052	Braceletes Firafolha
240053	Cinto Firafolha
240054	Ombreiras Firafolha
240055	Perneiras Firafolha
240056	Diadema Firafolha
240057	Luvas Firafolha
240058	Sandálias Firafolha
240059	Veste Firafolha
240060	Munhequeiras da Vigia do Caminho
240061	Faixa da Vigia do Caminho
240062	Ombreiras do Vigia do Caminho
240063	Calçotes da Vigia do Caminho
240064	Capucho da Vigia do Caminho
240065	Guantes da Vigia do Caminho
240066	Pisoteadores da Vigia do Caminho
240067	Colete da Vigia do Caminho
240068	Braceletes da Vigia do Caminho
240069	Cordão da Vigia do Caminho
240070	Dragonas da Vigia do Caminho
240071	Kilt da Vigia do Caminho
240072	Capuz da Vigia do Caminho
240073	Contato da Vigia do Caminho
240074	Sandálias da Vigia do Caminho
240075	Couros da Vigia do Caminho
240076	Braçadeiras da Vigia do Caminho
240077	Cinta da Vigia do Caminho
240078	Brafoneiras da Vigia do Caminho
240079	Perneiras da Vigia do Caminho
240080	Adereço da Vigia do Caminho
240081	Manoplas da Vigia do Caminho
240082	Escarpes da Vigia do Caminho
240083	Armadura da Vigia do Caminho
240084	Munhequeiras da Vigia do Caminho
240085	Cinturão da Vigia do Caminho
240086	Espaldares da Vigia do Caminho
240087	Guarda-pernas da Vigia do Caminho
240088	Bacinete da Vigia do Caminho
240089	Protetores de Mão da Vigia do Caminho
240090	Botas da Vigia do Caminho
240091	Túnica da Vigia do Caminho
240092	Túnica Esmagalmas
240093	Botas Esmagalmas
240095	Protetores de Mão Esmagalmas
240096	Bacinete Esmagalmas
240097	Guarda-pernas Esmagalmas
240098	Espaldares Esmagalmas
240099	Cinturão Esmagalmas
240100	Munhequeiras Esmagalmas
240101	Couraça Esmagalmas
240102	Escarpes Esmagalmas
240103	Luvas Esmagalmas
240104	Viseira Esmagalmas
240105	Coxotes Esmagalmas
240106	Brafoneiras Esmagalmas
240107	Cinta Esmagalmas
240108	Braçadeiras Esmagalmas
240109	Abraço Esmagalmas
240110	Grevas Esmagalmas
240122	Mitenes Esmagalmas
240123	Coroa Esmagalmas
240124	Kilt Esmagalmas
240125	Dragonas Esmagalmas
240126	Cordão Esmagalmas
240127	Braceletes Esmagalmas
240128	Armadura Esmagalmas
240129	Botinas Esmagalmas
240130	Guantes Esmagalmas
240131	Capacete Esmagalmas
240132	Cajado de Teste
240134	Perneiras Esmagalmas
240135	Palas Esmagalmas
240136	Cinto Esmagalmas
240137	Avambraços Esmagalmas
240138	Veste Herege
240139	Sandálias Hereges
240140	Luvas Hereges
240141	Capucho Herege
240142	Perneiras Hereges
240143	Ombreiras Hereges
240144	Cinto Herege
240145	Braceletes Hereges
240146	Induto Herege
240147	Protetores de Mão Hereges
240148	Capuz Herege
240149	Calças Hereges
240150	Dragonas Hereges
240151	Cinta Herege
240152	Munhequeiras Hereges
240153	Botas Hereges
240174	Solistra, Presa da Primeira Luz
240195	Espada Invisível
240217	Item de Monstro - Cajado_2M_Cravejado_A_02 - Vermelho
240742	Monstro - 1 M, Espada Curta, Vermelho
240832	Glândula Nivofaciente
240835	Caixote de Suprimentos da Clareira da Lua
240836	Apito de Tessália
240837	Cordas do Destino
240839	Thal'kituun, a Presença Oculta
240841	Guarda do Alto-comandante
240842	Arauto da Podridão Escarlate
240843	Pistola Abre-batalha
240844	Furador de Putriss
240845	Protótipo de Ímã
240846	Sucata Magnética
240848	Detritos de Nordrassil
240849	Cajado da Clareira
240850	Martelo Punho da Luz
240851	Regicida
240852	Cutelo Carmesim
240853	Ruína da Rainha
240854	Misericórdia
240919	Ravagane
240920	Leogan
240921	Esmagatória Escarlate
240922	Engano
240923	Duplicidade
240924	Acha-de-armas da Fera
240925	Experimento-800M
240936	Crematória Inerte
240945	Fatia da Torta de Maçã da Cássia
240997	Espora de Fraga
240998	Lâmina Soporífica
241001	Queda de Tyr
241002	Resquícios da Vermelha
241003	Miragem, Bastão da Ilusão
241004	Enigma
241006	Pináculo do Sacrifício
241008	Condenação
241011	Grande Cajado da Lealdade
241012	Varinha da Reanimação
241015	Égide do Bastião Escarlate
241017	Desatino do Demônio
241018	Coração Nathrezim
241020	Diário Completo de Putriss
241021	A Luz
241022	Manto d'Alvorada
241023	Clâmide da Discórdia
241024	Capa do Comandante Escarlate
241025	Bandeira do Almirante Alquebrado
241026	Xale do Cardeal
241027	Guarda da Protetora Escudeira
241028	Aro Nathrezim
241029	Elo de Baelin
241030	Anel da Confraria de Alvano
241031	Promessa de Bartolomeu
241032	Anel da Ressurreição
241034	Coração de Luz
241037	Experimento Abandonado
241038	Didjeridu de Sir Dornel
241039	Infusão de Almas
241068	Estandarte de Estephânio
241069	Gargantilha Encadeada
241070	Esperança de Herodes
241071	Talismã do Vigarista Escarlate
241072	Ampola de Pus
241073	Toque da Luz
241074	Elmo do Cruzado Vermelho
241075	Elmo do Destruidor em Fúria
241076	Capucho do Pacto
241077	Chapéu do Cardeal
241078	Mortalha do Embalsamado
241079	Peso do Mundo
241080	Brafoneiras de Herodes
241081	Crematória Corrompida
241082	Crematória
241083	S03 - Enclave Escarlate - Espada de 2M - Raide
241084	S03 - Scarlet Enclave - Herod's Sword - Normal
241085	S03 - Enclave Escarlate - Espada de 1M
241086	Escudo Torreão Escarlate
241087	Cajado Escarlate
241088	Cajado Escarlate
241089	Adaga Escarlate
241090	Machado Grande Escarlate
241091	Maça Escarlate
241092	Gume Escarlate
241120	S03 - Scarlet Enclave - Herod's Sword - Molten
241121	Adaga Renascida
241122	Faca Renascida
241123	Adaga Renascida
241124	Faca Renascida
241128	Pilha de Porteflexes
241152	Omoplatas Forjaurora
241153	Dragonas de Doan
241154	Dragonas Pele de Urso
241156	Vestes Pestilentas
241157	Guarda-peito Escarlate
241158	Corrente dos Abandonados
241159	Induto do Monastério
241160	Malha de Anéis Vestida à Aurora
241161	Peitoral Templário
241162	Couros Bênção do Sol
241163	Braçadeiras Ardessol
241164	Couros Argênteos Arranhados
241165	Munhequeiras Penitentes
241166	Embraces Listras d'Aurora
241167	Grilhões de Prisioneiro
241168	Guantes Ardessol
241169	Protótipo de Aceleração Nitrosa
241170	Protetores do Enclave
241171	Luvas das Almas Partidas
241172	Manoplas Trancadas de Caldoran
241173	Cingidouro do Grão Teurgo
241174	Cinturão do Campeão Renascido
241175	Cinto de Ferramentas do Torturador
241176	Fim de Diesalven
241177	Kilt do Arcanista Escarlate
241178	Placa da Dor Impávida
241179	Perneiras da Catástrofe
241180	Perneiras de Escama da Luz
241181	Perneiras Encadeadas Vestidas à Aurora
241182	Guarda-pernas de Placa Templário
241183	Trilha-cinzas
241184	Sandálias do Salvador
241185	Botas de Treinamento de Urso
241186	Botas de Malha Polidas Escarlates
241187	Botinas Bélicas Carmesins
241190	Apito de Pássaro
241191	Fórmula: Encantamento do Grande Cruzado - Arma
241195	Fórmula: Encantamento de Grande Feiticeiro - Arma de 2M
241201	Fórmula: Encantamento de Grande Feiticeiro - Arma
241212	Cocoricanhão
241241	Dobrão da Sorte
241613	Não Tem Mais Utilidade
241629	Bala de Canhão Escarlate
241649	Manoplas da Guarda de Eira dos Montes
241650	Poção Elevada Descolorida de Cura
241651	Receita: Poção Elevada Descolorida de Cura
241652	Coração Animal Descorado
241653	Lâmina Aquecida
241654	Crematória Inerte
241655	Poção de Cura Mal Manejada
241656	Poção de Cura Mal Manejada
241657	Lâmina Temperada
242018	Coração-sangrento das Terras Pestilentas
242224	Cesta de Corações
242256	Algibeira de Bombas Incendiárias
242257	Amostra Alquímica Misteriosa
242258	Anotações de Pesquisa
242266	Mundo das Proteções
242267	De Arcanista a Arquimago
242268	Encantamento Dado a Um Cruzado
242269	Inteligência do Grande Feiticeiro
242270	Inteligência do Grande Arcanista
242271	Inteligência do Grande Cruzado
242310	Mão da Justiça Renascida
242311	Amuleto de Leonid
242312	Selo da Família Bartolomeu
242313	Diário do Venerado
242314	Cinzas do Cruzado Caído
242315	Cinzas da Arrogância
242316	Pó do Desafiador
242317	Livro de Orações Profanado
242319	Amostras da Nova Peste
242320	Amostras da Nova Peste
242361	Fórmula: Encantamento de Grão-inquisidor - Arma de 2M
242362	Inteligência do Grão-inquisidor
242363	Quem, O Que, Onde, Quando e Morra! Cinco Chaves para a Melhor Inquisição
242364	Tendão de Dragão da Luz Maduro
242365	Asa de Balnazzar
242366	Destino Inescapável
242367	Asa e Corda
242425	Diário Rasgado, Página 1
242426	Diário Rasgado, Página 2
242427	Diário de Putriss
242428	Diário Rasgado, Página 3
242429	Diário de Putriss
242430	Diário Rasgado, Página 4
242431	Diário Rasgado, Página 5
242432	Diário de Putriss
242433	Diário Rasgado, Página 6
242434	Diário de Putriss
242435	Diário de Putriss
242436	Diário de Putriss
242465	Fragmento do Cálice Impelido
242793	Canhão Vil Portátil
243010	Crematória Corrompida
243064	Cajado Longo
243065	Varinha Quebrada
243177	Brinquedo Engenhoso
243198	Mira de Precisão Aviária
243229	Pedra de Regresso da Aurora
243230	Lâmina Forjada em Luz Arruinada
243345	Cajado Longo
244353	Mira de Precisão Aviária
244460	Caladbolg
245675	Chave da Porta de Dentro dos Gordok
246055	Guantes da Inquisição
246056	Braçadeiras da Inquisição
246057	Pisoteadores da Inquisição
246058	Calças de Placa da Inquisição
246059	Cordão da Inquisição
246060	Corselete da Inquisição
246061	Palas da Inquisição
246062	Viseira da Inquisição
]==]
