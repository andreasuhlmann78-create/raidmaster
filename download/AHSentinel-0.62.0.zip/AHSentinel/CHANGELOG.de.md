# AHSentinel (früher AH Analyzer Pro) – Änderungen (deutsch)

Diese Datei ist die deutsche Zusammenfassung für Discord. Die ausführliche englische Fassung steht in CHANGELOG.md.

## 0.62.0

**AH Analyzer Pro heißt jetzt AHSentinel** – passend zur Sentinel-Familie (BuffSentinel, GuildSentinel, ThreatSentinel).

- **Deine Daten werden automatisch übernommen:** In der ZIP sind der neue Ordner `AHSentinel` und ein kleiner Ordner `AHAnalyzerPro`, der beim ersten Start nur deine alten Daten (Preise, Buchhaltung, Listen, Sniper-Ziele, Einstellungen) übergibt. Danach kannst du `AHAnalyzerPro` löschen.
- **Neuer Befehl `/ahs`** (auch `/ahsentinel`); `/ahp` geht weiterhin.
- Sonst bleibt alles gleich.

**Installieren:** beide Ordner aus der ZIP nach `Interface\AddOns` kopieren (den alten Ordner `AHAnalyzerPro` überschreiben), Spiel starten, fertig.

## 0.61.2

- **Eine Sprache für alles:** Item-Namen folgen jetzt der Sprache des Addons (außer du hast eine eigene Sprache für Item-Namen gewählt), und der Tooltip zeigt den Item-Namen in dieser Sprache, wenn sie von der Sprache des Spiels abweicht.
- **Sprachwechsel baut jedes Fenster neu auf:** neben dem Hauptfenster auch „Heute tun“, das Test-Fenster, die Regeln für „Post an Twinks“ und die Leiste am Briefkasten (auch bei offenem Briefkasten).
- **Selbsttest:** neue Prüfung „Sprachwechsel“ – jede Sprache des Addons einmal, danach mehrfach hin und her; Fenster, Reiter, Texte, Item-Namen und Tooltip müssen in der gewählten Sprache erscheinen, danach ist die alte Sprache wieder eingestellt.

## 0.61.1

- **Behoben: „Heute tun“ schlug unrealistische Käufe vor.** Seiten-Scans sehen oft nur einen Teil des Auktionshauses – das sah aus wie riesige Verkäufe. Verkäufe pro Tag werden jetzt nur noch zwischen **vollständigen** Scans geschätzt, jeder Rückgang zählt nur zur Hälfte (der Rest ist abgelaufen oder zurückgezogen), und es wird nie mehr als die Hälfte der üblichen Angebotsmenge angenommen. Auch „seit Scan“ vergleicht nur noch vollständige Scans.
- **Kapitalschutz:** Jeder Vorschlag in „Heute tun“ nutzt höchstens 20 % deines Golds, alle zusammen höchstens die Hälfte; das Fenster zeigt den Kapitalbedarf. Der Selbsttest prüft das.
- **Übersicht:** Anstiege auf ein Vielfaches des Marktwerts und Rückgänge von einem früheren Mondpreis erscheinen nicht mehr.
- **Briefkasten:** Die Knöpfe des Addons sitzen jetzt ordentlich in einer Leiste **neben** dem Briefkasten statt über dessen Rahmen. „Alles abholen“ gibt es nur, wenn WoW kein eigenes „Alle öffnen“ hat (und im Testmodus für die Test-Post), „Anhalten“ nur während des Abholens.
- **Ein Geldfeld statt drei:** „5s“, „1g 20s“, „4s 85k“ oder „1.5“ (= 1g 50s) eintippen; bei einer reinen Zahl steht dabei, wie sie verstanden wird („= 5g“). Kein Silber mehr im Gold-Feld.
- Kleinigkeiten: „Bieten“ ohne gewähltes Angebot sagt das, die Händler-Warnung beim Einstellen kommt nur noch, wenn es um etwas geht (mind. 1 Silber und 10 %), fiktive Auktionen erscheinen im Testmodus sofort, das Fenster „Heute tun“ schließt beim Sprung in den Reiter.

## 0.61.0

**Mehr Gewinn, weniger Schein-Schnäppchen:**

- **„Heute tun“** (Knopf in der Übersicht, `/ahp heute`): die Aktionen, die gerade am meisten Gold bringen, sortiert nach geschätztem Netto-Gewinn – unter Händlerpreis kaufen, Flips, Taschen verkaufen, unterbotene Auktionen, Neu einstellen, Entzauber- und Gebots-Schnäppchen. Ein Klick auf eine Zeile führt direkt in den passenden Reiter.
- **Verkaufbarkeit statt Angebotspreisen:** Aus deinen Scans schätzt das Addon jetzt, wie viel sich von einem Item wirklich pro Tag verkauft und ob man dem Marktwert trauen kann. Selten angebotene Items und **Mondpreise** (z. B. 2499g 99s 99c) erscheinen nicht mehr bei Schnäppchen, Flips und in der Übersicht (Knopf „auch unsichere“ zeigt sie trotzdem). Schnäppchen sind nach **Gewinn pro Tag** sortiert, der Tooltip zeigt „~N/Tag verkauft (geschätzt)“.
- **Netto-Gewinn mit Einstellgebühr:** Im klassischen Auktionshaus wird die Gebühr jetzt aus dem Händlerpreis geschätzt („ca.“) und beim ersten echten Einstellen genau gelernt. Gewinne ziehen die Gebühr ab, die bei Rücklauf verloren geht (nach deiner eigenen Verkaufsquote).

## 0.60.11

- **Briefkasten-Knöpfe antworten immer:** „Post abgeholt: …“ erscheint jetzt auch in der Bildschirmmitte, und ein leerer Briefkasten meldet „Nichts zum Abholen“, statt still zu bleiben.
- **„An Twinks“ ohne Regel** sagt das im Chat, bevor sich das Regel-Fenster öffnet.
- **Testmodus:** Der fiktive Brief „Auktion erfolgreich“ gehört jetzt zur verkauften fiktiven Auktion, und diese verschwindet aus „Meine Auktionen“, sobald der Erlös abgeholt ist – wie im Spiel.

## 0.60.10

- **Testmodus mit fiktiven Auktionen:** „Meine Auktionen“ zeigt im Test drei fiktive Auktionen (eine unterboten, eine günstigste, eine verkauft) und alles, was du im Test einstellst – Abbrechen und Unterbietung prüfen lassen sich so ohne echte Auktion ausprobieren. Der Selbsttest nimmt fürs Abbrechen eine fiktive Auktion, wenn du keine hast.
- **Test-Briefkasten:** Im Testmodus arbeiten die Briefkasten-Knöpfe des Addons mit fiktiver Post (verkauft, gewonnen, abgelaufen, abgebrochen, überboten, ein normaler Brief): automatisch abholen, „Alles“, Rechnungen in der Buchhaltung und „Neu einstellen“ lassen sich ausprobieren – deine echte Post bleibt unberührt.
- **Einkauf:** Beim Wechsel zu einem anderen Item werden Gebotsfeld und gewähltes Angebot zurückgesetzt (kein altes Gebot mehr im Feld). Die Kopfzeile zeigt günstigstes Angebot und Marktwert (Median 14 Tage) getrennt und sagt, wenn noch weitere Angebote geladen werden.
- **Sniper:** Angebote des vorigen Ziels stehen nicht mehr unter dem Namen des neuen.
- **Selbsttest:** Der Sniper-Test „kauft“ (simuliert) den kleinsten Stapel statt eines 2er-Stapels.
- **Preisverlauf:** lässt sich jetzt auch am Titel verschieben.

## 0.60.9

- **Meldung, wenn der Scan fertig ist:** groß in der Bildschirmmitte („AH-Scan fertig: N Items“) und mit Ton (wenn in den Optionen der Ton an ist) – du musst nicht mehr auf den Chat schauen. Ein Scan ohne Ergebnis wird dort ebenfalls gemeldet.

## 0.60.8

- **Behoben: keine Preiszeilen im Tooltip** auf manchen Clients (z. B. TBC Anniversary). Das Addon hängt sich jetzt an alle Wege, über die WoW einen Item-Tooltip füllt, und passt die Größe nach seinen Zeilen an. Der Selbsttest prüft jetzt den echten Taschen-Tooltip.
- **Esc schließt nur das oberste Fenster:** z. B. den Preisverlauf – Addon-Fenster und Auktionshaus bleiben offen (vorher ging mit einem Esc alles zu).
- **Preisverlauf:** Das X liegt nicht mehr auf dem Knopf „Alles“.
- **Testmodus** setzt jetzt auch Favoriten im Einkauf, die Liste zum Neu-Einstellen und die Post-Regeln zurück.
- **Deine eigene Suche geht vor:** Eine laufende Wächter-Runde wird abgebrochen, der Einkauf wartet nicht mehr („Warte auf den Wächter …“).
- Einkauf zeigt nach dem Kauf „Gekauft: …“ statt „Kauf wird ausgeführt …“.
- Übersicht: Preissprünge um das Zehnfache (fast immer Fehldaten) erscheinen nicht mehr als Anstieg oder Rückgang.
- Kleinigkeiten: Sniper-Käufe heißen im Testmodus-Protokoll „Sniper-Kauf“, die Einkaufslisten geben nach dem Löschen die Tastatur frei, „N Einträge“ überlappt nicht mehr, Option heißt kurz „Ablauf-Erinnerung“, Einstellgebühr im klassischen AH „beim Einstellen“ statt „?“, iLvl-Hinweis nur bei vorhandenen Treffern, Mausrad im Berichtsfenster schneller, Titel „Testbericht“.

## 0.60.7

- **Neuer Knopf „Test“** oben im Fenster (und in der Leiste im Auktionshaus): Selbsttest und der neue **Testmodus** in einem Fenster.
- **Testmodus:** Alle Funktionen von Hand mit deinen echten Auktionshaus-Daten ausprobieren – Kaufen, Bieten, Sniper (auch mit dem Mausrad), Einstellen, Abbrechen, Händler-Verkauf, Post abholen und verschicken. Jeder Handel ist **nur simuliert**: Der Befehl an den Server wird abgefangen und die Antwort des Servers nachgespielt – Meldungen, Buchhaltung und Sniper-Zähler verhalten sich wie echt. Beim Beenden sind alle Einstellungen und Daten (Listen, Buchhaltung, Sniper, Wächter, Verkaufen) wieder wie vorher – auch automatisch nach `/reload` oder einem Absturz. Ein Protokoll zeigt jede simulierte Aktion und kommt mit in den kopierten Bericht.
- ⚠️ Nur die Knöpfe des Addons sind simuliert – Blizzards eigene Knöpfe im Auktionshaus kaufen weiterhin echt. Auch: `/ahp testmodus`.

## 0.60.6

- **Selbsttest simuliert echten Handel:** Mit den echten Angeboten aus dem Auktionshaus spielt er jetzt Sofortkauf, Gebot, Sniper-Kauf, Einstellen und Abbrechen genau wie im Ernstfall durch – gleiches Angebot, gleicher Preis, gleicher Befehl. Nur der Befehl an den Server wird abgefangen: Es wird nichts gekauft, eingestellt oder abgebrochen, und am Ende prüft der Test, dass dein Gold unverändert ist. Meldungen im Chat sind dabei mit „[Simulation]“ markiert.
- **Selbsttest:** Der Wächter wird nach seiner Testrunde gleich wieder ausgeschaltet und blockiert die folgenden Server-Suchen nicht mehr.

## 0.60.5

- **Behoben (klassische Clients):** Beim Öffnen des Auktionshauses konnte der Lua-Fehler „attempt to compare number with nil“ kommen (Gebote nach einem Reload).
- **Kopfzeile:** „Sniper: an/aus“ und „Wächter: an/aus“ stimmen jetzt immer, auch nach dem Umschalten.
- **Selbsttest:** Läuft im Hintergrund noch ein Markt-Scan, laufen die Server-Suchen nicht mehr alle in die Zeitüberschreitung – beim Test mit gespeicherten Daten wird der Scan beendet, sonst wird auf ihn gewartet. Ein neuer Scan ist während des Tests gesperrt.
- **Selbsttest:** Danach sind Einstellungen, Wächter und Fenster (Reiter, oder geschlossen) zuverlässig wie vorher. Klappt etwas nicht, steht es im Bericht.
- **Textfenster** („Bericht kopieren“) öffnet sich immer vorne, beginnt oben und scrollt mit dem Mausrad zügig (mit Shift in großen Schritten).

## 0.60.4

- **Selbsttest mit gespeicherten Daten:** neuer Knopf „Mit gespeicherten Daten“ im Selbsttest-Fenster (oder `/ahp test daten`). Er testet mit den Auktionshaus-Daten, die du schon gescannt hast – **kein neuer Scan**. Er läuft sogar bei geschlossenem Auktionshaus, dann werden nur die Suchen beim Server übersprungen.

## 0.60.3

- **Behoben für TBC Anniversary (und andere klassische Clients):** „Meine Auktionen“ wurde nie aktualisiert, und manche Meldungen des Auktionshauses (z. B. „eingestellt“) kamen nicht an. Diese Clients kennen die Ereignis-Namen des neuen Auktionshauses, lösen sie beim klassischen aber nie aus – das Addon nutzt dort jetzt immer seine eigenen. Gefunden mit dem neuen Selbsttest.
- **Selbsttest:** Der kopierte Bericht lässt sich jetzt scrollen, die Ergebnisliste ist breiter – Maus über eine Zeile zeigt den ganzen Text.

## 0.60.2

- **Selbsttest:** Optionen → „Selbsttest“ oder `/ahp test` prüft alle Funktionen mit echten Daten aus deinem Auktionshaus: Markt-Scan (falls nötig), Marktdaten, alle Reiter, alle Auswertungen und echte Suchen beim Server (Einkauf, Preisprüfung, Sniper, Wächter, eigene Auktionen). Während des Tests sind **Kaufen, Bieten, Einstellen und Abbrechen gesperrt**, danach sind Einstellungen und Sniper-Ziele wie vorher. Das Ergebnis erscheint in einem Fenster, lässt sich als Bericht kopieren und wird gespeichert.

## 0.60.1

- **Echter Minikarten-Knopf:** Der Knopf sitzt jetzt wie bei anderen Addons an der Minikarte – mit der Maus **rund um die Minikarte ziehen**, die Position wird gespeichert. Funktioniert mit runden und eckigen Minikarten. Ein-/ausblenden in den Optionen oder mit `/ahp minimap`, `/ahp reset` holt ihn zurück.
- **Neues Icon:** eine goldene **Waage** – am Minikarten-Knopf, oben im Fenster und in der Addon-Liste.

## 0.60.0

**Aufgeräumtes Fenster – 5 Reiter statt 11:**

- **Übersicht · Kaufen · Verkaufen · Markt · Buchhaltung.** Was zusammengehört, steht jetzt als Unterreiter:
  Kaufen = Einkauf, Sniper, Wächter, Schnäppchen · Verkaufen = Einstellen, Meine Auktionen · Markt = Alle Preise, Watchlist.
  Alle Funktionen sind noch da, nichts ist weggefallen.
- **Preisverlauf im eigenen Fenster:** Ein Klick auf ein Item öffnet den Verlauf neben dem Addon – die Liste, aus der du kommst, bleibt genau, wo sie war. Das Fenster lässt sich verschieben und in der Größe ziehen.
- **Sniper und Wächter in der Kopfzeile:** auf einen Blick sehen, ob sie laufen, und mit einem Klick an- oder ausschalten (Rechtsklick öffnet ihren Reiter).
- **Merkt sich, wo du warst:** Das Addon öffnet sich im zuletzt benutzten Reiter, jeder Haupt-Reiter merkt sich seinen Unterreiter.

## 0.59.33

**Komfort-Update – zwölf kleine Dinge, die jeden Tag Klicks sparen:**

- **Stapelgröße und Anzahl Stapel** (klassisches Auktionshaus): z. B. 5 Stapel à 20 – wird pro Item gemerkt, auch für die Serie.
- **Post automatisch abholen:** Beim Öffnen des Briefkastens wird die Auktionspost gleich abgeholt (Shift beim Öffnen = diesmal nicht).
- **Mindestpreis pro Item:** Knopf „Min“ beim Verkaufen – darunter wird nie unterboten, die Serie wartet statt billig zu verkaufen.
- **Nur was mir fehlt:** Am Berufsfenster kommt nur die fehlende Menge auf die Einkaufsliste (Taschen, Bank und Twinks werden gezählt).
- **Alt-Klick auf ein Item** in den Taschen oder im Chat: öffnet den Preisverlauf, bei offenem Auktionshaus den Einkauf.
- **Verkaufschance im Tooltip:** wie viel von dem, was du eingestellt hast, verkauft wurde und wie lange es meist dauert.
- **Erinnerung bei ablaufenden Auktionen** und beim Einloggen, was seit dem letzten Besuch abgelaufen ist.
- **Favoriten im Einkauf:** Suchen speichern und mit einem Klick wieder ausführen.
- **Gold-Ziel** für alle Charaktere zusammen (Optionen oder `/ahp ziel 5000`).
- **Gildenbank-Wert** in der Buchhaltung (ab TBC).
- **Raid-Vorrat:** Einkaufsliste mit Tränken, Fläschchen, Elixieren und Buff-Food für eine Raidwoche (`/ahp raid`).
- **Preis-Sync nur mit der Gilde** als neue Option.

## 0.59.32

- **Keine absurden Gewinne mehr:** Items mit 1000 % Gewinn oder mehr (fast immer Fehldaten) erscheinen nicht mehr bei den Schnäppchen und nicht mehr unter „Größte Preisanstiege“.

## 0.59.31

- **Itemlevel als Suchfilter:** Felder „iLvl ab / bis“ im Einkauf und im Markt – filtern sofort, ohne neue Suche beim Server.

## 0.59.30

- **Schrott beim Händler verkaufen** mit einem Knopf (graue Items und alles, was beim Händler mehr bringt).
- **Vermögen:** Wert von Taschen, Bank und Twinks plus das Gold aller Charaktere.
- **Tagesbilanz beim Einloggen**, jederzeit mit `/ahp bilanz`.
- **Neu einstellen mit einem Klick** für abgelaufene Auktionen.
- **Flip-Empfehlungen**, **Post an Twinks**, **/ahp help** im Chat.
- Einkauf: iLvl für jedes Item · Verkaufen: Angebote erscheinen viel schneller.
