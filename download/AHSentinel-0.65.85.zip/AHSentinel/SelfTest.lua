if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 0.62.0 - Selbsttest im Spiel
-- Prüft alle Funktionen mit echten Daten aus dem Auktionshaus:
--   Scan (falls nötig), Marktdaten, alle Reiter, Auswertungen, echte Suchen
--   (Einkauf, Preisprüfung, Sniper, Wächter, eigene Auktionen).
-- Sicher: Während des Tests sind Kaufen, Bieten, Einstellen und Abbrechen gesperrt.
-- Einstellungen, Sniper-Ziele und Schalter werden danach wiederhergestellt.
-- Start: Optionen -> Selbsttest, oder /ahs test
-- Ergebnis: Fenster mit allen Prüfungen, Chat-Zusammenfassung, gespeichert in
--   AHSentinelDB.selftest (WTF\Account\...\SavedVariables\AHSentinel.lua)
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local ST = {}
A.SelfTest = ST
local TM = { active = false, log = {} }   -- Testmodus (unten)
A.TestMode = TM

ST.SCAN_FRESH = 20 * 60        -- jüngerer Scan wird wiederverwendet
ST.SCAN_TIMEOUT = 15 * 60      -- so lange höchstens auf den Scan warten
ST.QUERY_TIMEOUT = 45          -- Server-Suchen
ST.running = false

local function Now() return GetTime() end
local function short(v) local s = tostring(v); if #s > 300 then s = s:sub(1, 297) .. "..." end return s end

-- ------------------------------------------------------------
-- Schutz: Kaufen, Bieten, Einstellen, Abbrechen während des Tests sperren
-- ------------------------------------------------------------
local BLOCK = {
    { "Sniper", "Buy" }, { "Sniper", "Reserve" }, { "Sniper", "Confirm" },
    { "Buy", "BuyItem" }, { "Buy", "PlaceBid" }, { "Buy", "StartCommodity" }, { "Buy", "ConfirmCommodity" },
    { "Seller", "Post" }, { "Seller", "Cancel" }, { "Seller", "BatchStep" }, { "Seller", "CancelNextUndercut" },
}

-- Alle Befehle, mit denen das Spiel wirklich kauft, bietet, einstellt oder abbricht.
-- Während des ganzen Tests landen sie nur im Protokoll (ST.tradeLog) - beim Server kommt nichts an.
local TRADE_FUNCS = { "PlaceBid", "StartCommoditiesPurchase", "ConfirmCommoditiesPurchase", "CancelCommoditiesPurchase",
    "PostItem", "PostCommodity", "CancelAuction" }

-- ------------------------------------------------------------
-- Fiktive eigene Auktionen (Testmodus und Selbsttest): stehen hinter den echten in
-- "Meine Auktionen" und lassen sich (simuliert) abbrechen - ohne echte Auktion.
-- ------------------------------------------------------------
local FAKE_ID0 = 990000000
local fakeSeq = 0
function ST.FakeAuction(itemID, qty, unitPrice, sold)
    fakeSeq = fakeSeq + 1
    local soldStatus = (Enum and Enum.AuctionStatus and Enum.AuctionStatus.Sold) or 1
    return {
        auctionID = FAKE_ID0 + fakeSeq, isFake = true,
        itemKey = { itemID = itemID, itemLevel = 0, itemSuffix = 0, battlePetSpeciesID = 0 },
        itemLink = "item:" .. itemID, quantity = qty or 1,
        buyoutAmount = math.max(1, math.floor((unitPrice or 1) * (qty or 1))),
        status = sold and soldStatus or 0, timeLeftSeconds = 24 * 3600,
    }
end
function ST.IsFakeAuction(id) return type(id) == "number" and id > FAKE_ID0 and id < FAKE_ID0 + 1000000 end

local function AddOwnedOverrides(proxy, real, getFakes)
    if not (real.GetNumOwnedAuctions and real.GetOwnedAuctionInfo) then return end
    local function realN()
        local ok, n = pcall(real.GetNumOwnedAuctions)
        return ok and n or 0
    end
    proxy.GetNumOwnedAuctions = function() return realN() + #getFakes() end
    proxy.GetOwnedAuctionInfo = function(i)
        local n = realN()
        if i <= n then return real.GetOwnedAuctionInfo(i) end
        return getFakes()[i - n]
    end
    proxy.CanCancelAuction = function(id)
        for _, f in ipairs(getFakes()) do if f.auctionID == id then return f.status == 0 end end
        -- fremde fiktive (z. B. Selbsttest im Testmodus) entscheidet die Ebene darunter
        if real.CanCancelAuction then return real.CanCancelAuction(id) end
        return not ST.IsFakeAuction(id)
    end
end
local function RemoveFake(list, id)
    for i = #list, 1, -1 do if list[i].auctionID == id then table.remove(list, i); return true end end
    return false
end
ST.AddOwnedOverrides, ST.RemoveFake = AddOwnedOverrides, RemoveFake

function ST:InstallTradeGuard()
    local real = A.AH
    if not real or self.realAH then return end
    self.realAH = real
    self.tradeLog = {}
    local proxy = {}
    for _, f in ipairs(TRADE_FUNCS) do
        if real[f] then   -- nur was der Client wirklich kann, sonst ändern sich die Wege im Addon
            proxy[f] = function(...)
                table.insert(ST.tradeLog, { fn = f, args = { ... }, time = Now() })
            end
        end
    end
    self.fakeOwned = {}
    AddOwnedOverrides(proxy, real, function() return ST.fakeOwned or {} end)
    A.AH = setmetatable(proxy, { __index = real })
end

function ST:RemoveTradeGuard()
    if self.realAH then A.AH = self.realAH; self.realAH = nil end
    self.fakeOwned = nil
end

-- echte (nicht gesperrte) Funktion eines Moduls - nur für die Handels-Simulation
function ST:RealFn(modName, fnName)
    return self.realFn and self.realFn[modName .. "." .. fnName] or A[modName][fnName]
end

function ST:Lock()
    self.saved = {}
    self.realFn = {}
    self:InstallTradeGuard()
    for _, b in ipairs(BLOCK) do
        local mod = A[b[1]]
        if mod and type(mod[b[2]]) == "function" then
            self.saved[b] = mod[b[2]]
            self.realFn[b[1] .. "." .. b[2]] = mod[b[2]]
            mod[b[2]] = function() return false, L["Selbsttest läuft - Kaufen und Einstellen sind gesperrt."] end
        end
    end
    -- Ein Markt-Scan mitten im Test blockiert alle Suchen beim Server: solange gesperrt
    -- (der Test selbst startet ihn bei Bedarf über ST.origScan)
    self.origScan = A.StartFullScan
    A.StartFullScan = function()
        A:Print(L["Selbsttest läuft - ein Markt-Scan ist solange gesperrt."])
        return false
    end
end

function ST:Unlock()
    for b, fn in pairs(self.saved or {}) do A[b[1]][b[2]] = fn end
    self.saved = nil
    if self.origScan then A.StartFullScan = self.origScan; self.origScan = nil end
    self.realFn = nil
    self:RemoveTradeGuard()
end

-- Zustand sichern / wiederherstellen
function ST:SaveState()
    local s = {}
    s.armed = A.Sniper and A.Sniper:IsArmed()
    s.watcher = A.Watcher and A.Watcher:IsEnabled()
    s.targets = {}
    for k, v in pairs(A.db.sniper and A.db.sniper.targets or {}) do s.targets[k] = v end
    s.tab = A.UI.activeTab
    s.uiShown = A.UI:IsVisible()
    s.lastSub = {}
    for k, v in pairs(A.db.settings.lastSub or {}) do s.lastSub[k] = v end
    s.lastTab = A.db.settings.lastTab
    s.uiLanguage = A.db.settings.uiLanguage
    s.nameLocale = A.db.settings.nameLocale
    s.helpSeen = A.db.settings.helpSeen          -- das erste Öffnen des Fensters zeigt sonst die Willkommens-Hilfe "gesehen"
    self.state = s
end

function ST:RestoreState()
    local s = self.state
    if not s then return end
    self.state = nil
    -- jeder Teil einzeln: ein Fehler in einem Teil darf die anderen nicht überspringen
    local problems = {}
    local function part(name, fn)
        local ok, err = pcall(fn)
        if not ok then table.insert(problems, name .. ": " .. tostring(err)) end
    end
    part("Wächter", function()
        if A.Watcher and A.Watcher:IsEnabled() ~= (s.watcher and true or false) then A.Watcher:SetEnabled(s.watcher) end
    end)
    part("Sniper", function()
        if not A.Sniper then return end
        A.db.sniper.targets = s.targets
        A.Sniper.result = nil
        if (A.Sniper:IsArmed() and true or false) ~= (s.armed and true or false) then A.Sniper:SetArmed(s.armed and true or false) end
    end)
    part("Einkauf", function() if A.Buy and A.Buy.detail then A.Buy:Back() end end)
    part("Fenster", function()
        for _, k in ipairs({ "chartWin", "listsWindow", "options", "helpWindow", "todayWin" }) do
            if A.UI[k] then A.UI[k]:Hide() end
        end
        if s.uiShown then
            local tab = s.tab or s.lastTab
            if tab then A.UI:SelectTab(tab) end
        else
            A.UI:Hide()
        end
    end)
    part("Sprache", function()
        local cur = A.db.settings.uiLanguage
        A.db.settings.nameLocale = s.nameLocale
        if cur ~= s.uiLanguage then A:SetUILanguage(s.uiLanguage or "auto") end
    end)
    part("Reiter merken", function()
        A.db.settings.lastSub = s.lastSub
        A.db.settings.lastTab = s.lastTab
        A.db.settings.helpSeen = s.helpSeen
    end)
    part("Anzeige", function()
        A:Fire("SNIPER_CHANGED")
        A:Fire("WATCHER_CHANGED")
        if A.UI.UpdateHeaderStatus then A.UI:UpdateHeaderStatus() end
    end)
    if #problems > 0 then
        self:Add("Ablauf", "Zustand wiederherstellen", "FAIL", table.concat(problems, "; "))
        A:ReportError("Test:Wiederherstellen", table.concat(problems, "; "))
    end
end

-- ------------------------------------------------------------
-- Ergebnisse
-- ------------------------------------------------------------
function ST:Add(group, name, status, detail)
    table.insert(self.results, { group = group, name = name, status = status, detail = detail and short(detail) or "" })
    if self.window and self.window:IsShown() then self.window:Refresh() end
end

-- Details ohne Farb- und Symbolcodes (sonst schneidet die Spalte mitten im |T…|t ab)
local function plain(d) return type(d) == "string" and A:PlainText(d) or d end
local function pass(detail) return "PASS", plain(detail) end
local function fail(detail) return "FAIL", plain(detail) end
local function skip(detail) return "SKIP", plain(detail) end

-- ------------------------------------------------------------
-- Hilfen für die Prüfungen
-- ------------------------------------------------------------
local function ScannedItems(n, filter)
    local out = {}
    for id in pairs(A.db.marketData) do
        local p, q = A:GetCurrent(id)
        if p and p > 0 and (not filter or filter(id, p, q)) then table.insert(out, id) end
    end
    table.sort(out, function(a, b) return (select(2, A:GetCurrent(a)) or 0) > (select(2, A:GetCurrent(b)) or 0) end)
    local res = {}
    for i = 1, math.min(n or #out, #out) do res[i] = out[i] end
    return res
end

local function SellableBagItem()
    local items = A.Seller and A.Seller:GetBagItems() or {}
    for _, e in ipairs(items) do
        if A:GetCurrent(e.itemID) then return e end
    end
    return items[1]
end

-- ------------------------------------------------------------
-- Schritte: { group, name, run = function() -> status, detail[, waitFn, timeout, checkFn] }
-- Liefert run eine Wartefunktion, wartet der Test darauf (höchstens timeout Sek.)
-- und ruft danach checkFn() -> status, detail auf.
-- ------------------------------------------------------------
function ST:Steps()
    local S = {}
    local function step(group, name, run) table.insert(S, { group = group, name = name, run = run }) end
    local ctx = {}
    self.ctx = ctx

    -- ---------- Grundlagen ----------
    step("Grundlagen", "Version und Client", function()
        local build = GetBuildInfo and select(4, GetBuildInfo()) or "?"
        return pass("v" .. A.version .. ", Interface " .. tostring(build) .. (A.AH_LEGACY and ", klassisches AH" or ", modernes AH")
            .. ", Sprache " .. tostring(GetLocale and GetLocale()))
    end)
    step("Grundlagen", "Auktionshaus offen", function()
        if A:IsAHOpen() then return pass() end
        if self.savedMode then
            ctx.noAH = true
            return skip("nicht offen - Test mit gespeicherten Daten, Server-Suchen werden übersprungen")
        end
        ctx.abort = true
        return fail("Auktionshaus ist nicht offen - Test abgebrochen. Erst beim Auktionator das AH öffnen.")
    end)
    step("Grundlagen", "Server-Funktionen vorhanden", function()
        local need = { "SendBrowseQuery", "SendSearchQuery", "GetBrowseResults" }
        local miss = {}
        for _, f in ipairs(need) do if not (A.AH and A.AH[f]) then table.insert(miss, f) end end
        if #miss > 0 then return fail("fehlt: " .. table.concat(miss, ", ")) end
        return pass()
    end)

    -- ---------- Gebühr WoW Forever: nur EINE, AH-Gebühr = max(5 %, 1s) pro Auktion, beim Einstellen ----------
    step("Grundlagen", "AH-Gebühr WoW Forever", function()
        local prev = A.forceForever
        local G = _G.GoldSentinelGame
        -- Spielversion über die gemeinsame Erkennung erzwingen (GoldSentinelGame), sonst über den eigenen Schalter
        local function setFlavor(f)
            if G and G.SetTestFlavor then A.forceForever = nil; G.SetTestFlavor(f)
            else A.forceForever = (f == "forever") end
        end
        local function run()
            setFlavor("forever")
            -- Gebühren wie im klassischen WoW (Anweisung 14:30): 5 % beim Verkauf, Einzahlung zurück
            if A:SaleFee(nil, 4042, 1) ~= 202 then return "Verkauf: Gebühr nicht 5 %" end
            if A:SaleFee(nil, 1, 20, 1) ~= 1 then return "Stapel 20 x 1c: Gebühr nicht 5 %" end
            if not A:DepositRefunded() then return "Einzahlung gilt auf Forever als nicht erstattet" end
            local saveVP, saveMin = A.GetVendorPrice, A.db and A.db.minDeposit
            if A.db then A.db.minDeposit = 100 end           -- Prüfung mit 1s-Minimum (sonst gemessen, A:MinDeposit)
            A.GetVendorPrice = function() return 40 end
            local d2, d8, d24 = A:ListingDeposit(nil, 20, 2), A:ListingDeposit(nil, 20, 8), A:ListingDeposit(nil, 20, 24)
            A.GetVendorPrice = function() return 1 end
            local s24 = A:ListingDeposit(nil, 20, 24)
            A.GetVendorPrice = saveVP
            if A.db then A.db.minDeposit = saveMin end
            if d2 ~= 100 or d8 ~= 160 or d24 ~= 480 then return string.format("Einzahlung 40c x 20: %s/%s/%s statt 100/160/480", d2, d8, d24) end
            if s24 ~= 100 then return "Mindest-Einzahlung 1s fehlt" end
            setFlavor("era")
            if A:SaleFee(nil, 200, 1) ~= 10 then return "andere Spielversion: Gebühr nicht 5 %" end
            if not A:DepositRefunded() then return "andere Spielversion: Gebühr muss erstattet werden" end
            return nil
        end
        local ok, err = pcall(run)
        if G and G.SetTestFlavor then G.SetTestFlavor(nil) end
        A.forceForever = prev
        if not ok then return fail(err) end
        if err then return fail(err) end
        return pass(string.format("5 %% beim Verkauf, Einzahlung zurück (dieser Client: %s)", A:IsForever() and "WoW Forever" or "andere Version"))
    end)
    step("Grundlagen", "Spielversion (GoldSentinelGame)", function()
        local G = _G.GoldSentinelGame
        if type(G) ~= "table" or not G.Status then return fail("GoldSentinelGame fehlt") end
        if A:IsForever() ~= (G.IsForever == true) then return fail("eigene Erkennung weicht ab") end
        if G.IsForever and not G.IsModern then return fail("Forever muss als moderner Client gelten") end
        return pass(G.Status())
    end)

    -- ---------- Scan ----------
    step("Scan", "Markt-Scan", function()
        local age = A.db.lastScanTime and (time() - A.db.lastScanTime) or math.huge
        if self.savedMode then
            local n = A:CountTable(A.db.marketData)
            if n == 0 then
                ctx.abort = true
                return fail("keine gespeicherten Daten - erst einmal im Auktionshaus scannen")
            end
            return pass(string.format("gespeicherte Daten: %d Items, letzter Scan vor %s (kein neuer Scan)", n,
                A.db.lastScanTime and A:FormatDuration(age) or "?"))
        end
        if age <= self.SCAN_FRESH and A:CountTable(A.db.marketData) > 0 then
            return pass(string.format("vorhandener Scan von vor %d Min. wird benutzt", math.floor(age / 60)))
        end
        if not A:IsScanReady() then
            if A:CountTable(A.db.marketData) > 0 then
                return skip("Scan gesperrt (noch " .. A:FormatDuration(A:GetCooldownRemaining()) .. ") - ältere Daten werden benutzt")
            end
            ctx.abort = true
            return fail("Scan gesperrt und keine Daten - später nochmal testen")
        end
        local before = A.db.lastScanTime or 0
        if not (self.origScan or A.StartFullScan)(A) then return fail("Scan ließ sich nicht starten") end
        ctx.scanStart = Now()
        return "WAIT", nil, function() return not A:IsScanning() and (A.db.lastScanTime or 0) > before end, self.SCAN_TIMEOUT,
            function()
                local n = A:CountTable(A.db.marketData)
                return n > 0 and pass(string.format("%d Items in %d Sek.", n, math.floor(Now() - ctx.scanStart))) or fail("Scan ohne Ergebnis")
            end
    end)
    step("Scan", "Marktdaten plausibel", function()
        local n, withMV, neg, absurd = 0, 0, 0, 0
        for id in pairs(A.db.marketData) do
            n = n + 1
            local mv = A:GetMarketValue(id)
            local cur = A:GetCurrent(id)
            if mv then withMV = withMV + 1; if mv <= 0 then neg = neg + 1 end end
            if mv and cur and A:IsAbsurdProfit(cur, mv) then absurd = absurd + 1 end
        end
        if n == 0 then return fail("keine Items") end
        local d = string.format("%d Items, %d mit Marktwert, %d auffällig billig (werden ausgeblendet)", n, withMV, absurd)
        if neg > 0 then return fail(d .. ", " .. neg .. " Marktwerte <= 0") end
        if withMV == 0 then return fail(d) end
        return pass(d)
    end)

    -- ---------- Oberfläche ----------
    step("Oberfläche", "Fenster öffnen", function()
        A.UI:Show()
        return A.UI:IsVisible() and pass() or fail("Fenster nicht sichtbar")
    end)
    for _, g in ipairs(A.UI:Groups()) do
        for _, id in ipairs(g.tabs) do
            local tab = A.UI:GetTab(id)
            step("Oberfläche", "Reiter " .. L[g.label] .. (#g.tabs > 1 and (" -> " .. L[A.UI.SUBLABELS[id] or tab.label]) or ""), function()
                local panel = A.UI:SelectTab(id)
                if not panel then return fail("lädt nicht") end
                if A.UI.activeTab ~= id then return fail("anderer Reiter aktiv: " .. tostring(A.UI.activeTab)) end
                if panel.Refresh then
                    local ok, err = pcall(panel.Refresh, panel)
                    if not ok then return fail(err) end
                end
                return pass()
            end)
        end
    end
    step("Oberfläche", "Preisverlauf-Fenster", function()
        local id = ScannedItems(1)[1]
        if not id then return skip("kein Item") end
        local p = A.UI:OpenChart(id)
        if not (A.UI.chartWin and A.UI.chartWin:IsShown()) then return fail("Fenster nicht offen") end
        if p and p.selected ~= id then return fail("falsches Item") end
        A.UI.chartWin:Hide()
        return pass(A:GetItemName(id))
    end)
    step("Oberfläche", "Optionen, Hilfe, Einkaufslisten", function()
        A.UI:ShowOptions(); local o = A.UI.options and A.UI.options:IsShown(); if A.UI.options then A.UI.options:Hide() end
        A.UI:ShowHelp("start"); local h = A.UI.helpWindow and A.UI.helpWindow:IsShown(); if A.UI.helpWindow then A.UI.helpWindow:Hide() end
        A.UI:ShowLists(); local l = A.UI.listsWindow and A.UI.listsWindow:IsShown(); if A.UI.listsWindow then A.UI.listsWindow:Hide() end
        if o and h and l then return pass() end
        return fail(string.format("Optionen %s, Hilfe %s, Listen %s", tostring(o), tostring(h), tostring(l)))
    end)
    -- Sprachen: jede Sprache des Addons einmal, danach mehrfach hin und her. Fenster, Reiter,
    -- Item-Namen und Tooltip müssen jedes Mal in der gewählten Sprache sein, ohne Fehler.
    step("Oberfläche", "Sprachwechsel (alle Sprachen, mehrfach)", function()
        local saved = A.db.settings.uiLanguage or "auto"
        local savedNames = A.db.settings.nameLocale
        A.db.settings.nameLocale = "auto"     -- Item-Namen folgen der Sprache des Addons
        local langs = {}
        for _, l in ipairs(A.UI_LANGUAGES) do if l ~= "auto" then table.insert(langs, l) end end
        -- danach noch mehrfach hin und her
        for _, l in ipairs({ "enUS", "deDE", "zhCN", "frFR", "deDE", "ruRU", "enUS" }) do table.insert(langs, l) end
        local problems, done, missing = {}, 0, {}
        local scanned200 = ScannedItems(200)
        local sample = SellableBagItem()
        local probe = sample and sample.itemID or ScannedItems(1)[1]
        local function tipLines()
            local out = {}
            for i = 1, GameTooltip:NumLines() do
                local fs = _G["GameTooltipTextLeft" .. i]
                local t = fs and fs.GetText and fs:GetText()
                if t then table.insert(out, t) end
            end
            if #out == 0 and GameTooltip.__Lines then
                for _, l in ipairs(GameTooltip:__Lines()) do table.insert(out, tostring(type(l) == "table" and (l.left or "") or l)) end
            end
            return table.concat(out, "\n")
        end
        local function doLang(lang)
            local ok, err = pcall(function()
                A:SetUILanguage(lang)
                if A.uiLang ~= lang then error("Sprache nicht übernommen") end
                -- Fenster in der neuen Sprache aufbauen und alle Reiter einmal zeigen
                A.UI:Show()
                for _, g in ipairs(A.UI:Groups()) do
                    for _, id in ipairs(g.tabs) do
                        local panel = A.UI:SelectTab(id)
                        if not panel then error("Reiter " .. id .. " lädt nicht") end
                    end
                end
                -- Texte: ein bekannter Text muss in dieser Sprache kommen
                local want = (lang == "deDE") and "Einkauf" or ((A.T[lang] and A.T[lang]["Einkauf"]) or A.EN["Einkauf"])
                if L["Einkauf"] ~= want then error("Text nicht in " .. lang .. ": " .. tostring(L["Einkauf"])) end
                -- Item-Namen in dieser Sprache (wenn der Name bekannt ist)
                if probe and A.Names then
                    local nm = A.Names:Get(probe, lang)
                    if nm and A.Names:ClientLocale() ~= lang and A:GetItemName(probe) ~= nm then
                        error("Item-Name nicht in " .. lang .. ": " .. tostring(A:GetItemName(probe)))
                    end
                end
                -- Optionen: keine Beschriftung braucht mehr als zwei Zeilen (sonst abgeschnitten)
                A.UI:ShowOptions()
                local ow = A.UI.options
                for _, lbl in ipairs(ow and ow.optionLabels or {}) do
                    local sw, wd = lbl:GetStringWidth() or 0, lbl:GetWidth() or 0
                    if wd > 0 and sw > wd * 2 + 4 then error("Optionen: abgeschnitten: " .. tostring(lbl:GetText())) end
                end
                if ow then ow:Hide() end
                -- Ergebnisliste im Einkauf: Namen in der aktiven Sprache (nicht in der Sprache der Suche)
                local res = A.Buy and A.Buy.results
                if res and res[1] and res[1].itemID and A.Names and A.Names:ClientLocale() ~= lang then
                    local want2 = A.Names:Get(res[1].itemID, lang)
                    if want2 and not A.UI.ItemName(res[1]):find(want2, 1, true) then
                        error("Einkauf: Name nicht in " .. lang .. ": " .. tostring(A.UI.ItemName(res[1])))
                    end
                end
                -- Namen der gescannten Items in dieser Sprache zählen (fehlende = Name in der Sprache des Spiels)
                if A.Names and lang ~= A.Names:ClientLocale() then
                    local ids, miss = scanned200, 0
                    for _, id in ipairs(ids) do if not A.Names:Get(id, lang) then miss = miss + 1 end end
                    missing[lang] = string.format("%d/%d", miss, #ids)
                end
                -- Tooltip: Zeilen von AHSentinel in dieser Sprache
                if probe then
                    GameTooltip:SetOwner(UIParent, "ANCHOR_NONE")
                    GameTooltip:SetHyperlink("item:" .. probe)
                    local txt = tipLines()
                    GameTooltip:Hide()
                    -- Tooltip Variante A: ohne Shift Block 1 "Preis" bzw. "Marktwert", Block 2 "Verkaufen:"/"Händler:"
                    -- oder das Entzauber-Urteil ("Händlerpreis" steht nur noch mit Shift) - Befund 20:15 C2
                    local keys = { L["Preis"], L["Marktwert"], L["AHSentinel: noch keine Preisdaten"], L["Verkaufen:"], L["Händler:"],
                        L["Entzaubern lohnt sich"], L["Entzaubern lohnt nicht"], L["Entzaubern: unsicher"] }
                    local found = false
                    for _, k in ipairs(keys) do if txt:find(k, 1, true) then found = true end end
                    if not found then
                        error("Tooltip nicht in " .. lang)
                    end
                end
            end)
            done = done + 1
            if not ok then table.insert(problems, lang .. ": " .. tostring(err)) end
        end
        -- eine Sprache pro Bild: alle auf einmal dauert in Retail zu lange ("script ran too long")
        local idx = 0
        local function nextLang()
            idx = idx + 1
            local lang = langs[idx]
            if not lang then return true end
            doLang(lang)
            return false
        end
        local function finish()
            A.db.settings.nameLocale = savedNames
            A:SetUILanguage(saved)
            A.UI:Show()
            if A:UILanguageSetting() ~= saved then table.insert(problems, "Sprache nicht zurückgestellt") end
            if #problems > 0 then return fail(table.concat(problems, "; ")) end
            local miss = {}
            for _, l in ipairs(A.UI_LANGUAGES) do if missing[l] then table.insert(miss, l .. " " .. missing[l]) end end
            return pass(string.format("%d Wechsel ohne Fehler, zurück auf %s. Fehlende Item-Namen: %s", done, A:UILanguageLabel(),
                #miss > 0 and table.concat(miss, ", ") or "-"))
        end
        return "WAIT", nil, nextLang, 120, finish
    end)
    step("Oberfläche", "Knopf an der Minikarte", function()
        local b = A.FloatingButton
        if not b then return fail("fehlt") end
        if A.db.settings.minimapHide then return skip("ausgeblendet (Option)") end
        return b:IsShown() and pass() or fail("nicht sichtbar")
    end)

    -- ---------- Auswertungen ----------
    local function calc(name, fn)
        step("Auswertungen", name, function()
            local ok, a, b = pcall(fn)
            if not ok then return fail(a) end
            return pass(a)
        end)
    end
    calc("Marktliste", function() return #A:BuildItemList() .. " Einträge" end)
    calc("Suche nach Namen", function()
        -- ein gescanntes Item, dessen Name der Client schon kennt (Retail lädt Namen erst nach)
        local id, name
        for _, sid in ipairs(ScannedItems(200)) do
            local n = A:GetClientItemName(sid)
            if n and not n:find("^Item #") then id, name = sid, n; break end
        end
        if not name then
            return string.format("kein Name bekannt (noch %d Items werden nachgeladen)", A:PendingItemLoads())
        end
        local found = A:FindItemByName(name)
        if found ~= id then error("'" .. name .. "' -> " .. tostring(found)) end
        return name
    end)
    calc("Unter Händlerpreis", function() return #A:FindVendorDeals() .. " Funde" end)
    calc("Unter Entzauberwert", function() return #A.Disenchant:FindDeals() .. " Funde" end)
    calc("Entzaubern: Startwerte und Teilen", function()
        local D = A.Disenchant
        local p, pw = D:PriorForKey("2:4:a"), D:PriorForKey("2:4:w")
        if not p or p[1][2] ~= 0.75 or p[2][2] ~= 0.20 or p[3][2] ~= 0.05 then error("Startwerte nicht 75/20/5") end
        if not pw or pw[1][2] ~= 0.20 or pw[2][2] ~= 0.75 then error("Waffen nicht gespiegelt") end
        local saveS, saveSh, saveRate = A.db.deStats, A.db.deShared, D.rate
        D.rate = {}                     -- Mengenlimit je Absender: der Test zählt nicht gegen echte Mitspieler
        A.db.deStats = { ["2:4:a"] = { n = 20, mats = { [11083] = { times = 16, total = 24 }, [11082] = { times = 4, total = 6 } } } }
        A.db.deShared = {}
        local parts = D:EncodeStats()
        A.db.deStats = {}
        local ok, taken = pcall(D.HandleShared, D, "Testspieler", time(), table.concat(parts, ";"))
        local nOwn, nShared = D:Combined("2:4:a")
        local y = D:YieldForKey("2:4:a")
        local bad = D:HandleShared("Fremd", time(), "2.4.a~5~" .. A.Sync.Enc(2589) .. ",1,1")
        A.db.deStats, A.db.deShared, D.rate = saveS, saveSh, saveRate
        if not ok then error(taken) end
        if taken ~= 1 or nOwn ~= 0 or nShared ~= 20 then error("geteilt: " .. tostring(taken) .. "/" .. nOwn .. "/" .. nShared) end
        if bad ~= 0 then error("fremdes Material angenommen") end
        if not y or math.abs(y[1][2] - 23.5 / 30) > 0.001 then error("Mischung falsch") end
        return "75/20/5, 20 geteilte übernommen, Staub jetzt " .. math.floor(y[1][2] * 1000 + 0.5) / 10 .. " %"
    end)
    calc("Gebote", function() return #A:GetBidDeals(30) .. " Funde" end)
    calc("Flips", function() return #A.Extras:GetFlipDeals(20) .. " Funde" end)
    calc("Vermögen", function() local r, t = A.Extras:InventoryValue(); return #r .. " Items, " .. A:FormatMoney(t.market) end)
    calc("Tagesbilanz", function() return A.Extras:DailyText():gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", "") end)
    calc("Buchhaltung", function() local s = A.Ledger:Summary("all"); local st = A.Ledger:Stats("all"); return (s.sales or 0) .. " Verkäufe, " .. #st.items .. " Items in der Statistik" end)
    calc("Händler-Verkauf (nur Liste)", function() local l, t = A.Extras:VendorCandidates(); return #l .. " Items, " .. A:FormatMoney(t) end)
    -- echter Weg wie beim Spieler: Tooltip über WoW füllen lassen (Taschen-Item, sonst Link)
    calc("Tooltip", function()
        local e = SellableBagItem()
        local id, how = e and e.itemID, nil
        GameTooltip:SetOwner(UIParent, "ANCHOR_NONE")
        local loc = e and e.slots and e.slots[1] and e.slots[1].loc
        local bag, slot
        if loc and loc.GetBagAndSlot then bag, slot = loc:GetBagAndSlot() end
        if bag and GameTooltip.SetBagItem then
            GameTooltip:SetBagItem(bag, slot); how = "Taschen-Item"
        else
            id = id or ScannedItems(1)[1]
            if not id then GameTooltip:Hide(); return "kein Item" end
            GameTooltip:SetHyperlink("item:" .. id); how = "Item-Link"
        end
        local ok = GameTooltip.__ahapItem == id and (GameTooltip.__ahapN or 0) >= 2
        local n = GameTooltip:NumLines()
        GameTooltip:Hide()
        if not ok then error(how .. ": keine Zeilen von AHSentinel im Tooltip (Weg: " .. tostring(A.Tooltip.mode) .. ")") end
        return string.format("%s %s: %d Zeilen (Weg: %s)", how, A:GetItemName(id), n, tostring(A.Tooltip.mode))
    end)
    calc("Verkaufbarkeit", function()
        -- alle Items, nicht nur die häufigsten (sonst sieht man die Mondpreise nicht)
        local n, sure, unsure, bad = 0, 0, 0, nil
        for id in pairs(A.db.marketData) do
            local l = A:GetLiquidity(id)
            n = n + 1
            if l.conf == "gering" then unsure = unsure + 1 elseif l.conf == "hoch" then sure = sure + 1 end
            -- Plausibilität: es verkauft sich nie mehr pro Tag, als üblicherweise angeboten wird
            if l.perDay and l.perDay > math.max(1, l.avgQty) and not bad then bad = A:GetItemName(id) .. string.format(" (%.0f/Tag bei Ø %.0f angeboten)", l.perDay, l.avgQty) end
        end
        if bad then error("unplausibel: " .. bad) end
        local _, full = A:FullScanTimes(time() - A.LIQ_DAYS * 86400)
        return string.format("%d Items: %d sicher, %d unsicher (Mondpreise/selten), %d vollständige Scans", n, sure, unsure, full)
    end)
    calc("Heute tun", function()
        local list, capital, money = A.Comfort:TodayActions(10, true)
        for i = 2, #list do
            if not list[i - 1].pin and list[i - 1].gold < list[i].gold then error("nicht nach Gold sortiert") end
        end
        -- Kapitalschutz: zusammen höchstens die Hälfte des Golds, je Vorschlag höchstens 20 %
        if (capital or 0) > (money or 0) * A.Comfort:TotalShare() + 1 then
            error(string.format("Kapitalbedarf %s über dem Anteil des Golds (%s)", A:FormatMoney(capital), A:FormatMoney(money)))
        end
        for _, r in ipairs(list) do
            if not r.pin and (r.capital or 0) > (money or 0) * A.Comfort.TODAY_ITEM_SHARE + 1 then error("Vorschlag zu teuer: " .. r.text) end
        end
        -- Plausibilität: ein Verkaufsvorschlag verspricht nie mehr als das Doppelte des günstigsten aktuellen Angebots
        for _, r in ipairs(list) do
            if r.kind == "sell" and r.itemID and r.unit then
                local cur, _, t = A:GetCurrent(r.itemID)
                if cur and t and t >= time() - 3 * 86400 and r.unit > cur * 2 then
                    error(string.format("Verkaufspreis zu hoch: %s (%s, günstigstes Angebot %s)", A:GetItemName(r.itemID), A:FormatMoney(r.unit), A:FormatMoney(cur)))
                end
            end
        end
        -- Knopf je Zeile: jede Zeile hat einen nächsten Schritt; QuickBuy legt nur eine Zeile an, kauft nichts
        local Td = A.Today
        if not (Td and Td.QuickBuy and Td.QuickSell) then error("Schnittstelle A.Today fehlt") end
        for _, r in ipairs(list) do
            if not Td:Label(r) then error("kein Knopf für: " .. tostring(r.text)) end
        end
        local probe = ScannedItems(1)[1]
        if probe then
            local before = GetMoney and GetMoney() or 0
            Td:QuickBuy(probe, 1, 1, "Selbsttest")
            local l2 = A.Comfort:TodayActions(10, true)
            local found = l2[1] and l2[1].kind == "quick" and l2[1].itemID == probe
            for i = #Td.extra, 1, -1 do if Td.extra[i].key == "quick:" .. probe then table.remove(Td.extra, i) end end
            Td.state["quick:" .. probe] = nil
            if not found then error("QuickBuy: keine Zeile oben in Heute tun") end
            if (GetMoney and GetMoney() or 0) ~= before then error("QuickBuy hat ohne Klick Gold ausgegeben") end
        end
        local sum = 0
        for _, r in ipairs(list) do sum = sum + r.gold end
        A.UI:ShowToday(); local shown = A.UI.todayWin and A.UI.todayWin:IsShown(); if A.UI.todayWin then A.UI.todayWin:Hide() end
        if not shown then error("Fenster nicht offen") end
        return string.format("%d Vorschläge, zusammen ca. %s, Kapital %s von %s", #list, A:FormatMoney(sum), A:FormatMoney(capital or 0), A:FormatMoney(money or 0))
    end)
    calc("Übersetzungen", function()
        local miss = 0
        for k, v in pairs(A.L) do if type(v) ~= "string" then miss = miss + 1 end end
        return "Sprache " .. tostring(A.uiLang)
    end)

    -- ---------- Echte Suchen beim Server (nur bei offenem Auktionshaus) ----------
    local realStep = step
    local function step(group, name, run)
        realStep(group, name, function()
            if ctx.noAH or not A:IsAHOpen() then return skip("Auktionshaus nicht offen") end
            if A:IsScanning() then return skip("Markt-Scan läuft noch - Suchen beim Server sind solange nicht möglich") end
            return run()
        end)
    end
    -- Läuft noch ein Markt-Scan (z. B. von Hand vor dem Test gestartet), blockiert er alle Suchen.
    -- Im Test mit gespeicherten Daten wird er beendet, sonst wird auf ihn gewartet.
    realStep("Server", "Kein Scan im Hintergrund", function()
        if ctx.noAH or not A:IsAHOpen() then return skip("Auktionshaus nicht offen") end
        if not A:IsScanning() then return pass() end
        ctx.bgStart = Now()
        if self.savedMode then
            ctx.bgStopped = true
            if A.AH and A.AH.AbortBrowse then pcall(A.AH.AbortBrowse) end
            if A.scanState and A.scanState.running then A:FinishScan(false) end
        end
        return "WAIT", nil, function() return not A:IsScanning() and (not A.QueryReady or A:QueryReady()) end,
            self.savedMode and 30 or self.SCAN_TIMEOUT,
            function()
                return pass(string.format(ctx.bgStopped and "laufender Scan wurde beendet (%.1f Sek.)" or "auf laufenden Scan gewartet (%.1f Sek.)",
                    Now() - ctx.bgStart))
            end
    end)
    step("Server", "Einkauf: Kategorie-Suche", function()
        -- Befund 22:25 2b/2c: während der Server-Schritte Sniper und Wächter pausieren (sie belegen sonst die Suchen),
        -- Zustand merken und nach "Eigene Auktionen" zurück (bei Abbruch über ST:RestoreState)
        local Sn, W = A.Sniper, A.Watcher
        if not ctx.pause then
            ctx.pause = { armed = A.db.sniper and A.db.sniper.armed and true or false, watcher = W and W:IsEnabled() or false }
            if ctx.pause.armed then Sn:SetArmed(false) end
            if ctx.pause.watcher then W:SetEnabled(false) end
        end
        local B = A.Buy
        local ok, msg = B:Search({ text = "", cat = "trade" }, true)
        if not ok then return fail(msg) end
        ctx.buyStart = Now()
        return "WAIT", nil, function() return not B.search and not B.wanted end, self.QUERY_TIMEOUT,
            function()
                local n = #(B.results or {})
                return n > 0 and pass(string.format("%d Items in %.1f Sek.", n, Now() - ctx.buyStart)) or fail("keine Ergebnisse")
            end
    end)
    step("Server", "Einkauf: Angebote eines Items", function()
        local B = A.Buy
        local first = B.results and B.results[1]
        if not first then return skip("kein Item aus der Suche") end
        ctx.simKey, ctx.simName = first.itemKey, first.name
        local ok, msg = B:Open(first.itemKey, first.name)
        -- R5 (Befund 0.65.65): immer mit Ist-Wert - auch wenn Open ohne Meldung scheitert oder keine Angebote kommen
        if not ok then return fail(string.format("%s: Suche nicht gestartet (%s)", tostring(first.name), tostring(msg or "ohne Meldung"))) end
        ctx.openStart = Now()
        return "WAIT", nil, function() return B.detail and not B.detail.loading end, self.QUERY_TIMEOUT,
            function()
                local d = B.detail
                local n = d and #(d.listings or {}) or 0
                local info = string.format("%s: %d Angebote in %.1f Sek. (Laden %s, Fehler %s)", tostring(first.name), n, Now() - ctx.openStart,
                    d and (d.loading and "läuft" or "fertig") or "keine Liste", tostring(d and d.error or "-"))
                B:Back()
                return n > 0 and pass(info) or fail(info)
            end
    end)
    step("Server", "Verkaufen: Preisprüfung", function()
        local e = SellableBagItem()
        if not e then return skip("nichts Verkaufbares in den Taschen") end
        local Se = A.Seller
        ctx.sellItem = e
        ctx.sellStart = Now()
        Se:CheckPrice(e.itemID, true)
        return "WAIT", nil, function() return Se:IsPriceFresh(e.itemID) and Se:GetPriceInfo(e.itemID).time >= ctx.sellStart - 0.1 end, self.QUERY_TIMEOUT,
            function()
                local pr = Se:GetPriceInfo(e.itemID)
                local sug = Se:Suggest(e.itemID)
                return pass(string.format("%s: %d Angebote, Vorschlag %s (%.1f Sek.)", e.name or A:GetItemName(e.itemID),
                    #(pr.listings or {}), sug and A:FormatMoney(sug) or "-", Now() - ctx.sellStart))
            end
    end)
    step("Server", "Sniper: Suche (kauft nichts)", function()
        local Sn = A.Sniper
        local id = ScannedItems(1)[1]
        if not id then return skip("kein Item") end
        -- Ziel mit Max-Preis 1 Kupfer: findet Angebote, kauft aber nie
        local ok, msg = Sn:SetTarget(tostring(id), 1, 1, 1)
        if not ok then return fail(msg) end
        ctx.snKey = "i:" .. id
        ctx.snStart = Now()
        return "WAIT", nil, function()
            if Sn.result and Sn.result.key == ctx.snKey then ctx.snResult = Sn.result; return true end
            if not Sn:IsBusy() and not ctx.snSent then
                local okS = Sn:Search(ctx.snKey)
                if okS then ctx.snSent = true end
            end
            return false
        end, self.QUERY_TIMEOUT, function()
            -- Befund 20:15 A4: nur das Ergebnis DIESES Ziels werten (ein offener Treffer eines anderen Ziels oder des
            -- Wächters zählt nicht) - Plan für genau dieses Ergebnis, mit Preis, Max-Preis und Einheit im Ergebnis
            -- Befund 22:25 2a: ein Treffer bei Max 1c ist richtig, wenn das Angebot 1c kostet. Darum Max auf das günstigste
            -- echte Angebot - 1c setzen und dann prüfen: kein Plan. Günstigstes Angebot 1c: kein Item über 1c -> übersprungen.
            local r = ctx.snResult
            local n = r and #(r.listings or {}) or 0
            local t = Sn:GetTarget(ctx.snKey)
            local low
            for _, l in ipairs(r and r.listings or {}) do if not l.bait and (not low or l.price < low) then low = l.price end end
            if low and low <= 1 then
                Sn:RemoveTarget(ctx.snKey)
                return "SKIP", string.format("%s: günstigstes Angebot 1c je Stück - kein Item über 1c, Treffer bei Max 1c wäre richtig", A:GetItemName(id))
            end
            local oldMax = t and t.maxPrice
            if t and low then t.maxPrice = low - 1 end
            local maxP = t and t.maxPrice
            local keep = Sn.result
            Sn.result = r
            local plan = r and Sn:PlanNext()
            Sn.result = keep
            if t then t.maxPrice = oldMax end
            Sn:RemoveTarget(ctx.snKey)
            if plan then
                return fail(string.format("Treffer bei Max-Preis %s je Stück: Plan %dx für %s (günstigstes Angebot %s je Stück)",
                    A:FormatMoney(maxP or 0), plan.qty or 0, A:FormatMoney(plan.total or 0), A:FormatMoney(low or 0)))
            end
            return pass(string.format("%s: %d Angebote gelesen (günstigstes %s je Stück, Max %s je Stück), kein Treffer (%.1f Sek.)",
                A:GetItemName(id), n, A:FormatMoney(low or 0), A:FormatMoney(maxP or 0), Now() - ctx.snStart))
        end
    end)
    step("Server", "Wächter: eine Runde (kauft nichts)", function()
        local W = A.Watcher
        if #W:ActiveCategories() == 0 then return skip("keine Kategorie gewählt") end
        ctx.wRound = W.lastRound or 0
        ctx.wStart = Now()
        -- Sniper-Modus mit Zielen pausiert den Wächter (B1) - für diesen Schritt Sniper aus (Zustand in ctx.pause)
        if A.db.sniper and A.db.sniper.armed then A.Sniper:SetArmed(false) end
        if not W:IsEnabled() then W:SetEnabled(true) end
        return "WAIT", nil, function() return (W.lastRound or 0) > ctx.wRound end, 120,
            function()
                local n = #(W:GetOpportunities() or {})
                -- für die nächsten Schritte wieder aus; der Zustand des Spielers kommt nach "Eigene Auktionen" zurück
                W:SetEnabled(false)
                return pass(string.format("Runde fertig in %.1f Sek., %d Schnäppchen gefunden", Now() - ctx.wStart, n))
            end
    end)
    step("Server", "Eigene Auktionen", function()
        if A.Watcher:IsEnabled() then A.Watcher:SetEnabled(false) end
        local Se = A.Seller
        local before = Se.ownedTime or 0
        local ok, msg = Se:QueryOwned()
        if not ok then return fail(msg) end
        local function restore()
            local p = ctx.pause
            ctx.pause = nil
            if not p then return end
            if (A.Watcher:IsEnabled() and true or false) ~= p.watcher then A.Watcher:SetEnabled(p.watcher) end
            if A.db.sniper and (A.db.sniper.armed and true or false) ~= p.armed then A.Sniper:SetArmed(p.armed) end
        end
        ctx.restorePause = restore
        return "WAIT", nil, function() return (Se.ownedTime or 0) > before end, self.QUERY_TIMEOUT,
            function() restore(); return pass(#Se.owned .. " eigene Auktionen") end
    end)

    -- ---------- Handel simulieren (echte Angebote, nichts geht an den Server) ----------
    local G = "Handel (simuliert)"
    local function lastTrade(fn, from)
        for i = #ST.tradeLog, (from or 0) + 1, -1 do
            local e = ST.tradeLog[i]
            if e and e.fn == fn then return e end
        end
    end
    -- Funktion aufrufen; Chat-Meldungen dabei als Simulation kennzeichnen
    -- Die Sperren gelten nur für Klicks des Spielers; hier laufen die echten Wege des Addons,
    -- deren Server-Befehle der Schutz (ST.tradeLog) abfängt.
    local function simCall(fn, ...)
        for b, real in pairs(ST.saved or {}) do A[b[1]][b[2]] = real end
        local print = A.Print
        A.Print = function(me, msg, ...) return print(me, "|cff88ccff[" .. L["Simulation"] .. "]|r " .. tostring(msg), ...) end
        local res = { n = 0 }
        local function keep(...) res.n = select("#", ...); for i = 1, res.n do res[i] = (select(i, ...)) end end
        -- Sniper kauft nur aus einem Tastendruck (Sn:HardwareOK). Hier fängt der Schutz (ST.tradeLog) jeden
        -- Server-Befehl ab - nichts geht an den Server; darum gilt der simulierte Aufruf als Druck.
        local Sn = A.Sniper
        local hw = Sn and Sn.inTrigger
        if Sn then Sn.inTrigger = true end
        keep(pcall(fn, ...))
        if Sn then Sn.inTrigger = hw end
        A.Print = print
        local lockMsg = L["Selbsttest läuft - Kaufen und Einstellen sind gesperrt."]
        for b in pairs(ST.saved or {}) do A[b[1]][b[2]] = function() return false, lockMsg end end
        if not res[1] then error(res[2], 0) end
        return unpack(res, 2, res.n)
    end
    local function money() return GetMoney and GetMoney() or 0 end

    step(G, "Schutz aktiv", function()
        if not (ST.realAH and getmetatable(A.AH)) then return fail("Befehle an den Server werden NICHT abgefangen - Simulation abgebrochen") end
        ctx.simOK = true
        ctx.money = money()
        local ok = A.Buy.BuyItem(A.Buy, { auctionID = 1, buyout = 1 })
        if ok then return fail("Kaufen ist nicht gesperrt") end
        return pass("Kaufen/Einstellen gesperrt, Server-Befehle werden nur protokolliert")
    end)
    local function simStep(name, run)
        step(G, name, function()
            if not ctx.simOK then return skip("Schutz nicht aktiv") end
            return run()
        end)
    end

    simStep("Angebote laden", function()
        local B = A.Buy
        if not ctx.simKey then return skip("kein Item aus der Einkauf-Suche") end
        local ok, msg = B:Open(ctx.simKey, ctx.simName)
        if not ok then return fail(msg) end
        return "WAIT", nil, function() return B.detail and not B.detail.loading end, self.QUERY_TIMEOUT,
            function()
                local d = B.detail
                local n = d and #(d.listings or {}) or 0
                if n == 0 then return fail("keine Angebote") end
                ctx.simItemID = d.itemID
                -- kleinster kaufbarer Stapel: der Sniper-Test soll so wenig wie möglich "kaufen"
                for _, l in ipairs(d.listings) do
                    if not l.own and l.qty and l.qty > 0 and (not ctx.simMinQty or l.qty < ctx.simMinQty) then ctx.simMinQty = l.qty end
                end
                return pass(string.format("%s: %d Angebote%s", d.name or "?", n, d.commodity and " (Ware)" or ""))
            end
    end)
    simStep("Sofortkauf", function()
        local B = A.Buy
        local d = B.detail
        if not (d and d.listings and #d.listings > 0) then return skip("keine Angebote") end
        local from = #ST.tradeLog
        if d.commodity then
            B:SetQuantity(1)
            local ok, msg = simCall(self:RealFn("Buy", "StartCommodity"), B)
            local e = lastTrade("StartCommoditiesPurchase", from)
            simCall(B.CancelPending, B)
            if not e then return fail("kein Kaufbefehl erzeugt: " .. tostring(msg)) end
            if e.args[1] ~= d.itemID or e.args[2] ~= 1 then return fail("falsche Werte: " .. tostring(e.args[1]) .. ", " .. tostring(e.args[2])) end
            return pass(string.format("würde 1x %s kaufen (Preisanfrage abgefangen)", d.name or "?"))
        end
        local pick
        for _, l in ipairs(d.listings) do
            if l.auctionID and l.buyout and l.buyout > 0 and not l.own and l.buyout <= money() then
                if not pick or l.buyout < pick.buyout then pick = l end
            end
        end
        if not pick then return skip("kein bezahlbares Angebot mit Sofortkauf") end
        local ok, msg = simCall(self:RealFn("Buy", "BuyItem"), B, pick)
        pick.used = nil
        B.lastPurchase = nil
        if not ok then return fail(msg) end
        local e = lastTrade("PlaceBid", from)
        if not e then return fail("kein Kaufbefehl erzeugt") end
        if e.args[1] ~= pick.auctionID or e.args[2] ~= pick.buyout then
            return fail("falscher Preis: " .. tostring(e.args[2]) .. " statt " .. tostring(pick.buyout))
        end
        return pass(string.format("würde %dx %s für %s kaufen (abgefangen)", pick.qty or 1, d.name or "?", A:FormatMoney(pick.buyout)))
    end)
    simStep("Gebot", function()
        local B = A.Buy
        local d = B.detail
        if not (d and d.listings and #d.listings > 0) then return skip("keine Angebote") end
        if d.commodity then return skip("Waren haben keine Gebote") end
        local pick, amount
        for _, l in ipairs(d.listings) do
            local min = B:MinBid(l)
            if l.auctionID and not l.own and min and min > 0 and (not l.buyout or l.buyout == 0 or min < l.buyout) and min <= money() then
                if not amount or min < amount then pick, amount = l, min end
            end
        end
        if not pick then return skip("kein Angebot, auf das man bieten kann") end
        local from = #ST.tradeLog
        local ok, msg = simCall(self:RealFn("Buy", "PlaceBid"), B, pick, amount)
        B.lastBid = nil
        if not ok then return fail(msg) end
        local e = lastTrade("PlaceBid", from)
        if not e then return fail("kein Gebotsbefehl erzeugt") end
        if e.args[1] ~= pick.auctionID or e.args[2] ~= amount then return fail("falscher Betrag: " .. tostring(e.args[2])) end
        return pass(string.format("würde %s bieten (abgefangen)", A:FormatMoney(amount)))
    end)
    simStep("Sniper-Kauf", function()
        local Sn = A.Sniper
        local id = ctx.simItemID
        if A.Buy.detail then A.Buy:Back() end
        if not id then return skip("kein Item") end
        local m = money()
        if m <= 0 then return skip("kein Gold") end
        -- Ziel, das sicher trifft: Max-Preis = ganzes Gold, Menge = kleinster Stapel (wie ein Spieler mit Menge 1)
        local ok, msg = Sn:SetTarget(tostring(id), m, ctx.simMinQty or 1, m)
        if not ok then return fail(msg) end
        ctx.simSnKey = "i:" .. id
        ctx.simSnStart = Now()
        ctx.simSnSent = nil
        Sn.result = nil
        return "WAIT", nil, function()
            if Sn.result and Sn.result.key == ctx.simSnKey then return true end
            if not Sn:IsBusy() and not ctx.simSnSent then
                local okS, why = Sn:Search(ctx.simSnKey)
                if okS then ctx.simSnSent = true else ctx.simSnWhy = why end
            end
            return false
        end, self.QUERY_TIMEOUT, function()
            local plan = Sn:PlanNext()
            local result
            if not plan then
                result = { skip("kein Treffer (zu wenig Gold oder nur eigene Angebote)") }
            else
                local from = #ST.tradeLog
                local okB, okBuy, msgB = pcall(simCall, ST:RealFn("Sniper", "Buy"), Sn, plan)
                local e = lastTrade(plan.kind == "item" and "PlaceBid" or "StartCommoditiesPurchase", from)
                if not okB then result = { fail(okBuy) }
                elseif not e then result = { fail("kein Kaufbefehl erzeugt: " .. tostring(msgB)) }
                elseif plan.kind == "item" and (e.args[1] ~= plan.listing.auctionID or e.args[2] ~= plan.total) then
                    result = { fail("falscher Preis: " .. tostring(e.args[2])) }
                else
                    result = { pass(string.format("würde %dx %s für %s kaufen (abgefangen, %.1f Sek.)", plan.qty or 1,
                        A:GetItemName(plan.itemID), A:FormatMoney(plan.total or 0), Now() - ctx.simSnStart)) }
                end
            end
            Sn.pending = nil
            Sn.lastPurchase = nil
            Sn:RemoveTarget(ctx.simSnKey)
            Sn.result = nil
            return result[1], result[2]
        end
    end)
    simStep("Einstellen", function()
        local e = SellableBagItem()
        if not e then return skip("nichts Verkaufbares in den Taschen") end
        local Se = A.Seller
        local price = Se:Suggest(e.itemID) or (A:GetCurrent(e.itemID)) or 10000
        local sdb = A.db.seller
        local prevItem, prevDur = sdb and sdb.items and sdb.items[e.itemID], sdb and sdb.duration
        local from = #ST.tradeLog
        local okC, ok, msg = pcall(simCall, self:RealFn("Seller", "Post"), Se, e.itemID, price, 1, 2, nil, true)   -- Gebühr-Warnung prüft T183
        -- gemerkten Preis und Dauer wieder wie vorher
        if sdb then
            if sdb.items then sdb.items[e.itemID] = prevItem end
            sdb.duration = prevDur
        end
        Se.pendingPost = nil
        A:Fire("SELLER_CHANGED")
        if not okC then return fail(ok) end
        if not ok then return fail(msg) end
        local t = lastTrade("PostItem", from) or lastTrade("PostCommodity", from)
        if not t then return fail("kein Einstellbefehl erzeugt") end
        local got = t.fn == "PostItem" and t.args[5] or t.args[4]
        if got ~= math.floor(price) then return fail("falscher Preis: " .. tostring(got)) end
        return pass(string.format("würde 1x %s für %s einstellen (abgefangen)", e.name or A:GetItemName(e.itemID), A:FormatMoney(price)))
    end)
    simStep("Abbrechen", function()
        local Se = A.Seller
        local o
        for _, x in ipairs(Se.owned or {}) do if not x.sold then o = x; break end end
        local fake
        if not o then
            -- keine eigene Auktion: eine fiktive anlegen (steht nur in der Liste, nicht im Auktionshaus)
            local id = ctx.simItemID or ScannedItems(1)[1]
            if not id then return skip("keine eigenen Auktionen und kein Item für eine fiktive") end
            local cur = A:GetCurrent(id) or 10000
            table.insert(ST.fakeOwned, ST.FakeAuction(id, 1, cur))
            Se:ReadOwned()
            for _, x in ipairs(Se.owned or {}) do if ST.IsFakeAuction(x.auctionID) then o = x end end
            if not o then return fail("fiktive Auktion erscheint nicht in 'Meine Auktionen'") end
            fake = true
        end
        local from = #ST.tradeLog
        local ok, msg = simCall(self:RealFn("Seller", "Cancel"), Se, o.auctionID)
        Se.pendingCancel = nil
        if not ok then return fail(msg) end
        local t = lastTrade("CancelAuction", from)
        if fake then RemoveFake(ST.fakeOwned, o.auctionID); Se:ReadOwned() end
        if not t or t.args[1] ~= o.auctionID then return fail("kein Abbruchbefehl erzeugt") end
        return pass(string.format("würde %dx %s abbrechen (abgefangen%s)", o.qty or 1, o.name or "?", fake and ", fiktive Auktion" or ""))
    end)
    simStep("Nichts wirklich ausgeführt", function()
        local m = money()
        local n = #ST.tradeLog
        if ctx.money and m < ctx.money then
            return fail(string.format("Gold hat sich verändert: %s -> %s", A:FormatMoney(ctx.money), A:FormatMoney(m)))
        end
        return pass(string.format("%d Befehle abgefangen, Gold unverändert", n))
    end)
    return S
end

-- ------------------------------------------------------------
-- Ablauf
-- ------------------------------------------------------------
-- saved = true: nur gespeicherte Daten (kein neuer Scan, Auktionshaus darf zu sein)
function ST:Start(saved)
    if not A:RequireDev() then return false end
    if self.running or (A.TestRoutine and A.TestRoutine.running) then A:Print(L["Selbsttest läuft schon ..."]); return false end
    if not A.db then return false end
    self.savedMode = saved and true or false
    self.running = true
    self.results = {}
    self.startTime = Now()
    self.startStamp = time()
    self:SaveState()
    self:Lock()
    -- Sniper-Modus und Wächter nicht dazwischenfunken lassen (Wächter wird gezielt getestet)
    if A.Sniper:IsArmed() then A.Sniper:SetArmed(false) end
    if A.Watcher:IsEnabled() then A.Watcher:SetEnabled(false) end
    self.steps = self:Steps()
    self.pos = 0
    self.wait = nil
    self:ShowWindow()
    if self.savedMode then
        A:Print(L["|cffffd100Selbsttest mit gespeicherten Daten gestartet|r - kein neuer Scan. Kaufen und Einstellen sind solange gesperrt."])
    else
        A:Print(L["|cffffd100Selbsttest gestartet|r - bitte das Auktionshaus offen lassen. Kaufen und Einstellen sind solange gesperrt."])
    end
    self:Next()
    return true
end

-- Retail bricht Skripte ab, die zu lange am Stück laufen ("script ran too long").
-- Deshalb nach spätestens SLICE_MS Millisekunden eine Pause bis zum nächsten Bild einlegen.
local SLICE_MS = 40
local clock = debugprofilestop

function ST:Next()
    local t0 = clock and clock()
    while true do
        if self.ctx and self.ctx.abort then return self:Finish() end
        if t0 and clock() - t0 > SLICE_MS and C_Timer and C_Timer.After then
            C_Timer.After(0, function() if ST.running and not ST.wait then ST:Next() end end)
            return
        end
        self.pos = self.pos + 1
        local s = self.steps[self.pos]
        if not s then return self:Finish() end
        self.current = s
        local ok, status, detail, waitFn, timeout, checkFn = pcall(s.run)
        if not ok then
            self:Add(s.group, s.name, "FAIL", status)
        elseif status == "WAIT" then
            self.wait = { fn = waitFn, untilT = Now() + (timeout or 30), check = checkFn, step = s }
            if self.window and self.window:IsShown() then self.window:Refresh() end
            return
        else
            self:Add(s.group, s.name, status or "PASS", detail)
        end
    end
end

function ST:Poll()
    local w = self.wait
    if not w then return end
    if not A:IsAHOpen() and (not self.savedMode or w.step.group == "Server") then
        self.wait = nil
        self:Add(w.step.group, w.step.name, "FAIL", "Auktionshaus wurde geschlossen")
        self.ctx.abort = true
        return self:Next()
    end
    local okW, done = pcall(w.fn)
    if okW and done then
        self.wait = nil
        local ok, status, detail = pcall(w.check)
        if ok then self:Add(w.step.group, w.step.name, status or "PASS", detail)
        else self:Add(w.step.group, w.step.name, "FAIL", status) end
        return self:Next()
    end
    if not okW or Now() > w.untilT then
        self.wait = nil
        self:Add(w.step.group, w.step.name, "FAIL", okW and "Zeitüberschreitung" or done)
        return self:Next()
    end
end

function ST:Counts()
    local c = { PASS = 0, FAIL = 0, SKIP = 0 }
    for _, r in ipairs(self.results or {}) do c[r.status] = (c[r.status] or 0) + 1 end
    return c
end

function ST:Finish()
    self.wait = nil
    self.running = false
    self:Unlock()
    self:RestoreState()
    local c = self:Counts()
    local secs = math.floor(Now() - (self.startTime or Now()))
    A.db.selftest = {
        time = self.startStamp, date = date("%Y-%m-%d %H:%M"), version = A.version,
        interface = GetBuildInfo and select(4, GetBuildInfo()) or nil, legacy = A.AH_LEGACY and true or false,
        locale = GetLocale and GetLocale(), seconds = secs, savedData = self.savedMode, testMode = TM.active or nil,
        pass = c.PASS, fail = c.FAIL, skip = c.SKIP, results = self.results,
    }
    local color = c.FAIL == 0 and "|cff33dd55" or "|cffff5544"
    A:Print(string.format(L["%sSelbsttest fertig:|r %d bestanden, %d fehlgeschlagen, %d übersprungen (%d Sek.)"], color, c.PASS, c.FAIL, c.SKIP, secs))
    for _, r in ipairs(self.results) do
        if r.status == "FAIL" then A:Print("|cffff5544FAIL|r " .. r.group .. " / " .. r.name .. ": " .. r.detail) end
    end
    if self.window then self.window:Refresh() end
end

function ST:Cancel()
    if not self.running then return end
    self:Add("Ablauf", "Abbruch", "SKIP", "von Hand abgebrochen")
    self.ctx.abort = true
    self:Finish()
end

-- Bericht als Text (zum Kopieren)
function ST:Report()
    local t = A.db.selftest
    if not t then return L["Noch kein Selbsttest gelaufen."] end
    local lines = {
        "AHSentinel - Selbsttest",
        string.format("Datum: %s   Version: %s   Interface: %s   %s   Sprache: %s   Dauer: %d Sek.",
            t.date or "?", t.version or "?", tostring(t.interface), t.legacy and "klassisches AH" or "modernes AH", tostring(t.locale), t.seconds or 0),
        string.format("Ergebnis: %d bestanden, %d fehlgeschlagen, %d übersprungen", t.pass or 0, t.fail or 0, t.skip or 0),
        (t.savedData and "Modus: gespeicherte Daten (kein neuer Scan)" or "Modus: mit Scan / Live-Daten")
            .. " - Handel nur simuliert (nichts gekauft, geboten, eingestellt oder abgebrochen)"
            .. (t.testMode and " - im Testmodus" or ""),
        "",
    }
    for _, r in ipairs(t.results or {}) do
        table.insert(lines, string.format("[%s] %s / %s%s", r.status, r.group, r.name, (r.detail ~= "" and (" - " .. r.detail) or "")))
    end
    return table.concat(lines, "\n")
end

-- ------------------------------------------------------------
-- Fenster
-- ------------------------------------------------------------
function ST:ShowWindow()
    if not A:RequireDev() then return false end
    local UI = A.UI
    local C = UI.C
    if not self.window then
        local w = UI:Dialog("AHAnalyzerProSelfTest", 840, 510, L["Test - Selbsttest und Testmodus"])
        w.view = "results"   -- oder "log" (Protokoll des Testmodus)
        w.status = UI:Label(w, "", "GameFontHighlight", C.text)
        w.status:SetPoint("TOPLEFT", 16, -40)
        w.status:SetWidth(800)
        w.table = UI:Table(w, {
            columns = {
                { key = "status", title = L["Ergebnis"], width = 70 },
                { key = "name", title = L["Prüfung"], width = 260 },
                { key = "detail", title = L["Details"], width = 460 },
            },
            rows = 14, rowHeight = 20, noMenu = true, itemTooltip = false,
            cell = function(r, key)
                if r.isLog then
                    if key == "status" then return "|cffff8c1a" .. r.time .. "|r" end
                    if key == "name" then return r.what end
                    return r.detail or ""
                end
                if key == "status" then
                    if r.status == "PASS" then return "|cff33dd55" .. L["bestanden"] .. "|r" end
                    if r.status == "FAIL" then return "|cffff5544" .. L["FEHLER"] .. "|r" end
                    if r.status == "RUN" then return "|cffffcc33" .. L["läuft ..."] .. "|r" end
                    if r.status == "CLIENT" then return "|cff66bbff" .. L["im Client prüfen"] .. "|r" end
                    return "|cff999999" .. L["übersprungen"] .. "|r"
                end
                if key == "name" then return r.group .. " / " .. r.name end
                return r.detail or ""
            end,
            -- Maus drüber: ganzer Text (falls die Spalte zu schmal ist). R3 (Befund 0.65.65, T191): neben dem Fenster statt
            -- am Mauszeiger - sonst lag der Tooltip über den anderen Zeilen und Knöpfen des Fensters
            onHover = function(r)
                UI:AnchorTooltip(w)
                if r.isLog then
                    GameTooltip:SetText(r.what, 1, 1, 1, 1, true)
                    GameTooltip:AddLine(r.detail or "", 0.9, 0.9, 0.9, true)
                    GameTooltip:Show()
                    return
                end
                GameTooltip:SetText(r.group .. " / " .. r.name, 1, 1, 1, 1, true)
                if r.detail and r.detail ~= "" then GameTooltip:AddLine(r.detail, 0.9, 0.9, 0.9, true) end
                GameTooltip:Show()
            end,
            emptyText = L["Noch keine Ergebnisse."],
        })
        w.table:SetPoint("TOPLEFT", 14, -64)
        -- Testroutine (GoldSentinelTest): "Alles testen" = /ahs testroutine, "Mit Auktionshaus" = /ahs testroutine server
        w.startBtn = UI:Button(w, L["Alles testen"], 140, 26, function() if A.TestRoutine then A.TestRoutine:Start("auto") end end, "primary")
        w.startBtn:SetPoint("BOTTOMLEFT", 16, 14)
        w.savedBtn = UI:Button(w, L["Mit Auktionshaus"], 200, 26, function() if A.TestRoutine then A.TestRoutine:Start("server") end end)
        w.savedBtn:SetPoint("LEFT", w.startBtn, "RIGHT", 6, 0)
        w.savedBtn.tooltip = L["Auktionshaus offen: Scan, Suchen beim Server und simulierter Handel.\nEinzelne Bereiche: /ahs testroutine a ... k, haendler, berufe, post, gildenbank, kampf; /ahs spieltest"]
        w.stopBtn = UI:Button(w, L["Abbrechen"], 110, 26, function()
            if A.TestRoutine and A.TestRoutine.running then A.TestRoutine:Stop() else ST:Cancel() end
        end, "danger")
        w.stopBtn:SetPoint("LEFT", w.savedBtn, "RIGHT", 6, 0)
        w.copyBtn = UI:Button(w, L["Bericht kopieren"], 150, 26, function()
            -- Bericht der Testroutine (ohne Testmodus-Protokoll: das enthält Twink-Namen)
            if A.TestRoutine and A.TestRoutine.lastText then
                UI:ShowTextWindow(L["Testbericht"], A.TestRoutine:ReportText())
            else
                UI:ShowTextWindow(L["Selbsttest"], ST:Report())
            end
        end)
        w.copyBtn:SetPoint("LEFT", w.stopBtn, "RIGHT", 6, 0)
        -- Testmodus: alles von Hand ausprobieren, Handel nur simuliert
        w.tmStatus = UI:Label(w, "", "GameFontHighlightSmall", C.text)
        w.tmStatus:SetPoint("BOTTOMLEFT", 16, 52)
        w.tmStatus:SetWidth(470)
        w.tmStatus:SetJustifyH("LEFT")
        w.tmBtn = UI:Button(w, L["Testmodus starten"], 170, 26, function() TM:Toggle() end)
        w.tmBtn:SetPoint("BOTTOMRIGHT", -16, 46)
        w.tmBtn.tooltip = L["Alle Funktionen mit echten Auktionshaus-Daten von Hand ausprobieren.\nKaufen, Bieten, Sniper, Einstellen, Abbrechen, Händler und Post sind nur simuliert.\nDeine Einstellungen und Daten werden beim Beenden wiederhergestellt."]
        w.viewBtn = UI:Button(w, L["Protokoll"], 120, 26, function()
            w.view = (w.view == "log") and "results" or "log"
            w:Refresh()
        end)
        w.viewBtn:SetPoint("RIGHT", w.tmBtn, "LEFT", -6, 0)
        w.viewBtn.tooltip = L["Umschalten: Ergebnisse des Selbsttests / Protokoll des Testmodus"]
        function w:Refresh()
            local rows = {}
            if self.view == "log" then
                for _, e in ipairs(TM.log) do table.insert(rows, { isLog = true, time = e.time, what = e.what, detail = e.detail }) end
            else
                for _, r in ipairs(ST.results or {}) do table.insert(rows, r) end
            end
            if self.view ~= "log" and ST.running and ST.current then
                table.insert(rows, { group = ST.current.group, name = ST.current.name, status = "RUN",
                                     detail = ST.wait and L["wartet auf den Server ..."] or "" })
            end
            self.table:SetData(rows, true)
            if #rows > self.table.numRows then
                self.table.offset = math.max(0, #rows - self.table.numRows)
                self.table:Render()
            end
            local c = ST:Counts()
            local TR = A.TestRoutine
            if TR and TR.running then
                self.status:SetText(string.format(L["|cffffcc33Läuft ...|r  %d bestanden, %d Fehler, %d übersprungen - Auktionshaus offen lassen."], c.PASS, c.FAIL, c.SKIP))
            elseif TR and TR.lastSummary then
                self.status:SetText(TR.lastSummary)
            elseif ST.running then
                self.status:SetText(string.format(L["|cffffcc33Läuft ...|r  %d bestanden, %d Fehler, %d übersprungen - Auktionshaus offen lassen."], c.PASS, c.FAIL, c.SKIP))
            elseif A.db.selftest then
                local t = A.db.selftest
                self.status:SetText(string.format(L["Letzter Test %s: %s%d bestanden, %d Fehler|r, %d übersprungen (%d Sek.)"], t.date or "?",
                    (t.fail or 0) == 0 and "|cff33dd55" or "|cffff5544", t.pass or 0, t.fail or 0, t.skip or 0, t.seconds or 0))
            else
                self.status:SetText(L["Prüft alle Funktionen. 'Alles testen' geht ohne Auktionshaus, 'Mit Auktionshaus' braucht es offen.\nKaufen, Einstellen, Post und Händler sind während des Tests nur simuliert."])
            end
            local busy = ST.running or (TR and TR.running) or false
            self.startBtn:SetActive(not busy)
            self.savedBtn:SetActive(not busy)
            self.stopBtn:SetActive(busy)
            if TM.active then
                self.tmStatus:SetText("|cffff5544" .. L["TESTMODUS AN"] .. "|r - " .. L["alles im Addon ausprobieren: Kaufen, Bieten, Sniper, Einstellen, Abbrechen sind nur simuliert. Blizzards eigene AH-Knöpfe kaufen echt!"])
                self.tmBtn:SetText(L["Testmodus beenden"])
            else
                self.tmStatus:SetText(L["Testmodus: aus. Starten, um alles von Hand gefahrlos auszuprobieren (echte Angebote, Handel nur simuliert)."])
                self.tmBtn:SetText(L["Testmodus starten"])
            end
            self.tmBtn:SetActive(not busy)
            self.viewBtn:SetText(self.view == "log" and L["Ergebnisse"] or L["Protokoll"])
        end
        w:SetScript("OnShow", function(self) self:Refresh() end)
        self.window = w
    end
    if not self.results and A.db.selftest then self.results = A.db.selftest.results end
    self.window:Show()
    self.window:Refresh()
    return self.window
end

local ticker = CreateFrame("Frame")
local acc = 0
ticker:SetScript("OnUpdate", function(_, dt)
    if not ST.running then return end
    acc = acc + (dt or 0)
    if acc < 0.25 then return end
    acc = 0
    ST:Poll()
    if ST.window and ST.window:IsShown() and ST.wait then ST.window:Refresh() end
end)

-- ============================================================
-- Testmodus: alle Funktionen von Hand ausprobieren - mit echten Auktionshaus-Daten,
-- aber jeder Handel ist nur simuliert.
--   * Kaufen, Bieten, Sniper, Einstellen, Abbrechen: der Befehl an den Server wird abgefangen,
--     die Antwort des Servers wird nachgespielt (Meldungen, Buchhaltung, Sniper-Zähler wie echt)
--   * Händler-Verkauf, Post abholen, Post an Twinks: nur protokolliert
--   * Einstellungen, Listen, Buchhaltung, Sniper, Wächter, Verkaufen: beim Start gesichert,
--     beim Beenden (oder beim nächsten Laden, z. B. nach /reload) wiederhergestellt
--   * Marktdaten und Scans bleiben echt
-- Öffnen: Knopf "Test" oben im Fenster, /ahs testmodus
-- ============================================================
-- (TM ist oben bei ST angelegt)

-- alles, was man im Addon von Hand ändern kann (Marktdaten, Scans und Sync bleiben echt)
local SNAP_KEYS = { "watchlist", "settings", "lists", "ledger", "seller", "watcher", "sniper",
    "buyFavorites", "repost", "mailRules" }
local SIM_FUNCS = { "PlaceBid", "StartCommoditiesPurchase", "ConfirmCommoditiesPurchase", "CancelCommoditiesPurchase",
    "PostItem", "PostCommodity", "CancelAuction" }

local function Copy(v)
    if type(v) ~= "table" then return v end
    local c = {}
    for k, x in pairs(v) do c[k] = Copy(x) end
    return c
end

-- Inhalt ersetzen, ohne die Tabelle zu tauschen (Module halten Verweise)
local function Replace(target, source)
    if type(target) ~= "table" or type(source) ~= "table" then return end
    for k in pairs(target) do target[k] = nil end
    for k, v in pairs(source) do target[k] = v end
end

function TM:IsActive() return self.active end

function TM:Log(what, detail)
    table.insert(self.log, { time = date("%H:%M:%S"), what = what, detail = detail or "" })
    while #self.log > 200 do table.remove(self.log, 1) end
    if ST.window and ST.window:IsShown() then ST.window:Refresh() end
end

local function Later(fn) if C_Timer and C_Timer.After then C_Timer.After(0.3, fn) else fn() end end

-- Server-Antworten nachspielen
local function SimPlaceBid(auctionID, amount)
    -- Sofortkauf, Sniper-Kauf oder Gebot? Einkauf und Sniper merken sich den Kauf direkt VOR dem Befehl.
    local sb = A.Sniper and A.Sniper.buying
    local bb = A.Buy and A.Buy.buying
    local kind = (sb and sb.auctionID == auctionID and "sniper") or (bb and bb.auctionID == auctionID and "buy") or nil
    Later(function()
        if kind then
            local buy = kind == "sniper" and A.Sniper.lastPurchase or A.Buy.lastPurchase
            local qty, id = buy and buy.qty or 1, buy and buy.itemID
            TM:Log(kind == "sniper" and L["Sniper-Kauf"] or L["Sofortkauf"],
                string.format("%dx %s - %s", qty, id and A:GetItemName(id) or "?", A:FormatMoney(amount)))
            A:SimulateAHEvent("AUCTION_HOUSE_PURCHASE_COMPLETED", auctionID)
        else
            TM:Log(L["Gebot"], string.format(L["Angebot %s - %s"], tostring(auctionID), A:FormatMoney(amount or 0)))
            A:Print(string.format(L["Gebot abgegeben: "] .. "%s", A:FormatMoney(amount or 0)))
        end
    end)
end

local function SimStartCommodity(itemID, qty)
    Later(function()
        local p = (A.Buy and A.Buy.pending and A.Buy.pending.itemID == itemID and A.Buy.pending)
            or (A.Sniper and A.Sniper.pending and A.Sniper.pending.itemID == itemID and A.Sniper.pending)
        local total = p and p.expected
        if not total then
            A:SimulateAHEvent("COMMODITY_PRICE_UNAVAILABLE")
            return
        end
        TM:Log(L["Preis geprüft"], string.format("%dx %s - %s", qty or 1, A:GetItemName(itemID), A:FormatMoney(total)))
        A:SimulateAHEvent("COMMODITY_PRICE_UPDATED", math.floor(total / math.max(1, qty or 1)), total)
    end)
end

local function SimConfirmCommodity(itemID, qty)
    -- Sniper oder Einkauf? Beide merken sich den Kauf (mit erwartetem Gesamtpreis) VOR dem Befehl.
    -- (Sniper/Einkauf setzen "confirming" direkt vor dem Befehl; "pending" ist da schon leer)
    local sp = A.Sniper and (A.Sniper.confirming or A.Sniper.pending)
    local bp = A.Buy and (A.Buy.confirming or A.Buy.pending)
    if A.Sniper then A.Sniper.confirming = nil end
    if A.Buy then A.Buy.confirming = nil end
    local kind = (sp and sp.itemID == itemID and "sniper") or "buy"
    local p = (kind == "sniper" and sp) or (bp and bp.itemID == itemID and bp) or nil
    local total = p and (p.total or p.expected)
    local what = (kind == "sniper" and (p and p.auto) and (L["Sniper-Kauf"] .. " (" .. L["Wächter"] .. ")"))
        or (kind == "sniper" and L["Sniper-Kauf"]) or L["Sofortkauf"]
    Later(function()
        TM:Log(what,
            string.format("%dx %s", qty or 1, A:GetItemName(itemID)) .. (total and (" - " .. A:FormatMoney(total)) or ""))
        A:SimulateAHEvent("COMMODITY_PURCHASE_SUCCEEDED")
    end)
end

local function SimPost(fn, loc, duration, a3, a4, a5)
    local qty, price
    if fn == "PostItem" then qty, price = 1, a5 else qty, price = a3, a4 end
    local p = A.Seller and A.Seller.pendingPost
    local itemID = p and p.itemID
    Later(function()
        p = p or (A.Seller and A.Seller.pendingPost)
        itemID = itemID or (p and p.itemID)
        TM:Log(L["Einstellen"], string.format("%dx %s - %s/" .. L["Stück"], qty or 1,
            itemID and A:GetItemName(itemID) or "?", A:FormatMoney(price or 0)))
        -- als fiktive Auktion in "Meine Auktionen" zeigen
        if itemID then table.insert(TM.fakeOwned, ST.FakeAuction(itemID, qty or 1, price or 1)) end
        A:SimulateAHEvent("AUCTION_HOUSE_AUCTION_CREATED", 0)
    end)
end

local function SimCancel(auctionID)
    Later(function()
        local c = A.Seller and A.Seller.pendingCancel
        TM:Log(L["Abbrechen"], (c and string.format("%dx %s", c.qty or 1, c.name or "?") or tostring(auctionID))
            .. (ST.IsFakeAuction(auctionID) and (" (" .. L["fiktive Auktion"] .. ")") or ""))
        ST.RemoveFake(TM.fakeOwned, auctionID)
        A:SimulateAHEvent("AUCTION_CANCELED", auctionID)
    end)
end

function TM:InstallGuard()
    local real = A.AH
    if not real or self.realAH then return end
    self.realAH = real
    local proxy = {}
    for _, f in ipairs(SIM_FUNCS) do
        if real[f] then
            proxy[f] = function(...)
                if f == "PlaceBid" then SimPlaceBid(...)
                elseif f == "StartCommoditiesPurchase" then SimStartCommodity(...)
                elseif f == "ConfirmCommoditiesPurchase" then SimConfirmCommodity(...)
                elseif f == "PostItem" or f == "PostCommodity" then SimPost(f, ...)
                elseif f == "CancelAuction" then SimCancel(...)
                end
            end
        end
    end
    AddOwnedOverrides(proxy, real, function() return TM.fakeOwned end)
    A.AH = setmetatable(proxy, { __index = real })
end

function TM:RemoveGuard()
    if self.realAH then A.AH = self.realAH; self.realAH = nil end
end

-- ------------------------------------------------------------
-- Testmodus: fiktive Auktionen und Test-Briefkasten
-- ------------------------------------------------------------
TM.fakeOwned, TM.fakeMail, TM.mailMoney = {}, {}, 0

-- Items mit Marktdaten und Namen (für glaubwürdige Testdaten)
local function TestItems(n)
    local out = {}
    for _, id in ipairs(ScannedItems(60)) do
        local name = A:GetItemName(id)
        if name and name ~= "" and name ~= "?" and not name:find("^Item ") then
            table.insert(out, { id = id, name = name, price = A:GetCurrent(id) or 10000 })
            if #out >= n then break end
        end
    end
    return out
end

function TM:SeedAuctions()
    wipe(self.fakeOwned)
    local items = TestItems(3)
    self.soldFake = nil
    -- unterboten (zu teuer), günstigstes, verkauft (dazu passt der Brief "Auktion erfolgreich")
    if items[1] then table.insert(self.fakeOwned, ST.FakeAuction(items[1].id, 1, math.floor(items[1].price * 1.5))) end
    if items[2] then table.insert(self.fakeOwned, ST.FakeAuction(items[2].id, 1, math.max(1, math.floor(items[2].price * 0.9)))) end
    if items[3] then
        local a = ST.FakeAuction(items[3].id, 1, items[3].price, true)
        table.insert(self.fakeOwned, a)
        self.soldFake = { id = items[3].id, name = items[3].name, price = a.buyoutAmount, auctionID = a.auctionID }
    end
end

local function Subject(global, fallback, name)
    local fmt = _G[global]
    if type(fmt) ~= "string" or fmt == "" then fmt = fallback end
    local ok, txt = pcall(string.format, fmt, name)
    return ok and txt or (fallback:gsub("%%s", name))
end

function TM:SeedMail()
    wipe(self.fakeMail)
    self.mailMoney = 0
    local it = TestItems(8)
    local function item(k) return it[k] or it[#it] or it[1] end
    if not it[1] then return end
    -- andere Items als bei den fiktiven Auktionen (1-3), der Verkauf passt zur verkauften Auktion
    local sold, won, expired, removed, outbid = self.soldFake or item(3), item(4), item(5), item(6), item(7)
    -- abgelaufene Ware: ein Item aus den Taschen, damit "Neu einstellen" es auch anbieten kann
    local bag = SellableBagItem()
    if bag and bag.itemID then
        expired = { id = bag.itemID, name = A:GetItemName(bag.itemID), price = A:GetCurrent(bag.itemID) or expired.price }
    end
    local salePrice = sold.price
    local cut = math.floor(salePrice * 0.05)
    -- verkauft: Gold + Rechnung
    table.insert(self.fakeMail, { sender = L["Auktionshaus"], subject = Subject("AUCTION_SOLD_MAIL_SUBJECT", "Auction successful: %s", sold.name),
        money = salePrice - cut, items = {}, soldAuctionID = sold.auctionID,
        invoice = { "seller", sold.name, L["Testkäufer"], salePrice, salePrice, 0, cut, 1 } })
    -- gewonnen: Item + Rechnung
    table.insert(self.fakeMail, { sender = L["Auktionshaus"], subject = Subject("AUCTION_WON_MAIL_SUBJECT", "Auction won: %s", won.name),
        money = 0, items = { { id = won.id, name = won.name, count = 1 } },
        invoice = { "buyer", won.name, L["Testverkäufer"], won.price, won.price, 0, 0, 1 } })
    -- abgelaufen: Ware zurück (-> Liste zum Neu-Einstellen)
    table.insert(self.fakeMail, { sender = L["Auktionshaus"], subject = Subject("AUCTION_EXPIRED_MAIL_SUBJECT", "Auction expired: %s", expired.name),
        money = 0, items = { { id = expired.id, name = expired.name, count = 5 } }, returned = true })
    -- abgebrochen: Ware zurück
    table.insert(self.fakeMail, { sender = L["Auktionshaus"], subject = Subject("AUCTION_REMOVED_MAIL_SUBJECT", "Auction cancelled: %s", removed.name),
        money = 0, items = { { id = removed.id, name = removed.name, count = 1 } }, returned = true })
    -- überboten: Gebot zurück
    table.insert(self.fakeMail, { sender = L["Auktionshaus"], subject = Subject("AUCTION_OUTBID_MAIL_SUBJECT", "Outbid on %s", outbid.name),
        money = math.max(1, math.floor(outbid.price * 0.8)), items = {} })
    -- normaler Brief (nur "Alles" holt ihn ab)
    table.insert(self.fakeMail, { sender = L["Testfreund"], subject = L["Hallo aus dem Test"], money = 10000,
        items = { { id = sold.id, name = sold.name, count = 1 } } })
end

local function MailLink(e) return "|cffffffff|Hitem:" .. e.id .. "::::::::|h[" .. e.name .. "]|h|r" end

local function CleanupMail(i)
    local m = TM.fakeMail[i]
    if m and (m.money or 0) == 0 and #m.items == 0 then table.remove(TM.fakeMail, i) end
    -- der "Server" hat geantwortet: der Abholer darf weitermachen, die Buchhaltung liest neu
    Later(function()
        if A.Mailer then A.Mailer.waiting = nil end
        if A.Fire then A:Fire("MAILER_CHANGED") end
    end)
end

local TEST_INBOX = {
    GetInboxNumItems = function() return #TM.fakeMail, #TM.fakeMail end,
    GetInboxHeaderInfo = function(i)
        local m = TM.fakeMail[i]
        if not m then return nil end
        return nil, nil, m.sender, m.subject, m.money or 0, 0, 29.5, #m.items, false, m.returned or false, false, false, false
    end,
    GetInboxInvoiceInfo = function(i)
        local m = TM.fakeMail[i]
        if not (m and m.invoice) then return nil end
        local v = m.invoice
        return v[1], v[2], v[3], v[4], v[5], v[6], v[7], 0, nil, nil, v[8]
    end,
    GetInboxItem = function(i, a)
        local m = TM.fakeMail[i]
        local e = m and m.items[a]
        if not e then return nil end
        return e.name, e.id, nil, e.count, 1, true
    end,
    GetInboxItemLink = function(i, a)
        local m = TM.fakeMail[i]
        local e = m and m.items[a]
        return e and MailLink(e) or nil
    end,
    TakeInboxMoney = function(i)
        local m = TM.fakeMail[i]
        if not m or (m.money or 0) <= 0 then return end
        TM.mailMoney = TM.mailMoney + m.money
        TM:Log(L["Post abholen"], string.format(L["Gold: %s (%s)"], A:FormatMoney(m.money), m.subject))
        m.money = 0
        -- Erlös abgeholt: die verkaufte fiktive Auktion verschwindet aus "Meine Auktionen" (wie im Spiel)
        if m.soldAuctionID and ST.RemoveFake(TM.fakeOwned, m.soldAuctionID) and A.Seller and A.Seller.ReadOwned then
            Later(function() pcall(A.Seller.ReadOwned, A.Seller) end)
        end
        CleanupMail(i)
    end,
    TakeInboxItem = function(i, a)
        local m = TM.fakeMail[i]
        local e = m and m.items[a]
        if not e then return end
        TM:Log(L["Post abholen"], string.format(L["Item: %dx %s (%s)"], e.count or 1, e.name, m.subject))
        table.remove(m.items, a)
        CleanupMail(i)
    end,
}

function TM:InstallInbox()
    if self.realInbox then return end
    self.realInbox = {}
    for k, fn in pairs(TEST_INBOX) do
        self.realInbox[k] = A.Inbox[k]
        A.Inbox[k] = fn
    end
end

function TM:RemoveInbox()
    if not self.realInbox then return end
    for k, fn in pairs(self.realInbox) do A.Inbox[k] = fn end
    self.realInbox = nil
end

-- im Briefkasten "abgeholtes" Testgold (nur gezählt) - liest und leert den Zähler
function TM:TakeMailMoneyCount()
    local m = self.mailMoney or 0
    self.mailMoney = 0
    return m
end

-- Chat-Meldungen im Testmodus markieren
local realPrint
local function HookPrint()
    if realPrint then return end
    realPrint = A.Print
    A.Print = function(me, msg, ...) return realPrint(me, "|cffff8c1a[" .. L["Test"] .. "]|r " .. tostring(msg), ...) end
end
local function UnhookPrint()
    if realPrint then A.Print = realPrint; realPrint = nil end
end

local function Restore(backup)
    if not (backup and A.db) then return end
    for _, k in ipairs(SNAP_KEYS) do
        if backup[k] ~= nil then
            if type(A.db[k]) == "table" and type(backup[k]) == "table" then Replace(A.db[k], backup[k]) else A.db[k] = backup[k] end
        elseif backup.__missing and backup.__missing[k] then
            -- gab es vor dem Test noch nicht (z. B. erster Favorit im Test): wieder leeren
            if type(A.db[k]) == "table" then wipe(A.db[k]) else A.db[k] = nil end
        end
    end
end

-- sichtbare Folgen wiederhergestellter Einstellungen (Minikarten-Knopf, Design, Sprache)
local function ApplyRestoredSettings(themeBefore, langBefore)
    local st = A.db and A.db.settings
    if not st then return end
    if A.FloatingButton then
        if A.SetMinimapAngle then
            local saved = st.minimapAngle
            pcall(A.SetMinimapAngle, A, saved or 225)   -- 225 = Standardplatz
            st.minimapAngle = saved
        end
        if A.SetMinimapButtonShown then pcall(A.SetMinimapButtonShown, A, not st.minimapHide) end
    end
    if A.UI and A.UI.frame or (A.UI and A.UI.ahHost) then
        if st.uiLanguage ~= langBefore and A.ApplyUILanguage then
            pcall(A.ApplyUILanguage, A)
            pcall(A.Fire, A, "LANGUAGE_CHANGED", A.uiLang)
        elseif st.theme ~= themeBefore and A.UI.Rebuild then
            pcall(A.UI.Rebuild, A.UI)
        end
    end
end

local function ClearPending()
    local B, Sn, Se, X, M = A.Buy, A.Sniper, A.Seller, A.Extras, A.Mailer
    if B then B.pending, B.lastPurchase, B.lastBid = nil, nil, nil end
    if Sn then Sn.pending, Sn.lastPurchase, Sn.result = nil, nil, nil end
    if Se then Se.pendingPost, Se.pendingCancel = nil, nil end
    if X then X.selling, X.mailPending = nil, nil end
end

local function Changed()
    for _, e in ipairs({ "TESTMODE_CHANGED", "DATA_CHANGED", "SNIPER_CHANGED", "WATCHER_CHANGED", "SELLER_CHANGED", "LISTS_CHANGED", "WATCHLIST_CHANGED" }) do
        pcall(A.Fire, A, e)
    end
    if A.UI and A.UI.UpdateStatus then pcall(A.UI.UpdateStatus, A.UI) end
    if A.UI and A.UI.RefreshActive then pcall(A.UI.RefreshActive, A.UI) end
    if ST.window and ST.window:IsShown() then ST.window:Refresh() end
end

function TM:Start()
    if not A:RequireDev() then return false end
    if self.active then return true end
    if not A.db then return false end
    if ST.running or (A.TestRoutine and A.TestRoutine.running) then A:Print(L["Selbsttest läuft schon ..."]); return false end
    local backup = { __missing = {} }
    for _, k in ipairs(SNAP_KEYS) do
        if A.db[k] == nil then backup.__missing[k] = true else backup[k] = Copy(A.db[k]) end
    end
    A.db.testMode = { active = true, started = time(), backup = backup }
    self:SeedAuctions()
    self:SeedMail()
    self:InstallGuard()
    self:InstallInbox()
    HookPrint()
    self.active = true
    -- fiktive Auktionen gleich in "Meine Auktionen" zeigen (nicht erst nach "Aktualisieren")
    if A.Seller and A.Seller.ReadOwned then pcall(A.Seller.ReadOwned, A.Seller) end
    wipe(self.log)
    self:Log(L["Testmodus AN"], L["Daten gesichert - Handel nur simuliert"])
    self:Log(L["Testdaten"], string.format(L["%d fiktive Auktionen in 'Meine Auktionen', %d fiktive Briefe im Briefkasten"], #self.fakeOwned, #self.fakeMail))
    A:Print(L["|cffff5544Testmodus AN|r - alle Funktionen mit echten Auktionshaus-Daten ausprobieren. Kaufen, Bieten, Einstellen, Abbrechen, Händler und Post sind nur simuliert. Deine Daten werden beim Beenden wiederhergestellt."])
    A:Print(L["Achtung: Nur die Knöpfe von AHSentinel sind simuliert - die eigenen Knöpfe des Auktionshauses (Blizzard) kaufen echt!"])
    Changed()
    return true
end

function TM:Stop(silent)
    if not self.active then return end
    if ST.running then A:Print(L["Selbsttest läuft schon ..."]); return end
    local n = 0
    for _, e in ipairs(self.log) do
        if e.what ~= L["Testmodus AN"] and e.what ~= L["Testdaten"] then n = n + 1 end
    end
    self:RemoveGuard()
    self:RemoveInbox()
    wipe(self.fakeOwned); wipe(self.fakeMail); self.mailMoney = 0
    if A.Seller and A.Seller.ReadOwned and A.AH and A.AH.GetNumOwnedAuctions then pcall(A.Seller.ReadOwned, A.Seller) end
    ClearPending()
    local themeBefore = A.db and A.db.settings and A.db.settings.theme
    local langBefore = A.db and A.db.settings and A.db.settings.uiLanguage
    Restore(A.db and A.db.testMode and A.db.testMode.backup)
    ApplyRestoredSettings(themeBefore, langBefore)
    if A.db then A.db.testMode = nil end
    self.active = false
    UnhookPrint()
    self:Log(L["Testmodus AUS"], L["Daten wiederhergestellt"])
    if not silent then
        A:Print(string.format(L["|cff33dd55Testmodus AUS|r - alle Daten wiederhergestellt (%d simulierte Aktionen)."], math.max(0, n)))
    end
    Changed()
end

function TM:Toggle()
    if self.active then self:Stop() else self:Start() end
end

-- Protokoll als Text (für den Bericht)
function TM:Report()
    local lines = { "", "=== " .. L["Testmodus - Protokoll"] .. " ===" }
    if #self.log == 0 then table.insert(lines, L["(leer)"]) end
    for _, e in ipairs(self.log) do
        table.insert(lines, string.format("%s  %s - %s", e.time, e.what, e.detail))
    end
    return table.concat(lines, "\n")
end

-- Abgestürzt oder neu geladen mitten im Test: echte Daten zurück
A:On("READY", function()
    if A.db and A.db.testMode then
        Restore(A.db.testMode.backup)
        A.db.testMode = nil
        ApplyRestoredSettings(A.db.settings.theme, A.db.settings.uiLanguage)
        A:Print(L["Testmodus vom letzten Mal beendet - deine echten Daten sind wiederhergestellt."])
    end
end)


-- Sprach- oder Designwechsel: das Test-Fenster neu aufbauen (nicht mitten im Test)
A:On("THEME_CHANGED", function()
    if ST.running or not ST.window then return end
    local shown = ST.window:IsShown()
    ST.window:Hide()
    ST.window = nil
    if shown then ST:ShowWindow() end
end)
