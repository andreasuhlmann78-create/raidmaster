local _, ns = ...
local L = ns.L

-- Amount window at the vendor (wish of the user, 9 Nov.): Shift+click on a ware in Blizzard's merchant window opens a
-- small window of ProfessionSentinel instead of Blizzard's split dialog (which only goes up to one stack).
-- Free amount (pre-filled: what the shopping list misses, otherwise one stack), price per piece/bundle, total;
-- "Buy" buys exactly that amount over several purchases with the same function as the shopping list
-- (ns.Plan.BuyAmount -> ns.Act). Right click (buy 1) and left click (pick up) stay as they are; with the chat input
-- active, Shift+click only inserts the link (Blizzard). No taint: only hooksecurefunc, Blizzard's dialog is just
-- hidden afterwards. Option "merchantQty" (default on), /ps menge.

local MQ = {}
ns.MerchantQty = MQ

local win          -- the window (created on first use)
MQ.FRAME_NAME = "ProfessionSentinelMerchantQty"
MQ.slot, MQ.itemID = nil, nil

function MQ.Enabled() return not ns.db or ns.db.merchantQty ~= false end

-- small wrappers (the test routine hands in stand-ins; nothing of Blizzard is replaced)
function MQ.ShiftDown() return IsShiftKeyDown and IsShiftKeyDown() and true or false end
function MQ.ChatActive()
    local eb = ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow()
    return eb ~= nil and eb.IsShown and eb:IsShown() and true or false
end
function MQ.SplitFrame() return _G.StackSplitFrame end
function MQ.BuyTab() return not (MerchantFrame and MerchantFrame.selectedTab) or MerchantFrame.selectedTab == 1 end

-- default amount: what the shopping list misses, otherwise one stack (one bundle for bundled goods)
function MQ.Default(slot, itemID)
    local plan = ns.Plan and ns.Plan.current
    for _, e in ipairs(plan and plan.list or {}) do
        if e.id == itemID and (e.missing or 0) > 0 then return e.missing end
    end
    local _, _, _, stackCount = ns.Plan.MerchantItemInfo(slot)
    if (stackCount or 1) > 1 then return stackCount end
    return math.max(1, ns.Plan.MerchantMaxStack(slot) or 1)
end

-- what the window shows for n pieces: the purchase plan (same rules as the shopping list) and the hint
function MQ.Preview(slot, n)
    local PL = ns.Plan
    local _, _, price, stackCount, numAvailable = PL.MerchantItemInfo(slot)
    stackCount = math.max(1, stackCount or 1)
    local plan = PL.PlanPurchase(n, price, stackCount, numAvailable, PL.MerchantMaxStack(slot), nil, nil)
    local hint
    if plan.limit == "stock" then hint = string.format(L.MQ_HINT_STOCK, plan.bought)
    elseif plan.rounded then hint = string.format(L.MQ_HINT_BUNDLE, stackCount, plan.bought) end
    return plan, hint, price or 0, stackCount
end

---------------------------------------------------------------------------
-- Window
---------------------------------------------------------------------------
local function Amount() return win and tonumber(win.qty:GetText()) or 0 end

local function Update()
    if not (win and MQ.slot) then return end
    local n = Amount()
    local plan, hint, price, stackCount = MQ.Preview(MQ.slot, n)
    local P = ns.Prices
    win.price:SetText(stackCount > 1 and string.format(L.MQ_PER_BUNDLE, stackCount, P.MoneyPlain(price))
        or string.format(L.MQ_PER_PIECE, P.MoneyPlain(price)))
    win.total:SetText(string.format(L.MQ_TOTAL, plan.bought, P.MoneyPlain(plan.spent)))
    win.hint:SetText(hint or "")
    win.buy:SetEnabled(n >= 1 and plan.bought > 0)
end
MQ.Update = Update

local function Create()
    if win then return win end
    local tmpl = BackdropTemplateMixin and "BackdropTemplate" or nil
    win = CreateFrame("Frame", MQ.FRAME_NAME, UIParent, tmpl)
    win:SetSize(230, 132)
    win:SetFrameStrata("DIALOG")
    if win.SetBackdrop then
        win:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 24,
            insets = { left = 6, right = 6, top = 6, bottom = 6 } })
    end
    win:EnableMouse(true)
    win:Hide()
    -- Esc closes the window wherever the focus is (Blizzard's list of frames closed by Esc; only appended)
    if type(_G.UISpecialFrames) == "table" then table.insert(_G.UISpecialFrames, MQ.FRAME_NAME) end
    win:SetScript("OnHide", function() MQ.slot, MQ.itemID = nil, nil end)
    if ns.RegisterUI then ns.RegisterUI(win, "Mengenfenster Händler") end
    win.icon = win:CreateTexture(nil, "ARTWORK")
    win.icon:SetSize(28, 28)
    win.icon:SetPoint("TOPLEFT", 14, -14)
    win.name = win:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    win.name:SetPoint("TOPLEFT", win.icon, "TOPRIGHT", 6, 0)
    win.name:SetPoint("RIGHT", win, "RIGHT", -12, 0)
    win.name:SetJustifyH("LEFT")
    win.name:SetWordWrap(false)
    win.price = win:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    win.price:SetPoint("TOPLEFT", win.name, "BOTTOMLEFT", 0, -3)
    win.qty = CreateFrame("EditBox", nil, win, "InputBoxTemplate")
    win.qty:SetSize(60, 20)
    win.qty:SetPoint("TOPLEFT", win.icon, "BOTTOMLEFT", 6, -10)
    win.qty:SetAutoFocus(false)
    win.qty:SetNumeric(true)
    win.qty:SetMaxLetters(5)
    win.qty:SetScript("OnTextChanged", function() Update() end)
    win.qty:SetScript("OnEnterPressed", function() MQ.Buy() end)
    win.qty:SetScript("OnEscapePressed", function() MQ.Close() end)
    win.total = win:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    win.total:SetPoint("LEFT", win.qty, "RIGHT", 10, 0)
    win.hint = win:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    win.hint:SetPoint("TOPLEFT", win.qty, "BOTTOMLEFT", -6, -6)
    win.hint:SetPoint("RIGHT", win, "RIGHT", -12, 0)
    win.hint:SetJustifyH("LEFT")
    win.hint:SetTextColor(0.25, 0.78, 0.92)
    win.buy = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
    win.buy:SetSize(90, 22)
    win.buy:SetPoint("BOTTOMLEFT", 12, 12)
    win.buy:SetText(L.PLAN_BUY_BTN)
    win.buy:SetScript("OnClick", function() MQ.Buy() end)
    win.cancel = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
    win.cancel:SetSize(90, 22)
    win.cancel:SetPoint("BOTTOMRIGHT", -12, 12)
    win.cancel:SetText(L.MQ_CANCEL)
    win.cancel:SetScript("OnClick", function() MQ.Close() end)
    -- mouse wheel: ±1, with Shift ±1 stack
    win:EnableMouseWheel(true)
    win:SetScript("OnMouseWheel", function(_, delta)
        local step = 1
        if MQ.ShiftDown() and MQ.slot then step = math.max(1, ns.Plan.MerchantMaxStack(MQ.slot) or 1) end
        win.qty:SetText(tostring(math.max(1, Amount() + delta * step)))
    end)
    return win
end
MQ.Create = Create
function MQ.Frame() return win end

-- docked right of the merchant window (covers nothing of it)
local function Dock()
    win:ClearAllPoints()
    if MerchantFrame and MerchantFrame.IsShown and MerchantFrame:IsShown() then
        win:SetPoint("TOPLEFT", MerchantFrame, "TOPRIGHT", 4, -24)
    else
        win:SetPoint("CENTER", UIParent, "CENTER", 0, 120)
    end
end

function MQ.Open(slot)
    local PL = ns.Plan
    local itemID = PL.MerchantItemID(slot)
    if not itemID then return false end
    Create()
    MQ.slot, MQ.itemID = slot, itemID
    local name, texture = PL.MerchantItemInfo(slot)
    win.icon:SetTexture(texture or (ns.GetItemIcon and ns.GetItemIcon(itemID)))
    win.name:SetText(name or (ns.ItemName and ns.ItemName(itemID)) or "?")
    win.qty:SetText(tostring(MQ.Default(slot, itemID)))
    Dock()
    win:Show()
    Update()
    win.qty:SetFocus()
    win.qty:HighlightText()
    return true
end

function MQ.Close()
    if win then win.qty:ClearFocus(); win:Hide() end
    MQ.slot, MQ.itemID = nil, nil
end

function MQ.Buy()
    if not (win and MQ.itemID) then return 0 end
    local n = Amount()
    if n < 1 then return 0 end
    local done = ns.Plan.BuyAmount(MQ.itemID, n) or 0
    MQ.Close()
    return done
end

-- the Shift+click on a ware of the merchant window (hooked after Blizzard's own handling)
function MQ.OnModifiedClick(button, mouse)
    if not MQ.Enabled() or (ns.InCombat and ns.InCombat()) then return false end
    if not MQ.ShiftDown() or not MQ.BuyTab() then return false end
    local slot = button and button.GetID and button:GetID()
    if MQ.ChatActive() then
        -- Blizzard inserted the link into the chat: nothing else (our window must not be open for this ware)
        if ns.Spieltest and ns.Spieltest.IsOn() then
            local opened = win ~= nil and win:IsShown() and MQ.slot == slot
            pcall(ns.Spieltest.OnMerchantShift, "chat", not opened)
        end
        return false
    end
    if not slot or slot < 1 then return false end
    -- Blizzard's split dialog (one stack at most) goes away; ours takes over
    local split = MQ.SplitFrame()
    if split and split.IsShown and split:IsShown() and split.Hide then split:Hide() end
    local ok = MQ.Open(slot)
    if ns.Spieltest and ns.Spieltest.IsOn() then
        pcall(ns.Spieltest.OnMerchantShift, "open", ok and not (split and split.IsShown and split:IsShown()))
    end
    return ok
end

-- toggle /ps menge
function MQ.Toggle()
    ns.db.merchantQty = not MQ.Enabled()
    ns.Print(L.MQ_OPTION .. ": " .. (MQ.Enabled() and "|cff40c040an/on|r" or "|cffff4040aus/off|r"))
    if not MQ.Enabled() then MQ.Close() end
end

-- hooks: only hooksecurefunc (nothing replaced), closed with the merchant
local hooked = false
function MQ.Hook()
    if hooked or not hooksecurefunc then return end
    if type(_G.MerchantItemButton_OnModifiedClick) == "function" then
        hooksecurefunc("MerchantItemButton_OnModifiedClick", function(self, mouse) MQ.OnModifiedClick(self, mouse) end)
        hooked = true
    end
end

local f = ns.AddEventFrame(CreateFrame("Frame"), "MerchantQty")
MQ.eventFrame = f
f:RegisterEvent("PLAYER_LOGIN")
pcall(f.RegisterEvent, f, "MERCHANT_SHOW")
pcall(f.RegisterEvent, f, "MERCHANT_CLOSED")
f:SetScript("OnEvent", function(_, event)
    if event == "MERCHANT_CLOSED" then MQ.Close()
    else MQ.Hook() end
end)
