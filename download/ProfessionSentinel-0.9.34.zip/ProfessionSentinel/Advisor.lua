local _, ns = ...
local L = ns.L

-- Rankings for the open profession (learned AND not yet learned recipes):
--
-- 1. "Leveln" – every recipe that gives skill points at your current skill
--      with prices:    sorted by AD.LevelScore: loss -> cost per point, profit -> profit per craft × chance
--                      (shown as gold per skill point = (value - cost) / expected points)
--      without prices: sorted by MATERIAL PER SKILL POINT = reagents / expected points      (lower = better)
--    expected points = chance × points per craft; chance: orange 100 %, from yellow on falling to 0 % at grey
--
-- 2. "Gold verdienen" – every recipe you can craft at your skill, grey ones included,
--    sorted by NET PROFIT PER CRAFT (selling in the AH minus 5 % or to a vendor), needs prices
--
-- 3. "Herstellen & Entzaubern" (enchanters only, "Verzauberer" tab) – buy the reagents, craft,
--    disenchant, sell the materials: every craftable recipe of ALL your professions whose product
--    can be disenchanted, sorted by profit (deValue - cost)
--
-- Prices (Prices.lua): vendor reagents at the vendor price, everything else at the AH value
-- (also farmed material), product at the higher of AH value (minus 5 % cut) and vendor sell value.
-- Only the enchanter tab counts disenchanting.

local AD = {}
ns.Advisor = AD

AD.STAR = "|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t"

-- How often a recipe can be crafted from the bags (nil = no reagents known)
function AD.CraftableCount(r, countFn)
    countFn = countFn or function(id) return ns.GetItemCount(id, false) end
    if not r.reagents or #r.reagents == 0 then return nil end
    local n = math.huge
    for i = 1, #r.reagents, 2 do
        local id, need = r.reagents[i], r.reagents[i + 1]
        if need and need > 0 then n = math.min(n, math.floor((countFn(id) or 0) / need)) end
    end
    return n == math.huge and nil or n
end

function AD.TotalReagents(r)
    local t = 0
    for i = 2, #(r.reagents or {}), 2 do t = t + (r.reagents[i] or 0) end
    return t
end

local function LearnLevel(r)
    return ((r.req or 0) > 1 and r.req) or r.learnLevel or 0
end

-- Can the recipe be crafted (or learned and crafted) at this skill?
function AD.Reachable(r, rank)
    local need = LearnLevel(r)
    return not (need > 1 and rank < need)
end

-- Evaluates one recipe for the given skill (nil if it cannot be crafted yet or has no reagents).
-- e.points = 0 for grey recipes.
function AD.Evaluate(r, rank, countFn, withPrices, withDE)
    if not r or not rank or (r.yellow or 0) <= 0 then return nil end
    if not AD.Reachable(r, rank) then return nil end
    local mats = AD.TotalReagents(r)
    if mats <= 0 then return nil end
    local p = ns.Lifeline.Chance(r, rank)
    local points = p * (r.skillUps or 1)
    local e = {
        recipe = r,
        chance = p,
        points = points,
        mats = mats,
        perPoint = points > 0 and mats / points or nil,
        craftable = AD.CraftableCount(r, countFn),
        orangeLeft = math.max(0, (r.yellow or 0) - rank),
        pointsLeft = math.max(0, (r.grey or 0) - rank),
    }
    -- gold values only with an AH price source (otherwise vendor-only products would look far too cheap)
    if withPrices ~= false and ns.Prices and ns.Prices.SourceName() then
        local pr = ns.Prices.Recipe(r, withDE)
        e.price = pr
        if pr.known then
            -- with disenchanting: the value of a craft is the better of selling and disenchanting (best way)
            e.net = (withDE and pr.bestNet) or pr.net
            e.via = withDE and pr.bestVia or pr.valueSource
            if points > 0 then
                e.netPerPoint = pr.net / points
                e.levelScore = AD.LevelScore(pr.net, points)
            end
            if pr.deNet and pr.deComplete ~= false then e.deNet = pr.deNet end
        end
    end
    return e
end

-- Source priority (for not learned recipes): trainer > friendly vendor > any vendor > drop/quest/chest
function AD.SourceScore(r)
    local S = ns.SRC
    if bit.band(r.src, S.TRAINER) ~= 0 or bit.band(r.src, S.AUTO) ~= 0 then return 4 end
    if bit.band(r.src, S.VENDOR) ~= 0 then
        local WP = ns.Waypoint
        if WP then
            for _, ri in ipairs(r.recipeItems or {}) do
                for _, id in ipairs(ri.v or {}) do
                    if WP.IsFriendly(id) then return 3 end
                end
            end
        end
        return 2
    end
    if bit.band(r.src, S.DROP + S.WORLDDROP + S.QUEST + S.CONTAINER) ~= 0 then return 1 end
    return 0
end

local function TieBreak(a, b)
    if a.learned ~= b.learned then return a.learned end
    if a.chance ~= b.chance then return a.chance > b.chance end
    local ca, cb = (a.craftable or 0) > 0, (b.craftable or 0) > 0
    if ca ~= cb then return ca end
    if (a.craftable or 0) ~= (b.craftable or 0) then return (a.craftable or 0) > (b.craftable or 0) end
    if (a.source or 0) ~= (b.source or 0) then return (a.source or 0) > (b.source or 0) end
    return (a.recipe.name or "") < (b.recipe.name or "")
end

-- Levelling score with prices (higher = better):
--   loss:   cost per point (net / points) – the cheapest way up
--   profit: profit per craft × points per craft – a profitable recipe that rarely gives a point
--           must not win just because many crafts add up (that would be slow levelling)
function AD.LevelScore(net, points)
    if not net or not points or points <= 0 then return nil end
    if net >= 0 then return net * points end
    return net / points
end

-- Levelling order: priced recipes by level score (desc), then unpriced by material per point (asc)
local function BetterLevel(a, b)
    local pa, pb = a.levelScore ~= nil, b.levelScore ~= nil
    if pa ~= pb then return pa end
    if pa then
        local na, nb = math.floor(a.levelScore + 0.5), math.floor(b.levelScore + 0.5)
        if na ~= nb then return na > nb end
    end
    local ma, mb = math.floor((a.perPoint or 0) * 100 + 0.5), math.floor((b.perPoint or 0) * 100 + 0.5)
    if ma ~= mb then return ma < mb end
    return TieBreak(a, b)
end
AD.BetterLevel = BetterLevel

local function BetterGold(a, b)
    -- what hardly sells comes after everything else (no profit recommendation)
    local ha, hb = a.sellCap == 0, b.sellCap == 0
    if ha ~= hb then return hb end
    local na, nb = math.floor(a.net + 0.5), math.floor(b.net + 0.5)
    if na ~= nb then return na > nb end
    return TieBreak(a, b)
end

local function BetterDE(a, b)
    local na, nb = math.floor(a.deNet + 0.5), math.floor(b.deNet + 0.5)
    if na ~= nb then return na > nb end
    return TieBreak(a, b)
end

-- Levelling ranking (recipes giving points). learnedFn / countFn optional (tests)
function AD.Ranking(recipes, rank, learnedFn, countFn, withPrices)
    learnedFn = learnedFn or ns.IsLearned
    local out = {}
    for _, r in ipairs(recipes or {}) do
        local e = AD.Evaluate(r, rank, countFn, withPrices)
        if e and e.points > 0 then
            e.learned = learnedFn(r) and true or false
            if not e.learned then e.source = AD.SourceScore(r) end
            out[#out + 1] = e
        end
    end
    table.sort(out, BetterLevel)
    for i, e in ipairs(out) do e.place = i end
    return out
end

---------------------------------------------------------------------------
-- Levelling by material (ranking tab, section "Levelling – material per skill point")
-- Pure amount of reagents, not their gold value. Intermediate products made by the SAME profession count as their
-- base materials (bars stay bars for blacksmithing: they come from mining). Expected points per craft by colour:
-- orange 1, yellow 0.5, green 0.25, grey 0 (left out) – times the recipe's skill-ups. Value = amount / points.
-- Learned recipes first, then the not learned ones; ties keep the order of the input (stable).
---------------------------------------------------------------------------
AD.COLOUR_POINTS = { orange = 1, yellow = 0.5, green = 0.25, grey = 0 }
-- ranking weight of the material per point: orange preferred (yellow wins only with < 50 % of orange's material)
AD.COLOUR_WEIGHT = { orange = 1, yellow = 2, green = 4, grey = 8 }

function AD.BaseMats(r, depth, seen)
    depth, seen = depth or 0, seen or {}
    if not r or not r.reagents then return 0 end
    seen[r] = true
    local t = 0
    for i = 1, #r.reagents, 2 do
        local id, need = r.reagents[i], r.reagents[i + 1] or 0
        local sub
        if depth < 4 then
            for _, x in ipairs(ns.ByOutput and ns.ByOutput[id] or {}) do
                if x.prof == r.prof and not seen[x] and x.reagents and #x.reagents > 0 then sub = x; break end
            end
        end
        if sub then
            local made = ((sub.outMin or 1) + (sub.outMax or sub.outMin or 1)) / 2
            t = t + need * AD.BaseMats(sub, depth + 1, seen) / math.max(made, 1)
        else
            t = t + need
        end
    end
    seen[r] = nil
    return t
end

function AD.ColourPoints(r, rank)
    if not r or not rank or (r.yellow or 0) <= 0 or (r.grey or 0) <= 0 then return 0 end
    local c
    if rank < r.yellow then c = "orange"
    elseif rank < (r.green or r.grey) then c = "yellow"
    elseif rank < r.grey then c = "green"
    else c = "grey" end
    return AD.COLOUR_POINTS[c] * (r.skillUps or 1), c
end

-- entries (optional): already evaluated entries (AD.Ranking) – saves a second pass over all recipes
function AD.MatRanking(recipes, rank, learnedFn, countFn, entries)
    learnedFn = learnedFn or ns.IsLearned
    local out = {}
    local src = entries or recipes or {}
    for i, x in ipairs(src) do
        local r = entries and x.recipe or x
        local e = entries and x or AD.Evaluate(r, rank, countFn, true)
        local pts, colour = AD.ColourPoints(r, rank)
        if e and pts > 0 then
            local mats = AD.BaseMats(r)
            if mats > 0 then
                if not entries then e.learned = learnedFn(r) and true or false end
                e.colour, e.colourPoints, e.baseMats = colour, pts, mats
                e.matValue = mats / pts
                -- orange first (UI rework U3): yellow only before orange when it needs less than half the
                -- material per point, green likewise against yellow
                e.matKey = e.matValue * (AD.COLOUR_WEIGHT[colour] or 1)
                e.order = i
                out[#out + 1] = e
            end
        end
    end
    table.sort(out, function(a, b)
        if a.learned ~= b.learned then return a.learned end
        local va, vb = math.floor(a.matKey * 1000 + 0.5), math.floor(b.matKey * 1000 + 0.5)
        if va ~= vb then return va < vb end
        return a.order < b.order
    end)
    for i, e in ipairs(out) do e.matPlace = i end
    return out
end

-- Gold ranking (all craftable recipes incl. grey, needs prices; best net profit per craft first)
function AD.GoldRanking(recipes, rank, learnedFn, countFn)
    learnedFn = learnedFn or ns.IsLearned
    local out = {}
    for _, r in ipairs(recipes or {}) do
        if r.out then
            local e = AD.Evaluate(r, rank, countFn, true, true)
            if e and e.net and (e.price.value > 0 or (e.price.deValue or 0) > 0) then
                e.learned = learnedFn(r) and true or false
                if not e.learned then e.source = AD.SourceScore(r) end
                -- what sells: at most what the market takes in ~2 days; "hardly sells" -> no profit recommendation
                local PS = ns.PriceSource
                e.sellCap = PS and PS.SellCap(r.out) or nil
                local pct = PS and PS.MinProfitPct() or 20
                e.belowMin = e.net < (e.price.cost or 0) * pct / 100
                e.recommend = e.sellCap ~= 0 and e.net > 0 and not e.belowMin
                out[#out + 1] = e
            end
        end
    end
    table.sort(out, BetterGold)
    for i, e in ipairs(out) do e.place = i end
    return out
end

-- Craft & disenchant (all craftable recipes incl. grey whose product can be disenchanted;
-- best profit after selling the materials first). recipes may mix professions: rankFn(r) gives
-- the skill for a recipe (default: the given rank)
function AD.DERanking(recipes, rank, learnedFn, countFn, rankFn)
    learnedFn = learnedFn or ns.IsLearned
    local out = {}
    for _, r in ipairs(recipes or {}) do
        local rk = rankFn and rankFn(r) or rank
        if r.out and rk then
            local e = AD.Evaluate(r, rk, countFn, true, true)
            if e and e.deNet then
                e.learned = learnedFn(r) and true or false
                if not e.learned then e.source = AD.SourceScore(r) end
                out[#out + 1] = e
            end
        end
    end
    table.sort(out, BetterDE)
    for i, e in ipairs(out) do e.dePlace = i end
    return out
end

---------------------------------------------------------------------------
-- Cache for the open profession (panel, Blizzard list star, hint on the profession window)
---------------------------------------------------------------------------
AD.current = { prof = nil, rank = nil, ranking = {}, gold = {}, de = {}, mat = {}, best = nil, bestLearned = nil }

local DoUpdate                  -- forward
-- measured for the diagnostic log (LANGSAM over 16 ms); the result is exactly the one of DoUpdate
function AD.Update(prof, rank)
    local t0 = ns.DiagClock and ns.DiagClock()
    local c = ns.Prices and ns.Prices.InPass and ns.Prices.InPass(DoUpdate, prof, rank) or DoUpdate(prof, rank)
    if t0 and ns.DiagSlow then ns.DiagSlow("AD.Update", t0) end
    return c
end

DoUpdate = function(prof, rank)
    local c = AD.current
    if not prof or not rank or not ns.ByProf[prof] then
        c.prof, c.rank = prof, rank
        c.ranking, c.gold, c.de, c.best, c.bestLearned, c.mat = {}, {}, {}, nil, nil, {}
        return c
    end
    -- computed into locals and assigned together at the end: a portioned rebuild (UI.Yield) may hand over to the
    -- next frame in between, and nobody may see half a result meanwhile
    local Y = ns.UI and ns.UI.Yield or function() end
    local ranking = AD.Ranking(ns.ByProf[prof], rank)
    Y()
    local mat = AD.MatRanking(nil, rank, nil, nil, ranking)
    Y()
    local gold = AD.GoldRanking(ns.ByProf[prof], rank)
    Y()
    local de = AD.CurrentDE()
    local bestLearned
    for _, e in ipairs(ranking) do
        if e.learned then bestLearned = e; break end
    end
    c.prof, c.rank = prof, rank
    c.ranking, c.mat, c.gold, c.de, c.best, c.bestLearned = ranking, mat, gold, de, ranking[1], bestLearned
    c.priceSource = ns.Prices and ns.Prices.SourceName()
    return c
end

-- Cached update for the panel and the profession window: computed again only when an input changed (profession,
-- skill, test mode, price source, recipe/learned data via AD.Invalidate) or after 5 s (AH prices move). Drawing,
-- tab switching and typing in the search box then only read the cache.
AD.stamp = 0
AD.CACHE_SECONDS = 30      -- AH prices: computed again at most every 30 s (was 5 s – too often in the event storm)
function AD.Invalidate()
    AD.stamp = AD.stamp + 1
    if ns.Disenchant and ns.Disenchant.InvalidateCache then ns.Disenchant.InvalidateCache() end
end

function AD.UpdateCached(prof, rank)
    local S = ns.Sim
    local key = table.concat({ tostring(prof), tostring(rank), tostring(S), tostring(S and S.known), tostring(S and S.rank),
        tostring(S and S.prof), tostring(ns.Prices and ns.Prices.SourceName()), tostring(AD.stamp) }, "|")
    local now = (GetTime and GetTime()) or 0
    if AD.cacheKey == key and AD.cacheTime and now - AD.cacheTime < AD.CACHE_SECONDS and now >= AD.cacheTime then
        AD.cacheHits = (AD.cacheHits or 0) + 1
        return AD.current
    end
    AD.Update(prof, rank)
    AD.cacheKey, AD.cacheTime = key, now
    AD.computeCount = (AD.computeCount or 0) + 1
    return AD.current
end

-- Craft & disenchant over all professions of this character (enchanters who want gold only)
function AD.CurrentDE()
    local DE = ns.Disenchant
    if not (DE and DE.WantsGold() and ns.Scan) then return {} end
    local all, ranks = {}, {}
    for _, p in ipairs(ns.Scan:PlayerProfessions()) do
        local rk = ns.Scan:Rank(p.id)
        if rk and ns.EffectiveRank then rk = ns.EffectiveRank(rk) end
        if rk and p.id ~= DE.ENCHANTING then
            ranks[p.id] = rk
            for _, r in ipairs(ns.ByProf[p.id] or {}) do all[#all + 1] = r end
        end
    end
    -- test mode: the simulated profession counts as well
    local sp = ns.Sim and ns.Sim.prof
    if sp and not ranks[sp] and sp ~= DE.ENCHANTING then
        ranks[sp] = (ns.Sim.rank) or (ns.Scan:Rank(sp)) or 300
        for _, r in ipairs(ns.ByProf[sp] or {}) do all[#all + 1] = r end
    end
    return AD.DERanking(all, nil, nil, nil, function(r) return ranks[r.prof] end)
end

-- The star marks the best LEARNED levelling recipe (the Blizzard list only shows learned ones)
function AD.IsBest(spell)
    local b = AD.current.bestLearned
    return b and b.recipe.spell == spell or false
end

function AD.Entry(r)
    for _, e in ipairs(AD.current.ranking or {}) do
        if e.recipe == r then return e end
    end
end

function AD.GoldEntry(r)
    for _, e in ipairs(AD.current.gold or {}) do
        if e.recipe == r then return e end
    end
end

function AD.DEEntry(r)
    for _, e in ipairs(AD.current.de or {}) do
        if e.recipe == r then return e end
    end
end

local function Num1(x)
    local s = string.format("%.1f", x)
    if ns.isGerman then s = s:gsub("%.", ",") end
    return s
end
AD.Num1 = Num1

-- Compact value for list rows: "+10s 80c/Pkt" (gold per point) or "2,0 Mat./Pkt" without prices
function AD.Value(e, plain)
    if not e then return "" end
    if e.netPerPoint then
        local P = ns.Prices
        return (plain and P.MoneyPlain(e.netPerPoint, true) or P.Money(e.netPerPoint, true)) .. L.PER_POINT
    end
    if e.perPoint then return string.format(L.RANK_PER_POINT, Num1(e.perPoint)) end
    return ""
end

-- Longer reason for tooltips: "+10s 80c/Pkt · 100 % · 12× aus Taschen"
function AD.Reason(e, short)
    if not e then return "" end
    local parts = { AD.Value(e) }
    if not short then
        parts[#parts + 1] = string.format("%d %%", math.floor(e.chance * 100 + 0.5))
        if e.learned then
            if e.craftable and e.craftable > 0 then
                parts[#parts + 1] = string.format(L.BEST_CRAFTABLE, e.craftable)
            elseif e.craftable == 0 then
                parts[#parts + 1] = L.BEST_NO_MATS
            end
        end
    end
    return table.concat(parts, " · ")
end

-- Coloured "+10s 80c/Pkt" (green profit / red cost); falls back to the material text
function AD.ValueColored(e)
    if e and e.netPerPoint then
        return "|cff" .. (e.netPerPoint >= 0 and "40c040" or "ff6060") .. ns.Prices.MoneyPlain(e.netPerPoint, true) .. L.PER_POINT .. "|r"
    end
    return "|cffffd100" .. AD.Value(e) .. "|r"
end

function AD.NetColored(net)
    if not net then return "?" end
    return "|cff" .. (net >= 0 and "40c040" or "ff6060") .. ns.Prices.MoneyPlain(net, true) .. "|r"
end

-- Dots for the material origins (AH yellow, vendor grey, farm green) – the game's own indicator icons
AD.ORIGIN_ICON = {
    ah = "|TInterface\\COMMON\\Indicator-Yellow:0|t",
    vendor = "|TInterface\\COMMON\\Indicator-Gray:0|t",
    farm = "|TInterface\\COMMON\\Indicator-Green:0|t",
    craft = "|TInterface\\GossipFrame\\TrainerGossipIcon:0|t",      -- made from other materials (cheapest way)
}

function AD.OriginDots(e)
    if not e or not e.price then return "" end
    local out = {}
    for _, k in ipairs({ "ah", "vendor", "farm", "craft" }) do
        if e.price.origins[k] then out[#out + 1] = AD.ORIGIN_ICON[k] end
    end
    return table.concat(out, "")
end

---------------------------------------------------------------------------
-- Levelling plan: from your skill to a target, point by point.
-- At every skill the best recipe by the levelling rule (gold per point with AH prices,
-- otherwise reagents per point; learned recipes win ties). Expected crafts per point =
-- 1 / (chance × points per craft). Consecutive points with the same recipe form one step.
-- Returns plan = { from, to, steps = { { recipe, from, to, crafts, learned } },
--                  reagents = { [itemID] = count }, cost, value, priced }
---------------------------------------------------------------------------
local PlanRaw
-- the plan evaluates many recipes at many skill levels: prices, AH values and bag counts once per pass
function AD.Plan(recipes, fromRank, toRank, learnedFn, withPrices)
    if ns.Prices and ns.Prices.InPass then return ns.Prices.InPass(PlanRaw, recipes, fromRank, toRank, learnedFn, withPrices) end
    return PlanRaw(recipes, fromRank, toRank, learnedFn, withPrices)
end

PlanRaw = function(recipes, fromRank, toRank, learnedFn, withPrices)
    learnedFn = learnedFn or ns.IsLearned
    local P = ns.Prices
    local priced = withPrices ~= false and P and P.SourceName() ~= nil
    -- prices and reagent totals do not depend on the skill: compute once
    local info = {}
    for _, r in ipairs(recipes or {}) do
        local mats = AD.TotalReagents(r)
        if mats > 0 and (r.yellow or 0) > 0 then
            local pr = priced and P.Recipe(r) or nil
            info[#info + 1] = { r = r, mats = mats, pr = pr, net = pr and pr.known and pr.net or nil,
                                learned = learnedFn(r) and true or false }
        end
    end
    local plan = { from = fromRank, to = toRank, steps = {}, reagents = {}, cost = 0, value = 0, priced = priced }
    local cur, crafts = nil, 0
    local s = fromRank
    local guard = 0
    while s < toRank and guard < 1000 do
        guard = guard + 1
        local best, bestScore, bestTie
        for _, x in ipairs(info) do
            if AD.Reachable(x.r, s) then
                local p = ns.Lifeline.Chance(x.r, s) * (x.r.skillUps or 1)
                if p > 0 then
                    -- higher score = better: gold per point (net / p) or minus reagents per point
                    local score
                    if priced and x.net then score = AD.LevelScore(x.net, p) + 1e9 else score = -(x.mats / p) end
                    local tie = (x.learned and 2 or 0) + p
                    if not best or score > bestScore + 1e-6 or (math.abs(score - bestScore) <= 1e-6 and tie > bestTie) then
                        best, bestScore, bestTie = x, score, tie
                    end
                end
            end
        end
        if not best then break end
        local p = ns.Lifeline.Chance(best.r, s) * (best.r.skillUps or 1)
        if cur and cur.x == best then
            cur.to = s + 1
            cur.exact = cur.exact + 1 / p
        else
            cur = { x = best, recipe = best.r, learned = best.learned, from = s, to = s + 1, exact = 1 / p }
            plan.steps[#plan.steps + 1] = cur
        end
        s = s + 1
    end
    plan.reached = s
    for _, st in ipairs(plan.steps) do
        st.crafts = math.ceil(st.exact - 1e-6)
        local r = st.recipe
        for i = 1, #(r.reagents or {}), 2 do
            local id, n = r.reagents[i], r.reagents[i + 1]
            plan.reagents[id] = (plan.reagents[id] or 0) + n * st.crafts
        end
        local pr = st.x.pr
        if pr then
            plan.cost = plan.cost + pr.cost * st.crafts
            plan.value = plan.value + pr.value * st.crafts
        end
        st.x = nil
    end
    return plan
end

-- Shopping list for a plan: what is missing after bags (and bank), split into vendor and AH
-- list = { { id, need, have, missing, origin "vendor"|"ah"|"farm", unit, known } }, totals
function AD.Shopping(plan, countFn)
    countFn = countFn or function(id) return ns.GetItemCount(id, true) end
    local P = ns.Prices
    local list, totals = {}, { vendor = 0, ah = 0, unknown = 0 }
    for id, need in pairs(plan.reagents or {}) do
        local have = countFn(id) or 0
        local missing = math.max(0, need - have)
        local unit, origin, known = P.ReagentUnit(id)
        list[#list + 1] = { id = id, need = need, have = have, missing = missing, origin = origin, unit = unit, known = known }
        if missing > 0 then
            if origin == "vendor" then totals.vendor = totals.vendor + unit * missing
            elseif known then totals.ah = totals.ah + unit * missing
            else totals.unknown = totals.unknown + 1 end
        end
    end
    table.sort(list, function(a, b)
        if (a.missing > 0) ~= (b.missing > 0) then return a.missing > 0 end
        if a.origin ~= b.origin then return a.origin == "vendor" end
        return ns.ItemName(a.id) < ns.ItemName(b.id)
    end)
    return list, totals
end

-- Default target: the cap of your current rank (75/150/225/300); at the cap the next one
function AD.DefaultTarget(rank, maxRank)
    local caps = { 75, 150, 225, 300 }
    if maxRank and maxRank > (rank or 0) then return math.min(maxRank, 300) end
    for _, c in ipairs(caps) do if c > (rank or 0) then return c end end
    return 300
end
