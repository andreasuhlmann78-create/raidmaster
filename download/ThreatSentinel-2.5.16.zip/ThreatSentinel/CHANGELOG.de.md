# ThreatSentinel – Änderungen

## 2.5.16
- Nur für Entwickler (für Spieler ändert sich nichts): neuer Befehl /ts testroutine alles – führt alle automatischen Prüfungen nacheinander in kleinen Portionen aus (höchstens 5 ms je Bild, das Spiel ruckelt nicht), zeigt den Fortschritt („Bereich C (3 von 12)“) und endet mit EINER Zusammenfassung („x von y bestanden, z hier nicht prüfbar – Gründe“). /ts testroutine stop bricht sauber ab; ein /reload oder Ausloggen mittendrin stellt alle echten Daten zurück
- Nur für Entwickler: Prüfliste im Spiel (/ts prüfliste, gemeinsame GoldSentinel-Datei GoldSentinelPruefliste, unverändert übernommen). Jede Prüfung, die das echte Spiel braucht, hat klare Schritte (Wo, nummerierte Schritte, was du siehst, Kosten) und hakt sich selbst ab, sobald du die Funktion wirklich benutzt. Der Stand steht im Testbericht und im Diagnose-Protokoll
- Gemeinsame Datei GoldSentinelDev auf Version 2 (unverändert übernommen)
- Testroutine: neue Fälle T-TR1 bis T-TR3 und T-PL1 bis T-PL3; die Zufallsfälle laufen in kleineren Portionen (20 Fälle je Bild)

## 2.5.15
- Heiler: Das kleine HUD zeigt jetzt auch Heilern, welcher Mitspieler von welchem Mob Aggro hat (so weisst du, wen du zuerst heilen musst). Dieselbe Liste wie beim Tank, keine zusätzliche Rechenzeit im Kampf. Option „Auch als Heiler: wer hat Aggro“ (Standard an; Schadensklassen bekommen es nicht)
- Aggrometer: neue Option „Nur im Kampf“ – ausserhalb des Kampfs bleibt das Aggrometer verborgen (Standard aus, es ändert sich also nichts, solange du es nicht einschaltest)
- Testroutine: neue Fälle T-N1a und T-N1b

## 2.5.14
- Gruppen-Chat: dieselbe Meldung geht höchstens einmal alle 5 Sekunden hinaus. Springt die Aggro schnell hin und her, flutet ThreatSentinel den Gruppen-Chat nicht mehr (Bildschirm-Warnungen und Töne bleiben unverändert)
- Leistung im Kampf wird gemessen: Nach jedem Kampf steht im Diagnose-Protokoll der längste Rahmen, den ThreatSentinel verursacht hat, und welcher Teil darin am meisten brauchte (Ziel: kein Rahmen über 16 ms). /ts protokoll zeigt den letzten Kampf
- Marktdaten-Netz: gemeinsame Datei GoldSentinelMarkt auf Version 7 (unverändert übernommen) – das Weitergeben eines Scans braucht viel weniger Speicher und verursacht keinen langen Ruckler mehr
- Testroutine: ein Sync-Test lässt keinen erfundenen Mitspieler mehr in der gemeinsamen Sync-Datei zurück; neue Fälle T-TS-T1, T-T2, T-T3

## 2.5.13
- Sync läuft jetzt über die gemeinsame GoldSentinel-Datei GoldSentinelSync (Version 2, unverändert übernommen). ThreatSentinel behält seine Kennung „ThreatSentinel“. Was wohin geht: Rollen, Spotts, Widerstände und Kontrollverlust-Meldungen gehen NUR an Gruppe/Schlachtzug – nie an die Gilde, nie über einen Kanal und nie ins Flüster-Netz. Nachrichten von Spielern mit älteren ThreatSentinel-Versionen werden weiter verstanden. Wer noch ThreatSentinel 2.5.12 oder älter hat, versteht die neuen Nachrichten nicht (Tanks erkennt er weiter an der Gruppenrolle) – bitte aktualisieren
- Zurückhalten im Kampf bleibt (der moderne Spiel-Client erlaubt im Kampf keine Addon-Nachrichten; Rollen werden nach dem Kampf gesendet)
- Neuer Befehl /ts sync test: zeigt, wie viele Spieler antworten (Gilde, Gruppe)
- Diagnose-Protokoll: Zeilen von GoldSentinelSync (Wege, Mitspieler, Netz – ohne Namen)
- Testberichte und Marktdaten lassen sich jetzt über GoldSentinelSync teilen, auch wenn ThreatSentinel das einzige GoldSentinel-Addon ist
- Marktdaten-Netz: gemeinsame Datei GoldSentinelMarkt auf Version 3 (unverändert übernommen)
- Testroutine: neue Fälle T-SYNC, T-GS1 bis T-GS5 und T-N1 bis T-N4

## 2.5.12
- Marktdaten-Netz: gemeinsame Datei GoldSentinelMarkt auf Version 2 (unverändert übernommen). Sie liest einen Vollscan nicht mehr ein zweites Mal, wenn AHSentinel geladen ist – das liess das Spiel beim AHSentinel-Vollscan und im Sniper ruckeln
- Testroutine: T-MN2 nimmt ein Test-Item, das es nicht gibt, prüft den Schalter an und aus und stellt die gespeicherten Marktdaten danach wieder her; T-MN3 deckt auch Version 2 ab (AHSentinel geladen, Scan weitergegeben)

## 2.5.11
- Marktdaten-Netz (gemeinsame GoldSentinel-Datei GoldSentinelMarkt v1): ThreatSentinel trägt den anonymen Marktdaten-Leser aller GoldSentinel-Addons mit. Er liest nur mit, wenn ein anderes Addon das ganze Auktionshaus scannt (scannt nie selbst), in kleinen Portionen und nie im Kampf; Namen werden nie gelesen oder gespeichert. Standard an, ausschaltbar in den Einstellungen mit „Marktdaten teilen (anonym, nur Preise)“. Ohne Auktionshaus-Funktionen (ältere Clients) bleibt er still
- Testbericht und Diagnose-Protokoll: Zeile „MARKT-NETZ“ (Version, an/aus, mitgelesene Scans, gesendet/empfangen, Speicher)
- Testroutine: neue Fälle T-MN1 bis T-MN4 (mit und ohne die gemeinsame Datei, Schalter aus, ohne Auktionshaus-API)

## 2.5.10
- Befehlsliste beim Tippen: Wer /ts (oder /threatsentinel) in den Chat tippt, sieht über dem Eingabefeld ALLE Befehle mit kurzer Beschreibung. Jeder weitere Buchstabe filtert („/ts ver“ = verschieben), meistbenutzte oben. Klick (oder Tab) wählt aus, Enter führt aus. Das Chatfeld selbst wird nie beschrieben. Entwickler-Befehle nur für den Entwickler. In den Einstellungen abschaltbar
- Befehls-Handler und Liste benutzen ein und dieselbe Befehlstabelle (in der Liste kann nichts fehlen)
- Grundregel-Wächter im Spiel: Nach jeder Auswertung prüft ThreatSentinel seine Grundregeln nach (Warnung nur über der Schwelle, „gehalten“ nur darunter, Werte nie negativ, Aggro bei einem Mitspieler immer gemeldet). Eine Verletzung steht einmal je Kampf im Diagnose-Protokoll („GRUNDREGEL VERLETZT“, nur Zahlen, keine Namen)
- Testroutine: neuer Bereich U mit umfassenden Tests – 14 Kampflagen durch alle Teile (solo, Gruppe, Schlachtzug 40, Tankwechsel, Spott, Bedrohung zurücksetzen, mehrere Ziele, Begleiter, schneller Zielwechsel, Grenzen 90/110 %, Mitspieler mit alter Version, geheime Werte, fehlende Bedrohungs-Schnittstelle), Abläufe wie ein Spieler, Standardwerte, 1000 Zufallsfälle mit festem Startwert (in Portionen, je Bild eine), echte aufgezeichnete Daten, ein Regressionstest je Befund seit dem 3. November, alle Spielversionen und beide Sprachen. Der Bericht zeigt je Bereich eine Zeile (OK · FEHLER · SKIP)
- Testroutine: neue Regressionstests T-R4, T-R5b, T-R5c, T-R13 und T-BL1 bis T-BL6

## 2.5.9
- Fehlgeschlagener Spott: Als Grund werden nur bekannte Zauber-Fehlertexte des Spiels übernommen (Abklingzeit, Reichweite, Sichtlinie, Ziel, immun, Ressource, Kontrollverlust). Jede andere Spielmeldung erscheint nur als „anderer Grund“ – Testberichte sind öffentlich, und manche Meldungen enthalten Namen
- Testroutine: T-K2 setzt sein Testfenster auf die aktuelle Lage der Testzentrale, statt es dort zu verankern (es wanderte mit, der Fall schlug im echten Client immer fehl)
- Testroutine: T-G1 prüft den Teil VOLL unabhängig von einer echten Sperre in WoW Forever und von der Einstellung „immer nur Anzeige“ (schlug in Forever fehl)
- T-W1 prüft zusätzlich, dass eine unbekannte Spielmeldung nur als „anderer Grund“ ankommt
- Aufgeräumt in Threat.lua (Kommentar wieder beim Moduswechsel, unbenutzte Variable entfernt)

## 2.5.8
- Testzentrale und Einstellungen weichen jetzt auch sichtbaren Fenstern anderer GoldSentinel-Addons aus (z. B. einer BuffSentinel-Leiste mit Inhalt), nicht nur Blizzard-Fenstern; bis zu vier Versuche, sonst die Stelle mit der wenigsten Überdeckung. Leere Anker zählen weiterhin nicht
- Testroutine: neuer Fall T-K2 (Bereich K, nur im echten Client)

## 2.5.7
- Diagnose-Protokoll (WoW Forever, Modus ANZEIGE): einmal je Kampf, 3 Sekunden nach dem Pull, eine Zeile „LESBAR-PLAKETTEN“: Für alle Plaketten wird festgehalten, ob „du hast die Aggro“ und deine Bedrohungsstufe lesbar sind – nicht nur für dein Ziel – und dasselbe für ein Gruppenmitglied (nur Zahlen, keine Namen). Grundlage für die Aggro-Warnung des Tanks in WoW Forever
- Testprotokoll: Fehlgeschlagene Spotts nennen jetzt den Grund aus der Fehlermeldung des Spiels (z. B. „noch nicht bereit“, „zu weit entfernt“); die Zusammenfassung zeigt die häufigsten Gründe
- Testassistent: Im Modus ANZEIGE werden die Schritte zu Plaketten, HUD und Zurückholen übersprungen („n/a“) statt als fehlgeschlagen gezählt – dort verändert ThreatSentinel absichtlich keine Plaketten
- Sync: „nachgeholt“ zählt nur Nachrichten, die wirklich gesendet wurden (nicht bei ausgeschaltetem Sync oder wenn du nach dem Kampf die Gruppe verlassen hast)
- Testroutine: neue Fälle T-M1, T-G1, T-W1; T-Q5 erweitert

## 2.5.6
- Behoben (wichtig für den Sprachtest des Entwicklers): Nach `/ts testroutine sprache` und /reload lud ThreatSentinel nicht mehr (Lua-Fehler beim Laden, die Entwickler-Prüfung wurde mit Punkt statt Doppelpunkt aufgerufen). Die Prüfung wird jetzt richtig und abgesichert aufgerufen; geht etwas schief, gilt die Spielsprache und das Laden läuft weiter. Wer den Sprachtest mit 2.5.4/2.5.5 gemacht hat: aktualisieren und /reload, sonst ist nichts nötig
- Sync: Ohne Gruppe wird nichts gesendet, auch kein Gruss („Herzschlag“); eigener Zähler „ohne Gruppe“ statt „verworfen“
- Diagnose-Protokoll: Die Zeile „LESBAR“ trennt „Ziel des Mobs lesbar“ von „Halter in der Gruppe“
- Testroutine: neue Fälle T-L1, T-L2; T77, T-SY2, T-P3 angepasst

## 2.5.5
- DD-Ansicht in WoW Forever (Modus ANZEIGE): zeigt wieder die Aggro-Warnung. Das Spiel versteckt die Prozente, lässt aber lesen, ob du die Aggro hast und welche Bedrohungsstufe du gegen dein Ziel hast: „Du hast Aggro!“ (rot, Warnton einmal) und „Über dem Tank - gleich Aggro!“ (orange). Nur lesbare Werte, keine eigenen Schwellwerte auf geschützten Prozenten; sind auch diese geschützt, bleibt die Anzeige neutral wie bisher
- Sync im Kampf (WoW Forever sperrt dort Addon-Nachrichten): Rolle/Version werden jetzt nach dem Kampf einmal gesendet statt verworfen (nur der letzte Stand). Meldungen zu Spott, Widerstand und Kontrolle gelten nur im Augenblick und werden weiter verworfen („Kampf, veraltet“). Diagnose-Protokoll: „nachgeholt N“
- Testroutine: T144 meldet bei offener Testzentrale keinen falschen Alarm mehr; „Simulationen zurückgesetzt“ vergleicht vorher/nachher und nennt den Schalter (oder „OK (… war schon an)“); Hinweiszeile zu Beginn, wenn Testmodus, Verschiebe-Modus oder Testzentrale schon an sind; neue Fälle T-Q1 bis T-Q5; T169 angepasst

## 2.5.4
- Richtigstellung zu 2.5.1/2.5.2: Die Schätzung aus Schaden und Heilung (Stufe 3 der Reihenfolge im Aggrometer) gibt es nur, wenn das Spiel Schaden und Heilung liefert – in WoW Forever derzeit nicht (kein Kampflog). Dort sortiert das Aggrometer nach Aggro-Halter und Bedrohungsstufe, wenn lesbar, sonst „Reihenfolge: Tank zuerst“
- Kopf im Aggrometer: „Reihenfolge: sicher“ nur, wenn wirklich jemand aus der Gruppe die Aggro des Mobs hat oder alle Bedrohungsstufen lesbar sind; sonst „Reihenfolge: Tank zuerst“
- Behoben (WoW Forever): Ein /reload mitten im Kampf konnte den Bedrohungsmodus in diesem Kampf noch auf VOLL schalten; der Kampf wird jetzt zusätzlich direkt beim Spiel nachgefragt
- Diagnose-Protokoll: Die Zeile „LESBAR“ entsteht nur noch im Kampf mit nicht leerer Liste (die leere Liste vor dem Pull wird nicht mehr gemessen)
- Zusammenfassung des Testprotokolls: Ein /reload startet die Auswertung nicht mehr von vorne („META cont=1“ bleibt in derselben Sitzung); eine geänderte Einstellung setzt sie zurück
- Beschädigte SavedVariables werden beim Laden repariert: Werte mit falschem Typ werden durch den Standard ersetzt (z. B. Text statt Zahl); beschädigte Einträge der obersten Ebene werden verworfen
- Sync: ohne Gruppe wird nichts gesendet (im Diagnose-Protokoll als „kein Weg“ gezählt)
- Testroutine: Sprachtest für den Entwickler (`/ts testroutine sprache`, dann /reload und `/ts testroutine f`, T128); neue Fälle T-P1b, T-A6b, T-A8, T139b, T122 (an einer Kopie), T-SY2

## 2.5.3
- Behoben (WoW Forever): Der Bedrohungsmodus springt im Kampf nicht mehr auf VOLL (im Dungeon gesehen: ANZEIGE -> VOLL -> ANZEIGE in einem Kampf). Ein lesbarer Wert im Kampf wird nur gemerkt; ThreatSentinel schaltet erst ausserhalb des Kampfs und erst nach zwei Kämpfen mit lesbaren Werten und ohne Geschütztes auf VOLL. Wurden in einem Kampf geschützte Werte gesehen, bleibt es bis Kampfende bei ANZEIGE
- Testzentrale und Einstellungen öffnen nicht mehr über offenen Blizzard-Fenstern (Charakterfenster, Karte, Händler, Briefkasten …), sondern daneben. Tooltips der Testzentrale erscheinen neben dem Fenster statt über seinen Knöpfen
- Oberflächen-Prüfung: Meldungen nennen jetzt das genaue Element (Pfad, Beschriftung, Lage); leere Ankerrahmen anderer Addons (unsichtbare Behälter) zählen nicht mehr als überdeckte Fenster
- Diagnose-Protokoll: Die Zeile „LESBAR“ nennt auch die geprüfte Einheit und ob der Mob dich angreift (ja/nein/geschützt, ohne Namen); die Gruppenzeile zählt Spieler und Begleiter getrennt; Sync-Zähler (gesendet, empfangen, verworfen mit Grund) alle 10 Minuten – ThreatSentinel synchronisiert nur über Gruppe/Schlachtzug, nie über einen eigenen Kanal
- GoldSentinelTest 2: Fehlerberichte an den Entwickler teilen (nur mit Zustimmung, /gstest)
- Testroutine: neue Fälle T-P1 (kein VOLL im Kampf), T-P3, T-GT1, T-GT2; die Test-Kulisse ersetzt jetzt auch die gespeicherte Erkennung (T153 schlug im echten Client fehl, weil das gespeicherte „secret“ die Kulisse überstimmte)

## 2.5.2
- Gemeinsame Datei `GoldSentinelGame.lua` auf die offizielle Version 3 gebracht (nur Kommentare und Beispiele, Code unverändert)

## 2.5.1
- Aggrometer in WoW Forever (Modus ANZEIGE, geschützte Werte): wieder nach Aggro sortiert – zuoberst, wer die Aggro hat, dann der Nächste usw. ThreatSentinel nimmt die beste verfügbare Stufe: 1) wer die Aggro hat (Ziel des Mobs, sonst „tankt“), wenn lesbar, 2) die Bedrohungsstufe 3/2/1/0, wenn lesbar, 3) eine Schätzung aus Schaden und Heilung dieses Kampfs mit klassischen Faktoren (Krieger-Tank ×1,3, Druide in Bärengestalt ×1,3, Paladin mit Zorn der Gerechtigkeit ×1,6, Schurke ×0,71, Heilung ×0,5 geteilt durch die Gegner), mit „~“ vor dem Namen. Eine kleine zweite Kopfzeile zeigt „Reihenfolge: sicher“, „Reihenfolge: ~ geschätzt“ oder „Reihenfolge: Tank zuerst“ (nichts lesbar, noch keine Schätzung). Die Balken zeigen weiter die echten Werte, nur die Reihenfolge ändert sich. Gedämpft gegen Flackern: höchstens alle 0,5 s, Schätzungen tauschen erst ab 10 % Unterschied. Era/TBC (lesbare Werte) unverändert
- Diagnose-Protokoll: einmal je Kampf eine Zeile „LESBAR Ziel-des-Mobs=ja/nein · Stufe=ja/nein · isTanking=ja/nein · Schätzung=ja/nein“ (was WoW Forever ThreatSentinel lesen lässt; keine Namen)
- Zusammenfassung des Testprotokolls: wird im Hintergrund in kleinen Schritten ausgewertet und beim Öffnen nur noch die neuen Einträge (vorher bis 45 ms auf einmal, T139)
- Testroutine: neue Fälle T-A1 bis T-A7 (Aggro-Halter oben, Bedrohungsstufen, Schätzung mit „~“, Dämpfung, Era/TBC unverändert, geschütztes Ziel des Mobs, Kopfzeile nicht abgeschnitten); T167 an die neue Reihenfolge angepasst

## 2.5.0
- Testroutine: Die letzten 13 übersprungenen Fälle laufen jetzt automatisch – „nicht automatisiert: 0“. Neu: Flächenspott-, Notfall- und Heiler-Reichweite-Hinweise (T66), widerstandener Spott mit Ersatz und Sync (T68), Tank kontrolliert (T69), Hinweis Spott-Taste (T71), Kampflog-Spott in Era/TBC (T72), eigene Zauber: Abklingzeit, Spott, Zerreissen, Siegel (T78), Kontrolle der Gruppe (T79), Widerstand ohne Kampflog in WoW Forever (T80), Spezialisierung und Betrachten (T82), Spott-Knöpfe und Tastenbelegung (T88), Ton- und Farbwahl, Popups (T91), Minimap-Knopf (T92), bildweise Aktualisierung (T138)
- Intern: Zeitgeber nach eigenen Zaubern, Kampflog, Kontrollverlust, Hinweis zur Spott-Taste und Tastenbelegung laufen jetzt auch über `ns.API`; das Hinweisfenster läuft über die zentrale Aktionsfunktion. Im normalen Spiel: unverändert

## 2.4.9
- Neu: Diagnose-Protokoll (übernommen aus der GoldSentinel-Vorlage). ThreatSentinel schreibt mit, was nur im echten Spiel passiert: Fehler (dieselbe Meldung direkt hintereinander wird nur gezählt), langsame Durchläufe (länger als ein Frame), Wechsel des Bedrohungsmodus und der Bedrohungserkennung in WoW Forever, Kampfbeginn. `/ts protokoll` oder „Diagnose-Protokoll zeigen“ in den Einstellungen öffnet es zum Kopieren. Beim Ausloggen / `/reload` liegt es als `GSDIAG1`-Text in den SavedVariables, damit der Uploader es schicken kann (Einstellung „Diagnose-Protokoll automatisch senden“, Standard an). Keine Spieler-, Charakter-, Gilden- oder Realmnamen
- Testroutine: neue Fälle T187 (Einträge, Zähler statt Schleife, Export, keine Namen), T189 (keine Einträge während der Testroutine), T188 (im Client prüfen)

## 2.4.8
- Testroutine: neuer Bereich K „Oberfläche im echten Client“ (`/ts testroutine k`, Knopf K in der Testzentrale), übernommen aus der GoldSentinel-Vorlage (`UICheck.lua`): eigene Tooltips verdecken keine Knöpfe (T180), eigene Fenster überdecken keine Blizzard-Fenster und keine Fenster anderer GoldSentinel-Addons (T181), Fenster liegen ganz im Bildschirm (T182), Knopf-Beschriftungen sind nicht abgeschnitten (T183), angezeigte Spielwerte sind plausibel (T184: Stufe, Klasse, eigener Name ohne Realm, Gruppe vollständig, Bedrohungsmodus, Spott gelernt), keine Fehlerschleife mit derselben Meldung mehr als 10× (T185). Liest nur, verändert nichts; ohne echten Client werden die Fälle übersprungen, nie als OK gezählt
- Alle eigenen Fenster (Einstellungen, Testzentrale, Testassistent, Berichte, Tonauswahl, Verschiebe-Leiste) und Kampfanzeigen (Aggrometer, DD-Ansicht, Schadens-/Heilmeter, HUD, Spott-Knöpfe, Minimap-Knopf) sind für diese Prüfung angemeldet. Kampfanzeigen docken an kein Blizzard-Fenster an und werden darum nur auf Bildschirm, Tooltips und Beschriftungen geprüft

## 2.4.7
- Behoben (WoW Forever): Der Name des eigenen Charakters enthält keinen Realm mehr. Namen vom eigenen Realm werden jetzt genau so geschrieben wie die Absender von Addon-Nachrichten, damit Tank-Sync, Rollen und Besitzer sicher zusammenpassen (Testfall T22)
- Intern: Addon-Nachrichten, CVars und Addon-Daten (`C_ChatInfo`, `C_CVar`, `C_AddOns` und die alten Einzelfunktionen) laufen jetzt auch über `ns.API`; neuer Testfall T106 (diese Funktionen fehlen -> kein Lua-Fehler, Sync weicht sauber aus)
- Testroutine: Die absichtlichen Fehler des Selbsttests werden weiter gezählt, aber nicht mehr als „Fehler im Spiel“ gemeldet

## 2.4.6
- Testroutine (nur Entwickler): neue Test-Kulisse mit Test-Einheiten, Testgruppe und Test-Plaketten. Sie arbeitet nur über `ns.API` und die eigenen Vorschau-Plaketten der Testzentrale und fasst nie Blizzard-Plaketten oder -Funktionen an. Damit laufen 24 bisher übersprungene Fälle automatisch (Siegel und Spott, Tank-Erkennung, Gruppe, Kandidaten der Bedrohungsprüfung, Zustände der Mobs, lose Mobs mit Übernahme und Besitzer, Hinweistext, regelmässiger Durchlauf, Einzelauswertung, Plaketten-Ereignisse, Aggro-Anführer, Plakette finden, Aussehen je Zustand und je Option, Zurücksetzen und Aufblinken, Meldungen, Meldungen anderer Tanks, Sync-Gruss, Reihenfolge im Aggrometer, HUD, Leben, geschützte Bedrohung im ganzen Durchlauf, Tempo mit 10 und 40 Mobs, verbotene Plaketten)
- Testbericht: neue Zeile „nicht automatisiert: N“ für die Fälle, die noch fehlen
- Im normalen Spiel: unverändert

## 2.4.5
- **Wichtig: Die Versionen 2.0.0 bis 2.4.3 luden überhaupt nicht** (Lua-Fehler gleich am Anfang von `Core.lua`, danach lief kein Modul). 2.4.4 hat das behoben – wer noch 2.0.0–2.4.3 hat, bitte unbedingt aktualisieren. Alles, was seit 2.0.0 dazukam (Gruppen-Ansicht, Schadens-/Heilmeter, Skillungsprüfung, WoW-Forever-Erkennung), wirkt erst ab 2.4.4
- Intern: Jede Blizzard-Funktion, die ThreatSentinel braucht, wird einmal in der neuen Datei `API.lua` (`ns.API`) ausgewählt und von dort aufgerufen. Keine Blizzard-Funktion wird ersetzt; die Testroutine prüft geschützte Werte, fehlende Funktionen und die Kampfsperre jetzt gefahrlos über diese Tabelle
- Testroutine: viele bisher übersprungene Fälle laufen jetzt (Abklingzeiten, Reichweite, Auren alter und moderner Weg, Mob-Schlüssel, geschützte Namen, fehlende Bedrohungsfunktionen, Sync-Kampfsperre, „unbekannt“ + geschützte Werte -> ANZEIGE, Reihenfolge im Aggrometer bei ANZEIGE, Plaketten-Auskunft, Sichtbarkeit von Aggrometer und DD-Ansicht, jede Option an/aus); neu „keine neuen Globals“ (T131) und „Fehlerzahl in der Diagnose“ (T161)
- Testroutine: Geht beim Zurücksetzen etwas schief, bricht die Routine immer sauber ab (nichts bleibt angehalten, alle Aktionen laufen wieder normal) und meldet den Fehler
- Bisher still abgefangene Fehler (Protokoll, Plaketten zurücksetzen, Anzeigen verschieben, CVars setzen, Notfall-Kurve) gehen jetzt auch an die Prüfung (`GoldSentinelTest`), ohne den Fehlerzähler im Spiel zu ändern
- Bildschirmfotos des Testprotokolls laufen über die zentrale Aktionsfunktion (während der Testroutine nur mitgeschrieben)
- Die Knöpfe der Testroutine in der Testzentrale sieht nur noch der Entwickler

## 2.4.4
- Behoben: Lua-Fehler beim Laden von `Core.lua` („attempt to call method 'On'“): Zwei Kampf-Ereignisse wurden angemeldet, bevor es die Ereignis-Funktion gab. Sie werden jetzt danach angemeldet; sonst unverändert
- Neue Testroutine für den Entwickler (`/ts testroutine`, `/ts testroutine a`–`j`, `halb`, `letzte`; Knopf „Alles testen“ und je Bereich ein Knopf in der Testzentrale). Ergebnisse und abgefangene Lua-Fehler gehen über die gemeinsame Datei `GoldSentinelTest.lua` an die Prüfung. Die Routine ersetzt keine Blizzard-Funktion, läuft nur ausserhalb des Kampfs, schickt nichts in den Chat oder an die Gruppe und stellt danach alle Einstellungen wieder her
- Intern: Aktionen mit Folgen (Chat, Addon-Nachrichten, CVars, Tastenbelegung, Neuladen, Betrachten, Töne) laufen über eine Stelle, damit die Testroutine sie nur mitschreibt statt ausführt

## 2.4.3
Korrekturen aus der Prüfung (WoW Forever):
- Erster Kampf nach dem Login: Solange noch nicht erkannt ist, ob die Bedrohungswerte lesbar sind, greift ThreatSentinel im Kampf nicht an den Plaketten ein (Modus ANZEIGE bis zum Ergebnis); geschützte Werte führen auch dann sofort zu ANZEIGE; liefert ein Kampf gar keine Daten, gilt AUS nur für diesen Kampf
- Modus ANZEIGE: Aggrometer und DD-Ansicht treffen keine eigenen Entscheidungen mehr – feste Reihenfolge (Tank, dann Gruppe), kein Vorsprung-Text, neutrale Balkenfarbe
- Blizzards Bedrohungsanzeigen auch bei „Immer nur Anzeige“, und sofort, wenn ThreatSentinel eingeschaltet wird (ausserhalb des Kampfs); Hinweis in den Einstellungen, dass es für Plaketten-Farben keine Blizzard-Einstellung gibt
- Testzentrale: Knopf „Client simulieren: Forever“ (Selbsttest mit GoldSentinelGame)

## 2.4.2
Korrekturen aus der Prüfung:
- Der Hinweis „Bedrohungsdaten sind geschützt“ und das Einschalten von Blizzards Bedrohungsanzeigen erscheinen nur noch, wenn ThreatSentinel eingeschaltet ist
- Testzentrale: Die Simulation „lesbar“ übersteuert keine echte Sperre mehr; der Knopf zeigt dann „echt gesperrt“
- Moderne API: Vergleiche von Einheiten (UnitIsUnit) laufen geschützt über eine sichere Prüfung
- Interne Prüfung geschützter Werte überall über GoldSentinelGame

## 2.4.1
- `GoldSentinelGame.lua` auf Version 2 aktualisiert (setzt sich gegen frühe, zurückgenommene Fassungen in anderen GoldSentinel-Addons durch; keine Lua-Fehler, wenn mehrere Addons gleichzeitig geladen sind)

## 2.4.0
- **Gemeinsame Versionserkennung aller GoldSentinel-Addons** (`GoldSentinelGame.lua`, `/gsgame`): WoW Forever und Retail gelten überall als moderne API, Classic Era, TBC, Wrath, Cata und MoP Classic als alte API. ThreatSentinel nutzt sie für die moderne API, die Namen (ohne Realm, geschützte Namen nie verarbeiten) und die Erkennung geschützter Werte; die Diagnose und „Bedrohung prüfen“ zeigen die erkannte Spielversion.
- Kampflog nur noch auf der modernen API gesperrt: Damit laufen **Schadens- und Heilmeter in TBC Anniversary** (bisher fälschlich aus), und widerstandener Spott wird in TBC wieder direkt erkannt.

## 2.2.0
- **WoW Forever: Bedrohungs-Erkennung im Spiel**. ThreatSentinel nimmt nicht mehr an, dass Bedrohungswerte gesperrt sind, sondern prüft es einmal pro Kampf selbst (moderne API) und wählt den passenden Modus:
  - **VOLL** (Werte lesbar, sowie Classic Era und TBC): alles wie bisher
  - **ANZEIGE** (Werte im Kampf geschützt): keine eigene Entscheidung mehr – kein Leuchten oder Ausblenden der Plaketten, keine Töne nach Schwellwerten; Aggrometer und DD-Ansicht zeigen die geschützten Werte als Balken; Blizzards Bedrohungsanzeigen (Prozent am Zielfenster, Bedrohungswarnung) werden ausserhalb des Kampfs eingeschaltet. Hinweis einmal pro Kampf.
  - **AUS** (keine Bedrohungsdaten): Bedrohungsanzeigen ausgeblendet; Tank-Sync, Rollen und Spott-Abklingzeiten bleiben
- Neu: **„Bedrohung prüfen“** (`/ts bedrohung` oder Knopf unter Allgemein) zeigt Modus, Status, Prozent (oder „geschützt“), den zuletzt erkannten Zustand mit Datum und Build sowie abgefangene Fehler
- Neue Einstellung **Bedrohungsmodus**: Automatisch (Standard) oder Immer nur Anzeige
- Testzentrale: Bedrohungszugriff simulierbar (lesbar / geschützt / nicht verfügbar)
- Moderne API: Der Ersatz über das Ziel des Mobs entfällt; im Kampf keine Eingriffe in Blizzards Plaketten, wenn die Werte geschützt sind; geschützte Namen und Zahlen werden nie mehr selbst verarbeitet; leere Aurenlisten im Kampf gelten als „unbekannt“; Tank-Sync sendet im Kampf nicht
- Abgefangene Fehler werden (moderne API) einmal pro Sitzung im Chat gemeldet und in der Diagnose sowie bei „Bedrohung prüfen“ gezählt
- Modus ANZEIGE merkt sich die eigenen Blizzard-Einstellungen und stellt sie im Modus VOLL wieder her (abschaltbar)
- Classic Era und TBC: unverändert

## 2.1.0
- **Skillung der Mitspieler**: ThreatSentinel prüft die Talente aller Spieler in Gruppe und Schlachtzug und leitet die Rolle daraus ab – Schutz-Krieger und Schutz-Paladin = Tank, Wilder-Kampf-Druide in Bärengestalt = Tank, Heilig-/Disziplin-Priester, Heilig-Paladin, Wiederherstellungs-Druide und -Schamane = Heiler, alle anderen = DD. Danach richten sich Plaketten, Warnungen (Frosch / Engelsgesang), Aggrometer und Schadens-/Heilmeter.
  - Eigene Talente werden direkt gelesen (auch für den eigenen Meter: Schatten-Priester bekommt den Schadensmeter, Heilig-Priester den Heilmeter)
  - Andere Spieler werden ausserhalb des Kampfs und in Reichweite nacheinander betrachtet; wer ThreatSentinel hat, meldet seine Rolle selbst
  - Ein zweiter Tank ohne Addon wird so zuverlässig erkannt (keine Fehlalarme für seine Mobs)
- Einstellungen › Gruppe zeigt die **erkannten Rollen** mit Quelle (ThreatSentinel, Talente x/y/z, geschätzt); die Prüfung lässt sich dort abschalten

## 2.0.0
- **ThreatSentinel für die ganze Gruppe**: Jeder mit dem Addon bekommt die Anzeigen seiner Rolle.
  - **Tank**: alles wie bisher
  - **DD**: Aggrometer + neuer **Schadensmeter** (Rangliste der Gruppe, Kampf / Gesamt, DPS)
  - **Heiler**: Aggrometer + neuer **Heilmeter** (Rangliste, HPS, ohne Überheilung)
- **Plaketten für DDs und Heiler**: Mobs beim Tank bleiben normal sichtbar; hervorgehoben wird nur Gefahr: **bald Aggro** (orange, blinkt) und **Aggro bei einem Spieler** (rot, brennt)
- **Warnton**: Der Tank hört Frosch (DD) bzw. Engelsgesang (Heiler). Wer selbst Aggro zieht, hört seinen Ton und sieht „Du hast Aggro – zurück zum Tank!“. Alle anderen bleiben ruhig. Töne unter Einstellungen › Töne.
- Tanks ohne Addon werden erkannt (Bärengestalt / Rechtschaffener Zorn sichtbar, sonst wer die meisten Mobs hält)
- Neuer Reiter **Gruppe** in den Einstellungen; Meter verschieb- und skalierbar (`/ts verschieben`)
- Schadens- und Heilmeter brauchen das Kampflog und gibt es deshalb nur in Classic / TBC, nicht in WoW Forever
- Hinweis: Wer bisher als Nicht-Tank „nur als Tank aktiv“ abgeschaltet hatte, bekommt jetzt die Gruppen-Ansicht (abschaltbar unter Gruppe)

## 1.8.1
- Neue Töne **Engelsgesang** und **Frosch**. Standard jetzt: Heiler hat Aggro = Engelsgesang, DD hat Aggro = Frosch. Hupe, Alarmhupe und alle anderen Töne bleiben wählbar; selbst gewählte Töne bleiben erhalten.

## 1.8.0
- **Viel stärkere Effekte**:
  - **Bald Aggro (orange)**: voll sichtbar, etwas grösser, dicker Rahmen, schnell blinkend, oranges Leuchten und eine Druckwelle beim Wechsel
  - **Aggro bei einem Spieler (rot)**: grössere, hellere Flammen (zwei Schichten), rotes pulsierendes Leuchten, Druckwelle beim Wechsel, Plakette grösser (140 %), dickerer Rahmen
  - Neue Einstellungen unter Plaketten › Effekte: Leuchten und Druckwelle an/aus, Stärke der Effekte (50–200 %)
- **Eigener Ton für den Heiler**: neue **Alarmhupe** (drei steigende Hupstösse) – der DD hat die einfache Hupe. So hört man ohne Hinschauen, wer die Aggro hat.
- **Testbericht in TBC und Classic: nur Sichtprüfung** – geprüft wird ausschliesslich, was man sieht: gehaltene Plaketten, Lebensbalken, bald Aggro (voll sichtbar, orange, blinkt, leuchtet), lose Plaketten (Rahmen, Farbe, Pulsieren, Flammen, Leuchten), Grösse der Plaketten, Raidmarkierung und Zauberbalken, Aufblitzen, HUD, Aggrometer, DD-Ansicht, Meldungen. Auf WoW Forever bleibt der volle Bericht mit allen Funktionsprüfungen.

## 1.7.4
- **Aggro bei einem Spieler**: Die Plakette **brennt** (animierte Flammen rundherum) und der Rahmen ist **rot** – auch bei DDs (bisher orange; orange heisst jetzt „bald Aggro“). Flammen unter Plaketten abschaltbar, Farben wählbar.

## 1.7.3
- Verliert der Tank die Aggro an einen Spieler (DD oder Heiler), ertönt standardmässig eine **Hupe**. Selbst gewählte Töne bleiben erhalten; unter „Töne“ frei änderbar.

## 1.7.2
- **Bald Aggro** (Vorwarnung): Die Plakette ist jetzt voll sichtbar, mit **orangem, schnell blinkendem Rahmen** (abschaltbar unter Plaketten; Farbe wählbar)
- **Töne standardmässig nur bei Aggroverlust** (an DD / Heiler). Aggro zurück, widerstanden, Notfall und die Warnung der DD-Ansicht sind standardmässig stumm und lassen sich unter Töne wieder einschalten. Selbst geänderte Töne bleiben, wie sie sind.

## 1.7.1
- Test- und Entwicklerfunktionen (Testzentrale, Testassistent, Testprotokoll `/ts log`, Ini-Prüfung) sind nur noch für den Entwickler sichtbar (gemeinsame Erkennung `GoldSentinelDev.lua` aller GoldSentinel-Addons, `/gsdev` zeigt den Status). Für alle anderen bleibt das Addon aufgeräumt.

## 1.7.0
- **Töne frei wählbar**: Jeder Ton (Aggroverlust an DD / Heiler, Vorwarnung, widerstanden, Aggro zurück, Notfall, DD-Ansicht) hat ein Auswahlfenster mit drei Gruppen: eigene ThreatSentinel-Töne, **Geräusche** (Hupe, Doppelhupe, Nebelhorn, Sirene, Alarmklingel, Glocke, Gong, Pfiff, Trommel, Doppelpiep, Ping) und **WoW-Töne** (Schlachtzugswarnung, Bereitschaftscheck, Alarm, Boss-Flüstern, Flüstern, Kartensignal …). Linksklick wählt und spielt ab, Rechtsklick spielt nur ab.
- **Eigener Ton**: eine WoW-Sound-ID (Zahl, z. B. von wowhead.com/sounds) oder eine eigene .ogg-/.mp3-Datei im Ordner `Interface\AddOns\ThreatSentinel_Sounds` (bleibt bei Updates erhalten; nach dem Hineinlegen das Spiel einmal neu starten)
- Neu: eigener Ton für die **Vorwarnung** (gelber Rand, Standard aus) und für die Warnung der DD-Ansicht (bisher derselbe Ton wie „Aggroverlust an DD“)
- **Ini-Prüfung**: Betrittst du als Tank einen Dungeon, läuft das Testprotokoll automatisch mit. Verlässt du die Instanz, erscheint der Bericht (Aggroverluste und Rückholungen, Plaketten, Töne, Meldungen, HUD, Aggrometer, Spott, Fehler, dazu Kämpfe in Tankhaltung und an wen die Aggro verloren ging). Sterben und Zurücklaufen als Geist oder /reload unterbrechen die Prüfung nicht. Hast du nicht getankt, gibt es keinen Bericht. Einstellungen unter „Allgemein“ (auch im Schlachtzug, Bilder, letzten Bericht zeigen).
- **Aggrometer und DD-Ansicht** (eigene Aggro) frei verschiebbar und in Grösse und Breite einstellbar – ebenso das kleine HUD. Neuer Knopf „Fenster verschieben / Grösse ändern“ (Anzeige-Reiter) oder `/ts verschieben`: Fenster ziehen, Mausrad ändert die Grösse, Rechtsklick setzt sie auf 100 %. Die Fenster bleiben dabei an ihrer Stelle.
- Testbericht: Die DD-Ansicht gilt als Tank nicht mehr als Fehler (sie ist dann absichtlich ausgeblendet); Spott über die Aktionsleiste zählt auch ohne Spott-Taste; nach /reload zählt die Auswertung die ganze Sitzung

## 1.6.1
- Testbericht: „Lose Plakette hervorgehoben“ meldet in Classic Era keinen falschen Fehler mehr (der Rahmen war da; die Prüfung verlangte zusätzlich einen Sichtbarkeitswert, den Classic anders meldet). Das Protokoll hält jetzt `shown` und `visible` getrennt fest.
- Testassistent: Der HUD-Schritt wird automatisch geprüft (Testmobs sterben oft, bevor man die Frage beantworten kann)
- Klarere Beschriftung der Zeile „Aggroverlust“ im Bericht

## 1.6.0
- Neues **Testprotokoll** für Tests ohne Zuschauer: `/ts log an | aus | leeren | status | bericht | bilder` oder Knopf in der Testzentrale. Schreibt maschinenlesbare Zeilen in die SavedVariables (`ThreatSentinelDB.testlog`): Sitzungsangaben (Client, Klasse, Gestalt, Pet, alle Einstellungen) und Ereignisse – Kampf, Mobs, Zustandswechsel, Bedrohung, der **tatsächliche** Zustand der Plaketten (Deckkraft, Grösse, Rahmen, Pulsieren, Aufblitzen, Hinweis, Raidmarkierung, Zauberbalken), Meldungen, Töne, HUD, Aggrometer, DD-Ansicht, Spott, Widerstand, Kontrolle, Sync, Tasten-Hinweis, Fehler, geblockte Aktionen und die Schritte des Testassistenten. Ringpuffer mit 5000 Einträgen, nur Änderungen, geschützte Werte stehen als SECRET. Standard aus; ausgeschaltet tut es nichts.
- **Testbericht im Spiel**: Wird das Testprotokoll ausgeschaltet (oder ist der Testassistent fertig), wertet ThreatSentinel das Protokoll selbst aus und zeigt einen Bericht: Aggroverluste und Rückholungen (mit Durchschnittszeit), Aussehen und Farbe gehaltener / loser Plaketten, Aufblitzen, HUD, Aggrometer, DD-Ansicht, Meldungen, Töne, Spott-Taste, Fehler. `/ts log bericht` oder „Auswertung“ in der Testzentrale zeigt ihn erneut; er steht auch im kopierbaren Bericht.
- Der Testassistent schaltet das Testprotokoll am Anfang ein und am Ende aus
- Automatische Bilder, solange das Protokoll läuft (loser Mob, Aggro zurück, jede neue Meldungsart, erstes Aggrometer im Kampf), höchstens 1 alle 2 s (Testmobs leben oft nur ~10 s) und 25 pro Sitzung; `/ts log bilder` schaltet sie um

## 1.5.0
- Neuer **Testassistent** (`/ts guide` oder Knopf in der Testzentrale): führt dich im Spiel Schritt für Schritt durch alle Funktionen, erkennt die meisten Schritte selbst, fragt mit Ja/Nein nach, was nur du sehen kannst, behält den Fortschritt über /reload hinweg und schreibt die Ergebnisse in den Bericht
- Live-Test-Option „Pet ist der Tank“ (Jäger / Hexer): Dein Pet tankt, du bist der DD, der Aggro zieht; die Spott-Taste lässt das Pet Knurren / Qual wirken
- Classic Era: Interface-Nummern 11509 / 11510 ergänzt

## 1.4.5
- Eingabefelder der Regler markieren beim Anklicken ihren Inhalt – Tippen ersetzt den Wert
- Testmeldungen bekommen während Tests einen dunklen Hintergrund und sind auf der Testzentrale lesbar
- Der Bericht nennt die aktive Gestalt / Haltung beim Namen statt nur als Nummer
- Die Einstellung „… reicht“ ist je Klasse beschriftet (Krieger: Zerreissen, sonst: Bedrohung)

## 1.4.4
- Retail: Ein Wächter-Druide gilt nur in Bärengestalt als Tank (nicht in Katzen-, Reise- oder Menschengestalt)
- Beim Belegen der Spott-Taste fragt das Addon nach, bevor es eine bestehende Belegung ersetzt
- Optionen anderer Klassen werden ausgeblendet (z. B. Rüstung-zerreissen-Stapel nur beim Krieger)
- Regler haben -/+-Knöpfe und ein Eingabefeld für exakte Werte
- Testzentrale: Meldungen erscheinen vor dem Fenster; neuer Knopf „Alle Meldungen nacheinander“; jede Zeile im „WoW-Forever-Schutz“ erklärt per Maus, wie man sie prüft; der Bericht enthält jetzt Datum, Spezialisierung, Gestalt, Umgebung (offene Welt / Dungeon / Raid) und Gruppe
- Klarere Wortwahl: Im Live-Test zählen Pets und NPC-Begleiter als DD

## 1.4.3
- Kleines HUD und Aggrometer stehen standardmässig am rechten Bildschirmrand statt neben deiner Figur und überdecken keine Namensplaketten mehr. Selbst verschobene Fenster bleiben, wo sie sind.

## 1.4.2
- Behoben: In Retail (und WoW Forever) erschien bei jedem Einloggen „ThreatSentinel wurde geblockt“. Das Kampflog wird in Clients mit geschützten Werten nicht mehr angemeldet; widerstandener Spott wird dort über die Bedrohung erkannt.
- Geblockte Aktionen werden mitgezählt und im Bericht der Testzentrale aufgeführt
- Demo: Vorschau-Mobs erscheinen immer im HUD (auch mit echten Plaketten in der Nähe); kein Flächenspott-Hinweis bei Klassen ohne Flächenspott
- Testmeldungen („Beispiel zeigen“) erscheinen jetzt vor dem Einstellungsfenster
- Aggrometer: Titel und Vorsprung laufen nicht mehr ineinander
- Der Wechsel zwischen Demo und Live-Test wird jetzt auf dem Bildschirm angezeigt

## 1.4.1
- Lädt jetzt auch in Retail (Midnight) als Testumgebung: Retail hat die Addon-Sperren, die WoW Forever übernimmt, schon heute. Tank-Erkennung dort über die Tank-Spezialisierung; Spott für Todesritter, Dämonenjäger, Mönch und Paladin (Hand der Abrechnung) ergänzt.

## 1.4.0
- Vorbereitet für WoW Forever: Das Spiel kann im Kampf Werte schützen („Secrets“). ThreatSentinel rechnet nie mit geschützten Werten, sondern schaltet auf einen Ersatzweg um, statt Lua-Fehler zu werfen:
  - Aggro: Bedrohungsstatus statt Prozente; Aggrometer und DD-Ansicht lassen die Werte vom Spiel anzeigen
  - Abklingzeiten: vom Addon ab dem eigenen Wirken gemessen (lernt die echte Dauer)
  - Spott widerstanden ohne Kampflog: Prüfung über die Bedrohung direkt nach dem Spott
  - Siegel der Wut, Rechtschaffener Zorn, Rüstung-zerreissen-Stapel und kontrollierte Mobs: aus den eigenen bzw. den Zaubern der Gruppe mitgezählt
  - Mob-Zuordnung ohne GUID: über die Plakette; Tank-Sync: andere Tanks an ihrem Ziel erkannt
  - Notfall-Hinweis: wenn möglich über die Lebensanzeige des Spiels
- Fehler in einem Teil halten nicht mehr das ganze Addon an
- Testzentrale: neue Spalte „WoW-Forever-Schutz“ (grün / gelb / rot je Funktion), „Forever-Sperren simulieren“ zum Ausprobieren aller Ersatzwege auf anderen Clients und „Bericht kopieren“

## 1.3.0
- Gehaltene Plaketten standardmässig mit 35 % Deckkraft und 80 % Grösse (einstellbar). Raidmarkierungen und Zauberbalken bleiben immer voll sichtbar.
- „Spott widerstanden“ nennt jetzt den bereiten Ersatz, z. B. „Spott widerstanden » Spöttischer Schlag!“ (Krieger: Spöttischer Schlag, danach Herausforderungsruf; Druide: Herausforderndes Gebrüll)
- Einmaliger Hinweis beim ersten Betreten einer Instanz, wenn die Spott-Taste noch nicht belegt ist
- Meldung in der Mitte: kleiner, Grösse und Höhe einstellbar, nach Wichtigkeit geordnet (eine wichtige Meldung wird nicht mehr von einer unwichtigeren verdrängt). „Aggro zurück“ standardmässig nur als Aufblitzen der Plakette.
- Neue eigene, kurze Töne – nicht mehr verwechselbar mit DBM/BigWigs oder dem Bereitschaftscheck
- Chat-Meldungen gehen standardmässig nur noch an die anderen Tanks (per Sync). Neu: Gruppe/Raid nur bei Bossen.
- Aggrometer: 100 % heisst jetzt immer „zieht jetzt die Aggro“ (110-%-Nahkampf- / 130-%-Fernkampf-Regel eingerechnet); „Gleich weg!“ statt „Vorsprung 0 %“
- Raidmarkierungen: Totenkopf vor Kreuz in der Lose-Liste, mit Symbol
- Voreinstellungen: Dezent, Standard, Laut
- Tank-Sync: kurzes Kürzel (z. B. „G“ für Grimbar) statt „übernommen von Grimbar“

## 1.2.3
- Paladin-Spott überarbeitet (Erkennung über Spell-IDs statt Namen):
  - TBC: Rechtschaffene Verteidigung wird auf den Mitspieler gewirkt, den der Mob angreift (Mob unter der Maus, sonst Ziel deines Ziels)
  - WoW Forever: Richturteil zählt nur mit aktivem Siegel der Wut als Spott, sonst zeigt die Plakette „Siegel der Wut fehlt“
  - Hand der Abrechnung entfernt (gibt es erst ab Wotlk)
- Diagnose zeigt die Spott-Art des Paladins und ob das Siegel der Wut aktiv ist

## 1.2.2
- Behoben: Das Addon lud in TBC Classic Anniversary 2.5.6 nicht (ein unbekanntes Ereignis brach das Laden ab – /ts und der Minimap-Knopf fehlten). Unbekannte Ereignisse werden jetzt übersprungen.
- Interface 20506 (TBC Classic Anniversary 2.5.6) ergänzt – das Addon gilt nicht mehr als veraltet
- Der Pfeil in „» Name (Rolle)“ wird jetzt richtig angezeigt (das alte Zeichen fehlte in der WoW-Schrift)
- Testzentrale: Vorschau-Plaketten in zwei Reihen, sie überlappen sich nicht mehr
- Testmeldungen bleiben stehen, wenn die Demo beendet wird

## 1.2.1
- Neuer Knopf **Unterstützen** (PayPal) in der Titelleiste des Einstellungsfensters und „Addon unterstützen“ auf der Seite Allgemein. Auch mit `/ts spenden`. Öffnet sich nie von selbst.

## 1.2.0
- Neue **Testzentrale** (Rechtsklick auf den Minimap-Knopf oder `/ts test`): Demo mit Vorschau-Plaketten, Live-Test solo, jede Meldung einzeln, Tank-Sync-Simulation und Diagnose
- Läuft auf Classic Era / Anniversary und TBC Anniversary sowie WoW Forever

## 1.1.0
- Erste Version: lose Mobs leuchten, gehaltene werden ausgeblendet, Spott auf Mauszeiger, Aggrometer, Tank-Sync
