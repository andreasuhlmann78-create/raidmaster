-- ============================================================
-- AH Analyzer Pro heißt jetzt AHSentinel.
-- Dieser Ordner lädt nur noch die alten Daten (AHAnalyzerProDB), damit AHSentinel sie beim
-- ersten Start übernehmen kann. Danach kann der Ordner "AHAnalyzerPro" gelöscht werden.
-- ============================================================
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function()
    local loaded = C_AddOns and C_AddOns.IsAddOnLoaded and C_AddOns.IsAddOnLoaded("AHSentinel")
        or (IsAddOnLoaded and IsAddOnLoaded("AHSentinel"))
    if not loaded then
        local de = (GetLocale and GetLocale()) == "deDE"
        print("|cff00d1d1[AH Analyzer Pro]|r " .. (de
            and "Das Addon heißt jetzt |cffffd100AHSentinel|r. Bitte den Ordner 'AHSentinel' installieren und aktivieren - deine Daten werden beim ersten Start übernommen."
            or "This addon is now called |cffffd100AHSentinel|r. Please install and enable the 'AHSentinel' folder - your data is taken over on first start."))
    end
end)
