-- ============================================================
-- AHSentinel 4.0 - Watchlist (Logik)
-- Beobachtete Items mit Kauf- und Verkaufs-Alarm
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local W = {}
A.Watchlist = W

local function DB()
    return A.db and A.db.watchlist or {}
end

-- Item hinzufügen oder aktualisieren.
-- input: Item-ID oder (Teil-)Name eines Items aus den Scan-Daten
-- buyBelow / sellAbove: Kupfer oder nil
function W:Add(input, buyBelow, sellAbove)
    if not A.db then return false, L["Datenbank nicht bereit."] end
    if not input or input == "" then return false, L["Bitte einen Item-Namen oder eine Item-ID eingeben."] end

    local itemID, matches = A:FindItemByName(input)
    if not itemID then
        if matches and matches > 1 then
            return false, "'" .. input .. L["' passt auf "] .. matches .. L[" Items. Bitte genauer eingeben."]
        end
        return false, "'" .. input .. L["' kenne ich (noch) nicht. Erst scannen, Item-ID eingeben oder das Item per Shift-Klick einfügen."]
    end

    local list = DB()
    local existing = list[itemID]
    list[itemID] = {
        name = A:GetItemName(itemID),
        buyBelow = buyBelow,
        sellAbove = sellAbove,
        added = existing and existing.added or time(),
    }
    A:Fire("WATCHLIST_CHANGED")
    return true, (existing and L["Aktualisiert: "] or L["Hinzugefügt: "]) .. list[itemID].name
end

-- Nur die Kaufgrenze setzen, eine vorhandene Verkaufsgrenze bleibt erhalten (für den Sniper)
function W:SetBuyBelow(input, buyBelow)
    local itemID = A:FindItemByName(input)
    local existing = itemID and DB()[itemID]
    return self:Add(input, buyBelow, existing and existing.sellAbove or nil)
end

function W:Remove(itemID)
    local list = DB()
    if list[itemID] then
        local name = list[itemID].name
        list[itemID] = nil
        A:Fire("WATCHLIST_CHANGED")
        return true, L["Entfernt: "] .. tostring(name)
    end
    return false, L["Nicht in der Watchlist."]
end

function W:Contains(itemID)
    return DB()[itemID] ~= nil
end

function W:Count()
    return A:CountTable(DB())
end

-- Status eines Eintrags: "buy", "sell" oder nil
function W:GetStatus(itemID)
    local w = DB()[itemID]
    if not w then return nil end
    local price = A:GetCurrent(itemID)
    if not price then return nil end
    if w.buyBelow and price <= w.buyBelow then return "buy" end
    if w.sellAbove and price >= w.sellAbove then return "sell" end
    return nil
end

-- Liste für die Tabelle
function W:GetAll()
    local out = {}
    for itemID, w in pairs(DB()) do
        local price = A:GetCurrent(itemID)
        local week = A:GetStats(itemID, 7 * 86400)
        table.insert(out, {
            itemID = itemID,
            name = A:GetItemName(itemID),
            price = price,
            avg7 = week and week.avg or nil,
            day = A:GetTrend(itemID, 86400),
            buyBelow = w.buyBelow,
            sellAbove = w.sellAbove,
            status = self:GetStatus(itemID),
        })
    end
    table.sort(out, function(a, b) return a.name < b.name end)
    return out
end

-- Anzahl aktiver Alarme
function W:CountAlerts()
    local n = 0
    for itemID in pairs(DB()) do
        if self:GetStatus(itemID) then n = n + 1 end
    end
    return n
end

-- Nach jedem Scan: Alarme im Chat melden
function W:CheckAlerts(announce)
    local hits = {}
    for itemID, w in pairs(DB()) do
        local status = self:GetStatus(itemID)
        if status then
            table.insert(hits, { itemID = itemID, name = A:GetItemName(itemID), status = status, price = A:GetCurrent(itemID), w = w })
        end
    end
    if announce and #hits > 0 then
        for _, h in ipairs(hits) do
            if h.status == "buy" then
                A:Print(L["|cff33dd55KAUFEN:|r "] .. h.name .. L[" für "] .. A:FormatMoney(h.price) .. L[" (Grenze "] .. A:FormatMoney(h.w.buyBelow) .. ")")
            else
                A:Print(L["|cffffaa33VERKAUFEN:|r "] .. h.name .. L[" steht bei "] .. A:FormatMoney(h.price) .. L[" (Ziel "] .. A:FormatMoney(h.w.sellAbove) .. ")")
            end
        end
        if A.db.settings.alertSound and PlaySound then
            pcall(PlaySound, 8959)
        end
    end
    return hits
end
