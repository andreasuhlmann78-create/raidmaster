-- ============================================================
-- AHSentinel 5.7 - Einkaufslisten (Logik)
--
-- Benannte Listen mit Items und Mengen (z.B. "Raid-Tränke").
--   * Preise prüfen: aktuelle Angebote aller Items der Liste laden
--   * Als Sniper-Ziele: für jedes Item, das noch fehlt, ein Sniper-Ziel
--     mit Max-Preis = Marktwert x Toleranz anlegen - gekauft wird wie
--     gewohnt per Mausrad / eigener Taste
-- Was schon in den Taschen ist, wird von der Menge abgezogen.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local Li = {}
A.Lists = Li

Li.TOLERANCES = { 100, 110, 125, 150 }
local MAX_NAME = 40

local function DB()
    return A.db and A.db.lists
end

local function Trim(s)
    return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

function Li:GetNames()
    local out = {}
    for name in pairs(DB().items) do table.insert(out, name) end
    table.sort(out, function(a, b) return string.lower(a) < string.lower(b) end)
    return out
end

function Li:Exists(name)
    return DB().items[name] ~= nil
end

function Li:Create(name)
    name = Trim(name)
    if name == "" then return false, L["Bitte einen Namen für die Liste eingeben."] end
    if string.len(name) > MAX_NAME then return false, L["Name zu lang (max. 40 Zeichen)."] end
    if self:Exists(name) then return false, L["Eine Liste mit diesem Namen gibt es schon."] end
    DB().items[name] = { created = time(), entries = {} }
    A:Fire("LISTS_CHANGED")
    return true, L["Liste angelegt: "] .. name, name
end

function Li:Delete(name)
    if not self:Exists(name) then return false, L["Liste nicht gefunden."] end
    DB().items[name] = nil
    A:Fire("LISTS_CHANGED")
    return true, L["Liste gelöscht: "] .. name
end

function Li:Rename(old, new)
    new = Trim(new)
    if not self:Exists(old) then return false, L["Liste nicht gefunden."] end
    if new == "" then return false, L["Bitte einen Namen für die Liste eingeben."] end
    if string.len(new) > MAX_NAME then return false, L["Name zu lang (max. 40 Zeichen)."] end
    if new ~= old and self:Exists(new) then return false, L["Eine Liste mit diesem Namen gibt es schon."] end
    if new == old then return true, L["Liste umbenannt: "] .. new, new end
    local db = DB()
    db.items[new] = db.items[old]
    db.items[old] = nil
    A:Fire("LISTS_CHANGED")
    return true, L["Liste umbenannt: "] .. new, new
end

-- Item hinzufügen (Name in jeder Sprache, ID oder Link). Menge wird addiert.
function Li:AddItem(name, input, qty)
    local list = DB().items[name]
    if not list then return false, L["Liste nicht gefunden."] end
    local itemID = tonumber(input)
    if not itemID or itemID <= 0 or itemID ~= math.floor(itemID) then itemID = A:FindItemByName(input) end
    if not itemID then return false, L["Item nicht gefunden. Name, Item-ID oder Shift-Klick auf ein Item."] end
    qty = math.floor(tonumber(qty) or 1)
    if qty < 1 then qty = 1 end
    local e = list.entries[itemID]
    if e then e.qty = e.qty + qty else list.entries[itemID] = { qty = qty, added = time() } end
    A:Fire("LISTS_CHANGED")
    return true, string.format(L["%dx %s auf die Liste '%s'"], qty, A:GetItemName(itemID), name), itemID
end

function Li:SetQty(name, itemID, qty)
    local list = DB().items[name]
    local e = list and list.entries[itemID]
    if not e then return false end
    qty = math.floor(tonumber(qty) or 0)
    if qty < 1 then return self:RemoveItem(name, itemID) end
    e.qty = qty
    A:Fire("LISTS_CHANGED")
    return true
end

function Li:RemoveItem(name, itemID)
    local list = DB().items[name]
    if not (list and list.entries[itemID]) then return false, L["Item nicht auf der Liste."] end
    list.entries[itemID] = nil
    A:Fire("LISTS_CHANGED")
    return true, L["Entfernt: "] .. A:GetItemName(itemID)
end

function Li:Count(name)
    local n = 0
    local list = DB().items[name]
    if list then for _ in pairs(list.entries) do n = n + 1 end end
    return n
end

-- Inhalt mit Preisen: Menge, in den Taschen, noch nötig, günstigstes Angebot, Marktwert, Kosten
function Li:GetItems(name)
    local list = DB().items[name]
    local out = {}
    if not list then return out end
    local Se = A.Seller
    for itemID, e in pairs(list.entries) do
        local have = Se and Se:CountInBags(itemID) or 0
        local need = math.max(0, e.qty - have)
        local pr = Se and Se:GetPriceInfo(itemID)
        local lowest, available = nil, 0
        if pr then
            lowest = pr.lowestOther
            for _, l in ipairs(pr.listings) do if not l.own then available = available + l.qty end end
        end
        local market = A:GetMarketValue(itemID)
        local unit = lowest or market
        local buy = A:GetVendorBuyPrice(itemID)
        local atVendor = buy ~= nil and (not unit or buy < unit)
        if atVendor then unit = buy end
        table.insert(out, {
            itemID = itemID, name = A:GetItemName(itemID), qty = e.qty, have = have, need = need,
            lowest = lowest, available = pr and available or nil, market = market,
            pct = lowest and A:GetMarketPercent(itemID, lowest) or nil,
            cost = unit and (unit * need) or nil, atVendor = atVendor, vendorBuy = buy,
        })
    end
    return out
end

function Li:TotalCost(name)
    local total, unknown = 0, 0
    for _, it in ipairs(self:GetItems(name)) do
        if it.need > 0 then
            if it.cost then total = total + it.cost else unknown = unknown + 1 end
        end
    end
    return total, unknown
end

-- Preise aller Items der Liste prüfen (über die Preisprüfung von "Verkaufen")
function Li:CheckPrices(name)
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    local n = 0
    for _, it in ipairs(self:GetItems(name)) do
        A.Seller:CheckPrice(it.itemID)
        n = n + 1
    end
    if n == 0 then return false, L["Die Liste ist leer."] end
    return true, string.format(L["Prüfe %d Items ..."], n)
end

function Li:Tolerance()
    return DB().tolerance or 100
end

function Li:CycleTolerance()
    local cur, i = self:Tolerance(), 1
    for k, v in ipairs(self.TOLERANCES) do if v == cur then i = k end end
    DB().tolerance = self.TOLERANCES[(i % #self.TOLERANCES) + 1]
    A:Fire("LISTS_CHANGED")
    return DB().tolerance
end

-- Für jedes fehlende Item ein Sniper-Ziel anlegen (Max-Preis = Marktwert x Toleranz)
function Li:ToSniper(name)
    if not self:Exists(name) then return false, L["Liste nicht gefunden."] end
    local tol = self:Tolerance()
    local made, skipped, done, atVendor = 0, {}, 0, {}
    for _, it in ipairs(self:GetItems(name)) do
        if it.need <= 0 then
            done = done + 1
        elseif it.atVendor then
            table.insert(atVendor, it.name)
        else
            local ref = it.market or it.lowest
            if not ref then
                table.insert(skipped, it.name)
            else
                local maxPrice = math.max(1, math.floor(ref * tol / 100))
                local ok = A.Sniper:SetTarget(tostring(it.itemID), maxPrice, it.need, maxPrice * it.need)
                if ok then made = made + 1 else table.insert(skipped, it.name) end
            end
        end
    end
    local msg = string.format(L["%d Sniper-Ziele angelegt (Max-Preis = %d %% vom Marktwert)."], made, tol)
    if done > 0 then msg = msg .. " " .. string.format(L["%d schon in den Taschen."], done) end
    if #skipped > 0 then msg = msg .. " " .. L["Ohne Preisdaten übersprungen: "] .. table.concat(skipped, ", ") end
    if #atVendor > 0 then msg = msg .. " " .. L["Beim Händler billiger: "] .. table.concat(atVendor, ", ") end
    return made > 0, msg
end
