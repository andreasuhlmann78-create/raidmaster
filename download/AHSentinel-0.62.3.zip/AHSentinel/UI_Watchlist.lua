-- ============================================================
-- AHSentinel 4.0 - Tab "Watchlist"
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C

local function BuildWatchlist(parent)
    local p = CreateFrame("Frame", nil, parent)

    local head = UI:TabTitle(p, L["Watchlist"], "watchlist")
    local sub = UI:Label(p, L["Beobachte Items und lass dich nach jedem Scan benachrichtigen, wenn eine Preisgrenze erreicht ist. Preise in Gold, Silber und Kupfer."], "GameFontDisableSmall", C.textDim)
    sub:SetPoint("TOPLEFT", head, "BOTTOMLEFT", 0, -4)

    -- Eingabezeile
    p.item = UI:EditBox(p, 230, 24, L["Item-Name (jede Sprache) oder ID"])
    UI:AttachItemSearch(p.item, { onPick = function() p.buy:SetFocus() end })
    p.item:SetPoint("TOPLEFT", 0, -46)
    -- Preisgrenzen in Gold / Silber / Kupfer
    local buyLabel = UI:Label(p, L["Kaufen <"], "GameFontHighlightSmall", C.textDim)
    buyLabel:SetPoint("LEFT", p.item, "RIGHT", 12, 0)
    p.buy = UI:MoneyInput(p)
    p.buy:SetPoint("LEFT", buyLabel, "RIGHT", 6, 0)
    p.buy.tooltip = L["Kaufen unter (Gold)"]
    local sellLabel = UI:Label(p, L["Verkaufen >"], "GameFontHighlightSmall", C.textDim)
    sellLabel:SetPoint("LEFT", p.buy, "RIGHT", 12, 0)
    p.sell = UI:MoneyInput(p)
    p.sell:SetPoint("LEFT", sellLabel, "RIGHT", 6, 0)

    local function clearInputs()
        p.item:SetText("")
        p.item:ClearFocus()
        p.item:UpdatePlaceholder()
        p.buy:Clear()
        p.sell:Clear()
    end

    local function submit()
        local ok, msg = A.Watchlist:Add(UI:GetItemInput(p.item), p.buy:GetCopper(), p.sell:GetCopper())
        p.message:SetText(msg)
        p.message:SetTextColor(unpack(ok and C.green or C.red))
        if ok then clearInputs() end
    end

    local add = UI:Button(p, L["Speichern"], 100, 24, submit, "primary")
    add:SetPoint("LEFT", p.sell, "RIGHT", 8, 0)
    add.tooltip = L["Fügt das Item hinzu oder ändert die Grenzen eines vorhandenen Eintrags."]
    local reset = UI:Button(p, L["Leeren"], 70, 24, clearInputs)
    reset:SetPoint("LEFT", add, "RIGHT", 6, 0)

    p.item:SetScript("OnEnterPressed", submit)
    p.buy:SetOnEnter(submit)
    p.sell:SetOnEnter(submit)
    UI:ChainEdits({ p.item, p.buy.boxes[1], p.buy.boxes[2], p.buy.boxes[3], p.sell.boxes[1], p.sell.boxes[2], p.sell.boxes[3] })

    p.message = UI:Label(p, "", "GameFontHighlightSmall", C.textDim)
    p.message:SetPoint("TOPLEFT", p.item, "BOTTOMLEFT", 0, -8)

    local columns = {
        { key = "name", title = L["Item"], width = 230 },
        { key = "price", title = L["Aktuell"], width = 120, align = "RIGHT" },
        { key = "avg7", title = L["Ø 7 Tage"], width = 120, align = "RIGHT" },
        { key = "day", title = L["24 Std."], width = 75, align = "RIGHT" },
        { key = "buyBelow", title = L["Kaufen <"], width = 110, align = "RIGHT" },
        { key = "sellAbove", title = L["Verkaufen >"], width = 110, align = "RIGHT" },
        { key = "status", title = L["Status"], width = 85 },
    }

    p.table = UI:Table(p, {
        columns = columns,
        rows = 15,
        rowHeight = 22,
        sortKey = "name",
        cell = function(item, key)
            if key == "name" then return UI.ItemName(item) end
            if key == "price" or key == "avg7" or key == "buyBelow" or key == "sellAbove" then
                return A:FormatMoney(item[key])
            end
            if key == "day" then return A:FormatPercent(item.day) end
            if key == "status" then
                if item.status == "buy" then return L["|cff33dd55KAUFEN|r"] end
                if item.status == "sell" then return L["|cffffaa33VERKAUFEN|r"] end
                if not item.price then return L["|cff666666keine Daten|r"] end
                return L["|cffaaaaaabeobachten|r"]
            end
        end,
        sortValue = function(item, key)
            if key == "name" then return string.lower(UI.ItemName(item)) end
            if key == "status" then return item.status or "z" end
            return item[key]
        end,
        onClick = function(item)
            -- Werte zum Bearbeiten in die Eingabefelder übernehmen
            p.item:SetText(tostring(item.itemID))
            p.buy:SetCopper(item.buyBelow)
            p.sell:SetCopper(item.sellAbove)
            p.item:UpdatePlaceholder()
            p.message:SetText(L["Bearbeiten: "] .. item.name .. L[" - Werte ändern und Speichern klicken."])
            p.message:SetTextColor(unpack(C.textDim))
        end,
        action = {
            text = "X", width = 28,
            tooltip = L["Aus der Watchlist entfernen"],
            onClick = function(item)
                local _, msg = A.Watchlist:Remove(item.itemID)
                p.message:SetText(msg)
                p.message:SetTextColor(unpack(C.textDim))
            end,
        },
        emptyText = L["Die Watchlist ist leer.\nOben ein Item eingeben oder im Tab 'Markt' auf + klicken."],
    })
    p.table:Fill(0, -100, 0, 34)        -- darunter der Knopf "Preisverlauf"

    local chartBtn = UI:Button(p, L["Preisverlauf des gewählten Items"], 220, 22, function()
        if p.table.selectedID then UI:OpenChart(p.table.selectedID) end
    end)
    chartBtn:SetPoint("TOPLEFT", p.table, "BOTTOMLEFT", 0, -8)

    function p:Refresh()
        self.table:SetData(A.Watchlist:GetAll(), true)
    end

    return p
end

UI:RegisterTab("watchlist", "Watchlist", 3, BuildWatchlist)
