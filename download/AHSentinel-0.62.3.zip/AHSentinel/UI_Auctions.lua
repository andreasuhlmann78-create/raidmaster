-- ============================================================
-- AHSentinel 5.4 - Tab "Auktionen" (deine eigenen Auktionen)
--   * Status je Auktion: günstigstes / gleich / unterboten / verkauft
--   * "Unterbietung prüfen": aktuelle Preise aller deiner Items laden
--   * Abbrechen per Klick (X oder "Nächste unterbotene abbrechen")
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C

local STATUS_COLOR = {
    ["günstigstes"] = "33dd55", ["gleich"] = "ffcc33", ["unterboten"] = "ff5544",
    ["verkauft"] = "00d1d1", ["?"] = "888888",
}
local STATUS_ORDER = { ["unterboten"] = 1, ["gleich"] = 2, ["?"] = 3, ["günstigstes"] = 4, ["verkauft"] = 5 }

local function FormatTimeLeft(sec)
    if not sec then return "-" end
    if sec >= 3600 then return string.format(L["%d Std."], math.floor(sec / 3600)) end
    return string.format(L["%d Min."], math.max(1, math.floor(sec / 60)))
end

local function BuildAuctions(parent)
    local p = CreateFrame("Frame", nil, parent)
    local Se = A.Seller

    local function setMessage(ok, msg)
        if not msg then return end
        p.message:SetText(msg)
        p.message:SetTextColor(unpack(ok and C.textDim or C.red))
    end

    local head = UI:TabTitle(p, L["Meine Auktionen"], "auctions")
    p.summary = UI:Label(p, "", "GameFontHighlightSmall", C.textDim)
    p.summary:SetPoint("TOPLEFT", head, "BOTTOMLEFT", 0, -4)
    p.summary:SetWidth(900)

    p.refreshBtn = UI:Button(p, L["Aktualisieren"], 120, 24, function()
        setMessage(Se:QueryOwned())
    end)
    p.refreshBtn:SetPoint("TOPLEFT", 0, -44)
    p.refreshBtn.tooltip = L["Deine Auktionen neu vom Server laden"]

    p.checkBtn = UI:Button(p, L["Unterbietung prüfen"], 160, 24, function()
        setMessage(Se:CheckUndercuts())
    end)
    p.checkBtn:SetPoint("LEFT", p.refreshBtn, "RIGHT", 6, 0)
    p.checkBtn.tooltip = L["Lädt die aktuellen Angebote aller Items, die du anbietest,\nund zeigt, wo dich jemand unterboten hat."]

    p.cancelNextBtn = UI:Button(p, L["Nächste unterbotene abbrechen"], 230, 24, function()
        setMessage(Se:CancelNextUndercut())
    end, "danger")
    p.cancelNextBtn:SetPoint("LEFT", p.checkBtn, "RIGHT", 6, 0)
    p.cancelNextBtn.tooltip = L["Ein Klick bricht EINE unterbotene Auktion ab (die Einstellgebühr ist dann verloren).\nDanach im Tab Verkaufen neu und günstiger einstellen."]

    -- abgelaufene / abgebrochene Auktionen (aus der Post) wieder einstellen: ein Klick = eine Auktion
    p.repostBtn = UI:Button(p, "", 190, 24, function()
        setMessage(A.Extras:RepostStep())
        p:Refresh()
    end, "primary")
    p.repostBtn:SetPoint("LEFT", p.cancelNextBtn, "RIGHT", 6, 0)
    p.repostBtn.tooltip = L["Stellt Items wieder ein, die als abgelaufene oder abgebrochene Auktion\nper Post zurückgekommen sind (nach 'AH-Post abholen' am Briefkasten).\nEin Klick = eine Auktion, Preis: aktueller Vorschlag (unterbieten), mit Preisschutz."]

    p.message = UI:Label(p, "", "GameFontHighlightSmall", C.textDim)
    p.message:SetPoint("LEFT", p.repostBtn, "RIGHT", 10, 0)
    p.message:SetPoint("RIGHT", p, "RIGHT", 0, 0)

    p.table = UI:Table(p, {
        columns = {
            { key = "name", title = L["Item"], width = 220 },
            { key = "qty", title = L["Menge"], width = 60, align = "RIGHT" },
            { key = "unitPrice", title = L["Preis/Stück"], width = 120, align = "RIGHT" },
            { key = "lowest", title = L["Günstigstes"], width = 120, align = "RIGHT",
              tooltip = L["Günstigstes fremdes Angebot (nach 'Unterbietung prüfen')"] },
            { key = "buyout", title = L["Gesamt"], width = 120, align = "RIGHT" },
            { key = "timeLeft", title = L["Restzeit"], width = 80, align = "RIGHT" },
            { key = "status", title = L["Status"], width = 110 },
        },
        rows = 16,
        rowHeight = 22,
        idKey = "auctionID",
        sortKey = "status",
        sortAsc = true,
        cell = function(o, key)
            if key == "name" then return UI.ItemName(o) end
            if key == "qty" then return tostring(o.qty) end
            if key == "timeLeft" then return o.sold and "-" or FormatTimeLeft(o.timeLeft) end
            if key == "status" then
                local s = o.status or "?"
                return "|cff" .. (STATUS_COLOR[s] or "888888") .. L[s] .. "|r"
            end
            return A:FormatMoney(o[key])
        end,
        sortValue = function(o, key)
            if key == "name" then return string.lower(UI.ItemName(o)) end
            if key == "status" then return STATUS_ORDER[o.status or "?"] or 9 end
            return o[key]
        end,
        onClick = function(o) end,
        action = {
            text = "X", width = 26,
            tooltip = L["Auktion abbrechen (Einstellgebühr ist verloren)"],
            onClick = function(o) setMessage(Se:Cancel(o.auctionID)) end,
        },
        emptyText = L["Keine eigenen Auktionen.\nIm Tab Verkaufen Items einstellen."],
    })
    p.table:Fill(0, -80, 0, 4)

    function p:Refresh()
        local open = A:IsAHOpen()
        for _, b in ipairs({ self.refreshBtn, self.checkBtn, self.cancelNextBtn }) do b:SetActive(open) end
        local Se2 = A.Seller
        if Se2.batch and Se2.batch.repost then
            local cur, pos, total = Se2:BatchCurrent()
            self.repostBtn:SetText(cur and string.format(L["Neu einstellen: %s (%d/%d)"], cur.name, pos, total) or L["Neu einstellen"])
            self.repostBtn:SetActive(open)
        else
            local n = A.Extras:RepostCount()
            self.repostBtn:SetText(string.format(L["Neu einstellen (%d)"], n))
            self.repostBtn:SetActive(open and n > 0)
        end
        local list = Se.owned
        self.table:SetData(list, true)
        local active, value = 0, 0
        for _, o in ipairs(list) do
            if not o.sold then active = active + 1; value = value + (o.buyout or 0) end
        end
        local text = string.format(L["%d aktiv (Wert %s)   |   %d unterboten   |   %d verkauft"], active, A:FormatMoney(value),
            Se:CountByStatus("unterboten"), Se:CountByStatus("verkauft"))
        if #Se.queue > 0 or Se.search then
            text = text .. "   |   " .. string.format(L["|cffffcc33prüfe Preise ... (%d offen)|r"], #Se.queue + (Se.search and 1 or 0))
        end
        if not open then text = L["|cffff5544Auktionshaus öffnen, um deine Auktionen zu sehen.|r"] .. "   " .. text end
        self.summary:SetText(text)
    end

    return p
end

UI:RegisterTab("auctions", "Auktionen", 3.7, BuildAuctions)
