-- ============================================================
-- AHSentinel 0.59.30 - Oberflächen der Extras
--   * Knopf am Händler: Schrott & Lohnendes verkaufen
--   * Knopf am Briefkasten: Post an Twinks
--   * Fenster: Regeln für die Post an Twinks
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C
local X = A.Extras

-- ------------------------------------------------------------
-- Händler
-- ------------------------------------------------------------
function UI:UpdateVendorButton()
    if not (X and X.atMerchant) then
        if self.vendorButton then self.vendorButton:Hide() end
        return
    end
    if A.db and A.db.settings.vendorButton == false then
        if self.vendorButton then self.vendorButton:Hide() end
        return
    end
    local parent = (type(MerchantFrame) == "table") and MerchantFrame or UIParent
    if not self.vendorButton then
        local b = UI:Button(parent, "", 250, 24, function()
            local ok, msg = X:SellToVendor()
            if msg then A:Print(msg) end
        end, "primary")
        b:SetPoint("TOPRIGHT", parent, "BOTTOMRIGHT", 0, -4)
        if b.SetFrameStrata then b:SetFrameStrata("HIGH") end
        b:SetScript("OnEnter", function(self)
            local list, total, junk, better = X:VendorCandidates()
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
            GameTooltip:SetText(L["Schrott & Lohnendes verkaufen"], 1, 1, 1)
            GameTooltip:AddLine(L["Verkauft graue Items und alles, was beim Händler mehr bringt\nals im Auktionshaus nach dem AH-Anteil."], 0.9, 0.9, 0.9, true)
            GameTooltip:AddLine(" ")
            GameTooltip:AddDoubleLine(L["Schrott"], A:FormatMoney(junk), 0.6, 0.6, 0.6, 1, 1, 1)
            GameTooltip:AddDoubleLine(L["Beim Händler lohnender"], A:FormatMoney(better), 0.6, 0.6, 0.6, 1, 1, 1)
            for i, e in ipairs(list) do
                if i > 12 then GameTooltip:AddLine(string.format(L["... und %d weitere"], #list - 12), 0.6, 0.6, 0.6); break end
                GameTooltip:AddDoubleLine(e.count .. "x " .. A:GetItemName(e.itemID), A:FormatMoney(e.value), 0.9, 0.9, 0.9, 1, 1, 1)
            end
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        self.vendorButton = b
    end
    local list, total = X:VendorCandidates()
    local b = self.vendorButton
    b:SetText(string.format(L["Verkaufen: %d Items (%s)"], #list, A:FormatMoney(total)))
    b:SetActive(#list > 0 and not X.selling)
    b:Show()
end
A:On("VENDOR_CHANGED", function() UI:UpdateVendorButton() end)

-- ------------------------------------------------------------
-- Post an Twinks: Regeln
-- ------------------------------------------------------------
local MAX_RULES = 8

function UI:ShowMailRules()
    if not self.mailRulesWindow then
        local w = self:Dialog("AHAnalyzerProMailRules", 470, 120 + MAX_RULES * 30, L["Post an Twinks"])
        local intro = UI:Label(w, L["Welche Waren an welchen Charakter? Am Briefkasten verschickt der Knopf\n'An Twinks' pro Klick eine Post mit passenden Waren aus deinen Taschen."], "GameFontHighlightSmall", C.textDim)
        intro:SetPoint("TOPLEFT", 16, -36)
        w.rows = {}
        local cats = X:RuleCategories()
        for i = 1, MAX_RULES do
            local r = CreateFrame("Frame", nil, w)
            r:SetSize(440, 26)
            r:SetPoint("TOPLEFT", 16, -70 - (i - 1) * 30)
            r.cat = UI:Button(r, "", 190, 24, function(self, button)
                local rule = X.RulesDB()[i]
                if not rule then return end
                local idx = 1
                for k, c in ipairs(cats) do if c.key == rule.cat then idx = k end end
                idx = (button == "RightButton") and ((idx - 2) % #cats + 1) or (idx % #cats + 1)
                rule.cat = cats[idx].key
                w:Refresh()
            end)
            if r.cat.RegisterForClicks then r.cat:RegisterForClicks("LeftButtonUp", "RightButtonUp") end
            r.cat:SetPoint("LEFT", 0, 0)
            r.cat.tooltip = L["Kategorie (Linksklick: nächste, Rechtsklick: vorige)"]
            local arrow = UI:Label(r, "->", "GameFontHighlight", C.textDim)
            arrow:SetPoint("LEFT", r.cat, "RIGHT", 8, 0)
            r.to = UI:EditBox(r, 150, 24, L["Charakter"])
            r.to:SetPoint("LEFT", arrow, "RIGHT", 8, 0)
            r.to:SetScript("OnTextChanged", function(self)
                local rule = X.RulesDB()[i]
                if rule then rule.to = self:GetText() end
            end)
            r.del = UI:Button(r, "X", 26, 24, function()
                table.remove(X.RulesDB(), i)
                w:Refresh()
            end, "danger")
            r.del:SetPoint("LEFT", r.to, "RIGHT", 8, 0)
            r.del.tooltip = L["Regel löschen"]
            w.rows[i] = r
        end
        w.add = UI:Button(w, L["+ Regel"], 110, 24, function()
            local rules = X.RulesDB()
            if #rules >= MAX_RULES then return end
            table.insert(rules, { cat = "herb", to = "" })
            w:Refresh()
        end, "primary")
        w.add:SetPoint("BOTTOMLEFT", 16, 16)
        w.alts = UI:Label(w, "", "GameFontDisableSmall", C.textDim)
        w.alts:SetPoint("LEFT", w.add, "RIGHT", 12, 0)
        w.alts:SetWidth(320)
        function w:Refresh()
            local rules = X.RulesDB()
            for i, r in ipairs(self.rows) do
                local rule = rules[i]
                if rule then
                    local c = X:CatByKey(rule.cat)
                    r.cat:SetText(c and L[c.label] or "?")
                    if not r.to:HasFocus() then r.to:SetText(rule.to or "") end
                    r:Show()
                else
                    r:Hide()
                end
            end
            self.add:SetActive(#rules < MAX_RULES)
            -- bekannte Twinks als Hilfe
            local names = {}
            local me = UnitName and UnitName("player")
            for _, c in ipairs(A.Chars and A.Chars:GetAll() or {}) do
                if c.name ~= me then table.insert(names, c.name) end
            end
            self.alts:SetText(#names > 0 and (L["Deine Twinks: "] .. table.concat(names, ", ")) or "")
            A:Fire("MAILRULES_CHANGED")
        end
        w:SetScript("OnShow", function(self) self:Refresh() end)
        self.mailRulesWindow = w
    end
    self.mailRulesWindow:Show()
    self.mailRulesWindow:Refresh()
    return self.mailRulesWindow
end
