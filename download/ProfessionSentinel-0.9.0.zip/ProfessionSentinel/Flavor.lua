local _, ns = ...

-- Detects which game version is running and sets ns.Flavor:
--   "forever" = WoW Forever (interface 16000-16999, project WOW_PROJECT_CAMELOT)
--   "era"     = Classic Era / Hardcore (interface 11500-11599)
--   "retail"  = Retail (interface 100000+, e.g. 120105 = 12.1.5 Midnight; project WOW_PROJECT_MAINLINE)
--   nil       = not supported (the addon stays idle and says so once)
-- Only the matching data file (Data_Forever.lua / Data_Era.lua / Data_Retail.lua) loads its tables.

local version, build, _, interface = GetBuildInfo()
interface = tonumber(interface) or 0

ns.ClientVersion = version
ns.ClientBuild = build
ns.Interface = interface

local flavor
if (WOW_PROJECT_CAMELOT and WOW_PROJECT_ID == WOW_PROJECT_CAMELOT) or (interface >= 16000 and interface < 17000) then
    flavor = "forever"
elseif interface >= 11500 and interface < 11600 then
    flavor = "era"
elseif interface >= 100000 or (WOW_PROJECT_MAINLINE and WOW_PROJECT_ID == WOW_PROJECT_MAINLINE) then
    flavor = "retail"
end

ns.Flavor = flavor
ns.IsForever = flavor == "forever"
ns.IsEra = flavor == "era"
ns.IsRetail = flavor == "retail"

-- Which profession window the client uses
ns.UsesModernProfessions = ns.IsForever or ns.IsRetail

-- Retail has no QuestieDB data: no vendor/drop/quest sources, no trainer locations
ns.HasSourceData = not ns.IsRetail
