local ADDON, ns = ...

-- Autotest (/ps autotest, nur Entwickler): testet das Addon im laufenden Spiel selbstständig.
--   * öffnet das Panel für jeden Beruf, klickt jeden Reiter, jeden Knopf, jede Zeile (links und rechts),
--     fährt mit der Maus über Zeilen (Tooltips), klappt Gruppen auf/zu, sucht, filtert, scrollt,
--     simuliert Fertigkeit 1/75/150/225/300 und "alles gelernt"/"nichts gelernt"
--   * Testmodus-Fenster: jeder Knopf wird geklickt; Slash-Befehle werden ausgeführt
--   * Item-Tooltips (Rezept, Ergebnis, Material), Lebenslinie im Berufsfenster, Andocken (falls offen)
--   * Logik-Selbsttest (TestMode:RunSelfTest), Laufzeit und Speicher
--   * fängt jeden Lua-Fehler ab, der dabei entsteht (auch aus OnClick/OnEnter)
-- Sicherheit: alles mit echten Folgen wird während des Tests NICHT ausgeführt, sondern nur protokolliert
--   (Händler-Einkauf, Flüstern, Sniper-Ziele in AHSentinel, Wegpunkte, Eingabefenster, Zielfrage).
--   Einstellungen und Simulation werden vorher gesichert und am Ende exakt wiederhergestellt.
-- Am Ende entsteht ein Bericht für Claude: Fenster zum Kopieren + gespeichert in
--   ProfessionSentinelDB.autotest.last (nach /reload in WTF\Account\<Konto>\SavedVariables\ProfessionSentinel.lua).

local AT = {}
ns.AutoTest = AT

local STEP_DELAY = 0.05            -- Sekunden zwischen den Schritten (UI kann zeichnen)
local RANKS = { 1, 75, 150, 225, 300 }
local MODES = { "recipes", "ranking", "plan", "trainers", "disenchant" }
local MAX_ROWS = 12                -- so viele sichtbare Zeilen je Ansicht anklicken/überfahren
local SLOW_MS = 50                 -- Refresh langsamer als das = Warnung
local HISTORY = 10                 -- so viele Kurzergebnisse bleiben gespeichert

local run                          -- aktueller Lauf (nil = keiner)
local queue, qi = {}, 0
local reportWin

---------------------------------------------------------------------------
-- Kleine Helfer
---------------------------------------------------------------------------
local function Now() return debugprofilestop and debugprofilestop() or (GetTime and GetTime() * 1000) or 0 end

local function DeepCopy(v, seen)
    if type(v) ~= "table" then return v end
    seen = seen or {}
    if seen[v] then return seen[v] end
    local t = {}
    seen[v] = t
    for k, x in pairs(v) do t[DeepCopy(k, seen)] = DeepCopy(x, seen) end
    return t
end

local function DeepEqual(a, b)
    if type(a) ~= type(b) then return false end
    if type(a) ~= "table" then return a == b end
    for k, v in pairs(a) do if not DeepEqual(v, b[k]) then return false end end
    for k in pairs(b) do if a[k] == nil then return false end end
    return true
end

local function Plain(s)
    s = tostring(s or "")
    s = s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", ""):gsub("|H.-|h(.-)|h", "%1"):gsub("|n", " ")
    return s
end

local function ObjType(f)
    if not f or not f.GetObjectType then return nil end
    local ok, t = pcall(f.GetObjectType, f)
    return ok and t or nil
end

local function Children(f)
    if not f or not f.GetChildren then return {} end
    local ok, a = pcall(function() return { f:GetChildren() } end)
    return ok and a or {}
end

local function Descendants(f, out)
    out = out or {}
    for _, k in ipairs(Children(f)) do
        out[#out + 1] = k
        Descendants(k, out)
    end
    return out
end

local function Shown(f)
    if not f or not f.IsVisible then return false end
    local ok, v = pcall(f.IsVisible, f)
    return ok and v or false
end

local function Label(f, i)
    local t
    if f and f.GetText then
        local ok, s = pcall(f.GetText, f)
        if ok and s and s ~= "" then t = Plain(s) end
    end
    if not t and f and f.GetName then
        local ok, s = pcall(f.GetName, f)
        if ok and s then t = s end
    end
    return t or ("Knopf #" .. (i or "?"))
end

local function ProfList()
    local list = {}
    for _, p in ipairs(ns.Professions or {}) do
        if ns.ByProf[p.id] and #ns.ByProf[p.id] > 3 then list[#list + 1] = p end
    end
    return list
end

local function AddonVersion()
    local get = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
    if not get then return "?" end
    local ok, v = pcall(get, ADDON, "Version")
    return ok and v or "?"
end

local function OtherAddons()
    local out = {}
    local isLoaded = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
    local get = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
    for _, name in ipairs({ "AHSentinel", "GuildSentinel", "RaidMaster", "TradeSkillMaster", "Auctionator", "TomTom", "BugSack", "Questie" }) do
        local ok, loaded = pcall(isLoaded or function() return false end, name)
        if ok and loaded then
            local okV, v = false, nil
            if get then okV, v = pcall(get, name, "Version") end
            out[#out + 1] = name .. ((okV and v) and (" " .. tostring(v)) or "")
        end
    end
    return #out > 0 and table.concat(out, ", ") or "keine"
end

---------------------------------------------------------------------------
-- Ergebnis erfassen
---------------------------------------------------------------------------
local function Area() return run and run.area or "?" end

local function Check(name, cond, detail)
    if not run then return cond end
    local a = Area()
    run.areas[a] = run.areas[a] or { ok = 0, fail = 0, order = #run.areaOrder + 1 }
    if not run.areas[a].seen then run.areas[a].seen = true; run.areaOrder[#run.areaOrder + 1] = a end
    if cond then run.areas[a].ok = run.areas[a].ok + 1 else run.areas[a].fail = run.areas[a].fail + 1 end
    run.checks[#run.checks + 1] = { area = a, name = name, ok = cond and true or false, detail = detail and Plain(detail) or nil }
    return cond
end

local function Warn(msg) if run then run.warnings[#run.warnings + 1] = "[" .. Area() .. "] " .. Plain(msg) end end
local function Skip(msg) if run then run.skipped[#run.skipped + 1] = "[" .. Area() .. "] " .. Plain(msg) end end
local function Note(msg) if run then run.notes[#run.notes + 1] = Plain(msg) end end

local function LuaError(msg, stack, where)
    if not run then return end
    msg = tostring(msg)
    local own = msg:find(ADDON, 1, true) or (stack and stack:find(ADDON, 1, true))
    local key = msg
    for _, e in ipairs(run.errors) do
        if e.key == key then e.count = e.count + 1; return end
    end
    local lines = {}
    for line in tostring(stack or ""):gmatch("[^\n]+") do
        if #lines < 8 and not line:find("AutoTest.lua", 1, true) then lines[#lines + 1] = line end
    end
    run.errors[#run.errors + 1] = { key = key, msg = msg, stack = table.concat(lines, "\n"), where = where or run.step or "?",
        own = own and true or false, count = 1 }
end

---------------------------------------------------------------------------
-- Sandbox: Aktionen mit echten Folgen abfangen
---------------------------------------------------------------------------
local INTERCEPT = {
    { "Plan", "BuyFromVendor", "Beim Händler kaufen", 0 },
    { "Plan", "ToSniper", "Plan -> Sniper (AHSentinel)", 0 },
    { "Disenchant", "SendToSniper", "Sniper-Ziele anlegen (AHSentinel)", 0 },
    { "Disenchant", "WhisperOffer", "VZ-Angebot flüstern", false },
    { "Disenchant", "AskGoal", "Fenster Ziel Verzauberkunst", nil },
    { "Disenchant", "EditMarkup", "Eingabe Aufschlag", nil },
    { "Disenchant", "EditMinProfit", "Eingabe Mindestgewinn", nil },
    { "Disenchant", "EditMargin", "Eingabe Marge", nil },
    { "Alerts", "ToSniper", "Rezept-Alarm -> Sniper", 0 },
    { "Waypoint", "Set", "Wegpunkt setzen", nil },
}

local function SandboxOn()
    run.saved.fn = {}
    for _, def in ipairs(INTERCEPT) do
        local mod, key, label, ret = def[1], def[2], def[3], def[4]
        local t = ns[mod]
        if t and type(t[key]) == "function" then
            run.saved.fn[mod .. "." .. key] = { t = t, key = key, fn = t[key] }
            t[key] = function()
                if run then run.intercepted[label] = (run.intercepted[label] or 0) + 1 end
                return ret
            end
        end
    end
end

local function SandboxOff()
    if not run or not run.saved.fn then return end
    for _, s in pairs(run.saved.fn) do s.t[s.key] = s.fn end
    run.saved.fn = nil
    -- falls doch ein eigenes Eingabefenster offen ist: schließen
    for i = 1, 4 do
        local f = _G["StaticPopup" .. i]
        if f and f:IsShown() and tostring(f.which or ""):find("^PROFESSIONSENTINEL") then f:Hide() end
    end
end

local function Original(mod, key)
    local s = run and run.saved.fn and run.saved.fn[mod .. "." .. key]
    return s and s.fn or (ns[mod] and ns[mod][key])
end

---------------------------------------------------------------------------
-- Zustand sichern / wiederherstellen
---------------------------------------------------------------------------
local DB_KEYS = { "panelMode", "filters", "collapsed", "lifeline", "best", "tooltip", "panelOpen", "recipeAlert",
    "guildShare", "vzMarkup", "vzMinProfit", "deMargin" }

local function SaveState()
    local s = { db = {} }
    for _, k in ipairs(DB_KEYS) do s.db[k] = DeepCopy(ns.db[k]) end
    s.sim = ns.Sim                                       -- Referenz (kann Metatabellen enthalten)
    s.panelShown = ns.UI and ns.UI:IsShown() or false
    s.testShown = _G.ProfessionSentinelTestMode and _G.ProfessionSentinelTestMode:IsShown() or false
    local sb = AT.SearchBox()
    s.search = sb and sb:GetText() or ""
    run.saved = s
end

local function RestoreState()
    local s = run.saved
    for _, k in ipairs(DB_KEYS) do
        local v = DeepCopy(s.db[k])
        if type(ns.db[k]) == "table" and type(v) == "table" then
            -- gleiche Tabelle behalten (UI hält Referenzen, z. B. collapsed)
            for key in pairs(ns.db[k]) do ns.db[k][key] = nil end
            for key, x in pairs(v) do ns.db[k][key] = x end
        else
            ns.db[k] = v
        end
    end
    ns.Sim = s.sim
    local sb = AT.SearchBox()
    if sb then sb:SetText(s.search or "") end
    local mc = AT.MissingCheck()
    if mc then mc:SetChecked(ns.db.filters.missing) end
    local tw = _G.ProfessionSentinelTestMode
    if tw and tw:IsShown() ~= s.testShown then tw:SetShown(s.testShown) end
    if ns.UI then
        local host = AT.ActiveHost()
        if s.panelShown then ns.UI:Show(host) else ns.UI:Hide() end
    end
    if GameTooltip then GameTooltip:Hide() end
    if ns.RefreshAll then pcall(ns.RefreshAll) end
end

local function StateUnchanged()
    for _, k in ipairs(DB_KEYS) do
        if not DeepEqual(ns.db[k], run.saved.db[k]) then return false, k end
    end
    if ns.Sim ~= run.saved.sim then return false, "Sim" end
    return true
end

---------------------------------------------------------------------------
-- Panel-Teile finden (ohne die UI-Datei zu ändern)
---------------------------------------------------------------------------
function AT.Panel() return _G.ProfessionSentinelPanel end

function AT.ActiveHost()
    if ns.UsesModernProfessions then
        return ProfessionsFrame and ProfessionsFrame:IsShown() and ProfessionsFrame or nil
    end
    if CraftFrame and CraftFrame:IsShown() then return CraftFrame end
    if TradeSkillFrame and TradeSkillFrame:IsShown() then return TradeSkillFrame end
end

function AT.SearchBox()
    for _, f in ipairs(Children(AT.Panel())) do
        if ObjType(f) == "EditBox" then return f end
    end
end

function AT.MissingCheck()
    for _, f in ipairs(Children(AT.Panel())) do
        if ObjType(f) == "CheckButton" then return f end
    end
end

function AT.Tabs()
    local p, out = AT.Panel(), {}
    for _, f in ipairs(Children(p)) do
        if ObjType(f) == "Button" and f ~= (p and p.CloseButton) and f:GetScript("OnClick") then out[#out + 1] = f end
    end
    return out
end

function AT.ScrollBox()
    for _, f in ipairs(Descendants(AT.Panel())) do
        if f.GetDataProvider and f.GetFrames then return f end
    end
end

local function RowCount()
    local sb = AT.ScrollBox()
    if not sb then return nil end
    local ok, dp = pcall(sb.GetDataProvider, sb)
    if not ok or not dp then return 0 end
    if dp.GetSize then
        local ok2, n = pcall(dp.GetSize, dp, true)       -- true = eingeklappte Gruppen nicht mitzählen
        if ok2 and type(n) == "number" then return n end
    end
    local n = 0
    if dp.Enumerate then
        local ok3 = pcall(function() for _ in dp:Enumerate() do n = n + 1 end end)
        if ok3 then return n end
    end
    return n
end

local function VisibleRows()
    local sb = AT.ScrollBox()
    if not sb then return {}, {} end
    local ok, frames = pcall(sb.GetFrames, sb)
    if not ok or type(frames) ~= "table" then return {}, {} end
    local rows, headers = {}, {}
    for _, f in ipairs(frames) do
        if Shown(f) then
            if ObjType(f) == "CheckButton" then headers[#headers + 1] = f else rows[#rows + 1] = f end
        end
    end
    return rows, headers
end

local function PanelTitle()
    local p = AT.Panel()
    if not p then return "" end
    local t = p.TitleText
    if type(t) ~= "table" and type(p.TitleContainer) == "table" then t = p.TitleContainer.TitleText end
    if type(t) == "table" and t.GetText then return Plain(t:GetText()) end
    if p.GetTitle then local ok, s = pcall(p.GetTitle, p); if ok then return Plain(s) end end
    return ""
end

local function Refresh()
    local t = Now()
    if ns.RefreshAll then ns.RefreshAll() elseif ns.UI then ns.UI:Refresh() end
    return Now() - t
end

---------------------------------------------------------------------------
-- Schritt-Bausteine
---------------------------------------------------------------------------
local function Step(area, name, fn) queue[#queue + 1] = { area = area, name = name, fn = fn } end

local function RowName(r)
    local fs = type(r.name) == "table" and r.name or type(r.label) == "table" and r.label or nil
    if fs and fs.GetText then local ok, t = pcall(fs.GetText, fs); if ok and t and t ~= "" then return Plain(t) end end
    return Label(r)
end

local function HoverRows(rows, what)
    local shown, empty, emptyNames = 0, 0, {}
    for i = 1, math.min(#rows, MAX_ROWS) do
        local r = rows[i]
        local enter, leave = r:GetScript("OnEnter"), r:GetScript("OnLeave")
        if enter then
            enter(r)
            run.hovers = run.hovers + 1
            if GameTooltip:IsShown() and (GameTooltip:NumLines() or 0) > 0 then shown = shown + 1
            else
                empty = empty + 1
                if #emptyNames < 3 then emptyNames[#emptyNames + 1] = "„" .. RowName(r) .. "“" end
            end
            if leave then leave(r) end
        end
    end
    if shown + empty > 0 then
        Check(what .. ": " .. (shown + empty) .. " Zeilen überfahren ohne Fehler", true)
        -- leerer Tooltip ist kein Absturz, aber sichtbar unschön: als Warnung melden
        if empty > 0 then Warn(what .. ": " .. empty .. " Zeile(n) ohne Tooltip-Inhalt: " .. table.concat(emptyNames, ", ")) end
    end
end

local function ClickRows(rows, what)
    local n = 0
    for i = 1, math.min(#rows, MAX_ROWS) do
        local r = rows[i]
        local onClick = r:GetScript("OnClick")
        if onClick then
            onClick(r, "LeftButton")
            onClick(r, "RightButton")
            n = n + 1
            run.clicks = run.clicks + 2
        end
    end
    if n > 0 then Check(what .. ": " .. n .. " Zeilen links+rechts geklickt", true) end
end

-- erste Kopfzeile, auf die direkt eine Inhaltszeile folgt (leere Gruppen lassen sich nicht zuklappen)
local function FirstFilledHeader()
    local sb = AT.ScrollBox()
    if not sb then return nil end
    local ok, frames = pcall(sb.GetFrames, sb)
    if not ok or type(frames) ~= "table" then return nil end
    local list = {}
    for _, f in ipairs(frames) do if Shown(f) then list[#list + 1] = f end end
    -- Reihenfolge wie auf dem Bildschirm (GetFrames ist nicht immer sortiert)
    table.sort(list, function(a, b)
        local ta = a.GetTop and select(2, pcall(a.GetTop, a)) or 0
        local tb = b.GetTop and select(2, pcall(b.GetTop, b)) or 0
        return (tonumber(ta) or 0) > (tonumber(tb) or 0)
    end)
    for i, f in ipairs(list) do
        local nxt = list[i + 1]
        if ObjType(f) == "CheckButton" and nxt and ObjType(nxt) ~= "CheckButton" then return f end
    end
end

local function ToggleFirstHeader(what)
    local h = FirstFilledHeader()
    if not h or not h:GetScript("OnClick") then
        run.noGroups = (run.noGroups or 0) + 1      -- im Bericht einmal zusammengefasst
        return
    end
    local label = RowName(h)
    local before = RowCount() or 0
    h:Click()
    run.clicks = run.clicks + 1
    local mid = RowCount() or 0
    -- dieselbe Gruppe wieder aufklappen: nach dem Neuaufbau kann ein anderer Frame sie zeigen, also über den Namen suchen
    local again
    local _, headers2 = VisibleRows()
    for _, x in ipairs(headers2) do if RowName(x) == label then again = x; break end end
    if again then again:Click(); run.clicks = run.clicks + 1 end
    local after = RowCount() or 0
    if mid == before then
        Warn(what .. ": Klick auf die Kopfzeile änderte die Zeilenzahl nicht (" .. before .. ")")
    end
    Check(what .. ": Gruppe zu- und wieder aufklappen, danach wie vorher", after == before, before .. " -> " .. mid .. " -> " .. after)
end

local function Scroll(what)
    local sb = AT.ScrollBox()
    if not sb then return end
    local ok1 = pcall(function() if sb.ScrollToEnd then sb:ScrollToEnd() end end)
    local ok2 = pcall(function() if sb.ScrollToBegin then sb:ScrollToBegin() end end)
    Check(what .. ": ans Ende und zurück scrollen", ok1 and ok2)
end

---------------------------------------------------------------------------
-- Testplan
---------------------------------------------------------------------------
local function BuildQueue()
    queue, qi = {}, 0
    local profs = ProfList()

    Step("Start", "Umgebung", function()
        Check("Spielversion erkannt", ns.Flavor ~= nil, tostring(ns.Flavor))
        Check("Rezeptdaten geladen", #ns.Recipes > 0, #ns.Recipes .. " Rezepte")
        Check("Gespeicherte Daten vorhanden", ns.db ~= nil)
        Check("Entwickler erkannt", ns.IsDev())
        Check("Berufe zum Testen", #profs > 0, #profs .. " Berufe")
        -- Item-Daten für die Tooltip-Tests vorladen
        run.tipItems = {}
        local r
        for _, x in ipairs(ns.ByProf[165] or ns.Recipes) do
            if x.recipeItems[1] and #x.reagents > 0 then r = x; break end
        end
        if r then
            run.tipItems = { { "Rezept", r.recipeItems[1].id }, { "Material", r.reagents[1] } }
            for _, e in ipairs(run.tipItems) do
                if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, e[2]) end
            end
        end
    end)

    Step("Logik-Selbsttest", "TestMode:RunSelfTest", function()
        if not (ns.TestMode and ns.TestMode.RunSelfTest) then Skip("TestMode fehlt"); return end
        local saved = ns.Sim
        local ok, results = ns.TestMode:RunSelfTest(false)
        ns.Sim = saved
        for i = 2, #(results or {}) do
            local line = Plain(results[i])
            local pass = not line:find(Plain(ns.L.TEST_FAIL), 1, true)
            Check((line:gsub("^%S+%s+", "")), pass)
        end
        Check("Selbsttest insgesamt", ok)
    end)

    Step("Slash-Befehle", "/ps help, line, alarm, /gsdev", function()
        local slash = SlashCmdList.PROFESSIONSENTINEL
        Check("/ps registriert", type(slash) == "function")
        if type(slash) ~= "function" then return end
        slash("help")
        local l0 = ns.db.lifeline
        slash("line"); local l1 = ns.db.lifeline
        slash("line"); local l2 = ns.db.lifeline
        Check("/ps line schaltet um und zurück", l1 == not l0 and l2 == l0, tostring(l0) .. " -> " .. tostring(l1) .. " -> " .. tostring(l2))
        local a0 = ns.db.recipeAlert ~= false
        slash("alarm"); local a1 = ns.db.recipeAlert ~= false
        slash("alarm"); local a2 = ns.db.recipeAlert ~= false
        Check("/ps alarm schaltet um und zurück", a1 == not a0 and a2 == a0)
        slash("ziel")
        Check("/ps ziel ruft Zielfrage auf (abgefangen)", (run.intercepted["Fenster Ziel Verzauberkunst"] or 0) > 0)
        if SlashCmdList.GOLDSENTINELDEV then SlashCmdList.GOLDSENTINELDEV(""); Check("/gsdev läuft", true) end
    end)

    Step("Testmodus-Fenster", "öffnen", function()
        if not ns.TestMode then Skip("TestMode fehlt"); return end
        local w = _G.ProfessionSentinelTestMode
        local existed = w ~= nil
        if w and w:IsShown() then w:Hide() end
        local okT, errT = pcall(ns.TestMode.Toggle, ns.TestMode)
        w = _G.ProfessionSentinelTestMode
        local opened = w ~= nil and w:IsShown()
        if not opened then
            -- Grund sammeln, damit der Bericht zeigt, woran es lag
            local why = {}
            why[#why + 1] = "Entwickler: " .. tostring(ns.IsDev())
            why[#why + 1] = "Fenster vorher: " .. (existed and "ja" or "nein") .. ", nachher: " .. (w and "ja" or "nein")
            if not okT then why[#why + 1] = "Fehler in Toggle: " .. tostring(errT) end
            if w then
                local okS, errS = pcall(w.Show, w)
                why[#why + 1] = "direktes Show(): " .. (okS and (w:IsShown() and "geht auf" or "bleibt zu") or ("Fehler " .. tostring(errS)))
                if w:IsShown() and not w:IsVisible() then why[#why + 1] = "sichtbar: nein (Elternfenster versteckt)" end
            end
            Check("Testmodus-Fenster geöffnet", false, table.concat(why, " · "))
            -- weitertesten, falls das direkte Show() geklappt hat
        else
            Check("Testmodus-Fenster geöffnet", true)
        end
    end)

    Step("Testmodus-Fenster", "jeden Knopf klicken", function()
        local w = _G.ProfessionSentinelTestMode
        if not (w and w:IsShown()) then Skip("Fenster nicht offen"); return end
        local n, names = 0, {}
        for i, f in ipairs(Descendants(w)) do
            local t = ObjType(f)
            if (t == "Button" or t == "CheckButton") and f ~= w.CloseButton and Shown(f) and f:GetScript("OnClick") then
                f:Click()
                n = n + 1
                run.clicks = run.clicks + 1
                names[#names + 1] = Label(f, i)
            end
        end
        Check("Knöpfe im Testmodus geklickt", n >= 10, n .. ": " .. table.concat(names, ", "))
    end)

    Step("Testmodus-Fenster", "schließen", function()
        ns.Sim = nil
        local w = _G.ProfessionSentinelTestMode
        if w and w:IsShown() then pcall(ns.TestMode.Toggle, ns.TestMode) end
        if w and w:IsShown() then
            w:Hide()                                    -- Ersatz, damit das Fenster nicht offen bleibt
            Check("Testmodus-Fenster über /ps test geschlossen", false, "blieb offen, direkt mit Hide() geschlossen")
        else
            Check("Testmodus-Fenster geschlossen", true)
        end
        Check("Ergebnistext erzeugt", ns.TestMode.Diagnostics and #Plain(ns.TestMode:Diagnostics()) > 50)
    end)

    for _, p in ipairs(profs) do
        local pname = ns.ProfName(p.id)
        local area = "Panel " .. pname

        Step(area, "öffnen", function()
            ns.Sim = { prof = p.id }
            ns.db.panelMode = "recipes"
            ns.db.filters.missing = false
            ns.UI:Show(nil)
            local sb = AT.SearchBox()
            if sb then sb:SetText("") end
            local ms = Refresh()
            run.perf[#run.perf + 1] = { pname, ms }
            Check("Panel sichtbar", ns.UI:IsShown())
            Check("Titel = Berufsname", PanelTitle():find(Plain(pname), 1, true) ~= nil, PanelTitle())
            local n = RowCount()
            Check("Rezeptliste hat Zeilen", n and n > 0, tostring(n))
            if ms > SLOW_MS then Warn(string.format("Refresh dauerte %.0f ms", ms)) end
        end)

        Step(area, "Reiter per Klick", function()
            local tabs = AT.Tabs()
            Check("Reiter gefunden", #tabs >= 4, #tabs .. " Reiter")
            ns.Sim.enchanter = true
            local seen = {}
            for i, b in ipairs(tabs) do
                b:Click()
                run.clicks = run.clicks + 1
                seen[ns.db.panelMode or "?"] = Label(b, i)
            end
            for _, m in ipairs(MODES) do
                Check("Reiter " .. m .. " erreichbar", seen[m] ~= nil, seen[m])
            end
        end)

        for _, mode in ipairs(MODES) do
            Step(area, "Ansicht " .. mode, function()
                ns.Sim = { prof = p.id, enchanter = mode == "disenchant" or nil }
                ns.db.panelMode = mode
                Refresh()
                local what = mode
                local n = RowCount()
                Check(what .. ": Ansicht aufgebaut", n ~= nil, tostring(n))
                if mode == "recipes" or mode == "trainers" then
                    if (n or 0) == 0 then Warn(what .. ": keine Zeilen") end
                end
                local rows = VisibleRows()
                HoverRows(rows, what)
            end)
            Step(area, "Ansicht " .. mode .. " bedienen", function()
                ns.Sim = { prof = p.id, enchanter = mode == "disenchant" or nil }
                ns.db.panelMode = mode
                Refresh()
                local rows = VisibleRows()
                ClickRows(rows, mode)
                Refresh()
                ToggleFirstHeader(mode)
                Scroll(mode)
            end)
        end

        Step(area, "Fertigkeit 1/75/150/225/300", function()
            ns.db.panelMode = "recipes"
            local counts = {}
            for _, rank in ipairs(RANKS) do
                ns.Sim = { prof = p.id, rank = rank }
                Refresh()
                counts[#counts + 1] = rank .. ":" .. tostring(RowCount())
                local rows = VisibleRows()
                HoverRows(rows, "Fertigkeit " .. rank)
            end
            Check("Alle Fertigkeitsstufen ohne Fehler", true, table.concat(counts, " "))
        end)

        Step(area, "Filter fehlend + gelernt-Simulation", function()
            ns.db.panelMode = "recipes"
            ns.db.filters.missing = false
            ns.Sim = { prof = p.id, known = "all" }
            Refresh()
            local all = RowCount() or 0
            local mc = AT.MissingCheck()
            if mc then
                mc:SetChecked(false)
                mc:Click()
                run.clicks = run.clicks + 1
                Check("Häkchen „fehlend“ setzt den Filter", ns.db.filters.missing == true)
            else
                ns.db.filters.missing = true
                Check("Häkchen „fehlend“ gefunden", false)
            end
            Refresh()
            local missAll = RowCount() or 0
            ns.Sim.known = "none"
            Refresh()
            local missNone = RowCount() or 0
            Check("Alles gelernt + nur fehlend -> weniger Zeilen", missAll < all, all .. " -> " .. missAll)
            if missNone ~= all then Warn(string.format("nichts gelernt + nur fehlend: %d statt %d Zeilen", missNone, all)) end
            if mc then mc:Click(); run.clicks = run.clicks + 1 else ns.db.filters.missing = false end
            Check("Filter wieder aus", ns.db.filters.missing == false)
        end)

        Step(area, "Suche", function()
            ns.Sim = { prof = p.id }
            ns.db.panelMode = "recipes"
            local sb = AT.SearchBox()
            if not sb then Check("Suchfeld gefunden", false); return end
            sb:SetText("")
            Refresh()
            local all = RowCount() or 0
            local r = ns.ByProf[p.id][math.floor(#ns.ByProf[p.id] / 2) + 1]
            local term = ns.RecipeName(r):lower()
            sb:SetText(term)
            Refresh()
            local hit = RowCount() or 0
            sb:SetText("zzqx-gibtsnicht")
            Refresh()
            local none = RowCount() or 0
            sb:SetText("")
            Refresh()
            local back = RowCount() or 0
            Check("Suche findet „" .. ns.RecipeName(r) .. "“", hit > 0 and hit <= all, all .. " -> " .. hit)
            Check("Unsinnige Suche -> weniger Zeilen", none < all, tostring(none))
            Check("Suche leeren -> alles wieder da", back == all)
        end)

        Step(area, "Lebenslinie aus/an", function()
            ns.Sim = { prof = p.id }
            ns.db.panelMode = "recipes"
            local saved = ns.db.lifeline
            ns.db.lifeline = false; Refresh()
            ns.db.lifeline = true; Refresh()
            ns.db.lifeline = saved; Refresh()
            Check("Lebenslinie umschalten ohne Fehler", true)
        end)

        Step(area, "schließen", function()
            local p2 = AT.Panel()
            if p2 and p2.CloseButton and p2.CloseButton:GetScript("OnClick") then
                p2.CloseButton:Click()
                run.clicks = run.clicks + 1
            else
                ns.UI:Hide()
            end
            Check("Panel über X geschlossen", not ns.UI:IsShown())
        end)
    end

    Step("Item-Tooltips", "Rezept und Material", function()
        if #run.tipItems == 0 then Skip("kein Beispielrezept gefunden"); return end
        local saved = ns.db.tooltip
        for _, e in ipairs(run.tipItems) do
            local what, id = e[1], e[2]
            GameTooltip:SetOwner(UIParent, "ANCHOR_NONE")
            ns.db.tooltip = false
            GameTooltip:SetItemByID(id)
            local base = GameTooltip:NumLines() or 0
            GameTooltip:Hide()
            GameTooltip:SetOwner(UIParent, "ANCHOR_NONE")
            ns.db.tooltip = true
            GameTooltip:SetItemByID(id)
            local with = GameTooltip:NumLines() or 0
            GameTooltip:Hide()
            if base == 0 then
                Skip(what .. "-Tooltip: Item " .. id .. " noch nicht im Cache")
            else
                Check(what .. "-Tooltip bekommt Zeilen vom Addon (Item " .. id .. ")", with > base, base .. " -> " .. with)
            end
        end
        ns.db.tooltip = saved
    end)

    Step("Berufsfenster", "Lebenslinie + Andocken", function()
        if ns.Lifeline and ns.Lifeline.RefreshBlizzard then
            ns.Lifeline.RefreshBlizzard()
            Check("Lebenslinie im Blizzard-Fenster aktualisiert", true)
        end
        local host = AT.ActiveHost()
        if not host then
            Skip("Berufsfenster war nicht offen – für den Andock-Test vorher einen Beruf öffnen (Addons dürfen das nicht selbst)")
            return
        end
        ns.Sim = nil
        ns.UI:Show(host)
        local prof = ns.UI.CurrentProfession and ns.UI.CurrentProfession()
        Check("Beruf aus dem offenen Fenster erkannt", prof ~= nil, prof and ns.ProfName(prof))
        local p = AT.Panel()
        local _, rel = p:GetPoint(1)
        Check("Panel am Berufsfenster angedockt", rel == host)
        Check("Panel hat Zeilen", (RowCount() or 0) > 0)
        if ns.UsesModernProfessions then
            Check("Lebenslinien-Hook Forever aktiv", ns.Lifeline and ns.Lifeline.foreverHooked)
        else
            Check("Lebenslinien-Hook Handwerk aktiv", ns.Lifeline and (ns.Lifeline.tsHooked or ns.Lifeline.craftHooked))
        end
    end)

    Step("Wegpunkt", "echter Wegpunkt (einmal)", function()
        local set = Original("Waypoint", "Set")
        local list = ns.Trainers and ns.Trainers[165]
        if not (set and list and list[1]) then Skip("kein Lehrer"); return end
        if TomTom then Skip("TomTom geladen – kein echter Wegpunkt, um deine Liste nicht zu füllen"); return end
        if not (C_Map and C_Map.HasUserWaypoint and C_Map.ClearUserWaypoint) then Skip("C_Map-Wegpunkte fehlen (nur Chat)"); return end
        local had = C_Map.HasUserWaypoint()
        if had then Skip("du hattest schon einen Wegpunkt – nicht überschrieben"); return end
        set(list[1][1], "Autotest")
        local ok = C_Map.HasUserWaypoint()
        C_Map.ClearUserWaypoint()
        Check("Wegpunkt gesetzt und wieder entfernt", ok)
    end)

    Step("Ende", "Leistung und Speicher", function()
        if UpdateAddOnMemoryUsage then pcall(UpdateAddOnMemoryUsage) end
        local getMem = GetAddOnMemoryUsage or (C_AddOns and C_AddOns.GetAddOnMemoryUsage)
        if getMem then
            local ok, kb = pcall(getMem, ADDON)
            if ok and kb then run.memory = kb end
        end
        Check("Keine Lua-Fehler vom Addon", (function()
            for _, e in ipairs(run.errors) do if e.own then return false end end
            return true
        end)(), #run.errors .. " insgesamt")
    end)
end

---------------------------------------------------------------------------
-- Bericht für Claude
---------------------------------------------------------------------------
local function CharLine()
    local _, class = UnitClass("player")
    local level = UnitLevel and UnitLevel("player") or "?"
    local profs = {}
    local c = ns.Char()
    for id, p in pairs(c and c.profs or {}) do profs[#profs + 1] = ns.ProfName(id) .. " " .. (p.rank or 0) .. "/" .. (p.max or 0) end
    table.sort(profs)
    return string.format("%s, Stufe %s, %s · Berufe: %s", tostring(class), tostring(level), tostring(UnitFactionGroup("player")),
        #profs > 0 and table.concat(profs, ", ") or "keine erkannt")
end

local function BuildReport()
    local ok, fail = 0, 0
    for _, c in ipairs(run.checks) do if c.ok then ok = ok + 1 else fail = fail + 1 end end
    local own = 0
    for _, e in ipairs(run.errors) do if e.own then own = own + 1 end end
    local secs = (Now() - run.t0) / 1000
    local verdict = run.aborted and "ABGEBROCHEN" or (fail == 0 and own == 0) and "BESTANDEN" or "FEHLER GEFUNDEN"
    local _, build, _, iface = GetBuildInfo()
    local client = (GetBuildInfo())

    local L = {}
    local function add(s) L[#L + 1] = s end
    add("# ProfessionSentinel – Autotest-Bericht für Claude")
    add("")
    add(string.format("**Ergebnis: %s** · %d/%d Prüfungen OK · %d Fehler · %d Lua-Fehler (%d vom Addon) · %d Warnungen · %d übersprungen · %.1f s",
        verdict, ok, ok + fail, fail, #run.errors, own, #run.warnings, #run.skipped, secs))
    if run.aborted then add("Abbruch: " .. run.aborted) end
    add("")
    add("## Umgebung")
    add("- Addon: ProfessionSentinel " .. AddonVersion() .. " · Spielversion: " .. ns.FlavorName() .. " (" .. tostring(ns.Flavor) .. ")")
    add(string.format("- Client: %s (Build %s) · Interface %s · Sprache %s", tostring(client), tostring(build), tostring(iface), GetLocale()))
    add(string.format("- Daten: %d Rezepte · %s · Build %s · Questie %s", #ns.Recipes, tostring(ns.DataMeta.flavor),
        tostring(ns.DataMeta.build), tostring(ns.DataMeta.questie)))
    add("- Charakter: " .. CharLine())
    add("- Andere Addons: " .. OtherAddons())
    add("- Zeitpunkt: " .. date("%Y-%m-%d %H:%M:%S"))
    add(string.format("- Bedienung: %d Klicks, %d Tooltips überfahren", run.clicks, run.hovers))

    add("")
    add("## Fehler (" .. fail .. ")")
    if fail == 0 then add("- keine") end
    for _, c in ipairs(run.checks) do
        if not c.ok then add("- [" .. c.area .. "] " .. c.name .. (c.detail and (" — " .. c.detail) or "")) end
    end

    add("")
    add("## Lua-Fehler (" .. #run.errors .. ")")
    if #run.errors == 0 then add("- keine") end
    for _, e in ipairs(run.errors) do
        add(string.format("- %s%d×, Schritt „%s“:", e.own and "" or "[fremdes Addon] ", e.count, e.where))
        add("  ```")
        add("  " .. e.msg)
        for line in e.stack:gmatch("[^\n]+") do add("  " .. line) end
        add("  ```")
    end

    add("")
    add("## Warnungen (" .. #run.warnings .. ")")
    if #run.warnings == 0 then add("- keine") end
    for _, w in ipairs(run.warnings) do add("- " .. w) end

    add("")
    add("## Übersprungen (" .. #run.skipped .. ")")
    if #run.skipped == 0 then add("- nichts") end
    for _, s in ipairs(run.skipped) do add("- " .. s) end

    add("")
    add("## Abgefangene Aktionen (nicht ausgeführt, nur gezählt)")
    local ic = {}
    for k, v in pairs(run.intercepted) do ic[#ic + 1] = k .. " ×" .. v end
    table.sort(ic)
    add(#ic > 0 and ("- " .. table.concat(ic, " · ")) or "- keine")

    add("")
    add("## Leistung")
    if #run.perf > 0 then
        local sum, maxv, maxn = 0, 0, ""
        for _, e in ipairs(run.perf) do sum = sum + e[2]; if e[2] > maxv then maxv, maxn = e[2], e[1] end end
        add(string.format("- Panel-Refresh: Schnitt %.1f ms, langsamster %.1f ms (%s)", sum / #run.perf, maxv, maxn))
    end
    add(run.memory and string.format("- Speicher Addon: %.0f KB", run.memory) or "- Speicher: unbekannt")

    add("")
    add("## Bereiche")
    for _, a in ipairs(run.areaOrder) do
        local s = run.areas[a]
        add(string.format("- %s: %d/%d%s", a, s.ok, s.ok + s.fail, s.fail > 0 and " ❌" or ""))
    end

    if #run.notes > 0 then
        add("")
        add("## Notizen")
        for _, n in ipairs(run.notes) do add("- " .. n) end
    end

    add("")
    add("## Alle Prüfungen")
    for _, c in ipairs(run.checks) do
        add((c.ok and "OK   " or "FAIL ") .. "[" .. c.area .. "] " .. c.name .. (c.detail and (" — " .. c.detail) or ""))
    end
    add("")
    add("_Ende des Berichts. Bitte diesen ganzen Text an Claude geben._")

    return table.concat(L, "\n"), { date = date("%Y-%m-%d %H:%M"), verdict = verdict, ok = ok, fail = fail,
        errors = #run.errors, own = own, version = AddonVersion(), flavor = ns.Flavor, secs = math.floor(secs * 10 + 0.5) / 10 }
end

---------------------------------------------------------------------------
-- Berichtsfenster (zum Kopieren)
---------------------------------------------------------------------------
local function ShowReport(text)
    if not text then ns.Print("Noch kein Autotest-Bericht vorhanden. Starten mit /ps autotest"); return end
    if not reportWin then
        reportWin = CreateFrame("Frame", "ProfessionSentinelAutoTestReport", UIParent, "ButtonFrameTemplate")
        reportWin:SetSize(640, 560)
        reportWin:SetPoint("CENTER")
        reportWin:SetFrameStrata("DIALOG")
        reportWin:SetMovable(true)
        reportWin:EnableMouse(true)
        reportWin:RegisterForDrag("LeftButton")
        reportWin:SetScript("OnDragStart", reportWin.StartMoving)
        reportWin:SetScript("OnDragStop", reportWin.StopMovingOrSizing)
        reportWin:SetClampedToScreen(true)
        if ButtonFrameTemplate_HidePortrait then ButtonFrameTemplate_HidePortrait(reportWin) end
        if ButtonFrameTemplate_HideButtonBar then ButtonFrameTemplate_HideButtonBar(reportWin) end
        if reportWin.Inset then reportWin.Inset:Hide() end
        reportWin:SetTitle("Autotest-Bericht für Claude")
        tinsert(UISpecialFrames, "ProfessionSentinelAutoTestReport")

        local hint = reportWin:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        hint:SetPoint("TOPLEFT", 16, -30)
        hint:SetPoint("RIGHT", -16, 0)
        hint:SetJustifyH("LEFT")
        hint:SetText("Strg+A, dann Strg+C – und im Chat mit Claude einfügen. Nach /reload liegt der Bericht auch in "
            .. "WTF\\Account\\<Konto>\\SavedVariables\\ProfessionSentinel.lua (autotest.last).")

        local sf = CreateFrame("ScrollFrame", "ProfessionSentinelAutoTestScroll", reportWin, "UIPanelScrollFrameTemplate")
        sf:SetPoint("TOPLEFT", 14, -62)
        sf:SetPoint("BOTTOMRIGHT", -32, 44)
        local eb = CreateFrame("EditBox", nil, sf)
        eb:SetMultiLine(true)
        eb:SetAutoFocus(false)
        eb:SetFontObject(ChatFontNormal or GameFontHighlightSmall)
        eb:SetWidth(580)
        eb:SetScript("OnEscapePressed", function() reportWin:Hide() end)
        eb:SetScript("OnTextChanged", function(self, user)
            if user then self:SetText(reportWin.text or "") end      -- nur lesen
        end)
        sf:SetScrollChild(eb)
        reportWin.eb = eb

        local sel = CreateFrame("Button", nil, reportWin, "UIPanelButtonTemplate")
        sel:SetSize(160, 22)
        sel:SetPoint("BOTTOMLEFT", 16, 14)
        sel:SetText("Alles markieren")
        sel:SetScript("OnClick", function() eb:SetFocus(); eb:HighlightText() end)
        local again = CreateFrame("Button", nil, reportWin, "UIPanelButtonTemplate")
        again:SetSize(160, 22)
        again:SetPoint("LEFT", sel, "RIGHT", 10, 0)
        again:SetText("Test erneut starten")
        again:SetScript("OnClick", function() reportWin:Hide(); AT:Start() end)
        local close = CreateFrame("Button", nil, reportWin, "UIPanelButtonTemplate")
        close:SetSize(120, 22)
        close:SetPoint("BOTTOMRIGHT", -16, 14)
        close:SetText(CLOSE or "Schließen")
        close:SetScript("OnClick", function() reportWin:Hide() end)
    end
    reportWin.text = text
    reportWin.eb:SetText(text)
    reportWin.eb:SetCursorPosition(0)
    reportWin:Show()
    reportWin.eb:SetFocus()
    reportWin.eb:HighlightText()
end

---------------------------------------------------------------------------
-- Ablauf
---------------------------------------------------------------------------
local origHandler
local events = CreateFrame("Frame")

local function Finish()
    if not run or run.done then return end
    run.done = true
    run.area = "Ende"
    SandboxOff()
    local okRestore, err = pcall(RestoreState)
    if not okRestore then LuaError(err, debugstack and debugstack() or "", "Wiederherstellen") end
    local same, key = StateUnchanged()
    Check("Einstellungen und Simulation exakt wiederhergestellt", okRestore and same, key and ("abweichend: " .. key) or nil)
    if origHandler then seterrorhandler(origHandler); origHandler = nil end
    events:UnregisterAllEvents()

    if run.noGroups then
        Note(run.noGroups .. " Ansichten ohne Gruppe mit Inhalt (nichts zum Auf-/Zuklappen, z. B. Rangliste ohne Berufsstufe)")
    end
    local text, summary = BuildReport()
    ns.db.autotest = ns.db.autotest or {}
    ns.db.autotest.last = text
    ns.db.autotest.history = ns.db.autotest.history or {}
    table.insert(ns.db.autotest.history, 1, summary)
    while #ns.db.autotest.history > HISTORY do table.remove(ns.db.autotest.history) end

    local col = summary.verdict == "BESTANDEN" and "40c040" or "ff4040"
    ns.Print(string.format("Autotest |cff%s%s|r: %d/%d OK, %d Fehler, %d Lua-Fehler (%.1f s). Bericht: /ps autotest bericht",
        col, summary.verdict, summary.ok, summary.ok + summary.fail, summary.fail, summary.errors, summary.secs))
    run = nil
    ShowReport(text)
end

local function DoStep()
    if not run or run.done then return end
    if run.aborted then Finish(); return end
    qi = qi + 1
    local s = queue[qi]
    if not s then Finish(); return end
    run.area, run.step = s.area, s.area .. " / " .. s.name
    local ok, err = xpcall(s.fn, function(e) return { e = e, stack = debugstack and debugstack(2, 12, 0) or "" } end)
    if not ok then
        LuaError(type(err) == "table" and err.e or err, type(err) == "table" and err.stack or "", run.step)
        Check("Schritt „" .. s.name .. "“ ohne Absturz", false, type(err) == "table" and tostring(err.e) or tostring(err))
    end
    if qi % 10 == 0 or qi == #queue then
        ns.Print(string.format("Autotest: Schritt %d/%d – %s", qi, #queue, run.step))
    end
end

-- Trampolin: funktioniert mit echtem C_Timer (verzögert) und mit sofort ausführenden Test-Attrappen
local inTick, again = false, false
local function Tick()
    if inTick then again = true; return end
    inTick = true
    repeat
        again = false
        DoStep()
        if run and not run.done then C_Timer.After(STEP_DELAY, Tick) end
    until not again
    inTick = false
end

function AT:Start()
    if run then ns.Print("Autotest läuft schon (Schritt " .. qi .. "/" .. #queue .. "). Abbrechen: /ps autotest stop"); return end
    if not ns.IsDev() then return end
    if InCombatLockdown and InCombatLockdown() then ns.Print("Autotest nicht im Kampf – danach erneut /ps autotest."); return end
    if not ns.UI or not ns.db then ns.Print("Addon nicht vollständig geladen."); return end
    run = { t0 = Now(), checks = {}, areas = {}, areaOrder = {}, errors = {}, warnings = {}, skipped = {}, notes = {},
        intercepted = {}, perf = {}, clicks = 0, hovers = 0, saved = {} }
    SaveState()
    SandboxOn()
    origHandler = geterrorhandler and geterrorhandler()
    if seterrorhandler then
        seterrorhandler(function(msg, ...)
            LuaError(msg, debugstack and debugstack(3, 12, 0) or "", run and run.step)
            if origHandler then return origHandler(msg, ...) end
        end)
    end
    events:RegisterEvent("PLAYER_REGEN_DISABLED")
    events:SetScript("OnEvent", function()
        if run then run.aborted = "Kampf hat begonnen – Test gestoppt, Einstellungen wiederhergestellt" end
    end)
    BuildQueue()
    ns.Print(string.format("Autotest startet: %d Schritte. Bitte nichts anklicken, bis der Bericht erscheint. Abbrechen: /ps autotest stop", #queue))
    Tick()
end

function AT:Stop()
    if not run then ns.Print("Kein Autotest aktiv."); return end
    run.aborted = "von Hand gestoppt (/ps autotest stop) bei Schritt " .. qi .. "/" .. #queue
    if not inTick then Finish() end
end

function AT:IsRunning() return run ~= nil end

function AT:ShowLast()
    ShowReport(ns.db and ns.db.autotest and ns.db.autotest.last)
end

function AT:History()
    local h = ns.db and ns.db.autotest and ns.db.autotest.history
    if not h or #h == 0 then ns.Print("Noch keine Autotest-Läufe."); return end
    for i, e in ipairs(h) do
        ns.Print(string.format("%d. %s · %s %s · %s · %d/%d OK · %d Lua-Fehler · %.1f s", i, e.date, tostring(e.version),
            tostring(e.flavor), e.verdict, e.ok, e.ok + e.fail, e.errors or 0, e.secs or 0))
    end
end

-- /ps autotest [stop | bericht | verlauf]
function AT:Command(arg)
    arg = (arg or ""):lower()
    if arg == "stop" then self:Stop()
    elseif arg == "bericht" or arg == "report" then self:ShowLast()
    elseif arg == "verlauf" or arg == "history" then self:History()
    else self:Start() end
end
