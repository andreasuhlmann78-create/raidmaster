-- ============================================================
-- AHSentinel 0.59.13 - Tab "Einkauf" (wie der Kaufen-Reiter des Auktionshauses)
--   oben:   Suchfeld, Stufe von/bis, Seltenheit, Suchen
--   links:  Kategorien
--   rechts: Ergebnisliste -> Klick auf ein Item zeigt alle Angebote
--           Waren: Menge wählen, Preis holen, bestätigen
--           Einzelangebote: Sofortkauf (2 Klicks) oder Gebot
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C

local QCOLOR = { [0] = "9d9d9d", "ffffff", "1eff00", "0070dd", "a335ee", "ff8000" }

local function Colored(name, quality)
    if quality and QCOLOR[quality] then return "|cff" .. QCOLOR[quality] .. (name or "?") .. "|r" end
    return name or "?"
end

local function TimeLeft(sec)
    if not sec then return "-" end
    if sec < 1800 then return L["< 30 Min."] end
    if sec < 7200 then return L["< 2 Std."] end
    if sec < 43200 then return L["< 12 Std."] end
    return L["> 12 Std."]
end

local function Num(edit)
    local n = tonumber((string.gsub(edit:GetText() or "", ",", ".")))
    if n then return math.floor(n) end
    return nil
end

local function BuildBuy(parent)
    local p = CreateFrame("Frame", nil, parent)
    local B = A.Buy
    p.cat = "all"

    local function setMessage(ok, msg)
        if not msg then return end
        p.message:SetText(msg)
        p.message:SetTextColor(unpack(ok and C.textDim or C.red))
    end

    -- ================= Suchzeile =================
    p.search = UI:EditBox(p, 210, 24, L["Suchen: Item-Name"])
    p.search:SetPoint("TOPLEFT", 0, 0)
    p.search.tooltipText = L["Name wie im Auktionshaus (Sprache deines Spiels), Teil reicht.\nShift-Klick auf ein Item trägt es ein."]
    UI:AttachItemSearch(p.search, { onPick = function(id) p:DoSearch(A:GetClientItemName(id)) end })

    p.lvlMin = UI:EditBox(p, 46, 24, L["St. ab"])
    p.lvlMin:SetPoint("LEFT", p.search, "RIGHT", 6, 0)
    p.lvlMax = UI:EditBox(p, 46, 24, L["St. bis"])
    p.lvlMax:SetPoint("LEFT", p.lvlMin, "RIGHT", 4, 0)

    -- Itemlevel: filtert sofort, ohne neue Suche beim Server
    p.ilvlMin = UI:EditBox(p, 50, 24, L["iLvl ab"])
    p.ilvlMin:SetPoint("LEFT", p.lvlMax, "RIGHT", 6, 0)
    p.ilvlMax = UI:EditBox(p, 50, 24, L["iLvl bis"])
    p.ilvlMax:SetPoint("LEFT", p.ilvlMin, "RIGHT", 4, 0)
    for _, e in ipairs({ p.ilvlMin, p.ilvlMax }) do
        e.tooltipText = L["Gegenstandsstufe (iLvl): zeigt nur Items in diesem Bereich.\nWirkt sofort auf die Ergebnisse, ohne neue Suche."]
        e:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
            GameTooltip:SetText(self.tooltipText, 1, 1, 1, 1, true)
            GameTooltip:Show()
        end)
        e:SetScript("OnLeave", function() GameTooltip:Hide() end)
        e:SetScript("OnTextChanged", function() if p.Refresh then p:Refresh() end end)
    end

    p.qualityBtn = UI:QualityPicker(p, 140)
    p.qualityBtn:SetPoint("LEFT", p.ilvlMax, "RIGHT", 6, 0)

    p.searchBtn = UI:Button(p, L["Suchen"], 110, 24, function() p:DoSearch(nil, true) end, "primary")
    p.searchBtn:SetPoint("LEFT", p.qualityBtn, "RIGHT", 6, 0)

    p.resetBtn = UI:Button(p, "X", 24, 24, function()
        for _, e in ipairs({ p.search, p.lvlMin, p.lvlMax, p.ilvlMin, p.ilvlMax }) do e:SetText(""); e:ClearFocus(); e:UpdatePlaceholder() end
        p.qualityBtn:Reset()
        p.cat = "all"
        p:Refresh()
    end)
    p.resetBtn:SetPoint("LEFT", p.searchBtn, "RIGHT", 4, 0)
    p.resetBtn.tooltip = L["Suche und Filter zurücksetzen"]

    -- Favoriten: gespeicherte Suchen
    local K = A.Comfort
    p.favBtn = UI:Button(p, L["Favoriten"], 86, 24, function()
        if p.favMenu:IsShown() then p.favMenu:Hide() else p:RefreshFavorites(); p.favMenu:Show() end
    end)
    p.favBtn:SetPoint("LEFT", p.resetBtn, "RIGHT", 6, 0)
    p.favBtn.tooltip = L["Gespeicherte Suchen: ein Klick sucht wieder.\nRechtsklick auf einen Favoriten löscht ihn."]
    local menu = CreateFrame("Frame", nil, p)
    menu:SetFrameStrata("FULLSCREEN_DIALOG")
    menu:SetPoint("TOPRIGHT", p.favBtn, "BOTTOMRIGHT", 0, -2)
    menu:SetSize(300, 40)
    menu:EnableMouse(true)
    UI:Box(menu, { C.bg[1], C.bg[2], C.bg[3], 1 }, C.frameEdge or C.border)
    menu:Hide()
    p.favMenu = menu
    menu.add = UI:Button(menu, L["+ Aktuelle Suche speichern"], 288, 22, function()
        local q = B.lastQuery and {} or nil
        if q then
            for k, v in pairs(B.lastQuery) do q[k] = v end
            q.minIlvl, q.maxIlvl = p:IlvlRange()
        end
        local ok, msg = K:AddFavorite(q)
        setMessage(ok, msg)
        p:RefreshFavorites()
    end, "primary")
    menu.add:SetPoint("TOPLEFT", 6, -6)
    menu.rows = {}
    function p:RefreshFavorites()
        local list = K.FavDB()
        for i = 1, K.MAX_FAVS do
            local b = menu.rows[i]
            if not b and list[i] then
                b = UI:Button(menu, "", 288, 22, function(self, button)
                    local f = K.FavDB()[self.index]
                    if not f then return end
                    if button == "RightButton" then
                        K:RemoveFavorite(self.index)
                        p:RefreshFavorites()
                        return
                    end
                    menu:Hide()
                    p:ApplyFavorite(f)
                end)
                if b.RegisterForClicks then b:RegisterForClicks("LeftButtonUp", "RightButtonUp") end
                b:SetPoint("TOPLEFT", 6, -6 - i * 24)
                b.index = i
                b.tooltip = L["Klick: suchen   |   Rechtsklick: löschen"]
                menu.rows[i] = b
            end
            if b then
                if list[i] then b:SetText(list[i].label or "?"); b:Show() else b:Hide() end
            end
        end
        menu:SetHeight(36 + #list * 24)
    end
    function p:ApplyFavorite(f)
        p.search:SetText(f.text or ""); p.search:UpdatePlaceholder()
        p.lvlMin:SetText(f.minLevel and tostring(f.minLevel) or ""); p.lvlMin:UpdatePlaceholder()
        p.lvlMax:SetText(f.maxLevel and tostring(f.maxLevel) or ""); p.lvlMax:UpdatePlaceholder()
        p.ilvlMin:SetText(f.minIlvl and tostring(f.minIlvl) or ""); p.ilvlMin:UpdatePlaceholder()
        p.ilvlMax:SetText(f.maxIlvl and tostring(f.maxIlvl) or ""); p.ilvlMax:UpdatePlaceholder()
        p.qualityBtn:SetSet(f.quals)
        p.cat = f.cat or "all"
        p:DoSearch(nil, true)
    end

    for _, e in ipairs({ p.search, p.lvlMin, p.lvlMax }) do e:SetScript("OnEnterPressed", function() p:DoSearch(nil, true) end) end
    -- iLvl: Enter sucht nur, wenn noch nichts gesucht wurde (sonst filtert es nur)
    for _, e in ipairs({ p.ilvlMin, p.ilvlMax }) do
        e:SetScript("OnEnterPressed", function(self)
            self:ClearFocus()
            if not B.lastQuery then p:DoSearch(nil, true) else p:Refresh() end
        end)
    end
    UI:ChainEdits({ p.search, p.lvlMin, p.lvlMax, p.ilvlMin, p.ilvlMax })

    function p:IlvlRange()
        local a, b = Num(self.ilvlMin), Num(self.ilvlMax)
        if a and b and a > b then a, b = b, a end
        return a, b
    end

    function p:DoSearch(text, force)
        if text then p.search:SetText(text); p.search:UpdatePlaceholder() end
        UI:HideSuggest()
        p.search:ClearFocus()
        local q = {
            text = p.search:GetText() or "", cat = p.cat,
            minLevel = Num(p.lvlMin), maxLevel = Num(p.lvlMax),
            quals = p.qualityBtn:GetSet(),
        }
        q.minIlvl, q.maxIlvl = p:IlvlRange()
        local ok, msg = B:Search(q, force)
        setMessage(ok, msg)
        p:Refresh()
    end

    -- ================= Links: Kategorien =================
    p.cats = UI:Table(p, {
        columns = { { key = "label", title = L["Kategorien"], width = 150 } },
        rows = 17,
        rowHeight = 22,
        idKey = "key",
        noMenu = true,
        itemTooltip = false,
        cell = function(c, key)
            local text = (c.level and "   " or "") .. L[c.label]
            if c.key == p.cat then return "|cffffd100" .. text .. "|r" end
            return text
        end,
        onClick = function(c)
            p.cat = c.key
            p:DoSearch()
        end,
        noCount = true,
    })
    p.cats:FillColumn(0, -34, 176, 24)
    p.cats:SetData(B.CATS)

    -- ================= Rechts: Ergebnisse =================
    local right = CreateFrame("Frame", nil, p)
    right:SetPoint("TOPLEFT", 190, -34)
    right:SetPoint("BOTTOMRIGHT", 0, 0)
    p.right = right

    p.results = UI:Table(right, {
        columns = {
            { key = "name", title = L["Item"], width = 270 },
            { key = "req", title = L["Stufe"], width = 46, align = "RIGHT" },
            { key = "ilvl", title = "iLvl", width = 46, align = "RIGHT" },
            { key = "qty", title = L["Verfügbar"], width = 76, align = "RIGHT" },
            { key = "price", title = L["Preis/Stück"], width = 122, align = "RIGHT" },
            { key = "pct", title = L["% Markt"], width = 60, align = "RIGHT",
              tooltip = L["Preis in Prozent vom Marktwert (Median 14 Tage)"] },
        },
        rows = 17,
        rowHeight = 22,
        sortKey = "price",
        cell = function(it, key)
            if key == "name" then return Colored(UI.ItemName(it), it.quality) end
            if key == "req" then return (it.req and it.req > 0) and tostring(it.req) or "" end
            if key == "ilvl" then
                local il = it.ilvl or UI:AnyItemLevel(it.itemID)
                if not il then UI:RequestItemInfo(it.itemID) end
                return il and tostring(il) or ""
            end
            if key == "qty" then
                if it.fromScan then return "|cff8a8a8a~" .. tostring(it.qty or 0) .. "|r" end
                return tostring(it.qty or 0)
            end
            if key == "price" then
                if it.fromScan then return "|cff8a8a8a" .. A:FormatMoney(it.price):gsub("|r", "|r|cff8a8a8a") .. "|r" end
                return A:FormatMoney(it.price)
            end
            if key == "pct" then return A:FormatMarketPercent(it.pct) end
        end,
        sortValue = function(it, key)
            if key == "name" then return string.lower(UI.ItemName(it)) end
            if key == "ilvl" then return it.ilvl or UI:AnyItemLevel(it.itemID) end
            return it[key]
        end,
        onClick = function(it)
            local ok, msg = B:Open(it.itemKey, it.name)
            if not ok then setMessage(false, msg) end
            p:Refresh()
        end,
        emptyText = L["Suchbegriff eingeben oder links eine Kategorie wählen."],
    })
    p.results:Fill(0, 0, 0, 24)

    -- ================= Rechts: Angebote eines Items =================
    local det = CreateFrame("Frame", nil, right)
    det:SetAllPoints()
    det:Hide()
    p.det = det

    p.backBtn = UI:Button(det, L["< Zurück"], 90, 24, function() B:Back(); p:Refresh() end)
    p.backBtn:SetPoint("TOPLEFT", 0, 0)
    p.itemName = UI:Label(det, "", "GameFontNormalLarge", C.accent)
    p.itemName:SetPoint("LEFT", p.backBtn, "RIGHT", 10, 0)
    p.itemName:SetWidth(300)
    if p.itemName.SetWordWrap then p.itemName:SetWordWrap(false) end

    p.chartBtn = UI:Button(det, L["Preisverlauf"], 100, 24, function()
        if B.detail then UI:OpenChart(B.detail.itemID) end
    end)
    p.chartBtn:SetPoint("TOPRIGHT", 0, 0)
    p.snipeBtn = UI:Button(det, L["Sniper-Ziel"], 100, 24, function()
        if B.detail then UI:OpenSniperFor(B.detail.itemID) end
    end)
    p.snipeBtn:SetPoint("RIGHT", p.chartBtn, "LEFT", -4, 0)
    p.snipeBtn.tooltip = L["Als Sniper-Ziel übernehmen"]
    p.refreshBtn = UI:Button(det, L["Aktualisieren"], 110, 24, function() B:Refresh(); p:Refresh() end)
    p.refreshBtn:SetPoint("RIGHT", p.snipeBtn, "LEFT", -4, 0)

    p.itemInfo = UI:Label(det, "", "GameFontHighlightSmall", C.textDim)
    p.itemInfo:SetPoint("TOPLEFT", 0, -32)
    p.itemInfo:SetWidth(730)

    -- Waren: Preisstufen
    p.tiers = UI:Table(det, {
        columns = {
            { key = "price", title = L["Preis/Stück"], width = 120, align = "RIGHT" },
            { key = "qty", title = L["Verfügbar"], width = 80, align = "RIGHT" },
            { key = "pct", title = L["% Markt"], width = 60, align = "RIGHT" },
            { key = "status", title = "", width = 100 },
        },
        rows = 15,
        rowHeight = 22,
        idKey = "rowID",
        noMenu = true,
        itemTooltip = false,
        cell = function(l, key)
            if key == "price" then return A:FormatMoney(l.price) end
            if key == "qty" then return tostring(l.qty) end
            if key == "pct" then return A:FormatMarketPercent(B.detail and A:GetMarketPercent(B.detail.itemID, l.price)) end
            if key == "status" then
                if l.own then return "|cff00d1d1" .. L["eigenes"] .. "|r" end
                if l.bait then return "|cffff9933" .. L["Lockangebot"] .. "|r" end
                if l.inQuote then return "|cff33dd55" .. L["im Kauf"] .. "|r" end
                return ""
            end
        end,
        onClick = function(l)
            B:QuantityUpTo(l)
            p:Refresh()
        end,
        emptyText = L["Keine Angebote."],
    })
    p.tiers:Fill(0, -52, -344, 24)

    -- Waren: Kaufbereich
    local box = CreateFrame("Frame", nil, det)
    box:SetPoint("TOPRIGHT", 0, -52)
    box:SetSize(330, 360)
    UI:Box(box, C.panel, C.border)
    p.box = box
    local bt = UI:Label(box, L["Kaufen"], "GameFontNormalLarge", C.text)
    bt:SetPoint("TOPLEFT", 14, -12)
    local qLabel = UI:Label(box, L["Menge:"], "GameFontHighlightSmall", C.textDim)
    qLabel:SetPoint("TOPLEFT", 14, -50)
    p.qty = UI:EditBox(box, 80, 24, "1")
    p.qty:SetPoint("TOPLEFT", 110, -44)
    if p.qty.SetNumeric then p.qty:SetNumeric(true) end
    p.qty:SetScript("OnTextChanged", function(self, userInput)
        if userInput then B:SetQuantity(Num(self) or 1); p:RefreshBox(true) end
    end)
    p.qty:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    p.maxBtn = UI:Button(box, L["Max"], 50, 24, function()
        B:SetQuantity(B:Available())
        p:Refresh()
    end)
    p.maxBtn:SetPoint("LEFT", p.qty, "RIGHT", 6, 0)
    p.maxBtn.tooltip = L["Alle verfügbaren Stück"]

    local function row(label, y)
        local l = UI:Label(box, label, "GameFontHighlightSmall", C.textDim)
        l:SetPoint("TOPLEFT", 14, y)
        local v = UI:Label(box, "-", "GameFontHighlight", C.text)
        v:SetPoint("TOPRIGHT", -14, y)
        v:SetJustifyH("RIGHT")
        return v
    end
    p.vUnit = row(L["Stückpreis (Ø)"], -86)
    p.vTop = row(L["Höchster Stückpreis"], -110)
    p.vTotal = row(L["Gesamt"], -140)
    p.boxNote = UI:Label(box, "", "GameFontHighlightSmall", C.textDim)
    p.boxNote:SetPoint("TOPLEFT", 14, -166)
    p.boxNote:SetWidth(300)
    p.boxNote:SetJustifyH("LEFT")

    p.buyBtn = UI:Button(box, L["Jetzt kaufen"], 300, 30, function()
        local ok, msg
        if B.pending and B.pending.state == "ready" then
            ok, msg = B:ConfirmCommodity()
        elseif not B.pending then
            ok, msg = B:StartCommodity()
        end
        setMessage(ok, msg)
        p:Refresh()
    end, "primary")
    p.buyBtn:SetPoint("TOPLEFT", 14, -240)
    p.cancelBtn = UI:Button(box, L["Abbrechen"], 300, 24, function()
        B:CancelPending()
        p:Refresh()
    end)
    p.cancelBtn:SetPoint("TOPLEFT", p.buyBtn, "BOTTOMLEFT", 0, -6)

    -- Einzelangebote
    p.items = UI:Table(det, {
        columns = {
            { key = "buyout", title = L["Sofortkauf"], width = 116, align = "RIGHT" },
            { key = "bid", title = L["Gebot"], width = 104, align = "RIGHT" },
            { key = "ilvl", title = "iLvl", width = 40, align = "RIGHT" },
            { key = "qty", title = L["Menge"], width = 46, align = "RIGHT" },
            { key = "time", title = L["Restzeit"], width = 70 },
            { key = "status", title = "", width = 64 },
        },
        rows = 15,
        rowHeight = 22,
        idKey = "rowID",
        noMenu = true,
        itemTooltip = false,
        cell = function(l, key)
            if key == "buyout" then return l.buyout and A:FormatMoney(l.buyout) or "|cff777777-|r" end
            if key == "bid" then return A:FormatMoney(l.bid and l.bid > 0 and l.bid or l.minBid) end
            if key == "ilvl" then
                local il = l.ilvl or (B.detail and UI:AnyItemLevel(B.detail.itemID))
                return il and tostring(il) or ""
            end
            if key == "qty" then return tostring(l.qty) end
            if key == "time" then return TimeLeft(l.timeLeft) end
            if key == "status" then
                if l.own then return "|cff00d1d1" .. L["eigenes"] .. "|r" end
                if l.used then return "|cff00d1d1" .. L["gekauft"] .. "|r" end
                return ""
            end
        end,
        onClick = function(l)
            p.selListing = l
            p.confirmBuy = nil
            p.bid:SetCopper(B:MinBid(l))
            p.bidFor = l
            p:Refresh()
        end,
        emptyText = L["Keine Angebote."],
    })
    p.items:Fill(0, -52, -264, 24)

    -- Stapelware (altes Auktionshaus): Angebote mit gleichem Stückpreis als EINE Zeile mit der Summe.
    -- Klick wählt eine Zeile, Shift+Klick wählt mehrere; gekauft wird die ganze Auswahl.
    p.stackSel = { itemID = nil, units = {} }
    p.stacks = UI:Table(det, {
        columns = {
            { key = "unit", title = L["Stückpreis"], width = 104, align = "RIGHT" },
            { key = "total", title = L["Gesamtpreis"], width = 122, align = "RIGHT" },
            { key = "qty", title = L["Menge"], width = 58, align = "RIGHT" },
            { key = "count", title = L["Angebote"], width = 64, align = "RIGHT" },
            { key = "status", title = "", width = 92 },
        },
        rows = 15,
        rowHeight = 22,
        idKey = "unit",
        noMenu = true,
        itemTooltip = false,
        sortKey = "unit", sortAsc = true,
        cell = function(g, key)
            if key == "unit" then return A:FormatMoney(g.unit) end
            if key == "total" then return A:FormatMoney(g.total) end
            if key == "qty" then return tostring(g.qty) end
            if key == "count" then return tostring(g.count) end
            if key == "status" then
                if g.own then return "|cff00d1d1" .. L["eigenes"] .. "|r" end
                if g.left == 0 then return "|cff00d1d1" .. L["gekauft"] .. "|r" end
                if p.stackSel.units[g.unit] then return "|cff33dd55" .. L["ausgewählt"] .. "|r" end
                return ""
            end
        end,
        sortValue = function(g, key) return g[key] end,
        onClick = function(g)
            if g.own then return end
            local sel = p.stackSel.units
            if IsShiftKeyDown and IsShiftKeyDown() then
                sel[g.unit] = (not sel[g.unit]) or nil          -- dazu oder wieder weg
            else
                wipe(sel); sel[g.unit] = true
            end
            p.confirmStacks = nil
            p:Refresh()
        end,
        emptyText = L["Keine Angebote."],
    })
    p.stacks:Fill(0, -52, -264, 24)
    p.stacks:Hide()

    local ibox = CreateFrame("Frame", nil, det)
    ibox:SetPoint("TOPRIGHT", 0, -52)
    ibox:SetSize(250, 360)
    UI:Box(ibox, C.panel, C.border)
    p.ibox = ibox
    local it = UI:Label(ibox, L["Gewähltes Angebot"], "GameFontNormalLarge", C.text)
    it:SetPoint("TOPLEFT", 14, -12)
    p.iboxTitle = it
    p.showSingles = false
    p.stackToggle = UI:Button(ibox, "", 222, 22, function()
        p.showSingles = not p.showSingles
        p.confirmStacks = nil
        p:Refresh()
    end)
    p.stackToggle:SetPoint("TOPLEFT", 14, -300)
    p.stackToggle.tooltip = L["Stapelware: Angebote mit gleichem Stückpreis zusammengefasst (Summe) oder jedes Angebot einzeln (dort auch Bieten)."]
    p.selInfo = UI:Label(ibox, "", "GameFontHighlightSmall", C.text)
    p.selInfo:SetPoint("TOPLEFT", 14, -40)
    p.selInfo:SetWidth(222)
    p.selInfo:SetJustifyH("LEFT")

    p.buyoutBtn = UI:Button(ibox, L["Sofortkauf"], 222, 30, function()
        if p.stackMode then
            local ok, msg = p:BuyNextStack()
            setMessage(ok, msg)
            p:Refresh()
            return
        end
        local l = p.selListing
        if not l then setMessage(false, L["Erst ein Angebot anklicken."]) return end
        if p.confirmBuy ~= l then
            p.confirmBuy = l          -- wie das Auktionshaus: Kauf erst nach Bestätigung
            p:Refresh()
            return
        end
        p.confirmBuy = nil
        local ok, msg = B:BuyItem(l)
        setMessage(ok, msg)
        p:Refresh()
    end, "primary")
    p.buyoutBtn:SetPoint("TOPLEFT", 14, -130)

    local bidLabel = UI:Label(ibox, L["Dein Gebot:"], "GameFontHighlightSmall", C.textDim)
    bidLabel:SetPoint("TOPLEFT", 14, -182)
    p.bidLabel = bidLabel
    p.bid = UI:MoneyInput(ibox)
    p.bid:SetPoint("TOPLEFT", 14, -200)
    p.bidBtn = UI:Button(ibox, L["Bieten"], 222, 26, function()
        if not p.selListing then setMessage(false, L["Erst ein Angebot anklicken."]) return end
        local ok, msg = B:PlaceBid(p.selListing, p.bid:GetCopper())
        setMessage(ok, msg)
        p:Refresh()
    end)
    p.bidBtn:SetPoint("TOPLEFT", 14, -234)
    p.bidBtn.tooltip = L["Gebot abgeben. Ist es so hoch wie der Sofortkauf-Preis, wird sofort gekauft."]

    -- ================= Statuszeile =================
    p.message = UI:Label(p, "", "GameFontHighlightSmall", C.textDim)
    p.message:SetPoint("BOTTOMLEFT", 0, 4)
    p.message:SetWidth(900)
    p.message:SetJustifyH("LEFT")

    -- Angebote mit gleichem Stückpreis zusammenfassen (nur fremde mit Sofortkauf)
    function p:StackGroups(listings)
        local by, out = {}, {}
        for _, l in ipairs(listings) do
            if l.buyout and l.buyout > 0 and (l.qty or 0) > 0 then
                local unit = math.floor(l.buyout / l.qty + 0.5)
                local key = unit .. (l.own and "o" or "")
                local g = by[key]
                if not g then
                    g = { unit = unit, own = l.own or nil, qty = 0, total = 0, count = 0, left = 0, members = {} }
                    by[key] = g
                    table.insert(out, g)
                end
                g.qty = g.qty + l.qty
                g.total = g.total + l.buyout
                g.count = g.count + 1
                if not l.used then g.left = g.left + 1 end
                table.insert(g.members, l)
            end
        end
        return out
    end

    -- was von der Auswahl noch zu kaufen ist: Stück, Gold, Angebote
    function p:StackRemaining(groups)
        local qty, cost, n = 0, 0, 0
        for _, g in ipairs(groups) do
            if self.stackSel.units[g.unit] and not g.own then
                for _, l in ipairs(g.members) do
                    if not l.used and not l.own then qty = qty + l.qty; cost = cost + l.buyout; n = n + 1 end
                end
            end
        end
        return qty, cost, n
    end

    -- ein Klick = ein Angebot (WoW verlangt für jeden Kauf einen eigenen Klick).
    -- Erster Klick zeigt die Summe zur Bestätigung, jeder weitere kauft das nächste Angebot der Auswahl.
    function p:BuyNextStack()
        local d = B.detail
        if not d or d.loading then return false, L["Angebote werden geladen ..."] end
        local groups = self:StackGroups(A:NoBait(d.listings))
        local qty, cost, n = self:StackRemaining(groups)
        if n == 0 then return false, L["Erst eine Zeile anklicken (Shift+Klick: mehrere)."] end
        if not self.confirmStacks then
            if GetMoney and GetMoney() < cost then
                return false, string.format(L["Nicht genug Gold: Auswahl kostet %s."], A:FormatMoney(cost))
            end
            self.confirmStacks = true
            return true, string.format(L["%d Stück für zusammen %s - jetzt pro Klick ein Angebot kaufen (%d Klicks)."], qty, A:FormatMoney(cost), n)
        end
        table.sort(groups, function(a, b) return a.unit < b.unit end)
        for _, g in ipairs(groups) do
            if self.stackSel.units[g.unit] and not g.own then
                for _, l in ipairs(g.members) do
                    if not l.used and not l.own then
                        local ok, msg = B:BuyItem(l)
                        if ok then self.stackBought = (self.stackBought or 0) + 1 end
                        return ok, msg
                    end
                end
            end
        end
        return false, L["Auswahl ist gekauft."]
    end

    function p:RefreshBox(keepQtyText)
        local d = B.detail
        if not (d and d.commodity) then return end
        local qty = d.qty or 1
        if not keepQtyText and not self.qty:HasFocus() then self.qty:SetText(tostring(qty)) end
        local total, unit, top, bait = B:Quote(qty)
        -- Zeilen markieren, die in diesem Kauf stecken
        local left = qty
        for _, l in ipairs(d.listings) do
            local avail = math.max(0, l.qty - (l.ownQty or 0))
            l.inQuote = left > 0 and avail > 0
            left = left - avail
        end
        self.tiers:Render()
        local pd = B.pending
        if pd and pd.state == "ready" then
            self.vTotal:SetText(A:FormatMoney(pd.total or pd.expected))
            self.vUnit:SetText(A:FormatMoney(math.floor((pd.total or pd.expected) / math.max(1, pd.qty))))
        else
            self.vUnit:SetText(total and A:FormatMoney(math.floor(unit + 0.5)) or "-")
            self.vTotal:SetText(total and A:FormatMoney(total) or "-")
        end
        self.vTop:SetText(top and A:FormatMoney(top) or "-")
        local note = ""
        if not total then note = "|cffff5544" .. L["So viele sind nicht verfügbar."] .. "|r"
        end
        if pd and pd.state == "ready" and pd.total and pd.expected and pd.total > pd.expected then
            note = "|cffff9933" .. L["Achtung: Preis ist inzwischen höher als angezeigt."] .. "|r"
        end
        self.boxNote:SetText(note)
        if pd and pd.state == "waiting" then
            self.buyBtn:SetText(L["Preis wird geholt ..."])
            self.buyBtn:SetActive(false)
            self.cancelBtn:Show()
        elseif pd and pd.state == "ready" then
            self.buyBtn:SetText(L["Kauf bestätigen: "] .. A:FormatMoney(pd.total or pd.expected))
            self.buyBtn:SetActive(true)
            self.cancelBtn:Show()
        else
            self.buyBtn:SetText(L["Jetzt kaufen"])
            self.buyBtn:SetActive(total ~= nil and A:IsAHOpen())
            self.cancelBtn:Hide()
        end
    end

    function p:Refresh()
        self.cats.selectedID = self.cat
        self.cats:Render()
        if B.message then setMessage(B.messageOK and true or false, B.message); B.message, B.messageOK = nil, nil end

        local d = B.detail
        if not d then
            self.det:Hide()
            self.results:Show()
            self.selListing, self.confirmBuy = nil, nil
            local items = B.results or {}
            local busy = (B.search and B.search.kind == "browse") or (B.wanted and B.wanted.kind == "browse")
            local nScan = B.snapshot and #B.snapshot or 0
            if B.search and B.search.kind == "browse" then
                self.results.empty:SetText(L["Suche läuft ..."])
                local pr = B.search.progress
                local text = L["Suche läuft ..."]
                if pr then text = text .. "  " .. string.format(L["Seite %d von %d"], pr[1], pr[2]) end
                if nScan > 0 then text = text .. "  |  " .. string.format(L["%d Items sofort aus dem letzten Scan (grau = noch nicht bestätigt)"], nScan) end
                setMessage(true, text)
            elseif B.wanted then
                self.results.empty:SetText(B:OthersBusy() or L["Suche läuft ..."])
                if nScan > 0 then
                    setMessage(true, (B:OthersBusy() or L["Suche läuft ..."]) .. "  |  "
                        .. string.format(L["%d Items sofort aus dem letzten Scan (grau = noch nicht bestätigt)"], nScan))
                end
            else
                self.results.empty:SetText(B.lastQuery and L["Keine Angebote gefunden."] or L["Suchbegriff eingeben oder links eine Kategorie wählen."])
            end
            if not busy and self.wasSearching then setMessage(true, " ") end
            self.wasSearching = busy
            -- während der Suche: Live-Treffer + Scan-Daten (sofort da), danach das Ergebnis
            local minIl, maxIl = self:IlvlRange()
            local shown = UI:FilterIlvl(busy and (B.partial or B.snapshot or {}) or items, minIl, maxIl)
            -- nur wenn es überhaupt Treffer gab, die der Filter ausblendet (sonst: erst suchen)
            if (minIl or maxIl) and #shown == 0 and not busy and B.lastQuery and #items > 0 then
                self.results.empty:SetText(L["Keine Items in diesem iLvl-Bereich."])
            end
            self.results:SetData(shown, true)
            self.searchBtn:SetActive(true)        -- neue Suche bricht die laufende ab
            return
        end

        self.results:Hide()
        self.det:Show()
        -- anderes Item (z. B. Alt-Klick, Sniper, Schnäppchen): Auswahl und Gebot vom vorigen nicht übernehmen
        if self.shownDetail ~= d then
            self.shownDetail = d
            self.selListing, self.confirmBuy, self.bidFor = nil, nil, nil
            self.bid:Clear()
            if self.stackSel.itemID ~= d.itemID then
                self.stackSel.itemID = d.itemID
                wipe(self.stackSel.units)
                self.confirmStacks, self.stackBought = nil, nil
            end
        end
        local quality = select(4, pcall(GetItemInfo, d.itemID))
        self.itemName:SetText(Colored(UI.ItemName(d), type(quality) == "number" and quality or nil))
        local mv = A:GetMarketValue(d.itemID)
        local info
        if d.loading then
            info = (B.wanted and B:OthersBusy()) or L["Angebote werden geladen ..."]
        else
            local cheapest
            for _, l in ipairs(d.listings) do
                if l.price and l.price > 0 and not l.own and (not cheapest or l.price < cheapest) then cheapest = l.price end
            end
            info = string.format(L["%d Angebote"], #d.listings)
            if cheapest then info = info .. "   |   " .. L["günstigstes "] .. A:FormatMoney(cheapest) end
            info = info .. "   |   " .. L["Marktwert (Median 14 Tage)"] .. " " .. A:FormatMoney(mv)
            if d.commodity then info = info .. "   |   " .. string.format(L["verfügbar: %d"], B:Available()) end
            if B.search and B.search.kind == "items" then
                -- weitere Seiten kommen noch: deutlich sagen, dass die Liste noch wächst
                info = info .. "   |   |cffffcc33" .. L["lädt weitere Angebote ..."] .. "|r"
            elseif d.time then info = info .. "   |   " .. L["geladen "] .. A:FormatAgo(d.time) end
        end
        self.itemInfo:SetText(info)

        for i, l in ipairs(d.listings) do l.rowID = i end
        if d.commodity then
            self.items:Hide(); self.ibox:Hide(); self.stacks:Hide()
            self.stackMode = false
            self.tiers:Show(); self.box:Show()
            self.tiers:SetData(A:NoBait(d.listings), true)
            self:RefreshBox()
        else
            self.tiers:Hide(); self.box:Hide()
            self.ibox:Show()
            -- Stapelware: zusammengefasst (Standard) oder einzeln
            local stackable = A:IsCommodityItem(d.itemID)
            if not stackable then
                for _, l in ipairs(d.listings) do if (l.qty or 1) > 1 then stackable = true; break end end
            end
            self.stackMode = stackable and not self.showSingles or false
            if stackable then
                self.stackToggle:Show()
                self.stackToggle:SetText(self.showSingles and L["Zusammengefasst anzeigen"] or L["Einzelne Angebote anzeigen"])
            else
                self.stackToggle:Hide()
            end
            local bidShown = not self.stackMode
            self.bid:SetShown(bidShown); self.bidBtn:SetShown(bidShown); self.bidLabel:SetShown(bidShown)
        end
        if not d.commodity and self.stackMode then
            self.items:Hide(); self.stacks:Show()
            self.iboxTitle:SetText(L["Auswahl"])
            local groups = self:StackGroups(A:NoBait(d.listings))
            self.stacks:SetData(groups, true)
            local qty, cost, n = self:StackRemaining(groups)
            local lines = {}
            if n > 0 then
                table.insert(lines, string.format(L["%d Stück in %d Angeboten"], qty, n))
                table.insert(lines, L["Zusammen: "] .. A:FormatMoney(cost))
                table.insert(lines, L["je Stück im Schnitt: "] .. A:FormatMoney(math.floor(cost / math.max(1, qty) + 0.5)))
                if self.stackBought and self.stackBought > 0 then
                    table.insert(lines, string.format(L["gekauft: %d Angebote"], self.stackBought))
                end
            else
                table.insert(lines, L["Zeile anklicken, Shift+Klick wählt mehrere."])
            end
            self.selInfo:SetText(table.concat(lines, "\n"))
            self.buyoutBtn:SetActive(n > 0 and A:IsAHOpen() or false)
            if n > 0 and self.confirmStacks then
                self.buyoutBtn:SetText(string.format(L["Nächstes kaufen (%d übrig)"], n))
            elseif n > 0 then
                self.buyoutBtn:SetText(L["Auswahl kaufen: "] .. A:FormatMoney(cost))
            else
                self.buyoutBtn:SetText(L["Auswahl kaufen"])
            end
        elseif not d.commodity then
            self.stacks:Hide()
            self.items:Show()
            self.iboxTitle:SetText(L["Gewähltes Angebot"])
            self.items.selectedID = self.selListing and self.selListing.rowID
            -- iLvl-Filter auch für die Einzelangebote (nur wo das Angebot selbst eine Stufe hat)
            local minIl, maxIl = self:IlvlRange()
            local rows = A:NoBait(d.listings)
            if minIl or maxIl then
                local f = {}
                for _, l in ipairs(rows) do
                    if not l.ilvl or ((not minIl or l.ilvl >= minIl) and (not maxIl or l.ilvl <= maxIl)) then table.insert(f, l) end
                end
                rows = f
            end
            self.items:SetData(rows, true)
            local l = self.selListing
            if l and not d.listings[l.rowID or 0] then l = nil; self.selListing = nil end
            if l then
                local lines = {}
                table.insert(lines, L["Menge: "] .. l.qty)
                table.insert(lines, L["Sofortkauf: "] .. (l.buyout and A:FormatMoney(l.buyout) or L["keiner"]))
                table.insert(lines, L["Mindestgebot: "] .. A:FormatMoney(B:MinBid(l)))
                if l.price then table.insert(lines, L["% Markt: "] .. A:FormatMarketPercent(A:GetMarketPercent(d.itemID, l.price))) end
                self.selInfo:SetText(table.concat(lines, "\n"))
            else
                self.selInfo:SetText(L["Angebot links anklicken."])
                -- kein Angebot gewählt (z. B. anderes Item): kein altes Gebot im Feld stehen lassen
                if self.bidFor then self.bid:Clear(); self.bidFor = nil end
            end
            local canBuy = l and l.buyout and not l.own and not l.used
            self.buyoutBtn:SetActive(canBuy and A:IsAHOpen() or false)
            if canBuy and self.confirmBuy == l then
                self.buyoutBtn:SetText(L["Bestätigen: "] .. A:FormatMoney(l.buyout))
            else
                self.buyoutBtn:SetText(L["Sofortkauf"])
            end
            -- ohne gewähltes Angebot bleibt "Bieten" klickbar und sagt, was fehlt
            self.bidBtn:SetActive((A:IsAHOpen() and not (l and (l.own or l.used))) and true or false)
        end
    end

    -- regelmäßig auffrischen, solange etwas läuft
    local elapsed = 0
    p:SetScript("OnUpdate", function(self, dt)
        elapsed = elapsed + (dt or 0)
        if elapsed >= 0.5 then
            elapsed = 0
            if B.search or B.wanted or B.pending then self:Refresh() end
        end
    end)

    -- nach einem Neuaufbau (Sprach- oder Designwechsel) die letzte Suche wieder anzeigen:
    -- Kategorie, Suchtext und Filter bleiben so, wie sie waren
    local q = B.lastQuery
    if q then
        p.cat = q.cat or "all"
        p.search:SetText(q.text or ""); p.search:UpdatePlaceholder()
        p.lvlMin:SetText(q.minLevel and tostring(q.minLevel) or ""); p.lvlMin:UpdatePlaceholder()
        p.lvlMax:SetText(q.maxLevel and tostring(q.maxLevel) or ""); p.lvlMax:UpdatePlaceholder()
        p.ilvlMin:SetText(q.minIlvl and tostring(q.minIlvl) or ""); p.ilvlMin:UpdatePlaceholder()
        p.ilvlMax:SetText(q.maxIlvl and tostring(q.maxIlvl) or ""); p.ilvlMax:UpdatePlaceholder()
        if q.quals and p.qualityBtn.SetSet then p.qualityBtn:SetSet(q.quals) end
    end

    p:Refresh()
    return p
end

-- von anderen Reitern aus ein Item im Einkauf öffnen (z.B. Gebote aus dem Profit-Reiter)
function UI:OpenBuyFor(itemID)
    if not itemID then return end
    if not A:IsAHOpen() then
        A:Print(L["Bitte zuerst das Auktionshaus öffnen."])
        return
    end
    self:Show()
    local panel = self:SelectTab("buy")
    local ok, msg = A.Buy:Open(itemID)
    if not ok and msg then A:Print(msg) end
    if panel and panel.Refresh then panel:Refresh() end
end

UI:RegisterTab("buy", "Einkauf", 1.5, BuildBuy)

A:On("BUY_CHANGED", function()
    local tab = UI:GetTab("buy")
    if tab and tab.panel and tab.panel:IsVisible() then tab.panel:Refresh() end
end)

-- Item-Daten nachgeladen (Itemlevel/Seltenheit): sichtbare Tabellen neu zeichnen
A:On("ITEMINFO_LOADED", function()
    local tab = UI:GetTab("buy")
    local p = tab and tab.panel
    if not (p and p:IsVisible()) then return end
    if p.results and p.results:IsVisible() then
        local minIl, maxIl = p:IlvlRange()
        if minIl or maxIl then
            p:Refresh()                         -- Filter neu anwenden: nachgeladene Items erscheinen
        else
            if p.results.sortKey == "ilvl" or p.results.sortKey == "name" then p.results:Sort() end
            p.results:Render()
        end
    end
    if p.items and p.items:IsVisible() then p.items:Render() end
end)
