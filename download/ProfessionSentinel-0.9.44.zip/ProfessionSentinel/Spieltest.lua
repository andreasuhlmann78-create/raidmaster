local _, ns = ...
local L = ns.L

-- Spieltest (play test): companion mode that checks the play-test checklist in the game by itself, as soon as the
-- player brings about the situation (opens the profession window, clicks a recipe, crafts, levels). It never calls a
-- protected function itself and never touches the UI in combat. Each check S1–S8 gets OK / FEHLER / open with the
-- measured value and the expectation; results go into the diagnostic log and, on /ps spieltest bericht, into a
-- GSTEST1 report (area "S"). A FEHLER prints one chat line per check. No names anywhere.
--   /ps spieltest an | aus | bericht        (off by default; on until /reload or for 2 hours)
-- The checks themselves are plain functions (ST.Check…) so the test routine can play every situation offline.

local ST = {}
ns.Spieltest = ST

ST.DURATION = 2 * 60 * 60          -- seconds
ST.CLICKS = 5                      -- S1: result after 5 clicks
ST.CRAFTS = 5                      -- S7: result after 5 crafts
ST.MAX_BUILDS_PER_SEC = 2          -- S7
ST.IDS = { "S1", "S2", "S3", "S4", "S5", "S6", "S7", "S8", "S9", "S10" }

local activeUntil                  -- not saved: on until /reload
local clicks = {}                  -- S1
local craft                        -- S7: { t0, builds0, slow0, n }
local lastRank = {}                -- S3: prof -> rank seen last

local function Now() return (GetTime and GetTime()) or 0 end

function ST.IsOn() return activeUntil ~= nil and Now() < activeUntil end

local function Store()
    if not ns.db then return nil end
    if type(ns.db.spieltest) ~= "table" then ns.db.spieltest = {} end
    local s = ns.db.spieltest
    if type(s.results) ~= "table" then s.results = {} end
    if type(s.warned) ~= "table" then s.warned = {} end
    return s
end

local function Name(id) return L["ST_" .. id] or id end

-- one result: OK / FEHLER with measured value and expectation; a FEHLER prints one chat line per check.
-- Like AHSentinel (P:Result): a FEHLER stays (a later OK does not wipe it from the report); an OK is written only
-- once (no log line on every refresh); OK -> FEHLER is written.
function ST.Record(id, ok, value, want)
    local s = Store()
    if not s then return end
    local status = ok and "OK" or "FEHLER"
    local old = s.results[id]
    if old and old.s == "FEHLER" then return "FEHLER" end
    if old and old.s == "OK" and ok then return "OK" end
    s.results[id] = { s = status, v = tostring(value or ""), w = tostring(want or ""), t = time and time() or 0 }
    if ns.Diag then ns.Diag("SPIELTEST", id .. " " .. status .. ": " .. tostring(value or "")) end
    if not ok and not s.warned[id] then
        s.warned[id] = true
        ns.Print(string.format(L.ST_FAIL_LINE, id, Name(id), tostring(value or "?"), tostring(want or "?")))
    end
    return status
end

---------------------------------------------------------------------------
-- The checks (pure: values in, OK / FEHLER out)
---------------------------------------------------------------------------
-- S1: a click selects the recipe through the window's list, at once (< 0.5 s)
function ST.CheckClick(c)
    return c ~= nil and c.ok == true and c.way == "Liste" and (c.ms or 0) < 500
end

-- S2: the plan starts at the skill of the open profession; never 0 if learned
function ST.CheckSkill(rank, planFrom)
    if type(rank) ~= "number" or rank <= 0 then return false, "Fertigkeit " .. tostring(rank), "> 0" end
    if planFrom ~= nil and planFrom ~= rank then return false, "Plan ab " .. tostring(planFrom), "ab " .. rank end
    return true, "Fertigkeit " .. rank .. (planFrom and (", Plan ab " .. planFrom) or ""), "Plan ab Fertigkeit"
end

-- S3: after a skill point "N× to yellow" goes down for every recipe that is still orange/yellow (or its colour changes)
function ST.CheckCounter(recipes, oldRank, newRank)
    if not (ns.Lifeline and ns.Lifeline.Calc) or not (oldRank and newRank) or newRank <= oldRank then
        return false, string.format("%s -> %s", tostring(oldRank), tostring(newRank)), "Fertigkeit steigt"
    end
    local checked, bad = 0, 0
    for _, r in ipairs(recipes or {}) do
        local a, b = ns.Lifeline.Calc(r, oldRank), ns.Lifeline.Calc(r, newRank)
        if a and a.crafts and a.crafts > 0 then
            checked = checked + 1
            -- orange counts are exact (must go down); yellow/green are expected values (must not go up)
            local same = b and b.crafts and b.target == a.target
            if same and (a.exact and b.crafts >= a.crafts or not a.exact and b.crafts > a.crafts) then bad = bad + 1 end
        end
        if checked >= 50 then break end
    end
    if checked == 0 then return true, "kein Rezept mit Zähler", "Zähler sinkt" end
    return bad == 0, string.format("%d von %d gesunken", checked - bad, checked), "alle"
end

-- S4: the panel covers neither the profession window nor AHSentinel's window (rectangles l/r/t/b)
function ST.CheckDock(panel, host, dock)
    local O = ns.UI and ns.UI.Overlap
    if not (O and panel) then return false, "kein Panel", "Panel sichtbar" end
    if host and O(panel, host) then return false, "überdeckt Berufsfenster", "nebeneinander" end
    if dock and O(panel, dock) then return false, "überdeckt AHSentinel", "nebeneinander" end
    return true, dock and "neben AHSentinel" or "neben Berufsfenster", "nebeneinander"
end

-- S5: the AH share of a sale is the same number in ProfessionSentinel and AHSentinel (AuctionFee(total) without
-- an item = the 5 % share; AHSentinel.API: its CutPct)
function ST.CheckFee(price, itemID, qty)
    local P, PS = ns.Prices, ns.PriceSource
    local own = P.AuctionFee(price)
    local api = PS.API()
    -- AHSentinel's real number (API.NetSale, 2nd value .cut) – not recomputed here
    if api and type(api.NetSale) == "function" and itemID then
        local ok, _, info = pcall(api.NetSale, itemID, qty or 1)
        if not ok or type(info) ~= "table" or type(info.cut) ~= "number" or (info.gross or 0) <= 0 then return nil end
        own = P.AuctionFee(info.gross)
        return info.cut == own, string.format("%s: PS %d, AHS %d", P.MoneyPlain(info.gross), own, info.cut), "gleich"
    end
    local A = PS.Legacy()
    local fn = A and (type(A.AuctionFee) == "function" and A.AuctionFee or type(A.AHFee) == "function" and A.AHFee)
    if not fn then return nil, "AHSentinel ohne Gebührenfunktion", "AHAnalyzerPro:AuctionFee" end
    local ok, theirs = pcall(fn, A, price)
    if not ok or type(theirs) ~= "number" then return false, "Fehler in AHSentinel (AuctionFee)", tostring(own) end
    return theirs == own, string.format("%s: PS %d, AHS %d", P.MoneyPlain(price), own, theirs), "gleich"
end

-- S6: levelling ranking – learned before not learned, each part by material per point, nothing grey
function ST.CheckRanking(list)
    local seenUnlearned, prev = false, nil
    for i, e in ipairs(list or {}) do
        if not (e.colourPoints and e.colourPoints > 0) then return false, "graues Rezept auf Platz " .. i, "kein graues" end
        if e.learned then
            if seenUnlearned then return false, "gelerntes nach ungelerntem (Platz " .. i .. ")", "gelernte zuerst" end
        elseif not seenUnlearned then
            seenUnlearned, prev = true, nil
        end
        if prev and e.matValue + 1e-9 < prev then return false, "Platz " .. i .. " nicht sortiert", "aufsteigend" end
        prev = e.matValue
    end
    return true, #(list or {}) .. " Rezepte", "sortiert"
end

-- S7: crafting does not set off a storm: at most 2 rebuilds per second, nothing slower than 16 ms
function ST.CheckStorm(builds, seconds, slow)
    local rate = (builds or 0) / math.max(seconds or 0, 1)
    local ok = rate <= ST.MAX_BUILDS_PER_SEC and (slow or 0) == 0
    return ok, string.format("%.1f Aufbau/s, %d LANGSAM", rate, slow or 0), "≤ 2/s, 0 LANGSAM"
end

-- S8: area K of the test routine (UICheck) once with the profession window open
function ST.CheckUI()
    local U = ns.UICheck
    if not (U and U.Available and U.Available()) then return nil, "nur im echten Client", "UICheck" end
    local problems, tested = {}, 0
    for _, fn in ipairs({ U.TooltipsCoverNothing, U.WindowsOverlapNothing, U.InsideScreen, U.TextFits, U.ValuesPlausible }) do
        local ok, p, n = pcall(fn)
        if ok then
            for _, x in ipairs(p or {}) do problems[#problems + 1] = x end
            tested = tested + (n or 0)
        else
            problems[#problems + 1] = "Lua-Fehler"
        end
    end
    return #problems == 0, (#problems == 0 and "keine" or table.concat(problems, "; ")) .. " · geprüft " .. tested, "keine"
end

-- S9: the bags gained exactly what was bought (the typed amount, or whole bundles)
function ST.CheckBuy(before, after, planned)
    local got = (after or 0) - (before or 0)
    return got == planned, string.format("%d in den Taschen dazu", got), tostring(planned)
end

---------------------------------------------------------------------------
-- Situations in the game (hooks from UI.lua, Scan.lua; events below)
---------------------------------------------------------------------------
local function Busy() return ns.InCombat and ns.InCombat() end

function ST.OnClick(c)
    if not ST.IsOn() or not ns.UsesModernProfessions then return end
    clicks[#clicks + 1] = ST.CheckClick(c) and true or false
    if #clicks >= ST.CLICKS then
        local bad = 0
        for _, ok in ipairs(clicks) do if not ok then bad = bad + 1 end end
        ST.Record("S1", bad == 0, string.format("%d von %d sofort über die Liste", #clicks - bad, #clicks), "alle")
        clicks = {}
    end
    -- S5 on the same click: the fee of this recipe's product
    if c and c.spell and ns.BySpell and ns.BySpell[c.spell] and ns.Prices then
        local r = ns.BySpell[c.spell]
        local price = r.out and ns.Prices.AH(r.out)
        if price then
            local stack = ns.Prices.StackSize(r.out)
            local ok, v, w = ST.CheckFee(price * stack, r.out, stack)
            if ok ~= nil then ST.Record("S5", ok, v, w) end
        end
    end
end

local function RealProfession()
    if not (ns.UI and ns.UI.CurrentProfession) or (ns.Sim and (ns.Sim.rank or ns.Sim.prof)) then return nil end
    return ns.UI.CurrentProfession()
end

local lastSituation                -- S2: only on a new situation (profession or skill changed)
function ST.OnProfession()
    if not ST.IsOn() then return end
    local prof, rank, max = RealProfession()
    if not prof then return end
    local situation = tostring(prof) .. ":" .. tostring(rank) .. ":" .. tostring(max)
    if situation == lastSituation then return end      -- same profession, same skill: nothing new to check
    lastSituation = situation
    local from
    if ns.Plan and ns.Plan.Build and type(rank) == "number" and rank > 0 then
        local saved = ns.Plan.current
        local ok, plan = pcall(ns.Plan.Build, prof, rank, max)
        ns.Plan.current = saved
        from = ok and plan and plan.from or nil
    end
    ST.Record("S2", ST.CheckSkill(rank, from))
    -- S3: a skill point since last time
    local old = lastRank[prof]
    if old and type(rank) == "number" and rank > old then
        ST.Record("S3", ST.CheckCounter(ns.ByProf and ns.ByProf[prof], old, rank))
    end
    if type(rank) == "number" then lastRank[prof] = rank end
end

function ST.OnRanking()
    if not ST.IsOn() then return end
    local AD = ns.Advisor
    if AD and AD.current and AD.current.mat and #AD.current.mat > 0 then ST.Record("S6", ST.CheckRanking(AD.current.mat)) end
end

function ST.OnDock()
    if not ST.IsOn() or Busy() then return end
    local UI = ns.UI
    local p = UI and UI.PanelFrame and UI.PanelFrame()
    if not (p and p:IsShown() and UI.Rect) then return end
    local host = UI.dockedHost and UI.dockedHost()
    local dock = UI.GetAHSDockFrame and UI.GetAHSDockFrame()
    local ok, v, w = ST.CheckDock(UI.Rect(p), host and UI.Rect(host), dock and UI.Rect(dock))
    -- without AHSentinel's window a pass is only final if AHSentinel is not loaded at all
    if ok and not dock and ns.Foreign("AHAnalyzerPro") then return end
    ST.Record("S4", ok, v, w)
end

local function OnCraft()
    if not ST.IsOn() then return end
    local t = Now()
    if not craft or t - craft.last > 30 then
        craft = { t0 = t, last = t, n = 0, builds0 = ns.UI and ns.UI.refreshRuns or 0, slow0 = ns.diagSlowCount or 0 }
    end
    craft.n, craft.last = craft.n + 1, t
    if craft.n >= ST.CRAFTS then
        local builds = (ns.UI and ns.UI.refreshRuns or 0) - craft.builds0
        ST.Record("S7", ST.CheckStorm(builds, t - craft.t0, (ns.diagSlowCount or 0) - craft.slow0))
        craft = nil
    end
end

function ST.OnWindowOpen()
    if not ST.IsOn() then return end
    local s = Store()
    if s and s.results.S8 then return end      -- once
    local function run()
        if Busy() or not (ns.UI and ns.UI.PanelVisible and ns.UI.PanelVisible()) then return end
        local ok, v, w = ST.CheckUI()
        if ok ~= nil then ST.Record("S8", ok, v, w) end
    end
    if ns.API.TimerAfter then ns.API.TimerAfter(1, run) else run() end
end

-- a purchase from the shopping list: look at the bags shortly after (the vendor answers a moment later)
function ST.OnBuy(itemID, before, planned)
    if not ST.IsOn() or not itemID or (planned or 0) <= 0 then return end
    local function check()
        ST.Record("S9", ST.CheckBuy(before, ns.GetItemCount(itemID, false), planned))
    end
    if ns.API.TimerAfter then ns.API.TimerAfter(1.5, check) else check() end
end

-- S10: Shift+click at the vendor – "open": our window open and Blizzard's dialog closed; "chat": with the chat input
-- active only the link, our window stays closed. OK only after BOTH situations were seen (otherwise open with hint).
local shiftSeen = {}
function ST.OnMerchantShift(kind, ok)
    if not ST.IsOn() then return end
    if not ok then
        if kind == "chat" then
            ST.Record("S10", false, "Mengenfenster trotz Chat-Eingabe offen", "nur Link im Chat")
        else
            ST.Record("S10", false, "Mengenfenster zu oder Blizzard-Dialog offen", "Mengenfenster offen, Dialog zu")
        end
        return
    end
    shiftSeen[kind] = true
    if shiftSeen.open and shiftSeen.chat then
        ST.Record("S10", true, "Fenster offen, Dialog zu; mit Chat nur Link", "so")
    end
end

---------------------------------------------------------------------------
-- Commands and report
---------------------------------------------------------------------------
-- which situation is still missing for an open check
local HINT = { S1 = "ST_HINT_CLICK", S2 = "ST_HINT_WINDOW", S3 = "ST_HINT_SKILLUP", S4 = "ST_HINT_AHS", S5 = "ST_HINT_CLICK",
    S6 = "ST_HINT_RANKING", S7 = "ST_HINT_CRAFT", S8 = "ST_HINT_WINDOW", S9 = "ST_HINT_BUY",
    S10 = "ST_HINT_SHIFT" }
function ST.Hint(id) return L[HINT[id]] or "" end

function ST.Start()
    activeUntil = Now() + ST.DURATION
    local s = Store()
    if s then s.results, s.warned = {}, {} end
    clicks, craft, lastRank, lastSituation, shiftSeen = {}, nil, {}, nil, {}
    ns.Print(L.ST_ON)
    ST.OnProfession()
end

function ST.Stop()
    activeUntil = nil
    ns.Print(L.ST_OFF)
end

-- report: chat summary and a GSTEST1 report (area "S"); returns counts ok, fehler, open
function ST.Report()
    local s = Store()
    local res = s and s.results or {}
    local nOk, nFail, nOpen = 0, 0, 0
    local GT = _G.GoldSentinelTest
    local run = GT and GT.Begin and GT.Begin("ProfessionSentinel", ns.VERSION, ProfessionSentinelDB)
    ns.Print(L.ST_REPORT_HEAD)
    for _, id in ipairs(ST.IDS) do
        local r = res[id]
        if r and r.s == "OK" then
            nOk = nOk + 1
            ns.Print("|cff40c040OK|r " .. id .. " " .. Name(id) .. " – " .. r.v)
            if run then run:Check(id, "S", Name(id), function() return true, r.v end) end
        elseif r and r.s == "FEHLER" then
            nFail = nFail + 1
            ns.Print("|cffff4040" .. L.ST_FAIL_WORD .. "|r " .. id .. " " .. Name(id) .. " – " .. r.v .. " (" .. r.w .. ")")
            if run then run:Check(id, "S", Name(id), function() return false, r.v, r.w end) end
        else
            nOpen = nOpen + 1
            ns.Print("|cffffd100" .. L.ST_OPEN_WORD .. "|r " .. id .. " " .. Name(id) .. " – " .. ST.Hint(id))
            if run then run:Skip(id, "S", Name(id), ST.Hint(id)) end
        end
    end
    if run then pcall(run.Finish, run, { modus = "spieltest" }) end
    ns.Print(string.format(L.ST_REPORT_SUM, nOk, nFail, nOpen))
    return nOk, nFail, nOpen
end

function ST.Command(arg)
    arg = (arg or ""):lower()
    if arg == "an" or arg == "on" or arg == "" and not ST.IsOn() then ST.Start()
    elseif arg == "aus" or arg == "off" then ST.Stop()
    elseif arg == "bericht" or arg == "report" or arg == "" then ST.Report()
    else ns.Print(L.ST_HELP) end
end

-- events: profession window opened (S8), own crafts (S7)
local f = ns.AddEventFrame(CreateFrame("Frame"), "Spieltest")
pcall(f.RegisterEvent, f, "TRADE_SKILL_SHOW")
pcall(f.RegisterEvent, f, "UNIT_SPELLCAST_SUCCEEDED")
f:SetScript("OnEvent", function(_, event, unit, _, spell)
    if not ST.IsOn() then return end
    if event == "TRADE_SKILL_SHOW" then ST.OnWindowOpen()
    elseif event == "UNIT_SPELLCAST_SUCCEEDED" and unit == "player" then
        if ns.IsSecret and ns.IsSecret(spell) then return end
        if type(spell) == "number" and ns.BySpell and ns.BySpell[spell] then OnCraft() end
    end
end)
ST.OnCraft = OnCraft
