local _, ns = ...
local L = ns.L

-- Recipe alarm: a recipe that you or one of your characters (same game version, with that
-- profession) still misses is listed in the auction house.
-- Source: AHSentinel – after every scan (event SCAN_FINISHED) and from its current prices
-- (A:GetCurrent, last 2 hours) when the panel opens.

local AL = {}
ns.Alerts = AL

AL.found = {}          -- { { itemID, recipe, price, qty, who = { names } } } sorted by price
AL.FRESH = 2 * 3600

local function AHS()
    local A = ns.Foreign("AHAnalyzerPro")
    return A and A.GetCurrent and A or nil
end

-- recipe item -> characters that miss it: { [itemID] = { recipe, names } }
function AL.Needed()
    local out = {}
    if not ns.db then return out end
    local me = ns.CharKey and ns.CharKey()
    for key, c in pairs(type(ns.db.chars) == "table" and ns.db.chars or {}) do
        if type(key) == "string" and type(c) == "table" and (c.flavor == nil or c.flavor == ns.Flavor) and type(c.profs) == "table" then
            for prof in pairs(c.profs) do
                for _, r in ipairs(ns.ByProf[prof] or {}) do
                    local known = type(c.known) == "table" and c.known[r.spell]
                    if key == me then known = ns.IsLearned(r) end
                    if not known and r.recipeItems and #r.recipeItems > 0 then
                        for _, ri in ipairs(r.recipeItems) do
                            local e = out[ri.id]
                            if not e then e = { recipe = r, names = {} }; out[ri.id] = e end
                            e.names[#e.names + 1] = (key:match("^[^-]+") or key)
                        end
                    end
                end
            end
        end
    end
    return out
end

-- prices: { [itemID] = { price, qty, unconfirmed } }
function AL.Match(prices)
    local needed = AL.Needed()
    local list = {}
    for itemID, e in pairs(needed) do
        local p = prices[itemID]
        if type(p) == "table" and type(p.price) == "number" and p.price > 0 and not p.u then
            list[#list + 1] = { itemID = itemID, recipe = e.recipe, price = p.price, qty = p.qty or 1, who = e.names }
        end
    end
    table.sort(list, function(a, b) return a.price < b.price end)
    return list
end

-- from AHSentinel's current prices (no new scan needed)
local lastCurrent = -100
function AL.ResetCurrent() lastCurrent = -100 end
function AL.FromCurrent()
    local A = AHS()
    if not A then return AL.found end
    local t0 = GetTime and GetTime() or 0
    if t0 - lastCurrent < 30 then return AL.found end      -- at most every 30 s
    lastCurrent = t0
    local prices = {}
    local now = time and time() or 0
    for itemID in pairs(AL.Needed()) do
        local ok, price, qty, t = pcall(A.GetCurrent, A, itemID)
        if not ok then ns.CountError("AHSentinel:GetCurrent", price) end
        if ok and type(price) == "number" and type(t) == "number" and now - t <= AL.FRESH then prices[itemID] = { price = price, qty = qty } end
    end
    AL.found = AL.Match(prices)
    return AL.found
end

function AL.PlaySound()
    if PlaySound and SOUNDKIT and SOUNDKIT.RAID_WARNING then pcall(PlaySound, SOUNDKIT.RAID_WARNING) end
end

local announced = {}   -- itemID -> price already announced this session
function AL.ResetAnnounced() announced = {}; AL.chatted = nil end

function AL.OnScan(best)
    if not (ns.db and ns.db.recipeAlert ~= false) or type(best) ~= "table" then return end
    AL.found = AL.Match(best)
    local fresh = {}
    for _, f in ipairs(AL.found) do
        if not announced[f.itemID] or f.price < announced[f.itemID] then
            fresh[#fresh + 1] = f
            announced[f.itemID] = f.price
        end
    end
    if #fresh == 0 then return end
    -- no long chat output (UI rework U8): the list is in the panel (tab "Recipes", group of the alarm, number on the
    -- tab); in the chat at most ONE short line per session
    if not AL.chatted then
        AL.chatted = true
        AL.PlaySound()
        ns.Print(string.format(L.ALERT_SHORT, #AL.found))
    end
    if ns.RefreshAll then ns.RefreshAll() end
end

-- one alert into the sniper: max price = current price, 1 piece
function AL.ToSniper(f)
    return ns.Disenchant.SendToSniper({ { id = f.itemID, maxPrice = f.price, qty = 1 } }, ns.ItemName(f.itemID), L.ALERT_SNIPE_DONE)
end

local ev = ns.AddEventFrame(CreateFrame("Frame"), "Alerts")
ev:RegisterEvent("PLAYER_LOGIN")
local registered = false
ev:SetScript("OnEvent", function()
    local A = ns.Foreign("AHAnalyzerPro")
    if registered or not (A and A.On) then return end
    local ok, err = pcall(A.On, A, "SCAN_FINISHED", function(_, best) AL.OnScan(best) end)
    if ok then registered = true; AL.registered = true else ns.CountError("AHSentinel:On", err) end
end)

---------------------------------------------------------------------------
-- Recipes in your bags: who of your characters needs it – or nobody (then: sell it)
-- { { itemID, recipe, count, who = { names }, ah, vendor } }
---------------------------------------------------------------------------
function AL.BagRecipes()
    local out = {}
    local A = ns.API
    local GetSlots = A.ContainerGetContainerNumSlots or A.GetContainerNumSlots
    local GetID = A.ContainerGetContainerItemID or A.GetContainerItemID
    if not (GetSlots and GetID) then return out end
    local counts = {}
    for bag = 0, (NUM_BAG_SLOTS or 4) do
        for slot = 1, (GetSlots(bag) or 0) do
            local id = GetID(bag, slot)
            if id and ns.ByRecipeItem[id] then counts[id] = (counts[id] or 0) + 1 end
        end
    end
    if not next(counts) then return out end
    local needed = AL.Needed()
    for id, n in pairs(counts) do
        local e = needed[id]
        out[#out + 1] = { itemID = id, recipe = ns.ByRecipeItem[id], count = n, who = e and e.names or {},
                          ah = ns.Prices.AH(id), vendor = ns.Prices.VendorSell(id) }
    end
    table.sort(out, function(a, b)
        if (#a.who > 0) ~= (#b.who > 0) then return #a.who > 0 end
        return ns.ItemName(a.itemID) < ns.ItemName(b.itemID)
    end)
    return out
end
