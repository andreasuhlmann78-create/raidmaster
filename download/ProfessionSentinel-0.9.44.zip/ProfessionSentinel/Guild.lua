local _, ns = ...
local L = ns.L

-- Guild: who can craft what, which recipes nobody in the guild knows, profession cooldowns.
-- ProfessionSentinel does NOT send anything itself: GuildSentinel and RaidMaster already share
-- professions and cooldowns in the guild. We only read their saved data:
--   GuildSentinelDB.guilds["Realm|Guild"].prof[Name] = { c, t, p = { [profession name] = { r, m, n = { recipe names }, i = { item IDs } } } }
--   RaidMaster.db.prof (same format, newer entry wins)
--   GuildSentinelDB.guilds["Realm|Guild"].cds[Name] = { t, k = { transmute|mooncloth|saltshaker = ready at (server time, 0 = ready) } }

local GU = {}
ns.Guild = GU

local function GuildRecord()
    if not (IsInGuild and IsInGuild()) then return nil end
    local gname = GetGuildInfo and GetGuildInfo("player")
    if not gname then return nil end
    local db = _G.GuildSentinelDB
    local key = (GetRealmName and GetRealmName() or "") .. "|" .. gname
    return db and type(db.guilds) == "table" and db.guilds[key] or nil
end
GU.GuildRecord = GuildRecord

function GU.Profs()
    local g = GU.GuildRecord()
    local out = {}
    if type(g) == "table" and type(g.prof) == "table" then
        for k, v in pairs(g.prof) do
            if type(k) == "string" and type(v) == "table" then out[k] = v end
        end
    end
    local rm = ns.Foreign("RaidMaster")
    if type(rm) == "table" and type(rm.db) == "table" and type(rm.db.prof) == "table" then
        for k, v in pairs(rm.db.prof) do
            if type(k) == "string" and type(v) == "table" and type(v.p) == "table" and (not out[k] or (v.t or 0) >= (out[k].t or 0)) then
                out[k] = v
            end
        end
    end
    return out
end

function GU.Available()
    return GU.GuildRecord() ~= nil or (type(ns.Foreign("RaidMaster")) == "table" and type(ns.Foreign("RaidMaster").db) == "table")
end

-- one roster entry into the online cache: "Name-Realm" -> "Name" (WoW Forever: "First Last" keeps the space).
-- Protected ("secret") names are skipped.
function GU.AddOnline(cache, name, online)
    -- IsSecret first, then the tests and comparisons
    if ns.IsSecret(name) or ns.IsSecret(online) or not online or type(name) ~= "string" or name == "" then return false end
    cache[(name:match("^[^-]+") or name)] = true
    return true
end

-- online members of the guild roster: { [Name] = true }
local onlineCache, onlineTime = {}, -100
function GU.Online()
    local t = GetTime and GetTime() or 0
    if t - onlineTime < 20 then return onlineCache end
    onlineTime, onlineCache = t, {}
    if GetNumGuildMembers and GetGuildRosterInfo then
        for i = 1, (GetNumGuildMembers() or 0) do
            local name, _, _, _, _, _, _, _, online = GetGuildRosterInfo(i)
            GU.AddOnline(onlineCache, name, online)
        end
    end
    return onlineCache
end
function GU.InvalidateOnline() onlineTime = -100 end

-- index (rebuilt at most once a minute): crafted item -> names, recipe name -> names
local index, indexTime, members = nil, -100, 0
local function Index()
    local t = GetTime and GetTime() or 0
    if index and t - indexTime < 60 then return index end
    indexTime = t
    index = { byItem = {}, byName = {}, rank = {} }
    members = 0
    for who, v in pairs(GU.Profs()) do
        local short = who:match("^[^-]+") or who
        members = members + 1
        for profName, pv in pairs(type(v.p) == "table" and v.p or {}) do
            local names = type(pv) == "table" and type(pv.n) == "table" and pv.n or {}
            local ids = type(pv) == "table" and type(pv.i) == "table" and pv.i or nil
            for k, rn in ipairs(names) do
                local id = ids and ids[k]
                if type(id) == "number" and id > 0 then
                    index.byItem[id] = index.byItem[id] or {}
                    index.byItem[id][short] = pv.r or 0
                end
                if type(rn) == "string" then
                    local key = rn:lower()
                    index.byName[key] = index.byName[key] or {}
                    index.byName[key][short] = pv.r or 0
                end
            end
        end
    end
    return index
end

function GU.Invalidate() indexTime, index = -100, nil end

-- guild members who know a recipe: { { name, rank, online } } (online first), nil = no guild data
function GU.Crafters(r)
    local idx = Index()
    if members == 0 then return nil end
    local set = {}
    local function add(t) for n, rk in pairs(t or {}) do set[n] = rk end end
    if r.out and r.out > 0 then add(idx.byItem[r.out]) end
    if r.name then add(idx.byName[r.name:lower()]) end
    if r.nameEN and r.nameEN ~= "" then add(idx.byName[r.nameEN:lower()]) end
    local on = GU.Online()
    local out = {}
    for n, rk in pairs(set) do out[#out + 1] = { name = n, rank = rk, online = on[n] or false } end
    table.sort(out, function(a, b)
        if a.online ~= b.online then return a.online end
        return a.name < b.name
    end)
    return out
end

function GU.MemberCount()
    Index()
    return members
end

-- "Testa (online), Ana" – at most max names
function GU.CraftersText(list, max)
    max = max or 6
    local parts = {}
    for i, c in ipairs(list or {}) do
        if i > max then parts[#parts + 1] = string.format(L.MORE, #list - max); break end
        parts[#parts + 1] = c.online and ("|cff40c040" .. c.name .. "|r") or ("|cffb0b0b0" .. c.name .. "|r")
    end
    return table.concat(parts, ", ")
end

-- recipes of a profession nobody in the guild knows (needs guild data)
function GU.NobodyKnows(prof)
    if GU.MemberCount() < 2 then return nil end
    local out = {}
    for _, r in ipairs(ns.ByProf[prof] or {}) do
        local c = GU.Crafters(r)
        if c and #c == 0 then out[#out + 1] = r end
    end
    return out
end

---------------------------------------------------------------------------
-- Cooldowns (from GuildSentinel): which profession they belong to
---------------------------------------------------------------------------
GU.COOLDOWNS = {
    { key = "transmute", prof = 171, label = "CD_TRANSMUTE" },
    { key = "mooncloth", prof = 197, label = "CD_MOONCLOTH" },
    { key = "saltshaker", prof = 165, label = "CD_SALTSHAKER" },
}

-- { { key, label, list = { { name, ready (seconds left, 0 = ready), online } } } } for a profession
function GU.Cooldowns(prof)
    local g = GU.GuildRecord()
    if not (type(g) == "table" and type(g.cds) == "table") then return nil end
    local now = GetServerTime and GetServerTime() or (time and time()) or 0
    local on = GU.Online()
    local out = {}
    for _, c in ipairs(GU.COOLDOWNS) do
        if not prof or c.prof == prof then
            local list = {}
            for who, v in pairs(g.cds) do
                local at = type(v) == "table" and type(v.k) == "table" and v.k[c.key]
                if type(who) == "string" and type(at) == "number" then
                    local short = who:match("^[^-]+") or who
                    list[#list + 1] = { name = short, left = math.max(0, at - now), online = on[short] or false }
                end
            end
            table.sort(list, function(a, b)
                if a.left ~= b.left then return a.left < b.left end
                return a.name < b.name
            end)
            if #list > 0 then out[#out + 1] = { key = c.key, label = L[c.label], list = list } end
        end
    end
    return out
end

function GU.LeftText(sec)
    if sec <= 0 then return "|cff40c040" .. L.CD_READY .. "|r" end
    local h = math.floor(sec / 3600)
    local m = math.floor((sec % 3600) / 60)
    if h >= 24 then return string.format(L.CD_DAYS, math.floor(h / 24), h % 24) end
    if h > 0 then return string.format(L.CD_HOURS, h, m) end
    return string.format(L.CD_MINUTES, math.max(1, m))
end
