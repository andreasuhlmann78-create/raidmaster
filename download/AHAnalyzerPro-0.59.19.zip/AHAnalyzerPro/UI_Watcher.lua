-- ============================================================
-- AH Analyzer Pro 5.9 - Tab "Wächter" (Schnäppchen-Wächter)
--   links:  an/aus, Schwelle, Mindestwert, Budget, Kategorien
--   rechts: gefundene Schnäppchen - kaufen mit Mausrad / Taste wie beim Sniper
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C

local STATUS_COLOR = {
    ["kaufbar"] = "33dd55", ["prüft"] = "ffcc33", ["gekauft"] = "00d1d1",
    ["Lockangebot"] = "ff9933", ["weg"] = "888888", ["abgelaufen"] = "888888",
}

local function BuildWatcher(parent)
    local p = CreateFrame("Frame", nil, parent)
    local W = A.Watcher
    local Sn = A.Sniper

    local function setMessage(ok, msg)
        if not msg then return end
        p.message:SetText(msg)
        p.message:SetTextColor(unpack(ok and C.textDim or C.red))
    end

    -- ================= Links: Einstellungen =================
    local head = UI:TabTitle(p, L["Schnäppchen-Wächter"], "watcher")
    local sub = UI:Label(p, L["Sucht nebenbei Handwerkswaren deutlich unter dem Marktwert -\negal, was du gerade snipst. Kaufen mit Mausrad / Taste wie beim Sniper."], "GameFontDisableSmall", C.textDim)
    sub:SetPoint("TOPLEFT", head, "BOTTOMLEFT", 0, -4)
    sub:SetWidth(440)
    sub:SetJustifyH("LEFT")

    p.enableBtn = UI:Button(p, "", 170, 26, function()
        W:Toggle()
        p:Refresh()
    end, "primary")
    p.enableBtn:SetPoint("TOPLEFT", 0, -50)
    p.enableBtn.tooltip = L["Wächter an/aus. Arbeitet nur, solange das Auktionshaus offen ist.\nGekauft wird nie ohne deinen Tastendruck."]

    p.status = UI:Label(p, "", "GameFontHighlightSmall", C.text)
    p.status:SetPoint("LEFT", p.enableBtn, "RIGHT", 10, 0)
    p.status:SetWidth(260)
    p.status:SetJustifyH("LEFT")

    -- Schwelle
    local thLabel = UI:Label(p, L["Treffer ab:"], "GameFontHighlightSmall", C.textDim)
    thLabel:SetPoint("TOPLEFT", 0, -92)
    p.thresholdButtons = {}
    local prev
    for i, pct in ipairs(W.THRESHOLDS) do
        local b = UI:Button(p, "<= " .. pct .. " %", 66, 22, function()
            W:SetThreshold(pct)
            p:Refresh()
        end)
        if prev then b:SetPoint("LEFT", prev, "RIGHT", 4, 0) else b:SetPoint("TOPLEFT", 96, -88) end
        b.pct = pct
        b.tooltip = string.format(L["Schnäppchen, wenn der Preis höchstens %d %% vom Marktwert (Median 14 Tage) beträgt"], pct)
        p.thresholdButtons[i] = b
        prev = b
    end

    -- Mindestwert pro Stück
    local mvLabel = UI:Label(p, L["Mindestwert/Stück:"], "GameFontHighlightSmall", C.textDim)
    mvLabel:SetPoint("TOPLEFT", 0, -126)
    p.minValue = UI:MoneyInput(p, function(m, userInput)
        if userInput then
            local v = m:GetCopper()
            if v then W:SetMinValue(v) end
        end
    end)
    p.minValue:SetPoint("TOPLEFT", 140, -120)
    p.minValue.tooltip = L["Nur Waren, deren Marktwert pro Stück mindestens so hoch ist\n(Standard 10 Kupfer - filtert Kleinkram)"]

    -- Budget je Schnäppchen
    local bLabel = UI:Label(p, L["Budget je Schnäppchen:"], "GameFontHighlightSmall", C.textDim)
    bLabel:SetPoint("TOPLEFT", 0, -158)
    p.budget = UI:MoneyInput(p, function(m, userInput)
        if userInput then
            local v = m:GetCopper()
            if v then W:SetBudget(v) end
        end
    end)
    p.budget:SetPoint("TOPLEFT", 140, -152)
    p.budget.tooltip = L["So viel Gold gibt ein Kauf-Druck pro Schnäppchen höchstens aus"]

    -- Kategorien
    local catLabel = UI:Label(p, L["Kategorien (nur Handwerkswaren):"], "GameFontHighlightSmall", C.textDim)
    catLabel:SetPoint("TOPLEFT", 0, -192)
    p.catButtons = {}
    for i, cat in ipairs(W.CATS) do
        local b = UI:Button(p, "", 144, 22, function()
            W:ToggleCategory(cat.key)
            p:Refresh()
        end)
        local col, row = (i - 1) % 3, math.floor((i - 1) / 3)
        b:SetPoint("TOPLEFT", col * 148, -210 - row * 26)
        b.cat = cat
        b.tooltip = L["Kategorie ein/aus"]
        p.catButtons[i] = b
    end

    p.modeLabel = UI:Label(p, "", "GameFontHighlightSmall", C.textDim)
    p.modeLabel:SetPoint("TOPLEFT", 0, -298)
    p.modeLabel:SetWidth(300)
    p.modeLabel:SetJustifyH("LEFT")
    p.modeBtn = UI:Button(p, L["Wieder zusammen suchen"], 150, 22, function()
        A.db.watcher.mode = "combined"
        W.emptyRounds = 0
        setMessage(true, L["Alle Kategorien wieder in einer Suche."])
        p:Refresh()
    end)
    p.modeBtn:SetPoint("TOPLEFT", 296, -294)
    p.modeBtn.tooltip = L["Alle gewählten Kategorien in einer einzigen Suche (schneller).\nLehnt der Server das ab, schaltet der Wächter selbst auf einzeln um."]

    p.stats = UI:Label(p, "", "GameFontDisableSmall", C.textDim)
    p.stats:SetPoint("TOPLEFT", 0, -326)
    p.stats:SetWidth(440)
    p.stats:SetJustifyH("LEFT")

    local note = UI:Label(p, L["Jeder Treffer wird per Einzelsuche nachgeprüft."], "GameFontDisableSmall", C.textDim)
    note:SetPoint("TOPLEFT", 0, -366)
    note:SetWidth(440)
    note:SetJustifyH("LEFT")

    p.message = UI:Label(p, "", "GameFontHighlightSmall", C.textDim)
    p.message:SetPoint("TOPLEFT", 0, -420)
    p.message:SetWidth(440)
    p.message:SetJustifyH("LEFT")

    -- ================= Rechts: Schnäppchen =================
    local right = CreateFrame("Frame", nil, p)
    right:SetPoint("TOPLEFT", 456, 0)
    right:SetPoint("BOTTOMRIGHT", 0, 0)

    local rt = UI:Label(right, L["Gefundene Schnäppchen"], "GameFontNormalLarge", C.accent)
    rt:SetPoint("TOPLEFT", 0, 0)
    p.binds = UI:Label(right, "", "GameFontHighlightSmall", C.textDim)
    p.binds:SetPoint("TOPLEFT", 0, -24)
    p.binds:SetWidth(470)

    p.table = UI:Table(right, {
        columns = {
            { key = "name", title = L["Item"], width = 150 },
            { key = "price", title = L["Preis/Stück"], width = 100, align = "RIGHT" },
            { key = "pct", title = L["% Markt"], width = 54, align = "RIGHT",
              tooltip = L["Preis in Prozent vom Marktwert (Median 14 Tage)"] },
            { key = "qty", title = L["Menge"], width = 50, align = "RIGHT" },
            { key = "status", title = "", width = 82 },
        },
        rows = 14,
        rowHeight = 22,
        cell = function(o, key)
            if key == "name" then return o.name end
            if key == "price" then return A:FormatMoney(o.price) end
            if key == "pct" then return A:FormatMarketPercent(o.pct) end
            if key == "qty" then return o.qty and tostring(o.qty) or "-" end
            if key == "status" then
                local s = o.status or ""
                return "|cff" .. (STATUS_COLOR[s] or "dddddd") .. L[s] .. "|r"
            end
        end,
        onClick = function(o)
            p.selected = o.itemID
            local ok, msg, soft = W:Select(o)
            if not soft then setMessage(ok, msg) end
            p:Refresh()
        end,
        emptyText = L["Noch keine Schnäppchen.\nWächter einschalten und das Auktionshaus offen lassen."],
    })
    p.table:Fill(0, -46, 0, 64)         -- darunter Kaufen-Knöpfe und Zusammenfassung

    p.buyBtn = UI:Button(right, L["Kaufen"], 130, 28, function()
        local ok, msg = Sn:OnTrigger()
        setMessage(ok, msg)
        p:Refresh()
    end, "primary")
    p.buyBtn:SetPoint("TOPLEFT", p.table, "BOTTOMLEFT", 0, -8)
    p.buyBtn.tooltip = L["Gleiche Wirkung wie Mausrad / eigene Taste:\nkauft das nächste bestätigte Schnäppchen (auch Waren mit einem Druck)."]

    p.sniperBtn = UI:Button(right, L["Im Sniper zeigen"], 130, 28, function() UI:SelectTab("sniper") end)
    p.sniperBtn:SetPoint("LEFT", p.buyBtn, "RIGHT", 6, 0)
    p.sniperBtn.tooltip = L["Angebote des Schnäppchens im Tab Sniper ansehen"]

    p.chartBtn = UI:Button(right, L["Preisverlauf"], 110, 28, function()
        if p.selected then UI:OpenChart(p.selected) end
    end)
    p.chartBtn:SetPoint("LEFT", p.sniperBtn, "RIGHT", 6, 0)

    p.summary = UI:Label(right, "", "GameFontHighlight", C.text)
    p.summary:SetPoint("TOPLEFT", p.buyBtn, "BOTTOMLEFT", 0, -8)
    p.summary:SetWidth(470)
    p.summary:SetJustifyH("LEFT")

    function p:Refresh()
        local db = A.db.watcher
        self.enableBtn:SetText(db.enabled and L["Wächter: AN"] or L["Wächter: AUS"])
        self.status:SetText(W:GetStatusText())
        for _, b in ipairs(self.thresholdButtons) do
            b.label:SetTextColor(unpack(b.pct == db.threshold and C.green or C.text))
        end
        if not self.minValue.boxes[1]:HasFocus() and not self.minValue.boxes[2]:HasFocus() and not self.minValue.boxes[3]:HasFocus() then
            self.minValue:SetCopper(db.minValue)
        end
        if not self.budget.boxes[1]:HasFocus() and not self.budget.boxes[2]:HasFocus() and not self.budget.boxes[3]:HasFocus() then
            self.budget:SetCopper(db.budget)
        end
        for _, b in ipairs(self.catButtons) do
            local on = db.cats[b.cat.key]
            b:SetText((on and "|cff33dd55[x]|r " or "|cff777777[ ]|r ") .. L[b.cat.label])
        end
        self.modeLabel:SetText(L["Suche: "] .. W:ModeLabel())
        if db.mode == "single" then self.modeBtn:Show() else self.modeBtn:Hide() end
        local s = W.stats
        self.stats:SetText(string.format(L["Runden %d   |   geprüft %d   |   Schnäppchen %d   |   gesamt %d"],
            s.rounds, s.candidates, s.verified, db.found or 0))
        self.binds:SetText(L["Kaufen mit: |cffffd700"] .. Sn:GetBindsText() .. "|r   " .. Sn:GetStatusText())

        -- Lockangebote gar nicht erst zeigen
        local list = {}
        for _, o in ipairs(W:GetOpportunities()) do if o.status ~= "Lockangebot" then table.insert(list, o) end end
        self.table.selectedID = self.selected
        self.table:SetData(list)

        local plan = Sn:IsResultFresh() and Sn:PlanNext() or nil
        local watchPlan = plan and Sn.extra[plan.key] and plan or nil
        self.buyBtn:SetActive((Sn.pending ~= nil) or watchPlan ~= nil)
        if Sn.pending and Sn.extra[Sn.pending.key] then
            local pd = Sn.pending
            if pd.state == "ready" and pd.auto then
                self.summary:SetText(L["|cff33dd55Nächster Kauf: "] .. pd.qty .. L[" Stück für "] .. A:FormatMoney(pd.total or pd.expected) .. L["|r  ("] .. Sn:GetBindsText() .. ")")
            elseif pd.state == "ready" then
                self.summary:SetText(L["|cff33dd55Reserviert: "] .. pd.qty .. L[" Stück für "] .. A:FormatMoney(pd.total or pd.expected) .. " - " .. Sn:GetBindsText() .. L[" zum Bestätigen|r"])
            else
                self.summary:SetText(L["|cffffcc33Preis wird vom Server geprüft ...|r"])
            end
        elseif watchPlan then
            local extra = ""
            self.summary:SetText(L["|cff33dd55Nächster Kauf: "] .. A:GetItemName(watchPlan.itemID) .. ", " .. watchPlan.qty .. L[" Stück für "]
                .. A:FormatMoney(watchPlan.total) .. extra .. "|r")
        else
            self.summary:SetText("")
        end
    end

    -- regelmäßig auffrischen (Countdown, Status)
    local elapsed = 0
    p:SetScript("OnUpdate", function(self, dt)
        elapsed = elapsed + (dt or 0)
        if elapsed >= 0.5 then
            elapsed = 0
            if A.db.watcher.enabled then self:Refresh() end
        end
    end)

    return p
end

UI:RegisterTab("watcher", "Wächter", 3.55, BuildWatcher)

A:On("WATCHER_CHANGED", function()
    if UI.activeTab == "watcher" or UI.activeTab == "sniper" then UI:RefreshActive() end
end)
