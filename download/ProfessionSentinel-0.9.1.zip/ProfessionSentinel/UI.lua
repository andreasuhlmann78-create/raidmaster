local _, ns = ...
local L = ns.L

-- Panel docked to the profession window of the running game version:
--   WoW Forever: ProfessionsFrame (Blizzard_Professions, Retail-style)
--   Classic Era: TradeSkillFrame (Blizzard_TradeSkillUI) and CraftFrame (Blizzard_CraftUI, enchanting)
-- Two tabs:
--   Recipes  – every recipe of the open profession: learned ones greyed out, missing ones in rarity colour,
--              each with the lifeline (crafts until yellow / green / grey); right-click = waypoint to a vendor
--   Trainers – all trainers of the profession by rank (up to 150 / 225 / 300, specialisations) with zone,
--              coordinates and faction; click = waypoint

local UI = {}
ns.UI = UI

local PANEL_WIDTH = 420
local ROW_HEIGHT = 28

local panel, scrollBox, scrollBar, searchBox, missingCheck, missingLabel, summary, testBadge, infoText
local tabRecipes, tabTrainers, tabRanking, tabDisenchant, tabPlan
local collapsed
local currentHost -- frame the panel is docked to (nil = free-floating test mode)

local function Mode()
    local m = ns.db and ns.db.panelMode
    if m == "trainers" and ns.HasSourceData == false then return "recipes" end
    if m == "trainers" or m == "ranking" or m == "plan" then return m end
    if m == "disenchant" and ns.Disenchant and ns.Disenchant.IsEnchanter() then return m end
    return "recipes"
end

---------------------------------------------------------------------------
-- Current profession and rank
---------------------------------------------------------------------------
local function ForeverProfession()
    if not C_TradeSkillUI then return nil end
    local prof, rank, maxRank
    if C_TradeSkillUI.GetChildProfessionInfo then
        local info = C_TradeSkillUI.GetChildProfessionInfo()
        if info and info.professionID then
            prof = ns.ResolveProf(info.professionID) or ns.ResolveProf(info.parentProfessionID)
            rank, maxRank = info.skillLevel, info.maxSkillLevel
        end
    end
    if not prof and C_TradeSkillUI.GetBaseProfessionInfo then
        local info = C_TradeSkillUI.GetBaseProfessionInfo()
        if info and info.professionID then
            prof = ns.ResolveProf(info.professionID)
            rank = rank or info.skillLevel
            maxRank = maxRank or info.maxSkillLevel
        end
    end
    return prof, rank, maxRank
end

local function EraProfession()
    if currentHost == CraftFrame and GetCraftDisplaySkillLine then
        local name, rank, maxRank = GetCraftDisplaySkillLine()
        return ns.MatchProfession(name), rank, maxRank
    end
    if GetTradeSkillLine then
        local name, rank, maxRank = GetTradeSkillLine()
        return ns.MatchProfession(name), rank, maxRank
    end
end

local function CurrentProfession()
    local prof, rank, maxRank
    if ns.Sim and ns.Sim.prof then
        prof = ns.Sim.prof
        rank, maxRank = ns.Scan:Rank(prof)
    elseif ns.UsesModernProfessions then
        prof, rank, maxRank = ForeverProfession()
    else
        prof, rank, maxRank = EraProfession()
    end
    if prof and not rank then rank, maxRank = ns.Scan:Rank(prof) end
    return prof, ns.EffectiveRank(rank), maxRank
end
UI.CurrentProfession = CurrentProfession

local function IsLearned(r)
    if ns.IsLearned(r) then return true end
    if ns.Sim and ns.Sim.known then return false end
    -- WoW Forever: ask the open profession window directly
    if ns.UsesModernProfessions and C_TradeSkillUI and C_TradeSkillUI.GetRecipeInfo and not (ns.Sim and ns.Sim.prof) then
        local linked = C_TradeSkillUI.IsTradeSkillLinked and C_TradeSkillUI.IsTradeSkillLinked()
        if not linked then
            local info = C_TradeSkillUI.GetRecipeInfo(r.spell)
            if info and info.learned then
                local c = ns.Char(); if c then c.known[r.spell] = true end
                return true
            end
        end
    end
    return false
end

---------------------------------------------------------------------------
-- Colours and texts
---------------------------------------------------------------------------
local DIFF = { red = "ff4040", orange = "ff8040", yellow = "ffd23f", green = "40c040", grey = "808080", white = "ffffff" }

local function SkillLevelsText(r)
    local parts = {}
    if (r.req or 0) > 1 then parts[#parts + 1] = "|cff" .. DIFF.orange .. r.req .. "|r" end
    if (r.yellow or 0) > 0 then
        parts[#parts + 1] = "|cff" .. DIFF.yellow .. r.yellow .. "|r"
        parts[#parts + 1] = "|cff" .. DIFF.green .. r.green .. "|r"
        parts[#parts + 1] = "|cff" .. DIFF.grey .. r.grey .. "|r"
    end
    return table.concat(parts, "  ")
end

local function MoneyText(copper)
    if not copper or copper <= 0 then return "" end
    if GetCoinTextureString then return GetCoinTextureString(copper) end
    return string.format("%dg %ds %dc", copper / 10000, (copper / 100) % 100, copper % 100)
end

---------------------------------------------------------------------------
-- Sources (Trainer / Vendor / Drop ...) with zone and coordinates
---------------------------------------------------------------------------
local function NPCLine(id)
    local WP = ns.Waypoint
    local n = ns.NPCs[id]
    if not n then return "NPC " .. id, true end
    local name, sub, lvl = n[1], n[4], n[5]
    local s = name
    if sub then s = s .. " |cff9d9d9d<" .. sub .. ">|r" end
    local extra = {}
    if lvl then extra[#extra + 1] = L.LEVEL .. " " .. lvl end
    local where = WP.LocationText(id)
    if where then extra[#extra + 1] = where end
    if #extra > 0 then s = s .. " |cffb0b0b0(" .. table.concat(extra, ", ") .. ")|r" end
    return s, (n[3] == nil) or WP.IsFriendly(id)
end

function UI:AddSourceLines(tt, r)
    local S = ns.SRC
    if bit.band(r.src, S.TRAINER) ~= 0 then
        tt:AddLine((r.req or 0) > 1 and string.format(L.SRC_TRAINER_AT, r.req) or L.SRC_TRAINER, 1, 1, 1)
    end
    if bit.band(r.src, S.AUTO) ~= 0 then tt:AddLine(L.SRC_AUTO, 1, 1, 1) end
    for _, ri in ipairs(r.recipeItems) do
        local q = ns.ItemQuality(ri.id)
        local line = "|cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(ri.id) .. "|r"
        if ri.rs then line = line .. "  |cffb0b0b0(" .. L.REQ .. " " .. ri.rs .. ")|r" end
        tt:AddLine(line)
        local rep = ns.RepLine(ri.fa, ri.fr)
        if rep then tt:AddLine("   " .. rep) end
        if ri.v then
            local sorted = {}
            for _, id in ipairs(ri.v) do
                local s, ok = NPCLine(id)
                if ok then table.insert(sorted, 1, { s, ok }) else sorted[#sorted + 1] = { s, ok } end
            end
            for i, e in ipairs(sorted) do
                if i <= 4 then
                    tt:AddLine("   " .. L.SRC_VENDOR .. ": " .. e[1] .. (e[2] and "" or " |cffff6060[" .. L.OTHER_FACTION .. "]|r"), 0.85, 0.85, 0.85)
                end
            end
            if #ri.v > 4 then tt:AddLine("   " .. string.format(L.MORE, #ri.v - 4), 0.6, 0.6, 0.6) end
            if ri.bp then tt:AddLine("   " .. MoneyText(ri.bp), 1, 1, 1) end
        end
        if ri.d then
            if (ri.dn or 0) > 15 then
                tt:AddLine("   " .. string.format(L.SRC_WORLDDROP, ri.dn), 0.85, 0.85, 0.85)
            else
                for i, id in ipairs(ri.d) do
                    if i <= 4 then tt:AddLine("   " .. L.SRC_DROP .. ": " .. (NPCLine(id)), 0.85, 0.85, 0.85) end
                end
                if (ri.dn or #ri.d) > 4 then tt:AddLine("   " .. string.format(L.MORE, (ri.dn or #ri.d) - 4), 0.6, 0.6, 0.6) end
            end
        end
        if ri.qr then tt:AddLine("   " .. string.format(L.SRC_QUEST, ri.qr), 0.85, 0.85, 0.85) end
        if ri.o then tt:AddLine("   " .. string.format(L.SRC_CONTAINER, ri.o), 0.85, 0.85, 0.85) end
        if not (ri.v or ri.d or ri.qr or ri.o) then
            tt:AddLine("   " .. (ns.HasSourceData == false and L.SRC_RETAIL or L.SRC_UNKNOWN), 0.6, 0.6, 0.6)
        end
    end
end

local function LifelineTooltipLines(tt, r, rank)
    local LL = ns.Lifeline
    local c = rank and LL and LL.Calc(r, rank)
    if not c then return end
    tt:AddLine(" ")
    tt:AddLine(L.LL_TITLE, 1, 0.82, 0)
    local parts = {}
    local function add(key, n, exact)
        if n then parts[#parts + 1] = "|cff" .. LL.HEX[key] .. L["LL_" .. key:upper()] .. " " .. (exact and "" or "≈") .. math.floor(n + 0.5) .. "×|r" end
    end
    add("yellow", c.toYellow, true)
    add("green", c.toGreen, c.toYellow and c.toGreen and r.green <= r.yellow)
    add("grey", c.toGrey, false)
    if #parts > 0 then
        tt:AddLine(table.concat(parts, "   "))
    else
        tt:AddLine(c.textColored)
    end
    tt:AddLine(L.LL_TIP_EXACT, 0.6, 0.6, 0.6, true)
end

function UI:ShowRecipeTooltip(owner, r, rank, deMode)
    local tt = GameTooltip
    tt:SetOwner(owner, "ANCHOR_RIGHT")
    local qr, qg, qb = ns.QualityRGB(r.quality)
    tt:AddLine(ns.RecipeName(r), qr, qg, qb)
    if r.cat then tt:AddLine(ns.ProfName(r.prof) .. " - " .. r.cat, 0.7, 0.7, 0.7) end
    if r.isNew then tt:AddLine("|cff3fc7eb" .. L.F_NEW .. "|r") end
    if IsLearned(r) then tt:AddLine(L.ALREADY_LEARNED, 0.5, 0.5, 0.5) end
    local levels = SkillLevelsText(r)
    if levels ~= "" then tt:AddDoubleLine(L.SKILL_LEVELS, levels, 1, 0.82, 0) end
    LifelineTooltipLines(tt, r, rank)
    if r.out then
        local cnt = (r.outMax or 1) > 1 and (r.outMin == r.outMax and (" x" .. r.outMin) or (" x" .. r.outMin .. "-" .. r.outMax)) or ""
        local q = ns.ItemQuality(r.out)
        tt:AddLine(" ")
        tt:AddLine(L.CREATES .. ": |cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(r.out) .. "|r" .. cnt, 1, 0.82, 0)
    elseif r.ench then
        tt:AddLine(" ")
        tt:AddLine(L.ENCHANT, 1, 0.82, 0)
    end
    if #r.reagents > 0 then
        -- reagents with origin and price (variant C breakdown)
        local P = ns.Prices
        local pr = P and P.Recipe(r, deMode)
        tt:AddLine(" ")
        tt:AddLine(L.REAGENTS, 1, 0.82, 0)
        for idx = 1, #r.reagents, 2 do
            local id, need = r.reagents[idx], r.reagents[idx + 1]
            local have = ns.GetItemCount(id)
            local q = ns.ItemQuality(id)
            local col = have >= need and "1eff00" or "ff6060"
            local part = pr and pr.parts[(idx + 1) / 2]
            local left = "|T" .. ns.GetItemIcon(id) .. ":0|t " .. need .. "× |cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(id) .. "|r"
            local right = "|cff" .. col .. have .. "/" .. need .. "|r"
            if part then
                local originText = (ns.Advisor and ns.Advisor.ORIGIN_ICON[part.origin] or "") .. " " ..
                    (part.origin == "vendor" and L.ORIGIN_VENDOR or part.origin == "farm" and L.ORIGIN_FARM or L.ORIGIN_AH)
                if part.known then
                    left = left .. "  |cffa89c84" .. originText .. " · " .. string.format(L.PER_PIECE, P.MoneyPlain(part.unit)) .. "|r"
                    right = P.Money(part.unit * need) .. "  " .. right
                else
                    left = left .. "  |cffa89c84" .. originText .. " · " .. L.NO_PRICE .. "|r"
                end
            end
            tt:AddDoubleLine(left, right)
        end
        if pr then
            tt:AddLine(" ")
            tt:AddDoubleLine(L.COST, P.Money(pr.cost) .. (pr.known and "" or " |cffff6060(?)|r"), 0.66, 0.61, 0.52, 1, 1, 1)
            if pr.valueAH then
                tt:AddDoubleLine(L.SELL_AH, P.Money(pr.valueAH), 0.66, 0.61, 0.52, 1, 1, 1)
                tt:AddDoubleLine(L.AH_CUT, "−" .. P.Money(pr.ahCut), 0.66, 0.61, 0.52, 1, 0.38, 0.38)
                if pr.ahFee then tt:AddDoubleLine(L.AH_FEE, "−" .. P.Money(pr.ahFee), 0.66, 0.61, 0.52, 1, 0.38, 0.38) end
                tt:AddDoubleLine(L.SELL_AH_NET, P.Money(pr.valueAHNet), 0.66, 0.61, 0.52, 1, 1, 1)
            end
            if pr.valueVendor then tt:AddDoubleLine(L.SELL_VENDOR, P.Money(pr.valueVendor), 0.66, 0.61, 0.52, 0.6, 0.6, 0.6) end
            if pr.deGross then
                -- disenchanting: expected materials, then the 5 % cut when selling them
                local label = L.DE_VALUE
                if (pr.deShared or 0) > 0 then label = string.format(L.DE_VALUE_SHARED, pr.deOwn or 0, pr.deShared)
                elseif (pr.deOwn or 0) > 0 then label = string.format(L.DE_VALUE_OWN, pr.deOwn) end
                tt:AddDoubleLine(label, P.Money(pr.deGross) .. (pr.deComplete == false and " |cffff6060+?|r" or ""), 0.66, 0.61, 0.52, 1, 1, 1)
                for _, y in ipairs(pr.deYield or {}) do
                    if y[2] >= 0.005 then
                        tt:AddDoubleLine("   |T" .. ns.GetItemIcon(y[1]) .. ":0|t " .. ns.ItemName(y[1]),
                            string.format(L.DE_CHANCE, math.floor(y[2] * 100 + 0.5), ns.Advisor.Num1(y[3])), 0.66, 0.61, 0.52, 0.8, 0.8, 0.8)
                    end
                end
                tt:AddDoubleLine(L.DE_CUT, "−" .. P.Money(pr.deCut), 0.66, 0.61, 0.52, 1, 0.38, 0.38)
                if pr.deFee then tt:AddDoubleLine(L.AH_FEE, "−" .. P.Money(pr.deFee), 0.66, 0.61, 0.52, 1, 0.38, 0.38) end
                tt:AddDoubleLine(L.DE_NETVALUE, P.Money(pr.deValue), 0.66, 0.61, 0.52, 1, 1, 1)
            end
            -- selling enchants: your price
            local DEm = ns.Disenchant
            if r.ench and r.prof == DEm.ENCHANTING and DEm.WantsSell() then
                local sp = pr.known and DEm.SellPrice(pr.cost)
                if sp then
                    tt:AddDoubleLine(string.format(L.VZ_SURCHARGE, ns.db.vzMarkup or 20), "+" .. P.Money(sp - pr.cost), 0.66, 0.61, 0.52, 0.25, 0.75, 0.25)
                    tt:AddDoubleLine(L.VZ_PRICE, P.Money(sp), 1, 0.82, 0, 1, 1, 1)
                    tt:AddDoubleLine(L.VZ_PRICE_OWNMATS, P.Money(sp - pr.cost), 0.66, 0.61, 0.52, 1, 1, 1)
                    tt:AddLine(L.VZ_WHISPER_HINT, 0.25, 0.78, 0.92)
                else
                    tt:AddLine(L.VZ_NO_PRICE, 1, 0.38, 0.38)
                end
            end
            if pr.known and r.out then
                tt:AddDoubleLine(L.NET_CRAFT, ns.Advisor.NetColored(pr.net), 1, 1, 1)
                if pr.deNet then tt:AddDoubleLine(L.NET_DE, ns.Advisor.NetColored(pr.deNet), 1, 1, 1) end
                if pr.deNet and (pr.value > 0 or pr.deNet > 0) then
                    local via = pr.bestVia == "de" and L.VIA_DE or pr.bestVia == "vendor" and L.VIA_VENDOR or L.VIA_AH
                    tt:AddDoubleLine(L.BEST_USE, "|cffffd100" .. via .. "|r", 1, 0.82, 0)
                end
                local chance = ns.Lifeline.Chance(r, rank or 0)
                if rank and chance > 0 then
                    tt:AddDoubleLine(L.NET_POINT, ns.Advisor.NetColored(pr.net / (chance * (r.skillUps or 1))), 1, 1, 1)
                end
            end
            local src = P.SourceName()
            tt:AddLine(src and string.format(L.PRICE_SOURCE, src) or L.PRICE_NONE, 0.54, 0.5, 0.44)
        end
    end
    -- guild (GuildSentinel / RaidMaster data)
    local GU = ns.Guild
    local crafters = GU and GU.Crafters(r)
    if crafters then
        tt:AddLine(" ")
        if #crafters > 0 then
            tt:AddLine(L.GUILD_CRAFTERS .. ": " .. GU.CraftersText(crafters), 1, 0.82, 0, true)
        else
            tt:AddLine(L.GUILD_NOBODY, 1, 0.5, 0.25)
        end
    end
    tt:AddLine(" ")
    tt:AddLine(L.SOURCES, 1, 0.82, 0)
    self:AddSourceLines(tt, r)
    local best, kind = ns.Waypoint.BestSourceNPC(r)
    if best then
        tt:AddLine(" ")
        tt:AddLine(kind == "drop" and L.WP_RIGHTCLICK_DROP or L.WP_RIGHTCLICK, 0.25, 0.78, 0.92)
    end
    -- place in the ranking (reagents per skill point) and why
    local AD = ns.Advisor
    local e = AD and AD.Entry(r)
    local g = AD and AD.GoldEntry(r)
    if g then
        tt:AddLine(L.GOLD_GROUP:gsub("%s*–.*$", "") .. ": " .. string.format(L.RANKING_PLACE, g.place):gsub("^[^:]*:%s*", "") .. " · " .. AD.NetColored(g.net), 1, 0.82, 0)
    end
    local d = deMode and AD and AD.DEEntry(r)
    if d then
        tt:AddLine(L.DE_GROUP:gsub("%s*–.*$", "") .. ": " .. string.format(L.RANKING_PLACE, d.dePlace):gsub("^[^:]*:%s*", "") .. " · " .. AD.NetColored(d.deNet), 1, 0.82, 0)
    end
    if e then
        tt:AddLine(" ")
        tt:AddLine((AD.IsBest(r.spell) and (AD.STAR .. " ") or "") .. string.format(L.RANKING_PLACE, e.place) .. " · " .. AD.Reason(e), 1, 0.82, 0)
        if not e.learned then
            local src = {}
            local S = ns.SRC
            if bit.band(r.src, S.TRAINER) ~= 0 then src[#src + 1] = L.SRC_TRAINER end
            if bit.band(r.src, S.VENDOR) ~= 0 then src[#src + 1] = L.SRC_VENDOR end
            if bit.band(r.src, S.DROP + S.WORLDDROP) ~= 0 then src[#src + 1] = L.SRC_DROP end
            if bit.band(r.src, S.QUEST) ~= 0 then src[#src + 1] = string.format(L.SRC_QUEST, 1):gsub("%s*%(.*%)", "") end
            if #src > 0 then tt:AddLine(string.format(L.LEARN_WHY, table.concat(src, ", ")), 0.25, 0.78, 0.92, true) end
        elseif AD.IsBest(r.spell) then
            tt:AddLine(L.BEST_WHY, 0.8, 0.8, 0.8, true)
        end
    end
    tt:Show()
end

local function ShowTrainerTooltip(owner, id, rankKey)
    local WP = ns.Waypoint
    local n = ns.NPCs[id]
    if not n then return end
    local tt = GameTooltip
    tt:SetOwner(owner, "ANCHOR_RIGHT")
    tt:AddLine(n[1], 1, 1, 1)
    if n[4] then tt:AddLine("<" .. n[4] .. ">", 0.7, 0.7, 0.7) end
    tt:AddLine(L["RANK_" .. rankKey] or L.RANK_0, 1, 0.82, 0)
    for _, rk in ipairs(WP.RANKS) do
        if rk.key == rankKey and rk.req then tt:AddLine(string.format(L.RANK_REQ, rk.req, rk.level), 0.8, 0.8, 0.8) end
    end
    local where = WP.LocationText(id)
    if where then tt:AddLine(where, 1, 1, 1) end
    if n[3] and not WP.IsFriendly(id) then tt:AddLine(L.OTHER_FACTION, 1, 0.4, 0.4) end
    if WP.Has(id) then tt:AddLine(L.WP_CLICK, 0.25, 0.78, 0.92) end
    tt:Show()
end

---------------------------------------------------------------------------
-- Selecting a learned recipe in the Blizzard window
---------------------------------------------------------------------------
local function SelectInBlizzard(r)
    if ns.UsesModernProfessions then
        if C_TradeSkillUI and C_TradeSkillUI.OpenRecipe then C_TradeSkillUI.OpenRecipe(r.spell) end
        return
    end
    local wanted = { [r.name:lower()] = true }
    if r.nameEN then wanted[r.nameEN:lower()] = true end
    if currentHost == CraftFrame and GetNumCrafts then
        for i = 1, GetNumCrafts() do
            local name = GetCraftInfo(i)
            if name and wanted[name:lower()] then
                if CraftFrame_SetSelection then CraftFrame_SetSelection(i) end
                if CraftFrame_Update then CraftFrame_Update() end
                return
            end
        end
    elseif GetNumTradeSkills then
        for i = 1, GetNumTradeSkills() do
            local name = GetTradeSkillInfo(i)
            if name and wanted[name:lower()] then
                if TradeSkillFrame_SetSelection then TradeSkillFrame_SetSelection(i) end
                if TradeSkillFrame_Update then TradeSkillFrame_Update() end
                return
            end
        end
    end
end

---------------------------------------------------------------------------
-- List rows
---------------------------------------------------------------------------
local function RowIcon(r)
    if r.out then return ns.GetItemIcon(r.out) end
    return ns.GetSpellIcon(r.spell)
end

local function InitHeader(button, node)
    local data = node:GetData()
    if not button.label then
        button:SetHeight(ROW_HEIGHT)
        button.bg = button:CreateTexture(nil, "BACKGROUND")
        button.bg:SetAllPoints()
        button.bg:SetColorTexture(1, 1, 1, 0.06)
        button.arrow = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        button.arrow:SetPoint("LEFT", 4, 0)
        button.label = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        button.label:SetPoint("LEFT", 20, 0)
        button.label:SetPoint("RIGHT", -60, 0)
        button.label:SetJustifyH("LEFT")
        button.label:SetWordWrap(false)
        button.count = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        button.count:SetPoint("RIGHT", -6, 0)
        button:SetHighlightTexture("Interface\\Buttons\\UI-Listbox-Highlight2", "ADD")
        button:GetHighlightTexture():SetAlpha(0.2)
    end
    button.label:SetText(data.name)
    button.count:SetText(data.countText or (data.known .. "/" .. data.total))
    button.arrow:SetText(node:IsCollapsed() and "+" or "-")
    button:SetScript("OnClick", function()
        node:ToggleCollapsed()
        local key = data.key or data.name
        if key == "guild-nobody" then
            collapsed[key] = node:IsCollapsed() and true or false   -- collapsed by default: remember "open" as false
        else
            collapsed[key] = node:IsCollapsed() or nil
        end
        button.arrow:SetText(node:IsCollapsed() and "+" or "-")
    end)
    button:SetScript("OnEnter", data.tip and function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(data.name, 1, 0.82, 0)
        GameTooltip:AddLine(data.tip, 1, 1, 1, true)
        GameTooltip:Show()
    end or nil)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

-- Both recipe and trainer rows use the same pooled Button: create every widget once,
-- and each initializer sets (or hides) all of them.
local function EnsureRow(button)
    if button.name then return end
    button:SetHeight(ROW_HEIGHT)
    button.check = button:CreateTexture(nil, "OVERLAY")
    button.check:SetSize(14, 14)
    button.check:SetPoint("TOPLEFT", 4, -3)
    button.check:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready")
    button.icon = button:CreateTexture(nil, "ARTWORK")
    button.icon:SetSize(16, 16)
    button.icon:SetPoint("TOPLEFT", 22, -2)
    button.name = button:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    button.name:SetPoint("LEFT", button.icon, "RIGHT", 6, 0)
    button.name:SetPoint("RIGHT", button, "RIGHT", -70, 0)
    button.name:SetJustifyH("LEFT")
    button.name:SetWordWrap(false)
    button.new = button:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    button.new:SetPoint("TOPRIGHT", -38, -4)
    button.new:SetTextColor(0.25, 0.78, 0.92)
    button.skill = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    button.skill:SetPoint("TOPRIGHT", -6, -4)
    button.skill:SetJustifyH("RIGHT")
    button.line = ns.Lifeline.Create(button, 2)
    button.line:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 44, 5)
    button.line:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -112, 5)
    button.hint = button:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
    button.hint:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -6, 2)
    button.hint:SetWidth(104)
    button.hint:SetJustifyH("RIGHT")
    button.hint:SetWordWrap(false)
    button.where = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    button.where:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 44, 3)
    button.where:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -6, 3)
    button.where:SetJustifyH("LEFT")
    button.where:SetWordWrap(false)
    button:SetHighlightTexture("Interface\\Buttons\\UI-Listbox-Highlight2", "ADD")
    button:GetHighlightTexture():SetAlpha(0.25)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
end

local function InitRecipeRow(button, data)
    local r = data.recipe
    local learned = data.learned
    button.where:Hide()
    button.icon:Show()
    button.icon:SetTexture(RowIcon(r))
    button.icon:SetDesaturated(learned)
    button.icon:SetAlpha(learned and 0.5 or 1)
    button.check:SetShown(learned)
    local qr, qg, qb = ns.QualityRGB(r.quality)
    local isBest = ns.Advisor and ns.Advisor.IsBest(r.spell) and ns.db.best ~= false
    local prefix = data.place and ("|cffffd100" .. data.place .. ".|r ") or ""
    button.name:SetText(prefix .. (isBest and (ns.Advisor.STAR .. " ") or "") .. ns.RecipeName(r))
    if learned and not data.suggest then
        -- leicht ausgegraut: rarity colour mixed with grey and dimmed
        button.name:SetTextColor(qr * 0.4 + 0.3, qg * 0.4 + 0.3, qb * 0.4 + 0.3)
        button.name:SetAlpha(0.6)
    else
        button.name:SetTextColor(qr, qg, qb)
        button.name:SetAlpha(1)
    end
    if data.suggest and not learned then
        button.new:SetText("|cff3fc7eb" .. L.TAG_LEARN .. "|r")
    else
        button.new:SetText(r.isNew and L.NEW_TAG or "")
    end
    local lvl = (r.req or 0) > 1 and r.req or (r.yellow or 0)
    local calc = ns.Lifeline.Calc(r, data.rank)
    local stateHex = calc and ns.Lifeline.HEX[calc.state] or "ffffff"
    button.skill:SetText(lvl > 0 and ("|cff" .. stateHex .. lvl .. "|r") or "")
    button.skill:SetAlpha(learned and 0.6 or 1)
    if data.suggest then
        -- ranking rows (variant D): full brightness, origin dots next to the skill, gold value instead of the hint
        ns.Lifeline.Update(button.line, r, data.rank, false)
        local e = data.entry
        if e then
            button.skill:SetText(ns.Advisor.OriginDots(e) .. " " .. (button.skill:GetText() or ""))
            if data.planStep then
                button.hint:SetText("|cffffd100" .. data.planStep.crafts .. "×|r |cffb0b0b0" .. data.planStep.from .. "–" .. data.planStep.to .. "|r")
            elseif data.sell then
                local pr = e.price
                local sp = pr and pr.known and ns.Disenchant.SellPrice(pr.cost)
                button.hint:SetText(sp and ("|cff40c040" .. L.VZ_PRICE_SHORT .. " " .. ns.Prices.MoneyPlain(sp) .. "|r")
                    or ("|cffffd100" .. L.MAT_COST .. " " .. (pr and pr.cost > 0 and ns.Prices.MoneyPlain(pr.cost) or "?") .. "?|r"))
            elseif data.de then
                button.hint:SetText(ns.Advisor.NetColored(e.deNet))
            elseif data.gold then
                button.hint:SetText(ns.Advisor.NetColored(e.net))
            else
                button.hint:SetText(ns.Advisor.ValueColored(e))
            end
        else
            button.hint:SetText("|cffffd100" .. (data.reason or "") .. "|r")
        end
        button.hint:SetAlpha(1)
        button.hint:Show()
        button.skill:SetAlpha(1)
        button.icon:SetDesaturated(false)
        button.icon:SetAlpha(1)
    elseif ns.db.lifeline ~= false then
        ns.Lifeline.Update(button.line, r, data.rank, learned)
        button.hint:SetText(calc and calc.textColored or "")
        button.hint:SetAlpha(learned and 0.6 or 1)
        button.hint:Show()
    else
        button.line:Hide()
        button.hint:Hide()
    end
    button:SetScript("OnEnter", function(self) UI:ShowRecipeTooltip(self, r, data.rank, data.de) end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    button:SetScript("OnClick", function(_, mouse)
        if mouse == "RightButton" and data.sell then
            ns.Disenchant.WhisperOffer(r)
            return
        end
        if mouse == "RightButton" then
            local id = ns.Waypoint.BestSourceNPC(r)
            if id then ns.Waypoint.Set(id, ns.NPCs[id][1] .. " – " .. ns.RecipeName(r)) end
            return
        end
        if IsModifiedClick and IsModifiedClick("CHATLINK") then
            local link = r.recipeItems[1] and ns.GetItemLink(r.recipeItems[1].id) or (r.out and ns.GetItemLink(r.out))
            if link and ChatEdit_InsertLink then ChatEdit_InsertLink(link) end
            return
        end
        if learned and not (ns.Sim and ns.Sim.prof) then SelectInBlizzard(r) end
    end)
end

local function InitTrainerRow(button, data)
    local WP = ns.Waypoint
    local id = data.npc
    local n = ns.NPCs[id]
    local friendly = (n and n[3] == nil) or WP.IsFriendly(id)
    button.check:Hide()
    button.line:Hide()
    button.hint:Hide()
    button.icon:Show()
    local fac = n and n[3]
    if fac == "H" then button.icon:SetTexture("Interface\\TargetingFrame\\UI-PVP-Horde")
    elseif fac == "A" then button.icon:SetTexture("Interface\\TargetingFrame\\UI-PVP-Alliance")
    else button.icon:SetTexture("Interface\\Minimap\\Tracking\\Profession") end
    button.icon:SetDesaturated(false)
    button.icon:SetAlpha(friendly and 1 or 0.4)
    button.name:SetText((n and n[1] or ("NPC " .. id)) .. (n and n[4] and (" |cff9d9d9d<" .. n[4] .. ">|r") or ""))
    button.name:SetTextColor(1, 1, 1)
    button.name:SetAlpha(friendly and 1 or 0.45)
    button.new:SetText("")
    button.skill:SetText(n and n[5] and ("|cffb0b0b0" .. L.LEVEL .. " " .. n[5] .. "|r") or "")
    button.skill:SetAlpha(friendly and 1 or 0.45)
    local where = WP.LocationText(id) or ""
    if not friendly and fac then where = where .. "  |cffff6060[" .. L.OTHER_FACTION .. "]|r" end
    button.where:SetText("|cffd0c0a0" .. where .. "|r")
    button.where:SetAlpha(friendly and 1 or 0.6)
    button.where:Show()
    button:SetScript("OnEnter", function(self) ShowTrainerTooltip(self, id, data.rankKey) end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    button:SetScript("OnClick", function() WP.Set(id, n and n[1]) end)
end

-- Simple info rows (disenchant tab): icon, name, value top right, detail line below, tooltip
local function InitInfoRow(button, data)
    button.check:Hide()
    button.line:Hide()
    button.hint:Hide()
    button.icon:SetShown(data.icon ~= nil)
    if data.icon then button.icon:SetTexture(data.icon) end
    button.icon:SetDesaturated(false)
    button.icon:SetAlpha(1)
    button.name:SetText(data.text or "")
    button.name:SetTextColor(1, 1, 1)
    button.name:SetAlpha(1)
    button.new:SetText("")
    button.skill:SetText(data.value or "")
    button.skill:SetAlpha(1)
    button.where:SetText(data.detail or "")
    button.where:SetAlpha(1)
    button.where:Show()
    button:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        if data.itemID then GameTooltip:SetItemByID(data.itemID) end
        for _, l in ipairs(data.tip or {}) do
            if type(l) == "table" then GameTooltip:AddDoubleLine(l[1], l[2], 0.8, 0.8, 0.8, 1, 1, 1)
            else GameTooltip:AddLine(l, 1, 1, 1, true) end
        end
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    button:SetScript("OnClick", function()
        if data.onClick then data.onClick(); return end
        if data.itemID and IsModifiedClick and IsModifiedClick("CHATLINK") then
            local link = select(2, GetItemInfo(data.itemID))
            if link and ChatEdit_InsertLink then ChatEdit_InsertLink(link) end
        end
    end)
end

local function InitRow(button, node)
    EnsureRow(button)
    local data = node:GetData()
    if data.npc then InitTrainerRow(button, data)
    elseif data.info then InitInfoRow(button, data)
    else InitRecipeRow(button, data) end
end

local function MatchesSearch(r, text)
    if text == "" then return true end
    if r.searchText:find(text, 1, true) then return true end
    if r.out and ns.ItemName(r.out):lower():find(text, 1, true) then return true end
    for i = 1, #r.reagents, 2 do
        if ns.ItemName(r.reagents[i]):lower():find(text, 1, true) then return true end
    end
    return false
end

---------------------------------------------------------------------------
-- Refresh
---------------------------------------------------------------------------
local function UpdateTabs()
    if not tabRecipes then return end
    local m = Mode()
    tabRecipes:SetText((m == "recipes" and "> " or "") .. L.RECIPES_TAB .. (m == "recipes" and " <" or ""))
    tabRanking:SetText((m == "ranking" and "> " or "") .. L.RANKING_TAB .. (m == "ranking" and " <" or ""))
    tabTrainers:SetText((m == "trainers" and "> " or "") .. L.TRAINERS .. (m == "trainers" and " <" or ""))
    tabTrainers:SetShown(ns.HasSourceData ~= false)    -- Retail: no trainer data
    tabPlan:SetText((m == "plan" and "> " or "") .. L.PLAN_TAB .. (m == "plan" and " <" or ""))
    tabDisenchant:SetText((m == "disenchant" and "> " or "") .. L.DE_TAB .. (m == "disenchant" and " <" or ""))
    tabDisenchant:SetShown(ns.Disenchant and ns.Disenchant.IsEnchanter() or false)
    missingCheck:SetShown(m == "recipes")
    missingLabel:SetShown(m == "recipes")
end

local function RefreshRecipes(prof, rank, maxRank, text)
    local onlyMissing = missingCheck:GetChecked()
    local dp = CreateTreeDataProvider()
    local cats, order = {}, {}
    local total, known = 0, 0
    for _, r in ipairs(ns.ByProf[prof] or {}) do
        local learned = IsLearned(r)
        total = total + 1
        if learned then known = known + 1 end
        if MatchesSearch(r, text) and not (onlyMissing and learned) then
            local cname = r.cat or ns.ProfName(prof)
            local c = cats[cname]
            if not c then
                c = { name = cname, items = {}, known = 0, total = 0 }
                cats[cname] = c
                order[#order + 1] = c
            end
            c.total = c.total + 1
            if learned then c.known = c.known + 1 end
            c.items[#c.items + 1] = { recipe = r, learned = learned, rank = rank }
        end
    end
    -- recipe alarm: recipes you or your characters miss that are in the AH right now (AHSentinel)
    local AL = ns.Alerts
    if AL and ns.db.recipeAlert ~= false and text == "" then
        local found = AL.FromCurrent()
        local mine = {}
        for _, f in ipairs(found) do if f.recipe.prof == prof then mine[#mine + 1] = f end end
        if #mine > 0 then
            local ha = dp:Insert({ header = true, key = "alerts", name = L.ALERT_GROUP, countText = tostring(#mine), tip = L.ALERT_EXPLAIN })
            for _, f in ipairs(mine) do
                local q = ns.ItemQuality(f.itemID)
                ha:Insert({ info = true, itemID = f.itemID, icon = ns.GetItemIcon(f.itemID),
                    text = "|cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(f.itemID) .. "|r",
                    value = ns.Prices.Money(f.price),
                    detail = "|cffd0c0a0" .. string.format(L.ALERT_WHO, table.concat(f.who, ", ")) .. "|r",
                    onClick = function() AL.ToSniper(f) end, tip = { " ", L.ALERT_CLICK } })
            end
            if collapsed["alerts"] then ha:SetCollapsed(true) end
        end
    end

    -- recipes in your bags (all professions): who needs them – or nobody
    if AL and text == "" then
        local bag = AL.BagRecipes()
        if #bag > 0 then
            local hbg = dp:Insert({ header = true, key = "bag-recipes", name = L.BAG_GROUP, countText = tostring(#bag), tip = L.BAG_EXPLAIN })
            for _, b in ipairs(bag) do
                local q = ns.ItemQuality(b.itemID)
                local detail
                if #b.who > 0 then
                    detail = "|cff40c040" .. string.format(L.BAG_NEEDED, table.concat(b.who, ", ")) .. "|r"
                else
                    local worth = b.ah and (L.ORIGIN_AH .. " ~" .. ns.Prices.MoneyPlain(b.ah)) or (b.vendor and (L.ORIGIN_VENDOR .. " " .. ns.Prices.MoneyPlain(b.vendor))) or ""
                    detail = "|cffffd100" .. L.BAG_NOBODY .. (worth ~= "" and (" – " .. worth) or "") .. "|r"
                end
                hbg:Insert({ info = true, itemID = b.itemID, icon = ns.GetItemIcon(b.itemID),
                    text = "|cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(b.itemID) .. "|r" .. (b.count > 1 and (" ×" .. b.count) or ""),
                    value = "|cffb0b0b0" .. ns.ProfName(b.recipe.prof) .. "|r", detail = detail })
            end
            if collapsed["bag-recipes"] then hbg:SetCollapsed(true) end
        end
    end

    -- ranking top 10 on top (only without a search)
    local AD = ns.Advisor
    if AD and ns.db.best ~= false and text == "" and rank then
        local ranking = AD.current.ranking or {}
        if #ranking > 0 then
            local priced = ranking[1].netPerPoint ~= nil
            local h = dp:Insert({ header = true, key = "ranking-top",
                name = AD.STAR .. " " .. (priced and L.LEVEL_TOP or L.RANKING_TOP),
                countText = "", tip = priced and L.LEVEL_EXPLAIN or L.RANKING_EXPLAIN })
            local shown = 0
            for _, e in ipairs(ranking) do
                if not (onlyMissing and e.learned) then
                    h:Insert({ recipe = e.recipe, learned = e.learned, rank = rank, suggest = true,
                        place = e.place, entry = e, reason = AD.Reason(e, true) })
                    shown = shown + 1
                    if shown >= 10 then break end
                end
            end
            if collapsed["ranking-top"] then h:SetCollapsed(true) end
        end
    end
    -- guild cooldowns of this profession (GuildSentinel)
    local GU = ns.Guild
    local cds = GU and text == "" and GU.Cooldowns(prof)
    if cds and #cds > 0 then
        local hc = dp:Insert({ header = true, key = "cooldowns", name = L.CD_GROUP, countText = "", tip = L.CD_EXPLAIN })
        for _, c in ipairs(cds) do
            local parts = {}
            for i, e in ipairs(c.list) do
                if i > 6 then parts[#parts + 1] = string.format(L.MORE, #c.list - 6); break end
                parts[#parts + 1] = (e.online and "|cffffffff" or "|cff9d9d9d") .. e.name .. "|r " .. GU.LeftText(e.left)
            end
            hc:Insert({ info = true, icon = ns.GetItemIcon(c.key == "transmute" and 12360 or c.key == "mooncloth" and 14342 or 15846),
                text = c.label, value = "", detail = table.concat(parts, " · ") })
        end
        if collapsed["cooldowns"] then hc:SetCollapsed(true) end
    end
    for _, c in ipairs(order) do
        local header = dp:Insert({ header = true, name = c.name, known = c.known, total = c.total })
        for _, item in ipairs(c.items) do header:Insert(item) end
        if collapsed[c.name] and text == "" then header:SetCollapsed(true) end
    end
    -- recipes nobody in the guild knows (needs GuildSentinel / RaidMaster data); collapsed by default
    local nobody = GU and text == "" and GU.NobodyKnows(prof)
    if nobody and #nobody > 0 then
        local hn = dp:Insert({ header = true, key = "guild-nobody", name = L.GUILD_NOBODY_GROUP, countText = tostring(#nobody), tip = L.GUILD_NOBODY_EXPLAIN })
        for _, r in ipairs(nobody) do hn:Insert({ recipe = r, learned = IsLearned(r), rank = rank }) end
        if collapsed["guild-nobody"] ~= false then hn:SetCollapsed(true) end
    end
    scrollBox:SetDataProvider(dp, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition)
    local rankText = rank and string.format("   %s: %d%s", L.YOUR_SKILL, rank, maxRank and maxRank > 0 and ("/" .. maxRank) or "") or ""
    summary:SetText(string.format("%d/%d %s%s", known, total, L.KNOWN, rankText))
end

-- "Heute herstellen": the most profitable crafts of all professions, one click = next step
local function InsertToday(dp, text)
    local TD = ns.Today
    if not TD or text ~= "" then return end
    local list = TD.Candidates()
    local P = ns.Prices
    local ht = dp:Insert({ header = true, key = "today", name = L.TODAY_GROUP, countText = tostring(#list),
        tip = P and P.SourceName() and L.TODAY_EXPLAIN or L.GOLD_NONE })
    for _, e in ipairs(list) do
        local r = e.recipe
        local q = ns.ItemQuality(r.out)
        ht:Insert({ info = true, itemID = r.out, icon = ns.GetItemIcon(r.out),
            text = "|cffffd100" .. e.count .. "×|r |cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(r.out) .. "|r",
            value = ns.Advisor.NetColored(e.net),
            detail = "|cff40c0ff>> " .. TD.StepText(e) .. "|r  |cffb0b0b0" .. string.format(L.TODAY_PER_CRAFT, P.MoneyPlain(e.perCraft, true)) .. "|r",
            onClick = function() TD.Run(e) end,
            tip = { ns.RecipeName(r) .. " – " .. ns.ProfName(r.prof), " ", L.TODAY_CLICK, " ", L.TODAY_EXPLAIN } })
    end
    if #list == 0 then
        ht:Insert({ info = true, text = "|cffb0b0b0" .. (P and P.SourceName() and L.TODAY_NONE or L.GOLD_NONE) .. "|r" })
    end
    if collapsed["today"] then ht:SetCollapsed(true) end
end

local function RefreshRanking(prof, rank, maxRank, text)
    local AD = ns.Advisor
    local P = ns.Prices
    local dp = CreateTreeDataProvider()
    InsertToday(dp, text)
    local ranking = AD and AD.current.ranking or {}
    local gold = AD and AD.current.gold or {}
    local learnedN, learnN = 0, 0
    local priced = ranking[1] and ranking[1].netPerPoint ~= nil

    -- 1. Levelling: gold per skill point (or reagents per point without prices)
    local h = dp:Insert({ header = true, key = "ranking", name = priced and L.LEVEL_GROUP or L.LEVEL_GROUP_NOPRICE,
        countText = tostring(#ranking), tip = L.LEVEL_EXPLAIN })
    for _, e in ipairs(ranking) do
        if e.learned then learnedN = learnedN + 1 else learnN = learnN + 1 end
        if MatchesSearch(e.recipe, text) then
            h:Insert({ recipe = e.recipe, learned = e.learned, rank = rank, suggest = true,
                place = e.place, entry = e, reason = AD.Reason(e, true) })
        end
    end
    if collapsed["ranking"] and text == "" then h:SetCollapsed(true) end

    -- 2. Making gold: net profit per craft, grey recipes included
    local g = dp:Insert({ header = true, key = "gold", name = L.GOLD_GROUP, countText = tostring(#gold),
        tip = #gold > 0 and L.GOLD_EXPLAIN or L.GOLD_NONE })
    for _, e in ipairs(gold) do
        if MatchesSearch(e.recipe, text) then
            g:Insert({ recipe = e.recipe, learned = e.learned, rank = rank, suggest = true, gold = true,
                place = e.place, entry = e })
        end
    end
    if collapsed["gold"] and text == "" then g:SetCollapsed(true) end

    scrollBox:SetDataProvider(dp, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition)
    local src = P and P.SourceName()
    local priceLine = src and string.format(L.PRICE_SOURCE, src) or L.PRICE_NONE
    if not rank then
        summary:SetText(L.OPEN_PROF_FIRST)
    elseif #ranking == 0 then
        summary:SetText(L.RANKING_NONE .. "\n" .. priceLine)
    else
        summary:SetText(string.format(L.RANKING_SUMMARY, #ranking, rank, learnedN, learnN) .. "\n" .. priceLine)
    end
end

local function RefreshPlan(prof, rank, maxRank, text)
    local PL, P, AD = ns.Plan, ns.Prices, ns.Advisor
    local dp = CreateTreeDataProvider()
    if not rank then
        scrollBox:SetDataProvider(dp)
        summary:SetText(L.OPEN_PROF_FIRST)
        return
    end
    local plan = PL.Build(prof, rank, maxRank)

    -- target (click: next cap)
    local ht = dp:Insert({ header = true, key = "plan-target", name = L.PLAN_HEADER, countText = "" })
    ht:Insert({ info = true, icon = "Interface\\Icons\\INV_Misc_Note_01",
        text = string.format(L.PLAN_TARGET_ROW, rank, plan.to), detail = "|cffb0b0b0" .. (ns.IsRetail and L.PLAN_TARGET_RETAIL or L.PLAN_TARGET_CLICK) .. "|r",
        onClick = function() PL.CycleTarget(prof, rank, maxRank) end, tip = { L.PLAN_EXPLAIN } })

    -- steps
    local hs = dp:Insert({ header = true, key = "plan-steps", name = L.PLAN_STEPS, countText = tostring(#plan.steps),
        tip = L.PLAN_EXPLAIN })
    for i, st in ipairs(plan.steps) do
        if MatchesSearch(st.recipe, text) then
            hs:Insert({ recipe = st.recipe, learned = st.learned, rank = st.from, suggest = true, place = i,
                planStep = st, entry = { price = P and P.SourceName() and P.Recipe(st.recipe) or nil, recipe = st.recipe } })
        end
    end
    if plan.reached < plan.to then
        hs:Insert({ info = true, text = "|cffff6060" .. string.format(L.PLAN_STUCK, plan.reached) .. "|r",
            detail = "|cffb0b0b0" .. L.PLAN_STUCK_HINT .. "|r" })
    end
    if collapsed["plan-steps"] and text == "" then hs:SetCollapsed(true) end

    -- shopping list + buttons
    local missingN = 0
    for _, e in ipairs(plan.list) do if e.missing > 0 then missingN = missingN + 1 end end
    local hb = dp:Insert({ header = true, key = "plan-shop", name = L.PLAN_SHOPPING, countText = missingN .. "/" .. #plan.list,
        tip = L.PLAN_SHOPPING_EXPLAIN })
    local merchant = PL.MerchantOpen()
    hb:Insert({ info = true, icon = "Interface\\Icons\\INV_Misc_Bag_10",
        text = (merchant and "|cff40c040" or "|cff808080") .. L.PLAN_VENDOR_BTN .. "|r",
        detail = "|cffb0b0b0" .. (merchant and string.format(L.PLAN_VENDOR_DETAIL, P.MoneyPlain(plan.totals.vendor)) or L.PLAN_NO_MERCHANT) .. "|r",
        onClick = merchant and PL.BuyFromVendor or nil })
    local hasSniper = ns.Disenchant.Sniper() ~= nil
    hb:Insert({ info = true, icon = "Interface\\Icons\\Ability_Hunter_SniperShot",
        text = (hasSniper and "|cff40c040" or "|cff808080") .. L.PLAN_SNIPE_BTN .. "|r",
        detail = "|cffb0b0b0" .. (hasSniper and string.format(L.PLAN_SNIPE_DETAIL, PL.TOLERANCE, P.MoneyPlain(plan.totals.ah)) or L.SNIPE_NEED_AHS) .. "|r",
        onClick = hasSniper and PL.ToSniper or nil, tip = { L.PLAN_SNIPE_TIP, " ", L.SNIPE_BUDGET } })
    for _, e in ipairs(plan.list) do
        local name = ns.ItemName(e.id)
        if text == "" or name:lower():find(text, 1, true) then
            local q = ns.ItemQuality(e.id)
            local origin = e.origin == "vendor" and L.ORIGIN_VENDOR or e.origin == "farm" and L.ORIGIN_FARM or L.ORIGIN_AH
            local price = e.known and string.format(L.PER_PIECE, P.MoneyPlain(e.unit)) or L.NO_PRICE
            hb:Insert({ info = true, itemID = e.id, icon = ns.GetItemIcon(e.id),
                text = "|cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. name .. "|r",
                value = e.missing > 0 and ("|cffff6060" .. string.format(L.PLAN_MISSING, e.missing) .. "|r") or ("|cff40c040" .. L.PLAN_HAVE_ALL .. "|r"),
                detail = "|cffd0c0a0" .. string.format(L.PLAN_ITEM_LINE, e.need, e.have, (ns.Advisor.ORIGIN_ICON[e.origin] or "") .. " " .. origin, price) .. "|r" })
        end
    end
    if collapsed["plan-shop"] and text == "" then hb:SetCollapsed(true) end

    scrollBox:SetDataProvider(dp, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition)
    local line = string.format(L.PLAN_SUMMARY, #plan.steps, plan.from, plan.reached)
    if plan.priced then
        line = line .. "\n" .. string.format(L.PLAN_COST, P.MoneyPlain(plan.cost), P.MoneyPlain(plan.value), AD.NetColored(plan.value - plan.cost))
    end
    summary:SetText(line)
end

local QUALITY_WORD = { [2] = "DE_Q2", [3] = "DE_Q3", [4] = "DE_Q4" }

local function GroupTitle(g)
    local q = L[QUALITY_WORD[g.quality] or "DE_Q2"]
    local kind = g.quality == 2 and (" · " .. (g.weapon and L.DE_WEAPON or L.DE_ARMOR)) or ""
    return "|cff" .. (ns.QUALITY_HEX[g.quality] or "ffffff") .. q .. "|r" .. kind .. " · " .. string.format(L.DE_ILVL, g.from or 0, g.to or 0)
end

local function RefreshDisenchant(prof, rank, maxRank, text)
    local DE = ns.Disenchant
    local AD = ns.Advisor
    local P = ns.Prices
    local dp = CreateTreeDataProvider()
    local hasAHS = DE and DE.AHS() ~= nil
    local wantsGold, wantsSell = DE.WantsGold(), DE.WantsSell()

    -- goal of this enchanter (click to change)
    local goal = DE.Goal()
    local hg = dp:Insert({ header = true, key = "de-goal", name = L.GOAL_HEADER, countText = "" })
    hg:Insert({ info = true, icon = "Interface\\Icons\\Trade_Engraving",
        text = string.format(L.GOAL_CURRENT, L["GOAL_" .. goal:upper()]),
        detail = "|cffb0b0b0" .. L.GOAL_CLICK .. "|r", onClick = DE.AskGoal,
        tip = { L.GOAL_QUESTION, " ", L.GOAL_GOLD .. ": " .. L.GOAL_GOLD_TIP, L.GOAL_SELL .. ": " .. L.GOAL_SELL_TIP, L.GOAL_BOTH .. ": " .. L.GOAL_BOTH_TIP } })

    -- selling enchants: material cost of every learned enchant
    if wantsSell then
        local list = {}
        for _, id in ipairs(DE.EnchantProfs()) do
            for _, r in ipairs(ns.ByProf[id] or {}) do
                if ns.IsLearned(r) and r.ench and r.reagents and #r.reagents > 0 then list[#list + 1] = r end
            end
        end
        table.sort(list, function(a, b)
            if (a.yellow or 0) ~= (b.yellow or 0) then return (a.yellow or 0) > (b.yellow or 0) end
            return (a.name or "") < (b.name or "")
        end)
        local hs = dp:Insert({ header = true, key = "de-sell", name = L.SELL_GROUP, countText = tostring(#list), tip = L.SELL_EXPLAIN })
        for _, r in ipairs(list) do
            if MatchesSearch(r, text) then
                local erank = ns.Scan and ns.Scan:Rank(r.prof) or rank
                hs:Insert({ recipe = r, learned = true, rank = erank, suggest = true, sell = true,
                    entry = { price = P.Recipe(r), recipe = r } })
            end
        end
        if collapsed["de-sell"] and text == "" then hs:SetCollapsed(true) end
        -- your wish for the selling price
        hg:Insert({ info = true, icon = "Interface\\Icons\\INV_Misc_Coin_02",
            text = string.format(L.VZ_MARKUP_ROW, ns.db.vzMarkup or 20), detail = "|cffb0b0b0" .. L.GOAL_CLICK .. "|r",
            onClick = DE.EditMarkup, tip = { L.VZ_PRICE_EXPLAIN } })
        hg:Insert({ info = true, icon = "Interface\\Icons\\INV_Misc_Coin_01",
            text = string.format(L.VZ_MIN_ROW, P.MoneyPlain(ns.db.vzMinProfit or 0)), detail = "|cffb0b0b0" .. L.GOAL_CLICK .. "|r",
            onClick = DE.EditMinProfit, tip = { L.VZ_PRICE_EXPLAIN } })
    end

    if not wantsGold then
        scrollBox:SetDataProvider(dp, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition)
        summary:SetText(L.SELL_SUMMARY .. "\n" .. ((P.SourceName() and string.format(L.PRICE_SOURCE, P.SourceName())) or L.PRICE_NONE))
        return
    end

    -- minimum margin and the sniper buttons (AHSentinel)
    local hm = dp:Insert({ header = true, key = "de-sniper", name = L.SNIPE_HEADER, countText = "", tip = L.SNIPE_EXPLAIN })
    hm:Insert({ info = true, icon = "Interface\\Icons\\INV_Misc_Coin_02",
        text = string.format(L.DE_MARGIN_ROW, ns.db.deMargin or 20), detail = "|cffb0b0b0" .. L.GOAL_CLICK .. "|r",
        onClick = DE.EditMargin, tip = { L.DE_MARGIN_EXPLAIN } })
    local hasSniper = DE.Sniper() ~= nil
    hm:Insert({ info = true, icon = "Interface\\Icons\\Ability_Hunter_SniperShot",
        text = (hasSniper and "|cff40c040" or "|cff808080") .. L.SNIPE_ITEMS_BTN .. "|r",
        detail = "|cffb0b0b0" .. (hasSniper and L.SNIPE_ITEMS_DETAIL or L.SNIPE_NEED_AHS) .. "|r",
        onClick = hasSniper and DE.SnipeDeals or nil, tip = { L.SNIPE_ITEMS_TIP, " ", L.SNIPE_BUDGET } })
    hm:Insert({ info = true, icon = "Interface\\Icons\\INV_Fabric_Linen_01",
        text = (hasSniper and "|cff40c040" or "|cff808080") .. L.SNIPE_MATS_BTN .. "|r",
        detail = "|cffb0b0b0" .. (hasSniper and string.format(L.SNIPE_MATS_DETAIL, DE.SNIPE_RECIPES, DE.SNIPE_CRAFTS) or L.SNIPE_NEED_AHS) .. "|r",
        onClick = hasSniper and DE.SnipeReagents or nil, tip = { L.SNIPE_MATS_TIP, " ", L.SNIPE_BUDGET } })
    if collapsed["de-sniper"] and text == "" then hm:SetCollapsed(true) end

    -- 1. Bargains in the AH (from AHSentinel's latest prices)
    local deals = hasAHS and DE.Deals(30) or nil
    local h1 = dp:Insert({ header = true, key = "de-deals", name = L.DE_DEALS, countText = deals and tostring(#deals) or "–",
        tip = hasAHS and L.DE_DEALS_EXPLAIN or L.DE_NEED_AHS })
    for _, d in ipairs(deals or {}) do
        local name = ns.ItemName(d.itemID)
        if d.name and d.name ~= "" and name:find("^Item ") then name = d.name end
        if text == "" or name:lower():find(text, 1, true) then
            local q = ns.ItemQuality(d.itemID)
            h1:Insert({ info = true, itemID = d.itemID, icon = ns.GetItemIcon(d.itemID),
                text = "|cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. name .. "|r" .. ((d.quantity or 1) > 1 and (" |cffb0b0b0×" .. d.quantity .. "|r") or ""),
                value = AD.NetColored(d.profit),
                detail = "|cffd0c0a0" .. string.format(L.DE_DEAL_LINE, P.MoneyPlain(d.price), P.MoneyPlain(d.net)) .. "|r",
                tip = { " ", { L.DE_DEAL_PRICE, P.Money(d.price) }, { L.DE_VALUE, P.Money(d.value) },
                        { L.DE_NETVALUE, P.Money(d.net) }, { L.NET_DE, AD.NetColored(d.profit) } } })
        end
    end
    if collapsed["de-deals"] and text == "" then h1:SetCollapsed(true) end

    -- 2. Craft & disenchant over all professions of this character
    local de = AD and AD.current.de or {}
    local h2 = dp:Insert({ header = true, key = "de-craft", name = L.DE_GROUP, countText = tostring(#de),
        tip = #de > 0 and L.DE_EXPLAIN or L.DE_NONE })
    for _, e in ipairs(de) do
        if MatchesSearch(e.recipe, text) then
            h2:Insert({ recipe = e.recipe, learned = e.learned, rank = rank, suggest = true, de = true,
                place = e.dePlace, entry = e })
        end
    end
    if collapsed["de-craft"] and text == "" then h2:SetCollapsed(true) end

    -- 3. Drop chances: learned (own + shared) against the starting values
    local groups = hasAHS and DE.Groups() or nil
    local h3 = dp:Insert({ header = true, key = "de-chances", name = L.DE_CHANCES, countText = groups and tostring(#groups) or "–",
        tip = hasAHS and L.DE_CHANCES_EXPLAIN or L.DE_NEED_AHS })
    if groups and #groups == 0 then
        h3:Insert({ info = true, text = "|cffb0b0b0" .. L.DE_NO_RESULTS .. "|r", detail = "|cffb0b0b0" .. L.DE_START_VALUES .. "|r" })
    end
    for _, g in ipairs(groups or {}) do
        local parts, tip = {}, { GroupTitle(g), " " }
        for _, row in ipairs(g.rows) do
            local nm = ns.ItemName(row.id)
            parts[#parts + 1] = string.format("%s %d%%", nm, math.floor(row.chance * 100 + 0.5))
            tip[#tip + 1] = { "|T" .. ns.GetItemIcon(row.id) .. ":0|t " .. nm,
                string.format(L.DE_CHANCE_VS, math.floor(row.chance * 100 + 0.5), math.floor(row.prior * 100 + 0.5), AD.Num1(row.avg)) }
        end
        tip[#tip + 1] = " "
        tip[#tip + 1] = string.format(L.DE_BASED_ON, g.own, g.shared)
        if text == "" or table.concat(parts, " "):lower():find(text, 1, true) then
            h3:Insert({ info = true, icon = ns.GetItemIcon(g.rows[1] and g.rows[1].id or 10940), text = GroupTitle(g),
                value = "|cffb0b0b0" .. string.format(L.DE_COUNT, g.own + g.shared) .. "|r",
                detail = "|cffd0c0a0" .. table.concat(parts, " · ") .. "|r", tip = tip })
        end
    end
    if collapsed["de-chances"] and text == "" then h3:SetCollapsed(true) end

    scrollBox:SetDataProvider(dp, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition)
    if hasAHS then
        local own, shared, players = DE.Totals()
        summary:SetText(string.format(L.DE_SUMMARY, own or 0, shared or 0, players or 0) .. "\n" .. L.DE_SOURCE_AHS)
    else
        summary:SetText(L.DE_SUMMARY_NOAHS)
    end
end

local function TrainerMatches(id, text)
    if text == "" then return true end
    local n = ns.NPCs[id]
    if not n then return false end
    local hay = ((n[1] or "") .. " " .. (n[4] or "") .. " " .. (ns.Waypoint.ZoneName(n) or "")):lower()
    return hay:find(text, 1, true) ~= nil
end

local function RefreshTrainers(prof, rank, maxRank, text)
    local WP = ns.Waypoint
    local dp = CreateTreeDataProvider()
    local list = (ns.Trainers and ns.Trainers[prof]) or {}
    local groups = {}
    for _, e in ipairs(list) do
        local id, rk = e[1], e[2]
        if TrainerMatches(id, text) then
            groups[rk] = groups[rk] or {}
            table.insert(groups[rk], id)
        end
    end
    local next = WP.NextRank(rank, maxRank)
    for _, rk in ipairs(WP.RANKS) do
        local ids = groups[rk.key]
        if ids and #ids > 0 then
            -- friendly trainers first
            table.sort(ids, function(a, b)
                local fa, fb = WP.IsFriendly(a) or ns.NPCs[a][3] == nil, WP.IsFriendly(b) or ns.NPCs[b][3] == nil
                if fa ~= fb then return fa end
                return (ns.NPCs[a][1] or "") < (ns.NPCs[b][1] or "")
            end)
            local friendlyCount = 0
            for _, id in ipairs(ids) do if WP.IsFriendly(id) or ns.NPCs[id][3] == nil then friendlyCount = friendlyCount + 1 end end
            local title = L["RANK_" .. rk.key] or L.RANK_0
            if next and next.key == rk.key then title = "|cff40c040>> |r" .. title end
            local header = dp:Insert({
                header = true, key = "trainer-" .. rk.key, name = title,
                countText = friendlyCount .. "/" .. #ids,
                tip = rk.req and string.format(L.RANK_REQ, rk.req, rk.level) or nil,
            })
            for _, id in ipairs(ids) do header:Insert({ npc = id, rankKey = rk.key }) end
            if collapsed["trainer-" .. rk.key] and text == "" then header:SetCollapsed(true) end
        end
    end
    scrollBox:SetDataProvider(dp, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition)
    local line
    if next and rank then
        local rankName = (L["RANK_" .. next.key] or ""):gsub("%s*–.*$", "")  -- "Fachmann – bis 300" -> "Fachmann"
        line = string.format(L.NEXT_RANK, rankName, next.req, next.level, rank, maxRank or 0)
    elseif rank and maxRank and maxRank > 0 then
        line = string.format(L.MAX_RANK, rank, maxRank)
    else
        line = ""
    end
    if prof == 185 or prof == 129 or prof == 356 then line = line .. (line ~= "" and "\n" or "") .. L.SECONDARY_NOTE end
    summary:SetText(line)
end

-- Best recipe: recomputed on every refresh (also when the panel is closed), shown on the
-- profession window hint and as a star in the Blizzard list.
local bestHints = {}

function UI:UpdateBest()
    local AD = ns.Advisor
    if not AD then return end
    local host = currentHost
    -- Era: the enchanting window has its own skill line
    if ns.IsEra and CraftFrame and CraftFrame:IsShown() then currentHost = CraftFrame
    elseif ns.IsEra and not currentHost and TradeSkillFrame and TradeSkillFrame:IsShown() then currentHost = TradeSkillFrame end
    local prof, rank = CurrentProfession()
    AD.Update(prof, rank)
    for _, b in pairs(bestHints) do
        local e = AD.current.bestLearned
        local top = AD.current.best
        if ns.db.best == false or not prof then
            b:Hide()
        elseif e then
            -- best learned recipe of the ranking (the one you can craft right away)
            b.text:SetText(AD.STAR .. " " .. string.format(L.BEST_HINT, "|cffffd100" .. e.place .. ".|r |cffffffff" .. ns.RecipeName(e.recipe) .. "|r", AD.Reason(e)))
            b:Show()
        elseif top then
            -- nothing learned gives points: show the best recipe to learn
            b.text:SetText("|cff3fc7eb" .. L.TAG_LEARN .. "|r |cffffffff" .. ns.RecipeName(top.recipe) .. "|r (" .. AD.Reason(top, true) .. ")")
            b:Show()
        else
            b:Hide()
        end
    end
    currentHost = host
end

function UI:Refresh()
    self:UpdateBest()
    if not panel or not panel:IsShown() then return end
    UpdateTabs()
    testBadge:SetShown(ns.Sim ~= nil and (ns.Sim.rank ~= nil or ns.Sim.known ~= nil or ns.Sim.prof ~= nil))
    local prof, rank, maxRank = CurrentProfession()
    if not prof then
        panel:SetTitle(L.TITLE)
        summary:SetText(L.OPEN_PROF_FIRST)
        scrollBox:SetDataProvider(CreateTreeDataProvider())
        return
    end
    local m = Mode()
    panel:SetTitle(ns.ProfName(prof) .. (m == "trainers" and (" – " .. L.TRAINERS) or m == "ranking" and (" – " .. L.RANKING_TAB)
        or m == "disenchant" and (" – " .. L.DE_TAB) or m == "plan" and (" – " .. L.PLAN_TAB) or ""))
    local text = (searchBox:GetText() or ""):lower()
    if m == "trainers" then
        RefreshTrainers(prof, rank, maxRank, text)
    elseif m == "plan" then
        RefreshPlan(prof, rank, maxRank, text)
    elseif m == "disenchant" and ns.Disenchant and ns.Disenchant.IsEnchanter() then
        RefreshDisenchant(prof, rank, maxRank, text)
    elseif m == "ranking" then
        RefreshRanking(prof, rank, maxRank, text)
    else
        RefreshRecipes(prof, rank, maxRank, text)
    end
end

function UI:SetMode(mode)
    ns.db.panelMode = mode
    self:Refresh()
end

---------------------------------------------------------------------------
-- Panel
---------------------------------------------------------------------------
local function CreatePanel()
    panel = CreateFrame("Frame", "ProfessionSentinelPanel", UIParent, "ButtonFrameTemplate")
    panel:SetWidth(PANEL_WIDTH)
    panel:SetHeight(560)
    panel:SetFrameStrata("HIGH")
    panel:SetClampedToScreen(true)
    if ButtonFrameTemplate_HidePortrait then ButtonFrameTemplate_HidePortrait(panel) end
    if ButtonFrameTemplate_HideButtonBar then ButtonFrameTemplate_HideButtonBar(panel) end
    panel:SetTitle(L.TITLE)
    panel:Hide()
    if panel.CloseButton then
        panel.CloseButton:SetScript("OnClick", function()
            panel:Hide()
            if currentHost then ns.db.panelOpen = false end
        end)
    end

    testBadge = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    testBadge:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -30, -6)
    testBadge:SetText("|cffff4040" .. L.TEST_ACTIVE .. "|r")
    testBadge:Hide()

    -- tabs
    tabRecipes = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    tabRecipes:SetSize(76, 22)
    tabRecipes:SetPoint("TOPLEFT", panel, "TOPLEFT", 12, -26)
    tabRecipes:SetScript("OnClick", function() UI:SetMode("recipes") end)
    tabRanking = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    tabRanking:SetSize(76, 22)
    tabRanking:SetPoint("LEFT", tabRecipes, "RIGHT", 4, 0)
    tabRanking:SetScript("OnClick", function() UI:SetMode("ranking") end)
    tabTrainers = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    tabPlan = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    tabPlan:SetSize(76, 22)
    tabPlan:SetPoint("LEFT", tabRanking, "RIGHT", 4, 0)
    tabPlan:SetScript("OnClick", function() UI:SetMode("plan") end)
    tabTrainers:SetSize(76, 22)
    tabTrainers:SetPoint("LEFT", tabPlan, "RIGHT", 4, 0)
    tabTrainers:SetScript("OnClick", function() UI:SetMode("trainers") end)
    tabDisenchant = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    tabDisenchant:SetSize(76, 22)
    tabDisenchant:SetPoint("LEFT", tabTrainers, "RIGHT", 4, 0)
    tabDisenchant:SetScript("OnClick", function() UI:SetMode("disenchant") end)

    searchBox = CreateFrame("EditBox", nil, panel, "SearchBoxTemplate")
    searchBox:SetHeight(20)
    searchBox:SetPoint("TOPLEFT", panel, "TOPLEFT", 18, -54)
    searchBox:SetPoint("RIGHT", panel, "RIGHT", -140, 0)
    searchBox:SetAutoFocus(false)
    if searchBox.Instructions then searchBox.Instructions:SetText(L.SEARCH) end
    searchBox:HookScript("OnTextChanged", function() UI:Refresh() end)

    missingCheck = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    missingCheck:SetSize(22, 22)
    missingCheck:SetPoint("LEFT", searchBox, "RIGHT", 8, 0)
    missingLabel = missingCheck:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    missingLabel:SetPoint("LEFT", missingCheck, "RIGHT", 2, 0)
    missingLabel:SetText(L.F_MISSING)
    missingCheck:SetChecked(ns.db.filters.missing)
    missingCheck:SetScript("OnClick", function(self)
        ns.db.filters.missing = self:GetChecked() and true or false
        UI:Refresh()
    end)

    summary = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    summary:SetPoint("TOPLEFT", searchBox, "BOTTOMLEFT", -4, -6)
    summary:SetPoint("RIGHT", panel, "RIGHT", -12, 0)
    summary:SetJustifyH("LEFT")

    local inset = panel.Inset or panel
    if panel.Inset then
        panel.Inset:ClearAllPoints()
        panel.Inset:SetPoint("TOPLEFT", panel, "TOPLEFT", 8, -106)
        panel.Inset:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -6, 22)
    end

    scrollBox = CreateFrame("Frame", nil, inset, "WowScrollBoxList")
    scrollBox:SetPoint("TOPLEFT", inset, "TOPLEFT", 4, -4)
    scrollBox:SetPoint("BOTTOMRIGHT", inset, "BOTTOMRIGHT", -20, 4)
    scrollBar = CreateFrame("EventFrame", nil, inset, "MinimalScrollBar")
    scrollBar:SetPoint("TOPLEFT", scrollBox, "TOPRIGHT", 4, 0)
    scrollBar:SetPoint("BOTTOMLEFT", scrollBox, "BOTTOMRIGHT", 4, 0)

    local view = CreateScrollBoxListTreeListView(0)
    view:SetElementExtent(ROW_HEIGHT)
    view:SetElementFactory(function(factory, node)
        -- different frame types = separate frame pools, so headers and rows never share a frame
        if node:GetData().header then factory("CheckButton", InitHeader) else factory("Button", InitRow) end
    end)
    ScrollUtil.InitScrollBoxListWithScrollBar(scrollBox, scrollBar, view)

    infoText = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    infoText:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -10, 6)
    local qdate = (ns.DataMeta.questie or ""):match("%d%d%d%d%-%d%d%-%d%d") or "?"
    infoText:SetText(string.format(L.DATA_INFO, ns.FlavorName(), ns.DataMeta.build or "?", qdate))

    panel:SetScript("OnShow", function() UI:Refresh() end)
    panel:SetScript("OnHide", function() GameTooltip:Hide() end)
end

-- Dock the panel to a host frame (nil = free-floating in the screen centre, used by test mode)
function UI:AttachTo(host)
    if not panel then CreatePanel() end
    currentHost = host
    panel:ClearAllPoints()
    if host then
        panel:SetPoint("TOPLEFT", host, "TOPRIGHT", 2, 0)
        panel:SetHeight(math.max(host:GetHeight() or 560, 460))
        panel:SetMovable(false)
        panel:RegisterForDrag()
    else
        panel:SetPoint("CENTER", UIParent, "CENTER", 220, 0)
        panel:SetHeight(580)
        panel:SetMovable(true)
        panel:EnableMouse(true)
        panel:RegisterForDrag("LeftButton")
        panel:SetScript("OnDragStart", panel.StartMoving)
        panel:SetScript("OnDragStop", panel.StopMovingOrSizing)
    end
end

function UI:Show(host)
    self:AttachTo(host)
    panel:Show()
    self:Refresh()
end

function UI:Hide()
    if panel then panel:Hide() end
end

function UI:IsShown()
    return panel and panel:IsShown()
end

local function ActiveHost()
    if ns.UsesModernProfessions then
        return ProfessionsFrame and ProfessionsFrame:IsShown() and ProfessionsFrame or nil
    end
    if CraftFrame and CraftFrame:IsShown() then return CraftFrame end
    if TradeSkillFrame and TradeSkillFrame:IsShown() then return TradeSkillFrame end
end

function UI:Toggle()
    local host = ActiveHost()
    if panel and panel:IsShown() then
        panel:Hide()
        if host then ns.db.panelOpen = false end
        return
    end
    if not host and not (ns.Sim and ns.Sim.prof) then
        ns.Print(L.OPEN_PROF_FIRST)
        return
    end
    if host then ns.db.panelOpen = true end
    self:Show(host)
end

---------------------------------------------------------------------------
-- Hosts: toggle button + show/hide with the profession window
---------------------------------------------------------------------------
local hostsDone = {}

local function SetupHost(host)
    if not host or hostsDone[host] then return end
    hostsDone[host] = true
    collapsed = ns.db.collapsed or {}
    ns.db.collapsed = collapsed
    local b = CreateFrame("Button", nil, host, "UIPanelButtonTemplate")
    b:SetSize(130, 22)
    b:SetPoint("TOPRIGHT", host, "BOTTOMRIGHT", -6, ns.UsesModernProfessions and 0 or 70)
    b:SetText(L.ALL_RECIPES)
    b:SetScript("OnClick", function()
        if panel and panel:IsShown() and currentHost == host then
            panel:Hide(); ns.db.panelOpen = false
        else
            ns.db.panelOpen = true
            UI:Show(host)
        end
    end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("ProfessionSentinel", 0.25, 0.78, 0.92)
        GameTooltip:AddLine(L.SUBTITLE, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- "Best recipe" hint next to the button: click selects it in the profession window
    local hint = CreateFrame("Button", nil, host)
    hint:SetSize(340, 22)
    hint:SetPoint("RIGHT", b, "LEFT", -8, 0)
    hint.text = hint:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    hint.text:SetAllPoints()
    hint.text:SetJustifyH("RIGHT")
    hint.text:SetWordWrap(false)
    hint:SetScript("OnClick", function()
        -- learned: select it in the profession window; nothing learned useful: open the ranking
        local e = ns.Advisor and ns.Advisor.current.bestLearned
        if e then SelectInBlizzard(e.recipe) else UI:Show(host); UI:SetMode("ranking") end
    end)
    hint:SetScript("OnEnter", function(self)
        local AD = ns.Advisor
        local e = AD and (AD.current.bestLearned or AD.current.best)
        if e then UI:ShowRecipeTooltip(self, e.recipe, AD.current.rank) end
    end)
    hint:SetScript("OnLeave", function() GameTooltip:Hide() end)
    hint:Hide()
    bestHints[host] = hint

    host:HookScript("OnShow", function()
        if ns.db.panelOpen ~= false then UI:Show(host) end
    end)
    host:HookScript("OnHide", function()
        if currentHost == host and panel then panel:Hide() end
    end)
    if host:IsShown() and ns.db.panelOpen ~= false then UI:Show(host) end
end

local loader = CreateFrame("Frame")
loader:RegisterEvent("ADDON_LOADED")
loader:RegisterEvent("PLAYER_LOGIN")
-- profession events differ between the clients (Retail has no TRADE_SKILL_UPDATE / CRAFT_UPDATE,
-- Classic Era no TRADE_SKILL_LIST_UPDATE): register each one only if the client knows it
for _, e in ipairs({ "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_DATA_SOURCE_CHANGED", "TRADE_SKILL_UPDATE", "CRAFT_UPDATE" }) do
    pcall(loader.RegisterEvent, loader, e)
end
loader:SetScript("OnEvent", function(_, event, name)
    if not ns.Flavor or not ns.db then return end
    collapsed = collapsed or ns.db.collapsed or {}
    if event == "ADDON_LOADED" then
        if name == "Blizzard_Professions" and ns.UsesModernProfessions then SetupHost(ProfessionsFrame)
        elseif name == "Blizzard_TradeSkillUI" and ns.IsEra then SetupHost(TradeSkillFrame)
        elseif name == "Blizzard_CraftUI" and ns.IsEra then SetupHost(CraftFrame) end
    elseif event == "PLAYER_LOGIN" then
        if ns.UsesModernProfessions and ProfessionsFrame then SetupHost(ProfessionsFrame) end
        if ns.IsEra and TradeSkillFrame then SetupHost(TradeSkillFrame) end
        if ns.IsEra and CraftFrame then SetupHost(CraftFrame) end
    else
        -- skill or recipe list changed: best recipe, hint and (if open) the panel
        UI:Refresh()
        if ns.Lifeline then ns.Lifeline.RefreshBlizzard() end
    end
end)
