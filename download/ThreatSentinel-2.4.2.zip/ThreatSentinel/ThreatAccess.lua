-- ThreatSentinel - ThreatAccess.lua
-- Erkennt im Spiel, ob die Bedrohungswerte im Kampf lesbar sind, und wählt danach den Modus:
--   ns.threatAccess = "unknown" | "open" | "secret" | "none"
--   VOLL    (open, oder alte API: Classic Era / TBC) - alles wie bisher
--   ANZEIGE (secret) - keine eigene Entscheidung: kein Leuchten / Ausblenden, keine Töne nach Schwellwerten,
--           geschützte Werte gehen unverändert an Balken und Texte (Aggrometer, DD-Ansicht), Blizzards
--           eigene Bedrohungsanzeigen werden eingeschaltet (ausserhalb des Kampfs)
--   AUS     (none) - Bedrohungsfunktionen ausgeblendet; Tank-Sync, Rollen, Spott-Abklingzeiten bleiben
-- Moderne API (WoW Forever, Retail): einmal pro Kampf prüfen, beim ersten Bedrohungs-Update mit gültigem Ziel.
-- Die Prüfung vergleicht keinen Wert, solange nicht klar ist, dass er offen ist (nur issecretvalue und nil).

local ADDON, ns = ...
local L = ns.L

local TA = {}
ns.ThreatAccess = TA
table.insert(ns.modules, TA)

local Game = GoldSentinelGame
local issecret = (Game and Game.IsSecret) or issecretvalue or function() return false end
local AnySecret = (Game and Game.AnySecret) or function(...)
	for i = 1, select("#", ...) do if issecret((select(i, ...))) then return true end end
	return false
end
local MAX_ATTEMPTS = 40          -- ~10 Sekunden ohne jede Antwort = "none"

ns.threatAccess = ns.isModern and "unknown" or "open"
ns.simAccess = nil               -- Testzentrale: "open" | "secret" | "none" simulieren
TA.checked = not ns.isModern     -- in diesem Kampf schon geprüft?
TA.attempts = 0
TA.lastProbe = nil               -- { status = "x" | "geschützt" | "-", pct = ... } für die Ausgabe

------------------------------------------------------------
-- Modus
------------------------------------------------------------
-- "FULL" | "DISPLAY" | "OFF"
function ns:ThreatMode()
	local acc = self.simAccess or self.threatAccess
	-- Simulation "lesbar" übersteuert nie eine echte Sperre (Testzentrale zeigt das an)
	if self.simAccess == "open" and self.threatAccess == "secret" then acc = "secret" end
	if acc == "none" then return "OFF" end
	if acc == "secret" then return "DISPLAY" end
	-- "Voll" lässt sich nicht erzwingen; "immer nur Anzeige" schon (nur moderne API - Classic / TBC bleiben wie bisher)
	if (self.isModern or self.simAccess) and self.db and self.db.threatMode == "DISPLAY" then return "DISPLAY" end
	return "FULL"
end

local MODE_TEXT = { FULL = "TA_MODE_FULL", DISPLAY = "TA_MODE_DISPLAY", OFF = "TA_MODE_OFF" }
function TA:ModeText(mode)
	return L[MODE_TEXT[mode or ns:ThreatMode()]]
end

------------------------------------------------------------
-- Ergebnis speichern und melden
------------------------------------------------------------
local function Store(state)
	ThreatSentinelDB = ThreatSentinelDB or {}
	local ver, build = GetBuildInfo()
	ThreatSentinelDB.threatAccess = { state = state, date = date("%Y-%m-%d %H:%M"), build = tostring(ver or "?") .. " (" .. tostring(build or "?") .. ")" }
end

-- Der Moduswechsel selbst (Plaketten lösen usw.) läuft zentral in Threat.lua (T:Tick merkt jeden Wechsel).
function TA:Set(state)
	ns.threatAccess = state
	self.checked = true
	Store(state)
	-- einmal pro Kampf sichtbar melden (nicht im Chat) - nur bei echter Sperre, nicht beim erzwungenen Modus,
	-- und nur, wenn ThreatSentinel eingeschaltet ist
	local enabled = ns.db and ns.db.enabled
	if enabled and not self.announced and (state == "secret" or state == "none") then
		self.announced = true
		local text = (state == "secret") and L.TA_NOTE_DISPLAY or L.TA_NOTE_OFF
		if ns.Alerts and ns.Alerts.Center then ns.Alerts:Center(text, { 1, 0.8, 0.2 }, 4, "remote") end
	end
	if state == "secret" and enabled then self.wantBlizzard = true; self:ApplyBlizzard() end
end

------------------------------------------------------------
-- Prüfung (einmal pro Kampf, beim ersten Bedrohungs-Update mit gültigem Ziel)
------------------------------------------------------------
-- Liest die Bedrohung aller Gruppenmitglieder auf "unit"; vergleicht nichts, solange es geschützt sein kann.
-- Rückgabe: found (irgendein offener Wert), secret (irgendein geschützter Wert), missing (Funktionen fehlen)
function TA:Read(unit)
	if not UnitDetailedThreatSituation and not UnitThreatSituation then return false, false, true end
	local found, secret = false, false
	for _, u in ipairs(ns.groupUnits or { "player" }) do
		if UnitDetailedThreatSituation then
			local ok, isT, st, sc, _, tv = pcall(UnitDetailedThreatSituation, u, unit)
			if ok then
				if AnySecret(isT, st, sc, tv) then secret = true
				elseif st ~= nil then found = true end
			end
		end
		if UnitThreatSituation then
			local ok, s2 = pcall(UnitThreatSituation, u, unit)
			if ok then
				if issecret(s2) then secret = true
				elseif s2 ~= nil then found = true end
			end
		end
		if secret then break end
	end
	return found, secret, false
end

-- Prüft das Ziel und alle Mobs im Kampf. Erst wenn KEIN Mob etwas liefert, zählt ein Versuch.
-- "none" nur, wenn die Funktionen fehlen - sonst bleibt der bisherige Zustand (keine Bedrohung = kein Urteil).
function TA:Probe(units)
	if self.checked or not ns.isModern then return end
	if not UnitAffectingCombat("player") then return end
	local anyFound = false
	for _, unit in ipairs(units) do
		local found, secret, missing = self:Read(unit)
		if missing then self:Set("none") return end
		if secret then self:Set("secret") return end
		if found then anyFound = true end
	end
	if anyFound then self:Set("open") return end
	self.attempts = self.attempts + 1
	if self.attempts >= MAX_ATTEMPTS then
		self.checked = true    -- in diesem Kampf nicht weiter versuchen; Zustand bleibt
	end
end

-- Liste der zu prüfenden Einheiten: zuerst das Ziel, dann alle Plaketten im Kampf
function TA:Candidates(mobs)
	local list = {}
	if ns.Safe(UnitExists("target"), false) and ns.Safe(UnitCanAttack("player", "target"), false) then
		list[1] = "target"
	end
	for unit in pairs(mobs or {}) do
		if ns.Safe(UnitAffectingCombat(unit), false) and ns.Safe(UnitCanAttack("player", unit), false) then
			list[#list + 1] = unit
		end
	end
	return list
end

ns:On("PLAYER_REGEN_DISABLED", function()
	if not ns.isModern then return end
	TA.checked, TA.attempts, TA.announced = false, 0, false
end)

------------------------------------------------------------
-- Blizzards eigene Bedrohungsanzeigen (Modus ANZEIGE, nur ausserhalb des Kampfs)
------------------------------------------------------------
local BLIZZ_CVARS = { threatShowNumeric = "1", threatWarning = "3" }
-- Die ursprünglichen Werte werden gemerkt und im Modus VOLL wiederhergestellt

local function GetCV(name)
	if C_CVar and C_CVar.GetCVar then return C_CVar.GetCVar(name) end
	if GetCVar then return GetCVar(name) end
end
local function SetCV(name, value)
	if C_CVar and C_CVar.SetCVar then return C_CVar.SetCVar(name, value) end
	if SetCVar then return SetCVar(name, value) end
end

function TA:ApplyBlizzard()
	if not self.wantBlizzard or not ns.db or not ns.db.enabled or not ns.db.blizzThreat then return end
	if InCombatLockdown() then return end   -- nach dem Kampf erneut
	self.wantBlizzard = false
	ns.db.blizzOrig = ns.db.blizzOrig or {}
	for name, value in pairs(BLIZZ_CVARS) do
		local ok, cur = pcall(GetCV, name)
		if ok and cur ~= nil and not issecret(cur) and cur ~= value then
			if ns.db.blizzOrig[name] == nil then ns.db.blizzOrig[name] = cur end
			pcall(SetCV, name, value)
		end
	end
end

function TA:RestoreBlizzard()
	local orig = ns.db and ns.db.blizzOrig
	if not orig or InCombatLockdown() then return end
	for name, value in pairs(orig) do pcall(SetCV, name, value) end
	ns.db.blizzOrig = nil
end

ns:On("PLAYER_REGEN_ENABLED", function()
	if ns:ThreatMode() == "FULL" then TA:RestoreBlizzard() else TA:ApplyBlizzard() end
end)

------------------------------------------------------------
-- "Bedrohung prüfen" (/ts bedrohung, Knopf in den Einstellungen)
------------------------------------------------------------
local function Shown(v)
	if v == nil then return "-" end
	if issecret(v) then return L.TA_PROTECTED end
	if type(v) == "number" then
		if v == math.floor(v) then return tostring(v) end
		return string.format("%.1f", v)
	end
	return tostring(v)
end

function TA:Report()
	local p = function(text) ns:Print(text) end
	p(string.format(L.TA_R_MODE, self:ModeText()) .. (ns.simAccess and (" " .. L.TA_R_SIM) or ""))
	if Game and Game.Status then p(Game.Status()) end
	if not ns.isModern then p(L.TA_R_OLDAPI) end
	local unit = "target"
	local hostile = ns.Safe(UnitExists(unit), false) and ns.Safe(UnitCanAttack("player", unit), false)
	if UnitAffectingCombat("player") and hostile then
		local okS, s2 = pcall(UnitThreatSituation, "player", unit)
		local okD, _, _, sc = pcall(UnitDetailedThreatSituation, "player", unit)
		p(string.format(L.TA_R_STATUS, okS and Shown(s2) or "-"))
		p(string.format(L.TA_R_PCT, okD and Shown(sc) or "-"))
		-- gleich als Prüfung für diesen Kampf verwenden
		if ns.isModern and not self.checked then
			local ok, err = pcall(self.Probe, self, { unit })
			if not ok then ns:ReportError(err) end
		end
	else
		p(L.TA_R_NOCOMBAT)
	end
	local last = ThreatSentinelDB and ThreatSentinelDB.threatAccess
	if last then
		p(string.format(L.TA_R_LAST, L["TA_STATE_" .. tostring(last.state)] or tostring(last.state), last.date or "?", last.build or "?"))
	else
		p(L.TA_R_NEVER)
	end
	p(string.format(L.TA_R_ERRORS, ns.errorCount or 0) .. ((ns.lastError and ns.errorCount > 0) and (" - " .. tostring(ns.lastError):match("^[^\n]*")) or ""))
end

function TA:Login()
	-- zuletzt erkannten Zustand übernehmen (gilt bis zur nächsten Prüfung im Kampf)
	local last = ThreatSentinelDB and ThreatSentinelDB.threatAccess
	-- "none" nicht übernehmen: das wird in jedem Kampf neu festgestellt
	if ns.isModern and last and (last.state == "open" or last.state == "secret") then
		ns.threatAccess = last.state
		if last.state == "secret" then self.wantBlizzard = true; self:ApplyBlizzard() end
	end
end
