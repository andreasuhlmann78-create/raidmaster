GuildSentinel 0.9.7 – guild tool for Classic Era, WoW Forever and Burning Crusade Classic
=====================================================================================

INSTALLATION
- Copy the folder "GuildSentinel" into your AddOns folder (...\Interface\AddOns\GuildSentinel).
  When updating, replace the old folder – your saved data is kept.
- Open it with the minimap button (left-click) or /gs. Everything works with the mouse.
- The more guild members use the addon, the more complete everything gets. Data syncs automatically on login.

LANGUAGE
- GuildSentinel always uses the language of your game client: English, German, French, Spanish (ES/MX), Italian,
  Portuguese (BR), Russian, Korean, Chinese (simplified/traditional).

NEW IN 0.9.7
- Built in the shared game-version detection of all GoldSentinel addons (GoldSentinelGame.lua): Classic Era, WoW
  Forever and TBC are detected the same way everywhere, with the shared guard against secret values in combat and
  the first/last name comparison. /gsgame shows what was detected. Nothing changes for players.

NEW IN 0.9.5
- WoW Forever: protection against "secret values" in combat (player tooltip, addon messages, cooldowns). Applicants
  who whisper during combat are added after combat instead of being lost.
- First and last names (WoW Forever): names are written correctly ("Rokan Steinwacht"), notes like "Alt of Rokan
  Steinwacht" are recognised, and a unique first name alone is enough (alts, thanks, mentor).
- Whispering "First Last" opens the whisper box for the full name.
- Modern APIs first (C_ChatInfo, C_GuildInfo, C_SpellBook), the old ones as fallback.

NEW IN 0.9.4
- Without a guild: instead of empty pages the overview shows a hint. GuildSentinel is a guild tool – members, events,
  board, polls, progress, professions, recruitment and group finder appear as soon as you are in a guild. Without a
  guild, My week, Addons and Settings remain. Joining or leaving takes effect right away.

NEW IN 0.9.3
- Guild name: the guild master can set a name for GuildSentinel under Leadership > Rank rights. It applies to everyone
  in the guild with the addon (ad {guild}, chronicle, rules, welcome guide, header). Empty = name from the game. Only
  the guild master can change it; messages from anyone else are ignored.

NEW IN 0.9.2
- Professions on WoW Forever: GuildSentinel now also reads the new (retail-style) profession window. The game client
  decides which way is used: WoW Forever the new window, Classic Era and TBC the classic one as before. Linked
  professions, guild professions and NPC windows are not read.
- The "Open next profession" button opens the new window directly on WoW Forever if needed.
- Settings > Test mode (developer only) shows the game client and profession window ("modern (Forever)" / "classic").

NEW IN 0.9.1
- Test mode is now developer-only: the Settings > Test mode tab and /gs test only appear for the developer account
  (shared detection of all GoldSentinel addons, GoldSentinelDev). Nothing else changes for everyone else.

NEW IN 0.9.0
- Group finder > Who's free: one click flags you as free for dungeon, raid, quest group or PvP (1, 2 or 4 hours).
  Everyone with GuildSentinel sees who is free – with level, item level and zone. In dungeons, raids and
  battlegrounds you automatically show as busy. After posting a search, GuildSentinel tells you how many are free.
- "I'll join" sends your item level: the searcher sees it in the replies and in chat.
- Leadership > Bulk actions (officers): remove inactive players by rule (offline 30–365 days, from which rank,
  keep max level) or promote several suggestions at once. Always a checklist first; the game only allows one step
  per click, so each click on "Next" performs exactly one.
- Leadership > GRM import: take over alts, join dates and personal notes from Guild Roster Manager
  (GRM must be enabled). Preview first; anything already in GuildSentinel stays.

NEW IN 0.8.3
- “Support” button at the top of the window (next to Close) and in Settings > General: shows the PayPal link
  to copy. Also with /gs donate. Only opens when you click it – no reminders, no ads in chat.

NEW IN 0.8.2
- Guild achievements: singular for the first weekly goal; names that are too long use a smaller font instead of being cut off.
- Professions: old raw-material entries from earlier versions (e.g. Felweed as "Alchemy") are removed when opened.

NEW IN 0.8.1
- Settings > Features: three columns, all switches and the button fit into the window.
- Leadership > Probation: "Promote" only with at least 40 % online days since joining (at least 3); percentage in the list.
- Leadership > Rank rights: test mode shows the test guild's ranks.
- Overview: departures count the same as Leadership > Departures; shorter "players online" text; hidden tiles leave no gap.
- My week: singular ("1 elixir"), clear markers (green + ready, orange ! missing), resistances on their own line.
- Chronicle: no duplicate entries, reported departures included; Discord export starts at the top.
- Guild achievements: wider name column.
- Loot wishes: dungeon preselected for your level, visible hint without a dungeon.
- Questions: "Remove" asks first; shorter field, "Show solved" fits.
- Addons page: heading "Addons by GoldSentinel".
- Professions: raw materials (e.g. Felweed) are removed from the watch list.
- Test mode: "Guild milestone" adds new max-level members instead of changing test characters.

NEW IN 0.8.0
- All game languages: German, English, French, Spanish (Spain and Mexico), Italian, Portuguese (Brazil), Russian,
  Korean, Chinese (simplified and traditional). The language always follows the game client – there is no language
  setting any more.
- Overview (new start page): guild health at a glance – active players vs. last month, joins and departures, who will
  soon be inactive, open applicants, probations due, weekly goal, next event and "For you" (events without your reply,
  polls, crafting requests, open questions). Click a tile to open the page.
- Leadership (officers only):
  * Probation: online days, events attended and thanks since joining; when it ends: "Promote" or "Talk".
  * Suggest mentor: who is online at similar times as the newcomer.
  * Departures with reason: date, last level, rank, reason ("moved to guild X").
  * Officer notes with history: longer, dated entries per player – only sent to officers with GuildSentinel.
  * Rank rights: which rank may do what (names from the game; the game only shows them to the guild leadership).
- My week: saved raids and heroic dungeons per character with time left, dailies today; raid prep (attunements,
  flasks/elixirs/potions, class reagents, durability, resistances).
- Board > Loot wishes: who needs what from which dungeon – the group finder shows "3 with loot wish".
- Board > Questions: "Who knows …?" – answers; "Helped" gives the writer a thanks point.
- Progress > Achievements (guild achievements with progress bars) and Chronicle (timeline, export for Discord).
- Weekly recap in guild chat after the Wednesday reset (can be turned off).
- Welcome guide for new members (once): key rules, mentor, commands.
- Test mode: "Click through everything" opens every page and tab and triggers all events.
- Improved: Escape closes an open dropdown first; watched recipes take the profession from the item data (herbs and
  ores are rejected); unknown ad placeholders are marked red; the level-up test event raises exactly one character by
  one level.

NEW IN 0.7.0
- Runs in all Classic clients: Classic Era (1.15), WoW Forever (1.60, paladins and shamans on both
  factions) and Burning Crusade Classic /
  Anniversary (2.5). In TBC GuildSentinel knows level 70, paladins and shamans on both factions, 25-player raids,
  the Outland dungeons, attunements (Karazhan, Serpentshrine, Tempest Keep, Hyjal, Black Temple), dungeon and
  heroic keys, portals to Silvermoon/Exodar/Shattrath, primal mooncloth, shadowcloth and spellcloth, TBC raid
  recipes and the first mount at 30.
- WoW Forever: the group finder knows the 9 new dungeons (Hall of Thanes to Shaper's Terrace) and the raids
  Barrow Deeps (10), Hyjal Summit (20) and Onyxia's Lair (40), sorted by level.
- Group finder with zone: every search and every reply shows where the player currently is.
- Long selection lists (e.g. all dungeons) are shown in several columns.
- Turn features on and off (Settings > Features): whatever is off disappears from the window, sends nothing and
  accepts nothing – e.g. board, events, thanks, cooldowns, mentors …
- Test mode (developer only, Settings > Test mode or /gs test): fills GuildSentinel with a made-up guild so you can try everything
  – even on your own. Buttons trigger events (new event, matching offer, alt in guild chat, level-up, milestone,
  applicant …). Nothing is sent in test mode; whatever would go to chat is shown with [Test] in your chat window.
  Your real data stays untouched.
- Fixed: error when showing prices on the board and market values for cooldowns.

NEW IN 0.6.0
- Who's where (Members > Who's where): all online members by zone, your zone on top – for meeting up, summoning
  and world bosses. Anyone currently offering portals or summons is shown too.
- Board (/gs board):
  * Services: mages (portals, food), warlocks (summoning, soulstone), rogues (lockpicking), enchanters – tick,
    "Offer", everyone sees it. Lasts up to 2 hours and ends when you log out.
  * Offers/wanted between members: offer or look for items, with price and note. If a request matches an offer,
    both get a notice. Not a guild bank – trading happens directly between players.
- Guild events (/gs events): PvP night, guild meeting, dungeon night, world boss … Anyone can create events,
  everyone replies yes, no or maybe with one click. Reminder with sound 15 minutes before.
  Raids stay with RaidMaster and the Discord sign-up – the next raid is only shown for information.
- Report absence: /gs away 14 vacation (or select a member > "Away …"). Members marked away don't show up as
  inactive and aren't suggested for promotion. /gs away 0 = back.
- Mentors for new members: officers assign a mentor; both get a notice.
- Write alts into the guild note: "Alt of …" into the public note (select a member, or all at once under Export)
  – so everyone without GuildSentinel sees it too. Needs the right to edit public notes.
- Guild chat with main names: when an alt writes, the main is shown in gray in front. "has come online" gets
  "(Alt of …)" or "(marked away)" added. Both can be turned off.
- Thanks: "Say thanks" (right-click a member or /gs thanks name) – once a day per player.
  Ranking under Progress > Helpful.
- Cooldowns (Professions > Cooldowns): transmutes, mooncloth, salt shaker – who is ready, who when?
  "Ask" prepares the whisper.
- Attunements & keys: now with Shadowforge Key, Skeleton Key, Crescent Key and Key to the City.
- Guild goals (Progress > Guild goals): weekly goal ("150 levels as a guild", week starts Wednesday) and guild
  milestones (members at 60, member count, raid attunements, first kills from RaidMaster) with announcements.
- New "Addons" page: all GoldSentinel addons – what you have installed, who in the guild uses which one,
  who has an old version, open with one click.

NEW IN 0.5.1
- (0.5.1) Language setting – since 0.8.0 the game language is always used.
- English names for the ad placeholders: {guild}, {members}, {wanted}, {crafters}, {player}.

NEW IN 0.5.0
- Polls: officers ask, everyone with the addon votes with one click, results are live (Polls page, /gs poll)
- Composition (Members > Composition): classes and roles per level range, raid target and what's missing.
  New placeholder {wanted} in the ad, e.g. "Looking for: Shamans, Tanks, Warlocks."
- Application questions: after the automatic reply the addon asks a few questions, one at a time.
  The answers are shown with the applicant (hover the name).
- Player tooltip: rank, main or alts, role, professions and raid attunements of guild members
- Professions > Gaps: important raid recipes nobody in the guild can craft. Placeholder {crafters} in the ad.
- Professions > Requests: add crafting requests; anyone who can craft it gets a notice and takes it with one click.

MEMBERS
- List with level, class, rank, zone or "last online" and notes. Search, filter by class/rank, online only,
  show or hide alts. Right-click a member for actions.
- Alts: a public note like "Alt: Name" (or "Main: Name", "Twink von Name") is detected automatically.
  Otherwise: select a member > "Alt of …", or pick your own main under Settings.
- Personal note for every member (only you see it).
- History: joined, left, removed, promoted, demoted, reached 60, accepted the guild rules.
- Inactive: who hasn't been online for 14/30/60/90 days (only if none of their alts were online either).
- Online times: overview by weekday and hour of when most players are online – great for picking raid times.
  GuildSentinel samples every 5 minutes; samples from everyone with the addon are combined.
- Promotion: the guild leadership sets per rank when someone gets suggested (days in guild, level, online days
  out of the last 14). Promote with one click – but always by hand.
- Composition: classes and roles per level range (1–29, 30–49, 50–59, 60) compared with a target for a 40-player
  raid. Click a row to change the target. Role: chosen by the player, from the talent spec (RaidMaster) or
  estimated from class (tanks are never estimated).
- Export: the member list as text (alts listed with their main) or as a table (CSV) to copy.

GROUP FINDER
- Pick a dungeon or activity, tick the roles you need, open spots, note – "Start search".
- "guild only" or "whole server": then everyone on the server with GuildSentinel sees your search, including other
  guilds. For this the addon uses its own channel, hidden from your chat.
- Players whose level and role fit get a notice in chat (optionally with sound). "I'll join" tells the searcher,
  who sees all replies and invites with one click.
- A search runs for 60 minutes. Set your role on the page or under Settings.

POLLS
- Officers ask a question with 2 to 8 answers (runs 1 hour to 7 days, optionally secret).
- Everyone with GuildSentinel gets a notice and votes with one click; you can change your vote until the end.
  Each player has one vote – alts count for their main.

PROGRESS
- Leveling race: ranking by level – at the same level, whoever got there first ranks higher. Plus levels gained in
  the last 7 days. Levels come from the guild roster, nobody needs the addon for this.
- Guild chat announcements: level 10, 20, 30, 40 (mount!), 50, 60 and "first guild member to reach 60".
- Raid attunements: Upper Blackrock Spire, Molten Core, Onyxia's Lair, Blackwing Lair. Everyone with GuildSentinel
  shares their completed attunement quests; without the addon it shows "?".

RECRUITMENT
- Ad text with placeholders {guild}, {name}, {discord}, {members}, {online}, {wanted} (what's missing) and
  {crafters} (professions needed) – the German names ({gilde}, {gesucht} …) work too – and a preview. Each click on "Post" writes into one channel, the next
  click into the next one. Quick: right-click the minimap button.
- Applicants: anyone who whispers you a keyword (e.g. "guild") lands in the list and gets an automatic reply if you
  like. Then the addon asks the application questions (custom questions possible, one per line).
  From there: invite, whisper, decline.
- Welcome new members and celebrate anniversaries (1, 3, 6 months, 1 and 2 years) in guild chat.
- Guild rules: officers write them and send them to everyone. Everyone with GuildSentinel sees them on login and
  accepts with one click. The leadership sees who is still missing.
- Announcements are made by only one player, even if many have the addon. Alts are not announced.
- The guild name is always read from the game – if the name changes, all texts follow.

PROFESSIONS
- Directory: everyone opens their profession windows once (or clicks "Scan …"). Then the whole guild knows who can
  craft what. Search by recipe or item, overview per profession, "Ask to craft" with one click.
- Requests: add requests (shift-click the item). Whoever can craft it gets a notice and takes the request; the
  requester is told. Requests stay for 14 days.
- Gaps: fire, nature, shadow, frost and arcane protection potions, flasks, elixirs, transmutes, mooncloth,
  dark iron, dynamite … – who can craft it, what's missing? Add more recipes with shift-click.

PLAYER TOOLTIP
- Hover a guild member: rank, main or alts, role, professions and raid attunements. Applicants are marked.
  Can be turned off under Settings.

WORKING WITH THE OTHER GOLDSENTINEL ADDONS (all optional, GuildSentinel also works on its own)
- RaidMaster: professions and alts come from RaidMaster (nothing is sent twice). Alts from Discord (/twink) take
  priority; if an officer sets an alt here, it is saved in RaidMaster too. Roles from talent specs, the next raid
  in events, first kills as guild milestones.
- AH Analyzer Pro: market value on the board and for profession cooldowns.
- BuffSentinel: detects your class services for the board.
- ThreatSentinel: your role (tank in Defensive Stance/Bear Form or the chosen role) for composition and group finder.
- LevelPilot: elite quests from your quest log as a group search with one click, players with the same quest.
- "Addons" page: overview and open with one click.

COMMANDS (everything also works with the mouse)
  /gs                 open/close the window
  /gs group           group finder
  /gs events          guild events
  /gs board           board (services, offers/wanted)
  /gs where           who's where
  /gs thanks <name>   say thanks
  /gs away <days> [note]  report absence (0 = back)
  /gs poll            polls
  /gs progress        leveling race
  /gs attune          raid attunements
  /gs rules           show the guild rules
  /gs find <recipe>   profession search
  /gs ad              open the ad page (post: button there or right-click the minimap button)
  /gs test            test mode on/off (developer only)
  /gs donate          support GuildSentinel (PayPal link to copy; also: the “Support” button at the top of the window)

© GoldSentinel – All rights reserved.
