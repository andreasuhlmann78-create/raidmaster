-- GuildSentinel - PagesMore.lua
-- Weitere Seiten: Gruppensuche und Fortschritt (Leveling-Rennen, Raid-Zugänge).

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local UI = ns.UI

local GREEN, GRAY, GOLD, ORANGE, RED = "|cff40d860", "|cff8a8f99", "|cffffd100", "|cffff9933", "|cffff5555"
local function Gray(t) return GRAY .. tostring(t) .. "|r" end
local function WhenShown(key, fn)
	return function(...) if UI:IsPageShown(key) then fn(...) end end
end

------------------------------------------------------------
-- Seite: Gruppensuche
------------------------------------------------------------
local Gp = { key = "group", feature = "group", order = 20, icon = "Interface\\Icons\\INV_Misc_GroupNeedMore" }
Gp.title = N["Gruppensuche"]
Gp.form = { act = "brd", scope = "guild", need = 4, roles = { tank = false, heal = true, dps = false } }
Gp.badge = function()
	local n = 0
	for _, s in ipairs(ns.Group:Open()) do if ns.Group:Fits(s) then n = n + 1 end end
	return n > 0 and (GREEN .. n .. "|r") or ""
end

Gp.view = "search"

function Gp.build(root)
	Gp.panel = root
	local G = ns.Group
	-- Reiter: Suchen / Wer ist frei
	Gp.tabs = UI:Tabs(root, {
		{ key = "search", text = L["Suchen"] },
		{ key = "free", text = L["Wer ist frei"] },
	}, function(key) Gp.view = key; Gp:Refresh() end)
	Gp.tabs:SetPoint("TOPLEFT", 0, 0)
	Gp.tabs:SetPoint("TOPRIGHT", 0, 0)
	local p = CreateFrame("Frame", nil, root)
	p:SetPoint("TOPLEFT", 0, -34)
	p:SetPoint("BOTTOMRIGHT")
	Gp.searchView = p
	Gp.freeView = CreateFrame("Frame", nil, root)
	Gp.freeView:SetPoint("TOPLEFT", 0, -34)
	Gp.freeView:SetPoint("BOTTOMRIGHT")
	Gp.freeView:Hide()
	Gp:BuildFree(Gp.freeView)

	-- neue Suche
	local h = UI:Header(p, L["Neue Suche"])
	h:SetPoint("TOPLEFT", 0, 0)
	local act = UI:Dropdown(p, 260, function()
		local out = {}
		local lvl = UnitLevel("player")
		for _, a in ipairs(G.ACTIVITIES) do
			local range = a.min and string.format(" |cff8a8f99(%d–%d)|r", a.min, a.max) or ""
			local fit = (not a.min or (lvl >= a.min - 2 and lvl <= a.max + 2))
			local wish = G.GearHint and G:GearHint(a.key) or ""
			out[#out + 1] = { value = a.key, text = (fit and "" or "|cff8a8f99") .. L[a.n] .. (fit and "" or "|r") .. range .. (wish ~= "" and (" " .. wish) or "") }
		end
		return out
	end, function() return Gp.form.act end, function(v) Gp.form.act = v end)
	act:SetPoint("TOPLEFT", h, "BOTTOMLEFT", 0, -6)
	local scope = UI:Dropdown(p, 170, function()
		-- "server" (Wert wie früher, für alte Versionen): Gilde und eigene Gruppe/Raid – kein Server-Kanal mehr
		return { { value = "guild", text = L["nur Gilde"] }, { value = "server", text = L["Gilde und Gruppe"] } }
	end, function() return Gp.form.scope end, function(v) Gp.form.scope = v end)
	scope:SetPoint("LEFT", act, "RIGHT", 8, 0)
	local need = UI:Dropdown(p, 130, function()
		local out = {}
		for _, n in ipairs({ 1, 2, 3, 4, 9, 19, 39 }) do out[#out + 1] = { value = n, text = string.format(L["%d frei"], n) } end
		return out
	end, function() return Gp.form.need end, function(v) Gp.form.need = v end)
	need:SetPoint("LEFT", scope, "RIGHT", 8, 0)
	Gp.startBtn = UI:Button(p, L["Suche starten"], 170, 24, function()
		local f = Gp.form
		G:Post(f.act, f.roles, f.need, Gp.note:GetText(), f.scope)
		Gp.note:SetText("")
		Gp:Refresh()
	end, true)
	Gp.startBtn:SetPoint("LEFT", need, "RIGHT", 10, 0)

	local gl = UI:Label(p, L["Gesucht:"], "GameFontHighlight")
	gl:SetPoint("TOPLEFT", act, "BOTTOMLEFT", 0, -12)
	local x = gl
	for _, r in ipairs(G.ROLES) do
		local c = UI:Check(p, G:RoleName(r), function() return Gp.form.roles[r] end, function(v) Gp.form.roles[r] = v end)
		c:SetPoint("LEFT", x, "RIGHT", (x == gl) and 8 or 60, 0)
		x = c
	end
	Gp.note = UI:Edit(p, 330, 24, L["Notiz (optional)"], false, 120)
	Gp.note:SetPoint("LEFT", x, "RIGHT", 80, 0)
	-- LevelPilot: Elite-Quest aus dem Questlog als Notiz übernehmen
	Gp.lpBtn = UI:Button(p, L["Elite-Quest (LevelPilot)"], 170, 24, function()
		local list = ns.Links:EliteQuests()
		if #list == 0 then ns:Print(L["LevelPilot kennt gerade keine offene Elite-Quest in deinem Questlog."]) return end
		Gp.lpIndex = ((Gp.lpIndex or 0) % #list) + 1
		local q = list[Gp.lpIndex]
		Gp.note:SetText(string.format(L["Elite-Quest: %s"], q.title))
		Gp.form.act = "quest"
		local m = ns.Links:EliteMatches()[q.id]
		if m and #m > 0 then
			local t = {}
			for _, x in ipairs(m) do t[#t + 1] = x.name .. " (" .. x.level .. ")" end
			ns:Print(string.format(L["LevelPilot: Mitspieler mit derselben Quest in deiner Nähe: %s"], table.concat(t, ", ")))
		end
	end)
	Gp.lpBtn:SetPoint("LEFT", Gp.note, "RIGHT", 8, 0)

	-- eigene Suche
	Gp.mine = UI:Label(p, "", "GameFontHighlight")
	Gp.mine:SetPoint("TOPLEFT", gl, "BOTTOMLEFT", 0, -16)
	Gp.mine:SetWidth(600)
	Gp.closeBtn = UI:Button(p, L["Suche beenden"], 140, 24, function()
		local s = G:Mine()
		if s then G:Close(s.id) end
	end)
	Gp.closeBtn:SetPoint("TOPRIGHT", 0, -78)

	-- offene Suchen
	Gp.list = UI:List(p, {
		{ key = "by", title = L["Wer"], width = 140 },
		{ key = "act", title = L["Was"], width = 200 },
		{ key = "roles", title = L["Gesucht"], width = 120 },
		{ key = "zone", title = L["Zone"], width = 150 },
		{ key = "note", title = L["Notiz"] },
	}, {
		key = function(s) return s.id end,
		render = function(s)
			local by = ns.Colored(s.by, s.c) .. Gray(" " .. (s.l or "?"))
			local mine = ns.Same(s.by, ns.Me())
			local fits = G:Fits(s)
			local actText = (fits and GREEN or "") .. G:ActivityName(s) .. (fits and "|r" or "")
			-- Suchen vom Server: Herkunft vor der Notiz (Gildensuchen ohne Zusatz)
			local where = s.scope == "server" and (ns.Same(s.gn, ns.GuildName()) and L["Gilde und Gruppe"] or (s.gn and ("<" .. s.gn .. ">") or L["Gruppe"])) or nil
			local zone = G:ZoneOf(s.by, s.z)
			local roles = G:RolesText(s) .. Gray(" · " .. string.format(L["%d frei"], s.need or 1))
			local note = s.note or ""
			if s.myJoin then note = GREEN .. L["du kommst mit"] .. "|r " .. note end
			if mine then note = GOLD .. string.format(L["deine Suche · %d Meldungen"], #G:Joins(s)) .. "|r " .. note end
			if where then note = Gray(where) .. " " .. note end
			if G.GearHint then note = G:GearHint(s.act) .. note end
			return { by, actText, roles, zone or Gray("?"), note }
		end,
		onClick = function() Gp:UpdateButtons() end,
		onEnter = function(row, s)
			GameTooltip:SetOwner(row, "ANCHOR_CURSOR")
			GameTooltip:AddLine(G:ActivityName(s), 1, 1, 1)
			local min, max = G:Range(s)
			if min then GameTooltip:AddLine(string.format(L["Stufe %d–%d"], min, max), 0.8, 0.8, 0.8) end
			GameTooltip:AddLine(string.format(L["%s · seit %s · läuft bis %s"], s.by, ns.Ago(s.t), date("%H:%M", s.exp)), 0.7, 0.7, 0.7)
			local z = G:ZoneOf(s.by, s.z)
			if z then GameTooltip:AddLine(L["Zone"] .. ": " .. z, 0.7, 0.7, 0.7) end
			if s.note and s.note ~= "" then GameTooltip:AddLine(s.note, 1, 1, 1, true) end
			GameTooltip:Show()
		end,
		empty = L["Gerade sucht niemand. Starte oben eine Suche – alle mit GuildSentinel bekommen einen Hinweis."],
	})
	Gp.list:SetPoint("TOPLEFT", 0, -110)
	Gp.list:SetPoint("RIGHT", 0, 0)
	Gp.list:SetHeight(210)

	Gp.myRole = UI:Dropdown(p, 130, function()
		local out = {}
		for _, r in ipairs(G.ROLES) do out[#out + 1] = { value = r, text = G:RoleName(r) } end
		return out
	end, function() return G:MyRole() end, function(v) G:SetMyRole(v) end)
	Gp.myRole:SetPoint("TOPLEFT", Gp.list, "BOTTOMLEFT", 0, -6)
	Gp.joinBtn = UI:Button(p, L["Ich komme mit"], 150, 24, function()
		local s = Gp.list:Selected()
		if s then G:Join(s.id, G:MyRole()) end
	end, true)
	Gp.joinBtn:SetPoint("LEFT", Gp.myRole, "RIGHT", 8, 0)
	Gp.whisperBtn = UI:Button(p, L["Anflüstern"], 120, 24, function()
		local s = Gp.list:Selected()
		if s then ns.Recruit:Whisper(s.by) end
	end)
	Gp.whisperBtn:SetPoint("LEFT", Gp.joinBtn, "RIGHT", 8, 0)

	-- Meldungen zur eigenen Suche
	local jh = UI:Header(p, L["Meldungen zu deiner Suche"])
	jh:SetPoint("TOPLEFT", Gp.myRole, "BOTTOMLEFT", 0, -14)
	Gp.joins = UI:List(p, {
		{ key = "name", title = L["Name"], width = 150 },
		{ key = "r", title = L["Rolle"], width = 90 },
		{ key = "l", title = L["Stufe"], width = 50, align = "CENTER" },
		{ key = "il", title = L["Gegenstandsst."], width = 100, align = "CENTER" },
		{ key = "z", title = L["Zone"], width = 140 },
		{ key = "t", title = L["Wann"], width = 80 },
		{ key = "st", title = L["Status"] },
	}, {
		key = function(j) return j.name end,
		render = function(j)
			return { ns.Colored(j.name, j.c), G:RoleName(j.r), tostring(j.l or "?"), j.il and tostring(j.il) or Gray("?"), j.z or Gray("?"), Gray(ns.Ago(j.t)), j.inv and (GREEN .. L["eingeladen"] .. "|r") or "" }
		end,
		onClick = function() Gp:UpdateButtons() end,
		empty = L["Noch keine Meldungen. Wer mitkommen will, erscheint hier."],
	})
	Gp.joins:SetPoint("TOPLEFT", jh, "BOTTOMLEFT", 0, -6)
	Gp.joins:SetPoint("BOTTOMRIGHT", -160, 0)
	Gp.inviteBtn = UI:Button(p, L["Einladen"], 150, 26, function()
		local j = Gp.joins:Selected()
		if j then G:Invite(j.name) end
	end, true)
	Gp.inviteBtn:SetPoint("TOPLEFT", Gp.joins, "TOPRIGHT", 10, 0)
	Gp.inviteAll = UI:Button(p, L["Alle einladen"], 150, 26, function()
		local s = G:Mine()
		for _, j in ipairs(G:Joins(s)) do if not j.inv then G:Invite(j.name) end end
	end)
	Gp.inviteAll:SetPoint("TOPLEFT", Gp.inviteBtn, "BOTTOMLEFT", 0, -6)
end

function Gp:UpdateButtons()
	local G = ns.Group
	local s = self.list:Selected()
	self.joinBtn:SetEnabled(s ~= nil and G:IsOpen(s) and not ns.Same(s.by, ns.Me()))
	self.whisperBtn:SetEnabled(s ~= nil and not ns.Same(s.by, ns.Me()))
	local mine = G:Mine()
	self.inviteBtn:SetEnabled(mine ~= nil and self.joins:Selected() ~= nil)
	self.inviteAll:SetEnabled(mine ~= nil and #G:Joins(mine) > 0)
end

function Gp:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	local G = ns.Group
	self.searchView:SetShown(self.view ~= "free")
	self.freeView:SetShown(self.view == "free")
	if self.view == "free" then self:RefreshFree() return end
	self.lpBtn:SetShown(ns.Links:Loaded("LevelPilot"))
	local mine = G:Mine()
	if mine then
		self.mine:SetText(string.format(L["Deine Suche: %s · %s · noch bis %s"], GREEN .. G:ActivityName(mine) .. "|r", G:RolesText(mine), date("%H:%M", mine.exp))
			.. (mine.scope == "server" and Gray(" · " .. L["Gilde und Gruppe"]) or "")
			.. ((mine.note and mine.note ~= "") and Gray(" · „" .. mine.note .. "“") or ""))
		self.startBtn:SetText(L["Neu starten"])
	else
		self.mine:SetText(Gray(L["Du suchst gerade nicht."]))
		self.startBtn:SetText(L["Suche starten"])
	end
	self.closeBtn:SetShown(mine ~= nil)
	self.list:SetData(G:Open())
	self.joins:SetData(G:Joins(mine))
	self:UpdateButtons()
end

------------------------------------------------------------
-- Reiter "Wer ist frei"
------------------------------------------------------------
Gp.freeForm = { kinds = { dungeon = true }, hours = 2 }

function Gp:BuildFree(v)
	local Fr = ns.Free
	local h = UI:Header(v, L["Ich bin frei für"])
	h:SetPoint("TOPLEFT", 0, 0)
	local x
	for i, k in ipairs(Fr.KINDS) do
		local c = UI:Check(v, L[k.n], function() return Gp.freeForm.kinds[k.key] end, function(val) Gp.freeForm.kinds[k.key] = val or nil end)
		if i == 1 then c:SetPoint("TOPLEFT", h, "BOTTOMLEFT", 0, -8) else c:SetPoint("LEFT", x, "RIGHT", 110, 0) end
		x = c
	end
	local dur = UI:Dropdown(v, 120, function()
		local out = {}
		for _, n in ipairs(Fr.DURATIONS) do out[#out + 1] = { value = n, text = string.format(L["%d Std."], n) } end
		return out
	end, function() return Gp.freeForm.hours end, function(val) Gp.freeForm.hours = val end)
	dur:SetPoint("LEFT", x, "RIGHT", 110, 0)
	Gp.freeBtn = UI:Button(v, L["Frei melden"], 150, 24, function()
		Fr:Set(Gp.freeForm.kinds, Gp.freeForm.hours)
	end, true)
	Gp.freeBtn:SetPoint("LEFT", dur, "RIGHT", 10, 0)
	Gp.freeOff = UI:Button(v, L["Nicht mehr frei"], 140, 24, function() Fr:Clear() end)
	Gp.freeOff:SetPoint("LEFT", Gp.freeBtn, "RIGHT", 8, 0)
	Gp.freeMine = UI:Label(v, "", "GameFontHighlightSmall")
	Gp.freeMine:SetPoint("TOPLEFT", h, "BOTTOMLEFT", 0, -40)
	Gp.freeMine:SetWidth(780)
	Gp.freeMine:SetJustifyH("LEFT")
	Gp.freeFilter = nil
	local filt = UI:Dropdown(v, 170, function()
		local out = { { value = "all", text = L["Alle"] } }
		for _, k in ipairs(Fr.KINDS) do out[#out + 1] = { value = k.key, text = L[k.n] } end
		return out
	end, function() return Gp.freeFilter or "all" end, function(val) Gp.freeFilter = (val ~= "all") and val or nil; Gp:RefreshFree() end)
	filt:SetPoint("TOPRIGHT", 0, -76)
	local fl = UI:Label(v, L["Zeigen:"], "GameFontHighlightSmall")
	fl:SetPoint("RIGHT", filt, "LEFT", -6, 0)
	Gp.freeList = UI:List(v, {
		{ key = "name", title = L["Name"], width = 150 },
		{ key = "l", title = L["Stufe"], width = 50, align = "CENTER" },
		{ key = "il", title = L["Gegenstandsst."], width = 100, align = "CENTER" },
		{ key = "k", title = L["Frei für"], width = 210 },
		{ key = "z", title = L["Zone"], width = 150 },
		{ key = "st", title = L["Status"] },
	}, {
		key = function(e) return e.name end,
		render = function(e)
			local st = e.busy and (ORANGE .. L["in einer Instanz"] .. "|r") or (GREEN .. string.format(L["frei bis %s"], date("%H:%M", e.u)) .. "|r")
			local name = ns.Colored(e.name, e.c) .. (e.me and Gray(" (" .. L["du"] .. ")") or "")
			return { name, tostring(e.l or "?"), e.il and tostring(e.il) or Gray("?"), Fr:KindsText(e.k), e.z or Gray("?"), st }
		end,
		onClick = function() Gp:UpdateFreeButtons() end,
		empty = L["Gerade hat sich niemand frei gemeldet. Melde dich oben frei – alle mit GuildSentinel sehen es hier."],
	})
	Gp.freeList:SetPoint("TOPLEFT", 0, -104)
	Gp.freeList:SetPoint("BOTTOMRIGHT", 0, 40)
	Gp.freeWhisper = UI:Button(v, L["Anflüstern"], 130, 26, function()
		local e = Gp.freeList:Selected()
		if e then ns.Recruit:Whisper(e.name) end
	end)
	Gp.freeWhisper:SetPoint("BOTTOMLEFT", 0, 4)
	Gp.freeInvite = UI:Button(v, L["In Gruppe einladen"], 160, 26, function()
		local e = Gp.freeList:Selected()
		if e then ns.InviteParty(e.name) end
	end, true)
	Gp.freeInvite:SetPoint("LEFT", Gp.freeWhisper, "RIGHT", 8, 0)
	local hint = UI:Label(v, Gray(L["In Dungeons, Raids und Schlachtfeldern giltst du automatisch als beschäftigt."]), "GameFontHighlightSmall")
	hint:SetPoint("LEFT", Gp.freeInvite, "RIGHT", 12, 0)
end

function Gp:UpdateFreeButtons()
	local e = self.freeList:Selected()
	local other = e ~= nil and not e.me
	self.freeWhisper:SetEnabled(other)
	self.freeInvite:SetEnabled(other and not e.busy)
end

function Gp:RefreshFree()
	local Fr = ns.Free
	local mine = Fr:Mine()
	if mine then
		self.freeMine:SetText(string.format(L["Du bist frei für %s bis %s."], GREEN .. Fr:KindsText(mine.k) .. "|r", date("%H:%M", mine.u))
			.. (Fr:InInstance() and (" " .. ORANGE .. L["Gerade in einer Instanz – du wirst als beschäftigt angezeigt."] .. "|r") or ""))
		self.freeBtn:SetText(L["Ändern"])
	else
		self.freeMine:SetText(Gray(L["Du bist gerade nicht als frei gemeldet."]))
		self.freeBtn:SetText(L["Frei melden"])
	end
	self.freeOff:SetEnabled(mine ~= nil)
	self.freeList:SetData(Fr:List(self.freeFilter))
	self:UpdateFreeButtons()
end

Gp.onShow = function(_, arg)
	if arg == "free" or arg == "search" then Gp.view = arg end
	Gp.tabs:Select(Gp.view or "search")
end
ns:Listen("GS_FREE", WhenShown("group", function() Gp:Refresh() end))
ns:Listen("GS_LFG", WhenShown("group", function() Gp:Refresh() end))
ns:Listen("GS_LFG_TICK", WhenShown("group", function() Gp:Refresh() end))
ns:Listen("GS_LFG", function() UI:RefreshHeader() end)
UI:AddPage(Gp)

------------------------------------------------------------
-- Seite: Fortschritt (Leveling-Rennen, Raid-Zugänge)
------------------------------------------------------------
local Pr = { key = "progress", features = { "race", "attune", "goals", "thanks", "chronicle" }, order = 30, icon = "Interface\\Icons\\INV_Misc_Note_01" }
Pr.title = N["Fortschritt"]
Pr.view = "race"
Pr.mainsOnly = true
Pr.minLevel = ns.Game.COMP_MIN

local function Mark(st)
	if st == true then return GREEN .. L["Ja"] .. "|r" end
	if st == false then return RED .. L["Nein"] .. "|r" end
	return Gray("?")
end

function Pr.build(p)
	Pr.panel = p
	Pr.tabs = UI:Tabs(p, {
		{ key = "race", text = L["Leveling-Rennen"], feature = "race" },
		{ key = "attune", text = L["Zugänge & Schlüssel"], feature = "attune" },
		{ key = "goals", text = L["Gildenziele"], feature = "goals" },
		{ key = "thanks", text = L["Hilfsbereit"], feature = "thanks" },
		{ key = "achv", text = L["Erfolge"], feature = "chronicle" },
		{ key = "chron", text = L["Chronik"], feature = "chronicle" },
	}, function(key) Pr.view = key; Pr:Refresh() end)
	Pr.tabs:SetPoint("TOPLEFT")
	Pr.tabs:SetPoint("TOPRIGHT")

	-- Rennen ----------------------------------------------
	local rv = CreateFrame("Frame", nil, p)
	rv:SetPoint("TOPLEFT", 0, -34)
	rv:SetPoint("BOTTOMRIGHT")
	Pr.raceView = rv
	Pr.first = UI:Label(rv, "", "GameFontNormalLarge")
	Pr.first:SetPoint("TOPLEFT", 0, -2)
	local mo = UI:Check(rv, L["nur Mains"], function() return Pr.mainsOnly end, function(v) Pr.mainsOnly = v; Pr:Refresh() end)
	mo:SetPoint("TOPRIGHT", -80, 0)
	Pr.raceStats = UI:Label(rv, "", "GameFontHighlightSmall")
	Pr.raceStats:SetPoint("TOPLEFT", Pr.first, "BOTTOMLEFT", 0, -6)
	Pr.raceList = UI:List(rv, {
		{ key = "rank", title = "#", width = 26, align = "RIGHT" },
		{ key = "name", title = L["Name"], width = 170 },
		{ key = "level", title = L["Stufe"], width = 50, align = "CENTER" },
		{ key = "class", title = L["Klasse"], width = 110 },
		{ key = "t", title = L["Stufe erreicht"], width = 130 },
		{ key = "gain", title = L["Letzte 7 Tage"], width = 100, align = "CENTER" },
		{ key = "on", title = L["Status"] },
	}, {
		key = function(x) return x.name end,
		render = function(x)
			local medal = (x.rank == 1 and GOLD) or (x.rank == 2 and "|cffd0d0d0") or (x.rank == 3 and "|cffcd7f32") or ""
			return { medal .. x.rank .. (medal ~= "" and "|r" or ""), ns.Colored(x.name, x.class), tostring(x.level), ns.ClassName(x.class),
				x.t and Gray(ns.Ago(x.t)) or Gray(L["unbekannt"]),
				x.gain and (x.gain > 0 and (GREEN .. "+" .. x.gain .. "|r") or Gray("0")) or Gray("?"),
				x.online and (GREEN .. L["online"] .. "|r") or "" }
		end,
		empty = L["Noch keine Gildendaten."],
	})
	Pr.raceList:SetPoint("TOPLEFT", 0, -46)
	Pr.raceList:SetPoint("BOTTOMRIGHT", 0, 24)
	local rh = UI:Label(rv, Gray(L["Bei gleicher Stufe steht vorne, wer sie zuerst erreicht hat. Die Stufen kommen aus der Gildenliste – das Addon braucht dafür niemand."]), "GameFontHighlightSmall")
	rh:SetPoint("BOTTOMLEFT", 0, 4)
	rh:SetPoint("RIGHT")

	-- Raid-Zugänge ----------------------------------------
	local av = CreateFrame("Frame", nil, p)
	av:SetPoint("TOPLEFT", 0, -34)
	av:SetPoint("BOTTOMRIGHT")
	Pr.attView = av
	local ml = UI:Label(av, L["ab Stufe"], "GameFontHighlight")
	ml:SetPoint("TOPLEFT", 0, -5)
	local dd = UI:Dropdown(av, 80, function()
		local out = {}
		for _, l in ipairs(ns.Game.LFG_LEVELS) do out[#out + 1] = { value = l, text = tostring(l) } end
		return out
	end, function() return Pr.minLevel end, function(v) Pr.minLevel = v; Pr:Refresh() end)
	dd:SetPoint("LEFT", ml, "RIGHT", 8, 0)
	local mo2 = UI:Check(av, L["nur Mains"], function() return Pr.mainsOnly end, function(v) Pr.mainsOnly = v; Pr:Refresh() end)
	mo2:SetPoint("LEFT", dd, "RIGHT", 14, 0)
	-- Gruppe: Raid-Zugänge, Dungeon-Schlüssel, heroische Schlüssel (TBC) – sonst wird die Tabelle zu breit
	local grp = UI:Dropdown(av, 170, function()
		local out = {}
		for _, g in ipairs(ns.Attune:Groups()) do out[#out + 1] = { value = g.key, text = L[g.n] } end
		return out
	end, function() return Pr.attGroup end, function(v) Pr.attGroup = v; Pr:ShowAttGroup() end)
	grp:SetPoint("LEFT", mo2, "RIGHT", 110, 0)
	Pr.attGroupDD = grp
	Pr.attSummary = UI:Label(av, "", "GameFontHighlightSmall")
	Pr.attSummary:SetPoint("TOPRIGHT", 0, -6)
	Pr.attSummary:SetJustifyH("RIGHT")
	Pr.attLists, Pr.attLegends = {}, {}
	for _, g in ipairs(ns.Attune:Groups()) do
		local items = ns.Attune:InGroup(g.key)
		local cols = {
			{ key = "name", title = L["Name"], width = 170 },
			{ key = "level", title = L["Stufe"], width = 50, align = "CENTER" },
		}
		for _, a in ipairs(items) do cols[#cols + 1] = { key = a.key, title = a.short, width = 70, align = "CENTER" } end
		cols[#cols + 1] = { key = "info", title = "" }
		local list = UI:List(av, cols, {
			key = function(x) return x.name end,
			render = function(x)
				local out = { ns.Colored(x.name, x.class), tostring(x.level) }
				for _, a in ipairs(items) do out[#out + 1] = Mark(ns.Attune:Status(x.name, a.key)) end
				out[#out + 1] = x.known and "" or Gray(L["ohne GuildSentinel"])
				return out
			end,
			onEnter = function(row, x)
				GameTooltip:SetOwner(row, "ANCHOR_CURSOR")
				GameTooltip:AddLine(ns.Colored(x.name, x.class))
				for _, a in ipairs(ns.Attune.LIST) do
					GameTooltip:AddDoubleLine(ns.Attune:Name(a), Mark(ns.Attune:Status(x.name, a.key)), 0.8, 0.8, 0.8)
				end
				GameTooltip:Show()
			end,
			empty = L["Niemand in dieser Stufe."],
		})
		list:SetPoint("TOPLEFT", 0, -32)
		list:SetPoint("BOTTOMRIGHT", 0, 44)
		list:Hide()
		Pr.attLists[g.key] = list
		local leg = UI:Label(av, "", "GameFontHighlightSmall")
		leg:SetPoint("TOPLEFT", list, "BOTTOMLEFT", 0, -6)
		leg:SetPoint("RIGHT")
		leg:SetJustifyH("LEFT")
		leg:SetJustifyV("TOP")
		leg:Hide()
		leg.items = items
		Pr.attLegends[g.key] = leg
	end
	Pr.attGroup = ns.Attune:Groups()[1].key

	Pr:BuildGoals(p)
	Pr:BuildThanks(p)
	Pr.tabs:Select("race")
	-- weitere Reiter anderer Dateien
	for _, fn in ipairs(Pr.extra or {}) do fn(p) end
end

function Pr:BuildGoals(p)
	local v = CreateFrame("Frame", nil, p)
	v:SetPoint("TOPLEFT", 0, -34)
	v:SetPoint("BOTTOMRIGHT")
	self.goalView = v
	local h = UI:Header(v, L["Wochenziel"])
	h:SetPoint("TOPLEFT", 0, -2)
	self.goalText = UI:Label(v, "", "GameFontHighlight")
	self.goalText:SetPoint("LEFT", h, "RIGHT", 12, 0)
	self.goalSet = UI:Button(v, L["Ziel ändern"], 120, 22, function()
		UI:Ask(L["Wie viele Stufen soll die Gilde diese Woche schaffen?"], tostring(ns.Goals:Target()), function(t) ns.Goals:SetTarget(t) end)
	end)
	self.goalSet:SetPoint("TOPRIGHT", 0, 0)
	local bar = CreateFrame("Frame", nil, v, UI.BACKDROP)
	bar:SetPoint("TOPLEFT", 0, -28)
	bar:SetPoint("RIGHT")
	bar:SetHeight(26)
	UI.Box(bar, 0.06, 0.07, 0.09, 1, 0.25, 0.28, 0.34, 1)
	bar.fill = bar:CreateTexture(nil, "ARTWORK")
	bar.fill:SetPoint("TOPLEFT", 1, -1)
	bar.fill:SetPoint("BOTTOMLEFT", 1, 1)
	bar.fill:SetTexture(UI.WHITE)
	bar.fill:SetVertexColor(ns.ACCENT[1], ns.ACCENT[2], ns.ACCENT[3], 0.6)
	bar.text = bar:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	bar.text:SetPoint("CENTER")
	self.goalBar = bar
	self.goalTop = UI:Label(v, "", "GameFontHighlightSmall")
	self.goalTop:SetPoint("TOPLEFT", bar, "BOTTOMLEFT", 0, -8)
	self.goalTop:SetWidth(780)
	local h2 = UI:Header(v, L["Gilden-Meilensteine"])
	h2:SetPoint("TOPLEFT", self.goalTop, "BOTTOMLEFT", 0, -16)
	self.mileList = UI:List(v, {
		{ key = "text", title = L["Erreicht"] },
		{ key = "t", title = L["Wann"], width = 130 },
	}, {
		render = function(m) return { GOLD .. m.text .. "|r", Gray(ns.Date(m.t)) } end,
		empty = string.format(L["Noch keine Meilensteine – die ersten kommen mit Stufe %d, 10 Spielern und den ersten Raid-Zugängen."], ns.Roster.MAX_LEVEL),
	})
	self.mileList:SetPoint("TOPLEFT", h2, "BOTTOMLEFT", 0, -6)
	self.mileList:SetPoint("BOTTOMRIGHT")
end

function Pr:BuildThanks(p)
	local v = CreateFrame("Frame", nil, p)
	v:SetPoint("TOPLEFT", 0, -34)
	v:SetPoint("BOTTOMRIGHT")
	self.thanksView = v
	local hint = UI:Label(v, Gray(L["Mit „Danke sagen“ (Mitglieder, Rechtsklick auf einen Namen oder /gs danke Name) dankt ihr für Hilfe – einmal am Tag je Spieler."]), "GameFontHighlightSmall")
	hint:SetPoint("TOPLEFT", 0, -4)
	hint:SetWidth(780)
	self.thanksList = UI:List(v, {
		{ key = "rank", title = "#", width = 26, align = "RIGHT" },
		{ key = "name", title = L["Name"], width = 170 },
		{ key = "n", title = L["Danke (30 Tage)"], width = 110, align = "CENTER" },
		{ key = "why", title = L["Zuletzt"] },
	}, {
		render = function(x)
			local r = ns.G().roster[x.name]
			local medal = (x.rank == 1 and GOLD) or (x.rank == 2 and "|cffd0d0d0") or (x.rank == 3 and "|cffcd7f32") or ""
			local why = (x.why and x.why ~= "") and (x.why .. Gray(" – " .. (x.lastFrom or ""))) or Gray(string.format(L["von %s, %s"], x.lastFrom or "?", ns.Ago(x.last)))
			return { medal .. x.rank .. (medal ~= "" and "|r" or ""), ns.Colored(x.name, r and r.c), tostring(x.n), why }
		end,
		empty = L["Noch keine Dank-Punkte. Wer hilft, bekommt einen Klick!"],
	})
	self.thanksList:SetPoint("TOPLEFT", 0, -24)
	self.thanksList:SetPoint("BOTTOMRIGHT")
end

function Pr:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	self.raceView:SetShown(self.view == "race")
	self.attView:SetShown(self.view == "attune")
	self.goalView:SetShown(self.view == "goals")
	self.thanksView:SetShown(self.view == "thanks")
	-- zusätzliche Reiter (Erfolge, Chronik) kommen aus PagesExtra.lua
	local extra = self.extraViews and self.extraViews[self.view]
	for key, x in pairs(self.extraViews or {}) do x.frame:SetShown(key == self.view) end
	if extra then extra.refresh() return end
	if self.view == "goals" then
		local total, top = ns.Goals:WeekLevels()
		local target = ns.Goals:Target()
		local f = math.min(1, total / math.max(1, target))
		self.goalBar.fill:SetWidth(math.max(1, ((self.goalBar:GetWidth() or 780) - 2) * f))
		self.goalBar.text:SetText(string.format(L["%d von %d Stufen (%d%%)"], total, target, math.floor(f * 100 + 0.5)))
		self.goalText:SetText(Gray(string.format(L["seit Mittwoch, %s"], date(L["%d.%m."], ns.Goals:WeekStart()))) .. (total >= target and ("  " .. GREEN .. L["geschafft!"] .. "|r") or ""))
		local t = {}
		for i = 1, math.min(8, #top) do t[i] = top[i].name .. " +" .. top[i].n end
		self.goalTop:SetText(#t > 0 and (L["Diese Woche am fleißigsten: "] .. table.concat(t, ", ")) or Gray(L["Diese Woche noch keine Stufen."]))
		self.goalSet:SetEnabled(ns.IsOfficer())
		self.mileList:SetData(ns.Goals:Miles())
		return
	elseif self.view == "thanks" then
		local top = ns.Social:ThanksTop(30)
		for i, x in ipairs(top) do x.rank = i end
		self.thanksList:SetData(top)
		return
	end
	if self.view == "race" then
		local f = ns.Race:First60()
		if f then
			local r = ns.G().roster[f.n]
			self.first:SetText(string.format(L["Erstes Gildenmitglied auf Stufe %d: %s"], ns.Roster.MAX_LEVEL, ns.Colored(f.n, r and r.c)) .. Gray(f.t and f.t > 0 and ("  " .. ns.Date(f.t)) or ""))
		else
			self.first:SetText(string.format(L["Wer ist als Erstes auf Stufe %d?"], ns.Roster.MAX_LEVEL))
		end
		local list = ns.Race:Ranking(self.mainsOnly)
		local sum, at60, gained = 0, 0, 0
		for _, x in ipairs(list) do
			sum = sum + x.level
			if x.level >= ns.Roster.MAX_LEVEL then at60 = at60 + 1 end
			gained = gained + (x.gain or 0)
		end
		self.raceStats:SetText(Gray(string.format(L["%d Spieler · Durchschnitt Stufe %.1f · %d auf Höchststufe · %d Stufen in den letzten 7 Tagen"],
			#list, #list > 0 and sum / #list or 0, at60, gained)))
		self.raceList:SetData(list)
	else
		self:ShowAttGroup()
	end
end

-- gewählte Gruppe der Zugänge zeigen (Tabelle, Legende, Zusammenfassung)
function Pr:ShowAttGroup()
	if not self.attLists then return end
	for key, list in pairs(self.attLists) do
		list:SetShown(key == self.attGroup)
		self.attLegends[key]:SetShown(key == self.attGroup)
	end
	if self.attGroupDD then self.attGroupDD.Refresh() end
	local list, leg = self.attLists[self.attGroup], self.attLegends[self.attGroup]
	if not list then return end
	local rows = ns.Attune:Rows(self.minLevel, self.mainsOnly)
	list:SetData(rows)
	local s = ns.Attune:Summary(rows)
	local t, names = {}, {}
	for _, a in ipairs(leg.items) do
		t[#t + 1] = string.format("%s %s%d|r/%d", a.short, GREEN, s[a.key].yes, s[a.key].yes + s[a.key].no)
		names[#names + 1] = a.short .. " = " .. ns.Attune:Name(a)
	end
	self.attSummary:SetText(table.concat(t, "   "))
	leg:SetText(Gray(table.concat(names, " · ") .. ". " .. L["? = hat GuildSentinel nicht, darum unbekannt."]))
end

Pr.onShow = function(_, arg)
	if arg then Pr.tabs:Select(arg) else Pr:Refresh() end
end
ns:Listen("GS_ROSTER", WhenShown("progress", function() Pr:Refresh() end))
ns:Listen("GS_ATTUNE", WhenShown("progress", function() Pr:Refresh() end))
ns:Listen("GS_PROGRESS", WhenShown("progress", function() Pr:Refresh() end))
ns:Listen("GS_GOALS", WhenShown("progress", function() Pr:Refresh() end))
ns:Listen("GS_SOCIAL", WhenShown("progress", function() if Pr.view == "thanks" then Pr:Refresh() end end))
ns.ProgressPage = Pr
UI:AddPage(Pr)

------------------------------------------------------------
-- Seite: Umfragen
------------------------------------------------------------
local Po = { key = "poll", feature = "poll", order = 25, icon = "Interface\\Icons\\INV_Scroll_03" }
Po.title = N["Umfragen"]
Po.view = "vote"
Po.hours = 24
Po.anon = false
Po.badge = function()
	local n = ns.Poll:OpenUnvoted()
	return n > 0 and (GOLD .. n .. "|r") or ""
end

function Po.build(p)
	Po.panel = p
	Po.tabs = UI:Tabs(p, {
		{ key = "vote", text = L["Abstimmen"] },
		{ key = "new", text = L["Neue Umfrage"] },
	}, function(key) Po.view = key; Po:Refresh() end)
	Po.tabs:SetPoint("TOPLEFT")
	Po.tabs:SetPoint("TOPRIGHT")

	-- Abstimmen ------------------------------------------
	local v = CreateFrame("Frame", nil, p)
	v:SetPoint("TOPLEFT", 0, -34)
	v:SetPoint("BOTTOMRIGHT")
	Po.voteView = v
	Po.list = UI:List(v, {
		{ key = "q", title = L["Frage"] },
		{ key = "st", title = L["Stand"], width = 90 },
	}, {
		rowH = 24,
		key = function(x) return x.id end,
		render = function(x)
			local _, total, _, mine = ns.Poll:Results(x)
			local open = ns.Poll:IsOpen(x)
			local q = (open and not mine) and (GOLD .. x.q .. "|r") or x.q
			local st = open and (mine and (GREEN .. L["abgestimmt"] .. "|r") or (ORANGE .. L["offen"] .. "|r")) or Gray(L["beendet"])
			return { q, st .. Gray(" · " .. total) }
		end,
		onClick = function() Po:ShowDetail() end,
		empty = L["Keine Umfragen. Offiziere starten eine unter „Neue Umfrage“."],
	})
	Po.list:SetPoint("TOPLEFT")
	Po.list:SetPoint("BOTTOMLEFT")
	Po.list:SetWidth(320)

	local d = CreateFrame("Frame", nil, v, UI.BACKDROP)
	d:SetPoint("TOPLEFT", Po.list, "TOPRIGHT", 10, 0)
	d:SetPoint("BOTTOMRIGHT")
	UI.Box(d, 0.07, 0.08, 0.11, 1, 0.18, 0.2, 0.25, 1)
	Po.detail = d
	d.q = UI:Label(d, "", "GameFontNormalLarge")
	d.q:SetPoint("TOPLEFT", 14, -12)
	d.q:SetPoint("RIGHT", -14, 0)
	d.q:SetJustifyV("TOP")
	d.sub = UI:Label(d, "", "GameFontDisableSmall")
	d.sub:SetPoint("TOPLEFT", d.q, "BOTTOMLEFT", 0, -6)
	d.rows = {}
	for i = 1, ns.Poll.MAX_OPTIONS do
		local b = CreateFrame("Button", nil, d, UI.BACKDROP)
		b:SetHeight(34)
		b:SetPoint("TOPLEFT", 14, -64 - (i - 1) * 40)
		b:SetPoint("RIGHT", -14, 0)
		UI.Box(b, 0.1, 0.11, 0.15, 1, 0.25, 0.28, 0.34, 1)
		b.bar = b:CreateTexture(nil, "ARTWORK")
		b.bar:SetPoint("TOPLEFT", 1, -1)
		b.bar:SetPoint("BOTTOMLEFT", 1, 1)
		b.bar:SetTexture(UI.WHITE)
		b.bar:SetVertexColor(ns.ACCENT[1], ns.ACCENT[2], ns.ACCENT[3], 0.35)
		b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
		b.text:SetPoint("LEFT", 10, 0)
		b.text:SetPoint("RIGHT", -110, 0)
		b.text:SetJustifyH("LEFT")
		b.count = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
		b.count:SetPoint("RIGHT", -10, 0)
		local hl = b:CreateTexture(nil, "HIGHLIGHT")
		hl:SetAllPoints()
		hl:SetTexture(UI.WHITE)
		hl:SetVertexColor(1, 1, 1, 0.06)
		b:SetScript("OnClick", function()
			local x = Po.list:Selected()
			if x and ns.Poll:IsOpen(x) then ns.Poll:Vote(x.id, i) end
		end)
		b:SetScript("OnEnter", function(self)
			local x = Po.list:Selected()
			if not x or x.anon or not self.voters or #self.voters == 0 then return end
			GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
			GameTooltip:AddLine(x.o[i], 1, 1, 1)
			GameTooltip:AddLine(table.concat(self.voters, ", "), 0.8, 0.8, 0.8, true)
			GameTooltip:Show()
		end)
		b:SetScript("OnLeave", function() GameTooltip:Hide() end)
		d.rows[i] = b
	end
	d.hint = UI:Label(d, "", "GameFontHighlightSmall")
	d.hint:SetPoint("BOTTOMLEFT", 14, 14)
	d.hint:SetPoint("RIGHT", -170, 0)
	d.close = UI:Button(d, L["Umfrage beenden"], 150, 26, function()
		local x = Po.list:Selected()
		if x then UI:Confirm(L["Umfrage beenden? Danach kann niemand mehr abstimmen."], function() ns.Poll:Close(x.id) end) end
	end)
	d.close:SetPoint("BOTTOMRIGHT", -12, 10)

	-- Neue Umfrage ----------------------------------------
	local n = CreateFrame("Frame", nil, p)
	n:SetPoint("TOPLEFT", 0, -34)
	n:SetPoint("BOTTOMRIGHT")
	Po.newView = n
	local h1 = UI:Header(n, L["Frage"])
	h1:SetPoint("TOPLEFT", 0, 0)
	Po.qEdit = UI:Edit(n, 600, 26, L["z. B. Raid lieber Mittwoch oder Donnerstag?"], false, 200)
	Po.qEdit:SetPoint("TOPLEFT", h1, "BOTTOMLEFT", 0, -6)
	local h2 = UI:Header(n, L["Antworten (eine pro Zeile, 2 bis 8)"])
	h2:SetPoint("TOPLEFT", Po.qEdit, "BOTTOMLEFT", 0, -16)
	Po.oEdit = UI:ScrollEdit(n, 600, 170, 600, L["Mittwoch\nDonnerstag\nEgal"])
	Po.oEdit:SetPoint("TOPLEFT", h2, "BOTTOMLEFT", 0, -6)
	local dl = UI:Label(n, L["Läuft"], "GameFontHighlight")
	dl:SetPoint("TOPLEFT", Po.oEdit, "BOTTOMLEFT", 0, -18)
	local dd = UI:Dropdown(n, 140, function()
		return { { value = 1, text = L["1 Stunde"] }, { value = 24, text = L["1 Tag"] }, { value = 72, text = L["3 Tage"] }, { value = 168, text = L["7 Tage"] } }
	end, function() return Po.hours end, function(val) Po.hours = val end)
	dd:SetPoint("LEFT", dl, "RIGHT", 8, 0)
	local an = UI:Check(n, L["Geheim (Namen der Abstimmenden nicht zeigen)"], function() return Po.anon end, function(val) Po.anon = val end)
	an:SetPoint("LEFT", dd, "RIGHT", 16, 0)
	Po.startBtn = UI:Button(n, L["Umfrage starten"], 200, 30, function()
		local opts = {}
		for line in (Po.oEdit:GetText() .. "\n"):gmatch("([^\n]*)\n") do opts[#opts + 1] = line end
		local x = ns.Poll:Create(Po.qEdit:GetText(), opts, Po.hours, Po.anon)
		if x then
			Po.qEdit:SetText("")
			Po.oEdit:SetText("")
			Po.tabs:Select("vote")
			Po.list.selectedKey = x.id
			Po:Refresh()
		end
	end, true)
	Po.startBtn:SetPoint("TOPLEFT", dl, "BOTTOMLEFT", 0, -22)
	Po.newHint = UI:Label(n, "", "GameFontHighlightSmall")
	Po.newHint:SetPoint("LEFT", Po.startBtn, "RIGHT", 14, 0)
	Po.newHint:SetWidth(400)

	Po.tabs:Select("vote")
end

function Po:ShowDetail()
	local d = self.detail
	local x = self.list:Selected()
	if not x then
		local list = ns.Poll:List()
		x = list[1]
		if x then self.list.selectedKey = x.id; self.list:Draw() end
	end
	if not x then
		d.q:SetText(Gray(L["Wähle links eine Umfrage."]))
		d.sub:SetText("")
		for _, b in ipairs(d.rows) do b:Hide() end
		d.hint:SetText("")
		d.close:Hide()
		return
	end
	local counts, total, voters, mine = ns.Poll:Results(x)
	local open = ns.Poll:IsOpen(x)
	d.q:SetText(x.q)
	d.sub:SetText(string.format(total == 1 and L["von %s · %s · %d Stimme"] or L["von %s · %s · %d Stimmen"], x.by, open and string.format(L["läuft bis %s"], ns.Date(x.exp)) or L["beendet"], total)
		.. (x.anon and (" · " .. L["geheim"]) or ""))
	local width = (d:GetWidth() or 440) - 30
	for i, b in ipairs(d.rows) do
		local opt = x.o[i]
		if opt then
			local c = counts[i]
			local pct = total > 0 and (c / total) or 0
			b.bar:SetWidth(math.max(1, (width - 2) * pct))
			b.text:SetText((mine == i and (GREEN .. "> " .. "|r") or "") .. opt)
			b.count:SetText(string.format("%d  (%d%%)", c, math.floor(pct * 100 + 0.5)))
			b.voters = voters[i]
			b:SetEnabled(open)
			b:Show()
		else
			b:Hide()
		end
	end
	d.hint:SetText(open and Gray(mine and L["Deine Stimme kannst du bis zum Ende ändern – einfach eine andere Antwort anklicken."] or L["Zum Abstimmen eine Antwort anklicken."]) or Gray(L["Diese Umfrage ist beendet."]))
	d.close:SetShown(open and ns.Poll:CanClose(x))
end

function Po:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	self.voteView:SetShown(self.view == "vote")
	self.newView:SetShown(self.view == "new")
	if self.view == "vote" then
		self.list:SetData(ns.Poll:List())
		self:ShowDetail()
	else
		local can = ns.Poll:CanCreate()
		self.startBtn:SetEnabled(can)
		self.newHint:SetText(can and Gray(L["Alle mit GuildSentinel bekommen einen Hinweis und stimmen mit einem Klick ab. Twinks zählen für ihren Main."])
			or (ORANGE .. L["Umfragen können nur Offiziere starten."] .. "|r"))
	end
end

Po.onShow = function() Po:Refresh() end
ns:Listen("GS_POLL", WhenShown("poll", function() Po:Refresh() end))
ns:Listen("GS_POLL", function() UI:RefreshHeader() end)
UI:AddPage(Po)
