if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Buchhaltung neu "wie die Profis" (Anweisung der Prüf-Sitzung BP1–BP7, Entscheid des Nutzers 10.11.)
--
-- Gewinn = realisierter Gewinn: Erlös verkaufter Ware nach 5 % − Kostenbasis der verkauften Stücke − verlorene
-- Einstellgebühren. Einkauf ist ergebnisneutral (Gold wird zu Ware). Kostenbasis je Item und Charakter als gleitender
-- Durchschnitt (q Stück, c Kupfer). Entzaubern und Post an eigene Twinks sind Umbuchungen.
--
-- Daten: AHSentinelDB.books (neue Tabelle, nur zusätzlich). Die alten Buchungen (db.ledger.entries) bleiben für
-- Statistik, Absatz und Prognose, wie sie sind; db.ledger.archive merkt den Stichtag. Sie fliessen NIE in die neue
-- Buchhaltung. Entzauber-, Lern-, Prognose- und Vollscan-Daten werden nicht angefasst.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local BK = {}
A.Books = BK

BK.LOG_MAX = 4000              -- so viele Buchungen bleiben (älteste zuerst weg; Summen je Tag bleiben in days)
BK.MATCH_BEFORE = 2 * 3600     -- Rechnung darf so viel vor der "ausstehend"-Buchung liegen (Uhr/Post-Verzögerung)
BK.MATCH_AFTER = 31 * 86400
BK.PENDING_OLD = 24 * 3600     -- BH-AUS: ausstehend länger als 24 Std. ohne Rechnung -> Bericht
BK.SOLD_KEEP = 3 * 86400       -- verkaufte auctionIDs so lange merken (nie doppelt "ausstehend")
BK.DIFF_WARN = 10000           -- Abstimmung: ab 1g Differenz ins Protokoll (einmal je Tag)

local function Now() return time() end

-- ------------------------------------------------------------
-- Speicher (Testroutine: Ersatztabelle BK.testDB; während der Routine ohne Ersatz: nichts buchen)
-- ------------------------------------------------------------
local function NewDB(since)
    return { v = 1, since = since or Now(), cb = {}, opened = {}, log = {}, seenSold = {}, gold = {}, diffDay = 0 }
end
BK.NewDB = NewDB
function BK:Data()
    if self.testDB then return self.testDB end
    return A.db and A.db.books
end
function BK:Store()
    if self.testDB then return self.testDB end
    if not A.db or A:Simulated() then return nil end
    return A.db.books
end
function BK:CharKey()
    local Ch = A.Chars
    if Ch and Ch.Key then local ok, k = pcall(Ch.Key, Ch); if ok and k then return k end end
    return "?"
end

-- BP1: Neustart mit Stichtag. Alte Buchungen bleiben unverändert (Statistik), db.ledger.archive merkt den Stichtag.
function BK:Restart(now)
    if not A.db then return nil end
    now = now or Now()
    local led = A.db.ledger
    if type(led) == "table" then
        led.archive = led.archive or {}
        table.insert(led.archive, { since = now, entries = led.entries and #led.entries or 0 })
        while #led.archive > 20 do table.remove(led.archive, 1) end
    end
    A.db.books = NewDB(now)
    self.openPending = true
    A:Fire("LEDGER_CHANGED")
    return A.db.books
end

function BK:Ensure()
    if self.testDB or not A.db then return end
    if type(A.db.books) ~= "table" or not A.db.books.since then self:Restart() end
end

-- ------------------------------------------------------------
-- Kostenbasis
-- ------------------------------------------------------------
local function Pos(db, ch, id)
    db.cb[ch] = db.cb[ch] or {}
    local p = db.cb[ch][id]
    if not p then p = { q = 0, c = 0 }; db.cb[ch][id] = p end
    return p
end
function BK:Position(id, ch)
    local db = self:Data()
    local p = db and db.cb[ch or self:CharKey()]
    p = p and p[id]
    return p and p.q or 0, p and p.c or 0
end
-- AB8 (Befund 11.11. 22:15): Einstandspreise aus den ALTEN Daten (vor dem Stichtag). Ware, die vor dem Neustart gekauft
-- wurde (Taschen, Bank, Post, eigene Auktionen), behält ihren Kaufpreis. Nur gelesen: db.ledger.entries bleibt, wie es ist.
-- Je Item: Käufe der letzten OLD_DAYS Tage vor dem Stichtag (Menge, Kosten); verbraucht wird über db.oldUsed[id].
BK.OLD_DAYS = 30
function BK:OldIndex(db)
    db = db or self:Data()
    if not db then return {} end
    if self.testDB then return self.testOld or {} end
    if self.oldIdx and self.oldIdxSince == db.since then return self.oldIdx end
    local idx = {}
    local led = A.db and A.db.ledger
    local from = db.since - self.OLD_DAYS * 86400
    -- AB8c: deLog wird auf 2000 Einträge gekappt - "out" (vorher entzaubert) ist nur ab dem ältesten Eintrag sicher.
    -- Ist deLog voll, beginnt der Zeitraum dort (Käufe UND Abgänge gleich lang), sonst fehlen Abgänge und zu viel
    -- alter Bestand bliebe. Die alten Buchungen tragen keinen Charakter -> je Item über alle Charaktere (wie bisher).
    local dl = A.db and A.db.deLog
    if dl and #dl >= 2000 and dl[1] and (dl[1].t or 0) > from then from = dl[1].t end
    for _, e in ipairs(led and led.entries or {}) do
        if e.kind == "buy" and e.itemID and (e.t or 0) < db.since and (e.t or 0) >= from and (e.qty or 0) > 0 and (e.amount or 0) > 0 then
            local x = idx[e.itemID] or { q = 0, c = 0, out = 0 }
            x.q, x.c = x.q + e.qty, x.c + e.amount
            idx[e.itemID] = x
        end
    end
    -- schon vor dem Stichtag verkauft oder entzaubert -> nicht mehr da (nur Menge, Preis bleibt der Durchschnitt)
    for _, e in ipairs(led and led.entries or {}) do
        local x = e.kind == "sale" and e.itemID and idx[e.itemID]
        if x and (e.t or 0) < db.since and (e.t or 0) >= from then x.out = x.out + (e.qty or 1) end
    end
    for _, d in ipairs(A.db and A.db.deLog or {}) do
        local x = d.itemID and idx[d.itemID]
        if x and (d.t or 0) < db.since and (d.t or 0) >= from then x.out = x.out + 1 end
    end
    for id, x in pairs(idx) do
        local left = x.q - x.out
        if left <= 0 then idx[id] = nil
        else x.c, x.q = math.floor(x.c / x.q * left + 0.5), left end
    end
    self.oldIdx, self.oldIdxSince = idx, db.since
    return idx
end
-- bis zu n Stück zum alten Einstand: zurück Kosten, Anzahl
function BK:OldFill(db, id, n)
    local x = self:OldIndex(db)[id]
    if not (x and x.q > 0 and n and n > 0) then return 0, 0 end
    db.oldUsed = db.oldUsed or {}
    local avail = x.q - (db.oldUsed[id] or 0)
    local k = math.min(n, avail)
    if k <= 0 then return 0, 0 end
    db.oldUsed[id] = (db.oldUsed[id] or 0) + k
    return math.floor(x.c / x.q * k + 0.5), k
end
function BK:OldUnit(id)
    local x = self:OldIndex()[id]
    return x and x.q > 0 and math.floor(x.c / x.q + 0.5) or nil
end

-- Entnahme zum Durchschnitt; was über die bekannte Menge hinausgeht, kommt zum alten Einstand (AB8, z. B. vor dem
-- Neustart gekauft und erst danach aus der Post geholt) - nur ohne jeden Kauf Kostenbasis 0 ("ohne Einkauf")
local function Take(db, ch, id, qty)
    local p = Pos(db, ch, id)
    local known = math.min(qty, p.q)
    local cost = 0
    if known > 0 then
        cost = math.floor(p.c * known / p.q + 0.5)
        p.q, p.c = p.q - known, p.c - cost
        if p.q <= 0 then p.q, p.c = 0, 0 end
    end
    local rest = qty - known
    if rest > 0 then
        local c2, n2 = BK:OldFill(db, id, rest)
        if n2 > 0 then
            cost, rest = cost + c2, rest - n2
            db.oldFilled = (db.oldFilled or 0) + n2
        end
    end
    return cost, rest
end
-- bt (BE2): Geschäftsart der Kostenbasis - "flip" (Kauf im AH), "de" (aus Entzaubern), "craft" (Herstellen),
-- "vendor" (Händlerware), "open" (Eröffnungsbestand), "xfer" (Post von eigenem Twink: Art bleibt). Gemischt = "mix".
local function Put(db, ch, id, qty, cost, bt)
    local p = Pos(db, ch, id)
    if bt then
        if p.q <= 0 or not p.bt then p.bt = bt elseif p.bt ~= bt then p.bt = "mix" end
    end
    p.q, p.c = p.q + qty, p.c + (cost or 0)
end
local function TypeOf(db, ch, id)
    local p = db.cb[ch] and db.cb[ch][id]
    return p and p.bt or nil
end

local function Log(db, e)
    e.t = e.t or Now()
    table.insert(db.log, e)
    while #db.log > BK.LOG_MAX do table.remove(db.log, 1) end
    return e
end

-- Netto-Wert je Stück zum Stichtag: realistischer Verkaufspreis nach Gebühren, mindestens Händler, Aufkauf (D6) zum
-- Preis vor dem Aufkauf
function BK:OpeningValue(id)
    local Le = A.Ledger
    local v = 0
    if Le and Le.UnitStockValue then
        local ok, x = pcall(Le.UnitStockValue, Le, id)
        if ok and type(x) == "number" then v = x end
    end
    local okB, bo = pcall(A.BuyoutInfo, A, id)
    if okB and bo and bo.p0 then
        local cap = math.floor(bo.p0 * (1 - A:CutPct()))
        if v > cap then v = cap end
    end
    local vendor = A:GetVendorPrice(id)
    if type(vendor) == "number" and vendor > v then v = vendor end
    return math.max(0, math.floor(v + 0.5))
end

-- BP1 Eröffnungsbestand dieses Charakters (einmal je Charakter und Stichtag): Taschen, Bank, eigene Auktionen
function BK:OpenChar(counts)
    local db = self:Store()
    if not db then return 0 end
    local ch = self:CharKey()
    if db.opened[ch] then return 0 end
    if not counts then
        local Le = A.Ledger
        if not (Le and Le.StockCounts) then return 0 end
        local ok, c = pcall(Le.StockCounts, Le)
        if not ok then return 0 end
        counts = c
    end
    local n, total = 0, 0
    for id, q in pairs(counts or {}) do
        if type(id) == "number" and q and q > 0 then
            -- AB8: gekaufte Stücke behalten ihren Kaufpreis (alte Daten); nur Ware ohne Kauf (Beute, Farm) zum Wert am Stichtag
            local cOld, nOld = self:OldFill(db, id, q)
            local v = self:OpeningValue(id)
            local cost = cOld + v * (q - nOld)
            Put(db, ch, id, q, cost, nOld > 0 and "flip" or "open")
            n, total = n + 1, total + cost
        end
    end
    db.opened[ch] = { t = Now(), items = n, value = total }
    Log(db, { k = "open", ch = ch, q = n, cost = total })
    return n, total
end

-- ------------------------------------------------------------
-- Buchungen
-- ------------------------------------------------------------
-- BP2 Kauf: Menge und Kosten dazu (ergebnisneutral)
function BK:OnBuy(id, qty, amount, t)
    local db = self:Store()
    if not (db and id and qty and qty > 0) then return end
    if t and t < db.since then return end
    local ch = self:CharKey()
    Put(db, ch, id, qty, amount or 0, "flip")
    Log(db, { k = "buy", ch = ch, id = id, q = qty, cost = math.floor(amount or 0), t = t })
end

-- BP4 Verkauf sofort "ausstehend" (eigene Auktion als verkauft erkannt bzw. Käufer-Meldung). gross = Sofortkauf gesamt
-- soldKey: Kennung des verkauften Eintrags. VF5: Teilverkäufe einer Waren-Auktion haben dieselbe auctionID - die
-- Kennung ist darum auctionID + Menge + Betrag + laufende Nummer gleicher Einträge (nicht die auctionID allein).
function BK:PendingSale(id, qty, gross, auctionID, t, soldKey)
    local db = self:Store()
    if not (db and id and qty and qty > 0) then return nil end
    t = t or Now()
    local key = soldKey or auctionID
    if key then
        if db.seenSold[key] then return nil end
        db.seenSold[key] = t
    end
    local ch = self:CharKey()
    local bt = TypeOf(db, ch, id)
    local cost, free = Take(db, ch, id, qty)
    local net = math.floor((gross or 0) * (1 - A:CutPct()) + 0.5)
    local e = Log(db, { k = "sale", ch = ch, id = id, q = qty, rev = net, gross = math.floor(gross or 0), cost = cost, free = free,
        st = "p", a = auctionID, t = t, bt = bt, sk = soldKey })
    A:Fire("LEDGER_CHANGED")
    return e
end

-- Rechnung (Verkauf): passende "ausstehend"-Buchung bestätigen (Rechnung gilt), sonst neu buchen. Nie doppelt.
function BK:OnInvoice(id, qty, amount, cut, t)
    local db = self:Store()
    if not (db and id) then return nil end
    t = t or Now()
    if t < db.since - self.MATCH_BEFORE then return nil end
    qty = math.max(1, qty or 1)
    local net = math.floor((amount or 0) - (cut or 0) + 0.5)
    local ch = self:CharKey()
    -- passende ausstehende: gleiches Item, gleiche Menge, Zeitfenster; bei mehreren die mit dem nächsten Erlös
    local best, bestD
    for _, e in ipairs(db.log) do
        if e.k == "sale" and e.st == "p" and e.id == id and e.q == qty and e.ch == ch and t >= (e.t or 0) - self.MATCH_BEFORE and t <= (e.t or 0) + self.MATCH_AFTER then
            local d = math.abs((e.rev or 0) - net)
            if not best or d < bestD then best, bestD = e, d end
        end
    end
    if best then
        if best.rev ~= net and A.Diag then
            pcall(A.Diag.Add, A.Diag, "BUCHHALTUNG", string.format("Rechnung weicht ab: Item %d · %d Stück · ausstehend %d · Rechnung %d (Rechnung gilt)", id, qty, best.rev or 0, net))
        end
        best.rev, best.st, best.ti = net, "c", t
        A:Fire("LEDGER_CHANGED")
        return best, "bestätigt"
    end
    -- BH-AUS (Prüf-Sitzung 14.11. 00:25): Rechnungen kommen in grossen Posten (z. B. 72 Stück), die ausstehenden Buchungen
    -- in kleinen Stapeln -> mehrere ausstehende Buchungen über die MENGE summiert bestätigen (älteste zuerst). Erlös der
    -- Rechnung anteilig nach Stück; ein Rest ohne ausstehende Buchung wird neu gebucht. Nie doppelt.
    local cands = {}
    for _, e in ipairs(db.log) do
        if e.k == "sale" and e.st == "p" and e.id == id and e.ch == ch and (e.q or 0) > 0 and (e.q or 0) <= qty
            and t >= (e.t or 0) - self.MATCH_BEFORE and t <= (e.t or 0) + self.MATCH_AFTER then
            cands[#cands + 1] = e
        end
    end
    table.sort(cands, function(a, b) return (a.t or 0) < (b.t or 0) end)
    local take, sum = {}, 0
    for _, e in ipairs(cands) do
        if sum + e.q <= qty then take[#take + 1] = e; sum = sum + e.q end
        if sum == qty then break end
    end
    if sum > 0 then
        local used = 0
        for i, e in ipairs(take) do
            local share = math.floor(net * e.q / qty + 0.5)
            if i == #take and sum == qty then share = net - used end
            used = used + share
            e.rev, e.st, e.ti = share, "c", t
        end
        if sum < qty then
            local restQ = qty - sum
            local bt = TypeOf(db, ch, id)
            local cost, free = Take(db, ch, id, restQ)
            Log(db, { k = "sale", ch = ch, id = id, q = restQ, rev = net - used, gross = math.floor((amount or 0) * restQ / qty), cost = cost, free = free, st = "c", t = t, ti = t, bt = bt })
        end
        A:Fire("LEDGER_CHANGED")
        return take[1], "bestätigt (summiert)"
    end
    local bt = TypeOf(db, ch, id)
    local cost, free = Take(db, ch, id, qty)
    local e = Log(db, { k = "sale", ch = ch, id = id, q = qty, rev = net, gross = math.floor(amount or 0), cost = cost, free = free, st = "c", t = t, ti = t, bt = bt })
    A:Fire("LEDGER_CHANGED")
    return e, "neu"
end

-- Einstellgebühr (bezahlt) und Erstattung (Verkauf/Abbruch)
function BK:OnFee(amount, t, id)
    local db = self:Store()
    if not db or not amount or amount == 0 then return end
    if t and t < db.since then return end
    Log(db, { k = "fee", ch = self:CharKey(), id = id, fee = math.floor(amount), t = t })
end

-- BP3 Entzaubern: Kostenbasis des Teils -> Materialien nach relativem Verkaufswert im Moment des Entzauberns
function BK:MatValue(id)
    local D = A.Disenchant
    if D and D.MatPrice then
        local ok, p = pcall(D.MatPrice, D, id)
        if ok and type(p) == "number" and p > 0 then return p end
    end
    return A:GetMarketValue(id) or 0
end
function BK:OnDisenchant(itemID, loot, t)
    local db = self:Store()
    if not (db and itemID and type(loot) == "table" and #loot > 0) then return end
    local ch = self:CharKey()
    local cost, free = Take(db, ch, itemID, 1)
    local vals, sum = {}, 0
    for i, l in ipairs(loot) do
        local q = l[2] or 1
        local v = self:MatValue(l[1]) * q
        vals[i] = v
        sum = sum + v
    end
    local given, biggest = 0, 1
    local parts = {}
    for i, l in ipairs(loot) do
        local share = sum > 0 and math.floor(cost * vals[i] / sum + 0.5) or (i == 1 and cost or 0)
        parts[i] = share
        given = given + share
        if vals[i] > vals[biggest] then biggest = i end
    end
    parts[biggest] = parts[biggest] + (cost - given)          -- Rundungsrest: Summe genau
    for i, l in ipairs(loot) do Put(db, ch, l[1], l[2] or 1, parts[i], "de") end
    -- PD1c: Teil ohne bekannte Herkunft -> "ohne Einkauf" gekennzeichnet (nicht still 0)
    Log(db, { k = "de", ch = ch, id = itemID, q = 1, cost = cost, free = (free or 0) > 0 and free or nil, t = t })
end

-- Herstellen: Kostenbasis der Zutaten -> Produkt
function BK:OnCraft(product, qty, reagents, t)
    local db = self:Store()
    if not (db and product) then return end
    local ch = self:CharKey()
    local cost = 0
    for _, r in ipairs(reagents or {}) do cost = cost + Take(db, ch, r[1], r[2] or 1) end
    Put(db, ch, product, qty or 1, cost, "craft")
    Log(db, { k = "craft", ch = ch, id = product, q = qty or 1, cost = cost, t = t })
end

-- BP2 Post an eigenen Twink: Kostenbasis wandert mit (kein Gewinn, kein Verlust)
function BK:OnTwinkMail(toKey, items, t)
    local db = self:Store()
    if not (db and toKey and items) then return end
    local ch = self:CharKey()
    if toKey == ch then return end
    for _, it in ipairs(items) do
        local bt = TypeOf(db, ch, it[1])
        local cost = Take(db, ch, it[1], it[2] or 1)
        Put(db, toKey, it[1], it[2] or 1, cost, bt)
        Log(db, { k = "xfer", ch = ch, to = toKey, id = it[1], q = it[2] or 1, cost = cost, t = t })
    end
end

-- ------------------------------------------------------------
-- Auswertung (BP5)
-- ------------------------------------------------------------
function BK:PeriodStart(key)
    local db = self:Data()
    local since = db and db.since or 0
    local from = since
    local Le = A.Ledger
    if key ~= "all" and Le and Le.PeriodStart then from = math.max(since, Le:PeriodStart(key)) end
    return from, since
end

-- Gewinn, Verkauft (Erlös), Eingesetzt (Kostenbasis), Gebühren, ausstehend, Anzahl; je Item in items
function BK:Summary(key)
    local db = self:Data()
    local s = { profit = 0, rev = 0, cost = 0, fees = 0, pending = 0, pendingN = 0, sales = 0, buys = 0, spent = 0, free = 0, items = {},
        freeRev = 0, byType = {}, byItem = {} }
    if not db then return s end
    local from = self:PeriodStart(key)
    for _, e in ipairs(db.log) do
        if (e.t or 0) >= from then
            if e.k == "sale" and e.st == "p" then
                -- BH-AUS: ausstehend ist KEIN Erlös - getrennt als "unterwegs"; älter als 24 Std. ohne Rechnung gemeldet
                s.pending, s.pendingN = s.pending + (e.rev or 0), s.pendingN + 1
                if Now() - (e.t or 0) > self.PENDING_OLD then s.pendingOld, s.pendingOldRev = (s.pendingOld or 0) + 1, (s.pendingOldRev or 0) + (e.rev or 0) end
            elseif e.k == "sale" and e.st ~= "x" then
                s.rev, s.cost, s.sales = s.rev + (e.rev or 0), s.cost + (e.cost or 0), s.sales + 1
                -- BE3: Anteil ohne Einkauf (Kostenbasis 0): Erlös dieser Stücke ist reiner Gewinn, getrennt ausgewiesen
                local freeRev = 0
                if (e.free or 0) > 0 then
                    s.free = s.free + e.free
                    freeRev = math.floor((e.rev or 0) * e.free / math.max(1, e.q or 1) + 0.5)
                    s.freeRev = s.freeRev + freeRev
                end
                -- BE2: Ergebnis je Geschäftsart (nur Stücke mit Einkauf) und je Item
                local bought = (e.rev or 0) - freeRev - (e.cost or 0)
                if (e.free or 0) < (e.q or 1) then
                    local bt = self.TYPE_LABELS[e.bt or ""] and e.bt or "unknown"
                    s.byType[bt] = (s.byType[bt] or 0) + bought
                    -- EB-DET: eingesetzt und Anzahl je Weg (Rendite = Gewinn / eingesetzt)
                    s.byTypeCost = s.byTypeCost or {}
                    s.byTypeN = s.byTypeN or {}
                    s.byTypeCost[bt] = (s.byTypeCost[bt] or 0) + (e.cost or 0)
                    s.byTypeN[bt] = (s.byTypeN[bt] or 0) + 1
                end
                s.byItem[e.id] = (s.byItem[e.id] or 0) + bought
                local it = s.items[e.id] or { itemID = e.id, sold = 0, rev = 0, cost = 0 }
                it.sold, it.rev, it.cost = it.sold + (e.q or 0), it.rev + (e.rev or 0), it.cost + (e.cost or 0)
                s.items[e.id] = it
            elseif e.k == "fee" then
                s.feesRaw = (s.feesRaw or 0) + (e.fee or 0)       -- BH-ANZ: nur noch Information (Gold-Fluss)
            elseif e.k == "buy" then
                s.buys, s.spent = s.buys + 1, s.spent + (e.cost or 0)
            elseif e.k == "own" then
                s.ownUse, s.ownN = (s.ownUse or 0) + (e.cost or 0), (s.ownN or 0) + (e.q or 0)   -- EB1: Ausgabe Eigenbedarf
            end
        end
    end
    -- BH-ANZ (Regel buchhaltung.md 5d): Anzahlung beim Einstellen = hinterlegt (kein Aufwand), beim Verkauf zurück (kein
    -- Ertrag), nur VERFALLEN ist Aufwand - im Zeitraum des Ablaufs
    local okD, forfeit, held = pcall(self.DepositStatus, self, db, from, Now())
    s.fees = okD and forfeit or 0
    s.depHeld = okD and held or 0
    s.profit = s.rev - s.cost - s.fees
    -- BE1/BE3: Rendite nur mit Ware mit Einkauf: (Gewinn − Gewinn ohne Einkauf) / Eingesetzt
    s.boughtProfit = s.profit - s.freeRev
    s.roi = s.cost > 0 and (s.boughtProfit / s.cost * 100) or nil
    return s
end

-- BH-ANZ: Anzahlungen je Figur+Item der Reihe nach (nur Auswertung, alte Buchungen unverändert).
-- BH-ANZ-1 (Prüf-Sitzung 02:30): hinterlegt bis zu einem ECHTEN Ereignis: Ablauf-Post bzw. Abbruch (Buchung "depx") ->
-- verfallen zu diesem Zeitpunkt. Eine Erstattung (negative Gebühr) löst die älteste hinterlegte Anzahlung auf - ohne
-- Zeitgrenze, auch eine schon als verfallen gebuchte (Forever: Erstattung beim Abbruch). Ohne Ereignis nach DEP_UNKNOWN
-- Tagen: verfallen (Post nie über AHSentinel gelesen).
BK.DEP_UNKNOWN = 7 * 86400
function BK:DepositStatus(db, from, to)
    db = db or self:Data()
    to = to or Now()
    local queues, forfeit, held = {}, 0, 0
    local function Q(e) local key = (e.ch or "?") .. "|" .. tostring(e.id or 0); queues[key] = queues[key] or {}; return queues[key] end
    for _, e in ipairs(db and db.log or {}) do
        if e.k == "fee" and e.fee and e.fee ~= 0 then
            local q = Q(e)
            if e.fee > 0 then q[#q + 1] = { t = e.t or 0, left = e.fee }
            else
                local r = -e.fee
                for pass = 1, 2 do                      -- erst hinterlegte, dann schon verfallene (zurückgekommen)
                    for _, d in ipairs(q) do
                        if r <= 0 then break end
                        if d.left > 0 and (pass == 1) == (not d.lostT) then
                            local take = math.min(d.left, r)
                            d.left, r = d.left - take, r - take
                        end
                    end
                end
            end
        elseif e.k == "depx" then
            for _, d in ipairs(Q(e)) do
                if d.left > 0 and not d.lostT and d.t <= (e.t or 0) then d.lostT = e.t or 0; break end
            end
        end
    end
    for _, q in pairs(queues) do
        for _, d in ipairs(q) do
            if d.left > 0 then
                local lostT = d.lostT or (d.t + self.DEP_UNKNOWN <= to and d.t + self.DEP_UNKNOWN) or nil
                if lostT then
                    if lostT >= (from or 0) and lostT <= to then forfeit = forfeit + d.left end
                else held = held + d.left end
            end
        end
    end
    return forfeit, held
end
-- Ablauf-Post bzw. Abbruch: die älteste hinterlegte Anzahlung dieses Items verfällt jetzt
function BK:OnDepositLost(itemID, why, t)
    local db = self:Store()
    if not (db and itemID) then return end
    t = t or Now()
    if t < db.since then return end
    Log(db, { k = "depx", ch = self:CharKey(), id = itemID, why = why, t = t })
end
-- EB4 Händlerkauf (nur lesen, Nachhaken an BuyMerchantItem): Kaufpreis aus GetMerchantItemInfo, Ware als Einkauf mit
-- Herkunft "vendor" ins Lager (Kostenbasis z. B. für Herstellen). Eigenbedarf erkennt EB1 beim Anlegen.
function BK:MerchantInfo(index)
    if not GetMerchantItemLink then return nil end
    local ok, price, stack
    -- neuere Clients: C_MerchantFrame.GetItemInfo (Tabelle); sonst GetMerchantItemInfo
    local CM = C_MerchantFrame
    if CM and CM.GetItemInfo then
        local okI, info = pcall(CM.GetItemInfo, index)
        if okI and type(info) == "table" then ok, price, stack = true, info.price, info.stackCount end
    end
    if not ok and GetMerchantItemInfo then ok, _, _, price, stack = pcall(GetMerchantItemInfo, index) end
    local okL, link = pcall(GetMerchantItemLink, index)
    local id = okL and link and tonumber(tostring(link):match("item:(%d+)"))
    if not (ok and id and type(price) == "number") then return nil end
    return id, price, math.max(1, tonumber(stack) or 1)
end
function BK:OnMerchantBuy(index, qty)
    if A.TestRoutine and A.TestRoutine.running and not self.testDB then return end
    local id, price, stack = self:MerchantInfo(index)
    if not (id and price and price > 0) then return end
    qty = math.max(1, tonumber(qty) or stack)
    local cost = math.floor(price * qty / stack + 0.5)       -- Preis gilt je Stapel
    local db = self:Store()
    if not db then return end
    local ch = self:CharKey()
    Put(db, ch, id, qty, cost, "vendor")
    Log(db, { k = "buy", ch = ch, id = id, q = qty, cost = cost, src = "vendor" })
    return id, qty, cost
end
-- EB4-1 (Prüf-Sitzung 05:10): Händlerware wird verbraucht (Essen, Wasser, Munition, Reagenzien) -> Lager mit dem
-- wirklichen Bestand abgleichen: was bei Händlerware fehlt (Taschen+Bank+eigene Auktionen), ist Eigenbedarf "verbraucht".
-- Nur Lagerposten mit Herkunft "vendor" (andere Ware meldet der Lager-Abgleich nur, BH-AUS-3 b).
function BK:CheckVendorUse()
    local db = self:Store()
    if not db then return 0 end
    -- EB4-2: kurz nach dem Herstellen bzw. mit offenem Briefkasten nicht abgleichen (Buchung/Versand kommt noch)
    if (self.lastCraftT and Now() - self.lastCraftT < 60) or (A.Activity and A.Activity.mailOpen) or self.pendingMail then return 0 end
    local ch = self:CharKey()
    local n = 0
    for id, p in pairs(db.cb[ch] or {}) do
        if type(p) == "table" and p.bt == "vendor" and (p.q or 0) > 0 then
            local gone = p.q - self:HaveCount(id)
            if gone > 0 then
                local cost = Take(db, ch, id, gone)
                Log(db, { k = "own", ch = ch, id = id, q = gone, cost = cost, why = "verbraucht" })
                n = n + gone
            end
        end
    end
    if n > 0 then A:Fire("LEDGER_CHANGED") end
    return n
end
if hooksecurefunc and BuyMerchantItem then
    pcall(hooksecurefunc, "BuyMerchantItem", function(index, qty) pcall(BK.OnMerchantBuy, BK, index, qty) end)
end

-- EB-NAME: die Anzahlung mit dem Wort des Spiels (Blizzard DEPOSIT, ohne Doppelpunkt)
function BK:DepositWord()
    local w = type(DEPOSIT) == "string" and DEPOSIT or nil
    if w then w = w:gsub("[:：]%s*$", ""):gsub("%s+$", "") end
    return (w and w ~= "") and w or L["Anzahlung"]
end

-- EB7/EB-DET: Zahlen für das Fenster "Buchhaltung – Details" (nur gebuchte Daten, nichts geschätzt)
BK.DETAIL_MIN_HOURS, BK.DETAIL_MIN_N = 2, 5
function BK:Details(key)
    key = key or "all"
    local s = self:Summary(key)
    local d = { key = key, profit = s.profit, own = s.ownUse or 0, ownN = s.ownN or 0, lost = s.fees or 0, held = s.depHeld or 0, ways = {} }
    -- Handel pro Stunde: Gewinn / Online-Spielzeit im Zeitraum (ohne AFK); unter 2 Std. "lernt noch"
    local from = self:PeriodStart(key)
    local Act = A.Activity
    local okS, sec = pcall(function() return Act and Act:Seconds(from).online or 0 end)
    d.onlineH = (okS and sec or 0) / 3600
    if d.onlineH >= self.DETAIL_MIN_HOURS then d.perHour = math.floor(s.profit / d.onlineH + 0.5) end
    -- Rendite je Weg (Entzaubern als SUMME über alle Fälle)
    for _, w in ipairs({ "de", "flip", "vendor", "craft" }) do
        local n, cost, gain = (s.byTypeN or {})[w] or 0, (s.byTypeCost or {})[w] or 0, (s.byType or {})[w] or 0
        d.ways[#d.ways + 1] = { way = w, n = n, cost = cost, gain = gain, pct = (n >= self.DETAIL_MIN_N and cost > 0) and gain / cost * 100 or nil }
    end
    -- Verkaufsquote: verkaufte / eingestellte Stück (Abbrüche und Abläufe = nicht verkauft), aus dem Prognose-Journal
    -- EB-DET-1: je Verkaufskette (Abbruch -> neu eingestellt -> verkauft zählt einmal; nur Ablauf ohne Neu-Einstellung = nicht verkauft)
    local Fc = A.Forecast
    local sold, posted = 0, 0
    if Fc and Fc.ChainSellRate then
        local okC, a, b = pcall(Fc.ChainSellRate, Fc, from)
        if okC then sold, posted = a or 0, b or 0 end
    end
    d.posted, d.sold = posted, sold
    d.sellRate = posted >= self.DETAIL_MIN_N and sold / posted or nil
    -- Gold-Abstimmung (alle Figuren, nur Zeitraum mit Gold-Ständen)
    local okR, change, explained, diff, nCh = pcall(self.ReconcileAll, self)
    if okR and change then d.gold = { change = change, explained = explained, diff = diff, chars = nCh, ok = math.abs(diff) <= math.max(100, math.abs(change) * 0.01) } end
    return d
end

-- EB1 Eigenbedarf (Nutzer 13.11. 21:05: Taschen für die eigenen Figuren): gekaufte Ware, die angelegt bzw. als Tasche
-- eingesetzt ist, ist keine Handelsware. Lager -> Buchung "own" (Ausgabe Eigenbedarf, nicht im Handelsgewinn, nicht im
-- Lager). Je Figur und Item nur so viele, wie neu angelegt sind (db.ownEq merkt die schon gebuchten).
function BK:EquippedCount(id)
    if not GetInventoryItemID then return 0 end
    local n = 0
    for slot = 1, 23 do
        local ok, iid = pcall(GetInventoryItemID, "player", slot)
        if ok and iid == id then n = n + 1 end
    end
    return n
end
function BK:CheckOwnUse()
    local db = self:Store()
    if not db then return 0 end
    local ch = self:CharKey()
    local pos = db.cb[ch]
    if not pos then return 0 end
    db.ownEq = db.ownEq or {}
    db.ownEq[ch] = db.ownEq[ch] or {}
    local done, n = db.ownEq[ch], 0
    for id, p in pairs(pos) do
        if type(p) == "table" and (p.q or 0) > 0 then
            local eq = self:EquippedCount(id)
            local new = math.min(p.q, eq - (done[id] or 0))
            if new > 0 then
                local cost = Take(db, ch, id, new)
                Log(db, { k = "own", ch = ch, id = id, q = new, cost = cost, why = "angelegt" })
                done[id] = (done[id] or 0) + new
                n = n + new
            end
            if eq < (done[id] or 0) then done[id] = eq end              -- abgelegt: wieder frei für neue Buchungen
        end
    end
    if n > 0 then A:Fire("LEDGER_CHANGED") end
    return n
end

-- BE2: Geschäftsarten (Herkunft der Kostenbasis); "unknown" = keine sichere Zuordnung (gemischt, Altbestand)
BK.TYPE_LABELS = { de = "Entzaubern", flip = "Flippen", craft = "Herstellen", vendor = "Händlerware", unknown = "unbekannt" }
function BK:WorstLoss(s)
    local bt, btV, item, itemV
    for k, v in pairs(s.byType or {}) do if v < 0 and (not btV or v < btV) then bt, btV = k, v end end
    for k, v in pairs(s.byItem or {}) do if v < 0 and (not itemV or v < itemV) then item, itemV = k, v end end
    return bt, btV, item, itemV
end
function BK:LossLines(s)
    local bt, btV, item, itemV = self:WorstLoss(s)
    if not bt and not item then return { L["Kein Verlust-Geschäft"] } end
    local out = {}
    if bt then out[#out + 1] = string.format(L["Verlust bei %s: %s"], L[self.TYPE_LABELS[bt]], A:FormatMoney(btV)) end
    if item then out[#out + 1] = string.format(L["Grösster Verlust: %s %s"], A:GetItemName(item) or ("#" .. item), A:FormatMoney(itemV)) end
    return out
end
-- BH1307: Kopf der Buchhaltung. Ist mehr als 30 % des Erlöses ohne Einkauf (Kostenbasis fehlt), gilt als Gewinn nur
-- "Gewinn mit Einkauf" (gross); der Rest steht klein und gelb daneben: "dazu ohne Einkauf … – Kostenbasis prüfen".
-- Rückgabe: Hauptzahl, Rendite-Text, Zusatz (nil oder Text)
BK.FREE_HEAD_SHARE = 0.30
function BK:HeadParts(s)
    local share = (s.rev or 0) > 0 and (s.freeRev or 0) / s.rev or 0
    if share > self.FREE_HEAD_SHARE then
        return s.boughtProfit or (s.profit - (s.freeRev or 0)), self:RoiText(s),
            string.format(L["dazu ohne Einkauf %s – Kostenbasis prüfen"], A:FormatMoney(s.freeRev or 0)), true
    end
    return s.profit, self:RoiText(s), nil, false
end
-- BH1307 (1): verkaufte Stücke ohne Einstand je Item mit vermuteter Herkunft (nur IDs und Zahlen, fürs Protokoll/Testbericht)
function BK:FreeOrigins(key)
    local db = self:Data()
    if not db then return {} end
    local from = self:PeriodStart(key)
    local per = {}
    for _, e in ipairs(db.log) do
        if e.k == "sale" and e.st ~= "x" and e.st ~= "p" and (e.t or 0) >= from and (e.free or 0) > 0 then
            local p = per[e.id] or { id = e.id, q = 0, rev = 0 }
            p.q = p.q + e.free
            p.rev = p.rev + math.floor((e.rev or 0) * e.free / math.max(1, e.q or 1) + 0.5)
            per[e.id] = p
        end
    end
    local D = A.Disenchant
    local out = {}
    for id, p in pairs(per) do
        local isMat = D and D.IsMaterial and D:IsMaterial(id)
        local fromDE = false
        if isMat then
            for _, d in ipairs(A.db and A.db.deLog or {}) do
                if d.loot then for _, m in ipairs(d.loot) do if m[1] == id then fromDE = true; break end end end
                if fromDE then break end
            end
        end
        p.origin = fromDE and "Entzauberung (Teil vor dem Stichtag gekauft oder ohne Kaufbuchung)"
            or (isMat and "Material ohne Entzauber-Eintrag (Beute, Post von einem Twink oder vor dem Stichtag)")
            or ((db.since and db.since > 0) and "vor dem Stichtag oder Beute/Post" or "unbekannt")
        out[#out + 1] = p
    end
    table.sort(out, function(a, b) return a.rev > b.rev end)
    return out
end
function BK:RoiText(s)
    if not s.roi then return L["Rendite –"] end
    return string.format(L["Rendite %d %%"], math.floor(s.roi + 0.5))
end

-- Liste "Pro Item": Verkauft, Erlös, Eingesetzt, Gewinn, Gewinn %
function BK:ByItem(key)
    local s = self:Summary(key)
    local out = {}
    for id, it in pairs(s.items) do
        local profit = it.rev - it.cost
        out[#out + 1] = { itemID = id, name = A:GetItemName(id), sold = it.sold, rev = it.rev, cost = it.cost, profit = profit,
            pct = it.cost > 0 and (s.byItem[id] or profit) / it.cost * 100 or nil }    -- AB6: % nur aus Stücken mit Einkauf
    end
    table.sort(out, function(a, b) return a.profit > b.profit end)
    return out
end

-- Lager dieses Charakters zum Einstandspreis und zum Marktwert (unrealisiert, mit Aufkauf-Schutz über D6)
function BK:StockValues()
    local db = self:Data()
    local ch = self:CharKey()
    local cost, market, n = 0, 0, 0
    local top = {}
    for id, p in pairs(db and db.cb[ch] or {}) do
        if p.q > 0 then
            cost = cost + p.c
            local u = self:OpeningValue(id)
            market = market + u * p.q
            n = n + 1
            top[#top + 1] = { id, u, p.q, u * p.q, p.c }
        end
    end
    -- TS111.3: die grössten Posten (Item, Stückwert, Menge, Wert, Einstand) fürs Protokoll/Testbericht
    table.sort(top, function(a, b) return a[4] > b[4] end)
    self.stockTop = top
    return cost, market, n
end
function BK:StockTopText(max)
    local parts = {}
    for i, t in ipairs(self.stockTop or {}) do
        if i > (max or 5) then break end
        parts[#parts + 1] = string.format("Item %d %d×%d=%d (Einstand %d)", t[1], t[3], t[2], t[4], t[5])
    end
    return table.concat(parts, " | ")
end

-- BP6 Gold: je Charakter beim Login, Logout und beim Öffnen der Buchhaltung
function BK:RecordGold(money, t)
    -- TB125-6: während der Testroutine nie echte Gold-Stände schreiben (nur in der Ersatztabelle)
    if A.TestRoutine and A.TestRoutine.running and not self.testDB then return end
    local db = self:Store()
    if not db then return end
    money = money or (GetMoney and GetMoney()) or nil
    if not money then return end
    t = t or Now()
    local ch = self:CharKey()
    local g = db.gold[ch]
    local day = A:DayStart(t)
    if not g then g = { start = money, startT = t, day = day, dayStart = money }; db.gold[ch] = g end
    if g.day ~= day then g.day, g.dayStart = day, money end
    g.last, g.lastT = money, t
end

-- Abstimmung: Gold seit Stichtag (bzw. Tagesbeginn) gegen das, was die Buchhaltung an Geld erklärt.
-- Erklärt = bestätigte Verkäufe (Rechnung, Geld in der Post) + Erstattungen − Käufe − Einstellgebühren
function BK:Reconcile(key, money)
    local db = self:Data()
    if not db then return nil end
    local ch = self:CharKey()
    local g = db.gold[ch]
    if not g then return nil end
    money = money or (GetMoney and GetMoney()) or g.last or 0
    local today = key == "today"
    local base = today and (g.dayStart or g.start) or g.start
    -- TB125-7: "seit Stichtag" nur über den Zeitraum, für den es Gold-Stände gibt (erster Stand dieser Figur)
    local from = today and A:DayStart(Now()) or math.max(db.since, g.startT or db.since)
    -- AB7: gleicher Zeitraum wie die Buchhaltung - Start = später von (Tagesbeginn, Neustart); Gold beim Neustart gemerkt
    if today and db.since > from and g.start then base, from = g.start, db.since end
    local explained, pending, turnover = 0, 0, 0
    for _, e in ipairs(db.log) do
        if e.ch == ch and (e.t or 0) >= from then
            if e.k == "sale" and e.st == "c" then explained = explained + (e.rev or 0); turnover = turnover + (e.rev or 0)
            elseif e.k == "sale" and e.st == "p" then pending = pending + (e.rev or 0); turnover = turnover + (e.rev or 0)
            elseif e.k == "buy" then explained = explained - (e.cost or 0); turnover = turnover + (e.cost or 0)
            elseif e.k == "fee" then explained = explained - (e.fee or 0) end
        end
    end
    local change = money - base
    local diff = change - explained
    self.lastRecon = { pending = pending, turnover = turnover, from = from,
        show = math.abs(diff) > math.max(100, turnover * 0.01) }      -- AB7: "nicht gebucht" erst ab 1 % des Umsatzes
    if math.abs(diff) >= self.DIFF_WARN and A.Diag and not self.testDB and db.diffDay ~= A:DayStart(Now()) then
        db.diffDay = A:DayStart(Now())
        pcall(A.Diag.Add, A.Diag, "BUCHHALTUNG-DIFFERENZ", string.format("Gold %+d · Buchhaltung %+d · nicht gebucht %+d (%s)", change, explained, diff,
            today and "heute" or "seit Stichtag"))
    end
    return change, explained, diff
end

-- TB125-7: Abstimmung über ALLE Figuren mit mindestens 2 Gold-Ständen, je Figur ab ihrem ersten Stand bis zum letzten.
-- Zurück: change, explained, diff, Figuren, frühester Beginn - oder nil ("lernt noch")
function BK:ReconcileAll()
    local db = self:Data()
    if not db then return nil end
    local change, explained, chars, from0, pending = 0, 0, 0, nil, 0
    for ch, g in pairs(db.gold or {}) do
        if type(g) == "table" and g.start and g.last and g.startT and g.lastT and g.lastT > g.startT then
            local from = math.max(db.since or 0, g.startT)
            chars = chars + 1
            change = change + (g.last - g.start)
            from0 = from0 and math.min(from0, from) or from
            for _, e in ipairs(db.log or {}) do
                if e.ch == ch and (e.t or 0) >= from and (e.t or 0) <= g.lastT then
                    if e.k == "sale" and e.st == "c" then explained = explained + (e.rev or 0)
                    elseif e.k == "sale" and e.st == "p" then pending = pending + (e.rev or 0)
                    elseif e.k == "buy" then explained = explained - (e.cost or 0)
                    elseif e.k == "fee" then explained = explained - (e.fee or 0) end
                end
            end
        end
    end
    if chars == 0 then return nil end
    return change, explained, change - explained, chars, from0, pending
end

-- Messauftrag B1: Zeit zwischen "ausstehend" und Rechnung (Median, Anzahl)
function BK:InvoiceDelay()
    local db = self:Data()
    local d = {}
    for _, e in ipairs(db and db.log or {}) do
        if e.k == "sale" and e.st == "c" and e.ti and e.a then d[#d + 1] = e.ti - (e.t or e.ti) end
    end
    if #d == 0 then return nil, 0 end
    table.sort(d)
    return d[math.floor((#d + 1) / 2)], #d
end

-- L1b: einmalige Reparatur nach dem Update auf 0.65.93 - eine alte "ausstehend"-Buchung (ohne neue Kennung) und eine
-- neue mit Kennung "...#1" für denselben Verkauf (gleiche auctionID, Item, Menge, Erlös): die neue ist doppelt -> weg,
-- ihre Kostenbasis zurück. Zurück: Anzahl
function BK:RepairDoubles(db)
    db = db or self:Store()
    if not db then return 0 end
    local old = {}
    for _, e in ipairs(db.log) do
        if e.k == "sale" and e.a and not e.sk then
            old[table.concat({ tostring(e.a), tostring(e.id), tostring(e.q), tostring(e.rev) }, ":")] = true
        end
    end
    local n = 0
    for i = #db.log, 1, -1 do
        local e = db.log[i]
        if e.k == "sale" and e.st == "p" and e.sk and e.sk:match("#1$")
            and old[table.concat({ tostring(e.a), tostring(e.id), tostring(e.q), tostring(e.rev) }, ":")] then
            table.remove(db.log, i)
            local known = (e.q or 1) - (e.free or 0)
            if known > 0 then Put(db, e.ch, e.id, known, e.cost or 0) end
            n = n + 1
        end
    end
    if n > 0 and A.Diag and not self.testDB then pcall(A.Diag.Add, A.Diag, "BUCHHALTUNG", string.format("doppelte ausstehend-Buchungen repariert: %d", n)) end
    return n
end

-- L1b: Doppel unabhängig von der Kennung sk finden (die echten Doppel aus 0.65.93/0.65.94 haben BEIDE kein sk).
-- Verkaufsbuchungen mit auctionID je (a, id, q, Erlös) gruppieren; erlaubt sind so viele, wie seenSold Kennungen
-- "a:q:Betrag#n" für diese Auktion und Menge hat (mindestens 1). Jede weitere - die spätere, zuerst "ausstehend" -
-- wird entfernt und ihre Kostenbasis zurückgegeben. Zurück: Anzahl entfernt
function BK:RepairDoubles2(db)
    db = db or self:Store()
    if not db then return 0 end
    -- L1c: nur "ausstehend" (st = "p") ohne sk, zeitlich nah an einer gleichen Buchung (<= 6 Std.); abgeschlossene nie.
    -- Waren-Auktionen werden oft mehrmals mit gleicher Menge und gleichem Erlös teilweise verkauft - das sind echte Verkäufe.
    local groups, order = {}, {}
    for i, e in ipairs(db.log) do
        if e.k == "sale" and e.a and not e.sk then
            local g = table.concat({ tostring(e.a), tostring(e.id), tostring(e.q), tostring(e.rev) }, ":")
            if not groups[g] then groups[g] = {}; order[#order + 1] = g end
            table.insert(groups[g], i)
        end
    end
    local drop, notes = {}, {}
    for _, g in ipairs(order) do
        local list = groups[g]
        if #list > 1 then
            local e1 = db.log[list[1]]
            local prefix = tostring(e1.a) .. ":" .. tostring(e1.q) .. ":"
            local allowed = 0
            for k in pairs(db.seenSold or {}) do
                if type(k) == "string" and k:sub(1, #prefix) == prefix and k:find("#", 1, true) then allowed = allowed + 1 end
            end
            allowed = math.max(1, allowed)
            local extra, removed = #list - allowed, 0
            for j = #list, 2, -1 do
                if extra <= 0 then break end
                local e, prev = db.log[list[j]], db.log[list[j - 1]]
                if e.st == "p" and math.abs((e.t or 0) - (prev.t or 0)) <= 6 * 3600 then
                    drop[list[j]] = true; extra = extra - 1; removed = removed + 1
                end
            end
            if removed > 0 then notes[#notes + 1] = string.format("Auktion %s · Menge %s · %d entfernt", tostring(e1.a), tostring(e1.q), removed) end
        end
    end
    local n = 0
    db.removedL1b = db.removedL1b or {}
    for i = #db.log, 1, -1 do
        if drop[i] then
            local e = table.remove(db.log, i)
            db.removedL1b[#db.removedL1b + 1] = e                -- gesichert, nicht gelöscht
            local known = (e.q or 1) - (e.free or 0)
            if known > 0 then Put(db, e.ch, e.id, known, e.cost or 0, e.bt) end
            n = n + 1
        end
    end
    self:RepairNote(db, "L1c", n, table.concat(notes, "; "))
    if n > 0 and A.Diag and not self.testDB then
        pcall(A.Diag.Add, A.Diag, "BUCHHALTUNG", string.format("L1c doppelte ausstehend-Buchungen entfernt: %d (gesichert in removedL1b) %s", n, table.concat(notes, "; ")))
    end
    if n > 0 then A:Fire("LEDGER_CHANGED") end
    return n
end

-- TR: Reparaturen dauerhaft festhalten (Datum, Version, Anzahl, Einzelheiten) - der Testbericht gibt sie aus
-- BH-AUS (2): einmalige Reparatur. Rechnungen, die früher als NEUER Verkauf gebucht wurden, obwohl kleine ausstehende
-- Buchungen dazu offen waren (Menge passte nicht 1:1): je Rechnung die älteren ausstehenden Buchungen desselben Items
-- über die Menge summiert als "durch Rechnung ersetzt" (st = "x") markieren - NICHT löschen - und deren zweifach
-- entnommenen Lagerbestand zurückbuchen. Alte Werte gesichert in db.repairBHAUS.
function BK:RepairPendingAUS(db)
    db = db or self:Data()
    if not db or not db.log then return 0 end
    local byKey = {}
    for _, e in ipairs(db.log) do
        if e.k == "sale" and e.id and e.ch then
            local k = e.ch .. "|" .. e.id
            local g = byKey[k] or { p = {}, n = {} }
            byKey[k] = g
            if e.st == "p" then g.p[#g.p + 1] = e
            elseif e.st == "c" and not e.a and not e.sk then g.n[#g.n + 1] = e end          -- als neu gebuchte Rechnung
        end
    end
    -- Gewinn alt (bisherige Rechnung: jede Verkaufsbuchung, auch ausstehende, zählte) für den Bericht
    local before = 0
    for _, e in ipairs(db.log) do
        if (e.t or 0) >= (db.since or 0) then
            if e.k == "sale" then before = before + (e.rev or 0) - (e.cost or 0) elseif e.k == "fee" then before = before - (e.fee or 0) end
        end
    end
    local backup, n, qtyN = {}, 0, 0
    for _, g in pairs(byKey) do
        table.sort(g.p, function(a, b) return (a.t or 0) < (b.t or 0) end)
        table.sort(g.n, function(a, b) return (a.t or 0) < (b.t or 0) end)
        for _, inv in ipairs(g.n) do
            local left = inv.q or 0
            for _, p in ipairs(g.p) do
                if left <= 0 then break end
                if p.st == "p" and (p.q or 0) <= left and (inv.t or 0) >= (p.t or 0) - self.MATCH_BEFORE and (inv.t or 0) <= (p.t or 0) + self.MATCH_AFTER then
                    backup[#backup + 1] = { t = p.t, id = p.id, q = p.q, rev = p.rev, cost = p.cost, free = p.free, st = p.st, by = inv.t,
                        icost = inv.cost, ifree = inv.free }
                    p.st, p.xby = "x", inv.t
                    -- BH-AUS-2: Einstand der ausstehenden Buchung auf die Rechnung UMBUCHEN (die Ware ist verkauft)
                    self:MoveCostToInvoice(db, p, inv)
                    left = left - p.q
                    n, qtyN = n + 1, qtyN + p.q
                end
            end
        end
    end
    if n > 0 then
        db.repairBHAUS = db.repairBHAUS or {}
        for _, b in ipairs(backup) do db.repairBHAUS[#db.repairBHAUS + 1] = b end
        self:RepairNote(db, "BH-AUS ausstehend durch Rechnung ersetzt", n, string.format("%d Stück", qtyN))
        if A.Diag and not self.testDB then pcall(A.Diag.Add, A.Diag, "BUCHHALTUNG", string.format("BH-AUS: %d ausstehende Buchungen (%d Stück) durch Rechnungen ersetzt (gesichert)", n, qtyN)) end
        A:Fire("LEDGER_CHANGED")
    end
    if n == 0 and db.repairBHAUSInfo then return n, qtyN end           -- zweiter Lauf: Bericht des ersten behalten
    local okS, sm = pcall(self.Summary, self, "all")
    local okV, stock = pcall(self.StockValues, self)
    db.repairBHAUSInfo = { t = Now(), v = tostring(A.version or "?"), n = n, q = qtyN, before = before,
        after = okS and sm and sm.profit or nil, pendingN = okS and sm and sm.pendingN or nil, stock = okV and stock or nil }
    return n, qtyN
end

-- BH-AUS-2 (Prüf-Sitzung 14.11. 01:05): Die Rechnung wurde als neuer Verkauf gebucht und hatte meist keinen Einstand
-- (free), weil die ausstehende Buchung die Ware schon aus dem Lager genommen hatte. Darum: Einstand der ausstehenden
-- Buchung auf die Rechnung umbuchen (free der Rechnung sinkt, cost steigt). Nur wenn die Rechnung selbst Ware mit
-- Einstand aus dem Lager genommen hat (also doppelt entnommen), geht dieser Rest ins Lager zurück.
function BK:MoveCostToInvoice(db, p, inv)
    local known = (p.q or 0) - (p.free or 0)
    if known <= 0 then p.xfix = 1; return 0, 0 end
    local move = math.min(known, inv.free or 0)
    local costMove = math.floor((p.cost or 0) * move / known + 0.5)
    if move > 0 then
        inv.cost = (inv.cost or 0) + costMove
        inv.free = (inv.free or 0) - move
        if inv.free <= 0 then inv.free = nil end
    end
    local rest = known - move
    -- BH-AUS-3 (Nutzer 01:06: die Ware ist nicht da): auch der Rest ist verkauft -> Einstand auf die Rechnung, nie ins Lager
    if rest > 0 then inv.cost = (inv.cost or 0) + ((p.cost or 0) - costMove) end
    p.xfix, p.xfix3 = 1, 1
    return move, rest
end
-- BH-AUS-3: Folge-Reparatur für 0.65.125 (lief schon): der Rest ging dort ins Lager (Phantom-Ware). Aus den Sicherungen
-- (inv.free vor der Umbuchung) den Rest neu rechnen, aus dem Lager nehmen und auf die Rechnung buchen. Sicherung bleibt.
function BK:RepairPendingAUS3(db)
    db = db or self:Data()
    if not db or not db.log then return 0 end
    local s0 = self:Summary("all")
    local n, stockBack, costMoved = 0, 0, 0
    local function find(pred) for _, e in ipairs(db.log) do if pred(e) then return e end end end
    local lists = {}
    for _, b in ipairs(db.repairBHAUS or {}) do if b.ifree ~= nil or b.icost ~= nil then lists[#lists + 1] = b end end
    for _, b in ipairs(db.repairBHAUS2 or {}) do lists[#lists + 1] = b end
    db.repairBHAUS3 = db.repairBHAUS3 or {}
    for _, b in ipairs(lists) do
        local p = find(function(e) return e.k == "sale" and e.st == "x" and e.id == b.id and e.t == b.t and (e.xby or 0) == (b.by or 0) end)
        if p and p.xfix and not p.xfix3 then
            local known = (p.q or 0) - (p.free or 0)
            local move = math.min(known, b.ifree or 0)
            local rest = known - move
            p.xfix3 = 1
            if rest > 0 then
                local inv = find(function(e) return e.k == "sale" and e.st == "c" and e.id == p.id and e.ch == p.ch and (e.t or 0) == (p.xby or -1) end)
                if inv then
                    local costMove = known > 0 and math.floor((p.cost or 0) * move / known + 0.5) or 0
                    local restCost = (p.cost or 0) - costMove
                    local pos = Pos(db, p.ch, p.id)
                    local back = math.min(rest, pos.q)
                    local backC = rest > 0 and math.floor(restCost * back / rest + 0.5) or 0
                    pos.q, pos.c = pos.q - back, math.max(0, pos.c - backC)
                    db.repairBHAUS3[#db.repairBHAUS3 + 1] = { t = p.t, id = p.id, rest = rest, cost = restCost, back = back, icost = inv.cost }
                    inv.cost = (inv.cost or 0) + restCost
                    n, stockBack, costMoved = n + 1, stockBack + back, costMoved + restCost
                end
            end
        end
    end
    local s1 = self:Summary("all")
    db.repairBHAUS3Info = { t = Now(), v = tostring(A.version or "?"), n = n, stockBack = stockBack, cost = costMoved, profit0 = s0.profit, profit1 = s1.profit }
    if n > 0 then
        self:RepairNote(db, "BH-AUS-3 Phantom-Ware auf Rechnung umgebucht", n, string.format("%d Stück aus dem Lager, Einstand %d", stockBack, costMoved))
        if A.Diag and not self.testDB then pcall(A.Diag.Add, A.Diag, "BUCHHALTUNG", string.format("BH-AUS-3: %d Buchungen, Lager -%d Stück, Einstand %d auf Rechnungen, Gewinn %d -> %d", n, stockBack, costMoved, s0.profit, s1.profit)) end
        A:Fire("LEDGER_CHANGED")
    end
    return n, stockBack, costMoved
end

-- BH-AUS-3 (b): Lager-Abgleich mit der Wirklichkeit (diese Figur): Lager-Stücke gegen Taschen+Bank (GetItemCount) und
-- eigene Auktionen. Nur melden, nie still korrigieren. Zurück: Liste { id, q (Lager), have, extra }
function BK:HaveCount(id)
    local n = 0
    if GetItemCount then local ok, c = pcall(GetItemCount, id, true); if ok and type(c) == "number" then n = c end end
    local Se = A.Seller
    for _, o in ipairs(Se and Se.owned or {}) do if o.itemID == id and not o.sold then n = n + (o.qty or 0) end end
    return n
end
function BK:StockCheck()
    local db = self:Data()
    local out = {}
    local pos = db and db.cb and db.cb[self:CharKey()]
    for id, p in pairs(pos or {}) do
        if type(p) == "table" and (p.q or 0) > 0 then
            local have = self:HaveCount(id)
            if p.q > have then out[#out + 1] = { id = id, q = p.q, have = have, extra = p.q - have } end
        end
    end
    table.sort(out, function(a, b) return a.extra > b.extra end)
    return out
end
-- Folge-Reparatur für 0.65.124 (lief schon): dort ging der ganze Einstand ins Lager. Lager-Zugang zurücknehmen und
-- richtig umbuchen. Erkennbar: st "x" ohne xfix. Sicherung in db.repairBHAUS2.
function BK:RepairPendingAUS2(db)
    db = db or self:Data()
    if not db or not db.log then return 0 end
    local inv = {}
    for _, e in ipairs(db.log) do
        if e.k == "sale" and e.st == "c" and not e.a and not e.sk and e.ch and e.id then inv[e.ch .. "|" .. e.id .. "|" .. (e.t or 0)] = e end
    end
    local n, stockBack, moved = 0, 0, 0
    local s0 = self:Summary("all")
    local cost0 = self:StockValues()
    db.repairBHAUS2 = db.repairBHAUS2 or {}
    for _, p in ipairs(db.log) do
        if p.k == "sale" and p.st == "x" and not p.xfix and p.ch and p.id then
            local iv = inv[p.ch .. "|" .. p.id .. "|" .. (p.xby or 0)]
            local known = (p.q or 0) - (p.free or 0)
            if iv and known > 0 then
                db.repairBHAUS2[#db.repairBHAUS2 + 1] = { t = p.t, id = p.id, q = p.q, cost = p.cost, by = p.xby, icost = iv.cost, ifree = iv.free }
                -- 0.65.124 hatte known Stück mit p.cost ins Lager gelegt -> zurücknehmen (nie unter 0)
                local pos = Pos(db, p.ch, p.id)
                local back = math.min(known, pos.q)
                local backC = known > 0 and math.floor((p.cost or 0) * back / known + 0.5) or 0
                pos.q, pos.c = pos.q - back, math.max(0, pos.c - backC)
                stockBack = stockBack + back
                local mv = self:MoveCostToInvoice(db, p, iv)
                moved, n = moved + mv, n + 1
            else
                p.xfix = 1
            end
        end
    end
    if n > 0 then
        local s1 = self:Summary("all")
        local cost1 = self:StockValues()
        db.repairBHAUS2Info = { t = Now(), v = tostring(A.version or "?"), n = n, stockBack = stockBack, moved = moved,
            profit0 = s0.profit, profit1 = s1.profit, stock0 = cost0, stock1 = cost1 }
        self:RepairNote(db, "BH-AUS-2 Einstand auf Rechnung umgebucht", n, string.format("%d Stück aus dem Lager zurück, %d Stück umgebucht", stockBack, moved))
        if A.Diag and not self.testDB then pcall(A.Diag.Add, A.Diag, "BUCHHALTUNG", string.format("BH-AUS-2: %d Buchungen, Lager -%d Stück, Einstand umgebucht %d Stück, Gewinn %d -> %d", n, stockBack, moved, s0.profit, s1.profit)) end
        A:Fire("LEDGER_CHANGED")
    end
    return n, stockBack, moved
end

function BK:RepairNote(db, what, n, info)
    if not db then return end
    db.repairLog = db.repairLog or {}
    db.repairLog[#db.repairLog + 1] = { t = time(), v = tostring(A.version or "?"), what = what, n = n or 0, info = info ~= "" and info or nil }
    while #db.repairLog > 50 do table.remove(db.repairLog, 1) end
end

-- AB8: einmalige Korrektur eines Neustarts, der die Kostenbasis verloren hat. Entzauberungen mit Kosten 0, deren Teil in den
-- alten Daten gekauft wurde, bekommen den Kaufpreis (deLog "paid", sonst alter Einstand); die Kosten wandern wie beim
-- Entzaubern auf die Materialien: verkaufte Anteile in die Verkaufsbuchungen danach, der Rest ins Lager. Ebenso Verkäufe
-- mit Stücken "ohne Einkauf". deLog wird nur gelesen. Zurück: Anzahl korrigierter Buchungen, Betrag
function BK:RepairOpening(db, deLog)
    db = db or self:Store()
    if not db then return 0, 0 end
    deLog = deLog or (A.db and A.db.deLog) or {}
    local n, total = 0, 0
    local usedDL = {}
    local function Loot(e)
        for i, d in ipairs(deLog) do
            if not usedDL[i] and d.itemID == e.id and math.abs((d.t or 0) - (e.t or 0)) <= 10 then usedDL[i] = true; return d end
        end
    end
    -- Materialanteil in die späteren Verkäufe bzw. ins Lager.
    -- AB8b: zuerst auf die "ohne Einkauf"-Stücke der Verkäufe (s.free sinkt, die Kosten gehören zu genau diesen Stücken),
    -- erst der Rest anteilig auf die übrigen Verkäufe und das Lager. Ohne jedes Ziel: Protokoll, nie still verlieren.
    local noTarget = 0
    local function Spread(ch, mat, q, add, t)
        local sold = {}
        for _, s in ipairs(db.log) do
            if s.k == "sale" and s.id == mat and s.ch == ch and (s.t or 0) >= t then sold[#sold + 1] = s end
        end
        local unit = add / math.max(1, q)
        local leftQ, leftAdd = q, add
        for _, s in ipairs(sold) do
            if leftQ <= 0 then break end
            local k = math.min(s.free or 0, leftQ)
            if k > 0 then
                local part = (k == leftQ) and leftAdd or math.floor(unit * k + 0.5)
                s.cost, s.free, s.fix = (s.cost or 0) + part, s.free - k, "AB8"
                leftQ, leftAdd = leftQ - k, leftAdd - part
            end
        end
        if leftAdd <= 0 then return end
        local qs = 0
        for _, s in ipairs(sold) do qs = qs + (s.q or 0) end
        local held = (db.cb[ch] and db.cb[ch][mat] and db.cb[ch][mat].q) or 0
        if qs + held <= 0 then noTarget = noTarget + leftAdd; return end
        local base = qs + held
        local toSales = math.floor(leftAdd * qs / base + 0.5)
        local given = 0
        for i, s in ipairs(sold) do
            local part = (i == #sold) and (toSales - given) or math.floor(toSales * (s.q or 0) / math.max(1, qs) + 0.5)
            s.cost, given = (s.cost or 0) + part, given + part
            s.fix = "AB8"
        end
        local rest = leftAdd - toSales
        if rest > 0 then
            if held > 0 then local p = Pos(db, ch, mat); p.c = p.c + rest
            elseif sold[#sold] then sold[#sold].cost = (sold[#sold].cost or 0) + rest end
        end
    end
    for _, e in ipairs(db.log) do
        if e.k == "de" and (e.cost or 0) == 0 and not e.fix then
            local d = Loot(e)
            local cost = d and tonumber(d.paid) and d.paid > 0 and math.floor(d.paid) or nil
            if cost then self:OldFill(db, e.id, 1) else cost = self:OldFill(db, e.id, 1) end
            if cost and cost > 0 then
                e.cost, e.fix = cost, "AB8"
                n, total = n + 1, total + cost
                local loot = d and d.loot or {}
                local vals, sum = {}, 0
                for i, l in ipairs(loot) do vals[i] = self:MatValue(l[1]) * (l[2] or 1); sum = sum + vals[i] end
                if #loot == 0 or sum <= 0 then
                    -- ohne Beute-Zeile: nichts raten - Kosten bleiben beim Entzaubern sichtbar (Protokoll)
                    e.noLoot = true
                else
                    local given = 0
                    for i, l in ipairs(loot) do
                        local share = (i == #loot) and (cost - given) or math.floor(cost * vals[i] / sum + 0.5)
                        given = given + share
                        Spread(e.ch, l[1], l[2] or 1, share, e.t or 0)
                    end
                end
            end
        elseif e.k == "sale" and (e.free or 0) > 0 and not e.fixFree then
            local c2, k = self:OldFill(db, e.id, e.free)
            if k > 0 then
                e.cost, e.free, e.fixFree = (e.cost or 0) + c2, e.free - k, true
                n, total = n + 1, total + c2
            end
        end
    end
    if n > 0 then self:RepairNote(db, "AB8", n, string.format("%d Kupfer", total)) end
    if n > 0 and A.Diag and not self.testDB then
        pcall(A.Diag.Add, A.Diag, "BUCHHALTUNG", string.format("AB8 Eröffnungsbilanz korrigiert: %d Buchungen bekommen den alten Einstand (%d Kupfer)", n, total))
    end
    if noTarget > 0 and A.Diag and not self.testDB then
        pcall(A.Diag.Add, A.Diag, "BUCHHALTUNG", string.format("AB8 %d Kupfer ohne Ziel – Material weitergegeben/entzaubert", noTarget))
    end
    self.lastNoTarget = noTarget
    if n > 0 then A:Fire("LEDGER_CHANGED") end
    return n, total
end

-- AB8b: Nachlauf für Daten, die 0.65.97 schon korrigiert hat. Dort bekamen Material-Verkäufe die Kosten anteilig,
-- "ohne Einkauf" blieb stehen. Diese Verkäufe (fix = "AB8") haben jetzt eine bekannte Herkunft -> free = 0.
-- Ändert nur Verkäufe, die die AB8-Korrektur angefasst hat; Protokoll mit Anzahl.
function BK:RepairAB8b(db)
    db = db or self:Store()
    if not db then return 0 end
    local n, pieces = 0, 0
    for _, e in ipairs(db.log or {}) do
        if e.k == "sale" and e.fix == "AB8" and (e.free or 0) > 0 and (e.cost or 0) > 0 then
            pieces = pieces + e.free
            e.free = 0
            n = n + 1
        end
    end
    if n > 0 then self:RepairNote(db, "AB8b", n, string.format("%d Stück", pieces)) end
    if n > 0 and A.Diag and not self.testDB then
        pcall(A.Diag.Add, A.Diag, "BUCHHALTUNG", string.format("AB8b %d Material-Verkäufe (%d Stück): \"ohne Einkauf\" -> Kosten aus der Korrektur", n, pieces))
    end
    if n > 0 then A:Fire("LEDGER_CHANGED") end
    return n, pieces
end

-- AB8 Plausibilität (Selbsttest/Testroutine): Liste der Warnungen { {stufe, text} }
function BK:Plausibility(key)
    local s = self:Summary(key or "today")
    local out = {}
    if s.rev > 0 and s.freeRev / s.rev > 0.30 then
        out[#out + 1] = { "WARNUNG", string.format(L["%d %% des Erlöses ohne Einkauf – Kostenbasis prüfen"], math.floor(s.freeRev / s.rev * 100 + 0.5)) }
    end
    if s.roi and s.roi > 100 and (s.byType.de or 0) > 0 then
        out[#out + 1] = { "WARNUNG", string.format(L["Rendite %d %% beim Entzaubern unwahrscheinlich – Kostenbasis prüfen"], math.floor(s.roi + 0.5)) }
    end
    local db = self:Data()
    local from = self:PeriodStart(key or "today")
    local bad = 0
    for _, e in ipairs(db and db.log or {}) do
        if e.k == "de" and (e.t or 0) >= from and (e.cost or 0) == 0 and self:OldIndex(db)[e.id] then bad = bad + 1 end
    end
    if bad > 0 then out[#out + 1] = { "FEHLER", string.format("%d Entzauberungen mit Kosten 0, obwohl das Teil gekauft wurde", bad) } end
    return out
end

-- Bericht (Testroutine, ohne Namen)
function BK:Report()
    local db = self:Data()
    local out, fields = { "Buchhaltung neu (BP1–BP7):" }, {}
    if not db then out[#out + 1] = "  noch nicht eingerichtet"; return out, fields end
    local s = self:Summary("all")
    local cost, market, n = self:StockValues()
    local med, nd = self:InvoiceDelay()
    out[#out + 1] = string.format("  Stichtag %s · Gewinn %d (Erlös %d − eingesetzt %d − Gebühren %d) · %d Verkäufe (%d ausstehend) · Lager Einstand %d / Markt %d (%d Items)",
        date("%d.%m. %H:%M", db.since), s.profit, s.rev, s.cost, s.fees, s.sales, s.pendingN, cost, market, n)
    do  -- BH-AUS: unterwegs (ausstehend, kein Erlös), alt ohne Rechnung, durch Rechnung ersetzt; Gold-Abstimmung vorhanden?
        local x = 0
        for _, e in ipairs(db.log or {}) do if e.k == "sale" and e.st == "x" then x = x + 1 end end
        local goldN, cbN = 0, 0
        for _ in pairs(db.gold or {}) do goldN = goldN + 1 end
        for _ in pairs(db.cb or {}) do cbN = cbN + 1 end
        out[#out + 1] = string.format("  BH-AUS unterwegs %d (%d Buchungen, älter als 24 Std. ohne Rechnung %d = %d) · durch Rechnung ersetzt %d · Gold-Stände %d Figuren, Einstand %d Figuren",
            s.pending, s.pendingN, s.pendingOld or 0, s.pendingOldRev or 0, x, goldN, cbN)
        fields.buch_unterwegs = string.format("%d/%d/%d/%d", s.pending, s.pendingN, s.pendingOld or 0, x)
        local ri = db.repairBHAUSInfo
        if ri then
            out[#out + 1] = string.format("  BH-AUS Reparatur %s (Version %s): aufgelöst %d Buchungen (%d Stück) · Gewinn alt %d -> neu %d · danach ausstehend %d",
                date("%d.%m. %H:%M", ri.t or 0), ri.v or "?", ri.n or 0, ri.q or 0, ri.before or 0, ri.after or 0, ri.pendingN or 0)
            fields.buch_reparatur = string.format("%d/%d/%d", ri.n or 0, ri.before or 0, ri.after or 0)
        end
        local r3 = db.repairBHAUS3Info
        if r3 then
            out[#out + 1] = string.format("  BH-AUS-3 Phantom-Ware %s (Version %s): %d Buchungen · Lager -%d Stück · Einstand %d auf Rechnungen · Gewinn %d -> %d",
                date("%d.%m. %H:%M", r3.t or 0), r3.v or "?", r3.n or 0, r3.stockBack or 0, r3.cost or 0, r3.profit0 or 0, r3.profit1 or 0)
            fields.buch_reparatur3 = string.format("%d/%d/%d", r3.n or 0, r3.profit0 or 0, r3.profit1 or 0)
        end
        do  -- BH-AUS-3 (b): Lager mehr als vorhanden (diese Figur, Taschen+Bank+eigene Auktionen)
            local okC, chk = pcall(self.StockCheck, self)
            local parts = {}
            for i, x in ipairs(okC and chk or {}) do
                if i > 8 then break end
                parts[#parts + 1] = string.format("Item %d: Lager %d, vorhanden %d (+%d)", x.id, x.q, x.have, x.extra)
            end
            out[#out + 1] = "  BH-AUS-3 Lager mehr als vorhanden (diese Figur): " .. (#parts > 0 and table.concat(parts, " · ") or "keins")
            fields.buch_lager_mehr = #parts > 0 and table.concat(parts, " · "):sub(1, 300) or "keins"
        end
        local r2 = db.repairBHAUS2Info
        if r2 then
            out[#out + 1] = string.format("  BH-AUS-2 Folge-Reparatur %s (Version %s): %d Buchungen · Lager zurück %d Stück · Einstand umgebucht %d Stück · Gewinn %d -> %d · Lager Einstand %d -> %d",
                date("%d.%m. %H:%M", r2.t or 0), r2.v or "?", r2.n or 0, r2.stockBack or 0, r2.moved or 0, r2.profit0 or 0, r2.profit1 or 0, r2.stock0 or 0, r2.stock1 or 0)
            fields.buch_reparatur2 = string.format("%d/%d/%d", r2.n or 0, r2.profit0 or 0, r2.profit1 or 0)
        end
        -- (5) Gold-Abstimmung: Stände je Figur werden beim Laden, Abmelden und Öffnen der Buchhaltung gemerkt
        local okR, change, explained, diff, nCh, from0, pend = pcall(self.ReconcileAll, self)
        if okR and change then
            out[#out + 1] = string.format("  BH-AUS Gold-Abstimmung (TB125-7: %d Figuren, ab %s, nur Zeitraum mit Gold-Ständen): Gold %+d · Buchhaltung %+d · nicht gebucht %+d · unterwegs %d",
                nCh, date("%d.%m. %H:%M", from0 or 0), change, explained, diff, pend or 0)
            fields.buch_abgleich = string.format("%d/%d/%d (%d Fig.)", change, explained, diff, nCh)
        else
            out[#out + 1] = "  BH-AUS Gold-Abstimmung: lernt noch (noch keine Figur mit 2 Gold-Ständen)"
            fields.buch_abgleich = "lernt noch"
        end
    end
    out[#out + 1] = string.format("  EB1 Eigenbedarf (angelegt, nicht im Handelsgewinn): %d Stück · %d", s.ownN or 0, s.ownUse or 0)
    fields.buch_eigenbedarf = string.format("%d/%d", s.ownN or 0, s.ownUse or 0)
    out[#out + 1] = string.format("  BH-ANZ %s: hinterlegt %d · verfallen (Aufwand, gesamt) %d · gezahlt minus zurück (Gold-Fluss) %d",
        self:DepositWord(), s.depHeld or 0, s.fees or 0, s.feesRaw or 0)
    fields.buch_anzahlung = string.format("%d/%d/%d", s.depHeld or 0, s.fees or 0, s.feesRaw or 0)
    out[#out + 1] = "  TS111.3 grösste Lagerposten: " .. (self:StockTopText(5) ~= "" and self:StockTopText(5) or "-")
    out[#out + 1] = string.format("  B1 Verzögerung verkauft -> Rechnung: %s", med and string.format("Median %.0f Min. (%d Fälle)", med / 60, nd) or "noch keine Messung")
    local Se = A.Seller
    local sm = Se and Se.saleMsg
    out[#out + 1] = string.format("  VERKAUF-MELDUNG: geschützt %d · lesbar %d (Systemmeldungen dieser Sitzung)", sm and sm.secret or 0, sm and sm.readable or 0)
    -- AB8: Plausibilität (FEHLER = Kostenbasis verloren) und alter Einstand
    local okP, pl = pcall(self.Plausibility, self, "today")
    for _, w in ipairs(okP and pl or {}) do out[#out + 1] = "  " .. w[1] .. " Plausibilität: " .. w[2] end
    -- BH1307: Herkunft der Verkäufe ohne Einstand (heute)
    local okF, fo = pcall(self.FreeOrigins, self, "today")
    for i, p in ipairs(okF and fo or {}) do
        if i > 10 then break end
        out[#out + 1] = string.format("  BH1307 ohne Einstand: Item %d · %d Stück · Erlös %d · Herkunft %s", p.id, p.q, p.rev, p.origin)
    end
    out[#out + 1] = string.format("  AB8 alter Einstand übernommen: %d Stück", db.oldFilled or 0)
    for _, r in ipairs(db.repairLog or {}) do
        out[#out + 1] = string.format("  Reparatur %s · %s · Version %s · Anzahl %s%s", r.what or "?", date("%d.%m. %H:%M", r.t or 0), r.v or "?",
            (r.n or 0) >= 0 and tostring(r.n) or "unbekannt", r.info and (" · " .. r.info) or "")
    end
    out[#out + 1] = string.format("  L1c gesicherte Buchungen: %d", db.removedL1b and #db.removedL1b or 0)
    if A.PD7 then local okP7, st7 = pcall(A.PD7.Status, A.PD7); if okP7 then out[#out + 1] = "  " .. st7 end end
    -- PD7: Datengrösse je Bereich (geschätzt) und letzte Verdichtung
    local okS, sz, nH = pcall(A.DataSizes, A)
    if okS and sz then
        out[#out + 1] = string.format("  PD7 Grösse (geschätzt): Preisverlauf %d Zeilen ~%d KB · Rhythmus ~%d KB · Prognose ~%d KB · Buchungen ~%d KB",
            nH or 0, sz.verlauf or 0, sz.rhythmus or 0, sz.prognose or 0, sz.buchungen or 0)
    end
    local cl = A.db and A.db.compactLog
    if cl then out[#out + 1] = string.format("  PD7 letzte Verdichtung %s (Version %s): %d -> %d Zeilen (~%d -> ~%d KB)", date("%d.%m. %H:%M", cl.t), cl.v or "?", cl.before or 0, cl.after or 0, cl.kb0 or 0, cl.kb1 or 0) end
    fields.buchhaltung_gewinn = tostring(s.profit)
    fields.buchhaltung_b1 = med and string.format("%.0f min (%d)", med / 60, nd) or "-"
    return out, fields
end

-- ------------------------------------------------------------
-- Ereignisse
-- ------------------------------------------------------------
-- eigene Auktionen gelesen: neu als verkauft markierte -> "ausstehend" (Forever: Chat-Meldung ist geschützt)
function BK:CheckOwned(owned)
    local db = self:Store()
    if not db then return 0 end
    local n = 0
    local seq, perID = {}, {}
    for _, o in ipairs(owned or {}) do
        if o.sold and o.auctionID and o.itemID then
            local gross = o.buyout or ((o.unitPrice or 0) * (o.qty or 1))
            local base = table.concat({ tostring(o.auctionID), tostring(o.qty or 1), tostring(gross) }, ":")
            seq[base] = (seq[base] or 0) + 1
            perID[o.auctionID] = (perID[o.auctionID] or 0) + 1
            local key = base .. "#" .. seq[base]
            -- L1: bis 0.65.92 galt die auctionID allein als Kennung. Der ERSTE verkaufte Eintrag dieser auctionID ist
            -- damals schon gebucht worden -> neue Kennung übernehmen statt nochmals buchen
            if not db.seenSold[key] and perID[o.auctionID] == 1 and db.seenSold[o.auctionID] then
                db.seenSold[key] = db.seenSold[o.auctionID]
            end
            if not db.seenSold[key] and self:PendingSale(o.itemID, o.qty or 1, gross, o.auctionID, nil, key) then n = n + 1 end
        end
    end
    -- alte auctionIDs vergessen
    local cutoff = Now() - self.SOLD_KEEP
    for id, t in pairs(db.seenSold) do if t < cutoff then db.seenSold[id] = nil end end
    return n
end

A:On("SELLER_CHANGED", function()
    local Se = A.Seller
    if Se and Se.owned and Se.ownedTime then pcall(BK.CheckOwned, BK, Se.owned) end
end)
-- altes Auktionshaus: Käufer-Meldung lesbar -> eigene Auktion gefunden
A:On("OWN_AUCTION_SOLD", function(o)
    if o and o.itemID then pcall(BK.PendingSale, BK, o.itemID, o.qty or 1, o.buyout or 0, o.auctionID) end
end)
A:On("DE_LOOT", function(itemID, loot) pcall(BK.OnDisenchant, BK, itemID, loot) end)
A:On("TWINK_MAIL_SENT", function(toKey, items) pcall(BK.OnTwinkMail, BK, toKey, items) end)
-- EB4-2 (1): Herstellen buchen (Zutaten aus dem Lager, Kosten ins Produkt) - bisher nicht verbunden
A:On("CRAFT_DONE", function(pid, made, reagents)
    if A.TestRoutine and A.TestRoutine.running and not BK.testDB then return end
    BK.lastCraftT = Now()
    local list = {}
    for _, r in ipairs(reagents or {}) do if r[1] then list[#list + 1] = { r[1], r[2] or 1 } end end
    pcall(BK.OnCraft, BK, pid, made, list)
end)
-- EB4-2 (2): von Hand verschickte Post: an eigene Figur -> Lager wandert mit (wie BP2); an andere -> Eigenbedarf
-- "verschickt" (im Bericht). Eigene Sendungen von AHSentinel bucht schon TWINK_MAIL_SENT.
function BK:ReadSendMail(to)
    local items = {}
    local max = ATTACHMENTS_MAX_SEND or 12
    for i = 1, max do
        local id, count
        if GetSendMailItemLink then
            local okL, link = pcall(GetSendMailItemLink, i)
            id = okL and link and tonumber(tostring(link):match("item:(%d+)"))
        end
        if id and GetSendMailItem then
            local okI, a, b, c, d = pcall(GetSendMailItem, i)
            if okI then for _, v in ipairs({ d, c, b }) do if type(v) == "number" and v >= 1 and v < 1000 then count = v; break end end end
        end
        if id then items[#items + 1] = { id, count or 1 } end
    end
    return items
end
function BK:OnMailSent(to, items)
    local db = self:Store()
    if not (db and items and #items > 0) then return 0 end
    local toKey
    local Ch = A.Chars
    for _, c in ipairs((Ch and Ch.GetAll and Ch:GetAll()) or {}) do
        if c.name and string.lower(c.name) == string.lower((to or ""):match("^[^-]+") or "") then toKey = c.key end
    end
    if toKey then self:OnTwinkMail(toKey, items); return #items end
    local ch, n = self:CharKey(), 0
    for _, it in ipairs(items) do
        local p = db.cb[ch] and db.cb[ch][it[1]]
        local take = p and math.min(p.q or 0, it[2] or 1) or 0
        if take > 0 then
            local cost = Take(db, ch, it[1], take)
            Log(db, { k = "own", ch = ch, id = it[1], q = take, cost = cost, why = "verschickt" })
            n = n + take
        end
    end
    if n > 0 then A:Fire("LEDGER_CHANGED") end
    return n
end
if hooksecurefunc and SendMail then
    pcall(hooksecurefunc, "SendMail", function(to)
        if (A.Extras and A.Extras.sending) or (A.TestRoutine and A.TestRoutine.running) then return end
        local ok, items = pcall(BK.ReadSendMail, BK, to)
        BK.pendingMail = ok and #items > 0 and { to = to, items = items } or nil
    end)
end
do
    local mf = CreateFrame("Frame")
    pcall(mf.RegisterEvent, mf, "MAIL_SEND_SUCCESS")
    pcall(mf.RegisterEvent, mf, "MAIL_FAILED")
    mf:SetScript("OnEvent", function(_, event)
        local pm = BK.pendingMail
        BK.pendingMail = nil
        if event == "MAIL_SEND_SUCCESS" and pm then pcall(BK.OnMailSent, BK, pm.to, pm.items) end
    end)
end

A:On("READY", function()
    BK:Ensure()
    local db = BK:Store()
    if db and not db.repairedL1 then pcall(BK.RepairDoubles, BK, db); db.repairedL1 = true end
    if db and not db.repairedL1b then pcall(BK.RepairDoubles2, BK, db); db.repairedL1b = true; db.repairedL1c = true end
    if db and not db.repairedL1c then
        -- L1c-Nachlauf: Die alte L1b-Reparatur (0.65.98/0.65.99) lief schon; was sie entfernt hat, lässt sich nicht finden.
        db.repairedL1c = true
        BK:RepairNote(db, "L1b (alt, 0.65.98/99)", -1, "Zahl unbekannt - steht nur im Diagnose-Protokoll jener Sitzung")
    end
    if db and not db.repairedAB8 then pcall(BK.RepairOpening, BK, db); db.repairedAB8 = true; db.repairedAB8b = true end
    if db and not db.repairedAB8b then pcall(BK.RepairAB8b, BK, db); db.repairedAB8b = true end
    if db and not db.repairedBHAUS then
        -- BH-AUS-R: Merker nur bei Erfolg; Fehler in die Diagnose (nächster Login versucht es wieder)
        local okR, err = pcall(BK.RepairPendingAUS, BK, db)
        if okR then db.repairedBHAUS = true; db.repairedBHAUS2 = true      -- neue Reparatur bucht schon richtig um
        elseif A.Diag then pcall(A.Diag.Add, A.Diag, "FEHLER", "BH-AUS Reparatur: " .. tostring(err)) end
    end
    if db and not db.repairedBHAUS2 then
        -- BH-AUS-2: 0.65.124 lief schon -> Lager-Zugang zurück, Einstand auf die Rechnung
        local okR2, err2 = pcall(BK.RepairPendingAUS2, BK, db)
        if okR2 then db.repairedBHAUS2 = true
        elseif A.Diag then pcall(A.Diag.Add, A.Diag, "FEHLER", "BH-AUS-2 Reparatur: " .. tostring(err2)) end
    end
    if db and not db.repairedBHAUS3 then
        -- BH-AUS-3: 0.65.125 lief schon -> Phantom-Ware aus dem Lager, Einstand auf die Rechnungen
        local okR3, err3 = pcall(BK.RepairPendingAUS3, BK, db)
        if okR3 then db.repairedBHAUS3 = true
        elseif A.Diag then pcall(A.Diag.Add, A.Diag, "FEHLER", "BH-AUS-3 Reparatur: " .. tostring(err3)) end
    end
    BK:RecordGold()
    -- Eröffnungsbestand nach dem Einloggen (Taschen/Bank sind dann gelesen)
    if C_Timer and C_Timer.After then
        C_Timer.After(20, function() if A.Job then A:Job("books:open", function() pcall(BK.OpenChar, BK) end) end end)
        C_Timer.After(30, function() if not (A.TestRoutine and A.TestRoutine.running) then pcall(BK.CheckOwnUse, BK); pcall(BK.CheckVendorUse, BK) end end)   -- EB1/EB4-1
    end
end)
-- BH-ANZ-1: Abbruch -> Anzahlung verfällt (kommt in Forever eine Erstattung, löst sie sie wieder auf)
A:On("AUCTION_CANCELLED", function(c)
    if c and c.itemID and not (A.TestRoutine and A.TestRoutine.running) then pcall(BK.OnDepositLost, BK, c.itemID, "abbruch") end
end)
do
    local f = CreateFrame("Frame")
    pcall(f.RegisterEvent, f, "PLAYER_LOGOUT")
    pcall(f.RegisterEvent, f, "PLAYER_MONEY")
    pcall(f.RegisterEvent, f, "PLAYER_EQUIPMENT_CHANGED")
    pcall(f.RegisterEvent, f, "BAG_UPDATE_DELAYED")
    f:SetScript("OnEvent", function(_, event)
        if event == "PLAYER_LOGOUT" then pcall(BK.RecordGold, BK)
        elseif event == "BAG_UPDATE_DELAYED" and not (A.TestRoutine and A.TestRoutine.running) then
            -- EB4-1: Händlerware verbraucht? höchstens alle 30 s prüfen
            if not BK.vendorPending and C_Timer and C_Timer.After then
                BK.vendorPending = true
                C_Timer.After(30, function() BK.vendorPending = nil; pcall(BK.CheckVendorUse, BK) end)
            end
        elseif event == "PLAYER_EQUIPMENT_CHANGED" and not (A.TestRoutine and A.TestRoutine.running) then
            -- EB1: etwas angelegt / Tasche eingesetzt -> kurz danach prüfen (gesammelt)
            if not BK.ownPending and C_Timer and C_Timer.After then
                BK.ownPending = true
                C_Timer.After(2, function() BK.ownPending = nil; pcall(BK.CheckOwnUse, BK) end)
            end
        end
    end)
end

-- /ahs buchhaltung neu (mit Rückfrage)
function BK:Command(arg)
    arg = (arg or ""):lower()
    if arg == "neu" or arg == "new" then
        if StaticPopupDialogs and StaticPopup_Show then
            StaticPopupDialogs["AHSENTINEL_BOOKS_RESTART"] = {
                text = L["Buchhaltung neu beginnen? Ab jetzt zählt nur noch, was ab heute passiert. Alte Daten bleiben im Hintergrund."],
                button1 = YES or "Ja", button2 = NO or "Nein", timeout = 0, whileDead = true, hideOnEscape = true,
                OnAccept = function()
                    BK:Restart()
                    pcall(BK.RecordGold, BK)
                    if A.Job then A:Job("books:open", function() pcall(BK.OpenChar, BK) end) end
                    A:Print(L["Buchhaltung neu begonnen."])
                end,
            }
            StaticPopup_Show("AHSENTINEL_BOOKS_RESTART")
            return true
        end
        BK:Restart()
        A:Print(L["Buchhaltung neu begonnen."])
        return true
    end
    local s = self:Summary("all")
    A:Print(string.format(L["Gewinn seit Neustart: %s (%d Verkäufe)"], A:FormatMoney(s.profit), s.sales))
    return true
end
