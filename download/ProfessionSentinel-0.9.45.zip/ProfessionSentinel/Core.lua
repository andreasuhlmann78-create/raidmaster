local ADDON, ns = ...
local L = ns.L

ns.ADDON = ADDON
ns.VERSION = "0.9.45"   -- must match "## Version:" in all four .toc files (the test routine checks it)
ns.Recipes = {}        -- array of recipe tables
ns.BySpell = {}        -- spellID -> recipe
ns.ByProf = {}         -- skillLineID -> { recipes... }
ns.ByRecipeItem = {}   -- recipe itemID -> recipe
ns.ByOutput = {}       -- crafted itemID -> { recipes... }
ns.ByName = {}         -- lower-case name (de/en) -> recipe
ns.ProfById = {}
ns.Professions = ns.Professions or {}
ns.Items = ns.Items or {}
ns.NPCs = ns.NPCs or {}
ns.DataMeta = ns.DataMeta or {}

-- Source bits (must match gen_addon_data.py)
ns.SRC = { TRAINER = 1, AUTO = 2, VENDOR = 4, DROP = 8, WORLDDROP = 16, QUEST = 32, CONTAINER = 64, UNKNOWN = 128 }

-- Item quality colours: grey, white, green, blue, purple, legendary, artifact
ns.QUALITY_HEX = { [0] = "9d9d9d", [1] = "ffffff", [2] = "1eff00", [3] = "0070dd", [4] = "a335ee", [5] = "ff8000", [6] = "e6cc80" }

function ns.QualityRGB(q)
    local hex = ns.QUALITY_HEX[q or 1] or "ffffff"
    return tonumber(hex:sub(1, 2), 16) / 255, tonumber(hex:sub(3, 4), 16) / 255, tonumber(hex:sub(5, 6), 16) / 255
end

function ns.Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff3fc7ebProfession|r|cffffd100Sentinel|r: " .. tostring(msg))
end

---------------------------------------------------------------------------
-- ns.API: the Blizzard functions the addon uses, read when the addon loads (again at ADDON_LOADED).
-- The addon calls and checks only these entries. The test routine replaces only entries of THIS table
-- (Stub(ns.API, ...)), never a Blizzard global or a C_ table: replacing those would taint them until /reload.
-- Functions of C_ tables get flat entries (C_MerchantFrame.GetItemInfo -> ns.API.MerchantGetItemInfo).
-- A function the client does not have stays nil, so old clients (Classic Era) keep their old ways.
---------------------------------------------------------------------------
ns.API = ns.API or {}
local API_GLOBALS = {
    "GetItemInfo", "GetItemIcon", "GetSpellTexture", "GetItemCount", "GetItemInfoInstant",
    "GetContainerNumSlots", "GetContainerItemID", "GetContainerNumFreeSlots", "GetContainerItemInfo",
    "GetProfessions", "GetProfessionInfo", "GetNumSkillLines", "GetSkillLineInfo",
    "GetTradeSkillLine", "GetTradeSkillInfo", "GetNumTradeSkills", "GetTradeSkillRecipeLink",
    "ExpandTradeSkillSubClass", "SetTradeSkillItemNameFilter",
    "GetNumCrafts", "GetCraftInfo", "GetCraftDisplaySkillLine", "GetCraftRecipeLink",
    "GetAddOnMetadata", "IsAddOnLoaded", "GetAddOnMemoryUsage",
    "GetMerchantNumItems", "GetMerchantItemInfo", "GetMerchantItemID", "GetMerchantItemLink",
    "GetMerchantItemCostInfo", "GetMerchantItemCostItem",
    "GetFactionInfoByID",
    "GetCursorPosition",   -- dragging the minimap button (Minimap.lua)
    "debugprofilestop",    -- diagnostic log: duration of clicks, rebuilds and slow steps (Diagnose.lua)
    "GetRealmName", "GetGuildInfo",   -- diagnostic log: names that are replaced by "<Name>" (never written out)
    "GetInboxNumItems", "GetInboxInvoiceInfo",   -- check of the recommendations (Market.lua PM6): invoices are only read
    -- actions (only as a switch "available"; ns.Act calls the live function)
    "BuyMerchantItem", "SendChatMessage", "DoTradeSkill",
}
local API_TABLES = {
    { "C_Item", "Item", { "GetItemInfo", "GetItemIconByID", "GetItemCount", "GetItemNameByID", "RequestLoadItemDataByID",
        "GetItemInfoInstant" } },
    { "C_Spell", "Spell", { "GetSpellTexture" } },
    { "C_Container", "Container", { "GetContainerNumSlots", "GetContainerItemID", "GetContainerNumFreeSlots",
        "GetContainerItemInfo" } },
    { "C_TradeSkillUI", "TradeSkill", { "GetChildProfessionInfo", "GetBaseProfessionInfo", "GetRecipeInfo",
        "GetProfessionInfoBySkillLineID", "GetAllRecipeIDs", "IsTradeSkillLinked", "IsTradeSkillGuild",
        "IsNPCCrafting", "OpenRecipe", "CraftRecipe", "GetRecipeSchematic" } },
    { "C_CurrencyInfo", "Currency", { "GetCurrencyInfo", "GetCurrencyListSize", "GetCurrencyListInfo" } },
    { "C_AddOns", "AddOns", { "GetAddOnMetadata", "IsAddOnLoaded", "GetAddOnMemoryUsage", "GetAddOnInfo" } },
    { "C_MerchantFrame", "Merchant", { "GetNumItems", "GetItemInfo", "BuyItem" } },
    { "C_Reputation", "Reputation", { "GetFactionDataByID" } },
    { "C_Timer", "Timer", { "After" } },
    { "C_ChatInfo", "Chat", { "SendChatMessage" } },
    { "C_Map", "Map", { "SetUserWaypoint", "CanSetUserWaypointOnMap" } },
    { "C_SuperTrack", "SuperTrack", { "SetSuperTrackedUserWaypoint" } },
}
ns.API_GLOBALS, ns.API_TABLES = API_GLOBALS, API_TABLES

local function Fn(v) return type(v) == "function" and v or nil end

-- (re)reads every entry; the offline tests call it after their mock has changed the client
function ns.API.Refresh()
    local A = ns.API
    for _, n in ipairs(API_GLOBALS) do A[n] = Fn(_G[n]) end
    for _, d in ipairs(API_TABLES) do
        local t = _G[d[1]]
        for _, f in ipairs(d[3]) do A[d[2] .. f] = type(t) == "table" and Fn(t[f]) or nil end
    end
end
ns.API.Refresh()

---------------------------------------------------------------------------
-- ns.Act: the ONLY place for actions with real consequences (buying, whispering, crafting, map pins).
-- kind: "buy" (slot, count) · "whisper" (text, target) · "craft" (spellID, count) · "tradeskill" (index, count)
--       · "waypoint" (mapID, x, y)
-- Whether a way exists is decided by ns.API (tests can switch it off); the call itself goes to the live
-- function, so hooks (also the test routine's watchers) see it. While the test routine runs, ns.ActRecord
-- is set: then the action is only written down and nothing happens.
-- Returns true when the action was started.
---------------------------------------------------------------------------
local function Live(tname, fname)
    local t = tname and _G[tname] or _G
    return type(t) == "table" and Fn(t[fname]) or nil
end

-- ACT BEGIN (tests/check_actions.py: the action functions may only be called between these marks)
function ns.CanAct(kind)
    local A = ns.API
    if kind == "buy" then return (A.BuyMerchantItem or A.MerchantBuyItem) ~= nil
    elseif kind == "whisper" then return (A.SendChatMessage or A.ChatSendChatMessage) ~= nil
    elseif kind == "craft" then return A.TradeSkillCraftRecipe ~= nil
    elseif kind == "tradeskill" then return A.DoTradeSkill ~= nil
    elseif kind == "waypoint" then return A.MapSetUserWaypoint ~= nil and UiMapPoint ~= nil and UiMapPoint.CreateFromCoordinates ~= nil
    end
    return false
end

function ns.Act(kind, ...)
    if ns.ActRecord then return ns.ActRecord(kind, ...) end
    local A = ns.API
    if kind == "buy" then
        local i, n = ...
        if A.BuyMerchantItem then
            local f = Live(nil, "BuyMerchantItem") or A.BuyMerchantItem
            f(i, n)
            return true
        end
        if A.MerchantBuyItem then
            local f = Live("C_MerchantFrame", "BuyItem") or A.MerchantBuyItem
            return (pcall(f, i, n))
        end
        return false
    elseif kind == "whisper" then
        local text, to = ...
        -- the global SendChatMessage where the client still has it, otherwise C_ChatInfo.SendChatMessage
        if A.SendChatMessage then
            local f = Live(nil, "SendChatMessage") or A.SendChatMessage
            f(text, "WHISPER", nil, to)
            return true
        end
        if A.ChatSendChatMessage then
            local f = Live("C_ChatInfo", "SendChatMessage") or A.ChatSendChatMessage
            f(text, "WHISPER", nil, to)
            return true
        end
        return false
    elseif kind == "craft" then
        local spell, n = ...
        if not A.TradeSkillCraftRecipe then return false end
        local f = Live("C_TradeSkillUI", "CraftRecipe") or A.TradeSkillCraftRecipe
        return (pcall(f, spell, n))
    elseif kind == "tradeskill" then
        local idx, n = ...
        if not A.DoTradeSkill then return false end
        local f = Live(nil, "DoTradeSkill") or A.DoTradeSkill
        f(idx, n)
        return true
    elseif kind == "waypoint" then
        local mapID, x, y = ...
        if not ns.CanAct("waypoint") then return false end
        local f = Live("C_Map", "SetUserWaypoint") or A.MapSetUserWaypoint
        f(UiMapPoint.CreateFromCoordinates(mapID, x, y))
        local st = Live("C_SuperTrack", "SetSuperTrackedUserWaypoint") or A.SuperTrackSetSuperTrackedUserWaypoint
        if st then st(true) end
        return true
    end
    return false
end
-- ACT END

---------------------------------------------------------------------------
-- Error counting (GoldSentinelTest.lua, shared by all GoldSentinel addons): stays local in the saved
-- variables, at most 50 kinds of errors; sent to the review with the next report.
---------------------------------------------------------------------------
function ns.CountError(where, err)
    local GT = _G.GoldSentinelTest
    if GT and GT.Error then pcall(GT.Error, ADDON, where, err) end
    -- diagnostic log (Diagnose.lua): entry FEHLER, the same error only counted (no loop)
    if ns.DiagError then pcall(ns.DiagError, where, err) end
end

-- pcall that counts the error; returns the results of fn, or nil on an error
function ns.Try(where, fn, ...)
    local res = { pcall(fn, ...) }
    if not res[1] then
        ns.CountError(where, res[2])
        return nil
    end
    return unpack(res, 2, table.maxn(res))
end

-- every event frame of the addon (the test routine calls their handlers directly)
ns.EventFrames = ns.EventFrames or {}
function ns.AddEventFrame(f, label)
    if f then ns.EventFrames[#ns.EventFrames + 1] = { frame = f, label = label } end
    return f
end

-- No actions with real consequences in combat (buying, crafting, whispering, waypoints)
function ns.InCombat()
    local G = _G.GoldSentinelGame
    if G and G.InCombat then return G.InCombat() end
    return InCombatLockdown and InCombatLockdown() and true or false
end

function ns.BlockedInCombat()
    if ns.InCombat() then ns.Print(L.NOT_IN_COMBAT); return true end
    return false
end

-- GetItemInfo: the old global first (exactly as before), C_Item where it is gone (modern client)
function ns.ItemInfo(itemID)
    local A = ns.API
    if A.GetItemInfo then return A.GetItemInfo(itemID) end
    if A.ItemGetItemInfo then return A.ItemGetItemInfo(itemID) end
    return nil
end

-- equip slot, class and subclass without the item cache (GetItemInfoInstant): equipLoc, classID, subclassID
function ns.ItemSlotInfo(itemID)
    local A = ns.API
    local fn = A.GetItemInfoInstant or A.ItemGetItemInfoInstant
    if fn and itemID then
        local ok, _, _, _, equipLoc, _, classID, subclassID = pcall(fn, itemID)
        if ok and (equipLoc or classID) then return equipLoc, classID, subclassID end
    end
    local ok, _, _, _, _, _, _, _, _, equipLoc, _, _, classID, subclassID = pcall(ns.ItemInfo, itemID)
    if ok then return equipLoc, classID, subclassID end
    return nil
end

function ns.FlavorName()
    if ns.IsForever then return L.FLAVOR_FOREVER end
    if ns.IsEra then return L.FLAVOR_ERA end
    if ns.IsRetail then return L.FLAVOR_RETAIL end
    return "?"
end

---------------------------------------------------------------------------
-- API compatibility helpers
---------------------------------------------------------------------------
function ns.GetItemIcon(itemID)
    local A = ns.API
    if A.ItemGetItemIconByID then
        local icon = A.ItemGetItemIconByID(itemID)
        if icon then return icon end
    end
    if A.GetItemIcon then return A.GetItemIcon(itemID) end
    return 134400 -- question mark
end

function ns.GetSpellIcon(spellID)
    local A = ns.API
    if A.SpellGetSpellTexture then
        local t = A.SpellGetSpellTexture(spellID)
        if t then return t end
    end
    if A.GetSpellTexture then return A.GetSpellTexture(spellID) end
    return 134400
end

function ns.GetItemLink(itemID)
    local A = ns.API
    if A.ItemGetItemInfo then return (select(2, A.ItemGetItemInfo(itemID))) end
    if A.GetItemInfo then return (select(2, A.GetItemInfo(itemID))) end
    return nil
end

-- bags (bank = true also counts the bank, as before)
local function CountRaw(itemID, bank)
    local A = ns.API
    if A.ItemGetItemCount then return A.ItemGetItemCount(itemID, bank) or 0 end
    if A.GetItemCount then return A.GetItemCount(itemID, bank) or 0 end
    return 0
end

function ns.GetItemCount(itemID, bank)
    if bank == nil then bank = true end
    -- inside a price pass (Prices.lua) every bag count is read once
    local pass = ns.Prices and ns.Prices.Pass and ns.Prices.Pass()
    if pass and itemID then
        local k = bank and itemID or -itemID
        local c = pass.cnt[k]
        if c == nil then c = CountRaw(itemID, bank); pass.cnt[k] = c else pass.hits = pass.hits + 1 end
        return c
    end
    local A = ns.API
    if A.ItemGetItemCount then return A.ItemGetItemCount(itemID, bank) or 0 end
    if A.GetItemCount then return A.GetItemCount(itemID, bank) or 0 end
    return 0
end

-- Names: the data ships German names; on other clients prefer the live client name.
function ns.ItemName(itemID)
    local d = ns.Items[itemID]
    if not ns.isGerman then
        local name
        if ns.API.ItemGetItemNameByID then name = ns.API.ItemGetItemNameByID(itemID)
        else name = ns.ItemInfo(itemID) end
        if name then return name end
    end
    return d and d[1] or ("Item " .. itemID)
end

function ns.ItemQuality(itemID)
    local d = ns.Items[itemID]
    return d and d[2] or 1
end

function ns.RecipeName(r)
    if ns.isGerman then return r.name end
    return (r.nameEN and r.nameEN ~= "") and r.nameEN or r.name
end

function ns.ProfName(profID)
    local p = ns.ProfById[profID]
    if not p then return "?" end
    if ns.isGerman then return p.name end
    if ns.ProfessionNamesEN[profID] then return ns.ProfessionNamesEN[profID] end
    -- Retail expansion lines: the client's own name in its language
    if ns.API.TradeSkillGetProfessionInfoBySkillLineID then
        local ok, info = pcall(ns.API.TradeSkillGetProfessionInfoBySkillLineID, profID)
        if ok and type(info) == "table" and info.professionName and info.professionName ~= "" then return info.professionName end
    end
    return p.name
end

---------------------------------------------------------------------------
-- Learned state (single place, test mode can override it)
---------------------------------------------------------------------------
function ns.IsLearned(r)
    if ns.Sim and ns.Sim.known == "all" then return true end
    if ns.Sim and ns.Sim.known == "none" then return false end
    return ns.Scan and ns.Scan:IsKnown(r.spell) or false
end

---------------------------------------------------------------------------
-- Build lookup tables from the compact generated rows
---------------------------------------------------------------------------
local indexed = false
local function BuildIndex()
    if indexed or not ns.RecipeRows then return end
    indexed = true
    for _, p in ipairs(ns.Professions) do
        ns.ProfById[p.id] = p
        ns.ByProf[p.id] = {}
    end
    for i, row in ipairs(ns.RecipeRows) do
        local r = {
            spell = row[1], prof = row[2], name = row[3], nameEN = row[4], cat = row[5], catOrder = row[6],
            req = row[7], yellow = row[8], green = row[9], grey = row[10],
            out = row[11] ~= 0 and row[11] or nil, outMin = row[12], outMax = row[13],
            src = row[14], isNew = row[15] == 1, ench = row[16] == 1,
            reagents = row[17], recipeItems = row[18], skillUps = row[19] or 1, learnLevel = row[20], index = i,
        }
        -- Rarity: recipe item first, otherwise the crafted item.
        local q
        if r.recipeItems[1] then q = ns.ItemQuality(r.recipeItems[1].id) end
        if not q and r.out then q = ns.ItemQuality(r.out) end
        r.quality = q or 1
        r.searchText = (r.name .. " " .. (r.nameEN or "") .. " " .. (r.cat or "")):lower()
        ns.Recipes[#ns.Recipes + 1] = r
        ns.BySpell[r.spell] = r
        if ns.ByProf[r.prof] then table.insert(ns.ByProf[r.prof], r) end
        for _, ri in ipairs(r.recipeItems) do ns.ByRecipeItem[ri.id] = r end
        if r.out then
            ns.ByOutput[r.out] = ns.ByOutput[r.out] or {}
            table.insert(ns.ByOutput[r.out], r)
        end
        ns.ByReagent = ns.ByReagent or {}
        for k = 1, #r.reagents, 2 do
            local id = r.reagents[k]
            ns.ByReagent[id] = ns.ByReagent[id] or {}
            table.insert(ns.ByReagent[id], r)
        end
        ns.ByName[r.name:lower()] = r
        if r.nameEN and r.nameEN ~= "" then ns.ByName[r.nameEN:lower()] = r end
    end
    -- Sort like the client window: category order, then skill (highest first), then name.
    for _, list in pairs(ns.ByProf) do
        table.sort(list, function(a, b)
            if (a.cat or "") ~= (b.cat or "") then
                if a.catOrder ~= b.catOrder then return a.catOrder < b.catOrder end
                return (a.cat or "") < (b.cat or "")
            end
            if a.yellow ~= b.yellow then return a.yellow > b.yellow end
            return a.name < b.name
        end)
    end
end
ns.BuildIndex = BuildIndex

---------------------------------------------------------------------------
-- Saved variables
---------------------------------------------------------------------------
local DEFAULTS = {
    tooltip = true,
    lifeline = true,
    best = true,
    panelOpen = true,
    filters = { missing = false },
    collapsed = {},
    chars = {},
    vzMarkup = 20,      -- selling enchants: surcharge on the material cost in %
    vzMinProfit = 0,    -- selling enchants: at least this much profit per enchant (copper)
    deMargin = 20,      -- disenchanting: minimum margin in % for the sniper prices
    recipeAlert = true, -- alarm when a missing recipe is in the AH (AHSentinel scan)
    todayCrates = false, -- WoW Forever: best Waylaid Crate (gold per favor) in "craft today" (off by default)
    guildShare = true,  -- share known recipes and cooldowns with the guild
    minimapButton = true, -- button at the minimap (Minimap.lua, /ps minimap)
    merchantQty = true,   -- Shift+click at the vendor opens the amount window (MerchantQty.lua, /ps menge)
    minimapAngle = 200,   -- position of that button around the minimap in degrees (per account)
    goldRaid = false,     -- tab "Gold": only raid food and potions (Market.lua PM5, offered up to the raid start)
}

local function CopyDefaults(src, dst)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then dst[k] = {} end
            CopyDefaults(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
end

local function Num(v, default, min, max)
    v = tonumber(v)
    if not v or v ~= v or (min and v < min) or (max and v >= max) then return default end
    return v
end

-- character entry: { known = { [spell] = true }, profs = { [id] = { rank, max } }, class, faction, flavor }
local function CleanChar(c)
    if type(c.known) ~= "table" then c.known = {} end
    if type(c.profs) ~= "table" then c.profs = {} end
    for id, p in pairs(c.profs) do
        if type(p) ~= "table" then c.profs[id] = nil end
    end
    if c.enchantGoal ~= nil and c.enchantGoal ~= "gold" and c.enchantGoal ~= "sell" and c.enchantGoal ~= "both" then
        c.enchantGoal = nil
    end
end

-- Saved variables: fill in defaults and drop broken entries (old or damaged files never cause Lua errors).
-- Returns db; also used by the test routine on its own test tables.
function ns.InitDB(db)
    if type(db) ~= "table" then db = {} end
    CopyDefaults(DEFAULTS, db)
    for key, c in pairs(db.chars) do
        if type(key) ~= "string" or type(c) ~= "table" then db.chars[key] = nil else CleanChar(c) end
    end
    db.vzMarkup = Num(db.vzMarkup, DEFAULTS.vzMarkup, 0)
    db.vzMinProfit = Num(db.vzMinProfit, DEFAULTS.vzMinProfit, 0)
    db.deMargin = Num(db.deMargin, DEFAULTS.deMargin, 0, 100)
    -- minimap button: only a real number is an angle (no text, NaN or infinity), kept within 0 … 360
    local angle = db.minimapAngle
    if type(angle) ~= "number" or angle ~= angle or angle >= math.huge or angle <= -math.huge then
        angle = DEFAULTS.minimapAngle
    end
    db.minimapAngle = angle % 360
    if type(db.minimapButton) ~= "boolean" then db.minimapButton = DEFAULTS.minimapButton end
    if db.panelMode ~= nil and type(db.panelMode) ~= "string" then db.panelMode = nil end
    if db.planTarget ~= nil then
        if type(db.planTarget) ~= "table" then db.planTarget = nil
        else
            for prof, t in pairs(db.planTarget) do
                if type(t) ~= "number" then db.planTarget[prof] = nil end
            end
        end
    end
    if db.favor ~= nil then
        if type(db.favor) ~= "table" then db.favor = nil
        else
            local f = db.favor
            for _, k in ipairs({ "costs", "wish", "goals" }) do
                if f[k] ~= nil and type(f[k]) ~= "table" then f[k] = {} end
            end
            for id, c in pairs(f.costs or {}) do
                if type(c) ~= "table" or type(c.n) ~= "number" then f.costs[id] = nil end
            end
            if f.currency ~= nil and type(f.currency) ~= "number" then f.currency = nil end
        end
    end
    -- diagnostic log (Diagnose.lua): a damaged log is dropped, never a Lua error
    if db.diag ~= nil and type(db.diag) ~= "table" then db.diag = nil end
    if db.diagExport ~= nil and type(db.diagExport) ~= "string" then db.diagExport = nil end
    if db.autotest ~= nil then
        if type(db.autotest) ~= "table" then db.autotest = nil
        else
            if type(db.autotest.history) ~= "table" then db.autotest.history = nil end
            if db.autotest.last ~= nil and type(db.autotest.last) ~= "string" then db.autotest.last = nil end
        end
    end
    return db
end
ns.DEFAULTS = DEFAULTS

-- the character entry for key (created if missing, repaired if broken)
function ns.InitChar(db, key)
    if type(db.chars) ~= "table" then db.chars = {} end
    local c = db.chars[key]
    if type(c) ~= "table" then c = { known = {}, profs = {} }; db.chars[key] = c end
    CleanChar(c)
    return c
end

---------------------------------------------------------------------------
-- Reputation needed for a recipe item (fa = faction id, fr = standing 4 friendly .. 7 exalted)
---------------------------------------------------------------------------
-- returns: text "Argentumdämmerung – Wohlwollend", met (true/false/nil = unknown)
function ns.RepInfo(fa, fr)
    if not fa or fa == 0 then return nil end
    local name, standing
    local A = ns.API
    if A.GetFactionInfoByID then
        local ok, n, _, st = pcall(A.GetFactionInfoByID, fa)
        if ok and n and n ~= "" then name, standing = n, st end
    end
    -- modern client (WoW Forever, Retail): C_Reputation.GetFactionDataByID; reaction uses the same scale
    -- as the old standingID (1 hated .. 8 exalted)
    if not standing and A.ReputationGetFactionDataByID then
        local ok, d = pcall(A.ReputationGetFactionDataByID, fa)
        if ok and type(d) == "table" and d.name and d.name ~= "" then name, standing = d.name, d.reaction end
    end
    name = name or (ns.Factions and ns.Factions[fa]) or ("Faction " .. fa)
    local need = (fr or 0) + 1                       -- client standing id: 1 hated .. 8 exalted
    local label = _G["FACTION_STANDING_LABEL" .. need] or L["REP_" .. need] or tostring(need)
    local met = nil
    if standing then met = standing >= need end
    return name .. " – " .. label, met
end

function ns.RepLine(fa, fr)
    local text, met = ns.RepInfo(fa, fr)
    if not text then return nil end
    local col = met == true and "40c040" or met == false and "ff6060" or "ffd100"
    return "|cff" .. col .. L.REP_NEEDED .. ": " .. text .. "|r"
end

-- "Name-Realm" of the player. Remembered once it is known; a protected ("secret") name in combat
-- (WoW Forever, Retail) is never used for strings or table keys – the remembered key is returned instead.
local charKey, playerName
local loggedIn = false              -- the key is remembered from PLAYER_LOGIN on (the name is reliable then)
local function IsSecret(v)
    local G = _G.GoldSentinelGame
    return G and G.IsSecret and G.IsSecret(v) or false
end
ns.IsSecret = IsSecret

function ns.CharKeyFrom(name, realm)
    if IsSecret(name) or IsSecret(realm) or type(name) ~= "string" or name == "" then return charKey end
    if type(realm) ~= "string" then realm = "" end
    return name .. "-" .. realm
end

-- "Name-Realm" -> "Name". Character names never contain "-", realms may ("Thrall-Azjol-Nerub"):
-- cut at the FIRST hyphen, exactly like CharsFor and the guild roster (^[^-]+).
function ns.NameFromKey(key)
    if type(key) ~= "string" or key == "" or key == "?-" then return nil end
    return key:match("^([^-]+)") or key
end

function ns.CharKey()
    if charKey then return charKey end
    local name = UnitName("player")
    local key = ns.CharKeyFrom(name, GetRealmName and GetRealmName() or "")
    if key and loggedIn then
        charKey = key
        -- the name straight from UnitName("player") (not cut out of the key)
        if not IsSecret(name) and type(name) == "string" and name ~= "" then playerName = name
        else playerName = ns.NameFromKey(key) end
    end
    return key or "?-"
end

-- player name without realm (remembered, never a protected value)
function ns.PlayerName()
    if not playerName then
        local key = ns.CharKey()
        if not playerName then return ns.NameFromKey(key) end
    end
    return playerName
end

function ns.Char()
    return ns.db and type(ns.db.chars) == "table" and ns.db.chars[ns.CharKey()] or nil
end

-- login: unsupported game versions say so once and stay idle
function ns.OnLogin()
    loggedIn = true
    if not ns.Flavor then
        ns.Print(string.format(L.UNSUPPORTED, ns.Interface or 0))
        return false
    end
    local c = ns.InitChar(ns.db, ns.CharKey())
    local _, class = UnitClass("player")
    c.class = class
    c.faction = UnitFactionGroup("player")
    c.flavor = ns.Flavor
    if ns.Scan then ns.Scan:Init() end
    return true
end

local frame = ns.AddEventFrame(CreateFrame("Frame"), "Core")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON then
        ns.API.Refresh()
        ProfessionSentinelDB = ns.InitDB(ProfessionSentinelDB)
        ns.db = ProfessionSentinelDB
        BuildIndex()
        -- Lua errors of this addon are counted for every player (stays local, sent with the next report)
        if _G.GoldSentinelTest then _G.GoldSentinelTest.TrackErrors(ADDON, ns.VERSION, ProfessionSentinelDB) end
        -- market data network (shared/GoldSentinelMarkt.lua, order MN1): reads along the full AH scans of any addon,
        -- never asks the player, standard on; data in ProfessionSentinelDB.gsMarkt. Without the AH API it stays idle.
        local GM = ns.MarketNet()
        if GM and GM.Attach then pcall(GM.Attach, ADDON, ProfessionSentinelDB) end
    elseif event == "PLAYER_LOGIN" then
        ns.OnLogin()
    end
end)

-- Other addons (AHSentinel, auxForever, Auctionator, Auctioneer, TSM, Enchantrix, TomTom, RaidMaster) are read only
-- through here. The test routine and the test mode put their stand-ins into ns.foreignTest – our OWN table – and never
-- into the other addon's global or its API (review 0.9.42, point 5: other addons must not see test values).
-- ns.foreignTest[name] = false means "not loaded" during a test.
ns.foreignTest = {}
function ns.Foreign(name)
    local v = ns.foreignTest[name]
    if v ~= nil then return v or nil end
    return _G[name]
end

-- market data network (shared/GoldSentinelMarkt.lua, order MN): the shared module (one per client, the newest
-- version wins) – read through ns.Foreign like other addons; the switch "share market data" is ProfessionSentinel's
-- own (db.gsMarktAus, set through GoldSentinelMarkt.SetShare). Off in ONE addon = it reads and shares nothing.
function ns.MarketNet()
    local M = ns.Foreign("GoldSentinelMarkt")
    return type(M) == "table" and M or nil
end
function ns.MarketNetOn() return ns.db ~= nil and not ns.db.gsMarktAus end
function ns.SetMarketNet(on)
    local M = ns.MarketNet()
    if M and M.SetShare and M.hosts and M.hosts[ADDON] then
        pcall(M.SetShare, ADDON, on)
    elseif ns.db then
        ns.db.gsMarktAus = (on == false) or nil
    end
end
-- test report line (MN3): version, on/off, scans read, sent/received, memory
function ns.MarketNetLine()
    local M = ns.MarketNet()
    if not M then return "MARKT-NETZ: nicht geladen" end
    local s = type(M.Stats) == "function" and M.Stats() or {}
    local items = 0
    local g = ns.db and ns.db.gsMarkt
    for _, f in pairs(type(g) == "table" and type(g.f) == "table" and g.f or {}) do
        for _ in pairs(type(f.i) == "table" and f.i or {}) do items = items + 1 end
    end
    return string.format("MARKT-NETZ: v%s · %s · Scans mitgelesen %d · gesendet %d · empfangen %d · Speicher %d Items",
        tostring(M.VERSION), (M.IsShareOn and M.IsShareOn()) and "an" or "aus", tonumber(s.scans) or 0,
        tonumber(s.sent) or 0, tonumber(s.received) or 0, items)
end

-- Test mode and self-test only for the developer (GoldSentinelDev.lua: BattleTag check, same as AHSentinel)
function ns.IsDev()
    local D = _G.GoldSentinelDev
    return D and D.IsDev and D:IsDev() or false
end

local function RequireDev()
    local D = _G.GoldSentinelDev
    if D and D.Require then return D:Require("ProfessionSentinel") end
    return false
end

---------------------------------------------------------------------------
-- Slash commands: ONE table for running them and for the list while typing (order BL, 13 Nov.: BL1).
-- Each entry: key (counter, test), words (German and English, the first one is shown in a German client, the
-- second in an English one), args (optional, locale key of the addition such as "an|aus|bericht"), desc (locale
-- key), dev (developer only, GoldSentinelDev), prefix (the word may go on without a space, as before), run(rest).
-- An empty or unknown word opens or closes the panel (as before).
---------------------------------------------------------------------------
-- "on"/"off" of a switch in the player's language (L.ON / L.OFF, review 0.9.44 point 6)
function ns.OnOffText(on)
    return on and ("|cff40c040" .. L.ON .. "|r") or ("|cffff4040" .. L.OFF .. "|r")
end

local function Toggle(key, label)
    ns.db[key] = not (ns.db[key] ~= false)
    ns.Print(label .. ": " .. ns.OnOffText(ns.db[key]))
end

ns.COMMANDS = {
    { key = "panel", words = { "" }, desc = "CMD_PANEL",
      run = function() if ns.UI then ns.UI:Toggle() end end },
    { key = "heute", words = { "heute", "today" }, desc = "CMD_TODAY",
      run = function()
          ns.db.panelMode = "ranking"
          if ns.UI then
              if ns.UI.IsShown and ns.UI:IsShown() then ns.UI:Refresh() else ns.UI:Toggle() end
          end
      end },
    { key = "line", words = { "line" }, desc = "CMD_LINE",
      run = function()
          ns.db.lifeline = not ns.db.lifeline
          ns.Print(L.LL_OPTION .. ": " .. ns.OnOffText(ns.db.lifeline))
          if ns.Lifeline then ns.Lifeline.RefreshBlizzard() end
          if ns.UI then ns.UI:Refresh() end
      end },
    { key = "alarm", words = { "alarm" }, desc = "CMD_ALARM",
      run = function() Toggle("recipeAlert", L.ALERT_OPTION) end },
    { key = "ziel", words = { "ziel", "goal" }, desc = "CMD_GOAL",
      run = function() if ns.Disenchant then ns.Disenchant.AskGoal() end end },
    { key = "kisten", words = { "kisten", "crates" }, desc = "CMD_CRATES",
      run = function()
          if ns.Favor and ns.Favor.Active() then ns.Favor.ToggleTodayCrates() else ns.Print(L.FAVOR_ONLY_FOREVER) end
      end },
    { key = "minimap", words = { "minimap" }, desc = "CMD_MINIMAP",
      run = function() if ns.Minimap then ns.Minimap.Toggle() end end },
    { key = "menge", words = { "menge", "amount" }, desc = "CMD_AMOUNT",
      run = function() if ns.MerchantQty then ns.MerchantQty.Toggle() end end },
    { key = "markt", words = { "markt", "market" }, desc = "CMD_MARKET",
      run = function()
          ns.SetMarketNet(not ns.MarketNetOn())
          ns.Print(L.MN_OPTION .. ": " .. ns.OnOffText(ns.MarketNetOn()))
      end },
    { key = "protokoll", words = { "protokoll", "protocol" }, desc = "CMD_PROTOCOL",
      run = function() if ns.Diagnose then ns.Diagnose.Show() end end },
    { key = "spieltest", words = { "spieltest", "playtest" }, args = "CMD_ARGS_PLAYTEST", desc = "CMD_PLAYTEST", prefix = true,
      run = function(rest) if ns.Spieltest then ns.Spieltest.Command(rest or "") end end },
    { key = "hilfe", words = { "hilfe", "help", "?" }, desc = "CMD_HELP",
      run = function() ns.Print(ns.IsDev() and L.TEST_HELP or L.HELP) end },
    -- developer only (GoldSentinelDev: BattleTag check)
    { key = "test", words = { "test" }, desc = "CMD_TEST", dev = true,
      run = function() if ns.TestMode and RequireDev() then ns.TestMode:Toggle() end end },
    { key = "selftest", words = { "selftest" }, desc = "CMD_SELFTEST", dev = true,
      run = function()
          -- same machine as the test routine: the result is reported through GoldSentinelTest as well
          if RequireDev() then
              if ns.TestRoutine then ns.TestRoutine:Command("selftest") elseif ns.TestMode then ns.TestMode:RunSelfTest(true) end
          end
      end },
    { key = "autotest", words = { "autotest" }, args = "CMD_ARGS_AUTOTEST", desc = "CMD_AUTOTEST", dev = true,
      run = function(rest) if ns.AutoTest and RequireDev() then ns.AutoTest:Command(rest ~= "" and rest or nil) end end },
    { key = "testroutine", words = { "testroutine", "tr" }, args = "CMD_ARGS_TESTROUTINE", desc = "CMD_TESTROUTINE", dev = true,
      run = function(rest) if ns.TestRoutine and RequireDev() then ns.TestRoutine:Command(rest ~= "" and rest or nil) end end },
}
ns.COMMAND_PREFIXES = { "/ps", "/professionsentinel" }
ns.COMMAND_FRESH = 10          -- a selection in the list counts for 10 seconds (BL3)

-- the command of a typed word (exact, or "spieltestan" style for prefix commands); nil = none
function ns.FindCommand(word)
    word = word or ""
    for _, c in ipairs(ns.COMMANDS) do
        for _, w in ipairs(c.words) do
            if word == w then return c end
        end
    end
    for _, c in ipairs(ns.COMMANDS) do
        if c.prefix then
            for _, w in ipairs(c.words) do
                if w ~= "" and word:sub(1, #w) == w then return c end
            end
        end
    end
    return nil
end

-- usage counter per command (saved variables) – the most used commands stand on top of the list (BL2)
local function CountUse(key)
    if not ns.db then return end
    ns.db.cmdCount = type(ns.db.cmdCount) == "table" and ns.db.cmdCount or {}
    ns.db.cmdCount[key] = (tonumber(ns.db.cmdCount[key]) or 0) + 1
end

-- the word shown for a command in this client's language (German first word, English second if there is one)
function ns.CommandWord(c)
    if not ns.isGerman and c.words[2] and c.words[2] ~= "?" then return c.words[2] end
    return c.words[1]
end

-- the list while typing (BL1/BL2): every command whose German or English word starts with the typed text,
-- developer commands only for the developer; most used first, then in table order.
-- Returns { { cmd, word, args, desc, uses } }
function ns.CommandList(typed, isDev)
    typed = (typed or ""):lower():match("^%s*(%S*)") or ""
    if isDev == nil then isDev = ns.IsDev() end
    local counts = ns.db and type(ns.db.cmdCount) == "table" and ns.db.cmdCount or {}
    local out = {}
    for i, c in ipairs(ns.COMMANDS) do
        if c.key ~= "panel" and (isDev or not c.dev) then
            local hit
            for _, w in ipairs(c.words) do
                if w ~= "" and w:sub(1, #typed) == typed then hit = true end
            end
            if hit then
                out[#out + 1] = { cmd = c, word = ns.CommandWord(c), args = c.args and L[c.args] or nil,
                    desc = L[c.desc] or c.desc, uses = tonumber(counts[c.key]) or 0, order = i }
            end
        end
    end
    table.sort(out, function(a, b)
        if a.uses ~= b.uses then return a.uses > b.uses end
        return a.order < b.order
    end)
    return out
end

-- a command chosen in the list (click, arrow keys, Tab) – Enter then runs it (BL3); the chat box is never written
ns.commandSelection = nil
function ns.SelectCommand(key, now)
    ns.commandSelection = key and { key = key, t = now or (GetTime and GetTime()) or 0 } or nil
end

-- the selected command, if it is fresh (≤ 10 s) and fits the typed beginning
function ns.SelectedCommand(word, now)
    local s = ns.commandSelection
    if not s then return nil end
    now = now or (GetTime and GetTime()) or 0
    if now - s.t > ns.COMMAND_FRESH or now < s.t then return nil end
    for _, c in ipairs(ns.COMMANDS) do
        if c.key == s.key then
            for _, w in ipairs(c.words) do
                if w ~= "" and w:sub(1, #(word or "")) == (word or "") then return c end
            end
        end
    end
    return nil
end

SLASH_PROFESSIONSENTINEL1 = "/ps"
SLASH_PROFESSIONSENTINEL2 = "/professionsentinel"
SlashCmdList.PROFESSIONSENTINEL = function(msg)
    msg = (msg or ""):lower():match("^%s*(.-)%s*$")
    if not ns.Flavor then
        ns.Print(string.format(L.UNSUPPORTED, ns.Interface or 0))
        return
    end
    local word, rest = msg:match("^(%S*)%s*(.-)$")
    word, rest = word or "", rest or ""
    -- a fresh selection from the list wins over the unfinished word ("/ps pro" + chosen "protokoll")
    local c = ns.SelectedCommand(word)
    ns.SelectCommand(nil)
    if c and c.words[1] ~= word and not (c.words[2] == word) then rest = "" end
    if not c then
        c = ns.FindCommand(word)
        -- prefix commands without a space ("spieltestan"): what follows the word is the rest, as before
        if c and c.prefix and not (c.words[1] == word or c.words[2] == word) then
            for _, w in ipairs(c.words) do
                if word:sub(1, #w) == w then rest = (word:sub(#w + 1) .. " " .. rest):match("^%s*(.-)%s*$"); break end
            end
        end
    end
    if c and c.dev and not ns.IsDev() then c = nil end
    -- unknown words and developer commands of other players: the panel as before (RequireDev says why)
    if not c then
        if word == "test" or word == "selftest" or word == "autotest" or word == "testroutine" or word == "tr" then
            RequireDev()
            return
        end
        c = ns.COMMANDS[1]
    end
    CountUse(c.key)
    c.run(rest)
end
