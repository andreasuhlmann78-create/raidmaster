if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - API.lua
-- Öffentliche Schnittstelle AHSentinel.API, Version 1 (Vertrag: raidmaster shared/wissen/schnittstelle-ahsentinel-api.md,
-- Anweisung der Prüf-Sitzung 9. Nov. 16:50). Nur Weiterleitungen auf vorhandene Funktionen.
--   * global AHSentinel mit Feld API; Alias AHAnalyzerPro.API (dieselbe Tabelle)
--   * jede Funktion wirft nie einen Lua-Fehler (pcall), nil wenn nichts bekannt; Beträge in Kupfer (ganze Zahlen)
--   * neue Funktionen nur hinzufügen, nie Bedeutung oder Rückgabewerte ändern (sonst Version 2 mit neuem Feld)
-- Die alten öffentlichen Funktionen (RealPrice, RealValue, AuctionFee, AHFee, ForeverAuctionFee, GetMarketValue,
-- GetCurrent) bleiben unverändert.
-- ============================================================
local A = AHAnalyzerPro

local API = { version = 1 }
-- Rückwärts: bis 0.65.49 war AHAnalyzerPro:API(name) eine interne Hilfsfunktion (jetzt A:Global). Wer sie noch so
-- aufruft, bekommt weiter dasselbe Ergebnis.
setmetatable(API, { __call = function(_, self, name) return A:Global(name) end })
A.API = API
_G.AHSentinel = _G.AHSentinel or {}
_G.AHSentinel.API = API

local function Int(v) return type(v) == "number" and math.floor(v + 0.5) or nil end

-- sicher aufrufen: nie ein Fehler, nil bei Fehler
local function Safe(fn)
    return function(...)
        local r = { pcall(fn, ...) }
        if not r[1] then return nil end
        return unpack(r, 2, table.maxn(r))
    end
end

-- Preis je Stück, Quelle ("scan" / "market" / "vendor"), Alter in Sekunden
API.Price = Safe(function(itemID)
    if not itemID then return nil end
    local v, info = A:RealPrice(itemID)
    if v then
        local age = (info and info.currentTime) and math.max(0, time() - info.currentTime) or nil
        -- "scan" nur, wenn der Wert wirklich aus dem letzten Scan stammt (Ausreisser-Ersatz durch den Median: "market")
        -- Nachprüfung 08:40 Punkt 3: "scan" nur, wenn der Preis wirklich im letzten Scan war (inScan)
        return Int(v), (info and info.source == "ah" and info.inScan) and "scan" or "market", age
    end
    local vendor = A:GetVendorPrice(itemID)
    if type(vendor) == "number" and vendor > 0 then return Int(vendor), "vendor", nil end
    return nil
end)

-- Netto-Erlös gesamt für qty Stück (5 % bzw. 15 % neutral, erwarteter Einzahlungsverlust, mindestens Händlerwert);
-- 2. Wert { gross, cut, depositRisk, vendorWins }
API.NetSale = Safe(function(itemID, qty)
    if not itemID then return nil end
    qty = math.max(1, math.floor(tonumber(qty) or 1))
    local net, unit, info, vendorWins = A:RealValue(itemID, qty)
    if not net then return nil end
    local gross = unit and unit * qty or net
    local cut = unit and A:SaleFee(itemID, unit, qty) or 0
    local risk = (info and info.relistCost) or 0
    return Int(net), { gross = Int(gross), cut = Int(cut), depositRisk = Int(risk), vendorWins = vendorWins and true or false }
end)

-- Einzahlung (Blizzard-Wert, sonst Formel nach Regelwerk, Minimum gemessen statt fest)
API.Deposit = Safe(function(itemID, qty, hours)
    if not itemID then return nil end
    qty = math.max(1, math.floor(tonumber(qty) or 1))
    local size = math.max(1, A:AuctionSize(itemID, qty) or 1)
    local auctions = math.max(1, math.ceil(qty / size))
    local dep, src = A:ListingDeposit(itemID, qty, hours or 24, auctions)
    if src ~= "blizzard" then
        local vendor = A:GetVendorPrice(itemID)
        if not (type(vendor) == "number" and vendor > 0) then return nil end   -- unbekannt: kein Händlerpreis
    end
    return Int(dep)
end)

API.CutPct = Safe(function() return A:CutPct() end)

-- Kosten gesamt über den günstigsten Weg (wie Gewinn-Fenster, Cr:BestUnit); 2. Wert Liste je Zutat
API.MaterialCost = Safe(function(itemID, qty)
    local Cr = A.Crafting
    if not (itemID and Cr and Cr.RecipeIndex) then return nil end
    local rec = Cr:RecipeIndex(nil, true)[itemID]
    if not rec then return nil end
    qty = math.max(1, math.floor(tonumber(qty) or 1))
    local crafts = math.ceil(qty / math.max(rec.made or 1, 1))
    local total, list = 0, {}
    for _, re in ipairs(rec.reagents or {}) do
        local unit, how = Cr:BestUnit(re[1], 1)
        if not unit then return nil end
        local need = crafts * re[2]
        local cost = Int(unit * need)
        total = total + cost
        list[#list + 1] = { itemID = re[1], qty = need, source = how or "ah", cost = cost }
    end
    return Int(total), list
end)

-- Entzaubern: Wert brutto je Entzauberung, netto, Anzahl eigene Entzauberungen, Quelle ("own" / "table")
API.DisenchantValue = Safe(function(itemID)
    local D = A.Disenchant
    if not (itemID and D and D.Prior and D:Prior(itemID)) then return nil end
    local v, net, _, basis, n = D:DealValue(itemID)
    if not v then return nil end
    return Int(v), Int(net), n or 0, basis == "actual" and "own" or "table"
end)

-- bester Weg für ein Stück: "sell" oder "disenchant", Netto-Wert dieses Wegs
API.BestWay = Safe(function(itemID)
    if not itemID then return nil end
    local sale = API.NetSale(itemID, 1)
    local _, de = API.DisenchantValue(itemID)
    if de and (not sale or de > sale) then return "disenchant", de end
    if sale then return "sell", sale end
    return nil
end)

-- Verkaufsdauer: "fast" / "slow" / "rare" / nil, Median-Stunden bis Verkauf, Absatz pro Tag am Markt
local SPEED = { schnell = "fast", langsam = "slow", kaum = "rare" }
API.SellSpeed = Safe(function(itemID)
    if not itemID then return nil end
    local Le = A.Ledger
    local r = Le and Le.SellSpeed and Le:SellSpeed(itemID)
    local okL, liq = pcall(A.GetLiquidity, A, itemID)
    local perDay = okL and liq and liq.perDay or nil
    if not r and not perDay then return nil end
    return r and SPEED[r.speed] or nil, r and r.hours or nil, perDay
end)

-- eingestellter Mindestgewinn in % (Einstellung "Mindestrendite", DEBuy:MinRoi, Standard 20) - dieselbe Grenze wie
-- "Lohnt bis" im Tooltip und der automatische Mindestpreis (offener Punkt 2a)
API.MinProfitPct = Safe(function()
    local Se = A.Seller
    local p = (Se and Se.MinProfitPct) and Se:MinProfitPct() or 0.20
    return math.floor(p * 100 + 0.5)
end)

-- Gold pro Stunde (H9, Zeitraum 30 Tage): Kupfer pro Stunde und gemessene Sekunden; nil, solange zu wenig gemessen
local GPH = { craft = "craft", disenchant = "de", flip = "flip" }
API.GoldPerHour = Safe(function(kind)
    local Act = A.Activity
    if not Act then return nil end
    local rows, total = Act:Report("30")
    local r
    if kind == "all" or kind == nil then r = total
    elseif kind == "ah" then
        local f, w = rows.flip, rows.raw
        r = { profit = f.profit + w.profit, seconds = (f.seconds or 0) + (w.seconds or 0) }
        r.perHour = r.seconds >= Act.MIN_SECONDS and (r.profit / r.seconds * 3600) or nil
    elseif GPH[kind] then r = rows[GPH[kind]]
    end
    if not (r and r.perHour) then return nil end
    return Int(r.perHour), Int(r.seconds)
end)

-- letzter Scan: Zeitpunkt (time()), Anzahl Items
API.LastScan = Safe(function()
    local db = A.db
    if not db or (db.lastScanTime or 0) == 0 then return nil end
    if API._countVersion ~= A.priceVersion or not API._count then
        local n = 0
        for _ in pairs(db.marketData or {}) do n = n + 1 end
        API._count, API._countVersion = n, A.priceVersion
    end
    return db.lastScanTime, API._count
end)

-- ------------------------------------------------------------
-- Ereignis: Subscribe(fn) -> fn(reason) mit "scan", "ledger", "settings"; gedrosselt (höchstens einmal je 2 s je Grund)
-- ------------------------------------------------------------
API.subscribers = {}
API.THROTTLE = 2
local pending = {}
local scheduled = false
API.Subscribe = Safe(function(fn)
    if type(fn) ~= "function" then return nil end
    API.subscribers[#API.subscribers + 1] = fn
    return true
end)

function API.Flush()
    scheduled = false
    local reasons = {}
    for _, r in ipairs({ "scan", "ledger", "settings" }) do
        if pending[r] then reasons[#reasons + 1] = r; pending[r] = nil end
    end
    for _, r in ipairs(reasons) do
        for _, fn in ipairs(API.subscribers) do pcall(fn, r) end
    end
end

function API.Notify(reason)
    if #API.subscribers == 0 then return end
    pending[reason] = true
    if scheduled then return end
    scheduled = true
    if C_Timer and C_Timer.After then C_Timer.After(API.THROTTLE, API.Flush) else API.Flush() end
end

A:On("SCAN_FINISHED", function() API.Notify("scan") end)
A:On("LEDGER_CHANGED", function() API.Notify("ledger") end)
A:On("SETTINGS_CHANGED", function() API.Notify("settings") end)
