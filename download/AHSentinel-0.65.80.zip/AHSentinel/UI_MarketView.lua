if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Stufe 3: Reiter "Markt" ersetzt "Heute tun" (Anweisung der Prüf-Sitzung 10.11. 10:45, Entscheide des
-- Nutzers: die Liste aller Items "braucht niemand", Daten bleiben im Hintergrund; so einfach wie möglich)
--
-- M1 Eine Leiste mit 6 Ansichten: Heute (das bisherige "Heute tun") / Flippen / Händler / Lücken / Überfüllt / Trends.
--    Jede Ansicht: eine Erklärzeile, höchstens 20 Zeilen, je Zeile eine Zahl, Sicherheit als Farbe, ein Knopf.
-- M2 Die Liste aller Items ist aus der Anzeige verschwunden (Reiter "Alle Preise" ausgeblendet, Daten bleiben).
--    Nachschlagen über das Suchfeld oben.
-- M3 Detailbereich rechts (Klick auf eine Zeile oder Suche): Preis- und Angebotsverlauf, Preisleiter, eigene
--    Geschichte, gelernte Preisgrenzen, EINE Empfehlung mit Begründung, Knöpfe Watchlist / Einkaufsliste / Sniper.
-- M4 Lage-Zeile: Preis-Index aus einem Korb typischer Waren.
-- M5 Nachschub (Herstellen) bleibt in "Heute" (ProfessionSentinel oder eigene Rezeptliste).
-- M6 Einzige neue Option: "Standard-Ansicht".
--
-- NICHTS GEHT VERLOREN: Zeilen und Knöpfe von "Heute tun" (A.Today: Prüfen -> Kaufen -> Einstellen, nie ohne Klick),
-- QuickBuy/QuickSell (Zeilen oben), /ahs heute, UI:ShowToday. Rechnen in Portionen (A:Job, A:Pause).
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C

local MV = {}
A.MarketView = MV

MV.VIEWS = { "heute", "flip", "vendor", "gaps", "crowded", "trends" }
MV.LABELS = { heute = "Heute", flip = "Flippen", vendor = "Händler", gaps = "Lücken", crowded = "Überfüllt", trends = "Trends" }
MV.EXPLAIN = {
    heute = "Deine Sachen zuerst (einstellen, neu einstellen, entzaubern, herstellen), darunter die besten Chancen. Der Knopf macht den nächsten Schritt.",
    flip = "Unter deiner Kaufgrenze kaufen und wieder einstellen - sortiert nach Gewinn je Gold Einsatz und Tag.",
    vendor = "Sofortkauf unter dem Händlerpreis: kaufen und beim Händler verkaufen - sicherer Gewinn.",
    gaps = "Wenig Angebot, stetiger Absatz, Preis steigt - gute Zeit zum Einstellen. Was du im Lager hast, steht oben.",
    crowded = "Viel mehr Angebot als Absatz: lieber nicht einstellen - jede Rückkehr kostet die Einzahlung.",
    trends = "Echte Bewegungen über 7 und 30 Tage (nur wenn stabil). Fallende Leveling-Waren stehen oben.",
}
MV.MAX_ROWS = 20
MV.DETAIL_W = 300
-- M4 Korb typischer Waren (Stoffe, Erze, Kräuter, Staub/Essenzen, Leder) - nur die, die im Markt vorkommen
MV.BASKET = { 2589, 2592, 4306, 4338, 14047, 2770, 2771, 2772, 3858, 10620, 2447, 765, 785, 2450, 3820, 3821, 3818,
    10940, 11083, 11137, 11176, 16204, 10938, 10998, 11082, 2318, 2319, 4234, 4304, 8170 }
local LEVELING = { cloth = true, leather = true, metal = true, herb = true }

function MV:DefaultView()
    local v = A.db and A.db.settings and A.db.settings.marketView
    for _, x in ipairs(self.VIEWS) do if x == v then return v end end
    return "heute"
end

-- ------------------------------------------------------------
-- Daten der Ansichten (in Portionen gerechnet; Zeilen im Format von "Heute tun", damit der Knopf gleich arbeitet)
-- ------------------------------------------------------------
local function Fresh(t) return t and time() - t <= 2 * 86400 end

-- Sicherheit: "hoch" (grün) / "mittel" (gelb) / "niedrig" (grau)
function MV:Safety(itemID)
    local ok, reliable, l = pcall(A.IsReliable, A, itemID)
    if not ok then return "niedrig" end
    local conf = l and l.conf
    if reliable and conf == "hoch" then return "hoch" end
    if reliable then return "mittel" end
    return "niedrig"
end

function MV:BuildFlip()
    local out = {}
    local X = A.Extras
    if not (X and X.GetFlipDeals) then return out end
    local okF, flips = A:PCall(X.GetFlipDeals, X, 50)
    if not okF then return out end
    local Ln = A.Learn
    local money = GetMoney and GetMoney() or 0
    local cap = money * ((A.Comfort and A.Comfort.TODAY_ITEM_SHARE) or 0.2)
    for _, d in ipairs(flips) do
        A:Pause()
        local ok = A:IsReliable(d.itemID)
        if ok and Ln and Ln.On and Ln:On() and d.ref then
            local lim = Ln:BuyLimit(math.floor(d.ref * (1 - A:CutPct())), "e")
            if lim and d.price > lim then ok = false end
        end
        if ok then
            local okA, kind = pcall(self.Advice, self, d.itemID)        -- H3: Liste = Detail
            ok = okA and kind == "buy"
        end
        if ok then
            local l = A:GetLiquidity(d.itemID) or {}
            local perDay = l.perDay or 0
            local qty = math.max(1, math.min(math.floor(math.max(1, perDay)), d.quantity or 1))
            if d.qtyMax then qty = math.min(qty, d.qtyMax) end
            if d.price > 0 then qty = math.max(1, math.min(qty, math.floor(cap / d.price))) end
            local score = (d.profit / math.max(1, d.price)) * math.min(1, perDay)
            out[#out + 1] = { kind = "flip", itemID = d.itemID, maxUnit = d.price, qty = qty, unit = A:GetSalePrice(d.itemID),
                gold = math.floor(d.profit * qty), score = score, safety = self:Safety(d.itemID),
                text = string.format(L["Kaufe %dx %s bis %s, wieder einstellen um %s (verkauft sich ~%s/Tag)"], qty, d.name or A:GetItemName(d.itemID),
                    A:FormatMoney(d.price), A:FormatMoney(d.ref), string.format("%.1f", perDay)),
                where = L["Einkauf"], run = function() A.UI:OpenBuyFor(d.itemID) end }
        end
    end
    table.sort(out, function(a, b) return a.score > b.score end)
    self.reason.flip = L["Kein Flip unter deiner Kaufgrenze (realistischer Wiederverkauf aus Angebot und Absatz)."]
    return out
end

function MV:BuildVendor()
    local out = {}
    local okV, list = A:PCall(A.VendorFlipOffers, A, nil, self.MAX_ROWS)
    if not okV then return out end
    for _, d in ipairs(list) do
        out[#out + 1] = { kind = "vendor", itemID = d.itemID, maxUnit = d.vendor - 1, qty = d.qty, vendor = d.vendor,
            gold = math.floor(d.profit or ((d.vendor - d.price) * d.qty)), safety = "hoch",
            text = string.format(L["Unter Händlerpreis: kaufen und beim Händler verkaufen - %dx %s ab %s, Händler zahlt %s"],
                d.qty, d.name or A:GetItemName(d.itemID), A:FormatMoney(d.price), A:FormatMoney(d.vendor)),
            where = L["Einkauf"], run = function() A.UI:OpenBuyFor(d.itemID) end }
    end
    table.sort(out, function(a, b) return a.gold > b.gold end)
    self.reason.vendor = L["Kein Sofortkauf unter dem Händlerpreis im letzten Scan."]
    return out
end

-- mittlere Angebotsmenge der letzten 7 Tage (aus dem Preisverlauf)
local function AvgQty(itemID, days)
    local h = A:GetHistory(itemID)
    local from = time() - (days or 7) * 86400
    local sum, n = 0, 0
    for i = #h, 1, -1 do
        local e = h[i]
        if e.t < from then break end
        if e.q then sum, n = sum + e.q, n + 1 end
    end
    return n >= 2 and sum / n or nil, n
end

local function PerDay(itemID)
    local VS = A.FullScan
    if VS and VS.MeasuredRate then
        local ok, m = pcall(VS.MeasuredRate, VS, itemID)
        if ok and m then return m, true end
    end
    local ok, l = pcall(A.GetLiquidity, A, itemID)
    return ok and l and l.perDay or nil, false
end

function MV:BuildGaps()
    local out = {}
    local db = A.db
    if not db then return out end
    local Se = A.Seller
    for itemID in pairs(db.marketData) do
        A:Pause()
        local price, qty, t = A:GetCurrent(itemID)
        if price and qty and Fresh(t) and A:IsReliable(itemID) then
            local avg = AvgQty(itemID, 7)
            if avg and qty < avg * 0.5 then
                local trend = A:GetTrend(itemID, 7 * 86400)
                local perDay, measured = PerDay(itemID)
                if trend and trend > 0 and perDay and perDay >= 1 then
                    local have = Se and Se:CountInBags(itemID) or 0
                    local r = { itemID = itemID, gold = math.floor(perDay * price), have = have,
                        num = "+" .. math.floor(trend + 0.5) .. " %", safety = measured and "hoch" or "niedrig",
                        text = string.format(L["Wenig Angebot (%d statt Ø %d), Absatz ~%s/Tag%s, Preis steigt"], qty, math.floor(avg + 0.5),
                            string.format("%.1f", perDay), " (" .. (measured and L["gemessen"] or L["geschätzt"]) .. ")") }
                    if have > 0 then
                        r.kind, r.unit, r.count = "sell", A:GetSalePrice(itemID) or price, have
                        r.text = r.text .. " · " .. string.format(L["%d in der Tasche"], have)
                    else r.kind = "lookup" end
                    out[#out + 1] = r
                end
            end
        end
    end
    table.sort(out, function(a, b)
        if (a.have > 0) ~= (b.have > 0) then return a.have > 0 end
        return a.gold > b.gold
    end)
    self.reason.gaps = L["Keine Ware mit wenig Angebot (unter halbem 7-Tage-Ø), Absatz ab 1/Tag und steigendem Preis."]
    return out
end

-- H6 (Befund 12:55): nicht nur auf GEMESSENEN Absatz warten - bis dahin mit dem geschätzten rechnen (grau, "geschätzt").
-- Kandidaten: Taschen, eigene Auktionen, gehandelte/beobachtete Items und geflutete Waren des letzten Scans.
MV.CROWDED_DAYS = 2           -- Warteschlange länger als so viele Tage Absatz = überfüllt
MV.reason = {}
function MV:CrowdedCandidates()
    local Se = A.Seller
    local seen, cands = {}, {}
    local function add(id, n) if id and not seen[id] then seen[id] = true; cands[#cands + 1] = { id, n or 1 } end end
    local okB, bag = false, {}
    if Se and Se.GetBagItems then okB, bag = A:PCall(Se.GetBagItems, Se, true) end
    for _, e in ipairs(okB and bag or {}) do add(e.itemID, e.count) end
    for _, o in ipairs(Se and Se.owned or {}) do if not o.sold then add(o.itemID, o.qty) end end
    local Fc = A.Forecast
    if Fc and Fc.RelevantItems then
        local ok, set = pcall(Fc.RelevantItems, Fc)
        if ok then for id in pairs(set) do add(id, 1) end end
    end
    for id in pairs(A.db and A.db.marketData or {}) do
        A:Pause()
        if not seen[id] then
            local ok, why = pcall(A.FlipBlocked, A, id)
            if ok and why == "flood" then add(id, 1) end
        end
    end
    return cands
end

function MV:BuildCrowded()
    local out = {}
    for _, c in ipairs(self:CrowdedCandidates()) do
        A:Pause()
        local itemID, have = c[1], math.max(1, c[2] or 1)
        local ok, v = pcall(A.SellOutlook, A, itemID, have)
        local wait = ok and v and v.queue and v.perDay and v.perDay > 0 and (v.queue + have) / v.perDay or nil
        if ok and v and v.queue and (v.rare or (wait and wait > self.CROWDED_DAYS)) then
            local okL, loss = pcall(A.ExpectedDepositLoss, A, itemID, have, A.RELIST_MAX)
            local measured = v.perDaySource == "measured"
            local days = wait and math.floor(wait + 0.5) or nil
            out[#out + 1] = { kind = "lookup", itemID = itemID, warn = true, gold = math.floor((okL and loss) or 0), wait = wait or 9999,
                num = days and string.format(L["~%d Tage"], math.max(1, math.min(days, 999))) or L["kaum"],
                safety = measured and "mittel" or "niedrig",
                text = string.format(L["Nicht einstellen: %d im Angebot, Absatz ~%s/Tag - Einzahlungsrisiko %s"], v.queue,
                    v.perDay and string.format("%.1f", v.perDay) or "0", A:FormatMoney((okL and loss) or 0))
                    .. (measured and "" or (" (" .. L["geschätzt"] .. ")")) }
        end
    end
    table.sort(out, function(a, b) return (a.wait or 0) > (b.wait or 0) end)
    self.reason.crowded = L["Keines deiner Items (Taschen, Auktionen, gehandelt, beobachtet) ist überfüllt."]
    return out
end

-- Tage Preisverlauf (ältester Scan-Eintrag im Protokoll)
function MV:HistoryDays()
    local log = A.db and A.db.scanLog or {}
    local first = log[1] and log[1].t
    if not first then return 0 end
    return math.floor((time() - first) / 86400)
end

function MV:BuildTrends()
    local out = {}
    local db = A.db
    if not db then return out end
    local Fc = A.Forecast
    for itemID in pairs(db.marketData) do
        A:Pause()
        local _, _, t = A:GetCurrent(itemID)
        if Fresh(t) and A:IsReliable(itemID) then
            local t7, t30, t3 = A:GetTrend(itemID, 7 * 86400), A:GetTrend(itemID, 30 * 86400), A:GetTrend(itemID, 3 * 86400)
            -- stabil: 3 und 7 Tage (und 30 Tage, wenn es den Verlauf schon gibt) in dieselbe Richtung, mind. 10 %
            local stable = t7 and t3 and math.abs(t7) >= 10 and (t3 > 0) == (t7 > 0)
            if stable and t30 then stable = math.abs(t30) >= 10 and (t30 > 0) == (t7 > 0) and math.abs(t30) < 500 end
            if stable and math.abs(t7) < 500 then
                local g = Fc and Fc:Group(itemID) or "misc"
                local ref = t30 or t7
                local levelFall = LEVELING[g] and ref < 0
                out[#out + 1] = { kind = "lookup", itemID = itemID, gold = math.floor(math.abs(ref)), levelFall = levelFall,
                    num = t30 and string.format("%+d %% / %+d %%", math.floor(t7 + 0.5), math.floor(t30 + 0.5)) or string.format("%+d %%", math.floor(t7 + 0.5)),
                    safety = t30 and self:Safety(itemID) or "niedrig", warn = ref < 0,
                    text = t30 and string.format(levelFall and L["Leveling-Ware fällt: 7 Tage %+d %%, 30 Tage %+d %%"] or L["7 Tage %+d %%, 30 Tage %+d %%"],
                        math.floor(t7 + 0.5), math.floor(t30 + 0.5))
                        or string.format(L["7 Tage %+d %% (30 Tage noch nicht da)"], math.floor(t7 + 0.5)) }
            end
        end
    end
    table.sort(out, function(a, b)
        if a.levelFall ~= b.levelFall then return a.levelFall and true or false end
        return a.gold > b.gold
    end)
    local days = self:HistoryDays()
    self.reason.trends = days < 7 and string.format(L["Trends: braucht 7 Tage Verlauf, noch %d Tage."], 7 - days)
        or L["Keine stabile Bewegung über 3 und 7 Tage (mindestens 10 %)."]
    return out
end

MV.BUILDERS = { flip = "BuildFlip", vendor = "BuildVendor", gaps = "BuildGaps", crowded = "BuildCrowded", trends = "BuildTrends" }
MV.cache = {}

function MV:Version()
    return table.concat({ A:DataVersion(), math.floor(time() / 300), A.Seller and A.Seller.owned and #A.Seller.owned or 0 }, "|")
end

-- Zeilen einer Ansicht (aus dem Zwischenspeicher; sonst im Hintergrund rechnen, onDone ruft danach auf)
function MV:Rows(view, fresh, onDone)
    if view == "heute" then
        local list, capital, money = A.Comfort:TodayActions(10, fresh)
        return list or {}, false, capital, money
    end
    local ver = self:Version()
    local c = self.cache[view]
    if c and c.version == ver and not fresh then return c.rows, false end
    if not A:HasJob("market:" .. view) then
        A:Job("market:" .. view, function()
            local ok, rows = A:PCall(MV[MV.BUILDERS[view]], MV)
            if not ok and A.ReportOnce then A:ReportOnce("MarketView:" .. view, "MarketView", tostring(rows)) end
            rows = ok and rows or {}
            while #rows > MV.MAX_ROWS do table.remove(rows) end
            MV.cache[view] = { version = ver, rows = rows }
            if onDone then pcall(onDone) end
        end)
    end
    return c and c.rows or {}, true
end

-- ------------------------------------------------------------
-- M4 Lage: Preis-Index aus dem Korb (Median der Verhältnisse jetzt / vor 1 bzw. 7 Tagen)
-- ------------------------------------------------------------
local function PriceAt(itemID, t)
    local h = A:GetHistory(itemID)
    for i = #h, 1, -1 do if h[i].t <= t and h[i].p and h[i].p > 0 and not h[i].u then return h[i].p end end
    return nil
end
function MV:Index(now)
    now = now or time()
    local r1, r7 = {}, {}
    for _, id in ipairs(self.BASKET) do
        local cur = A:GetCurrent(id)
        if cur and cur > 0 then
            local p1, p7 = PriceAt(id, now - 86400), PriceAt(id, now - 7 * 86400)
            if p1 then r1[#r1 + 1] = cur / p1 end
            if p7 then r7[#r7 + 1] = cur / p7 end
        end
    end
    local function med(t) if #t < 3 then return nil end table.sort(t); return t[math.floor((#t + 1) / 2)] end
    local d1, d7 = med(r1), med(r7)
    return d1 and (d1 - 1) * 100 or nil, d7 and (d7 - 1) * 100 or nil, #r1
end
function MV:IndexText()
    local d1, d7 = self:Index()
    if not d1 then return L["Markt heute: noch zu wenig Daten (Korb typischer Waren)"] end
    local s = string.format(L["Markt heute %+.0f %%"], d1)
    if d7 then s = s .. " " .. string.format(L["(7 Tage %+.0f %%)"], d7) end
    return s
end

-- ------------------------------------------------------------
-- M3 Detail: eine Empfehlung mit Begründung
-- ------------------------------------------------------------
function MV:Advice(itemID)
    local Se, Ln = A.Seller, A.Learn
    local have = Se and Se:CountInBags(itemID) or 0
    local price = A:GetCurrent(itemID)
    if have > 0 then
        local ok, v = pcall(A.SellOutlook, A, itemID, have)
        if ok and v and (v.rare or (v.wait and v.wait > A.RARE_DAYS)) then
            local vendor = A:GetVendorPrice(itemID)
            return "hold", L["liegen lassen"], string.format(L["%d im Angebot, Absatz zu klein - jede Rückkehr kostet die Einzahlung%s."], v.queue or 0,
                (type(vendor) == "number" and vendor > 0) and (" (" .. L["Händler"] .. " " .. A:FormatMoney(vendor) .. ")") or "")
        end
        local okS, p = pcall(Se.Suggest, Se, itemID)
        p = okS and p or A:RealPrice(itemID)
        if p then
            return "sell", string.format(L["einstellen für %s"], A:FormatMoney(p)),
                string.format(L["%d in der Tasche, verkauft sich ~%s/Tag"], have, (ok and v and v.perDay) and string.format("%.1f", v.perDay) or "?")
        end
    end
    local Fc = A.Forecast
    if Fc and price then
        local okP, way, ev = pcall(Fc.BuyPrediction, Fc, itemID)
        -- Flip (Wiederverkauf): dieselbe Prüfung wie Heute/Flippen (A:FlipCheck) - Liste und Detail nie widersprüchlich
        local okF, fok, fr = pcall(A.FlipCheck, A, itemID, price)
        if okF and fr and (fr.why == "crash" or fr.why == "flood") then
            return "hold", L["liegen lassen"], fr.why == "crash" and L["Preissturz - der Marktwert ist veraltet, kein Wiederverkauf"]
                or L["Angebot geflutet (3× so viel wie üblich) - kein Wiederverkauf"]
        end
        if okF and fok and fr then
            return "buy", string.format(L["kaufen bis %s"], A:FormatMoney(fr.limit)),
                string.format(L["Wiederverkauf realistisch %s (Angebot und Absatz), Gewinn ~%s für %d Stück"], A:FormatMoney(fr.resale),
                    A:FormatMoney(math.max(0, fr.profit)), fr.qty)
        end
        if okP and ev and (way == "e" or way == "v") and okF and fr and fr.limit then
            ev = nil                -- Flip/Händler: die Flip-Prüfung hat schon "nein" gesagt
            return "hold", L["liegen lassen"], string.format(L["Preis %s über deiner Kaufgrenze %s"], A:FormatMoney(price), A:FormatMoney(math.max(0, fr.limit)))
        end
        if okP and ev then
            local lim = (Ln and Ln.BuyLimit) and Ln:BuyLimit(ev, way) or ev
            if lim and lim > 0 then
                if price <= lim then
                    return "buy", string.format(L["kaufen bis %s"], A:FormatMoney(lim)),
                        string.format(L["erwarteter Netto-Wert %s (%s), Sicherheitsmarge eingerechnet"], A:FormatMoney(ev),
                            ({ e = L["wieder einstellen"], d = L["entzaubern"], v = L["Händler"] })[way] or way)
                end
                return "hold", L["liegen lassen"], string.format(L["Preis %s über deiner Kaufgrenze %s"], A:FormatMoney(price), A:FormatMoney(lim))
            end
        end
    end
    return "hold", L["liegen lassen"], L["zu wenig Daten für eine Empfehlung"]
end

-- Zeilen des Detailbereichs (Text). Rückgabe Liste von Strings
function MV:DetailLines(itemID)
    local out = {}
    local price, qty, t = A:GetCurrent(itemID)
    local mv = A:GetMarketValue(itemID)
    out[#out + 1] = string.format(L["Preis %s · Marktwert %s · Menge %s"], price and A:FormatMoney(price) or "-", mv and A:FormatMoney(mv) or "-", qty and tostring(qty) or "-")
    local t7, t30 = A:GetTrend(itemID, 7 * 86400), A:GetTrend(itemID, 30 * 86400)
    if t7 or t30 then out[#out + 1] = string.format(L["Trend 7 Tage %s · 30 Tage %s"], t7 and string.format("%+d %%", math.floor(t7 + 0.5)) or "-", t30 and string.format("%+d %%", math.floor(t30 + 0.5)) or "-") end
    -- Preisleiter (Vollscan)
    local VS = A.FullScan
    local s = VS and VS:Ladder(itemID)
    if s and s.steps and #s.steps > 0 then
        local parts = {}
        for i = 1, math.min(4, #s.steps) do parts[#parts + 1] = A:FormatMoney(s.steps[i][1]) .. ": " .. s.steps[i][2] end
        out[#out + 1] = L["Preisleiter: "] .. table.concat(parts, " · ")
    end
    -- eigene Geschichte
    local Le = A.Ledger
    if Le then
        local sold = Le.SoldCount and Le:SoldCount(itemID, 30) or 0
        local okR, posts, sales = pcall(Le.PostRate, Le, itemID, 30)
        local buy = Le.AverageBuyPrice and Le:AverageBuyPrice(itemID, 30)
        out[#out + 1] = string.format(L["Du (30 Tage): %d verkauft%s%s"], sold or 0,
            (okR and posts and posts > 0) and (" · " .. string.format(L["Quote %d/%d"], sales or 0, posts)) or "",
            buy and (" · " .. string.format(L["Einkauf Ø %s"], A:FormatMoney(buy))) or "")
    end
    -- gelernte Grenzen
    local Ln = A.Learn
    if Ln and Ln.Limits then
        local ok, mn, normal, mx = pcall(Ln.Limits, Ln, itemID)
        if ok and normal then
            out[#out + 1] = string.format(L["Gelernt: Min %s · Normal %s · Max %s"], mn and A:FormatMoney(mn) or "-", A:FormatMoney(normal), A:FormatMoney(mx))
        end
    end
    local okO, v = pcall(A.SellOutlook, A, itemID, 1)
    if okO and v and v.queue then
        out[#out + 1] = string.format(L["Warteschlange %d · Absatz ~%s/Tag%s"], v.queue, v.perDay and string.format("%.1f", v.perDay) or "?",
            v.perDaySource == "measured" and (" (" .. L["gemessen"] .. ")") or "")
    end
    return out
end

-- ------------------------------------------------------------
-- Oberfläche
-- ------------------------------------------------------------
local SAFETY_COLOR = { hoch = "33dd55", mittel = "ffcc33", niedrig = "999999" }

local function BuildMarketView(parent)
    local p = CreateFrame("Frame", nil, parent)
    local T = A.Today
    p.view = MV:DefaultView()

    local head = UI:TabTitle(p, L["Markt"], "market")
    p.lage = UI:Label(p, "", "GameFontHighlightSmall", C.textDim)
    p.lage:SetPoint("LEFT", head, "RIGHT", 160, 0)

    -- M2: Suche (Nachschlagen) oben rechts
    p.search = UI:EditBox(p, 220, 24, L["Item suchen ..."])
    p.search:SetPoint("TOPRIGHT", 0, 2)
    UI:AttachItemSearch(p.search, {})
    local function Lookup()
        local text = UI:GetItemInput(p.search)
        local id = tonumber(text) or (A.FindItemByName and A:FindItemByName(text))
        if id then p:ShowDetail(id) end
    end
    p.search:SetScript("OnEnterPressed", function(self) self:ClearFocus(); Lookup() end)
    p.search:HookScript("OnTextChanged", function(self) if self.itemID then Lookup() end end)

    -- M1: Leiste mit 6 Ansichten
    p.viewBtns = {}
    local prev
    for i, v in ipairs(MV.VIEWS) do
        local b = UI:Button(p, L[MV.LABELS[v]], 104, 24, function() p:SetView(v) end)
        if prev then b:SetPoint("LEFT", prev, "RIGHT", 4, 0) else b:SetPoint("TOPLEFT", 0, -30) end
        b.tooltip = L[MV.EXPLAIN[v]]
        b.view = v
        p.viewBtns[v] = b
        prev = b
    end
    p.refreshBtn = UI:Button(p, L["Aktualisieren"], 110, 24, function() p.fresh = true; p:Refresh() end)
    p.refreshBtn:SetPoint("LEFT", prev, "RIGHT", 10, 0)
    p.explain = UI:Label(p, "", "GameFontDisableSmall", C.textDim)
    p.explain:SetPoint("TOPLEFT", 0, -60)
    p.explain:SetPoint("RIGHT", p, "RIGHT", -(MV.DETAIL_W + 10), 0)
    p.explain:SetJustifyH("LEFT")
    if p.explain.SetWordWrap then p.explain:SetWordWrap(false) end

    p.table = UI:Table(p, {
        columns = {
            { key = "gold", title = L["Zahl"], width = 86, align = "RIGHT" },
            { key = "text", title = L["Was tun"], width = 250 },
            { key = "state", title = L["Stand"], width = 120 },
        },
        flex = "text",
        action = {
            text = "", width = 140,
            label = function(r)
                if T and r.kind and r.kind ~= "lookup" then
                    local lab, active = T:Label(r)
                    if lab then return lab, active end
                end
                if r.itemID then return L["Details"], true end
                return nil, false
            end,
            onClick = function(r)
                if T and r.kind and r.kind ~= "lookup" and T:Label(r) then
                    T:Click(r)
                    local s = T:State(r)
                    if s.dirty then s.dirty = nil; p:Refresh() else p.table:Render() end
                elseif r.itemID then p:ShowDetail(r.itemID) end
            end,
        },
        rows = 14, rowHeight = 24, noMenu = true, itemTooltip = false, idKey = "text",
        sortKey = "order", sortAsc = true,
        cell = function(r, key)
            if key == "gold" then
                if r.pin then return "|cffffcc33" .. L["Auftrag"] .. "|r" end
                if r.tip then return "|cff888888" .. L["Tipp"] .. "|r" end
                local col = SAFETY_COLOR[r.safety or "hoch"] or "33dd55"
                if r.warn then col = "ff5544" end
                return "|cff" .. col .. (r.num or A:FormatMoney(r.gold or 0)) .. "|r"
            end
            if key == "state" then return (T and r.kind and r.kind ~= "lookup") and T:Info(r) or (r.where or "") end
            return r[key] or ""
        end,
        sortValue = function(r, key)
            if key == "order" then return r.order or 0 end
            if key == "gold" then return (r.pin and math.huge) or (r.tip and -1) or r.gold or 0 end
            return tostring(r[key] or "")
        end,
        -- Klick: Detailbereich (Item) bzw. wie bisher in den Reiter (Zeilen ohne Item)
        onClick = function(r)
            -- Heute: wie bisher in den passenden Reiter (nichts geht verloren); andere Ansichten: Detailbereich
            if r.itemID and not (p.view == "heute" and r.run) then return p:ShowDetail(r.itemID) end
            if r.kind == "vendorsell" then
                A:Print(L["Geh zu einem Händler - dort verkauft der Knopf rechts in dieser Zeile."])
                return
            end
            if not r.run then
                A:Print(L["Für diesen Tipp gibt es kein Fenster - der Knopf rechts führt ihn aus."])
                return
            end
            local ok, err = pcall(r.run)
            if not ok then
                if A.Diag then pcall(A.Diag.Add, A.Diag, "HEUTE-KLICK", "Fehler " .. tostring(r.kind) .. ": " .. tostring(err):sub(1, 120)) end
                A:Print(L["Das hat nicht geklappt: "] .. tostring(err):sub(1, 120))
            end
        end,
        onHover = function(r)
            GameTooltip:SetOwner(UIParent, "ANCHOR_CURSOR")
            GameTooltip:SetText(r.text or "", 1, 1, 1, 1, true)
            if r.safety then GameTooltip:AddLine(L["Sicherheit: "] .. L[r.safety], 0.6, 0.6, 0.6) end
            GameTooltip:AddLine(L["Knopf rechts: nächster Schritt direkt hier. Klick auf die Zeile: Details rechts."], 0.6, 0.6, 0.6, true)
            GameTooltip:Show()
        end,
        emptyText = L["Gerade nichts in dieser Ansicht. Nach dem nächsten Scan (und mit offenem Auktionshaus) wieder hineinschauen."],
    })
    p.table:Fill(0, -78, -(MV.DETAIL_W + 10), 24)
    p.info = UI:Label(p, "", "GameFontDisableSmall", C.textDim)
    p.info:SetPoint("BOTTOMLEFT", 0, 4)
    p.info:SetPoint("RIGHT", p, "RIGHT", -(MV.DETAIL_W + 10), 0)
    p.info:SetJustifyH("LEFT")
    if p.info.SetWordWrap then p.info:SetWordWrap(false) end

    -- M3: Detailbereich rechts
    local d = CreateFrame("Frame", nil, p)
    UI:Box(d, C.panel, C.border)
    d:SetPoint("TOPRIGHT", 0, -78)
    d:SetPoint("BOTTOMRIGHT", 0, 4)
    d:SetWidth(MV.DETAIL_W)
    p.detail = d
    d.title = UI:Label(d, L["Details"], "GameFontNormal", C.heading)
    d.title:SetPoint("TOPLEFT", 8, -8)
    d.title:SetPoint("RIGHT", d, "RIGHT", -8, 0)
    if d.title.SetWordWrap then d.title:SetWordWrap(false) end
    -- Preis- und Angebotsverlauf übereinander (je 30 Balken, letzte 14 Tage)
    d.bars = { price = {}, qty = {} }
    local BAR_N, BAR_W, BAR_H = 30, 8, 34
    for k, key in ipairs({ "price", "qty" }) do
        local base = -30 - (k - 1) * (BAR_H + 8)
        for i = 1, BAR_N do
            local tex = d:CreateTexture(nil, "ARTWORK")
            tex:SetColorTexture(key == "price" and 0.2 or 0.4, key == "price" and 0.8 or 0.6, key == "price" and 0.8 or 1, 0.8)
            tex:SetSize(BAR_W - 1, 1)
            tex:SetPoint("BOTTOMLEFT", d, "TOPLEFT", 8 + (i - 1) * BAR_W, base - BAR_H)
            d.bars[key][i] = tex
        end
    end
    d.barLabel = UI:Label(d, L["Preis (oben) und Angebot (unten), 14 Tage"], "GameFontDisableSmall", C.textDim)
    d.barLabel:SetPoint("TOPLEFT", 8, -30 - 2 * (BAR_H + 8))
    d.lines = {}
    for i = 1, 7 do
        local fs = UI:Label(d, "", "GameFontHighlightSmall", C.text)
        fs:SetPoint("TOPLEFT", 8, -30 - 2 * (BAR_H + 8) - 6 - i * 16)
        fs:SetPoint("RIGHT", d, "RIGHT", -8, 0)
        if fs.SetWordWrap then fs:SetWordWrap(false) end
        d.lines[i] = fs
    end
    d.advice = UI:Label(d, "", "GameFontNormal", C.green)
    d.advice:SetPoint("TOPLEFT", d.lines[#d.lines], "BOTTOMLEFT", 0, -10)
    d.reason = UI:Label(d, "", "GameFontHighlightSmall", C.textDim)
    d.reason:SetPoint("TOPLEFT", d.advice, "BOTTOMLEFT", 0, -4)
    d.reason:SetPoint("RIGHT", d, "RIGHT", -8, 0)
    d.watchBtn = UI:Button(d, L["Watchlist"], 92, 22, function()
        if d.itemID and A.Watchlist then local _, msg = A.Watchlist:Add(tostring(d.itemID)); A:Print(msg) end
    end)
    d.watchBtn:SetPoint("BOTTOMLEFT", 8, 8)
    d.listBtn = UI:Button(d, L["Einkaufsliste"], 92, 22, function()
        if not (d.itemID and A.Lists) then return end
        local names = A.Lists:GetNames()
        local name = names[1]
        if not name then local _, _, created = A.Lists:Create(L["Markt"]); name = created end
        if name then local _, msg = A.Lists:AddItem(name, tostring(d.itemID), 1); A:Print(msg) end
    end)
    d.listBtn:SetPoint("LEFT", d.watchBtn, "RIGHT", 4, 0)
    d.sniperBtn = UI:Button(d, L["Sniper"], 92, 22, function()
        if not (d.itemID and A.Sniper) then return end
        local _, _, lim = MV:LimitFor(d.itemID)
        local ok, msg = A.Sniper:SetTarget(tostring(d.itemID), lim or A:GetMarketValue(d.itemID) or 1, 20, nil)
        A:Print(msg or (ok and L["Sniper-Ziel angelegt."] or ""))
    end)
    d.sniperBtn:SetPoint("LEFT", d.listBtn, "RIGHT", 4, 0)
    d.sniperBtn.tooltip = L["Sniper-Ziel mit der vorgeschlagenen Kaufgrenze anlegen."]
    d.chartBtn = UI:Button(d, L["Preisverlauf"], 284, 22, function() if d.itemID then UI:OpenChart(d.itemID) end end)
    d.chartBtn:SetPoint("BOTTOMLEFT", d.watchBtn, "TOPLEFT", 0, 4)

    function p:ClearDetail()
        d.itemID, d.kind = nil, nil
        d.title:SetText(L["Details"])
        for _, fs in ipairs(d.lines) do fs:SetText("") end
        d.advice:SetText(""); d.reason:SetText("")
        for i = 1, BAR_N do d.bars.price[i]:SetHeight(1); d.bars.qty[i]:SetHeight(1) end
    end

    function p:ShowDetail(itemID)
        d.itemID = itemID
        d.title:SetText(A:GetItemName(itemID) or ("#" .. itemID))
        -- Verlauf: 30 Zeitfenster über 14 Tage
        local h = A:GetHistory(itemID)
        local now = time()
        local from = now - 14 * 86400
        local slotP, slotQ = {}, {}
        for _, e in ipairs(h) do
            if e.t >= from and e.p and e.p > 0 and not e.u then
                local i = math.min(BAR_N, math.floor((e.t - from) / (14 * 86400) * BAR_N) + 1)
                slotP[i] = math.min(slotP[i] or math.huge, e.p)
                slotQ[i] = math.max(slotQ[i] or 0, e.q or 0)
            end
        end
        local maxP, maxQ = 0, 0
        for i = 1, BAR_N do maxP = math.max(maxP, slotP[i] or 0); maxQ = math.max(maxQ, slotQ[i] or 0) end
        for i = 1, BAR_N do
            d.bars.price[i]:SetHeight(maxP > 0 and math.max(1, (slotP[i] or 0) / maxP * BAR_H) or 1)
            d.bars.qty[i]:SetHeight(maxQ > 0 and math.max(1, (slotQ[i] or 0) / maxQ * BAR_H) or 1)
        end
        local lines = MV:DetailLines(itemID)
        for i, fs in ipairs(d.lines) do fs:SetText(lines[i] or "") end
        local kind, advice, reason = MV:Advice(itemID)
        d.advice:SetText(advice or "")
        d.advice:SetTextColor(unpack((kind == "hold") and C.yellow or C.green))
        d.reason:SetText(reason or "")
        d.kind = kind
    end

    function p:SetView(v)
        -- H7: Detailbereich beim Ansichtswechsel leeren - danach zeigt er die erste Zeile der neuen Ansicht
        if self.view ~= v then self:ClearDetail() end
        self.view = v
        self.fresh = nil
        self:Refresh()
    end

    function p:Refresh()
        for v, b in pairs(self.viewBtns) do
            b.label:SetTextColor(unpack(v == self.view and C.accent or C.text))
        end
        self.explain:SetText(L[MV.EXPLAIN[self.view]])
        self.lage:SetText(MV:IndexText())
        local view = self.view
        local userFresh = self.fresh
        local list, busy, capital, money = MV:Rows(view, self.fresh, function()
            if p:IsVisible() and p.view == view then p:Refresh() end
        end)
        self.fresh = nil
        local rows = {}
        for i, r in ipairs(list or {}) do
            if i > MV.MAX_ROWS and not r.pin then break end
            r.order = i
            rows[#rows + 1] = r
        end
        self.list = rows
        -- Zustände alter Zeilen nur beim Knopf "Aktualisieren" vergessen (sonst verlöre eine laufende Zeile ihren Schritt)
        if view == "heute" and userFresh and T and T.Prune then T:Prune(rows) end
        self.table:SetData(rows, true)
        -- H6: leere Ansicht nennt den Grund
        if self.table.empty then
            local why = (not busy and #rows == 0 and view ~= "heute") and MV.reason[view] or nil
            self.table.empty:SetText(why or L["Gerade nichts in dieser Ansicht. Nach dem nächsten Scan (und mit offenem Auktionshaus) wieder hineinschauen."])
        end
        local txt
        if busy then txt = L["Wird berechnet ..."]
        elseif view == "heute" then
            local sum = 0
            for _, r in ipairs(rows) do sum = sum + (r.gold or 0) end
            txt = string.format(L["%d Vorschläge, zusammen ca. %s"], #rows, A:FormatMoney(sum))
                .. "   |   " .. string.format(L["Kapitalbedarf: %s von %s (höchstens die Hälfte)"], A:FormatMoney(capital or 0), A:FormatMoney(money or 0))
        else
            txt = string.format(L["%d Zeilen"], #rows)
        end
        if not A:IsAHOpen() then txt = txt .. "   |   |cffffcc33" .. L["Auktionshaus öffnen, um Käufe direkt auszuführen"] .. "|r" end
        self.info:SetText(txt)
        if not d.itemID and rows[1] and rows[1].itemID then self:ShowDetail(rows[1].itemID) end
    end

    -- Antworten vom Server abholen (Angebote geladen, Preis reserviert, eingestellt ...) - wie "Heute tun"
    local acc = 0
    p:SetScript("OnUpdate", function(self, dt)
        acc = acc + (dt or 0)
        if acc < 0.4 then return end
        acc = 0
        if not (T and self.list) then return end
        for _, r in ipairs(self.list) do if r.kind and r.kind ~= "lookup" then T:Update(r) end end
        self.table:Render()
    end)
    p:HookScript("OnShow", function(self) self:Refresh() end)
    -- für ältere Aufrufe (UI:ShowToday, Tests): Tabelle und Refresh wie das alte Fenster
    UI.marketView = p
    return p
end

-- Kaufgrenze für den Sniper-Knopf: erwarteter Netto-Wert × (1 − Marge)
function MV:LimitFor(itemID)
    local Fc, Ln = A.Forecast, A.Learn
    if not Fc then return nil end
    local ok, way, ev = pcall(Fc.BuyPrediction, Fc, itemID)
    if not (ok and ev) then return nil end
    return way, ev, (Ln and Ln.BuyLimit) and Ln:BuyLimit(ev, way) or ev
end

UI:RegisterTab("marketview", "Markt", 2, BuildMarketView)

-- Teil B der Testroutine: Zeilen je Ansicht (echte Daten, nur lesen) und Index
function MV:Report()
    local out, fields = { "Markt-Reiter (echte Daten):" }, {}
    local parts = {}
    for _, v in ipairs(self.VIEWS) do
        local n
        if v == "heute" then
            local ok, list = pcall(A.Comfort.TodayActions, A.Comfort, 10)
            n = ok and list and #list or nil
        else
            local ok, rows = pcall(self[self.BUILDERS[v]], self)
            n = ok and rows and math.min(#rows, self.MAX_ROWS) or nil
        end
        parts[#parts + 1] = string.format("%s %s", L[self.LABELS[v]], n and tostring(n) or "Fehler")
    end
    out[#out + 1] = "  Zeilen je Ansicht: " .. table.concat(parts, " · ")
    local d1, d7, n = self:Index()
    out[#out + 1] = string.format("  Index: heute %s · 7 Tage %s (%d Waren im Korb)", d1 and string.format("%+.1f %%", d1) or "-", d7 and string.format("%+.1f %%", d7) or "-", n or 0)
    fields.markt_zeilen = table.concat(parts, " | ")
    fields.markt_index = d1 and string.format("%+.1f/%s", d1, d7 and string.format("%+.1f", d7) or "-") or "-"
    return out, fields
end

-- ------------------------------------------------------------
-- "Heute tun" öffnet jetzt den Markt-Reiter, Ansicht "Heute" (/ahs heute, Übersicht, QuickBuy/QuickSell)
-- ------------------------------------------------------------
function UI:ShowToday()
    if GameTooltip and GameTooltip.Hide then GameTooltip:Hide() end
    if self.Show then pcall(self.Show, self) end
    self:SelectTab("marketview")
    local tab = self:GetTab("marketview")
    local p = tab and tab.panel
    if not p then return nil end
    if p.view ~= "heute" then p.view = "heute" end
    p:Show()
    p:Refresh()
    self.todayWin = p
    return p
end
