if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 4.0 - Tab "Übersicht" (Dashboard)
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C

local function BuildOverview(parent)
    local p = CreateFrame("Frame", nil, parent)

    local head = UI:TabTitle(p, L["Markt-Übersicht"], "overview")
    local sub = UI:Label(p, L["Kennzahlen aus deinen Scans. Trends brauchen mindestens zwei Scans."], "GameFontDisableSmall", C.textDim)
    sub:SetPoint("TOPLEFT", head, "BOTTOMLEFT", 0, -4)

    -- Was bringt jetzt am meisten Gold?
    p.todayBtn = UI:Button(p, L["Heute tun"], 150, 26, function() UI:ShowToday() end, "primary")
    p.todayBtn:SetPoint("TOPRIGHT", 0, 0)
    p.todayBtn.tooltip = L["Die Aktionen, die gerade am meisten Gold bringen - netto, nur mit verlässlichen Preisen.\nKlick auf eine Zeile führt direkt in den passenden Reiter. Auch: /ahs heute"]

    -- Kennzahl-Karten
    local cardW, cardH, gap = 224, 66, 10     -- 4 Karten füllen die ganze Breite
    p.cardItems = UI:Card(p, cardW, cardH, L["Items in der Datenbank"], "Interface\\Icons\\INV_Misc_Bag_08")
    p.cardItems:SetPoint("TOPLEFT", 0, -44)
    p.cardScans = UI:Card(p, cardW, cardH, L["Letzter Scan"], "Interface\\Icons\\INV_Misc_Spyglass_02")
    p.cardScans:SetPoint("LEFT", p.cardItems, "RIGHT", gap, 0)
    p.cardNext = UI:Card(p, cardW, cardH, L["Nächster Scan möglich"], "Interface\\Icons\\INV_Misc_PocketWatch_01")
    p.cardNext:SetPoint("LEFT", p.cardScans, "RIGHT", gap, 0)
    p.cardAlerts = UI:Card(p, cardW, cardH, L["Watchlist-Alarme"], "Interface\\Icons\\Ability_Warrior_BattleShout")
    p.cardAlerts:SetPoint("LEFT", p.cardNext, "RIGHT", gap, 0)

    -- Gewinner / Verlierer
    local columns = {
        { key = "name", title = L["Item"], width = 230 },
        { key = "price", title = L["Preis"], width = 110, align = "RIGHT" },
        { key = "change", title = L["seit Scan"], width = 75, align = "RIGHT" },
    }
    local function cell(item, key)
        if key == "name" then return UI.ItemName(item) end
        if key == "price" then return A:FormatMoney(item.price) end
        if key == "change" then return A:FormatPercent(item.change) end
    end

    local upTitle = UI:Label(p, L["Größte Preisanstiege"], "GameFontNormal", C.green)
    upTitle:SetPoint("TOPLEFT", 0, -130)
    p.upTable = UI:Table(p, {
        columns = columns, rows = 12, rowHeight = 22, cell = cell,
        onClick = function(item) UI:OpenChart(item.itemID) end,
        emptyText = L["Noch keine Vergleichsdaten.\nNach dem zweiten Scan erscheinen hier Trends."],
    })
    p.upTable:FillAnchors({ "TOPLEFT", 0, -150 }, { "BOTTOM", -7, 22 })     -- linke Hälfte, bis kurz über den Tipp

    local downTitle = UI:Label(p, L["Größte Preisrückgänge"], "GameFontNormal", C.red)
    downTitle:SetPoint("TOPLEFT", p, "TOP", 7, -130)
    p.downTable = UI:Table(p, {
        columns = columns, rows = 12, rowHeight = 22, cell = cell,
        onClick = function(item) UI:OpenChart(item.itemID) end,
        emptyText = L["Noch keine Vergleichsdaten."],
    })
    p.downTable:FillAnchors({ "TOP", 7, -150 }, { "BOTTOMRIGHT", 0, 22 })   -- rechte Hälfte

    local hint = UI:Label(p, L["Tipp: Auf ein Item klicken öffnet den Preisverlauf."], "GameFontDisableSmall", C.textDim)
    hint:SetPoint("BOTTOMLEFT", 0, 4)

    -- Karten auf die ganze Breite verteilen
    local cards = { p.cardItems, p.cardScans, p.cardNext, p.cardAlerts }
    function p:LayoutCards()
        local w = self:GetWidth()
        if not w or w < 400 then return end
        local cw = math.floor((w - 3 * gap) / 4)
        for _, c in ipairs(cards) do c:SetWidth(cw) end
    end

    function p:Refresh()
        local db = A.db
        if not db then return end
        self:LayoutCards()

        self.cardItems.value:SetText(A:CountTable(db.marketData))
        self.cardItems.sub:SetText(L["Scans insgesamt: "] .. (db.totalScans or 0))

        local lastLog = db.scanLog[#db.scanLog]
        self.cardScans.value:SetText(A:FormatAgo(db.lastScanTime))
        self.cardScans.sub:SetText(lastLog and (lastLog.items .. L[" Items erfasst"]) or "")

        if A:IsScanning() then
            self.cardNext.value:SetText(L["|cffffcc33Scan läuft|r"])
        elseif A:IsScanReady() then
            self.cardNext.value:SetText(L["|cff33dd55jetzt|r"])
        else
            self.cardNext.value:SetText(A:FormatDuration(A:GetCooldownRemaining()) .. L[" Min."])
        end
        self.cardNext.sub:SetText(A:IsAHOpen() and L["Auktionshaus ist offen"] or L["Auktionshaus öffnen zum Scannen"])

        local alerts = A.Watchlist and A.Watchlist:CountAlerts() or 0
        self.cardAlerts.value:SetText(alerts > 0 and ("|cff33dd55" .. alerts .. "|r") or "0")
        self.cardAlerts.sub:SetText((A.Watchlist and A.Watchlist:Count() or 0) .. L[" Items beobachtet"])

        local list = A:BuildItemList()
        local ups, downs = {}, {}
        for _, it in ipairs(list) do
            -- Sprünge um das Zehnfache und mehr (ab +900 % bzw. ab -90 %) sind fast immer Fehldaten,
            -- z. B. ein Spaß-Angebot für 9999g im vorigen Scan: nicht als Anstieg/Rückgang zeigen
            -- nur Items mit verlässlichem Marktwert (keine Mondpreise einzelner Angebote)
            if it.change and (it.change > 0.05 and it.change < 900 or it.change < -0.05 and it.change > -90)
                and not A:IsOddPrice(it.price) and A:IsReliable(it.itemID) then
                -- Bezug zum Marktwert: ein Anstieg auf ein Vielfaches des Marktwerts ist meist nur das
                -- letzte teure Einzelangebot, ein Rückgang von einem Vielfachen war vorher ein Mondpreis
                local mv = A:GetMarketValue(it.itemID)
                local prev = it.price / (1 + it.change / 100)
                local ok = mv and mv > 0
                if ok and it.change > 0 and it.price > mv * 3 then ok = false end
                if ok and it.change < 0 and (prev > mv * 3 or A:IsOddPrice(math.floor(prev + 0.5))) then ok = false end
                if ok then
                    if it.change > 0 then table.insert(ups, it) else table.insert(downs, it) end
                end
            end
        end
        table.sort(ups, function(a, b) return a.change > b.change end)
        table.sort(downs, function(a, b) return a.change < b.change end)
        self.upTable:SetData(ups)
        self.downTable:SetData(downs)
    end

    -- Countdown in den Karten laufen lassen
    local elapsed = 0
    p:SetScript("OnUpdate", function(self, dt)
        elapsed = elapsed + dt
        if elapsed < 1 then return end
        elapsed = 0
        if A:IsScanning() then
            self.cardNext.value:SetText(L["|cffffcc33Scan läuft|r"])
        elseif A:IsScanReady() then
            self.cardNext.value:SetText(L["|cff33dd55jetzt|r"])
        else
            self.cardNext.value:SetText(A:FormatDuration(A:GetCooldownRemaining()) .. L[" Min."])
        end
        self.cardScans.value:SetText(A:FormatAgo(A.db and A.db.lastScanTime))
    end)

    return p
end

-- ------------------------------------------------------------
-- Fenster "Heute tun" (alt; seit Stufe 3 öffnet UI:ShowToday den Reiter Markt -> Heute, UI_MarketView.lua).
-- Das Fenster bleibt als UI:ShowTodayWindow erhalten.
-- ------------------------------------------------------------
function UI:ShowTodayWindow()
    if GameTooltip and GameTooltip.Hide then GameTooltip:Hide() end
    local T = A.Today
    if not self.todayWin then
        local w = self:Dialog("AHAnalyzerProToday", 1010, 440, L["Heute tun - was jetzt am meisten Gold bringt"])
        w.info = UI:Label(w, "", "GameFontHighlightSmall", C.textDim)
        w.info:SetPoint("TOPLEFT", 16, -38)
        w.info:SetWidth(970)
        w.info:SetJustifyH("LEFT")
        w.table = UI:Table(w, {
            columns = {
                { key = "gold", title = L["Gewinn ca."], width = 92, align = "RIGHT" },
                { key = "text", title = L["Was tun"], width = 470 },
                { key = "state", title = L["Stand"], width = 220 },
            },
            -- Knopf je Zeile: immer der nächste Schritt (Prüfen -> Kaufen -> Einstellen ...)
            action = {
                text = "", width = 176,
                label = function(r) if T then return T:Label(r) end end,
                onClick = function(r)
                    if not T then return end
                    T:Click(r)
                    local s = T:State(r)
                    if s.dirty then s.dirty = nil; w:Refresh() else w.table:Render() end
                end,
            },
            rows = 10, rowHeight = 26, noMenu = true, itemTooltip = false, idKey = "text",
            sortKey = "gold", sortAsc = false,
            cell = function(r, key)
                if key == "gold" then
                    if r.pin then return "|cffffcc33" .. L["Auftrag"] .. "|r" end
                    if r.tip then return "|cff888888" .. L["Tipp"] .. "|r" end
                    return "|cff33dd55" .. A:FormatMoney(r.gold) .. "|r"
                end
                if key == "state" then return T and T:Info(r) or (r.where or "") end
                return r[key] or ""
            end,
            -- Aufträge (QuickBuy/QuickSell) immer oben
            sortValue = function(r, key)
                if key == "gold" then return (r.pin and math.huge) or (r.tip and -1) or r.gold end
                return tostring(r[key] or "")
            end,
            -- Klick auf die Zeile: wie bisher in den Reiter (Ausweichweg); Fenster zu, damit es den Reiter nicht verdeckt
            -- H2 (Befund 07:35): jede Zeile hat ein sichtbares Ziel; ohne Ziel bleibt das Fenster offen und es kommt eine
            -- Meldung. Fehler werden nicht verschluckt (Protokoll HEUTE-KLICK, Chat-Meldung).
            onClick = function(r)
                if r.kind == "vendorsell" then
                    A:Print(L["Geh zu einem Händler - dort verkauft der Knopf rechts in dieser Zeile."])
                    return
                end
                if not r.run then
                    A:Print(L["Für diesen Tipp gibt es kein Fenster - der Knopf rechts führt ihn aus."])
                    return
                end
                w:Hide()
                local ok, err = pcall(r.run)
                if not ok then
                    if A.Diag then pcall(A.Diag.Add, A.Diag, "HEUTE-KLICK", "Fehler " .. tostring(r.kind) .. ": " .. tostring(err):sub(1, 120)) end
                    A:Print(L["Das hat nicht geklappt: "] .. tostring(err):sub(1, 120))
                    w:Show()
                end
            end,
            onHover = function(r)
                GameTooltip:SetOwner(UIParent, "ANCHOR_CURSOR")
                GameTooltip:SetText(r.text, 1, 1, 1, 1, true)
                GameTooltip:AddLine(L["Knopf rechts: nächster Schritt direkt hier. Klick auf die Zeile: dorthin wechseln."], 0.6, 0.6, 0.6, true)
                GameTooltip:Show()
            end,
            emptyText = L["Gerade nichts Lohnendes gefunden.\nNach dem nächsten Scan (und mit offenem Auktionshaus) wieder hineinschauen."],
        })
        w.table:SetPoint("TOPLEFT", 14, -62)
        w.refresh = UI:Button(w, L["Aktualisieren"], 130, 24, function() w.fresh = true; w:Refresh() end)
        w.refresh:SetPoint("BOTTOMLEFT", 16, 12)
        w.note = UI:Label(w, (A:IsForever() and L["Geschätzt aus deinen Scans - keine Garantie. Gewinne sind netto (AH-Anteil, erwartete Einstellgebühr). Gekauft wird nie teurer und nie mehr als vorgeschlagen."]
            or L["Geschätzt aus deinen Scans - keine Garantie. Gewinne sind netto (AH-Anteil, erwartete Einstellgebühr). Gekauft wird nie teurer und nie mehr als vorgeschlagen."]), "GameFontDisableSmall", C.textDim)
        w.note:SetPoint("LEFT", w.refresh, "RIGHT", 12, 0)
        function w:Refresh()
            local list, capital, money = A.Comfort:TodayActions(10, self.fresh)      -- Knopf "Aktualisieren": sofort
            self.fresh = nil
            list = list or {}
            self.list = list
            if T and T.Prune then T:Prune(list) end
            self.table:SetData(list, true)
            local goal = A.Comfort.GoldGoalText and A.Comfort:GoldGoalText()
            local sum = 0
            for _, r in ipairs(list) do sum = sum + (r.gold or 0) end
            local txt = string.format(L["%d Vorschläge, zusammen ca. %s"], #list, A:FormatMoney(sum))
                .. "   |   " .. string.format(L["Kapitalbedarf: %s von %s (höchstens die Hälfte)"], A:FormatMoney(capital or 0), A:FormatMoney(money or 0))
            if goal then txt = txt .. "   |   " .. goal end
            if not A:IsAHOpen() then txt = txt .. "   |   |cffffcc33" .. L["Auktionshaus öffnen, um Käufe direkt auszuführen"] .. "|r" end
            self.info:SetText(txt)
        end
        -- Antworten vom Server abholen (Angebote geladen, Preis reserviert, eingestellt ...)
        local acc = 0
        w:SetScript("OnUpdate", function(self, dt)
            acc = acc + (dt or 0)
            if acc < 0.4 then return end
            acc = 0
            if not (T and self.list) then return end
            for _, r in ipairs(self.list) do T:Update(r) end
            self.table:Render()
        end)
        w:HookScript("OnShow", function(self) self:Refresh() end)
        self.todayWindow = w
    end
    self.todayWindow:Show()
    self.todayWindow:Refresh()
    return self.todayWindow
end

UI:RegisterTab("overview", "Übersicht", 1, BuildOverview)
