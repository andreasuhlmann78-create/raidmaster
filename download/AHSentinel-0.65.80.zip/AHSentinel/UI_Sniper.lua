if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.9 - Tab "Sniper"
-- Ziele mit Preis, Menge, Budget, Seltenheit, Itemlevel und Stufe.
-- Sniper-Modus AN: sucht selbstständig, Kauf per Mausrad / eigener Taste.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C

local function Num(edit)
    local n = tonumber((string.gsub(edit:GetText() or "", ",", ".")))
    if n then return math.floor(n) end
    return nil
end

-- ------------------------------------------------------------
-- Fenster "Taste drücken" (eigene Taste wählen)
-- ------------------------------------------------------------
local capture

local IGNORE_KEYS = {
    LSHIFT = true, RSHIFT = true, LCTRL = true, RCTRL = true, LALT = true, RALT = true,
    UNKNOWN = true, LMETA = true, RMETA = true,
}

local function Mods()
    local m = ""
    if IsAltKeyDown and IsAltKeyDown() then m = m .. "ALT-" end
    if IsControlKeyDown and IsControlKeyDown() then m = m .. "CTRL-" end
    if IsShiftKeyDown and IsShiftKeyDown() then m = m .. "SHIFT-" end
    return m
end

local function OpenCapture(onDone)
    if not capture then
        capture = CreateFrame("Frame", "AHAnalyzerProKeyCapture", UIParent)
        capture:SetSize(380, 130)
        capture:SetPoint("CENTER", 0, 120)
        capture:SetFrameStrata("FULLSCREEN_DIALOG")
        UI:Box(capture, C.panel, C.accent)
        local title = UI:Label(capture, L["Eigene Kauf-Taste wählen"], "GameFontNormalLarge", C.accent)
        title:SetPoint("TOP", 0, -14)
        capture.text = UI:Label(capture, L["Drücke jetzt eine Taste, die mittlere Maustaste,\nMaustaste 4/5 oder dreh das Mausrad.\nShift / Strg / Alt dazu ist möglich.  ESC = Abbrechen"], "GameFontHighlightSmall", C.text)
        capture.text:SetPoint("TOP", title, "BOTTOM", 0, -10)
        capture.text:SetJustifyH("CENTER")
        capture.error = UI:Label(capture, "", "GameFontHighlightSmall", C.red)
        capture.error:SetPoint("BOTTOM", 0, 12)

        capture:EnableKeyboard(true)
        capture:EnableMouse(true)
        capture:EnableMouseWheel(true)
        if capture.SetPropagateKeyboardInput then capture:SetPropagateKeyboardInput(false) end

        local function finish(key)
            capture:Hide()
            if key and capture.onDone then capture.onDone(key) end
        end

        capture:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then finish(nil) return end
            if IGNORE_KEYS[key] then return end
            finish(Mods() .. key)
        end)
        capture:SetScript("OnMouseWheel", function(self, delta)
            finish(Mods() .. "MOUSEWHEEL")
        end)
        capture:SetScript("OnMouseDown", function(self, button)
            if button == "LeftButton" or button == "RightButton" then
                self.error:SetText(L["Linke/rechte Maustaste geht nicht - bitte eine andere wählen."])
                return
            end
            local map = { MiddleButton = "BUTTON3", Button4 = "BUTTON4", Button5 = "BUTTON5" }
            if map[button] then finish(Mods() .. map[button]) end
        end)
    end
    capture.onDone = onDone
    capture.error:SetText("")
    capture:Show()
end
A.UI.OpenKeyCapture = OpenCapture

-- gefangene Taste -> Liste von Belegungen
local function KeyToBinds(key)
    local mods, base = key:match("^(.*%-)(.-)$")
    if not base or base == "" then mods, base = "", key end
    if base == "MOUSEWHEEL" then
        return { mods .. "MOUSEWHEELUP", mods .. "MOUSEWHEELDOWN" }
    end
    return { key }
end
A.UI.KeyToBinds = KeyToBinds

-- ------------------------------------------------------------
-- Tab
-- ------------------------------------------------------------
local function BuildSniper(parent)
    local p = CreateFrame("Frame", nil, parent)
    local Sn = A.Sniper

    local function setMessage(ok, msg)
        if not msg then return end
        p.message:SetText(msg)
        p.message:SetTextColor(unpack(ok and C.textDim or C.red))
    end

    -- ================= Linke Seite =================
    local head = UI:TabTitle(p, L["Sniper"], "sniper")
    local sub = UI:Label(p, A:IsForever()
        and L["Zum Kaufen einfach weiterscrollen – jede Raste macht den nächsten Schritt."]
        or L["1. Ziel eintragen   2. Sniper-Modus AN   3. Mausrad drehen = kaufen"], "GameFontDisableSmall", C.textDim)
    sub:SetPoint("TOPLEFT", head, "BOTTOMLEFT", 0, -4)

    p.listsBtn = UI:Button(p, L["Einkaufslisten"], 120, 22, function() UI:ShowLists() end)
    p.listsBtn:SetPoint("TOPLEFT", 326, 0)
    p.listsBtn.tooltip = L["Listen mit Items und Mengen - mit einem Klick als Sniper-Ziele übernehmen"]

    -- Zeile 1: Ziel und Menge
    p.item = UI:EditBox(p, 220, 24, L["Name, ID oder Suchwort"])
    p.item.tooltipText = L["Item-Name in jeder Sprache, Item-ID, Shift-Klick auf ein Item - oder ein Suchwort"]
    UI:AttachItemSearch(p.item, { onPick = function() p.max:SetFocus() end })
    p.item:SetPoint("TOPLEFT", 0, -46)
    p.qty = UI:EditBox(p, 60, 24, L["Menge"])
    p.qty:SetPoint("LEFT", p.item, "RIGHT", 6, 0)

    -- Zeile 2: Max-Preis pro Stück und Budget in Gold / Silber / Kupfer
    local maxLabel = UI:Label(p, L["Max/Stück:"], "GameFontHighlightSmall", C.textDim)
    maxLabel:SetPoint("TOPLEFT", 0, -82)
    p.max = UI:MoneyInput(p)
    p.max:SetPoint("TOPLEFT", 70, -76)
    local budgetLabel = UI:Label(p, L["Budget:"], "GameFontHighlightSmall", C.textDim)
    budgetLabel:SetPoint("TOPLEFT", 236, -82)
    p.budget = UI:MoneyInput(p)
    p.budget:SetPoint("TOPLEFT", 290, -76)

    -- Zeile 3: Filter (einklappbar)
    p.filterRow = CreateFrame("Frame", nil, p)
    p.filterRow:SetPoint("TOPLEFT", 0, -108)
    p.filterRow:SetSize(446, 24)
    local fr = p.filterRow

    -- Seltenheit: Aufklappmenü zum Anhaken
    p.qualPicker = UI:QualityPicker(fr, 164)
    p.qualPicker:SetPoint("TOPLEFT", 0, 0)

    p.ilvlMin = UI:EditBox(fr, 50, 24, L["iLvl ab"])
    p.ilvlMin:SetPoint("LEFT", p.qualPicker, "RIGHT", 8, 0)
    p.ilvlMax = UI:EditBox(fr, 50, 24, L["iLvl bis"])
    p.ilvlMax:SetPoint("LEFT", p.ilvlMin, "RIGHT", 4, 0)
    p.lvlMin = UI:EditBox(fr, 50, 24, L["Stufe ab"])
    p.lvlMin:SetPoint("LEFT", p.ilvlMax, "RIGHT", 8, 0)
    p.lvlMax = UI:EditBox(fr, 50, 24, L["Stufe bis"])
    p.lvlMax:SetPoint("LEFT", p.lvlMin, "RIGHT", 4, 0)

    function p:UpdateQualityButtons()
        self.qualPicker:Refresh()
    end

    local allEdits = { p.item, p.qty, p.max.boxes[1], p.max.boxes[2], p.max.boxes[3],
        p.budget.boxes[1], p.budget.boxes[2], p.budget.boxes[3], p.ilvlMin, p.ilvlMax, p.lvlMin, p.lvlMax }

    local function clearForm()
        for _, e in ipairs(allEdits) do e:SetText(""); e:ClearFocus(); e:UpdatePlaceholder() end
        p.qualPicker:Reset()
    end

    local function setTarget()
        local ok, msg = Sn:SetTarget(UI:GetItemInput(p.item), p.max:GetCopper(), Num(p.qty), p.budget:GetCopper(), {
            quals = p.qualPicker:GetSet(),
            ilvlMin = Num(p.ilvlMin), ilvlMax = Num(p.ilvlMax),
            lvlMin = Num(p.lvlMin), lvlMax = Num(p.lvlMax),
        })
        setMessage(ok, msg)
        if ok then clearForm() end
    end
    for _, e in ipairs(allEdits) do e:SetScript("OnEnterPressed", setTarget) end

    p.setBtn = UI:Button(p, L["Ziel setzen"], 120, 24, setTarget, "primary")
    p.setBtn:SetPoint("LEFT", p.qty, "RIGHT", 6, 0)
    p.setBtn.tooltip = L["Ziel speichern.\nMenge leer = 1 Stück, Budget leer = Menge x Max-Preis.\nFilter (Seltenheit, Itemlevel, Stufe) gehören zum Ziel."]

    p.clearBtn = UI:Button(fr, "X", 24, 24, clearForm)
    p.clearBtn:SetPoint("LEFT", p.lvlMax, "RIGHT", 6, 0)
    p.clearBtn.tooltip = L["Alle Eingaben leeren"]
    UI:ChainEdits(allEdits)

    -- Zeile 3: Modus und Auslöser
    p.armBtn = UI:Button(p, "", 150, 26, function()
        Sn:ToggleArmed()
        p:Refresh()
    end, "primary")

    p.armBtn.tooltip = L["Sniper-Modus an/aus (auch /ahs sniper).\nNur aktiv, solange das Auktionshaus offen ist."]

    p.wheelBtn = UI:Button(p, L["Mausrad"], 80, 26, function()
        Sn:UseMouseWheel()
        setMessage(true, L["Kaufen mit dem Mausrad (hoch und runter)."])
    end)
    p.wheelBtn:SetPoint("LEFT", p.armBtn, "RIGHT", 6, 0)
    p.wheelBtn.tooltip = L["Mausrad als Auslöser (beide Richtungen)"]

    p.keyBtn = UI:Button(p, L["Eigene Taste"], 104, 26, function()
        OpenCapture(function(key)
            Sn:SetBinds(KeyToBinds(key))
            setMessage(true, L["Kaufen jetzt mit: "] .. Sn:GetBindsText())
        end)
    end)
    p.keyBtn:SetPoint("LEFT", p.wheelBtn, "RIGHT", 6, 0)
    p.keyBtn.tooltip = L["Eigene Taste oder Maustaste als Auslöser wählen"]

    p.filterBtn = UI:Button(p, "", 86, 26, function()
        A.db.settings.sniperFilters = not A.db.settings.sniperFilters
        p:Layout()
    end)
    p.filterBtn:SetPoint("LEFT", p.keyBtn, "RIGHT", 6, 0)
    p.filterBtn.tooltip = L["Filter ein-/ausblenden:\nSeltenheit (Grau bis Episch), Itemlevel, Stufe"]

    p.status = UI:Label(p, "", "GameFontHighlightSmall", C.text)
    p.status:SetWidth(440)

    -- Ziele
    p.targets = UI:Table(p, {
        columns = {
            { key = "name", title = L["Ziel"], width = 118 },
            { key = "maxPrice", title = L["Max/St."], width = 62, align = "RIGHT" },
            -- SN2 (Anweisung 10.11.): Stand ganz lesbar ("50/100 gekauft · Budget 5g aufgebraucht"); Filter im Tooltip
            { key = "qty", title = L["Stand"], width = 236 },
        },
        rows = 8,
        rowHeight = 22,
        idKey = "key",
        sortKey = "name",
        cell = function(e, key)
            local done = e.done
            local function dim(s) return done and ("|cff777777" .. s .. "|r") or s end
            if key == "name" then
                local n = UI.ItemName(e)
                if Sn:OthersFaster(e) then n = "|cffffcc00!|r " .. n end      -- D3
                if e.watch then n = "|cff33dd55" .. L["[Wächter]"] .. "|r " .. n end
                if Sn.search and Sn.search.targetKey == e.key then n = "|cffffcc33> |r" .. n end
                return dim(n)
            end
            if key == "filter" then return dim(e.filter) end
            if key == "maxPrice" then
                if e.overValue and not done then return "|cffffcc00" .. A:FormatMoney(e.maxPrice, true) .. "|r" end   -- H4
                return dim(A:FormatMoney(e.maxPrice, true))
            end
            if key == "qty" then
                local s = Sn:ProgressText(e.target)
                if e.bought >= e.qty then return "|cff33dd55" .. s .. "|r" end
                if Sn:BudgetUsedUp(e.target) then return "|cffffcc00" .. s .. "|r" end
                return s
            end
            if key == "filter" then return dim(e.filter) end
        end,
        sortValue = function(e, key)
            if key == "name" or key == "filter" then return string.lower(e[key]) end
            if key == "qty" then return e.qtyLeft end
            if key == "budget" then return e.budgetLeft end
            return e[key]
        end,
        tooltipLines = function(e, tt)          -- H4, D2, D3
            local t = e.target
            if e.filter and e.filter ~= L["alle"] then tt:AddLine(L["Filter: "] .. e.filter, 0.8, 0.8, 0.8) end
            -- SN4: Stückzahl aus dem Budget
            if t and t.maxPrice and t.maxPrice > 0 and t.budget then
                tt:AddLine(string.format(L["Mit %s Budget und höchstens %s kauft der Sniper höchstens %d Stück."],
                    A:FormatMoney(t.budget), A:FormatMoney(t.maxPrice), Sn:BudgetPieces(t)), 0.9, 0.9, 0.9, true)
            end
            if t and Sn:BudgetUsedUp(t) and (t.bought or 0) < (t.qty or 0) then
                tt:AddLine(Sn:BudgetText(t), 1, 0.8, 0, true)
            end
            if e.overValue then
                tt:AddLine(string.format(L["Max über Verkaufswert – jeder Kauf verliert ca. %s/Stück"], A:FormatMoney(e.overValue)), 1, 0.8, 0, true)
            end
            if (e.hitN or 0) > 0 then
                tt:AddLine(string.format(L["Treffer %d · gekauft %d (%d %%)"], e.hitN, e.boughtN or 0,
                    math.floor((e.boughtN or 0) / e.hitN * 100 + 0.5)), 0.8, 0.8, 0.8)
            end
            if Sn:OthersFaster(e) then tt:AddLine(L["Hier sind andere schneller – anderes Ziel wählen?"], 1, 0.8, 0, true) end
        end,
        onClick = function(e)
            p.selected = e.key
            local t = e.target
            -- Werte ins Formular übernehmen (zum Ändern)
            if t.kind == "item" then UI:SetItemInput(p.item, t.itemID) else p.item:SetText(t.text); p.item.itemID = nil end
            p.max:SetCopper(t.maxPrice)
            p.qty:SetText(tostring(t.qty))
            p.budget:SetCopper(t.budget)
            p.ilvlMin:SetText(t.ilvlMin and tostring(t.ilvlMin) or "")
            p.ilvlMax:SetText(t.ilvlMax and tostring(t.ilvlMax) or "")
            p.lvlMin:SetText(t.lvlMin and tostring(t.lvlMin) or "")
            p.lvlMax:SetText(t.lvlMax and tostring(t.lvlMax) or "")
            for _, ed in ipairs(allEdits) do ed:UpdatePlaceholder() end
            p.qualPicker:SetSet(Sn:QualSet(t))
            if Sn:FilterText(t) ~= L["alle"] and not A.db.settings.sniperFilters then
                A.db.settings.sniperFilters = true
                p:Layout()
            end
            if A:IsAHOpen() and not e.done then
                local ok, msg, soft = Sn:Search(e.key)
                if not soft then setMessage(ok, msg) end
            else
                setMessage(true, L["Ziel gewählt - Werte stehen oben zum Ändern."])
            end
            p:Refresh()
        end,
        action = {
            text = "X", width = 26,
            tooltip = L["Ziel entfernen"],
            onClick = function(e)
                setMessage(Sn:RemoveTarget(e.key))
            end,
        },
        emptyText = L["Noch keine Ziele.\nOben Item, Max-Preis, Menge und Budget eingeben."],
    })


    p.searchBtn = UI:Button(p, L["Jetzt suchen"], 130, 28, function()
        local ok, msg, soft = Sn:CheckNext()
        setMessage(ok or soft, msg)
        p:Refresh()
    end)
    p.searchBtn:SetPoint("TOPLEFT", p.targets, "BOTTOMLEFT", 0, -8)
    p.searchBtn.tooltip = L["Nächstes offenes Ziel sofort suchen"]

    p.buyBtn = UI:Button(p, L["Kaufen"], 130, 28, function()
        local ok, msg = Sn:OnTrigger()
        setMessage(ok, msg)
        p:Refresh()
    end, "primary")
    p.buyBtn:SetPoint("LEFT", p.searchBtn, "RIGHT", 6, 0)
    -- S3: Preis bestätigt -> Knopf blinkt bis Kauf oder Abbruch (Sn.buyAlert)
    p.buyBtn:HookScript("OnUpdate", function(self)
        if Sn.buyAlert and Sn.pending then
            local t = GetTime() * 4
            self:SetAlpha(0.45 + 0.55 * (0.5 + 0.5 * math.sin(t)))
            self.blinking = true
        elseif self.blinking then
            self.blinking = nil
            self:SetAlpha(1)
        end
    end)
    -- WoW Forever: Waren immer mit 2 Rasten (1. reserviert, 2. kauft), Entscheid der Prüf-Sitzung 9. Nov. 09:35
    p.buyBtn.tooltip = (Sn.InstantEnabled and Sn:InstantEnabled())
        and L["Gleiche Wirkung wie Mausrad / eigene Taste:\nkauft das nächste passende Angebot (auch Waren mit einem Druck)."]
        or L["Gleiche Wirkung wie Mausrad / eigene Taste:\nkauft das nächste passende Angebot (Waren: 2x drücken)."]

    p.resetBtn = UI:Button(p, L["Zähler zurücksetzen"], 150, 28, function()
        if not p.selected then setMessage(false, L["Erst ein Ziel in der Liste anklicken."]) return end
        setMessage(Sn:ResetProgress(p.selected))
    end)
    p.resetBtn:SetPoint("LEFT", p.buyBtn, "RIGHT", 6, 0)
    p.resetBtn.tooltip = L["Gekaufte Menge und ausgegebenes Gold des gewählten Ziels auf 0 setzen"]

    p.message = UI:Label(p, "", "GameFontHighlightSmall", C.textDim)
    p.message:SetPoint("TOPLEFT", p.searchBtn, "BOTTOMLEFT", 0, -6)
    p.message:SetWidth(440)

    -- ================= Rechte Seite: Angebote =================
    local right = CreateFrame("Frame", nil, p)
    right:SetPoint("TOPLEFT", 456, 0)
    right:SetPoint("BOTTOMRIGHT", 0, 0)

    p.resultTitle = UI:Label(right, L["Noch nichts gesucht"], "GameFontNormalLarge", C.accent)
    p.resultTitle:SetPoint("TOPLEFT", 0, 0)
    p.resultTitle:SetWidth(470)
    p.resultInfo = UI:Label(right, "", "GameFontHighlightSmall", C.textDim)
    p.resultInfo:SetPoint("TOPLEFT", 0, -24)
    p.resultInfo:SetWidth(470)

    local function resultItem()
        return Sn.result and Sn.result.itemID
    end

    p.openBtn = UI:Button(right, L["Im Auktionshaus zeigen"], 170, 24, function()
        setMessage(Sn:OpenInAH(resultItem()))
    end)
    p.openBtn:SetPoint("TOPLEFT", 0, -46)

    p.chartBtn = UI:Button(right, L["Preisverlauf"], 100, 24, function()
        local id = resultItem()
        if id then UI:OpenChart(id) end
    end)
    p.chartBtn:SetPoint("LEFT", p.openBtn, "RIGHT", 6, 0)

    local STATUS_COLOR = {
        ["kaufbar"] = "33dd55", ["gekauft"] = "00d1d1", ["zu teuer"] = "888888", ["Filter"] = "888888",
        ["eigenes"] = "888888", ["Menge erreicht"] = "888888", ["Lockangebot"] = "ff9933",
    }

    p.listings = UI:Table(right, {
        columns = {
            { key = "price", title = L["Preis/Stück"], width = 110, align = "RIGHT" },
            { key = "pct", title = L["% Markt"], width = 52, align = "RIGHT",
              tooltip = L["Preis in Prozent vom Marktwert (Median 14 Tage).\nGrün = günstig, Orange/Rot = teuer."] },
            { key = "qty", title = L["Menge"], width = 52, align = "RIGHT" },
            { key = "cost", title = L["Gesamt"], width = 100, align = "RIGHT" },
            { key = "ilvl", title = "iLvl", width = 40, align = "RIGHT" },
            { key = "status", title = "", width = 96 },
        },
        rows = 14,
        rowHeight = 22,
        itemTooltip = false,
        cell = function(l, key)
            if key == "price" then
                return l.status == "kaufbar" and ("|cff33dd55" .. A:FormatMoney(l.price) .. "|r") or A:FormatMoney(l.price)
            end
            if key == "pct" then
                local id = Sn.result and Sn.result.itemID
                return A:FormatMarketPercent(id and A:GetMarketPercent(id, l.price))
            end
            if key == "qty" then
                if l.planned and l.planned < l.qty then return l.planned .. L[" von "] .. l.qty end
                return tostring(l.qty)
            end
            if key == "cost" then return A:FormatMoney(l.price * l.qty) end
            if key == "ilvl" then return l.ilvl and tostring(l.ilvl) or "-" end
            if key == "status" then
                local s = l.status or ""
                if s == "" then return "" end
                return "|cff" .. (STATUS_COLOR[s] or "ff9933") .. L[s] .. "|r"     -- Status-Codes erst hier übersetzen
            end
        end,
        emptyText = L["Hier erscheinen die Angebote\nnach einer Suche."],
    })
    p.listings:Fill(0, -80, 0, 64)      -- darunter die Zusammenfassung

    p.summary = UI:Label(right, "", "GameFontHighlight", C.text)
    p.summary:SetPoint("TOPLEFT", p.listings, "BOTTOMLEFT", 0, -8)
    p.summary:SetWidth(470)
    -- Gesamtmenge: was bei diesem Item insgesamt gekauft wird
    p.total = UI:Label(right, "", "GameFontHighlight", C.accent)
    p.total:SetPoint("TOPLEFT", p.summary, "BOTTOMLEFT", 0, -6)
    p.total:SetWidth(470)

    -- Anordnung je nachdem, ob die Filter sichtbar sind
    function p:Layout()
        -- Filterzeile (Seltenheit, Itemlevel, Stufe) ist immer sichtbar
        local open = true
        self.filterRow:Show()
        self.filterBtn:Hide()
        local y = open and -140 or -108
        self.armBtn:ClearAllPoints()
        self.armBtn:SetPoint("TOPLEFT", 0, y)
        self.status:ClearAllPoints()
        self.status:SetPoint("TOPLEFT", 0, y - 30)
        self.targets:FillColumn(0, y - 62, 448, 64)    -- zwei Zeilen Status (Kaufen mit … / Heute: …)    -- linke Spalte; darunter Knöpfe und Meldung
        self.filterBtn:SetText(open and L["Filter <<"] or L["Filter >>"])
    end

    -- Formular mit einem Item vorbefüllen (Rechtsklick-Menü "Als Sniper-Ziel")
    function p:Prefill(itemID)
        UI:SetItemInput(self.item, itemID)
        local price = A:GetCurrent(itemID)
        self.max:SetCopper(price)
        self.qty:SetText("")
        self.budget:Clear()
        for _, ed in ipairs(allEdits) do ed:UpdatePlaceholder() end
        self.max:SetFocus()
        setMessage(true, L["Max-Preis, Menge und Budget prüfen, dann 'Ziel setzen'. (Vorschlag = aktueller Preis)"])
    end

    function p:Refresh()
        local db = A.db.sniper
        self.armBtn:SetText(db.armed and L["Sniper-Modus: AN"] or L["Sniper-Modus: AUS"])
        self.status:SetText(L["Kaufen mit: |cffffd700"] .. Sn:GetBindsText() .. L["|r     "] .. Sn:GetStatusText()
            .. "\n|cffaaaaaa" .. Sn:StatsText() .. "|r")
        self:UpdateQualityButtons()

        self.targets.selectedID = self.selected
        self.targets:SetData(Sn:GetTargets(), true)

        local plan = Sn:IsResultFresh() and Sn:PlanNext() or nil
        self.buyBtn:SetActive(Sn.pending ~= nil or plan ~= nil)
        self.searchBtn:SetActive(not Sn.search)

        if Sn.search then
            local t = Sn:GetTarget(Sn.search.targetKey)
            self.resultTitle:SetText(t and Sn:TargetName(t) or "?")
            self.resultInfo:SetText(L["|cffffcc33Suche läuft ...|r"])
            -- Gesamtzeile stehen lassen, solange der Treffer desselben Ziels noch gilt (Forever: ohne Vorab-Reservierung
            -- sucht der Sniper weiter, während der Treffer wartet)
            if self.total then
                local tq, tc, tn
                if Sn.result and Sn.result.key == Sn.search.targetKey and Sn:IsResultFresh() then tq, tc, tn = Sn:PlanTotal() end
                if tq then
                    local txt = string.format(L["Insgesamt: %d Stück für %s (Ø %s/Stück)"], tq, A:FormatMoney(tc), A:FormatMoney(math.floor(tc / math.max(1, tq) + 0.5)))
                    if tn and tn > 1 then txt = txt .. string.format(L["  -  %d Käufe"], tn) end
                    self.total:SetText(txt)
                else
                    self.total:SetText("")
                end
            end
            -- Angebote eines anderen Ziels nicht unter dem neuen Namen stehen lassen
            if not (Sn.result and Sn.result.key == Sn.search.targetKey) then
                self.listings:SetData({})
                if self.summary then self.summary:SetText("") end
            end
            return
        end

        local r = Sn.result
        if not r then
            self.resultTitle:SetText(L["Noch nichts gesucht"])
            self.resultInfo:SetText(A:IsAHOpen() and L["Sniper-Modus einschalten oder 'Jetzt suchen' klicken."] or L["|cffff5544Auktionshaus öffnen, um zu suchen.|r"])
            self.listings:SetData({})
            self.summary:SetText("")
            -- SN3: aufgebrauchtes Budget auch ohne Suchergebnis als Kopfzeile
            local sel = self.selected and Sn:GetTarget(self.selected)
            local cand = sel and { sel } or {}
            if not sel then for _, e in ipairs(Sn:GetTargets()) do cand[#cand + 1] = e.target end end
            for _, tt in ipairs(cand) do
                if tt and (tt.bought or 0) < (tt.qty or 0) and Sn:BudgetUsedUp(tt) then
                    self.summary:SetText("|cffffcc00" .. Sn:BudgetText(tt) .. "|r")
                    break
                end
            end
            self.total:SetText("")
            return
        end

        local t = Sn:GetTarget(r.key)
        self.resultTitle:SetText(r.itemID and A:GetItemName(r.itemID) or (t and Sn:TargetName(t) or "?"))
        local info = L["gesucht "] .. A:FormatAgo(r.stamp) .. "   |   " .. #r.listings .. L[" Angebote"]
        if t then
            local qLeft, bLeft = Sn:Remaining(t)
            info = info .. L["   |   noch "] .. math.max(0, qLeft) .. L[" Stück, "] .. A:FormatMoney(math.max(0, bLeft)) .. L[" Budget"]
        end
        if r.candidates and r.candidates > 1 then info = info .. "   |   " .. r.candidates .. L[" passende Items"] end
        self.resultInfo:SetText(info)

        Sn:PlanNext()   -- Status der Angebote aktualisieren
        self.listings:SetData(A:NoBait(r.listings))
        local tq, tc, tn = nil, nil, nil
        if Sn:IsResultFresh() then tq, tc, tn = Sn:PlanTotal() end
        if tq then
            local txt = string.format(L["Insgesamt: %d Stück für %s (Ø %s/Stück)"], tq, A:FormatMoney(tc), A:FormatMoney(math.floor(tc / math.max(1, tq) + 0.5)))
            if tn and tn > 1 then txt = txt .. string.format(L["  -  %d Käufe"], tn) end
            self.total:SetText(txt)
        else
            self.total:SetText("")
        end

        if Sn.pending then
            local pd = Sn.pending
            if pd.state == "ready" and pd.auto then
                self.summary:SetText(L["|cff33dd55Nächster Kauf: "] .. pd.qty .. L[" Stück für "] .. A:FormatMoney(pd.total or pd.expected) .. L["|r  ("] .. Sn:GetBindsText() .. ")")
            elseif pd.state == "ready" then
                self.summary:SetText(L["|cff33dd55Reserviert: "] .. pd.qty .. L[" Stück für "] .. A:FormatMoney(pd.total or pd.expected) .. " - " .. Sn:GetBindsText() .. L[" zum Bestätigen|r"])
            else
                self.summary:SetText(L["|cffffcc33Preis wird vom Server geprüft ...|r"])
            end
        elseif t and (t.bought or 0) < (t.qty or 0) and Sn:BudgetUsedUp(t) then
            -- SN3: Kopfzeile, solange das Budget aufgebraucht ist
            self.summary:SetText("|cffffcc00" .. Sn:BudgetText(t) .. "|r")
        elseif not Sn:IsResultFresh() then
            -- SN1: gekaufte Stück dieser Suche nennen
            local bn, bsum, missed = Sn:ResultBought(r)
            if bn > 0 or missed > 0 then
                self.summary:SetText("|cffaaaaaa" .. string.format(L["Ergebnis ist veraltet – in dieser Suche gekauft: %d Stück für %s · verpasst %d – neue Suche nötig."],
                    bn, A:FormatMoney(bsum), missed) .. "|r")
            else
                self.summary:SetText(L["|cffaaaaaaErgebnis ist veraltet - neue Suche nötig.|r"])
            end
        elseif plan then
            self.summary:SetText(L["|cff33dd55Nächster Kauf: "] .. plan.qty .. L[" Stück für "] .. A:FormatMoney(plan.total) .. L["|r  ("] .. Sn:GetBindsText() .. ")")
        elseif #r.listings == 0 then
            self.summary:SetText(r.itemID and L["|cffaaaaaaKeine Angebote gefunden.|r"] or L["|cffaaaaaaKein passendes Item unter deinem Max-Preis.|r"])
        else
            self.summary:SetText(L["Nichts Passendes unter deinem Max-Preis. Günstigstes: "] .. A:FormatMoney(r.listings[1].price))
        end
    end

    -- regelmäßig auffrischen, solange etwas läuft
    local elapsed = 0
    p:SetScript("OnUpdate", function(self, dt)
        elapsed = elapsed + (dt or 0)
        if elapsed >= 0.5 then
            elapsed = 0
            if Sn.search or Sn.pending or (A.db.sniper.armed and A:IsAHOpen()) then self:Refresh() end
        end
    end)

    p:UpdateQualityButtons()
    p:Layout()
    return p
end

UI:RegisterTab("sniper", "Sniper", 3.5, BuildSniper)

-- nur die Reiter neu zeichnen, die den Sniper zeigen (sonst baut z.B. der Markt bei jeder Sniper-Suche neu auf)
A:On("SNIPER_CHANGED", function()
    if UI.activeTab == "sniper" or UI.activeTab == "watcher" then UI:RefreshActive() end
end)

-- Beim Design-Wechsel das Tasten-Fenster neu bauen
A:On("THEME_CHANGED", function()
    if capture then capture:Hide(); capture = nil end
end)
