if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Messreihe "Ausrüstung in ganzen Silbern" (Entscheid des Nutzers 10.11. 10:15, Anweisung S1-S5)
--
-- Frage: Warum lehnt der Server bei Ausrüstung Kupferbeträge ab ("Interner Auktion-Fehler" bei 199c, 200c geht), bei
-- Waren aber nicht? Die Rundung in Seller.lua (ganze Silber, "−1 Silber") bleibt, bis die Messung etwas anderes BELEGT.
--
-- S1 Ein billiges Ausrüstungsteil (grau/weiss, vom Spieler bestätigt): Sofortkauf 1s 00c, 1s 01c, 1s 50c, 1s 99c,
--    2s 00c, 10s 50c, 1g 00s 01c und einmal Gebot 1s 50c + Sofortkauf 2s - je einstellen, Ergebnis, gleich abbrechen.
-- S2 Gegenprobe Ware: 1 Stück einer stapelbaren Ware mit 1s 99c.
-- S3 Blizzard-Vergleich: nur Anleitung im Bericht (der Spieler macht es von Hand).
-- S4 Ergebnis ins Protokoll (AUSRUESTUNG-PREIS) und in den Testbericht, ohne Namen.
-- S5 Kosten-Schutz: höchstens 10 Einstellungen, Kosten vorher anzeigen, Zustimmung nötig, Abbruch jederzeit.
--
-- ECHT: Es wird wirklich eingestellt und abgebrochen - NUR nach Zustimmung und NUR per Klick (jeder Schritt ein
-- Klick, WoW verlangt dafür ein Hardware-Ereignis). Im Testmodus/in der Testroutine nie.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local GetItemInfo = GetItemInfo or (C_Item and C_Item.GetItemInfo)
local A = AHAnalyzerPro
local L = A.L

local MR = {}
A.SilverTest = MR

MR.MAX_POSTS = 10
-- { Sofortkauf, Gebot, Art } - Art "gear" (S1) oder "com" (S2)
MR.PLAN = {
    { 100 }, { 101 }, { 150 }, { 199 }, { 200 }, { 1050 }, { 10001 },
    { 200, 150 },
    { 199, nil, "com" },
}

function MR:API() return A.AH end                       -- eigene Funktion (Seam für die Testroutine)
function MR:Data()
    if self.testDB then return self.testDB end
    return A.db and A.db.silverTest
end

-- graue/weisse, nicht stapelbare Ausrüstungsteile (billigste zuerst) und die billigste stapelbare Ware in den Taschen.
-- In WoW Forever kommt ein abgebrochenes Teil per Post zurück - darum je Einstellung ein eigenes Teil.
function MR:PickItems()
    local Se = A.Seller
    local gear, com
    local gearList = {}
    local okB, bag = false, {}
    if Se and Se.GetBagItems then okB, bag = pcall(Se.GetBagItems, Se, true) end
    for _, e in ipairs(okB and bag or {}) do
        local info = { pcall(GetItemInfo, e.itemID) }
        local quality, stack, classID, vendor = info[4], info[9], info[13], info[12]
        if info[1] and info[2] then
            if (classID == 2 or classID == 4) and (quality or 9) <= 1 and (stack or 1) == 1 and not e.bound then
                for _ = 1, math.max(1, e.count or 1) do gearList[#gearList + 1] = { itemID = e.itemID, vendor = vendor or 0 } end
            elseif (stack or 1) > 1 then
                if not com or (vendor or 0) < com.vendor then com = { itemID = e.itemID, vendor = vendor or 0 } end
            end
        end
    end
    table.sort(gearList, function(a, b) return a.vendor < b.vendor end)
    gear = gearList[1]
    return gear, com, gearList
end

-- Einzahlungen der ganzen Reihe (kürzeste Laufzeit). In Forever kommt beim Abbrechen meist nichts zurück.
function MR:Costs(gear, com)
    local sum = 0
    for _, p in ipairs(self.PLAN) do
        local id = (p[3] == "com") and (com and com.itemID) or (gear and gear.itemID)
        if id then
            local ok, d = pcall(A.ListingDeposit, A, id, 1, A.DURATION_HOURS[1] or 2, 1)
            sum = sum + ((ok and d) or 0)
        end
    end
    return sum
end

-- Vorbereiten (zeigt Plan und Kosten). Rückgabe ok, Text
function MR:Prepare()
    if A:Simulated() and not self.testDB then return false, L["Messreihe: im Testmodus/in der Testroutine nicht möglich (es würde echt eingestellt)."] end
    if not A:IsAHOpen() and not self.testDB then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    local gear, com, gearList = self:PickItems()
    if self.testItems then gear, com, gearList = self.testItems.gear, self.testItems.com, nil end
    if not gear then return false, L["Messreihe: kein graues oder weisses Ausrüstungsteil in den Taschen."] end
    local gearPosts = 0
    for _, p in ipairs(self.PLAN) do if p[3] ~= "com" then gearPosts = gearPosts + 1 end end
    self.run = { gear = gear, com = com, gearList = gearList, used = {}, i = 0, posts = 0, consent = false, step = "post", rows = {}, cost = self:Costs(gear, com) }
    local text = string.format(L["Messreihe: %d Einstellungen, jede wird gleich wieder abgebrochen. Kosten (Einzahlungen) bis %s. Jeder Schritt ist ein Klick."],
        math.min(#self.PLAN, self.MAX_POSTS), A:FormatMoney(self.run.cost))
    if gearList and #gearList < gearPosts then
        text = text .. " " .. string.format(L["Nur %d passende Ausrüstungsteile in den Taschen (abgebrochene kommen per Post zurück) - es werden nur so viele Ausrüstungs-Preise gemessen."], #gearList)
    end
    return true, text
end

function MR:Confirm()
    if not self.run then return false end
    self.run.consent = true
    return true
end

function MR:Stop(reason)
    local r = self.run
    if not r then return end
    r.stopped = reason or "abgebrochen"
    self:Save()
    self.run = nil
end

-- ein Klick: nächster Schritt (einstellen bzw. die eben eingestellte Auktion abbrechen)
function MR:Step()
    local r = self.run
    if not r then return false, "übersprungen" end
    if not r.consent then return false, "übersprungen" end
    if r.wait then return false, L["Messreihe: warte auf die Antwort des Servers ..."] end
    local C = self:API()
    if r.step == "cancel" then
        local id = self:FindOwn(r.last)
        if not id then return false, L["Messreihe: eigene Auktion noch nicht gefunden - gleich nochmal."] end
        local ok, err = pcall(C.CancelAuction, id)
        r.last.cancel = ok and "abgebrochen" or ("Fehler " .. tostring(err))
        r.step, r.wait = "post", ok and { kind = "cancel", t = GetTime() } or nil
        return ok, r.last.cancel
    end
    r.i = r.i + 1
    local p = self.PLAN[r.i]
    if not p or r.posts >= self.MAX_POSTS then self:Save(); self.run = nil; return false, L["Messreihe fertig."] end
    local com = p[3] == "com"
    local item = com and r.com or r.gear
    if not com and r.gearList then
        -- je Einstellung ein eigenes Teil (das abgebrochene kommt per Post zurück)
        item = nil
        local Se = A.Seller
        local seen = {}
        for _, g in ipairs(r.gearList) do
            seen[g.itemID] = (seen[g.itemID] or 0) + 1
            local have = Se and Se:CountInBags(g.itemID) or 0
            if have >= 1 and (r.used[g.itemID] or 0) < math.min(seen[g.itemID], have + (r.used[g.itemID] or 0)) then item = g; break end
        end
        if item then r.used[item.itemID] = (r.used[item.itemID] or 0) + 1 end
    end
    if not item then
        r.rows[#r.rows + 1] = { buyout = p[1], bid = p[2], kind = com and "com" or "gear", result = "kein Item" }
        return self:Step()
    end
    local Se = A.Seller
    local loc
    if self.testItems then loc = "loc" else
        local _, entry = Se:CountInBags(item.itemID)
        loc = entry and entry.slots and entry.slots[1] and entry.slots[1].loc
    end
    if not loc then return false, L["Messreihe: Item nicht mehr in den Taschen."] end
    local row = { buyout = p[1], bid = p[2], kind = com and "com" or "gear", itemID = item.itemID }
    r.rows[#r.rows + 1] = row
    r.last, r.posts = row, r.posts + 1
    self.active = true
    local ok, err
    if com then ok, err = pcall(C.PostCommodity, loc, 1, 1, p[1])
    else ok, err = pcall(C.PostItem, loc, 1, 1, p[2], p[1]) end
    if not ok then
        row.result, row.msg = "Fehler", tostring(err)
        self.active = nil
        return false, row.msg
    end
    r.wait = { kind = "post", t = GetTime() }
    return true, string.format(L["Messreihe: eingestellt mit %s - Antwort abwarten, dann Klick zum Abbrechen."], A:FormatMoney(p[1]))
end

-- eigene Auktion zur letzten Einstellung (Menge 1, gleicher Sofortkauf)
function MR:FindOwn(row)
    if self.testOwn then return self.testOwn(row) end
    local Se = A.Seller
    for _, o in ipairs(Se and Se.owned or {}) do
        if o.itemID == row.itemID and not o.sold and (o.rawBuyout == row.buyout or o.buyout == row.buyout or o.unitPrice == row.buyout) then return o.auctionID end
    end
    return nil
end

-- Antworten des Servers
function MR:OnEvent(event, a1, a2)
    local r = self.run
    if not (r and r.wait) then return end
    if r.wait.kind == "post" then
        if event == "AUCTION_HOUSE_AUCTION_CREATED" then
            r.last.result = "erstellt"
            r.wait, r.step = nil, "cancel"
            local Se = A.Seller
            if Se and Se.QueryOwned and not self.testItems then pcall(Se.QueryOwned, Se) end
        elseif event == "AUCTION_HOUSE_SHOW_ERROR" or event == "UI_ERROR_MESSAGE" then
            r.last.result = "Fehler"
            local msg = type(a2) == "string" and a2 or (type(a1) == "string" and a1) or nil
            if not msg and A.Seller and A.Seller.ErrorText then msg = select(1, A.Seller:ErrorText(a1)) or select(2, A.Seller:ErrorText(a1)) end
            r.last.msg = r.last.msg or msg or tostring(a1)
            r.wait, r.step = nil, "post"
        end
        self.active = nil
        if not r.wait then self:Log(r.last) end
    elseif r.wait.kind == "cancel" and event == "AUCTION_CANCELED" then
        r.wait = nil
    end
end

function MR:Log(row)
    if A.Diag and not self.testDB then
        pcall(A.Diag.Add, A.Diag, "AUSRUESTUNG-PREIS", string.format("%s · Sofortkauf %d%s · %s%s", row.kind == "com" and "Ware" or "Ausrüstung",
            row.buyout, row.bid and (" · Gebot " .. row.bid) or "", tostring(row.result), row.msg and (" · " .. row.msg) or ""))
    end
end

-- Ergebnis speichern (neue Tabelle db.silverTest, ohne Namen: nur Zahlen und Fehlertexte des Spiels)
function MR:Save()
    local r = self.run
    if not r then return end
    local db = self.testDB
    if not db then
        if not A.db or A:Simulated() then return end
        A.db.silverTest = A.db.silverTest or {}
        db = A.db.silverTest
    end
    local rows = {}
    for _, x in ipairs(r.rows) do
        rows[#rows + 1] = string.format("%s;%d;%s;%s;%s;%s", x.kind, x.buyout, tostring(x.bid or ""), tostring(x.result or "?"),
            tostring(x.cancel or ""), tostring(x.msg or ""):gsub(";", ","))
    end
    db.t, db.rows, db.stopped, db.vendor = time(), rows, r.stopped, r.gear and r.gear.vendor
end

local evt = CreateFrame("Frame")
for _, e in ipairs({ "AUCTION_HOUSE_AUCTION_CREATED", "AUCTION_HOUSE_SHOW_ERROR", "UI_ERROR_MESSAGE", "AUCTION_CANCELED" }) do pcall(evt.RegisterEvent, evt, e) end
evt:SetScript("OnEvent", function(_, event, a1, a2)
    if MR.run and not MR.testItems then pcall(MR.OnEvent, MR, event, a1, a2) end
end)

-- Bericht (Testbericht, Teil server): Tabelle der letzten Messreihe + Anleitung S3
function MR:Report()
    local db = self:Data()
    local out = { "Einstellen Ausrüstung: Messreihe" }
    if not (db and db.rows and #db.rows > 0) then
        out[#out + 1] = "  noch nicht gemessen - /ahs messreihe am offenen Auktionshaus (mit Zustimmung, echte Einzahlungen)"
    else
        for _, line in ipairs(db.rows) do
            local kind, buyout, bid, result, cancel, msg = line:match("^([^;]*);([^;]*);([^;]*);([^;]*);([^;]*);(.*)$")
            out[#out + 1] = string.format("  %s · Sofortkauf %s%s · %s%s%s", kind == "com" and "Ware" or "Ausrüstung", A:FormatMoney(tonumber(buyout) or 0),
                (bid and bid ~= "") and (" · Gebot " .. A:FormatMoney(tonumber(bid) or 0)) or "", tostring(result),
                (cancel and cancel ~= "") and (" · " .. cancel) or "", (msg and msg ~= "") and (" · " .. msg) or "")
        end
        if db.stopped then out[#out + 1] = "  abgebrochen: " .. tostring(db.stopped) end
    end
    out[#out + 1] = "  S3 von Hand: dasselbe Teil im Blizzard-Fenster mit 1s 99c einstellen - lässt das Fenster Kupfer zu, was meldet der Server?"
    return out
end

-- ------------------------------------------------------------
-- Fenster (/ahs messreihe)
-- ------------------------------------------------------------
function MR:Show()
    local UI = A.UI
    if not UI then return end
    local ok, text = self:Prepare()
    if not ok then A:Print(text); return end
    if not self.win then
        local w = UI:Dialog("AHSentinelSilverTest", 520, 260, L["Messreihe Ausrüstung (ganze Silber)"])
        w.text = UI:Label(w, "", "GameFontHighlightSmall", UI.C.text)
        w.text:SetPoint("TOPLEFT", 16, -40)
        w.text:SetWidth(488)
        w.text:SetJustifyH("LEFT")
        w.yes = UI:Button(w, L["Zustimmen"], 120, 24, function() MR:Confirm(); w:Refresh() end, "primary")
        w.yes:SetPoint("BOTTOMLEFT", 16, 14)
        w.step = UI:Button(w, L["Nächster Schritt"], 160, 24, function()
            local _, msg = MR:Step()
            if msg then A:Print(msg) end
            w:Refresh()
        end, "primary")
        w.step:SetPoint("LEFT", w.yes, "RIGHT", 8, 0)
        w.stop = UI:Button(w, L["Abbrechen"], 120, 24, function() MR:Stop("vom Nutzer"); w:Hide() end)
        w.stop:SetPoint("LEFT", w.step, "RIGHT", 8, 0)
        function w:Refresh()
            local r = MR.run
            local lines = { w.intro or "" }
            if r then
                for _, x in ipairs(r.rows) do
                    lines[#lines + 1] = string.format("%s %s%s: %s%s", x.kind == "com" and L["Ware"] or L["Ausrüstung"], A:FormatMoney(x.buyout),
                        x.bid and (" / " .. A:FormatMoney(x.bid)) or "", tostring(x.result or "..."), x.cancel and (" · " .. x.cancel) or "")
                end
            else lines[#lines + 1] = L["Messreihe fertig."] end
            w.text:SetText(table.concat(lines, "\n"))
            if w.yes.SetActive then w.yes:SetActive(r ~= nil and not r.consent) end
            if w.step.SetActive then w.step:SetActive(r ~= nil and r.consent) end
        end
        self.win = w
    end
    self.win.intro = text
    self.win:Show()
    self.win:Refresh()
end
