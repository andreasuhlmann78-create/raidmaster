local ADDON, ns = ...
local L = ns.L

-- Options window (OPT-ALLE, decision of the user 18 Nov. 2026 10:27 "nach Vorbild AHSentinel"; goal: every setting found in
-- under 5 seconds). Left a bar with the areas, right only the options of the chosen area: ONE column, at most 12 rows, no
-- scrolling; a search field on top filters over all areas. Every row: a short label, the switch or value on the right, the
-- explanation only in the tooltip. Rarely used options under "More" (folded). "Default" per area.
-- Only the DISPLAY is new: every setting keeps its saved key (ns.db.lifeline, ns.db.recipeAlert …) and its effect – the
-- commands (/ps line, /ps alarm …) stay. The window is built when it is first shown, the rows of an area when the area is shown.

local O = {}
ns.Options = O

O.WIDTH, O.HEIGHT = 540, 470
O.BAR_W = 150
O.ROW_H = 22
O.MAX_ROWS = 16             -- an area has at most 12 rows; a search shows the area names as headers in between
O.LABEL_MAX = 28            -- characters of a label (OPT-ALLE c)

local function DB() return ns.db or {} end
local function Refresh() if ns.RefreshAll then ns.RefreshAll() end end

---------------------------------------------------------------------------
-- The options: one entry per setting (key = saved field). kind: toggle | choice | number | money
---------------------------------------------------------------------------
O.AREAS = {
    { key = "window", label = "OPTW_AREA_WINDOW" },
    { key = "gold", label = "OPTW_AREA_GOLD" },
    { key = "help", label = "OPTW_AREA_HELP" },
}

O.LIST = {
    -- Window (the most used first)
    { key = "autoOpen", area = "window", kind = "toggle", label = "OPTW_AUTOOPEN", tip = "OPTW_AUTOOPEN_TIP", cmd = "/ps auto",
      get = function() return not (DB().autoOpen == false) end,
      set = function(v) if v then ns.db.autoOpen = nil else ns.db.autoOpen = false end end,
      default = true },
    { key = "theme", area = "window", kind = "toggle", label = "OPTW_THEME", tip = "OPTW_THEME_TIP", cmd = "/ps stil",
      get = function() return DB().theme ~= "classic" end,
      set = function(v)
          ns.db.theme = (not v) and "classic" or nil
          if ns.UI and ns.UI.ApplyTheme then ns.UI.ApplyTheme() end
      end,
      default = true },
    { key = "lifeline", area = "window", kind = "toggle", label = "OPTW_LIFELINE", tip = "OPTW_LIFELINE_TIP", cmd = "/ps line",
      get = function() return DB().lifeline ~= false end,
      set = function(v)
          ns.db.lifeline = v and true or false
          if ns.Lifeline and ns.Lifeline.RefreshBlizzard then ns.Lifeline.RefreshBlizzard() end
          Refresh()
      end,
      default = true },
    { key = "minimapButton", area = "window", kind = "toggle", label = "OPTW_MINIMAP", tip = "OPTW_MINIMAP_TIP", cmd = "/ps minimap",
      get = function() return not (DB().minimapButton == false) end,
      set = function(v)
          ns.db.minimapButton = v and true or false
          if ns.Minimap and ns.Minimap.Update then ns.Minimap.Update() end
      end,
      default = true },
    -- Gold & enchanting
    { key = "enchantGoal", area = "gold", kind = "choice", label = "OPTW_GOAL", tip = "OPTW_GOAL_TIP", cmd = "/ps ziel",
      choices = { { "gold", "OPTW_GOAL_GOLD", "GOAL_GOLD_TIP" }, { "sell", "OPTW_GOAL_SELL", "GOAL_SELL_TIP" }, { "both", "OPTW_GOAL_BOTH", "GOAL_BOTH_TIP" } },
      get = function() return ns.Disenchant and ns.Disenchant.Goal() or "gold" end,
      set = function(v) if ns.Disenchant and ns.Disenchant.SetGoal then ns.Disenchant.SetGoal(v, true) end end,
      default = "gold" },
    { key = "deMargin", area = "gold", kind = "number", label = "OPTW_MARGIN", tip = "OPTW_MARGIN_TIP", unit = "%", min = 0, max = 99,
      get = function() return tonumber(DB().deMargin) or 20 end,
      set = function(v) ns.db.deMargin = v; Refresh() end,
      default = 20 },
    { key = "goldRaid", area = "gold", kind = "toggle", label = "OPTW_RAID", tip = "OPTW_RAID_TIP",
      avail = function() return ns.Market and ns.Market.RaidFilterOffered and ns.Market.RaidFilterOffered() end,
      availTip = "OPTW_RAID_GONE",
      get = function() return DB().goldRaid == true end,
      set = function(v) ns.db.goldRaid = v and true or false; Refresh() end,
      default = false },
    { key = "todayCrates", area = "gold", kind = "toggle", label = "OPTW_CRATES", tip = "OPTW_CRATES_TIP", cmd = "/ps kisten", rare = true,
      avail = function() return ns.Favor and ns.Favor.Active and ns.Favor.Active() end,
      availTip = "FAVOR_ONLY_FOREVER",
      get = function() return DB().todayCrates == true end,
      set = function(v) ns.db.todayCrates = v and true or false; Refresh() end,
      default = false },
    { key = "vzMarkup", area = "gold", kind = "number", label = "OPTW_VZ_MARKUP", tip = "OPTW_VZ_MARKUP_TIP", unit = "%", min = 0, max = 1000, rare = true,
      get = function() return tonumber(DB().vzMarkup) or 20 end,
      set = function(v) ns.db.vzMarkup = v; Refresh() end,
      default = 20 },
    { key = "vzMinProfit", area = "gold", kind = "money", label = "OPTW_VZ_MIN", tip = "OPTW_VZ_MIN_TIP", rare = true,
      get = function() return tonumber(DB().vzMinProfit) or 0 end,
      set = function(v) ns.db.vzMinProfit = math.max(0, v); Refresh() end,
      default = 0 },
    -- Help & data
    { key = "recipeAlert", area = "help", kind = "toggle", label = "OPTW_ALARM", tip = "OPTW_ALARM_TIP", cmd = "/ps alarm",
      get = function() return DB().recipeAlert ~= false end,
      set = function(v) ns.db.recipeAlert = v and true or false; Refresh() end,
      default = true },
    { key = "merchantQty", area = "help", kind = "toggle", label = "OPTW_AMOUNT", tip = "OPTW_AMOUNT_TIP", cmd = "/ps menge",
      get = function() return DB().merchantQty ~= false end,
      set = function(v)
          ns.db.merchantQty = v and true or false
          if not v and ns.MerchantQty and ns.MerchantQty.Close then ns.MerchantQty.Close() end
      end,
      default = true },
    { key = "gsMarktAus", area = "help", kind = "toggle", label = "OPTW_MARKET", tip = "OPTW_MARKET_TIP", cmd = "/ps markt",
      get = function() return ns.MarketNetOn and ns.MarketNetOn() or false end,
      set = function(v) if ns.SetMarketNet then ns.SetMarketNet(v and true or false) end end,
      default = true },
}

O.byKey = {}
for _, o in ipairs(O.LIST) do O.byKey[o.key] = o end

function O.Text(k) return (k and L[k]) or tostring(k or "") end
function O.Available(o) return not o.avail or (o.avail() and true or false) end
function O.AreaLabel(key)
    for _, a in ipairs(O.AREAS) do if a.key == key then return O.Text(a.label) end end
    return key
end

-- the value of a setting / set it (number kinds are checked against their limits; nothing else is written)
function O.Get(key) local o = O.byKey[key]; if o then return o.get() end end
function O.Set(key, v)
    local o = O.byKey[key]
    if not (o and ns.db) then return false end
    if o.kind == "number" or o.kind == "money" then
        v = tonumber(v)
        if not v or v ~= v then return false end
        if o.kind == "money" then v = math.floor(v + 0.5) end
        if (o.min and v < o.min) or (o.max and v > o.max) or v < 0 then return false end
    elseif o.kind == "choice" then
        local okc = false
        for _, c in ipairs(o.choices) do if c[1] == v then okc = true end end
        if not okc then return false end
    else
        v = v and true or false
    end
    o.set(v)
    if O.frame and O.frame:IsShown() then O.Draw() end
    return true
end

-- "Default": every option of the area back to its default
function O.ResetArea(area)
    local n = 0
    for _, o in ipairs(O.LIST) do
        if o.area == area and O.Available(o) and O.Get(o.key) ~= o.default then
            if O.Set(o.key, o.default) then n = n + 1 end
        end
    end
    return n
end

-- the area that fits a view of the panel (OPT-ALLE e: the options button opens where you are)
function O.AreaForMode(mode)
    if mode == "gold" or mode == "disenchant" or mode == "favor" then return "gold" end
    return "window"
end

-- the rows to show: one area (rare ones folded under "More") or a search over all areas (with the area names)
function O.Rows(area, search, moreOpen)
    local rows = {}
    search = search and search:lower():gsub("^%s+", ""):gsub("%s+$", "") or ""
    if search ~= "" then
        local lastArea
        for _, a in ipairs(O.AREAS) do
            for _, o in ipairs(O.LIST) do
                if o.area == a.key then
                    local hay = (O.Text(o.label) .. " " .. O.Text(o.tip) .. " " .. (o.cmd or "")):lower()
                    if hay:find(search, 1, true) then
                        if lastArea ~= a.key then rows[#rows + 1] = { header = O.AreaLabel(a.key) }; lastArea = a.key end
                        rows[#rows + 1] = { opt = o }
                    end
                end
            end
        end
        if #rows == 0 then rows[1] = { info = L.OPTW_NOTHING } end
        return rows
    end
    local rare = 0
    for _, o in ipairs(O.LIST) do
        if o.area == area then
            if o.rare then rare = rare + 1 else rows[#rows + 1] = { opt = o } end
        end
    end
    if rare > 0 then
        rows[#rows + 1] = { more = true, open = moreOpen, count = rare }
        if moreOpen then
            for _, o in ipairs(O.LIST) do
                if o.area == area and o.rare then rows[#rows + 1] = { opt = o } end
            end
        end
    end
    return rows
end

---------------------------------------------------------------------------
-- Window (built when first shown)
---------------------------------------------------------------------------
local win, rowPool, areaButtons = nil, {}, {}
O.area, O.moreOpen = "window", {}

local function Tip(owner, title, text, extra)
    if not GameTooltip then return end
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    GameTooltip:AddLine(title, 1, 0.82, 0)
    if text and text ~= "" then GameTooltip:AddLine(text, 1, 1, 1, true) end
    if extra and extra ~= "" then GameTooltip:AddLine(extra, 0.6, 0.6, 0.6, true) end
    GameTooltip:Show()
end
local function HideTip() if GameTooltip then GameTooltip:Hide() end end

local function Button(parent, w, h)
    if ns.UI and ns.UI.FlatButton then return ns.UI.FlatButton(parent, w, h, true) end
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(w, h)
    return b
end
local function Selected(b, on)
    if ns.UI and ns.UI.SetSelected then ns.UI.SetSelected(b, on) end
end

local function OptTip(row)
    local o = row.opt
    if not o then return end
    local extra = o.cmd and string.format(L.OPTW_CMD, o.cmd) or nil
    if not O.Available(o) then extra = O.Text(o.availTip) end
    Tip(row, O.Text(o.label), O.Text(o.tip), extra)
end

local function ApplyEdit(row)
    local o = row.opt
    if not o then return end
    local t = row.edit:GetText() or ""
    local v
    if o.kind == "money" then
        v = ns.Disenchant and ns.Disenchant.ParseMoney and ns.Disenchant.ParseMoney(t)
    else
        v = tonumber((t:gsub(",", "."):gsub("%%", "")))
    end
    if not O.Set(o.key, v) then O.Draw() end      -- not valid: the old value again
end

local function MakeRow(i)
    local row = CreateFrame("Frame", nil, win.list)
    row:SetSize(O.WIDTH - O.BAR_W - 40, O.ROW_H)
    row:SetPoint("TOPLEFT", win.list, "TOPLEFT", 0, -(i - 1) * O.ROW_H)
    row:EnableMouse(true)
    row.label = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.label:SetPoint("LEFT", row, "LEFT", 4, 0)
    row.label:SetWidth(200)
    row.label:SetJustifyH("LEFT")
    if row.label.SetWordWrap then row.label:SetWordWrap(false) end
    row:SetScript("OnEnter", OptTip)
    row:SetScript("OnLeave", HideTip)
    -- on/off: ONE button
    row.toggle = Button(row, 64, 20)
    row.toggle:SetPoint("RIGHT", row, "RIGHT", -4, 0)
    row.toggle:SetScript("OnClick", function()
        local o = row.opt
        if o and O.Available(o) then O.Set(o.key, not o.get()) end
    end)
    row.toggle:SetScript("OnEnter", function() OptTip(row) end)
    row.toggle:SetScript("OnLeave", HideTip)
    -- a choice: a row of buttons
    row.choice = {}
    for c = 3, 1, -1 do
        local b = Button(row, 70, 20)
        if c == 3 then b:SetPoint("RIGHT", row, "RIGHT", -4, 0) else b:SetPoint("RIGHT", row.choice[c + 1], "LEFT", -2, 0) end
        b:SetScript("OnClick", function()
            local o = row.opt
            if o and o.choices and o.choices[c] then O.Set(o.key, o.choices[c][1]) end
        end)
        b:SetScript("OnEnter", function()
            local o = row.opt
            local ch = o and o.choices and o.choices[c]
            if ch then Tip(b, O.Text(ch[2]), O.Text(ch[3])) end
        end)
        b:SetScript("OnLeave", HideTip)
        row.choice[c] = b
    end
    -- a value: a small edit box (Enter or leaving the field applies it)
    row.edit = CreateFrame("EditBox", nil, row, "InputBoxTemplate")
    row.edit:SetSize(72, 20)
    row.edit:SetPoint("RIGHT", row, "RIGHT", -22, 0)
    row.edit:SetAutoFocus(false)
    row.edit:SetScript("OnEnterPressed", function(self) self:ClearFocus(); ApplyEdit(row) end)
    row.edit:SetScript("OnEditFocusLost", function() ApplyEdit(row) end)
    row.edit:SetScript("OnEscapePressed", function(self) self:ClearFocus(); O.Draw() end)
    row.edit:SetScript("OnEnter", function() OptTip(row) end)
    row.edit:SetScript("OnLeave", HideTip)
    row.unit = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.unit:SetPoint("LEFT", row.edit, "RIGHT", 4, 0)
    -- "More" (folded rare options)
    row.more = Button(row, 200, 20)
    row.more:SetPoint("LEFT", row, "LEFT", 0, 0)
    row.more:SetScript("OnClick", function()
        O.moreOpen[O.area] = not O.moreOpen[O.area]
        O.Draw()
    end)
    return row
end

local function Row(i)
    if not rowPool[i] then rowPool[i] = MakeRow(i) end
    return rowPool[i]
end

local function DrawRow(row, r)
    row.opt = r.opt
    row.toggle:Hide(); row.edit:Hide(); row.unit:Hide(); row.more:Hide()
    for _, b in ipairs(row.choice) do b:Hide() end
    row.label:SetText("")
    if r.header then
        row.label:SetText("|cffffd100" .. r.header .. "|r")
    elseif r.info then
        row.label:SetText("|cffa0a0a0" .. r.info .. "|r")
    elseif r.more then
        row.more:SetText((r.open and "- " or "+ ") .. string.format(L.OPTW_MORE, r.count))
        row.more:Show()
    elseif r.opt then
        local o = r.opt
        local avail = O.Available(o)
        row.label:SetText((avail and "" or "|cff808080") .. O.Text(o.label) .. (avail and "" or "|r"))
        if o.kind == "toggle" then
            local on = o.get()
            row.toggle:SetText(on and ("|cff40c040" .. L.ON .. "|r") or ("|cff9a9a9a" .. L.OFF .. "|r"))
            Selected(row.toggle, on)
            if row.toggle.SetEnabled then row.toggle:SetEnabled(avail) end
            row.toggle:Show()
        elseif o.kind == "choice" then
            local v = o.get()
            for c, ch in ipairs(o.choices) do
                local b = row.choice[c]
                b:SetText(O.Text(ch[2]))
                Selected(b, v == ch[1])
                b:Show()
            end
        else
            local v = o.get()
            if not (row.edit.HasFocus and row.edit:HasFocus()) then
                row.edit:SetText(o.kind == "money" and ns.Prices.MoneyPlain(v) or tostring(v))
            end
            row.edit:Show()
            if o.unit then row.unit:SetText(o.unit); row.unit:Show() end
        end
    end
    row:Show()
end

function O.Draw()
    if not win then return end
    local search = win.search and win.search:GetText() or ""
    -- texts again on every draw (language of the moment; the test routine shows both)
    for _, a in ipairs(O.AREAS) do
        local b = areaButtons[a.key]
        if b then
            b:SetText(O.AreaLabel(a.key))
            Selected(b, search == "" and O.area == a.key)
        end
    end
    win.default:SetText(L.OPTW_DEFAULT)
    win.protocol:SetText(L.OPTW_PROTOCOL)
    if win.search.Instructions then win.search.Instructions:SetText(L.OPTW_SEARCH) end
    local rows = O.Rows(O.area, search, O.moreOpen[O.area])
    O.shownRows = rows
    local n = math.min(#rows, O.MAX_ROWS)
    for i = 1, n do DrawRow(Row(i), rows[i]) end
    for i = n + 1, #rowPool do rowPool[i]:Hide(); rowPool[i].opt = nil end
    win.default:SetShown(search == "")
    win.title:SetText(L.OPTW_TITLE .. (search == "" and (" – " .. O.AreaLabel(O.area)) or ""))
end

local function CreateWindow()
    local tmpl = BackdropTemplateMixin and "BackdropTemplate" or nil
    win = CreateFrame("Frame", nil, UIParent, tmpl)       -- no global name (T132)
    if ns.RegisterUI then ns.RegisterUI(win, "ProfessionSentinel-Optionen") end
    win:Hide()
    win:SetSize(O.WIDTH, O.HEIGHT)
    win:SetPoint("CENTER")
    win:SetFrameStrata("DIALOG")
    win:SetClampedToScreen(true)
    win:SetMovable(true)
    win:EnableMouse(true)
    win:RegisterForDrag("LeftButton")
    win:SetScript("OnDragStart", win.StartMoving)
    win:SetScript("OnDragStop", win.StopMovingOrSizing)
    if win.SetBackdrop then
        win:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 32,
            insets = { left = 11, right = 12, top = 12, bottom = 11 } })
    end
    win.title = win:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    win.title:SetPoint("TOPLEFT", 20, -18)
    -- search over all areas (OPT-ALLE b)
    win.search = CreateFrame("EditBox", nil, win, "SearchBoxTemplate")
    win.search:SetSize(180, 20)
    win.search:SetPoint("TOPRIGHT", win, "TOPRIGHT", -20, -14)
    win.search:SetAutoFocus(false)
    if win.search.Instructions then
        win.search.Instructions:SetText(L.OPTW_SEARCH)
        if win.search.Instructions.SetWordWrap then win.search.Instructions:SetWordWrap(false) end
    end
    win.search:HookScript("OnTextChanged", function() O.Draw() end)
    -- the areas on the left
    for i, a in ipairs(O.AREAS) do
        local b = Button(win, O.BAR_W - 10, 26)
        b:SetPoint("TOPLEFT", win, "TOPLEFT", 16, -50 - (i - 1) * 30)
        b:SetText(O.Text(a.label))
        b:SetScript("OnClick", function()
            O.area = a.key
            if win.search:GetText() ~= "" then win.search:SetText("") end
            O.Draw()
        end)
        areaButtons[a.key] = b
    end
    -- the list on the right
    win.list = CreateFrame("Frame", nil, win)
    win.list:SetPoint("TOPLEFT", win, "TOPLEFT", O.BAR_W + 16, -50)
    win.list:SetSize(O.WIDTH - O.BAR_W - 36, O.MAX_ROWS * O.ROW_H)
    -- below: default for the area, close
    win.default = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
    win.default:SetSize(130, 22)
    win.default:SetPoint("BOTTOMLEFT", win, "BOTTOMLEFT", 18, 16)
    win.default:SetText(L.OPTW_DEFAULT)
    win.default:SetScript("OnClick", function() O.ResetArea(O.area); O.Draw() end)
    win.default:SetScript("OnEnter", function(self) Tip(self, L.OPTW_DEFAULT, string.format(L.OPTW_DEFAULT_TIP, O.AreaLabel(O.area))) end)
    win.default:SetScript("OnLeave", HideTip)
    -- the diagnostic log for a player who reports a problem (normal way besides /ps protokoll)
    win.protocol = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
    win.protocol:SetSize(150, 22)
    win.protocol:SetPoint("BOTTOM", win, "BOTTOM", 0, 16)
    win.protocol:SetText(L.OPTW_PROTOCOL)
    win.protocol:SetScript("OnClick", function() if ns.Diagnose and ns.Diagnose.Show then ns.Diagnose.Show() end end)
    win.protocol:SetScript("OnEnter", function(self) Tip(self, L.OPTW_PROTOCOL, L.OPTW_PROTOCOL_TIP, string.format(L.OPTW_CMD, "/ps protokoll")) end)
    win.protocol:SetScript("OnLeave", HideTip)
    win.close = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
    win.close:SetSize(120, 22)
    win.close:SetPoint("BOTTOMRIGHT", win, "BOTTOMRIGHT", -18, 16)
    win.close:SetText(CLOSE or L.DG_CLOSE)
    win.close:SetScript("OnClick", function() win:Hide() end)
    O.frame = win
end

function O.Frame() return win end

-- open (at an area; nil = the last one)
function O.Open(area)
    local t0 = ns.DiagClock and ns.DiagClock()
    if not win then CreateWindow() end
    if area and O.byArea(area) then O.area = area end
    if win.search:GetText() ~= "" then win.search:SetText("") end
    win:Show()
    O.Draw()
    if t0 and ns.Perf then ns.Perf("Optionen öffnen", t0) end
    if ns.PLHit then ns.PLHit("OPT", "Optionen geöffnet") end
    return win
end
function O.byArea(area)
    for _, a in ipairs(O.AREAS) do if a.key == area then return true end end
    return false
end
function O.Hide() if win then win:Hide() end end
function O.Toggle(area)
    if win and win:IsShown() then win:Hide() else O.Open(area) end
end
-- the options button of the panel: the area of the current view
function O.OpenForPanel()
    local mode = ns.db and ns.db.panelMode
    return O.Open(O.AreaForMode(mode))
end

---------------------------------------------------------------------------
-- The game's settings window (Entscheid des Nutzers 18.11. 11:10: every player function on the normal way): an entry
-- "ProfessionSentinel" with the button "Open options". Modern clients: Settings (canvas category); older: InterfaceOptions.
---------------------------------------------------------------------------
function O.RegisterGameSettings()
    if O.gameCategory or O.gamePanel then return O.gameCategory or O.gamePanel end
    local f = CreateFrame("Frame")
    f.name = "ProfessionSentinel"
    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText("ProfessionSentinel")
    local hint = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    hint:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
    hint:SetPoint("RIGHT", f, "RIGHT", -16, 0)
    hint:SetJustifyH("LEFT")
    hint:SetText(L.OPTW_GAME_HINT)
    local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    b:SetSize(200, 24)
    b:SetPoint("TOPLEFT", hint, "BOTTOMLEFT", 0, -12)
    b:SetText(L.OPTW_GAME_BUTTON)
    b:SetScript("OnClick", function()
        -- the game's settings window stays below; ours opens above it
        O.Open()
    end)
    f.openButton = b
    O.gamePanel = f
    local S = _G.Settings
    if type(S) == "table" and S.RegisterCanvasLayoutCategory and S.RegisterAddOnCategory then
        local ok, cat = pcall(S.RegisterCanvasLayoutCategory, f, "ProfessionSentinel")
        if ok and cat then
            pcall(S.RegisterAddOnCategory, cat)
            O.gameCategory = cat
            return cat
        end
    end
    if _G.InterfaceOptions_AddCategory then pcall(_G.InterfaceOptions_AddCategory, f) end
    return f
end

local loader = ns.AddEventFrame and ns.AddEventFrame(CreateFrame("Frame"), "Options") or CreateFrame("Frame")
loader:RegisterEvent("PLAYER_LOGIN")
loader:SetScript("OnEvent", function()
    if ns.Flavor then pcall(O.RegisterGameSettings) end
end)
