# ProfessionSentinel – Changelog

## 0.3.0
- New "Trainers" tab: every trainer of the open profession by rank – Journeyman (to 150), Expert (to 225), Artisan (to 300), specialisations – with zone, coordinates and faction; your next rank is marked
- Vendors and drop mobs in the recipe tooltip now show zone and coordinates
- Click a trainer for a waypoint; right-click a recipe for a waypoint to the nearest vendor (TomTom if installed, otherwise the game's map pin)
- Zone names in the client's language; new WoW Forever zones (Isle of Zephras, Riverlands) supported
- Test mode: trainer and waypoint checks, "test waypoint" button

## 0.2.0
- Detects the game version from the client and adapts: WoW Forever (own recipes and skill levels – many recipes turn grey sooner) and Classic Era (classic profession and enchanting windows)
- Lifeline: a thin line under every recipe (orange → yellow → green → grey) with a marker at your skill and how many crafts it takes until the next colour – in Blizzard's recipe list and in the "All recipes" panel
- Tooltip shows crafts until yellow, green and grey
- Test mode (/ps test): diagnostics, simulated skill, simulated learned state, panel without profession window, self-test (/ps selftest)
- /ps line toggles the lifeline
- Fixed swapped skill levels on a few client recipes (e.g. Charged Scale of Onyxia)

## 0.1.0
- First release for WoW Forever (Interface 16001)
- "All recipes" panel docked to the profession window, grouped like the client's categories
- Learned recipes greyed out, missing recipes in rarity colour
- Tooltips with skill levels, reagents and recipe sources (trainer, vendor, drop, quest)
- Recipe item tooltips show learned / not learned for all your characters
- 2210 recipes, 934 of them new in WoW Forever
