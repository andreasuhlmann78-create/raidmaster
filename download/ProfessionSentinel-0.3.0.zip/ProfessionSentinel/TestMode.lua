local _, ns = ...
local L = ns.L

-- Test mode (/ps test): diagnostics, simulation (skill, learned state, profession without
-- profession window) and a self-test of data, lifeline maths and the game APIs the addon uses.
-- Nothing here changes saved data: the simulation lives in ns.Sim and is cleared by "Reset".

local TM = {}
ns.TestMode = TM

local win, diagText, resultText, skillSlider, skillValue, skillActive, profLabel, knownButtons
local profIndex = 1

local function Sim()
    ns.Sim = ns.Sim or {}
    return ns.Sim
end

local function Clean()
    if ns.Sim and not ns.Sim.rank and not ns.Sim.known and not ns.Sim.prof then ns.Sim = nil end
end

local function RefreshAll()
    Clean()
    if ns.RefreshAll then ns.RefreshAll() end
end

local function OK(b) return b and "|cff40c040OK|r" or "|cffff4040--|r" end

---------------------------------------------------------------------------
-- Diagnostics
---------------------------------------------------------------------------
local function TemplateExists(name)
    if C_XMLUtil and C_XMLUtil.GetTemplateInfo then
        return C_XMLUtil.GetTemplateInfo(name) ~= nil
    end
    return nil
end

function TM:Diagnostics()
    local lines = {}
    local function add(s) lines[#lines + 1] = s end
    add("|cffffd100" .. L.TEST_DIAG .. "|r")
    add(string.format("Spielversion/Game: |cffffffff%s|r  (Interface %d, Client %s, Build %s)",
        ns.FlavorName(), ns.Interface or 0, ns.ClientVersion or "?", ns.ClientBuild or "?"))
    add(string.format("Daten/Data: |cffffffff%d|r Rezepte · %s · Build %s · Questie %s", #ns.Recipes,
        tostring(ns.DataMeta.flavor), tostring(ns.DataMeta.build), tostring(ns.DataMeta.questie)))
    local tCount, npcCount, withCoords = 0, 0, 0
    for _, list in pairs(ns.Trainers or {}) do tCount = tCount + #list end
    for _, n in pairs(ns.NPCs) do npcCount = npcCount + 1; if n[6] and n[7] then withCoords = withCoords + 1 end end
    add(string.format("Lehrer/Trainers: |cffffffff%d|r · NPCs mit Koordinaten / with coordinates: |cffffffff%d|r von %d",
        tCount, withCoords, npcCount))
    local c = ns.Char()
    if c then
        local profs = {}
        for id, p in pairs(c.profs) do profs[#profs + 1] = ns.ProfName(id) .. " " .. (p.rank or 0) .. "/" .. (p.max or 0) end
        local n = 0
        for _ in pairs(c.known) do n = n + 1 end
        add("Charakter: " .. ns.CharKey() .. " · " .. (#profs > 0 and table.concat(profs, ", ") or "keine Berufe erkannt") .. " · " .. n .. " " .. L.KNOWN)
    end
    add(" ")
    add("|cffffd100API|r")
    local checks
    if ns.IsForever then
        checks = {
            { "ProfessionsFrame (geladen/loaded)", ProfessionsFrame ~= nil },
            { "C_TradeSkillUI.GetChildProfessionInfo", C_TradeSkillUI and C_TradeSkillUI.GetChildProfessionInfo ~= nil },
            { "C_TradeSkillUI.GetRecipeInfo", C_TradeSkillUI and C_TradeSkillUI.GetRecipeInfo ~= nil },
            { "C_TradeSkillUI.GetAllRecipeIDs", C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs ~= nil },
            { "C_TradeSkillUI.OpenRecipe", C_TradeSkillUI and C_TradeSkillUI.OpenRecipe ~= nil },
            { "Lebenslinie in Blizzard-Liste / lifeline hook", ns.Lifeline and ns.Lifeline.foreverHooked },
        }
    else
        checks = {
            { "TradeSkillFrame (geladen/loaded)", TradeSkillFrame ~= nil },
            { "CraftFrame (geladen/loaded)", CraftFrame ~= nil },
            { "GetTradeSkillLine / GetTradeSkillInfo", GetTradeSkillLine ~= nil and GetTradeSkillInfo ~= nil },
            { "GetTradeSkillRecipeLink", GetTradeSkillRecipeLink ~= nil },
            { "GetCraftDisplaySkillLine", GetCraftDisplaySkillLine ~= nil },
            { "Lebenslinie Handwerk / lifeline hook", ns.Lifeline and ns.Lifeline.tsHooked },
            { "Lebenslinie Verzauberkunst / lifeline hook", ns.Lifeline and ns.Lifeline.craftHooked },
        }
    end
    local common = {
        { "ScrollUtil / ScrollBox", ScrollUtil ~= nil and CreateScrollBoxListTreeListView ~= nil },
        { "CreateTreeDataProvider", CreateTreeDataProvider ~= nil },
        { "ButtonFrameTemplate", TemplateExists("ButtonFrameTemplate") ~= false },
        { "SearchBoxTemplate", TemplateExists("SearchBoxTemplate") ~= false },
        { "MinimalScrollBar", TemplateExists("MinimalScrollBar") ~= false },
        { "TooltipDataProcessor / OnTooltipSetItem", TooltipDataProcessor ~= nil or GameTooltip:HasScript("OnTooltipSetItem") },
        { "IsPlayerSpell", IsPlayerSpell ~= nil },
        { "Wegpunkt / waypoint: " .. (ns.Waypoint and ns.Waypoint.Available() or "nur Chat / chat only"), ns.Waypoint and ns.Waypoint.Available() ~= nil },
        { "C_Map.GetMapInfo (Zonennamen / zone names)", C_Map ~= nil and C_Map.GetMapInfo ~= nil },
    }
    for _, ch in ipairs(checks) do add(OK(ch[2]) .. "  " .. ch[1]) end
    for _, ch in ipairs(common) do add(OK(ch[2]) .. "  " .. ch[1]) end
    add(" ")
    add(L.TEST_HELP)
    return table.concat(lines, "\n")
end

---------------------------------------------------------------------------
-- Self-test
---------------------------------------------------------------------------
function TM:RunSelfTest(toChat)
    local results, fails = {}, 0
    local function check(name, cond, detail)
        if not cond then fails = fails + 1 end
        results[#results + 1] = (cond and "|cff40c040" .. L.TEST_PASS or "|cffff4040" .. L.TEST_FAIL) .. "|r  " .. name
            .. (detail and (" |cff9d9d9d(" .. detail .. ")|r") or "")
    end
    local LL = ns.Lifeline

    -- 1. Data
    check("Spielversion erkannt / game version detected", ns.Flavor ~= nil, tostring(ns.Flavor))
    check("Passende Daten geladen / matching data loaded", ns.DataMeta.flavor == ns.Flavor and #ns.Recipes > 0,
        tostring(ns.DataMeta.flavor) .. ", " .. #ns.Recipes)
    local bad, profsOk = 0, true
    for _, r in ipairs(ns.Recipes) do
        if r.yellow > 0 and not (r.yellow <= r.green and r.green <= r.grey) then bad = bad + 1 end
        if not ns.ByProf[r.prof] then profsOk = false end
    end
    check("Farbstufen geordnet / thresholds ordered (gelb<=grün<=grau)", bad == 0, bad .. " Abweichungen")
    check("Jedes Rezept hat einen Beruf / every recipe has a profession", profsOk)

    -- 2. Version-specific thresholds (Feine Lederstiefel / Fine Leather Boots, spell 2158)
    local flb = ns.BySpell[2158]
    if ns.IsForever then
        check("Forever-Stufen aktiv (Feine Lederstiefel grau 125)", flb and flb.grey == 125, flb and (flb.yellow .. "/" .. flb.green .. "/" .. flb.grey))
    elseif ns.IsEra then
        check("Era-Stufen aktiv (Feine Lederstiefel grau 150)", flb and flb.grey == 150, flb and (flb.yellow .. "/" .. flb.green .. "/" .. flb.grey))
    end

    -- 3. Lifeline maths with fixed examples
    local A = { req = 65, yellow = 95, green = 110, grey = 125, skillUps = 1 }
    local c80 = LL.Calc(A, 80)
    check("Orange: 80 -> 15× bis Gelb (genau)", c80 and c80.state == "orange" and c80.target == "yellow" and c80.crafts == 15 and c80.exact)
    local c95 = LL.Calc(A, 95)
    check("Gelb: 95 -> ≈ bis Grün", c95 and c95.state == "yellow" and c95.target == "green" and (c95.crafts or 0) >= 15, c95 and tostring(c95.crafts))
    local c115 = LL.Calc(A, 115)
    check("Grün: 115 -> ≈ bis Grau", c115 and c115.state == "green" and c115.target == "grey", c115 and tostring(c115.crafts))
    local c125 = LL.Calc(A, 125)
    check("Grau ab 125", c125 and c125.state == "grey")
    local c50 = LL.Calc(A, 50)
    check("Zu niedrig: 50 -> 'ab 65'", c50 and c50.state == "red")
    local Z = { req = 35, yellow = 40, green = 40, grey = 40, skillUps = 1 }  -- Forever: grey after 5 points
    local z36 = LL.Calc(Z, 36)
    check("Sofort grau (35/40/40/40): 36 -> 4× bis Grau", z36 and z36.target == "grey" and z36.crafts == 4)
    local z40 = LL.Calc(Z, 40)
    check("35/40/40/40: 40 -> grau", z40 and z40.state == "grey")
    local frac, pos = LL.Layout(A, 80)
    local sum = frac[1] + frac[2] + frac[3] + frac[4]
    check("Linie: Zonen = 100 %, Marker im Bereich", math.abs(sum - 1) < 0.001 and pos and pos >= 0 and pos <= 1)
    check("Chance gelb->grau fällt / chance falls", LL.Chance(A, 95) == 1 and LL.Chance(A, 110) < 1 and LL.Chance(A, 125) == 0)

    -- 4. Trainers, locations, waypoints
    local WP = ns.Waypoint
    local lw = ns.Trainers and ns.Trainers[165] or {}
    local una
    for _, e in ipairs(lw) do if e[1] == 3007 then una = e end end
    local unaN = ns.NPCs[3007]
    check("Lehrer geladen (Lederverarbeitung) / trainers loaded", #lw > 5, #lw .. " Lehrer")
    check("Una = Fachmann (bis 300) mit Koordinaten", una and una[2] == 4 and unaN and unaN[6] and unaN[7] and unaN[8],
        unaN and string.format("%s %.1f, %.1f", tostring(unaN[2]), unaN[7] or 0, unaN[8] or 0))
    local ranksOk = true
    for _, list in pairs(ns.Trainers or {}) do
        for _, e in ipairs(list) do
            if not ns.NPCs[e[1]] or e[2] < 0 or e[2] > 5 then ranksOk = false end
        end
    end
    check("Alle Lehrer haben Daten und gültigen Rang / all trainers valid", ranksOk)
    local n1 = WP.NextRank(70, 75)
    local n2 = WP.NextRank(210, 225)
    local n3 = WP.NextRank(300, 300)
    check("Nächster Rang: 70/75 -> Geselle, 210/225 -> Fachmann, 300/300 -> keiner",
        n1 and n1.key == 2 and n2 and n2.key == 4 and n3 == nil)
    local flbVendor
    for _, r in ipairs(ns.Recipes) do
        if r.nameEN == "Murloc Scale Belt" then flbVendor = WP.BestSourceNPC(r) end
    end
    check("Rezept -> Händler mit Koordinaten (Murlocschuppengürtel)", flbVendor ~= nil and WP.Has(flbVendor),
        flbVendor and WP.LocationText(flbVendor))

    -- 5. Character / scan
    local c = ns.Char()
    check("Charakterdaten vorhanden / character data", c ~= nil)

    -- 5. UI building blocks
    check("Panel-Bausteine / panel building blocks", CreateTreeDataProvider ~= nil and ScrollUtil ~= nil and CreateScrollBoxListTreeListView ~= nil)

    local head = string.format("|cffffd100Selbsttest / self-test:|r %d/%d %s", #results - fails, #results, L.TEST_PASS)
    table.insert(results, 1, head)
    local text = table.concat(results, "\n")
    if resultText then resultText:SetText(text) end
    if toChat then
        ns.Print(head)
        for i = 2, #results do
            if results[i]:find(L.TEST_FAIL, 1, true) then ns.Print(results[i]) end
        end
    end
    return fails == 0, results
end

---------------------------------------------------------------------------
-- Window
---------------------------------------------------------------------------
local function ProfList()
    local list = {}
    for _, p in ipairs(ns.Professions) do
        if ns.ByProf[p.id] and #ns.ByProf[p.id] > 3 then list[#list + 1] = p end
    end
    return list
end

local function UpdateProfLabel()
    local list = ProfList()
    local p = list[profIndex]
    profLabel:SetText(p and (ns.ProfName(p.id) .. " (" .. #ns.ByProf[p.id] .. ")") or "-")
end

local function UpdateKnownButtons()
    local mode = ns.Sim and ns.Sim.known or "real"
    for key, b in pairs(knownButtons) do
        b:SetText((mode == key and "> " or "") .. b.label .. (mode == key and " <" or ""))
    end
end

local function SetSkill(v)
    v = math.max(1, math.min(375, math.floor(v + 0.5)))
    skillSlider:SetValue(v)
end

local function MakeButton(parent, text, w, onClick)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(w, 22)
    b:SetText(text)
    b:SetScript("OnClick", onClick)
    return b
end

local function CreateWindow()
    win = CreateFrame("Frame", "ProfessionSentinelTestMode", UIParent, "ButtonFrameTemplate")
    win:SetSize(520, 720)
    win:SetPoint("CENTER", UIParent, "CENTER", -260, 0)
    win:SetFrameStrata("DIALOG")
    win:SetMovable(true)
    win:EnableMouse(true)
    win:RegisterForDrag("LeftButton")
    win:SetScript("OnDragStart", win.StartMoving)
    win:SetScript("OnDragStop", win.StopMovingOrSizing)
    win:SetClampedToScreen(true)
    if ButtonFrameTemplate_HidePortrait then ButtonFrameTemplate_HidePortrait(win) end
    if ButtonFrameTemplate_HideButtonBar then ButtonFrameTemplate_HideButtonBar(win) end
    win:SetTitle(L.TEST_TITLE)
    if win.Inset then win.Inset:Hide() end
    tinsert(UISpecialFrames, "ProfessionSentinelTestMode")

    local y = -32
    local function header(text)
        local fs = win:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        fs:SetPoint("TOPLEFT", 16, y)
        fs:SetText(text)
        y = y - 22
        return fs
    end

    -- Simulation ---------------------------------------------------------
    header("|cffffd100" .. L.TEST_SIM .. "|r")

    -- profession picker
    local pl = win:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    pl:SetPoint("TOPLEFT", 16, y); pl:SetText(L.TEST_PROF .. ":")
    local prev = MakeButton(win, "<", 26, function()
        local n = #ProfList(); profIndex = profIndex - 1; if profIndex < 1 then profIndex = n end; UpdateProfLabel()
        if ns.Sim and ns.Sim.prof then Sim().prof = ProfList()[profIndex].id; RefreshAll() end
    end)
    prev:SetPoint("TOPLEFT", 120, y + 4)
    profLabel = win:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    profLabel:SetPoint("LEFT", prev, "RIGHT", 8, 0)
    profLabel:SetWidth(180)
    local nextB = MakeButton(win, ">", 26, function()
        local n = #ProfList(); profIndex = profIndex + 1; if profIndex > n then profIndex = 1 end; UpdateProfLabel()
        if ns.Sim and ns.Sim.prof then Sim().prof = ProfList()[profIndex].id; RefreshAll() end
    end)
    nextB:SetPoint("LEFT", profLabel, "RIGHT", 8, 0)
    y = y - 30
    local open = MakeButton(win, L.TEST_OPEN_PANEL, 300, function()
        local p = ProfList()[profIndex]
        if not p then return end
        Sim().prof = p.id
        ns.UI:Show(nil)
        RefreshAll()
    end)
    open:SetPoint("TOPLEFT", 16, y)
    y = y - 34

    -- skill slider
    skillActive = CreateFrame("CheckButton", nil, win, "UICheckButtonTemplate")
    skillActive:SetSize(22, 22)
    skillActive:SetPoint("TOPLEFT", 12, y + 2)
    local sl = win:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    sl:SetPoint("LEFT", skillActive, "RIGHT", 2, 0)
    sl:SetText(L.TEST_SKILL)
    skillValue = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    skillValue:SetPoint("TOPRIGHT", -20, y)
    y = y - 26
    skillSlider = CreateFrame("Slider", nil, win)
    skillSlider:SetOrientation("HORIZONTAL")
    skillSlider:SetSize(380, 16)
    skillSlider:SetPoint("TOPLEFT", 50, y)
    skillSlider:SetMinMaxValues(1, 375)
    skillSlider:SetValueStep(1)
    if skillSlider.SetObeyStepOnDrag then skillSlider:SetObeyStepOnDrag(true) end
    local track = skillSlider:CreateTexture(nil, "BACKGROUND")
    track:SetPoint("LEFT"); track:SetPoint("RIGHT"); track:SetHeight(6)
    track:SetColorTexture(0.25, 0.22, 0.18, 1)
    skillSlider:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
    skillSlider:EnableMouseWheel(true)
    skillSlider:SetScript("OnMouseWheel", function(self, d) SetSkill(self:GetValue() + d) end)
    local minus = MakeButton(win, "-", 26, function() SetSkill(skillSlider:GetValue() - 1) end)
    minus:SetPoint("RIGHT", skillSlider, "LEFT", -6, 0)
    local plus = MakeButton(win, "+", 26, function() SetSkill(skillSlider:GetValue() + 1) end)
    plus:SetPoint("LEFT", skillSlider, "RIGHT", 6, 0)
    skillSlider:SetScript("OnValueChanged", function(self, v)
        v = math.floor(v + 0.5)
        skillValue:SetText(skillActive:GetChecked() and v or ("|cff9d9d9d" .. v .. " (" .. L.TEST_SKILL_OFF .. ")|r"))
        if skillActive:GetChecked() then Sim().rank = v; RefreshAll() end
    end)
    skillActive:SetScript("OnClick", function(self)
        if self:GetChecked() then Sim().rank = math.floor(skillSlider:GetValue() + 0.5)
        elseif ns.Sim then ns.Sim.rank = nil end
        skillSlider:GetScript("OnValueChanged")(skillSlider, skillSlider:GetValue())
        RefreshAll()
    end)
    y = y - 34

    -- learned state
    local kl = win:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    kl:SetPoint("TOPLEFT", 16, y); kl:SetText(L.TEST_KNOWN .. ":")
    knownButtons = {}
    local x = 150
    for _, def in ipairs({ { "real", L.TEST_KNOWN_REAL }, { "all", L.TEST_KNOWN_ALL }, { "none", L.TEST_KNOWN_NONE } }) do
        local key, label = def[1], def[2]
        local b = MakeButton(win, label, 116, function()
            Sim().known = key ~= "real" and key or nil
            UpdateKnownButtons(); RefreshAll()
        end)
        b.label = label
        b:SetPoint("TOPLEFT", x, y + 4)
        knownButtons[key] = b
        x = x + 120
    end
    y = y - 34

    -- actions
    local run = MakeButton(win, L.TEST_RUN, 200, function() TM:RunSelfTest(false) end)
    run:SetPoint("TOPLEFT", 16, y)
    local reset = MakeButton(win, L.TEST_RESET, 140, function() TM:Reset() end)
    reset:SetPoint("LEFT", run, "RIGHT", 10, 0)
    local lineToggle = MakeButton(win, L.LL_OPTION, 150, function()
        ns.db.lifeline = not ns.db.lifeline
        RefreshAll()
    end)
    lineToggle:SetPoint("LEFT", reset, "RIGHT", 10, 0)
    lineToggle:SetWidth(140)
    y = y - 30
    local wpTest = MakeButton(win, L.TEST_WAYPOINT, 300, function()
        local p = ProfList()[profIndex]
        local list = p and ns.Trainers and ns.Trainers[p.id]
        if list and list[1] then ns.Waypoint.Set(list[1][1]) end
    end)
    wpTest:SetPoint("TOPLEFT", 16, y)
    local trainerTab = MakeButton(win, L.TRAINERS, 140, function()
        local p = ProfList()[profIndex]
        if not p then return end
        Sim().prof = p.id
        ns.db.panelMode = "trainers"
        ns.UI:Show(nil)
        RefreshAll()
    end)
    trainerTab:SetPoint("LEFT", wpTest, "RIGHT", 10, 0)
    y = y - 34

    -- result / diagnostics text
    resultText = win:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    resultText:SetPoint("TOPLEFT", 16, y)
    resultText:SetWidth(488)
    resultText:SetJustifyH("LEFT")
    resultText:SetJustifyV("TOP")
    resultText:SetSpacing(2)
    diagText = resultText

    win:SetScript("OnShow", function()
        UpdateProfLabel()
        UpdateKnownButtons()
        resultText:SetText(TM:Diagnostics())
    end)
    -- default slider position: real rank of the first profession or 1
    local c = ns.Char()
    local startRank = 1
    if c then for _, p in pairs(c.profs) do startRank = math.max(startRank, p.rank or 1) end end
    skillSlider:SetValue(startRank)
end

function TM:Reset()
    ns.Sim = nil
    if skillActive then skillActive:SetChecked(false) end
    if skillSlider then skillSlider:GetScript("OnValueChanged")(skillSlider, skillSlider:GetValue()) end
    if knownButtons then UpdateKnownButtons() end
    if ns.UI and ns.UI:IsShown() then
        local host = (ns.IsForever and ProfessionsFrame and ProfessionsFrame:IsShown() and ProfessionsFrame)
            or (CraftFrame and CraftFrame:IsShown() and CraftFrame)
            or (TradeSkillFrame and TradeSkillFrame:IsShown() and TradeSkillFrame)
        if host then ns.UI:Show(host) else ns.UI:Hide() end
    end
    if resultText then resultText:SetText(TM:Diagnostics()) end
    RefreshAll()
end

function TM:Toggle()
    if not win then CreateWindow() end
    if win:IsShown() then win:Hide() else win:Show() end
end
