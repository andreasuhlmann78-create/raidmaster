# AH Analyzer Pro – Changelog

## 0.60.10
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Test mode with fictional auctions:** "My auctions" now shows three fictional auctions (one
  undercut, one cheapest, one sold) plus everything you post in test mode - so cancelling and the
  undercut check can be tried without a real auction. The self-test uses a fictional auction for
  "cancel" when you have none.
- **Test mailbox:** in test mode the mailbox buttons of the addon work with fictional mail (sold,
  won, expired, cancelled, outbid, a normal letter): auto-collect, "All", ledger invoices and the
  repost list can all be tried - your real mail stays untouched.
- **Buy tab:** the bid field and the selected listing are reset when you switch to another item
  (no more old bid in the field). The header shows the cheapest listing and the market value
  (median 14 days) separately, and says when more listings are still loading.
- **Sniper:** listings of the previous target are no longer shown under the new target's name.
- **Self-test:** the sniper test buys (simulated) the smallest stack instead of a 2-stack.
- **Price history window:** can be dragged by its title.

## 0.60.9
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Message when the scan is done:** a large message in the middle of the screen ("AH scan done:
  N items") plus a sound (if alert sounds are on in the options) - you no longer have to watch the
  chat. A scan without results is shown there too.

## 0.60.8
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fixed: no price lines in item tooltips** on some clients (e.g. TBC Anniversary). The addon
  now hooks every way WoW fills an item tooltip and resizes the tooltip after adding its lines.
  The self-test now checks the real bag tooltip.
- **Esc closes only the top window:** e.g. the price history window - the addon window and the
  auction house stay open (before, one Esc closed everything).
- **Price history window:** the close button no longer sits on top of the "All" button.
- **Test mode** now also restores search favorites, repost list and mail rules.
- **Your own searches come first:** a running watcher round is stopped so the buy tab no longer
  waits ("Waiting for the watcher ...").
- Buy tab shows "Bought: ..." instead of "Purchase in progress ..." when done.
- Overview: tenfold price jumps (almost always bogus data) are no longer listed as rises/drops.
- Smaller fixes: test mode log shows sniper buys as such, shopping lists release the keyboard after
  deleting a list, no "N entries" overlap in the lists window, shorter option label "Expiry
  reminder", posting fee on classic AH shows "when posting" instead of "?", iLvl filter hint only
  when there are results, faster mouse-wheel scrolling in the report window, report title
  "Test report".

## 0.60.7
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **New "Test" button** at the top of the window (and in the auction house bar): self-test and
  the new **test mode** in one window.
- **Test mode:** try every feature by hand with your real auction house data - buy, bid, sniper
  (mouse wheel too), post, cancel, vendor sale, collecting and sending mail. Every trade is only
  simulated: the command to the server is intercepted and the server's answer is played back, so
  messages, ledger and sniper counters behave like the real thing. All settings and data (lists,
  ledger, sniper, watcher, selling) are restored when you stop test mode - or automatically after
  a /reload or crash. A log shows every simulated action and is included in the copied report.
  Note: only the addon's buttons are simulated, Blizzard's own auction house buttons still buy
  for real. Also: `/ahp testmode`.

## 0.60.6
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Self-test simulates real trading:** with the real auction house listings it now runs instant
  buy, bid, sniper buy, posting and cancelling exactly like the real thing - same listing, same
  price, same command. The command to the server is intercepted, so nothing is bought, posted or
  cancelled; the test finally checks that your gold is unchanged. Chat messages during the
  simulation are marked "[Simulation]".
- **Self-test:** the watcher is switched off again right after its test round, so it no longer
  blocks the following server searches.

## 0.60.5
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fixed (classic clients):** a Lua error "attempt to compare number with nil" could appear when
  opening the auction house (bid tracking after a reload).
- **Watcher/Sniper status in the header** now always updates when you switch them on or off.
- **Self-test:** a market scan still running in the background no longer makes all server
  searches time out - in the "saved data" mode it is stopped, otherwise the test waits for it.
  Starting a scan during the test is blocked.
- **Self-test:** settings, the watcher and the window (tab, or closed) are restored reliably
  after the test; if something can't be restored, the report says so.
- **Text window** (copy report) now always opens in front, starts at the top and scrolls
  quickly with the mouse wheel (hold Shift for big steps).

## 0.60.4
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Self-test with saved data:** new button "With saved data" in the self-test window (or
  `/ahp test saved`). It tests with the auction house data you already scanned - no new scan.
  It even runs with the auction house closed; the server searches are then skipped.

## 0.60.3
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix for TBC Anniversary (and other classic clients):** "My auctions" never updated and some
  auction house messages (e.g. "auction posted") never arrived. These clients know the event names
  of the modern auction house but never fire them for the classic one; the addon now always uses
  its own events there. Found by the new self-test.
- **Self-test:** the copied report can now be scrolled, and the result list is wider - hover a
  row to see the full text.

## 0.60.2
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Self-test:** Options -> "Self-test" or `/ahp test` checks every feature with real data from
  your auction house: market scan (if needed), market data, every tab, all calculations and real
  server searches (Buy, price check, Sniper, Watcher, your auctions). Buying, bidding, posting and
  cancelling are locked while it runs; your settings and sniper targets are restored afterwards.
  The result is shown in a window, can be copied as a report and is saved in the SavedVariables.

## 0.60.1
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Real minimap button:** the button now sits on the minimap like with other addons - drag it
  around the minimap with the mouse, the position is saved. Works with round and square
  minimaps. Hide or show it in Options or with `/ahp minimap`; `/ahp reset` brings it back.
- **New icon:** a golden scale - on the minimap button, in the title bar and in the addon list.

## 0.60.0
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**Tidier window - 5 tabs instead of 11:**

- **Overview · Buy · Sell · Market · Ledger.** Related pages are now sub-tabs:
  Buy = Buy, Sniper, Watcher, Bargains · Sell = Post, My auctions · Market = All prices, Watchlist.
  Every feature is still there, nothing was removed.
- **Price history in its own window:** clicking an item opens the price history next to the
  addon - the list you came from stays exactly where it was. The window can be moved and resized.
- **Sniper and watcher in the title bar:** see at a glance whether they are running and turn them
  on or off with one click (right-click opens their tab).
- **Remembers where you were:** the addon opens on the tab you used last, and every main tab
  remembers its last sub-tab.

## 0.59.33
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**Comfort update - twelve small things that save clicks every day:**

- **Stack size and number of stacks** (classic auction house): in the Sell tab, choose e.g.
  5 stacks of 20. Remembered per item and used by "Post all".
- **Collect mail automatically:** opening the mailbox collects auction mail right away
  (hold Shift while opening to skip). Can be turned off in Options.
- **Minimum price per item:** the new "Min" button in the Sell tab remembers the current price
  as a floor. The suggestion never goes below it, and "Post all" waits instead of selling cheap.
- **Only what I'm missing:** next to your profession window, a new button puts only the missing
  materials on a shopping list - counting your bags, bank and alts.
- **Alt-click an item** in your bags or a link in chat: opens the price history, or the Buy tab
  while the auction house is open.
- **Sell rate in the tooltip:** how much of what you posted actually sold (last 60 days) and how
  long it usually took.
- **Expiring auctions:** a message when your auctions have less than 30 minutes left, and at
  login what expired since your last visit.
- **Favorites in the Buy tab:** save searches (text, category, level, iLvl, rarity) and run them
  again with one click.
- **Gold goal:** set a goal for all characters together (Options or `/ahp goal 5000`) and get a
  message when you reach it. The daily summary shows your progress.
- **Guild bank value:** new view Ledger -> "Guild bank" shows what is in your guild bank and what
  it is worth (TBC and later).
- **Raid supplies:** one click creates a shopping list with potions, flasks, elixirs and buff
  food for a raid week (Classic, TBC, Wrath) - with the total cost. Also `/ahp raid`.
- **Price sync with your guild only:** new option to share prices only with your guild.

## 0.59.32
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **No more absurd profits:** items that would show a profit of 1000 % or more (almost always
  bad data such as an outlier market value or placeholder prices) are no longer listed in the
  Profit tab (all views: market value, vendor, disenchant, bids, flips) and no longer appear
  under "Biggest price increases" in the Overview.

## 0.59.31
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Item level as a search filter:** the Buy tab and the Market tab now have "iLvl from" /
  "iLvl to" fields. They filter the results instantly, without a new search on the server,
  and also apply to the single listings of an item. In the Buy tab you can also search with
  only an iLvl range.

## 0.59.30
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sell junk at vendors:** at any vendor a button below the window sells grey items and
  everything a vendor pays more for than the auction house (after the AH cut). The tooltip
  lists what will be sold. Can be turned off in Options.
- **Inventory value:** new view **Ledger -> "Assets"** shows what your bags, bank and alts are
  worth (market value and vendor value), plus the gold of all characters.
- **Daily summary at login:** once a day the chat shows yesterday's profit, the last 7 days,
  the gold of all characters and how many items are waiting to be reposted. Any time with
  `/ahp summary`. Can be turned off in Options.
- **Repost with one click:** expired or cancelled auctions that came back by mail are
  remembered. In the Auctions tab, "Repost (n)" posts them again one click at a time,
  undercutting the current price, with price protection.
- **Flip recommendations:** new view **Profit -> "Flips"**: items that are listed regularly and
  are currently well below market value. Stars show the turnover, sorted by expected profit.
- **Mail to alts:** set rules like "Herbs -> Alchemist" (Options -> Mail to alts). At the mailbox
  the "To alts" button sends one mail per click with up to 12 matching stacks.
- **Buy tab:** the iLvl column now shows the item level for every item (also for items the
  game had not loaded yet) and can be sorted.
- **Sell tab - listings appear faster:** listings show up while they are still loading, a click
  on an item now goes before the bargain watcher and sniper, and hovering over an item already
  starts loading its listings.
- **Chat help:** `/ahp help` (or `/ahp ?`) lists all commands in the chat. Unknown commands show
  the list too.

## 0.59.29
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Bid sniping:** new view **Profit -> "Bids"** lists auctions whose next bid is far below
  market value, with the time left. They are collected during the full scan (classic auction
  house) and every search in the Buy tab. Click an item to open it in the Buy tab and bid.
  (Thanks paladriel for the idea!)
- **Price protection when posting:** warns if your price is far below market value or follows a
  suspiciously cheap single unit - a second click is then needed, and "Post all" skips such items.
  Threshold in Options (off / 20 / 30 / 40 / 50 %, default 40 %).
- **Sale notification:** as soon as one of your auctions sells you get a message with the
  proceeds after the AH cut and your profit compared to what you paid, plus a coin sound.
  Can be turned off in Options.

## 0.59.28
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Support button:** if you like the addon, you can now support it with a small donation.
  The "Support" button in the addon window (also in Options and via `/ahp donate`) shows the
  PayPal link ready to copy. Thank you!

## 0.59.27
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Own window by default:** the addon now opens in its own window, detached from the auction house.
  The "AH Analyzer" tab at the auction house shows/hides it. You can still embed it in the
  auction house window: Options -> "Show in auction house".
- **Resizable window:** drag the bottom-right corner to make it as big as you like - all lists
  grow with it. The size and position are saved. Text size: Options -> "Text and content size".
  "Positions" in the options resets window size and position.

## 0.59.26
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Profit tab: column names fixed** (thanks paladriel!). The comparison column was renamed in the
  wrong place since the iLvl column was added - now "Market value" / "Vendor price" /
  "Disenchant value" are on the right column, and the price column is called **"Current buyout"**
  (cheapest buyout at the last scan), so it can't be mixed up with the 14-day market value.
- **"Search in auction house"** (right-click menu) now works on the classic auction house
  (Classic Era, WoW Forever, TBC, Wrath) - it opens the Browse tab and searches for the item.
  It also switches back from the AH Analyzer view first on every client.

## 0.59.25
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper shows the total amount** below the offer list: how many units of the sniped item
  will be bought in total (up to your target quantity, budget and gold), the total cost,
  the average price per unit and how many purchases (wheel notches) that takes.

## 0.59.24
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Mouse-wheel buying now also works over the addon window** (lists, charts, the whole
  AH Analyzer area): while a hit is waiting, the wheel buys it instead of scrolling.
  When nothing is waiting, the wheel scrolls the lists as usual.

## 0.59.23
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix: buying with the mouse wheel didn't work on the classic auction house** (Classic Era,
  WoW Forever, TBC, Wrath) since 0.59.20. There you can only buy what is in the auction house's
  current result list - and Sniper and Watcher kept searching on. Now, while a hit is waiting:
  it stays in the list (on the right result page, loaded in advance), the Sniper only re-checks it,
  the Watcher waits, and the sound keeps repeating until you buy it or it is gone.
- **Options -> "Sniper buys with" / "Watcher buys with":** choose mouse wheel (default) or your own
  key, separately for Sniper and Watcher hits. The same key for both buys whatever hit is waiting.

## 0.59.22
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Back button in the price history:** when you open an item's price history from another tab
  (e.g. Market, Overview, Buy, Watchlist), a "< Market" button next to the title takes you back -
  to the same page and sorting of the list you came from.

## 0.59.21
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Self-adjusting search speed - always at the limit of the server.** Where the server reports
  when it is ready (modern auction house and the classic one), the addon adds no delay of its own.
  Where it doesn't, the delay shrinks after every answer and doubles when the server drops a request,
  so Sniper, Watcher, Buy tab and price checks automatically run as fast as each WoW version allows.
  The Watcher no longer waits 2 seconds between rounds.

## 0.59.20
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper and Watcher search as often as the auction house allows.** The Sniper searches your
  targets, the Watcher looks for lucky bargains in the categories - they take turns
  (Sniper, Watcher, Sniper, ...) so neither one blocks the other.
  The Sniper's default interval is now "max." (Options -> "Sniper searches every").
- **After a hit the Sniper keeps searching:** the hit stays buyable with the mouse wheel / your key,
  and the sound repeats every few seconds as long as it is there (chat message only once).
- Your own actions always come first: a search in the Buy tab and price checks in the Sell tab.

## 0.59.19
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Watcher searches much more often:** instead of a fixed round every 20 seconds it now starts
  the next round as soon as the server allows (2 s pause). It takes turns with the Sniper and
  always lets your own searches in the Buy tab go first, so nothing else gets slower.
- **Watcher on the classic auction house** now reads all result pages - before it stopped after
  the first page and only saw the rarest (usually most expensive) items.
- **Bait offers (single items at the very bottom) are no longer shown** anywhere - not in Buy,
  Sniper, Sell price check or the Watcher list. They are still ignored for prices, and when buying
  commodities the price shown already includes them (the server always sells the cheapest units first).

## 0.59.18
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Pages in every table:** above each list there is now a page bar
  ("6280 entries  < 1 2 3 ... 370 >"). Click a number to jump straight to that page,
  < and > go one page back/forward. The mouse wheel and the scrollbar still work as before.
  Narrow lists show a compact "< 3 / 20 >".

## 0.59.17
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- In every item list (Buy, Market, Overview, Watchlist, Sell, Auctions, Profit, Charts,
  Ledger ...) clicking the **Item** column now sorts by **rarity first, then by name**
  (epic, rare, uncommon, common, poor - click again for the reverse order).
- New **iLvl** column in all item lists (item level of weapons and armor), sortable.

## 0.59.16
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Buy tab shows results **instantly**: clicking a category (e.g. Metal & Stone) immediately lists
  every item of that category from your last market scan (price and quantity in grey = not yet
  confirmed). The live search runs in the background and replaces them page by page with the
  real current offers - on the classic auction house that takes a few seconds per page.
- Clicking an item while a category search is still running now opens its offers right away
  instead of waiting for the category search to finish.

## 0.59.15
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Buy tab is much faster when switching categories (e.g. Herbs <-> Cooking):
  - a new search now cancels the running one immediately - before, it waited until the old
    search had read all its pages (several seconds each on the classic auction house);
  - results are remembered for 3 minutes, so switching back shows them instantly.
    The *Search* button (or Enter) always loads fresh data from the server.

## 0.59.14
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Classic Era / classic auction house:** "Your client does not support auction house search
  (SendBrowseQuery missing)" is gone - the classic auction house (Classic Era, TBC Anniversary,
  Wrath) is supported since 5.9.12; this is the first public release that includes it.
- **Size:** new option *Options -> Size in auction house* (100-160 %). Above 100 % the addon
  extends past the auction house to the right and down and everything (text included) gets
  bigger. A "<" button at the top leads back to the auction house. The separate window grows too.
- **Works next to TSM, Auctionator & co.:** the "AH Analyzer" tab now moves next to the
  right-most tab, including tabs that other addons add later - no more overlapping tabs.
  Clicking another addon's tab now closes the AH Analyzer view.
- Buy tab (classic auction house) now reads all result pages - before, it often showed only
  epic items.
- Tables: the scrollbar can be dragged with the mouse.

> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Fix (Classic auction house): the Buy tab only showed epic items - it stopped after the
  first result page. It now reads all pages (with a "page x of y" progress) and shows
  results while it is still searching.
- Tables: the scrollbar can now be dragged with the left mouse button, and clicking into
  the bar jumps there.
- Charts: tiny price changes no longer look like a crash; axis labels show silver/copper
  when needed.
- New tab **Buy** (right next to Overview) - works like the auction house's own Buy tab:
  - Search by name (part is enough) and/or category on the left (weapons, armor,
    containers, consumables, trade goods with cloth/leather/metal/herbs/cooking/
    elemental/enchanting, gems, recipes, miscellaneous), level from/to, rarity.
  - Results with available quantity, cheapest price per unit and % of market value.
  - Click an item to see all listings. Commodities: enter a quantity or click a price
    tier, "Buy now" gets the price from the server, "Confirm purchase" buys.
    Bait offers are marked. Gear: buyout (second click confirms) or place a bid.
  - Purchases are booked in the ledger right away. Sniper, price checks and the watcher
    wait while you search in the Buy tab.
- The addon window is now exactly as large as the auction house window (measured every
  time the auction house opens, also with UI scaling). Options > Window size: "like AH"
  switches it back on, - / + sets the size by hand.
- The addon window is always exactly as wide and as high as the auction house window
  (measured every time the auction house opens, UI scaling included; also the wide classic
  auction house). Options > Window size now only
  changes options, help and lists.
- Better use of space in every tab: lists and tables now stretch to the full width and
  height of the window (more rows, wider name column) - in the auction house and in the
  separate window. Fixed: the watchlist button and the chart item list reached past the
  bottom edge.
- No more stutter when scanning a big auction house: the scan only counts results while
  it runs, the evaluation afterwards (prices, bait check, names, price sync) runs in small
  portions over several frames, long lists are built and sorted in the background and at
  most once per second. In a test with 12,000 items the longest frame dropped from about
  660 ms to under 50 ms. Classic auction house: the full list is read in time slices too.
- Auction house view fills the whole auction house window (also the wider classic auction
  house in Classic Era / Anniversary), covers the classic search row and is no longer
  see-through.
- Nicer lists: every item list shows the item icon and the name in its rarity color;
  the cards in Overview and Ledger have icons and use the full width.
- Rarity is now a drop-down menu with check boxes (Poor, Common, Uncommon, Rare, Epic -
  any combination, e.g. only Uncommon and Epic) in the Buy tab and for sniper targets;
  older sniper targets keep their range. The sniper filter row (rarity, item level, level) is
  always visible now. New: rarity filter for the item list in Charts.
- Fresh look: every tab has its own icon in the title with a fading gold line; tables have
  a gradient header with a gold rule, a soft hover glow and a gold bar on the selected row;
  panels and cards get a subtle sheen and an inlaid border; charts show a soft gold area
  under the price line and highlight the current price.
- The separate addon window takes exactly the width and height of the auction house window.
- The sniper filter row (rarity, item level, level) is always visible.
- Auction house view: slightly narrower scan button so all eleven tabs fit in every language.

## 5.9.12
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Classic Era, TBC Anniversary and Wrath Classic:** the addon now works with the classic
  auction house. Fixes "Your client does not support the auction house search
  (SendBrowseQuery missing)".
  - Market scan reads the whole auction house at once (when the server allows it every
    15 minutes), otherwise page by page.
  - Price check, sniper (items and search terms), bargain watcher, buying, posting,
    your auctions and cancelling use the classic auction house functions.
  - Stackable goods are posted as full stacks (e.g. 35 linen cloth = one stack of 20,
    the rest with the next click). The deposit is not shown in the classic auction house.
- WoW Forever, Cataclysm Classic, Mists of Pandaria Classic and Retail are unchanged.

## 5.9.11
> ⚠️ **This is a beta version.** It may still contain bugs.
> If you run into any errors or unexpected behavior in-game, please report them in the comments on CurseForge, ideally with the Lua error message (if any) and the WoW version you play on.

- Updated version number to 5.9.11.
- Supports all WoW versions: Classic Era, WoW Forever, TBC Anniversary, Wrath Classic, Wrath Titan Reforged, Cataclysm Classic, Mists of Pandaria Classic and Retail.

## 5.9.1
- TOC: interface numbers for every WoW version (Classic Era, WoW Forever, TBC Anniversary,
  Wrath, Wrath Titan Reforged, Cataclysm, Mists of Pandaria Classic, Retail) - the addon
  is no longer listed as "out of date" there.

## 5.9
- Bait offers: a single unit at the very bottom of a commodity (linen cloth,
  copper bars ...) is treated as bait and ignored everywhere - sniper (no hit,
  status "bait offer"), sell suggestion and undercut check, market value,
  trends, bargains, EMAs and price sync. Gear is not affected.
- After every scan, suspiciously cheap commodities (below 70 % of market value)
  are stored as "unverified" and re-checked with a single search; the real
  price replaces them. Unverified prices never count and are not shared.
- Note: when buying commodities the server always sells the cheapest units
  first, so on a real hit the bait unit is bought along (and included in the
  planned cost).
- Charts: time-based EMAs over 6 hours, 1 day and 7 days (real prices only,
  from 10 prices on), markers where the 1-day EMA crosses the 7-day EMA,
  grey points for unverified prices. On/off button.
- New tab "Watcher" (bargain watcher) next to the sniper: searches trade goods
  (herbs, metal & stone, cloth, leather, enchanting, elemental, gems, cooking,
  optional consumables - never weapons/armor) for prices at or below x % of
  market value (default 50 %, minimum value per unit 10 copper). All categories
  run in one search, with automatic fallback to one category at a time. Every
  hit is verified (bait offers don't count), announced with sound and chat,
  and bought with the same mouse wheel / key as the sniper.
- Speed: search results are evaluated as soon as the server reports them,
  the server's own throttle is used instead of fixed waits (0.3 s instead of
  1.5-2 s between searches), automatic slow-down on errors. /ahp debug shows
  the speed.
- Sniper and watcher buy commodities with ONE mouse wheel notch: on a hit the
  price is fetched from the server in advance (and refreshed while the hit
  waits), the first notch buys right away. If the price has risen meanwhile,
  nothing is bought and a new search starts. If the server gives no price
  confirmation, it switches back to two notches by itself.
- In the auction house the options button is now a gear icon, so all ten tabs
  fit in every language.

## 5.8
- Disenchant values learn: every disenchant you do is recognised (spell + loot
  window) and remembered per group (quality, item level band, armor/weapon).
  The table values count as 10 imaginary disenchants; with each real one your
  results weigh more (50 % after 10, 83 % after 50, 91 % after 100), so chances
  and amounts move towards the reality on your server.
- The tooltip shows how many of your own results went into the value; the
  options show the total and can reset it.
- Starting values for green items as observed in the WoW Forever beta:
  70 % dust, 25 % essence, 5 % shards on every item level band (weapons
  mirrored: 70 % essence, 25 % dust).

## 5.7
- Mailbox: "Collect AH mail" takes gold and items from all auction mail with one
  click ("All" for every mail, COD is never paid). Invoices are booked first,
  stops when your bags are full.
- Sell tab: "Series" posts every bag item with a remembered price, one click per
  auction. Fresh prices are loaded at the start; items are skipped if the price
  falls below 70 % of your last price or a vendor pays more.
- Vendor buy prices are read automatically at every merchant: used for profession
  material costs, shopping lists (items cheaper at a vendor are not sniped) and
  shown in the tooltip.
- Alts & gold: gold, bags and bank of every character (account-wide). The tooltip
  shows how many your alts have; the Ledger tab has a "Gold" view with all
  characters and the gold of the last 30 days.
- Ledger "Statistics": sell-through per item, sales by time of day and weekday,
  best selling hours.
- Disenchant value (Classic table, estimates) in the tooltip and a new Profit view
  "Below disenchant value".

## 5.6
- Shopping lists: named lists of items and quantities. "Check prices" loads all
  listings at once, "As sniper targets" creates a target for every missing item
  (max price = 100/110/125/150 % of the market value). Items already in your bags
  are subtracted. Open via the Sniper tab, right-click on an item or `/ahp lists`.
- Professions: a window next to the profession frame (incl. Enchanting) shows
  material cost, value of the result and profit after the AH cut, plus the best
  recipes. "Materials as shopping list" puts the reagents for N crafts on a list.
- Help pages for all new tabs in all languages.

## 5.5
- New tab "Ledger": income (after the 5 % AH cut), spending, deposits and profit
  for today / 7 days / 30 days / all, per item or as a history.
  Sales and purchases are read from the invoices in your mailbox (just open it),
  sniper purchases and deposits are booked right away - nothing is counted twice.
- Sell tab warns when the price is below your average purchase price.

## 5.4
- New tab "Sell": items from your bags, price check, suggestion that undercuts the
  lowest listing (by 1 copper, 1 % or 5 %), quantity, duration, deposit, AH cut and
  proceeds. Warns (and asks for a second click) when a vendor pays more.
- New tab "Auctions": your auctions with status (lowest / tied / undercut / sold),
  "Check undercuts" and cancel with one click per auction.
- Tabs inside the auction house window shrink to fit in every language.

## 5.3
- Market value = median of the last 14 days (single outliers barely count).
- New column "% market" in the Market and Sniper tabs, coloured green to red.
- Vendor price in the item tooltip (can be turned off in the options).
- Profit tab: bargains below market value or below vendor price; a vendor bargain
  becomes a sniper target with one click. After every scan the chat shows how
  many items are listed below vendor price.
- Column headers explain themselves on mouse-over. CSV export has market value
  and vendor price.

## 4.9 – 5.2
- Prices and a small price chart in every item tooltip.
- The addon as its own tab inside the auction house window.
- Money shown with coin icons or letters.

## 4.8
- The addon now speaks the language of your WoW client: English, German, French,
  Spanish (EU/LA), Portuguese, Italian, Russian, Korean, Chinese (simplified/traditional).
- Language can be changed manually in the options or with `/ahp language`.

## 4.7
- German/English interface, item names follow the client language automatically.

## 4.6
- Built-in item name list for ~23,000 items in 10 languages (source: QuestieDB, wow-classic-items).

## 4.5
- Search items by name in any language, by item ID or by shift-clicking an item.
- Suggestions while typing, accents and upper/lower case don't matter.

## 4.4
- Two designs: "Classic" (looks like the WoW auction house) and "Modern".
- Options window, help for every tab, right-click menu on every item.

## 4.3
- Sniper: targets with max price per item, quantity, budget, rarity, item level and level filters.
- Searches targets on its own while the auction house is open; buy with the mouse wheel or your own key.

## 4.0 – 4.2
- Market scan, price history, trends, watchlist with alerts, charts, flipping calculator.
- Price sync between all players using the addon.
