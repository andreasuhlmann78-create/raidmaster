-- GuildSentinel - Comp.lua
-- Aufstellung der Gilde: Klassen und Rollen je Stufenbereich, verglichen mit einem Raid-Ziel (40er-Raid).
-- Was fehlt, steht im Platzhalter {gesucht} der Gildenwerbung, z. B. "Gesucht: Schamanen, Tanks, Hexenmeister."
--
-- Rolle eines Spielers (in dieser Reihenfolge):
--   1. selbst gewählt in GuildSentinel (Einstellungen / Gruppensuche) – in der Gilde geteilt
--   2. aus der Skillung, die RaidMaster kennt
--   3. geschätzt nach Klasse (Priester, Druide, Schamane, Paladin = Heiler, sonst Schaden; Tanks werden nie geschätzt)
--
--   G.roles[Name] = { r = "tank"/"heal"/"dps", t }
--   G.comp = { min = Stufe ab der gezählt wird, alts = Twinks mitzählen, want = { tank, heal, [Klasse] = Anzahl } }

local ADDON, ns = ...
local L = ns.L
local C = {}
ns.Comp = C

C.BANDS = { { min = 1, max = 29 }, { min = 30, max = 49 }, { min = 50, max = 59 }, { min = 60, max = 60 } }

-- Raid-Ziel für einen 40er-Raid in Classic (änderbar auf der Seite Mitglieder > Aufstellung)
C.DEFAULT_WANT = {
	tank = 4, heal = 12,
	WARRIOR = 8, ROGUE = 4, HUNTER = 3, MAGE = 6, WARLOCK = 4, PRIEST = 5, DRUID = 3, SHAMAN = 5, PALADIN = 5,
}

local HEALERS = { PRIEST = true, DRUID = true, SHAMAN = true, PALADIN = true }

-- Mehrzahl für die Werbung (eigene Schlüssel, damit Ein- und Mehrzahl getrennt übersetzt werden)
local PLURAL = {
	WARRIOR = L["Krieger#pl"], ROGUE = L["Schurken#pl"], HUNTER = L["Jäger#pl"], MAGE = L["Magier#pl"], WARLOCK = L["Hexenmeister#pl"],
	PRIEST = L["Priester#pl"], DRUID = L["Druiden#pl"], SHAMAN = L["Schamanen#pl"], PALADIN = L["Paladine#pl"],
	tank = L["Tanks#pl"], heal = L["Heiler#pl"],
}
function C:Plural(key)
	return ((PLURAL[key] or key):gsub("#pl$", ""))
end

function C:Classes()
	local faction = UnitFactionGroup and UnitFactionGroup("player")
	local list = { "WARRIOR", "ROGUE", "HUNTER", "MAGE", "WARLOCK", "PRIEST", "DRUID" }
	if faction == "Alliance" then list[#list + 1] = "PALADIN" else list[#list + 1] = "SHAMAN" end
	return list
end

------------------------------------------------------------
-- Einstellungen
------------------------------------------------------------
function C:Settings()
	local g = ns.G()
	g.comp = g.comp or {}
	local c = g.comp
	c.min = c.min or 55
	if c.alts == nil then c.alts = false end
	c.want = c.want or {}
	return c
end

function C:Want(key)
	local w = self:Settings().want[key]
	if w == nil then w = self.DEFAULT_WANT[key] or 0 end
	return w
end

function C:SetWant(key, n)
	if not ns.guild then return end
	self:Settings().want[key] = math.max(0, math.min(40, tonumber(n) or 0))
	ns:Fire("GS_COMP")
end

------------------------------------------------------------
-- Rollen
------------------------------------------------------------
-- Rolle und woher sie kommt ("own", "rm", "guess")
function C:Role(name, classFile)
	local r = ns.G().roles[name]
	if r and r.r then return r.r, "own" end
	local rm = ns.RMI:Role(name)
	if rm then return rm, "rm" end
	if ns.Same(name, ns.Me()) then
		local m = ns.G().mine[ns.Me()]
		if m and m.role then return m.role, "own" end
	end
	return (classFile and HEALERS[classFile]) and "heal" or "dps", "guess"
end

function C:ShareRole()
	local g = ns.guild
	if not g then return end
	local role = ns.Group:MyRole()
	g.roles[ns.Me()] = { r = role, t = ns.Now() }
	ns.Comm:Send("ROLE", { r = role, t = ns.Now() })
	ns:Fire("GS_COMP")
end

local function StoreRole(name, r, t)
	local g = ns.guild
	if not g or (r ~= "tank" and r ~= "heal" and r ~= "dps") or type(t) ~= "number" then return false end
	local old = g.roles[name]
	if old and (old.t or 0) >= t then return false end
	g.roles[name] = { r = r, t = t }
	return true
end
C.StoreRole = StoreRole

ns.Comm:Register("ROLE", function(sender, d)
	if StoreRole(sender, d.r, tonumber(d.t)) then ns:Fire("GS_COMP") end
end)

ns:Listen("GS_LOGIN", function()
	C_Timer.After(18, function()
		local m = ns.G().mine[ns.Me()]
		if m and m.role then C:ShareRole() end
	end)
end)

------------------------------------------------------------
-- Zählen
------------------------------------------------------------
-- Tabelle: rows = { { key, label, bands = { n1..n4 }, raid = Anzahl ab Mindeststufe, want, missing, guessed } }
function C:Table()
	local s = self:Settings()
	local rows, byKey = {}, {}
	local function Row(key, label, isRole)
		local r = { key = key, label = label, role = isRole, bands = { 0, 0, 0, 0 }, raid = 0, guessed = 0 }
		rows[#rows + 1] = r
		byKey[key] = r
		return r
	end
	Row("tank", L["Tanks"], true)
	Row("heal", L["Heiler"], true)
	Row("dps", L["Schaden"], true)
	for _, cf in ipairs(self:Classes()) do Row(cf, ns.ClassName(cf), false) end
	for _, e in ipairs(ns.Roster.list) do
		if s.alts or not ns.Roster:IsAlt(e.name) then
			local band
			for i, b in ipairs(self.BANDS) do if e.level >= b.min and e.level <= b.max then band = i end end
			local role, src = self:Role(e.name, e.class)
			for _, key in ipairs({ role, e.class }) do
				local r = byKey[key]
				if r then
					if band then r.bands[band] = r.bands[band] + 1 end
					if e.level >= s.min then
						r.raid = r.raid + 1
						if r.role and src == "guess" then r.guessed = r.guessed + 1 end
					end
				end
			end
		end
	end
	for _, r in ipairs(rows) do
		if r.key == "dps" then r.want = nil else r.want = self:Want(r.key) end
		r.missing = r.want and math.max(0, r.want - r.raid) or 0
	end
	return rows
end

-- Was fehlt (größte Lücke zuerst): { { key, label, missing } }
function C:Missing()
	local out = {}
	for _, r in ipairs(self:Table()) do
		if r.missing > 0 then out[#out + 1] = { key = r.key, label = self:Plural(r.key), missing = r.missing, role = r.role, want = r.want } end
	end
	table.sort(out, function(a, b)
		-- Anteil, der fehlt, entscheidet (4 von 4 Tanks fehlen wiegt mehr als 4 von 8 Kriegern)
		local fa, fb = a.missing / math.max(1, a.want), b.missing / math.max(1, b.want)
		if fa ~= fb then return fa > fb end
		if a.missing ~= b.missing then return a.missing > b.missing end
		if a.role ~= b.role then return a.role end
		return a.label < b.label
	end)
	return out
end

-- Text für {gesucht}: "Gesucht: Schamanen, Tanks, Hexenmeister." (höchstens drei, leer wenn nichts fehlt)
function C:WantedText(max)
	local list = self:Missing()
	if #list == 0 then return "" end
	local t = {}
	for i = 1, math.min(max or 3, #list) do t[i] = list[i].label end
	return string.format(L["Gesucht: %s."], table.concat(t, ", "))
end
