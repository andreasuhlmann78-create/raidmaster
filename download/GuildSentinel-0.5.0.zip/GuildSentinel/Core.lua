-- GuildSentinel - Core.lua
-- Grundlagen: Datenbank, Ereignisse, Hilfsfunktionen, Slash-Befehle.
--
-- GuildSentinelDB = {
--   settings = { ... },                        -- für alle Charaktere gleich (Fenster, Minimap ...)
--   guilds = { ["Realm|Gilde"] = G },          -- je Gilde eigene Daten
-- }
-- G = {
--   roster   = { [Name] = { c, l, r, ri, z, no, on, seen, first } }   -- letzter bekannter Stand
--   log      = { { t, k, n, x } }               -- Verlauf (beigetreten, verlassen, befördert ...)
--   notes    = { [Name] = "Eigene Notiz" }      -- nur für mich
--   alts     = { [Twink] = { m = Main, t, by } } -- Twinks (in der Gilde geteilt)
--   mine     = { [Name] = { c, l } }            -- meine eigenen Charaktere in dieser Gilde
--   prof     = { [Name] = { c, t, p = { [Beruf] = { r, m, n = { Rezepte } } } } }
--   apps     = { [Name] = { t, msg, c, st } }   -- Bewerber
-- }

local ADDON, ns = ...
local L = ns.L

ns.version = "0.5.0"
ns.ICON = "Interface\\Icons\\INV_Shirt_GuildTabard_01"
ns.HEX = "4fd18a"
ns.ACCENT = { 0.31, 0.82, 0.54 }
ns.TITLE = "|cff4fd18aGuild|rSentinel"

------------------------------------------------------------
-- Standardwerte
------------------------------------------------------------
ns.defaults = {
	minimapShow = true,
	minimapAngle = 200,
	framePoint = nil,
	-- Rekrutierung
	adText = "",
	adTargets = {},            -- gewählte Kanäle (Kurzname, klein geschrieben)
	adInterval = 15,           -- Minuten bis zur Erinnerung
	adRemind = true,
	keywords = "",
	autoReply = true,
	replyText = "",
	welcome = true,
	welcomeText = "",
	discord = "",
	askQuestions = true,       -- Bewerbungsfragen stellen
	questions = "",            -- eine Frage pro Zeile (leer = Standardfragen)
	tooltip = true,            -- Infos im Spieler-Tooltip
	-- Anzeige
	showOffline = true,
	showAlts = true,
	-- Ansagen im Gildenchat (es sagt immer nur einer an, auch wenn mehrere das Addon haben)
	annLevels = true,          -- Stufen-Meilensteine
	annMilestones = { [10] = true, [20] = true, [30] = true, [40] = true, [50] = true, [60] = true },
	annFirst = true,           -- "Erster der Gilde auf 60"
	annJubilee = true,         -- Jubiläen (1, 3, 6 Monate, 1 Jahr)
	rulesPopup = true,         -- neue Gildenregeln beim Einloggen zeigen
	-- Gruppensuche
	lfgNotify = true,          -- Hinweis, wenn eine passende Suche kommt
	lfgServer = true,          -- Suchen vom ganzen Server sehen (eigener, ausgeblendeter Kanal)
	lfgSound = true,
}

ns.guildDefaults = {
	roster = {}, log = {}, notes = {}, alts = {}, mine = {}, prof = {},
	apps = {},
	levels = {},               -- [Name] = { [Stufe] = Zeit }  (wann erreicht, soweit gesehen)
	race = {},                 -- { first60 = { n, t } }
	attune = {},               -- [Name] = { t, k = { mc = true, ... } }
	act = {},                  -- [Halbstunden-Nr.] = Spieler online
	days = {},                 -- [Name] = { [Tag-Nr.] = true }  (an welchen Tagen online)
	firstSeen = {},            -- [Name] = Zeit (frühester bekannter Beitritt, in der Gilde geteilt)
	rules = { v = 0, t = 0, text = "", by = "" },
	rulesAck = {},             -- [Name] = { v, t }
	ann = {},                  -- [Schlüssel] = Zeit  (schon angesagt)
	promo = {},                -- [Rang-Index] = { on, days, level, active }
	lfg = {},                  -- [id] = Suche (Gruppensuche)
	roles = {},                -- [Name] = { r = Rolle, t }  (selbst gewählt, geteilt)
	comp = {},                 -- Aufstellung: { min, alts, want = { ... } }
	polls = {},                -- [id] = Umfrage
	creq = {},                 -- [id] = Herstellungswunsch
	craftWatch = {},           -- [Item-ID] = Beruf-Zauber-ID (zusätzlich beobachtete Rezepte)
}

------------------------------------------------------------
-- Kompatibilität
------------------------------------------------------------
ns.GetItemInfo = (C_Item and C_Item.GetItemInfo) or GetItemInfo
ns.SendAddonMessage = (C_ChatInfo and C_ChatInfo.SendAddonMessage) or SendAddonMessage
ns.RegisterPrefix = (C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix) or RegisterAddonMessagePrefix
ns.GuildRoster = (C_GuildInfo and C_GuildInfo.GuildRoster) or GuildRoster

------------------------------------------------------------
-- Ereignisse
------------------------------------------------------------
local frame = CreateFrame("Frame")
local handlers = {}
local listeners = {}

function ns:On(event, fn)
	if not handlers[event] then
		handlers[event] = {}
		if not event:find("^GS_") then frame:RegisterEvent(event) end
	end
	table.insert(handlers[event], fn)
end

frame:SetScript("OnEvent", function(_, event, ...)
	local list = handlers[event]
	if not list then return end
	for _, fn in ipairs(list) do
		local ok, err = pcall(fn, ...)
		if not ok and ns.debug then ns:Print("|cffff4040" .. event .. ":|r " .. tostring(err)) end
	end
end)

-- interne Nachrichten (Seiten aktualisieren usw.)
function ns:Listen(name, fn)
	listeners[name] = listeners[name] or {}
	table.insert(listeners[name], fn)
end

function ns:Fire(name, ...)
	for _, fn in ipairs(listeners[name] or {}) do
		local ok, err = pcall(fn, ...)
		if not ok and ns.debug then ns:Print("|cffff4040" .. name .. ":|r " .. tostring(err)) end
	end
end

------------------------------------------------------------
-- Hilfsfunktionen
------------------------------------------------------------
function ns:Print(msg)
	DEFAULT_CHAT_FRAME:AddMessage(ns.TITLE .. ": " .. tostring(msg))
end

function ns.Short(name)
	if type(name) ~= "string" then return nil end
	return (name:gsub("%-.*$", ""))
end

function ns.Me()
	return ns.Short(UnitName("player"))
end

function ns.Same(a, b)
	return a and b and ns.Short(a):lower() == ns.Short(b):lower()
end

-- Name schön schreiben: "aRTHAS" -> "Arthas" (nur erster Buchstabe, Umlaute bleiben)
function ns.Proper(name)
	name = ns.Short(name)
	if not name or name == "" then return name end
	name = name:gsub("^%s+", ""):gsub("%s+$", "")
	local first = name:match("^[%z\1-\127\194-\244][\128-\191]*") or name:sub(1, 1)
	return first:upper() .. name:sub(#first + 1):lower()
end

function ns.Now()
	return GetServerTime and GetServerTime() or time()
end

local function MergeDefaults(dst, src)
	for k, v in pairs(src) do
		if type(v) == "table" then
			if type(dst[k]) ~= "table" then dst[k] = {} end
			MergeDefaults(dst[k], v)
		elseif dst[k] == nil then
			dst[k] = v
		end
	end
end
ns.MergeDefaults = MergeDefaults

function ns.Copy(t)
	if type(t) ~= "table" then return t end
	local c = {}
	for k, v in pairs(t) do c[k] = ns.Copy(v) end
	return c
end

function ns.Count(t)
	local n = 0
	for _ in pairs(t or {}) do n = n + 1 end
	return n
end

function ns.Trim(s)
	return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

-- Klassenfarbe als Hex
function ns.ClassHex(classFile)
	local c = classFile and (CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS)[classFile]
	if not c then return "ffffff" end
	if c.colorStr then return c.colorStr:sub(3) end
	return string.format("%02x%02x%02x", c.r * 255, c.g * 255, c.b * 255)
end

function ns.ClassName(classFile)
	if not classFile then return "" end
	return (LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[classFile]) or classFile
end

function ns.Colored(name, classFile)
	return "|cff" .. ns.ClassHex(classFile) .. tostring(name) .. "|r"
end

-- "vor 3 Tagen", "vor 2 Std." …
function ns.Ago(t)
	if not t or t <= 0 then return L["unbekannt"] end
	local d = ns.Now() - t
	if d < 60 then return L["gerade eben"] end
	if d < 3600 then return string.format(L["vor %d Min."], math.floor(d / 60)) end
	if d < 86400 then return string.format(L["vor %d Std."], math.floor(d / 3600)) end
	local days = math.floor(d / 86400)
	if days == 1 then return L["gestern"] end
	if days < 60 then return string.format(L["vor %d Tagen"], days) end
	return string.format(L["vor %d Monaten"], math.floor(days / 30))
end

function ns.Date(t)
	return date(L["%d.%m. %H:%M"], t or ns.Now())
end

function ns.ItemID(link)
	if type(link) == "number" then return link end
	return type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil
end

-- Item-Infos (kann beim ersten Mal leer sein, dann kommt GET_ITEM_INFO_RECEIVED)
function ns.Item(id)
	if not id or id == 0 then return nil end
	local name, link, quality, _, _, _, _, _, _, icon = ns.GetItemInfo(id)
	return name, link, quality, icon
end

function ns.ItemIcon(id)
	local _, _, _, icon = ns.Item(id)
	if not icon and GetItemIcon then icon = GetItemIcon(id) end
	return icon or "Interface\\Icons\\INV_Misc_QuestionMark"
end

ns:On("GET_ITEM_INFO_RECEIVED", function()
	if ns.itemTimer then return end
	ns.itemTimer = true
	C_Timer.After(0.5, function() ns.itemTimer = nil; ns:Fire("GS_ITEMS") end)
end)

-- Text mit {platzhaltern} füllen
function ns.Fill(text, vars)
	return (tostring(text or ""):gsub("{(%w+)}", function(k)
		local v = vars[k]
		if v == nil then return "{" .. k .. "}" end
		return tostring(v)
	end))
end

------------------------------------------------------------
-- Gilde und Rechte
------------------------------------------------------------
function ns.GuildName()
	if not IsInGuild() then return nil end
	return (GetGuildInfo("player"))
end

function ns.IsOfficer()
	if not IsInGuild() then return false end
	if CanEditOfficerNote and CanEditOfficerNote() then return true end
	if CanGuildRemove and CanGuildRemove() then return true end
	if CanGuildPromote and CanGuildPromote() then return true end
	return false
end

function ns.CanInvite()
	return IsInGuild() and CanGuildInvite and CanGuildInvite() and true or false
end

------------------------------------------------------------
-- Datenbank
------------------------------------------------------------
local EMPTY = {}
for k in pairs(ns.guildDefaults) do EMPTY[k] = {} end

-- aktuelle Gilde (ohne Gilde: leere Tabelle, die nicht gespeichert wird)
function ns.G()
	return ns.guild or EMPTY
end

function ns:SetupGuild()
	local gname = ns.GuildName()
	if not gname then
		ns.guild, ns.guildKey = nil, nil
		return
	end
	local realm = GetRealmName and GetRealmName() or ""
	local key = realm .. "|" .. gname
	if ns.guildKey == key then return end
	GuildSentinelDB.guilds[key] = GuildSentinelDB.guilds[key] or {}
	local g = GuildSentinelDB.guilds[key]
	MergeDefaults(g, ns.guildDefaults)
	-- 0.3.0: keine Gildenbank mehr in GuildSentinel – alte Daten entfernen
	g.bank, g.bankLocal, g.wishes, g.don, g.cfg, g.names = nil, nil, nil, nil, nil, nil
	ns.guild, ns.guildKey = g, key
	-- mich selbst als eigenen Charakter merken
	local _, classFile = UnitClass("player")
	g.mine[ns.Me()] = { c = classFile, l = UnitLevel("player") }
	ns:Fire("GS_GUILD")
end

ns:On("ADDON_LOADED", function(name)
	if name ~= ADDON then return end
	GuildSentinelDB = GuildSentinelDB or {}
	GuildSentinelDB.settings = GuildSentinelDB.settings or {}
	GuildSentinelDB.guilds = GuildSentinelDB.guilds or {}
	MergeDefaults(GuildSentinelDB.settings, ns.defaults)
	ns.db = GuildSentinelDB.settings
	if ns.Comm then ns.Comm:Setup() end
end)

ns:On("PLAYER_LOGIN", function()
	ns:SetupGuild()
	if ns.UI then ns.UI:Login() end
	if IsInGuild() and ns.GuildRoster then ns.GuildRoster() end
	ns:Fire("GS_LOGIN")
end)

-- Gildeninfo kommt manchmal erst etwas später
ns:On("PLAYER_GUILD_UPDATE", function()
	C_Timer.After(1, function() ns:SetupGuild() end)
end)
ns:On("GUILD_ROSTER_UPDATE", function()
	if not ns.guild then ns:SetupGuild() end
end)

------------------------------------------------------------
-- Slash-Befehle (alles geht auch per Maus im Fenster)
------------------------------------------------------------
SLASH_GUILDSENTINEL1 = "/gs"
SLASH_GUILDSENTINEL2 = "/guildsentinel"
SlashCmdList.GUILDSENTINEL = function(msg)
	msg = ns.Trim(msg)
	local cmd, rest = msg:match("^(%S*)%s*(.-)$")
	cmd = (cmd or ""):lower()
	if cmd == "" then
		if ns.UI then ns.UI:Toggle() end
	elseif cmd == "berufe" or cmd == "prof" then
		ns.Prof:ReadNext()
	elseif cmd == "suche" or cmd == "find" then
		if ns.UI then ns.UI:Open("prof", rest) end
	elseif cmd == "gruppe" or cmd == "group" or cmd == "lfg" then
		if ns.UI then ns.UI:Open("group") end
	elseif cmd == "fortschritt" or cmd == "progress" or cmd == "rennen" then
		if ns.UI then ns.UI:Open("progress") end
	elseif cmd == "zugang" or cmd == "attune" then
		if ns.UI then ns.UI:Open("progress", "attune") end
	elseif cmd == "umfrage" or cmd == "poll" then
		if ns.UI then ns.UI:Open("poll") end
	elseif cmd == "regeln" or cmd == "rules" then
		ns.Rules:ShowPopup(true)
	elseif cmd == "werbung" or cmd == "ad" then
		ns.Recruit:Post()
	elseif cmd == "debug" then
		ns.debug = not ns.debug
		ns:Print("debug " .. tostring(ns.debug))
	else
		ns:Print(L["Befehle: /gs (Fenster), /gs gruppe, /gs umfrage, /gs fortschritt, /gs zugang, /gs regeln, /gs berufe, /gs suche <Rezept>, /gs werbung"])
	end
end
