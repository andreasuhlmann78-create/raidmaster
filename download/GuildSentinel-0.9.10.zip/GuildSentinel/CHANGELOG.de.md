# GuildSentinel – Änderungen

## 0.9.10
- **Twink-Notizen in der Sprache des Clients**: Notizen, die GuildSentinel selbst schreibt ("Reroll de …", "… 的分身" usw.), werden auf französischen, spanischen, italienischen, portugiesischen, koreanischen und chinesischen Clients wieder erkannt. Wo die Kennzeichnung nicht in die kurze Gildennotiz passt (Russisch), schreibt GuildSentinel die Kurzform "Alt: Name".
- **AHSentinel** (früher AH Analyzer Pro) wird unter dem neuen Ordnernamen erkannt (Seite Addons, Marktwerte).
- **Bewerber-Flüstern im Kampf** (WoW Forever): Mehr als 30 Flüsternachrichten in einem Kampf werden jetzt im Hinweis mitgezählt, statt still wegzufallen.
- Robuster bei beschädigten Daten: fehlerhafte Termin-Abgleiche und kaputte Termin- oder Danke-Einträge lösen keine Fehler mehr aus.
- Testmodus (nur Entwickler): betritt oder verlässt den Server-Kanal nicht mehr, sendet nach "Testmodus beenden" nichts Verzögertes mehr und lässt die echten Einstellungen (letzte Werbung, Frei-Meldung, Meine Woche) unberührt.
- Neu für den Entwickler: `/gs testroutine` (Knopf "Alles testen" unter Einstellungen > Testmodus) prüft alle Funktionen und speichert einen Bericht für die Prüfung von GoldSentinel; die Diagnose zeigt den Fehlerzähler. Für Spieler ändert sich nichts.

Ältere Versionen: siehe LIESMICH.txt.
