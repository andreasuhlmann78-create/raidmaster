-- BuffSentinel - Display.lua
-- Klickbare Buttons: Procs (Klick löst aus), fehlende Buffs (Klick buffed), Cooldowns (Klick wirkt)
--
-- Blizzard-Regel: Klick-Buttons, die Zauber wirken, dürfen im Kampf weder erstellt, ein-/ausgeblendet,
-- verschoben noch umkonfiguriert werden. Darum: Vor dem Kampf werden alle erlaubten Buttons "scharf"
-- gemacht (sichtbar, aber durchsichtig). Im Kampf wird nur die Deckkraft geändert – das ist erlaubt.
--
-- Verschieben (nur ausserhalb des Kampfes):
--   Testmodus:  Button ziehen = nur dieser Button,  Shift + ziehen = ganze Gruppe,  Rechtsklick = zurücksetzen
--   sonst:      Shift + ziehen = nur dieser Button

local ADDON, BS = ...

local SIZES   = { proc = 56, buff = 50, cd = 40, dispel = 34 }
local SPACING = { proc = 48, buff = 44, cd = 6 }
local ANCHORS = {
    proc   = { label = "Procs",     x = 0, y = 170 },
    buff   = { label = "Buffs",     x = 0, y = 95 },
    cd     = { label = "Cooldowns", x = 0, y = -200 },
    dispel = { label = "Reinigen",  x = -420, y = 60, w = 300, h = 120, point = "TOPLEFT" },
}
local KIND_ORDER   = { "proc", "buff", "cd" }               -- Button-Pools
local ANCHOR_ORDER = { "proc", "buff", "cd", "dispel" }     -- verschiebbare Bereiche
BS.ANCHOR_ORDER = ANCHOR_ORDER

-- Moderne Clients filtern Klicks je nach "Beim Drücken auslösen"-Einstellung selbst
local USE_KEYDOWN = GetCVar and GetCVar("ActionButtonUseKeyDown") ~= nil

------------------------------------------------------------------------
-- Sound
------------------------------------------------------------------------
-- Warntöne nicht zu schnell hintereinander: pro Art höchstens alle SOUND_SAME Sekunden,
-- zwischen zwei beliebigen Tönen mindestens SOUND_ANY Sekunden. "Sounds testen" (force) ist ausgenommen.
local SOUND_SAME, SOUND_ANY = 4, 1.5
local lastSound, lastAnySound = {}, 0

-- kind: "buff" | "proc" | "cooldown" | "dispel" | "dispel_imp" (wichtiger Debuff)
local function PlayAlert(kind, force)
    local s = BS.db and BS.db.sound
    local setting = (kind == "dispel_imp") and "dispel" or kind
    if not force and (not s or not s[setting]) then return end
    local now = GetTime()
    if not force then
        if now - lastAnySound < SOUND_ANY then return end
        if now - (lastSound[kind] or 0) < SOUND_SAME then return end
    end
    lastSound[kind], lastAnySound = now, now
    local id
    if kind == "buff" or kind == "dispel_imp" then
        id = (SOUNDKIT and SOUNDKIT.RAID_WARNING) or 8959
    elseif kind == "proc" then
        id = (SOUNDKIT and SOUNDKIT.ALARM_CLOCK_WARNING_3) or 12889
    elseif kind == "dispel" then
        id = (SOUNDKIT and SOUNDKIT.IG_PLAYER_INVITE) or 880
    else
        id = (SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON) or 856
    end
    pcall(PlaySound, id, "Master")
end
BS.PlayAlert = PlayAlert

------------------------------------------------------------------------
-- Anker (verschiebbare Bereiche)
------------------------------------------------------------------------
local function SaveAnchor(kind, f)
    local p1, _, p2, x, y = f:GetPoint()
    BS.db.pos[kind] = { p1, p2, x, y }
end

function BS:CreateDisplay()
    self.anchors = {}
    for _, kind in ipairs(ANCHOR_ORDER) do
        local a = ANCHORS[kind]
        local f = CreateFrame("Frame", "BuffSentinelAnchor_" .. kind, UIParent)
        f:SetSize(a.w or 340, a.h or (SIZES[kind] + 24))
        f:SetMovable(true)
        f:SetClampedToScreen(true)
        f:SetFrameStrata("MEDIUM")
        f.kind = kind

        f.bg = f:CreateTexture(nil, "BACKGROUND")
        f.bg:SetAllPoints()
        f.bg:SetColorTexture(0.15, 0.55, 1, 0.25)
        f.text = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        f.text:SetPoint("TOP", f, "TOP", 0, 14)
        f.text:SetText(a.label .. " – Fläche ziehen = ganze Gruppe")

        f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", function(s)
            if not InCombatLockdown() then s:StartMoving() end
        end)
        f:SetScript("OnDragStop", function(s)
            s:StopMovingOrSizing()
            SaveAnchor(kind, s)
        end)
        self.anchors[kind] = f
    end
    self:ApplyPositions()
    self:ApplyScale()
    self:ApplyLock()
end

function BS:ApplyPositions()
    if InCombatLockdown() then return end
    for kind, f in pairs(self.anchors) do
        f:ClearAllPoints()
        local p = self.db.pos[kind]
        if p then
            f:SetPoint(p[1], UIParent, p[2], p[3], p[4])
        else
            local a = ANCHORS[kind]
            f:SetPoint(a.point or "CENTER", UIParent, "CENTER", a.x, a.y)
        end
    end
end

function BS:ResetPositions()
    if InCombatLockdown() then BS.Print("Im Kampf nicht möglich.") return end
    wipe(self.db.pos)
    wipe(self.db.btnPos)
    self:ApplyPositions()
    self:Layout()
end

function BS:ResetButtonPosition(key)
    if InCombatLockdown() or not key then return end
    self.db.btnPos[key] = nil
    self:Layout()
end

function BS:ApplyScale()
    if InCombatLockdown() then return end
    for _, f in pairs(self.anchors) do f:SetScale(self.db.scale or 1) end
end

function BS:ApplyLock()
    if InCombatLockdown() then return end
    local unlocked = self.testMode or not self.db.locked
    for _, f in pairs(self.anchors) do
        f:EnableMouse(unlocked)
        if unlocked then f.bg:Show(); f.text:Show() else f.bg:Hide(); f.text:Hide() end
    end
    self:Refresh()
end

------------------------------------------------------------------------
-- Buttons
------------------------------------------------------------------------
local function SetFontSize(fs, size, flags)
    local font = fs:GetFont()
    if font then fs:SetFont(font, size, flags or "OUTLINE") end
end

local function ShowGlow(b, on)
    if on then
        if not b.glow:IsShown() then
            b.glow:Show()
            if b.anim then b.anim:Play() end
        end
    elseif b.glow:IsShown() then
        b.glow:Hide()
        if b.anim then b.anim:Stop() end
    end
end

-- Ziehen: einzelner Button oder ganze Gruppe (Anker)
local function DragStart(b)
    if InCombatLockdown() or not b.entry then return end
    if BS.testMode then
        if IsShiftKeyDown() then
            b.dragGroup = true
            b:GetParent():StartMoving()
        else
            b.dragGroup = false
            b:StartMoving()
        end
    elseif IsShiftKeyDown() then
        b.dragGroup = false
        b:StartMoving()
    else
        return
    end
    b.dragging = true
end

local function DragStop(b)
    if not b.dragging then return end
    b.dragging = false
    if b.dragGroup then
        local f = b:GetParent()
        f:StopMovingOrSizing()
        SaveAnchor(f.kind, f)
    else
        b:StopMovingOrSizing()
        if b.SetUserPlaced then b:SetUserPlaced(false) end
        local p1, _, p2, x, y = b:GetPoint()
        if b.entry then BS.db.btnPos[BS.ButtonPosKey(b.entry)] = { p1, p2, x, y } end
        b.moved = true
    end
end

local function CreateButton(kind, i)
    local size = SIZES[kind]
    local b = CreateFrame("Button", "BuffSentinel_" .. kind .. i, BS.anchors[kind], "SecureActionButtonTemplate")
    b:SetSize(size, size)
    b:SetFrameStrata("MEDIUM")
    b:SetMovable(true)
    b:SetClampedToScreen(true)
    if USE_KEYDOWN then b:RegisterForClicks("AnyUp", "AnyDown") else b:RegisterForClicks("AnyUp") end
    b:RegisterForDrag("LeftButton")
    b:SetScript("OnDragStart", DragStart)
    b:SetScript("OnDragStop", DragStop)
    b:HookScript("OnMouseUp", function(self, button)
        if BS.testMode and button == "RightButton" and self.entry and not InCombatLockdown() then
            BS:ResetButtonPosition(BS.ButtonPosKey(self.entry))
        end
    end)
    b.kind = kind

    b.border = b:CreateTexture(nil, "BACKGROUND")
    b.border:SetPoint("TOPLEFT", -2, 2)
    b.border:SetPoint("BOTTOMRIGHT", 2, -2)
    b.border:SetColorTexture(0, 0, 0, 0.9)

    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetAllPoints()
    b.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)

    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.15)

    b.glow = b:CreateTexture(nil, "OVERLAY")
    b.glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    b.glow:SetBlendMode("ADD")
    b.glow:SetPoint("CENTER")
    b.glow:SetSize(size * 1.9, size * 1.9)
    if kind == "buff" then b.glow:SetVertexColor(1, 0.3, 0.3) else b.glow:SetVertexColor(1, 0.8, 0.25) end
    b.glow:Hide()
    if b.glow.CreateAnimationGroup then
        b.anim = b.glow:CreateAnimationGroup()
        local a = b.anim:CreateAnimation("Alpha")
        if a.SetFromAlpha then a:SetFromAlpha(1); a:SetToAlpha(0.25) else a:SetChange(-0.75) end
        a:SetDuration(0.45)
        b.anim:SetLooping("BOUNCE")
    end

    if kind == "cd" then
        local ok, cd = pcall(CreateFrame, "Cooldown", nil, b, "CooldownFrameTemplate")
        if ok and cd then
            cd:SetAllPoints()
            if cd.SetHideCountdownNumbers then cd:SetHideCountdownNumbers(true) end
            if cd.SetDrawEdge then cd:SetDrawEdge(false) end
            b.cd = cd
        end
    end

    -- Rahmen für "frei platziert" (nur im Testmodus sichtbar)
    b.placed = b:CreateTexture(nil, "BORDER")
    b.placed:SetPoint("TOPLEFT", -3, 3)
    b.placed:SetPoint("BOTTOMRIGHT", 3, -3)
    b.placed:SetColorTexture(0.2, 0.9, 0.4, 0.9)
    b.placed:Hide()

    local overlay = CreateFrame("Frame", nil, b)
    overlay:SetAllPoints()
    overlay:SetFrameLevel(b:GetFrameLevel() + 5)

    b.timer = overlay:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    b.timer:SetPoint("CENTER")
    SetFontSize(b.timer, math.floor(size * 0.40))

    b.count = overlay:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    b.count:SetPoint("BOTTOMRIGHT", -2, 3)
    SetFontSize(b.count, math.floor(size * 0.30))

    b.label = overlay:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    b.label:SetPoint("TOP", b, "BOTTOM", 0, -4)
    b.label:SetWidth(size + SPACING[kind] - 4)
    SetFontSize(b.label, 12)
    if kind == "buff" then b.label:SetTextColor(1, 0.35, 0.35) else b.label:SetTextColor(1, 0.75, 0.25) end
    if kind == "cd" then b.label:Hide() end

    b.target = overlay:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.target:SetPoint("TOP", b.label, "BOTTOM", 0, -2)
    b.target:SetWidth(size + SPACING[kind] + 20)

    b:SetScript("OnEnter", function(self)
        local e = self.entry
        if not e then return end
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine(e.label, 1, 0.82, 0)
        if BS.testMode then
            GameTooltip:AddLine("Testmodus – Klick wirkt nichts", 0.4, 0.9, 0.5)
            GameTooltip:AddLine("Ziehen: nur dieser Button", 0.8, 0.8, 0.8)
            GameTooltip:AddLine("Shift + ziehen: ganze Gruppe", 0.8, 0.8, 0.8)
            GameTooltip:AddLine("Rechtsklick: Position zurücksetzen", 0.8, 0.8, 0.8)
        elseif e.data.alertOnly then
            GameTooltip:AddLine("Nur Meldung (kein Zauber hinterlegt)", 0.8, 0.8, 0.8)
        elseif e.data.items then
            GameTooltip:AddLine("Klick: " .. (e.itemName or "kein passender Gegenstand") ..
                (e.data.weapon == "off" and " auf Nebenhand" or " auf Haupthand"), 0.8, 0.8, 0.8)
        else
            local spell = self:GetAttribute("spell") or e.spellName or "?"
            local unit = self:GetAttribute("unit")
            if unit and unit ~= "player" then
                GameTooltip:AddLine("Klick: " .. spell .. " auf " .. (UnitName(unit) or unit), 0.8, 0.8, 0.8)
            else
                GameTooltip:AddLine("Klick: " .. spell, 0.8, 0.8, 0.8)
            end
        end
        if not BS.testMode and not InCombatLockdown() then
            GameTooltip:AddLine("Shift + ziehen: verschieben", 0.5, 0.5, 0.55)
        end
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)

    b:Hide()
    return b
end

function BS:GetButton(kind, i)
    local pool = self.pools[kind]
    if not pool[i] then pool[i] = CreateButton(kind, i) end
    return pool[i]
end

local function ConfigureButton(b, e)
    b.entry = e
    b.wasShown, b.wasReady, b.readyInit, b.flashUntil, b.cdStart = false, nil, false, nil, nil
    b.icon:SetTexture(e.icon)
    b.icon:SetDesaturated(false)
    b.icon:SetVertexColor(1, 1, 1)
    b.timer:SetText("")
    b.count:SetText("")
    b.target:SetText("")
    b.label:SetText(e.alertText or e.label)
    ShowGlow(b, false)
    if b.cd then b.cd:SetCooldown(0, 0) end

    b:SetAttribute("macrotext", nil)
    if BS.testMode then
        -- Testmodus: Klicks wirken nichts
        b:SetAttribute("type", nil)
        b:SetAttribute("spell", nil)
    elseif e.data.items then
        -- Gift/Gegenstand auf die Waffe: "/use item:ID" + Waffenplatz (16 Haupthand, 17 Nebenhand)
        b:SetAttribute("type", "macro")
        b:SetAttribute("spell", nil)
        if e.itemID then
            local slot = (e.data.weapon == "off") and 17 or 16
            b:SetAttribute("macrotext", "/use item:" .. e.itemID .. "\n/use " .. slot)
        end
    elseif e.spellName and not e.data.alertOnly then
        b:SetAttribute("type", "spell")
        b:SetAttribute("spell", e.spellName)
    else
        b:SetAttribute("type", nil)
        b:SetAttribute("spell", nil)
    end
    if e.kind == "buff" and not e.data.items then
        b:SetAttribute("unit", "player")
    else
        b:SetAttribute("unit", nil)
    end
end

------------------------------------------------------------------------
-- Layout: Einträge der aktuellen Skillung auf Buttons verteilen (nur ausserhalb des Kampfes)
------------------------------------------------------------------------
function BS:Layout()
    if not self.ready or not self.anchors then return end
    if InCombatLockdown() then self.pendingLayout = true return end
    self.pendingLayout = false

    self:ResolveEntries()
    self:ScanPlayerAuras()

    for _, kind in ipairs(KIND_ORDER) do
        for _, b in ipairs(self.pools[kind]) do
            b.entry = nil
            b:Hide()
            b:SetAttribute("type", nil)
            b:SetAttribute("spell", nil)
            b:SetAttribute("unit", nil)
        end
    end

    local count = { buff = 0, proc = 0, cd = 0 }
    self.hasItemEntries = false
    for _, e in ipairs(self.entries) do
        if e.data.items then self.hasItemEntries = true end
        if e.enabled then
            local kind = e.kind
            count[kind] = count[kind] + 1
            ConfigureButton(self:GetButton(kind, count[kind]), e)
        end
    end

    -- Position: frei platziert (pro Button gespeichert) oder in der Reihe der Gruppe
    for _, kind in ipairs(KIND_ORDER) do
        local n, size, gap = count[kind], SIZES[kind], SPACING[kind]
        for i = 1, n do
            local b = self.pools[kind][i]
            local p = self.db.btnPos[BS.ButtonPosKey(b.entry)]
            b:ClearAllPoints()
            if p then
                b:SetPoint(p[1], UIParent, p[2], p[3], p[4])
            else
                b:SetPoint("CENTER", self.anchors[kind], "CENTER", (i - (n + 1) / 2) * (size + gap), 0)
            end
        end
    end

    if self.UpdateRaster then self:UpdateRaster(true) end
    if self.LayoutDispel then self:LayoutDispel() end
    self:Refresh()
end

-- Beim Kampfbeginn (kurz vor der Sperre): alle Buttons der Zone sichtbar machen, inaktive durchsichtig
function BS:Arm()
    if InCombatLockdown() or not self.ready then return end
    if self.isRetail then return end   -- Retail: im Kampf keine Anzeige (geheime Werte)
    local ctxOK = self:GetContext()
    for _, kind in ipairs(KIND_ORDER) do
        for _, b in ipairs(self.pools[kind]) do
            if b.entry and ctxOK then
                if not b:IsShown() then b:SetAlpha(0) end
                b:Show()
            end
        end
    end
    if self.ArmDispel then self:ArmDispel(ctxOK) end
end

------------------------------------------------------------------------
-- Testmodus
------------------------------------------------------------------------
-- Klassen, die es in der laufenden WoW-Version gibt (ab Erweiterung)
local TEST_CLASSES = {
    { "WARRIOR", 1, "Krieger" }, { "PALADIN", 1, "Paladin" }, { "HUNTER", 1, "Jäger" }, { "ROGUE", 1, "Schurke" },
    { "PRIEST", 1, "Priester" }, { "SHAMAN", 1, "Schamane" }, { "MAGE", 1, "Magier" }, { "WARLOCK", 1, "Hexenmeister" },
    { "DRUID", 1, "Druide" }, { "DEATHKNIGHT", 3, "Todesritter" }, { "MONK", 5, "Mönch" },
    { "DEMONHUNTER", 12, "Dämonenjäger" }, { "EVOKER", 12, "Rufer" },
}

-- Classic Era / SoD / Hardcore: Paladin nur Allianz, Schamane nur Horde.
-- Ab TBC und in WoW Forever gibt es beide Klassen für beide Fraktionen.
local function FactionAllows(cls)
    if BS.expansion ~= 1 or BS.isForever then return true end
    local faction = UnitFactionGroup and UnitFactionGroup("player")
    if cls == "PALADIN" and faction == "Horde" then return false end
    if cls == "SHAMAN" and faction == "Alliance" then return false end
    return true
end

local function AvailableClasses()
    local t = {}
    for _, c in ipairs(TEST_CLASSES) do
        if BS.expansion >= c[2] and BS.ClassData[c[1]] and FactionAllows(c[1]) then t[#t + 1] = c end
    end
    return t
end

local function ClassLabel(cls)
    if LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[cls] then return LOCALIZED_CLASS_NAMES_MALE[cls] end
    for _, c in ipairs(TEST_CLASSES) do if c[1] == cls then return c[3] end end
    return cls
end

local function SpecCount(cls)
    local data = BS.ClassData[cls]
    local names = data and ((BS.family == "modern" and data.specNamesModern) or data.specNames)
    return names and #names or 3
end

local function CreateTestBar()
    local f = CreateFrame("Frame", "BuffSentinelTestBar", UIParent)
    f:SetSize(560, 112)
    f:SetPoint("TOP", UIParent, "TOP", 0, -90)
    f:SetFrameStrata("DIALOG")
    f:SetMovable(true)
    f:EnableMouse(true)
    f:SetClampedToScreen(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)

    local bg = f:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.07, 0.08, 0.10, 0.94)
    local line = f:CreateTexture(nil, "BORDER")
    line:SetPoint("TOPLEFT"); line:SetPoint("TOPRIGHT"); line:SetHeight(2)
    line:SetColorTexture(1, 0.65, 0.2, 1)

    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 12, -10)
    title:SetText("BuffSentinel – Testmodus")
    local hint = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    hint:SetPoint("TOPLEFT", 12, -32)
    hint:SetWidth(540)
    hint:SetJustifyH("LEFT")
    hint:SetText("Button ziehen = einzeln verschieben  ·  Shift + ziehen = ganze Gruppe  ·  " ..
        "Rechtsklick = Button zurücksetzen  ·  Klicks wirken im Testmodus nichts")
    hint:SetTextColor(0.75, 0.75, 0.8)

    local function Btn(label, w, x, y, fn)
        local b = CreateFrame("Button", nil, f)
        b:SetSize(w, 22)
        b:SetPoint("BOTTOMLEFT", x, y)
        local t = b:CreateTexture(nil, "BACKGROUND"); t:SetAllPoints(); t:SetColorTexture(0.18, 0.19, 0.24, 1)
        local h = b:CreateTexture(nil, "HIGHLIGHT"); h:SetAllPoints(); h:SetColorTexture(1, 0.65, 0.2, 0.2)
        b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        b.text:SetPoint("CENTER")
        b.text:SetText(label)
        b:SetScript("OnClick", fn)
        return b
    end

    -- Zeile 1: Klasse und Skillung durchschalten
    local cl = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    cl:SetPoint("BOTTOMLEFT", 12, 44)
    cl:SetText("Klasse:")
    Btn("<", 24, 70, 40, function() BS:CycleTestClass(-1) end)
    f.classText = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    f.classText:SetPoint("BOTTOMLEFT", 100, 44)
    f.classText:SetWidth(120)
    Btn(">", 24, 222, 40, function() BS:CycleTestClass(1) end)

    local sl = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    sl:SetPoint("BOTTOMLEFT", 262, 44)
    sl:SetText("Skillung:")
    Btn("<", 24, 326, 40, function() BS:CycleTestSpec(-1) end)
    f.specText = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    f.specText:SetPoint("BOTTOMLEFT", 356, 44)
    f.specText:SetWidth(110)
    Btn(">", 24, 468, 40, function() BS:CycleTestSpec(1) end)
    Btn("Eigene", 52, 498, 40, function() BS:SetTestClass(nil) end)

    -- Zeile 2: Aktionen
    Btn("Sounds testen", 130, 12, 10, function() BS:TestSounds() end)
    f.soundText = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    f.soundText:SetPoint("TOPRIGHT", -12, -12)
    f.soundText:SetTextColor(0.4, 0.9, 0.5)
    Btn("Alle Positionen zurücksetzen", 210, 150, 10, function() BS:ResetPositions() end)
    Btn("Einstellungen", 100, 368, 10, function() BS:ToggleOptions() end)
    Btn("Beenden", 70, 476, 10, function() BS:StopTestMode() end)
    f:Hide()
    return f
end

function BS:UpdateTestBar()
    local f = self.testBar
    if not f then return end
    local cls = self.testClass or self.class
    f.classText:SetText(ClassLabel(cls) .. (self.testClass and "" or " (du)"))
    f.specText:SetText(self:SpecName(self.mainSpec) or "–")
end

-- Fremde Klasse/Skillung anzeigen (nil = zurück zur eigenen)
function BS:SetTestClass(cls, spec)
    if InCombatLockdown() or not self.testMode then return end
    if cls == self.realClass then cls = nil end
    if cls then
        self.testClass = cls
        self.class = cls
        self.mainSpec = spec or 1
        self.testStore = {}
    else
        self.testClass = nil
        self.class = self.realClass
        self.mainSpec = self.realSpec or 0
    end
    self:Layout()
    self:UpdateTestBar()
    if self.optionsFrame and self.optionsFrame:IsShown() then self:RefreshOptions() end
end

function BS:CycleTestClass(dir)
    local list = AvailableClasses()
    local cur = self.testClass or self.class
    local idx = 1
    for i, c in ipairs(list) do if c[1] == cur then idx = i end end
    idx = (idx - 1 + dir) % #list + 1
    self:SetTestClass(list[idx][1], 1)
end

function BS:CycleTestSpec(dir)
    if not self.testMode then return end
    local cls = self.testClass or self.class
    local n = SpecCount(cls)
    local spec = self.mainSpec or 0
    if spec < 1 then spec = 1 else spec = (spec - 1 + dir) % n + 1 end
    -- auch bei der eigenen Klasse: als Testklasse behandeln, damit deine Einstellungen unberührt bleiben
    if not self.testClass then
        self.testClass = cls
        self.testStore = {}
    end
    self.mainSpec = spec
    self:Layout()
    self:UpdateTestBar()
    if self.optionsFrame and self.optionsFrame:IsShown() then self:RefreshOptions() end
end

-- Positionen einzelner Buttons gelten pro Klasse
local function PosKey(e)
    return (BS.class or "?") .. ":" .. e.key
end
BS.ButtonPosKey = PosKey

-- Alle Warntöne nacheinander, mit genug Abstand und Anzeige, welcher gerade läuft
local TEST_SOUNDS = {
    { "proc",       "Proc" },
    { "buff",       "Buff fehlt" },
    { "dispel",     "Debuff zum Reinigen" },
    { "dispel_imp", "Wichtiger Raid-Debuff" },
    { "cooldown",   "Cooldown bereit" },
}
local SOUND_STEP = 3

function BS:TestSounds()
    if self.soundTestRunning then return end
    self.soundTestRunning = true
    local bar = self.testBar
    for i, s in ipairs(TEST_SOUNDS) do
        local delay = (i - 1) * SOUND_STEP
        local function play()
            if not BS.testMode then BS.soundTestRunning = false return end
            PlayAlert(s[1], true)
            if bar and bar.soundText then bar.soundText:SetText(string.format("Ton %d/%d: %s", i, #TEST_SOUNDS, s[2])) end
        end
        if delay == 0 or not (C_Timer and C_Timer.After) then play() else C_Timer.After(delay, play) end
    end
    local function done()
        BS.soundTestRunning = false
        if bar and bar.soundText then bar.soundText:SetText("") end
    end
    if C_Timer and C_Timer.After then C_Timer.After(#TEST_SOUNDS * SOUND_STEP, done) else done() end
end

function BS:StartTestMode()
    if InCombatLockdown() then BS.Print("Der Testmodus geht nur ausserhalb des Kampfes.") return end
    self.testMode = true
    self.testStart = GetTime()
    self.realClass, self.realSpec = self.class, self.mainSpec
    if not self.testBar then self.testBar = CreateTestBar() end
    self.testBar:Show()
    self:Layout()          -- Buttons ohne Zauberwirkung neu aufbauen
    self:ApplyLock()
    self:UpdateTestBar()
    BS.Print("Testmodus an – Buttons frei verschieben, Klassen und Skillungen durchschalten. Klicks wirken nichts.")
    if self.optionsFrame and self.optionsFrame:IsShown() then self:RefreshOptions() end
end

function BS:StopTestMode()
    if not self.testMode then return end
    self.testMode = false
    -- eigene Klasse und Skillung wiederherstellen
    local hadTestClass = self.testClass ~= nil
    self.testClass, self.testStore = nil, nil
    if self.realClass then self.class = self.realClass end
    if self.realSpec then self.mainSpec = self.realSpec end
    if self.testBar then self.testBar:Hide() end
    for _, kind in ipairs(KIND_ORDER) do
        for _, b in ipairs(self.pools[kind]) do b.placed:Hide() end
    end
    if InCombatLockdown() then
        self.pendingScan = true
    else
        if hadTestClass then self:FullScan() else self:Layout() end   -- Zauber wieder hinterlegen
        self:ApplyLock()
    end
    BS.Print("Testmodus aus – Positionen gespeichert.")
    if self.optionsFrame and self.optionsFrame:IsShown() then self:RefreshOptions() end
end

function BS:ToggleTestMode()
    if self.testMode then self:StopTestMode() else self:StartTestMode() end
end

-- Beispielanzeige je Button
local DEMO_NAMES = { "Thrall", "Jaina", "Zuljin", "Grommash", "Sylvanas" }
local function Demo(b, kind, i, now)
    local e = b.entry
    b.icon:SetVertexColor(1, 1, 1)
    if BS.db.btnPos[BS.ButtonPosKey(e)] then b.placed:Show() else b.placed:Hide() end
    if kind == "proc" then
        b.icon:SetDesaturated(false)
        b.timer:SetText(tostring(5 - math.floor((now - (BS.testStart or now)) % 5)))
        b.count:SetText(e.data.minStacks and tostring(e.data.minStacks) or "")
        b.target:SetText(e.data.enemyDispel and "→ Feuerschild" or "")
        ShowGlow(b, true)
    elseif kind == "buff" then
        b.icon:SetDesaturated(false)
        b.count:SetText(e.data.group and "3" or "")
        b.target:SetText(e.data.group and ("→ " .. DEMO_NAMES[(i - 1) % #DEMO_NAMES + 1]) or "")
        ShowGlow(b, true)
    else
        -- Cooldowns: abwechselnd bereit (leuchtet) und in Abklingzeit
        if i % 2 == 0 then
            b.icon:SetDesaturated(true)
            b.timer:SetText(tostring(12 + i))
            ShowGlow(b, false)
        else
            b.icon:SetDesaturated(false)
            b.timer:SetText("")
            ShowGlow(b, math.floor(now) % 4 < 2)
        end
    end
end

------------------------------------------------------------------------
-- Auren des Spielers
------------------------------------------------------------------------
function BS:ScanPlayerAuras()
    -- Retail: Auren sind im Kampf geheim -> erst nach dem Kampf wieder lesen
    if self.isRetail and self:InCombat() then return end
    wipe(self.playerAuras)
    wipe(self.playerAuraInfo)
    for i = 1, 40 do
        local name, icon, count, expires, spellId
        if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
            local a = C_UnitAuras.GetAuraDataByIndex("player", i, "HELPFUL")
            if not a then break end
            name, icon, count, expires, spellId = a.name, a.icon, a.applications, a.expirationTime, a.spellId
        else
            local n, ic, c, _, _, exp, _, _, _, sid = UnitBuff("player", i)
            if not n then break end
            name, icon, count, expires, spellId = n, ic, c, exp, sid
        end
        if name and not BS.IsSecret(name) then
            self.playerAuras[name] = spellId or true
            self.playerAuraInfo[name] = { id = spellId, icon = icon, count = count, expires = expires }
            if self.LearnAura then self:LearnAura(name, spellId) end
        end
    end
    if self.RecordAuras then self:RecordAuras() end
end

function BS:UNIT_AURA(unit)
    if unit == "player" then self:ScanPlayerAuras() end
end

------------------------------------------------------------------------
-- Kampflog: Auslöser für reaktive Fähigkeiten
------------------------------------------------------------------------
local function HandleMiss(self, src, dst, missType, now)
    local me = self.playerGUID
    if src == me and missType == "DODGE" then
        self.triggers.dodge = now                          -- Ziel ist ausgewichen -> Überwältigen
    end
    if dst == me then
        if missType == "DODGE" or missType == "PARRY" or missType == "BLOCK" then
            self.triggers.avoid = now                      -- Rache, Mungobiss ...
        end
        if missType == "PARRY" then self.triggers.parry = now end   -- Riposte, Gegenangriff
    end
end

function BS:COMBAT_LOG_EVENT_UNFILTERED()
    if not CombatLogGetCurrentEventInfo then return end
    local _, sub, _, src, _, _, _, dst, _, _, _, p12, _, _, p15, p16 = CombatLogGetCurrentEventInfo()
    local now = GetTime()
    if sub == "SWING_MISSED" then
        HandleMiss(self, src, dst, p12, now)
    elseif sub == "SPELL_MISSED" or sub == "RANGE_MISSED" then
        HandleMiss(self, src, dst, p15, now)
    elseif sub == "SWING_DAMAGE" then
        if dst == self.playerGUID and type(p16) == "number" and p16 > 0 then
            self.triggers.avoid = now                      -- Teilblock zählt auch
        end
    end
end

-- Proc wurde benutzt -> Fenster schliessen
function BS:UNIT_SPELLCAST_SUCCEEDED(unit, _, spellID)
    if unit ~= "player" then return end
    local name = type(spellID) == "number" and BS.SpellInfo(spellID) or nil
    if not name then return end
    local now = GetTime()
    for _, b in ipairs(self.pools.proc) do
        if b.entry and b.entry.spellName == name then b.entry.consumedAt = now end
    end
end

------------------------------------------------------------------------
-- Auswertung pro Typ
------------------------------------------------------------------------
function BS:EvalBuff(b, e, inCombat, mounted, lockdown)
    if mounted and not inCombat then return false end
    if e.mode == "combat" and not inCombat then return false end

    -- Waffenbuff (Gift, Waffenverzauberung des Schamanen u. ä.)
    if e.data.weapon then
        local hasMH, _, _, _, hasOH = GetWeaponEnchantInfo()
        if e.data.weapon == "off" then
            if not BS.HasOffhandWeapon() or hasOH then return false end
        elseif hasMH then
            return false
        end
        b.count:SetText("")
        if e.data.items then
            b.target:SetText(e.itemID and "" or "kein Gift in den Taschen")
            b.icon:SetDesaturated(not e.itemID)
        else
            b.target:SetText("")
            local usable, noMana = BS.IsUsable(e.spellName)
            b.icon:SetDesaturated(not usable and not noMana)
        end
        return true
    end

    if e.data.group then
        local miss = self.groupMissing[e.key]
        if not miss or #miss == 0 then return false end
        if not lockdown then
            -- Ausserhalb des Kampfes: Button zeigt immer auf den nächsten Spieler ohne Buff
            local first = miss[1]
            local spell = e.spellName
            if e.groupSpellKnown and (first.groupCount or 0) >= 3 then spell = e.groupSpellName end
            if b:GetAttribute("unit") ~= first.unit then b:SetAttribute("unit", first.unit) end
            if b:GetAttribute("spell") ~= spell then b:SetAttribute("spell", spell) end
        end
        -- Im Kampf bleibt das Ziel fest (Blizzard-Regel); Anzeige passt sich an
        local unit, current = b:GetAttribute("unit"), nil
        for _, m in ipairs(miss) do
            if m.unit == unit then current = m break end
        end
        if current then
            local spell = b:GetAttribute("spell")
            local prefix = (spell ~= e.spellName) and "Gruppe → " or "→ "
            b.target:SetText(prefix .. (current.name or "?"))
            b.icon:SetDesaturated(not current.inRange)
        else
            b.target:SetText("weitere nach dem Kampf")
            b.icon:SetDesaturated(true)
        end
        b.count:SetText(#miss > 1 and tostring(#miss) or "")
        return true
    end

    if BS.HasAny(self.playerAuras, e.auraNames) then return false end
    b.target:SetText("")
    b.count:SetText("")
    local usable, noMana = BS.IsUsable(e.spellName)
    b.icon:SetDesaturated(not usable and not noMana)
    return true
end

function BS:EvalProc(b, e, now, inCombat)
    if not inCombat then return false end
    local d = e.data
    local active, remain, stacks = false, nil, nil

    if e.procAuraNames then
        for n in pairs(e.procAuraNames) do
            local a = self.playerAuraInfo[n]
            if a then
                active = true
                stacks = a.count
                if a.expires and a.expires > 0 then remain = a.expires - now end
            end
        end
    end

    if d.trigger then
        local t, w = self.triggers[d.trigger], d.window or 5
        if t and t > (e.consumedAt or 0) and now - t <= w then
            active = true
            remain = w - (now - t)
        end
    end

    if d.reactive and e.spellName then
        local usable, noMana = BS.IsUsable(e.spellName)
        if usable or noMana then active = true end
    end

    -- Gegner entzaubern: Ziel hat einen entfernbaren Buff
    local dispelHit
    if d.enemyDispel then
        local name, n = self:FindEnemyDispel(d.enemyDispel)
        if name then
            active = true
            dispelHit = name
            if n and n > 1 then stacks = n end
        end
    end

    if d.targetBelow then
        if UnitExists("target") and UnitCanAttack("player", "target") and not UnitIsDead("target") then
            local hp, max = UnitHealth("target"), UnitHealthMax("target")
            if max and max > 0 and (hp / max * 100) <= d.targetBelow then active = true end
        end
    end

    if active and d.minStacks and (stacks or 0) < d.minStacks then active = false end
    if active and e.spellName and not d.alertOnly and not BS.IsReady(e.spellName) then active = false end
    if not active then return false end

    b.timer:SetText((remain and remain > 0) and BS.FormatTime(remain) or "")
    b.count:SetText((stacks and stacks > 1) and tostring(stacks) or "")
    b.target:SetText(dispelHit and ("→ " .. dispelHit) or "")
    if e.spellName and not d.alertOnly then
        local usable, noMana = BS.IsUsable(e.spellName)
        -- blau getönt = Bedingung erfüllt, aber zu wenig Wut/Mana/Energie
        if noMana then b.icon:SetVertexColor(0.45, 0.45, 1) else b.icon:SetVertexColor(1, 1, 1) end
        b.icon:SetDesaturated(not usable and not noMana)
    end
    return true
end

function BS:EvalCooldown(b, e, now, inCombat, ctx)
    if self.db.cdWorldCombatOnly and ctx == "world" and not inCombat then return false end
    local s, dur = BS.GetCooldown(e.spellName)
    local ready = (not s or s == 0 or dur <= BS.GCD_LIMIT or (s + dur - now) <= 0.05)
    if ready then
        b.icon:SetDesaturated(false)
        b.timer:SetText("")
        if b.cd and b.cdStart then b.cd:SetCooldown(0, 0); b.cdStart = nil end
        if b.readyInit and b.wasReady == false then
            -- gerade bereit geworden -> kurz aufleuchten
            b.flashUntil = now + 2
            PlayAlert("cooldown")
        end
    else
        b.icon:SetDesaturated(true)
        b.timer:SetText(self.db.cdTimer and BS.FormatTime(s + dur - now) or "")
        if b.cd and b.cdStart ~= s then b.cd:SetCooldown(s, dur); b.cdStart = s end
    end
    b.readyInit, b.wasReady = true, ready
    return true
end

------------------------------------------------------------------------
-- Hauptschleife (10x pro Sekunde)
------------------------------------------------------------------------
function BS:Refresh()
    if not self.ready or not self.anchors then return end
    local now      = GetTime()
    local ctxOK, ctx = self:GetContext()
    self.ctx, self.ctxOK = ctx, ctxOK
    local lockdown = InCombatLockdown()
    local inCombat = lockdown or UnitAffectingCombat("player")
    local mounted  = IsMounted and IsMounted()
    local test     = self.testMode and not lockdown
    local preview  = (test or not self.db.locked) and not lockdown
    -- Retail: im Kampf ist nichts auswertbar -> alles ausblenden
    if self.isRetail and inCombat then ctxOK = false end

    for _, kind in ipairs(KIND_ORDER) do
        for i, b in ipairs(self.pools[kind]) do
            local e = b.entry
            if e then
                local show = false
                if preview then
                    show = true
                elseif ctxOK then
                    if kind == "buff" then
                        show = self:EvalBuff(b, e, inCombat, mounted, lockdown)
                    elseif kind == "proc" then
                        show = self:EvalProc(b, e, now, inCombat)
                    else
                        show = self:EvalCooldown(b, e, now, inCombat, ctx)
                    end
                end

                if show and not b.wasShown and not preview and kind ~= "cd" then PlayAlert(kind) end
                b.wasShown = show and not preview

                if lockdown then
                    b:SetAlpha(show and 1 or 0)
                elseif show then
                    b:SetAlpha((preview and not test) and 0.7 or 1)
                    b:Show()
                else
                    b:Hide()
                end

                if test then
                    Demo(b, kind, i, now)
                else
                    b.placed:Hide()
                    if kind == "cd" then
                        ShowGlow(b, show and b.flashUntil ~= nil and now < b.flashUntil)
                    else
                        ShowGlow(b, show and not preview)
                    end
                end
            end
        end
    end

    if self.RefreshDispel then self:RefreshDispel(now, ctxOK, lockdown, preview, test) end
end
