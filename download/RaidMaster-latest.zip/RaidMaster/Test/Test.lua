-- ============================================================================
-- RaidMaster Test – Werkzeug, um RaidMaster im Spiel auszuprobieren (fest in RaidMaster eingebaut)
--
-- Testmodus: alles, was du hier machst, bleibt bei dir:
--   * Raid-, DKP- und Lootdaten werden beim Start gesichert und beim Beenden
--     (oder beim nächsten Einloggen) wiederhergestellt
--   * keine Addon-Nachrichten an Gilde/Raid, Raidchat-Texte erscheinen nur bei dir
--   * ein Testraid mit 40 Spielern (MC-Aufstellung) wird vorgespielt
-- Öffnen: Knopf "Test" oben im RaidMaster-Fenster, /rmtest oder /rm test
-- ============================================================================

local ADDON, NS = ...
local RM = (type(NS) == "table" and NS.UI and NS) or RaidMaster
if not RM or not RM.UI then return end
local UI = RM.UI
local COLORS = UI.COLORS
local T = { active = false, role = "raidlead", log = {}, integrated = true }
RaidMasterTest = T
RM.Test = T

-- Testraid: 39 Testspieler + du = 40, aufgestellt wie für Molten Core üblich:
-- 4 Tanks, 6 Furor-Krieger, 6 Priester (5 Heilig, 1 Schatten), 5 Paladine (Allianz) bzw. Schamanen (Horde),
-- 3 Druiden (2 Wiederherstellung, 1 Wildheit), 4 Schurken, 5 Frostmagier (Entfluchen bei Lucifron, Feuer ist
-- in MC nutzlos), 3 Hexenmeister (Verbannen bei Garr), 3 Jäger (Einlullender Schuss bei Magmadar).
-- Talentpunkte je Baum (Classic-Reihenfolge), damit Einteilung und Skillungen echte Rollen sehen.
local FAKE = {}
-- Ersatzbank: nicht im Raid, bekommen aber (je nach Einstellung) die Raid-DKP mit
local BENCH = {
	{ "Testersatz1", "WARRIOR", { 5, 5, 41 } }, { "Testersatz2", "PRIEST", { 21, 30, 0 } },
	{ "Testersatz3", "MAGE", { 21, 0, 30 } }, { "Testersatz4", "ROGUE", { 19, 32, 0 } },
	{ "Testersatz5", "DRUID", { 11, 0, 40 } },
}
local function BuildFake()
	wipe(FAKE)
	local horde = (UnitFactionGroup and UnitFactionGroup("player")) == "Horde"
	local function add(name, class, points) FAKE[#FAKE + 1] = { name, class, points } end
	for i = 1, 4 do add("Testtank" .. i, "WARRIOR", { 5, 5, 41 }) end
	for i = 1, 6 do add("Testkrieger" .. i, "WARRIOR", { 17, 34, 0 }) end
	for i = 1, 5 do add("Testpriester" .. i, "PRIEST", { 21, 30, 0 }) end
	add("Testschatten", "PRIEST", { 13, 0, 38 })
	if horde then
		for i = 1, 5 do add("Testschamane" .. i, "SHAMAN", { 0, 5, 46 }) end
	else
		for i = 1, 5 do add("Testpaladin" .. i, "PALADIN", { 31, 20, 0 }) end
	end
	add("Testdruide1", "DRUID", { 11, 0, 40 }); add("Testdruide2", "DRUID", { 11, 0, 40 })
	add("Testbaer", "DRUID", { 0, 31, 20 })
	for i = 1, 4 do add("Testschurke" .. i, "ROGUE", { 19, 32, 0 }) end
	for i = 1, 5 do add("Testmagier" .. i, "MAGE", { 21, 0, 30 }) end
	for i = 1, 3 do add("Testhexer" .. i, "WARLOCK", { 17, 0, 34 }) end
	add("Testjaeger", "HUNTER", { 21, 30, 0 }); add("Testjaegerin", "HUNTER", { 21, 30, 0 }); add("Testjaeger2", "HUNTER", { 0, 31, 20 })
end
BuildFake()
-- Im Raid gibt es nur Raidleiter, Assistenten und Raidmitglieder (keine Offiziere)
local ROLE_NAMES = { member = "Raidmitglied", lead = "Assistent", raidlead = "Raidleiter" }

local function Log(msg)
	local line = date("%H:%M:%S") .. "  " .. msg
	table.insert(T.log, 1, line)
	while #T.log > 60 do table.remove(T.log) end
	print("|cffff8c1a[RM-Test]|r " .. msg)
	if T.Refresh then T.Refresh() end
end

local function Copy(v)
	if type(v) ~= "table" then return v end
	local c = {}
	for k, x in pairs(v) do c[k] = Copy(x) end
	return c
end

---------------------------------------------------------------------------
-- Tempo: wie lange eine Test-Versteigerung läuft (gespeichert in RaidMasterTestOptions)
---------------------------------------------------------------------------
T.SPEEDS = { 3, 5, 8, 10, 15, 20, 30 }
function T.AuctionSec()
	local o = RaidMasterTestOptions
	local v = type(o) == "table" and tonumber(o.auctionSec)
	return v or 3
end
-- kurze Pausen zwischen den Schritten passend zum Tempo (schnell = kürzer)
local function Pause(sec)
	return sec * math.min(1, T.AuctionSec() / 20)
end
-- im Testmodus die Versteigerungsdauer von RaidMaster setzen (echte Einstellung kommt beim Beenden zurück)
-- Gebote möglichst vor den letzten 5 Sekunden, damit der Schutz gegen Last-Second-Gebote nicht verlängert
function T.BidWindow()
	local d = T.AuctionSec()
	return math.max(d * 0.5, d - 5.5)
end
function T.ApplySpeed()
	if T.active and RM.db and RM.db.data and RM.db.data.settings then
		RM.db.data.settings.auctionTime = T.AuctionSec()
		-- im Test keine Verlängerung bei späten Geboten (echte Einstellung kommt beim Beenden zurück)
		RM.db.data.settings.antiSnipe = false
	end
end

-- Haben alle Testspieler geboten, läuft die Restzeit nur noch kurz (nur im Testmodus)
T.REST_AFTER_BIDS = 1
function T.ShortenRest(c)
	local A = RM.Auction
	if not T.active or not c or A.current ~= c or c.finished then return end
	local now = GetTime()
	if c.endsAt - now <= T.REST_AFTER_BIDS then return end
	c.endsAt = now + T.REST_AFTER_BIDS
	if A.OnBid and c.aid then
		pcall(A.OnBid, RM.Me(), { a = c.aid, n = c.highName or "", v = c.high or 0, r = T.REST_AFTER_BIDS })
	end
	RM.Fire("AUCTION_CHANGED")
end
-- Ergebnis automatisch an Discord senden (Standard an)
function T.AutoSendOn()
	local o = RaidMasterTestOptions
	return not (type(o) == "table" and o.autoSend == false)
end
function T.SetAutoSend(v)
	if type(RaidMasterTestOptions) ~= "table" then RaidMasterTestOptions = {} end
	RaidMasterTestOptions.autoSend = v and true or false
end

-- "Raid starten" in RaidMaster spielt im Testmodus den ganzen Raid durch (Standard an)
function T.FollowStartOn()
	local o = RaidMasterTestOptions
	return not (type(o) == "table" and o.followStart == false)
end
function T.SetFollowStart(v)
	if type(RaidMasterTestOptions) ~= "table" then RaidMasterTestOptions = {} end
	RaidMasterTestOptions.followStart = v and true or false
end

function T.SetAuctionSec(v)
	if type(RaidMasterTestOptions) ~= "table" then RaidMasterTestOptions = {} end
	RaidMasterTestOptions.auctionSec = tonumber(v) or 8
	T.ApplySpeed()
	Log(string.format("Test-Versteigerungen dauern jetzt %d Sek.", T.AuctionSec()))
end

---------------------------------------------------------------------------
-- Testmodus: Daten sichern, RaidMaster-Funktionen umleiten
---------------------------------------------------------------------------
local saved = {}
-- echte RaidMaster-Funktionen beim Laden merken: "Testmodus beenden" stellt immer genau diese wieder her
-- (auch wenn ein anderes Addon, z. B. das alte RaidMasterTest, sie zwischendurch ersetzt hat)
local REAL = {}
local OVERRIDE = { "InRaid", "RaidMembers", "IsAssist", "IsLeader", "CanEdit", "SendAddonMessage", "RaidChat", "Announce", "Whisper", "IAmMasterLooter", "MasterLooterName" }

local function CaptureReal()
	if REAL.captured then return end
	for _, k in ipairs(OVERRIDE) do REAL[k] = RM[k] end
	REAL.Deliver = RM.Loot and RM.Loot.Deliver
	REAL.Ensure = RM.Loot and RM.Loot.EnsureSettings
	REAL.Warn = RM.Loot and RM.Loot.Warn
	REAL.CheckMainLeader = RM.CheckMainLeader
	REAL.RaidStart, REAL.RaidEnd = RM.Raid.Start, RM.Raid.End
	REAL.captured = true
end
CaptureReal()   -- Test.lua lädt als letzte Datei von RaidMaster, alles ist schon da

local function FakeMembers()
	local list = { { name = RM.Me(), class = select(2, UnitClass("player")), online = true, rank = 2, index = 1, group = 1 } }
	for i, f in ipairs(FAKE) do list[#list + 1] = { name = f[1], class = f[2], online = true, rank = 0, index = i + 1, group = math.floor(i / 5) + 1 } end
	return list
end

function T.Start()
	if T.active then return end
	CaptureReal()
	local db = RM.db
	BuildFake()
	T.pool = T.pool or RM.DKP.ActivePool()
	db.specs = db.specs or {}
	RaidMasterTestDB = { data = Copy(db.data), session = Copy(db.session), trade = Copy(db.trade), config = Copy(db.config), specs = Copy(db.specs) }
	for _, k in ipairs(OVERRIDE) do saved[k] = REAL[k] end
	saved.Deliver = REAL.Deliver
	saved.Ensure = REAL.Ensure
	saved.Warn = REAL.Warn
	saved.CheckMainLeader = REAL.CheckMainLeader
	-- im Testraid nichts an der echten Gruppe ändern (Plündermethode, Raidleiter)
	if RM.Loot and RM.Loot.EnsureSettings then RM.Loot.EnsureSettings = function() end end
	if RM.Loot and RM.Loot.Warn then RM.Loot.Warn = function() end end
	if RM.CheckMainLeader then RM.CheckMainLeader = function() end end
	-- Raid starten/beenden in RaidMaster steuert den Test-Durchlauf
	saved.RaidStart, saved.RaidEnd = REAL.RaidStart, REAL.RaidEnd
	RM.Raid.Start = function(...)
		-- "Raid starten" in RaidMaster hat Vorrang: alles, was das Test-Tool gerade macht, wird abgebrochen
		if T.active and not T.manualStart then T.Override("Raid starten") end
		local was = RM.db.session.active
		local r = saved.RaidStart(...)
		if T.active and not was and RM.db.session.active and not T.manualStart and not T.IsRunning() and T.FollowStartOn() then
			local pool = RM.db.session.pool
			if pool and RM.Data.Pools[pool] and RM.Data.Pools[pool].bosses[1] then T.pool = pool end
			Log("Raid in RaidMaster gestartet – das Test-Tool spielt jetzt " .. RM.DKP.PoolName(T.pool) .. " durch.")
			C_Timer.After(1, function() if T.active and not T.IsRunning() then T.RunRaids(T.runs) end end)
		end
		return r
	end
	RM.Raid.End = function(...)
		-- "Raid beenden" in RaidMaster hat Vorrang: Durchlauf, Versteigerung und Warteschlange des Test-Tools abbrechen
		if T.active and not T.runEnding then T.Override("Raid beenden", true) end
		local was = RM.db.session.active
		local r = saved.RaidEnd(...)
		if T.active and was and not RM.db.session.active and not T.runEnding then
			T.AutoSend("Raid beendet.")
		end
		return r
	end
	RM.InRaid = function() return true end
	RM.RaidMembers = FakeMembers
	-- Rollen: Teilnehmer (nur bieten), Co-Raidleiter (Assistent), Raidleiter (Gruppenleiter mit allen Rechten),
	-- (früher zusätzlich "Offizier" – im Raid gibt es nur Raidleiter, Assistenten und Mitglieder)
	RM.IsAssist = function() return T.role ~= "member" end
	RM.IsLeader = function() return T.role == "raidlead" end
	RM.CanEdit = function() return T.role == "raidlead" end
	-- im Testraid bist du als Raidleiter auch der Plündermeister (startet die Versteigerungen)
	RM.IAmMasterLooter = function() return T.role == "raidlead" end
	RM.MasterLooterName = function() return RM.Me() end
	RM.SendAddonMessage = function() T.blocked = (T.blocked or 0) + 1 end
	RM.RaidChat = function(msg, ch) print("|cffff7f00[Test-" .. (ch or "RAID") .. "]|r " .. msg) end
	RM.Whisper = function(msg, target) print("|cffff80ff[Test-Flüstern an " .. tostring(target) .. "]|r " .. msg) end
	RM.Announce = function(msg, warning) print("|cffff4800[Test-" .. (warning and "Raidwarnung" or "Raid") .. "]|r " .. msg) end
	if RM.Loot then RM.Loot.Deliver = function(link, name) Log("Item würde übergeben: " .. tostring(link) .. " -> " .. tostring(name)) end end
	-- Skillungen der Testspieler (nur im Test, werden beim Beenden zurückgesetzt)
	if RM.Spec and RM.Spec.Store then
		for _, f in ipairs(FAKE) do pcall(RM.Spec.Store, f[1], f[2], f[3], "addon") end
		for _, f in ipairs(BENCH) do pcall(RM.Spec.Store, f[1], f[2], f[3], "addon") end
	end
	-- Ersatzbank mit 5 Testspielern
	RM.db.config.standby = RM.db.config.standby or {}
	for _, f in ipairs(BENCH) do
		local p = RM.DKP.EnsurePlayer(f[1], f[2])
		p.d = p.d or {}
		p.d[RM.DKP.ActivePool()] = 100
		RM.db.config.standby[f[1]] = true
	end
	-- Testspieler mit 100 DKP im aktuellen Topf
	local pool = RM.DKP.ActivePool()
	for _, f in ipairs(FAKE) do
		local p = RM.DKP.EnsurePlayer(f[1], f[2])
		p.d = p.d or {}
		p.d[pool] = 100
	end
	T.active = true
	T.blocked = 0
	-- Markierung für den Discord-Bot: Daten aus dem Testmodus nie als echte DKP übernehmen
	-- post = true: jedes Speichern (/reload, Ausloggen) schickt das Testergebnis an Discord (DKP- und Loot-Kanal)
	RM.db.testMode = { active = true, started = GetServerTime(), pool = T.pool, post = T.AutoSendOn() or nil }
	T.ApplySpeed()
	Log("Testmodus AN – Daten gesichert, keine Nachrichten an Gilde/Raid. Testraid mit " .. #FAKE + 1 .. " Spielern (MC-Aufstellung) und " .. #BENCH .. " auf der Ersatzbank.")
	RM.Fire("SESSION_CHANGED"); RM.Fire("DATA_CHANGED")
end

-- Inhalt einer Tabelle ersetzen, ohne die Tabelle selbst zu tauschen (andere Teile halten Verweise)
local function Replace(target, source)
	if type(target) ~= "table" or type(source) ~= "table" then return end
	for k in pairs(target) do target[k] = nil end
	for k, v in pairs(source) do target[k] = v end
end

local function Restore(silent)
	local b = RaidMasterTestDB
	if b and RM.db then
		local pos = RM.db.config and RM.db.config.positions
		local size = RM.db.config and RM.db.config.mainSize
		Replace(RM.db.data, b.data)
		Replace(RM.db.session, b.session)
		Replace(RM.db.trade, b.trade)
		Replace(RM.db.config, b.config)
		if b.specs and RM.db.specs then Replace(RM.db.specs, b.specs) end
		if pos then RM.db.config.positions = pos end
		RM.db.config.mainSize = size
	end
	if RM.db then RM.db.testMode = nil end
	RaidMasterTestDB = nil
	if not silent then RM.Fire("SESSION_CHANGED"); RM.Fire("DATA_CHANGED"); RM.Fire("CONFIG_CHANGED") end
end

function T.Stop()
	if not T.active then return end
	if RM.Auction and RM.Auction.current then pcall(RM.Auction.Cancel) end
	for _, k in ipairs(OVERRIDE) do RM[k] = saved[k] end
	if RM.Auction and RM.Auction.queue then wipe(RM.Auction.queue) end   -- Test-Items nicht im echten Raid lassen
	if T.StopRun then T.StopRun() end
	if RM.Loot then RM.Loot.isOpen = false; wipe(RM.Loot.items) end
	if RM.Loot and saved.Deliver then RM.Loot.Deliver = saved.Deliver end
	if RM.Loot and saved.Ensure then RM.Loot.EnsureSettings = saved.Ensure end
	if RM.Loot and saved.Warn then RM.Loot.Warn = saved.Warn end
	if saved.CheckMainLeader then RM.CheckMainLeader = saved.CheckMainLeader end
	if saved.RaidStart then RM.Raid.Start, RM.Raid.End = saved.RaidStart, saved.RaidEnd; saved.RaidStart, saved.RaidEnd = nil, nil end
	T.active = false
	T.HideAutoSend()
	Restore()
	Log(string.format("Testmodus AUS – alle Daten wiederhergestellt (%d Addon-Nachrichten wurden zurückgehalten).", T.blocked or 0))
end

-- Testdaten an Discord: WoW speichert beim /reload, der Uploader schickt die Datei, der Bot postet
-- DKP-Stand, Teilnehmer und Loot des Tests (mit TEST markiert) und löscht alles nach 10 Minuten.
-- Nach dem Neuladen ist der Testmodus beendet und deine echten Daten sind wieder da.
function T.SendToDiscord()
	if not T.active then Log("Erst den Testmodus starten und einen Raid simulieren.") return end
	RM.db.testMode = RM.db.testMode or { active = true, started = GetServerTime() }
	RM.db.testMode.post = true
	RM.db.testMode.pool = T.pool
	RM.UI.Confirm("Testdaten an Discord senden?\nDie Oberfläche wird neu geladen. Der Bot postet DKP, Teilnehmer und Loot des Tests "
		.. "(mit TEST markiert) und löscht sie nach 10 Minuten. Danach ist der Testmodus beendet, deine echten Daten sind wieder da.",
		function() ReloadUI() end, function() RM.db.testMode.post = nil end)
end

-- Gibt es im Test schon ein Ergebnis (Raid, Bosse, DKP, Loot)?
function T.HasResults()
	local since = RM.db.testMode and RM.db.testMode.started or 0
	for _, e in ipairs(RM.db.data.log or {}) do
		if type(e) == "table" and not e.u and (e.t or 0) >= since then return true end
	end
	return false
end

-- Nach dem Raid: Ergebnis mit Countdown automatisch senden (lädt die Oberfläche neu)
local sendFrame, sendTicker
local sendState = {}
local SEND_DELAY = 10
function T.HideAutoSend()
	if sendFrame then sendFrame:Hide() end
end
function T.AutoSend(reason)
	if not T.active or not T.AutoSendOn() then return end
	RM.db.testMode = RM.db.testMode or { active = true, started = GetServerTime() }
	RM.db.testMode.post = true
	RM.db.testMode.pool = T.pool
	if not sendFrame then
		local f = UI.Frame(UIParent, 440, 112)
		f:SetFrameStrata("FULLSCREEN_DIALOG")
		f:SetToplevel(true)
		f:SetClampedToScreen(true)
		UI.Skin(f, nil, COLORS.accent)
		UI.MakeMovable(f, "testSend", "TOP", 0, -150)
		f.text = UI.Text(f, "", 13)
		f.text:SetPoint("TOPLEFT", 14, -12)
		f.text:SetWidth(412)
		f.text:SetJustifyH("LEFT")
		local now = UI.Button(f, "Jetzt senden", 130, 28, function() f:Hide(); ReloadUI() end)
		now:SetPoint("BOTTOMLEFT", 14, 12)
		now:SetAccent(true)
		local later = UI.Button(f, "Später", 130, 28, function()
			f:Hide()
			Log("Ergebnis wird beim nächsten /reload oder Ausloggen an Discord gesendet (oder 'Test an Discord senden').")
		end)
		later:SetPoint("LEFT", now, "RIGHT", 8, 0)
		sendFrame = f
		function f.Tick()
			if not f:IsShown() then return end
			local left = sendState.endsAt - GetTime()
			if left <= 0 then
				f:Hide()
				if T.active then ReloadUI() end
				return
			end
			f.text:SetText((sendState.reason or "Test fertig.") .. "\n" .. string.format(
				"Ergebnis (DKP, Teilnehmer, Loot) geht in |cffffd200%d Sek.|r an Discord – die Oberfläche lädt dafür neu.\n"
				.. "Danach ist der Testmodus beendet, deine echten Daten sind wieder da.", math.ceil(left)))
		end
		f:SetScript("OnHide", function() if sendTicker then sendTicker:Cancel(); sendTicker = nil end end)
	end
	sendState.reason = reason
	sendState.endsAt = GetTime() + SEND_DELAY
	sendFrame:Show()
	sendFrame:Raise()
	if sendTicker then sendTicker:Cancel() end
	sendTicker = C_Timer.NewTicker(0.25, sendFrame.Tick)
	sendFrame.Tick()
	Log((reason or "Test fertig.") .. " Ergebnis geht in " .. SEND_DELAY .. " Sek. an Discord.")
end

-- Raid starten/beenden in RaidMaster überschreibt alle laufenden Befehle des Test-Tools:
-- Durchlauf (auch mehrere Raidabende), laufende Versteigerung, Warteschlange, Vergabe-Fenster, Sende-Countdown.
-- Beim Starten wird ein noch offener Test-Raid still geschlossen (ohne Bonus), damit der neue Start gilt.
function T.Override(what, keepSession)
	local A = RM.Auction
	local did = false
	if T.IsRunning() then T.StopRun(); did = true end
	T.series = nil
	if A.current then pcall(A.Cancel); A.current = nil; did = true end
	if #A.queue > 0 then wipe(A.queue); did = true end
	if A.HideAward then A.HideAward() end
	if RM.Loot then RM.Loot.isOpen = false; wipe(RM.Loot.items) end
	if sendFrame and sendFrame:IsShown() then T.HideAutoSend(); did = true end
	if not keepSession and RM.db.session.active then
		RM.db.session.active = false
		RM.db.session.ended = GetServerTime()
		did = true
	end
	RM.Fire("AUCTION_CHANGED"); RM.Fire("SESSION_CHANGED")
	if did then Log("\"" .. what .. "\" in RaidMaster – laufende Befehle des Test-Tools abgebrochen.") end
end

-- "Testmodus beenden": ein vorhandenes Ergebnis vorher an Discord senden?
function T.StopAsk()
	if not T.active then return end
	if T.AutoSendOn() and T.HasResults() then
		RM.UI.Confirm("Das Testergebnis vorher an Discord senden (DKP-, Teilnehmer- und Loot-Kanal)?\n"
			.. "Ja: die Oberfläche lädt neu, danach ist der Testmodus beendet. Nein: alles verwerfen.",
			function() T.HideAutoSend(); RM.db.testMode.post = true; ReloadUI() end,
			function() T.HideAutoSend(); T.Stop() end, "Senden", "Verwerfen")
	else
		T.Stop()
	end
end

-- Abgestürzt/ausgeloggt mitten im Test: beim nächsten Laden zurücksetzen
local loader = CreateFrame("Frame")
loader:RegisterEvent("PLAYER_LOGIN")
loader:SetScript("OnEvent", function()
	if RaidMasterTestDB then
		Restore(true)
		print("|cffff8c1a[RM-Test]|r Testdaten vom letzten Mal entfernt – deine echten Daten sind wiederhergestellt.")
	end
end)

function T.RoleName() return ROLE_NAMES[T.role] or "?" end

function T.SetRole(role)
	if role == "officer" then role = "raidlead" end      -- frühere Ansicht "Offizier" = Raidleiter
	if not ROLE_NAMES[role] then role = "raidlead" end
	T.role = role
	if not T.active then T.Start() end
	Log("Ansicht als " .. ROLE_NAMES[role] .. ".")
	RM.Fire("CONFIG_CHANGED"); RM.Fire("SESSION_CHANGED")
	if RM.Markers and RM.Markers.UpdateBar then RM.Markers.UpdateBar() end
	if RM.UI.RefreshCurrent then RM.UI.RefreshCurrent() end
end

---------------------------------------------------------------------------
-- Simulationen (Testraid: 39 Testspieler + du)
---------------------------------------------------------------------------
local function Need()
	if not T.active then T.Start() end
	if T.role ~= "raidlead" then
		Log("Für Raid, Bosskill und Versteigerung bitte 'Ansicht als: Raidleiter' wählen.")
		return false
	end
	return true
end

-- DKP für dich selbst (beliebige Menge, auch negativ) im gewählten Raid – nur im Testmodus
function T.GiveMeDKP(amount)
	amount = tonumber(amount)
	if not amount or amount == 0 then Log("Bitte eine Zahl eingeben (z. B. 500 oder -50).") return end
	amount = math.floor(amount)
	if not T.active then T.Start() end
	local pool = T.pool or RM.DKP.ActivePool()
	RM.DKP.EnsurePlayer(RM.Me(), select(2, UnitClass("player")))
	-- im Test immer erlaubt, unabhängig von der gewählten Ansicht
	local canEdit = RM.CanEdit
	RM.CanEdit = function() return true end
	local ok = pcall(RM.DKP.Adjust, RM.Me(), amount, "Test: DKP selbst vergeben", pool)
	RM.CanEdit = canEdit
	Log(string.format("%s%d DKP für dich (%s) – jetzt %d.", amount > 0 and "+" or "", amount, RM.DKP.PoolName(pool), RM.DKP.Get(RM.Me(), pool)))
	if not ok then Log("DKP konnten nicht gebucht werden.") end
	RM.Fire("DATA_CHANGED")
	if RM.UI.RefreshCurrent then RM.UI.RefreshCurrent() end
end

function T.StartRaid()
	if not Need() then return end
	RM.db.config.activePool = T.pool
	T.manualStart = true
	local ok, err = pcall(RM.Raid.Start)
	T.manualStart = nil
	if not ok then error(err) end
	Log("Raid gestartet (" .. RM.DKP.PoolName(T.pool) .. ").")
end

function T.EndRaid()
	if not Need() then return end
	RM.Raid.End()      -- sendet das Ergebnis (siehe Raid.End im Testmodus)
	Log("Raid beendet.")
end

function T.BossKill()
	if not Need() then return end
	local b = T.boss and RM.Data.Bosses[T.boss]
	if not b then Log("Bitte zuerst einen Boss wählen.") return end
	if not RM.db.session.active then RM.db.config.activePool = b.pool; RM.Raid.Start() end
	local id = b.e[#b.e]
	RM.SimulateEvent("ENCOUNTER_START", id, b.name, 14, 10)
	C_Timer.After(1, function()
		RM.SimulateEvent("ENCOUNTER_END", id, b.name, 14, 10, 1)
		Log("Bosskill simuliert: " .. b.name .. " (Vorlage: " .. RM.Data.GetTemplate(RM.db.config.markerTemplate).name .. ").")
	end)
end

function T.Auction(link)
	if not Need() then return end
	if not link or not link:find("item:") then
		link = select(2, (RM.GetItemInfo or GetItemInfo)(6948)) or "|cffffffff|Hitem:6948::::::::60:::::|h[Ruhestein]|h|r"
	end
	T.ApplySpeed()
	RM.Auction.Start(link)
	if not RM.Auction.current then Log("Versteigerung konnte nicht starten.") return end
	Log("Versteigerung gestartet: " .. link .. " – Testspieler bieten gleich.")
	local amounts = { 10, 15, 25, 30 }
	local step = math.min(2, math.max(0.4, (T.BidWindow() - 0.5) / #amounts))
	for i, amount in ipairs(amounts) do
		local who = FAKE[(i % #FAKE) + 1][1]
		C_Timer.After(0.5 + i * step, function()
			local ok, err = RM.Auction.ReceiveBid(who, amount, "")
			Log(who .. " bietet " .. amount .. " DKP" .. (ok and "" or (" – abgelehnt: " .. tostring(err))))
			if i == #amounts then T.ShortenRest(RM.Auction.current) end
		end)
	end
end

-- Magmadar: Jäger nach Einlullender Schuss fragen; die Testjäger antworten per Flüstern
function T.TranqTest()
	if not T.active then T.Start() end
	if T.role == "member" then Log("Die Jäger-Abfrage gibt es nur für Raidleiter und Assistenten.") return end
	RM.Tranq.Ask()
	Log("Jäger-Abfrage gestartet – Testjaeger und Testjaeger2 antworten 'ja', Testjaegerin 'nein'.")
	C_Timer.After(5, function()
		RM.SimulateEvent("CHAT_MSG_WHISPER", "ja", "Testjaeger")
		RM.SimulateEvent("CHAT_MSG_WHISPER", "nein", "Testjaegerin")
		RM.SimulateEvent("CHAT_MSG_WHISPER", "ja", "Testjaeger2")
		Log("Antworten: " .. RM.Tranq.StatusText():gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
		RM.Tranq.Post()
		Log("Einlull-Rotation als Schlachtzugwarnung gepostet (im Test nur bei dir).")
	end)
end

---------------------------------------------------------------------------
-- Ganzen Raid durchspielen: alle Bosse nacheinander, Beute aus der echten Beutetabelle
-- (Classic, TBC, Wrath), Versteigerungen mit Testgeboten, Trash-Beute zwischendurch
---------------------------------------------------------------------------
local run
function T.IsRunning() return run ~= nil or T.series ~= nil end

local function LootTable(def)
	if not (def and RaidMasterTestLoot) then return nil end
	for id in pairs(def.ids or {}) do
		local t = RaidMasterTestLoot[id .. ":" .. tostring(def.exp)]
		if t then return t end
		for key, v in pairs(RaidMasterTestLoot) do
			if key:match("^" .. id .. ":") then return v end
		end
	end
end

local function BossLoot(lt, boss, index)
	local en = (boss.en or ""):lower()
	for _, b in ipairs(lt) do if b.n:lower() == en then return b.i end end
	if en ~= "" then
		for _, b in ipairs(lt) do
			local n = b.n:lower()
			if n:find(en, 1, true) or en:find(n, 1, true) then return b.i end
		end
	end
	return lt[index] and lt[index].i
end

local function ItemInfo(id)
	local name, link, quality = (RM.GetItemInfo or GetItemInfo)(id)
	return link, quality
end

-- n zufällige Items, die das Spiel schon kennt (sonst beim nächsten Mal)
local function Pick(ids, n)
	local pool, out = {}, {}
	for _, id in ipairs(ids or {}) do if ItemInfo(id) then pool[#pool + 1] = id end end
	for _ = 1, n do
		if #pool == 0 then break end
		out[#out + 1] = table.remove(pool, math.random(#pool))
	end
	return out
end

local RULE_NAMES = { auction = "Versteigerung", bank = "Gildenbank", de = "Entzauberer", crafter = "Handwerker",
	manual = "von Hand verteilen", notify = "Hinweis (legendär) – nie automatisch", roll = "Würfeln" }

-- ein Item wie im echten Raid behandeln: Regel prüfen, versteigern oder zuteilen
local function HandleItem(id, source)
	local link, quality = ItemInfo(id)
	if not link then return end
	local action = RM.Loot.Classify(link, quality)
	-- wie ein offenes Lootfenster beim Plündermeister (Seite Loot: "Aktuelles Lootfenster")
	RM.Loot.isOpen = true
	RM.Loot.items[#RM.Loot.items + 1] = { link = link, quality = quality, action = action, done = action ~= "auction" and action ~= "manual" and action ~= "notify" }
	RM.Fire("LOOT_CHANGED")
	if action == "auction" then
		-- wie im echten Raid in die Warteschlange von RaidMaster (Seite Versteigerung)
		RM.Auction.Enqueue(link)
		Log(source .. ": " .. link .. " -> Warteschlange (Versteigerung)")
	else
		local who = RM.Loot.RecipientFor and RM.Loot.RecipientFor(action)
		Log(source .. ": " .. link .. " -> " .. (RULE_NAMES[action] or tostring(action)) .. (who and who ~= "" and (" (" .. who .. ")") or ""))
		run.other = run.other + 1
	end
end

-- Testspieler bieten auf die laufende Versteigerung (2–4 Gebote, jeder höchstens seine DKP)
local function AddFakeBids(c)
	if not c or c.testBids then return end
	c.testBids = true
	local bidders = {}
	for _, f in ipairs(FAKE) do bidders[#bidders + 1] = f[1] end
	local count = math.random(2, 4)
	local amount = c.min
	-- Gebote gleichmäßig auf den Anfang der Versteigerung verteilen
	local step = math.min(1.5, math.max(0.4, (T.BidWindow() - 0.5) / count))
	for i = 1, count do
		local who = table.remove(bidders, math.random(#bidders))
		amount = amount + math.random(0, 3) * (c.inc or 5)
		local a = amount
		local last = (i == count)
		C_Timer.After(0.5 + i * step, function()
			if RM.Auction.current == c and not c.finished then
				local have = RM.DKP.Get(who, c.pool)
				local bid = math.min(a, have)
				if bid >= ((c.highName and (c.high + c.inc)) or c.min) then RM.Auction.ReceiveBid(who, bid, "") end
				if last then T.ShortenRest(c) end
			end
		end)
		amount = amount + (c.inc or 5)
	end
end

-- nächstes Item aus der Warteschlange von RaidMaster versteigern
local function StartFromQueue()
	if RM.Auction.current or #RM.Auction.queue == 0 then return false end
	RM.Auction.Start(1)
	AddFakeBids(RM.Auction.current)
	return RM.Auction.current ~= nil
end

local function RunStep()
	if not run or not T.active then return end
	local now = GetTime()
	if now < run.waitUntil then return end
	local c = RM.Auction.current
	-- Versteigerung fertig: wie die Raidleitung "Vergeben" klicken
	if c and c.finished then
		-- selbst versteigern: du klickst "Vergeben" / "Nicht vergeben" wie im echten Raid
		if not T.autoAuction then return end
		if c.highName then
			if RM.Auction.HideAward then RM.Auction.HideAward() end
			RM.Auction.Award()
		else
			RM.Auction.current = nil
		end
		run.waitUntil = now + Pause(1.5)
		return
	end
	-- läuft eine Versteigerung (von dir gestartet), bieten die Testspieler mit
	if c then AddFakeBids(c) return end
	if #RM.Auction.queue > 0 then
		if T.autoAuction then
			if not StartFromQueue() then Log("Versteigerung aus der Warteschlange nicht möglich."); wipe(RM.Auction.queue) end
			run.waitUntil = now + 1
		elseif not run.told then
			run.told = true
			Log(string.format("%d Item(s) in der Warteschlange – starte jede Versteigerung selbst auf der Seite Versteigerung "
				.. "(Item wählen, \"Gewähltes starten\"). Testspieler bieten mit, \"Vergeben\" klickst du. Danach geht es zum nächsten Boss.", #RM.Auction.queue))
			RM.UI.Open("auction")
		end
		return
	end
	run.told = false
	-- nächster Boss
	run.index = run.index + 1
	local boss = run.def.bosses[run.index]
	if not boss then
		RM.Auction.Award = run.origAward
		RM.Loot.isOpen = false; wipe(RM.Loot.items)
		T.runEnding = true
		local ok, err = pcall(RM.Raid.End)
		T.runEnding = nil
		if not ok then Log("Fehler beim Raidende: " .. tostring(err)) end
		Log(string.format("Raid-Durchlauf fertig: %d Bosse, %d Items versteigert, %d nach Regel verteilt.", #run.def.bosses, #run.awarded, run.other))
		for _, a in ipairs(run.awarded) do Log("  " .. a) end
		Log("Alles im Testmodus – 'Testmodus beenden' setzt deine echten Daten zurück.")
		run.ticker:Cancel()
		run = nil
		if T.series and T.series.left > 0 then
			C_Timer.After(3, function() if T.active and T.series then T.NextSeriesRun() end end)
		else
			if T.series and T.series.total > 1 then
				Log(string.format("Alle %d Raidabende fertig – 'Test an Discord senden' zeigt die Raid-Abrechnungen im Discord.", T.series.total))
			end
			local total = T.series and T.series.total or 1
			T.series = nil
			T.SetTimeOffset(0)
			T.AutoSend(total > 1 and string.format("Alle %d Raidabende fertig.", total) or "Raid-Durchlauf fertig.")
		end
		if T.Refresh then T.Refresh() end
		return
	end
	-- Trash vor jedem zweiten Boss
	if run.loot and run.index > 1 and run.index % 2 == 0 and run.loot.trash then
		for _, id in ipairs(Pick(run.loot.trash, 1)) do HandleItem(id, "Trash") end
	end
	local ids = boss.e
	wipe(RM.Loot.items)
	RM.SimulateEvent("ENCOUNTER_START", ids[#ids], boss.name, 9, 40)
	RM.SimulateEvent("ENCOUNTER_END", ids[#ids], boss.name, 9, 40, 1)
	Log(string.format("Boss %d/%d besiegt: %s", run.index, #run.def.bosses, boss.name))
	if run.loot then
		local drops = BossLoot(run.loot, boss, run.index)
		local n = (#run.def.bosses == 1 or run.index == #run.def.bosses) and 3 or 2
		local picked = Pick(drops, n)
		if #picked == 0 then Log("  (keine Beute bekannt oder noch nicht vom Server geladen)") end
		for _, id in ipairs(picked) do HandleItem(id, boss.name) end
	end
	run.waitUntil = now + Pause(2)
end

-- Mehrere Raidabende hintereinander: auf Wunsch je eine Woche auseinander datiert
-- (GetServerTime wird nur im Testmodus verschoben und danach zurückgesetzt)
T.runs, T.weekly = 1, true
local realServerTime
local function SetTimeOffset(sec)
	if not realServerTime then realServerTime = GetServerTime end
	if sec == 0 then
		GetServerTime = realServerTime
	else
		GetServerTime = function() return realServerTime() + sec end
	end
end
T.SetTimeOffset = SetTimeOffset

function T.RunRaids(n)
	n = math.max(1, math.min(10, math.floor(tonumber(n) or 1)))
	if run then Log("Es läuft schon ein Durchlauf.") return end
	T.series = { total = n, left = n }
	T.NextSeriesRun()
end

function T.NextSeriesRun()
	local sr = T.series
	if not sr or sr.left <= 0 then return end
	local idx = sr.total - sr.left + 1
	T.SetTimeOffset(T.weekly and -(sr.left - 1) * 7 * 86400 or 0)
	Log(string.format("Raidabend %d von %d%s", idx, sr.total,
		(T.weekly and sr.total > 1) and (" – datiert auf " .. date("%d.%m.%Y", GetServerTime())) or ""))
	sr.left = sr.left - 1
	-- zurückdatierte Abende gehören auch zu den Testdaten für Discord
	if RM.db.testMode then RM.db.testMode.started = math.min(RM.db.testMode.started or GetServerTime(), GetServerTime() - 60) end
	T.RunRaid()
end

function T.RunRaid()
	if run then Log("Es läuft schon ein Durchlauf.") return end
	if not T.active then T.Start() end
	if T.role ~= "raidlead" then T.SetRole("raidlead") end
	local def = RM.Data.Pools[T.pool]
	if not def or not def.bosses[1] then Log("Für diesen Raid sind keine Bosse hinterlegt.") return end
	local loot = LootTable(def)
	-- Items beim Server anfragen, damit Namen/Qualität bereitstehen
	if loot then
		for _, b in ipairs(loot) do for _, id in ipairs(b.i) do ItemInfo(id) end end
		for _, id in ipairs(loot.trash or {}) do ItemInfo(id) end
	end
	run = { def = def, loot = loot, index = 0, queue = {}, awarded = {}, other = 0, waitUntil = GetTime() + 2 }
	T.ApplySpeed()      -- Tempo aus dem Test-Fenster (Dauer der Versteigerungen)
	-- Vergaben mitschreiben (egal ob du oder der automatische Durchlauf "Vergeben" klickt)
	local origAward = RM.Auction.Award
	run.origAward = origAward
	RM.Auction.Award = function(...)
		local c = RM.Auction.current
		if run and c and c.highName then
			run.awarded[#run.awarded + 1] = c.highName .. " " .. c.link .. " (" .. c.high .. " DKP)"
			Log("Vergeben: " .. c.link .. " an " .. c.highName .. " für " .. c.high .. " DKP")
		end
		return origAward(...)
	end
	RM.db.config.activePool = def.key
	if not RM.db.session.active then
		T.manualStart = true
		local ok, err = pcall(RM.Raid.Start)
		T.manualStart = nil
		if not ok then Log("Fehler beim Raidstart: " .. tostring(err)) end
	end
	Log("Raid-Durchlauf gestartet: " .. def.name .. " (" .. #def.bosses .. " Bosse)" ..
		(loot and ", Beute aus der Beutetabelle" or ", keine Beutetabelle für diesen Raid (nur Classic/TBC/Wrath)") ..
		". Versteigerungen laufen je " .. T.AuctionSec() .. " Sek.")
	run.ticker = C_Timer.NewTicker(0.5, RunStep)
	if T.Refresh then T.Refresh() end
end

function T.StopRun()
	T.series = nil
	T.SetTimeOffset(0)
	if not run then return end
	run.ticker:Cancel()
	if run.origAward then RM.Auction.Award = run.origAward end
	RM.Loot.isOpen = false; wipe(RM.Loot.items)
	if RM.Auction.current then pcall(RM.Auction.Cancel) end
	wipe(RM.Auction.queue)
	RM.Fire("AUCTION_CHANGED")
	if RM.Auction.HideAward then RM.Auction.HideAward() end
	run = nil
	Log("Raid-Durchlauf abgebrochen.")
end

function T.TrashLoot()
	if not T.active then T.Start() end
	local loot = LootTable(RM.Data.Pools[T.pool])
	if not (loot and loot.trash and loot.trash[1]) then Log("Keine Trash-Beute für diesen Raid bekannt (nur Classic/TBC/Wrath).") return end
	for _, id in ipairs(loot.trash) do ItemInfo(id) end
	local picked = Pick(loot.trash, 1)
	if not picked[1] then Log("Items werden noch vom Server geladen – gleich nochmal klicken.") return end
	local own = not run
	if own then run = { queue = {}, awarded = {}, other = 0 } end
	HandleItem(picked[1], "Trash")
	if own then
		run = nil
		-- ohne Raid-Durchlauf: Item steht in der Warteschlange; gleich versteigern, falls nichts läuft
		if StartFromQueue() then Log("Versteigerung gestartet – Testspieler bieten gleich.") end
	end
end

---------------------------------------------------------------------------
-- Selbsttest: was kann dieser Client, ist RaidMaster richtig eingestellt?
---------------------------------------------------------------------------
function T.SelfTest()
	local out = {}
	local function line(ok, text) out[#out + 1] = (ok == nil and "|cffbbbbbb•|r " or ok and "|cff40ff40OK|r  " or "|cffff5544!!|r  ") .. text end
	line(true, "RaidMaster " .. RM.VERSION .. " – " .. RM.GameInfoText())
	line(true, "Sprache: " .. (RM.LANGUAGES[RM.LOCALE] or RM.LOCALE) .. " (Client " .. tostring(RM.GAME_LOCALE) .. ")")
	line(#RM.Data.RaidList > 0, string.format("Raids dieser Version: %d mit %d Bossen, %d Markierungsvorlagen", #RM.Data.RaidList, #RM.Data.BossOrder, #RM.Data.MarkerTemplates))
	local noInfo = 0
	for _, id in ipairs(RM.Data.BossOrder) do if not RM.Data.BossInfo[id] then noInfo = noInfo + 1 end end
	line(noInfo == 0, "Boss-Taktiken: " .. (noInfo == 0 and "alle vorhanden" or (noInfo .. " fehlen")))
	line(RM.Caps.masterLoot, "Plündermeister: " .. (RM.Caps.masterLoot and "verfügbar" or "nicht verfügbar (Retail: Handel statt Verteilen)"))
	line(RM.Caps.specs or RM.Caps.talentTrees, "Skillungen: " .. (RM.Caps.specs and "Spezialisierungen" or RM.Caps.talentTrees and "Talentbäume" or "nicht lesbar"))
	line(C_ChatInfo ~= nil or SendAddonMessage ~= nil, "Addon-Nachrichten (Sync, Gebote): " .. ((C_ChatInfo or SendAddonMessage) and "ok" or "fehlt"))
	local plates = GetCVar and GetCVar("nameplateShowEnemies")
	line(plates == "1", "Gegner-Namensplaketten: " .. (plates == "1" and "an" or "AUS – für 'Adds markieren' Taste V drücken"))
	line(IsInGuild(), "Gilde: " .. (RM.MyGuild() or "keine"))
	local edit = (saved.CanEdit or RM.CanEdit)()
	line(nil, "Deine Rechte: " .. (edit and "volle Rechte (DKP ändern, versteigern)" or "keine Raidleiter-Rechte"))
	local inRaid = (saved.InRaid or RM.InRaid)()
	line(nil, "Gruppe: " .. (inRaid and ("im Raid" .. (((saved.IsAssist or RM.IsAssist)()) and ", Raidleiter/Assistent" or "")) or "kein Raid"))
	if inRaid then
		local m = RM.GetLootMethod and RM.GetLootMethod()
		line(m == "master" or not RM.Caps.masterLoot, "Plündermethode: " .. tostring(m))
	end
	local d = RM.db.data
	local players = 0
	for _ in pairs(d.players or {}) do players = players + 1 end
	line(true, string.format("Daten: %d Spieler, %d Log-Einträge, Stand %s", players, #(d.log or {}), d.version > 0 and RM.FormatTime(math.min(d.version, GetServerTime())) or "leer"))
	line(nil, "Testmodus: " .. (T.active and ("AN, Ansicht als " .. ROLE_NAMES[T.role]) or "aus"))
	T.selfTest = table.concat(out, "\n")
	Log("Selbsttest ausgeführt.")
end

---------------------------------------------------------------------------
-- Fenster
---------------------------------------------------------------------------
local win
local function Section(parent, text, y)
	local h = UI.Header(parent, text)
	h:SetPoint("TOPLEFT", 14, y)
	return h
end

local function CreateWindow()
	local f = UI.Frame(UIParent, 560, 828)
	UI.Skin(f)
	f:SetFrameStrata("HIGH")
	f:SetClampedToScreen(true)
	UI.MakeMovable(f, "testTool", "CENTER", 300, 0)
	_G.RaidMasterTestFrame = f
	tinsert(UISpecialFrames, "RaidMasterTestFrame")

	local title = UI.Text(f, "RaidMaster |cffffffffTest|r", 16, COLORS.accent[1], COLORS.accent[2], COLORS.accent[3])
	title:SetPoint("TOPLEFT", 14, -12)
	local close = UI.CloseButton(f, function() f:Hide() end)
	close:SetPoint("TOPRIGHT", -8, -8)

	f.status = UI.Text(f, "", 12)
	f.status:SetPoint("TOPLEFT", 14, -40)
	f.status:SetWidth(530)
	local toggle = UI.Button(f, "", 260, 28, function() if T.active then T.StopAsk() else T.Start() end end,
		"Testmodus: Daten werden gesichert und beim Beenden wiederhergestellt.\nKeine Nachrichten an Gilde oder Raid.")
	toggle:SetPoint("TOPLEFT", 14, -62)
	local selfBtn = UI.Button(f, "Selbsttest", 120, 28, function() T.SelfTest() end, "Prüft Spielversion, Daten, Rechte und Einstellungen.")
	selfBtn:SetPoint("LEFT", toggle, "RIGHT", 8, 0)
	local openBtn = UI.Button(f, "RaidMaster öffnen", 130, 28, function() RM.UI.Open() end)
	openBtn:SetPoint("LEFT", selfBtn, "RIGHT", 8, 0)

	Section(f, "Ansicht als", -104)
	local roleBtns = {}
	local x = 14
	for _, role in ipairs({ "member", "lead", "raidlead" }) do
		local b = UI.Button(f, ROLE_NAMES[role], 170, 26, function() T.SetRole(role) end,
			role == "member" and "Raidmitglied: sieht nur DKP-Stände und Versteigerung (bieten), keine Rechte." or
			role == "lead" and "Assistent: Raid-Seiten und Symbolleiste, kein DKP ändern." or
			"Raidleiter: alle Rechte – Raid starten/beenden, Plündermeister, DKP, Versteigerung, Einstellungen.")
		b:SetPoint("TOPLEFT", x, -128)
		roleBtns[role] = b
		x = x + 177
	end

	Section(f, "Raid simulieren", -170)
	T.pool = RM.DKP.ActivePool()
	local raidDrop = UI.Dropdown(f, 230, function() return UI.PoolGroups(RM.db.data) end, function() return T.pool end, function(v)
		T.pool = v
		local def = RM.Data.Pools[v]
		T.boss = def and def.bossIDs and def.bossIDs[1]
		T.Refresh()
	end, "Raid für den Test")
	raidDrop:SetPoint("TOPLEFT", 14, -194)
	local def0 = RM.Data.Pools[T.pool]
	T.boss = def0 and def0.bossIDs and def0.bossIDs[1]
	local bossDrop = UI.Dropdown(f, 230, function()
		local def = RM.Data.Pools[T.pool]
		local items = {}
		for _, id in ipairs(def and def.bossIDs or {}) do items[#items + 1] = { id, RM.Data.Bosses[id].name } end
		return { { items = items } }
	end, function() return T.boss end, function(v) T.boss = v end, "Boss für den Bosskill")
	bossDrop:SetPoint("LEFT", raidDrop, "RIGHT", 10, 0)
	local startBtn = UI.Button(f, "Raid starten", 126, 26, function() T.StartRaid() end, "Startet eine Raid-Sitzung mit Pünktlichkeitsbonus.")
	startBtn:SetPoint("TOPLEFT", 14, -226)
	local killBtn = UI.Button(f, "Bosskill", 126, 26, function() T.BossKill() end,
		"Spielt Bosskampf-Beginn und -Ende vor: Boss-DKP, Erstkill, automatische Markierungsvorlage.")
	killBtn:SetPoint("LEFT", startBtn, "RIGHT", 8, 0)
	killBtn:SetAccent(true)
	local endBtn = UI.Button(f, "Raid beenden", 126, 26, function() T.EndRaid() end, "Beendet die Sitzung mit Abschlussbonus.")
	endBtn:SetPoint("LEFT", killBtn, "RIGHT", 8, 0)
	local tqBtn = UI.Button(f, "Jäger-Abfrage", 120, 26, function() T.TranqTest() end,
		"Magmadar: fragt die Jäger nach Einlullender Schuss und postet die Rotation (Testjäger antworten selbst).")
	tqBtn:SetPoint("LEFT", endBtn, "RIGHT", 8, 0)

	local runBtn = UI.Button(f, "Ganzen Raid durchspielen", 200, 26, function() T.RunRaids(T.runs) end,
		"Alle Bosse des gewählten Raids nacheinander: Bosskill, Beute aus der echten Beutetabelle (Classic/TBC/Wrath),\n"
		.. "Regeln (Versteigerung, Gildenbank, Entzauberer ...), Versteigerungen mit Testgeboten, Trash-Beute zwischendurch.")
	runBtn:SetPoint("TOPLEFT", 14, -258)
	runBtn:SetAccent(true)
	local trashBtn = UI.Button(f, "Trash-Loot", 120, 26, function() T.TrashLoot() end, "Ein zufälliges Trash-Item des Raids droppen lassen.")
	trashBtn:SetPoint("LEFT", runBtn, "RIGHT", 8, 0)
	local stopRunBtn = UI.Button(f, "Durchlauf abbrechen", 160, 26, function() T.StopRun() end)
	stopRunBtn:SetPoint("LEFT", trashBtn, "RIGHT", 8, 0)
	local autoCheck = UI.Check(f, "Automatisch versteigern (ohne Klicken)", function() return T.autoAuction end,
		function(v) T.autoAuction = v end,
		"Aus (Standard): die Beute liegt in der Warteschlange, du startest jede Versteigerung selbst und klickst \"Vergeben\".\n"
		.. "An: der Durchlauf versteigert und vergibt alles von selbst.")
	autoCheck:SetPoint("TOPLEFT", 14, -290)
	local speedLabel = UI.Text(f, "Dauer je Versteigerung:", 12)
	speedLabel:SetPoint("TOPLEFT", 290, -295)
	local speedOpts = {}
	for _, v in ipairs(T.SPEEDS) do speedOpts[#speedOpts + 1] = { v, v .. " Sek." } end
	local speed = UI.Cycle(f, 90, speedOpts, function() return T.AuctionSec() end, function(v) T.SetAuctionSec(v) end,
		"Wie lange jede Versteigerung im Test höchstens läuft (Klick = nächster Wert). Die Testspieler bieten entsprechend schneller;\n"
		.. "haben alle geboten, läuft die Restzeit nur noch 1 Sek. Keine Verlängerung bei späten Geboten.\n"
		.. "Gilt nur im Testmodus – beim Beenden kommt deine echte Einstellung zurück.")
	speed:SetPoint("TOPLEFT", 450, -290)
	local runsLabel = UI.Text(f, "Raidabende hintereinander:", 12)
	runsLabel:SetPoint("TOPLEFT", 16, -323)
	local runsBox = UI.EditBox(f, 44, 24)
	runsBox:SetPoint("TOPLEFT", 190, -318)
	runsBox:SetText("1")
	runsBox:SetScript("OnTextChanged", function(self, user)
		if user then T.runs = math.max(1, math.min(10, math.floor(tonumber(self:GetText()) or 1))) end
	end)
	runsBox:SetScript("OnEnterPressed", function(self) self:ClearFocus(); self:SetText(tostring(T.runs)) end)
	local weeklyCheck = UI.Check(f, "je eine Woche auseinander datieren", function() return T.weekly end, function(v) T.weekly = v end,
		"Die Raidabende bekommen Daten im Wochenabstand (der letzte heute) – so sieht der Verlauf im Discord aus wie nach mehreren Wochen.")
	weeklyCheck:SetPoint("TOPLEFT", 250, -321)

	Section(f, "Versteigerung", -354)
	local itemBox = UI.LinkBox(f, 300, 26)
	itemBox:SetPoint("TOPLEFT", 14, -378)
	local hint = UI.Text(itemBox, "Item per Shift-Klick (leer = Ruhestein)", 11, unpack(COLORS.muted))
	hint:SetPoint("LEFT", 8, 0)
	itemBox:HookScript("OnTextChanged", function(self) if self:GetText() == "" then hint:Show() else hint:Hide() end end)
	itemBox:HookScript("OnEditFocusGained", function() hint:Hide() end)
	local aucBtn = UI.Button(f, "Mit Testgeboten versteigern", 220, 26, function() T.Auction(itemBox:GetText()) end,
		"Startet eine Versteigerung; 4 Testspieler bieten nacheinander. Danach fragt RaidMaster wie im echten Raid, ob vergeben wird.")
	aucBtn:SetPoint("LEFT", itemBox, "RIGHT", 8, 0)
	local dkpBox = UI.EditBox(f, 120, 26)
	dkpBox:SetPoint("TOPLEFT", 14, -412)
	dkpBox:SetText("1000")
	dkpBox:SetScript("OnEnterPressed", function(self) T.GiveMeDKP(self:GetText()); self:ClearFocus() end)
	local dkpBtn = UI.Button(f, "DKP an mich (gewählter Raid)", 220, 26, function() T.GiveMeDKP(dkpBox:GetText()) end,
		"Bucht dir beliebig viele DKP im oben gewählten Raid (negativ = abziehen). Nur im Testmodus – wird beim Beenden zurückgesetzt.")
	dkpBtn:SetPoint("LEFT", dkpBox, "RIGHT", 8, 0)
	local discordBtn = UI.Button(f, "Test an Discord senden", 168, 26, function() T.SendToDiscord() end,
		"DKP-Stand, Teilnehmer und Loot dieses Tests im Discord posten (mit TEST markiert, nach 10 Minuten gelöscht).\n"
		.. "Lädt die Oberfläche neu – danach ist der Testmodus beendet. Der Uploader muss laufen.")
	discordBtn:SetPoint("LEFT", dkpBtn, "RIGHT", 8, 0)

	local sendCheck = UI.Check(f, "Ergebnis nach dem Raid automatisch an Discord senden (DKP- und Loot-Kanal)",
		function() return T.AutoSendOn() end,
		function(v)
			T.SetAutoSend(v)
			if T.active and RM.db.testMode then RM.db.testMode.post = v or nil end
		end,
		"An (Standard): nach \"Raid beenden\" bzw. am Ende des Durchlaufs wird das Ergebnis nach 10 Sek. gesendet\n"
		.. "(lädt die Oberfläche neu), und auch jedes /reload oder Ausloggen im Testmodus schickt es.\n"
		.. "Der Bot postet es mit TEST markiert und löscht es nach 10 Minuten. Der Uploader muss laufen.")
	sendCheck:SetPoint("TOPLEFT", 14, -444)
	local followCheck = UI.Check(f, "\"Raid starten\" in RaidMaster spielt im Test den ganzen Raid durch",
		function() return T.FollowStartOn() end, function(v) T.SetFollowStart(v) end,
		"An (Standard): startest du im Testmodus den Raid in RaidMaster (Seite Raidleiter), startet das Test-Tool\n"
		.. "den Durchlauf (Bosse, Beute, Testgebote) für diesen Raid. \"Raid beenden\" in RaidMaster bricht ihn ab\n"
		.. "und schickt das Ergebnis an Discord. Der Knopf \"Raid starten\" hier im Test-Tool startet nur die Sitzung.")
	followCheck:SetPoint("TOPLEFT", 14, -468)

	Section(f, "Schlachtzugsymbole (echt, z. B. an Trainingspuppen)", -502)
	local m1 = UI.Button(f, "Totenkopf aufs Ziel", 160, 26, function() RM.Markers.Mark(8) end)
	m1:SetPoint("TOPLEFT", 14, -526)
	local m2 = UI.Button(f, "Adds markieren", 160, 26, function() RM.Markers.MarkAdds() end, "Markiert alle sichtbaren Gegner nach der gewählten Vorlage.")
	m2:SetPoint("LEFT", m1, "RIGHT", 8, 0)
	local m3 = UI.Button(f, "Alle aus", 120, 26, function() RM.Markers.ClearAll() end)
	m3:SetPoint("LEFT", m2, "RIGHT", 8, 0)

	Section(f, "Protokoll", -568)
	local diagBtn = UI.Button(f, "Diagnose", 110, 22, function() if RM.Diag then RM.Diag.Toggle() end end,
		"Zeigt Fehler und Hänger von RaidMaster und vom Test-Durchlauf und kann sie lösen.")
	diagBtn:SetPoint("TOPRIGHT", -14, -564)
	local box = UI.Multiline(f, 532, 220, true)
	box:SetPoint("TOPLEFT", 14, -592)

	function T.Refresh()
		if not f:IsShown() then return end
		f.status:SetText(T.active and ("|cffff8c1aTestmodus AN|r – Ansicht als |cffffffff" .. ROLE_NAMES[T.role] .. "|r. Deine echten Daten sind gesichert.")
			or "|cff999999Testmodus aus.|r Starte ihn, um gefahrlos zu testen – beim Beenden wird alles zurückgesetzt.")
		toggle:SetText(T.active and "Testmodus beenden (alles zurücksetzen)" or "Testmodus starten")
		toggle:SetAccent(not T.active)
		for role, b in pairs(roleBtns) do b:SetAccent(T.active and T.role == role) end
		raidDrop:Refresh(); bossDrop:Refresh(); autoCheck:Refresh()
		local text = T.selfTest and (T.selfTest .. "\n\n") or ""
		box:SetText(text .. table.concat(T.log, "\n"))
	end
	f:SetScript("OnShow", function() T.Refresh() end)
	return f
end

function T.Toggle()
	win = win or CreateWindow()
	if win:IsShown() then win:Hide() else win:Show(); T.Refresh() end
end

SLASH_RAIDMASTERTEST1 = "/rmtest"
function T.Slash(msg)
	msg = (msg or ""):lower()
	if msg == "start" then T.Start()
	elseif msg == "stop" or msg == "ende" then T.StopAsk()
	elseif msg == "check" or msg == "selbsttest" then T.SelfTest(); if not (win and win:IsShown()) then print((T.selfTest or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")) end
	else T.Toggle() end
end
SlashCmdList["RAIDMASTERTEST"] = T.Slash

-- Diagnose von RaidMaster: Zustand des Test-Durchlaufs anzeigen und Hänger lösen
if RM.Diag then
	table.insert(RM.Diag.providers, function()
		local lines = { "|cffffd200Test-Tool|r" }
		lines[#lines + 1] = "  Testmodus: " .. (T.active and ("an, Ansicht als " .. ROLE_NAMES[T.role]) or "aus")
		if run then
			local A = RM.Auction
			local why
			if A.current and A.AwaitingAward() then why = "wartet auf DICH: Vergeben / Nicht vergeben / Neu versteigern"
			elseif A.current then why = "Versteigerung läuft"
			elseif #A.queue > 0 then why = (T.autoAuction and "startet gleich die nächste Versteigerung" or ("wartet auf DICH: " .. #A.queue .. " Item(s) in der Warteschlange – Seite Versteigerung, \"Gewähltes starten\""))
			else why = "nächster Boss kommt gleich" end
			lines[#lines + 1] = string.format("  Durchlauf: %s, Boss %d von %d – %s", run.def and run.def.name or "?", run.index or 0, run.def and #run.def.bosses or 0, why)
			if T.series then lines[#lines + 1] = string.format("  Raidabend %d von %d", T.series.total - T.series.left, T.series.total) end
		else
			lines[#lines + 1] = "  Kein Durchlauf aktiv."
		end
		return lines
	end)
	table.insert(RM.Diag.fixers, function()
		if run then
			run.told = false
			run.waitUntil = math.min(run.waitUntil or 0, GetTime())
			if run.ticker == nil or (run.ticker.IsCancelled and run.ticker:IsCancelled()) then
				run.ticker = C_Timer.NewTicker(0.5, RunStep)
				return { "Test-Durchlauf neu angestoßen." }
			end
		end
	end)
end

-- Früher gab es das Test-Tool als eigenes Addon "RaidMasterTest" – das alte wird abgeschaltet
do
	RM.On("PLAYER_LOGIN", function()
		local loaded = (C_AddOns and C_AddOns.IsAddOnLoaded and C_AddOns.IsAddOnLoaded("RaidMasterTest"))
			or (IsAddOnLoaded and IsAddOnLoaded("RaidMasterTest"))
		if loaded or (RaidMasterTest and RaidMasterTest ~= T) then
			-- das alte Addon hat sich beim Laden über das eingebaute gelegt: stoppen und stilllegen
			local old = RaidMasterTest
			if old and old ~= T then
				if old.active and old.Stop then pcall(old.Stop) end
				for k, v in pairs(old) do
					if type(v) == "function" then
						old[k] = function() print("|cffff8c1a[RaidMaster]|r Altes RaidMasterTest ist abgeschaltet – bitte /reload.") end
					end
				end
				old.active = false
				RaidMasterTest = T
			end
			SlashCmdList["RAIDMASTERTEST"] = T.Slash
			-- falls das alte Addon RaidMaster-Funktionen umgebogen hat: echte wiederherstellen
			if not T.active and REAL.captured then
				for _, k in ipairs(OVERRIDE) do RM[k] = REAL[k] end
			end
			RM.Fire("CONFIG_CHANGED"); RM.Fire("SESSION_CHANGED")
			local disable = (C_AddOns and C_AddOns.DisableAddOn) or DisableAddOn
			if disable then pcall(disable, "RaidMasterTest") end
			print("|cffff8c1a[RaidMaster]|r Das Test-Tool ist jetzt in RaidMaster eingebaut. Das alte Addon \"RaidMasterTest\" "
				.. "wurde abgeschaltet – bitte einmal /reload und den Ordner Interface\\AddOns\\RaidMasterTest löschen.")
		end
	end)
end
