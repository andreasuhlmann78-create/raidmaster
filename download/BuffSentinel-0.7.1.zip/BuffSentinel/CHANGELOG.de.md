# BuffSentinel – Änderungen

## 0.7.1
- Behoben: Hauptbaum wird richtig erkannt (z. B. 14/41/0 = Furor statt Waffen), auch mit Zweitskillung – die aktive Talentgruppe wird ausdrücklich gelesen.
- Behoben: Talente und Procs werden nach WoW-Version gefiltert. WoW-Forever-Talente (Bloodthrill, Vanguard) und WotLK-Procs (Plötzlicher Tod, Schäumendes Blut, Schwert und Schild, Hot Streak) erscheinen nicht mehr in TBC/Classic Era.
- Behoben: Der Testmodus zeigt Talent-Procs nur für die gewählte Skillung (z. B. Hot Streak nur Feuer, Anmut der Natur nur Gleichgewicht).
- Die Listen in den Einstellungen springen beim Abhaken nicht mehr; neuer Knopf „Auto“ setzt einen Eintrag auf die automatische Auswahl zurück.
- Fehlende Schriftzeichen (Pfeil, Häkchen) und ein veralteter Hinweistext behoben.
- Testmodus-Layout: zweizeilige Beschriftungen, Gruppentitel neben der Fläche, Flächen wachsen mit der Anzahl Buttons, Testleiste ganz oben, Einstellungsfenster schliesst sich beim Start, Reinigungsleiste mit 5 Beispielplätzen und ausgeblendet bei Klassen ohne Reinigen.
- Hexenmeister-Procs heissen nach ihrer Quelle (Schattentrance, Heimzahlen).
- Server-Sync versucht den Kanalbeitritt mehrmals und zeigt einen klaren Status.
- Behoben: Tooltip blieb nach dem Öffnen des Spendenfensters stehen.

## 0.7.0
- Neuer Knopf „Unterstützen“ (PayPal) oben im Einstellungsfenster und auf der Seite „Zonen & Anzeige“, auch per `/bsen spenden`. Öffnet sich nur auf Klick – kein Aufpoppen, keine Chat-Meldungen.

## 0.6.3
- Mindestens 3 Sekunden zwischen Warntönen, derselbe Ton höchstens alle 4 Sekunden.
- „Sounds testen“ spielt alle Töne mit 3 Sekunden Abstand und zeigt an, welcher läuft.

## 0.6.1
- WoW Forever: neue Paladin- (Siegel der Wut, Lichtwacht, Stimme der Wahrheit, Schnelles Richturteil, Bollwerk des Templers, Lichtenergie) und Schamanen-Fähigkeiten (Wut des Weitsehers, Feuernova, Totemprojektion).
- Testmodus in Classic Era zeigt nur die Klassen deiner Fraktion.

## 0.6.0
- Testmodus mit Beispielanzeige für alle Klassen und Skillungen; Buttons frei platzierbar.

## 0.5.0
- Reinigungsleiste für Mitspieler und Entzaubern von Gegnern.

## 0.4.0
- Erste Version: Proc-Buttons, Buff-Wächter mit Ein-Klick-Buff, Cooldown-Leiste, Skillungserkennung, alle WoW-Versionen.
