-- BuffSentinel - Data/Warrior.lua
--
-- Feldbeschreibung (gilt für alle Klassendateien):
--   key            eindeutiger Schlüssel
--   kind           "buff" = Warnung + Ein-Klick-Button wenn Buff fehlt
--                  "proc" = Button erscheint sofort, wenn die Fähigkeit nutzbar wird – Klick löst sie aus
--                  "cd"   = Cooldown-Leiste, leuchtet kurz auf wenn bereit
--   spell          Spell-ID (Rang 1) oder Liste von Alternativen; Strings nur für unbekannte IDs
--   v              "classic" (Standard: Era/SoD/HC, Forever, TBC, Wrath, Titan, Cata) | "modern" (MoP, Retail) | "all"
--   min / max      Erweiterung: 1 Era+Forever, 2 TBC, 3 Wrath/Titan, 4 Cata, 5 MoP, 12 Retail
--   forever        nur in WoW Forever;  noForever = nicht in WoW Forever
--   retail         Buff gilt auch in Retail (dort nur ausserhalb des Kampfes);  retailOnly = nur Retail
--   specs          Talentbaum (Classic) bzw. Spezialisierung (MoP/Retail) -> nur dort automatisch aktiv
--   talents        nur aktiv, wenn eines dieser Talente (Name) geskillt ist  (Classic-Bäume)
--   talentSpell    nur aktiv, wenn dieses Talent (Zauber-ID) gelernt ist     (MoP/Retail)
--   enableIfTalent / enableIfTalentSpell   zusätzlich aktiv mit diesem Talent
--   trigger        Kampflog: "dodge" (Ziel weicht aus), "avoid" (du blockst/parierst/weichst aus), "parry"
--   reactive       Client meldet die Fähigkeit als nutzbar -> Proc
--   procAuras      Proc wird über einen Buff auf dir erkannt;  minStacks = ab so vielen Stapeln
--   targetBelow    Ziel unter x % Leben
--   group          Buff bei der ganzen Gruppe prüfen;  groupSpell = Gruppenvariante;  manaOnly = nur Manaklassen
--   weapon         "main"/"off" = Waffenbuff (Gift, Waffenverzauberung);  items = Gegenstände (bester zuerst)
--   optional       nicht automatisch aktiv;  mode = "combat" (nur im Kampf) | "always"

local ADDON, BS = ...
BS.ClassData = BS.ClassData or {}

BS.ClassData.WARRIOR = {
    specNames       = { "Waffen", "Furor", "Schutz" },
    specNamesModern = { "Waffen", "Furor", "Schutz" },
    icon = "Interface\\Icons\\Ability_Warrior_BattleShout",
    entries = {
        ----------------------------------------------------------------
        -- Classic-Familie (Era, Forever, TBC, Wrath, Titan, Cata)
        ----------------------------------------------------------------
        { key = "battleshout",   kind = "buff", spell = 6673, mode = "combat" },
        { key = "commanding",    kind = "buff", spell = 469, min = 3, mode = "combat", optional = true },

        -- Procs
        { key = "overpower",     kind = "proc", spell = 7384, specs = { 1 }, trigger = "dodge", window = 5,
          reactive = true, enableIfTalentForever = { "Bloodthrill" } },   -- Bloodthrill: nur WoW Forever
        { key = "revenge",       kind = "proc", spell = 6572, specs = { 3 }, trigger = "avoid", window = 5, reactive = true },
        { key = "execute",       kind = "proc", spell = 5308, targetBelow = 20 },
        { key = "victoryrush",   kind = "proc", spell = 34428, min = 2, reactive = true },
        { key = "suddendeath",   kind = "proc", spell = 5308, procAuras = { 52437 }, min = 3, max = 3, specs = { 1 },
          talents = { "Sudden Death", "Plötzlicher Tod" }, label = "Plötzlicher Tod", alert = "HINRICHTEN!" },
        { key = "suddendeathc",  kind = "proc", spell = 86346, procAuras = { 52437 }, min = 4, max = 4, specs = { 1 },
          talents = { "Sudden Death", "Plötzlicher Tod" }, label = "Plötzlicher Tod" },
        { key = "bloodsurge",    kind = "proc", spell = 1464, procAuras = { 46916 }, min = 3, specs = { 2 },
          talents = { "Bloodsurge", "Schäumendes Blut" }, alert = "ZERSCHMETTERN!" },
        { key = "swordboard",    kind = "proc", spell = 23922, procAuras = { 50227 }, min = 3, specs = { 3 },
          talents = { "Sword and Board", "Schwert und Schild" }, alert = "SCHILDSCHLAG!" },
        { key = "ragingblow",    kind = "proc", spell = 85288, min = 4, specs = { 2 }, reactive = true },

        -- Cooldowns Waffen
        { key = "mortalstrike",  kind = "cd", spell = 12294, specs = { 1 } },
        { key = "colossus",      kind = "cd", spell = 86346, min = 4, specs = { 1 } },
        { key = "sweeping",      kind = "cd", spell = 12292, specs = { 1 } },
        { key = "bladestorm",    kind = "cd", spell = 46924, min = 3, specs = { 1 } },
        { key = "spearing",      kind = "cd", spell = "Spearing Strike", specs = { 1 }, forever = true },
        { key = "retaliation",   kind = "cd", spell = 20230, specs = { 1 } },
        { key = "charge",        kind = "cd", spell = 100,   specs = { 1 }, enableIfTalentForever = { "Vanguard" } },   -- Vanguard: nur WoW Forever

        -- Cooldowns Furor
        { key = "bloodthirst",   kind = "cd", spell = 23881, specs = { 2 } },
        { key = "whirlwind",     kind = "cd", spell = 1680,  specs = { 2 } },
        { key = "deathwish",     kind = "cd", spell = 12328, specs = { 2 } },
        { key = "recklessness",  kind = "cd", spell = 1719,  specs = { 2 } },
        { key = "intercept",     kind = "cd", spell = 20252, specs = { 2 } },

        -- Cooldowns Schutz
        { key = "shieldslam",    kind = "cd", spell = 23922, specs = { 3 } },
        { key = "shieldblock",   kind = "cd", spell = 2565,  specs = { 3 } },
        { key = "shockwave",     kind = "cd", spell = 46968, min = 3, specs = { 3 } },
        { key = "shieldwall",    kind = "cd", spell = 871,   specs = { 3 } },
        { key = "laststand",     kind = "cd", spell = 12975, specs = { 3 } },
        { key = "spellreflect",  kind = "cd", spell = 23920, min = 2, specs = { 3 } },

        -- Cooldowns alle
        { key = "heroicleap",    kind = "cd", spell = 6544,  min = 4 },
        { key = "pummel",        kind = "cd", spell = 6552 },
        { key = "bloodrage",     kind = "cd", spell = 2687,  max = 3 },
        { key = "berserkerrage", kind = "cd", spell = 18499 },

        ----------------------------------------------------------------
        -- Moderne Familie (MoP Classic, Retail)
        ----------------------------------------------------------------
        { key = "m_battleshout", kind = "buff", v = "modern", spell = 6673, group = true, retail = true },
        { key = "m_commanding",  kind = "buff", v = "modern", spell = 469, max = 5, optional = true, mode = "combat" },

        { key = "m_overpower",   kind = "proc", v = "modern", spell = 7384, specs = { 1 }, reactive = true },
        { key = "m_execute",     kind = "proc", v = "modern", spell = 5308, specs = { 1, 2 }, targetBelow = 20 },
        { key = "m_suddendeath", kind = "proc", v = "modern", spell = 5308, procAuras = { 52437 }, specs = { 1, 2 },
          label = "Plötzlicher Tod", alert = "HINRICHTEN!" },
        { key = "m_victory",     kind = "proc", v = "modern", spell = 34428, reactive = true },
        { key = "m_bloodsurge",  kind = "proc", v = "modern", spell = 100130, procAuras = { 46916 }, specs = { 2 } },
        { key = "m_ragingblow",  kind = "proc", v = "modern", spell = 85288, specs = { 2 }, reactive = true },
        { key = "m_ultimatum",   kind = "proc", v = "modern", spell = 78, procAuras = { 122510 }, specs = { 3 } },
        { key = "m_swordboard",  kind = "proc", v = "modern", spell = 23922, procAuras = { 50227 }, specs = { 3 } },

        { key = "m_mortal",      kind = "cd", v = "modern", spell = 12294, specs = { 1 } },
        { key = "m_colossus",    kind = "cd", v = "modern", spell = 86346, specs = { 1, 2 } },
        { key = "m_bloodthirst", kind = "cd", v = "modern", spell = 23881, specs = { 2 } },
        { key = "m_shieldslam",  kind = "cd", v = "modern", spell = 23922, specs = { 3 } },
        { key = "m_revenge",     kind = "cd", v = "modern", spell = 6572,  specs = { 3 } },
        { key = "m_shieldblock", kind = "cd", v = "modern", spell = 2565,  specs = { 3 } },
        { key = "m_barrier",     kind = "cd", v = "modern", spell = 112048, specs = { 3 } },
        { key = "m_reckless",    kind = "cd", v = "modern", spell = 1719,  specs = { 1, 2 } },
        { key = "m_banner",      kind = "cd", v = "modern", spell = 114207 },
        { key = "m_avatar",      kind = "cd", v = "modern", spell = 107574 },
        { key = "m_bloodbath",   kind = "cd", v = "modern", spell = 12292 },
        { key = "m_bladestorm",  kind = "cd", v = "modern", spell = 46924 },
        { key = "m_dragonroar",  kind = "cd", v = "modern", spell = 118000 },
        { key = "m_shieldwall",  kind = "cd", v = "modern", spell = 871,   specs = { 3 } },
        { key = "m_laststand",   kind = "cd", v = "modern", spell = 12975, specs = { 3 } },
        { key = "m_diebysword",  kind = "cd", v = "modern", spell = 118038, specs = { 1, 2 } },
        { key = "m_leap",        kind = "cd", v = "modern", spell = 6544 },
        { key = "m_pummel",      kind = "cd", v = "modern", spell = 6552 },
        { key = "m_berserker",   kind = "cd", v = "modern", spell = 18499 },
    },
}
