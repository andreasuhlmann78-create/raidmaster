if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Testroutine (ab 0.65.6)
-- Prüft das Addon "auf Herz und Nieren" nach auftraege/AHSentinel/testroutine-ahsentinel.txt und schreibt den
-- Bericht über GoldSentinelTest.lua in AHSentinelDB.gsTest (der RaidMasterUploader meldet ihn an die Prüfung).
--   /ahs testroutine            alles, was ohne Spieler-Handlung geht (Auktionshaus darf zu sein)
--   /ahs testroutine a ... k    nur ein Bereich (k = Oberfläche; Spieltest: /ahs spieltest)
--   /ahs testroutine server     Auktionshaus offen: Scan, Suchen, simulierter Handel (bisheriger Selbsttest)
--   /ahs testroutine haendler | berufe | post | gildenbank | kampf   halbautomatische Teile
--   Kurzform: /ahs test = testroutine server, /ahs test daten = testroutine
-- Nur für den Entwickler (GoldSentinelDev). Sicher:
--   * echte Daten (AHSentinelDB) werden vorher gesichert, nachher verglichen und wiederhergestellt
--   * Kaufen, Bieten, Einstellen, Abbrechen, Post, Händler-Verkauf und Preis-Sync sind nur simuliert (A:Simulated)
--   * keine Blizzard-Funktion wird ersetzt: Simulationen laufen über eigene Nahtstellen
--     (A.apiOverride / A:API, A.testCombat / A:InCombat, A.AH-Proxy, Test-Briefkasten A.Inbox)
--   * im Kampf startet sie nicht; beginnt ein Kampf, bricht sie ab und stellt alles zurück
-- Testfall-IDs bleiben über alle Versionen gleich (T01 ... T152, neue ab T153).
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local ST, TM = A.SelfTest, A.TestMode

local TR = { running = false, rows = {}, log = {} }
A.TestRoutine = TR

local FAKE = 990000001                 -- Test-Item-IDs ab hier (SelfTest FAKE_ID0 + 1)
local LINEN = 2589                     -- Leinenstoff
local SLICE_MS = 40                    -- Retail: "script ran too long" vermeiden
local clock = debugprofilestop

local function G() return _G.GoldSentinelGame end
local function GTest() return _G.GoldSentinelTest end
local function Ms() return clock and clock() or (GetTime() * 1000) end

-- ------------------------------------------------------------
-- Hilfen
-- ------------------------------------------------------------
local function Copy(v)
    if type(v) ~= "table" then return v end
    local c = {}
    for k, x in pairs(v) do c[k] = Copy(x) end
    return c
end

local function Replace(target, source)
    if type(target) ~= "table" or type(source) ~= "table" then return end
    for k in pairs(target) do target[k] = nil end
    for k, v in pairs(source) do target[k] = v end
end

-- A.Print für die Dauer von fn abfangen; liefert die Zeilen (ohne Farbcodes)
local function Capture(fn, ...)
    local lines = {}
    local real = A.Print
    A.Print = function(_, msg) table.insert(lines, A:PlainText(tostring(msg))) end
    local res = { pcall(fn, ...) }
    A.Print = real
    if not res[1] then error(res[2], 0) end
    return lines, unpack(res, 2)
end
TR.Capture = Capture

-- Testwert, der wie ein geschützter Wert ("secret value") bei Vergleich, Verketten, Index und Länge einen Fehler wirft
local function Boom() error("geschützter Testwert benutzt", 2) end
local SECRET = setmetatable({}, { __index = Boom, __newindex = Boom, __concat = Boom, __lt = Boom, __le = Boom,
    __len = Boom, __call = Boom, __unm = Boom, __add = Boom, __sub = Boom, __mul = Boom, __div = Boom,
    __tostring = function() return "<geschützt>" end })
TR.SECRET = SECRET

-- fn mit simuliertem geschützten Wert ausführen: GoldSentinelGame.IsSecret (Addon-Tabelle, kein Blizzard-Global)
-- erkennt SECRET nur für die Dauer dieses einen synchronen Aufrufs.
local function WithSecret(fn, ...)
    local g = G()
    if not (g and g.IsSecret) then return pcall(fn, ...) end
    local real = g.IsSecret
    g.IsSecret = function(v) if v == SECRET then return true end return real(v) end
    local res = { pcall(fn, ...) }
    g.IsSecret = real
    return unpack(res)
end

local function Count(t) return A:CountTable(t) end

-- Prüfsumme grosser, nur gelesener Tabellen (statt einer Kopie)
local function Checksum(t)
    local n, h, newest = 0, 0, 0
    for id, e in pairs(t or {}) do
        n = n + 1
        if type(e) == "table" and type(e.history) == "table" then
            h = h + #e.history
            local last = e.history[#e.history]
            if type(last) == "table" and type(last.t) == "number" and last.t > newest then newest = last.t end
        end
    end
    return { n = n, h = h, newest = newest }
end

local function HasFakeIDs(t)
    for id in pairs(t or {}) do if type(id) == "number" and id >= 990000000 then return id end end
    return nil
end

-- ------------------------------------------------------------
-- Sandbox: echte Daten sichern, vergleichen, wiederherstellen
-- ------------------------------------------------------------
-- markets.<Schlüssel>.data ist dieselbe Tabelle wie marketData (Preisliste des aktiven Auktionshauses, A:ActivateMarket):
-- echte Preise aus echten Suchen während des Laufs, wie marketData selbst (Befund 20:15 A2 "markets.…")
local NO_COPY = { marketData = true, names = true, gsTest = true, testRoutine = true, markets = true }
-- Änderungen aus echten Spiel-Ereignissen (während der Routine läuft das Spiel weiter)
-- watcher.found: Zähler echter Wächter-Funde (der Wächter läuft im Spiel weiter, wenn das AH offen ist)
local ALLOWED = { "gsTest", "testRoutine", "marketData", "markets", "names", "namesSent", "vendorPrices", "selftest", "watcher.found",
    "sync.received", "sync.peers", "sync.lastReceived", "sync.lastScanTimeReceived", "sync.namesReceived",
    "settings.cmdUse",       -- Befehlszähler (CmdHint): vom Nutzer während des Laufs getippte Befehle (z. B. "testroutine stop")
    "gsSync.book" }          -- X6a: echter Sync im Hintergrund (Adressbuch seen/last) - bleibt live, wird nicht zurückgeschrieben
local ALLOWED_PART = {
    server = { "lastScanTime", "totalScans", "scanLog", "lastOwnScan", "fullScan" },   -- fullScan: VM1 echter Schnell-Vollscan
    haendler = { "vendorBuy", "vendorCost" },
}
-- beim ersten Lesen mit Standardwerten angelegt (normales Verhalten, keine Testdaten): nil -> Tabelle ist erlaubt
local LAZY = { ["watcher.binds"] = true, ["settings.lastSub"] = true, recipes = true, buyFavorites = true, activity = true }
local function HasTestMarker(v)
    if type(v) == "string" then return v:find("AHS%-Test") ~= nil end
    if type(v) == "number" then return v >= 990000000 end
    if type(v) == "table" then
        for k, x in pairs(v) do if HasTestMarker(k) or HasTestMarker(x) then return true end end
    end
    return false
end
-- Schlüssel, die Namen tragen: im Bericht nur als Platzhalter
local NAME_KEYS = { chars = "<Charakter>", recipes = "<Charakter>", guildBank = "<Gilde>", deShared = "<Spieler>",
    peers = "<Spieler>", book = "<Spieler>" }      -- X6b: gsSync.book.<Spieler> (Bericht geht ins öffentliche Repo)

local function OwnCharKey()
    local Ch = A.Chars
    if Ch and Ch.Key then local ok, k = pcall(Ch.Key, Ch); if ok then return k end end
    return nil
end

local function PathText(segs)
    local out = {}
    for i, s in ipairs(segs) do
        local prev = segs[i - 1]
        if prev and NAME_KEYS[prev] then out[i] = NAME_KEYS[prev] else out[i] = tostring(s) end
    end
    return table.concat(out, ".")
end

TR.PathText = PathText

function TR:IsAllowed(segs)
    local p = table.concat({ unpack(segs, 1, math.min(#segs, 2)) }, ".")
    local function match(list)
        for _, a in ipairs(list or {}) do
            if p == a or segs[1] == a then return true end
        end
        return false
    end
    if match(ALLOWED) or match(ALLOWED_PART[self.part]) then return true end
    -- VF3 (Befund grosser Test): Zeitpunkt der letzten Prüfung eines echten Sniper-Ziels ist Hintergrund-Zustand
    if segs[1] == "sniper" and segs[2] == "targets" and segs[4] == "checked" then return true end
    -- eigener Charakter: Gold, Taschen, Bank kommen aus echten Spiel-Ereignissen
    if segs[1] == "chars" and segs[2] ~= nil and segs[2] == self.ownChar then return true end
    return false
end

local function Diff(a, b, segs, out, self)
    if #out >= 200 then return end
    if #segs > 0 and self:IsAllowed(segs) then return end
    if type(a) == "table" and type(b) == "table" then
        for k, v in pairs(a) do
            local s = { unpack(segs) }; s[#s + 1] = k
            Diff(v, b[k], s, out, self)
        end
        for k, v in pairs(b) do
            if a[k] == nil then
                local s = { unpack(segs) }; s[#s + 1] = k
                local lazy = LAZY[table.concat(s, ".")] and type(v) == "table" and not HasTestMarker(v)
                if not self:IsAllowed(s) and not lazy then table.insert(out, s) end
            end
        end
    elseif a ~= b then
        table.insert(out, { unpack(segs) })
    end
end

function TR:Backup()
    local db = A.db
    local b = { __missing = {} }
    for k, v in pairs(db) do
        if not NO_COPY[k] then b[k] = Copy(v) end
    end
    self.ownChar = OwnCharKey()
    self.sums = { market = Checksum(db.marketData), names = Count(db.names) }
    db.testRoutine = { backup = b, part = self.part, started = time() }
end

local function SetPath(root, segs, value)
    local t = root
    for i = 1, #segs - 1 do
        if type(t[segs[i]]) ~= "table" then t[segs[i]] = {} end
        t = t[segs[i]]
    end
    t[segs[#segs]] = value
end

local function GetPath(root, segs)
    local t = root
    for i = 1, #segs do
        if type(t) ~= "table" then return nil end
        t = t[segs[i]]
    end
    return t
end

-- vergleicht mit der Sicherung, schreibt Unterschiede zurück; liefert die Pfade (Text) der Unterschiede
-- Schutz der echten Entzauber-Daten (Entscheid des Nutzers 10.11. 09:25): Fingerabdruck von deStats/deLog/deShared/
-- deBuys (Zahl der Einträge, Summe der Mengen) vor und nach dem Lauf - Abweichung = FEHLER im Bericht
local function DEPrint(src)
    src = src or {}
    local g, n, times, total = 0, 0, 0, 0
    for _, st in pairs(src.deStats or {}) do
        g = g + 1; n = n + (st.n or 0)
        for _, m in pairs(st.mats or {}) do times = times + (m.times or 0); total = total + (m.total or 0) end
    end
    local logN, logQ = 0, 0
    for _, e in ipairs(src.deLog or {}) do
        logN = logN + 1
        for _, l in ipairs(e.loot or {}) do logQ = logQ + (l[2] or 1) end
    end
    local sh = 0
    for _ in pairs(src.deShared or {}) do sh = sh + 1 end
    local buys = #(src.deBuys or {})
    return string.format("deStats %d Gruppen/%d/%d/%d · deLog %d/%d · deShared %d · deBuys %d", g, n, times, total, logN, logQ, sh, buys)
end
TR.DEPrint = DEPrint

-- W1 (Befund 10.11. 13:50): Entzauber-Tests nur auf Ersatztabellen. Die echten Tabellen (deStats, deShared, deLog,
-- deBuys, deBackup, deCount) werden NIE angefasst: vorher weggelegt (gleiche Tabellen, kein Kopieren/Zurückschreiben),
-- der Test läuft auf Kopien, danach kommen genau die echten Tabellen wieder hin.
TR.DE_KEYS = { "deStats", "deShared", "deLog", "deBuys", "deBackup", "deCount" }
function TR.DESandbox(fn, empty)
    local db = A.db
    local real = {}
    for _, k in ipairs(TR.DE_KEYS) do
        real[k] = db[k]
        if empty then db[k] = (type(real[k]) == "table") and {} or nil
        else db[k] = Copy(real[k]) end
    end
    local res = { pcall(fn) }
    for _, k in ipairs(TR.DE_KEYS) do db[k] = real[k] end
    if not res[1] then error(res[2], 0) end
    return unpack(res, 2)
end

-- Teil 2 (Anweisung Testroutine Entzaubern E13-E15): ECHTE Daten des Nutzers, nur lesen, ohne Namen
function TR:DEReport()
    local D = A.Disenchant
    local db = A.db or {}
    local out = { "Entzaubern (echte Daten):" }
    if not D then return out end
    local any = false
    local plaus = {}
    local keys = {}
    for key in pairs(db.deStats or {}) do keys[#keys + 1] = key end
    table.sort(keys)
    for _, key in ipairs(keys) do
        local st = db.deStats[key]
        local q, from, to, weapon = D:KeyInfo(key)
        local nOwn, nShared, mats = D:Combined(key)
        local prior = D:PriorForKey(key) or {}
        local qual = ({ [2] = "grün", [3] = "blau", [4] = "episch" })[q] or tostring(q)
        out[#out + 1] = string.format("  Gruppe %s %s-%s %s (%s): %d eigene, %d geteilt", qual, tostring(from), tostring(to),
            weapon and "Waffe" or "Rüstung", key, nOwn or 0, nShared or 0)
        any = true
        local N = st.n or 0
        local sumTimes = 0
        local allowed = D:AllowedMats(key) or {}
        for id, m in pairs(st.mats or {}) do
            sumTimes = sumTimes + (m.times or 0)
            local p0
            for _, e in ipairs(prior) do if e[1] == id then p0 = e[2] end end
            local rate = N > 0 and (m.times or 0) / N or 0
            local mark = ""
            if p0 and N >= 20 then
                local sd = math.sqrt(N * p0 * (1 - p0))
                local lo, hi = math.max(0, math.floor(N * p0 - 1.96 * sd)), math.ceil(N * p0 + 1.96 * sd)
                if (m.times or 0) < lo or (m.times or 0) > hi then
                    mark = string.format(" – auffällig (erwartet %d–%d)", lo, hi)
                end
            end
            out[#out + 1] = string.format("    %d: %d/%d = %.1f %% · Tabelle %s · Menge %d · Ø %.2f%s", id, m.times or 0, N, rate * 100,
                p0 and string.format("%.0f %%", p0 * 100) or "-", m.total or 0, (m.times or 0) > 0 and (m.total or 0) / m.times or 0, mark)
            -- E15 Plausibilität
            if next(allowed) and not allowed[id] then plaus[#plaus + 1] = key .. ": Material " .. id .. " ausserhalb der Tabelle" end
            if (m.times or 0) > N then plaus[#plaus + 1] = key .. ": Material " .. id .. " öfter als Entzauberungen" end
            if (m.times or 0) > 0 and (m.total or 0) / m.times > 5 then plaus[#plaus + 1] = key .. ": Ø-Menge " .. id .. " > 5" end
        end
        if q == 2 and N > 0 and math.abs(sumTimes - N) > math.max(1, N * 0.05) then
            plaus[#plaus + 1] = string.format("%s: Summe Materialien %d statt %d", key, sumTimes, N)
        end
    end
    if not any then out[#out + 1] = "  keine eigenen Ergebnisse" end
    -- 6d (Nachprüfung 10.11.): EINE Zeile, warum "Entzaubern gelernt" (Σ deStats.n) und der Verlauf (deLog) verschieden
    -- sind - nur melden, nichts angleichen
    do
        local learned = 0
        for _, st in pairs(db.deStats or {}) do learned = learned + (st.n or 0) end
        local logN, rej, firstT = 0, 0, nil
        for _, e in ipairs(db.deLog or {}) do
            if e.rejected then rej = rej + 1 else logN = logN + 1 end
            if e.t and (not firstT or e.t < firstT) then firstT = e.t end
        end
        local shared = 0
        for _, rec in pairs(db.deShared or {}) do
            if type(rec) == "table" then for _, x in pairs(rec.g or {}) do if type(x) == "table" and x.n then shared = shared + x.n end end end
        end
        out[#out + 1] = string.format("  Erklärung gelernt/Verlauf: gelernt %d (Summe deStats.n) · Verlauf %d (ohne %d abgelehnte) · Unterschied %d = Ergebnisse vor dem Verlauf (ab %s) bzw. Verlauf gekürzt; geteilte (%d) zählen nur in deShared",
            learned, logN, rej, learned - logN, firstT and date("%d.%m.", firstT) or "-", shared)
    end
    -- E4c (Anweisung Markt-Entzaubern): Ø-Dauer bis Verkauf je Material (Prognose-Journal, verkaufte Einstellungen)
    do
        local mats = {}
        for _, e in ipairs(db.deLog or {}) do for _, l in ipairs(e.loot or {}) do mats[l[1]] = true end end
        local Fc = A.Forecast
        local f = Fc and Fc:Data()
        local hrs = {}
        for _, str in ipairs(f and f.list or {}) do
            if str:sub(1, 1) == "P" then
                local e = Fc:Decode(str)
                if e and mats[e.id] and e.r == "s" and e.sh then
                    hrs[e.id] = hrs[e.id] or {}
                    table.insert(hrs[e.id], e.sh)
                end
            end
        end
        local parts = {}
        for id, list in pairs(hrs) do
            table.sort(list)
            local med = list[math.floor((#list + 1) / 2)]
            parts[#parts + 1] = string.format("%d: Median %.1f Std. (%d Verkäufe)", id, med, #list)
        end
        table.sort(parts)
        out[#out + 1] = "  Dauer bis Verkauf je Material: " .. (#parts > 0 and table.concat(parts, " · ") or "noch keine verkauften Materialien im Journal")
        -- D6e: Materialien mit Kennzeichen "Aufkauf" (Item-ID, Menge vorher/jetzt, Preis vorher/jetzt, seit) - Schwellen messen
        local bo = {}
        for id in pairs(mats) do
            local okB, b = pcall(A.BuyoutInfo, A, id)
            if okB and b then
                bo[#bo + 1] = string.format("%d: Menge %d -> %d, Preis %d -> %d (Marktwert %d), seit %s", id, b.q0 or 0, b.q1 or 0, b.p0 or 0, b.p1 or 0,
                    b.mv or 0, b.since and date("%d.%m. %H:%M", b.since) or "?")
            end
        end
        table.sort(bo)
        out[#out + 1] = "  Aufkauf erkannt (D6, Startwerte Menge -70 % in 6 Std., Preis +50 %): " .. (#bo > 0 and table.concat(bo, " · ") or "keiner")
    end
    -- E14 Zählkontrolle heute - W5 (Befund 10.11. 13:50): nur Verlauf-Einträge seit Beginn der Zählung (deCount.since);
    -- ohne Beginn (Zählung älter als 0.65.78) ist heute kein Vergleich möglich -> kein falscher Alarm
    local today = A:DayStart(time())
    local c = (db.deCount and db.deCount.day == today) and db.deCount or { counted = 0, missed = 0 }
    local from = c.since or today
    local logToday, rejToday, before = 0, 0, 0
    for _, e in ipairs(db.deLog or {}) do
        if (e.t or 0) >= today then
            if (e.t or 0) < from then before = before + 1
            elseif e.rejected then rejToday = rejToday + 1 else logToday = logToday + 1 end
        end
    end
    local okCount, note = true, ""
    if not db.deCount or db.deCount.day ~= today then
        okCount = logToday == 0
        if not okCount then note = " – FEHLER (ungleich)" end
    elseif not c.since then
        note = " – Vergleich ab morgen (Beginn der Zählung unbekannt)"
    else
        okCount = (c.counted or 0) == logToday
        if not okCount then note = " – FEHLER (ungleich)" end
    end
    if before > 0 then note = note .. string.format(" · %d Einträge vor Beginn der Zählung nicht verglichen", before) end
    out[#out + 1] = string.format("  Zählkontrolle heute: Verlauf %d · gezählt %d · verpasst %d · abgelehnt %d%s", logToday, c.counted or 0,
        c.missed or 0, rejToday, note)
    out[#out + 1] = "  Plausibilität: " .. (#plaus == 0 and "OK" or table.concat(plaus, "; "))
    return out, okCount, plaus
end

function TR:CompareAndRestore()
    local db = A.db
    local tr = db and db.testRoutine
    local b = tr and tr.backup
    if not b then return { "Sicherung fehlt" } end
    local cur = {}
    for k, v in pairs(db) do if not NO_COPY[k] then cur[k] = v end end
    local diffs = {}
    Diff(b, cur, {}, diffs, self)
    local paths = {}
    for _, segs in ipairs(diffs) do
        if segs[1] ~= "__missing" then
            table.insert(paths, PathText(segs))
            local orig = GetPath(b, segs)
            if #segs == 1 and type(db[segs[1]]) == "table" and type(orig) == "table" then
                Replace(db[segs[1]], Copy(orig))     -- Tabellen nicht tauschen: Module halten Verweise
            else
                SetPath(db, segs, Copy(orig))
            end
        end
    end
    -- Testdaten dürfen auch in den erlaubten Teilen nicht landen
    local fake = HasFakeIDs(db.marketData)
    if fake then table.insert(paths, "marketData.<Test-ID>"); db.marketData[fake] = nil end
    return paths
end

-- nach /reload oder Absturz mitten in der Routine: Sicherung zurückschreiben
function TR:RecoverAfterReload()
    local db = A.db
    local tr = db and db.testRoutine
    if not (tr and tr.backup) then return false end
    self.part = tr.part
    self.ownChar = OwnCharKey()
    for k, v in pairs(tr.backup) do
        if k ~= "__missing" and not NO_COPY[k] then
            if type(db[k]) == "table" and type(v) == "table" then Replace(db[k], v) else db[k] = v end
        end
    end
    for k in pairs(db) do
        if not NO_COPY[k] and tr.backup[k] == nil then db[k] = nil end
    end
    local fake = HasFakeIDs(db.marketData)
    while fake do db.marketData[fake] = nil; fake = HasFakeIDs(db.marketData) end
    db.testRoutine = nil
    return true
end

A:On("READY", function()
    if A.db and A.db.testRoutine then
        local ok = pcall(TR.RecoverAfterReload, TR)
        if ok then A:Print(L["Testroutine vom letzten Mal abgebrochen - deine echten Daten sind wiederhergestellt."]) end
    end
end)

-- ------------------------------------------------------------
-- Laufzeit-Zustand (nicht in den SavedVariables)
-- ------------------------------------------------------------
function TR:SaveRuntime()
    local Sn, W, B, Se, Td, S = A.Sniper, A.Watcher, A.Buy, A.Seller, A.Today, A.Sync
    self.rt = {
        forceForever = A.forceForever, print = A.Print,
        snInstantFailed = Sn and Sn.instantFailed, snPending = Sn and Sn.pending, snExtra = Sn and Sn.extra,
        hold = W and W.holdForScan, opps = W and Copy(W.opps),
        bDetail = B and B.detail, sePendingPost = Se and Se.pendingPost,
        todayState = Td and Copy(Td.state), todayExtra = Td and Copy(Td.extra),
        syncQueue = S and S.queue and #S.queue or 0,
        syncStatus = S and S.status, heard = S and S.heardScanTime,
        aahLegacy = A.AH_LEGACY,
    }
end

function TR:RestoreRuntime()
    local r = self.rt
    if not r then return {} end
    self.rt = nil
    local problems = {}
    local function part(name, fn)
        local ok, err = pcall(fn)
        if not ok then table.insert(problems, name .. ": " .. tostring(err)) end
    end
    part("Flags", function()
        A.forceForever = r.forceForever
        A.apiOverride, A.testCombat = nil, nil
        A.AH_LEGACY = r.aahLegacy
        if A.Extras then A.Extras.testMyName = nil end
        local g = G()
        if g and g.SetTestFlavor then g.SetTestFlavor(nil) end
        A.Print = r.print
    end)
    part("Sniper", function()
        local Sn = A.Sniper
        if not Sn then return end
        Sn.instantFailed, Sn.pending, Sn.extra = r.snInstantFailed, r.snPending, r.snExtra
        Sn.result = nil
    end)
    part("Wächter", function()
        local W = A.Watcher
        if not W then return end
        W.holdForScan = r.hold
        if type(W.opps) == "table" and type(r.opps) == "table" then Replace(W.opps, r.opps) end
    end)
    part("Einkauf/Verkaufen", function()
        if A.Buy then A.Buy.detail = r.bDetail end
        if A.Seller then A.Seller.pendingPost = r.sePendingPost end
    end)
    part("Heute tun", function()
        local Td = A.Today
        if not Td then return end
        if type(r.todayState) == "table" then Replace(Td.state, r.todayState) end
        if type(r.todayExtra) == "table" then Replace(Td.extra, r.todayExtra) end
    end)
    part("Sync", function()
        local S = A.Sync
        if not S then return end
        S.status, S.heardScanTime = r.syncStatus, r.heard
        if S.queue and #S.queue > r.syncQueue then for i = #S.queue, r.syncQueue + 1, -1 do table.remove(S.queue, i) end end
    end)
    part("Scan-Wunsch", function() if A.DropScanWish and A.scanWanted then A:DropScanWish(false) end end)
    return problems
end

-- ------------------------------------------------------------
-- Nachweis "nichts wirklich ausgeführt": Zähler über hooksecurefunc (taint-frei, nur während der Routine)
-- ------------------------------------------------------------
TR.real = {}
local function Hook(tbl, name, label, cond)
    if not hooksecurefunc then return end
    local target = tbl and tbl[name] or (not tbl and _G[name])
    if type(target) ~= "function" then return end
    local ok = pcall(function()
        local fn = function(...)
            if not TR.running then return end
            if cond and not cond(...) then return end
            TR.real[label] = (TR.real[label] or 0) + 1
        end
        if tbl then hooksecurefunc(tbl, name, fn) else hooksecurefunc(name, fn) end
    end)
    return ok
end
local function MerchantOpen() return MerchantFrame and MerchantFrame.IsShown and MerchantFrame:IsShown() end
local function SyncPrefix(prefix) return prefix == "AHAP1" end
function TR:InstallCounters()
    if self.countersInstalled then return end
    self.countersInstalled = true
    Hook(nil, "SendMail", "SendMail")
    Hook(nil, "TakeInboxMoney", "TakeInboxMoney")
    Hook(nil, "TakeInboxItem", "TakeInboxItem")
    Hook(nil, "LeaveChannelByName", "LeaveChannelByName")
    Hook(nil, "SetOverrideBindingClick", "SetOverrideBindingClick")
    if C_Container then Hook(C_Container, "UseContainerItem", "UseContainerItem", MerchantOpen)
    else Hook(nil, "UseContainerItem", "UseContainerItem", MerchantOpen) end
    if C_ChatInfo and C_ChatInfo.SendAddonMessage then Hook(C_ChatInfo, "SendAddonMessage", "SendAddonMessage", SyncPrefix)
    else Hook(nil, "SendAddonMessage", "SendAddonMessage", SyncPrefix) end
end

-- ------------------------------------------------------------
-- Ergebnisse (alle über GoldSentinelTest: T:Check / T:Skip / T:Client)
-- ------------------------------------------------------------
function TR:Row(status, id, area, name, detail)
    table.insert(self.rows, { group = tostring(area) .. " " .. tostring(id), name = name, status = status,
        detail = detail and A:PlainText(tostring(detail)) or "" })
    if ST and ST.window and ST.window:IsShown() then ST.window:Refresh() end
end

local function LastDetail(T, id)
    local e = T.results[#T.results]
    if not (e and e.id == id) then return "" end
    if e.lua then return "Lua: " .. e.lua end
    local d = e.ergebnis and ("ist: " .. e.ergebnis) or ""
    if e.erwartet then d = d .. " | soll: " .. e.erwartet end
    return d
end

-- Ehrliche Zählung (0.65.16): eine Prüfung, die im Client nicht möglich ist, gibt "SKIP", Grund zurück und zählt dann
-- als ÜBERSPRUNGEN statt als OK. Die Funktion läuft genau einmal; Lua-Fehler bleiben FEHLER.
-- TU8: je Bereich TU1–TU7 zählen (Name beginnt mit "TUn")
function TR:TUCount(name, kind)
    local tu = type(name) == "string" and name:match("^(TU%d)")
    if not tu then return end
    self.tuStats = self.tuStats or {}
    local st = self.tuStats[tu] or { ok = 0, fail = 0, skip = 0 }
    st[kind] = st[kind] + 1
    self.tuStats[tu] = st
end
function TR:Check(id, area, name, fn)
    local res = { pcall(fn) }
    if res[1] and res[2] == "SKIP" then return self:Skip(id, area, name, tostring(res[3] or "nicht prüfbar")) end
    local ok = self.T:Check(id, area, name, function()
        if not res[1] then error(res[2], 0) end
        return unpack(res, 2)
    end)
    self:Row(ok and "PASS" or "FAIL", id, area, name, LastDetail(self.T, id))
    self:TUCount(name, ok and "ok" or "fail")
    return ok
end
function TR:Skip(id, area, name, reason)
    self.T:Skip(id, area, name, reason)
    self:Row("SKIP", id, area, name, reason)
    self:TUCount(name, "skip")
end
function TR:Client(id, area, name, how)
    self.T:Client(id, area, name, how)
    self:Row("CLIENT", id, area, name, how)
end

-- Absichtlich erzeugte Fehler-Einträge wieder aus db.gsTest.errors entfernen (keine echten Fehler)
function TR:ClearTestErrors()
    local s = A.db and A.db.gsTest and A.db.gsTest.errors
    if type(s) ~= "table" then return end
    for k, e in pairs(s) do
        if type(k) == "string" and (k:find("AHS%-Test") or k:find("geschützter Testwert")) then s[k] = nil end
    end
end
local function ErrorEntry(where)
    local s = A.db and A.db.gsTest and A.db.gsTest.errors
    for k, e in pairs(s or {}) do
        if type(e) == "table" and e.wo == where and tostring(e.msg):find("AHS%-Test") then return e end
    end
    return nil
end

-- ------------------------------------------------------------
-- Ablauf
-- ------------------------------------------------------------
-- ------------------------------------------------------------
-- G2 Abdeckung (Gesamtprüfung): jeder T-Testfall der Anweisungen vom 9./10.11. und jeder offene Punkt ->
-- Prüfungen dieser Routine oder begründet "im Client prüfen". { Testfall, Quelle, { Prüfungen } [, Client-Grund] }
-- Prüfungen aus Teilen, die nur mit offenem Fenster laufen, stehen in PART_ONLY.
-- ------------------------------------------------------------
local COVERAGE = {
    { "T-PG1–5", "prognose-stufe1", { "T303" } }, { "T-PG6", "prognose-stufe1", { "T304" } }, { "T-PG7", "prognose-stufe1", { "T305" } },
    { "T-PG8", "prognose-stufe1", { "T306" } }, { "T-PG9", "prognose-stufe1", { "T307" } },
    { "T-VS1", "vollscan", { "T308" } }, { "T-VS2–4", "vollscan", { "T309" } }, { "T-VS5", "vollscan", { "T310" }, "M1d im Spiel: Schnell-Vollscan an, Bericht Abschnitt Vollscan" },
    { "T-VS6", "vollscan", { "T311" } }, { "T-VS7", "vollscan", { "T312" } },
    { "T-L1", "lernen-stufe2", { "T313" } }, { "T-L2", "lernen-stufe2", { "T314" } }, { "T-L3", "lernen-stufe2", { "T315" } },
    { "T-L4", "lernen-stufe2", { "T316" } }, { "T-L5", "lernen-stufe2", { "T317" } }, { "T-L6", "lernen-stufe2", { "T318" } },
    { "T-L7", "lernen-stufe2", { "T319" } }, { "T-L8", "lernen-stufe2", { "T320" } }, { "T-L9", "lernen-stufe2", { "T321" } },
    { "T-L10", "lernen-stufe2", { "T322" } }, { "T-L11", "lernen-stufe2", { "T323" } }, { "T-L12", "lernen-stufe2", { "T324" } },
    { "T-M1", "markt-stufe3", { "T326" } }, { "T-M2", "markt-stufe3", { "T327" } }, { "T-M3", "markt-stufe3", { "T328" } },
    { "T-M4", "markt-stufe3", { "T329" } }, { "T-M5", "markt-stufe3", { "T330" } }, { "T-M6", "markt-stufe3", { "T331" } },
    { "T-M7", "markt-stufe3", { "T332" }, "Lage nur im Client messbar" },
    { "T-G1", "gesamtpruefung", { "T333" } }, { "T-G2", "gesamtpruefung", { "T334" } }, { "T-G3", "gesamtpruefung", { "T335" } },
    { "T-G4", "gesamtpruefung", { "T336" } }, { "T-G5", "gesamtpruefung", { "T337", "T122" } }, { "T-G6", "gesamtpruefung", { "T338" }, "Bereich K in allen Kombinationen" },
    { "T-G7", "gesamtpruefung", { "T339" } },
    { "T-AS1", "ausruestung-silber", { "T340" }, "echte Messreihe: /ahs messreihe am offenen Auktionshaus (mit Zustimmung)" },
    { "T-AS2", "ausruestung-silber", { "T341" } }, { "T-AS3", "ausruestung-silber", { "T342", "T290" } },
    { "T-AB1–4", "angebot-und-absatz", { "T285" } },
    { "T-AB5", "angebot-und-absatz", {}, "Tooltip, Gewinn-Fenster, Beste Rezepte und API.BestWay zeigen im Spiel denselben besten Weg" },
    { "T-AB6", "angebot-und-absatz", { "T273" }, "Shift-Zeile im Tooltip ansehen" },
    { "T-AB9/T-AB12", "befund-absatz-zu-hoch", {}, "Entzauberwert der Braunen Leinenhose (Staub 76c, Essenz 92c) bleibt ~1s 19c - im Tooltip prüfen" },
    { "T-AB10", "befund-absatz-zu-hoch", { "T291" } }, { "T-AB11", "befund-absatz-zu-hoch", { "T291" } }, { "T-AB13", "befund-absatz-zu-hoch", { "T309" } },
    { "T-BL1", "befehlsliste", { "T288", "T565" } }, { "T-BL5", "offen-ahsentinel BL-A", { "T566" } }, { "T-BL6", "offen-ahsentinel BL-A", { "T567" } }, { "T-BL2", "befehlsliste", { "T288" } },
    { "T-BL3–6 (Befehlsliste)", "befehlsliste", { "T288" }, "Klick zählt +1, im Kampf keine Liste, Option aus - im Chat ausprobieren" },
    { "T-BL7 (Befehlsliste)", "befehlsliste", {}, "Bereich K: Liste ganz im Bild (/ahs tippen)" },
    { "T-DC1–5", "entzauber-chancen", { "T293" } },
    { "T-D1", "laufzeit-2-stunden", { "T292" } },
    { "T-D2–4", "laufzeit-2-stunden", { "T292" }, "von Hand 24 Std., nächstes Item wieder Standard; Era/TBC kürzeste Stufe - im Spiel" },
    { "T-D5a–c", "offen Punkt 1", { "T295" } },
    { "T-TE1/T-TE2", "testroutine-entzaubern", { "T301" } }, { "T-TE3", "testroutine-entzaubern", { "T336" } },
    { "T-GW1–3", "tooltip-gesamtwert", { "T283" } }, { "T-GW4", "tooltip-gesamtwert", { "T294" }, "Händler besser -> Gesamt = Händlerwert × Menge (Tooltip)" },
    { "T-GW5", "tooltip-gesamtwert", { "T294" } }, { "T-GW6", "tooltip-gesamtwert", {}, "Bereich K: lange Beträge enGB/deDE nicht abgeschnitten" },
    { "T-BM1–6", "befund-buchhaltung", { "T297" } },
    { "T-DZ1–3", "befund-entzaubern-zaehlen", { "T298" } }, { "T-DZ4", "befund-entzaubern-zaehlen", { "T300" } }, { "T-DZ5", "befund-entzaubern-zaehlen", { "T298" } },
    { "T-SK3/T-SK4", "befund-sofortkauf", { "T296" } },
    { "T-SK1/T-SK5", "befund-sofortkauf", { "T378" } }, { "T-SK2", "befund-sofortkauf", { "T379" } },
    { "T-SK6/T-SK7", "befund-sofortkauf", {}, "Zufalls-Suffix: genau ein zweiter Versuch, dann DETAIL-LEER (Nachbildung s73; im Spiel)" },
    { "H5", "befund-markt-heute-flip", { "T377" } },
    { "T-N1/T-N2 (0669)", "befund-testroutine-0669", { "T302" } }, { "T-N3 (0669)", "befund-testroutine-0669", { "T122" } },
    { "T-GF1/3/4/5", "befund-tooltip-gesamtwert-fehlt", { "T294" } }, { "T-GF2", "befund-tooltip-gesamtwert-fehlt", {}, "mit Blizzard-Taschen im Spiel" },
    { "T-SY1–3", "hinweis-sync-kanal", { "T272" } },
    { "offen 1", "offen-ahsentinel", { "T295" } }, { "offen 2", "offen-ahsentinel", { "T294" } }, { "offen 2b", "offen-ahsentinel", { "T296" } },
    { "offen 3", "offen-ahsentinel", { "T266" } }, { "offen 4 (G3/G5)", "offen-ahsentinel", { "T308", "T309" } }, { "offen 5", "offen-ahsentinel", { "T343" } },
    { "offen 6a T-O1–5", "offen-ahsentinel", {}, "Meine Auktionen: Stückpreis, Status gleich/unterboten, Kopfzeile - im Spiel ansehen" },
    { "offen 6b T-H1–4", "offen-ahsentinel", { "T292" }, "Heute/Markt: Händler-Tipp, Zeilen-Klick - im Spiel" },
    { "offen 6c", "offen-ahsentinel", { "T292", "T295" } }, { "offen 6d", "offen-ahsentinel", { "T285" }, "siehe T-AB5/T-AB12" },
    { "offen 6e", "offen-ahsentinel", { "T288" } }, { "offen 6f", "offen-ahsentinel", { "T294" } }, { "offen 6g", "offen-ahsentinel", { "T277" } },
    { "offen 7 R3/R6", "offen-ahsentinel", { "T122" }, "R3 Tooltip-Lage und T124 im Teil berufe" },
    { "offen 8", "offen-ahsentinel", {}, "Texte (Gebühr, Stapel-Knopf) im Spiel lesen" },
    { "offen 9", "offen-ahsentinel", { "T293" } }, { "offen 10", "offen-ahsentinel", {}, "Raid-Vorrat T145c im Spiel" },
    { "offen 11", "offen-ahsentinel", {}, "Hinweise ohne Muss" },
    { "T-HF1", "befund-markt-heute-flip", { "T344" } }, { "T-HF2", "befund-markt-heute-flip", { "T345" } },
    { "T-HF3", "befund-markt-heute-flip", { "T346" } }, { "T-HF4", "befund-markt-heute-flip", { "T347" } },
    { "T-HF5", "befund-markt-heute-flip", { "T348" } }, { "T-HF6", "befund-markt-heute-flip", { "T349" } },
    { "T-HF7", "befund-markt-heute-flip", { "T350" } },
    { "T-HF8", "befund-markt-heute-flip", { "T351", "T352", "T353" } },
    { "T-MS1", "anweisung-meine-auktionen-summe", { "T354" } }, { "T-MS2", "anweisung-meine-auktionen-summe", { "T355" } },
    { "T-MS3", "anweisung-meine-auktionen-summe", { "T356" } },
    { "T-SN1", "anweisung-sniper-anzeige", { "T357" } }, { "T-SN2", "anweisung-sniper-anzeige", { "T358" } },
    { "T-SN3", "anweisung-sniper-anzeige", { "T359" }, "Bereich K: Zielzeile im Sniper nicht abgeschnitten" },
    { "T-W1", "befund-testroutine-0676", { "T360" }, "Lauf: Sandbox OK (kein Pfad)" },
    { "T-W2", "befund-testroutine-0676", { "T361", "T362" } },
    { "T-W3", "befund-testroutine-0676", { "T169", "T373" } },
    { "T-W4", "befund-testroutine-0676", { "T310" }, "M1d im Bericht: längster Frame ≤ 8 ms" },
    { "T-W5", "befund-testroutine-0676", { "T363" } },
    { "T-LG1", "befund-buchhaltung-lager", { "T364" } }, { "T-LG2", "befund-buchhaltung-lager", { "T365" } },
    { "T-LG3", "befund-buchhaltung-lager", { "T366" } }, { "T-LG4", "befund-buchhaltung-lager", { "T367" } },
    { "T-LG5", "befund-buchhaltung-lager", { "T368" } },
    { "T-HF9", "befund-markt-heute-flip", { "T369" } }, { "T-HF10", "befund-markt-heute-flip", { "T370" } },
    { "T-HF11", "befund-markt-heute-flip", { "T371" }, "ersetzt durch T-AM1 (Entscheid aktueller Markt)" },
    { "T-AM1", "anweisung-aktueller-markt-entscheid", { "T371" } }, { "T-AM2", "anweisung-aktueller-markt-entscheid", { "T344" } },
    { "T-AM3", "anweisung-aktueller-markt-entscheid", { "T384" } }, { "T-AM4", "anweisung-aktueller-markt-entscheid", { "T385" } },
    { "T-K1", "anweisung-markt-kapital-25", { "T386" } }, { "T-K2", "anweisung-markt-kapital-25", { "T387" } },
    { "T-K3", "anweisung-markt-kapital-25", { "T388" } },
    { "T-LG6", "befund-buchhaltung-kopf", { "T389" } }, { "T-LG7", "befund-buchhaltung-kopf", { "T390" } },
    { "T-LG8", "befund-buchhaltung-kopf", { "T391" } },
    { "T-ME1", "anweisung-markt-entzaubern", { "T392" } }, { "T-ME2", "anweisung-markt-entzaubern", { "T393" } },
    { "T-ME3", "anweisung-markt-entzaubern", { "T394" } }, { "T-ME4", "anweisung-markt-entzaubern", { "T395" } },
    { "T-ME5", "anweisung-markt-entzaubern", { "T396" } }, { "T-ME6", "anweisung-markt-entzaubern", { "T397" } },
    { "T-ME7", "anweisung-markt-entzaubern", { "T398" } },
    { "T-SR1", "befund-sniper-reagiert-nicht", {}, "Suffix-Varianten: laut Nachtrag 16:35 nicht belegt (Kapuzen gefunden) - im Spiel beobachten" },
    { "T-SR2", "befund-sniper-reagiert-nicht", { "T399" } }, { "T-SR3", "befund-sniper-reagiert-nicht", { "T400" } },
    { "T-SR4", "befund-sniper-reagiert-nicht", { "T401" } }, { "T-SR5", "befund-sniper-reagiert-nicht", { "T402" } },
    { "T-SR6", "befund-sniper-reagiert-nicht", { "T409" } },
    { "T-F1", "befund-schein-flip-0683", { "T403" } }, { "T-F2", "befund-schein-flip-0683", { "T404" } },
    { "T-F3", "befund-schein-flip-0683", { "T405" } }, { "T-F4", "befund-schein-flip-0683", { "T406" } },
    { "T-ME8", "anweisung-markt-entzaubern", { "T407" } }, { "T-ME9", "anweisung-markt-entzaubern", { "T408" } },
    { "T-SP1", "befund-entzauber-sperrliste", { "T380" } }, { "T-SP2", "befund-entzauber-sperrliste", { "T381" } },
    { "T-SP3", "befund-entzauber-sperrliste", { "T382" } }, { "T-SP4", "befund-entzauber-sperrliste", { "T383" } },
    { "T-FC3000", "offen-ahsentinel Punkt 3 (Prognose im Hintergrund)", { "T372" } },
    { "T-0", "offen-ahsentinel Punkt 0 (Verkaufs-Meldung geschützt)", { "T80", "T414" } },
    { "T-UP1", "befund-unterbietung-prüfen-lag", { "T415" } }, { "T-UP2", "befund-unterbietung-prüfen-lag", { "T416" } },
    { "T-UP3", "befund-unterbietung-prüfen-lag", { "T417" } },
    { "T-VM1", "offen-ahsentinel Punkt 2 (Vollscan-Messung)", { "T410" } },
    { "T-VM2", "offen-ahsentinel Punkt 2 (Vollscan-Messung)", { "T411", "T412" } },
    { "T-X1", "befund-testroutine-0686", { "T413" } },
    { "T-X2a", "befund-testroutine-0686", { "T418" } }, { "T-X2b", "befund-testroutine-0686", { "T419" } },
    { "T-SR7a", "befund-sniper-reagiert-nicht", { "T420" } }, { "T-SR7b", "befund-sniper-reagiert-nicht", { "T421" } },
    { "T-SR7c", "befund-sniper-reagiert-nicht", { "T422" } },
    { "T-ME10", "offen-ahsentinel Punkt 3 (nicht entzauberbar)", { "T423" } },
    { "T-ME11", "offen-ahsentinel Punkt 3 (nicht entzauberbar)", { "T424" } },
    { "T-X3", "befund-testroutine-0686", { "T203" } }, { "T-X4a", "befund-testroutine-0686", { "T230" } },
    { "T-X4b", "befund-testroutine-0686", { "T425" } },
    { "T-X5", "befund-testroutine-0686", { "T373" }, "Grenze 16 ms im Spiel; Portion vorausschauend (Nachbildung s88)" },
    { "T-X6", "befund-testroutine-0686", { "T426" } }, { "T-X6b", "befund-testroutine-0686", {}, "Sniper an, Testroutine -> Sandbox OK (Nachbildung s88)" },
    { "T-X7a", "befund-testroutine-0686", { "T427" } }, { "T-X7b", "befund-testroutine-0686", { "T428" } },
    { "T-X7c", "befund-testroutine-0686", { "T429" } }, { "T-X8", "befund-testroutine-0686", { "T430" } },
    { "T-MD1", "befund-markt-entzaubern-menge", { "T431" } }, { "T-MD2", "befund-markt-entzaubern-menge", { "T432" } },
    { "T-MD3", "befund-markt-entzaubern-menge", { "T433" } }, { "T-MD4", "befund-markt-entzaubern-menge", { "T434" } },
    { "T-MD5", "befund-markt-entzaubern-menge", { "T435" } }, { "T-MD6a", "befund-markt-entzaubern-menge", { "T436", "T437" } },
    { "T-MD6b", "befund-markt-entzaubern-menge", { "T438" } },
    { "T-SR8a", "befund-sniper-reagiert-nicht", { "T439" } }, { "T-SR8b", "befund-sniper-reagiert-nicht", { "T440" } },
    { "T-BP1", "anweisung-buchhaltung-profi", { "T441" } }, { "T-BP2", "anweisung-buchhaltung-profi", { "T442" } },
    { "T-BP3", "anweisung-buchhaltung-profi", { "T443" } }, { "T-BP4", "anweisung-buchhaltung-profi", { "T444" } },
    { "T-BP5", "anweisung-buchhaltung-profi", { "T445" } }, { "T-BP6", "anweisung-buchhaltung-profi", { "T446" } },
    { "T-BP7", "anweisung-buchhaltung-profi", { "T447" } }, { "T-BP8", "anweisung-buchhaltung-profi", { "T448" } },
    { "T-BP9", "anweisung-buchhaltung-profi", { "T449" } },
    { "T-SG1", "anweisung-sniper-signal", { "T450" } }, { "T-SG2", "anweisung-sniper-signal", { "T451" } },
    { "T-SG3", "anweisung-sniper-signal", { "T452" } }, { "T-SG4", "anweisung-sniper-signal", { "T453" } },
    { "T-ZM1", "anweisung-sync-zusammenfuehren", { "T454" } }, { "T-ZM2", "anweisung-sync-zusammenfuehren", { "T455" } },
    { "T-ZM3", "anweisung-sync-zusammenfuehren", { "T456" } }, { "T-ZM4", "anweisung-sync-zusammenfuehren", { "T457" } },
    { "T-VF1", "befund-grosser-test-0688", { "T458" } }, { "T-VF2", "befund-grosser-test-0688", { "T459" } },
    { "T-VF3", "befund-grosser-test-0688", { "T52", "T460" } },
    { "T-VF4", "befund-grosser-test-0688", { "T410" }, "Bilder/s je Schritt im Abschnitt Vollscan-Messung; Ruckeln spürt nur der Spieler" },
    { "T-VF5a", "befund-grosser-test-0688", { "T461" } }, { "T-VF5b", "befund-grosser-test-0688", { "T462" } },
    { "T-BE1", "anweisung-buchhaltung-ehrlich", { "T463" } }, { "T-BE2", "anweisung-buchhaltung-ehrlich", { "T464" } },
    { "T-BE3", "anweisung-buchhaltung-ehrlich", { "T465" } }, { "T-BE4", "anweisung-buchhaltung-ehrlich", { "T466" } },
    { "T-LB1", "anweisung-lohnt-bis-ueberall", { "T467", "T248" } }, { "T-LB2", "anweisung-lohnt-bis-ueberall", { "T468" } },
    { "T-LB3", "anweisung-lohnt-bis-ueberall", { "T469" } }, { "T-LB4", "anweisung-lohnt-bis-ueberall", { "T470" } },
    { "T-MP1", "befund-materialpreise-alt", { "T471", "T506" } }, { "T-MP2", "befund-materialpreise-alt", { "T469", "T472" } },
    { "T-MP3", "befund-materialpreise-alt", { "T473" } },
    { "T-VF5c", "befund-grosser-test-0688", { "T474" } }, { "T-VF5d", "befund-grosser-test-0688", { "T475" } },
    { "T-ZM5", "anweisung-sync-zusammenfuehren", { "T476" } },
    { "T-JK1", "anweisung-jetzt-kaufen-verkaufen", { "T477" } }, { "T-JK2", "anweisung-jetzt-kaufen-verkaufen", { "T478" } },
    { "T-JK3", "anweisung-jetzt-kaufen-verkaufen", { "T479" } }, { "T-JK4", "anweisung-jetzt-kaufen-verkaufen", { "T480" } },
    { "T-JK5", "anweisung-jetzt-kaufen-verkaufen", { "T481" } }, { "T-JK1b", "anweisung-jetzt-kaufen-verkaufen", { "T483" } },
    { "T-AB8a", "befund-bilder-2205", { "T484" } }, { "T-AB8b", "befund-bilder-2205", { "T485" } }, { "T-AB8b1", "offen-ahsentinel AB8b", { "T491", "T492" } },
    { "T-AB1b", "offen-ahsentinel AB1", { "T493" } }, { "T-AB1c", "offen-ahsentinel AB1", { "T494" } }, { "T-AB1d", "offen-ahsentinel AB1", { "T495" } },
    { "T-VF5e", "offen-ahsentinel L1b", { "T496" } }, { "T-VF5f", "offen-ahsentinel L1c", { "T502" } }, { "T-MP2b", "offen-ahsentinel TR", { "T503" } }, { "T-PD1a", "befund-pc-daten-0694", { "T497" } }, { "T-PD1b", "befund-pc-daten-0694", { "T498" } },
    { "T-PD5a", "befund-pc-daten-0694", { "T499" } }, { "T-PD5c", "offen-ahsentinel PD5c", { "T504" } }, { "T-PD7a", "befund-pc-daten-0694", { "T505" } }, { "T-AB8c", "offen-ahsentinel AB8c", { "T507" } }, { "T-AB4b", "offen-ahsentinel AB4b", { "T508" } }, { "T-AB4c-a", "offen-ahsentinel AB4c", { "T509" } }, { "T-AB4c-b", "offen-ahsentinel AB4c", { "T510" } }, { "T-SM1", "offen-ahsentinel SM", { "T511" } }, { "T-SM2", "offen-ahsentinel SM", { "T512" } }, { "T-MV1", "offen-ahsentinel MV1", { "T513" } },
    { "T-TU1", "anweisung-tests-umfassend", { "T514", "T515", "T516", "T517", "T518", "T519", "T520", "T521", "T522", "T523", "T524" } },
    { "T-TU2", "anweisung-tests-umfassend", { "T525", "T526", "T487", "T493", "T494", "T495", "T510", "T511" } },
    { "T-TU3", "anweisung-tests-umfassend", { "T527" } }, { "T-TU4", "anweisung-tests-umfassend", { "T528", "T529" } },
    { "T-AB4", "befund-bilder-2205", { "T489" } }, { "T-AB8", "befund-bilder-2205", { "T484", "T485" } }, { "T-L1b", "offen-ahsentinel L1b", { "T496" } },
    { "T-L1c", "offen-ahsentinel L1c", { "T502" } }, { "T-JK", "anweisung-jetzt-kaufen-verkaufen", { "T477", "T478", "T479", "T480", "T481", "T482" } },
    { "T-LB", "anweisung-lohnt-bis-ueberall", { "T467", "T468", "T469", "T470" } }, { "T-VF5", "befund-grosser-test-0688", { "T474", "T475", "T496", "T502" } },
    { "T-SM1b", "anweisung-tests-umfassend TU2", { "T526" } }, { "T-HP1", "offen-ahsentinel HP", { "T530" } }, { "T-HP2", "offen-ahsentinel HP", { "T531" } },
    { "T-API-PM", "offen-ahsentinel API-PM", { "T532" } },
    { "T-ST1", "anweisung-strategie-entzaubern-grenzen", { "T533", "T536" } }, { "T-ST2", "anweisung-strategie-entzaubern-grenzen", { "T534" } },
    { "T-ST3", "anweisung-strategie-entzaubern-grenzen", { "T535" } },
    { "T-CH1", "offen-ahsentinel CH", { "T537" } }, { "T-CH2", "offen-ahsentinel CH", { "T538" } }, { "T-CH3", "offen-ahsentinel CH", { "T539" } },
    { "T-CH4", "offen-ahsentinel CH", { "T540" } }, { "T-CH5", "offen-ahsentinel CH", { "T541" } },
    { "T-AB4d", "offen-ahsentinel AB4d", { "T542", "T543", "T544", "T545" } }, { "T-WS1", "offen-ahsentinel WS", { "T546" } }, { "T-WS2", "offen-ahsentinel WS", { "T547" } },
    { "T-WS3", "offen-ahsentinel WS", { "T548" } },
    { "T-MA2", "anweisung-markt-reiter", { "T550", "T551" } }, { "T-MA1", "anweisung-markt-reiter", { "T552" } }, { "T-MA3", "anweisung-markt-reiter", { "T553", "T530" } },
    { "T-Ü1", "anweisung-markt-reiter", { "T555" } }, { "T-Ü2", "anweisung-markt-reiter", { "T555" } }, { "T-Ü3", "anweisung-markt-reiter", { "T554" } }, { "T-RK2a", "offen-ahsentinel RK2-A", { "T556" } }, { "T-RK2b", "offen-ahsentinel RK2-A", { "T557" } }, { "T-Ü3b", "anweisung-markt-reiter", { "T558" } }, { "T-API-PM2", "offen-ahsentinel API-PM2", { "T568" } }, { "T-TU5", "anweisung-tests-umfassend", { "T570" } }, { "T-TU7", "anweisung-tests-umfassend", { "T571" } }, { "T-BP-1113-1", "offen-ahsentinel BP-2026-11-13-1", { "T572" } }, { "T-MA1b", "offen-ahsentinel MA1-B", { "T573" } }, { "T-MA1c", "offen-ahsentinel MA1-B", { "T574" } }, { "T-MA2c", "offen-ahsentinel MA2-B", { "T575" } }, { "T-FG1", "offen-ahsentinel FG", { "T576" } }, { "T-RK2c", "offen-ahsentinel RK2-B", { "T579" } }, { "T-FG2", "offen-ahsentinel FG", { "T577" } }, { "T-FG3", "offen-ahsentinel FG", { "T578" } }, { "T-API-PM3", "offen-ahsentinel API-PM3", { "T569" } }, { "T-SB1", "offen-ahsentinel SB", { "T559" } }, { "T-SB2", "offen-ahsentinel SB", { "T560" } }, { "T-SB3", "offen-ahsentinel SB", { "T561" } }, { "T-SB4", "offen-ahsentinel SB", { "T562" } }, { "T-SB5", "offen-ahsentinel SB", { "T563" } }, { "T-SB6", "offen-ahsentinel SB", { "T564" } }, { "T-WS4", "offen-ahsentinel WS", { "T548" } }, { "T-WS5", "offen-ahsentinel WS", { "T549" } }, { "T-WS6", "offen-ahsentinel WS", { "T549" } }, { "T-PD2", "befund-pc-daten-0694", { "T501" } }, { "T-PD5b", "befund-pc-daten-0694", { "T500" } }, { "T-AB7", "befund-bilder-2205", { "T486" } },
    { "T-AB2", "befund-bilder-2205", { "T487" } }, { "T-AB1", "befund-bilder-2205", { "T488" } }, { "T-AB4", "befund-bilder-2205", { "T489" } },
    { "T-AB5", "befund-bilder-2205", { "T490" } }, { "T-JK6", "anweisung-jetzt-kaufen-verkaufen", { "T482" } },
}
TR.COVERAGE = COVERAGE
-- Prüfungen, die nur in einem Fenster-Teil laufen (server/berufe/haendler/k)
local PART_ONLY = { T122 = "k", T124 = "berufe", T359 = "k", T410 = "server", T411 = "server", T458 = "server", T459 = "server" }

-- Rückgabe: Zeilen "Testfall (Quelle) -> Prüfungen: Ergebnis", Anzahl ohne Abdeckung
function TR:CoverageLines()
    local status = {}
    for _, r in ipairs(self.rows or {}) do
        local id = tostring(r.group):match("(T[%w%.]+)$")
        if id then status[id] = r.status end
    end
    local out, missing = {}, 0
    for _, c in ipairs(COVERAGE) do
        local parts = {}
        for _, id in ipairs(c[3]) do parts[#parts + 1] = id .. " " .. (status[id] or (PART_ONLY[id] and ("Teil " .. PART_ONLY[id])) or "?") end
        local res
        if #c[3] == 0 and not c[4] then res = "FEHLT"; missing = missing + 1
        elseif #c[3] == 0 then res = "im Client prüfen: " .. c[4]
        else
            res = table.concat(parts, ", ")
            if c[4] then res = res .. " · im Client: " .. c[4] end
        end
        out[#out + 1] = string.format("  %s (%s) -> %s", c[1], c[2], res)
    end
    return out, missing
end

-- G7: Zusammenfassung für den Nutzer (5 Zeilen)
function TR:SummaryLines()
    local c = self.T and self.T.counts or {}
    local fehler = c.fehler or 0
    local todo = {}
    for _, r in ipairs(self.rows or {}) do
        local what = tostring(r.detail or ""):match("^HALB: (.+)$")
        if r.status == "SKIP" and what then todo[what] = true end
    end
    local list = {}
    for k in pairs(todo) do list[#list + 1] = k end
    table.sort(list)
    local Fc, VS = A.Forecast, A.FullScan
    local hit = "zu wenig Daten"
    if Fc then
        local ok, R = pcall(Fc.Eval, Fc)
        if ok and R and R.all.n >= 10 then hit = string.format("%d %% (N %d)", math.floor(R.all.hit / R.all.n * 100 + 0.5), R.all.n)
        elseif ok and R then hit = string.format("zu wenig Daten (%d)", R.all.n) end
    end
    local measured = 0
    local st = VS and VS:Data()
    for id in pairs(st and st.sold or {}) do if VS:MeasuredRate(id) then measured = measured + 1 end end
    local size = 0
    for _, k in ipairs({ "forecast", "forecastStats", "forecastHours", "fullScan", "learn" }) do
        if A.db and A.db[k] and A.Learn and A.Learn.SizeOf then size = size + A.Learn.SizeOf(A.db[k]) end
    end
    return {
        "ZUSAMMENFASSUNG: " .. (fehler == 0 and "OK" or (fehler .. " FEHLER")) .. string.format(" (%d OK, %d übersprungen, %d im Client)", c.ok or 0, c.uebersprungen or 0, c.client or 0),
        "Im Spiel noch tun: " .. (#list > 0 and table.concat(list, " · ") or "nichts für diesen Teil"),
        "Prognose-Trefferquote: " .. hit,
        string.format("Gemessener Absatz verfügbar für %d Items", measured),
        string.format("Speicher Prognose/Vollscan/Lernen: %d KB", math.ceil(size / 1024)),
    }
end

-- G1: "/ahs testroutine alles" - nach dem automatischen Teil die Fenster-Teile nacheinander
TR.CHAIN = { "server", "berufe", "haendler" }
TR.CHAIN_WAIT = 120
function TR:ChainReady(part)
    if part == "server" then return A:IsAHOpen() end
    if part == "berufe" then return A.Crafting and A.Crafting.kind ~= nil end
    if part == "haendler" then
        local f = A:Global("MerchantFrame")
        return f and f.IsShown and f:IsShown() or false
    end
    return true
end
function TR:ChainNeed(part)
    local what = ({ server = L["das Auktionshaus"], berufe = L["ein Berufsfenster"], haendler = L["einen Händler"] })[part] or part
    return string.format(L["Testroutine alles: als Nächstes Teil %s - bitte %s öffnen (ich warte bis 2 Minuten)."], part, what)
end
function TR:ChainNext()
    local chain = self.chain
    if not chain or #chain == 0 then self.chain = nil; return end
    local part = chain[1]
    local waited = 0
    local function try()
        if self.running then return end
        if self:ChainReady(part) then
            table.remove(chain, 1)
            self.chainCont = true
            self:Start(part)
            self.chainCont = nil
            return
        end
        if waited == 0 then A:Print(self:ChainNeed(part)) end
        waited = waited + 2
        if waited > self.CHAIN_WAIT then
            A:Print(string.format(L["Testroutine alles: Teil %s übersprungen (Fenster nicht offen)."], part))
            table.remove(chain, 1)
            return self:ChainNext()
        end
        C_Timer.After(2, try)
    end
    C_Timer.After(1, try)
end

TR.PARTS = { auto = true, a = true, b = true, c = true, d = true, e = true, f = true, g = true, h = true, i = true, j = true, k = true, p = true, v = true, l = true, m = true, z = true, alles = true,
    server = true, haendler = true, berufe = true, post = true, gildenbank = true, kampf = true }

function TR:Step(fn) table.insert(self.steps, fn) end

function TR:Start(part)
    if not A:RequireDev() then return false end
    part = (part == nil or part == "") and "auto" or tostring(part):lower()
    part = ({ ["händler"] = "haendler", haendler = "haendler", merchant = "haendler", professions = "berufe",
        mail = "post", guildbank = "gildenbank", combat = "kampf", prognose = "p", forecast = "p", vollscan = "v", fullscan = "v", lernen = "l", learn = "l", markt = "m", market = "m", gesamt = "z", all = "alles" })[part] or part
    if part == "alles" then
        part = "auto"
        self.chain = {}
        for _, x in ipairs(self.CHAIN) do self.chain[#self.chain + 1] = x end
    elseif not self.chainCont then
        self.chain = nil
    end
    if not self.PARTS[part] then
        A:Print(string.format(L["Unbekannter Teil der Testroutine: %s (a-k, server, haendler, berufe, post, gildenbank, kampf; /ahs spieltest)"], part))
        return false
    end
    if self.running or (ST and ST.running) then A:Print(L["Selbsttest läuft schon ..."]); return false end
    if TM and TM.active then A:Print(L["Erst den Testmodus beenden."]); return false end
    if not A.db then return false end
    if A:InCombat() then A:Print(L["Im Kampf kann die Testroutine nicht starten."]); return false end
    local GT = GTest()
    if not (GT and GT.Begin) then A:Print(L["GoldSentinelTest.lua fehlt - Testroutine nicht möglich."]); return false end

    self.part = part
    self.rows = {}
    self.tuStats, self.defaults, self.stLines = {}, nil, nil
    self.real = {}
    self.T = GT.Begin("AHSentinel", A.version, A.db)
    self.memBefore = collectgarbage("count")
    self.money0 = GetMoney and GetMoney() or 0
    self:InstallCounters()
    -- T242: Blizzard-Globale beim Start merken (nach den Zählern: hooksecurefunc legt eine sichere Hülle an);
    -- danach müssen sie gleich und gleich sicher sein
    self.startGlobals, self.startSecure = {}, {}
    for _, n in ipairs({ "TakeInboxMoney", "MailFrame", "IsInGuild", "ProfessionsFrame" }) do
        self.startGlobals[n] = _G[n]
        if issecurevariable then self.startSecure[n] = (issecurevariable(n)) end
    end
    -- X6 (Nachtrag 17:30): einen laufenden echten Sniper-Treffer VOR der Sicherung beenden - er zählt dann in die echten
    -- Tageszahlen und nicht später während der Routine (Sandbox meldete sonst "sniper.stats.missed").
    -- Ausschalten selbst erst nach der Sicherung, damit die Wiederherstellung "an" zurückschreibt.
    if A.Sniper and A.Sniper.episode and A.Sniper.MeterEnd then pcall(A.Sniper.MeterEnd, A.Sniper, "abgebrochen") end
    self:Backup()
    self:SaveRuntime()
    ST:SaveState()
    -- Schutz für die GANZE Routine: Handels-Proxy, Sperren der Kauf-Knöpfe, Test-Briefkasten, A:Simulated()
    ST:Lock()
    TM:InstallInbox()
    self.running = true
    self.wasArmed = A.Sniper and A.Sniper:IsArmed()
    if self.wasArmed then A.Sniper:SetArmed(false) end
    if A.Watcher and A.Watcher:IsEnabled() then A.Watcher:SetEnabled(false) end

    self.steps, self.pos, self.wait = {}, 0, nil
    self:BuildSteps(part)
    ST.results = self.rows
    if ST.ShowWindow then ST:ShowWindow() end
    A:Print(string.format(L["Testroutine gestartet (%s) - Kaufen, Einstellen, Post, Händler und Preis-Sync sind solange nur simuliert."], part))
    self:Next()
    return true
end

function TR:Next()
    local t0 = Ms()
    while self.running do
        if Ms() - t0 > SLICE_MS then
            C_Timer.After(0, function() if TR.running and not TR.wait then TR:Next() end end)
            return
        end
        self.pos = self.pos + 1
        local s = self.steps[self.pos]
        if not s then return self:Finish() end
        local ok, status, waitFn, timeout, checkFn = pcall(s, self)
        if not ok then
            self:Check("T000", "-", "Ablauf der Routine", function() error(status, 0) end)
        elseif status == "WAIT" then
            self.wait = { fn = waitFn, untilT = GetTime() + (timeout or 30), check = checkFn }
            return
        end
    end
end

function TR:Poll()
    local w = self.wait
    if not w then return end
    local okW, done = pcall(w.fn)
    if (okW and done) or not okW or GetTime() > w.untilT then
        self.wait = nil
        local timedOut = not (okW and done)
        local ok, err = pcall(w.check, timedOut, not okW and done or nil)
        if not ok then self:Check("T000", "-", "Ablauf der Routine (Warten)", function() error(err, 0) end) end
        return self:Next()
    end
end

-- Kampf begonnen: abbrechen, alles zurück
function TR:Abort(reason)
    if not self.running then return end
    self.wait = nil
    if reason == "Kampf begonnen" then self:Skip("T95", "C", "Routine und Kampf", reason)
    else self:Skip("T000", "-", "Abbruch", reason) end
    self.steps = {}
    self:Finish(true)
end

-- Nutzer bricht ab (/ahs testroutine stop, Knopf "Abbrechen"): wie beim Kampf alles zurück, Bericht mit T000 "Abbruch"
function TR:Stop()
    if not self.running then A:Print(L["Die Testroutine läuft nicht."]); return false end
    self:Abort("vom Nutzer abgebrochen")
    A:Print(L["Testroutine abgebrochen. Deine Daten sind wiederhergestellt."])
    return true
end

function TR:Finish(aborted)
    if not self.running then return end
    self.wait = nil
    local T = self.T
    if not aborted then
        -- Testfall-IDs eindeutig (jede ID genau einmal im Bericht)
        self:Check("T174", "I", "Testfall-IDs eindeutig", function()
            local seen, dup = {}, {}
            for _, r in ipairs(self.rows) do
                local id = tostring(r.group):match("(%S+)$")
                if id and id ~= "T000" then
                    if seen[id] then dup[#dup + 1] = id end
                    seen[id] = true
                end
            end
            return #dup == 0, #dup == 0 and "keine doppelten IDs" or ("doppelt: " .. table.concat(dup, ", ")), "jede ID einmal"
        end)
    end
    -- G2 Abdeckung (Gesamtprüfung): jeder Auftrag hat eine Prüfung oder ist begründet "im Client prüfen"
    if not aborted and (self.part == "auto" or self.part == "z") then
        self:Check("T334", "Z", "T-G2 Abdeckung aller Aufträge (Liste im Bericht)", function()
            local _, missing = self:CoverageLines()
            return missing == 0, string.format("%d Aufträge, ohne Abdeckung %d", #self.COVERAGE, missing), "ohne Abdeckung 0"
        end)
        self:Check("T339", "Z", "T-G7 Zusammenfassung in 5 Zeilen oben im Bericht", function()
            local lines = self:SummaryLines()
            return #lines == 5 and lines[1]:find("ZUSAMMENFASSUNG", 1, true) ~= nil, tostring(#lines) .. " Zeilen", "5 Zeilen"
        end)
    end
    -- Nachweis "nichts wirklich ausgeführt" (2.5)
    if not aborted then
        self:Check("T157", "I", "Nichts wirklich ausgeführt (Gold, Post, Händler, Sync, Kanal)", function()
            local parts, bad = {}, 0
            for k, n in pairs(self.real) do
                if k ~= "SetOverrideBindingClick" then parts[#parts + 1] = k .. "=" .. n; bad = bad + n end
            end
            local m = GetMoney and GetMoney() or 0
            if m < self.money0 then parts[#parts + 1] = "Gold weniger"; bad = bad + 1 end
            return bad == 0, string.format("%d Befehle nur protokolliert, echte Aktionen: %s", ST.tradeLog and #ST.tradeLog or 0,
                #parts > 0 and table.concat(parts, ", ") or "0"), "0"
        end)
    end
    self.running = false
    -- Schutz und Zustand zurück
    local problems = {}
    local function part(name, fn)
        local ok, err = pcall(fn)
        if not ok then table.insert(problems, name .. ": " .. tostring(err)) end
    end
    part("Schutz", function() ST:Unlock() end)
    part("Briefkasten", function() TM:RemoveInbox(); wipe(TM.fakeMail); wipe(TM.fakeOwned); TM.mailMoney = 0 end)
    for _, p in ipairs(self:RestoreRuntime()) do table.insert(problems, p) end
    part("Zustand", function() ST:RestoreState() end)
    part("Sniper", function() if self.wasArmed and A.Sniper and not A.Sniper:IsArmed() then A.Sniper:SetArmed(true) end end)
    self:ClearTestErrors()
    -- Schutz der Entzauber-Daten: Fingerabdruck vorher (Sicherung) gegen jetzt, VOR dem Zurückschreiben
    local deBefore = DEPrint(A.db and A.db.testRoutine and A.db.testRoutine.backup)
    local deNow = DEPrint(A.db)
    local paths = self:CompareAndRestore()
    local again = #paths > 0 and self:CompareAndRestore() or {}
    if A.db then A.db.testRoutine = nil end
    if #problems > 0 then A:ReportError("Test:Wiederherstellen", table.concat(problems, "; ")) end
    local sandbox = "OK"
    if #paths > 0 then
        sandbox = string.format("FEHLER: %d Pfade, wiederhergestellt%s: %s", #paths, #again > 0 and " (nicht vollständig)" or "",
            table.concat(paths, ", ", 1, math.min(#paths, 12)))
    end
    collectgarbage("collect")
    local memKB = math.floor(collectgarbage("count") - (self.memBefore or 0))
    -- ehrliche Zählung: was nicht automatisch geprüft wurde, steht ausdrücklich im Bericht
    local notAuto, clientList = 0, {}
    for _, r in ipairs(self.rows) do
        if r.status == "SKIP" or r.status == "CLIENT" then notAuto = notAuto + 1 end
        if r.status == "CLIENT" then clientList[#clientList + 1] = r.group .. " " .. r.name end
    end
    local okR0, deLines, deCountOK, dePlaus = pcall(self.DEReport, self)
    -- Ersatztabellen der Tests sicher weg (falls ein Test abbrach)
    if A.Forecast then A.Forecast.testStore, A.Forecast.evalCache = nil, nil end
    if A.FullScan then A.FullScan.testDB = nil end
    if A.Learn then A.Learn.testDB, A.Learn.forceOff, A.Learn.itemCache = nil, nil, nil end
    -- Prognose-Güte (Stufe 1 P6 Teil B): echte Daten, nur lesen
    local okF, fcLines, fcFields = false, nil, nil
    if A.Forecast then okF, fcLines, fcFields = pcall(A.Forecast.Report, A.Forecast) end
    self.sandbox = sandbox
    local finish = { sandbox = sandbox, teil = self.part, speicher_kb = tostring(memKB),
        nicht_automatisiert = tostring(notAuto),
        -- im GSTEST1-Export (ohne Namen): Schutz der Entzauber-Daten, Zählkontrolle, Plausibilität
        entzauber_schutz = (deBefore == deNow) and "OK" or "FEHLER",
        entzauber_stand = okR0 and deLines and table.concat(deLines, " | "):sub(1, 900) or "-",
        entzauber_zaehlung = okR0 and (deCountOK and "OK" or "ungleich") or "-",
        entzauber_plausibel = okR0 and (#(dePlaus or {}) == 0 and "OK" or tostring(#dePlaus) .. " auffällig") or "-" }
    if okF and type(fcFields) == "table" then for k, v in pairs(fcFields) do finish[k] = v end
    else finish.prognose_faelle = okF and "-" or ("FEHLER " .. tostring(fcLines)):sub(1, 200) end
    -- Vollscan (V6 Teil B): echte Daten, nur lesen
    local okV, vsLines, vsFields = false, nil, nil
    if A.FullScan then okV, vsLines, vsFields = pcall(A.FullScan.Report, A.FullScan) end
    if okV and type(vsFields) == "table" then for k, v in pairs(vsFields) do finish[k] = v end
    else finish.vollscan_m1d = okV and "-" or ("FEHLER " .. tostring(vsLines)):sub(1, 200) end
    -- Lern-Datenbank (Stufe 2 Teil B): echte Daten, nur lesen
    local okLn, lnLines, lnFields = false, nil, nil
    if A.Learn then okLn, lnLines, lnFields = pcall(A.Learn.Report, A.Learn) end
    if okLn and type(lnFields) == "table" then for k, v in pairs(lnFields) do finish[k] = v end
    else finish.lernen_faelle = okLn and "-" or ("FEHLER " .. tostring(lnLines)):sub(1, 200) end
    -- Markt-Reiter (Stufe 3 Teil B): Zeilen je Ansicht aus echten Daten, Index
    local okMk, mkLines, mkFields = false, nil, nil
    if A.MarketView and A.MarketView.Report then okMk, mkLines, mkFields = pcall(A.MarketView.Report, A.MarketView) end
    if okMk and type(mkFields) == "table" then for k, v in pairs(mkFields) do finish[k] = v end
    else finish.markt_zeilen = okMk and "-" or ("FEHLER " .. tostring(mkLines)):sub(1, 200) end
    -- Buchhaltung neu (BP1–BP7): echte Daten, nur lesen; B1 Verzögerung, VERKAUF-MELDUNG geschützt/lesbar
    local okBk, bkLines, bkFields = false, nil, nil
    if A.Books then okBk, bkLines, bkFields = pcall(A.Books.Report, A.Books) end
    if okBk and type(bkFields) == "table" then for k, v in pairs(bkFields) do finish[k] = v end end
    -- Zeitpunkt (JK1–JK4): Rhythmus-Speicher und Trefferquote je Signal-Art, nur lesen
    local okTm, tmLines, tmFields = false, nil, nil
    if A.Timing then okTm, tmLines, tmFields = pcall(A.Timing.Report, A.Timing) end
    if okTm and type(tmFields) == "table" then for k, v in pairs(tmFields) do finish[k] = v end end
    local text = T:Finish(finish)
    text = text .. "\n" .. string.format("Nicht automatisiert: %d (übersprungen oder im Client prüfen)", notAuto)
    if #clientList > 0 then text = text .. "\nIm Client prüfen:\n  " .. table.concat(clientList, "\n  ") end
    -- N4 (Nachprüfung 0.65.69): in EINER Zeile, was der Spieler für die übersprungenen Teile tun muss
    local todo, seenTodo = {}, {}
    for _, r in ipairs(self.rows) do
        local d = tostring(r.detail or "")
        local what = d:match("^HALB: (.+)$")
        if r.status == "SKIP" and what and not seenTodo[what] then seenTodo[what] = true; todo[#todo + 1] = what end
    end
    if #todo > 0 then text = text .. "\nNoch zu tun für die übersprungenen Teile: " .. table.concat(todo, " · ") end
    text = text .. "\n" .. string.format("Sprache: %s · Addon-Sprache: %s · Auktionshaus: %s",
        tostring(GetLocale and GetLocale()), tostring(A.uiLang), A.AH_LEGACY and "klassisch" or "modern")
    if #problems > 0 then text = text .. "\nWiederherstellen: " .. table.concat(problems, "; ") end
    -- Entzauber-Daten unverändert? (Pflicht, Entscheid des Nutzers)
    text = text .. "\n" .. (deBefore == deNow and ("Entzauber-Daten unverändert: " .. deNow)
        or ("Entzauber-Daten: FEHLER – vorher " .. deBefore .. " · nachher " .. deNow .. " (wiederhergestellt)"))
    if okR0 and deLines then text = text .. "\n" .. table.concat(deLines, "\n") end
    if okF and fcLines then text = text .. "\n" .. table.concat(fcLines, "\n") end
    if okV and vsLines then text = text .. "\n" .. table.concat(vsLines, "\n") end
    if okLn and lnLines then text = text .. "\n" .. table.concat(lnLines, "\n") end
    if okMk and mkLines then text = text .. "\n" .. table.concat(mkLines, "\n") end
    if okBk and bkLines then text = text .. "\n" .. table.concat(bkLines, "\n") end
    if okTm and tmLines then text = text .. "\n" .. table.concat(tmLines, "\n") end
    -- Ü1: Abschnitt MARKT-KERN (nur lesen)
    if A.Core then
        local okC2, mkLines2 = pcall(A.Core.Report, A.Core)
        if okC2 and mkLines2 then text = text .. "\n" .. table.concat(mkLines2, "\n") end
    end
    -- TU8: je Bereich eine Zeile; TU3 Standardwerte; TU6 Regressionen n von m
    do
        local tl = { "Umfassende Tests (TU):" }
        for _, k in ipairs({ "TU1", "TU2", "TU3", "TU4", "TU5", "TU6", "TU7" }) do
            local st = self.tuStats and self.tuStats[k]
            if st then tl[#tl + 1] = string.format("  %s OK %d · FEHLER %d · SKIP %d", k, st.ok, st.fail, st.skip) end
            if k == "TU5" then
                local lr = A.Core and A.Core.lastReal
                if lr then tl[#tl + 1] = string.format("  TU5 echte Daten (%s): %d Items geprüft · Verletzungen %d%s", date("%d.%m. %H:%M", lr.t), lr.n, lr.bad, lr.first and (" – " .. lr.first) or "")
                else tl[#tl + 1] = "  TU5 SKIP – echte Daten: noch nicht gelaufen (\"/ahs testroutine echt\" oder nach dem nächsten Vollscan)" end
            elseif st or k == "TU6" then -- schon oben bzw. unten
            elseif k == "TU7" then tl[#tl + 1] = "  TU7 SKIP – Markt-Kern (RK) noch nicht umgesetzt"
            else tl[#tl + 1] = string.format("  %s SKIP – in diesem Teil nicht gelaufen", k) end
        end
        if self.REGRESSIONS then
            local have, miss = 0, {}
            for _, rid in ipairs(self.REGRESSIONS) do
                local found = false
                for _, c in ipairs(COVERAGE) do
                    local n = c[1]
                    if n == "T-" .. rid or n:sub(1, #rid + 3) == "T-" .. rid .. "-" or n:match("^T%-" .. rid:gsub("%-", "%%-") .. "[%da-z]") then found = true; break end
                end
                if found then have = have + 1 else miss[#miss + 1] = rid end
            end
            tl[#tl + 1] = string.format("  TU6 Regressionen: %d von %d vorhanden%s", have, #self.REGRESSIONS, #miss > 0 and (" (fehlt: " .. table.concat(miss, ", ") .. ")") or "")
        end
        for _, d in ipairs(self.defaults or {}) do tl[#tl + 1] = "  TU3 Standard: " .. d end
        for _, d in ipairs(self.stLines or {}) do tl[#tl + 1] = "  ST1 Entzauber-Grenze " .. d end
        text = text .. "\n" .. table.concat(tl, "\n")
    end
    if A.SilverTest then
        local okS, sLines = pcall(A.SilverTest.Report, A.SilverTest)
        if okS and sLines then text = text .. "\n" .. table.concat(sLines, "\n") end
    end
    if self.part == "auto" or self.part == "z" then
        local okC, cov = pcall(self.CoverageLines, self)
        if okC and cov then text = text .. "\nAbdeckung (Auftrag -> Prüfungen -> Ergebnis):\n" .. table.concat(cov, "\n") end
    end
    local okSum, sum = pcall(self.SummaryLines, self)
    if okSum and sum then text = table.concat(sum, "\n") .. "\n\n" .. text end
    self.lastText = text
    local c = T.counts
    self.lastSummary = string.format(L["Testroutine fertig: %d OK, %d FEHLER, %d übersprungen, %d im Client prüfen."],
        c.ok, c.fehler, c.uebersprungen, c.client)
    self.notAutomated = notAuto
    A:Print((c.fehler == 0 and "|cff33dd55" or "|cffff5544") .. self.lastSummary .. "|r")
    A:Print(L["Bericht gespeichert – wird beim nächsten /reload oder Ausloggen an die Prüfung gemeldet."])
    A:Print(L["Bitte jetzt /reload."])
    if A.UI and A.UI.ShowTextWindow then pcall(A.UI.ShowTextWindow, A.UI, L["Testbericht"], text) end
    if ST.window then ST.window:Refresh() end
    -- G1: "/ahs testroutine alles" - nächster Teil
    if not aborted and self.chain and #self.chain > 0 then self:ChainNext() end
end

function TR:ReportText()
    return self.lastText or L["Noch kein Selbsttest gelaufen."]
end

local frame = CreateFrame("Frame")
TR.frame = frame
pcall(frame.RegisterEvent, frame, "PLAYER_REGEN_DISABLED")
frame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_REGEN_DISABLED" and TR.running then
        TR:Abort("Kampf begonnen")
        A:Print(L["Testroutine abgebrochen: Kampf begonnen. Deine Daten sind wiederhergestellt."])
    end
end)
local acc = 0
frame:SetScript("OnUpdate", function(_, dt)
    if not TR.running then return end
    acc = acc + (dt or 0)
    if acc < 0.25 then return end
    acc = 0
    TR:Poll()
end)

-- ============================================================
-- Testfälle
-- ============================================================
local function want(part, area)
    return part == "auto" or part == area
end

-- bisherige Selbsttest-Schritte über GoldSentinelTest laufen lassen (Adapter, testroutine 2.2)
local OLD_IDS = {
    ["Grundlagen/Einstellgebühr WoW Forever"] = { "T16", "B" },
    ["Scan/Markt-Scan"] = { "T20", "B" }, ["Scan/Marktdaten plausibel"] = { "T21", "B" },
    ["Oberfläche/Preisverlauf-Fenster"] = { "T26a", "B" }, ["Oberfläche/Optionen, Hilfe, Einkaufslisten"] = { "T26b", "B" },
    ["Oberfläche/Sprachwechsel (alle Sprachen, mehrfach)"] = { "T112", "F" },
    ["Auswertungen/Suche nach Namen"] = { "T15", "B" }, ["Auswertungen/Verkaufbarkeit"] = { "T14", "B" },
    ["Auswertungen/Heute tun"] = { "T72", "B" }, ["Auswertungen/Tooltip"] = { "T73", "B" },
    ["Auswertungen/Vermögen"] = { "T60", "B" },
    ["Server/Einkauf: Kategorie-Suche"] = { "T32", "B" }, ["Server/Einkauf: Angebote eines Items"] = { "T33", "B" },
    ["Server/Verkaufen: Preisprüfung"] = { "T48", "B" }, ["Server/Sniper: Suche (kauft nichts)"] = { "T40", "B" },
    ["Server/Wächter: eine Runde (kauft nichts)"] = { "T45", "B" }, ["Server/Eigene Auktionen"] = { "T51", "B" },
    ["Handel (simuliert)/Sofortkauf"] = { "T35", "B" }, ["Handel (simuliert)/Gebot"] = { "T36", "B" },
    ["Handel (simuliert)/Sniper-Kauf"] = { "T41", "B" }, ["Handel (simuliert)/Einstellen"] = { "T49", "B" },
    ["Handel (simuliert)/Abbrechen"] = { "T51b", "B" },
}
local TAB_LETTERS = "abcdefghijklmnop"

function TR:AddOldSteps(savedMode)
    ST.savedMode = savedMode
    local old = ST:Steps()
    local tabN = 0
    for idx, s in ipairs(old) do
        local key = s.group .. "/" .. s.name
        local map = OLD_IDS[key]
        local id, area
        if map then id, area = map[1], map[2]
        elseif s.group == "Oberfläche" and s.name:find("^Reiter") then
            tabN = tabN + 1
            id, area = "T25" .. TAB_LETTERS:sub(tabN, tabN), "B"
        else
            id, area = string.format("S%02d", idx), "B"
        end
        local name = s.group .. ": " .. s.name
        if s.name ~= "Übersetzungen" then        -- konnte nie fehlschlagen, ersetzt durch T113
            local function adapt(status, detail, expect)
                if status == "SKIP" then return self:Skip(id, area, name, detail or "") end
                return self:Check(id, area, name, function()
                    return status ~= "FAIL", detail ~= "" and detail or nil, status == "FAIL" and "bestanden" or nil
                end)
            end
            self:Step(function()
                if ST.ctx and ST.ctx.abort then return self:Skip(id, area, name, "früherer Schritt hat den alten Selbsttest beendet") end
                local ok, status, detail, waitFn, timeout, checkFn = pcall(s.run)
                if not ok then return self:Check(id, area, name, function() error(status, 0) end) end
                if status == "WAIT" then
                    return "WAIT", waitFn, timeout, function(timedOut, werr)
                        if timedOut then
                            -- Befund 22:25 2c: bei Zeitüberschreitung den Grund ausgeben (Suchen, Einkauf, Sniper, Wächter)
                            return self:Check(id, area, name, function()
                                return false, werr and tostring(werr) or ("Zeitüberschreitung nach " .. tostring(timeout) .. " s · " .. self:WaitDiag()),
                                    "Antwort in " .. tostring(timeout) .. " s"
                            end)
                        end
                        local ok2, st2, d2 = pcall(checkFn)
                        if not ok2 then return self:Check(id, area, name, function() error(st2, 0) end) end
                        return adapt(st2 or "PASS", d2)
                    end
                end
                return adapt(status or "PASS", detail)
            end)
        end
    end
end

-- HALB-Fälle mit offenem Auktionshaus (Teil "server"). Alles mit Folgen landet nur im Protokoll (ST.tradeLog).
-- Zustand beim Warten (für Zeitüberschreitungen): Suchen der letzten Minute, Einkauf, Sniper, Wächter
function TR:WaitDiag()
    local parts = {}
    local ok, n = pcall(A.QueriesLastMinute, A)
    parts[#parts + 1] = "Suchen/Min. " .. tostring(ok and n or "?")
    local B = A.Buy
    if B then
        parts[#parts + 1] = string.format("Einkauf loading = %s, Warteschlange = %s, Suche = %s", tostring(B.detail and B.detail.loading),
            tostring(B.wanted ~= nil), tostring(B.search ~= nil))
    end
    local Sn, W = A.Sniper, A.Watcher
    if Sn then parts[#parts + 1] = "Sniper " .. ((Sn.IsArmed and Sn:IsArmed()) and "AN" or "aus") .. ((Sn.IsBusy and Sn:IsBusy()) and " (sucht)" or "") end
    if W then parts[#parts + 1] = "Wächter " .. ((W.IsEnabled and W:IsEnabled()) and "AN" or "aus") end
    return table.concat(parts, ", ")
end

-- T410/T411 (T-VM1/T-VM2): Auswertung einer Vollscan-Messung - auch für die Nachbildung mit erfundener Messung
function TR:VMCheck(m, timedOut)
    local VS = A.FullScan
    local need = { "Warten auf Server", "Ereignis-Aufruf", "Einlesen", "Verdichtung", "Preisverlauf+Neuaufbau" }
    self:Check("T410", "H", "T-VM1 Vollscan-Messung: alle Schritte mit ms und längste Lücke", function()
        if not m then return false, timedOut and "keine Antwort des Servers (Zeit abgelaufen)" or "keine Messung", "Messung da" end
        local miss = {}
        for _, n in ipairs(need) do if not (m.steps and m.steps[n]) then miss[#miss + 1] = n end end
        local lines = VS:MeasureLines(m)
        local txt = table.concat(lines, " ")
        local ok = #miss == 0 and m.gapMax ~= nil and txt:find("längste Lücke", 1, true) ~= nil
        return ok, string.format("%d Schritte, längste Lücke %.0f ms (%s)%s", #(m.order or {}), m.gapMax or 0, tostring(m.gapStep or "-"),
            #miss > 0 and (" · fehlt: " .. table.concat(miss, ", ")) or ""), "alle 5 Schritte mit ms und Lücke"
    end)
    self:Check("T411", "H", "T-VM2 Vollscan: kein Schritt und keine Lücke über 1 s", function()
        if not m then return "SKIP", "keine Messung" end
        local bad = VS:MProblems(m)
        return #bad == 0, #bad > 0 and ("Hänger: " .. table.concat(bad, " | ")) or string.format("längste Lücke %.0f ms", m.gapMax or 0),
            "jeder Schritt und jede Lücke <= 1000 ms"
    end)
    -- VF1 (Befund grosser Test 0.65.88): ruckelfrei - kein Schritt mit längstem Frame über 16 ms (Ziel: Budget, Standard 4 ms)
    self:Check("T458", "H", "T-VF1 Vollscan ruckelfrei: kein Schritt mit längstem Frame über 16 ms (Ziel ≤ Budget)", function()
        if not m then return "SKIP", "keine Messung" end
        local bad, worst, worstName = {}, 0, "-"
        for _, name in ipairs(m.order or {}) do
            local st = m.steps[name]
            if st and name ~= "Warten auf Server" then
                if st.max > worst then worst, worstName = st.max, name end
                if st.max > 16 then bad[#bad + 1] = string.format("%s %.0f ms", name, st.max) end
            end
        end
        return #bad == 0, string.format("längster Frame %.0f ms (%s) · Frames über 33 ms %d von %d%s", worst, worstName, m.slow33 or 0, m.ticks or 0,
            #bad > 0 and (" · zu lang: " .. table.concat(bad, ", ")) or ""), "jeder Schritt ≤ 16 ms (Ziel " .. VS:FrameBudget() .. " ms)"
    end)
    self:Check("T459", "H", "T-VF2 Vollscan: Speicher-Zuwachs ≤ 10 MB, höchstens 1 Speicherbereinigung", function()
        if not m then return "SKIP", "keine Messung" end
        local grow = (m.addonBefore and m.addonAfter) and (m.addonAfter - m.addonBefore) or ((m.memAfter or 0) - (m.memBefore or 0))
        local ok = grow <= 10240 and (m.gcN or 0) <= 1
        return ok, string.format("Zuwachs %.0f KB (%s) · Speicherbereinigungen %d", grow, m.addonBefore and "AHSentinel" or "ganzer Lua-Speicher", m.gcN or 0),
            "≤ 10240 KB · ≤ 1"
    end)
end

function TR:AddServerSteps()
    local B = function(fn) self:Step(fn) end
    local Chk = function(...) return self:Check(...) end
    local Skp = function(...) return self:Skip(...) end
    local function TradeCount(fn)
        local n = 0
        for _, e in ipairs(ST.tradeLog or {}) do if e.fn == fn then n = n + 1 end end
        return n
    end
    local modern = not A.AH_LEGACY

    B(function()
        if not (A.UI.CanIntegrate and A.UI:CanIntegrate()) then
            -- R8 (Nachtrag 07:55): den wahren Grund nennen (Option aus, kein Rahmen, AH zu)
            local why
            if A.db and A.db.settings.ahIntegration == false then why = "Einbindung in den Optionen aus"
            elseif not A:IsAHOpen() then why = "Auktionshaus zu"
            else why = "Einbindung nicht möglich (kein AH-Rahmen: AuctionHouseFrame/AuctionFrame fehlt)" end
            return Skp("T27", "B", "Einbindung ins Auktionshaus", why)
        end
        Chk("T27", "B", "Einbindung ins Auktionshaus", function()
            local UI, st = A.UI, A.db.settings
            local was = st.ahIntegration
            local res = { pcall(function()
                Capture(function() UI:SetIntegration(true) end)
                local host = UI.ahHost ~= nil
                Capture(function() UI:ShowInAH() end)
                Capture(function() UI:LeaveAH() end)
                Capture(function() UI:SetIntegration(false) end)
                Capture(SlashCmdList.AHANALYZERPRO, "ah")
                Capture(SlashCmdList.AHANALYZERPRO, "ahdebug")
                return host and UI.ahLastError == nil, string.format("Rahmen %s, Fehler %s", tostring(host), tostring(UI.ahLastError))
            end) }
            Capture(function() UI:SetIntegration(was and true or false) end)
            st.ahIntegration = was
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "Rahmen da, kein ahLastError"
        end)
    end)

    B(function()
        if not modern then return Skp("T37", "B", "Warenkauf simuliert", "keine Waren im alten AH") end
        Chk("T37", "B", "Warenkauf simuliert", function()
            local Bu = A.Buy
            local saved = { detail = Bu.detail, pending = Bu.pending, last = Bu.lastPurchase, conf = Bu.confirming }
            local money = GetMoney and GetMoney() or 0
            local s0, c0 = TradeCount("StartCommoditiesPurchase"), TradeCount("ConfirmCommoditiesPurchase")
            local res = { pcall(function()
                Bu.pending = nil
                Bu.detail = { itemID = LINEN, commodity = true, qty = 1, listings = { { qty = 5, price = 100 } } }
                -- echte Funktionen (die Routine sperrt Kaufen); der Server-Befehl landet über den Schutz-Proxy nur im Protokoll
                local okS = ST:RealFn("Buy", "StartCommodity")(Bu)
                A:SimulateAHEvent("COMMODITY_PRICE_UPDATED", 100, 100)
                local ready = Bu.pending and Bu.pending.state == "ready"
                local okC = ST:RealFn("Buy", "ConfirmCommodity")(Bu)
                return okS and ready and okC and TradeCount("StartCommoditiesPurchase") == s0 + 1
                    and TradeCount("ConfirmCommoditiesPurchase") == c0 + 1 and (GetMoney and GetMoney() or 0) == money,
                    string.format("Start %s, Preis da %s, Bestätigt %s (nur Protokoll)", tostring(okS), tostring(ready), tostring(okC))
            end) }
            Bu.detail, Bu.pending, Bu.lastPurchase, Bu.confirming = saved.detail, saved.pending, saved.last, saved.conf
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "Start und Bestätigen nur im Protokoll, Gold gleich"
        end)
    end)

    -- T42: Sniper scharf, ein paar Sekunden laufen lassen - nie ein Bestätigen ohne Klick
    B(function()
        local Sn = A.Sniper
        self.t42 = { targets = Copy(A.db.sniper.targets), c0 = TradeCount("ConfirmCommoditiesPurchase"),
            b0 = TradeCount("PlaceBid"), s0 = TradeCount("StartCommoditiesPurchase"), until_ = GetTime() + 8 }
        local mv = A:GetMarketValue(LINEN) or 10000
        Capture(function()
            Sn:SetTarget(tostring(LINEN), math.floor(mv * 2), 1, math.floor(mv * 4))
            Sn:SetArmed(true)
        end)
        return "WAIT", function() return GetTime() >= self.t42.until_ end, 12, function()
            local t = self.t42
            self.t42 = nil
            local starts = TradeCount("StartCommoditiesPurchase")
            Capture(function()
                Sn:SetArmed(false)
                if Sn.CancelPending then Sn:CancelPending() end
            end)
            A.db.sniper.targets = t.targets
            Chk("T42", "B", "Sniper-Vorab-Reservierung kauft nie ohne Klick", function()
                local c, b = TradeCount("ConfirmCommoditiesPurchase") - t.c0, TradeCount("PlaceBid") - t.b0
                -- WoW Forever blockt StartCommoditiesPurchase ohne Tastendruck: dort darf der Sniper gar nicht vorab reservieren
                local auto = starts - (t.s0 or 0)
                local foreverOK = not A:IsForever() or auto == 0
                return c == 0 and b == 0 and foreverOK, string.format("Bestätigen %d, Kauf/Gebot %d, Vorab-Reservierungen %d", c, b, auto),
                    A:IsForever() and "0, 0, 0 (Forever)" or "0, 0"
            end)
        end
    end)

    -- T50: Serie einstellen (Befehle nur im Protokoll)
    B(function()
        local Se = A.Seller
        self.t50 = { batch = Se.batch }
        local ok, msg = Capture(function() return Se:StartBatch() end)
        if not Se.batch then
            Se.batch = self.t50.batch
            self.t50 = nil
            return Chk("T50", "B", "Serie einstellen", function()
                return true, "keine Items mit gemerktem Preis - Start lehnt sauber ab", "ohne Fehler"
            end)
        end
        return "WAIT", function()
            local e = Se:BatchCurrent()
            local pr = e and Se.prices[e.itemID]
            return not e or (pr and pr.time >= Se.batch.started)
        end, 15, function()
            local posts = TradeCount("PostItem") + TradeCount("PostCommodity")
            for _ = 1, 2 do Capture(function() Se:BatchStep() end) end
            Capture(function() Se:StopBatch() end)
            Se.pendingPost = nil
            self.t50 = nil
            Chk("T50", "B", "Serie einstellen", function()
                local n = TradeCount("PostItem") + TradeCount("PostCommodity") - posts
                return Se.batch == nil, string.format("%d Einstell-Befehle nur im Protokoll, Serie beendet", n), "Serie danach nil"
            end)
        end
    end)

    -- T52: fiktive zu teure eigene Auktion -> unterboten; Abbrechen nur im Protokoll
    B(function()
        local Se = A.Seller
        if not ST.fakeOwned then return Skp("T52", "B", "Unterboten", "kein Schutz-Proxy für eigene Auktionen") end
        local mv = A:GetMarketValue(LINEN) or 100
        local fake = ST.FakeAuction(LINEN, 1, math.floor(mv * 1.5))
        table.insert(ST.fakeOwned, fake)
        self.t52 = { fake = fake, c0 = TradeCount("CancelAuction") }
        Capture(function() Se:QueryOwned() end)
        return "WAIT", function()
            for _, o in ipairs(Se.owned or {}) do if o.auctionID == fake.auctionID then return true end end
        end, 10, function()
            Capture(function() Se:CheckUndercuts() end)
        end
    end)
    B(function()
        local Se = A.Seller
        if not self.t52 then return end
        return "WAIT", function()
            local pr = Se.prices[LINEN]
            return pr and Se:IsPriceFresh(LINEN)
        end, 15, function(timedOut)
            local t = self.t52
            self.t52 = nil
            local o
            for _, x in ipairs(Se.owned or {}) do if x.auctionID == t.fake.auctionID then o = x end end
            Se:UpdateOwnedStatus()
            -- VF2: nur die Test-Auktion ansprechen (sonst traf der Aufruf eine ECHTE unterbotene Auktion des Spielers)
            local _, okC, msgC = Capture(function() return Se:CancelNextUndercut(t.fake.auctionID) end)
            t.cancelMsg = tostring(msgC)
            ST.RemoveFake(ST.fakeOwned, t.fake.auctionID)
            Se.pendingCancel = nil
            Capture(function() Se:QueryOwned() end)
            -- R7 (Nachtrag 07:55): seit H1 (Abbrechen nur, wenn es sich lohnt) ist "liegen" eine richtige Antwort. Erwartung
            -- aus Se:CancelWorth für genau diese Auktion; dazu zwei feste Fälle (a) grosser Abstand -> unterboten,
            -- (b) 1c Abstand bei 1s Einzahlung -> liegen. Nicht abgeschwächt: Status UND Anzahl Abbrechen-Befehle.
            Chk("T52", "B", "Unterboten", function()
                local pr = Se.prices[LINEN]
                local status = o and o.status
                -- Sicherheitsregel: Während der Testroutine sperrt der Selbsttest jedes Abbrechen schon VOR dem Schutz-Proxy
                -- (Meldung "Selbsttest läuft ..."). Gezählt wird darum der Abbrechen-VERSUCH: unterboten -> genau 1 Versuch,
                -- der an der Sperre endet; liegen -> 0 Versuche ("Keine unterbotenen Auktionen"). Echte Befehle immer 0.
                local lock = L["Selbsttest läuft - Kaufen und Einstellen sind gesperrt."]
                local tried = (t.cancelMsg == lock or TradeCount("CancelAuction") - t.c0 == 1) and 1 or 0
                local cancels = tried
                local expect, expCancels = "günstigstes", 0
                if pr and pr.lowestOther and o and pr.lowestOther < o.unitPrice then
                    local okW, worth = pcall(Se.CancelWorth, Se, o, pr.lowestOther)
                    if okW and worth == false then expect = "liegen" else expect, expCancels = "unterboten", 1 end
                elseif pr and pr.lowestOther and o and pr.lowestOther == o.unitPrice then
                    expect = "gleich"
                end
                -- feste Fälle (eigene Funktionen als Seam: 1 Einstellung erwartet, Einzahlung 1s)
                local saved = { el = A.ExpectedListings, ld = A.ListingDeposit }
                A.ExpectedListings = function() return 1 end
                A.ListingDeposit = function() return 100 end
                local okA, a = pcall(Se.CancelWorth, Se, { itemID = FAKE_ID, unitPrice = 100000, qty = 1 }, 50000)
                local okB, b = pcall(Se.CancelWorth, Se, { itemID = FAKE_ID, unitPrice = 101, qty = 1 }, 100)
                A.ExpectedListings, A.ListingDeposit = saved.el, saved.ld
                local fixed = okA and a == true and okB and b == false
                return o ~= nil and status == expect and cancels == expCancels and fixed,
                    string.format("Status %s, Abbrechen-Versuche %d (%s) · fest: 10g gegen 5g %s, 1c Abstand %s", tostring(status),
                        cancels, A:PlainText(t.cancelMsg or "-"), okA and (a and "unterboten" or "liegen") or "Fehler", okB and (b and "unterboten" or "liegen") or "Fehler"),
                    string.format("%s, %d Befehl(e) · fest: unterboten, liegen", expect, expCancels)
            end)
        end
    end)

    B(function()
        local m = A.jobMeasure
        A.jobMeasure = nil
        if not (m and m.frames and m.frames > 0) then
            return Skp("T126", "H", "Scan-Auswertung in Portionen", "keine Hintergrund-Arbeit gemessen (kein Scan im Teil server)")
        end
        Chk("T126", "H", "Scan-Auswertung in Portionen", function()
            return m.max <= (A.FRAME_BUDGET or 6) + 2, string.format("längste Portion %.1f ms in %d Frames", m.max, m.frames),
                "<= " .. ((A.FRAME_BUDGET or 6) + 2) .. " ms"
        end)
    end)

    -- VM1–VM3 (offen 10.11., Entscheid des Nutzers: vor dem grossen Test): echten Schnell-Vollscan auslösen (nur lesen) und
    -- je Schritt messen. Am Vollscan selbst ändert sich nichts; die Messung steht im Bericht (Abschnitt Vollscan-Messung).
    B(function()
        local VS = A.FullScan
        local why
        if not VS then why = "kein Vollscan-Modul"
        elseif not VS:Available() then why = "Schnell-Vollscan gibt es in diesem Client nicht (altes Auktionshaus)"
        elseif VS.running then why = "es läuft schon ein Scan"
        elseif (VS:Wait() or 0) > 0 then why = string.format("Server-Abstand: erst in %d Min. wieder (Messung beim nächsten Lauf)", math.ceil(VS:Wait() / 60)) end
        if why then
            Skp("T410", "H", "T-VM1 Vollscan-Messung: alle Schritte mit ms und längste Lücke", why)
            Skp("T458", "H", "T-VF1 Vollscan ruckelfrei: kein Schritt mit längstem Frame über 16 ms (Ziel ≤ Budget)", why)
            Skp("T459", "H", "T-VF2 Vollscan: Speicher-Zuwachs ≤ 10 MB, höchstens 1 Speicherbereinigung", why)
            return Skp("T411", "H", "T-VM2 Vollscan: kein Schritt und keine Lücke über 1 s", why)
        end
        A:Print(L["Testroutine: Schnell-Vollscan wird gemessen (nur lesen) - das Spiel kann kurz hängen."])
        VS.lastMeasure = nil
        -- während der Routine liefert VS:Store() nichts (A:Simulated): der echte Vollscan schreibt bewusst in die echte
        -- Tabelle (echte Daten, Sandbox erlaubt "fullScan"), damit Verfolgung V4 so lange dauert wie im Alltag
        VS.testDB = VS:Real()
        local okS, started = pcall(VS.Start, VS, true)
        if not (okS and started) then
            VS.testDB = nil
            Skp("T410", "H", "T-VM1 Vollscan-Messung: alle Schritte mit ms und längste Lücke", "Vollscan ließ sich nicht starten")
            Skp("T458", "H", "T-VF1 Vollscan ruckelfrei: kein Schritt mit längstem Frame über 16 ms (Ziel ≤ Budget)", "Vollscan ließ sich nicht starten")
            Skp("T459", "H", "T-VF2 Vollscan: Speicher-Zuwachs ≤ 10 MB, höchstens 1 Speicherbereinigung", "Vollscan ließ sich nicht starten")
            return Skp("T411", "H", "T-VM2 Vollscan: kein Schritt und keine Lücke über 1 s", "Vollscan ließ sich nicht starten")
        end
        local m0 = VS.running and VS.running.m
        return "WAIT", function()
            return VS.running == nil and (m0 == nil or m0.final)
        end, 120 + (VS.MEASURE_TAIL or 3), function(timedOut)
            local m = m0 or VS.lastMeasure
            if m and not m.final and m.ended then VS:MFinal(m) end
            VS.testDB = nil
            self:VMCheck(m, timedOut)
        end
    end)

    B(function()
        if not A.AH_LEGACY then return Skp("T98", "D", "Server-Wege altes AH", "nur im alten Client (Classic Era, TBC)") end
        Chk("T98", "D", "Server-Wege altes AH", function()
            local n = TradeCount("PlaceBid") + TradeCount("PostAuction") + TradeCount("PostItem")
            return true, string.format("Scan, Suchen und Handel siehe bisheriger Selbsttest oben; %d Handels-Befehle nur im Protokoll", n),
                "wie 0.64.2"
        end)
    end)
end

function TR:BuildSteps(part)
    local B = function(fn) self:Step(fn) end
    local Chk = function(...) return self:Check(...) end
    local Skp = function(...) return self:Skip(...) end
    local Cli = function(...) return self:Client(...) end
    local g = G()
    local modern = not A.AH_LEGACY

    -- ---------------- A. Laden und Erkennung ----------------
    if want(part, "a") then B(function()
        Chk("T01", "A", "alle Module geladen", function()
            local miss = {}
            for _, k in ipairs({ "Sniper", "Watcher", "Buy", "Seller", "Ledger", "Lists", "Watchlist", "Crafting", "Disenchant",
                "Chars", "Mailer", "Extras", "Comfort", "Today", "Sync", "Names", "Tooltip", "UI", "SelfTest", "TestMode",
                "Inbox", "AH", "TestRoutine" }) do
                if A[k] == nil then miss[#miss + 1] = k end
            end
            for _, l in ipairs({ "frFR", "esES", "esMX", "ptBR", "itIT", "ruRU", "koKR", "zhCN", "zhTW", "enUS" }) do
                if type(A.T[l]) ~= "table" then miss[#miss + 1] = "Locale " .. l end
            end
            if A.Names and A.Names.HasBuiltin then
                for _, l in ipairs({ "enUS", "deDE", "frFR", "esES", "esMX", "ptBR", "ruRU", "koKR", "zhCN", "zhTW" }) do
                    if not A.Names:HasBuiltin(l) then miss[#miss + 1] = "Names " .. l end
                end
            end
            return #miss == 0, #miss == 0 and "alle da" or table.concat(miss, ", "), "keine fehlen"
        end)
        Chk("T02", "A", "Version .toc = Code", function()
            local get = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
            local v = get and get("AHSentinel", "Version")
            return v == A.version, tostring(v), A.version
        end)
        Chk("T03", "A", "Addon nicht veraltet", function()
            local info = (C_AddOns and C_AddOns.GetAddOnInfo) or GetAddOnInfo
            local iface = GetBuildInfo and select(4, GetBuildInfo())
            if not info then return "SKIP", "Client ohne GetAddOnInfo (Interface " .. tostring(iface) .. ")" end
            local _, _, _, loadable, reason = info("AHSentinel")
            return reason ~= "INTERFACE_VERSION", "Interface " .. tostring(iface) .. ", Grund " .. tostring(reason), "kein INTERFACE_VERSION"
        end)
        Chk("T04", "A", "gemeinsame Dateien", function()
            local D, T = _G.GoldSentinelDev, GTest()
            local bad = {}
            if not (g and g.version and g.version >= 2 and g.apiVersion) then bad[#bad + 1] = "GoldSentinelGame" end
            if g and type(g.Status) == "function" and type(g.Status()) ~= "string" then bad[#bad + 1] = "Status" end
            if g and g.IsForever and not g.IsModern then bad[#bad + 1] = "Forever nicht modern" end
            if not (D and (D.version or 0) >= 1) then bad[#bad + 1] = "GoldSentinelDev" end
            if not (T and T.version >= 1 and T.registry and T.registry["AHSentinel"]) then bad[#bad + 1] = "GoldSentinelTest/TrackErrors" end
            return #bad == 0, #bad == 0 and (g and g.Status() or "") or table.concat(bad, ", "), "alles erfüllt"
        end)
        Chk("T05", "A", "Weichen je Client simuliert", function()
            if not (g and g.SetTestFlavor) then return false, "SetTestFlavor fehlt" end
            local prevForce, before = A.forceForever, A:IsForever()
            A.forceForever = nil
            local bad = {}
            local ok, err = pcall(function()
                for _, f in ipairs({ "forever", "era", "tbc", "retail" }) do
                    g.SetTestFlavor(f)
                    if A:IsForever() ~= (f == "forever") then bad[#bad + 1] = f .. ": IsForever" end
                    -- seit 0.65.42 (Gebühren klassisch): überall 5 % beim Verkauf, Einzahlung zurück
                    if A:DepositRefunded() ~= true then bad[#bad + 1] = f .. ": DepositRefunded" end
                    if A:SaleFee(nil, 50, 1, 1) ~= 2 then bad[#bad + 1] = f .. ": SaleFee" end      -- 5 % abgerundet
                    if f == "forever" and A.Comfort:RaidSetKey() ~= "classic" then bad[#bad + 1] = "forever: RaidSetKey" end
                end
            end)
            g.SetTestFlavor(nil)
            A.forceForever = prevForce
            if not ok then error(err, 0) end
            if A:IsForever() ~= before then bad[#bad + 1] = "nach dem Test andere Erkennung" end
            if tostring(g.Status()):find("%[") then bad[#bad + 1] = "Status zeigt noch [Test]" end
            return #bad == 0, #bad == 0 and "RaidSetKey für era/tbc folgt WOW_PROJECT_ID" or table.concat(bad, "; "), "alles erfüllt"
        end)
        Chk("T06", "A", "Ladereihenfolge", function()
            local T = GTest()
            return T ~= nil and _G.GoldSentinelDev ~= nil and g ~= nil, nil, "Dev, Game, Test vor Locale.lua geladen"
        end)
        Chk("T07", "A", "AH-Weiche", function()
            local expectLegacy = (not (C_AuctionHouse and C_AuctionHouse.SendBrowseQuery)) and QueryAuctionItems ~= nil
            local realAH = ST.realAH or A.AH
            local ok = (A.AH_LEGACY and true or false) == (expectLegacy and true or false)
            if A.AH_LEGACY then ok = ok and realAH ~= C_AuctionHouse and realAH.SendBrowseQuery ~= nil
            else ok = ok and realAH == C_AuctionHouse end
            return ok, A.AH_LEGACY and "klassisch" or "modern", expectLegacy and "klassisch" or "modern"
        end)
        Chk("T08", "A", "Berufe-Weiche", function()
            local k = A.Crafting:TradeKind()
            local expect = GetNumTradeSkills and "trade" or "modern"
            return k == expect, k, expect
        end)
        if modern then Cli("T08c", "A", "Berufe-Weiche (Forever)", "/dump GetNumTradeSkills – muss nil sein, sonst liest das Addon die alte Liste") end
        Chk("T09", "A", "Tooltip-Weg", function()
            local m = A.Tooltip and A.Tooltip.mode
            local expect = TooltipDataProcessor and "TooltipDataProcessor" or "OnTooltipSetItem"
            return type(m) == "string" and m:find(expect, 1, true) ~= nil, tostring(m), expect
        end)
        Chk("T10", "A", "Chat-Befehle registriert", function()
            local ok = SLASH_AHANALYZERPRO1 == "/ahs" and SLASH_AHANALYZERPRO2 == "/ahsentinel" and SLASH_AHANALYZERPRO3 == "/ahp"
                and SLASH_AHANALYZERPRO4 == "/ahanalyzer" and type(SlashCmdList.AHANALYZERPRO) == "function"
                and SlashCmdList.GOLDSENTINELGAME ~= nil
            return ok, nil, "/ahs, /ahsentinel, /ahp, /ahanalyzer, /gsgame"
        end)
    end) end

    -- ---------------- B. Jede Funktion (Auswahl ohne Spieler-Handlung) ----------------
    if want(part, "b") then
        -- bisheriger Selbsttest mit gespeicherten Daten (Server-Teile werden übersprungen)
        if part == "auto" or part == "b" then
            if Count(A.db.marketData) > 0 then self:AddOldSteps(true)
            else B(function() Skp("S00", "B", "bisheriger Selbsttest", "keine gespeicherten Marktdaten - erst einmal scannen") end) end
        end
        B(function()
        Chk("T11", "B", "Geld anzeigen und lesen", function()
            local bad = {}
            for _, x in ipairs({ 1, 99, 10000, 1234567 }) do
                if A:ParseGold(A:FormatMoneyInput(x)) ~= x then bad[#bad + 1] = tostring(x) end
            end
            local s = A:FormatMoney(123456)
            if not (s:find("12") and s:find("34") and s:find("56")) then bad[#bad + 1] = "FormatMoney" end
            if A:PlainText("|cffff0000a|r|Tx:0|tb") ~= "ab" then bad[#bad + 1] = "PlainText" end
            return #bad == 0, table.concat(bad, ", "), "alle Rundläufe gleich"
        end)
        Chk("T12", "B", "Ereignis-Bus", function()
            local got
            A:On("AHS_TEST", function() error("AHS-Test Zuhörer") end)
            A:On("AHS_TEST", function(v) got = v end)
            Capture(function() A:Fire("AHS_TEST", 1) end)
            A.listeners["AHS_TEST"] = nil
            self:ClearTestErrors()
            return got == 1, tostring(got), "1 (zweiter Zuhörer läuft trotz Fehler im ersten)"
        end)
        Chk("T13", "B", "Preis-Kern mit Testdaten", function()
            local id, now = FAKE, time()
            local ok, err = pcall(function()
                A:RecordPrice(id, 100, 1, now - 1000)
                A:RecordPrice(id, 200, 1, now - 500)
                A:RecordPrice(id, 300, 1, now)
            end)
            local cur, n, mv = A:GetCurrent(id), #A:GetHistory(id), A:GetMarketValue(id)
            A.db.marketData[id] = nil
            if A.InvalidateMarket then pcall(A.InvalidateMarket, A, id) end
            if not ok then error(err, 0) end
            local good = cur == 300 and n == 3 and mv and mv >= 100 and mv <= 300
            return good and A.db.marketData[id] == nil, string.format("aktuell %s, Einträge %d, Marktwert %s", tostring(cur), n, tostring(mv)),
                "300, 3, 100–300"
        end)
        Chk("T17", "B", "Händler-Verkaufspreis", function()
            local p = A:GetVendorPrice(LINEN)
            return p == nil or (type(p) == "number" and p >= 0), tostring(p), "Zahl >= 0"
        end)
        Chk("T18", "B", "Händler-Scan mit Testhändler (moderner und alter Weg)", function()
            local db = A.db
            local items = {
                { id = FAKE + 10, price = 100, stack = 5, avail = -1 },
                { id = FAKE + 11, price = 100, stack = 1, avail = 3 },
                { id = FAKE + 12, price = 0, stack = 1, avail = -1, ext = true },
            }
            local cmf = { GetNumItems = function() return #items end,
                GetItemInfo = function(i) local e = items[i]; return e and { price = e.price, stackCount = e.stack, numAvailable = e.avail, hasExtendedCost = e.ext } end }
            local common = {
                GetMerchantItemLink = function(i) return items[i] and ("item:" .. items[i].id) end,
                GetMerchantItemCostInfo = function(i) return items[i] and items[i].ext and 1 or 0 end,
                GetMerchantItemCostItem = function(i) return nil, 2, "currency:3001", "Testwährung" end,
            }
            local results = {}
            for _, way in ipairs({ "modern", "alt" }) do
                local o = {}
                for k, v in pairs(common) do o[k] = v end
                if way == "modern" then o.C_MerchantFrame = cmf; o.GetMerchantNumItems = false; o.GetMerchantItemInfo = false
                else
                    o.C_MerchantFrame = false
                    o.GetMerchantNumItems = function() return #items end
                    o.GetMerchantItemInfo = function(i) local e = items[i]; return "x", nil, e.price, e.stack, e.avail, true, nil, e.ext end
                end
                A.apiOverride = o
                local ok, n = pcall(A.ScanMerchant, A)
                A.apiOverride = nil
                local c = db.vendorCost and db.vendorCost[FAKE + 12]
                results[way] = string.format("%s/%s/%s/%s", tostring(ok and n), tostring(db.vendorBuy[FAKE + 10]),
                    tostring(db.vendorBuy[FAKE + 11]), c and c.costs and c.costs[1] and (c.costs[1].kind .. ":" .. tostring(c.costs[1].id) .. "x" .. tostring(c.costs[1].amount)) or "nil")
                for k = 10, 12 do db.vendorBuy[FAKE + k] = nil; if db.vendorCost then db.vendorCost[FAKE + k] = nil end end
            end
            local want = "2/20/nil/currency:3001x2"
            return results.modern == want and results.alt == want, "modern " .. results.modern .. ", alt " .. results.alt, want
        end)
        Chk("T22", "B", "15-Minuten-Sperre", function()
            local saved = A.db.lastScanTime
            A.db.lastScanTime = time() - 100
            local rem, ready = A:GetCooldownRemaining(), A:IsScanReady()
            A.db.lastScanTime = saved
            return A.SCAN_COOLDOWN == 900 and rem >= 799 and rem <= 800 and not ready, tostring(rem), "800, gesperrt"
        end)
        Chk("T23", "B", "Anfrage-Drossel", function()
            local p = A.pace
            local errs, gap = p.errors, p.gap
            local r = A:QueryReady()
            A:QueryError()
            local grew = p.errors == errs + 1
            p.errors, p.gap = errs, gap
            return type(r) == "boolean" and A:QueryGap() >= 0 and grew, nil, "boolean, Abstand >= 0, Fehlerzähler +1"
        end)
        Chk("T29", "B", "Minikarten-Winkel", function()
            local st = A.db.settings
            local before = st.minimapAngle
            if not A.SetMinimapAngle then return true, "kein Minikarten-Knopf" end
            A:SetMinimapAngle(90)
            local v = st.minimapAngle
            A:SetMinimapAngle(before or 225)
            st.minimapAngle = before
            return v == 90, tostring(v), "90"
        end)
        Chk("T38", "B", "Einkauf-Favoriten", function()
            local K = A.Comfort
            local favs = K.FavDB()
            if #favs >= K.MAX_FAVS - 1 then return "SKIP", "Favoriten fast voll" end
            local saved = Copy(favs)
            local ok1 = K:AddFavorite({ text = "AHS-Test" })
            local ok2 = K:AddFavorite({ text = "AHS-Test" })
            Replace(favs, saved)
            return ok1 and not ok2, string.format("erst %s, doppelt %s", tostring(ok1), tostring(ok2)), "erst true, doppelt false"
        end)
        Chk("T47", "B", "Verkaufen rechnen", function()
            local Se = A.Seller
            if not (Se and Se.Undercut) then return "SKIP", "Undercut fehlt" end
            local u = Se:Undercut(1000)
            return type(u) == "number" and u < 1000 and u > 0 and Se:Undercut(1) >= 1, tostring(u), "< 1000, Undercut(1) >= 1"
        end)
        Chk("T61", "B", "Einkaufslisten", function()
            local Li = A.Lists
            local name = "AHS-Test"
            local existed = Li:Exists(name)
            if existed then return "SKIP", "Liste AHS-Test gab es schon" end
            Li:Create(name)
            Li:AddItem(name, tostring(LINEN), 5)
            local n = Li:Count(name)
            Li:Delete(name)
            return n == 1 and not Li:Exists(name), tostring(n), "1, danach weg"
        end)
        Chk("T68", "B", "Gold-Ziel", function()
            local K = A.Comfort
            local before = K:GoldGoal()
            Capture(function() K:GoalCommand("5000") end)
            local v = K:GoldGoal()
            Capture(function() K:GoalCommand("aus") end)
            local off = K:GoldGoal()
            K:SetGoldGoal(before)
            return v == 50000000 and off == nil, tostring(v) .. " / " .. tostring(off), "50000000 / nil"
        end)
        Chk("T70", "B", "Raid-Vorrat", function()
            local K, Li = A.Comfort, A.Lists
            local name = L["Raid-Vorrat"]
            local existed = Li:Exists(name)
            local key = K:RaidSetKey()
            if not key then
                local ok, msg = K:CreateRaidList(1)
                return ok == false, "keine Vorlage für diesen Client", "Meldung statt Liste"
            end
            local ok = K:CreateRaidList(1)
            local n = Li:Count(name)
            if not existed then Li:Delete(name) end
            return ok and n == #K.RAID_SETS[key], tostring(n), tostring(#K.RAID_SETS[key])
        end)
        Chk("T74", "B", "Item-Namen und Suche", function()
            local N = A.Names
            local de = N:Get(LINEN, "deDE")
            return de == "Leinenstoff" and N:ParseID("item:" .. LINEN) == LINEN and N:Resolve(tostring(LINEN)) == LINEN,
                tostring(de), "Leinenstoff, 2589"
        end)
        Chk("T75", "B", "Sync-Empfang (Testnachricht)", function()
            local S = A.Sync
            local sdb = A.db.sync
            if not (S and S.OnMessage and sdb) then return "SKIP", "Preis-Sync nicht geladen" end
            local saved = Copy(sdb)
            local heard = S.heardScanTime or 0
            sdb.enabled = true
            local ok, err = pcall(function()
                -- 0.65.30: Ankündigung "G" mit Kennung des Auktionshauses (Server/Fraktion)
                S:OnMessage("AHAP1", "G:" .. S.Enc(heard + 1) .. ":" .. A:MarketTag() .. ":" .. S.Enc(1), "GUILD", "AHS-Testpeer-Realm")
                -- offener Punkt 5: "gehört" erst, wenn die angekündigten Preise da sind
                S:OnMessage("AHAP1", "P:" .. S.Enc(heard + 1) .. ":" .. A:MarketTag() .. ":" .. S.Enc(990000950) .. "," .. S.Enc(100) .. "," .. S.Enc(1),
                    "GUILD", "AHS-Testpeer-Realm")
            end)
            A.db.marketData[990000950] = nil
            local after = S.heardScanTime or 0
            Replace(sdb, saved)
            S.heardScanTime = heard
            if not ok then error(err, 0) end
            return after == heard + 1, "heardScanTime +" .. tostring(after - heard), "+1, Daten danach wie vorher"
        end)
        Chk("T76", "B", "Sync senden nur simuliert, Kodierung", function()
            local S = A.Sync
            local bad = {}
            for _, n in ipairs({ 0, 1, 35, 36, 123456789 }) do
                if S.Dec(S.Enc(n)) ~= n then bad[#bad + 1] = tostring(n) end
            end
            return #bad == 0 and A:Simulated(), #bad == 0 and "Rundlauf ok, A:Simulated() = true" or table.concat(bad, ", "), "alle gleich"
        end)
        Chk("T78", "B", "Testmodus während der Routine abgelehnt", function()
            local lines, ok = Capture(function() return TM:Start() end)
            return ok == false and not TM.active, tostring(ok), "false"
        end)
        Chk("T79", "B", "Diagnose", function()
            local lines = Capture(function() A:PrintDebug() end)
            local all = table.concat(lines, "\n")
            local need = (g and g.Status and A:PlainText(g.Status())) or ""
            local errLine = A:PlainText(L["Fehler seit Login: %d · Berichte offen: %d"]):match("^[^%%]+") or "?"
            local good = all:find(A.version, 1, true) ~= nil and all:find(need, 1, true) ~= nil and all:find(errLine, 1, true) ~= nil
            return good, string.format("%d Zeilen", #lines), "Version, Spielversion, Fehlerzeile"
        end)
        end)
    end

    -- ---------------- B. Oberfläche, Optionen, Befehle, Rechnen (0.65.7) ----------------
    if want(part, "b") then
        local UI = A.UI
        local function Shown(f) return f and f.IsShown and f:IsShown() or false end
        local function Click(b, button)
            if not b then error("Knopf fehlt", 0) end
            local f = b:GetScript("OnClick")
            if not f then error("Knopf ohne OnClick", 0) end
            return f(b, button or "LeftButton")
        end
        local function Opt() UI:ShowOptions(); return UI.options end
        local function Eff(v) return v ~= false end          -- nil = Standard "an"
        local function HideAll()
            for _, k in ipairs({ "options", "helpWindow", "textWindow", "donateWindow", "listsWindow", "todayWin",
                "mailRulesWindow", "chartWin" }) do
                if UI[k] then UI[k]:Hide() end
            end
            if UI.HideMenu then UI:HideMenu() end
        end
        -- zurückgeschriebene Fenster-Werte auch anwenden (Grösse, Position, Zoom, Minikarten-Knopf)
        local function ApplyLayout()
            local st, f = A.db.settings, UI.frame
            if f then
                f.fitW = nil
                pcall(UI.FitToAH, UI)
                local pos = st.windowPos
                f:ClearAllPoints()
                if pos then f:SetPoint(pos.point or "CENTER", UIParent, pos.relPoint or "CENTER", pos.x or 0, pos.y or 0)
                else f:SetPoint("CENTER") end
            end
            if st.ahZoom and UI.SetAHZoom then pcall(UI.SetAHZoom, UI, st.ahZoom) end
            if A.SetMinimapButtonShown then A:SetMinimapButtonShown(not st.minimapHide) end
            if st.minimapAngle then A:SetMinimapAngle(st.minimapAngle) end
        end
        B(function()
        Chk("T24", "B", "Hauptfenster und Designs", function()
            local theme = A.db.settings.theme
            UI:Show(); local v1 = UI:IsVisible()
            UI:Hide(); local v2 = UI:IsVisible()
            UI:Toggle(); local v3 = UI:IsVisible()
            UI:SetTheme("modern"); UI:SetTheme("classic"); UI:SetTheme(theme or "classic")
            ApplyLayout()
            return v1 and not v2 and v3 and A.db.settings.theme == theme,
                string.format("%s/%s/%s, Design %s", tostring(v1), tostring(not v2), tostring(v3), tostring(A.db.settings.theme)),
                "zeigen/verstecken/umschalten, Design wie vorher"
        end)
        local extra = {
            { "T26c", "Hilfe (jede Seite)", function()
                local help = (A.uiLang == "deDE" and UI.HELP_DE) or A.HELP[A.uiLang] or UI.HELP_EN
                local n = 0
                for id in pairs(help or {}) do UI:ShowHelp(id); n = n + 1 end
                return Shown(UI.helpWindow) and n > 0, n .. " Seiten"
            end },
            { "T26d", "Einkaufslisten", function() UI:ShowLists(); local s = Shown(UI.listsWindow); UI:ToggleLists(); return s end },
            { "T26e", "Heute tun", function() UI:ShowToday(); return Shown(UI.todayWin) end },
            { "T26f", "Post-Regeln", function() UI:ShowMailRules(); return Shown(UI.mailRulesWindow) end },
            { "T26g", "Unterstützen", function() UI:ShowDonate(); return Shown(UI.donateWindow) end },
            { "T26h", "Textfenster", function() UI:ShowTextWindow("Test", "Test"); return Shown(UI.textWindow) end },
            { "T26i", "Item-Menü", function()
                local inList = A.Watchlist:Contains(LINEN)
                Capture(function()
                    for _, act in ipairs({ "chart", "watch", "watch", "sniper", "list" }) do
                        UI:ShowItemMenu(LINEN, UIParent); UI:OnMenuClick(act)
                    end
                    if A:IsAHOpen() then UI:ShowItemMenu(LINEN, UIParent); UI:OnMenuClick("ah") end
                end)
                return A.Watchlist:Contains(LINEN) == inList, "Watchlist danach wie vorher"
            end },
        }
        for _, w in ipairs(extra) do
            Chk(w[1], "B", "Zusatzfenster " .. w[2], function()
                local ok, detail = w[3]()
                HideAll()
                return ok and true or false, detail or (ok and "öffnet und schließt" or "nicht offen"), "öffnet und schließt"
            end)
        end
        Chk("T28", "B", "Größe, Zoom, Position", function()
            local st = A.db.settings
            local KEYS = { "scale", "windowPos", "buttonPos", "ahZoom", "windowSize", "minimapAngle", "minimapHide" }
            local saved = {}
            for _, k in ipairs(KEYS) do saved[k] = Copy(st[k]) end
            UI:SetScale((st.scale or 1) + 0.05); UI:SetScale((saved.scale or 1))
            if UI.SetAHZoom and UI.AHZoom then UI:SetAHZoom(UI:AHZoom()) end
            if UI.ResetWindowSize then UI:ResetWindowSize() end
            UI:ResetPosition()
            if A.ResetButtonPosition then Capture(A.ResetButtonPosition, A) end
            -- auch nil zurückschreiben (pairs überspringt nil: war ahZoom vorher nil, blieb der Testwert stehen)
            for _, k in ipairs(KEYS) do st[k] = saved[k] end
            ApplyLayout()
            return true, "ohne Fehler, Werte zurück"
        end)
        end)

        -- T30.xx: jede Option einmal an und aus (wie ein Klick im Optionsfenster)
        local OPTIONS = {
            { "01", "Design", function()
                local theme = A.db.settings.theme
                Click(Opt().modernBtn); local m = A.db.settings.theme
                Click(Opt().classicBtn); local c = A.db.settings.theme
                UI:SetTheme(theme or "classic")
                return m == "modern" and c == "classic", m .. "/" .. c
            end },
            { "02", "Im AH anzeigen", "ahBtn", "ahIntegration" },
            { "03", "Preis im Tooltip", "ttInfoBtn", "tooltipInfo" },
            { "04", "Preisverlauf im Tooltip", function()
                local before, steps = A.Tooltip:ChartDays(), {}
                for _ = 1, 8 do
                    Click(Opt().ttChartBtn)
                    steps[#steps + 1] = tostring(A.Tooltip:ChartDays())
                    if A.Tooltip:ChartDays() == before then break end
                end
                return A.Tooltip:ChartDays() == before and #steps > 1, table.concat(steps, ",")
            end },
            { "05", "Händlerpreis im Tooltip", "ttVendorBtn", "tooltipVendor" },
            { "06", "Twinks im Tooltip", "ttCharsBtn", "tooltipChars" },
            { "07", "Entzauberwert im Tooltip", "ttDEBtn", "tooltipDE" },
            { "40", "Mit dem Auktionshaus öffnen", "openAHBtn", "openWithAH" },
            { "39", "Entzauber-Details im Tooltip", function()
                local seen = {}
                for _ = 1, 3 do Click(Opt().ttDEDetailBtn); seen[#seen + 1] = A.Tooltip:DEMode() end
                return #seen == 3 and seen[1] ~= seen[2] and seen[2] ~= seen[3] and seen[3] ~= seen[1], table.concat(seen, ",")
            end },
            { "08", "Entzaubern zurücksetzen (Sandbox)", function()
                -- W1: nur Ersatztabellen (auch deBackup) - die echte Sicherung bleibt unberührt
                return TR.DESandbox(function()
                    local w = Opt()
                    A.db.deBackup = nil
                    if next(A.db.deStats or {}) == nil then A.db.deStats = { ["2:1:a"] = { n = 1, mats = { [10940] = { times = 1, total = 1 } } } } end
                    Click(w.deReset); local asked = w.deConfirm
                    Click(w.deReset)
                    local cleared = next(A.db.deStats or {}) == nil
                    return asked and cleared, "Rückfrage " .. tostring(asked) .. ", geleert " .. tostring(cleared)
                end)
            end },
            { "09", "Knöpfe am Briefkasten", "mailBtn", "mailButtons" },
            { "10", "Meldung bei Verkauf", "saleBtn", "saleAlert" },
            { "11", "Preisschutz", function()
                local before, seen = A.Seller:GuardPercent(), {}
                for _ = 1, #A.Seller.GUARD_STEPS do Click(Opt().guardBtn); seen[#seen + 1] = A.Seller:GuardPercent() end
                return A.Seller:GuardPercent() == before, table.concat(seen, ",")
            end },
            { "12", "Gewinn im Berufsfenster", "craftBtn", "craftPanel" },
            { "13", "Sprache des Addons", function()
                local v = A:UILanguageSetting()
                Click(Opt().uiLangBtn); local mid = A:UILanguageSetting()
                Click(Opt().uiLangBtn, "RightButton"); local back = A:UILanguageSetting()
                if back ~= v then A:SetUILanguage(v) end
                return mid ~= v and back == v, v .. " -> " .. mid .. " -> " .. back
            end },
            { "14", "Item-Namen-Sprache", function()
                local before, n = A.db.settings.nameLocale, 0
                repeat Click(Opt().langBtn); n = n + 1 until A.db.settings.nameLocale == before or n > 20
                return A.db.settings.nameLocale == before, n .. " Klicks bis zurück"
            end },
            { "15", "Geldanzeige", "moneyBtn", "moneyStyle", function(v) return v == "letters" end },
            { "16", "Fenstergröße", function()
                local sc = A.db.settings.scale or 1
                Click(Opt().scaleUp); Click(Opt().scaleDown)
                return math.abs((A.db.settings.scale or 1) - sc) < 0.001, tostring(A.db.settings.scale)
            end },
            { "17", "Schrift- und Inhaltsgröße", function()
                local z = A.db.settings.ahZoom or 1
                Click(Opt().zoomUp); local up = A.db.settings.ahZoom or 1
                Click(Opt().zoomDown); local down = A.db.settings.ahZoom or 1
                A.db.settings.ahZoom = z
                return (up > z or z >= 1.6) and math.abs(down - z) < 0.001, string.format("%.2f -> %.2f -> %.2f", z, up, down)
            end },
            { "18", "Ton", "soundBtn", "alertSound", function(v) return v and true or false end },
            { "19", "Preise teilen (nur simuliert)", function()
                local l = self.real.LeaveChannelByName or 0
                local on = A.Sync:IsEnabled() and true or false
                Capture(Click, Opt().syncBtn); local mid = A.Sync:IsEnabled() and true or false
                Capture(Click, Opt().syncBtn)
                return mid ~= on and (self.real.LeaveChannelByName or 0) == l,
                    "an/aus, Kanal-Austritt 0 (kein eigener Kanal mehr)"
            end },
            { "20", "nur Gilde", function()
                local gOnly = A.Sync:GuildOnly()
                Capture(Click, Opt().syncGuildBtn); local mid = A.Sync:GuildOnly()
                Capture(Click, Opt().syncGuildBtn)
                return mid ~= gOnly and A.Sync:GuildOnly() == gOnly, tostring(mid)
            end },
            { "21", "Sniper-Intervall", function()
                local v = A.db.sniper.interval or 0
                Click(Opt().snipeUp); local up = A.db.sniper.interval or 0
                Click(Opt().snipeDown); local down = A.db.sniper.interval or 0
                A.db.sniper.interval = v
                return up ~= v and down == v, string.format("%s -> %s -> %s", tostring(v), tostring(up), tostring(down))
            end },
            { "22", "Sniper-Taste (Mausrad)", function()
                local binds = Copy(A.db.sniper.binds)
                A.Sniper:UseMouseWheel("sniper")
                local wheel = A.Sniper:IsMouseWheelBind("sniper")
                A.db.sniper.binds = binds
                return wheel, A.Sniper:GetBindsText("sniper")
            end },
            { "23", "Wächter-Taste (Mausrad)", function()
                local binds = Copy(A.db.watcher.binds)
                A.Sniper:UseMouseWheel("watcher")
                local wheel = A.Sniper:IsMouseWheelBind("watcher")
                A.db.watcher.binds = binds
                return wheel, A.Sniper:GetBindsText("watcher")
            end },
            { "24", "Tagesbilanz + Jetzt zeigen", function()
                local v = A.db.settings.dailySummary
                Click(Opt().dailyBtn); local mid = A.db.settings.dailySummary
                Click(Opt().dailyBtn)
                Capture(Click, Opt().dailyNow)
                return Eff(mid) ~= Eff(v), "umgeschaltet"
            end },
            { "25", "Knopf beim Händler", "vendorBtn", "vendorButton", function() return UI:VendorButtonEnabled() end },  -- Standard hängt an LevelPilot
            { "26", "Post an Twinks (Regeln)", function()
                Click(Opt().rulesBtn)
                return Shown(UI.mailRulesWindow), "Regeln-Fenster"
            end },
            { "27", "Minikarte", function()
                local hide = A.db.settings.minimapHide and true or false
                Click(Opt().minimapBtn); local mid = A.db.settings.minimapHide and true or false
                Click(Opt().minimapBtn)
                return mid ~= hide and (A.db.settings.minimapHide and true or false) == hide, "aus/an"
            end },
            { "28", "Post automatisch abholen", "autoMailBtn", "autoCollect" },
            { "29", "Alt-Klick", "altClickBtn", "altClick" },
            { "30", "Verkaufschance im Tooltip", "chanceBtn", "tooltipChance" },
            { "31", "Ablauf-Erinnerung", "expiryBtn", "expiryReminder" },
            { "32", "Gold-Ziel setzen/löschen", function()
                Capture(function() A.Comfort:SetGoldGoal(5000 * 10000); A.Comfort:SetGoldGoal(nil) end)
                return A.Comfort:GoldGoal() == nil, "gesetzt und gelöscht"
            end },
            { "33", "Zeile Selbsttest nur für Dev", function()
                local b = Opt().selfTestBtn
                return b:IsShown() == (A:IsDev() and true or false), "sichtbar " .. tostring(b:IsShown())
            end },
            { "34", "CSV-Export", function()
                local lines = Capture(Click, Opt().exportBtn)
                if Count(A.db.marketData) == 0 then
                    return table.concat(lines, "\n"):find(A:PlainText(L["Noch keine Daten zum Exportieren. Erst einen Scan machen."]), 1, true) ~= nil,
                        "keine Daten: Hinweis"
                end
                return Shown(UI.textWindow), "Textfenster mit CSV"
            end },
            { "35", "Positionen", function()
                local st = A.db.settings
                local KEYS = { "windowPos", "windowSize", "buttonPos", "minimapAngle", "minimapHide" }
                local saved = {}
                for _, k in ipairs(KEYS) do saved[k] = Copy(st[k]) end
                Capture(Click, Opt().resetBtn)
                local reset = st.windowPos == nil and st.windowSize == nil
                for _, k in ipairs(KEYS) do st[k] = saved[k] end
                return reset, "zurückgesetzt " .. tostring(reset) .. ", Werte danach zurück"
            end },
            { "36", "Unterstützen", function() Click(Opt().donateBtn); return Shown(UI.donateWindow), "Fenster" end },
            { "37", "Warnung Einstellgebühr", function()
                local before, seen = A.Seller:FeeWarnPercent(), {}
                for _ = 1, #A.Seller.FEE_WARN_STEPS do Click(Opt().feeBtn); seen[#seen + 1] = A.Seller:FeeWarnPercent() end
                return A.Seller:FeeWarnPercent() == before, table.concat(seen, ",")
            end },
            { "38", "Unter Händlerpreis ab", function()
                local before, seen = A:VendorFlipMin(), {}
                for _ = 1, 5 do Click(Opt().vflipBtn); seen[#seen + 1] = A:VendorFlipMin() end
                return A:VendorFlipMin() == before, table.concat(seen, ",")
            end },
        }
        -- pro Option ein eigener Schritt (SLICE_MS, kein "script ran too long" bei mehreren UI:Rebuild)
        for _, o in ipairs(OPTIONS) do
        B(function()
            Chk("T30." .. o[1], "B", "Option " .. o[2], function()
                local st = A.db.settings
                local snap = Copy(st)
                local res = { pcall(function()
                    if type(o[3]) == "function" then return o[3]() end
                    local field, key, eff = o[3], o[4], o[5] or Eff
                    local v0 = eff(st[key])
                    Click(Opt()[field]); local v1 = eff(st[key])
                    Click(Opt()[field]); local v2 = eff(st[key])
                    return (v1 ~= v0) and (v2 == v0), string.format("%s: %s -> %s -> %s", key, tostring(v0), tostring(v1), tostring(v2))
                end) }
                -- Einstellungen genau wie vorher (nil/true-Unterschiede der Umschalter), Fenster zu
                for k, v in pairs(snap) do if k ~= "theme" and k ~= "uiLanguage" then st[k] = Copy(v) end end
                for k in pairs(st) do if snap[k] == nil then st[k] = nil end end
                if o[1] == "16" or o[1] == "17" or o[1] == "35" then ApplyLayout() end
                HideAll()
                if not res[1] then error(res[2], 0) end
                return res[2] and true or false, res[3], "umgeschaltet und zurück"
            end)
        end)
        end

        -- T31.xx: jeder Chat-Befehl (A:Print abgefangen)
        local function Has(lines, text) return table.concat(lines, "\n"):find(A:PlainText(text), 1, true) ~= nil end
        local CMDS = {
            { "01", "" }, { "02", "show" },
            -- Die Routine sperrt den Markt-Scan (ST:Lock). AH zu: für diesen einen Aufruf den echten Start einsetzen
            -- (er lehnt ab, weil das AH zu ist) und sofort zurückstellen. AH offen: Sperre bleibt, sonst liefe ein echter Scan.
            { "03", "scan", function(out, ahOpen)
                if ahOpen then return Has(out, L["Selbsttest läuft - ein Markt-Scan ist solange gesperrt."]) end
                return Has(out, L["Bitte zuerst das Auktionshaus öffnen."]) and not A:IsScanning()
            end, function(run)
                if A:IsAHOpen() or not ST.origScan then return run() end
                local locked = A.StartFullScan
                A.StartFullScan = ST.origScan
                local r = { pcall(run) }
                A.StartFullScan = locked
                if not r[1] then error(r[2], 0) end
                return unpack(r, 2)
            end },
            { "04", "export" }, { "05", "debug", function(out) return Has(out, g.Status()) end },
            { "06", "reset" }, { "07", "resetscan" }, { "08", "sync" }, { "09", "sync" }, { "10", "ahdebug" }, { "11", "ah" },
            { "12", "sniper" }, { "13", "sniper" }, { "14", "design" }, { "15", "design" }, { "16", "optionen" },
            { "17", "options" }, { "18", "spenden" }, { "19", "donate" }, { "20", "bilanz" }, { "21", "summary" },
            { "22", "ziel 5000", function() return A.Comfort:GoldGoal() == 50000000 end }, { "23", "ziel" },
            { "24", "ziel aus", function() return A.Comfort:GoldGoal() == nil end },
            { "25", "heute" }, { "26", "today" }, { "27", "minikarte" }, { "28", "minikarte" }, { "29", "raid" },
            { "30", "twinks" }, { "31", "sprache" }, { "32", "listen" }, { "33", "hilfe" }, { "34", "handbuch" },
            { "35", "xyz", function(out) return Has(out, string.format(L["Unbekannter Befehl: %s"], "xyz")) end },
        }
        -- pro Befehl ein eigener Schritt (SLICE_MS)
        for _, cmd in ipairs(CMDS) do
        B(function()
            if cmd[2] == "resetscan" and A:IsScanning() then
                Skp("T31." .. cmd[1], "B", "Befehl /ahs resetscan", "Markt-Scan läuft - würde ihn abbrechen")
            else
            Chk("T31." .. cmd[1], "B", "Befehl /ahs " .. cmd[2], function()
                local st = A.db.settings
                local snap = { goal = st.goldGoal, reached = st.goldGoalReached, ui = UI:IsVisible(), lang = st.uiLanguage or "auto",
                    theme = st.theme, raid = A.Lists:Exists(L["Raid-Vorrat"]), windowPos = Copy(st.windowPos),
                    windowSize = Copy(st.windowSize), buttonPos = Copy(st.buttonPos), minimapAngle = st.minimapAngle,
                    minimapHide = st.minimapHide, armed = A.Sniper:IsArmed() }
                local ahOpen = A:IsAHOpen()
                local function run() return pcall(Capture, SlashCmdList.AHANALYZERPRO, cmd[2]) end
                local res = { (cmd[4] or function(f) return f() end)(run) }
                local ok = res[1] and (not cmd[3] or cmd[3](res[2], ahOpen) and true or false)
                -- Folgen zurück (Sprache direkt setzen: nur ein Neuaufbau statt einer Runde durch alle Sprachen)
                if cmd[2] == "sprache" and A:UILanguageSetting() ~= snap.lang then A:SetUILanguage(snap.lang) end
                if cmd[2] == "raid" and not snap.raid and A.Lists:Exists(L["Raid-Vorrat"]) then A.Lists:Delete(L["Raid-Vorrat"]) end
                if (A.Sniper:IsArmed() and true or false) ~= (snap.armed and true or false) then A.Sniper:SetArmed(snap.armed and true or false) end
                st.goldGoal, st.goldGoalReached = snap.goal, snap.reached
                for _, k in ipairs({ "windowPos", "windowSize", "buttonPos", "minimapAngle", "minimapHide" }) do st[k] = snap[k] end
                if cmd[2] == "reset" then ApplyLayout() end
                if A.SetMinimapButtonShown then A:SetMinimapButtonShown(not st.minimapHide) end
                if st.theme ~= snap.theme then UI:SetTheme(snap.theme) end
                HideAll()
                if snap.ui then UI:Show() else UI:Hide() end
                if not res[1] then error(res[2], 0) end
                return ok, ok and "ohne Fehler" or (table.concat(res[2], " / "):sub(1, 120)), "erwartete Meldung"
            end)
            end
        end)
        end
        B(function() Skp("T31.36", "B", "Befehle test*/testmodus", "würde die laufende Routine stören") end)

        B(function()
        Chk("T34", "B", "Einkauf rechnen", function()
            local Bu = A.Buy
            local saved, savedP = Bu.detail, Bu.pending
            Bu.pending = nil
            Bu.detail = { itemID = FAKE, commodity = true, qty = 1,
                listings = { { qty = 5, price = 100 }, { qty = 10, price = 150 } } }
            local res = { pcall(function()
                local t8 = Bu:Quote(8)
                local t20 = Bu:Quote(20)
                local av = Bu:Available()
                Bu:SetQuantity(99)
                local q = Bu.detail.qty
                -- K3 (Befund Sofortkauf): +5 % nur mit Bieter; ohne Bieter ist das Startgebot das Mindestgebot
                local m1, m2 = Bu:MinBid({ bid = 1000, hasBidder = true }), Bu:MinBid({ minBid = 77 })
                if Bu:MinBid({ bid = 1000 }) ~= 1000 then m1 = -1 end
                local own = Bu.BuyItem(Bu, { own = true, auctionID = 1, buyout = 1 })
                return t8 == 950 and t20 == nil and av == 15 and q == 15 and m1 == 1050 and m2 == 77 and not own,
                    string.format("%s/%s/%d/%d/%s/%s", tostring(t8), tostring(t20), av, q, tostring(m1), tostring(m2))
            end) }
            Bu.detail, Bu.pending = saved, savedP
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "950/nil/15/15/1050/77"
        end)
        Chk("T39", "B", "Sniper-Ziele", function()
            local Sn = A.Sniper
            local targets = Copy(A.db.sniper.targets)
            local res = { pcall(function()
                local ok = Sn:SetTarget(tostring(LINEN), 500, 3, 2000)
                local t = Sn:GetTarget("i:" .. LINEN)
                local q = t and Sn:Remaining(t)
                local done = t and Sn:IsDone(t)
                if t then Sn:FilterText(t) end
                Sn:RemoveTarget("i:" .. LINEN)
                return ok and t ~= nil and q == 3 and done == false and Sn:GetTarget("i:" .. LINEN) == nil,
                    string.format("gesetzt %s, Rest %s, fertig %s", tostring(ok), tostring(q), tostring(done))
            end) }
            A.db.sniper.targets = targets
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "gesetzt, Rest 3, nicht fertig, entfernt"
        end)
        Chk("T43", "B", "Sniper-Tasten", function()
            local Sn = A.Sniper
            local name = Sn:KeyName("SHIFT-BUTTON4")
            local before = self.real.SetOverrideBindingClick or 0
            if not A:IsAHOpen() then Sn:ApplyBindings() end
            local set = (self.real.SetOverrideBindingClick or 0) - before
            return name == "Shift+" .. L["Maustaste 4"] and (A:IsAHOpen() or set == 0),
                string.format("%s, Tasten bei geschlossenem AH: %d", tostring(name), set), "Shift+" .. L["Maustaste 4"] .. ", 0"
        end)
        Chk("T44", "B", "Wächter-Einstellungen", function()
            local W = A.Watcher
            local saved = Copy(A.db.watcher)
            local res = { pcall(function()
                W:SetThreshold(40); W:SetMinValue(20); W:SetBudget(1000)
                for _, c in ipairs(W.CATS or {}) do W:ToggleCategory(c.key or c[1] or c); W:CategoryLabel(c.key or c[1] or c) end
                W:ModeLabel(); W:ActiveCategories()
                -- TR:Start schaltet den Wächter ab; für den Wartegrund hier nur das Feld setzen (kein Start einer Runde),
                -- Replace(A.db.watcher, saved) stellt es danach zurück
                A.db.watcher.enabled = true
                local why = W:WhyWaiting()
                A.db.watcher.enabled = false
                return A:IsAHOpen() or why == L["wartet auf das Auktionshaus"], tostring(why)
            end) }
            Replace(A.db.watcher, saved)
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], A:IsAHOpen() and "ohne Fehler" or L["wartet auf das Auktionshaus"]
        end)
        Chk("T54", "B", "Buchhaltung rechnen", function()
            local Le = A.Ledger
            local entries = Copy(A.db.ledger.entries)
            local res = { pcall(function()
                local s0 = Le:Summary("all").sales
                Le:Add({ kind = "buy", itemID = FAKE, qty = 2, amount = 200 })
                Le:Add({ kind = "sale", itemID = FAKE, qty = 1, amount = 300, cut = 15 })
                local s1 = Le:Summary("all").sales
                local sold, avg = Le:SoldCount(FAKE, 30), Le:AverageBuyPrice(FAKE, 30)
                Le:Stats("all"); Le:ByItem("all"); Le:PeriodStart("7")
                return s1 == s0 + 1 and sold == 1 and avg == 100, string.format("Verkäufe +%d, verkauft %d, Ø Kauf %s",
                    s1 - s0, sold, tostring(avg))
            end) }
            A.db.ledger.entries = entries
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "+1, 1, 100"
        end)
        Chk("T62", "B", "Watchlist", function()
            local Wl = A.Watchlist
            local had = Copy(A.db.watchlist[LINEN])
            local res = { pcall(function()
                local ok = Wl:Add(tostring(LINEN), 100, 500)
                local has = Wl:Contains(LINEN)
                Wl:SetBuyBelow(tostring(LINEN), 120); Wl:GetStatus(LINEN); Wl:CountAlerts()
                Capture(Wl.CheckAlerts, Wl, false)
                return ok and has, "hinzugefügt " .. tostring(ok)
            end) }
            A.db.watchlist[LINEN] = had
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "hinzugefügt und wieder wie vorher"
        end)
        end)
    end

    -- ---------------- C. Taschen, Addon-Info, Esc im Kampf (0.65.7) ----------------
    if want(part, "c") then B(function()
        Chk("T89", "C", "Taschen ohne alte Funktionen", function()
            local Se, X, M = A.Seller, A.Extras, A.Mailer
            local function run()
                if Se.InvalidateBags then Se:InvalidateBags() end
                local items = Se:GetBagItems()
                local cand = X:VendorCandidates()
                local free = M.FreeSlots and M.FreeSlots() or 0
                return #items, #cand, free
            end
            -- 1) alte Funktionen fehlen, C_Container da (moderner Weg)
            A.apiOverride = { GetContainerNumSlots = false, GetContainerItemInfo = false, GetContainerNumFreeSlots = false }
            local ok1, n1, c1, f1 = pcall(run)
            -- 2) gar nichts da (nur simuliert): leere Liste, kein Fehler
            A.apiOverride = { C_Container = false, GetContainerNumSlots = false, GetContainerItemInfo = false,
                GetContainerNumFreeSlots = false }
            local ok2, n2, c2, f2 = pcall(run)
            A.apiOverride = nil
            if Se.InvalidateBags then Se:InvalidateBags() end
            if not ok1 then error(n1, 0) end
            if not ok2 then error(n2, 0) end
            local modernOK = (C_Container == nil) or n1 > 0 or f1 > 0
            return modernOK and n2 == 0 and c2 == 0 and f2 == 0,
                string.format("C_Container: %d Items, %d frei · ohne alles: %d/%d/%d", n1, f1, n2, c2, f2), "Taschen gelesen; ohne alles 0/0/0"
        end)
        Chk("T92", "C", "Addon-Info und Chat-Hilfen", function()
            local GSS = _G.GoldSentinelSync
            local f = GSS and GSS.api and GSS.api.send                 -- nur nachsehen, nie senden
            local f2 = A.Sync and A.Sync.ep and A.Sync.ep.prefix
            local hid = false
            -- C_AddOns fehlt (nachgespielt über A.apiOverride): Rückfall auf die alten globalen Funktionen
            A.apiOverride = { C_AddOns = false }
            local okMeta
            local okRun = pcall(function()
                local tbl = A:Global("C_AddOns")
                local meta = (tbl and tbl.GetAddOnMetadata) or A:Global("GetAddOnMetadata")
                local loaded = (tbl and tbl.IsAddOnLoaded) or A:Global("IsAddOnLoaded")
                okMeta = tbl == nil and (meta == nil or meta("AHSentinel", "Version") == A.version)
                    and (loaded == nil or loaded("AHSentinel") ~= false)
            end)
            okMeta = okRun and okMeta
            A.apiOverride = nil
            return f ~= nil and f2 == "AHAP1" and hid == false and okMeta,
                string.format("Senden über GoldSentinelSync %s, Kennung %s, Metadaten %s", tostring(f ~= nil), tostring(f2), tostring(okMeta)),
                "GoldSentinelSync, Kennung AHAP1, Metadaten"
        end)
        -- ein Test-Rahmen für alle Läufe; Ablauf in pcall, danach immer Kampf aus und Rahmen versteckt
        local f = self.escTestFrame
        if not f then f = CreateFrame("Frame", nil, UIParent); self.escTestFrame = f end
        if not (f.SetPropagateKeyboardInput and f.EnableKeyboard) then
            Skp("T94", "C", "Esc-Fenster im Kampf", "Client ohne SetPropagateKeyboardInput")
        else
        Chk("T94", "C", "Esc-Fenster im Kampf", function()
            self.escCalls = 0
            if not self.escHooked then
                hooksecurefunc(f, "SetPropagateKeyboardInput", function() if A.testCombat then TR.escCalls = (TR.escCalls or 0) + 1 end end)
                self.escHooked = true
            end
            local ok, err = pcall(function()
                A.testCombat = true
                A.UI:EscCloses(f)
                f:Show(); f:Hide(); f:Show()
                local key = f:GetScript("OnKeyDown")
                if key then key(f, "A"); key(f, "ESCAPE") end
            end)
            A.testCombat = nil
            f:Hide()
            if f.EnableKeyboard then pcall(f.EnableKeyboard, f, false) end
            if not ok then error(err, 0) end
            return self.escCalls == 0, self.escCalls .. " Aufrufe im Kampf", "0"
        end)
        end
    end) end

    -- ---------------- I/J. Ergänzungen (0.65.7) ----------------
    if want(part, "i") then B(function()
        self.wantJobError = true
        A:Job("ahs-test-error", function() error("AHS-Test T129", 0) end)
    end)
    B(function()
        if not self.wantJobError then return end
        return "WAIT", function() return not A:HasJob("ahs-test-error") end, 5, function(timedOut)
            local e = ErrorEntry("Job:ahs-test-error")
            self.wantJobError = nil
            Chk("T129", "I", "Fehler in Hintergrund-Aufgabe wird gemeldet", function()
                return e ~= nil, e and "Eintrag da" or "kein Eintrag", "Eintrag wo = Job:ahs-test-error"
            end)
            self:ClearTestErrors()
        end
    end) end
    if want(part, "j") then B(function()
        if not (C_AddOns and C_AddOns.GetAddOnOptionalDependencies) then
            Skp("T143", "J", "Übergang vom alten AH Analyzer Pro", "Client ohne GetAddOnOptionalDependencies")
        else
        Chk("T143", "J", "Übergang vom alten AH Analyzer Pro", function()
            local get = C_AddOns.GetAddOnOptionalDependencies
            local deps = { get("AHSentinel") }
            for _, d in ipairs(deps) do if d == "AHAnalyzerPro" then return false, "OptionalDeps enthält AHAnalyzerPro", "nicht enthalten" end end
            return _G.AHAnalyzerPro == A and A.version ~= nil, #deps .. " OptionalDeps, AHAnalyzerPro = AHSentinel", "kein AHAnalyzerPro"
        end)
        end
        Cli("T143b", "J", "Alter Ordner AHAnalyzerPro zusätzlich vorhanden",
            "Ordner AddOns\\AHAnalyzerPro (bis 0.61) zusätzlich aktivieren: genau eine Meldung 'Bitte den alten Ordner ... löschen', keine doppelten /ahs-Befehle, keine Lua-Fehler")
    end) end

    -- ---------------- C. Forever-Sonderfälle (simuliert) ----------------
    if want(part, "c") then B(function()
        local function secretCheck(id, name, fn, verify)
            Chk(id, "C", name, function()
                local ok, err = WithSecret(fn)
                self:ClearTestErrors()
                if not ok then return false, tostring(err), "kein Lua-Fehler" end
                if verify then return verify() end
                return true
            end)
        end
        local Se, S, D, M, Sn = A.Seller, A.Sync, A.Disenchant, A.Mailer, A.Sniper
        local lastSale = Se and Se.lastSale
        secretCheck("T80", "Systemmeldung \"verkauft\" geschützt", function()
            Se.saleFrame:GetScript("OnEvent")(Se.saleFrame, "CHAT_MSG_SYSTEM", SECRET)
        end, function() return Se.lastSale == lastSale, nil, "lastSale unverändert" end)
        -- T-0 (offen Punkt 0, Fehler aus dem Spiel 0.65.80): ein geschützter Wert ist in Forever auch ein "string". Der Test
        -- nimmt eine echte Verkaufs-Meldung (passt zum Muster) und lässt nur die Schutz-Funktion (GoldSentinelGame, Addon-Tabelle)
        -- sie als geschützt erkennen -> kein Lua-Fehler, keine Verkaufs-Buchung.
        Chk("T414", "C", "T-0 Verkaufs-Meldung als geschützter Text (string) -> kein Lua-Fehler, keine Buchung", function()
            local tmpl = _G.ERR_AUCTION_SOLD_S or "A buyer has been found for your auction of %s."
            local msg = string.format(tmpl, "AHS-Test Ware")
            local g = G()
            if not (g and g.IsSecret) then return "SKIP", "keine Schutz-Funktion (GoldSentinelGame)" end
            local real, onSold = g.IsSecret, Se.OnSold
            local calls = 0
            g.IsSecret = function(v) if v == msg then return true end return real(v) end
            Se.OnSold = function() calls = calls + 1 end
            local ok, err = pcall(Se.saleFrame:GetScript("OnEvent"), Se.saleFrame, "CHAT_MSG_SYSTEM", msg)
            g.IsSecret, Se.OnSold = real, onSold
            -- Gegenprobe: ohne Schutz erkennt das Muster die Meldung (sonst prüft der Test nichts)
            local calls2 = 0
            Se.OnSold = function() calls2 = calls2 + 1 end
            pcall(Se.saleFrame:GetScript("OnEvent"), Se.saleFrame, "CHAT_MSG_SYSTEM", msg)
            Se.OnSold = onSold
            -- ohne Vorlage des Spiels (ERR_AUCTION_SOLD_S) erkennt das Addon gar keine Verkaufs-Meldung: Gegenprobe entfällt
            local tmplOK = _G.ERR_AUCTION_SOLD_S ~= nil
            return ok and calls == 0 and (calls2 == 1 or not tmplOK), string.format("Lua-Fehler %s · Buchungen geschützt %d · Gegenprobe ungeschützt %s",
                ok and "nein" or tostring(err), calls, tmplOK and tostring(calls2) or "entfällt (keine Vorlage)"), "nein · 0 · 1"
        end)
        local peers = Count(A.db.sync and A.db.sync.peers)
        secretCheck("T81", "Addon-Nachricht Sync geschützt", function()
            -- seit 0.65.55 Empfang über GoldSentinelSync (Befund 20:15 C1)
            local GSS = _G.GoldSentinelSync
            GSS.OnAddonMessage("AHAP1", SECRET, "GUILD", "Testpeer")
            GSS.OnAddonMessage("AHAP1", "H:1", "GUILD", SECRET)
        end, function()
            local e = A.db.gsTest and A.db.gsTest.errors
            for k in pairs(e or {}) do if k:find("^Sync|") and k:find("geschützt") then return false, "Sync-Fehler", "keiner" end end
            return Count(A.db.sync and A.db.sync.peers) == peers, nil, "peers unverändert"
        end)
        secretCheck("T82", "Zauber-Ereignis Entzaubern geschützt", function()
            D.evt:GetScript("OnEvent")(D.evt, "UNIT_SPELLCAST_SUCCEEDED", "player", "x", SECRET)
        end)
        secretCheck("T83", "Tooltip-Daten geschützt", function()
            local tip = { AddLine = function() error("Zeile hinzugefügt") end, NumLines = function() return 0 end }
            A.Tooltip:Handle(tip, { id = SECRET })
        end)
        secretCheck("T84", "Fehlermeldung am Briefkasten geschützt", function()
            local was = M.running
            M.running = true
            local ok, err = pcall(M.evt:GetScript("OnEvent"), M.evt, "UI_ERROR_MESSAGE", SECRET, SECRET)
            M.running = was
            if not ok then error(err, 0) end
        end)
        local inst = Sn and Sn.instantFailed
        secretCheck("T85", "Blockierte Aktion geschützt", function()
            Sn:OnEvent("ADDON_ACTION_BLOCKED", SECRET, SECRET)
        end, function() return Sn.instantFailed == inst, nil, "instantFailed unverändert" end)
        Chk("T86", "C", "Forever-Namen: Post-Regel an sich selbst", function()
            local X = A.Extras
            if not (X and X.IsMyself and g and g.SetTestFlavor) then return "SKIP", "IsMyself oder SetTestFlavor fehlt" end
            g.SetTestFlavor("forever")
            X.testMyName = "Testa Beispiel"
            local ok, me = pcall(X.IsMyself, "Testa")
            local ok2, other = pcall(X.IsMyself, "Ersatz1")
            X.testMyName = nil
            g.SetTestFlavor(nil)
            return ok and ok2 and me == true and other == false, tostring(me) .. "/" .. tostring(other), "true/false"
        end)
        Chk("T87", "C", "Händler ohne alte Funktionen", function()
            A.apiOverride = { GetMerchantNumItems = false, GetMerchantItemInfo = false, GetMerchantItemLink = false,
                GetMerchantItemID = false, C_MerchantFrame = false, GetMerchantItemCostInfo = false }
            local ok, n = pcall(A.ScanMerchant, A)
            A.apiOverride = nil
            return ok and n == 0, tostring(n), "0 ohne Fehler"
        end)
        Chk("T88", "C", "Berufe ohne alte Funktionen", function()
            A.apiOverride = { GetNumTradeSkills = false }
            local k1 = A.Crafting:TradeKind()
            A.apiOverride = { GetNumTradeSkills = false, C_TradeSkillUI = false }
            local k2 = A.Crafting:TradeKind()
            A.apiOverride = nil
            local ts = C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs
            return k1 == (ts and "modern" or "trade") and k2 == "trade", k1 .. "/" .. k2, (ts and "modern" or "trade") .. "/trade"
        end)
        Chk("T90", "C", "Item-Aliase beim Laden", function()
            return A:StackSize(LINEN) >= 1 and A:GetItemIcon(LINEN) ~= nil, tostring(A:StackSize(LINEN)), "Stapel >= 1, Symbol da"
        end)
        Chk("T91", "C", "Post ohne Funktionen", function()
            A.apiOverride = { SendMail = false, ClickSendMailItemButton = false }
            local open = MailFrame and MailFrame:IsShown()
            local ok, r, msg = pcall(A.Extras.MailStep, A.Extras)
            A.apiOverride = nil
            if not ok then error(r, 0) end
            if not open then return r == false, tostring(msg), "Briefkasten zu -> false" end
            return r == false and msg == L["Dein Client unterstützt das Verschicken nicht."], tostring(msg), "Dein Client unterstützt ..."
        end)
        Chk("T93", "C", "Sniper-Tasten im Kampf", function()
            local Sn = A.Sniper
            local before = self.real.SetOverrideBindingClick or 0
            A.testCombat = true
            Sn:ApplyBindings()
            local pend = Sn.pendingBindings
            A.testCombat = false
            Sn.evt:GetScript("OnEvent")(Sn.evt, "PLAYER_REGEN_ENABLED")
            local after = Sn.pendingBindings
            A.testCombat = nil
            local set = (self.real.SetOverrideBindingClick or 0) - before
            return (SetOverrideBindingClick == nil) or (pend == true and after == false), string.format("im Kampf %s, danach %s, Tasten %d",
                tostring(pend), tostring(after), set), "true, false"
        end)
        Chk("T95", "C", "Routine-Start im Kampf abgelehnt", function()
            A.testCombat = true
            self.running = false
            local lines, ok = Capture(function() return TR.Start(TR, "a") end)
            self.running = true
            A.testCombat = nil
            return ok == false, tostring(ok), "false"
        end)
        Chk("T96", "C", "Kampflog nicht benutzt", function()
            local bad = {}
            for name, f in pairs({ Crafting = A.Crafting.evt, Extras = A.Extras.evt, Seller = A.Seller.saleFrame, Sniper = A.Sniper.evt,
                Disenchant = A.Disenchant.evt, Mailer = A.Mailer.evt, Comfort = A.Comfort.evt, Chars = A.Chars.evt,
                Sync = A.Sync.frame, Kern = A.eventFrame, Test = TR.frame }) do
                if f and f.IsEventRegistered and f:IsEventRegistered("COMBAT_LOG_EVENT_UNFILTERED") then bad[#bad + 1] = name end
            end
            return #bad == 0, #bad == 0 and "keiner" or table.concat(bad, ", "), "keiner"
        end)
    end) end

    -- ---------------- D. Alte Clients ----------------
    if want(part, "d") then B(function()
        if not A.AH_LEGACY then
            Skp("T97", "D", "Nachbildung altes AH", "nur im alten Client")
        else
            Chk("T97", "D", "Nachbildung altes AH", function()
                local AH = ST.realAH or A.AH
                local k = AH.MakeItemKey and AH.MakeItemKey(LINEN)
                return k and k.itemID == LINEN, tostring(k and k.itemID), tostring(LINEN)
            end)
        end
        Chk("T102", "D", "Raid-Vorrat je Version", function()
            local key = A.Comfort:RaidSetKey()
            local p = WOW_PROJECT_ID
            local expect
            if A:IsForever() then expect = "classic"
            elseif p == (WOW_PROJECT_CLASSIC or 2) then expect = "classic"
            elseif p == (WOW_PROJECT_BURNING_CRUSADE_CLASSIC or 5) then expect = "tbc"
            elseif p == (WOW_PROJECT_WRATH_CLASSIC or 11) then expect = "wrath" end
            return key == expect, tostring(key), tostring(expect)
        end)
        Chk("T103", "D", "keine Rückschritte zum letzten Bericht", function()
            local reps = A.db.gsTest and A.db.gsTest.reports
            return true, string.format("%d frühere Berichte (Vergleich macht die Prüf-Sitzung)", reps and #reps or 0)
        end)
    end) end

    -- ---------------- E. Daten ----------------
    if want(part, "e") then B(function()
        Chk("T104", "E", "Neuinstallation", function()
            local orig, origOld, migrated = AHSentinelDB, AHAnalyzerProDB, A.migratedFromOld
            local ok, err, res
            AHSentinelDB, AHAnalyzerProDB = nil, nil
            local lines
            ok, err = pcall(function()
                lines = Capture(function() A:InitDB() end)
                local d = A.db
                res = { d.dbVersion, d.settings.detachedWindow, d.sniper.fastSearch, d.settings.nameLocale }
            end)
            AHSentinelDB, AHAnalyzerProDB, A.db, A.migratedFromOld = orig, origOld, orig, migrated
            A:ApplyUILanguage()
            local GT = GTest()
            if GT then GT.TrackErrors("AHSentinel", A.version, A.db) end
            if not ok then error(err, 0) end
            return res[1] == 4 and res[2] == true and res[3] == true and res[4] == "auto",
                string.format("%s/%s/%s/%s", tostring(res[1]), tostring(res[2]), tostring(res[3]), tostring(res[4])), "4/true/true/auto"
        end)
        Chk("T105", "E", "Migration Datenbank 3 -> 4", function()
            local orig, migrated = AHSentinelDB, A.migratedFromOld
            local t1, t2 = time() - 2000, time() - 1000
            AHSentinelDB = { dbVersion = 3, marketData = { [LINEN] = { history = { { price = 100, time = t2, quantity = 1 },
                { price = 90, timestamp = t1, qty = 2 } } } } }
            local lines, h
            local ok, err = pcall(function()
                lines = Capture(function() A:InitDB() end)
                h = A.db.marketData[LINEN] and A.db.marketData[LINEN].history
            end)
            AHSentinelDB, A.db, A.migratedFromOld = orig, orig, migrated
            A:ApplyUILanguage()
            local GT = GTest()
            if GT then GT.TrackErrors("AHSentinel", A.version, A.db) end
            if not ok then error(err, 0) end
            local good = h and #h == 2 and h[1].t == t1 and h[1].p == 90 and h[1].q == 2 and h[2].p == 100
            return good and table.concat(lines, " "):find(A:PlainText(L["Datenbank auf Version 4 umgestellt."]), 1, true) ~= nil,
                h and (#h .. " Einträge") or "nil", "2 Einträge sortiert, Meldung"
        end)
        Chk("T109", "E", "Abbruch mitten im Test (Wiederherstellung)", function()
            return type(TR.RecoverAfterReload) == "function" and A.db.testRoutine and A.db.testRoutine.backup ~= nil, nil,
                "Sicherung liegt in AHSentinelDB.testRoutine"
        end)
    end) end

    -- ---------------- F. Sprachen ----------------
    if want(part, "f") then B(function()
        local LANGS = { "frFR", "esES", "esMX", "ptBR", "itIT", "ruRU", "koKR", "zhCN", "zhTW" }
        Chk("T110", "F", "Text-Schlüssel vollständig", function()
            local miss, parts = 0, {}
            for _, l in ipairs(LANGS) do
                local n = 0
                for k in pairs(A.EN) do if A.T[l][k] == nil then n = n + 1 end end
                miss = miss + n
                if n > 0 then parts[#parts + 1] = l .. " " .. n end
            end
            return miss == 0, miss == 0 and (Count(A.EN) .. " Schlüssel je Sprache") or table.concat(parts, ", "), "0 fehlend"
        end)
        Chk("T111", "F", "Formatplatzhalter", function()
            local function marks(s)
                local out = {}
                for m in tostring(s):gsub("%%%%", ""):gmatch("%%[%-%d%.]*[sdfi]") do out[#out + 1] = m:sub(-1) end
                return table.concat(out)
            end
            local bad = {}
            for k, en in pairs(A.EN) do
                local want = marks(k)
                if marks(en) ~= want then bad[#bad + 1] = "enUS: " .. k:sub(1, 30) end
                for _, l in ipairs(LANGS) do
                    local v = A.T[l][k]
                    if v and marks(v) ~= want then bad[#bad + 1] = l .. ": " .. k:sub(1, 30) end
                end
                if #bad > 10 then break end
            end
            return #bad == 0, #bad == 0 and "0 Abweichungen" or table.concat(bad, " | "), "0 Abweichungen"
        end)
        Chk("T113", "F", "Text-Werte gültig, Hilfeseiten", function()
            local bad = {}
            for k, v in pairs(A.EN) do if type(v) ~= "string" then bad[#bad + 1] = "enUS" end end
            for _, l in ipairs(LANGS) do
                for k, v in pairs(A.T[l]) do if type(v) ~= "string" then bad[#bad + 1] = l; break end end
            end
            local ref = A.HELP.deDE or A.HELP.enUS
            if type(ref) == "table" then
                for _, l in ipairs(LANGS) do
                    local h = A.HELP[l]
                    if type(h) == "table" and #h ~= #ref then bad[#bad + 1] = "Hilfe " .. l end
                end
            end
            return #bad == 0, table.concat(bad, ", "), "alles Text, gleiche Hilfeseiten"
        end)
        Chk("T114", "F", "Texte der gemeinsamen Dateien", function()
            local D = _G.GoldSentinelDev
            local a = g and g.Text("game")
            local b = D and D.Text and D:Text("blocked")
            return a ~= "game" and (b == nil or b ~= "blocked"), tostring(a), "übersetzter Text"
        end)
    end) end

    -- ---------------- G. Zusammenspiel ----------------
    if want(part, "g") then B(function()
        Chk("T115", "G", "gemeinsame Dateien nach Simulation wieder echt", function()
            if not (g and g.SetTestFlavor) then return "SKIP", "SetTestFlavor fehlt" end
            local f = g.flavor
            g.SetTestFlavor(f == "forever" and "era" or "forever")
            g.SetTestFlavor(nil)
            return g.flavor == f, tostring(g.flavor), tostring(f)
        end)
        Chk("T116", "G", "globale Namen", function()
            return _G.AHAnalyzerPro == A and A.version ~= nil and _G.AHSentinelDB == A.db, nil, "AHAnalyzerPro = A, AHSentinelDB = A.db"
        end)
        Chk("T117", "G", "ProfessionSentinel liest AHSentinel (QuickBuy/QuickSell, Händler-Kosten)", function()
            local Td = A.Today
            local ok1 = Td:QuickBuy(LINEN, 2, 100, "Test")
            local found
            for _, r in ipairs(Td.extra) do if r.key == "quick:" .. LINEN and r.pin then found = true end end
            local ok0 = Td:QuickBuy(LINEN, 2, 0, "Test")
            local lines, ok2 = Capture(function() return Td:QuickSell(LINEN) end)
            for i = #Td.extra, 1, -1 do
                local k = Td.extra[i].key
                if k == "quick:" .. LINEN or k == "quicksell:" .. LINEN then table.remove(Td.extra, i) end
            end
            Td.state["quick:" .. LINEN], Td.state["quicksell:" .. LINEN] = nil, nil
            if A.UI and A.UI.todayWin then A.UI.todayWin:Hide() end
            return ok1 and found and ok0 == false and ok2, nil, "Zeile mit pin, maxPrice 0 abgelehnt"
        end)
        Chk("T118", "G", "AHSentinel liest ProfessionSentinel (Stub, Fehler abgefangen)", function()
            local real = _G.ProfessionSentinelAPI
            local okA, okB
            _G.ProfessionSentinelAPI = { version = 1, TodayCrafts = function() error("AHS-Test PS") end }
            okA = pcall(A.Comfort.TodayActions, A.Comfort, 10, true)
            _G.ProfessionSentinelAPI = { version = 2 }
            okB = pcall(A.Comfort.TodayActions, A.Comfort, 10, true)
            _G.ProfessionSentinelAPI = real
            self:ClearTestErrors()
            return okA and okB and _G.ProfessionSentinelAPI == real, nil, "kein Fehler in TodayActions, echte API zurück"
        end)
    end) end

    -- ---------------- H. Leistung ----------------
    if want(part, "h") then B(function()
        local function measure(id, name, fn, n, limit)
            Chk(id, "H", name, function()
                local sum, max = 0, 0
                for i = 1, n do
                    local t = Ms()
                    fn()
                    local d = Ms() - t
                    sum = sum + d
                    if d > max then max = d end
                end
                local avg = sum / n
                return avg < limit, string.format("Mittel %.3f ms, höchstens %.2f ms (%d Items)", avg, max, Count(A.db.marketData)),
                    string.format("< %.2f ms", limit)
            end)
        end
        measure("T121", "Takt-Funktionen (Sniper, Wächter)", function() A.Sniper:Tick(); A.Watcher:Tick() end, 100, 0.4)
        measure("T123", "Heute tun (10)", function() A.Comfort:TodayActions(10) end, 3, 16)
        measure("T123b", "Marktliste", function() A:BuildItemList() end, 3, 16)
        measure("T125", "Zauber-Ereignis im Raid", function()
            A.Disenchant.evt:GetScript("OnEvent")(A.Disenchant.evt, "UNIT_SPELLCAST_SUCCEEDED", "raid5", "x", 1)
        end, 1000, 0.02)
        Chk("T127", "H", "Speicher", function()
            local kb = 0
            if UpdateAddOnMemoryUsage and GetAddOnMemoryUsage then
                UpdateAddOnMemoryUsage()
                kb = GetAddOnMemoryUsage("AHSentinel") or 0
            end
            return true, string.format("AHSentinel %.0f KB", kb)
        end)
    end) end

    -- ---------------- I. Fehlerzählung ----------------
    if want(part, "i") then B(function()
        Chk("T128", "I", "Fehler in Ereignis-Zuhörer wird gemeldet", function()
            A:On("AHS_TEST_ERROR", function() error("AHS-Test T128") end)
            Capture(function() A:Fire("AHS_TEST_ERROR") end)
            A.listeners["AHS_TEST_ERROR"] = nil
            local e = ErrorEntry("Fire:AHS_TEST_ERROR")
            self:ClearTestErrors()
            return e ~= nil, e and "Eintrag da" or "kein Eintrag", "Eintrag in gsTest.errors"
        end)
        Chk("T130", "I", "Verkaufs-Meldung: Fehler gemeldet statt verschluckt", function()
            local Se = A.Seller
            local raw = _G.ERR_AUCTION_SOLD_S
            if type(raw) ~= "string" then return "SKIP", "Client ohne ERR_AUCTION_SOLD_S" end
            -- Muster fehlt, obwohl der Text da ist -> die Verkaufs-Meldung geht für Spieler gar nicht
            if Se.SoldPattern and not Se.SoldPattern() then return false, "Muster fehlt für: " .. raw, "Muster aus ERR_AUCTION_SOLD_S" end
            self:ClearTestErrors()          -- GoldSentinelTest speichert höchstens MAX_ERRORS verschiedene Fehler
            local GT, n = _G.GoldSentinelTest, 0
            for _ in pairs(A.db.gsTest and A.db.gsTest.errors or {}) do n = n + 1 end
            if GT and GT.MAX_ERRORS and n >= GT.MAX_ERRORS then
                return "SKIP", string.format("Fehlerspeicher voll (%d von %d) - erst nach dem nächsten Bericht prüfbar", n, GT.MAX_ERRORS)
            end
            local real = Se.OnSold
            Se.OnSold = function() error("AHS-Test T130") end
            local msg = raw:gsub("%%%d?%$?s", "Leinenstoff")
            pcall(Se.saleFrame:GetScript("OnEvent"), Se.saleFrame, "CHAT_MSG_SYSTEM", msg)
            Se.OnSold = real
            local e = ErrorEntry("Verkauft")
            self:ClearTestErrors()
            return e ~= nil, e and "Eintrag da" or ("kein Eintrag (Text: " .. msg .. ")"), "Eintrag \"Verkauft\""
        end)
        Chk("T132", "I", "blockierte Aktion wird gemeldet", function()
            local f = _G.GoldSentinelTestFrame
            if not f then return false, "GoldSentinelTestFrame fehlt" end
            f:GetScript("OnEvent")(f, "ADDON_ACTION_BLOCKED", "AHSentinel", "AHS-Test()")
            local okS = pcall(A.Sniper.OnEvent, A.Sniper, "ADDON_ACTION_BLOCKED", "AHSentinel", "AHS-Test()")
            local s = A.db.gsTest.errors
            local found
            for k in pairs(s) do if k:find("ADDON_ACTION_BLOCKED", 1, true) and k:find("AHS-Test", 1, true) then found = true end end
            self:ClearTestErrors()
            return found and okS, nil, "Eintrag, Sniper ohne Fehler"
        end)
    end)
        if want(part, "i") then
            -- unbehandelter Lua-Fehler: wartet auf den Fehler-Abgriff von GoldSentinelTest
            B(function()
                C_Timer.After(0, function() error("AHS-Test T131") end)
                return "WAIT", function() return ErrorEntry("Lua") ~= nil end, 3, function(timedOut)
                    local found = ErrorEntry("Lua") ~= nil
                    self:ClearTestErrors()
                    self:Check("T131", "I", "unbehandelter Lua-Fehler wird gezählt", function()
                        -- ohne BugSack/BugGrabber und ohne Fehler-Handler kein Abgriff möglich: übersprungen, nie OK/FEHLER
                        -- (Entscheid der Prüf-Sitzung 9. Nov. 09:35)
                        if not found and not (_G.BugGrabber or (_G.geterrorhandler and _G.seterrorhandler)) then
                            return "SKIP", "kein Fehler-Abgriff im Client (BugSack/BugGrabber/seterrorhandler fehlen)"
                        end
                        return found, found and "gezählt" or "nicht gezählt", "Eintrag \"Lua\" (BugSack/Fehler-Abgriff)"
                    end)
                end
            end)
        end
    end

    -- ---------------- J. Regressionstests ----------------
    if want(part, "j") then B(function()
        Chk("T133", "J", "Raid-Vorrat in Forever", function()
            if not (g and g.SetTestFlavor) then return "SKIP", "SetTestFlavor fehlt" end
            g.SetTestFlavor("forever")
            local k = A.Comfort:RaidSetKey()
            g.SetTestFlavor(nil)
            return k == "classic", tostring(k), "classic"
        end)
        Chk("T136", "J", "Favor-Kosten: Format stabil", function()
            for id, c in pairs(A.db.vendorCost or {}) do
                if type(c) ~= "table" or type(c.costs) ~= "table" or c.gold == nil or c.qty == nil then
                    return false, "Eintrag " .. tostring(id), "{ gold, qty, costs, t }"
                end
                return A:GetVendorCost(id) == c, nil, "GetVendorCost = gespeicherte Tabelle"
            end
            return "SKIP", "keine Favor-Kosten gespeichert - erst einen Händler mit Währungs-Artikeln ansprechen (Format über T18 geprüft)"
        end)
        Chk("T137", "J", "Artikelanzahl über C_MerchantFrame", function()
            local cmf = { GetNumItems = function() return 1 end, GetItemInfo = function() return { price = 50, stackCount = 1, numAvailable = -1 } end }
            A.apiOverride = { GetMerchantNumItems = false, C_MerchantFrame = cmf, GetMerchantItemLink = function() return "item:" .. (FAKE + 20) end }
            local ok, n = pcall(A.ScanMerchant, A)
            A.apiOverride = nil
            local v = A.db.vendorBuy[FAKE + 20]
            A.db.vendorBuy[FAKE + 20] = nil
            return ok and n == 1 and v == 50, tostring(n) .. "/" .. tostring(v), "1/50"
        end)
        Chk("T139", "J", "Sniper ADDON_ACTION_BLOCKED", function()
            local Sn = A.Sniper
            local inst, pend = Sn.instantFailed, Sn.pending
            local db = A.db.sniper
            local instantSetting, blocked = db and db.instantBuy, db and db.instantBlocked
            Sn.pending = { auto = true, itemID = FAKE }
            local ok, err = pcall(Capture, Sn.OnEvent, Sn, "ADDON_ACTION_BLOCKED", "AHSentinel", "C_AuctionHouse.StartCommoditiesPurchase()")
            local p = Sn.pending
            Sn.instantFailed, Sn.pending = inst, pend
            if db then db.instantBuy, db.instantBlocked = instantSetting, blocked end
            if not ok then error(err, 0) end
            return p == nil, tostring(p), "pending nil"
        end)
        Chk("T140", "J", "Wächter-Pause wirkt (moderner Weg)", function()
            local W = A.Watcher
            local saved, legacy, drop, hold = A.db.lastScanTime, A.AH_LEGACY, A.lastThrottleDrop, W.holdForScan
            A.AH_LEGACY = false
            A.db.lastScanTime = 0
            W.holdForScan = nil
            W:OnThrottleDrop()
            local h1 = W:HoldingForScan()
            A.db.lastScanTime = time()
            local h2 = W:HoldingForScan()
            A.AH_LEGACY, A.db.lastScanTime, A.lastThrottleDrop, W.holdForScan = legacy, saved, drop, hold
            return h1 == true and h2 == false, tostring(h1) .. "/" .. tostring(h2), "true/false"
        end)
        Chk("T141", "J", "Pause ändert altes AH nicht", function()
            local W = A.Watcher
            local saved, legacy, hold = A.db.lastScanTime, A.AH_LEGACY, W.holdForScan
            A.AH_LEGACY = true
            A.db.lastScanTime = 0
            W.holdForScan = nil
            W:OnThrottleDrop()
            local h = W.holdForScan
            A.AH_LEGACY, A.db.lastScanTime, W.holdForScan = legacy, saved, hold
            return h == nil, tostring(h ~= nil), "keine Pause"
        end)
        if not A.AH_LEGACY then
            Cli("T142", "J", "Scan nicht vom Wächter blockiert", "Forever: Wächter an, Scan fällig -> /ahs scan startet den Scan")
            Cli("T138", "J", "Wächter und Server-Limit", "Forever: Wächter 2–3 Runden, dann /ahs scan: startet der Scan?")
        else
            Skp("T142", "J", "Scan nicht vom Wächter blockiert", "nur moderner Client")
        end
        Skp("T144", "J", "CurseForge Forever-Tag", "betrifft curseforge/upload.py im raidmaster-Repo, nicht das Addon – prüft die Prüf-Sitzung im Workflow")
        Chk("T145", "J", "Raid-Liste: alle Item-IDs vorhanden", function()
            local miss = {}
            local exists = (C_Item and C_Item.DoesItemExistByID) or (GetItemInfoInstant and function(id) return GetItemInfoInstant(id) ~= nil end)
            if not exists then return "SKIP", "Client ohne C_Item.DoesItemExistByID/GetItemInfoInstant" end
            local list = A.Comfort.RAID_SETS.classic
            for _, e in ipairs(list) do
                if not exists(e[1]) then miss[#miss + 1] = tostring(e[1]) end
            end
            -- nur GetItemInfoInstant und mehr als die Hälfte unbekannt: Item-Daten fehlen im Client -> übersprungen
            -- (Entscheid der Prüf-Sitzung 9. Nov. 09:35); einzelne fehlende IDs bleiben FEHLER
            if not (C_Item and C_Item.DoesItemExistByID) and #miss * 2 > #list then
                return "SKIP", "Item-Daten fehlen im Client (" .. #miss .. " von " .. #list .. " unbekannt)"
            end
            return #miss == 0, #miss == 0 and "alle vorhanden" or table.concat(miss, ", "), "alle vorhanden"
        end)
        if A:IsForever() then
            Cli("T145c", "J", "Raid-Vorrat passt zu Forever", "Passen die Schutztränke zu Barrow Deeps, Hyjalgipfel, Onyxia? (Punkt 5 nach dem Launch)")
            Cli("T149", "J", "Händler-Währungsfunktionen", "/dump GetMerchantItemCostInfo, /dump GetMerchantItemCostItem – fehlen sie, liest das Addon keine Favor-Kosten")
            Cli("T151", "J", "Interface-Nummer", "/dump select(4, GetBuildInfo()) – ist es nicht 16001, neue Nummer in AHSentinel.toc ergänzen")
        end
        Chk("T150", "J", "Erkennung über GoldSentinelGame", function()
            local prev = A.forceForever
            A.forceForever = nil
            local follows = (A:IsForever() == (g and g.IsForever == true))
            A.forceForever = true; local t = A:IsForever()
            A.forceForever = false; local f = A:IsForever()
            A.forceForever = prev
            return follows and t == true and f == false, nil, "folgt G.IsForever, Schalter gewinnt"
        end)
        -- neu ab 0.65.6
        Chk("T153", "J", "Scan-Start scheitert dauerhaft: höchstens 2 Chatzeilen, Wächter läuft weiter", function()
            local proxy = A.AH
            if not (ST.realAH and getmetatable(proxy)) then return false, "Handels-Proxy fehlt" end
            local W = A.Watcher
            local saved = { last = A.db.lastScanTime, legacy = A.AH_LEGACY, open = A.ahOpen, hold = W.holdForScan, round = W.round,
                start = A.StartFullScan, lastQ = A.pace.last, errs = A.pace.errors, gap = A.pace.gap }
            proxy.SendBrowseQuery = function() error("AHS-Test SendBrowseQuery") end
            proxy.IsThrottledMessageSystemReady = function() return true end
            A.AH_LEGACY, A.ahOpen, A.db.lastScanTime, W.holdForScan, W.round = false, true, 0, nil, nil
            A.StartFullScan = ST.origScan or A.StartFullScan
            local lines, res = {}, {}
            local ok, err = pcall(function()
                lines = Capture(function()
                    A:StartFullScan()
                    if A.scanWishTicker then A.scanWishTicker:Cancel(); A.scanWishTicker = nil end
                    for i = 1, 10 do
                        A.scanWishNext = 0
                        if A.scanWanted then A:TryWantedScan() end
                        if A.scanWishTicker then A.scanWishTicker:Cancel(); A.scanWishTicker = nil end
                    end
                end)
                res.wanted, res.hold = A.scanWanted, W:HoldingForScan()
            end)
            if A.DropScanWish then A:DropScanWish(false) end
            proxy.SendBrowseQuery, proxy.IsThrottledMessageSystemReady = nil, nil
            A.db.lastScanTime, A.AH_LEGACY, A.ahOpen, W.holdForScan, W.round = saved.last, saved.legacy, saved.open, saved.hold, saved.round
            A.StartFullScan = saved.start
            A.pace.last, A.pace.errors, A.pace.gap = saved.lastQ, saved.errs, saved.gap
            if not ok then error(err, 0) end
            return #lines <= 2 and res.wanted == nil and res.hold == false,
                string.format("%d Chatzeilen, Wunsch %s, Wächter-Pause %s", #lines, tostring(res.wanted ~= nil), tostring(res.hold)),
                "<= 2 Zeilen, Wunsch verworfen, keine Pause"
        end)
        Chk("T154", "J", "15-Minuten-Pause während eines Scan-Wunschs", function()
            local W = A.Watcher
            local hold = W.holdForScan
            W.holdForScan = nil
            W:HoldForScan(120)
            local m1 = W.holdForScan and W.holdForScan.max
            W:HoldForScan()
            local m2 = W.holdForScan and W.holdForScan.max
            W.holdForScan = hold
            return m1 == 120 and m2 == nil, tostring(m1) .. " -> " .. tostring(m2), "120 -> nil (15 Min.)"
        end)
        Chk("T155", "J", "Rezept-Auswahl im Berufsfenster: Ereignisname", function()
            local Cr = A.Crafting
            local nameOK = Cr.RECIPE_SELECTED_EVENT == "ProfessionsRecipeListMixin.Event.OnRecipeSelected"
            local hooked = (not (EventRegistry and EventRegistry.RegisterCallback)) or Cr.selectionHooked == true
            local before = Cr.lastModernRecipe
            Cr:OnRecipeSelected({ recipeID = 123456 })
            local got = Cr.lastModernRecipe
            Cr.lastModernRecipe = before
            return nameOK and hooked and got == 123456, string.format("Name %s, angemeldet %s", tostring(nameOK), tostring(hooked)), "ja, ja"
        end)
        if modern then
            Cli("T155c", "J", "Rezept-Auswahl (Forever)", "Rezept im Blizzard-Berufsfenster wählen -> /dump AHAnalyzerPro.Crafting.lastModernRecipe zeigt dessen ID")
        end
    end) end

    -- ---------------- Halbautomatische Teile ----------------
    -- ---------------- Ergänzungen 0.65.8 (fehlende Fälle aus testroutine-ahsentinel.txt) ----------------
    -- Jeder Fall ein eigener Schritt (SLICE_MS). HALB-Fälle laufen in ihrem Teil (server, berufe, haendler);
    -- im Teil "auto" stehen sie mit Hinweis als übersprungen im Bericht, damit nichts fehlt.
    local function Real(name) return self.real[name] or 0 end
    local function TradeCount(fn)
        local n = 0
        for _, e in ipairs(ST.tradeLog or {}) do if not fn or e.fn == fn then n = n + 1 end end
        return n
    end
    local HALB_SERVER = "HALB: Auktionshaus öffnen, dann /ahs testroutine server"

    if want(part, "b") then
        B(function()
        Chk("T46", "B", "Wächter-Kandidaten mit Testdaten", function()
            local W, Sn = A.Watcher, A.Sniper
            local opps, extra = Copy(W.opps), {}
            for k, v in pairs(Sn.extra) do extra[k] = v end
            local res = { pcall(function()
                W:AddCandidate({ itemID = FAKE + 20, price = 50, market = 200, pct = 25 })
                local found = false
                for _, o in ipairs(W:GetOpportunities()) do if o.itemID == FAKE + 20 then found = true end end
                local t = Sn.extra["w:" .. (FAKE + 20)]
                if t then t.created = (t.created or 0) - 100000 end
                W:Cleanup(); W:ClearTargets()
                local left = Sn.extra["w:" .. (FAKE + 20)]
                return found and left == nil, string.format("in der Liste %s, Ziel danach %s", tostring(found), left and "da" or "weg")
            end) }
            W.opps = opps
            for k in pairs(Sn.extra) do if extra[k] == nil then Sn.extra[k] = nil end end
            for k, v in pairs(extra) do Sn.extra[k] = v end
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "Kandidat gelistet, Cleanup/ClearTargets räumen"
        end)
        end)

        B(function()
        if not ERR_AUCTION_SOLD_S then return Skp("T53", "B", "Verkaufs-Meldung", "Client ohne ERR_AUCTION_SOLD_S") end
        Chk("T53", "B", "Verkaufs-Meldung", function()
            local Se = A.Seller
            local owned, last = Se.owned, Se.lastSale
            local name = A:GetItemName(LINEN)
            local o = { itemID = LINEN, name = name, qty = 2, buyout = 200, unitPrice = 100, auctionID = FAKE + 21 }
            Se.owned = { o }
            local lines = Capture(function()
                -- Text mit "%s" oder "%1$s" (Befund 20:15 B1: deDE nutzt die Positionsangabe - gsub("%%s") ersetzte sie nicht)
                local msg = ERR_AUCTION_SOLD_S:gsub("%%%d?%$?s", (name:gsub("%%", "%%%%")))
                Se.saleFrame:GetScript("OnEvent")(Se.saleFrame, "CHAT_MSG_SYSTEM", msg)
            end)
            local got = Se.lastSale
            Se.owned, Se.lastSale = owned, last
            local said = table.concat(lines, "\n"):find(A:PlainText(L["Verkauft:"]), 1, true) ~= nil
            return got and got.itemID == LINEN and o.sold == true and said,
                string.format("Item %s, verkauft %s, Meldung %s", tostring(got and got.itemID), tostring(o.sold), tostring(said)),
                "lastSale.itemID gesetzt, o.sold, Meldung im Chat"
        end)
        end)

        B(function()
        Chk("T55", "B", "Buchhaltung aus Test-Briefkasten", function()
            local Le = A.Ledger
            local entries, seen = Copy(A.db.ledger.entries), Copy(A.db.ledger.seen)
            local mail = Copy(TM.fakeMail)
            local res = { pcall(function()
                TM:SeedMail()
                local n1 = Le:ScanInbox() or 0
                local n2 = Le:ScanInbox() or 0
                return n1 >= 2 and n2 == 0, string.format("erster Lauf %d, zweiter %d", n1, n2)
            end) }
            A.db.ledger.entries, A.db.ledger.seen = entries, seen
            wipe(TM.fakeMail); for _, m in ipairs(mail or {}) do table.insert(TM.fakeMail, m) end
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "Verkauf und Kauf gebucht, zweiter Lauf 0"
        end)
        end)

        B(function()
        Chk("T57", "B", "Neu einstellen", function()
            local X, Se = A.Extras, A.Seller
            local repost, batch = Copy(A.db.repost), Se.batch
            local res = { pcall(function()
                X:NoteReturned(FAKE + 22, 5)
                local n = X:RepostCount()
                local before = TradeCount()
                local ok, msg = X:RepostStep()
                Se.batch = batch
                return n >= 1 and TradeCount() == before, string.format("zum Neu-Einstellen %d, Klick: %s", n, tostring(msg))
            end) }
            A.db.repost = repost
            Se.batch = batch
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], ">= 1, nichts an den Server"
        end)
        end)

        B(function()
        Chk("T59", "B", "Händler-Verkauf (Kandidaten)", function()
            local list, total = A.Extras:VendorCandidates()
            local X = A.Extras
            local ok, msg = X:SellToVendor()                    -- ohne Händler: lehnt ab
            local atMerchant = X:IsAtMerchant()
            if atMerchant then X.selling = nil end
            return type(list) == "table" and (atMerchant or not ok) and Real("UseContainerItem") == 0,
                string.format("%d Kandidaten, ohne Händler abgelehnt %s", #list, tostring(not ok)), "ohne Fehler, nichts verkauft"
        end)
        if MerchantOpen() then
            Chk("T59b", "B", "Händler-Verkauf simuliert", function()
                local X = A.Extras
                local ok = X:SellToVendor()
                for _ = 1, 3 do X:SellStep() end
                X.selling = nil
                return Real("UseContainerItem") == 0, "UseContainerItem " .. Real("UseContainerItem"), "0"
            end)
        else
            Skp("T59b", "B", "Händler-Verkauf simuliert", "HALB: Händler ansprechen, dann /ahs testroutine haendler")
        end
        -- Oberfläche: eigener Knopf darf die Blizzard-Reiter "Händler" / "Rückkauf" nie verdecken
        if MerchantOpen() then
            Chk("T186", "B", "Händler-Knopf verdeckt keinen Reiter des Händlerfensters", function()
                local UI = A.UI
                if UI.UpdateVendorButton then UI:UpdateVendorButton() end
                local b = UI.vendorButton
                if not (b and b:IsShown()) then return true, "Knopf nicht sichtbar (aus oder nichts zu verkaufen)", "kein Reiter verdeckt" end
                local hit = UI:VendorButtonOverlap(b)
                return hit == nil, hit and ("verdeckt " .. hit) or "kein Reiter verdeckt", "kein Reiter verdeckt"
            end)
        else
            Skp("T186", "B", "Händler-Knopf verdeckt keinen Reiter des Händlerfensters", "HALB: Händler ansprechen, dann /ahs testroutine haendler")
        end
        end)

        B(function()
        Chk("T63", "B", "Berufe rechnen", function()
            local Cr = A.Crafting
            local p1, p2, out = FAKE + 30, FAKE + 31, FAKE + 32
            local saved = { mv = A.GetMarketValue, buy = A.GetVendorBuyPrice, sale = A.GetSalePrice, rel = A.IsReliable,
                recipes = Copy(A.db.recipes), lists = Copy(A.db.lists), api = Cr.API.ahstest }
            local res = { pcall(function()
                -- eigene Funktionen des Addons für Test-IDs umlenken (kein Blizzard-Global)
                A.GetMarketValue = function(s, id) if id == p1 then return 100 elseif id == p2 then return 300
                    elseif id == out then return 2000 end return saved.mv(s, id) end
                A.GetVendorBuyPrice = function(s, id) if id == p2 then return 50 end return saved.buy(s, id) end
                A.GetSalePrice = function(s, id) if id == out then return 2000 end return saved.sale(s, id) end
                A.IsReliable = function(s, id) if id == out then return true, { perDay = 4 } end return saved.rel(s, id) end
                local unit, atVendor = Cr:UnitPrice(p2, true)
                local key = A.Chars:Key()
                A.db.recipes[key] = A.db.recipes[key] or {}
                A.db.recipes[key]["AHS-Test"] = { t = time(), list = { { name = "AHS-Test Rezept", productID = out, made = 1,
                    reagents = { { p1, 2 }, { p2, 1 } } } } }
                local found
                for _, s in ipairs(Cr:TodaySuggestions(50)) do if s.productID == out then found = s end end
                -- Einkaufsliste über eine Test-Berufe-API (eigene Tabelle des Addons)
                Cr.API.ahstest = { info = function() return "AHS-Test Rezept", "optimal" end, link = function() return "item:" .. out end,
                    made = function() return 1, 1 end, numReagents = function() return 2 end,
                    reagent = function(_, r) local id = r == 1 and p1 or p2; return "x", r == 1 and 2 or 1, 0, "item:" .. id end,
                    title = function() return "AHS-Test Beruf" end, selected = function() return 1 end, num = function() return 1 end }
                local okL = Cr:ReagentsToList("ahstest", 1, 2)
                local exists = A.Lists:Exists("AHS-Test Beruf")
                return unit == 50 and atVendor and found and found.profit > 0 and okL and exists,
                    string.format("Händler %s/%s, Vorschlag %s, Liste %s", tostring(unit), tostring(atVendor),
                        found and A:FormatMoney(found.profit) or "nein", tostring(exists))
            end) }
            A.GetMarketValue, A.GetVendorBuyPrice, A.GetSalePrice, A.IsReliable = saved.mv, saved.buy, saved.sale, saved.rel
            A.db.recipes, A.db.lists = saved.recipes, saved.lists
            Cr.API.ahstest = saved.api
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "Händlerpreis billiger, Gewinn > 0, Liste angelegt"
        end)
        end)

        B(function()
        Chk("T65", "B", "Entzaubern lernen", function()
            local D = A.Disenchant
            local res = { pcall(TR.DESandbox, function()          -- W1: Ersatztabellen
                local prior = D:Prior(LINEN)          -- Leinenstoff: nicht entzauberbar
                local n0 = D:TotalLearned()
                local okR = pcall(D.Record, D, 2140, { { 10940, 2 } })     -- grüner Dolch -> Seltsamer Staub
                local n1 = D:TotalLearned()
                local y = D:Yield(2140)
                local v = D:GetValue(2140)
                local groups = D:Groups()
                return okR and n1 >= n0 and type(groups) == "table" and (prior == nil or prior == false or type(prior) == "table"),
                    string.format("gelernt %d -> %d, Gruppen %d, Wert %s", n0, n1, #groups, tostring(v))
            end) }
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "ohne Fehler"
        end)
        end)

        B(function()
        Chk("T66", "B", "Charaktere", function()
            local Ch = A.Chars
            local chars = Copy(A.db.chars)
            local res = { pcall(function()
                local key = Ch:Key()
                Ch:RecordMoney(); Ch:ScanBags()
                local counts = Ch:ItemCounts(LINEN)
                local total = Ch:TotalMoney()
                local days = Ch:DailyTotals(7)
                Ch:ChangeSince(1)
                A.db.chars["AHS-Test-AHS-Test"] = { name = "AHS-Test", realm = "AHS-Test", money = 1, gold = {}, bags = {}, bank = {} }
                local okRm = Ch:Remove("AHS-Test-AHS-Test")
                local okMe = Ch:Remove(key)          -- eigener Charakter: abgelehnt
                -- Name und Realm nie in den Bericht
                return type(key) == "string" and key:find("-", 1, true) ~= nil and type(counts) == "table" and type(total) == "number"
                    and type(days) == "table" and okRm and not okMe and A.db.chars["AHS-Test-AHS-Test"] == nil,
                    string.format("Schlüssel Name-Realm, %d Tage, Testcharakter entfernt %s, eigener abgelehnt %s", #days,
                        tostring(okRm), tostring(not okMe))
            end) }
            A.db.chars = chars
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "alles ohne Fehler"
        end)
        end)

        B(function()
        Chk("T69", "B", "Verkaufschance und Ablauf-Erinnerung", function()
            local K = A.Comfort
            -- Sandbox (Befund 22:25, Pfad "ownedEnds"): Ersatztabelle statt der echten Ablaufzeiten
            local ends, warned = A.db.ownedEnds, Copy(K.warned)
            A.db.ownedEnds, K.testEnds = {}, true
            local res = { pcall(function()
                K:BuildChances()
                local c = K:SellChance(LINEN)
                K:ChanceText(LINEN)
                K:OnOwnedRead({ { itemID = FAKE + 23, qty = 1, timeLeft = 1, auctionID = FAKE + 23, name = "AHS-Test" } })
                Capture(function() K:LoginExpiryCheck() end)
                K:ForgetOne(FAKE + 23)
                return c == nil or type(c) == "number" or type(c) == "table", "Chance " .. tostring(type(c))
            end) }
            A.db.ownedEnds, K.warned, K.testEnds = ends, warned, nil
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "ohne Fehler"
        end)
        end)

        B(function()
        Chk("T71", "B", "Alt-Klick ohne Alt", function()
            local UI = A.UI
            local before = UI.chartWin and UI.chartWin:IsShown()
            local r = A.Comfort:OnModifiedClick("item:" .. LINEN)
            local after = UI.chartWin and UI.chartWin:IsShown()
            return not r and (after and true or false) == (before and true or false), tostring(r), "nil, kein Fenster"
        end)
        Cli("T71b", "B", "Alt-Klick im Spiel", "Alt+Klick auf ein Taschen-Item: Preisverlauf (AH zu) bzw. Einkauf (AH offen)")
        end)

        B(function()
        Chk("T77", "B", "Sync an/aus/nur Gilde", function()
            local S = A.Sync
            local on, gOnly = S:IsEnabled() and true or false, S:GuildOnly() and true or false
            local l = Real("LeaveChannelByName")
            local t0 = S:GetStatusText()
            local res = { pcall(function()
                Capture(function() S:Toggle() end); local t1 = S:GetStatusText()
                Capture(function() S:Toggle() end)
                Capture(function() S:SetGuildOnly(not gOnly) end); local mid = S:GuildOnly() and true or false
                Capture(function() S:SetGuildOnly(gOnly) end)
                return t1 ~= t0 and mid ~= gOnly, string.format("Status %s -> %s", A:PlainText(t0), A:PlainText(t1))
            end) }
            local back = (S:IsEnabled() and true or false) == on and (S:GuildOnly() and true or false) == gOnly
            if not back then
                if (S:IsEnabled() and true or false) ~= on then Capture(function() S:Toggle() end) end
                if (S:GuildOnly() and true or false) ~= gOnly then Capture(function() S:SetGuildOnly(gOnly) end) end
            end
            if not res[1] then error(res[2], 0) end
            return res[2] and back and Real("LeaveChannelByName") == l,
                res[3], "Status ändert sich, Kanal 0, Werte wie vorher"
        end)
        end)

        -- HALB im Teil "server"
        if part ~= "server" then
            B(function()
            for _, c in ipairs({ { "T27", "Einbindung ins Auktionshaus" }, { "T37", "Warenkauf simuliert" },
                { "T42", "Sniper-Vorab-Reservierung kauft nie ohne Klick" }, { "T50", "Serie einstellen" },
                { "T52", "Unterboten" }, { "T126", "Scan-Auswertung in Portionen" } }) do
                Skp(c[1], c[1] == "T126" and "H" or "B", c[2], HALB_SERVER)
            end
            end)
        end
    end


    if want(part, "d") then B(function()
        if A.AH_LEGACY then
            Chk("T101", "D", "Alter Taschen- und Tooltip-Weg", function()
                local Se = A.Seller
                if Se.InvalidateBags then Se:InvalidateBags() end
                local items = Se:GetBagItems()
                return type(items) == "table", #items .. " Items", "Liste ohne Fehler"
            end)
            Skp("T98", "D", "Server-Wege altes AH", part == "server" and "siehe bisheriger Selbsttest (Scan, Suchen, Handel)" or HALB_SERVER)
        else
            for _, c in ipairs({ { "T98", "Server-Wege altes AH" }, { "T101", "Alter Taschen- und Tooltip-Weg" } }) do
                Skp(c[1], "D", c[2], "nur im alten Client (Classic Era, TBC)")
            end
        end
        if GetNumTradeSkills then
            Skp("T99", "D", "Alte Berufe-API", "HALB: Berufsfenster öffnen, dann /ahs testroutine berufe")
        else
            Skp("T99", "D", "Alte Berufe-API", "nur im alten Client (Classic Era, TBC)")
        end
        if A:Global("GetMerchantItemInfo") then
            Skp("T100", "D", "Alter Händler-Weg", "HALB: Händler ansprechen, dann /ahs testroutine haendler")
        else
            Skp("T100", "D", "Alter Händler-Weg", "nur im alten Client (Classic Era, TBC)")
        end
    end) end

    if want(part, "e") then
        -- InitDB mit Testdaten: echte Datenbank, Sprache und Fehler-Zählung danach zurück
        local function SmallCopy()
            local db = {}
            for k, v in pairs(A.db) do if not NO_COPY[k] then db[k] = Copy(v) end end
            db.marketData, db.names = {}, {}
            return db
        end
        local function WithTestDB(build, fn)
            local real, realOld, migr = AHSentinelDB, AHAnalyzerProDB, A.migratedFromOld
            local realDB = A.db
            AHSentinelDB, AHAnalyzerProDB = build()
            A.migratedFromOld = nil
            local res = { pcall(fn) }
            AHSentinelDB, AHAnalyzerProDB, A.migratedFromOld = real, realOld, migr
            A.db = realDB
            A:ApplyUILanguage()
            local GT = GTest()
            if GT and GT.TrackErrors then pcall(GT.TrackErrors, "AHSentinel", A.version, A.db) end
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        B(function()
        Chk("T106", "E", "Übernahme aus AH Analyzer Pro", function()
            return WithTestDB(function()
                return nil, { marketData = { [FAKE + 40] = { history = {} } }, dbVersion = 4, settings = {} }
            end, function()
                Capture(function() A:InitDB() end)
                local moved = type(AHSentinelDB) == "table" and AHSentinelDB.marketData and AHSentinelDB.marketData[FAKE + 40] ~= nil
                local mark = type(AHAnalyzerProDB) == "table" and AHAnalyzerProDB.migratedTo == "AHSentinel"
                local flag = A.migratedFromOld == true
                local first = AHSentinelDB
                A.migratedFromOld = nil
                Capture(function() A:InitDB() end)
                local again = A.migratedFromOld == true
                return moved and mark and flag and not again and AHSentinelDB == first,
                    string.format("übernommen %s, Vermerk %s, Hinweis %s, zweites Mal %s", tostring(moved), tostring(mark),
                        tostring(flag), tostring(again)), "übernommen, Vermerk, nur einmal"
            end)
        end)
        end)
        B(function()
        Chk("T107", "E", "kleine Migrationen", function()
            return WithTestDB(function()
                local db = SmallCopy()
                db.sniper.interval, db.sniper.fastSearch = 3, nil
                db.watcher.interval = 20
                db.lastScanTime = time() + 3600
                db.settings.detachedWindow, db.settings.ahIntegration = nil, true
                return db, nil
            end, function()
                Capture(function() A:InitDB() end)
                local d = A.db
                local gapOK = A.Watcher:Gap() < 20
                return d.sniper.interval == 0 and d.lastScanTime == 0 and d.settings.ahIntegration == false and gapOK,
                    string.format("Sniper %s, Scan-Zeit %s, im AH %s, Wächter-Pause %s", tostring(d.sniper.interval),
                        tostring(d.lastScanTime), tostring(d.settings.ahIntegration), tostring(A.Watcher:Gap())),
                    "0, 0, false, MIN_GAP"
            end)
        end)
        end)
        B(function()
        Chk("T108", "E", "beschädigte Einträge", function()
            return WithTestDB(function()
                local db = SmallCopy()
                db.marketData = { [1] = "kaputt", [2] = { history = nil }, [3] = { history = { { t = nil } } } }
                db.settings.lastSub = 5
                db.sniper.targets = { ["i:1"] = "x" }
                db.watcher.cats = nil
                db.vendorCost = { [1] = 5 }
                db.ledger.entries = { "x" }
                db.lists.items = db.lists.items or {}
                db.lists.items.x = 7
                db.chars = { x = true }
                db.deStats, db.sync.peers, db.recipes = nil, nil, 3
                return db, nil
            end, function()
                local errs = {}
                local function try(name, f, ...)
                    local ok, e = pcall(f, ...)
                    if not ok then errs[#errs + 1] = name .. ": " .. tostring(e):sub(1, 80) end
                end
                try("InitDB", function() Capture(function() A:InitDB() end) end)
                try("Heute tun", function() A.Comfort:TodayActions(nil, true) end)
                try("Tooltip", function() if GameTooltip and GameTooltip.SetHyperlink then
                    GameTooltip:SetOwner(UIParent, "ANCHOR_NONE"); GameTooltip:SetHyperlink("item:" .. LINEN); GameTooltip:Hide() end end)
                try("Wächter", function() A.Watcher:Tick() end)
                try("Sniper", function() A.Sniper:Tick() end)
                try("Ablauf", function() Capture(function() A.Comfort:LoginExpiryCheck() end) end)
                try("Marktliste", function() A:GetMarketValue(1); A:GetMarketValue(3); A:GetHistory(2) end)
                return #errs == 0, #errs == 0 and "kein Lua-Fehler" or table.concat(errs, " | "), "kein Lua-Fehler"
            end)
        end)
        end)
    end

    if want(part, "g") then B(function()
        if type(_G.ProfessionSentinelAPI) == "table" and _G.ProfessionSentinelAPI.version == 1 then
            Chk("T119", "G", "echtes ProfessionSentinel geladen", function()
                local ok, rows = pcall(A.Comfort.TodayActions, A.Comfort, nil, true)
                return ok, ok and (#(rows or {}) .. " Zeilen in Heute tun") or tostring(rows), "ohne Fehler"
            end)
        else
            Skp("T119", "G", "echtes ProfessionSentinel geladen", "HALB: ProfessionSentinel zusätzlich aktivieren")
        end
        local other = (C_AddOns and C_AddOns.IsAddOnLoaded or IsAddOnLoaded)
        local has = other and (other("Auctionator") or other("TradeSkillMaster"))
        if has and A:IsAHOpen() then
            Chk("T120", "G", "fremde AH-Addons", function()
                return A.UI.ahLastError == nil, tostring(A.UI.ahLastError), "kein UI.ahLastError"
            end)
        else
            Skp("T120", "G", "fremde AH-Addons", "HALB: Auctionator oder TSM aktiv und Auktionshaus offen")
        end
    end) end

    if want(part, "h") then
        B(function()
        if not (GameTooltip and GameTooltip.SetHyperlink and GameTooltip.SetOwner) then
            return Skp("T122", "H", "Tooltip schnell", "GameTooltip fehlt")
        end
        Chk("T122", "H", "Tooltip schnell", function()
            local st = A.db.settings
            local chart = st.tooltipChart
            -- wie im Spiel mit dem Zwischenspeicher je Item (Befund 22:25 Punkt 3)
            local TT = A.Tooltip
            if TT then TT.testCache = true; TT.prof = {} end
            local t0 = Ms()
            local okL, errL = pcall(function()
                for _ = 1, 100 do
                    GameTooltip:SetOwner(UIParent, "ANCHOR_NONE"); GameTooltip:SetHyperlink("item:" .. LINEN); GameTooltip:Hide()
                end
            end)
            local per = (Ms() - t0) / 100
            -- N3: Zeit je Block (AHSentinel-Zeilen, Diagramm) - der Rest gehört Blizzards Tooltip selbst
            local pr = TT and TT.prof or {}
            local profText = (pr.n or 0) > 0 and string.format(" (davon Zeilen %.2f, Diagramm %.2f ms)", (pr.lines or 0) / pr.n, (pr.chart or 0) / pr.n) or ""
            if TT then TT.testCache = nil; TT.prof = nil; if TT.InvalidateCache then TT:InvalidateCache() end end
            if not okL then error(errL, 0) end
            return per < 2, string.format("%.2f ms je Aufruf", per) .. profText, "< 2 ms"
        end)
        end)
        B(function()
        if not A.Crafting.kind then
            return Skp("T124", "H", "Berufsliste (Zwischenspeicher)", "HALB: Berufsfenster öffnen, dann /ahs testroutine berufe")
        end
        Chk("T124", "H", "Berufsliste (Zwischenspeicher)", function()
            local Cr = A.Crafting
            local t0 = Ms(); Cr:ReadAll(Cr.kind); local a = Ms() - t0
            t0 = Ms(); Cr:ReadAll(Cr.kind); local b = Ms() - t0
            return Cr.kind ~= "modern" or b < 2, string.format("erstes Mal %.1f ms, zweites Mal %.1f ms", a, b), "zweites Mal < 2 ms"
        end)
        end)
    end

    if want(part, "j") then
        B(function()
        Chk("T146", "J", "KO 5a: leere Rezeptliste nicht gemerkt", function()
            local Cr = A.Crafting
            local kind, at, rem = Cr.kind, Cr.rememberedAt, Cr.Remember
            local res = { pcall(function()
                Cr.kind, Cr.rememberedAt = "modern", nil
                Cr.Remember = function() return 0 end
                Cr.evt:GetScript("OnEvent")(Cr.evt, "TRADE_SKILL_LIST_UPDATE")
                local empty = Cr.rememberedAt
                Cr.Remember = function() return 3 end
                Cr.evt:GetScript("OnEvent")(Cr.evt, "TRADE_SKILL_LIST_UPDATE")
                local full = Cr.rememberedAt
                return empty == nil and full ~= nil, string.format("leer %s, voll %s", tostring(empty), full and "gesetzt" or "nil")
            end) }
            Cr.kind, Cr.rememberedAt, Cr.Remember = kind, at, rem
            if Cr.panel and not kind then Cr.panel:Hide() end
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "leer nil, voll gesetzt"
        end)
        end)
        B(function()
        local Cr0 = A.Crafting
        if not (Cr0.ModernRecipeID and Cr0:TradeKind() == "modern" and Cr0:ModernRecipeID(1)) then
            return Skp("T147", "J", "KO 5b: Zutaten-Knopf ohne SchematicForm", "HALB: Berufsfenster (moderner Client) öffnen, dann /ahs testroutine berufe")
        end
        Chk("T147", "J", "KO 5b: Zutaten-Knopf ohne SchematicForm", function()
            local Cr = A.Crafting
            local last = Cr.lastModernRecipe
            local id = Cr:ModernRecipeID(1)
            Cr:OnRecipeSelected({ recipeID = id })
            local got = Cr.API.modern.selected()
            Cr.lastModernRecipe = last
            return got ~= nil, tostring(got), "Index des zuletzt gewählten Rezepts"
        end)
        end)
        B(function()
        if not (A.Crafting:TradeKind() == "modern" and A.Crafting:SchematicCacheSize() > 0) then
            return Skp("T148", "J", "KO 5c: Zwischenspeicher bleibt bei Listen-Ereignissen", "HALB: Berufsfenster (moderner Client) öffnen, dann /ahs testroutine berufe")
        end
        Chk("T148", "J", "KO 5c: Zwischenspeicher bleibt bei Listen-Ereignissen", function()
            local Cr = A.Crafting
            Cr.evt:GetScript("OnEvent")(Cr.evt, "TRADE_SKILL_LIST_UPDATE")
            local n1 = Cr:SchematicCacheSize()
            Cr.evt:GetScript("OnEvent")(Cr.evt, "TRADE_SKILL_LIST_UPDATE")
            local n2 = Cr:SchematicCacheSize()
            return n2 >= n1, string.format("%d -> %d Einträge", n1, n2), "nicht geleert"
        end)
        end)
        B(function()
        Chk("T159", "J", "GetDockFrame liefert den sichtbaren Frame bzw. nil", function()
            local Cr = A.Crafting
            if not Cr.GetDockFrame then return false, "Funktion fehlt", "AHAnalyzerPro.Crafting:GetDockFrame()" end
            local had, shown = Cr.panel ~= nil, Cr.panel and Cr.panel:IsShown()
            local res = { pcall(function()
                local f = Cr:EnsurePanel()
                f:Show(); local a = Cr:GetDockFrame()
                f:Hide(); local b = Cr:GetDockFrame()
                return a == f and b == nil, string.format("sichtbar: %s, versteckt: %s", a == f and "Frame" or tostring(a), tostring(b))
            end) }
            if Cr.panel then if shown then Cr.panel:Show() else Cr.panel:Hide() end end
            if not had and Cr.panel and not shown then Cr.panel:Hide() end
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "sichtbar: Frame, versteckt: nil"
        end)
        end)
        B(function()
        Chk("T160", "J", "Gewinn-Fenster neben der Reiterleiste, nie darüber", function()
            local Cr = A.Crafting
            -- eigene Testrahmen: "Berufsfenster" mit einer Reiterleiste, die rechts 40 Punkte herausragt
            local p = self.dockTestParent
            if not p then
                p = CreateFrame("Frame", nil, UIParent); p:SetSize(400, 300)
                local tabs = CreateFrame("Frame", nil, p); tabs:SetSize(44, 200)
                tabs:SetPoint("TOPLEFT", p, "TOPRIGHT", -4, -40)
                p.tabs = tabs
                self.dockTestParent = p
            end
            p:ClearAllPoints(); p:SetPoint("CENTER", UIParent, "CENTER", -300, 0); p:Show(); p.tabs:Show()
            local f = Cr:EnsurePanel()
            local wasShown, wasOffset = f:IsShown(), Cr.dockOffset
            local res = { pcall(function()
                Cr:Dock(f, p)
                local withTabs = Cr.dockOffset
                local fl = f:GetLeft() and f:GetLeft() * f:GetEffectiveScale()
                local tr = p.tabs:GetRight() * p.tabs:GetEffectiveScale()
                p.tabs:Hide()
                p:SetHitRectInsets(0, 0, 0, 0)
                Cr:Dock(f, p)
                local without = Cr.dockOffset
                -- altes Berufsfenster mit 34 Punkten unsichtbarem Rand: seit Punkt 10 (offen-ahsentinel) gilt x >= 0,
                -- nie über dem Fenster oder den Reitern (Entscheid der Prüf-Sitzung 9. Nov. 09:35)
                p:SetHitRectInsets(0, 34, 0, 0)
                Cr:Dock(f, p)
                local inset = Cr.dockOffset
                return fl and fl >= tr and without == 0 and inset and inset >= 0,
                    string.format("mit Reitern %+.0f (links %.0f, Reiter rechts %.0f), ohne Rand %+.0f, mit Rand 34 %+.0f",
                    withTabs or 0, fl or -1, tr, without or 0, inset or 0)
            end) }
            p:SetHitRectInsets(0, 0, 0, 0)
            p:Hide()
            -- echte Lage wiederherstellen
            Cr.dockOffset = wasOffset
            if Cr.kind and Cr.API[Cr.kind] then Cr:Dock(f, Cr.API[Cr.kind].frame()) end
            if not wasShown then f:Hide() end
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "linke Kante >= rechte Kante der Reiter; ohne Rand 0, mit Rand 34 -> x >= 0"
        end)
        end)
        B(function()
        Chk("T163", "J", "GetDockFrame(true) auch verborgen", function()
            local Cr = A.Crafting
            local had, shown = Cr.panel, Cr.panel and Cr.panel:IsShown()
            local res = { pcall(function()
                local f = Cr:EnsurePanel()
                f:Hide()
                local a, b = Cr:GetDockFrame(true), Cr:GetDockFrame()
                f:Show()
                local c, d = Cr:GetDockFrame(true), Cr:GetDockFrame()
                return a == f and b == nil and c == f and d == f,
                    string.format("verborgen: (true) %s / () %s, sichtbar: %s / %s", a == f and "Frame" or "nil",
                        b == f and "Frame" or "nil", c == f and "Frame" or "nil", d == f and "Frame" or "nil")
            end) }
            if Cr.panel then if shown then Cr.panel:Show() else Cr.panel:Hide() end end
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "verborgen: Frame / nil, sichtbar: Frame / Frame"
        end)
        end)
        B(function()
        Chk("T162", "J", "Preisfeld g/s/c in allen Sprachen, nie k", function()
            local lang = A.uiLang
            local bad = {}
            local ok, err = pcall(function()
                for _, l in ipairs({ "deDE", "enUS", "frFR", "esES", "esMX", "ptBR", "itIT", "ruRU", "koKR", "zhCN", "zhTW" }) do
                    A.uiLang = l
                    local a, b = A:FormatMoneyInput(78), A:FormatMoneyInput(390)
                    if a ~= "78c" or b ~= "3s 90c" then bad[#bad + 1] = l .. ": " .. a .. " / " .. b end
                end
            end)
            A.uiLang = lang
            if not ok then error(err, 0) end
            for text, want in pairs({ ["78"] = 780000, ["78c"] = 78, ["1s 20c"] = 120, ["1g"] = 10000, ["78k"] = 78 }) do
                if A:ParseGold(text) ~= want then bad[#bad + 1] = text .. " -> " .. tostring(A:ParseGold(text)) end
            end
            return #bad == 0, #bad == 0 and "78c, 3s 90c; Eingaben verstanden" or table.concat(bad, "; "),
                "78c / 3s 90c; 78=78g, 78c, 1s 20c, 1g, 78k=78c"
        end)
        end)
        B(function()
        local AC = _G.AuctionCategories
        if not (type(AC) == "table" and #AC > 0) then
            return Skp("T161", "J", "Kategorien wie im Blizzard-AH", "HALB: Auktionshaus einmal öffnen (lädt die Blizzard-Kategorien)")
        end
        Chk("T161", "J", "Kategorien wie im Blizzard-AH", function()
            local Bu = A.Buy
            Bu:BuildCategories()
            -- unsere Liste: Hauptkategorie -> Namen der Unterkategorien in Reihenfolge
            local mine, order = {}, {}
            for _, c in ipairs(Bu.CATS) do
                if c.key ~= "all" and not c.level then mine[c.key] = { name = Bu:CatText(c), subs = {} }; order[#order + 1] = c.key
                elseif c.level and c.parent and mine[c.parent] then table.insert(mine[c.parent].subs, Bu:CatText(c)) end
            end
            local bad, i = {}, 0
            for _, cat in ipairs(AC) do
                local hasClass = false
                for _, f in ipairs(cat.filters or {}) do if type(f) == "table" and f.classID then hasClass = true end end
                if cat.name and hasClass and not cat.implicitFilter then
                    i = i + 1
                    local m = mine[order[i] or ""]
                    if not m or m.name ~= cat.name then bad[#bad + 1] = cat.name .. ": fehlt/Reihenfolge"
                    else
                        local want = {}
                        for _, sub in ipairs(cat.subCategories or {}) do
                            local sh = false
                            for _, f in ipairs(sub.filters or {}) do if type(f) == "table" and f.classID then sh = true end end
                            if sub.name and sh then want[#want + 1] = sub.name end
                        end
                        if table.concat(want, "|") ~= table.concat(m.subs, "|") then
                            bad[#bad + 1] = string.format("%s: %d statt %d Unterkategorien", cat.name, #m.subs, #want)
                        end
                    end
                end
            end
            return #bad == 0, #bad == 0 and (i .. " Hauptkategorien gleich") or table.concat(bad, "; "), "gleich wie das Blizzard-AH"
        end)
        end)
        -- Klick auf ein Rezept (0.65.12): Test-Berufsliste über eine eigene Tabelle des Addons (Cr.API.ahstest)
        local function FakeProfession(opts)
            local st = { filtered = opts.filtered, collapsed = opts.collapsed, sel = nil, reveals = 0 }
            local names = { "AHS-Test A", "AHS-Test B", "AHS-Test C" }
            local function visible()
                local out = {}
                for _, n in ipairs(names) do
                    if not ((st.filtered and n ~= "AHS-Test A") or (st.collapsed and n == "AHS-Test C")) then out[#out + 1] = n end
                end
                return out
            end
            st.api = {
                num = function() return #visible() end,
                info = function(i) return visible()[i], "optimal" end,
                link = function() return nil end, made = function() return 1, 1 end, numReagents = function() return 0 end,
                reagent = function() return nil end, title = function() return "AHS-Test Beruf" end,
                selected = function() return st.sel end,
                select = function(i) st.sel = i end,
                find = function(r) for i, n in ipairs(visible()) do if n == r.name then return i end end end,
                reveal = function() st.filtered, st.collapsed, st.reveals = false, false, st.reveals + 1 end,
                frame = function() return nil end,
            }
            return st
        end
        local function RunSelect(id, name, opts, target)
            B(function()
                local Cr = A.Crafting
                local st = FakeProfession(opts)
                Cr.API.ahstest = st.api
                self.selTest = { st = st, lines = {}, real = A.Print }
                A.Print = function(_, msg) table.insert(self.selTest.lines, A:PlainText(tostring(msg))) end
                Cr:SelectRecipe({ kind = "ahstest", name = target, index = 3 })
                return "WAIT", function() return Cr.pendingSelect == nil end, 3, function()
                    local t = self.selTest
                    self.selTest = nil
                    A.Print = t.real
                    Cr.API.ahstest = nil
                    Chk(id, "J", name, function()
                        local n = t.st.sel and t.st.api.info(t.st.sel)
                        return n == target, string.format("gewählt %s, Filter zurückgesetzt %d-mal, Meldungen %d", tostring(n),
                            t.st.reveals, #t.lines), target
                    end)
                end
            end)
        end
        RunSelect("T165", "Suchtext im Berufsfenster aktiv: Klick öffnet trotzdem das Rezept", { filtered = true }, "AHS-Test B")
        RunSelect("T166", "Rezept in zugeklappter Kategorie: wird geöffnet", { collapsed = true }, "AHS-Test C")
        B(function()
        Chk("T164", "J", "kein Rahmen verdeckt eine Rezept-Zeile", function()
            local Cr = A.Crafting
            local f = Cr:EnsurePanel()
            local wasShown = f:IsShown()
            f:Show()
            local bad, checked = {}, 0
            local res = { pcall(function()
                for _, row in ipairs(f.top.rows or {}) do
                    local l, b, w, h = row:GetRect()
                    if l and w and w > 0 then
                        checked = checked + 1
                        local cx, cy = l + w / 2, b + h / 2
                        local function scan(fr, depth)
                            if depth > 5 then return end
                            for _, c in ipairs({ fr:GetChildren() }) do
                                if c ~= row and c:IsShown() then
                                    local isAncestor = false
                                    local p2 = row:GetParent()
                                    while p2 do if p2 == c then isAncestor = true end p2 = p2:GetParent() end
                                    local cl, cb, cw, ch = c:GetRect()
                                    if not isAncestor and cl and cx >= cl and cx <= cl + cw and cy >= cb and cy <= cb + ch
                                        and c.IsMouseEnabled and c:IsMouseEnabled() and c:GetFrameLevel() >= row:GetFrameLevel()
                                        and not (row:GetParent() == c:GetParent() and c:GetObjectType() == "Button") then
                                        bad[#bad + 1] = tostring(c:GetName() or c:GetObjectType())
                                    end
                                    scan(c, depth + 1)
                                end
                            end
                        end
                        scan(f, 1)
                    end
                end
            end) }
            if not wasShown then f:Hide() end
            if not res[1] then error(res[2], 0) end
            return #bad == 0, string.format("%d Zeilen geprüft, verdeckt: %s", checked, #bad == 0 and "keine" or table.concat(bad, ", ")),
                "keine fremden Rahmen mit Maus über den Zeilen"
        end)
        end)
        -- 20 Ereignisse in 1 s -> höchstens 3 Aufbauten; Klick während des Aufbaus öffnet das Rezept; < 16 ms pro Frame
        B(function()
            local Cr = A.Crafting
            local st = FakeProfession({})
            Cr.API.ahstest = st.api
            local f = Cr:EnsurePanel()
            self.thr = { st = st, kind = Cr.kind, shown = f:IsShown(), builds = Cr.topBuilds, t0 = GetTime(), n = 0,
                measure = A.jobMeasure }
            A.jobMeasure = { max = 0, frames = 0 }
            Cr.kind = "ahstest"
            f:Show()
            return "WAIT", function()
                local t = self.thr
                -- je Abfrage (alle 0,25 s) 5 Ereignisse: 20 in rund 1 s
                for _ = 1, 5 do
                    if t.n < 20 then
                        t.n = t.n + 1
                        A.priceVersion = (A.priceVersion or 0) + 1   -- Daten ändern sich wirklich (Prüfsumme; ohne Änderung kein Aufbau)
                        Cr:RequestRefresh(true, "AHS-Test")
                        if t.n == 10 then Cr:SelectRecipe({ kind = "ahstest", name = "AHS-Test B", index = 2 }) end
                    end
                end
                return GetTime() - t.t0 >= 1.5 and not Cr.refreshPlanned and not Cr.topBuilding
            end, 6, function()
                local t = self.thr
                self.thr = nil
                local builds = Cr.topBuilds - t.builds
                local m = A.jobMeasure
                A.jobMeasure = t.measure
                Cr.kind = t.kind
                Cr.API.ahstest = nil
                Cr.pendingSelect = nil
                if not t.shown then f:Hide() end
                Cr.topDirty = true
                Chk("T167", "J", "Ereignisse gesammelt: höchstens 3 Neuaufbauten", function()
                    return builds >= 1 and builds <= 3, string.format("%d Ereignisse, %d Aufbauten", t.n, builds), "1 bis 3"
                end)
                Chk("T168", "J", "Klick während des Aufbaus öffnet das Rezept", function()
                    local n = t.st.sel and t.st.api.info(t.st.sel)
                    return n == "AHS-Test B", tostring(n), "AHS-Test B"
                end)
                Chk("T169", "H", "Aufbau der Rangliste < 16 ms pro Frame", function()
                    -- W3: nur die Aufgabe "craft-top" bewerten; andere Aufgaben im selben Zeitraum nur nennen
                    local own = m.jobs and m.jobs["craft-top"] or 0
                    local others = {}
                    for k, v in pairs(m.jobs or {}) do if k ~= "craft-top" and v >= 16 then others[#others + 1] = string.format("%s %.1f ms", k, v) end end
                    return own < 16, string.format("längste Portion Rangliste %.1f ms%s", own,
                        #others > 0 and (" · andere Aufgaben: " .. table.concat(others, ", ")) or ""), "< 16 ms"
                end)
                -- Punkt 4 (Nachprüfung 10.11. 14:35): keine Hintergrund-Aufgabe ≥ 16 ms je Frame (FEHLER, nicht nur nennen)
                Chk("T373", "H", "Keine Hintergrund-Aufgabe ≥ 16 ms je Frame (während des Ranglisten-Aufbaus)", function()
                    local bad, worst = {}, 0
                    for k, v in pairs(m.jobs or {}) do
                        if v > worst then worst = v end
                        if v >= 16 then bad[#bad + 1] = string.format("%s %.1f ms", k, v) end
                    end
                    return #bad == 0, #bad == 0 and string.format("längste %.1f ms", worst) or ("zu lang: " .. table.concat(bad, ", ")), "alle < 16 ms"
                end)
            end
        end)
        B(function()
        Chk("T170", "J", "Forever wie klassisch: 5 % beim Verkauf, Einzahlung zurück, Gewinn-Fenster gleich wie Era", function()
            local g2 = G()
            if not (g2 and g2.SetTestFlavor) then return false, "SetTestFlavor fehlt" end
            local Cr = A.Crafting
            local p1, out = FAKE + 50, FAKE + 51
            local saved = { mv = A.GetMarketValue, api = Cr.API.ahstest, force = A.forceForever }
            local res = { pcall(function()
                A.GetMarketValue = function(sf, id) if id == p1 then return 1000 elseif id == out then return 2000 end return saved.mv(sf, id) end
                Cr.API.ahstest = { info = function() return "AHS-Test Kettenhose", "optimal" end, link = function() return "item:" .. out end,
                    made = function() return 1, 1 end, numReagents = function() return 1 end,
                    reagent = function() return "x", 1, 0, "item:" .. p1 end, title = function() return "AHS-Test" end,
                    selected = function() return 1 end, select = function() end, num = function() return 1 end }
                A.forceForever = nil
                g2.SetTestFlavor("forever")
                local f20, f300 = A:SaleFee(nil, 20, 1), A:SaleFee(nil, 6000, 1)
                local rf = Cr:ReadRecipe("ahstest", 1)
                g2.SetTestFlavor("era")
                local re = Cr:ReadRecipe("ahstest", 1)
                local refunded = A:DepositRefunded()
                g2.SetTestFlavor(nil)
                -- Gebühren klassisch (0.65.42): 2000 - 5 % = 1900 - 1000 Material = 900 (ohne Daten kein Einzahlungsverlust); Era 900
                -- R1 (Befund 0.65.65): Forever zeigt die Einzahlung (mind. 1s, zurück beim Verkauf) - nicht im Gewinn
                return f20 == 1 and f300 == 300 and (rf.deposit or 0) == A:MinDeposit() and rf.profit == 900 and re.profit == 900 and refunded,
                    string.format("20c -> %s, 3s -> %s, Gewinn Forever %s (Gebühr %s), Era %s", A:FormatMoneyInput(f20),
                        A:FormatMoneyInput(f300), A:FormatMoneyInput(rf.profit), A:FormatMoneyInput(rf.deposit), A:FormatMoneyInput(re.profit))
            end) }
            A.GetMarketValue, Cr.API.ahstest, A.forceForever = saved.mv, saved.api, saved.force
            if g2.SetTestFlavor then g2.SetTestFlavor(nil) end
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "1c, 3s, Forever 9s (Einzahlung 1s, zurück bei Verkauf), Era 9s"
        end)
        end)
        B(function()
        Chk("T171", "J", "Klick ohne vorherigen Klick: Rezept sofort gewählt (Befund 5. Nov., 50 s)", function()
            local Cr = A.Crafting
            local st = FakeProfession({})
            Cr.API.ahstest = st.api
            local res = { pcall(function()
                Cr.lastClick = nil
                Cr:SelectRecipe({ kind = "ahstest", name = "AHS-Test C", index = 3 })
                local c = Cr.lastClick
                local n = st.sel and st.api.info(st.sel)
                return Cr.pendingSelect == nil and c and c.ok and c.ms < 500 and n == "AHS-Test C",
                    string.format("gleich gewählt: %s, %s ms, Weg %s", tostring(n), c and tostring(c.ms) or "-", c and tostring(c.way) or "-")
            end) }
            Cr.API.ahstest = nil
            Cr.pendingSelect = nil
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "im selben Aufruf gewählt, < 500 ms"
        end)
        end)
        B(function()
        Chk("T172", "J", "Diagnose-Protokoll: Einträge, Zähler, GSDIAG1, keine Namen", function()
            local Dg = A.Diag
            if not Dg then return false, "Diag.lua fehlt", "A.Diag" end
            local d = Dg.Store()
            local saved = Copy(d)
            local res = { pcall(function()
                d.entries = {}
                Dg:Add("KLICK", "Rezept AHS-Test · Rezept-ID 1", 12)
                Dg:Add("KLICK", "Rezept AHS-Test · Rezept-ID 1", 30)
                Dg:Error("AHS-Test", "Fehler x"); Dg:Error("AHS-Test", "Fehler x")
                A:Fire("CRAFT_TOP_BUILT", "TRADE_SKILL_LIST_UPDATE", 5, 3)
                local text = Dg:Text()
                local exp = Dg:Export()
                local me = UnitName and UnitName("player")
                local realm = GetRealmName and GetRealmName()
                -- Kopfzeilen (Client-Version, z. B. "WoW Forever") nicht mitprüfen: der Realm kann gleich heissen wie die Spielversion
                local body = text:gsub("^[^\n]*\n[^\n]*\n", "")
                local leak = (me and me ~= "" and text:find(me, 1, true)) or (realm and realm ~= "" and body:find(realm, 1, true))
                local klick, fehler = d.entries[3], d.entries[2]
                return klick and klick.n == 2 and klick.ms == 30 and fehler and fehler.n == 2 and d.entries[1].k == "AUFBAU"
                    and exp:sub(1, 19) == "GSDIAG1|AHSentinel|" and not leak,
                    string.format("%d Einträge, KLICK x%s (%s ms), FEHLER x%s, Export %s, Name im Text: %s", #d.entries,
                        tostring(klick and klick.n), tostring(klick and klick.ms), tostring(fehler and fehler.n), exp:sub(1, 19), leak and "JA" or "nein")
            end) }
            Replace(d, saved)
            self:ClearTestErrors()
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "gezählt, GSDIAG1|AHSentinel|, keine Namen"
        end)
        end)
        -- Befund 5. Nov.: Klick wählt erst nach 50 s -> spätestens nach 0,5 s entschieden, mit Meldung
        B(function()
            local Cr = A.Crafting
            local st = FakeProfession({})
            st.api.select = function() end                  -- das Berufsfenster reagiert nicht
            Cr.API.ahstest = st.api
            self.t173 = { lines = {}, real = A.Print, t0 = GetTime() }
            A.Print = function(_, msg) table.insert(self.t173.lines, A:PlainText(tostring(msg))) end
            Cr.lastClick = nil
            Cr:SelectRecipe({ kind = "ahstest", name = "AHS-Test B", index = 2 })
            return "WAIT", function() return Cr.pendingSelect == nil end, 3, function()
                local t = self.t173
                self.t173 = nil
                A.Print = t.real
                Cr.API.ahstest = nil
                Cr.pendingSelect = nil
                local secs = GetTime() - t.t0
                Chk("T173", "J", "Rezept wählt sich nicht: nach höchstens 0,5 s Meldung statt 50 s warten", function()
                    local c = Cr.lastClick
                    return c and c.ok == false and secs <= 1 and #t.lines >= 1,
                        string.format("entschieden nach %.2f s, Meldungen %d", secs, #t.lines), "<= 0,5 s (Takt 0,25 s), 1 Meldung"
                end)
            end
        end)
        B(function()
            if not modern then return end
            for _, c in ipairs({
                { "T175", "Rezept im ProfessionSentinel-Panel ohne vorherigen AHSentinel-Klick anklicken: Berufsfenster zeigt es in < 0,5 s (/ahs protokoll: KLICK ... gewählt)" },
                { "T176", "Rezept in AHSentinel \"Beste Rezepte\" anklicken, auch mit Suchtext im Berufsfenster: sofort gewählt, kein Chat-Hinweis" },
                { "T177", "Berufsfenster mit AHSentinel und ProfessionSentinel öffnen: nebeneinander, Berufsreiter frei, /ahs protokoll ohne ÜBERLAPPT" },
                { "T178", "Kupferne Kettenhose im Gewinn-Fenster: 18c Gewinn, Zeile Einstellgebühr 1s" },
                { "T179", "Auktionshaus öffnen, Einkauf -> Waffen: Unterkategorien gleich wie im Blizzard-AH" },
            }) do Cli(c[1], "J", "Im Spiel", c[2]) end
        end)
        B(function()
        Chk("T180", "J", "Köderwerte: Rezept-Auswahl und Protokoll verarbeiten geschützte Werte nicht", function()
            local Cr, Dg = A.Crafting, A.Diag
            local last = Cr.lastModernRecipe
            local d = Dg and Dg.Store()
            local n0 = d and #d.entries or 0
            local ok, err = WithSecret(function()
                Cr:OnRecipeSelected(SECRET)
                if Dg then Dg:Add("KLICK", SECRET, 5); Dg:Add("KLICK", "AHS-Test", SECRET) end
            end)
            local changed = Cr.lastModernRecipe ~= last
            Cr.lastModernRecipe = last
            local n1 = d and #d.entries or 0
            if not ok then error(err, 0) end
            return not changed and n1 == n0, string.format("Auswahl geändert %s, neue Einträge %d", tostring(changed), n1 - n0),
                "keine Wirkung, kein Lua-Fehler"
        end)
        end)
        -- 0.65.17: Einstellgebühr messen, Warnung, "Heute tun" unter Händlerpreis
        local FAKE_ID = 999990017
        B(function()
        Chk("T181", "J", "Gebühren klassisch (T-G1 bis T-G4): Einzahlung aus Händlerpreis 2/8/24 Std., mind. 1s; 5 % beim Verkauf; erwartete Kosten", function()
            local saved = { force = A.forceForever, vp = A.GetVendorPrice, el = A.ExpectedListings, dd = A.DefaultDuration, open = A.IsAHOpen,
                eh = A.EvalHours }
            A.EvalHours = function() return 24 end          -- 0.65.68: Bewertungs-Laufzeit (Punkt 1) fest 24 Std. für diesen Test
            local res = { pcall(function()
                A.forceForever = true
                A.IsAHOpen = function() return false end            -- Formel, nicht Blizzards Wert
                local vendor = 40
                A.GetVendorPrice = function() return vendor end
                local g1 = { (A:ListingDeposit(FAKE_ID, 20, 2)), (A:ListingDeposit(FAKE_ID, 20, 8)), (A:ListingDeposit(FAKE_ID, 20, 24)) }
                vendor = 1
                local g2 = { (A:ListingDeposit(FAKE_ID, 20, 2)), (A:ListingDeposit(FAKE_ID, 20, 8)), (A:ListingDeposit(FAKE_ID, 20, 24)) }
                local g3 = A:SaleFee(FAKE_ID, 4042, 1)
                -- T-G4: erwartete Kosten einer Auktion: p = 1 -> nur 5 %, p = 0,5 -> 5 % + Einzahlung
                vendor = 40
                local realSizes = A.db.settings.auctionSize            -- Sandbox (Befund 20:15 A2): echte Tabelle nie anfassen
                A.db.settings.auctionSize = { [FAKE_ID] = 20 }         -- 20 Stück in EINER Auktion
                A.DefaultDuration = function() return 24 end
                A.ExpectedListings = function() return 1 end
                local c1 = A:AuctionFee(2000, FAKE_ID, 20)
                A.ExpectedListings = function() return 2 end
                local c2 = A:AuctionFee(2000, FAKE_ID, 20)
                A.db.settings.auctionSize = realSizes
                A.forceForever = false
                local era = A:SaleFee(FAKE_ID, 200, 1)
                return table.concat(g1, "/"), table.concat(g2, "/"), g3, c1, c2, era
            end) }
            A.forceForever, A.GetVendorPrice, A.ExpectedListings, A.DefaultDuration, A.IsAHOpen = saved.force, saved.vp, saved.el, saved.dd, saved.open
            A.EvalHours = saved.eh
            if not res[1] then error(res[2], 0) end
            local got = string.format("%s · %s · %s · %s/%s · Era %s", res[2], res[3], tostring(res[4]), tostring(res[5]), tostring(res[6]), tostring(res[7]))
            return got == "100/160/480 · 100/100/100 · 202 · 100/580 · Era 10", got, "100/160/480 · 100/100/100 · 202 · 100/580 · Era 10"
        end)
        end)
        B(function()
        Chk("T182", "J", "Gebühr beim Einstellen: Protokoll EINSTELLEN mit Preis, Menge, Gebühr, ohne Namen", function()
            local Se, Dg = A.Seller, A.Diag
            local d = Dg and Dg.Store()
            local n0 = d and #d.entries or 0
            local saveMin, saveMeasure = A.db.minDeposit, Se.MeasureMinDeposit
            Se.MeasureMinDeposit = function() end                           -- Test lernt kein Minimum
            local ok, err = pcall(Se.RecordDeposit, Se, { itemID = FAKE_ID, qty = 5, auctions = 1, unitPrice = 1000, duration = 2, deposit = 250 }, 250)
            Se.MeasureMinDeposit, A.db.minDeposit = saveMeasure, saveMin
            local e = d and #d.entries > n0 and d.entries[1]
            local text = e and (tostring(e.k) .. " " .. tostring(e.t)) or ""
            if e then table.remove(d.entries, 1) end
            if not ok then error(err, 0) end
            local fields = text:find("EINSTELLEN", 1, true) and text:find(tostring(FAKE_ID), 1, true) and text:find("5000", 1, true)
                and text:find("250", 1, true) and text:find("5.00", 1, true)
            local noName = not (UnitName and text:find(UnitName("player") or "\0", 1, true))
            return (not Dg) or (fields and noName and true or false), "Eintrag: " .. text, "Item, Menge 5, 5000 gesamt, Gebühr 250 (5.00 %)"
        end)
        end)
        B(function()
        Chk("T183", "J", "Einstellgebühr: Warnung ab 10 % vom Preis (einstellbar, 0 = aus)", function()
            local Se, st = A.Seller, A.db.settings
            local saved = st.feeWarnPct
            st.feeWarnPct = nil
            local a = Se:FeeTooHigh(200, 1000, 1)     -- 20 %
            local b = Se:FeeTooHigh(50, 1000, 1)      -- 5 %
            local c = Se:FeeTooHigh(150, 100, 10)     -- 15 % bei Menge 10
            st.feeWarnPct = 0
            local d = Se:FeeTooHigh(900, 1000, 1)
            st.feeWarnPct = saved
            return a and b == nil and c and d == nil and true or false,
                string.format("20%%: %s, 5%%: %s, 15%% Menge 10: %s, aus: %s", tostring(a), tostring(b), tostring(c), tostring(d)), "Warnung, keine, Warnung, keine"
        end)
        end)
        B(function()
        Chk("T184", "J", "Heute tun: Angebot unter Händlerpreis ergibt Zeile mit richtigem Gewinn, sonst keine", function()
            local Bu, db = A.Buy, A.db
            local saved = { md = db.marketData, res = Bu.results, rt = Bu.resultsTime, det = Bu.detail, vp = db.vendorPrices[FAKE_ID],
                vp2 = db.vendorPrices[FAKE_ID + 1], min = db.settings.vendorFlipMin }
            for k = 0, 150 do A.vendorChecked[FAKE_ID + k] = true end   -- HP1: Händlerpreis vom Spiel bestätigt (Test)
            local res = { pcall(function()
                db.marketData, Bu.results = {}, {}
                db.vendorPrices[FAKE_ID] = 80
                Bu.detail = { itemID = FAKE_ID, commodity = true, time = time(), listings = { { price = 50, qty = 5, ownQty = 0 } } }
                local r1 = A:VendorFlipOffers(0, 10)
                local r1def = A:VendorFlipOffers(nil, 10)                -- Standard 10 Silber: 1s 50c reicht nicht
                Bu.detail.listings = { { price = 90, qty = 5, ownQty = 0 } }
                local r2 = A:VendorFlipOffers(0, 10)
                db.vendorPrices[FAKE_ID + 1] = nil
                Bu.detail = { itemID = FAKE_ID + 1, commodity = true, time = time(), listings = { { price = 1, qty = 5, ownQty = 0 } } }
                local okNoVendor = (A:GetVendorPrice(FAKE_ID + 1) or 0) == 0
                local r3 = A:VendorFlipOffers(0, 10)
                return r1, r1def, r2, r3, okNoVendor
            end) }
            db.marketData, Bu.results, Bu.resultsTime, Bu.detail = saved.md, saved.res, saved.rt, saved.det
            db.vendorPrices[FAKE_ID], db.vendorPrices[FAKE_ID + 1], db.settings.vendorFlipMin = saved.vp, saved.vp2, saved.min
            for k = 0, 150 do A.vendorChecked[FAKE_ID + k] = nil end
            if not res[1] then error(res[2], 0) end
            local r1, r1def, r2, r3, okNoVendor = res[2], res[3], res[4], res[5], res[6]
            local row = r1[1]
            local good = row and row.itemID == FAKE_ID and row.profit == 150 and row.qty == 5 and #r1def == 0 and #r2 == 0
                and (#r3 == 0 or not okNoVendor)
            return good and true or false, string.format("Gewinn %s (%s), mit 10s-Grenze %d Zeilen, über Händlerpreis %d, ohne Händlerpreis %d",
                tostring(row and row.profit), row and A:FormatMoney(row.profit) or "-", #r1def, #r2, #r3),
                "+1s 50c (150), 0, 0, 0"
        end)
        end)
        B(function()
        Chk("T185", "J", "Heute tun: höchstens 10 Angebote unter Händlerpreis, nach Gewinn sortiert", function()
            local Bu, db = A.Buy, A.db
            local saved = { md = db.marketData, res = Bu.results, rt = Bu.resultsTime, det = Bu.detail }
            local vps = {}
            for k = 0, 150 do A.vendorChecked[FAKE_ID + k] = true end   -- HP1: Händlerpreis vom Spiel bestätigt (Test)
            local res = { pcall(function()
                db.marketData, Bu.detail = {}, nil
                Bu.results, Bu.resultsTime = {}, time()
                for i = 1, 14 do
                    local id = FAKE_ID + 100 + i
                    vps[id] = db.vendorPrices[id]
                    db.vendorPrices[id] = 1000
                    table.insert(Bu.results, { itemID = id, price = 1000 - i * 50, qty = 1 })
                end
                return A:VendorFlipOffers(0, 10)
            end) }
            db.marketData, Bu.results, Bu.resultsTime, Bu.detail = saved.md, saved.res, saved.rt, saved.det
            for id in pairs(vps) do db.vendorPrices[id] = vps[id] end
            for k = 0, 150 do A.vendorChecked[FAKE_ID + k] = nil end
            if not res[1] then error(res[2], 0) end
            local list = res[2]
            local sorted = true
            for i = 2, #list do if list[i].profit > list[i - 1].profit then sorted = false end end
            return #list == 10 and sorted and list[1].profit == 700, string.format("%d Zeilen, bester %s, sortiert %s", #list,
                tostring(list[1] and list[1].profit), tostring(sorted)), "10 Zeilen, bester 700"
        end)
        end)
        -- 0.65.18: Befunde der Prüfung 9. Nov. (offen-ahsentinel.txt Punkte 1-5, 9)
        B(function()
        Chk("T198", "J", "Sniper: reserviert nie ohne Tastendruck (kein Sofortkauf mehr, Anweisung 17:35), Blockade bleibt gespeichert", function()
            local Sn, g2 = A.Sniper, G()
            local db = A.db.sniper
            local saved = { inst = Sn.instantFailed, pend = Sn.pending, blocked = db.instantBlocked, setting = db.instantBuy }
            local res = { pcall(function()
                db.instantBuy, db.instantBlocked, Sn.instantFailed = true, nil, nil
                local fv, other
                if g2 and g2.SetTestFlavor then
                    g2.SetTestFlavor("forever"); fv = Sn:InstantEnabled()
                    g2.SetTestFlavor("era"); other = Sn:InstantEnabled()
                    g2.SetTestFlavor(nil)
                end
                -- WoW blockt den Aufruf: danach auch nach "/reload" (instantFailed weg) kein Sofortkauf
                Capture(function() Sn:OnEvent("ADDON_ACTION_BLOCKED", "AHSentinel", "C_AuctionHouse.StartCommoditiesPurchase()") end)
                Sn.instantFailed = nil
                local afterReload = Sn:InstantEnabled()
                return fv == false and other == false and afterReload == false and db.instantBlocked ~= nil,
                    string.format("Forever %s, Era %s, nach Blockade und Neuladen %s, gespeichert %s", tostring(fv), tostring(other),
                        tostring(afterReload), tostring(db.instantBlocked))
            end) }
            if g2 and g2.SetTestFlavor then g2.SetTestFlavor(nil) end
            Sn.instantFailed, Sn.pending, db.instantBlocked, db.instantBuy = saved.inst, saved.pend, saved.blocked, saved.setting
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "Forever false, Era false, danach false, Interface gespeichert"
        end)
        end)
        B(function()
        Chk("T199", "J", "Verkaufs-Meldung: Muster auch mit %1$s", function()
            local Se = A.Seller
            if not Se.SoldPattern then return false, "Se.SoldPattern fehlt" end
            local p1 = Se.SoldPattern("Eure Auktion von %1$s wurde verkauft.")
            local p2 = Se.SoldPattern("A buyer has been found for your auction of %s.")
            local n1 = p1 and ("Eure Auktion von Leinenstoff wurde verkauft."):match(p1)
            local n2 = p2 and ("A buyer has been found for your auction of Linen Cloth."):match(p2)
            return n1 == "Leinenstoff" and n2 == "Linen Cloth", string.format("%s / %s", tostring(n1), tostring(n2)), "Leinenstoff / Linen Cloth"
        end)
        end)
        B(function()
        Chk("T200", "J", "Kategorie-Schlüssel gleich in beiden Quellen, alte Schlüssel gefunden", function()
            local Bu, X = A.Buy, A.Extras
            if not (Bu.GroupKey and Bu.MainKey and Bu.CatKey) then return false, "GroupKey/MainKey fehlen" end
            local bad = {}
            -- AuctionCategories: Rüstung -> Stoff mit mehreren Plätzen (inventoryType) = Rückfall Klasse 4 / Unterklasse 1
            local a = Bu.GroupKey({ { 4, 1, 5 }, { 4, 1, 7 }, { 4, 1, 20 } })
            if a ~= Bu.CatKey({ 4, 1 }) then bad[#bad + 1] = "Stoff " .. tostring(a) end
            local w = Bu.MainKey({ { 2, 0 }, { 2, 1 }, { 2, 7 } })
            if w ~= Bu.CatKey({ 2 }) then bad[#bad + 1] = "Waffen " .. tostring(w) end
            local multi = Bu.GroupKey({ { 2, 7 }, { 2, 0 }, { 2, 4 } })
            if multi ~= "c2_0-4-7" then bad[#bad + 1] = "mehrere " .. tostring(multi) end
            -- alter Schlüssel bis 0.65.17 ("…_<Platz>_<Anzahl>") findet die Kategorie über X:CatByKey
            local saved = Bu.CATS
            Bu.CATS = { { key = "all" }, { key = "c4_1", label = "AHS-Test", filters = { { 4, 1 } } } }
            local c = X:CatByKey("c4_1_5_3")
            Bu.CATS = saved
            if not c then bad[#bad + 1] = "alter Schlüssel nicht gefunden" end
            return #bad == 0, #bad == 0 and "gleich" or table.concat(bad, "; "), "Stoff = c4_1, Waffen = Klasse, alt gefunden"
        end)
        end)
        B(function()
        Chk("T201", "J", "Heute tun: gemerkte Rezepte bleiben unverändert (Sandbox recipes…prof)", function()
            local Cr = A.Crafting
            local list = Cr:KnownRecipes()
            local touched = 0
            for _, e in pairs((A.db.recipes or {})[A.Chars and A.Chars:Key() or ""] or {}) do
                for _, r in ipairs(type(e) == "table" and e.list or {}) do if r.prof ~= nil then touched = touched + 1 end end
            end
            if #list == 0 then return "SKIP", "keine gemerkten Rezepte (erst ein Berufsfenster öffnen)" end
            return touched == 0 and list[1].prof ~= nil, string.format("%d Rezepte, gespeichert mit prof: %d", #list, touched), "0"
        end)
        end)
        B(function()
        local tab = A.UI and A.UI.GetTab and A.UI:GetTab("buy")
        local p = tab and tab.panel
        if not (p and p.cats and p.Refresh) then return Skp("T202", "J", "Kategorie-Liste behält die Scroll-Position", "HALB: Reiter Einkauf einmal öffnen") end
        Chk("T202", "J", "Kategorie-Liste behält die Scroll-Position", function()
            local cat, off = p.cat, p.cats.offset
            local res = { pcall(function()
                p.cat = "all"
                p:Refresh()
                local maxOff = math.max(0, #(p.cats.items or {}) - (p.cats.numRows or 1))
                if maxOff == 0 then return "SKIP", "Liste passt ganz in die Spalte" end
                p.cats.offset = maxOff
                p:Refresh(); p:Refresh()
                return p.cats.offset == maxOff, string.format("offset %d nach 2x Refresh (soll %d)", p.cats.offset, maxOff), "gleich"
            end) }
            p.cat, p.cats.offset = cat, off
            p.catsSig = nil
            pcall(p.Refresh, p)
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], res[4]
        end)
        end)
        B(function()
        Chk("T187", "J", "Händler-Knopf: ab Werk aus, wenn LevelPilot graue Items verkauft; eigene Einstellung gewinnt", function()
            local UI, s = A.UI, A.db.settings
            local savedOv, savedSet = A.apiOverride, s.vendorButton
            local res = { pcall(function()
                local lp = { IsAddOnLoaded = function(n) return n == "LevelPilot" end }
                local none = { IsAddOnLoaded = function() return false end }
                s.vendorButton = nil
                A.apiOverride = { C_AddOns = lp, LevelPilotDB = { settings = { autoSellGrey = true } } }
                local a = UI:VendorButtonEnabled()                 -- LevelPilot verkauft -> aus
                A.apiOverride = { C_AddOns = lp, LevelPilotDB = { settings = { autoSellGrey = false } } }
                local b = UI:VendorButtonEnabled()                 -- LevelPilot verkauft nicht -> an
                A.apiOverride = { C_AddOns = none, LevelPilotDB = false }
                local c = UI:VendorButtonEnabled()                 -- ohne LevelPilot -> an
                A.apiOverride = { C_AddOns = lp, LevelPilotDB = { settings = { autoSellGrey = true } } }
                s.vendorButton = true
                local d = UI:VendorButtonEnabled()                 -- selbst eingeschaltet -> an
                return a, b, c, d
            end) }
            A.apiOverride, s.vendorButton = savedOv, savedSet
            if not res[1] then error(res[2], 0) end
            local a, b, c, d = res[2], res[3], res[4], res[5]
            return (not a) and b and c and d, string.format("LevelPilot an %s, LevelPilot aus %s, ohne %s, selbst an %s",
                tostring(a), tostring(b), tostring(c), tostring(d)), "false, true, true, true"
        end)
        end)
        -- 0.65.22: Entzaubern im Tooltip - tatsächlicher Ø und Aufschlüsselung je Material
        B(function()
        Chk("T203", "J", "Entzaubern tatsächlich: 4 bekannte Entzauberungen -> Ø genau, Aufschlüsselung = geschätzter Wert", function()
            local D, TT = A.Disenchant, A.Tooltip
            local KEY, DUST, ESS, SHARD = "2:1:a", 10940, 10938, 10978
            local saved = { st = A.db.deStats, sh = A.db.deShared, prior = D.Prior, cur = A.GetCurrent, mv = A.GetMarketValue, mp = D.MatPrice }
            local res = { pcall(function()
                -- X3 (Befund 0.65.86): ALLE Preisquellen ersetzen - der Materialpreis selbst (D:MatPrice, eigene Funktion)
                -- liefert den Testpreis; "tatsächlich" und "geschätzt" rechnen damit, unabhängig von der echten Preisleiter
                D.MatPrice = function(self, id)
                    local P = ({ [DUST] = 100, [ESS] = 300 })[id]
                    if P then return P, 120, P, "ah", false, false, {} end
                    if id == SHARD then return nil end
                    return saved.mp(self, id)
                end
                -- 4 Entzauberungen: 2+2+1+2 Staub (4x), 1 Essenz (1x) -> Staub 7, Essenz 1
                A.db.deStats = { [KEY] = { n = 4, mats = { [DUST] = { times = 4, total = 7 }, [ESS] = { times = 1, total = 1 } } } }
                A.db.deShared = {}
                D.Prior = function(self, id) if id == FAKE_ID then return D:PriorForKey(KEY), KEY end return saved.prior(self, id) end
                local prices = { [DUST] = 100, [ESS] = 300 }
                A.GetCurrent = function(self, id) if prices[id] then return prices[id], 1, time() - 120 end return saved.cur(self, id) end
                A.GetMarketValue = function(self, id) if prices[id] then return prices[id] end if id == SHARD then return nil end return saved.mv(self, id) end
                local av, complete, n = D:ActualValue(FAKE_ID)
                local v = D:GetValue(FAKE_ID)
                local sum = 0
                for _, r in ipairs(D:EstimateRows(FAKE_ID)) do sum = sum + (r.share or 0) end
                local lines = TT and TT.DisenchantLines and TT:DisenchantLines(FAKE_ID, true) or {}
                local text = {}
                for _, l in ipairs(lines) do text[#text + 1] = l[1] .. " " .. l[2] end
                text = table.concat(text, " | ")
                -- ohne Daten: keine Zeile "tatsächlich"
                A.db.deStats = {}
                local none = D:ActualValue(FAKE_ID)
                return av, complete, n, v, sum, text, none
            end) }
            A.db.deStats, A.db.deShared, D.Prior, A.GetCurrent, A.GetMarketValue, D.MatPrice = saved.st, saved.sh, saved.prior, saved.cur, saved.mv, saved.mp
            if not res[1] then error(res[2], 0) end
            local av, complete, n, v, sum, text, none = res[2], res[3], res[4], res[5], res[6], res[7], res[8]
            -- (7 x Preis Staub + 1 x Preis Essenz) / 4 - Preis = Rechenwert aus dem letzten Scan (K3, ohne Abzug)
            local want = math.floor((7 * 100 + 1 * 300) / 4 + 0.5)
            local ok = av == want and complete and n == 4 and v and math.abs(sum - v) <= 1 and none == nil
                and text:find(string.format(L["Entzaubern tatsächlich (Ø aus %d)"], 4), 1, true) ~= nil
            return ok, string.format("tatsächlich %s aus %s, geschätzt %s = Summe %.0f, ohne Daten %s · %s", tostring(av), tostring(n),
                tostring(v), sum, tostring(none), text), "250 aus 4 ((7×100 + 1×300) / 4), Summe der Anteile = geschätzter Wert, ohne Daten keine Zeile"
        end)
        end)
        -- 0.65.23: Spieltest (Bereich S) - je Prüfung ein OK- und ein FEHLER-Fall mit nachgestellter Lage
        local function Both(id, name, okData, badData)
            B(function()
            Chk(id, "S", name, function()
                local E = A.Spieltest and A.Spieltest.Eval
                if not E then return false, "Spieltest fehlt", "A.Spieltest.Eval" end
                local key = name:match("^(S%d)")
                local okA, istA = E[key](okData)
                local okB, istB = E[key](badData)
                return okA == true and okB == false, string.format("OK-Fall: %s (%s) · FEHLER-Fall: %s (%s)", tostring(okA), tostring(istA),
                    tostring(okB), tostring(istB)), "OK-Fall OK, FEHLER-Fall FEHLER"
            end)
            end)
        end
        Both("T204", "S1 Gebühr im Verkaufen-Reiter",
            { forever = true, unit = 78, qty = 5, auctions = 1, cut = 19, depositShown = true },        -- 5 %, abgerundet (390 -> 19)
            { forever = true, unit = 78, qty = 5, auctions = 1, cut = 100, depositShown = true })
        Both("T205", "S2 Gebühr echt",
            { measured = 500, shown = 500 }, { measured = 600, shown = 500 })
        Both("T206", "S3 Gewinn-Fenster",
            { forever = true, value = 2000, made = 1, stack = 1, net = 1900, cost = 1000, profit = 900, depositShown = false },
            { forever = true, value = 2000, made = 1, stack = 1, net = 1800, cost = 1000, profit = 800, depositShown = true })
        Both("T207", "S4 Entzaubern im Tooltip",
            { estSum = 216.4, estValue = 216, actualShown = true, n = 4, nCombined = 4 },
            { estSum = 180, estValue = 216, actualShown = true, n = 0, nCombined = 0 })
        Both("T208", "S5 Gewinn-Fenster überdeckt nichts",
            { problems = {}, tested = 2 }, { problems = { "Gewinn-Fenster überdeckt ProfessionsFrame" }, tested = 2 })
        Both("T209", "S6 Händler-Knopf",
            { shown = true, candidates = 3, enabled = true, lpSells = false, ownSetting = nil },
            { shown = true, candidates = 0, enabled = true, lpSells = true, ownSetting = nil, overlapTab = "MerchantFrameTab2" })
        Both("T210", "S7 Neuaufbau beim Herstellen",
            { builds = { 1, 3.5, 6 }, slow = {}, crafts = 5 }, { builds = { 1, 1.4, 1.8 }, slow = { 24 }, crafts = 5 })
        Both("T211", "S8 kein ADDON_ACTION_BLOCKED",
            { blocked = {} }, { blocked = { "BLOCKED PlaceAuctionBid()" } })
        B(function()
        Chk("T212", "S", "Spieltest-Ablauf: einmal je Lage, FEHLER bleibt, eine Chat-Zeile je Prüfung, Bericht offen/OK/FEHLER", function()
            local P = A.Spieltest
            local saved = { until_ = P.activeUntil, res = P.results, warned = P.warned, started = P.started, saved = P.saved, print = A.Print,
                blocked = P.blocked }
            local printed = 0
            local res = { pcall(function()
                A.Print = function() printed = printed + 1 end
                P.activeUntil, P.started, P.results, P.warned, P.saved, P.blocked = (GetTime and GetTime() or 0) + 60, time(), {}, {}, true, {}
                P:Result("S1", true, "100", "100")
                P:Result("S1", true, "200", "200")      -- schon OK: einmal je Lage (erster Wert bleibt)
                P:Result("S2", false, "600", "500")
                P:Result("S2", false, "700", "500")     -- zweiter FEHLER: keine weitere Chat-Zeile
                P:Result("S2", true, "500", "500")      -- FEHLER bleibt stehen
                P:Result("S3", nil)                      -- Lage nicht verwertbar: bleibt offen
                local lines, c = P:Lines()
                return c, P.results.S1.status .. "/" .. P.results.S1.ist, P.results.S2.status, P.results.S2.ist, lines
            end) }
            A.Print = saved.print
            P.activeUntil, P.results, P.warned, P.started, P.saved, P.blocked = saved.until_, saved.res, saved.warned, saved.started, saved.saved, saved.blocked
            if not res[1] then error(res[2], 0) end
            local c, s1, s2, ist2, lines = res[2], res[3], res[4], res[5], res[6]
            local needOK = lines[3] and lines[3].status == "offen" and lines[3].need ~= nil
            return c.ok == 1 and c.fehler == 1 and c.offen == #P.CHECKS - 2 and s1 == "OK/100" and s2 == "FEHLER" and ist2 == "600" and printed == 1 and needOK,
                string.format("OK %d, FEHLER %d, offen %d, S1 %s, S2 %s (%s), Chat-Zeilen %d", c.ok, c.fehler, c.offen, s1, s2, ist2, printed),
                "OK 1, FEHLER 1, Rest offen, S2 bleibt FEHLER mit erstem Wert, 1 Chat-Zeile, offen mit Lage"
        end)
        end)
        B(function()
        Chk("T213", "S", "S5 prüft nur Gewinn-Fenster gegen Berufsfenster und ProfessionSentinel (Befund 9. Nov. 08:12)", function()
            local P = A.Spieltest
            local function F(l, b, w, h, vis) return { GetRect = function() return l, b, w, h end, IsVisible = function() return vis ~= false end,
                GetHitRectInsets = function() return 0, 0, 0, 0 end } end
            -- kein Blizzard-Fenster überschreiben (Taint): eigenes Testfenster über die Liste P.S5_BLIZZARD
            local saved = { list = P.S5_BLIZZARD, gs = _G.GoldSentinelUIFrames }
            local res = { pcall(function()
                local panel = F(500, 300, 300, 400)
                P.S5_BLIZZARD = { "AHSentinelTestProfFrame" }
                _G.AHSentinelTestProfFrame = F(100, 300, 390, 400)        -- links daneben
                _G.GoldSentinelUIFrames = {
                    { frame = F(810, 300, 300, 400), name = "Panel", addon = "ProfessionSentinel" },   -- rechts daneben
                    { frame = F(600, 400, 50, 50), name = "BuffSentinelAnchor_cd", addon = "BuffSentinel" },  -- anderes Addon: zählt nicht
                }
                local okD = P:S5Data(panel)
                _G.GoldSentinelUIFrames[1].frame = F(700, 300, 300, 400)   -- ProfessionSentinel darüber
                local badD = P:S5Data(panel)
                return okD, badD
            end) }
            P.S5_BLIZZARD, _G.GoldSentinelUIFrames, _G.AHSentinelTestProfFrame = saved.list, saved.gs, nil
            if not res[1] then error(res[2], 0) end
            local okD, badD = res[2], res[3]
            if not (okD and badD) then return "SKIP", "UICheck nicht geladen" end
            local okA = P.Eval.S5(okD)
            local okB, istB = P.Eval.S5(badD)
            return okA == true and okB == false and okD.tested == 2, string.format("daneben: %s (%d geprüft), darüber: %s (%s)",
                tostring(okA), okD.tested, tostring(okB), tostring(istB)), "daneben OK (BuffSentinel ignoriert), ProfessionSentinel darüber FEHLER"
        end)
        end)
        B(function()
        Chk("T214", "J", "Post abholen: Gold gemeldet, auch wenn die Gutschrift erst nach MAIL_INBOX_UPDATE kommt (Befund 9. Nov. 08:19)", function()
            local M = A.Mailer
            local saved = { running = M.running, money = M.money, items = M.items, start = M.startMoney, waiting = M.waiting, last = M.lastAction,
                next = M.NextMail, take = A.Inbox.TakeInboxMoney, mf = M.MailOpen, print = A.Print, screen = A.ScreenMessage, fire = A.Fire }
            local msgs = {}
            local res = { pcall(function()
                local mail = 15626                                         -- 1g 56s 26c
                M.MailOpen = function() return true end                    -- Nahtstelle statt Blizzard-MailFrame
                A.Inbox.TakeInboxMoney = function() end                    -- Gold kommt (noch) nicht an (A.Inbox, nicht _G)
                A.Print = function(_, m) msgs[#msgs + 1] = m end
                A.ScreenMessage, A.Fire = function() end, function() end
                M.running, M.money, M.items, M.waiting, M.lastAction = true, 0, 0, nil, 0
                M.startMoney = GetMoney and GetMoney() or 0
                local n = 0
                M.NextMail = function() n = n + 1; if n == 1 then return 1, mail, 0 end return nil end
                M:Step()                           -- holt das Gold
                M.waiting, M.lastAction = nil, 0   -- MAIL_INBOX_UPDATE vor PLAYER_MONEY
                M:Step()                           -- keine Post mehr -> Stop
                return M.running
            end) }
            M.running, M.money, M.items, M.startMoney, M.waiting, M.lastAction = saved.running, saved.money, saved.items, saved.start, saved.waiting, saved.last
            M.NextMail, A.Inbox.TakeInboxMoney, M.MailOpen, A.Print, A.ScreenMessage, A.Fire = saved.next, saved.take, saved.mf, saved.print, saved.screen, saved.fire
            if not res[1] then error(res[2], 0) end
            local text = table.concat(msgs, " | ")
            local want = A:FormatMoney(15626)
            return res[2] == false and text:find(want, 1, true) ~= nil, text, "Meldung mit " .. want
        end)
        end)
        -- 0.65.26: Entzaubern im Tooltip kurz + Materialblock, Teilen mit allen (Schutz vor Unsinn)
        local function WithDE(nOwn, fn)
            local D = A.Disenchant
            local KEY, DUST, ESS = "2:1:a", 10940, 10938
            local saved = { st = A.db.deStats, sh = A.db.deShared, prior = D.Prior, cur = A.GetCurrent, mv = A.GetMarketValue,
                ov = A.apiOverride, mode = A.db.settings.tooltipDEMode, chars = A.db.chars, rate = D.rate, bi = A.BuyoutInfo, bc = A.buyoutCache }
            local res = { pcall(function()
                -- TR (13.11.): kein echtes Aufkauf-Kennzeichen der Materialien in der Sandbox (T223 Essenz 97 statt 300)
                A.BuyoutInfo = function(self, id) if id == DUST or id == ESS or id == FAKE_ID then return nil end return saved.bi(self, id) end
                local dust = math.floor(nOwn * 1.75 + 0.5)
                A.db.deStats = nOwn > 0 and { [KEY] = { n = nOwn, mats = { [DUST] = { times = nOwn, total = dust }, [ESS] = { times = 1, total = 1 } } } } or {}
                A.db.deShared, D.rate = {}, {}
                D.Prior = function(self, id) if id == FAKE_ID then return D:PriorForKey(KEY), KEY end return saved.prior(self, id) end
                local prices = { [DUST] = 100, [ESS] = 300, [FAKE_ID] = 50 }
                A.GetCurrent = function(self, id) if prices[id] then return prices[id], 1, time() - 60 end return saved.cur(self, id) end
                A.GetMarketValue = function(self, id) if prices[id] then return prices[id] end return saved.mv(self, id) end
                return fn(D, KEY, DUST, ESS)
            end) }
            A.db.deStats, A.db.deShared, D.Prior, A.GetCurrent, A.GetMarketValue = saved.st, saved.sh, saved.prior, saved.cur, saved.mv
            A.apiOverride, A.db.settings.tooltipDEMode, A.db.chars, D.rate = saved.ov, saved.mode, saved.chars, saved.rate
            A.BuyoutInfo = saved.bi
            if not res[1] then error(res[2], 0) end
            return select(2, unpack(res))
        end
        -- Shift über die Naht A:API (nie die Blizzard-Funktion ersetzen), übrige Ersatzwerte der Sandbox behalten
        local function SetShift(on)
            local o = {}
            for k, v in pairs(A.apiOverride or {}) do o[k] = v end
            o.IsShiftKeyDown = function() return on end
            A.apiOverride = o
        end
        local function FakeTT()
            local t = { lines = {} }
            function t:AddDoubleLine(l, r) self.lines[#self.lines + 1] = tostring(l) .. " || " .. tostring(r) end
            function t:AddLine(l) self.lines[#self.lines + 1] = tostring(l) end
            return t
        end
        B(function()
        Chk("T215", "J", "Entzaubern-Tooltip Variante A: Urteil + Wege, Materialblock ohne Shift (ausser 'kurz'), Quelle wechselt bei 10, Shift = Rechnung", function()
            local TT = A.Tooltip
            return WithDE(4, function(D)
                -- 4 Entzauberungen: Tabelle (T)
                local s4 = TT:DisenchantShort(FAKE_ID)
                local v4, _, yield = D:GetValue(FAKE_ID)
                local want4 = D:NetValue(v4, yield)
                A.db.settings.tooltipDEMode = "short"
                SetShift(false)
                local tShort = FakeTT(); TT:AddDisenchantLines(tShort, FAKE_ID)
                A.db.settings.tooltipDEMode = "mats"
                local tMats = FakeTT(); TT:AddDisenchantLines(tMats, FAKE_ID)
                local mats = TT:DisenchantMats(FAKE_ID)
                local matsOK = #mats >= 2
                for _, m in ipairs(mats) do if not (m.chance and m.chance > 0 and m.price and m.icon ~= nil) then matsOK = false end end
                SetShift(true)
                local tShift = FakeTT(); TT:AddDisenchantLines(tShift, FAKE_ID)
                local shiftText = table.concat(tShift.lines, " | ")
                -- 10 Entzauberungen: tatsächlich (Ø 10)
                A.db.deStats["2:1:a"] = { n = 10, mats = { [10940] = { times = 10, total = 18 }, [10938] = { times = 2, total = 2 } } }
                local s10 = TT:DisenchantShort(FAKE_ID)
                local av, _, n, rows = D:ActualValue(FAKE_ID)
                local want10 = D:ActualNet(av, rows, n)
                -- seit 0.65.41 (Entzauber-Urteil): ohne Shift nur die 2 Urteilszeilen, auch bei "mit Materialien";
                -- mit Shift Urteil + Rechnung + Materialblock
                local verdict = tShort.lines[1] and (tShort.lines[1]:find(L["Entzaubern lohnt sich"], 1, true) or tShort.lines[1]:find(L["Entzaubern lohnt nicht"], 1, true)
                    or tShort.lines[1]:find(L["Entzaubern: unsicher"], 1, true))
                local ok = s4 and s4.net == want4 and s4.basis == "estimate" and s4.right:find("(T)", 1, true)
                    and (#tShort.lines == 3 or #tShort.lines == 4) and verdict and #tMats.lines > #tShort.lines and matsOK
                    and table.concat(tMats.lines, "|"):find(L["Materialien (Tabelle)"]:sub(1, -2), 1, true)
                    and shiftText:find(L["Entzaubern geschätzt (Tabelle)"], 1, true)
                    and s10 and s10.basis == "actual" and s10.net == want10 and s10.right:find("(Ø 10)", 1, true)
                return ok and true or false, string.format("4: %s %s · kurz %d Zeile(n), mit Materialien %d, Materialien ok %s · Shift %s · 10: %s %s",
                    tostring(s4 and s4.net), tostring(s4 and s4.right), #tShort.lines, #tMats.lines, tostring(matsOK),
                    shiftText:find(L["Entzaubern geschätzt (Tabelle)"], 1, true) and "ganze Rechnung" or "fehlt", tostring(s10 and s10.net),
                    tostring(s10 and s10.right)), "Tabelle bei 4 = NetValue, 'kurz': Urteil + Wege (3-4 Zeilen), 'mit Materialien': dazu Block 'Materialien (Tabelle)' ohne Shift, Shift: Rechnung, tatsächlich ab 10"
            end)
        end)
        end)
        B(function()
        Chk("T273", "J", "Tooltip Variante A ganz (T-V1 ohne Shift, T-V2 mit Shift, T-V5 nicht entzauberbar), T-D2 Kopf echt aus 12, T-P2 Quelle Scan/Markt", function()
            local TT, D = A.Tooltip, A.Disenchant
            local saved = { vp = A.GetVendorPrice, trend = A.GetTrend, liq = A.LiquidityText, mode = A.db.settings.tooltipDEMode,
                bag = TT.OwnBagTooltip, ss = A.Ledger.SellSpeedText }
            local res = { pcall(function()
                A.GetVendorPrice = function(_, id) if id == FAKE_ID or id == FAKE_ID + 50 then return 7 end return saved.vp(A, id) end
                A.GetTrend = function() return 5 end
                A.LiquidityText = function() return "~3/Tag" end
                TT.OwnBagTooltip = function() return false end
                A.Ledger.SellSpeedText = function() return nil end
                A.db.settings.tooltipDEMode = "mats"
                local function has(t, key) return table.concat(t.lines, " | "):find(key, 1, true) ~= nil end
                local out = {}
                -- V1 / V2 (entzauberbar, mit Preisen), Tabelle (4 eigene)
                local v1, v2 = WithDE(4, function()
                    SetShift(false)
                    local a = FakeTT(); TT:AddLines(a, FAKE_ID)
                    SetShift(true)
                    local b = FakeTT(); TT:AddLines(b, FAKE_ID)
                    SetShift(false)
                    return a, b
                end)
                if type(v1) ~= "table" then error("WithDE: " .. tostring(v2), 0) end
                out[#out + 1] = string.format("V1 %s/%s/%s/%s/%s", tostring(has(v1, L["Preis"])), tostring(has(v1, L["Materialien (Tabelle)"]:sub(1, -2))),
                    tostring(not has(v1, L["Realer Wert (nach Gebühren)"])), tostring(not has(v1, L["Trend 24 Std."])), tostring(not has(v1, L["Händlerpreis"])))
                out[#out + 1] = string.format("V2 %s/%s/%s/%s/%s", tostring(has(v2, L["Realer Wert (nach Gebühren)"])), tostring(has(v2, L["Trend 24 Std."])),
                    tostring(has(v2, "~3/Tag")), tostring(has(v2, L["Händlerpreis"])), tostring(has(v2, L["Entzaubern geschätzt (Tabelle)"])))
                -- T-P2: Materialblock mit Quelle
                out[#out + 1] = "P2 " .. tostring(has(v1, "|cff999999" .. L["Scan"] .. "|r") or has(v1, "|cff999999" .. L["Markt"] .. "|r"))
                -- T-D2: 12 eigene Entzauberungen -> Kopf "Materialien (echt, aus 12 Entzauberungen)"
                local d2 = WithDE(12, function()
                    SetShift(false)
                    local c = FakeTT(); TT:AddDisenchantLines(c, FAKE_ID)
                    return has(c, string.format(L["Materialien (echt, aus %d Entzauberungen)"], 12))
                end)
                out[#out + 1] = "D2 " .. tostring(d2)
                -- V5: nicht entzauberbar -> kein Urteil, kein Materialblock, Block 2 nur "Verkaufen:" bzw. "Händler:"
                local v5 = WithDE(4, function()
                    local cur, mv = A.GetCurrent, A.GetMarketValue
                    A.GetCurrent = function(self, id) if id == FAKE_ID + 50 then return 200, 1, time() - 60 end return cur(self, id) end
                    A.GetMarketValue = function(self, id) if id == FAKE_ID + 50 then return 200 end return mv(self, id) end
                    SetShift(false)
                    local e = FakeTT(); TT:AddLines(e, FAKE_ID + 50)
                    A.GetCurrent, A.GetMarketValue = cur, mv
                    return string.format("%s/%s/%s", tostring(has(e, L["Verkaufen:"]) or has(e, L["Händler:"])),
                        tostring(not (has(e, L["Entzaubern lohnt sich"]) or has(e, L["Entzaubern lohnt nicht"]) or has(e, L["Entzaubern: unsicher"]))),
                        tostring(not has(e, L["Materialien (Tabelle)"]:sub(1, -2))))
                end)
                out[#out + 1] = "V5 " .. tostring(v5)
                return table.concat(out, " ")
            end) }
            A.GetVendorPrice, A.GetTrend, A.LiquidityText, A.db.settings.tooltipDEMode = saved.vp, saved.trend, saved.liq, saved.mode
            TT.OwnBagTooltip, A.Ledger.SellSpeedText = saved.bag, saved.ss
            SetShift(false)
            if not res[1] then error(res[2], 0) end
            local want = "V1 true/true/true/true/true V2 true/true/true/true/true P2 true D2 true V5 true/true/true"
            return res[2] == want, res[2], want
        end)
        end)
        B(function()
        Chk("T216", "J", "Entzaubern teilen: Twink eigen, anderer Spieler geteilt (ohne Namen), Unsinn/Doppeltes/zu viel verworfen, nur Gilde nie Kanal", function()
            local S = A.Sync
            local Enc = S.Enc
            return WithDE(0, function(D, KEY, DUST, ESS)
                local function part(n, list)
                    local m = {}
                    for _, x in ipairs(list) do m[#m + 1] = Enc(x[1]) .. "," .. Enc(x[2]) .. "," .. Enc(x[3]) end
                    return KEY:gsub(":", ".") .. "~" .. Enc(n) .. "~" .. table.concat(m, ",")
                end
                local now = time()
                A.db.chars = { ["AHSTwink-AHSRealm"] = { name = "AHSTwink", realm = "AHSRealm" } }
                local twink = D:HandleShared("AHSTwink-AHSRealm", now, part(3, { { DUST, 3, 5 } }))
                local good = part(4, { { DUST, 4, 7 }, { ESS, 1, 1 } })
                local other = D:HandleShared("AHSFremder-AHSRealm", now, good)
                local dup = D:HandleShared("AHSFremder-AHSRealm", now, good)
                local wrongMat = D:HandleShared("AHSDritter-AHSRealm", now, part(2, { { 20725, 1, 1 } }))      -- Nexus passt nicht zu grün
                local tooMany = D:HandleShared("AHSVierter-AHSRealm", now, part(2, { { DUST, 2, 30 } }))       -- 15 je Entzauberung
                -- eine Sendung mit 8 Teilstücken (gleiche Zeit) kommt ganz an, eine zweite Sendung in derselben Minute nicht
                local spam = 0
                for i = 1, 8 do spam = spam + D:HandleShared("AHSSpammer-AHSRealm", now, part(i, { { DUST, i, i } })) end
                spam = spam + D:HandleShared("AHSSpammer-AHSRealm", now - 1, part(9, { { DUST, 9, 9 } }))
                local names = false
                for k in pairs(A.db.deShared) do if not tostring(k):find("^#") or tostring(k):find("AHS", 1, true) then names = true end end
                local nOwn, nShared = D:Combined(KEY)
                -- nur Gilde: nur GUILD; sonst Gilde und Gruppe - nie ein Kanal (GoldSentinelSync.api ersetzt, nie Blizzard)
                local GSS = _G.GoldSentinelSync
                local savedG, sa = A.db.sync.guildOnly, { g = GSS.api.inGuild, r = GSS.api.inRaid, p = GSS.api.inGroup }
                GSS.api.inGuild, GSS.api.inRaid, GSS.api.inGroup = function() return true end, function() return false end, function() return true end
                A.db.sync.guildOnly = true
                local d1 = table.concat(S:Paths(), "+")
                A.db.sync.guildOnly = nil
                local d2 = table.concat(S:Paths(), "+")
                A.db.sync.guildOnly = savedG
                GSS.api.inGuild, GSS.api.inRaid, GSS.api.inGroup = sa.g, sa.r, sa.p
                local ok = twink == 0 and other == 1 and dup == 0 and wrongMat == 0 and tooMany == 0 and spam == 8 and not names
                    and nOwn == 0 and d1 == "GUILD" and d2 == "GUILD+PARTY"
                return ok, string.format("Twink %d, anderer %d, doppelt %d, falsches Material %d, zu viel %d, Spam angenommen %d von 9, Namen gespeichert %s, nur Gilde %s, alle %s",
                    twink, other, dup, wrongMat, tooMany, spam, tostring(names), tostring(d1), tostring(d2)),
                    "0, 1, 0, 0, 0, 8 (eine Sendung ganz, zweite Sendung verworfen), nein, GUILD, GUILD+PARTY"
            end)
        end)
        end)
        B(function()
        Chk("T217", "J", "Entzaubern grün bis Itemstufe 15 ohne Splitter (80/20), ab 16 mit Splitter (Befund 9. Nov. 09:04)", function()
            local D = A.Disenchant
            local function fmt(p)
                local t = {}
                for _, e in ipairs(p or {}) do t[#t + 1] = e[1] .. "=" .. math.floor(e[2] * 100 + 0.5) .. "%" end
                return table.concat(t, " ")
            end
            local a1, w1, a2, a3 = D:PriorForKey("2:1:a"), D:PriorForKey("2:1:w"), D:PriorForKey("2:2:a"), D:PriorForKey("2:3:a")
            -- Braune Leinenhose (Rüstung bis 15): Staub 80, Essenz 20, kein Splitter; Wollcape (16-20): 75/20/5 mit Splitter
            local ok1 = #a1 == 2 and a1[1][1] == 10940 and a1[1][2] == 0.80 and a1[2][1] == 10938 and a1[2][2] == 0.20
            local okW = #w1 == 2 and w1[1][2] == 0.20 and w1[2][2] == 0.80
            local ok2 = #a2 == 3 and a2[3][1] == 10978 and a2[3][2] == 0.05
            -- 0.65.67 (Entscheid des Nutzers): in Forever 75/20/5 nach dem Forever-Leitfaden, sonst Tabelle 75/15/10
            local ok3 = #a3 == 3 and a3[3][2] == (A:IsForever() and 0.05 or 0.10)
            -- unplausible Splitter-Meldung für Stufe bis 15: geteilt verworfen, eigene nicht mitgezählt
            local saved = { st = A.db.deStats, sh = A.db.deShared, rate = D.rate }
            local res = { pcall(function()
                A.db.deStats = { ["2:1:a"] = { n = 3, mats = { [10940] = { times = 3, total = 5 }, [10978] = { times = 1, total = 1 } } } }
                A.db.deShared, D.rate = {}, {}
                local Enc = A.Sync.Enc
                local taken = D:HandleShared("AHSFremder-AHSRealm", time(), "2.1.a~" .. Enc(2) .. "~" .. Enc(10978) .. "," .. Enc(1) .. "," .. Enc(1))
                local _, _, mats = D:Combined("2:1:a")
                return taken, mats[10978] ~= nil
            end) }
            A.db.deStats, A.db.deShared, D.rate = saved.st, saved.sh, saved.rate
            if not res[1] then error(res[2], 0) end
            local taken, shardCounted = res[2], res[3]
            return ok1 and okW and ok2 and ok3 and taken == 0 and not shardCounted,
                string.format("bis 15 Rüstung: %s · Waffe: %s · 16-20: %s · 21-25: %s · Splitter geteilt %d, eigener gezählt %s",
                    fmt(a1), fmt(w1), fmt(a2), fmt(a3), taken, tostring(shardCounted)),
                "80/20 ohne Splitter, Waffe 20/80, 75/20/5, 21-25 Forever 75/20/5 sonst 75/15/10, Splitter verworfen"
        end)
        end)
        -- 0.65.28: Entscheide der Prüf-Sitzung 9. Nov. 09:35
        Both("T221", "S9 Hauptfenster mit dem Auktionshaus",
            { open = true, option = true, before = false, visible = true },
            { open = false, option = true, before = false, visible = true })
        B(function()
        Chk("T218", "J", "Forever: keine Reservierung ohne Tastendruck, Status 'nochmal drehen' mit Zeit, Reservierung läuft ab", function()
            local Sn = A.Sniper
            local g2 = _G.GoldSentinelGame
            if not (g2 and g2.SetTestFlavor) then return "SKIP", "SetTestFlavor fehlt" end
            local db = A.db.sniper
            local saved = { pending = Sn.pending, armed = db and db.armed, open = A.ahOpen, force = A.forceForever, print = A.Print }
            local res = { pcall(function()
                A.forceForever = nil
                g2.SetTestFlavor("forever")
                local instant = Sn:InstantEnabled()
                A.Print = function() end
                if db then db.armed = false end
                A.ahOpen = true
                local now = GetTime()
                Sn.pending = { state = "ready", started = now, auto = false, plan = { itemID = 2589, qty = 1, kind = "commodity" } }
                local status = Sn:GetStatusText() or ""
                Sn.pending.started = now - 11            -- Zeitlimit (10 s) vorbei
                Sn:Tick()
                local expired = Sn.pending == nil
                g2.SetTestFlavor(nil)
                return instant, status, expired
            end) }
            if g2.SetTestFlavor then g2.SetTestFlavor(nil) end
            Sn.pending, A.ahOpen, A.forceForever, A.Print = saved.pending, saved.open, saved.force, saved.print
            if db then db.armed = saved.armed end
            if not res[1] then error(res[2], 0) end
            local instant, status, expired = res[2], res[3], res[4]
            local plain = status:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
            local want = L["|cff33dd55Reserviert - nochmal %s zum Kaufen (%d s)|r"]:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):match("^([^%%]+)")
            return instant == false and plain:find(want, 1, true) ~= nil and plain:find("10 s", 1, true) ~= nil and expired,
                string.format("Sofortkauf %s, Status \"%s\", abgelaufen %s", tostring(instant), plain, tostring(expired)),
                "kein Sofortkauf, \"Reserviert - nochmal ... (10 s)\", nach 10 s verfallen"
        end)
        end)
        B(function()
        Chk("T219", "J", "Hauptfenster mit dem Auktionshaus: auf -> auf, zu -> zu, vorher offen bleibt offen, Option aus -> nichts", function()
            local UI = A.UI
            local st = A.db.settings
            local saved = { opt = st.openWithAH, show = UI.Show, hide = UI.Hide, vis = UI.IsVisible, auto = UI.autoOpened, was = UI.wasOpenBeforeAH }
            local visible = false
            local res = { pcall(function()
                UI.Show = function() visible = true end
                UI.Hide = function() visible = false end
                UI.IsVisible = function() return visible end
                local out = {}
                -- 1. AH auf -> auf, AH zu -> zu
                st.openWithAH = nil; visible = false
                UI:OnAHStateAuto(true, false); out[1] = visible
                UI:OnAHStateAuto(false, visible); out[2] = visible
                -- 2. vorher offen -> bleibt offen
                visible = true
                UI:OnAHStateAuto(true, true); UI:OnAHStateAuto(false, true); out[3] = visible
                -- 3. Option aus -> nichts
                st.openWithAH = false; visible = false
                UI:OnAHStateAuto(true, false); out[4] = visible
                UI:OnAHStateAuto(false, false); out[5] = visible
                return out
            end) }
            st.openWithAH = saved.opt
            UI.Show, UI.Hide, UI.IsVisible, UI.autoOpened, UI.wasOpenBeforeAH = saved.show, saved.hide, saved.vis, saved.auto, saved.was
            if not res[1] then error(res[2], 0) end
            local o = res[2]
            return o[1] == true and o[2] == false and o[3] == true and o[4] == false and o[5] == false,
                string.format("auf %s, zu %s, vorher offen %s, Option aus: %s/%s", tostring(o[1]), tostring(o[2]), tostring(o[3]),
                    tostring(o[4]), tostring(o[5])), "auf true, zu false, vorher offen true, Option aus false/false"
        end)
        end)
        B(function()
        Chk("T220", "J", "Hauptfenster bleibt im Bildschirm: höchstens 90 %, Position geklemmt", function()
            local UI = A.UI
            if not (UIParent and UIParent.GetWidth and CreateFrame) then return "SKIP", "kein UIParent" end
            local U = A.UIC and A.UIC.UICheck
            if U and U.LayoutReal and not U.LayoutReal() then return "SKIP", "kein echtes Layout (GetRect wertet Anker nicht aus)" end
            local f = CreateFrame("Frame", nil, UIParent)
            local sw, sh = UIParent:GetWidth(), UIParent:GetHeight()
            f:SetSize(sw * 1.5, sh * 1.5)
            f:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", sw * 0.8, -sh * 0.5)
            local res = { pcall(UI.EnsureOnScreen, UI, f) }
            local l, b, w, h = f:GetRect()
            local sc, ps = f:GetEffectiveScale(), UIParent:GetEffectiveScale()
            f:Hide()
            if not res[1] then error(res[2], 0) end
            if not l then return "SKIP", "keine Rechtecke (Client ohne Layout)" end
            local inside = l * sc >= -1 and b * sc >= -1 and (l + w) * sc <= sw * ps + 1 and (b + h) * sc <= sh * ps + 1
            local share = (w * sc) / (sw * ps)
            return inside and share <= 0.91, string.format("im Bildschirm %s, Breite %.0f %% (l %.0f b %.0f w %.0f h %.0f, Massstab %.2f/%.2f, Bildschirm %.0f x %.0f)",
                tostring(inside), share * 100, l, b, w, h, sc, ps, sw, sh),
                "ganz im Bildschirm, höchstens 90 %"
        end)
        end)
        -- 0.65.29: Entzauberungswert statt "Gewinn", Gewinn beim Kauf, Block = Summe, Ausreisser; Teilen nach 10 / 2 Minuten
        B(function()
        Chk("T223", "J", "Entzauberungswert gleich je Gruppe, Gewinn beim Kauf je Kaufpreis, Block-Anteile = Wert, Ausreisser zählt nicht", function()
            local TT = A.Tooltip
            return WithDE(4, function(D, KEY, DUST, ESS)
                local savedCur = A.GetCurrent
                local cur = A.GetCurrent
                -- Ausreisser: Essenz aktuell 2c bei Median 300c -> zählt nicht (Markt), unsicher
                A.GetCurrent = function(self, id) if id == ESS then return 2, 5, time() - 60 end return cur(self, id) end
                TT.buyContext = { itemID = FAKE_ID, price = 100 }
                local a = TT:DisenchantShort(FAKE_ID)
                TT.buyContext = { itemID = FAKE_ID, price = 1000 }
                local b = TT:DisenchantShort(FAKE_ID)
                TT.buyContext = nil
                local v = D:GetValue(FAKE_ID)
                local sum, essRow = 0, nil
                for _, r in ipairs(D:EstimateRows(FAKE_ID)) do sum = sum + (r.share or 0); if r.id == ESS then essRow = r end end
                A.GetCurrent = savedCur
                local ok = a and b and a.net == b.net and a.gain == a.net - 100 and b.gain == b.net - 1000 and a.left:find(L["Entzauberungswert"], 1, true)
                    and math.abs(sum - v) <= 1 and essRow and essRow.price == 300 and essRow.unsure == true and essRow.source == "market"
                return ok and true or false, string.format("Wert %s/%s, Gewinn %s/%s, Summe %.0f = %s, Essenz %s (%s, unsicher %s)",
                    tostring(a and a.net), tostring(b and b.net), tostring(a and a.gain), tostring(b and b.gain), sum, tostring(v),
                    tostring(essRow and essRow.price), tostring(essRow and essRow.source), tostring(essRow and essRow.unsure)),
                    "gleicher Wert, Gewinn = Wert - Kaufpreis, Summe = Wert, 2c-Angebot ignoriert (Markt 300c)"
            end)
        end)
        end)
        B(function()
        Chk("T222", "J", "Entzauberungen teilen: nach 10 neuen oder 2 Minuten nach der letzten, nicht vorher", function()
            local D = A.Disenchant
            -- Sandbox (Befund 22:25, Pfad "deLog"): D:Record schreibt über LogResult in deLog/deBuys -> Ersatztabellen
            local saved = { bc = D.BroadcastStats, un = D.unshared, last = D.lastRecordAt, st = A.db.deStats, prior = D.Prior, after = D.SHARE_AFTER,
                log = A.db.deLog, buys = A.db.deBuys }
            A.db.deLog, A.db.deBuys = {}, {}
            local sent = 0
            local res = { pcall(function()
                D.BroadcastStats = function(self) sent = sent + 1; self.unshared = 0; return true end
                D.SHARE_AFTER = 99999            -- Zeitgeber im Test nicht abwarten, ShareIfQuiet direkt aufrufen
                D.Prior = function(self, id) if id == FAKE_ID then return D:PriorForKey("2:2:a"), "2:2:a" end return saved.prior(self, id) end
                A.db.deStats, D.unshared = {}, 0
                for _ = 1, 3 do D:Record(FAKE_ID, { { 10940, 2 } }) end
                local after3 = sent
                local early = D:ShareIfQuiet(-1)          -- inzwischen kam eine neue: nicht teilen
                local quiet = D:ShareIfQuiet(D.lastRecordAt)
                local after2min = sent
                for _ = 1, 10 do D:Record(FAKE_ID, { { 10940, 2 } }) end
                return after3, early, after2min, sent
            end) }
            D.BroadcastStats, D.unshared, D.lastRecordAt, A.db.deStats, D.Prior, D.SHARE_AFTER = saved.bc, saved.un, saved.last, saved.st, saved.prior, saved.after
            A.db.deLog, A.db.deBuys = saved.log, saved.buys
            if not res[1] then error(res[2], 0) end
            local after3, early, after2min, total = res[2], res[3], res[4], res[5]
            return after3 == 0 and not early and after2min == 1 and total == 2, string.format("nach 3: %d, zu früh: %s, nach 2 Min.: %d, nach 10 weiteren: %d",
                after3, tostring(early), after2min, total), "0, false, 1, 2"
        end)
        end)
        -- 0.65.30: Preise je Server und Fraktion/Auktionshaus, Sync mit Kennung
        B(function()
        Chk("T225", "J", "Preise je Server/Fraktion: getrennte Listen, neutrales AH eigen, fremde und alte Sync-Preise verworfen", function()
            local db, S = A.db, A.Sync
            local saved = { md = db.marketData, own = db.lastOwnScan, markets = db.markets, key = A.marketKey, mig = db.marketsMigrated,
                ov = A.apiOverride, hd = S.HandleData, recv = db.sync.lastScanTimeReceived }
            local res = { pcall(function()
                local o = {}
                for k, v in pairs(A.apiOverride or {}) do o[k] = v end
                local npcFaction = nil
                o.GetRealmName = function() return "AHS-Testserver" end
                o.UnitFactionGroup = function(u) if u == "npc" then return npcFaction end return "Horde" end
                o.C_Map = { GetBestMapForUnit = function() return 1446 end }        -- Tanaris
                A.apiOverride = o
                db.markets, db.marketsMigrated, A.marketKey = {}, true, nil
                db.marketData = {}
                local kH = A:MarketKey(false)
                A:ActivateMarket(kH)
                db.marketData[FAKE_ID] = { history = { { t = time(), p = 111, q = 1 } } }
                npcFaction = nil                                       -- neutraler Auktionator in Tanaris
                local kN = A:MarketKey(true)
                A:ActivateMarket(kN)
                local emptyNeutral = db.marketData[FAKE_ID] == nil
                A:ActivateMarket(kH)
                local back = db.marketData[FAKE_ID] ~= nil
                npcFaction = "Horde"
                local kH2 = A:MarketKey(true)
                -- Sync: richtige Kennung angenommen, fremde und alte ohne Kennung verworfen
                local got = 0
                S.HandleData = function() got = got + 1; return 1 end
                local tag, other = A:MarketTag(kH), A:MarketTag("AHS-Testserver|Alliance")
                local t = S.Enc(time())
                S:OnMessage("AHAP1", "P:" .. t .. ":" .. tag .. ":1,2,3", "GUILD", "AHSFremder-X")
                S:OnMessage("AHAP1", "P:" .. t .. ":" .. other .. ":1,2,3", "GUILD", "AHSFremder-X")
                S:OnMessage("AHAP1", "D:" .. t .. ":1,2,3", "GUILD", "AHSFremder-X")
                return kH, kN, kH2, emptyNeutral, back, got
            end) }
            db.marketData, db.lastOwnScan, db.markets, A.marketKey, db.marketsMigrated = saved.md, saved.own, saved.markets, saved.key, saved.mig
            A.apiOverride, S.HandleData, db.sync.lastScanTimeReceived = saved.ov, saved.hd, saved.recv
            if A.ClearPriceCaches then A:ClearPriceCaches() end
            if not res[1] then error(res[2], 0) end
            local kH, kN, kH2, emptyNeutral, back, got = res[2], res[3], res[4], res[5], res[6], res[7]
            local ok = kH == "AHS-Testserver|Horde" and kN == "AHS-Testserver|Neutral" and kH2 == kH and emptyNeutral and back and got == 1
            return ok, string.format("Horde %s, neutral %s, Horde-AH %s, neutral leer %s, zurück %s, Sync angenommen %d von 3",
                kH, kN, kH2, tostring(emptyNeutral), tostring(back), got), "getrennt, neutral eigen, nur 1 von 3 Sync-Nachrichten"
        end)
        end)
        -- 0.65.31: EINE Preisfunktion (Werte stimmen Punkt 8) mit Quellen-Reihenfolge und Händler-Untergrenze
        B(function()
        Chk("T226", "J", "Eine Preisfunktion (K3): Wert = letzter Scan ohne Abzug/Deckel, Ausreisser -> Median, eigener Verkauf nur Statistik, Händler als Untergrenze, überall gleich", function()
            local saved = { cur = A.GetCurrent, mv = A.GetMarketValue, sale = A.Ledger.AverageSalePrice, vp = A.db.vendorPrices[FAKE_ID],
                scan = A.db.lastScanTime, nro = A.NextRealOffer }
            local res = { pcall(function()
                local sale, cur, med = nil, 900, 1000
                A.db.lastScanTime = time() - 600
                A.NextRealOffer = function() return nil end
                A.GetCurrent = function(self, id) if id == FAKE_ID then return cur, 1, time() - 60 end return saved.cur(self, id) end
                A.GetMarketValue = function(self, id) if id == FAKE_ID then return med end return saved.mv(self, id) end
                A.Ledger.AverageSalePrice = function(self, id, d) if id == FAKE_ID then return sale end return saved.sale(self, id, d) end
                A.db.vendorPrices[FAKE_ID] = 1
                local pAH, iAH = A:RealPrice(FAKE_ID)                 -- 900 (genau das Angebot)
                cur = 5000; local pHigh = A:RealPrice(FAKE_ID)        -- kein Deckel: 5000
                cur = 50; local pOut, iOut = A:RealPrice(FAKE_ID)     -- 5 % vom Median: Ausreisser -> Median
                cur = 900; sale = 400; local pSale, iSale = A:RealPrice(FAKE_ID) -- eigener Verkauf ändert nichts
                local same = A.Crafting:UnitPrice(FAKE_ID) == pSale and A:GetSalePrice(FAKE_ID) == pSale and A.Disenchant:MatPrice(FAKE_ID) == pSale
                A.db.vendorPrices[FAKE_ID] = 5000
                local v, _, _, vendorWins = A:RealValue(FAKE_ID, 2)
                return pAH, iAH.source, pHigh, pOut, iOut.source, iOut.unsure, pSale, iSale.source, iSale.sale, same, v, vendorWins
            end) }
            A.GetCurrent, A.GetMarketValue, A.Ledger.AverageSalePrice, A.db.vendorPrices[FAKE_ID] = saved.cur, saved.mv, saved.sale, saved.vp
            A.db.lastScanTime, A.NextRealOffer = saved.scan, saved.nro
            if not res[1] then error(res[2], 0) end
            local pAH, sAH, pHigh, pOut, sOut, unsure, pSale, sSale, saleStat, same, v, vw = unpack(res, 2)
            local ok = pAH == 900 and sAH == "ah" and pHigh == 5000 and pOut == 1000 and sOut == "market" and unsure and pSale == 900
                and sSale == "ah" and saleStat == 400 and same and v == 10000 and vw
            return ok, string.format("Scan %s (%s), ohne Deckel %s, Ausreisser %s (%s), mit eigenem Verkauf %s (%s, Statistik %s), überall gleich %s, Händler %s (%s)",
                tostring(pAH), tostring(sAH), tostring(pHigh), tostring(pOut), tostring(sOut), tostring(pSale), tostring(sSale), tostring(saleStat),
                tostring(same), tostring(v), tostring(vw)), "900 ah, 5000, 1000 market, 900 ah (Statistik 400), gleich, 10000 Händler"
        end)
        end)
        -- 0.65.32: Entzauber-Tabelle nach Disenchantry (MIT), Forever-Waffen 21-30, Mengen min-max, kein zweiter Block
        B(function()
        Chk("T227", "J", "Entzauber-Tabelle (Disenchantry): Forever-Waffe 21-30 Grosse Magieessenz, Itemstufe 23 Rüstung 75/15/10 mit 4-6 Staub", function()
            local D = A.Disenchant
            local saved = A.forceForever
            local res = { pcall(function()
                A.forceForever = true
                local wF = D:PriorForKey("2:3:w")
                A.forceForever = false
                local wE = D:PriorForKey("2:3:w")
                local a3 = D:PriorForKey("2:3:a")          -- Era-Tabelle (0.65.67: Forever hat den Leitfaden, T293)
                A.forceForever = saved
                return wF, wE, a3
            end) }
            A.forceForever = saved
            if not res[1] then error(res[2], 0) end
            local wF, wE, a3 = res[2], res[3], res[4]
            local ok = wF[2][1] == 10939 and wE[2][1] == 10998 and a3[1][2] == 0.75 and a3[2][2] == 0.15 and a3[3][2] == 0.10
                and a3[1][4] == 4 and a3[1][5] == 6 and wF[2][2] == 0.75
            return ok, string.format("Forever-Waffe Essenz %s (sonst %s), Rüstung 23: %d/%d/%d %%, Staub %s-%s", tostring(wF[2][1]), tostring(wE[2][1]),
                a3[1][2] * 100, a3[2][2] * 100, a3[3][2] * 100, tostring(a3[1][4]), tostring(a3[1][5])), "10939 (sonst 10998), 75/15/10, 4-6"
        end)
        end)
        B(function()
        Chk("T228", "J", "Materialblock (T-V4, T-D1, T-D3, T-D4, T-V6): auch mit Disenchantry, ohne Shift, 'Tabelle'; Modus 'kurz' ohne Block", function()
            local TT = A.Tooltip
            return WithDE(4, function()
                local o = {}
                for k, v in pairs(A.apiOverride or {}) do o[k] = v end
                o.IsShiftKeyDown = function() return false end         -- Variante A: Block ohne Shift
                A.apiOverride = o
                A.db.settings.tooltipDEMode = "mats"
                local t1 = FakeTT(); TT:AddDisenchantLines(t1, FAKE_ID)
                o.DisenchantryLoaded = true
                local t2 = FakeTT(); TT:AddDisenchantLines(t2, FAKE_ID)
                local hasBlock1 = table.concat(t1.lines, "|"):find(L["Materialien (Tabelle)"]:sub(1, -2), 1, true) ~= nil
                local hasBlock2 = table.concat(t2.lines, "|"):find(L["Materialien (Tabelle)"]:sub(1, -2), 1, true) ~= nil
                A.db.settings.tooltipDEMode = "short"
                local t3 = FakeTT(); TT:AddDisenchantLines(t3, FAKE_ID)
                local hasBlock3 = table.concat(t3.lines, "|"):find(L["Materialien (Tabelle)"]:sub(1, -2), 1, true) ~= nil
                return hasBlock1 and hasBlock2 and not hasBlock3, string.format("ohne Disenchantry Block %s, mit Disenchantry Block %s, Modus kurz %s",
                    tostring(hasBlock1), tostring(hasBlock2), tostring(hasBlock3)), "Block immer (auch mit Disenchantry), nur nicht bei 'kurz'"
            end)
        end)
        end)
        -- T229 (0.65.33) ersetzt durch T232 (Stück je Auktion: gewählt / gelernt aus der Buchhaltung / 1)
        -- 0.65.34: Sammelkauf zum Entzaubern
        local function WithDEBuy(fn)
            local DEB = A.DEBuy
            local saved = { buy = A.Buy, open = A.IsAHOpen, combat = A.InCombat, free = A.Mailer.FreeSlots, value = DEB.Value,
                session = DEB.session, skipped = DEB.skipped, max = A.db.settings.deBuyMax, roi = A.db.settings.deBuyRoi,
                buys = A.db.deBuys, prior = A.Disenchant.Prior, comm = A.IsCommodityItem, lp = DEB.lastPlanned,
                sm = A.Disenchant.StaleMain, bi = A.BuyoutInfo }
            local res = { pcall(function()
                local bought = {}
                -- TR (13.11.): Materialpreise in der Sandbox frisch und ohne Aufkauf - nie die echten Preise/Zeiten
                A.Disenchant.StaleMain = function(self, id) if id >= FAKE_ID then return DEB.testStale or false, 10940, DEB.testStale and 25 or 0 end return saved.sm(self, id) end
                A.BuyoutInfo = function(self, id) if id == 10940 or id >= FAKE_ID then return nil end return saved.bi(self, id) end
                local fakeB = { results = {}, detail = nil }
                function fakeB:Open(key) self.detail = { itemID = type(key) == "table" and key.itemID or key, listings = self.offers[type(key) == "table" and key.itemID or key] or {}, loading = false } return true end
                -- Antwort des Servers gleich mitschicken (Sammelkauf zählt erst bei Erfolg, offener Punkt 4)
                function fakeB:BuyItem(l)
                    bought[#bought + 1] = l; l.used = true
                    A:Fire("BUY_PURCHASE_RESULT", not self.failNext, { itemID = l.itemID, cost = l.buyout })
                    return true
                end
                fakeB.offers = {}
                A.Buy = fakeB
                A.IsAHOpen = function() return true end
                A.InCombat = function() return false end
                A.IsCommodityItem = function() return false end
                A.Disenchant.Prior = function(self, id) if id >= FAKE_ID then return { { 10940, 1, 1 } }, "2:1:a" end return saved.prior(self, id) end
                local free = 10
                A.Mailer.FreeSlots = function() return free end
                DEB.session, DEB.skipped, A.db.deBuys = { bought = 0, paid = 0, expected = 0 }, {}, {}
                A.db.settings.deBuyMax, A.db.settings.deBuyRoi = 50000, 20
                return fn(DEB, fakeB, bought, function(n) free = n end)
            end) }
            A.Buy, A.IsAHOpen, A.InCombat, A.Mailer.FreeSlots, DEB.Value = saved.buy, saved.open, saved.combat, saved.free, saved.value
            DEB.session, DEB.skipped, A.db.settings.deBuyMax, A.db.settings.deBuyRoi = saved.session, saved.skipped, saved.max, saved.roi
            A.db.deBuys, A.Disenchant.Prior, A.IsCommodityItem, DEB.lastPlanned = saved.buys, saved.prior, saved.comm, saved.lp
            A.Disenchant.StaleMain, A.BuyoutInfo, DEB.testStale = saved.sm, saved.bi, nil
            if not res[1] then error(res[2], 0) end
            return select(2, unpack(res))
        end
        B(function()
        Chk("T230", "J", "Sammelkauf: nur bis \"Lohnt bis\" (RK2-A, Rendite nicht doppelt) und >= 10c Gewinn, sortiert; Marge 10 % unter 10 Entzauberungen", function()
            return WithDEBuy(function(DEB, fakeB)
                local D = A.Disenchant
                local savedDV, savedBN = D.DealValue, D.BatchNet
                local nDE = 4
                D.DealValue = function(self, id) return 1000, 1000, true, "estimate", nDE end
                D.BatchNet = function() return nil end                  -- X4a: Mengen-Senkung hat einen eigenen Test (T-X4b)
                -- Rechnung wie vor Stufe 2 (Option "Lernen" aus, T-L12); mit Lernen gilt die gelernte Marge (T317)
                local Ln = A.Learn
                if Ln then Ln.forceOff = true end
                local rows = {
                    { itemID = FAKE_ID, price = 500 },          -- Wert 900 (Abschlag) -> +400, 80 %
                    { itemID = FAKE_ID + 1, price = 800 },      -- +100, 12 % -> unter 20 %
                    { itemID = FAKE_ID + 2, price = 300 },      -- +600, 200 %
                    { itemID = FAKE_ID + 3, price = 895 },      -- +5c -> unter 10c
                }
                local list = DEB:Candidates(rows)
                nDE = 12
                local v12 = DEB:Value(FAKE_ID)
                D.DealValue, D.BatchNet = savedDV, savedBN
                if Ln then Ln.forceOff = nil end
                -- RK2-A: Lohnt bis = 1000 × min(1/1,2; 0,9) = 833 (Mindestrendite strenger); Gewinn gegen Lohnt bis
                local ok = #list == 3 and list[1].itemID == FAKE_ID + 2 and list[1].profit == 533 and list[2].profit == 333 and list[3].profit == 33 and v12 == 833
                return ok, string.format("%d Kandidaten, oben %s (+%s), danach +%s, +%s, Wert ab 10 Entzauberungen %s", #list,
                    tostring(list[1] and list[1].itemID - FAKE_ID), tostring(list[1] and list[1].profit), tostring(list[2] and list[2].profit), tostring(list[3] and list[3].profit), tostring(v12)),
                    "3, oben +533, dann +333, +33, Wert 833"
            end)
        end)
        end)
        B(function()
        Chk("T503", "J", "T-MP2b Sammelkauf mit veraltetem Hauptmaterial -> 0 Kandidaten, Grund \"stale\" (eigener Fall, nicht in T230/T425)", function()
            return WithDEBuy(function(DEB)
                local D = A.Disenchant
                local savedDV = D.DealValue
                D.DealValue = function(self, id) return 1000, 1000, true, "estimate", 20 end
                DEB.testStale = true
                local res = { pcall(function()
                    local list = DEB:Candidates({ { itemID = FAKE_ID, price = 300 } })
                    local _, why = D:PlannedValue(FAKE_ID, 1)
                    return #list, why
                end) }
                D.DealValue = savedDV
                if not res[1] then error(res[2], 0) end
                return res[2] == 0 and res[3] == "stale", string.format("%d Kandidaten · Grund %s", res[2], tostring(res[3])), "0 · stale"
            end)
        end)
        Chk("T425", "J", "T-X4b Sammelkauf: 3 Kandidaten zu 300c, Budget 50000 -> Mengen-Senkung mit nParts = 3 (nicht 166)", function()
            return WithDEBuy(function(DEB)
                local D = A.Disenchant
                local savedDV, savedBN = D.DealValue, D.BatchNet
                local seen = {}
                D.DealValue = function(self, id) return 1000, 1000, true, "estimate", 20 end
                D.BatchNet = function(self, id, n) seen[#seen + 1] = n; return nil end
                local Ln = A.Learn
                if Ln then Ln.forceOff = true end
                local savedMax = A.db.settings.deBuyMax
                A.db.settings.deBuyMax = 50000
                local res = { pcall(function()
                    return DEB:Candidates({ { itemID = FAKE_ID, price = 300 }, { itemID = FAKE_ID + 1, price = 300 }, { itemID = FAKE_ID + 2, price = 300 } })
                end) }
                D.DealValue, D.BatchNet = savedDV, savedBN
                A.db.settings.deBuyMax = savedMax
                if Ln then Ln.forceOff = nil end
                if not res[1] then error(res[2], 0) end
                local maxN = 0
                for _, n in ipairs(seen) do if n > maxN then maxN = n end end
                local ok = #res[2] == 3 and DEB.lastPlanned == 3 and maxN == 3
                return ok, string.format("%d Kandidaten · geplant %s · grösste Menge an BatchNet %d", #res[2], tostring(DEB.lastPlanned), maxN), "3 · 3 · 3"
            end)
        end)
        end)
        B(function()
        Chk("T231", "J", "Sammelkauf: Raste kauft das oberste; weg/teurer übersprungen; Stopp bei Gold-Grenze und vollen Taschen; Statuszeile", function()
            return WithDEBuy(function(DEB, fakeB, bought, setFree)
                DEB.Value = function(self, id) return 1000, "actual", 20 end
                fakeB.results = { { itemID = FAKE_ID, price = 300 }, { itemID = FAKE_ID + 1, price = 500 }, { itemID = FAKE_ID + 2, price = 400 } }
                fakeB.offers = {
                    [FAKE_ID] = { { auctionID = 1, buyout = 300, qty = 1 } },
                    [FAKE_ID + 2] = { { auctionID = 3, buyout = 450, qty = 1 } },              -- teurer als gelistet
                    [FAKE_ID + 1] = { { auctionID = 2, buyout = 500, qty = 1 } },
                }
                local steps = {}
                local function step() local ok, msg, st = DEB:Next(); steps[#steps + 1] = st end
                step(); step()                       -- oberstes (+700): laden, kaufen
                step(); step()                       -- nächstes (+600, FAKE+2): laden, teurer -> übersprungen
                step(); step()                       -- FAKE+1 (+500): laden, kaufen
                local status = DEB:StatusText()
                -- Gold-Grenze: 8c bezahlt, Grenze 7c
                fakeB.results = { { itemID = FAKE_ID + 5, price = 300 } }
                A.db.settings.deBuyMax = 900
                local _, _, stLimit = DEB:Next()
                A.db.settings.deBuyMax = 50000
                setFree(0)
                local _, _, stBags = DEB:Next()
                local ok = table.concat(steps, ",") == "loading,bought,loading,skipped,loading,bought" and #bought == 2 and bought[1].auctionID == 1
                    and bought[2].auctionID == 2 and DEB.session.paid == 800 and DEB.session.expected == 1200 and stLimit == "stop" and stBags == "stop"
                    and #A.db.deBuys == 2
                return ok, string.format("%s · gekauft %d · %s · Grenze %s · Taschen %s", table.concat(steps, ","), #bought, status, tostring(stLimit), tostring(stBags)),
                    "laden/kaufen, weg/teurer übersprungen, 2 Käufe 8c, +12c erwartet, Stopp bei Grenze und Taschen"
            end)
        end)
        end)
        -- 0.65.35: Stück je Auktion (Befund 11:31/11:32), Menge = alles aus den Taschen, Buchhaltung L1/L2/L5
        B(function()
        Chk("T232", "J", "Stück je Auktion: ohne Daten 1, selbst gewählt 20, gelernt aus Einstellungen; Verkaufsgebühr 5 % abgerundet (Wollstoffballen 3s97: 19c, +36c)", function()
            local saved = { force = A.forceForever, own = A.db.settings.auctionSize, ps = A.Ledger.PostSizes }
            local ID
            for _, id in ipairs({ 2997, 2447, 2589 }) do if A:StackSize(id) >= 20 then ID = id; break end end
            if not ID then return "SKIP", "kein stapelbares Item mit Daten im Client" end
            local res = { pcall(function()
                A.forceForever = true
                A.db.settings.auctionSize = {}
                local learned = {}
                A.Ledger.PostSizes = function(self, id) return learned end
                local n0, s0 = A:AuctionSize(ID)
                local fee1 = A:SaleFee(ID, 397, 1)              -- 5 % (Gebühren klassisch), unabhängig von der Menge je Auktion
                local profit1 = 397 - fee1 - 342
                A:CycleAuctionSize(ID); A:CycleAuctionSize(ID); A:CycleAuctionSize(ID)   -- 1 -> 5 -> 20
                local n20, s20 = A:AuctionSize(ID)
                local fee20 = A:SaleFee(ID, 397, 1)
                A.db.settings.auctionSize = {}
                learned = { 5, 5, 1, 5, 20 }
                local nL, sL = A:AuctionSize(ID)
                return n0, s0, fee1, profit1, n20, s20, fee20, 397 - fee20 - 342, nL, sL
            end) }
            A.forceForever, A.db.settings.auctionSize, A.Ledger.PostSizes = saved.force, saved.own, saved.ps
            if not res[1] then error(res[2], 0) end
            local n0, s0, fee1, p1, n20, s20, fee20, p20, nL, sL = unpack(res, 2)
            -- H1 (Befund 07:35): ohne Daten im modernen AH = die ganze Menge als EINE Auktion (mindestens ein Stapel)
            local ok = ((A.AH_LEGACY and n0 == 1 and s0 == "default") or (not A.AH_LEGACY and n0 >= 20 and s0 == "whole")) and fee1 == 19 and p1 == 36 and n20 == 20 and s20 == "own" and fee20 == 19 and p20 == 36 and nL == 5 and sL == "learned"
            return ok, string.format("ohne Daten %d (%s): Gebühr %d, Gewinn %d · gewählt %d: Gebühr %d, Gewinn %d · gelernt %d (%s)",
                n0, s0, fee1, p1, n20, fee20, p20, nL, sL), "ganze Menge (whole): 19, +36 · 20: 19, +36 · gelernt 5"
        end)
        end)
        B(function()
        Chk("T233", "J", "Buchhaltung Forever: Verkauf = Post-Gold (keine zweite Gebühr, keine Erstattung); Abbrechen bucht gemessene Erstattung", function()
            local Le = A.Ledger
            local db = A.db.ledger
            local saved = { entries = db.entries, seen = db.seen, force = A.forceForever, inbox = A.Inbox.Available, n = _G.GetInboxNumItems,
                h = _G.GetInboxHeaderInfo, i = _G.GetInboxInvoiceInfo }
            local res = { pcall(function()
                db.entries, db.seen = {}, {}
                A.forceForever = true
                -- Rechnung aus der Post (Forever): Preis 3s98, consignment 20c, deposit 1s, Post-Gold 3s98
                local mail = { money = 398, price = 398, cons = 20, dep = 100 }
                Le:Add({ kind = "sale", t = time(), itemID = FAKE_ID, qty = 1, amount = mail.money, cut = 0, refund = 0, src = "mail" })
                local s1 = Le:Summary("all")
                -- Abbrechen: Erstattung 40c gemessen
                Le:Add({ kind = "deposit", t = time(), itemID = FAKE_ID, qty = 1, amount = 100, src = "post" })
                Le:Add({ kind = "refund", t = time(), itemID = FAKE_ID, qty = 1, amount = 40, src = "cancel" })
                local s2 = Le:Summary("all")
                return s1.income, s1.fees, s2.fees
            end) }
            db.entries, db.seen, A.forceForever = saved.entries, saved.seen, saved.force
            if not res[1] then error(res[2], 0) end
            local income, fees1, fees2 = res[2], res[3], res[4]
            return income == 398 and fees1 == 0 and fees2 == 60, string.format("Erlös %d, Gebühren %d, nach Abbruch %d", income, fees1, fees2), "398, 0, 60 (1s - 40c Erstattung)"
        end)
        end)
        B(function()
        Chk("T234", "J", "E1 Entzauber-Wächter: meldet einmal je neuem Fund, höchstens 1x pro Minute, nie im Kampf, abschaltbar, kauft nie", function()
            local DEB = A.DEBuy
            local saved = { seen = DEB.seen, last = DEB.lastAlert, pend = DEB.pending, watch = A.db.settings.deWatch,
                pr = A.Print, sm = A.ScreenMessage, api = A.apiOverride }
            local res = { pcall(function()
                return WithDEBuy(function(D, fakeB, bought)
                    local now = 1000
                    A.apiOverride = setmetatable({ GetTime = function() return now end }, { __index = saved.api })
                    local msgs = 0
                    A.Print = function() msgs = msgs + 1 end
                    A.ScreenMessage = function() end
                    D.seen, D.lastAlert, D.pending = {}, -1000, false
                    A.db.settings.deWatch = nil
                    D.Value = function(self, id) return 2000 end
                    local rows = { { itemID = FAKE_ID, price = 1000 }, { itemID = FAKE_ID + 1, price = 1200 } }
                    local r1 = D:WatchCheck(rows) and 1 or 0           -- neu -> Meldung
                    local r2 = D:WatchCheck(rows) and 1 or 0           -- gleich -> keine
                    now = now + 10
                    rows[#rows + 1] = { itemID = FAKE_ID + 2, price = 900 }
                    local r3 = D:WatchCheck(rows) and 1 or 0           -- neu, aber < 60 s -> keine
                    now = now + 60
                    local r4 = D:WatchCheck(rows) and 1 or 0           -- offener Fund nach einer Minute -> Meldung
                    now = now + 120
                    rows[#rows + 1] = { itemID = FAKE_ID + 3, price = 800 }
                    A.InCombat = function() return true end
                    local r5 = D:WatchCheck(rows) and 1 or 0           -- Kampf -> keine
                    A.InCombat = function() return false end
                    A.db.settings.deWatch = false
                    local r6 = D:WatchCheck(rows) and 1 or 0           -- aus -> keine
                    return string.format("%d%d%d%d%d%d", r1, r2, r3, r4, r5, r6), msgs, #bought
                end)
            end) }
            DEB.seen, DEB.lastAlert, DEB.pending, A.db.settings.deWatch = saved.seen, saved.last, saved.pend, saved.watch
            A.Print, A.ScreenMessage, A.apiOverride = saved.pr, saved.sm, saved.api
            if not res[1] then error(res[2], 0) end
            local pattern, msgs, nb = res[2], res[3], res[4]
            return pattern == "100100" and msgs == 2 and nb == 0, string.format("Muster %s, Meldungen %d, Käufe %d", tostring(pattern), msgs or -1, nb or -1),
                "100100, 2 Meldungen, 0 Käufe"
        end)
        end)
        B(function()
        Chk("T235", "J", "E2 Entzauber-Fenster: gekaufte Teile zuerst; Set-, Quest-, Sperrlisten-, graue Teile nie; blau erst nach Freigeben", function()
            local DW, D = A.DEWindow, A.Disenchant
            if not (DW and D) then return "SKIP", "DEWindow fehlt" end
            local saved = { ns = DW.NumSlots, si = DW.SlotInfo, set = DW.InEquipmentSet, q = DW.IsQuestItem, prior = D.Prior,
                buys = A.db.deBuys, block = A.db.deBlock, skipped = DW.skipped, allowed = DW.allowed, vals = DW.Values }
            local res = { pcall(function()
                local F = FAKE_ID
                -- Tasche 0: 1 grün, 2 grün (Set), 3 grün (Quest), 4 grau, 5 grün (Sperrliste), 6 blau, 7 gekauftes grün
                local bag = { [1] = { F, 2 }, [2] = { F + 1, 2 }, [3] = { F + 2, 2 }, [4] = { F + 3, 0 }, [5] = { F + 4, 2 },
                    [6] = { F + 5, 3 }, [7] = { F + 6, 2 } }
                DW.NumSlots = function(self, b) return b == 0 and 7 or 0 end
                DW.SlotInfo = function(self, b, sl) local x = b == 0 and bag[sl]; return x and { itemID = x[1], quality = x[2] } or nil end
                DW.InEquipmentSet = function(self, b, sl) return sl == 2 end
                DW.IsQuestItem = function(self, b, sl) return sl == 3 end
                DW.Values = function() return 1000, 1100 end
                D.Prior = function(self, id) if id >= F and id <= F + 6 then return { { 10940, 1, 1 } }, "x" end return saved.prior(self, id) end
                A.db.deBuys = { { t = time() - 60, itemID = F + 6, paid = 500, value = 900 } }
                A.db.deBlock = { [F + 4] = true }
                DW.skipped, DW.allowed = {}, {}
                local q = DW:Queue()
                local ids = {}
                for _, e in ipairs(q) do ids[#ids + 1] = e.itemID - F end
                local order = table.concat(ids, ",")
                local rare1 = DW:NeedsConfirm(F + 5, 3)
                DW:Allow(F + 5)
                local rare2 = DW:NeedsConfirm(F + 5, 3)
                DW.Values = function() return 1000, 2000 end
                local sell = DW:NeedsConfirm(F, 2)
                DW:Skip()
                local afterSkip = DW:Current()
                return order, tostring(rare1), tostring(rare2), tostring(sell), afterSkip and (afterSkip.itemID - F) or -1
            end) }
            DW.NumSlots, DW.SlotInfo, DW.InEquipmentSet, DW.IsQuestItem, D.Prior = saved.ns, saved.si, saved.set, saved.q, saved.prior
            A.db.deBuys, A.db.deBlock, DW.skipped, DW.allowed, DW.Values = saved.buys, saved.block, saved.skipped, saved.allowed, saved.vals
            if not res[1] then error(res[2], 0) end
            local order, r1, r2, sell, nxt = res[2], res[3], res[4], res[5], res[6]
            local ok = order == "6,0,5" and r1 == "rare" and r2 == "nil" and sell == "sell" and nxt == 0
            return ok, string.format("Reihenfolge %s, blau %s->%s, Verkauf %s, nach Überspringen %s", order, r1, r2, sell, tostring(nxt)),
                "6,0,5 (gekauft zuerst), rare->nil, sell, 0"
        end)
        end)
        B(function()
        Chk("T236", "J", "E2 sicherer Knopf: Makro mit /stopmacro [combat] und Taschenplatz, im Kampf keine Attribute; Ergebnis hakt Sammelkauf ab", function()
            local DW, D = A.DEWindow, A.Disenchant
            if not (DW and D and D.LogResult) then return "SKIP", "DEWindow fehlt" end
            local macro = DW:MacroFor({ bag = 2, slot = 7, itemID = FAKE_ID }) or ""
            local okMacro = macro:find("^/stopmacro %[combat%]") ~= nil and macro:find("/use 2 7", 1, true) ~= nil
            local savedArm, savedCombat = DW.frame, A.InCombat
            local set = 0
            DW.frame = { deBtn = { SetAttribute = function() set = set + 1 end } }
            A.InCombat = function() return true end
            local armed = DW:Arm({ bag = 2, slot = 7, itemID = FAKE_ID, quality = 2 })
            A.InCombat = savedCombat
            DW.frame = savedArm
            local saved = { buys = A.db.deBuys, log = A.db.deLog }
            local res = { pcall(function()
                local now = time()
                A.db.deBuys = { { t = now - 100, itemID = FAKE_ID, paid = 700 }, { t = now - 50, itemID = FAKE_ID, paid = 800 } }
                A.db.deLog = {}
                local e = D:LogResult(FAKE_ID, { { 10940, 2 } }, now)
                return e.paid, A.db.deBuys[1].done ~= nil, A.db.deBuys[2].done == nil, #A.db.deLog
            end) }
            A.db.deBuys, A.db.deLog = saved.buys, saved.log
            if not res[1] then error(res[2], 0) end
            local ok = okMacro and armed == false and set == 0 and res[2] == 700 and res[3] and res[4] and res[5] == 1
            return ok, string.format("Makro %s, im Kampf gesetzt %d, Zuordnung %s/%s/%s", okMacro and "ok" or macro:gsub("\n", " | "), set,
                tostring(res[2]), tostring(res[3]), tostring(res[4])), "Makro ok, 0, 700/true/true"
        end)
        end)
        B(function()
        Chk("T237", "J", "E4 Abrechnung Entzaubern: 3 gekaufte Teile, bekannte Materialien -> ausgegeben, Wert, Gewinn, Rendite; eigene Teile getrennt", function()
            local Le, D = A.Ledger, A.Disenchant
            if not (Le and Le.DisenchantReport and D) then return "SKIP", "DisenchantReport fehlt" end
            local saved = { log = A.db.deLog, buys = A.db.deBuys, mp = D.MatPrice, fee = A.FeePerPiece }
            local res = { pcall(function()
                local now = time()
                D.MatPrice = function(self, id) if id == 10940 then return 300 elseif id == 10938 then return 1000 end return nil end
                A.FeePerPiece = function() return 0 end
                A.db.deBuys = {}
                A.db.deLog = {}
                -- 3 Teile zu je 500/600/700 gekauft, 4. Teil noch offen
                for k, paid in ipairs({ 500, 600, 700, 800 }) do
                    A.db.deBuys[k] = { t = now - 300 + k, itemID = FAKE_ID + k, paid = paid }
                end
                D:LogResult(FAKE_ID + 1, { { 10940, 2 } }, now)            -- 600
                D:LogResult(FAKE_ID + 2, { { 10938, 1 } }, now)            -- 1000
                D:LogResult(FAKE_ID + 3, { { 10940, 3 } }, now)            -- 900
                D:LogResult(FAKE_ID + 9, { { 10940, 1 } }, now)            -- eigenes Teil, 300
                local rows, t = Le:DisenchantReport("all")
                return t.count, t.spent, t.value, t.profit, math.floor((t.roi or 0) + 0.5), t.own, t.ownValue, t.open, t.openSpent, #rows
            end) }
            A.db.deLog, A.db.deBuys, D.MatPrice, A.FeePerPiece = saved.log, saved.buys, saved.mp, saved.fee
            if not res[1] then error(res[2], 0) end
            local got = table.concat({ res[2], res[3], res[4], res[5], res[6], res[7], res[8], res[9], res[10], res[11] }, "/")
            return got == "3/1800/2500/700/39/1/300/1/800/1", got, "3/1800/2500/700/39/1/300/1/800/1 (Anzahl/ausgegeben/Wert/Gewinn/Rendite/eigene/Wert/offen/offen-Preis/Tage)"
        end)
        end)
        B(function()
        Chk("T238", "J", "Werte stimmen 4: Sync-Preis passt zum eigenen Bild -> zählt; sonst erst mit zweitem Absender", function()
            local S = A.Sync
            if not (S and S.Judge) then return "SKIP", "Sync:Judge fehlt" end
            local saved = { gmv = A.GetMarketValue, pend = S.pendingConfirm }
            local res = { pcall(function()
                S.pendingConfirm = {}
                A.GetMarketValue = function(self, id) if id == FAKE_ID then return 1000 end return nil end
                local now = time()
                local a = S:Judge(FAKE_ID, 1500, "#a", now)             -- im Bild (150 %)
                local b = S:Judge(FAKE_ID, 22, "#a", now)               -- Ausreisser (2 %)
                local c = S:Judge(FAKE_ID + 1, 500, "#a", now)          -- kein eigenes Bild, erster Absender
                local d = S:Judge(FAKE_ID + 1, 520, "#a", now)          -- derselbe Absender nochmal
                local e = S:Judge(FAKE_ID + 1, 540, "#b", now)          -- zweiter Absender, ähnlich
                local f = S:Judge(FAKE_ID + 2, 500, "#a", now)
                local g = S:Judge(FAKE_ID + 2, 2000, "#b", now)         -- zweiter Absender, ganz anders
                return table.concat({ a, b, c, d, e, f, g }, ",")
            end) }
            A.GetMarketValue, S.pendingConfirm = saved.gmv, saved.pend
            if not res[1] then error(res[2], 0) end
            return res[2] == "ok,pending,pending,pending,confirmed,pending,pending", res[2], "ok,pending,pending,pending,confirmed,pending,pending"
        end)
        end)
        B(function()
        Chk("T239", "J", "Werte stimmen 2: halber Scan zählt nie als vollständig (nichts gilt als weg)", function()
            local db = A.db
            local saved = db.scanLog
            local res = { pcall(function()
                local now = time()
                db.scanLog = { { t = now - 300, items = 1000 }, { t = now - 200, items = 990, partial = true }, { t = now - 100, items = 950 } }
                local set, n = A:FullScanTimes(now - 86400)
                return n, set[now - 200] == nil, set[now - 100] == true
            end) }
            db.scanLog = saved
            if not res[1] then error(res[2], 0) end
            return res[2] == 2 and res[3] and res[4], string.format("vollständig %s, halber ausgeschlossen %s", tostring(res[2]), tostring(res[3])), "2, true"
        end)
        end)
        B(function()
        Chk("T240", "J", "Werte stimmen 6: Nicht-Verkauf kostet in Forever die Einzahlung (Quote 50 % -> 1x Einzahlung), Era unverändert", function()
            local Le = A.Ledger
            local saved = { pr = Le.PostRate, force = A.forceForever, rp = A.RealPrice, vp = A.GetVendorPrice, fpp = A.FeePerPiece, liq = A.GetLiquidity,
                sq = A.SellQueue, dd = A.DefaultDuration }
            if A.ResetOutlook then A:ResetOutlook() end
            local res = { pcall(function()
                A.RealPrice = function(self, id) return 10000, { value = 10000, source = "market" } end
                A.GetVendorPrice = function() return 0 end
                A.FeePerPiece = function(self, id, unit) return math.max(math.floor(unit * 0.05 + 0.5), 100) end
                A.GetLiquidity = function() return { perDay = 5, scans = 10 } end
                Le.PostRate = function() return 0, 0 end
                A.forceForever = true
                local base = A:RealValue(FAKE_ID, 1)                     -- 10000 - 500 = 9500
                Le.PostRate = function() return 10, 5 end                 -- Quote 50 % -> 2x einstellen
                A:ResetOutlook()
                local half, _, info = A:RealValue(FAKE_ID, 1)             -- 9500 - 100 (Einzahlung mind. 1s) = 9400
                Le.PostRate = function() return 0, 0 end
                A:ResetOutlook()
                -- 0.65.63 Angebot und Absatz: 3 vor mir, 2 je Tag, 24 Std. -> W = (3 + 1) / 2 = 2 Tage -> 2x einstellen
                A.GetLiquidity = function() return { perDay = 2, scans = 10, span = 3 } end
                A.SellQueue = function() return 3, "scan" end
                A.DefaultDuration = function() return 24 end
                if A.ResetOutlook then A:ResetOutlook() end
                local slow = A:RealValue(FAKE_ID, 1)                     -- 9500 - 100 = 9400
                A.forceForever = false
                local era = A:RealValue(FAKE_ID, 1)
                return base, half, info and info.listings, slow, era
            end) }
            Le.PostRate, A.forceForever, A.RealPrice, A.GetVendorPrice, A.FeePerPiece, A.GetLiquidity = saved.pr, saved.force, saved.rp, saved.vp, saved.fpp, saved.liq
            A.SellQueue, A.DefaultDuration = saved.sq, saved.dd
            if A.ResetOutlook then A:ResetOutlook() end
            if not res[1] then error(res[2], 0) end
            local got = string.format("%s/%s/%s/%s/%s", tostring(res[2]), tostring(res[3]), tostring(res[4]), tostring(res[5]), tostring(res[6]))
            -- Gebühren klassisch (0.65.42): verloren geht bei Rücklauf die Einzahlung (hier Minimum 1s), nicht die 5 %
            return got == "9500/9400/2/9400/9500", got, "9500/9400/2/9400/9500 (Quote 50 % bzw. 3 vor mir bei 2/Tag: 1x Einzahlung 1s verloren; Era unverändert)"
        end)
        end)
        B(function()
        Chk("T241", "J", "Werte stimmen 10: Vorhersage gegen Verkauf -> Abweichung je Gruppe und gesamt, Diag WERT", function()
            local Le = A.Ledger
            local db = A.db.ledger
            local saved = { entries = db.entries, rp = A.RealPrice }
            local res = { pcall(function()
                db.entries = {}
                local now = time()
                A.RealPrice = function() return 1100 end
                Le:Add({ kind = "deposit", t = now - 3600, itemID = FAKE_ID, qty = 2, amount = 100, src = "post" })
                A.RealPrice = function() return 900 end
                Le:Add({ kind = "deposit", t = now - 3500, itemID = FAKE_ID + 1, qty = 1, amount = 100, src = "post" })
                Le:Add({ kind = "sale", t = now, itemID = FAKE_ID, qty = 2, amount = 2000, src = "mail", inv = { price = 2000 } })       -- 1100 vs 1000: +10 %
                Le:Add({ kind = "sale", t = now, itemID = FAKE_ID + 1, qty = 1, amount = 1000, src = "mail", inv = { price = 1000 } })   -- 900 vs 1000: -10 %
                Le:Add({ kind = "sale", t = now, itemID = FAKE_ID + 2, qty = 1, amount = 1000, src = "mail" })                           -- ohne Vorhersage
                local t = Le:Deviation("all")
                local diag = A.Diag and A.Diag.Count and A.Diag:Count("WERT") or nil
                return t.n, math.floor((t.avg or 9) * 1000 + 0.5), db.entries[3].dev and math.floor(db.entries[3].dev * 100 + 0.5)
            end) }
            db.entries, A.RealPrice = saved.entries, saved.rp
            if not res[1] then error(res[2], 0) end
            local got = string.format("%s/%s/%s", tostring(res[2]), tostring(res[3]), tostring(res[4]))
            return got == "2/0/10", got, "2 Verkäufe, Schnitt 0 (+10 % und -10 %), erster +10 %"
        end)
        end)
        B(function()
        Chk("T242", "I", "Testroutine ersetzt keine Blizzard-Funktionen/-Fenster (TakeInboxMoney, MailFrame, IsInGuild, ProfessionsFrame)", function()
            local names = { "TakeInboxMoney", "MailFrame", "IsInGuild", "ProfessionsFrame" }
            local changed = {}
            for _, n in ipairs(names) do
                if TR.startGlobals and TR.startGlobals[n] ~= _G[n] then changed[#changed + 1] = n end
                if issecurevariable and TR.startSecure and TR.startSecure[n] ~= nil then
                    local sec = issecurevariable(n)
                    if sec ~= TR.startSecure[n] then changed[#changed + 1] = n .. " (Taint)" end
                end
            end
            if not TR.startGlobals then return "SKIP", "Startwerte nicht gemerkt" end
            return #changed == 0, #changed == 0 and "alle unverändert" or table.concat(changed, ", "), "alle unverändert"
        end)
        end)
        B(function()
        Chk("T243", "S", "Spieltest S7 zählt nur Zauber, die ein Rezept des offenen Berufs sind", function()
            local P = A.Spieltest
            if not (P and P.IsCraftSpell) then return "SKIP", "IsCraftSpell fehlt" end
            local saved = A.apiOverride
            local res = { pcall(function()
                A.apiOverride = setmetatable({ C_TradeSkillUI = { GetRecipeInfo = function(id) if id == 2330 then return { recipeID = 2330 } end return nil end } },
                    { __index = saved })
                local modernYes, modernNo = P:IsCraftSpell(2330), P:IsCraftSpell(8936)
                A.apiOverride = setmetatable({ C_TradeSkillUI = false, GetSpellInfo = function(id) return id == 7934 and "Gegengift" or "Heilende Berührung" end,
                    GetNumTradeSkills = function() return 2 end,
                    GetTradeSkillInfo = function(i) if i == 1 then return "Tränke", "header" end return "Gegengift", "easy" end }, { __index = saved })
                local oldYes, oldNo = P:IsCraftSpell(7934), P:IsCraftSpell(5185)
                return modernYes, modernNo, oldYes, oldNo
            end) }
            A.apiOverride = saved
            if not res[1] then error(res[2], 0) end
            local got = string.format("%s/%s/%s/%s", tostring(res[2]), tostring(res[3]), tostring(res[4]), tostring(res[5]))
            return got == "true/false/true/false", got, "Rezept ja, anderer Zauber nein (modern und alt)"
        end)
        end)
        B(function()
        Chk("T244", "J", "Kategorien: dritte Ebene (Waffen -> Einhändig -> Äxte) und Rückfall ohne AuctionCategories (B.testCategories)", function()
            local Bu = A.Buy
            local saved = Bu.testCategories
            local res = { pcall(function()
                Bu.testCategories = {
                    { name = "Waffen", filters = { { classID = 2 } }, subCategories = {
                        { name = "Einhändig", filters = { { classID = 2, subClassID = 0 }, { classID = 2, subClassID = 4 } }, subCategories = {
                            { name = "Äxte", filters = { { classID = 2, subClassID = 0 } } },
                            { name = "Streitkolben", filters = { { classID = 2, subClassID = 4 } } } } },
                        { name = "Bögen", filters = { { classID = 2, subClassID = 2 } } } } },
                    { name = "Rüstung", filters = { { classID = 4 } } },
                }
                Bu:BuildCategories()
                local axes, oneH, main
                for _, c in ipairs(Bu.CATS) do
                    if c.text == "Äxte" then axes = c elseif c.text == "Einhändig" then oneH = c elseif c.text == "Waffen" then main = c end
                end
                local okTree = axes and oneH and main and axes.level == 2 and axes.parent == oneH.key and oneH.parent == main.key
                local function visibleNames(key)
                    local n = {}
                    for _, c in ipairs(Bu:VisibleCats(key)) do n[#n + 1] = Bu:CatText(c) end
                    return table.concat(n, ",")
                end
                local closed = visibleNames(nil)
                local atMain = visibleNames(main and main.key)
                local atAxes = visibleNames(axes and axes.key)
                Bu.testCategories = {}            -- leer -> Rückfall über die Item-Klassen des Spiels
                Bu:BuildCategories()
                return okTree, closed, atMain, atAxes, Bu.catsFromGame
            end) }
            Bu.testCategories = saved
            Bu:BuildCategories()
            if not res[1] then error(res[2], 0) end
            local okTree, closed, atMain, atAxes, src = res[2], res[3], res[4], res[5], res[6]
            local ok = okTree and closed == "Alle,Waffen,Rüstung" and atMain == "Alle,Waffen,Einhändig,Bögen,Rüstung"
                and atAxes == "Alle,Waffen,Einhändig,Äxte,Streitkolben,Bögen,Rüstung" and (src == "ItemClass" or src == "fest")
            return ok and true or false, string.format("Baum %s · zu: %s · Waffen: %s · Äxte: %s · Rückfall %s", tostring(okTree), closed, atMain, atAxes, tostring(src)),
                "3 Ebenen, nur der offene Zweig sichtbar, Rückfall ItemClass (bzw. feste Liste)"
        end)
        end)
        B(function()
        Chk("T245", "J", "Heute tun: Unter Händlerpreis aus Scan/Suche rechnet mit 1 Stück (Menge gilt für alle Preisstufen)", function()
            local Bu, db = A.Buy, A.db
            local saved = { res = Bu.results, rt = Bu.resultsTime, det = Bu.detail, md = db.marketData, vp = db.vendorPrices[FAKE_ID + 50] }
            for k = 0, 150 do A.vendorChecked[FAKE_ID + k] = true end   -- HP1: Händlerpreis vom Spiel bestätigt (Test)
            local res = { pcall(function()
                db.marketData, Bu.detail = {}, nil
                db.vendorPrices[FAKE_ID + 50] = 1000
                Bu.results, Bu.resultsTime = { { itemID = FAKE_ID + 50, price = 600, qty = 40 } }, time()
                local r = A:VendorFlipOffers(0, 10)
                return r[1] and r[1].qty, r[1] and r[1].profit
            end) }
            Bu.results, Bu.resultsTime, Bu.detail, db.marketData, db.vendorPrices[FAKE_ID + 50] = saved.res, saved.rt, saved.det, saved.md, saved.vp
            for k = 0, 150 do A.vendorChecked[FAKE_ID + k] = nil end
            if not res[1] then error(res[2], 0) end
            return res[2] == 1 and res[3] == 400, string.format("Menge %s, Gewinn %s", tostring(res[2]), tostring(res[3])), "1 Stück, 400"
        end)
        end)
        B(function()
        Chk("T246", "J", "Verkaufen: Preis über dem 100-fachen des Marktwerts -> Rückfrage (Tippfehler)", function()
            local Se = A.Seller
            if not (Se and Se.PriceTooHigh) then return "SKIP", "PriceTooHigh fehlt" end
            local saved = A.GetMarketValue
            A.GetMarketValue = function(self, id) if id == FAKE_ID then return 100 end return nil end
            local a = Se:PriceTooHigh(FAKE_ID, 780000)     -- 78g statt 78c
            local b = Se:PriceTooHigh(FAKE_ID, 5000)       -- 50x: in Ordnung
            local c = Se:PriceTooHigh(FAKE_ID + 1, 780000) -- ohne Marktwert: keine Rückfrage
            A.GetMarketValue = saved
            return a ~= nil and b == nil and c == nil, string.format("%s / %s / %s", tostring(a), tostring(b), tostring(c)), "7800 / nil / nil"
        end)
        end)
        B(function()
        Chk("T247", "J", "Buchhaltung-Reparatur fixL1 (T-M1 bis T-M6): alte Forever-Verkäufe cut/refund = 0 mit Sicherung, Rest unverändert, nur einmal", function()
            local Le = A.Ledger
            local db = A.db.ledger
            local saved = { entries = db.entries, fix = db.fixL1, force = A.forceForever, pr = A.Print, fire = A.Fire }
            local msgs = 0
            local res = { pcall(function()
                local now = time()
                local function fresh()
                    return {
                        { kind = "sale", t = now, itemID = FAKE_ID, qty = 1, amount = 398, cut = 20, refund = 100, src = "mail" },              -- M1
                        { kind = "sale", t = now, itemID = FAKE_ID, qty = 1, amount = 398, cut = 0, refund = 0, src = "mail", inv = { price = 398 } }, -- M2
                        { kind = "deposit", t = now, itemID = FAKE_ID, qty = 1, amount = 100, src = "post" },                                    -- M6
                        { kind = "buy", t = now, itemID = FAKE_ID, qty = 1, amount = 250, src = "mail" },
                        { kind = "refund", t = now, itemID = FAKE_ID, qty = 1, amount = 40, src = "cancel" },
                    }
                end
                A.Print = function() msgs = msgs + 1 end
                A.Fire = function() end
                -- T-M3: Era -> nichts
                db.entries, db.fixL1, A.forceForever = fresh(), nil, false
                local era = Le:FixL1()
                local eraUnchanged = db.entries[1].cut == 20 and db.entries[1].refund == 100 and db.fixL1 == nil
                -- T-M1, M2, M6: Forever
                db.entries, db.fixL1, A.forceForever = fresh(), nil, true
                local n1 = Le:FixL1()
                local e1, e2 = db.entries[1], db.entries[2]
                local m1 = e1.cut == 0 and e1.refund == 0 and e1.old and e1.old.cut == 20 and e1.old.refund == 100 and e1.amount == 398
                local m2 = e2.old == nil and e2.cut == 0
                local m6 = db.entries[3].amount == 100 and db.entries[4].amount == 250 and db.entries[5].amount == 40 and db.entries[3].old == nil
                -- T-M4: zweiter Lauf -> nichts, keine Meldung
                local msgs1 = msgs
                local n2 = Le:FixL1()
                -- T-M5: Einnahmen = Summe amount
                local sum = Le:Summary("all")
                return tostring(era), eraUnchanged, n1, m1, m2, m6, tostring(n2), msgs1, msgs, sum.income
            end) }
            db.entries, db.fixL1, A.forceForever, A.Print, A.Fire = saved.entries, saved.fix, saved.force, saved.pr, saved.fire
            if not res[1] then error(res[2], 0) end
            local era, eraOK, n1, m1, m2, m6, n2, msgs1, msgsAll, income = res[2], res[3], res[4], res[5], res[6], res[7], res[8], res[9], res[10], res[11]
            local ok = era == "nil" and eraOK and n1 == 1 and m1 and m2 and m6 and n2 == "nil" and msgs1 == 1 and msgsAll == 1 and income == 796
            return ok and true or false, string.format("Era %s/%s, korrigiert %s, M1 %s, M2 %s, M6 %s, 2. Lauf %s, Meldungen %d, Einnahmen %s",
                era, tostring(eraOK), tostring(n1), tostring(m1), tostring(m2), tostring(m6), n2, msgsAll, tostring(income)),
                "Era nichts, 1 korrigiert, M1/M2/M6 ok, 2. Lauf nichts, 1 Meldung, Einnahmen 796"
        end)
        end)
        B(function()
        Chk("T248", "J", "Entzauber-Urteil (T-E1 bis T-E7): rot/grün/grau, Lohnt bis abwärts, Wege mit Betrag (besserer zuerst), eigene Items nur die Wege", function()
            local TT, D = A.Tooltip, A.Disenchant
            if not (TT and TT.DisenchantVerdict) then return "SKIP", "DisenchantVerdict fehlt" end
            local saved = { dv = D.DealValue, mu = TT.MatsUnsure, ctx = TT.buyContext, roi = A.db.settings.deBuyRoi, ov = A.apiOverride,
                rv = A.RealValue, mats = TT.DisenchantMats, lines = TT.DisenchantLines, short = TT.DisenchantShort, bag = TT.bagTooltip }
            local res = { pcall(function()
                local complete, net, sell = true, 935, 899
                D.DealValue = function(self, id) if id == FAKE_ID then return net, net, complete, "estimate", 0 end return saved.dv(self, id) end
                A.RealValue = function(self, id, q) if id == FAKE_ID then return sell end return saved.rv(self, id, q) end
                TT.MatsUnsure = function() return false end
                A.db.settings.deBuyRoi = 20
                TT.buyContext = { itemID = FAKE_ID, price = 1000 }
                local e1 = TT:DisenchantVerdict(FAKE_ID)
                TT.buyContext = { itemID = FAKE_ID, price = 650 }
                local e2 = TT:DisenchantVerdict(FAKE_ID)
                complete = false
                local e3 = TT:DisenchantVerdict(FAKE_ID)
                complete = true
                TT.DisenchantMats = function() return { { id = 10940, chance = 1, price = 100, avg = 2, name = "Staub" } } end
                TT.DisenchantLines = function() return { { "Entzaubern geschätzt (Tabelle)", "~9s 35c" } } end
                TT.DisenchantShort = function() return { left = "Entzauberungswert", right = "~9s 35c" } end
                local o = setmetatable({ IsShiftKeyDown = function() return false end }, { __index = saved.ov })
                A.apiOverride = o
                -- T-E7: AH-Item 10s, net 9s 35c, Verkauf 8s 99c -> 4 Zeilen
                TT.buyContext = { itemID = FAKE_ID, price = 1000 }
                local t7 = FakeTT(); TT:AddDisenchantLines(t7, FAKE_ID, "short")
                o.IsShiftKeyDown = function() return true end
                local tShift = FakeTT(); TT:AddDisenchantLines(tShift, FAKE_ID, "mats")
                o.IsShiftKeyDown = function() return false end
                -- T-E5 / T-E6: eigenes Item in den Taschen (nur die Wege)
                TT.buyContext = nil
                TT.bagTooltip = true
                net, sell = 121, 99
                local t5 = FakeTT(); TT:AddDisenchantLines(t5, FAKE_ID, "short")
                net, sell = 121, 150
                local t6 = FakeTT(); TT:AddDisenchantLines(t6, FAKE_ID, "short")
                TT.bagTooltip = saved.bag
                return e1.state, e1.gain, e1.limit, e2.state, e2.gain, e3.state, t7.lines, #tShift.lines, t5.lines, t6.lines
            end) }
            D.DealValue, TT.MatsUnsure, TT.buyContext, A.db.settings.deBuyRoi, A.apiOverride = saved.dv, saved.mu, saved.ctx, saved.roi, saved.ov
            TT.DisenchantMats, TT.DisenchantLines, TT.DisenchantShort, A.RealValue, TT.bagTooltip = saved.mats, saved.lines, saved.short, saved.rv, saved.bag
            if not res[1] then error(res[2], 0) end
            local t7, nShift, t5, t6 = res[8], res[9], res[10], res[11]
            local function has(lines, k, txt) return lines[k] and lines[k]:find(txt, 1, true) ~= nil end
            local ok7 = #t7 == 4 and has(t7, 1, L["Entzaubern lohnt nicht"]) and has(t7, 2, L["Lohnt bis"]) and has(t7, 3, L["Entzaubern:"])
                and has(t7, 3, A:FormatMoney(935)) and has(t7, 4, L["Verkaufen:"]) and has(t7, 4, A:FormatMoney(899))
            -- LB1 (0.65.95): in den Taschen zuerst "Lohnt bis", dann die zwei Wege
            local ok5 = #t5 == 3 and has(t5, 1, L["Lohnt bis"]) and has(t5, 2, L["Entzaubern:"]) and has(t5, 2, A:FormatMoney(121)) and has(t5, 3, L["Verkaufen:"]) and has(t5, 3, A:FormatMoney(99))
            local ok6 = #t6 == 3 and has(t6, 1, L["Lohnt bis"]) and has(t6, 2, L["Verkaufen bringt mehr:"]) and has(t6, 2, A:FormatMoney(150)) and has(t6, 3, L["Entzaubern:"])
            local got = string.format("%s %s %s / %s %s / %s / E7 %d Zeilen %s / Shift %d / E5 %s / E6 %s", tostring(res[2]), tostring(res[3]),
                tostring(res[4]), tostring(res[5]), tostring(res[6]), tostring(res[7]), #t7, tostring(ok7), nShift, tostring(ok5), tostring(ok6))
            local ok = res[2] == "bad" and res[3] == -65 and res[4] == A.Core:LimitFromNet(935, 0) and res[5] == "good" and res[6] == 285 and res[7] == "unsure"
                and ok7 and nShift > 4 and ok5 and ok6
            return ok, got, "bad -65 " .. tostring(A.Core:LimitFromNet(935, 0)) .. " (RK2-A) / good 285 / unsure / E7 4 Zeilen / Shift mehr / E5, E6 je 3 Zeilen (Lohnt bis + Wege, besserer zuerst)"
        end)
        end)
        -- LB1–LB4 (anweisung-lohnt-bis-ueberall) und MP2 (befund-materialpreise-alt): nur eigene Funktionen ersetzt
        local function WithLB(cfg, fn)
            local TT, D = A.Tooltip, A.Disenchant
            local saved = { dv = D.DealValue, mu = TT.MatsUnsure, ctx = TT.buyContext, rv = A.RealValue, bag = TT.bagTooltip, sm = D.StaleMain,
                de = A.db.settings.tooltipDE, mats = TT.DisenchantMats, lines = TT.DisenchantLines, short = TT.DisenchantShort, ov = A.apiOverride, prof = TT.HasEnchanting }
            D.DealValue = function(self, id) if id == FAKE_ID then return 935, 935, true, "estimate", 0 end return saved.dv(self, id) end
            A.RealValue = function(self, id, q) if id == FAKE_ID then return 899 end return saved.rv(self, id, q) end
            TT.MatsUnsure = function() return false end
            D.StaleMain = function(self, id) if id == FAKE_ID then return cfg.stale or false, 10940, cfg.stale and 25 or 1 end return saved.sm(self, id) end
            TT.DisenchantMats = function() return { { id = 10940, chance = 1, price = 100, avg = 2, name = "Staub" } } end
            TT.DisenchantLines = function() return { { "Entzaubern geschätzt (Tabelle)", "~9s 35c" } } end
            TT.DisenchantShort = function() return { left = "Entzauberungswert", right = "~9s 35c" } end
            A.apiOverride = setmetatable({ IsShiftKeyDown = function() return false end }, { __index = saved.ov })
            TT.buyContext = nil
            TT.bagTooltip = cfg.bag
            local res = { pcall(fn, TT, D) }
            D.DealValue, A.RealValue, TT.MatsUnsure, D.StaleMain, TT.buyContext, TT.bagTooltip = saved.dv, saved.rv, saved.mu, saved.sm, saved.ctx, saved.bag
            TT.DisenchantMats, TT.DisenchantLines, TT.DisenchantShort, A.apiOverride = saved.mats, saved.lines, saved.short, saved.ov
            A.db.settings.tooltipDE = saved.de
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        local function HasLine(lines, txt) for _, l in ipairs(lines) do if l:find(txt, 1, true) then return l end end return nil end
        B(function()
        Chk("T467", "J", "T-LB1 Taschen-Tooltip eines entzauberbaren Items -> \"Lohnt bis\" mit Betrag (über den zwei Wegen)", function()
            return WithLB({ bag = true }, function(TT)
                local t = FakeTT(); TT:AddDisenchantLines(t, FAKE_ID, "short")
                local l = HasLine(t.lines, L["Lohnt bis"])
                local ok = l ~= nil and t.lines[1] == l and l:find(A:FormatMoney(A.Core:LimitFromNet(935, 0)), 1, true) ~= nil
                return ok, tostring(l), "Lohnt bis || " .. A:FormatMoney(A.Core:LimitFromNet(935, 0)) .. " (RK2-A, erste Zeile)"
            end)
        end)
        Chk("T468", "J", "T-LB2 ohne Verzauberkunst (Kurz-Modus, fremdes Fenster) -> \"Lohnt bis\" vorhanden", function()
            return WithLB({ bag = false }, function(TT)
                -- der Entzauber-Teil ist nicht an den Beruf gebunden: TT:AddDisenchantLines fragt keinen Beruf ab
                local t = FakeTT(); TT:AddDisenchantLines(t, FAKE_ID, "short")
                local l = HasLine(t.lines, L["Lohnt bis"])
                return l ~= nil, tostring(l), "Lohnt bis || Betrag"
            end)
        end)
        Chk("T469", "J", "T-LB3/T-MP2 Hauptmaterial 25 Std. alt -> \"Lohnt bis: Preise veraltet – erst scannen\" (kein Betrag), Urteil unsicher", function()
            return WithLB({ bag = true, stale = true }, function(TT)
                local t = FakeTT(); TT:AddDisenchantLines(t, FAKE_ID, "short")
                local l = HasLine(t.lines, L["Lohnt bis"]) or ""
                TT.buyContext = { itemID = FAKE_ID, price = 500 }
                local v = TT:DisenchantVerdict(FAKE_ID)
                local ok = l:find(L["Preise veraltet – erst scannen"], 1, true) ~= nil and not l:find(A:FormatMoney(A.Core:LimitFromNet(935, 0)), 1, true) and v.state == "unsure"
                return ok, string.format("\"%s\" · Urteil %s", l, tostring(v.state)), "ohne Betrag · unsicher"
            end)
        end)
        Chk("T470", "J", "T-LB4 Option \"Entzaub.: aus\" -> nichts vom Entzauber-Teil im Tooltip", function()
            return WithLB({ bag = true }, function(TT)
                local D = A.Disenchant
                local sp, sla, sld = D.Prior, A.LogAbsatz, TT.LogDEValue
                D.Prior = function(self, id) if id == FAKE_ID then return true end return sp(self, id) end
                A.LogAbsatz = function() end
                TT.LogDEValue = function() end
                local ok, res = pcall(function()
                    A.db.settings.tooltipDE = true
                    local t1 = FakeTT(); TT:AddBlock2(t1, FAKE_ID, false)
                    A.db.settings.tooltipDE = false
                    local t2 = FakeTT(); TT:AddBlock2(t2, FAKE_ID, false)
                    local on = HasLine(t1.lines, L["Lohnt bis"]) ~= nil
                    local off = HasLine(t2.lines, L["Lohnt bis"]) or HasLine(t2.lines, L["Entzaubern:"])
                    return { on and not off, string.format("an: Lohnt bis=%s · aus: %s", tostring(on), tostring(off or "nichts vom Entzauber-Teil")) }
                end)
                D.Prior, A.LogAbsatz, TT.LogDEValue = sp, sla, sld
                if not ok then error(res, 0) end
                return res[1], res[2], "an: Lohnt bis=true · aus: nichts vom Entzauber-Teil"
            end)
        end)
        end)
        B(function()
        Chk("T249", "J", "Bester Weg im Gewinn-Fenster (T-W1 bis T-W5): Ballen aus Leinenstoff, Entzaubern vs. Verkaufen, Einkaufsliste", function()
            local Cr = A.Crafting
            if not (Cr and Cr.BestUnit and Cr.API) then return "SKIP", "BestUnit fehlt" end
            local CLOTH, BOLT, PANTS = 2589, 2996, FAKE_ID + 10
            local saved = { idx = Cr.testRecipeIndex, up = Cr.UnitPrice, rv = A.RealValue, dev = Cr.DisenchantValue, lists = A.Lists, api = Cr.API.ahstest }
            local added = {}
            local res = { pcall(function()
                local prices = { [CLOTH] = 8, [BOLT] = 25, [PANTS] = 199 }
                Cr.UnitPrice = function(self, id) return prices[id], false end
                Cr.testRecipeIndex = { [BOLT] = { made = 1, reagents = { { CLOTH, 2 } }, name = "Leinenstoffballen" } }
                local w1, how1 = Cr:BestUnit(BOLT, 0)
                Cr.testRecipeIndex = {}
                local w2, how2 = Cr:BestUnit(BOLT, 0)
                Cr.testRecipeIndex = { [BOLT] = { made = 1, reagents = { { CLOTH, 2 } }, name = "Leinenstoffballen" } }
                -- Rezept "Hose": 1 Ballen; Verkaufen netto 99 (1s Gebühr), Entzaubern 121
                Cr.API.ahstest = {
                    num = function() return 1 end, info = function() return "Testhose", "easy" end,
                    link = function() return "item:" .. PANTS end, made = function() return 1, 1 end,
                    numReagents = function() return 1 end,
                    reagent = function() return "Leinenstoffballen", 1, 0, "item:" .. BOLT end,
                    selected = function() return 1 end, title = function() return "AHS-Test" end,
                }
                A.RealValue = function(self, id, qty) if id == PANTS then return 99 * (qty or 1) end return saved.rv(self, id, qty) end
                Cr.DisenchantValue = function(self, id, made) if id == PANTS then return 121 end return nil end
                local r3 = Cr:ReadRecipe("ahstest", 1)
                Cr.DisenchantValue = function() return nil end
                local r4 = Cr:ReadRecipe("ahstest", 1)
                A.Lists = { Exists = function() return true end, Create = function() end,
                    AddItem = function(_, _, id, q) added[#added + 1] = id .. "x" .. q end }
                Cr:ReagentsToList("ahstest", 1, 1)
                return w1, how1, w2, how2, r3.best, r3.profit, r3.sellProfit, r3.reagents[1].via, Cr:OriginText(r3) ~= "", r4.best, r4.deProfit
            end) }
            Cr.testRecipeIndex, Cr.UnitPrice, A.RealValue, Cr.DisenchantValue, A.Lists, Cr.API.ahstest = saved.idx, saved.up, saved.rv, saved.dev, saved.lists, saved.api
            if not res[1] then error(res[2], 0) end
            local got = string.format("W1 %s %s · W2 %s %s · W3 %s %s (verkaufen %s, via %s, Herkunft %s) · W4 %s %s · W5 %s",
                tostring(res[2]), tostring(res[3]), tostring(res[4]), tostring(res[5]), tostring(res[6]), tostring(res[7]), tostring(res[8]),
                tostring(res[9]), tostring(res[10]), tostring(res[11]), tostring(res[12]), table.concat(added, ","))
            local ok = res[2] == 16 and res[3] == "craft" and res[4] == 25 and res[5] == "ah" and res[6] == "de" and res[7] == 105
                and res[8] == 83 and res[9] == "craft" and res[10] and res[11] == "sell" and res[12] == nil and table.concat(added, ",") == CLOTH .. "x2"
            return ok and true or false, got, "W1 16 craft · W2 25 ah · W3 de 105 (verkaufen 83) · W4 sell, keine Entzauber-Zeile · W5 Leinenstoff x2"
        end)
        end)
        B(function()
        Chk("T250", "J", "Rechnung und Buchhaltung klassisch (T-R1, T-R2, T-M7 bis T-M9): Feld 'Preis' = Menge, Gesamt aus Post-Gold, fixL2 einmal", function()
            local Le = A.Ledger
            local db = A.db.ledger
            local I = A.Inbox
            local saved = { entries = db.entries, seen = db.seen, f1 = db.fixL1, f2 = db.fixL2, force = A.forceForever, pr = A.Print, fire = A.Fire,
                av = I.Available, n = I.GetInboxNumItems, h = I.GetInboxHeaderInfo, inv = I.GetInboxInvoiceInfo, raw = Le.rawLogged }
            local res = { pcall(function()
                A.Print, A.Fire = function() end, function() end
                local mail = { money = 3878, price = 47, cons = 202, dep = 38, count = 0, bid = 4042 }   -- Feldlage RECHNUNG-ROH: Feld 4 = Gesamt
                I.Available = function() return true end
                I.GetInboxNumItems = function() return 1 end
                I.GetInboxHeaderInfo = function() return nil, nil, "AH", "Verkauft", mail.money, 0, 29 end
                I.GetInboxInvoiceInfo = function() return "seller", "AHS-Testitem", nil, mail.bid or mail.price, mail.price, mail.dep, mail.cons, nil, nil, mail.count end
                Le.rawLogged = true
                -- T-R1 Forever
                db.entries, db.seen, A.forceForever = {}, {}, true
                Le:ScanInbox()
                local r1 = db.entries[1] or {}
                -- T-R2 Era: Rechnung mit Gesamtpreis und Menge unverändert
                db.entries, db.seen, A.forceForever = {}, {}, false
                mail.price, mail.count, mail.bid = 4042, 86, nil
                Le:ScanInbox()
                local r2 = db.entries[1] or {}
                -- T-M7 / T-M8 / T-M9: fixL2
                db.entries, db.fixL2, A.forceForever = {
                    { kind = "sale", t = time(), qty = 0, amount = 47, cut = 0, refund = 0, src = "mail", old = { cut = 202, refund = 38 } },
                    { kind = "sale", t = time(), qty = 0, amount = 3878, cut = 0, refund = 0, src = "mail", inv = { price = 47, cut = 202, deposit = 38, money = 3878 } },
                    { kind = "deposit", t = time(), qty = 86, amount = 100, src = "post" },
                }, nil, true
                local n1 = Le:FixL2(true)
                local m7, m8 = db.entries[1], db.entries[2]
                local n2 = Le:FixL2(true)
                local sum = Le:Summary("all")
                return r1.amount, r1.cut, r1.refund, r1.qty, r2.amount, r2.qty, r2.cut, m7.amount, m7.approx, m7.cut, m7.refund, m7.qty,
                    m8.amount, m8.qty, n1, tostring(n2), sum.income, db.entries[3].amount
            end) }
            db.entries, db.seen, db.fixL1, db.fixL2, A.forceForever, A.Print, A.Fire = saved.entries, saved.seen, saved.f1, saved.f2, saved.force, saved.pr, saved.fire
            I.Available, I.GetInboxNumItems, I.GetInboxHeaderInfo, I.GetInboxInvoiceInfo, Le.rawLogged = saved.av, saved.n, saved.h, saved.inv, saved.raw
            if not res[1] then error(res[2], 0) end
            local v = {}
            for k = 2, #res do v[#v + 1] = tostring(res[k]) end
            local got = table.concat(v, "/")
            -- Korrektur 15:40: Feld "Preis" = MENGE -> T-R1 qty 47; fixL2-Werte (T-M7/T-M8) wie damals berechnet
            local want = "4042/202/38/47/4042/86/202/4040/true/202/38/86/4042/86/2/nil/7678/100"
            return got == want, got, want
        end)
        end)
        B(function()
        Chk("T251", "J", "Laufzeit und Verkaufsdauer (T-L1, T-L2, T-V1, T-V2): Vorbelegung mit Grund, schnell/kaum", function()
            local Le, X = A.Ledger, A.Extras
            local db = A.db.ledger
            local saved = { force = A.forceForever, vp = A.GetVendorPrice, ss = Le.SellSpeed, entries = db.entries, cache = Le.speedCache,
                open = A.IsAHOpen, rp = A.RealPrice, min = A.db.minDeposit }
            local res = { pcall(function()
                A.forceForever = true
                A.db.minDeposit = 100                                          -- T-L1 gilt mit 1s-Minimum
                A.IsAHOpen = function() return false end
                -- T-L1: Seltsamer Staub (Händler 1c): 24 Std. kostet gleich viel wie 2 Std.
                A.GetVendorPrice = function() return 1 end
                local h1, why1 = A:DefaultDuration(FAKE_ID, 20)
                -- T-L2: teure Einzahlung, verkauft sich meist in 1 Std. -> 2 Std.
                A.GetVendorPrice = function() return 5000 end
                Le.SellSpeed = function() return { speed = "schnell", hours = 1 } end
                local h2, why2 = A:DefaultDuration(FAKE_ID, 1)
                Le.SellSpeed = saved.ss
                -- T-V1: 3 Einstellungen, Verkäufe nach 2/3/4 Std. (Buchung aus der Post: 1 Std. nach dem Verkauf)
                local now = time()
                local t0 = now - 20 * 3600
                db.entries = {}
                for k, d in ipairs({ 2, 3, 4 }) do
                    db.entries[#db.entries + 1] = { kind = "deposit", src = "post", itemID = FAKE_ID, t = t0 + k, qty = 1, amount = 100, hours = 24 }
                    db.entries[#db.entries + 1] = { kind = "sale", src = "mail", itemID = FAKE_ID, t = t0 + k + d * 3600 + 3600, qty = 1, amount = 1000 }
                end
                local v1 = Le:SellSpeed(FAKE_ID, now)
                -- T-V2: 5 Einstellungen, abgelaufen, nie verkauft -> kaum
                db.entries = {}
                for k = 1, 5 do db.entries[#db.entries + 1] = { kind = "deposit", src = "post", itemID = FAKE_ID + 1, t = now - 3 * 86400 + k, qty = 1, amount = 100, hours = 24 } end
                local v2 = Le:SellSpeed(FAKE_ID + 1, now)
                Le.speedCache = {}
                local txt = Le:SellSpeedText(FAKE_ID + 1)
                return h1, why1, h2, v1 and v1.speed, v1 and math.floor(v1.hours + 0.5), v2 and v2.speed, txt
            end) }
            A.forceForever, A.GetVendorPrice, Le.SellSpeed, db.entries, Le.speedCache = saved.force, saved.vp, saved.ss, saved.entries, {}
            A.IsAHOpen, A.RealPrice, A.db.minDeposit = saved.open, saved.rp, saved.min
            if not res[1] then error(res[2], 0) end
            local got = string.format("%s %s / %s / %s ~%s / %s (%s)", tostring(res[2]), tostring(res[3]), tostring(res[4]), tostring(res[5]),
                tostring(res[6]), tostring(res[7]), tostring(res[8]))
            -- D2/D3 (Wunsch 07:25): Standard-Laufzeit (Stufe 1 = 2 Std.), "24 Std. kostet gleich viel" nur als Hinweis
            local ok = res[2] == 2 and res[3] == L["24 Std. kostet gleich viel"] and res[4] == 2 and res[5] == "schnell" and res[6] == 3
                and res[7] == "kaum" and res[8] == L["kaum (läuft oft ab)"]
            return ok, got, "2 (Hinweis: gleich viel) / 2 / schnell ~3 / kaum"
        end)
        end)
        B(function()
        Chk("T252", "J", "Sniper-Meldungen (T-S1, T-S3): 'Gekauft' erst bei Erfolg, Fehler ohne Korrektur, Hinweis nie im Kampf (T-S2 im Simulator)", function()
            local Sn = A.Sniper
            if not (Sn and Sn.PurchaseSucceeded) then return "SKIP", "PurchaseSucceeded fehlt" end
            local key = "i:" .. FAKE_ID
            -- Sandbox (Befund 22:25, Pfad "ledger.entries"): Erfolg feuert SNIPER_PURCHASE_DONE, die Buchhaltung bucht ->
            -- in eine Ersatzliste
            local saved = { pr = A.Print, sm = Sn.BuyHint, combat = A.InCombat, inflight = Sn.inFlight, lp = Sn.lastPurchase,
                getT = Sn.GetTarget, alert = Sn.buyAlert, pending = Sn.pending, after = Sn.AfterPurchase, entries = A.db.ledger.entries }
            A.db.ledger.entries = {}
            local msgs, screens = {}, 0
            local res = { pcall(function()
                A.Print = function(_, m) msgs[#msgs + 1] = A:PlainText(tostring(m)) end
                Sn.BuyHint = function() screens = screens + 1 end          -- G2: eigener Hinweis statt ScreenMessage
                local t = { key = key, bought = 0, spent = 0 }
                Sn.GetTarget = function(self, k) if k == key then return t end return saved.getT(self, k) end
                Sn.AfterPurchase = function() end
                -- Erfolg
                Sn.inFlight = { key = key, itemID = FAKE_ID, qty = 21, cost = 246, time = GetTime() }
                local b0 = t.bought
                Sn:OnEvent("COMMODITY_PURCHASE_SUCCEEDED")
                local b1 = t.bought
                -- Fehler: nichts gezählt, keine Korrektur
                Sn.inFlight = { key = key, itemID = FAKE_ID, qty = 21, cost = 246, time = GetTime() }
                Sn:OnEvent("COMMODITY_PURCHASE_FAILED")
                local b2 = t.bought
                -- Wartezeit (T-S2): eine Chat-Zeile - im Simulator geprüft (s58); hier sperrt die Testroutine jeden Kauf
                Sn.pending = { key = key, itemID = FAKE_ID, qty = 5, state = "waiting", started = GetTime() }
                local m1, m2 = true, nil
                -- Hinweis: im Kampf kein grosser Text
                A.InCombat = function() return true end
                Sn:StartAlert(Sn.pending)
                local inCombatScreens = screens
                A.InCombat = function() return false end
                Sn:StartAlert(Sn.pending)
                return b0, b1, b2, m1 ~= nil, m2 == nil or tostring(m2), inCombatScreens, screens, Sn.buyAlert ~= nil
            end) }
            A.Print, Sn.BuyHint, A.InCombat, Sn.inFlight, Sn.lastPurchase = saved.pr, saved.sm, saved.combat, saved.inflight, saved.lp
            Sn.GetTarget, Sn.buyAlert, Sn.pending, Sn.AfterPurchase = saved.getT, saved.alert, saved.pending, saved.after
            A.db.ledger.entries = saved.entries
            if not res[1] then error(res[2], 0) end
            local text = table.concat(msgs, " | ")
            local okMsgs = text:find(L["Gekauft: "], 1, true) ~= nil and text:find("Zähler korrigiert", 1, true) == nil
            local got = string.format("Zähler %s->%s->%s, Wartemeldung %s/%s, Hinweis Kampf %s, danach %s, aktiv %s, Meldungen ok %s",
                tostring(res[2]), tostring(res[3]), tostring(res[4]), tostring(res[5]), tostring(res[6]), tostring(res[7]), tostring(res[8]), tostring(res[9]), tostring(okMsgs))
            local ok = res[2] == 0 and res[3] == 21 and res[4] == 21 and res[5] and res[6] == true and res[7] == 0 and res[8] == 1 and res[9] and okMsgs
            return ok, got, "0->21->21, 1 Wartemeldung, im Kampf kein Hinweis"
        end)
        end)
        B(function()
        Chk("T253", "J", "Leistung und Sammelkauf (offene Punkte 3, 4): 5000 Buchungen, 200 Aufrufe -> Index 1x gebaut; gescheiterter Kauf zählt nicht", function()
            local Le = A.Ledger
            local db = A.db.ledger
            local saved = { entries = db.entries, ix = Le.itemIndex }
            local res = { pcall(function()
                local list, now = {}, time()
                for k = 1, 5000 do
                    list[k] = { kind = (k % 3 == 0) and "sale" or "deposit", src = (k % 3 == 0) and "mail" or "post", itemID = FAKE_ID + (k % 50),
                        t = now - k * 60, qty = 1, amount = 100 }
                end
                db.entries = list
                Le.itemIndex = nil
                local b0 = Le.indexBuilds
                for k = 1, 200 do Le:AverageSalePrice(FAKE_ID + (k % 50), 14); Le:PostRateRaw(FAKE_ID + (k % 50), 30) end
                return Le.indexBuilds - b0
            end) }
            db.entries, Le.itemIndex = saved.entries, nil
            if not res[1] then error(res[2], 0) end
            local builds = res[2]
            -- Sammelkauf: Kauf scheitert -> Gekauft bleibt 0, keine deBuys-Zeile
            local res2 = { pcall(function()
                return WithDEBuy(function(DEB, fakeB, bought)
                    DEB.Value = function(self, id) return 2000 end
                    fakeB.results = { { itemID = FAKE_ID, itemKey = { itemID = FAKE_ID }, price = 1000, qty = 1, name = "AHS-Test" } }
                    fakeB.offers[FAKE_ID] = { { auctionID = 1, buyout = 1000, qty = 1, itemID = FAKE_ID } }
                    fakeB.failNext = true
                    DEB:Next()                      -- lädt
                    DEB:Next()                      -- kauft -> scheitert
                    return DEB.session.bought, #A.db.deBuys, #bought
                end)
            end) }
            if not res2[1] then error(res2[2], 0) end
            local got = string.format("Index %d, gescheitert: gekauft %s, deBuys %s, gesendet %s", builds, tostring(res2[2]), tostring(res2[3]), tostring(res2[4]))
            return builds == 1 and res2[2] == 0 and res2[3] == 0 and res2[4] == 1, got, "Index 1, gekauft 0, deBuys 0, gesendet 1"
        end)
        end)
        B(function()
        Chk("T254", "J", "Gewinn-Fenster (offener Punkt 2): Zeile AH-Gebühr nur 5 %, Neu-Einstellungen bzw. Händler getrennt, nie negativ", function()
            local Cr = A.Crafting
            local OUT, MAT = FAKE_ID + 60, FAKE_ID + 61
            local saved = { up = Cr.UnitPrice, rv = A.RealValue, api = Cr.API.ahstest, dev = Cr.DisenchantValue, idx = Cr.testRecipeIndex }
            local res = { pcall(function()
                Cr.testRecipeIndex = {}
                Cr.DisenchantValue = function() return nil end
                Cr.UnitPrice = function(self, id) if id == OUT then return 2000 elseif id == MAT then return 1000 end end
                Cr.API.ahstest = { num = function() return 1 end, info = function() return "AHS-Test", "easy" end,
                    link = function() return "item:" .. OUT end, made = function() return 1, 1 end, numReagents = function() return 1 end,
                    reagent = function() return "x", 1, 0, "item:" .. MAT end, selected = function() return 1 end, title = function() return "AHS" end }
                -- Quote 50 %: 5 % = 100, Einzahlungsverlust 100
                A.RealValue = function(self, id) if id == OUT then return 1800, 2000, { listings = 2 }, false end return saved.rv(self, id) end
                local r1 = Cr:ReadRecipe("ahstest", 1)
                -- Händler zahlt mehr
                A.RealValue = function(self, id) if id == OUT then return 2500, 2000, {}, true end return saved.rv(self, id) end
                local r2 = Cr:ReadRecipe("ahstest", 1)
                return r1.fee, r1.relist, r1.profit, r2.fee, r2.vendorWins, r2.profit
            end) }
            Cr.UnitPrice, A.RealValue, Cr.API.ahstest, Cr.DisenchantValue, Cr.testRecipeIndex = saved.up, saved.rv, saved.api, saved.dev, saved.idx
            if not res[1] then error(res[2], 0) end
            local v = {}
            for k = 2, 7 do v[#v + 1] = tostring(res[k]) end
            local got = table.concat(v, "/")
            return got == "100/100/800/100/2500/1500", got, "100/100/800/100/2500/1500 (Gebühr, Neu-Einstellungen, Gewinn / Gebühr, Händler, Gewinn)"
        end)
        end)
        B(function()
        Chk("T255", "J", "Korrektur Menge und Rechenwert (T-R3, T-R4, T-M10, T-P1, T-P3): Feld 'Preis' = Menge, fixL3 einmal, Wert = letzter Scan", function()
            local Le = A.Ledger
            local db = A.db.ledger
            local I = A.Inbox
            local saved = { entries = db.entries, seen = db.seen, f3 = db.fixL3, force = A.forceForever, pr = A.Print, fire = A.Fire,
                av = I.Available, n = I.GetInboxNumItems, h = I.GetInboxHeaderInfo, inv = I.GetInboxInvoiceInfo, raw = Le.rawLogged,
                gmv = A.GetMarketValue, gc = A.GetCurrent, scan = A.db.lastScanTime, asp = Le.AverageSalePrice, nro = A.NextRealOffer }
            local res = { pcall(function()
                A.Print, A.Fire = function() end, function() end
                A.forceForever = true
                Le.rawLogged = true
                local mail
                I.Available = function() return true end
                I.GetInboxNumItems = function() return 1 end
                I.GetInboxHeaderInfo = function() return nil, nil, "AH", "Verkauft", mail.money, 0, 29 end
                I.GetInboxInvoiceInfo = function() return "seller", "AHS-Testitem", nil, mail.money + mail.cons - mail.dep, mail.q, mail.dep, mail.cons, nil, nil, 0 end
                local function one(q, cons, dep, money)
                    mail = { q = q, cons = cons, dep = dep, money = money }
                    db.entries, db.seen = {}, {}
                    Le:ScanInbox()
                    local e = db.entries[1] or {}
                    return string.format("%s/%s/%s", tostring(e.qty), tostring(e.amount), e.qty and math.floor(e.amount / e.qty + 0.5) or "?")
                end
                local r1 = one(47, 202, 38, 3878)
                local r3 = one(184, 837, 200, 16107)
                local r4 = one(69, 313, 296, 6262)
                -- T-M10 fixL3
                db.entries, db.fixL3 = { { kind = "sale", src = "mail", t = time(), qty = 91, amount = 16744,
                    inv = { price = 184, cut = 837, deposit = 200, money = 16107, count = 0 } } }, nil
                local n1 = Le:FixL3(true)
                local q = db.entries[1].qty
                local n2 = Le:FixL3(true)
                -- T-P1 / T-P3 Rechenwert
                local now = time()
                A.db.lastScanTime = now - 60
                local cur, med = 84, 87
                A.GetMarketValue = function(self, id) if id == FAKE_ID then return med end return saved.gmv(self, id) end
                A.GetCurrent = function(self, id) if id == FAKE_ID then return cur, 10, now - 30 end return saved.gc(self, id) end
                Le.AverageSalePrice = function() return 40, 10 end
                local p1 = A:PriceInfo(FAKE_ID)
                cur = 1
                A.NextRealOffer = function() return 84 end
                local p3 = A:PriceInfo(FAKE_ID)
                A.GetCurrent = function(self, id) if id == FAKE_ID then return 70, 10, now - 86400 end return saved.gc(self, id) end
                local p4 = A:PriceInfo(FAKE_ID)
                return r1, r3, r4, n1, q, tostring(n2), p1.value .. " " .. p1.source, p3.value .. " " .. p3.source, p4.value .. " " .. p4.source, p1.sale
            end) }
            db.entries, db.seen, db.fixL3, A.forceForever, A.Print, A.Fire = saved.entries, saved.seen, saved.f3, saved.force, saved.pr, saved.fire
            I.Available, I.GetInboxNumItems, I.GetInboxHeaderInfo, I.GetInboxInvoiceInfo, Le.rawLogged = saved.av, saved.n, saved.h, saved.inv, saved.raw
            A.GetMarketValue, A.GetCurrent, A.db.lastScanTime, Le.AverageSalePrice, A.NextRealOffer = saved.gmv, saved.gc, saved.scan, saved.asp, saved.nro
            if not res[1] then error(res[2], 0) end
            local v = {}
            for k = 2, #res do v[#v + 1] = tostring(res[k]) end
            local got = table.concat(v, " | ")
            local want = "47/4042/86 | 184/16744/91 | 69/6279/91 | 1 | 184 | nil | 84 ah | 84 ah | 87 market | 40"
            return got == want, got, want
        end)
        end)
        B(function()
        Chk("T256", "J", "Mindest-Einzahlung gemessen statt fest (Hinweis 16:05): db.minDeposit, Diag MINDESTEINZAHLUNG, Vorbelegung", function()
            local Se = A.Seller
            local saved = { force = A.forceForever, vp = A.GetVendorPrice, open = A.IsAHOpen, min = A.db.minDeposit, ss = A.Ledger.SellSpeed }
            local res = { pcall(function()
                A.forceForever = true
                A.IsAHOpen = function() return false end
                A.GetVendorPrice = function() return 1 end
                A.Ledger.SellSpeed = function() return nil end
                A.db.minDeposit = nil
                local a = A:ListingDeposit(FAKE_ID, 20, 24, 1)                -- Startwert 1s
                A.GetVendorPrice = function() return 10 end                    -- 1 Stück je Auktion: 2 Std. 0c, 24 Std. 6c
                local h1, w1 = A:DefaultDuration(FAKE_ID, 1)
                A.GetVendorPrice = function() return 1 end
                -- Einstellen: Formel 12c, abgezogen 12c -> Minimum 1c
                Se:MeasureMinDeposit({ itemID = FAKE_ID, qty = 20, auctions = 1, duration = 3 }, 12)
                local m1 = A:MinDeposit()
                local e = A.Diag and A.Diag.Store and A.Diag.Store().entries[1]
                local diag = e and e.k == "MINDESTEINZAHLUNG" and e.t:find("gemessen=12", 1, true) ~= nil
                local b = A:ListingDeposit(FAKE_ID, 20, 24, 1)                -- 12c
                A.GetVendorPrice = function() return 10 end
                local h2, w2 = A:DefaultDuration(FAKE_ID, 1)
                A.GetVendorPrice = function() return 1 end
                -- Formel über 1s: misst nichts
                Se:MeasureMinDeposit({ itemID = FAKE_ID, qty = 2000, auctions = 1, duration = 3 }, 1200)
                local m2 = A:MinDeposit()
                -- abgezogen 1s bei Formel 12c -> Minimum wieder 1s
                Se:MeasureMinDeposit({ itemID = FAKE_ID, qty = 20, auctions = 1, duration = 3 }, 100)
                return a, w1 == L["24 Std. kostet gleich viel"], m1, diag, b, w2 ~= L["24 Std. kostet gleich viel"], m2, A:MinDeposit()
            end) }
            A.forceForever, A.GetVendorPrice, A.IsAHOpen, A.db.minDeposit, A.Ledger.SellSpeed = saved.force, saved.vp, saved.open, saved.min, saved.ss
            if not res[1] then error(res[2], 0) end
            local got = string.format("%s/%s/%s/%s/%s/%s/%s/%s", tostring(res[2]), tostring(res[3]), tostring(res[4]), tostring(res[5]),
                tostring(res[6]), tostring(res[7]), tostring(res[8]), tostring(res[9]))
            local want = "100/true/1/true/12/true/1/100"
            return got == want, got, want
        end)
        end)
        B(function()
        Chk("T257", "J", "H1 Abbrechen nur, wenn es sich lohnt (T-H1a 1c unterboten / Einzahlung 1s -> liegen lassen, T-H1b 40 % billiger / 1c -> abbrechen)", function()
            local Se = A.Seller
            local saved = { el = A.ExpectedListings, owned = Se.owned, pr = Se.prices[FAKE_ID], mk = A.marketKey }
            local res = { pcall(function()
                A.ExpectedListings = function() return 1 end
                A.marketKey = nil
                local oa = { auctionID = 9001, itemID = FAKE_ID, name = "Test", qty = 1, unitPrice = 1000, deposit = 100 }
                local wa = Se:CancelWorth(oa, 999)
                local ob = { auctionID = 9002, itemID = FAKE_ID, name = "Test", qty = 1, unitPrice = 1000, deposit = 1 }
                local wb, cb = Se:CancelWorth(ob, 600)
                Se.owned = { oa }
                Se.prices[FAKE_ID] = { lowestOther = 999 }
                Se:UpdateOwnedStatus()
                local sa = oa.status
                local okNext = Se:CancelNextUndercut()
                return wa, wb, cb and cb.gain > cb.cost, sa, okNext
            end) }
            A.ExpectedListings, Se.owned, Se.prices[FAKE_ID], A.marketKey = saved.el, saved.owned, saved.pr, saved.mk
            if not res[1] then error(res[2], 0) end
            local got = string.format("%s/%s/%s/%s/%s", tostring(res[2]), tostring(res[3]), tostring(res[4]), tostring(res[5]), tostring(res[6]))
            local want = "false/true/true/liegen/false"
            return got == want, got, want
        end)
        end)
        B(function()
        Chk("T258", "J", "H2 höchstens 90 Suchen je Minute, Sniper zuerst (T-H2: 120 Anfragen in 30 s)", function()
            local pace = A.pace
            local saved = { force = A.forceForever, clock = A.QueryClock, ready = A.QueryReady, win = pace.window, last = pace.last, gap = pace.gap,
                noted = pace.limitNoted, logged = pace.limitLogged }
            local res = { pcall(function()
                A.forceForever = true
                local now = 0
                A.QueryClock = function() return now end
                A.QueryReady = function() return true end
                pace.window, pace.last, pace.gap, pace.limitNoted = {}, -100, 0, nil
                local sn, wa = 0, 0
                for i = 1, 120 do
                    now = i * 0.25
                    pace.last = -100
                    local prio = (i % 2 == 1) and "sniper" or nil
                    if A:CanQueryNow(prio) then
                        A:NoteQuery()
                        if prio then sn = sn + 1 else wa = wa + 1 end
                    end
                end
                return sn + wa, sn, wa
            end) }
            A.forceForever, A.QueryClock, A.QueryReady = saved.force, saved.clock, saved.ready
            pace.window, pace.last, pace.gap, pace.limitNoted, pace.limitLogged = saved.win, saved.last, saved.gap, saved.noted, saved.logged
            if not res[1] then error(res[2], 0) end
            local got = string.format("gesamt %d, Sniper %d, andere %d", res[2], res[3], res[4])
            return res[2] == 90 and res[4] <= 80 and res[3] >= 50, got, "gesamt 90, andere <= 80, Sniper >= 50"
        end)
        end)
        B(function()
        Chk("T259", "J", "H3 neutrales AH 15 % (T-H3): A:CutPct, Verkaufsgebühr, Erlös, Formel-Einzahlung 'unsicher'", function()
            local Se = A.Seller
            local saved = { mk = A.marketKey, force = A.forceForever, vp = A.GetVendorPrice, open = A.IsAHOpen }
            local res = { pcall(function()
                A.forceForever = true
                A.IsAHOpen = function() return false end
                A.GetVendorPrice = function() return 100 end
                A.marketKey = "Testwelt|Neutral"
                local c1, f1 = A:CutPct(), A:SaleFee(nil, 4042, 1)
                local _, cut1 = Se:Proceeds(1000, 1, FAKE_ID, 1)
                local _, uns1 = Se:Deposit(FAKE_ID, 3, 1, false, nil, 1)
                A.marketKey = "Testwelt|Horde"
                local c2, f2 = A:CutPct(), A:SaleFee(nil, 4042, 1)
                local _, uns2 = Se:Deposit(FAKE_ID, 3, 1, false, nil, 1)
                return c1, f1, cut1, uns1, c2, f2, uns2
            end) }
            A.marketKey, A.forceForever, A.GetVendorPrice, A.IsAHOpen = saved.mk, saved.force, saved.vp, saved.open
            if not res[1] then error(res[2], 0) end
            local got = string.format("%s/%s/%s/%s/%s/%s/%s", tostring(res[2]), tostring(res[3]), tostring(res[4]), tostring(res[5]),
                tostring(res[6]), tostring(res[7]), tostring(res[8]))
            local want = "0.15/606/150/true/0.05/202/false"
            return got == want, got, want
        end)
        end)
        B(function()
        Chk("T260", "J", "H4 Sniper-Kaufgrenze über dem Netto-Verkaufswert -> Hinweis mit Verlust je Stück (T-H4)", function()
            local Sn = A.Sniper
            local saved = { rp = A.RealPrice, force = A.forceForever, mk = A.marketKey }
            local res = { pcall(function()
                A.forceForever = false
                A.marketKey = nil
                A.RealPrice = function() return 1000 end
                return Sn:MaxOverValue({ itemID = FAKE_ID, maxPrice = 1000 }), Sn:MaxOverValue({ itemID = FAKE_ID, maxPrice = 900 })
            end) }
            A.RealPrice, A.forceForever, A.marketKey = saved.rp, saved.force, saved.mk
            if not res[1] then error(res[2], 0) end
            local got = tostring(res[2]) .. "/" .. tostring(res[3])
            return got == "50/nil", got, "50/nil"
        end)
        end)
        B(function()
        Chk("T261", "J", "H5 automatischer Mindestpreis (T-H5a Händler, T-H5b Herstellkosten/Einkauf, T-H5c Hand-Mindestpreis)", function()
            local Se, Le, Cr = A.Seller, A.Ledger, A.Crafting
            -- Sandbox (Befund 22:25, Pfad "seller.items.<Test-Item>"): SetFloor legt einen Eintrag an -> genau so zurück
            local item = Se:GetFloor(FAKE_ID)
            local sellerItems = A.db.seller and A.db.seller.items
            local itemEntry = sellerItems and sellerItems[FAKE_ID]
            local saved = { vp = A.GetVendorPrice, ab = Le.AverageBuyPrice, ri = Cr and Cr.testRecipeIndex, raw = Se.SuggestRaw, mk = A.marketKey, floor = item,
                roi = A.db.settings.deBuyRoi }
            local res = { pcall(function()
                A.marketKey = nil
                A.db.settings.deBuyRoi = 20                         -- Mindestgewinn = Einstellung (Standard 20 %)
                if Cr then Cr.testRecipeIndex = {} end
                Se:SetFloor(FAKE_ID, nil)
                A.GetVendorPrice = function() return 950 end
                Le.AverageBuyPrice = function() return nil end
                local a, sa = Se:AutoFloor(FAKE_ID)
                Le.AverageBuyPrice = function() return 1900 end
                local b, sb = Se:AutoFloor(FAKE_ID)
                Se.SuggestRaw = function() return 800, "Test" end
                local sp, _, at, ssrc = Se:Suggest(FAKE_ID)
                Se:SetFloor(FAKE_ID, 500)
                local c, sc = Se:AutoFloor(FAKE_ID)
                return a, sa, b, sb, sp, at, ssrc, c, sc
            end) }
            A.GetVendorPrice, Le.AverageBuyPrice, Se.SuggestRaw, A.marketKey, A.db.settings.deBuyRoi = saved.vp, saved.ab, saved.raw, saved.mk, saved.roi
            if Cr then Cr.testRecipeIndex = saved.ri end
            if sellerItems then sellerItems[FAKE_ID] = itemEntry end
            if not res[1] then error(res[2], 0) end
            local parts = {}
            for i = 2, 10 do parts[#parts + 1] = tostring(res[i]) end
            local got = table.concat(parts, "/")
            local want = "1000/vendor/2400/cost/2400/true/cost/500/hand"
            return got == want, got, want
        end)
        end)
        B(function()
        Chk("T262", "J", "H6 Abläufe in Folge (T-H6): 3 abgelaufen nach einem Verkauf, laufende zählt nicht, verlorene Einzahlungen", function()
            local Le = A.Ledger
            local db = A.db.ledger
            local saved = { entries = db.entries }
            local res = { pcall(function()
                local now = time()
                db.entries = {}
                Le.speedCache, Le.rateCache = {}, {}
                for k = 1, 4 do
                    db.entries[#db.entries + 1] = { kind = "deposit", src = "post", itemID = FAKE_ID, t = now - 10 * 86400 + k * 86400, qty = 1, amount = 100, hours = 24 }
                end
                db.entries[#db.entries + 1] = { kind = "sale", src = "mail", itemID = FAKE_ID, t = now - 10 * 86400 + 86400 + 3 * 3600, qty = 1, amount = 1000 }
                db.entries[#db.entries + 1] = { kind = "deposit", src = "post", itemID = FAKE_ID, t = now - 3600, qty = 1, amount = 100, hours = 24 }
                if Le.InvalidateIndex then Le:InvalidateIndex() end
                return Le:ExpiryStreak(FAKE_ID, now)
            end) }
            db.entries = saved.entries
            Le.speedCache, Le.rateCache = {}, {}
            if Le.InvalidateIndex then Le:InvalidateIndex() end
            if not res[1] then error(res[2], 0) end
            local got = tostring(res[2]) .. "/" .. tostring(res[3])
            return got == "3/300", got, "3/300"
        end)
        end)
        B(function()
        Chk("T263", "J", "H7 Rendite je Geschäftsart (T-H7): Flippen, Herstellen, Entzaubern, Rohstoffe richtig zugeordnet und summiert", function()
            local Act, Le = A.Activity, A.Ledger
            local db = A.db.ledger
            local saved = { entries = db.entries, act = A.db.activity, deLog = A.db.deLog, rep = Le.DisenchantReport }
            local res = { pcall(function()
                local now = time()
                A.db.activity = { days = {}, crafts = {} }
                A.db.deLog = { { t = now - 86400, itemID = FAKE_ID + 9, paid = 100, loot = { { FAKE_ID + 3, 2 } } } }
                Le.DisenchantReport = function() return {}, { spent = 100, value = 250, ownValue = 0 } end
                db.entries = {
                    { kind = "buy", itemID = FAKE_ID, t = now - 2 * 86400, qty = 10, amount = 1000 },
                    { kind = "sale", src = "mail", itemID = FAKE_ID, t = now - 86400, qty = 10, amount = 1500, cut = 75 },
                    { kind = "sale", src = "mail", itemID = FAKE_ID + 1, t = now - 86400, qty = 1, amount = 500, cut = 25 },
                    { kind = "sale", src = "mail", itemID = FAKE_ID + 2, t = now - 86400, qty = 1, amount = 300, cut = 15 },
                    { kind = "sale", src = "mail", itemID = FAKE_ID + 3, t = now - 86400, qty = 2, amount = 260, cut = 13 },
                }
                Act:NoteCraft(FAKE_ID + 1, 200, now - 2 * 86400)
                local r, t = Act:Business(0)
                local function f(x) return string.format("%d/%d/%d", x.invested, x.revenue, x.profit) end
                return f(r.flip) .. " " .. f(r.craft) .. " " .. f(r.de) .. " " .. f(r.raw) .. " " .. f(t)
            end) }
            db.entries, A.db.activity, A.db.deLog, Le.DisenchantReport = saved.entries, saved.act, saved.deLog, saved.rep
            if not res[1] then error(res[2], 0) end
            local want = "1000/1425/425 200/475/275 100/250/150 0/285/285 1300/2435/1135"
            return res[2] == want, res[2], want
        end)
        end)
        B(function()
        Chk("T264", "J", "H9 Gold pro Stunde (T-H9a bis g): 6g/Std., Pause, Folgetag, zu wenig Daten, 7 Min., AFK, Scan ohne Handlung", function()
            local Act, Le = A.Activity, A.Ledger
            local db = A.db.ledger
            local saved = { entries = db.entries, act = A.db.activity, deLog = A.db.deLog, sessions = Act.sessions, afk = Act.afk, rep = Le.DisenchantReport }
            local res = { pcall(function()
                local today = Le.DayKey(time())
                local base = today + 12 * 3600
                Le.DisenchantReport = function() return {}, { spent = 0, value = 0, ownValue = 0 } end
                A.db.deLog = {}
                local function fresh() A.db.activity = { days = {}, crafts = {} }; Act.sessions = {}; Act.afk = nil end
                -- a: 30 Min. AH aktiv (jede Minute eine Handlung), Gewinn Flippen 3g -> 6g/Std.
                fresh()
                for m = 0, 30 do Act:Touch("ah", base + m * 60) end
                Act:Stop("ah", base + 30 * 60)
                db.entries = { { kind = "buy", itemID = FAKE_ID, t = base - 3600, qty = 1, amount = 10000 },
                               { kind = "sale", src = "mail", itemID = FAKE_ID, t = base + 2 * 3600, qty = 1, amount = 40000, cut = 0 } }
                local ra = Act:Report("all")
                local a = math.floor((ra.flip.perHour or 0) + 0.5)
                -- b: Herstellen mit 5 Min. Pause in der Serie -> Pause zählt nicht
                fresh()
                for _, m in ipairs({ 0, 1, 2, 7, 8 }) do Act:Touch("craft", base + m * 60) end
                local b = Act:Seconds(0).craft
                -- c: hergestellt am Vortag, Verkauf heute per Post -> zählt zum Herstellen des Vortags
                fresh()
                Act:NoteCraft(FAKE_ID + 1, 100, today - 4 * 3600)
                db.entries = { { kind = "sale", src = "mail", itemID = FAKE_ID + 1, t = today + 10 * 3600, qty = 1, amount = 1000, cut = 50 } }
                local c1 = Act:Business(today).craft.revenue
                local c2 = Act:Business(today - 86400).craft.revenue
                -- d: 10 Min. Daten -> zu wenig Daten
                fresh()
                for m = 0, 10 do Act:Touch("ah", base + m * 60) end
                Act.sessions = {}
                db.entries = { { kind = "sale", src = "mail", itemID = FAKE_ID + 2, t = base + 3600, qty = 1, amount = 1000, cut = 50 } }
                local rd = Act:Report("all")
                local d = rd.raw.perHour == nil and Act:PerHourText(rd.raw):find(L["zu wenig Daten"], 1, true) ~= nil
                -- e: AH 30 Min. offen, letzte Handlung nach 5 Min. -> 7 Min.
                fresh()
                for m = 0, 5 do Act:Touch("ah", base + m * 60) end
                Act:Stop("ah", base + 30 * 60)
                local e = Act:Seconds(0).ah
                -- f: AFK nach 3 Min. -> ab da nichts
                fresh()
                for m = 0, 3 do Act:Touch("ah", base + m * 60) end
                Act:SetAFK(true, base + 210)
                Act:Touch("ah", base + 300)
                Act:Stop("ah", base + 600)
                local f = Act:Seconds(0).ah
                Act:SetAFK(false)
                -- g: automatischer Scan ohne Handlung -> keine Zeit
                fresh()
                A:Fire("SCAN_FINISHED", true)
                A:Fire("SEARCH_RESULTS")
                local g = Act:Seconds(0).ah
                return a, b, c1, c2, d, e, f, g
            end) }
            db.entries, A.db.activity, A.db.deLog, Act.sessions, Act.afk, Le.DisenchantReport = saved.entries, saved.act, saved.deLog, saved.sessions, saved.afk, saved.rep
            if not res[1] then error(res[2], 0) end
            local parts = {}
            for i = 2, 9 do parts[#parts + 1] = tostring(res[i]) end
            local got = table.concat(parts, "/")
            local want = "60000/180/0/950/true/420/180/0"
            return got == want, got, want
        end)
        end)
        B(function()
        Chk("T265", "J", "H8 Raid-Hinweis vor dem 9.12.2026: ab 25.11. einmal am Tag, nach dem 9.12. aus", function()
            local Act = A.Activity
            local saved = { force = A.forceForever, print = A.Print, act = A.db.activity }
            local res = { pcall(function()
                A.forceForever = true
                A.db.activity = { days = {}, crafts = {} }
                local n = 0
                A.Print = function() n = n + 1 end
                local function at(m, d) return time({ year = 2026, month = m, day = d, hour = 12 }) end
                return Act:RaidHint(at(11, 20)), Act:RaidHint(at(11, 26)), Act:RaidHint(at(11, 26) + 3600), Act:RaidHint(at(11, 27)),
                    Act:RaidHint(at(12, 10)), n
            end) }
            A.forceForever, A.Print, A.db.activity = saved.force, saved.print, saved.act
            if not res[1] then error(res[2], 0) end
            local got = string.format("%s/%s/%s/%s/%s/%s", tostring(res[2]), tostring(res[3]), tostring(res[4]), tostring(res[5]), tostring(res[6]), tostring(res[7]))
            return got == "false/true/false/true/false/2", got, "false/true/false/true/false/2"
        end)
        end)
        B(function()
        Chk("T266", "J", "Schnittstelle AHSentinel.API v1 (T-API1 bis T-API7)", function()
            local API, Cr, D = A.API, A.Crafting, A.Disenchant
            local saved = { rp = A.RealPrice, up = Cr.UnitPrice, ri = Cr.testRecipeIndex, prior = D.Prior, deal = D.DealValue, subs = API.subscribers }
            local res = { pcall(function()
                local out = {}
                -- 1: dieselbe Tabelle, Version 1, alter Aufruf AHAnalyzerPro:API(name) geht weiter
                out[#out + 1] = tostring(_G.AHSentinel and _G.AHSentinel.API == AHAnalyzerPro.API and API.version == 1 and AHAnalyzerPro:API("print") == print)
                -- 2: unbekanntes Item -> nil, kein Fehler
                local unk = 999999991
                local all = API.Price(unk) == nil and API.NetSale(unk, 1) == nil and API.Deposit(unk, 1, 24) == nil and API.MaterialCost(unk, 1) == nil
                    and API.DisenchantValue(unk) == nil and API.BestWay(unk) == nil and API.SellSpeed(unk) == nil and API.Price(nil) == nil
                out[#out + 1] = tostring(all)
                -- 3: Price = Rechenwert aus dem letzten Scan
                A.RealPrice = function() return 1234, { inScan = true, source = "ah", currentTime = time() - 60 } end
                local p, src = API.Price(FAKE_ID)
                -- Ausreisser-Ersatz durch den Median: Quelle "market", auch wenn das Item im Scan ist (offener Punkt 2b)
                A.RealPrice = function() return 1000, { inScan = true, source = "market", currentTime = time() - 60 } end
                local _, srcM = API.Price(FAKE_ID)
                -- Mindestgewinn = Einstellung "Mindestrendite" (offener Punkt 2a)
                local roi = A.db.settings.deBuyRoi
                A.db.settings.deBuyRoi = 30
                local mp = API.MinProfitPct()
                A.db.settings.deBuyRoi = roi
                out[#out + 1] = tostring(p) .. src .. "/" .. tostring(srcM) .. "/" .. tostring(mp)
                -- 4: NetSale = RealValue
                out[#out + 1] = tostring(API.NetSale(FAKE_ID, 20) == math.floor(A:RealValue(FAKE_ID, 20) + 0.5))
                A.RealPrice = saved.rp
                -- 5: MaterialCost wählt Leinenstoff statt Ballen (Ballen selbst herstellen ist günstiger)
                local hose, ballen, stoff = FAKE_ID + 10, FAKE_ID + 11, FAKE_ID + 12
                Cr.testRecipeIndex = { [hose] = { made = 1, reagents = { { ballen, 3 } } }, [ballen] = { made = 1, reagents = { { stoff, 2 } } } }
                local prices = { [ballen] = 100, [stoff] = 30 }
                Cr.UnitPrice = function(_, id) return prices[id] end
                local cost, list = API.MaterialCost(hose, 1)
                out[#out + 1] = tostring(cost) .. (list and list[1] and list[1].source or "?")
                -- 6: DisenchantValue = Entzauberungswert (D:DealValue)
                D.Prior = function() return true end
                D.DealValue = function() return 500, 450, true, "estimate", 0 end
                local g, n, cnt, s6 = API.DisenchantValue(FAKE_ID)
                out[#out + 1] = string.format("%s/%s/%s/%s", tostring(g), tostring(n), tostring(cnt), tostring(s6))
                -- 7: Subscribe: nach Scan genau ein Aufruf "scan"
                API.subscribers = {}
                API.Flush()                                   -- liegengebliebene Gründe aus dem Spiel (z. B. "ledger") zuerst leeren (C4)
                local calls = {}
                API.Subscribe(function(r) calls[#calls + 1] = r end)
                A:Fire("SCAN_FINISHED", true)
                A:Fire("SCAN_FINISHED", true)
                API.Flush()
                out[#out + 1] = table.concat(calls, ",")
                return table.concat(out, " ")
            end) }
            A.RealPrice, Cr.UnitPrice, Cr.testRecipeIndex, D.Prior, D.DealValue, API.subscribers = saved.rp, saved.up, saved.ri, saved.prior, saved.deal, saved.subs
            if not res[1] then error(res[2], 0) end
            local want = "true true 1234scan/market/30 true 180craft 500/450/0/table scan"
            return res[2] == want, res[2], want
        end)
        end)
        B(function()
        Chk("T267", "J", "G1 Gewinn-Fenster aus bei offenem ProfessionSentinel-Panel, G2 'Jetzt kaufen' genau einmal (T-G1, T-G2)", function()
            local Cr, Sn = A.Crafting, A.Sniper
            local saved = { kind = Cr.kind, panel = Cr.panel, open = Cr.Open, hid = Cr.hiddenForPS, cbu = Cr.closedByUser, ov = A.apiOverride,
                ba = Sn.buyAlert, sound = A.db.settings.alertSound, ht = Sn.hintText, ha = Sn.hintAt }
            local res = { pcall(function()
                local shown = true
                local fake = { IsShown = function() return shown end, Hide = function() shown = false end }
                local opened = 0
                Cr.kind, Cr.panel, Cr.hiddenForPS, Cr.closedByUser = "trade", fake, nil, nil
                Cr.Open = function() opened = opened + 1; shown = true end
                local psOpen = true
                A.apiOverride = { ProfessionSentinel = { IsPanelShown = function() return psOpen end } }
                Cr:CheckPSPanel()
                local a = shown
                psOpen = false
                Cr:CheckPSPanel()
                local b, o1 = shown, opened
                A.apiOverride = { ProfessionSentinel = false }          -- ohne ProfessionSentinel: wie bisher
                Cr:CheckPSPanel()
                local c = shown and opened == 1
                -- G2: waiting -> ready zweimal gemeldet -> genau 1 Hinweis
                A.db.settings.alertSound = false
                Sn.hintText, Sn.hintAt = nil, nil
                local n0 = Sn.hintCount
                Sn:StartAlert({})
                Sn:StartAlert({})
                local n = Sn.hintCount - n0
                local _, _, rel = Sn.hintFrame and Sn.hintFrame:GetPoint(1)
                Sn:StopAlert()
                if Sn.hintFrame then Sn.hintFrame:Hide() end
                return a, b, o1, c, n
            end) }
            Cr.kind, Cr.panel, Cr.Open, Cr.hiddenForPS, Cr.closedByUser, A.apiOverride = saved.kind, saved.panel, saved.open, saved.hid, saved.cbu, saved.ov
            Sn.buyAlert, A.db.settings.alertSound, Sn.hintText, Sn.hintAt = saved.ba, saved.sound, saved.ht, saved.ha
            if not res[1] then error(res[2], 0) end
            local got = string.format("%s/%s/%s/%s/%s", tostring(res[2]), tostring(res[3]), tostring(res[4]), tostring(res[5]), tostring(res[6]))
            return got == "false/true/1/true/1", got, "false/true/1/true/1"
        end)
        end)
        B(function()
        Chk("T268", "J", "D1 Verkaufsrechnung nicht doppelt (T-D1a/b, T-R5 bis T-R7, T-D1c/T-M11 fixL4), D2 Diagnose-Zählung", function()
            local Le, I = A.Ledger, A.Inbox
            local db = A.db.ledger
            local saved = { entries = db.entries, seen = db.seen, fix = db.fixL4, removed = db.removed, force = A.forceForever,
                av = I.Available, n = I.GetInboxNumItems, h = I.GetInboxHeaderInfo, inv = I.GetInboxInvoiceInfo, raw = Le.rawLogged,
                pr = A.Print, fire = A.Fire, md = A.db.marketData, pk = A.parkedKey, mk = A.db.markets }
            local res = { pcall(function()
                A.Print, A.Fire = function() end, function() end
                A.forceForever, Le.rawLogged = true, true
                local mails = {}
                I.Available = function() return true end
                I.GetInboxNumItems = function() return #mails end
                I.GetInboxHeaderInfo = function(i) return nil, nil, "AH", "Verkauft", mails[i].money, 0, 29 end
                I.GetInboxInvoiceInfo = function(i) local m = mails[i]; return "seller", "AHS-Testitem", nil, m.bid, m.q, m.dep, m.cons, nil, nil, 0, m.f11 end
                local function sum() local q, a = 0, 0; for _, e in ipairs(db.entries) do q = q + (e.qty or 0); a = a + (e.amount or 0) end; return #db.entries .. ":" .. q .. ":" .. a end
                -- D1a / R5: zuerst mit Gold 7778, dann dieselbe Rechnung mit Gold 0
                db.entries, db.seen = {}, {}
                mails = { { bid = 8082, q = 18, dep = 100, cons = 404, money = 7778, f11 = 18 } }
                Le:ScanInbox()
                local e1 = db.entries[1] or {}
                local b = string.format("%s/%s/%s", tostring(e1.amount), tostring(e1.qty), e1.qty and tostring(math.floor(e1.amount / e1.qty + 0.5)) or "?")
                mails[1].money = 0
                Le:ScanInbox()
                local a = sum()
                -- alte Buchung (Schlüssel mit Gold aus 0.65.51) und Rechnung mit Gold 0 -> nicht neu
                db.seen = {}
                Le:ScanInbox()
                local a2 = sum()
                -- R6: zwei Verkäufe 18 Stück in derselben Stunde mit Gold 7778 und 7700 -> 2 Buchungen
                db.entries, db.seen = {}, {}
                mails = { { bid = 8082, q = 18, dep = 100, cons = 404, money = 7778 }, { bid = 8000, q = 18, dep = 100, cons = 400, money = 7700 } }
                Le:ScanInbox()
                local r6 = #db.entries
                -- zwei gleiche Rechnungen gleichzeitig -> 2 Buchungen, beim zweiten Lesen keine neue
                db.entries, db.seen = {}, {}
                mails = { { bid = 8082, q = 18, dep = 100, cons = 404, money = 7778 }, { bid = 8082, q = 18, dep = 100, cons = 404, money = 7778 } }
                Le:ScanInbox(); Le:ScanInbox()
                local same = #db.entries
                -- R7: nur mit Gold 0 -> 1 Buchung aus Feld 4
                db.entries, db.seen = {}, {}
                mails = { { bid = 8082, q = 18, dep = 100, cons = 404, money = 0 } }
                Le:ScanInbox()
                local e7 = db.entries[1] or {}
                local r7 = string.format("%d/%s/%s", #db.entries, tostring(e7.amount), tostring(e7.approx))
                -- D1c / M11: fixL4 nimmt die Doppelbuchung aus 0.65.44 heraus, einmalig, mit Sicherung
                local now = time()
                db.entries, db.fixL4, db.removed = {
                    { kind = "sale", src = "mail", itemID = FAKE_ID, name = "AHS-Testitem", t = now, qty = 18, amount = 8082, cut = 404, refund = 100,
                      inv = { price = 18, cut = 404, deposit = 100, money = 7778 } },
                    { kind = "sale", src = "mail", itemID = FAKE_ID, name = "AHS-Testitem", t = now + 60, qty = 18, amount = 18, cut = 404, refund = 100,
                      inv = { price = 18, cut = 404, deposit = 100, money = 0 } },
                    { kind = "sale", src = "mail", itemID = FAKE_ID, name = "AHS-Testitem", t = now - 5 * 3600, qty = 18, amount = 8082, cut = 404, refund = 100,
                      inv = { price = 18, cut = 404, deposit = 100, money = 7778 } },
                }, nil, nil
                local n1 = Le:FixL4(true)
                local n2 = Le:FixL4(true)
                local m = string.format("%s/%s/%d/%d/%s", tostring(n1), tostring(n2), #db.entries, #db.removed, tostring(db.removed[1] and db.removed[1].old4 and db.removed[1].old4.amount))
                -- D2: Zählung nach dem Ausloggen (ParkMarket) wie die Statuszeile
                A.db.markets = { ["Test|Horde"] = { data = { [1] = {}, [2] = {}, [3] = {} } } }
                A.db.marketData, A.parkedKey = {}, "Test|Horde"
                local d2 = A:MarketItemCount()
                return b, a, a2, r6, same, r7, m, d2
            end) }
            db.entries, db.seen, db.fixL4, db.removed, A.forceForever = saved.entries, saved.seen, saved.fix, saved.removed, saved.force
            I.Available, I.GetInboxNumItems, I.GetInboxHeaderInfo, I.GetInboxInvoiceInfo, Le.rawLogged = saved.av, saved.n, saved.h, saved.inv, saved.raw
            A.Print, A.Fire, A.db.marketData, A.parkedKey, A.db.markets = saved.pr, saved.fire, saved.md, saved.pk, saved.mk
            if not res[1] then error(res[2], 0) end
            local parts = {}
            for i = 2, 9 do parts[#parts + 1] = tostring(res[i]) end
            local got = table.concat(parts, " | ")
            local want = "8082/18/449 | 1:18:8082 | 1:18:8082 | 2 | 2 | 1/8082/true | 1/nil/2/1/18 | 3"
            return got == want, got, want
        end)
        end)
        B(function()
        Chk("T269", "J", "Sniper schneller A+C (T-SN1, T-SN2, T-SN5, T-SN6, T-SN7, T-SN9) und fremder AH-Fehler (offener Punkt 3)", function()
            local Sn = A.Sniper
            local saved = { confirm = Sn.Confirm, buy = Sn.Buy, fresh = Sn.IsResultFresh, plan = Sn.PlanNext, open = A.IsAHOpen, pending = Sn.pending,
                lp = Sn.lastPress, result = Sn.result, getT = Sn.GetTarget, rem = Sn.Remaining, pr = A.Print, hint = Sn.BuyHint, fire = A.Fire,
                inflight = Sn.inFlight, after = Sn.AfterPurchase, ba = Sn.buyAlert }
            local res = { pcall(function()
                local out = {}
                A.IsAHOpen = function() return true end
                A.Print, Sn.BuyHint, A.Fire = function() end, function() end, function() end
                local confirms, buys = 0, 0
                Sn.Confirm = function() confirms = confirms + 1; Sn.pending = nil; return true end
                Sn.Buy = function() buys = buys + 1; return true end
                Sn.IsResultFresh = function() return true end
                Sn.PlanNext = function() return { kind = "commodity", key = "i:" .. FAKE_ID, itemID = FAKE_ID, qty = 5, total = 50 } end
                -- SN1: bereit, zweite Raste 0,06 s nach der ersten -> bestätigt; Reservieren-Raste 0,1 s danach -> gesperrt
                Sn.pending = { key = "i:" .. FAKE_ID, state = "ready" }
                Sn.lastPress = GetTime() - 0.06
                Sn:OnTrigger()
                Sn.lastPress = GetTime() - 0.1
                Sn:OnTrigger()
                out[#out + 1] = confirms .. "/" .. buys
                -- SN2: 5 Rasten in der Wartezeit -> nichts, keine Meldung; erste Raste nach "ready" -> bestätigt
                confirms = 0
                Sn.pending = { key = "i:" .. FAKE_ID, state = "waiting" }
                local msgs = 0
                for _ = 1, 5 do
                    Sn.lastPress = GetTime() - 1
                    local _, msg = Sn:OnTrigger()
                    if msg then msgs = msgs + 1 end
                end
                local c0 = confirms
                Sn.pending.state = "ready"
                Sn.lastPress = GetTime() - 1
                Sn:OnTrigger()
                out[#out + 1] = c0 .. "/" .. msgs .. "/" .. confirms
                Sn.Confirm, Sn.Buy, Sn.IsResultFresh, Sn.PlanNext = saved.confirm, saved.buy, saved.fresh, saved.plan
                -- SN5: 20@11c, 30@18c, 50@23c, Max 19c -> 50 Stück
                local t = { key = "i:" .. FAKE_ID, itemID = FAKE_ID, maxPrice = 19, qty = 1000, budget = 100000, bought = 0, spent = 0 }
                Sn.GetTarget = function(_, k) return t end
                Sn.Remaining = function() return 1000, 100000 end
                Sn.result = { key = t.key, itemID = FAKE_ID, commodity = true, time = GetTime(), listings = {
                    { qty = 20, price = 11, pass = true }, { qty = 30, price = 18, pass = true }, { qty = 50, price = 23, pass = true } } }
                local plan = Sn:PlanNext()
                out[#out + 1] = tostring(plan and plan.qty)
                -- SN6: Waren-Ergebnis 4 s alt -> nicht mehr aktuell
                Sn.result.time = GetTime() - 4
                out[#out + 1] = tostring(Sn:IsResultFresh())
                -- SN7: Preis bestätigt für weniger Stücke -> Menge = gelieferte Menge
                Sn.pending = { key = t.key, itemID = FAKE_ID, qty = 100, state = "waiting" }
                Sn:OnEvent("COMMODITY_PRICE_UPDATED", 18, 900)
                out[#out + 1] = tostring(Sn.pending and Sn.pending.state) .. ":" .. tostring(Sn.pending and Sn.pending.qty)
                Sn.pending = nil
                -- SN9: ohne Tastendruck kein Kauf
                local okB = Sn:Buy({ kind = "commodity", key = t.key, itemID = FAKE_ID, qty = 1, total = 10 })
                out[#out + 1] = tostring(okB) .. ":" .. tostring(Sn.pending)
                -- Punkt 3: fremder AH-Fehler, danach Erfolg -> gezählt
                Sn.AfterPurchase = function() end
                Sn.inFlight = { key = t.key, itemID = FAKE_ID, qty = 7, cost = 70, time = GetTime() }
                Sn:OnEvent("AUCTION_HOUSE_SHOW_ERROR", 1)
                local still = Sn.inFlight ~= nil
                Sn:OnEvent("COMMODITY_PURCHASE_SUCCEEDED")
                out[#out + 1] = tostring(still) .. ":" .. tostring(t.bought)
                return table.concat(out, " ")
            end) }
            Sn.Confirm, Sn.Buy, Sn.IsResultFresh, Sn.PlanNext, A.IsAHOpen, Sn.pending = saved.confirm, saved.buy, saved.fresh, saved.plan, saved.open, saved.pending
            Sn.lastPress, Sn.result, Sn.GetTarget, Sn.Remaining, A.Print, Sn.BuyHint, A.Fire = saved.lp, saved.result, saved.getT, saved.rem, saved.pr, saved.hint, saved.fire
            Sn.inFlight, Sn.AfterPurchase, Sn.buyAlert = saved.inflight, saved.after, saved.ba
            if not res[1] then error(res[2], 0) end
            local want = "1/0 0/0/1 50 false ready:50 false:nil true:7"
            return res[2] == want, res[2], want
        end)
        end)
        B(function()
        Chk("T270", "J", "AH-Anteil abgerundet wie gemessen (6279 -> 313, 4042 -> 202)", function()
            local saved = { mk = A.marketKey }
            A.marketKey = nil
            local a, b = A:SaleFee(nil, 6279, 1), A:SaleFee(nil, 4042, 1)
            local _, c = A.Seller:Proceeds(91, 69, nil, 1)
            A.marketKey = saved.mk
            local got = a .. "/" .. b .. "/" .. c
            return got == "313/202/313", got, "313/202/313"
        end)
        end)
        B(function()
        Chk("T271", "J", "Sniper schneller B+D (T-SN3 Wächter pausiert, T-SN4 Ziele nach Ertrag, T-SN8 Messung und Anzeige, D3)", function()
            local Sn, W = A.Sniper, A.Watcher
            local db = A.db.sniper
            local saved = { armed = db.armed, targets = db.targets, stats = db.stats, ep = Sn.episode, hits = Sn.hitTimes, credit = Sn.credit,
                buf = Sn.meterBuf, extra = Sn.extra, open = A.IsAHOpen }
            local res = { pcall(function()
                local out = {}
                local ka, kb = "i:" .. FAKE_ID, "i:" .. (FAKE_ID + 1)
                db.targets = { [ka] = { key = ka, kind = "item", itemID = FAKE_ID, maxPrice = 10, qty = 5, budget = 50, bought = 0, spent = 0 },
                               [kb] = { key = kb, kind = "item", itemID = FAKE_ID + 1, maxPrice = 10, qty = 5, budget = 50, bought = 0, spent = 0 } }
                Sn.extra = {}
                A.IsAHOpen = function() return true end
                -- SN3
                db.armed = true
                local y1 = W:YieldReason()
                db.armed = false
                local y2 = W:YieldReason()
                out[#out + 1] = tostring(y1 == L["Sniper hat Ziele – Wächter pausiert"]) .. "/" .. tostring(y2 ~= L["Sniper hat Ziele – Wächter pausiert"])
                -- SN4: Ziel A mit 3 Treffern in 10 Min., Ziel B ohne -> A öfter, B nicht heraus
                local now = GetTime()
                Sn.hitTimes = { [ka] = { now - 60, now - 120, now - 300 } }
                Sn.credit = {}
                local entries = { { key = ka }, { key = kb } }
                local na, nb = 0, 0
                for _ = 1, 26 do
                    local e = Sn:PickTarget(entries)
                    if e.key == ka then na = na + 1 else nb = nb + 1 end
                end
                out[#out + 1] = tostring(na > nb and nb >= 1) .. ":" .. na .. "/" .. nb
                -- SN8: Ablauf Treffer -> gekauft: 5 Zeiten, Ergebnis gekauft, Anzeige zählt
                db.stats, Sn.episode, Sn.hitTimes = nil, nil, {}
                Sn.testMeter = true                      -- Messung im Test erlaubt (db.stats wird danach zurückgesetzt)
                Sn.meterBuf = { n = 0, out = {}, sums = {}, cnt = {}, last = GetTime() }
                local ta = db.targets[ka]
                Sn:MeterHit(ta, GetTime() - 0.4)
                Sn:MeterHit(ta, GetTime())              -- derselbe Treffer, neu gesucht: zählt nicht doppelt
                Sn:MeterMark("tReserve"); Sn:MeterMark("tReady"); Sn:MeterMark("tConfirm"); Sn:MeterMark("tDone")
                Sn:MeterEnd("gekauft")
                local n5 = 0
                for i = 1, 5 do if Sn.lastEpisode and Sn.lastEpisode.times[i] then n5 = n5 + 1 end end
                local r5 = Sn.lastEpisode and Sn.lastEpisode.result
                Sn:MeterHit(db.targets[kb], GetTime())
                Sn:MeterEnd("weg")
                local st = Sn:Stats()
                out[#out + 1] = string.format("%d/%s/%d/%d/%d", n5, tostring(r5), st.hits, st.bought, st.missed)
                out[#out + 1] = tostring(Sn:StatsText():find("2", 1, true) ~= nil)
                -- D3: 10 Treffer, 1 gekauft -> Hinweis
                out[#out + 1] = tostring(Sn:OthersFaster({ hitN = 10, boughtN = 1 })) .. "/" .. tostring(Sn:OthersFaster({ hitN = 10, boughtN = 3 }))
                return table.concat(out, " ")
            end) }
            db.armed, db.targets, db.stats, Sn.episode, Sn.hitTimes, Sn.credit, Sn.meterBuf, Sn.extra = saved.armed, saved.targets, saved.stats, saved.ep, saved.hits, saved.credit, saved.buf, saved.extra
            A.IsAHOpen, Sn.testMeter = saved.open, nil
            if not res[1] then error(res[2], 0) end
            local ok = res[2]:match("^true/true true:%d+/%d+ 5/gekauft/2/1/1 true true/false$") ~= nil
            return ok, res[2], "true/true true:A/B 5/gekauft/2/1/1 true true/false"
        end)
        end)
        B(function()
        Chk("T272", "J", "Sync über GoldSentinelSync (T-SY1 bis T-SY3, T-GS1 bis T-GS5): nie Kanal, Gilde/Gruppe, Kanal verweigert, alte Nachricht, Test-Zeile", function()
            local S, GSS = A.Sync, _G.GoldSentinelSync
            if not (GSS and S.ep) then return false, "GoldSentinelSync fehlt" end
            local sa = { send = GSS.api.send, g = GSS.api.inGuild, r = GSS.api.inRaid, p = GSS.api.inGroup, queue = GSS.queue,
                refused = GSS.stats.channelRefused, sim = A.Simulated, pr = A.Print, peers = A.db.sync.peers, om = S.OnMessage, en = A.db.sync.enabled }
            local res = { pcall(function()
                local out = {}
                local sent = {}
                GSS.api.send = function(prefix, msg, dist, target) sent[#sent + 1] = dist; return true end
                GSS.queue = {}
                A.Simulated = function() return false end
                A.Print = function() end
                -- SY1/SY2/GS1: in Gilde -> GUILD, in Gruppe -> PARTY, nie CHANNEL
                GSS.api.inGuild, GSS.api.inRaid, GSS.api.inGroup = function() return true end, function() return false end, function() return true end
                S.SendNow("S:0:test")
                while #GSS.queue > 0 do GSS.Pump(true) end
                out[#out + 1] = table.concat(sent, "+")
                -- ohne Gilde und Gruppe: nichts
                sent = {}
                GSS.api.inGuild, GSS.api.inGroup = function() return false end, function() return false end
                local okNo = S.SendNow("S:0:test")
                out[#out + 1] = tostring(okNo) .. ":" .. #GSS.queue .. ":" .. table.concat(S:Paths(), "+")
                -- SY3: NOT_ALLOWED_IN_CHANNEL wird gezählt
                local r0 = GSS.stats.channelRefused
                GSS.OnChannelNotice("NOT_ALLOWED_IN_CHANNEL")
                out[#out + 1] = tostring(GSS.stats.channelRefused - r0)
                -- GS2/GS3: alte Nachricht ohne Kopf (alte Version eines Mitspielers), Absender nil wird vertragen
                local got = {}
                A.db.sync.enabled = true
                S.OnMessage = function(_, prefix, msg, dist, sender) got[#got + 1] = tostring(msg) .. "|" .. tostring(sender) end
                GSS.OnAddonMessage("AHAP1", "S:0:abc", "GUILD", nil)
                out[#out + 1] = table.concat(got, ",")
                S.OnMessage = sa.om
                local okNil = pcall(S.OnMessage, S, "AHAP1", "S:0:abc", "GUILD", nil)
                out[#out + 1] = tostring(okNil)
                -- GS4: kein Beitritt, kein Kanal-Weg
                out[#out + 1] = tostring(S.Target == nil and S.channelId == nil)
                -- GS5: /ahs sync test gibt eine Zeile aus (ohne Weg sofort)
                local lines = {}
                A.Print = function(_, m) lines[#lines + 1] = A:PlainText(tostring(m)) end
                S:Test()
                out[#out + 1] = tostring(#lines == 1 and lines[1]:find(L["Sync-Test: kein Weg (keine Gilde, keine Gruppe)."], 1, true) ~= nil)
                return table.concat(out, " ")
            end) }
            GSS.api.send, GSS.api.inGuild, GSS.api.inRaid, GSS.api.inGroup, GSS.queue = sa.send, sa.g, sa.r, sa.p, sa.queue
            GSS.stats.channelRefused, A.Simulated, A.Print, A.db.sync.peers, S.OnMessage, A.db.sync.enabled = sa.refused, sa.sim, sa.pr, sa.peers, sa.om, sa.en
            if not res[1] then error(res[2], 0) end
            local want = "GUILD+PARTY false:0: 1 S:0:abc|nil true true true"
            return res[2] == want, res[2], want
        end)
        end)
        B(function()
        Chk("T274", "J", "T-S1 über Sn:Confirm: 'Kauf gesendet', Zähler unverändert, Kaufbefehl nur über den Schutz (Protokoll)", function()
            local Sn = A.Sniper
            local saved = { pending = Sn.pending, inflight = Sn.inFlight, getT = Sn.GetTarget, pr = A.Print, it = Sn.inTrigger, ba = Sn.buyAlert,
                conf = Sn.confirming }
            local msgs = {}
            local res = { pcall(function()
                local key = "i:" .. FAKE_ID
                local t = { key = key, itemID = FAKE_ID, maxPrice = 20, qty = 50, budget = 5000, bought = 0, spent = 0 }
                Sn.GetTarget = function(self, k) if k == key then return t end return saved.getT(self, k) end
                A.Print = function(_, m) msgs[#msgs + 1] = A:PlainText(tostring(m)) end
                Sn.pending = { key = key, itemID = FAKE_ID, qty = 21, state = "ready", total = 246, started = GetTime() }
                Sn.inTrigger = true                     -- wie eine Raste (Sn:OnTrigger); Server-Befehl fängt der Schutz ab
                local ok = ST:RealFn("Sniper", "Confirm")(Sn)
                Sn.inTrigger = saved.it
                local sent = false
                for _, m in ipairs(msgs) do if m:find(L["Kauf gesendet: "], 1, true) then sent = true end end
                return ok, sent, t.bought, Sn.inFlight ~= nil and Sn.inFlight.qty
            end) }
            Sn.pending, Sn.inFlight, Sn.GetTarget, A.Print, Sn.inTrigger, Sn.buyAlert, Sn.confirming = saved.pending, saved.inflight, saved.getT, saved.pr, saved.it, saved.ba, saved.conf
            if not res[1] then error(res[2], 0) end
            local got = string.format("%s/%s/%s/%s", tostring(res[2]), tostring(res[3]), tostring(res[4]), tostring(res[5]))
            return got == "true/true/0/21", got, "true/true/0/21 (gesendet, noch nicht gezählt)"
        end)
        end)
        B(function()
        Chk("T275", "J", "T-V2 Teil 2: Item 'kaum' wird nicht als Flip vorgeschlagen ('schnell' schon)", function()
            local X = A.Extras
            local saved = { md = A.db.marketData, cur = A.GetCurrent, mv = A.GetMarketValue, rp = A.RealPrice, hist = A.GetHistory,
                ss = A.Ledger.SellSpeed, abs = A.IsAbsurdProfit, edl = A.ExpectedDepositLoss, lad = A.OfferLadder, rb = A.ResaleBasis }
            local res = { pcall(function()
                A.db.marketData = { [FAKE_ID] = {} }
                -- Befund Markt/Heute-Flip: Wiederverkauf aus Angebotsliste und Absatz (hier dahinter viel Angebot zu 19s)
                A.OfferLadder = function(_, id) if id == FAKE_ID then return { { 500, 10 }, { 1900, 50 } } end return saved.lad(A, id) end
                A.ResaleBasis = function(_, id) if id == FAKE_ID then return 30, 24 end return saved.rb(A, id) end
                A.GetCurrent = function(_, id) if id == FAKE_ID then return 500, 10, time() - 60 end return saved.cur(A, id) end
                A.GetMarketValue = function(_, id) if id == FAKE_ID then return 2000 end return saved.mv(A, id) end
                A.RealPrice = function(_, id) if id == FAKE_ID then return 2000 end return saved.rp(A, id) end
                A.GetHistory = function() local n = time(); return { { t = n - 10800, p = 2000, q = 10 }, { t = n - 7200, p = 2000, q = 10 }, { t = n - 3600, p = 2000, q = 10 } } end
                A.IsAbsurdProfit = function() return false end
                A.ExpectedDepositLoss = function() return 0 end
                local function found(speed)
                    A.Ledger.SellSpeed = function() return { speed = speed } end
                    for _, d in ipairs(X:GetFlipDeals(20)) do if d.itemID == FAKE_ID then return true end end
                    return false
                end
                return found("kaum"), found("schnell")
            end) }
            A.db.marketData, A.GetCurrent, A.GetMarketValue, A.RealPrice, A.GetHistory = saved.md, saved.cur, saved.mv, saved.rp, saved.hist
            A.Ledger.SellSpeed, A.IsAbsurdProfit, A.ExpectedDepositLoss = saved.ss, saved.abs, saved.edl
            A.OfferLadder, A.ResaleBasis = saved.lad, saved.rb
            if not res[1] then error(res[2], 0) end
            local got = "kaum " .. tostring(res[2]) .. ", schnell " .. tostring(res[3])
            return res[2] == false and res[3] == true, got, "kaum false, schnell true"
        end)
        end)
        B(function()
        Chk("T276", "J", "G2 beim Herstellen: 30 Ereignisse in 20 s mit 'Herstellen läuft' -> höchstens 3 Aufbauten (CRAFT_GAP 10 s)", function()
            local Cr = A.Crafting
            local saved = { clock = Cr.Clock, after = Cr.After, panel = Cr.panel, kind = Cr.kind, topKind = Cr.topKind, rd = Cr.RefreshDetail,
                top = Cr.Top, job = A.Job, until_ = Cr.craftingUntil, last = Cr.lastTopBuild, dirty = Cr.topDirty, force = Cr.topForce,
                planned = Cr.refreshPlanned, since = Cr.pendingSince, later = Cr.topLater, building = Cr.topBuilding, sig = Cr.topSig,
                api = Cr.API.ahstest, builds = Cr.topBuilds, pv = A.priceVersion, ev = Cr.lastEvent }
            local res = { pcall(function()
                local now, timers = 0, {}
                Cr.Clock = function() return now end
                Cr.After = function(sec, fn) timers[#timers + 1] = { t = now + sec, fn = fn } end
                local function runUntil(t)
                    while true do
                        local best
                        for i, x in ipairs(timers) do if x.t <= t and (not best or x.t < timers[best].t) then best = i end end
                        if not best then break end
                        local x = table.remove(timers, best)
                        now = x.t
                        x.fn()
                    end
                    now = t
                end
                Cr.API.ahstest = { num = function() return 5 end, selected = function() return nil end }
                Cr.panel = { IsShown = function() return true end, top = { SetData = function() end } }
                Cr.kind, Cr.topKind = "ahstest", "ahstest"
                Cr.RefreshDetail = function() end
                Cr.Top = function() return {}, 0 end
                A.Job = function(_, _, fn) fn() end
                Cr.lastTopBuild, Cr.topDirty, Cr.topForce, Cr.refreshPlanned, Cr.pendingSince, Cr.topLater, Cr.topBuilding = nil, nil, nil, nil, nil, nil, nil
                local b0 = Cr.topBuilds
                for i = 0, 29 do
                    runUntil(i * 20 / 30)
                    Cr.craftingUntil = now + Cr.CRAFT_HOLD       -- eigener Herstell-Zauber
                    A.priceVersion = (A.priceVersion or 0) + 1  -- Daten ändern sich wirklich
                    Cr:RequestRefresh(true, "Test")
                end
                runUntil(20)
                return Cr.topBuilds - b0
            end) }
            Cr.Clock, Cr.After, Cr.panel, Cr.kind, Cr.topKind, Cr.RefreshDetail, Cr.Top, A.Job = saved.clock, saved.after, saved.panel, saved.kind, saved.topKind, saved.rd, saved.top, saved.job
            Cr.craftingUntil, Cr.lastTopBuild, Cr.topDirty, Cr.topForce, Cr.refreshPlanned, Cr.pendingSince = saved.until_, saved.last, saved.dirty, saved.force, saved.planned, saved.since
            Cr.topLater, Cr.topBuilding, Cr.topSig, Cr.API.ahstest, Cr.topBuilds, A.priceVersion, Cr.lastEvent = saved.later, saved.building, saved.sig, saved.api, saved.builds, saved.pv, saved.ev
            if not res[1] then error(res[2], 0) end
            return res[2] >= 1 and res[2] <= 3, string.format("%d Aufbauten in 20 s", res[2]), "1 bis 3 Aufbauten"
        end)
        end)
        B(function()
        Chk("T277", "J", "GoldSentinelSync 2 und GoldSentinelTest 2 (T-N1 bis T-N4, T-GT1, T-GT2) und gebündelte Scan-Preise im Netz", function()
            local S, GSS, GT = A.Sync, _G.GoldSentinelSync, _G.GoldSentinelTest
            if not (GSS and S.ep) then return false, "GoldSentinelSync fehlt" end
            local NAME = "Testa Beispiel"
            local sa = { send = GSS.api.send, g = GSS.api.inGuild, r = GSS.api.inRaid, p = GSS.api.inGroup, queue = GSS.queue, nq = GSS.netQueue,
                sim = A.Simulated, book = GSS.book[NAME], consent = GT and GT.Setting and GT.Setting("consent"), lastNet = S.lastNetScan,
                sending = S.sendingScanTime, en = A.db.sync.enabled }
            local res = { pcall(function()
                local out = {}
                -- N1 / GT1
                out[#out + 1] = tostring(GSS.VERSION == 2) .. "/" .. tostring(GT and GT.version == 2)
                -- N2: gemerkter Name steht in AHSentinelDB.gsSync.book
                GSS.Learn(NAME, "whisper", 2)
                out[#out + 1] = tostring(type(A.db.gsSync) == "table" and type(A.db.gsSync.book) == "table" and A.db.gsSync.book[NAME] ~= nil)
                -- N3: net = false und scope "guild" -> keine WHISPER; ohne net = false (Kontrolle) -> Netz
                GSS.api.send = function() return true end
                GSS.api.inGuild, GSS.api.inRaid, GSS.api.inGroup = function() return true end, function() return false end, function() return false end
                GSS.queue, GSS.netQueue = {}, {}
                A.Simulated = function() return false end
                S.ep:Send("x", { net = false }); S.ep:Send("x", { scope = "guild" })
                local w1 = #GSS.netQueue
                S.ep:Send("x")
                local w2 = #GSS.netQueue
                out[#out + 1] = w1 .. "/" .. tostring(w2 > 0)
                -- gebündelte Scan-Preise: 1000 Items -> Gilde alles, Netz höchstens NET_SCAN_MSGS Nachrichten je Ziel, Rest nicht
                GSS.queue, GSS.netQueue = {}, {}
                A.db.sync.enabled = true
                S.lastNetScan, S.sendingScanTime = nil, nil
                local data = {}
                for i = 1, 1000 do data[900000 + i] = { price = 1000 + i, qty = i } end
                S:BroadcastScan(time(), data)
                local guildMsgs, netMsgs = #GSS.queue, #GSS.netQueue
                local targets = 0
                for _, e in pairs(GSS.book) do if (e.v or 0) >= 2 then targets = targets + 1 end end
                local perTarget = netMsgs / math.max(1, math.min(GSS.NET_FANOUT, targets))
                out[#out + 1] = tostring(guildMsgs > S.NET_SCAN_MSGS and netMsgs > 0 and perTarget <= S.NET_SCAN_MSGS)
                -- zweiter Scan gleich danach: nichts ins Netz (höchstens alle 30 Min.)
                GSS.netQueue = {}
                S.sendingScanTime = nil
                S:BroadcastScan(time() + 1, data)
                out[#out + 1] = tostring(#GSS.netQueue == 0)
                -- N4: NETZ-Zeile ohne Spielernamen
                local lines = table.concat(GSS.DiagLines(), "\n")
                out[#out + 1] = tostring(lines:find("NETZ", 1, true) ~= nil and lines:find(NAME, 1, true) == nil)
                -- GT2: ohne Zustimmung bleibt der Ausgang leer
                local ok2 = true
                if GT and GT.SetSetting and GT.Outbox then
                    GT.SetSetting("consent", false)
                    local sh = A.db.gsTest and A.db.gsTest.share
                    local n0 = sh and sh.outbox and #sh.outbox or 0
                    GT.Outbox(A.db, { kind = "error", addon = "AHSentinel", version = A.version, errors = { { wo = "Test", msg = "Testfehler", count = 1 } } })
                    sh = A.db.gsTest and A.db.gsTest.share
                    ok2 = (sh and sh.outbox and #sh.outbox or 0) == n0
                end
                out[#out + 1] = tostring(ok2)
                return table.concat(out, " ")
            end) }
            GSS.api.send, GSS.api.inGuild, GSS.api.inRaid, GSS.api.inGroup, GSS.queue, GSS.netQueue = sa.send, sa.g, sa.r, sa.p, sa.queue, sa.nq
            A.Simulated, GSS.book[NAME], S.lastNetScan, S.sendingScanTime, A.db.sync.enabled = sa.sim, sa.book, sa.lastNet, sa.sending, sa.en
            if GT and GT.SetSetting then GT.SetSetting("consent", sa.consent) end
            if not res[1] then error(res[2], 0) end
            local want = "true/true true 0/true true true true true"
            return res[2] == want, res[2], want
        end)
        end)
        B(function()
        Chk("T278", "J", "A4 Sniper: Angebot 2c bei Max 1c -> kein Treffer (Ware und Einzelangebot); SetTarget(…, 1, 1, 1) = 1c je Stück", function()
            local Sn = A.Sniper
            local db = A.db.sniper
            local key = "i:" .. FAKE_ID
            local saved = { result = Sn.result, t = db.targets[key], getT = Sn.GetTarget }
            local res = { pcall(function()
                local ok = Sn:SetTarget(tostring(FAKE_ID), 1, 1, 1)
                local t = db.targets[key]
                local setOK = ok and t and t.maxPrice == 1 and t.qty == 1 and t.budget == 1
                local tt = { key = key, itemID = FAKE_ID, maxPrice = 1, qty = 1, budget = 1, bought = 0, spent = 0 }
                Sn.GetTarget = function(_, k) if k == key then return tt end return saved.getT(Sn, k) end
                Sn.result = { key = key, itemID = FAKE_ID, commodity = true, time = GetTime(), listings = {
                    { qty = 5, price = 2, pass = true } } }
                local p1 = Sn:PlanNext()
                Sn.result = { key = key, itemID = FAKE_ID, commodity = false, time = GetTime(), listings = {
                    { qty = 1, price = 2, buyout = 2, pass = true, auctionID = 1 } } }
                local p2 = Sn:PlanNext()
                -- Kontrolle: 1c bei Max 1c ist ein Treffer
                Sn.result = { key = key, itemID = FAKE_ID, commodity = true, time = GetTime(), listings = {
                    { qty = 1, price = 1, pass = true } } }
                local p3 = Sn:PlanNext()
                return setOK, p1 == nil, p2 == nil, p3 ~= nil
            end) }
            Sn.result, db.targets[key], Sn.GetTarget = saved.result, saved.t, saved.getT
            if not res[1] then error(res[2], 0) end
            local got = string.format("%s/%s/%s/%s", tostring(res[2]), tostring(res[3]), tostring(res[4]), tostring(res[5]))
            return got == "true/true/true/true", got, "true/true/true/true"
        end)
        end)
        B(function()
        Chk("T279", "J", "A1 Tagesbeginn ohne time(tabelle): DayStart(0), DayStart(jetzt), DayStart(nil) sind Zahlen; Gold/Std. mit Zeitraum 'alles' ohne Fehler", function()
            local Act = A.Activity
            local a, b, c = A:DayStart(0), A:DayStart(time()), A:DayStart(nil)
            local ok = type(a) == "number" and type(b) == "number" and type(c) == "number" and b <= time() and time() - b < 86400 + 3600
            local okR = pcall(Act.Report, Act, "all")
            local okS = pcall(Act.Seconds, Act, 0)
            return ok and okR and okS, string.format("%s / %s / %s, Report %s, Seconds %s", tostring(a), tostring(b), tostring(c), tostring(okR), tostring(okS)),
                "Zahlen, kein Fehler"
        end)
        end)
        B(function()
        -- T280 (Befund 22:25 Punkt 3): Zwischenspeicher liefert dieselben Zeilen; mit Shift andere (Shift-Teil)
        Chk("T280", "H", "Tooltip-Zwischenspeicher: gleiche Zeilen, Shift getrennt", function()
            local TT = A.Tooltip
            if not (TT and TT.AddLinesCached) then return "SKIP", "kein Zwischenspeicher" end
            local function Lines(shift)
                local o = setmetatable({ IsShiftKeyDown = function() return shift end }, { __index = A.apiOverride })
                local saved = A.apiOverride
                A.apiOverride = o
                local out = {}
                local tip = { AddLine = function(_, a) out[#out + 1] = tostring(a) end,
                    AddDoubleLine = function(_, a, b) out[#out + 1] = tostring(a) .. "=" .. tostring(b) end }
                local ok, err = pcall(TT.AddLinesCached, TT, tip, LINEN)
                A.apiOverride = saved
                if not ok then error(err, 0) end
                return table.concat(out, "\n"), #out
            end
            TT.testCache = true
            TT:InvalidateCache()
            local h0 = TT.cacheHits or 0
            local okA, a1, n1 = pcall(Lines, false)
            local okB, a2 = pcall(Lines, false)
            local okC, s1, n3 = pcall(Lines, true)
            local hits = (TT.cacheHits or 0) - h0
            TT.testCache = nil
            TT:InvalidateCache()
            if not (okA and okB and okC) then error(tostring(not okA and a1 or not okB and a2 or s1), 0) end
            local ok = a1 == a2 and hits >= 1 and (n3 >= n1)
            return ok, string.format("%d Zeilen, wieder %s, Treffer %d, mit Shift %d Zeilen", n1, a1 == a2 and "gleich" or "ANDERS", hits, n3),
                "gleich, Treffer >= 1, Shift >= ohne"
        end)
        end)
        B(function()
        -- T281 (Wunsch 22:15): /ahs testroutine stop - Abbruch stellt alles her (geprüft an einer Kopie des Ablaufs)
        Chk("T281", "I", "Testroutine abbrechen (stop/Abbrechen)", function()
            if not (TR.Stop and TR.Abort) then return false, "TR:Stop fehlt", "vorhanden" end
            local okSlash = false
            local slash = SlashCmdList and (SlashCmdList.AHSENTINEL or SlashCmdList.AHAP or SlashCmdList.AHANALYZERPRO)
            okSlash = slash ~= nil
            return okSlash and type(TR.Stop) == "function", okSlash and "Befehl und Knopf vorhanden (Abbruch selbst: Nachbildung s61)" or "Slash fehlt",
                "vorhanden"
        end)
        end)
        B(function()
        -- T282 (Protokoll 10.11.: WERT "echt 1", +7800 %): Forever-Verkauf - echter Stückpreis = Gesamt (Feld 4) / Menge,
        -- nicht Feld 5 (= Menge). Sandbox: eigene leere Buchungsliste, danach die echte zurück (Pfad ledger.entries).
        Chk("T282", "J", "Vorhersage gegen Verkauf: Forever-Stückpreis aus Feld 4", function()
            local Le = A.Ledger
            if not (Le and Le.CompareSale and Le.SaleGross) then return false, "fehlt", "vorhanden" end
            local db = A.db.ledger
            local real = db.entries
            local t = time()
            db.entries = { { kind = "deposit", itemID = 10940, t = t - 3600, pred = 79 } }
            local e = { kind = "sale", itemID = 10940, t = t, qty = 95, amount = 8360,
                inv = { price = 95, bid = 8360, qtyField = true } }
            local ok, dev = pcall(Le.CompareSale, Le, e, true)
            local classic = Le:SaleGross({ amount = 5, inv = { price = 500 } })
            db.entries = real
            if not ok then error(dev, 0) end
            local okDev = type(dev) == "number" and math.abs(dev - (79 - 88) / 88) < 0.001
            return okDev and classic == 500, string.format("Abweichung %s %%, Klassik-Gesamt %s",
                dev and string.format("%.1f", dev * 100) or "nil", tostring(classic)), "-10.2 % (79 gegen 88), Klassik 500"
        end)
        end)
        B(function()
        -- T283 (Anweisung Gesamtwert, T-GW1 bis T-GW5): Zeile "N in den Taschen:" nur stapelbar ab 2 Stück, Betrag =
        -- A:RealValue(id, N); Zwischenspeicher kennt die Anzahl. Anzahl über A.apiOverride (Seam), nichts Echtes verändert.
        Chk("T283", "K", "Tooltip: Gesamtwert aller Stücke in den Taschen", function()
            local TT = A.Tooltip
            if not (TT and TT.AddBagTotal) then return false, "fehlt", "vorhanden" end
            local saved, savedStack = A.apiOverride, TT.IsStackable
            local function run(count, stackable)
                A.apiOverride = setmetatable({ GetItemCount = function() return count end }, { __index = saved })
                TT.IsStackable = function() return stackable end
                local out = {}
                local tip = { AddLine = function(_, a) out[#out + 1] = tostring(a) end,
                    AddDoubleLine = function(_, a, b) out[#out + 1] = tostring(a) .. "=" .. tostring(b) end }
                local ok, err = pcall(TT.AddBagTotal, TT, tip, LINEN)
                A.apiOverride, TT.IsStackable = saved, savedStack
                if not ok then error(err, 0) end
                return out[1]
            end
            local gw1 = run(386, true)
            local want = A:FormatMoney((A:RealValue(LINEN, 386)))
            local gw2 = run(1, true)
            local gw3 = run(2, false)
            local k1, k2
            A.apiOverride = setmetatable({ GetItemCount = function() return 5 end }, { __index = saved })
            k1 = TT:CacheKey(LINEN)
            A.apiOverride = setmetatable({ GetItemCount = function() return 6 end }, { __index = saved })
            k2 = TT:CacheKey(LINEN)
            A.apiOverride = saved
            local ok = gw1 ~= nil and gw1:find("386", 1, true) and gw1:find(want, 1, true) and gw2 == nil and gw3 == nil and k1 ~= k2
            return ok and true or false, string.format("386: %s · 1 Stück: %s · nicht stapelbar: %s · Schlüssel je Anzahl %s",
                tostring(gw1), gw2 and "Zeile" or "keine", gw3 and "Zeile" or "keine", k1 ~= k2 and "verschieden" or "GLEICH"),
                "Zeile mit RealValue(id, 386), sonst keine, Schlüssel verschieden"
        end)
        end)
        B(function()
        -- T284 (Befund E1-E3): Einstellen-Diagnose - Blizzards Aufruf nachgehakt, Fehlertext des Spiels gefunden
        Chk("T284", "J", "Einstellen: Blizzard-Aufruf mitschreiben, echte Fehlermeldung", function()
            local Se = A.Seller
            if not (Se and Se.ErrorText and Se.LogPost) then return false, "fehlt", "vorhanden" end
            local E = A:Global("Enum")
            local code = E and E.AuctionHouseError and E.AuctionHouseError.DatabaseError
            if not code then return "SKIP", "kein Enum.AuctionHouseError (altes Auktionshaus)" end
            local text, name = Se:ErrorText(code)
            local hooked = Se.postHooked and true or false
            return text ~= nil and hooked, string.format("Fehler %s = %s (%s), Blizzard-Aufruf nachgehakt: %s", tostring(code),
                tostring(text), tostring(name), hooked and "ja" or "nein"), "Text des Spiels, nachgehakt"
        end)
        end)
        B(function()
        -- T285 (Anweisung Angebot und Absatz, T-AB1 bis T-AB4, T-AB6): Warteschlange Q, Absatz S, Wartezeit W, Einstellungen N.
        -- Nur Seams auf eigene Funktionen (A.SellQueue, A.GetLiquidity ...), nichts Echtes verändert.
        Chk("T285", "J", "Angebot und Absatz: Warteschlange, Absatz, Einstellungen, kaum", function()
            local Le, Se, TT = A.Ledger, A.Seller, A.Tooltip
            local saved = { pr = Le.PostRate, force = A.forceForever, rp = A.RealPrice, vp = A.GetVendorPrice, fpp = A.FeePerPiece,
                liq = A.GetLiquidity, sq = A.SellQueue, dd = A.DefaultDuration, prices = Se.prices[FAKE_ID], own = A.OwnSalesPerDay }
            local res = { pcall(function()
                A.forceForever = true
                Le.PostRate = function() return 0, 0 end
                A.OwnSalesPerDay = function() return nil end
                A.RealPrice = function() return 200, { value = 200, source = "market" } end      -- Netto 1s 90c
                A.GetVendorPrice = function() return 60 end
                A.FeePerPiece = function(self, id, unit) return math.floor(unit * 0.05 + 0.5) end
                A.DefaultDuration = function() return 24 end
                local function run(q, perDay, scans)
                    A.SellQueue = function() return q, "scan" end
                    A.GetLiquidity = function() return { perDay = perDay, scans = scans or 10, span = 5 } end
                    A:ResetOutlook()
                    local v, _, info, vendorWins = A:RealValue(FAKE_ID, 1)
                    return v, info and info.outlook, vendorWins
                end
                local ab1, o1, vw1 = run(150, 5)
                local ab2, o2 = run(3, 10)
                local ab3, o3 = run(40, 0, 6)
                -- T-AB4: Lockangebote und eigene zählen nicht (echte A.SellQueue mit einer Angebotsliste)
                A.SellQueue = saved.sq
                Se.prices[FAKE_ID] = { stamp = time(), listings = {
                    { price = 50, qty = 1, bait = true }, { price = 150, qty = 10, own = true, ownQty = 10 },
                    { price = 180, qty = 7 }, { price = 250, qty = 99 } } }
                local q4 = A:SellQueue(FAKE_ID, 200)
                return ab1, o1, vw1, ab2, o2, ab3, o3, q4
            end) }
            Le.PostRate, A.forceForever, A.RealPrice, A.GetVendorPrice, A.FeePerPiece = saved.pr, saved.force, saved.rp, saved.vp, saved.fpp
            A.GetLiquidity, A.SellQueue, A.DefaultDuration, Se.prices[FAKE_ID], A.OwnSalesPerDay = saved.liq, saved.sq, saved.dd, saved.prices, saved.own
            A:ResetOutlook()
            if not res[1] then error(res[2], 0) end
            local ab1, o1, vw1, ab2, o2, ab3, o3, q4 = unpack(res, 2, 9)
            local ok1 = o1 and o1.listings > 1 and o1.rare and vw1 and ab1 < 119        -- Entzaubern 1s 19c gewinnt
            local ok2 = o2 and o2.listings == 1 and ab2 == 190
            local ok3 = o3 and o3.rare
            local ok4 = q4 == 7
            -- T-AB6: ohne Shift keine Begründung, mit Shift eine
            local n0, n1 = 0, 0
            local tip0 = { AddLine = function() n0 = n0 + 1 end, AddDoubleLine = function() n0 = n0 + 1 end }
            local tip1 = { AddLine = function() n1 = n1 + 1 end, AddDoubleLine = function() n1 = n1 + 1 end }
            pcall(TT.AddBlock2, TT, tip0, LINEN, false)
            pcall(TT.AddBlock2, TT, tip1, LINEN, true)
            local text = TT:OutlookText(LINEN)
            local ok6 = (text == nil and n1 >= n0) or (text ~= nil and n1 > n0)
            return (ok1 and ok2 and ok3 and ok4 and ok6) and true or false,
                string.format("AB1 %s (N %s, kaum %s) · AB2 %s (N %s) · AB3 kaum %s · AB4 Q %s · AB6 %d/%d Zeilen",
                    tostring(ab1), tostring(o1 and o1.listings), tostring(o1 and o1.rare), tostring(ab2), tostring(o2 and o2.listings),
                    tostring(o3 and o3.rare), tostring(q4), n0, n1),
                "AB1 Händler 60 < Entzaubern 119, N > 1, kaum · AB2 190, N 1 · AB3 kaum · AB4 Q 7 · AB6 Shift mehr Zeilen"
        end)
        end)
        B(function()
        -- T286 (Anweisung Buchhaltung mit Lager, T-BL1 bis T-BL3): Ergebnis mit Lager = Kasse + Lagerwert-Änderung.
        -- Sandbox: eigene Lagerstand-Tabelle (Pfad ledger.stock), danach die echte zurück; StockValue als Seam.
        Chk("T286", "J", "Buchhaltung: Kasse und Ergebnis mit Lager, Einzahl/Mehrzahl", function()
            local Le, db = A.Ledger, A.db.ledger
            local saved = { stock = db.stock, sv = Le.StockValue }
            local res = { pcall(function()
                local key = (A.Chars:Key())
                local today = A:DayStart(time())
                db.stock = {}
                local none = Le:StockChange("today")                                     -- T-BL2: kein Stand -> nil
                db.stock = { [today] = { [key] = { start = 1000 } } }                     -- Lager zu Beginn 10s
                Le.StockValue = function() return 15500 end                               -- Lager jetzt 1g 55s
                local change = Le:StockChange("today")
                return none, change
            end) }
            db.stock, Le.StockValue = saved.stock, saved.sv
            if not res[1] then error(res[2], 0) end
            local none, change = res[2], res[3]
            local kasse = 3592
            local result = change and (kasse + change)
            local one = string.format(L["%d Verkauf, AH-Anteil %s"], 1, "x")
            local two = string.format(L["%d Verkäufe, AH-Anteil %s"], 2, "x")
            local ok = none == nil and result == 18092 and one ~= two
            return ok, string.format("ohne Stand %s · Ergebnis %s · %s / %s", tostring(none), result and A:FormatMoney(result) or "nil", one, two),
                "ohne Stand nil · Ergebnis 1g 80s 92c · Einzahl und Mehrzahl verschieden"
        end)
        end)
        B(function()
        -- T287 (T-BL4): Preis nicht im letzten Scan -> Tooltip kennzeichnet ihn; Verkaufen <= Rechenwert
        Chk("T287", "K", "Tooltip: Preis nicht im Scan gekennzeichnet", function()
            local saved = A.PriceInfo
            local out = {}
            local okT, err = pcall(function()
                A.PriceInfo = function(self, id) return { value = 22, source = "market", inScan = false, median = 22 } end
                local tip = { AddLine = function(_, a) out[#out + 1] = tostring(a) end,
                    AddDoubleLine = function(_, a, b) out[#out + 1] = tostring(a) .. "=" .. tostring(b) end }
                A.Tooltip:AddLines(tip, LINEN)
            end)
            A.PriceInfo = saved
            if not okT then error(err, 0) end
            local text = table.concat(out, "\n")
            local cur = A:GetCurrent(LINEN)
            if not cur then return "SKIP", "kein Preis für Leinenstoff" end
            local marked = text:find("(" .. L["alt"] .. ")", 1, true) ~= nil
            return marked, marked and "Preis mit (alt)" or "ohne Kennzeichen", "(alt)"
        end)
        end)
        B(function()
        -- T288 (Befehlsliste beim Tippen, T-BL1/T-BL2/T-BL5/T-BL6): nur Logik, ohne ins Eingabefeld zu schreiben
        Chk("T288", "I", "Befehlsliste beim Tippen von /ahs: Filter, meistbenutzte oben, eingehakt", function()
            local H = A.CmdHint
            if not (H and H.List and H.Match) then return false, "fehlt", "vorhanden" end
            local savedStore = H.store
            local use = { protokoll = 3, scan = 1 }
            H.store = function() return use end
            local all = H:List("")
            local pro = H:List("pro")
            H.store = savedStore
            local box = _G.ChatFrame1EditBox or _G.ChatFrameEditBox
            local hooked = box and H.hooked and H.hooked[box] and true or false
            local ok = H:Match("/ahs") == "" and H:Match("/AHS pr") == "pr" and H:Match("/say hi") == nil
                and all[1] and all[1].run == "protokoll" and all[2] and all[2].run == "scan" and #pro >= 1 and pro[1].run == "protokoll"
            return (ok and (hooked or not box)) and true or false,
                string.format("%d Befehle, oben %s/%s, 'pro' -> %s, Eingabefeld eingehakt %s", #all, tostring(all[1] and all[1].run),
                    tostring(all[2] and all[2].run), tostring(pro[1] and pro[1].run), hooked and "ja" or "nein"),
                "protokoll/scan oben, 'pro' -> protokoll, eingehakt"
        end)
        end)
        B(function()
        -- T289 (Befund F1, T-AB7/T-AB8): S aus dem Markt, eigene Verkäufe nur als Untergrenze; selbst verkauft -> nie "kaum"
        Chk("T289", "J", "Absatz: Markt-S, eigene Verkäufe als Untergrenze, nie kaum bei eigenen Verkäufen", function()
            local saved = { liq = A.GetLiquidity, sq = A.SellQueue, dd = A.DefaultDuration, own = A.OwnSalesPerDay, rp = A.RealPrice }
            local res = { pcall(function()
                A.SellQueue = function() return 10886, "scan" end
                A.DefaultDuration = function() return 24 end
                A.RealPrice = function() return 80, { value = 80 } end
                A.OwnSalesPerDay = function() return 332 end
                A.GetLiquidity = function() return { perDay = 2000, scans = 10, span = 5 } end
                A:ResetOutlook()
                local v7 = A:SellOutlook(FAKE_ID, 1)
                A.GetLiquidity = function() return { scans = 1 } end
                A:ResetOutlook()
                local v8 = A:SellOutlook(FAKE_ID, 1)
                return v7, v8
            end) }
            A.GetLiquidity, A.SellQueue, A.DefaultDuration, A.OwnSalesPerDay, A.RealPrice = saved.liq, saved.sq, saved.dd, saved.own, saved.rp
            A:ResetOutlook()
            if not res[1] then error(res[2], 0) end
            local v7, v8 = res[2], res[3]
            local ok = v7 and v7.perDay == 2000 and not v7.rare and math.abs((v7.wait or 0) - 5.44) < 0.05 and v8 and not v8.rare
            return ok and true or false, string.format("AB7 S %s W %.1f kaum %s · AB8 kaum %s", tostring(v7 and v7.perDay), v7 and v7.wait or -1,
                tostring(v7 and v7.rare), tostring(v8 and v8.rare)), "AB7 S 2000 W 5.4 kein kaum · AB8 kein kaum"
        end)
        end)
        B(function()
        -- T290 (Befund F2, T-S1 bis T-S3): Einzelstücke ganze Silber, Waren Kupfer, Knopf "1 Silber"
        Chk("T290", "J", "Einstellen: Einzelstücke ganze Silber, Waren mit Kupfer", function()
            local Se = A.Seller
            if not (Se and Se.RoundPrice and Se.SilverOnly) then return false, "fehlt", "vorhanden" end
            local savedC, savedU = A.IsCommodityItem, A.db.seller.undercut
            local res = { pcall(function()
                A.db.seller.undercut = "copper"
                A.IsCommodityItem = function() return false end
                local s1 = Se:RoundPrice(FAKE_ID, 199)
                local u1 = Se:Undercut(200, FAKE_ID)
                local lbl = Se:UndercutLabel("copper", FAKE_ID)
                A.IsCommodityItem = function() return true end
                local s2 = Se:RoundPrice(FAKE_ID, 83)
                local u2 = Se:Undercut(84, FAKE_ID)
                return s1, u1, lbl, s2, u2
            end) }
            A.IsCommodityItem, A.db.seller.undercut = savedC, savedU
            if not res[1] then error(res[2], 0) end
            local s1, u1, lbl, s2, u2 = unpack(res, 2, 6)
            if A.AH_LEGACY then return "SKIP", "altes Auktionshaus: Kupfer erlaubt" end
            local ok = s1 == 100 and u1 == 100 and lbl == L["1 Silber"] and s2 == 83 and u2 == 83
            return ok, string.format("Einzelstück 199 -> %s, -1 Silber von 200 -> %s, Knopf %s · Ware 83 -> %s, 84 - 1 -> %s",
                tostring(s1), tostring(u1), tostring(lbl), tostring(s2), tostring(u2)), "100, 100, 1 Silber · 83, 83"
        end)
        end)
        B(function()
        -- T291 (Befund Absatz zu hoch, T-AB10/T-AB11): Deckel 20 % der Scan-Menge; eigene Quote geht vor
        Chk("T291", "J", "Absatz: Deckel bei überfüllten Items, eigene Quote zuerst", function()
            local saved = { liq = A.GetLiquidity, sq = A.SellQueue, dd = A.DefaultDuration, own = A.OwnSalesPerDay, rp = A.RealPrice,
                cur = A.GetCurrent, pr = A.Ledger.PostRate }
            local res = { pcall(function()
                A.SellQueue = function() return 222, "scan" end
                A.GetCurrent = function() return 200, 222, time() end
                A.DefaultDuration = function() return 24 end
                A.RealPrice = function() return 200, { value = 200 } end
                A.OwnSalesPerDay = function() return nil end
                A.GetLiquidity = function() return { perDay = 600, scans = 10, span = 5 } end
                A.Ledger.PostRate = function() return 0, 0 end
                A:ResetOutlook()
                local v10 = A:SellOutlook(FAKE_ID, 1)
                A.Ledger.PostRate = function() return 10, 9 end
                A:ResetOutlook()
                local v11 = A:SellOutlook(FAKE_ID, 1)
                return v10, v11
            end) }
            A.GetLiquidity, A.SellQueue, A.DefaultDuration, A.OwnSalesPerDay, A.RealPrice, A.GetCurrent, A.Ledger.PostRate =
                saved.liq, saved.sq, saved.dd, saved.own, saved.rp, saved.cur, saved.pr
            A:ResetOutlook()
            if not res[1] then error(res[2], 0) end
            local v10, v11 = res[2], res[3]
            local ok = v10 and math.abs(v10.perDay - 44.4) < 0.05 and v10.listings == 6 and not v10.rare
                and v11 and v11.listingsSource == "own" and math.abs(v11.listings - 10 / 9) < 0.01
            return ok and true or false, string.format("AB10 S %.1f N %s · AB11 N %.2f (%s)", v10 and v10.perDay or -1, tostring(v10 and v10.listings),
                v11 and v11.listings or -1, tostring(v11 and v11.listingsSource)), "AB10 S 44.4 N 6 · AB11 N 1.11 (own)"
        end)
        end)
        B(function()
        -- T292 (Befund Heute tun H1, Wunsch Laufzeit D1): Waren im modernen AH = eine Auktion; Standard-Laufzeit Stufe 1
        Chk("T292", "J", "Waren eine Auktion (modernes AH), Standard-Laufzeit", function()
            local savedC = A.IsCommodityItem
            local n, src = A:AuctionSize(LINEN, 349)
            local step = A:StandardDurationStep()
            local stored = A.db.settings.defaultDuration
            if A.AH_LEGACY then return "SKIP", "altes Auktionshaus: Stapel" end
            local ok = n >= 349 and (src == "whole" or src == "learned" or src == "own") and (stored ~= nil or step == 1)
            return ok, string.format("Leinenstoff 349 Stück -> %d je Auktion (%s), Laufzeit-Stufe %d", n, tostring(src), step),
                ">= 349 (eine Auktion), Stufe 1 ohne eigene Einstellung"
        end)
        end)
        B(function()
        -- T293 (Anweisung Entzauber-Chancen Forever, T-DC1 bis T-DC4 und T-DC5): Startwerte je Version
        Chk("T293", "J", "Entzauber-Chancen grüner Items: Forever-Leitfaden, Era Tabelle", function()
            local D = A.Disenchant
            local saved = A.forceForever
            local function ch(key)
                local p = D:PriorForKey(key)
                if not p then return "?" end
                local t = {}
                for _, e in ipairs(p) do t[#t + 1] = string.format("%.0f", e[2] * 100) end
                return table.concat(t, "/")
            end
            local res = { pcall(function()
                A.forceForever = true
                local f3a, f3w, f1a = ch("2:3:a"), ch("2:3:w"), ch("2:1:a")
                A.forceForever = false
                local e3a = ch("2:3:a")
                return f3a, f3w, f1a, e3a
            end) }
            A.forceForever = saved
            if not res[1] then error(res[2], 0) end
            local f3a, f3w, f1a, e3a = unpack(res, 2, 5)
            -- T-DC5: 0,75 × 5 × 81 + 0,20 × 1,5 × 386 + 0,05 × 1 × 108 = 424,95c brutto
            local dc5 = 0.75 * 5 * 81 + 0.20 * 1.5 * 386 + 0.05 * 1 * 108
            local ok = f3a == "75/20/5" and f3w == "20/75/5" and f1a == "80/20" and e3a == "75/15/10" and math.abs(dc5 - 424.95) < 0.001
            return ok, string.format("Forever Rüstung %s, Waffe %s, bis 15 %s · Era %s · Umhang %.2fc", f3a, f3w, f1a, e3a, dc5),
                "75/20/5, 20/75/5, 80/20 · Era 75/15/10 · 424.95c"
        end)
        end)
        B(function()
        -- T294 (Befund Gesamtwert fehlt, T-GF3/T-GF4/T-GF5): stapelbar über A:StackSize (nicht das globale GetItemInfo),
        -- RealValue-Fehler -> Ersatzwert und Protokoll GESAMTWERT
        Chk("T294", "K", "Tooltip-Gesamtwert: erscheint, Ersatzwert bei Fehler", function()
            local TT = A.Tooltip
            local saved = { ov = A.apiOverride, rv = A.RealValue, logged = TT.totalLogged }
            local function line(count, broken)
                A.apiOverride = setmetatable({ GetItemCount = function() return count end }, { __index = saved.ov })
                if broken then
                    A.RealValue = function(self, id, n) if (n or 1) > 1 then error("Testfehler") end return saved.rv(self, id, n) end
                end
                local out
                local tip = { AddLine = function() end, AddDoubleLine = function(_, a, b) out = tostring(a) .. "=" .. tostring(b) end }
                local ok, err = pcall(TT.AddBagTotal, TT, tip, LINEN)
                A.apiOverride, A.RealValue = saved.ov, saved.rv
                if not ok then error(err, 0) end
                return out
            end
            TT.totalLogged = { [LINEN] = true }                 -- Protokoll in der Testroutine nicht schreiben
            local gf3 = line(239)
            local gf4 = line(1)
            local gf5 = line(110, true)
            TT.totalLogged = saved.logged
            local one = A:RealValue(LINEN, 1)
            local ok = gf3 ~= nil and gf4 == nil and gf5 ~= nil and one ~= nil and gf5:find(A:FormatMoney(one * 110), 1, true) ~= nil
            return ok, string.format("239: %s · 1: %s · Fehler: %s", tostring(gf3), tostring(gf4), tostring(gf5)),
                "Zeile · keine · Ersatz Verkaufen × 110"
        end)
        end)
        B(function()
        -- T295 (Nachprüfung 08:40 Punkt 1, T-D5a-c): Bewertung mit 24 Std., wenn das gleich viel kostet; sonst Standard
        Chk("T295", "J", "Laufzeit für die Bewertung: 24 Std. bei gleicher Einzahlung, sonst Standard-Laufzeit", function()
            local saved = { ld = A.ListingDeposit, force = A.forceForever, dd = A.db.settings.defaultDuration }
            local res = { pcall(function()
                A.forceForever, A.db.settings.defaultDuration = true, 1
                A.ListingDeposit = function() return 100 end                         -- Mindesteinzahlung: 2 und 24 Std. gleich
                local a = A:EvalHours(FAKE_ID, 1)
                A.ListingDeposit = function(self, id, q, h) return (h or 24) >= 24 and 500 or 100 end    -- 24 Std. teurer
                local b = A:EvalHours(FAKE_ID, 1)
                A.forceForever = false
                local c = A:EvalHours(FAKE_ID, 1)
                return a, b, c
            end) }
            A.ListingDeposit, A.forceForever, A.db.settings.defaultDuration = saved.ld, saved.force, saved.dd
            if not res[1] then error(res[2], 0) end
            local a, b, c = res[2], res[3], res[4]
            return a == 24 and b == 2 and c == 24, string.format("gleich teuer %s Std. · 24 Std. teurer %s Std. · Era %s Std.", tostring(a), tostring(b), tostring(c)),
                "24 · 2 · 24"
        end)
        end)
        B(function()
        -- T296 (Befund Sofortkauf K3, T-SK3/T-SK4): Mindestgebot ohne Bieter = Startgebot, mit Bieter +5 %; Gebotsfeld nur,
        -- wenn ein Gebot billiger als Sofortkauf möglich ist
        Chk("T296", "J", "Mindestgebot ohne/mit Bieter, Gebotsfeld nur wenn sinnvoll", function()
            local B2 = A.Buy
            local sk3 = { bid = 900, buyout = 900 }
            local sk4 = { bid = 900, buyout = 2000, hasBidder = true }
            local m3, m4 = B2:MinBid(sk3), B2:MinBid(sk4)
            local c3, c4 = B2:CanBid(sk3), B2:CanBid(sk4)
            return m3 == 900 and m4 == 945 and c3 == false and c4 == true,
                string.format("ohne Bieter %s (Feld %s) · mit Bieter %s (Feld %s)", tostring(m3), tostring(c3), tostring(m4), tostring(c4)),
                "900 (kein Feld) · 945 (Feld)"
        end)
        end)
        B(function()
        -- T297 (Befund Buchhaltung Menge und Gebühren, T-BM1 bis T-BM5). Sandbox: eigene Buchungsliste (ledger.entries),
        -- die echte kommt danach zurück; Stapelgrösse als Seam auf die eigene Funktion A:StackSize.
        Chk("T297", "J", "Buchhaltung: Menge nie = Preis, Erstattung ohne Einzahlung wird gedeckt", function()
            local Le, db = A.Ledger, A.db.ledger
            local saved = { entries = db.entries, ss = A.StackSize, mv = A.GetMarketValue, f6 = db.fixL6 }
            local res = { pcall(function()
                A.StackSize = function(self, id) return id == 10940 and 20 or 1 end
                A.GetMarketValue = function(self, id) return id == 10940 and 80 or 800 end
                local q1 = Le:QtyFromField5(FAKE_ID, 800, 800, 800)          -- T-BM1 Ausrüstung: Feld 5 = Preis
                local q2 = Le:QtyFromField5(10940, 20, 1580, 1580)           -- T-BM2 20 Staub
                db.entries = { { kind = "sale", itemID = FAKE_ID, qty = 22000, amount = 22000, t = time() - 100 } }
                db.fixL6 = nil
                Le:FixL6()
                local q3, old3 = db.entries[1].qty, db.entries[1].old5 and db.entries[1].old5.qty
                db.entries[1].qty = 5                                      -- zweiter Lauf ändert nichts
                Le:FixL6()
                local again = db.entries[1].qty
                -- T-BM4/5: Erstattung 3238 ohne Einzahlung -> Einzahlung 3238 nachbuchen; mit Einzahlung -> nichts
                local add1 = Le:CoverRefunds({ { kind = "sale", itemID = FAKE_ID, refund = 3238, t = 1000, qty = 1 } })
                local add2 = Le:CoverRefunds({ { kind = "deposit", itemID = FAKE_ID, amount = 3238, t = 900 },
                    { kind = "sale", itemID = FAKE_ID, refund = 3238, t = 1000, qty = 1 } })
                return q1, q2, q3, old3, again, #add1, add1[1] and add1[1].amount, #add2
            end) }
            db.entries, A.StackSize, A.GetMarketValue, db.fixL6 = saved.entries, saved.ss, saved.mv, saved.f6
            if not res[1] then error(res[2], 0) end
            local q1, q2, q3, old3, again, n1, a1, n2 = unpack(res, 2, 9)
            local ok = q1 == 1 and q2 == 20 and q3 == 1 and old3 == 22000 and again == 5 and n1 == 1 and a1 == 3238 and n2 == 0
            return ok, string.format("BM1 %s · BM2 %s · BM3 %s (alt %s, 2. Lauf %s) · BM5 %d nachgebucht (%s) · BM4 %d",
                tostring(q1), tostring(q2), tostring(q3), tostring(old3), tostring(again), n1, tostring(a1), n2),
                "BM1 1 · BM2 20 · BM3 1 (alt 22000, 2. Lauf unverändert) · BM5 1 (3238) · BM4 0"
        end)
        end)
        B(function()
        -- T298 (Befund Entzauber-Ergebnisse zählen, Z5 b-f / T-DZ2, T-DZ5): Fenster-Weg, Makro-Weg (nur Taschen-Differenz),
        -- Beute 2× zählt +2, fremdes Material abgelehnt (nicht gezählt, im Verlauf markiert), nicht eindeutig -> verpasst.
        -- Sandbox: eigene Tabellen für deStats/deLog/deCount (Pfade deStats, deLog), echte danach zurück; Seams nur auf
        -- eigene Funktionen (D.Prior, D.ReadLoot, D.BagDECounts).
        Chk("T298", "J", "Entzaubern zählen: Fenster, Makro über Taschen, 2× Staub, abgelehnt, nicht eindeutig", function()
            local D = A.Disenchant
            local db = A.db
            local saved = { st = db.deStats, log = db.deLog, cnt = db.deCount, prior = D.Prior, read = D.ReadLoot, bags = D.BagDECounts,
                un = D.unshared, last = D.lastRecordAt, tc = D.testCount }
            local ev = D.evt:GetScript("OnEvent")
            local res = { pcall(function()
                db.deStats, db.deLog, db.deCount, D.testCount = {}, {}, nil, true
                local realPrior = saved.prior
                D.Prior = function(self, id) if id == FAKE_ID then return D:PriorForKey("2:1:a"), "2:1:a" end return realPrior(self, id) end
                local loot = { { 10940, 2 } }
                D.ReadLoot = function() return loot end
                -- (b) Fenster
                D:NoteCandidate(FAKE_ID)
                ev(D.evt, "UNIT_SPELLCAST_SUCCEEDED", "player", "x", 13262)
                ev(D.evt, "LOOT_READY")
                local st = db.deStats["2:1:a"]
                local nB, totB = st and st.n or 0, st and st.mats[10940] and st.mats[10940].total or 0
                -- (c) Makro: kein Kandidat, nur Taschen-Differenz
                D.BagDECounts = function() return { [FAKE_ID] = 2 } end
                ev(D.evt, "UNIT_SPELLCAST_START", "player", "x", 13262)
                ev(D.evt, "UNIT_SPELLCAST_SUCCEEDED", "player", "x", 13262)
                ev(D.evt, "LOOT_READY")
                D.BagDECounts = function() return { [FAKE_ID] = 1 } end
                D:ResolveBags()
                local nC = db.deStats["2:1:a"].n
                -- (e) Material ausserhalb der Gruppe (Splitter bei "bis 15") -> abgelehnt (Beute ohne Material: E6, T300)
                loot = { { 10978, 1 } }
                D:NoteCandidate(FAKE_ID)
                ev(D.evt, "UNIT_SPELLCAST_SUCCEEDED", "player", "x", 13262)
                ev(D.evt, "LOOT_READY")
                local nE = db.deStats["2:1:a"].n
                local rej = db.deLog[#db.deLog] and db.deLog[#db.deLog].rejected
                -- (f) eindeutig / nicht eindeutig
                local f1 = D:BagDiff({ [FAKE_ID] = 2 }, { [FAKE_ID] = 1 })
                local f2, why2 = D:BagDiff({ [FAKE_ID] = 1, [FAKE_ID + 1] = 1 }, {})
                local c = D:CountToday()
                return nB, totB, nC, nE, rej, f1, f2, why2, c.counted
            end) }
            db.deStats, db.deLog, db.deCount, D.Prior, D.ReadLoot, D.BagDECounts = saved.st, saved.log, saved.cnt, saved.prior, saved.read, saved.bags
            D.unshared, D.lastRecordAt, D.testCount = saved.un, saved.last, saved.tc
            if not res[1] then error(res[2], 0) end
            local nB, totB, nC, nE, rej, f1, f2, why2, counted = unpack(res, 2, 10)
            local ok = nB == 1 and totB == 2 and nC == 2 and nE == 2 and rej ~= nil and f1 == FAKE_ID and f2 == nil and why2 == "nicht eindeutig" and counted == 2
            return ok, string.format("Fenster n %d (Staub %d) · Makro n %d · fremd n %d (%s) · eindeutig %s · zwei verschiedene %s · gezählt %s",
                nB, totB, nC, nE, tostring(rej), tostring(f1 == FAKE_ID), tostring(why2), tostring(counted)),
                "1 (2) · 2 · 2 (abgelehnt) · ja · nicht eindeutig · 2"
        end)
        end)
        B(function()
        -- T299 (Befund Optionen überlagert O2, T-OÜ1): Optionen öffnen -> keine zwei Elemente überlagern sich
        Chk("T299", "K", "Optionen: keine Zeile, kein Knopf überlagert einen anderen", function()
            local U = A.UIC and A.UIC.UICheck
            if not (U and U.ControlsOverlapNothing and A.UI.ShowOptions) then return false, "fehlt", "vorhanden" end
            local was = A.UI.options and A.UI.options:IsShown()
            A.UI:ShowOptions()
            local w = A.UI.options
            local probs, tested = U.ControlsOverlapNothing(w)
            if not was and w then w:Hide() end
            if tested == 0 then return "SKIP", "Lage der Elemente nicht messbar" end
            return #probs == 0 and tested > 0, #probs == 0 and string.format("%d Paare geprüft", tested) or table.concat(probs, "; "):sub(1, 300),
                "keine Überlagerung"
        end)
        end)
        B(function()
        -- T300 (Anweisung Testroutine Entzaubern E1, E5, E6, E8, E10, E12): Kette und Rechnung mit festen Zahlen.
        -- Sandbox: Ersatztabellen deStats/deLog/deShared/deCount, echte danach zurück (Fingerabdruck im Bericht).
        Chk("T300", "J", "Entzaubern: LOOT_READY+OPENED einmal, anderer Zauber/fremde Beute nichts, Lernrechnung, geteilt, Wert", function()
            local D = A.Disenchant
            local db = A.db
            local saved = { st = db.deStats, log = db.deLog, sh = db.deShared, cnt = db.deCount, prior = D.Prior, read = D.ReadLoot,
                mp = D.MatPrice, un = D.unshared, last = D.lastRecordAt, tc = D.testCount }
            local ev = D.evt:GetScript("OnEvent")
            local res = { pcall(function()
                db.deStats, db.deLog, db.deShared, db.deCount, D.testCount = {}, {}, {}, nil, true
                local realPrior = saved.prior
                local P = D:PriorForKey("2:1:a")
                D.Prior = function(self, id) if id == FAKE_ID then return P, "2:1:a" end return realPrior(self, id) end
                local loot = { { P[1][1], 1 } }
                D.ReadLoot = function() return loot end
                -- E1: LOOT_READY und LOOT_OPENED mit derselben Beute -> genau +1
                D:NoteCandidate(FAKE_ID)
                ev(D.evt, "UNIT_SPELLCAST_SUCCEEDED", "player", "x", 13262)
                ev(D.evt, "LOOT_READY"); ev(D.evt, "LOOT_OPENED")
                local e1 = db.deStats["2:1:a"] and db.deStats["2:1:a"].n or 0
                -- E5: anderer Zauber -> nichts, kein Rest
                D:NoteCandidate(FAKE_ID)
                ev(D.evt, "UNIT_SPELLCAST_SUCCEEDED", "player", "x", 2575)
                ev(D.evt, "LOOT_READY")
                local e5 = db.deStats["2:1:a"].n
                -- E6: Entzaubern ohne Beute, dann Mob-Beute (kein Material) -> nicht gezählt, nicht abgelehnt
                D:NoteCandidate(FAKE_ID)
                ev(D.evt, "UNIT_SPELLCAST_SUCCEEDED", "player", "x", 13262)
                loot = { { 2589, 3 } }
                ev(D.evt, "LOOT_READY")
                local e6, e6log = db.deStats["2:1:a"].n, #db.deLog
                -- E8: Lernrechnung W = PRIOR_WEIGHT, 9× Staub (15 Stück), 1× Essenz
                local W = D.PRIOR_WEIGHT
                local y = D:Blend(P, 10, { [P[1][1]] = { times = 9, total = 15 }, [P[2][1]] = { times = 1, total = 1 } })
                local wantC = (P[1][2] * W + 9) / (W + 10)
                local wantA = (P[1][2] * W * P[1][3] + 15) / (P[1][2] * W + 9)
                local sum = 0
                for _, e in ipairs(y) do sum = sum + e[2] end
                local e8 = math.abs(y[1][2] - wantC) < 1e-9 and math.abs(y[1][3] - wantA) < 1e-9 and math.abs(sum - 1) < 0.001
                -- E10: gleicher Absender zweimal -> ersetzt, nicht addiert
                local Enc = A.Sync and A.Sync.Enc
                local nA, nB = 0, 0
                if Enc then
                    local payload = "2.1.a~" .. Enc(4) .. "~" .. Enc(P[1][1]) .. "," .. Enc(4) .. "," .. Enc(6)
                    D:HandleShared("AHSFremder-AHSRealm", time(), payload)
                    nA = select(2, D:Combined("2:1:a"))
                    D:HandleShared("AHSFremder-AHSRealm", time(), payload)
                    nB = select(2, D:Combined("2:1:a"))
                end
                -- E12: Wert mit festen Preisen
                D.MatPrice = function(self, id) if id == P[1][1] then return 100 elseif id == P[2][1] then return 300 end return nil end
                db.deStats, db.deShared = {}, {}
                local v = D:GetValue(FAKE_ID)
                local want = 0
                for _, e in ipairs(P) do
                    local pr = (e[1] == P[1][1] and 100) or (e[1] == P[2][1] and 300) or nil
                    if pr then want = want + e[2] * e[3] * pr end
                end
                return e1, e5, e6, e6log, e8, nA, nB, v, math.floor(want + 0.5)
            end) }
            db.deStats, db.deLog, db.deShared, db.deCount = saved.st, saved.log, saved.sh, saved.cnt
            D.Prior, D.ReadLoot, D.MatPrice, D.unshared, D.lastRecordAt, D.testCount = saved.prior, saved.read, saved.mp, saved.un, saved.last, saved.tc
            if not res[1] then error(res[2], 0) end
            local e1, e5, e6, e6log, e8, nA, nB, v, want = unpack(res, 2, 10)
            local ok = e1 == 1 and e5 == 1 and e6 == 1 and e6log == 1 and e8 and nA == nB and v == want
            return ok, string.format("E1 %d · E5 %d · E6 %d (Verlauf %d) · E8 %s · E10 %d/%d · E12 %s = %s",
                e1, e5, e6, e6log, tostring(e8), nA, nB, tostring(v), tostring(want)), "1 · 1 · 1 (1) · true · gleich · gleich"
        end)
        end)
        B(function()
        -- T301 (T-TE1/T-TE2): Bericht "Entzaubern (echte Daten)" - leer ohne Fehler; 70× grün 26-30 Rüstung mit 9 Splittern
        -- -> Gruppe gezeigt, Splitter gegen 5 % als auffällig markiert. Nur Ersatztabellen.
        Chk("T301", "J", "Bericht Entzaubern (echte Daten): leer, Gruppe mit Abweichung markiert", function()
            local D, db = A.Disenchant, A.db
            local saved = { st = db.deStats, log = db.deLog, sh = db.deShared, cnt = db.deCount }
            local res = { pcall(function()
                db.deStats, db.deLog, db.deShared, db.deCount = {}, {}, {}, nil
                local empty = table.concat(TR:DEReport(), "\n")
                local P = D:PriorForKey("2:4:a")
                local shard = P[3] and P[3][1]
                db.deStats = { ["2:4:a"] = { n = 70, mats = { [P[1][1]] = { times = 58, total = 73 }, [P[2][1]] = { times = 9, total = 13 },
                    [shard or 0] = { times = 9, total = 9 } } } }
                local full = table.concat(TR:DEReport(), "\n")
                return empty, full, shard
            end) }
            db.deStats, db.deLog, db.deShared, db.deCount = saved.st, saved.log, saved.sh, saved.cnt
            if not res[1] then error(res[2], 0) end
            local empty, full, shard = res[2], res[3], res[4]
            local markedShard = shard and full:find(tostring(shard) .. ": 9/70", 1, true) and full:find("auffällig", 1, true)
            local ok = empty:find("keine eigenen Ergebnisse", 1, true) ~= nil and markedShard and full:find("26-30", 1, true) ~= nil
            return ok and true or false, ok and "leer ok · Splitter 9/70 auffällig" or full:sub(1, 300), "leer ok · Splitter 9/70 auffällig"
        end)
        end)
        B(function()
        -- T302 (Nachprüfung 0.65.69 T-N1/T-N2): Statistik mit abgelehntem Eintrag; Zurücksetzen mit Sicherung und
        -- Wiederherstellen - nur auf Ersatztabellen (Schutz der echten Entzauber-Daten)
        Chk("T302", "J", "Entzaubern: abgelehnt getrennt gezählt, Zurücksetzen sichert, Wiederherstellen exakt", function()
            local D, DW, db = A.Disenchant, A.DEWindow, A.db
            local saved = { st = db.deStats, sh = db.deShared, log = db.deLog, bk = db.deBackup }
            local res = { pcall(function()
                local now = time()
                db.deLog = { { t = now, itemID = 1, loot = { { 10940, 1 } } }, { t = now, itemID = 2, loot = { { 10940, 2 } } },
                    { t = now, itemID = 3, loot = { { 10978, 1 } }, rejected = "nicht in der Tabelle der Gruppe" } }
                local st = DW and DW.Stats and DW:Stats(now) or {}
                db.deStats = { ["2:1:a"] = { n = 7, mats = { [10940] = { times = 7, total = 9 } } } }
                db.deShared, db.deBackup = {}, nil
                local before = TR.DEPrint(db)
                D:Reset()
                local afterReset, backups = TR.DEPrint(db), #(db.deBackup or {})
                local okR = D:RestoreBackup()
                local afterRestore = TR.DEPrint(db)
                return st.total, st.rejected, st.mats and st.mats[10940], st.mats and st.mats[10978], before, afterReset, backups, okR, afterRestore
            end) }
            db.deStats, db.deShared, db.deLog, db.deBackup = saved.st, saved.sh, saved.log, saved.bk
            if not res[1] then error(res[2], 0) end
            local total, rej, dust, shard, before, afterReset, backups, okR, afterRestore = unpack(res, 2, 10)
            local ok = total == 3 and rej == 1 and dust == 3 and shard == 1 and afterReset ~= before and backups == 1 and okR and afterRestore == before
            return ok, string.format("gesamt %s (abgelehnt %s), Staub %s, Splitter %s · Sicherung %s · zurück %s", tostring(total), tostring(rej),
                tostring(dust), tostring(shard), tostring(backups), afterRestore == before and "exakt" or "ANDERS"),
                "gesamt 3 (abgelehnt 1), Staub 3, Splitter 1 · Sicherung 1 · zurück exakt"
        end)
        end)
        B(function()
        Chk("T152", "J", "pcall um alle AH-Aufrufe", function()
            local realAH = A.AH
            local W = A.Watcher
            local wsaved = Copy(A.db.watcher)              -- ganzer Wächter-Speicher (Sandbox-Befund "watcher.…")
            local function Fail() error("AHS-Test T152", 0) end
            local proxy = setmetatable({ SendBrowseQuery = Fail, SendSearchQuery = Fail, GetBrowseResults = Fail,
                GetItemSearchResultInfo = Fail, SendSellSearchQuery = Fail, IsThrottledMessageSystemReady = function() return true end },
                { __index = realAH })
            local errs = {}
            local function try(name, f, ...)
                local ok, e = pcall(f, ...)
                if not ok then errs[#errs + 1] = name .. ": " .. tostring(e):sub(1, 60) end
            end
            A.AH = proxy
            local lines = Capture(function()
                try("Einkauf", A.Buy.Search, A.Buy, { searchString = "AHS-Test" }, true)
                try("Sniper", A.Sniper.Search, A.Sniper, "i:" .. LINEN)
                try("Preisprüfung", A.Seller.CheckPrice, A.Seller, LINEN, true)
                try("Wächter", W.StartRound, W)
            end)
            A.AH = realAH
            W.round = nil
            Replace(A.db.watcher, wsaved)
            if A.Seller.queue then for i = #A.Seller.queue, 1, -1 do if A.Seller.queue[i] == LINEN then table.remove(A.Seller.queue, i) end end end
            self:ClearTestErrors()
            return #errs == 0, #errs == 0 and (#lines .. " Meldungen, kein Lua-Fehler") or table.concat(errs, " | "), "kein Lua-Fehler"
        end)
        end)
    end

    -- ---------------- P. Prognose (Stufe 1: Prognose-Journal, Testfälle T-PG1–T-PG9) ----------------
    -- Teil A nur mit Ersatztabellen (Fc.testStore) - die echten Tabellen werden nicht berührt (T307 vergleicht)
    if want(part, "p") then B(function()
        local Fc = A.Forecast
        if not Fc then return Skp("T303", "P", "Prognose-Journal", "Forecast.lua nicht geladen") end
        -- eigene Funktion als Seam (feste Vorhersage), immer zurücksetzen
        local function WithStore(fn)
            local savedPred, savedBuy = Fc.PostPrediction, Fc.BuyPrediction
            local Le = A.Ledger
            local savedLoot = Le and Le.DisenchantLootValue
            Fc.testStore = {}
            Fc.evalCache = nil
            Fc:Store()
            local res = { pcall(fn, Fc.testStore) }
            Fc.testStore, Fc.evalCache = nil, nil
            Fc.PostPrediction, Fc.BuyPrediction = savedPred, savedBuy
            if Le then Le.DisenchantLootValue = savedLoot end
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        local function Find(store, kind, id)
            for i, s in ipairs(store.f.list) do
                local e = Fc:Decode(s)
                if e and e.kind == kind and e.id == id then return e, i end
            end
        end
        Chk("T303", "P", "T-PG1–5 Einstellen (Verkaufen-Reiter + Blizzard-Fenster), Verkauf FIFO, Teilverkauf, Ablauf, Abbruch, unbekannt", function()
            return WithStore(function(store)
                Fc.PostPrediction = function() return { p = 0.8, W = 10, N = 1, Q = 200, qs = "scan", S = 20, ss = "m", u = 0, net = 76 } end
                local now = time()
                Fc:OnPosted({ itemID = 10940, qty = 20, unitPrice = 80, duration = 3, auctions = 1, t = now - 10 * 3600 })       -- T-PG1
                Fc:OnPosted({ itemID = 10938, qty = 20, unitPrice = 50, duration = 3, t = now - 30 * 3600, external = true })   -- T-PG2/4
                Fc:OnPosted({ itemID = 10998, qty = 1, unitPrice = 900, duration = 3, t = now - 30 * 3600 })                    -- T-PG3
                Fc:OnPosted({ itemID = 11083, qty = 1, unitPrice = 300, duration = 3, t = now - 3600 })                         -- T-PG5
                Fc:OnPosted({ itemID = 11082, qty = 1, unitPrice = 300, duration = 3, t = now - 9 * 86400 })                    -- unbekannt
                local n1 = #store.f.list
                Fc:OnSale(10940, 20, 1600, 80, now - 5 * 3600)                    -- verkauft nach 5 Std.
                Fc:OnSale(10938, 10, 500, 25, now - 28 * 3600)                    -- 10 von 20
                Fc:OnCancel(11083, now)
                Fc:Close(now)                                                       -- ohne Briefkasten: nur "unbekannt" (9 Tage)
                local unk = Find(store, "P", 11082)
                local exBefore = Find(store, "P", 10998)
                Fc:NoteMail(now)                                                    -- Briefkasten gelesen -> Ablauf/Teilverkauf
                local s1, ext, ex, ca = Find(store, "P", 10940), Find(store, "P", 10938), Find(store, "P", 10998), Find(store, "P", 11083)
                local R = Fc:Eval(now)
                local a = R.all
                local ratio = (s1.sh or 0) / (s1.W or 1)
                local ok = n1 == 5 and s1.r == "s" and s1.sq == 20 and s1.sh == 5 and math.abs(ratio - 0.5) < 1e-9 and s1.p == 0.8 and s1.d == 24
                    and ext.x == 1 and ext.r == "t" and ext.sq == 10 and Fc:PostOutcome(ext) == 0.5
                    and exBefore.r == nil and ex.r == "e" and Fc:PostOutcome(ex) == 0 and ca.r == "c" and Fc:PostOutcome(ca) == 0
                    and unk.r == "u" and a.n == 4 and a.c == 1 and (R.unknown or 0) == 1 and math.abs(a.sy - 1.5) < 1e-9
                return ok, string.format("Einträge %d · Staub %s/%s nach %s Std. (Verhältnis %.2f) · Blizzard-Fenster x=%s %s %s/20 · Ablauf %s→%s y=%s · Abbruch %s y=%s · 9 Tage %s · Fälle %d, verkauft Σ %.1f, abgebrochen %d, unbekannt %d",
                    n1, tostring(s1.r), tostring(s1.sq), tostring(s1.sh), ratio, tostring(ext.x), tostring(ext.r), tostring(ext.sq),
                    tostring(exBefore.r or "offen"), tostring(ex.r), tostring(Fc:PostOutcome(ex)), tostring(ca.r), tostring(Fc:PostOutcome(ca)),
                    tostring(unk.r), a.n, a.sy, a.c, R.unknown or 0),
                    "Einträge 5 · Staub s/20 nach 5 Std. (Verhältnis 0.50) · Blizzard-Fenster x=1 t 10/20 · Ablauf offen→e y=0 · Abbruch c y=0 · 9 Tage u · Fälle 4, verkauft Σ 1.5, abgebrochen 1, unbekannt 1"
            end)
        end)
        Chk("T304", "P", "T-PG6 Kauf 70 Entzauber-Teile, Beute 87 % des Kaufpreises -> Verlust; Flip mit Gewinn; offener Kauf", function()
            return WithStore(function(store)
                local Le = A.Ledger
                Fc.BuyPrediction = function(_, id) if id == 990000301 then return "d", 1300 end return "e", 150 end
                Le.DisenchantLootValue = function() return 1220, true end      -- 87 % von 1403 (9g 82s / 70)
                local now = time()
                Fc:OnBuy(990000301, 70, 98200, "buy", now - 7200)
                for _ = 1, 70 do Fc:OnDisenchant(990000301, { { 10940, 1 } }, { ev = 1300, dk = "2:3:a", src = "e", n = 0 }) end
                Fc:OnBuy(990000302, 5, 500, "sniper", now - 7200)
                Fc:OnSale(990000302, 5, 1000, 50, now - 3600)
                Fc:OnBuy(990000303, 3, 300, "watcher", now - 600)
                local buy = Find(store, "B", 990000301)
                local R = Fc:Eval(now)
                local d, e, de = R.B.d, R.B.e, R.D["2:3:a"]
                local okR, lines = pcall(Fc.Report, Fc)
                local txt = okR and table.concat(lines, "\n") or ""
                local ok = buy.r == "c" and buy.rq == 70 and buy.rv == 85400 and d and d.n == 1 and d.win == 0 and d.profit == 85400 - 1403 * 70
                    and e and e.n == 1 and e.win == 1 and e.profit == 450 and de and de.n == 70 and de.loss == 70 and de.lossN == 70
                    and R.openBuys == 1 and txt:find("Entzaubern: zu wenig Daten (1)", 1, true) ~= nil
                if not (okR and txt:find("Entzaubern: zu wenig Daten (1)", 1, true)) then ok = false end
                return ok, (okR and "" or ("Bericht FEHLER " .. tostring(lines):sub(1, 120) .. " · ")) .. string.format("Kauf %s %s/70, Erlös %s · Entzaubern %s Käufe, mit Gewinn %s · Flip %s, Gewinn %s · Entzauberungen %s, Verlust %s/%s · offen %d",
                    tostring(buy.r), tostring(buy.rq), tostring(buy.rv), tostring(d and d.n), tostring(d and d.win), tostring(e and e.n),
                    tostring(e and e.profit), tostring(de and de.n), tostring(de and de.loss), tostring(de and de.lossN), R.openBuys),
                    "Kauf c 70/70, Erlös 85400 · Entzaubern 1 Käufe, mit Gewinn 0 · Flip 1, Gewinn 450 · Entzauberungen 70, Verlust 70/70 · offen 1"
            end)
        end)
        Chk("T305", "P", "T-PG7 Brier und Zuverlässigkeit mit festen Zahlen (0,8/0,8/0,2 -> 1/0/0 = 0,24)", function()
            return WithStore(function(store)
                local now = time()
                for i, c in ipairs({ { 0.8, 1 }, { 0.8, 0 }, { 0.2, 0 } }) do
                    store.f.list[#store.f.list + 1] = Fc:Encode("P", { t = now - 86400, id = 990000310 + i, q = 1, pr = 100, d = 24, p = c[1], W = 10,
                        g = "misc", r = c[2] == 1 and "s" or "e", sq = c[2], sh = c[2] == 1 and 5 or nil, sp = c[2] == 1 and 100 or nil })
                end
                local R = Fc:Eval(now)
                local a = R.all
                local brier = Fc:Brier(a)
                local c5, c2 = a.cls[5], a.cls[2]
                local lines = Fc:Report()
                local few = table.concat(lines, "\n"):find("zu wenig Daten (3)", 1, true) ~= nil
                local ok = a.n == 3 and brier and math.abs(brier - 0.24) < 1e-9 and c5 and c5[1] == 2 and math.abs(c5[2] - 1.6) < 1e-9 and c5[3] == 1
                    and c2 and c2[1] == 1 and c2[3] == 0 and a.hit == 2 and few
                return ok, string.format("Brier %.3f · Klasse 80–100 %%: %s Fälle, Σp %.1f, verkauft %s · 20–40 %%: %s Fälle · richtig %d/3 · Bericht \"zu wenig Daten (3)\" %s",
                    brier or -1, tostring(c5 and c5[1]), c5 and c5[2] or 0, tostring(c5 and c5[3]), tostring(c2 and c2[1]), a.hit, few and "ja" or "nein"),
                    "Brier 0.240 · Klasse 80–100 %: 2 Fälle, Σp 1.6, verkauft 1 · 20–40 %: 1 Fälle · richtig 2/3 · Bericht \"zu wenig Daten (3)\" ja"
            end)
        end)
        Chk("T306", "P", "T-PG8 Ringpuffer 3000, älter als 60 Tage in die Zusammenfassung, Speicher < 300 KB, keine Namen", function()
            return WithStore(function(store)
                local now = time()
                store.f.list[1] = Fc:Encode("P", { t = now - 61 * 86400, id = 990000320, q = 1, pr = 100, d = 24, p = 0.5, r = "s", sq = 1, g = "misc", v = "1" })
                for i = 1, 3004 do
                    Fc:Add("P", { t = now - (3004 - i) * 1400, id = 10940 + (i % 50), q = 20, a = 1, pr = 1234, rel = 0.983, d = 24, Q = 1234, qs = "s",
                        S = 293.8, ss = "c", u = 1, p = 0.354, W = 12.53, N = 3, net = 1150, g = "de", r = "s", sq = 20, sh = 11.2, sp = 1230 })
                    if i % 500 == 0 then A:Pause() end
                end
                local f, st = store.f, store.st
                local fj, sj = Fc:Size()
                local archived = (st.P.misc and st.P.misc.n or 0) + (st.P.de and st.P.de.n or 0)
                local clean = true
                for _, s in ipairs(f.list) do if not s:match("^[PBD];[%w%.;:%-]*$") then clean = false; break end end
                local R = Fc:Eval(now)
                local ok = #f.list == 3000 and archived == 5 and R.all.n == 3005 and (fj + sj) < 300 * 1024 and clean
                return ok, string.format("Einträge %d · in der Zusammenfassung %d · Fälle gesamt %d · Speicher %d KB · nur Zahlen/Kürzel %s",
                    #f.list, archived, R.all.n, math.ceil((fj + sj) / 1024), clean and "ja" or "nein"),
                    "Einträge 3000 · in der Zusammenfassung 5 · Fälle gesamt 3005 · Speicher < 300 KB · nur Zahlen/Kürzel ja"
            end)
        end)
        Chk("T307", "P", "T-PG9 Teil B: Bericht Prognose-Güte aus echten Daten, nur lesen (echte Tabellen unverändert)", function()
            local db = A.db
            local function Snap()
                local f, st, h = db.forecast, db.forecastStats, db.forecastHours
                local n = f and f.list and #f.list or -1
                local last = f and f.list and f.list[n] or ""
                local hs = 0
                for _ in pairs(h or {}) do hs = hs + 1 end
                return string.format("%d|%s|%s|%d|%s", n, last, tostring(f and f.mail), hs, tostring(st and st.dropped))
            end
            local before = Snap()
            local okR, lines, fields = pcall(Fc.Report, Fc)
            pcall(Fc.TooltipLine, Fc, 10940)
            local after = Snap()
            local txt = okR and table.concat(lines, "\n") or tostring(lines)
            local ok = okR and before == after and txt:find("Prognose-Güte", 1, true) ~= nil and fields and fields.prognose_speicher_kb ~= nil
            return ok, string.format("Bericht %s (%d Zeilen) · echte Tabellen %s · Speicher %s KB", okR and "da" or ("FEHLER " .. txt:sub(1, 80)),
                okR and #lines or 0, before == after and "unverändert" or "GEÄNDERT", tostring(fields and fields.prognose_speicher_kb)),
                "Bericht da · echte Tabellen unverändert"
        end)
    end) end

    -- ---------------- V. Vollscan mit Einzelauktionen (T-VS1–T-VS7) ----------------
    -- nur Ersatztabellen (VS.testDB, Fc.testStore) und eigene Seams; ReplicateItems wird nie aufgerufen
    if want(part, "v") then B(function()
        local VS, Fc = A.FullScan, A.Forecast
        if not VS then return Skp("T308", "V", "Vollscan", "Vollscan.lua nicht geladen") end
        local function WithDB(fn)
            local saved = { api = VS.API, led = VS.LedgerEntries, com = A.IsCommodityItem }
            VS.testDB = { v = 1, ladder = {}, sigs = {}, sold = {}, m1b = {}, m1c = {}, m1d = {}, own = { gone = 0, sold = 0, checks = {} } }
            if Fc then Fc.testStore = {}; Fc:Store() end
            local res = { pcall(fn, VS.testDB) }
            VS.testDB = nil
            if Fc then Fc.testStore, Fc.evalCache = nil, nil end
            VS.API, VS.LedgerEntries, A.IsCommodityItem = saved.api, saved.led, saved.com
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        local function It(list)       -- { {Menge, Stückpreis, Stufe}, ... } -> Item-Arrays wie beim Lesen
            local it = { q = {}, b = {} }
            for k, e in ipairs(list) do it.q[k] = e[1]; it.b[k] = e[1] * e[2] * 8 + (e[3] or 3) end
            return it
        end
        Chk("T308", "V", "T-VS1 Verdichtung: Mindestpreis, Menge, Warteschlange Q zum Preis, Lockangebot zählt nicht", function()
            return WithDB(function()
                A.IsCommodityItem = function() return true end
                local s = VS:Digest(10940, It({ { 20, 80 }, { 20, 80 }, { 40, 90 } }))
                local q85, q90, q70 = VS:LadderQueue(s, 85), VS:LadderQueue(s, 90), VS:LadderQueue(s, 70)
                local b = VS:Digest(10940, It({ { 1, 10 }, { 20, 80 }, { 40, 90 } }))
                local st = s.st[3]
                local ok = s.min == 80 and s.qty == 80 and s.auc == 3 and q85 == 40 and q90 == 80 and q70 == 0 and st == 80
                    and b.min == 80 and b.qty == 60 and b.bait == 1
                return ok, string.format("Mindestpreis %d, Menge %d, Auktionen %d, Q(85c) %d, Q(90c) %d, Q(70c) %d, Stufe 3 %d · mit Lockangebot: Mindestpreis %d, Menge %d, Lockangebote %d",
                    s.min, s.qty, s.auc, q85, q90, q70, st, b.min, b.qty, b.bait),
                    "Mindestpreis 80, Menge 80, Auktionen 3, Q(85c) 40, Q(90c) 80, Q(70c) 0, Stufe 3 80 · mit Lockangebot: Mindestpreis 80, Menge 60, Lockangebote 1"
            end)
        end)
        Chk("T309", "V", "T-VS2–4 Verfolgung: vorzeitig weg (lange Restzeit), abgelaufen (kurze), neu, gleiche Signatur mehrfach", function()
            return WithDB(function(st)
                local prev = VS.EncodeSigs(VS.Sigs(It({ { 20, 80, 3 }, { 20, 80, 3 }, { 5, 100, 1 } })))
                local e1, x1, n1 = VS:Compare(prev, It({ { 20, 80, 3 }, { 7, 100, 4 } }), 1800)
                -- nach 3 Std.: Stufe 3 (mind. 2 Std.) gilt nicht mehr sicher als "vorzeitig" -> abgelaufen
                local e2, x2 = VS:Compare(VS.EncodeSigs(VS.Sigs(It({ { 20, 80, 3 } }))), It({}), 3 * 3600)
                local now = time()
                for i = 1, 3 do VS:UpdateSold(st, 990000330, 24, 0, 86400, now - (3 - i) * 86400) end
                st.sold[990000330] = st.sold[990000330]:gsub(";(%d+);(%d+);(%d+);", function(n, f, l) return ";" .. n .. ";" .. (now - 4 * 86400) .. ";" .. l .. ";" end, 1)
                local m, x, days = VS:MeasuredRate(990000330)
                local ok = e1 == 20 and x1 == 5 and n1 == 1 and e2 == 0 and x2 == 20 and m and math.abs(m - 24) < 0.01 and days == 4
                return ok, string.format("vorzeitig weg %d, abgelaufen %d, neu %d · nach 3 Std.: vorzeitig %d, abgelaufen %d · Absatz gemessen %s/Tag (%s Tage)",
                    e1, x1, n1, e2, x2, m and string.format("%.1f", m) or "-", tostring(days)),
                    "vorzeitig weg 20, abgelaufen 5, neu 1 · nach 3 Std.: vorzeitig 0, abgelaufen 20 · Absatz gemessen 24.0/Tag (4 Tage)"
            end)
        end)
        Chk("T361", "V", "T-W2 Ware 1000 Stück zu 80c in A, 950 zu 80c in B (Teilkauf) -> weg 50, nicht 1000", function()
            return WithDB(function()
                A.IsCommodityItem = function() return true end
                local prev = VS.EncodeSigs(VS.Sigs(It({ { 1000, 80, 4 }, { 200, 95, 4 } })))
                local e1 = VS:Compare(prev, It({ { 950, 80, 4 }, { 150, 95, 4 } }), 1800, 990000500)
                -- Neueinstellung zum gleichen Preis rechnet gegen; teurere Stufe (95c > 80c + 2 %) zählt nicht
                local e2 = VS:Compare(prev, It({ { 950, 80, 4 }, { 100, 80, 4 }, { 200, 95, 4 } }), 1800, 990000500)
                A.IsCommodityItem = function() return false end
                local e3 = VS:Compare(VS.EncodeSigs(VS.Sigs(It({ { 1, 5000, 4 } }))), It({}), 1800, 990000501)
                local ok = e1 == 50 and e2 == 0 and e3 == 1
                return ok, string.format("Teilkauf weg %d · mit Neueinstellung %d · Ausrüstung (Signatur) %d", e1, e2, e3), "50 · 0 · 1"
            end)
        end)
        Chk("T362", "V", "T-W2 Hochrechnen erst ab 6 Std. Abdeckung, Plausibilitätsgrenze 2 × Ø-Menge", function()
            return WithDB(function(st)
                local now = time()
                local x1 = VS:UpdateSold(st, 990000502, 50, 0, 23 * 60, now - 5 * 3600)
                local short = x1.rate == nil
                for i = 1, 14 do VS:UpdateSold(st, 990000502, 50, 0, 23 * 60, now - 5 * 3600 + i * 1380) end
                local x2 = VS:DecodeSold(st.sold[990000502])
                -- 15 Paare × 23 Min. = 5,75 Std. -> noch zu kurz; das 16. Paar erreicht 6 Std.
                local still = x2.rate == nil
                local x3 = VS:UpdateSold(st, 990000502, 50, 0, 23 * 60, now, 5000)
                local rate = x3.rate
                local xb = VS:UpdateSold(st, 990000503, 100000, 0, 7 * 3600, now, 1000)
                local ok = short and still and rate and math.abs(rate - 800 * 86400 / (16 * 1380)) < 1 and xb.rate == nil and xb.bad == 1
                return ok, string.format("nach 23 Min. %s · nach 5,75 Std. %s · nach 6,1 Std. %s/Tag · 100000 in 7 Std. bei Ø 1000: Rate %s, unplausibel %d",
                    short and "zu kurz" or "Rate", still and "zu kurz" or "Rate", rate and string.format("%.0f", rate) or "-", tostring(xb.rate), xb.bad or 0),
                    "zu kurz · zu kurz · ~3130/Tag · Rate nil, unplausibel 1"
            end)
        end)
        Chk("T310", "V", "T-VS5 Lesen in Portionen: 30'000 Einträge, kein Frame über 8 ms, 0-basierter Index", function()
            return WithDB(function()
                local N = 30000
                local fake = {
                    GetReplicateItemInfo = function(i)
                        if i < 0 or i >= N then return nil end
                        return nil, 0, 1 + i % 20, 1, true, 1, 0, 0, 0, (1 + i % 20) * (50 + i % 7), 0, false, nil, nil, nil, 0, 990000400 + i % 300, true
                    end,
                    GetReplicateItemTimeLeft = function(i) return 1 + i % 4 end,
                }
                local r = VS:NewRead(fake, N)
                local guard = 0
                while not VS:ReadPortion(r, VS.READ_BUDGET or 5) and guard < 100000 do guard = guard + 1 end
                local items = 0
                for _ in pairs(r.items) do items = items + 1 end
                local ok = r.count == N and items == 300 and r.maxMs <= 8 and r.base == 0
                return ok, string.format("%d gelesen, %d Items, %d Portionen, längste %.1f ms, Index ab %d", r.count, items, r.frames, r.maxMs, r.base),
                    "30000 gelesen, 300 Items, längste ≤ 8 ms, Index ab 0"
            end)
        end)
        Chk("T311", "V", "T-VS6 Gegenprobe: eigene verkaufte Auktion wird als vorzeitig weg gefunden", function()
            return WithDB(function(st)
                if not Fc then return "SKIP", "Forecast.lua fehlt" end
                local now = time()
                Fc:Add("P", { t = now - 3600, id = 990000331, q = 5, a = 1, pr = 100, d = 24, p = 0.5 })
                st.sigs[990000331] = (now - 1800) .. "|" .. VS.EncodeSigs(VS.Sigs(It({ { 5, 100, 4 }, { 3, 120, 4 } })))
                VS.LedgerEntries = function() return { { kind = "sale", itemID = 990000331, qty = 5, amount = 500, t = now - 600 } } end
                local items = { [990000331] = It({ { 3, 120, 4 } }) }
                local mem = { [990000331] = VS:Digest(990000331, items[990000331]) }
                local pairsN = VS:Track(st, items, mem, now)
                local x = VS:DecodeSold(st.sold[990000331])
                local ok = pairsN >= 1 and x and x.early == 5 and st.own.gone == 1 and st.own.sold == 1 and #st.own.checks == 0
                return ok, string.format("Paare %d · vorzeitig weg %s Stück · eigene vorzeitig weg %d, davon verkauft %d", pairsN, tostring(x and x.early),
                    st.own.gone, st.own.sold), "Paare 1 · vorzeitig weg 5 Stück · eigene vorzeitig weg 1, davon verkauft 1"
            end)
        end)
        Chk("T312", "V", "T-VS7 keine Namen im Speicher; Teil B: Bericht Vollscan aus echten Daten, nur lesen", function()
            local clean, why = true, nil
            WithDB(function(st)
                local items = { [990000332] = It({ { 2, 300, 2 }, { 4, 310, 3 } }) }
                VS:Track(st, items, { [990000332] = VS:Digest(990000332, items[990000332]) }, time())
                local function scan(t, path)
                    for k, v in pairs(t) do
                        if type(v) == "table" then scan(v, path .. "." .. tostring(k))
                        elseif type(v) == "string" and not v:match("^[%d;:,|%.%-]*$") then clean, why = false, path .. "." .. tostring(k) end
                    end
                end
                scan(st, "fullScan")
            end)
            local db = A.db
            local function Snap()
                local f = db.fullScan or {}
                local n = 0
                for _ in pairs(f.sigs or {}) do n = n + 1 end
                return string.format("%s|%d|%d", tostring(f.lastCall), n, #(f.m1d or {}))
            end
            local before = Snap()
            local okR, lines, fields = pcall(VS.Report, VS)
            local after = Snap()
            local txt = okR and table.concat(lines, "\n") or tostring(lines)
            local ok = clean and okR and before == after and txt:find("Vollscan", 1, true) ~= nil and not txt:find("Testa", 1, true)
            return ok, string.format("nur Zahlen %s · Bericht %s (%d Zeilen) · echte Tabellen %s", clean and "ja" or ("nein: " .. tostring(why)),
                okR and "da" or ("FEHLER " .. txt:sub(1, 80)), okR and #lines or 0, before == after and "unverändert" or "GEÄNDERT"),
                "nur Zahlen ja · Bericht da · echte Tabellen unverändert"
        end)
    end) end

    -- ---------------- L. Lern-Datenbank (Stufe 2, T-L1–T-L12) ----------------
    -- nur Ersatztabellen (Ln.testDB, Fc.testStore) und eigene Seams; echte Tabellen bleiben unverändert (T325)
    if want(part, "l") then B(function()
        local Ln, Fc = A.Learn, A.Forecast
        if not (Ln and Fc) then return Skp("T313", "L", "Lern-Datenbank", "Learn.lua/Forecast.lua nicht geladen") end
        local function WithLearn(fn)
            local saved = { mv = Ln.MarketValue, base = Ln.BaseValue, led = Ln.LedgerEntries, so = A.SellOutlook, ex = A.db.settings.learnExplore,
                pred = Fc.PostPrediction, grp = Fc.Group }
            Ln.testDB = { v = 1, corr = {}, shared = {}, warned = {}, rhythm = {}, exploreN = 0, lastCorr = 0, corrCases = 0, sharedCases = 0 }
            Fc.testStore, Fc.evalCache, Ln.itemCache = {}, nil, nil
            Fc:Store()
            local res = { pcall(fn, Ln.testDB, Fc.testStore) }
            Ln.testDB, Fc.testStore, Fc.evalCache, Ln.itemCache, Ln.forceOff = nil, nil, nil, nil, nil
            Ln.MarketValue, Ln.BaseValue, Ln.LedgerEntries, A.SellOutlook, Fc.PostPrediction, Fc.Group = saved.mv, saved.base, saved.led, saved.so, saved.pred, saved.grp
            A.db.settings.learnExplore = saved.ex
            Ln.rate = {}
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        -- n Fälle (sold verkauft, Rest halb abgelaufen, halb abgebrochen) für Item id, Preislage rel, Laufzeit 24 Std.
        local function Cases(store, id, rel, n, sold, g)
            local now = time()
            for i = 1, n do
                local r = i <= sold and "s" or (i % 2 == 0 and "e" or "c")
                store.f.list[#store.f.list + 1] = Fc:Encode("P", { t = now - 86400 - i * 60, id = id, q = 1, pr = 100, rel = rel, d = 24, p = 0.5, W = 10,
                    g = g or "misc", r = r, sq = r == "s" and 1 or 0, sh = r == "s" and 5 or nil, sp = r == "s" and 100 or nil })
            end
            Fc.evalCache, Ln.itemCache = nil, nil
        end
        Chk("T372", "L", "Punkt 3: 3000 Journal-Einträge, Minutenwechsel -> Shift-Tooltip (Gruppenzellen) < 2 ms, Auswertung im Hintergrund", function()
            return WithLearn(function(db, store)
                Cases(store, 990000502, 1.0, 3000, 1500)
                local R = Fc:Eval()                         -- Zwischenspeicher füllen
                Fc.evalCache.key = "alte Minute"            -- Minutenwechsel
                local t0 = clock and clock() or 0
                local cells = Ln:GroupCells("misc")
                local ms = clock and (clock() - t0) or 0
                local bg = Fc.evalRunning == true
                local ok = ms < 2 and next(cells) ~= nil and bg and R.total == 3000
                return ok, string.format("%.2f ms · Zellen %s · Neuberechnung im Hintergrund %s", ms, next(cells) and "da" or "leer", tostring(bg)),
                    "< 2 ms · Zellen da · Hintergrund true"
            end)
        end)
        Chk("T313", "L", "T-L1 Verkaufschance je Preislage mit Zensur (abgelaufen/abgebrochen zählen als nicht verkauft)", function()
            return WithLearn(function(db, store)
                Cases(store, 990000501, 1.0, 10, 6)
                local p, info = Ln:Chance(990000501, 1.0, 24, "misc")
                local ok = math.abs(p - 0.575) < 1e-6 and info.nItem == 10 and info.nGroup == 10 and info.src == "item" and info.hours == 5
                return ok, string.format("Chance %.3f · Item %d, Gruppe %d, Quelle %s, Dauer %s Std.", p, info.nItem, info.nGroup, info.src, tostring(info.hours)),
                    "Chance 0.575 · Item 10, Gruppe 10, Quelle item, Dauer 5 Std."
            end)
        end)
        Chk("T314", "L", "T-L2 Schrumpfen (0 eigene -> Gruppe, 100 eigene -> fast eigene) und geteilte Zähler mit Plausibilität", function()
            return WithLearn(function(db, store)
                Cases(store, 990000501, 1.0, 10, 6)
                Cases(store, 990000502, 1.0, 100, 90)
                local pZ = Ln:Chance(990000502, 1.0, 24, "misc")
                local pY, iY = Ln:Chance(990000503, 1.0, 24, "misc")
                local Enc = A.Sync and A.Sync.Enc
                local good = Enc and ("misc.3.24~" .. Enc(40) .. "~" .. Enc(10) .. ";gear2.1.8~" .. Enc(5) .. "~" .. Enc(5)) or ""
                local bad = Enc and ("misc.3.24~" .. Enc(10) .. "~" .. Enc(20) .. ";xyz.3.24~" .. Enc(5) .. "~" .. Enc(1) .. ";misc.9.24~" .. Enc(5) .. "~" .. Enc(1)) or ""
                local now = time()
                local t1 = Ln:HandleShared("Testa Beispiel", now, good, now)
                local t2 = Ln:HandleShared("Testa Beispiel", now, good, now + 10)        -- zweite Sendung in 60 s: abgelehnt
                local t3 = Ln:HandleShared("Testb Beispiel", now, bad, now)
                local ns = Ln:SharedCell("misc", "3:24")
                local named = false
                for k in pairs(db.shared) do if tostring(k):find("Testa", 1, true) then named = true end end
                local ok = math.abs(pZ - (90 + 10 * (101 / 120)) / 110) < 1e-6 and math.abs(pY - 101 / 120) < 1e-6 and iY.src == "group"
                    and t1 == 2 and t2 == 0 and t3 == 0 and ns == 40 and not named
                return ok, string.format("100 eigene %.3f (eigene Quote 0.900) · 0 eigene %.3f = Gruppe (%s) · geteilt angenommen %d / zweite Sendung %d / unplausibel %d · Zelle %d · Namen %s",
                    pZ, pY, iY.src, t1, t2, t3, ns, named and "JA" or "nein"),
                    "100 eigene 0.895 · 0 eigene 0.842 = Gruppe · geteilt 2 / 0 / 0 · Zelle 40 · Namen nein"
            end)
        end)
        Chk("T315", "L", "T-L3 Croston/SBA mit fester Reihe (alle 4 Tage 4 Stück -> 0,95/Tag), regelmässig -> nicht selten", function()
            return WithLearn(function()
                local rare, regular = {}, {}
                for i = 1, 30 do rare[i] = (i % 4 == 0) and 4 or 0; regular[i] = 2 end
                local r1, r2 = Ln:CrostonRate(rare), Ln:CrostonRate(regular)
                local now = time()
                local led = {}
                for i = 1, 7 do led[#led + 1] = { kind = "sale", itemID = 990000510, qty = 4, t = now - 30 * 86400 + i * 4 * 86400 - 3600 } end
                Ln.LedgerEntries = function() return led end
                local r3 = Ln:Croston(990000510, now)
                local ok = r1 and math.abs(r1 - 0.95) < 1e-9 and r2 == nil and r3 and math.abs(r3 - 0.95) < 1e-9
                return ok, string.format("selten %s/Tag · regelmässig %s · aus der Buchhaltung %s/Tag", r1 and string.format("%.2f", r1) or "-", tostring(r2),
                    r3 and string.format("%.2f", r3) or "-"), "selten 0.95/Tag · regelmässig nil · aus der Buchhaltung 0.95/Tag"
            end)
        end)
        Chk("T316", "L", "T-L4 Preisgrenzen aus festen Zahlen: Normal = höchste Preislage mit Chance >= 80 %, Max = Normal × 1,25, Minimum", function()
            return WithLearn(function(db, store)
                Cases(store, 990000520, 1.0, 30, 27)
                Cases(store, 990000520, 1.065, 30, 24)
                Cases(store, 990000520, 1.15, 30, 9)
                Ln.MarketValue = function() return 1000 end
                Ln.BaseValue = function() return 380 end
                local mn, normal, mx = Ln:Limits(990000520, 24)
                local wantMin = math.ceil(380 / (1 - A:CutPct()))
                Fc.Group = function(_, id) return id == 990000521 and "gear3" or "misc" end
                local few = (function() Cases(store, 990000521, 1.0, 3, 3, "gear3"); return Ln:Limits(990000521, 24) end)()
                local ok = normal == 1000 and mx == 1250 and mn == wantMin and few == nil
                return ok, string.format("Min %s (soll %d) · Normal %s · Max %s · zu wenig Fälle -> %s", tostring(mn), wantMin, tostring(normal), tostring(mx), tostring(few)),
                    "Normal 1000 · Max 1250 · Min = 380 / (1 − AH-Anteil) · zu wenig Fälle -> nil"
            end)
        end)
        Chk("T317", "L", "T-L5 Menge je Einstellung: Absatz 6/Tag -> 24 Std. 6, 2 Std. 1; genug Absatz -> keine Grenze", function()
            return WithLearn(function()
                A.SellOutlook = function() return { perDay = 6 } end
                local c24, r24 = Ln:PostCap(990000530, 20, 24)
                local c2, r2 = Ln:PostCap(990000530, 20, 2)
                local cBig = Ln:PostCap(990000530, 5, 24)
                local ok = c24 == 6 and r24 == 14 and c2 == 1 and r2 == 19 and cBig == nil
                return ok, string.format("24 Std.: %s + %s in der Tasche · 2 Std.: %s + %s · 5 Stück: %s", tostring(c24), tostring(r24), tostring(c2), tostring(r2), tostring(cBig)),
                    "24 Std.: 6 + 14 in der Tasche · 2 Std.: 1 + 19 · 5 Stück: nil"
            end)
        end)
        Chk("T318", "L", "T-L6 Teurer neu einstellen erst ab Einzahlung + 10 %", function()
            return WithLearn(function()
                local Se = A.Seller
                local o = { itemID = nil, unitPrice = 1000, qty = 1, deposit = 50 }
                local hi = Ln:RelistHigher(o, 1300)
                local lo = Ln:RelistHigher(o, 1100)
                local want = Se:Undercut(1300, nil)
                local ok = hi == want and lo == nil
                return ok, string.format("Konkurrenz 1300 -> neu %s (soll %d) · Konkurrenz 1100 -> %s", tostring(hi), want, tostring(lo)),
                    "Konkurrenz 1300 -> unterboten · 1100 -> nil"
            end)
        end)
        Chk("T319", "L", "T-L7 Marge aus dem gemessenen Fehler (unter 20 Fällen 20 %, mind. 10 %) und Tagesbudget", function()
            return WithLearn(function(db, store)
                local m0 = Ln:Margin("d")
                local now = time()
                for i = 1, 25 do
                    store.f.list[#store.f.list + 1] = Fc:Encode("B", { t = now - 3 * 86400, id = 990000540, q = 1, pr = 90, way = "d", ev = 100, src = "buy", g = "gear2", r = "c", rq = 1, rv = 80 })
                end
                Fc.evalCache = nil
                local m1 = Ln:Margin("d")
                local lim = Ln:BuyLimit(1000, "d")
                store.f.list[#store.f.list + 1] = Fc:Encode("B", { t = now, id = 990000541, q = 2, pr = 300, way = "d", ev = 400, src = "buy", g = "gear2" })
                local left, limit, spent = Ln:BudgetLeft("d", now)
                local gold = GetMoney and GetMoney() or 0
                -- K1 (Entscheid 10.11.): Standard-Tagesbudget = Markt-Anteil des Golds (25 %)
                local ok = math.abs(m0 - 0.20) < 1e-9 and math.abs(m1 - 0.20) < 1e-9 and lim == 800 and spent == 600 and limit == math.floor(gold * Ln:BudgetPct())
                    and left == math.max(0, limit - 600)
                for i = 1, #store.f.list - 1 do
                    store.f.list[i] = store.f.list[i]:gsub(";80$", ";95")
                end
                Fc.evalCache = nil
                local m2 = Ln:Margin("d")
                ok = ok and math.abs(m2 - 0.10) < 1e-9
                return ok, string.format("Marge ohne Fälle %.2f · 25 Käufe mit 80 %% %.2f · Grenze 1000 -> %d · mit 95 %% %.2f (mind. 0,10) · Budget %s von %s, heute %s",
                    m0, m1, lim or -1, m2, A:FormatMoney(left or 0), A:FormatMoney(limit or 0), A:FormatMoney(spent or 0)),
                    "Marge 0.20 · 0.20 · Grenze 800 · 0.10 · Budget = 25 % Gold − 6s"
            end)
        end)
        Chk("T320", "L", "T-L8 Verlustgrenze: Marktwert −30 % seit dem Kauf -> ein Hinweis, danach nicht mehr", function()
            return WithLearn(function(db, store)
                local now = time()
                store.f.list[#store.f.list + 1] = Fc:Encode("B", { t = now - 86400, id = 990000550, q = 5, pr = 900, way = "e", ev = 950, src = "buy", g = "misc", mv = 1000 })
                store.f.list[#store.f.list + 1] = Fc:Encode("B", { t = now - 86400, id = 990000551, q = 5, pr = 900, way = "e", ev = 950, src = "buy", g = "misc", mv = 1000 })
                Ln.MarketValue = function(_, id) return id == 990000550 and 700 or 900 end
                local w1 = Ln:LossWarnings(now)
                Ln:LossWarnings(now, true)
                local w2 = Ln:LossWarnings(now)
                local ok = #w1 == 1 and w1[1].itemID == 990000550 and w1[1].qty == 5 and #w2 == 0
                return ok, string.format("Hinweise %d (Item %s, %s Stück, jetzt %s) · danach %d", #w1, tostring(w1[1] and w1[1].itemID - 990000000),
                    tostring(w1[1] and w1[1].qty), tostring(w1[1] and w1[1].sellNow), #w2), "Hinweise 1 (Item 550, 5 Stück) · danach 0"
            end)
        end)
        Chk("T321", "L", "T-L9 Rhythmus nur ab 21 Tagen und nur, wenn beide Hälften dasselbe zeigen", function()
            return WithLearn(function(db)
                local today = math.floor(time() / 86400)
                local function H(lo, hi) local t = {} for i = 1, 24 do t[i] = (i == lo and 800) or (i == hi and 1200) or 1000 end return table.concat(t, ",") end
                local W = "1000,1000,1000,1000,1000,1000,1000"
                db.rhythm[990000560] = table.concat({ today - 30, H(5, 22), H(5, 22), W, W }, ";")
                db.rhythm[990000561] = table.concat({ today - 30, H(5, 22), H(13, 22), W, W }, ";")
                db.rhythm[990000562] = table.concat({ today - 10, H(5, 22), H(5, 22), W, W }, ";")
                local r1, r2, r3 = Ln:Rhythm(990000560), Ln:Rhythm(990000561), Ln:Rhythm(990000562)
                local want = string.format(L["günstig um %d Uhr, teuer um %d Uhr"], 4, 21)
                local ok = r1 == want and r2 == nil and r3 == nil
                return ok, string.format("stabil: %s · Hälften verschieden: %s · 10 Tage: %s", tostring(r1), tostring(r2), tostring(r3)),
                    "stabil: " .. want .. " · Hälften verschieden: nil · 10 Tage: nil"
            end)
        end)
        Chk("T322", "L", "T-L10 Selbstkorrektur gedämpft (höchstens ±30 % je Schritt)", function()
            return WithLearn(function(db, store)
                local now = time()
                for i = 1, 20 do
                    store.f.list[#store.f.list + 1] = Fc:Encode("P", { t = now - 2 * 86400, id = 990000570, q = 1, pr = 100, rel = 1, d = 24, p = 0.8, W = 10, g = "misc", r = "e", sq = 0 })
                end
                Fc.evalCache = nil
                db.x7Since = 0                         -- X7: in diesem Test zählen auch ältere Fälle
                local n = Ln:SelfCorrect(now, true)
                local c = db.corr.misc
                local ok = Ln.Damp(1, 2, 0.3) == 1.3 and Ln.Damp(1, 0.5, 0.3) == 0.7 and n == 1 and c and math.abs(c.p - 0.7) < 1e-9 and c.d == 1
                return ok, string.format("Dämpfung 2 -> %.2f, 0,5 -> %.2f · Gruppe Sonstiges: Chance 1,00 -> %s, Dauer %s", Ln.Damp(1, 2, 0.3), Ln.Damp(1, 0.5, 0.3),
                    c and string.format("%.2f", c.p) or "-", c and string.format("%.2f", c.d) or "-"), "Dämpfung 1.30 / 0.70 · Chance 1,00 -> 0,70, Dauer 1,00"
            end)
        end)
        -- X7 (Befund 0.65.86): Zuordnung der Verkäufe und Fälle für die Selbstkorrektur
        Chk("T427", "L", "T-X7a 10 Staub eingestellt, 6 verkauft (Rechnung, Post schneller als 1 Std.), Rest abgelaufen -> Ergebnis 0,6, nicht 0", function()
            return WithLearn(function(db, store)
                local now = time()
                store.f.list[#store.f.list + 1] = Fc:Encode("P", { t = now - 600, id = 10940, q = 10, pr = 100, rel = 1, d = 24, p = 0.9, W = 1, g = "de" })
                -- Rechnung: Post 5 Min. nach dem Einstellen angekommen -> Verkaufszeit = Ankunft - 1 Std. (liegt vor der Einstellung)
                Fc:OnSale(10940, 6, 600, 30, now - 300 - 3600, true)
                store.f.mail = now + 26 * 3600
                Fc:Close(now + 26 * 3600)
                local e = Fc:Decode(store.f.list[#store.f.list])
                local y = e and Fc:PostOutcome(e)
                local rows = Fc:PDiagnosis("de", 5)
                local ok = e and e.sq == 6 and e.r == "t" and y and math.abs(y - 0.6) < 1e-9 and e.rs == "inv" and (rows[1] or ""):find("Teilverkauf", 1, true) ~= nil
                return ok, string.format("verkauft %s · Ergebnis %s (%s) · Herkunft %s · Diagnose \"%s\"", tostring(e and e.sq), tostring(y), tostring(e and e.r),
                    tostring(e and e.rs), tostring(rows[1])), "6 · 0,6 (t) · inv · Teilverkauf"
            end)
        end)
        Chk("T428", "L", "T-X7b Material entzaubert und behalten (nie eingestellt) -> kein Verkaufs-Fall, zählt nicht in die Trefferquote", function()
            return WithLearn(function(db, store)
                Fc:Add("D", { t = time(), id = 990000580, ev = 100, g = "gear2", dk = "2:1:a", lv = 90 })
                Fc.evalCache = nil
                local R = Fc:Eval()
                local R2 = Fc:EvalSince(0)
                local ok = R.all.n == 0 and R2.all.n == 0 and R.des == 1
                return ok, string.format("Verkaufs-Fälle %d / seit %d · Entzauber-Fälle %d", R.all.n, R2.all.n, R.des), "0 / 0 · 1"
            end)
        end)
        Chk("T429", "L", "T-X7c Selbstkorrektur lernt nicht mit Fällen vor der Behebung (x7Since)", function()
            return WithLearn(function(db, store)
                local now = time()
                for i = 1, 20 do
                    store.f.list[#store.f.list + 1] = Fc:Encode("P", { t = now - 2 * 86400, id = 990000571, q = 1, pr = 100, rel = 1, d = 24, p = 0.9, W = 10, g = "misc", r = "e", sq = 0 })
                end
                Fc.evalCache = nil
                db.x7Since = now - 3600
                local n = Ln:SelfCorrect(now, true)
                local ok = n == 0 and db.corr.misc == nil
                return ok, string.format("geändert %d · Gruppe Sonstiges %s", n, db.corr.misc and "korrigiert" or "unverändert"), "0 · unverändert"
            end)
        end)
        Chk("T323", "L", "T-L11 Ausprobieren: Standard aus; an -> jede 10. Einstellung +5 % und im Journal markiert", function()
            return WithLearn(function(db, store)
                local off = Ln:ExploreOn()
                A.db.settings.learnExplore = true
                db.exploreN = 9
                local up, isX = Ln:ExplorePrice(990000580, 1000)
                Fc.PostPrediction = function() return { p = 0.5 } end
                Fc:OnPosted({ itemID = 990000580, qty = 1, unitPrice = up, duration = 3 })
                local e = Fc:Decode(store.f.list[#store.f.list])
                local up2, isX2 = Ln:ExplorePrice(990000580, 1000)
                local ok = off == false and up == 1050 and isX and e and e.ex == 1 and db.exploreN == 10 and up2 == 1000 and not isX2
                return ok, string.format("Standard %s · 10. Einstellung %s (%s) · Journal ex=%s · Zähler %d · 11.: %s", off and "an" or "aus", tostring(up), tostring(isX),
                    tostring(e and e.ex), db.exploreN, tostring(up2)), "Standard aus · 10. Einstellung 1050 (true) · Journal ex=1 · Zähler 10 · 11.: 1000"
            end)
        end)
        Chk("T324", "L", "T-L12 Option \"Lernen\" aus -> alles wie vor Stufe 2", function()
            return WithLearn(function(db, store)
                Cases(store, 990000520, 1.0, 30, 27)
                Ln.MarketValue = function() return 1000 end
                Ln.forceOff = true
                A.SellOutlook = function() return { perDay = 6 } end
                local res = { Ln:Limits(990000520), Ln:BuyLimit(1000, "d"), Ln:Margin("d"), Ln:PostCap(990000520, 20, 24), Ln:RelistHigher({ unitPrice = 1, qty = 1, deposit = 0 }, 5000),
                    Ln:BudgetLeft("d"), (Ln:Corr("misc")), Ln:Rhythm(990000520), Ln:Croston(990000520), Ln:ExploreOn() }
                local ok = res[1] == nil and res[2] == 1000 and res[3] == 0 and res[4] == nil and res[5] == nil and res[6] == nil and res[7] == 1 and res[8] == nil
                    and res[9] == nil and res[10] == false
                local parts = {}
                for i = 1, 10 do parts[i] = tostring(res[i]) end
                return ok, table.concat(parts, " · "), "nil · 1000 · 0 · nil · nil · nil · 1 · nil · nil · false"
            end)
        end)
        Chk("T325", "L", "Lern-Datenbank: Speicher < 1 MB (voll), Teil B Bericht aus echten Daten nur lesen", function()
            local size
            WithLearn(function(db)
                local h = {}
                for i = 1, 24 do h[i] = "123456" end
                local hs = table.concat(h, ",")
                for i = 1, 300 do db.rhythm[990000600 + i] = table.concat({ 20000, hs, hs, "1234567,1234567,1234567,1234567,1234567,1234567,1234567", "1234567,1234567,1234567,1234567,1234567,1234567,1234567" }, ";") end
                for i = 1, 50 do
                    local c = {}
                    for _, g in ipairs(Fc.GROUPS) do for cl = 1, 5 do for _, d in ipairs({ 2, 8, 24 }) do c[g .. "|" .. cl .. ":" .. d] = { 4999, 2500 } end end end
                    db.shared["#s" .. i] = { t = time(), c = c }
                end
                for _, g in ipairs(Fc.GROUPS) do db.corr[g] = { d = 1.1, p = 0.9, n = 100, t = time() } end
                size = Ln.SizeOf(db)
            end)
            local db = A.db
            local function Snap()
                local l = db.learn or {}
                local n = 0
                for _ in pairs(l.rhythm or {}) do n = n + 1 end
                return string.format("%d|%s|%s", n, tostring(l.lastCorr), tostring(l.exploreN))
            end
            local before = Snap()
            local okR, lines = pcall(Ln.Report, Ln)
            local after = Snap()
            local ok = size and size < 1024 * 1024 and okR and before == after and table.concat(lines, "\n"):find("Lern-Datenbank", 1, true) ~= nil
            return ok, string.format("voll %d KB · Bericht %s · echte Tabellen %s", math.ceil((size or 0) / 1024), okR and "da" or tostring(lines),
                before == after and "unverändert" or "GEÄNDERT"), "< 1024 KB · Bericht da · unverändert"
        end)
    end) end

    -- ---------------- M. Markt-Reiter (Stufe 3, T-M1–T-M7) ----------------
    if want(part, "m") then B(function()
        local MV = A.MarketView
        local UI = A.UI
        if not (MV and UI and UI.ShowToday) then return Skp("T326", "M", "Markt-Reiter", "UI_MarketView.lua nicht geladen") end
        Chk("T326", "M", "T-M1 /ahs heute öffnet Markt -> Heute (UI:ShowToday)", function()
            local p = UI:ShowToday()
            local ok = p ~= nil and UI.activeTab == "marketview" and p.view == "heute" and p.table ~= nil
            return ok, string.format("Reiter %s · Ansicht %s", tostring(UI.activeTab), tostring(p and p.view)), "Reiter marketview · Ansicht heute"
        end)
        Chk("T327", "M", "T-M2 ProfessionSentinel ruft QuickSell -> Zeile oben mit Knopf", function()
            local Td = A.Today
            local n0 = #Td.extra
            local id = 990000700
            local okQ = Td:QuickSell(id, 3)
            local p = UI.marketView
            if p then p:Refresh() end
            local first = p and p.list and p.list[1]
            local label = first and Td:Label(first)
            for i = #Td.extra, 1, -1 do if Td.extra[i].itemID == id then table.remove(Td.extra, i) end end
            Td.state["quicksell:" .. id] = nil
            local ok = okQ and first and first.kind == "quicksell" and first.itemID == id and first.pin and label ~= nil and #Td.extra == n0
            return ok, string.format("QuickSell %s · oben %s (%s) · Knopf %s", tostring(okQ), tostring(first and first.kind), first and first.pin and "Auftrag" or "-", tostring(label)),
                "QuickSell true · oben quicksell (Auftrag) · Knopf da"
        end)
        Chk("T328", "M", "T-M3 Händler-Ansicht: Sofortkauf 3c, Händler 5c -> Zeile mit Knopf Prüfen", function()
            local saved = A.VendorFlipOffers
            A.VendorFlipOffers = function() return { { itemID = 990000701, name = "Test", price = 3, vendor = 5, qty = 1, profit = 2 } } end
            local res = { pcall(MV.BuildVendor, MV) }
            A.VendorFlipOffers = saved
            if not res[1] then error(res[2], 0) end
            local r = res[2][1]
            local label = r and A.Today:Label(r)
            A.Today.state[A.Today:Key(r)] = nil
            local want = A:IsAHOpen() and L["Prüfen"] or L["AH öffnen"]
            local ok = r and r.kind == "vendor" and r.gold == 2 and r.maxUnit == 4 and label == want
            return ok, string.format("Zeile %s · Gewinn %s · Grenze %s · Knopf %s", tostring(r and r.kind), tostring(r and r.gold), tostring(r and r.maxUnit), tostring(label)),
                "Zeile vendor · Gewinn 2 · Grenze 4 · Knopf " .. want
        end)
        Chk("T329", "M", "T-M4 Überfüllt: Angebot 552, Absatz 2/Tag -> Warnung, keine Einstellen-Empfehlung", function()
            local Se = A.Seller
            local savedSO, savedBag, savedCnt = A.SellOutlook, Se.GetBagItems, Se.CountInBags
            A.SellOutlook = function() return { queue = 552, perDay = 2, wait = 276, rare = true } end
            Se.GetBagItems = function() return { { itemID = 990000702, count = 20 } } end
            Se.CountInBags = function() return 20 end
            local res = { pcall(function() return MV:BuildCrowded(), { MV:Advice(990000702) } end) }
            A.SellOutlook, Se.GetBagItems, Se.CountInBags = savedSO, savedBag, savedCnt
            if not res[1] then error(res[2], 0) end
            local rows, adv = res[2], res[3]
            local r = rows[1]
            local ok = r and r.warn and r.itemID == 990000702 and r.text:find("552", 1, true) ~= nil and adv[1] == "hold"
            return ok, string.format("Zeilen %d · Warnung %s · %s · Empfehlung %s", #rows, tostring(r and r.warn), tostring(r and r.num), tostring(adv[2])),
                "Zeilen 1 · Warnung true · ~276 Tage · Empfehlung liegen lassen"
        end)
        Chk("T330", "M", "T-M5 Suche \"Seltsamer Staub\" -> Detailbereich mit Empfehlung", function()
            local p = UI:ShowToday()
            if not p then return false, "kein Markt-Reiter" end
            local name = A:GetItemName(10940)
            local id = A.FindItemByName and A:FindItemByName(name)
            p:ShowDetail(id or 10940)
            local d = p.detail
            local advice = d.advice:GetText() or ""
            local ok = (id == 10940 or not id) and d.itemID == 10940 and advice ~= "" and (d.reason:GetText() or "") ~= "" and (d.lines[1]:GetText() or "") ~= ""
            return ok, string.format("gefunden %s · Empfehlung \"%s\" · %s", tostring(id), advice, tostring(d.reason:GetText())), "gefunden 10940 · Empfehlung da"
        end)
        Chk("T331", "M", "T-M6 die alte Liste aller Items steht in keiner Leiste mehr", function()
            local inBar, mv = false, false
            for _, g in ipairs(UI:Groups()) do
                for _, id in ipairs(g.tabs) do
                    if id == "market" then inBar = true end
                    if id == "marketview" then mv = true end
                end
            end
            return not inBar and mv, string.format("Alle Preise in der Leiste %s · Markt-Reiter %s", inBar and "JA" or "nein", mv and "da" or "fehlt"),
                "Alle Preise in der Leiste nein · Markt-Reiter da"
        end)
        Chk("T332", "M", "T-M7 alle 6 Ansichten: Knöpfe, Liste und Detailbereich überlagern sich nicht", function()
            local p = UI:ShowToday()
            if not p then return false, "kein Markt-Reiter" end
            local function rect(f) local l, b, w, h = f:GetRect(); return l, b, w, h end
            local l1, b1, w1, h1 = rect(p.viewBtns.heute)
            local l2 = rect(p.viewBtns.flip)
            if not (l1 and l2 and w1 and w1 > 0) or l1 == l2 then return "SKIP", "HALB: Lage nicht messbar (im Client prüfen)" end
            local problems = {}
            local function over(a, b)
                local al, ab, aw, ah = rect(a); local bl, bb, bw, bh = rect(b)
                if not (al and bl) then return false end
                return al < bl + bw - 1 and bl < al + aw - 1 and ab < bb + bh - 1 and bb < ab + ah - 1
            end
            for _, v in ipairs(MV.VIEWS) do
                p:SetView(v)
                local btns = {}
                for _, x in ipairs(MV.VIEWS) do btns[#btns + 1] = p.viewBtns[x] end
                btns[#btns + 1] = p.refreshBtn
                btns[#btns + 1] = p.search
                for i = 1, #btns do for j = i + 1, #btns do if over(btns[i], btns[j]) then problems[#problems + 1] = v .. ": Knopf " .. i .. "/" .. j end end end
                if over(p.table, p.detail) then problems[#problems + 1] = v .. ": Liste/Detail" end
            end
            p:SetView("heute")
            return #problems == 0, #problems == 0 and "keine Überlagerung" or table.concat(problems, "; "), "keine Überlagerung"
        end)
    end) end

    -- ---------------- Befund Markt/Heute-Flip (10.11. 12:55, T-HF1–T-HF7) ----------------
    if want(part, "m") then B(function()
        local MV = A.MarketView
        if not (MV and A.FlipCheck) then return Skp("T344", "M", "Flip-Prüfung", "nicht geladen") end
        local ID = 990001000
        -- eigene Funktionen als Seams (nie Blizzard): Marktwert, aktueller Preis, Angebotsliste, Absatz/Laufzeit, Verlauf
        local function WithItem(cfg, fn)
            local saved = { mv = A.GetMarketValue, cur = A.GetCurrent, lad = A.OfferLadder, basis = A.ResaleBasis, hist = A.GetHistory, so = A.SellOutlook }
            A.GetMarketValue = function(self, id) if id == ID then return cfg.mv end return saved.mv(self, id) end
            A.GetCurrent = function(self, id) if id == ID then return cfg.cur, cfg.qty or 10, time() - (cfg.age or 60) end return saved.cur(self, id) end
            A.OfferLadder = function(self, id) if id == ID then return cfg.ladder end return saved.lad(self, id) end
            A.ResaleBasis = function(self, id) if id == ID then return cfg.perDay, cfg.hours end return saved.basis(self, id) end
            A.GetHistory = function(self, id) if id == ID then return cfg.history or {} end return saved.hist(self, id) end
            if cfg.outlook then A.SellOutlook = function(self, id, ...) if id == ID then return cfg.outlook end return saved.so(self, id, ...) end end
            local res = { pcall(fn) }
            A.GetMarketValue, A.GetCurrent, A.OfferLadder, A.ResaleBasis, A.GetHistory, A.SellOutlook = saved.mv, saved.cur, saved.lad, saved.basis, saved.hist, saved.so
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        local HF1 = { mv = 20300, cur = 4597, perDay = 52, hours = 2,
            ladder = { { 4597, 256 }, { 4598, 424 }, { 4999, 65 }, { 5000, 158 }, { 20298, 3 } } }
        Chk("T344", "M", "T-HF1 Instabiles Magiepartikel: Marktwert 2g 3s, Leiter ab 45s 97c, Absatz 52/Tag, 2 Std. -> Wiederverkauf ~46s, kein Flip", function()
            return WithItem(HF1, function()
                local resale = A:ResalePrice(ID, 4597, 4)
                local ok, r = A:FlipCheck(ID, 4597)
                local good = resale and resale >= 4500 and resale <= 4600 and not ok
                return good, string.format("Wiederverkauf %s · Flip %s (%s)", A:FormatMoney(resale or 0), tostring(ok), tostring(r and r.why)),
                    "Wiederverkauf ≈ 45–46s · Flip false"
            end)
        end)
        Chk("T345", "M", "T-HF2 gleiches Item: Detail \"liegen lassen\", Heute/Flippen ohne Kaufzeile (Liste = Detail)", function()
            return WithItem(HF1, function()
                local kind, advice = MV:Advice(ID)
                local okF = A:FlipCheck(ID, 4597)
                local good = kind == "hold" and not okF
                return good, string.format("Detail %s (%s) · Flip-Zeile %s", tostring(kind), tostring(advice), okF and "JA" or "nein"), "Detail hold · Flip-Zeile nein"
            end)
        end)
        Chk("T346", "M", "T-HF3 echter Flip: Marktwert 1s, Leiter 50c: 5 · 95c: 40, Absatz 30/Tag -> Wiederverkauf ~94c, 5 Stück ok", function()
            return WithItem({ mv = 100, cur = 50, perDay = 30, hours = 24, ladder = { { 50, 5 }, { 95, 40 } } }, function()
                local ok, r = A:FlipCheck(ID, 50, 5)
                local kind = MV:Advice(ID)
                local good = ok and r.resale == 94 and r.qty == 5 and r.profit > 0 and kind == "buy"
                return good, string.format("Flip %s · Wiederverkauf %s · Menge %s · Gewinn %s · Detail %s", tostring(ok), tostring(r and r.resale), tostring(r and r.qty),
                    tostring(r and r.profit), tostring(kind)), "Flip true · Wiederverkauf 94 · Menge 5 · Detail buy"
            end)
        end)
        Chk("T347", "M", "T-HF4 Menge 3× Ø -> kein Flip, Zeile in Überfüllt", function()
            local now = time()
            local hist = {}
            for i = 1, 5 do hist[i] = { t = now - i * 86400, p = 100, q = 100 } end
            A.db.marketData[ID] = { history = {} }
            local res = { pcall(WithItem, { mv = 100, cur = 50, qty = 300, perDay = 30, hours = 24, history = hist,
                outlook = { queue = 300, perDay = 2, perDaySource = "market", hours = 24 } }, function()
                local why = A:FlipBlocked(ID)
                local ok = A:FlipCheck(ID, 50)
                local Se = A.Seller
                local savedBag = Se.GetBagItems
                Se.GetBagItems = function() return {} end
                local okR, rows = pcall(MV.BuildCrowded, MV)
                Se.GetBagItems = savedBag
                local found = false
                for _, r in ipairs(okR and rows or {}) do if r.itemID == ID then found = true end end
                return why, ok, found
            end) }
            A.db.marketData[ID] = nil
            if not res[1] then error(res[2], 0) end
            local why, ok, found = res[2], res[3], res[4]
            return why == "flood" and not ok and found, string.format("gesperrt %s · Flip %s · in Überfüllt %s", tostring(why), tostring(ok), tostring(found)),
                "gesperrt flood · Flip false · in Überfüllt true"
        end)
        Chk("T348", "M", "T-HF5 Überfüllt ohne gemessenen Absatz: 855 Stück, 52/Tag, 2 Std. -> Zeile da, \"geschätzt\"", function()
            local Se = A.Seller
            local savedBag = Se.GetBagItems
            Se.GetBagItems = function() return { { itemID = ID, count = 4 } } end
            local res = { pcall(WithItem, { mv = 20300, cur = 4597, perDay = 52, hours = 2,
                outlook = { queue = 855, perDay = 52, perDaySource = "market", hours = 2 } }, function() return MV:BuildCrowded() end) }
            Se.GetBagItems = savedBag
            if not res[1] then error(res[2], 0) end
            local row
            for _, r in ipairs(res[2]) do if r.itemID == ID then row = r end end
            local good = row and row.text:find(L["geschätzt"], 1, true) ~= nil and row.safety == "niedrig"
            return good, row and (row.num .. " · " .. row.text) or "keine Zeile", "Zeile da, geschätzt, grau"
        end)
        Chk("T349", "M", "T-HF6 leere Ansicht nennt den Grund", function()
            local saved, savedH = A.VendorFlipOffers, MV.HistoryDays
            A.VendorFlipOffers = function() return {} end
            MV.HistoryDays = function() return 3 end
            local res = { pcall(function()
                MV:BuildVendor()
                MV.BuildTrendsReason = nil
                local days = MV:HistoryDays()
                local trends = days < 7 and string.format(L["Trends: braucht 7 Tage Verlauf, noch %d Tage."], 7 - days)
                return MV.reason.vendor, trends
            end) }
            A.VendorFlipOffers, MV.HistoryDays = saved, savedH
            if not res[1] then error(res[2], 0) end
            local good = res[2] == L["Kein Sofortkauf unter dem Händlerpreis im letzten Scan."] and res[3]:find("4", 1, true) ~= nil
            return good, tostring(res[2]) .. " · " .. tostring(res[3]), "Grund genannt"
        end)
        Chk("T350", "M", "T-HF7 Ansichtswechsel leert den Detailbereich bzw. zeigt die erste Zeile", function()
            local p = A.UI:ShowToday()
            if not p then return false, "kein Markt-Reiter" end
            p:ShowDetail(10940)
            p:SetView("trends")
            local first = p.list and p.list[1] and p.list[1].itemID
            local id = p.detail.itemID
            p:SetView("heute")
            local good = id == nil or id == first
            return good, string.format("Detail danach %s (erste Zeile %s)", tostring(id), tostring(first)), "leer oder erste Zeile"
        end)
        -- H9 (Befund 10.11. 14:07/14:25): Materialpreis ehrlich (Scan / frisch gestiegen / Marktwert), Lockangebote im Verlauf
        local D = A.Disenchant
        local function MatCase(cfg, fn)
            local savedPI = A.PriceInfo
            A.PriceInfo = function(self, id, ...) if id == ID then return { value = cfg.cur or cfg.mv, source = cfg.cur and "ah" or "market", median = cfg.mv } end return savedPI(self, id, ...) end
            D.resaleCache[ID] = nil
            local res = { pcall(WithItem, cfg, fn) }
            A.PriceInfo = savedPI
            D.resaleCache[ID] = nil
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        local function Hist(price, hoursBack, n, q)
            local h, now = {}, time()
            for k = n, 1, -1 do h[#h + 1] = { t = now - math.floor(hoursBack * 3600 * k / n), p = price, q = q or 300 } end
            return h
        end
        Chk("T369", "M", "T-HF9 Splitter Scan 37s (311 Stück) seit 30 Std., Marktwert 16s 70c, Absatz 25/Tag -> Materialpreis ≈ 37s, Label Scan", function()
            local cfg = { mv = 1670, cur = 3700, qty = 311, perDay = 25, hours = 24, ladder = { { 3700, 311 }, { 3800, 40 } } }
            cfg.history = Hist(3700, 30, 12, 311)
            return MatCase(cfg, function()
                local v, _, _, src, unsure, _, x = D:MatPrice(ID)
                local ok = v and v >= 3600 and v <= 3700 and src == "ah" and unsure == true
                return ok, string.format("%s · Quelle %s · unsicher %s · Scan %s / Marktwert %s", A:FormatMoney(v or 0), tostring(src), tostring(unsure),
                    A:FormatMoney(x and x.scan or 0), A:FormatMoney(x and x.mv or 0)), "≈ 37s · Quelle ah (Scan) · unsicher (beide Werte im Shift)"
            end)
        end)
        -- X1 (Befund 0.65.86): ein einzelnes 2c-Angebot im Scan drückt den Materialwert nicht (Deckel nur mit bereinigtem Scan-Wert)
        Chk("T413", "M", "T-X1 Essenz-Leiter 300c, Scan-Minimum 2c (1 Stück) -> Materialwert ≈ 300c (nicht 2c), unsicher", function()
            local cfg = { mv = 300, cur = 2, qty = 1, perDay = 20, hours = 24, ladder = { { 2, 1 }, { 300, 50 } } }
            cfg.history = Hist(300, 48, 12, 50)
            return MatCase(cfg, function()
                local v, _, _, src, unsure = D:MatPrice(ID)
                local ok = v and v >= 290 and v <= 300 and unsure == true
                return ok, string.format("%s · Quelle %s · unsicher %s", tostring(v), tostring(src), tostring(unsure)), "≈ 300c (Leiter), unsicher, nicht 2c"
            end)
        end)
        Chk("T370", "M", "T-HF10 Verlauf 37s × 20 Scans + 3 Lockangebote à 10s (je 1 Stück) -> Marktwert ≈ 37s", function()
            local saved = A.GetHistory
            local h = Hist(3700, 48, 20, 300)
            local now = time()
            for k = 1, 3 do h[#h + 1] = { t = now - 600 + k * 60, p = 1000, q = 1 } end
            A.GetHistory = function(self, id) if id == ID then return h end return saved(self, id) end
            local ok2, mv = pcall(A.GetMarketValue, A, ID)
            A.GetHistory = saved
            if not ok2 then error(mv, 0) end
            return mv and math.abs(mv - 3700) <= 50, "Marktwert " .. A:FormatMoney(mv or 0), "≈ 37s"
        end)
        -- Entscheid 10.11. 15:54 "aktueller Markt" (T-AM1, T-AM3, T-AM4; T-AM2 = T344): Wert aus dem aktuellen Markt,
        -- der Marktwert nur als Hinweis
        Chk("T371", "M", "T-AM1 Splitter Scan 37s erst seit 1 Std., Marktwert 16s 70c -> Wert 37s, Hinweis \"frisch gestiegen\"", function()
            local cfg = { mv = 1670, cur = 3700, qty = 311, perDay = 20, hours = 24, ladder = { { 3700, 311 } } }
            cfg.history = Hist(1670, 72, 20, 300)
            local now = time()
            cfg.history[#cfg.history + 1] = { t = now - 3600, p = 3700, q = 311 }
            cfg.history[#cfg.history + 1] = { t = now - 600, p = 3700, q = 311 }
            return MatCase(cfg, function()
                local v, _, _, src, unsure, _, x = D:MatPrice(ID)
                local hint = A:PriceHintText(x and x.hints)
                local ok = v and v >= 3600 and v <= 3700 and src == "ah" and x and x.hints.fresh == 1 and hint and hint:find(L["Preis frisch gestiegen (seit %d Std.)"]:sub(1, 10), 1, true)
                return ok, string.format("%s · Quelle %s · Hinweis %s", A:FormatMoney(v or 0), tostring(src), tostring(hint)), "≈ 37s · Scan · frisch gestiegen (seit 1 Std.)"
            end)
        end)
        Chk("T384", "M", "T-AM3 Preis 50 % des Marktwerts seit 3 Std. -> Wert = aktueller Preis, Hinweis \"eingebrochen\"", function()
            local cfg = { mv = 1670, cur = 835, qty = 200, perDay = 20, hours = 24 }
            cfg.history = Hist(1670, 72, 20, 300)
            local now = time()
            cfg.history[#cfg.history + 1] = { t = now - 3 * 3600, p = 835, q = 200 }
            cfg.history[#cfg.history + 1] = { t = now - 600, p = 835, q = 200 }
            return MatCase(cfg, function()
                local v, _, _, src, _, _, x = D:MatPrice(ID)
                local ok = v == 835 and src == "ah" and x and x.hints.crash == 3
                return ok, string.format("%s · Quelle %s · %s", A:FormatMoney(v or 0), tostring(src), tostring(A:PriceHintText(x and x.hints))), "8s 35c · Scan · eingebrochen (seit 3 Std.)"
            end)
        end)
        Chk("T385", "M", "T-AM4 Letzter Scan vor 5 Std. -> Wert aus dem letzten Scan, Hinweis \"alt (vor 5 Std.)\"", function()
            local cfg = { mv = 1670, cur = 1600, qty = 200, perDay = 20, hours = 24, age = 5 * 3600 }
            cfg.history = Hist(1600, 72, 20, 300)
            return MatCase(cfg, function()
                local v, _, _, src, _, _, x = D:MatPrice(ID)
                local ok = v == 1600 and src == "ah" and x and x.hints.old == 5
                return ok, string.format("%s · Quelle %s · %s", A:FormatMoney(v or 0), tostring(src), tostring(A:PriceHintText(x and x.hints))), "16s · Scan · alt (vor 5 Std.)"
            end)
        end)
        -- Befund Schein-Flip 10.11. 16:50 (T-F1–T-F4)
        local KISTE = { mv = 499, cur = 378, qty = 473, perDay = 150, hours = 2,
            ladder = { { 378, 1 }, { 399, 2 }, { 400, 9 }, { 408, 9 }, { 409, 3 }, { 488, 5 }, { 500, 36 }, { 588, 1 }, { 600, 15 }, { 800, 24 }, { 998, 21 }, { 1000, 79 } } }
        Chk("T403", "M", "T-F1 Abgefangene Kiste: Leiter 3s 99c ×2 · 4s ×9 …, Absatz 150/Tag, 2 Std. -> Wiederverkauf ≈ 4s, kein Flip", function()
            return WithItem(KISTE, function()
                local ok, r = A:FlipCheck(ID, 380)
                local good = not ok and r and r.resale and r.resale >= 398 and r.resale <= 408
                return good, string.format("Wiederverkauf %s · Flip %s (%s)", A:FormatMoney(r and r.resale or 0), tostring(ok), tostring(r and r.why)), "≈ 3s 99c–4s 8c · kein Flip"
            end)
        end)
        Chk("T404", "M", "T-F2 Kauf bis 3s 80c, nur 1 Stück darunter -> Menge ≤ 1; ohne Preisleiter kein Flip", function()
            local cfg = { mv = 1000, cur = 378, qty = 6, perDay = 30, hours = 24, ladder = { { 378, 1 }, { 1000, 5 } } }
            local ok1, r1 = WithItem(cfg, function() return A:FlipCheck(ID, 380) end)
            local cfg2 = { mv = 1000, cur = 378, qty = 6, perDay = 30, hours = 24, ladder = nil }
            local ok2, r2 = WithItem(cfg2, function() return A:FlipCheck(ID, 380) end)
            local good = r1 and r1.qty == 1 and not ok2 and r2 and r2.why == "noladder"
            return good, string.format("Menge %s (Flip %s) · ohne Leiter %s (%s)", tostring(r1 and r1.qty), tostring(ok1), tostring(ok2), tostring(r2 and r2.why)), "Menge 1 · ohne Leiter kein Flip"
        end)
        Chk("T405", "M", "T-F3 Listen- und Detail-Rechnung verschieden -> Zeile verworfen, FLIP-WIDERSPRUCH im Protokoll", function()
            local cfg = { mv = 1000, cur = 378, qty = 6, perDay = 30, hours = 24, ladder = { { 378, 1 }, { 1000, 5 } } }
            local diag = {}
            local savedD = A.Diag and A.Diag.Add
            if A.Diag then A.Diag.Add = function(_, k, t) diag[#diag + 1] = k .. " " .. t end end
            local res = { pcall(WithItem, cfg, function()
                local _, r = A:FlipCheck(ID, 378)
                return MV:FlipConsistent(ID, r.limit, r.resale), MV:FlipConsistent(ID, r.limit + 1, r.resale)
            end) }
            if A.Diag then A.Diag.Add = savedD end
            if not res[1] then error(res[2], 0) end
            local same, diff = res[2], res[3]
            local line = diag[#diag] or ""
            local good = same == true and diff == false and line:find("FLIP-WIDERSPRUCH", 1, true) ~= nil
            return good, string.format("gleich %s · verschieden %s · \"%s\"", tostring(same), tostring(diff), line:sub(1, 80)), "true · false · FLIP-WIDERSPRUCH"
        end)
        Chk("T406", "M", "T-F4 Zeile in \"Heute\" anklicken -> Detail zeigt diese Zeile", function()
            local tab = A.UI and A.UI:GetTab("marketview")
            if tab and not tab.panel then A.UI:SelectTab("marketview") end
            local p = tab and tab.panel
            if not (p and p.table and p.table.rows and p.detail) then return false, "Markt-Reiter fehlt", "Detail = Zeile" end
            local oldView, ran = p.view, false
            p.view = "heute"
            local row = { itemID = 2589, text = "Testzeile", kind = "flip", run = function() ran = true end }
            local res = { pcall(function()
                p.table:SetData({ row }, true)
                local fr = p.table.rows[1]
                local f = fr and fr:GetScript("OnClick")
                if f then f(fr, "LeftButton") end
                return p.detail.itemID
            end) }
            p.view = oldView
            pcall(p.Refresh, p)
            if not res[1] then error(res[2], 0) end
            return res[2] == 2589 and ran, string.format("Detail %s · Reiter geöffnet %s", tostring(res[2]), tostring(ran)), "Detail 2589 · Reiter geöffnet"
        end)
        Chk("T407", "M", "T-ME8 Zauberstab (Waffe/Zauberstab) -> nie entzaubern (keine Zeile, kein \"Entzaubern lohnt\")", function()
            local D = A.Disenchant
            return D:IsNeverDE(990009001, 2, 19) and not D:IsNeverDE(990009001, 2, 7), "Zauberstab gesperrt, Schwert erlaubt", "gesperrt · erlaubt"
        end)
        Chk("T408", "M", "T-ME9 Entzaubern scheitert mit \"kann nicht entzaubert werden\" -> Item danach überall ausgeschlossen, Protokollzeile", function()
            local D, DW = A.Disenchant, A.DEWindow
            local saved = { never = A.db.deNever, lc = DW and DW.lastClick, dg = A.Diag and A.Diag.Add }
            local diag = {}
            A.db.deNever = nil
            if DW then DW.lastClick = { itemID = 990009002 } end
            if A.Diag then A.Diag.Add = function(_, k, t) diag[#diag + 1] = k .. " " .. t end end
            local res = { pcall(function()
                local hit = D:OnUIError("Dieser Gegenstand kann nicht entzaubert werden.")
                local other = D:OnUIError("Nicht genug Mana")
                return hit, other, D:IsNeverDE(990009002, nil, nil)
            end) }
            A.db.deNever = saved.never
            if DW then DW.lastClick = saved.lc end
            if A.Diag then A.Diag.Add = saved.dg end
            if not res[1] then error(res[2], 0) end
            local good = res[2] == true and res[3] == false and res[4] == true and (diag[1] or ""):find("DE-NICHT-MOEGLICH", 1, true) ~= nil
            return good, string.format("erkannt %s · andere Meldung %s · gesperrt %s · \"%s\"", tostring(res[2]), tostring(res[3]), tostring(res[4]), diag[1] or "-"),
                "true · false · gesperrt · DE-NICHT-MOEGLICH"
        end)
        -- H5: Kauf-Prognose "Wiederverkauf" mit dem realistischen Preis (Fall Instabiles Magiepartikel, Marktwert 2g 3s)
        Chk("T377", "M", "H5 Kauf-Prognose Flip: Journal speichert den realistischen Wiederverkauf (~46s), nicht den Marktwert 2g 3s", function()
            return WithItem(HF1, function()
                local Fc = A.Forecast
                local way, ev = Fc:BuyPrediction(ID)
                local ok = way == "e" and ev and ev <= 4600 and ev >= 4000
                return ok, string.format("Weg %s · Vorhersage %s", tostring(way), A:FormatMoney(ev or 0)), "Weg e · ≈ 43–46s (nach AH-Anteil)"
            end)
        end)
        -- Sofortkauf offline (T-SK1, T-SK2, T-SK5): nur eigene Seams (A.Print, A.Diag.Add, A.Fire, A.AH.PlaceBid, A.Seller.ErrorText)
        local Bu = A.Buy
        -- echte (vom Selbsttest gesperrte) Kauf-Funktion; der Blizzard-Aufruf ist über A.AH.PlaceBid (Seam) abgefangen
        local function RealBuyItem(l)
            local f = A.SelfTest and A.SelfTest.RealFn and A.SelfTest:RealFn("Buy", "BuyItem") or Bu.BuyItem
            return f(Bu, l)
        end
        local function WithBuy(fn)
            local saved = { pr = A.Print, dg = A.Diag and A.Diag.Add, fire = A.Fire, pb = A.AH.PlaceBid, et = A.Seller and A.Seller.ErrorText,
                res = Bu.results, msg = Bu.message, det = Bu.detail }
            local cap = { prints = {}, diag = {}, bids = 0 }
            A.Print = function(_, m) cap.prints[#cap.prints + 1] = tostring(m) end
            if A.Diag then A.Diag.Add = function(_, k, t) cap.diag[#cap.diag + 1] = tostring(k) .. " " .. tostring(t) end end
            A.Fire = function(self, ev, ...) if ev == "BUY_PURCHASE_RESULT" then return end return saved.fire(self, ev, ...) end
            A.AH.PlaceBid = function() cap.bids = cap.bids + 1 end
            if A.Seller then A.Seller.ErrorText = function() return "Item not found", "ItemNotFound" end end
            Bu.detail = nil
            local res = { pcall(fn, cap) }
            A.Print, A.Fire, A.AH.PlaceBid = saved.pr, saved.fire, saved.pb
            if A.Diag then A.Diag.Add = saved.dg end
            if A.Seller then A.Seller.ErrorText = saved.et end
            Bu.results, Bu.message, Bu.detail = saved.res, saved.msg, saved.det
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        Chk("T378", "M", "T-SK1/T-SK5 Fehlercode ItemNotFound -> \"Angebot ist weg\", listing.dead, Zeile weg, zweiter Klick abgewiesen, KAUF-FEHLER ohne Namen", function()
            return WithBuy(function(cap)
                local l = { auctionID = 990000777, buyout = 1, qty = 1 }
                Bu.results = { { itemID = 990000778, quantity = 1, name = "Testa Beispiel" } }
                Bu:PurchaseFailed({ itemID = 990000778, cost = 1, auctionID = 990000777, listing = l }, 1)
                local okMsg = (cap.prints[1] or ""):find(L["Angebot ist weg (vermutlich schon gekauft)."]:sub(1, 12), 1, true) ~= nil
                local second, why = RealBuyItem(l)
                local diag = table.concat(cap.diag, " | ")
                local ok = okMsg and l.dead and #Bu.results == 0 and not second and cap.bids == 0 and diag:find("KAUF-FEHLER", 1, true)
                    and not diag:find("Testa", 1, true)
                return ok, string.format("Meldung %s · dead %s · Zeilen %d · zweiter Klick %s (%s) · Protokoll %s", okMsg and "ok" or (cap.prints[1] or "-"),
                    tostring(l.dead), #Bu.results, tostring(second), tostring(why), diag:sub(1, 60)), "weg · dead · 0 Zeilen · abgewiesen · KAUF-FEHLER ohne Namen"
            end)
        end)
        Chk("T379", "M", "T-SK2 zu wenig Gold -> \"Nicht genug Gold.\" vor dem Aufruf", function()
            return WithBuy(function(cap)
                local money = GetMoney and GetMoney() or 0
                local okB, why = RealBuyItem({ auctionID = 990000779, buyout = money + 1, qty = 1 })
                return not okB and why == L["Nicht genug Gold."] and cap.bids == 0, string.format("%s · %s · Aufrufe %d", tostring(okB), tostring(why), cap.bids),
                    "false · Nicht genug Gold. · 0 Aufrufe"
            end)
        end)
    end) end

    -- ---------------- Z. Gesamtprüfung (T-G1–T-G7), Messreihe Ausrüstung (T-AS1–3), Sync Punkt 5 ----------------
    if want(part, "z") then B(function()
        Chk("T333", "Z", "T-G1 /ahs testroutine alles: Ablauf auto -> server -> berufe -> haendler, fehlendes Fenster in einer Zeile", function()
            local plan = table.concat(TR.CHAIN, ",")
            local need = TR:ChainNeed("server")
            local ok = TR.PARTS.alles == true and plan == "server,berufe,haendler" and need:find("server", 1, true) ~= nil and not need:find("\n", 1, true)
            return ok, string.format("Teil alles %s · Reihenfolge %s · Hinweis \"%s\"", tostring(TR.PARTS.alles), plan, need),
                "Teil alles true · Reihenfolge server,berufe,haendler · eine Zeile"
        end)
        Chk("T335", "Z", "T-G3 Abschnitte mit echten Daten: Entzaubern, Prognose-Güte, Vollscan, Lern-Datenbank, Markt", function()
            local got = {}
            local function try(name, fn)
                local ok, lines, fields = pcall(fn)
                got[#got + 1] = name .. (ok and type(lines) == "table" and #lines > 0 and "" or " FEHLT")
                return ok and type(lines) == "table" and #lines > 0
            end
            local all = try("Entzaubern", function() return TR:DEReport() end)
            all = try("Prognose", function() return A.Forecast:Report() end) and all
            all = try("Vollscan", function() return A.FullScan:Report() end) and all
            all = try("Lernen", function() return A.Learn:Report() end) and all
            all = try("Markt", function() return A.MarketView:Report() end) and all
            all = try("Messreihe", function() return A.SilverTest:Report() end) and all
            return all, table.concat(got, " · "), "alle sechs Abschnitte da"
        end)
        Chk("T336", "Z", "T-G4 Sandbox vergleicht alle echten Tabellen (Buchhaltung, Entzaubern, Journal, Lernen, Vollscan, Einstellungen)", function()
            local tables = { "ledger", "deStats", "deLog", "deShared", "forecast", "forecastStats", "forecastHours", "fullScan", "learn", "settings" }
            local notCompared = {}
            for _, k in ipairs(tables) do
                if NO_COPY[k] or TR:IsAllowed({ k }) then notCompared[#notCompared + 1] = k end
            end
            local out = {}
            Diff({ learn = { a = 1 } }, { learn = { a = 2 } }, {}, out, TR)
            local ok = #notCompared == 0 and #out == 1
            return ok, string.format("nicht verglichen: %s · Änderung erkannt %s", #notCompared == 0 and "keine" or table.concat(notCompared, ", "), #out == 1 and "ja" or "nein"),
                "nicht verglichen: keine · Änderung erkannt ja"
        end)
        Chk("T337", "Z", "T-G5 Speicher und Ladezeit (Journal < 300 KB, Lernen < 1 MB)", function()
            local Fc, Ln = A.Forecast, A.Learn
            local fj, sj = Fc:Size()
            local learn = A.db.learn and Ln.SizeOf(A.db.learn) or 0
            local vs = A.db.fullScan and Ln.SizeOf(A.db.fullScan) or 0
            local lm = A.loadMs or {}
            local ok = (fj + sj) < 300 * 1024 and learn < 1024 * 1024 and vs < 2 * 1024 * 1024
            return ok, string.format("Journal %d KB · Lernen %d KB · Vollscan %d KB · Laden %s ms + %s ms", math.ceil((fj + sj) / 1024), math.ceil(learn / 1024),
                math.ceil(vs / 1024), lm.init and string.format("%.0f", lm.init) or "?", lm.ready and string.format("%.0f", lm.ready) or "?"),
                "Journal < 300 KB · Lernen < 1024 KB"
        end)
        Cli("T338", "K", "T-G6 Bereich K in allen Kombinationen", "Klassisch/Modern × 100/130 % × enGB/deDE: je /ahs testroutine k (nichts abgeschnitten/überlagert)")
        -- Messreihe Ausrüstung: nur mit Ersatz (MR.testDB, MR.API, Testitems) - nie echt einstellen
        local MR = A.SilverTest
        local function WithMR(fn)
            local saved = { api = MR.API }
            local calls = {}
            MR.testDB = {}
            MR.testItems = { gear = { itemID = 990000900, vendor = 5 }, com = { itemID = 990000901, vendor = 1 } }
            MR.API = function() return {
                PostItem = function(loc, dur, qty, bid, buyout) calls[#calls + 1] = "post:" .. tostring(buyout) .. ":" .. tostring(bid) end,
                PostCommodity = function(loc, dur, qty, price) calls[#calls + 1] = "postc:" .. tostring(price) end,
                CancelAuction = function(id) calls[#calls + 1] = "cancel:" .. tostring(id) end,
            } end
            MR.testOwn = function(row) return 4242 end
            local res = { pcall(fn, calls) }
            MR.API, MR.testDB, MR.testItems, MR.testOwn, MR.run, MR.active = saved.api, nil, nil, nil, nil, nil
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        Chk("T340", "Z", "T-AS1 Messreihe nur nach Zustimmung; jede erstellte Einstellung wird abgebrochen; Protokoll vollständig", function()
            return WithMR(function(calls)
                local okP = MR:Prepare()
                MR:Confirm()
                local guard = 0
                while MR.run and guard < 40 do
                    guard = guard + 1
                    local r = MR.run
                    local okS = MR:Step()
                    if MR.run and MR.run.wait then
                        if MR.run.wait.kind == "post" then
                            local last = MR.run.last
                            if last.kind == "gear" and last.buyout % 100 ~= 0 and not last.bid then MR:OnEvent("AUCTION_HOUSE_SHOW_ERROR", 99, "Interner Auktion-Fehler")
                            else MR:OnEvent("AUCTION_HOUSE_AUCTION_CREATED") end
                        else MR:OnEvent("AUCTION_CANCELED") end
                    end
                end
                local posts, cancels, created = 0, 0, 0
                for _, c in ipairs(calls) do if c:find("^post") then posts = posts + 1 elseif c:find("^cancel") then cancels = cancels + 1 end end
                for _, line in ipairs(MR.testDB.rows or {}) do if line:find(";erstellt;", 1, true) then created = created + 1 end end
                local ok = okP and posts == #MR.PLAN and posts <= MR.MAX_POSTS and created == cancels and #(MR.testDB.rows or {}) == #MR.PLAN
                return ok, string.format("eingestellt %d (höchstens %d) · erstellt %d · abgebrochen %d · Protokoll %d Zeilen", posts, MR.MAX_POSTS, created, cancels,
                    #(MR.testDB.rows or {})), "jede erstellte Einstellung abgebrochen, Protokoll vollständig"
            end)
        end)
        Chk("T341", "Z", "T-AS2 ohne Zustimmung: nichts eingestellt (übersprungen)", function()
            return WithMR(function(calls)
                MR:Prepare()
                local ok1, msg = MR:Step()
                local ok = not ok1 and msg == "übersprungen" and #calls == 0
                return ok, string.format("%s · Aufrufe %d", tostring(msg), #calls), "übersprungen · Aufrufe 0"
            end)
        end)
        Chk("T342", "Z", "T-AS3 Rundung ganze Silber und −1 Silber unverändert (Messreihe ändert nichts)", function()
            local Se = A.Seller
            local r0, u0 = Se.RoundPrice, Se.Undercut
            WithMR(function() MR:Prepare(); MR:Confirm(); MR:Step() end)
            local ok = Se.RoundPrice == r0 and Se.Undercut == u0
            return ok, ok and "Seller unverändert" or "Seller GEÄNDERT", "Seller unverändert (Regel: T290)"
        end)
        Chk("T343", "Z", "Offener Punkt 5: Kopf mit 1000 angekündigt, 3 Preise empfangen -> Zeiten nicht gesetzt, Anfrage wird beantwortet", function()
            local S = A.Sync
            if not (S and S.OnScanPart) then return false, "OnScanPart fehlt" end
            local saved = { hd = S.HandleData, heard = S.heardScanTime, ann = S.announced, last = A.db.sync.lastScanTimeReceived }
            local completeSeen
            S.HandleData = function(_, t, body, pk, complete) completeSeen = complete; return 0 end
            local res = { pcall(function()
                local t = time() - 60
                S.heardScanTime = 0
                S:OnScanPart("G", t, S.Enc(1000))
                S:OnScanPart("P", t, "a,b,c;d,e,f;g,h,i")
                local heard1, c1 = S.heardScanTime, completeSeen
                S:OnScanPart("G", t + 1, S.Enc(3))
                S:OnScanPart("P", t + 1, "a,b,c;d,e,f;g,h,i")
                return heard1, c1, S.heardScanTime == t + 1, completeSeen
            end) }
            S.HandleData, S.heardScanTime, S.announced = saved.hd, saved.heard, saved.ann
            A.db.sync.lastScanTimeReceived = saved.last
            if not res[1] then error(res[2], 0) end
            local heard1, c1, heard2, c2 = res[2], res[3], res[4], res[5]
            local ok = heard1 == 0 and c1 == false and heard2 and c2 == true
            return ok, string.format("1000 angekündigt, 3 da: gehört %s, vollständig %s · 3 angekündigt, 3 da: gehört %s, vollständig %s", tostring(heard1),
                tostring(c1), tostring(heard2), tostring(c2)), "gehört 0, vollständig false · gehört ja, vollständig true"
        end)
    end) end

    -- ---------------- H8 Entzauber-Wert, Meine Auktionen Summe, Sniper-Anzeige (10.11. 13:15–13:20) ----------------
    if want(part, "m") then B(function()
        local D, DEB = A.Disenchant, A.DEBuy
        if not (D and D.BatchNet and DEB and DEB.Judge) then return Skp("T351", "M", "Entzauber-Wert H8", "nicht geladen") end
        local ID, MA, MB, MC = 990002000, 990002001, 990002002, 990002003
        local PRICE = { [MA] = 677, [MB] = 1369, [MC] = 3747 }
        -- eigene Funktionen als Seams: Ausbeute, tatsächlicher Ø, Materialpreis, realistischer Preis/Absatz, Gebühr
        local function WithDE(perDayA, fn)
            local saved = { y = D.Yield, av = D.ActualValue, mp = D.MatPrice, rc = D.RealisticCap, fee = A.FeePerPiece }
            D.Yield = function(self, id) if id == ID then return { { MA, 0.75, 1.5 }, { MB, 0.20, 1.5 }, { MC, 0.05, 1.5 } }, nil, 0, 0 end return saved.y(self, id) end
            D.ActualValue = function(self, id) if id == ID then return nil end return saved.av(self, id) end
            D.MatPrice = function(self, id) if PRICE[id] then return PRICE[id], nil, PRICE[id], "market" end return saved.mp(self, id) end
            D.RealisticCap = function(self, id)
                if PRICE[id] then return PRICE[id], nil, (id == MA) and perDayA or nil end
                return saved.rc(self, id)
            end
            A.FeePerPiece = function(self, id, p) if PRICE[id] then return p * 0.05 + 50 end return saved.fee(self, id, p) end
            local res = { pcall(fn) }
            D.Yield, D.ActualValue, D.MatPrice, D.RealisticCap, A.FeePerPiece = saved.y, saved.av, saved.mp, saved.rc, saved.fee
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        Chk("T351", "M", "T-HF8 Kauf 14s, Materialien 6s 77c / 13s 69c / 37s 47c, Chancen 75/20/5, Ø 1,5 -> lohnt nicht (≈ −1s)", function()
            return WithDE(nil, function()
                local net = D:BatchNet(ID, 1)
                local profit, _, ok = DEB:Judge(ID, 1400, 1)
                local loss = net and (net - 1400)
                local good = loss and loss < 0 and loss > -300 and profit and profit < 0 and not ok
                return good, string.format("Wert nach Gebühr %s (%s je Teil) · mit Sicherheitsmarge %s · lohnt %s", A:FormatMoney(net or 0),
                    tostring(loss), tostring(profit), tostring(ok)), "Verlust 0 bis 3s je Teil · lohnt false"
            end)
        end)
        Chk("T352", "M", "T-HF8 70 Teile, Absatz Seelenstaub 20/Tag -> Materialpreis tiefer, Verlust grösser", function()
            return WithDE(20, function()
                local one = D:BatchNet(ID, 1)
                local many, _, _, steps = D:BatchNet(ID, 70)
                local p1 = DEB:Judge(ID, 1400, 1)
                local p70 = DEB:Judge(ID, 1400, 70)
                local good = one and many and many < one and steps == 2 and p1 and p70 and p70 < p1
                return good, string.format("je Teil 1: %s · 70: %s (%s Stufen) · Gewinn %s / %s", A:FormatMoney(one or 0), A:FormatMoney(many or 0),
                    tostring(steps), tostring(p1), tostring(p70)), "70 Teile tiefer (2 Stufen), Verlust grösser"
            end)
        end)
        Chk("T353", "M", "T-HF8 Abrechnung je Kauf-Charge: bezahlt, verkauft, Lager, Gebühren, Ergebnis", function()
            local Le = A.Ledger
            if not (Le and Le.DisenchantCharges and A.db.ledger) then return false, "Ledger fehlt", "Abrechnung" end
            local saved = { log = A.db.deLog, buys = A.db.deBuys, ent = A.db.ledger.entries, mp = D.MatPrice, fee = A.FeePerPiece }
            local t0 = A:DayStart(time()) + 3600
            local buys, log = {}, {}
            for i = 1, 50 do
                buys[i] = { t = t0, itemID = ID, paid = 1000, done = t0 + 100 + i }
                log[i] = { t = t0 + 100 + i, itemID = ID, paid = 1000, loot = { { MA, 2 } } }
            end
            A.db.deBuys, A.db.deLog = buys, log
            A.db.ledger.entries = {
                { kind = "sale", t = t0 + 500, itemID = MA, qty = 20, amount = 14000, cut = 700, refund = 0 },
                { kind = "sale", t = t0 + 600, itemID = MA, qty = 20, amount = 14000, cut = 700, refund = 0 },
                { kind = "sale", t = t0 + 700, itemID = MA, qty = 20, amount = 14000, cut = 700, refund = 0 },
            }
            D.MatPrice = function(self, id) if id == MA then return 700, nil, 700, "market" end return saved.mp(self, id) end
            A.FeePerPiece = function(self, id, p) if id == MA then return 35 end return saved.fee(self, id, p) end
            local res = { pcall(function()
                local c = Le:DisenchantCharges()[1]
                return c, c and Le:ChargeLine(c)
            end) }
            A.db.deLog, A.db.deBuys, A.db.ledger.entries, D.MatPrice, A.FeePerPiece = saved.log, saved.buys, saved.ent, saved.mp, saved.fee
            if not res[1] then error(res[2], 0) end
            local c, line = res[2], res[3]
            local good = c and c.paid == 50000 and c.sold == 42000 and c.stock == 26600 and c.fees == 2100 and c.result == 16500
                and line and line:find(A:FormatMoney(42000), 1, true) ~= nil
            return good, c and string.format("bezahlt %d · verkauft %d · Lager %d · Gebühren %d · Ergebnis %d · \"%s\"", c.paid, c.sold, c.stock, c.fees,
                c.result, tostring(line)) or "keine Charge", "50000 / 42000 / 26600 / 2100 / +16500"
        end)

        -- Meine Auktionen S1–S4
        local Se = A.Seller
        local function WithOwned(rows, fn)
            local tab = A.UI and A.UI:GetTab("auctions")
            if tab and not tab.panel then A.UI:SelectTab("auctions") end
            local p = tab and tab.panel
            if not (p and p.Totals and Se) then return nil, "Reiter Auktionen fehlt" end
            local saved = Se.owned
            Se.owned = rows
            local res = { pcall(function() p:Refresh(); return p.summary:GetText() or "", p.footer:GetText() or "", p:Totals(rows) end) }
            Se.owned = saved
            pcall(p.Refresh, p)
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], res[4]
        end
        local SOLD = { 10832, 8214, 7494, 5476, 5416, 4107, 1369, 1369 }
        local function Rows(withSold)
            local rows = { { buyout = 20000, status = "günstigstes", qty = 1 }, { buyout = 5000, status = "unterboten", qty = 1 } }
            if withSold then for _, b in ipairs(SOLD) do rows[#rows + 1] = { buyout = b, sold = true, status = "verkauft", qty = 1 } end end
            return rows
        end
        Chk("T354", "M", "T-MS1 8 verkaufte Zeilen -> Kopf \"8 verkauft (4g 42s 77c, erhalten 4g 20s 60c)\"", function()
            local head, _, t = WithOwned(Rows(true))
            if not head then return false, tostring(_), "Kopfzeile" end
            local want = string.format("8 verkauft (%s, erhalten %s)", A:FormatMoney(44277), A:FormatMoney(42060))
            local good = t.soldSum == 44277 and t.received == 42060 and head:find(want, 1, true) ~= nil
            return good, string.format("Summe %d · erhalten %d · \"%s\"", t.soldSum, t.received, head), want
        end)
        Chk("T355", "M", "T-MS2 keine verkauften Zeilen -> keine Summe", function()
            local head = WithOwned(Rows(false))
            if not head then return false, "Reiter fehlt", "keine Summe" end
            return head:find("erhalten", 1, true) == nil and head:find("0 verkauft", 1, true) ~= nil, head, "\"0 verkauft\" ohne Summe"
        end)
        Chk("T356", "M", "T-MS3 Fusszeile = Summe der sichtbaren Zeilen je Status", function()
            local _, foot = WithOwned(Rows(true))
            if not foot then return false, "Reiter fehlt", "Fusszeile" end
            local want = string.format(L["Summe der Liste: aktiv %s (%d) · unterboten %s (%d) · verkauft %s (%d)"],
                A:FormatMoney(25000), 2, A:FormatMoney(5000), 1, A:FormatMoney(44277), 8)
            return foot == want, foot, want
        end)

        -- Sniper SN1–SN4
        local Sn = A.Sniper
        Chk("T357", "M", "T-SN1 23 Zeilen \"gekauft\" zu 10s -> \"gekauft: 23 Stück für 2g 30s\"", function()
            local r = { listings = {}, missedStart = (Sn:Stats().missed or 0) - 13 }
            for i = 1, 23 do r.listings[i] = { price = 1000, buyout = 1000, qty = 1, used = 1 } end
            for i = 24, 30 do r.listings[i] = { price = 1000, buyout = 1000, qty = 1 } end
            local n, sum, missed = Sn:ResultBought(r)
            local text = string.format(L["Ergebnis ist veraltet – in dieser Suche gekauft: %d Stück für %s · verpasst %d – neue Suche nötig."], n, A:FormatMoney(sum), missed)
            local good = n == 23 and sum == 23000 and missed == 13 and text:find("23", 1, true) ~= nil
            return good, text, "23 Stück für 2g 30s · verpasst 13"
        end)
        Chk("T358", "M", "T-SN2 Menge 100, Budget 5g, Max 10s, 50 gekauft -> \"50/100 gekauft · Budget 5g aufgebraucht\" + Hinweis", function()
            local t = { qty = 100, budget = 50000, maxPrice = 1000, bought = 50, spent = 50000 }
            local line = Sn:ProgressText(t)
            local want = string.format(L["%d/%d gekauft"], 50, 100) .. " · " .. string.format(L["Budget %s aufgebraucht"], A:FormatMoney(50000, true))
            local t2 = { qty = 100, budget = 50000, maxPrice = 1000, bought = 21, spent = 21000 }
            local line2 = Sn:ProgressText(t2)
            local note = Sn:BudgetText(t)
            local good = line == want and Sn:BudgetUsedUp(t) and not Sn:BudgetUsedUp(t2) and Sn:BudgetPieces(t) == 50
                and line2:find(A:FormatMoney(29000, true), 1, true) ~= nil and note:find("50", 1, true) ~= nil
            return good, string.format("\"%s\" · \"%s\" · \"%s\" · höchstens %d Stück", line, line2, note, Sn:BudgetPieces(t)), want
        end)

        -- W1 (Befund 10.11. 13:50): Reset-/Wiederherstellen-Tests nur auf Ersatztabellen - die echte Sicherung bleibt dieselbe
        Chk("T360", "M", "T-W1 Entzaubern zurücksetzen im Test: echte deStats/deShared/deLog/deBuys/deBackup unverändert", function()
            local db = A.db
            local real, before = {}, TR.DEPrint(db)
            for _, k in ipairs(TR.DE_KEYS) do real[k] = db[k] end
            local bkN = type(db.deBackup) == "table" and #db.deBackup or -1
            local inside = TR.DESandbox(function()
                A.Disenchant:Reset()
                local n = #(db.deBackup or {})
                A.Disenchant:RestoreBackup()
                return n
            end)
            local same = true
            for _, k in ipairs(TR.DE_KEYS) do if db[k] ~= real[k] then same = false end end
            local bkN2 = type(db.deBackup) == "table" and #db.deBackup or -1
            local ok = same and bkN == bkN2 and TR.DEPrint(db) == before and inside >= 1
            return ok, string.format("Ersatz-Sicherung %d · echte Tabellen %s · deBackup %d -> %d · Fingerabdruck %s", inside,
                same and "dieselben" or "GETAUSCHT", bkN, bkN2, TR.DEPrint(db) == before and "gleich" or "ANDERS"), "echte Tabellen dieselben, Fingerabdruck gleich"
        end)
        -- LG1–LG5 (Befund Buchhaltung 10.11. 14:05/14:15): Lagerwert, im AH, Entzauber-Abrechnung, Käufe genau einmal
        local Le = A.Ledger
        local STU, DUST, SHARD, ASTRAL = 990003001, 990003002, 990003003, 990003004
        local UNIT = { [STU] = 1000, [DUST] = 677, [SHARD] = 3747, [ASTRAL] = 1369 }
        -- X2 (Befund 0.65.86): ersetzt ALLE Quellen der Lager-Rechnung - auch ownedEnds, das Journal und den Zeitpunkt der
        -- Abfrage der eigenen Auktionen. owned = nil heisst "nie abgefragt"; opts.ownedEnds / opts.journal (P-Einträge)
        local function WithStock(bags, owned, fn, opts)
            opts = opts or {}
            local Ch, Se, Fc = A.Chars, A.Seller, A.Forecast
            local saved = { me = Ch and Ch.Me, owned = Se and Se.owned, otime = Se and Se.ownedTime, ends = A.db.ownedEnds,
                usv = Le.UnitStockValue, cache = Le.unitCache, ent = A.db.ledger.entries,
                booked = Le.bookedAuctions, lp = A.Sniper and A.Sniper.lastPurchase, bp = A.Buy and A.Buy.lastPurchase, log = A.db.deLog, buys = A.db.deBuys,
                mp = A.Disenchant.MatPrice, fee = A.FeePerPiece }
            if Ch then Ch.Me = function() return { bags = bags, bank = {} } end end
            if Se then
                Se.owned = owned or {}
                Se.ownedTime = owned and GetTime() or nil
            end
            A.db.ownedEnds = opts.ownedEnds or {}
            Le.UnitStockValue = function(self, id) if UNIT[id] then return UNIT[id] end return saved.usv(self, id) end
            Le.unitCache, Le.bookedAuctions = {}, {}
            A.db.ledger.entries = {}
            if Fc then
                Fc.testStore = {}
                local f = Fc:Store()
                for _, e in ipairs(opts.journal or {}) do table.insert(f.list, Fc:Encode("P", e)) end
            end
            local res = { pcall(fn) }
            if Ch then Ch.Me = saved.me end
            A.db.ownedEnds = saved.ends
            if Se then Se.owned, Se.ownedTime = saved.owned, saved.otime end
            Le.UnitStockValue, Le.unitCache, A.db.ledger.entries, Le.bookedAuctions = saved.usv, saved.cache, saved.ent, saved.booked
            if A.Sniper then A.Sniper.lastPurchase = saved.lp end
            if A.Buy then A.Buy.lastPurchase = saved.bp end
            A.db.deLog, A.db.deBuys, A.Disenchant.MatPrice, A.FeePerPiece = saved.log, saved.buys, saved.mp, saved.fee
            if Fc then Fc.testStore, Fc.evalCache = nil, nil end
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        Chk("T364", "M", "T-LG1 26 Stulpen, 14 Seelenstaub, 3 Splitter im Lager, keine Auktionen -> Lager positiv (≈ 4g 67s)", function()
            return WithStock({ [STU] = 26, [DUST] = 14, [SHARD] = 3 }, {}, function()
                local v, ah = Le:StockValue()
                local want = 26 * 1000 + 14 * 677 + 3 * 3747
                return v == want and ah == 0, string.format("Lager %s (im AH %s)", A:FormatMoney(v), A:FormatMoney(ah)), A:FormatMoney(want) .. ", im AH 0"
            end)
        end)
        Chk("T365", "M", "T-LG2 10 Astralessenz aktiv im AH zu 13s 69c -> \"davon im AH\" = Angebotspreis × 0,95", function()
            return WithStock({ [STU] = 26 }, { { itemID = ASTRAL, qty = 10, buyout = 13690, status = "günstigstes" } }, function()
                local v, ah = Le:StockValue()
                local ok = ah == 13005 and v == 26000 + 13005
                return ok, string.format("Lager %s, davon im AH %s", A:FormatMoney(v), A:FormatMoney(ah)), "davon im AH " .. A:FormatMoney(13005)
            end)
        end)
        -- X2 (Befund 0.65.86): "abgefragt, leer" ist eine echte Antwort; nur "nie abgefragt" nimmt ownedEnds/Journal
        Chk("T418", "M", "T-X2a eigene Auktionen abgefragt und leer, ownedEnds und Journal mit alten Einträgen -> im AH 0", function()
            local now = time()
            return WithStock({ [STU] = 26 }, {}, function()
                local v, ah = Le:StockValue()
                return ah == 0 and v == 26000, string.format("Lager %s (im AH %s)", A:FormatMoney(v), A:FormatMoney(ah)), A:FormatMoney(26000) .. ", im AH 0"
            end, { ownedEnds = { { itemID = DUST, qty = 5, endsAt = now + 3600 } },
                journal = { { t = now - 600, id = SHARD, q = 2, a = 1, pr = 5000, d = 24 } } })
        end)
        Chk("T419", "M", "T-X2b nie abgefragt, Journal mit 2 laufenden Einstellungen -> beide im AH (LG8 bleibt)", function()
            local now = time()
            return WithStock({}, nil, function()
                local _, ah = Le:StockParts()
                return ah[DUST] == 3 and ah[SHARD] == 2, string.format("im AH Staub %s, Splitter %s", tostring(ah[DUST]), tostring(ah[SHARD])), "3 und 2"
            end, { journal = { { t = now - 600, id = DUST, q = 3, a = 1, pr = 700, d = 24 }, { t = now - 300, id = SHARD, q = 2, a = 1, pr = 5000, d = 24 } } })
        end)
        Chk("T366", "M", "T-LG3 Entzauber-Abrechnung: Kauf, Beute verkauft / im AH / Lager, Ergebnis", function()
            return WithStock({}, { { itemID = DUST, qty = 20, buyout = 14000 } }, function()
                local t0 = A:DayStart(time()) + 3600
                local buys, log = {}, {}
                for i = 1, 50 do
                    buys[i] = { t = t0, itemID = 990003010, paid = 1000, done = t0 + 100 + i }
                    log[i] = { t = t0 + 100 + i, itemID = 990003010, paid = 1000, loot = { { DUST, 2 } } }
                end
                A.db.deBuys, A.db.deLog = buys, log
                A.db.ledger.entries = { { kind = "sale", t = t0 + 500, itemID = DUST, qty = 60, amount = 42000, cut = 2100, refund = 0 } }
                A.Disenchant.MatPrice = function(self, id) if id == DUST then return 700, nil, 700, "market" end return nil end
                A.FeePerPiece = function(self, id, p) return 35 end
                local ch = Le:DisenchantCharges()
                local c = ch[1]
                local tl = Le:ChargeTotalLine(Le:ChargeTotal(ch))
                -- 100 Staub: 60 verkauft (42000, Gebühr 2100), 20 im AH (14000 × 0,95 = 13300), 20 Lager (20 × 665 = 13300)
                local ok = c and c.sold == 42000 and c.inAH == 13300 and c.stock == 13300 and c.result == 42000 + 13300 + 13300 - 2100 - 50000
                    and tl:find(A:FormatMoney(13300), 1, true) ~= nil
                return ok, c and string.format("verkauft %d · im AH %d · Lager %d · Ergebnis %d · \"%s\"", c.sold, c.inAH, c.stock, c.result, tl) or "keine Charge",
                    "42000 · 13300 · 13300 · Ergebnis +16500"
            end)
        end)
        Chk("T367", "M", "T-LG4 Sniper-Kauf 1× 10s + Rechnung 1× 10s -> genau 1 Kauf, 10s", function()
            return WithStock({}, {}, function()
                local lp = { itemID = STU, qty = 1, cost = 1000, time = GetTime(), listing = { auctionID = 4711 } }
                A.Sniper.lastPurchase = lp
                Le:OnPurchaseEvent("AUCTION_HOUSE_PURCHASE_COMPLETED", 4711)
                Le:OnPurchaseEvent("AUCTION_HOUSE_PURCHASE_COMPLETED", 4711)        -- zweites Ereignis: nichts
                A:Fire("SNIPER_PURCHASE_DONE", lp)                                  -- zweiter Weg: nichts
                local m = Le:FindUnmatchedBuy(STU, "x", 1, 1000, time() + 3600)      -- Rechnung findet die Kaufmeldung
                if m then m.mail = true end
                local n, sum = 0, 0
                for _, e in ipairs(A.db.ledger.entries) do if e.kind == "buy" then n = n + e.qty; sum = sum + e.amount end end
                local dbl = #Le:FindDoubleBuys()
                return n == 1 and sum == 1000 and m ~= nil and dbl == 0, string.format("%d Kauf, %s · Rechnung zugeordnet %s · Doppelte %d", n,
                    A:FormatMoney(sum), tostring(m ~= nil), dbl), "1 Kauf, 10s · zugeordnet · 0 Doppelte"
            end)
        end)
        Chk("T368", "M", "T-LG5 50 Sniper-Käufe à 10s -> Pro Item 50 / 5g", function()
            return WithStock({}, {}, function()
                for i = 1, 50 do
                    local lp = { itemID = STU, qty = 1, cost = 1000, time = GetTime(), listing = { auctionID = 5000 + i } }
                    A.Sniper.lastPurchase = lp
                    Le:OnPurchaseEvent("AUCTION_HOUSE_PURCHASE_COMPLETED", 5000 + i)
                    if i % 2 == 0 then Le:OnPurchaseEvent("AUCTION_HOUSE_PURCHASE_COMPLETED", 5000 + i - 1) end   -- verspätetes Ereignis
                end
                local row
                for _, r in ipairs(Le:ByItem("today")) do if r.itemID == STU then row = r end end
                local ok = row and row.boughtQty == 50 and row.spent == 50000
                return ok, row and string.format("gekauft %d für %s", row.boughtQty, A:FormatMoney(row.spent)) or "keine Zeile", "50 für 5g"
            end)
        end)
        -- SP1–SP4 (Befund Sperrliste 10.11. 14:10): nur Ersatztabelle für deBlock, Taschen über eigene Seams
        local DW = A.DEWindow
        local function WithDW(nItems, fn)
            local saved = { block = A.db.deBlock, ns = DW.NumSlots, si = DW.SlotInfo, es = DW.InEquipmentSet, qi = DW.IsQuestItem, prior = A.Disenchant.Prior,
                skipped = DW.skipped, pr = A.Print, never = A.db.deNever, dg = A.Diag and A.Diag.Add }
            if A.Diag then A.Diag.Add = function() end end                    -- keine Testzeilen im echten Protokoll
            A.db.deBlock = {}
            A.db.deNever = { items = {}, classes = {}, classFails = {} }       -- Punkt 3: "freigeben" leert auch deNever - nie die echte
            DW.skipped = {}
            DW.NumSlots = function(_, bag) return bag == 0 and nItems or 0 end
            DW.SlotInfo = function(_, bag, slot) if bag == 0 and slot <= nItems then return { itemID = 990005000 + slot, quality = 2, icon = 134400 } end end
            DW.InEquipmentSet = function() return false end
            DW.IsQuestItem = function() return false end
            A.Disenchant.Prior = function(self, id, ...) if id and id > 990005000 and id <= 990005100 then return { { 10940, 1, 1 } }, "2:1:a" end return saved.prior(self, id, ...) end
            local printed = {}
            A.Print = function(_, m) printed[#printed + 1] = tostring(m) end
            local res = { pcall(fn, printed) }
            A.db.deBlock, DW.NumSlots, DW.SlotInfo, DW.InEquipmentSet, DW.IsQuestItem, A.Disenchant.Prior, DW.skipped, A.Print =
                saved.block, saved.ns, saved.si, saved.es, saved.qi, saved.prior, saved.skipped, saved.pr
            A.db.deNever = saved.never
            if A.Diag then A.Diag.Add = saved.dg end
            if DW.askFrame then DW.askFrame:Hide() end
            if DW.listFrame then DW.listFrame:Hide() end
            pcall(DW.Refresh, DW)
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        local function Click(b) local f = b and b.GetScript and b:GetScript("OnClick"); if f then f(b, "LeftButton") end end
        Chk("T380", "M", "T-SP1 Rechtsklick -> Rückfrage; \"Nur diesmal\" -> nicht auf der Sperrliste", function()
            return WithDW(2, function()
                local cur = DW:Current()
                local q = DW:AskBlock(cur)
                local shown = q and q:IsShown()
                Click(q.once)
                local ok = shown and not DW:IsBlocked(cur.itemID) and DW.skipped["0:1:" .. cur.itemID] == true and not q:IsShown()
                return ok, string.format("Rückfrage %s · gesperrt %s · übersprungen %s", tostring(shown), tostring(DW:IsBlocked(cur.itemID)),
                    tostring(DW.skipped["0:1:" .. cur.itemID])), "Rückfrage · nicht gesperrt · übersprungen"
            end)
        end)
        Chk("T381", "M", "T-SP2 Gesperrtes Item in \"Gesperrt (1)\" -> Freigeben -> erscheint wieder", function()
            return WithDW(1, function()
                local id = 990005001
                DW:SetBlocked(id, true)
                local before = DW:Current()
                local l = DW:ToggleBlockList(true)
                local title = l.title:GetText()
                Click(l.rows[1].btn)
                local after = DW:Current()
                local ok = before == nil and title == string.format(L["Gesperrt (%d)"], 1) and after and after.itemID == id
                return ok, string.format("vorher %s · Liste \"%s\" · nachher %s", before and "da" or "weg", tostring(title), after and "da" or "weg"), "weg · Gesperrt (1) · da"
            end)
        end)
        Chk("T382", "M", "T-SP3 Fenster leer, 5 gesperrte Items in der Tasche -> Hinweis mit Zahl", function()
            return WithDW(5, function()
                for k = 1, 5 do DW:SetBlocked(990005000 + k, true) end
                local nb, ns = DW:HiddenCounts()
                local f = DW:Build()
                local txt = ""
                if f then DW:Refresh(); txt = f.count:GetText() or "" end
                local ok = nb == 5 and ns == 0 and (not f or txt:find("5", 1, true) ~= nil)
                return ok, string.format("gesperrt %d · übersprungen %d · \"%s\"", nb, ns, txt), "5 gesperrt im Hinweis"
            end)
        end)
        Chk("T383", "M", "T-SP4 /ahs entzaubern freigeben leert die Sperrliste", function()
            return WithDW(3, function(printed)
                for k = 1, 3 do DW:SetBlocked(990005000 + k, true) end
                local n = DW:Command("freigeben")
                local ok = n == 3 and #DW:BlockedList() == 0 and (printed[1] or ""):find("3", 1, true) ~= nil
                return ok, string.format("freigegeben %s · Liste %d · \"%s\"", tostring(n), #DW:BlockedList(), printed[1] or "-"), "3 · 0"
            end)
        end)
        -- Punkt 3 (offen 11.11.): gelernte Sperre je Item, Klasse erst ab 3 verschiedenen Items; deNever sichtbar und freigebbar
        Chk("T423", "M", "T-ME10 ein Lederteil scheitert -> nur dieses Item gesperrt; erst 3 verschiedene -> Klasse 4:2 gesperrt", function()
            return WithDW(0, function()
                local D = A.Disenchant
                local savedIC = D.ItemClass
                D.ItemClass = function(self, id) if id and id > 990005000 and id <= 990005100 then return 4, 2 end return savedIC(self, id) end
                local res = { pcall(function()
                    D:MarkNever(990005011)
                    local a1, b1 = D:IsNeverDE(990005011, 4, 2), D:IsNeverDE(990005012, 4, 2)
                    D:MarkNever(990005012)
                    D:MarkNever(990005013)
                    local c3 = D:IsNeverDE(990005099, 4, 2)
                    return a1, b1, c3
                end) }
                D.ItemClass = savedIC
                if not res[1] then error(res[2], 0) end
                local ok = res[2] == true and res[3] == false and res[4] == true
                return ok, string.format("Item gesperrt %s · anderes Leder nach 1 Fehlschlag %s · nach 3 verschiedenen %s", tostring(res[2]), tostring(res[3]), tostring(res[4])),
                    "true · false (erlaubt) · true (Klasse)"
            end)
        end)
        Chk("T424", "M", "T-ME11 deNever in \"Gesperrt (N)\" (nicht entzauberbar), Freigeben je Zeile; /ahs entzaubern freigeben leert deNever", function()
            return WithDW(0, function()
                local D = A.Disenchant
                local savedIC = D.ItemClass
                D.ItemClass = function(self, id) if id and id > 990005000 and id <= 990005100 then return 4, 2 end return savedIC(self, id) end
                local res = { pcall(function()
                    D:MarkNever(990005021)
                    D:MarkNever(990005022)
                    DW:SetBlocked(990005023, true)
                    local n1 = #DW:ListEntries()
                    local l = DW:ToggleBlockList(true)
                    local title = l and l.title and l.title:GetText() or ""
                    local rowTxt = l and l.rows and l.rows[2] and l.rows[2].name:GetText() or ""
                    DW:ReleaseEntry({ kind = "never", itemID = 990005021 })
                    local after1 = D:IsNeverDE(990005021, 4, 2)
                    local n = DW:Command("freigeben")
                    return n1, title, rowTxt, after1, n, #DW:ListEntries(), D:IsNeverDE(990005022, 4, 2)
                end) }
                D.ItemClass = savedIC
                if not res[1] then error(res[2], 0) end
                local n1, title, rowTxt, after1, n, n2, still = res[2], res[3], res[4], res[5], res[6], res[7], res[8]
                local ok = n1 == 3 and tostring(title):find("3", 1, true) ~= nil and after1 == false and n == 2 and n2 == 0 and still == false
                return ok, string.format("Liste %d (\"%s\") · Zeile \"%s\" · nach Freigeben %s · freigegeben %s · danach %d · gesperrt %s", n1, tostring(title),
                    A:PlainText(tostring(rowTxt)), tostring(after1), tostring(n), n2, tostring(still)), "3 · Gesperrt (3) · false · 2 · 0 · false"
            end)
        end)
        -- K1–K3 (Entscheid 10.11. 15:59: Markt höchstens 25 % des Golds; Absatz unplausibel)
        Chk("T386", "M", "T-K1 Gold 15g 52s, Vorschläge mit Bedarf 6g 50s -> gekürzt auf ≤ 3g 88s, Fusszeile \"(höchstens 25 %)\"", function()
            local s0 = A.db.settings.marketCapital
            A.db.settings.marketCapital = nil
            local money = 155274
            local rows = {
                { price = 1000, qty = 30, unitGold = 200, gold = 6000, retext = function(q) return q .. "x A" end, text = "30x A" },
                { price = 500, qty = 70, unitGold = 50, gold = 3500, retext = function(q) return q .. "x B" end, text = "70x B" },
            }
            local out, used = A.MarketView:CapRows(rows, money)
            local foot = string.format(L["Kapitalbedarf: %s von %s (höchstens %d %%)"], A:FormatMoney(used), A:FormatMoney(money), A:MarketCapitalPct())
            A.db.settings.marketCapital = s0
            local ok = used <= math.floor(money * 0.25) and #out == 2 and out[2].qty == 17 and out[2].text == "17x B" and foot:find("25", 1, true) ~= nil
            return ok, string.format("Bedarf %s · Zeilen %d · B gekürzt auf %s · \"%s\"", A:FormatMoney(used), #out, tostring(out[2] and out[2].qty), foot),
                "≤ 3g 88s · 2 Zeilen · B 17 Stück"
        end)
        Chk("T387", "M", "T-K2 Ausrüstung, Absatz gemessen 2346/Tag, Ø-Menge 200 -> unplausibel, Rückfall auf Schätzung, Protokollzeile", function()
            local VS = A.FullScan
            if not VS then return false, "Vollscan fehlt", "unplausibel" end
            local ID2 = 990006001
            local now = math.floor(time())
            local saved = { data = VS.Data, cf = VS.CancelFactor, liq = A.GetLiquidity, cur = A.GetCurrent, dg = A.Diag and A.Diag.Add, noted = A.implausibleNoted[ID2] }
            local diag = {}
            VS.Data = function() return { sold = { [ID2] = string.format("2346;5;%d;%d;100;0;0;0;0;", now - 4 * 86400, now) } } end
            VS.CancelFactor = function() return 1 end
            A.GetLiquidity = function(self, id) if id == ID2 then return { avgQty = 200, perDay = 30 } end return saved.liq(self, id) end
            A.GetCurrent = function(self, id) if id == ID2 then return 1000, 200, time() end return saved.cur(self, id) end
            if A.Diag then A.Diag.Add = function(_, k, t) diag[#diag + 1] = k .. " " .. t end end
            A.implausibleNoted[ID2] = nil
            local res = { pcall(function()
                local m = VS:MeasuredRate(ID2)
                local pd, src = A:PerDayInfo(ID2)
                return m, pd, src
            end) }
            VS.Data, VS.CancelFactor, A.GetLiquidity, A.GetCurrent = saved.data, saved.cf, saved.liq, saved.cur
            if A.Diag then A.Diag.Add = saved.dg end
            A.implausibleNoted[ID2] = saved.noted
            if not res[1] then error(res[2], 0) end
            local m, pd, src = res[2], res[3], res[4]
            local line = diag[1] or ""
            local ok = m == nil and pd == 30 and src == L["geschätzt"] and line:find("ABSATZ-UNPLAUSIBEL", 1, true) ~= nil
            return ok, string.format("gemessen %s · genutzt %s (%s) · \"%s\"", tostring(m), tostring(pd), tostring(src), line), "gemessen nil · 30 geschätzt · ABSATZ-UNPLAUSIBEL"
        end)
        Chk("T388", "M", "T-K3 Option 25 % -> 40 %: Bedarf bis 40 %; Eingabe 80 % -> 50 %", function()
            local s0 = A.db.settings.marketCapital
            local a = A:SetMarketCapitalPct(40)
            local capA = A.MarketView:CapRows({ { price = 100, qty = 1000, unitGold = 1, retext = function(q) return tostring(q) end } }, 10000)
            local b = A:SetMarketCapitalPct(80)
            local c = A:SetMarketCapitalPct("abc")
            A.db.settings.marketCapital = s0
            local ok = a == 40 and capA[1].qty == 40 and b == 50 and c == 25
            return ok, string.format("40 -> %s (Stück %s) · 80 -> %s · ungültig -> %s", tostring(a), tostring(capA[1] and capA[1].qty), tostring(b), tostring(c)), "40 (40 Stück) · 50 · 25"
        end)

        -- Markt-Ansicht "Entzaubern" (Anweisung 10.11. 16:20, T-ME1–T-ME7) - nur eigene Seams, keine echten Tabellen
        local MVx, Dx = A.MarketView, A.Disenchant
        local STU2, SD, AE, GS = 990007001, 990007002, 990007003, 990007004
        local MP = { [SD] = 677, [AE] = 1369, [GS] = 3700 }
        local function WithME(cfg, fn)
            local saved = { y = Dx.Yield, av = Dx.ActualValue, mp = Dx.MatPrice, fee = A.FeePerPiece, lad = A.OfferLadder, pdi = A.PerDayInfo,
                sc = A.Ledger.StockCounts, fb = A.FlipBlocked, ph = A.PriceHints, min = A.db.settings.deMinGain, cap = A.db.settings.marketCapital,
                money = MVx.Money, bi = A.BuyoutInfo, sm = Dx.StaleMain }
            Dx.StaleMain = function(self, id) if id == STU2 then return cfg.stale or false end return saved.sm(self, id) end   -- MP2: Preise frisch
            MVx.Money = function() return cfg.money or 1e9 end           -- D2: Gold des Tests (Standard: Budget reicht)
            A.BuyoutInfo = function(self, id) if MP[id] or id == STU2 then return cfg.buyout and cfg.buyout[id] or nil end return saved.bi(self, id) end
            Dx.Yield = function(self, id) if id == STU2 then return { { SD, 0.676, 1.46 }, { AE, 0.218, 1.52 }, { GS, 0.106, 1.0 } }, nil, 0, 0 end return saved.y(self, id) end
            Dx.ActualValue = function(self, id) if id == STU2 then return nil end return saved.av(self, id) end
            Dx.MatPrice = function(self, id) if MP[id] then return MP[id], nil, MP[id], "ah", false, false, { hints = {} } end return saved.mp(self, id) end
            A.FeePerPiece = function(self, id, p) if MP[id] then return p * 0.05 + 70 end return saved.fee(self, id, p) end
            A.OfferLadder = function(self, id) if id == STU2 then return cfg.ladder end return saved.lad(self, id) end
            A.PerDayInfo = function(self, id) if MP[id] then return cfg.perDay and cfg.perDay[id] or 1000, "gemessen" end return saved.pdi(self, id) end
            A.Ledger.StockCounts = function() return cfg.have or {} end
            A.FlipBlocked = function(self, id) if MP[id] then return nil end return saved.fb(self, id) end
            A.PriceHints = function(self, id) if MP[id] then return {} end return saved.ph(self, id) end
            A.db.settings.deMinGain, A.db.settings.marketCapital = cfg.min, nil
            MVx.haveCache = nil
            local res = { pcall(fn) }
            Dx.Yield, Dx.ActualValue, Dx.MatPrice, A.FeePerPiece, A.OfferLadder, A.PerDayInfo = saved.y, saved.av, saved.mp, saved.fee, saved.lad, saved.pdi
            A.Ledger.StockCounts, A.FlipBlocked, A.PriceHints = saved.sc, saved.fb, saved.ph
            A.db.settings.deMinGain, A.db.settings.marketCapital = saved.min, saved.cap
            MVx.Money, A.BuyoutInfo, Dx.StaleMain = saved.money, saved.bi, saved.sm
            MVx.haveCache, MVx.cache.de = nil, nil
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        Chk("T392", "M", "T-ME1 Bronzene Stulpen 10s (94 Stück), Staub 6s 77c / Essenz 13s 69c / Splitter 37s -> Gewinn ≥ 20 %, Zeile da, \"lohnt bis\" ≈ 11s", function()
            return WithME({ ladder = { { 1000, 94 }, { 1500, 20 } } }, function()
                local r = MVx:DEOffer(STU2, 1000, 94)
                local ok = r and r.net >= 1250 and r.net <= 1400 and r.pct >= 20 and r.upto >= 1040 and r.upto <= 1170 and r.qty == 94
                return ok, r and string.format("Wert %s · Gewinn %d %% · lohnt bis %s · %d Stück", A:FormatMoney(r.net), math.floor(r.pct + 0.5), A:FormatMoney(r.upto), r.qty) or "keine Zeile",
                    "Wert ≈ 13s · ≥ 20 % · lohnt bis ≈ 10s 9xc–11s · 94 Stück"
            end)
        end)
        Chk("T393", "M", "T-ME2 gleiches Item zu 17s -> keine Zeile", function()
            return WithME({ ladder = { { 1700, 94 } } }, function()
                local r, why = MVx:DEOffer(STU2, 1700, 94)
                return r == nil, "Zeile " .. (r and "da" or ("keine (" .. tostring(why) .. ")")), "keine Zeile"
            end)
        end)
        Chk("T394", "M", "T-ME3 Staub-Absatz 300/Tag, 50 Teile -> keine Kürzung; Absatz 30/Tag, 40 Teile -> gekürzt, gelber Hinweis", function()
            return WithME({ ladder = { { 1000, 50 } }, perDay = { [SD] = 300 } }, function()
                local a = MVx:DEOffer(STU2, 1000, 50)
                local b = WithME({ ladder = { { 1000, 40 } }, perDay = { [SD] = 30 } }, function() return MVx:DEOffer(STU2, 1000, 40) end)
                local ok = a and a.qty == 50 and not a.slow and b and b.qty < 40 and b.qty >= 1 and b.slow == SD and b.text:find(L["Material verkauft sich langsamer als deine Menge"], 1, true) ~= nil
                return ok, string.format("300/Tag: %s Stück · 30/Tag: %s Stück, Hinweis %s", tostring(a and a.qty), tostring(b and b.qty), tostring(b and b.slow ~= nil)), "50 · < 40 mit Hinweis"
            end)
        end)
        Chk("T395", "M", "T-ME4 Gold 15g -> Kapitalbedarf der Vorschläge ≤ 3g 75s", function()
            return WithME({ ladder = { { 1000, 94 } } }, function()
                local r = MVx:DEOffer(STU2, 1000, 94)
                local rows, used = MVx:CapRows({ r }, 150000)
                return used <= 37500 and rows[1] and rows[1].qty == 37, string.format("Bedarf %s · %s Stück", A:FormatMoney(used), tostring(rows[1] and rows[1].qty)), "≤ 3g 75s · 37 Stück"
            end)
        end)
        Chk("T396", "M", "T-ME5 Fertigkeit zu niedrig bzw. kein Verzauberer -> nicht entzauberbar", function()
            local saved = { es = Dx.EnchantSkill, rs = Dx.RequiredSkill }
            Dx.RequiredSkill = function() return 100 end
            Dx.EnchantSkill = function() return 50 end
            local low = Dx:CanDisenchant(STU2)
            Dx.EnchantSkill = function() return 0 end
            local none = Dx:CanDisenchant(STU2)
            Dx.EnchantSkill = function() return 150 end
            local high = Dx:CanDisenchant(STU2)
            Dx.EnchantSkill, Dx.RequiredSkill = saved.es, saved.rs
            local ok = low == false and none == false and high == true and Dx:RequiredSkill(30) == 50 and Dx:RequiredSkill(60) == 200
            return ok, string.format("50 von 100: %s · kein Verzauberer: %s · 150: %s", tostring(low), tostring(none), tostring(high)), "false · false · true"
        end)
        Chk("T397", "M", "T-ME6 Option Mindestgewinn 30 % -> Zeilen mit 20–29 % fallen weg", function()
            return WithME({ ladder = { { 1100, 94 } }, min = 30 }, function()
                local r30 = MVx:DEOffer(STU2, 1100, 94)
                A.db.settings.deMinGain = 20
                -- RK2-B: "lohnt bis" = eine Rechnung (gelernte Startmarge 20 % wäre strenger) -> hier ohne Lernen gemessen
                local Ln = A.Learn
                if Ln then Ln.forceOff = true end
                local okR, r20 = pcall(MVx.DEOffer, MVx, STU2, 1100, 94)
                if Ln then Ln.forceOff = nil end
                if not okR then error(r20, 0) end
                local p80 = MVx:SetDEMinPct(80)
                local ok = r30 == nil and r20 ~= nil and r20.pct < 30 and p80 == 50
                return ok, string.format("30 %%: %s · 20 %%: %s (%s %%) · 80 -> %d", r30 and "da" or "weg", r20 and "da" or "weg", r20 and math.floor(r20.pct) or "-", p80), "weg · da (20–29 %) · 50"
            end)
        end)
        Chk("T398", "M", "T-ME7 Zeile wählen, Menge 50 -> Fusszeile nur der aktuelle Kauf (50 Stück · 5g · Gewinn · ≈ Staub)", function()
            return WithME({ ladder = { { 1000, 50 } } }, function()
                local r = MVx:DEOffer(STU2, 1000, 50)
                local foot = MVx:DEFooter(r)
                local none = MVx:DEFooter(nil)
                local ok = r and foot:find("50", 1, true) and foot:find(A:FormatMoney(50000), 1, true) and foot:find("≈ 49", 1, true) ~= nil
                    and none == L["Zeile wählen – hier steht dann der aktuelle Kauf."]
                return ok, string.format("\"%s\" · ohne Auswahl \"%s\"", foot, none), "50 Stück · 5g · erwarteter Gewinn … · ≈ 49 Staub"
            end)
        end)
        -- D1–D6 (befund-markt-entzaubern-menge): Wert je Teil vorgegeben (D:PlannedValue), Preisleiter vorgegeben
        local function WithMD(cfg, fn)
            local savedPV, savedII = Dx.PlannedValue, MVx.ItemInfo
            Dx.PlannedValue = function(self, id, n)
                if id == STU2 then
                    local net = cfg.net
                    if cfg.drop and n and n > 1 then net = net - cfg.drop * n end
                    return net, cfg.basis or "actual", 20, net
                end
                return savedPV(self, id, n)
            end
            MVx.ItemInfo = function(self, id) if id == STU2 then return 2, cfg.ilvl end return savedII(self, id) end
            local res = { pcall(WithME, cfg, fn) }
            Dx.PlannedValue, MVx.ItemInfo = savedPV, savedII
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        local LADDER_MD = { { 900, 1 }, { 1200, 30 }, { 1400, 9 } }
        Chk("T431", "M", "T-MD1 Leiter 1×9s, 30×12s, 9×14s, Wert 18s 55c -> 40 Stück, Kosten 4g 95s, Gewinn 2g 47s (je Stufe), Rendite gesamt", function()
            return WithMD({ ladder = LADDER_MD, net = 1855, min = 20 }, function()
                local r = MVx:DEOffer(STU2, 900, 40)
                local ok = r and r.qty == 40 and r.cost == 49500 and r.profit == 24700 and math.abs(r.pct - 24700 / 49500 * 100) < 0.01
                    and r.text:find(A:FormatMoney(r.upto), 1, true) ~= nil and r.text:find(A:FormatMoney(1238), 1, true) ~= nil
                return ok, r and string.format("%d Stück · Kosten %s · Gewinn %s (%d %%) · \"%s\"", r.qty, A:FormatMoney(r.cost), A:FormatMoney(r.profit),
                    math.floor(r.pct + 0.5), A:PlainText(r.text)) or "keine Zeile", "40 · 4g 95s · 2g 47s (50 %) · bis … (Ø 12s 38c)"
            end)
        end)
        Chk("T432", "M", "T-MD2 Gold 14g 51s -> Kosten ≤ 3g 62s 75c (25 %), Sniper-Budget = genau diese Kosten, Höchstpreis = lohnt bis", function()
            return WithMD({ ladder = LADDER_MD, net = 1855, min = 20, money = 145100 }, function()
                local r = MVx:DEOffer(STU2, 900, 40)
                local Sn = A.Sniper
                local savedST, got = Sn.SetTarget, nil
                Sn.SetTarget = function(_, key, maxP, qty, budget) got = { key = key, max = maxP, qty = qty, budget = budget }; return true end
                local savedCur = MVx.deCurrent
                local okB = pcall(MVx.BuyDE, MVx, r)
                Sn.SetTarget, MVx.deCurrent = savedST, savedCur
                local ok = okB and r and r.cost <= 36275 and r.qty == 30 and got and got.budget == r.cost and got.max == r.upto and got.qty == r.qty
                return ok, r and string.format("%d Stück · Kosten %s · Sniper: Budget %s, bis %s", r.qty, A:FormatMoney(r.cost), got and A:FormatMoney(got.budget) or "-",
                    got and A:FormatMoney(got.max) or "-") or "keine Zeile", "30 · ≤ 3g 62s 75c · Budget = Kosten"
            end)
        end)
        Chk("T433", "M", "T-MD3 41 Teile -> Wert je Teil ≤ Wert bei 1 Teil; Zeile, Detail und Sammelkauf (D:PlannedValue) gleich", function()
            return WithMD({ ladder = { { 900, 41 } }, net = 1855, drop = 5, min = 20 }, function()
                local r = MVx:DEOffer(STU2, 900, 41)
                local savedCur = MVx.deCurrent
                MVx.deCurrent = r
                local lines = table.concat(MVx:DEDetailLines(STU2), " ")
                MVx.deCurrent = savedCur
                local pv = Dx:PlannedValue(STU2, r and r.qty or 1)
                local ok = r and r.net < 1855 and r.net == pv and lines:find(A:FormatMoney(r.net), 1, true) ~= nil
                return ok, r and string.format("1 Teil 18s 55c · %d Teile %s · Sammelkauf-Funktion %s · Detail %s", r.qty, A:FormatMoney(r.net), A:FormatMoney(pv),
                    lines:find(A:FormatMoney(r.net), 1, true) and "gleich" or "ANDERS") or "keine Zeile", "kleiner · gleich · gleich"
            end)
        end)
        Chk("T434", "M", "T-MD4 Hauptmaterial frisch gestiegen, echte Chancen -> Sicherheit \"mittel\", Zeile \"ohne Anstieg: X\"", function()
            return WithMD({ ladder = { { 900, 10 } }, net = 1855, min = 20 }, function()
                local savedPH, savedMV = A.PriceHints, A.GetMarketValue
                A.PriceHints = function(self, id) if id == SD then return { fresh = 3 } end if MP[id] then return {} end return savedPH(self, id) end
                A.GetMarketValue = function(self, id) if id == SD then return 400 end if MP[id] then return MP[id] end return savedMV(self, id) end
                local res = { pcall(MVx.DEOffer, MVx, STU2, 900, 10) }
                A.PriceHints, A.GetMarketValue = savedPH, savedMV
                if not res[1] then error(res[2], 0) end
                local r = res[2]
                local ok = r and r.safety == "mittel" and r.noRise and r.noRise < r.net and r.text:find(string.format(L["ohne Anstieg: %s"], A:FormatMoney(r.noRise)), 1, true) ~= nil
                return ok, r and string.format("Sicherheit %s · ohne Anstieg %s (Wert %s)", r.safety, r.noRise and A:FormatMoney(r.noRise) or "-", A:FormatMoney(r.net)) or "keine Zeile",
                    "mittel · ohne Anstieg < Wert"
            end)
        end)
        Chk("T435", "M", "T-MD5 Fusszeile = Menge der Zeile; Item ohne geladene Info -> nach ITEMINFO_LOADED steht die Stufe in der Zeile", function()
            local cfg = { ladder = LADDER_MD, net = 1855, min = 20 }
            return WithMD(cfg, function()
                local r = MVx:DEOffer(STU2, 900, 40)
                local before = A:PlainText(r.text)
                local foot = MVx:DEFooter(r)
                MVx.cache.de = { version = "test", rows = { r } }
                cfg.ilvl = 29
                A:Fire("ITEMINFO_LOADED")
                local after = A:PlainText(r.text)
                local ok = before:find("Stufe ?", 1, true) ~= nil and after:find("Stufe 29", 1, true) ~= nil and foot:find(tostring(r.qty) .. " ", 1, true) == 1
                    and foot:find(A:FormatMoney(r.cost), 1, true) ~= nil
                return ok, string.format("vorher \"%s\" · nachher \"%s\" · Fuss \"%s\"", before:sub(1, 40), after:sub(1, 40), foot), "Stufe ? -> Stufe 29 · Fuss 40 Stück, gleiche Kosten"
            end)
        end)
        -- D6: Aufkauf erkennen (nur eigene Funktionen ersetzt: A:GetHistory, A:GetMarketValue)
        local function WithHist(hist, mv, fn)
            local saved = { gh = A.GetHistory, mv = A.GetMarketValue, cache = A.buyoutCache }
            A.buyoutCache = {}
            A.GetHistory = function(self, id) if hist[id] then return hist[id] end return saved.gh(self, id) end
            A.GetMarketValue = function(self, id) if mv[id] then return mv[id] end return saved.mv(self, id) end
            local res = { pcall(fn) }
            A.GetHistory, A.GetMarketValue, A.buyoutCache = saved.gh, saved.mv, saved.cache
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        Chk("T436", "M", "T-MD6a Splitter 120 -> 8 Stück in 2 Std., 40s -> 1g 15s -> Aufkauf; Kaufen mit 40s, Verkaufen 1g 15s + Hinweis", function()
            local now = time()
            local h = { { t = now - 3 * 3600, p = 4000, q = 120 }, { t = now - 1 * 3600, p = 11573, q = 8 } }
            return WithHist({ [GS] = h }, { [GS] = 4000 }, function()
                local b = A:BuyoutInfo(GS)
                local hint = A:PriceHintText(A:PriceHints(GS)) or ""
                local cur = A:GetCurrent(GS)
                local ok = b and b.p0 == 4000 and b.p1 == 11573 and b.q0 == 120 and b.q1 == 8 and cur == 11573 and hint:find(L["Aufkauf: zum Kaufen mit altem Preis gerechnet"], 1, true) ~= nil
                return ok, b and string.format("Aufkauf: Menge %d -> %d, Preis %s -> %s · Verkaufen (Scan) %s · \"%s\"", b.q0, b.q1, A:FormatMoney(b.p0), A:FormatMoney(b.p1),
                    A:FormatMoney(cur or 0), hint) or "kein Kennzeichen", "Kennzeichen · Kaufen mit 40s · Verkaufen 1g 15s 73c"
            end)
        end)
        Chk("T437", "M", "T-MD6a Kapuze im Markt mit altem Splitterpreis gerechnet, Zeile nennt den Aufkauf", function()
            return WithMD({ ladder = { { 900, 10 } }, net = 1855, min = 20, buyout = { [GS] = { p0 = 4000, p1 = 11573, q0 = 120, q1 = 8 } } }, function()
                local r = MVx:DEOffer(STU2, 900, 10)
                local ok = r and r.buyout == GS and A:PlainText(r.text):find("Aufkauf", 1, true) ~= nil and r.safety ~= "hoch"
                return ok, r and string.format("Aufkauf %s · Sicherheit %s · \"%s\"", tostring(r.buyout), r.safety, A:PlainText(r.text):sub(-70)) or "keine Zeile",
                    "Aufkauf bei … – mit altem Preis gerechnet"
            end)
        end)
        Chk("T438", "M", "T-MD6b Preis steigt über 3 Tage langsam 40s -> 60s, Menge gleich -> kein Aufkauf", function()
            local now = time()
            local h = {}
            for i = 0, 12 do h[#h + 1] = { t = now - (72 - i * 6) * 3600, p = 4000 + i * 167, q = 120 } end
            return WithHist({ [GS] = h }, { [GS] = 4000 }, function()
                local b = A:BuyoutInfo(GS)
                return b == nil, b and "Kennzeichen (falsch)" or "kein Kennzeichen", "kein Kennzeichen"
            end)
        end)
        -- Sniper reagiert nicht (Befund 10.11. 16:30, T-SR2–T-SR5) - nur eigene Seams
        local SnX = A.Sniper
        Chk("T399", "M", "T-SR2 Sniper-Modus an -> Statuszeile zeigt Zeit bis zur nächsten Suche und letzte Treffer", function()
            local saved = { open = A.IsAHOpen, nxt = SnX.nextSearchAt, wr = SnX.waitReason, ld = SnX.lastDone, se = SnX.search }
            local db = A.db.sniper
            local armed = db and db.armed
            if db then db.armed = true end
            A.IsAHOpen = function() return true end
            SnX.search, SnX.waitReason = nil, nil
            SnX.nextSearchAt = GetTime() + 12
            SnX.lastDone = { time = GetTime() - 40, hits = 5 }
            local okS, st = pcall(SnX.AutoStatus, SnX)
            A.IsAHOpen = saved.open
            if db then db.armed = armed end
            SnX.nextSearchAt, SnX.waitReason, SnX.lastDone, SnX.search = saved.nxt, saved.wr, saved.ld, saved.se
            if not okS then error(st, 0) end
            local ok = st and st:find("12", 1, true) and st:find("5", 1, true) ~= nil
            return ok, tostring(st), "nächste Suche in 12 s · zuletzt vor 40 s: 5 Treffer"
        end)
        Chk("T400", "M", "T-SR3 Entzauber-Ziel Max 10s, Entzauberwert 12s 36c -> keine Verlust-Warnung", function()
            local D = A.Disenchant
            local ID3 = 990008001
            local saved = { nsv = A.NetSellValue, dv = D.DealValue, pr = D.Prior }
            A.NetSellValue = function(self, id) if id == ID3 then return 455 end return saved.nsv(self, id) end
            D.DealValue = function(self, id) if id == ID3 then return 1300, 1236, true, "estimate", 0 end return saved.dv(self, id) end
            D.Prior = function(self, id) if id == ID3 then return { { 10940, 1, 1 } }, "2:1:a" end return saved.pr(self, id) end
            local res = { pcall(function()
                return SnX:MaxOverValue({ itemID = ID3, maxPrice = 1000 }), SnX:MaxOverValue({ itemID = ID3, maxPrice = 1500 })
            end) }
            A.NetSellValue, D.DealValue, D.Prior = saved.nsv, saved.dv, saved.pr
            if not res[1] then error(res[2], 0) end
            return res[2] == nil and res[3] == 264, string.format("Max 10s: %s · Max 15s: %s", tostring(res[2]), tostring(res[3])), "keine Warnung · 2s 64c"
        end)
        Chk("T401", "M", "T-SR4 Vollscan-Sperre aktiv -> Statuszeile nennt sie; Sniper-Suche läuft trotzdem", function()
            local VS = A.FullScan
            if not VS then return false, "Vollscan fehlt", "Statuszeile" end
            local saved = { open = A.IsAHOpen, wait = VS.Wait, run = VS.running, wr = SnX.waitReason }
            local db = A.db.sniper
            local armed = db and db.armed
            if db then db.armed = true end
            A.IsAHOpen = function() return true end
            VS.Wait = function() return 180 end
            VS.running = { t0 = 0 }
            SnX.waitReason = nil
            local res = { pcall(function() return SnX:AutoStatus(), A:IsScanning(true), A:IsScanning() end) }
            A.IsAHOpen, VS.Wait, VS.running, SnX.waitReason = saved.open, saved.wait, saved.run, saved.wr
            if db then db.armed = armed end
            if not res[1] then error(res[2], 0) end
            local st, marketOnly, any = res[2], res[3], res[4]
            local ok = st and st:find("3", 1, true) and marketOnly == false and any == true
            return ok, string.format("\"%s\" · blockiert Sniper %s", tostring(st), tostring(marketOnly)), "Vollscan-Sperre noch 3 Min. · blockiert false"
        end)
        Chk("T402", "M", "T-SR5 Drei Angebote weg -> genau eine Chatzeile plus eine Sammelzeile, nächste Raste kauft das nächste Angebot", function()
            local saved = { pr = A.Print, seen = SnX.failSeen, last = SnX.failLast, more = SnX.failMore, res = SnX.result, gt = SnX.GetTarget, rem = SnX.Remaining }
            local printed = {}
            A.Print = function(_, m) printed[#printed + 1] = tostring(m) end
            SnX.failSeen, SnX.failLast, SnX.failMore = {}, -1000, 0
            local res = { pcall(function()
                SnX:ReportFail(11); SnX:ReportFail(11); SnX:ReportFail(12); SnX:ReportFail(13)
                local before = #printed
                SnX:FlushFails()
                local t = { key = "test", maxPrice = 1000, qty = 10, budget = 100000, bought = 0, spent = 0 }
                SnX.GetTarget = function(_, key) if key == "test" then return t end return saved.gt(SnX, key) end
                SnX.Remaining = function(_, tt) if tt == t then return 10, 100000 end return saved.rem(SnX, tt) end
                SnX.result = { key = "test", itemID = 990008002, listings = {
                    { auctionID = 11, price = 900, buyout = 900, qty = 1, pass = true, gone = true },
                    { auctionID = 14, price = 950, buyout = 950, qty = 1, pass = true } } }
                local plan = SnX:PlanNext()
                return before, #printed, plan and plan.listing and plan.listing.auctionID, SnX.result.listings[1].status
            end) }
            A.Print, SnX.failSeen, SnX.failLast, SnX.failMore, SnX.result, SnX.GetTarget, SnX.Remaining =
                saved.pr, saved.seen, saved.last, saved.more, saved.res, saved.gt, saved.rem
            if not res[1] then error(res[2], 0) end
            local before, after, nextID, status = res[2], res[3], res[4], res[5]
            local ok = before == 1 and after == 2 and nextID == 14 and status == "weg" and (printed[2] or ""):find("2", 1, true) ~= nil
            return ok, string.format("Zeilen sofort %d · mit Sammelzeile %d (\"%s\") · nächstes Angebot %s · erstes %s", before, after, printed[2] or "-",
                tostring(nextID), tostring(status)), "1 · 2 (2 weitere) · 14 · weg"
        end)
        Chk("T409", "M", "T-SR6 Angebot 123 schlägt fehl, nächste Suche liefert 123 wieder -> \"weg\"; 456 zum gleichen Preis -> \"kaufbar\"", function()
            local saved = { dead = SnX.dead, dc = SnX.deadCommodity, red = SnX.deadRedelivered, res = SnX.result, gt = SnX.GetTarget, rem = SnX.Remaining,
                hid = A.deadOffers, fid = SnX.failIDs, pau = SnX.itemPause }
            local res = { pcall(function()
                SnX.dead, SnX.deadCommodity, SnX.deadRedelivered = {}, {}, 0
                A.deadOffers, SnX.failIDs, SnX.itemPause = { ids = {}, com = {}, comFails = {} }, {}, {}       -- S7: Ersatz
                SnX:MarkDead({ auctionID = 123, price = 900, buyout = 900, qty = 1 }, 990008003)
                local list = { { auctionID = 123, price = 900, buyout = 900, qty = 1, pass = true }, { auctionID = 456, price = 900, buyout = 900, qty = 1, pass = true } }
                local again = SnX:ApplyDead(990008003, list)
                local t = { key = "test", maxPrice = 1000, qty = 10, budget = 100000, bought = 0, spent = 0 }
                SnX.GetTarget = function(_, key) if key == "test" then return t end return saved.gt(SnX, key) end
                SnX.Remaining = function(_, tt) if tt == t then return 10, 100000 end return saved.rem(SnX, tt) end
                SnX.result = { key = "test", itemID = 990008003, listings = list }
                local plan = SnX:PlanNext()
                -- Waren ohne auctionID: gleiche Preis+Menge 60 s
                SnX:MarkDead({ price = 50, qty = 20 }, 990008004)
                local c = { { price = 50, qty = 20 }, { price = 50, qty = 30 } }
                SnX:ApplyDead(990008004, c)
                return again, list[1].status, list[2].status, plan and plan.listing and plan.listing.auctionID, c[1].gone, c[2].gone, SnX.deadRedelivered
            end) }
            SnX.dead, SnX.deadCommodity, SnX.deadRedelivered, SnX.result, SnX.GetTarget, SnX.Remaining = saved.dead, saved.dc, saved.red, saved.res, saved.gt, saved.rem
            A.deadOffers, SnX.failIDs, SnX.itemPause = saved.hid, saved.fid, saved.pau
            if not res[1] then error(res[2], 0) end
            local again, s1, s2, nextID, g1, g2, red = res[2], res[3], res[4], res[5], res[6], res[7], res[8]
            local ok = again == 1 and s1 == "weg" and s2 == "kaufbar" and nextID == 456 and g1 == true and not g2 and red == 2
            return ok, string.format("wieder geliefert %d · 123 %s · 456 %s · nächster Kauf %s · Ware gleich %s / andere Menge %s · gezählt %d", again, tostring(s1), tostring(s2),
                tostring(nextID), tostring(g1), tostring(g2), red), "1 · weg · kaufbar · 456 · gesperrt / frei · 2"
        end)
        -- S7 (Wunsch des Nutzers 10.11. 18:24): tote Angebote komplett ausblenden - nur Ersatztabellen, echte Sniper-Daten bleiben
        local function WithDead(fn)
            local saved = { hid = A.deadOffers, fid = SnX.failIDs, pau = SnX.itemPause, dead = SnX.dead, dc = SnX.deadCommodity, red = SnX.deadRedelivered,
                res = SnX.result, srch = SnX.search, hp = SnX.hasPlan, ld = SnX.lastDone, gt = SnX.GetTarget, rem = SnX.Remaining, vp = A.VerifyPrice,
                al = SnX.Alert, ep = SnX.episode, dg = A.Diag and A.Diag.Add, pr = A.Print, diagAt = SnX.diagAt }
            A.deadOffers, SnX.failIDs, SnX.itemPause = { ids = {}, com = {}, comFails = {} }, {}, {}
            SnX.dead, SnX.deadCommodity, SnX.deadRedelivered = {}, {}, 0
            local diag, verified = {}, {}
            if A.Diag then A.Diag.Add = function(_, k, t) diag[#diag + 1] = k .. " " .. tostring(t) end end
            A.Print = function() end
            A.VerifyPrice = function(_, id, price) verified[#verified + 1] = price end
            SnX.Alert = function() end
            local t = { key = "test", itemID = 990008010, maxPrice = 800, qty = 10, budget = 100000, bought = 0, spent = 0 }
            SnX.GetTarget = function(_, key) if key == "test" then return t end return saved.gt(SnX, key) end
            SnX.Remaining = function(_, tt) if tt == t then return 10, 100000 end return saved.rem(SnX, tt) end
            local res = { pcall(fn, t, diag, verified) }
            A.deadOffers, SnX.failIDs, SnX.itemPause = saved.hid, saved.fid, saved.pau
            SnX.dead, SnX.deadCommodity, SnX.deadRedelivered = saved.dead, saved.dc, saved.red
            SnX.result, SnX.search, SnX.hasPlan, SnX.lastDone, SnX.GetTarget, SnX.Remaining = saved.res, saved.srch, saved.hp, saved.ld, saved.gt, saved.rem
            A.VerifyPrice, SnX.Alert, SnX.episode, A.Print, SnX.diagAt = saved.vp, saved.al, saved.ep, saved.pr, saved.diagAt
            if A.Diag then A.Diag.Add = saved.dg end
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        local function Offers(...)
            local out = {}
            for _, x in ipairs({ ... }) do out[#out + 1] = { auctionID = x[1], price = x[2], buyout = x[2], qty = 1, pass = true } end
            return out
        end
        Chk("T420", "M", "T-SR7a Kauf schlägt fehl, Server liefert dieselbe auctionID wieder -> Zeile weg, \"Günstigstes: 10s\" + \"1 totes Angebot ausgeblendet\"", function()
            return WithDead(function(t, diag, verified)
                SnX:MarkDead({ auctionID = 123, price = 900, buyout = 900, qty = 1 }, t.itemID)
                SnX.search = { targetKey = "test", started = GetTime() }
                SnX:FinishSearch(t.itemID, Offers({ 123, 900 }, { 124, 1000 }, { 125, 1300 }), false)
                local r = SnX.result
                local seen = false
                for _, l in ipairs(r.listings) do if l.auctionID == 123 then seen = true end end
                local txt = A:PlainText(SnX:NothingText(r))
                local logged = false
                for _, d in ipairs(diag) do if d:find("SNIPER-TOT-AUSGEBLENDET", 1, true) then logged = true end end
                local ok = not seen and txt:find(A:PlainText(A:FormatMoney(1000)), 1, true) ~= nil and txt:find("1", 1, true) ~= nil
                    and #(r.hidden or {}) == 1 and logged
                return ok, string.format("Zeile 123 %s · \"%s\" · Protokoll %s", seen and "SICHTBAR" or "weg", txt, logged and "ja" or "nein"),
                    "weg · Günstigstes 10s + 1 totes Angebot ausgeblendet · Protokoll SNIPER-TOT-AUSGEBLENDET"
            end)
        end)
        Chk("T421", "M", "T-SR7b neue auctionID zum gleichen Preis -> sichtbar und kaufbar", function()
            return WithDead(function(t)
                t.maxPrice = 1000
                SnX:MarkDead({ auctionID = 123, price = 900, buyout = 900, qty = 1 }, t.itemID)
                SnX.search = { targetKey = "test", started = GetTime() }
                SnX:FinishSearch(t.itemID, Offers({ 123, 900 }, { 456, 900 }), false)
                local plan = SnX:PlanNext()
                local r = SnX.result
                local ok = #r.listings == 1 and r.listings[1].auctionID == 456 and plan and plan.listing and plan.listing.auctionID == 456
                return ok, string.format("sichtbar %d (%s) · nächster Kauf %s", #r.listings, tostring(r.listings[1] and r.listings[1].auctionID),
                    tostring(plan and plan.listing and plan.listing.auctionID)), "1 (456) · 456"
            end)
        end)
        Chk("T422", "M", "T-SR7c totes 9s-Angebot zählt nicht im Preis (Scan/Verlauf), Ware nach 2 Fehlschlägen, 3 verschiedene -> Pause", function()
            return WithDead(function(t, diag, verified)
                SnX:MarkDead({ auctionID = 123, price = 900, buyout = 900, qty = 1 }, t.itemID)
                SnX.search = { targetKey = "test", started = GetTime() }
                SnX:FinishSearch(t.itemID, Offers({ 123, 900 }, { 124, 1000 }), false)
                local price = verified[#verified]
                -- Ware ohne auctionID: erst nach 2 Fehlschlägen ausgeblendet
                local W = 990008011
                SnX:MarkDead({ price = 50, qty = 20 }, W)
                local one = A:IsDeadOffer(W, nil, 50, 20)
                SnX:MarkDead({ price = 50, qty = 20 }, W)
                local two = A:IsDeadOffer(W, nil, 50, 20)
                -- 3 verschiedene auctionIDs beim gleichen Item -> 10 Min. pausiert
                for k = 1, 3 do SnX:MarkDead({ auctionID = 700 + k, price = 900, qty = 1 }, 990008012) end
                local paused = SnX:ItemPaused(990008012)
                local ok = price == 1000 and not one and two and paused
                return ok, string.format("Preis in den Verlauf %s · Ware 1×/2× %s/%s · Pause %s", tostring(price), tostring(one), tostring(two), tostring(paused)),
                    "1000 (nicht 900) · false/true · true"
            end)
        end)
        -- VM2 (T-VM2) in der Nachbildung: erfundene Messung mit 1,5 s Hänger in der Verdichtung -> FEHLER mit Schrittname
        Chk("T412", "M", "T-VM2 Vollscan-Messung: Lücke 1,5 s in \"Verdichtung\" -> Hänger mit Schrittname, Bericht nennt ms und Lücke", function()
            local VS = A.FullScan
            local saved = { cur = VS.curMeasure, last = VS.lastMeasure }
            local res = { pcall(function()
                local m = VS:MBegin({}, 0)
                VS.curMeasure = nil                                   -- nur diese erfundenen Zeiten, kein echter Frame
                VS:MTick(m, 16)
                VS:MSet(m, "Ereignis-Aufruf", 20); VS:MAdd(m, "Warten auf Server", 20); VS:MAdd(m, "Ereignis-Aufruf", 5, 5)
                VS:MSet(m, "Einlesen", 25); VS:MTick(m, 33); VS:MTick(m, 41); VS:MAdd(m, "Einlesen", 16, 6)
                VS:MSet(m, "Verdichtung", 45); VS:MTick(m, 1545); VS:MAdd(m, "Verdichtung", 1500, 2)
                VS:MSet(m, "Preisverlauf+Neuaufbau", 1550); VS:MTick(m, 1560); VS:MAdd(m, "Preisverlauf+Neuaufbau", 10)
                VS:MEnd(m, { n = 100, count = 90 }, 10)
                VS.curMeasure = nil
                m.final = true
                local bad = VS:MProblems(m)
                local lines = VS:MeasureLines(m)
                return m.gapStep, table.concat(bad, " | "), table.concat(lines, " "), m.steps["Einlesen"].max
            end) }
            VS.curMeasure, VS.lastMeasure = saved.cur, saved.last
            if not res[1] then error(res[2], 0) end
            local step, bad, txt, einMax = res[2], res[3], res[4], res[5]
            local ok = step == "Verdichtung" and bad:find("Verdichtung", 1, true) ~= nil and not bad:find("Einlesen", 1, true)
                and txt:find("längste Lücke", 1, true) ~= nil and txt:find("FEHLER", 1, true) ~= nil and einMax < 1000
            return ok, string.format("Lücke bei %s · Hänger \"%s\" · Einlesen längster Frame %.0f ms", tostring(step), bad, einMax or -1),
                "Verdichtung · nur Verdichtung > 1 s · Bericht mit FEHLER"
        end)
        -- X6 (Befund 0.65.86): echter Sync im Hintergrund ist kein Sandbox-FEHLER, und Pfade im Bericht nennen keine Namen
        Chk("T426", "M", "T-X6 Sync-Adressbuch während der Routine -> Sandbox OK; Pfade im Bericht ohne Spielernamen", function()
            local NAME = "Testa Beispiel"
            local allowed = TR:IsAllowed({ "gsSync", "book", NAME, "seen" })
            local txt = TR.PathText({ "gsSync", "book", NAME, "seen" })
            local txt2 = TR.PathText({ "peers", NAME })
            local ok = allowed and not txt:find(NAME, 1, true) and txt:find("<Spieler>", 1, true) ~= nil and not txt2:find(NAME, 1, true)
            return ok, string.format("erlaubt %s · \"%s\" · \"%s\"", tostring(allowed), txt, txt2), "true · gsSync.book.<Spieler>.seen · peers.<Spieler>"
        end)
        -- X8 (Befund 0.65.86): Entzauber-Beute in Chancen-, Mengen- und Rest-Faktor zerlegen (nur messen)
        Chk("T430", "M", "T-X8 Zerlegung 2:4:a: Chance (gemessen/Tabelle) × Menge (gemessen/angenommen) = gemessener Wert / Tabellenwert", function()
            local D = A.Disenchant
            local KEY = "2:4:a"
            local prior = D:PriorForKey(KEY)
            if not prior then return "SKIP", "keine Tabelle für " .. KEY end
            local savedMP = D.MatPrice
            local P = {}
            for i, p in ipairs(prior) do P[p[1]] = 100 * i end
            D.MatPrice = function(self, id) if P[id] then return P[id] end return savedMP(self, id) end
            local res = { pcall(TR.DESandbox, function()
                -- 100 Entzauberungen: Anteile und Mengen frei erfunden
                local mats = {}
                for i, p in ipairs(prior) do
                    local times = math.floor(100 * (p[2] or 0) * (i == 1 and 0.9 or 1.1) + 0.5)
                    mats[p[1]] = { times = times, total = math.floor(times * (p[3] or 1) * 1.2 + 0.5) }
                end
                A.db.deStats[KEY] = { n = 100, mats = mats }
                local cf, qf = A.Forecast:DEFactors(KEY)
                local tab, meas = 0, 0
                for _, p in ipairs(prior) do
                    local m = mats[p[1]]
                    tab = tab + (p[2] or 0) * (p[3] or 1) * P[p[1]]
                    meas = meas + (m.times / 100) * (m.total / math.max(1, m.times)) * P[p[1]]
                end
                return cf, qf, meas / tab
            end) }
            D.MatPrice = savedMP
            if not res[1] then error(res[2], 0) end
            local cf, qf, want = res[2], res[3], res[4]
            local ok = cf and qf and math.abs(cf * qf - want) < 0.01 and qf > 1.1
            return ok, string.format("Chance %.2f × Menge %.2f = %.2f (gemessen/Tabelle %.2f)", cf or -1, qf or -1, (cf or 0) * (qf or 0), want),
                "Produkt = gemessen/Tabelle (± 0,01), Menge ≈ 1,2"
        end)
        -- U1–U4 (befund-unterbietung-prüfen-lag): nur aktive, je Item EINE Suche, Liste EINMAL am Ende neu, LANGSAM erst > 50 ms
        local function WithUndercut(owned, fn)
            local Se = A.Seller
            local saved = { owned = Se.owned, cp = Se.CheckPrice, ub = Se.undercutBatch, lb = Se.lastBatch, fire = A.Fire, dg = A.Diag and A.Diag.Add, slow = Se.SLOW_MS }
            local calls, fires, diag = {}, {}, {}
            Se.owned = owned
            Se.CheckPrice = function(_, id, front, silent) calls[#calls + 1] = { id = id, silent = silent }; return true end
            A.Fire = function(self, ev, ...) fires[ev] = (fires[ev] or 0) + 1; if ev == "SELLER_CHANGED" or ev == "DATA_CHANGED" then return end return saved.fire(self, ev, ...) end
            if A.Diag then A.Diag.Add = function(_, k, t) diag[#diag + 1] = k .. " " .. tostring(t) end end
            local res = { pcall(fn, Se, calls, fires, diag) }
            Se.owned, Se.CheckPrice, Se.undercutBatch, Se.lastBatch, A.Fire, Se.SLOW_MS = saved.owned, saved.cp, saved.ub, saved.lb, saved.fire, saved.slow
            if A.Diag then A.Diag.Add = saved.dg end
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        Chk("T415", "M", "T-UP1 1 aktive Auktion, 200 verkaufte -> genau 1 Suche (leise)", function()
            local owned = { { itemID = 990007001, qty = 1, buyout = 100 } }
            for k = 1, 200 do owned[#owned + 1] = { itemID = 990007100 + k, qty = 1, buyout = 100, sold = true } end
            return WithUndercut(owned, function(Se, calls)
                Se:CheckUndercuts()
                local ok = #calls == 1 and calls[1].id == 990007001 and calls[1].silent == true
                return ok, string.format("%d Suche(n), leise %s", #calls, tostring(calls[1] and calls[1].silent)), "1 Suche, leise"
            end)
        end)
        Chk("T416", "M", "T-UP2 30 aktive -> Liste EINMAL am Ende neu, kein Schritt > 16 ms", function()
            local owned = {}
            for k = 1, 30 do owned[#owned + 1] = { itemID = 990007200 + k, qty = 1, buyout = 100 } end
            return WithUndercut(owned, function(Se, calls, fires)
                Se:CheckUndercuts()
                local f0 = fires.SELLER_CHANGED or 0
                for k = 1, 30 do Se:BatchDone(990007200 + k) end
                local b = Se.lastBatch
                local during = (fires.SELLER_CHANGED or 0) - f0
                local ok = #calls == 30 and during == 1 and (fires.DATA_CHANGED or 0) == 1 and b and b.maxMs <= 16 and Se.undercutBatch == nil
                return ok, string.format("%d Suchen · Liste neu %d× (Daten %d×) · längster Schritt %.1f ms", #calls, during, fires.DATA_CHANGED or 0, b and b.maxMs or -1),
                    "30 · 1× · ≤ 16 ms"
            end)
        end)
        Chk("T417", "M", "T-UP3 LANGSAM nur über 50 ms (Grenze Se.SLOW_MS)", function()
            return WithUndercut({}, function(Se, calls, fires, diag)
                Se.SLOW_MS = 50
                Se:Measure("Test schnell", function() end)
                local fast = #diag
                Se.SLOW_MS = -1                                        -- jede Dauer liegt darüber
                Se:Measure("Test langsam", function() end)
                local slow = #diag - fast
                local ok = Se.SLOW_MS == -1 and fast == 0 and slow == 1 and (diag[1] or ""):find("LANGSAM", 1, true) ~= nil
                return ok, string.format("schnell %d Zeilen · über der Grenze %d (\"%s\")", fast, slow, diag[1] or "-"), "0 · 1 LANGSAM"
            end)
        end)
        -- S8 (Einkauf "~"-Zeilen, Detail leer): nur eigene Tabellen/Funktionen ersetzt (A.AH-Hülle, A:IsAHOpen, A:CanQueryNow)
        local function WithProbe(browse, fn)
            local Bx = A.Buy
            local X = 990008020
            local sent = {}
            local fake = setmetatable({
                SendBrowseQuery = function(q) sent[#sent + 1] = { kind = "browse", q = q } end,
                SendSearchQuery = function(key) sent[#sent + 1] = { kind = "items", key = key } end,
                GetBrowseResults = function() return browse end,
                GetNumBrowseResults = function() return #browse end,
                HasFullBrowseResults = function() return true end,
                IsThrottledMessageSystemReady = function() return true end,
            }, { __index = A.AH })
            local saved = { ah = A.AH, open = A.IsAHOpen, cq = A.CanQueryNow, res = Bx.results, det = Bx.detail, srch = Bx.search, want = Bx.wanted,
                msg = Bx.message, gone = Bx.goneScan, md = A.db.marketData[X], dg = A.Diag and A.Diag.Add, nq = A.NoteQuery, legacy = A.AH_LEGACY }
            local diag = {}
            A.AH, A.AH_LEGACY = fake, nil
            A.IsAHOpen = function() return true end
            A.CanQueryNow = function() return true end
            A.NoteQuery = function() end
            if A.Diag then A.Diag.Add = function(_, k, t) diag[#diag + 1] = k .. " " .. tostring(t) end end
            Bx.goneScan = {}
            Bx.search, Bx.wanted, Bx.detail = nil, nil, nil
            local old = time() - 3600
            Bx.results = { { itemKey = X, itemID = X, name = "AHS-Test Kapuze", price = 1200, qty = 3, fromScan = old } }
            A.db.marketData[X] = { history = { { t = old, p = 1200, q = 3 } } }
            local res = { pcall(fn, Bx, X, sent, diag) }
            A.AH, A.IsAHOpen, A.CanQueryNow, A.NoteQuery, A.AH_LEGACY = saved.ah, saved.open, saved.cq, saved.nq, saved.legacy
            Bx.results, Bx.detail, Bx.search, Bx.wanted, Bx.message, Bx.goneScan = saved.res, saved.det, saved.srch, saved.want, saved.msg, saved.gone
            A.db.marketData[X] = saved.md
            if A.Diag then A.Diag.Add = saved.dg end
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        local function FinishBrowse(Bx)
            for _ = 1, 2 do                       -- erster Poll merkt die Anzahl, zweiter schliesst ab
                local s = Bx.search
                if not s then break end
                Bx:Poll()
                s = Bx.search
                if s then s.answered = true; s.lastChange = GetTime() - 2 end
            end
            if Bx.search then Bx:Poll() end
        end
        Chk("T439", "M", "T-SR8a Zeile nur aus dem Scan, Server 0 Treffer -> Zeile weg, nach \"Aktualisieren\" nicht wieder da", function()
            return WithProbe({}, function(Bx, X, sent, diag)
                Bx:Open(X, "AHS-Test Kapuze")
                local probe = sent[1] and sent[1].kind == "browse"
                FinishBrowse(Bx)
                local inList = false
                for _, r in ipairs(Bx.results) do if r.itemID == X then inList = true end end
                local again = false
                for _, r in ipairs(Bx:Snapshot({})) do if r.itemID == X then again = true end end
                local logged = false
                for _, d in ipairs(diag) do if d:find("DETAIL-PROBE", 1, true) then logged = true end end
                local ok = probe and not inList and not again and logged and Bx.message == L["Keine Angebote mehr – aus der Liste genommen"]
                return ok, string.format("Gegenprobe %s · in der Liste %s · nach Aktualisieren %s · Protokoll %s · \"%s\"", tostring(probe), tostring(inList),
                    tostring(again), tostring(logged), tostring(Bx.message)), "Browse · weg · nicht wieder da · DETAIL-PROBE · Hinweis"
            end)
        end)
        Chk("T440", "M", "T-SR8b Zeile aus dem Scan, Browse liefert das Item mit Suffix-itemKey -> Detailsuche mit diesem Key", function()
            local X = 990008020
            local key = { itemID = X, itemLevel = 29, itemSuffix = 1234, battlePetSpeciesID = 0 }
            return WithProbe({ { itemKey = key, minPrice = 1150, totalQuantity = 2 } }, function(Bx, X2, sent)
                Bx:Open(X2, "AHS-Test Kapuze")
                FinishBrowse(Bx)
                local items = sent[2]
                local row = Bx.results[1]
                local ok = items and items.kind == "items" and type(items.key) == "table" and items.key.itemSuffix == 1234 and row and row.fromScan == nil
                    and Bx.detail and Bx.detail.itemID == X2
                return ok, string.format("2. Anfrage %s mit Suffix %s · Zeile live %s", tostring(items and items.kind), tostring(items and type(items.key) == "table" and items.key.itemSuffix),
                    tostring(row and row.fromScan == nil)), "items mit Suffix 1234 · Zeile live"
            end)
        end)
        -- Buchhaltung neu BP1–BP7 (anweisung-buchhaltung-profi): nur Ersatztabelle BK.testDB, Charakter "Testa-Beispiel"
        local BKx = A.Books
        local B_STU, B_SD, B_AE = 990009001, 990009002, 990009003
        local function WithBooks(fn, vals)
            local saved = { db = BKx.testDB, ck = BKx.CharKey, ov = BKx.OpeningValue, mv = BKx.MatValue }
            BKx.testDB = BKx.NewDB(time() - 60)
            BKx.CharKey = function() return "Testa-Beispiel" end
            local V = vals or { [B_SD] = 500, [B_AE] = 1300 }
            BKx.MatValue = function(self, id) if V[id] then return V[id] end return saved.mv(self, id) end
            BKx.OpeningValue = function(self, id) if V[id] then return V[id] end return saved.ov(self, id) end
            local res = { pcall(fn, BKx.testDB) }
            BKx.testDB, BKx.CharKey, BKx.OpeningValue, BKx.MatValue = saved.db, saved.ck, saved.ov, saved.mv
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        Chk("T441", "M", "T-BP1 Neustart: Stichtag, Archiv-Marke, neue Summen 0, alte Buchungen und Entzauber-/Lern-/Prognose-Daten unverändert", function()
            local realDB = A.db
            local de, ln, fc = { ["2:1:a"] = { n = 3 } }, { corr = {} }, { list = { "P;1" } }
            local old = { { kind = "buy", t = time() - 86400, itemID = B_STU, qty = 10, amount = 99999 }, { kind = "sale", t = time() - 3600, itemID = B_SD, qty = 1, amount = 500 } }
            local fake = { ledger = { entries = old }, deStats = de, learn = ln, forecast = fc, settings = realDB.settings }
            A.db = fake
            local res = { pcall(function()
                local db = BKx:Restart()
                local s = BKx:Summary("all")
                return db, s
            end) }
            A.db = realDB
            if not res[1] then error(res[2], 0) end
            local db, s = res[2], res[3]
            local ok = db and fake.books == db and fake.ledger.archive and fake.ledger.archive[1] and fake.ledger.archive[1].entries == 2
                and fake.ledger.entries == old and #old == 2 and old[1].amount == 99999 and fake.deStats == de and de["2:1:a"].n == 3
                and fake.learn == ln and fake.forecast == fc and s.profit == 0 and s.sales == 0
            return ok, string.format("Archiv-Marke %s · alte Buchungen %d unverändert · Gewinn %s · Entzauber/Lernen/Prognose gleich %s", tostring(fake.ledger.archive and #fake.ledger.archive),
                #old, tostring(s and s.profit), tostring(fake.deStats == de and fake.learn == ln and fake.forecast == fc)), "1 · 2 · 0 · true"
        end)
        Chk("T442", "M", "T-BP2 Kauf 10 Stulpen à 10s -> Gewinn 0, Lager zum Einstandspreis 1g", function()
            return WithBooks(function()
                BKx:OnBuy(B_STU, 10, 10000)
                local s = BKx:Summary("all")
                local cost = BKx:StockValues()
                return s.profit == 0 and cost == 10000, string.format("Gewinn %s · Lager Einstand %s", A:FormatMoney(s.profit), A:FormatMoney(cost)), "0 · 1g"
            end)
        end)
        Chk("T443", "M", "T-BP3 Entzaubern 1 Stulpe (10s) -> 2 Staub (je 5s) + 1 Essenz (13s): Staub 4s 35c, Essenz 5s 65c, Summe 10s, Gewinn 0", function()
            return WithBooks(function()
                BKx:OnBuy(B_STU, 10, 10000)
                BKx:OnDisenchant(B_STU, { { B_SD, 2 }, { B_AE, 1 } })
                local qS, cS = BKx:Position(B_SD)
                local qE, cE = BKx:Position(B_AE)
                local qT, cT = BKx:Position(B_STU)
                local s = BKx:Summary("all")
                local ok = qS == 2 and cS == 435 and qE == 1 and cE == 565 and qT == 9 and cT == 9000 and s.profit == 0
                return ok, string.format("Staub %d/%dc · Essenz %d/%dc · Stulpen %d/%dc · Gewinn %d", qS, cS, qE, cE, qT, cT, s.profit), "2/435 · 1/565 · 9/9000 · 0"
            end)
        end)
        Chk("T444", "M", "T-BP4 Verkauf 2 Staub à 5s (Gebühr 15c) -> Gewinn = 2 × 5s × 0,95 − Kostenbasis − Gebühr, exakt", function()
            return WithBooks(function()
                BKx:OnBuy(B_STU, 10, 10000)
                BKx:OnDisenchant(B_STU, { { B_SD, 2 }, { B_AE, 1 } })
                BKx:OnFee(15)
                BKx:OnInvoice(B_SD, 2, 1000, 50)
                local s = BKx:Summary("all")
                local want = math.floor(1000 * (1 - A:CutPct()) + 0.5) - 435 - 15
                return s.profit == want, string.format("Gewinn %dc (Erlös %d − eingesetzt %d − Gebühr %d)", s.profit, s.rev, s.cost, s.fees), tostring(want) .. "c"
            end)
        end)
        Chk("T445", "M", "T-BP5 eigene Auktion verkauft -> sofort \"ausstehend\"; Rechnung -> bestätigt, Summe gleich, nie doppelt", function()
            return WithBooks(function()
                BKx:OnBuy(B_SD, 2, 600)
                local owned = { { auctionID = 77, itemID = B_SD, qty = 2, buyout = 1000, sold = true } }
                BKx:CheckOwned(owned)
                local s1 = BKx:Summary("all")
                BKx:CheckOwned(owned)                                     -- nochmal gelesen: nicht doppelt
                BKx:OnInvoice(B_SD, 2, 1000, 50)
                local s2 = BKx:Summary("all")
                local ok = s1.pendingN == 1 and s1.sales == 1 and s2.sales == 1 and s2.pendingN == 0 and s1.profit == s2.profit and s2.profit == 950 - 600
                return ok, string.format("ausstehend %d (Gewinn %d) · nach Rechnung %d Verkauf, ausstehend %d, Gewinn %d", s1.pendingN, s1.profit, s2.sales, s2.pendingN, s2.profit),
                    "1 (350) · 1 Verkauf, 0 ausstehend, 350"
            end)
        end)
        Chk("T446", "M", "T-BP6 Eröffnungsbestand 36 Staub (4s 70c netto) -> Verkauf zu 4s 94c: Gewinn nur aus dem Unterschied", function()
            return WithBooks(function()
                BKx:OpenChar({ [B_SD] = 36 })
                BKx:OnInvoice(B_SD, 36, 36 * 494, math.floor(36 * 494 * A:CutPct() + 0.5))
                local s = BKx:Summary("all")
                local want = (36 * 494 - math.floor(36 * 494 * A:CutPct() + 0.5)) - 36 * 470
                local ok = s.profit == want and math.abs(s.profit) < 36 * 494 / 10
                return ok, string.format("Gewinn %dc (nicht %dc)", s.profit, 36 * 494), tostring(want) .. "c"
            end, { [B_SD] = 470 })
        end)
        Chk("T447", "M", "T-BP7 Post an eigenen Twink: Kostenbasis wandert mit, Gewinn 0", function()
            return WithBooks(function()
                BKx:OnBuy(B_SD, 2, 1000)
                BKx:OnTwinkMail("Testb-Beispiel", { { B_SD, 2 } })
                local q1, c1 = BKx:Position(B_SD)
                local q2, c2 = BKx:Position(B_SD, "Testb-Beispiel")
                local s = BKx:Summary("all")
                return q1 == 0 and q2 == 2 and c2 == 1000 and s.profit == 0, string.format("ich %d/%d · Twink %d/%d · Gewinn %d", q1, c1, q2, c2, s.profit), "0/0 · 2/1000 · 0"
            end)
        end)
        Chk("T448", "M", "T-BP8 Abstimmung: Gold +50s, Buchhaltung +45s -> \"nicht gebucht 5s\"", function()
            return WithBooks(function(db)
                db.gold["Testa-Beispiel"] = { start = 100000, startT = db.since, day = A:DayStart(time()), dayStart = 100000, last = 100000 }
                BKx:OnInvoice(B_SD, 1, math.floor(4500 / (1 - A:CutPct()) + 0.5), math.floor(4500 / (1 - A:CutPct()) + 0.5) - 4500)
                local change, explained, diff = BKx:Reconcile("all", 105000)
                return change == 5000 and explained == 4500 and diff == 500, string.format("Gold %+d · erklärt %+d · nicht gebucht %+d", change or 0, explained or 0, diff or 0), "+5000 · +4500 · +500"
            end)
        end)
        Chk("T449", "M", "T-BP9 Einkaufstag: 246 Teile für 30g -> kein Verlust; Gewinn nur aus Verkäufen", function()
            return WithBooks(function()
                BKx:OnBuy(B_STU, 246, 300000)
                local s0 = BKx:Summary("today")
                for _ = 1, 20 do BKx:OnDisenchant(B_STU, { { B_SD, 2 }, { B_AE, 1 } }) end
                local s1 = BKx:Summary("today")
                local qS, cS = BKx:Position(B_SD)
                BKx:OnInvoice(B_SD, 20, 20 * 600, math.floor(20 * 600 * A:CutPct() + 0.5))
                local s2 = BKx:Summary("today")
                local takenCost = cS - select(2, BKx:Position(B_SD))
                local rev = 20 * 600 - math.floor(20 * 600 * A:CutPct() + 0.5)
                local ok = s0.profit == 0 and s1.profit == 0 and s2.profit == rev - takenCost and qS == 40
                return ok, string.format("nach Einkauf %d · nach 20 Entzauberungen %d · nach Verkauf 20 Staub %d (Erlös %d − eingesetzt %d)", s0.profit, s1.profit, s2.profit, rev, takenCost),
                    "0 · 0 · Erlös − Kostenbasis"
            end)
        end)
        -- SG1–SG4 (Wunsch des Nutzers 11.11.): goldenes Signal bei Sniper-Treffer - nur eigene Funktionen ersetzt
        local function WithSignal(fn)
            local saved = { open = A.IsAHOpen, combat = A.InCombat, at = SnX.signalAt, on = A.db.settings.sniperSignal, col = A.db.settings.sniperSignalColor,
                hid = A.deadOffers, pau = SnX.itemPause }
            local st = { open = true, combat = false }
            A.IsAHOpen = function() return st.open end
            A.InCombat = function() return st.combat end
            SnX.signalAt = nil
            A.db.settings.sniperSignal, A.db.settings.sniperSignalColor = nil, nil
            A.deadOffers, SnX.itemPause = { ids = {}, com = {}, comFails = {} }, {}
            local res = { pcall(fn, st) }
            SnX:StopSignal("Test")
            A.IsAHOpen, A.InCombat, SnX.signalAt = saved.open, saved.combat, saved.at
            A.db.settings.sniperSignal, A.db.settings.sniperSignalColor = saved.on, saved.col
            A.deadOffers, SnX.itemPause = saved.hid, saved.pau
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        local SG_PLAN = { itemID = 990008030, qty = 1, total = 900, listing = { auctionID = 31, price = 900, qty = 1 } }
        Chk("T450", "M", "T-SG1 Treffer -> Signal sichtbar in Gold; aus nach Kauf bzw. spätestens nach 4 s", function()
            return WithSignal(function()
                local shown = SnX:Signal(SG_PLAN)
                local f = SnX.signalFrame
                local gold = f and f.color == "gold"
                local r, g = f.rgb[1], f.rgb[2]
                A:Fire("BUY_PURCHASE_RESULT", true, { itemID = SG_PLAN.itemID })
                local afterBuy = SnX:SignalShown()
                SnX.signalAt = nil
                SnX:Signal(SG_PLAN)
                f.started = GetTime() - 4.1
                f:GetScript("OnUpdate")(f, 0.1)
                local afterTime = SnX:SignalShown()
                local ok = shown and gold and math.abs(r - 1) < 0.01 and math.abs(g - 0.82) < 0.01 and not afterBuy and not afterTime
                return ok, string.format("gezeigt %s · Farbe %s · nach Kauf %s · nach 4 s %s", tostring(shown), tostring(f and f.color), tostring(afterBuy), tostring(afterTime)),
                    "true · gold · aus · aus"
            end)
        end)
        Chk("T451", "M", "T-SG2 totes Angebot / im Kampf / AH zu -> kein Signal", function()
            return WithSignal(function(st)
                A:HideDeadOffer(SG_PLAN.itemID, 31, 900, 1, "Test")
                local a, wa = SnX:Signal(SG_PLAN)
                A.deadOffers = { ids = {}, com = {}, comFails = {} }
                st.combat = true
                local b, wb = SnX:Signal(SG_PLAN)
                st.combat, st.open = false, false
                local c, wc = SnX:Signal(SG_PLAN)
                local ok = not a and not b and not c and not SnX:SignalShown()
                return ok, string.format("tot %s (%s) · Kampf %s (%s) · AH zu %s (%s)", tostring(a), tostring(wa), tostring(b), tostring(wb), tostring(c), tostring(wc)), "alle kein Signal"
            end)
        end)
        Chk("T452", "M", "T-SG3 zwei Treffer in 1 s -> ein Signal; Option aus -> kein Signal", function()
            return WithSignal(function()
                local n0 = SnX.signalCount or 0
                SnX:Signal(SG_PLAN)
                SnX:Signal(SG_PLAN)
                local two = (SnX.signalCount or 0) - n0
                SnX:StopSignal("Test")
                SnX.signalAt = nil
                A.db.settings.sniperSignal = false
                local off = SnX:Signal(SG_PLAN)
                return two == 1 and not off, string.format("%d Signal(e) für 2 Treffer · Option aus: %s", two, tostring(off)), "1 · false"
            end)
        end)
        Chk("T453", "M", "T-SG4 Signal-Frame nimmt keine Maus an, eigener Frame (kein Blizzard-Frame)", function()
            return WithSignal(function()
                SnX:Signal(SG_PLAN)
                local f = SnX.signalFrame
                local mouse = f and f.IsMouseEnabled and f:IsMouseEnabled()
                local named = f and f.GetName and f:GetName()
                local ok = f ~= nil and not mouse and named == nil and f ~= UIParent
                return ok, string.format("Maus %s · Name %s", tostring(mouse), tostring(named)), "Maus false · ohne Namen (eigener Frame)"
            end)
        end)
        -- ZM1–ZM4 (Daten von zwei Rechnern zusammenführen): nur Ersatztabellen, D:Prior ersetzt (eigene Funktion)
        local Mgx = A.Merge
        local ZM_A, ZM_B, ZM_DUST, ZM_ESS = 990010001, 990010002, 990010101, 990010102
        local function WithZM(fn)
            local Dz = A.Disenchant
            local savedP = Dz.Prior
            Dz.Prior = function(self, id)
                if id == ZM_A or id == ZM_B then return { { ZM_DUST, 0.75, 1.5 }, { ZM_ESS, 0.25, 1 } }, "2:36:a" end
                return savedP(self, id)
            end
            local res = { pcall(fn) }
            Dz.Prior = savedP
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        local function ZMSide(entries, n)
            local log, mats = {}, { [ZM_DUST] = { times = 0, total = 0 }, [ZM_ESS] = { times = 0, total = 0 } }
            for _, e in ipairs(entries) do
                log[#log + 1] = { t = e[1], itemID = e[2], loot = { { ZM_DUST, e[3] } } }
                mats[ZM_DUST].times, mats[ZM_DUST].total = mats[ZM_DUST].times + 1, mats[ZM_DUST].total + e[3]
            end
            return { deLog = log, deStats = { ["2:36:a"] = { n = n or #entries, mats = mats } }, deShared = {}, deBuys = {},
                settings = { scale = 1 }, ledger = { entries = {} }, forecast = { list = {} }, marketData = {} }
        end
        Chk("T454", "M", "T-ZM1 gleiche Entzauberungen auf beiden Rechnern -> nur einmal gezählt", function()
            return WithZM(function()
                local t0 = time() - 3600
                local dst = ZMSide({ { t0, ZM_A, 2 }, { t0 + 60, ZM_B, 1 } })
                local src = ZMSide({ { t0, ZM_A, 2 }, { t0 + 60, ZM_B, 1 } })
                local c = Mgx:MergeInto(dst, src)
                Mgx:ProcessQueue(dst)
                local st = dst.deStats["2:36:a"]
                local ok = c.de == 0 and #dst.deLog == 2 and st.n == 2 and st.mats[ZM_DUST].total == 3
                return ok, string.format("neu %d · Verlauf %d · gezählt %d (Staub %d)", c.de, #dst.deLog, st.n, st.mats[ZM_DUST].total), "0 · 2 · 2 (3)"
            end)
        end)
        Chk("T455", "M", "T-ZM2 PC 3 und Laptop 2 verschiedene Entzauberungen -> deStats = Summe beider (5), nichts verloren", function()
            return WithZM(function()
                local t0 = time() - 7200
                local dst = ZMSide({ { t0, ZM_A, 1 }, { t0 + 10, ZM_A, 2 }, { t0 + 20, ZM_B, 1 } })
                local src = ZMSide({ { t0 + 30, ZM_A, 2 }, { t0 + 40, ZM_B, 2 } })
                local c = Mgx:MergeInto(dst, src)
                local done, open = Mgx:ProcessQueue(dst)
                local st = dst.deStats["2:36:a"]
                local ok = c.de == 2 and done == 2 and open == 0 and st.n == 5 and st.mats[ZM_DUST].total == 8 and #dst.deLog == 5 and dst.deMergeQueue == nil
                return ok, string.format("neu %d · gezählt %d · offen %d · deStats n %d, Staub %d · Verlauf %d", c.de, done, open, st.n, st.mats[ZM_DUST].total, #dst.deLog),
                    "2 · 2 · 0 · 5, 8 · 5"
            end)
        end)
        Chk("T456", "M", "T-ZM3 Einstellungen des aktuellen Rechners bleiben; Buchungen und Prognose-Fälle ohne Doppel vereinigt", function()
            return WithZM(function()
                local dst, src = ZMSide({}), ZMSide({})
                dst.settings.scale, src.settings.scale = 1.2, 0.8
                local t = time() - 100
                dst.ledger.entries = { { kind = "buy", t = t, itemID = ZM_A, qty = 1, amount = 500 } }
                src.ledger.entries = { { kind = "buy", t = t, itemID = ZM_A, qty = 1, amount = 500 }, { kind = "buy", t = t + 5, itemID = ZM_B, qty = 1, amount = 700 } }
                dst.forecast.list = { "P;1" }
                src.forecast.list = { "P;1", "P;2" }
                dst.books = { since = t, log = { { k = "buy", t = t, id = ZM_A, q = 1, ch = "Testa-Beispiel", cost = 500 } }, cb = {} }
                src.books = { since = t - 50, log = { { k = "buy", t = t, id = ZM_A, q = 1, ch = "Testa-Beispiel", cost = 500 }, { k = "buy", t = t + 5, id = ZM_B, q = 1, ch = "Testb-Beispiel", cost = 700 } },
                    cb = { ["Testb-Beispiel"] = { [ZM_B] = { q = 1, c = 700 } } } }
                local c = Mgx:MergeInto(dst, src)
                local ok = dst.settings.scale == 1.2 and #dst.ledger.entries == 2 and c.buys == 1 and #dst.forecast.list == 2 and #dst.books.log == 2
                    and dst.books.cb["Testb-Beispiel"] and dst.books.since == t - 50
                return ok, string.format("Grösse %.1f · Buchungen alt %d (neu Käufe %d) · Prognose %d · Books %d", dst.settings.scale, #dst.ledger.entries, c.buys or 0,
                    #dst.forecast.list, #dst.books.log), "1.2 · 2 (1) · 2 · 2"
            end)
        end)
        Chk("T457", "M", "T-ZM4 Paket wird gelesen und danach geleert (nie zweimal)", function()
            local saved = _G.AHSentinelMerge
            _G.AHSentinelMerge = { v = 1, from = "Test", t = time(), db = { deLog = {} } }
            local pkg = Mgx:Take()
            local after = _G.AHSentinelMerge
            local src = Mgx:Unwrap(pkg)
            local direct = Mgx:Unwrap({ deLog = {}, settings = {} })
            _G.AHSentinelMerge = saved
            local ok = pkg ~= nil and after == nil and type(src) == "table" and type(direct) == "table"
            return ok, string.format("gelesen %s · danach %s · Hülle %s · Kurzform %s", tostring(pkg ~= nil), tostring(after), tostring(src ~= nil), tostring(direct ~= nil)),
                "true · nil · true · true"
        end)
        -- VF2 (Befund grosser Test): bei "liegen" nie abbrechen - 30 eigene Auktionen, alle "liegen" -> 0 Abbrüche
        Chk("T460", "M", "T-VF3 30 eigene Auktionen \"liegen\" -> 0 Abbrüche, auch über \"nächste unterbotene abbrechen\"", function()
            local Se = A.Seller
            local saved = { owned = Se.owned, cancel = Se.Cancel }
            local calls = 0
            Se.Cancel = function() calls = calls + 1; return true end
            local owned = {}
            for k = 1, 30 do owned[k] = { auctionID = 990011000 + k, itemID = 990011000, qty = 1, unitPrice = 100, status = "liegen" } end
            Se.owned = owned
            local res = { pcall(function()
                local a = Se:CancelNextUndercut()
                owned[7].status = "unterboten"
                local b = Se:CancelNextUndercut(990011001)                 -- nur diese Auktion (liegt) -> nichts
                return a, b
            end) }
            Se.owned, Se.Cancel = saved.owned, saved.cancel
            if not res[1] then error(res[2], 0) end
            return calls == 0, string.format("%d Abbrüche", calls), "0"
        end)
        -- VF5 (Befund 11.11. 16:31): Teilverkauf einer Waren-Auktion - gleiche auctionID für aktive Restmenge und verkaufte Teile
        Chk("T461", "M", "T-VF5a owned = aktiv 9, verkauft 4, verkauft 1 (alle id 7) -> Se:Cancel(7) bricht die aktive ab", function()
            local Se = A.Seller
            local fake = setmetatable({ CancelAuction = function(id) Se.testCancelled = id end, CanCancelAuction = function() return true end }, { __index = A.AH })
            local saved = { owned = Se.owned, ah = A.AH, open = A.IsAHOpen, pc = Se.pendingCancel }
            Se.owned = {
                { auctionID = 7, itemID = 990012001, qty = 9, unitPrice = 3124, sold = false },
                { auctionID = 7, itemID = 990012001, qty = 4, unitPrice = 3124, sold = true },
                { auctionID = 7, itemID = 990012001, qty = 1, unitPrice = 3124, sold = true },
            }
            A.AH, A.IsAHOpen, Se.testCancelled = fake, function() return true end, nil
            -- während der Routine sperrt der Selbsttest jedes Abbrechen: geprüft wird, dass der Aufruf bis zur Sperre kommt
            -- (also die AKTIVE Restmenge gewählt hat) und nicht mit "schon verkauft" endet
            local res = { pcall(function() local a = Se:OwnedActive(7); return a, Se:Cancel(7) end) }
            local cancelled = Se.testCancelled
            Se.owned, A.AH, A.IsAHOpen, Se.pendingCancel, Se.testCancelled = saved.owned, saved.ah, saved.open, saved.pc, nil
            if not res[1] then error(res[2], 0) end
            local active, okC, msg = res[2], res[3], tostring(res[4] or "")
            local lock = L["Selbsttest läuft - Kaufen und Einstellen sind gesperrt."]
            local ok = active and active.qty == 9 and not active.sold and (okC == true or msg == lock) and msg ~= L["Diese Auktion ist schon verkauft."]
            return ok, string.format("gewählt %s Stück (verkauft %s) · Abbrechen: %s", tostring(active and active.qty), tostring(active and active.sold),
                A:PlainText(okC and "ausgeführt" or msg)), "9 Stück aktiv · bis zur Sperre (nicht \"schon verkauft\")"
        end)
        Chk("T462", "M", "T-VF5b Books: zwei Teilverkäufe (4 und 1) derselben auctionID -> beide \"ausstehend\", aktive Restmenge nicht verkauft", function()
            return WithBooks(function()
                BKx:OnBuy(990012001, 14, 14000)
                local owned = {
                    { auctionID = 7, itemID = 990012001, qty = 9, buyout = 28116, sold = false },
                    { auctionID = 7, itemID = 990012001, qty = 4, buyout = 12496, sold = true },
                    { auctionID = 7, itemID = 990012001, qty = 1, buyout = 3124, sold = true },
                }
                BKx:CheckOwned(owned)
                BKx:CheckOwned(owned)
                local s1 = BKx:Summary("all")
                local q = BKx:Position(990012001)
                local ok = s1.pendingN == 2 and s1.sales == 2 and q == 9
                return ok, string.format("ausstehend %d · Verkäufe %d · im Lager %d", s1.pendingN, s1.sales, q), "2 · 2 · 9"
            end)
        end)
        -- BE1–BE3 (Buchhaltung ehrlich): Rendite, wo du Geld verlierst, Ware ohne Einkauf getrennt
        Chk("T463", "M", "T-BE1 Gewinn 240, Eingesetzt 1333 -> Rendite 18 %", function()
            return WithBooks(function()
                BKx:OnBuy(B_SD, 1, 1333)
                BKx:OnInvoice(B_SD, 1, 1573, 0)
                local s = BKx:Summary("all")
                local txt = BKx:RoiText(s)
                return s.profit == 240 and txt == string.format(L["Rendite %d %%"], 18), string.format("Gewinn %d · %s", s.profit, txt), "240 · Rendite 18 %"
            end)
        end)
        Chk("T464", "M", "T-BE2 Entzaubern +310, Flippen −40, Item X −125 -> Tooltip \"Flippen −40c\" und \"X −1s 25c\"", function()
            return WithBooks(function()
                local X, Y = 990013001, 990013002
                BKx:OnBuy(B_STU, 1, 1000)
                BKx:OnDisenchant(B_STU, { { B_SD, 2 } })                 -- Staub mit Kostenbasis 1000 (Entzaubern)
                BKx:OnInvoice(B_SD, 2, 1310, 0)                          -- Entzaubern +310
                BKx:OnBuy(X, 1, 1000); BKx:OnInvoice(X, 1, 875, 0)       -- Flippen X −125
                BKx:OnBuy(Y, 1, 1000); BKx:OnInvoice(Y, 1, 1085, 0)      -- Flippen Y +85 -> Flippen gesamt −40
                local s = BKx:Summary("all")
                local lines = table.concat(BKx:LossLines(s), " | ")
                local ok = s.byType.de == 310 and s.byType.flip == -40 and lines:find(string.format(L["Verlust bei %s: %s"], L["Flippen"], A:FormatMoney(-40)), 1, true) ~= nil
                    and lines:find(A:FormatMoney(-125), 1, true) ~= nil
                return ok, string.format("Entzaubern %s · Flippen %s · \"%s\"", tostring(s.byType.de), tostring(s.byType.flip), A:PlainText(lines)), "310 · −40 · Flippen −40c, X −1s 25c"
            end)
        end)
        Chk("T465", "M", "T-BE3 Beute verkauft 120 (Kosten 0) + Handel Gewinn 100 auf 500 -> Gewinn 220, davon ohne Einkauf 120, Rendite 20 %", function()
            return WithBooks(function()
                BKx:OnInvoice(990013003, 1, 120, 0)                      -- Beute, nie gekauft
                BKx:OnBuy(B_SD, 1, 500); BKx:OnInvoice(B_SD, 1, 600, 0)
                local s = BKx:Summary("all")
                local ok = s.profit == 220 and s.freeRev == 120 and BKx:RoiText(s) == string.format(L["Rendite %d %%"], 20)
                return ok, string.format("Gewinn %d · ohne Einkauf %d · %s", s.profit, s.freeRev, BKx:RoiText(s)), "220 · 120 · Rendite 20 %"
            end)
        end)
        Chk("T466", "M", "T-BE4 keine Verluste -> \"Kein Verlust-Geschäft\"; ohne Einsatz -> \"Rendite –\"", function()
            return WithBooks(function()
                local s0 = BKx:Summary("all")
                BKx:OnBuy(B_SD, 1, 500); BKx:OnInvoice(B_SD, 1, 600, 0)
                local s = BKx:Summary("all")
                local lines = BKx:LossLines(s)
                local ok = #lines == 1 and lines[1] == L["Kein Verlust-Geschäft"] and BKx:RoiText(s0) == L["Rendite –"]
                return ok, string.format("\"%s\" · leer: %s", lines[1] or "-", BKx:RoiText(s0)), "Kein Verlust-Geschäft · Rendite –"
            end)
        end)
        -- MP1–MP3 (befund-materialpreise-alt 11.11.): nur eigene Funktionen ersetzt, nie eine echte Suche
        Chk("T471", "M", "T-MP1 AH offen: Hauptmaterialien älter als 30 Min. werden einzeln frisch geholt (frische nicht), zweiter Lauf sofort danach holt nichts", function()
            local D, Se, Dg = A.Disenchant, A.Seller, A.Diag
            local X, Y, Z = 990014001, 990014002, 990014003
            local saved = { ah = A.IsAHOpen, sim = A.Simulated, ids = D.MatIDs, gc = A.GetCurrent, cp = Se.CheckPrice, add = Dg.Add }
            local now, asked, diag = time(), {}, nil
            A.IsAHOpen = function() return true end
            A.Simulated = function() return false end
            D.MatIDs = function() return { { id = X, n = 30 }, { id = Y, n = 20 }, { id = Z, n = 10 } } end
            A.GetCurrent = function(self, id, ...)
                if id == X then return 1000, 50, now - 7 * 3600 elseif id == Y then return 2000, 80, now - 600 elseif id == Z then return nil end
                return saved.gc(self, id, ...)
            end
            Se.CheckPrice = function(self, id) asked[#asked + 1] = id end
            saved.bgp = Se.CheckPriceBg
            Se.CheckPriceBg = function(self, id) asked[#asked + 1] = id end
            Dg.Add = function(self, cat, txt) if cat == "PREIS-ALT" then diag = txt end end
            for _, id in ipairs({ X, Y, Z }) do D.matRefreshAt[id] = nil end
            local res = { pcall(function() return D:RefreshMats("Test"), D:RefreshMats("Test") end) }
            A.IsAHOpen, A.Simulated, D.MatIDs, A.GetCurrent, Se.CheckPrice, Dg.Add = saved.ah, saved.sim, saved.ids, saved.gc, saved.cp, saved.add
            Se.CheckPriceBg = saved.bgp
            for _, id in ipairs({ X, Y, Z }) do D.matRefreshAt[id] = nil end
            if not res[1] then error(res[2], 0) end
            local n1, n2 = res[2], res[3]
            local ok = n1 == 2 and n2 == 0 and #asked == 2 and asked[1] == X and asked[2] == Z and diag ~= nil and diag:find("7.0 Std.", 1, true) ~= nil
            return ok, string.format("1. Lauf %s (%s) · 2. Lauf %s · Diagnose %s", tostring(n1), table.concat(asked, ","), tostring(n2), diag and "ja" or "nein"),
                string.format("2 (%d,%d) · 0 · ja", X, Z)
        end)
        Chk("T472", "M", "T-MP2 Hauptmaterial veraltet -> Markt \"Entzaubern\" bietet nicht an, Sniper kauft nicht und sagt warum", function()
            local D, MV, Sn = A.Disenchant, A.MarketView, A.Sniper
            local ID = 990014004
            local saved = { dv = D.DealValue, sm = D.StaleMain, pr = D.Prior }
            D.DealValue = function(self, id) if id == ID then return 935, 935, true, "estimate", 0 end return saved.dv(self, id) end
            D.StaleMain = function(self, id) if id == ID then return true, 10940, 25 end return saved.sm(self, id) end
            D.Prior = function(self, id) if id == ID then return { { 10940, 1, 1 } }, "2:20:a" end return saved.pr(self, id) end
            local res = { pcall(function()
                local pv, why = D:PlannedValue(ID, 1)
                local offer, why2 = MV:DEOffer(ID, 500, 3, 100000)
                local st = Sn:DEStale({ de = true, maxPrice = 700 }, ID)
                local txt = Sn:NothingText({ itemID = ID, listings = {}, staleNote = L["Materialpreise veraltet"] })
                return pv, why, offer, why2, st, txt
            end) }
            D.DealValue, D.StaleMain, D.Prior = saved.dv, saved.sm, saved.pr
            if not res[1] then error(res[2], 0) end
            local pv, why, offer, why2, st, txt = res[2], res[3], res[4], res[5], res[6], res[7]
            local ok = pv == nil and why == "stale" and offer == nil and why2 == "Preise veraltet" and st == true and txt:find(L["Materialpreise veraltet"], 1, true) ~= nil
            return ok, string.format("Wert %s/%s · Markt %s/%s · Sniper gesperrt %s · Text %s", tostring(pv), tostring(why), tostring(offer), tostring(why2), tostring(st), A:PlainText(txt)),
                "nil/stale · nil/Preise veraltet · true · Materialpreise veraltet – erst scannen"
        end)
        Chk("T473", "M", "T-MP3 Aufkauf erkannt -> Kennzeichen bleibt über einen weiteren Scan mit hohem Preis; erst Menge wieder normal hebt es auf", function()
            local ID = 990014005
            local saved = { store = A.buyoutTestStore, det = A.DetectBuyout, gh = A.GetHistory }
            local hist = {}
            local live = { info = { since = time() - 3600, q0 = 200, p0 = 100, q1 = 20, p1 = 300, mv = 100 } }
            A.buyoutTestStore = {}
            A.DetectBuyout = function(self, id) if id == ID then return live.info end return saved.det(self, id) end
            A.GetHistory = function(self, id) if id == ID then return hist end return saved.gh(self, id) end
            local res = { pcall(function()
                A.buyoutCache[ID] = nil
                local a = A:BuyoutInfo(ID)                                  -- erkannt -> gespeichert
                live.info = nil                                           -- Erkennung greift nicht mehr (z. B. Marktwert schon gestiegen)
                hist[1] = { t = time() - 60, p = 290, q = 30 }            -- neuer Scan: Preis hoch, Menge klein
                A.buyoutCache[ID] = nil
                local b = A:BuyoutInfo(ID)
                hist[2] = { t = time() - 10, p = 280, q = 150 }           -- Menge wieder >= 50 % von 200
                A.buyoutCache[ID] = nil
                local c = A:BuyoutInfo(ID)
                return a, b, c
            end) }
            local store = A.buyoutTestStore
            A.buyoutTestStore, A.DetectBuyout, A.GetHistory = saved.store, saved.det, saved.gh
            A.buyoutCache[ID] = nil
            if not res[1] then error(res[2], 0) end
            local a, b, c = res[2], res[3], res[4]
            local ok = a ~= nil and b ~= nil and b.kept == true and b.p0 == 100 and c == nil and store[ID] == nil
            return ok, string.format("erkannt %s · nächster Scan %s (Preis vorher %s) · Menge normal %s", tostring(a ~= nil), b and "bleibt" or "weg", tostring(b and b.p0), c and "bleibt" or "aufgehoben"),
                "true · bleibt (100) · aufgehoben"
        end)
        -- L1 (Nachtrag VF5): Kennung je Teilverkauf - nie doppelt gegenüber Buchungen aus 0.65.92 und älter
        Chk("T474", "M", "T-VF5c seenSold[7] aus alter Version -> erster verkaufter Eintrag von id 7 wird nicht nochmals gebucht, der zweite schon", function()
            return WithBooks(function(db)
                BKx:OnBuy(990012001, 14, 14000)
                db.seenSold[7] = time() - 600
                local owned = {
                    { auctionID = 7, itemID = 990012001, qty = 4, buyout = 12496, sold = true },
                    { auctionID = 7, itemID = 990012001, qty = 1, buyout = 3124, sold = true },
                }
                local n = BKx:CheckOwned(owned)
                local n2 = BKx:CheckOwned(owned)
                local s = BKx:Summary("all")
                return n == 1 and n2 == 0 and s.pendingN == 1, string.format("neu %d · nochmals %d · ausstehend %d", n, n2, s.pendingN), "1 · 0 · 1"
            end)
        end)
        Chk("T475", "M", "T-VF5d Reparatur: doppelte ausstehend-Buchung (neue Kennung #1 neben alter Buchung) wird entfernt, Lager zurück", function()
            return WithBooks(function(db)
                BKx:OnBuy(990012001, 14, 14000)
                BKx:PendingSale(990012001, 4, 12496, 7, time() - 30)                -- alt (ohne Kennung)
                BKx:PendingSale(990012001, 4, 12496, 7, time() - 10, "7:4:12496#1")  -- neu, dieselbe Auktion
                local before = BKx:Position(990012001)
                local n = BKx:RepairDoubles(db)
                local s = BKx:Summary("all")
                local after = BKx:Position(990012001)
                local ok = n == 1 and s.pendingN == 1 and before == 6 and after == 10
                return ok, string.format("repariert %d · ausstehend %d · Lager %d -> %d", n, s.pendingN, before, after), "1 · 1 · 6 -> 10"
            end)
        end)
        Chk("T476", "M", "T-ZM5 derselbe Charakter kauft 5 auf dem PC und 3 auf dem Laptop -> nach dem Zusammenführen 8 mit beiden Einständen", function()
            local ch, id = "Testa-Beispiel", 990014006
            local d, sb = BKx.NewDB(time() - 3600), BKx.NewDB(time() - 3600)
            d.log = { { k = "buy", ch = ch, id = id, q = 5, cost = 5000, t = time() - 1200 } }
            d.cb = { [ch] = { [id] = { q = 5, c = 5000 } } }
            sb.log = { { k = "buy", ch = ch, id = id, q = 3, cost = 3600, t = time() - 600 } }
            sb.cb = { [ch] = { [id] = { q = 3, c = 3600 } } }
            local dst, src = { books = d }, { books = sb }
            local c = {}
            Mgx:MergeBooks(dst, src, c)
            local p = dst.books.cb[ch][id]
            return p.q == 8 and p.c == 8600 and c.books == 1, string.format("Menge %d · Einstand %d · neue Buchungen %d", p.q, p.c, c.books), "8 · 8600 · 1"
        end)
        -- JK1–JK6 (anweisung-jetzt-kaufen-verkaufen): eigener Speicher (A.Timing.testDB), Zeit und Preise über eigene Funktionen
        local JK = 990015001
        local function WithTM(cfg, fn)
            local TMx, Dx2 = A.Timing, A.Disenchant
            local saved = { db = TMx.testDB, now = TMx.now, gc = A.GetCurrent, bi = A.BuyoutInfo, pr = Dx2.Prior, gh = A.GetHistory, noted = TMx.notedAt, sig = A.db.settings.timingSignal }
            TMx.testDB, TMx.notedAt = TMx.NewDB(), {}
            A.db.settings.timingSignal = nil
            -- Tag 0 = Mitternacht vor (cfg.days) Tagen (Ortszeit); Werte je Stunde aus cfg.price(tag, stunde)
            local t0 = time()
            local d0 = date("*t", t0 - (cfg.days or 8) * 86400); d0.hour, d0.min, d0.sec = 0, 0, 0
            local start = time(d0)
            local nowT = start + (cfg.days or 8) * 86400 + 20 * 3600 + 1800
            local function at(day, hour) local d = date("*t", start + day * 86400 + 43200); d.hour, d.min, d.sec = hour, 5, 0; return time(d) end
            local qty = 1000
            for day = 0, (cfg.days or 8) do
                for hour = 0, 23 do
                    local t = at(day, hour)
                    if t < nowT - 1800 then
                        qty = qty - 3
                        TMx:Record(JK, cfg.price(day, hour), qty, t)
                    end
                end
            end
            TMx.now = nowT
            local cur = { p = cfg.cur, t = nowT - (cfg.curAge or 300) }
            A.GetCurrent = function(self, id, ...) if id == JK then return cur.p, 50, cur.t end return saved.gc(self, id, ...) end
            A.BuyoutInfo = function(self, id) if id == JK then return cfg.buyout end return saved.bi(self, id) end
            Dx2.Prior = function(self, id) if id == JK then return nil end return saved.pr(self, id) end
            local res = { pcall(fn, TMx, nowT, cur) }
            TMx.testDB, TMx.now, TMx.notedAt = saved.db, saved.now, saved.noted
            A.GetCurrent, A.BuyoutInfo, Dx2.Prior, A.GetHistory = saved.gc, saved.bi, saved.pr, saved.gh
            A.db.settings.timingSignal = saved.sig
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        local function Flat(day, hour) return 1000 + ((day * 7 + hour) % 3 - 1) * 10 end          -- ±1 %
        Chk("T477", "M", "T-JK1 Preis 14 % unter üblich, Trend flach -> \"Jetzt günstig – kaufen (−14 %)\"", function()
            return WithTM({ price = Flat, cur = 860 }, function(TMx)
                local sig, why = TMx:Signal(JK, "any")
                local txt = TMx:Text(sig) or ("keine Zeile: " .. tostring(why))
                local ok = sig and sig.kind == "buy" and sig.pct == 14 and txt == string.format(L["Jetzt günstig – kaufen (−%d %% unter üblich)"], 14)
                return ok, txt, "Jetzt günstig – kaufen (−14 % unter üblich)"
            end)
        end)
        Chk("T478", "M", "T-JK2 gleich, aber Tageswerte fallen seit 2 Tagen -> \"Fällt – abwarten\" (kein kaufen)", function()
            local function Fall(day) return ({ [6] = 960, [7] = 920, [8] = 880 })[day] or 1000 end
            return WithTM({ price = Fall, cur = 820 }, function(TMx)
                local sig, why = TMx:Signal(JK, "any")
                local txt = TMx:Text(sig) or ("keine Zeile: " .. tostring(why))
                return sig and sig.kind == "wait", txt, L["Fällt – abwarten"]
            end)
        end)
        Chk("T479", "M", "T-JK3 erst 6 Tage Daten -> keine Zeile (mit Shift: \"Rhythmus: noch 1 Tage messen\")", function()
            return WithTM({ price = Flat, cur = 860, days = 6 }, function(TMx)
                local sig, why, left = TMx:Signal(JK, "any")
                return sig == nil and why == "tage" and left == 1, string.format("%s · Grund %s · noch %s", sig and "Zeile" or "keine Zeile", tostring(why), tostring(left)), "keine Zeile · tage · 1"
            end)
        end)
        Chk("T480", "M", "T-JK4 Preis älter als 30 Min. oder Aufkauf-Kennzeichen -> keine Zeile", function()
            local a = WithTM({ price = Flat, cur = 860, curAge = 31 * 60 }, function(TMx) return { TMx:Signal(JK, "any") } end)
            local b = WithTM({ price = Flat, cur = 860, buyout = { since = 1 } }, function(TMx) return { TMx:Signal(JK, "any") } end)
            local ok = a[1] == nil and a[2] == "alt" and b[1] == nil and b[2] == "aufkauf"
            return ok, string.format("alt: %s (%s) · Aufkauf: %s (%s)", a[1] and "Zeile" or "keine", tostring(a[2]), b[1] and "Zeile" or "keine", tostring(b[2])), "keine (alt) · keine (aufkauf)"
        end)
        Chk("T481", "M", "T-JK5 Nachprüfen: kaufen-Fall nach 24 Std. höher = Treffer; Quote 50 % bei 20 Fällen -> Signal-Art ausgeblendet", function()
            return WithTM({ price = Flat, cur = 860 }, function(TMx, nowT)
                local sig = TMx:Signal(JK, "any")                                -- wird als Fall notiert
                local cases = #TMx.testDB.cases
                local hist = { { t = nowT + 86400 - 600, p = 950, q = 40 } }
                A.GetHistory = function(self, id) if id == JK then return hist end return {} end
                local n = TMx:Resolve(nowT + 86400 + 3600)
                local first = TMx.testDB.res.buy
                TMx.testDB.res.buy = string.rep("10", 10)                       -- 20 Fälle, 10 Treffer
                local sig2, why2 = TMx:Signal(JK, "any")
                local ok = sig and cases == 1 and n == 1 and first == "1" and sig2 == nil and why2 == "ausgeblendet"
                return ok, string.format("Fall %d · nachgeprüft %d (%s) · bei 50 %%/20: %s", cases, n, tostring(first), sig2 and "gezeigt" or tostring(why2)), "1 · 1 (1) · ausgeblendet"
            end)
        end)
        Chk("T483", "M", "JK1 Verkaufen-Reiter: Preis 20 % über üblich mit Absatz -> \"Jetzt teuer – verkaufen\"; schwach und um 8 Uhr üblich +30 % -> \"Jetzt nicht verkaufen – besser um 8 Uhr\"", function()
            local function Peak(day, hour) return hour == 8 and 1300 or 1000 end
            local a = WithTM({ price = Peak, cur = 1200 }, function(TMx) return { TMx:Signal(JK, "sell") } end)
            local b = WithTM({ price = Peak, cur = 950 }, function(TMx) return { TMx:Signal(JK, "sell") } end)
            local ok = a[1] and a[1].kind == "sell" and a[1].pct == 20 and b[1] and b[1].kind == "notnow" and b[1].at == 8 and b[1].pct >= 36
            return ok, string.format("%s · %s", A.Timing:Text(a[1]) or tostring(a[2]), A.Timing:Text(b[1]) or tostring(b[2])),
                "Jetzt teuer – verkaufen (+20 %) · Jetzt nicht verkaufen – besser um 8 Uhr (+37 %)"
        end)
        Chk("T482", "M", "T-JK6 Speicher: 5'000 Items mit vollem Rhythmus (14 Tage) < 2 MB (Nachbildung, schlechtester Fall)", function()
            local TMx = A.Timing
            local r = { base = 123456, first = 20400, lastH = 489600, lastQ = 99999, H = {}, D = {}, W = {}, S = {} }
            for h = 1, 24 do r.H[h] = { { d = 1, c = 1295 }, { d = 2, c = 700 }, { d = 3, c = 10 } }; r.S[h] = 35 end
            for i = 1, TMx.DAY_SLOTS do r.D[i] = { d = i, c = 999, n = 35 } end
            for i = 1, 7 do r.W[i] = 1000 end
            local str = TMx:Encode(r)
            local back = TMx:Decode(str)
            local per = #str + #tostring(990099999) + 8
            local total = per * 5000
            local ok = total < 2 * 1024 * 1024 and back and back.H[24][3].c == 10 and back.D[10].n == 35 and back.W[7] == 1000
            return ok, string.format("%d Bytes je Item · 5'000 Items %d KB · lesbar %s", per, math.ceil(total / 1024), tostring(back ~= nil)), "< 2048 KB · lesbar true"
        end)
        -- AB1–AB8 (befund-bilder-2205): nur eigene Funktionen ersetzt, nie ein echter Aufruf an den Server
        Chk("T484", "M", "T-AB8a Teil vor dem Neustart gekauft (19s), nach dem Neustart entzaubert -> Kosten 19s, nicht 0; Materialien tragen sie", function()
            return WithBooks(function(db)
                BKx.testOld = { [B_STU] = { q = 3, c = 5700 } }
                local okR, err = pcall(function() BKx:OnDisenchant(B_STU, { { B_SD, 2 }, { B_AE, 1 } }) end)
                BKx.testOld = nil
                if not okR then error(err, 0) end
                local de = db.log[#db.log]
                local q1, c1 = BKx:Position(B_SD)
                local q2, c2 = BKx:Position(B_AE)
                local ok = de.k == "de" and de.cost == 1900 and c1 + c2 == 1900 and q1 == 2 and q2 == 1
                return ok, string.format("Entzaubern Kosten %d · Material %d + %d", de.cost, c1, c2), "1900 · Summe 1900"
            end)
        end)
        Chk("T485", "M", "T-AB8b Reparatur: Entzauberung mit Kosten 0 (Teil gekauft) -> FEHLER in der Plausibilität; nach der Korrektur Kosten im Verkauf, FEHLER weg", function()
            return WithBooks(function(db)
                BKx:OnDisenchant(B_STU, { { B_SD, 2 } })                      -- ohne alte Daten: Kosten 0
                local deT = db.log[#db.log].t
                BKx:OnInvoice(B_SD, 2, 2000, 100)
                BKx.testOld = { [B_STU] = { q = 1, c = 1900 } }
                local res = { pcall(function()
                    local before = BKx:Plausibility("all")
                    local n = BKx:RepairOpening(db, { { t = deT, itemID = B_STU, loot = { { B_SD, 2 } }, paid = 1900 } })
                    local after = BKx:Plausibility("all")
                    return before, n, after
                end) }
                BKx.testOld = nil
                if not res[1] then error(res[2], 0) end
                local before, n, after = res[2], res[3], res[4]
                local function hasErr(l) for _, w in ipairs(l) do if w[1] == "FEHLER" then return true end end return false end
                local s = BKx:Summary("all")
                local ok = hasErr(before) and n == 1 and s.cost == 1900 and not hasErr(after)
                return ok, string.format("vorher FEHLER %s · korrigiert %d · Verkauf eingesetzt %d · nachher FEHLER %s", tostring(hasErr(before)), n, s.cost, tostring(hasErr(after))),
                    "true · 1 · 1900 · false"
            end)
        end)
        Chk("T491", "M", "T-AB8b1 Korrektur trifft Material-Verkäufe \"ohne Einkauf\": danach freeRev 0, Rendite = Gewinn / Eingesetzt, keine 30-%-Warnung", function()
            return WithBooks(function(db)
                BKx:OnDisenchant(B_STU, { { B_AE, 1 } })                     -- Staub nicht als Beute gebucht (wie im echten Fall)
                local deT = db.log[#db.log].t
                BKx:OnInvoice(B_SD, 2, 2000, 100)                             -- Staub verkauft: 2 Stück ohne Einkauf
                local s0 = BKx:Summary("all")
                BKx.testOld = { [B_STU] = { q = 1, c = 1900 } }
                local ok0, n = pcall(BKx.RepairOpening, BKx, db, { { t = deT, itemID = B_STU, loot = { { B_SD, 2 } }, paid = 1900 } })
                BKx.testOld = nil
                if not ok0 then error(n, 0) end
                local s = BKx:Summary("all")
                local warn = false
                for _, w in ipairs(BKx:Plausibility("all")) do if w[2]:find("ohne Einkauf", 1, true) then warn = true end end
                local roiSoll = s.cost > 0 and s.profit / s.cost * 100 or nil
                local ok = s0.freeRev > 0 and s.freeRev == 0 and s.free == 0 and s.cost == 1900 and s.roi and roiSoll and math.abs(s.roi - roiSoll) < 0.01 and not warn
                return ok, string.format("vorher ohne Einkauf %d · nachher %d (Stück %d) · eingesetzt %d · Rendite %.1f %% (soll %.1f) · Warnung %s",
                    s0.freeRev, s.freeRev, s.free, s.cost, s.roi or -1, roiSoll or -1, tostring(warn)), "> 0 · 0 (0) · 1900 · Rendite = Gewinn/Eingesetzt · false"
            end)
        end)
        Chk("T492", "M", "T-AB8b2 Nachlauf für Daten aus 0.65.97: Verkauf mit Korrektur-Kosten und \"ohne Einkauf\" -> ohne Einkauf 0, andere Verkäufe unberührt", function()
            return WithBooks(function(db)
                db.log[#db.log + 1] = { k = "sale", st = "c", ch = "Testa-Beispiel", id = B_SD, q = 2, rev = 2000, cost = 800, free = 2, fix = "AB8", t = time() }
                db.log[#db.log + 1] = { k = "sale", st = "c", ch = "Testa-Beispiel", id = B_AE, q = 1, rev = 500, cost = 0, free = 1, t = time() }
                local n, pieces = BKx:RepairAB8b(db)
                local ok = n == 1 and pieces == 2 and db.log[#db.log - 1].free == 0 and db.log[#db.log].free == 1
                return ok, string.format("korrigiert %d (%d Stück) · anderer Verkauf ohne Einkauf %d", n, pieces, db.log[#db.log].free), "1 (2 Stück) · 1"
            end)
        end)
        -- AB1-Rest: Abbrechen - nur eigene Funktionen ersetzt (A.Fire, A.Print, Se.QueryOwned), nie CancelAuction
        local function WithOwned(rows, fn)
            local Se = A.Seller
            local saved = { owned = Se.owned, pc = Se.pendingCancel, s = Se.search, q = Se.queue, bg = Se.bgQueue, fire = A.Fire, pr = A.Print, qo = Se.QueryOwned }
            local fired = {}
            Se.owned, Se.queue, Se.bgQueue = rows, {}, {}
            A.Fire = function(self, ev, ...) fired[#fired + 1] = ev end
            A.Print = function() end
            Se.QueryOwned = function() end
            local res = { pcall(fn, Se, fired) }
            Se.owned, Se.pendingCancel, Se.search, Se.queue, Se.bgQueue = saved.owned, saved.pc, saved.s, saved.q, saved.bg
            A.Fire, A.Print, Se.QueryOwned = saved.fire, saved.pr, saved.qo
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        Chk("T493", "M", "T-AB1b Teilverkauf (2 von 5 verkauft) + Abbrechen der Restmenge -> aktive Zeile weg, verkaufte bleibt", function()
            local sold = { auctionID = 7, itemID = 990016020, qty = 2, sold = true }
            local act = { auctionID = 7, itemID = 990016020, qty = 3, unitPrice = 2726, status = "unterboten" }
            return WithOwned({ sold, act }, function(Se)
                local o = Se:OwnedActive(7)
                Se.pendingCancel = { auctionID = 7, time = time(), qty = 3, itemID = 990016020, row = o }
                Se:OnCanceled(7)
                local ok = o == act and #Se.owned == 1 and Se.owned[1] == sold
                return ok, string.format("gewählt aktiv %s · Zeilen danach %d (verkaufte %s)", tostring(o == act), #Se.owned, tostring(Se.owned[1] == sold)), "true · 1 (true)"
            end)
        end)
        Chk("T494", "M", "T-AB1c zwei Auktionen desselben Items, verschiedene Preise -> nur die gewählte verschwindet, die andere bleibt mit Status", function()
            local a = { auctionID = 8, itemID = 990016021, qty = 5, unitPrice = 100, status = "günstigste" }
            local b = { auctionID = 9, itemID = 990016021, qty = 5, unitPrice = 120, status = "unterboten" }
            return WithOwned({ a, b }, function(Se)
                Se.pendingCancel = { auctionID = 9, time = time(), qty = 5, itemID = 990016021, row = b }
                Se:OnCanceled(9)
                local ok = #Se.owned == 1 and Se.owned[1] == a and a.status == "günstigste"
                return ok, string.format("Zeilen %d · übrig auctionID %s Status %s", #Se.owned, tostring(Se.owned[1] and Se.owned[1].auctionID), tostring(a.status)), "1 · 8 günstigste"
            end)
        end)
        Chk("T495", "M", "T-AB1d Abbrechen während \"prüfe Preise\" läuft -> Zeile weg, Prüfung und Warteschlange laufen weiter", function()
            local a = { auctionID = 10, itemID = 990016022, qty = 1, unitPrice = 500 }
            return WithOwned({ a }, function(Se, fired)
                local search = { itemID = 990016023 }
                Se.search, Se.queue = search, { 990016024 }
                Se.pendingCancel = { auctionID = 10, time = time(), qty = 1, itemID = 990016022, row = a }
                Se:OnCanceled(10)
                local ev = table.concat(fired, ",")
                local ok = #Se.owned == 0 and Se.search == search and #Se.queue == 1 and ev:find("AUCTION_CANCELLED", 1, true) ~= nil
                return ok, string.format("Zeilen %d · Prüfung läuft %s · Warteschlange %d · Ereignisse %s", #Se.owned, tostring(Se.search == search), #Se.queue, ev),
                    "0 · true · 1 · SELLER_CHANGED,AUCTION_CANCELLED"
            end)
        end)
        Chk("T496", "M", "T-VF5e Doppel ohne Kennung (0.65.93/94): zwei gleiche ausstehend-Buchungen, eine Kennung -> 1 entfernt, Lager zurück; zwei echte gleiche Teilverkäufe (#1, #2) -> nichts", function()
            return WithBooks(function(db)
                local ch, id = "Testa-Beispiel", 990012001
                BKx:OnBuy(id, 14, 14000)
                BKx:PendingSale(id, 4, 12496, 7, time() - 30)
                local e1 = db.log[#db.log]
                local e2 = {}
                for k, v in pairs(e1) do e2[k] = v end
                e2.t = e1.t + 5
                db.log[#db.log + 1] = e2
                db.cb[ch][id].q, db.cb[ch][id].c = 6, 6000
                db.seenSold[7], db.seenSold["7:4:12496#1"] = time() - 30, time() - 30
                local n1 = BKx:RepairDoubles2(db)
                local q1 = BKx:Position(id)
                -- zwei echte Teilverkäufe gleicher Grösse
                local e3 = {}
                for k, v in pairs(e1) do e3[k] = v end
                e3.a, e3.t = 8, e1.t + 20
                local e4 = {}
                for k, v in pairs(e3) do e4[k] = v end
                e4.t = e3.t + 5
                db.log[#db.log + 1], db.log[#db.log + 2] = e3, e4
                db.seenSold["8:4:12496#1"], db.seenSold["8:4:12496#2"] = time(), time()
                local n2 = BKx:RepairDoubles2(db)
                local ok = n1 == 1 and q1 == 10 and n2 == 0
                return ok, string.format("Doppel entfernt %d · Lager %d · echte Teilverkäufe entfernt %d", n1, q1, n2), "1 · 10 · 0"
            end)
        end)
        Chk("T502", "M", "T-VF5f dieselbe Waren-Auktion 3-mal je 1 Stück verkauft (gleicher Erlös, abgeschlossen, ohne Kennung) -> nichts entfernt; Reparatur festgehalten", function()
            return WithBooks(function(db)
                local ch, id = "Testa-Beispiel", 990012001
                for i = 1, 3 do
                    db.log[#db.log + 1] = { k = "sale", st = "c", ch = ch, id = id, q = 1, rev = 395, cost = 300, a = 9, t = time() - 600 + i * 60 }
                end
                local n = BKx:RepairDoubles2(db)
                local last = db.repairLog and db.repairLog[#db.repairLog]
                local ok = n == 0 and #db.log >= 3 and last and last.what == "L1c" and last.n == 0
                return ok, string.format("entfernt %d · Buchungen %d · Reparatur-Protokoll %s/%s", n, #db.log, tostring(last and last.what), tostring(last and last.n)), "0 · 3 · L1c/0"
            end)
        end)
        Chk("T497", "M", "T-PD1a 18 Sniper-Käufe kurz hintereinander, Kauf-Ereignisse kommen verspätet -> alle 18 sofort gebucht; Entzaubern danach nie mit Kosten 0", function()
            local Le = A.Ledger
            local saved = { bp = Le.BookPurchase, pend = Le.pendingBuys, add = A.Diag.Add }
            local booked = {}
            Le.pendingBuys = {}
            Le.BookPurchase = function(self, p, src, aid) if p.booked then return false end p.booked = true; booked[#booked + 1] = { p = p, src = src, aid = aid }; return true end
            A.Diag.Add = function() end
            local res = { pcall(function()
                for i = 1, 18 do Le:NotePurchase({ itemID = 7048, qty = 1, cost = 900, time = time(), listing = { auctionID = 5000 + i } }, "sniper") end
                for i = 1, 18 do Le:OnPurchaseEvent("AUCTION_HOUSE_PURCHASE_COMPLETED", 5000 + i) end
                return #booked
            end) }
            Le.BookPurchase, Le.pendingBuys, A.Diag.Add = saved.bp, saved.pend, saved.add
            if not res[1] then error(res[2], 0) end
            local nBooked = res[2]
            local zero = WithBooks(function(db)
                BKx:OnBuy(B_STU, 18, 18 * 900)
                for _ = 1, 18 do BKx:OnDisenchant(B_STU, { { B_SD, 1 } }) end
                local z = 0
                for _, e in ipairs(db.log) do if e.k == "de" and (e.cost or 0) ~= 900 then z = z + 1 end end
                return z
            end)
            local ok = nBooked == 18 and booked[18] and booked[18].aid == 5018 and booked[18].src == "sniper" and zero == 0
            return ok, string.format("gebucht %d · Entzaubern nicht 900: %d", nBooked, zero), "18 · 0"
        end)
        Chk("T498", "M", "T-PD1b Ereignis/Rechnung kommt danach nochmals für dieselbe Auktion -> keine zweite Buchung", function()
            local Le = A.Ledger
            local saved = { bp = Le.BookPurchase, pend = Le.pendingBuys, add = A.Diag.Add, snl = A.Sniper.lastPurchase, bl = A.Buy and A.Buy.lastPurchase }
            local booked = 0
            Le.pendingBuys = {}
            Le.BookPurchase = function(self, p) if p.booked then return false end p.booked = true; booked = booked + 1; return true end
            A.Diag.Add = function() end
            A.Sniper.lastPurchase = nil
            if A.Buy then A.Buy.lastPurchase = nil end
            local res = { pcall(function()
                Le:NotePurchase({ itemID = 7048, qty = 1, cost = 900, time = time(), listing = { auctionID = 6001 } }, "sniper")
                Le:OnPurchaseEvent("AUCTION_HOUSE_PURCHASE_COMPLETED", 6001)
                Le:OnPurchaseEvent("AUCTION_HOUSE_PURCHASE_COMPLETED", 6001)
            end) }
            Le.BookPurchase, Le.pendingBuys, A.Diag.Add, A.Sniper.lastPurchase = saved.bp, saved.pend, saved.add, saved.snl
            if A.Buy then A.Buy.lastPurchase = saved.bl end
            if not res[1] then error(res[2], 0) end
            return booked == 1, string.format("Buchungen %d", booked), "1"
        end)
        Chk("T499", "M", "T-PD5a Vollscan liefert 0 (bzw. < 30 % des letzten) -> nichts übernommen (keine Verfolgung, kein Preisverlauf), Hinweis", function()
            local VSx = A.FullScan
            local saved = { st = VSx.Store, tr = VSx.Track, pb = A.ProcessBest, fire = A.Fire, pr = A.Print, add = A.Diag.Add, li = VSx.lastItems, mem = VSx.mem }
            local st = { lastGoodItems = 5000, lastGood = 1 }
            local calls, printed = {}, nil
            VSx.Store = function() return st end
            VSx.Track = function() calls[#calls + 1] = "Track" end
            A.ProcessBest = function() calls[#calls + 1] = "ProcessBest" end
            A.Fire = function() end
            A.Print = function(self, msg) printed = msg end
            A.Diag.Add = function() end
            local res = { pcall(VSx.Finish, VSx, { items = {}, n = 0, count = 0, ms = 0, maxMs = 0, frames = 0 }, nil, time()) }
            VSx.Store, VSx.Track, A.ProcessBest, A.Fire, A.Print, A.Diag.Add, VSx.lastItems, VSx.mem = saved.st, saved.tr, saved.pb, saved.fire, saved.pr, saved.add, saved.li, saved.mem
            if not res[1] then error(res[2], 0) end
            local v1, v2, v3 = VSx:ValidResult(100, 5000), VSx:ValidResult(4000, 5000), VSx:ValidResult(300, nil)
            local ok = res[2] == false and #calls == 0 and st.lastGood == 1 and st.m1d == nil and printed == L["Vollscan ohne Antwort – nichts übernommen."] and not v1 and v2 and v3
            return ok, string.format("übernommen %s · Aufrufe %d · letzter gültiger unverändert %s · 100/5000 %s · 4000/5000 %s · Hinweis %s",
                tostring(res[2]), #calls, tostring(st.lastGood == 1), tostring(v1), tostring(v2), tostring(printed)), "false · 0 · true · false · true · Vollscan ohne Antwort – nichts übernommen."
        end)
        Chk("T504", "M", "T-PD5c Markt dauerhaft kleiner: 1. Vollscan mit 20 % verworfen, 2. mit ähnlicher Zahl angenommen; Referenz älter als 24 Std. gilt nicht", function()
            local VSx = A.FullScan
            local saved = { st = VSx.Store, tr = VSx.Track, pb = A.ProcessBest, fire = A.Fire, pr = A.Print, add = A.Diag.Add, li = VSx.lastItems, mem = VSx.mem, lc = VSx.lastCommodities }
            local st = { lastGoodItems = 5000, lastGood = time() - 3600 }
            local accepted = {}
            VSx.Store = function() return st end
            VSx.Track = function() end
            A.ProcessBest = function() end
            A.Fire, A.Print, A.Diag.Add = function() end, function() end, function() end
            -- angenommen = Finish übernimmt (st.lastGood wird neu gesetzt)
            local function Try(n, now)
                local before = st.lastGood
                local items = {}
                for i = 1, n do items[990018000 + i] = { q = { 1 }, b = { 100 } } end
                pcall(VSx.Finish, VSx, { items = items, n = n, count = n, ms = 0, maxMs = 0, frames = 0 }, nil, now)
                accepted[#accepted + 1] = st.lastGood ~= before
            end
            local res = { pcall(function()
                Try(1000, time())                                  -- 20 % -> verworfen
                Try(1050, time() + 1)                              -- ähnlich -> angenommen
                st.lowItems, st.lastGood, st.lastGoodItems = nil, time() - 30 * 3600, 5000
                Try(900, time())                                   -- Referenz alt -> angenommen
            end) }
            VSx.Store, VSx.Track, A.ProcessBest, A.Fire, A.Print, A.Diag.Add = saved.st, saved.tr, saved.pb, saved.fire, saved.pr, saved.add
            VSx.lastItems, VSx.mem, VSx.lastCommodities = saved.li, saved.mem, saved.lc
            if not res[1] then error(res[2], 0) end
            local ok = accepted[1] == false and accepted[2] == true and accepted[3] == true
            return ok, string.format("1. %s · 2. %s · alte Referenz %s", tostring(accepted[1]), tostring(accepted[2]), tostring(accepted[3])), "false · true · true"
        end)
        Chk("T505", "M", "T-PD7a Verdichtung nach Vorgabe: 48 Std. voll, bis 7 Tage 1/Std., bis 60 Tage 1/Tag, älter weg, ohne Handel seit 30 Tagen nur Tageswerte; Marktwert ±3 %", function()
            local md, now = {}, time()
            for k = 1, 20 do
                local h = {}
                for i = 70 * 8, 1, -1 do                                 -- alle 3 Std. ein Scan, 70 Tage
                    h[#h + 1] = { t = now - i * 3 * 3600 + 300, p = 1000 + k * 10 + ((i * 7) % 11) * 5, q = 20 + i % 5 }
                end
                md[990019000 + k] = { history = h }
            end
            -- ein Item ohne Handel seit 40 Tagen
            local idle = {}
            for i = 1, 60 do idle[#idle + 1] = { t = now - 100 * 86400 + i * 3600 * 20, p = 500, q = 3 } end
            md[990019100] = { history = idle }
            local saved = A.GetHistory
            A.GetHistory = function(self, id) if md[id] then return md[id].history end return saved(self, id) end
            local res = { pcall(function()
                local mv0 = {}
                for id in pairs(md) do A:InvalidateMarket(id); mv0[id] = A:GetMarketValue(id) end
                local before, after = A:CompactAll(now, md)
                local worst, bad = 0, nil
                for id, e in pairs(md) do
                    if id ~= 990019100 then
                        A:InvalidateMarket(id)
                        local mv1 = A:GetMarketValue(id)
                        worst = math.max(worst, math.abs(mv1 / mv0[id] - 1))
                    end
                    local perHour, perDay = {}, {}
                    for _, x in ipairs(e.history) do
                        local age = now - x.t
                        if age > 60 * 86400 then bad = "älter als 60 Tage" end
                        if age > 7 * 86400 or id == 990019100 then
                            local d = math.floor(x.t / 86400); if perDay[d] then bad = "2 Werte am selben Tag" end; perDay[d] = true
                        elseif age > 48 * 3600 then
                            local hh = math.floor(x.t / 3600); if perHour[hh] then bad = "2 Werte in derselben Stunde" end; perHour[hh] = true
                        end
                    end
                end
                return before, after, worst, bad
            end) }
            A.GetHistory = saved
            for id in pairs(md) do A:InvalidateMarket(id) end
            if not res[1] then error(res[2], 0) end
            local before, after, worst, bad = res[2], res[3], res[4], res[5]
            local ok = after < before and worst <= 0.03 and bad == nil
            return ok, string.format("Zeilen %d -> %d · Marktwert max. %.1f %% · Verstösse: %s", before, after, worst * 100, tostring(bad or "keine")),
                "weniger Zeilen · ≤ 3 % · keine"
        end)
        -- T-PD7 (< 8 MB bei 5'000 Items × 14 Tagen) bleibt offen: mit der Vorgabe und stündlichen Scans bleiben je Item
        -- 48 + 120 + 7 Zeilen (~61 Bytes je Zeile in der Datei) -> ~53 MB; Begründung im Bericht an die Prüf-Sitzung.
        Chk("T506", "M", "T-MP1 Scan mit Waren -> GetCurrent-Zeit der Ware = Scanzeit (Preisverlauf in der Sandbox; Nachbildung s94 mit ganzem Scan)", function()
            local saved = A.db.marketData
            A.db.marketData = {}
            local ID = 990019201
            local res = { pcall(function()
                local t1, t2 = time() - 7 * 3600, time() - 30
                A:RecordPrice(ID, 400, 120, t1)                    -- alter Scan
                local best = { [ID] = { price = 420, qty = 95 } }  -- neuer Scan: Ware, wie ProcessBest sie aufnimmt
                for id, b in pairs(best) do A:RecordPrice(id, b.price, b.qty, t2, false, b.u) end
                local p, q, t = A:GetCurrent(ID)
                return p, t, t2
            end) }
            A.db.marketData = saved
            A:InvalidateMarket(ID)
            if not res[1] then error(res[2], 0) end
            local p, t, t2 = res[2], res[3], res[4]
            return p == 420 and t == t2, string.format("Preis %s · Zeit = Scanzeit %s", tostring(p), tostring(t == t2)), "420 · true"
        end)
        Chk("T507", "M", "T-AB8c Entzauber-Protokoll voll (2000) -> alter Einstand nur ab dessen ältestem Eintrag (Käufe davor zählen nicht als Bestand)", function()
            local BK = A.Books
            local saved = { led = A.db.ledger, dl = A.db.deLog, tdb = BK.testDB, idx = BK.oldIdx, since = BK.oldIdxSince }
            local now, X = time(), 990019301
            local dl = {}
            for i = 1, 2000 do dl[i] = { t = now - 5 * 86400 + i * 60, itemID = (i == 10) and X or 990019302 } end
            A.db.ledger = { entries = {
                { kind = "buy", itemID = X, qty = 10, amount = 10000, t = now - 20 * 86400 },
                { kind = "buy", itemID = X, qty = 5, amount = 5000, t = now - 2 * 86400 },
            } }
            A.db.deLog, BK.testDB, BK.oldIdx = dl, nil, nil
            local res = { pcall(function() return BK:OldIndex({ since = now }) end) }
            A.db.ledger, A.db.deLog, BK.testDB, BK.oldIdx, BK.oldIdxSince = saved.led, saved.dl, saved.tdb, saved.idx, saved.since
            if not res[1] then error(res[2], 0) end
            local x = res[2][X]
            local ok = x and x.q == 4 and x.c == 4000
            return ok, string.format("alter Bestand %s Stück · %s Kupfer", tostring(x and x.q), tostring(x and x.c)), "4 · 4000"
        end)
        Chk("T508", "M", "T-AB4b Seelenstaub-Aufkauf (vorher 4s, jetzt 12s98) -> Kauf-Rechnung mit dem Preis vor dem Aufkauf (≤ 4s80), Testlog-Zeile mit beiden Preisen", function()
            local Dx4 = A.Disenchant
            local DUST = 990019401
            local now = time()
            local saved = { pi = A.PriceInfo, mv = A.GetMarketValue, gc = A.GetCurrent, gh = A.GetHistory, ph = A.PriceHints, rc = Dx4.RealisticCap, add = A.Diag.Add }
            local logged
            A.PriceInfo = function(self, id) if id == DUST then return { value = 1298, source = "ah", currentTime = now - 60, median = 1298 } end return saved.pi(self, id) end
            A.GetMarketValue = function(self, id) if id == DUST then return 1298 end return saved.mv(self, id) end
            A.GetCurrent = function(self, id, ...) if id == DUST then return 1298, 40, now - 60 end return saved.gc(self, id, ...) end
            A.GetHistory = function(self, id) if id == DUST then return {} end return saved.gh(self, id) end
            A.PriceHints = function(self, id) if id == DUST then return { buyout = { p0 = 400, since = now - 7200 }, fresh = true } end return saved.ph(self, id) end
            Dx4.RealisticCap = function(self, id) if id == DUST then return nil end return saved.rc(self, id) end
            A.Diag.Add = function(self, cat, txt) if cat == "AUFKAUF" then logged = txt end end
            Dx4.boLogged = {}
            local res = { pcall(Dx4.MatPrice, Dx4, DUST) }
            A.PriceInfo, A.GetMarketValue, A.GetCurrent, A.GetHistory, A.PriceHints, Dx4.RealisticCap, A.Diag.Add = saved.pi, saved.mv, saved.gc, saved.gh, saved.ph, saved.rc, saved.add
            if not res[1] then error(res[2], 0) end
            local v = res[2]
            local ok = v and v <= 480 and logged and logged:find("400", 1, true) and logged:find("1298", 1, true)
            return ok and true or false, string.format("Kauf-Preis %s · Testlog \"%s\"", tostring(v), tostring(logged)), "≤ 480 · Zeile mit 400 und 1298"
        end)
        Chk("T509", "M", "T-AB4c-a ganze Leiter 210 % des Marktwerts (Aufkauf), 9 Abläufe, gelerntes Maximum darunter -> Vorschlag knapp unter 28s99, Hinweis Aufkauf", function()
            local Se = A.Seller
            local ID = 990019501
            local saved = { pr = Se.prices[ID], mv = A.GetMarketValue, lim = A.Learn and A.Learn.Limits, bi = A.BuyoutInfo, ex = A.Ledger.ExpiryStreak }
            Se.prices[ID] = { time = GetTime(), stamp = time(), lowestOther = 2899, listings = {
                { price = 2899, qty = 78 }, { price = 2999, qty = 10 }, { price = 3052, qty = 5 } } }
            A.GetMarketValue = function(self, id) if id == ID then return 1380 end return saved.mv(self, id) end
            if A.Learn then A.Learn.Limits = function(self, id) if id == ID then return 1000, 1214, 2000 end return saved.lim(self, id) end end
            A.BuyoutInfo = function(self, id) if id == ID then return nil end return saved.bi(self, id) end
            A.Ledger.ExpiryStreak = function(self, id) if id == ID then return 9, 900 end return saved.ex(self, id) end
            local res = { pcall(Se.SuggestRaw, Se, ID) }
            local high = Se:HighMarket(ID)
            Se.prices[ID], A.GetMarketValue, A.BuyoutInfo, A.Ledger.ExpiryStreak = saved.pr, saved.mv, saved.bi, saved.ex
            if A.Learn then A.Learn.Limits = saved.lim end
            if not res[1] then error(res[2], 0) end
            local v, why = res[2], res[3]
            local ok = v and v < 2899 and v >= 2899 * 0.9 and why == L["Aufkauf – jetzt teuer verkaufen, Preis fällt meist bald (2 Std.)"] and high
            return ok and true or false, string.format("Vorschlag %s · \"%s\" · Leiter hoch %s", tostring(v), tostring(why), tostring(high)), "unter 2899 (Unterbieten-Einstellung, ≥ 90 %) · Aufkauf-Hinweis · true"
        end)
        Chk("T510", "M", "T-AB4c-b Preis von Hand getippt -> fertige Preisprüfung überschreibt ihn nicht; Item-Wechsel/Klick auf \"Vorschlag\" -> wieder automatisch", function()
            local Se = A.Seller
            local ID = 990019502
            local saved = Se.handPrice[ID]
            Se:SetHandPrice(ID, true)
            local a = Se:AutoApplyAllowed(ID)
            Se:SetHandPrice(ID, false)
            local b = Se:AutoApplyAllowed(ID)
            Se.handPrice[ID] = saved
            return a == false and b == true, string.format("nach Handpreis automatisch %s · nach Vorschlag %s", tostring(a), tostring(b)), "false · true"
        end)
        Chk("T511", "M", "T-SM1 zwei Ziele mit Treffer innert 30 s -> beide kaufbar, besserer Abstand zuerst; abgelaufener Treffer fällt raus", function()
            local Sn = A.Sniper
            local saved = { r = Sn.result, hp = Sn.hasPlan, q = Sn.hitQueue, gt = Sn.GetTarget, pn = Sn.PlanNext, fire = A.Fire, pend = Sn.pending }
            local tg = { ["i:990019601"] = { maxPrice = 1000 }, ["i:990019602"] = { maxPrice = 1000 }, ["i:990019603"] = { maxPrice = 1000 } }
            Sn.GetTarget = function(self, key) return tg[key] or saved.gt(self, key) end
            Sn.PlanNext = function(self) return self.result and { key = self.result.key } or nil end
            A.Fire = function() end
            Sn.pending = nil
            local now = GetTime()
            local rA = { key = "i:990019601", time = now, listings = { { price = 400, qty = 1 } } }   -- Abstand 60 %
            local rB = { key = "i:990019602", time = now, listings = { { price = 600, qty = 1 } } }   -- Abstand 40 %
            local rC = { key = "i:990019603", time = now - 600, listings = { { price = 100, qty = 1 } } } -- abgelaufen
            local res = { pcall(function()
                Sn.hitQueue, Sn.result, Sn.hasPlan = { rB, rA, rC }, nil, false
                local n0 = Sn:QueuedHits()
                Sn:PromoteHit()
                local first = Sn.result and Sn.result.key
                Sn.result, Sn.hasPlan = nil, false                    -- gekauft
                Sn:PromoteHit()
                local second = Sn.result and Sn.result.key
                return n0, first, second, #Sn.hitQueue
            end) }
            Sn.result, Sn.hasPlan, Sn.hitQueue, Sn.GetTarget, Sn.PlanNext, A.Fire, Sn.pending = saved.r, saved.hp, saved.q, saved.gt, saved.pn, saved.fire, saved.pend
            if not res[1] then error(res[2], 0) end
            local ok = res[2] == 2 and res[3] == "i:990019601" and res[4] == "i:990019602" and res[5] == 0
            return ok, string.format("wartend %d · zuerst %s · dann %s · übrig %d", res[2], tostring(res[3]), tostring(res[4]), res[5]), "2 · i:990019601 · i:990019602 · 0"
        end)
        Chk("T512", "M", "T-SM2 Ware ohne Menge mit Budget 5s, Max 22c -> 22 Stück (Budget / Max); Ausrüstung ohne Menge -> 1; Menge angegeben bleibt", function()
            local Sn = A.Sniper
            local saved = A.IsCommodityItem
            A.IsCommodityItem = function(self, id) if id == 990019701 then return true elseif id == 990019702 then return false end return saved(self, id) end
            local res = { pcall(function()
                local a, ea = Sn:DefaultQty(990019701, nil, 22, 500)
                local b = Sn:DefaultQty(990019702, nil, 22, 500)
                local c = Sn:DefaultQty(990019701, 5, 22, 500)
                return a, ea, b, c
            end) }
            A.IsCommodityItem = saved
            if not res[1] then error(res[2], 0) end
            local ok = res[2] == 22 and res[3] == true and res[4] == 1 and res[5] == 5
            return ok, string.format("Ware %s (leer %s) · Ausrüstung %s · Menge 5 -> %s", tostring(res[2]), tostring(res[3]), tostring(res[4]), tostring(res[5])), "22 · true · 1 · 5"
        end)
        Chk("T513", "M", "T-MV1 3 aktiv, 5 verkauft -> nach \"Aktualisieren\" 3 Zeilen (Kopf zählt weiter 5 verkauft); \"Verkaufte: an\" -> 8 Zeilen; neu Verkauftes bleibt bis zum nächsten Klick", function()
            local Se = A.Seller
            local saved = { owned = Se.owned, seen = Se.soldSeenAt, hb = Se.soldHideBefore }
            local rows = {}
            for i = 1, 3 do rows[#rows + 1] = { auctionID = 800 + i, itemID = 990019801, qty = 1 } end
            for i = 1, 5 do rows[#rows + 1] = { auctionID = 900 + i, itemID = 990019801, qty = 1, sold = true } end
            Se.owned, Se.soldSeenAt = rows, {}
            local res = { pcall(function()
                Se:VisibleOwned(false)                               -- Verkaufte gesehen
                Se:HideSoldNow(time() + 1)                           -- Klick auf "Aktualisieren"
                local a = #Se:VisibleOwned(false)
                local b = #Se:VisibleOwned(true)
                local sold = 0
                for _, o in ipairs(Se.owned) do if o.sold then sold = sold + 1 end end
                -- neu verkauft nach dem Klick
                Se.soldSeenAt["901:x"] = nil
                rows[#rows + 1] = { auctionID = 950, itemID = 990019801, qty = 1, sold = true }
                Se.soldSeenAt["950:990019801:1"] = time() + 5
                local c = #Se:VisibleOwned(false)
                return a, b, sold, c
            end) }
            Se.owned, Se.soldSeenAt, Se.soldHideBefore = saved.owned, saved.seen, saved.hb
            if not res[1] then error(res[2], 0) end
            local ok = res[2] == 3 and res[3] == 8 and res[4] == 5 and res[5] == 4
            return ok, string.format("nach Aktualisieren %d · mit Verkauften %d · Kopf verkauft %d · neu verkauft sichtbar %d", res[2], res[3], res[4], res[5]), "3 · 8 · 5 · 4"
        end)
        Chk("T500", "M", "T-PD5b Vollscan läuft -> Sniper sucht nicht (\"Warte, bis der Vollscan fertig ist.\"); 15-Min.-Sperre allein blockiert nicht", function()
            local Sn, VSx = A.Sniper, A.FullScan
            local saved = { run = VSx.running, open = A.IsAHOpen, s = Sn.search, p = Sn.pending }
            A.IsAHOpen = function() return true end
            Sn.search, Sn.pending = nil, nil
            VSx.running = { t0 = 0 }
            local res = { pcall(function()
                local ok1, why1 = Sn:CanSearch()
                VSx.running = nil
                return ok1, why1, Sn:FullScanRunning()
            end) }
            VSx.running, A.IsAHOpen, Sn.search, Sn.pending = saved.run, saved.open, saved.s, saved.p
            if not res[1] then error(res[2], 0) end
            local ok = res[2] == false and res[3] == L["Warte, bis der Vollscan fertig ist."] and res[4] == false
            return ok, string.format("während Vollscan: %s (%s) · danach läuft %s", tostring(res[2]), tostring(res[3]), tostring(res[4])), "false (Warte, bis der Vollscan fertig ist.) · false"
        end)
        Chk("T501", "M", "T-PD2 derselbe Kauf 3-mal gemeldet -> 1 Fall; alte Doppel beiseitegelegt (nicht gelöscht), Bericht \"Doppel 0\"", function()
            local F = A.Forecast
            local saved = F.testStore
            F.testStore = {}
            local savedLB = F.ledgerBuysTest
            local res = { pcall(function()
                local t = time()
                for _ = 1, 3 do F:OnBuy(990017001, 1, 900, "sniper", t, 7777) end            -- dieselbe Auktion 3-mal
                local f = F:Store()
                local n1 = #f.list
                -- alte Daten ohne auctionID: 1 echter Kauf in der Buchhaltung, 3 gleiche Fälle -> 2 Doppel;
                -- 4 echte Käufe in derselben Minute (Sniper) mit 4 Buchungen -> keine Doppel
                F.ledgerBuysTest = function(e) return e.id == 990017002 and 1 or (e.id == 990017003 and 4 or nil) end
                for _ = 1, 3 do F:OnBuy(990017002, 1, 500, "sniper", t) end
                for _ = 1, 4 do F:OnBuy(990017003, 1, 900, "sniper", t) end
                local before = F:Doubles(f)
                local moved = F:Dedupe(f)
                return n1, before, moved, F:Doubles(f), #f.list, #f.dups
            end) }
            F.testStore, F.ledgerBuysTest = saved, savedLB
            if not res[1] then error(res[2], 0) end
            local n1, before, moved, after, len, dups = res[2], res[3], res[4], res[5], res[6], res[7]
            local ok = n1 == 1 and before == 2 and moved == 2 and after == 0 and len == 6 and dups == 2
            return ok, string.format("Fälle %d · Doppel vorher %d · beiseite %d · nachher %d · Journal %d · beiseitegelegt %d", n1, before, moved, after, len, dups), "1 · 2 · 2 · 0 · 6 · 2"
        end)
        Chk("T486", "M", "T-AB7 Neustart nach Tagesbeginn: Gold-Abstimmung ab dem Neustart -> \"nicht gebucht\" 0 (Käufe vor dem Neustart zählen nicht)", function()
            return WithBooks(function(db)
                db.gold["Testa-Beispiel"] = { start = 50000, startT = db.since, day = A:DayStart(time()), dayStart = 120000 }   -- 7g vor dem Neustart ausgegeben
                BKx:OnInvoice(B_SD, 3, 1500, 0)
                local change, explained, diff = BKx:Reconcile("today", 51500)
                local r = BKx.lastRecon or {}
                local ok = change == 1500 and diff == 0 and r.show == false
                return ok, string.format("Gold %+d · erklärt %+d · nicht gebucht %+d · gezeigt %s", change, explained, diff, tostring(r.show)), "+1500 · +1500 · +0 · false"
            end)
        end)
        Chk("T487", "M", "T-AB2 zweiter Klick nach dem Einstellen (Platz in der Tasche leer) -> kein Aufruf, verständliche Meldung statt Lua-Fehler", function()
            local Se, AHx = A.Seller, A.AH
            local saved = { open = A.IsAHOpen, cnt = Se.CountInBags, lv = Se.LocValid, inv = Se.InvalidateBags, pc = AHx.PostCommodity, pp = Se.pendingPost }
            local calls = 0
            A.IsAHOpen = function() return true end
            Se.CountInBags = function() return 17, { commodity = true, count = 17, slots = { { loc = {} } } } end
            Se.LocValid = function() return false end
            Se.InvalidateBags = function() end
            AHx.PostCommodity = function() calls = calls + 1 end
            Se.pendingPost = nil
            local res = { pcall(Se.PostSource, Se, 990016001) }     -- Prüfung vor dem Aufruf (Se:Post ist im Selbsttest gesperrt)
            A.IsAHOpen, Se.CountInBags, Se.LocValid, Se.InvalidateBags, AHx.PostCommodity, Se.pendingPost = saved.open, saved.cnt, saved.lv, saved.inv, saved.pc, saved.pp
            if not res[1] then error(res[2], 0) end
            local ok = res[2] == false and calls == 0 and res[3] == L["Schon eingestellt – nicht mehr in deinen Taschen."]
            return ok, string.format("%s · Aufrufe %d · \"%s\"", tostring(res[2]), calls, tostring(res[3])), "false · 0 · Schon eingestellt – nicht mehr in deinen Taschen."
        end)
        Chk("T488", "M", "T-AB1 Status statt \"?\": Grund (AH zu / wartet); Materialpreise hinten an (eigene Auktionen zuerst); abgebrochene Zeile sofort weg", function()
            local Se = A.Seller
            local saved = { open = A.IsAHOpen, q = Se.queue, bg = Se.bgQueue, s = Se.search, owned = Se.owned }
            Se.queue, Se.bgQueue, Se.search = { 990016002 }, {}, nil
            A.IsAHOpen = function() return false end
            local res = { pcall(function()
                local w1 = Se:WaitReason(990016002)
                Se:CheckPriceBg(990016003)
                local qOk = #Se.queue == 1 and Se.queue[1] == 990016002 and Se.bgQueue[1] == 990016003
                local row = { auctionID = 77, itemID = 990016002, qty = 3 }
                Se.owned = { { auctionID = 77, itemID = 990016002, qty = 2, sold = true }, row }
                Se:DropOwnedRow({ auctionID = 77, row = row })
                return w1, qOk, #Se.owned, Se.owned[1] and Se.owned[1].sold
            end) }
            A.IsAHOpen, Se.queue, Se.bgQueue, Se.search, Se.owned = saved.open, saved.q, saved.bg, saved.s, saved.owned
            if not res[1] then error(res[2], 0) end
            local ok = res[2] == L["AH zu"] and res[3] and res[4] == 1 and res[5] == true
            return ok, string.format("\"%s\" · Reihenfolge %s · Zeilen danach %d (verkaufte bleibt)", tostring(res[2]), tostring(res[3]), res[4]), "AH zu · true · 1"
        end)
        Chk("T489", "M", "T-AB4 Seelenstaub-Aufkauf (12s98 statt 4s): kein Kauf-Signal; eigene Ware -> \"Jetzt teuer – verkaufen ... Aufkauf\"", function()
            local a = WithTM({ price = Flat, cur = 1298, buyout = { p0 = 400, since = 1 } }, function(TMx) return { TMx:Signal(JK, "any") } end)
            local b = WithTM({ price = Flat, cur = 1298, buyout = { p0 = 400, since = 1 } }, function(TMx) return { TMx:Signal(JK, "own") } end)
            local txt = b[1] and A.Timing:Text(b[1]) or ""
            local ok = a[1] == nil and a[2] == "aufkauf" and b[1] and b[1].kind == "sell" and b[1].buyout and txt:find(L["Aufkauf – Preis kann schnell fallen"], 1, true) ~= nil
            return ok, string.format("Tooltip fremd: %s · eigene Ware: %s", tostring(a[2]), txt), "aufkauf · Jetzt teuer – verkaufen (+225 %) · Aufkauf – Preis kann schnell fallen"
        end)
        Chk("T490", "M", "T-AB5 Nebenmaterial mit 37 % Anteil am Wert 25 Std. alt -> veraltet (kein Betrag), auch wenn das Hauptmaterial frisch ist", function()
            local Dx3 = A.Disenchant
            local M1, M2, IT = 990016011, 990016012, 990016010
            local saved = { pm = Dx3.PerPartMats, mp = Dx3.MatPrice, gc = A.GetCurrent }
            Dx3.PerPartMats = function(self, id) if id == IT then return { { id = M1, per = 1 }, { id = M2, per = 0.5 } } end return saved.pm(self, id) end
            Dx3.MatPrice = function(self, id) if id == M1 then return 100 elseif id == M2 then return 120 end return saved.mp(self, id) end
            A.GetCurrent = function(self, id, ...)
                if id == M1 then return 100, 50, time() - 600 elseif id == M2 then return 120, 50, time() - 25 * 3600 end
                return saved.gc(self, id, ...)
            end
            local res = { pcall(Dx3.StaleMain, Dx3, IT) }
            Dx3.PerPartMats, Dx3.MatPrice, A.GetCurrent = saved.pm, saved.mp, saved.gc
            if not res[1] then error(res[2], 0) end
            local ok = res[2] == true and res[3] == M2
            return ok, string.format("veraltet %s · Material %s · %s Std.", tostring(res[2]), tostring(res[3]), tostring(res[4])), string.format("true · %d · 25 Std.", M2)
        end)
        -- ============================================================
        -- TU1–TU6 (anweisung-tests-umfassend 13.11.): Marktlagen, Abläufe, Standardwerte, Grundregeln, Regressionen.
        -- Nur eigene Funktionen ersetzt und zurückgestellt; erfundene Zahlen; nichts Echtes ausgeführt.
        -- ============================================================
        local TUX, TUW = 990020001, 990020002            -- Ware (commodity) / Ausrüstung
        -- Marktlage herstellen: Leiter (Se.prices), Marktwert, aktueller Preis + Zeit, Verlauf, Aufkauf, Händler, Ware ja/nein
        local function WithLage(lage, fn)
            local Se, Dx = A.Seller, A.Disenchant
            local saved = { p1 = Se.prices[TUX], p2 = Se.prices[TUW], mv = A.GetMarketValue, gc = A.GetCurrent, gh = A.GetHistory,
                bi = A.BuyoutInfo, vp = A.GetVendorPrice, ic = A.IsCommodityItem, lim = A.Learn and A.Learn.Limits, ph = A.PriceHints,
                pi = A.PriceInfo, rc = Dx.RealisticCap, ex = A.Ledger.ExpiryStreak, fl = Se.GetFloor, af = Se.AutoFloor, hp1 = Se.handPrice[TUX], hp2 = Se.handPrice[TUW] }
            local mine = { [TUX] = true, [TUW] = true }
            local now = time()
            local scanAge = lage.scanAge or 60
            A.GetMarketValue = function(self, id) if mine[id] then return lage.mv end return saved.mv(self, id) end
            A.GetCurrent = function(self, id, ...) if mine[id] then return lage.cur, lage.qty or 50, now - scanAge end return saved.gc(self, id, ...) end
            A.GetHistory = function(self, id) if mine[id] then return lage.hist or {} end return saved.gh(self, id) end
            A.BuyoutInfo = function(self, id) if mine[id] then return lage.buyout end return saved.bi(self, id) end
            A.GetVendorPrice = function(self, id) if mine[id] then return lage.vendor or 0 end return saved.vp(self, id) end
            A.IsCommodityItem = function(self, id) if id == TUX then return true elseif id == TUW then return false end return saved.ic(self, id) end
            if A.Learn then A.Learn.Limits = function(self, id) if mine[id] then return nil end return saved.lim(self, id) end end
            A.PriceHints = function(self, id) if mine[id] then return { buyout = lage.buyout, fresh = scanAge < 1800 } end return saved.ph(self, id) end
            A.PriceInfo = function(self, id) if mine[id] then return { value = lage.cur, source = "ah", currentTime = now - scanAge, median = lage.mv } end return saved.pi(self, id) end
            Dx.RealisticCap = function(self, id) if mine[id] then return nil end return saved.rc(self, id) end
            A.Ledger.ExpiryStreak = function(self, id) if mine[id] then return lage.expired or 0, 0 end return saved.ex(self, id) end
            Se.GetFloor = function(self, id) if mine[id] then return lage.floor end return saved.fl(self, id) end
            Se.AutoFloor = function(self, id) if mine[id] then return nil end return saved.af(self, id) end
            for id in pairs(mine) do
                Se.handPrice[id] = nil
                Se.prices[id] = lage.ladder and { time = GetTime() - (lage.checkAge or 0), stamp = now, listings = lage.ladder,
                    lowestOther = lage.lowestOther, lowestOwn = lage.lowestOwn } or nil
            end
            local res = { pcall(fn, Se, Dx) }
            Se.prices[TUX], Se.prices[TUW], Se.handPrice[TUX], Se.handPrice[TUW] = saved.p1, saved.p2, saved.hp1, saved.hp2
            A.GetMarketValue, A.GetCurrent, A.GetHistory, A.BuyoutInfo, A.GetVendorPrice, A.IsCommodityItem = saved.mv, saved.gc, saved.gh, saved.bi, saved.vp, saved.ic
            if A.Learn then A.Learn.Limits = saved.lim end
            A.PriceHints, A.PriceInfo, Dx.RealisticCap, A.Ledger.ExpiryStreak, Se.GetFloor, Se.AutoFloor = saved.ph, saved.pi, saved.rc, saved.ex, saved.fl, saved.af
            for id in pairs(mine) do A:InvalidateMarket(id) end
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        local function Ladder(list) local t = {} for i, x in ipairs(list) do t[i] = { price = x[1], qty = x[2], own = x[3] } end return t end
        -- Erwartung je Lage (Marktwert 1000): Vorschlag-Bereich, Leiter hoch, Hinweis "billiger" unterdrückt, Kauf-Preis Entzaubern
        local LAGEN = {
            { "L-NORMAL", { mv = 1000, cur = 990, ladder = Ladder({ { 990, 50 }, { 1000, 40 }, { 1010, 30 } }), lowestOther = 990, expired = 3 },
                { lo = 890, hi = 989, high = false, noCheaper = false, why = "unterbietet" } },
            { "L-AUFKAUF", { mv = 1380, cur = 2899, ladder = Ladder({ { 2899, 78 }, { 2999, 10 }, { 3052, 5 }, { 3100, 3 } }), lowestOther = 2899, expired = 9 },
                { lo = 2609, hi = 2898, high = true, noCheaper = true, why = "Aufkauf" } },
            { "L-AUFKAUF-KENNZ", { mv = 1000, cur = 2500, ladder = Ladder({ { 2500, 4 } }), lowestOther = 2500, buyout = { p0 = 1000, since = 1 } },
                { lo = 2250, hi = 2499, high = true, noCheaper = true, why = "Aufkauf", buyPrice = 1000 } },
            { "L-AUSREISSER", { mv = 1000, cur = 5000, ladder = Ladder({ { 5000, 1 } }), lowestOther = 5000 },
                { lo = 1000, hi = 1000, high = false, noCheaper = true, why = "Ausreisser" } },
            { "L-FLUT", { mv = 1000, cur = 800, qty = 300, ladder = Ladder({ { 800, 300 } }), lowestOther = 800, hist = { { t = time() - 86400, p = 1000, q = 100 } } },
                { lo = 720, hi = 799, high = false, noCheaper = false, why = "unterbietet" } },
            { "L-DUENN", { mv = 1000, cur = 1050, ladder = Ladder({ { 1050, 2 }, { 1100, 1 } }), lowestOther = 1050 },
                { lo = 945, hi = 1049, high = false, noCheaper = true, why = "unterbietet" } },
            { "L-LEER", { mv = 1000, cur = 1000, ladder = Ladder({ { 1000, 5, true } }), lowestOwn = 1000 },
                { lo = 1000, hi = 1000, high = false, noCheaper = false, why = "eigenen" } },
            { "L-ALT", { mv = 1000, cur = 990, scanAge = 7 * 3600, checkAge = 3600, ladder = Ladder({ { 990, 50 } }), lowestOther = 990 },
                { lo = 1000, hi = 1000, high = false, noCheaper = false, why = "Marktwert" } },
            { "L-HAENDLER", { mv = 183, cur = 183, vendor = 500, ladder = Ladder({ { 183, 40 } }), lowestOther = 183 },
                { lo = 160, hi = 182, high = false, noCheaper = false, why = "unterbietet", vendorOk = false } },
        }
        for i, lg in ipairs(LAGEN) do
            local name, lage, want = lg[1], lg[2], lg[3]
            Chk(string.format("T%d", 513 + i), "M", "TU1 Marktlage " .. name .. ": Verkaufen-Vorschlag, Leiter-Erkennung, Hinweis \"billiger\", Entzauber-Kaufpreis, Händler", function()
                return WithLage(lage, function(Se, Dx)
                    local got = {}
                    for _, id in ipairs({ TUX, TUW }) do
                        local v, why = Se:SuggestRaw(id)
                        v = Se:RoundPrice(id, v)
                        local lo, hi = want.lo, want.hi
                        if id == TUW then lo, hi = math.floor(lo / 100) * 100 - 100, math.max(100, math.floor(hi / 100) * 100) end   -- Ausrüstung: ganze Silber
                        local high = Se:HighMarket(id) and true or false
                        local noCheaper = Se:SuppressCheaperHint(id)
                        local okV = v and v >= lo and v <= hi and tostring(why or ""):find(want.why, 1, true)
                        local okBuy = true
                        if want.buyPrice then local bp = Dx:MatPrice(id); okBuy = bp and bp <= want.buyPrice * 1.2 end
                        local okVendor = want.vendorOk == nil or A:VendorPlausible(id) == want.vendorOk
                        if not (okV and high == want.high and noCheaper == want.noCheaper and okBuy and okVendor) then
                            got[#got + 1] = string.format("%s: Vorschlag %s (%s) · hoch %s · ohne 'billiger' %s · Kauf-Ok %s · Händler-Ok %s",
                                id == TUX and "Ware" or "Ausrüstung", tostring(v), tostring(why), tostring(high), tostring(noCheaper), tostring(okBuy), tostring(okVendor))
                        end
                    end
                    return #got == 0, #got == 0 and "Ware und Ausrüstung wie erwartet" or table.concat(got, " | "),
                        string.format("Vorschlag %d–%d (%s) · hoch %s · ohne 'billiger' %s", want.lo, want.hi, want.why, tostring(want.high), tostring(want.noCheaper))
                end)
            end)
        end
        Chk("T523", "M", "TU1 Marktlagen L-FALLEND / L-SPITZE: Zeitpunkt-Zeile 'Fällt – abwarten' statt kaufen bzw. 'Jetzt teuer – verkaufen'", function()
            local function Fall(day) return ({ [6] = 960, [7] = 920, [8] = 880 })[day] or 1000 end
            local a = WithTM({ price = Fall, cur = 820 }, function(TMx) return { TMx:Signal(JK, "any") } end)
            local b = WithTM({ price = Flat, cur = 1200 }, function(TMx) return { TMx:Signal(JK, "own") } end)
            local ok = a[1] and a[1].kind == "wait" and b[1] and b[1].kind == "sell"
            return ok, string.format("fallend %s · Spitze %s", tostring(a[1] and a[1].kind or a[2]), tostring(b[1] and b[1].kind or b[2])), "wait · sell"
        end)
        Chk("T524", "M", "TU1 Marktlage L-RELIST: Auktion verschwindet und kommt mit gleicher Menge neu -> kein Verkauf gebucht", function()
            return WithBooks(function(db)
                BKx:OnBuy(990012001, 5, 5000)
                local n1 = BKx:CheckOwned({ { auctionID = 31, itemID = 990012001, qty = 5, buyout = 6000 } })
                local n2 = BKx:CheckOwned({ { auctionID = 32, itemID = 990012001, qty = 5, buyout = 6000 } })    -- neu eingestellt
                local s = BKx:Summary("all")
                return n1 == 0 and n2 == 0 and s.pendingN == 0, string.format("gebucht %d/%d · ausstehend %d", n1, n2, s.pendingN), "0/0 · 0"
            end)
        end)
        -- TU2 Abläufe
        Chk("T525", "M", "TU2 Ablauf: Preis tippen -> Preisprüfung kommt später -> Preis bleibt; Item-Wechsel -> wieder Vorschlag; Item B während A lädt -> kein Preis von A", function()
            return WithLage({ mv = 1000, cur = 990, ladder = Ladder({ { 990, 50 } }), lowestOther = 990 }, function(Se)
                Se:SetHandPrice(TUX, true)                               -- getippt
                local keep = not Se:AutoApplyAllowed(TUX)                -- Preisprüfung fertig: nicht überschreiben
                Se:SetHandPrice(TUX, false)                              -- Item-Wechsel
                local auto = Se:AutoApplyAllowed(TUX)
                Se.prices[TUW] = nil                                      -- B hat (noch) keine Prüfung
                local vB, whyB = Se:SuggestRaw(TUW)
                local ok = keep and auto and vB == 1000 and tostring(whyB):find("Marktwert", 1, true)
                return ok and true or false, string.format("bleibt %s · danach automatisch %s · B: %s (%s)", tostring(keep), tostring(auto), tostring(vB), tostring(whyB)), "true · true · 1000 (Marktwert)"
            end)
        end)
        Chk("T526", "M", "TU2 Ablauf Sniper: drei Ziele mit Treffern innert 30 s -> alle drei nacheinander kaufbar (bester zuerst), nach Fehlkauf bleiben die anderen", function()
            local Sn = A.Sniper
            local saved = { r = Sn.result, hp = Sn.hasPlan, q = Sn.hitQueue, gt = Sn.GetTarget, pn = Sn.PlanNext, fire = A.Fire, pend = Sn.pending }
            local tg = {}
            for i = 1, 3 do tg["i:99002010" .. i] = { maxPrice = 1000 } end
            Sn.GetTarget = function(self, key) return tg[key] or saved.gt(self, key) end
            Sn.PlanNext = function(self) return self.result and { key = self.result.key } or nil end
            A.Fire = function() end
            Sn.pending = nil
            local now = GetTime()
            local res = { pcall(function()
                Sn.hitQueue, Sn.result, Sn.hasPlan = {}, nil, false
                for i, p in ipairs({ 700, 300, 500 }) do Sn:QueueHit({ key = "i:99002010" .. i, time = now, listings = { { price = p, qty = 1 } } }) end
                local order = {}
                for _ = 1, 3 do
                    Sn:PromoteHit()
                    order[#order + 1] = Sn.result and Sn.result.key:sub(-1) or "-"
                    Sn.result, Sn.hasPlan = nil, false                    -- gekauft bzw. Kauf fehlgeschlagen: weiter zum nächsten
                end
                return table.concat(order, ",")
            end) }
            Sn.result, Sn.hasPlan, Sn.hitQueue, Sn.GetTarget, Sn.PlanNext, A.Fire, Sn.pending = saved.r, saved.hp, saved.q, saved.gt, saved.pn, saved.fire, saved.pend
            if not res[1] then error(res[2], 0) end
            return res[2] == "2,3,1", "Reihenfolge " .. tostring(res[2]), "2,3,1 (300c, 500c, 700c)"
        end)
        -- TU3 Standardwerte (Liste im Testbericht)
        Chk("T527", "M", "TU3 Standardwerte leerer Felder: Sniper-Menge (Ware/Ausrüstung), Budget, Mindestpreis, Verkaufen-Menge, Laufzeit, Unterbieten", function()
            local Sn, Se = A.Sniper, A.Seller
            local sc = A.IsCommodityItem
            A.IsCommodityItem = function(self, id) if id == TUX then return true elseif id == TUW then return false end return sc(self, id) end
            local res = { pcall(function()
                local qW = Sn:DefaultQty(TUX, nil, 22, 50000)
                local qA = Sn:DefaultQty(TUW, nil, 22, 50000)
                local qN = Sn:DefaultQty(TUX, nil, 22, nil)
                local floor = Se:GetFloor(TUX)
                local dur = A.db.seller and A.db.seller.duration
                local uc = A.db.seller and A.db.seller.undercut or "copper"
                return qW, qA, qN, floor, dur, uc
            end) }
            A.IsCommodityItem = sc
            if not res[1] then error(res[2], 0) end
            local qW, qA, qN, floor, dur, uc = res[2], res[3], res[4], res[5], res[6], res[7]
            TR.defaults = {
                string.format("Sniper Menge leer, Ware, Budget 5g, Max 22c -> %d (bis Budget)", qW),
                string.format("Sniper Menge leer, Ausrüstung -> %d", qA),
                string.format("Sniper Menge leer ohne Budget -> %d; Budget leer -> Menge × Max", qN),
                string.format("Mindestpreis leer -> %s (kein Mindestpreis; automatisch Händler/Einstand nur als Grenze)", tostring(floor)),
                "Verkaufen Menge leer -> 1 (grauer Platzhalter)",
                string.format("Laufzeit -> %s (zuletzt gewählt, sonst Stufe 1)", tostring(dur or 1)),
                string.format("Unterbieten -> %s", tostring(uc)),
            }
            local ok = qW == 2272 and qA == 1 and qN == 1 and floor == nil
            return ok, table.concat(TR.defaults, " · "), "2272 · 1 · 1 · kein Mindestpreis"
        end)
        -- TU4 Grundregeln mit Zufallsdaten (fester Startwert, im Bericht genannt)
        Chk("T528", "M", "TU4 Grundregeln, 1000 zufällige Leitern (Startwert 4711): Vorschlag ganzzahlig ≥ 1, nie unter günstigstem fremdem − Unterbietung (ausser Ausreisser), kein 'billiger' über Marktwert", function()
            local seed = 4711
            local function rnd(n) seed = (seed * 1103515245 + 12345) % 2147483648; return seed % n end
            local bad = {}
            local res = { pcall(function()
                for case = 1, 1000 do
                    local mv = 100 + rnd(5000)
                    local n = 1 + rnd(8)
                    local list, lowest, qtyAll = {}, nil, 0
                    for k = 1, n do
                        local p = math.max(1, math.floor(mv * (30 + rnd(270)) / 100))
                        local q = 1 + rnd(40)
                        list[#list + 1] = { p, q }
                        qtyAll = qtyAll + q
                        lowest = lowest and math.min(lowest, p) or p
                    end
                    table.sort(list, function(a, b) return a[1] < b[1] end)
                    local lage = { mv = mv, cur = lowest, ladder = Ladder(list), lowestOther = lowest }
                    WithLage(lage, function(Se)
                        local v, why = Se:SuggestRaw(TUX)
                        local u = Se:Undercut(lowest, TUX)
                        local outlier = tostring(why):find("Ausreisser", 1, true)
                        local okInt = type(v) == "number" and v == math.floor(v) and v >= 1 and v == v and v < math.huge
                        local okLow = outlier or v >= u
                        local okHint = not (lowest > mv) or Se:SuppressCheaperHint(TUX)
                        if not (okInt and okLow and okHint) and #bad < 5 then
                            bad[#bad + 1] = string.format("Fall %d: Markt %d, günstigstes %d (%d Angebote) -> Vorschlag %s (%s), Hinweis-Sperre %s",
                                case, mv, lowest, n, tostring(v), tostring(why), tostring(okHint))
                        end
                    end)
                    if case % 50 == 0 then A:Pause() end
                end
            end) }
            if not res[1] then error(res[2], 0) end
            return #bad == 0, #bad == 0 and "1000 Fälle ohne Verletzung (Startwert 4711)" or table.concat(bad, " | "), "0 Verletzungen"
        end)
        Chk("T529", "M", "TU4 Grundregel Buchhaltung mit Zufallsfolgen (Startwert 99): Einstand rein = Einstand raus + Lager, auf den Kupfer", function()
            local seed = 99
            local function rnd(n) seed = (seed * 1103515245 + 12345) % 2147483648; return seed % n end
            return WithBooks(function(db)
                local ch, ids = "Testa-Beispiel", { B_STU, B_SD, B_AE }
                local paid = 0
                for _ = 1, 300 do
                    local r = rnd(10)
                    local id = ids[1 + rnd(3)]
                    if r < 5 then local q, c = 1 + rnd(5), 100 + rnd(2000); BKx:OnBuy(id, q, c); paid = paid + c
                    elseif r < 8 then BKx:OnInvoice(id, 1 + rnd(3), 500 + rnd(1500), 0)
                    else BKx:OnDisenchant(B_STU, { { B_SD, 1 + rnd(2) } }) end
                end
                local out = 0
                for _, e in ipairs(db.log) do if e.k == "sale" then out = out + (e.cost or 0) end end
                local held = 0
                for _, p in pairs(db.cb[ch] or {}) do held = held + (p.c or 0) end
                -- Entzaubern bucht nur um (Teil -> Material): Summe bleibt
                local ok = paid == out + held
                return ok, string.format("bezahlt %d = verkauft (Einstand) %d + Lager %d -> %d", paid, out, held, out + held), "gleich"
            end)
        end)
        Chk("T530", "M", "T-HP1 Händlerpreis-Tabelle 5s, Spiel sagt nach dem Hotfix 1s25 -> 1s25; keine Händler-Chance mit ungeprüftem Tabellenpreis", function()
            local ID = 990020301
            local saved = { vp = A.db.vendorPrices, ov = A.apiOverride, chk = A.vendorChecked[ID], add = A.Diag.Add, mv = A.GetMarketValue }
            A.db.vendorPrices = { [ID] = 500 }
            A.vendorChecked[ID] = nil
            A.Diag.Add = function() end
            A.GetMarketValue = function(self, id) if id == ID then return 183 end return saved.mv(self, id) end
            local o = {}
            for k, v in pairs(saved.ov or {}) do o[k] = v end
            local loaded = false
            o.GetItemInfo = function(id) if id == ID and loaded then return "Testgranate", nil, 1, 20, 20, "x", "y", 20, "", 1, 125 end return nil end
            A.apiOverride = o
            local res = { pcall(function()
                local before = A:GetVendorPrice(ID)                  -- Spiel kennt das Item noch nicht -> Tabelle (Rückfall)
                local plausibleBefore = A.vendorChecked[ID] == true or not A.vendorFromTable[ID]
                loaded = true
                local after = A:GetVendorPrice(ID)
                return before, plausibleBefore, after, A.db.vendorPrices[ID]
            end) }
            A.db.vendorPrices, A.apiOverride, A.vendorChecked[ID], A.Diag.Add, A.GetMarketValue = saved.vp, saved.ov, saved.chk, saved.add, saved.mv
            A.vendorFromTable[ID] = nil
            if not res[1] then error(res[2], 0) end
            local ok = res[2] == 500 and res[3] == false and res[4] == 125 and res[5] == 125
            return ok, string.format("ungeladen %s (geprüft %s) · Spiel %s · Tabelle nachgeführt %s", tostring(res[2]), tostring(res[3]), tostring(res[4]), tostring(res[5])), "500 (false) · 125 · 125"
        end)
        Chk("T531", "M", "T-HP2 Mindest-Einzahlung: Formel < 1s und gemessen 1c (ab 17.11.) -> Minimum 1c; gemessen 1s -> 1s", function()
            local Se = A.Seller
            local ID = 990020302
            local saved = { md = A.db.minDeposit, vp = A.GetVendorPrice, fe = A.IsForever, fire = A.Fire, add = A.Diag.Add }
            A.GetVendorPrice = function(self, id) if id == ID then return 10 end return saved.vp(self, id) end
            A.IsForever = function() return true end
            A.Fire, A.Diag.Add = function() end, function() end
            local res = { pcall(function()
                Se:MeasureMinDeposit({ itemID = ID, qty = 1, duration = 3, auctions = 1 }, 1)
                local a = A:MinDeposit()
                Se:MeasureMinDeposit({ itemID = ID, qty = 1, duration = 3, auctions = 1 }, 100)
                return a, A:MinDeposit()
            end) }
            A.db.minDeposit, A.GetVendorPrice, A.IsForever, A.Fire, A.Diag.Add = saved.md, saved.vp, saved.fe, saved.fire, saved.add
            if not res[1] then error(res[2], 0) end
            return res[2] == 1 and res[3] == 100, string.format("gemessen 1c -> %s · gemessen 1s -> %s", tostring(res[2]), tostring(res[3])), "1 · 100"
        end)
        Chk("T532", "M", "API-PM AHSentinel.API.WorthUpTo / MarketState vorhanden (bis zum Rechenkern nil erlaubt); WorthUpTo = \"Lohnt bis\" im Tooltip", function()
            local API = _G.AHSentinel and _G.AHSentinel.API
            if not (API and API.WorthUpTo and API.MarketState) then return false, "fehlt", "beide Funktionen vorhanden" end
            local TT = A.Tooltip
            local okT, r = pcall(TT.DisenchantVerdict, TT, FAKE_ID)
            local w = API.WorthUpTo(FAKE_ID)
            local tip = okT and r and r.limit or nil
            local ok = (w == nil and tip == nil) or (w ~= nil and tip ~= nil and math.abs(w - tip) <= 1) or w == nil
            return ok, string.format("API %s · Tooltip %s · Lage %s", tostring(w), tostring(tip), tostring((API.MarketState(FAKE_ID)))), "gleich oder nil"
        end)
        -- Q / ST1–ST3 (anweisung-strategie-entzaubern-grenzen)
        local function KeyFor(ilvl)
            local Dq = A.Disenchant
            for k = 1, 20 do
                local key = "2:" .. k .. ":a"
                local q, from, to = Dq:KeyInfo(key)
                if q and from and to and ilvl >= from and ilvl <= to then return key end
            end
        end
        local function WithMatPrices(key, unit, bump, fn)
            local Dq = A.Disenchant
            local y = Dq:YieldForKey(key) or Dq:PriorForKey(key)
            local ids, sum = {}, 0
            for _, e in ipairs(y or {}) do if (e[2] or 0) > 0 then ids[e[1]] = true; sum = sum + e[2] * (e[3] or 1) end end
            local per = unit and sum > 0 and unit / sum or 100
            local saved = { gc = A.GetCurrent, mp = Dq.MatPrice }
            A.GetCurrent = function(self, id, ...) if ids[id] then return math.floor(per + 1 + 0.5), 100, time() - 180 end return saved.gc(self, id, ...) end
            Dq.MatPrice = function(self, id) if ids[id] then return math.floor(per + 0.5) * ((bump and bump[id]) or 1), 180, per, "ah" end return saved.mp(self, id) end
            local res = { pcall(fn, Dq, ids) }
            A.GetCurrent, Dq.MatPrice = saved.gc, saved.mp
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        Chk("T533", "M", "T-ST1 Referenz-Nachrechnung: Gruppe 26–30 = 1050c ± 2 %, 36–40 = 2275c ± 2 %; ein Material mit Aufkauf-Preis (+50 %) -> Abweichung > 5 % mit Material genannt", function()
            local k30, k40 = KeyFor(28), KeyFor(38)
            if not (k30 and k40) then return false, "Gruppen nicht gefunden", "2:x:a für 28 und 38" end
            local r30 = WithMatPrices(k30, 1050, nil, function(Dq) return Dq:ReferenceCheck(k30) end)
            local r40 = WithMatPrices(k40, 2275, nil, function(Dq) return Dq:ReferenceCheck(k40) end)
            local first
            local rBad = WithMatPrices(k40, 2275, setmetatable({}, { __index = function(t, id) if not first then first = id end return id == first and 1.5 or 1 end }),
                function(Dq) return Dq:ReferenceCheck(k40) end)
            local ok = r30 and math.abs(r30.ref / 1050 - 1) <= 0.02 and math.abs(r30.dev) <= 0.05
                and r40 and math.abs(r40.ref / 2275 - 1) <= 0.02 and math.abs(r40.dev) <= 0.05
                and rBad and math.abs(rBad.dev) > 0.05 and rBad.worst and rBad.worst.dev and rBad.worst.dev > 0.4
            return ok and true or false, string.format("26–30 Wert %s (eigene %s) · 36–40 Wert %s (eigene %s) · Aufkauf-Fall Abweichung %.0f %% (Material %s)",
                tostring(r30 and r30.ref), tostring(r30 and r30.ours), tostring(r40 and r40.ref), tostring(r40 and r40.ours),
                (rBad and rBad.dev or 0) * 100, tostring(rBad and rBad.worst and rBad.worst.id)), "1050 · 2275 · > 5 % mit Material"
        end)
        Chk("T534", "M", "T-ST2 \"[Entzaubern lohnt]\" nur unter \"Lohnt bis\" mit frischen Preisen: Material 25 Std. alt -> keine Markierung; Preis über der Grenze -> keine", function()
            local Dq = A.Disenchant
            local ID = 990020401
            local saved = { dv = Dq.DealValue, sm = Dq.StaleMain }
            local stale = false
            Dq.DealValue = function(self, id) if id == ID then return 1200, 1200, true, "estimate", 0 end return saved.dv(self, id) end
            Dq.StaleMain = function(self, id) if id == ID then return stale, 10940, stale and 25 or 0 end return saved.sm(self, id) end
            local res = { pcall(function()
                local lim = Dq:WorthLimit(ID)
                local a = Dq:WorthMark(ID, lim)            -- genau an der Grenze
                local b = Dq:WorthMark(ID, lim + 1)        -- darüber
                stale = true
                local c = Dq:WorthMark(ID, 100)            -- alt -> nie
                return lim, a, b, c
            end) }
            Dq.DealValue, Dq.StaleMain = saved.dv, saved.sm
            if not res[1] then error(res[2], 0) end
            local want = A.Core:LimitFromNet(1200, 0)            -- RK2-A: eine Rechnung (ohne gelernte Marge 1000)
            local ok = res[2] == want and res[3] == true and res[4] == false and res[5] == false
            return ok, string.format("Lohnt bis %s · an der Grenze %s · darüber %s · alt %s", tostring(res[2]), tostring(res[3]), tostring(res[4]), tostring(res[5])), want .. " · true · false · false"
        end)
        Chk("T535", "M", "T-ST3 Grenze sinkt um 10 % -> Sniper-Ziel aus Entzaubern angepasst + genau eine Chat-Zeile; Änderung < 5 % -> still angepasst (RK2-B)", function()
            local Sn, Dq = A.Sniper, A.Disenchant
            local saved = { wl = Dq.WorthLimit, pr = A.Print, fire = A.Fire }
            local lim, printed = 900, {}
            Dq.WorthLimit = function(self, id) return lim end
            A.Print = function(self, msg) printed[#printed + 1] = msg end
            A.Fire = function() end
            local targets = { ["i:990020402"] = { itemID = 990020402, kind = "item", key = "i:990020402", maxPrice = 1000, de = true },
                ["i:990020403"] = { itemID = 990020403, kind = "item", key = "i:990020403", maxPrice = 1000 } }
            local res = { pcall(function()
                local n1 = Sn:UpdateDETargets(targets)
                lim = 880                                          -- nur noch 2 %
                local n2 = Sn:UpdateDETargets(targets)
                return n1, n2
            end) }
            Dq.WorthLimit, A.Print, A.Fire = saved.wl, saved.pr, saved.fire
            if not res[1] then error(res[2], 0) end
            local t1, t2 = targets["i:990020402"], targets["i:990020403"]
            -- RK2-B (b): auch < 5 % wird angepasst (Ziel immer genau "Lohnt bis"), Chat-Zeile nur ab 5 %
            local ok = res[2] == 1 and res[3] == 1 and t1.maxPrice == 880 and t2.maxPrice == 1000 and #printed == 1
            return ok, string.format("angepasst %d/%d · Max %d (anderes Ziel %d) · Chat-Zeilen %d", res[2], res[3], t1.maxPrice, t2.maxPrice, #printed), "1/1 · 880 (1000) · 1"
        end)
        Chk("T536", "M", "T-ST1b Referenz-Nachrechnung mit den ECHTEN Scan-Preisen (nur lesen): Gruppen 26–30, 31–35, 36–40 – Abweichung ≤ 5 %", function()
            local Dq = A.Disenchant
            local lines, bad, any = {}, {}, false
            for _, g in ipairs({ { 28, "26–30" }, { 33, "31–35" }, { 38, "36–40" } }) do
                local key = KeyFor(g[1])
                local r = key and Dq:ReferenceCheck(key)
                if r then
                    any = true
                    local fresh = r.oldest <= 1800
                    lines[#lines + 1] = string.format("%s: Wert %s · lohnt bis %s · Quelle %s (%d Min.) · eigene Rechnung %+.0f %%", g[2], A:FormatMoney(r.ref),
                        A:FormatMoney(r.limit), fresh and "frisch" or "alt", math.floor(r.oldest / 60), r.dev * 100)
                    if math.abs(r.dev) > 0.05 and r.worst then
                        bad[#bad + 1] = string.format("%s: %+.0f %% (Material %d, Quelle %s, Alter %s Min.)", g[2], r.dev * 100, r.worst.id, tostring(r.worst.src),
                            r.worst.age and math.floor(r.worst.age / 60) or "?")
                    end
                end
            end
            TR.stLines = lines
            if not any then return "SKIP", "keine Scan-Preise der Materialien (erst scannen)" end
            return #bad == 0, #bad == 0 and table.concat(lines, " | ") or table.concat(bad, " | "), "Abweichung ≤ 5 % je Gruppe"
        end)
        -- CH1–CH5 (Befehlsliste: Klick wählt aus, Enter führt aus) - nur Logik, Eingabefeld nachgebaut (zählt Schreibzugriffe)
        local function WithCH(fn)
            local H = A.CmdHint
            local saved = { sel = H.selected, box = H.editBox, last = H.lastBox, items = H.items, frame = H.frame, ic = H.instantClose, click = H.clickAt }
            local box = { writes = 0, focus = 0, shown = true }
            function box:SetText() self.writes = self.writes + 1 end
            function box:Insert() self.writes = self.writes + 1 end
            function box:SetFocus() self.focus = self.focus + 1 end
            function box:IsShown() return self.shown end
            local fr = { shown = true }
            function fr:Hide() self.shown = false end
            function fr:IsShown() return self.shown end
            function fr:IsMouseOver() return false end
            H.frame, H.editBox, H.lastBox, H.instantClose, H.selected, H.clickAt = fr, box, box, true, nil, nil
            H.items = { { cmd = "/ahs entzaubern", run = "entzaubern" }, { cmd = "/ahs entzaubern liste", run = "entzaubern liste" } }
            local savedDraw = H.Draw
            H.Draw = function() end
            local res = { pcall(fn, H, box, fr) }
            H.Draw = savedDraw
            H.selected, H.editBox, H.lastBox, H.items, H.frame, H.instantClose, H.clickAt = saved.sel, saved.box, saved.last, saved.items, saved.frame, saved.ic, saved.click
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        Chk("T537", "I", "T-CH1 Klick auf einen Eintrag wählt aus (nicht ausführen), Liste bleibt offen, Fokus zurück ins Chatfeld", function()
            return WithCH(function(H, box, fr)
                H:Select(H.items[1], true)
                local s = H:Selection()
                return s and s.item.run == "entzaubern" and fr.shown and box.focus == 1, string.format("Auswahl %s · Liste offen %s · Fokus %d", tostring(s and s.item.run), tostring(fr.shown), box.focus), "entzaubern · true · 1"
            end)
        end)
        Chk("T538", "I", "T-CH2 Enter mit \"/ahs ent\" + Auswahl \"entzaubern\" -> entzaubern wird ausgeführt", function()
            return WithCH(function(H)
                H:Select(H.items[1], true)
                local r = H:Resolve("ent")
                return r == "entzaubern", "ausgeführt " .. tostring(r), "entzaubern"
            end)
        end)
        Chk("T539", "I", "T-CH3 Auswahl älter als 10 s oder anderer Anfang -> getippter Text gilt (nichts Falsches)", function()
            return WithCH(function(H)
                H:Select(H.items[1], true)
                H.selected.t = H.selected.t - 11
                local a = H:Resolve("ent")
                H:Select(H.items[1], true)
                local b = H:Resolve("scan")
                return a == "ent" and b == "scan", string.format("alt -> %s · anderer Anfang -> %s", a, b), "ent · scan"
            end)
        end)
        Chk("T540", "I", "T-CH4 Chatfeld nie beschrieben (SetText/Insert-Zähler 0); Tab wählt den nächsten Eintrag", function()
            return WithCH(function(H, box)
                H:SelectNext(1)
                local first = H:Selection().item.run
                H:SelectNext(1)
                local second = H:Selection().item.run
                H:Resolve("ent")
                return box.writes == 0 and first == "entzaubern" and second == "entzaubern liste", string.format("Schreibzugriffe %d · Tab %s -> %s", box.writes, first, second), "0 · entzaubern -> entzaubern liste"
            end)
        end)
        Chk("T541", "I", "T-CH5 Fokusverlust ohne Klick in der Liste -> Liste zu; direkt nach einem Klick in der Liste -> bleibt", function()
            return WithCH(function(H, box, fr)
                H:Select(H.items[1], true)                   -- Klick gerade eben
                H:OnFocusLost(box)
                local afterClick = fr.shown
                H.clickAt = nil
                H.editBox = box
                H:OnFocusLost(box)
                return afterClick == true and fr.shown == false, string.format("nach Klick offen %s · ohne Klick offen %s", tostring(afterClick), tostring(fr.shown)), "true · false"
            end)
        end)
        -- AB4d und WS1–WS6 (Warnschutz)
        for i, c in ipairs({ { 110, 1110 }, { 130, 1300 }, { 148, 1480 } }) do
            Chk(string.format("T%d", 541 + i), "M", string.format("T-AB4d Markt %d %% des Marktwerts mit voller Leiter und gelerntem Maximum darunter -> knapp unter dem günstigsten (nie der Normalpreis)", c[1]), function()
                local lage = { mv = 1000, cur = c[2], ladder = Ladder({ { c[2], 100 }, { c[2] + 20, 100 }, { c[2] + 40, 100 } }), lowestOther = c[2] }
                return WithLage(lage, function(Se)
                    local savedL = A.Learn and A.Learn.Limits
                    if A.Learn then A.Learn.Limits = function(self, id) if id == TUX then return 800, 1000, 1050 end return savedL(self, id) end end
                    local ok0, v, why = pcall(Se.SuggestRaw, Se, TUX)
                    if A.Learn then A.Learn.Limits = savedL end
                    if not ok0 then error(v, 0) end
                    local ok = v and v < c[2] and v >= c[2] * 0.9
                    return ok and true or false, string.format("Vorschlag %s (%s)", tostring(v), tostring(why)), string.format("knapp unter %d", c[2])
                end)
            end)
        end
        Chk("T545", "M", "T-AB4d-b ein einzelnes Angebot zu 300 % und gelerntes Maximum -> Normalpreis (gelernt)", function()
            return WithLage({ mv = 1000, cur = 3000, ladder = Ladder({ { 3000, 1 } }), lowestOther = 3000 }, function(Se)
                local savedL = A.Learn and A.Learn.Limits
                if A.Learn then A.Learn.Limits = function(self, id) if id == TUX then return 800, 1000, 1250 end return savedL(self, id) end end
                local ok0, v, why = pcall(Se.SuggestRaw, Se, TUX)
                if A.Learn then A.Learn.Limits = savedL end
                if not ok0 then error(v, 0) end
                return v == 1000, string.format("Vorschlag %s (%s)", tostring(v), tostring(why)), "1000 (Normalpreis)"
            end)
        end)
        local function WithGuard(on, fn)
            local saved = A.db.settings.warnGuard
            if on then A.db.settings.warnGuard = nil else A.db.settings.warnGuard = false end
            local res = { pcall(fn) }
            A.db.settings.warnGuard = saved
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        Chk("T546", "M", "T-WS1 Fall 07:53: 10 Stück zu 12s25 bei günstigstem 20s48 (volle Leiter) -> Warnung, Verschenkt ~82s; nichts eingestellt", function()
            return WithGuard(true, function()
                return WithLage({ mv = 1395, cur = 2048, ladder = Ladder({ { 2048, 40 }, { 2100, 20 }, { 2150, 10 } }), lowestOther = 2048 }, function(Se)
                    local w = Se:SellWarning(TUX, 1225, 10)
                    local ok = w and w.ref == 2048 and w.lost == 8230 and w.pct == 40
                    return ok and true or false, w and w.text or "keine Warnung", "Warnung, 40 %, ~82s"
                end)
            end)
        end)
        Chk("T547", "M", "T-WS2 Fall 06:43: 12s14 bei 28s99 -> Warnung", function()
            return WithGuard(true, function()
                return WithLage({ mv = 1380, cur = 2899, ladder = Ladder({ { 2899, 78 }, { 2999, 10 }, { 3052, 5 } }), lowestOther = 2899 }, function(Se)
                    local w = Se:SellWarning(TUX, 1214, 9)
                    return w ~= nil, w and w.text or "keine Warnung", "Warnung"
                end)
            end)
        end)
        Chk("T548", "M", "T-WS3/T-WS4 knapp unter dem günstigsten (−1c) -> keine Warnung; dünne Leiter mit Ausreisser (Marktwert-Vorschlag) -> keine Warnung", function()
            return WithGuard(true, function()
                local a = WithLage({ mv = 1000, cur = 990, ladder = Ladder({ { 990, 50 }, { 1000, 40 }, { 1010, 30 } }), lowestOther = 990 }, function(Se) return Se:SellWarning(TUX, 989, 5) end)
                local b = WithLage({ mv = 1000, cur = 5000, ladder = Ladder({ { 5000, 1 } }), lowestOther = 5000 }, function(Se) return Se:SellWarning(TUX, 1000, 1) end)
                return a == nil and b == nil, string.format("−1c: %s · Ausreisser: %s", a and a.text or "keine", b and b.text or "keine"), "keine · keine"
            end)
        end)
        Chk("T549", "M", "T-WS5/T-WS6 Kauf über dem Max-Preis des Ziels -> Warnung; Warnschutz aus -> keine Warnung", function()
            local a = WithGuard(true, function() return A.Seller:BuyWarning(TUX, 1200, 1000) end)
            local b = WithGuard(false, function() return A.Seller:BuyWarning(TUX, 1200, 1000) end)
            local c = WithGuard(false, function() return WithLage({ mv = 1000, cur = 2048, ladder = Ladder({ { 2048, 40 }, { 2100, 20 }, { 2150, 10 } }), lowestOther = 2048 }, function(Se) return Se:SellWarning(TUX, 1225, 10) end) end)
            return a ~= nil and b == nil and c == nil, string.format("über Max: %s · aus: %s / %s", a and a.text or "keine", b and "Warnung" or "keine", c and "Warnung" or "keine"), "Warnung · keine / keine"
        end)
        -- MA1/MA2/MA3, Ü1–Ü3 (anweisung-markt-reiter Teil F Stufe 1); eigener Speicher A.Core.testDB
        local function WithCore(fn)
            local MKx = A.Core
            local saved = { db = MKx.testDB, now = MKx.now, noted = MKx.notedAt, prev = MKx.ownPrev, guess = MKx.guess, gh = A.GetHistory, tw = MKx.truthWait }
            MKx.testDB, MKx.notedAt, MKx.ownPrev, MKx.guess, MKx.truthWait = MKx.NewDB(), {}, {}, {}, {}
            local res = { pcall(fn, MKx) }
            MKx.testDB, MKx.now, MKx.notedAt, MKx.ownPrev, MKx.guess, A.GetHistory, MKx.truthWait = saved.db, saved.now, saved.noted, saved.prev, saved.guess, saved.gh, saved.tw
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        Chk("T550", "M", "T-MA2 Empfehlung gespeichert, nach 24 Std. mit dem Scan geprüft (Treffer, Fehler); je Item und Weg höchstens 1-mal je 6 Std.", function()
            return WithCore(function(MK)
                local t0 = time() - 30 * 3600
                MK.now = t0
                local a = MK:Note("flip", 990020501, 800, 1000)
                local b = MK:Note("flip", 990020501, 800, 1000)       -- doppelt -> nein
                MK:Note("flip", 990020502, 800, 1000)
                A.GetHistory = function(self, id)
                    if id == 990020501 then return { { t = t0 + 24 * 3600, p = 950, q = 10 } } end
                    if id == 990020502 then return { { t = t0 + 24 * 3600, p = 700, q = 10 } } end
                    return {}
                end
                local n = MK:Resolve(time())
                local nq, q, e = MK:Quote("flip")
                local ok = a and not b and n == 2 and nq == 2 and q == 0.5 and e and math.abs(e - 0.175) < 0.01
                return ok and true or false, string.format("notiert %s/%s · geprüft %d · Quote %s · Fehler %s", tostring(a), tostring(b), n, tostring(q), tostring(e)), "true/false · 2 · 0.5 · 0.175"
            end)
        end)
        Chk("T551", "M", "T-MA2b Freigabe: 19 Fälle -> lernt noch; 20 Fälle 59 % -> gesperrt (Protokoll); 61 % -> frei", function()
            return WithCore(function(MK)
                local db = MK:Store()
                db.res.de = string.rep("1", 11) .. string.rep("0", 8)
                local s1 = MK:WayState("de")
                db.res.de = string.rep("1", 59) .. string.rep("0", 41)
                db.res.de = db.res.de:sub(-50)
                local q59 = select(2, MK:Quote("de"))
                db.res.de = string.rep("1", 12) .. string.rep("0", 8)       -- 20 Fälle, 60 %
                local s60 = MK:WayState("de")
                db.res.de = string.rep("1", 11) .. string.rep("0", 9)       -- 20 Fälle, 55 %
                local s55 = MK:WayState("de")
                db.res.de = string.rep("1", 31) .. string.rep("0", 19)      -- 50 Fälle, 62 %
                local s62 = MK:WayState("de")
                local ok = s1 == "lernt" and s55 == "gesperrt" and s60 == "frei" and s62 == "frei"
                return ok, string.format("19: %s · 55 %%: %s · 60 %%: %s · 62 %%: %s", s1, s55, s60, s62), "lernt · gesperrt · frei · frei"
            end)
        end)
        Chk("T552", "M", "T-MA1 eigene Auktionen: verschwunden mit langer Restzeit = 'verkauft'; gleiche Menge neu da = 'neu eingestellt'; Fehlerquote gegen die Wahrheit", function()
            return WithCore(function(MK)
                MK:OnOwned({ { auctionID = 1, itemID = 990020601, qty = 5, timeLeft = 4 }, { auctionID = 2, itemID = 990020602, qty = 3, timeLeft = 4 },
                    { auctionID = 3, itemID = 990020603, qty = 2, timeLeft = 4 } })
                -- 1 verkauft, 2 abgebrochen und mit gleicher Menge neu eingestellt, 3 abgebrochen (nicht neu) -> Erkennung irrt
                MK:OnOwned({ { auctionID = 9, itemID = 990020602, qty = 3, timeLeft = 4 } })
                local g1, g2, g3 = MK.guess[1] and MK.guess[1].g, MK.guess[2] and MK.guess[2].g, MK.guess[3] and MK.guess[3].g
                MK:Truth(1, "verkauft"); MK:Truth(2, "abgebrochen"); MK:Truth(3, "abgebrochen")
                local n, rate = MK:MA1Rate()
                local ok = g1 == "verkauft" and g2 == "neu" and g3 == "verkauft" and n == 3 and math.abs(rate - 1 / 3) < 0.01
                return ok, string.format("Erkennung %s/%s/%s · geprüft %d · Fehlerquote %.0f %%", tostring(g1), tostring(g2), tostring(g3), n, (rate or 0) * 100), "verkauft/neu/verkauft · 3 · 33 %"
            end)
        end)
        Chk("T553", "M", "T-MA3 Händlerpreis-Tabelle gegen das Spiel gezählt; Händler-Weg nur mit bestätigtem Preis (T530)", function()
            local c0, d0 = A.vendorCheckedCount or 0, A.vendorDiffCount or 0
            local ID = 990020701
            local saved = { vp = A.db.vendorPrices, ov = A.apiOverride, chk = A.vendorChecked[ID], add = A.Diag.Add }
            A.db.vendorPrices, A.vendorChecked[ID] = { [ID] = 500 }, nil
            A.Diag.Add = function() end
            local o = {}
            for k, v in pairs(saved.ov or {}) do o[k] = v end
            o.GetItemInfo = function(id) if id == ID then return "Test", nil, 1, 1, 1, "x", "y", 1, "", 1, 125 end return nil end
            A.apiOverride = o
            local res = { pcall(A.GetVendorPrice, A, ID) }
            A.db.vendorPrices, A.apiOverride, A.vendorChecked[ID], A.Diag.Add = saved.vp, saved.ov, saved.chk, saved.add
            if not res[1] then error(res[2], 0) end
            local ok = res[2] == 125 and (A.vendorCheckedCount or 0) == c0 + 1 and (A.vendorDiffCount or 0) == d0 + 1
            A.vendorCheckedCount, A.vendorDiffCount = c0, d0
            return ok, string.format("Preis %s · bestätigt +%d · abweichend +%d", tostring(res[2]), (A.vendorCheckedCount or 0) - c0 + 1, 1), "125 · +1 · +1"
        end)
        Chk("T554", "M", "T-Ü3 Plausibilität: Gewinn > 300 % -> Daten prüfen; Absatz > 25 % des Angebots je Stunde -> unplausibel; Produkt < 5 Angebote -> dünn", function()
            local MK = A.Core
            local a = MK:Implausible(350)
            local b = MK:Implausible(50, 30, 100)
            local c = MK:Implausible(50, nil, nil, 3)
            local d = MK:Implausible(80, 10, 100, 20)
            return a ~= nil and b ~= nil and c ~= nil and d == nil, string.format("%s · %s · %s · %s", tostring(a), tostring(b), tostring(c), tostring(d)), "drei Gründe · nil"
        end)
        Chk("T558", "M", "T-Ü3b Markt-Zeilen: Gewinn > 300 % -> Spalte Stand \"unplausibel: …\" und nicht als Empfehlung gemerkt; normale Zeile unverändert", function()
            return WithCore(function(MK)
                local rows = { { itemID = TUX, price = 100, sell = 500, state = "ok" }, { itemID = TUX, price = 100, sell = 150, state = "ok" } }
                local n = MK:MarkRows("flip", rows)
                local noted = MK:NoteRows("flip", rows)
                local ok = n == 1 and rows[1].implausible ~= nil and tostring(rows[1].state):find(L["unplausibel"], 1, true) == 1 and rows[2].state == "ok" and noted == 1
                return ok, string.format("markiert %d · Stand \"%s\" · zweite \"%s\" · gemerkt %d", n, tostring(rows[1].state), tostring(rows[2].state), noted), "1 · unplausibel: … · ok · 1"
            end)
        end)
        Chk("T555", "M", "T-Ü1/T-Ü2 Testbericht-Abschnitt MARKT-KERN: je Weg Fälle/Quote/Fehler/Zustand, gesperrter Weg als 'Ü2 VERFEHLT'", function()
            return WithCore(function(MK)
                local db = MK:Store()
                db.res.flip = string.rep("1", 10) .. string.rep("0", 15)
                local lines = table.concat(MK:Report(), "\n")
                local ok = lines:find("MARKT-KERN", 1, true) and lines:find("Weg flip: Fälle 25", 1, true) and lines:find("Ü2 VERFEHLT: Weg flip", 1, true) and lines:find("MA1", 1, true) and lines:find("MA3", 1, true)
                return ok and true or false, (lines:gsub("\n", " | ")):sub(1, 300), "Abschnitt mit Weg flip gesperrt"
            end)
        end)
        -- RK2-A: EIN "Lohnt bis" je Item (Tooltip, Einkauf, Markt "Entzaubern", Sammelkauf, Markt-Kaufgrenze, Sniper, API)
        local function WithDE(nets, fn)
            local Dq = A.Disenchant
            local saved = { dv = Dq.DealValue, sm = Dq.StaleMain, bn = Dq.BatchNet, mu = A.Tooltip and A.Tooltip.MatsUnsure }
            Dq.DealValue = function(self, id) local e = nets[id]; if e then return e[1], e[1], true, "estimate", e[2] end return saved.dv(self, id) end
            Dq.StaleMain = function(self, id) if nets[id] then return false, nil, 0 end return saved.sm(self, id) end
            Dq.BatchNet = function(self, id, n) if nets[id] then return nil end return saved.bn(self, id, n) end
            if A.Tooltip then A.Tooltip.MatsUnsure = function(self, id) if nets[id] then return false end return saved.mu(self, id) end end
            local res = { pcall(fn, Dq) }
            Dq.DealValue, Dq.StaleMain, Dq.BatchNet = saved.dv, saved.sm, saved.bn
            if A.Tooltip then A.Tooltip.MatsUnsure = saved.mu end
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        Chk("T556", "M", "T-RK2a 20 Items (fester Startwert): Tooltip, Einkauf, Markt \"Entzaubern\", Sammelkauf, Markt-Kaufgrenze, Sniper-Ziel und API liefern denselben Kupferbetrag (Lernen an und aus)", function()
            local nets, ids = {}, {}
            local seed = 12345
            for i = 1, 20 do
                seed = (seed * 1103515245 + 12345) % 2147483648
                local id = 990020600 + i
                nets[id] = { 200 + seed % 200000, (seed % 3 == 0) and 15 or 3 }
                ids[#ids + 1] = id
            end
            local MK, Ln = A.Core, A.Learn
            local bad, n, sample = {}, 0, ""
            for _, learn in ipairs({ true, false }) do
                if Ln then Ln.forceOff = (not learn) or nil end
                local okR, err = pcall(WithDE, nets, function(Dq)
                    for _, id in ipairs(ids) do
                        local src = MK:LimitSources(id)
                        n = n + 1
                        local m = MK:LimitMismatch(id)
                        local cnt = 0
                        for _ in pairs(src) do cnt = cnt + 1 end
                        if m or cnt < 7 then bad[#bad + 1] = id .. (m and (" " .. m) or (" nur " .. cnt .. " Stellen")) end
                        -- Sniper-Ziel aus Entzaubern folgt genau diesem Betrag
                        local t = { de = true, kind = "item", itemID = id, maxPrice = math.max(1, math.floor((src.kern or 1) * 2)) }
                        local savedP = A.Print
                        A.Print = function() end
                        local okS = pcall(A.Sniper.UpdateDETargets, A.Sniper, { t })
                        A.Print = savedP
                        if not (okS and t.maxPrice == src.kern) then bad[#bad + 1] = id .. " Sniper " .. tostring(t.maxPrice) .. "≠" .. tostring(src.kern) end
                        if sample == "" then sample = string.format("Netto %d -> Lohnt bis %s", nets[id][1], tostring(src.kern)) end
                    end
                end)
                if not okR then bad[#bad + 1] = tostring(err) end
            end
            if Ln then Ln.forceOff = nil end
            return #bad == 0, string.format("%d Prüfungen (je 7 Stellen), %d abweichend%s · %s", n, #bad, bad[1] and (" – " .. bad[1]) or "", sample),
                "40 Prüfungen, 0 abweichend"
        end)
        Chk("T557", "M", "T-RK2b Rechnung: Lohnt bis = Netto × min(1/(1+Mindestrendite), 1 − Sicherheitsmarge); Sammelkauf zieht die Rendite nicht doppelt ab; Selbsttest meldet zwei Werte", function()
            local MK, Ln = A.Core, A.Learn
            local ID = 990020650
            if Ln then Ln.forceOff = true end
            local r = { pcall(WithDE, { [ID] = { 1200, 3 } }, function(Dq)
                local few = MK:WorthUpTo(ID, 1)                     -- < 10 Entzauberungen: 10 % Marge, 20 % Rendite -> 1000
                local tri = MK:WorthUpTo(ID, 3)
                local _, _, ok = A.DEBuy:Judge(ID, 900, 1)          -- unter Lohnt bis, Gewinn 100c: kaufen (früher 11 % Rendite -> nein)
                local TT = A.Tooltip
                local orig = TT.DisenchantVerdict
                TT.DisenchantVerdict = function(self, id) local x = orig(self, id); if x and id == ID then x.limit = x.limit + 7 end return x end
                local mm = MK:LimitMismatch(ID)
                TT.DisenchantVerdict = orig
                return few, tri, ok, mm
            end) }
            if Ln then Ln.forceOff = nil end
            if not r[1] then error(r[2], 0) end
            local few, tri, ok, mm = r[2], r[3], r[4], r[5]
            local good = few == 1000 and tri == 3000 and ok == true and type(mm) == "string" and mm:find("tooltip", 1, true) ~= nil
            return good, string.format("Lohnt bis %s · 3 Stück %s · Sammelkauf bei 900 %s · Selbsttest \"%s\"", tostring(few), tostring(tri), tostring(ok), tostring(mm)),
                "1000 · 3000 · true · tooltip abweichend"
        end)
        -- SB: Sniper-Budget aufgebraucht -> Abfrage, "Ja" füllt um den ursprünglichen Betrag auf (nie echter Kauf: Buy ist ersetzt)
        local function WithSB(fn)
            local Sn = A.Sniper
            local KEY, ID = "i:990020701", 990020701
            local t = { kind = "item", itemID = ID, maxPrice = 100, qty = 50, budget = 1000, bought = 10, spent = 1000 }
            local saved = { gt = Sn.GetTarget, buy = Sn.Buy, sr = Sn.ShowRefill, open = A.IsAHOpen, mon = Sn.Money, r = Sn.result, hp = Sn.hasPlan,
                q = Sn.hitQueue, pend = Sn.pending, lp = Sn.lastPress, ask = Sn.refillAsk, no = Sn.refillNo, fire = A.Fire, pr = A.Print }
            local log = { asks = 0, buys = 0 }
            Sn.GetTarget = function(self, key) if key == KEY then return t end return saved.gt(self, key) end
            Sn.Buy = function(self, plan) log.buys = log.buys + 1; log.plan = plan; return true, "Test-Kauf" end
            Sn.ShowRefill = function(self, tt, text) log.asks = log.asks + 1; log.text = text end
            A.IsAHOpen = function() return true end
            Sn.Money = function() return log.money or 1000000 end
            A.Fire, A.Print = function() end, function(_, m) log.print = m end
            Sn.pending, Sn.hitQueue, Sn.refillAsk, Sn.refillNo = nil, {}, nil, nil
            local function Hit()
                Sn.result = { key = KEY, itemID = ID, commodity = true, time = GetTime(), listings = { { price = 90, qty = 5, pass = true } } }
                Sn.hasPlan = Sn:PlanNext() ~= nil
            end
            local function Press() Sn.lastPress = 0; return Sn:OnTrigger(nil) end
            local res = { pcall(fn, Sn, t, log, Hit, Press) }
            Sn.GetTarget, Sn.Buy, Sn.ShowRefill, A.IsAHOpen, Sn.Money = saved.gt, saved.buy, saved.sr, saved.open, saved.mon
            Sn.result, Sn.hasPlan, Sn.hitQueue, Sn.pending, Sn.lastPress, Sn.refillAsk, Sn.refillNo, A.Fire, A.Print =
                saved.r, saved.hp, saved.q, saved.pend, saved.lp, saved.ask, saved.no, saved.fire, saved.pr
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        Chk("T559", "M", "T-SB1 Budget aufgebraucht + Treffer + Mausrad -> Abfrage \"Budget auffüllen?\", kein Kauf", function()
            return WithSB(function(Sn, t, log, Hit, Press)
                Hit()
                local waiting = Sn:HitWaiting()
                local ok1, msg = Press()
                local ok = waiting == true and log.asks == 1 and log.buys == 0 and not ok1 and tostring(msg):find(A:FormatMoney(1000), 1, true) ~= nil
                return ok, string.format("wartet %s · Abfragen %d · Käufe %d · \"%s\"", tostring(waiting), log.asks, log.buys, tostring(msg)), "true · 1 · 0 · Text mit Budget"
            end)
        end)
        Chk("T560", "M", "T-SB2 \"Ja\" -> Budget + ursprünglicher Betrag (1000 -> 2000), nächster Dreh kauft (kein Kauf aus der Abfrage)", function()
            return WithSB(function(Sn, t, log, Hit, Press)
                Hit(); Press()
                local okA = Sn:RefillAnswer(true)
                local afterAsk = log.buys
                Press()
                local ok = okA and t.budget == 2000 and afterAsk == 0 and log.buys == 1 and log.plan and log.plan.qty == 5
                return ok, string.format("Budget %s · Käufe nach Ja %d · nach Dreh %d (Menge %s)", tostring(t.budget), afterAsk, log.buys, tostring(log.plan and log.plan.qty)), "2000 · 0 · 1 (5)"
            end)
        end)
        Chk("T561", "M", "T-SB3 \"Nein\" -> nichts ändert sich, keine neue Abfrage für denselben Treffer", function()
            return WithSB(function(Sn, t, log, Hit, Press)
                Hit(); Press()
                Sn:RefillAnswer(false)
                Press()
                local ok = t.budget == 1000 and log.asks == 1 and log.buys == 0
                return ok, string.format("Budget %s · Abfragen %d · Käufe %d", tostring(t.budget), log.asks, log.buys), "1000 · 1 · 0"
            end)
        end)
        Chk("T562", "M", "T-SB4 Gold reicht nur teilweise (400) -> nur 400 aufgefüllt + Hinweis \"nur … aufgefüllt – Gold\"", function()
            return WithSB(function(Sn, t, log, Hit, Press)
                log.money = 400
                Hit(); Press()
                Sn:RefillAnswer(true)
                local ok = t.budget == 1400 and log.print and log.print:find(A:FormatMoney(400), 1, true) ~= nil
                return ok, string.format("Budget %s · Hinweis \"%s\"", tostring(t.budget), tostring(log.print)), "1400 · nur 4s aufgefüllt – Gold"
            end)
        end)
        Chk("T563", "M", "T-SB5 aufgefülltes Budget wieder aufgebraucht -> erneute Abfrage (nie automatisch weiter)", function()
            return WithSB(function(Sn, t, log, Hit, Press)
                Hit(); Press(); Sn:RefillAnswer(true)
                t.spent = 2000                                        -- wieder aufgebraucht
                Hit(); Press()
                local ok = log.asks == 2 and t.budget == 2000 and log.buys == 0
                return ok, string.format("Abfragen %d · Budget %s · Käufe %d", log.asks, tostring(t.budget), log.buys), "2 · 2000 · 0"
            end)
        end)
        Chk("T564", "M", "T-SB6 Max-Preis und Menge bleiben beim Auffüllen unverändert; Abfrage-Text nennt das ursprüngliche Budget", function()
            return WithSB(function(Sn, t, log, Hit, Press)
                Hit(); Press(); Sn:RefillAnswer(true)
                t.spent = 2000
                Hit(); Press()
                local ok = t.maxPrice == 100 and t.qty == 50 and t.budget0 == 1000 and tostring(log.text):find(A:FormatMoney(1000), 1, true) ~= nil
                return ok, string.format("Max %s · Menge %s · ursprünglich %s · Text \"%s\"", tostring(t.maxPrice), tostring(t.qty), tostring(t.budget0), tostring(log.text)), "100 · 50 · 1000 · Text mit 10s"
            end)
        end)
        -- BL-A: eine Befehlstabelle für Liste und Handler
        Chk("T565", "I", "T-BL1 jedes Wort, das der Handler versteht, steht in A.COMMANDS (Tabelle verglichen): jedes Wort führt zu seinem Eintrag mit run; unbekanntes Wort -> \"Unbekannter Befehl\"", function()
            local n, bad = 0, {}
            for _, c in ipairs(A.COMMANDS) do
                if type(c.run) ~= "function" then bad[#bad + 1] = "ohne run: " .. tostring(c[1]) end
                if not L[c[3]] then bad[#bad + 1] = "ohne Text: " .. tostring(c[1]) end
                for _, w in ipairs(A:CommandWords(c)) do
                    n = n + 1
                    local hit = A:FindCommand(w)
                    if hit ~= c then bad[#bad + 1] = "'" .. w .. "' -> " .. tostring(hit and hit[1]) end
                end
            end
            -- Handler: unbekanntes Wort meldet sich, ein Tabellen-Wort ruft genau dessen run (Seam auf unsere Tabelle)
            local saved = { pr = A.Print, pc = A.PrintCommands }
            local got, called
            A.Print = function(_, m) got = m end
            A.PrintCommands = function() end
            local probe = { "zzbl1probe", "zzbl1probe", "Diese Liste", run = function(rest) called = rest end, arg = true }
            table.insert(A.COMMANDS, probe)
            local okH, err = pcall(function()
                SlashCmdList["AHANALYZERPRO"]("gibtsnicht123")
                SlashCmdList["AHANALYZERPRO"]("zzbl1probe xy")
            end)
            for i = #A.COMMANDS, 1, -1 do if A.COMMANDS[i] == probe then table.remove(A.COMMANDS, i) end end
            A.Print, A.PrintCommands = saved.pr, saved.pc
            if not okH then bad[#bad + 1] = tostring(err) end
            local unk = got and got:find("gibtsnicht123", 1, true) ~= nil
            local ok = #bad == 0 and unk and called == "xy"
            return ok, string.format("%d Wörter, %d Fehler%s · unbekannt gemeldet %s · neuer Tabellen-Eintrag erreicht %s", n, #bad, bad[1] and (" – " .. bad[1]) or "", tostring(unk), tostring(called)),
                "alle Wörter -> eigener Eintrag · unbekannt gemeldet · xy"
        end)
        Chk("T566", "I", "T-BL5 Entwickler-Befehle (dev) nur mit A:IsDev(): nicht in Chat-Liste und Befehlsliste, Handler ruft run nicht", function()
            local saved = { dev = A.IsDev, req = A.RequireDev, pr = A.Print, prt = _G.print }
            local lines, ran = {}, false
            A.IsDev = function() return false end
            A.RequireDev = function() return false end
            A.Print = function() end
            local probe = { "zzbl5probe", "zzbl5probe", "Diese Liste", dev = true, run = function() ran = true end }
            table.insert(A.COMMANDS, probe)
            local res = { pcall(function()
                local H = A.CmdHint
                local list = H and H.List and H:List("") or {}
                local inHint = false
                for _, it in ipairs(list) do if tostring(it.cmd):find("zzbl5probe", 1, true) or tostring(it.cmd):find("testroutine", 1, true) then inHint = true end end
                SlashCmdList["AHANALYZERPRO"]("zzbl5probe")
                SlashCmdList["AHANALYZERPRO"]("testroutine")
                return inHint
            end) }
            for i = #A.COMMANDS, 1, -1 do if A.COMMANDS[i] == probe then table.remove(A.COMMANDS, i) end end
            A.IsDev, A.RequireDev, A.Print = saved.dev, saved.req, saved.pr
            if not res[1] then error(res[2], 0) end
            local devN = 0
            for _, c in ipairs(A.COMMANDS) do if c.dev then devN = devN + 1 end end
            local ok = res[2] == false and ran == false and devN >= 4
            return ok, string.format("in der Befehlsliste %s · ausgeführt %s · Entwickler-Einträge %d", tostring(res[2]), tostring(ran), devN), "false · false · >= 4"
        end)
        Chk("T567", "I", "T-BL6 alle Sprachen: jede Befehls-Beschreibung übersetzt, gleiche Zahl Platzhalter wie der Schlüssel", function()
            local miss = {}
            local function pc(x) local n = 0; for _ in tostring(x):gmatch("%%[%a%%]") do n = n + 1 end return n end
            local langs = 0
            for lang in pairs(A.UI_LANGUAGE_NAMES) do
                if lang ~= "deDE" then
                    langs = langs + 1
                    local T = A.T[lang] or {}
                    for _, c in ipairs(A.COMMANDS) do
                        local v = T[c[3]]
                        if not v then miss[#miss + 1] = lang .. ": " .. c[3]
                        elseif pc(v) ~= pc(c[3]) then miss[#miss + 1] = lang .. " Platzhalter: " .. c[3] end
                    end
                end
            end
            return #miss == 0 and langs >= 10, string.format("%d Sprachen, %d Befehle, %d Lücken%s", langs, #A.COMMANDS, #miss, miss[1] and (" – " .. miss[1]) or ""), "10 Sprachen, 0 Lücken"
        end)
        -- API-PM2 / API-PM3
        Chk("T568", "M", "T-API-PM2 WorthUpTo: 1. Wert Summe für qty, 3. Wert \"sicher\"/\"unsicher\" (unverändert), 4. Wert Sicherheit 0–1 (nil = lernt), 5. Wert Stückpreis", function()
            local API = _G.AHSentinel and _G.AHSentinel.API
            local ID = 990020801
            local Ln = A.Learn
            if Ln then Ln.forceOff = true end
            local r = { pcall(WithDE, { [ID] = { 1200, 3 } }, function()
                return WithCore(function(MK)
                    local a = { API.WorthUpTo(ID, 3) }
                    MK:Store().res.de = string.rep("1", 18) .. string.rep("0", 2)        -- 20 Fälle, 90 %
                    local b = { API.WorthUpTo(ID, 1) }
                    return a, b
                end)
            end) }
            if Ln then Ln.forceOff = nil end
            if not r[1] then error(r[2], 0) end
            local a, b = r[2], r[3]
            local ok = a[1] == 3000 and a[2] == "disenchant" and (a[3] == "sicher" or a[3] == "unsicher") and a[4] == nil and a[5] == 1000
                and b[1] == 1000 and b[4] == 0.9 and b[5] == 1000
            return ok, string.format("3 Stück: %s/%s/%s/%s/%s · gelernt: %s/%s/%s", tostring(a[1]), tostring(a[2]), tostring(a[3]), tostring(a[4]), tostring(a[5]),
                tostring(b[1]), tostring(b[4]), tostring(b[5])), "3000/disenchant/sicher/nil/1000 · 1000/0.9/1000"
        end)
        Chk("T569", "M", "T-API-PM3 MaterialCost: 20 Zutaten, je 2 Leiterstufen -> Kosten über die Leiter für die benötigte Menge (nicht günstigstes × Menge)", function()
            local API = _G.AHSentinel and _G.AHSentinel.API
            local Cr = A.Crafting
            local PROD = 990020900
            local reag, ladders, want = {}, {}, 0
            for i = 1, 20 do
                local id = PROD + i
                reag[#reag + 1] = { id, 3 }                                 -- 2 Herstellungen × 3 = 6 Stück je Zutat
                ladders[id] = { { 100 + i, 4 }, { 200 + i, 10 } }           -- 4 billig, Rest teurer
                want = want + 4 * (100 + i) + 2 * (200 + i)
            end
            local saved = { ri = Cr.RecipeIndex, bu = Cr.BestUnit, ol = A.OfferLadder }
            Cr.RecipeIndex = function(self, ...) return { [PROD] = { made = 1, reagents = reag } } end
            Cr.BestUnit = function(self, id, ...) if ladders[id] then return ladders[id][1][1], "ah" end return saved.bu(self, id, ...) end
            A.OfferLadder = function(self, id) if ladders[id] then return ladders[id], "search" end return saved.ol(self, id) end
            local res = { pcall(function() return API.MaterialCost(PROD, 2) end) }
            Cr.RecipeIndex, Cr.BestUnit, A.OfferLadder = saved.ri, saved.bu, saved.ol
            if not res[1] then error(res[2], 0) end
            local total, list = res[2], res[3]
            local cheapest = 0
            for i = 1, 20 do cheapest = cheapest + 6 * (100 + i) end
            local ok = total == want and type(list) == "table" and #list == 20 and list[1].qty == 6
            return ok, string.format("Kosten %s (Leiter %d, günstigstes × Menge wäre %d) · %d Zutaten", tostring(total), want, cheapest, type(list) == "table" and #list or 0),
                string.format("%d · 20 Zutaten", want)
        end)
        Chk("T570", "M", "TU5 echte Daten (nur lesen): Vorschlag unter günstigstem − Unterbietung -> Verletzung mit Zahlen; korrekter Vorschlag -> keine; nichts geändert", function()
            return WithCore(function(MK)
                local Se = A.Seller
                local ID = 990021001
                local saved = { pr = Se.prices[ID], sr = Se.SuggestRaw, fr = Se.IsPriceFresh }
                Se.prices[ID] = { lowestOther = 1000, stamp = time() }
                Se.IsPriceFresh = function(self, id) if id == ID then return true end return saved.fr(self, id) end
                local sugg = 500
                Se.SuggestRaw = function(self, id) if id == ID then return sugg, "Test" end return saved.sr(self, id) end
                local r = { pcall(function()
                    local bad1, bad2 = {}, {}
                    MK:RealCheckItem(ID, bad1)
                    sugg = Se:Undercut(1000, ID)
                    MK:RealCheckItem(ID, bad2)
                    return bad1, bad2, Se.prices[ID].lowestOther
                end) }
                Se.prices[ID], Se.SuggestRaw, Se.IsPriceFresh = saved.pr, saved.sr, saved.fr
                if not r[1] then error(r[2], 0) end
                local ok = #r[2] == 1 and r[2][1]:find("500", 1, true) ~= nil and #r[3] == 0 and r[4] == 1000
                return ok, string.format("zu billig: %s · richtig: %d Verletzungen · Daten unverändert %s", tostring(r[2][1]), #r[3], tostring(r[4] == 1000)), "1 Verletzung mit 500 · 0 · true"
            end)
        end)
        Chk("T571", "M", "TU7 Freigaben (Teil D) mit erfundenen Trefferquoten: 59 % -> gesperrt, 61 % -> frei, 19 Fälle -> lernt noch", function()
            return WithCore(function(MK)
                local db = MK:Store()
                local function quote(hits, n) return string.rep("1", hits) .. string.rep("0", n - hits) end
                db.res.flip = quote(59, 100)
                db.res.vendor = quote(61, 100)
                db.res.de = quote(19, 19)
                local a, b, c = MK:WayState("flip"), MK:WayState("vendor"), MK:WayState("de")
                return a == "gesperrt" and b == "frei" and c == "lernt", string.format("59 %% %s · 61 %% %s · 19 Fälle %s", a, b, c), "gesperrt · frei · lernt"
            end)
        end)
        -- BP-2026-11-13-1: Auktions-Post mit beliebigem Absender wird über die Rechnung erkannt und gleich verbucht
        Chk("T572", "J", "T-BP-1113-1 Post mit Absender \"Stormwind Auction House\", mit anderem und ohne Absender, jeweils mit Rechnung -> alle Auktions-Post, gleich verbucht", function()
            local Le, M = A.Ledger, A.Mailer
            local db = A.db.ledger
            local I = A.Inbox
            local saved = { entries = db.entries, seen = db.seen, force = A.forceForever, pr = A.Print, fire = A.Fire,
                av = I.Available, n = I.GetInboxNumItems, h = I.GetInboxHeaderInfo, inv = I.GetInboxInvoiceInfo, raw = Le.rawLogged }
            local out = {}
            local res = { pcall(function()
                A.Print, A.Fire = function() end, function() end
                I.Available = function() return true end
                I.GetInboxNumItems = function() return 1 end
                I.GetInboxInvoiceInfo = function() return "seller", "AHS-Testitem", nil, 4042, 47, 38, 202, nil, nil, 0 end
                Le.rawLogged, A.forceForever = true, true
                for _, sender in ipairs({ "Stormwind Auction House", "Testa-Beispiel", false }) do
                    I.GetInboxHeaderInfo = function() return nil, nil, sender or nil, "Verkauft", 3878, 0, 29 end
                    db.entries, db.seen = {}, {}
                    local isAH = M and M.IsAuctionMail and M:IsAuctionMail(1)
                    Le:ScanInbox()
                    local e = db.entries[1] or {}
                    out[#out + 1] = string.format("%s:%s/%s/%s", tostring(isAH), tostring(e.kind), tostring(e.amount), tostring(e.qty))
                end
            end) }
            db.entries, db.seen, A.forceForever, A.Print, A.Fire = saved.entries, saved.seen, saved.force, saved.pr, saved.fire
            I.Available, I.GetInboxNumItems, I.GetInboxHeaderInfo, I.GetInboxInvoiceInfo, Le.rawLogged = saved.av, saved.n, saved.h, saved.inv, saved.raw
            if not res[1] then error(res[2], 0) end
            local ok = #out == 3 and out[1] == out[2] and out[2] == out[3] and out[1]:find("^true:sale/") ~= nil
            return ok, table.concat(out, " · "), "dreimal gleich: true:sale/…"
        end)
        -- MA1-B: Wahrheit vor der Vermutung; "neu" nur aus neuen auctionIDs
        Chk("T573", "M", "T-MA1b Abbruch-Ereignis und Verkaufs-Meldung kommen VOR der neuen Liste -> beide Fälle gezählt und richtig", function()
            return WithCore(function(MK)
                MK:OnOwned({ { auctionID = 11, itemID = 990020611, qty = 5, timeLeft = 4 }, { auctionID = 12, itemID = 990020612, qty = 3, timeLeft = 4 } })
                MK:Truth(11, "verkauft")                                      -- Chat-Meldung zuerst
                MK:Truth(12, "abgebrochen")                                   -- Abbruch feuert sofort
                local before = (MK:MA1Rate())
                MK:OnOwned({ { auctionID = 19, itemID = 990020612, qty = 3, timeLeft = 4 } })  -- neue Liste: 12 neu eingestellt
                local n, rate = MK:MA1Rate()
                local ok = before == 0 and n == 2 and rate == 0
                return ok, string.format("vor der Liste %d · danach %d Fälle · Fehlerquote %s", before, n, tostring(rate)), "0 · 2 · 0"
            end)
        end)
        Chk("T574", "M", "T-MA1c 5 gleiche Stapel, einer verkauft (kein neuer) -> \"verkauft\"; einer abgebrochen und mit neuer auctionID neu eingestellt -> \"neu\"", function()
            return WithCore(function(MK)
                local L5 = {}
                for i = 1, 5 do L5[i] = { auctionID = 20 + i, itemID = 990020620, qty = 20, timeLeft = 4 } end
                MK:OnOwned(L5)
                MK:OnOwned({ L5[2], L5[3], L5[4], L5[5] })                    -- 21 verschwunden, nichts neu
                local g1 = MK.guess[21] and MK.guess[21].g
                MK:OnOwned({ L5[3], L5[4], L5[5], { auctionID = 31, itemID = 990020620, qty = 20, timeLeft = 4 } })   -- 22 weg, 31 neu
                local g2 = MK.guess[22] and MK.guess[22].g
                return g1 == "verkauft" and g2 == "neu", string.format("%s · %s", tostring(g1), tostring(g2)), "verkauft · neu"
            end)
        end)
        Chk("T575", "M", "T-MA2c Wahrheit je Weg: Entzaubern = Materialwert danach (Teil billiger egal), Material −30 % -> kein Treffer, Fehler 30 %; Händler = bestätigter Händlerpreis, AH-Preis egal", function()
            return WithCore(function(MK)
                local Dq = A.Disenchant
                local DE1, DE2, VE = 990020631, 990020632, 990020633
                local saved = { dv = Dq.DealValue, vp = A.GetVendorPrice, chk = A.vendorChecked[VE] }
                local nets = { [DE1] = 1000, [DE2] = 700 }
                Dq.DealValue = function(self, id) if nets[id] then return nets[id], nets[id], true, "estimate", 3 end return saved.dv(self, id) end
                A.GetVendorPrice = function(self, id) if id == VE then return 500 end return saved.vp(self, id) end
                A.vendorChecked[VE] = true
                -- AH-Preise der Teile fallen stark (für de/vendor ohne Bedeutung)
                A.GetHistory = function(self, id) return { { t = time() - 3 * 3600, p = 1 } } end
                local r = { pcall(function()
                    local t0 = time() - 30 * 3600
                    MK.now = t0
                    MK:Note("de", DE1, 800, 1000); MK:Note("de", DE2, 800, 1000); MK:Note("vendor", VE, 300, 500)
                    MK.now = nil
                    local n = MK:Resolve(time())
                    local db = MK:Data()
                    return n, db.res.de, db.err.de and db.err.de[2], db.res.vendor
                end) }
                Dq.DealValue, A.GetVendorPrice, A.vendorChecked[VE] = saved.dv, saved.vp, saved.chk
                if not r[1] then error(r[2], 0) end
                local ok = r[2] == 3 and r[3] == "10" and r[4] == 300 and r[5] == "1"
                return ok, string.format("geprüft %s · de %s · Fehler 2. Fall %s ‰ · Händler %s", tostring(r[2]), tostring(r[3]), tostring(r[4]), tostring(r[5])), "3 · 10 · 300 ‰ · 1"
            end)
        end)
        Chk("T579", "M", "T-RK2c 20 Items, Lernen an/aus, deMinGain 20 und 35: Markt-Zeile, Detail, Tooltip, Einkauf, Sammelkauf, Sniper-Ziel, API gleich; Sniper-Ziel 3 % darüber wird angepasst", function()
            local nets, ids = {}, {}
            local seed = 777
            for i = 1, 20 do
                seed = (seed * 1103515245 + 12345) % 2147483648
                local id = 990020660 + i
                nets[id] = { 300 + seed % 150000, (seed % 2 == 0) and 15 or 4 }
                ids[#ids + 1] = id
            end
            local MK, Ln = A.Core, A.Learn
            local savedMin = A.db.settings.deMinGain
            local bad, n, need = {}, 0, { "kern", "tooltip", "einkauf", "markt", "sammelkauf", "marktgrenze", "marktzeile", "detail", "sniper", "api" }
            local adj
            for _, learn in ipairs({ true, false }) do
                for _, mg in ipairs({ 20, 35 }) do
                    if Ln then Ln.forceOff = (not learn) or nil end
                    A.db.settings.deMinGain = mg
                    local okR, err = pcall(WithDE, nets, function()
                        for _, id in ipairs(ids) do
                            n = n + 1
                            local src = MK:LimitSources(id)
                            for _, k in ipairs(need) do
                                if src[k] ~= src.kern then bad[#bad + 1] = string.format("%d %s=%s kern=%s", id, k, tostring(src[k]), tostring(src.kern)) end
                            end
                        end
                        local t = { de = true, kind = "item", itemID = ids[1], maxPrice = 0 }
                        local k = MK:LimitSources(ids[1]).kern
                        t.maxPrice = math.floor(k * 1.03)
                        local savedP = A.Print
                        A.Print = function() end
                        pcall(A.Sniper.UpdateDETargets, A.Sniper, { t })
                        A.Print = savedP
                        adj = (t.maxPrice == k)
                    end)
                    if not okR then bad[#bad + 1] = tostring(err) end
                end
            end
            if Ln then Ln.forceOff = nil end
            A.db.settings.deMinGain = savedMin
            return #bad == 0 and adj == true, string.format("%d Prüfungen je 10 Stellen, %d abweichend%s · Sniper +3 %% angepasst %s", n, #bad, bad[1] and (" – " .. bad[1]) or "", tostring(adj)),
                "80 Prüfungen, 0 abweichend · true"
        end)
        -- FG: Freigaben (Teil D) in den Markt-Zeilen
        local function FGRows() return { { itemID = TUX, price = 100, sell = 150, safety = "hoch" }, { itemID = TUW, price = 200, sell = 260, safety = "hoch" } } end
        local function Q(h, n) return string.rep("1", h) .. string.rep("0", n - h) end
        Chk("T576", "M", "T-FG1 Weg Flippen 59 % aus 20 -> keine Flip-Zeile, Kopf \"Weg … gesperrt (Treffer 59 %)\"", function()
            return WithCore(function(MK)
                MK:Store().res.flip = Q(59, 100)
                local rows, head = MK:ApplyRelease("flip", FGRows())
                local ok = #rows == 0 and type(head) == "string" and head:find("59", 1, true) ~= nil
                return ok, string.format("%d Zeilen · \"%s\"", #rows, tostring(head)), "0 · gesperrt (Treffer 59 %)"
            end)
        end)
        Chk("T577", "M", "T-FG2 Weg Entzaubern 19 Fälle -> Zeilen grau \"lernt noch (19 von 20)\", keine Kauf-Empfehlung", function()
            return WithCore(function(MK)
                MK:Store().res.de = Q(19, 19)
                local rows, head = MK:ApplyRelease("de", FGRows())
                local r = rows[1] or {}
                local ok = #rows == 2 and r.learning == true and r.recommend == false and r.safety == "niedrig"
                    and tostring(r.coreNote):find("19", 1, true) ~= nil and tostring(r.coreNote):find("20", 1, true) ~= nil and head ~= nil
                return ok, string.format("%d Zeilen · \"%s\" · Empfehlung %s", #rows, tostring(r.coreNote), tostring(r.recommend)), "2 · lernt noch (19 von 20) · false"
            end)
        end)
        Chk("T578", "M", "T-FG3 Absatz: MA1 29 Fälle -> Flip-Zeilen grau \"lernt noch (29 von 30)\"; 30 Fälle, 15 % falsch -> frei", function()
            return WithCore(function(MK)
                local db = MK:Store()
                db.res.flip = Q(20, 20)
                db.ma1 = { n = 29, wrong = 4 }
                local r1 = MK:ApplyRelease("flip", FGRows())
                db.ma1 = { n = 30, wrong = 4 }                                  -- 13 %
                local r2, h2 = MK:ApplyRelease("flip", FGRows())
                local a, b = r1[1] and r1[1].coreNote, r2[1] and r2[1].coreNote
                local ok = tostring(a):find("29", 1, true) ~= nil and b == nil and h2 == nil and r2[1].safety == "hoch"
                return ok, string.format("29 Fälle \"%s\" · 30 Fälle %s", tostring(a), tostring(b)), "lernt noch (29 von 30) · nil (frei)"
            end)
        end)
        -- TU6 Regressionen: je Befund ein bleibender Test (Liste im Testbericht)
        TR.REGRESSIONS = { "AB1", "AB2", "AB4", "AB4b", "AB4c", "AB5", "AB7", "AB8", "L1b", "L1c", "MP1", "MP2", "MP3",
            "PD1", "PD2", "PD5", "PD7", "SM1", "SM2", "MV1", "JK", "LB", "VF5", "AB4d", "WS1", "CH1", "HP1", "ST1", "RK2", "SB", "BL", "MA1", "FG" }
        -- LG6–LG8 (Befund Buchhaltungskopf 10.11. 16:00)
        -- T-LG6 abgelöst durch BP5 (Buchhaltung neu): Kopf zeigt EIN Ergebnis "Gewinn", Rest im Tooltip (nachrechenbar)
        Chk("T389", "M", "T-LG6/BP5 Kopf: nur \"Gewinn\" (realisiert), Tooltip: Erlös − eingesetzt − Gebühren = Gewinn, Kasse, Lager, Abstimmung", function()
            local tab = A.UI and A.UI:GetTab("ledger")
            if tab and not tab.panel then A.UI:SelectTab("ledger") end
            local p = tab and tab.panel
            if not (p and p.cards and p.cards.profit and p.ProfitTooltip) then return false, "Reiter Buchhaltung fehlt", "Gewinn" end
            return WithBooks(function()
                BKx:OnBuy(B_SD, 10, 10000)
                BKx:OnInvoice(B_SD, 4, 6000, 300)
                local per = p.period
                p.period = "all"
                local res = { pcall(function()
                    p:Refresh()
                    local tips = {}
                    for _, l in ipairs(p:ProfitTooltip()) do tips[#tips + 1] = l[1] end
                    return p.cards.profit.value:GetText(), table.concat(tips, " | "), p.cards.income == nil and p.cards.stock == nil
                end) }
                p.period = per
                pcall(p.Refresh, p)
                if not res[1] then error(res[2], 0) end
                local val, tip, onlyOne = res[2] or "", res[3] or "", res[4]
                local want = 5700 - 4000
                local ok = onlyOne and val:find(A:FormatMoney(want), 1, true) ~= nil and tip:find(A:FormatMoney(5700), 1, true) ~= nil
                    and tip:find(A:FormatMoney(4000), 1, true) ~= nil
                return ok, string.format("Kopf \"%s\" · nur Gewinn %s · Tooltip \"%s\"", A:PlainText(val), tostring(onlyOne), A:PlainText(tip):sub(1, 160)),
                    "Gewinn 17s · Erlös 57s − eingesetzt 40s"
            end)
        end)
        Chk("T390", "M", "T-LG7 200 Grober Faden gekauft und verbraucht -> \"für Berufe verbraucht\", nicht im Handelsergebnis", function()
            local FADEN = 990006002
            local saved = { ent = A.db.ledger.entries, ir = Le.IsReagent, sc = Le.StockCounts }
            A.db.ledger.entries = { { kind = "buy", t = time() - 60, itemID = FADEN, qty = 200, amount = 2000, src = "buy" } }
            Le.IsReagent = function(_, id) return id == FADEN end
            Le.StockCounts = function() return {} end
            local res = { pcall(function() return Le:CraftUse("today"), Le:Summary("today") end) }
            A.db.ledger.entries, Le.IsReagent, Le.StockCounts = saved.ent, saved.ir, saved.sc
            if not res[1] then error(res[2], 0) end
            local use, sum = res[2], res[3]
            local trade = sum.profit + use
            local ok = use == 2000 and trade == 0
            return ok, string.format("Berufe verbraucht %s · Handel %s", A:FormatMoney(use), A:FormatMoney(math.abs(trade))), "Berufe 20s · Handel 0"
        end)
        Chk("T391", "M", "T-LG8 aktive Auktion 10 Seelenstaub (nur im Journal, AH zu) -> im AH 10", function()
            local Fc, Se = A.Forecast, A.Seller
            local DUST2 = 990006003
            local saved = { owned = Se and Se.owned, ends = A.db.ownedEnds, otime = Se and Se.ownedTime }
            if Se then Se.owned, Se.ownedTime = {}, nil end          -- X2: "nie abgefragt" (AH zu)
            A.db.ownedEnds = {}
            Fc.testStore, Fc.evalCache = {}, nil
            Fc:Store()
            Fc.testStore.f.list[1] = Fc:Encode("P", { t = time() - 600, id = DUST2, q = 10, a = 1, pr = 700, d = 24 })
            local res = { pcall(function() local _, ah, v = Le:StockParts(); return ah[DUST2], v end) }
            if Se then Se.owned, Se.ownedTime = saved.owned, saved.otime end
            A.db.ownedEnds = saved.ends
            Fc.testStore, Fc.evalCache = nil, nil
            if not res[1] then error(res[2], 0) end
            return res[2] == 10, string.format("im AH %s Stück · Wert %s", tostring(res[2]), A:FormatMoney(res[3] or 0)), "10 Stück"
        end)
        -- W5: Zählkontrolle vergleicht nur Einträge seit Beginn der Zählung
        Chk("T363", "M", "T-W5 Zählkontrolle nur ab Beginn der Zählung (kein falscher Alarm)", function()
            return TR.DESandbox(function()
                local db, now = A.db, time()
                local today = A:DayStart(now)
                local start = math.max(today + 1, now - 600)
                db.deLog = {}
                for i = 1, 5 do db.deLog[#db.deLog + 1] = { t = math.max(today, start - 100 - i), itemID = 1, loot = { { 10940, 1 } } } end
                for i = 1, 3 do db.deLog[#db.deLog + 1] = { t = start + i, itemID = 1, loot = { { 10940, 1 } } } end
                db.deCount = { day = today, counted = 3, missed = 0, since = start }
                local lines, okA = TR:DEReport()
                local la = ""
                for _, l in ipairs(lines) do if l:find("Zählkontrolle", 1, true) then la = l end end
                db.deCount = { day = today, counted = 2, missed = 0, since = start }
                local _, okB = TR:DEReport()
                return okA and not okB, la .. " · gezählt 2 statt 3 -> " .. (okB and "OK (falsch)" or "FEHLER (richtig)"),
                    "3 = 3 OK (5 ältere nicht verglichen) · 2 statt 3 FEHLER"
            end, true)
        end)
    end) end

    -- ---------------- K. Oberfläche im echten Client (UICheck.lua, Vorlage T18–T23) ----------------
    -- ohne echten Client ehrlich übersprungen, nie als OK gezählt; nur lesen
    if want(part, "k") then B(function()
        local U = A.UIC and A.UIC.UICheck
        if not U then return Skp("T191", "K", "Oberfläche im Client", "UICheck.lua nicht geladen") end
        local UI = A.UI
        local wasShown = UI and UI.frame and UI.frame:IsShown()
        if UI and UI.frame and not wasShown then UI.frame:Show() end         -- eigenes Fenster zum Prüfen öffnen
        local function List(problems) return #problems == 0 and "keine" or table.concat(problems, "; ") end
        local ui = {
            { "T191", "Eigene Tooltips verdecken keine Knöpfe", U.TooltipsCoverNothing },
            { "T192", "Kein Überlappen mit Blizzard- oder GoldSentinel-Fenstern", U.WindowsOverlapNothing },
            { "T193", "Fenster ganz im Bildschirm", U.InsideScreen },
            { "T194", "Beschriftungen von Knöpfen nicht abgeschnitten", U.TextFits },
            { "T195", "Angezeigte Spielwerte plausibel", U.ValuesPlausible, true },
            { "T196", "Keine Fehlerschleife (gleiche Meldung > 10×)", U.NoErrorLoops, true },
        }
        for _, c in ipairs(ui) do
            if not c[4] and not U.Available() then
                Skp(c[1], "K", c[2], "nur im echten Client (Fenster, Rechtecke, Tooltip)")
            else
                Chk(c[1], "K", c[2], function()
                    local problems, tested, hints = c[3]()
                    local info = List(problems) .. " · geprüft " .. tostring(tested)
                        .. (hints and #hints > 0 and (" · Hinweise: " .. table.concat(hints, "; ")) or "")
                    return #problems == 0, info, "keine"
                end)
            end
        end
        -- T-SN3 (Anweisung 10.11.): Sniper-Zielzeile "50/100 gekauft · Budget 5g aufgebraucht" nicht abgeschnitten
        if not U.Available() then
            Skp("T359", "K", "T-SN3 Sniper-Zielzeile nicht abgeschnitten", "nur im echten Client")
        else
            Chk("T359", "K", "T-SN3 Sniper-Zielzeile nicht abgeschnitten", function()
                local tab = UI:GetTab("sniper")
                if tab and not tab.panel then UI:SelectTab("sniper") end
                local p = tab and tab.panel
                local row = p and p.targets and p.targets.rows and p.targets.rows[1]
                local fs = row and row.cells and row.cells[3]
                if not (fs and fs.IsTruncated) then return false, "Zelle nicht gefunden", "nicht abgeschnitten" end
                local old = fs:GetText()
                local sample = A.Sniper:ProgressText({ qty = 100, budget = 50000, maxPrice = 1000, bought = 50, spent = 50000 })
                fs:SetText(sample)
                local cut = fs:IsTruncated()
                fs:SetText(old)
                local sample2 = A.Sniper:ProgressText({ qty = 1000, budget = 1234567, maxPrice = 1000, bought = 999, spent = 10000 })
                fs:SetText(sample2)
                local cut2 = fs:IsTruncated()
                fs:SetText(old)
                return not cut and not cut2, string.format("\"%s\" %s · \"%s\" %s", sample, cut and "abgeschnitten" or "ganz", sample2, cut2 and "abgeschnitten" or "ganz"), "ganz lesbar"
            end)
        end
        if UI and UI.frame and not wasShown then UI.frame:Hide() end
        if not (A.Crafting and A.Crafting.panel and A.Crafting.panel:IsShown()) then
            Cli("T197", "K", "Gewinn-Fenster am Berufsfenster",
                "Berufsfenster öffnen (mit und ohne ProfessionSentinel), dann /ahs testroutine k: T192 ohne \"überdeckt\", T195 ohne Fehler")
        end
    end) end

    if part == "server" then
        if not A:IsAHOpen() then
            B(function() Skp("S00", "B", "Teil server", "Auktionshaus nicht offen - erst öffnen, dann /ahs testroutine server") end)
        else
            B(function() A.jobMeasure = { max = 0, frames = 0 } end)
            self:AddOldSteps(false)
            self:AddServerSteps()
        end
    elseif part == "haendler" then
        B(function()
            if not MerchantOpen() then return Skp("T59b", "B", "Händler-Verkauf simuliert", "Händlerfenster nicht offen") end
            Chk("T59b", "B", "Händler-Verkauf simuliert", function()
                local X = A.Extras
                local before = Real("UseContainerItem")
                local ok, msg = Capture(function() return X:SellToVendor() end)
                for _ = 1, 3 do Capture(function() X:SellStep() end) end
                X.selling = nil
                return Real("UseContainerItem") == before, "UseContainerItem " .. (Real("UseContainerItem") - before), "0"
            end)
            if A:Global("GetMerchantItemInfo") and not A:Global("C_MerchantFrame") then
                Chk("T100", "D", "Alter Händler-Weg", function()
                    local n = A:ScanMerchant()
                    return (n or 0) > 0, tostring(n), "> 0 über GetMerchantItemInfo"
                end)
            else
                Skp("T100", "D", "Alter Händler-Weg", "nur im alten Client (Classic Era, TBC)")
            end
        end)
        B(function()
            if not MerchantOpen() then return Skp("T19", "B", "Händler echt", "Händlerfenster nicht offen") end
            Chk("T19", "B", "Händler echt", function()
                local n = A:ScanMerchant()
                return n > 0, tostring(n), "> 0"
            end)
            Chk("T135", "J", "Händler-Einkaufspreise", function()
                return Count(A.db.vendorBuy) > 0, tostring(Count(A.db.vendorBuy)), "> 0"
            end)
        end)
    elseif part == "berufe" then
        B(function()
            local Cr = A.Crafting
            if not Cr.kind then return Skp("T64", "B", "Berufsfenster echt", "Berufsfenster nicht offen") end
            Chk("T64", "B", "Berufsfenster echt", function()
                local n = Cr:Remember(Cr.kind)
                return (n or 0) > 0, tostring(Cr.kind) .. ", " .. tostring(n) .. " Rezepte", "> 0"
            end)
            if modern then
                Chk("T134", "J", "Berufsfenster in Forever nicht leer", function()
                    return Cr:TradeKind() == "modern", Cr:TradeKind(), "modern"
                end)
            end
        end)
        B(function()
            local Cr = A.Crafting
            if not Cr.kind then return Skp("T124", "H", "Berufsliste (Zwischenspeicher)", "Berufsfenster nicht offen") end
            if Cr.kind == "trade" or Cr.kind == "craft" then
                Chk("T99", "D", "Alte Berufe-API", function()
                    local n = Cr:Remember(Cr.kind)
                    return (n or 0) > 0, Cr.kind .. ", " .. tostring(n), "trade/craft, > 0"
                end)
            else
                Skp("T99", "D", "Alte Berufe-API", "nur im alten Client (Classic Era, TBC)")
            end
            Chk("T124", "H", "Berufsliste (Zwischenspeicher)", function()
                local t0 = Ms(); Cr:ReadAll(Cr.kind); local a = Ms() - t0
                t0 = Ms(); Cr:ReadAll(Cr.kind); local b = Ms() - t0
                return Cr.kind ~= "modern" or b < 2, string.format("erstes Mal %.1f ms, zweites Mal %.1f ms", a, b),
                    Cr.kind == "modern" and "zweites Mal < 2 ms" or "nur Messwert"
            end)
            if Cr.kind == "modern" then
                Chk("T147", "J", "KO 5b: Zutaten-Knopf ohne SchematicForm", function()
                    return Cr.API.modern.selected() ~= nil, tostring(Cr.API.modern.selected()),
                        "Rezept im Blizzard-Fenster gewählt -> Index (vorher ein Rezept anklicken)"
                end)
                Chk("T148", "J", "KO 5c: Zwischenspeicher bleibt bei Listen-Ereignissen", function()
                    Cr:ReadAll("modern")
                    local n1 = Cr:SchematicCacheSize()
                    Cr.evt:GetScript("OnEvent")(Cr.evt, "TRADE_SKILL_LIST_UPDATE")
                    Cr.evt:GetScript("OnEvent")(Cr.evt, "TRADE_SKILL_LIST_UPDATE")
                    local n2 = Cr:SchematicCacheSize()
                    return n1 > 0 and n2 >= n1, string.format("%d -> %d Einträge", n1, n2), "nicht geleert"
                end)
            end
        end)
    elseif part == "post" then
        B(function()
            if not (MailFrame and MailFrame:IsShown()) then return Skp("T56", "B", "Post abholen", "Briefkasten nicht offen") end
            TM:SeedMail()
            Chk("T56", "B", "Post abholen (Test-Briefkasten)", function()
                return A.Mailer:HasAHMail() == true, nil, "Test-Post erkannt"
            end)
            Chk("T58", "B", "Post an Twinks simuliert", function()
                local ok = pcall(A.Extras.MailPlan, A.Extras)
                return ok and (self.real.SendMail or 0) == 0, nil, "Plan ohne Fehler, SendMail 0"
            end)
        end)
    elseif part == "gildenbank" then
        B(function()
            local K = A.Comfort
            if not (K.GuildBankSupported and K:GuildBankSupported()) then return Skp("T67", "B", "Gildenbank", "nicht unterstützt") end
            Chk("T67", "B", "Gildenbank", function()
                local ok = K:ScanGuildBank()
                return ok, nil, "gelesen"
            end)
        end)
    elseif part == "kampf" then
        B(function()
            local s = A.db.gsTest and A.db.gsTest.errors
            local n = 0
            for _ in pairs(s or {}) do n = n + 1 end
            Chk("T158", "C", "Fehler aus dem letzten Kampf", function()
                return n == 0, n .. " Fehlerarten seit dem letzten Bericht", "0"
            end)
        end)
    end
end
