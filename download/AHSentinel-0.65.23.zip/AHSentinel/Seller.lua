if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.9 - Verkaufen und eigene Auktionen (Logik)
--
-- * Taschen lesen: alle Items, die man im Auktionshaus verkaufen kann
-- * Preis prüfen: aktuelle Angebote eines Items (eine Suche pro Item,
--   nacheinander, nie während Markt-Scan oder Sniper-Suche)
-- * Preisvorschlag: günstigstes fremdes Angebot unterbieten, sonst
--   Marktwert (Median), sonst zuletzt benutzter Preis
-- * Einstellen mit Einstellgebühr, AH-Gebühr und Warnung, wenn ein
--   Händler mehr zahlt
-- * Eigene Auktionen: Status (günstigstes / unterboten / verkauft),
--   Abbrechen - immer nur per Klick (das verlangt WoW selbst)
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
-- Retail 12.x: die alten Item-/Zauber-Funktionen gibt es nur noch in C_Item / C_Spell
local GetItemInfo = GetItemInfo or (C_Item and C_Item.GetItemInfo)
local A = AHAnalyzerPro
local L = A.L

local Se = {}
A.Seller = Se

local AH_CUT = 0.05            -- Anteil, den das Auktionshaus vom Verkaufspreis einbehält
local SEARCH_TIMEOUT = 8       -- Sekunden, bis eine Preisprüfung als ergebnislos gilt
local PRICE_FRESH = 300        -- so lange (Sek.) gilt eine Preisprüfung als aktuell
local SORTS = { { sortOrder = 0, reverseSort = false } }

Se.prices = {}                 -- [itemID] = { time, stamp, listings = { {price, qty, own} }, lowestOther, lowestOwn }
Se.queue = {}                  -- Item-IDs, deren Preis noch geprüft werden soll
Se.search = nil                -- laufende Preisprüfung
Se.lastSearch = -100
Se.owned = {}                  -- eigene Auktionen
Se.ownedTime = nil
Se.pendingPost = nil
Se.pendingCancel = nil

-- Unterbieten: um 1 Kupfer, 1 % oder 5 %
Se.UNDERCUT = {
    { key = "copper", label = "1 Kupfer" },
    { key = "p1", label = "1 %" },
    { key = "p5", label = "5 %" },
}

local function DB()
    return A.db and A.db.seller
end

local function SafeCall(fn, ...)
    if not fn then return nil end
    local ok, a, b = pcall(fn, ...)
    if ok then return a, b end
    if A.ReportOnce then A:ReportOnce(fn, "SafeCall:Verkaufen", a) end
    return nil
end

local function Now() return GetTime() end

-- ------------------------------------------------------------
-- Dauer der Auktion (1 = kurz, 2 = mittel, 3 = lang).
-- Die Stunden hängen vom Server ab - Blizzards eigene Texte nutzen, wenn vorhanden.
-- ------------------------------------------------------------
function Se:DurationLabel(d)
    local g = ({ AUCTION_DURATION_ONE, AUCTION_DURATION_TWO, AUCTION_DURATION_THREE })[d]
    if type(g) == "string" and g ~= "" then return g end
    return L[({ "Kurz", "Mittel", "Lang" })[d] or "Mittel"]
end

function Se:UndercutLabel(key)
    for _, u in ipairs(self.UNDERCUT) do if u.key == key then return L[u.label] end end
    return L["1 Kupfer"]
end

function Se:CycleUndercut()
    local db = DB()
    local i = 1
    for k, u in ipairs(self.UNDERCUT) do if u.key == db.undercut then i = k end end
    db.undercut = self.UNDERCUT[(i % #self.UNDERCUT) + 1].key
    A:Fire("SELLER_CHANGED")
    return db.undercut
end

-- ------------------------------------------------------------
-- Taschen
-- ------------------------------------------------------------
local function ContainerInfo(bag, slot)
    local CC, GetContainerItemInfo = A:API("C_Container"), A:API("GetContainerItemInfo")   -- A:API: ohne Test = Blizzard
    if CC and CC.GetContainerItemInfo then
        local info = SafeCall(CC.GetContainerItemInfo, bag, slot)
        if type(info) == "table" then return info end
        return nil
    end
    -- ältere Clients: viele Rückgabewerte statt einer Tabelle
    if GetContainerItemInfo then
        local ok, tex, count, locked, quality, readable, lootable, link, filtered, noValue, itemID = pcall(GetContainerItemInfo, bag, slot)
        if ok and tex then
            return { stackCount = count, isLocked = locked, quality = quality, hyperlink = link, hasNoValue = noValue, itemID = itemID }
        end
    end
    return nil
end

local function NumSlots(bag)
    local CC, old = A:API("C_Container"), A:API("GetContainerNumSlots")
    if CC and CC.GetContainerNumSlots then return SafeCall(CC.GetContainerNumSlots, bag) or 0 end
    if old then return SafeCall(old, bag) or 0 end
    return 0
end

local function MakeLocation(bag, slot)
    if ItemLocation and ItemLocation.CreateFromBagAndSlot then
        return SafeCall(ItemLocation.CreateFromBagAndSlot, ItemLocation, bag, slot)
    end
    return nil
end

local bagCache = nil           -- Taschen-Inhalt bis zur nächsten Änderung

-- Waren (stapelbar, Preis pro Stück) oder Einzelangebot (z.B. Ausrüstung)
function Se:IsCommodity(itemID, loc)
    local C = A.AH
    if loc and C and C.GetItemCommodityStatus and Enum and Enum.ItemCommodityStatus then
        local st = SafeCall(C.GetItemCommodityStatus, loc)
        if st == Enum.ItemCommodityStatus.Commodity then return true end
        if st == Enum.ItemCommodityStatus.Item then return false end
    end
    local stack = select(8, GetItemInfo(itemID))
    return (stack or 1) > 1
end

-- Alle verkaufbaren Items in den Taschen, nach Item zusammengefasst
-- light = true: ohne Preise (schneller, nur zum Zählen)
function Se:GetBagItems(light)
    local byID, list = {}, {}
    local C = A.AH
    for bag = 0, (NUM_BAG_SLOTS or 4) + (NUM_REAGENTBAG_SLOTS or 0) do   -- Retail: auch die Reagenzientasche
        for slot = 1, NumSlots(bag) do
            local info = ContainerInfo(bag, slot)
            local itemID = info and (info.itemID or (info.hyperlink and tonumber(info.hyperlink:match("item:(%d+)"))))
            if itemID and not info.isBound then
                local loc = MakeLocation(bag, slot)
                local valid = true
                -- IsSellItemValid antwortet nur bei offenem Auktionshaus sinnvoll (sonst immer "nein")
                if loc and C and C.IsSellItemValid and A:IsAHOpen() then
                    local ok, v = pcall(C.IsSellItemValid, loc, false)
                    if ok and v == false then valid = false end
                end
                if valid then
                    local e = byID[itemID]
                    if not e then
                        e = { itemID = itemID, name = A:GetItemName(itemID), count = 0, slots = {}, quality = info.quality or 1 }
                        byID[itemID] = e
                        table.insert(list, e)
                    end
                    e.count = e.count + (info.stackCount or 1)
                    table.insert(e.slots, { bag = bag, slot = slot, count = info.stackCount or 1, loc = loc })
                end
            end
        end
    end
    for _, e in ipairs(list) do
        e.commodity = self:IsCommodity(e.itemID, e.slots[1].loc)
    end
    if light then return list end
    bagCache = {}
    for _, e in ipairs(list) do
        bagCache[e.itemID] = e
        e.market = A:GetMarketValue(e.itemID)
        e.vendor = A:GetVendorPrice(e.itemID)
        local pr = self:GetPriceInfo(e.itemID)
        e.lowest = pr and pr.lowestOther or nil
        e.value = (e.market or e.lowest or e.vendor or 0) * e.count
    end
    return list
end

-- Anzahl eines Items in den Taschen (zwischengespeichert bis zur nächsten Taschenänderung)
function Se:InvalidateBags() bagCache = nil end

function Se:CountInBags(itemID)
    if not bagCache then
        bagCache = {}
        for _, e in ipairs(self:GetBagItems(true)) do bagCache[e.itemID] = e end
    end
    local e = bagCache[itemID]
    if e then return e.count, e end
    return 0, nil
end

-- ------------------------------------------------------------
-- Preisprüfung (aktuelle Angebote eines Items)
-- ------------------------------------------------------------
local function MakeKey(itemID)
    local C = A.AH
    if C and C.MakeItemKey then
        local key = SafeCall(C.MakeItemKey, itemID)
        if key then return key end
    end
    return { itemID = itemID, itemLevel = 0, itemSuffix = 0, battlePetSpeciesID = 0 }
end

local function ReadListings(itemID, key)
    local C = A.AH
    local out = {}
    local nCom = SafeCall(C.GetNumCommoditySearchResults, itemID) or 0
    if nCom > 0 then
        for i = 1, nCom do
            local info = SafeCall(C.GetCommoditySearchResultInfo, itemID, i)
            if type(info) == "table" and info.unitPrice and info.unitPrice > 0 then
                local ownQty = info.numOwnerItems or (info.containsOwnerItem and info.quantity) or 0
                table.insert(out, { price = info.unitPrice, qty = info.quantity or 1, own = ownQty > 0, ownQty = ownQty })
            end
        end
        table.sort(out, function(a, b) return a.price < b.price end)
        A:MarkBait(out)          -- Lockangebote (1 Stück ganz unten) markieren
        return out, true
    end
    local nItem = SafeCall(C.GetNumItemSearchResults, key) or 0
    for i = 1, nItem do
        local info = SafeCall(C.GetItemSearchResultInfo, key, i)
        if type(info) == "table" and info.buyoutAmount and info.buyoutAmount > 0 then
            local qty = info.quantity or 1
            table.insert(out, { price = math.floor(info.buyoutAmount / math.max(1, qty)), qty = qty,
                                own = info.containsOwnerItem or false, ownQty = info.containsOwnerItem and qty or 0 })
        end
    end
    return out, false
end

local function ResultsFull(itemID, key)
    local C = A.AH
    if SafeCall(C.HasFullCommoditySearchResults, itemID) then return true end
    return SafeCall(C.HasFullItemSearchResults, key) == true
end

function Se:IsBusy()
    return self.search ~= nil
end

-- warten noch Preisprüfungen? (haben Vorrang vor Sniper und Wächter)
function Se:HasWork()
    return self.search ~= nil or #self.queue > 0
end

-- wartet ein angeklicktes Item? (dann lassen Sniper und Wächter kurz den Vortritt)
function Se:HasUrgent()
    return self.urgent ~= nil and A:IsAHOpen()
end

-- Zwischenstand der laufenden Preisprüfung (Angebote, die schon da sind)
function Se:GetPartial(itemID)
    local s = self.search
    if s and s.itemID == itemID then return s.partial end
    return nil
end

function Se:GetPriceInfo(itemID)
    return self.prices[itemID]
end

function Se:IsPriceFresh(itemID)
    local p = self.prices[itemID]
    return p ~= nil and (Now() - p.time) <= PRICE_FRESH
end

-- Preis eines Items prüfen lassen (wird nacheinander abgearbeitet)
function Se:CheckPrice(itemID, front)
    if not itemID then return false end
    if front then self.urgent = itemID end
    if self.search and self.search.itemID == itemID then return true end
    for i, id in ipairs(self.queue) do
        if id == itemID then
            -- angeklickt: nach vorne holen
            if front and i > 1 then table.remove(self.queue, i); table.insert(self.queue, 1, itemID) end
            if front then self:Preempt() end
            return true
        end
    end
    if front then table.insert(self.queue, 1, itemID) else table.insert(self.queue, itemID) end
    if front then self:Preempt() end
    A:Fire("SELLER_CHANGED")
    return true
end

-- Vorladen (Maus über einem Item): leise hinten anstellen, höchstens ein paar
function Se:Prefetch(itemID)
    if not (itemID and A:IsAHOpen()) or self:IsPriceFresh(itemID) then return end
    if self.search and self.search.itemID == itemID then return end
    for _, id in ipairs(self.queue) do if id == itemID then return end end
    if #self.queue >= 3 then return end
    table.insert(self.queue, itemID)
    A:Fire("SELLER_CHANGED")
end

-- ein angeklicktes Item soll sofort dran sein: laufende Wächter-Runde abbrechen
-- (der Wächter macht danach einfach weiter; ein wartender Sniper-Treffer bleibt unangetastet)
function Se:Preempt()
    local W = A.Watcher
    if W and W:IsBusy() and not (A.Sniper and A.Sniper.HitWaiting and A.Sniper:HitWaiting()) then
        if A.AH and A.AH.AbortBrowse then pcall(A.AH.AbortBrowse) end
        if W.Abort then W:Abort() end
    end
    if not self.search then self:StartNext() end
end

local function CanStartSearch()
    if not A:IsAHOpen() then return false end
    if A:IsScanning() then return false end
    if A.Sniper and (A.Sniper:IsBusy() or (A.Sniper.pending and not A.Sniper.pending.auto)) then return false end
    if A.Watcher and A.Watcher:IsBusy() then return false end
    if A.Buy and A.Buy:Blocks() then return false end
    if not (A.AH and A.AH.SendSearchQuery) then return false end
    return A:CanQueryNow()
end

function Se:StartNext()
    if self.search or #self.queue == 0 or not CanStartSearch() then return end
    local itemID = table.remove(self.queue, 1)
    if self.urgent == itemID then self.urgent = nil end
    local key = MakeKey(itemID)
    local ok = pcall(A.AH.SendSearchQuery, key, SORTS, true)
    self.lastSearch = Now()
    A:NoteQuery()
    if not ok then
        A:QueryError()
        A:Fire("SELLER_CHANGED")
        return
    end
    self.search = { itemID = itemID, key = key, started = Now(), lastCount = -1, lastChange = Now() }
    A:Fire("SELLER_CHANGED")
end

function Se:PollSearch()
    local s = self.search
    if not s then return end
    if not A:IsAHOpen() then self.search = nil; return end
    local okRead, listings, commodity = pcall(ReadListings, s.itemID, s.key)
    if not okRead then listings, commodity = {}, false end
    local count = #listings
    local now = Now()
    if count ~= s.lastCount then s.lastCount, s.lastChange = count, now end
    local full = ResultsFull(s.itemID, s.key)
    local timedOut = now - s.started > SEARCH_TIMEOUT
    local done = (full and (count > 0 or s.answered or now - s.started >= 1))
        or (count > 0 and now - s.lastChange >= 0.75)
        or timedOut
    if not done then
        -- schon vorhandene Angebote sofort zeigen (die Liste wächst, während der Rest lädt)
        if count > 0 and count ~= s.shown then
            s.shown = count
            table.sort(listings, function(a, b) return a.price < b.price end)
            s.partial = listings
            A:Fire("SELLER_CHANGED")
        end
        return
    end
    self.search = nil
    if timedOut and count == 0 then A:QueryError() end
    table.sort(listings, function(a, b) return a.price < b.price end)
    local info = { time = now, stamp = time(), listings = listings, commodity = commodity }
    local bait = 0
    for _, l in ipairs(listings) do
        if l.bait then
            bait = bait + 1          -- Lockangebote zählen nicht
        elseif l.own then
            if not info.lowestOwn then info.lowestOwn = l.price end
            -- eine Zeile kann eigene und fremde Angebote enthalten (Waren)
            if l.qty > (l.ownQty or 0) and not info.lowestOther then info.lowestOther = l.price end
        elseif not info.lowestOther then
            info.lowestOther = l.price
        end
    end
    info.bait = bait
    self.prices[s.itemID] = info
    -- günstigsten echten Preis (ohne Lockangebote) in den Preisverlauf - bestätigt damit auch den Scan
    local first
    for _, l in ipairs(listings) do if not l.bait then first = l; break end end
    if first then
        local total = 0
        for _, l in ipairs(listings) do if not l.bait then total = total + l.qty end end
        A:VerifyPrice(s.itemID, first.price, total)
    end
    self:UpdateOwnedStatus()
    A:Fire("SELLER_CHANGED")
    A:Fire("DATA_CHANGED")
end

-- ------------------------------------------------------------
-- Preisvorschlag
-- ------------------------------------------------------------
function Se:Undercut(price)
    local mode = DB().undercut or "copper"
    local p
    if mode == "p1" then p = math.floor(price * 0.99)
    elseif mode == "p5" then p = math.floor(price * 0.95)
    else p = price - 1 end
    if p >= price then p = price - 1 end
    return math.max(1, p)
end

-- Mindestpreis pro Item: darunter wird nie unterboten (nil = keiner)
function Se:GetFloor(itemID)
    local e = itemID and DB().items[itemID]
    return e and e.floor or nil
end

function Se:SetFloor(itemID, price)
    if not itemID then return end
    local db = DB()
    db.items[itemID] = db.items[itemID] or {}
    db.items[itemID].floor = (price and price > 0) and math.floor(price) or nil
    A:Fire("SELLER_CHANGED")
end

-- Rückgabe: Preis pro Stück (Kupfer) oder nil, Begründung
function Se:Suggest(itemID)
    local price, why = self:SuggestRaw(itemID)
    local floor = self:GetFloor(itemID)
    if floor and (not price or price < floor) then
        return floor, string.format(L["dein Mindestpreis (%s) - Konkurrenz ist billiger"], A:FormatMoney(floor)), true
    end
    return price, why
end

function Se:SuggestRaw(itemID)
    local pr = self.prices[itemID]
    if pr and self:IsPriceFresh(itemID) then
        if pr.lowestOther then
            if pr.lowestOwn and pr.lowestOwn <= pr.lowestOther then
                return pr.lowestOwn, L["dein Angebot ist schon das günstigste"]
            end
            return self:Undercut(pr.lowestOther), L["unterbietet das günstigste Angebot"]
        end
        if pr.lowestOwn then return pr.lowestOwn, L["nur deine eigenen Angebote"] end
    end
    local mv = A:GetMarketValue(itemID)
    if mv then return mv, L["Marktwert (keine aktuelle Preisprüfung)"] end
    local last = DB().items[itemID]
    if last and last.price then return last.price, L["zuletzt benutzter Preis"] end
    return nil, L["keine Preisdaten - bitte Preis eingeben"]
end

-- ------------------------------------------------------------
-- Gebühren
-- ------------------------------------------------------------
-- Einstellgebühr (Era/TBC/Retail): aus dem Spiel (CalculateItemDeposit/CalculateCommodityDeposit), kommt beim
-- Verkauf zurück. WoW Forever: es gibt KEINE Einstellgebühr (Regel vom 9. Nov.) -> 0; die einzige Gebühr ist die
-- AH-Gebühr max(5 %, 1s) pro Auktion, siehe Se:PostFee / A:SaleFee.
function Se:Deposit(itemID, duration, qty, commodity, loc, auctions)
    if A:IsForever() then return 0 end
    local C = A.AH
    local dep
    if C and commodity and C.CalculateCommodityDeposit then
        dep = SafeCall(C.CalculateCommodityDeposit, itemID, duration, qty)
    elseif C and loc and C.CalculateItemDeposit then
        dep = SafeCall(C.CalculateItemDeposit, loc, duration, qty)
    end
    if type(dep) ~= "number" then dep = nil end
    return dep
end

-- Gebühr, die BEIM EINSTELLEN bezahlt wird: Forever die AH-Gebühr (max(5 %, 1s) pro Auktion), sonst die Einstellgebühr
function Se:PostFee(itemID, unitPrice, qty, deposit, auctions)
    if A:IsForever() then return A:SaleFee(itemID, unitPrice, qty, auctions or 1) end
    return deposit
end

-- Warnung, wenn die Einstellgebühr mehr als x % vom Preis ausmacht (0 = aus, Standard 10)
Se.FEE_WARN_STEPS = { 0, 5, 10, 20, 30 }
function Se:FeeWarnPercent()
    local v = A.db and A.db.settings and A.db.settings.feeWarnPct
    if v == nil then return 10 end
    return v
end
function Se:CycleFeeWarn()
    local cur, steps = self:FeeWarnPercent(), self.FEE_WARN_STEPS
    local idx = 1
    for i, v in ipairs(steps) do if v == cur then idx = i end end
    A.db.settings.feeWarnPct = steps[idx % #steps + 1]
    return A.db.settings.feeWarnPct
end
-- liefert Anteil in Prozent, wenn er über der Schwelle liegt, sonst nil
function Se:FeeTooHigh(deposit, unitPrice, qty)
    local pct = self:FeeWarnPercent()
    if pct <= 0 or not deposit or deposit <= 0 or not unitPrice or unitPrice <= 0 then return nil end
    local share = deposit / (unitPrice * (qty or 1)) * 100
    if share > pct then return share end
    return nil
end

-- Beim Einstellen die tatsächlich abgezogene Gebühr ins Protokoll (Eintrag EINSTELLEN: Preis, Menge, Gebühr),
-- damit die Forever-Regel max(5 %, 1s) pro Auktion im Spiel bestätigt wird. Keine Namen.
-- (Die Messung je Item / Verlauf für eine Forever-Formel aus 0.65.17-0.65.20 ist gestrichen: Regel vom 9. Nov.)
function Se:RecordDeposit(p, measured)
    if not p or not p.itemID then return end
    if A.Spieltest and A.Spieltest.activeUntil then pcall(A.Spieltest.OnPostMeasured, A.Spieltest, p, measured) end
    local total = (p.unitPrice or 0) * (p.qty or 1)
    if A.Diag then
        A.Diag:Add("EINSTELLEN", string.format(
            "Item %d · Menge %d · Auktionen %d · Laufzeit %d · Preis %d/Stück, %d gesamt · Gebühr erwartet %s, abgezogen %s%s",
            p.itemID, p.qty or 1, p.auctions or 1, p.duration or 0, p.unitPrice or 0, total,
            p.deposit and tostring(p.deposit) or "-", measured and tostring(measured) or "-",
            (measured and total > 0) and string.format(" (%.2f %% vom Preis)", measured / total * 100) or ""))
    end
end

-- Erlös: brutto, AH-Gebühr, netto (ohne Einstellgebühr anderer Versionen)
-- Forever: AH-Gebühr = max(5 %, 1s) pro Auktion (beim Einstellen bezahlt); auctions bekannt -> genau
function Se:Proceeds(unitPrice, qty, itemID, auctions)
    local gross = unitPrice * qty
    local cut
    if A:IsForever() then
        cut = A:SaleFee(itemID, unitPrice, qty, auctions or (not itemID and 1) or nil)
    else
        cut = math.floor(gross * AH_CUT + 0.5)
    end
    return gross, cut, gross - cut
end

-- Vergleich mit dem Händler: zahlt der mehr als das Auktionshaus netto?
-- Die Einstellgebühr wird hier immer ganz abgezogen (WoW Forever: sie ist nie erstattet).
function Se:VendorBeats(itemID, unitPrice, qty, deposit, auctions)
    local vendor = A:GetVendorPrice(itemID)
    if not vendor or vendor <= 0 then return false, nil end
    local _, _, net = self:Proceeds(unitPrice, qty, itemID, auctions or 1)
    net = net - (deposit or 0)
    return vendor * qty >= net, vendor * qty
end

-- ------------------------------------------------------------
-- Preisschutz: Ist der Preis gefährlich niedrig? (wie "Undercut Protection")
-- Rückgabe: Liste mit Gründen (leer = alles gut)
-- ------------------------------------------------------------
Se.GUARD_STEPS = { 0, 20, 30, 40, 50 }       -- 0 = aus; sonst: Warnung, wenn mehr als x % unter Marktwert
function Se:GuardPercent()
    local s = A.db and A.db.settings
    local v = s and s.priceGuard
    if v == nil then return 40 end
    return v
end

function Se:CycleGuard()
    local cur, steps = self:GuardPercent(), self.GUARD_STEPS
    local idx = 1
    for i, v in ipairs(steps) do if v == cur then idx = i end end
    A.db.settings.priceGuard = steps[(idx % #steps) + 1]
    return A.db.settings.priceGuard
end

function Se:PriceRisks(itemID, unitPrice)
    local out = {}
    local pct = self:GuardPercent()
    if not (itemID and unitPrice) or pct <= 0 then return out end
    local mv = A:GetMarketValue(itemID)
    if mv and mv > 0 and unitPrice < mv * (1 - pct / 100) then
        table.insert(out, string.format(L["%d %% unter dem Marktwert (%s)"], math.floor((1 - unitPrice / mv) * 100 + 0.5), A:FormatMoney(math.floor(mv))))
    end
    -- Preis-Manipulation: das günstigste fremde Angebot ist ein Einzelstück weit unter der nächsten Stufe
    local pr = self.prices[itemID]
    if pr and pr.listings then
        local real = {}
        for _, l in ipairs(pr.listings) do
            if not l.own and l.price then table.insert(real, l) end
            if #real >= 2 then break end
        end
        local a, b = real[1], real[2]
        if a and b and (a.qty or 1) <= 2 and a.price < b.price * 0.6 and unitPrice <= a.price then
            table.insert(out, string.format(L["günstigstes Angebot ist auffällig billig (nur %d Stück, nächstes %s)"], a.qty or 1, A:FormatMoney(b.price)))
        end
    end
    return out
end

-- ------------------------------------------------------------
-- Einstellen (nur per Klick)
-- qty = Gesamtmenge (Waren) bzw. Anzahl Auktionen (Einzelangebote, je 1 Stück)
-- ------------------------------------------------------------
-- stackSize (nur altes Auktionshaus, Waren): Stück je Stapel; nil = möglichst große Stapel
function Se:Post(itemID, unitPrice, qty, duration, stackSize, feeConfirmed)
    local C = A.AH
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    if not itemID then return false, L["Erst links ein Item aus deinen Taschen wählen."] end
    if not unitPrice or unitPrice < 1 then return false, L["Bitte einen Preis pro Stück eingeben (Gold, Silber, Kupfer)."] end
    unitPrice = math.floor(unitPrice)
    qty = math.floor(tonumber(qty) or 1)
    if qty < 1 then return false, L["Menge muss mindestens 1 sein."] end
    if duration ~= 1 and duration ~= 2 and duration ~= 3 then duration = 2 end
    if self.pendingPost and Now() - self.pendingPost.time < 5 then
        return false, L["Warte auf die Bestätigung des letzten Angebots ..."]
    end
    local have, entry = self:CountInBags(itemID)
    if not entry then return false, L["Dieses Item ist nicht (mehr) in deinen Taschen."] end
    local commodity = entry.commodity
    local loc = entry.slots[1].loc
    if not loc then return false, L["Dein Client unterstützt das Einstellen nicht (ItemLocation fehlt)."] end

    local ok, err
    local postQty
    -- Einstellgebühr VOR dem Einstellen aus dem Spiel lesen (danach ist das Item nicht mehr in der Tasche)
    local apiDeposit
    do
        local C2 = A.AH
        local q = commodity and qty or 1
        if commodity and C2.CalculateCommodityDeposit then apiDeposit = SafeCall(C2.CalculateCommodityDeposit, itemID, duration, q)
        elseif C2.CalculateItemDeposit then apiDeposit = SafeCall(C2.CalculateItemDeposit, loc, duration, 1) end
        if type(apiDeposit) ~= "number" then apiDeposit = nil end
    end
    -- alter AH-Weg: CalculateItemDeposit ist dort die eigene Schätzung (LegacyAH.lua), solange kein Faktor gelernt ist
    local apiEstimate = (A.AH_LEGACY and A.AH and A.AH.DepositIsEstimate and A.AH.DepositIsEstimate(duration)) and true or nil
    -- Warnung: Gebühr über x % vom Preis -> zweiter Klick nötig (innerhalb von 15 s, gleicher Preis)
    -- Forever: die AH-Gebühr max(5 %, 1s) pro Auktion; sonst die Einstellgebühr
    local warnAuctions = 1
    if commodity and A.AH_LEGACY and tonumber(stackSize) and tonumber(stackSize) >= 1 then
        warnAuctions = math.max(1, math.floor(qty / math.floor(tonumber(stackSize))))
    end
    do
        local dep = self:PostFee(itemID, unitPrice, commodity and qty or 1,
            apiDeposit or self:Deposit(itemID, duration, commodity and qty or 1, commodity, loc), warnAuctions)
        local share = self:FeeTooHigh(dep, unitPrice, commodity and qty or 1)
        local key = itemID .. ":" .. unitPrice .. ":" .. duration
        if share and not feeConfirmed and not (self.feeConfirm and self.feeConfirm.key == key and Now() - self.feeConfirm.time < 15) then
            self.feeConfirm = { key = key, time = Now() }
            return false, string.format(A:IsForever() and L["Achtung: Die AH-Gebühr %s ist %d %% vom Preis. Nochmals klicken, um trotzdem einzustellen."]
                or L["Achtung: Die Einstellgebühr %s ist %d %% vom Preis. Nochmals klicken, um trotzdem einzustellen."],
                A:FormatMoney(dep), math.floor(share + 0.5)) .. (A:DepositRefunded() and L[" (wird beim Verkauf erstattet)"] or "")
        end
        self.feeConfirm = nil
    end
    if commodity then
        if qty > have then return false, string.format(L["Nur %d Stück in den Taschen."], have) end
        if not C.PostCommodity then return false, L["Dein Client unterstützt das Einstellen von Waren nicht (PostCommodity fehlt)."] end
        -- altes Auktionshaus: nur volle Stapel in einem Rutsch (Rest beim nächsten Klick)
        if A.AH_LEGACY then
            local maxStack = math.max(1, select(8, GetItemInfo(itemID)) or 1)
            stackSize = math.floor(tonumber(stackSize) or 0)
            if stackSize >= 1 then
                stackSize = math.min(stackSize, maxStack)
                if qty < stackSize then return false, string.format(L["Zu wenig für einen Stapel à %d."], stackSize) end
                qty = stackSize * math.floor(qty / stackSize)
            else
                stackSize = nil
                if qty > maxStack then qty = maxStack * math.floor(qty / maxStack) end
            end
        else
            stackSize = nil
        end
        postQty = qty
        ok, err = pcall(C.PostCommodity, loc, duration, qty, unitPrice, stackSize)
    else
        if not C.PostItem then return false, L["Dein Client unterstützt das Einstellen nicht (PostItem fehlt)."] end
        postQty = 1
        ok, err = pcall(C.PostItem, loc, duration, 1, nil, unitPrice)
    end
    if not ok then return false, L["Einstellen fehlgeschlagen: "] .. tostring(err) end

    local auctions = (stackSize and stackSize >= 1) and math.max(1, math.floor(postQty / stackSize)) or 1
    local deposit = self:PostFee(itemID, unitPrice, postQty, apiDeposit or self:Deposit(itemID, duration, postQty, commodity, nil), auctions)
    self.pendingPost = { itemID = itemID, qty = postQty, unitPrice = unitPrice, duration = duration, auctions = auctions,
                         deposit = deposit, apiDeposit = apiDeposit, apiEstimate = apiEstimate, money = GetMoney and GetMoney() or nil,
                         time = Now(), left = (not commodity) and (qty - 1) or 0 }
    local db = DB()
    local prev = db.items[itemID] or {}
    db.items[itemID] = { price = unitPrice, duration = duration, qty = commodity and qty or nil,
                         stack = stackSize or (commodity and prev.stack) or nil,
                         stacks = (stackSize and math.floor(qty / stackSize)) or (commodity and prev.stacks) or nil,
                         floor = prev.floor }
    db.duration = duration
    local msg = string.format(L["Wird eingestellt: %dx %s für %s/Stück ..."], postQty, A:GetItemName(itemID), A:FormatMoney(unitPrice))
    A:Fire("SELLER_CHANGED")
    return true, msg
end

-- ------------------------------------------------------------
-- Serien-Einstellen: alle Taschen-Items mit gemerktem Preis nacheinander,
-- ein Klick = eine Auktion. Schutz:
--   * Vorschlag unter 70 % deines letzten Preises -> überspringen
--   * Händler zahlt mehr -> überspringen
-- ------------------------------------------------------------
Se.BATCH_FLOOR = 0.7

-- only: { [itemID] = true } = nur diese Items (z.B. zurückgekommene Auktionen), auch ohne gemerkten Preis
function Se:BatchCandidates(only)
    local out = {}
    local db = DB()
    for _, e in ipairs(self:GetBagItems(true)) do
        local last = db.items[e.itemID]
        if only then
            if only[e.itemID] then table.insert(out, { itemID = e.itemID, name = e.name }) end
        elseif last and last.price then
            table.insert(out, { itemID = e.itemID, name = e.name })
        end
    end
    table.sort(out, function(a, b) return string.lower(a.name) < string.lower(b.name) end)
    return out
end

function Se:StartBatch(only)
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    local list = self:BatchCandidates(only)
    if #list == 0 then return false, L["Keine Items mit gemerktem Preis in den Taschen (erst einmal normal einstellen)."] end
    -- immer frisch prüfen: eingestellt wird nur mit Preisen, die nach dem Start geladen wurden
    self.batch = { items = list, pos = 1, posted = 0, skipped = {}, started = Now() }
    for _, e in ipairs(list) do self:CheckPrice(e.itemID) end
    A:Fire("SELLER_CHANGED")
    return true, string.format(L["Serie: %d Items. Jeder Klick stellt eine Auktion ein."], #list)
end

function Se:StopBatch(reason)
    local b = self.batch
    if not b then return end
    self.batch = nil
    local msg = string.format(L["Serie beendet: %d eingestellt, %d übersprungen."], b.posted, #b.skipped)
    if #b.skipped > 0 then msg = msg .. " " .. table.concat(b.skipped, "; ") end
    if reason then msg = msg .. " " .. reason end
    A:Print(msg)
    A:Fire("SELLER_CHANGED")
    return msg
end

-- aktuelles Item der Serie (leere überspringen)
function Se:BatchCurrent()
    local b = self.batch
    if not b then return nil end
    while b.items[b.pos] do
        local e = b.items[b.pos]
        if self:CountInBags(e.itemID) > 0 or (self.pendingPost and self.pendingPost.itemID == e.itemID) then
            return e, b.pos, #b.items
        end
        b.pos = b.pos + 1
    end
    return nil
end

local function BatchSkip(self, e, reason)
    local b = self.batch
    table.insert(b.skipped, e.name .. " (" .. reason .. ")")
    b.pos = b.pos + 1
    return true, string.format(L["Übersprungen: %s - %s"], e.name, reason)
end

-- ein Klick: das nächste Item einstellen
function Se:BatchStep()
    if not self.batch then return false, L["Keine Serie aktiv."] end
    if self.pendingPost and Now() - self.pendingPost.time < 5 then
        return false, L["Warte auf die Bestätigung des letzten Angebots ..."], true
    end
    local e = self:BatchCurrent()
    if not e then return true, self:StopBatch() end
    local id = e.itemID
    local pr = self.prices[id]
    if not pr or pr.time < self.batch.started then
        self:CheckPrice(id, true)
        return false, string.format(L["Preis von %s wird geprüft - gleich nochmal klicken."], e.name), true
    end
    local last = DB().items[id]
    local price, _, atFloor = self:Suggest(id)
    if not price then return BatchSkip(self, e, L["kein Preis"]) end
    -- Konkurrenz unter deinem Mindestpreis: warten statt billig verkaufen
    if atFloor and self:IsPriceFresh(id) and pr.lowestOther and pr.lowestOther < price then
        return BatchSkip(self, e, string.format(L["Konkurrenz unter deinem Mindestpreis (%s)"], A:FormatMoney(price)))
    end
    if last and last.price and price < math.floor(last.price * self.BATCH_FLOOR) then
        return BatchSkip(self, e, string.format(L["nur %s, unter 70 %% deines letzten Preises"], A:FormatMoney(price)))
    end
    local count, entry = self:CountInBags(id)
    local qty = (entry and entry.commodity) and count or 1
    local stack = (entry and entry.commodity and A.AH_LEGACY and last and last.stack) or nil
    if stack then
        if count < stack then return BatchSkip(self, e, string.format(L["Zu wenig für einen Stapel à %d."], stack)) end
        qty = stack * math.min(math.floor(count / stack), last.stacks or math.huge)
    end
    local auctions = stack and math.floor(qty / stack) or 1
    local deposit = entry and self:Deposit(id, (last and last.duration) or DB().duration or 2, qty, entry.commodity, entry.slots[1].loc, auctions)
    if self:VendorBeats(id, price, qty, deposit, auctions) then return BatchSkip(self, e, L["Händler zahlt mehr"]) end
    local risks = self:PriceRisks(id, price)
    if #risks > 0 then return BatchSkip(self, e, L["Preisschutz: "] .. risks[1]) end
    local ok, msg = self:Post(id, price, qty, (last and last.duration) or DB().duration or 2, stack)
    if ok then
        self.batch.posted = self.batch.posted + 1
        if entry and entry.commodity then self.batch.pos = self.batch.pos + 1 end
    end
    return ok, msg
end

-- ------------------------------------------------------------
-- Eigene Auktionen
-- ------------------------------------------------------------
function Se:QueryOwned()
    local C = A.AH
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    if not (C and C.QueryOwnedAuctions) then return false, L["Dein Client unterstützt das Abfragen eigener Auktionen nicht."] end
    local ok, err = pcall(C.QueryOwnedAuctions, SORTS)
    if not ok then return false, tostring(err) end
    self.ownedQueried = Now()
    return true, L["Eigene Auktionen werden geladen ..."]
end

function Se:ReadOwned()
    local C = A.AH
    local list = {}
    local n = SafeCall(C.GetNumOwnedAuctions) or 0
    local soldStatus = (Enum and Enum.AuctionStatus and Enum.AuctionStatus.Sold) or 1
    for i = 1, n do
        local info = SafeCall(C.GetOwnedAuctionInfo, i)
        if type(info) == "table" and info.auctionID then
            local itemID = (info.itemKey and info.itemKey.itemID) or (info.itemLink and tonumber(info.itemLink:match("item:(%d+)")))
            local qty = info.quantity or 1
            local buyout = info.buyoutAmount or info.bidAmount or 0
            table.insert(list, {
                auctionID = info.auctionID, itemID = itemID, name = itemID and A:GetItemName(itemID) or "?",
                qty = qty, buyout = buyout, unitPrice = math.floor(buyout / math.max(1, qty)),
                sold = info.status == soldStatus, timeLeft = info.timeLeftSeconds,
            })
        end
    end
    self.owned = list
    self.ownedTime = Now()
    self:UpdateOwnedStatus()
    A:Fire("SELLER_CHANGED")
end

-- Status: "verkauft", "unterboten", "gleich", "günstigstes", "?" (noch nicht geprüft)
function Se:UpdateOwnedStatus()
    for _, o in ipairs(self.owned) do
        local pr = o.itemID and self.prices[o.itemID]
        o.lowest = pr and pr.lowestOther or nil
        if o.sold then o.status = "verkauft"
        elseif not pr then o.status = "?"
        elseif not pr.lowestOther then o.status = "günstigstes"
        elseif pr.lowestOther < o.unitPrice then o.status = "unterboten"
        elseif pr.lowestOther == o.unitPrice then o.status = "gleich"
        else o.status = "günstigstes" end
    end
end

-- Preise aller eigenen (aktiven) Auktionen prüfen
function Se:CheckUndercuts()
    local seen, n = {}, 0
    for _, o in ipairs(self.owned) do
        if not o.sold and o.itemID and not seen[o.itemID] then
            seen[o.itemID] = true
            self:CheckPrice(o.itemID)
            n = n + 1
        end
    end
    if n == 0 then return false, L["Keine aktiven Auktionen."] end
    return true, string.format(L["Prüfe %d Items ..."], n)
end

function Se:CountByStatus(status)
    local n = 0
    for _, o in ipairs(self.owned) do if o.status == status then n = n + 1 end end
    return n
end

-- Eine Auktion abbrechen (nur per Klick). Die Einstellgebühr ist dabei verloren.
function Se:Cancel(auctionID)
    local C = A.AH
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    if not (C and C.CancelAuction) then return false, L["Dein Client unterstützt das Abbrechen nicht (CancelAuction fehlt)."] end
    local o
    for _, x in ipairs(self.owned) do if x.auctionID == auctionID then o = x end end
    if not o then return false, L["Auktion nicht gefunden."] end
    if o.sold then return false, L["Diese Auktion ist schon verkauft."] end
    if C.CanCancelAuction and SafeCall(C.CanCancelAuction, auctionID) == false then
        return false, L["Diese Auktion kann nicht abgebrochen werden."]
    end
    local ok, err = pcall(C.CancelAuction, auctionID)
    if not ok then return false, L["Abbrechen fehlgeschlagen: "] .. tostring(err) end
    self.pendingCancel = { auctionID = auctionID, time = Now(), name = o.name, qty = o.qty }
    return true, string.format(L["Wird abgebrochen: %dx %s ..."], o.qty, o.name)
end

-- die nächste unterbotene Auktion abbrechen (ein Klick = eine Auktion)
function Se:CancelNextUndercut()
    for _, o in ipairs(self.owned) do
        if o.status == "unterboten" then return self:Cancel(o.auctionID) end
    end
    return false, L["Keine unterbotenen Auktionen (vorher 'Unterbietung prüfen')."]
end

-- ------------------------------------------------------------
-- Ereignisse und Takt
-- ------------------------------------------------------------
local evt = CreateFrame("Frame")
local function Reg(e) A:RegisterAHEvent(evt, e) end
Reg("OWNED_AUCTIONS_UPDATED")
Reg("AUCTION_HOUSE_AUCTION_CREATED")
Reg("AUCTION_CANCELED")
Reg("AUCTION_HOUSE_SHOW_ERROR")
Reg("BAG_UPDATE")
Reg("BAG_UPDATE_DELAYED")

local bagDirty = false
evt:SetScript("OnEvent", function(_, event, a1)
    if event == "OWNED_AUCTIONS_UPDATED" then
        Se:ReadOwned()
    elseif event == "AUCTION_HOUSE_AUCTION_CREATED" then
        local p = Se.pendingPost
        if p then
            Se.pendingPost = nil
            -- tatsächlich abgezogene Gebühr: Gold vorher - nachher (nur wenn plausibel: 0 < x <= 10x Spiel-Wert)
            -- Testmodus/Testroutine: nur simuliert eingestellt -> nichts messen (keine echten Daten schreiben)
            if not A:Simulated() then
                local function Measure()
                    local after = GetMoney and GetMoney()
                    local m = (p.money and after) and (p.money - after) or nil
                    -- unplausibel (Post, Handel o. ä. dazwischen): nicht protokollieren
                    if m and (m <= 0 or (p.deposit and p.deposit > 0 and m > p.deposit * 10 + 10000)) then m = nil end
                    return m
                end
                local measured = Measure()
                p.measured = measured
                if measured or not (C_Timer and C_Timer.After) then
                    pcall(Se.RecordDeposit, Se, p, measured)
                else
                    -- Gold oft erst nach dem Ereignis abgebucht: kurz danach noch einmal, falls kein neues Angebot dazwischen
                    Se.postSeq = (Se.postSeq or 0) + 1
                    local seq = Se.postSeq
                    C_Timer.After(0.5, function()
                        local m = (Se.postSeq == seq and not Se.pendingPost) and Measure() or nil
                        pcall(Se.RecordDeposit, Se, p, m)
                    end)
                end
            end
            local msg = string.format(L["|cff33dd55Eingestellt:|r %dx %s für %s/Stück"], p.qty, A:GetItemName(p.itemID), A:FormatMoney(p.unitPrice))
            if p.deposit then
                msg = msg .. string.format(A:IsForever() and L[" (AH-Gebühr %s)"] or L[" (Einstellgebühr %s)"], A:FormatMoney(p.measured or p.deposit))
            end
            if p.left and p.left > 0 then msg = msg .. string.format(L[" - noch %d: nochmal 'Einstellen' klicken"], p.left) end
            A:Print(msg)
            A:Fire("AUCTION_POSTED", p, a1)
            Se.lastPosted = p
        end
        Se:QueryOwned()
    elseif event == "AUCTION_CANCELED" then
        local c = Se.pendingCancel
        Se.pendingCancel = nil
        if c then
            A:Print(string.format(A:IsForever() and L["Abgebrochen: %dx %s (AH-Gebühr anteilig zurück)"]
                or L["Abgebrochen: %dx %s (Einstellgebühr verloren)"], c.qty, c.name))
        end
        A:Fire("AUCTION_CANCELLED", c, a1)
        Se:QueryOwned()
    elseif event == "AUCTION_HOUSE_SHOW_ERROR" then
        if Se.pendingPost and Now() - Se.pendingPost.time < 5 then
            Se.pendingPost = nil
            A:Print(L["|cffff5544Einstellen fehlgeschlagen|r (zu wenig Gold für die Einstellgebühr oder Item nicht verfügbar)."])
            A:Fire("SELLER_CHANGED")
        elseif Se.pendingCancel and Now() - Se.pendingCancel.time < 5 then
            Se.pendingCancel = nil
            A:Print(L["|cffff5544Abbrechen fehlgeschlagen.|r"])
            A:Fire("SELLER_CHANGED")
        end
    elseif event == "BAG_UPDATE" or event == "BAG_UPDATE_DELAYED" then
        bagDirty = true
        bagCache = nil
    end
end)

-- Ergebnisse sofort auswerten, sobald der Server sie meldet
A:On("SEARCH_RESULTS", function()
    if Se.search then Se.search.answered = true; Se:PollSearch() end
end)
A:On("QUERY_READY", function()
    if not Se.search then Se:StartNext() end
end)

local ticker = CreateFrame("Frame")
local acc, bagAcc = 0, 0
ticker:SetScript("OnUpdate", function(_, dt)
    acc = acc + (dt or 0)
    bagAcc = bagAcc + (dt or 0)
    if acc >= 0.1 then
        acc = 0
        if Se.search then Se:PollSearch() else Se:StartNext() end
        if Se.pendingPost and Now() - Se.pendingPost.time > 10 then Se.pendingPost = nil; A:Fire("SELLER_CHANGED") end
    end
    -- Taschenänderungen gesammelt melden (nicht bei jedem einzelnen Ereignis)
    if bagDirty and bagAcc >= 0.5 then
        bagAcc, bagDirty = 0, false
        A:Fire("SELLER_CHANGED")
    end
end)

A:On("AH_STATE", function()
    if A:IsAHOpen() then
        C_Timer.After(1, function() if A:IsAHOpen() then Se:QueryOwned() end end)
    else
        Se.search = nil
        wipe(Se.queue)
        Se.pendingPost, Se.pendingCancel = nil, nil
        if Se.batch then Se:StopBatch() end
    end
    A:Fire("SELLER_CHANGED")
end)

function Se:GetDebugText()
    local C = A.AH
    local function yn(v) return v and L["ja"] or L["nein"] end
    return "PostCommodity=" .. yn(C and C.PostCommodity) .. ", PostItem=" .. yn(C and C.PostItem)
        .. ", Eigene=" .. yn(C and C.QueryOwnedAuctions) .. ", Abbrechen=" .. yn(C and C.CancelAuction)
        .. ", C_Container=" .. yn(C_Container) .. ", ItemLocation=" .. yn(ItemLocation)
        .. ", Auktionen=" .. #self.owned .. ", Warteschlange=" .. #self.queue
end

-- ------------------------------------------------------------
-- Verkaufs-Meldung: sobald eine Auktion verkauft ist (Systemnachricht des Spiels)
-- Meldung mit Erlös (netto nach AH-Anteil) und Gewinn gegenüber deinem Einkauf
-- ------------------------------------------------------------
local function SoldPattern(text)
    local s = text or _G.ERR_AUCTION_SOLD_S
    -- "%s" oder mit Positionsangabe "%1$s" (manche Sprachfassungen)
    if type(s) ~= "string" or not (s:find("%%s") or s:find("%%%d%$s")) then return nil end
    -- Text des Spiels in ein Suchmuster verwandeln: "%s" = Item-Name
    local p = s:gsub("%%(%d)%$s", "\1"):gsub("%%s", "\1")      -- Platzhalter vorübergehend als Steuerzeichen
    p = p:gsub("([%(%)%.%[%]%*%+%-%?%^%$%%])", "%%%1")
    p = p:gsub("\1", "(.+)")
    return "^" .. p .. "$"
end
Se.SoldPattern = SoldPattern      -- nur lesen (Testroutine T130/T199)

function Se:SaleAlertEnabled()
    return not (A.db and A.db.settings.saleAlert == false)
end

-- Item-Name aus der Meldung -> passende eigene Auktion (für den Preis)
function Se:FindOwnedByName(name)
    local lname = string.lower(name or "")
    for _, o in ipairs(self.owned or {}) do
        if o.itemID and not o.alerted then
            local n1 = A:GetClientItemName(o.itemID)
            local n2 = A:GetItemName(o.itemID)
            if (n1 and string.lower(n1) == lname) or (n2 and string.lower(n2) == lname) then return o end
        end
    end
    return nil
end

function Se:OnSold(name)
    if not self:SaleAlertEnabled() then return end
    local o = self:FindOwnedByName(name)
    local itemID = o and o.itemID or (A.FindItemByName and A:FindItemByName(name))
    local qty = o and o.qty or 1
    local gross = o and o.buyout or (itemID and A:GetMarketValue(itemID) and math.floor(A:GetMarketValue(itemID) * qty)) or nil
    if o then o.alerted = true; o.sold = true; o.status = "verkauft" end
    local parts = { "|cff33dd55" .. L["Verkauft:"] .. "|r " .. qty .. "x " .. (itemID and A:GetItemName(itemID) or name) }
    if gross and gross > 0 then
        local _, _, net = self:Proceeds(math.floor(gross / math.max(1, qty)), qty, itemID, 1)
        table.insert(parts, L["für "] .. A:FormatMoney(gross) .. " (" .. L["netto "] .. A:FormatMoney(net) .. ")")
        local avgBuy = itemID and A.Ledger and A.Ledger.AverageBuyPrice and A.Ledger:AverageBuyPrice(itemID, 30)
        if avgBuy and avgBuy > 0 then
            local profit = net - avgBuy * qty
            local col = profit >= 0 and "|cff33dd55+" or "|cffff5544-"
            table.insert(parts, L["Gewinn "] .. col .. A:FormatMoney(math.abs(profit)) .. "|r")
        end
    end
    local msg = table.concat(parts, "  ") .. "  |cffaaaaaa- " .. L["Gold im Briefkasten abholen"] .. "|r"
    A:Print(msg)
    if UIErrorsFrame and UIErrorsFrame.AddMessage then
        pcall(UIErrorsFrame.AddMessage, UIErrorsFrame, L["Verkauft:"] .. " " .. qty .. "x " .. (itemID and A:GetItemName(itemID) or name), 0.2, 0.87, 0.33)
    end
    if A.db and A.db.settings.alertSound and PlaySound then pcall(PlaySound, 120) end   -- Münzklang
    self.lastSale = { name = name, itemID = itemID, qty = qty, gross = gross, time = Now() }
    A:Fire("SELLER_CHANGED")
end

local saleFrame = CreateFrame("Frame")
Se.saleFrame = saleFrame        -- für die Testroutine
saleFrame:RegisterEvent("CHAT_MSG_SYSTEM")
saleFrame:SetScript("OnEvent", function(_, event, msg)
    if event ~= "CHAT_MSG_SYSTEM" or type(msg) ~= "string" then return end
    local pat = SoldPattern()
    local name = pat and msg:match(pat)
    if name then
        local ok, err = pcall(Se.OnSold, Se, name)
        if not ok then A:ReportError("Verkauft", err) end   -- (bis 0.65.5 verschluckt: A.Debug gab es nie)
    end
end)
