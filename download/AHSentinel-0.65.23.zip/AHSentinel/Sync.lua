if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 4.5 - Preis- und Namens-Synchronisation zwischen allen Nutzern
--
-- Alle Spieler mit diesem Addon treten einem unsichtbaren Kanal bei.
-- Nach jedem eigenen Scan werden die Preise dort verteilt, die anderen
-- Addons tragen sie in ihren Preisverlauf ein. Wer neu einloggt, fragt
-- nach dem neuesten Scan der letzten 2 Stunden.
-- Zusätzlich werden Item-Namen in der Sprache des eigenen Clients geteilt,
-- damit jeder in jeder WoW-Sprache suchen kann.
-- Dazu die Ergebnisse beim Entzaubern (welches Material wie oft herauskam),
-- damit alle die Dropchancen schneller lernen.
-- Es werden nur Preisdaten, Item-Namen und Entzauberungs-Ergebnisse geteilt, nichts sonst.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local S = {}
A.Sync = S

local PREFIX = "AHAP1"              -- Addon-Nachrichten-Kennung (max. 16 Zeichen)
local CHANNEL_NAME = "AHAPSync"     -- unsichtbarer gemeinsamer Kanal
local SEND_INTERVAL = 1.1           -- Sekunden zwischen zwei Nachrichten (Server-Drossel)
local MAX_MSG = 240                 -- Nutzlast pro Nachricht in Bytes
local MAX_AGE = 3 * 86400           -- ältere Daten werden nicht angenommen
local RESPOND_MAX_AGE = 2 * 3600    -- auf Anfragen nur mit Scans der letzten 2 Std. antworten
local MAX_FACTOR = 20               -- Preise, die 20x vom eigenen Wert abweichen, gelten als unplausibel

S.channelId = 0
S.queue = {}
S.heardScanTime = 0                 -- neuester Scan-Zeitpunkt, den andere gerade senden
S.status = L["nicht verbunden"]

-- ------------------------------------------------------------
-- Zahlen kompakt kodieren (Basis 36)
-- ------------------------------------------------------------
local DIGITS = "0123456789abcdefghijklmnopqrstuvwxyz"

local function Enc(n)
    n = math.floor(tonumber(n) or 0)
    if n <= 0 then return "0" end
    local out = ""
    while n > 0 do
        local r = n % 36
        out = DIGITS:sub(r + 1, r + 1) .. out
        n = math.floor(n / 36)
    end
    return out
end

local function Dec(s)
    return s and tonumber(s, 36) or nil
end

S.Enc, S.Dec = Enc, Dec

-- ------------------------------------------------------------
-- Senden
-- ------------------------------------------------------------
local function GetSendFunction()
    local CI = A:API("C_ChatInfo")              -- A:API: ohne Testroutine = Blizzard-Funktion
    if CI and CI.SendAddonMessage then return CI.SendAddonMessage end
    return A:API("SendAddonMessage")
end
S.GetSendFunction = GetSendFunction          -- für die Testroutine (T92, nur nachsehen, nie senden)

-- nur mit der eigenen Gilde teilen?
function S:GuildOnly()
    return A.db and A.db.sync and A.db.sync.guildOnly == true
end

-- Testmodus / Testroutine: nichts senden, nur mitschreiben (S.simLog)
S.simLog = {}
local function SendNow(msg)
    if A:Simulated() then
        table.insert(S.simLog, msg)
        while #S.simLog > 200 do table.remove(S.simLog, 1) end
        return true
    end
    local send = GetSendFunction()
    if not send then return false end
    if S:GuildOnly() then
        if IsInGuild and IsInGuild() then return (pcall(send, PREFIX, msg, "GUILD")) end
        return false
    end
    if S.channelId and S.channelId > 0 then
        return (pcall(send, PREFIX, msg, "CHANNEL", S.channelId))
    end
    if IsInGuild and IsInGuild() then
        return (pcall(send, PREFIX, msg, "GUILD"))
    end
    return false
end

local function ProcessQueue()
    if #S.queue == 0 then
        if S.ticker then S.ticker:Cancel(); S.ticker = nil end
        A:Fire("SYNC_CHANGED")
        return
    end
    local msg = table.remove(S.queue, 1)
    SendNow(msg)
end

local function Enqueue(msg)
    table.insert(S.queue, msg)
    if not S.ticker then
        S.ticker = C_Timer.NewTicker(SEND_INTERVAL, ProcessQueue)
    end
end

S.Enqueue = Enqueue
S.MAX_MSG = MAX_MSG

function S:IsSending()
    return #self.queue > 0
end

-- Einen Scan an alle verteilen
function S:BroadcastScan(scanTime, data)
    if not self:IsEnabled() or not self:IsConnected() or type(data) ~= "table" then return end
    if self.sendingScanTime == scanTime and self:IsSending() then return end
    self.sendingScanTime = scanTime

    local entries = {}
    for itemID, b in pairs(data) do
        A:Pause()
        if b.price and b.price > 0 and not b.u then      -- unbestätigte (mögliche Lockangebote) nicht weitergeben
            table.insert(entries, Enc(itemID) .. "," .. Enc(b.price) .. "," .. Enc(b.qty or 0))
        end
    end
    if #entries == 0 then return end

    local tEnc = Enc(scanTime)
    Enqueue("H:" .. tEnc .. ":" .. Enc(#entries))
    local head = "D:" .. tEnc .. ":"
    local chunk = {}
    local size = #head
    for _, e in ipairs(entries) do
        A:Pause()
        if size + #e + 1 > MAX_MSG and #chunk > 0 then
            Enqueue(head .. table.concat(chunk, ";"))
            chunk, size = {}, #head
        end
        table.insert(chunk, e)
        size = size + #e + 1
    end
    if #chunk > 0 then Enqueue(head .. table.concat(chunk, ";")) end
    A:Fire("SYNC_CHANGED")
end

-- Item-Namen der eigenen Client-Sprache verteilen (für die Suche in allen Sprachen)
function S:BroadcastNames(loc, list)
    if not self:IsEnabled() or not self:IsConnected() or #list == 0 then return end
    local head = "N:" .. loc .. ":"
    local chunk, size = {}, #head
    for _, e in ipairs(list) do
        local part = Enc(e.id) .. "=" .. e.name
        if #head + #part <= MAX_MSG then
            if size + #part + 1 > MAX_MSG and #chunk > 0 then
                Enqueue(head .. table.concat(chunk, ";"))
                chunk, size = {}, #head
            end
            table.insert(chunk, part)
            size = size + #part + 1
        end
    end
    if #chunk > 0 then Enqueue(head .. table.concat(chunk, ";")) end
    A:Fire("SYNC_CHANGED")
end

-- Nach dem Einloggen: fehlende Daten anfragen
function S:RequestLatest()
    if not self:IsEnabled() or not self:IsConnected() then return end
    local since = 0
    if A.db then
        since = math.max(A.db.lastScanTime or 0, A.db.sync.lastScanTimeReceived or 0)
    end
    Enqueue("R:" .. Enc(since))
end

-- ------------------------------------------------------------
-- Empfangen
-- ------------------------------------------------------------
local function ShortName(sender)
    if Ambiguate then
        local ok, n = pcall(Ambiguate, sender, "none")
        if ok and n then return n end
    end
    return (sender or ""):match("^[^-]+") or sender
end

local function IsMe(sender)
    local me = UnitName and UnitName("player")
    return me and ShortName(sender) == me
end

local refreshPending = false
local function ScheduleRefresh()
    if refreshPending then return end
    refreshPending = true
    C_Timer.After(2, function()
        refreshPending = false
        A:Fire("DATA_CHANGED")
    end)
end

function S:HandleData(scanTime, payload)
    local now = time()
    if not scanTime or scanTime > now + 300 or scanTime < now - MAX_AGE then return 0 end
    local added = 0
    for part in payload:gmatch("[^;]+") do
        local a, b, c = part:match("^(%w+),(%w+),(%w+)$")
        local itemID, price, qty = Dec(a), Dec(b), Dec(c)
        if itemID and price and itemID > 0 and itemID < 10000000 and price > 0 and price < 100000000000 then
            qty = qty and math.min(qty, 10000000) or 0
            local own = A:GetCurrent(itemID)
            local plausible = not own or (price <= own * MAX_FACTOR and price * MAX_FACTOR >= own)
            -- verdächtig billige Waren nur als "unbestätigt" übernehmen (zählen nicht)
            if plausible and A:RecordPrice(itemID, price, qty, scanTime, true, A:IsSuspicious(itemID, price)) then
                added = added + 1
            end
        end
    end
    if added > 0 then
        A.db.sync.received = (A.db.sync.received or 0) + added
        A.db.sync.lastReceived = now
        if scanTime > (A.db.sync.lastScanTimeReceived or 0) then
            A.db.sync.lastScanTimeReceived = scanTime
        end
        ScheduleRefresh()
    end
    return added
end

function S:HandleRequest(since)
    local own = A.db and A.db.lastOwnScan
    if not own or not own.t or not own.data then return end
    local now = time()
    if own.t <= (since or 0) or own.t < now - RESPOND_MAX_AGE then return end
    if self.pendingResponse then return end
    self.pendingResponse = true
    -- Zufällige Verzögerung, damit nicht alle gleichzeitig antworten
    C_Timer.After(2 + math.random() * 8, function()
        S.pendingResponse = false
        if S.heardScanTime >= own.t then return end   -- jemand anderes hat schon einen gleich neuen Scan geschickt
        S:BroadcastScan(own.t, own.data)
    end)
end

-- WoW Forever: geschützte Werte ("secret values") nie vergleichen, zerlegen oder als Schlüssel benutzen
local function AnySecret(...)
    local G = _G.GoldSentinelGame
    return G and G.AnySecret and G.AnySecret(...) or false
end

function S:OnMessage(prefix, msg, distType, sender)
    if AnySecret(prefix, msg, distType, sender) then return end
    if prefix ~= PREFIX or not self:IsEnabled() or not A.db or type(msg) ~= "string" then return end
    if IsMe(sender) then return end
    if self:GuildOnly() and distType ~= "GUILD" then return end

    local name = ShortName(sender)
    A.db.sync.peers[name] = time()

    local kind, tEnc, rest = msg:match("^(%a):(%w+):?(.*)$")
    if kind == "N" then
        if A.Names then A.Names:HandleNames(tEnc, rest or "") end
        A:Fire("SYNC_CHANGED")
        return
    end
    if kind == "E" then
        if A.Disenchant then A.Disenchant:HandleShared(name, Dec(tEnc), rest or "") end
        return
    elseif kind == "Q" then
        if A.Disenchant then A.Disenchant:HandleRequest() end
        return
    end
    local t = Dec(tEnc)
    if kind == "H" then
        if t and t > self.heardScanTime then self.heardScanTime = t end
    elseif kind == "D" then
        if t and t > self.heardScanTime then self.heardScanTime = t end
        self:HandleData(t, rest or "")
    elseif kind == "R" then
        self:HandleRequest(t)
    end
    A:Fire("SYNC_CHANGED")
end

-- ------------------------------------------------------------
-- Kanal
-- ------------------------------------------------------------
local function HideChannelFromChat()
    local remove = A:API("ChatFrame_RemoveChannel")
    if not remove then return false end
    for i = 1, (NUM_CHAT_WINDOWS or 10) do
        local cf = _G["ChatFrame" .. i]
        if cf then pcall(remove, cf, CHANNEL_NAME) end
    end
    return true
end
S.HideChannelFromChat = HideChannelFromChat   -- für die Testroutine (T92)

function S:UpdateChannelId()
    local id = 0
    if GetChannelName then
        local ok, result = pcall(GetChannelName, CHANNEL_NAME)
        if ok and type(result) == "number" then id = result end
    end
    self.channelId = id
    if id > 0 then
        self.status = L["verbunden (Kanal "] .. id .. ")"
    elseif IsInGuild and IsInGuild() then
        self.status = L["nur Gilde (Kanal nicht verfügbar)"]
    else
        self.status = L["nicht verbunden"]
    end
    return id
end

function S:Connect(attempt)
    attempt = attempt or 1
    if not self:IsEnabled() then return end
    if A:Simulated() then          -- Testmodus / Testroutine: keinen Kanal betreten oder verlassen
        self.status = L["nicht verbunden"]
        A:Fire("SYNC_CHANGED")
        return
    end
    if self:GuildOnly() then
        -- nur Gilde: gemeinsamen Kanal verlassen
        if LeaveChannelByName and self:UpdateChannelId() > 0 then pcall(LeaveChannelByName, CHANNEL_NAME) end
        self.channelId = 0
        self.status = (IsInGuild and IsInGuild()) and L["nur Gilde"] or L["nur Gilde - du bist in keiner Gilde"]
        if IsInGuild and IsInGuild() then
            C_Timer.After(2, function() S:RequestLatest() end)
            if A.Disenchant and A.Disenchant.RequestShared then
                C_Timer.After(15, function() A.Disenchant:RequestShared() end)
            end
        end
        A:Fire("SYNC_CHANGED")
        return
    end
    local join = JoinTemporaryChannel or JoinChannelByName
    if join and self:UpdateChannelId() == 0 then
        pcall(join, CHANNEL_NAME)
    end
    C_Timer.After(2, function()
        if S:UpdateChannelId() > 0 then
            HideChannelFromChat()
            S:RequestLatest()
            if A.Disenchant and A.Disenchant.RequestShared then
                C_Timer.After(15, function() A.Disenchant:RequestShared() end)
            end
        elseif attempt < 5 then
            S:Connect(attempt + 1)
        elseif S:IsConnected() then
            S:RequestLatest()      -- Gilden-Rückfall
        end
        A:Fire("SYNC_CHANGED")
    end)
end

function S:Disconnect()
    if LeaveChannelByName and self.channelId > 0 and not A:Simulated() then
        pcall(LeaveChannelByName, CHANNEL_NAME)
    end
    wipe(self.queue)
    if self.ticker then self.ticker:Cancel(); self.ticker = nil end
    self.channelId = 0
    self.status = L["ausgeschaltet"]
    A:Fire("SYNC_CHANGED")
end

-- ------------------------------------------------------------
-- Status / Einstellungen
-- ------------------------------------------------------------
function S:IsEnabled()
    return A.db and A.db.sync and A.db.sync.enabled
end

function S:IsConnected()
    if self:GuildOnly() then return (IsInGuild and IsInGuild()) or false end
    return (self.channelId and self.channelId > 0) or (IsInGuild and IsInGuild()) or false
end

-- alle Spieler mit dem Addon <-> nur die eigene Gilde
function S:SetGuildOnly(on)
    if not A.db then return end
    A.db.sync.guildOnly = on and true or nil
    if self:IsEnabled() then
        self.status = L["verbinde ..."]
        self:Connect()
    end
    A:Fire("SYNC_CHANGED")
end

function S:Toggle()
    if not A.db then return end
    A.db.sync.enabled = not A.db.sync.enabled
    if A.db.sync.enabled then
        self.status = L["verbinde ..."]
        self:Connect()
        A:Print(L["Preis-Sync eingeschaltet."])
    else
        self:Disconnect()
        A:Print(L["Preis-Sync ausgeschaltet."])
    end
end

-- Mitspieler, die in den letzten "seconds" Sekunden etwas gesendet haben
function S:CountPeers(seconds)
    if not A.db then return 0 end
    local limit = time() - (seconds or 3600)
    local n = 0
    for name, t in pairs(A.db.sync.peers) do
        if t >= limit then n = n + 1 elseif t < time() - 30 * 86400 then A.db.sync.peers[name] = nil end
    end
    return n
end

function S:GetStatusText()
    if not self:IsEnabled() then return L["|cff888888Sync aus|r"] end
    local peers = self:CountPeers(3600)
    local text = (self:IsConnected() and L["|cff33dd55Sync|r"] or L["|cffff5544Sync getrennt|r"]) .. ": " .. peers .. L[" Mitspieler (1 Std.)"]
    if self:IsSending() then text = text .. L[", sende ... ("] .. #self.queue .. ")" end
    return text
end

function S:GetDebugText()
    if not A.db then return "-" end
    return string.format(L["%s, Status: %s, Mitspieler 1 Std.: %d, empfangene Preise: %d, empfangene Namen: %d, zuletzt empfangen: %s, Warteschlange: %d"],
        self:IsEnabled() and L["an"] or L["aus"], self.status, self:CountPeers(3600),
        A.db.sync.received or 0, A.db.sync.namesReceived or 0, A:FormatAgo(A.db.sync.lastReceived), #self.queue)
end

-- ------------------------------------------------------------
-- Einrichtung
-- ------------------------------------------------------------
local frame = CreateFrame("Frame")
S.frame = frame         -- für die Testroutine
pcall(frame.RegisterEvent, frame, "CHAT_MSG_ADDON")
frame:SetScript("OnEvent", function(_, event, ...)
    if event == "CHAT_MSG_ADDON" then
        local ok, err = pcall(S.OnMessage, S, ...)
        if not ok then
            A:Print(L["Sync-Fehler: "] .. tostring(err))
            A:ReportError("Sync", err)
        end
    end
end)

if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
    pcall(C_ChatInfo.RegisterAddonMessagePrefix, PREFIX)
elseif RegisterAddonMessagePrefix then
    pcall(RegisterAddonMessagePrefix, PREFIX)
end

A:On("READY", function()
    -- Kanäle sind direkt nach dem Login oft noch nicht bereit
    C_Timer.After(6, function() S:Connect() end)
end)

A:On("SCAN_FINISHED", function(_, best, scanTime)
    A:Job("sync-send", function() S:BroadcastScan(scanTime, best) end)
end)
