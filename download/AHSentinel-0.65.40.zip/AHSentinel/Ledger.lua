if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.7 - Buchhaltung (Logik)
--
-- Was wird gebucht?
--   * Verkäufe   - aus den Rechnungen im Briefkasten ("Auktion erfolgreich"):
--                  Verkaufspreis, AH-Anteil (5 %), zurückerstattete Einstellgebühr
--   * Käufe      - aus den Rechnungen im Briefkasten ("Auktion gewonnen")
--                  und sofort bei Käufen über den Sniper (doppelt wird nie gezählt)
--   * Einstellgebühren - sofort beim Einstellen über den Tab Verkaufen
-- Der Briefkasten muss dafür geöffnet werden - die Rechnungen liest das
-- Addon automatisch, du musst nichts abholen oder anklicken.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
-- Retail 12.x: die alten Item-/Zauber-Funktionen gibt es nur noch in C_Item / C_Spell
local GetItemInfo = GetItemInfo or (C_Item and C_Item.GetItemInfo)
local A = AHAnalyzerPro
local L = A.L

-- Briefkasten über A.Inbox (im Testmodus: Test-Briefkasten mit fiktiver Post)
local function GetInboxNumItems(...) return A.Inbox.GetInboxNumItems(...) end
local function GetInboxHeaderInfo(...) return A.Inbox.GetInboxHeaderInfo(...) end
local function GetInboxInvoiceInfo(...) return A.Inbox.GetInboxInvoiceInfo(...) end
local function GetInboxItem(...) return A.Inbox.GetInboxItem(...) end
local function GetInboxItemLink(...) return A.Inbox.GetInboxItemLink(...) end
local function TakeInboxMoney(...) return A.Inbox.TakeInboxMoney(...) end
local function TakeInboxItem(...) return A.Inbox.TakeInboxItem(...) end

local Le = {}
A.Ledger = Le

local KEEP_DAYS = 180          -- Buchungen älter als das werden gelöscht
local MAX_ENTRIES = 5000
local MATCH_WINDOW = 3 * 86400 -- Sniper-Kauf und Rechnung im Briefkasten gelten als derselbe Kauf
local AH_MAIL_DAYS = 30        -- so lange liegt Auktionspost im Briefkasten

local function DB()
    return A.db and A.db.ledger
end

-- ------------------------------------------------------------
-- Buchen
-- kind: "sale" (Verkauf, amount = Preis brutto, cut = AH-Anteil, refund = Einstellgebühr zurück)
--       "buy"  (Kauf, amount = bezahlter Preis)
--       "deposit" (Einstellgebühr, amount = Gebühr)
-- ------------------------------------------------------------
function Le:Add(e)
    local db = DB()
    if not db then return nil end
    e.t = e.t or time()
    e.qty = e.qty or 1
    e.amount = math.floor(e.amount or 0)
    if not e.name and e.itemID then e.name = A:GetItemName(e.itemID) end
    -- Werte stimmen, Punkt 10: beim Einstellen die Vorhersage merken, beim Verkauf vergleichen
    if e.kind == "deposit" and e.itemID and not e.pred then
        local ok, v = pcall(A.RealPrice, A, e.itemID, { noRelist = true })
        if ok and v then e.pred = math.floor(v + 0.5) end
    elseif e.kind == "sale" and e.itemID and e.src == "mail" then
        pcall(self.CompareSale, self, e)
    end
    table.insert(db.entries, e)
    self:Prune()
    A:Fire("LEDGER_CHANGED")
    return e
end

function Le:Prune()
    local db = DB()
    local cutoff = time() - KEEP_DAYS * 86400
    local list = db.entries
    if #list > MAX_ENTRIES or (list[1] and list[1].t < cutoff) then
        local keep = {}
        for _, e in ipairs(list) do if e.t >= cutoff then table.insert(keep, e) end end
        while #keep > MAX_ENTRIES do table.remove(keep, 1) end
        db.entries = keep
    end
    for key, t in pairs(db.seen) do
        if t < time() - (AH_MAIL_DAYS + 5) * 86400 then db.seen[key] = nil end
    end
end

-- Item-ID aus dem Namen in der Rechnung (Name in der Sprache des Clients)
local function ResolveName(name)
    if not name or name == "" then return nil end
    if GetItemInfo then
        local ok, _, link = pcall(GetItemInfo, name)
        if ok and type(link) == "string" then
            local id = tonumber(link:match("item:(%d+)"))
            if id then return id end
        end
    end
    if A.Names then
        local id = A.Names:Resolve(name)
        if id then return id end
    end
    return nil
end

-- ------------------------------------------------------------
-- Briefkasten lesen
-- ------------------------------------------------------------
function Le:ScanInbox()
    local db = DB()
    if not db or not A.Inbox.Available() or not (_G.GetInboxInvoiceInfo or A:Simulated()) then return 0 end
    local n = GetInboxNumItems() or 0
    local added = 0
    local now = time()
    for i = 1, n do
        local okH, _, _, sender, subject, money, cod, daysLeft = pcall(GetInboxHeaderInfo, i)
        local okI, invoiceType, itemName, playerName, bid, buyout, deposit, consignment, _, _, count = pcall(GetInboxInvoiceInfo, i)
        if okH and okI and (invoiceType == "seller" or invoiceType == "buyer") and itemName then
            -- Ankunftszeit aus der Restlaufzeit (Auktionspost bleibt 30 Tage)
            local arrived = now - math.floor(((AH_MAIL_DAYS - (daysLeft or AH_MAIL_DAYS)) * 86400) + 0.5)
            local hour = math.floor(arrived / 3600)
            count = count or 1
            local price = (invoiceType == "seller") and (buyout or bid or 0) or (bid or buyout or 0)
            local base = table.concat({ invoiceType, itemName, tostring(playerName or ""), tostring(price), tostring(count) }, "|")
            local key = base .. "|" .. hour
            -- gleiche Rechnung beim nächsten Öffnen evtl. eine Stunde verschoben (Rundung)
            if not db.seen[key] and not db.seen[base .. "|" .. (hour - 1)] and not db.seen[base .. "|" .. (hour + 1)] then
                db.seen[key] = now
                local itemID = ResolveName(itemName)
                if invoiceType == "seller" then
                    if A:IsForever() then
                        -- L1 (Prüfung 11:55): in Forever ist die einzige Gebühr beim Einstellen schon gebucht. Erlös = Gold,
                        -- das die Post wirklich bringt; Anteil/Einzahlung der Rechnung nur merken, nicht verrechnen.
                        local got = (type(money) == "number" and money > 0) and money or (price - (consignment or 0))
                        self:Add({ kind = "sale", t = arrived, itemID = itemID, name = itemName, qty = count,
                                   amount = got, cut = 0, refund = 0, player = playerName, src = "mail",
                                   inv = { price = price, cut = consignment or 0, deposit = deposit or 0, money = money or 0 } })
                        if A.Diag then
                            A.Diag:Add("RECHNUNG", string.format("Item %s · Menge %d · Preis %d · consignment %d · deposit %d · Post-Gold %d",
                                tostring(itemID or "?"), count, price or 0, consignment or 0, deposit or 0, money or 0))
                        end
                    else
                        self:Add({ kind = "sale", t = arrived, itemID = itemID, name = itemName, qty = count,
                                   amount = price, cut = consignment or 0, refund = deposit or 0, player = playerName, src = "mail" })
                    end
                    added = added + 1
                else
                    -- schon über den Sniper gebucht?
                    local match = self:FindUnmatchedBuy(itemID, itemName, count, price, arrived)
                    if match then
                        match.mail = true
                        match.player = match.player or playerName
                    else
                        self:Add({ kind = "buy", t = arrived, itemID = itemID, name = itemName, qty = count,
                                   amount = price, player = playerName, src = "mail" })
                        added = added + 1
                    end
                end
            end
        end
    end
    if added > 0 then
        A:Print(added == 1 and L["Buchhaltung: 1 neue Rechnung aus dem Briefkasten gebucht."]
            or string.format(L["Buchhaltung: %d neue Rechnungen aus dem Briefkasten gebucht."], added))
    end
    return added
end

function Le:FindUnmatchedBuy(itemID, itemName, qty, amount, t)
    for _, e in ipairs(DB().entries) do
        if e.kind == "buy" and (e.src == "sniper" or e.src == "buy") and not e.mail and e.qty == qty and e.amount == amount
            and math.abs(e.t - t) <= MATCH_WINDOW and ((itemID and e.itemID == itemID) or e.name == itemName) then
            return e
        end
    end
    return nil
end

-- ------------------------------------------------------------
-- Auswertung
-- ------------------------------------------------------------
Le.PERIODS = {
    { key = "today", label = "Heute" },
    { key = "7", label = "7 Tage", days = 7 },
    { key = "30", label = "30 Tage", days = 30 },
    { key = "all", label = "Alles" },
}

function Le:PeriodStart(key)
    if key == "today" then
        local d = date("*t", time())
        return time({ year = d.year, month = d.month, day = d.day, hour = 0, min = 0, sec = 0 })
    end
    for _, p in ipairs(self.PERIODS) do
        if p.key == key and p.days then return time() - p.days * 86400 end
    end
    return 0
end

function Le:GetEntries(key)
    local from = self:PeriodStart(key)
    local out = {}
    for _, e in ipairs(DB().entries) do
        if e.t >= from then table.insert(out, e) end
    end
    return out
end

-- ------------------------------------------------------------
-- Abrechnung Entzaubern (Anweisung Sammelkauf E4, ab 0.65.38)
-- Je Tag und gesamt: ausgegeben für Sammelkauf-Teile, Wert der erhaltenen Materialien, Gewinn, Anzahl, Rendite %.
-- Zugeordnet werden Kauf und Entzauberung über ItemID + Zeitfenster (Disenchant.lua D:LogResult, 14 Tage).
-- Materialwert = reale Preisfunktion (A:PriceInfo über D:MatPrice): eigene Verkäufe der letzten 14 Tage zuerst,
-- also der echte Erlös, wenn das Material schon verkauft wurde; sonst der aktuelle reale Wert. Nach AH-Gebühr.
-- Entzauberungen eigener Teile (ohne Kauf) zählen getrennt (nur Materialwert).
-- ------------------------------------------------------------
local function DayKey(t)
    local d = date("*t", t)
    return time({ year = d.year, month = d.month, day = d.day, hour = 0, min = 0, sec = 0 })
end
Le.DayKey = DayKey

-- Materialwert einer Entzauberung (netto nach AH-Gebühr), complete = false wenn ein Preis fehlt
function Le:DisenchantLootValue(loot)
    local D = A.Disenchant
    local v, complete = 0, true
    for _, m in ipairs(loot or {}) do
        local p = D and D.MatPrice and D:MatPrice(m[1]) or nil
        if p then
            local qty = m[2] or 1
            local fee = A.FeePerPiece and A:FeePerPiece(m[1], p) or 0
            v = v + math.max(0, p - fee) * qty
        else
            complete = false
        end
    end
    return math.floor(v + 0.5), complete
end

function Le:DisenchantReport(key)
    local from = self:PeriodStart(key)
    local days, total = {}, { count = 0, spent = 0, value = 0, own = 0, ownValue = 0, incomplete = 0 }
    for _, e in ipairs(A.db and A.db.deLog or {}) do
        if (e.t or 0) >= from then
            local dk = DayKey(e.t)
            local d = days[dk]
            if not d then d = { day = dk, count = 0, spent = 0, value = 0, own = 0, ownValue = 0 }; days[dk] = d end
            local v, complete = self:DisenchantLootValue(e.loot)
            if not complete then total.incomplete = total.incomplete + 1 end
            if e.paid then
                d.count, d.spent, d.value = d.count + 1, d.spent + e.paid, d.value + v
                total.count, total.spent, total.value = total.count + 1, total.spent + e.paid, total.value + v
            else
                d.own, d.ownValue = d.own + 1, d.ownValue + v
                total.own, total.ownValue = total.own + 1, total.ownValue + v
            end
        end
    end
    local rows = {}
    for _, d in pairs(days) do
        d.profit = d.value - d.spent
        d.roi = d.spent > 0 and (d.profit / d.spent * 100) or nil
        rows[#rows + 1] = d
    end
    table.sort(rows, function(a, b) return a.day > b.day end)
    total.profit = total.value - total.spent
    total.roi = total.spent > 0 and (total.profit / total.spent * 100) or nil
    -- gekauft, noch nicht entzaubert
    total.open, total.openSpent = 0, 0
    for _, b in ipairs(A.db and A.db.deBuys or {}) do
        if not b.done and (b.t or 0) >= from then total.open, total.openSpent = total.open + 1, total.openSpent + (b.paid or 0) end
    end
    return rows, total
end

-- ------------------------------------------------------------
-- Vorhersage gegen Wirklichkeit (Werte stimmen, Punkt 10)
-- Vorhersage = realer Preis pro Stück beim Einstellen (A:RealPrice), Wirklichkeit = Verkaufspreis pro Stück aus der
-- Rechnung. Abweichung = (Vorhersage - echt) / echt: positiv = Werte zu hoch. Je Item-Gruppe (Item-Klasse) und gesamt.
-- Diagnose-Protokoll: Eintrag WERT (ohne Namen), die Prüf-Sitzung wertet ihn über GSDIAG1 aus.
-- ------------------------------------------------------------
Le.DEV_DAYS = 7
local function ItemGroup(itemID)
    if not (GetItemInfo and itemID) then return nil end
    local classID = select(12, GetItemInfo(itemID))
    return classID
end
function Le:GroupName(classID)
    if classID == nil then return "?" end
    local f = A:API("GetItemClassInfo")
    local n = f and f(classID)
    return n or ("#" .. tostring(classID))
end

function Le:CompareSale(e)
    local gross = (e.inv and e.inv.price) or e.amount or 0
    local unit = gross / math.max(1, e.qty or 1)
    if unit <= 0 then return nil end
    local best
    for _, d in ipairs(DB().entries) do
        if d.kind == "deposit" and d.itemID == e.itemID and d.pred and d.t <= e.t and e.t - d.t <= self.DEV_DAYS * 86400 then
            if not best or d.t > best.t then best = d end
        end
    end
    if not best then return nil end
    e.pred = best.pred
    e.dev = (best.pred - unit) / unit
    e.grp = ItemGroup(e.itemID)
    if A.Diag then
        A.Diag:Add("WERT", string.format("Gruppe %s · Item %d · vorhergesagt %d · echt %d · Abweichung %+d %%",
            tostring(e.grp or "?"), e.itemID, best.pred, math.floor(unit + 0.5), math.floor(e.dev * 100 + (e.dev >= 0 and 0.5 or -0.5))))
    end
    return e.dev
end

-- Abweichung im Zeitraum: total = { n, avg }, groups = { { grp, name, n, avg } } (avg als Anteil, 0.08 = 8 % zu hoch)
function Le:Deviation(key)
    local total, by = { n = 0, sum = 0 }, {}
    for _, e in ipairs(self:GetEntries(key)) do
        if e.kind == "sale" and type(e.dev) == "number" then
            local d = math.max(-1, math.min(3, e.dev))         -- einzelne Ausreisser begrenzen
            total.n, total.sum = total.n + 1, total.sum + d
            local g = e.grp or "?"
            local b = by[g]
            if not b then b = { grp = g, n = 0, sum = 0 }; by[g] = b end
            b.n, b.sum = b.n + 1, b.sum + d
        end
    end
    total.avg = total.n > 0 and total.sum / total.n or nil
    local groups = {}
    for _, b in pairs(by) do
        b.avg = b.sum / b.n
        b.name = self:GroupName(b.grp ~= "?" and b.grp or nil)
        groups[#groups + 1] = b
    end
    table.sort(groups, function(a, b) return a.n > b.n end)
    return total, groups
end

function Le:DeviationText(key)
    local t, groups = self:Deviation(key)
    if not t.avg then return L["Abweichung: noch keine Verkäufe mit Vorhersage."] end
    local function one(avg)
        local pct = math.floor(math.abs(avg) * 100 + 0.5)
        if pct == 0 then return L["genau"] end
        return string.format(avg > 0 and L["%d %% zu hoch"] or L["%d %% zu tief"], pct)
    end
    local parts = {}
    for k = 1, math.min(3, #groups) do parts[#parts + 1] = string.format("%s %s (%d)", groups[k].name, one(groups[k].avg), groups[k].n) end
    return string.format(L["Abweichung: Werte im Schnitt %s (%d Verkäufe)"], one(t.avg), t.n)
        .. (#parts > 0 and ("  ·  " .. table.concat(parts, ", ")) or "")
end

-- ------------------------------------------------------------
-- Einmalige Reparatur alter Verkaufsbuchungen (Anweisung "Buchhaltung Reparatur", 9. Nov. 13:20)
-- Vor 0.65.35 trugen Forever-Verkäufe cut = consignment und refund = deposit der Rechnung (Gebühr doppelt).
-- Nur Forever, nur kind "sale", src "mail", ohne Feld "inv", mit cut > 0 oder refund > 0: Sicherung e.old, dann
-- cut = refund = 0 (amount bleibt). Nichts löschen. Schalter db.ledger.fixL1: läuft nie zweimal.
-- Rückgabe: Anzahl korrigierter Verkäufe (nil = schon gelaufen bzw. kein Forever)
-- ------------------------------------------------------------
function Le:FixL1(quiet)
    local db = DB()
    if not db or db.fixL1 then return nil end
    if not A:IsForever() then return nil end
    local n = 0
    for _, e in ipairs(db.entries or {}) do
        if e.kind == "sale" and e.src == "mail" and e.inv == nil and ((e.cut or 0) > 0 or (e.refund or 0) > 0) then
            e.old = { cut = e.cut, refund = e.refund }
            e.cut, e.refund = 0, 0
            n = n + 1
        end
    end
    db.fixL1 = 1
    if A.Diag then A.Diag:Add("MIGRATION", string.format("fixL1 N=%d", n)) end
    if n > 0 then
        if not quiet then A:Print(string.format(L["Buchhaltung: %d alte Verkäufe korrigiert (Gebühr war doppelt abgezogen)."], n)) end
        A:Fire("LEDGER_CHANGED")
    end
    return n
end
A:On("READY", function() pcall(Le.FixL1, Le) end)

-- eigene Verkaufsquote eines Items: Einstellungen (Auktionen, älter als 2 Tage - laufende zählen nicht) und
-- Verkäufe (je Rechnung eine Auktion) der letzten days Tage. Rückgabe: posts, sales
function Le:PostRate(itemID, days)
    local now = time()
    local from, till = now - (days or 30) * 86400, now - 2 * 86400
    local posts, sales = 0, 0
    for _, e in ipairs(DB().entries) do
        if e.itemID == itemID and e.t >= from then
            if e.kind == "deposit" and e.t <= till then posts = posts + math.max(1, e.auctions or 1)
            elseif e.kind == "sale" then sales = sales + 1 end
        end
    end
    return posts, sales
end

-- Summen: income (Verkäufe nach AH-Anteil), spent (Käufe), fees (Einstellgebühren minus Erstattungen), profit
function Le:Summary(key)
    local s = { income = 0, gross = 0, cut = 0, spent = 0, fees = 0, refunds = 0, sales = 0, buys = 0 }
    for _, e in ipairs(self:GetEntries(key)) do
        if e.kind == "sale" then
            s.gross = s.gross + e.amount
            s.cut = s.cut + (e.cut or 0)
            s.income = s.income + e.amount - (e.cut or 0)
            s.refunds = s.refunds + (e.refund or 0)
            s.sales = s.sales + 1
        elseif e.kind == "buy" then
            s.spent = s.spent + e.amount
            s.buys = s.buys + 1
        elseif e.kind == "deposit" then
            s.fees = s.fees + e.amount
        elseif e.kind == "refund" then
            s.refunds = s.refunds + (e.amount or 0)       -- Erstattung beim Abbrechen (L2)
        end
    end
    s.fees = s.fees - s.refunds
    s.profit = s.income - s.spent - s.fees
    return s
end

-- pro Item: verkauft, Erlös (nach AH-Anteil), gekauft, Kosten, Gebühren, Gewinn
function Le:ByItem(key)
    local by, list = {}, {}
    for _, e in ipairs(self:GetEntries(key)) do
        local id = e.itemID or e.name or "?"
        local r = by[id]
        if not r then
            r = { itemID = e.itemID, name = e.itemID and A:GetItemName(e.itemID) or e.name or "?", soldQty = 0, income = 0,
                  boughtQty = 0, spent = 0, fees = 0 }
            by[id] = r
            table.insert(list, r)
        end
        if e.kind == "sale" then
            r.soldQty = r.soldQty + e.qty
            r.income = r.income + e.amount - (e.cut or 0)
            r.fees = r.fees - (e.refund or 0)
        elseif e.kind == "buy" then
            r.boughtQty = r.boughtQty + e.qty
            r.spent = r.spent + e.amount
        elseif e.kind == "deposit" then
            r.fees = r.fees + e.amount
        elseif e.kind == "refund" then
            r.fees = r.fees - (e.amount or 0)
        end
    end
    for _, r in ipairs(list) do r.profit = r.income - r.spent - r.fees end
    return list
end

-- ------------------------------------------------------------
-- Statistik: Verkaufsquote und beste Verkaufszeit
-- ------------------------------------------------------------
-- Zeitpunkt des Verkaufs: Rechnungen kommen ca. 1 Std. nach dem Verkauf
function Le:SaleTime(e)
    if e.src == "mail" then return e.t - 3600 end
    return e.t
end

-- items: pro Item eingestellt / verkauft / Quote / Ø Preis
-- hours[0..23], weekdays[1..7] (1 = Montag): Anzahl Verkäufe und Erlös
function Le:Stats(key)
    local by, items = {}, {}
    local hours, weekdays = {}, {}
    for h = 0, 23 do hours[h] = { n = 0, income = 0 } end
    for d = 1, 7 do weekdays[d] = { n = 0, income = 0 } end
    for _, e in ipairs(self:GetEntries(key)) do
        if e.kind == "sale" or (e.kind == "deposit" and e.src == "post") then
            local id = e.itemID or e.name or "?"
            local r = by[id]
            if not r then
                r = { itemID = e.itemID, name = e.itemID and A:GetItemName(e.itemID) or e.name or "?", posted = 0, sold = 0, income = 0 }
                by[id] = r
                table.insert(items, r)
            end
            if e.kind == "sale" then
                r.sold = r.sold + e.qty
                r.income = r.income + e.amount - (e.cut or 0)
                local t = self:SaleTime(e)
                local h = tonumber(date("%H", t))
                local wd = tonumber(date("%w", t))       -- 0 = Sonntag
                wd = (wd == 0) and 7 or wd
                hours[h].n = hours[h].n + 1
                hours[h].income = hours[h].income + e.amount - (e.cut or 0)
                weekdays[wd].n = weekdays[wd].n + 1
                weekdays[wd].income = weekdays[wd].income + e.amount - (e.cut or 0)
            else
                r.posted = r.posted + e.qty
            end
        end
    end
    for _, r in ipairs(items) do
        r.rate = (r.posted > 0) and math.min(100, r.sold / r.posted * 100) or nil
        r.avg = (r.sold > 0) and math.floor(r.income / r.sold + 0.5) or nil
    end
    -- beste Stunden (nach Anzahl Verkäufe)
    local best = {}
    for h = 0, 23 do if hours[h].n > 0 then table.insert(best, h) end end
    table.sort(best, function(a, b) return hours[a].n > hours[b].n end)
    return { items = items, hours = hours, weekdays = weekdays, best = best }
end

-- Durchschnittlicher Einkaufspreis pro Stück (für die Gewinnrechnung beim Verkaufen)
-- wie oft wurde das Item in den letzten x Tagen verkauft (eigene Verkäufe)
function Le:SoldCount(itemID, days)
    local from = time() - (days or 30) * 86400
    local n = 0
    for _, e in ipairs(DB().entries) do
        if e.kind == "sale" and e.itemID == itemID and e.t >= from then n = n + 1 end
    end
    return n
end

-- Stück je Auktion der letzten n eigenen Einstellungen dieses Items (L5, für die Gebühr im Gewinn-Fenster)
function Le:PostSizes(itemID, n)
    local out = {}
    local entries = DB() and DB().entries or {}
    for i = #entries, 1, -1 do
        local e = entries[i]
        if e.kind == "deposit" and e.src == "post" and e.itemID == itemID and (e.qty or 0) > 0 then
            out[#out + 1] = math.max(1, math.floor((e.qty or 1) / math.max(1, e.auctions or 1) + 0.5))
            if #out >= (n or 10) then break end
        end
    end
    return out
end

-- Ø Verkaufspreis pro Stück (brutto) aus echten Verkäufen der letzten Tage
function Le:AverageSalePrice(itemID, days)
    local from = time() - (days or 14) * 86400
    local qty, sum = 0, 0
    for _, e in ipairs(DB().entries) do
        if e.kind == "sale" and e.itemID == itemID and e.t >= from and (e.qty or 0) > 0 then
            qty = qty + e.qty
            sum = sum + (e.amount or 0)
        end
    end
    if qty == 0 then return nil end
    return math.floor(sum / qty + 0.5), qty
end

function Le:AverageBuyPrice(itemID, days)
    local from = time() - (days or 30) * 86400
    local qty, cost = 0, 0
    for _, e in ipairs(DB().entries) do
        if e.kind == "buy" and e.itemID == itemID and e.t >= from then
            qty = qty + e.qty
            cost = cost + e.amount
        end
    end
    if qty == 0 then return nil end
    return math.floor(cost / qty + 0.5), qty
end

-- ------------------------------------------------------------
-- Ereignisse
-- ------------------------------------------------------------
-- Einstellgebühr beim Einstellen über den Tab Verkaufen
-- (auch ohne Gebühr gebucht: zählt als "eingestellt" für die Verkaufsquote)
A:On("AUCTION_POSTED", function(p)
    if p and p.itemID then
        -- wirklich abgezogen (Gold vorher - nachher), sonst die erwartete Gebühr
        Le:Add({ kind = "deposit", itemID = p.itemID, qty = p.qty or 1, auctions = p.auctions or 1, amount = p.measured or p.deposit or 0, src = "post" })
    end
end)

-- L2: Erstattung beim Abbrechen (gemessen: Gold nachher - vorher) buchen
A:On("AUCTION_CANCELLED", function(c)
    if not (c and c.money) then return end
    local function book()
        local now = GetMoney and GetMoney() or 0
        local back = now - c.money
        if back > 0 and back < 100000000 then
            Le:Add({ kind = "refund", itemID = c.itemID, qty = c.qty or 1, amount = back, src = "cancel" })
        end
        if A.Diag then A.Diag:Add("ABBRUCH", string.format("Item %s · Menge %d · Erstattung %d", tostring(c.itemID or "?"), c.qty or 1, math.max(0, back))) end
    end
    if C_Timer and C_Timer.After then C_Timer.After(0.5, book) else book() end
end)

local evt = CreateFrame("Frame")
local function Reg(e) A:RegisterAHEvent(evt, e) end
Reg("MAIL_SHOW")
Reg("MAIL_INBOX_UPDATE")
Reg("AUCTION_HOUSE_PURCHASE_COMPLETED")
Reg("COMMODITY_PURCHASE_SUCCEEDED")

local scanPending = false
evt:SetScript("OnEvent", function(_, event)
    if event == "MAIL_SHOW" or event == "MAIL_INBOX_UPDATE" then
        -- mehrere Ereignisse kurz hintereinander: einmal lesen
        if scanPending then return end
        scanPending = true
        C_Timer.After(0.5, function()
            scanPending = false
            local ok, err = pcall(Le.ScanInbox, Le)
            if not ok then A:Print(L["Buchhaltung: Fehler beim Lesen der Post: "] .. tostring(err)) end
        end)
    elseif event == "AUCTION_HOUSE_PURCHASE_COMPLETED" or event == "COMMODITY_PURCHASE_SUCCEEDED" then
        -- Kauf über den Sniper: sofort buchen (die Rechnung im Briefkasten wird später zugeordnet)
        local lp = A.Sniper and A.Sniper.lastPurchase
        if lp and not lp.booked and GetTime() - lp.time < 15 then
            lp.booked = true
            local itemID = lp.itemID
            Le:Add({ kind = "buy", itemID = itemID, qty = lp.qty, amount = lp.cost, src = "sniper" })
        end
        -- Kauf im Reiter Einkauf
        local bp = A.Buy and A.Buy.lastPurchase
        if bp and not bp.booked and bp.cost and GetTime() - bp.time < 15 then
            bp.booked = true
            Le:Add({ kind = "buy", itemID = bp.itemID, qty = bp.qty, amount = bp.cost, src = "buy" })
        end
    end
end)

function Le:GetDebugText()
    local db = DB()
    if not db then return "-" end
    return #db.entries .. " Buchungen, Briefkasten-API=" .. ((_G.GetInboxInvoiceInfo and L["ja"]) or L["nein"])
end
