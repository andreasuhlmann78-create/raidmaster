local ADDON, ns = ...
local L = ns.L

-- /ps autotest (developer only) – since 0.9.11 a short form of the test routine (TestRoutine.lua):
--   /ps autotest              = /ps testroutine (everything, one report through GoldSentinelTest)
--   /ps autotest stop         = /ps testroutine stop
--   /ps autotest bericht      = the last report (copy window)
--   /ps autotest verlauf      = short history of the last 10 runs
-- The old step machine (own sandbox, own Markdown report) is gone: there is only one report format now.
-- ProfessionSentinelDB.autotest.last keeps a copy of the last report text, autotest.history the short history.
-- This file also holds the copy window used by the test routine.

local AT = {}
ns.AutoTest = AT

local HISTORY = 10
local reportWin

---------------------------------------------------------------------------
-- Copy window (Ctrl+A / Ctrl+C)
---------------------------------------------------------------------------
function AT.ShowReport(text, title, hint)
    if not text then ns.Print(L.TR_NO_REPORT); return end
    if not reportWin then
        reportWin = CreateFrame("Frame", "ProfessionSentinelAutoTestReport", UIParent, "ButtonFrameTemplate")
        reportWin:Hide()
        reportWin:SetSize(640, 560)
        reportWin:SetPoint("CENTER")
        reportWin:SetFrameStrata("DIALOG")
        reportWin:SetMovable(true)
        reportWin:EnableMouse(true)
        reportWin:RegisterForDrag("LeftButton")
        reportWin:SetScript("OnDragStart", reportWin.StartMoving)
        reportWin:SetScript("OnDragStop", reportWin.StopMovingOrSizing)
        reportWin:SetClampedToScreen(true)
        if ButtonFrameTemplate_HidePortrait then ButtonFrameTemplate_HidePortrait(reportWin) end
        if ButtonFrameTemplate_HideButtonBar then ButtonFrameTemplate_HideButtonBar(reportWin) end
        if reportWin.Inset then reportWin.Inset:Hide() end
        tinsert(UISpecialFrames, "ProfessionSentinelAutoTestReport")

        local h = reportWin:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        h:SetPoint("TOPLEFT", 16, -30)
        h:SetPoint("RIGHT", -16, 0)
        h:SetJustifyH("LEFT")
        reportWin.hint = h

        local sf = CreateFrame("ScrollFrame", "ProfessionSentinelAutoTestScroll", reportWin, "UIPanelScrollFrameTemplate")
        sf:SetPoint("TOPLEFT", 14, -62)
        sf:SetPoint("BOTTOMRIGHT", -32, 44)
        local eb = CreateFrame("EditBox", nil, sf)
        eb:SetMultiLine(true)
        eb:SetAutoFocus(false)
        eb:SetFontObject(ChatFontNormal or GameFontHighlightSmall)
        eb:SetWidth(580)
        eb:SetScript("OnEscapePressed", function() reportWin:Hide() end)
        eb:SetScript("OnTextChanged", function(self, user)
            if user then self:SetText(reportWin.text or "") end      -- read only
        end)
        sf:SetScrollChild(eb)
        reportWin.eb = eb

        local sel = CreateFrame("Button", nil, reportWin, "UIPanelButtonTemplate")
        sel:SetSize(160, 22)
        sel:SetPoint("BOTTOMLEFT", 16, 14)
        sel:SetText(L.AT_SELECT_ALL)
        sel:SetScript("OnClick", function() eb:SetFocus(); eb:HighlightText() end)
        local again = CreateFrame("Button", nil, reportWin, "UIPanelButtonTemplate")
        again:SetSize(160, 22)
        again:SetPoint("LEFT", sel, "RIGHT", 10, 0)
        again:SetText(L.AT_RUN_AGAIN)
        again:SetScript("OnClick", function()
            reportWin:Hide()
            if ns.TestRoutine then ns.TestRoutine:Command("") end
        end)
        local close = CreateFrame("Button", nil, reportWin, "UIPanelButtonTemplate")
        close:SetSize(120, 22)
        close:SetPoint("BOTTOMRIGHT", -16, 14)
        close:SetText(CLOSE or "Close")
        close:SetScript("OnClick", function() reportWin:Hide() end)
    end
    reportWin:SetTitle(title or L.TR_REPORT_TITLE)
    reportWin.hint:SetText(hint or L.TR_REPORT_HINT)
    reportWin.text = text
    reportWin.eb:SetText(text)
    reportWin.eb:SetCursorPosition(0)
    reportWin:Show()
    reportWin.eb:SetFocus()
    reportWin.eb:HighlightText()
end

---------------------------------------------------------------------------
-- Commands
---------------------------------------------------------------------------
function AT:IsRunning() return ns.TestRoutine and ns.TestRoutine:IsRunning() or false end

function AT:ShowLast()
    local db = ns.db
    local text = db and type(db.autotest) == "table" and type(db.autotest.last) == "string" and db.autotest.last or nil
    AT.ShowReport(text, L.TR_REPORT_TITLE, L.TR_REPORT_HINT)
end

function AT:History()
    local db = ns.db
    local h = db and type(db.autotest) == "table" and type(db.autotest.history) == "table" and db.autotest.history or nil
    if not h or #h == 0 then ns.Print(L.TR_NO_REPORT); return end
    for i, e in ipairs(h) do
        if i > HISTORY then break end
        if type(e) == "table" then
            ns.Print(string.format("%d. %s · %s %s · %s · %d/%d OK · %d Lua-Fehler · %.1f s", i, tostring(e.date), tostring(e.version),
                tostring(e.flavor), tostring(e.verdict), tonumber(e.ok) or 0, (tonumber(e.ok) or 0) + (tonumber(e.fail) or 0),
                tonumber(e.errors) or 0, tonumber(e.secs) or 0))
        end
    end
end

-- /ps autotest [stop | bericht | verlauf]
function AT:Command(arg)
    arg = (arg or ""):lower()
    if arg == "bericht" or arg == "report" then self:ShowLast()
    elseif arg == "verlauf" or arg == "history" then self:History()
    elseif ns.TestRoutine then
        ns.TestRoutine:Command(arg == "stop" and "stop" or "")
    end
end
