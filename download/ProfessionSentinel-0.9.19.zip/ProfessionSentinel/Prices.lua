local _, ns = ...
local L = ns.L

-- Prices for the gold ranking.
--   Reagents:  sold by a vendor  -> the vendor price (fixed, from the game data)
--              everything else   -> the auction house value (also for farmed material: what you
--                                   could have sold it for)
--   Product:   the higher of auction house value minus the 5 % AH cut and vendor sell value
--              (× items per craft)
--   Disenchanting (Disenchant.lua, only with withDE = true – the enchanter tab): expected
--              material value minus the 5 % AH cut, as a separate value. The other professions'
--              rankings never count disenchanting.
-- AH values come from AHSentinel (GoldSentinel), otherwise TSM, otherwise Auctionator.
-- ns.Items[id] = { name, quality, vendorSell, vendorBuyPerPiece (0 = no vendor), farmable }

local P = {}
ns.Prices = P

-- Auction house cut: 5 % of the sale price is kept by the auction house
P.AH_CUT = 0.05

-- Listing fee (deposit): WoW Forever charges at least 1 silver per auction and does NOT refund it,
-- not even when the item sells. Classic formula: 15 % of the vendor sell value of the auction (12 h),
-- at least 1 silver. Other game versions refund the deposit on a sale – not counted there.
-- Fee per piece = fee of one full auction (a full stack, or 1 piece if the item does not stack) / pieces.
P.MIN_FEE = 100
P.FEE_RATE = 0.15

function P.FeeApplies()
    return ns.IsForever == true
end

local function StackSize(itemID)
    -- old global first (exactly as before), C_Item.GetItemInfo in the modern client
    local ok, _, _, _, _, _, _, _, stack = pcall(ns.ItemInfo, itemID)
    if ok and type(stack) == "number" and stack > 0 then return stack end
    return 1
end

function P.FeePerPiece(itemID)
    if not P.FeeApplies() or not itemID then return 0 end
    local perAuction = StackSize(itemID)
    local vs = P.VendorSell(itemID) or 0
    local fee = math.max(P.MIN_FEE, math.floor(vs * perAuction * P.FEE_RATE))
    return fee / perAuction
end

---------------------------------------------------------------------------
-- Auction house value (copper) and which addon delivered it
---------------------------------------------------------------------------
function P.AH(itemID)
    if ns.Sim and ns.Sim.prices then
        local v = ns.Sim.prices[itemID]
        if v then return v, "Test" end
    end
    local A = _G.AHAnalyzerPro
    if A and A.GetMarketValue then
        local ok, v = pcall(A.GetMarketValue, A, itemID)
        if not ok then ns.CountError("AHSentinel:GetMarketValue", v) end
        if ok and type(v) == "number" and v > 0 then return v, "AHSentinel" end
    end
    if _G.TSM_API and TSM_API.GetCustomPriceValue then
        local ok, v = pcall(TSM_API.GetCustomPriceValue, "dbmarket", "i:" .. itemID)
        if not ok then ns.CountError("TSM", v) end
        if ok and type(v) == "number" and v > 0 then return v, "TSM" end
    end
    local AU = _G.Auctionator
    if AU and AU.API and AU.API.v1 and AU.API.v1.GetAuctionPriceByItemID then
        local ok, v = pcall(AU.API.v1.GetAuctionPriceByItemID, "ProfessionSentinel", itemID)
        if not ok then ns.CountError("Auctionator", v) end
        if ok and type(v) == "number" and v > 0 then return v, "Auctionator" end
    end
    return nil
end

function P.SourceName()
    if ns.Sim and ns.Sim.prices then return "Test" end
    if _G.AHAnalyzerPro and _G.AHAnalyzerPro.GetMarketValue then return "AHSentinel" end
    if _G.TSM_API and TSM_API.GetCustomPriceValue then return "TSM" end
    local AU = _G.Auctionator
    if AU and AU.API and AU.API.v1 then return "Auctionator" end
    return nil
end

function P.VendorBuy(itemID)
    local d = ns.Items[itemID]
    if d and d[4] and d[4] > 0 then return d[4] end
    -- AHSentinel reads what a vendor asks while you visit it (also new Retail vendor goods)
    local A = _G.AHAnalyzerPro
    if A and A.GetVendorBuyPrice then
        local ok, v = pcall(A.GetVendorBuyPrice, A, itemID)
        if not ok then ns.CountError("AHSentinel:GetVendorBuyPrice", v) end
        if ok and type(v) == "number" and v > 0 then return v end
    end
    return nil
end

function P.VendorSell(itemID)
    local d = ns.Items[itemID]
    local v = d and d[3]
    if not v or v == 0 then
        local ok, _, _, _, _, _, _, _, _, _, _, sell = pcall(ns.ItemInfo, itemID)
        if ok and type(sell) == "number" and sell > 0 then v = sell end
    end
    return v and v > 0 and v or nil
end

function P.IsFarmable(itemID)
    local d = ns.Items[itemID]
    return d and d[5] == 1 or false
end

---------------------------------------------------------------------------
-- Cost of one reagent: (copper per piece, origin "vendor" | "ah" | "farm", known)
---------------------------------------------------------------------------
function P.ReagentUnit(itemID)
    local vb = P.VendorBuy(itemID)
    if vb then return vb, "vendor", true end
    local ah = P.AH(itemID)
    local origin = P.IsFarmable(itemID) and "farm" or "ah"
    if ah then return ah, origin, true end
    return 0, origin, false
end

-- Full calculation for a recipe. Returns a table:
--   cost, value, net (per craft, copper), known (all prices found), parts = { {id, count, unit, origin, known} },
--   origins = { vendor = true, ah = true, farm = true }, valueSource "ah" | "vendor" | nil
function P.Recipe(r, withDE)
    local res = { cost = 0, value = 0, known = true, parts = {}, origins = {} }
    for i = 1, #(r.reagents or {}), 2 do
        local id, n = r.reagents[i], r.reagents[i + 1]
        local unit, origin, known = P.ReagentUnit(id)
        res.parts[#res.parts + 1] = { id = id, count = n, unit = unit, origin = origin, known = known }
        res.origins[origin] = true
        res.cost = res.cost + unit * n
        if not known then res.known = false end
    end
    if r.out then
        local count = ((r.outMin or 1) + (r.outMax or r.outMin or 1)) / 2
        local ah = P.AH(r.out)
        local vs = P.VendorSell(r.out)
        -- The auction house keeps 5 % of every sale: compare what actually lands in the mailbox
        local ahGross = ah and ah * count or nil
        local ahFee = ahGross and P.FeePerPiece(r.out) * count or 0
        local ahNet = ahGross and (ahGross * (1 - P.AH_CUT) - ahFee) or nil
        local vend = vs and vs * count or nil
        if ahNet and (not vend or ahNet >= vend) then
            res.value, res.valueSource = ahNet, "ah"
        elseif vend then
            res.value, res.valueSource = vend, "vendor"
        end
        res.valueAH, res.valueAHNet, res.valueVendor = ahGross, ahNet, vend
        res.ahCut = ahGross and ahGross * P.AH_CUT or nil
        res.ahFee = ahGross and ahFee > 0 and ahFee or nil
        -- Disenchanting (materials are sold in the AH as well: minus the 5 % cut)
        local DE = ns.Disenchant
        if DE and withDE then
            local gross, complete, yield, own, shared, src = DE.Value(r.out)
            if gross then
                res.deGross = gross * count
                -- listing fee for the materials (WoW Forever): expected pieces × fee per piece
                local deFee = 0
                for _, y in ipairs(yield or {}) do deFee = deFee + (y[2] or 0) * (y[3] or 0) * P.FeePerPiece(y[1]) end
                deFee = deFee * count
                res.deCut = res.deGross * P.AH_CUT
                res.deFee = deFee > 0 and deFee or nil
                res.deValue = res.deGross - res.deCut - deFee
                res.deComplete, res.deYield, res.deOwn, res.deShared, res.deSource = complete, yield, own, shared, src
            end
        end
    end
    -- net = selling the product (AH or vendor); deNet = disenchanting it and selling the materials
    res.net = res.value - res.cost
    if res.deValue then res.deNet = res.deValue - res.cost end
    -- best way to use the product
    if res.deNet and (res.value <= 0 or res.deNet > res.net) then
        res.bestNet, res.bestVia = res.deNet, "de"
    else
        res.bestNet, res.bestVia = res.net, res.valueSource
    end
    return res
end

---------------------------------------------------------------------------
-- Money text: "+10s 80c", "−2s", "1g 5s"
---------------------------------------------------------------------------
function P.Money(copper, signed)
    if not copper then return "?" end
    local neg = copper < 0
    copper = math.floor(math.abs(copper) + 0.5)
    local g, s, c = math.floor(copper / 10000), math.floor((copper % 10000) / 100), copper % 100
    local parts = {}
    if g > 0 then parts[#parts + 1] = "|cffffd100" .. g .. "g|r" end
    if s > 0 then parts[#parts + 1] = "|cffc7c7cf" .. s .. "s|r" end
    if c > 0 or #parts == 0 then parts[#parts + 1] = "|cffc87533" .. c .. "c|r" end
    local txt = table.concat(parts, " ")
    if signed then txt = (neg and "−" or "+") .. txt elseif neg then txt = "−" .. txt end
    return txt
end

-- Plain version without colour codes (for compact hints)
function P.MoneyPlain(copper, signed)
    if not copper then return "?" end
    local neg = copper < 0
    copper = math.floor(math.abs(copper) + 0.5)
    local g, s, c = math.floor(copper / 10000), math.floor((copper % 10000) / 100), copper % 100
    local parts = {}
    if g > 0 then parts[#parts + 1] = g .. "g" end
    if s > 0 then parts[#parts + 1] = s .. "s" end
    if c > 0 or #parts == 0 then parts[#parts + 1] = c .. "c" end
    local txt = table.concat(parts, " ")
    if signed then txt = (neg and "−" or "+") .. txt elseif neg then txt = "−" .. txt end
    return txt
end

P.ORIGIN_COLOR = { ah = "d9a400", vendor = "9a9aa8", farm = "3aa83a" }
