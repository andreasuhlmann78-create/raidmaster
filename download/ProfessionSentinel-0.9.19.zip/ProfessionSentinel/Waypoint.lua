local _, ns = ...
local L = ns.L

-- Locations and waypoints for NPCs (trainers, vendors, drop mobs).
-- ns.NPCs[id] = { name, zone, faction, title, level, uiMapID, x, y }
-- Waypoint order: TomTom (if installed) -> the game's own map pin (C_Map.SetUserWaypoint via ns.Act) -> chat output.

local WP = {}
ns.Waypoint = WP

-- Zone name in the client's language (falls back to the stored name)
function WP.ZoneName(n)
    if not n then return nil end
    local mapID = n[6]
    if mapID and C_Map and C_Map.GetMapInfo then
        local ok, info = pcall(C_Map.GetMapInfo, mapID)
        if ok and info and info.name and info.name ~= "" then return info.name end
    end
    return n[2]
end

function WP.Has(id)
    local n = ns.NPCs[id]
    return n and n[6] and n[7] and n[8] and true or false
end

-- "Zone 41.5, 42.6" (or just the zone, or nil)
function WP.LocationText(id)
    local n = ns.NPCs[id]
    if not n then return nil end
    local zone = WP.ZoneName(n)
    if n[7] and n[8] then
        return string.format("%s %.1f, %.1f", zone or "?", n[7], n[8])
    end
    return zone
end

-- Is the NPC friendly to the player's faction? (nil faction = hostile to both / unknown -> false)
function WP.IsFriendly(id)
    local n = ns.NPCs[id]
    local fac = n and n[3]
    if not fac then return false end
    local mine = UnitFactionGroup("player")
    local want = mine == "Horde" and "H" or "A"
    return fac:find(want, 1, true) ~= nil
end

function WP.Available()
    if TomTom and TomTom.AddWaypoint then return "TomTom" end
    if ns.CanAct("waypoint") then return "map" end
    return nil
end

-- Sets a waypoint to the NPC. Returns true when a waypoint was placed.
function WP.Set(id, label)
    if ns.BlockedInCombat() then return false end
    local n = ns.NPCs[id]
    if not n or not n[6] or not n[7] or not n[8] then
        ns.Print(L.WP_NO_COORDS)
        return false
    end
    local mapID, x, y = n[6], n[7] / 100, n[8] / 100
    local title = label or n[1]
    local where = WP.LocationText(id) or ""
    -- 1) TomTom
    if TomTom and TomTom.AddWaypoint then
        local ok, err = pcall(TomTom.AddWaypoint, TomTom, mapID, x, y, { title = title, persistent = false, minimap = true, world = true })
        if not ok then ns.CountError("TomTom", err) end
        if ok then
            ns.Print(string.format(L.WP_SET, title, where) .. " (TomTom)")
            return true
        end
    end
    -- 2) the game's own map pin
    if ns.CanAct("waypoint") then
        local can = true
        if ns.API.MapCanSetUserWaypointOnMap then
            local ok, res = pcall(ns.API.MapCanSetUserWaypointOnMap, mapID)
            can = ok and res
        end
        if can then
            local okP, set = pcall(ns.Act, "waypoint", mapID, x, y)     -- map pin + super tracking (ns.Act)
            if okP and set then
                ns.Print(string.format(L.WP_SET, title, where))
                return true
            end
        end
    end
    -- 3) chat only
    ns.Print(string.format(L.WP_CHAT, title, where))
    return false
end

-- Best NPC to walk to for a recipe: a friendly vendor first, then any vendor, then a drop mob.
function WP.BestSourceNPC(r)
    local anyVendor, drop
    for _, ri in ipairs(r.recipeItems or {}) do
        for _, id in ipairs(ri.v or {}) do
            if WP.Has(id) then
                if WP.IsFriendly(id) then return id, "vendor" end
                anyVendor = anyVendor or id
            end
        end
        if (ri.dn or 0) <= 15 then
            for _, id in ipairs(ri.d or {}) do
                if WP.Has(id) then drop = drop or id end
            end
        end
    end
    if anyVendor then return anyVendor, "vendor" end
    if drop then return drop, "drop" end
    return nil
end

-- Trainer ranks
WP.RANKS = {
    { key = 4, cap = 300, req = 200, level = 35 },
    { key = 3, cap = 225, req = 125, level = 20 },
    { key = 2, cap = 150, req = 50, level = 10 },
    { key = 1, cap = 75, req = 1, level = 5 },
    { key = 5 },
    { key = 0 },
}

-- Which rank does the player need next? Returns the rank table or nil (cap reached or unknown).
function WP.NextRank(rank, maxRank)
    if not rank or not maxRank or maxRank <= 0 then return nil end
    for i = #WP.RANKS, 1, -1 do
        local r = WP.RANKS[i]
        if r.cap and r.cap > maxRank then return r end
    end
    return nil
end
