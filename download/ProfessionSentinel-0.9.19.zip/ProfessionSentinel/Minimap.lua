local ADDON, ns = ...
local L = ns.L

-- Button at the minimap (like every GoldSentinel addon, built after shared/vorlage/__ADDON__/Minimap.lua):
--   left-click  = open or close the panel, exactly like /ps (ns.UI:Toggle)
--   right-click = options: ProfessionSentinel has no options window, its options are switched with /ps commands;
--                 the right-click lists every option with its state and its command in the chat
--   drag        = move it around the minimap; the angle is saved per account (ProfessionSentinelDB.minimapAngle)
-- /ps minimap shows or hides it (ProfessionSentinelDB.minimapButton, on by default).
-- No library (no LibDBIcon), works in every client. The button is not a protected frame: showing, hiding and
-- moving it is fine in combat too. The cursor is read through ns.API (the test routine simulates a drag there).

local M = {}
ns.Minimap = M

M.NAME = ADDON .. "MinimapButton"
M.ICON = "Interface\\Icons\\INV_Misc_Book_11"   -- the addon's icon (IconTexture in the .toc files)
M.SIZE = 31
M.RADIUS_EXTRA = 6                               -- distance from the minimap's edge to the button's centre

local btn

local function Map() return _G.Minimap end

-- saved angle; anything that is not a usable number gives the default (ns.InitDB repairs the file itself)
function M.Angle()
    local a = ns.db and ns.db.minimapAngle
    if type(a) ~= "number" or a ~= a or a >= math.huge or a <= -math.huge then return ns.DEFAULTS.minimapAngle end
    return a
end

function M.IsEnabled()
    return not (ns.db and ns.db.minimapButton == false)
end

-- offset of the button's centre from the minimap's centre for an angle in degrees
function M.Offset(angle, map)
    map = map or Map()
    local w = map and map.GetWidth and tonumber((map:GetWidth())) or nil
    local radius = (w and w > 0 and w or 140) / 2 + M.RADIUS_EXTRA
    local rad = math.rad(angle)
    return math.cos(rad) * radius, math.sin(rad) * radius
end

-- angle in degrees (0 … 360) of a cursor position (screen coordinates as GetCursorPosition returns them)
function M.AngleFromCursor(cx, cy)
    local map = Map()
    if not map then return M.Angle() end
    local mx, my = map:GetCenter()
    mx, my = tonumber(mx) or 0, tonumber(my) or 0
    local scale = tonumber((map:GetEffectiveScale())) or 1
    if scale <= 0 then scale = 1 end
    local dx, dy = (tonumber(cx) or 0) / scale - mx, (tonumber(cy) or 0) / scale - my
    if dx == 0 and dy == 0 then return M.Angle() end
    return math.deg(math.atan2(dy, dx)) % 360
end

-- position and visibility from the saved variables (also after /reload and after the test routine)
function M.Update()
    if not btn then return end
    local map = Map()
    if not map or not M.IsEnabled() then btn:Hide() return end
    local x, y = M.Offset(M.Angle(), map)
    btn:ClearAllPoints()
    btn:SetPoint("CENTER", map, "CENTER", x, y)
    btn:Show()
end
ns.UpdateMinimapButton = M.Update

local function StateText(on)
    return on and ("|cff40c040" .. L.ON .. "|r") or ("|cff808080" .. L.OFF .. "|r")
end

-- /ps minimap: show or hide the button
function M.Toggle()
    if not ns.db then return end
    ns.db.minimapButton = not M.IsEnabled()
    M.Update()
    ns.Print(ns.db.minimapButton and L.MINIMAP_SHOWN or L.MINIMAP_HIDDEN)
end

-- the options of ProfessionSentinel: label, state, command
function M.OptionList()
    local db = ns.db or {}
    local list = {
        { L.LL_OPTION, db.lifeline ~= false, "/ps line" },
        { L.ALERT_OPTION, db.recipeAlert ~= false, "/ps alarm" },
    }
    if ns.Favor and ns.Favor.Active and ns.Favor.Active() then
        list[#list + 1] = { L.FAVOR_TODAY_OPTION, db.todayCrates == true, "/ps kisten" }
    end
    list[#list + 1] = { L.MINIMAP_OPTION, M.IsEnabled(), "/ps minimap" }
    return list
end

-- right-click: every option with its state and the command that switches it
function M.ShowOptions()
    ns.Print(L.OPTIONS_HEAD)
    for _, o in ipairs(M.OptionList()) do
        ns.Print(string.format(L.OPTIONS_LINE, o[1], StateText(o[2]), o[3]))
    end
end

-- left-click: the same as /ps
function M.LeftClick()
    if not ns.Flavor then
        ns.Print(string.format(L.UNSUPPORTED, ns.Interface or 0))
        return
    end
    if ns.UI then ns.UI:Toggle() end
end

function M.OnClick(_, button)
    if button == "RightButton" then M.ShowOptions() else M.LeftClick() end
end

function M.ShowTooltip(owner)
    if not GameTooltip then return end
    GameTooltip:SetOwner(owner or UIParent, "ANCHOR_LEFT")
    GameTooltip:AddLine(L.TITLE, 0.25, 0.78, 0.92)
    GameTooltip:AddLine(L.MINIMAP_LEFT, 1, 1, 1)
    GameTooltip:AddLine(L.MINIMAP_RIGHT, 1, 1, 1)
    GameTooltip:AddLine(L.MINIMAP_DRAG, 0.7, 0.7, 0.7)
    GameTooltip:Show()
end

-- while dragging: follow the cursor
local function DragUpdate()
    local get = ns.API.GetCursorPosition
    if not get or not ns.db then return end
    local cx, cy = get()
    ns.db.minimapAngle = M.AngleFromCursor(cx, cy)
    M.Update()
end
M.DragUpdate = DragUpdate

local function Build()
    if btn then M.Update() return btn end
    local map = Map()
    if not map or not ns.Flavor or not ns.db then return nil end
    btn = CreateFrame("Button", M.NAME, map)
    btn:SetSize(M.SIZE, M.SIZE)
    btn:SetFrameStrata("MEDIUM")
    btn:SetFrameLevel(8)
    btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    btn:RegisterForDrag("LeftButton")
    btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    local icon = btn:CreateTexture(nil, "BACKGROUND")
    icon:SetTexture(M.ICON)
    icon:SetSize(20, 20)
    icon:SetPoint("TOPLEFT", 7, -6)
    icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    btn.icon = icon
    local border = btn:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT")
    btn.border = border

    btn:SetScript("OnClick", M.OnClick)
    btn:SetScript("OnDragStart", function(self)
        if GameTooltip then GameTooltip:Hide() end
        self:SetScript("OnUpdate", DragUpdate)
    end)
    btn:SetScript("OnDragStop", function(self)
        self:SetScript("OnUpdate", nil)
        M.Update()
    end)
    btn:SetScript("OnEnter", function(self) M.ShowTooltip(self) end)
    btn:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)

    M.button = btn
    M.Update()
    return btn
end
M.Build = Build

-- built at login (the saved variables are loaded then); unsupported game versions stay idle
local loader = ns.AddEventFrame(CreateFrame("Frame"), "Minimap")
loader:RegisterEvent("PLAYER_LOGIN")
loader:SetScript("OnEvent", function()
    if not ns.Flavor or not ns.db then return end
    ns.Try("Minimap-Button", Build)
end)
