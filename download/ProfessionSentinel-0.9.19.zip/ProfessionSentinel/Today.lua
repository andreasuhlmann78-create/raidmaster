local _, ns = ...
local L = ns.L

-- "Heute herstellen": the most profitable crafts of all your professions right now – and per row
-- always the next step, one click each:
--   1. buy missing vendor reagents (vendor open)        -> buys exactly what is missing
--   2. buy missing AH reagents                          -> AHSentinel quick buy (or its sniper)
--   3. open the profession window                       -> hint (WoW does not let addons open it)
--   4. craft                                            -> crafts the count in the open window
--   5. list the products                                -> AHSentinel's sell tab with the item
-- Count per recipe: at most TODAY_MAX, and the reagents of one row at most 20 % of your gold
-- (the same capital protection as AHSentinel's "Heute tun").
-- Public API for AHSentinel ("Heute tun"): ProfessionSentinelAPI.TodayCrafts(max)

local TD = {}
ns.Today = TD

TD.MAX_ROWS = 6
TD.TODAY_MAX = 5
TD.ITEM_SHARE = 0.20

local function Money() return GetMoney and GetMoney() or 0 end

local function BagCount(id) return ns.GetItemCount(id, false) end

-- Which profession window is open right now (data profession id) – nil if none
function TD.OpenProfession()
    local shown = (ns.Sim and ns.Sim.prof) or (ProfessionsFrame and ProfessionsFrame:IsShown())
        or (TradeSkillFrame and TradeSkillFrame:IsShown())
    if not shown then return nil end
    local UI = ns.UI
    if UI and UI.CurrentProfession then
        local ok, prof = pcall(UI.CurrentProfession, UI)
        if ok and prof then return prof end
    end
    return nil
end

-- candidates: learned recipes of all your professions with a product, priced, net > 0 per craft,
-- the product sold in the AH; best total gain first
function TD.Candidates(countFn)
    local AD, P = ns.Advisor, ns.Prices
    if not (AD and P and P.SourceName()) then return {} end
    local out = {}
    local money = Money()
    local seen = {}
    local profs = {}
    for _, p in ipairs(ns.Scan and ns.Scan:PlayerProfessions() or {}) do profs[#profs + 1] = p.id end
    if ns.Sim and ns.Sim.prof then profs[#profs + 1] = ns.Sim.prof end
    for _, prof in ipairs(profs) do
        if not seen[prof] then
            seen[prof] = true
            local rank = ns.Scan:Rank(prof)
            if ns.EffectiveRank then rank = ns.EffectiveRank(rank) end
            for _, r in ipairs(ns.ByProf[prof] or {}) do
                if r.out and ns.IsLearned(r) and (rank == nil or AD.Reachable(r, rank)) then
                    local pr = P.Recipe(r)
                    if pr.known and pr.net > 0 and pr.valueSource == "ah" and pr.cost > 0 then
                        local count = TD.TODAY_MAX
                        if money > 0 then count = math.min(count, math.floor(money * TD.ITEM_SHARE / pr.cost)) end
                        if count >= 1 then
                            out[#out + 1] = { recipe = r, price = pr, count = count, net = pr.net * count, perCraft = pr.net }
                        end
                    end
                end
            end
        end
    end
    table.sort(out, function(a, b) return a.net > b.net end)
    for i = #out, TD.MAX_ROWS + 1, -1 do out[i] = nil end
    for _, e in ipairs(out) do TD.Plan(e, countFn) end
    return out
end

-- what is missing for the count, and the next step
function TD.Plan(e, countFn)
    countFn = countFn or BagCount
    local r, P = e.recipe, ns.Prices
    e.missing, e.missingVendor, e.missingAH = {}, 0, 0
    for i = 1, #r.reagents, 2 do
        local id, n = r.reagents[i], r.reagents[i + 1]
        local need = n * e.count - (countFn(id) or 0)
        if need > 0 then
            local unit, origin = P.ReagentUnit(id)
            e.missing[#e.missing + 1] = { id = id, count = need, origin = origin, unit = unit }
            if origin == "vendor" then e.missingVendor = e.missingVendor + 1 else e.missingAH = e.missingAH + 1 end
        end
    end
    e.have = r.out and (countFn(r.out) or 0) or 0
    local merchant = ns.Plan and ns.Plan.MerchantOpen()
    if e.have >= e.count or (e.have > 0 and #e.missing > 0) then
        -- the batch is crafted (or products from earlier crafts are waiting): list them first
        e.step = "sell"
    elseif e.missingVendor > 0 and merchant then
        e.step = "vendor"
    elseif e.missingAH > 0 then
        e.step = "ah"
    elseif e.missingVendor > 0 then
        e.step = "goVendor"
    elseif TD.OpenProfession() == r.prof then
        e.step = "craft"
    elseif e.have > 0 then
        e.step = "sell"
    else
        e.step = "openProf"
    end
    return e
end

function TD.StepText(e)
    local P = ns.Prices
    if e.step == "vendor" then
        local sum = 0
        for _, m in ipairs(e.missing) do if m.origin == "vendor" then sum = sum + m.unit * m.count end end
        return string.format(L.TODAY_STEP_VENDOR, P.MoneyPlain(sum))
    elseif e.step == "ah" then
        local sum = 0
        for _, m in ipairs(e.missing) do if m.origin ~= "vendor" then sum = sum + m.unit * m.count end end
        return string.format(L.TODAY_STEP_AH, e.missingAH, P.MoneyPlain(sum))
    elseif e.step == "goVendor" then
        return L.TODAY_STEP_GOVENDOR
    elseif e.step == "craft" then
        return string.format(L.TODAY_STEP_CRAFT, e.count)
    elseif e.step == "sell" then
        return string.format(L.TODAY_STEP_SELL, e.have)
    end
    return string.format(L.TODAY_STEP_OPENPROF, ns.ProfName(e.recipe.prof))
end

---------------------------------------------------------------------------
-- Actions
---------------------------------------------------------------------------
local function AHS() return _G.AHAnalyzerPro end

-- buy the missing vendor reagents of one row at the open vendor
function TD.BuyVendor(e)
    local PL = ns.Plan
    if not (PL and PL.MerchantOpen()) then ns.Print(L.PLAN_NO_MERCHANT); return false end
    local saved = PL.current
    local list = {}
    for _, m in ipairs(e.missing) do
        if m.origin == "vendor" then list[#list + 1] = { id = m.id, missing = m.count, origin = "vendor" } end
    end
    PL.current = { list = list }
    local n = PL.BuyFromVendor()
    PL.current = saved
    return n > 0
end

-- AH reagents: AHSentinel's quick buy (search + one click per purchase, never above max price);
-- older AHSentinel: its sniper with market value + 10 %
function TD.BuyAH(e)
    local A = AHS()
    local Q = A and A.Today and A.Today.QuickBuy
    local done = 0
    for _, m in ipairs(e.missing) do
        if m.origin ~= "vendor" and m.unit and m.unit > 0 then
            local maxPrice = math.floor(m.unit * 1.10)
            if Q then
                local ok, err = pcall(Q, A.Today, m.id, m.count, maxPrice, ns.RecipeName(e.recipe))
                if ok then done = done + 1 else ns.CountError("AHSentinel:Today.QuickBuy", err) end
            end
        end
    end
    if done > 0 then return true end
    -- fallback: sniper targets
    local targets = {}
    for _, m in ipairs(e.missing) do
        if m.origin ~= "vendor" and m.unit and m.unit > 0 then
            targets[#targets + 1] = { id = m.id, maxPrice = math.floor(m.unit * 1.10), qty = m.count }
        end
    end
    if #targets == 0 then return false end
    return ns.Disenchant.SendToSniper(targets, ns.RecipeName(e.recipe), L.PLAN_SNIPE_DONE) > 0
end

-- craft in the open profession window
function TD.Craft(e)
    local r = e.recipe
    if TD.OpenProfession() ~= r.prof then ns.Print(string.format(L.TODAY_STEP_OPENPROF, ns.ProfName(r.prof))); return false end
    if ns.UsesModernProfessions and ns.CanAct("craft") then
        return ns.Act("craft", r.spell, e.count) and true or false
    end
    local wanted = { [r.name:lower()] = true }
    if r.nameEN and r.nameEN ~= "" then wanted[r.nameEN:lower()] = true end
    local A = ns.API
    if A.GetNumTradeSkills and A.GetTradeSkillInfo and ns.CanAct("tradeskill") then
        for i = 1, A.GetNumTradeSkills() do
            local name = A.GetTradeSkillInfo(i)
            if name and wanted[name:lower()] then
                return ns.Act("tradeskill", i, e.count) and true or false
            end
        end
    end
    ns.Print(L.TODAY_NOT_FOUND)
    return false
end

-- list the products: AHSentinel's quick sell, otherwise its sell tab with the item selected
function TD.Sell(e)
    local A = AHS()
    local id = e.recipe.out
    if A and A.Today and A.Today.QuickSell then
        local ok, err = pcall(A.Today.QuickSell, A.Today, id, e.have)
        if ok then return true end
        ns.CountError("AHSentinel:Today.QuickSell", err)
    end
    if A and A.UI and A.UI.SelectTab then
        local function try(where, fn, ...)
            local ok, r = pcall(fn, ...)
            if not ok then ns.CountError(where, r) end
            return ok and r or nil
        end
        if A.UI.Show then try("AHSentinel:UI.Show", A.UI.Show, A.UI) end
        try("AHSentinel:UI.SelectTab", A.UI.SelectTab, A.UI, "sell")
        local tab = A.UI.GetTab and try("AHSentinel:UI.GetTab", A.UI.GetTab, A.UI, "sell")
        if type(tab) == "table" and type(tab.panel) == "table" and tab.panel.Select then
            try("AHSentinel:UI.Select", tab.panel.Select, tab.panel, id)
        end
        return true
    end
    ns.Print(L.TODAY_NEED_AHS)
    return false
end

-- one click: the next step of a row
function TD.Run(e)
    if ns.BlockedInCombat() then return false end
    TD.Plan(e)
    local ok
    if e.step == "vendor" then ok = TD.BuyVendor(e)
    elseif e.step == "ah" then ok = TD.BuyAH(e)
    elseif e.step == "craft" then ok = TD.Craft(e)
    elseif e.step == "sell" then ok = TD.Sell(e)
    elseif e.step == "goVendor" then ns.Print(L.TODAY_STEP_GOVENDOR)
    else ns.Print(string.format(L.TODAY_STEP_OPENPROF, ns.ProfName(e.recipe.prof))) end
    if C_Timer then C_Timer.After(1.5, function() if ns.RefreshAll then ns.RefreshAll() end end) end
    return ok
end

---------------------------------------------------------------------------
-- Public API for AHSentinel ("Heute tun") and other addons
--   ProfessionSentinelAPI.version = 1
--   ProfessionSentinelAPI.TodayCrafts(max) -> list of {
--       itemID, recipeName, count, gold (net for all crafts, after 5 % AH cut), perCraft, cost (reagents per craft),
--       capital (money needed for the missing reagents), step ("vendor"|"ah"|"goVendor"|"craft"|"sell"|"openProf"),
--       stepText, run = function() – does the next step }
---------------------------------------------------------------------------
_G.ProfessionSentinelAPI = _G.ProfessionSentinelAPI or {}
local API = _G.ProfessionSentinelAPI
API.version = 1
function API.TodayCrafts(max)
    local ok, list = pcall(TD.Candidates)
    if not ok then ns.CountError("API.TodayCrafts", list) end
    if not ok or type(list) ~= "table" then return {} end
    local out = {}
    for i, e in ipairs(list) do
        if max and i > max then break end
        local capital = 0
        for _, m in ipairs(e.missing) do capital = capital + (m.unit or 0) * m.count end
        out[#out + 1] = {
            itemID = e.recipe.out, recipeName = ns.RecipeName(e.recipe), count = e.count,
            gold = math.floor(e.net), perCraft = math.floor(e.perCraft), cost = math.floor(e.price.cost),
            capital = math.floor(capital), step = e.step, stepText = TD.StepText(e),
            run = function() return TD.Run(e) end,
        }
    end
    return out
end
