-- ThreatSentinel - DamageMeter.lua
-- Schadensmeter (für DDs) und Heilmeter (für Heiler): Rangliste der Gruppe, aus dem Kampflog.
-- Begleiter (Pets) zählen zu ihrem Besitzer. Überheilung zählt nicht.
-- Linksklick auf den Titel: aktueller Kampf / Gesamt. Rechtsklick: zurücksetzen.
-- Clients ohne Kampflog (WoW Forever, Retail) zeigen keinen Meter.

local ADDON, ns = ...
local L = ns.L

local DM = {}
ns.DmgMeter = DM
table.insert(ns.modules, DM)

local WHITE = "Interface\\Buttons\\WHITE8X8"
local BAR_TEX = "Interface\\TargetingFrame\\UI-StatusBar"
local ROW_H = 16
local SEG_GAP = 4          -- Sekunden ohne Ereignis (und man selbst ausser Kampf), bis ein neuer Kampf beginnt

local AFFIL_MINE, AFFIL_PARTY, AFFIL_RAID = 0x1, 0x2, 0x4
local TYPE_PLAYER, TYPE_PET, TYPE_GUARDIAN = 0x400, 0x1000, 0x2000
local REACT_HOSTILE, REACT_NEUTRAL = 0x40, 0x20

DM.allowed = not ns.isModern          -- Kampflog: nur alte API (GoldSentinelGame.IsModern)
DM.total = { dmg = {}, heal = {}, time = 0 }
DM.cur = nil               -- aktueller / letzter Kampf: { start, last, dmg = {}, heal = {} }
DM.showTotal = false
DM.petOwner = {}           -- GUID eines Begleiters -> Name des Besitzers (aus der Gruppe)
DM.summonOwner = {}        -- GUID eines beschworenen Wesens (Totem, Höllenbestie ...) -> Besitzer
DM.classOf = {}            -- Name -> Klasse

local band = bit and bit.band or function(a, b)
	local r, p = 0, 1
	while a > 0 and b > 0 do
		if a % 2 == 1 and b % 2 == 1 then r = r + p end
		a, b, p = math.floor(a / 2), math.floor(b / 2), p * 2
	end
	return r
end

------------------------------------------------------------
-- Gruppe: Begleiter ihren Besitzern zuordnen
------------------------------------------------------------
function DM:UpdateOwners()
	wipe(self.petOwner)
	local function map(pet, owner)
		local g = UnitGUID(pet)
		local n = ns:FullName(owner)
		if g and n and not ns.IsSecret(g) then self.petOwner[g] = n end
	end
	map("pet", "player")
	if IsInRaid() then
		for i = 1, GetNumGroupMembers() do map("raidpet" .. i, "raid" .. i) end
	else
		for i = 1, GetNumSubgroupMembers() do map("partypet" .. i, "party" .. i) end
	end
	for _, u in ipairs(ns.groupUnits or {}) do
		if UnitIsPlayer(u) then
			local n = ns:FullName(u)
			if n then self.classOf[n] = select(2, UnitClass(u)) end
		end
	end
end

------------------------------------------------------------
-- Kampflog
------------------------------------------------------------
local function SourceName(guid, name, flags)
	if band(flags, AFFIL_MINE + AFFIL_PARTY + AFFIL_RAID) == 0 then return nil end
	if band(flags, TYPE_PLAYER) > 0 then
		-- Spielernamen im Kampflog können den Realm enthalten
		return name
	end
	if band(flags, TYPE_PET + TYPE_GUARDIAN) > 0 then
		local owner = DM.petOwner[guid] or DM.summonOwner[guid]
		if owner then return owner end
		if band(flags, AFFIL_MINE) > 0 then return ns.playerName end
	end
	return nil
end

-- Kampfzeit eines Abschnitts in die Gesamtzeit übernehmen (nur den noch nicht gezählten Teil)
local function Account(s)
	if not s then return end
	local d = math.max(0, s.last - s.start)
	DM.total.time = DM.total.time + d - (s.counted or 0)
	s.counted = d
end

local function NewSegment(now)
	Account(DM.cur)
	DM.cur = { start = now, last = now, dmg = {}, heal = {} }
	DM:UpdateOwners()
	return DM.cur
end

local function Segment(now)
	local s = DM.cur
	if not s or ((s.ended or not UnitAffectingCombat("player")) and now - s.last > SEG_GAP) then
		s = NewSegment(now)
	end
	return s
end

local function Add(kind, who, amount, now)
	if not who or not amount or amount <= 0 then return end
	local s = Segment(now)
	s[kind][who] = (s[kind][who] or 0) + amount
	-- nach dem Kampfende (DoT, letzter Schlag des Pets) zählt der Wert, verlängert den Kampf aber nicht
	if not s.ended then s.last = now end
	DM.total[kind][who] = (DM.total[kind][who] or 0) + amount
end

local DAMAGE = { SPELL_DAMAGE = true, SPELL_PERIODIC_DAMAGE = true, RANGE_DAMAGE = true, DAMAGE_SHIELD = true, DAMAGE_SPLIT = true }
local HEAL = { SPELL_HEAL = true, SPELL_PERIODIC_HEAL = true }

function DM:OnCombatLog()
	if not ns.db or not ns.db.dmgMeter then return end
	local _, sub, _, srcGUID, srcName, srcFlags, _, dstGUID, _, dstFlags, _, a12, _, _, a15, a16 = CombatLogGetCurrentEventInfo()
	if not srcFlags or ns.IsSecret(srcGUID, "combatlog") then return end
	local now = GetTime()
	if sub == "SPELL_SUMMON" then
		-- Totems, Höllenbestie, Ingenieurs-Helfer: dem Beschwörer zuordnen
		local owner = SourceName(srcGUID, srcName, srcFlags)
		if owner and dstGUID then DM.summonOwner[dstGUID] = owner end
	elseif sub == "SWING_DAMAGE" then
		if band(dstFlags or 0, REACT_HOSTILE + REACT_NEUTRAL) == 0 then return end
		Add("dmg", SourceName(srcGUID, srcName, srcFlags), a12, now)
	elseif DAMAGE[sub] then
		if band(dstFlags or 0, REACT_HOSTILE + REACT_NEUTRAL) == 0 then return end
		Add("dmg", SourceName(srcGUID, srcName, srcFlags), a15, now)
	elseif HEAL[sub] then
		local eff = (a15 or 0) - math.max(0, a16 or 0)
		Add("heal", SourceName(srcGUID, srcName, srcFlags), eff, now)
	end
end

if DM.allowed then
	ns:On("COMBAT_LOG_EVENT_UNFILTERED", function() DM:OnCombatLog() end)
end

ns:On("PLAYER_REGEN_DISABLED", function()
	-- neuer Kampf, ausser der letzte läuft noch (Gruppe kämpft schon, man selbst kommt dazu)
	local s, now = DM.cur, GetTime()
	if not s or s.ended or now - s.last > SEG_GAP then NewSegment(now) else DM:UpdateOwners() end
end)
ns:On("GROUP_ROSTER_UPDATE", function() DM:UpdateOwners() end)
ns:On("UNIT_PET", function() DM:UpdateOwners() end)
ns:On("PLAYER_REGEN_ENABLED", function()
	local s = DM.cur
	if s and not s.ended then
		s.ended = true
		Account(s)
	end
end)

function DM:Reset()
	wipe(self.total.dmg); wipe(self.total.heal)
	self.total.time = 0
	self.cur = nil
	wipe(self.summonOwner)
end

------------------------------------------------------------
-- Anzeige
------------------------------------------------------------
-- Was zeigt diese Figur? "dmg" (DD), "heal" (Heiler) oder nil
function DM:Kind()
	local db = ns.db
	if not db or not db.enabled or not db.dmgMeter then return nil end
	local role = ns:MyRole()
	if role == "HEALER" then return "heal" end
	if role == "TANK" then return db.dmgMeterTank and "dmg" or nil end
	return "dmg"
end

function DM:Init()
	local f = CreateFrame("Frame", "ThreatSentinelDmgMeter", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	f:SetSize(ns.db.dmgWidth or 230, 26)
	if f.SetBackdrop then
		f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
		f:SetBackdropColor(0.03, 0.04, 0.06, 0.6)
		f:SetBackdropBorderColor(0.25, 0.65, 1, 0.5)
	end
	f:SetClampedToScreen(true)
	f:SetMovable(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", function(self) self:StartMoving() end)
	f:SetScript("OnDragStop", function(self)
		self:StopMovingOrSizing()
		ns.Mover:SavePoint(self, "dmgPoint")
	end)

	-- Titel ist klickbar (auch wenn das Fenster selbst durchklickbar ist)
	f.titleBtn = CreateFrame("Button", nil, f)
	f.titleBtn:SetPoint("TOPLEFT", 2, -2)
	f.titleBtn:SetPoint("TOPRIGHT", -2, -2)
	f.titleBtn:SetHeight(16)
	f.titleBtn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	f.titleBtn:SetScript("OnClick", function(_, mb)
		if ns.moveMode then return end
		if mb == "RightButton" then DM:Reset() else DM.showTotal = not DM.showTotal end
		DM:Tick()
	end)
	f.titleBtn:SetScript("OnEnter", function(s)
		GameTooltip:SetOwner(s, "ANCHOR_TOP")
		GameTooltip:AddLine(L.DM_TIP1, 1, 1, 1)
		GameTooltip:AddLine(L.DM_TIP2, 1, 1, 1)
		GameTooltip:Show()
	end)
	f.titleBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)

	f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	f.title:SetPoint("TOPLEFT", 6, -5)
	f.title:SetPoint("TOPRIGHT", -90, -5)
	f.title:SetJustifyH("LEFT")
	if f.title.SetWordWrap then f.title:SetWordWrap(false) end
	f.sum = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	f.sum:SetPoint("TOPRIGHT", -6, -5)
	f.sum:SetWidth(84)
	f.sum:SetJustifyH("RIGHT")

	f.rows = {}
	f:Hide()
	self.f = f
	ns.Mover:Attach(f, "dmg")
	self:ApplySettings()
	C_Timer.NewTicker(0.5, function()
		local ok, err = pcall(DM.Tick, DM)
		if not ok then ns:ReportError(err) end
	end)
end

function DM:Width()
	return math.max(160, math.min(400, ns.db.dmgWidth or 230))
end

function DM:LayoutRow(r)
	r:SetSize(self:Width() - 8, ROW_H - 2)
end

function DM:ApplySettings()
	local f, db = self.f, ns.db
	if not f then return end
	local p = db.dmgPoint
	f:ClearAllPoints()
	f:SetPoint(p[1], UIParent, p[3], p[4], p[5])
	f:SetWidth(self:Width())
	for _, r in ipairs(f.rows) do self:LayoutRow(r) end
	f:SetScale(db.dmgScale or 1)
	f:EnableMouse(ns:Unlocked())
	-- beim Verschieben gehört der Titel zum Fenster (ziehen, Rechtsklick = Grösse 100 %)
	f.titleBtn:EnableMouse(not ns.moveMode)
end

function DM:Row(i)
	local f = self.f
	local r = f.rows[i]
	if r then return r end
	r = CreateFrame("StatusBar", nil, f)
	r:SetPoint("TOPLEFT", 4, -20 - (i - 1) * ROW_H)
	r:SetStatusBarTexture(BAR_TEX)
	r:SetMinMaxValues(0, 1)
	r.bg = r:CreateTexture(nil, "BACKGROUND")
	r.bg:SetAllPoints()
	r.bg:SetTexture(WHITE)
	r.bg:SetVertexColor(1, 1, 1, 0.06)
	r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	r.name:SetPoint("LEFT", 4, 0)
	r.name:SetPoint("RIGHT", -90, 0)
	r.name:SetJustifyH("LEFT")
	if r.name.SetWordWrap then r.name:SetWordWrap(false) end
	r.value = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	r.value:SetPoint("RIGHT", -4, 0)
	self:LayoutRow(r)
	f.rows[i] = r
	return r
end

local function Short(n)
	if n >= 1e6 then return string.format("%.1fM", n / 1e6) end
	if n >= 1e4 then return string.format("%.0fk", n / 1e3) end
	if n >= 1e3 then return string.format("%.1fk", n / 1e3) end
	return tostring(math.floor(n + 0.5))
end

local function ClassColor(name)
	local class = DM.classOf[name] or DM.classOf[(name or ""):match("^[^-]+") or ""]
	local c = class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
	if c then return c.r, c.g, c.b end
	return 0.6, 0.6, 0.6
end

-- Beispielwerte (Verschieben / Testmodus)
local function Sample(kind)
	local me = ns.playerName or "Du"
	if kind == "heal" then
		return { { me, 18400 }, { "Anna", 15200 }, { "Grimbar", 2100 } }, 60
	end
	return { { "Torben", 42100 }, { me, 38800 }, { "Mira", 35500 }, { "Grimbar", 21000 }, { "Anna", 4200 } }, 60
end

function DM:Render(kind, list, seconds, label)
	local f, db = self.f, ns.db
	f.title:SetText(string.format(kind == "heal" and L.DM_HEAL or L.DM_DMG, label))
	local total, top = 0, 0
	for _, e in ipairs(list) do
		total = total + e[2]
		if e[2] > top then top = e[2] end
	end
	seconds = math.max(1, seconds or 1)
	f.sum:SetText(Short(total / seconds) .. (kind == "heal" and " HPS" or " DPS"))
	local n = math.min(#list, db.dmgRows or 6)
	-- du selbst immer sichtbar
	local shown = {}
	for i = 1, n do shown[i] = list[i] end
	local meIn = false
	for _, e in ipairs(shown) do if e[1] == ns.playerName then meIn = true end end
	if not meIn then
		for _, e in ipairs(list) do
			if e[1] == ns.playerName then shown[math.max(1, n)] = e break end
		end
	end
	for i, e in ipairs(shown) do
		local r = self:Row(i)
		local cr, cg, cb = ClassColor(e[1])
		r:SetStatusBarColor(cr, cg, cb, 0.85)
		r:SetValue(top > 0 and e[2] / top or 0)
		r.name:SetText((e[3] or i) .. ". " .. ((e[1] == ns.playerName) and ("> " .. e[1]) or e[1]))
		r.value:SetText(string.format("%s (%s)", Short(e[2]), Short(e[2] / seconds)))
		r:Show()
	end
	for i = #shown + 1, #f.rows do f.rows[i]:Hide() end
	f:SetHeight(24 + #shown * ROW_H)
	f:Show()
end

function DM:Tick()
	local f, db = self.f, ns.db
	if not f then return end
	local kind = self:Kind()

	if ns.moveMode or (ns.testMode and kind) then
		local list, secs = Sample(kind or "dmg")
		self:Render(kind or "dmg", list, secs, L.DM_FIGHT)
		return
	end
	if not kind or not self.allowed then f:Hide() return end
	if db.dmgMeterGroupOnly and not IsInGroup() then f:Hide() return end

	local src, secs, label
	if self.showTotal then
		src = self.total
		local cur = self.cur
		local open = 0
		if cur then
			local endT = cur.ended and cur.last or math.max(cur.last, GetTime())
			open = math.max(0, endT - cur.start - (cur.counted or 0))
		end
		secs = self.total.time + open
		label = L.DM_TOTAL
	else
		src = self.cur
		if not src then f:Hide() return end
		local endT = src.ended and src.last or math.max(src.last, GetTime())
		secs = math.max(1, endT - src.start)
		label = L.DM_FIGHT
	end
	local data = src and src[kind]
	if not data or not next(data) then f:Hide() return end
	local list = {}
	for who, v in pairs(data) do list[#list + 1] = { who, v } end
	table.sort(list, function(a, b) return a[2] > b[2] end)
	for i, e in ipairs(list) do e[3] = i end
	self:Render(kind, list, secs, label)
end
