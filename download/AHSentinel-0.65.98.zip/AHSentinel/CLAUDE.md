# Hinweise für Claude-Sitzungen (AHSentinel)

Massgeblich sind die Regeln in `raidmaster/CLAUDE.md` (Repo andreasuhlmann78-create/raidmaster). Kurz daraus:

## Regelmässig ins Repo schauen (Entscheid des Nutzers, 12. November 2026)

Aufträge der Prüf-Sitzung kommen über `raidmaster/auftraege/AHSentinel/`. Deshalb `git pull --rebase` im raidmaster-Repo
und `auftraege/AHSentinel/` prüfen (dazu `git log --oneline -5 -- auftraege/AHSentinel/`):
- bei jeder neuen Nachricht des Nutzers, bevor du antwortest oder etwas änderst,
- während längerer Arbeit spätestens alle 15 Minuten (zwischen zwei Arbeitsschritten),
- immer direkt vor jedem Push und jeder Veröffentlichung.

Ist etwas Neues da: laufende Arbeit fertig machen, dann den Auftrag lesen und dem Nutzer kurz melden.
Nur was in `auftraege/AHSentinel/offen-ahsentinel.txt` steht, gilt als Auftrag. `auftraege/` ändert nur die Prüf-Sitzung.
AHSentinel ändert und veröffentlicht nur EINE Sitzung (die AHSentinel-Sitzung des Nutzers).

Diese Datei gehört nicht ins Addon-ZIP.
