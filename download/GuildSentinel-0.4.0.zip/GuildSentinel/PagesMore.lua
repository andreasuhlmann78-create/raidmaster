-- GuildSentinel - PagesMore.lua
-- Weitere Seiten: Gruppensuche und Fortschritt (Leveling-Rennen, Raid-Zugänge).

local ADDON, ns = ...
local L = ns.L
local UI = ns.UI

local GREEN, GRAY, GOLD, ORANGE, RED = "|cff40d860", "|cff8a8f99", "|cffffd100", "|cffff9933", "|cffff5555"
local function Gray(t) return GRAY .. tostring(t) .. "|r" end
local function WhenShown(key, fn)
	return function(...) if UI:IsPageShown(key) then fn(...) end end
end

------------------------------------------------------------
-- Seite: Gruppensuche
------------------------------------------------------------
local Gp = { key = "group", order = 20, icon = "Interface\\Icons\\INV_Misc_GroupNeedMore" }
Gp.title = L["Gruppensuche"]
Gp.form = { act = "brd", scope = "guild", need = 4, roles = { tank = false, heal = true, dps = false } }
Gp.badge = function()
	local n = 0
	for _, s in ipairs(ns.Group:Open()) do if ns.Group:Fits(s) then n = n + 1 end end
	return n > 0 and (GREEN .. n .. "|r") or ""
end

function Gp.build(p)
	Gp.panel = p
	local G = ns.Group

	-- neue Suche
	local h = UI:Header(p, L["Neue Suche"])
	h:SetPoint("TOPLEFT", 0, 0)
	local act = UI:Dropdown(p, 260, function()
		local out = {}
		local lvl = UnitLevel("player")
		for _, a in ipairs(G.ACTIVITIES) do
			local range = a.min and string.format(" |cff8a8f99(%d–%d)|r", a.min, a.max) or ""
			local fit = (not a.min or (lvl >= a.min - 2 and lvl <= a.max + 2))
			out[#out + 1] = { value = a.key, text = (fit and "" or "|cff8a8f99") .. a.n .. (fit and "" or "|r") .. range }
		end
		return out
	end, function() return Gp.form.act end, function(v) Gp.form.act = v end)
	act:SetPoint("TOPLEFT", h, "BOTTOMLEFT", 0, -6)
	local scope = UI:Dropdown(p, 170, function()
		return { { value = "guild", text = L["nur Gilde"] }, { value = "server", text = L["ganzer Server"] } }
	end, function() return Gp.form.scope end, function(v) Gp.form.scope = v end)
	scope:SetPoint("LEFT", act, "RIGHT", 8, 0)
	local need = UI:Dropdown(p, 130, function()
		local out = {}
		for _, n in ipairs({ 1, 2, 3, 4, 9, 19, 39 }) do out[#out + 1] = { value = n, text = string.format(L["%d frei"], n) } end
		return out
	end, function() return Gp.form.need end, function(v) Gp.form.need = v end)
	need:SetPoint("LEFT", scope, "RIGHT", 8, 0)
	Gp.startBtn = UI:Button(p, L["Suche starten"], 170, 24, function()
		local f = Gp.form
		G:Post(f.act, f.roles, f.need, Gp.note:GetText(), f.scope)
		Gp.note:SetText("")
		Gp:Refresh()
	end, true)
	Gp.startBtn:SetPoint("LEFT", need, "RIGHT", 10, 0)

	local gl = UI:Label(p, L["Gesucht:"], "GameFontHighlight")
	gl:SetPoint("TOPLEFT", act, "BOTTOMLEFT", 0, -12)
	local x = gl
	for _, r in ipairs(G.ROLES) do
		local c = UI:Check(p, G:RoleName(r), function() return Gp.form.roles[r] end, function(v) Gp.form.roles[r] = v end)
		c:SetPoint("LEFT", x, "RIGHT", (x == gl) and 8 or 60, 0)
		x = c
	end
	Gp.note = UI:Edit(p, 330, 24, L["Notiz (optional), z. B. 'Quest: Vermächtnis von Kel'Thuzad'"], false, 120)
	Gp.note:SetPoint("LEFT", x, "RIGHT", 80, 0)

	-- eigene Suche
	Gp.mine = UI:Label(p, "", "GameFontHighlight")
	Gp.mine:SetPoint("TOPLEFT", gl, "BOTTOMLEFT", 0, -16)
	Gp.mine:SetWidth(600)
	Gp.closeBtn = UI:Button(p, L["Suche beenden"], 140, 24, function()
		local s = G:Mine()
		if s then G:Close(s.id) end
	end)
	Gp.closeBtn:SetPoint("TOPRIGHT", 0, -78)

	-- offene Suchen
	Gp.list = UI:List(p, {
		{ key = "by", title = L["Wer"], width = 150 },
		{ key = "act", title = L["Was"], width = 220 },
		{ key = "roles", title = L["Gesucht"], width = 130 },
		{ key = "where", title = L["Wo"], width = 90 },
		{ key = "note", title = L["Notiz"] },
	}, {
		key = function(s) return s.id end,
		render = function(s)
			local by = ns.Colored(s.by, s.c) .. Gray(" " .. (s.l or "?"))
			local mine = ns.Same(s.by, ns.Me())
			local fits = G:Fits(s)
			local actText = (fits and GREEN or "") .. G:ActivityName(s) .. (fits and "|r" or "")
			local where = s.scope == "server" and (ns.Same(s.gn, ns.GuildName()) and L["Gilde+Server"] or (s.gn and ("<" .. s.gn .. ">") or L["Server"])) or L["Gilde"]
			local roles = G:RolesText(s) .. Gray(" · " .. string.format(L["%d frei"], s.need or 1))
			local note = s.note or ""
			if s.myJoin then note = GREEN .. L["du kommst mit"] .. "|r " .. note end
			if mine then note = GOLD .. string.format(L["deine Suche · %d Meldungen"], #G:Joins(s)) .. "|r " .. note end
			return { by, actText, roles, Gray(where), note }
		end,
		onClick = function() Gp:UpdateButtons() end,
		onEnter = function(row, s)
			GameTooltip:SetOwner(row, "ANCHOR_CURSOR")
			GameTooltip:AddLine(G:ActivityName(s), 1, 1, 1)
			local min, max = G:Range(s)
			if min then GameTooltip:AddLine(string.format(L["Stufe %d–%d"], min, max), 0.8, 0.8, 0.8) end
			GameTooltip:AddLine(string.format(L["%s · seit %s · läuft bis %s"], s.by, ns.Ago(s.t), date("%H:%M", s.exp)), 0.7, 0.7, 0.7)
			GameTooltip:Show()
		end,
		empty = L["Gerade sucht niemand. Starte oben eine Suche – alle mit GuildSentinel bekommen einen Hinweis."],
	})
	Gp.list:SetPoint("TOPLEFT", 0, -110)
	Gp.list:SetPoint("RIGHT", 0, 0)
	Gp.list:SetHeight(240)

	Gp.myRole = UI:Dropdown(p, 130, function()
		local out = {}
		for _, r in ipairs(G.ROLES) do out[#out + 1] = { value = r, text = G:RoleName(r) } end
		return out
	end, function() return G:MyRole() end, function(v) G:SetMyRole(v) end)
	Gp.myRole:SetPoint("TOPLEFT", Gp.list, "BOTTOMLEFT", 0, -6)
	Gp.joinBtn = UI:Button(p, L["Ich komme mit"], 150, 24, function()
		local s = Gp.list:Selected()
		if s then G:Join(s.id, G:MyRole()) end
	end, true)
	Gp.joinBtn:SetPoint("LEFT", Gp.myRole, "RIGHT", 8, 0)
	Gp.whisperBtn = UI:Button(p, L["Anflüstern"], 120, 24, function()
		local s = Gp.list:Selected()
		if s then ns.Recruit:Whisper(s.by) end
	end)
	Gp.whisperBtn:SetPoint("LEFT", Gp.joinBtn, "RIGHT", 8, 0)

	-- Meldungen zur eigenen Suche
	local jh = UI:Header(p, L["Meldungen zu deiner Suche"])
	jh:SetPoint("TOPLEFT", Gp.myRole, "BOTTOMLEFT", 0, -14)
	Gp.joins = UI:List(p, {
		{ key = "name", title = L["Name"], width = 160 },
		{ key = "r", title = L["Rolle"], width = 100 },
		{ key = "l", title = L["Stufe"], width = 50, align = "CENTER" },
		{ key = "t", title = L["Wann"], width = 110 },
		{ key = "st", title = L["Status"] },
	}, {
		key = function(j) return j.name end,
		render = function(j)
			return { ns.Colored(j.name, j.c), G:RoleName(j.r), tostring(j.l or "?"), Gray(ns.Ago(j.t)), j.inv and (GREEN .. L["eingeladen"] .. "|r") or "" }
		end,
		onClick = function() Gp:UpdateButtons() end,
		empty = L["Noch keine Meldungen. Wer mitkommen will, erscheint hier."],
	})
	Gp.joins:SetPoint("TOPLEFT", jh, "BOTTOMLEFT", 0, -6)
	Gp.joins:SetPoint("BOTTOMRIGHT", -160, 0)
	Gp.inviteBtn = UI:Button(p, L["Einladen"], 150, 26, function()
		local j = Gp.joins:Selected()
		if j then G:Invite(j.name) end
	end, true)
	Gp.inviteBtn:SetPoint("TOPLEFT", Gp.joins, "TOPRIGHT", 10, 0)
	Gp.inviteAll = UI:Button(p, L["Alle einladen"], 150, 26, function()
		local s = G:Mine()
		for _, j in ipairs(G:Joins(s)) do if not j.inv then G:Invite(j.name) end end
	end)
	Gp.inviteAll:SetPoint("TOPLEFT", Gp.inviteBtn, "BOTTOMLEFT", 0, -6)
end

function Gp:UpdateButtons()
	local G = ns.Group
	local s = self.list:Selected()
	self.joinBtn:SetEnabled(s ~= nil and G:IsOpen(s) and not ns.Same(s.by, ns.Me()))
	self.whisperBtn:SetEnabled(s ~= nil and not ns.Same(s.by, ns.Me()))
	local mine = G:Mine()
	self.inviteBtn:SetEnabled(mine ~= nil and self.joins:Selected() ~= nil)
	self.inviteAll:SetEnabled(mine ~= nil and #G:Joins(mine) > 0)
end

function Gp:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	local G = ns.Group
	local mine = G:Mine()
	if mine then
		self.mine:SetText(string.format(L["Deine Suche: %s · %s · noch bis %s"], GREEN .. G:ActivityName(mine) .. "|r", G:RolesText(mine), date("%H:%M", mine.exp))
			.. (mine.scope == "server" and Gray(" · " .. L["ganzer Server"]) or ""))
		self.startBtn:SetText(L["Neu starten"])
	else
		self.mine:SetText(Gray(L["Du suchst gerade nicht."]) .. (ns.db.lfgServer and "" or Gray(" " .. L["(Suchen vom ganzen Server sind in den Einstellungen aus.)"])))
		self.startBtn:SetText(L["Suche starten"])
	end
	self.closeBtn:SetShown(mine ~= nil)
	self.list:SetData(G:Open())
	self.joins:SetData(G:Joins(mine))
	self:UpdateButtons()
end

Gp.onShow = function() Gp:Refresh() end
ns:Listen("GS_LFG", WhenShown("group", function() Gp:Refresh() end))
ns:Listen("GS_LFG_TICK", WhenShown("group", function() Gp:Refresh() end))
ns:Listen("GS_LFG", function() UI:RefreshHeader() end)
UI:AddPage(Gp)

------------------------------------------------------------
-- Seite: Fortschritt (Leveling-Rennen, Raid-Zugänge)
------------------------------------------------------------
local Pr = { key = "progress", order = 30, icon = "Interface\\Icons\\INV_Misc_Note_01" }
Pr.title = L["Fortschritt"]
Pr.view = "race"
Pr.mainsOnly = true
Pr.minLevel = 55

local function Mark(st)
	if st == true then return GREEN .. L["Ja"] .. "|r" end
	if st == false then return RED .. L["Nein"] .. "|r" end
	return Gray("?")
end

function Pr.build(p)
	Pr.panel = p
	Pr.tabs = UI:Tabs(p, {
		{ key = "race", text = L["Leveling-Rennen"] },
		{ key = "attune", text = L["Raid-Zugänge"] },
	}, function(key) Pr.view = key; Pr:Refresh() end)
	Pr.tabs:SetPoint("TOPLEFT")
	Pr.tabs:SetPoint("TOPRIGHT")

	-- Rennen ----------------------------------------------
	local rv = CreateFrame("Frame", nil, p)
	rv:SetPoint("TOPLEFT", 0, -34)
	rv:SetPoint("BOTTOMRIGHT")
	Pr.raceView = rv
	Pr.first = UI:Label(rv, "", "GameFontNormalLarge")
	Pr.first:SetPoint("TOPLEFT", 0, -2)
	local mo = UI:Check(rv, L["nur Mains"], function() return Pr.mainsOnly end, function(v) Pr.mainsOnly = v; Pr:Refresh() end)
	mo:SetPoint("TOPRIGHT", -80, 0)
	Pr.raceStats = UI:Label(rv, "", "GameFontHighlightSmall")
	Pr.raceStats:SetPoint("TOPLEFT", Pr.first, "BOTTOMLEFT", 0, -6)
	Pr.raceList = UI:List(rv, {
		{ key = "rank", title = "#", width = 26, align = "RIGHT" },
		{ key = "name", title = L["Name"], width = 170 },
		{ key = "level", title = L["Stufe"], width = 50, align = "CENTER" },
		{ key = "class", title = L["Klasse"], width = 110 },
		{ key = "t", title = L["Stufe erreicht"], width = 130 },
		{ key = "gain", title = L["Letzte 7 Tage"], width = 100, align = "CENTER" },
		{ key = "on", title = L["Status"] },
	}, {
		key = function(x) return x.name end,
		render = function(x)
			local medal = (x.rank == 1 and GOLD) or (x.rank == 2 and "|cffd0d0d0") or (x.rank == 3 and "|cffcd7f32") or ""
			return { medal .. x.rank .. (medal ~= "" and "|r" or ""), ns.Colored(x.name, x.class), tostring(x.level), ns.ClassName(x.class),
				x.t and Gray(ns.Ago(x.t)) or Gray(L["unbekannt"]),
				x.gain and (x.gain > 0 and (GREEN .. "+" .. x.gain .. "|r") or Gray("0")) or Gray("?"),
				x.online and (GREEN .. L["online"] .. "|r") or "" }
		end,
		empty = L["Noch keine Gildendaten."],
	})
	Pr.raceList:SetPoint("TOPLEFT", 0, -46)
	Pr.raceList:SetPoint("BOTTOMRIGHT", 0, 24)
	local rh = UI:Label(rv, Gray(L["Bei gleicher Stufe steht vorne, wer sie zuerst erreicht hat. Die Stufen kommen aus der Gildenliste – das Addon braucht dafür niemand."]), "GameFontHighlightSmall")
	rh:SetPoint("BOTTOMLEFT", 0, 4)
	rh:SetPoint("RIGHT")

	-- Raid-Zugänge ----------------------------------------
	local av = CreateFrame("Frame", nil, p)
	av:SetPoint("TOPLEFT", 0, -34)
	av:SetPoint("BOTTOMRIGHT")
	Pr.attView = av
	local ml = UI:Label(av, L["ab Stufe"], "GameFontHighlight")
	ml:SetPoint("TOPLEFT", 0, -5)
	local dd = UI:Dropdown(av, 80, function()
		local out = {}
		for _, l in ipairs({ 1, 40, 50, 55, 58, 60 }) do out[#out + 1] = { value = l, text = tostring(l) } end
		return out
	end, function() return Pr.minLevel end, function(v) Pr.minLevel = v; Pr:Refresh() end)
	dd:SetPoint("LEFT", ml, "RIGHT", 8, 0)
	local mo2 = UI:Check(av, L["nur Mains"], function() return Pr.mainsOnly end, function(v) Pr.mainsOnly = v; Pr:Refresh() end)
	mo2:SetPoint("LEFT", dd, "RIGHT", 14, 0)
	Pr.attSummary = UI:Label(av, "", "GameFontHighlightSmall")
	Pr.attSummary:SetPoint("TOPRIGHT", 0, -6)
	Pr.attSummary:SetJustifyH("RIGHT")
	local cols = {
		{ key = "name", title = L["Name"], width = 170 },
		{ key = "level", title = L["Stufe"], width = 50, align = "CENTER" },
	}
	for _, a in ipairs(ns.Attune.LIST) do cols[#cols + 1] = { key = a.key, title = a.short, width = 80, align = "CENTER" } end
	cols[#cols + 1] = { key = "info", title = "" }
	Pr.attList = UI:List(av, cols, {
		key = function(x) return x.name end,
		render = function(x)
			local out = { ns.Colored(x.name, x.class), tostring(x.level) }
			for _, a in ipairs(ns.Attune.LIST) do out[#out + 1] = Mark(ns.Attune:Status(x.name, a.key)) end
			out[#out + 1] = x.known and "" or Gray(L["ohne GuildSentinel"])
			return out
		end,
		onEnter = function(row, x)
			GameTooltip:SetOwner(row, "ANCHOR_CURSOR")
			GameTooltip:AddLine(ns.Colored(x.name, x.class))
			for _, a in ipairs(ns.Attune.LIST) do
				GameTooltip:AddDoubleLine(a.name, Mark(ns.Attune:Status(x.name, a.key)), 0.8, 0.8, 0.8)
			end
			GameTooltip:Show()
		end,
		empty = L["Niemand in dieser Stufe."],
	})
	Pr.attList:SetPoint("TOPLEFT", 0, -32)
	Pr.attList:SetPoint("BOTTOMRIGHT", 0, 24)
	local names = {}
	for _, a in ipairs(ns.Attune.LIST) do names[#names + 1] = a.short .. " = " .. a.name end
	local ah = UI:Label(av, Gray(table.concat(names, " · ") .. ". " .. L["? = hat GuildSentinel nicht, darum unbekannt."]), "GameFontHighlightSmall")
	ah:SetPoint("BOTTOMLEFT", 0, 4)
	ah:SetPoint("RIGHT")

	Pr.tabs:Select("race")
end

function Pr:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	self.raceView:SetShown(self.view == "race")
	self.attView:SetShown(self.view == "attune")
	if self.view == "race" then
		local f = ns.Race:First60()
		if f then
			local r = ns.G().roster[f.n]
			self.first:SetText(string.format(L["Erstes Gildenmitglied auf 60: %s"], ns.Colored(f.n, r and r.c)) .. Gray(f.t and f.t > 0 and ("  " .. ns.Date(f.t)) or ""))
		else
			self.first:SetText(L["Wer ist als Erstes auf 60?"])
		end
		local list = ns.Race:Ranking(self.mainsOnly)
		local sum, at60, gained = 0, 0, 0
		for _, x in ipairs(list) do
			sum = sum + x.level
			if x.level >= ns.Roster.MAX_LEVEL then at60 = at60 + 1 end
			gained = gained + (x.gain or 0)
		end
		self.raceStats:SetText(Gray(string.format(L["%d Spieler · Durchschnitt Stufe %.1f · %d auf 60 · %d Stufen in den letzten 7 Tagen"],
			#list, #list > 0 and sum / #list or 0, at60, gained)))
		self.raceList:SetData(list)
	else
		local rows = ns.Attune:Rows(self.minLevel, self.mainsOnly)
		self.attList:SetData(rows)
		local s = ns.Attune:Summary(rows)
		local t = {}
		for _, a in ipairs(ns.Attune.LIST) do
			t[#t + 1] = string.format("%s %s%d|r/%d", a.short, GREEN, s[a.key].yes, s[a.key].yes + s[a.key].no)
		end
		self.attSummary:SetText(table.concat(t, "   "))
	end
end

Pr.onShow = function(_, arg)
	if arg == "attune" then Pr.tabs:Select("attune") else Pr:Refresh() end
end
ns:Listen("GS_ROSTER", WhenShown("progress", function() Pr:Refresh() end))
ns:Listen("GS_ATTUNE", WhenShown("progress", function() Pr:Refresh() end))
ns:Listen("GS_PROGRESS", WhenShown("progress", function() Pr:Refresh() end))
UI:AddPage(Pr)
