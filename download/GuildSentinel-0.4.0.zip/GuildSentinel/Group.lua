-- GuildSentinel - Group.lua
-- Gruppensuche in der Gilde: "Suche Gruppe für Schwarzfelstiefen, brauche Heiler".
-- Die Suche geht an alle mit GuildSentinel – nur in der Gilde oder auf dem ganzen Server (über einen eigenen,
-- im Chat ausgeblendeten Kanal, auch an Spieler anderer Gilden). Wer von Stufe und Rolle passt, bekommt einen
-- Hinweis im Chat und meldet sich mit einem Klick ("Ich komme mit"). Der Suchende lädt mit einem Klick ein.
--
--   G.lfg[id] = { id, by, c = Klasse, l = Stufe, act = Aktivität, note, roles = { tank, heal, dps }, need = Plätze,
--                 scope = "guild"/"server", gn = Gilde des Suchenden, t, exp, closed,
--                 joins = { [Name] = { r = Rolle, l, c, t } } }

local ADDON, ns = ...
local L = ns.L
local G = {}
ns.Group = G

G.DURATION = 3600         -- eine Suche läuft 60 Minuten
G.CHANNEL = "GuildSentinelLFG"   -- eigener Kanal für die Suche auf dem ganzen Server

-- Dungeons (Classic) mit Stufenbereich; Namen wie im deutschen Spiel
G.ACTIVITIES = {
	{ key = "rfc", n = L["Ragefireabgrund"], min = 13, max = 18 },
	{ key = "wc", n = L["Höhlen des Wehklagens"], min = 17, max = 24 },
	{ key = "dm", n = L["Die Todesminen"], min = 17, max = 26 },
	{ key = "sfk", n = L["Burg Schattenfang"], min = 22, max = 30 },
	{ key = "bfd", n = L["Tiefschwarze Grotte"], min = 24, max = 32 },
	{ key = "stocks", n = L["Das Verlies"], min = 24, max = 32 },
	{ key = "gnomer", n = L["Gnomeregan"], min = 29, max = 38 },
	{ key = "rfk", n = L["Kral der Klingenhauer"], min = 29, max = 38 },
	{ key = "smgy", n = L["Scharlachrotes Kloster: Friedhof"], min = 30, max = 37 },
	{ key = "smlib", n = L["Scharlachrotes Kloster: Bibliothek"], min = 33, max = 40 },
	{ key = "smarm", n = L["Scharlachrotes Kloster: Waffenkammer"], min = 35, max = 42 },
	{ key = "smcath", n = L["Scharlachrotes Kloster: Kathedrale"], min = 38, max = 45 },
	{ key = "rfd", n = L["Hügel der Klingenhauer"], min = 37, max = 46 },
	{ key = "ulda", n = L["Uldaman"], min = 41, max = 51 },
	{ key = "zf", n = L["Zul'Farrak"], min = 44, max = 54 },
	{ key = "mara", n = L["Maraudon"], min = 46, max = 55 },
	{ key = "st", n = L["Tempel von Atal'Hakkar"], min = 50, max = 56 },
	{ key = "brd", n = L["Schwarzfelstiefen"], min = 52, max = 60 },
	{ key = "lbrs", n = L["Untere Schwarzfelsspitze"], min = 55, max = 60 },
	{ key = "ubrs", n = L["Obere Schwarzfelsspitze"], min = 55, max = 60 },
	{ key = "dme", n = L["Düsterbruch"], min = 55, max = 60 },
	{ key = "strat", n = L["Stratholme"], min = 58, max = 60 },
	{ key = "scholo", n = L["Scholomance"], min = 58, max = 60 },
	{ key = "quest", n = L["Quests / Elitequests"] },
	{ key = "pvp", n = L["PvP"] },
	{ key = "farm", n = L["Farmen"] },
	{ key = "other", n = L["Sonstiges"] },
}
G.BY_KEY = {}
for _, a in ipairs(G.ACTIVITIES) do G.BY_KEY[a.key] = a end

G.ROLES = { "tank", "heal", "dps" }

function G:RoleName(r)
	if r == "tank" then return L["Tank"] end
	if r == "heal" then return L["Heiler"] end
	return L["Schaden"]
end

-- eigene Rolle: gewählt (Einstellungen) oder nach Klasse vermutet
local HEALERS = { PRIEST = true, DRUID = true, SHAMAN = true, PALADIN = true }
function G:MyRole()
	local g = ns.G()
	local m = g.mine[ns.Me()]
	if m and m.role then return m.role end
	local _, cf = UnitClass("player")
	return HEALERS[cf] and "heal" or "dps"
end

function G:SetMyRole(r)
	local g = ns.guild
	if not g then return end
	g.mine[ns.Me()] = g.mine[ns.Me()] or {}
	g.mine[ns.Me()].role = r
end

function G:ActivityName(s)
	local a = G.BY_KEY[s.act]
	return a and a.n or tostring(s.act or "?")
end

function G:Range(s)
	local a = G.BY_KEY[s.act]
	if a and a.min then return a.min, a.max end
	return nil
end

function G:IsOpen(s)
	return s and not s.closed and (s.exp or 0) > ns.Now()
end

-- passt die Suche zu mir? (Stufe im Bereich ±2, eine meiner Rollen gesucht)
function G:Fits(s, level, role)
	if not self:IsOpen(s) or ns.Same(s.by, ns.Me()) then return false end
	level = level or UnitLevel("player")
	local min, max = self:Range(s)
	if min and (level < min - 2 or level > max + 2) then return false end
	local roles = s.roles or {}
	if not roles.tank and not roles.heal and not roles.dps then return true end
	return roles[role or self:MyRole()] and true or false
end

------------------------------------------------------------
-- Suchen anlegen, beenden, mitmachen
------------------------------------------------------------
local counter = 0

function G:Post(act, roles, need, note, scope)
	local g = ns.guild
	if not g or not IsInGuild() then ns:Print(L["Du bist in keiner Gilde."]) return end
	counter = counter + 1
	local now = ns.Now()
	local _, cf = UnitClass("player")
	local s = {
		id = ns.Me() .. now .. counter, by = ns.Me(), c = cf, l = UnitLevel("player"), act = act or "other",
		note = ns.Trim(note), roles = { tank = roles.tank and true or nil, heal = roles.heal and true or nil, dps = roles.dps and true or nil },
		need = math.max(1, math.min(39, tonumber(need) or 1)), t = now, exp = now + self.DURATION, joins = {},
		scope = (scope == "server") and "server" or "guild", gn = ns.GuildName(),
	}
	-- nur eine eigene offene Suche gleichzeitig
	for id, o in pairs(g.lfg) do
		if ns.Same(o.by, ns.Me()) and self:IsOpen(o) then self:Close(id, true) end
	end
	g.lfg[s.id] = s
	ns.Comm:Send("LFG", self:Wire(s), "GUILD", nil, true)
	if s.scope == "server" then self:SendServer("LFG", self:Wire(s)) end
	ns:Fire("GS_LFG")
	return s
end

-- was über die Leitung geht (ohne Meldungen)
function G:Wire(s)
	return { id = s.id, by = s.by, c = s.c, l = s.l, act = s.act, note = s.note, roles = s.roles, need = s.need, t = s.t, exp = s.exp,
		closed = s.closed, scope = s.scope, gn = s.gn }
end

function G:Close(id, quiet)
	local s = ns.G().lfg[id]
	if not s then return end
	s.closed = true
	ns.Comm:Send("LFGX", { id = id }, "GUILD", nil, true)
	if s.scope == "server" then self:SendServer("LFGX", { id = id }) end
	if not quiet then ns:Fire("GS_LFG") end
end

function G:Join(id, role)
	local s = ns.G().lfg[id]
	if not self:IsOpen(s) then return end
	role = role or self:MyRole()
	local _, cf = UnitClass("player")
	s.myJoin = role
	ns.Comm:Send("LFGJ", { id = id, r = role, l = UnitLevel("player"), c = cf }, "WHISPER", s.by, true)
	ns:Print(string.format(L["%s weiß Bescheid, dass du mitkommst (%s)."], s.by, self:RoleName(role)))
	ns:Fire("GS_LFG")
end

function G:Invite(name)
	local fn = (C_PartyInfo and C_PartyInfo.InviteUnit) or InviteUnit
	if fn then fn(name) end
	for _, s in pairs(ns.G().lfg) do
		if ns.Same(s.by, ns.Me()) and s.joins and s.joins[name] then s.joins[name].inv = true end
	end
	ns:Fire("GS_LFG")
end

function G:Notify(s)
	if not ns.db.lfgNotify then return end
	local roles = {}
	for _, r in ipairs(self.ROLES) do if s.roles and s.roles[r] then roles[#roles + 1] = self:RoleName(r) end end
	ns:Print(string.format(L["%s sucht für %s: %s. Mitkommen: /gs gruppe"], ns.Colored(s.by, s.c), self:ActivityName(s),
		#roles > 0 and table.concat(roles, ", ") or L["alle Rollen"]))
	if ns.db.lfgSound and PlaySound then
		local kit = SOUNDKIT and (SOUNDKIT.TELL_MESSAGE or SOUNDKIT.RAID_WARNING)
		if kit then pcall(PlaySound, kit) end
	end
end

-- Suchen empfangen
function G:Store(d)
	local g = ns.guild
	if not g or type(d.id) ~= "string" or type(d.by) ~= "string" then return nil end
	local old = g.lfg[d.id]
	local s = {
		id = d.id, by = d.by, c = d.c, l = tonumber(d.l) or 0, act = d.act, note = type(d.note) == "string" and d.note or "",
		roles = type(d.roles) == "table" and d.roles or {}, need = tonumber(d.need) or 1, t = tonumber(d.t) or ns.Now(),
		exp = tonumber(d.exp) or (ns.Now() + self.DURATION), closed = (d.closed or (old and old.closed)) and true or nil,
		scope = d.scope == "server" and "server" or "guild", gn = type(d.gn) == "string" and d.gn or nil,
		joins = old and old.joins or {}, myJoin = old and old.myJoin,
	}
	g.lfg[d.id] = s
	return s, old
end

ns.Comm:Register("LFG", function(sender, d, channel)
	-- über den Server-Kanal nur Suchen, die auch für den Server gedacht sind, und nur vom Suchenden selbst
	if channel == "CHANNEL" and (d.scope ~= "server" or not ns.Same(d.by, sender)) then return end
	local s, old = G:Store(d)
	if not s then return end
	if not old and G:Fits(s) then G:Notify(s) end
	ns:Fire("GS_LFG")
end)

ns.Comm:Register("LFGX", function(sender, d)
	local s = type(d.id) == "string" and ns.G().lfg[d.id]
	if s and ns.Same(s.by, sender) then s.closed = true; ns:Fire("GS_LFG") end
end)

ns.Comm:Register("LFGJ", function(sender, d, channel)
	local s = type(d.id) == "string" and ns.G().lfg[d.id]
	if not s or not ns.Same(s.by, ns.Me()) or channel ~= "WHISPER" then return end
	local role = (d.r == "tank" or d.r == "heal") and d.r or "dps"
	local isNew = not s.joins[sender]
	s.joins[sender] = { r = role, l = tonumber(d.l) or 0, c = d.c, t = ns.Now() }
	if isNew then
		ns:Print(string.format(L["%s (%s, Stufe %d) kommt mit – Einladen: /gs gruppe"], ns.Colored(sender, d.c), G:RoleName(role), tonumber(d.l) or 0))
		if ns.db.lfgSound and PlaySound and SOUNDKIT and SOUNDKIT.TELL_MESSAGE then pcall(PlaySound, SOUNDKIT.TELL_MESSAGE) end
	end
	ns:Fire("GS_LFG")
end)

------------------------------------------------------------
-- Abfragen
------------------------------------------------------------
function G:Open()
	local out = {}
	for _, s in pairs(ns.G().lfg) do
		if self:IsOpen(s) then out[#out + 1] = s end
	end
	table.sort(out, function(a, b)
		local am, bm = ns.Same(a.by, ns.Me()), ns.Same(b.by, ns.Me())
		if am ~= bm then return am end
		return (a.t or 0) > (b.t or 0)
	end)
	return out
end

function G:Mine()
	for _, s in pairs(ns.G().lfg) do
		if ns.Same(s.by, ns.Me()) and self:IsOpen(s) then return s end
	end
	return nil
end

function G:Joins(s)
	local out = {}
	for name, j in pairs(s and s.joins or {}) do out[#out + 1] = { name = name, r = j.r, l = j.l, c = j.c, t = j.t, inv = j.inv } end
	table.sort(out, function(a, b) return (a.t or 0) < (b.t or 0) end)
	return out
end

function G:RolesText(s)
	local t = {}
	for _, r in ipairs(self.ROLES) do if s.roles and s.roles[r] then t[#t + 1] = self:RoleName(r) end end
	return #t > 0 and table.concat(t, ", ") or L["alle Rollen"]
end

------------------------------------------------------------
-- Suche für den ganzen Server: eigener Kanal (im Chat ausgeblendet)
------------------------------------------------------------
function G:ChannelId()
	local id = GetChannelName and GetChannelName(self.CHANNEL) or 0
	return (id and id > 0) and id or nil
end

function G:SendServer(msgType, data)
	if not self:ChannelId() then return false end
	ns.Comm:Send(msgType, data, "CHANNEL", self.CHANNEL, true)
	return true
end

-- Kanal in allen Chatfenstern ausblenden (die Nachrichten sind nur für das Addon)
function G:HideChannel()
	if not ChatFrame_RemoveChannel then return end
	for i = 1, (NUM_CHAT_WINDOWS or 10) do
		local cf = _G["ChatFrame" .. i]
		if cf then pcall(ChatFrame_RemoveChannel, cf, self.CHANNEL) end
	end
end

function G:JoinChannel()
	if not ns.db.lfgServer then return end
	if not self:ChannelId() then
		local join = JoinTemporaryChannel or JoinChannelByName
		if join then pcall(join, self.CHANNEL) end
	end
	C_Timer.After(2, function()
		self:HideChannel()
		-- wer schon sucht, schickt seine Suche noch einmal (dann sieht man sie auch als Neuer)
		if self:ChannelId() then ns.Comm:Send("LFGQ", {}, "CHANNEL", self.CHANNEL) end
	end)
end

function G:LeaveChannel()
	if self:ChannelId() and LeaveChannelByName then pcall(LeaveChannelByName, self.CHANNEL) end
end

ns.Comm:Register("LFGQ", function(sender, d, channel)
	local s = G:Mine()
	if channel ~= "CHANNEL" or not s or s.scope ~= "server" then return end
	if G.lastQ and GetTime() - G.lastQ < 30 then return end
	G.lastQ = GetTime()
	C_Timer.After(1 + math.random() * 4, function() G:SendServer("LFG", G:Wire(s)) end)
end)

ns:Listen("GS_LOGIN", function() C_Timer.After(10, function() G:JoinChannel() end) end)
ns:On("CHANNEL_UI_UPDATE", function()
	if G:ChannelId() then G:HideChannel() end
end)

-- alte Suchen aufräumen
ns:Listen("GS_LOGIN", function()
	local g = ns.guild
	if not g then return end
	local limit = ns.Now() - 86400
	for id, s in pairs(g.lfg) do if (s.exp or 0) < limit then g.lfg[id] = nil end end
end)
C_Timer.NewTicker(60, function()
	if ns.guild then ns:Fire("GS_LFG_TICK") end
end)
