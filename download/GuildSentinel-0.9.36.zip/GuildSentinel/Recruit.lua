-- GuildSentinel - Recruit.lua
-- Rekrutierung: Werbetext in öffentlichen Kanälen posten, Bewerber aus Flüsternachrichten sammeln,
-- automatisch antworten und neue Mitglieder im Gildenchat begrüßen.
--
-- Öffentliche Kanäle erlauben Addon-Nachrichten nur direkt nach einem Mausklick. Darum postet jeder
-- Klick auf "Werbung vorbereiten": Chat-Eingabe für genau einen Kanal (der nächste kommt beim nächsten Klick dran);
-- der Spieler sendet mit Enter.

local ADDON, ns = ...
local L = ns.L
local Rc = {}
ns.Recruit = Rc

Rc.CHANNEL_COOLDOWN = 60      -- Sekunden je Kanal
Rc.GLOBAL_COOLDOWN = 8        -- Sekunden zwischen zwei Klicks
Rc.lastPost = {}              -- [Kanal] = GetTime()
Rc.lastAny = 0
Rc.lastAdTime = 0             -- Serverzeit der letzten Werbung (für die Erinnerung)

-- Wert aus den Einstellungen, leer = Standardtext
local function Value(key, default)
	local v = ns.db[key]
	if not v or ns.Trim(v) == "" then return default end
	return v
end

------------------------------------------------------------
-- Texte
------------------------------------------------------------
-- Alter Standard-Werbetext (bis 0.9.24). Wer ihn unverändert gespeichert hat, bekommt einmalig den neuen Standard
-- (mit dem neuen {gesucht} ergäbe er holprige Sätze). Abweichende eigene Texte bleiben.
Rc.OLD_DEFAULT_DE = "<{gilde}> sucht Mitstreiter! {gesucht} Raids, Dungeons und eine entspannte Gemeinschaft. {discord} Flüstert mich an: /w {name} gilde"
function Rc:IsOldDefault(text)
	if type(text) ~= "string" then return false end
	text = ns.Trim(text)
	return text == Rc.OLD_DEFAULT_DE
		or text == ns.Trim(L["<{gilde}> sucht Mitstreiter! {gesucht} Raids, Dungeons und eine entspannte Gemeinschaft. {discord} Flüstert mich an: /w {name} gilde"])
end
function Rc:MigrateAdText()
	if ns.db and self:IsOldDefault(ns.db.adText) then
		ns.db.adText = nil
		return true
	end
	return false
end
ns:On("PLAYER_LOGIN", function() Rc:MigrateAdText() end)

-- Vorschlag 2 (seit 0.9.28): nennt den Server-Tag der Gilde auf Discord ({tag}). Ohne Discord-Link fällt der ganze
-- Discord-Satz weg, ohne Tag nur "– erkennbar am Tag …".
function Rc:Suggestion2()
	return L["<{gilde}> ({fraktion}) sucht {gesucht}! Entspannte, deutschsprachige Gilde mit Raidziel. Discord: {discord} – erkennbar am Tag {tag}."]
end

-- "{tag}" samt seinem Satzteil entfernen. Was davor am nächsten an {tag} steht, entscheidet:
--   Gedankenstrich  " – erkennbar am Tag {tag}."  -> ab dem Strich weg, das Satzende bleibt
--   offene Klammer  " (Tag {tag})"                -> die Klammer samt Inhalt weg
--   Satzende        "Join us! Tag: {tag}. Whisper" -> der ganze Satz mit {tag} weg
--   nichts davon    "Tag {tag}. Hallo"             -> nur {tag} leer ("Tag. Hallo")
local DASHES_TAG = { " – ", " — ", " - ", "——", "，" }
local ENDS = { ".", "!", "?", "。", "！", "？" }
-- vor {tag} zählt ein Punkt nur mit Leerzeichen danach als Satzende (nicht der Punkt in "discord.gg")
local ENDS_BEFORE = { ". ", "! ", "? ", "。", "！", "？" }

local function LastOf(s, list)
	local best, blen
	for _, d in ipairs(list) do
		local i = 0
		while true do
			local j = s:find(d, i + 1, true)
			if not j then break end
			if not best or j > best then best, blen = j, #d end
			i = j
		end
	end
	return best, blen
end

local function FirstOf(s, list)
	local best, blen
	for _, d in ipairs(list) do
		local j = s:find(d, 1, true)
		if j and (not best or j < best) then best, blen = j, #d end
	end
	return best, blen
end

local function DropTag(text)
	local at = text:find("{tag}", 1, true)
	local guard = 0
	while at and guard < 20 do
		guard = guard + 1
		local before, rest = text:sub(1, at - 1), text:sub(at + 5)
		local dash = LastOf(before, DASHES_TAG)
		local paren = LastOf(before, { "(", "（" })
		if paren and before:find("[%)）]", paren) then paren = nil end
		local sEnd, sLen = LastOf(before, ENDS_BEFORE)
		local best = math.max(dash or 0, paren or 0, sEnd or 0)
		if best == 0 then
			-- kein Strich, keine Klammer, kein Satzende davor: nur {tag} leeren (Build räumt " ." und Leerstellen auf)
			text = before .. rest
		elseif best == paren then
			local close, clen = FirstOf(rest, { ")", "）" })
			text = before:sub(1, paren - 1) .. (close and rest:sub(close + clen) or rest)
		elseif best == dash then
			-- der Satzteil nach {tag} gehört dazu (Koreanisch: "태그 {tag}(으)로 알아보세요."), das Satzende bleibt
			local stop = FirstOf(rest, ENDS)
			text = before:sub(1, dash - 1) .. (stop and rest:sub(stop) or "")
		else
			-- eigener Satz: das Satzende davor bleibt, der Satz mit {tag} samt seinem Satzende fällt weg
			local stop, slen = FirstOf(rest, ENDS)
			text = before:sub(1, sEnd + sLen - 1) .. (stop and rest:sub(stop + slen) or "")
		end
		at = text:find("{tag}", 1, true)
	end
	return text
end
Rc.DropTag = DropTag

-- Standard-Werbetext (seit 0.9.25). Ein selbst gespeicherter Text bleibt unverändert; leeres Feld = dieser Text.
-- GA2 (13.11.): In der Phase Aufbau ein eigener Standardtext, der den Aufbau nennt.
function Rc:DefaultAd(phase)
	phase = phase or (ns.RaidReady and ns.RaidReady:Phase()) or "raid"
	if phase == "build" then
		return L["<{gilde}> ({fraktion}) ist im Aufbau und sucht {gesucht} – entspannt, hilfsbereit, deutschsprachig, Raidziel. Discord: {discord} – flüstert mir: /w {name} gilde"]
	end
	return L["{gilde} ({fraktion}) sucht {gesucht} für Dungeons und Raids – entspannt, hilfsbereit, deutschsprachig. Discord: {discord} – flüstert mir: /w {name} gilde"]
end

-- eigener Werbetext, der weder {gesucht} noch {phase} enthält? (GA2: Hinweis mit "Übernehmen")
function Rc:OwnAdWithoutWanted()
	local t = ns.db.adText
	if type(t) ~= "string" or ns.Trim(t) == "" then return false end
	t = ns.Trim(t)
	if t == ns.Trim(self:Suggestion2()) then return false end
	for _, ph in ipairs({ "build", "trans", "raid" }) do if t == ns.Trim(self:DefaultAd(ph)) then return false end end
	return not (t:find("{gesucht}", 1, true) or t:find("{wanted}", 1, true) or t:find("{phase}", 1, true))
end

-- {phase}: "im Aufbau" / "fast raidbereit" / "raidbereit"
function Rc:PhaseText()
	local p = ns.RaidReady and ns.RaidReady:Phase() or "build"
	if p == "trans" then return L["fast raidbereit"] elseif p == "raid" then return L["raidbereit"] end
	return L["im Aufbau"]
end

function Rc:DefaultReply()
	return L["Hallo {spieler}! Danke für dein Interesse an <{gilde}>. Ein Offizier meldet sich gleich bei dir. {discord}"]
end

function Rc:DefaultWelcome()
	return L["Willkommen bei <{gilde}>, {spieler}! Schön, dass du da bist. {discord}"]
end

function Rc:DefaultQuestions()
	return L["Welche Klasse und Stufe spielst du?"] .. "\n" .. (ns.Game.TBC and L["Hast du schon Raid-Erfahrung (Karazhan, Gruul, Magtheridon ...)?"] or L["Hast du schon Raid-Erfahrung (MC, Onyxia ...)?"]) .. "\n"
		.. L["Wann spielst du meistens (Tage und Uhrzeit)?"] .. "\n" .. L["Wie bist du auf uns gekommen?"]
end

-- GA1 (13.11.): Altersfrage. Ist ein Mindestalter eingestellt (Standard 16, 0 = aus), wird sie IMMER als letzte Frage
-- gestellt – auch bei eigenen Fragenlisten. Ausgewertet wird nur "16+" / "unter 16" / "unklar"; das genaue Alter und
-- der Antworttext werden nie gespeichert, nie geteilt und nie ins Diagnose-Protokoll geschrieben.
function Rc:MinAge()
	local n = tonumber(ns.db.minAge)
	if not n or n < 0 then return 0 end
	return math.floor(n)
end

function Rc:AgeQuestion() return L["Wie alt bist du?"] end

-- "ok" (>= Mindestalter), "young" (darunter), "unclear" (keine Zahl, "bald 16", Ausweichen)
local SOON = { "bald", "fast", "gleich", "demnächst", "soon", "almost", "nearly", "bientôt", "presque", "pronto", "casi", "quasi",
	"quase", "почти", "скоро", "곧", "거의", "快", "将", "將" }
function Rc.AgeCheck(msg, min)
	if type(msg) ~= "string" or ns.IsSecret(msg) then return "unclear" end
	local low = msg:lower()
	for _, w in ipairs(SOON) do if low:find(w, 1, true) then return "unclear" end end
	local nums = {}
	for d in low:gmatch("%d+") do nums[#nums + 1] = tonumber(d) end
	-- genau eine plausible Zahl (Ausweichen wie "zwischen 15 und 20" = unklar)
	if #nums ~= 1 or nums[1] < 5 or nums[1] > 99 then return "unclear" end
	return nums[1] >= (min or 16) and "ok" or "young"
end

function Rc:AgeLabel(cat)
	if cat == "ok" then return string.format(L["%d+"], self:MinAge())
	elseif cat == "young" then return string.format(L["unter %d"], self:MinAge()) end
	return L["Alter unklar"]
end

function Rc:DefaultAgeReject()
	return L["Danke für dein Interesse an <{gilde}>! Wir nehmen leider erst ab {alter} Jahren auf. Viel Spass weiterhin in Azeroth!"]
end

function Rc:Questions()
	local out = {}
	for line in (Value("questions", self:DefaultQuestions()) .. "\n"):gmatch("([^\n]*)\n") do
		line = ns.Trim(line)
		if line ~= "" and #out < 6 then out[#out + 1] = line:sub(1, 200) end
	end
	if self:MinAge() > 0 then
		out[#out + 1] = self:AgeQuestion()
		out.age = #out
	end
	return out
end

-- nächste Frage flüstern (oder Dank, wenn alle beantwortet sind)
function Rc:AskNext(name, target)
	local a = ns.G().apps[name]
	if not a or not a.qi then return end
	local qs = self:Questions()
	if a.qi > #qs then
		a.qi = nil
		a.qdone = ns.Now()
		ns.Chat(L["Danke für deine Antworten! Ein Offizier meldet sich bei dir."], "WHISPER", target or name)
		ns:Print(string.format(L["%s hat alle Bewerbungsfragen beantwortet – siehe Seite Rekrutierung."], name))
		ns:Fire("GS_APPS")
		return
	end
	a.qt = ns.Now()
	ns.Chat(string.format(L["Frage %d/%d: %s"], a.qi, #qs, qs[a.qi]), "WHISPER", target or name)
end

function Rc:StartQuestions(name, target, delay)
	local a = ns.G().apps[name]
	if not a or not ns.db.askQuestions or #self:Questions() == 0 or a.qdone then return end
	a.qi, a.qa = 1, {}
	ns.Later(delay or 3, function() Rc:AskNext(name, target) end)
end

-- Antwort auf die offene Frage? (true = als Antwort gespeichert)
function Rc:TakeAnswer(name, msg, target)
	local a = ns.G().apps[name]
	if not a or not a.qi or not a.qt or ns.Now() - a.qt > 1800 then return false end
	local qs = self:Questions()
	a.qa = a.qa or {}
	if qs.age and a.qi == qs.age then
		-- Altersfrage: nur das Ergebnis behalten, nie die Antwort oder die Zahl
		local cat = Rc.AgeCheck(msg, self:MinAge())
		a.age = cat
		a.qa[#a.qa + 1] = { q = qs[a.qi], a = self:AgeLabel(cat), age = true }
		a.last = ns.Now()
		if cat == "young" then
			a.qi, a.qt, a.qdone = nil, nil, ns.Now()
			a.st = "agedecl"
			local text = self:Build(Value("ageRejectText", self:DefaultAgeReject()), { spieler = name, alter = tostring(self:MinAge()) })
			ns.Later(1.5, function() ns.Chat(text, "WHISPER", target or name) end)
			ns:Print(string.format(L["%s: unter dem Mindestalter – freundlich abgesagt."], name))
			ns:Fire("GS_APPS")
			return true
		end
		a.qi = a.qi + 1
		ns:Fire("GS_APPS")
		ns.Later(1.5, function() Rc:AskNext(name, target) end)
		return true
	end
	a.qa[#a.qa + 1] = { q = qs[a.qi] or "?", a = ns.Trim(msg):sub(1, 250) }
	a.qi = a.qi + 1
	a.last = ns.Now()
	ns:Fire("GS_APPS")
	ns.Later(1.5, function() Rc:AskNext(name, target) end)
	return true
end

function Rc:DefaultKeywords()
	return L["gilde, guild, beitreten, join, ginv, bewerbung"]
end


-- Fraktion des Spielers in der Sprache des Spiels (Horde/Allianz)
function Rc:Faction()
	local tag, loc
	if UnitFactionGroup then tag, loc = UnitFactionGroup("player") end
	if ns.IsSecret(tag) or ns.IsSecret(loc) then return "" end
	if type(loc) == "string" and loc ~= "" then return loc end
	if tag == "Horde" then return L["Horde"] end
	if tag == "Alliance" then return L["Allianz"] end
	return ""
end

-- {discord} ohne Link: "Discord: {discord} – " bzw. "Discord: {discord}" fällt ganz weg (kein "Discord: –")
local DASHES = { "——", "–", "—", "-" }
-- "Discord:" in allen Schreibweisen der Locales (Französisch "Discord :", Chinesisch "Discord：")
local LABELS = { "[Dd]iscord%s*:%s*", "[Dd]iscord%s*：%s*" }
local function DropDiscord(text)
	for _, lab in ipairs(LABELS) do
		for _, d in ipairs(DASHES) do
			local dd = d:gsub("%p", "%%%0")
			-- nach einem Satzende beginnt der Rest dann mit einem Grossbuchstaben ("… deutschsprachig. Flüstert mir")
			-- (nur a–z; Umlaute am Satzanfang bleiben, wie sie sind)
			text = text:gsub("([%.!%?]%s*)" .. lab .. "{discord}%s*" .. dd .. "%s*(%l)", function(pre, c) return pre .. c:upper() end)
			text = text:gsub(lab .. "{discord}%s*" .. dd .. "%s*", "")
			-- "… Raidziel. Discord: {discord}." -> "… Raidziel." (kein doppelter Punkt)
			text = text:gsub("([%.!%?])%s*" .. lab .. "{discord}%s*[%.!]", "%1")
			text = text:gsub("%s*" .. dd .. "%s*" .. lab .. "{discord}", "")
		end
		text = text:gsub(lab .. "{discord}", "")
	end
	text = text:gsub("{discord}", "")
	return text
end
Rc.DropDiscord = DropDiscord

-- Platzhalter füllen und Leerstellen sauber machen. raw = true: ohne Kürzen (für den Zähler auf der Seite)
-- {discord}: steht "Discord:" schon im Text davor, nur der Link; sonst wie früher "Discord: <Link>" (eigene Texte,
-- Antwort und Willkommen bleiben so, wie sie waren).
function Rc:Build(text, extra, raw)
	local discord = ns.Trim(ns.db.discord)
	local total, online = ns.Roster:Stats()
	text = tostring(text or "")
	-- Server-Tag nur zusammen mit einem Discord-Link
	local tag = ns.Trim(ns.db.discordTag)
	if tag == "" or discord == "" then text = DropTag(text) end
	if discord == "" then
		text = DropDiscord(text)
	else
		local escaped = discord:gsub("%%", "%%%%")
		for _, lab in ipairs(LABELS) do text = text:gsub("(" .. lab .. "){discord}", "%1" .. escaped) end
	end
	local vars = {
		gilde = ns.DisplayGuildName() or "",
		name = ns.Me() or "",
		discord = discord ~= "" and (L["Discord: "] .. discord) or "",
		mitglieder = total or 0,
		online = online or 0,
		gesucht = ns.RaidReady and ns.RaidReady:Wanted() or (ns.Comp and ns.Comp:WantedList()) or "",
		berufe = ns.Craft and ns.Craft:WantedText() or "",
		fraktion = self:Faction(),
		tag = ns.Trim(ns.db.discordTag),
		phase = self:PhaseText(),
	}
	for k, v in pairs(extra or {}) do vars[k] = v end
	-- englische Namen der Platzhalter gehen auch
	vars.guild, vars.members, vars.wanted, vars.crafters, vars.player, vars.faction = vars.gilde, vars.mitglieder, vars.gesucht, vars.berufe, vars.spieler, vars.fraktion
	local s = ns.Fill(text, vars)
	s = s:gsub("%(%s*%)", ""):gsub("%s+", " "):gsub("%s+([%.,!%?])", "%1"):gsub("<>", "")
	s = s:gsub("。%s*。", "。")
	s = ns.Trim(s)
	if raw then return s end
	-- Platz für "/<Kanal> " in der Chat-Eingabe (höchstens 255 Zeichen) lassen
	return ns.CutBytes(s, Rc.AD_MAX)
end

-- Werbetext ungekürzt (Zähler: wird gekürzt?)
function Rc:AdRaw()
	return self:Build(Value("adText", self:DefaultAd()), nil, true)
end

function Rc:AdText()
	return self:Build(Value("adText", self:DefaultAd()))
end

------------------------------------------------------------
-- Kanäle
------------------------------------------------------------
-- Kanäle von Addons (auch anderer GoldSentinel-Addons): dort nie Werbung (Kanal-Addon-Nachrichten, keine Spieler)
Rc.ADDON_CHANNELS = { guildsentinellfg = true, ahapsync = true, levelpilotnet = true, buffsentinelsync = true, goldsentinel = true }

-- Namen der Blizzard-Kanäle des Servers (Allgemein, Handel, LokaleVerteidigung, Gruppensuche …) in der Sprache des Spiels
local function ServerChannels()
	local out = {}
	if EnumerateServerChannels then
		local list = { pcall(EnumerateServerChannels) }
		if list[1] then
			for i = 2, #list do
				local n = list[i]
				if type(n) == "string" and not ns.IsSecret(n) then out[n:lower()] = true end
			end
		end
	end
	return out
end

-- Blizzard-Kanal? (instanceID > 0 = Zonenkanal wie Allgemein/Handel, oder Name in der Liste des Servers)
-- Alles andere (eigene Kanäle von Spielern oder Addons) ist kein Ziel für Werbung.
function Rc.IsBlizzard(short, instanceID, server)
	if type(short) ~= "string" or short == "" then return false end
	local k = short:lower():gsub("%s+", "")
	if Rc.ADDON_CHANNELS[k] then return false end
	if tonumber(instanceID) and tonumber(instanceID) > 0 then return true end
	server = server or ServerChannels()
	return server[short:lower()] and true or false
end

-- beigetretene Blizzard-Kanäle: { { name, id, short } }
function Rc:Joined()
	local out = {}
	if not GetChannelName then return out end
	local server = ServerChannels()
	for i = 1, 20 do
		local id, name, instanceID = GetChannelName(i)
		if id and id > 0 and type(name) == "string" and name ~= "" and not ns.IsSecret(name) then
			local short = name:match("^([^%-]+)") and ns.Trim(name:match("^([^%-]+)")) or name
			if Rc.IsBlizzard(short, instanceID, server) then
				out[#out + 1] = { name = name, id = id, short = short }
			end
		end
	end
	return out
end

local function Kind(name)
	local n = name:lower()
	if n:find("^world") or n:find("^welt") or n:find("global") then return 1 end
	if n:find("looking") or n:find("suche") or n:find("lfg") then return 2 end
	if n:find("^trade") or n:find("^handel") then return 3 end
	if n:find("^general") or n:find("^allgemein") then return 4 end
	return 5
end

-- Beim ersten Mal sinnvolle Kanäle vorwählen (Welt, Gruppensuche, Handel)
function Rc:EnsureTargets()
	if ns.db.adTargetsInit then return end
	local list = self:Joined()
	if #list == 0 then return end
	ns.db.adTargets = ns.db.adTargets or {}
	for _, c in ipairs(list) do
		if Kind(c.name) <= 3 then ns.db.adTargets[c.short:lower()] = true end
	end
	ns.db.adTargetsInit = true
end

function Rc:IsTarget(short)
	return ns.db.adTargets and ns.db.adTargets[short:lower()] and true or false
end

function Rc:SetTarget(short, on)
	ns.db.adTargets = ns.db.adTargets or {}
	ns.db.adTargets[short:lower()] = on and true or nil
	ns.db.adTargetsInit = true
	ns:Fire("GS_RECRUIT")
end

-- gewählte, beigetretene Kanäle in sinnvoller Reihenfolge
function Rc:Targets()
	local out = {}
	for _, c in ipairs(self:Joined()) do
		if self:IsTarget(c.short) then out[#out + 1] = c end
	end
	table.sort(out, function(a, b)
		local ka, kb = Kind(a.name), Kind(b.name)
		if ka == kb then return a.id < b.id end
		return ka < kb
	end)
	return out
end

-- nächster Kanal, der wieder dran ist (nil, Sekunden bis frei)
function Rc:NextTarget()
	local now = GetTime()
	local best, wait = nil, math.huge
	for _, c in ipairs(self:Targets()) do
		local left = (self.lastPost[c.short] or -1000) + self.CHANNEL_COOLDOWN - now
		if left <= 0 then return c, 0 end
		if left < wait then best, wait = c, left end
	end
	return nil, (wait < math.huge) and math.ceil(wait) or nil, best
end

function Rc:GlobalWait()
	return math.max(0, math.ceil(self.lastAny + self.GLOBAL_COOLDOWN - GetTime()))
end

------------------------------------------------------------
-- Werbung vorbereiten (nur aus einem Klick). Seit 0.9.23 sendet GuildSentinel nicht mehr selbst in einen Kanal
-- (WoW Forever blockiert das, ADDON_ACTION_BLOCKED): Die Chat-Eingabe öffnet sich mit "/<Kanal> <Text>", der Spieler
-- schickt mit Enter. Erst wenn der eigene Text im Kanal erscheint (CHAT_MSG_CHANNEL), zählt die Werbung als gepostet
-- (Wartezeiten, "zuletzt gepostet", Erinnerung).
------------------------------------------------------------
-- Text für einen Chat-Kanal vorbereiten (der Spieler schickt ihn mit Enter ab): "/<Kanalnummer> <Text>".
-- Selbst senden (SendChatMessage an "CHANNEL") blockiert WoW Forever für Addons – auch aus einem Klick.
-- Rückgabe: true und der Text, wie er in der Eingabe steht (gekürzt, falls "/<Kanal> <Text>" länger als 255 wäre).
function ns.OpenChannelChat(id, text)
	local prefix = "/" .. tostring(id) .. " "
	text = ns.CutBytes(ns.ChatSafe(text), 255 - #prefix)
	if ns.Test and ns.Test:Active() then ns.Test:Log("CHANNEL", id, text) return true, text end
	if not (ChatFrame_OpenChat and tonumber(id)) then return false end
	ns.Act("ChatFrame_OpenChat", ChatFrame_OpenChat, prefix .. text)
	return true, text
end

-- (steht hier und nicht in Core.lua: Core.lua sendet auch Addon-Nachrichten, dort meldet die Addon-Prüfung jedes
-- "CHANNEL" als eigenen Addon-Kanal)

Rc.PREPARED_FOR = 300       -- so lange (Sekunden) wartet ein vorbereiteter Text auf das Senden
Rc.AD_MAX = 251             -- Werbetext höchstens so lang: "/<Kanal> " (bis "/99 ") + Text <= 255 Zeichen der Chat-Eingabe

function Rc:Post()
	if not ns.InGuild() then ns:Print(L["Du bist in keiner Gilde."]) return false end
	local gw = self:GlobalWait()
	if gw > 0 then
		ns:Print(string.format(L["Bitte noch %d Sekunden warten."], gw))
		return false
	end
	local targets = self:Targets()
	if #targets == 0 then
		ns:Print(L["Kein Kanal gewählt oder keinem gewählten Kanal beigetreten. Wähle die Kanäle auf der Seite Rekrutierung."])
		return false
	end
	local c, wait = self:NextTarget()
	if not c then
		ns:Print(string.format(L["Alle gewählten Kanäle hatten gerade Werbung. Nächster in %d Sekunden."], wait or 0))
		return false
	end
	local text = self:AdText()
	if text == "" then return false end
	local ok, shown = ns.OpenChannelChat(c.id, text)
	if not ok then return false end
	-- im Testmodus nur angezeigt: nichts merken (die Zeit der letzten echten Werbung bleibt)
	if ns.Test and ns.Test:Active() then return true end
	-- genau den Text merken, der in der Eingabe steht (nach dem Kürzen) – den sendet der Spieler
	self.prepared = { short = c.short, id = c.id, text = shown, t = GetTime() }
	ns:Print(string.format(L["Werbung für %s steht in der Chat-Eingabe – mit Enter senden."], c.short))
	ns:Fire("GS_RECRUIT")
	return true
end

-- vorbereiteter Text ist im Kanal erschienen: jetzt erst als gepostet zählen
function Rc:Posted(short)
	self.prepared = nil
	self.lastPost[short] = GetTime()
	self.lastAny = GetTime()
	self.lastAdTime = ns.Now()
	ns.db.lastAdTime = self.lastAdTime
	self.reminded = false
	ns:Fire("GS_RECRUIT")
end

-- eigene Kanal-Nachricht: war es die vorbereitete Werbung?
-- (text, sender, …, channelIndex = 8. Wert). Geschützte Werte (Forever) werden übergangen.
function Rc.OnChannel(text, sender, _, _, _, _, _, index)
	local p = Rc.prepared
	if not p then return false end
	if GetTime() - p.t > Rc.PREPARED_FOR then Rc.prepared = nil return false end
	if ns.IsSecret(text) or ns.IsSecret(sender) or type(text) ~= "string" or type(sender) ~= "string" then return false end
	if not ns.Same(ns.Short(sender), ns.Me()) then return false end
	if tonumber(index) and tonumber(index) ~= p.id then return false end
	if ns.Trim(text) ~= ns.Trim(p.text) then return false end
	Rc:Posted(p.short)
	return true
end
ns:On("CHAT_MSG_CHANNEL", function(...) Rc.OnChannel(...) end)

-- Erinnerung, wenn die Werbung wieder fällig ist
C_Timer.NewTicker(30, function()
	if not ns.db or not ns.db.adRemind or not IsInGuild() then return end
	local last = ns.db.lastAdTime or 0
	if last == 0 or Rc.reminded then return end
	if ns.Now() - last >= (ns.db.adInterval or 15) * 60 then
		Rc.reminded = true
		ns:Print(L["Die Gildenwerbung ist wieder fällig. Minimap-Knopf: Rechtsklick bereitet sie im Chat vor."])
		ns:Fire("GS_RECRUIT")
	end
end)

function Rc:Due()
	local last = ns.db and ns.db.lastAdTime or 0
	return last > 0 and ns.Now() - last >= (ns.db.adInterval or 15) * 60
end

------------------------------------------------------------
-- Bewerber
------------------------------------------------------------
-- st: new, invited, declined, joined
function Rc:Keywords()
	local list = {}
	for w in Value("keywords", self:DefaultKeywords()):gmatch("[^,;]+") do
		w = ns.Trim(w):lower()
		if w ~= "" then list[#list + 1] = w end
	end
	return list
end

function Rc:Matches(msg)
	msg = (msg or ""):lower()
	for _, w in ipairs(self:Keywords()) do
		if msg:find(w, 1, true) then return true end
	end
	return false
end

function Rc:AddApplicant(name, msg, classFile, race)
	local g = ns.guild
	if not g then return end
	name = ns.Short(name)
	local a = g.apps[name] or { t = ns.Now(), st = "new" }
	a.msg = msg or a.msg
	a.last = ns.Now()
	a.c = classFile or a.c
	a.race = race or a.race
	if a.st == "declined" then a.st = "new" end    -- "agedecl" (unter dem Mindestalter) bleibt
	g.apps[name] = a
	ns:Fire("GS_APPS")
	return a
end

function Rc:Applicants(showAll)
	local out = {}
	for name, a in pairs(ns.G().apps) do
		if showAll or (a.st ~= "joined" and a.st ~= "declined" and a.st ~= "agedecl") then
			out[#out + 1] = { name = name, a = a }
		end
	end
	table.sort(out, function(x, y) return (x.a.last or x.a.t or 0) > (y.a.last or y.a.t or 0) end)
	return out
end

-- Einladen in die Gilde: Das Spiel (WoW Forever) verbietet Addons den direkten Aufruf (ADDON_ACTION_FORBIDDEN, auch
-- mit Mausklick). Deshalb kommt "/ginvite <Name>" in die Chat-Eingabe, der Spieler sendet mit Enter – dann führt
-- Blizzards eigener Befehl die Einladung aus. Namen mit Leerzeichen gehen so, wie sie sind (der Befehl nimmt den Rest
-- der Zeile). Der Status "eingeladen" kommt erst mit der Systemmeldung des Spiels (ERR_GUILD_INVITE_S).
function ns.OpenGuildInvite(name)
	name = ns.Trim(name or "")
	if name == "" then return false end
	local cmd = (type(SLASH_GUILD_INVITE1) == "string" and SLASH_GUILD_INVITE1:sub(1, 1) == "/") and SLASH_GUILD_INVITE1 or "/ginvite"
	local text = cmd .. " " .. name
	if ns.Test and ns.Test:Active() then ns.Test:Log("GINVITE", name, text) return true, text end
	if not ChatFrame_OpenChat then return false end
	ns.Act("ChatFrame_OpenChat", ChatFrame_OpenChat, text)
	if ns.Diag then ns.Diag("EINLADEN", "in die Chat-Eingabe gelegt") end
	return true, text
end

Rc.inviteSent = {}  -- Name -> Zeitpunkt, an dem "/ginvite" in die Chat-Eingabe gelegt wurde

function Rc:Invite(name)
	if not ns.CanInvite() then ns:Print(L["Dein Rang darf niemanden in die Gilde einladen."]) return false end
	local ap = ns.G().apps[name]
	if ap and ap.st == "agedecl" then ns:Print(L["Unter dem Mindestalter – Einladen gesperrt."]) return false end
	if not ns.OpenGuildInvite(name) then return false end
	self.inviteSent[name] = GetTime()
	ns:Print(string.format(L["„/ginvite %s“ steht in der Chat-Eingabe – mit Enter einladen."], name))
	return true
end

-- Systemmeldung "Ihr habt X eingeladen …": erst jetzt ist die Einladung wirklich raus
function Rc.OnInviteConfirmed(name)
	if not (ns.guild and name) then return false end
	name = ns.Short(name)
	Rc.inviteSent[name] = nil
	local a = ns.G().apps[name]
	if not a then return false end
	if a.st ~= "joined" then a.st = "invited"; a.ti = ns.Now() end
	ns:Fire("GS_APPS")
	return true
end

local P_INVITED
ns:On("CHAT_MSG_SYSTEM", function(msg)
	if type(msg) ~= "string" or ns.IsSecret(msg) or not ns.ToPattern then return end
	P_INVITED = P_INVITED or ns.ToPattern(ERR_GUILD_INVITE_S) or false
	local n = P_INVITED and msg:match(P_INVITED)
	if n then Rc.OnInviteConfirmed(n) end
end)

function Rc:SetStatus(name, st)
	local a = ns.G().apps[name]
	if not a then return end
	a.st = st
	ns:Fire("GS_APPS")
end

function Rc:Remove(name)
	ns.G().apps[name] = nil
	ns:Fire("GS_APPS")
end

function Rc:Whisper(name)
	if ns.Test and ns.Test:Active() then ns.Test:Log("WHISPER", name, "…") return end
	if ChatFrame_SendTell then ns.Act("ChatFrame_SendTell", ChatFrame_SendTell, name) end
end

local replied = {}

function Rc.OnWhisper(msg, sender, guid)
	if not ns.Feature("recruit") then return end
	if not ns.guild or not ns.db then return end
	local name = ns.Short(sender)
	if not name or ns.Roster.byName[name] then return end      -- schon in der Gilde
	local known = ns.guild.apps[name]
	if not known and not Rc:Matches(msg) then return end
	-- Antwort auf eine Bewerbungsfrage
	if known and Rc:TakeAnswer(name, msg, sender) then return end
	local classFile, race
	if guid and GetPlayerInfoByGUID then
		local _, cf, _, rc = GetPlayerInfoByGUID(guid)
		classFile, race = cf, rc
	end
	Rc:AddApplicant(name, msg, classFile, race)
	if not known then ns:Print(string.format(L["Neuer Bewerber: %s – siehe Seite Rekrutierung."], name)) end
	-- automatisch antworten (einmal je 10 Minuten)
	if ns.db.autoReply and (not replied[name] or GetTime() - replied[name] > 600) then
		replied[name] = GetTime()
		local text = Rc:Build(Value("replyText", Rc:DefaultReply()), { spieler = name })
		if text ~= "" then
			ns.Later(1.5, function() ns.Chat(text, "WHISPER", sender) end)
		end
	end
	-- danach die Bewerbungsfragen, eine nach der anderen
	if not known then Rc:StartQuestions(name, sender, 4) end
end
-- WoW Forever: im Kampf können Absender oder Text "secret values" sein. Solche Flüsternachrichten werden gemerkt
-- und nach dem Kampf noch einmal angesehen: Was dann lesbar ist (z. B. nur die GUID war geschützt), wird verarbeitet.
-- Ein geschützter Text oder Absender bleibt geschützt – diese Nachrichten werden nur gezählt und einmal gemeldet,
-- statt still verloren zu gehen. Höchstens 30 werden gemerkt; was darüber hinausgeht, zählt mit (combatDropped).
Rc.combatQueue = {}
Rc.combatDropped = 0
ns:On("CHAT_MSG_WHISPER", function(msg, sender, _, _, _, _, _, _, _, _, _, guid)
	if ns.IsSecret(msg) or ns.IsSecret(sender) or ns.IsSecret(guid) then
		if #Rc.combatQueue < 30 then
			Rc.combatQueue[#Rc.combatQueue + 1] = { msg, sender, guid }
		else
			Rc.combatDropped = Rc.combatDropped + 1
		end
		return
	end
	Rc.OnWhisper(msg, sender, guid)
end)
ns:On("PLAYER_REGEN_ENABLED", function()
	if #Rc.combatQueue == 0 and Rc.combatDropped == 0 then return end
	local q, dropped = Rc.combatQueue, Rc.combatDropped
	Rc.combatQueue, Rc.combatDropped = {}, 0
	C_Timer.After(0.5, function()
		-- Ein geschützter Wert bleibt geschützt, auch nach dem Kampf. Lesbare Einträge verarbeiten, die anderen
		-- zählen und einmal melden, damit keine Bewerbung still verloren geht. Überzählige (mehr als 30) gelten
		-- als nicht auswertbar und werden mitgezählt.
		local hidden = dropped
		for _, x in ipairs(q) do
			if ns.IsSecret(x[1]) or ns.IsSecret(x[2]) then
				hidden = hidden + 1
			else
				local ok, err = pcall(Rc.OnWhisper, x[1], x[2], (not ns.IsSecret(x[3])) and x[3] or nil)
				if not ok then ns.CountError("Whisper", err) end
			end
		end
		if hidden > 0 and ns.Feature("recruit") then
			ns:Print(string.format(L["%d Flüsternachricht(en) im Kampf nicht auswertbar – bitte den Chat prüfen."], hidden))
		end
	end)
end)

------------------------------------------------------------
-- Begrüßung neuer Mitglieder (nur einer begrüßt: wer zuerst Bescheid gibt)
------------------------------------------------------------
Rc.claimed = {}

Rc.claimBy = {}

ns.Comm:Register("WEL", function(sender, d)
	if type(d.n) ~= "string" then return end
	Rc.claimed[d.n] = GetTime()
	-- bei gleichzeitigem Anspruch gewinnt der alphabetisch erste Name
	local cur = Rc.claimBy[d.n]
	if not cur or sender < cur then Rc.claimBy[d.n] = sender end
end)

ns:Listen("GS_JOINED", function(name)
	if not ns.db or not ns.db.welcome or ns.Same(name, ns.Me()) then return end
	ns.Later(1 + math.random() * 4, function()
		local c = Rc.claimed[name]
		if c and GetTime() - c < 60 then return end
		Rc.claimed[name] = GetTime()
		Rc.claimBy[name] = ns.Me()
		ns.Comm:Send("WEL", { n = name }, "GUILD", nil, true)
		ns.Later(2, function()
			if Rc.claimBy[name] ~= ns.Me() then return end
			local text = Rc:Build(Value("welcomeText", Rc:DefaultWelcome()), { spieler = name })
			if text ~= "" then ns.Chat(text, "GUILD") end
		end)
	end)
end)

-- Vorschau der Begrüßung
function Rc:WelcomePreview()
	return self:Build(Value("welcomeText", self:DefaultWelcome()), { spieler = L["Neuling"] })
end

function Rc:ReplyPreview()
	return self:Build(Value("replyText", self:DefaultReply()), { spieler = L["Bewerber"] })
end

ns:Listen("GS_LOGIN", function()
	Rc.lastAdTime = ns.db.lastAdTime or 0
	C_Timer.After(5, function() Rc:EnsureTargets() end)
end)
ns:On("CHANNEL_UI_UPDATE", function() Rc:EnsureTargets(); ns:Fire("GS_RECRUIT") end)
