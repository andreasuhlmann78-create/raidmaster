if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Waves.lua (Rechenkern 0.66, Regel R4 der Prüf-Sitzung 14.11.)
-- Wellen je Stufenband: Die Levelwelle wandert ca. 1 Band je 1–2 Tage nach oben; ein Band fällt beim Durchziehen stark,
-- danach seitwärts. Band-Index = Mittel über die Entzauber-Materialien des Bands von (Tagesmedian / Tagesmedian am
-- ersten Tag des Fensters). Zustand: 2 Tage nacheinander > 15 % gefallen = "welle" (nicht kaufen/halten, zügig
-- verkaufen); die letzten 3 Tage je ±10 % = "durch"; sonst "offen". Nur Messung aus dem Preisverlauf (bestätigte Preise),
-- nichts gespeichert, nichts angezeigt (Anzeige erst mit dem neuen Markt-Reiter).
-- ============================================================
local A = AHAnalyzerPro
if not (A and A.On) then return end
local W = {}
A.Waves = W

-- Bänder nach den Entzauber-Materialien (Staub, Essenz, Splitter) - Itemstufe wie die Entzauber-Tabelle
W.BANDS = {
    { key = "5-25",  mats = { 10940, 10938, 10939, 10998, 10978 } },
    { key = "26-35", mats = { 11083, 11082, 11134, 11084, 11138 } },
    { key = "36-45", mats = { 11137, 11135, 11174, 11139, 11177 } },
    { key = "46-55", mats = { 11176, 11175, 16202, 11178, 14343 } },
    { key = "56-60", mats = { 16204, 16203, 14344, 20725 } },
}
W.DAYS = 10
W.FALL, W.FLAT = 0.15, 0.10

-- Tagesmediane (bestätigte Preise) eines Items: { [Tag] = Median }
function W:DailyMedians(itemID, from)
    local F, n = A:HF(itemID)
    local byDay = {}
    for i = 1, n do
        local b = (i - 1) * 5
        local t, p = F[b + 1], F[b + 2]
        if t >= from and F[b + 5] % 2 == 0 and p and p > 0 then
            local d = math.floor((t - from) / 86400) + 1
            local l = byDay[d] or {}
            l[#l + 1] = p
            byDay[d] = l
        end
    end
    local out = {}
    for d, l in pairs(byDay) do out[d] = A.Median(l) end
    return out
end

-- Index je Tag (1..DAYS) eines Bands; nil wo kein Material an diesem Tag einen Preis hat
function W:BandIndex(band, now)
    now = now or time()
    local from = A:DayStart(now) - (self.DAYS - 1) * 86400
    local sums, cnts = {}, {}
    for _, id in ipairs(band.mats) do
        local m = self:DailyMedians(id, from)
        local base
        for d = 1, self.DAYS do if m[d] then base = m[d]; break end end
        if base and base > 0 then
            for d = 1, self.DAYS do
                if m[d] then sums[d], cnts[d] = (sums[d] or 0) + m[d] / base, (cnts[d] or 0) + 1 end
            end
        end
    end
    local idx = {}
    for d = 1, self.DAYS do if cnts[d] then idx[d] = sums[d] / cnts[d] end end
    return idx
end

-- Zustand aus einer Index-Reihe (Tage mit Wert, älteste zuerst)
function W:StateOf(idx)
    local vals = {}
    for d = 1, self.DAYS do if idx[d] then vals[#vals + 1] = idx[d] end end
    local n = #vals
    if n < 3 then return "offen", vals end
    local f1 = vals[n - 1] > 0 and (vals[n] / vals[n - 1] - 1) or 0
    local f2 = vals[n - 2] > 0 and (vals[n - 1] / vals[n - 2] - 1) or 0
    if f1 < -self.FALL and f2 < -self.FALL then return "welle", vals end
    if n >= 4 then
        local flat = true
        for k = n - 2, n do
            if vals[k - 1] <= 0 or math.abs(vals[k] / vals[k - 1] - 1) > self.FLAT then flat = false end
        end
        if flat then return "durch", vals end
    end
    return "offen", vals
end

function W:States(now)
    local out = {}
    for _, band in ipairs(self.BANDS) do
        local ok, idx = pcall(self.BandIndex, self, band, now)
        local st, vals = "offen", {}
        if ok then st, vals = self:StateOf(idx) end
        out[#out + 1] = { key = band.key, state = st, days = #vals, last = vals[#vals] }
    end
    return out
end
-- Ist ein Item gerade in einem Band "in der Welle"? (für spätere Anzeige "nicht kaufen/halten")
function W:InWave(itemID, now)
    for _, band in ipairs(self.BANDS) do
        for _, id in ipairs(band.mats) do
            if id == itemID then
                local ok, idx = pcall(self.BandIndex, self, band, now)
                return ok and self:StateOf(idx) == "welle", band.key
            end
        end
    end
    return false
end
