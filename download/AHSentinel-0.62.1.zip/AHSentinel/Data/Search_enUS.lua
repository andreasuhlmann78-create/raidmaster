-- AHSentinel - Suchindex (enUS), aus Names_enUS.lua erzeugt. Nicht von Hand ändern.
AHAnalyzerPro_NameSearch = AHAnalyzerPro_NameSearch or {}
AHAnalyzerPro_NameSearch["enUS"] = [==[

25	worn shortsword
35	bent staff
36	worn mace
37	worn axe
38	recruit s shirt
39	recruit s pants
40	recruit s boots
43	squire s boots
44	squire s pants
45	squire s shirt
47	footpad s shoes
48	footpad s pants
49	footpad s shirt
51	neophyte s boots
52	neophyte s pants
53	neophyte s shirt
55	apprentice s boots
56	apprentice s robe
57	acolyte s robe
59	acolyte s shoes
60	layered tunic
61	dwarven leather pants
79	dwarven cloth britches
80	soft fur lined shoes
85	dirty leather vest
117	tough jerky
118	minor healing potion
120	thug pants
121	thug boots
127	trapper s shirt
129	rugged trapper s boots
139	brawler s pants
140	brawler s boots
147	rugged trapper s pants
148	rugged trapper s shirt
153	primitive kilt
154	primitive mantle
159	refreshing spring water
182	garrick s head
193	tattered cloth vest
194	tattered cloth pants
195	tattered cloth boots
200	thick cloth vest
201	thick cloth pants
202	thick cloth shoes
203	thick cloth gloves
209	dirty leather pants
210	dirty leather boots
236	cured leather armor
237	cured leather pants
238	cured leather boots
239	cured leather gloves
285	scalemail vest
286	scalemail pants
287	scalemail boots
414	dalaran sharp
422	dwarven mild
537	dull frenzy scale
555	rough vulture feathers
556	buzzard beak
647	destiny
710	bracers of the people s militia
711	tattered cloth gloves
714	dirty leather gloves
718	scalemail gloves
719	rabbit handler gloves
720	brawler gloves
723	goretusk liver
724	goretusk liver pie
725	gnoll paw
727	notched shortsword
728	recipe westfall stew
729	stringy vulture meat
730	murloc eye
731	goretusk snout
732	okra
733	westfall stew
735	rolf and malakai s medallions
737	holy spring water
738	sack of barley
739	sack of corn
740	sack of rye
742	a sycamore branch
743	bundle of charred oak
744	thunderbrew s boot flask
745	marshal mcbride s documents
748	stormwind armor marker
750	tough wolf meat
752	red burlap bandana
753	dragonmaw shortsword
754	shortsword of vengeance
755	melted candle
756	tunnel pick
763	ice covered bracers
765	silverleaf
766	flanged mace
767	long bo staff
768	lumberjack axe
769	chunk of boar meat
770	pointy crocolisk tooth
771	chipped boar tusk
772	large candle
773	gold dust
774	malachite
776	vendetta
777	prowler teeth
778	kobold excavation pick
779	shiny seashell
780	torn murloc fin
781	stone gnoll hammer
782	painted gnoll armband
783	light hide
785	mageroyal
787	slitherskin mackerel
789	stout battlehammer
790	forester s axe
791	gnarled ash staff
792	knitted sandals
793	knitted gloves
794	knitted pants
795	knitted tunic
796	rough leather boots
797	rough leather gloves
798	rough leather pants
799	rough leather vest
804	large blue sack
805	small red pouch
809	bloodrazor
810	hammer of the northern wind
811	axe of the deep woods
812	glowing brightwood staff
813	broken cog
814	flask of oil
816	small hand blade
818	tigerseye
820	slicer blade
821	riverpaw leather vest
826	brutish riverpaw axe
827	wicked blackjack
828	small blue pouch
829	red leather bandana
832	silver defias belt
833	lifestone
835	large rope net
837	heavy weave armor
838	heavy weave pants
839	heavy weave gloves
840	heavy weave shoes
841	furlbrow s pocket watch
843	tanned leather boots
844	tanned leather gloves
845	tanned leather pants
846	tanned leather jerkin
847	chainmail armor
848	chainmail pants
849	chainmail boots
850	chainmail gloves
851	cutlass
852	mace
853	hatchet
854	quarter staff
856	blue leather bag
857	large red sack
858	lesser healing potion
859	fine cloth shirt
860	cavalier s boots
862	runed ring
863	gloom reaper
864	knightly longsword
865	leaden mace
866	monk s staff
867	gloves of holy might
868	ardent custodian
869	dazzling longsword
870	fiery war axe
871	flurry axe
872	rockslicer
873	staff of jordan
875	brown horse summoning
876	worn wooden buckler
878	fist sized spinneret
880	staff of horrors
884	ghoul rib
885	black metal axe
886	black metal shortsword
887	pound of flesh
888	naga battle gloves
889	a dusty unsent letter
890	twisted chanter s staff
892	gnoll casting gloves
893	dire wolf fang
895	worgen skull
896	worgen fang
897	madwolf bracers
899	venom web fang
901	deptecated white stallion summoning mount
910	an undelivered letter
911	ironwood treebranch
913	huge ogre sword
914	large ogre chain armor
915	red silk bandana
916	a torn journal page
918	deviate hide pack
920	wicked spiked mace
921	a faded journal page
922	dacian falx
923	longsword
924	maul
925	flail
926	battle axe
927	double axe
928	long staff
929	healing potion
932	fel steed saddlebags
933	large rucksack
934	stalvan s reaper
935	night watch shortsword
936	midnight mace
937	black duskwood staff
938	muddy journal pages
939	a bloodstained journal page
940	robes of insight
942	freezing band
943	warden staff
944	elemental mage staff
945	shadow sword
948	nature sword
954	scroll of strength
955	scroll of intellect
957	william s shipment
961	healing herb
962	pork belly pie
966	tome of frost shield
967	tome of frost ward
968	tome of fire blast
973	tome of fireball ii
974	tome of frost armor ii
975	tome of chains of ice
976	tome of remove curse
980	tome of frost shield ii
981	bernice s necklace
983	red linen sash
985	tome of khadgar s unlocking
986	tome of frostbolt ii
989	tome of frost nova
992	tome of fireball iii
994	tome of ice armor
997	fire sword of crippling
1004	tome of chains of ice ii
1006	brass collar
1008	well used sword
1009	compact hammer
1010	gnarled short staff
1011	sharp axe
1013	iron rivet
1015	lean wolf flank
1017	seasoned wolf kabob
1019	red linen bandana
1029	tablet of serpent totem
1030	tablet of unyielding will
1031	tablet of molten blast
1032	tablet of agitating totem
1033	tablet of nullify poison
1034	tablet of undying strength
1035	tablet of call spirit
1036	tablet of nullify disease
1037	tablet of lightning bolt ii
1038	tablet of restoration ii
1041	horn of the black wolf
1048	tablet of lightning shield ii
1049	tablet of purge
1052	tablet of spirit armor ii
1053	tablet of molten blast ii
1057	tablet of restoration iii
1058	tablet of lightning bolt iii
1061	tablet of nullify poison ii
1063	tablet of nullify disease ii
1072	full moonshine
1074	hard spider leg tip
1075	shadowhide pendant
1076	defias renegade ring
1077	defias mage ring
1080	tough condor meat
1081	crisp spider meat
1082	redridge goulash
1083	glyph of azora
1084	codex of renew
1085	codex of mind vision
1086	codex of inner fire
1087	codex of shadow word pain
1088	codex of renew ii
1089	codex of nullify disease
1090	codex of resurrection
1091	codex of holy smite ii
1092	codex of lesser heal ii
1093	codex of remove curse
1095	codex of dispel magic
1096	codex of shadow word pain ii
1100	monster bag
1101	codex of renew v
1102	codex of lesser heal iii
1105	codex of renew vi
1108	codex of renew iii
1109	codex of dominate
1111	codex of sleep
1112	codex of holy word fortitude ii
1113	conjured bread
1114	conjured rye
1116	ring of pure silver
1119	bottled spirits
1121	feet of the lynx
1127	flash bundle
1129	ghoul fang
1130	vial of spider venom
1131	totem of infliction
1132	horn of the timber wolf
1133	horn of the winter wolf
1134	horn of the gray wolf
1136	libram divine favor ii
1138	libram divine favor
1139	libram cleanse
1141	libram holy light ii
1144	libram divine shield
1146	libram resurrection
1149	libram seal of might ii
1150	libram purify
1151	libram holy light iii
1154	belt of the people s militia
1155	rod of the sleepwalker
1156	lavishly jeweled ring
1158	solid metal club
1159	militia quarterstaff
1161	militia shortsword
1164	sam s tome
1166	dented buckler
1167	small targe
1168	skullflame shield
1169	blackskull shield
1171	well stitched robe
1172	grayson s torch
1173	weather worn boots
1175	a gold tooth
1176	smelling salts
1177	oil of olaf
1178	explosive rocket
1179	ice cold milk
1180	scroll of stamina
1181	scroll of spirit
1182	brass studded bracers
1183	elastic wristguards
1187	spiked collar
1189	overseer s ring
1190	overseer s cloak
1191	bag of marbles
1193	banded buckler
1194	bastard sword
1195	kobold mining shovel
1196	tabar
1197	giant mace
1198	claymore
1199	charged soulstone
1200	large wooden shield
1201	dull heater shield
1202	wall shield
1203	aegis of stormwind
1204	the green tower
1205	melon juice
1206	moss agate
1207	murphstar
1208	maybell s love letter
1210	shadowgem
1211	gnoll war harness
1212	gnoll spittle
1213	gnoll kindred bracers
1214	gnoll punisher
1215	support girdle
1216	frost bracers
1217	unknown reward
1218	heavy gnoll war club
1219	redridge machete
1220	lupine axe
1221	underbelly whelp scale
1222	broken tooth
1224	grimoire of sense demons
1228	grimoire of blood boil
1229	grimoire of create soulstone
1231	grimoire of shadow bolt ii
1232	grimoire of demon skin ii
1238	grimoire of fear
1239	grimoire of siphon mana
1243	grimoire of shadow bolt iii
1244	grimoire of demon armor
1245	grimoire of immolate ii
1246	grimoire of demon breath
1250	grimoire of detect lesser invisibility
1251	linen bandage
1252	gramma stonefield s note
1254	lesser firestone
1256	crystal kelp frond
1257	invisibility liquor
1260	tharil zun s head
1261	midnight orb
1262	keg of thunderbrew lager
1263	brain hacker
1264	headbasher
1265	scorpion sting
1270	finely woven cloak
1273	forest chain
1274	hops
1275	deputy chain coat
1276	fire hardened buckler
1280	cloaked hood
1282	sparkmetal coif
1283	verner s note
1284	crate of horseshoes
1287	giant tarantula fang
1288	large venom sac
1292	butcher s cleaver
1293	the state of lakeshire
1294	the general s response
1296	blackrock mace
1297	robes of the shadowcaster
1299	lesser belt of the spire
1300	lesser staff of the spire
1302	black whelp gloves
1303	bridgeworker s gloves
1304	riding gloves
1306	wolfmane wristguards
1307	gold pickup schedule
1309	oslow s toolbox
1310	smith s trousers
1314	ghoul fingers
1315	lei of lilies
1317	hardened root staff
1318	night reaver
1319	ring of iron will
1322	fishliver oil
1325	daffodil bouquet
1326	sauteed sunfish
1327	wiley s note
1328	book of faerie fire
1332	book of cure poison
1334	book of rejuvenation ii
1339	book of entangling roots
1341	book of moonfire
1349	abercrombie s crate
1351	fingerbone bracers
1352	cracked skull mortar
1353	shaw s report
1355	buckskin cape
1356	commendation elwynn forest
1357	captain sander s treasure map
1358	a clue to sander s treasure
1359	lion stamped gloves
1360	stormwind chain gloves
1361	another clue to sander s treasure
1362	final clue to sander s treasure
1364	ragged leather vest
1366	ragged leather pants
1367	ragged leather boots
1368	ragged leather gloves
1369	ragged leather belt
1370	ragged leather bracers
1372	ragged cloak
1374	frayed shoes
1376	frayed cloak
1377	frayed gloves
1378	frayed pants
1380	frayed robe
1381	a mysterious message
1382	rock mace
1383	stone tomahawk
1384	dull blade
1386	thistlewood axe
1387	ghoulfang
1388	crooked staff
1389	kobold mining mallet
1391	riverpaw mystic staff
1394	driftwood club
1395	apprentice s pants
1396	acolyte s pants
1399	magic candle
1400	swiftfeather token
1401	green tea leaf
1402	brimstone
1404	tidal charm
1405	foamspittle staff
1406	pearl encrusted spear
1407	solomon s plea to westfall
1408	stoutmantle s response to solomon
1409	solomon s plea to darkshire
1410	ebonlocke s response to solomon
1411	withered staff
1412	crude bastard sword
1413	feeble sword
1414	cracked sledge
1415	carpenter s mallet
1416	rusty hatchet
1417	beaten battle axe
1418	worn leather belt
1419	worn leather boots
1420	worn leather bracers
1421	worn hide cloak
1422	worn leather gloves
1423	worn leather pants
1425	worn leather vest
1427	patchwork shoes
1429	patchwork cloak
1430	patchwork gloves
1431	patchwork pants
1433	patchwork armor
1434	glowing wax stick
1436	frontier britches
1438	warrior s shield
1440	gnoll skull basher
1443	jeweled amulet of cainwyn
1445	blackrock pauldrons
1446	blackrock boots
1447	ring of saviors
1448	blackrock gauntlets
1449	minor channeling ring
1450	potion of fervor
1451	bottle of zombie juice
1453	spectral comb
1454	axe of the enforcer
1455	blackrock champion s axe
1457	shadowhide mace
1458	shadowhide maul
1459	shadowhide scalper
1460	shadowhide two handed sword
1461	slayer s battle axe
1462	ring of the shadow
1464	buzzard talon
1465	tigerbane
1467	spotted sunfish
1468	murloc fin
1469	scimitar of atun
1470	murloc skin bag
1473	riverside staff
1475	small venom sac
1476	snapped spider limb
1477	scroll of agility ii
1478	scroll of protection ii
1479	salma s oven mitts
1480	fist of the people s militia
1481	grimclaw
1482	shadowfang
1483	face smasher
1484	witching stave
1485	pitchfork
1486	tree bark jacket
1487	conjured pumpernickel
1488	avenger s armor
1489	gloomshroud armor
1490	guardian talisman
1491	ring of precision
1493	heavy marauder scimitar
1495	calico shoes
1497	calico cloak
1498	calico gloves
1499	calico pants
1500	master totem
1501	calico tunic
1502	warped leather belt
1503	warped leather boots
1504	warped leather bracers
1505	warped cloak
1506	warped leather gloves
1507	warped leather pants
1509	warped leather vest
1510	heavy hammer
1511	commoner s sword
1512	crude battle axe
1514	rusty warhammer
1515	rough wooden staff
1516	worn hatchet
1518	ghost hair comb
1519	bloodscalp ear
1520	troll sweat
1521	lumbering ogre axe
1522	headhunting spear
1523	huge stone club
1524	skullsplitter tusk
1528	handful of oats
1529	jade
1532	shrunken head
1534	libram holy light iv
1536	libram seal of wrath
1539	gnarled hermit s staff
1547	shield of the faith
1554	tome of frostbolt iii
1557	buckler of the seas
1559	tome of arcane missiles ii
1560	bluegill sandals
1561	harvester s robe
1566	edge of the people s militia
1567	tome of khadgar s unlocking ii
1568	tome of water elemental
1571	tome of frost nova ii
1574	tome of fire ward
1588	tablet of molten blast iii
1589	tablet of spirit armor iii
1591	tablet of lightning shield iii
1596	ghost hair thread
1597	tablet of lightning storm
1598	rot blossom
1602	sickle axe
1603	tablet of call spirit ii
1604	chromatic sword
1607	soulkeeper
1608	skullcrusher mace
1613	spiritchaser staff
1619	tablet of lightning storm ii
1623	raptor skin pouch
1624	skullsplitter helm
1625	exquisite flamberge
1630	broken electro lantern
1637	letter to ello
1639	grinning axe
1640	monstrous war axe
1641	codex of shadow word pain iii
1645	moonberry juice
1648	codex of heal iv
1651	codex of holy word shield vi
1652	sturdy lunchbox
1656	translated letter
1657	codex of resurrection ii
1658	codex of shadow word pain iv
1659	engineering gloves
1664	spellforce rod
1676	codex of sleep ii
1677	drake scale vest
1678	black ogre kickers
1679	korg bat
1680	headchopper
1681	grimoire of cripple
1685	troll hide bag
1686	bristly whisker
1687	retractable claw
1688	long soft tail
1696	curved raptor talon
1697	keen raptor tooth
1701	curved basilisk claw
1702	intact basilisk spine
1703	crystal basilisk spine
1705	lesser moonstone
1706	azuredeep shards
1707	stormwind brie
1708	sweet nectar
1710	greater healing potion
1711	scroll of stamina ii
1712	scroll of spirit ii
1713	ankh of life
1714	necklace of calisea
1715	polished jazeraint armor
1716	robe of the magi
1717	double link tunic
1718	basilisk hide pants
1720	tanglewood staff
1721	viking warhammer
1722	thornstone sledgehammer
1725	large knapsack
1726	poison tipped bone spear
1727	sword of decay
1728	teebu s blazing longsword
1729	gunnysack of the night watch
1730	worn mail belt
1731	worn mail boots
1732	worn mail bracers
1733	worn cloak
1734	worn mail gloves
1735	worn mail pants
1737	worn mail vest
1738	laced mail belt
1739	laced mail boots
1740	laced mail bracers
1741	laced cloak
1742	laced mail gloves
1743	laced mail pants
1744	laced mail shoulderpads
1745	laced mail vest
1746	linked chain belt
1747	linked chain boots
1748	linked chain bracers
1749	linked chain cloak
1750	linked chain gloves
1751	linked chain pants
1752	linked chain shoulderpads
1753	linked chain vest
1754	reinforced chain belt
1755	reinforced chain boots
1756	reinforced chain bracers
1757	reinforced chain cloak
1758	reinforced chain gloves
1759	reinforced chain pants
1760	reinforced chain shoulderpads
1761	reinforced chain vest
1764	canvas shoes
1766	canvas cloak
1767	canvas gloves
1768	canvas pants
1769	canvas shoulderpads
1770	canvas vest
1772	brocade shoes
1774	brocade cloak
1775	brocade gloves
1776	brocade pants
1777	brocade shoulderpads
1778	brocade vest
1780	cross stitched sandals
1782	cross stitched cloak
1783	cross stitched gloves
1784	cross stitched pants
1785	cross stitched shoulderpads
1786	cross stitched vest
1787	patched leather belt
1788	patched leather boots
1789	patched leather bracers
1790	patched cloak
1791	patched leather gloves
1792	patched leather pants
1793	patched leather shoulderpads
1794	patched leather jerkin
1795	rawhide belt
1796	rawhide boots
1797	rawhide bracers
1798	rawhide cloak
1799	rawhide gloves
1800	rawhide pants
1801	rawhide shoulderpads
1802	rawhide tunic
1803	tough leather belt
1804	tough leather boots
1805	tough leather bracers
1806	tough cloak
1807	tough leather gloves
1808	tough leather pants
1809	tough leather shoulderpads
1810	tough leather armor
1811	blunt claymore
1812	short handled battle axe
1813	chipped quarterstaff
1814	battered mallet
1815	ornamental mace
1816	unbalanced axe
1817	stock shortsword
1818	standard claymore
1819	gouging pick
1820	wooden maul
1821	warped blade
1822	cedar walking stick
1823	bludgeoning cudgel
1824	shiny war axe
1825	bulky bludgeon
1826	rock maul
1827	meat cleaver
1828	stone war axe
1829	short cutlass
1830	long bastard sword
1831	oaken war staff
1832	lucky trousers
1835	dirty leather belt
1836	dirty leather bracers
1839	rough leather belt
1840	rough leather bracers
1843	tanned leather belt
1844	tanned leather bracers
1845	chainmail belt
1846	chainmail bracers
1849	cured leather belt
1850	cured leather bracers
1851	cleansing water
1852	scalemail bracers
1853	scalemail belt
1875	thistlenettle s badge
1877	book of rejuvenation iii
1882	book of moonfire iii
1886	book of moonfire ii
1893	miner s revenge
1894	miners union card
1913	studded blackjack
1917	jeweled dagger
1922	supplies for sven
1923	ambassador s satchel
1925	defias rapier
1926	weighted sap
1927	deadmines cleaver
1928	defias mage staff
1929	silk threaded trousers
1930	stonemason cloak
1931	huge gnoll claw
1933	staff of conjuring
1934	stonemason trousers
1935	assassin s blade
1936	goblin screwdriver
1937	buzz saw
1938	block mallet
1939	skin of sweet rum
1941	cask of merlot
1942	bottle of moonshine
1943	goblin mail leggings
1944	metalworking gloves
1945	woodworking gloves
1946	mary s looking glass
1951	blackwater cutlass
1955	dragonmaw chain boots
1956	faded shadowhide pendant
1958	petrified shinbone
1959	cold iron pick
1962	glowing shadowhide pendant
1965	white wolf gloves
1968	ogre s monocle
1970	restoring balm
1971	furlbrow s deed
1972	westfall deed
1973	orb of deception
1974	mindthrust bracers
1976	slaghammer
1977	20 slot bag
1978	wolfclaw gloves
1979	wall of the dead
1980	underworld band
1981	icemail jerkin
1982	nightblade
1986	gutrender
1987	krazek s fixed pot
1988	chief brigadier gauntlets
1990	ballast maul
1991	goblin power shovel
1992	swampchill fetish
1993	ogremind ring
1994	ebonclaw reaver
1996	voodoo band
1997	pressed felt robe
1998	bloodscalp channeling staff
2000	archeus
2004	grelin whitebeard s journal
2005	the first troll legend
2006	the second troll legend
2007	the third troll legend
2008	the fourth troll legend
2011	twisted sabre
2013	cryptbone staff
2014	black metal greatsword
2015	black metal war axe
2016	dusty chain armor
2017	glowing leather bracers
2018	skeletal longsword
2020	hollowfang blade
2021	green carapace shield
2024	espadon
2025	bearded axe
2026	rock hammer
2027	scimitar
2028	hammer
2029	cleaver
2030	gnarled staff
2032	gallan cuffs
2033	ambassador s boots
2034	scholarly robes
2035	sword of the night sky
2036	dusty mining gloves
2037	tunneler s boots
2039	plains ring
2040	troll protector
2041	tunic of westfall
2042	staff of westfall
2043	ring of forlorn spirits
2044	crescent of forlorn spirits
2046	bluegill kukri
2047	anvilmar hand axe
2048	anvilmar hammer
2054	trogg hand axe
2055	small wooden hammer
2056	the velvet hammer
2057	pitted defias shortsword
2058	kazon s maul
2059	sentry cloak
2064	trogg club
2065	rockjaw blade
2066	skull hatchet
2067	frostbit staff
2069	black bear hide vest
2070	darnassian bleu
2072	dwarven magestaff
2073	dwarven hatchet
2074	solid shortblade
2075	priest s mace
2077	magician staff
2078	northern shortsword
2079	sergeant s warhammer
2080	hillborne axe
2082	wizbang s gunnysack
2084	darksteel bastard sword
2085	chunk of flesh
2087	hard crawler carapace
2088	long crawler limb
2089	scrimshaw dagger
2091	magic dust
2092	worn dagger
2098	double barreled shotgun
2099	dwarven hand cannon
2100	precisely calibrated boomstick
2101	light quiver
2102	small ammo pouch
2105	thug shirt
2108	frostmane leather vest
2109	frostmane chain vest
2110	light magesmith robe
2112	lumberjack jerkin
2113	calor s note
2114	snowy robe
2117	thin cloth shoes
2119	thin cloth gloves
2120	thin cloth pants
2121	thin cloth armor
2122	cracked leather belt
2123	cracked leather boots
2124	cracked leather bracers
2125	cracked leather gloves
2126	cracked leather pants
2127	cracked leather vest
2128	scratched claymore
2129	large round shield
2130	club
2131	shortsword
2132	short staff
2133	small shield
2134	hand axe
2136	conjured purified water
2137	whittling knife
2138	sharpened letter opener
2139	dirk
2140	carving knife
2141	cuirboulli vest
2142	cuirboulli belt
2143	cuirboulli boots
2144	cuirboulli bracers
2145	cuirboulli gloves
2146	cuirboulli pants
2148	polished scale belt
2149	polished scale boots
2150	polished scale bracers
2151	polished scale gloves
2152	polished scale leggings
2153	polished scale vest
2154	the story of morgan ladimore
2156	padded boots
2158	padded gloves
2159	padded pants
2160	padded armor
2161	book from sven s farm
2162	sarah s ring
2163	shadowblade
2164	gut ripper
2166	foreman s leggings
2167	foreman s gloves
2168	foreman s boots
2169	buzzer blade
2172	rustic belt
2175	shadowhide battle axe
2186	outfitter belt
2187	a stack of letters
2188	a letter to grelin whitebeard
2194	diamond hammer
2195	anvilmar knife
2203	brashclaw s chopper
2204	brashclaw s skewer
2205	duskbringer
2207	jambiya
2208	poniard
2209	kris
2210	battered buckler
2211	bent large shield
2212	cracked buckler
2213	worn large shield
2214	wooden buckler
2215	wooden shield
2216	simple buckler
2217	rectangular shield
2218	craftsman s dagger
2219	small round shield
2220	box shield
2221	targe shield
2222	tower shield
2223	the collector s schedule
2224	militia dagger
2225	sharp kitchen knife
2226	ogremage staff
2227	heavy ogre war axe
2230	gloves of brawn
2231	inferno robe
2232	dark runner boots
2233	shadow weaver leggings
2234	nightwalker armor
2235	brackclaw
2236	blackfang
2237	patched pants
2238	urchin s pants
2239	the collector s ring
2240	rugged cape
2241	desperado cape
2243	hand of edward the odd
2244	krol blade
2245	helm of narv
2246	myrmidon s signet
2249	militia buckler
2250	dusky crab cakes
2251	gooey spider leg
2252	miscellaneous goblin supplies
2254	icepane warhammer
2256	skeletal club
2257	frostmane staff
2258	frostmane shortsword
2259	frostmane club
2260	frostmane hand axe
2262	mark of kern
2263	phytoblade
2264	mantle of thieves
2265	stonesplinter axe
2266	stonesplinter dagger
2267	stonesplinter mace
2268	stonesplinter blade
2271	staff of the blessed seer
2273	guerrilla armor
2274	sapper s gloves
2276	swampwalker boots
2277	necromancer leggings
2278	forest tracker epaulets
2280	kam s walking stick
2281	rodentia flint axe
2282	rodentia shortsword
2283	rat cloth belt
2284	rat cloth cloak
2287	haunch of meat
2288	conjured fresh water
2289	scroll of strength ii
2290	scroll of intellect ii
2291	kang the decapitator
2292	necrology robes
2295	large boar tusk
2296	great goretusk snout
2299	burning war axe
2300	embossed leather vest
2302	handstitched leather boots
2303	handstitched leather pants
2304	light armor kit
2307	fine leather boots
2308	fine leather cloak
2309	embossed leather boots
2310	embossed leather cloak
2311	white leather jerkin
2312	fine leather gloves
2313	medium armor kit
2314	toughened leather armor
2315	dark leather boots
2316	dark leather cloak
2317	dark leather tunic
2318	light leather
2319	medium leather
2320	coarse thread
2321	fine thread
2324	bleach
2325	black dye
2326	ivy weave bracers
2327	sturdy leather bracers
2361	battleworn hammer
2362	worn wooden shield
2364	woven vest
2366	woven pants
2367	woven boots
2369	woven gloves
2370	battered leather harness
2371	battered leather belt
2372	battered leather pants
2373	battered leather boots
2374	battered leather bracers
2375	battered leather gloves
2376	worn heater shield
2377	round buckler
2378	skeleton finger
2379	tarnished chain vest
2380	tarnished chain belt
2381	tarnished chain leggings
2382	the embalmer s heart
2383	tarnished chain boots
2384	tarnished chain bracers
2385	tarnished chain gloves
2386	rusted chain vest
2387	rusted chain belt
2388	rusted chain leggings
2389	rusted chain boots
2390	rusted chain bracers
2391	rusted chain gloves
2392	light mail armor
2393	light mail belt
2394	light mail leggings
2395	light mail boots
2396	light mail bracers
2397	light mail gloves
2398	light chain armor
2399	light chain belt
2400	light chain leggings
2401	light chain boots
2402	light chain bracers
2403	light chain gloves
2406	pattern fine leather boots
2407	pattern white leather jerkin
2408	pattern fine leather gloves
2409	pattern dark leather tunic
2410	smoky torch
2411	black stallion bridle
2413	palomino
2414	pinto bridle
2415	white stallion
2417	augmented chain vest
2418	augmented chain leggings
2419	augmented chain belt
2420	augmented chain boots
2421	augmented chain bracers
2422	augmented chain gloves
2423	brigandine vest
2424	brigandine belt
2425	brigandine leggings
2426	brigandine boots
2427	brigandine bracers
2428	brigandine gloves
2429	russet vest
2431	russet pants
2432	russet boots
2434	russet gloves
2435	embroidered armor
2437	embroidered pants
2438	embroidered boots
2440	embroidered gloves
2441	ringed buckler
2442	reinforced targe
2443	metal buckler
2444	ornate buckler
2445	large metal shield
2446	kite shield
2447	peacebloom
2448	heavy pavise
2449	earthroot
2450	briarthorn
2451	crested heater shield
2452	swiftthistle
2453	bruiseweed
2454	elixir of lion s strength
2455	minor mana potion
2456	minor rejuvenation potion
2457	elixir of minor agility
2458	elixir of minor fortitude
2459	swiftness potion
2460	elixir of tongues nyi
2463	studded doublet
2464	studded belt
2465	studded pants
2466	skullsplitter fetish
2467	studded boots
2468	studded bracers
2469	studded gloves
2470	reinforced leather vest
2471	reinforced leather belt
2472	reinforced leather pants
2473	reinforced leather boots
2474	reinforced leather bracers
2475	reinforced leather gloves
2476	chilled basilisk haunch
2477	ravager s skull
2479	broad axe
2480	large club
2481	peon sword
2482	inferior tomahawk
2483	rough broad axe
2484	small knife
2485	splintered board
2486	large stone mace
2487	acolyte staff
2488	gladius
2489	two handed sword
2490	tomahawk
2491	large axe
2492	cudgel
2493	wooden mallet
2494	stiletto
2495	walking stick
2496	raider shortsword
2497	rusted claymore
2498	small tomahawk
2499	double bladed axe
2500	light hammer
2501	wooden warhammer
2502	scuffed dagger
2503	adept short staff
2504	worn shortbow
2505	polished shortbow
2506	hornwood recurve bow
2507	laminated recurve bow
2509	ornate blunderbuss
2510	solid blunderbuss
2511	hunter s boomstick
2512	rough arrow
2514	depricated sharp arrow
2515	sharp arrow
2516	light shot
2519	heavy shot
2520	broadsword
2521	flamberge
2522	crescent axe
2523	bullova
2524	truncheon
2525	war hammer
2526	main gauche
2527	battle staff
2528	falchion
2529	zweihander
2530	francisca
2531	great axe
2532	morning star
2533	war maul
2534	rondel
2535	war staff
2536	trogg stone tooth
2545	malleable chain leggings
2546	royal frostmane girdle
2547	boar handler gloves
2548	barrel of barleybrew scalder
2549	staff of the shade
2553	recipe elixir of minor agility
2555	recipe swiftness potion
2556	recipe elixir of tongues
2560	jitters completed journal
2561	chok sul s head
2562	bouquet of scarlet begonias
2563	strange smelling powder
2564	elven spirit claws
2565	rod of molten fire
2566	sacrificial robes
2567	evocator s blade
2568	brown linen vest
2569	linen boots
2570	linen cloak
2571	viny wrappings
2572	red linen robe
2575	red linen shirt
2576	white linen shirt
2577	blue linen shirt
2578	barbaric linen vest
2579	green linen shirt
2580	reinforced linen cape
2581	heavy linen bandage
2582	green woolen vest
2583	woolen boots
2584	woolen cape
2585	gray woolen robe
2586	gamemaster s robe
2587	gray woolen shirt
2589	linen cloth
2590	forest spider webbing
2591	dirty trogg cloth
2592	wool cloth
2593	flask of port
2594	flagon of mead
2595	jug of bourbon
2596	skin of dwarven stout
2598	pattern red linen robe
2601	pattern gray woolen robe
2604	red dye
2605	green dye
2606	lurker venom
2607	mo grosh crystal
2608	threshadon ambergris
2609	disarming colloid
2610	disarming mixture
2611	crude flint
2612	plain robe
2613	double stitched robes
2614	robe of apprenticeship
2615	chromatic robe
2616	shimmering silk robes
2617	burning robes
2618	silver dress robes
2619	grelin s report
2620	augural shroud
2621	cowl of necromancy
2622	nimar s tribal headdress
2623	holy diadem
2624	thinking cap
2625	menethil statuette
2628	senir s report
2629	intrepid strongbox key
2632	curved dagger
2633	jungle remedy
2634	venom fern extract
2635	loose chain belt
2636	carved stone idol
2637	ironband s progress report
2639	merrin s letter
2640	miners gear
2642	loose chain boots
2643	loose chain bracers
2644	loose chain cloak
2645	loose chain gloves
2646	loose chain pants
2648	loose chain vest
2649	flimsy chain belt
2650	flimsy chain boots
2651	flimsy chain bracers
2652	flimsy chain cloak
2653	flimsy chain gloves
2654	flimsy chain pants
2656	flimsy chain vest
2657	red leather bag
2658	ados fragment
2659	modr fragment
2660	golm fragment
2661	neru fragment
2662	ribbly s quiver
2663	ribbly s bandolier
2664	spinner fang
2665	stormwind seasoning herbs
2666	barrel of thunder ale
2667	macgrann s dried meats
2668	threshadon tooth
2669	threshadon claw
2671	wendigo mane
2672	stringy wolf meat
2673	coyote meat
2674	crawler meat
2675	crawler claw
2676	shimmerweed
2677	boar ribs
2678	mild spices
2679	charred wolf meat
2680	spiced wolf meat
2681	roasted boar meat
2682	cooked crab claw
2683	crab cake
2684	coyote steak
2685	succulent pork ribs
2686	thunder ale
2687	dry pork ribs
2688	squirrel nut
2690	latched belt
2691	outfitter boots
2692	hot spices
2693	stormwind seasoning salts
2694	settler s leggings
2696	cask of evershine
2697	recipe goretusk liver pie
2698	recipe cooked crab claw
2699	recipe redridge goulash
2700	recipe succulent pork ribs
2701	recipe seasoned wolf kabob
2702	lightforge ingot
2712	crate of lightforge ingots
2713	ol sooty s head
2719	small brass key
2720	muddy note
2721	holy shroud
2722	wine ticket
2723	bottle of pinot noir
2724	cloth request
2725	green hills of stranglethorn page 1
2728	green hills of stranglethorn page 4
2730	green hills of stranglethorn page 6
2732	green hills of stranglethorn page 8
2734	green hills of stranglethorn page 10
2735	green hills of stranglethorn page 11
2738	green hills of stranglethorn page 14
2740	green hills of stranglethorn page 16
2742	green hills of stranglethorn page 18
2744	green hills of stranglethorn page 20
2745	green hills of stranglethorn page 21
2748	green hills of stranglethorn page 24
2749	green hills of stranglethorn page 25
2750	green hills of stranglethorn page 26
2751	green hills of stranglethorn page 27
2754	tarnished bastard sword
2755	green hills of stranglethorn
2756	green hills of stranglethorn chapter i
2757	green hills of stranglethorn chapter ii
2758	green hills of stranglethorn chapter iii
2759	green hills of stranglethorn chapter iv
2760	thurman s sewing kit
2763	fisherman knife
2764	small dagger
2765	hunting knife
2766	deft stiletto
2770	copper ore
2771	tin ore
2772	iron ore
2773	cracked shortbow
2774	rust covered blunderbuss
2775	silver ore
2776	gold ore
2777	feeble shortbow
2778	cheap blunderbuss
2779	tear of tilloa
2780	light hunting bow
2781	dirty blunderbuss
2782	mishandled recurve bow
2783	shoddy blunderbuss
2784	musquash root
2785	stiff recurve bow
2786	oiled blunderbuss
2787	trogg dagger
2788	black claw stout
2795	book stresses of iron
2797	heart of mokk
2798	rethban ore
2799	gorilla fang
2800	black velvet robes
2801	blade of hanna
2802	blazing emblem
2805	yeti fur cloak
2806	package for stormpike
2807	guillotine axe
2808	torch of holy flame
2815	curve bladed ripper
2816	death speaker scepter
2817	soft leather tunic
2818	stretched leather trousers
2819	cross dagger
2820	nifty stopwatch
2821	mo grosh masher
2822	mo grosh toothpick
2823	mo grosh can opener
2824	hurricane
2825	bow of searing arrows
2828	nissa s remains
2829	gregor s remains
2830	thurman s remains
2831	devlin s remains
2832	verna s westfall stew recipe
2833	the lich s spellbook
2834	embalming ichor
2835	rough stone
2836	coarse stone
2837	thurman s letter
2838	heavy stone
2839	a letter to yvette
2840	copper bar
2841	bronze bar
2842	silver bar
2843	dirty knucklebones
2844	copper mace
2845	copper axe
2846	tirisfal pumpkin
2847	copper shortsword
2848	bronze mace
2849	bronze axe
2850	bronze shortsword
2851	copper chain belt
2852	copper chain pants
2853	copper bracers
2854	runed copper bracers
2855	putrid claw
2856	iron pike
2857	runed copper belt
2858	darkhound blood
2859	vile fin scale
2862	rough sharpening stone
2863	coarse sharpening stone
2864	runed copper breastplate
2865	rough bronze leggings
2866	rough bronze cuirass
2867	rough bronze bracers
2868	patterned bronze bracers
2869	silvered bronze breastplate
2870	shining silver breastplate
2871	heavy sharpening stone
2872	vicious night web spider venom
2874	an unsent letter
2875	scarlet insignia ring
2876	duskbat pelt
2877	combatant claymore
2878	bearded boneaxe
2879	antipodean rod
2880	weak flux
2881	plans runed copper breastplate
2882	plans silvered bronze shoulders
2883	plans deadly bronze poniard
2885	scarlet crusade documents
2886	crag boar rib
2887	ruined wolf pelt
2888	beer basted boar ribs
2889	recipe beer basted boar ribs
2890	ruined boar pelt
2891	letter to the city architect
2892	deadly poison
2893	deadly poison ii
2894	rhapsody malt
2895	creeping pain
2896	creeping anguish
2898	mountaineer chestpiece
2899	wendigo collar
2900	stone buckler
2901	mining pick
2902	cloak of the faith
2903	daryl s hunting bow
2904	daryl s hunting rifle
2905	goat fur cloak
2906	darkshire mail leggings
2907	dwarven tree chopper
2908	thornblade
2909	red wool bandana
2910	gold militia boots
2911	keller s girdle
2912	claw of the shadowmancer
2913	silk mantle of gamn
2915	taran icebreaker
2916	gold lion shield
2917	tranquil ring
2919	relic of the ancients
2920	sacred relic
2921	blessed relic
2922	spirit relic
2923	relic of righteousness
2924	crocolisk meat
2925	crocolisk skin
2926	head of bazil thredd
2927	creeping torment
2928	dust of decay
2929	tomb rot
2930	essence of pain
2931	maiden s anguish
2932	torment vine
2933	seal of wrynn
2934	ruined leather scraps
2939	crocolisk tear
2940	bloody bear paw
2941	prison shank
2942	iron knuckles
2943	eye of paleth
2944	cursed eye of paleth
2946	broken balanced throwing dagger
2947	broken small throwing knife
2949	mariner boots
2950	icicle rod
2951	ring of the underwood
2953	watch master s cloak
2954	night watch pantaloons
2955	first mate hat
2956	report on the defias brotherhood
2957	journeyman s vest
2958	journeyman s pants
2959	journeyman s boots
2960	journeyman s gloves
2961	burnt leather vest
2962	burnt leather breeches
2963	burnt leather boots
2964	burnt leather gloves
2965	warrior s tunic
2966	warrior s pants
2967	warrior s boots
2968	warrior s gloves
2969	spellbinder vest
2970	spellbinder pants
2971	spellbinder boots
2972	spellbinder gloves
2973	hunting tunic
2974	hunting pants
2975	hunting boots
2976	hunting gloves
2977	veteran armor
2978	veteran leggings
2979	veteran boots
2980	veteran gloves
2981	seer s robe
2982	seer s pants
2983	seer s boots
2984	seer s gloves
2985	inscribed leather breastplate
2986	inscribed leather pants
2987	inscribed leather boots
2988	inscribed leather gloves
2989	burnished tunic
2990	burnished leggings
2991	burnished boots
2992	burnished gloves
2996	bolt of linen cloth
2997	bolt of woolen cloth
2998	a simple compass
2999	steelgrill s tools
3000	brood mother carapace
3002	relic horn of justice
3003	relic of the eye
3004	relic of the dead
3005	relic of truth
3006	holy relic shard
3008	wendigo fur cloak
3010	fine sand
3011	feathered headdress
3012	scroll of agility
3013	scroll of protection
3014	battleworn axe
3016	gunther s spellbook
3017	sevren s orders
3018	hide of lupos
3019	noble s robe
3020	enduring cap
3021	ranger bow
3022	bluegill breeches
3023	large bore blunderbuss
3024	bkp 2700 enforcer
3025	bkp 42 ultra
3026	reinforced bow
3027	heavy recurve bow
3028	longbow
3029	depricated whipwood arrow
3030	razor arrow
3031	depricated razor arrow
3033	solid shot
3034	glyphed breastplate
3035	laced pumpkin
3036	heavy shortbow
3037	whipwood recurve bow
3039	short ash bow
3040	hunter s muzzle loader
3041	mage eye blunderbuss
3042	bkp sparrow smallbore
3044	oldmonster mace standard basic offhand
3045	lambent scale boots
3047	lambent scale gloves
3048	lambent scale legguards
3049	lambent scale breastplate
3053	humbert s chestpiece
3055	forest leather chestpiece
3056	forest leather pants
3057	forest leather boots
3058	forest leather gloves
3065	bright boots
3066	bright gloves
3067	bright pants
3069	bright robe
3070	ensign cloak
3071	striking hatchet
3072	smoldering robe
3073	smoldering pants
3074	smoldering gloves
3075	eye of flame
3076	smoldering boots
3078	naga heartpiercer
3079	skorn s rifle
3080	candle of beckoning
3081	nether gem
3082	dargol s skull
3083	restabilization cog
3084	gyromechanic gear
3085	barrel of shimmer stout
3086	cask of shimmer stout
3087	mug of shimmer stout
3088	book of rejuvenation iv
3089	tome of flamestrike
3090	tome of frostbolt
3091	tome of arcane intellect ii
3092	tome of flamestrike iii
3093	tome of flamestrike ii
3094	tome of fire blast ii
3095	tome of fire blast iii
3096	tome of feather fall
3097	tome of conjure water ii
3098	tome of slow
3099	tome of ice armor ii
3100	tome of blizzard ii
3101	tome of frost nova iii
3102	tome of arcane intellect iii
3103	coldridge hammer
3107	broken keen throwing knife
3108	broken heavy throwing dagger
3110	tunnel rat ear
3111	broken crude throwing axe
3113	codex of holy word shield
3114	codex of shadow word befuddle
3115	codex of renew iv
3116	codex of holy word shield ii
3117	hildelve s journal
3118	codex of greater heal
3119	codex of holy word shield v
3120	codex of holy smite iv
3121	codex of levitate
3122	codex of holy word shield iii
3123	codex of holy word fortitude iii
3124	codex of inner fire iii
3125	tablet of serpent totem ii
3126	tablet of shock ii
3127	tablet of shock iii
3129	tablet of lightning bolt iv
3130	tablet of restoration iv
3131	broken weighted throwing axe
3132	tablet of molten blast iv
3133	tablet of mana totem
3134	grimoire of curse of mannoroth
3135	broken sharp throwing axe
3137	broken deadly throwing axe
3138	grimoire of shadow bolt iv
3139	grimoire of demon armor ii
3140	grimoire of blood boil ii
3141	grimoire of life drain
3142	grimoire of curse of sargeras
3143	grimoire of burning spirit
3144	grimoire of burning spirit ii
3146	grimoire of burning spirit iii
3148	work shirt
3151	siege brigade vest
3152	driving gloves
3153	oil stained cloak
3154	thelsamar axe
3155	remedy of arugal
3156	glutton shackle
3157	darksoul shackle
3158	burnt hide bracers
3160	ironplate buckler
3161	robe of the keeper
3162	notched rib
3163	blackened skull
3164	discolored worg heart
3165	quinn s potion
3166	ironheart chain
3167	thick spider hair
3168	chipped scale
3169	chipped bear tooth
3170	large bear tooth
3171	broken boar tusk
3172	boar intestines
3173	bear meat
3174	spider ichor
3175	ruined dragonhide
3176	small claw
3177	tiny fang
3179	cracked dragon molting
3180	flecked raptor scale
3181	partially digested meat
3182	spider s silk
3183	mangy claw
3184	hook dagger
3185	acrobatic staff
3186	viking sword
3187	sacrificial kris
3188	coral claymore
3189	wood chopper
3190	beatstick
3191	arced war axe
3192	short bastard sword
3193	oak mallet
3194	black malice
3195	barbaric battle axe
3196	edged bastard sword
3197	stonecutter claymore
3198	battering hammer
3199	battle slayer
3200	burnt leather bracers
3201	barbarian war axe
3202	forest leather bracers
3203	dense triangle mace
3204	deepwood bracers
3205	inscribed leather bracers
3206	cavalier two hander
3207	hunting bracers
3208	conk hammer
3209	ancient war sword
3210	brutal war axe
3211	burnished bracers
3212	lambent scale bracers
3213	veteran bracers
3214	warrior s bracers
3216	warm winter robe
3217	foreman belt
3218	pyrewood shackle
3220	blood sausage
3222	wicked dagger
3223	frostmane scepter
3224	silver lined bracers
3225	bloodstained knife
3227	nightbane staff
3228	jimmied handcuffs
3229	tarantula silk sash
3230	black wolf bracers
3231	cutthroat pauldrons
3233	gnoll hide sack
3234	deliah s ring
3235	ring of scorn
3236	rot hide ichor
3237	sample ichor
3238	johaan s findings
3239	rough weightstone
3240	coarse weightstone
3241	heavy weightstone
3248	translated letter from the embalmer
3250	bethor s scroll
3251	bethor s potion
3252	deathstalker report
3253	grizzled bear heart
3254	skittering blood
3255	berard s journal
3256	lake skulker moss
3257	lake creeper moss
3258	hardened tumor
3259	ruined bat hide
3260	scarlet initiate robes
3261	webbed cloak
3262	putrid wooden hammer
3263	webbed pants
3264	duskbat wing
3265	scavenger paw
3266	scarlet armband
3267	forsaken shortsword
3268	forsaken dagger
3269	forsaken maul
3270	flax vest
3272	zombie skin leggings
3273	rugged mail vest
3274	flax boots
3275	flax gloves
3276	deathguard buckler
3277	executor staff
3278	aura proc damage sword
3279	battle chain boots
3280	battle chain bracers
3281	battle chain gloves
3282	battle chain pants
3283	battle chain tunic
3284	tribal boots
3285	tribal bracers
3286	tribal gloves
3287	tribal pants
3288	tribal vest
3289	ancestral boots
3290	ancestral gloves
3291	ancestral woollies
3292	ancestral tunic
3293	deadman cleaver
3294	deadman club
3295	deadman blade
3296	deadman dagger
3297	fel moss
3299	fractured canine
3300	rabbit s foot
3301	sharp canine
3302	brackwater boots
3303	brackwater bracers
3304	brackwater gauntlets
3305	brackwater leggings
3306	brackwater vest
3307	barbaric cloth boots
3308	barbaric cloth gloves
3309	barbaric loincloth
3310	barbaric cloth vest
3311	ceremonial leather ankleguards
3312	ceremonial leather bracers
3313	ceremonial leather harness
3314	ceremonial leather gloves
3315	ceremonial leather loincloth
3316	alaric s head
3317	a talking head
3318	alaric s remains
3319	short sabre
3320	bonecaster sash
3321	gray fur booties
3322	wispy cloak
3323	ghostly bracers
3324	ghostly mantle
3325	vile fin battle axe
3327	vile fin oracle staff
3328	spider web robe
3329	spiked wooden plank
3330	dargol s hauberk
3331	melrache s cape
3332	perrine s boots
3334	farmer s shovel
3335	farmer s broom
3336	flesh piercer
3337	dragonmaw war banner
3339	dwarven tinder
3340	incendicite ore
3341	gauntlets of ogre strength
3342	captain sander s shirt
3343	captain sander s booty bag
3344	captain sander s sash
3345	silk wizard hat
3347	bundle of crocolisk skins
3348	giant crocolisk skin
3349	sida s bag
3352	ooze covered bag
3353	rune inscribed pendant
3354	dalaran pendant
3355	wild steelbloom
3356	kingsblood
3357	liferoot
3358	khadgar s whisker
3360	stitches femur
3363	frayed belt
3365	frayed bracers
3369	grave moss
3370	patchwork belt
3371	empty vial
3372	leaded vial
3373	patchwork bracers
3374	calico belt
3375	calico bracers
3376	canvas belt
3377	canvas bracers
3378	brocade belt
3379	brocade bracers
3380	cross stitched belt
3381	cross stitched bracers
3382	weak troll s blood potion
3383	elixir of wisdom
3384	minor magic resistance potion
3385	lesser mana potion
3386	potion of curing
3387	limited invulnerability potion
3388	strong troll s blood potion
3389	elixir of defense
3390	elixir of lesser agility
3391	elixir of ogre s strength
3392	ringed helm
3393	recipe minor magic resistance potion
3394	recipe potion of curing
3395	recipe limited invulnerability potion
3396	recipe elixir of lesser agility
3397	young crocolisk skin
3399	vulture talon
3400	lucine longsword
3401	rough crocolisk scale
3402	soft patch of fur
3403	ivory boar tusk
3404	buzzard wing
3405	raven claw talisman
3406	black feather quill
3407	sapphire of sky
3408	rune of nesting
3409	nightsaber fang
3411	strigid owl feather
3412	webwood spider silk
3413	doomspike
3414	crested scepter
3415	staff of the friar
3416	martyr s chain
3417	onyx claymore
3418	fel cone
3419	red rose
3420	black rose
3421	simple wildflowers
3422	beautiful wildflowers
3423	bouquet of white roses
3424	bouquet of black roses
3425	woven wand
3426	bold yellow shirt
3427	stylish black shirt
3428	common gray shirt
3429	guardsman belt
3430	sniper rifle
3431	bone studded leather
3434	slumber sand
3435	zombie skin bracers
3437	clasped belt
3438	ankh of resurrection
3439	zombie skin boots
3440	bonecracker
3442	apprentice sash
3443	ceremonial tomahawk
3444	tiller s vest
3445	ceremonial knife
3446	darkwood staff
3447	cryptwalker boots
3448	senggin root
3449	mystic shawl
3450	faerleia s shield
3451	nightglow concoction
3452	ceranium rod
3453	quilted bracers
3454	reconnaissance boots
3455	deathstalker shortsword
3456	dog whistle
3457	stamped trousers
3458	rugged mail gloves
3460	johaan s special drink
3461	high robe of the adjudicator
3462	talonstrike
3463	broken silver star
3464	feathered arrow
3465	exploding shot
3466	strong flux
3467	dull iron key
3468	renferrel s findings
3469	copper chain boots
3470	rough grinding stone
3471	copper chain vest
3472	runed copper gauntlets
3473	runed copper pants
3474	gemmed copper gauntlets
3475	cloak of flames
3476	gray bear tongue
3477	creeper ichor
3478	coarse grinding stone
3480	rough bronze shoulders
3481	silvered bronze shoulders
3482	silvered bronze boots
3483	silvered bronze gauntlets
3484	green iron boots
3485	green iron gauntlets
3486	heavy grinding stone
3487	heavy copper broadsword
3488	copper battle axe
3489	thick war axe
3490	deadly bronze poniard
3491	heavy bronze mace
3492	mighty iron hammer
3493	raptor s end
3495	elixir of suffering
3496	mountain lion blood
3497	elixir of pain
3498	taretha s necklace
3499	burnished gold key
3502	mudsnout blossoms
3505	alterac signet ring
3506	mudsnout composite
3508	mudsnout mixture
3509	daggerspine scale
3510	torn fin eye
3511	cloak of the people s militia
3514	mor ladim s skull
3515	ataeric s staff
3516	lescovar s head
3517	keg of shindigger stout
3518	decrypted letter
3520	tainted keg
3521	cleverly encrypted letter
3522	black night elf breastplate
3526	black night elf gloves
3527	white night elf breastplate
3528	red leather c03 breastplate
3529	black night elf helm
3530	wool bandage
3531	heavy wool bandage
3533	red leather c03 boots
3535	red leather c03 bracers
3536	demon hunter blindfold
3537	black leather d02 breastplate
3538	gray leather d02 breastplate
3541	black leather d02 boots
3542	gray leather d02 boots
3545	black leather d02 bracers
3546	gray leather d02 bracers
3547	white leather d03 breastplate
3550	targ s head
3551	muckrake s head
3552	glommus s head
3553	mug thol s head
3554	crown of will
3555	robe of solomon
3556	dread mage hat
3558	fen keeper robe
3559	night watch gauntlets
3560	mantle of honor
3561	resilient poncho
3562	belt of vindication
3563	seafarer s pantaloons
3564	shipment of iron
3565	beerstained gloves
3566	raptorbane armor
3567	dwarven fishing pole
3569	vicar s robe
3570	bonegrinding pestle
3571	trogg beater
3572	daryl s shortsword
3573	hunting quiver
3574	hunting ammo sack
3575	iron bar
3576	tin bar
3577	gold bar
3578	harvester s pants
3581	serrated knife
3582	acidproof cloak
3583	weathered belt
3585	camouflaged tunic
3586	logsplitter
3587	embroidered belt
3588	embroidered bracers
3589	heavy weave belt
3590	heavy weave bracers
3591	padded belt
3592	padded bracers
3593	russet belt
3594	russet bracers
3595	tattered cloth belt
3596	tattered cloth bracers
3597	thick cloth belt
3598	thick cloth bracers
3599	thin cloth belt
3600	thin cloth bracers
3601	syndicate missive
3602	knitted belt
3603	knitted bracers
3604	bandolier of the night watch
3605	quiver of the night watch
3606	woven belt
3607	woven bracers
3608	plans mighty iron hammer
3609	plans copper chain vest
3610	plans gemmed copper gauntlets
3611	plans green iron boots
3612	plans green iron gauntlets
3613	valdred s hands
3614	yowler s paw
3615	kurzen s head
3616	mind s eye
3617	pendant of shadow
3618	gobbler s head
3619	snellig s snuffbox
3620	lillith s remains
3621	ivar s head
3622	essence of nightlash
3623	thule s head
3625	nek rosh s head
3626	head of baron vardus
3627	fang of vagash
3628	hand of dextren ward
3629	mistmantle family ring
3630	head of targorr
3631	bellygrub s tusk
3632	fangore s paw
3633	head of gath ilzogg
3634	head of grimson
3635	maggot eye s paw
3637	head of vancleef
3638	sarltooth s talon
3639	ear of balgaras
3640	head of deepfury
3641	journeyman s bracers
3642	ancestral bracers
3643	spellbinder bracers
3644	barbaric cloth bracers
3645	seer s cuffs
3647	bright bracers
3648	warrior s buckler
3649	tribal buckler
3650	battle shield
3651	veteran shield
3652	hunting buckler
3653	ceremonial buckler
3654	brackwater shield
3655	burnished shield
3656	lambent scale shield
3657	hillsbrad town registry
3658	recovered tome
3659	worn leather book
3660	tomes of alterac
3661	handcrafted staff
3662	crocolisk steak
3663	murloc fin soup
3664	crocolisk gumbo
3665	curiously tasty omelet
3666	gooey spider cake
3667	tender crocolisk meat
3668	assassin s contract
3669	gelatinous goo
3670	large slimy bone
3671	lifeless skull
3672	head of nagaz
3673	broken arrow
3674	decomposed boot
3675	extinguished torch
3676	slimy ichor
3678	recipe crocolisk steak
3679	recipe blood sausage
3680	recipe murloc fin soup
3681	recipe crocolisk gumbo
3682	recipe curiously tasty omelet
3683	recipe gooey spider cake
3684	perenolde tiara
3685	raptor egg
3688	bloodstone oval
3689	bloodstone marble
3690	bloodstone shard
3691	bloodstone wedge
3692	hillsbrad human skull
3693	humbert s sword
3701	darthalia s sealed commendation
3702	bear gall bladder
3703	southshore stout
3704	rusted iron key
3706	ensorcelled parchment
3707	nagaz parchment
3708	helcular s rod
3710	rod of helcular
3711	belamoore s research journal
3712	turtle meat
3713	soothing spices
3714	worn stone token
3715	bracers of earth binding
3716	murloc head
3717	sack of murloc heads
3718	foreboding plans
3719	hillman s cloak
3720	yeti fur
3721	farren s report
3722	familiar hide
3723	familiar fang
3724	familiar claw
3725	familiar horn
3726	big bear steak
3727	hot lion chops
3728	tasty lion steak
3729	soothing turtle bisque
3730	big bear meat
3731	lion meat
3732	hooded cowl
3733	orcish war chain
3734	recipe big bear steak
3735	recipe hot lion chops
3736	recipe tasty lion steak
3737	recipe soothing turtle bisque
3738	brewing rod
3739	skull ring
3740	decapitating sword
3741	stomping boots
3742	bow of plunder
3743	sentry buckler
3744	bloodstone pendant
3745	rune of opening
3747	meditative sash
3748	feline mantle
3749	high apothecary cloak
3750	ribbed breastplate
3751	mercenary leggings
3752	grunt vest
3753	shepherd s girdle
3754	shepherd s gloves
3755	fish gutter
3758	crusader belt
3759	insulated sage gloves
3760	band of the undercity
3761	deadskull shield
3762	librarian s satchel
3763	lunar buckler
3764	mantis boots
3765	brigand s pauldrons
3766	gryphon feather quill
3767	fine parchment
3769	broken wand
3770	mutton chop
3771	wild hog shank
3772	conjured spring water
3775	crippling poison
3776	crippling poison ii
3777	lethargy root
3778	taut compound bow
3779	hefty war axe
3780	long barreled musket
3781	broad claymore
3782	large war club
3783	light scimitar
3784	metal stave
3785	keen axe
3786	shiny dirk
3787	stone club
3788	soul crystal relic
3789	relic stone of piety
3790	consecrated relic parchment
3791	relic of the light
3792	interlaced belt
3793	interlaced boots
3794	interlaced bracers
3795	interlaced cloak
3796	interlaced gloves
3797	interlaced pants
3798	interlaced shoulderpads
3799	interlaced vest
3800	hardened leather belt
3801	hardened leather boots
3802	hardened leather bracers
3803	hardened cloak
3804	hardened leather gloves
3805	hardened leather pants
3806	hardened leather shoulderpads
3807	hardened leather tunic
3808	double mail belt
3809	double mail boots
3810	double mail bracers
3811	double stitched cloak
3812	double mail gloves
3813	double mail pants
3814	double mail shoulderpads
3815	double mail vest
3816	reflective heater
3817	reinforced buckler
3818	fadeleaf
3819	wintersbite
3820	stranglekelp
3821	goldthorn
3822	runic darkblade
3823	lesser invisibility potion
3824	shadow oil
3825	elixir of fortitude
3826	mighty troll s blood potion
3827	mana potion
3828	elixir of detect lesser invisibility
3829	frost oil
3830	recipe elixir of fortitude
3831	recipe mighty troll s blood potion
3832	recipe elixir of detect lesser invisibility
3833	adept s cloak
3834	sturdy cloth trousers
3835	green iron bracers
3836	green iron helm
3837	golden scale coif
3838	shadowmaw claw
3839	pristine tigress fang
3840	green iron shoulders
3841	golden scale shoulders
3842	green iron leggings
3843	golden scale leggings
3844	green iron hauberk
3845	golden scale cuirass
3846	polished steel boots
3847	golden scale boots
3848	big bronze knife
3849	hardened iron shortsword
3850	jade serpentblade
3851	solid iron maul
3852	golden iron destroyer
3853	moonsteel broadsword
3854	frost tiger blade
3855	massive iron axe
3856	shadow crescent axe
3857	coal
3858	mithril ore
3859	steel bar
3860	mithril bar
3861	blacksteel bar
3862	aged gorilla sinew
3863	jungle stalker feather
3864	citrine
3866	plans jade serpentblade
3867	plans golden iron destroyer
3868	plans frost tiger blade
3869	plans shadow crescent axe
3870	plans green iron shoulders
3871	plans golden scale shoulders
3872	plans golden scale leggings
3873	plans golden scale cuirass
3874	plans polished steel boots
3875	plans golden scale boots
3876	fang of bhag thera
3877	talon of tethis
3879	paw of sin dall
3880	head of bangalash
3882	buzzard feather
3889	russet hat
3890	studded hat
3891	augmented chain helm
3892	embroidered hat
3893	reinforced leather cap
3894	brigandine helm
3897	dizzy s eye
3898	library scrip
3899	legends of the gurubashi volume 3
3900	pupellyverbos port
3901	bloodscalp tusk
3902	staff of nobles
3904	gan zulah s head
3905	nezzliok s head
3906	balia mah trophy
3907	ziata jai trophy
3908	zul mamwe trophy
3909	broken armor of ana thek
3910	snuff
3911	pulsing blue shard
3912	soul gem
3913	filled soul gem
3914	journeyman s backpack
3915	bloody bone necklace
3916	split bone necklace
3917	singing blue crystal
3918	singing crystal shard
3919	mistvale giblets
3920	bloodsail charts
3921	bloodsail orders
3922	shaky s payment
3923	water elemental bracers
3924	maury s clubbed foot
3925	jon jon s golden spyglass
3926	chucky s huge ring
3927	fine aged cheddar
3928	superior healing potion
3929	maury s loot
3930	maury s key
3931	poisoned spider fang
3932	smotts chest
3935	smotts cutlass
3936	crochet belt
3937	crochet boots
3938	crochet bracers
3939	crochet cloak
3940	crochet gloves
3941	crochet pants
3942	crochet shoulderpads
3943	crochet vest
3944	twill belt
3945	twill boots
3946	twill bracers
3947	twill cloak
3948	twill gloves
3949	twill pants
3950	twill shoulderpads
3951	twill vest
3952	mesh belt
3953	mesh boots
3954	mesh bracers
3955	mesh cloak
3956	mesh gloves
3957	mesh pants
3958	mesh mantle
3959	mesh armor
3960	bag of water elemental bracers
3961	thick leather belt
3962	thick leather boots
3963	thick leather bracers
3964	thick cloak
3965	thick leather gloves
3966	thick leather pants
3967	thick leather shoulderpads
3968	thick leather tunic
3969	smooth leather belt
3970	smooth leather boots
3971	smooth leather bracers
3972	smooth cloak
3973	smooth leather gloves
3974	smooth leather pants
3975	smooth leather shoulderpads
3976	smooth leather armor
3977	strapped belt
3978	strapped boots
3979	strapped bracers
3980	strapped cloak
3981	strapped gloves
3982	strapped pants
3983	strapped shoulderpads
3984	strapped armor
3985	monogrammed sash
3986	protective pavise
3987	deflecting tower
3988	plate wall shield
3989	blocking targe
3990	crested buckler
3991	plated buckler
3992	laminated scale belt
3993	laminated scale boots
3994	laminated scale bracers
3995	laminated scale cloak
3996	laminated scale gloves
3997	laminated scale pants
3998	laminated scale shoulderpads
3999	laminated scale armor
4000	overlinked chain belt
4001	overlinked chain boots
4002	overlinked chain bracers
4003	overlinked chain cloak
4004	overlinked chain gloves
4005	overlinked chain pants
4006	overlinked chain shoulderpads
4007	overlinked chain armor
4008	sterling chain belt
4009	sterling chain boots
4010	sterling chain bracers
4011	sterling chain cloak
4012	sterling chain gloves
4013	sterling chain pants
4014	sterling chain shoulderpads
4015	sterling chain armor
4016	zanzil s mixture
4017	sharp shortsword
4018	whetted claymore
4019	heavy flint axe
4020	splintering battle axe
4021	blunting mace
4022	crushing maul
4023	fine pointed dagger
4024	heavy war staff
4025	balanced long bow
4026	sentinel musket
4027	catelyn s blade
4028	bundle of akiris reeds
4029	akiris reed
4030	holy relic water
4031	hallowed relic charm
4032	radiant relic hammer
4033	dawn s glow
4034	stone of the tides
4035	silver thread robe
4036	silver thread cuffs
4037	silver thread pants
4038	nightsky robe
4039	nightsky cowl
4040	nightsky gloves
4041	aurora cowl
4042	aurora gloves
4043	aurora bracers
4044	aurora pants
4045	mistscape bracers
4046	mistscape pants
4047	mistscape boots
4048	emblazoned hat
4049	emblazoned bracers
4050	emblazoned leggings
4051	emblazoned boots
4052	insignia cap
4053	large river crocolisk skin
4054	insignia leggings
4055	insignia boots
4056	cortello s riddle
4057	insignia chestguard
4058	glyphed breastplate
4059	glyphed bracers
4060	glyphed leggings
4061	imperial leather bracers
4062	imperial leather pants
4063	imperial leather gloves
4064	emblazoned buckler
4065	combat shield
4066	insignia buckler
4067	glyphed buckler
4068	chief brigadier shield
4069	blackforge buckler
4070	jouster s crest
4071	glimmering mail breastplate
4072	glimmering mail gauntlets
4073	glimmering mail greaves
4074	mail combat armor
4075	mail combat gauntlets
4076	mail combat boots
4077	mail combat headguard
4078	chief brigadier coif
4079	chief brigadier leggings
4080	blackforge cowl
4082	blackforge breastplate
4083	blackforge gauntlets
4084	blackforge leggings
4085	krazek s crock pot
4086	flash rifle
4087	trueshot bow
4088	dreadblade
4089	ricochet blunderbuss
4090	mug o hurt
4091	widowmaker
4092	prismatic basilisk scale
4093	large basilisk tail
4094	tablet shard
4095	deprecate snare kit
4096	coarse gorilla hair
4097	chipped gorilla tooth
4098	carefully folded note
4099	tuft of gorilla hair
4100	crumpled note
4101	ripped note
4102	torn note
4103	shackle key
4104	snapjaw crocolisk skin
4105	elder crocolisk skin
4106	tumbled crystal
4107	tiger hunter gloves
4108	panther hunter leggings
4109	excelsior boots
4110	master hunter s bow
4111	master hunter s rifle
4112	choker of the high shaman
4113	medicine blanket
4114	darktide cape
4115	grom gol buckler
4116	olmann sewar
4117	scorching sash
4118	poobah s nose ring
4119	raptor hunter tunic
4120	robe of crystal waters
4121	gemmed gloves
4122	bookmaker s scepter
4123	frost metal pauldrons
4124	cap of harmony
4125	tranquil orb
4126	guerrilla cleaver
4127	shrapnel blaster
4128	silver spade
4129	collection plate
4130	smotts compass
4131	belt of corruption
4132	darkspear armsplints
4133	darkspear cuffs
4134	nimboya s mystical staff
4135	bloodbone band
4136	darkspear boots
4137	darkspear shoes
4138	blackwater tunic
4139	junglewalker sandals
4140	palm frond mantle
4141	tome of conjure food
4143	tome of conjure food ii
4145	tome of conjure mana gem
4146	tome of polymorph sheep
4147	tome of conjure food iii
4148	tome of counterspell
4149	tome of frost shield iii
4150	tome of conjure water iv
4151	tome of frostbolt iv
4152	tome of conjure food iv
4153	tome of arcane missiles iii
4154	tome of slow ii
4155	tome of water elemental ii
4157	tome of dampen magic
4158	tome of khadgar s unlocking iii
4159	tome of arcane missiles
4161	tome of fireball iv
4162	tome of blink ii
4164	libram holy light v
4165	libram holy light vi
4166	libram seal of protection
4167	libram judgement
4168	tablet of ensnaring totem
4169	tablet of unyielding will ii
4170	tablet of astral recall
4171	tablet of agitating totem iii
4172	tablet of thunderclap ii
4173	tablet of shock iv
4174	tablet of shock v
4175	tablet of lightning shield iv
4176	tablet of undying strength ii
4177	tablet of nature resistance
4178	tablet of lightning bolt v
4179	tablet of restoration v
4180	tablet of ethereal form ii
4181	tablet of agitating totem iv
4182	tablet of unyielding will iii
4183	tablet of healing totem v
4184	tablet of molten blast v
4185	tablet of group astral recall
4186	tablet of fire resistance
4187	tablet of serpent totem v
4188	tablet of invisibility totem
4189	tablet of chain lightning
4190	feathered armor
4191	feathered leggings
4194	feathered bracers
4195	feathered boots
4196	feathered mantle
4197	berylline pads
4198	grimoire of soul funnel
4199	grimoire of soul funnel ii
4200	grimoire of immolate iii
4201	grimoire of eye of kilrogg
4202	grimoire of fear ii
4203	grimoire of pestilence ii
4204	grimoire of soul funnel iii
4205	grimoire of immolate iv
4206	grimoire of curse of sargeras ii
4207	grimoire of curse of archimonde
4208	grimoire of mind bomb
4209	grimoire of shadow ward
4210	grimoire of create lesser bloodstone
4211	grimoire of pestilence
4212	grimoire of curse of mannoroth iii
4213	grimoire of doom
4214	grimoire of life drain iii
4215	grimoire of rain of fire
4216	grimoire of holy ward
4217	grimoire of soul funnel iv
4218	grimoire of create bloodstone
4219	grimoire of burning spirit iv
4220	grimoire of blood boil iii
4221	grimoire of detect invisibility
4223	book of abolish magic
4225	book of entangling roots iii
4226	book of wrath vi
4228	book of moonfire iv
4230	book of healing touch vi
4231	cured light hide
4232	medium hide
4233	cured medium hide
4234	heavy leather
4235	heavy hide
4236	cured heavy hide
4237	handstitched leather belt
4238	linen bag
4239	embossed leather gloves
4240	woolen bag
4241	green woolen bag
4242	embossed leather pants
4243	fine leather tunic
4244	hillman s leather vest
4245	small silk pack
4246	fine leather belt
4247	hillman s leather gloves
4248	dark leather gloves
4249	dark leather belt
4250	hillman s belt
4251	hillman s shoulders
4252	dark leather shoulders
4253	toughened leather gloves
4254	barbaric gloves
4255	green leather armor
4256	guardian armor
4257	green leather belt
4258	guardian belt
4259	green leather bracers
4260	guardian leather bracers
4261	solliden s trousers
4262	gem studded leather belt
4263	standard issue shield
4264	barbaric belt
4265	heavy armor kit
4266	codex of inner fire ii
4267	codex of shadow word fumble
4268	codex of heal ii
4269	codex of prayer of healing
4270	codex of heal iii
4271	codex of holy smite v
4272	codex of holy protection
4273	codex of heal
4274	codex of divine escape
4275	codex of mind rot
4276	codex of shadow word fumble ii
4277	codex of shadow word befuddle ii
4278	lesser bloodstone ore
4279	codex of shadow word pain v
4280	codex of holy word shield iv
4281	codex of shadow protection
4282	codex of dispel magic ii
4283	codex of sleep iii
4284	codex of holy smite vi
4285	codex of holy word fortitude iv
4286	codex of prayer of healing ii
4287	codex of nullify disease ii
4288	codex of remove curse ii
4289	salt
4290	dust bowl
4291	silken thread
4292	pattern green woolen bag
4293	pattern hillman s leather vest
4294	pattern hillman s belt
4296	pattern dark leather shoulders
4297	pattern barbaric gloves
4298	pattern guardian belt
4299	pattern guardian armor
4300	pattern guardian leather bracers
4301	pattern barbaric belt
4302	small green dagger
4303	cranial thumper
4304	thick leather
4305	bolt of silk cloth
4306	silk cloth
4307	heavy linen gloves
4308	green linen bracers
4309	handstitched linen britches
4310	heavy woolen gloves
4311	heavy woolen cloak
4312	soft soled linen boots
4313	red woolen boots
4314	double stitched woolen shoulders
4315	reinforced woolen shoulders
4316	heavy woolen pants
4317	phoenix pants
4318	gloves of meditation
4319	azure silk gloves
4320	spidersilk boots
4321	spider silk slippers
4322	enchanter s cowl
4323	shadow hood
4324	azure silk vest
4325	boots of the enchanter
4326	long silken cloak
4327	icy cloak
4328	spider belt
4329	star belt
4330	stylish red shirt
4331	phoenix gloves
4332	bright yellow shirt
4333	dark silk shirt
4334	formal white shirt
4335	rich purple silk shirt
4336	black swashbuckler s shirt
4337	thick spider s silk
4338	mageweave cloth
4339	bolt of mageweave
4340	gray dye
4341	yellow dye
4342	purple dye
4343	brown linen pants
4344	brown linen shirt
4345	pattern red woolen boots
4346	pattern heavy woolen cloak
4347	pattern reinforced woolen shoulders
4348	pattern phoenix gloves
4349	pattern phoenix pants
4350	pattern spider silk slippers
4351	pattern shadow hood
4352	pattern boots of the enchanter
4353	pattern spider belt
4354	pattern rich purple silk shirt
4355	pattern icy cloak
4356	pattern star belt
4357	rough blasting powder
4358	rough dynamite
4359	handful of copper bolts
4360	rough copper bomb
4361	copper tube
4362	rough boomstick
4363	copper modulator
4364	coarse blasting powder
4365	coarse dynamite
4366	target dummy
4367	small seaforium charge
4368	flying tiger goggles
4369	deadly blunderbuss
4370	large copper bomb
4371	bronze tube
4372	lovingly crafted boomstick
4373	shadow goggles
4374	small bronze bomb
4375	whirring bronze gizmo
4376	flame deflector
4377	heavy blasting powder
4378	heavy dynamite
4379	silver plated shotgun
4380	big bronze bomb
4381	minor recombobulator
4382	bronze framework
4383	moonsight rifle
4384	explosive sheep
4385	green tinted goggles
4386	ice deflector
4387	iron strut
4388	discombobulator ray
4389	gyrochronatom
4390	iron grenade
4391	compact harvest reaper kit
4392	advanced target dummy
4393	craftsman s monocle
4394	big iron bomb
4395	goblin land mine
4396	mechanical dragonling
4397	gnomish cloaking device
4398	large seaforium charge
4399	wooden stock
4400	heavy stock
4401	mechanical squirrel box
4402	small flame sac
4403	portable bronze mortar
4404	silver contact
4405	crude scope
4406	standard scope
4407	accurate scope
4408	schematic mechanical squirrel
4409	schematic small seaforium charge
4410	schematic shadow goggles
4411	schematic flame deflector
4412	schematic moonsight rifle
4413	schematic discombobulator ray
4414	schematic portable bronze mortar
4415	schematic craftsman s monocle
4416	schematic goblin land mine
4417	schematic large seaforium charge
4419	scroll of intellect iii
4421	scroll of protection iii
4422	scroll of stamina iii
4424	scroll of spirit iii
4425	scroll of agility iii
4426	scroll of strength iii
4428	spider palp
4429	deepfury s orders
4430	ethereal talisman
4432	sully balloo s letter
4433	waterlogged envelope
4434	scarecrow trousers
4435	mote of myzrael
4436	jewel encrusted sash
4437	channeler s staff
4438	pugilist bracers
4439	bruiser club
4440	sigil of strom
4441	mackreel s moonshine
4443	grim pauldrons
4444	black husk shield
4445	flesh carver
4446	blackvenom blade
4447	cloak of night
4448	husk of naraxis
4449	naraxis fang
4450	sigil fragment
4453	sigil of thoradin
4454	talon of vultros
4455	raptor hide harness
4456	raptor hide belt
4457	barbecued buzzard wing
4458	sigil of arathor
4459	brittle dragon bone
4460	ripped wing webbing
4461	raptor hide
4462	cloak of rot
4463	beaded raptor collar
4464	trouncing boots
4465	bonefist gauntlets
4466	sigil of trollbane
4467	sigil of ignaeus
4468	sheathed trol kalar
4469	rod of order
4470	simple wood
4471	flint and tinder
4472	scroll of myzrael
4473	eldritch shackles
4474	ravenwood bow
4476	beastwalker robe
4477	nefarious buckler
4478	iridescent scale leggings
4479	burning charm
4480	thundering charm
4481	cresting charm
4482	sealed folder
4483	burning key
4484	cresting key
4485	thundering key
4487	maiden s folly charts
4488	spirit of silverpine charts
4489	maiden s folly log
4490	spirit of silverpine log
4491	goggles of gem hunting
4492	elven gem
4493	elven gems
4494	seahorn s sealed letter
4495	bloodstone amulet
4496	small brown pouch
4497	heavy brown bag
4498	brown leather satchel
4499	huge brown sack
4500	traveler s backpack
4502	sample elven gem
4503	witherbark tusk
4504	dwarven guard cloak
4505	swampland trousers
4506	stromgarde badge
4507	pit fighter s shield
4508	blood tinged armor
4509	seawolf gloves
4510	befouled bloodstone orb
4511	black water hammer
4512	highland raptor eye
4513	raptor heart
4514	sara balloo s plea
4515	marez s head
4516	otto s head
4517	falconcrest s head
4518	torn scroll fragment
4519	crumpled scroll fragment
4520	singed scroll fragment
4521	alterac granite
4522	witherbark medicine pouch
4524	balloo s memorial
4525	trelane s wand of invocation
4526	raptor talon amulet
4527	azure agate
4528	tor gan s orb
4529	enchanted agate
4530	trelane s phylactery
4531	trelane s orb
4532	trelane s ember agate
4533	sealed letter to archmage malin
4534	steel clasped bracers
4535	ironforge memorial ring
4536	shiny red apple
4537	tel abim banana
4538	snapvine watermelon
4539	goldenbark apple
4540	tough hunk of bread
4541	freshly baked bread
4542	moist cornbread
4543	white drakeskin cap
4544	mulgore spice bread
4545	radiant silver bracers
4546	call of the raptor
4547	gnomish zapper
4548	servomechanic sledgehammer
4549	seafire band
4550	coldwater ring
4551	or kalar s head
4552	smooth stone chip
4553	jagged piece of stone
4554	shiny polished stone
4555	thick scaly tail
4556	speckled shell fragment
4557	fiery gland
4558	empty barrel
4560	fine scimitar
4561	scalping tomahawk
4562	severing axe
4563	billy club
4564	spiked club
4565	simple dagger
4566	sturdy quarterstaff
4567	merc sword
4568	grunt axe
4569	staunch hammer
4570	birchwood maul
4571	war knife
4575	medicine staff
4576	light bow
4577	compact shotgun
4580	sabertooth fang
4581	patch of fine fur
4582	soft bushy tail
4583	thick furry mane
4584	large trophy paw
4585	dripping spider mandible
4586	smooth raptor skin
4587	tribal raptor feathers
4588	pristine raptor skull
4589	long elegant feather
4590	curved yellow bill
4591	eagle eye
4592	longjaw mud snapper
4593	bristle whisker catfish
4594	rockscale cod
4595	junglevine wine
4596	discolored healing potion
4597	recipe discolored healing potion
4598	goblin fishing pole
4599	cured ham steak
4600	cherry grog
4601	soft banana bread
4602	moon harvest pumpkin
4603	raw spotted yellowtail
4604	forest mushroom cap
4605	red speckled mushroom
4606	spongy morel
4607	delicious cave mold
4608	raw black truffle
4609	recipe barbecued buzzard wing
4610	carved stone urn
4611	blue pearl
4612	black drake s heart
4613	corroded black box
4614	pendant of myzrael
4615	blacklash s bindings
4616	ryedol s lucky pick
4621	ambassador infernus bracer
4622	sealed note to advisor belgrum
4623	lesser stoneshield potion
4624	recipe lesser stoneshield potion
4625	firebloom
4626	small stone shard
4627	large stone slab
4628	bracers of rock binding
4629	supply crate
4630	scrap metal
4631	tablet of ryun eh
4632	ornate bronze lockbox
4633	heavy bronze lockbox
4634	iron lockbox
4635	hammertoe s amulet
4636	strong iron lockbox
4637	steel lockbox
4638	reinforced steel lockbox
4639	enchanted sea kelp
4640	sign of the earth
4641	hand of dagun
4643	grimsteel cape
4644	the legacy heart
4645	chains of hematus
4646	star of xil yeh
4647	yagyin s digest
4648	sigil of the hammer
4649	bonegrip s note
4650	bel dugur s note
4652	salbac shield
4653	ironheel boots
4654	mysterious fossil
4655	giant clam meat
4656	small pumpkin
4658	warrior s cloak
4659	warrior s girdle
4660	walking boots
4661	bright mantle
4662	journeyman s cloak
4663	journeyman s belt
4665	burnt cloak
4666	burnt leather belt
4668	battle chain cloak
4669	battle chain girdle
4671	ancestral cloak
4672	ancestral belt
4674	tribal cloak
4675	tribal belt
4676	skeletal gauntlets
4677	veteran cloak
4678	veteran girdle
4680	brackwater cloak
4681	brackwater girdle
4683	spellbinder cloak
4684	spellbinder belt
4686	barbaric cloth cloak
4687	barbaric cloth belt
4689	hunting cloak
4690	hunting belt
4692	ceremonial cloak
4693	ceremonial leather belt
4694	burnished pauldrons
4695	burnished cloak
4696	lapidis tankard of tidesippe
4697	burnished girdle
4698	seer s mantle
4699	seer s belt
4700	inscribed leather spaulders
4701	inscribed cloak
4702	prospector s pick
4703	broken tools
4705	lambent scale pauldrons
4706	lambent scale cloak
4707	lambent scale girdle
4708	bright belt
4709	forest leather mantle
4710	forest cloak
4711	glimmering cloak
4712	glimmering mail girdle
4713	silver thread cloak
4714	silver thread sash
4715	emblazoned cloak
4716	combat cloak
4717	mail combat belt
4718	nightsky mantle
4719	nightsky cloak
4720	nightsky sash
4721	insignia mantle
4722	insignia cloak
4723	humbert s pants
4724	humbert s helm
4725	chief brigadier pauldrons
4726	chief brigadier cloak
4727	chief brigadier girdle
4728	twain s shoulder
4729	aurora mantle
4731	glyphed epaulets
4732	glyphed cloak
4733	blackforge pauldrons
4734	mistscape mantle
4735	mistscape cloak
4736	mistscape sash
4737	imperial leather spaulders
4738	imperial leather belt
4739	plainstrider meat
4740	plainstrider feather
4741	stromgarde cavalry leggings
4742	mountain cougar pelt
4743	pulsating crystalline shard
4744	arcane runed bracers
4745	war rider bracers
4746	doomsayer s robe
4747	stormbull well water
4748	redhorn well water
4749	wildmane well water
4751	windfury talon
4752	azure feather
4753	bronze feather
4755	water pitcher
4756	ruined cat pelt
4757	cracked egg shells
4758	prairie wolf paw
4759	plainstrider talon
4763	blackwood recurve bow
4765	enamelled broadsword
4766	feral blade
4767	coppercloth gloves
4768	adept s gloves
4769	trophy swoop quill
4770	bristleback belt
4771	harvest cloak
4772	warm cloak
4775	cracked bill
4776	ruffled feather
4777	ironwood maul
4778	heavy spiked mace
4779	dull kodo tooth
4780	kodo horn fragment
4781	whispering vest
4782	solstice robe
4783	totem of hawkwind
4784	lifeless stone
4785	brimstone belt
4786	wise man s belt
4787	burning pitch
4788	agile boots
4789	stable boots
4790	inferno cloak
4791	enchanted water
4792	spirit cloak
4793	sylvan cloak
4794	wolf bracers
4795	bear bracers
4796	owl bracers
4797	fiery cloak
4798	heavy runed cloak
4799	antiquated cloak
4800	mighty chain pants
4801	stalker claws
4802	cougar claws
4803	prairie alpha tooth
4804	prairie wolf heart
4805	flatland cougar femur
4806	plainstrider scale
4807	swoop gizzard
4808	well stone
4809	ambercorn
4810	boulder pads
4813	small leather collar
4814	discolored fang
4816	legionnaire s leggings
4817	blessed claymore
4818	executioner s sword
4819	fizsprocket s clipboard
4820	guardian buckler
4821	bear buckler
4822	owl s disk
4823	water of the seers
4824	blurred axe
4825	callous axe
4826	marauder axe
4827	wizard s belt
4828	nightwind belt
4829	dreamer s belt
4830	saber leggings
4831	stalking pants
4832	mystic sarong
4833	glorious shoulders
4834	venture co documents
4835	elite shoulders
4836	fireproof orb
4837	strength of will
4838	orb of power
4840	long bayonet
4841	horn of arra chea
4843	amethyst runestone
4844	opal runestone
4845	diamond runestone
4846	cog #5
4847	lotwil s shackles of elemental binding
4848	battleboar snout
4849	battleboar flank
4850	bristleback attack plans
4851	dirt stained map
4852	flash bomb
4854	demon scarred cloak
4859	burning blade medallion
4860	glistening frenzy scale
4861	sleek feathered tunic
4862	scorpid worker tail
4863	gnomish tools
4864	minshina s skull
4865	ruined pelt
4866	zalazane s head
4867	broken scorpid leg
4869	fizzle s claw
4870	canvas scraps
4871	searing collar
4872	dry scorpid eye
4873	dry hardened barnacle
4874	clean fishbones
4875	slimy bone
4876	bloody leather boot
4877	stone arrowhead
4878	broken bloodstained bow
4879	squashed rabbit carcass
4880	broken spear
4881	aged envelope
4882	benedict s key
4883	admiral proudmoore s orders
4886	venomtail poison sac
4887	intact makrura eye
4888	crawler mucus
4890	taillasher egg
4891	kron s amulet
4892	durotar tiger fur
4893	savannah lion tusk
4894	plainstrider kidney
4895	thunder lizard horn
4896	kodo liver
4897	thunderhawk saliva gland
4898	lightning gland
4903	eye of burning shadow
4904	venomtail antidote
4905	sarkoth s mangled claw
4906	rainwalker boots
4907	woodland tunic
4908	nomadic bracers
4909	kodo hunter s leggings
4910	painted chain gloves
4911	thick bark buckler
4913	painted chain belt
4914	battleworn leather gloves
4915	soft wool boots
4916	soft wool vest
4917	battleworn chain leggings
4918	sack of supplies
4919	soft wool belt
4920	battleworn cape
4921	dust covered leggings
4922	jagged chain vest
4923	primitive hatchet
4924	primitive club
4925	primitive hand blade
4926	chen s empty keg
4928	sandrunner wristguards
4929	light scorpid armor
4930	handmade leather bag
4931	hickory shortbow
4932	harpy wing clipper
4933	seasoned fighter s cloak
4935	wide metal girdle
4936	dirt trodden boots
4937	charging buckler
4938	blemished wooden staff
4939	steady bastard sword
4940	veiled grips
4941	really sticky glue
4942	tiger hide boots
4944	handsewn cloak
4945	faintly glowing skull
4946	lightweight boots
4947	jagged dagger
4948	stinging mace
4949	orcish cleaver
4951	squealer s belt
4952	stormstout
4953	trogg ale
4954	nomadic belt
4958	sun beaten cloak
4959	throwing tomahawk
4960	flash pellet
4961	dreamwatcher staff
4962	double layered gloves
4963	thunderhorn cloak
4964	goblin smasher
4965	bloodhoof hand axe
4966	mazzranache s head
4967	tribal warrior s shield
4968	bound harness
4969	fortified bindings
4970	rough hewn kodo leggings
4971	skorn s hammer
4972	cliff runner boots
4973	plains hunter wristguards
4974	compact fighting knife
4975	vigilant buckler
4976	mistspray kilt
4977	sword of hammerfall
4978	ryedol s hammer
4979	enchanted stonecloth bracers
4980	prospector gloves
4981	agmond s belt pouch
4982	ripped prospector belt
4983	rock pulverizer
4984	skull of impending doom
4986	flawed power stone
4987	dwarf captain s sword
4988	burning obsidian band
4989	mage dragon robe
4990	scorched bands
4992	recruitment letter
4995	signed recruitment letter
4998	blood ring
4999	azora s will
5000	coral band
5001	heart ring
5002	glowing green talisman
5003	crystal starfire medallion
5004	mark of the kirin tor
5005	emberspark pendant
5006	khazgorm s journal
5007	band of thorns
5008	quicksilver ring
5009	mindbender loop
5010	inscribed gold ring
5011	welken ring
5012	fungal spores
5013	fertile bulb
5014	wrapping paper pt
5015	wrapped item pt
5016	artisan s trousers
5017	nitroglycerin
5018	wood pulp
5019	sodium nitrate
5020	kolkar booty key
5021	explosive stick of gann
5022	barak s head
5023	verog s head
5024	frost vial
5025	hezrul s head
5026	fire tar
5027	rendered spores
5028	lord sakrasis scepter
5029	talisman of the naga lord
5030	centaur bracers
5038	tear of the moons
5040	shadow hunter knife
5042	red ribboned wrapping paper
5043	red ribboned gift
5044	blue ribboned gift
5045	skull gift
5048	blue ribboned wrapping paper
5049	self locking ironpaper
5050	ignition key
5051	dig rat
5052	unconscious dig rat
5054	samophlange
5055	intact raptor horn
5056	root sample
5057	ripe watermelon
5058	silithid egg
5059	digging claw
5060	thieves tools
5061	stolen silver
5062	raptor head
5063	kreenig snarlsnout s tusk
5064	witchwing talon
5065	harpy lieutenant ring
5066	fissure plant
5067	serena s head
5068	dried seeds
5069	fire wand
5071	shadow wand
5072	lok s skull
5073	nak s skull
5074	kuz s skull
5075	blood shard
5076	shipment of boots
5077	telescopic lens
5078	theramore medal
5079	cold basilisk eye
5080	gazlowe s ledger
5081	kodo hide bag
5082	thin kodo leather
5083	pattern kodo hide bag
5084	baron longshore s head
5085	bristleback quilboar tusk
5086	zhevra hooves
5087	plainstrider beak
5088	control console operating manual
5089	console key
5092	charred razormane wand
5093	razormane backstabber
5094	razormane war shield
5095	rainbow fin albacore
5096	prowler claws
5097	cats eye emerald
5098	altered snapjaw shell
5099	hoof of lakota mani
5100	echeyakee s hide
5101	ishamuhale s fang
5102	owatanka s tailspike
5103	washte pawne s feather
5104	heart of isha awak
5105	explosive shell
5106	red defias mask
5107	deckhand s shirt
5108	dark iron leather
5109	stonesplinter rags
5110	dalaran wizard s robe
5111	rathorian s cape
5112	ritual blade
5113	mark of the syndicate
5114	severed talon
5115	broken wishbone
5116	long tail feather
5117	vibrant plume
5118	large flat tooth
5119	fine loose hair
5120	long tail hair
5121	dirty kodo scale
5122	thick kodo hair
5123	steel arrowhead
5124	small raptor tooth
5125	charged scale
5126	knowledge defias disguise
5127	knowledge south seas pirate disguise
5128	shed lizard skin
5129	knowledge dark iron dwarf disguise
5130	knowledge dalaran wizard disguise
5131	knowledge stonesplinter disguise
5132	knowledge syndicate disguise
5133	seeping gizzard
5134	small furry paw
5135	thin black claw
5136	torn furry ear
5137	bright eyeball
5138	harvester s head
5139	book of thorns
5140	flash powder
5141	book of regrowth
5142	book of wrath ii
5143	thunder lizard blood
5145	book of healing touch ii
5147	book of entangling roots ii
5148	book of thorns ii
5149	book of wrath iii
5150	book of healing touch iii
5151	book of wrath iv
5152	book of healing touch iv
5153	book of mark of the wild iv
5154	book of thorns iii
5155	book of mark of the wild ii
5156	book of wrath v
5158	book of tranquility
5160	book of healing touch v
5163	book of mark of the wild iii
5164	thunderhawk wings
5165	sunscale feather
5166	webwood venom sac
5167	webwood egg
5168	timberling seed
5169	timberling sprout
5170	mossy tumor
5172	death capsule
5173	deathweed
5174	note from neeru
5175	earth totem
5176	fire totem
5177	water totem
5178	air totem
5179	moss twined heart
5180	necklace of harmony
5181	vibrant silk cape
5182	shiver blade
5183	pulsating hydra heart
5184	filled crystal phial
5185	crystal phial
5186	partially filled vessel
5187	rhahk zor s hammer
5188	filled vessel
5189	glowing fruit
5190	shimmering frond
5191	cruel barb
5192	thief s blade
5193	cape of the brotherhood
5194	taskmaster axe
5195	gold flecked gloves
5196	smite s reaver
5197	cookie s tenderizer
5198	cookie s stirring rod
5199	smelting pants
5200	impaling harpoon
5201	emberstone staff
5202	corsair s overshirt
5203	flatland prowler claw
5204	bloodfeather belt
5205	sprouted frond
5206	bogling root
5207	opaque wand
5208	smoldering wand
5209	gloom wand
5210	burning wand
5211	dusk wand
5212	blazing wand
5213	scorching wand
5214	wand of eventide
5215	ember wand
5216	umbral wand
5217	tainted heart
5218	cleansed timberling heart
5219	inscribed bark
5220	gnarlpine fang
5221	melenas head
5223	empty mana gem
5227	empty mana jewel
5229	handstitched leather bracers
5232	minor soulstone
5233	stone of relu
5234	flagongut s fossil
5235	alchemist s wand
5236	combustible wand
5237	mind numbing poison
5238	pitchwood wand
5239	blackbone wand
5240	torchlight wand
5241	dwarven flamestick
5242	cinder wand
5243	firebelcher
5244	consecrated wand
5245	summoner s wand
5246	excavation rod
5247	rod of sorrow
5248	flash wand
5249	burning sliver
5250	charred wand
5251	phial of scrying
5252	wand of decay
5253	goblin igniter
5254	rugged spaulders
5255	quilboar tomahawk
5256	kovork s rattle
5257	dark hooded cape
5259	flaming arrows
5263	pocket lint
5264	complimentary beer token
5265	watered down beer
5266	eye of adaegus
5267	scarlet kris
5268	cracked silithid shell
5269	silithid ichor
5270	death cap
5271	scaber stalk
5272	insane scribbles
5273	mathystra relic
5274	rose mantle
5275	binding girdle
5279	harpy skinner
5283	monster dagger ornate spikey base
5299	gloves of the moon
5302	cobalt buckler
5306	wind rider staff
5309	privateer musket
5310	sea dog britches
5311	buckled boots
5312	riveted gauntlets
5313	totemic clan ring
5314	boar hunter s cape
5315	timberland armguards
5316	barkshell tunic
5317	dry moss tunic
5318	zhovur axe
5319	bashing pauldrons
5320	padded lamellar boots
5321	elegant shortsword
5322	demolition hammer
5323	everglow lantern
5324	engineer s hammer
5325	welding shield
5326	flaring baton
5327	greasy tinker s pants
5328	cinched belt
5329	cat figurine
5330	elven cup relic
5332	glowing cat figurine
5333	mathystra relic
5335	a sack of coins
5336	grell earring
5337	wayfaring gloves
5338	ancient moonstone seal
5339	serpentbloom
5340	cauldron stirrer
5341	spore covered tunic
5342	raptor punch
5343	barkeeper s cloak
5344	pointed axe
5345	stonewood hammer
5346	orcish battle bow
5347	pestilent wand
5348	worn parchment
5349	conjured muffin
5350	conjured water
5351	bounty hunter s ring
5352	book the powers below
5353	message for elissa starbreeze
5354	letter to delgren
5355	beastmaster s girdle
5356	branding rod
5357	ward of the vale
5359	lorgalis manuscript
5360	highborne relic
5361	fishbone toothpick
5362	chew toy
5363	folded handkerchief
5364	dry salt lick
5366	glowing soul gem
5367	primitive rock tool
5368	empty wallet
5369	gnawed bone
5370	bent spoon
5371	piece of coral
5373	lucky charm
5374	small pocket watch
5375	scratching stick
5376	broken mirror
5377	scallop shell
5379	broken boot knife
5380	sealed letter to elissa
5381	sealed letter to balthule
5382	anaya s pendant
5383	athrikus narassin s head
5385	crawler leg
5386	fine moonstalker pelt
5387	enchanted moonstalker cloak
5388	ran bloodtooth s skull
5389	corrupted furbolg totem
5390	fandral s message
5391	rare earth
5392	thistlewood dagger
5393	thistlewood staff
5394	archery training gloves
5395	woodland shield
5396	key to searing gorge
5397	defias gunpowder
5398	canopy leggings
5399	tracking boots
5400	blood of cobrahn
5401	blood of pythas
5402	blood of anacondra
5403	blood of serpentis
5404	serpent s shoulders
5405	draped cloak
5406	empty minor bloodstone
5411	winterhoof cleansing totem
5412	thresher eye
5413	moonstalker fang
5414	grizzled scalp
5415	thunderhorn cleansing totem
5416	wildmane cleansing totem
5419	feral bracers
5420	banshee armor
5421	fiery blaze enchantment
5422	brambleweed leggings
5423	boahn s fang
5424	ancient statuette
5425	runescale girdle
5426	serpent s kiss
5427	crude pocket watch
5428	an exotic cookbook
5429	a pretty rock
5430	intricate bauble
5431	empty hip flask
5432	hickory pipe
5433	rag doll
5435	shiny dinglehopper
5437	bathran s hair
5439	small quiver
5440	bottle of disease
5441	small shot pouch
5442	head of arugal
5443	gold plated buckler
5444	miner s cape
5445	ring of zoram
5446	broken elemental bracer
5447	damaged elemental bracer
5448	fractured elemental bracer
5451	crushed elemental bracer
5455	divined scroll
5456	divining scroll
5457	severed voodoo claw
5458	dirtwood belt
5459	defender axe
5460	orendil s cure
5461	branch of cenarius
5462	dartol s rod of transformation
5463	glowing gem
5464	iron shaft
5465	small spider leg
5466	scorpid stinger
5467	kodo meat
5468	soft frenzy flesh
5469	strider meat
5470	thunder lizard tail
5471	stag meat
5472	kaldorei spider kabob
5473	scorpid surprise
5474	roasted kodo meat
5475	wooden key
5476	fillet of frenzy
5477	strider stew
5478	dig rat stew
5479	crispy lizard tail
5480	lean venison
5481	satyr horns
5482	recipe kaldorei spider kabob
5483	recipe scorpid surprise
5484	recipe roasted kodo meat
5485	recipe fillet of frenzy
5486	recipe strider stew
5487	recipe dig rat stew
5488	recipe crispy lizard tail
5489	recipe lean venison
5490	wrathtail head
5493	elune s tear
5494	handful of stardust
5498	small lustrous pearl
5500	iridescent pearl
5503	clam meat
5504	tangy clam meat
5505	teronis journal
5506	beady eye stalk
5507	ornate spyglass
5508	fallen moonstone
5509	healthstone
5510	greater healthstone
5511	lesser healthstone
5512	minor healthstone
5513	mana jade
5514	mana agate
5516	threshadon fang
5517	tiny bronze key
5518	tiny iron key
5519	iron pommel
5520	velinde s journal
5521	velinde s key
5522	spellstone
5523	small barnacled clam
5524	thick shelled clam
5525	boiled clams
5526	clam chowder
5527	goblin deviled clams
5528	recipe clam chowder
5529	tomb dust
5530	blinding powder
5533	ilkrud magthrull s tome
5534	parker s lunch
5535	compendium of the fallen
5536	mythology of the titans
5537	sarilus foulborne s head
5538	vorrel s wedding ring
5539	letter of commendation
5540	pearl handled dagger
5541	iridescent hammer
5542	pearl clasped cloak
5543	plans iridescent hammer
5544	dal bloodclaw s skull
5547	reconstructed rod
5562	the lay of ameth aran
5563	the fall of ameth aran
5565	infernal stone
5566	broken antler
5567	silver hook
5568	smooth pebble
5569	seaweed
5570	deepmoss egg
5571	small black pouch
5572	small green pouch
5573	green leather bag
5574	white leather bag
5575	large green sack
5576	large brown sack
5577	plans rough bronze bracers
5578	plans silvered bronze breastplate
5579	militia warhammer
5580	militia hammer
5581	smooth walking staff
5582	stonetalon sap
5583	fey dragon scale
5584	twilight whisker
5585	courser eye
5586	thistlewood blade
5587	thornroot club
5588	lydon s toxin
5589	moss covered gauntlets
5590	cord bracers
5591	rain spotted cape
5592	shackled girdle
5593	crag buckler
5594	letter to jin zil
5595	thicket hammer
5596	ashwood bow
5601	hatched egg sac
5602	sticky spider webbing
5603	wizbang s gunnysack
5604	elven wand
5605	pruning knife
5606	gardening gloves
5608	living cowl
5609	steadfast cinch
5610	gustweald cloak
5611	tear of grief
5612	ivy cuffs
5613	staff of the purifier
5614	seraph s strike
5615	woodsman sword
5616	gutwrencher
5617	vagabond leggings
5618	scout s cloak
5619	jade phial
5620	vial of innocent blood
5621	tourmaline phial
5622	clergy ring
5623	amethyst phial
5624	circlet of the order
5626	skullchipper
5627	relic blade
5628	zamah s note
5629	hammerfist gloves
5630	windfelt gloves
5631	rage potion
5633	great rage potion
5634	free action potion
5635	sharp claw
5636	delicate feather
5637	large fang
5638	toxic fogger
5639	filled jade phial
5640	recipe rage potion
5641	recipe cowardly flight potion
5642	recipe free action potion
5643	recipe great rage potion
5644	tome of conjure water
5645	filled tourmaline phial
5646	vial of blessed water
5647	tome of blink
5648	tome of frost armor iii
5649	tome of blizzard
5650	tome of conjure water iii
5654	instant toxin
5655	chestnut mare bridle
5656	brown horse bridle
5657	recipe instant toxin
5658	libram seal of might
5659	smoldering embers
5660	libram seal of righteousness
5661	libram seal of righteousness ii
5662	libram seal of righteousness iii
5663	horn of the red wolf
5664	corroded shrapnel
5665	horn of the dire wolf
5666	libram seal of wrath ii
5667	libram seal of wisdom ii
5668	horn of the brown wolf
5669	dust devil debris
5670	libram seal of wrath iv
5671	libram seal of might iii
5672	libram exorcism
5673	libram exorcism ii
5674	libram exorcism iii
5675	crystalized scales
5676	libram sense undead
5677	libram turn undead
5679	libram seal of wisdom iii
5680	libram seal of protection ii
5681	corrosive sap
5682	libram turn undead ii
5683	libram divine shield ii
5684	libram seal of salvation
5685	libram redemption
5686	ordanus head
5687	gatekeeper s key
5689	sleepers key
5690	claw key
5691	barrow key
5692	remote detonator red
5693	remote detonator blue
5694	ng 5 explosives red
5695	ng 5 explosives blue
5696	tablet of shock
5697	tablet of healing totem
5698	tablet of lightning shield
5699	tablet of ghost wolf
5700	tablet of healing totem ii
5701	tablet of sentry totem
5702	tablet of agitating totem ii
5703	tablet of thunderclap
5704	tablet of water breathing
5705	tablet of healing totem iii
5706	tablet of serpent totem iii
5707	tablet of far sight
5708	tablet of ethereal form
5709	tablet of water walking
5710	tablet of healing totem iv
5711	tablet of ghost wolf ii
5712	tablet of serpent totem iv
5713	tablet of thunderbolt
5714	tablet of ensnaring totem ii
5715	tablet of lightning storm iii
5716	tablet of restoration vi
5717	venture co letters
5718	venture co engineering plans
5719	grimoire of life drain ii
5720	grimoire of curse of mannoroth ii
5721	grimoire of create spellstone
5722	grimoire of siphon mana ii
5723	grimoire of curse of sargeras iii
5724	grimoire of curse of tongues
5725	grimoire of pestilence iii
5726	grimoire of create greater bloodstone
5727	grimoire of mana funnel
5728	grimoire of rain of fire ii
5729	grimoire of fear iii
5730	book of rejuvenation
5731	scroll of messaging
5732	ng 5
5733	unidentified ore
5734	super reaper 6000 blueprints
5735	sealed envelope
5736	gerenzo s mechanical arm
5737	covert ops plans alpha & beta
5738	covert ops pack
5739	barbaric harness
5740	red fireworks rocket
5741	rock chip
5742	gemstone dagger
5743	prismstone ring
5744	pale skinner
5748	centaur longbow
5749	scythe axe
5750	warchief s girdle
5751	webwing cloak
5752	wyvern tailspike
5753	ruffled chaplet
5754	wolfpack medallion
5755	onyx shredder plate
5756	sliverblade
5757	hardwood cudgel
5758	mithril lockbox
5759	thorium lockbox
5760	eternium lockbox
5761	anvilmar sledge
5762	red linen bag
5763	red woolen bag
5764	green silk pack
5765	black silk pack
5766	lesser wizard s robe
5767	violet robes
5768	gnome voucher
5769	goblin voucher
5770	robes of arcana
5771	pattern red linen bag
5772	pattern red woolen bag
5773	pattern robes of arcana
5774	pattern green silk pack
5775	pattern black silk pack
5776	elder s cane
5777	brave s axe
5778	primitive walking stick
5779	forsaken bastard sword
5780	murloc scale belt
5781	murloc scale breastplate
5782	thick murloc armor
5783	murloc scale bracers
5784	slimy murloc scale
5785	thick murloc scale
5786	pattern murloc scale belt
5787	pattern murloc scale breastplate
5788	pattern thick murloc armor
5789	pattern murloc scale bracers
5790	lonebrow s journal
5791	henrig lonebrow s journal
5792	razorflank s medallion
5793	razorflank s heart
5794	salty scorpid venom
5795	hardened tortoise shell
5796	encrusted tail fin
5797	indurium flake
5798	rocket car parts
5799	kravel s parts order
5800	kravel s parts
5801	kraul guano
5802	delicate car parts
5803	speck of dream dust
5804	goblin rumors
5805	heart of zeal
5806	fool s stout
5807	fool s stout report
5808	pridewing venom sac
5809	highperch venom sac
5810	fresh carcass
5811	frostmaw s mane
5812	robes of antiquity
5813	emil s brand
5814	snapbrook armor
5815	glacial stone
5816	light of elune
5817	lunaris bow
5818	moonbeam wand
5819	sunblaze coif
5820	faerie mantle
5821	darkstalker boots
5822	hedgeseed gauntlets
5823	poisonous mushroom
5824	tablet of will
5825	treshala s pendant
5826	kravel s scheme
5827	fizzle brassbolts letter
5829	razor sharp beak
5830	kenata s head
5831	fardel s head
5832	marcel s head
5833	indurium ore
5834	mok morokk s snuff
5835	mok morokk s grog
5836	mok morokk s strongbox
5837	steelsnap s rib
5838	kodo skin scroll
5839	journal page
5840	searing tongue
5841	searing heart
5842	unrefined ore sample
5843	grenka s claw
5844	fragments of rok alim
5845	flank of meat
5846	korran s sealed note
5847	mirefin head
5848	hollow vulture bone
5849	crate of crash helmets
5850	belgrom s sealed note
5851	cozzle s key
5852	fuel regulator blueprints
5853	intact silithid carapace
5854	silithid talon
5855	silithid heart
5857	gnome prize box
5858	goblin prize box
5859	party grenade
5860	legacy of the aspects
5861	beginnings of the undead threat
5862	seaforium booster
5863	guild charter
5864	gray ram
5865	modified seaforium booster
5866	sample of indurium ore
5867	etched phial
5868	filled etched phial
5869	cloven hoof
5871	large hoof
5872	brown ram
5873	white ram
5874	harness black ram
5875	harness blue ram
5876	blueleaf tuber
5877	cracked silithid carapace
5878	super snuff
5879	twilight pendant
5880	crate with holes
5881	head of kelris
5882	captain s documents
5883	forked mudrock tongue
5884	unpopped darkmist eye
5897	snufflenose owner s manual
5916	gnome camera key
5917	spy s report
5918	defiant orc head
5919	blackened iron shield
5936	animal skin belt
5937	goblin camera key
5938	pristine crawler leg
5939	sewing gloves
5940	bone buckler
5941	brass scale pants
5942	jeweled pendant
5943	rift bracers
5944	greaves of the people s militia
5945	deadmire s tooth
5946	sealed note to elling
5947	defias docket
5948	letter to jorgen
5949	scrap of paper
5950	reethe s badge
5951	moist towelette
5952	corrupted brain stem
5956	blacksmith hammer
5957	handstitched leather vest
5958	fine leather pants
5959	acidic venom sac
5960	sealed note to watcher backus
5961	dark leather pants
5962	guardian pants
5963	barbaric leggings
5964	barbaric shoulders
5965	guardian cloak
5966	guardian gloves
5967	girdle of nobility
5968	rugged boots
5969	regent s cloak
5970	serpent gloves
5971	feathered cape
5972	pattern fine leather pants
5973	pattern barbaric leggings
5974	pattern guardian cloak
5975	ruffian belt
5976	guild tabard
5996	elixir of water breathing
5997	elixir of minor defense
5998	stormpike s request
6016	wolf heart sample
6037	truesilver bar
6038	giant clam scorcho
6039	recipe giant clam scorcho
6040	golden scale bracers
6041	steel weapon chain
6042	iron shield spike
6043	iron counterweight
6044	plans iron shield spike
6045	plans iron counterweight
6046	plans steel weapon chain
6047	plans golden scale coif
6048	shadow protection potion
6049	fire protection potion
6050	frost protection potion
6051	holy protection potion
6052	nature protection potion
6053	recipe holy protection potion
6054	recipe shadow protection potion
6055	recipe fire protection potion
6056	recipe frost protection potion
6057	recipe nature protection potion
6058	blackened leather belt
6059	nomadic vest
6060	flax bracers
6061	graystone bracers
6062	heavy cord bracers
6063	cold steel gauntlets
6064	miniature platinum discs
6065	khadgar s essays on dimensional convergence
6066	khan dez hepah s head
6067	centaur ear
6068	recipe shadow oil
6069	crudely dried meat
6070	wolfskin bracers
6071	draenethyst crystal
6072	khan jehn s head
6073	khan shaka s head
6074	war horn mouthpiece
6075	vimes s report
6076	tapered pants
6077	maraudine key fragment
6078	pikeman shield
6079	crude charm
6080	shadow panther heart
6081	mire lord fungus
6082	green whelp blood
6083	broken tears
6084	stormwind guard leggings
6085	footman tunic
6086	faustin s truth serum
6087	chausses of westfall
6089	zraedus s brew
6091	crate of power stones
6092	black whelp boots
6093	orc crusher
6094	piercing axe
6095	wandering boots
6096	apprentice s shirt
6097	acolyte s shirt
6098	neophyte s robe
6116	apprentice s robe
6117	squire s shirt
6118	squire s pants
6119	neophyte s robe
6120	recruit s shirt
6121	recruit s pants
6122	recruit s boots
6123	novice s robe
6124	novice s pants
6125	brawler s harness
6126	trapper s pants
6127	trapper s boots
6129	acolyte s robe
6130	trapper s shirt
6131	trapper s pants
6132	libram seal of wisdom
6133	libram seal of fury
6134	primitive mantle
6135	primitive kilt
6136	thug shirt
6137	thug pants
6138	thug boots
6139	novice s robe
6140	apprentice s robe
6144	neophyte s robe
6145	clarice s pendant
6146	sundried driftwood
6148	web covered boots
6149	greater mana potion
6150	a frayed knot
6166	coyote jawbone
6167	neeka s report
6168	sawtooth snapper claw
6169	unprepared sawtooth flank
6170	wizards reagents
6171	wolf handler gloves
6172	lost supplies
6173	snow boots
6174	twain random sword
6175	atal ai artifact
6176	dwarven kite shield
6177	ironwrought bracers
6178	shipment to nethergarde
6179	privateer s cape
6180	slarkskin
6181	fetish of hakkar
6182	dim torch
6183	unlit poor torch
6184	monstrous crawler leg
6185	bear shawl
6186	trogg slicer
6187	dwarven defender
6188	mud stompers
6189	durable chain shoulders
6190	draenethyst shard
6191	kimbra boots
6192	khan hratha s head
6193	bundle of atal ai artifacts
6194	barreling reaper
6195	wax polished armor
6196	noboru s cudgel
6197	loch croc hide vest
6198	jurassic wristguards
6199	black widow band
6200	garneg s war belt
6201	lithe boots
6202	fingerless gloves
6203	thuggish shield
6204	tribal worg helm
6205	burrowing shovel
6206	rock chipper
6207	pvp horde tower plans
6208	pvp alliance tower plans
6209	pvp horde mine deed
6210	pvp alliance mine deed
6211	recipe elixir of ogre s strength
6212	head of jammal an
6214	heavy copper maul
6215	balanced fighting stick
6216	mystical powder
6217	copper rod
6218	runed copper rod
6219	arclight spanner
6220	meteor shard
6222	formula imbue chest minor spirit
6223	crest of darkshire
6226	bloody apron
6238	brown linen robe
6239	red linen vest
6240	blue linen vest
6241	white linen robe
6242	blue linen robe
6243	green woolen robe
6245	karnitol s satchel
6246	hatefury claw
6247	hatefury horn
6248	scorpashi venom
6249	aged kodo hide
6250	felhound brain
6251	nether wing
6252	doomwarder blood
6253	leftwitch s package
6256	fishing pole
6257	roc gizzard
6258	ironfur liver
6259	groddoc liver
6260	blue dye
6261	orange dye
6262	galen s journal
6263	blue overalls
6264	greater adept s robe
6265	soul shard
6266	disciple s vest
6267	disciple s pants
6268	pioneer tunic
6269	pioneer trousers
6270	pattern blue linen vest
6271	pattern red linen vest
6272	pattern blue linen robe
6273	pattern green woolen robe
6274	pattern blue overalls
6275	pattern greater adept s robe
6276	musty note
6277	musty parchment
6278	musty scroll
6279	musty letter
6280	musty missive
6281	rattlecage skull
6282	sacred burial trousers
6283	the book of ur
6284	runes of summoning
6285	egalin s grimoire
6286	pure hearts
6287	atal ai tablet fragment
6288	atal ai tablet
6289	raw longjaw mud snapper
6290	brilliant smallfish
6291	raw brilliant smallfish
6292	10 pound mud snapper
6293	dried bat blood
6294	12 pound mud snapper
6295	15 pound mud snapper
6296	patch of bat hair
6298	bloody bat fang
6299	sickly looking fish
6300	husk fragment
6302	delicate insect wing
6303	raw slitherskin mackerel
6304	damp diary page day 4
6305	damp diary page day 87
6306	damp diary page day 512
6307	message in a bottle
6308	raw bristle whisker catfish
6309	17 pound catfish
6310	19 pound catfish
6311	22 pound catfish
6312	dalin s heart
6313	comar s heart
6314	wolfmaster cape
6315	steelarrow crossbow
6316	loch frenzy delight
6317	raw loch frenzy
6318	odo s ley staff
6319	girdle of the blindwatcher
6320	commander s crest
6321	silverlaine s family seal
6323	baron s scepter
6324	robes of arugal
6325	recipe brilliant smallfish
6326	recipe slitherskin mackerel
6327	the pacifier
6328	recipe longjaw mud snapper
6329	recipe loch frenzy delight
6330	recipe bristle whisker catfish
6331	howling blade
6332	black pearl ring
6333	spikelash dagger
6335	grizzled boots
6336	infantry tunic
6337	infantry leggings
6338	silver rod
6339	runed silver rod
6340	fenrus hide
6341	eerie stable lantern
6342	formula enchant chest minor mana
6343	formula imbue chest spirit
6344	formula enchant bracer minor spirit
6345	formula imbue cloak protection
6346	formula enchant chest lesser mana
6347	formula enchant bracer minor strength
6348	formula enchant weapon minor beastslayer
6349	formula enchant 2h weapon lesser intellect
6350	rough bronze boots
6351	dented crate
6352	waterlogged crate
6353	small chest
6354	small locked chest
6355	sturdy locked chest
6356	battered chest
6357	sealed crate
6358	oily blackmouth
6359	firefin snapper
6360	steelscale crushfish
6361	raw rainbow fin albacore
6362	raw rockscale cod
6363	26 pound catfish
6364	32 pound catfish
6365	strong fishing pole
6366	darkwood fishing pole
6367	big iron fishing pole
6368	recipe rainbow fin albacore
6369	recipe rockscale cod
6370	blackmouth oil
6371	fire oil
6372	swim speed potion
6373	elixir of firepower
6374	enchanted powder
6375	formula enchant bracer lesser spirit
6376	formula enchant boots minor stamina
6377	formula enchant boots minor agility
6378	seer s cape
6379	inscribed leather belt
6380	inscribed buckler
6381	bright cloak
6382	forest leather belt
6383	forest buckler
6384	stylish blue shirt
6385	stylish green shirt
6386	glimmering mail legguards
6387	glimmering mail bracers
6388	glimmering mail pauldrons
6389	glimmering mail coif
6390	pattern stylish blue shirt
6391	pattern stylish green shirt
6392	belt of arugal
6393	silver thread gloves
6394	silver thread boots
6395	silver thread amice
6396	emblazoned chestpiece
6397	emblazoned gloves
6398	emblazoned belt
6399	emblazoned shoulders
6400	glimmering shield
6401	pattern dark silk shirt
6402	mail combat leggings
6403	mail combat armguards
6404	mail combat spaulders
6405	nightsky trousers
6406	nightsky boots
6407	nightsky wristbands
6408	insignia gloves
6409	insignia belt
6410	insignia bracers
6411	chief brigadier armor
6412	chief brigadier boots
6413	chief brigadier bracers
6414	seal of sylvanas
6415	aurora robe
6416	aurora boots
6417	aurora cloak
6418	aurora sash
6419	glyphed mitts
6420	glyphed boots
6421	glyphed belt
6422	glyphed helm
6423	blackforge greaves
6424	blackforge cape
6425	blackforge girdle
6426	blackforge bracers
6427	mistscape robe
6428	mistscape gloves
6429	mistscape wizard hat
6430	imperial leather breastplate
6431	imperial leather boots
6432	imperial cloak
6433	imperial leather helm
6435	infused burning gem
6436	burning gem
6438	dull elemental bracer
6439	broken binding bracer
6440	brainlash
6441	shadowstalker scalp
6442	oracle crystal
6443	deviate hide
6444	forked tongue
6445	brittle molting
6446	snakeskin bag
6447	worn turtle shell shield
6448	tail spike
6449	glowing lizardscale cloak
6450	silk bandage
6451	heavy silk bandage
6452	anti venom
6453	strong anti venom
6454	manual strong anti venom
6456	acidic slime
6457	rusted engineering parts
6458	oil covered fish
6459	savage trodders
6460	cobrahn s grasp
6461	slime encrusted pads
6462	secure crate
6463	deep fathom ring
6464	wailing essence
6465	robe of the moccasin
6466	deviate scale cloak
6467	deviate scale gloves
6468	deviate scale belt
6469	venomstrike
6470	deviate scale
6471	perfect deviate scale
6472	stinging viper
6473	armor of the fang
6474	pattern deviate scale cloak
6475	pattern deviate scale gloves
6476	pattern deviate scale belt
6477	grassland sash
6478	rat stompers
6479	malem pendant
6480	slick deviate leggings
6481	dagmire gauntlets
6482	firewalker boots
6486	singed scale
6487	vile familiar head
6488	simple tablet
6489	weatherworn parchment
6490	dark parchment
6491	heavy parchment
6492	sooty parchment
6493	tattered parchment
6494	scrawled parchment
6495	weatherbeaten parchment
6496	detailed parchment
6497	simple parchment
6498	inscribed kodo leather
6499	inscribed kodo leather
6500	inscribed kodo leather
6501	inscribed kodo leather
6502	violet scale armor
6503	harlequin robes
6504	wingblade
6505	crescent staff
6506	infantry boots
6507	infantry bracers
6508	infantry cloak
6509	infantry belt
6510	infantry gauntlets
6511	journeyman s robe
6512	disciple s robe
6513	disciple s sash
6514	disciple s cloak
6515	disciple s gloves
6516	imp summoning scroll
6517	pioneer belt
6518	pioneer boots
6519	pioneer bracers
6520	pioneer cloak
6521	pioneer gloves
6522	deviate fish
6523	buckled harness
6524	studded leather harness
6525	grunt s harness
6526	battle harness
6527	ancestral robe
6528	spellbinder robe
6529	shiny bauble
6530	nightcrawlers
6531	barbaric cloth robe
6532	bright baubles
6533	aquadynamic fish attractor
6534	forged steel bars
6535	tablet of verga
6536	willow vest
6537	willow boots
6538	willow robe
6539	willow belt
6540	willow pants
6541	willow gloves
6542	willow cape
6543	willow bracers
6544	voidwalker summoning scroll
6545	soldier s armor
6546	soldier s leggings
6547	soldier s gauntlets
6548	soldier s girdle
6549	soldier s cloak
6550	soldier s wristguards
6551	soldier s boots
6552	bard s tunic
6553	bard s trousers
6554	bard s gloves
6555	bard s cloak
6556	bard s bracers
6557	bard s boots
6558	bard s belt
6559	bard s buckler
6560	soldier s shield
6561	seer s padded armor
6562	shimmering boots
6563	shimmering bracers
6564	shimmering cloak
6565	shimmering gloves
6566	shimmering amice
6567	shimmering armor
6568	shimmering trousers
6569	shimmering robe
6570	shimmering sash
6571	scouting buckler
6572	defender shield
6573	defender boots
6574	defender bracers
6575	defender cloak
6576	defender girdle
6577	defender gauntlets
6578	defender leggings
6579	defender spaulders
6580	defender tunic
6581	scouting belt
6582	scouting boots
6583	scouting bracers
6584	scouting tunic
6585	scouting cloak
6586	scouting gloves
6587	scouting trousers
6588	scouting spaulders
6589	viridian band
6590	battleforge boots
6591	battleforge wristguards
6592	battleforge armor
6593	battleforge cloak
6594	battleforge girdle
6595	battleforge gauntlets
6596	battleforge legguards
6597	battleforge shoulderguards
6598	dervish buckler
6599	battleforge shield
6600	dervish belt
6601	dervish boots
6602	dervish bracers
6603	dervish tunic
6604	dervish cape
6605	dervish gloves
6607	dervish leggings
6608	bright armor
6609	sage s cloth
6610	sage s robe
6611	sage s sash
6612	sage s boots
6613	sage s bracers
6614	sage s cloak
6615	sage s gloves
6616	sage s pants
6617	sage s mantle
6619	manual the path of defense
6620	elaborate parchment
6621	manual of taunt
6622	sword of zeal
6623	succubus summoning scroll
6624	ken zigla s draught
6625	dirt caked pendant
6626	dogran s pendant
6627	mutant scale breastplate
6628	raven s claws
6629	sporid cape
6630	seedcloud buckler
6631	living root
6632	feyscale cloak
6633	butcher s slicer
6634	ritual salve
6635	earth sapta
6636	fire sapta
6637	water sapta
6638	air sapta
6640	felstalker hoof
6641	haunting blade
6642	phantom armor
6643	bloated smallfish
6644	bloated mackerel
6645	bloated mud snapper
6646	bloated albacore
6647	bloated catfish
6648	stoneskin totem scroll
6649	searing totem scroll
6650	healing stream totem scroll
6651	broken wine bottle
6652	reagent pouch
6653	torch of the dormant flame
6654	torch of the eternal flame
6655	glowing ember
6656	rough quartz
6657	savory deviate delight
6658	example collar
6659	scarab trousers
6660	julie s dagger
6661	recipe savory deviate delight
6662	elixir of giant growth
6663	recipe elixir of giant growth
6664	voodoo mantle
6665	hexed bracers
6666	dredge boots
6667	engineer s cloak
6668	draftsman boots
6669	sacred band
6670	panther armor
6671	juggernaut leggings
6672	schematic flash bomb
6675	tempered bracers
6676	constable buckler
6677	spellcrafter wand
6678	band of elven grace
6679	armor piercer
6681	thornspike
6682	death speaker robes
6684	snufflenose command stick
6685	death speaker mantle
6686	tusken helm
6687	corpsemaker
6688	whisperwind headdress
6689	wind spirit staff
6690	ferine leggings
6691	swinetusk shank
6692	pronged reaver
6693	agamaggan s clutch
6694	heart of agamaggan
6695	stygian bone amulet
6696	nightstalker bow
6697	batwing mantle
6698	stone of pierce
6707	stone of lapidis
6708	stone of goodman
6709	moonglow vest
6710	pattern moonglow vest
6711	stone of kurtz
6712	practice lock
6713	ripped pants
6714	ez thro dynamite
6715	ruined jumper cables
6716	schematic ez thro dynamite
6717	gaffer jack
6718	electropeller
6719	windborne belt
6720	spirit hunter headdress
6721	chestplate of kor
6722	beastial manacles
6723	medal of courage
6724	stone of backus
6725	marbled buckler
6726	razzeric s customized seatbelt
6727	razzeric s racing grips
6728	stone of brownell
6729	fizzle s zippy lighter
6730	ironforge chain
6731	ironforge breastplate
6732	gnomish mechanic s gloves
6733	ironforge gauntlets
6734	plans ironforge chain
6735	plans ironforge breastplate
6736	plans ironforge gauntlets
6737	dryleaf pants
6738	bleeding crescent
6739	cliffrunner s aim
6740	azure sash
6741	orcish war sword
6742	stonefist girdle
6743	sustaining ring
6744	gloves of kapelan
6745	swiftrunner cape
6746	basalt buckler
6747	enforcer pauldrons
6748	monkey ring
6749	tiger band
6750	snake hoop
6751	mourning shawl
6752	lancer boots
6753	feather charm
6754	large moneybag
6755	a small container of gems
6756	jewelry box
6757	jaina s signet ring
6766	flayed demon skin old2
6767	tyranis pendant
6773	gelkis marauder chain
6774	uthek s finger
6775	tome of divinity
6776	tome of valor
6777	tome of righteousness
6778	tome of justice
6779	tome of nobility
6780	lilac sash
6781	bartleby s mug
6782	marshal haggard s badge
6783	dead tooth s key
6784	braced handguards
6785	powers of the void
6786	simple dress
6787	white woolen dress
6788	magram hunter s belt
6789	ceremonial centaur blanket
6790	ring of calm
6791	hellion boots
6792	sanguine pauldrons
6793	auric bracers
6794	stormfire gauntlets
6795	white swashbuckler s shirt
6796	red swashbuckler s shirt
6797	eyepoker
6798	blasting hackbut
6799	vejrek s head
6800	umbral ore
6801	baroque apron
6802	sword of omen
6803	prophetic cane
6804	windstorm hammer
6805	horn of vorlus
6806	dancing flame
6807	frog leg stew
6808	elunite ore
6809	elura s medallion
6810	surena s choker
6811	aquadynamic fish lens
6812	case of elunite
6826	brilliant scale
6827	box of supplies
6828	visionary buckler
6829	sword of serenity
6830	bonebiter
6831	black menace
6832	cloak of blight
6833	white tuxedo shirt
6834	black tuxedo
6835	black tuxedo pants
6836	dress shoes
6837	wedding dress
6838	scorched spider fang
6839	charred horn
6840	galvanized horn
6841	vial of phlogiston
6842	furen s instructions
6843	cask of scalder
6844	burning blood
6845	burning rock
6846	defias script
6847	dark iron script
6848	searing coral
6849	sunscorched shell
6850	bloodscalp scalp
6851	essence of the exile
6852	eternal eye
6866	symbol of life
6887	spotted yellowtail
6888	herb baked egg
6889	small egg
6890	smoked bear meat
6891	recipe herb baked egg
6892	recipe smoked bear meat
6893	workshop key
6894	whirlwind heart
6895	jordan s smithing hammer
6897	manual path of the berserker
6898	orb of soran ruk
6899	warlock orb 35
6900	enchanted gold bloodrobe
6901	glowing thresher cape
6902	bands of serra kis
6903	gaze dreamer pants
6904	bite of serra kis
6905	reef axe
6906	algae fists
6907	tortoise armor
6908	ghamoo ra s bind
6909	strike of the hydra
6910	leech pants
6911	moss cinch
6912	heartswood
6913	heartswood core
6914	soran ruk fragment
6915	large soran ruk fragment
6916	tome of divinity
6926	furen s notes
6927	big will s ear
6928	bloodstone choker
6929	bath rah s parchment
6930	rod of channeling
6931	moldy tome
6947	instant poison
6948	hearthstone
6949	instant poison ii
6950	instant poison iii
6951	mind numbing poison ii
6952	thick bear fur
6953	verigan s fist
6966	elunite axe
6967	elunite sword
6968	elunite hammer
6969	elunite dagger
6970	furen s favor
6971	fire hardened coif
6972	fire hardened hauberk
6973	fire hardened leggings
6974	fire hardened gauntlets
6975	whirlwind axe
6976	whirlwind warhammer
6977	whirlwind sword
6978	umbral axe
6979	haggard s axe
6980	haggard s dagger
6981	umbral dagger
6982	umbral mace
6983	haggard s hammer
6984	umbral sword
6985	haggard s sword
6986	crimson lotus
6987	fish scale
6988	felhunter summoning scroll
6989	vial of hatefury blood
6990	lesser infernal stone
6991	smoldering coal
6992	jordan s ore shipment
6993	jordan s refined ore shipment
6994	whitestone oak lumber
6995	corrupted kor gem
6996	jordan s weapon notes
6997	tattered manuscript
6998	nimbus boots
6999	tome of the cabal
7000	heartwood girdle
7001	gravestone scepter
7002	arctic buckler
7003	beetle clasps
7004	prelacy cape
7005	skinning knife
7006	reconstructed tome
7007	backus phat lewt
7026	linen belt
7027	boots of darkness
7046	azure silk pants
7047	hands of darkness
7048	azure silk hood
7049	truefaith gloves
7050	silk headband
7051	earthen vest
7052	azure silk belt
7053	azure silk cloak
7054	robe of power
7055	crimson silk belt
7056	crimson silk cloak
7057	green silken shoulders
7058	crimson silk vest
7059	crimson silk shoulders
7060	azure shoulders
7061	earthen silk belt
7062	crimson silk pantaloons
7063	crimson silk robe
7064	crimson silk gloves
7065	green silk armor
7067	elemental earth
7068	elemental fire
7069	elemental air
7070	elemental water
7071	iron buckle
7072	naga scale
7073	broken fang
7074	chipped claw
7075	core of earth
7076	essence of earth
7077	heart of fire
7078	essence of fire
7079	globe of water
7080	essence of water
7081	breath of wind
7082	essence of air
7083	purified kor gem
7084	pattern crimson silk shoulders
7085	pattern azure shoulders
7086	pattern earthen silk belt
7087	pattern crimson silk cloak
7088	pattern crimson silk robe
7089	pattern azure silk cloak
7090	pattern green silk armor
7091	pattern truefaith gloves
7092	pattern hands of darkness
7093	pattern boots of darkness
7094	driftwood branch
7095	bog boots
7096	plucked feather
7097	leg meat
7098	splintered tusk
7099	severed pincer
7100	sticky ichor
7101	bug eye
7106	zodiac gloves
7107	belt of the stars
7108	infantry shield
7109	pioneer buckler
7110	silver thread armor
7111	nightsky armor
7112	aurora armor
7113	mistscape armor
7114	pattern azure silk gloves
7115	heirloom axe
7116	heirloom dagger
7117	heirloom hammer
7118	heirloom sword
7119	twitching antenna
7120	ruga s bulwark
7126	smoky iron ingot
7127	powdered azurite
7128	uncloven satyr hoof
7129	brutal gauntlets
7130	brutal helm
7131	dragonmaw shinbone
7132	brutal legguards
7133	brutal hauberk
7134	sturdy dragonmaw shinbone
7135	broken dragonmaw shinbone
7146	the scarlet key
7148	goblin jumper cables
7166	copper dagger
7170	twain random sword foo
7187	vancleef s boots
7188	stormwind guard shield
7189	goblin rocket boots
7190	scorched rocket boots
7191	fused wiring
7192	plans goblin rocket boots
7206	mirror lake water sample
7207	jennea s flask
7208	tazan s key
7209	tazan s satchel
7226	mage tastic gizmonitor
7227	balnir snapdragons
7228	tigule and foror s strawberry ice cream
7229	explorer s vest
7230	smite s mighty hammer
7231	astor s letter of introduction
7247	chest of containment coffers
7249	charged rift gem
7266	ur s treatise on shadow magic
7267	pristine spider silk
7268	xavian water sample
7269	deino s flask
7270	laughing sister s hair
7271	flawless ivory tusk
7272	bolt charged bramble
7273	witherbark totem stick
7274	rituals of power
7275	the agamaggan scrolls
7276	handstitched leather cloak
7277	handstitched leather bracers
7278	light leather quiver
7279	small leather ammo pouch
7280	rugged leather pants
7281	light leather bracers
7282	light leather pants
7283	black whelp cloak
7284	red whelp gloves
7285	nimble leather gloves
7286	black whelp scale
7287	red whelp scale
7288	pattern rugged leather pants
7289	pattern black whelp cloak
7290	pattern red whelp gloves
7291	infernal orb
7292	filled containment coffer
7293	dalaran mana gem
7294	andron s ledger
7295	tazan s logbook
7296	extinguished torch
7297	morbent s bane
7298	blade of cunning
7306	fenwick s head
7307	flesh eating worm
7308	cantation of manifestation
7309	dalaran status report
7326	thun grim s axe
7327	thun grim s dagger
7328	thun grim s mace
7329	thun grim s sword
7330	infiltrator buckler
7331	phalanx shield
7332	regal armor
7333	overseer s whistle
7334	efflorescent robe
7335	grizzly tunic
7336	wildwood chain
7337	the rock
7338	mood ring
7339	miniscule diamond ring
7340	flawless diamond solitaire
7341	cubic zirconia ring
7342	silver piffeny band
7343	bingles wrench
7344	torch of holy flame
7345	bingles screwdriver
7346	bingles hammer
7347	bingles cog inverter
7348	fletcher s gloves
7349	herbalist s gloves
7350	disciple s bracers
7351	disciple s boots
7352	earthen leather shoulders
7353	elder s padded armor
7354	elder s boots
7355	elder s bracers
7356	elder s cloak
7357	elder s hat
7358	pilferer s gloves
7359	heavy earthen gloves
7360	pattern dark leather gloves
7361	pattern herbalist s gloves
7362	pattern earthen leather shoulders
7363	pattern pilferer s gloves
7364	pattern heavy earthen gloves
7365	gnoam sprecklesprocket
7366	elder s gloves
7367	elder s mantle
7368	elder s pants
7369	elder s robe
7370	elder s sash
7371	heavy quiver
7372	heavy leather ammo pouch
7373	dusky leather leggings
7374	dusky leather armor
7375	green whelp armor
7376	bingles blastencapper
7377	frost leather cloak
7378	dusky bracers
7386	green whelp bracers
7387	dusky belt
7388	skull key
7389	venture co ledger
7390	dusky boots
7391	swift boots
7392	green whelp scale
7406	infiltrator cord
7407	infiltrator armor
7408	infiltrator shoulders
7409	infiltrator boots
7410	infiltrator bracers
7411	infiltrator cloak
7412	infiltrator gloves
7413	infiltrator cap
7414	infiltrator pants
7415	dervish spaulders
7416	phalanx bracers
7417	phalanx boots
7418	phalanx breastplate
7419	phalanx cloak
7420	phalanx headguard
7421	phalanx gauntlets
7422	phalanx girdle
7423	phalanx leggings
7424	phalanx spaulders
7425	cyrik s head
7426	cerulean ring
7427	cerulean talisman
7428	shadowcat hide
7429	twilight armor
7430	twilight robe
7431	twilight pants
7432	twilight cowl
7433	twilight gloves
7434	twilight boots
7435	twilight mantle
7436	twilight cape
7437	twilight cuffs
7438	twilight belt
7439	sentinel breastplate
7440	sentinel trousers
7441	sentinel cap
7442	gyromast s key
7443	sentinel gloves
7444	sentinel boots
7445	sentinel shoulders
7446	sentinel cloak
7447	sentinel bracers
7448	sentinel girdle
7449	pattern dusky leather leggings
7450	pattern green whelp armor
7451	pattern green whelp bracers
7452	pattern dusky boots
7453	pattern swift boots
7454	knight s breastplate
7455	knight s legguards
7456	knight s headguard
7457	knight s gauntlets
7458	knight s boots
7459	knight s pauldrons
7460	knight s cloak
7461	knight s bracers
7462	knight s girdle
7463	sentinel buckler
7464	glyphs of summoning
7465	knight s crest
7466	vermilion band
7467	vermilion necklace
7468	regal robe
7469	regal leggings
7470	regal wizard hat
7471	regal gloves
7472	regal boots
7473	regal mantle
7474	regal cloak
7475	regal cuffs
7476	regal sash
7477	ranger tunic
7478	ranger leggings
7479	ranger helm
7480	ranger gloves
7481	ranger boots
7482	ranger shoulders
7483	ranger cloak
7484	ranger wristguards
7485	ranger cord
7486	captain s breastplate
7487	captain s leggings
7488	captain s circlet
7489	captain s gauntlets
7490	captain s boots
7491	captain s shoulderguards
7492	captain s cloak
7493	captain s bracers
7494	captain s waistguard
7495	captain s buckler
7496	field plate shield
7497	ivory band
7498	top of gelkak s key
7499	middle of gelkak s key
7500	bottom of gelkak s key
7506	gnomish universal remote
7507	arcane orb
7508	ley orb
7509	manaweave robe
7510	lesser spellfire robes
7511	astral knot robe
7512	nether lace robe
7513	ragefire wand
7514	icefury wand
7515	celestial orb
7516	tabetha s instructions
7517	gossamer tunic
7518	gossamer robe
7519	gossamer pants
7520	gossamer headpiece
7521	gossamer gloves
7522	gossamer boots
7523	gossamer shoulderpads
7524	gossamer cape
7525	gossamer bracers
7526	gossamer belt
7527	cabalist chestpiece
7528	cabalist leggings
7529	cabalist helm
7530	cabalist gloves
7531	cabalist boots
7532	cabalist spaulders
7533	cabalist cloak
7534	cabalist bracers
7535	cabalist belt
7536	champion s wall shield
7537	gothic shield
7538	champion s armor
7539	champion s leggings
7540	champion s helmet
7541	champion s gauntlets
7542	champion s greaves
7543	champion s pauldrons
7544	champion s cape
7545	champion s bracers
7546	champion s girdle
7547	onyx ring
7548	onyx choker
7549	fairy s embrace
7550	warrior s honor
7551	entwined opaline talisman
7552	falcon s hook
7553	band of the unicorn
7554	willow branch
7555	regal star
7556	twilight orb
7557	gossamer rod
7558	shimmering stave
7559	runic cane
7560	schematic gnomish universal remote
7561	schematic goblin jumper cables
7566	agamand family sword
7567	agamand family axe
7568	agamand family dagger
7569	agamand family mace
7586	tharnariun s hope
7587	thun grim s instructions
7606	polar gauntlets
7607	sable wand
7608	seer s fine stein
7609	elder s amber stave
7610	aurora sphere
7611	mistscape stave
7613	pattern green leather armor
7626	bundle of furs
7627	dolanaar delivery
7628	nondescript letter
7629	ukor s burden
7646	crate of inn supplies
7666	shattered necklace
7667	talvash s phial of scrying
7668	bloodstained journal
7669	shattered necklace ruby
7670	shattered necklace sapphire
7671	shattered necklace topaz
7672	shattered necklace power source
7673	talvash s enhancing necklace
7674	delivery to mathias
7675	defias shipping schedule
7676	thistle tea
7678	recipe thistle tea
7679	shrike bat fang
7680	jadespine basilisk scale
7681	obsidian golem shard
7682	torturing poker
7683	bloody brass knuckles
7684	bloodmage mantle
7685	orb of the forgotten seer
7686	ironspine s eye
7687	ironspine s fist
7688	ironspine s ribcage
7689	morbid dawn
7690	ebon vise
7691	embalmed shroud
7708	necrotic wand
7709	blighted leggings
7710	loksey s training stick
7711	robe of doan
7712	mantle of doan
7713	illusionary rod
7714	hypnotic blade
7715	onin s report
7716	shattered necklace
7717	ravager
7718	herod s shoulder
7719	raging berserker s helm
7720	whitemane s chapeau
7721	hand of righteousness
7722	triune amulet
7723	mograine s might
7724	gauntlets of divinity
7725	tabard of the scarlet crusade
7726	aegis of the scarlet commander
7727	watchman pauldrons
7728	beguiler robes
7729	chesterfall musket
7730	cobalt crusher
7731	ghostshard talisman
7733	staff of prehistoria
7734	six demon bag
7735	jannok s rose
7736	fight club
7737	sethir s journal
7738	evergreen gloves
7739	timberland cape
7740	gni kiv medallion
7741	the shaft of tsol
7742	schematic gnomish cloaking device
7746	explorers league commendation
7747	vile protector
7748	forcestone buckler
7749	omega orb
7750	mantle of woe
7751	vorrel s boots
7752	dreamslayer
7753	bloodspiller
7754	harbinger boots
7755	flintrock shoulders
7756	dog training gloves
7757	windweaver staff
7758	ruthless shiv
7759	archon chestpiece
7760	warchief kilt
7761	steelclaw reaver
7766	empty brown waterskin
7767	empty blue waterskin
7768	empty red waterskin
7769	filled brown waterskin
7770	filled blue waterskin
7771	filled red waterskin
7786	headsplitter
7787	resplendent guardian
7806	lollipop
7807	candy bar
7808	chocolate square
7809	easter dress
7810	vial of purest water
7811	remaining drops of purest water
7812	corrupt manifestation s bracers
7813	shard of water
7846	crag coyote fang
7847	buzzard gizzard
7848	rock elemental shard
7866	empty thaumaturgy vessel
7867	vessel of dragon s blood
7868	thieven kit
7869	lucius s lockbox
7870	thaumaturgy vessel lockbox
7871	token of thievery
7872	rusty thieves tools
7886	untranslated journal
7887	necklace and gem salvage
7888	jarkal s enhancing necklace
7906	horns of nez ra
7907	certificate of thievery
7908	klaven mortwake s journal
7909	aquamarine
7910	star ruby
7911	truesilver ore
7912	solid stone
7913	barbaric iron shoulders
7914	barbaric iron breastplate
7915	barbaric iron helm
7916	barbaric iron boots
7917	barbaric iron gloves
7918	heavy mithril shoulder
7919	heavy mithril gauntlet
7920	mithril scale pants
7921	heavy mithril pants
7922	steel plate helm
7923	defias tower key
7924	mithril scale bracers
7925	mithril scale gloves
7926	ornate mithril pants
7927	ornate mithril gloves
7928	ornate mithril shoulder
7929	orcish war leggings
7930	heavy mithril breastplate
7931	mithril coif
7932	mithril scale shoulders
7933	heavy mithril boots
7934	heavy mithril helm
7935	ornate mithril breastplate
7936	ornate mithril boots
7937	ornate mithril helm
7938	truesilver gauntlets
7939	truesilver breastplate
7941	heavy mithril axe
7942	blue glittering axe
7943	wicked mithril blade
7944	dazzling mithril rapier
7945	big black mace
7946	runed mithril hammer
7947	ebon shiv
7948	ninja belt
7949	ninja pants
7950	ninja armor
7951	ninja gloves
7952	ninja boots
7953	mask of thero shan
7954	the shatterer
7955	copper claymore
7956	bronze warhammer
7957	bronze greatsword
7958	bronze battle axe
7959	blight
7960	truesilver champion
7961	phantom blade
7963	steel breastplate
7964	solid sharpening stone
7965	solid weightstone
7966	solid grinding stone
7967	mithril shield spike
7968	southsea treasure
7969	mithril spurs
7970	e c a c
7971	black pearl
7972	ichor of undeath
7973	big mouth clam
7974	zesty clam meat
7975	plans heavy mithril pants
7976	plans mithril shield spike
7977	plans mithril scale gloves
7978	plans barbaric iron shoulders
7979	plans barbaric iron breastplate
7980	plans barbaric iron helm
7981	plans barbaric iron boots
7982	plans barbaric iron gloves
7983	plans ornate mithril pants
7984	plans ornate mithril gloves
7985	plans ornate mithril shoulder
7986	plans ornate mithril breastplate
7987	plans ornate mithril helm
7988	plans ornate mithril boots
7989	plans mithril spurs
7990	plans heavy mithril helm
7991	plans mithril scale shoulders
7992	plans blue glittering axe
7993	plans dazzling mithril rapier
7994	plans orcish war leggings
7995	plans mithril scale bracers
7996	lucky fishing hat
7997	red defias mask
8006	the ziggler
8007	mana citrine
8008	mana ruby
8009	dentrium power stone
8026	garrett family treasure
8027	krom stoutarm s treasure
8028	plans runed mithril hammer
8029	plans wicked mithril blade
8030	plans ebon shiv
8046	kearnen s journal
8047	magenta fungus cap
8048	emerald dreamcatcher
8049	gnarlpine necklace
8050	tallonkai s jewel
8051	flare gun
8052	an alleum power stone
8053	obsidian power source
8066	fizzule s whistle
8067	crafted light shot
8068	crafted heavy shot
8069	crafted solid shot
8070	reward voucher
8071	sizzle stick
8072	silixiz s tower key
8073	cache of zanzil s altered mixture
8074	gallywix s head
8075	conjured sourdough
8076	conjured sweet roll
8077	conjured mineral water
8078	conjured sparkling water
8079	conjured crystal water
8080	light plate chestpiece
8081	light plate belt
8082	light plate boots
8083	light plate bracers
8084	light plate gloves
8085	light plate pants
8086	light plate shoulderpads
8087	sample of zanzil s altered mixture
8088	platemail belt
8089	platemail boots
8090	platemail bracers
8091	platemail gloves
8092	platemail helm
8093	platemail leggings
8094	platemail armor
8095	hinott s oil
8106	hibernal armor
8107	hibernal boots
8108	hibernal bracers
8109	hibernal cloak
8110	hibernal gloves
8111	hibernal mantle
8112	hibernal pants
8113	hibernal robe
8114	hibernal sash
8115	hibernal cowl
8116	heraldic belt
8117	heraldic boots
8118	heraldic bracers
8119	heraldic breastplate
8120	heraldic cloak
8121	heraldic gloves
8122	heraldic headpiece
8123	heraldic leggings
8124	heraldic spaulders
8125	myrmidon s bracers
8126	myrmidon s breastplate
8127	myrmidon s cape
8128	myrmidon s gauntlets
8129	myrmidon s girdle
8130	myrmidon s greaves
8131	myrmidon s helm
8132	myrmidon s leggings
8133	myrmidon s pauldrons
8134	myrmidon s defender
8135	chromite shield
8136	gargantuan tumor
8137	chromite bracers
8138	chromite chestplate
8139	chromite gauntlets
8140	chromite girdle
8141	chromite greaves
8142	chromite barbute
8143	chromite legplates
8144	chromite pauldrons
8146	wicked claw
8147	tiny copper key
8148	tiny silver key
8149	voodoo charm
8150	deeprock salt
8151	flask of mojo
8152	flask of big mojo
8153	wildvine
8154	scorpid scale
8155	sathrah s sacrifice
8156	jouster s wristguards
8157	jouster s chestplate
8158	jouster s gauntlets
8159	jouster s girdle
8160	jouster s greaves
8161	jouster s visor
8162	jouster s legplates
8163	jouster s pauldrons
8165	worn dragonscale
8167	turtle scale
8168	jet black feather
8169	thick hide
8170	rugged leather
8171	rugged hide
8172	cured thick hide
8173	thick armor kit
8174	comfortable leather hat
8175	nightscape tunic
8176	nightscape headband
8177	practice sword
8178	training sword
8179	cadet s bow
8180	hunting bow
8181	hunting rifle
8182	pellet rifle
8183	precision bow
8184	firestarter
8185	turtle scale leggings
8186	dire wand
8187	turtle scale gloves
8188	explosive shotgun
8189	turtle scale breastplate
8190	hanzo sword
8191	turtle scale helm
8192	nightscape shoulders
8193	nightscape pants
8194	goblin nutcracker
8195	nightscape cloak
8196	ebon scimitar
8197	nightscape boots
8198	turtle scale bracers
8199	battlefield destroyer
8200	big voodoo robe
8201	big voodoo mask
8202	big voodoo pants
8203	tough scorpid breastplate
8204	tough scorpid gloves
8205	tough scorpid bracers
8206	tough scorpid leggings
8207	tough scorpid shoulders
8208	tough scorpid helm
8209	tough scorpid boots
8210	wild leather shoulders
8211	wild leather vest
8212	wild leather leggings
8213	wild leather boots
8214	wild leather helmet
8215	wild leather cloak
8216	big voodoo cloak
8217	quickdraw quiver
8218	thick leather ammo pouch
8223	blade of the basilisk
8224	silithid ripper
8225	tainted pierce
8226	the butcher
8243	scooby snack
8244	flawless draenethyst sphere
8245	imperial red tunic
8246	imperial red boots
8247	imperial red bracers
8248	imperial red cloak
8249	imperial red gloves
8250	imperial red mantle
8251	imperial red pants
8252	imperial red robe
8253	imperial red sash
8254	imperial red circlet
8255	serpentskin girdle
8256	serpentskin boots
8257	serpentskin bracers
8258	serpentskin armor
8259	serpentskin cloak
8260	serpentskin gloves
8261	serpentskin helm
8262	serpentskin leggings
8263	serpentskin spaulders
8264	ebonhold wristguards
8265	ebonhold armor
8266	ebonhold cloak
8267	ebonhold gauntlets
8268	ebonhold girdle
8269	ebonhold boots
8270	ebonhold helmet
8271	ebonhold leggings
8272	ebonhold shoulderpads
8273	valorous wristguards
8274	valorous chestguard
8275	ebonhold buckler
8276	valorous gauntlets
8277	valorous girdle
8278	valorous greaves
8279	valorous helm
8280	valorous legguards
8281	valorous pauldrons
8282	valorous shield
8283	arcane armor
8284	arcane boots
8285	arcane bands
8286	arcane cloak
8287	arcane gloves
8288	arcane pads
8289	arcane leggings
8290	arcane robe
8291	arcane sash
8292	arcane cover
8293	traveler s belt
8294	traveler s boots
8295	traveler s bracers
8296	traveler s jerkin
8297	traveler s cloak
8298	traveler s gloves
8299	traveler s helm
8300	traveler s leggings
8301	traveler s spaulders
8302	hero s bracers
8303	hero s breastplate
8304	hero s cape
8305	hero s gauntlets
8306	hero s belt
8307	hero s boots
8308	hero s band
8309	hero s leggings
8310	hero s pauldrons
8311	alabaster plate vambraces
8312	alabaster breastplate
8313	hero s buckler
8314	alabaster plate gauntlets
8315	alabaster plate girdle
8316	alabaster plate greaves
8317	alabaster plate helmet
8318	alabaster plate leggings
8319	alabaster plate pauldrons
8320	alabaster shield
8343	heavy silken thread
8344	silvery spinnerets
8345	wolfshead helm
8346	gauntlets of the sea
8347	dragonscale gauntlets
8348	helm of fire
8349	feathered breastplate
8350	the 1 ring
8363	shaman voodoo charm
8364	mithril head trout
8365	raw mithril head trout
8366	bloated trout
8367	dragonscale breastplate
8368	thick wolfhide
8383	plain letter
8384	pattern comfortable leather hat
8385	pattern turtle scale gloves
8386	pattern big voodoo robe
8387	pattern big voodoo mask
8388	pattern nightscape cloak
8389	pattern big voodoo pants
8390	pattern big voodoo cloak
8391	snickerfang jowl
8392	blasted boar lung
8393	scorpok pincer
8394	basilisk brain
8395	pattern tough scorpid breastplate
8396	vulture gizzard
8397	pattern tough scorpid bracers
8398	pattern tough scorpid gloves
8399	pattern tough scorpid boots
8400	pattern tough scorpid shoulders
8401	pattern tough scorpid leggings
8402	pattern tough scorpid helm
8403	pattern wild leather shoulders
8404	pattern wild leather vest
8405	pattern wild leather helmet
8406	pattern wild leather boots
8407	pattern wild leather leggings
8408	pattern wild leather cloak
8409	pattern nightscape shoulders
8410	r o i d s
8411	lung juice cocktail
8412	ground scorpok assay
8423	cerebral cortex compound
8424	gizzard gum
8425	parrot droppings
8426	large ruffled feather
8427	mutilated rat carcass
8428	laden dew gland
8429	punctured dew gland
8430	empty dew gland
8431	spool of light chartreuse silk thread
8432	eau de mixilpixil
8443	gahz ridian ornament
8444	executioner s key
8463	warchief s orders
8483	wastewander water pouch
8484	gadgetzan water co care package
8485	cat carrier bombay
8486	cat carrier cornish rex
8487	cat carrier orange tabby
8488	cat carrier silver tabby
8489	cat carrier white kitten
8490	cat carrier siamese
8491	cat carrier black tabby
8492	parrot cage green wing macaw
8493	weegli s barrel
8494	parrot cage hyacinth macaw
8495	parrot cage senegal
8496	parrot cage cockatiel
8497	rabbit crate snowshoe
8498	tiny emerald whelpling
8499	tiny crimson whelpling
8500	great horned owl
8501	hawk owl
8502	bronze lotterybox
8503	heavy bronze lotterybox
8504	iron lotterybox
8505	heavy iron lotterybox
8506	mithril lotterybox
8507	heavy mithril lotterybox
8508	large fin
8523	field testing kit
8524	model 4711 ftz power source
8525	zinge s purchase order
8526	violet tragan
8527	sealed field testing kit
8528	violet powder
8529	noggenfogger elixir
8543	underwater mushroom cap
8544	mageweave bandage
8545	heavy mageweave bandage
8546	powerful smelling salts
8548	divino matic rod
8563	red mechanostrider
8564	hippogryph egg
8583	horn of the skeletal mount
8584	untapped dowsing widget
8585	tapped dowsing widget
8586	whistle of the mottled red raptor
8587	centipaar insect parts
8588	whistle of the emerald raptor
8591	whistle of the turquoise raptor
8592	whistle of the violet raptor
8593	scrimshank s surveying gear
8594	insect analysis report
8595	blue mechanostrider
8603	thistleshrub dew
8623	oox 17 tn distress beacon
8624	red sparkler
8625	white sparkler
8626	blue sparkler
8627	reins of the night saber
8628	reins of the spotted nightsaber
8629	reins of the striped nightsaber
8630	reins of the bengal tiger
8631	reins of the striped frostsaber
8632	reins of the spotted frostsaber
8633	reins of the leopard
8643	extraordinary egg
8644	fine egg
8645	ordinary egg
8646	bad egg
8647	egg crate
8663	mithril insignia
8683	clara s fresh apple
8684	hinterlands honey ripple
8685	dran s ripple delivery
8686	mithril pendant
8687	sealed description of thredd s visitor
8703	signet of expertise
8704	oox 09 hl distress beacon
8705	oox 22 fe distress beacon
8707	gahz rilla s electrified scale
8708	hammer of expertise
8723	caliph scorpidsting s head
8724	rin ji s secret
8743	book of mark of the wild
8744	book of wrath
8746	interlaced cowl
8747	hardened leather helm
8748	double mail coif
8749	crochet hat
8750	thick leather hat
8751	overlinked coif
8752	laminated scale circlet
8753	smooth leather helmet
8754	twill cover
8755	light plate helmet
8756	book of regrowth ii
8757	book of starfire
8758	book of remove curse
8759	book of regrowth iii
8760	book of abolish poison
8761	book of starfire ii
8762	book of rejuvenation v
8763	book of moonfire v
8764	book of faerie fire ii
8765	book of regrowth iv
8766	morning glory dew
8768	book of starfire iii
8769	book of thorns iv
8770	book of moonfire vi
8771	book of rejuvenation vi
8772	book of regrowth v
8773	book of entangling roots v
8774	book of healing touch vii
8775	book of tranquility ii
8776	book of mark of the wild vi
8777	book of moonfire ix
8778	book of rejuvenation vii
8779	book of faerie fire iii
8780	book of starfire v
8781	book of regrowth vii
8782	book of thorns v
8783	book of healing touch ix
8784	book of wrath vii
8785	book of rejuvenation ix
8786	book of tranquility iii
8787	book of soothe animal
8788	book of soothe animal ii
8789	book of soothe animal iii
8790	book of faerie fire iv
8791	book of regrowth viii
8792	book of thorns vi
8793	book of wrath viii
8794	book of healing touch x
8795	book of entangling roots vi
8796	book of moonfire x
8797	book of rejuvenation x
8798	book of starfire vi
8799	book of mark of the wild vii
8800	book of regrowth ix
8801	book of tranquility iv
8802	tome of arcane intellect
8804	tome of arcane explosion
8805	tome of detect magic
8806	tome of remove lesser curse
8807	tome of amplify magic
8808	tome of mana shield
8809	tome of sleep
8810	tome of sleep ii
8811	tome of scorch
8812	tome of arcane explosion ii
8813	tome of dampen magic ii
8814	tome of fireball v
8815	tome of cone of cold
8816	tome of frostbolt v
8818	tome of mana shield ii
8819	tome of scorch ii
8820	tome of fire ward ii
8821	tome of amplify magic ii
8822	tome of arcane explosion iii
8823	tome of fire blast iv
8824	tome of fireball vi
8825	tome of frost ward iii
8826	tome of arcane missiles iv
8827	elixir of water walking
8828	tome of frostbolt vi
8829	tome of cone of cold ii
8830	tome of scorch iii
8831	purple lotus
8832	tome of blizzard iii
8833	tome of mana shield iii
8834	tome of dampen magic iii
8835	tome of fireball vii
8836	arthas tears
8837	tome of arcane explosion v
8838	sungrass
8839	blindweed
8840	renegade boots
8841	tome of fire blast v
8842	tome of frostbolt vii
8843	tome of fire ward iii
8844	tome of sleep iii
8845	ghost mushroom
8846	gromsblood
8847	tome of scorch v
8848	tome of flamestrike iv
8849	tome of arcane missiles v
8850	tome of conjure water v
8851	tome of fireball viii
8852	tome of arcane intellect iv
8853	tome of conjure food v
8854	tome of cone of cold iii
8855	tome of amplify magic iii
8856	tome of frostbolt viii
8857	tome of blizzard iv
8858	tome of mana shield iv
8859	tome of fire blast vi
8860	tome of fireball ix
8861	tome of conjure mana gem iii
8862	tome of arcane missiles vi
8863	tome of dampen magic iv
8864	tome of flamestrike v
8865	tome of ice armor iii
8866	tome of cone of cold iv
8867	tome of frostbolt ix
8868	tome of conjure water vi
8869	tome of fire ward iv
8871	tome of conjure food vi
8872	tome of blizzard v
8873	tome of mana shield v
8874	tome of scorch vi
8875	tome of frost ward iv
8876	tome of frost ward ii
8877	tome of fireball x
8878	tome of fire blast vii
8879	tome of frost nova iv
8880	tome of arcane explosion vi
8881	tome of khadgar s unlocking iv
8882	tome of amplify magic iv
8883	tome of arcane intellect v
8884	tome of frostbolt x
8885	tome of arcane missiles vii
8886	tome of flamestrike vi
8887	tome of scorch vii
8888	tome of cone of cold v
8889	tome of conjure mana gem iv
8890	tome of fireball xi
8891	tome of ice armor iv
8892	tome of conjure water vii
8893	tome of sleep iv
8894	tome of dampen magic v
8895	tome of blizzard vi
8896	tome of mana shield vi
8897	tome of fire ward v
8898	tome of arcane explosion iv
8899	tome of scorch iv
8900	book of entangling roots iv
8901	book of healing touch viii
8902	book of mark of the wild v
8903	book of moonfire vii
8904	book of moonfire viii
8905	book of regrowth vi
8906	book of rejuvenation viii
8907	book of starfire iv
8909	libram holy strike ii
8910	libram lay on hands
8911	libram fist of justice
8912	libram crusader strike
8913	libram holy strike iii
8914	libram crusader strike ii
8915	libram holy strike iv
8916	libram fist of justice ii
8917	libram lay on hands ii
8918	libram seal of protection iii
8919	libram holy strike v
8920	libram crusader strike iii
8921	libram fist of justice iii
8922	libram holy strike vi
8923	essence of agony
8924	dust of deterioration
8925	crystal vial
8926	instant poison iv
8927	instant poison v
8928	instant poison vi
8929	libram exorcism iv
8930	libram seal of righteousness iv
8931	libram crusader strike iv
8932	alterac swiss
8933	libram holy light vii
8934	libram holy strike vii
8935	libram judgement ii
8936	libram seal of wrath iii
8937	libram lay on hands iii
8938	libram turn undead iii
8939	libram exorcism v
8940	libram fist of justice iv
8941	libram holy light viii
8942	libram seal of righteousness v
8943	libram holy strike viii
8944	libram crusader strike v
8945	libram judgement iii
8947	libram exorcism vi
8948	dried king bolete
8949	elixir of agility
8950	homemade cherry pie
8951	elixir of greater defense
8952	roasted quail
8953	deep fried plantains
8954	codex of holy word fortitude
8955	codex of fade
8956	oil of immolation
8957	spinefin halibut
8958	codex of mind blast
8959	raw spinefin halibut
8960	codex of cure disease
8961	codex of psychic scream
8962	codex of mind blast ii
8963	codex of mind soothe
8964	codex of flash heal
8965	codex of fade ii
8966	codex of shackle undead
8967	codex of mind blast iii
8968	codex of mana burn
8969	codex of flash heal ii
8971	codex of psychic scream ii
8972	codex of mind blast iv
8973	thick yeti hide
8974	codex of mind control
8975	codex of fade iii
8976	codex of abolish disease
8977	codex of mana burn ii
8978	codex of flash heal iii
8980	codex of mind blast v
8981	codex of mind soothe ii
8983	codex of flash heal iv
8984	deadly poison iii
8985	deadly poison iv
8986	codex of shackle undead ii
8987	codex of holy protection ii
8988	codex of mana burn iii
8989	codex of fade iv
8990	codex of mind blast vi
8991	codex of inner fire iv
8992	codex of psychic scream iii
8993	codex of shadow protection ii
8994	codex of shadow word pain vi
8995	codex of holy word shield vii
8996	codex of resurrection iii
8997	codex of mind control ii
8998	codex of mind vision ii
8999	codex of flash heal v
9000	codex of renew vii
9001	codex of greater heal ii
9002	codex of mind blast vii
9003	codex of holy smite vii
9004	codex of holy word fortitude v
9005	codex of mana burn iv
9006	codex of holy word shield viii
9007	codex of fade v
9008	codex of prayer of healing iii
9009	codex of inner fire v
9010	codex of flash heal vi
9011	codex of shadow word pain vii
9012	codex of renew viii
9013	codex of greater heal iii
9014	codex of mind soothe iii
9015	codex of mind blast viii
9016	codex of holy smite viii
9017	codex of holy protection iii
9018	codex of holy word shield ix
9019	codex of renew ix
9020	codex of psychic scream iv
9021	codex of mana burn v
9022	codex of flash heal vii
9023	codex of shadow protection iii
9024	codex of mind control iii
9025	codex of greater heal iv
9026	codex of resurrection iv
9027	codex of mind blast ix
9028	codex of shadow word pain viii
9029	codex of fade vi
9030	restorative potion
9031	codex of shackle undead iii
9032	codex of prayer of healing iv
9033	codex of inner fire vi
9034	codex of holy word fortitude vi
9035	codex of holy word shield x
9036	magic resistance potion
9037	tablet of rockbiter weapon
9039	tablet of earth shock
9040	tablet of healing wave ii
9041	tablet of earthbind totem
9043	tablet of stoneclaw totem
9044	tablet of earth shock ii
9046	tablet of strength of earth totem
9047	tablet of flame shock
9048	tablet of rebirth
9049	tablet of fire nova totem
9050	tablet of healing wave iii
9051	tablet of earth shock iii
9052	tablet of stoneskin totem ii
9053	tablet of rockbiter weapon ii
9054	tablet of flame shock ii
9055	tablet of stoneclaw totem ii
9056	tablet of healing wave iv
9057	tablet of frostbrand weapon
9058	tablet of frost shock
9059	tablet of flametongue weapon
9060	inlaid mithril cylinder
9061	goblin rocket fuel
9062	tablet of cure disease
9063	tablet of poison cleansing totem
9064	tablet of flametongue weapon ii
9065	tablet of fire nova totem ii
9066	tablet of frost resistance totem
9067	tablet of strength of earth totem ii
9068	tablet of stoneskin totem iii
9069	tablet of earth shock iv
9070	tablet of healing wave v
9071	tablet of mana font totem
9072	tablet of flametongue totem
9073	tablet of windfury weapon
9074	tablet of flame shock iii
9075	tablet of fire resistance totem
9076	tablet of magma totem
9077	tablet of stoneclaw totem iii
9078	tablet of grounding totem
9079	tablet of lightning shock
9080	tablet of nature resistance totem
9081	tablet of healing stream totem ii
9082	tablet of rockbiter weapon iii
9083	tablet of searing totem iii
9084	tablet of windfury totem
9085	tablet of fire nova totem iii
9086	tablet of healing wave vi
9087	tablet of purge ii
9088	gift of arthas
9089	tablet of frost shock ii
9090	tablet of frostbrand weapon ii
9091	tablet of stoneskin totem iv
9093	tablet of mana font totem ii
9094	tablet of flametongue weapon iii
9095	tablet of earth shock v
9096	tablet of disease cleansing totem
9097	tablet of magma totem ii
9098	tablet of strength of earth totem iii
9099	tablet of stoneclaw totem iv
9100	tablet of lightning shield v
9101	tablet of windfury weapon ii
9102	tablet of chain lightning ii
9103	tablet of healing stream totem iii
9104	tablet of searing totem iv
9105	tablet of healing wave vii
9123	tablet of lightning bolt vi
9124	tablet of lightning shock ii
9125	tablet of grace of air totem
9126	tablet of flametongue totem ii
9127	tablet of fire resistance totem ii
9128	tablet of fire nova totem iv
9129	tablet of rockbiter weapon iv
9130	tablet of nature resistance totem ii
9131	tablet of stoneskin totem v
9132	tablet of molten blast vi
9133	tablet of chain heal ii
9134	tablet of windfury totem ii
9135	tablet of frost shock iii
9136	tablet of mana font totem iii
9137	tablet of lightning shield vi
9138	tablet of magma totem iii
9139	tablet of frostbrand weapon iii
9140	tablet of chain lightning iii
9141	tablet of stoneclaw totem v
9142	tablet of earth shock vi
9143	tablet of healing wave viii
9144	wildvine potion
9145	tablet of lightning bolt vii
9146	tablet of searing totem v
9147	tablet of healing stream totem iv
9148	tablet of flametongue weapon iv
9149	philosopher s stone
9150	tablet of strength of earth totem iv
9151	tablet of flame shock v
9152	tablet of fire nova totem v
9153	rig blueprints
9154	elixir of detect undead
9155	arcane elixir
9156	tablet of molten blast vii
9157	tablet of chain heal iii
9158	tablet of frost resistance totem iii
9159	tablet of lightning shock iii
9160	tablet of windfury weapon iii
9161	tablet of stoneskin totem vi
9162	tablet of lightning shield vii
9164	tablet of grace of air totem ii
9165	tablet of flametongue totem iii
9166	tablet of mana font totem iv
9167	tablet of chain lightning iv
9168	tablet of healing wave ix
9169	tablet of lightning bolt viii
9170	tablet of fire resistance totem iii
9171	tablet of magma totem iv
9172	invisibility potion
9173	goblin transponder
9174	tablet of frost shock iv
9175	tablet of rockbiter weapon v
9176	tablet of stoneclaw totem vi
9177	tablet of earth shock vii
9178	tablet of nature resistance totem iii
9179	elixir of greater intellect
9180	tablet of windfury totem iii
9181	tablet of healing stream totem v
9182	tablet of searing totem vi
9183	tablet of chain heal
9184	tablet of flame shock iv
9185	tablet of frost resistance totem ii
9186	mind numbing poison iii
9187	elixir of greater agility
9188	tablet of searing totem ii
9189	shay s bell
9190	grimoire of immolate
9191	grimoire of curse of weakness
9192	grimoire of corruption
9193	grimoire of life tap
9194	grimoire of curse of agony
9195	grimoire of drain soul
9197	elixir of dream vision
9198	grimoire of health funnel
9199	grimoire of curse of recklessness
9200	grimoire of curse of weakness ii
9201	grimoire of corruption ii
9202	grimoire of life tap ii
9203	grimoire of ritual of summoning
9204	grimoire of health funnel ii
9205	grimoire of curse of agony ii
9206	elixir of giants
9207	grimoire of create bloodstone ii
9208	grimoire of drain soul ii
9209	grimoire of curse of weakness iii
9210	ghost dye
9211	grimoire of curse of recklessness ii
9212	grimoire of shadow bolt v
9214	grimoire of inferno
9215	grimoire of health funnel iii
9216	grimoire of corruption iii
9217	grimoire of life tap iii
9218	grimoire of enslave demon
9219	grimoire of hellfire
9221	grimoire of curse of agony iii
9222	grimoire of curse of the elements
9223	grimoire of curse of weakness iv
9224	elixir of demonslaying
9225	grimoire of shadow bolt vi
9226	grimoire of health funnel iv
9227	grimoire of drain soul iii
9228	grimoire of create bloodstone iii
9229	grimoire of life drain iv
9230	grimoire of curse of recklessness iii
9231	grimoire of corruption iv
9233	elixir of detect demon
9234	tiara of the deep
9235	pratt s letter
9236	jangdor s letter
9237	woodpaw gnoll mane
9238	uncracked scarab shell
9240	mallet of zul farrak
9241	sacred mallet
9242	ancient tablet
9243	shriveled heart
9244	stoley s shipment
9245	stoley s bottle
9246	firebeard s head
9247	hatecrest naga scale
9248	mysterious relic
9249	captain s key
9250	ship schedule
9251	upper map fragment
9252	lower map fragment
9253	middle map fragment
9254	cuergo s treasure map
9255	lahassa essence
9256	imbel essence
9257	samha essence
9258	byltan essence
9259	troll tribal necklace
9260	volatile rum
9261	lead ore
9262	black vitriol
9263	troyas stave
9264	elixir of shadow power
9265	cuergo s hidden treasure
9266	woodpaw battle plans
9275	cuergo s key
9276	pirate s footlocker
9277	techbot s memory core
9278	essential artificial
9279	white punch card
9280	yellow punch card
9281	red punch card
9282	blue punch card
9283	empty leaden collection phial
9284	full leaden collection phial
9285	field plate vambraces
9286	field plate armor
9287	field plate gauntlets
9288	field plate girdle
9289	field plate boots
9290	field plate helmet
9291	field plate leggings
9292	field plate pauldrons
9293	recipe magic resistance potion
9294	recipe wildvine potion
9295	recipe invisibility potion
9296	recipe gift of arthas
9297	recipe elixir of dream vision
9298	recipe elixir of giants
9299	thermaplugg s safe combination
9300	recipe elixir of demonslaying
9301	recipe elixir of shadow power
9302	recipe ghost dye
9303	recipe philosopher s stone
9304	recipe transmute iron to gold
9305	recipe transmute mithril to truesilver
9306	stave of equinex
9307	a sparkling stone
9308	grime encrusted object
9309	robo mechanical guts
9311	default stationery
9312	blue firework
9313	green firework
9314	red streaks firework
9315	yellow rose firework
9316	prismatic punch card
9317	red white and blue firework
9318	red firework
9319	nimboya s laden pike
9320	witherbark skull
9321	venom bottle
9322	undamaged venom sac
9323	gadrin s parchment
9324	shadra s venom
9325	a small stave
9326	grime encrusted ring
9327	security delta data access card
9328	super snapper fx
9329	a short note
9330	snapshot of gammerita
9331	feralas a history
9332	crusted bandages
9333	tarnished silver necklace
9334	cracked pottery
9335	broken obsidian club
9336	gold capped troll tusk
9355	hoop earring
9356	a wooden leg
9357	a parrot skeleton
9358	a head rag
9359	wirt s third leg
9360	cuergo s gold
9361	cuergo s gold with worm
9362	brilliant gold ring
9363	sparklematic wrapped box
9364	heavy leaden collection phial
9365	high potency radioactive fallout
9366	golden scale gauntlets
9367	plans golden scale gauntlets
9368	jer kai s signet ring
9369	iridescent sprite darter wing
9370	gordunni scroll
9371	gordunni orb
9372	sul thraze the lasher
9375	expert goldminer s helmet
9378	shovelphlange s mining axe
9379	sang thraze the deflector
9380	jang thraze the protector
9381	earthen rod
9382	tromping miner s boots
9383	obsidian cleaver
9384	stonevault shiv
9385	archaic defender
9386	excavator s brand
9387	revelosh s boots
9388	revelosh s armguards
9389	revelosh s spaulders
9390	revelosh s gloves
9391	the shoveler
9392	annealed blade
9393	beacon of hope
9394	horned viking helmet
9396	legguards of the vault
9397	energy cloak
9398	worn running boots
9399	precision arrow
9400	baelog s shortbow
9401	nordic longshank
9402	earthborn kilt
9403	battered viking shield
9404	olaf s all purpose shield
9405	girdle of golem strength
9406	spirewind fetter
9407	stoneweaver leggings
9408	ironshod bludgeon
9409	ironaya s bracers
9410	cragfists
9411	rockshard pauldrons
9412	galgann s fireblaster
9413	the rockpounder
9414	oilskin leggings
9415	grimlok s tribal vestments
9416	grimlok s charge
9417	archaedic shard
9418	stoneslayer
9419	galgann s firehammer
9420	adventurer s pith helmet
9421	major healthstone
9422	shadowforge bushmaster
9423	the jackhammer
9424	ginn su sword
9425	pendulum of doom
9426	monolithic bow
9427	stonevault bonebreaker
9428	unearthed bands
9429	miner s hat of the deep
9430	spaulders of a lost age
9431	papal fez
9432	skullplate bracers
9433	forgotten wraps
9434	elemental raiment
9435	reticulated bone gauntlets
9436	faranell s parcel
9437	untested basilisk sample
9438	acceptable scorpid sample
9439	untested hyena sample
9440	acceptable basilisk sample
9441	acceptable hyena sample
9442	untested scorpid sample
9443	used monster sample
9444	techbot cpu shell
9445	grubbis paws
9446	electrocutioner leg
9447	electrocutioner lagnut
9448	spidertank oilrag
9449	manual crowd pummeler
9450	gnomebot operating boots
9451	bubbling water
9452	hydrocane
9453	toxic revenger
9454	acidic walkers
9455	emissary cuffs
9456	glass shooter
9457	royal diplomatic scepter
9458	thermaplugg s central core
9459	thermaplugg s left arm
9460	grimtotem horn
9461	charged gear
9462	crate of grimtotem horns
9463	gordunni cobalt
9465	digmaster 5000
9466	orwin s shovel
9467	gahz rilla fang
9468	sharpbeak s feather
9469	gahz rilla scale armor
9470	bad mojo mask
9471	nekrum s medallion
9472	hexx s key
9473	jinxed hoodoo skin
9474	jinxed hoodoo kilt
9475	diabolic skiver
9476	big bad pauldrons
9477	the chief s enforcer
9478	ripsaw
9479	embrace of the lycan
9480	eyegouger
9481	the minotaur
9482	witch doctor s cane
9483	flaming incinerator
9484	spellshock leggings
9485	vibroblade
9486	supercharger battle axe
9487	hi tech supergun
9488	oscillating power hammer
9489	gyromatic icemaker
9490	gizmotron megachopper
9491	hotshot pilot s gloves
9492	electromagnetic gigaflux reactivator
9507	a carefully packed crate
9508	mechbuilder s overalls
9509	petrolspill leggings
9510	caverndeep trudgers
9511	bloodletter scalpel
9512	blackmetal cape
9513	ley staff
9514	arcane staff
9515	nether lace tunic
9516	astral knot blouse
9517	celestial stave
9518	mud s crushers
9519	durtfeet stompers
9520	silent hunter
9521	skullsplitter
9522	energized stone circle
9523	troll temper
9527	spellshifter rod
9528	edana s dark heart
9529	internal warrior equipment kit l25
9530	horn of hatetalon
9531	gemshale pauldrons
9532	internal warrior equipment kit l30
9533	masons fraternity ring
9534	engineer s guild headpiece
9535	fire welded bracers
9536	fairywing mantle
9537	neatly wrapped box
9538	talvash s gold ring
9539	box of rations
9540	box of spells
9541	box of goodies
9542	simple letter
9543	simple rune
9544	simple memorandum
9545	simple sigil
9546	simple scroll
9547	simple note
9548	hallowed letter
9550	encrypted rune
9551	encrypted sigil
9552	rune inscribed note
9553	etched parchment
9554	encrypted tablet
9555	encrypted letter
9556	hallowed rune
9557	hallowed sigil
9558	encrypted memorandum
9559	encrypted scroll
9560	encrypted parchment
9561	hallowed tablet
9562	rune inscribed tablet
9563	consecrated rune
9564	etched tablet
9565	etched note
9566	etched rune
9567	etched sigil
9568	rune inscribed parchment
9569	hallowed scroll
9570	consecrated letter
9571	glyphic letter
9572	glyphic rune
9573	glyphic memorandum
9574	glyphic scroll
9575	glyphic tablet
9576	tainted letter
9577	tainted memorandum
9578	tainted scroll
9579	tainted parchment
9580	verdant sigil
9581	verdant note
9587	thawpelt sack
9588	nogg s gold ring
9589	encrusted minerals
9590	splintered log
9591	resilient sinew
9592	metallic fragments
9593	treant muisek
9594	wildkin muisek
9595	hippogryph muisek
9596	faerie dragon muisek
9597	mountain giant muisek
9598	sleeping robes
9599	barkmail leggings
9600	lace pants
9601	cushioned boots
9602	brushwood blade
9603	gritroot staff
9604	mechanic s pipehammer
9605	repairman s cape
9606	treant muisek vessel
9607	bastion of stormwind
9608	shoni s disarming tool
9609	shilly mitts
9618	wildkin muisek vessel
9619	hippogryph muisek vessel
9620	faerie dragon muisek vessel
9621	mountain giant muisek vessel
9622	reedknot ring
9623	civinad robes
9624	triprunner dungarees
9625	dual reinforced leggings
9626	dwarven charge
9627	explorer s league lodestar
9628	neeru s herb pouch
9629	a shrunken head
9630	pratt s handcrafted boots
9631	pratt s handcrafted gloves
9632	jangdor s handcrafted gloves
9633	jangdor s handcrafted boots
9634	skilled handling gloves
9635	master apothecary cape
9636	swashbuckler sash
9637	shinkicker boots
9638	chelonian cuffs
9639	the hand of antu sul
9640	vice grips
9641	lifeblood amulet
9642	band of the great tortoise
9643	optomatic deflector
9644	thermotastic egg timer
9645	gnomish inventor boots
9646	gnomish water sinking device
9647	failed flying experiment
9648	chainlink towel
9649	royal highmark vestments
9650	honorguard chestpiece
9651	gryphon rider s stormhammer
9652	gryphon rider s leggings
9653	speedy racer goggles
9654	cairnstone sliver
9655	seedtime hoop
9656	granite grips
9657	vinehedge cinch
9658	boots of the maharishi
9660	stargazer cloak
9661	earthclasp barrier
9662	rushridge boots
9663	dawnrider s chestpiece
9664	sentinel s guard
9665	wingcrest gloves
9666	stronghorn girdle
9678	tok kar s murloc basher
9679	tok kar s murloc chopper
9680	tok kar s murloc shanker
9681	grilled king crawler legs
9682	leather chef s belt
9683	strength of the treant
9684	force of the hippogryph
9685	will of the mountain giant
9686	spirit of the faerie dragon
9687	grappler s belt
9698	gloves of insight
9699	garrison cloak
9703	scorched cape
9704	rustler gloves
9705	tharg s shoelace
9706	tharg s disk
9718	reforged blade of heroes
9719	broken blade of heroes
9738	gem of cobrahn
9739	gem of anacondra
9740	gem of pythas
9741	gem of serpentis
9742	simple cord
9743	simple shoes
9744	simple bands
9745	simple cape
9746	simple gloves
9747	simple britches
9748	simple robe
9749	simple blouse
9750	gypsy sash
9751	gypsy sandals
9752	gypsy bands
9753	gypsy buckler
9754	gypsy cloak
9755	gypsy gloves
9756	gypsy trousers
9757	gypsy tunic
9758	cadet belt
9759	cadet boots
9760	cadet bracers
9761	cadet cloak
9762	cadet gauntlets
9763	cadet leggings
9764	cadet shield
9765	cadet vest
9766	greenweave sash
9767	greenweave sandals
9768	greenweave bracers
9769	greenweave branch
9770	greenweave cloak
9771	greenweave gloves
9772	greenweave leggings
9773	greenweave robe
9774	greenweave vest
9775	bandit cinch
9776	bandit boots
9777	bandit bracers
9778	bandit buckler
9779	bandit cloak
9780	bandit gloves
9781	bandit pants
9782	bandit jerkin
9783	raider s chestpiece
9784	raider s boots
9785	raider s bracers
9786	raider s cloak
9787	raider s gauntlets
9788	raider s belt
9789	raider s legguards
9790	raider s shield
9791	ivycloth tunic
9792	ivycloth boots
9793	ivycloth bracelets
9794	ivycloth cloak
9795	ivycloth gloves
9796	ivycloth mantle
9797	ivycloth pants
9798	ivycloth robe
9799	ivycloth sash
9800	ivy orb
9801	superior belt
9802	superior boots
9803	superior bracers
9804	superior buckler
9805	superior cloak
9806	superior gloves
9807	superior shoulders
9808	superior leggings
9809	superior tunic
9810	fortified boots
9811	fortified bracers
9812	fortified cloak
9813	fortified gauntlets
9814	fortified belt
9815	fortified leggings
9816	fortified shield
9817	fortified spaulders
9818	fortified chain
9819	durable tunic
9820	durable boots
9821	durable bracers
9822	durable cape
9823	durable gloves
9824	durable shoulders
9825	durable pants
9826	durable robe
9827	scaled leather belt
9828	scaled leather boots
9829	scaled leather bracers
9830	scaled shield
9831	scaled cloak
9832	scaled leather gloves
9833	scaled leather leggings
9834	scaled leather shoulders
9835	scaled leather tunic
9836	banded armor
9837	banded bracers
9838	banded cloak
9839	banded gauntlets
9840	banded girdle
9841	banded leggings
9842	banded pauldrons
9843	banded shield
9844	conjurer s vest
9845	conjurer s shoes
9846	conjurer s bracers
9847	conjurer s cloak
9848	conjurer s gloves
9849	conjurer s hood
9850	conjurer s mantle
9851	conjurer s breeches
9852	conjurer s robe
9853	conjurer s cinch
9854	archer s jerkin
9855	archer s belt
9856	archer s boots
9857	archer s bracers
9858	archer s buckler
9859	archer s cap
9860	archer s cloak
9861	archer s gloves
9862	archer s trousers
9863	archer s shoulderpads
9864	renegade boots
9865	renegade bracers
9866	renegade chestguard
9867	renegade cloak
9868	renegade gauntlets
9869	renegade belt
9870	renegade circlet
9871	renegade leggings
9872	renegade pauldrons
9873	renegade shield
9874	sorcerer drape
9875	sorcerer sash
9876	sorcerer slippers
9877	sorcerer cloak
9878	sorcerer hat
9879	sorcerer bracelets
9880	sorcerer gloves
9881	sorcerer mantle
9882	sorcerer sphere
9883	sorcerer pants
9884	sorcerer robe
9885	huntsman s boots
9886	huntsman s bands
9887	huntsman s armor
9888	elven protector
9889	huntsman s cap
9890	huntsman s cape
9891	huntsman s belt
9892	huntsman s gloves
9893	huntsman s leggings
9894	huntsman s shoulders
9895	jazeraint boots
9896	jazeraint bracers
9897	jazeraint chestguard
9898	jazeraint cloak
9899	jazeraint shield
9900	jazeraint gauntlets
9901	jazeraint belt
9902	jazeraint helm
9903	jazeraint leggings
9904	jazeraint pauldrons
9905	royal blouse
9906	royal sash
9907	royal boots
9908	royal cape
9909	royal bands
9910	royal gloves
9911	royal trousers
9912	royal amice
9913	royal gown
9914	royal scepter
9915	royal headband
9916	tracker s belt
9917	tracker s boots
9918	brigade defender
9919	tracker s cloak
9920	tracker s gloves
9921	tracker s headband
9922	tracker s leggings
9923	tracker s shoulderpads
9924	tracker s tunic
9925	tracker s wristguards
9926	brigade boots
9927	brigade bracers
9928	brigade breastplate
9929	brigade cloak
9930	brigade gauntlets
9931	brigade girdle
9932	brigade circlet
9933	brigade leggings
9934	brigade pauldrons
9935	embossed plate shield
9936	abjurer s boots
9937	abjurer s bands
9938	abjurer s cloak
9939	abjurer s gloves
9940	abjurer s hood
9941	abjurer s mantle
9942	abjurer s pants
9943	abjurer s robe
9944	abjurer s crystal
9945	abjurer s sash
9946	abjurer s tunic
9947	chieftain s belt
9948	chieftain s boots
9949	chieftain s bracers
9950	chieftain s breastplate
9951	chieftain s cloak
9952	chieftain s gloves
9953	chieftain s headdress
9954	chieftain s leggings
9955	chieftain s shoulders
9956	warmonger s bracers
9957	warmonger s chestpiece
9958	warmonger s buckler
9959	warmonger s cloak
9960	warmonger s gauntlets
9961	warmonger s belt
9962	warmonger s greaves
9963	warmonger s circlet
9964	warmonger s leggings
9965	warmonger s pauldrons
9966	embossed plate armor
9967	embossed plate gauntlets
9968	embossed plate girdle
9969	embossed plate helmet
9970	embossed plate leggings
9971	embossed plate pauldrons
9972	embossed plate bracers
9973	embossed plate boots
9974	overlord s shield
9978	gahz ridian detector
9998	black mageweave vest
9999	black mageweave leggings
10000	margol s horn
10001	black mageweave robe
10002	shadoweave pants
10003	black mageweave gloves
10004	shadoweave robe
10005	margol s gigantic horn
10007	red mageweave vest
10008	white bandit mask
10009	red mageweave pants
10010	stormcloth pants
10011	stormcloth gloves
10018	red mageweave gloves
10019	dreamweave gloves
10020	stormcloth vest
10021	dreamweave vest
10022	proof of deed
10023	shadoweave gloves
10024	black mageweave headband
10025	shadoweave mask
10026	black mageweave boots
10027	black mageweave shoulders
10028	shadoweave shoulders
10029	red mageweave shoulders
10030	admiral s hat
10031	shadoweave boots
10032	stormcloth headband
10033	red mageweave headband
10034	tuxedo shirt
10035	tuxedo pants
10036	tuxedo jacket
10038	stormcloth shoulders
10039	stormcloth boots
10040	white wedding dress
10041	dreamweave circlet
10042	cindercloth robe
10043	pious legwraps
10044	cindercloth boots
10045	simple linen pants
10046	simple linen boots
10047	simple kilt
10048	colorful kilt
10049	diabolist s blade
10050	mageweave bag
10051	red mageweave bag
10052	orange martial shirt
10053	simple black dress
10054	lavender mageweave shirt
10055	pink mageweave shirt
10056	orange mageweave shirt
10057	duskwoven tunic
10058	duskwoven sandals
10059	duskwoven bracers
10060	duskwoven cape
10061	duskwoven turban
10062	duskwoven gloves
10063	duskwoven amice
10064	duskwoven pants
10065	duskwoven robe
10066	duskwoven sash
10067	righteous waistguard
10068	righteous boots
10069	righteous bracers
10070	righteous armor
10071	righteous cloak
10072	righteous gloves
10073	righteous helmet
10074	righteous leggings
10075	righteous spaulders
10076	lord s armguards
10077	lord s breastplate
10078	lord s crest
10079	lord s cape
10080	lord s gauntlets
10081	lord s girdle
10082	lord s boots
10083	lord s crown
10084	lord s legguards
10085	lord s pauldrons
10086	gothic plate armor
10087	gothic plate gauntlets
10088	gothic plate girdle
10089	gothic sabatons
10090	gothic plate helmet
10091	gothic plate leggings
10092	gothic plate spaulders
10093	revenant deflector
10094	gothic plate vambraces
10095	councillor s boots
10096	councillor s cuffs
10097	councillor s circlet
10098	councillor s cloak
10099	councillor s gloves
10100	councillor s shoulders
10101	councillor s pants
10102	councillor s robes
10103	councillor s sash
10104	councillor s tunic
10105	wanderer s armor
10106	wanderer s boots
10107	wanderer s bracers
10108	wanderer s cloak
10109	wanderer s belt
10110	wanderer s gloves
10111	wanderer s hat
10112	wanderer s leggings
10113	wanderer s shoulders
10118	ornate breastplate
10119	ornate greaves
10120	ornate cloak
10121	ornate gauntlets
10122	ornate girdle
10123	ornate circlet
10124	ornate legguards
10125	ornate pauldrons
10126	ornate bracers
10127	revenant bracers
10128	revenant chestplate
10129	revenant gauntlets
10130	revenant girdle
10131	revenant boots
10132	revenant helmet
10133	revenant leggings
10134	revenant shoulders
10135	high councillor s tunic
10136	high councillor s bracers
10137	high councillor s boots
10138	high councillor s cloak
10139	high councillor s circlet
10140	high councillor s gloves
10141	high councillor s pants
10142	high councillor s mantle
10143	high councillor s robe
10144	high councillor s sash
10145	mighty girdle
10146	mighty boots
10147	mighty armsplints
10148	mighty cloak
10149	mighty gauntlets
10150	mighty helmet
10151	mighty tunic
10152	mighty leggings
10153	mighty spaulders
10154	mercurial girdle
10155	mercurial greaves
10156	mercurial bracers
10157	mercurial breastplate
10158	mercurial guard
10159	mercurial cloak
10160	mercurial circlet
10161	mercurial gauntlets
10162	mercurial legguards
10163	mercurial pauldrons
10164	templar chestplate
10165	templar gauntlets
10166	templar girdle
10167	templar boots
10168	templar crown
10169	templar legplates
10170	templar pauldrons
10171	templar bracers
10172	mystical mantle
10173	mystical bracers
10174	mystical cape
10175	mystical headwrap
10176	mystical gloves
10177	mystical leggings
10178	mystical robe
10179	mystical boots
10180	mystical belt
10181	mystical armor
10182	swashbuckler s breastplate
10183	swashbuckler s boots
10184	swashbuckler s bracers
10185	swashbuckler s cape
10186	swashbuckler s gloves
10187	swashbuckler s eyepatch
10188	swashbuckler s leggings
10189	swashbuckler s shoulderpads
10190	swashbuckler s belt
10191	crusader s armguards
10192	crusader s boots
10193	crusader s armor
10194	crusader s cloak
10195	crusader s shield
10196	crusader s gauntlets
10197	crusader s belt
10198	crusader s helm
10199	crusader s leggings
10200	crusader s pauldrons
10201	overlord s greaves
10202	overlord s vambraces
10203	overlord s chestplate
10204	heavy lamellar shield
10205	overlord s gauntlets
10206	overlord s girdle
10207	overlord s crown
10208	overlord s legplates
10209	overlord s spaulders
10210	elegant mantle
10211	elegant boots
10212	elegant cloak
10213	elegant bracers
10214	elegant gloves
10215	elegant robes
10216	elegant belt
10217	elegant leggings
10218	elegant tunic
10219	elegant circlet
10220	nightshade tunic
10221	nightshade girdle
10222	nightshade boots
10223	nightshade armguards
10224	nightshade cloak
10225	nightshade gloves
10226	nightshade helmet
10227	nightshade leggings
10228	nightshade spaulders
10229	engraved bracers
10230	engraved breastplate
10231	engraved cape
10232	engraved gauntlets
10233	engraved girdle
10234	engraved boots
10235	engraved helm
10236	engraved leggings
10237	engraved pauldrons
10238	heavy lamellar boots
10239	heavy lamellar vambraces
10240	heavy lamellar chestpiece
10241	heavy lamellar helm
10242	heavy lamellar gauntlets
10243	heavy lamellar girdle
10244	heavy lamellar leggings
10245	heavy lamellar pauldrons
10246	master s vest
10247	master s boots
10248	master s bracers
10249	master s cloak
10250	master s hat
10251	master s gloves
10252	master s leggings
10253	master s mantle
10254	master s robe
10255	master s belt
10256	adventurer s bracers
10257	adventurer s boots
10258	adventurer s cape
10259	adventurer s belt
10260	adventurer s gloves
10261	adventurer s bandana
10262	adventurer s legguards
10263	adventurer s shoulders
10264	adventurer s tunic
10265	masterwork bracers
10266	masterwork breastplate
10267	masterwork cape
10268	masterwork gauntlets
10269	masterwork girdle
10270	masterwork boots
10271	masterwork shield
10272	masterwork circlet
10273	masterwork legplates
10274	masterwork pauldrons
10275	emerald breastplate
10276	emerald sabatons
10277	emerald gauntlets
10278	emerald girdle
10279	emerald helm
10280	emerald legplates
10281	emerald pauldrons
10282	emerald vambraces
10283	wolf heart samples
10285	shadow silk
10286	heart of the wild
10287	greenweave mantle
10288	sage s circlet
10289	durable hat
10290	pink dye
10298	gnomeregan band
10299	gnomeregan amulet
10300	pattern red mageweave vest
10301	pattern white bandit mask
10302	pattern red mageweave pants
10303	pattern stormcloth pants
10304	pattern stormcloth gloves
10305	scroll of protection iv
10306	scroll of spirit iv
10307	scroll of stamina iv
10308	scroll of intellect iv
10309	scroll of agility iv
10310	scroll of strength iv
10311	pattern orange martial shirt
10312	pattern red mageweave gloves
10313	pattern stormcloth vest
10314	pattern lavender mageweave shirt
10315	pattern red mageweave shoulders
10316	pattern colorful kilt
10317	pattern pink mageweave shirt
10318	pattern admiral s hat
10319	pattern stormcloth headband
10320	pattern red mageweave headband
10321	pattern tuxedo shirt
10322	pattern stormcloth shoulders
10323	pattern tuxedo pants
10324	pattern stormcloth boots
10325	pattern white wedding dress
10326	pattern tuxedo jacket
10327	horn of echeyakee
10328	scarlet chestpiece
10329	scarlet belt
10330	scarlet leggings
10331	scarlet gauntlets
10332	scarlet boots
10333	scarlet wristguards
10338	fresh zhevra carcass
10358	duracin bracers
10359	everlast boots
10360	black kingsnake
10361	brown snake
10362	ornate shield
10363	engraved wall
10364	templar shield
10365	emerald shield
10366	demon guard
10367	hyperion shield
10368	imbued plate armor
10369	imbued plate gauntlets
10370	imbued plate girdle
10371	imbued plate greaves
10372	imbued plate helmet
10373	imbued plate leggings
10374	imbued plate pauldrons
10375	imbued plate vambraces
10376	commander s boots
10377	commander s vambraces
10378	commander s armor
10379	commander s helm
10380	commander s gauntlets
10381	commander s girdle
10382	commander s leggings
10383	commander s pauldrons
10384	hyperion armor
10385	hyperion greaves
10386	hyperion gauntlets
10387	hyperion girdle
10388	hyperion helm
10389	hyperion legplates
10390	hyperion pauldrons
10391	hyperion vambraces
10392	crimson snake
10393	cockroach
10394	prairie dog whistle
10398	mechanical chicken
10399	blackened defias armor
10400	blackened defias leggings
10401	blackened defias gloves
10402	blackened defias boots
10403	blackened defias belt
10404	durable belt
10405	bandit shoulders
10406	scaled leather headband
10407	raider s shoulderpads
10408	banded helm
10409	banded boots
10410	leggings of the fang
10411	footpads of the fang
10412	belt of the fang
10413	gloves of the fang
10414	sample snapjaw shell
10418	glimmering mithril insignia
10420	skull of the coldbringer
10421	rough copper vest
10423	silvered bronze leggings
10424	plans silvered bronze leggings
10438	felix s box
10439	durnan s scalding mornbrew
10440	nori s mug
10441	glowing shard
10442	mysterious artifact
10443	singed letter
10444	standard issue flare gun
10445	drawing kit
10446	heart of obsidion
10447	head of lathoric the black
10450	undamaged hippogryph feather
10454	essence of eranikus
10455	chained essence of eranikus
10456	a bulging coin purse
10457	empty sea snail shell
10458	prayer to elune
10459	chief sharptusk thornmantle s head
10460	hakkari blood
10461	shadowy bracers
10462	shadowy belt
10463	pattern shadoweave mask
10464	staff of command
10465	egg of hakkar
10466	atal ai stone circle
10467	trader s satchel
10478	roland s mana gem
10479	kovic s trading satchel
10498	gyromatic micro adjustor
10499	bright eye goggles
10500	fire goggles
10501	catseye ultra goggles
10502	spellpower goggles xtreme
10503	rose colored goggles
10504	green lens
10505	solid blasting powder
10506	deepdive helmet
10507	solid dynamite
10508	mithril blunderbuss
10509	heart of flame
10510	mithril heavy bore rifle
10511	golem oil
10512	hi impact mithril slugs
10513	mithril gyro shot
10514	mithril frag bomb
10515	torch of retribution
10518	parachute cloak
10538	tablet of beth amara
10539	tablet of jin yael
10540	tablet of markri
10541	tablet of sael hai
10542	goblin mining helmet
10543	goblin construction helmet
10544	thistlewood maul
10545	gnomish goggles
10546	deadly scope
10547	camping knife
10548	sniper scope
10549	rancher s trousers
10550	wooly mittens
10551	thorium plated dagger
10552	symbol of ragnaros
10553	foreman vest
10554	foreman pants
10556	stone circle
10558	gold power core
10559	mithril tube
10560	unstable trigger
10561	mithril casing
10562	hi explosive bomb
10563	rubbing rune of beth amara
10564	rubbing rune of jin yael
10565	rubbing rune of markri
10566	rubbing rune of sael hai
10567	quillshooter
10569	hoard of the black dragonflight
10570	manslayer
10571	ebony boneclub
10572	freezing shard
10573	boneslasher
10574	corpseshroud
10575	black dragonflight molt
10576	mithril mechanical dragonling
10577	goblin mortar
10578	thoughtcast boots
10579	explosive arrow
10580	goblin boom box
10581	death s head vestment
10582	briar tredders
10583	quillward harness
10584	stormgale fists
10585	goblin radio
10586	the big one
10587	goblin bomb dispenser
10588	goblin rocket helmet
10589	oathstone of ysera s dragonflight
10590	pocked black box
10592	catseye elixir
10593	imperfect draenethyst fragment
10595	kum sha s junk
10597	head of magus rimtori
10598	hetaera s bloodied head
10599	hetaera s beaten head
10600	hetaera s bruised head
10601	schematic bright eye goggles
10602	schematic deadly scope
10603	schematic catseye ultra goggles
10604	schematic mithril heavy bore rifle
10605	schematic spellpower goggles xtreme
10606	schematic parachute cloak
10607	schematic deepdive helmet
10608	schematic sniper scope
10609	schematic mithril mechanical dragonling
10610	hetaera s blood
10620	thorium ore
10621	runed scroll
10622	kadrak s flag
10623	winter s bite
10624	stinging bow
10625	stealthblade
10626	ragehammer
10627	bludgeon of the grinning dog
10628	deathblow
10629	mistwalker boots
10630	soulcatcher halo
10631	murkwater gauntlets
10632	slimescale bracers
10633	silvershell leggings
10634	mindseye circle
10635	painted chain leggings
10636	nomadic gloves
10637	brewer s gloves
10638	long draping cape
10639	hyacinth mushroom
10640	webwood ichor
10641	moonpetal lily
10642	iverron s antidote
10643	sealed letter to ag tor
10644	recipe goblin rocket fuel
10645	gnomish death ray
10646	goblin sapper charge
10647	engineer s ink
10648	blank parchment
10649	nightmare shard
10650	plague infested quilboar mane
10651	cracked arcane focusing crystal
10652	will of the mountain giant
10653	trailblazer boots
10654	jutebraid gloves
10655	sedgeweed britches
10656	barkmail vest
10657	talbar mantle
10658	quagmire galoshes
10659	shard of afrasa
10660	first mosh aru tablet
10661	second mosh aru tablet
10662	filled egg of hakkar
10663	essence of hakkar
10664	a note to magus rimtori
10678	magatha s note
10679	andron s note
10680	jes rimon s note
10681	xylem s note
10682	belnistrasz s oathstone
10683	explorer s knapsack
10684	colossal parachute
10686	aegis of battle
10687	empty vial labeled #1
10688	empty vial labeled #2
10689	empty vial labeled #3
10690	empty vial labeled #4
10691	filled vial labeled #1
10692	filled vial labeled #2
10693	filled vial labeled #3
10694	filled vial labeled #4
10695	box of empty vials
10696	enchanted azsharite felbane sword
10697	enchanted azsharite felbane dagger
10698	enchanted azsharite felbane staff
10699	yeh kinya s bramble
10700	encarmine boots
10701	boots of zua tec
10702	enormous ogre boots
10703	fiendish skiv
10704	chillnail splinter
10705	firwillow wristbands
10706	nightscale girdle
10707	steelsmith greaves
10708	skullspell orb
10709	pyrestone orb
10710	dragonclaw ring
10711	dragon s blood necklace
10712	cuely s elixir
10713	plans inlaid mithril cylinder
10714	crystallized azsharite
10715	kim jael s scope
10716	gnomish shrink ray
10717	kim jael s compass
10718	kim jael s wizzlegoober
10719	mobile alarm
10720	gnomish net o matic projector
10721	gnomish harm prevention belt
10722	kim jael s stuffed chicken
10723	gnomish ham radio
10724	gnomish rocket boots
10725	gnomish battle chicken
10726	gnomish mind control cap
10727	goblin dragon gun
10728	pattern black swashbuckler s shirt
10738	shipment to galvan
10739	ring of fortitude
10740	centurion legplates
10741	lordrec helmet
10742	dragonflight leggings
10743	drakefire headguard
10744	axe of the ebon drake
10745	kaylari shoulders
10746	runesteel vambraces
10747	teacher s sash
10748	wanderlust boots
10749	avenguard helm
10750	lifeforce dirk
10751	gemburst circlet
10752	emerald encrusted chest
10753	amulet of grol
10754	amulet of sevine
10755	amulet of allistarj
10757	ward of the defiler
10758	x caliboar
10759	severed horn of the defiler
10760	swine fists
10761	coldrage dagger
10762	robes of the lich
10763	icemetal barbute
10764	deathchill armor
10765	bonefingers
10766	plaguerot sprig
10767	savage boar s guard
10768	boar champion s belt
10769	glowing eye of mordresh
10770	mordresh s lifeless skull
10771	deathmage sash
10772	glutton s cleaver
10773	hakkari urn
10774	fleshhide shoulders
10775	carapace of tuten kash
10776	silky spider cape
10777	arachnid gloves
10778	necklace of sanctuary
10779	demon s blood
10780	mark of hakkar
10781	hakkari breastplate
10782	hakkari shroud
10783	atal ai spaulders
10784	atal ai breastplate
10785	atal ai leggings
10786	atal ai boots
10787	atal ai gloves
10788	atal ai girdle
10789	manual of engineering disciplines
10790	gnome engineer membership card
10791	goblin engineer membership card
10792	nixx s pledge of secrecy
10793	overspark s pledge of secrecy
10794	oglethorpe s pledge of secrecy
10795	drakeclaw band
10796	drakestone
10797	firebreather
10798	atal alarion s tusk ring
10799	headspike
10800	darkwater bracers
10801	slitherscale boots
10802	wingveil cloak
10803	blade of the wretched
10804	fist of the damned
10805	eater of the dead
10806	vestments of the atal ai prophet
10807	kilt of the atal ai prophet
10808	gloves of the atal ai prophet
10818	yeh kinya s scroll
10819	wildkin feather
10820	jackseed belt
10821	sower s cloak
10822	dark whelpling
10823	vanquisher s sword
10824	amberglow talisman
10826	staff of lore
10827	surveyor s tunic
10828	dire nail
10829	dragon s eye
10830	m73 frag grenade
10831	fel orb
10832	fel tracker owner s manual
10833	horns of eranikus
10834	felhound tracker kit
10835	crest of supremacy
10836	rod of corrosion
10837	tooth of eranikus
10838	might of hakkar
10839	crystallized note
10840	crystallized note
10841	goldthorn tea
10842	windscale sarong
10843	featherskin cape
10844	spire of hakkar
10845	warrior s embrace
10846	bloodshot greaves
10847	dragon s call
10858	plans solid iron maul
10918	wound poison
10919	apothecary gloves
10920	wound poison ii
10921	wound poison iii
10922	wound poison iv
10938	lesser magic essence
10939	greater magic essence
10940	strange dust
10958	hilary s necklace
10959	demon hide sack
10978	small glimmering shard
10998	lesser astral essence
10999	ironfel
11000	shadowforge key
11018	un goro soil
11020	evergreen pouch
11022	packet of tharlendris seeds
11023	ancona chicken
11024	evergreen herb casing
11026	tree frog box
11027	wood frog box
11038	formula enchant 2h weapon lesser spirit
11039	formula enchant cloak minor agility
11040	morrowgrain
11058	sha ni s nose ring
11078	relic coffer key
11079	gor tesh s lopped off head
11080	gor tesh s lopped off head
11081	formula enchant shield lesser protection
11082	greater astral essence
11083	soul dust
11084	large glimmering shard
11085	customer of the month coffer key
11086	jang thraze the protector
11098	formula enchant cloak lesser shadow resistance
11101	formula enchant bracer lesser strength
11102	unhatched sprite darter egg
11103	seed voucher
11104	large compass
11105	curled map parchment
11106	lion headed key
11107	a small pack
11108	faded photograph
11109	special chicken feed
11110	chicken egg
11111	broken sprite darter egg
11112	research equipment
11113	crate of foodstuffs
11114	dinosaur bone
11115	secret safe key
11116	a mangled journal
11118	archaedic stone
11119	milly s harvest
11120	belgrom s hammer
11121	darkwater talwar
11122	carrot on a stick
11123	rainstrider leggings
11124	helm of exile
11125	grape manifest
11126	tablet of kurniya
11127	scavenged goods
11128	golden rod
11129	essence of the elements
11130	runed golden rod
11131	hive wall sample
11133	linken s training sword
11134	lesser mystic essence
11135	greater mystic essence
11136	linken s tempered sword
11137	vision dust
11138	small glowing shard
11139	large glowing shard
11140	prison cell key
11141	bait
11142	broken samophlange
11143	nugget slug
11144	truesilver rod
11145	runed truesilver rod
11146	broken and battered samophlange
11147	samophlange manual cover
11148	samophlange manual page
11149	samophlange manual
11150	formula enchant gloves mining
11151	formula enchant gloves herbalism
11152	formula enchant gloves fishing
11162	linken s superior sword
11163	formula enchant bracer lesser deflection
11164	formula enchant weapon lesser beastslayer
11165	formula enchant weapon lesser elemental slayer
11166	formula enchant gloves skinning
11167	formula enchant boots lesser spirit
11168	formula enchant shield lesser block
11169	book of aquor
11171	fel iron
11172	silvery claws
11173	irontree heart
11174	lesser nether essence
11175	greater nether essence
11176	dream dust
11177	small radiant shard
11178	large radiant shard
11179	golden flame
11184	blue power crystal
11185	green power crystal
11186	red power crystal
11187	stemleaf bracers
11188	yellow power crystal
11189	woodland robes
11190	viny gloves
11191	farmer s boots
11192	outfitter gloves
11193	blazewind breastplate
11194	prismscale hauberk
11195	warforged chestplate
11196	mindburst medallion
11197	dark keeper key
11198	rune of escape
11199	engineer s shield 1
11200	engineer s shield 2
11201	engineer s shield 3
11202	formula enchant shield stamina
11203	formula enchant gloves advanced mining
11204	formula enchant bracer greater spirit
11205	formula enchant gloves advanced herbalism
11206	formula enchant cloak lesser agility
11207	formula enchant weapon fiery weapon
11208	formula enchant weapon demonslaying
11222	head of krom zar
11223	formula enchant bracer deflection
11224	formula enchant shield frost resistance
11225	formula enchant bracer greater stamina
11226	formula enchant gloves riding skill
11227	piece of krom zar s banner
11228	frenzied dragonflight molt
11229	brightscale girdle
11230	encased fiery essence
11231	altered black dragonflight molt
11242	evoroot
11243	videre elixir
11262	orb of lorica
11263	nether force wand
11265	cragwood maul
11266	fractured elemental shard
11267	elemental shard sample
11268	head of argelmach
11269	intact elemental core
11270	nixx s signed pledge
11282	oglethorpe s signed pledge
11283	overspark s signed pledge
11284	accurate slugs
11285	jagged arrow
11286	thorium shackles
11287	lesser magic wand
11288	greater magic wand
11289	lesser mystic wand
11290	greater mystic wand
11291	star wood
11302	uther s strength
11303	fine shortbow
11304	fine longbow
11305	dense shortbow
11306	sturdy recurve
11307	massive longbow
11308	sylvan shortbow
11309	the heart of the mountain
11310	flameseer mantle
11311	emberscale cape
11312	lost thunderbrew recipe
11313	ribbly s head
11315	bloodpetal sprout
11316	bloodpetal
11318	atal ai haze
11319	unloaded zapper
11320	bloodpetal zapper
11324	explorer s knapsack
11325	dark iron ale mug
11362	medium quiver
11363	medium shot pouch
11364	tabard of stormwind
11366	helendis riverhorn s letter
11367	solomon s plea to bolvar
11368	bolvar s decree
11370	dark iron ore
11371	dark iron bar
11382	blood of the mountain
11384	broken basilisk teeth
11385	basilisk scale
11386	squishy basilisk eye
11387	basilisk heart
11388	basilisk venom
11389	shimmering basilisk skin
11390	broken bat fang
11391	spined bat wing
11392	severed bat claw
11393	small bat skull
11394	bat heart
11395	bat ear
11402	sleek bat pelt
11403	large bat fang
11404	evil bat eye
11405	giant silver vein
11406	rotting bear carcass
11407	torn bear pelt
11408	bear jaw
11409	bear organ
11410	savage bear claw
11411	large bear bone
11412	nagmara s vial
11413	nagmara s filled vial
11414	grizzled mane
11415	mixed berries
11416	delicate ribcage
11417	feathery wing
11418	hollow wing bone
11419	mysterious unhatched egg
11420	elegant writing tool
11422	goblin engineer s renewal gift
11423	gnome engineer s renewal gift
11444	grim guzzler boar
11445	flute of the ancients
11446	a crumpled up note
11462	discarded knife
11463	undelivered parcel
11464	marshal windsor s lost information
11465	marshal windsor s lost information
11466	raschal s report
11467	blackrock medallion
11468	dark iron fanny pack
11469	bloodband bracers
11470	tablet transcript
11471	fragile sprite darter egg
11472	silvermane stalker flank
11473	px83 enigmatron
11474	sprite darter egg
11475	wine stained cloak
11476	u cha s pelt
11477	white ravasaur claw
11478	un goro gorilla pelt
11479	un goro stomper pelt
11480	un goro thunderer pelt
11482	crystal pylon user s manual
11502	loreskin shoulders
11503	blood amber
11504	piece of threshadon carcass
11507	spotted hyena pelt
11508	gamemaster s slippers
11509	ravasaur pheromone gland
11510	lar korwi s head
11511	cenarion beacon
11512	patch of tainted skin
11513	tainted vitriol
11514	fel creep
11515	corrupted soul shard
11516	cenarion plant salve
11522	silver totem of aquementas
11562	crystal restore
11563	crystal force
11564	crystal ward
11565	crystal yield
11566	crystal charge
11567	crystal spire
11568	torwa s pouch
11569	preserved threshadon meat
11570	preserved pheromone mixture
11582	fel salve
11583	cactus apple
11584	cactus apple surprise
11590	mechanical repair kit
11602	grim guzzler key
11603	vilerend slicer
11604	dark iron plate
11605	dark iron shoulders
11606	dark iron mail
11607	dark iron sunderer
11608	dark iron pulverizer
11609	altered black dragonflight molt
11610	plans dark iron pulverizer
11611	plans dark iron sunderer
11612	plans dark iron plate
11613	debug samophlange manual cover
11614	plans dark iron mail
11615	plans dark iron shoulders
11616	debug samophlange manual page
11617	eridan s supplies
11622	lesser arcanum of rumination
11623	spritecaster cape
11624	kentic amice
11625	enthralled sphere
11626	blackveil cape
11627	fleetfoot greaves
11628	houndmaster s bow
11629	houndmaster s rifle
11630	rockshard pellets
11631	stoneshell guard
11632	earthslag shoulders
11633	spiderfang carapace
11634	silkweb gloves
11635	hookfang shanker
11642	lesser arcanum of constitution
11643	lesser arcanum of tenacity
11644	lesser arcanum of resilience
11645	lesser arcanum of voracity
11646	lesser arcanum of voracity
11647	lesser arcanum of voracity
11648	lesser arcanum of voracity
11649	lesser arcanum of voracity
11662	ban thok sash
11665	ogreseer fists
11668	flute of xavaric
11669	naglering
11674	jadefire felbind
11675	shadefiend boots
11677	graverot cape
11678	carapace of anub shiah
11679	rubicund armguards
11682	eridan s vial
11684	ironfoe
11685	splinthide shoulders
11686	girdle of beastial fury
11702	grizzle s skinner
11703	stonewall girdle
11722	dregmetal spaulders
11723	goodsteel s balanced flameberge
11724	overdue package
11725	solid crystal leg shaft
11726	savage gladiator chain
11727	goodsteel ledger
11728	savage gladiator leggings
11729	savage gladiator helm
11730	savage gladiator grips
11731	savage gladiator greaves
11732	libram of rumination
11733	libram of constitution
11734	libram of tenacity
11735	ragefury eyepatch
11736	libram of resilience
11737	libram of voracity
11742	wayfarer s knapsack
11743	rockfist
11744	bloodfist
11745	fists of phalanx
11746	golem skull helm
11747	flamestrider robes
11748	pyric caduceus
11749	searingscale leggings
11750	kindling stave
11751	burning essence
11752	black blood of the tormented
11753	eye of kajal
11754	black diamond
11755	verek s collar
11764	cinderhide armsplints
11765	pyremail wristguards
11766	flameweave cuffs
11767	emberplate armguards
11768	incendic bracers
11782	boreal mantle
11783	chillsteel girdle
11784	arbiter s blade
11785	rock golem bulwark
11786	stone of the earth
11787	shalehusk boots
11802	lavacrest leggings
11803	force of magma
11804	spraggle s canteen
11805	rubidium hammer
11807	sash of the burning heart
11808	circle of flame
11809	flame wrath
11810	force of will
11811	smoking heart of the mountain
11812	cape of the fire salamander
11813	formula smoking heart of the mountain
11814	molten fists
11815	hand of justice
11816	angerforge s battle axe
11817	lord general s sword
11818	grimesilt outhouse key
11819	second wind
11820	royal decorated armor
11821	warstrife leggings
11822	omnicast boots
11823	luminary kilt
11824	cyclopean band
11825	pet bombling
11826	lil smoky
11827	schematic lil smoky
11828	schematic pet bombling
11829	un goro ash
11830	webbed diemetradon scale
11831	webbed pterrordax scale
11832	burst of knowledge
11833	gorishi queen lure
11834	super sticky tar
11835	gorishi queen brain
11837	gorishi scent gland
11839	chief architect s monocle
11840	master builder s shirt
11841	senior designer s pantaloons
11842	lead surveyor s mantle
11843	bank voucher
11844	pestlezugg s un goro report
11845	handmade leather bag
11846	wizbang s special brew
11847	battered cloak
11848	flax belt
11849	rustmetal bracers
11850	short duskbat cape
11851	scavenger tunic
11852	roamer s leggings
11853	rambling boots
11854	samophlange screwdriver
11855	tork wrench
11856	ceremonial elven blade
11857	sanctimonial rod
11858	battlehard cape
11859	jademoon orb
11860	charged lightning rod
11861	girdle of reprisal
11862	white bone band
11863	white bone shredder
11864	white bone spear
11865	rancor boots
11866	nagmara s whipping belt
11867	maddening gauntlets
11868	choking band
11869	sha ni s ring
11870	oblivion orb
11871	snarkshaw spaulders
11872	eschewal greaves
11873	ethereal mist cape
11874	clouddrift mantle
11875	breezecloud bracers
11876	plainstalker tunic
11882	outrider leggings
11883	a dingy fanny pack
11884	moonlit amice
11885	shadowforge torch
11886	urgent message
11887	cenarion circle cache
11888	quintis research gloves
11889	bark iron pauldrons
11902	linken s sword of mastery
11903	cat carrier corrupted kitten
11904	spirit of aquementas
11905	linken s boomerang
11906	beastsmasher
11907	beastslayer
11908	archaeologist s quarry boots
11909	excavator s utility belt
11910	bejeweled legguards
11911	treetop leggings
11912	package of empty ooze containers
11913	clayridge helm
11914	empty cursed ooze jar
11915	shizzle s drizzle blocker
11916	shizzle s muzzle
11917	shizzle s nozzle wiper
11918	grotslab gloves
11919	cragplate greaves
11920	wraith scythe
11921	impervious giant
11922	blood etched blade
11923	the hammer of grace
11924	robes of the royal crown
11925	ghostshroud
11926	deathdealer breastplate
11927	legplates of the eternal guardian
11928	thaurissan s royal scepter
11929	haunting specter leggings
11930	the emperor s new cape
11931	dreadforge retaliator
11932	guiding stave of wisdom
11933	imperial jewel
11934	emperor s seal
11935	magmus stone
11936	relic hunter belt
11937	fat sack of coins
11938	sack of gems
11939	shiny bracelet
11940	sparkly necklace
11941	false documents
11942	legal documents
11943	deed to thandol span
11944	dark iron baby booties
11945	dark iron ring
11946	fire opal necklace
11947	filled cursed ooze jar
11948	empty tainted ooze jar
11949	filled tainted ooze jar
11950	windblossom berries
11951	whipper root tuber
11952	night dragon s breath
11953	empty pure sample jar
11954	filled pure sample jar
11955	bag of empty ooze containers
11962	manacle cuffs
11963	penance spaulders
11964	swiftstrike cudgel
11965	quartz ring
11966	small sack of coins
11967	zircon band
11968	amber hoop
11969	jacinth circle
11970	spinel ring
11971	amethyst band
11972	carnelian loop
11973	hematite link
11974	aquamarine ring
11975	topaz ring
11976	sardonyx knuckle
11977	serpentine loop
11978	jasper link
11979	peridot circle
11980	opal ring
11981	lead band
11982	viridian band
11983	chrome ring
11984	cobalt ring
11985	cerulean ring
11986	thallium hoop
11987	iridium circle
11988	tellurium band
11989	vanadium loop
11990	selenium loop
11991	quicksilver ring
11992	vermilion band
11993	clay ring
11994	coral band
11995	ivory band
11996	basalt ring
11997	greenstone circle
11998	jet loop
11999	lodestone hoop
12000	limb cleaver
12001	onyx ring
12002	marble circle
12003	dark dwarven lager
12004	obsidian band
12005	granite ring
12006	meadow ring
12007	prairie ring
12008	savannah ring
12009	tundra ring
12010	fen ring
12011	forest hoop
12012	marsh ring
12013	desert ring
12014	arctic ring
12015	swamp ring
12016	jungle ring
12017	prismatic band
12018	conservator helm
12019	cerulean talisman
12020	thallium choker
12021	shieldplate sabatons
12022	iridium chain
12023	tellurium necklace
12024	vanadium talisman
12025	selenium chain
12026	quicksilver pendant
12027	vermilion necklace
12028	basalt necklace
12029	greenstone talisman
12030	jet chain
12031	lodestone necklace
12032	onyx choker
12033	thaurissan family jewels
12034	marble necklace
12035	obsidian pendant
12036	granite necklace
12037	mystery meat
12038	lagrave s seal
12039	tundra necklace
12040	forest pendant
12041	windshear leggings
12042	marsh chain
12043	desert choker
12044	arctic pendant
12045	swamp pendant
12046	jungle necklace
12047	spectral necklace
12048	prismatic pendant
12049	splintsteel armor
12050	hazecover boots
12051	brazen gauntlets
12052	ring of the moon
12053	volcanic rock ring
12054	demon band
12055	stardust band
12056	ring of the heavens
12057	dragonscale band
12058	demonic bone ring
12059	conqueror s medallion
12060	shindrell s note
12061	blade of reckoning
12062	skilled fighting blade
12064	gamemaster hood
12065	ward of the elements
12066	shaleskin cape
12082	wyrmhide spaulders
12083	valconian sash
12102	ring of the aristocrat
12103	star of mystaria
12104	brindlethorn tunic
12105	pridemail leggings
12106	boulderskin breastplate
12107	whispersilk leggings
12108	basaltscale armor
12109	azure moon amice
12110	raincaster drape
12111	lavaplate gauntlets
12112	crypt demon bracers
12113	sunborne cape
12114	nightfall gloves
12115	stalwart clutch
12122	kum isha s junk
12143	dragonspine key
12144	eggscilloscope
12162	plans hardened iron shortsword
12163	plans moonsteel broadsword
12164	plans massive iron axe
12184	raptor flesh
12185	bloodsail admiral s hat
12190	dreamless sleep potion
12191	silver dawning s lockbox
12192	mist veil s lockbox
12202	tiger meat
12203	red wolf meat
12204	heavy kodo meat
12205	white spider meat
12206	tender crab meat
12207	giant egg
12208	tender wolf meat
12209	lean wolf steak
12210	roast raptor
12211	spiced wolf ribs
12212	jungle stew
12213	carrion surprise
12214	mystery stew
12215	heavy kodo stew
12216	spiced chili crab
12217	dragonbreath chili
12218	monster omelet
12219	unadorned seal of ascension
12220	intact elemental bracer
12223	meaty bat wing
12224	crispy bat wing
12225	blump family fishing pole
12226	recipe crispy bat wing
12227	recipe lean wolf steak
12228	recipe roast raptor
12229	recipe hot wolf ribs
12230	felwood slime sample
12231	recipe jungle stew
12232	recipe carrion surprise
12233	recipe mystery stew
12234	corrupted felwood sample
12235	un goro slime sample
12236	pure un goro sample
12237	fine crab chunks
12238	darkshore grouper
12239	recipe dragonbreath chili
12240	recipe heavy kodo stew
12241	collected dragon egg
12242	sea creature bones
12243	smoldering claw
12247	broad bladed knife
12248	daring dirk
12249	merciless axe
12250	midnight axe
12251	big stick
12252	staff of protection
12253	brilliant red cloak
12254	well oiled cloak
12255	pale leggings
12256	cindercloth leggings
12257	heavy notched belt
12258	serpent clasp belt
12259	glinting steel dagger
12260	searing golden blade
12261	plans searing golden blade
12262	empty worg pup cage
12263	caged worg pup
12264	worg carrier
12282	worn battleaxe
12283	broodling essence
12284	draco incarcinatrix 900
12286	eggscilloscope prototype
12287	collectronic module
12288	encased corrupt ooze
12289	sea turtle remains
12291	merged ooze sample
12292	strangely marked box
12293	fine gold thread
12295	leggings of the people s militia
12296	spark of the people s militia
12299	netted gloves
12300	orb of draconic energy
12301	bamboo cage key
12302	reins of the frostsaber
12303	reins of the nightsaber
12323	unforged seal of ascension
12324	forged seal of ascension
12325	reins of the primal leopard
12326	reins of the tawny sabercat
12327	reins of the golden sabercat
12330	horn of the red wolf
12334	frostmaul shards
12335	gemstone of smolderthorn
12336	gemstone of spirestone
12337	gemstone of bloodaxe
12339	vaelan s gift
12341	blackwood fruit sample
12342	blackwood grain sample
12343	blackwood nut sample
12344	seal of ascension
12345	bijou s belongings
12346	empty cleansing bowl
12347	filled cleansing bowl
12349	cliffspring river sample
12350	empty sampling tube
12351	horn of the arctic wolf
12352	doomrigger s clasp
12353	white stallion bridle
12354	palomino bridle
12355	talisman of corruption
12356	highperch wyvern egg
12358	darkstone tablet
12359	thorium bar
12360	arcanite bar
12361	blue sapphire
12363	arcane crystal
12364	huge emerald
12365	dense stone
12366	thick yeti fur
12367	pristine yeti horn
12368	dawn s gambit
12369	scepter of vectus
12382	key to the city
12383	moontouched feather
12384	cache of mau ari
12400	the judge s gavel
12402	ancient egg
12404	dense sharpening stone
12405	thorium armor
12406	thorium belt
12408	thorium bracers
12409	thorium boots
12410	thorium helm
12411	third mosh aru tablet
12412	fourth mosh aru tablet
12414	thorium leggings
12415	radiant breastplate
12416	radiant belt
12417	radiant circlet
12418	radiant gloves
12419	radiant boots
12420	radiant leggings
12422	imperial plate chest
12424	imperial plate belt
12425	imperial plate bracers
12426	imperial plate boots
12427	imperial plate helm
12428	imperial plate shoulders
12429	imperial plate leggings
12430	frostsaber e ko
12431	winterfall e ko
12432	shardtooth e ko
12433	wildkin e ko
12434	chillwind e ko
12435	ice thistle e ko
12436	frostmaul e ko
12437	ridgewell s crate
12438	tinkee s letter
12440	magic knucklebone dnd
12442	charm pouch dnd
12443	knucklebone pouch dnd
12444	uncracked chillwind horn
12445	felnok s package
12446	anvilmar musket
12447	thistlewood bow
12448	light hunting rifle
12449	primitive bow
12450	juju flurry
12451	juju power
12455	juju ember
12457	juju chill
12458	juju guile
12459	juju escape
12460	juju might
12462	embrace of the wind serpent
12463	drakefang butcher
12464	bloodfire talons
12465	nightfall drape
12466	dawnspire cord
12467	alien egg
12468	chilton wand
12469	mutilator
12470	sandstalker ankleguards
12471	desertwalker cane
12472	krakle s thermometer
12522	bingles flying gloves
12524	blue feathered amulet
12525	jaron s supplies
12527	ribsplitter
12528	the judge s gavel
12529	smolderweb carrier
12530	spire spider egg
12531	searing needle
12532	spire of the stoneshaper
12533	roughshod pike
12534	omokk s head
12535	doomforged straightedge
12542	funeral pyre vestment
12543	songstone of ironforge
12544	thrall s resolve
12545	eye of orgrimmar
12546	aristocratic cuffs
12547	mar alom s grip
12548	magni s will
12549	braincage
12550	runed golem shackles
12551	stoneshield cloak
12552	blisterbane wrap
12553	swiftwalker boots
12554	hands of the exalted herald
12555	battlechaser s greaves
12556	high priestess boots
12557	ebonsteel spaulders
12558	blue feathered necklace
12562	important blackrock documents
12563	warlord goretooth s command
12564	assassination note
12565	winna s kitten carrier
12566	hardened flasket
12567	filled flasket
12582	keris of zul serak
12583	blackhand doomsaw
12584	grand marshal s longsword
12585	stormwind medallion
12586	immature venom sac
12587	eye of rend
12588	bonespike shoulder
12589	dustfeather sash
12590	felstriker
12592	blackblade of shahram
12602	draconian deflector
12603	nightbrace tunic
12604	starfire tiara
12605	serpentine skuller
12606	crystallized girdle
12607	brilliant chromatic scale
12608	butcher s apron
12609	polychromatic visionwrap
12610	runic plate shoulders
12611	runic plate boots
12612	runic plate helm
12613	runic breastplate
12614	runic plate leggings
12615	savage mail tunic
12616	savage mail boots
12617	savage mail shoulders
12618	enchanted thorium breastplate
12619	enchanted thorium leggings
12620	enchanted thorium helm
12621	demonfork
12622	shardtooth meat
12623	chillwind meat
12624	wildthorn mail
12625	dawnbringer shoulders
12626	funeral cuffs
12627	temporal displacer
12628	demon forged breastplate
12630	head of rend blackhand
12631	fiery plate gauntlets
12632	storm gauntlets
12633	whitesoul helm
12634	chiselbrand girdle
12635	simple parchment
12636	helm of the great chief
12637	backusarian gauntlets
12638	andorhal watch
12639	stronghold gauntlets
12640	lionheart helm
12641	invulnerable mail
12642	cleansed infernal orb
12643	dense weightstone
12644	dense grinding stone
12645	thorium shield spike
12646	infus emerald
12647	felhas ruby
12648	imprisoned felhound spirit
12649	imprisoned infernal spirit
12650	attuned dampener
12651	blackcrow
12652	bijou s reconnaissance report
12653	riphook
12654	doomshot
12655	enchanted thorium bar
12662	demonic rune
12663	glyphed oaken branch
12682	plans thorium armor
12683	plans thorium belt
12684	plans thorium bracers
12685	plans radiant belt
12687	plans imperial plate shoulders
12688	plans imperial plate belt
12689	plans radiant breastplate
12690	plans imperial plate bracers
12691	plans wildthorn mail
12692	plans thorium shield spike
12693	plans thorium boots
12694	plans thorium helm
12695	plans radiant gloves
12696	plans demon forged breastplate
12697	plans radiant boots
12698	plans dawnbringer shoulders
12699	plans fiery plate gauntlets
12700	plans imperial plate boots
12701	plans imperial plate helm
12702	plans radiant circlet
12703	plans storm gauntlets
12704	plans thorium leggings
12705	plans imperial plate chest
12706	plans runic plate shoulders
12707	plans runic plate boots
12708	crossroads supply crates
12709	finkle s skinner
12710	glowing hunk of the beast s flesh
12711	plans whitesoul helm
12712	warosh s mojo
12713	plans radiant leggings
12714	plans runic plate helm
12715	plans imperial plate leggings
12716	plans helm of the great chief
12717	plans lionheart helm
12718	plans runic breastplate
12719	plans runic plate leggings
12720	plans stronghold gauntlets
12721	good luck half charm
12722	good luck other half charm
12723	good luck charm
12724	janice s parcel
12725	plans enchanted thorium helm
12726	plans enchanted thorium leggings
12727	plans enchanted thorium breastplate
12728	plans invulnerable mail
12730	warosh s scroll
12731	pristine hide of the beast
12732	incendia agave
12733	sacred frostsaber meat
12734	enchanted scarlet thread
12735	frayed abomination stitching
12736	frostwhisper s embalming fluid
12737	gloom weed
12738	dalson outhouse key
12739	dalson cabinet key
12740	fifth mosh aru tablet
12741	sixth mosh aru tablet
12752	cap of the scarlet savant
12753	skin of shadow
12756	leggings of arcana
12757	breastplate of bloodthirst
12762	secrecy of plans
12763	un goro etherfruit
12764	thorium greatsword
12765	secret note #1
12766	secret note #2
12768	secret note #3
12769	bleakwood hew
12770	bijou s information
12771	empty firewater flask
12772	inlaid thorium hammer
12773	ornate thorium handaxe
12774	dawn s edge
12775	huge thorium battleaxe
12776	enchanted battlehammer
12777	blazing rapier
12778	document chest
12779	rune edge
12780	general drakkisath s command
12781	serenity
12782	corruption
12783	heartseeker
12784	arcanite reaper
12785	incendia powder
12789	qatest raid buffs lvl 60
12790	arcanite champion
12791	barman shanker
12792	volcanic hammer
12793	mixologist s tunic
12794	masterwork stormhammer
12795	blood talon
12796	hammer of the titans
12797	frostguard
12798	annihilator
12799	large opal
12800	azerothian diamond
12802	darkspear
12803	living essence
12804	powerful mojo
12805	orb of fire
12806	unforged rune covered breastplate
12807	scourge banner
12808	essence of undeath
12809	guardian stone
12810	enchanted leather
12811	righteous orb
12812	unfired plate gauntlets
12813	flask of mystery goo
12814	flame in a bottle
12815	beacon torch
12816	plans thorium greatsword
12817	plans bleakwood hew
12818	plans inlaid thorium hammer
12819	plans ornate thorium handaxe
12820	winterfall firewater
12821	plans dawn s edge
12822	toxic horror droplet
12823	plans huge thorium battleaxe
12824	plans enchanted battlehammer
12825	plans blazing rapier
12826	plans rune edge
12827	plans serenity
12828	plans volcanic hammer
12829	winterfall crate
12830	plans corruption
12831	plans blood talon
12832	plans darkspear
12833	plans hammer of the titans
12834	plans arcanite champion
12835	plans annihilator
12836	plans frostguard
12837	plans masterwork stormhammer
12838	plans arcanite reaper
12839	plans heartseeker
12840	minion s scourgestone
12841	invader s scourgestone
12842	crudely written log
12843	corruptor s scourgestone
12844	argent dawn valor token
12845	medallion of faith
12846	argent dawn commission
12847	soul stained pike
12848	blood stained pike
12849	demon kissed sack
12866	jade bracers
12871	chromatic carapace
12884	arnak s hoof
12885	pamela s doll
12886	pamela s doll s head
12887	pamela s doll s left side
12888	pamela s doll s right side
12891	jaron s pick
12894	joseph s wedding ring
12895	breastplate of the chromatic flight
12896	first relic fragment
12897	second relic fragment
12898	third relic fragment
12899	fourth relic fragment
12900	annals of darrowshire
12903	legguards of the chromatic defier
12904	shawn s super special swami hat
12905	wildfire cape
12906	purified moonwell water
12907	corrupt moonwell water
12922	empty canteen
12923	awbee s scale
12924	ritual candle
12925	arikara serpent skin
12926	flaming band
12927	truestrike shoulders
12928	umi s mechanical yeti
12929	emberfury talisman
12930	briarwood reed
12935	warmaster legguards
12936	battleborn armbraces
12938	blood of heroes
12939	dal rend s tribal guardian
12940	dal rend s sacred charge
12942	panther cage key
12945	legplates of the chromatic defier
12946	hypercapacitor gizmo
12947	alex s ring of audacity
12952	gyth s skull
12953	dragoneye coif
12954	davil s libram
12955	redpath s shield
12956	skull of horgus
12957	shattered sword of marduk
12958	recipe transmute arcanite
12960	tribal war feathers
12963	blademaster leggings
12964	tristam legguards
12965	spiritshroud leggings
12966	blackmist armguards
12967	bloodmoon cloak
12968	frostweaver cape
12969	seeping willow
12970	general s ceremonial plate
12973	scarlet cannonball
12974	the black knight
12975	prospector axe
12976	ironpatch blade
12977	magefist gloves
12978	stormbringer belt
12979	firebane cloak
12982	silver linked footguards
12983	rakzur club
12984	skycaller
12985	ring of defense
12987	darkweave breeches
12988	starsight tunic
12989	gargoyle s bite
12990	razor s edge
12992	searing blade
12994	thorbia s gauntlets
12996	band of purification
12997	redbeard crest
12998	magician s mantle
12999	drakewing bands
13000	staff of hale magefire
13001	maiden s circle
13002	lady alizabeth s pendant
13003	lord alexander s battle axe
13004	torch of austen
13005	amy s blanket
13006	mass of mcgowan
13007	mageflame cloak
13008	dalewind trousers
13009	cow king s hide
13010	dreamsinger legguards
13011	silver lined belt
13012	yorgen bracers
13013	elder wizard s mantle
13014	axe of rin ji
13015	serathil
13016	killmaim
13017	hellslayer battle axe
13018	executioner s cleaver
13019	harpyclaw short bow
13020	skystriker bow
13021	needle threader
13022	gryphonwing long bow
13023	eaglehorn long bow
13024	beazel s basher
13025	deadwood sledge
13026	heaven s light
13027	bonesnapper
13028	bludstone hammer
13029	umbral crystal
13030	basilisk bone
13031	orb of mistmantle
13032	sword of corruption
13033	zealot blade
13034	speedsteel rapier
13035	serpent slicer
13036	assassination blade
13037	crystalpine stinger
13038	swiftwind
13039	skull splitting crossbow
13040	heartseeking crossbow
13041	guardian blade
13042	sword of the magistrate
13043	blade of the titans
13044	demonslayer
13045	viscous hammer
13046	blanchard s stout
13047	twig of the world tree
13048	looming gavel
13049	deanship claymore
13051	witchfury
13052	warmonger
13053	doombringer
13054	grim reaper
13055	bonechewer
13056	frenzied striker
13057	bloodpike
13058	khoo s point
13059	stoneraven
13060	the needler
13062	thunderwood
13063	starfaller
13064	jaina s firestarter
13065	wand of allistarj
13066	wyrmslayer spaulders
13067	hydralick armor
13068	obsidian greaves
13070	sapphiron s scale boots
13071	plated fist of hakoo
13072	stonegrip gauntlets
13073	mugthol s helm
13074	golem shard leggings
13075	direwing legguards
13076	giantslayer bracers
13077	girdle of uther
13079	shield of thorsen
13080	widow s clutch
13081	skullance shield
13082	mountainside buckler
13083	garrett family crest
13084	kaleidoscope chain
13085	horizon choker
13086	reins of the winterspring frostsaber
13087	river pride choker
13088	gazlowe s charm
13089	skibi s pendant
13090	breastplate of the chosen
13091	medallion of grand marshal morris
13092	dragonstalker tunic
13093	blush ember ring
13094	the queen s jewel
13095	assault band
13096	band of the hierophant
13097	thunderbrow ring
13098	painweaver band
13099	moccasins of the white hare
13100	furen s boots
13101	wolfrunner shoes
13102	cassandra s grace
13103	pads of the venom spider
13105	sutarn s ring
13106	glowing magical bracelets
13107	magiskull cuffs
13108	tigerstrike mantle
13109	blackflame cape
13110	wolffear harness
13111	sandals of the insurgent
13112	winged helm
13113	feathermoon headdress
13114	troll s bane leggings
13115	sheepshear mantle
13116	spaulders of the unseen
13117	ogron s sash
13118	serpentine sash
13119	enchanted kodo bracers
13120	deepfury bracers
13121	wing of the whelpling
13122	dark phantom cape
13123	dreamwalker armor
13124	ravasaur scale boots
13125	elven chain boots
13126	battlecaller gauntlets
13127	frostreaver crown
13128	high bergg helm
13129	firemane leggings
13130	windrunner legguards
13131	sparkleshell mantle
13132	skeletal shoulders
13133	drakesfire epaulets
13134	belt of the gladiator
13135	lordly armguards
13136	lil timmy s peashooter
13137	ironweaver
13138	the silencer
13139	guttbuster
13140	blood red key
13141	tooth of gnarr
13142	brigam girdle
13143	mark of the dragon lord
13144	serenity belt
13145	enormous ogre belt
13146	shell launcher shotgun
13148	chillpike
13149	eldarathian tome of summoning vol 1
13151	the mystic studies of hor ank
13152	the story with no conclusion
13153	tome of mal cin vorail
13154	jael marin s studies of the arcane
13155	resonating skull
13156	mystic crystal
13157	fetid skull
13158	words of the high chief
13159	bone dust
13161	trindlehaven staff
13162	reiver claws
13163	relentless scythe
13164	heart of the scale
13166	slamshot shoulders
13167	fist of omokk
13168	plate of the shaman king
13169	tressermane leggings
13170	skyshroud leggings
13171	smokey s lighter
13172	siabi s premium tobacco
13173	broken flightblade throwing axe
13174	plagued flesh sample
13175	voone s twitchbow
13176	scourge data
13177	talisman of evasion
13178	rosewine circle
13179	brazecore armguards
13180	stratholme holy water
13181	demonskin gloves
13182	phase blade
13183	venomspitter
13184	fallbrush handgrips
13185	sunderseer mantle
13186	empty felstone field bottle
13187	empty dalson s tears bottle
13188	empty writhing haunt bottle
13189	empty gahrron s withering bottle
13190	filled felstone field bottle
13191	filled dalson s tears bottle
13192	filled writhing haunt bottle
13193	filled gahrron s withering bottle
13194	felstone field cauldron key
13195	dalson s tears cauldron key
13196	gahrron s withering cauldron key
13197	writhing haunt cauldron key
13198	hurd smasher
13199	crushridge bindings
13202	extended annals of darrowshire
13203	armswake cloak
13204	bashguuder
13205	rhombeard protector
13206	wolfshear leggings
13207	shadow lord fel dan s head
13208	bleak howler armguards
13209	seal of the dawn
13210	pads of the dread wolf
13211	slashclaw bracers
13212	halycon s spiked collar
13213	smolderweb s eye
13216	crown of the penitent
13217	band of the penitent
13218	fang of the crystal spider
13223	stratholme courier s pouch
13243	argent defender
13244	gilded gauntlets
13245	kresh s back
13246	argent avenger
13247	quartermaster zigris footlocker
13248	burstshot harquebus
13249	argent crusader
13250	head of balnazzar
13251	head of baron rivendare
13252	cloudrunner girdle
13253	hands of power
13254	astral guard
13255	trueaim gauntlets
13257	demonic runed spaulders
13258	slaghide gauntlets
13259	ribsteel footguards
13260	wind dancer boots
13261	globe of d sak
13262	ashbringer
13282	ogreseer tower boots
13283	magus ring
13284	swiftdart battleboots
13285	the blackrock slicer
13286	rivenspike
13287	pattern raptor hide harness
13288	pattern raptor hide belt
13289	egan s blaster
13302	market row postbox key
13303	crusaders square postbox key
13304	festival lane postbox key
13305	elders square postbox key
13306	king s square postbox key
13307	fras siabi s postbox key
13308	schematic ice deflector
13309	schematic lovingly crafted boomstick
13310	schematic accurate scope
13311	schematic mechanical dragonling
13313	sacred highborne writings
13314	alanna s embrace
13315	testament of hope
13317	whistle of the ivory raptor
13320	arcane quickener
13321	green mechanostrider
13322	unpainted mechanostrider
13323	purple mechanostrider
13324	red and blue mechanostrider
13325	fluorescent green mechanostrider
13326	white mechanostrider mod a
13327	icy blue mechanostrider mod a
13328	black ram
13329	frost ram
13330	derek s radish bag
13331	red skeletal horse
13332	blue skeletal horse
13333	brown skeletal horse
13334	green skeletal warhorse
13335	deathcharger s reins
13340	cape of the black baron
13342	pet fish
13343	pet stone
13344	dracorian gauntlets
13345	seal of rivendare
13346	robes of the exalted
13347	crystal of zin malor
13348	demonshear
13349	scepter of the unholy
13350	insignia of the black guard
13351	crimson hammersmith s apron
13352	vosh gajin s snakestone
13353	book of the dead
13354	ectoplasmic resonator
13356	somatic intensifier
13357	osseous agitator
13358	wyrmtongue shoulders
13359	crown of tyranny
13360	gift of the elven magi
13361	skullforge reaver
13362	letter from the front
13363	municipal proclamation
13364	fras siabi s advertisement
13365	town meeting notice
13366	ingenious toy
13367	wrapped gift
13368	bonescraper
13369	fire striders
13370	vitreous focuser
13371	father flame
13372	slavedriver s cane
13373	band of flesh
13374	soulstealer mantle
13375	crest of retribution
13376	royal tribunal cloak
13377	miniature cannon balls
13378	songbird blouse
13379	piccolo of the flaming fire
13380	willey s portable howitzer
13381	master cannoneer boots
13382	cannonball runner
13383	woollies of the prancing minstrel
13384	rainbow girdle
13385	tome of knowledge
13386	archivist cape
13387	foresight girdle
13388	the postmaster s tunic
13389	the postmaster s trousers
13390	the postmaster s band
13391	the postmaster s treads
13392	the postmaster s seal
13393	malown s slam
13394	skul s cold embrace
13395	skul s fingerbone claws
13396	skul s ghastly touch
13397	stoneskin gargoyle cape
13398	boots of the shrieker
13399	gargoyle shredder talons
13400	vambraces of the sadist
13401	the cruel hand of timmy
13402	timmy s galoshes
13403	grimgore noose
13404	mask of the unforgiven
13405	wailing nightbane pauldrons
13408	soul breaker
13409	tearfall bracers
13422	stonescale eel
13423	stonescale oil
13442	mighty rage potion
13443	superior mana potion
13444	major mana potion
13445	elixir of superior defense
13446	major healing potion
13447	elixir of the sages
13448	the deed to caer darrow
13450	the deed to southshore
13451	the deed to tarren mill
13452	elixir of the mongoose
13453	elixir of brute force
13454	greater arcane elixir
13455	greater stoneshield potion
13456	greater frost protection potion
13457	greater fire protection potion
13458	greater nature protection potion
13459	greater shadow protection potion
13460	greater holy protection potion
13461	greater arcane protection potion
13462	purification potion
13463	dreamfoil
13464	golden sansam
13465	mountain silversage
13466	plaguebloom
13467	icecap
13468	black lotus
13469	head of weldon barov
13470	head of alexi barov
13471	the deed to brill
13473	felstone good luck charm
13474	farmer dalson s shotgun
13475	dalson family wedding ring
13476	recipe mighty rage potion
13477	recipe superior mana potion
13478	recipe elixir of superior defense
13479	recipe elixir of the sages
13480	recipe major healing potion
13481	recipe elixir of brute force
13482	recipe transmute air to fire
13483	recipe transmute fire to earth
13484	recipe transmute earth to water
13485	recipe transmute water to air
13486	recipe transmute undeath to water
13487	recipe transmute water to undeath
13488	recipe transmute life to earth
13489	recipe transmute earth to life
13490	recipe greater stoneshield potion
13491	recipe elixir of the mongoose
13492	recipe purification potion
13493	recipe greater arcane elixir
13494	recipe greater fire protection potion
13495	recipe greater frost protection potion
13496	recipe greater nature protection potion
13497	recipe greater arcane protection potion
13498	handcrafted mastersmith leggings
13499	recipe greater shadow protection potion
13500	recipe greater holy protection potion
13501	recipe major mana potion
13502	handcrafted mastersmith girdle
13503	alchemist s stone
13505	runeblade of baron rivendare
13506	flask of petrification
13507	cliffwatcher longhorn report
13508	eye of arachnida
13509	clutch of foresight
13510	flask of the titans
13511	flask of distilled wisdom
13512	flask of supreme power
13513	flask of chromatic resistance
13514	wail of the banshee
13515	ramstein s lightning bolts
13517	recipe alchemist s stone
13518	recipe flask of petrification
13519	recipe flask of the titans
13520	recipe flask of distilled wisdom
13521	recipe flask of supreme power
13522	recipe flask of chromatic resistance
13523	blood of innocents
13524	skull of burning shadows
13525	darkbind fingers
13526	flamescarred girdle
13527	lavawalker greaves
13528	twilight void bracers
13529	husk of nerub enkan
13530	fangdrip runners
13531	crypt stalker leggings
13532	darkspinner claws
13533	acid etched pauldrons
13534	banshee finger
13535	coldtouch phantom wraps
13536	horn of awakening
13537	chillhide bracers
13538	windshrieker pauldrons
13539	banshee s touch
13542	demon box
13544	spectral essence
13545	shellfish
13546	bloodbelly fish
13562	remains of trey lightforge
13582	zergling leash
13583	panda collar
13584	diablo stone
13585	keepsake of remembrance
13602	greater spellstone
13603	major spellstone
13624	soulbound keepsake
13626	human head of ras frostwhisper
13699	firestone
13700	greater firestone
13701	major firestone
13702	doom weed
13703	kodo bone
13704	skeleton key
13724	enriched manna biscuit
13725	krastinov s bag of horrors
13752	soulbound keepsake
13754	raw glossy mightfish
13755	winter squid
13756	raw summer bass
13757	lightning eel
13758	raw redgill
13759	raw nightfin snapper
13760	raw sunscale salmon
13761	frozen eggs
13810	blessed sunfruit
13811	necklace of the dawn
13812	ring of the dawn
13813	blessed sunfruit juice
13815	some rune
13816	fine longsword
13817	tapered greatsword
13818	jagged axe
13819	balanced war axe
13820	clout mace
13821	bulky maul
13822	spiked dagger
13823	stout war staff
13824	recurve long bow
13825	primed musket
13842	fall winter morning
13843	fall winter afternoon
13844	fall winter evening
13845	fall winter night
13846	spring summer morning
13847	spring summer afternoon
13848	spring summer evening
13849	spring summer night
13850	rumbleshot s ammo
13851	hot wolf ribs
13852	the grand crusader s command
13853	slab of carrion worm meat
13856	runecloth belt
13857	runecloth tunic
13858	runecloth robe
13860	runecloth cloak
13863	runecloth gloves
13864	runecloth boots
13865	runecloth pants
13866	runecloth headband
13867	runecloth shoulders
13868	frostweave robe
13869	frostweave tunic
13870	frostweave gloves
13871	frostweave pants
13872	bundle of wood
13873	viewing room key
13874	heavy crate
13875	ironbound locked chest
13876	40 pound grouper
13877	47 pound grouper
13878	53 pound grouper
13879	59 pound grouper
13880	68 pound grouper
13881	bloated redgill
13882	42 pound redgill
13883	45 pound redgill
13884	49 pound redgill
13885	34 pound redgill
13886	37 pound redgill
13887	52 pound redgill
13888	darkclaw lobster
13889	raw whitescale salmon
13890	plated armorfish
13891	bloated salmon
13892	kodo kombobulator
13893	large raw mightfish
13895	formal dangui
13896	dark green wedding hanbok
13897	white traditional hanbok
13898	royal dangui
13899	red traditional hanbok
13900	green wedding hanbok
13901	15 pound salmon
13902	18 pound salmon
13903	22 pound salmon
13904	25 pound salmon
13905	29 pound salmon
13906	32 pound salmon
13907	7 pound lobster
13908	9 pound lobster
13909	12 pound lobster
13910	15 pound lobster
13911	19 pound lobster
13912	21 pound lobster
13913	22 pound lobster
13914	70 pound mightfish
13915	85 pound mightfish
13916	92 pound mightfish
13917	103 pound mightfish
13918	reinforced locked chest
13920	healthy dragon scale
13926	golden pearl
13927	cooked glossy mightfish
13928	grilled squid
13929	hot smoked bass
13930	filet of redgill
13931	nightfin soup
13932	poached sunscale salmon
13933	lobster stew
13934	mightfish steak
13935	baked salmon
13936	dreadmaster s shroud
13937	headmaster s charge
13938	bonecreeper stylus
13939	recipe spotted yellowtail
13940	recipe cooked glossy mightfish
13941	recipe filet of redgill
13942	recipe grilled squid
13943	recipe hot smoked bass
13944	tombstone breastplate
13945	recipe nightfin soup
13946	recipe poached sunscale salmon
13947	recipe lobster stew
13948	recipe mightfish steak
13949	recipe baked salmon
13950	detention strap
13951	vigorsteel vambraces
13952	iceblade hacker
13953	silent fang
13954	verdant footpads
13955	stoneform shoulders
13956	clutch of andros
13957	gargoyle slashers
13958	wyrmthalak s shackles
13959	omokk s girth restrainer
13960	heart of the fiend
13961	halycon s muzzle
13962	vosh gajin s strand
13963	voone s vice grips
13964	witchblade
13965	blackhand s breadth
13966	mark of tyranny
13967	windreaver greaves
13968	eye of the beast
13969	loomguard armbraces
13982	warblade of caer darrow
13983	gravestone war axe
13984	darrowspike
13986	crown of caer darrow
14002	darrowshire strongguard
14022	barov peasant caller
14023	barov peasant caller
14024	frightalon
14025	mystic s belt
14042	cindercloth vest
14043	cindercloth gloves
14044	cindercloth cloak
14045	cindercloth pants
14046	runecloth bag
14047	runecloth
14048	bolt of runecloth
14062	kodo mount
14083	tyrande s staff
14086	beaded sandals
14087	beaded cuffs
14088	beaded cloak
14089	beaded gloves
14090	beaded britches
14091	beaded robe
14093	beaded cord
14094	beaded wraps
14095	native bands
14096	native vest
14097	native pants
14098	native cloak
14099	native sash
14100	brightcloth robe
14101	brightcloth gloves
14102	native handwraps
14103	brightcloth cloak
14104	brightcloth pants
14106	felcloth robe
14107	felcloth pants
14108	felcloth boots
14109	native robe
14110	native sandals
14111	felcloth hood
14112	felcloth shoulders
14113	aboriginal sash
14114	aboriginal footwraps
14115	aboriginal bands
14116	aboriginal cape
14117	aboriginal gloves
14119	aboriginal loincloth
14120	aboriginal robe
14121	aboriginal vest
14122	ritual bands
14123	ritual cape
14124	ritual gloves
14125	ritual leggings
14126	ritual amice
14127	ritual shroud
14128	wizardweave robe
14129	ritual sandals
14130	wizardweave turban
14131	ritual belt
14132	wizardweave leggings
14133	ritual tunic
14134	cloak of fire
14136	robe of winter night
14137	mooncloth leggings
14138	mooncloth vest
14139	mooncloth shoulders
14140	mooncloth circlet
14141	ghostweave vest
14142	ghostweave gloves
14143	ghostweave belt
14144	ghostweave pants
14145	cursed felblade
14146	gloves of spell mastery
14147	cavedweller bracers
14148	crystalline cuffs
14149	subterranean cape
14150	robe of evocation
14151	chanting blade
14152	robe of the archmage
14153	robe of the void
14154	truefaith vestments
14155	mooncloth bag
14156	bottomless bag
14157	pagan mantle
14158	pagan vest
14159	pagan shoes
14160	pagan bands
14161	pagan cape
14162	pagan mitts
14163	pagan wraps
14164	pagan belt
14165	pagan britches
14166	buccaneer s bracers
14167	buccaneer s cape
14168	buccaneer s gloves
14169	aboriginal shoulder pads
14170	buccaneer s mantle
14171	buccaneer s pants
14172	buccaneer s robes
14173	buccaneer s cord
14174	buccaneer s boots
14175	buccaneer s vest
14176	watcher s boots
14177	watcher s cuffs
14178	watcher s cap
14179	watcher s cape
14180	watcher s jerkin
14181	watcher s handwraps
14182	watcher s mantle
14183	watcher s leggings
14184	watcher s robes
14185	watcher s cinch
14186	raincaller mantle
14187	raincaller cuffs
14188	raincaller cloak
14189	raincaller cap
14190	raincaller vest
14191	raincaller mitts
14192	raincaller robes
14193	raincaller pants
14194	raincaller cord
14195	raincaller boots
14196	thistlefur sandals
14197	thistlefur bands
14198	thistlefur cloak
14199	thistlefur gloves
14200	thistlefur cap
14201	thistlefur mantle
14202	thistlefur jerkin
14203	thistlefur pants
14204	thistlefur robe
14205	thistlefur belt
14206	vital bracelets
14207	vital leggings
14208	vital headband
14209	vital sash
14210	vital cape
14211	vital handwraps
14212	vital shoulders
14213	vital raiment
14214	vital boots
14215	vital tunic
14216	geomancer s jerkin
14217	geomancer s cord
14218	geomancer s boots
14219	geomancer s cloak
14220	geomancer s cap
14221	geomancer s bracers
14222	geomancer s gloves
14223	geomancer s spaulders
14224	geomancer s trousers
14225	geomancer s wraps
14226	embersilk bracelets
14227	ironweb spider silk
14228	embersilk coronet
14229	embersilk cloak
14230	embersilk tunic
14231	embersilk mitts
14232	embersilk mantle
14233	embersilk leggings
14234	embersilk robes
14235	embersilk cord
14236	embersilk boots
14237	darkmist armor
14238	darkmist boots
14239	darkmist cape
14240	darkmist bands
14241	darkmist handguards
14242	darkmist pants
14243	darkmist mantle
14244	darkmist wraps
14245	darkmist girdle
14246	darkmist wizard hat
14247	lunar mantle
14248	lunar bindings
14249	lunar vest
14250	lunar slippers
14251	lunar cloak
14252	lunar coronet
14253	lunar handwraps
14254	lunar raiment
14255	lunar belt
14256	felcloth
14257	lunar leggings
14258	bloodwoven cord
14259	bloodwoven boots
14260	bloodwoven bracers
14261	bloodwoven cloak
14262	bloodwoven mitts
14263	bloodwoven mask
14264	bloodwoven pants
14265	bloodwoven wraps
14266	bloodwoven pads
14267	bloodwoven jerkin
14268	gaea s cuffs
14269	gaea s slippers
14270	gaea s cloak
14271	gaea s circlet
14272	gaea s handwraps
14273	gaea s amice
14274	gaea s leggings
14275	gaea s raiment
14276	gaea s belt
14277	gaea s tunic
14278	opulent mantle
14279	opulent bracers
14280	opulent cape
14281	opulent crown
14282	opulent gloves
14283	opulent leggings
14284	opulent robes
14285	opulent boots
14286	opulent belt
14287	opulent tunic
14288	arachnidian armor
14289	arachnidian girdle
14290	arachnidian footpads
14291	arachnidian bracelets
14292	arachnidian cape
14293	arachnidian circlet
14294	arachnidian gloves
14295	arachnidian legguards
14296	arachnidian pauldrons
14297	arachnidian robes
14298	bonecaster s spaulders
14299	bonecaster s boots
14300	bonecaster s cape
14301	bonecaster s bindings
14302	bonecaster s gloves
14303	bonecaster s shroud
14304	bonecaster s belt
14305	bonecaster s sarong
14306	bonecaster s vest
14307	bonecaster s crown
14308	celestial tunic
14309	celestial belt
14310	celestial slippers
14311	celestial bindings
14312	celestial crown
14313	celestial cape
14314	celestial handwraps
14315	celestial kilt
14316	celestial pauldrons
14317	celestial silk robes
14318	resplendent tunic
14319	resplendent boots
14320	resplendent bracelets
14321	resplendent cloak
14322	resplendent circlet
14323	resplendent gauntlets
14324	resplendent sarong
14325	resplendent epaulets
14326	resplendent robes
14327	resplendent belt
14328	eternal chestguard
14329	eternal boots
14330	eternal bindings
14331	eternal cloak
14332	eternal crown
14333	eternal gloves
14334	eternal sarong
14335	eternal spaulders
14336	eternal wraps
14337	eternal cord
14338	empty water tube
14339	moonwell water tube
14340	freezing lich robes
14341	rune thread
14342	mooncloth
14343	small brilliant shard
14344	large brilliant shard
14364	mystic s slippers
14365	mystic s cape
14366	mystic s bracelets
14367	mystic s gloves
14368	mystic s shoulder pads
14369	mystic s wrap
14370	mystic s woolies
14371	mystic s robe
14372	sanguine armor
14373	sanguine belt
14374	sanguine sandals
14375	sanguine cuffs
14376	sanguine cape
14377	sanguine handwraps
14378	sanguine mantle
14379	sanguine trousers
14380	sanguine robe
14381	grimtotem satchel
14382	durability chestpiece
14383	durability bracers
14384	durability boots
14385	durability cloak
14386	durability hat
14387	durability gloves
14388	durability leggings
14389	durability shoulderpads
14390	durability belt
14391	durability sword
14392	durability staff
14393	durability shield
14394	durability bow
14395	spells of shadow
14396	incantations from the nether
14397	resilient mantle
14398	resilient tunic
14399	resilient boots
14400	resilient cape
14401	resilient cap
14402	resilient bands
14403	resilient handgrips
14404	resilient leggings
14405	resilient robe
14406	resilient cord
14407	stonecloth vest
14408	stonecloth boots
14409	stonecloth cape
14410	stonecloth circlet
14411	stonecloth gloves
14412	stonecloth epaulets
14413	stonecloth robe
14414	stonecloth belt
14415	stonecloth britches
14416	stonecloth bindings
14417	silksand tunic
14418	silksand boots
14419	silksand bracers
14420	silksand cape
14421	silksand circlet
14422	silksand gloves
14423	silksand shoulder pads
14424	silksand legwraps
14425	silksand wraps
14426	silksand girdle
14427	windchaser wraps
14428	windchaser footpads
14429	windchaser cuffs
14430	windchaser cloak
14431	windchaser handguards
14432	windchaser amice
14433	windchaser woolies
14434	windchaser robes
14435	windchaser cinch
14436	windchaser coronet
14437	venomshroud vest
14438	venomshroud boots
14439	venomshroud armguards
14440	venomshroud cape
14441	venomshroud mask
14442	venomshroud mitts
14443	venomshroud mantle
14444	venomshroud leggings
14445	venomshroud silk robes
14446	venomshroud belt
14447	highborne footpads
14448	highborne bracelets
14449	highborne crown
14450	highborne cloak
14451	highborne gloves
14452	highborne pauldrons
14453	highborne robes
14454	highborne cord
14455	highborne padded armor
14456	elunarian vest
14457	elunarian cuffs
14458	elunarian boots
14459	elunarian cloak
14460	elunarian diadem
14461	elunarian handgrips
14462	elunarian sarong
14463	elunarian spaulders
14464	elunarian silk robes
14465	elunarian belt
14466	pattern frostweave tunic
14467	pattern frostweave robe
14468	pattern runecloth bag
14469	pattern runecloth robe
14470	pattern runecloth tunic
14471	pattern cindercloth vest
14472	pattern runecloth cloak
14473	pattern ghostweave belt
14474	pattern frostweave gloves
14476	pattern cindercloth gloves
14477	pattern ghostweave gloves
14478	pattern brightcloth robe
14479	pattern brightcloth gloves
14480	pattern ghostweave vest
14481	pattern runecloth gloves
14482	pattern cindercloth cloak
14483	pattern felcloth pants
14484	pattern brightcloth cloak
14485	pattern wizardweave leggings
14486	pattern cloak of fire
14487	bonechill hammer
14488	pattern runecloth boots
14489	pattern frostweave pants
14490	pattern cindercloth pants
14491	pattern runecloth pants
14492	pattern felcloth boots
14493	pattern robe of winter night
14494	pattern brightcloth pants
14495	pattern ghostweave pants
14496	pattern felcloth hood
14497	pattern mooncloth leggings
14498	pattern runecloth headband
14499	pattern mooncloth bag
14500	pattern wizardweave robe
14501	pattern mooncloth vest
14502	frostbite girdle
14503	death s clutch
14504	pattern runecloth shoulders
14505	pattern wizardweave turban
14506	pattern felcloth robe
14507	pattern mooncloth shoulders
14508	pattern felcloth shoulders
14509	pattern mooncloth circlet
14510	pattern bottomless bag
14511	pattern gloves of spell mastery
14512	pattern truefaith vestments
14513	pattern robe of the archmage
14514	pattern robe of the void
14522	maelstrom leggings
14523	demon pick
14525	boneclenched gauntlets
14526	pattern mooncloth
14528	rattlecage buckler
14529	runecloth bandage
14530	heavy runecloth bandage
14531	frightskull shaft
14536	bonebrace hauberk
14537	corpselight greaves
14538	deadwalker mantle
14539	bone ring helm
14540	taragaman the hungerer s heart
14541	barovian family sword
14542	kravel s crate
14543	darkshade gloves
14544	lieutenant s insignia
14545	ghostloom leggings
14546	roon s kodo horn
14547	hand of iruxos
14548	royal cap spaulders
14549	boots of avoidance
14550	bladebane armguards
14551	edgemaster s handguards
14552	stockade pauldrons
14553	sash of mercy
14554	cloudkeeper legplates
14555	alcor s sunrazor
14557	the lion horn of stormwind
14558	lady maye s pendant
14559	prospector s sash
14560	prospector s boots
14561	prospector s cuffs
14562	prospector s chestpiece
14563	prospector s cloak
14564	prospector s mitts
14565	prospector s woolies
14566	prospector s pads
14567	bristlebark belt
14568	bristlebark boots
14569	bristlebark bindings
14570	bristlebark blouse
14571	bristlebark cape
14572	bristlebark gloves
14573	bristlebark amice
14574	bristlebark britches
14576	ebon hilt of marduk
14577	skullsmoke pants
14578	dokebi cord
14579	dokebi boots
14580	dokebi bracers
14581	dokebi chestguard
14582	dokebi cape
14583	dokebi gloves
14584	dokebi hat
14585	dokebi leggings
14587	dokebi mantle
14588	hawkeye s cord
14589	hawkeye s shoes
14590	hawkeye s bracers
14591	hawkeye s helm
14592	hawkeye s tunic
14593	hawkeye s cloak
14594	hawkeye s gloves
14595	hawkeye s breeches
14596	hawkeye s epaulets
14598	warden s waistband
14599	warden s footpads
14600	warden s wristbands
14601	warden s wraps
14602	warden s cloak
14603	warden s mantle
14604	warden s wizard hat
14605	warden s woolies
14606	warden s gloves
14607	hawkeye s buckler
14608	dokebi buckler
14610	araj s scarab
14611	bloodmail hauberk
14612	bloodmail legguards
14613	taelan s hammer
14614	bloodmail belt
14615	bloodmail gauntlets
14616	bloodmail boots
14617	sawbones shirt
14619	skeletal fragments
14620	deathbone girdle
14621	deathbone sabatons
14622	deathbone gauntlets
14623	deathbone legguards
14624	deathbone chestplate
14625	symbol of lost honor
14626	necropile robe
14627	pattern bright yellow shirt
14628	imbued skeletal fragments
14629	necropile cuffs
14630	pattern enchanter s cowl
14631	necropile boots
14632	necropile leggings
14633	necropile mantle
14634	recipe frost oil
14635	pattern gem studded leather belt
14636	cadaverous belt
14637	cadaverous armor
14638	cadaverous leggings
14639	schematic minor recombobulator
14640	cadaverous gloves
14641	cadaverous walkers
14644	skeleton key mold
14645	unfinished skeleton key
14646	northshire gift voucher
14647	coldridge valley gift voucher
14648	shadowglen gift voucher
14649	valley of trials gift voucher
14650	camp narache gift voucher
14651	deathknell gift voucher
14652	scorpashi sash
14653	scorpashi slippers
14654	scorpashi wristbands
14655	scorpashi breastplate
14656	scorpashi cape
14657	scorpashi gloves
14658	scorpashi skullcap
14659	scorpashi leggings
14660	scorpashi shoulder pads
14661	keeper s cord
14662	keeper s hooves
14663	keeper s bindings
14664	keeper s armor
14665	keeper s cloak
14666	keeper s gloves
14667	keeper s wreath
14668	keeper s woolies
14669	keeper s mantle
14670	pridelord armor
14671	pridelord boots
14672	pridelord bands
14673	pridelord cape
14674	pridelord girdle
14675	pridelord gloves
14676	pridelord halo
14677	pridelord pants
14678	pridelord pauldrons
14679	of love and family
14680	indomitable vest
14681	indomitable boots
14682	indomitable armguards
14683	indomitable cloak
14684	indomitable belt
14685	indomitable gauntlets
14686	indomitable headdress
14687	indomitable leggings
14688	indomitable epaulets
14722	war paint anklewraps
14723	war paint bindings
14724	war paint cloak
14725	war paint waistband
14726	war paint gloves
14727	war paint legguards
14728	war paint shoulder pads
14729	war paint shield
14730	war paint chestpiece
14742	hulking boots
14743	hulking bands
14744	hulking chestguard
14745	hulking cloak
14746	hulking belt
14747	hulking gauntlets
14748	hulking leggings
14749	hulking spaulders
14750	slayer s cuffs
14751	slayer s surcoat
14752	slayer s cape
14753	slayer s skullcap
14754	slayer s gloves
14755	slayer s sash
14756	slayer s slippers
14757	slayer s pants
14758	slayer s shoulderguards
14759	enduring bracers
14760	enduring breastplate
14761	enduring belt
14762	enduring boots
14763	enduring cape
14764	enduring gauntlets
14765	enduring circlet
14766	enduring breeches
14767	enduring pauldrons
14768	ravager s armor
14769	ravager s sandals
14770	ravager s armguards
14771	ravager s cloak
14772	ravager s handwraps
14773	ravager s cord
14774	ravager s crown
14775	ravager s woolies
14776	ravager s mantle
14777	ravager s shield
14778	khan s bindings
14779	khan s chestpiece
14780	khan s buckler
14781	khan s cloak
14782	khan s gloves
14783	khan s belt
14784	khan s greaves
14785	khan s helmet
14786	khan s legguards
14787	khan s mantle
14788	protector armguards
14789	protector breastplate
14790	protector buckler
14791	protector cape
14792	protector gauntlets
14793	protector waistband
14794	protector ankleguards
14795	protector helm
14796	protector legguards
14797	protector pads
14798	bloodlust breastplate
14799	bloodlust boots
14800	bloodlust buckler
14801	bloodlust cape
14802	bloodlust gauntlets
14803	bloodlust belt
14804	bloodlust helm
14805	bloodlust britches
14806	bloodlust epaulets
14807	bloodlust bracelets
14808	warstrike belt
14809	warstrike sabatons
14810	warstrike armsplints
14811	warstrike chestguard
14812	warstrike buckler
14813	warstrike cape
14814	warstrike helmet
14815	warstrike gauntlets
14816	warstrike legguards
14817	warstrike shoulder pads
14821	symbolic breastplate
14825	symbolic crest
14826	symbolic gauntlets
14827	symbolic belt
14828	symbolic greaves
14829	symbolic legplates
14830	symbolic pauldrons
14831	symbolic crown
14832	symbolic vambraces
14833	tyrant s gauntlets
14834	tyrant s armguards
14835	tyrant s chestpiece
14838	tyrant s belt
14839	tyrant s greaves
14840	tyrant s legplates
14841	tyrant s epaulets
14842	tyrant s shield
14843	tyrant s helm
14844	sunscale chestguard
14846	sunscale gauntlets
14847	sunscale belt
14848	sunscale sabatons
14849	sunscale helmet
14850	sunscale legplates
14851	sunscale spaulders
14852	sunscale shield
14853	sunscale wristguards
14854	vanguard breastplate
14855	vanguard gauntlets
14856	vanguard girdle
14857	vanguard sabatons
14858	vanguard headdress
14859	vanguard legplates
14860	vanguard pauldrons
14861	vanguard vambraces
14862	warleader s breastplate
14863	warleader s gauntlets
14864	warleader s belt
14865	warleader s greaves
14866	warleader s crown
14867	warleader s leggings
14868	warleader s shoulders
14869	warleader s bracers
14872	tirion s gift
14894	lily root
14895	saltstone surcoat
14896	saltstone sabatons
14897	saltstone gauntlets
14898	saltstone girdle
14899	saltstone helm
14900	saltstone legplates
14901	saltstone shoulder pads
14902	saltstone shield
14903	saltstone armsplints
14904	brutish breastplate
14905	brutish gauntlets
14906	brutish belt
14907	brutish helmet
14908	brutish legguards
14909	brutish shoulders
14910	brutish armguards
14911	brutish boots
14912	brutish shield
14913	jade greaves
14914	jade bracers
14915	jade breastplate
14916	jade deflector
14917	jade gauntlets
14918	jade belt
14919	jade circlet
14920	jade legplates
14921	jade epaulets
14922	lofty sabatons
14923	lofty armguards
14924	lofty breastplate
14925	lofty helm
14926	lofty gauntlets
14927	lofty belt
14928	lofty legguards
14929	lofty shoulder pads
14930	lofty shield
14931	heroic armor
14932	heroic greaves
14933	heroic gauntlets
14934	heroic girdle
14935	heroic skullcap
14936	heroic legplates
14937	heroic pauldrons
14938	heroic bracers
14939	warbringer s chestguard
14940	warbringer s sabatons
14941	warbringer s armsplints
14942	warbringer s gauntlets
14943	warbringer s belt
14944	warbringer s crown
14945	warbringer s legguards
14946	warbringer s spaulders
14947	warbringer s shield
14948	bloodforged chestpiece
14949	bloodforged gauntlets
14950	bloodforged belt
14951	bloodforged sabatons
14952	bloodforged helmet
14953	bloodforged legplates
14954	bloodforged shield
14955	bloodforged shoulder pads
14956	bloodforged bindings
14957	high chief s sabatons
14958	high chief s armor
14959	high chief s gauntlets
14960	high chief s belt
14961	high chief s crown
14962	high chief s legguards
14963	high chief s pauldrons
14964	high chief s shield
14965	high chief s bindings
14966	glorious breastplate
14967	glorious gauntlets
14968	glorious belt
14969	glorious headdress
14970	glorious legplates
14971	glorious shoulder pads
14972	glorious sabatons
14973	glorious shield
14974	glorious bindings
14975	exalted harness
14976	exalted gauntlets
14977	exalted girdle
14978	exalted sabatons
14979	exalted helmet
14980	exalted legplates
14981	exalted epaulets
14982	exalted shield
14983	exalted armsplints
15002	nimboya s pike
15003	primal belt
15004	primal boots
15005	primal bands
15006	primal buckler
15007	primal cape
15008	primal mitts
15009	primal leggings
15010	primal wraps
15011	lupine cord
15012	lupine slippers
15013	lupine cuffs
15014	lupine buckler
15015	lupine cloak
15016	lupine handwraps
15017	lupine leggings
15018	lupine vest
15019	lupine mantle
15042	empty termite jar
15043	plagueland termites
15044	barrel of plagueland termites
15045	green dragonscale breastplate
15046	green dragonscale leggings
15047	red dragonscale breastplate
15048	blue dragonscale breastplate
15049	blue dragonscale shoulders
15050	black dragonscale breastplate
15051	black dragonscale shoulders
15052	black dragonscale leggings
15053	volcanic breastplate
15054	volcanic leggings
15055	volcanic shoulders
15056	stormshroud armor
15057	stormshroud pants
15058	stormshroud shoulders
15059	living breastplate
15060	living leggings
15061	living shoulders
15062	devilsaur leggings
15063	devilsaur gauntlets
15064	warbear harness
15065	warbear woolies
15066	ironfeather breastplate
15067	ironfeather shoulders
15068	frostsaber tunic
15069	frostsaber leggings
15070	frostsaber gloves
15071	frostsaber boots
15072	chimeric leggings
15073	chimeric boots
15074	chimeric gloves
15075	chimeric vest
15076	heavy scorpid vest
15077	heavy scorpid bracers
15078	heavy scorpid gauntlet
15079	heavy scorpid leggings
15080	heavy scorpid helm
15081	heavy scorpid shoulders
15082	heavy scorpid belt
15083	wicked leather gauntlets
15084	wicked leather bracers
15085	wicked leather armor
15086	wicked leather headband
15087	wicked leather pants
15088	wicked leather belt
15090	runic leather armor
15091	runic leather gauntlets
15092	runic leather bracers
15093	runic leather belt
15094	runic leather headband
15095	runic leather pants
15096	runic leather shoulders
15102	un goro tested sample
15103	corrupt tested sample
15104	wingborne boots
15105	staff of noh orahil
15106	staff of dar orahil
15107	orb of noh orahil
15108	orb of dar orahil
15109	staff of soran ruk
15110	rigid belt
15111	rigid moccasins
15112	rigid bracelets
15113	rigid buckler
15114	rigid cape
15115	rigid gloves
15116	rigid shoulders
15117	rigid leggings
15118	rigid tunic
15119	highborne pants
15120	robust girdle
15121	robust boots
15122	robust bracers
15123	robust buckler
15124	robust cloak
15125	robust gloves
15126	robust leggings
15127	robust shoulders
15128	robust tunic
15129	robust helm
15130	cutthroat s vest
15131	cutthroat s boots
15132	cutthroat s armguards
15133	cutthroat s buckler
15134	cutthroat s hat
15135	cutthroat s cape
15136	cutthroat s belt
15137	cutthroat s mitts
15138	onyxia scale cloak
15139	cutthroat s pants
15140	cutthroat s mantle
15141	onyxia scale breastplate
15142	ghostwalker boots
15143	ghostwalker bindings
15144	ghostwalker rags
15145	ghostwalker buckler
15146	ghostwalker crown
15147	ghostwalker cloak
15148	ghostwalker belt
15149	ghostwalker gloves
15150	ghostwalker pads
15151	ghostwalker legguards
15152	nocturnal shoes
15153	nocturnal cloak
15154	nocturnal sash
15155	nocturnal gloves
15156	nocturnal cap
15157	nocturnal leggings
15158	nocturnal shoulder pads
15159	nocturnal tunic
15160	nocturnal wristbands
15161	imposing belt
15162	imposing boots
15163	imposing bracers
15164	imposing vest
15165	imposing cape
15166	imposing gloves
15167	imposing bandana
15168	imposing pants
15169	imposing shoulders
15170	potent armor
15171	potent boots
15172	potent bands
15173	potent cape
15174	potent gloves
15175	potent helmet
15176	potent pants
15177	potent shoulders
15178	potent belt
15179	praetorian padded armor
15180	praetorian girdle
15181	praetorian boots
15182	praetorian wristbands
15183	praetorian cloak
15184	praetorian gloves
15185	praetorian coif
15186	praetorian leggings
15187	praetorian pauldrons
15188	grand armguards
15189	grand boots
15190	grand cloak
15191	grand belt
15192	grand gauntlets
15193	grand crown
15194	grand legguards
15195	grand breastplate
15196	private s tabard
15197	scout s tabard
15198	knight s colors
15199	stone guard s herald
15200	senior sergeant s insignia
15202	wildkeeper leggings
15203	guststorm legguards
15204	moonstone wand
15205	owlsight rifle
15206	jadefinger baton
15207	steelcap shield
15208	cenarion moondust
15209	relic bundle
15210	raider shortsword
15211	militant shortsword
15212	fighter broadsword
15213	mercenary blade
15214	nobles brand
15215	furious falchion
15216	rune sword
15217	widow blade
15218	crystal sword
15219	dimensional blade
15220	battlefell sabre
15221	holy war sword
15222	barbed club
15223	jagged star
15224	battlesmasher
15225	sequoia hammer
15226	giant club
15227	diamond tip bludgeon
15228	smashing star
15229	blesswind hammer
15230	ridge cleaver
15231	splitting hatchet
15232	hacking cleaver
15233	savage axe
15234	greater scythe
15235	crescent edge
15236	moon cleaver
15237	corpse harvester
15238	warlord s axe
15239	felstone reaver
15240	demon s claw
15241	battle knife
15242	honed stiletto
15243	deadly kris
15244	razor blade
15245	vorpal dagger
15246	demon blade
15247	bloodstrike dagger
15248	gleaming claymore
15249	polished zweihander
15250	glimmering flamberge
15251	headstriker sword
15252	tusker sword
15253	beheading blade
15254	dark espadon
15255	gallant flamberge
15256	massacre sword
15257	shin blade
15258	divine warblade
15259	hefty battlehammer
15260	stone hammer
15261	sequoia branch
15262	greater maul
15263	royal mallet
15264	backbreaker
15265	painbringer
15266	fierce mauler
15267	brutehammer
15268	twin bladed axe
15269	massive battle axe
15270	gigantic war axe
15271	colossal great axe
15272	razor axe
15273	death striker
15274	diviner long staff
15275	thaumaturgist staff
15276	magus long staff
15277	gray kodo
15278	solstice staff
15279	ivory wand
15280	wizard s hand
15281	glowstar rod
15282	dragon finger
15283	lunar wand
15284	long battle bow
15285	archer s longbow
15286	long redwood bow
15287	crusader bow
15288	blasthorn bow
15289	archstrike bow
15290	brown kodo
15291	harpy needler
15292	green kodo
15293	teal kodo
15294	siege bow
15295	quillfire bow
15296	hawkeye bow
15297	grizzly bracers
15298	grizzly buckler
15299	grizzly cape
15300	grizzly gloves
15301	grizzly slippers
15302	grizzly belt
15303	grizzly pants
15304	grizzly jerkin
15305	feral shoes
15306	feral bindings
15307	feral buckler
15308	feral cord
15309	feral cloak
15310	feral gloves
15311	feral harness
15312	feral leggings
15313	feral shoulder pads
15314	bundle of relics
15322	smoothbore gun
15323	percussion shotgun
15324	burnside rifle
15325	sharpshooter harquebus
15326	broken gleaming throwing axe
15327	broken wicked throwing dagger
15328	joseph s key
15329	wrangler s belt
15330	wrangler s boots
15331	wrangler s wristbands
15332	wrangler s buckler
15333	wrangler s cloak
15334	wrangler s gloves
15335	briarsteel shortsword
15336	wrangler s leggings
15337	wrangler s wraps
15338	wrangler s mantle
15339	pathfinder hat
15340	pathfinder cloak
15341	pathfinder footpads
15342	pathfinder guard
15343	pathfinder gloves
15344	pathfinder pants
15345	pathfinder shoulder pads
15346	pathfinder vest
15347	pathfinder belt
15348	pathfinder bracers
15349	headhunter s belt
15350	headhunter s slippers
15351	headhunter s bands
15352	headhunter s buckler
15353	headhunter s headdress
15354	headhunter s cloak
15355	headhunter s mitts
15356	headhunter s armor
15357	headhunter s spaulders
15358	headhunter s woolies
15359	trickster s vest
15360	trickster s bindings
15361	trickster s sash
15362	trickster s boots
15363	trickster s headdress
15364	trickster s cloak
15365	trickster s handwraps
15366	trickster s leggings
15367	trickster s protector
15368	trickster s pauldrons
15369	wolf rider s belt
15370	wolf rider s boots
15371	wolf rider s cloak
15372	wolf rider s gloves
15373	wolf rider s headgear
15374	wolf rider s leggings
15375	wolf rider s shoulder pads
15376	wolf rider s padded armor
15377	wolf rider s wristbands
15378	rageclaw belt
15379	rageclaw boots
15380	rageclaw bracers
15381	rageclaw chestguard
15382	rageclaw cloak
15383	rageclaw gloves
15384	rageclaw helm
15385	rageclaw leggings
15386	rageclaw shoulder pads
15387	jadefire bracelets
15388	jadefire belt
15389	jadefire sabatons
15390	jadefire chestguard
15391	jadefire cap
15392	jadefire cloak
15393	jadefire gloves
15394	jadefire pants
15395	jadefire epaulets
15396	curvewood dagger
15397	oakthrush staff
15398	sandcomber boots
15399	dryweed belt
15400	clamshell bracers
15401	welldrip gloves
15402	noosegrip gauntlets
15403	ridgeback bracers
15404	breakwater girdle
15405	shucking gloves
15406	crustacean boots
15407	cured rugged hide
15408	heavy scorpid scale
15409	refined deeprock salt
15410	scale of onyxia
15411	mark of fordring
15412	green dragonscale
15413	ornate adamantium breastplate
15414	red dragonscale
15415	blue dragonscale
15416	black dragonscale
15417	devilsaur leather
15418	shimmering platinum warhammer
15419	warbear leather
15420	ironfeather
15421	shroud of the exile
15422	frostsaber leather
15423	chimera leather
15424	axe of orgrimmar
15425	peerless bracers
15426	peerless boots
15427	peerless cloak
15428	peerless belt
15429	peerless gloves
15430	peerless headband
15431	peerless leggings
15432	peerless shoulders
15433	peerless armor
15434	supreme sash
15435	supreme shoes
15436	supreme bracers
15437	supreme cape
15438	supreme gloves
15439	supreme crown
15440	supreme leggings
15441	supreme shoulders
15442	supreme breastplate
15443	kris of orgrimmar
15444	staff of orgrimmar
15445	hammer of orgrimmar
15446	stormwind deputy kit
15447	living rot
15448	coagulated rot
15449	ghastly trousers
15450	dredgemire leggings
15451	gargoyle leggings
15452	featherbead bracers
15453	savannah bracers
15454	mortar and pestle
15455	dustfall robes
15456	lightstep leggings
15457	desert shoulders
15458	tundra boots
15459	grimtoll wristguards
15461	lightheel boots
15462	loamflake bracers
15463	palestrider gloves
15464	brute hammer
15465	stingshot wand
15466	clink shield
15467	inventor s league ring
15468	windsong drape
15469	windsong cinch
15470	plainsguard leggings
15471	brawnhide armor
15472	charger s belt
15473	charger s boots
15474	charger s bindings
15475	charger s cloak
15476	charger s handwraps
15477	charger s pants
15478	charger s shield
15479	charger s armor
15480	war torn girdle
15481	war torn greaves
15482	war torn bands
15483	war torn cape
15484	war torn handgrips
15485	war torn pants
15486	war torn shield
15487	war torn tunic
15488	bloodspattered surcoat
15489	bloodspattered sabatons
15490	bloodspattered cloak
15491	bloodspattered gloves
15492	bloodspattered sash
15493	bloodspattered loincloth
15494	bloodspattered shield
15495	bloodspattered wristbands
15496	bloodspattered shoulder pads
15497	outrunner s cord
15498	outrunner s slippers
15499	outrunner s cuffs
15500	outrunner s chestguard
15501	outrunner s cloak
15502	outrunner s gloves
15503	outrunner s legguards
15504	outrunner s shield
15505	outrunner s pauldrons
15506	grunt s anklewraps
15507	grunt s bracers
15508	grunt s cape
15509	grunt s handwraps
15510	grunt s belt
15511	grunt s legguards
15512	grunt s shield
15513	grunt s pauldrons
15514	grunt s chestpiece
15515	spiked chain belt
15516	spiked chain slippers
15517	spiked chain wristbands
15518	spiked chain breastplate
15519	spiked chain cloak
15520	spiked chain gauntlets
15521	spiked chain leggings
15522	spiked chain shield
15523	spiked chain shoulder pads
15524	sentry s surcoat
15525	sentry s slippers
15526	sentry s cape
15527	sentry s gloves
15528	sentry s sash
15529	sentry s leggings
15530	sentry s shield
15531	sentry s shoulderguards
15532	sentry s armsplints
15533	sentry s headdress
15534	wicked chain boots
15535	wicked chain bracers
15536	wicked chain chestpiece
15537	wicked chain cloak
15538	wicked chain gauntlets
15539	wicked chain waistband
15540	wicked chain helmet
15541	wicked chain legguards
15542	wicked chain shoulder pads
15543	wicked chain shield
15544	thick scale sabatons
15545	thick scale bracelets
15546	thick scale breastplate
15547	thick scale cloak
15548	thick scale gauntlets
15549	thick scale belt
15550	thick scale crown
15551	thick scale legguards
15552	thick scale shield
15553	thick scale shoulder pads
15554	pillager s girdle
15555	pillager s boots
15556	pillager s bracers
15557	pillager s chestguard
15558	pillager s crown
15559	pillager s cloak
15560	pillager s gloves
15561	pillager s leggings
15562	pillager s pauldrons
15563	pillager s shield
15564	rugged armor kit
15565	marauder s boots
15566	marauder s bracers
15567	marauder s tunic
15568	marauder s cloak
15569	marauder s crest
15570	marauder s gauntlets
15571	marauder s belt
15572	marauder s circlet
15573	marauder s leggings
15574	marauder s shoulder pads
15575	sparkleshell belt
15576	sparkleshell sabatons
15577	sparkleshell bracers
15578	sparkleshell breastplate
15579	sparkleshell cloak
15580	sparkleshell headwrap
15581	sparkleshell gauntlets
15582	sparkleshell legguards
15583	sparkleshell shoulder pads
15584	sparkleshell shield
15585	pardoc grips
15586	fast growing flower
15587	ringtail girdle
15588	bracesteel belt
15589	steadfast stompers
15590	steadfast bracelets
15591	steadfast breastplate
15592	steadfast buckler
15593	steadfast coronet
15594	steadfast cloak
15595	steadfast gloves
15596	steadfast legplates
15597	steadfast shoulders
15598	steadfast girdle
15599	ancient greaves
15600	ancient vambraces
15601	ancient chestpiece
15602	ancient crown
15603	ancient cloak
15604	ancient defender
15605	ancient gauntlets
15606	ancient belt
15607	ancient legguards
15608	ancient pauldrons
15609	bonelink armor
15610	bonelink bracers
15611	bonelink cape
15612	bonelink gauntlets
15613	bonelink belt
15614	bonelink sabatons
15615	bonelink helmet
15616	bonelink legplates
15617	bonelink epaulets
15618	bonelink wall shield
15619	gryphon mail belt
15620	gryphon mail bracelets
15621	gryphon mail buckler
15622	gryphon mail breastplate
15623	gryphon mail crown
15624	gryphon cloak
15625	gryphon mail gauntlets
15626	gryphon mail greaves
15627	gryphon mail legguards
15628	gryphon mail pauldrons
15629	formidable bracers
15630	formidable sabatons
15631	formidable chestpiece
15632	formidable cape
15633	formidable crest
15634	formidable circlet
15635	formidable gauntlets
15636	formidable belt
15637	formidable legguards
15638	formidable shoulder pads
15639	ironhide bracers
15640	ironhide breastplate
15641	ironhide belt
15642	ironhide greaves
15643	ironhide cloak
15644	ironhide gauntlets
15645	ironhide helmet
15646	ironhide legguards
15647	ironhide pauldrons
15648	ironhide shield
15649	merciless bracers
15650	merciless surcoat
15651	merciless crown
15652	merciless cloak
15653	merciless gauntlets
15654	merciless belt
15655	merciless legguards
15656	merciless epaulets
15657	merciless shield
15658	impenetrable sabatons
15659	impenetrable bindings
15660	impenetrable breastplate
15661	impenetrable cloak
15662	impenetrable gauntlets
15663	impenetrable belt
15664	impenetrable helmet
15665	impenetrable legguards
15666	impenetrable pauldrons
15667	impenetrable wall
15668	magnificent bracers
15669	magnificent breastplate
15670	magnificent helmet
15671	magnificent cloak
15672	magnificent gauntlets
15673	magnificent belt
15674	magnificent greaves
15675	magnificent guard
15676	magnificent leggings
15677	magnificent shoulders
15678	triumphant sabatons
15679	triumphant bracers
15680	triumphant chestpiece
15681	triumphant cloak
15682	triumphant gauntlets
15683	triumphant girdle
15684	triumphant skullcap
15685	triumphant legplates
15686	triumphant shoulder pads
15687	triumphant shield
15688	magic beans
15689	trader s ring
15690	kodobone necklace
15691	sidegunner shottie
15692	kodo brander
15693	grand shoulders
15694	merciless greaves
15695	studded ring shield
15696	ruined tome
15697	kodo rustler boots
15698	wrangling spaulders
15699	small brown wrapped package
15702	chemist s ring
15703	chemist s smock
15704	hunter s insignia medal
15705	tidecrest blade
15706	hunt tracker blade
15707	brantwood sash
15708	blight leather gloves
15709	gearforge girdle
15710	cenarion lunardust
15722	spraggle s canteen
15723	tea with sugar
15724	pattern heavy scorpid bracers
15725	pattern wicked leather gauntlets
15726	pattern green dragonscale breastplate
15727	pattern heavy scorpid vest
15728	pattern wicked leather bracers
15729	pattern chimeric gloves
15730	pattern red dragonscale breastplate
15731	pattern runic leather gauntlets
15732	pattern volcanic leggings
15733	pattern green dragonscale leggings
15734	pattern living shoulders
15735	pattern ironfeather shoulders
15736	smokey s special compound
15737	pattern chimeric boots
15738	pattern heavy scorpid gauntlets
15739	pattern runic leather bracers
15740	pattern frostsaber boots
15741	pattern stormshroud pants
15742	pattern warbear harness
15743	pattern heavy scorpid belt
15744	pattern wicked leather headband
15745	pattern runic leather belt
15746	pattern chimeric leggings
15747	pattern frostsaber leggings
15748	pattern heavy scorpid leggings
15749	pattern volcanic breastplate
15750	sceptre of light
15751	pattern blue dragonscale breastplate
15752	pattern living leggings
15753	pattern stormshroud armor
15754	pattern warbear woolies
15755	pattern chimeric vest
15756	pattern runic leather headband
15757	pattern wicked leather pants
15758	pattern devilsaur gauntlets
15759	pattern black dragonscale breastplate
15760	pattern ironfeather breastplate
15761	pattern frostsaber gloves
15762	pattern heavy scorpid helm
15763	pattern blue dragonscale shoulders
15764	pattern stormshroud shoulders
15765	pattern runic leather pants
15766	gem of the serpent
15767	hameya s key
15768	pattern wicked leather belt
15769	pattern onyxia scale cloak
15770	pattern black dragonscale shoulders
15771	pattern living breastplate
15772	pattern devilsaur leggings
15773	pattern wicked leather armor
15774	pattern heavy scorpid shoulders
15775	pattern volcanic shoulders
15776	pattern runic leather armor
15777	pattern runic leather shoulders
15778	mechanical yeti
15779	pattern frostsaber tunic
15780	pattern onyxia scale breastplate
15781	pattern black dragonscale leggings
15782	beaststalker blade
15783	beasthunter dagger
15784	crystal breeze mantle
15785	zaeldarr s head
15786	fernpulse jerkin
15787	willow band hauberk
15788	everlook report
15789	deep river cloak
15790	studies in spirit speaking
15791	turquoise sash
15792	plow wood spaulders
15793	a chewed bone
15794	ripped ogre loincloth
15795	emerald mist gauntlets
15796	seaspray bracers
15797	shining armplates
15798	chipped ogre teeth
15799	heroic commendation medal
15800	intrepid shortsword
15801	valiant shortsword
15802	mooncloth boots
15803	book of the ancients
15804	cerise drape
15805	penelope s rose
15806	mirah s song
15807	light crossbow
15808	fine light crossbow
15809	heavy crossbow
15810	short spear
15811	heavy spear
15812	orchid amice
15813	gold link belt
15814	hameya s slayer
15815	hameya s cloak
15822	shadowskin spaulders
15823	bricksteel gauntlets
15824	astoria robes
15825	traphook jerkin
15826	curative animal salve
15827	jadescale breastplate
15842	empty dreadmist peak sampler
15843	filled dreadmist peak sampler
15844	empty cliffspring falls sampler
15845	filled cliffspring falls sampler
15846	salt shaker
15847	quel thalas registry
15848	crate of ghost magnets
15849	ghost o plasm
15850	patch of duskwing s fur
15851	lunar fungus
15852	kodo horn
15853	windreaper
15854	dancing sliver
15855	ring of protection
15856	archlight talisman
15857	magebane scion
15858	freewind gloves
15859	seapost girdle
15860	blinkstrike armguards
15861	swiftfoot treads
15862	blitzcleaver
15863	grave scepter
15864	condor bracers
15865	anchorhold buckler
15866	veildust medicine bag
15867	prismcharm
15868	the grand crusader s command
15869	silver skeleton key
15870	golden skeleton key
15871	truesilver skeleton key
15872	arcanite skeleton key
15873	ragged john s neverending cup
15874	soft shelled clam
15875	rotten apple
15876	nathanos chest
15877	shrine bauble
15878	rackmore s silver key
15879	overlord ror s claw
15880	head of ramstein the gorger
15881	rackmore s golden key
15882	half pendant of aquatic endurance
15883	half pendant of aquatic agility
15884	augustus receipt book
15885	pendant of the sea lion
15886	timolain s phylactery
15887	heroic guard
15890	vanguard shield
15891	hulking shield
15892	slayer s shield
15893	prospector s buckler
15894	bristlebark buckler
15895	burnt buckler
15902	a crazy grab bag
15903	right handed claw
15904	right handed blades
15905	right handed brass knuckles
15906	left handed brass knuckles
15907	left handed claw
15908	taming rod
15909	left handed blades
15911	taming rod
15912	buccaneer s orb
15913	taming rod
15914	taming rod
15915	taming rod
15916	taming rod
15917	taming rod
15918	conjurer s sphere
15919	taming rod
15920	taming rod
15921	taming rod
15922	taming rod
15923	taming rod
15924	soft shelled clam meat
15925	journeyman s stave
15926	spellbinder orb
15927	bright sphere
15928	silver thread rod
15929	nightsky orb
15930	imperial red scepter
15931	arcane star
15932	disciple s stein
15933	simple branch
15934	sage s stave
15935	durable rod
15936	duskwoven branch
15937	hibernal sphere
15938	mystical orb
15939	councillor s scepter
15940	elegant scepter
15941	high councillor s scepter
15942	master s rod
15943	imbued shield
15944	ancestral orb
15945	runic stave
15946	mystic s sphere
15947	sanguine star
15962	satyr s rod
15963	stonecloth branch
15964	silksand star
15965	windchaser orb
15966	venomshroud orb
15967	highborne star
15968	elunarian sphere
15969	beaded orb
15970	native branch
15971	aboriginal rod
15972	ritual stein
15973	watcher s star
15974	pagan rod
15975	raincaller scepter
15976	thistlefur branch
15977	vital orb
15978	geomancer s rod
15979	embersilk stave
15980	darkmist orb
15981	lunar sphere
15982	bloodwoven rod
15983	gaea s scepter
15984	opulent scepter
15985	arachnidian branch
15986	bonecaster s star
15987	astral orb
15988	resplendent orb
15989	eternal rod
15990	enduring shield
15991	warleader s shield
15992	dense blasting powder
15993	thorium grenade
15994	thorium widget
15995	thorium rifle
15996	lifelike mechanical toad
15997	thorium shells
15998	lewis note
15999	spellpower goggles xtreme plus
16000	thorium tube
16001	si 7 insignia fredo
16002	si 7 insignia turyen
16003	si 7 insignia rutger
16004	dark iron rifle
16005	dark iron bomb
16006	delicate arcanite converter
16007	flawless arcanite rifle
16008	master engineer s goggles
16009	voice amplification modulator
16022	arcanite dragonling
16023	masterwork target dummy
16026	pvp plate helm alliance
16027	pvp plate breastplate alliance
16028	pvp plate legplates alliance
16029	pvp plate gauntlets alliance
16030	pvp plate boots alliance
16031	pvp plate shoulder alliance
16033	pvp plate wrist alliance
16034	pvp plate cloak alliance
16035	pvp cloth helm horde
16036	pvp cloth robe horde
16037	pvp cloth legs horde
16038	pvp cloth shoulder horde
16039	ta kierthan songblade
16040	arcane bomb
16041	schematic thorium grenade
16042	schematic thorium widget
16043	schematic thorium rifle
16044	schematic lifelike mechanical toad
16045	schematic spellpower goggles xtreme plus
16046	schematic masterwork target dummy
16047	schematic thorium tube
16048	schematic dark iron rifle
16049	schematic dark iron bomb
16050	schematic delicate arcanite converter
16051	schematic thorium shells
16052	schematic voice amplification modulator
16053	schematic master engineer s goggles
16054	schematic arcanite dragonling
16055	schematic arcane bomb
16056	schematic flawless arcanite rifle
16057	explorer s knapsack
16058	fordring s seal
16059	common brown shirt
16060	common white shirt
16072	expert cookbook
16073	artisan cookbook
16082	artisan fishing the way of the lure
16083	expert fishing the bass and you
16084	expert first aid under wraps
16085	artisan first aid heal thyself
16110	recipe monster omelet
16111	recipe spiced chili crab
16112	manual heavy silk bandage
16113	manual mageweave bandage
16114	foreman s blackjack
16115	osric s crate
16166	bean soup
16167	versicolor treat
16168	heaven peach
16169	wild ricecake
16170	steamed mandu
16171	shinsollo
16189	maggran s reserve letter
16190	bloodfury ripper s remains
16191	ornate mirror
16192	besseleth s fang
16202	lesser eternal essence
16203	greater eternal essence
16204	illusion dust
16205	gaea seed
16206	arcanite rod
16207	runed arcanite rod
16208	enchanted gaea seeds
16209	podrig s order
16210	gordon s crate
16214	formula enchant bracer greater intellect
16215	formula enchant boots greater stamina
16216	formula enchant cloak greater resistance
16217	formula enchant shield greater stamina
16218	formula enchant bracer superior spirit
16219	formula enchant gloves greater agility
16220	formula enchant boots spirit
16221	formula enchant chest major health
16222	formula enchant shield superior spirit
16223	formula enchant weapon icy chill
16224	formula enchant cloak superior defense
16242	formula enchant chest major mana
16243	formula runed arcanite rod
16244	formula enchant gloves greater strength
16245	formula enchant boots greater agility
16246	formula enchant bracer superior strength
16247	formula enchant 2h weapon superior impact
16248	formula enchant weapon unholy
16249	formula enchant 2h weapon major intellect
16250	formula enchant weapon superior striking
16251	formula enchant bracer superior stamina
16252	formula enchant weapon crusader
16253	formula enchant chest greater stats
16254	formula enchant weapon lifestealing
16255	formula enchant 2h weapon major spirit
16262	nessa s collection
16263	laird s response
16282	bundle of hides
16283	ahanu s leather goods
16302	grimoire of firebolt rank 2
16303	ursangous s paw
16304	shadumbra s head
16305	sharptalon s claw
16306	zargh s meats
16307	gryshka s letter
16308	northridge crowbar
16309	drakefire amulet
16310	brock s list
16311	honorary picks
16312	incendrites
16313	felix s chest
16314	felix s bucket of bolts
16315	sergeant major s cape
16316	grimoire of firebolt rank 3
16317	grimoire of firebolt rank 4
16318	grimoire of firebolt rank 5
16319	grimoire of firebolt rank 6
16320	grimoire of firebolt rank 7
16321	grimoire of blood pact rank 1
16322	grimoire of blood pact rank 2
16323	grimoire of blood pact rank 3
16324	grimoire of blood pact rank 4
16325	grimoire of blood pact rank 5
16326	grimoire of fire shield rank 1
16327	grimoire of fire shield rank 2
16328	grimoire of fire shield rank 3
16329	grimoire of fire shield rank 4
16330	grimoire of fire shield rank 5
16331	grimoire of phase shift
16332	thazz ril s pick
16333	samuel s remains
16334	sergeant s insignia
16335	senior sergeant s insignia
16336	sergeant major s cape
16337	sergeant major s cape
16338	knight lieutenant s steed
16339	commander s steed
16340	first sergeant s cloak
16341	sergeant s cloak
16342	sergeant s cape
16343	blood guard s mount
16344	zzunusedlieutenant general s mount
16345	high warlord s blade
16346	grimoire of torment rank 2
16347	grimoire of torment rank 3
16348	grimoire of torment rank 4
16349	grimoire of torment rank 5
16350	grimoire of torment rank 6
16351	grimoire of sacrifice rank 1
16352	grimoire of sacrifice rank 2
16353	grimoire of sacrifice rank 3
16354	grimoire of sacrifice rank 4
16355	grimoire of sacrifice rank 5
16356	grimoire of sacrifice rank 6
16357	grimoire of consume shadows rank 1
16358	grimoire of consume shadows rank 2
16359	grimoire of consume shadows rank 3
16360	grimoire of consume shadows rank 4
16361	grimoire of consume shadows rank 5
16362	grimoire of consume shadows rank 6
16363	grimoire of suffering rank 1
16364	grimoire of suffering rank 2
16365	grimoire of suffering rank 3
16366	grimoire of suffering rank 4
16368	grimoire of lash of pain rank 2
16369	knight lieutenant s silk boots
16371	grimoire of lash of pain rank 3
16372	grimoire of lash of pain rank 4
16373	grimoire of lash of pain rank 5
16374	grimoire of lash of pain rank 6
16375	grimoire of soothing kiss rank 1
16376	grimoire of soothing kiss rank 2
16377	grimoire of soothing kiss rank 3
16378	grimoire of soothing kiss rank 4
16379	grimoire of seduction
16380	grimoire of lesser invisibility
16381	grimoire of devour magic rank 2
16382	grimoire of devour magic rank 3
16383	grimoire of devour magic rank 4
16384	grimoire of tainted blood rank 1
16385	grimoire of tainted blood rank 2
16386	grimoire of tainted blood rank 3
16387	grimoire of tainted blood rank 4
16388	grimoire of spell lock rank 1
16389	grimoire of spell lock rank 2
16390	grimoire of paranoia
16391	knight lieutenant s silk gloves
16392	knight lieutenant s leather boots
16393	knight lieutenant s dragonhide footwraps
16396	knight lieutenant s leather gauntlets
16397	knight lieutenant s dragonhide gloves
16401	knight lieutenant s chain boots
16403	knight lieutenant s chain gauntlets
16405	knight lieutenant s plate boots
16406	knight lieutenant s plate gauntlets
16408	befouled water globe
16409	knight lieutenant s lamellar sabatons
16410	knight lieutenant s lamellar gauntlets
16413	knight captain s silk raiment
16414	knight captain s silk leggings
16415	lieutenant commander s silk spaulders
16416	lieutenant commander s crown
16417	knight captain s leather armor
16418	lieutenant commander s leather veil
16419	knight captain s leather legguards
16420	lieutenant commander s leather spaulders
16421	knight captain s dragonhide tunic
16422	knight captain s dragonhide leggings
16423	lieutenant commander s dragonhide epaulets
16424	lieutenant commander s dragonhide shroud
16425	knight captain s chain hauberk
16426	knight captain s chain leggings
16427	lieutenant commander s chain pauldrons
16428	lieutenant commander s chain helmet
16429	lieutenant commander s plate helm
16430	knight captain s plate chestguard
16431	knight captain s plate leggings
16432	lieutenant commander s plate pauldrons
16433	knight captain s lamellar breastplate
16434	lieutenant commander s lamellar headguard
16435	knight captain s lamellar leggings
16436	lieutenant commander s lamellar shoulders
16437	marshal s silk footwraps
16440	marshal s silk gloves
16441	field marshal s coronet
16442	marshal s silk leggings
16443	field marshal s silk vestments
16444	field marshal s silk spaulders
16446	marshal s leather footguards
16448	marshal s dragonhide gauntlets
16449	field marshal s dragonhide spaulders
16450	marshal s dragonhide legguards
16451	field marshal s dragonhide helmet
16452	field marshal s dragonhide breastplate
16453	field marshal s leather chestpiece
16454	marshal s leather handgrips
16455	field marshal s leather mask
16456	marshal s leather leggings
16457	field marshal s leather epaulets
16459	marshal s dragonhide boots
16462	marshal s chain boots
16463	marshal s chain grips
16465	field marshal s chain helm
16466	field marshal s chain breastplate
16467	marshal s chain legguards
16468	field marshal s chain spaulders
16471	marshal s lamellar gloves
16472	marshal s lamellar boots
16473	field marshal s lamellar chestplate
16474	field marshal s lamellar faceguard
16475	marshal s lamellar legplates
16476	field marshal s lamellar pauldrons
16477	field marshal s plate armor
16478	field marshal s plate helm
16479	marshal s plate legguards
16480	field marshal s plate shoulderguards
16483	marshal s plate boots
16484	marshal s plate gauntlets
16485	blood guard s silk footwraps
16486	first sergeant s silk cuffs
16487	blood guard s silk gloves
16489	champion s silk hood
16490	legionnaire s silk pants
16491	legionnaire s silk robes
16492	champion s silk shoulderpads
16494	blood guard s dragonhide boots
16496	blood guard s dragonhide gauntlets
16497	first sergeant s leather armguards
16498	blood guard s leather treads
16499	blood guard s leather vices
16501	champion s dragonhide spaulders
16502	legionnaire s dragonhide trousers
16503	champion s dragonhide helm
16504	legionnaire s dragonhide breastplate
16505	legionnaire s leather hauberk
16506	champion s leather headguard
16507	champion s leather mantle
16508	legionnaire s leather leggings
16509	blood guard s plate boots
16510	blood guard s plate gloves
16513	legionnaire s plate armor
16514	champion s plate headguard
16515	legionnaire s plate legguards
16516	champion s plate pauldrons
16518	blood guard s mail walkers
16519	blood guard s mail grips
16521	champion s mail helm
16522	legionnaire s mail chestpiece
16523	legionnaire s mail leggings
16524	champion s mail shoulders
16525	legionnaire s chain breastplate
16526	champion s chain headguard
16527	legionnaire s chain leggings
16528	champion s chain pauldrons
16530	blood guard s chain gauntlets
16531	blood guard s chain boots
16532	first sergeant s mail wristguards
16533	warlord s silk cowl
16534	general s silk trousers
16535	warlord s silk raiment
16536	warlord s silk amice
16539	general s silk boots
16540	general s silk handguards
16541	warlord s plate armor
16542	warlord s plate headpiece
16543	general s plate leggings
16544	warlord s plate shoulders
16545	general s plate boots
16548	general s plate gauntlets
16549	warlord s dragonhide hauberk
16550	warlord s dragonhide helmet
16551	warlord s dragonhide epaulets
16552	general s dragonhide leggings
16554	general s dragonhide boots
16555	general s dragonhide gloves
16558	general s leather treads
16560	general s leather mitts
16561	warlord s leather helm
16562	warlord s leather spaulders
16563	warlord s leather breastplate
16564	general s leather legguards
16565	warlord s chain chestpiece
16566	warlord s chain helmet
16567	general s chain legguards
16568	warlord s chain shoulders
16569	general s chain boots
16571	general s chain gloves
16573	general s mail boots
16574	general s mail gauntlets
16577	warlord s mail armor
16578	warlord s mail helm
16579	general s mail leggings
16580	warlord s mail spaulders
16581	resonite crystal
16583	demonic figurine
16602	troll charm
16603	enchanted resonite crystal
16604	moon robes of elune
16605	friar s robes of the light
16606	juju hex robes
16607	acolyte s sacrificial robes
16608	aquarius belt
16622	thornflinger
16623	opaline medallion
16642	shredder operating manual chapter 1
16643	shredder operating manual chapter 2
16644	shredder operating manual chapter 3
16645	shredder operating manual page 1
16646	shredder operating manual page 2
16647	shredder operating manual page 3
16648	shredder operating manual page 4
16649	shredder operating manual page 5
16650	shredder operating manual page 6
16651	shredder operating manual page 7
16652	shredder operating manual page 8
16653	shredder operating manual page 9
16654	shredder operating manual page 10
16655	shredder operating manual page 11
16656	shredder operating manual page 12
16658	wildhunter cloak
16659	deftkin belt
16660	driftmire shield
16661	soft willow cape
16662	fragment of the dragon s eye
16663	blood of the black dragon champion
16664	ornate bracers
16665	tome of tranquilizing shot
16666	vest of elements
16667	coif of elements
16668	kilt of elements
16669	pauldrons of elements
16670	boots of elements
16671	bindings of elements
16672	gauntlets of elements
16673	cord of elements
16674	beaststalker s tunic
16675	beaststalker s boots
16676	beaststalker s gloves
16677	beaststalker s cap
16678	beaststalker s pants
16679	beaststalker s mantle
16680	beaststalker s belt
16681	beaststalker s bindings
16682	magister s boots
16683	magister s bindings
16684	magister s gloves
16685	magister s belt
16686	magister s crown
16687	magister s leggings
16688	magister s robes
16689	magister s mantle
16690	devout robe
16691	devout sandals
16692	devout gloves
16693	devout crown
16694	devout skirt
16695	devout mantle
16696	devout belt
16697	devout bracers
16698	dreadmist mask
16699	dreadmist leggings
16700	dreadmist robe
16701	dreadmist mantle
16702	dreadmist belt
16703	dreadmist bracers
16704	dreadmist sandals
16705	dreadmist wraps
16706	wildheart vest
16707	shadowcraft cap
16708	shadowcraft spaulders
16709	shadowcraft pants
16710	shadowcraft bracers
16711	shadowcraft boots
16712	shadowcraft gloves
16713	shadowcraft belt
16714	wildheart bracers
16715	wildheart boots
16716	wildheart belt
16717	wildheart gloves
16718	wildheart spaulders
16719	wildheart kilt
16720	wildheart cowl
16721	shadowcraft tunic
16722	lightforge bracers
16723	lightforge belt
16724	lightforge gauntlets
16725	lightforge boots
16726	lightforge breastplate
16727	lightforge helm
16728	lightforge legplates
16729	lightforge spaulders
16730	breastplate of valor
16731	helm of valor
16732	legplates of valor
16733	spaulders of valor
16734	boots of valor
16735	bracers of valor
16736	belt of valor
16737	gauntlets of valor
16738	witherseed gloves
16739	rugwood mantle
16740	shredder operating gloves
16741	oilrag handwraps
16742	warsong saw blades
16743	logging rope
16744	warsong oil
16745	warsong axe shipment
16746	warsong report
16747	broken lock
16748	padded lining
16762	fathom core
16763	warsong runner update
16764	warsong scout update
16765	warsong outrider update
16766	undermine clam chowder
16767	recipe undermine clam chowder
16768	furbolg medicine pouch
16769	furbolg medicine totem
16782	strange water globe
16783	bundle of reports
16784	sapphire of aku mai
16785	rokaro s letter
16786	black dragonspawn eye
16787	amulet of draconic subversion
16788	captain rackmore s wheel
16789	captain rackmore s tiller
16790	damp note
16791	silkstream cuffs
16792	giant club
16793	arcmetal shoulders
16794	gripsteel wristguards
16795	arcanist crown
16796	arcanist leggings
16797	arcanist mantle
16798	arcanist robes
16799	arcanist bindings
16800	arcanist boots
16801	arcanist gloves
16802	arcanist belt
16803	felheart slippers
16804	felheart bracers
16805	felheart gloves
16806	felheart belt
16807	felheart shoulder pads
16808	felheart horns
16809	felheart robes
16810	felheart pants
16811	boots of prophecy
16812	gloves of prophecy
16813	circlet of prophecy
16814	pants of prophecy
16815	robes of prophecy
16816	mantle of prophecy
16817	girdle of prophecy
16818	netherwind belt
16819	vambraces of prophecy
16820	nightslayer chestpiece
16821	nightslayer cover
16822	nightslayer pants
16823	nightslayer shoulder pads
16824	nightslayer boots
16825	nightslayer bracelets
16826	nightslayer gloves
16827	nightslayer belt
16828	cenarion belt
16829	cenarion boots
16830	cenarion bracers
16831	cenarion gloves
16832	bloodfang spaulders
16833	cenarion vestments
16834	cenarion helm
16835	cenarion leggings
16836	cenarion spaulders
16837	earthfury boots
16838	earthfury belt
16839	earthfury gauntlets
16840	earthfury bracers
16841	earthfury vestments
16842	earthfury helmet
16843	earthfury legguards
16844	earthfury epaulets
16845	giantstalker s breastplate
16846	giantstalker s helmet
16847	giantstalker s leggings
16848	giantstalker s epaulets
16849	giantstalker s boots
16850	giantstalker s bracers
16851	giantstalker s belt
16852	giantstalker s gloves
16853	lawbringer chestguard
16854	lawbringer helm
16855	lawbringer legplates
16856	lawbringer spaulders
16857	lawbringer bracers
16858	lawbringer belt
16859	lawbringer boots
16860	lawbringer gauntlets
16861	bracers of might
16862	sabatons of might
16863	gauntlets of might
16864	belt of might
16865	breastplate of might
16866	helm of might
16867	legplates of might
16868	pauldrons of might
16869	the skull of scryer
16870	the skull of somnus
16871	the skull of chronalis
16872	the skull of axtroz
16873	braidfur gloves
16882	battered junkbox
16883	worn junkbox
16884	sturdy junkbox
16885	heavy junkbox
16886	outlaw sabre
16887	witch s finger
16888	dull drakefire amulet
16889	polished walking staff
16890	slatemetal cutlass
16891	claystone shortsword
16892	lesser soulstone
16893	soulstone
16894	clear crystal rod
16895	greater soulstone
16896	major soulstone
16897	stormrage chestguard
16898	stormrage boots
16899	stormrage handguards
16900	stormrage cover
16901	stormrage legguards
16902	stormrage pauldrons
16903	stormrage belt
16904	stormrage bracers
16905	bloodfang chestpiece
16906	bloodfang boots
16907	bloodfang gloves
16908	bloodfang hood
16909	bloodfang pants
16910	bloodfang belt
16911	bloodfang bracers
16912	netherwind boots
16913	netherwind gloves
16914	netherwind crown
16915	netherwind pants
16916	netherwind robes
16917	netherwind mantle
16918	netherwind bindings
16919	boots of transcendence
16920	handguards of transcendence
16921	halo of transcendence
16922	leggings of transcendence
16923	robes of transcendence
16924	pauldrons of transcendence
16925	belt of transcendence
16926	bindings of transcendence
16927	nemesis boots
16928	nemesis gloves
16929	nemesis skullcap
16930	nemesis leggings
16931	nemesis robes
16932	nemesis spaulders
16933	nemesis belt
16934	nemesis bracers
16935	dragonstalker s bracers
16936	dragonstalker s belt
16937	dragonstalker s spaulders
16938	dragonstalker s legguards
16939	dragonstalker s helm
16940	dragonstalker s gauntlets
16941	dragonstalker s greaves
16942	dragonstalker s breastplate
16943	bracers of ten storms
16944	belt of ten storms
16945	epaulets of ten storms
16946	legplates of ten storms
16947	helmet of ten storms
16948	gauntlets of ten storms
16949	greaves of ten storms
16950	breastplate of ten storms
16951	judgement bindings
16952	judgement belt
16953	judgement spaulders
16954	judgement legplates
16955	judgement crown
16956	judgement gauntlets
16957	judgement sabatons
16958	judgement breastplate
16959	bracelets of wrath
16960	waistband of wrath
16961	pauldrons of wrath
16962	legplates of wrath
16963	helm of wrath
16964	gauntlets of wrath
16965	sabatons of wrath
16966	breastplate of wrath
16967	feralas ahi
16968	sar theris striker
16969	savage coast blue sailfin
16970	misty reed mahi mahi
16971	clamlette surprise
16972	karang s banner
16973	vial of dire water
16974	empty water vial
16975	warsong sash
16976	murgut s totem
16977	warsong boots
16978	warsong gauntlets
16979	flarecore gloves
16980	flarecore mantle
16981	owlbeard bracers
16982	corehound boots
16983	molten helm
16984	black dragonscale boots
16985	windseeker boots
16986	sandspire gloves
16987	screecher belt
16988	fiery chain shoulders
16989	fiery chain girdle
16990	spritekin cloak
16991	triage bandage
16992	smokey s explosive launcher
16993	smokey s fireshooter
16994	duskwing gloves
16995	duskwing mantle
16996	gorewood bow
16997	stormrager
16998	sacred protector
16999	royal seal of alexis
17000	band of the wraith
17001	elemental circle
17002	ichor spitter
17003	skullstone hammer
17004	sarah s guide
17005	boorguard tunic
17006	cobalt legguards
17007	stonerender gauntlets
17008	small scroll
17009	ambassador malcin s head
17010	fiery core
17011	lava core
17012	core leather
17013	dark iron leggings
17014	dark iron bracers
17015	dark iron reaver
17016	dark iron destroyer
17017	pattern flarecore mantle
17018	pattern flarecore gloves
17019	arcane dust
17020	arcane powder
17021	wild berries
17022	pattern corehound boots
17023	pattern molten helm
17024	wild root
17025	pattern black dragonscale boots
17026	wild thornroot
17027	scented candle
17028	holy candle
17029	sacred candle
17030	ankh
17031	rune of teleportation
17032	rune of portals
17033	symbol of divinity
17034	maple seed
17035	stranglethorn seed
17036	ashwood seed
17037	hornbeam seed
17038	ironwood seed
17039	skullbreaker
17042	nail spitter
17043	zealot s robe
17044	will of the martyr
17045	blood of the martyr
17046	gutterblade
17047	luminescent amice
17048	rumsey rum
17049	plans fiery chain girdle
17050	chan s imperial robes
17051	plans dark iron bracers
17052	plans dark iron leggings
17053	plans fiery chain shoulders
17054	joonho s mercy
17055	changuk smasher
17056	light feather
17057	shiny fish scales
17058	fish oil
17059	plans dark iron reaver
17060	plans dark iron destroyer
17061	juno s shadow
17062	recipe mithril head trout
17063	band of accuria
17064	shard of the scale
17065	medallion of steadfast might
17066	drillborer disk
17067	ancient cornerstone grimoire
17068	deathbringer
17069	striker s mark
17070	fang of the mystics
17071	gutgore ripper
17072	blastershot launcher
17073	earthshaker
17074	shadowstrike
17075	vis kag the bloodletter
17076	bonereaver s edge
17077	crimson shocker
17078	sapphiron drape
17082	shard of the flame
17102	cloak of the shrouded mists
17103	azuresong mageblade
17104	spinal reaper
17105	aurastone hammer
17106	malistar s defender
17107	dragon s blood cape
17108	mark of deflection
17109	choker of enlightenment
17110	seal of the archmagus
17111	blazefury medallion
17112	empyrean demolisher
17113	amberseal keeper
17114	araj s phylactery shard
17115	squirrel token
17116	squirrel token
17117	rat catcher s flute
17118	carton of mystery meat
17119	deeprun rat kabob
17124	syndicate emblem
17125	seal of ravenholdt
17126	elegant letter
17142	shard of the defiler
17182	sulfuras hand of ragnaros
17183	dented buckler
17184	small shield
17185	round buckler
17186	small targe
17187	banded buckler
17188	ringed buckler
17189	metal buckler
17190	ornate buckler
17191	scepter of celebras
17192	reinforced targe
17193	sulfuron hammer
17194	holiday spices
17195	fake mistletoe
17196	holiday spirits
17197	gingerbread cookie
17198	egg nog
17199	bad egg nog
17200	recipe gingerbread cookie
17201	recipe egg nog
17202	snowball
17203	sulfuron ingot
17204	eye of sulfuras
17222	spider sausage
17223	thunderstrike
17224	scrying scope
17242	key to salem s chest
17262	james key
17302	blue ribboned holiday gift
17303	blue ribboned wrapping paper
17304	green ribboned wrapping paper
17305	green ribboned holiday gift
17306	stormpike soldier s blood
17307	purple ribboned wrapping paper
17308	purple ribboned holiday gift
17309	discordant bracers
17310	aspect of neptulon
17322	eye of the emberseer
17323	mulverick s beacon
17324	guse s beacon
17325	jeztor s beacon
17326	stormpike soldier s flesh
17327	stormpike lieutenant s flesh
17328	stormpike commander s flesh
17329	hand of lucifron
17330	hand of sulfuron
17331	hand of gehennas
17332	hand of shazzrah
17333	aqual quintessence
17344	candy cane
17345	silithid goo
17346	encrusted silithid object
17347	syndicate man tracker murp
17348	major healing draught
17349	superior healing draught
17351	major mana draught
17352	superior mana draught
17353	stormpike assault orders
17354	master ryson s all seeing eye
17355	rabine s letter
17362	ryson s beacon
17363	ryson s beacon
17364	scrying scope
17384	zinfizzlex s portable shredder unit
17402	greatfather s winter ale
17403	steamwheedle fizzy spirits
17404	blended bean brew
17405	green garden tea
17406	holiday cheesewheel
17407	graccu s homemade meat pie
17408	spicy beefstick
17409	encrusted crystal fragment
17410	zinfizzlex s portable shredder unit
17411	steamsaw
17413	codex prayer of fortitude
17414	codex prayer of fortitude ii
17422	armor scraps
17423	storm crystal
17442	frostwolf assault orders
17502	frostwolf soldier s medal
17503	frostwolf lieutenant s medal
17504	frostwolf commander s medal
17505	ichman s beacon
17506	vipore s beacon
17507	slidore s beacon
17508	forcestone buckler
17522	irondeep supplies
17523	smokey s drape
17542	coldtooth supplies
17562	knight lieutenant s dreadweave boots
17564	knight lieutenant s dreadweave gloves
17566	lieutenant commander s headguard
17567	knight captain s dreadweave leggings
17568	knight captain s dreadweave robe
17569	lieutenant commander s dreadweave mantle
17570	champion s dreadweave hood
17571	legionnaire s dreadweave leggings
17572	legionnaire s dreadweave robe
17573	champion s dreadweave shoulders
17576	blood guard s dreadweave boots
17577	blood guard s dreadweave gloves
17578	field marshal s coronal
17579	marshal s dreadweave leggings
17580	field marshal s dreadweave shoulders
17581	field marshal s dreadweave robe
17583	marshal s dreadweave boots
17584	marshal s dreadweave gloves
17586	general s dreadweave boots
17588	general s dreadweave gloves
17590	warlord s dreadweave mantle
17591	warlord s dreadweave hood
17592	warlord s dreadweave robe
17593	general s dreadweave pants
17594	knight lieutenant s satin boots
17596	knight lieutenant s satin gloves
17598	lieutenant commander s diadem
17599	knight captain s satin leggings
17600	knight captain s satin robes
17601	lieutenant commander s satin amice
17602	field marshal s headdress
17603	marshal s satin pants
17604	field marshal s satin mantle
17605	field marshal s satin vestments
17607	marshal s satin sandals
17608	marshal s satin gloves
17610	champion s satin cowl
17611	legionnaire s satin trousers
17612	legionnaire s satin vestments
17613	champion s satin shoulderpads
17616	blood guard s satin boots
17617	blood guard s satin gloves
17618	general s satin boots
17620	general s satin gloves
17622	warlord s satin mantle
17623	warlord s satin cowl
17624	warlord s satin robes
17625	general s satin leggings
17626	frostwolf muzzle
17642	alterac ram hide
17643	frostwolf hide
17662	stolen treats
17682	book gift of the wild
17683	book gift of the wild ii
17684	theradric crystal carving
17685	smokywood pastures sampler
17686	master hunter s bow
17687	master hunter s rifle
17688	jungle boots
17689	stormpike training collar
17690	frostwolf insignia rank 1
17691	stormpike insignia rank 1
17692	horn ring
17693	coated cerulean vial
17694	band of the fist
17695	chestnut mantle
17696	filled cerulean vial
17702	celebrian rod
17703	celebrian diamond
17704	edge of winter
17705	thrash blade
17706	plans edge of winter
17707	gemshard heart
17708	elixir of frost power
17709	recipe elixir of frost power
17710	charstone dirk
17711	elemental rockridge leggings
17712	winter veil disguise kit
17713	blackstone ring
17714	bracers of the stone princess
17715	eye of theradras
17716	snowmaster 9000
17717	megashot rifle
17718	gizlock s hypertech buckler
17719	inventor s focal sword
17720	schematic snowmaster 9000
17721	gloves of the greatfather
17722	pattern gloves of the greatfather
17723	green holiday shirt
17724	pattern green holiday shirt
17725	formula enchant weapon winter s might
17726	smokywood pastures special gift
17727	smokywood pastures gift pack
17728	albino crocscale boots
17730	gatorbite axe
17731	scroll of celebras
17732	rotgrip mantle
17733	fist of stone
17734	helm of the mountain
17735	the feast of winter veil
17736	rockgrip gauntlets
17737	cloud stone
17738	claw of celebras
17739	grovekeeper s drape
17740	soothsayer s headdress
17741	nature s embrace
17742	fungus shroud armor
17743	resurgence rod
17744	heart of noxxion
17745	noxious shooter
17746	noxxion s shackles
17747	razorlash root
17748	vinerot sandals
17749	phytoskin spaulders
17750	chloromesh girdle
17751	brusslehide leggings
17752	satyr s lash
17753	verdant keeper s aim
17754	infernal trickster leggings
17755	satyrmane sash
17756	shadowshard fragment
17757	amulet of spirits
17758	amulet of union
17759	mark of resolution
17760	seed of life
17761	gem of the first khan
17762	gem of the second khan
17763	gem of the third khan
17764	gem of the fourth khan
17765	gem of the fifth khan
17766	princess theradras scepter
17767	bloomsprout headpiece
17768	woodseed hoop
17769	sagebrush spaulders
17770	branchclaw gauntlets
17771	elementium bar
17772	zealous shadowshard pendant
17773	prodigious shadowshard pendant
17774	mark of the chosen
17775	acumen robes
17776	sprightring helm
17777	relentless chain
17778	sagebrush girdle
17779	hulkstone pauldrons
17780	blade of eternal darkness
17781	the pariah s instructions
17782	talisman of binding shard
17783	talisman of binding fragment
17822	frostwolf maps
17823	stormpike battle plans
17849	stormpike banner
17850	frostwolf banner
17900	stormpike insignia rank 2
17901	stormpike insignia rank 3
17902	stormpike insignia rank 4
17903	stormpike insignia rank 5
17904	stormpike insignia rank 6
17905	frostwolf insignia rank 2
17906	frostwolf insignia rank 3
17907	frostwolf insignia rank 4
17908	frostwolf insignia rank 5
17909	frostwolf insignia rank 6
17922	lionfur armor
17943	fist of stone
17962	blue sack of gems
17963	green sack of gems
17964	gray sack of gems
17965	yellow sack of gems
17966	onyxia hide backpack
17967	refined scale of onyxia
17968	charged scale of onyxia
17969	red sack of gems
17982	ragnaros core
18000	tough jerky
18001	tough hunk of bread
18002	forest mushroom cap
18005	refreshing spring water
18022	royal seal of alexis
18023	blood ruby pendant
18042	thorium headed arrow
18043	coal miner boots
18044	hurley s tankard
18045	tender wolf steak
18046	recipe tender wolf steak
18047	flame walkers
18048	mastersmith s hammer
18082	zum rah s vexing cane
18083	jumanza grips
18102	dragonrider boots
18103	band of rumination
18104	feralsurge girdle
18142	severed night elf head
18143	tuft of gnome hair
18144	human bone chip
18145	tauren hoof
18146	darkspear troll mojo
18147	forsaken heart
18148	skull of korrak
18149	rune of recall
18150	rune of recall
18151	filled amethyst phial
18152	amethyst phial
18153	red moro gai gem
18154	blizzard stationery
18155	blue moro gai gem
18156	green moro gai gem
18157	black moro gai gem
18158	gold moro gai gem
18159	white moro gai gem
18160	recipe thistle tea
18168	force reactive disk
18169	flame mantle of the dawn
18170	frost mantle of the dawn
18171	arcane mantle of the dawn
18172	nature mantle of the dawn
18173	shadow mantle of the dawn
18182	chromatic mantle of the dawn
18202	eskhandar s left claw
18203	eskhandar s right claw
18204	eskhandar s pelt
18205	eskhandar s collar
18206	dwarf spine
18207	orc tooth
18208	drape of benediction
18209	energized sparkplug
18222	thorny vine
18223	serrated petal
18224	lasher root
18225	worn running shoes
18226	a sealed pact
18227	nubless pacifier
18228	autographed picture of foror & tigule
18229	nat pagle s guide to extreme anglin
18230	broken i w i n button
18231	sleeveless t shirt
18232	field repair bot 74a
18233	tear stained handkerchief
18234	document from boomstick imports
18235	schematic field repair bot 74a
18236	gordok chew toy
18237	mastiff jawbone
18238	shadowskin gloves
18239	pattern shadowskin gloves
18240	ogre tannin
18241	black war steed bridle
18242	reins of the black war tiger
18243	black battlestrider
18244	black war ram
18245	horn of the black war wolf
18246	whistle of the black war raptor
18247	black war kodo
18248	red skeletal warhorse
18249	crescent key
18250	gordok shackle key
18251	core armor kit
18252	pattern core armor kit
18253	major rejuvenation potion
18254	runn tum tuber surprise
18255	runn tum tuber
18256	imbued vial
18257	recipe major rejuvenation potion
18258	gordok ogre suit
18259	formula enchant weapon spell power
18260	formula enchant weapon healing power
18261	book of incantations
18262	elemental sharpening stone
18263	flarecore wraps
18264	plans elemental sharpening stone
18265	pattern flarecore wraps
18266	gordok courtyard key
18267	recipe runn tum tuber surprise
18268	gordok inner door key
18269	gordok green grog
18282	core marksman rifle
18283	biznicks 247x128 accurascope
18284	kreeg s stout beatdown
18285	crystallized mana shard
18286	condensed mana fragment
18287	evermurky
18288	molasses firewater
18289	barbed thorn necklace
18290	schematic biznicks 247x128 accurascope
18291	schematic force reactive disk
18292	schematic core marksman rifle
18294	elixir of greater water breathing
18295	phasing boots
18296	marksman bands
18297	thornling seed
18298	unbridled leggings
18299	hydrospawn essence
18300	hyjal nectar
18301	lethtendris s wand
18302	band of vigor
18303	nimble buckler
18304	greenroot mail
18305	breakwater legguards
18306	gloves of shadowy mist
18307	riptide shoes
18308	clever hat
18309	gloves of restoration
18310	fiendish machete
18311	quel dorai channeling rod
18312	energized chestplate
18313	helm of awareness
18314	ring of demonic guile
18315	ring of demonic potency
18316	obsidian bauble
18317	tempest talisman
18318	merciful greaves
18319	fervent helm
18320	demonheart spaulders
18321	energetic rod
18322	waterspout boots
18323	satyr s bow
18324	waveslicer
18325	felhide cap
18326	razor gauntlets
18327	whipvine cord
18328	shadewood cloak
18329	arcanum of rapidity
18330	arcanum of focus
18331	arcanum of protection
18332	libram of rapidity
18333	libram of focus
18334	libram of protection
18335	pristine black diamond
18336	gauntlet of gordok might
18337	orphic bracers
18338	wand of arcane potency
18339	eidolon cloak
18340	eidolon talisman
18341	quel dorei sash
18342	quel dorei guard
18343	petrified band
18344	stonebark gauntlets
18345	murmuring ring
18346	threadbare trousers
18347	well balanced axe
18348	quel serrar
18349	gauntlets of accuracy
18350	amplifying cloak
18351	magically sealed bracers
18352	petrified bark shield
18353	stoneflower staff
18354	pimgib s collar
18355	ferra s collar
18356	garona a study on stealth and treachery
18357	codex of defense
18358	the arcanist s cookbook
18359	the light and how to swing it
18360	harnessing shadows
18361	the greatest race of hunters
18362	holy bologna what the light won t tell you
18363	frost shock and you
18364	the emerald dream
18365	a thoroughly read copy of nat pagle s extreme anglin
18366	gordok s handguards
18367	gordok s gauntlets
18368	gordok s gloves
18369	gordok s handwraps
18370	vigilance charm
18371	mindtap talisman
18372	blade of the new moon
18373	chestplate of tranquility
18374	flamescarred shoulders
18375	bracers of the eclipse
18376	timeworn mace
18377	quickdraw gloves
18378	silvermoon leggings
18379	odious greaves
18380	eldritch reinforced legplates
18381	evil eye pendant
18382	fluctuating cloak
18383	force imbued gauntlets
18384	bile etched spaulders
18385	robe of everlasting night
18386	padre s trousers
18387	brightspark gloves
18388	stoneshatter
18389	cloak of the cosmos
18390	tanglemoss leggings
18391	eyestalk cord
18392	distracting dagger
18393	warpwood binding
18394	demon howl wristguards
18395	emerald flame ring
18396	mind carver
18397	elder magus pendant
18398	tidal loop
18399	ocean s breeze
18400	ring of living stone
18401	foror s compendium of dragon slaying
18402	glowing crystal ring
18403	dragonslayer s signet
18404	onyxia tooth pendant
18405	belt of the archmage
18406	onyxia blood talisman
18407	felcloth gloves
18408	inferno gloves
18409	mooncloth gloves
18410	sprinter s sword
18411	spry boots
18412	core fragment
18413	cloak of warding
18414	pattern belt of the archmage
18415	pattern felcloth gloves
18416	pattern inferno gloves
18417	pattern mooncloth gloves
18418	pattern cloak of warding
18420	bonecrusher
18421	backwood helm
18422	head of onyxia
18423	head of onyxia
18424	sedge boots
18425	kreeg s mug
18426	lethtendris s web
18427	sergeant s cloak
18428	senior sergeant s insignia
18429	first sergeant s plate bracers
18430	first sergeant s plate bracers
18432	first sergeant s mail wristguards
18434	first sergeant s dragonhide armguards
18435	first sergeant s leather armguards
18436	first sergeant s dragonhide armguards
18437	first sergeant s silk cuffs
18438	sergeant s mark
18440	sergeant s cape
18441	sergeant s cape
18442	master sergeant s insignia
18443	master sergeant s insignia
18444	master sergeant s insignia
18445	sergeant major s plate wristguards
18447	sergeant major s plate wristguards
18448	sergeant major s chain armguards
18449	sergeant major s chain armguards
18450	robe of combustion
18451	hyena hide belt
18452	sergeant major s leather armsplints
18453	sergeant major s leather armsplints
18454	sergeant major s dragonhide armsplints
18455	sergeant major s dragonhide armsplints
18456	sergeant major s silk cuffs
18457	sergeant major s silk cuffs
18458	modest armguards
18459	gallant s wristguards
18460	unsophisticated hand cannon
18461	sergeant s cloak
18462	jagged bone fist
18463	ogre pocket knife
18464	gordok nose ring
18465	royal seal of eldre thalas
18466	royal seal of eldre thalas
18467	royal seal of eldre thalas
18468	royal seal of eldre thalas
18469	royal seal of eldre thalas
18470	royal seal of eldre thalas
18471	royal seal of eldre thalas
18472	royal seal of eldre thalas
18473	royal seal of eldre thalas
18475	oddly magical belt
18476	mud stained boots
18477	shaggy leggings
18478	hyena hide jerkin
18479	carrion scorpid helm
18480	scarab plate helm
18481	skullcracking mace
18482	ogre toothpick shooter
18483	mana channeling wand
18484	cho rush s blade
18485	observer s shield
18486	mooncloth robe
18487	pattern mooncloth robe
18488	heated ancient blade
18489	unfired ancient blade
18490	insightful hood
18491	lorespinner
18492	treated ancient blade
18493	bulky iron spaulders
18494	denwatcher s shoulders
18495	redoubt cloak
18496	heliotrope cloak
18497	sublime wristguards
18498	hedgecutter
18499	barrier shield
18500	tarnished elven ring
18501	felvine shard
18502	monstrous glaive
18503	kromcrush s chestplate
18504	girdle of insight
18505	mugger s belt
18506	mongoose boots
18507	boots of the full moon
18508	swift flight bracers
18509	chromatic cloak
18510	hide of the wild
18511	shifting cloak
18512	larval acid
18513	a dull and flat elven blade
18514	pattern girdle of insight
18515	pattern mongoose boots
18516	pattern swift flight bracers
18517	pattern chromatic cloak
18518	pattern hide of the wild
18519	pattern shifting cloak
18520	barbarous blade
18521	grimy metal boots
18522	band of the ogre king
18523	brightly glowing stone
18524	leggings of destruction
18525	bracers of prosperity
18526	crown of the ogre king
18527	harmonious gauntlets
18528	cyclone spaulders
18529	elemental plate girdle
18530	ogre forged hauberk
18531	unyielding maul
18532	mindsurge robe
18533	gordok bracers of power
18534	rod of the ogre magi
18535	milli s shield
18536	milli s lexicon
18537	counterattack lodestone
18538	treant s bane
18539	reliquary of purity
18540	sealed reliquary of purity
18541	puissant cape
18542	typhoon
18543	ring of entropy
18544	doomhide gauntlets
18545	leggings of arcane supremacy
18546	infernal headcage
18547	unmelting ice girdle
18562	elementium ore
18563	bindings of the windseeker
18564	bindings of the windseeker
18565	vessel of rebirth
18566	essence of the firelord
18567	elemental flux
18582	the twin blades of azzinoth
18583	warglaive of azzinoth right
18584	warglaive of azzinoth left
18585	band of allegiance
18586	lonetree s circle
18587	goblin jumper cables xl
18588	ez thro dynamite ii
18590	raging beast s blood
18591	case of blood
18592	plans sulfuron hammer
18594	powerful seaforium charge
18595	blood opal
18597	orcish orphan whistle
18598	human orphan whistle
18600	tome of arcane brilliance
18601	glowing crystal prison
18602	tome of sacrifice
18603	satyr blood
18604	tears of the hederine
18605	imprisoned doomguard
18606	alliance battle standard
18607	horde battle standard
18608	benediction
18609	anathema
18610	keen machete
18611	gnarlpine leggings
18612	bloody chain boots
18622	flawless fel essence jaedenar
18623	flawless fel essence dark portal
18624	flawless fel essence azshara
18625	kroshius infernal core
18626	fel fire
18627	gong of dethmoora
18628	thorium brotherhood contract
18629	black lodestone
18630	doomsday flare
18631	truesilver transformer
18632	moonbrook riot taffy
18633	styleen s sour suckerpop
18634	gyrofreeze ice reflector
18635	bellara s nutterbar
18636	ruined jumper cables xl
18637	major recombobulator
18638	hyper radiant flame reflector
18639	ultra flash shadow reflector
18640	happy fun rock
18641	dense dynamite
18642	jaina s autograph
18643	cairne s hoofprint
18645	gnomish alarm o bot
18646	the eye of divinity
18647	schematic red firework
18648	schematic green firework
18649	schematic blue firework
18650	schematic ez thro dynamite ii
18651	schematic truesilver transformer
18652	schematic gyrofreeze ice reflector
18653	schematic goblin jumper cables xl
18654	schematic gnomish alarm o bot
18655	schematic major recombobulator
18656	schematic powerful seaforium charge
18657	schematic hyper radiant flame reflector
18658	schematic ultra flash shadow reflector
18659	splinter of nordrassil
18660	world enlarger
18661	schematic world enlarger
18662	heavy leather ball
18663	j eevee s jar
18664	a treatise on military ranks
18665	the eye of shadow
18670	xorothian glyphs
18671	baron charr s sceptre
18672	elemental ember
18673	avalanchion s stony hide
18674	hardened stone band
18675	military ranks of the horde & alliance
18676	sash of the windreaver
18677	zephyr cloak
18678	tempestria s frozen necklace
18679	frigid ring
18680	ancient bone bow
18681	burial shawl
18682	ghoul skin leggings
18683	hammer of the vesper
18684	dimly opalescent ring
18686	bone golem shoulders
18687	xorothian stardust
18688	imp in a jar
18689	phantasmal cloak
18690	wraithplate leggings
18691	dark advisor s pendant
18692	death knight sabatons
18693	shivery handwraps
18694	shadowy mail greaves
18695	spellbound tome
18696	intricately runed shield
18697	coldstone slippers
18698	tattered leather hood
18699	icy tomb spaulders
18700	malefic bracers
18701	innervating band
18702	belt of the ordained
18703	ancient petrified leaf
18704	mature blue dragon sinew
18705	mature black dragon sinew
18706	arena master
18707	ancient rune etched stave
18708	petrified bark
18709	arena wristguards
18710	arena bracers
18711	arena bands
18712	arena vambraces
18713	rhok delar longbow of the ancient keepers
18714	ancient sinew wrapped lamina
18715	lok delar stave of the ancient keepers
18716	ash covered boots
18717	hammer of the grand crusader
18718	grand crusader s helm
18719	the traitor s heart
18720	shroud of the nathrezim
18721	barrage girdle
18722	death grips
18723	animated chain necklace
18724	enchanted black dragon sinew
18725	peacemaker
18726	magistrate s cuffs
18727	crimson felt hat
18728	anastari heirloom
18729	screeching bow
18730	shadowy laced handwraps
18731	pattern heavy leather ball
18734	pale moon cloak
18735	maleki s footwraps
18736	plaguehound leggings
18737	bone slicing hatchet
18738	carapace spine crossbow
18739	chitinous plate legguards
18740	thuzadin sash
18741	morlune s bracer
18742	stratholme militia shoulderguard
18743	gracious cape
18744	plaguebat fur gloves
18745	sacred cloth leggings
18746	divination scryer
18749	charger s lost soul
18752	exorcism censer
18753	arcanite barding
18754	fel hardened bracers
18755	xorothian firestick
18756	dreadguard s protector
18757	diabolic mantle
18758	specter s blade
18759	malicious axe
18760	necromantic band
18761	oblivion s touch
18762	shard of the green flame
18766	reins of the swift frostsaber
18767	reins of the swift mistsaber
18768	reins of the swift dawnsaber
18769	enchanted thorium platemail
18770	enchanted thorium platemail
18771	enchanted thorium platemail
18772	swift green mechanostrider
18773	swift white mechanostrider
18774	swift yellow mechanostrider
18775	manna enriched horse feed
18776	swift palomino
18777	swift brown steed
18778	swift white steed
18779	bottom half of advanced armorsmithing volume i
18780	top half of advanced armorsmithing volume i
18781	bottom half of advanced armorsmithing volume ii
18782	top half of advanced armorsmithing volume ii
18783	bottom half of advanced armorsmithing volume iii
18784	top half of advanced armorsmithing volume iii
18785	swift white ram
18786	swift brown ram
18787	swift gray ram
18788	swift blue raptor
18789	swift olive raptor
18790	swift orange raptor
18791	purple skeletal warhorse
18792	blessed arcanite barding
18793	great white kodo
18794	great brown kodo
18795	great gray kodo
18796	horn of the swift brown wolf
18797	horn of the swift timber wolf
18798	horn of the swift gray wolf
18799	charger s redeemed soul
18802	shadowy potion
18803	finkle s lava dredger
18804	lord grayson s satchel
18805	core hound tooth
18806	core forged greaves
18807	helm of latent power
18808	gloves of the hypnotic flame
18809	sash of whispered secrets
18810	wild growth spaulders
18811	fireproof cloak
18812	wristguards of true flight
18813	ring of binding
18814	choker of the fire lord
18815	essence of the pure flame
18816	perdition s blade
18817	crown of destruction
18818	mor zul s instructions
18819	rohan s exorcism censer
18820	talisman of ephemeral power
18821	quick strike ring
18822	obsidian edged blade
18823	aged core leather gloves
18824	magma tempered boots
18825	grand marshal s aegis
18826	high warlord s shield wall
18827	grand marshal s handaxe
18828	high warlord s cleaver
18829	deep earth spaulders
18830	grand marshal s sunderer
18831	high warlord s battle axe
18832	brutality blade
18833	grand marshal s bullseye
18834	insignia of the horde
18835	high warlord s recurve
18836	grand marshal s repeater
18837	high warlord s crossbow
18838	grand marshal s dirk
18839	combat healing potion
18840	high warlord s razor
18841	combat mana potion
18842	staff of dominance
18843	grand marshal s right hand blade
18844	high warlord s right claw
18845	insignia of the horde
18846	insignia of the horde
18847	grand marshal s left hand blade
18848	high warlord s left claw
18849	insignia of the horde
18850	insignia of the horde
18851	insignia of the horde
18852	insignia of the horde
18853	insignia of the horde
18854	insignia of the alliance
18855	grand marshal s hand cannon
18856	insignia of the alliance
18857	insignia of the alliance
18858	insignia of the alliance
18859	insignia of the alliance
18860	high warlord s street sweeper
18861	flamewaker legplates
18862	insignia of the alliance
18863	insignia of the alliance
18864	insignia of the alliance
18865	grand marshal s punisher
18866	high warlord s bludgeon
18867	grand marshal s battle hammer
18868	high warlord s pulverizer
18869	grand marshal s glaive
18870	helm of the lifegiver
18871	high warlord s pig sticker
18872	manastorm leggings
18873	grand marshal s stave
18874	high warlord s war staff
18875	salamander scale pants
18876	grand marshal s claymore
18877	high warlord s greatsword
18878	sorcerous dagger
18879	heavy dark iron ring
18880	darkreaver s head
18902	reins of the swift stormsaber
18904	zorbin s ultra shrinker
18922	secret plans fiery flux
18942	fiery flux
18943	dark iron pillow
18944	incendosaur scale
18945	dark iron residue
18946	head of overseer maltorius
18947	rage scar yeti hide
18948	barbaric bracers
18949	pattern barbaric bracers
18950	chambermaid pillaclencher s pillow
18951	evonice s landin pilla
18952	simone s head
18953	klinfran s head
18954	solenor s head
18955	artorius s head
18956	miniaturization residue
18957	brushwood blade
18958	water elemental core
18959	smithing tuyere
18960	lookout s spyglass
18961	zukk ash carapace
18962	stinglasher s glands
18963	turtle egg albino
18964	turtle egg loggerhead
18965	turtle egg hawksbill
18966	turtle egg leatherback
18967	turtle egg olive
18969	pristine yeti hide
18970	ring of critical testing 2
18972	perfect yeti hide
18984	dimensional ripper everlook
18986	ultrasafe transporter gadgetzan
18987	blackhand s command
19002	head of nefarian
19003	head of nefarian
19004	minor healthstone
19005	minor healthstone
19006	lesser healthstone
19007	lesser healthstone
19008	healthstone
19009	healthstone
19010	greater healthstone
19011	greater healthstone
19012	major healthstone
19013	major healthstone
19016	vessel of rebirth
19017	essence of the firelord
19018	dormant wind kissed blade
19019	thunderfury blessed blade of the windseeker
19020	camp mojache zukk ash report
19022	nat pagle s extreme angler fc 5000
19023	katoom s best lure
19024	arena grand master
19025	skylord plume
19026	snake burst firework
19027	schematic snake burst firework
19028	elegant dress
19029	horn of the frostwolf howler
19030	stormpike battle charger
19031	frostwolf battle tabard
19032	stormpike battle tabard
19033	slagtree s lost tools
19034	lard s lunch
19035	lard s special picnic basket
19036	final message to the wildhammer
19037	emerald peak spaulders
19038	ring of subtlety
19039	zorbin s water resistant hat
19040	zorbin s mega slicer
19041	pratt s handcrafted tunic
19042	jangdor s handcrafted tunic
19043	heavy timbermaw belt
19044	might of the timbermaw
19045	stormpike battle standard
19046	frostwolf battle standard
19047	wisdom of the timbermaw
19048	heavy timbermaw boots
19049	timbermaw brawlers
19050	mantle of the timbermaw
19051	girdle of the dawn
19052	dawn treaders
19054	red dragon orb
19055	green dragon orb
19056	argent boots
19057	gloves of the dawn
19058	golden mantle of the dawn
19059	argent shoulders
19060	warsong gulch enriched ration
19061	warsong gulch iron ration
19062	warsong gulch field ration
19064	shackle key
19065	emerald circle
19066	warsong gulch runecloth bandage
19067	warsong gulch mageweave bandage
19068	warsong gulch silk bandage
19069	huntsman malkhor s skull
19070	huntsman malkhor s bones
19071	vessel of tainted blood
19083	frostwolf legionnaire s cloak
19084	stormpike soldier s cloak
19085	frostwolf advisor s cloak
19086	stormpike sage s cloak
19087	frostwolf plate belt
19088	frostwolf mail belt
19089	frostwolf leather belt
19090	frostwolf cloth belt
19091	stormpike plate girdle
19092	stormpike mail girdle
19093	stormpike leather girdle
19094	stormpike cloth girdle
19095	frostwolf legionnaire s pendant
19096	frostwolf advisor s pendant
19097	stormpike soldier s pendant
19098	stormpike sage s pendant
19099	glacial blade
19100	electrified dagger
19101	whiteout staff
19102	crackling staff
19103	frostbite
19104	stormstrike hammer
19105	frost runed headdress
19106	ice barbed spear
19107	bloodseeker
19108	wand of biting cold
19109	deep rooted ring
19110	cold forged blade
19111	winteraxe epaulets
19112	frozen steel vambraces
19113	yeti hide bracers
19114	highland bow
19115	flask of forest mojo
19116	greenleaf handwraps
19117	laquered wooden plate legplates
19118	nature s breath
19119	owlbeast hide gloves
19120	rune of the guard captain
19121	deep woodlands cloak
19123	everwarm handwraps
19124	slagplate leggings
19125	seared mail girdle
19126	slagplate gauntlets
19127	charred leather tunic
19128	seared mail vest
19129	everglowing robe
19130	cold snap
19131	snowblind shoes
19132	crystal adorned crown
19133	fel infused leggings
19134	flayed doomguard belt
19135	blacklight bracer
19136	mana igniting cord
19137	onslaught girdle
19138	band of sulfuras
19139	fireguard shoulders
19140	cauterizing band
19141	luffa
19142	fire runed grimoire
19143	flameguard gauntlets
19144	sabatons of the flamewalker
19145	robe of volatile power
19146	wristguards of stability
19147	ring of spell power
19148	dark iron helm
19149	lava belt
19150	sentinel basic care package
19151	sentinel standard care package
19152	sentinel advanced care package
19153	outrider advanced care package
19154	outrider basic care package
19155	outrider standard care package
19156	flarecore robe
19157	chromatic gauntlets
19159	woven ivy necklace
19160	contest winner s tabard
19162	corehound belt
19163	molten belt
19164	dark iron gauntlets
19165	flarecore leggings
19166	black amnesty
19167	blackfury
19168	blackguard
19169	nightfall
19170	ebon hand
19182	darkmoon faire prize ticket
19183	hourglass sand
19202	plans heavy timbermaw belt
19203	plans girdle of the dawn
19204	plans heavy timbermaw boots
19205	plans gloves of the dawn
19206	plans dark iron helm
19207	plans dark iron gauntlets
19208	plans black amnesty
19209	plans blackfury
19210	plans ebon hand
19211	plans blackguard
19212	plans nightfall
19213	silverwing talisman of merit
19215	pattern wisdom of the timbermaw
19216	pattern argent boots
19217	pattern argent shoulders
19218	pattern mantle of the timbermaw
19219	pattern flarecore robe
19220	pattern flarecore leggings
19221	darkmoon special reserve
19222	cheap beer
19223	darkmoon dog
19224	red hot wings
19225	deep fried candybar
19227	ace of beasts
19228	beasts deck
19229	sayge s fortune #1
19230	two of beasts
19231	three of beasts
19232	four of beasts
19233	five of beasts
19234	six of beasts
19235	seven of beasts
19236	eight of beasts
19237	sayge s fortune #19
19238	sayge s fortune #3
19239	sayge s fortune #4
19240	sayge s fortune #5
19241	sayge s fortune #6
19242	sayge s fortune #7
19243	sayge s fortune #8
19244	sayge s fortune #9
19245	sayge s fortune #10
19246	sayge s fortune #11
19247	sayge s fortune #12
19248	sayge s fortune #13
19249	sayge s fortune #14
19250	sayge s fortune #15
19251	sayge s fortune #16
19252	sayge s fortune #18
19253	sayge s fortune #17
19254	sayge s fortune #21
19255	sayge s fortune #22
19256	sayge s fortune #2
19257	warlords deck
19258	ace of warlords
19259	two of warlords
19260	three of warlords
19261	four of warlords
19262	five of warlords
19263	six of warlords
19264	seven of warlords
19265	eight of warlords
19266	sayge s fortune #20
19267	elementals deck
19268	ace of elementals
19269	two of elementals
19270	three of elementals
19271	four of elementals
19272	five of elementals
19273	six of elementals
19274	seven of elementals
19275	eight of elementals
19276	ace of portals
19277	portals deck
19278	two of portals
19279	three of portals
19280	four of portals
19281	five of portals
19282	six of portals
19283	seven of portals
19284	eight of portals
19287	darkmoon card heroism
19288	darkmoon card blue dragon
19289	darkmoon card maelstrom
19290	darkmoon card twisting nether
19291	darkmoon storage box
19292	last month s mutton
19293	last year s mutton
19295	darkmoon flower
19296	greater darkmoon prize
19297	lesser darkmoon prize
19298	minor darkmoon prize
19299	fizzy faire drink
19300	bottled winterspring water
19301	alterac manna biscuit
19302	darkmoon ring
19303	darkmoon necklace
19304	spiced beef jerky
19305	pickled kodo foot
19306	crunchy frog
19307	alterac heavy runecloth bandage
19308	tome of arcane domination
19309	tome of shadow force
19310	tome of the ice lord
19311	tome of fiery arcana
19312	lei of the lifegiver
19315	therazane s touch
19316	ice threaded arrow
19317	ice threaded bullet
19318	bottled alterac spring water
19319	harpy hide quiver
19320	gnoll skin bandolier
19321	the immovable object
19322	zzdeprecated warsong mark of honor
19323	the unstoppable force
19324	the lobotomizer
19325	don julio s band
19326	pattern might of the timbermaw
19327	pattern timbermaw brawlers
19328	pattern dawn treaders
19329	pattern golden mantle of the dawn
19330	pattern lava belt
19331	pattern chromatic gauntlets
19332	pattern corehound belt
19333	pattern molten belt
19334	the untamed blade
19335	spineshatter
19336	arcane infused gem
19337	the black book
19338	free ticket voucher
19339	mind quickening gem
19340	rune of metamorphosis
19341	lifegiving gem
19342	venomous totem
19343	scrolls of blinding light
19344	natural alignment crystal
19345	aegis of preservation
19346	dragonfang blade
19347	claw of chromaggus
19348	red dragonscale protector
19349	elementium reinforced bulwark
19350	heartstriker
19351	maladath runed blade of the black flight
19352	chromatically tempered sword
19353	drake talon cleaver
19354	draconic avenger
19355	shadow wing focus staff
19356	staff of the shadow flame
19357	herald of woe
19358	draconic maul
19360	lok amir il romathis
19361	ashjre thul crossbow of smiting
19362	doom s edge
19363	crul shorukh edge of chaos
19364	ashkandi greatsword of the brotherhood
19365	claw of the black drake
19366	master dragonslayer s orb
19367	dragon s touch
19368	dragonbreath hand cannon
19369	gloves of rapid evolution
19370	mantle of the blackwing cabal
19371	pendant of the fallen dragon
19372	helm of endless rage
19373	black brood pauldrons
19374	bracers of arcane accuracy
19375	mish undare circlet of the mind flayer
19376	archimtiros ring of reckoning
19377	prestor s talisman of connivery
19378	cloak of the brood lord
19379	neltharion s tear
19380	therazane s link
19381	boots of the shadow flame
19382	pure elementium band
19383	master dragonslayer s medallion
19384	master dragonslayer s ring
19385	empowered leggings
19386	elementium threaded cloak
19387	chromatic boots
19388	angelista s grasp
19389	taut dragonhide shoulderpads
19390	taut dragonhide gloves
19391	shimmering geta
19392	girdle of the fallen crusader
19393	primalist s linked waistguard
19394	drake talon pauldrons
19395	rejuvenating gem
19396	taut dragonhide belt
19397	ring of blackrock
19398	cloak of firemaw
19399	black ash robe
19400	firemaw s clutch
19401	primalist s linked legguards
19402	legguards of the fallen crusader
19403	band of forced concentration
19405	malfurion s blessed bulwark
19406	drake fang talisman
19407	ebony flame gloves
19422	darkmoon faire fortune
19423	sayge s fortune #23
19424	sayge s fortune #24
19425	mysterious lockbox
19426	orb of the darkmoon
19430	shroud of pure thought
19431	styleen s impeding scarab
19432	circle of applied force
19433	emberweave leggings
19434	band of dark dominion
19435	essence gatherer
19436	cloak of draconic might
19437	boots of pure thought
19438	ringo s blizzard boots
19439	interlaced shadow jerkin
19440	powerful anti venom
19441	huge venom sac
19442	formula powerful anti venom
19443	sayge s fortune #25
19444	formula enchant weapon strength
19445	formula enchant weapon agility
19446	formula enchant bracer mana regeneration
19447	formula enchant bracer healing
19448	formula enchant weapon mighty spirit
19449	formula enchant weapon mighty intellect
19450	a jubling s tiny home
19451	sayge s fortune #26
19452	sayge s fortune #27
19453	sayge s fortune #28
19454	sayge s fortune #29
19462	unhatched jubling egg
19482	lecraft rabbit pelt
19483	peeling the onion
19484	the frostwolf artichoke
19491	amulet of the darkmoon
19505	warsong battle tabard
19506	silverwing battle tabard
19507	inquisitor s shawl
19508	branded leather bracers
19509	dusty mail boots
19510	legionnaire s band
19511	legionnaire s band
19512	legionnaire s band
19513	legionnaire s band
19514	protector s band
19515	protector s band
19516	protector s band
19517	protector s band
19518	advisor s ring
19519	advisor s ring
19520	advisor s ring
19521	advisor s ring
19522	lorekeeper s ring
19523	lorekeeper s ring
19524	lorekeeper s ring
19525	lorekeeper s ring
19526	battle healer s cloak
19527	battle healer s cloak
19528	battle healer s cloak
19529	battle healer s cloak
19530	caretaker s cape
19531	caretaker s cape
19532	caretaker s cape
19533	caretaker s cape
19534	scout s medallion
19535	scout s medallion
19536	scout s medallion
19537	scout s medallion
19538	sentinel s medallion
19539	sentinel s medallion
19540	sentinel s medallion
19541	sentinel s medallion
19542	scout s blade
19543	scout s blade
19544	scout s blade
19545	scout s blade
19546	sentinel s blade
19547	sentinel s blade
19548	sentinel s blade
19549	sentinel s blade
19550	legionnaire s sword
19551	legionnaire s sword
19552	legionnaire s sword
19553	legionnaire s sword
19554	protector s sword
19555	protector s sword
19556	protector s sword
19557	protector s sword
19558	outrider s bow
19559	outrider s bow
19560	outrider s bow
19561	outrider s bow
19562	outrunner s bow
19563	outrunner s bow
19564	outrunner s bow
19565	outrunner s bow
19566	advisor s gnarled staff
19567	advisor s gnarled staff
19568	advisor s gnarled staff
19569	advisor s gnarled staff
19570	lorekeeper s staff
19571	lorekeeper s staff
19572	lorekeeper s staff
19573	lorekeeper s staff
19574	strength of mugamba
19575	strength of mugamba
19576	strength of mugamba
19577	rage of mugamba
19578	berserker bracers
19579	heathen s brand
19580	berserker bracers
19581	berserker bracers
19582	windtalker s wristguards
19583	windtalker s wristguards
19584	windtalker s wristguards
19585	heathen s brand
19586	heathen s brand
19587	forest stalker s bracers
19588	hero s brand
19589	forest stalker s bracers
19590	forest stalker s bracers
19591	the eye of zuldazar
19592	the eye of zuldazar
19593	the eye of zuldazar
19594	the all seeing eye of zuldazar
19595	dryad s wrist bindings
19596	dryad s wrist bindings
19597	dryad s wrist bindings
19598	pebble of kajaro
19599	pebble of kajaro
19600	pebble of kajaro
19601	jewel of kajaro
19602	kezan s taint
19603	kezan s taint
19604	kezan s taint
19605	kezan s unstoppable taint
19606	vision of voodress
19607	vision of voodress
19608	vision of voodress
19609	unmarred vision of voodress
19610	enchanted south seas kelp
19611	enchanted south seas kelp
19612	enchanted south seas kelp
19613	pristine enchanted south seas kelp
19614	zandalarian shadow talisman
19615	zandalarian shadow talisman
19616	zandalarian shadow talisman
19617	zandalarian shadow mastery talisman
19618	maelstrom s tendril
19619	maelstrom s tendril
19620	maelstrom s tendril
19621	maelstrom s wrath
19642	icoke prize voucher
19682	bloodvine vest
19683	bloodvine leggings
19684	bloodvine boots
19685	primal batskin jerkin
19686	primal batskin gloves
19687	primal batskin bracers
19688	blood tiger breastplate
19689	blood tiger shoulders
19690	bloodsoul breastplate
19691	bloodsoul shoulders
19692	bloodsoul gauntlets
19693	darksoul breastplate
19694	darksoul leggings
19695	darksoul shoulders
19696	harvest bread
19697	bounty of the harvest
19698	zulian coin
19699	razzashi coin
19700	hakkari coin
19701	gurubashi coin
19702	vilebranch coin
19703	witherbark coin
19704	sandfury coin
19705	skullsplitter coin
19706	bloodscalp coin
19707	red hakkari bijou
19708	blue hakkari bijou
19709	yellow hakkari bijou
19710	orange hakkari bijou
19711	green hakkari bijou
19712	purple hakkari bijou
19713	bronze hakkari bijou
19714	silver hakkari bijou
19715	gold hakkari bijou
19716	primal hakkari bindings
19717	primal hakkari armsplint
19718	primal hakkari stanchion
19719	primal hakkari girdle
19720	primal hakkari sash
19721	primal hakkari shawl
19722	primal hakkari tabard
19723	primal hakkari kossack
19724	primal hakkari aegis
19725	arathi resource crate
19726	bloodvine
19727	blood scythe
19760	overlord s embrace
19764	pattern bloodvine vest
19765	pattern bloodvine leggings
19766	pattern bloodvine boots
19767	primal bat leather
19768	primal tiger leather
19769	pattern primal batskin jerkin
19770	pattern primal batskin gloves
19771	pattern primal batskin bracers
19772	pattern blood tiger breastplate
19773	pattern blood tiger shoulders
19774	souldarite
19775	sealed azure bag
19776	plans bloodsoul breastplate
19777	plans bloodsoul shoulders
19778	plans bloodsoul gauntlets
19779	plans darksoul breastplate
19780	plans darksoul leggings
19781	plans darksoul shoulders
19782	presence of might
19783	syncretist s sigil
19784	death s embrace
19785	falcon s call
19786	vodouisant s vigilant embrace
19787	presence of sight
19788	hoodoo hex
19789	prophetic aura
19790	animist s caress
19802	heart of hakkar
19803	brownell s blue striped racer
19804	pale ghoulfish
19805	keefer s angelfish
19806	dezian queenfish
19807	speckled tastyfish
19808	rockhide strongfish
19812	rune of the dawn
19813	punctured voodoo doll
19814	punctured voodoo doll
19815	punctured voodoo doll
19816	punctured voodoo doll
19817	punctured voodoo doll
19818	punctured voodoo doll
19819	punctured voodoo doll
19820	punctured voodoo doll
19821	punctured voodoo doll
19822	zandalar vindicator s breastplate
19823	zandalar vindicator s belt
19824	zandalar vindicator s armguards
19825	zandalar freethinker s breastplate
19826	zandalar freethinker s belt
19827	zandalar freethinker s armguards
19828	zandalar augur s hauberk
19829	zandalar augur s belt
19830	zandalar augur s bracers
19831	zandalar predator s mantle
19832	zandalar predator s belt
19833	zandalar predator s bracers
19834	zandalar madcap s tunic
19835	zandalar madcap s mantle
19836	zandalar madcap s bracers
19838	zandalar haruspex s tunic
19839	zandalar haruspex s belt
19840	zandalar haruspex s bracers
19841	zandalar confessor s mantle
19842	zandalar confessor s bindings
19843	zandalar confessor s wraps
19845	zandalar illusionist s mantle
19846	zandalar illusionist s wraps
19848	zandalar demoniac s wraps
19849	zandalar demoniac s mantle
19850	uther s tribute
19851	grom s tribute
19852	ancient hakkari manslayer
19853	gurubashi dwarf destroyer
19854	zin rokh destroyer of worlds
19855	bloodsoaked legplates
19856	the eye of hakkar
19857	cloak of consumption
19858	zandalar honor token
19859	fang of the faceless
19861	touch of chaos
19862	aegis of the blood god
19863	primalist s seal
19864	bloodcaller
19865	warblade of the hakkari
19866	warblade of the hakkari
19867	bloodlord s defender
19869	blooddrenched grips
19870	hakkari loa cloak
19871	talisman of protection
19872	swift razzashi raptor
19873	overlord s crimson band
19874	halberd of smiting
19875	bloodstained coif
19876	soul corrupter s necklace
19877	animist s leggings
19878	bloodsoaked pauldrons
19880	gurubashi head collection
19881	channeler s head
19882	the hexxer s head
19883	sacred cord
19884	jin do s judgement
19885	jin do s evil eye
19886	the hexxer s cover
19887	bloodstained legplates
19888	overlord s embrace
19889	blooddrenched leggings
19890	jin do s hexxer
19891	jin do s bag of whammies
19892	animist s boots
19893	zanzil s seal
19894	bloodsoaked gauntlets
19895	bloodtinged kilt
19896	thekal s grasp
19897	betrayer s boots
19898	seal of jin
19899	ritualistic legguards
19900	zulian stone axe
19901	zulian slicer
19902	swift zulian tiger
19903	fang of venoxis
19904	runed bloodstained hauberk
19905	zanzil s band
19906	blooddrenched footpads
19907	zulian tigerhide cloak
19908	sceptre of smiting
19909	will of arlokk
19910	arlokk s grasp
19911	whipweed heart
19912	overlord s onyx band
19913	bloodsoaked greaves
19914	panther hide sack
19915	zulian defender
19918	jeklik s crusher
19919	bloodstained greaves
19920	primalist s band
19921	zulian hacker
19922	arlokk s hoodoo stick
19923	jeklik s opaline talisman
19925	band of jin
19927	mar li s touch
19928	animist s spaulders
19929	bloodtinged gloves
19930	mar li s eye
19931	gurubashi mojo madness
19933	glowing scorpid blood
19934	large scorpid claw
19935	empty venom sac
19936	dried scorpid carapace
19937	small scorpid claw
19938	heavy scorpid leg
19939	gri lek s blood
19940	renataki s tooth
19941	wushoolay s mane
19942	hazza rah s dream thread
19943	massive mojo
19944	nat pagle s fish terminator
19945	foror s eyepatch
19946	tigule s harpoon
19947	nat pagle s broken reel
19948	zandalarian hero badge
19949	zandalarian hero medallion
19950	zandalarian hero charm
19951	gri lek s charm of might
19952	gri lek s charm of valor
19953	renataki s charm of beasts
19954	renataki s charm of trickery
19955	wushoolay s charm of nature
19956	wushoolay s charm of spirits
19957	hazza rah s charm of destruction
19958	hazza rah s charm of healing
19959	hazza rah s charm of magic
19960	crystalized honey
19961	gri lek s grinder
19962	gri lek s carver
19963	pitchfork of madness
19964	renataki s soul conduit
19965	wushoolay s poker
19967	thoughtblighter
19968	fiery retributer
19969	nat pagle s extreme anglin boots
19970	arcanite fishing pole
19972	lucky fishing hat
19973	nat s measuring tape
19974	mudskunk lure
19975	zulian mudskunk
19978	fishing tournament
19979	hook of the master angler
19982	duskbat drape
19984	ebon mask
19986	pirate s eye patch
19989	tome of devouring shadows
19990	blessed prayer beads
19991	devilsaur eye
19992	devilsaur tooth
19993	hoodoo hunting bow
19994	harvest fruit
19995	harvest boar
19996	harvest fish
19997	harvest nectar
19998	bloodvine lens
19999	bloodvine goggles
20000	schematic bloodvine goggles
20001	schematic bloodvine lens
20002	greater dreamless sleep potion
20003	devilsaur claws
20004	major troll s blood potion
20005	devilsaur claws
20006	circle of hope
20007	mageblood potion
20008	living action potion
20009	for the light
20010	the horde s hellscream
20011	recipe mageblood potion
20012	recipe greater dreamless sleep potion
20013	recipe living action potion
20014	recipe major troll s blood potion
20015	elder raptor feathers
20016	trophy raptor skull
20017	perfect courser antler
20018	angerclaw grizzly hide
20019	tooth of morphaz
20020	bundle of goods
20021	gold pirate earring
20022	azure key
20023	encoded fragment
20024	putrid bile duct
20025	blood of morphaz
20026	rotting flesh
20027	healthy courser gland
20028	glittering dust
20029	enchanted coral
20030	pet rock
20031	essence mango
20032	flowing ritual robes
20033	zandalar demoniac s robe
20034	zandalar illusionist s robe
20035	glacial spike
20036	fire ruby
20037	arcane crystal pendant
20038	mandokir s sting
20039	dark iron boots
20040	plans dark iron boots
20041	highlander s plate girdle
20042	highlander s lamellar girdle
20043	highlander s chain girdle
20044	highlander s mail girdle
20045	highlander s leather girdle
20046	highlander s lizardhide girdle
20047	highlander s cloth girdle
20048	highlander s plate greaves
20049	highlander s lamellar greaves
20050	highlander s chain greaves
20051	highlander s mail greaves
20052	highlander s leather boots
20053	highlander s lizardhide boots
20054	highlander s cloth boots
20055	highlander s chain pauldrons
20056	highlander s mail pauldrons
20057	highlander s plate spaulders
20058	highlander s lamellar spaulders
20059	highlander s leather shoulders
20060	highlander s lizardhide shoulders
20061	highlander s epaulets
20062	arathi basin enriched ration
20063	arathi basin field ration
20064	arathi basin iron ration
20065	arathi basin mageweave bandage
20066	arathi basin runecloth bandage
20067	arathi basin silk bandage
20068	deathguard s cloak
20069	ironbark staff
20070	sageclaw
20071	talisman of arathor
20072	defiler s talisman
20073	cloak of the honor guard
20074	heavy crocolisk stew
20075	recipe heavy crocolisk stew
20076	zandalar signet of mojo
20077	zandalar signet of might
20078	zandalar signet of serenity
20079	spirit of zanza
20080	sheen of zanza
20081	swiftness of zanza
20082	woestave
20083	hunting spear
20084	hunting net
20085	arcane shard
20086	broken dusksteel throwing knife
20087	wavethrasher scales
20088	highlander s chain girdle
20089	highlander s chain girdle
20090	highlander s padded girdle
20091	highlander s chain greaves
20092	highlander s chain greaves
20093	highlander s padded greaves
20094	highlander s cloth boots
20095	highlander s cloth boots
20096	highlander s cloth boots
20097	highlander s cloth girdle
20098	highlander s cloth girdle
20099	highlander s cloth girdle
20100	highlander s lizardhide boots
20101	highlander s lizardhide boots
20102	highlander s lizardhide boots
20103	highlander s lizardhide girdle
20104	highlander s lizardhide girdle
20105	highlander s lizardhide girdle
20106	highlander s lamellar girdle
20107	highlander s lamellar girdle
20108	highlander s lamellar girdle
20109	highlander s lamellar greaves
20110	highlander s lamellar greaves
20111	highlander s lamellar greaves
20112	highlander s leather boots
20113	highlander s leather boots
20114	highlander s leather boots
20115	highlander s leather girdle
20116	highlander s leather girdle
20117	highlander s leather girdle
20118	highlander s mail girdle
20119	highlander s mail girdle
20120	highlander s mail girdle
20121	highlander s mail greaves
20122	highlander s mail greaves
20123	highlander s mail greaves
20124	highlander s plate girdle
20125	highlander s plate girdle
20126	highlander s mail girdle
20127	highlander s plate greaves
20128	highlander s plate greaves
20129	highlander s mail greaves
20130	diamond flask
20131	battle tabard of the defilers
20132	arathor battle tabard
20134	skyfury helm
20150	defiler s chain girdle
20151	defiler s chain girdle
20152	defiler s chain girdle
20153	defiler s chain girdle
20154	defiler s chain greaves
20155	defiler s chain greaves
20156	defiler s chain greaves
20157	defiler s chain greaves
20158	defiler s chain pauldrons
20159	defiler s cloth boots
20160	defiler s cloth boots
20161	defiler s cloth boots
20162	defiler s cloth boots
20163	defiler s cloth girdle
20164	defiler s cloth girdle
20165	defiler s cloth girdle
20166	defiler s cloth girdle
20167	defiler s lizardhide boots
20168	defiler s lizardhide boots
20169	defiler s lizardhide boots
20170	defiler s lizardhide boots
20171	defiler s lizardhide girdle
20172	defiler s lizardhide girdle
20173	defiler s lizardhide girdle
20174	defiler s lizardhide girdle
20175	defiler s lizardhide shoulders
20176	defiler s epaulets
20177	defiler s lamellar girdle
20178	defiler s lamellar girdle
20179	defiler s lamellar girdle
20180	defiler s lamellar girdle
20181	defiler s lamellar greaves
20182	defiler s lamellar greaves
20183	defiler s lamellar greaves
20184	defiler s lamellar spaulders
20185	defiler s lamellar greaves
20186	defiler s leather boots
20187	defiler s leather boots
20188	defiler s leather boots
20189	defiler s leather boots
20190	defiler s leather girdle
20191	defiler s leather girdle
20192	defiler s leather girdle
20193	defiler s leather girdle
20194	defiler s leather shoulders
20195	defiler s mail girdle
20196	defiler s mail girdle
20197	defiler s padded girdle
20198	defiler s mail girdle
20199	defiler s mail greaves
20200	defiler s mail greaves
20201	defiler s mail greaves
20202	defiler s mail greaves
20203	defiler s mail pauldrons
20204	defiler s plate girdle
20205	defiler s plate girdle
20206	defiler s plate girdle
20207	defiler s mail girdle
20208	defiler s plate greaves
20209	defiler s plate greaves
20210	defiler s mail greaves
20211	defiler s plate greaves
20212	defiler s plate spaulders
20213	belt of shrunken heads
20214	mindfang
20215	belt of shriveled heads
20216	belt of preserved heads
20217	belt of tiny heads
20218	faded hakkari cloak
20219	tattered hakkari cape
20220	ironbark staff
20222	defiler s enriched ration
20223	defiler s field ration
20224	defiler s iron ration
20225	highlander s enriched ration
20226	highlander s field ration
20227	highlander s iron ration
20228	defiler s advanced care package
20229	defiler s basic care package
20230	defiler s standard care package
20231	arathor advanced care package
20232	defiler s mageweave bandage
20233	arathor basic care package
20234	defiler s runecloth bandage
20235	defiler s silk bandage
20236	arathor standard care package
20237	highlander s mageweave bandage
20243	highlander s runecloth bandage
20244	highlander s silk bandage
20253	pattern warbear harness
20254	pattern warbear woolies
20255	whisperwalk boots
20256	warsong gulch ribbon of sacrifice
20257	seafury gauntlets
20258	zulian ceremonial staff
20259	shadow panther hide gloves
20260	seafury leggings
20261	shadow panther hide belt
20262	seafury boots
20263	gurubashi helm
20264	peacekeeper gauntlets
20265	peacekeeper boots
20266	peacekeeper leggings
20295	blue dragonscale leggings
20296	green dragonscale gauntlets
20310	flayed demon skin
20337	gnome head on a stick
20367	hunting gear
20368	bland bow of steadiness
20369	azurite fists
20371	blue murloc egg
20373	stonelash scorpid stinger
20374	stonelash pincer stinger
20375	stonelash flayer stinger
20376	sand skitterer fang
20377	rock stalker fang
20378	twilight tablet fragment
20379	noggle s satchel
20380	dreamscale breastplate
20381	dreamscale
20382	pattern dreamscale breastplate
20383	head of the broodlord lashlayer
20384	silithid carapace fragment
20385	deathclasp s pincer
20387	forsaken stink bomb cluster
20388	lollipop
20389	candy corn
20390	candy bar
20391	flimsy male gnome mask
20392	flimsy female gnome mask
20393	treat bag
20394	twilight lexicon chapter 1
20395	twilight lexicon chapter 2
20396	twilight lexicon chapter 3
20397	hallowed wand pirate
20398	hallowed wand ninja
20399	hallowed wand leper gnome
20400	pumpkin bag
20401	restored twilight tablet
20402	agent of nozdormu
20403	proxy of nozdormu
20404	encrypted twilight text
20405	decoded tablet transcription
20406	twilight cultist mantle
20407	twilight cultist robe
20408	twilight cultist cowl
20409	hallowed wand ghost
20410	hallowed wand bat
20411	hallowed wand skeleton
20413	hallowed wand random
20414	hallowed wand wisp
20415	the war of the shifting sands
20416	crest of beckoning fire
20418	crest of beckoning thunder
20419	crest of beckoning stone
20420	crest of beckoning water
20422	twilight cultist medallion of station
20423	sandy scorpid claw
20424	sandworm meat
20425	advisor s gnarled staff
20426	advisor s ring
20427	battle healer s cloak
20428	caretaker s cape
20429	legionnaire s band
20430	legionnaire s sword
20431	lorekeeper s ring
20432	signet of beckoning fire
20433	signet of beckoning thunder
20434	lorekeeper s staff
20435	signet of beckoning stone
20436	signet of beckoning water
20437	outrider s bow
20438	outrunner s bow
20439	protector s band
20440	protector s sword
20441	scout s blade
20442	scout s medallion
20443	sentinel s blade
20444	sentinel s medallion
20447	scepter of beckoning fire
20448	scepter of beckoning thunder
20449	scepter of beckoning stone
20450	scepter of beckoning water
20451	twilight cultist ring of lordship
20452	smoked desert dumplings
20453	geologist s transcription kit
20454	hive zora rubbing
20455	hive ashi rubbing
20456	hive regal rubbing
20457	hive ashi silithid brain
20458	hive zora silithid brain
20459	hive regal silithid brain
20460	brann bronzebeard s lost letter
20461	brann bronzebeard s lost letter
20463	glyphed crystal prism
20464	glyphs of calling
20465	crystal unlocking mechanism
20466	vyral s signet ring
20467	torn recipe page
20469	decoded true believer clippings
20470	solanian s scrying orb
20471	scroll of scourge magic
20472	solanian s journal
20473	the arcanist s compendium volume 4
20474	sunstrider book satchel
20475	adamantite arrow maker
20476	sandstalker bracers
20477	sandstalker gauntlets
20478	sandstalker breastplate
20479	spitfire breastplate
20480	spitfire gauntlets
20481	spitfire bracers
20482	arcane sliver
20483	tainted arcane sliver
20485	duke s seal
20487	lok delar stave of the ancient keepers dep
20488	rhok delar longbow of the ancient keepers dep
20489	crown of the council
20490	ironforge mint
20491	undercity mint
20492	stormwind nougat
20493	orgrimmar nougat
20494	gnomeregan gumdrop
20495	darkspear gumdrop
20496	darnassus marzipan
20497	thunder bluff marzipan
20498	silithid chitin
20499	broken silithid chitin
20500	light silithid carapace
20501	heavy silithid carapace
20502	ironbark shield
20503	enamored water spirit
20504	lightforged blade
20505	chivalrous signet
20506	pattern spitfire bracers
20507	pattern spitfire gauntlets
20508	pattern spitfire breastplate
20509	pattern sandstalker bracers
20510	pattern sandstalker gauntlets
20511	pattern sandstalker breastplate
20512	sanctified orb
20513	abyssal crest
20514	abyssal signet
20515	abyssal scepter
20516	bobbing apple
20517	razorsteel shoulders
20518	scroll create crest of beckoning
20519	southsea pirate hat
20520	dark rune
20521	fury visor
20522	feral staff
20524	shadowhide leggings
20525	earthen sigil
20526	scroll create crest of beckoning
20527	scroll create crest of beckoning
20528	scroll create crest of beckoning
20530	robes of servitude
20531	scroll create signet of beckoning
20532	scroll create signet of beckoning
20533	scroll create signet of beckoning
20534	abyss shard
20535	scroll create signet of beckoning
20536	soul harvester
20537	runed stygian boots
20538	runed stygian leggings
20539	runed stygian belt
20540	scroll create scepter of beckoning
20541	decoded twilight text
20542	scroll create scepter of beckoning
20543	scroll create scepter of beckoning
20544	scroll create scepter of beckoning
20545	decoded twilight text
20546	pattern runed stygian leggings
20547	pattern runed stygian boots
20548	pattern runed stygian belt
20549	darkrune gauntlets
20550	darkrune breastplate
20551	darkrune helm
20552	decoded twilight text
20553	plans darkrune gauntlets
20554	plans darkrune breastplate
20555	plans darkrune helm
20556	wildstaff
20557	hallow s end pumpkin treat
20558	warsong gulch mark of honor
20559	arathi basin mark of honor
20560	alterac valley mark of honor
20561	flimsy male dwarf mask
20562	flimsy female dwarf mask
20563	flimsy female nightelf mask
20564	flimsy male nightelf mask
20565	flimsy female human mask
20566	flimsy male human mask
20567	flimsy female troll mask
20568	flimsy male troll mask
20569	flimsy female orc mask
20570	flimsy male orc mask
20571	flimsy female tauren mask
20572	flimsy male tauren mask
20573	flimsy male undead mask
20574	flimsy female undead mask
20575	black whelp tunic
20576	pattern black whelp tunic
20577	nightmare blade
20578	emerald dragonfang
20579	green dragonskin cloak
20580	hammer of bestial fury
20581	staff of rampant growth
20582	trance stone
20583	sturdy female dwarf mask
20584	sturdy female gnome mask
20585	sturdy female human mask
20586	sturdy female night elf mask
20587	sturdy female orc mask
20588	sturdy female tauren mask
20589	sturdy female troll mask
20590	sturdy female undead mask
20591	sturdy male dwarf mask
20592	sturdy male gnome mask
20593	sturdy male human mask
20594	sturdy male night elf mask
20595	sturdy male orc mask
20596	sturdy male tauren mask
20597	sturdy male troll mask
20598	sturdy male undead mask
20599	polished ironwood crossbow
20600	malfurion s signet ring
20601	sack of spoils
20602	chest of spoils
20603	bag of spoils
20604	stink bomb cleaner
20605	rotten eggs
20606	amber voodoo feather
20607	blue voodoo feather
20608	green voodoo feather
20609	voodoo feathers
20610	bloodshot spider eye
20611	thick black claw
20612	inert scourgestone
20613	rotting wood
20614	bloodvenom essence
20615	dragonspur wraps
20616	dragonbone wristguards
20617	ancient corroded leggings
20618	gloves of delusional power
20619	acid inscribed greaves
20620	holy mightstone
20621	boots of the endless moor
20622	dragonheart necklace
20623	circlet of restless dreams
20624	ring of the unliving
20625	belt of the dark bog
20626	black bark wristbands
20627	dark heart pants
20628	deviate growth cap
20629	malignant footguards
20630	gauntlets of the shining light
20631	mendicant s slippers
20632	mindtear band
20633	unnatural leather spaulders
20634	boots of fright
20635	jade inlaid vestments
20636	hibernation crystal
20637	acid inscribed pauldrons
20638	leggings of the demented mind
20639	strangely glyphed legplates
20640	southsea head bucket
20641	southsea mojo boots
20642	antiquated nobleman s tunic
20643	undercity reservist s cap
20644	nightmare engulfed object
20645	nature s whisper
20646	sandstrider s mark
20647	black crystal dagger
20648	cold forged hammer
20649	sunprism pendant
20650	desert wind gauntlets
20651	orange murloc egg
20652	abyssal cloth slippers
20653	abyssal plate gauntlets
20654	amethyst war staff
20655	abyssal cloth handwraps
20656	abyssal mail sabatons
20657	crystal tipped stiletto
20658	abyssal leather boots
20659	abyssal mail handguards
20660	stonecutting glaive
20661	abyssal leather gloves
20662	abyssal plate greaves
20663	deep strike bow
20664	abyssal cloth sash
20665	abyssal leather leggings
20666	hardened steel warhammer
20667	abyssal leather belt
20668	abyssal mail legguards
20669	darkstone claymore
20670	abyssal mail clutch
20671	abyssal plate legplates
20672	sparkling crystal wand
20673	abyssal plate girdle
20674	abyssal cloth pants
20675	soulrender
20676	decoded twilight text
20677	decoded twilight text
20678	decoded twilight text
20679	decoded twilight text
20680	abyssal mail pauldrons
20681	abyssal leather bracers
20682	elemental focus band
20683	abyssal plate epaulets
20684	abyssal mail armguards
20685	wavefront necklace
20686	abyssal cloth amice
20687	abyssal plate vambraces
20688	earthen guard
20689	abyssal leather shoulders
20690	abyssal cloth wristbands
20691	windshear cape
20692	multicolored band
20693	weighted cloak
20694	glowing black orb
20695	abyssal war beads
20696	crystal spiked maul
20697	crystalline threaded cape
20698	elemental attuned blade
20699	cenarion reservist s legplates
20700	cenarion reservist s legplates
20701	cenarion reservist s legguards
20702	cenarion reservist s legguards
20703	cenarion reservist s leggings
20704	cenarion reservist s leggings
20705	cenarion reservist s pants
20706	cenarion reservist s pants
20707	cenarion reservist s pants
20708	tightly sealed trunk
20709	rumsey rum light
20710	crystal encrusted greaves
20711	crystal lined greaves
20712	wastewalker s gauntlets
20713	desertstalkers s gauntlets
20714	sandstorm boots
20715	dunestalker s boots
20716	sandworm skin gloves
20717	desert bloom gloves
20720	dark whisper blade
20721	band of the cultist
20722	crystal slugthrower
20723	brann s trusty pick
20724	corrupted blackwood staff
20725	nexus crystal
20726	formula enchant gloves threat
20727	formula enchant gloves shadow power
20728	formula enchant gloves frost power
20729	formula enchant gloves fire power
20730	formula enchant gloves healing power
20731	formula enchant gloves superior agility
20732	formula enchant cloak greater fire resistance
20733	formula enchant cloak greater nature resistance
20734	formula enchant cloak stealth
20735	formula enchant cloak subtlety
20736	formula enchant cloak dodge
20737	singed corestone
20741	deadwood ritual totem
20742	winterfall ritual totem
20743	unstable mana crystal
20744	minor wizard oil
20745	minor mana oil
20746	lesser wizard oil
20747	lesser mana oil
20748	brilliant mana oil
20749	brilliant wizard oil
20750	wizard oil
20752	formula minor mana oil
20753	formula lesser wizard oil
20754	formula lesser mana oil
20755	formula wizard oil
20756	formula brilliant wizard oil
20757	formula brilliant mana oil
20758	formula minor wizard oil
20759	otembe s hammer
20760	chieftain zul marosh s head
20761	recipe transmute elemental fire
20763	broken weapon
20764	prospector anvilward s head
20765	incriminating documents
20766	slimy bag
20767	scum covered bag
20768	oozing bag
20769	disgusting oozeling
20770	bubbling green ichor
20771	tainted soil sample
20772	springpaw pelt
20797	lynx collar
20798	intact arcane converter
20799	felendren s head
20800	cenarion logistics badge
20801	cenarion tactical badge
20802	cenarion combat badge
20803	twilight battle orders
20804	erona s package
20805	followup logistics assignment
20806	logistics task briefing x
20807	logistics task briefing i
20808	combat assignment
20809	tactical assignment
20810	signed field duty papers
20812	tattered pelt
20813	lynx tooth
20814	broken master s throwing dagger
20815	jeweler s kit
20816	delicate copper wire
20817	bronze setting
20818	elegant silver ring
20819	cut malachite
20820	simple pearl ring
20821	inlaid malachite ring
20822	cut tigerseye
20823	gloom band
20824	simple grinder
20825	cut shadowgem
20826	heavy silver ring
20827	ring of silver might
20828	ring of twilight shadows
20829	cut moonstone
20830	amulet of the moon
20831	heavy golden necklace of battle
20832	moonsoul crown
20833	wicked moonstone ring
20834	ornate spyglass xt
20835	sunstrider sword
20836	sunstrider dagger
20837	sunstrider axe
20838	sunstrider bow
20839	sunstrider staff
20840	sunstrider mace
20841	sunstrider shield
20842	frayed tender vine
20843	smashed petal
20844	deadly poison v
20845	torn wyrm scale
20846	faintly glowing eye
20847	wraith fragment
20848	sparkling dust
20849	arcane forged shortsword
20850	arcane forged axe
20851	arcane forged mace
20852	arcane forged dirk
20853	mana gathering staff
20854	design amulet of the moon
20855	design wicked moonstone ring
20856	design heavy golden necklace of battle
20857	honey bread
20858	stone scarab
20859	gold scarab
20860	silver scarab
20861	bronze scarab
20862	crystal scarab
20863	clay scarab
20864	bone scarab
20865	ivory scarab
20866	azure idol
20867	onyx idol
20868	lambent idol
20869	amber idol
20870	jasper idol
20871	obsidian idol
20872	vermillion idol
20873	alabaster idol
20874	idol of the sun
20875	idol of night
20876	idol of death
20877	idol of the sage
20878	idol of rebirth
20879	idol of life
20881	idol of strife
20882	idol of war
20883	qiraji glyphed jewel
20884	qiraji magisterial ring
20885	qiraji martial drape
20886	qiraji spiked hilt
20887	qiraji engraved jewel
20888	qiraji ceremonial ring
20889	qiraji regal drape
20890	qiraji ornate hilt
20891	neophyte s robe
20892	acolyte s robe
20893	apprentice s robe
20894	apprentice s pants
20895	apprentice s boots
20896	lookout s pants
20897	lookout s tunic
20898	lookout s shoes
20899	warder s pants
20900	warder s boots
20901	warder s shirt
20902	recruit s pants
20903	recruit s boots
20904	recruit s tunic
20906	braided copper ring
20907	solid bronze ring
20908	festival of nian firework
20909	barbaric iron collar
20910	stiff shortbow
20911	light guard
20912	large shield
20913	medium guard
20914	unadorned chain belt
20915	unadorned chain boots
20916	unadorned chain bracers
20917	unadorned chain gloves
20918	unadorned chain leggings
20919	unadorned chain vest
20920	sun cured belt
20921	sun cured boots
20922	sun cured bracers
20923	sun cured gloves
20924	sun cured pants
20925	sun cured vest
20926	vek nilash s circlet
20927	ouro s intact hide
20928	qiraji bindings of command
20930	vek lor s diadem
20931	skin of the great sandworm
20932	qiraji bindings of dominance
20934	wraith essence
20935	tainted wraith essence
20936	qiraji blessed jewel
20937	qiraji encased jewel
20938	sunstrider isle gift voucher
20939	logistics task briefing ii
20940	logistics task briefing iii
20941	combat task briefing xii
20942	combat task briefing iii
20943	tactical task briefing x
20944	tactical task briefing ix
20945	tactical task briefing ii
20946	tactical task briefing iii
20947	tactical task briefing iv
20948	tactical task briefing v
20949	magical ledger
20950	pendant of the agate shield
20951	narain s scrying goggles
20952	cut agate
20953	cut jade
20954	heavy iron knuckles
20955	golden dragon ring
20956	silver rose pendant
20957	cut citrine
20958	blazing citrine ring
20959	the jade eye
20960	engraved truesilver ring
20961	citrine ring of rapid healing
20962	cut aquamarine
20963	mithril filigree
20964	aquamarine signet
20965	cut ruby
20966	jade pendant of blasting
20967	citrine pendant of golden healing
20969	ruby crown of restoration
20970	design pendant of the agate shield
20971	design heavy iron knuckles
20972	design silver rose pendant
20973	design blazing citrine ring
20974	design jade pendant of blasting
20975	design the jade eye
20976	design citrine pendant of golden healing
20977	recruit s shortsword
20978	new bent staff
20979	warder s axe
20980	warder s shortbow
20981	neophyte s mace
20982	sharp dagger
20983	acolyte s dagger
20984	recruit s shield
20985	light cloth shoes
20986	light cloth pants
20987	light cloth gloves
20988	light cloth bracers
20989	light cloth belt
20990	light cloth armor
20991	daylight cloak
20992	sunrise bracers
20993	lynxskin gloves
20994	green chain vest
20995	well watcher gloves
20996	sunspire cord
20997	green chain boots
20998	wyrm sash
20999	green chain gauntlets
21000	vigorous bracers
21001	striding pants
21002	unkempt belt
21003	unkempt bracers
21004	unkempt cloak
21005	unkempt gloves
21006	unkempt pants
21007	unkempt robe
21008	unkempt shoes
21009	scraggy leather belt
21010	scraggy leather boots
21011	scraggy leather bracers
21012	scraggy leather gloves
21013	scraggy leather pants
21014	scraggy leather vest
21015	shoddy chain belt
21016	shoddy chain vest
21017	shoddy chain pants
21018	shoddy chain gloves
21019	shoddy chain bracers
21020	shoddy chain boots
21021	battered shield
21022	weather beaten buckler
21023	dirge s kickin chimaerok chops
21024	chimaerok tenderloin
21025	recipe dirge s kickin chimaerok chops
21026	oracle sphere
21027	lakmaeran s carcass
21028	500 pound chicken
21029	ransom letter
21030	darnassus kimchi pie
21031	cabbage kimchi
21032	meridith s love letter
21033	radish kimchi
21037	crude map
21038	hardpacked snowball
21039	narain s turban
21040	narain s robe
21041	bag of gold
21042	narain s special kit
21043	mysterious envelope
21071	raw sagefish
21072	smoked sagefish
21099	recipe smoked sagefish
21100	coin of ancestry
21103	draconic for dummies
21104	draconic for dummies
21105	draconic for dummies
21106	draconic for dummies
21107	draconic for dummies
21108	draconic for dummies
21109	draconic for dummies
21110	draconic for dummies
21111	draconic for dummies volume ii
21112	magical book binding
21113	watertight trunk
21114	rumsey rum dark
21115	defiler s talisman
21116	defiler s talisman
21117	talisman of arathor
21118	talisman of arathor
21119	talisman of arathor
21120	defiler s talisman
21126	death s sting
21128	staff of the qiraji prophets
21130	diary of weavil
21131	followup combat assignment
21132	logistics assignment
21133	followup tactical assignment
21134	dark edge of insanity
21135	broken assassin s throwing axe
21136	arcanite buoy
21137	blue scepter shard
21138	red scepter shard
21139	green scepter shard
21140	auction stationery
21141	destroyed red scepter shard
21142	from the desk of lord victor nefarius
21143	unsigned field duty papers
21144	demon summoning torch
21145	essence of xandivious
21146	fragment of the nightmare s corruption
21147	fragment of the nightmare s corruption
21148	fragment of the nightmare s corruption
21149	fragment of the nightmare s corruption
21150	iron bound trunk
21151	rumsey rum black label
21152	the nightmare s corruption
21153	raw greater sagefish
21154	festival dress
21155	timbermaw offering of peace
21156	scarab bag
21157	festive green dress
21158	hive zora scout report
21159	hive zora scout orders
21160	hive regal scout report
21161	hive ashi scout report
21162	bloated oily blackmouth
21163	bloated firefin
21164	bloated rockscale cod
21165	tactical task briefing vi
21166	tactical task briefing vii
21167	tactical task briefing viii
21168	baby shark
21171	filled festive mug
21173	empty festive mug
21174	empty festive mug
21175	the scepter of the shifting sands
21176	black qiraji resonating crystal
21177	symbol of kings
21178	gloves of earthen power
21179	band of earthen wrath
21180	earthstrike
21181	grace of earth
21182	band of earthen might
21183	earthpower vest
21184	deeprock bracers
21185	earthcalm orb
21186	rockfury bracers
21187	earthweave cloak
21188	fist of cenarius
21189	might of cenarius
21190	wrath of cenarius
21191	carefully wrapped present
21193	d sak s sack
21194	d sak s big sack
21195	d sak s sacktastic
21196	signet ring of the bronze dragonflight
21197	signet ring of the bronze dragonflight
21198	signet ring of the bronze dragonflight
21199	signet ring of the bronze dragonflight
21200	signet ring of the bronze dragonflight
21201	signet ring of the bronze dragonflight
21202	signet ring of the bronze dragonflight
21203	signet ring of the bronze dragonflight
21204	signet ring of the bronze dragonflight
21205	signet ring of the bronze dragonflight
21206	signet ring of the bronze dragonflight
21207	signet ring of the bronze dragonflight
21208	signet ring of the bronze dragonflight
21209	signet ring of the bronze dragonflight
21210	signet ring of the bronze dragonflight
21211	pouch of reindeer dust
21212	fresh holly
21213	preserved holly
21214	tome of frostbolt xi
21215	graccu s mince meat fruitcake
21216	smokywood pastures extra special gift
21217	sagefish delight
21218	blue qiraji resonating crystal
21219	recipe sagefish delight
21220	head of ossirian the unscarred
21221	eye of c thun
21222	armored chitin
21223	black stone
21224	ancient armor fragment
21225	heavy silithid husk
21226	runic stone
21227	ancient hero s skull
21228	mithril bound trunk
21229	qiraji lord s insignia
21230	ancient qiraji artifact
21232	imperial qiraji armaments
21235	winter veil roast
21236	winter veil loaf
21237	imperial qiraji regalia
21240	winter veil candy
21241	winter veil eggnog
21242	blessed qiraji war axe
21243	bloated mightfish
21244	blessed qiraji pugio
21245	tactical task briefing i
21246	combat task briefing i
21247	combat task briefing ii
21248	combat task briefing iv
21249	combat task briefing v
21250	combat task briefing vi
21251	combat task briefing vii
21252	combat task briefing viii
21253	combat task briefing ix
21254	winter veil cookie
21255	combat task briefing x
21256	combat task briefing xi
21257	logistics task briefing iv
21258	logistics task briefing iv
21259	logistics task briefing v
21260	logistics task briefing vi
21261	logistics task briefing vi
21262	logistics task briefing viii
21263	logistics task briefing vii
21264	logistics task briefing vii
21265	logistics task briefing ix
21266	logistics assignment
21267	toasting goblet
21268	blessed qiraji war hammer
21269	blessed qiraji bulwark
21270	gently shaken gift
21271	gently shaken gift
21272	blessed qiraji musket
21273	blessed qiraji acolyte staff
21275	blessed qiraji augur staff
21277	tranquil mechanical yeti
21278	stormshroud gloves
21279	tome of fireball xii
21280	tome of arcane missiles viii
21281	grimoire of shadow bolt x
21282	grimoire of immolate viii
21283	grimoire of corruption vii
21284	codex of greater heal v
21285	codex of renew x
21287	codex of prayer of healing v
21288	libram blessing of wisdom vi
21289	libram blessing of might vii
21290	libram holy light ix
21291	tablet of healing wave x
21292	tablet of strength of earth totem v
21293	tablet of grace of air totem iii
21294	book of healing touch xi
21295	book of starfire vii
21296	book of rejuvenation xi
21297	manual of heroic strike ix
21298	manual of battle shout vii
21299	manual of revenge vi
21300	handbook of backstab ix
21301	green helper box
21302	handbook of deadly poison v
21303	handbook of feint v
21304	guide multi shot v
21305	red helper box
21306	guide serpent sting ix
21307	guide aspect of the hawk vii
21308	jingling bell
21309	snowman kit
21310	gaily wrapped present
21311	earth warder s vest
21312	belt of the den watcher
21313	d sak s small bag
21314	metzen s letters and notes
21315	smokywood satchel
21316	leggings of the ursa
21317	helm of the pathfinder
21318	earth warder s gloves
21319	gloves of the pathfinder
21320	vest of the den watcher
21321	red qiraji resonating crystal
21322	ursa s embrace
21323	green qiraji resonating crystal
21324	yellow qiraji resonating crystal
21325	mechanical greench
21326	defender of the timbermaw
21327	ticking present
21328	wand of holiday cheer
21329	conqueror s crown
21330	conqueror s spaulders
21331	conqueror s breastplate
21332	conqueror s legguards
21333	conqueror s greaves
21334	doomcaller s robes
21335	doomcaller s mantle
21336	doomcaller s trousers
21337	doomcaller s circlet
21338	doomcaller s footwraps
21340	soul pouch
21341	felcloth bag
21342	core felcloth bag
21343	enigma robes
21344	enigma boots
21345	enigma shoulderpads
21346	enigma leggings
21347	enigma circlet
21348	tiara of the oracle
21349	footwraps of the oracle
21350	mantle of the oracle
21351	vestments of the oracle
21352	trousers of the oracle
21353	genesis helm
21354	genesis shoulderpads
21355	genesis boots
21356	genesis trousers
21357	genesis vest
21358	pattern soul pouch
21359	deathdealer s boots
21360	deathdealer s helm
21361	deathdealer s spaulders
21362	deathdealer s leggings
21363	festive gift
21364	deathdealer s vest
21365	striker s footguards
21366	striker s diadem
21367	striker s pauldrons
21368	striker s leggings
21369	pattern felcloth bag
21370	striker s hauberk
21371	pattern core felcloth bag
21372	stormcaller s diadem
21373	stormcaller s footguards
21374	stormcaller s hauberk
21375	stormcaller s leggings
21376	stormcaller s pauldrons
21377	deadwood headdress feather
21378	logistics task briefing i
21379	logistics task briefing ii
21380	logistics task briefing iii
21381	logistics task briefing ix
21382	logistics task briefing v
21383	winterfall spirit beads
21384	logistics task briefing viii
21385	logistics task briefing x
21386	followup logistics assignment
21387	avenger s crown
21388	avenger s greaves
21389	avenger s breastplate
21390	avenger s legguards
21391	avenger s pauldrons
21392	sickle of unyielding strength
21393	signet of unyielding strength
21394	drape of unyielding strength
21395	blade of eternal justice
21396	ring of eternal justice
21397	cape of eternal justice
21398	hammer of the gathering storm
21399	ring of the gathering storm
21400	cloak of the gathering storm
21401	scythe of the unseen path
21402	signet of the unseen path
21403	cloak of the unseen path
21404	dagger of veiled shadows
21405	band of veiled shadows
21406	cloak of veiled shadows
21407	mace of unending life
21408	band of unending life
21409	cloak of unending life
21410	gavel of infinite wisdom
21411	ring of infinite wisdom
21412	shroud of infinite wisdom
21413	blade of vaulted secrets
21414	band of vaulted secrets
21415	drape of vaulted secrets
21416	kris of unspoken names
21417	ring of unspoken names
21418	shroud of unspoken names
21436	alliance commendation signet
21438	horde commendation signet
21452	staff of the ruins
21453	mantle of the horusath
21454	runic stone shoulders
21455	southwind helm
21456	sandstorm cloak
21457	bracers of brutality
21458	gauntlets of new life
21459	crossbow of imminent doom
21460	helm of domination
21461	leggings of the black blizzard
21462	gloves of dark wisdom
21463	ossirian s binding
21464	shackles of the unscarred
21466	stinger of ayamiss
21467	thick silithid chestguard
21468	mantle of maz nadir
21469	gauntlets of southwind
21470	cloak of the savior
21471	talon of furious concentration
21472	dustwind turban
21473	eye of moam
21474	chitinous shoulderguards
21475	legplates of the destroyer
21476	obsidian scaled leggings
21477	ring of fury
21478	bow of taut sinew
21479	gauntlets of the immovable
21480	scaled silithid gauntlets
21481	boots of the desert protector
21482	boots of the fiery sands
21483	ring of the desert winds
21484	helm of regrowth
21485	buru s skull fragment
21486	gloves of the swarm
21487	slimy scaled gauntlets
21488	fetish of chitinous spikes
21489	quicksand waders
21490	slime kickers
21491	scaled bracers of the gorger
21492	manslayer of the qiraji
21493	boots of the vanguard
21494	southwind s grasp
21495	legplates of the qiraji command
21496	bracers of qiraji command
21497	boots of the qiraji general
21498	qiraji sacrificial dagger
21499	vestments of the shifting sands
21500	belt of the inquisition
21501	toughened silithid hide gloves
21502	sand reaver wristguards
21503	belt of the sand reaver
21504	charm of the shifting sands
21505	choker of the shifting sands
21506	pendant of the shifting sands
21507	amulet of the shifting sands
21508	mark of cenarius
21509	ahn qiraj war effort supplies
21510	ahn qiraj war effort supplies
21511	ahn qiraj war effort supplies
21512	ahn qiraj war effort supplies
21513	ahn qiraj war effort supplies
21514	logistics task briefing xi
21515	mark of remulos
21517	gnomish turban of psychic might
21519	mistletoe
21520	ravencrest s legacy
21521	runesword of the red
21522	shadowsong s sorrow
21523	fang of korialstrasz
21524	red winter hat
21525	green winter hat
21526	band of icy depths
21527	darkwater robes
21528	colossal bag of loot
21529	amulet of shadow shielding
21530	onyx embedded leggings
21531	drake tooth necklace
21532	drudge boots
21533	colossus of zora s husk
21534	colossus of ashi s husk
21535	colossus of regal s husk
21536	elune stone
21537	festival dumplings
21538	festive pink dress
21539	festive purple dress
21540	elune s lantern
21541	festive black pant suit
21542	festival suit
21543	festive teal pant suit
21544	festive blue pant suit
21545	smokywood supplies
21546	elixir of greater firepower
21547	recipe elixir of greater firepower
21548	pattern stormshroud gloves
21552	striped yellowtail
21557	small red rocket
21558	small blue rocket
21559	small green rocket
21560	small purple rocket
21561	small white rocket
21562	small yellow rocket
21563	don rodrigo s band
21565	rune of perfection
21566	rune of perfection
21567	rune of duty
21568	rune of duty
21569	firework launcher
21570	cluster launcher
21571	blue rocket cluster
21574	green rocket cluster
21575	purple rocket cluster
21576	red rocket cluster
21577	white rocket cluster
21578	yellow rocket cluster
21579	vanquished tentacle of c thun
21581	gauntlets of annihilation
21583	cloak of clarity
21584	bracers of eternal reckoning
21585	dark storm gauntlets
21586	belt of never ending agony
21587	wristguards of castigation
21588	wristguards of elemental fury
21589	large blue rocket
21590	large green rocket
21591	large purple rocket
21592	large red rocket
21593	large white rocket
21594	bracers of the fallen son
21595	large yellow rocket
21596	ring of the godslayer
21597	royal scepter of vek lor
21598	royal qiraji belt
21599	vek lor s gloves of devastation
21600	boots of epiphany
21601	ring of emperor vek lor
21602	qiraji execution bracers
21603	wand of qiraji nobility
21604	bracelets of royal redemption
21605	gloves of the hidden temple
21606	belt of the fallen emperor
21607	grasp of the fallen emperor
21608	amulet of vek nilash
21609	regenerating belt of vek nilash
21610	wormscale blocker
21611	burrower bracers
21612	wormscale stompers
21613	wormhide boots
21614	wormhide protector
21615	don rigoberto s lost hat
21616	huhuran s stinger
21617	wasphide gauntlets
21618	hive defiler wristguards
21619	gloves of the messiah
21620	ring of the martyr
21621	cloak of the golden hive
21622	sharpened silithid femur
21623	gauntlets of the righteous champion
21624	gauntlets of kalimdor
21625	scarab brooch
21626	slime coated leggings
21627	cloak of untold secrets
21635	barb of the sand reaver
21639	pauldrons of the unrelenting
21640	lunar festival fireworks pack
21645	hive tunneler s boots
21647	fetish of the sand reaver
21648	recomposed boots
21650	ancient qiraji ripper
21651	scaled sand reaver leggings
21652	silithid carapace chestguard
21663	robes of the guardian saint
21664	barbed choker
21665	mantle of wicked revenge
21666	sartura s might
21667	legplates of blazing light
21668	scaled leggings of qiraji fury
21669	creeping vine helm
21670	badge of the swarmguard
21671	robes of the battleguard
21672	gloves of enforcement
21673	silithid claw
21674	gauntlets of steadfast determination
21675	thick qirajihide belt
21676	leggings of the festering swarm
21677	ring of the qiraji fury
21678	necklace of purity
21679	kalimdor s revenge
21680	vest of swift execution
21681	ring of the devoured
21682	bile covered gauntlets
21683	mantle of the desert crusade
21684	mantle of the desert s fury
21685	petrified scarab
21686	mantle of phrenic power
21687	ukko s ring of darkness
21688	boots of the fallen hero
21689	gloves of ebru
21690	angelista s charm
21691	ooze ridden gauntlets
21692	triad girdle
21693	guise of the devourer
21694	ternary mantle
21695	angelista s touch
21696	robes of the triumvirate
21697	cape of the trinity
21698	leggings of immersion
21699	barrage shoulders
21700	pendant of the qiraji guardian
21701	cloak of concentrated hatred
21702	amulet of foul warding
21703	hammer of ji zhi
21704	boots of the redeemed prophecy
21705	boots of the fallen prophet
21706	boots of the unwavering will
21707	ring of swarming thought
21708	beetle scaled wristguards
21709	ring of the fallen god
21710	cloak of the fallen god
21711	lunar festival invitation
21712	amulet of the fallen god
21713	elune s candle
21714	large blue rocket cluster
21715	sand polished hammer
21716	large green rocket cluster
21717	large purple rocket cluster
21718	large red rocket cluster
21719	large white rocket cluster
21720	large yellow rocket cluster
21721	moonglow
21722	pattern festival dress
21723	pattern festival suit
21724	schematic small blue rocket
21725	schematic small green rocket
21726	schematic small red rocket
21727	schematic large blue rocket
21728	schematic large green rocket
21729	schematic large red rocket
21730	schematic blue rocket cluster
21731	schematic green rocket cluster
21732	schematic red rocket cluster
21733	schematic large blue rocket cluster
21734	schematic large green rocket cluster
21735	schematic large red rocket cluster
21736	nether drake reins
21737	schematic cluster launcher
21738	schematic firework launcher
21739	lunar festival invitation debug
21740	small rocket recipes
21741	cluster rocket recipes
21742	large rocket recipes
21743	large cluster rocket recipes
21744	lucky rocket cluster
21745	elder s moonstone
21746	lucky red envelope
21747	festival firecracker
21748	figurine jade owl
21749	combat task briefing i
21750	combat task briefing ii
21751	tactical task briefing iii
21752	thorium setting
21753	gem studded band
21754	the aquamarine ward
21755	aquamarine pendant of the warrior
21756	figurine golden hare
21757	grimscale murloc head
21758	figurine black pearl panther
21760	figurine truesilver crab
21761	scarab coffer key
21762	greater scarab coffer key
21763	figurine truesilver boar
21764	ruby pendant of fire
21765	truesilver healing ring
21766	opal necklace of impact
21767	simple opal ring
21768	sapphire signet
21769	figurine ruby serpent
21770	ring of mmmrrrggglll
21771	captain kelisendra s cargo
21772	cut sapphire
21773	cut opal
21774	emerald crown of destruction
21775	onslaught ring
21776	captain kelisendra s lost rutters
21777	figurine emerald owl
21778	ring of bitter shadows
21779	band of natural fire
21780	blood crown
21781	thaelis s head
21783	magister duskwither s journal
21784	figurine black diamond crab
21785	cut emerald
21786	cut azerothian diamond
21789	figurine dark iron scorpid
21790	sapphire pendant of winter night
21791	living emerald pendant
21792	necklace of the diamond tower
21793	arcanite sword pendant
21800	silithid husked launcher
21801	antenna of invigoration
21802	the lost kris of zedd
21803	helm of the holy avenger
21804	coif of elemental fury
21805	polished obsidian pauldrons
21806	gavel of qiraji authority
21807	unmarked letter
21808	arcane core
21809	fury of the forgotten swarm
21810	treads of the wandering nomad
21812	box of chocolates
21813	bag of candies
21814	breastplate of annihilation
21815	love token
21816	heart candy
21817	heart candy
21818	heart candy
21819	heart candy
21820	heart candy
21821	heart candy
21822	heart candy
21823	heart candy
21829	perfume bottle
21830	empty wrapper
21831	wrappered gift
21833	cologne bottle
21835	anesthetic poison
21836	ritssyn s ring of chaos
21837	anubisath warhammer
21838	garb of royal ascension
21839	scepter of the false prophet
21840	bolt of netherweave
21841	netherweave bag
21842	bolt of imbued netherweave
21843	imbued netherweave bag
21844	bolt of soulcloth
21845	primal mooncloth
21846	spellfire belt
21847	spellfire gloves
21848	spellfire robe
21849	netherweave bracers
21850	netherweave belt
21851	netherweave gloves
21852	netherweave pants
21853	netherweave boots
21854	netherweave robe
21855	netherweave tunic
21856	neretzek the blood drinker
21858	spellfire bag
21859	imbued netherweave pants
21860	imbued netherweave boots
21861	imbued netherweave robe
21862	imbued netherweave tunic
21863	soulcloth gloves
21864	soulcloth shoulders
21865	soulcloth vest
21866	arcanoweave bracers
21867	arcanoweave boots
21868	arcanoweave robe
21869	frozen shadoweave shoulders
21870	frozen shadoweave boots
21871	frozen shadoweave robe
21872	ebon shadowbag
21873	primal mooncloth belt
21874	primal mooncloth shoulders
21875	primal mooncloth robe
21876	primal mooncloth bag
21877	netherweave cloth
21878	zzdeprecated spellthread
21879	charged draenethyst crystal
21880	perfect draenethyst crystal
21881	netherweb spider silk
21882	soul essence
21883	ebon felcloth
21884	primal fire
21885	primal water
21886	primal life
21887	knothide leather
21888	gloves of the immortal
21889	gloves of the redeemed prophecy
21890	gloves of the fallen prophet
21891	shard of the fallen star
21892	pattern bolt of imbued netherweave
21893	pattern imbued netherweave bag
21894	pattern bolt of soulcloth
21895	pattern primal mooncloth
21896	pattern netherweave robe
21897	pattern netherweave tunic
21898	pattern imbued netherweave pants
21899	pattern imbued netherweave boots
21900	pattern imbued netherweave robe
21901	pattern imbued netherweave tunic
21902	pattern soulcloth gloves
21903	pattern soulcloth shoulders
21904	pattern soulcloth vest
21905	pattern arcanoweave bracers
21906	pattern arcanoweave boots
21907	pattern arcanoweave robe
21908	pattern spellfire belt
21909	pattern spellfire gloves
21910	pattern spellfire robe
21911	pattern spellfire bag
21912	pattern frozen shadoweave shoulders
21913	pattern frozen shadoweave robe
21914	pattern frozen shadoweave boots
21915	pattern ebon shadowbag
21916	pattern primal mooncloth belt
21917	pattern primal mooncloth robe
21918	pattern primal mooncloth shoulders
21919	pattern primal mooncloth bag
21920	creased letter
21921	carefully penned note
21924	pattern runecloth robe
21925	immaculate letter
21926	slightly creased note
21927	instant poison vii
21928	winterspring blood sample
21929	flame spessarite
21931	woven copper ring
21932	heavy copper ring
21933	thick bronze necklace
21934	ornate tigerseye necklace
21935	stable ectoplasm
21936	frozen ectoplasm
21937	scorched ectoplasm
21938	magma core
21939	fel elemental rod
21940	design golden hare
21941	design black pearl panther
21942	design ruby crown of restoration
21943	design truesilver crab
21944	design truesilver boar
21945	design the aquamarine ward
21946	ectoplasmic distiller
21947	design gem studded band
21948	design opal necklace of impact
21949	design ruby serpent
21951	design cut azerothian diamond
21952	design emerald crown of destruction
21953	design emerald owl
21954	design ring of bitter shadows
21955	design black diamond crab
21956	design dark iron scorpid
21957	design necklace of the diamond tower
21958	design arcanite sword pendant
21959	design blood crown
21960	handmade woodcraft
21975	pledge of adoration stormwind
21979	gift of adoration darnassus
21980	gift of adoration ironforge
21981	gift of adoration stormwind
21982	ogre warbeads
21983	incomplete banner of provocation
21984	left piece of lord valthalak s amulet
21985	sealed blood container
21986	banner of provocation
21987	incendicite of incendius
21988	ember of emberseer
21989	cinder of cynders
21990	netherweave bandage
21991	heavy netherweave bandage
21992	manual netherweave bandage
21993	manual heavy netherweave bandage
21994	belt of heroism
21995	boots of heroism
21996	bracers of heroism
21997	breastplate of heroism
21998	gauntlets of heroism
21999	helm of heroism
22000	legplates of heroism
22001	spaulders of heroism
22002	darkmantle belt
22003	darkmantle boots
22004	darkmantle bracers
22005	darkmantle cap
22006	darkmantle gloves
22007	darkmantle pants
22008	darkmantle spaulders
22009	darkmantle tunic
22010	beastmaster s belt
22011	beastmaster s bindings
22012	master first aid doctor in the house
22013	beastmaster s cap
22014	hallowed brazier
22015	beastmaster s gloves
22016	beastmaster s mantle
22017	beastmaster s pants
22018	conjured glacier water
22019	conjured croissant
22044	mana emerald
22046	right piece of lord valthalak s amulet
22047	top piece of lord valthalak s amulet
22048	lord valthalak s amulet
22049	brazier of beckoning
22050	brazier of beckoning
22051	brazier of beckoning
22052	brazier of beckoning
22053	deadly poison vi
22054	deadly poison vii
22055	wound poison v
22056	brazier of beckoning
22057	brazier of invocation
22058	valentine s day stationery
22059	valentine s day card
22060	beastmaster s tunic
22061	beastmaster s boots
22062	sorcerer s belt
22063	sorcerer s bindings
22064	sorcerer s boots
22065	sorcerer s crown
22066	sorcerer s gloves
22067	sorcerer s leggings
22068	sorcerer s mantle
22069	sorcerer s robes
22070	deathmist belt
22071	deathmist bracers
22072	deathmist leggings
22073	deathmist mantle
22074	deathmist mask
22075	deathmist robe
22076	deathmist sandals
22077	deathmist wraps
22078	virtuous belt
22079	virtuous bracers
22080	virtuous crown
22081	virtuous gloves
22082	virtuous mantle
22083	virtuous robe
22084	virtuous sandals
22085	virtuous skirt
22086	soulforge belt
22087	soulforge boots
22088	soulforge bracers
22089	soulforge breastplate
22090	soulforge gauntlets
22091	soulforge helm
22092	soulforge legplates
22093	soulforge spaulders
22094	bloodkelp
22095	bindings of the five thunders
22096	boots of the five thunders
22097	coif of the five thunders
22098	cord of the five thunders
22099	gauntlets of the five thunders
22100	kilt of the five thunders
22101	pauldrons of the five thunders
22102	vest of the five thunders
22103	master healthstone
22104	master healthstone
22105	master healthstone
22106	feralheart belt
22107	feralheart boots
22108	feralheart bracers
22109	feralheart cowl
22110	feralheart gloves
22111	feralheart kilt
22112	feralheart spaulders
22113	feralheart vest
22114	pink murloc egg
22115	extra dimensional ghost revealer
22116	master soulstone
22117	pledge of loyalty stormwind
22119	pledge of loyalty ironforge
22120	pledge of loyalty darnassus
22121	pledge of loyalty undercity
22122	pledge of loyalty thunder bluff
22123	pledge of loyalty orgrimmar
22128	master firestone
22130	symbol of love
22131	stormwind gift collection
22132	ironforge gift collection
22133	darnassus gift collection
22134	undercity gift collection
22135	thunder bluff gift collection
22136	orgrimmar gift collection
22137	ysida s satchel
22138	blackrock bracer
22139	ysida s locket
22140	sentinel s card
22141	ironforge guard s card
22142	grunt s card
22143	stormwind guard s card
22144	bluffwatcher s card
22145	guardian s moldy card
22146	book gift of the wild iii
22147	flintweed seed
22148	wild quillvine
22149	beads of ogre mojo
22150	beads of ogre might
22151	anthion s holy water
22152	anthion s pouch
22153	tome of arcane brilliance 2
22154	pledge of adoration ironforge
22155	pledge of adoration darnassus
22156	pledge of adoration orgrimmar
22157	pledge of adoration undercity
22158	pledge of adoration thunder bluff
22159	pledge of friendship darnassus
22160	pledge of friendship ironforge
22161	pledge of friendship orgrimmar
22162	pledge of friendship thunder bluff
22163	pledge of friendship undercity
22164	gift of adoration orgrimmar
22165	gift of adoration thunder bluff
22166	gift of adoration undercity
22167	gift of friendship darnassus
22168	gift of friendship ironforge
22169	gift of friendship orgrimmar
22170	gift of friendship stormwind
22171	gift of friendship thunder bluff
22172	gift of friendship undercity
22173	dwarven homebrew
22174	romantic poem
22175	freshly baked pie
22176	homemade bread
22177	freshly picked flowers
22178	pledge of friendship stormwind
22179	grimoire of firebolt rank 8
22180	grimoire of blood pact rank 6
22181	grimoire of fire shield rank 6
22182	grimoire of torment rank 7
22183	grimoire of suffering rank 5
22184	grimoire of consume shadows rank 7
22185	grimoire of sacrifice rank 7
22186	grimoire of lash of pain rank 7
22187	grimoire of soothing kiss rank 5
22188	grimoire of devour magic rank 5
22189	grimoire of devour magic rank 6
22190	grimoire of tainted blood rank 5
22191	obsidian mail tunic
22192	bloodkelp elixir of dodging
22193	bloodkelp elixir of resistance
22194	black grasp of the destroyer
22195	light obsidian belt
22196	thick obsidian breastplate
22197	heavy obsidian belt
22198	jagged obsidian shield
22200	silver shafted arrow
22201	reliquary of purity
22202	small obsidian shard
22203	large obsidian shard
22204	wristguards of renown
22205	black steel bindings
22206	bouquet of red roses
22207	sash of the grand hunt
22208	lavastone hammer
22209	plans heavy obsidian belt
22212	golem fitted pauldrons
22214	plans light obsidian belt
22216	venoxis s venom sac
22217	kurinnaxx s venom sac
22218	handful of rose petals
22219	plans jagged obsidian shield
22220	plans black grasp of the destroyer
22221	plans obsidian mail tunic
22222	plans thick obsidian breastplate
22223	foreman s head protector
22224	jeering spectre s essence
22225	dragonskin cowl
22226	druidical remains
22227	starbreeze village relic
22228	brilliant sword of zealotry
22229	soul ashes of the banished
22230	frightmaw hide
22231	kayser s boots of precision
22232	marksman s girdle
22233	zigris footlocker
22234	mantle of lost hope
22235	truesilver shafted arrow
22236	buttermilk delight
22237	dark desire
22238	very berry cream
22239	sweet surprise
22240	greaves of withering despair
22241	dark warder s pauldrons
22242	verek s leash
22243	small soul pouch
22244	box of souls
22245	soot encrusted footwear
22246	enchanted mageweave pouch
22247	faith healer s boots
22248	enchanted runecloth bag
22249	big bag of enchantment
22250	herb pouch
22251	cenarion herb bag
22252	satchel of cenarius
22253	tome of the lost
22254	wand of eternal light
22255	magma forged band
22256	mana shaping handwraps
22257	bloodclot band
22258	love potion
22259	unbestowed friendship bracelet
22260	friendship bracelet
22261	love fool
22262	alliance gift collection
22263	horde gift collection
22264	carefully written letter
22265	lovingly composed letter
22266	flarethorn
22267	spellweaver s turban
22268	draconic infused emblem
22269	shadow prowler s cloak
22270	entrenching boots
22271	leggings of frenzied magic
22272	forest s embrace
22273	moonshadow hood
22274	grizzled pelt
22275	firemoss boots
22276	lovely red dress
22277	red dinner suit
22278	lovely blue dress
22279	lovely black dress
22280	lovely purple dress
22281	blue dinner suit
22282	purple dinner suit
22283	sack of homemade bread
22284	bundle of cards
22285	stormwind pledge collection
22286	ironforge pledge collection
22287	parcel of cards
22288	case of homebrew
22289	stack of cards
22290	darnassus pledge collection
22291	box of woodcrafts
22292	box of fresh pies
22293	package of cards
22294	orgrimmar pledge collection
22295	satchel of cards
22296	basket of flowers
22297	thunder bluff pledge collection
22298	book of romantic poems
22299	sheaf of cards
22300	undercity pledge collection
22301	ironweave robe
22302	ironweave cowl
22303	ironweave pants
22304	ironweave gloves
22305	ironweave mantle
22306	ironweave belt
22307	pattern enchanted mageweave pouch
22308	pattern enchanted runecloth bag
22309	pattern big bag of enchantment
22310	pattern cenarion herb bag
22311	ironweave boots
22312	pattern satchel of cenarius
22313	ironweave bracers
22314	huntsman s harpoon
22315	hammer of revitalization
22317	lefty s brass knuckle
22318	malgen s long bow
22319	tome of divine right
22320	mux s quality goods
22321	heart of wyrmthalak
22322	the jaw breaker
22324	winter kimchi
22325	belt of the trickster
22326	amalgam s band
22327	amulet of the redeemed
22328	legplates of vigilance
22329	scepter of interminable focus
22330	shroud of arcane mastery
22331	band of the steadfast hero
22332	blade of necromancy
22333	hammer of divine might
22334	band of mending
22335	lord valthalak s staff of command
22336	draconian aegis of the legion
22337	shroud of domination
22338	volcanic ash
22339	rune band of wizardry
22340	pendant of celerity
22342	leggings of torment
22343	handguards of savagery
22344	brazier of invocation user s manual
22345	totem of rebirth
22347	fahrad s reloading repeater
22348	doomulus prime
22349	desecrated breastplate
22350	desecrated tunic
22351	desecrated robe
22352	desecrated legplates
22353	desecrated helmet
22354	desecrated pauldrons
22355	desecrated bracers
22356	desecrated waistguard
22357	desecrated gauntlets
22358	desecrated sabatons
22359	desecrated legguards
22360	desecrated headpiece
22361	desecrated spaulders
22362	desecrated wristguards
22363	desecrated girdle
22364	desecrated handguards
22365	desecrated boots
22366	desecrated leggings
22367	desecrated circlet
22368	desecrated shoulderpads
22369	desecrated bindings
22370	desecrated belt
22371	desecrated gloves
22372	desecrated sandals
22373	wartorn leather scrap
22374	wartorn chain scrap
22375	wartorn plate scrap
22376	wartorn cloth scrap
22377	the thunderwood poker
22378	ravenholdt slicer
22379	shivsprocket s shiv
22380	simone s cultivating hammer
22381	silithus venom sample
22382	sealed venom container
22383	sageblade
22384	persuader
22385	titanic leggings
22386	head of instructor razuvious dep
22387	heart of anub rekhan
22388	plans titanic leggings
22389	plans sageblade
22390	plans persuader
22392	formula enchant 2h weapon agility
22393	codex prayer of shadow protection
22394	staff of metanoia
22395	totem of rage
22396	totem of life
22397	idol of ferocity
22398	idol of rejuvenation
22399	idol of health
22400	libram of truth
22401	libram of hope
22402	libram of grace
22403	diana s pearl necklace
22404	willey s back scratcher
22405	mantle of the scarlet crusade
22406	redemption
22407	helm of the new moon
22408	ritssyn s wand of bad mojo
22409	tunic of the crescent moon
22410	gauntlets of deftness
22411	helm of the executioner
22412	thuzadin mantle
22413	sin dorei armaments
22414	antheol s elemental grimoire
22415	dragonhawk feather
22416	dreadnaught breastplate
22417	dreadnaught legplates
22418	dreadnaught helmet
22419	dreadnaught pauldrons
22420	dreadnaught sabatons
22421	dreadnaught gauntlets
22422	dreadnaught waistguard
22423	dreadnaught bracers
22424	redemption wristguards
22425	redemption tunic
22426	redemption handguards
22427	redemption legguards
22428	redemption headpiece
22429	redemption spaulders
22430	redemption boots
22431	redemption girdle
22432	devilsaur barb
22433	don mauricio s band of domination
22434	bloodcap
22435	gorishi sting
22436	cryptstalker tunic
22437	cryptstalker legguards
22438	cryptstalker headpiece
22439	cryptstalker spaulders
22440	cryptstalker boots
22441	cryptstalker handguards
22442	cryptstalker girdle
22443	cryptstalker wristguards
22444	putrid vine
22445	arcane dust
22446	greater planar essence
22447	lesser planar essence
22448	small prismatic shard
22449	large prismatic shard
22450	void crystal
22451	primal air
22452	primal earth
22456	primal shadow
22457	primal mana
22458	moonshadow stave
22459	void sphere
22460	prismatic sphere
22461	runed fel iron rod
22462	runed adamantite rod
22463	runed eternium rod
22464	earthshatter tunic
22465	earthshatter legguards
22466	earthshatter headpiece
22467	earthshatter spaulders
22468	earthshatter boots
22469	earthshatter handguards
22470	earthshatter girdle
22471	earthshatter wristguards
22472	boots of ferocity
22473	antheol s disciplinary rod
22474	meledor s apprentice badge
22475	ralen s apprentice badge
22476	bonescythe breastplate
22477	bonescythe legplates
22478	bonescythe helmet
22479	bonescythe pauldrons
22480	bonescythe sabatons
22481	bonescythe gauntlets
22482	bonescythe waistguard
22483	bonescythe bracers
22484	necrotic rune
22487	aldaron s head
22488	dreamwalker tunic
22489	dreamwalker legguards
22490	dreamwalker headpiece
22491	dreamwalker spaulders
22492	dreamwalker boots
22493	dreamwalker handguards
22494	dreamwalker girdle
22495	dreamwalker wristguards
22496	frostfire robe
22497	frostfire leggings
22498	frostfire circlet
22499	frostfire shoulderpads
22500	frostfire sandals
22501	frostfire gloves
22502	frostfire belt
22503	frostfire bindings
22504	plagueheart robe
22505	plagueheart leggings
22506	plagueheart circlet
22507	plagueheart shoulderpads
22508	plagueheart sandals
22509	plagueheart gloves
22510	plagueheart belt
22511	plagueheart bindings
22512	robe of faith
22513	leggings of faith
22514	circlet of faith
22515	shoulderpads of faith
22516	sandals of faith
22517	gloves of faith
22518	belt of faith
22519	bindings of faith
22520	the phylactery of kel thuzad
22521	superior mana oil
22522	superior wizard oil
22523	insignia of the dawn
22524	insignia of the crusade
22525	crypt fiend parts
22526	bone fragments
22527	core of elements
22528	dark iron scraps
22529	savage frond
22530	formula enchant bracer major defense
22531	formula enchant bracer superior healing
22532	formula enchant bracer restore mana prime
22533	formula enchant bracer fortitude
22534	formula enchant bracer spellpower
22535	formula enchant ring striking
22536	formula enchant ring spellpower
22537	formula enchant ring healing power
22538	formula enchant ring stats
22539	formula enchant shield intellect
22540	formula enchant shield shield block
22541	formula enchant shield resistance
22542	formula enchant boots vitality
22543	formula enchant boots fortitude
22544	formula enchant boots dexterity
22545	formula enchant boots surefooted
22547	formula enchant chest exceptional stats
22548	formula enchant cloak major resistance
22549	quartermaster lymel s bill of lading
22550	quartermaster lymel s goods
22551	formula enchant weapon major intellect
22552	formula enchant weapon major striking
22553	formula enchant weapon potency
22554	formula enchant 2h weapon savagery
22555	formula enchant weapon major spellpower
22556	formula enchant 2h weapon major agility
22557	formula enchant weapon battlemaster
22558	formula enchant weapon spellsurge
22559	formula enchant weapon mongoose
22560	formula enchant weapon sunfire
22561	formula enchant weapon soulfrost
22562	formula superior mana oil
22563	formula superior wizard oil
22564	formula arcane dust
22565	formula large prismatic shard
22566	phantasmal substance
22567	gargoyle fragment
22568	sealed craftsman s writ
22569	intact spider fang
22570	plagued blood sample
22571	courier s bag
22572	mote of air
22573	mote of earth
22574	mote of fire
22575	mote of life
22576	mote of mana
22577	mote of shadow
22578	mote of water
22579	plagued murloc spine
22580	crystallized mana essence
22581	damaged arcane instruments
22582	case of crystallized essences
22583	rathis tomber s supplies
22589	atiesh greatstaff of the guardian
22590	night elf plans an daroth
22591	night elf plans an owyn
22592	night elf plans scrying on the sin dorei
22593	writ of safe passage
22594	night elf plans
22595	call to arms announcement
22597	the lady s necklace
22598	stone of light
22599	stone of flame
22600	craftsman s writ dense weightstone
22601	craftsman s writ imperial plate chest
22602	craftsman s writ volcanic hammer
22603	craftsman s writ huge thorium battleaxe
22604	craftsman s writ radiant circlet
22605	craftsman s writ wicked leather headband
22606	craftsman s writ rugged armor kit
22607	craftsman s writ wicked leather belt
22608	craftsman s writ runic leather pants
22609	craftsman s writ brightcloth pants
22610	craftsman s writ runecloth boots
22611	craftsman s writ runecloth bag
22612	craftsman s writ runecloth robe
22613	craftsman s writ goblin sapper charge
22614	craftsman s writ thorium grenade
22615	craftsman s writ gnomish battle chicken
22616	craftsman s writ thorium tube
22617	craftsman s writ major mana potion
22618	craftsman s writ major healing potion
22619	craftsman s writ greater frost protection potion
22620	craftsman s writ greater arcane protection potion
22621	craftsman s writ flask of petrification
22622	craftsman s writ stonescale eel
22623	craftsman s writ plated armorfish
22624	craftsman s writ lightning eel
22625	craftsman s writ baked salmon
22626	craftsman s writ runn tum tuber surprise
22627	the lady s necklace
22628	renzithen s restorative draught
22629	sealed sin dorei orders
22630	atiesh greatstaff of the guardian
22631	atiesh greatstaff of the guardian
22632	atiesh greatstaff of the guardian
22633	troll juju
22634	underlight ore
22635	savage guard
22636	ice guard
22637	primal hakkari idol
22638	shadow guard
22639	zeb sora troll ear
22640	head of kel gash the wicked
22641	rotting heart
22642	spinal dust
22644	crunchy spider leg
22645	crunchy spider surprise
22646	master spellstone
22647	recipe crunchy spider surprise
22648	hive ashi dossier
22649	hive regal dossier
22650	hive zora dossier
22651	outrider s plate legguards
22652	glacial vest
22653	dar khan s head
22654	glacial gloves
22655	glacial wrists
22656	the purifier
22657	amulet of the dawn
22658	glacial cloak
22659	medallion of the dawn
22660	gaea s embrace
22661	polar tunic
22662	polar gloves
22663	polar bracers
22664	icy scale breastplate
22665	icy scale bracers
22666	icy scale gauntlets
22667	bracers of hope
22668	bracers of subterfuge
22669	icebane breastplate
22670	icebane gauntlets
22671	icebane bracers
22672	sentinel s plate legguards
22673	outrider s chain leggings
22674	wavefront medallion
22675	bundle of medallions
22676	outrider s mail leggings
22677	catlord claws
22678	talisman of ascendance
22679	supply bag
22680	band of resolution
22681	band of piety
22682	frozen rune
22683	pattern gaea s embrace
22684	pattern glacial gloves
22685	pattern glacial cloak
22686	pattern glacial vest
22687	pattern glacial wrists
22688	verimonde s last resort
22689	sanctified leather helm
22690	leggings of the plague hunter
22691	corrupted ashbringer
22692	pattern polar tunic
22693	infused crystal
22694	pattern polar gloves
22695	pattern polar bracers
22696	pattern icy scale breastplate
22697	pattern icy scale gauntlets
22698	pattern icy scale bracers
22699	icebane leggings
22700	glacial leggings
22701	polar leggings
22702	icy scale leggings
22703	plans icebane breastplate
22704	plans icebane gauntlets
22705	plans icebane bracers
22706	dar khan s journal
22707	ramaladni s icy grasp
22708	fate of ramaladni
22710	bloodthistle
22711	cloak of the hakkari worshippers
22712	might of the tribe
22713	zulian scepter of rites
22714	sacrificial gauntlets
22715	gloves of the tormented
22716	belt of untapped power
22717	letter from silvermoon
22718	blooddrenched mask
22719	omarion s handbook
22720	zulian headdress
22721	band of servitude
22722	seal of the gurubashi berserker
22723	a letter from the keeper of the rolls
22725	band of cenarius
22726	splinter of atiesh
22727	frame of atiesh
22728	steam tonk controller
22729	schematic steam tonk controller
22730	eyestalk waist cord
22731	cloak of the devoured
22732	mark of c thun
22733	staff head of atiesh
22734	base of atiesh
22735	research notes
22736	andonisus reaper of souls
22737	atiesh greatstaff of the guardian
22739	tome of polymorph turtle
22740	outrider s leather pants
22741	outrider s lizardhide pants
22742	bloodsail shirt
22743	bloodsail sash
22744	bloodsail boots
22745	bloodsail pants
22746	buccaneer s uniform
22747	outrider s silk leggings
22748	sentinel s chain leggings
22749	sentinel s leather pants
22750	sentinel s lizardhide pants
22752	sentinel s silk leggings
22753	sentinel s lamellar legguards
22754	eternal quintessence
22755	blazing torch
22756	sylvan vest
22757	sylvan crown
22758	sylvan shoulders
22759	bramblewood helm
22760	bramblewood boots
22761	bramblewood belt
22762	ironvine breastplate
22763	ironvine gloves
22764	ironvine belt
22765	mildewed letter
22766	plans ironvine breastplate
22767	plans ironvine gloves
22768	plans ironvine belt
22769	pattern bramblewood belt
22770	pattern bramblewood boots
22771	pattern bramblewood helm
22772	pattern sylvan shoulders
22773	pattern sylvan crown
22774	pattern sylvan vest
22775	suntouched special reserve
22776	springpaw appetizers
22777	bundle of fireworks
22778	scourgebane infusion
22779	scourgebane draught
22780	white murloc egg
22781	polar bear collar
22782	sin dorei cloak of warding
22783	sunwell blade
22784	sunwell orb
22785	felweed
22786	dreaming glory
22787	ragveil
22788	flame cap
22789	terocone
22790	ancient lichen
22791	netherbloom
22792	nightmare vine
22793	mana thistle
22794	fel lotus
22795	fel blossom
22796	apothecary s poison
22797	nightmare seed
22798	might of menethil
22799	soulseeker
22800	brimstone staff
22801	spire of twilight
22802	kingsfall
22803	midnight haze
22804	maexxna s fang
22806	widow s remorse
22807	wraith blade
22808	the castigator
22809	maul of the redeemed crusader
22810	toxin injector
22811	soulstring
22812	nerubian slavemaker
22813	claymore of unholy might
22815	severance
22816	hatchet of sundered bone
22818	the plague bearer
22819	shield of condemnation
22820	wand of fates
22821	doomfinger
22822	icoke prize voucher
22823	elixir of camouflage
22824	elixir of major strength
22825	elixir of healing power
22826	sneaking potion
22827	elixir of major frost power
22828	insane strength potion
22829	super healing potion
22830	elixir of the searching eye
22831	elixir of major agility
22832	super mana potion
22833	elixir of major firepower
22834	elixir of major defense
22835	elixir of major shadow power
22836	major dreamless sleep potion
22837	heroic potion
22838	haste potion
22839	destruction potion
22840	elixir of major mageblood
22841	major fire protection potion
22842	major frost protection potion
22843	blood guard s chain greaves
22844	major nature protection potion
22845	major arcane protection potion
22846	major shadow protection potion
22847	major holy protection potion
22848	elixir of empowerment
22849	ironshield potion
22850	super rejuvenation potion
22851	flask of fortification
22852	blood guard s dragonhide treads
22853	flask of mighty restoration
22854	flask of relentless assault
22855	blood guard s dreadweave walkers
22856	blood guard s leather walkers
22857	blood guard s mail greaves
22858	blood guard s plate greaves
22859	blood guard s satin walkers
22860	blood guard s silk walkers
22861	flask of blinding light
22862	blood guard s chain vices
22863	blood guard s dragonhide grips
22864	blood guard s leather grips
22865	blood guard s dreadweave handwraps
22866	flask of pure death
22867	blood guard s mail vices
22868	blood guard s plate gauntlets
22869	blood guard s satin handwraps
22870	blood guard s silk handwraps
22871	shrouding potion
22872	legionnaire s plate hauberk
22873	legionnaire s plate leggings
22874	legionnaire s chain hauberk
22875	legionnaire s chain legguards
22876	legionnaire s mail hauberk
22877	legionnaire s dragonhide chestpiece
22878	legionnaire s dragonhide leggings
22879	legionnaire s leather chestpiece
22880	legionnaire s leather legguards
22881	legionnaire s dreadweave legguards
22882	legionnaire s satin legguards
22883	legionnaire s silk legguards
22884	legionnaire s dreadweave tunic
22885	legionnaire s satin tunic
22886	legionnaire s silk tunic
22887	legionnaire s mail legguards
22888	ammen vale gift voucher
22889	vial of moth blood
22890	tome of frost ward v
22891	grimoire of shadow ward iv
22892	dim necrotic stone
22893	luzran s head
22894	knucklerot s head
22895	conjured cinnamon roll
22896	healing crystal
22897	tome of conjure food vii
22898	consecrated crystal
22899	etched crystal
22900	recipe elixir of camouflage
22901	recipe sneaking potion
22902	recipe elixir of major frost power
22903	recipe insane strength potion
22904	recipe elixir of the searching eye
22905	recipe elixir of major agility
22906	recipe shrouding potion
22907	recipe super mana potion
22908	recipe elixir of major firepower
22909	recipe elixir of major defense
22910	recipe elixir of major shadow power
22911	recipe major dreamless sleep potion
22912	recipe heroic potion
22913	recipe haste potion
22914	recipe destruction potion
22915	recipe transmute primal air to fire
22916	recipe transmute primal earth to water
22917	recipe transmute primal fire to earth
22918	recipe transmute primal water to air
22919	recipe elixir of major mageblood
22920	recipe major fire protection potion
22921	recipe major frost protection potion
22922	recipe major nature protection potion
22923	recipe major arcane protection potion
22924	recipe major shadow protection potion
22925	recipe major holy protection potion
22926	recipe elixir of empowerment
22927	recipe ironshield potion
22928	simple crystal
22929	glyphic crystal
22930	a bloodstained envelope
22931	hallowed crystal
22932	a torn letter
22934	lasher sample
22935	touch of frost
22936	wristguards of vengeance
22937	gem of nerubis
22938	cryptfiend silk cloak
22939	band of unanswered prayers
22940	icebane pauldrons
22941	polar shoulder pads
22942	the widow s embrace
22943	malice stone pendant
22944	a crumpled missive
22945	a careworn note
22946	a ragged page
22947	pendant of forgotten names
22948	a smudged document
22949	cracked necrotic crystal
22950	faint necrotic crystal
22951	springpaw hide leggings
22952	springpaw hide cloak
22953	fur lined chain shirt
22954	kiss of the spider
22955	neutralizing agent
22956	rusty mace
22957	rusty sin dorei sword
22958	farstrider sword
22959	smooth metal staff
22960	cloak of suturing
22961	band of reanimation
22962	inoculating crystal
22963	ranger s pocketknife
22964	sunsail bracers
22965	longshoreman s bindings
22966	silk wristbands
22967	icy scale spaulders
22968	glacial mantle
22969	ven jashi s bow
22970	a bloodstained envelope
22971	hoodoo wand
22972	a careworn note
22973	a crumpled missive
22974	a ragged page
22975	a smudged document
22976	magister s pouch
22977	a torn letter
22978	emitter spare part
22979	slayer s band
22980	staff of the sun
22981	gluth s missing collar
22982	farstrider s longbow
22983	rime covered mantle
22984	dawnblade
22985	suncrown hauberk
22986	apothecary s robe
22987	deathstalker s vest
22988	the end of dreams
22989	blood elf amulet
22990	tranquillien champion s cloak
22991	apprentice boots
22992	bogwalker boots
22993	volunteer s greaves
22994	digested hand of power
22995	sin dorei warblade
22996	reforged quel dorei crest
22997	ley keeper s wand
22998	ghostclaw leggings
22999	tabard of the argent dawn
23000	plated abomination ribcage
23001	eye of diminution
23002	turtle box
23003	blood elf plans
23004	idol of longevity
23005	totem of flowing water
23006	libram of light
23007	piglet s collar
23008	sealed research report
23009	wand of the whispering dead
23010	sealed research report
23011	sealed research report
23012	sealed research report
23013	sealed research report
23014	iblis blade of the fallen seraph
23015	rat cage
23016	sealed research report
23017	veil of eclipse
23018	signet of the fallen defender
23019	icebane helmet
23020	polar helmet
23021	the soul harvester s bindings
23022	curmudgeon s payoff
23023	sadist s collar
23024	prepared field duty papers
23025	seal of the damned
23026	supply request crystal
23027	warmth of forgiveness
23028	hailstone band
23029	noth s frigid heart
23030	cloak of the scourge
23031	band of the inevitable
23032	glacial headdress
23033	icy scale coif
23035	preceptor s hat
23036	necklace of necropsy
23037	ring of spiritual fervor
23038	band of unnatural forces
23039	the eye of nerub
23040	glyph of deflection
23041	slayer s crest
23042	loatheb s reflection
23043	the face of death
23044	harbinger of doom
23045	shroud of dominion
23046	the restrained essence of sapphiron
23047	eye of the dead
23048	sapphiron s right eye
23049	sapphiron s left eye
23050	cloak of the necropolis
23051	glaive of the defender
23053	stormrage s talisman of seething
23054	gressil dawn of ruin
23055	word of thawing
23056	hammer of the twisting nether
23057	gem of trapped innocents
23058	life channeling necklace
23059	ring of the dreadnaught
23060	bonescythe ring
23061	ring of faith
23062	frostfire ring
23063	plagueheart ring
23064	ring of the dreamwalker
23065	ring of the earthshatterer
23066	ring of redemption
23067	ring of the cryptstalker
23068	legplates of carnage
23069	necro knight s garb
23070	leggings of polarity
23071	leggings of apocalypse
23072	fists of the unrelenting
23073	boots of displacement
23075	death s bargain
23076	brilliant citrine
23077	blood garnet
23078	gauntlets of undead slaying
23079	deep peridot
23081	handwraps of undead slaying
23082	handguards of undead slaying
23083	captured flame
23084	gloves of undead cleansing
23085	robe of undead cleansing
23087	breastplate of undead slaying
23088	chestguard of undead slaying
23089	tunic of undead slaying
23090	bracers of undead slaying
23091	bracers of undead cleansing
23092	wristguards of undead slaying
23093	wristwraps of undead slaying
23094	teardrop blood garnet
23095	bold blood garnet
23096	runed blood garnet
23097	delicate blood garnet
23098	inscribed flame spessarite
23099	luminous flame spessarite
23100	glinting flame spessarite
23101	potent flame spessarite
23103	radiant deep peridot
23104	jagged deep peridot
23105	enduring deep peridot
23106	dazzling deep peridot
23107	shadow draenite
23108	glowing shadow draenite
23109	royal shadow draenite
23110	shifting shadow draenite
23111	sovereign shadow draenite
23112	golden draenite
23113	brilliant golden draenite
23114	gleaming golden draenite
23115	thick golden draenite
23116	rigid golden draenite
23117	azure moonstone
23118	solid azure moonstone
23119	sparkling azure moonstone
23120	stormy azure moonstone
23121	lustrous azure moonstone
23122	consecrated sharpening stone
23123	blessed wizard oil
23124	staff of balzaphon
23125	chains of the lich
23126	waistband of balzaphon
23127	cloak of revanchion
23128	the shadow s grasp
23129	bracers of mending
23130	design teardrop blood garnet
23131	design bold blood garnet
23132	lord blackwood s blade
23133	design runed blood garnet
23134	design delicate blood garnet
23135	design inscribed flame spessarite
23136	design luminous flame spessarite
23137	design glinting flame spessarite
23138	design potent flame spessarite
23139	lord blackwood s buckler
23140	design radiant deep peridot
23141	design jagged deep peridot
23142	design enduring deep peridot
23143	design dazzling deep peridot
23144	design glowing shadow draenite
23145	design royal shadow draenite
23146	design shifting shadow draenite
23147	design sovereign shadow draenite
23148	design brilliant golden draenite
23149	design gleaming golden draenite
23150	design thick golden draenite
23151	design rigid golden draenite
23152	design solid azure moonstone
23153	design sparkling azure moonstone
23154	design stormy azure moonstone
23155	design lustrous azure moonstone
23156	blackwood s thigh
23157	thick citrine
23158	solid aquamarine
23159	sparkling aquamarine
23160	friendship bread
23161	freshly squeezed lemonade
23162	foror s crate of endless resist gear storage
23163	performer s wand
23164	bubbly beverage
23165	headhunter axe
23166	hexxer stave
23167	shadowcaster mace
23168	scorn s focal dagger
23169	scorn s icy choker
23170	the frozen clutch
23171	the axe of severing
23172	refreshing red apple
23173	abomination skin leggings
23175	tasty summer treat
23176	fizzy energy drink
23177	lady falther ess finger
23178	mantle of lady falther ess
23179	flame of orgrimmar
23180	flame of thunder bluff
23181	flame of the undercity
23182	flame of stormwind
23183	flame of ironforge
23184	flame of darnassus
23191	crystal controlling orb
23192	tabard of the scarlet crusade
23193	naxxramas deathcharger reins
23194	lesser mark of the dawn
23195	mark of the dawn
23196	greater mark of the dawn
23197	idol of the moon
23198	idol of brutality
23199	totem of the storm
23200	totem of sustaining
23201	libram of divinity
23203	libram of fervor
23205	hellfire spineleaf
23206	mark of the champion
23207	mark of the champion
23211	toasted smorc
23212	scrapper s vest
23213	scrapper s pants
23214	plump helboar carcass
23215	bag of smorc ingredients
23216	pulsating voidwalker essence
23217	ravager egg
23218	condensed voidwalker essence
23219	girdle of the mentor
23220	crystal webbed robe
23221	misplaced servo arm
23222	clefthoof hide
23223	clefthoof bones
23224	summer gift package
23226	ghoul skin tunic
23227	icoke gift box voucher
23229	sword of sockety goodness
23230	dagger of sockety goodness
23231	clefthoof sinew
23232	huge sword of sockety goodness
23233	red bryanite of strength stuff
23234	blue bryanite of agility
23235	yellow bryanite of stamina
23236	meta bryanite
23237	ring of the eternal flame
23238	stygian buckler
23239	plump buzzard wing
23242	claw of the frost wyrm
23243	champion s plate shoulders
23244	champion s plate helm
23246	fiery festival brew
23247	burning blossom
23248	purified helboar meat
23249	amani invasion plans
23250	prismatic shell
23251	champion s chain helm
23252	champion s chain shoulders
23253	champion s dragonhide headguard
23254	champion s dragonhide shoulders
23255	champion s dreadweave cowl
23256	champion s dreadweave spaulders
23257	champion s leather helm
23258	champion s leather shoulders
23259	champion s mail headguard
23260	champion s mail pauldrons
23261	champion s satin hood
23262	champion s satin mantle
23263	champion s silk cowl
23264	champion s silk mantle
23265	blackened chain girdle
23266	ranger s vest
23267	satin lined boots
23268	purification mixture
23269	felblood sample
23270	tainted helboar meat
23272	knight captain s lamellar breastplate
23273	knight captain s lamellar leggings
23274	knight lieutenant s lamellar gauntlets
23275	knight lieutenant s lamellar sabatons
23276	lieutenant commander s lamellar headguard
23277	lieutenant commander s lamellar shoulders
23278	knight lieutenant s chain greaves
23279	knight lieutenant s chain vices
23280	knight lieutenant s dragonhide grips
23281	knight lieutenant s dragonhide treads
23282	knight lieutenant s dreadweave handwraps
23283	knight lieutenant s dreadweave walkers
23284	knight lieutenant s leather grips
23285	knight lieutenant s leather walkers
23286	knight lieutenant s plate gauntlets
23287	knight lieutenant s plate greaves
23288	knight lieutenant s satin handwraps
23289	knight lieutenant s satin walkers
23290	knight lieutenant s silk handwraps
23291	knight lieutenant s silk walkers
23292	knight captain s chain hauberk
23293	knight captain s chain legguards
23294	knight captain s dragonhide chestpiece
23295	knight captain s dragonhide leggings
23296	knight captain s dreadweave legguards
23297	knight captain s dreadweave tunic
23298	knight captain s leather chestpiece
23299	knight captain s leather legguards
23300	knight captain s plate hauberk
23301	knight captain s plate leggings
23302	knight captain s satin legguards
23303	knight captain s satin tunic
23304	knight captain s silk legguards
23305	knight captain s silk tunic
23306	lieutenant commander s chain helm
23307	lieutenant commander s chain shoulders
23308	lieutenant commander s dragonhide headguard
23309	lieutenant commander s dragonhide shoulders
23310	lieutenant commander s dreadweave cowl
23311	lieutenant commander s dreadweave spaulders
23312	lieutenant commander s leather helm
23313	lieutenant commander s leather shoulders
23314	lieutenant commander s plate helmet
23315	lieutenant commander s plate shoulders
23316	lieutenant commander s satin hood
23317	lieutenant commander s satin mantle
23318	lieutenant commander s silk cowl
23319	lieutenant commander s silk mantle
23320	tablet of flame shock vi
23321	recruit s robe
23322	acolyte s robe
23323	crown of the fire festival
23324	mantle of the fire festival
23326	midsummer sausage
23327	fire toasted bun
23329	enriched lasher root
23330	wilted petal
23331	broken vine
23332	withered lasher root
23333	shattered power core
23334	cracked power core
23336	helboar blood sample
23337	cenarion antidote
23338	eroded leather case
23339	arelion s journal
23340	arelion s journal page 2
23341	arelion s journal page 3
23342	arelion s journal page 4
23343	torn pilgrim s pack
23344	scout s pants
23345	scout s shirt
23346	battleworn claymore
23347	weathered crossbow
23348	scout s boots
23349	battleworn shoes
23350	battleworn pants
23351	battleworn shirt
23352	potent voidwalker essence
23353	mana residue
23354	crystalized mana residue
23355	toxic helboar meat
23357	hatched ravager egg
23358	signaling gem
23360	head of instructor razuvious
23361	cleansing vial
23362	hammer of the sun
23363	titanic breastplate
23364	zzdeprecatedheart of the sky
23365	steel rimmed buckler
23366	zzdeprecatedperfect diamond
23367	light silk robe
23368	soft leather boots
23370	ley keeper s blade
23371	velania s walking stick
23372	bloodhawk claymore
23373	long knife
23374	warp hound blood
23375	black leather vest
23376	gatewatcher s chain gloves
23377	guard s leggings
23378	undamaged warp hound corpse
23379	cinder bracers
23380	broken power core
23381	chipped power core
23383	ripped wyrm scale
23384	dimly glowing eye
23385	dormant mana powder
23386	condensed mana powder
23387	bonestripper tail feather
23388	tranquillien tabard
23389	empty draenei supply pouch
23390	exodar bastard sword
23391	exodar dagger
23392	exodar maul
23393	exodar shortsword
23394	healing salve
23395	farstrider s buckler
23396	slightly used ranger s blade
23397	satin lined gloves
23398	worn ranger s bow
23399	fallen apprentice s robe
23400	sylastor s cloak
23401	divining crystal
23402	arcanist s dagger
23403	salvaged mail leggings
23404	padded running shoes
23405	farstrider s tunic
23406	sentry bracers
23407	supple cotton bracer
23408	farstrider s bracers
23409	well crafted long bow
23410	well crafted sword
23411	well crafted staff
23412	troll kickers
23413	troll kickers
23414	troll kickers
23415	survival knife
23417	sanctified crystal
23420	engraved axe
23421	engraved sword
23422	engraved dagger
23423	mercenary greatsword
23424	fel iron ore
23425	adamantite ore
23426	khorium ore
23427	eternium ore
23429	mercenary clout
23430	mercenary sword
23431	mercenary stiletto
23432	engraved greatsword
23433	blood robes
23434	robes of the shard
23435	elderberry pie
23436	living ruby
23437	talasite
23438	star of elune
23439	noble topaz
23440	dawnstone
23441	nightseye
23442	glowing sanctified crystal
23444	goldenmist special brew
23445	fel iron bar
23446	adamantite bar
23447	eternium bar
23448	felsteel bar
23449	khorium bar
23451	grand marshal s mageblade
23452	grand marshal s tome of power
23453	grand marshal s tome of restoration
23454	grand marshal s warhammer
23455	grand marshal s demolisher
23456	grand marshal s swiftblade
23457	high warlord s destroyer
23458	high warlord s spellblade
23459	high warlord s battle mace
23460	broken blood sample
23461	high warlord s quickblade
23462	high warlord s tome of destruction
23463	high warlord s tome of mending
23464	high warlord s battle mace
23465	high warlord s destroyer
23466	high warlord s spellblade
23467	high warlord s quickblade
23468	high warlord s tome of destruction
23469	high warlord s tome of mending
23470	rugged trapper s shirt
23471	rugged trapper s pants
23472	rugged trapper s boots
23473	recruit s shirt
23474	recruit s pants
23475	recruit s boots
23476	squire s shirt
23477	squire s pants
23478	recruit s pants
23479	recruit s robe
23480	lit torch
23482	fel iron plate gloves
23483	haal eshi scroll
23484	fel iron plate belt
23485	empty birdcage
23486	caged female kaliri hatchling
23487	fel iron plate boots
23488	fel iron plate pants
23489	fel iron breastplate
23490	fel iron chain tunic
23491	fel iron chain gloves
23492	suntouched special reserve
23493	fel iron chain coif
23494	fel iron chain bracers
23495	springpaw appetizer
23497	fel iron hatchet
23498	fel iron hammer
23499	fel iron greatsword
23500	saltheril s haven party invitation
23501	bloodthistle petal
23502	adamantite maul
23503	adamantite cleaver
23504	adamantite dagger
23505	adamantite rapier
23506	adamantite plate bracers
23507	adamantite breastplate
23508	adamantite plate gloves
23509	enchanted adamantite breastplate
23510	enchanted adamantite belt
23511	enchanted adamantite boots
23512	enchanted adamantite leggings
23513	flamebane breastplate
23514	flamebane gloves
23515	flamebane bracers
23516	flamebane helm
23517	felsteel gloves
23518	felsteel leggings
23519	felsteel helm
23520	ragesteel gloves
23521	ragesteel helm
23522	ragesteel breastplate
23523	khorium pants
23524	khorium belt
23525	khorium boots
23526	swiftsteel gloves
23527	earthpeace breastplate
23528	fel sharpening stone
23529	adamantite sharpening stone
23530	felsteel shield spike
23531	felfury gauntlets
23532	gauntlets of the iron tower
23533	steelgrip gauntlets
23534	storm helm
23535	helm of the stalwart defender
23536	oathkeeper s helm
23537	black felsteel bracers
23538	bracers of the green fortress
23539	blessed bracers
23540	felsteel longblade
23541	khorium champion
23542	fel edged battleaxe
23543	felsteel reaper
23544	runic hammer
23545	power of the scourge
23546	fel hardened maul
23547	resilience of the scourge
23548	might of the scourge
23549	fortitude of the scourge
23550	heavy stone axe
23551	azure phial
23552	filled azure phial
23553	living branch
23554	eternium runed blade
23555	dirge
23556	hand of eternity
23557	larvae of the great worm
23558	the burrower s shell
23559	lesser rune of warding
23560	arena team charter 2v2
23561	arena team charter 3v3
23562	arena team charter 5v5
23563	nether chain shirt
23564	twisting nether chain shirt
23565	embrace of the twisting nether
23566	azure phial
23568	bundle of vials
23569	letter from the mag har
23570	jom gabbar
23571	primal might
23572	primal nether
23573	hardened adamantite bar
23574	recipe transmute primal might
23575	lesser ward of shielding
23576	greater ward of shielding
23577	the hungering cold
23578	diet mcweaksauce
23579	the mcweaksauce classic
23580	avruu s orb
23584	loch modan lager
23585	stouthammer lite
23586	aerie peak pale ale
23587	mirren s drinking hat
23588	kaliri feather
23589	mag har ancestral beads
23590	plans adamantite maul
23591	plans adamantite cleaver
23592	plans adamantite dagger
23593	plans adamantite rapier
23594	plans adamantite plate bracers
23595	plans adamantite plate gloves
23596	plans adamantite breastplate
23597	plans enchanted adamantite belt
23598	plans enchanted adamantite boots
23599	plans enchanted adamantite breastplate
23600	plans enchanted adamantite leggings
23601	plans flamebane bracers
23602	plans flamebane helm
23603	plans flamebane gloves
23604	plans flamebane breastplate
23605	plans felsteel gloves
23606	plans felsteel leggings
23607	plans felsteel helm
23608	plans khorium belt
23609	plans khorium pants
23610	plans khorium boots
23611	plans ragesteel gloves
23612	plans ragesteel helm
23613	plans ragesteel breastplate
23614	red snapper
23615	plans swiftsteel gloves
23616	crushed crystal fragment
23617	plans earthpeace breastplate
23618	plans adamantite sharpening stone
23619	plans felsteel shield spike
23620	plans felfury gauntlets
23621	plans gauntlets of the iron tower
23622	plans steelgrip gauntlets
23623	plans storm helm
23624	plans helm of the stalwart defender
23625	plans oathkeeper s helm
23626	plans black felsteel bracers
23627	plans bracers of the green fortress
23628	plans blessed bracers
23629	plans felsteel longblade
23630	plans khorium champion
23631	plans fel edged battleaxe
23632	plans felsteel reaper
23633	plans runic hammer
23634	plans fel hardened maul
23635	plans eternium runed blade
23636	plans dirge
23637	plans hand of eternity
23638	plans lesser ward of shielding
23639	plans greater ward of shielding
23642	sha naar relic
23643	purifying earth
23644	crate of reagents
23645	seer s relic
23646	shipment of rare crystals
23654	draenei fishing net
23655	elven manacles
23657	dawn runner cargo
23658	advisor s pack
23659	fel tainted morsels
23660	advisor s rapier
23661	mark of the lightbringer
23662	letter from nazgrel
23663	girdle of elemental fury
23664	pauldrons of elemental fury
23665	leggings of elemental fury
23666	belt of the grand crusader
23667	spaulders of the grand crusader
23668	leggings of the grand crusader
23669	ancestral spirit wolf totem
23670	thalanaar moonwell water
23671	earth crystal
23672	crate of red snapper
23675	robotron control unit
23676	moongraze stag tenderloin
23677	moongraze buck hide
23678	faintly glowing crystal
23679	bloodscalp totem
23680	gift of naias
23681	heart of naias
23682	ritual torch
23685	root trapper vine
23686	lacy handkerchief
23687	blacktalon s claws
23688	hauteur s ashes
23691	corrupted mark of the lightbringer
23692	azure snapdragon bulb
23693	carinda s scroll of retribution
23694	gryphon egg
23695	featherbeard s map
23697	taming rod
23702	taming rod
23703	taming rod
23704	eversong port
23705	tabard of flame
23706	arcane fragment
23707	spindleweb silk gland
23709	tabard of frost
23710	upperdeck tabard #3
23711	grimoire of intercept rank 1
23712	white tiger cub
23713	hippogryph hatchling
23714	perpetual purple firework
23715	permanent lung juice cocktail
23716	carved ogre idol
23717	pitted gold band
23718	permanent ground scorpok assay
23719	permanent cerebral cortex compound
23720	riding turtle
23721	permanent gizzard gum
23722	permanent r o i d s
23723	warchief kargath s fist
23726	fel ember
23729	fel horde banner
23730	grimoire of intercept rank 2
23731	grimoire of intercept rank 3
23732	voidstone
23733	ritual torch
23734	grimoire of cleave rank 1
23735	grand warlock s amulet
23736	fel iron bomb
23737	adamantite grenade
23738	nautical compass
23739	nautical map
23740	top secret venture company plans
23742	fel iron musket
23744	foul essence
23745	grimoire of cleave rank 2
23746	adamantite rifle
23747	felsteel boomstick
23748	ornate khorium rifle
23749	empty bota bag
23750	filled bota bag
23751	skin of purest water
23752	flask of purest water
23753	drycap mushroom
23754	bristlehide clefthoof hide
23755	grimoire of cleave rank 3
23756	cookie s jumbo gumbo
23757	skittering crawler meat
23758	cogspinner goggles
23759	rune covered tablet
23760	chalice of elune
23761	power amplification goggles
23762	ultra spectropic detection goggles
23763	hyper vision goggles
23764	adamantite scope
23765	khorium scope
23766	stabilized eternium scope
23767	crashin thrashin robot
23768	white smoke flare
23769	red smoke flare
23770	blue smoke flare
23771	green smoke flare
23772	fel iron shells
23773	adamantite shells
23774	fel iron toolbox
23775	titanium toolbox
23776	warsong lumber
23777	diabolical plans
23778	sentinel luciel s report
23779	ancient relic
23780	diabolical plans
23781	elemental blasting powder
23782	fel iron casing
23783	handful of fel iron bolts
23784	adamantite frame
23785	hardened adamantite tube
23786	khorium power core
23787	felsteel stabilizer
23788	tree seedlings
23789	remains of cowlen s family
23790	hollowed out tree
23791	pile of leaves
23792	tree disguise kit
23793	heavy knothide leather
23794	permanent sheen of zanza
23795	permanent spirit of zanza
23796	permanent swiftness of zanza
23797	diabolical plans
23798	diabolical plans
23799	schematic adamantite rifle
23800	schematic felsteel boomstick
23801	bristlelimb key
23802	schematic ornate khorium rifle
23803	schematic cogspinner goggles
23804	schematic power amplification goggles
23805	schematic ultra spectropic detection goggles
23806	schematic hyper vision goggles
23807	schematic adamantite scope
23808	schematic khorium scope
23809	schematic stabilized eternium scope
23810	schematic crashin thrashin robot
23811	schematic white smoke flare
23812	schematic red smoke flare
23813	schematic blue smoke flare
23814	schematic green smoke flare
23815	schematic adamantite shell machine
23816	schematic fel iron toolbox
23817	schematic titanium toolbox
23818	stillpine furbolg language primer
23819	elemental seaforium charge
23820	critter enlarger
23821	zapthrottle mote extractor
23822	healing potion injector
23823	mana potion injector
23824	rocket boots xtreme
23825	nigh invulnerability belt
23826	the bigger one
23827	super sapper charge
23828	gnomish power goggles
23829	gnomish battle goggles
23830	clopper s equipment
23831	goblin tonk controller
23832	gnomish tonk controller
23833	crude murloc knife
23834	crude murloc idol
23835	gnomish poultryizer
23836	goblin rocket launcher
23837	weathered treasure map
23838	foreman s enchanted helmet
23839	foreman s reinforced helmet
23840	remote mail terminal
23841	gnomish flame turret
23843	whorl of air
23844	nolkai s lantern
23845	ravager hide
23846	nolkai s box
23847	nolkai s band
23848	nethergarde bitter
23849	stillpine grain
23850	gurf s dignity
23851	battered journal
23852	nolkai s bag
23853	letter to <name>
23854	shadoweave cloth
23855	spellfire cloth
23857	legacy of the mountain king
23858	singed page
23859	nazzivus monument glyph
23860	the kurken s hide
23861	drawing kit
23862	redemption of the fallen
23863	corrupted crystal
23864	torment of the worgen
23865	wrath of the titans
23866	singed page
23867	singed page
23868	singed page
23869	crystallized bark
23870	red crystal pendant
23871	potion of water breathing
23872	blue satchel
23873	galaen s amulet
23874	schematic elemental seaforium charge
23875	crystal mining pick
23876	crystal mining pick
23877	crystal mining pick
23878	impact site crystal sample
23879	altered crystal sample
23880	axxarien crystal sample
23881	gargolmar s hand
23882	schematic critter enlarger
23883	schematic healing potion injector
23884	schematic mana potion injector
23885	schematic remote mail terminal
23886	omor s hoof
23887	schematic rocket boots xtreme
23888	schematic zapthrottle mote extractor
23890	ominous letter
23891	ominous letter
23892	ominous letter
23893	ominous letter
23894	fel orc blood vial
23895	netted goods
23896	taming totem
23897	taming totem
23898	taming totem
23899	traitor s communication
23900	tzerak s armor plate
23901	nazan s head
23902	topher s list
23903	nurguni s supplies
23904	shattered blade
23909	blood elf bandit mask
23910	blood elf communication
23919	stack of reports
23920	tattered handkerchief
23921	bulging sack of silver
23922	rat skeleton
23923	amani sacrificial dagger
23924	robes of silvermoon
23925	ravager cage key
23926	tome of divinity
23927	sand pear
23928	the exarch s orders
23929	letter from lor themar theron
23930	letter sealed by sylvanas
23931	azure watch robes
23932	survey data crystal
23933	medivh s journal
23934	medivh s journal
23937	letter of introduction
23938	pristine ravager carapace
23939	pristine ravager claw
23940	pristine ravager fang
23941	crushed ravager carapace
23942	crushed ravager fang
23943	crushed ravager claw
23944	broken ravager carapace
23945	broken ravager fang
23946	broken ravager claw
23947	cracked ravager carapace
23948	cracked ravager fang
23949	cracked ravager claw
23950	damaged ravager carapace
23951	damaged ravager fang
23952	damaged ravager claw
23953	worn ravager carapace
23954	worn ravager fang
23955	worn ravager claw
23957	weathered ravager carapace
23958	weathered ravager fang
23959	weathered ravager claw
23960	beaten ravager carapace
23961	beaten ravager fang
23962	beaten ravager claw
23965	chipped ravager claw
23966	flawed ravager carapace
23967	flawed ravager fang
23968	flawed ravager claw
23969	imperfect ravager carapace
23970	imperfect ravager fang
23971	imperfect ravager claw
23972	mangled ravager carapace
23973	mangled ravager fang
23974	mangled ravager claw
23975	damaged ravager fang
23976	gnarled ravager carapace
23977	gnarled ravager fang
23978	gnarled ravager claw
23979	chipped ravager carapace
23980	chipped ravager fang
23981	steam pump part
23982	kessel s whistle
23983	shadowbat blood
23984	irradiated crystal shard
23985	crystal of vitality
23986	crystal of insight
23987	mutated petal
23988	mutated vine
23989	crystal of ferocity
23990	completed star chart
23992	torn saurian pelt
23993	cracked saurian claw
23994	thorny constrictor vine
23995	murloc tagger
23997	head of tel athion
23999	honor hold tabard
24000	formula enchant bracer superior healing
24001	recipe elixir of major agility
24002	plans felsteel shield spike
24003	formula enchant chest exceptional stats
24004	thrallmar tabard
24005	murloc tag stub
24006	grunt s waterskin
24007	footman s waterskin
24008	dried mushroom rations
24009	dried fruit rations
24020	shadowrend longblade
24021	light touched breastplate
24022	scale leggings of the skirmisher
24023	bracers of finesse
24024	pauldrons of arcane rage
24025	deathclaw s paw
24026	elder brown bear flank
24027	bold living ruby
24028	delicate living ruby
24029	teardrop living ruby
24030	runed living ruby
24031	bright living ruby
24032	subtle living ruby
24033	solid star of elune
24035	sparkling star of elune
24036	flashing living ruby
24037	lustrous star of elune
24039	stormy star of elune
24040	blood mushroom
24041	aquatic stinkhorn
24042	ruinous polyspore
24043	fel cone fungus
24044	hellreaver
24045	band of renewal
24046	kilt of rolling thunders
24047	brilliant dawnstone
24048	smooth dawnstone
24049	ysera s tear
24050	gleaming dawnstone
24051	rigid dawnstone
24052	thick dawnstone
24053	mystic dawnstone
24054	sovereign nightseye
24055	shifting nightseye
24056	glowing nightseye
24057	royal nightseye
24058	inscribed noble topaz
24059	potent noble topaz
24060	luminous noble topaz
24061	glinting noble topaz
24062	enduring talasite
24063	shifting sash of midnight
24064	ironsole clompers
24065	dazzling talasite
24066	radiant talasite
24067	jagged talasite
24068	arcane residue
24069	crystalfire staff
24071	bland dagger
24072	sand pear pie
24073	garrote string necklace
24074	fel iron blood ring
24075	golden draenite ring
24076	azure moonstone ring
24077	thick adamantite necklace
24078	heavy adamantite ring
24079	khorium band of shadows
24080	khorium band of frost
24081	satyrnaar fel wood
24082	khorium inferno band
24083	lifegiver britches
24084	draenei banner
24085	khorium band of leaves
24086	arcane khorium band
24087	heavy felsteel ring
24088	delicate eternium ring
24089	blazing eternium band
24090	bloodstained ravager gauntlets
24091	tenacious defender
24092	pendant of frozen flame
24093	pendant of thawing
24094	heart fire warhammer
24095	pendant of withering
24096	heartblood prayer beads
24097	pendant of shadow s end
24098	pendant of the null rune
24099	the high chief s key
24100	warder s dagger
24101	book of ferocious bite v
24102	manual of eviscerate ix
24103	moongraze hide boots
24104	moongraze fur cloak
24105	roasted moongraze tenderloin
24106	thick felsteel necklace
24107	ravager chitin tunic
24108	ravager hide leggings
24109	thick ravager belt
24110	living ruby pendant
24111	kurken hide jerkin
24112	kurkenstoks
24113	cowlen s bracers of kinship
24114	braided eternium chain
24115	testprospectironore
24116	eye of the night
24117	embrace of the dawn
24118	signet of argas
24119	band of argas
24120	seal of argas
24121	chain of the twilight owl
24122	coronet of verdant flame
24123	circlet of arcane might
24124	figurine felsteel boar
24125	figurine dawnstone crab
24126	figurine living ruby serpent
24127	figurine talasite owl
24128	figurine nightseye panther
24129	salvaged leather belt
24130	worn slippers
24131	slightly rusted bracers
24132	a letter from the admiral
24133	weathered mail tunic
24134	weathered leather vest
24135	weathered cloth armor
24136	farstrider s bow
24138	silver crossbow
24139	faint arcane essence
24140	blackened urn
24141	battle worn gauntlets
24142	battle worn gloves
24143	initiate s shirt
24144	battle worn handguards
24145	initiate s pants
24146	initiate s boots
24147	unprepared star chart
24148	partial star chart
24149	unfinished star chart
24150	mok nathal wildercloak
24151	mok nathal clan ring
24152	charred bone fragment
24153	bloodcursed soul
24154	witching band
24155	ursol s claw
24156	filled shimmering vessel
24157	shimmering vessel
24158	design khorium band of shadows
24159	design khorium band of frost
24160	design khorium inferno band
24161	design khorium band of leaves
24162	design arcane khorium band
24163	design heavy felsteel ring
24164	design delicate eternium ring
24165	design blazing eternium band
24166	design thick felsteel necklace
24167	design living ruby pendant
24168	design braided eternium chain
24169	design eye of the night
24170	design embrace of the dawn
24171	design chain of the twilight owl
24172	design coronet of verdant flame
24173	design circlet of arcane might
24174	design pendant of frozen flame
24175	design pendant of thawing
24176	design pendant of withering
24177	design pendant of shadow s end
24178	design pendant of the null rune
24179	design felsteel boar
24180	design dawnstone crab
24181	design living ruby serpent
24182	design talasite owl
24183	design nightseye panther
24184	filled shimmering vessel
24185	dragon bone
24186	copper powder
24187	shiny rock
24188	tin powder
24189	crystalline fragments
24190	iron powder
24191	small gem shards
24192	design bright living ruby
24193	design bold living ruby
24194	design delicate living ruby
24195	design teardrop living ruby
24196	design runed living ruby
24197	design subtle living ruby
24198	design flashing living ruby
24199	design solid star of elune
24200	design sparkling star of elune
24201	design lustrous star of elune
24202	design stormy star of elune
24203	design brilliant dawnstone
24204	design smooth dawnstone
24205	design rigid dawnstone
24206	design gleaming dawnstone
24207	design thick dawnstone
24208	design mystic dawnstone
24209	design sovereign nightseye
24210	design shifting nightseye
24211	design glowing nightseye
24212	design royal nightseye
24213	design inscribed noble topaz
24214	design potent noble topaz
24215	design luminous noble topaz
24216	design glinting noble topaz
24217	design enduring talasite
24218	design radiant talasite
24219	design dazzling talasite
24220	design jagged talasite
24221	bundle of dragon bones
24222	the shadowfoot stabber
24223	bloodvalor s notes
24224	crate of bloodforged ingots
24225	blood of the wrathful
24226	blood knight insignia
24227	soft leather belt
24228	the sun king s command
24230	velen s orders
24231	coarse snuff
24232	shabby knot
24233	discarded nutriment
24234	mithril powder
24235	thorium powder
24236	medical supplies
24237	galaen s journal
24238	mushroom sample
24239	crate of materials
24240	box of mushrooms
24241	green chain belt
24242	fel iron powder
24243	adamantite powder
24245	glowcap
24246	sanguine hibiscus
24247	underspore frond
24248	brain of the black stalker
24249	unyielding bracers
24250	bracers of havok
24251	blackstrike bracers
24252	cloak of the black void
24253	cloak of eternity
24254	white remedy cape
24255	unyielding girdle
24256	girdle of ruination
24257	black belt of knowledge
24258	resolute cape
24259	vengeance wrap
24260	manaweave cloak
24261	whitemend pants
24262	spellstrike pants
24263	battlecast pants
24264	whitemend hood
24266	spellstrike hood
24267	battlecast hood
24268	netherweave net
24269	netherweave net
24270	bag of jewels
24271	spellcloth
24272	shadowcloth
24273	mystic spellthread
24274	runic spellthread
24275	silver spellthread
24276	golden spellthread
24277	items for magister astalor bloodsworn
24278	flare gun
24279	vicious teromoth sample
24280	naga claws
24281	carved ivory bone
24282	rogue s diary
24283	an antique gun
24284	tyr s hand holy water
24285	crepuscular powder
24286	arcane catalyst
24287	extinguishing mixture
24288	rune thread
24289	chrono beacon
24290	mature spore sac
24291	bog lord tendril
24292	pattern mystic spellthread
24293	pattern silver spellthread
24294	pattern runic spellthread
24295	pattern golden spellthread
24296	pattern unyielding bracers
24297	pattern bracers of havok
24298	pattern blackstrike bracers
24299	pattern cloak of the black void
24300	pattern cloak of eternity
24301	pattern white remedy cape
24302	pattern unyielding girdle
24303	pattern girdle of ruination
24304	pattern black belt of knowledge
24305	pattern resolute cape
24306	pattern vengeance wrap
24307	pattern manaweave cloak
24308	pattern whitemend pants
24309	pattern spellstrike pants
24310	pattern battlecast pants
24311	pattern whitemend hood
24312	pattern spellstrike hood
24313	pattern battlecast hood
24314	pattern bag of jewels
24315	pattern heavy netherweave net
24316	pattern spellcloth
24317	bloodmyst water sample
24318	water sample flask
24323	translated sunhawk missive
24330	drain schematics
24334	wheel of the lost hope
24335	orb of returning
24336	fireproof satchel
24337	deactivating jewel
24338	hellfire spineleaf
24339	stung
24340	vandril s hand me down pants
24341	fortified oven mitts
24342	stillpine shocker
24343	the thumper
24344	tabard of the hand
24345	book of cower iv
24346	robe of the dragon slayer
24347	vest of the dragon slayer
24348	tunic of the dragon slayer
24349	signet ring of the hand
24350	signet ring of the hand
24351	mace of the hand
24352	blade of the hand
24353	crossbow of the hand
24354	staff of the hand
24355	ironvine seeds
24356	wastewalker shiv
24357	vest of living lightning
24359	princely reign leggings
24360	tracker s belt
24361	spellfire longsword
24362	spore soaked vaneer
24363	unscarred breastplate
24364	azureplate greaves
24365	deft handguards
24366	scorpid sting mantle
24367	orders from lady vashj
24368	coilfang armaments
24369	coilfang spellbook
24372	diaphanous wing
24373	scout jyoba s report
24374	eel filet
24375	thick hydra scale
24376	runed fungalcap
24378	coilfang hammer of renewal
24379	bogstrok scale cloak
24380	calming spore reed
24381	coilfang needler
24382	zurai s report
24383	fulgor spore
24384	diamond core sledgemace
24385	pendant of battle lust
24386	libram of saints departed
24387	ironblade gauntlets
24388	girdle of the gale storm
24389	legion blunderbuss
24390	auslese s light channeler
24391	kilt of the night strider
24392	arcing bracers
24393	bloody surgeon s mitts
24394	warsong howling axe
24395	mindfire waistband
24396	vest of vengeance
24397	raiments of divine authority
24398	mantle of the dusk dweller
24399	sunhawk missive
24400	dead mire soil sample
24401	unidentified plant parts
24402	package of identified plants
24403	common fern
24404	ruined specimen
24405	common azerothian species
24406	common flower
24407	uncatalogued species
24408	edible stalks
24411	ikeyen s belongings
24412	warden s arrow
24413	totem of the thunderhead
24414	blood elf plans
24415	vindicator idaar s letter
24416	corrupted flower
24417	scout s arrow
24419	digested caracoli
24421	nagrand cherry
24422	feralfen idol
24423	beaten chain leggings
24424	rough leather leggings
24425	hand sewn pants
24426	spore bat eye
24427	fen strider tentacle
24428	ahuurn s elixir
24429	expedition flare
24430	seafarer s blade
24431	mcweaksauce s meat tenderizer
24432	the shell cracker
24433	crossbow of the albatross
24434	the discipline stick
24435	reinforced mail boots
24436	huntsman s bracers
24437	slightly worn bracer
24438	fur covered robe
24439	savage leggings
24440	heavy chain leggings
24441	exodar crossbow
24442	mail belt of the silverpine
24443	bracers of shed fur
24444	newly weaved pants
24445	fortified wristguards
24446	sturdy leather belt
24447	naga scale boots
24448	battle tested blade
24449	fertile spores
24450	manaspark gloves
24451	lykul bloodbands
24452	starlight gauntlets
24453	zangartooth shortblade
24454	cloak of enduring swiftness
24455	tunic of the nightwatcher
24456	greaves of the iron guardian
24457	truth bearer shoulderguards
24458	studded girdle of virtue
24459	cloak of healing rays
24460	talisman of tenacity
24461	hatebringer
24462	luminous pearls of insight
24463	pauldrons of brute force
24464	the stalker s fangs
24465	shamblehide chestguard
24466	skulldugger s leggings
24467	living fire
24468	burstcap mushroom
24469	muck ridden core
24470	murloc cage
24471	ango rosh attack plans
24472	boss grog ak s head
24473	enraged crusher core
24474	violet scrying crystal
24475	gordawg s imprint
24476	jaggal clam
24477	jaggal clam meat
24478	jaggal pearl
24479	shadow pearl
24480	ghostly essence
24481	robes of the augurer
24482	alturus s report
24483	withered basidium
24484	withered basidium
24485	marshlight bleeder venom
24486	fenclaw hide
24487	second key fragment
24488	third key fragment
24489	restored apprentice s key
24490	the master s key
24491	cannonball
24492	keanna s log
24493	marshfang slicer blade
24494	tears of the goddess
24496	horn of banthar
24497	feralfen protection totem
24498	feralfen totem
24499	daggerfen poison manual
24500	daggerfen poison vial
24501	gordawg s boulder
24502	warmaul skull
24503	gurok s earthen head
24504	howling wind
24505	heart of tusker
24506	elemental sliver
24507	elemental shard
24508	elemental fragment
24509	primordial element
24510	primordial core
24511	primordial essence
24513	eye of gutripper
24514	first key fragment
24515	mangy mane
24516	damaged rock flayer talon
24517	blood soaked tail
24518	coarse mane
24519	twisted rock flayer talon
24520	honor hold favor
24521	mangled tail
24522	thrallmar favor
24523	hoof of bach lor
24538	fire bomb
24539	marsh lichen
24540	edible fern
24541	medicinal swamp moss
24542	murkblood idol
24543	head of ortor of murkblood
24544	gladiator s plate chestpiece
24545	gladiator s plate helm
24546	gladiator s plate shoulders
24547	gladiator s plate legguards
24549	gladiator s plate gauntlets
24550	gladiator s greatsword
24551	talisman of the horde
24552	gladiator s dreadweave robe
24553	gladiator s dreadweave hood
24554	gladiator s dreadweave mantle
24555	gladiator s dreadweave leggings
24556	gladiator s dreadweave gloves
24557	gladiator s war staff
24558	murkblood invasion plans
24559	murkblood invasion plans
24560	torch of liquid fire
24573	elder kuruti s response
24575	outlander s girdle
24576	loosely threaded belt
24577	loosely threaded boots
24578	loosely threaded bracers
24579	mark of honor hold
24580	loosely threaded hat
24581	mark of thrallmar
24582	outlander s boots
24583	outlander s tunic
24584	outlander s gloves
24585	outlander s facewrap
24586	outlander s leggings
24587	outlander s pauldrons
24588	outlander s bracers
24589	fireheart girdle
24590	fireheart boots
24591	fireheart chestpiece
24592	fireheart gloves
24593	fireheart skullcap
24594	fireheart leggings
24595	fireheart shoulderpads
24596	fireheart bracers
24597	starfire sash
24598	starfire sandals
24599	starfire vest
24600	starfire gloves
24601	starfire circlet
24602	starfire trousers
24603	starfire mantle
24604	starfire wristwraps
24605	laughing skull waistguard
24606	laughing skull boot
24607	laughing skull tunic
24608	laughing skull gloves
24609	laughing skull cap
24610	laughing skull pants
24611	laughing skull shoulderpads
24612	laughing skull bracelets
24613	vindicator belt
24614	vindicator boots
24615	vindicator tunic
24616	vindicator gloves
24617	vindicator cap
24618	vindicator pants
24619	vindicator shoulderpads
24620	vindicator bracers
24621	slavehandler belt
24622	slavehandler footpads
24623	slavehandler jerkin
24624	slavehandler handwraps
24625	slavehandler cap
24626	slavehandler pants
24627	slavehandler amice
24628	slavehandler wristguards
24629	feralfen sash
24630	feralfen sandals
24631	feralfen jerkin
24632	feralfen hand
24633	feralfen hood
24634	feralfen pants
24635	feralfen amice
24636	feralfen cuffs
24637	mistyreed belt
24638	mistyreed boot
24639	mistyreed tunic
24640	mistyreed gloves
24641	mistyreed hood
24642	mistyreed pants
24643	mistyreed shoulderpads
24644	mistyreed bracer
24645	astralaan belt
24646	astralaan boots
24647	astralaan robe
24648	astralaan gloves
24649	astralaan headdress
24650	astralaan pants
24651	astralaan shoulderpads
24652	astralaan bracer
24653	consortium sash
24654	consortium boot
24655	consortium robe
24656	consortium gloves
24657	consortium hood
24658	consortium pants
24659	consortium mantle
24660	consortium bracer
24661	shadow council chain
24662	shadow council boots
24663	shadow council tunic
24664	shadow council gloves
24665	shadow council cowl
24666	shadow council pants
24667	shadow council mantle
24668	shadow council bracer
24669	eldr naan belt
24670	eldr naan boot
24671	eldr naan jerkin
24672	eldr naan gloves
24673	eldr naan hood
24674	eldr naan pants
24675	eldr naan shoulderpads
24676	eldr naan bracelets
24677	archmage belt
24678	archmage slippers
24679	archmage robe
24680	archmage gloves
24681	archmage headpiece
24682	archmage pants
24683	archmage mantle
24684	archmage bracelets
24685	elementalist belt
24686	elementalist boots
24687	elementalist tunic
24688	elementalist gloves
24689	elementalist skullcap
24690	elementalist leggings
24691	elementalist mantle
24692	elementalist bracelets
24693	bonechewer pelt girdle
24694	bonechewer shredboots
24695	bonechewer chestpiece
24696	bonechewer spikegloves
24697	bonechewer skincloak
24698	bonechewer ripleggings
24699	bonechewer shoulderguards
24700	bonechewer bands
24701	haal eshi cord
24702	haal eshi boots
24703	haal eshi jerkin
24704	haal eshi gloves
24705	haal eshi hat
24706	haal eshi leggings
24707	haal eshi pauldrons
24708	haal eshi bindings
24709	vengeance belt
24710	vengeance boots
24711	vengeance chestpiece
24712	vengeance gloves
24713	vengeance helm
24714	vengeance legguards
24715	vengeance pauldrons
24716	vengeance bands
24717	dreghood belt
24718	dreghood boots
24719	dreghood chestpiece
24720	dreghood gloves
24721	dreghood cowl
24722	dreghood trousers
24723	dreghood pauldrons
24724	dreghood bands
24725	dementia cord
24726	dementia boots
24727	dementia vest
24728	dementia gloves
24729	dementia hood
24730	dementia trousers
24731	dementia shoulderguards
24732	dementia armguards
24733	sunroc waistband
24734	sunroc boots
24735	sunroc chestpiece
24736	sunroc gloves
24737	sunroc mask
24738	sunroc pants
24739	sunroc shoulderguards
24740	sunroc armguards
24741	ranger belt
24742	ranger boots
24743	ranger jerkin
24744	ranger gloves
24745	ranger hat
24746	ranger pants
24747	ranger pauldrons
24748	ranger armguards
24749	daggerfen belt
24750	daggerfen boots
24751	daggerfen battlevest
24752	daggerfen gloves
24753	daggerfen cowl
24754	daggerfen stitchpants
24755	daggerfen pauldrons
24756	daggerfen bindings
24757	umbrafen waistband
24758	umbrafen boots
24759	umbrafen tunic
24760	umbrafen gloves
24761	umbrafen cap
24762	umbrafen britches
24763	umbrafen shoulderguards
24764	umbrafen bindings
24765	clefthoof belt
24766	clefthoof wanderboots
24767	clefthoof hidemantle
24768	clefthoof gloves
24769	clefthoof cover
24770	clefthoof britches
24771	clefthoof shoulderguards
24772	clefthoof bracers
24773	boneshredder belt
24774	boneshredder boots
24775	boneshredder jerkin
24776	boneshredder gloves
24777	boneshredder skullcap
24778	boneshredder britches
24779	boneshredder shoulderguards
24780	boneshredder wristguards
24781	murkblood belt
24782	loosely threaded gloves
24783	murkblood boots
24784	murkblood chestpiece
24785	murkblood gloves
24786	murkblood cover
24787	murkblood pants
24788	murkblood shoulderguards
24789	murkblood bracers
24790	expedition girdle
24791	expedition boots
24792	expedition tunic
24793	expedition gloves
24794	expedition hood
24795	expedition pants
24796	expedition shoulderguards
24797	expedition bracers
24798	dragonhawk belt
24799	dragonhawk boots
24800	dragonhawk tunic
24801	dragonhawk gloves
24802	dragonhawk hat
24803	dragonhawk pants
24804	dragonhawk shoulderguards
24805	dragonhawk bands
24806	unyielding waistband
24807	unyielding footwraps
24808	unyielding chain vest
24809	unyielding fists
24810	unyielding helm
24811	unyielding leggings
24812	unyielding spaulders
24813	unyielding bindings
24814	felstone waistband
24815	felstone greaves
24816	felstone chain vest
24817	felstone gauntlets
24818	felstone helm
24819	felstone leggings
24820	felstone spaulders
24821	felstone bindings
24822	netherstalker belt
24823	netherstalker greaves
24824	netherstalker armor
24825	netherstalker gloves
24826	netherstalker helmet
24827	netherstalker legguards
24828	netherstalker mantle
24829	netherstalker bracer
24830	nexus strider belt
24831	nexus strider greaves
24832	nexus strider breastplate
24833	nexus strider gloves
24834	nexus strider helmet
24835	nexus strider legwraps
24836	nexus strider mantle
24837	nexus strider bracer
24838	wrathfin waistband
24839	wrathfin greaves
24840	wrathfin armor
24841	wrathfin gloves
24842	wrathfin helmet
24843	wrathfin legguards
24844	wrathfin mantle
24845	wrathfin bindings
24846	fenclaw waistband
24847	fenclaw footwraps
24848	fenclaw armor
24849	fenclaw fists
24850	fenclaw helm
24851	fenclaw legguards
24852	fenclaw mantle
24853	fenclaw bindings
24854	marshcreeper belt
24855	marshcreeper sludgeboots
24856	marshcreeper fen vest
24857	marshcreeper gloves
24858	marshcreeper helm
24859	marshcreeper leggings
24860	marshcreeper mantle
24861	marshcreeper bracelets
24862	blood knight girdle
24863	blood knight boots
24864	blood knight breastplate
24865	blood knight gauntlets
24866	blood knight helm
24867	blood knight greaves
24868	blood knight pauldrons
24869	blood knight bracers
24870	ironspine belt
24871	ironspine greaves
24872	ironspine chain vest
24873	ironspine gloves
24874	ironspine helm
24875	ironspine legguards
24876	ironspine shoulderguards
24877	ironspine bracelets
24878	der izu belt
24879	der izu greaves
24880	der izu chestpiece
24881	der izu fists
24882	der izu helm
24883	der izu legguards
24884	der izu spaulders
24885	der izu bracer
24886	skettis belt
24887	skettis footwraps
24888	skettis chestpiece
24889	skettis gauntlets
24890	skettis helmet
24891	skettis legguards
24892	skettis spaulders
24893	skettis bracer
24894	sundered waistband
24895	sundered footwraps
24896	sundered chestpiece
24897	sundered gauntlets
24898	sundered helmet
24899	sundered legguards
24900	sundered spaulders
24901	tortured bracer
24902	talhide stitched belt
24903	talhide lined boots
24904	talhide chestpiece
24905	talhide lined gloves
24906	talhide helmet
24907	talhide lined leggings
24908	talhide shoulderguards
24909	talhide lined bracers
24910	netherstorm belt
24911	netherstorm greaves
24912	netherstorm chestpiece
24913	netherstorm gauntlets
24914	netherstorm helm
24915	netherstorm legguards
24916	netherstorm shoulderguards
24917	netherstorm bracer
24918	grimscale belt
24919	grimscale sabatons
24920	grimscale armor
24921	grimscale gauntlets
24922	grimscale helm
24923	grimscale legguards
24924	grimscale pauldrons
24925	grimscale vambraces
24926	ango rosh belt
24927	ango rosh sabatons
24928	ango rosh breastplate
24929	ango rosh gauntlets
24930	ango rosh helm
24931	ango rosh legguards
24932	ango rosh pauldrons
24933	ango rosh vambraces
24934	darkcrest belt
24935	darkcrest sabatons
24936	darkcrest breastplate
24937	darkcrest gauntlets
24938	darkcrest helm
24939	darkcrest legguards
24940	darkcrest pauldrons
24941	darkcrest bracers
24942	bloodscale belt
24943	bloodscale sabatons
24944	bloodscale breastplate
24945	bloodscale gauntlets
24946	bloodscale helm
24947	bloodscale legguards
24948	bloodscale pauldrons
24949	bloodscale bracers
24950	bogslayer belt
24951	bogslayer sabatons
24952	bogslayer breastplate
24953	bogslayer gauntlets
24954	bogslayer helm
24955	bogslayer legplates
24956	bogslayer pauldrons
24957	bogslayer bracers
24958	khan aish girdle
24959	khan aish greaves
24960	khan aish breastplate
24961	khan aish gloves
24962	khan aish helmet
24963	khan aish legplates
24964	khan aish epaulets
24965	khan aish bracers
24966	talonguard girdle
24967	talonguard greaves
24968	talonguard armor
24969	talonguard gloves
24970	talonguard helmet
24971	talonguard legplates
24972	talonguard epaulets
24973	talonguard bracers
24974	reaver girdle
24975	reaver greaves
24976	reaver armor
24977	reaver gloves
24978	reaver helmet
24979	reaver legplates
24980	reaver epaulets
24981	reaver bracers
24982	boulderfist belt
24983	boulderfist greaves
24984	boulderfist armor
24985	boulderfist gloves
24986	boulderfist helm
24987	boulderfist legplates
24988	boulderfist epaulets
24989	boulderfist bracers
24990	warmaul belt
24991	warmaul greaves
24992	warmaul breastplate
24993	warmaul gloves
24994	warmaul helmet
24995	warmaul legplates
24996	warmaul epaulets
24997	warmaul vambraces
24998	bloodfist girdle
24999	bloodfist greaves
25000	bloodfist breastplate
25001	bloodfist gloves
25002	bloodfist helmet
25003	bloodfist legplates
25004	bloodfist epaulets
25005	bloodfist vambraces
25006	conqueror s girdle
25007	conqueror s greaves
25008	conqueror s breastplate
25009	conqueror s gauntlets
25010	conqueror s helmet
25011	conqueror s legplates
25012	conqueror s epaulets
25013	conqueror s vambraces
25014	shattered hand belt
25015	shattered hand sabatons
25016	shattered hand breastplate
25017	shattered hand gauntlets
25018	shattered hand helmet
25019	shattered hand legplates
25020	shattered hand epaulets
25021	shattered hand vambraces
25022	warlord s iron girdle
25023	warlord s sabatons
25024	warlord s iron breastplate
25025	warlord s iron gauntlets
25026	warlord s iron helm
25027	warlord s iron legplates
25028	warlord s iron epaulets
25029	warlord s iron vambraces
25030	silky velvet cloak
25031	silvermoon royal cloak
25032	hellfire cloak
25033	scavenger s cloak
25034	elementalist cloak
25035	silver lined cloak
25036	boulderfist cloak
25037	patched cape
25038	forest shroud
25039	farseer cloak
25040	murkblood cape
25041	ambusher s cloak
25042	nether cloak
25043	amber cape
25044	rubellite ring
25045	azurite ring
25046	spined ring
25047	tourmaline loop
25048	smoky quartz ring
25049	scheelite ring
25050	moldavite ring
25051	blue topaz band
25052	hauyne ring
25053	lazuli ring
25054	sodalite band
25055	alexandrite ring
25056	almandine ring
25057	amber band
25058	anglesite choker
25059	fire opal collar
25060	sunstone necklace
25061	hiddenite necklace
25062	zircon amulet
25063	multi colored beads
25064	amethyst pendant
25065	turquoise brooch
25066	pink sapphire necklace
25067	diopside beads
25068	kunzite necklace
25069	epidote stone necklace
25070	coral beads
25071	tanzanite pendant
25072	northman s shield
25073	emperor shield
25074	telaari shield
25075	hardened steel shield
25076	screaming shield
25077	modani war shield
25078	zangari shield
25079	outland shield
25080	spell breaker shield
25081	bayeaux shield
25082	fel iron shield
25083	smouldering shield
25084	zeth gor shield
25085	dragonscale shield
25086	dreamseeker dandelion
25087	bleeding eye
25088	laughing skull orb
25089	supplicant s rod
25090	slavehandler rod
25091	mistyreed torch
25092	consortium crystal
25093	shadow council orb
25094	eldr naan scepter
25095	archmage orb
25096	elementalist star
25097	astralaan orb
25098	tuurik torch
25099	draenei crystal rod
25100	liege blade
25101	cross pommel dagger
25102	jaedenis dagger
25103	nightstalker dagger
25104	anzac dagger
25105	arachnid dagger
25106	cobra shortblade
25107	draconic dagger
25108	grave keeper knife
25109	moon blade
25110	sharp bowie knife
25111	lionhead dagger
25112	fel ripper
25113	phantom dagger
25114	doomsayer s mace
25115	riversong mace
25116	pneumatic war hammer
25117	flanged battle mace
25118	battle star
25119	silvermoon war mace
25120	rockshard club
25121	dreaded mace
25122	khorium plated bludgeon
25123	boneshredder mace
25124	footman mace
25125	retro spike club
25126	anvilmar hammer
25127	knight s war hammer
25128	shining mace
25129	giant s leg bone
25130	gronn bone club
25131	hateful bludgeon
25132	thrallmar war hammer
25133	stormwind maul
25134	highmountain hammer
25135	clefthoof mace
25136	blood stained hammer
25137	draenethyst mallet
25138	blood knight maul
25139	algaz battle hammer
25140	commanding mallet
25141	halaani hammer
25142	telaari longblade
25143	silver hand blade
25144	skettis curved blade
25145	wisdom blade
25146	light etched longsword
25147	skystrider katana
25148	bone collector sword
25149	baron s broadsword
25150	honor hold saber
25151	assassins short blade
25152	howling sword
25153	gladiator greatblade
25154	blood groove blade
25155	iron skull sword
25156	royal crusader sword
25157	serpentlord claymore
25158	skeletal broadsword
25159	thunderstrike falchion
25160	vengeance blade
25161	dragon wing blade
25162	darkened broadsword
25163	elexorien blade
25164	crude umbrafen blade
25165	boulderfist claymore
25166	mok nathal warblade
25167	nethersteel claymore
25168	sha tari longsword
25169	fel orc brute sword
25170	rattan bo staff
25171	straight hardwood staff
25172	jinbali warp staff
25173	master s bo staff
25174	hanbo staff
25175	demoniac longstaff
25176	taiji quarterstaff
25177	tanjo staff
25178	bata staff
25179	nguni stick
25180	calenda fighting stick
25181	tapered staff
25182	crystal etched warstaff
25183	voodoo hex staff
25184	ravager claws
25185	thrasher blades
25186	vampiric handscythes
25187	shekketh talons
25188	spleenripper claws
25189	ironspine point
25190	wight s claws
25191	dread fangs
25192	gutrippers
25193	deathclaw talons
25194	serpent s fangs
25195	diamond tipped claws
25196	boneshredder claws
25197	razor scythes
25198	karaborian battle axe
25199	knight s war axe
25200	jagged broadaxe
25201	reaver s sickle
25202	kingly axe
25203	chipped woodchopper
25204	colossal war axe
25205	silvermoon crescent axe
25206	berserker axe
25207	shadowmoon cleaver
25208	bladespire broadaxe
25209	amani tomahawk
25210	double bladed axe
25211	rockbiter cutter
25212	lucky strike axe
25213	fel touched axe
25214	mok nathal battleaxe
25215	spiked battle axe
25216	ogre splitting axe
25217	sundering axe
25218	silver edged axe
25219	rending claw
25220	glorious war axe
25221	ghostly battle axe
25222	ceremonial slayer s axe
25223	windcaller hatchet
25224	slavemaster axe
25225	deepforge broadaxe
25226	war scythe
25227	sha tari longspear
25228	halberd polearm
25229	partisan polearm
25230	voulge blade
25231	fel wrought halberd
25232	war glaive
25233	battle scythe
25234	telaari polearm
25235	ethereal etched glaive
25236	grim scythe
25237	nether trident
25238	hellfire war spear
25239	legend s glaive
25240	azerothian longbow
25241	ashenvale longbow
25242	telaari longbow
25243	windtalker bow
25244	viper bow
25245	razorsong bow
25246	thalassian compound bow
25247	expert s bow
25248	talbuk hunting bow
25249	ranger s recurved bow
25250	rocslayer longbow
25251	orc flatbow
25252	dream catcher bow
25253	windspear longbow
25254	tower crossbow
25255	ram s head crossbow
25256	stronghold crossbow
25257	citadel crossbow
25258	repeater crossbow
25259	collapsible crossbow
25260	archer s crossbow
25261	mighty crossbow
25262	battle damaged crossbow
25263	assassins silent crossbow
25264	pocket ballista
25265	barreled crossbow
25266	well balanced crossbow
25267	rampant crossbow
25268	lead slug shotgun
25269	longbeard rifle
25270	gnomish assault rifle
25271	croc hunter s rifle
25272	pc 54 shotgun
25273	sawed off shotgun
25274	cliffjumper shotgun
25275	dragonbreath musket
25276	tauren runed musket
25277	sporting rifle
25278	nessingwary longrifle
25279	sen jin longrifle
25280	game hunter musket
25281	big boar battle rifle
25282	mahogany wand
25283	crystallized ebony wand
25284	purpleheart wand
25285	bloodwood wand
25286	yew wand
25287	magician s wand
25288	conjurer s wand
25289	majestic wand
25290	solitaire wand
25291	nobility torch
25292	mechano wand
25293	draenethyst wand
25294	dragonscale wand
25295	flawless wand
25296	absorption dagger
25297	tuning knife
25298	combustion dagger
25299	siphoning dagger
25300	lightning dagger
25301	shattering dagger
25302	soul drain dagger
25303	amplifying blade
25304	destructo blade
25305	elemental dagger
25306	permafrost dagger
25307	shadow dagger
25308	thunder spike
25309	warpdagger
25310	naaru lightmace
25311	revitalizing hammer
25312	glorious scepter
25313	cold iron scepter
25314	ceremonial hammer
25315	restorative mace
25316	spirit clad mace
25317	lesser sledgemace
25318	ancestral hammer
25319	tranquility mace
25320	queen s insignia
25321	divine hammer
25322	lordly scepter
25323	ascendant s scepter
25324	angerstaff
25325	brutal scar limb
25326	primal lore staff
25327	frenzied staff
25328	faerie kind staff
25329	tranquility staff
25330	starshine staff
25331	vengeance staff
25332	reflective staff
25333	purification staff
25334	intimidating greatstaff
25335	feral warp staff
25336	splintering greatstaff
25337	swarming sting staff
25338	loosely threaded pants
25339	loosely threaded shoulderpads
25340	loosely threaded vest
25341	dilapidated cloth belt
25342	dilapidated cloth boots
25343	dilapidated cloth bracers
25344	dilapidated cloth gloves
25345	dilapidated cloth hat
25346	dilapidated cloth pants
25347	dilapidated cloth shoulderpads
25348	dilapidated cloth vest
25349	moldy leather armor
25350	moldy leather belt
25351	moldy leather boots
25352	moldy leather bracers
25353	moldy leather gloves
25354	moldy leather helmet
25355	moldy leather pants
25356	moldy leather shoulderpads
25357	decaying leather armor
25358	decaying leather belt
25359	decaying leather boots
25360	decaying leather bracers
25361	decaying leather gloves
25362	decaying leather helmet
25363	decaying leather pants
25364	decaying leather shoulderpads
25365	eroded mail armor
25366	eroded mail belt
25367	eroded mail boots
25368	eroded mail bracers
25369	eroded mail circlet
25370	eroded mail gloves
25371	eroded mail pants
25372	eroded mail shoulderpads
25373	corroded mail armor
25374	corroded mail belt
25375	corroded mail boots
25376	corroded mail bracers
25377	corroded mail circlet
25378	corroded mail gloves
25379	corroded mail pants
25380	corroded mail shoulderpads
25381	tarnished plate belt
25382	tarnished plate boots
25383	tarnished plate bracers
25384	tarnished plate chestpiece
25385	tarnished plate gloves
25386	tarnished plate helmet
25387	tarnished plate pants
25388	tarnished plate shoulderpads
25389	deteriorating plate belt
25390	deteriorating plate boots
25391	deteriorating plate bracers
25392	deteriorating plate chestpiece
25393	deteriorating plate gloves
25394	deteriorating plate helmet
25395	deteriorating plate pants
25396	deteriorating plate shoulderpads
25397	eroded axe
25398	stone reaper
25399	deteriorating blade
25400	tarnished claymore
25401	corroded mace
25402	the stoppable force
25403	sharpened stilleto
25404	dense war staff
25405	rusted musket
25406	broken longbow
25407	the movable object
25408	shiny tail hair
25409	resilient tail hair
25410	damaged hoof
25411	worn hoof
25412	dirt covered fur
25413	smooth fur
25414	brittle horn
25415	aged horn
25416	oshu gun crystal fragment
25417	bloody fang
25418	razor sharp fang
25419	unmarked bag of gems
25420	severed claw
25421	gnarled claw
25422	bulging sack of gems
25423	bag of premium gems
25424	gem stuffed envelope
25425	molted feather
25426	brilliant feather
25427	beaten talon
25428	savage talon
25429	grime encrusted scale
25430	glimmering scale
25431	ripped fin
25432	pristine fin
25433	obsidian warbeads
25434	fractured carapace
25435	hardened carapace
25436	twitching leg
25437	barbed leg
25438	malachite pendant
25439	tigerseye band
25440	cracked boar tusk
25441	gnarled boar tusk
25442	mangled snout
25443	bloody snout
25444	corrosive ichor
25445	wretched ichor
25446	brittle skull
25447	broken skull
25448	blacksting s stinger
25449	bundle of skins
25450	creeping moss
25451	swamp moss
25452	blighted fungus
25453	death cap fungus
25454	luminescent globe
25455	phosphorescent globe
25456	glowing spores
25457	incandescent spores
25458	mag har battle standard
25459	count ungula s mandible
25460	bleeding hollow supply crate
25461	book of forgotten names
25462	tome of dusk
25463	pair of ivory tusks
25464	blood tempered ranseur
25465	stormcrow amulet
25466	broken antenna
25467	torn moth wing
25468	boulderfist plans
25469	grimoire of avoidance
25470	golden gryphon
25471	ebon gryphon
25472	snowy gryphon
25473	swift blue gryphon
25474	tawny windrider
25475	blue windrider
25476	green windrider
25477	swift red windrider
25478	defender s gauntlets
25479	boots of the earthcaller
25480	wastewalker s sash
25481	suntrider s gauntlets
25482	venn ren s boots
25483	fine sash
25484	telhamat pendant
25485	amaan s signet
25486	demonslayer s wristguards
25487	wind dancer s pendant
25488	signet of aeranas
25489	windtalker s cloak
25490	boulderfist key
25491	salvaged spore sacs
25492	earthcaller s mace
25493	qr 9447 2h axe
25494	totemic staff
25495	wolfrider s dagger
25496	mag har bow
25497	broken balanced stone dirk
25498	rough stone statue
25499	felblood band
25500	felforce medallion
25501	lost anchorite s cloak
25502	lightbearer s gauntlets
25503	flamehandler s gloves
25504	pilgrim s belt
25505	carinda s wedding band
25506	vindicator s chain helm
25507	leggings of telhamat
25508	omenai vest
25509	northwind cleft key
25510	ceremonial robes
25511	thunderforge leggings
25512	tribal hauberk
25513	clefthoof hide mask
25514	ikeyen s pauldrons
25515	mud encrusted boots
25516	ikeyen s boots
25517	preserver s medallion
25518	explorer s leggings
25519	warden s hammer
25521	greater rune of warding
25522	marshstrider s spaulders
25523	windcaller s gauntlets
25524	cenarion expedition boots
25525	zangar epaulets
25526	plans greater rune of warding
25527	swift red gryphon
25528	swift green gryphon
25529	swift purple gryphon
25530	helm of natural purity
25531	swift green windrider
25532	swift yellow windrider
25533	swift purple windrider
25534	marsh survivalist s belt
25535	netherwhelp s collar
25536	sporeggar smasher
25537	hewing axe of the marsh
25538	sporeling claw
25539	potion of water breathing
25540	dark cloak of the marsh
25541	cenarion ring of casting
25542	lucky circle of the fool
25543	talbuk sticker
25544	zerid s vintage musket
25545	talbuk dirk
25546	qr xxxx paladin chest
25547	qr xxxx druid shoulders
25548	tallstalk mushroom
25549	blood knight tabard
25550	redcap toadstool
25551	qr xxxx hunter legs
25552	warmaul ogre banner
25553	exodar staff
25554	kil sorrow armaments
25555	kil sorrow banner
25556	oversized ogre hauberk
25557	salvaged ango rosh pauldrons
25558	ango rosh souleater s cowl
25559	lo ap s tunic of muck diving
25560	lo ap s muck diving pads
25561	muck ridden galoshes
25562	earthen mark of razing
25563	earthen mark of power
25564	earthen mark of health
25565	spaulders of the ring
25566	judicator s gauntlets
25567	cord of the ring
25568	warcaster s scaled leggings
25569	murkblood avenger s chestplate
25570	melia s lustrous crown
25571	qr 9863 druid helm
25572	qr 9863 shaman legs
25573	qr 9863 warrior chest
25574	greenkeeper s pantaloons
25575	thunderbringer s guard
25576	smuggler s mitts
25577	greenblood pantaloons
25578	caustic feelers
25579	dark shaman s cover
25580	qr 9867 warrior legs
25581	qr 9867 hunter gloves
25582	qr 9867 druid moonkin belt
25583	eighty silver links
25584	murkblood oven mitts
25585	murkblood avenger s legplates
25586	burning blade peace offering
25589	clefthoof helm
25590	head of cho war
25591	clefthoof gloves
25592	clefthoof wristguards
25593	windroc greaves
25594	windroc boots
25595	windroc shroud
25596	peep s whistle
25597	vindicator s cinch
25598	fen strider s bracer
25599	explorer s bands
25600	bog walker s bands
25601	murk darkened bracers
25602	bog walker s belt
25603	lantresor s warblade
25604	warmaul prison key
25605	burning blade devotee s cinch
25606	burning blade cultist band
25607	burning blade cultist band
25608	lantresor s warblade
25609	burning blade devotee s cinch
25610	fen strider s footguards
25611	the witch doctor s wraps
25612	daggerfen mail
25613	feralfen mystic s handwraps
25614	feralfen beastmaster s hauberk
25615	feralfen champion s boots
25616	tim s trusty helmet
25617	captain krosh s crash helmet
25618	telaar courier s cloak
25619	glowing crystal insignia
25620	ancient crystal talisman
25621	serpent spirit s drape
25622	staff of the four golden coins
25623	bracers of the battle cleric
25624	king s bulwark
25625	qr 9922 feral druid staff
25626	qr 9922 paladin bracer
25627	qr 9922 shield
25628	ogre mauler s badge
25629	ogre handler s shooter
25630	ogre basher s slippers
25631	boots of the specialist
25632	wand of happiness
25633	uniting charm
25634	oshu gun relic
25635	eye of veil skith
25636	talbuk cape
25637	ethereal sash
25638	eye of veil reskk
25639	hemet s elekk gun
25640	nesingwary safari stick
25641	broken fitz s throwing axe
25642	eye of veil shienor
25643	harold s rejuvenating broach
25644	blessed book of nagrand
25645	totem of the plains
25647	telaar supply crate
25648	cho war s key
25649	knothide leather scraps
25650	knothide armor kit
25651	vindicator s armor kit
25652	magister s armor kit
25653	riding crop
25654	felscale gloves
25655	felscale boots
25656	felscale pants
25657	felscale breastplate
25658	damp woolen blanket
25659	scaled draenic boots
25660	scaled draenic vest
25661	scaled draenic gloves
25662	scaled draenic pants
25666	mug gok s head
25667	obsoleteidol of the beast
25668	thick draenic boots
25669	thick draenic gloves
25670	thick draenic pants
25671	thick draenic vest
25672	teromoth sample
25673	wild draenish boots
25674	wild draenish gloves
25675	wild draenish leggings
25676	wild draenish vest
25677	terokkar chokeberry
25678	warp hunter essence
25679	comfortable insoles
25680	stylin purple hat
25681	stylin adventure hat
25682	stylin jungle hat
25683	stylin crimson hat
25684	kokorek s talisman
25685	fel leather gloves
25686	fel leather boots
25687	fel leather leggings
25689	heavy clefthoof vest
25690	heavy clefthoof leggings
25691	heavy clefthoof boots
25692	netherfury leggings
25693	netherfury boots
25694	netherfury belt
25695	felstalker belt
25696	felstalker breastplate
25697	felstalker bracers
25699	crystal infused leather
25700	fel scales
25701	breastplate of retribution
25702	scaled legs of ruination
25703	zhevra leather
25705	luanga s orders
25706	luanga s orders
25707	fel hide
25708	thick clefthoof leather
25710	moonkin headdress
25711	deadly borer leggings
25712	perfectly balanced cape
25713	holy healing band
25714	crimson pendant of clarity
25715	jade warrior pauldrons
25716	handguards of precision
25717	sure step boots
25718	mantle of magical might
25719	arakkoa feather
25720	pattern heavy knothide leather
25721	pattern vindicator s armor kit
25722	pattern magister s armor kit
25723	bent antenna
25724	ripped moth wing
25725	pattern riding crop
25726	pattern comfortable insoles
25727	sealed box
25728	pattern stylin purple hat
25729	pattern stylin adventure hat
25730	pattern stylin jungle hat
25731	pattern stylin crimson hat
25732	pattern fel leather gloves
25733	pattern fel leather boots
25734	pattern fel leather leggings
25735	pattern heavy clefthoof vest
25736	pattern heavy clefthoof leggings
25737	pattern heavy clefthoof boots
25738	pattern felstalker belt
25739	pattern felstalker bracers
25740	pattern felstalker breastplate
25741	pattern netherfury belt
25742	pattern netherfury leggings
25743	pattern netherfury boots
25744	dampscale basilisk eye
25745	olemba seed
25746	box of parts
25751	the master planner s blueprints
25754	mana bomb code sheet 1
25755	mana bomb code sheet 2
25756	mana bomb code sheet 3
25757	mana bomb code sheet 4
25759	mogor s anointing club
25760	battle mage s baton
25761	staff of beasts
25762	honed voidaxe
25763	ceremonial warmaul blood blade
25764	mag hari fury brand
25765	fel orc plans
25766	creatures that owe sal salabim golds
25767	raliq s debt
25768	coosh coosh s debt
25769	floon s debt
25770	fel cannon activator
25771	fel cannon activator
25772	crystalline kopesh
25773	hungering bone cudgel
25774	azure lightblade
25775	ogre slayer s band
25776	ogre slayer s pendant
25777	ogre slayer s cover
25778	manacles of remembrance
25779	warmaul slayer s band
25780	warmaul defender s cloak
25781	segmented breastplate
25782	sunstrider legguards
25783	pilgrim s cover
25784	imbued chain
25785	adept s band
25786	hypnotist s watch
25787	charm of alacrity
25788	dauntless handguards
25789	rune engraved belt
25790	expedition scout s epaulets
25791	gloves of preservation
25792	curate s boots
25793	curate s footwraps
25794	bone studded girdle
25795	gloves of preservation
25796	lurking shadow spaulders
25797	crushing grasp
25802	dreadfang venom sac
25803	medallion of the valiant guardian
25804	naliko s revenge
25805	mantle of vivification
25806	nethekurse s rod of torment
25807	timber worg tail
25808	rod of dire shadows
25809	maimfist s choker
25810	vicar s cloak
25811	conquerer s band
25812	timber worg pelt
25813	small mushroom
25814	deathskitter s fang
25815	stonegazer s blood
25817	blessed vial
25819	breastplate of the warbringer
25820	metallic headband of simm onz
25821	leggings of unending assault
25822	watcher s tunic
25823	grunt s waraxe
25824	farseer s band
25825	footman s longsword
25826	sage s band
25827	muck covered drape
25828	petrified lichen guard
25829	talisman of the alliance
25830	gladiator s leather helm
25831	gladiator s leather tunic
25832	gladiator s leather spaulders
25833	gladiator s leather legguards
25834	gladiator s leather gloves
25835	explorer s walking stick
25836	preserver s cudgel
25837	ironjaw s pelt
25838	warden s hauberk
25840	extract of the afterlife
25841	draenei vessel
25842	restless bones
25843	fel iron rod
25844	adamantite rod
25845	eternium rod
25846	plans adamantite rod
25847	plans eternium rod
25848	formula runed adamantite rod
25849	formula runed eternium rod
25850	tuurem artifact
25852	tail feather of torgos
25853	pack of incendiary bombs
25854	gladiator s silk amice
25855	gladiator s silk cowl
25856	gladiator s silk raiment
25857	gladiator s silk handguards
25858	gladiator s silk trousers
25861	crude throwing axe
25862	marshberry
25863	olemba root
25864	telaari frond
25865	dragonspine
25866	greatmother s list of herbs
25867	earthstorm diamond
25868	skyfire diamond
25869	recipe transmute earthstorm diamond
25870	recipe transmute skyfire diamond
25871	standard thrown weapon
25872	balanced throwing dagger
25873	keen throwing knife
25874	large throwing knife
25875	deadly throwing axe
25876	gleaming throwing axe
25877	master s throwing dagger
25878	dusksteel throwing knife
25880	coarse stone statue
25881	heavy stone statue
25882	solid stone statue
25883	dense stone statue
25884	primal stone statue
25886	purple smoke flare
25887	schematic purple smoke flare
25888	design primal stone statue
25889	draenei holy water
25890	destructive skyfire diamond
25891	pristine shimmerscale eel
25893	mystical skyfire diamond
25894	swift skyfire diamond
25895	enigmatic skyfire diamond
25896	powerful earthstorm diamond
25897	bracing earthstorm diamond
25898	tenacious earthstorm diamond
25899	brutal earthstorm diamond
25900	grimoire of demonic frenzy
25901	insightful earthstorm diamond
25902	design powerful earthstorm diamond
25903	design bracing earthstorm diamond
25904	design insightful earthstorm diamond
25905	design tenacious earthstorm diamond
25906	design brutal earthstorm diamond
25907	design destructive skyfire diamond
25908	design swift skyfire diamond
25909	design mystical skyfire diamond
25910	design enigmatic skyfire diamond
25911	salvaged wood
25912	salvaged metal
25913	ring of the slain anchorite
25914	broken choker
25915	fallen vindicator s blade
25916	terokkar axe
25917	healer s staff of the forest
25918	blood guided knife
25919	sedai s necklace
25920	sedai s blade
25921	sedai s ring
25922	fearless girdle
25923	fierce mantle
25924	swamprunner s boots
25925	terrorcloth mantle
25926	nexus stalker s band
25927	consortium cloak of the quick
25928	ethereal healing pendant
25929	cenarion thicket legplates
25930	cenarion thicket helm
25931	cenarion thicket circlet
25932	cenarion thicket jerkin
25933	extra sharp blade
25934	spiked destroyer
25935	invincible stave
25936	terokkar tablet of vim
25937	terokkar tablet of precision
25938	mysteries of the light
25939	voidfire wand
25940	idol of the claw
25941	boots of the outlander
25942	faith bearer s gauntlets
25943	creepjacker
25944	shaarde the greater
25945	cloak of revival
25946	nethershade boots
25947	lightning rod pauldrons
25948	girdle of the penitent
25949	gloves of the afterlife
25950	staff of polarities
25951	fleet refugee s boots
25952	scimitar of the nexus stalkers
25953	ethereal warp bow
25954	sigil of shaffar
25955	mask of the howling storm
25956	nexus bracers of vigor
25957	ethereal boots of the skystrider
25958	eagle engraved bracers
25959	feathered armbands
25960	talonstalker bracers
25961	feathered wrist cuffs
25962	longstrider s loop
25963	kokorek s signet
25964	shaarde the lesser
25965	cloak of grasping talons
25966	arakkoa sage s shawl
25967	eagle crested pauldrons
25968	shalassi sentry s epaulets
25969	rapscallion s touch
25970	shalassi oracle s sandals
25971	stout oak longbow
25972	deadeye s piece
25973	dark augur s wand
25974	helm of lupine cunning
25975	wolf hunter s guise
25976	helm of lupine grace
25977	helm of lupine ferocity
25978	seth s graphite fishing pole
25979	flintlocke s piloting pants
25980	aerodynamic scaled vest
25981	dirigible crash helmet
25982	foreman s sash
25983	heavy miner s belt
25984	miner s brace
25985	cenarion naturalist s staff
25986	dreadtusk s fury
25987	helboar carving blade
25988	glowing alabaster ring
25989	draenethyst chaplet
25990	smooth soapstone band
25991	seamless stone band
25992	enforcer s chain
25993	finely wrought chain
25994	rune of force
25995	star of sha naar
25996	emblem of perseverance
25997	gladiator s linked armor
25998	gladiator s linked helm
25999	gladiator s linked spaulders
26000	gladiator s linked gauntlets
26001	gladiator s linked leggings
26002	flaming torch
26004	farmhand s vest
26005	jessera s fungus lined tunic
26006	crystal flecked pants
26007	vindicator s woolies
26008	scholar s gloves
26009	flutterer silk handwraps
26010	vindicator s soft sole slippers
26011	cryo core attendant s boots
26012	kessel s cinch wrap
26013	cincture of woven reeds
26014	jessera s fungus lined cuffs
26015	anchorite neophyte s cuffs
26016	surveyor s mantle
26017	venomous silk cover
26018	elekk handler s leathers
26019	jessera s fungus lined vest
26020	shard covered leggings
26021	vindicator s leather chaps
26022	researcher s gloves
26023	ravager hide gloves
26024	vindicator s leather moccasins
26025	technician s boots
26026	ornately tooled belt
26027	kessel s sweat stained elekk leash
26028	jessera s fungus lined bands
26029	watchman s bracers
26030	jessera s fungus lined hauberk
26031	elekk rider s mail
26032	crystal studded legguards
26033	vindicator s iron legguards
26034	protective field gloves
26035	corin s handguards
26036	vindicator s stompers
26037	lightweight mesh boots
26038	segmented girdle
26039	kessel s sturdy riding handle
26040	jessera s fungus lined bracers
26041	vigilant vambraces
26042	oshu gun crystal powder sample
26043	oshu gun crystal powder sample
26044	halaa research token
26045	halaa battle token
26048	letter to kialon
26050	fist of argus
26051	2 stone sledgehammer
26052	vindicator s smasher
26053	elekk handler s blade
26054	blade of argus
26055	oculus of the hidden eye
27317	elemental sapta
27357	potion of greater vision
27388	mr pinchy
27389	surplus bastard sword
27390	vindicator s letter opener
27398	carved crystalline orb
27399	stillpine defender
27400	peacekeeper s buckler
27401	arugoo s crossbow of destruction
27402	huntsman s crossbow
27403	stillpine stinger
27404	lightspark
27408	hope bearer helm
27409	raven heart headdress
27410	collar of command
27411	slippers of serenity
27412	ironstaff of regeneration
27413	ring of the exarchs
27414	mok nathal beast mask
27415	darkguard face mask
27416	fetish of the fallen
27417	ravenwing pauldrons
27418	stormreaver shadow kilt
27419	forge camp spite plans
27420	uther s ceremonial warboots
27421	forge camp rage plans
27422	barbed gill trout
27423	cloak of impulsiveness
27424	amani venom axe
27425	spotted feltail
27426	northshire battlemace
27427	durotan s battle harness
27428	stormfront gauntlets
27429	zangarian sporefish
27430	scaled greaves of patience
27431	time shifted dagger
27432	broxigar s ring of valor
27433	pauldrons of sufferance
27434	mantle of perenolde
27435	figluster s mudfish
27436	iron band of the unbreakable
27437	icefin bluefish
27438	golden darter
27439	furious crawdad
27440	diamond prism of recurrence
27441	felblood snapper
27442	goldenscale vendorfish
27443	steam pump debris
27444	foulfin
27445	magical crawdad box
27446	mr pinchy s gift
27447	bracers of just rewards
27448	cloak of the everliving
27449	blood knight defender
27450	wild stalker boots
27451	boots of the darkwalker
27452	light scribe bands
27453	averinn s ring of slaying
27454	volcanic pauldrons
27455	irondrake faceguard
27456	raiments of nature s breath
27457	life bearer s gauntlets
27458	oceansong kilt
27459	vambraces of daring
27460	reavers ring
27461	chestguard of the prowler
27462	crimson bracers of gloom
27463	terror flame dagger
27464	omor s unyielding will
27465	mana etched gloves
27466	headdress of alacrity
27467	silent strider kneeboots
27468	moonglade handwraps
27469	gladiator s mail armor
27470	gladiator s mail gauntlets
27471	gladiator s mail helm
27472	gladiator s mail leggings
27473	gladiator s mail spaulders
27474	beast lord handguards
27475	gauntlets of the bold
27476	truncheon of five hells
27477	faol s signet of cleansing
27478	girdle of the blasted reaches
27479	flaming torch
27480	soul device
27481	heavy supply crate
27483	moon touched bands
27484	libram of avengement
27485	embroidered cape of mysteries
27487	bloodlord legplates
27488	mage collar of the firestorm
27489	virtue bearer s vambraces
27490	firebrand battleaxe
27491	signet of repose
27492	moonchild leggings
27493	gloves of the deadwatcher
27494	emerald eye bracer
27495	soldier s dog tags
27497	doomplate gauntlets
27498	scroll of agility v
27499	scroll of intellect v
27500	scroll of protection v
27501	scroll of spirit v
27502	scroll of stamina v
27503	scroll of strength v
27505	ruby helm of the just
27506	robe of effervescent light
27507	adamantine repeater
27508	incanter s gloves
27509	handgrips of assassination
27510	tidefury gauntlets
27511	inscribed scrollcase
27512	the willbreaker
27513	curious crate
27514	leggings of the unrepentant
27515	huge spotted feltail
27516	enormous barbed gill trout
27517	bands of nethekurse
27518	ivory idol of the moongoddess
27519	cloak of malice
27520	greathelm of the unbreakable
27521	telaari hunting girdle
27522	world s end bracers
27523	exarch s diamond band
27524	firemaul of destruction
27525	jeweled boots of sanctification
27526	skyfire hawk bow
27527	greaves of the shatterer
27528	gauntlets of desolation
27529	figurine of the colossus
27531	wastewalker gloves
27532	master fishing the art of angling
27533	demonblood eviscerator
27534	hortus seal of brilliance
27535	gauntlets of the righteous
27536	hallowed handwraps
27537	gloves of oblivion
27538	lightsworn hammer
27539	justice bearer s pauldrons
27540	nexus torch
27541	archery belt of the broken
27542	cord of belief
27543	starlight dagger
27544	totem of spontaneous regrowth
27545	mennu s scaled leggings
27546	traitor s noose
27547	coldwhisper cord
27548	girdle of many blessings
27549	wavefury boots
27550	ironscale war cloak
27551	skeletal necklace of battlerage
27552	soft leather vest
27553	crimson steer energy drink
27631	needle shrike
27632	terokk s quill
27633	terokk s mask
27634	the saga of terokk
27635	lynx steak
27636	bat bites
27637	shadowstalker s sash
27638	hierophant s sash
27639	slayer s waistguard
27640	hand of argus crossfire
27641	vindicator s walking stick
27643	stormbreaker s girdle
27644	avenger s waistguard
27645	dreamstalker sash
27646	marksman s belt
27647	marksman s legguards
27648	dreamstalker leggings
27649	hierophant s leggings
27650	shadowstalker s leggings
27651	buzzard bites
27652	stormbreaker s leggings
27653	slayer s leggings
27654	avenger s legplates
27655	ravager dog
27656	sporeling snack
27657	blackened basilisk
27658	roasted clefthoof
27659	warp burger
27660	talbuk steak
27661	blackened trout
27662	feltail delight
27663	blackened sporefish
27664	grilled mudfish
27665	poached bluefish
27666	golden fish sticks
27667	spicy crawdad
27668	lynx meat
27669	bat flesh
27671	buzzard meat
27672	girdle of the immovable
27673	phosphorescent blade
27674	ravager flesh
27676	strange spores
27677	chunk o basilisk
27678	clefthoof meat
27679	sublime mystic dawnstone
27680	halaani bag
27681	warped flesh
27682	talbuk venison
27683	quagmirran s eye
27684	recipe buzzard bites
27685	recipe lynx steak
27686	recipe roasted moongraze tenderloin
27687	recipe bat bites
27688	recipe ravager dog
27689	recipe sporeling snack
27690	recipe blackened basilisk
27691	recipe roasted clefthoof
27692	recipe warp burger
27693	recipe talbuk steak
27694	recipe blackened trout
27695	recipe feltail delight
27696	recipe blackened sporefish
27697	recipe grilled mudfish
27698	recipe poached bluefish
27699	recipe golden fish sticks
27700	recipe spicy crawdad
27702	gladiator s lamellar chestpiece
27703	gladiator s lamellar gauntlets
27704	gladiator s lamellar helm
27705	gladiator s lamellar legguards
27706	gladiator s lamellar shoulders
27707	gladiator s satin gloves
27708	gladiator s satin hood
27709	gladiator s satin leggings
27710	gladiator s satin mantle
27711	gladiator s satin robe
27712	shackles of quagmirran
27713	pauldrons of desolation
27714	swamplight lantern
27715	circle s stalwart helmet
27716	refuge armor
27717	expedition forager leggings
27718	aldor defender s legplates
27719	aldor leggings of puissance
27720	robes of the aldor
27721	expedition footgear
27722	gloves of marshmanship
27723	belt of the moonkin
27724	wild shoulderpads
27725	expedition mantle
27726	hearty cenarion cincture
27727	swift cenarion footwear
27728	cushy cenarion walkers
27729	humanoid skull
27730	watcher s cloak of vigilance
27731	vindicator s cloak
27732	infiltrator s cloak
27733	warden s ring of precision
27734	expedition caster s band
27735	pendant of the marsh
27736	master cookbook
27737	moonglade shoulders
27738	incanter s pauldrons
27739	spaulders of the righteous
27740	band of ursol
27741	bleeding hollow warhammer
27742	mage fury girdle
27743	girdle of living flame
27744	idol of ursoc
27745	hungarhide gauntlets
27746	arcanium signet bands
27747	boggspine knuckles
27748	cassock of the loyal
27749	staff of the wild
27750	hammer of the sporelings
27751	survivalist s pike
27752	zangarmarsh claymore
27753	ensorcelled marshfang blade
27754	keen marshfang slicer
27755	girdle of gallantry
27756	marshfang blade axe
27757	greatstaff of the leviathan
27758	hydra fang necklace
27759	headdress of the tides
27760	dunewind sash
27761	ring of the shadow deeps
27762	weathered band of the swamplord
27763	crown of the forest lord
27764	hands of the sun
27765	armwraps of disdain
27766	swampstone necklace
27767	bogreaver
27768	oracle belt of timeless mystery
27769	endbringer
27770	argussian compass
27771	doomplate shoulderguards
27772	stormshield of renewal
27773	barbaric legstraps
27775	hallowed pauldrons
27776	shoulderpads of assassination
27777	stark blood garnet
27778	spaulders of oblivion
27779	bone chain necklace
27780	ring of fabled hope
27781	demonfang ritual helm
27783	moonrage girdle
27784	scintillating coral band
27785	notched deep peridot
27786	barbed deep peridot
27787	chestguard of no remorse
27788	bloodsworn warboots
27789	cloak of whispering shells
27790	mask of penance
27791	serpentcrest life staff
27792	steam hinge chain of valor
27793	earth mantle handwraps
27794	recoilless rocket ripper x 54
27795	sash of serpentra
27796	mana etched spaulders
27797	wastewalker shoulderpads
27798	gauntlets of vindication
27799	vermillion robes of the dominant
27800	earthsoul britches
27801	beast lord mantle
27802	tidefury shoulderguards
27803	shoulderguards of the bold
27804	devilshark cape
27805	ring of the silver hand
27806	fathomheart gauntlets
27807	air elemental gas
27808	jump a tron 4000 key
27809	barbed deep peridot
27812	stark blood garnet
27813	boots of the colossus
27814	twinblade of mastery
27815	totem of the astral winds
27816	mindrage pauldrons
27817	starbolt longbow
27818	starry robes of the crescent
27820	notched deep peridot
27821	extravagant boots of malice
27822	crystal band of valor
27823	shard encrusted breastplate
27824	robe of the great dark beyond
27825	predatory gloves
27826	mantle of the sea wolf
27827	lucid dream bracers
27828	warp scarab brooch
27829	axe of the nexus kings
27830	circlet of the victor
27831	mantle of the unforgiven
27832	band of the victor
27833	band of the victor
27834	circlet of the victor
27835	stillwater girdle
27837	wastewalker leggings
27838	incanter s trousers
27839	legplates of the righteous
27840	scepter of sha tar
27841	severed talon of the matriarch
27842	grand scepter of the nexus kings
27843	glyph lined sash
27844	pauldrons of swift retribution
27845	magma plume boots
27846	claw of the watcher
27847	fanblade pauldrons
27848	embroidered spellpyre boots
27854	smoked talbuk venison
27855	mag har grainbread
27856	skethyl berries
27857	garadar sharp
27858	sunspring carp
27859	zangar caps
27860	purified draenic water
27861	lathrai s stolen goods
27863	extended cost bryanite
27864	brian s bryanite of extended cost copying
27865	bracers of shirrak
27866	scintillating headdress of second sight
27867	boots of the unjust
27868	runesong dagger
27869	soulpriest s ring of resolve
27870	doomplate legguards
27871	maladaar s blessed chaplet
27872	the harvester of souls
27873	moonglade pants
27874	beast lord leggings
27875	hallowed trousers
27876	will of the fallen exarch
27877	draenic wildstaff
27878	auchenai death shroud
27879	gladiator s scaled chestpiece
27880	gladiator s scaled gauntlets
27881	gladiator s scaled helm
27882	gladiator s scaled legguards
27883	gladiator s scaled shoulders
27884	ornate boots of the sanctified
27885	soul wand of the aldor
27886	idol of the emerald queen
27887	platinum shield of the valorous
27888	dream wing helm
27889	jaedenfire gloves of annihilation
27890	wand of the netherwing
27891	adamantine figurine
27892	cloak of the inciter
27893	ornate leggings of the venerated
27894	tangled mane
27895	band of many prisms
27896	alembic of infernal power
27897	breastplate of many graces
27898	wrathfire hand cannon
27899	mana wrath
27900	jewel of charismatic mystique
27901	blackout truncheon
27902	silent slippers of meditation
27903	sonic spear
27904	resounding ring of glory
27905	greatsword of horrid dreams
27906	crimsonforge breastplate
27907	mana etched pantaloons
27908	leggings of assassination
27909	tidefury kilt
27910	silvermoon crest shield
27911	epoch s whispering cinch
27912	harness of the deep currents
27913	whispering blade of slaying
27914	moonstrider boots
27915	sky hunter swift boots
27916	sethekk feather darts
27917	libram of the eternal rest
27918	bands of syth
27919	light woven slippers
27920	mark of conquest
27921	mark of conquest
27922	mark of defiance
27924	mark of defiance
27925	ravenclaw band
27926	mark of vindication
27927	mark of vindication
27928	terminal edge
27929	terminal edge
27930	splintermark
27931	splintermark
27932	razor claw
27933	serrated tooth
27934	vorpal claw
27935	needle fang
27936	greaves of desolation
27937	sky breaker
27938	savage mask of the lynx lord
27939	incendic rod
27940	marvelous madstone of immortality
27941	compassionate critter s friend
27942	incendic rod
27943	chieftain mummaki s totem
27944	talisman of true treasure tracking
27945	shark s tooth of bona fide fluidic mobility
27946	avian cloak of feathers
27947	totem of impact
27948	trousers of oblivion
27949	libram of zeal
27976	polished pendant of edible energy
27977	legplates of the bold
27978	soap on a rope
27979	stone of stupendous springing strides
27980	terokk s nightmace
27981	sethekk oracle cloak
27982	charm of potent and powerful passions
27983	libram of zeal
27984	totem of impact
27985	deathforge girdle
27986	crow wing reaper
27987	melmorta s twilight longbow
27988	burnoose of shifting ages
27989	idol of savagery
27990	idol of savagery
27991	shadow labyrinth key
27992	infallible tikbalang ward
27993	mask of inner fire
27994	mantle of three terrors
27995	sun gilded shouldercaps
27996	ring of spiritual precision
28024	orion s report
28025	video mount
28026	crazy cenarion cloak
28027	lunatic s choker
28028	moonstruck bands
28029	goldenvine wraps
28030	spell slinger s protector
28031	nomad s woven cloak
28032	delicate green poncho
28033	epoch mender
28034	hourglass of the unraveller
28038	seaforium pu 36 explosive nether modulator
28039	crude explosives
28040	vengeance of the illidari
28041	bladefist s breadth
28042	regal protectorate
28043	demon stalker pendant
28044	band of the demon stalker
28045	cloak of the demon stalker
28046	legion missive
28047	nekrogg s key
28048	crude explosives
28050	sacred feather vest
28051	jerkin of the untamed spirit
28052	goldweave tunic
28053	wicked arrow
28054	fleshripper s bladed chestplate
28055	gilded crimson chestplate
28056	blackflight arrow
28057	bonechewer berserker s vest
28058	shredded wyrm wing
28059	iridescent eye
28060	impact shot
28061	ironbite shell
28062	expedition repeater
28063	survivalist s wand
28064	idol of the wild
28065	libram of wracking
28066	totem of lightning
28068	grimoire of suffering rank 6
28069	golden cenarion greaves
28070	verdant handwraps
28071	grimoire of anguish rank 1
28072	grimoire of anguish rank 2
28073	grimoire of anguish rank 3
28074	studded green anklewraps
28075	destroyers mantle
28099	drillmaster zurok s orders
28100	volatile healing potion
28101	unstable mana potion
28102	onslaught elixir
28103	adept s elixir
28104	elixir of mastery
28105	duron s report
28106	kingston s primers
28107	legion missive
28108	power infused mushroom
28109	essence infused mushroom
28110	fat gnome and little elf
28111	everlasting underspore frond
28112	underspore pod
28113	warboss nekrogg s orders
28114	warboss nekrogg s orders
28116	zeppelin debris
28118	runed ornate ruby
28119	smooth ornate dawnstone
28120	gleaming ornate dawnstone
28121	icon of unyielding courage
28123	potent ornate topaz
28124	liar s cord
28126	gladiator s dragonhide gloves
28127	gladiator s dragonhide helm
28128	gladiator s dragonhide legguards
28129	gladiator s dragonhide spaulders
28130	gladiator s dragonhide tunic
28131	reaver buster launcher
28132	area 52 special
28134	brooch of heightened potential
28135	bomb crate
28136	gladiator s wyrmhide gloves
28137	gladiator s wyrmhide helm
28138	gladiator s wyrmhide legguards
28139	gladiator s wyrmhide spaulders
28140	gladiator s wyrmhide tunic
28141	ranger s sash
28142	farstrider s belt
28143	rusted chain girdle
28144	troll handler gloves
28145	tranquillien wraps
28146	courier s wraps
28147	tranquillien scout s bracers
28148	bronze mail bracers
28149	tranquillien breeches
28150	renzithen s dusty cloak
28151	arcanist s wand
28152	quel thalas recurve
28153	farstrider s shield
28154	red silk trousers
28155	apothecary s waistband
28156	rotting handwraps
28157	black leather jerkin
28158	batskin belt
28159	undertaker s gloves
28160	an telas scale shirt
28161	tranquillien scale leggings
28162	tranquillien defender s girdle
28163	maltendis s handguards
28164	tranquillien flamberge
28166	shield of the void
28167	sha tari wrought armguards
28168	insignia of the mag hari hero
28169	mag hari ritualist s horns
28170	auchenai bracers
28171	spymistress s wristguards
28172	mag hari scout s tunic
28173	mag hari huntsman s leggings
28174	shattrath wraps
28175	mag hari warlord s legplates
28176	sha tari wrought greaves
28177	auchenai boots
28178	spymistress s boots
28179	shattrath jumpers
28180	myrmidon s headdress
28181	earthwarden s coif
28182	helm of the claw
28183	hydromancer s headwrap
28184	millennium blade
28185	khadgar s kilt of abjuration
28186	laughing skull battle harness
28187	star heart lamp
28188	bloodfire greatstaff
28189	latro s shifting sword
28190	scarab of the infinite cycle
28191	mana etched vestments
28192	helm of desolation
28193	mana etched crown
28194	primal surge bracers
28202	moonglade robe
28203	breastplate of the righteous
28204	tunic of assassination
28205	breastplate of the bold
28206	cowl of the guiltless
28207	pauldrons of the crimson flight
28210	bloodskull destroyer
28211	lieutenant s signet of lordaeron
28212	aran s sorcerous slacks
28213	lordaeron medical guide
28214	grips of the lunar eclipse
28215	mok nathal mask of battle
28216	dathrohan s ceremonial hammer
28217	tarren mill vitality locket
28218	pontiff s pantaloons of prophecy
28219	emerald scale greaves
28220	moon crown antlers
28221	boots of the watchful heart
28222	reaver of the infinites
28223	arcanist s stone
28224	wastewalker helm
28225	doomplate warhelm
28226	timeslicer
28227	sparking arcanite ring
28228	beast lord cuirass
28229	incanter s robe
28230	hallowed garments
28231	tidefury chestpiece
28232	robe of oblivion
28233	necklace of resplendent hope
28234	medallion of the alliance
28235	medallion of the alliance
28236	medallion of the alliance
28237	medallion of the alliance
28238	medallion of the alliance
28239	medallion of the horde
28240	medallion of the horde
28241	medallion of the horde
28242	medallion of the horde
28243	medallion of the horde
28244	pendant of triumph
28245	pendant of dominance
28246	band of triumph
28247	band of dominance
28248	totem of the void
28249	capacitus cloak of calibration
28250	vestia s pauldrons of inner grace
28251	boots of the glade keeper
28252	bloodfyre robes of annihilation
28253	plasma rat s hyper scythe
28254	warp engineer s prismatic chain
28255	lunar claw pauldrons
28256	thoriumweave cloak
28257	hammer of the penitent
28258	nethershrike
28259	cosmic lifeband
28260	manual of the nethermancer
28261	video invis
28262	jade skull breastplate
28263	stellaris
28264	wastewalker tunic
28265	dath remar s ring of defense
28266	molten earth kilt
28267	edge of the cosmos
28268	natural mender s wraps
28269	baba s cloak of arcanistry
28270	formula enchant chest major resilience
28271	formula enchant gloves spell strike
28272	formula enchant gloves major spellpower
28273	formula enchant gloves major healing
28274	formula enchant cloak spell penetration
28275	beast lord helm
28276	formula enchant cloak greater arcane resistance
28277	formula enchant cloak greater shadow resistance
28278	incanter s cowl
28279	formula enchant boots cat s swiftness
28280	formula enchant boots boar s speed
28281	formula enchant weapon major healing
28282	formula enchant shield major stamina
28283	soul mirror
28284	don carlos tequila
28285	helm of the righteous
28286	telescopic sharprifle
28287	vial of sedative serum
28288	abacus of violent odds
28289	dargonhawk whistle
28290	smooth golden draenite
28291	design smooth golden draenite
28292	archmage vargoth s staff
28293	high warlord s claymore
28294	gladiator s heavy crossbow
28295	gladiator s slicer
28296	libram of the lightbringer
28297	gladiator s spellblade
28298	gladiator s decapitator
28299	gladiator s bonegrinder
28300	gladiator s painsaw
28301	syrannis mystic sheen
28302	gladiator s bonecracker
28303	invoker s signet
28304	prismatic mittens of mending
28305	gladiator s pummeler
28306	towering mantle of the hunt
28307	gladiator s quickblade
28308	gladiator s cleaver
28309	gladiator s hacker
28310	gladiator s shiv
28311	revenger
28312	gladiator s shanker
28313	gladiator s right ripper
28314	gladiator s left ripper
28315	stormreaver warblades
28316	aegis of the sunbird
28317	energis armwraps
28318	obsidian clodstompers
28319	gladiator s war edge
28320	gladiator s touch of defeat
28321	enchanted thorium torque
28322	runed dagger of solace
28323	ring of umbral doom
28324	gauntlets of cruel intention
28325	dreamer s dragonstaff
28327	arcane netherband
28328	mithril bark cloak
28331	gladiator s chain helm
28332	gladiator s chain leggings
28333	gladiator s chain spaulders
28334	gladiator s chain armor
28335	gladiator s chain gauntlets
28336	belmara s tome
28337	breastplate of righteous fury
28338	devil stitched leggings
28339	boots of the shifting sands
28340	mantle of autumn
28341	warpstaff of arcanum
28342	warp infused drape
28343	jagged bark pendant
28344	wyrmfury pauldrons
28345	warp splinter s thorn
28346	gladiator s endgame
28347	warpscale leggings
28348	moonglade cowl
28349	tidefury helm
28350	warhelm of the bold
28351	dathric s blade
28352	luminrath s mantle
28353	cohlien s cap
28355	gladiator s idol of tenacity
28356	gladiator s libram of justice
28357	gladiator s totem of the third wind
28358	gladiator s shield wall
28359	netherologist s notes
28360	mighty blood garnet
28361	mighty blood garnet
28362	bold ornate ruby
28363	inscribed ornate topaz
28364	etherlithium matrix crystal
28367	greatsword of forlorn visions
28368	sigil of krasus
28369	battery recharging blaster
28370	bangle of endless blessings
28371	netherfury cape
28372	idol of feral shadows
28373	cloak of scintillating auras
28374	mana sphere shoulderguards
28375	rubium war girdle
28376	b naar personnel roster
28377	sergeant s heavy cloak
28378	sergeant s heavy cape
28379	sergeant s heavy cape
28380	sergeant s heavy cloak
28381	general s plate bracers
28383	general s plate greaves
28384	outland striders
28385	general s plate belt
28386	nether core s control rod
28387	lamp of peaceful repose
28390	thatia s self correcting gauntlets
28391	worldfire chestguard
28392	reflex blades
28393	warmaul of infused light
28394	ryngo s band of ingenuity
28395	shattered halls key
28396	gloves of the unbound
28397	emberhawk crossbow
28398	the sleeper s cord
28399	filtered draenic water
28400	warp storm warblade
28401	hauberk of desolation
28402	general s dreadweave stalkers
28403	doomplate chestguard
28404	general s dreadweave belt
28405	general s dreadweave cuffs
28406	sigil laced boots
28407	elementium band of the sentry
28408	broken silver star
28409	general s silk belt
28410	general s silk footguards
28411	general s silk cuffs
28412	lamp of peaceful radiance
28413	hallowed crown
28414	helm of assassination
28415	hood of oblivion
28416	hungering spineripper
28417	nether ray stinger
28418	shiffar s nexus horn
28419	choker of fluid thought
28420	fel weightstone
28421	adamantite weightstone
28422	general s leather boots
28423	general s leather belt
28424	general s leather bracers
28425	fireguard
28426	blazeguard
28427	blazefury
28428	lionheart blade
28429	lionheart champion
28430	lionheart executioner
28431	the planar edge
28432	black planar edge
28433	wicked edge of the planes
28434	lunar crescent
28435	mooncleaver
28436	bloodmoon
28437	drakefist hammer
28438	dragonmaw
28439	dragonstrike
28440	thunder
28441	deep thunder
28442	stormherald
28443	general s dragonhide belt
28444	general s dragonhide boots
28445	general s dragonhide bracers
28446	general s wyrmhide belt
28447	general s wyrmhide boots
28448	general s wyrmhide bracers
28449	general s chain sabatons
28450	general s chain girdle
28451	general s chain bracers
28452	bloodgem shard
28453	bracers of the white stag
28454	stalker s war bands
28455	archmage vargoth s staff
28457	ethereal technology
28458	bold tourmaline
28459	delicate tourmaline
28460	teardrop tourmaline
28461	runed tourmaline
28462	bright tourmaline
28463	solid zircon
28464	sparkling zircon
28465	lustrous zircon
28466	brilliant amber
28467	smooth amber
28468	rigid amber
28469	gleaming amber
28470	thick amber
28471	krasus compendium
28472	krasus s compendium chapter 1
28473	krasus s compendium chapter 2
28474	krasus s compendium chapter 3
28475	heliotrope oculus
28476	gladiator s maul
28477	harbinger bands
28478	to arch s primers
28479	stone of glacius
28481	brown elekk
28482	great elite elekk
28483	breastplate of kings
28484	bulwark of kings
28485	bulwark of the ancient kings
28486	moser s magnificent muffin
28490	shaffar s wrappings
28491	windwalker s footwraps
28492	talonite s boots
28493	dreadhawk s schynbald
28494	ravenguard s greaves
28495	windwalker s sash
28496	talonite s belt
28497	dreadhawk s girdle
28498	ravenguard s baldric
28499	arakkoa hunter s supplies
28500	fossil oil
28501	ravager egg omelet
28502	vambraces of courage
28503	whirlwind bracers
28504	steelhawk crossbow
28505	gauntlets of renewed hope
28506	gloves of dexterous manipulation
28507	handwraps of flowing thought
28508	gloves of saintly blessings
28509	worgen claw necklace
28510	spectral band of innervation
28511	bands of indwelling
28512	bracers of justice
28513	demonic rune stone
28514	bracers of maliciousness
28515	bands of nefarious deeds
28516	barbed choker of discipline
28517	boots of foretelling
28518	iron gauntlets of the maiden
28519	gloves of quickening
28520	gloves of centering
28521	mitts of the treemender
28522	shard of the virtuous
28523	totem of healing rains
28524	emerald ripper
28525	signet of unshakable faith
28526	etherlithium matrix crystals
28527	mana wraith essence
28528	moroes lucky pocket watch
28529	royal cloak of arathi kings
28530	brooch of unquenchable fury
28531	barbed shrike
28532	silver throwing knifes
28533	wooden boomerang
28534	fel tipped dart
28535	amani throwing axe
28536	jagged guillotine
28537	wildhammer throwing axe
28538	forked shuriken
28539	razor edged boomerang
28540	arakkoa talon axe
28541	sawshrike
28542	heartseeker knives
28543	dreghood throwing axe
28544	assassin s shuriken
28545	edgewalker longboots
28547	elemental power extractor
28548	elemental power
28549	armory history
28550	flaming torch
28551	fel reaver part
28552	a mysterious tome
28553	band of the exorcist
28554	shredder spare parts
28555	seal of the exorcist
28556	swift windfire diamond
28557	swift starfire diamond
28558	spirit shard
28559	exorcist s plate helm
28560	exorcist s lamellar helm
28561	exorcist s leather helm
28562	unyielding battle horn
28563	doomclaw s hand
28564	energy isolation cube
28565	nethershard girdle
28566	crimson girdle of the indomitable
28567	belt of gale force
28568	idol of the avian heart
28569	boots of valiance
28570	shadow cloak of dalaran
28571	blank scroll
28572	blade of the unrequited
28573	despair
28574	exorcist s dragonhide helm
28575	exorcist s wyrmhide helm
28576	exorcist s chain helm
28577	exorcist s linked helm
28578	masquerade gown
28579	romulo s poison vial
28580	b naar console transcription
28581	wolfslayer sniper rifle
28582	red riding hood s cloak
28583	big bad wolf s head
28584	big bad wolf s paw
28585	ruby slippers
28586	wicked witch s hat
28587	legacy
28588	blue diamond witchwand
28589	beastmaw pauldrons
28590	ribbon of sacrifice
28591	earthsoul leggings
28592	libram of souls redeemed
28593	eternium greathelm
28594	trial fire trousers
28595	bright blood garnet
28596	design bright blood garnet
28597	panzar thar breastplate
28598	fel reaver construction manual
28599	scaled breastplate of carnage
28600	stonebough jerkin
28601	chestguard of the conniver
28602	robe of the elder scribes
28603	talisman of nightbane
28604	nightstaff of the everliving
28605	general s linked bracers
28606	shield of impenetrable darkness
28607	sunfury disguise
28608	ironstriders of urgency
28609	emberspur talisman
28610	ferocious swift kickers
28611	dragonheart flameshield
28612	pauldrons of the solace giver
28613	grand marshal s chain armor
28614	grand marshal s chain gauntlets
28615	grand marshal s chain helm
28616	grand marshal s chain leggings
28617	grand marshal s chain spaulders
28618	grand marshal s dragonhide gloves
28619	grand marshal s dragonhide helm
28620	grand marshal s dragonhide legguards
28621	wrynn dynasty greaves
28622	grand marshal s dragonhide spaulders
28623	grand marshal s dragonhide tunic
28624	grand marshal s dreadweave gloves
28625	grand marshal s dreadweave hood
28626	grand marshal s dreadweave leggings
28627	grand marshal s dreadweave mantle
28628	grand marshal s dreadweave robe
28629	general s linked girdle
28630	general s linked sabatons
28631	dragon quake shoulderguards
28632	plans adamantite weightstone
28633	staff of infinite mysteries
28634	scrap reaver x6000 controller
28635	sunfury arcanist robes
28636	sunfury researcher gloves
28637	sunfury guardsman medallion
28638	general s mail bracers
28639	general s mail girdle
28640	general s mail sabatons
28641	general s lamellar belt
28642	general s lamellar greaves
28643	general s lamellar bracers
28644	general s scaled belt
28645	general s scaled greaves
28646	general s scaled bracers
28647	forest wind shoulderpads
28649	garona s signet ring
28651	unyielding battle horn
28652	cincture of will
28653	shadowvine cloak of infusion
28654	malefic girdle
28655	cord of nature s sustenance
28656	girdle of the prowler
28657	fool s bane
28658	terestian s stranglestaff
28659	xavian stiletto
28660	gilded thorium cloak
28661	mender s heart ring
28662	breastplate of the lightbinder
28663	boots of the incorrupt
28664	nitrin s instructions
28665	mountain gronn eyeball
28666	pauldrons of the justice seeker
28667	flawless greater windroc beak
28668	aged clefthoof blubber
28669	rapscallion boots
28670	boots of the infernal coven
28671	steelspine faceguard
28672	drape of the dark reavers
28673	tirisfal wand of ascendancy
28674	saberclaw talisman
28675	shermanar great ring
28676	heart of urtrak
28677	the book of the dead
28679	grand marshal s lamellar chestpiece
28680	grand marshal s lamellar gauntlets
28681	grand marshal s lamellar helm
28683	grand marshal s lamellar shoulders
28684	grand marshal s leather gloves
28685	grand marshal s leather helm
28686	grand marshal s leather legguards
28687	grand marshal s leather spaulders
28688	grand marshal s leather tunic
28689	grand marshal s linked armor
28690	grand marshal s linked gauntlets
28691	grand marshal s linked helm
28692	grand marshal s linked leggings
28693	grand marshal s linked spaulders
28694	grand marshal s mail armor
28695	grand marshal s mail gauntlets
28696	grand marshal s mail helm
28697	grand marshal s mail leggings
28698	grand marshal s mail spaulders
28699	grand marshal s plate chestpiece
28700	grand marshal s plate gauntlets
28701	grand marshal s plate helm
28702	grand marshal s plate legguards
28703	grand marshal s plate shoulders
28704	grand marshal s satin gloves
28705	grand marshal s satin hood
28706	grand marshal s satin leggings
28707	grand marshal s satin mantle
28708	grand marshal s satin robe
28709	grand marshal s scaled chestpiece
28710	grand marshal s scaled gauntlets
28711	grand marshal s scaled helm
28712	grand marshal s scaled legguards
28713	grand marshal s scaled shoulders
28714	grand marshal s silk amice
28715	grand marshal s silk cowl
28716	grand marshal s silk handguards
28717	grand marshal s silk raiment
28718	grand marshal s silk trousers
28719	grand marshal s wyrmhide gloves
28720	grand marshal s wyrmhide helm
28721	grand marshal s wyrmhide legguards
28722	grand marshal s wyrmhide spaulders
28723	grand marshal s wyrmhide tunic
28724	grand marshal s lamellar legguards
28725	rune activation device
28726	mantle of the mind flayer
28727	pendant of the violet eye
28728	aran s soothing sapphire
28729	spiteblade
28730	mithril band of the unscarred
28731	shining chain of the afterworld
28732	cowl of defiance
28733	girdle of truth
28734	jewel of infinite possibilities
28735	earthblood chestguard
28740	rip flayer leggings
28741	skulker s greaves
28742	pantaloons of repentance
28743	mantle of abrahmis
28744	uni mind headdress
28745	mithril chain of heroism
28746	fiend slayer boots
28747	battlescar boots
28748	legplates of the innocent
28749	king s defender
28750	girdle of treachery
28751	heart flame leggings
28752	forestlord striders
28753	ring of recurrence
28754	triptych shield of the ancients
28755	bladed shoulderpads of the merciless
28756	headdress of the high potentate
28757	ring of a thousand marks
28758	exorcist s mail helm
28759	exorcist s dreadweave hood
28760	exorcist s silk hood
28761	exorcist s scaled helm
28762	adornment of stolen souls
28763	jade ring of the everliving
28764	farstrider wildercloak
28765	stainless cloak of the pure hearted
28766	ruby drape of the mysticant
28767	the decapitator
28768	malchazeen
28769	the keystone
28770	nathrezim mindblade
28771	light s justice
28772	sunfury bow of the phoenix
28773	gorehowl
28774	glaive of the pit
28775	thundering greathelm
28776	liar s tongue gloves
28777	cloak of the pit stalker
28778	terror pit girdle
28779	girdle of the endless pit
28780	soul eater s handwraps
28781	karaborian talisman
28782	crystalheart pulse staff
28783	eredar wand of obliteration
28784	unyielding banner scrap
28785	the lightning capacitor
28786	apex s crystal focus
28787	annihilator servo
28788	tabard of the protector
28789	eye of magtheridon
28790	naaru lightwarden s band
28791	ring of the recalcitrant
28792	a dal s signet of defense
28793	band of crimson fury
28794	axe of the gronn lords
28795	bladespire warbands
28796	malefic mask of the shadows
28797	brute cloak of the ogre magi
28798	badge of the protector
28799	belt of divine inspiration
28800	hammer of the naaru
28801	maulgar s warhelm
28802	bloodmaw magus blade
28803	cowl of nature s breath
28804	collar of cho gall
28805	high warlord s chain armor
28806	high warlord s chain gauntlets
28807	high warlord s chain helm
28808	high warlord s chain leggings
28809	high warlord s chain spaulders
28810	windshear boots
28811	high warlord s dragonhide gloves
28812	high warlord s dragonhide helm
28813	high warlord s dragonhide legguards
28814	high warlord s dragonhide spaulders
28815	high warlord s dragonhide tunic
28817	high warlord s dreadweave gloves
28818	high warlord s dreadweave hood
28819	high warlord s dreadweave leggings
28820	high warlord s dreadweave mantle
28821	high warlord s dreadweave robe
28822	teeth of gruul
28823	eye of gruul
28824	gauntlets of martial perfection
28825	aldori legacy defender
28826	shuriken of negation
28827	gauntlets of the dragonslayer
28828	gronn stitched girdle
28829	arklon crystal artifact
28830	dragonspine trophy
28831	high warlord s lamellar chestpiece
28832	high warlord s lamellar gauntlets
28833	high warlord s lamellar helm
28834	high warlord s lamellar legguards
28835	high warlord s lamellar shoulders
28836	high warlord s leather gloves
28837	high warlord s leather helm
28838	high warlord s leather legguards
28839	high warlord s leather spaulders
28840	high warlord s leather tunic
28841	high warlord s linked armor
28842	high warlord s linked gauntlets
28843	high warlord s linked helm
28844	high warlord s linked leggings
28845	high warlord s linked spaulders
28846	high warlord s mail armor
28847	high warlord s mail gauntlets
28848	high warlord s mail helm
28849	high warlord s mail leggings
28850	high warlord s mail spaulders
28851	high warlord s plate chestpiece
28852	high warlord s plate gauntlets
28853	high warlord s plate helm
28854	high warlord s plate legguards
28855	high warlord s plate shoulders
28856	high warlord s satin gloves
28857	high warlord s satin hood
28858	high warlord s satin leggings
28859	high warlord s satin mantle
28860	high warlord s satin robe
28861	high warlord s scaled chestpiece
28862	high warlord s scaled gauntlets
28863	high warlord s scaled helm
28864	high warlord s scaled legguards
28865	high warlord s scaled shoulders
28866	high warlord s silk amice
28867	high warlord s silk cowl
28868	high warlord s silk handguards
28869	high warlord s silk raiment
28870	high warlord s silk trousers
28871	high warlord s wyrmhide gloves
28872	high warlord s wyrmhide helm
28873	high warlord s wyrmhide legguards
28874	high warlord s wyrmhide spaulders
28875	high warlord s wyrmhide tunic
28878	inscription of faith
28881	inscription of discipline
28882	inscription of warding
28885	inscription of vengeance
28886	greater inscription of discipline
28887	greater inscription of faith
28888	greater inscription of vengeance
28889	greater inscription of warding
28903	inscription of the orb
28904	inscription of the oracle
28907	inscription of the blade
28908	inscription of the knight
28909	greater inscription of the orb
28910	greater inscription of the blade
28911	greater inscription of the knight
28912	greater inscription of the oracle
28913	box of surveying equipment
28915	reins of the dark riding talbuk
28917	high warlord s bonegrinder
28918	high warlord s decapitator
28919	high warlord s maul
28920	high warlord s cleaver
28921	high warlord s hacker
28922	high warlord s left ripper
28923	high warlord s painsaw
28924	high warlord s bonecracker
28925	high warlord s pummeler
28926	high warlord s quickblade
28927	red hawkstrider
28928	high warlord s right ripper
28929	high warlord s shanker
28930	high warlord s shiv
28931	high warlord s spellblade
28933	high warlord s heavy crossbow
28934	surveying equipment
28935	high warlord s war staff
28936	swift pink hawkstrider
28937	high warlord s slicer
28938	high warlord s battletome
28939	high warlord s barricade
28940	grand marshal s barricade
28941	grand marshal s battletome
28942	grand marshal s bonegrinder
28943	grand marshal s warblade
28944	grand marshal s cleaver
28945	grand marshal s decapitator
28946	grand marshal s hacker
28947	grand marshal s left ripper
28948	grand marshal s maul
28949	grand marshal s painsaw
28950	grand marshal s bonecracker
28951	grand marshal s pummeler
28952	grand marshal s quickblade
28953	grand marshal s right ripper
28954	grand marshal s shanker
28955	grand marshal s shiv
28956	grand marshal s slicer
28957	grand marshal s spellblade
28959	grand marshal s war staff
28960	grand marshal s heavy crossbow
28962	triangulation device
28963	voidheart crown
28964	voidheart robe
28966	voidheart leggings
28967	voidheart mantle
28968	voidheart gloves
28969	teleporter power pack
28970	nether dragon essence
28971	nether dragonkin egg
28972	flightblade throwing axe
28973	marshal s chain bracers
28974	marshal s chain girdle
28975	marshal s chain sabatons
28976	marshal s dragonhide belt
28977	marshal s dragonhide boots
28978	marshal s dragonhide bracers
28979	light throwing knife
28980	marshal s dreadweave belt
28981	marshal s dreadweave cuffs
28982	marshal s dreadweave stalkers
28983	marshal s lamellar belt
28984	marshal s lamellar bracers
28985	marshal s lamellar greaves
28986	marshal s leather belt
28987	marshal s leather boots
28988	marshal s leather bracers
28989	marshal s linked bracers
28990	marshal s linked girdle
28991	marshal s linked sabatons
28992	marshal s mail bracers
28993	marshal s mail girdle
28994	marshal s mail sabatons
28995	marshal s plate belt
28996	marshal s plate bracers
28997	marshal s plate greaves
28998	marshal s scaled belt
28999	marshal s scaled bracers
29000	marshal s scaled greaves
29001	marshal s silk belt
29002	marshal s silk cuffs
29003	marshal s silk footguards
29004	marshal s wyrmhide belt
29005	marshal s wyrmhide boots
29006	marshal s wyrmhide bracers
29007	weighted throwing axe
29008	sharp throwing axe
29009	heavy throwing dagger
29010	wicked throwing dagger
29011	warbringer greathelm
29012	warbringer chestguard
29013	jagged throwing axe
29014	blacksteel throwing dagger
29015	warbringer legguards
29016	warbringer shoulderguards
29017	warbringer handguards
29018	triangulation device
29019	warbringer breastplate
29020	warbringer gauntlets
29021	warbringer battle helm
29022	warbringer greaves
29023	warbringer shoulderplates
29024	eye of the storm mark of honor
29026	ata mal crystal
29027	unstable warp rift generator
29028	cyclone headdress
29029	cyclone hauberk
29030	cyclone kilt
29031	cyclone shoulderpads
29032	cyclone gloves
29033	cyclone chestguard
29034	cyclone handguards
29035	cyclone faceguard
29036	cyclone legguards
29037	cyclone shoulderguards
29038	cyclone breastplate
29039	cyclone gauntlets
29040	cyclone helm
29041	draenethyst crystal of command
29042	cyclone war kilt
29043	cyclone shoulderplates
29044	netherblade facemask
29045	netherblade chestpiece
29046	netherblade breeches
29047	netherblade shoulderpads
29048	netherblade gloves
29049	light collar of the incarnate
29050	robes of the incarnate
29051	warp nether
29052	warp nether extractor
29053	trousers of the incarnate
29054	light mantle of the incarnate
29055	handwraps of the incarnate
29056	shroud of the incarnate
29057	gloves of the incarnate
29058	soul collar of the incarnate
29059	leggings of the incarnate
29060	soul mantle of the incarnate
29061	justicar diadem
29062	justicar chestpiece
29063	justicar leggings
29064	justicar pauldrons
29065	justicar gloves
29066	justicar chestguard
29067	justicar handguards
29068	justicar faceguard
29069	justicar legguards
29070	justicar shoulderguards
29071	justicar breastplate
29072	justicar gauntlets
29073	justicar crown
29074	justicar greaves
29075	justicar shoulderplates
29076	collar of the aldor
29077	vestments of the aldor
29078	legwraps of the aldor
29079	pauldrons of the aldor
29080	gloves of the aldor
29081	demon stalker greathelm
29082	demon stalker harness
29083	demon stalker greaves
29084	demon stalker shoulderguards
29085	demon stalker gauntlets
29086	crown of malorne
29087	chestguard of malorne
29088	legguards of malorne
29089	shoulderguards of malorne
29090	handguards of malorne
29091	chestpiece of malorne
29092	gloves of malorne
29093	antlers of malorne
29094	britches of malorne
29095	pauldrons of malorne
29096	breastplate of malorne
29097	gauntlets of malorne
29098	stag helm of malorne
29099	greaves of malorne
29100	mantle of malorne
29101	challenge of the blue flight
29102	reins of the cobalt war talbuk
29103	reins of the white war talbuk
29104	reins of the silver war talbuk
29105	reins of the tan war talbuk
29106	ata mal crystal
29108	blade of the unyielding
29109	rod of the unyielding
29110	ruined scented candle
29111	box of stale candy
29112	cenarion spirits
29113	demonic essence
29115	consortium blaster
29116	nomad s leggings
29117	stormspire vest
29118	smuggler s ammo pouch
29119	haramad s bargain
29120	pattern truefaith vestments
29121	guile of khoraazi
29122	nether runner s cowl
29123	medallion of the lightbearer
29124	vindicator s brand
29125	retainer s blade
29126	seer s signet
29127	vindicator s hauberk
29128	lightwarden s band
29129	anchorite s robes
29130	auchenai staff
29131	retainer s leggings
29132	scryer s bloodgem
29133	seer s cane
29134	gauntlets of the chosen
29135	earthcaller s headdress
29136	far seer s helm
29137	hellscream s will
29138	arechron s gift
29139	ceremonial cover
29140	cloak of the ancient spirits
29141	tempest leggings
29142	kurenai kilt
29143	clefthoof hide quiver
29144	worg hide quiver
29145	band of ancestral spirits
29146	band of elemental spirits
29147	talbuk hide spaulders
29148	blackened leather spaulders
29149	sporeling s firestick
29150	hardened stone shard
29151	veteran s musket
29152	marksman s bow
29153	blade of the archmage
29154	legion cannon
29155	stormcaller
29156	honor s call
29157	golden ring of power
29158	truesilver commander s ring
29159	glowing thorium band
29160	emerald lion ring
29161	void ridge soul shard
29162	galaxis soul shard
29163	raw farahlite
29164	farahlite core
29165	warbringer
29166	hellforged halberd
29167	blackened spear
29168	ancestral band
29169	ring of convalescence
29170	windcaller s orb
29171	earthwarden
29172	ashyen s gift
29173	strength of the untamed
29174	watcher s cowl
29175	gavel of pure light
29176	crest of the sha tar
29177	a dal s command
29179	xi ri s gift
29180	blessed scale girdle
29181	timelapse shard
29182	riftmaker
29183	bindings of the timewalker
29184	timewarden s leggings
29185	continuum blade
29186	glyph of the defender
29187	inscription of endurance
29189	glyph of renewal
29190	glyph of renewal
29191	glyph of power
29192	glyph of ferocity
29193	glyph of the gladiator
29194	glyph of nature warding
29195	glyph of arcane warding
29196	glyph of fire warding
29197	glyph of fire warding
29198	glyph of frost warding
29199	glyph of shadow warding
29200	falfindel s blaster
29201	thick bronze darts
29202	whirling steel axes
29203	enchanted thorium blades
29204	felsteel whisper knives
29205	inquisitor s crest top half
29206	inquisitor s crest bottom half
29207	conjuring powder
29209	zaxxis insignia
29210	assassin s throwing axe
29211	fitz s throwing axe
29212	balanced stone dirk
29213	pattern felstalker belt
29214	pattern felstalker bracers
29215	pattern felstalker breastplate
29216	flawless crystal shard
29217	pattern netherfury belt
29218	pattern netherfury boots
29219	pattern netherfury leggings
29220	blue hawkstrider
29221	black hawkstrider
29222	purple hawkstrider
29223	swift green hawkstrider
29224	swift purple hawkstrider
29226	warp rift generator
29227	reins of the cobalt war talbuk
29228	reins of the dark war talbuk
29229	reins of the silver war talbuk
29230	reins of the tan war talbuk
29231	reins of the white war talbuk
29232	recipe transmute skyfire diamond
29233	dathric s blade
29234	belmara s tome
29235	luminrath s mantle
29236	cohlien s cap
29237	warpath bracers
29238	lion s heart girdle
29239	eaglecrest warboots
29240	bands of negation
29241	belt of depravity
29242	boots of blasphemy
29243	wave fury vambraces
29244	wave song girdle
29245	wave crest striders
29246	nightfall wristguards
29247	girdle of the deathdealer
29248	shadowstep striders
29249	bands of the benevolent
29250	cord of sanctification
29251	boots of the pious
29252	bracers of dignity
29253	girdle of valorous deeds
29254	boots of the righteous path
29255	bands of rarefied magic
29257	sash of arcane visions
29258	boots of ethereal manipulation
29259	bracers of the hunt
29260	heart of the fel reaver
29261	girdle of ferocity
29262	boots of the endless hunt
29263	forestheart bracers
29264	tree mender s belt
29265	barkchip boots
29266	azure shield of coldarra
29267	light bearer s faith shield
29268	mazthoril honor shield
29269	sapphiron s wing bone
29270	flametongue seal
29271	talisman of kalecgos
29272	orb of the soul eater
29273	khadgar s knapsack
29274	tears of heaven
29275	searing sunblade
29276	violet signet
29277	violet signet
29278	violet signet
29279	violet signet of the great protector
29280	violet signet
29281	violet signet
29282	violet signet
29283	violet signet of the master assassin
29284	violet signet
29285	violet signet
29286	violet signet
29287	violet signet of the archmage
29288	violet signet
29289	violet signet
29290	violet signet of the grand restorer
29291	violet signet
29292	helboar bacon
29293	bonestripper buzzard hotwings
29294	band of eternity
29295	band of eternity
29296	band of eternity
29297	band of the eternal defender
29298	band of eternity
29299	band of eternity
29300	band of eternity
29301	band of the eternal champion
29302	band of eternity
29303	band of eternity
29304	band of eternity
29305	band of the eternal sage
29306	band of eternity
29307	band of eternity
29308	band of eternity
29309	band of the eternal restorer
29311	fel reaver construction manual
29312	cover of righteous fury
29313	earthbreaker s greaves
29314	leggings of the third coin
29315	gloves of penitence
29316	warchief s mantle
29317	tempest s touch
29318	southshore sneakers
29319	tarren mill defender s cinch
29320	band of the guardian
29321	time bending gem
29322	keeper s ring of piety
29323	andormu s tear
29324	warp attuned orb
29325	flesh beast s metal greaves
29326	consortium mantle of phasing
29327	cryo mitts
29328	consortium prince s wrap
29329	terokk s quill
29330	the saga of terokk
29331	annals of kirin var
29332	terokk s mask
29333	torc of the sethekk prophet
29334	sethekk oracle s focus
29335	talon lord s collar
29336	mark of the ravenguard
29337	the exarch s protector
29338	loathsome remnant
29339	auchenai tracker s hauberk
29340	auchenai monk s tunic
29341	auchenai anchorite s robe
29342	consortium plated legguards
29343	haramad s leggings of the third coin
29344	haramad s linked chain pantaloons
29345	haramad s leg wraps
29346	feltooth eviscerator
29347	talisman of the breaker
29348	the bladefist
29349	adamantine chain of the unbroken
29350	the black stalk
29351	wrathtide longbow
29352	cobalt band of tyrigosa
29353	shockwave truncheon
29354	light touched stole of altruism
29355	terokk s shadowstaff
29356	quantum blade
29357	master thief s gloves
29359	feral staff of lashing
29360	vileblade of the betrayer
29361	naberius s phylactery
29362	the sun eater
29363	mana wyrmling
29364	brown rabbit crate
29365	smithing hammer
29366	b naar access crystal
29367	ring of cryptic dreams
29368	manasurge pendant
29369	shawl of shifting probabilities
29370	icon of the silver crescent
29371	nexus claw
29372	void talon
29373	band of halos
29374	necklace of eternal hope
29375	bishop s cloak
29376	essence of the martyr
29377	ethereum phase spear
29378	starheart baton
29379	ring of arathi warlords
29380	ethereum phase blade
29381	choker of vile intent
29382	blood knight war cloak
29383	bloodlust brooch
29384	ring of unyielding force
29385	farstrider defender s cloak
29386	necklace of the juggernaut
29387	gnomeregan auto blocker 600
29388	libram of repentance
29389	totem of the pulsing earth
29390	everbloom idol
29391	pulse dagger
29393	diamond berries
29394	lyribread
29395	ethermead
29396	coruu access crystal
29397	duro access crystal
29398	circle of banishing
29399	rod of the void caller
29400	abyssal shroud
29401	sparkling southshore cider
29411	ara access crystal
29412	jessen s special slop
29425	mark of kil jaeden
29426	firewing signet
29427	mark of the betrayer
29428	bessy s bell
29429	boom s doom
29434	badge of justice
29443	bloodmaul brutebane brew
29445	surveying markers
29447	fel zapper
29448	mag har mild cheese
29449	bladespire bagel
29450	telaari grapes
29451	clefthoof ribs
29452	zangar trout
29453	sporeggar mushroom
29454	silverwine
29456	gift of the ethereal
29457	nethershard
29458	aegis of the vindicator
29459	ethereum relay data
29460	ethereum prison key
29461	mana bomb fragment
29463	amber bands of the aggressor
29464	shaleskin shale
29465	black battlestrider
29466	black war kodo
29467	black war ram
29468	black war steed bridle
29469	horn of the black war wolf
29470	red skeletal warhorse
29471	reins of the black war tiger
29472	whistle of the black war raptor
29473	protectorate igniter
29474	ivory bell
29475	pacifying dust
29476	crimson crystal shard
29477	crimson crystal shard
29478	seed of revitalization
29480	parched hydra sample
29481	withered bog lord sample
29482	ethereum essence
29483	shadow armor kit
29485	flame armor kit
29486	frost armor kit
29487	nature armor kit
29488	arcane armor kit
29489	enchanted felscale leggings
29490	enchanted felscale gloves
29491	enchanted felscale boots
29492	flamescale leggings
29493	flamescale boots
29494	flamescale belt
29495	enchanted clefthoof leggings
29496	enchanted clefthoof gloves
29497	enchanted clefthoof boots
29498	blastguard pants
29499	blastguard boots
29500	blastguard belt
29501	sha naar key
29502	cobrascale hood
29503	cobrascale gloves
29504	windscale hood
29505	hood of primal life
29506	gloves of the living touch
29507	windslayer wraps
29508	living dragonscale helm
29509	windstrike gloves
29510	netherdrake helm
29511	netherdrake gloves
29512	earthen netherscale boots
29513	staff of the dreghood elders
29514	thick netherscale breastplate
29515	ebon netherscale breastplate
29516	ebon netherscale belt
29517	ebon netherscale bracers
29518	amani scimitar
29519	netherstrike breastplate
29520	netherstrike belt
29521	netherstrike bracers
29522	windhawk hauberk
29523	windhawk bracers
29524	windhawk belt
29525	primalstrike vest
29526	primalstrike belt
29527	primalstrike bracers
29528	drums of war
29529	drums of battle
29530	drums of speed
29531	drums of restoration
29532	drums of panic
29533	cobrahide leg armor
29534	clefthide leg armor
29535	nethercobra leg armor
29536	nethercleft leg armor
29539	cobra scales
29540	reinforced mining bag
29545	sunfury military briefing
29546	sunfury arcane briefing
29547	wind scales
29548	nether dragonscales
29549	codex prayer of fortitude iii
29550	tome of conjure water ix
29551	severed tail
29552	broken rock flayer talon
29553	basilisk liver
29554	encrusted basilisk skin
29555	glimmering basilisk skin
29556	basilisk venom sac
29557	rainbow feather
29558	charged scale
29559	vibrant feather
29560	electrified scale
29561	dragon femur
29562	dragon s tooth
29563	dragon s claw
29564	dragon s fang
29565	raptor liver
29566	raptor blood feather
29567	raptor talon
29568	raptor war feather
29569	strong junkbox
29570	a gnome effigy
29571	a steamy romance novel
29572	aboriginal carvings
29573	embalming fluid
29574	mummified parts
29575	a jack o lantern
29576	shark bait
29577	troll keepsake
29578	crystalized stone
29579	crystalized stone chips
29580	crystal fragments
29581	strange crystal
29582	ethereum data cell
29583	sinister scimitar
29584	throat piercers
29585	legion whip
29586	head of forgefiend razorsaw
29588	burning legion missive
29589	burning legion missive
29590	burning legion missive
29591	prepared ethereum wrapping
29592	insignia of the horde
29593	insignia of the alliance
29594	knight lieutenant s mail greaves
29595	knight lieutenant s mail vices
29596	knight captain s mail hauberk
29597	knight captain s mail legguards
29598	lieutenant commander s mail headguard
29599	lieutenant commander s mail pauldrons
29600	blood guard s lamellar gauntlets
29601	blood guard s lamellar sabatons
29602	legionnaire s lamellar breastplate
29603	legionnaire s lamellar leggings
29604	champion s lamellar headguard
29605	champion s lamellar shoulders
29606	marshal s mail boots
29607	marshal s mail gauntlets
29608	marshal s mail leggings
29609	field marshal s mail armor
29610	field marshal s mail helm
29611	field marshal s mail spaulders
29612	general s lamellar boots
29613	general s lamellar gloves
29614	general s lamellar legplates
29615	warlord s lamellar chestplate
29616	warlord s lamellar faceguard
29617	warlord s lamellar pauldrons
29618	protectorate disruptor
29624	first half of socrethar s stone
29625	second half of socrethar s stone
29664	pattern reinforced mining bag
29669	pattern shadow armor kit
29672	pattern flame armor kit
29673	pattern frost armor kit
29674	pattern nature armor kit
29675	pattern arcane armor kit
29677	pattern enchanted felscale leggings
29682	pattern enchanted felscale gloves
29684	pattern enchanted felscale boots
29689	pattern flamescale leggings
29691	pattern flamescale boots
29693	pattern flamescale belt
29698	pattern enchanted clefthoof leggings
29699	socrethar s teleportation stone
29700	pattern enchanted clefthoof gloves
29701	pattern enchanted clefthoof boots
29702	pattern blastguard pants
29703	pattern blastguard boots
29704	pattern blastguard belt
29713	pattern drums of panic
29714	pattern drums of restoration
29717	pattern drums of battle
29718	pattern drums of speed
29719	pattern cobrahide leg armor
29720	pattern clefthide leg armor
29721	pattern nethercleft leg armor
29722	pattern nethercobra leg armor
29723	pattern cobrascale hood
29724	pattern cobrascale gloves
29725	pattern windscale hood
29726	pattern hood of primal life
29727	pattern gloves of the living touch
29728	pattern windslayer wraps
29729	pattern living dragonscale helm
29730	pattern earthen netherscale boots
29731	pattern windstrike gloves
29732	pattern netherdrake helm
29733	pattern netherdrake gloves
29734	pattern thick netherscale breastplate
29735	holy dust
29736	arcane rune
29737	navuud s concoction
29738	vial of void horror ooze
29739	arcane tome
29740	fel armament
29741	diagnostic results
29742	the warden s key
29743	purple elekk
29744	gray elekk
29745	great blue elekk
29746	great green elekk
29747	great purple elekk
29749	farahlon lasher cutting
29750	ethereum stasis chamber key
29751	talbuk horn sample
29753	chestguard of the fallen defender
29754	chestguard of the fallen champion
29755	chestguard of the fallen hero
29756	gloves of the fallen hero
29757	gloves of the fallen champion
29758	gloves of the fallen defender
29759	helm of the fallen hero
29760	helm of the fallen champion
29761	helm of the fallen defender
29762	pauldrons of the fallen hero
29763	pauldrons of the fallen champion
29764	pauldrons of the fallen defender
29765	leggings of the fallen hero
29766	leggings of the fallen champion
29767	leggings of the fallen defender
29768	hulking hydra heart
29769	diagnostic results
29770	experimental repair apparatus
29771	kirin var journeyman s belt
29772	kirin var scout s belt
29773	battle mage s helmet
29774	kirin var defender s chausses
29775	pendant of the battle mage
29776	core of ar kelos
29777	cloak of the valiant defender
29778	phase disruptor
29779	rejuvenating scepter
29780	kirin tor apprentice s robes
29781	lifewarden s breastplate
29782	coif of the wicked
29783	legguards of the resolute defender
29784	harmony s touch
29785	crimson mail bracers
29786	kirin var defender s greaves
29787	master smith s hammer
29788	finely wrought scale leggings
29789	andrethan s masterwork
29790	demolition charges
29791	reinforced heaume
29792	dawnstrike s cloak
29793	signet of the violet tower
29794	strength of the violet tower
29795	burning legion gate key
29796	socrethar s teleportation stone
29797	orders from kael thas
29798	dome generator segment
29799	lifeless tendril
29800	evil eye
29801	ripfang lynx pelt
29802	barbscale crocolisk skin
29803	diagnostic device
29804	wrangler s boots
29805	socrethar s head
29806	cowpoke s riding gloves
29807	engraved cattleman s buckle
29808	shimmering azure boots
29810	dragon crested epaulets
29811	goldenlink bracers
29812	blued steel gauntlets
29813	cloak of woven energy
29814	celestial jewel ring
29815	chain of glowing tendrils
29817	talbuk tagger
29818	energy field modulator
29822	fragment of dimensius
29837	qaenchant weapon +81 healing
29838	qaenchant weapon battlemaster
29839	qaenchant weapon mongoose
29840	qaenchant weapon soulfrost
29841	qaenchant weapon sunfire
29842	qaenchant weapon +40 spell damage
29843	qaenchant weapon +30 intellect
29844	qaenchant weapon +7 damage
29845	qaenchant weapon +20 strength
29846	qaenchant 2h weapon +35 agility
29847	qaenchant 2h weapon +70 attack power
29848	qaenchant shield +5 resistances
29849	qaenchant shield +18 stamina
29850	qaenchant shield +12 intellect
29851	qaenchant shield +15 block value
29852	qaenchant boots +9 stamina & +8% speed
29853	qaenchant boots +6 agility & +8% speed
29854	qaenchant boots +5 snare resist & +10 hit rating
29856	qaenchant boots +12 agility
29857	qaenchant boots +12 stamina
29858	qaenchant cloak +15 shadow resistance
29859	qaenchant cloak +15 arcane resistance
29860	qaenchant cloak +12 agility
29861	qaenchant cloak +20 spell penetration
29862	qaenchant gloves +35 healing
29863	qaenchant gloves +20 spell damage
29864	qaenchant gloves +15 spell hit rating
29866	qaenchant gloves +10 spell crit rating
29867	qaenchant gloves +15 strength
29868	qaenchant gloves +26 attack power
29869	qaenchant chest +15 resilience
29870	qaenchant chest +6 mana5
29871	qaenchant chest +15 spirit
29872	qaenchant chest +6 stats
29873	qaenchant chest +150 mana
29874	qaenchant chest +150 health
29877	indalamar s super hot
29886	hunter 105 epic ammo box
29887	hunter 150 epic ammo box
29901	blue moth egg
29902	red moth egg
29903	yellow moth egg
29904	white moth egg
29905	kael s vial remnant
29906	vashj s vial remnant
29908	rage reaver
29909	screaming dagger
29910	the staff of twin worlds
29911	agamaggan s quill
29912	the final code
29913	foe reaver
29914	hellfire skiver
29915	desolation rod
29916	ironstar repeater
29917	landslide buckler
29918	mindstorm wristbands
29919	adamantine kite shield
29920	phoenix ring of rebirth
29921	fire crest breastplate
29922	band of al ar
29923	talisman of the sun king
29924	netherbane
29925	phoenix wing cloak
29926	whispering tunic
29927	shadowbrim travel hat
29928	wanderer s stitched trousers
29929	raging spirit harness
29930	nature stitched kilt
29931	phantasmal headdress
29932	arcane ringed tunic
29933	arcane ringed greaves
29934	helm of affinity
29935	fire scarred breastplate
29936	skyfire greaves
29937	helm of infinite visions
29938	battle seeker chestguard
29939	flayer hide leggings
29940	veteran s skullcap
29941	scale brand breastplate
29942	battle scarred leggings
29943	legionnaire s studded helm
29944	protectorate breastplate
29945	magistrate s greaves
29946	invader s greathelm
29947	gloves of the searing grip
29948	claw of the phoenix
29949	arcanite steam pistol
29950	greaves of the bloodwarder
29951	star strider boots
29952	rina s bough
29953	golden dragonhawk hatchling
29954	spiritbinder s mantle
29955	mana infused wristguards
29956	red dragonhawk hatchling
29957	silver dragonhawk hatchling
29958	blue dragonhawk hatchling
29959	spiritualist s gauntlets
29960	captured firefly
29961	enraged earthen soul
29962	heartrazor
29963	enraged fiery soul
29964	blackstorm leggings
29965	girdle of the righteous path
29966	vambraces of ending
29967	nether vest
29968	nether leggings
29969	sparky s discarded helmet
29970	wildfeather leggings
29971	dragonstrike leggings
29972	trousers of the astromancer
29973	primalstorm breastplate
29974	living crystal breastplate
29975	golden dragonstrike breastplate
29976	worldstorm gauntlets
29977	star soul breeches
29978	consortium combatant s robes
29979	netherstorm eyepatch
29980	midrealm leggings
29981	ethereum life staff
29982	wand of the forgotten star
29983	fel steel warhelm
29984	girdle of zaetar
29985	void reaver greaves
29986	cowl of the grand engineer
29987	gauntlets of the sun king
29988	the nexus key
29989	sunshower light cloak
29990	crown of the sun
29991	sunhawk leggings
29992	royal cloak of the sunstriders
29993	twinblade of the phoenix
29994	thalassian wildercloak
29995	leggings of murderous intent
29996	rod of the sun king
29997	band of the ranger general
29998	royal gauntlets of silvermoon
29999	after hours pauldrons
30000	mixologist s gloves
30001	doc s belt
30002	boot s boots
30003	gloves of the nether stalker
30004	landing boots
30005	overmaster s shoulders
30006	wind trader s band
30007	the darkener s grasp
30008	pendant of the lost ages
30009	the burning crusader
30010	fleshling simulation staff
30011	ameer s impulse taser
30012	ameer s judgement
30013	twin bladed ripper
30014	x 52 pilot s leggings
30015	the sun king s talisman
30016	x 52 technician s helm
30017	telonicus s pendant of mayhem
30018	lord sanguinar s claim
30019	area 52 defender s pants
30020	fire cord of the magus
30021	wildfury greatstaff
30022	pendant of the perilous
30023	totem of the maelstrom
30024	mantle of the elven kings
30025	serpentshrine shuriken
30026	bands of the celestial archer
30027	boots of courage unending
30028	seventh ring of the tirisfalen
30029	bark gloves of ancient wisdom
30030	girdle of fallen stars
30031	red havoc boots
30032	red belt of battle
30033	boots of the protector
30034	belt of the guardian
30035	boots of the long road
30036	belt of the long road
30037	boots of blasting
30038	belt of blasting
30039	boots of utter darkness
30040	belt of deep shadow
30041	boots of natural grace
30042	belt of natural power
30043	hurricane boots
30044	monsoon belt
30045	boots of the crimson hawk
30046	belt of the black eagle
30047	blackfathom warbands
30048	brighthelm of justice
30049	fathomstone
30050	boots of the shifting nightmare
30051	idol of the crescent goddess
30052	ring of lethality
30053	pauldrons of the wardancer
30054	ranger general s chestguard
30055	shoulderpads of the stranger
30056	robe of hateful echoes
30057	bracers of eradication
30058	mallet of the tides
30059	choker of animalistic fury
30060	boots of effortless striking
30061	ancestral ring of conquest
30062	grove bands of remulos
30063	libram of absolute truth
30064	cord of screaming terrors
30065	glowing breastplate of truth
30066	tempest strider boots
30067	velvet boots of the guardian
30068	girdle of the tidal call
30069	earthforged leggings
30070	windforged leggings
30071	light earthforged blade
30072	light skyforged axe
30073	light emberforged hammer
30074	heavy earthforged breastplate
30075	gnarled chestpiece of the ancients
30076	stormforged hauberk
30077	windforged rapier
30079	illidari shoulderpads
30080	luminescent rod of the naaru
30081	warboots of obliteration
30082	talon of azshara
30083	ring of sundered souls
30084	pauldrons of the argent sentinel
30085	mantle of the tireless tracker
30086	stoneforged claymore
30087	stormforged axe
30088	skyforged great axe
30089	lavaforged warhammer
30090	world breaker
30091	true aim stalker bands
30092	orca hide boots
30093	great earthforged hammer
30094	totem of spirits
30095	fang of the leviathan
30096	girdle of the invulnerable
30097	coral barbed shoulderpads
30098	razor scale battlecloak
30099	frayed tether of the drowned
30100	soul strider boots
30101	bloodsea brigand s vest
30102	krakken heart breastplate
30103	fang of vashj
30104	cobra lash boots
30105	serpent spine longbow
30106	belt of one hundred deaths
30107	vestments of the sea witch
30108	lightfathom scepter
30109	ring of endless coils
30110	coral band of the revived
30111	runetotem s mantle
30112	glorious gauntlets of crestfall
30113	destroyer chestguard
30114	destroyer handguards
30115	destroyer greathelm
30116	destroyer legguards
30117	destroyer shoulderguards
30118	destroyer breastplate
30119	destroyer gauntlets
30120	destroyer battle helm
30121	destroyer greaves
30122	destroyer shoulderblades
30123	crystalforge chestguard
30124	crystalforge handguards
30125	crystalforge faceguard
30126	crystalforge legguards
30127	crystalforge shoulderguards
30129	crystalforge breastplate
30130	crystalforge gauntlets
30131	crystalforge war helm
30132	crystalforge greaves
30133	crystalforge shoulderbraces
30134	crystalforge chestpiece
30135	crystalforge gloves
30136	crystalforge greathelm
30137	crystalforge leggings
30138	crystalforge pauldrons
30139	rift stalker hauberk
30140	rift stalker gauntlets
30141	rift stalker helm
30142	rift stalker leggings
30143	rift stalker mantle
30144	deathmantle chestguard
30145	deathmantle handguards
30146	deathmantle helm
30148	deathmantle legguards
30149	deathmantle shoulderpads
30150	vestments of the avatar
30151	gloves of the avatar
30152	cowl of the avatar
30153	breeches of the avatar
30154	mantle of the avatar
30155	clam bar
30156	recipe clam bar
30157	cursed talisman
30158	morkh s shattered armor
30159	shroud of the avatar
30160	handguards of the avatar
30161	hood of the avatar
30162	leggings of the avatar
30163	wings of the avatar
30164	cataclysm chestguard
30165	cataclysm gloves
30166	cataclysm headguard
30167	cataclysm legguards
30168	cataclysm shoulderguards
30169	cataclysm chestpiece
30170	cataclysm handgrips
30171	cataclysm headpiece
30172	cataclysm leggings
30173	cataclysm shoulderpads
30174	dust of the fey drake
30175	gor drek s ointment
30177	stronglimb deeproot s trunk
30183	nether vortex
30184	thunderlord dire wolf tail
30185	cataclysm chestplate
30186	gladiator s felweave amice
30187	gladiator s felweave cowl
30188	gladiator s felweave handguards
30189	cataclysm gauntlets
30190	cataclysm helm
30191	qaenchant ring +2 weapon damage
30192	cataclysm legplates
30193	qaenchant ring +12 spell damage
30194	cataclysm shoulderplates
30195	qaenchant ring +20 healing
30196	robes of tirisfal
30197	qaenchant ring +4 stats
30198	qaenchant cloak +7 resistances
30199	qaenchant boots +4 health & mana5
30200	gladiator s felweave raiment
30201	gladiator s felweave trousers
30205	gloves of tirisfal
30206	cowl of tirisfal
30207	leggings of tirisfal
30210	mantle of tirisfal
30211	gloves of the corruptor
30212	hood of the corruptor
30213	leggings of the corruptor
30214	robe of the corruptor
30215	mantle of the corruptor
30216	nordrassil chestguard
30217	nordrassil gloves
30218	junior technician 3rd grade shoulders
30219	nordrassil headguard
30220	nordrassil life kilt
30221	nordrassil life mantle
30222	nordrassil chestplate
30223	nordrassil handgrips
30224	junior technician 3rd grade gloves
30225	junior technician 3rd grade bracers
30226	alley s recurve
30227	mark v s throwing star
30228	nordrassil headdress
30229	nordrassil feral kilt
30230	nordrassil feral mantle
30231	nordrassil chestpiece
30232	nordrassil gauntlets
30233	nordrassil headpiece
30234	nordrassil wrath kilt
30235	nordrassil wrath mantle
30236	chestguard of the vanquished champion
30237	chestguard of the vanquished defender
30238	chestguard of the vanquished hero
30239	gloves of the vanquished champion
30240	gloves of the vanquished defender
30241	gloves of the vanquished hero
30242	helm of the vanquished champion
30243	helm of the vanquished defender
30244	helm of the vanquished hero
30245	leggings of the vanquished champion
30246	leggings of the vanquished defender
30247	leggings of the vanquished hero
30248	pauldrons of the vanquished champion
30249	pauldrons of the vanquished defender
30250	pauldrons of the vanquished hero
30251	rina s diminution powder
30252	unearthed enkaat wand
30253	ethereal gloves
30254	zephyrion s belt
30255	chestguard of the stormspire
30256	pants of the naaru
30257	shattrath leggings
30258	chestplate of a dal
30259	voren thal s presence
30260	voren thal s package
30262	trep s shoulderguards
30263	heavy duty engineering boots
30264	area 52 engineering gloves
30265	zaxxis bracers
30266	zaxxis boots
30267	zaxxis gloves
30268	heap leggings
30269	warp raider s eyepatch
30270	scavenged breastplate
30271	midrealm hat
30272	eco dome leggings
30273	duro footgear
30274	papa s armbands
30275	mech tech shoulders
30276	wheeler family heirloom
30277	ripfang paw
30278	pilfered ethereal blade
30279	mama s insurance
30280	pattern belt of blasting
30281	pattern belt of the long road
30282	pattern boots of blasting
30283	pattern boots of the long road
30284	audi s embroidered boots
30285	b o o m operative s belt
30286	otherworldly pauldrons
30287	mantle of arcane mastery
30288	cenarion warden s gloves
30289	cenarion warden s belt
30290	leggings of concentrated power
30291	nexus guard s pauldrons
30292	my little friend
30293	heavenly inspiration
30294	red pointy hat
30295	exotic spiked shoulders
30296	lost chestplate of the reverent
30297	circlet of the starcaller
30298	void slayer s tunic
30299	starcaller s plated legguards
30300	dabiri s enigma
30301	pattern belt of natural power
30302	pattern belt of deep shadow
30303	pattern belt of the black eagle
30304	pattern monsoon belt
30305	pattern boots of natural grace
30306	pattern boots of utter darkness
30307	pattern boots of the crimson hawk
30308	pattern hurricane boots
30309	stonebreaker brew
30311	warp slicer
30312	infinity blade
30313	staff of disintegration
30314	phaseshift bulwark
30315	draenethyst mine crystal
30316	devastation
30317	cosmic infuser
30318	netherstrand longbow
30319	nether spike
30320	bundle of nether spikes
30321	plans belt of the guardian
30322	plans red belt of battle
30323	plans boots of the protector
30324	plans red havoc boots
30325	ravenous ravager egg
30326	bonechewer blood samples
30327	bonechewer blood
30328	protectorate assassin s tunic
30329	flesh handler s headpiece
30330	starcaller s plated belt
30331	diviner s cinch
30332	ferocious bands
30333	spaulders of the protectorate
30334	starcaller s plated stompers
30335	druidic force boots
30336	surger s hand wraps
30337	protectorate headplate
30338	diviner s cloak
30339	protectorate assassin s ring
30340	starkiller s bauble
30341	flesh handler s gauntlets
30342	protectorate waistband
30343	medallion of the horde
30344	medallion of the horde
30345	medallion of the horde
30346	medallion of the horde
30348	medallion of the alliance
30349	medallion of the alliance
30350	medallion of the alliance
30351	medallion of the alliance
30352	demolisher s bracers
30353	bloodmaul brutebane keg
30354	ultra deconsolodation zapper
30355	grilled shadowmoon tuber
30356	shadowmoon tuber
30357	oronok s tuber of healing
30358	oronok s tuber of agility
30359	oronok s tuber of strength
30360	lurky s egg
30361	oronok s tuber of spell power
30362	energized helm
30363	warp shielded hauberk
30364	resonating axe
30365	overseer s signet
30366	manastorm band
30368	slippers of the high priestess
30369	cleansed fel pauldrons
30370	gauntlets of the redeemed vindicator
30371	lightwarden s girdle
30372	socrethar s girdle
30373	netherfused pauldrons
30374	greaves of spellpower
30375	gauntlets of the vanquisher
30377	karja s medallion
30378	thalodien s charm
30379	vindicator s light vest
30380	girdle of the lost vindicator
30381	kaylaan s spaulders
30382	aldor ceremonial wraps
30383	belt of the sage
30384	brightdawn bracers
30385	qr xxxx plate spell bracer
30386	bloodguard s greaves
30394	sunfury blade
30395	warp master s maul
30396	jeweled halberd
30397	spymaster s crossbow
30398	boots of the beneficent
30399	nightstalker s wristguards
30400	thadell s bracers
30401	farahlite studded boots
30402	field agent s bracers
30404	bleeding hollow blood sample
30413	vindicator vuuleen s blade
30415	vindicator vuuleen s shield
30416	bladespire clan banner
30417	helm of gurn grubnosh
30418	darkspear purple glow
30419	brilliant necklace
30420	heavy jade ring
30421	red ring of destruction
30422	diamond focus ring
30425	bleeding hollow blood
30426	coilskar chest key
30428	first fragment of the cipher of damnation
30429	grom tor s lockbox
30430	boiled blood
30431	thunderlord clan artifact
30432	thunderlord clan drum
30433	thunderlord clan arrow
30434	thunderlord clan tablet
30435	the thunderspike
30436	jagged blue crystal
30437	jagged red crystal
30438	cache of the legion key
30442	crystalline key
30443	recipe transmute primal fire to earth
30444	pattern reinforced mining bag
30446	solarian s sapphire
30447	tome of fiery redemption
30448	talon of al ar
30449	void star talisman
30450	warp spring coil
30451	lohn goron bow of the torn heart
30453	second fragment of the cipher of damnation
30454	ar tor s lockbox
30457	gilneas sparkling water
30458	stromgarde muenster
30459	netherflame robe
30460	netherflame belt
30461	netherflame boots
30462	oronok s boar whistle
30463	lifeblood belt
30464	lifeblood bracers
30465	lifeblood leggings
30466	crocolisk tooth
30467	crocolisk tail
30468	t chali s hookah
30469	pattern netherflame robe
30470	pattern netherflame belt
30471	pattern netherflame boots
30472	pattern lifeblood leggings
30473	pattern lifeblood belt
30474	pattern lifeblood bracers
30475	razor thorn
30476	hypnotic flower
30477	connective tissue
30478	stringy ectoplasm
30479	wicked strong fetish
30480	fiery warhorse s reins
30481	fiery soul fragment
30483	pattern shadowcloth
30486	merciless gladiator s plate chestpiece
30487	merciless gladiator s plate gauntlets
30488	merciless gladiator s plate helm
30489	merciless gladiator s plate legguards
30490	merciless gladiator s plate shoulders
30491	general s plate greaves tier 2
30497	sentinel s mail leggings
30498	outrider s lamellar legguards
30499	brightsong wine
30500	rotten arakkoa egg
30501	bundle of bloodthistle
30503	archeologist s shrunken head
30504	leafblade dagger
30505	ghostclaw tunic
30506	snipe egg
30507	lucky rock
30508	pickled murloc head
30509	armor fragment
30510	imbued leaf
30511	stonewood
30512	giant spinneret
30513	bloody spider fang
30514	nether guards
30515	junior technician 3rd grade goggles
30516	chief engineer s belt
30517	netherfarer s leggings
30518	warpthread vest
30519	boots of the nexus warden
30520	gold trimmed cuffs
30521	warpweaver s gloves
30522	conjurer s staff
30523	hotshot cattle prod
30524	ancient draenei manuscript chapter 1
30525	ancient draenei manuscript chapter 2
30526	ancient draenei manuscript chapter 3
30527	draenei tomb relic
30529	plucked lashh an feather
30530	fistful of feathers
30531	breeches of the occultist
30532	kirin tor master s trousers
30533	vanquisher s legplates
30534	wyrmscale greaves
30535	forestwalker kilt
30536	greaves of the martyr
30538	midnight legguards
30539	tally s waiver signed
30540	tally s waiver unsigned
30541	stormsong kilt
30542	dimensional ripper area 52
30543	pontifex kilt
30544	ultrasafe transporter toshley s station
30545	cavrylin s medallion
30546	sovereign tanzanite
30547	luminous fire opal
30548	polished chrysoprase
30549	shifting tanzanite
30550	sundered chrysoprase
30551	infused fire opal
30552	blessed tanzanite
30553	pristine fire opal
30554	stalwart fire opal
30555	glowing tanzanite
30556	glinting fire opal
30558	glimmering fire opal
30559	etched fire opal
30560	rune covered chrysoprase
30561	vekh nir crystal
30563	regal tanzanite
30564	shining fire opal
30565	assassin s fire opal
30566	defender s tanzanite
30567	charged vekh nir crystal
30568	the sharp cookie
30569	proximo s rudius
30570	arkadian claymore
30571	don rodrigo s heart
30572	imperial tanzanite
30573	mysterious fire opal
30574	brutal tanzanite
30575	nimble fire opal
30579	illidari bane shard
30581	durable fire opal
30582	deadly fire opal
30583	timeless chrysoprase
30584	enscribed fire opal
30585	glistening fire opal
30586	seer s chrysoprase
30587	champion s fire opal
30588	potent fire opal
30589	dazzling chrysoprase
30590	enduring chrysoprase
30591	empowered fire opal
30592	steady chrysoprase
30593	iridescent fire opal
30594	effulgent chrysoprase
30595	legion codex key
30596	baa ri tablet fragment
30597	halaani claymore
30598	don amancio s heart
30599	avenging blades
30600	fluorescent tanzanite
30601	beaming fire opal
30602	jagged chrysoprase
30603	royal tanzanite
30604	resplendent fire opal
30605	vivid chrysoprase
30606	lambent chrysoprase
30607	splendid fire opal
30608	radiant chrysoprase
30609	swift nether drake
30610	smoked black bear meat
30611	halaani razorshaft
30612	halaani grimshot
30613	felfire diemetradon eye
30614	fel bomb
30615	halaani whiskey
30616	bundle of bloodthistle
30617	stormrage missive
30618	trachela s carcass
30619	fel reaver s piston
30620	spyglass of the hidden fleet
30621	prism of inner calm
30622	flamewrought key
30623	reservoir key
30626	sextant of unstable currents
30627	tsunami talisman
30628	fel reaver power core
30629	scarab of displacement
30630	fel reaver energy matrix
30631	fel reaver armor plate
30632	lament of the highborne
30633	auchenai key
30634	warpforged key
30635	key of time
30637	flamewrought key
30638	box o tricks
30639	blood elf disguise
30640	eclipsion armor
30641	boots of elusion
30642	drape of the righteous
30643	belt of the tracker
30644	grips of deftness
30645	third fragment of the cipher of damnation
30646	borak s lockbox
30649	orders from akama
30650	dertrok s wand case
30651	dertrok s first wand
30652	dertrok s second wand
30653	dertrok s third wand
30654	dertrok s fourth wand
30655	infused vekh nir crystal
30656	protovoltaic magneto collector
30657	the cipher of damnation
30658	flanis s pack
30659	kagrosh s pack
30663	fathom brooch of the tidewalker
30664	living root of the wildheart
30665	earring of soulful meditation
30666	ritssyn s lost pendant
30667	ring of unrelenting storms
30668	grasp of the dead
30672	elemental displacer
30673	inferno waist cord
30674	zierhut s lost treads
30675	lurker s cord
30676	lurker s grasp
30677	lurker s belt
30678	lurker s girdle
30679	sunfury glaive
30680	glider s foot wraps
30681	glider s boots
30682	glider s sabatons
30683	glider s greaves
30684	ravager s cuffs
30685	ravager s wrist wraps
30686	ravager s bands
30687	ravager s bracers
30688	deathforge key
30689	razuun s orders
30690	power converter
30691	haalum s medallion fragment
30692	eykenen s medallion fragment
30693	lakaan s medallion fragment
30694	uylaru s medallion fragment
30695	legion teleporter control
30696	scourgebane
30700	scourgestone fragments
30701	oscillating frequency scanners
30703	conjured mountain spring water
30704	ruuan ok claw
30705	spaulders of slaughter
30706	harbinger s pendant
30707	nimble foot treads
30708	belt of flowing thought
30709	pantaloons of flaming wrath
30710	blood guard s necklace of ferocity
30712	the doctor s key
30713	the art of fel reaver maintenance
30716	ever burning ash
30717	harbinger s pendant
30719	spectrecles
30720	serpent coil braid
30721	spectrecles
30722	ethereum nexus reaver
30723	talon of the tempest
30724	barrel blade longrifle
30725	anger spark gloves
30726	archaic charm of presence
30727	gilded trousers of benediction
30728	fathom helm of the deeps
30729	black iron battlecloak
30730	terrorweave tunic
30731	faceguard of the endless watch
30732	exodar life staff
30733	hope ender
30734	leggings of the seventh circle
30735	ancient spellcloak of the highborne
30736	ring of flowing light
30737	gold leaf wildboots
30738	ring of reciprocity
30739	scaled greaves of the marksman
30740	ripfiend shoulderplates
30741	topaz studded battlegrips
30742	temporal phase modulator
30743	proto nether drake essence
30744	draenic leather pack
30745	heavy toolbox
30746	mining sack
30747	gem pouch
30748	enchanter s satchel
30749	draenic sparring blade
30750	draenic warblade
30751	mag hari light axe
30752	mag hari battleaxe
30753	warphorn spear
30754	ancient bone mace
30755	mag hari fighting claw
30756	illidari bane shard
30757	draenic light crossbow
30758	aldor guardian rifle
30759	mag hari light recurve
30760	formal draenic robe
30761	infernoweave leggings
30762	infernoweave robe
30763	infernoweave boots
30764	infernoweave gloves
30765	heavy draenic breastplate
30766	inferno tempered leggings
30767	inferno tempered gauntlets
30768	inferno tempered boots
30769	inferno tempered chestguard
30770	inferno forged boots
30771	heavy draenic bracers
30772	inferno forged leggings
30773	inferno forged hauberk
30774	inferno forged gloves
30775	layered bone shield
30776	inferno hardened chestguard
30777	aldor heavy belt
30778	inferno hardened leggings
30779	inferno hardened boots
30780	inferno hardened gloves
30781	mag hari chain vest
30782	adolescent nether drake essence
30783	mature nether drake essence
30784	worn mag hari gauntlets
30785	morgroron s glaive
30786	makazradon s glaive
30787	illidari bane mageblade
30788	illidari bane broadsword
30789	illidari bane claymore
30791	silkwing cocoon
30792	iridescent wing
30793	skettis see invis potion
30794	shredder keys
30796	outland ore
30797	gorefiend s armor
30798	extra sharp daggermaw tooth
30799	gorefiend s cloak
30800	gorefiend s truncheon
30803	felhound whistle
30804	bronze band of force
30805	thick stain resistant gloves
30806	fel hound walking kit
30807	uvuros s fiery mane
30808	book of fel names
30809	mark of sargeras
30810	sunfury signet
30811	scroll of demonic unbanishing
30812	iridescent scale
30813	envenomed fang
30814	enormous molar
30815	giant scale
30816	spice bread
30817	simple flour
30818	repolarized magneto sphere
30819	felfire spleen
30820	vicious scorpid claw
30821	envenomed scorpid stinger
30822	box of ingots
30823	demon warding totem
30824	overcharged manacell
30825	ring of arcane shielding
30826	design ring of arcane shielding
30827	lexicon demonica
30828	vial of underworld loam
30829	tear of the earthmother
30830	trident of the outcast tribe
30831	cloak of arcane evasion
30832	gavel of unearthed secrets
30833	pattern cloak of arcane evasion
30834	shapeshifter s signet
30835	salvager s hauberk
30836	leggings of the skettis exile
30837	flameheart bracers
30838	flameheart gloves
30839	flameheart vest
30840	ether energized flesh
30841	lower city prayerbook
30842	pattern flameheart bracers
30843	pattern flameheart gloves
30844	pattern flameheart vest
30845	glyph of chromatic warding
30846	glyph of the outcast
30847	x 52 rocket helmet
30849	scalewing lightning gland
30850	freshly drawn blood
30851	felspine s hide
30852	multi spectrum light trap
30853	imbued silver spear
30854	book of fel names
30855	shatterstone pick
30856	underworld helm
30857	deep core lantern
30858	peon sleep potion
30859	wand of the seer
30860	kaylaan s signet
30861	furious shackles
30862	blessed adamantite bracers
30863	deadly cuffs
30864	bracers of the pathfinder
30865	tracker s blade
30866	blood stained pauldrons
30867	overdeveloped felfire gizzard
30868	rejuvenating bracers
30869	howling wind bracers
30870	cuffs of devastation
30871	bracers of martyrdom
30872	chronicle of dark secrets
30873	stillwater boots
30874	the unbreakable will
30875	forged illidari bane blade
30876	quenched illidari bane blade
30877	qaenchant bracer +6 mana5 sec
30878	glimmering steel mantle
30879	don alejandro s money belt
30880	quickstrider moccasins
30881	blade of infamy
30882	bastion of light
30883	pillar of ferocity
30884	hatefury mantle
30885	archbishop s slippers
30886	enchanted leather sandals
30887	golden links of restoration
30888	anetheron s noose
30889	kaz rogal s hardened heart
30890	collection of souls
30891	black featherlight boots
30892	beast tamer s shoulders
30893	sun touched chain leggings
30894	blue suede shoes
30895	angelista s sash
30896	glory of the defender
30897	girdle of hope
30898	shady dealer s pantaloons
30899	don rodrigo s poncho
30900	bow stitched leggings
30901	boundless agony
30902	cataclysm s edge
30903	legguards of endless rage
30904	savior s grasp
30905	midnight chestguard
30906	bristleblitz striker
30907	mail of fevered pursuit
30908	apostle of argus
30909	antonidas s aegis of rapt concentration
30910	tempest of chaos
30911	scepter of purification
30912	leggings of eternity
30913	robes of rhonin
30914	belt of the crescent moon
30915	belt of seething fury
30916	leggings of channeled elements
30917	razorfury mantle
30918	hammer of atonement
30919	valestalker girdle
30920	qr 10574 cloth mage chest
30921	qr 10637 cloth mage legs
30922	ata mal crown
30923	grom tor s bloodied bandage
30924	gloves of the high magus
30925	spaulders of the torn heart
30926	ashwalker s footwraps
30927	earthmender s bracer of shattering
30928	sketh lon survivor s tunic
30929	soothsayer s kilt
30930	grips of the void
30931	ghostly headwrap
30932	akama s sash
30933	hauberk of karabor
30934	qr 10574 leather rogue legs
30935	qr 10637 leather rogue helm
30936	eva s strap
30937	earthmender s fists of undoing
30938	azurestrike shoulders
30939	felboar hide shoes
30940	aged leather bindings
30941	ash tempered legguards
30942	manimal s cinch
30943	verdant gloves
30944	umberhowl s collar
30945	grom tor s friend s cousin s tunic
30946	mooncrest headdress
30947	crimson mail hauberk
30948	sunfury legguards
30949	qr 10574 mail hunter helm
30950	darkhunter s cinch
30951	ar tor s mainstay
30952	earthmender s crimson spaulders
30953	boots of the skybreaker
30954	qr 10637 mail hunter bracers
30955	crown of cinders
30958	blackened chain greaves
30959	torn heart family tunic
30960	runed sketh lon legplates
30961	ash covered helm
30962	borak s belt of bravery
30963	qr 10574 plate warrior gloves
30964	skybreaker s pauldrons
30965	qr 10637 plate warrior boots
30966	singed vambraces
30967	the hands of fate
30968	earthmender s plated boots
30969	onslaught gauntlets
30970	onslaught handguards
30971	torn heart cloak
30972	onslaught battle helm
30973	band of anguish
30974	onslaught greathelm
30975	onslaught breastplate
30976	onslaught chestguard
30977	onslaught greaves
30978	onslaught legguards
30979	onslaught shoulderblades
30980	onslaught shoulderguards
30981	grom tor s pendant of conquest
30982	lightbringer gauntlets
30983	lightbringer gloves
30984	spellbreaker s buckler
30985	lightbringer handguards
30986	bloodforged guard
30987	lightbringer faceguard
30988	lightbringer greathelm
30989	lightbringer war helm
30990	lightbringer breastplate
30991	lightbringer chestguard
30992	lightbringer chestpiece
30993	lightbringer greaves
30994	lightbringer leggings
30995	lightbringer legguards
30996	lightbringer pauldrons
30997	lightbringer shoulderbraces
30998	lightbringer shoulderguards
30999	ashtongue blade
31000	bloodwarder s rifle
31001	gronnstalker s gloves
31002	summoner s blade
31003	gronnstalker s helmet
31004	gronnstalker s chestguard
31005	gronnstalker s leggings
31006	gronnstalker s spaulders
31007	skyshatter gloves
31008	skyshatter gauntlets
31009	wildcaller
31010	slayer s axe
31011	skyshatter grips
31012	skyshatter helmet
31013	ceremonial kris
31014	skyshatter headguard
31015	skyshatter cover
31016	skyshatter chestguard
31017	skyshatter breastplate
31018	skyshatter tunic
31019	skyshatter leggings
31020	skyshatter legguards
31021	skyshatter pants
31022	skyshatter shoulderpads
31023	skyshatter mantle
31024	skyshatter pauldrons
31025	idol of the avenger
31026	slayer s handguards
31027	slayer s helm
31028	slayer s chestguard
31029	slayer s legguards
31030	slayer s shoulderpads
31031	stormfury totem
31032	thunderheart gloves
31033	libram of righteous power
31034	thunderheart gauntlets
31035	thunderheart handguards
31036	oronok s ancient scepter
31037	thunderheart helmet
31038	staff of the redeemer
31039	thunderheart cover
31040	thunderheart headguard
31041	thunderheart tunic
31042	thunderheart chestguard
31043	thunderheart vest
31044	thunderheart leggings
31045	thunderheart legguards
31046	thunderheart pants
31047	thunderheart spaulders
31048	thunderheart pauldrons
31049	thunderheart shoulderpads
31050	gloves of the malefic
31051	hood of the malefic
31052	robe of the malefic
31053	leggings of the malefic
31054	mantle of the malefic
31055	gloves of the tempest
31056	cowl of the tempest
31057	robes of the tempest
31058	leggings of the tempest
31059	mantle of the tempest
31060	gloves of absolution
31061	handguards of absolution
31062	torn heart axe of battle
31063	cowl of absolution
31064	hood of absolution
31065	shroud of absolution
31066	vestments of absolution
31067	leggings of absolution
31068	breeches of absolution
31069	mantle of absolution
31070	shoulderpads of absolution
31071	grom tor s charge
31072	lohn goron bow of the torn heart
31073	borak s reminder
31074	amulet of the torn heart
31075	evoker s mark of the redemption
31076	spellsword s mark of the redemption
31077	slayer s mark of the redemption
31078	protector s mark of the redemption
31079	mercurial adamantite
31080	mercurial stone
31084	key to the arcatraz
31085	top shard of the arcatraz key
31086	bottom shard of the arcatraz key
31087	ata mal crystal
31088	tainted core
31089	chestguard of the forgotten conqueror
31090	chestguard of the forgotten vanquisher
31091	chestguard of the forgotten protector
31092	gloves of the forgotten conqueror
31093	gloves of the forgotten vanquisher
31094	gloves of the forgotten protector
31095	helm of the forgotten protector
31096	helm of the forgotten vanquisher
31097	helm of the forgotten conqueror
31098	leggings of the forgotten conqueror
31099	leggings of the forgotten vanquisher
31100	leggings of the forgotten protector
31101	pauldrons of the forgotten conqueror
31102	pauldrons of the forgotten vanquisher
31103	pauldrons of the forgotten protector
31104	evoker s helmet of second sight
31105	overlord s helmet of second sight
31106	stalker s helmet of second sight
31107	shamanistic helmet of second sight
31108	kor kron flare gun
31109	stealther s helmet of second sight
31110	druidic helmet of second sight
31111	uvuros hide gloves
31112	uvuros hide boots
31113	violet badge
31114	uvuros hide cinch
31115	uvuros plated spaulders
31116	infused amethyst
31117	soothing amethyst
31118	pulsing amethyst
31119	wyrmcult net
31120	meeting note
31121	costume scraps
31122	overseer disguise
31123	spinning nether weather vane
31124	nether weather vane
31125	boots of the decimator
31126	gloves of ferocity
31127	hauberk of totemic rage
31128	rexxar s whistle
31129	blackwhelp net
31130	wyrmcult blackwhelp
31131	sash of silent blades
31132	crust burster venom gland
31133	leggings of concentrated darkness
31134	blade of misfortune
31135	baron sablemane s poison
31136	breastplate of blade turning
31137	gauntlets of purification
31138	storm lord s girdle
31139	fist of reckoning
31140	cloak of entropy
31141	kodohide drum
31142	blade of trapped knowledge
31143	shroud of frenzy
31144	spirit s whistle
31145	headdress of the sleeper
31146	rexxar s battle horn
31147	pendant of cunning
31148	demon hide spaulders
31149	gloves of pandemonium
31150	gloves of piety
31151	girdle of siege
31152	chestguard of illumination
31153	axe of the legion
31154	bronze torc
31155	drakescale breastplate
31156	drakescale hauberk
31157	drakehide tunic
31158	drakeweave raiment
31159	felstone pauldrons
31160	felstone epaulets
31161	felstone spaulders
31162	felstone mantle
31163	nethersteel handguards
31164	nethersteel gauntlets
31165	nethersteel reinforced gloves
31166	nethersteel lined handwraps
31168	demon forged chestguard
31169	sketh lon war totem
31170	demon forged hauberk
31172	demon cured tunic
31173	boots of savagery
31174	demonweave raiment
31175	blade dancer s wristguards
31176	rockwurm plate handguards
31177	rockwurm scale gauntlets
31178	amulet of unstable power
31179	rockwurm hide gloves
31180	gauntlets of the skullsplitter
31181	rockwurm hide handwraps
31182	legion helm
31183	legion coif
31184	legion headguard
31185	legion crown
31186	braxxis staff of slumber
31187	boots of the pathfinder
31188	crocolisk scale vambraces
31189	crocolisk scale wristguards
31190	the dreamer s shoulderpads
31191	crocolisk hide bracers
31192	crocolisk hide bindings
31193	blade of unquenched thirst
31194	gronn blessed warbeads
31195	voidplate girdle
31196	amulet of sanctification
31197	voidscale belt
31198	voidhide cord
31199	voidweave cilice
31200	shield of the wayward footman
31201	illidari cloak
31202	girdle of divine blessing
31203	arcane loop
31204	the gunblade
31209	chimaerascale legplates
31210	chimaerascale legguards
31211	chimaerahide pants
31212	chimaerahide leggings
31213	abyssal plate sabatons
31214	abyssal mail greaves
31215	abyssal leather treads
31216	abyssal cloth footwraps
31217	crimson beholder eye
31218	fiery beholder eye
31219	emerald beholder eye
31220	amethyst beholder eye
31221	illidari vambraces
31222	headdress of inner rage
31223	illidari wristguards
31224	illidari bracers
31225	illidari bindings
31226	leggings of the sly
31227	feathered girdle
31228	feathered belt
31229	feathered waistband
31230	abyss walker s boots
31231	feathered sash
31232	grim sabatons
31233	grim greaves
31234	crystalblade of the draenei
31235	grim boots
31236	grim slippers
31237	elekk hide leggings
31238	dragonbone ring
31239	primed key mold
31240	scales of the beast
31241	primed key mold
31242	nagascale legplates
31243	nagascale legguards
31244	nagahide pants
31245	primed key mold
31246	nagahide leggings
31247	bog pauldrons
31248	bog epaulets
31249	bog spaulders
31250	bog mantle
31251	unfired key mold
31252	charred key mold
31253	action figure night elf druid staff
31254	striderhide cloak
31255	cloak of the craft
31256	silvermoon armor
31257	action figure troll priest staff
31258	band of sorrow
31259	action figure human warrior sword
31260	sketh lon commander s journal page 1
31261	sketh lon commander s journal page 2
31262	sketh lon commander s journal page 3
31263	silvermoon tunic
31264	silvermoon robes
31265	action figure human warrior shield
31266	action figure tauren hunter polearm
31267	action figure gnome warrior sword
31268	abomination cleaver
31269	ghoul hammer
31270	banshee rod
31271	illidan s command
31272	crown of endless knowledge
31275	necklace of trophies
31276	boots of zealotry
31277	pathfinder s band
31278	illidari tabard
31279	enchanted illidari tabard
31280	thundercaller s gauntlets
31281	mask of veiled death
31282	shroud of spiritual purity
31283	sash of sealed fate
31284	bracers of recklessness
31285	chestguard of the talon
31286	breastplate of rapid striking
31287	draenei honor guard shield
31288	the master s treads
31289	staff of divine infusion
31290	band of dominion
31291	crystalforged war axe
31292	crystal pulse shield
31293	girdle of gale force
31294	pauldrons of surging mana
31295	chestguard of the dark stalker
31297	robe of the crimson order
31298	legguards of the shattered hand
31299	the oathkeeper
31300	ironroot seeds
31302	onster sword stratholme d3
31303	valanos longbow
31304	the essence focuser
31305	ced s carver
31306	leggings of the sacred crest
31307	heart of fury
31308	the bringer of death
31310	wildhammer flare gun
31312	sinister area 52 boots
31313	nether rocket gloves
31314	rocket chief pauldrons
31315	goblin girdle
31316	lianthe s key
31317	rod of lianthe
31318	singing crystal axe
31319	band of impenetrable defenses
31320	chestguard of exile
31321	choker of repentance
31322	the hammer of destiny
31323	don santos famous hunting rifle
31324	sketh lon feather
31326	truestrike ring
31328	leggings of beast mastery
31329	lifegiving cloak
31330	lightning crown
31331	the night blade
31332	blinkstrike
31333	the night watchman
31334	staff of natural fury
31335	pants of living growth
31336	blade of wizardry
31337	orb of the blackwhelp
31338	charlotte s ivy
31339	lola s eve
31340	will of edward the odd
31341	wyrmcultist s cloak
31342	the ancient scepter of sue min
31343	kamaei s cerulean skirt
31344	ceremonial incense
31345	the journal of val zareq
31346	burning bleeding hollow torch
31347	bleeding hollow torch
31349	grulloc s sack
31350	huffer s whistle
31351	dragonfire trap
31354	recipe flask of the titans
31355	recipe flask of supreme power
31356	recipe flask of distilled wisdom
31357	recipe flask of chromatic resistance
31358	design dawnstone crab
31359	design enduring deep peridot
31360	unfinished headpiece
31361	pattern cobrahide leg armor
31362	pattern nethercobra leg armor
31363	gorgrom s favor
31364	wildguard breastplate
31365	energized headpiece
31366	felsworn gas mask
31367	wildguard leggings
31368	wildguard helm
31369	iceguard breastplate
31370	iceguard leggings
31371	iceguard helm
31372	rocknail flayer carcass
31373	rocknail flayer giblets
31374	worg master s head
31375	gladiator s kodohide gloves
31376	gladiator s kodohide helm
31377	gladiator s kodohide legguards
31378	gladiator s kodohide spaulders
31379	gladiator s kodohide tunic
31380	acrobat s mark of the sha tar
31381	aggressor s mark of the sha tar
31382	mage s mark of the sha tar
31383	spiritualist s mark of the sha tar
31384	damaged mask
31386	staff of parshah
31387	mystery mask
31389	captured eye of grillok
31390	plans wildguard breastplate
31391	plans wildguard leggings
31392	plans wildguard helm
31393	plans iceguard breastplate
31394	plans iceguard leggings
31395	plans iceguard helm
31396	gladiator s ringmail armor
31397	gladiator s ringmail gauntlets
31398	the frozen eye
31399	the natural ward
31400	gladiator s ringmail helm
31401	design the frozen eye
31402	design the natural ward
31403	sablemane s sleeping powder
31404	green trophy tabard of the illidari
31405	purple trophy tabard of the illidari
31406	gladiator s ringmail leggings
31407	gladiator s ringmail spaulders
31408	offering of the sha tar
31409	gladiator s mooncloth gloves
31410	gladiator s mooncloth hood
31411	gladiator s mooncloth leggings
31412	gladiator s mooncloth mantle
31413	gladiator s mooncloth robe
31414	wild wood staff
31415	iron oak shield
31416	scorch wood bow
31417	staff of the ashtongue deathsworn
31418	sylvanaar gloves
31419	living grove shoulderpads
31420	protector s boots
31421	sentinel armbands
31422	heavy elven dirk
31423	wolf hewer s axe
31424	arcane wand of sylvanaar
31425	ogre vanquisher s belt
31426	agile mountain bracers
31427	sylvanaar defender s pauldrons
31428	commander skyshadow s gloves
31429	spelunker s mantle
31430	miner s gloves
31431	all weather armguards
31432	explorer s boots
31433	sylvanaar elite caster s armor
31434	ogre assassin s britches
31435	gurn s horned helmet
31436	sylvanaar champion s shoulders
31437	medicinal drake essence
31438	fizit s mantle of drake hunting
31439	precise gloves of alacrity
31440	devolved drake girdle
31441	clocktock s jumpers
31442	metro s slimming legs
31443	nickwinkle s harness experiment
31444	party hat mistake
31445	last year s in belt
31446	vibro shanker
31447	vibro dagger
31448	vibro sword
31449	distilled stalker sight
31450	stealth of the stalker
31451	pure energy
31452	energized wristwraps
31453	charged footwear
31454	scalewing gloves
31455	muscle toning belt
31456	gnomish casting boots
31457	toshley s station hero s hat
31458	razaani buster leggings
31459	soul saver s chest plate
31460	sha tari vindicator s waistguard
31461	a dal s gift
31462	shattrath s champion belt
31463	zezzak s shard
31464	naaru belt of precision
31465	sha tari anchorite s cloak
31469	black dragon corpse
31470	witch doctor s beads
31471	t chali s kilt
31472	hexxer s belt
31473	ogre defiler s handguards
31474	wand of the ancestors
31475	thunderlord scalpel
31476	slow death dirk
31477	red hands of the thunderlord
31478	tor chunk s foot covers
31479	rugged mountain bracers
31480	ogre beater s belt
31481	thunderlord armbands
31482	dire wolf handler gloves
31483	gor drek s pauldrons
31484	wolf chaps
31485	dark deed leggings
31486	bear strength harness
31487	wild horned helm
31488	boots of the ancient killer
31489	orb of the grishna
31490	netherwing protector s shield
31491	netherwing defender s shield
31492	claw of the netherwing flight
31493	netherwing spiritualist s charm
31494	netherwing sorceror s charm
31495	grishnath orb
31496	tome of fireball xiv
31498	tome of frostbolt xiv
31500	tome of arcane missiles xi
31501	tome of conjure food viii
31502	libram blessing of might viii
31503	libram greater blessing of might iii
31504	nethervine crystal
31505	manual of heroic strike xi
31506	manual of revenge viii
31507	grimoire of searing pain
31508	coven britches
31509	wyrmcultist s hood
31510	hewing gloves
31511	chest of the wyrmcult
31512	tree warden s belt
31513	blackwhelp belt
31514	dragonkin shirt
31515	whelpscale gauntlets
31516	bracers of the weald
31517	dire pinfeather
31518	exorcism feather
31519	inkling s leggings
31520	blackwing helm
31521	expedition defender s shoulders
31522	primal mooncloth supplies
31523	treebole s hoop
31524	square of imbued netherweave
31525	vial of primal reagents
31526	raven s wood exorciser s band
31527	leafbeard ring
31528	ring of the stonebark
31529	grillok s eyepatch
31530	sample of primal mooncloth
31531	wraithcloth bindings
31532	supple leather boots
31533	diluvian spaulders
31534	whiteknuckle gauntlets
31535	bloodboil poison
31536	camp anger key
31537	darktread boots
31538	twin moon shoulderguards
31539	chaintwine cinch
31540	fairweather s wristguards
31541	whistling sword
31542	fanged axe
31543	adjudicator s staff
31544	clefthoof hide leggings
31545	oilcloth breeches
31546	tourmaline crown
31547	malefactor s eyepatch
31548	blackened chestplate
31549	leonine breastplate
31550	albreck s findings
31552	windchanneller s miter
31553	windchanneller s mantle
31554	windchanneller s tunic
31555	windchanneller s ceinture
31556	windchanneller s leggings
31557	windchanneller s boots
31558	windchanneller s bindings
31559	windchanneller s gloves
31560	skystalker s shroud
31561	skystalker s shoulders
31562	skystalker s tunic
31563	skystalker s cord
31564	skystalker s leggings
31565	skystalker s boots
31566	skystalker s bracers
31567	skystalker s gloves
31568	mistshroud helm
31569	mistshroud shoulders
31570	mistshroud tunic
31571	mistshroud belt
31572	mistshroud pants
31573	mistshroud boots
31574	mistshroud bracers
31575	mistshroud gauntlets
31576	slatesteel helm
31577	slatesteel shoulders
31578	slatesteel breastplate
31579	slatesteel girdle
31580	slatesteel leggings
31581	slatesteel boots
31582	slatesteel bracers
31583	slatesteel gauntlets
31584	high warlord s kodohide gloves
31585	high warlord s kodohide helm
31586	high warlord s kodohide legguards
31587	high warlord s kodohide spaulders
31588	high warlord s kodohide tunic
31589	grand marshal s kodohide gloves
31590	grand marshal s kodohide helm
31591	grand marshal s kodohide legguards
31592	grand marshal s kodohide spaulders
31593	grand marshal s kodohide tunic
31594	general s kodohide belt
31595	general s kodohide boots
31596	marshal s kodohide belt
31597	marshal s kodohide boots
31598	general s kodohide bracers
31599	marshal s kodohide bracers
31606	demoniac scryer
31607	demoniac scryer reading
31610	rod of purification
31613	gladiator s ornamented chestguard
31614	gladiator s ornamented gloves
31615	ancient draenei arcane relic
31616	gladiator s ornamented headcover
31617	ancient draenei war talisman
31618	gladiator s ornamented legplates
31619	gladiator s ornamented spaulders
31620	grand marshal s mooncloth mitts
31621	high warlord s mooncloth mitts
31622	grand marshal s mooncloth cowl
31623	grand marshal s mooncloth legguards
31624	grand marshal s mooncloth shoulderpads
31625	grand marshal s mooncloth vestments
31626	high warlord s mooncloth cowl
31627	high warlord s mooncloth legguards
31628	high warlord s mooncloth shoulderpads
31629	high warlord s mooncloth vestments
31630	grand marshal s ornamented chestplate
31631	grand marshal s ornamented gloves
31632	grand marshal s ornamented headguard
31633	grand marshal s ornamented leggings
31634	grand marshal s ornamented spaulders
31635	high warlord s ornamented chestplate
31636	high warlord s ornamented gloves
31637	high warlord s ornamented headguard
31638	high warlord s ornamented leggings
31639	high warlord s ornamented spaulders
31640	grand marshal s ringmail chestguard
31641	grand marshal s ringmail gloves
31642	grand marshal s ringmail headpiece
31643	grand marshal s ringmail legguards
31644	grand marshal s ringmail shoulders
31646	high warlord s ringmail chestguard
31647	high warlord s ringmail gloves
31648	high warlord s ringmail headpiece
31649	high warlord s ringmail legguards
31650	high warlord s ringmail shoulderpads
31651	bladespire totem
31652	enchanted nethervine crystal
31653	condensed nether gas
31655	veil skith prison key
31656	lesser nether drake spirit
31657	chemise of rebirth
31658	scout s hood
31659	researcher s mantle
31660	feralfen skulker s belt
31661	leesa oh s wristbands
31662	rilak s missive
31663	spirit calling totems
31664	zuluhed s key
31665	toy rc mortar tank
31666	battered steam tonk controller
31667	knife of a thousand lies
31668	orb collecting totem
31670	raptor ribs
31671	serpent flesh
31672	mok nathal shortribs
31673	crunchy serpent
31674	recipe crunchy serpent
31675	recipe mok nathal shortribs
31676	fel regeneration potion
31677	fel mana potion
31678	mental interference rod
31679	fel strength elixir
31680	recipe fel strength elixir
31681	recipe fel regeneration potion
31682	recipe fel mana potion
31683	dreadwing skin belt
31684	netherhide gloves
31685	brood mother leggings
31686	nether protector s chest
31687	mok nathal mantle
31688	spiritcaller s mask
31689	mok nathal hero s pantaloons
31690	belt of the soul saver
31691	natasha s guardian cord
31692	natasha s ember necklace
31693	natasha s arcane filament
31694	natasha s pack collar
31695	natasha s choker
31696	natasha s battle chain
31697	dread relic
31698	letter from shattrath
31699	imbued draenethyst crystal
31700	runed silver staff
31701	saboteur s axe
31702	challenge from the horde
31703	nether stalker s blade
31704	the tempest key
31705	derelict caravan chest key
31706	the head of the hand of kargath
31707	cabal orders
31708	scroll of atalor
31709	drape of arunen
31710	gavel of k alen
31711	nether empowered footgear
31712	mok nathal champion s shoulderguards
31713	ritualist s helm
31714	nether drake wristguards
31715	demoniac soul prison
31717	shadowcast tunic
31718	darkstorm tunic
31719	stormstrike vest
31720	battlemaster s breastplate
31721	kalithresh s trident
31722	murmur s essence
31723	madman s blade
31724	arakkoa divining rod
31725	cilice of suffering
31726	necklace of bloodied feathers
31727	choker of bloodied feathers
31728	heirloom signet of willpower
31729	heirloom signet of valor
31730	heirloom signet of convalescence
31731	mekeda s gift
31732	unearthed orb
31733	akuno s blade
31734	ancient draenei crest
31735	timeless shell
31736	crystal of deep shadows
31737	timeless arrow
31739	smoke beacon
31740	meeting note
31741	nether wraith essence
31742	nether wraith beacon
31744	botanist s field guide
31745	illidari bane dagger
31746	phoenix fire band
31747	potent sha tari pendant
31748	shattrath choker of power
31749	a dal s recovery necklace
31750	earthen signet
31751	blazing signet
31752	sablemane s trap
31753	essence of infinity
31754	grisly totem
31755	wyvern cage key
31756	dib muad s crysknife
31757	fel cannonball
31758	revered mother s crysknife
31759	shani s crysknife
31760	miniwing
31761	talonbranch wand
31762	feather wrapped bow
31763	druid signal
31764	stillfire leggings
31765	redeemer s plate
31766	skywitch hat
31767	txt rexxar s misha summoner
31768	deep mire cloak
31769	sha tari torch
31770	marsh bracers
31772	anchorite relic
31773	mag har tabard
31774	kurenai tabard
31775	sporeggar tabard
31776	consortium tabard
31777	keepers of time tabard
31778	lower city tabard
31779	aldor tabard
31780	scryers tabard
31781	sha tar tabard
31782	warpstalker breastplate
31783	bloodfire leggings
31784	ancient terokkar hood
31785	edge of inevitability
31786	blacksting shoulders
31787	stalwart girdle
31788	blacksting gloves
31789	marshfang boots
31790	expedition pendant
31791	wildlord s band
31792	evergrove ranger s cloak
31793	ruuan weald wristguards
31794	sha tari vindicator s legplates
31795	draenei prayer beads
31796	sha tari marksman s gloves
31797	elekk hide spaulders
31798	death speaker s tunic
31799	fei fei doggy treat
31800	outcast s cache
31804	cenarion expedition tabard
31807	naturalized ammunition
31808	sablemane s signet
31809	evergrove wand
31810	fumper
31811	dread relic
31812	doom skull
31813	warp chaser blood
31814	mature bone sifter carcass
31815	zeppit s crystal
31816	dragonbone greatsword
31817	dragonbone shoulders
31818	dragonbone talisman
31819	noble plate pauldrons
31820	blessed signet ring
31821	blade of retribution
31823	book of many blessings
31825	fumper
31826	enormous bone worm organs
31827	sablemane s trap
31828	ritual prayer beads
31829	reins of the cobalt riding talbuk
31830	reins of the cobalt riding talbuk
31831	reins of the silver riding talbuk
31832	reins of the silver riding talbuk
31833	reins of the tan riding talbuk
31834	reins of the tan riding talbuk
31835	reins of the white riding talbuk
31836	reins of the white riding talbuk
31837	codex prayer of shadow protection ii
31838	major combat healing potion
31839	major combat healing potion
31840	major combat mana potion
31841	major combat mana potion
31842	qaenchant bracer +12 intellect
31843	qaenchant bracer +24 attack power
31844	qaenchant bracer +30 healing
31845	qaenchant bracer +15 spell damage
31846	qaenchant bracer +12 defense
31847	qaenchant bracer +12 stamina
31848	qaenchant bracer +4 all stats
31849	qaenchant bracer +12 strength
31852	major combat healing potion
31853	major combat healing potion
31854	major combat mana potion
31855	major combat mana potion
31856	darkmoon card crusade
31857	darkmoon card wrath
31858	darkmoon card vengeance
31859	darkmoon card madness
31860	great golden draenite
31861	great dawnstone
31862	balanced shadow draenite
31863	balanced nightseye
31864	infused shadow draenite
31865	infused nightseye
31866	veiled flame spessarite
31867	veiled noble topaz
31868	wicked noble topaz
31869	wicked flame spessarite
31870	design great golden draenite
31871	design balanced shadow draenite
31872	design infused shadow draenite
31873	design veiled flame spessarite
31874	design wicked flame spessarite
31875	design great dawnstone
31876	design balanced nightseye
31877	design infused nightseye
31878	design veiled noble topaz
31879	design wicked noble topaz
31880	blood elf orphan whistle
31881	draenei orphan whistle
31882	ace of blessings
31883	eight of blessings
31884	five of blessings
31885	four of blessings
31886	seven of blessings
31887	six of blessings
31888	three of blessings
31889	two of blessings
31890	blessings deck
31891	storms deck
31892	ace of storms
31893	eight of storms
31894	five of storms
31895	four of storms
31896	seven of storms
31898	six of storms
31899	three of storms
31900	two of storms
31901	ace of furies
31902	eight of furies
31903	five of furies
31904	four of furies
31905	seven of furies
31906	six of furies
31907	furies deck
31908	three of furies
31909	two of furies
31910	ace of lunacy
31911	eight of lunacy
31912	five of lunacy
31913	four of lunacy
31914	lunacy deck
31915	seven of lunacy
31916	six of lunacy
31917	three of lunacy
31918	two of lunacy
31919	nexus prince s ring of balance
31920	shaffar s band of brutality
31921	yor s collapsing band
31922	ring of conflict survival
31923	band of the crystalline void
31924	yor s revenge
31925	fiery band
31926	frigid band
31927	living band
31928	dark band
31929	enigmatic band
31930	enigmatic charm
31931	fiery charm
31932	living charm
31933	dark charm
31934	frigid charm
31935	frigid cloak
31936	fiery cloak
31937	living cloak
31938	enigmatic cloak
31939	dark cloak
31940	ethereum torque
31941	mark of the nexus king
31942	deathwing brood cloak
31943	ethereum band
31944	demonic capacitor
31945	shadow circuit
31946	ashtongue cowl
31947	energized isolation cube
31948	skystalk
31949	warden s arrow
31950	bogblossom
31951	toy dragon
31952	khorium lockbox
31953	ward of waking
31954	chewed up boot
31955	arelion s knapsack
31956	salvaged ethereum prison key
31957	ethereum prisoner i d tag
31958	merciless gladiator s bonecracker
31959	merciless gladiator s bonegrinder
31960	merciless gladiator s chain armor
31961	merciless gladiator s chain gauntlets
31962	merciless gladiator s chain helm
31963	merciless gladiator s chain leggings
31964	merciless gladiator s chain spaulders
31965	merciless gladiator s cleaver
31966	merciless gladiator s decapitator
31967	merciless gladiator s dragonhide gloves
31968	merciless gladiator s dragonhide helm
31969	merciless gladiator s dragonhide legguards
31971	merciless gladiator s dragonhide spaulders
31972	merciless gladiator s dragonhide tunic
31973	merciless gladiator s dreadweave gloves
31974	merciless gladiator s dreadweave hood
31975	merciless gladiator s dreadweave leggings
31976	merciless gladiator s dreadweave mantle
31977	merciless gladiator s dreadweave robe
31978	merciless gladiator s endgame
31979	merciless gladiator s felweave amice
31980	merciless gladiator s felweave cowl
31981	merciless gladiator s felweave handguards
31982	merciless gladiator s felweave raiment
31983	merciless gladiator s felweave trousers
31984	merciless gladiator s greatsword
31985	merciless gladiator s hacker
31986	merciless gladiator s crossbow of the phoenix
31987	merciless gladiator s kodohide gloves
31988	merciless gladiator s kodohide helm
31989	merciless gladiator s kodohide legguards
31990	merciless gladiator s kodohide spaulders
31991	merciless gladiator s kodohide tunic
31992	merciless gladiator s lamellar chestpiece
31993	merciless gladiator s lamellar gauntlets
31994	ethereum key tablet alpha
31995	merciless gladiator s lamellar legguards
31996	merciless gladiator s lamellar shoulders
31997	merciless gladiator s lamellar helm
31998	merciless gladiator s leather gloves
31999	merciless gladiator s leather helm
32000	merciless gladiator s leather legguards
32001	merciless gladiator s leather spaulders
32002	merciless gladiator s leather tunic
32003	merciless gladiator s left ripper
32004	merciless gladiator s linked armor
32005	merciless gladiator s linked gauntlets
32006	merciless gladiator s linked helm
32007	merciless gladiator s linked leggings
32008	merciless gladiator s linked spaulders
32009	merciless gladiator s mail armor
32010	merciless gladiator s mail gauntlets
32011	merciless gladiator s mail helm
32012	merciless gladiator s mail leggings
32013	merciless gladiator s mail spaulders
32014	merciless gladiator s maul
32015	merciless gladiator s mooncloth gloves
32016	merciless gladiator s mooncloth hood
32017	merciless gladiator s mooncloth leggings
32018	merciless gladiator s mooncloth mantle
32019	merciless gladiator s mooncloth robe
32020	merciless gladiator s ornamented chestguard
32021	merciless gladiator s ornamented gloves
32022	merciless gladiator s ornamented headcover
32023	merciless gladiator s ornamented legplates
32024	merciless gladiator s ornamented spaulders
32025	merciless gladiator s painsaw
32026	merciless gladiator s pummeler
32027	merciless gladiator s quickblade
32028	merciless gladiator s right ripper
32029	merciless gladiator s ringmail armor
32030	merciless gladiator s ringmail gauntlets
32031	merciless gladiator s ringmail helm
32032	merciless gladiator s ringmail leggings
32033	merciless gladiator s ringmail spaulders
32034	merciless gladiator s satin gloves
32035	merciless gladiator s satin hood
32036	merciless gladiator s satin leggings
32037	merciless gladiator s satin mantle
32038	merciless gladiator s satin robe
32039	merciless gladiator s scaled chestpiece
32040	merciless gladiator s scaled gauntlets
32041	merciless gladiator s scaled helm
32042	merciless gladiator s scaled legguards
32043	merciless gladiator s scaled shoulders
32044	merciless gladiator s shanker
32045	merciless gladiator s shield wall
32046	merciless gladiator s shiv
32047	merciless gladiator s silk amice
32048	merciless gladiator s silk cowl
32049	merciless gladiator s silk handguards
32050	merciless gladiator s silk raiment
32051	merciless gladiator s silk trousers
32052	merciless gladiator s slicer
32053	merciless gladiator s spellblade
32054	merciless gladiator s war edge
32055	merciless gladiator s war staff
32056	merciless gladiator s wyrmhide gloves
32057	merciless gladiator s wyrmhide helm
32058	merciless gladiator s wyrmhide legguards
32059	merciless gladiator s wyrmhide spaulders
32060	merciless gladiator s wyrmhide tunic
32061	evidence from alpha
32062	elixir of major fortitude
32063	earthen elixir
32064	protectorate treasure cache
32067	elixir of draenic wisdom
32068	elixir of ironskin
32069	mana tombs stasis chamber key
32070	recipe earthen elixir
32071	recipe elixir of ironskin
32072	gauntlets of dissension
32073	spaulders of dementia
32074	relics of aviana
32075	book of the raven
32076	handguards of the steady
32077	wrath infused gauntlets
32078	pauldrons of wild magic
32079	shaffar s stasis chamber key
32080	mantle of shadowy embrace
32081	eye of the stalker
32082	the fel barrier
32083	faceguard of determination
32084	helmet of the steadfast champion
32085	warpstalker helm
32086	storm master s helmet
32087	mask of the deceiver
32088	cowl of beastly rage
32089	mana binders cowl
32090	cowl of naaru blessings
32092	the eye of haramad
32093	chancellor s dreadweave gloves
32094	chancellor s dreadweave hood
32095	chancellor s dreadweave leggings
32096	chancellor s dreadweave mantle
32097	chancellor s dreadweave robe
32098	chancellor s mooncloth cowl
32099	chancellor s mooncloth legguards
32100	chancellor s mooncloth mitts
32101	chancellor s mooncloth shoulderpads
32102	chancellor s mooncloth vestments
32103	chancellor s satin gloves
32104	chancellor s satin hood
32105	chancellor s satin leggings
32106	chancellor s satin mantle
32107	chancellor s satin robe
32108	chancellor s silk amice
32109	chancellor s silk cowl
32110	chancellor s silk handguards
32111	chancellor s silk raiment
32112	chancellor s silk trousers
32113	chancellor s dragonhide gloves
32114	chancellor s dragonhide helm
32115	chancellor s dragonhide legguards
32116	chancellor s dragonhide spaulders
32117	chancellor s dragonhide tunic
32118	chancellor s kodohide gloves
32119	chancellor s kodohide helm
32120	chancellor s leather legguards
32121	chancellor s kodohide spaulders
32122	chancellor s kodohide legguards
32123	chancellor s kodohide tunic
32124	chancellor s leather gloves
32125	chancellor s leather helm
32126	chancellor s leather spaulders
32127	chancellor s leather tunic
32128	chancellor s wyrmhide gloves
32129	chancellor s wyrmhide helm
32130	chancellor s wyrmhide legguards
32131	chancellor s wyrmhide spaulders
32132	chancellor s wyrmhide tunic
32133	chancellor s chain armor
32134	chancellor s chain gauntlets
32135	chancellor s chain helm
32136	chancellor s chain leggings
32137	chancellor s chain spaulders
32138	chancellor s linked armor
32139	chancellor s linked gauntlets
32140	chancellor s linked helm
32141	chancellor s linked leggings
32142	chancellor s linked spaulders
32143	chancellor s mail armor
32144	chancellor s mail gauntlets
32145	chancellor s mail helm
32146	chancellor s mail leggings
32147	chancellor s mail spaulders
32148	chancellor s ringmail chestguard
32149	chancellor s ringmail gloves
32150	chancellor s ringmail headpiece
32151	chancellor s ringmail legguards
32152	chancellor s ringmail shoulders
32153	chancellor s lamellar chestpiece
32154	chancellor s lamellar gauntlets
32155	chancellor s lamellar helm
32156	chancellor s lamellar legguards
32157	chancellor s lamellar shoulders
32158	chancellor s ornamented chestplate
32159	chancellor s ornamented gloves
32160	chancellor s ornamented headguard
32161	chancellor s ornamented leggings
32162	chancellor s ornamented spaulders
32163	chancellor s plate chestpiece
32164	chancellor s plate gauntlets
32165	chancellor s plate helm
32166	chancellor s plate legguards
32167	chancellor s plate shoulders
32168	chancellor s scaled chestpiece
32169	chancellor s scaled gauntlets
32170	chancellor s scaled helm
32171	chancellor s scaled legguards
32172	chancellor s scaled shoulders
32173	chancellor s bonecracker
32174	chancellor s cleaver
32175	chancellor s hacker
32176	chancellor s pummeler
32177	chancellor s quickblade
32178	chancellor s shanker
32179	chancellor s shiv
32180	chancellor s slicer
32181	chancellor s bonegrinder
32182	chancellor s decapitator
32183	chancellor s maul
32184	chancellor s painsaw
32185	chancellor s war staff
32186	chancellor s warblade
32187	chancellor s heavy crossbow
32188	chancellor s left ripper
32189	chancellor s right ripper
32190	chancellor s spellblade
32191	chancellor s battletome
32192	chancellor s barricade
32193	bold crimson spinel
32194	delicate crimson spinel
32195	teardrop crimson spinel
32196	runed crimson spinel
32197	bright crimson spinel
32198	subtle crimson spinel
32199	flashing crimson spinel
32200	solid empyrean sapphire
32201	sparkling empyrean sapphire
32202	lustrous empyrean sapphire
32203	stormy empyrean sapphire
32204	brilliant lionseye
32205	smooth lionseye
32206	rigid lionseye
32207	gleaming lionseye
32208	thick lionseye
32209	mystic lionseye
32210	great lionseye
32211	sovereign shadowsong amethyst
32212	shifting shadowsong amethyst
32213	balanced shadowsong amethyst
32214	infused shadowsong amethyst
32215	glowing shadowsong amethyst
32216	royal shadowsong amethyst
32217	inscribed pyrestone
32218	potent pyrestone
32219	luminous pyrestone
32220	glinting pyrestone
32221	veiled pyrestone
32222	wicked pyrestone
32223	enduring seaspray emerald
32224	radiant seaspray emerald
32225	dazzling seaspray emerald
32226	jagged seaspray emerald
32227	crimson spinel
32228	empyrean sapphire
32229	lionseye
32230	shadowsong amethyst
32231	pyrestone
32232	eternium shell bracers
32233	wolpertinger s tankard
32234	fists of mukoa
32235	cursed vision of sargeras
32236	rising tide
32237	the maelstrom s fury
32238	ring of calming waves
32239	slippers of the seacaller
32240	guise of the tidal lurker
32241	helm of soothing currents
32242	boots of oceanic fury
32243	pearl inlaid boots
32244	seer s stone
32245	tide stomper s greaves
32247	ring of captured storms
32248	halberd of desolation
32249	seaspray emerald
32250	pauldrons of abyssal fury
32251	wraps of precise flight
32252	nether shadow tunic
32253	legionkiller
32254	the brutalizer
32255	felstone bulwark
32256	waistwrap of infinity
32257	idol of the white stag
32258	naturalist s preserving cinch
32259	bands of the coming storm
32260	choker of endless nightmares
32261	band of the abyssal lord
32262	syphon of the nathrezim
32263	praetorian s legguards
32264	shoulders of the hidden predator
32265	shadow walker s cord
32266	ring of deceitful intent
32267	boots of the resilient
32268	myrmidon s treads
32269	messenger of fate
32270	focused mana bindings
32271	kilt of immortal nature
32273	amice of brilliant light
32274	design bold crimson spinel
32275	spiritwalker gauntlets
32276	flashfire girdle
32277	design delicate crimson spinel
32278	grips of silent justice
32279	the seeker s wristguards
32280	gauntlets of enforcement
32281	design teardrop crimson spinel
32282	design runed crimson spinel
32283	design bright crimson spinel
32284	design subtle crimson spinel
32285	design flashing crimson spinel
32286	design solid empyrean sapphire
32287	design sparkling empyrean sapphire
32288	design lustrous empyrean sapphire
32289	design stormy empyrean sapphire
32290	design brilliant lionseye
32291	design smooth lionseye
32292	design rigid lionseye
32293	design gleaming lionseye
32294	design thick lionseye
32295	design mystic lionseye
32296	design great lionseye
32297	design sovereign shadowsong amethyst
32298	design shifting shadowsong amethyst
32299	design balanced shadowsong amethyst
32300	design infused shadowsong amethyst
32301	design glowing shadowsong amethyst
32302	design royal shadowsong amethyst
32303	design inscribed pyrestone
32304	design potent pyrestone
32305	design luminous pyrestone
32306	design glinting pyrestone
32307	design veiled pyrestone
32308	design wicked pyrestone
32309	design enduring seaspray emerald
32310	design radiant seaspray emerald
32311	design dazzling seaspray emerald
32312	design jagged seaspray emerald
32313	raven stone
32314	green riding nether ray
32315	cenarion sparrowhawk whistle
32316	purple riding nether ray
32317	red riding nether ray
32318	silver riding nether ray
32319	blue riding nether ray
32320	captive sparrowhawk
32321	sparrowhawk net
32323	shadowmoon destroyer s drape
32324	insidious bands
32325	rifle of the stoic guardian
32326	twisted blades of zarak
32327	robe of the shadow council
32328	botanist s gloves of growth
32329	cowl of benevolence
32330	totem of ancestral guidance
32331	cloak of the illidari council
32332	torch of the damned
32333	girdle of stability
32334	vest of mounting assault
32335	unstoppable aggressor s ring
32336	black bow of the betrayer
32337	shroud of forgiveness
32338	blood cursed shoulderpads
32339	belt of primal majesty
32340	garments of temperance
32341	leggings of divine retribution
32342	girdle of mighty resolve
32343	wand of prismatic focus
32344	staff of immaculate recovery
32345	dreadboots of the legion
32346	boneweave girdle
32347	grips of damnation
32348	soul cleaver
32349	translucent spellthread necklace
32350	touch of inspiration
32351	elunite empowered bracers
32352	naturewarden s treads
32353	gloves of unfailing faith
32354	crown of empowered fate
32355	essence of the eagle
32356	essence of the hawk
32357	essence of the falcon
32358	vim gol s vile grimoire
32359	arthorn s package
32361	blind seers icon
32362	pendant of titans
32363	naaru blessed life rod
32364	southfury moonstone
32365	heartshatter breastplate
32366	shadowmaster s boots
32367	leggings of devastation
32368	tome of the lightbringer
32369	blade of savagery
32370	nadina s pendant of purity
32373	helm of the illidari shatterer
32374	zhar doom greatstaff of the devourer
32375	bulwark of azzinoth
32376	forest prowler s helm
32377	mantle of darkness
32378	silver star
32379	grulloc s dragon skull
32380	maggoc s treasure chest
32381	schematic fused wiring
32382	slaag s standard
32383	skulloc s soul
32385	magtheridon s head
32386	magtheridon s head
32387	idol of the raven goddess
32388	shadow dust
32389	soulguard leggings
32390	soulguard girdle
32391	soulguard slippers
32392	soulguard bracers
32393	redeemed soul cinch
32394	redeemed soul moccasins
32395	redeemed soul wristguards
32396	redeemed soul legguards
32397	waistguard of shackled souls
32398	boots of shackled souls
32399	bracers of shackled souls
32400	greaves of shackled souls
32401	shadesteel girdle
32402	shadesteel sabots
32403	shadesteel bracers
32404	shadesteel greaves
32405	verdant sphere
32406	skyguard blasting charges
32407	creature maiev s glaive
32408	naj entus spine
32409	relentless earthstorm diamond
32410	thundering skyfire diamond
32411	design thundering skyfire diamond
32412	design relentless earthstorm diamond
32413	frost grenade
32414	tom s legs a
32415	tom s legs b
32416	tom s legs c
32417	tom s legs 1
32418	tom s legs 2
32419	tom s legs 3
32420	night s end
32421	tom s axe a
32422	tom s axe b
32423	icy blasting primers
32424	blade s edge ogre brew
32426	testing darkrune
32427	netherwing crystal
32428	heart of darkness
32429	pattern boots of shackled souls
32430	pattern bracers of shackled souls
32431	pattern greaves of shackled souls
32432	pattern waistguard of shackled souls
32433	pattern redeemed soul moccasins
32434	pattern redeemed soul wristguards
32435	pattern redeemed soul legguards
32436	pattern redeemed soul cinch
32437	pattern soulguard slippers
32438	pattern soulguard bracers
32439	pattern soulguard leggings
32440	pattern soulguard girdle
32441	plans shadesteel sabots
32442	plans shadesteel bracers
32443	plans shadesteel greaves
32444	plans shadesteel girdle
32445	skyguard tabard
32446	elixir of shadows
32447	pattern night s end
32449	essence infused moonstone
32450	gladiator s gavel
32451	gladiator s salvation
32452	gladiator s reprieve
32453	star s tears
32454	arthorn s research
32455	star s lament
32456	skyguard bombs
32457	arakkoa fetish
32458	ashes of al ar
32459	time phased phylactery
32461	furious gizmatic goggles
32462	morthis materials
32464	nethercite ore
32465	fortune coin
32466	bland blade
32467	vim gol s grimoire
32468	netherdust pollen
32469	illidari service papers
32470	nethermine flayer hide
32471	shard of azzinoth
32472	justicebringer 2000 specs
32473	tankatronic goggles
32474	surestrike goggles v2 0
32475	living replicator specs
32476	gadgetstorm goggles
32478	deathblow x11 goggles
32479	wonderheal xt40 shades
32480	magnified moon specs
32481	charm of swift flight
32482	touch of victory
32483	the skull of gul dan
32485	ashtongue talisman of valor
32486	ashtongue talisman of equilibrium
32487	ashtongue talisman of swiftness
32488	ashtongue talisman of insight
32489	ashtongue talisman of zeal
32490	ashtongue talisman of acumen
32491	ashtongue talisman of vision
32492	ashtongue talisman of lethality
32493	ashtongue talisman of shadows
32494	destruction holo gogs
32495	powerheal 4000 lens
32496	memento of tyrande
32497	stormrage signet ring
32498	fortune coin
32500	crystal spire of karabor
32501	shadowmoon insignia
32502	fel gland
32503	yarzill s mutton
32505	madness of the betrayer
32506	netherwing egg
32508	necklace of the deep
32509	netherwing relic
32510	softstep boots of tracking
32512	girdle of lordaeron s fallen
32513	wristbands of divine influence
32514	skettis band
32515	wristguards of determination
32516	wraps of purification
32517	the wavemender s mantle
32518	veil of turning leaves
32519	belt of divine guidance
32520	manaforged sphere
32521	faceplate of the impenetrable
32522	demonic bulwark
32523	ishaal s almanac
32524	shroud of the highborne
32525	cowl of the illidari high lord
32526	band of devastation
32527	ring of ancient knowledge
32528	blessed band of karabor
32529	heretic s gauntlets
32531	gezzarak s fang
32532	windrager s coils
32533	karrog s shard
32534	brooch of the immortal king
32535	gift of the talonpriests
32536	terokk s gavel
32537	terokk s gavel
32538	skywitch s drape
32539	skyguard s drape
32540	terokk s might
32541	terokk s wisdom
32542	imp in a ball
32561	tier 5 arrow box
32563	grilled picnic treat
32564	ishaal s almanac
32566	picnic basket
32567	aether ray eye
32568	swiftsteel bracers
32569	apexis shard
32570	swiftsteel shoulders
32571	dawnsteel bracers
32572	apexis crystal
32573	dawnsteel shoulders
32574	bindings of lightning reflexes
32575	shoulders of lightning reflexes
32576	depleted crystal focus
32577	living earth bindings
32578	charged crystal focus
32579	living earth shoulders
32580	swiftstrike bracers
32581	swiftstrike shoulders
32582	bracers of renewed life
32583	shoulderpads of renewed life
32584	swiftheal wraps
32585	swiftheal mantle
32586	bracers of nimble thought
32587	mantle of nimble thought
32588	banana charm
32589	hellfire encased pendant
32590	nethervoid cloak
32591	choker of serrated blades
32592	chestguard of relentless storms
32593	treads of the den mother
32595	ogrela reagent dust
32596	unstable flask of the elder
32597	unstable flask of the soldier
32598	unstable flask of the beast
32599	unstable flask of the bandit
32600	unstable flask of the physician
32601	unstable flask of the sorcerer
32602	crystalforged darkrune
32606	girdle of the lightbearer
32608	pillager s gauntlets
32609	boots of the divine light
32616	egbert s egg
32617	sleepy willy
32619	preserved fruit
32620	time lost scroll
32621	partially digested hand
32622	elekk training collar
32623	bossi s spare parts
32624	large iron metamorphosis geode
32625	small iron metamorphosis geode
32626	large copper metamorphosis geode
32627	small copper metamorphosis geode
32628	large silver metamorphosis geode
32629	large gold metamorphosis geode
32630	small gold metamorphosis geode
32631	small silver metamorphosis geode
32634	unstable amethyst
32635	unstable peridot
32636	unstable sapphire
32637	unstable citrine
32638	unstable topaz
32639	unstable talasite
32640	potent unstable diamond
32641	imbued unstable diamond
32642	raw darkrune
32643	darkrune
32645	crystalline crossbow
32646	medallion of karabor
32647	shard bound bracers
32648	vortex walking boots
32649	medallion of karabor
32650	cerulean crystal rod
32651	crystal orb of enlightenment
32652	ogri la aegis
32653	apexis cloak
32654	crystalforged trinket
32655	crystalweave bracers
32656	crystalhide handwraps
32657	arthorn s sparrowhawk whistle
32658	badge of tenacity
32659	crystal infused shiv
32660	crystalforged sword
32661	apexis crystal mace
32662	flaming quartz staff
32663	apexis cleaver
32664	dreamcrystal band
32665	crystalweave cape
32666	hardened hide of tyrantus
32667	bash ale
32668	dos ogris
32670	depleted two handed axe
32671	depleted mace
32672	depleted badge
32673	depleted dagger
32674	depleted sword
32675	depleted mail gauntlets
32676	depleted cloth bracers
32677	depleted cloak
32678	depleted ring
32679	depleted staff
32680	booterang
32681	onyx scale of rivendark
32682	obsidia scale
32683	jet scale of furywing
32684	insidion s ebony scale
32685	ogri la chicken fingers
32686	mingo s fortune giblets
32687	hazzik s package
32688	bloodstained fortune
32689	bloodstained fortune
32690	bloodstained fortune
32691	bloodstained fortune
32692	bloodstained fortune
32693	bloodstained fortune
32694	overseer s badge
32695	captain s badge
32696	banishing crystal
32697	apexis guardian s head
32698	wrangling rope
32700	bloodstained fortune
32701	bloodstained fortune
32702	bloodstained fortune
32703	bloodstained fortune
32704	bloodstained fortune
32705	bloodstained fortune
32706	bloodstained fortune
32707	bloodstained fortune
32708	bloodstained fortune
32709	bloodstained fortune
32710	bloodstained fortune
32711	bloodstained fortune
32712	bloodstained fortune
32713	bloodstained fortune
32714	splintered spider fang
32715	akkarai s talons
32716	gezzarak s claws
32717	karrog s spine
32718	vakkiz s scale
32720	time lost offering
32721	skyguard rations
32722	enriched terocone juice
32723	nethermine cargo
32724	sludge covered object
32725	murkblood miner s pick
32726	murkblood escape plans
32727	vial of tears
32728	sludge
32732	dragon teeth
32733	fel whip
32734	hand of the overseer
32735	radiant spencerite
32736	plans swiftsteel bracers
32737	plans swiftsteel shoulders
32738	plans dawnsteel bracers
32739	plans dawnsteel shoulders
32741	shabby arakkoa disguise
32742	adversarial bloodlines
32744	pattern bracers of renewed life
32745	pattern shoulderpads of renewed life
32746	pattern swiftstrike bracers
32747	pattern swiftstrike shoulders
32748	pattern bindings of lightning reflexes
32749	pattern shoulders of lightning reflexes
32750	pattern living earth bindings
32751	pattern living earth shoulders
32752	pattern swiftheal wraps
32753	pattern swiftheal mantle
32754	pattern bracers of nimble thought
32755	pattern mantle of nimble thought
32756	gyro balanced khorium destroyer
32757	blessed medallion of karabor
32758	brute cologne
32759	accelerator module
32760	the macho gnome s arrow
32761	the sarge s bullet
32762	rulkster s brain juice
32763	rulkster s secret sauce
32764	flaskataur s celestial brew
32765	flaskataur s tears
32766	flaskataur s flask of flaskocity
32767	flaskataur s flask of pretty good power
32768	reins of the raven lord
32769	belt of the raven lord
32770	skyguard silver cross
32771	airman s ribbon of gallantry
32772	brilliant pearl band
32773	bash ir s skeleton key
32774	the black pearl
32775	deepdiving pearl
32776	crown of the sea witch
32777	kronk s grab bag
32778	boots of righteous fortitude
32779	band of frigid elements
32780	the boomstick
32781	talon of anzu
32782	time lost figurine
32783	blue ogre brew
32784	red ogre brew
32785	veteran s chain sabatons
32786	veteran s dragonhide boots
32787	veteran s dreadweave stalkers
32788	veteran s kodohide boots
32789	veteran s lamellar greaves
32790	veteran s leather boots
32791	veteran s linked sabatons
32792	veteran s mail sabatons
32793	veteran s plate greaves
32794	veteran s scaled greaves
32795	veteran s silk footguards
32796	veteran s wyrmhide boots
32797	veteran s chain girdle
32798	veteran s dragonhide belt
32799	veteran s dreadweave belt
32800	veteran s kodohide belt
32801	veteran s lamellar belt
32802	veteran s leather belt
32803	veteran s linked girdle
32804	veteran s mail girdle
32805	veteran s plate belt
32806	veteran s scaled belt
32807	veteran s silk belt
32808	veteran s wyrmhide belt
32809	veteran s chain bracers
32810	veteran s dragonhide bracers
32811	veteran s dreadweave cuffs
32812	veteran s kodohide bracers
32813	veteran s lamellar bracers
32814	veteran s leather bracers
32816	veteran s linked bracers
32817	veteran s mail bracers
32818	veteran s plate bracers
32819	veteran s scaled bracers
32820	veteran s silk cuffs
32821	veteran s wyrmhide bracers
32822	flawless arcane essence
32823	illidari lord balthas instructions
32824	tigole s trashbringer
32825	soul cannon
32828	ogri la tabard
32829	windcharger s lance
32830	severin s cane
32831	jeweled rod
32832	scout s throwing knives
32833	purified jaggal pearl
32834	nether ray cage
32835	ogri la care package
32836	purified shadow pearl
32837	warglaive of azzinoth
32838	warglaive of azzinoth
32839	cauldron of major arcane protection
32840	major arcane protection potion
32842	dragonmaw flare gun
32843	scryer medals
32844	major nature protection potion
32845	major shadow protection potion
32846	major fire protection potion
32847	major frost protection potion
32848	explosives package
32849	cauldron of major fire protection
32850	cauldron of major frost protection
32851	cauldron of major nature protection
32852	cauldron of major shadow protection
32853	aldor medals
32854	hammer of righteous might
32857	reins of the onyx netherwing drake
32858	reins of the azure netherwing drake
32859	reins of the cobalt netherwing drake
32860	reins of the purple netherwing drake
32861	reins of the veridian netherwing drake
32862	reins of the violet netherwing drake
32863	skybreaker whip
32864	commander s badge
32865	drake tamer s gloves
32866	ascendant s boots
32867	dragonmaw augur s cinch
32868	skybreaker s mantle
32869	illidari lord s tunic
32870	legguards of contemplation
32871	horns of the illidari
32872	illidari rod of discipline
32882	hellfire shot
32883	felbane slugs
32888	the relics of terokk
32895	scroll of the maelstrom
32896	scroll of the sun
32897	mark of the illidari
32898	shattrath flask of fortification
32899	shattrath flask of mighty restoration
32900	shattrath flask of supreme power
32901	shattrath flask of relentless assault
32902	bottled nethergon energy
32903	cenarion mana salve
32904	cenarion healing salve
32905	bottled nethergon vapor
32906	stunned wolpertinger
32907	wolpertinger net
32908	tempest keep armaments
32909	blue ogre brew special
32910	red ogre brew special
32912	yellow brewfest stein
32914	bland shiv
32915	filled yellow brewfest stein
32916	grimbooze s research notes
32917	filled yellow brewfest stein
32918	filled yellow brewfest stein
32919	filled yellow brewfest stein
32920	filled yellow brewfest stein
32921	brewfest mug 2007 filled f
32941	corruptor s signet
32942	ring of the overseer
32943	swiftsteel bludgeon
32944	talon of the phoenix
32945	fist of molten fury
32946	claw of molten fury
32947	auchenai healing potion
32948	auchenai mana potion
32949	unusually slow sword
32950	unusually slow mace
32951	unusually slow two hander
32952	qaenchant weapon spellsurge
32954	tom s boots 1
32955	tom s boots 2
32956	tom s boots 3
32957	tom s bracer 1
32958	tom s bracer 2
32959	tom s bracer 3
32960	elekk dispersion ray
32961	merciless gladiator s reprieve
32962	merciless gladiator s touch of defeat
32963	merciless gladiator s gavel
32964	merciless gladiator s salvation
32965	debug headless horseman create fire node
32966	debug headless horseman start fire
32967	debug headless horseman extinguish fire
32971	water bucket
32973	general s mooncloth cuffs
32974	general s mooncloth belt
32975	general s mooncloth slippers
32976	marshal s mooncloth belt
32977	marshal s mooncloth cuffs
32978	marshal s mooncloth slippers
32979	veteran s mooncloth belt
32980	veteran s mooncloth cuffs
32981	veteran s mooncloth slippers
32982	general s ornamented belt
32983	general s ornamented bracers
32984	general s ornamented greaves
32985	marshal s ornamented belt
32986	marshal s ornamented bracers
32987	marshal s ornamented greaves
32988	veteran s ornamented belt
32989	veteran s ornamented bracers
32990	veteran s ornamented greaves
32991	general s ringmail bracers
32992	general s ringmail girdle
32993	general s ringmail sabatons
32994	marshal s ringmail bracers
32995	marshal s ringmail girdle
32996	marshal s ringmail sabatons
32997	veteran s ringmail bracers
32998	veteran s ringmail girdle
32999	veteran s ringmail sabatons
33001	reflective dust
33004	clamlette magnifique
33006	vengeful gladiator s heavy crossbow
33007	grimbooze s secret recipe
33008	deserter propaganda
33009	tender strider meat
33010	griftah s note
33012	terokkar lilac
33013	budd s map of zul aman
33014	fine poking stick
33015	altered leaflets
33016	blue brewfest stein
33017	filled blue brewfest stein
33018	filled blue brewfest stein
33019	filled blue brewfest stein
33020	filled blue brewfest stein
33021	filled blue brewfest stein
33022	brewfest mug 2008 filled f
33023	savory sausage
33024	pickled sausage
33025	spicy smoked sausage
33026	the golden link
33028	barleybrew light
33029	barleybrew dark
33030	barleybrew clear
33031	thunder 45
33032	thunderbrew ale
33033	thunderbrew stout
33034	gordok grog
33035	ogre mead
33036	mudder s milk
33037	defias orders
33038	damaged diving gear
33039	tool kit
33040	repaired diving gear
33041	salvaged strongbox
33042	black coffee
33043	the essential brewfest pretzel
33044	salvage kit
33045	renn s supplies
33046	insignia of pvp pwn
33047	belbi s eyesight enhancing romance goggles
33048	stewed trout
33050	grimtotem note
33051	grimtotem battle plan
33052	fisherman s feast
33053	hot buttered trout
33054	the seal of danzalar
33055	band of vile aggression
33056	veteran s band of dominance
33057	veteran s band of triumph
33058	band of the vigilant
33061	grimtotem key
33064	veteran s band of salvation
33065	veteran s pendant of dominance
33066	veteran s pendant of triumph
33067	veteran s pendant of conquest
33068	veteran s pendant of salvation
33069	sturdy rope
33070	raptor bait
33071	blackhoof armaments
33072	tabetha s torch
33073	test_ears_hidden builtbyblue
33074	test_eyes_hidden builtbyblue
33075	test_noseandears_hidden builtbyblue
33076	merciless gladiator s idol of tenacity
33077	merciless gladiator s libram of justice
33078	merciless gladiator s totem of the third wind
33079	murloc costume
33081	voodoo skull
33082	wreath
33083	orcish grog
33085	bloodfen feather
33086	stonemaul banner
33087	black dragonkin essence
33088	brogg s totem
33091	energized totem
33092	healing potion injector
33093	mana potion injector
33095	stonemaul banner
33096	complimentary brewfest sampler
33097	mushroom ring
33101	captured totem
33102	blood of zul jin
33103	marsh venom
33104	ring of skill
33105	budd s guise of zul aman
33106	forest troll tusk
33107	tattered voodoo doll
33108	ooze buster
33110	razorspine s sword
33112	witchbane
33113	witchbane torch
33114	sealed letter
33115	sealed letter
33117	jack o lantern
33122	cloak of darkness
33124	pattern cloak of darkness
33126	thresher oil
33127	dastardly denizens of the deep
33131	crimson sun
33132	delicate fire ruby
33133	don julio s heart
33134	kailee s rose
33135	falling star
33137	sparkling falling star
33138	mystic bladestone
33139	brilliant bladestone
33140	blood of amber
33141	great bladestone
33142	rigid bladestone
33143	stone of blades
33144	facet of eternity
33148	formula enchant cloak dodge
33149	formula enchant cloak stealth
33150	formula enchant cloak subtlety
33151	formula enchant cloak subtlety
33152	formula enchant gloves superior agility
33153	formula enchant gloves threat
33154	sinister squashling
33155	design kailee s rose
33156	design crimson sun
33157	design falling star
33158	design stone of blades
33159	design blood of amber
33160	design facet of eternity
33163	zeppelin cargo
33165	formula enchant weapon greater agility
33166	pagle s fish paste extra strength
33173	ragesteel shoulders
33174	plans ragesteel shoulders
33175	wyrmtail
33176	flying broom
33182	swift flying broom
33184	swift magic broom
33185	adamantite weapon chain
33186	plans adamantite weapon chain
33189	rickety magic broom
33191	jungle stompers
33192	carved witch doctor s stick
33193	mossy band
33194	ancient ceremonial band
33195	cracked stone band
33196	softly glowing ring
33197	mossy necklace
33198	necklace of decay
33200	ancient ceremonial necklace
33201	silver moonstone pendant
33202	marsh frog leg
33203	robes of heavenly purpose
33204	shadowprowler s chestguard
33205	pattern shadowprowler s chestguard
33206	pauldrons of primal fury
33207	implacable guardian sabatons
33208	flask of chromatic wonder
33209	recipe flask of chromatic wonder
33211	bladeangel s money belt
33214	akil zon s talonblade
33215	bloodstained elven battlevest
33216	chestguard of hidden purpose
33217	unstacked tricky treat
33218	goblin gumbeaux
33219	goblin gumbo kettle
33222	nyn jah s tabi boots
33223	fishing chair
33224	reins of the spectral tiger
33225	reins of the swift spectral tiger
33226	tricky treat
33228	crimson tunic
33229	mordant s travel tunic
33230	leggings of the long road
33231	oversized stonemaul hood
33232	journeyman s cowl
33233	cobalt threaded gloves
33234	iced berry slush
33235	journeyman s epaulets
33236	fizzy faire drink classic
33237	brogg s battle harness
33239	marshwarden s tunic
33240	grimtotem earthbinder s tunic
33241	oiled leather leggings
33242	raptorhide legguards
33243	skirmisher s cover
33244	the wanderer s cover
33245	grimsby s gaudy girdle
33246	funnel cake
33247	swift wind spaulders
33248	crested shoulderpads
33249	boots of the skirmisher
33250	archer s wristguard
33251	steel banded hauberk
33252	gleaming scale breastplate
33253	golden helm
33254	afrazi forest strider drumstick
33255	rustproof waistguard
33256	refitted bruiser gauntlets
33257	scaled marshwalkers
33258	protective engineer s leggings
33259	crimson barbut
33260	spellbound cloak
33261	destroyer s cloak
33262	morlann s seal
33263	raptor eye ring
33264	glowing tourmaline ring
33265	pendant of ferocity
33266	book of the adept
33267	fleshripper
33268	bone dirk
33269	bejeweled dagger
33270	mariner s sword
33271	battlecaster s edge
33272	biting axe
33273	seasoned marshwood bow
33274	mercenary s crossbow
33277	tome of thomas thomson
33279	iron tusk girdle
33280	war feathered loop
33281	brooch of nature s mercy
33283	amani punisher
33285	fury of the ursine
33286	mojo mender s mask
33287	gnarled ironwood pauldrons
33288	complimentary brewfest sampler debug
33291	voodoo woven belt
33292	hallowed helm
33293	signet of ancient magics
33296	brooch of deftness
33297	the savage s choker
33298	prowler s strikeblade
33299	spaulders of the advocate
33300	shoulderpads of dancing blades
33303	skullshatter warboots
33304	cloak of subjugated power
33305	design don julio s heart
33306	ram racing reins
33307	formula enchant weapon executioner
33309	merciless gladiator s redoubt
33313	merciless gladiator s barrier
33315	qaenchant weapon executioner
33317	robe of departed spirits
33322	shimmer pelt vest
33324	treads of the life path
33325	voodoo shaker
33326	bulwark of the amani empire
33327	mask of introspection
33328	arrow fall chestguard
33329	shadowtooth trollskin cuirass
33331	chain of unleashed rage
33332	enamelled disc of mojo
33333	kharmaa s shroud of hope
33334	fetish of the primal gods
33354	wub s cursed hexblade
33356	helm of natural regeneration
33357	footpads of madness
33386	man kin do s belt
33388	heartless
33389	dagger of bad mojo
33421	battleworn tuskguard
33432	coif of the jungle stalker
33442	target rifle
33446	girdle of stromgarde s hope
33453	hood of hexing
33455	brewfest prize ticket
33463	hood of the third eye
33464	hex lord s voodoo pauldrons
33465	staff of primal fury
33466	loop of cursed bones
33467	blade of twisted visions
33468	dark blessing
33469	hauberk of the empire s champion
33471	two toed sandals
33473	chestguard of the warlord
33474	ancient amani longbow
33476	cleaver of the unforgiving
33478	jin rohk the great apocalypse
33479	grimgrin faceguard
33480	cord of braided troll hair
33481	pauldrons of stone resolve
33482	cobra lash boots
33483	life step belt
33484	dory s embrace
33489	mantle of ill intent
33490	staff of dark mending
33491	tuskbreaker
33492	trollbane
33493	umbral shiv
33494	amani divining staff
33495	rage
33496	signet of primal wrath
33497	mana attuned band
33498	signet of the quiet forest
33499	signet of the last defender
33500	signet of eternal life
33501	bloodthirster s wargreaves
33502	libram of mending
33503	libram of divine judgement
33504	libram of divine purpose
33505	totem of living water
33506	skycall totem
33507	stonebreaker s totem
33508	idol of budding life
33509	idol of terror
33510	idol of the unseen moon
33512	furious deathgrips
33513	eternium rage shackles
33514	pauldrons of gruesome fate
33515	unwavering legguards
33516	bracers of the ancient phalanx
33517	bonefist gauntlets
33518	high justicar s legplates
33519	handguards of the templar
33520	vambraces of the naaru
33522	chestguard of the stoic guardian
33523	sabatons of the righteous defender
33524	girdle of the protector
33527	shifting camouflage pants
33528	gauntlets of sniping
33529	steadying bracers
33530	natural life leggings
33531	polished waterscale gloves
33532	gleaming earthen bracers
33533	avalanche leggings
33534	grips of nature s wrath
33535	earthquake bracers
33536	stormwrap
33537	treads of booming thunder
33538	shallow grave trousers
33539	trickster s stickyfingers
33540	master assassin wristwraps
33542	shaman testing axe
33543	shaman testing dagger
33552	pants of splendid recovery
33557	gargon s bracers of peaceful slumber
33559	starfire waistband
33566	blessed elunite coverings
33570	temp dwarf loot 1
33572	temp dwarf loot 2
33573	temp dwarf loot 3
33574	temp dwarf loot 4
33577	moon walkers
33578	armwraps of the kaldorei protector
33579	vestments of hibernation
33580	band of the swift paw
33582	footwraps of wild encroachment
33583	waistguard of the great beast
33584	pantaloons of arcane annihilation
33585	achromic trousers of the naaru
33586	studious wraps
33587	light blessed bonds
33588	runed spell cuffs
33589	wristguards of tranquil thought
33590	cloak of fiends
33591	shadowcaster s drape
33592	cloak of ancient rituals
33593	slikk s cloak of placation
33600	temp troll loot 1
33601	temp troll loot 3
33602	temp troll loot 2
33603	temp troll loot 4
33622	design relentless earthstorm diamond
33623	temp orc loot 1
33624	temp orc loot 2
33625	temp orc loot 3
33626	temp orc loot 4
33633	forceful earthstorm diamond
33640	fury
33661	vengeful gladiator s barrier
33662	vengeful gladiator s bonecracker
33663	vengeful gladiator s bonegrinder
33664	vengeful gladiator s chain armor
33665	vengeful gladiator s chain gauntlets
33666	vengeful gladiator s chain helm
33667	vengeful gladiator s chain leggings
33668	vengeful gladiator s chain spaulders
33669	vengeful gladiator s cleaver
33670	vengeful gladiator s decapitator
33671	vengeful gladiator s dragonhide gloves
33672	vengeful gladiator s dragonhide helm
33673	vengeful gladiator s dragonhide legguards
33674	vengeful gladiator s dragonhide spaulders
33675	vengeful gladiator s dragonhide tunic
33676	vengeful gladiator s dreadweave gloves
33677	vengeful gladiator s dreadweave hood
33678	vengeful gladiator s dreadweave leggings
33679	vengeful gladiator s dreadweave mantle
33680	vengeful gladiator s dreadweave robe
33681	vengeful gladiator s endgame
33682	vengeful gladiator s felweave amice
33683	vengeful gladiator s felweave cowl
33684	vengeful gladiator s felweave handguards
33685	vengeful gladiator s felweave raiment
33686	vengeful gladiator s felweave trousers
33687	vengeful gladiator s gavel
33688	vengeful gladiator s greatsword
33689	vengeful gladiator s hacker
33690	vengeful gladiator s kodohide gloves
33691	vengeful gladiator s kodohide helm
33692	vengeful gladiator s kodohide legguards
33693	vengeful gladiator s kodohide spaulders
33694	vengeful gladiator s kodohide tunic
33695	vengeful gladiator s lamellar chestpiece
33696	vengeful gladiator s lamellar gauntlets
33697	vengeful gladiator s lamellar helm
33698	vengeful gladiator s lamellar legguards
33699	vengeful gladiator s lamellar shoulders
33700	vengeful gladiator s leather gloves
33701	vengeful gladiator s leather helm
33702	vengeful gladiator s leather legguards
33703	vengeful gladiator s leather spaulders
33704	vengeful gladiator s leather tunic
33705	vengeful gladiator s left ripper
33706	vengeful gladiator s linked armor
33707	vengeful gladiator s linked gauntlets
33708	vengeful gladiator s linked helm
33709	vengeful gladiator s linked leggings
33710	vengeful gladiator s linked spaulders
33711	vengeful gladiator s mail armor
33712	vengeful gladiator s mail gauntlets
33713	vengeful gladiator s mail helm
33714	vengeful gladiator s mail leggings
33715	vengeful gladiator s mail spaulders
33716	vengeful gladiator s staff
33717	vengeful gladiator s mooncloth gloves
33718	vengeful gladiator s mooncloth hood
33719	vengeful gladiator s mooncloth leggings
33720	vengeful gladiator s mooncloth mantle
33721	vengeful gladiator s mooncloth robe
33722	vengeful gladiator s ornamented chestguard
33723	vengeful gladiator s ornamented gloves
33724	vengeful gladiator s ornamented headcover
33725	vengeful gladiator s ornamented legplates
33726	vengeful gladiator s ornamented spaulders
33727	vengeful gladiator s painsaw
33728	vengeful gladiator s plate chestpiece
33729	vengeful gladiator s plate gauntlets
33730	vengeful gladiator s plate helm
33731	vengeful gladiator s plate legguards
33732	vengeful gladiator s plate shoulders
33733	vengeful gladiator s pummeler
33734	vengeful gladiator s quickblade
33735	vengeful gladiator s redoubt
33736	vengeful gladiator s reprieve
33737	vengeful gladiator s right ripper
33738	vengeful gladiator s ringmail armor
33739	vengeful gladiator s ringmail gauntlets
33740	vengeful gladiator s ringmail helm
33741	vengeful gladiator s ringmail leggings
33742	vengeful gladiator s ringmail spaulders
33743	vengeful gladiator s salvation
33744	vengeful gladiator s satin gloves
33745	vengeful gladiator s satin hood
33746	vengeful gladiator s satin leggings
33747	vengeful gladiator s satin mantle
33748	vengeful gladiator s satin robe
33749	vengeful gladiator s scaled chestpiece
33750	vengeful gladiator s scaled gauntlets
33751	vengeful gladiator s scaled helm
33752	vengeful gladiator s scaled legguards
33753	vengeful gladiator s scaled shoulders
33754	vengeful gladiator s shanker
33755	vengeful gladiator s shield wall
33756	vengeful gladiator s shiv
33757	vengeful gladiator s silk amice
33758	vengeful gladiator s silk cowl
33759	vengeful gladiator s silk handguards
33760	vengeful gladiator s silk raiment
33761	vengeful gladiator s silk trousers
33762	vengeful gladiator s slicer
33763	vengeful gladiator s spellblade
33764	vengeful gladiator s touch of defeat
33765	vengeful gladiator s war edge
33766	vengeful gladiator s war staff
33767	vengeful gladiator s wyrmhide gloves
33768	vengeful gladiator s wyrmhide helm
33769	vengeful gladiator s wyrmhide legguards
33770	vengeful gladiator s wyrmhide spaulders
33771	vengeful gladiator s wyrmhide tunic
33772	testing gladiator s lamellar shoulders
33782	steady talasite
33783	design steady talasite
33784	darkrune fragment
33785	temp gnome loot 1
33786	temp gnome loot 2
33787	temp gnome loot 3
33788	temp gnome loot 4
33791	heavy copper longsword
33792	plans heavy copper longsword
33797	portable brewfest keg
33801	vengeful gladiator s mutilator
33803	adamantite stinger
33804	schematic adamantite arrow maker
33805	shadowhunter s treads
33807	vazruden s horn
33808	the horseman s helm
33809	amani war bear
33810	amani mask of death
33811	vindicator s plate belt
33812	vindicator s plate greaves
33813	vindicator s plate bracers
33814	keli dan s feathered stave
33815	bladefist s seal
33816	toothy s bucket
33818	muckbreath s bucket
33820	weather beaten fishing hat
33821	the heart of quagmirran
33823	bloodfin catfish
33824	crescent tail skullfish
33825	skullfish soup
33826	black stalker egg
33827	the warlord s treatise
33828	tome of diabolic remedy
33829	hex shrunken head
33830	ancient aqir artifact
33831	berserker s call
33832	battlemaster s determination
33833	nazan s riding crop
33834	the headfeathers of ikiss
33835	shaffar s wondrous amulet
33836	the exarch s soul gem
33837	cooking pot
33838	giant kaliri wing
33839	kaliri stew
33840	murmur s whisper
33841	vengeful gladiator s idol of tenacity
33842	vengeful gladiator s libram of justice
33843	vengeful gladiator s totem of the third wind
33844	barrel of fish
33846	ruined fishing net
33847	epoch hunter s head
33848	demon broiled surprise
33849	mana berry
33850	spiritual soup
33851	cooking pot
33852	cooking pot
33853	vindicator s band of dominance
33854	unidentified eye
33855	tarnished silver ring
33856	list of goods
33857	crate of meat
33858	aeonus s hourglass
33859	warp splinter clipping
33860	pathaleon s projector
33861	the scroll of skyriss
33862	brewfest regalia
33863	brewfest dress
33864	brown brewfest hat
33865	amani hex stick
33866	stormchops
33867	broiled bloodfin
33868	brewfest boots
33869	recipe broiled bloodfin
33870	recipe skullfish soup
33871	recipe stormchops
33872	spicy hot talbuk
33873	recipe spicy hot talbuk
33874	kibler s bits
33875	recipe kibler s bits
33876	vindicator s chain bracers
33877	vindicator s chain girdle
33878	vindicator s chain sabatons
33879	vindicator s dragonhide belt
33880	vindicator s dragonhide boots
33881	vindicator s dragonhide bracers
33882	vindicator s dreadweave belt
33883	vindicator s dreadweave cuffs
33884	vindicator s dreadweave stalkers
33885	vindicator s kodohide belt
33886	vindicator s kodohide boots
33887	vindicator s kodohide bracers
33888	vindicator s lamellar belt
33889	vindicator s lamellar bracers
33890	vindicator s lamellar greaves
33891	vindicator s leather belt
33892	vindicator s leather boots
33893	vindicator s leather bracers
33894	vindicator s linked bracers
33895	vindicator s linked girdle
33896	vindicator s linked sabatons
33897	vindicator s mail bracers
33898	vindicator s mail girdle
33899	vindicator s mail sabatons
33900	vindicator s mooncloth belt
33901	vindicator s mooncloth cuffs
33902	vindicator s mooncloth slippers
33903	vindicator s ornamented belt
33904	vindicator s ornamented bracers
33905	vindicator s ornamented greaves
33906	vindicator s ringmail bracers
33907	vindicator s ringmail girdle
33908	vindicator s ringmail sabatons
33909	vindicator s scaled belt
33910	vindicator s scaled bracers
33911	vindicator s scaled greaves
33912	vindicator s silk belt
33913	vindicator s silk cuffs
33914	vindicator s silk footguards
33915	vindicator s wyrmhide belt
33916	vindicator s wyrmhide boots
33917	vindicator s wyrmhide bracers
33918	vindicator s band of salvation
33919	vindicator s band of triumph
33920	vindicator s pendant of conquest
33921	vindicator s pendant of dominance
33922	vindicator s pendant of salvation
33923	vindicator s pendant of triumph
33924	delicious chocolate cake
33925	recipe delicious chocolate cake
33926	sealed scroll case
33927	brewfest pony keg
33928	hollowed bone decanter
33929	brewfest brew
33930	amani charm of the bloodletter
33931	amani charm of mighty mojo
33932	amani charm of the witch doctor
33933	amani charm of the raging defender
33934	crystal healing potion
33935	crystal mana potion
33936	gladiator s libram of fortitude
33937	merciless gladiator s libram of fortitude
33938	vengeful gladiator s libram of fortitude
33939	gladiator s totem of indomitability
33940	merciless gladiator s totem of indomitability
33941	vengeful gladiator s totem of indomitability
33942	gladiator s idol of steadfastness
33943	merciless gladiator s idol of steadfastness
33944	vengeful gladiator s idol of steadfastness
33945	gladiator s idol of resolve
33946	merciless gladiator s idol of resolve
33947	vengeful gladiator s idol of resolve
33948	gladiator s libram of vengeance
33949	merciless gladiator s libram of vengeance
33950	vengeful gladiator s libram of vengeance
33951	gladiator s totem of survival
33952	merciless gladiator s totem of survival
33953	vengeful gladiator s totem of survival
33954	plans hammer of righteous might
33955	brewfest stein voucher
33956	harkor s home brew
33957	witches band
33958	the horseman s signet ring
33959	ring of ghoulish delight
33964	helm of the stormcaller
33965	hauberk of the furious elements
33966	brewfest slippers
33967	green brewfest hat
33968	blue brewfest hat
33969	purple brewfest hat
33970	pauldrons of the furious elements
33971	elunite imbued leggings
33972	mask of primal power
33973	pauldrons of tribal fury
33974	grasp of the moonkin
33976	brewfest ram
33977	swift brewfest ram
33978	honorary brewer hand stamp
33985	dreary candle
33986	indalamar s ring of 200 crit
33987	indalamar s ring of 200 spell crit
33988	indalamar s ring of 200 haste
33989	indalamar s ring of 200 spell haste
33993	mojo
33995	indalamar s ring of healer ownage
33996	indalamar s ring of 234 spell damage
33997	indalamar s ring of 400 attack power
33998	indalamar s ring of 1400 armor penetration
33999	cenarion war hippogryph
34000	flimsy female blood elf mask
34001	flimsy female draenei mask
34002	flimsy male blood elf mask
34003	flimsy male draenei mask
34008	blix s eyesight enhancing romance goggles
34009	hammer of judgement
34010	pepe s shroud of pacification
34011	illidari runeshield
34012	shroud of the final stand
34014	vengeful gladiator s waraxe
34015	vengeful gladiator s chopper
34016	vengeful gladiator s left render
34017	small step brew
34018	long stride brew
34019	path of brew
34020	jungle river water
34021	brewdoo magic
34022	stout shrunken head
34028	honorary brewer hand stamp
34029	tiny voodoo mask
34033	vengeful gladiator s grimoire
34039	bow of unusual slowness
34044	b ball
34046	skill catch
34047	skill sprint
34048	skill tackle
34049	battlemaster s audacity
34050	battlemaster s perseverance
34059	vengeful gladiator s baton of light
34060	flying machine control
34061	turbo charged flying machine control
34062	conjured manna biscuit
34063	dried sausage
34064	succulent sausage
34065	spiced onion cheese
34066	vengeful gladiator s piercing touch
34067	tattered hexcloth sack
34068	weighted jack o lantern
34071	bunch of jack o lanterns
34073	the horseman s signet ring
34074	witches band
34075	ring of ghoulish delight
34077	smashed pumpkin loot
34085	red winter clothes
34086	winter boots
34087	green winter clothes
34089	alicia s poem
34092	merciless nether drake
34094	indalamar s ring of 200 attack power
34095	indalamar s ring of 200 hit rating
34099	knothide ammo pouch
34100	knothide quiver
34105	quiver of a thousand feathers
34106	netherscale ammo pouch
34107	tattered shoulderpads
34109	weather beaten journal
34113	field repair bot 110g
34114	schematic field repair bot 110g
34129	swift warstrider
34130	recovery diver s potion
34140	dark iron tankard
34141	dark iron ale keg
34151	player draenei tauren
34152	player dwarf orc
34153	player gnome blood elf
34154	player human undead
34155	player troll night elf
34156	blb kit
34157	head of kael thas
34158	team a tabard
34159	team b tabard
34160	the signet ring of prince kael thas
34161	kael s standard
34162	battlemaster s depravity
34163	battlemaster s cruelty
34164	dragonscale encrusted longblade
34165	fang of kalecgos
34166	band of lucent beams
34167	legplates of the holy juggernaut
34168	starstalker legguards
34169	breeches of natural aggression
34170	pantaloons of calming strife
34171	winter stationery
34172	pattern drums of speed
34173	pattern drums of speed
34174	pattern drums of restoration
34175	pattern drums of restoration
34176	reign of misery
34177	clutch of demise
34178	collar of the pit lord
34179	heart of the pit
34180	felfury legplates
34181	leggings of calamity
34182	grand magister s staff of torrents
34183	shivering felspine
34184	brooch of the highborne
34185	sword breaker s bulwark
34186	chain links of the tumultuous storm
34188	leggings of the immortal night
34189	band of ruinous delight
34190	crimson paragon s cover
34191	handful of snowflakes
34192	pauldrons of perseverance
34193	spaulders of the thalassian savior
34194	mantle of the golden forest
34195	shoulderpads of vehemence
34196	golden bow of quel thalas
34197	shiv of exsanguination
34198	stanchion of primal instinct
34199	archon s gavel
34200	pattern quiver of a thousand feathers
34201	pattern netherscale ammo pouch
34202	shawl of wonderment
34203	grip of mannoroth
34204	amulet of unfettered magics
34205	shroud of redeemed souls
34206	book of highborne hymns
34207	glove reinforcements
34208	equilibrium epaulets
34209	spaulders of reclamation
34210	amice of the convoker
34211	harness of carnal instinct
34212	sunglow vest
34213	ring of hardened resolve
34214	muramasa
34215	warharness of reckless fury
34216	heroic judicator s chestguard
34218	pattern netherscale ammo pouch
34220	chaotic skyfire diamond
34221	design chaotic skyfire diamond
34227	deadman s hand
34228	vicious hawkstrider hauberk
34229	garments of serene shores
34230	ring of omnipotence
34231	aegis of angelic fortune
34232	fel conquerer raiments
34233	robes of faltered light
34234	shadowed gauntlets of paroxysm
34240	gauntlets of the soothed soul
34241	cloak of unforgivable sin
34242	tattered cape of antonidas
34243	helm of burning righteousness
34244	duplicitous guise
34245	cover of ursol the wise
34246	smuggled mana cell
34247	apolyon the soul render
34248	bash ir phasing device
34249	hula girl doll
34250	skill throw bullet
34251	skill throw
34252	skill juke
34253	sizzling embers
34254	razorthorn root
34255	razorthorn flayer gland
34256	charmed amani jewel
34257	fel siphon
34258	love rocket
34259	demonic blood
34261	pattern green winter clothes
34262	pattern winter boots
34319	pattern red winter clothes
34329	crux of the apocalypse
34330	heavy knothide armor kit
34331	hand of the deceiver
34332	cowl of gul dan
34333	coif of alleria
34334	thori dal the stars fury
34335	hammer of sanctification
34336	sunflare
34337	golden staff of the sin dorei
34338	mana remnants
34339	cowl of light s purity
34340	dark conjuror s collar
34341	borderland paingrips
34342	handguards of the dawn
34343	thalassian ranger gauntlets
34344	handguards of defiled worlds
34345	crown of anasterian
34346	mounting vengeance
34347	wand of the demonsoul
34348	wand of cleansing light
34349	blade of life s inevitability
34350	gauntlets of the ancient shadowmoon
34351	tranquil majesty wraps
34352	borderland fortress grips
34353	quad deathblow x44 goggles
34354	mayhem projection goggles
34355	lightning etched specs
34356	surestrike goggles v3 0
34357	hard khorium goggles
34358	hard khorium choker
34359	pendant of sunfire
34360	amulet of flowing life
34361	hard khorium band
34362	loop of forged power
34363	ring of flowing life
34364	sunfire robe
34365	robe of eternal light
34366	sunfire handwraps
34367	hands of eternal light
34368	attuned crystal cores
34369	carapace of sun and shadow
34370	gloves of immortal dusk
34371	leather chestguard of the sun
34372	leather gauntlets of the sun
34373	embrace of the phoenix
34374	fletcher s gloves of the phoenix
34375	sun drenched scale chestguard
34376	sun drenched scale gloves
34377	hard khorium battleplate
34378	hard khorium battlefists
34379	sunblessed breastplate
34380	sunblessed gauntlets
34381	felstrength legplates
34382	judicator s legguards
34383	kilt of spiritual reconstruction
34384	breeches of natural splendor
34385	leggings of the immortal beast
34386	pantaloons of growing strife
34388	pauldrons of berserking
34389	spaulders of the thalassian defender
34390	erupting epaulets
34391	spaulders of devastation
34392	demontooth shoulderpads
34393	shoulderpads of knowledge s pursuit
34394	breastplate of agony s aversion
34395	noble judicator s chestguard
34396	garments of crashing shores
34397	bladed chaos tunic
34398	utopian tunic of elune
34399	robes of ghostly hatred
34400	crown of dath remar
34401	helm of uther s resolve
34402	shroud of chieftain ner zhul
34403	cover of ursoc the mighty
34404	mask of the fury hunter
34405	helm of arcane purity
34406	gloves of tyri s power
34407	tranquil moonlight wraps
34408	gloves of the forest drifter
34409	gauntlets of the ancient frostwolf
34410	honeyed holiday ham
34411	hot apple cider
34412	sparkling apple cider
34413	recipe hot apple cider
34414	shattered sun banner
34415	crystaline shard shield
34416	gloves of the dune
34417	marauder s handwraps
34418	scrying wand
34419	thorium flight blade
34420	captured legion scroll
34421	cave crawler s mail treads
34422	tempered thorium boots
34423	strength of the high chief
34424	power of the high chief
34425	clockwork rocket bot
34426	winter veil gift
34427	blackened naaru sliver
34428	steely naaru sliver
34429	shifting naaru sliver
34430	glimmering naaru sliver
34431	lightbringer bands
34432	lightbringer bracers
34433	lightbringer wristguards
34434	bracers of absolution
34435	cuffs of absolution
34436	bracers of the malefic
34437	skyshatter bands
34438	skyshatter bracers
34439	skyshatter wristguards
34440	mad alchemist s potion
34441	onslaught bracers
34442	onslaught wristguards
34443	gronnstalker s bracers
34444	thunderheart wristguards
34445	thunderheart bracers
34446	thunderheart bands
34447	bracers of the tempest
34448	slayer s bracers
34469	strange engine part
34470	timbal s focusing crystal
34471	vial of the sunwell
34472	shard of contempt
34473	commendation of kael thas
34474	strange engine part
34475	arcane charges
34476	broken engine part
34477	darkspine chest key
34478	tiny sporebat
34479	darkspine iron ore
34480	romantic picnic basket
34481	recipe mad alchemist s potion
34482	leatherworker s satchel
34483	orb of murloc control
34485	lightbringer girdle
34487	lightbringer belt
34488	lightbringer waistguard
34489	flaming oil
34490	bag of many hides
34491	pattern bag of many hides
34492	rocket chicken
34493	dragon kite
34494	paper zeppelin
34496	upper deck paper airplane book
34497	paper flying machine
34498	paper zeppelin kit
34499	paper flying machine kit
34500	ata mal armament
34501	cleansed ata mal metal
34502	bloodberry
34503	box of adamantite shells
34504	adamantite shell machine
34518	golden pig coin
34519	silver pig coin
34527	belt of absolution
34528	cord of absolution
34529	vengeful gladiator s longbow
34530	vengeful gladiator s rifle
34533	astromancer s crystal
34535	azure whelpling
34537	bloodberry elixir
34538	blessed weapon coating
34539	righteous weapon coating
34540	vengeful gladiator s battle staff
34541	belt of the malefic
34542	skyshatter cord
34543	skyshatter belt
34544	essence of the immortals
34545	skyshatter girdle
34546	onslaught belt
34547	onslaught waistguard
34548	cache of the shattered sun
34549	gronnstalker s belt
34550	indalamar s ring of 200 spirit
34551	indalamar s ring of 80 mp5
34554	thunderheart belt
34555	thunderheart cord
34556	thunderheart waistguard
34557	belt of the tempest
34558	slayer s belt
34559	lightbringer treads
34560	lightbringer stompers
34561	lightbringer boots
34562	boots of absolution
34563	treads of absolution
34564	boots of the malefic
34565	skyshatter boots
34566	skyshatter treads
34567	skyshatter greaves
34568	onslaught boots
34569	onslaught treads
34570	gronnstalker s boots
34571	thunderheart boots
34572	thunderheart footwraps
34573	thunderheart treads
34574	boots of the tempest
34575	slayer s boots
34576	battlemaster s cruelty
34577	battlemaster s depravity
34578	battlemaster s determination
34579	battlemaster s audacity
34580	battlemaster s perseverance
34581	mysterious arrow
34582	mysterious shell
34583	aldor supplies package
34584	scryer supplies package
34585	scryer supplies package
34587	aldor supplies package
34592	aldor supplies package
34593	scryer supplies package
34594	scryer supplies package
34595	aldor supplies package
34599	juggling torch
34601	shoulderplates of everlasting pain
34602	eversong cuffs
34603	distracting blades
34604	jaded crystal dagger
34605	breastplate of fierce survival
34606	edge of oppression
34607	fel tinged mantle
34608	rod of the blazing light
34609	quickening blade of the prince
34610	scarlet sin dorei robes
34611	cudgel of consecration
34612	greaves of the penitent knight
34613	shoulderpads of the silvermoon retainer
34614	tunic of the ranger lord
34615	netherforce chestplate
34616	breeching comet
34622	spinesever
34625	kharmaa s ring of fate
34626	prototype tonk controller
34627	heavy tonk armor
34664	sunmote
34665	bombardier s blade
34666	the sunbreaker
34667	archmage s guile
34670	seeker s gavel
34671	k iru s presage
34672	inuuro s blade
34673	legionfoe
34674	truestrike crossbow
34675	sunward crest
34676	dawnforged defender
34677	shattered sun pendant of restoration
34678	shattered sun pendant of acumen
34679	shattered sun pendant of might
34680	shattered sun pendant of resolve
34683	sandals of summer
34684	handful of summer petals
34685	vestment of summer
34686	brazier of dancing flames
34689	design chaotic skyfire diamond
34697	bindings of raging fire
34698	bracers of the forest stalker
34699	sun forged cleaver
34700	gauntlets of divine blessings
34701	leggings of the betrayed
34702	cloak of swift mending
34703	latro s dancing blade
34704	band of arcane alacrity
34705	bracers of divine infusion
34706	band of determination
34707	boots of resuscitation
34708	cloak of the coming night
34712	prismatic signet
34780	naaru ration
34783	nightstrike
34788	duskhallow mantle
34789	bracers of slaughter
34790	battle mace of the high priestess
34791	gauntlets of the tranquil waves
34792	cloak of the betrayed
34793	cord of reconstruction
34794	axe of shattered dreams
34795	helm of sanctification
34796	robes of summer flame
34797	sun infused focus staff
34798	band of celerity
34799	hauberk of the war bringer
34807	sunstrider warboots
34808	gloves of arcane acuity
34809	sunrage treads
34810	cloak of blade turning
34822	ancient coin
34823	beautiful glass eye
34824	silver statuette
34825	mithril shaving razor
34826	gold wedding band
34827	noble s monocle
34828	antique silver cufflinks
34829	ornate drinking stein
34831	eye of the sea
34832	captain rumsey s lager
34833	unlit torches
34834	recipe captain rumsey s lager
34836	spun truesilver fishing line
34837	the 2 ring
34838	mariner s log
34839	piece of polished driftwood
34840	broken spyglass
34841	salvaged scrap metal
34843	giant shark tooth
34845	pit lord s satchel
34846	black sack of gems
34847	annihilator holo gogs
34848	bracers of the forgotten conqueror
34850	midsummer ground flower
34851	bracers of the forgotten protector
34852	bracers of the forgotten vanquisher
34853	belt of the forgotten conqueror
34854	belt of the forgotten protector
34855	belt of the forgotten vanquisher
34856	boots of the forgotten conqueror
34857	boots of the forgotten protector
34858	boots of the forgotten vanquisher
34859	razor sharp fillet knife
34860	rusted lock
34861	sharpened fish hook
34862	practice torches
34863	bag of fishing treasures
34864	baby crocolisk
34865	blackfin darter
34866	giant freshwater shrimp
34867	monstrous felblood snapper
34868	world s largest mudfish
34872	formula void shatter
34887	angelista s revenge
34888	ring of the stalwart protector
34889	fused nethergon band
34890	anveena s touch
34891	the blade of harbingers
34892	crossbow of relentless strikes
34893	vanir s right fist of brutality
34894	blade of serration
34895	scryer s blade of focus
34896	gavel of naaru blessings
34898	staff of the forest lord
34900	shroud of nature s harmony
34901	grovewalker s leggings
34902	oakleaf spun handguards
34903	embrace of starlight
34904	barbed gloves of the sage
34905	crystalwind leggings
34906	embrace of everlasting prowess
34907	shattered gem fragments
34910	tameless breeches
34911	handwraps of the aggressor
34912	scaled drakeskin chestguard
34914	leggings of the pursuit
34916	gauntlets of rapidity
34917	shroud of the lore`nial
34918	legwraps of sweltering flame
34919	boots of incantations
34921	ecclesiastical cuirass
34922	greaves of pacification
34923	waistguard of reparation
34924	gown of spiritual wonder
34925	adorned supernal legwraps
34926	slippers of dutiful mending
34927	tunic of the dark hour
34928	trousers of the scryers retainer
34929	belt of the silent path
34930	wave of life chestguard
34931	runed scales of antiquity
34932	clutch of the soothing breeze
34933	hauberk of whirling fury
34934	rushing storm kilt
34935	aftershock waistguard
34936	tormented demonsoul robes
34937	corrupted soulcloth pantaloons
34938	enslaved doomguard soulgrips
34939	chestplate of stoicism
34940	sunguard legplates
34941	girdle of the fearless
34942	breastplate of ire
34943	legplates of unending fury
34944	girdle of seething rage
34945	shattrath protectorate s breastplate
34946	inscribed legplates of the aldor
34947	blue s greaves of the righteous guardian
34949	swift blade of uncertainty
34950	vanir s left fist of savagery
34951	vanir s left fist of brutality
34952	the mutilator
34953	earthen ring magma totem
34955	scorched stone
34985	brutal gladiator s baton of light
34986	brutal gladiator s barrier
34987	brutal gladiator s battle staff
34988	brutal gladiator s bonecracker
34989	brutal gladiator s bonegrinder
34990	brutal gladiator s chain armor
34991	brutal gladiator s chain gauntlets
34992	brutal gladiator s chain helm
34993	brutal gladiator s chain leggings
34994	brutal gladiator s chain spaulders
34995	brutal gladiator s chopper
34996	brutal gladiator s cleaver
34997	brutal gladiator s decapitator
34998	brutal gladiator s dragonhide gloves
34999	brutal gladiator s dragonhide helm
35000	brutal gladiator s dragonhide legguards
35001	brutal gladiator s dragonhide spaulders
35002	brutal gladiator s dragonhide tunic
35003	brutal gladiator s dreadweave gloves
35004	brutal gladiator s dreadweave hood
35005	brutal gladiator s dreadweave leggings
35006	brutal gladiator s dreadweave mantle
35007	brutal gladiator s dreadweave robe
35008	brutal gladiator s endgame
35009	brutal gladiator s felweave amice
35010	brutal gladiator s felweave cowl
35011	brutal gladiator s felweave handguards
35012	brutal gladiator s felweave raiment
35013	brutal gladiator s felweave trousers
35014	brutal gladiator s gavel
35015	brutal gladiator s greatsword
35016	brutal gladiator s grimoire
35017	brutal gladiator s hacker
35018	brutal gladiator s heavy crossbow
35019	brutal gladiator s idol of resolve
35020	brutal gladiator s idol of steadfastness
35021	brutal gladiator s idol of tenacity
35022	brutal gladiator s kodohide gloves
35023	brutal gladiator s kodohide helm
35024	brutal gladiator s kodohide legguards
35025	brutal gladiator s kodohide spaulders
35026	brutal gladiator s kodohide tunic
35027	brutal gladiator s lamellar chestpiece
35028	brutal gladiator s lamellar gauntlets
35029	brutal gladiator s lamellar helm
35030	brutal gladiator s lamellar legguards
35031	brutal gladiator s lamellar shoulders
35032	brutal gladiator s leather gloves
35033	brutal gladiator s leather helm
35034	brutal gladiator s leather legguards
35035	brutal gladiator s leather spaulders
35036	brutal gladiator s leather tunic
35037	brutal gladiator s left render
35038	brutal gladiator s left ripper
35039	brutal gladiator s libram of fortitude
35040	brutal gladiator s libram of justice
35041	brutal gladiator s libram of vengeance
35042	brutal gladiator s linked armor
35043	brutal gladiator s linked gauntlets
35044	brutal gladiator s linked helm
35045	brutal gladiator s linked leggings
35046	brutal gladiator s linked spaulders
35047	brutal gladiator s longbow
35048	brutal gladiator s mail armor
35049	brutal gladiator s mail gauntlets
35050	brutal gladiator s mail helm
35051	brutal gladiator s mail leggings
35052	brutal gladiator s mail spaulders
35053	brutal gladiator s mooncloth gloves
35054	brutal gladiator s mooncloth hood
35055	brutal gladiator s mooncloth leggings
35056	brutal gladiator s mooncloth mantle
35057	brutal gladiator s mooncloth robe
35058	brutal gladiator s mutilator
35059	brutal gladiator s ornamented chestguard
35060	brutal gladiator s ornamented gloves
35061	brutal gladiator s ornamented headcover
35062	brutal gladiator s ornamented legplates
35063	brutal gladiator s ornamented spaulders
35064	brutal gladiator s painsaw
35065	brutal gladiator s piercing touch
35066	brutal gladiator s plate chestpiece
35067	brutal gladiator s plate gauntlets
35068	brutal gladiator s plate helm
35069	brutal gladiator s plate legguards
35070	brutal gladiator s plate shoulders
35071	brutal gladiator s pummeler
35072	brutal gladiator s quickblade
35073	brutal gladiator s redoubt
35074	brutal gladiator s reprieve
35075	brutal gladiator s rifle
35076	brutal gladiator s right ripper
35077	brutal gladiator s ringmail armor
35078	brutal gladiator s ringmail gauntlets
35079	brutal gladiator s ringmail helm
35080	brutal gladiator s ringmail leggings
35081	brutal gladiator s ringmail spaulders
35082	brutal gladiator s salvation
35083	brutal gladiator s satin gloves
35084	brutal gladiator s satin hood
35085	brutal gladiator s satin leggings
35086	brutal gladiator s satin mantle
35087	brutal gladiator s satin robe
35088	brutal gladiator s scaled chestpiece
35089	brutal gladiator s scaled gauntlets
35090	brutal gladiator s scaled helm
35091	brutal gladiator s scaled legguards
35092	brutal gladiator s scaled shoulders
35093	brutal gladiator s shanker
35094	brutal gladiator s shield wall
35095	brutal gladiator s shiv
35096	brutal gladiator s silk amice
35097	brutal gladiator s silk cowl
35098	brutal gladiator s silk handguards
35099	brutal gladiator s silk raiment
35100	brutal gladiator s silk trousers
35101	brutal gladiator s slicer
35102	brutal gladiator s spellblade
35103	brutal gladiator s staff
35104	brutal gladiator s totem of indomitability
35105	brutal gladiator s totem of survival
35106	brutal gladiator s totem of the third wind
35107	brutal gladiator s touch of defeat
35108	brutal gladiator s war edge
35109	brutal gladiator s war staff
35110	brutal gladiator s waraxe
35111	brutal gladiator s wyrmhide gloves
35112	brutal gladiator s wyrmhide helm
35113	brutal gladiator s wyrmhide legguards
35114	brutal gladiator s wyrmhide spaulders
35115	brutal gladiator s wyrmhide tunic
35128	hardened khorium
35129	guardian s band of dominance
35130	guardian s band of salvation
35131	guardian s band of triumph
35132	guardian s pendant of conquest
35133	guardian s pendant of dominance
35134	guardian s pendant of salvation
35135	guardian s pendant of triumph
35136	guardian s chain sabatons
35137	guardian s dragonhide boots
35138	guardian s dreadweave stalkers
35139	guardian s kodohide boots
35140	guardian s lamellar greaves
35141	guardian s leather boots
35142	guardian s linked sabatons
35143	guardian s mail sabatons
35144	guardian s mooncloth slippers
35145	guardian s ornamented greaves
35146	guardian s plate greaves
35147	guardian s ringmail sabatons
35148	guardian s scaled greaves
35149	guardian s silk footguards
35150	guardian s wyrmhide boots
35151	guardian s chain girdle
35152	guardian s dragonhide belt
35153	guardian s dreadweave belt
35154	guardian s kodohide belt
35155	guardian s lamellar belt
35156	guardian s leather belt
35157	guardian s linked girdle
35158	guardian s mail girdle
35159	guardian s mooncloth belt
35160	guardian s ornamented belt
35161	guardian s plate belt
35162	guardian s ringmail girdle
35163	guardian s scaled belt
35164	guardian s silk belt
35165	guardian s wyrmhide belt
35166	guardian s chain bracers
35167	guardian s dragonhide bracers
35168	guardian s dreadweave cuffs
35169	guardian s kodohide bracers
35170	guardian s lamellar bracers
35171	guardian s leather bracers
35172	guardian s linked bracers
35173	guardian s mail bracers
35174	guardian s mooncloth cuffs
35175	guardian s ornamented bracers
35176	guardian s plate bracers
35177	guardian s ringmail bracers
35178	guardian s scaled bracers
35179	guardian s silk cuffs
35180	guardian s wyrmhide bracers
35181	powerheal 9000 lens
35182	hyper magnified moon specs
35183	wonderheal xt68 shades
35184	primal attuned goggles
35185	justicebringer 3000 specs
35186	schematic annihilator holo gogs
35187	schematic justicebringer 3000 specs
35189	schematic powerheal 9000 lens
35190	schematic hyper magnified moon specs
35191	schematic wonderheal xt68 shades
35192	schematic primal attuned goggles
35193	schematic lightning etched specs
35194	schematic surestrike goggles v3 0
35195	schematic mayhem projection goggles
35196	schematic hard khorium goggles
35197	schematic quad deathblow x44 goggles
35198	design loop of forged power
35199	design ring of flowing life
35200	design hard khorium band
35201	design pendant of sunfire
35202	design amulet of flowing life
35203	design hard khorium choker
35204	pattern sunfire handwraps
35205	pattern hands of eternal light
35206	pattern sunfire robe
35207	pattern robe of eternal light
35208	plans sunblessed gauntlets
35209	plans hard khorium battlefists
35210	plans sunblessed breastplate
35211	plans hard khorium battleplate
35212	pattern leather gauntlets of the sun
35213	pattern fletcher s gloves of the phoenix
35214	pattern gloves of immortal dusk
35215	pattern sun drenched scale gloves
35216	pattern leather chestguard of the sun
35217	pattern embrace of the phoenix
35218	pattern carapace of sun and shadow
35219	pattern sun drenched scale chestguard
35221	tabard of the shattered sun
35225	x 51 nether rocket
35226	x 51 nether rocket x treme
35227	goblin weather machine prototype 01 b
35229	nether residue
35230	darnarian s scroll of teleportation
35231	sunfury attack plans
35232	shattered sun supplies
35233	multiphase spectrographic goggles
35237	orb of the crawler
35238	design balanced shadowsong amethyst
35239	design glowing shadowsong amethyst
35240	design infused shadowsong amethyst
35241	design royal shadowsong amethyst
35242	design shifting shadowsong amethyst
35243	design sovereign shadowsong amethyst
35244	design bold crimson spinel
35245	design bright crimson spinel
35246	design delicate crimson spinel
35247	design flashing crimson spinel
35248	design runed crimson spinel
35249	design subtle crimson spinel
35250	design teardrop crimson spinel
35251	design dazzling seaspray emerald
35252	design enduring seaspray emerald
35253	design jagged seaspray emerald
35254	design radiant seaspray emerald
35255	design brilliant lionseye
35256	design gleaming lionseye
35257	design great lionseye
35258	design mystic lionseye
35259	design rigid lionseye
35260	design smooth lionseye
35261	design thick lionseye
35262	design lustrous empyrean sapphire
35263	design solid empyrean sapphire
35264	design sparkling empyrean sapphire
35265	design stormy empyrean sapphire
35266	design glinting pyrestone
35267	design inscribed pyrestone
35268	design luminous pyrestone
35269	design potent pyrestone
35270	design veiled pyrestone
35271	design wicked pyrestone
35273	study of advanced smelting
35275	orb of the sin dorei
35277	twilight correspondence
35279	tabard of summer skies
35280	tabard of summer flames
35282	sin dorei band of dominance
35283	sin dorei band of salvation
35284	sin dorei band of triumph
35285	giant sunfish
35286	bloated giant sunfish
35287	luminous bluetail
35290	sin dorei pendant of conquest
35291	sin dorei pendant of salvation
35292	sin dorei pendant of triumph
35294	recipe elixir of empowerment
35295	recipe haste potion
35296	plans adamantite weapon chain
35297	formula enchant boots boar s speed
35298	formula enchant boots vitality
35299	formula enchant boots cat s swiftness
35300	pattern windstrike gloves
35301	pattern netherdrake gloves
35302	pattern cobrascale gloves
35303	pattern gloves of the living touch
35304	design solid star of elune
35305	design runed living ruby
35306	design bright living ruby
35307	design rigid dawnstone
35308	pattern unyielding bracers
35309	pattern unyielding girdle
35310	schematic healing potion injector
35311	schematic mana potion injector
35313	bloated barbed gill trout
35314	partially digested weeds
35315	quick dawnstone
35316	reckless noble topaz
35317	vindicator s pendant of reprieve
35318	forceful talasite
35319	vindicator s pendant of subjugation
35320	vindicator s band of subjugation
35321	cloak of arcane alacrity
35322	design quick dawnstone
35323	design reckless noble topaz
35324	cloak of swift reprieve
35325	design forceful talasite
35326	battlemaster s alacrity
35327	battlemaster s alacrity
35328	dreadweave gloves
35329	dreadweave hood
35330	dreadweave leggings
35331	dreadweave mantle
35332	dreadweave robe
35333	mooncloth cowl
35334	mooncloth legguards
35335	mooncloth mitts
35336	mooncloth shoulderpads
35337	mooncloth vestments
35338	satin gloves
35339	satin hood
35340	satin leggings
35341	satin mantle
35342	satin robe
35343	evoker s silk amice
35344	evoker s silk cowl
35345	evoker s silk handguards
35346	evoker s silk raiment
35347	evoker s silk trousers
35348	bag of fishing treasures
35349	snarly s bucket
35350	chuck s bucket
35356	dragonhide gloves
35357	dragonhide helm
35358	dragonhide legguards
35359	dragonhide spaulders
35360	dragonhide robe
35361	kodohide gloves
35362	kodohide helm
35363	kodohide legguards
35364	kodohide spaulders
35365	kodohide robe
35366	opportunist s leather gloves
35367	opportunist s leather helm
35368	opportunist s leather legguards
35369	opportunist s leather spaulders
35370	opportunist s leather tunic
35371	wyrmhide gloves
35372	wyrmhide helm
35373	wyrmhide legguards
35374	wyrmhide spaulders
35375	wyrmhide robe
35376	stalker s chain armor
35377	stalker s chain gauntlets
35378	stalker s chain helm
35379	stalker s chain leggings
35380	stalker s chain spaulders
35381	seer s linked armor
35382	seer s linked gauntlets
35383	seer s linked helm
35384	seer s linked leggings
35385	seer s linked spaulders
35386	seer s mail armor
35387	seer s mail gauntlets
35388	seer s mail helm
35389	seer s mail leggings
35390	seer s mail spaulders
35391	seer s ringmail chestguard
35392	seer s ringmail gloves
35393	seer s ringmail headpiece
35394	seer s ringmail legguards
35395	seer s ringmail shoulderpads
35396	enchant 2h weapon major agility
35397	enchant 2h weapon savagery
35398	enchant boots boar s speed
35399	enchant boots cat s swiftness
35400	enchant boots dexterity
35402	crusader s ornamented chestplate
35403	crusader s ornamented gloves
35404	crusader s ornamented headguard
35405	crusader s ornamented leggings
35406	crusader s ornamented spaulders
35407	savage plate chestpiece
35408	savage plate gauntlets
35409	savage plate helm
35410	savage plate legguards
35411	savage plate shoulders
35412	crusader s scaled chestpiece
35413	crusader s scaled gauntlets
35414	crusader s scaled helm
35415	crusader s scaled legguards
35416	crusader s scaled shoulders
35417	enchant boots fortitude
35418	enchant boots surefooted
35419	enchant boots vitality
35420	enchant bracer brawn
35421	enchant bracer fortitude
35422	enchant bracer major defense
35423	enchant bracer major intellect
35424	enchant bracer restore mana prime
35425	enchant bracer spellpower
35426	enchant bracer stats
35427	enchant bracer superior healing
35428	enchant chest exceptional health
35429	enchant chest exceptional stats
35430	enchant chest major resilience
35431	enchant chest major spirit
35432	enchant cloak greater agility
35433	enchant cloak greater arcane resistance
35434	enchant cloak greater shadow resistance
35435	enchant cloak major resistance
35436	enchant cloak spell penetration
35437	enchant cloak major armor
35438	enchant gloves assault
35439	enchant gloves blasting
35440	enchant gloves major healing
35441	enchant gloves major spellpower
35442	enchant gloves major strength
35443	enchant gloves spell strike
35444	enchant ring healing power
35445	enchant ring spellpower
35446	enchant ring stats
35447	enchant ring striking
35448	enchant shield intellect
35449	enchant shield major stamina
35450	enchant shield resistance
35451	enchant shield shield block
35452	enchant weapon battlemaster
35453	enchant weapon greater agility
35454	enchant weapon major healing
35455	enchant weapon major intellect
35456	enchant weapon major spellpower
35457	enchant weapon major striking
35458	enchant weapon mongoose
35459	enchant weapon potency
35460	enchant weapon soulfrost
35461	enchant weapon spellsurge
35462	enchant weapon sunfire
35464	dreadweave robe
35465	evoker s silk amice
35466	satin hood
35467	mooncloth vestments
35468	opportunist s leather gloves
35469	dragonhide robe
35470	kodohide spaulders
35471	wyrmhide gloves
35472	seer s mail armor
35473	seer s ringmail gloves
35474	seer s linked helm
35475	stalker s chain gauntlets
35476	crusader s ornamented spaulders
35477	crusader s scaled gauntlets
35478	savage plate helm
35487	bright crimson spinel
35488	runed crimson spinel
35489	teardrop crimson spinel
35494	shroud of winter s chill
35495	the frost lord s war cloak
35496	icebound cloak
35497	cloak of the frigid winds
35498	formula enchant weapon deathfrost
35500	formula enchant chest defense
35501	eternal earthstorm diamond
35502	design eternal earthstorm diamond
35503	ember skyfire diamond
35504	phoenix hatchling
35505	design ember skyfire diamond
35507	amulet of bitter hatred
35508	choker of the arctic flow
35509	amulet of glacial tranquility
35511	hailstone pendant
35512	pocket full of snow
35513	swift white hawkstrider
35514	frostscythe of lord ahune
35516	sun touched satchel
35517	pattern bindings of lightning reflexes
35518	pattern bracers of nimble thought
35519	pattern bracers of renewed life
35520	pattern living earth bindings
35521	pattern living earth shoulders
35522	pattern mantle of nimble thought
35523	pattern shoulderpads of renewed life
35524	pattern shoulders of lightning reflexes
35525	pattern swiftheal mantle
35526	pattern swiftheal wraps
35527	pattern swiftstrike bracers
35528	pattern swiftstrike shoulders
35529	plans dawnsteel bracers
35530	plans dawnsteel shoulders
35531	plans swiftsteel bracers
35532	plans swiftsteel shoulders
35533	design amulet of flowing life
35534	design hard khorium band
35535	design hard khorium choker
35536	design loop of forged power
35537	design pendant of sunfire
35538	design ring of flowing life
35539	pattern carapace of sun and shadow
35540	pattern embrace of the phoenix
35541	pattern fletcher s gloves of the phoenix
35542	pattern gloves of immortal dusk
35544	pattern hands of eternal light
35545	pattern leather chestguard of the sun
35546	pattern leather gauntlets of the sun
35548	pattern robe of eternal light
35549	pattern sun drenched scale chestguard
35550	pattern sun drenched scale gloves
35551	pattern sunfire handwraps
35552	pattern sunfire robe
35553	plans hard khorium battlefists
35554	plans hard khorium battleplate
35555	plans sunblessed breastplate
35556	plans sunblessed gauntlets
35557	huge snowball
35562	bear flank
35563	charred bear kabobs
35564	recipe charred bear kabobs
35565	juicy bear burger
35566	recipe juicy bear burger
35568	flame of silvermoon
35569	flame of the exodar
35581	rocket boots xtreme lite
35582	schematic rocket boots xtreme lite
35691	ruined metal parts
35693	figurine empyrean tortoise
35694	figurine khorium boar
35695	design figurine empyrean tortoise
35696	design figurine khorium boar
35697	design figurine crimson serpent
35698	design figurine shadowsong panther
35699	design figurine seaspray albatross
35700	figurine crimson serpent
35702	figurine shadowsong panther
35703	figurine seaspray albatross
35707	regal nightseye
35708	design regal nightseye
35710	delicious baked ham
35716	shattrath flask of pure death
35717	shattrath flask of blinding light
35720	lord of frost s private label
35721	flaskataur s lamp
35722	foror s wipe neutralizer
35723	shards of ahune
35725	summer incense
35728	greater inscription of the blade
35729	greater inscription of the knight
35730	greater inscription of the oracle
35731	greater inscription of the orb
35733	ring of harmonic beauty
35748	guardian s alchemist stone
35749	sorcerer s alchemist stone
35750	redeemer s alchemist stone
35751	assassin s alchemist stone
35752	recipe guardian s alchemist stone
35753	recipe sorcerer s alchemist stone
35754	recipe redeemer s alchemist stone
35755	recipe assassin s alchemist stone
35756	formula enchant cloak steelweave
35758	steady seaspray emerald
35759	forceful seaspray emerald
35760	reckless pyrestone
35761	quick lionseye
35762	design reckless pyrestone
35763	design quick lionseye
35764	design steady seaspray emerald
35765	design forceful seaspray emerald
35766	design steady seaspray emerald
35767	design reckless pyrestone
35768	design quick lionseye
35769	design forceful seaspray emerald
35828	totemic beacon
35874	whizzlespark s portable pet mansion
35906	reins of the black war elekk
35945	brilliant glass
36737	brutal gladiator s hatchet
36748	dark brewmaiden s brew
36876	scorched holy symbol
36877	folded letter
36941	competitor s tabard
37011	magic broom
37012	the horseman s reins
37127	brightbrew charm
37128	balebrew charm
37148	singed page
37297	gold medallion
37298	competitor s souvenir
37311	skybreaker whip
37312	carrot on a stick
37313	riding crop
37488	wild winter pilsner
37489	izzard s ever flavor
37490	aromatic honey brew
37491	metok s bubble bock
37492	springtime stout
37493	blackrock lager
37494	stranglethorn brew
37495	draenic pale ale
37496	binary brew
37497	autumnal acorn ale
37498	bartlett s bitter brew
37499	lord of frost s private label
37503	purified shadowsong amethyst
37504	design purified shadowsong amethyst
37567	healing injector kit
37571	brew of the month club membership form
37582	pyroblast cinnamon ball
37583	g n e r d s
37584	soothing spearmint candy
37585	chewy fel taffy
37586	handful of candy
37588	mostly digested fish
37596	direbrew s bottle do not use
37597	direbrew s shanker
37599	brew of the month club membership form
37604	tooth pick
37605	pouch of pennies
37606	penny pouch
37676	vengeful nether drake
37710	crashin thrashin racer controller
37719	swift zhevra
37736	brew of the month club membership form
37737	brew of the month club membership form
37739	brutal gladiator s blade of alacrity
37740	brutal gladiator s swift judgement
37750	fresh brewfest hops
37816	preserved brewfest hops
37827	brewfest kodo
37828	great brewfest kodo
37829	brewfest prize token
37863	direbrew s remote
37864	medallion of the alliance
37865	medallion of the horde
37898	wild winter pilsner
37899	izzard s ever flavor
37900	aromatic honey brew
37901	metok s bubble bock
37902	springtime stout
37903	blackrock lager
37904	stranglethorn brew
37905	draenic pale ale
37906	binary brew
37907	autumnal acorn ale
37908	bartlett s bitter brew
37909	lord of frost s private label
37915	pattern dress shoes
37927	guardian s band of subjugation
37928	guardian s pendant of subjugation
37929	guardian s pendant of reprieve
37934	noble s elementium signet
38050	soul trader beacon
38082	gigantique bag
38089	ruby shades
38090	sapphire pinky ring
38091	gold eternium band
38160	soul trader s bindings
38161	soul trader s gloves
38162	soul trader s boots
38163	soul trader s head wrap
38175	the horseman s blade
38186	ethereal credit
38225	mycah s botanical bag
38229	pattern mycah s botanical bag
38233	path of illidan
38276	haliscan brimmed hat
38277	haliscan jacket
38278	haliscan pantaloons
38280	direbrew s dire brew
38281	direbrew s dire brew
38285	soul trader s waistband
38286	soul trader s pauldrons
38287	empty mug of direbrew
38288	direbrew hops
38289	coren s lucky coin
38290	dark iron smoking pipe
38291	ethereal mutagen
38294	ethereal liqueur
38300	diluted ethereum essence
38301	d i s c o
38308	ethereal essence sphere
38309	tabard of nature
38310	tabard of the arcane
38311	tabard of the void
38312	tabard of brilliance
38313	tabard of fury
38314	tabard of the defender
38320	dire brew
38327	pattern haliscan jacket
38328	pattern haliscan pantaloons
38329	don carlos hat
38427	pickled egg
38428	rock salted pretzel
38429	blackrock spring water
38430	blackrock mineral water
38431	blackrock fortified water
38432	plugger s blackrock ale
38466	sulfuron slammer
38506	don carlos famous hat
38518	cro s apple
38545	bold ornate ruby
38546	gleaming ornate dawnstone
38547	inscribed ornate topaz
38548	potent ornate topaz
38549	runed ornate ruby
38550	smooth ornate dawnstone
38576	big battle bear
38577	party g r e n a d e
38578	the flag of ownership
38579	venomous tome
38587	empty brewfest stein
38626	empty brew bottle
38628	nether ray fry
39476	fresh goblin brewfest hops
39477	fresh dwarven brewfest hops
39656	tyrael s hilt
43516	brutal nether drake
]==]
