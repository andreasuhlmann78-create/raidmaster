-- ============================================================
-- AH Analyzer Pro 0.59.13 - Einkauf (Logik) - wie der Kaufen-Reiter des Auktionshauses
--
-- * Suche nach Name und/oder Kategorie, Stufe von/bis, Seltenheit
--   -> Liste der Items mit günstigstem Preis und verfügbarer Menge
-- * Item anklicken -> alle Angebote
--   - Waren: Menge wählen, Preis vom Server holen, Kauf bestätigen
--   - Einzelangebote (Ausrüstung): Sofortkauf oder Gebot
-- * Gekauft wird nur per Klick (das verlangt WoW selbst).
-- * Läuft über A.AH - also auch mit dem klassischen Auktionshaus.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local B = {}
A.Buy = B

local TIMEOUT = 10              -- Sekunden, bis eine Suche als ergebnislos gilt
local MAX_PAGES = 20            -- höchstens so viele Ergebnisseiten
local PRICE_WAIT = 6            -- so lange auf die Preisbestätigung des Servers warten
local SORTS = { { sortOrder = 0, reverseSort = false } }

local CLASS = (Enum and Enum.ItemClass) or {}
local TRADE = CLASS.Tradegoods or 7

-- Kategorien wie im Auktionshaus (level = Einrückung)
B.CATS = {
    { key = "all",        label = "Alle",                  filters = nil },
    { key = "weapon",     label = "Waffen",                filters = { { CLASS.Weapon or 2 } } },
    { key = "armor",      label = "Rüstung",               filters = { { CLASS.Armor or 4 } } },
    { key = "container",  label = "Behälter",              filters = { { CLASS.Container or 1 } } },
    { key = "consumable", label = "Verbrauchbares",        filters = { { CLASS.Consumable or 0 } } },
    { key = "trade",      label = "Handwerkswaren",        filters = { { TRADE } } },
    { key = "cloth",      label = "Stoff",                 filters = { { TRADE, 5 } }, level = 1 },
    { key = "leather",    label = "Leder",                 filters = { { TRADE, 6 } }, level = 1 },
    { key = "metal",      label = "Metall & Stein",        filters = { { TRADE, 7 } }, level = 1 },
    { key = "herb",       label = "Kräuter",               filters = { { TRADE, 9 } }, level = 1 },
    { key = "cooking",    label = "Kochzutaten",           filters = { { TRADE, 8 } }, level = 1 },
    { key = "elemental",  label = "Elementar",             filters = { { TRADE, 10 } }, level = 1 },
    { key = "enchanting", label = "Verzauberungsmaterial", filters = { { TRADE, 12 } }, level = 1 },
    { key = "gems",       label = "Edelsteine",            filters = { { CLASS.Gem or 3 } } },
    { key = "recipe",     label = "Rezepte",               filters = { { CLASS.Recipe or 9 } } },
    { key = "misc",       label = "Verschiedenes",         filters = { { CLASS.Miscellaneous or 15 } } },
}


B.search = nil          -- laufende Suche (browse oder items)
B.wanted = nil          -- Suche wartet, bis andere Suchen fertig sind
B.results = {}          -- Items der letzten Suche
B.detail = nil          -- gewähltes Item mit Angeboten
B.pending = nil         -- Warenkauf: Preis vom Server angefragt / bestätigt
B.lastPurchase = nil

local function Now() return GetTime() end

local function SafeCall(fn, ...)
    if not fn then return nil end
    local ok, a = pcall(fn, ...)
    if ok then return a end
    return nil
end

local function Changed() A:Fire("BUY_CHANGED") end

-- ------------------------------------------------------------
-- Zustand
-- ------------------------------------------------------------
function B:IsBusy()
    return self.search ~= nil
end

function B:HasPending()
    return self.pending ~= nil
end

-- sollen Sniper, Preisprüfung und Wächter gerade warten? (Klicks im Einkauf haben Vorrang)
function B:Blocks()
    return self.search ~= nil or self.wanted ~= nil or self.pending ~= nil
end

-- warten andere Teile des Addons gerade auf eigene Suchergebnisse?
function B:OthersBusy()
    if A:IsScanning() then return L["Warte, bis der Markt-Scan fertig ist."] end
    local Sn = A.Sniper
    if Sn and (Sn:IsBusy() or (Sn.pending and not Sn.pending.auto)) then return L["Warte auf den Sniper ..."] end
    if A.Seller and A.Seller:IsBusy() then return L["Warte auf die Preisprüfung ..."] end
    if A.Watcher and A.Watcher:IsBusy() then return L["Warte auf den Wächter ..."] end
    return nil
end

function B:CatLabel(key)
    for _, c in ipairs(self.CATS) do if c.key == key then return L[c.label] end end
    return ""
end

-- gewählte Seltenheiten (nil = alle) -> Filter für die Suche
local function QualityFilters(quals)
    local out = {}
    if not quals or not (Enum and Enum.AuctionHouseFilter) then return out end
    local names = { [0] = "PoorQuality", "CommonQuality", "UncommonQuality", "RareQuality", "EpicQuality", "LegendaryQuality" }
    for q = 0, 5 do
        local v = quals[q] and names[q] and Enum.AuctionHouseFilter[names[q]]
        if v then table.insert(out, v) end
    end
    return out
end

local function ClassFilters(cat)
    local out = {}
    for _, c in ipairs(B.CATS) do
        if c.key == cat and c.filters then
            for _, f in ipairs(c.filters) do table.insert(out, { classID = f[1], subClassID = f[2] }) end
        end
    end
    return out
end

-- ------------------------------------------------------------
-- Suche (Liste der Items)
-- q = { text, cat, minLevel, maxLevel, quals = { [Qualität] = true } oder nil }
-- ------------------------------------------------------------
function B:Search(q)
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    if not (A.AH and A.AH.SendBrowseQuery) then return false, L["Dein Client unterstützt die Auktionshaus-Suche nicht (SendBrowseQuery fehlt)."] end
    q = q or {}
    q.text = (q.text or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if q.text == "" and (not q.cat or q.cat == "all") and not q.minLevel and not q.maxLevel and not q.quals then
        return false, L["Suchbegriff eingeben oder links eine Kategorie wählen."]
    end
    self.lastQuery = q
    self.detail = nil
    self.partial = nil
    self.wanted = { kind = "browse", q = q }
    self:TryStart()
    Changed()
    return true, self.search and L["Suche läuft ..."] or (self:OthersBusy() or L["Suche läuft ..."])
end

-- Angebote eines Items laden
function B:Open(itemKey, name)
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    if type(itemKey) == "number" then itemKey = (A.AH.MakeItemKey and SafeCall(A.AH.MakeItemKey, itemKey)) or { itemID = itemKey, itemLevel = 0, itemSuffix = 0, battlePetSpeciesID = 0 } end
    self:CancelPending()
    self.detail = { itemKey = itemKey, itemID = itemKey.itemID, name = name or A:GetItemName(itemKey.itemID), listings = {}, loading = true }
    self.wanted = { kind = "items", itemKey = itemKey }
    self:TryStart()
    Changed()
    return true
end

function B:Back()
    self:CancelPending()
    self.detail = nil
    if self.wanted and self.wanted.kind == "items" then self.wanted = nil end
    Changed()
end

function B:Refresh()
    if self.detail then return self:Open(self.detail.itemKey, self.detail.name) end
    if self.lastQuery then return self:Search(self.lastQuery) end
    return false
end

-- gewünschte Suche starten, sobald alles frei ist
function B:TryStart()
    local w = self.wanted
    if not w or self.search then return end
    if not A:IsAHOpen() then self.wanted = nil; return end
    if self:OthersBusy() or not A:CanQueryNow() then return end
    -- vorab reservierter Sniper-Preis würde von der Suche nicht gestört, ein eigener Kauf schon
    self.wanted = nil
    local ok, err
    if w.kind == "browse" then
        local q = w.q
        ok, err = pcall(A.AH.SendBrowseQuery, {
            searchString = q.text or "",
            sorts = SORTS,
            filters = QualityFilters(q.quals),
            itemClassFilters = ClassFilters(q.cat),
            minLevel = q.minLevel or 0,
            maxLevel = q.maxLevel or 0,
        })
    else
        ok, err = pcall(A.AH.SendSearchQuery, w.itemKey, SORTS, true)
    end
    A:NoteQuery()
    if not ok then
        A:QueryError()
        self.message = L["Suche fehlgeschlagen: "] .. tostring(err)
        if self.detail then self.detail.loading = false end
        Changed()
        return
    end
    self.message = nil
    self.search = { kind = w.kind, q = w.q, itemKey = w.itemKey, started = Now(), lastCount = -1, lastChange = Now(), pages = 0 }
    Changed()
end

-- ------------------------------------------------------------
-- Ergebnisse lesen
-- ------------------------------------------------------------
local function ItemInfo(itemID)
    if not GetItemInfo then return nil end
    local ok, name, _, quality, ilvl, req, _, _, stack = pcall(GetItemInfo, itemID)
    if ok and name then return quality, ilvl, req, stack end
    return nil
end

local function ReadBrowse(q)
    local out = {}
    for _, r in ipairs(SafeCall(A.AH.GetBrowseResults) or {}) do
        local key = r.itemKey
        local id = type(key) == "table" and key.itemID
        if id then
            local quality, ilvl, req = ItemInfo(id)
            local keep = true
            if q and q.quals and quality and not q.quals[quality] then keep = false end
            if keep then
                table.insert(out, {
                    itemKey = key, itemID = id, name = A:GetItemName(id),
                    price = r.minPrice, qty = r.totalQuantity or 0,
                    quality = quality, ilvl = (key.itemLevel and key.itemLevel > 0) and key.itemLevel or ilvl, req = req,
                    pct = r.minPrice and A:GetMarketPercent(id, r.minPrice) or nil,
                    own = r.containsOwnerItem,
                })
            end
        end
    end
    return out
end

local function ReadListings(itemKey)
    local C = A.AH
    local id = itemKey.itemID
    local out = {}
    local nCom = SafeCall(C.GetNumCommoditySearchResults, id) or 0
    if nCom > 0 then
        for i = 1, nCom do
            local info = SafeCall(C.GetCommoditySearchResultInfo, id, i)
            if type(info) == "table" and info.unitPrice and info.unitPrice > 0 then
                local ownQty = info.numOwnerItems or (info.containsOwnerItem and info.quantity) or 0
                table.insert(out, { price = info.unitPrice, qty = info.quantity or 1, own = ownQty > 0, ownQty = ownQty })
            end
        end
        table.sort(out, function(a, b) return a.price < b.price end)
        A:MarkBait(out)
        return out, true
    end
    local n = SafeCall(C.GetNumItemSearchResults, itemKey) or 0
    for i = 1, n do
        local info = SafeCall(C.GetItemSearchResultInfo, itemKey, i)
        if type(info) == "table" then
            local qty = info.quantity or 1
            local buyout = (info.buyoutAmount and info.buyoutAmount > 0) and info.buyoutAmount or nil
            local ilvl
            if info.itemLink and GetDetailedItemLevelInfo then ilvl = SafeCall(GetDetailedItemLevelInfo, info.itemLink) end
            table.insert(out, {
                auctionID = info.auctionID, qty = qty, buyout = buyout,
                price = buyout and math.floor(buyout / math.max(1, qty)) or nil,
                bid = info.bidAmount, minBid = info.minBid, link = info.itemLink, ilvl = ilvl,
                own = info.containsOwnerItem or false, timeLeft = info.timeLeftSeconds,
            })
        end
    end
    -- Sofortkauf zuerst nach Preis, reine Gebote ans Ende
    table.sort(out, function(a, b)
        if (a.price ~= nil) ~= (b.price ~= nil) then return a.price ~= nil end
        if a.price and b.price and a.price ~= b.price then return a.price < b.price end
        return (a.bid or a.minBid or 0) < (b.bid or b.minBid or 0)
    end)
    return out, false
end

local function ItemFull(itemKey)
    local C = A.AH
    if SafeCall(C.HasFullCommoditySearchResults, itemKey.itemID) then return true end
    return SafeCall(C.HasFullItemSearchResults, itemKey) == true
end

function B:Poll()
    local s = self.search
    if not s then return end
    if not A:IsAHOpen() then self.search = nil; return end
    local now = Now()
    local timedOut = now - s.started > TIMEOUT

    if s.kind == "browse" then
        local C = A.AH
        local count = SafeCall(C.GetNumBrowseResults) or #(SafeCall(C.GetBrowseResults) or {})
        -- Altes AH: Fortschritt an den erhaltenen Seiten messen - eine neue Seite bringt oft
        -- keine neuen Items (gleiche Items, weitere Angebote), ist aber trotzdem Fortschritt
        local gotPages, totalPages
        if C.GetBrowseProgress then gotPages, totalPages = C.GetBrowseProgress() end
        local sig = gotPages and (count .. ":" .. gotPages) or count
        if sig ~= s.lastCount then
            s.lastCount, s.lastChange, s.waitingMore = sig, now, false
            s.progress = gotPages and totalPages and totalPages > 1 and { gotPages, math.min(totalPages, MAX_PAGES) } or nil
            -- Zwischenstand schon anzeigen
            if count > 0 then
                self.partial = ReadBrowse(s.q)
                Changed()
            end
        end
        local full = SafeCall(C.HasFullBrowseResults)
        if count > 0 and full == false and not s.waitingMore and s.pages < MAX_PAGES and A:QueryReady() and C.RequestMoreBrowseResults then
            if pcall(C.RequestMoreBrowseResults) then
                s.pages, s.waitingMore = s.pages + 1, true
                return
            end
        end
        local done
        if A.AH_LEGACY then
            -- Altes AH: jede Seite muss einzeln abgefragt werden, dazwischen sperrt der Server
            -- für ein paar Sekunden. Nicht vorzeitig aufhören, sonst fehlen z.B. alle blauen
            -- und weißen Items (die Liste kommt nach Seltenheit sortiert).
            done = (count > 0 and (full == true or s.pages >= MAX_PAGES))
                or (count > 0 and now - s.lastChange >= 15)
                or (count == 0 and s.answered and now - s.lastChange >= 0.5)
                or (count == 0 and timedOut)
        else
            done = (count > 0 and (full == true or s.pages >= MAX_PAGES or (not s.waitingMore and now - s.lastChange >= 1)))
                or (count > 0 and s.waitingMore and now - s.lastChange >= 3)
                or (count == 0 and s.answered and now - s.lastChange >= 0.5)
                or timedOut
        end
        if not done then return end
        self.search, self.partial = nil, nil
        self.results = ReadBrowse(s.q)
        self.resultsTime = time()
        self.message = (#self.results == 0) and L["Keine Angebote gefunden."] or nil
        Changed()
        return
    end

    local okRead, listings, commodity = pcall(ReadListings, s.itemKey)
    if not okRead then listings, commodity = {}, false end
    local count = #listings
    if count ~= s.lastCount then s.lastCount, s.lastChange = count, now end
    local full = ItemFull(s.itemKey)
    local done = (full and (count > 0 or s.answered or now - s.started >= 1))
        or (count > 0 and now - s.lastChange >= 0.75)
        or timedOut
    if not done then return end
    self.search = nil
    local d = self.detail
    if d and d.itemID == s.itemKey.itemID then
        d.listings, d.commodity, d.loading, d.time = listings, commodity, false, time()
        -- günstigsten echten Preis (ohne Lockangebote) in den Preisverlauf
        local first, total = nil, 0
        for _, l in ipairs(listings) do
            if not l.bait and l.price then
                first = first or l
                total = total + l.qty
            end
        end
        if first then A:VerifyPrice(d.itemID, first.price, total) end
        if d.commodity then
            d.qty = math.min(d.qty or 1, math.max(1, self:Available()))
        end
    end
    Changed()
    A:Fire("DATA_CHANGED")
end

-- ------------------------------------------------------------
-- Waren kaufen: Menge -> Preis vom Server -> bestätigen
-- ------------------------------------------------------------
-- kaufbare Menge (ohne eigene Angebote)
function B:Available()
    local d = self.detail
    if not (d and d.commodity) then return 0 end
    local n = 0
    for _, l in ipairs(d.listings) do n = n + math.max(0, l.qty - (l.ownQty or 0)) end
    return n
end

-- Kosten für qty Stück (günstigste zuerst, wie der Server) -> total, Stückpreis Ø, höchster Preis, Lockstücke
function B:Quote(qty)
    local d = self.detail
    if not (d and d.commodity) or not qty or qty < 1 then return nil end
    local left, total, top, bait = qty, 0, 0, 0
    for _, l in ipairs(d.listings) do
        if left <= 0 then break end
        local avail = math.max(0, l.qty - (l.ownQty or 0))
        local n = math.min(left, avail)
        if n > 0 then
            total = total + n * l.price
            top = l.price
            if l.bait then bait = bait + n end
            left = left - n
        end
    end
    if left > 0 then return nil end
    return total, total / qty, top, bait
end

function B:SetQuantity(qty)
    local d = self.detail
    if not d then return end
    d.qty = math.max(1, math.min(math.floor(tonumber(qty) or 1), math.max(1, self:Available())))
    if self.pending then self:CancelPending() end
    Changed()
end

-- Menge bis einschließlich dieser Zeile (Klick auf eine Preisstufe)
function B:QuantityUpTo(listing)
    local d = self.detail
    if not (d and d.commodity) then return end
    local n = 0
    for _, l in ipairs(d.listings) do
        n = n + math.max(0, l.qty - (l.ownQty or 0))
        if l == listing then break end
    end
    self:SetQuantity(math.max(1, n))
end

function B:StartCommodity()
    local d = self.detail
    local C = A.AH
    if not (d and d.commodity) then return false end
    if not (C.StartCommoditiesPurchase and C.ConfirmCommoditiesPurchase) then
        return false, L["Dein Client unterstützt keinen Warenkauf (StartCommoditiesPurchase fehlt)."]
    end
    local qty = d.qty or 1
    local total = self:Quote(qty)
    if not total then return false, L["So viele sind nicht verfügbar."] end
    -- ein vorab reservierter Sniper-Preis würde sonst überschrieben
    if A.Sniper and A.Sniper.pending then A.Sniper:CancelPending() end
    local ok, err = pcall(C.StartCommoditiesPurchase, d.itemID, qty)
    if not ok then return false, L["Kauf fehlgeschlagen: "] .. tostring(err) end
    self.pending = { itemID = d.itemID, qty = qty, expected = total, started = Now(), state = "waiting" }
    Changed()
    return true, L["Preis wird vom Server geholt ..."]
end

function B:ConfirmCommodity()
    local p = self.pending
    if not p then return false, L["Nichts zu bestätigen."] end
    if p.state ~= "ready" then return false, L["Preis wird noch geprüft ..."] end
    self.pending = nil
    local ok, err = pcall(A.AH.ConfirmCommoditiesPurchase, p.itemID, p.qty)
    if not ok then Changed(); return false, L["Kauf fehlgeschlagen: "] .. tostring(err) end
    self.lastPurchase = { itemID = p.itemID, qty = p.qty, cost = p.total, time = Now() }
    Changed()
    return true, L["Kauf wird ausgeführt ..."]
end

function B:CancelPending()
    if not self.pending then return end
    self.pending = nil
    if A.AH and A.AH.CancelCommoditiesPurchase then pcall(A.AH.CancelCommoditiesPurchase) end
    Changed()
end

-- ------------------------------------------------------------
-- Einzelangebote: Sofortkauf und Gebot
-- ------------------------------------------------------------
function B:BuyItem(l)
    if not (l and l.auctionID and l.buyout) then return false, L["Kein Sofortkauf-Preis."] end
    if l.own then return false, L["Das ist dein eigenes Angebot."] end
    if GetMoney and GetMoney() < l.buyout then return false, L["Nicht genug Gold."] end
    local ok, err = pcall(A.AH.PlaceBid, l.auctionID, l.buyout)
    if not ok then return false, L["Kauf fehlgeschlagen: "] .. tostring(err) end
    l.used = true
    self.lastPurchase = { itemID = self.detail and self.detail.itemID, qty = l.qty, cost = l.buyout, time = Now() }
    Changed()
    return true, L["Kauf wird ausgeführt ..."]
end

-- kleinstes erlaubtes Gebot
function B:MinBid(l)
    if not l then return nil end
    if l.bid and l.bid > 0 then return l.bid + math.max(1, math.floor(l.bid * 0.05)) end
    return l.minBid
end

function B:PlaceBid(l, amount)
    if not (l and l.auctionID) then return false, L["Kein Angebot gewählt."] end
    if l.own then return false, L["Das ist dein eigenes Angebot."] end
    local min = self:MinBid(l)
    if not amount or amount <= 0 then return false, L["Bitte ein Gebot eingeben."] end
    if min and amount < min then return false, L["Gebot zu niedrig - mindestens "] .. A:FormatMoney(min) end
    if l.buyout and amount >= l.buyout then return self:BuyItem(l) end
    if GetMoney and GetMoney() < amount then return false, L["Nicht genug Gold."] end
    local ok, err = pcall(A.AH.PlaceBid, l.auctionID, amount)
    if not ok then return false, L["Gebot fehlgeschlagen: "] .. tostring(err) end
    self.lastBid = { time = Now(), amount = amount }
    Changed()
    return true, L["Gebot abgegeben: "] .. A:FormatMoney(amount)
end

-- ------------------------------------------------------------
-- Ereignisse
-- ------------------------------------------------------------
local evt = CreateFrame("Frame")
local function Reg(e) return A:RegisterAHEvent(evt, e) end
B.priceEvents = Reg("COMMODITY_PRICE_UPDATED")
Reg("COMMODITY_PRICE_UNAVAILABLE")
Reg("COMMODITY_PURCHASE_SUCCEEDED")
Reg("COMMODITY_PURCHASE_FAILED")
Reg("AUCTION_HOUSE_PURCHASE_COMPLETED")
Reg("AUCTION_HOUSE_SHOW_ERROR")

local function AfterPurchase()
    local lp = B.lastPurchase
    if lp and not lp.done then
        lp.done = true
        A:Print(L["Gekauft: "] .. lp.qty .. "x " .. A:GetItemName(lp.itemID) .. L[" für "] .. A:FormatMoney(lp.cost or 0))
    end
    -- Angebote neu laden
    C_Timer.After(0.5, function() if B.detail and A:IsAHOpen() then B:Open(B.detail.itemKey, B.detail.name) end end)
end

evt:SetScript("OnEvent", function(_, event, a1, a2)
    if event == "COMMODITY_PRICE_UPDATED" then
        local p = B.pending
        if not p or p.state ~= "waiting" then return end
        p.unit, p.total, p.state, p.started = a1, a2, "ready", Now()
        Changed()
    elseif event == "COMMODITY_PRICE_UNAVAILABLE" then
        if B.pending then
            B.pending = nil
            B.message = L["Angebot nicht mehr verfügbar - Kauf abgebrochen."]
            Changed()
        end
    elseif event == "COMMODITY_PURCHASE_SUCCEEDED" or event == "AUCTION_HOUSE_PURCHASE_COMPLETED" then
        local lp = B.lastPurchase
        if lp and Now() - lp.time < 15 and not lp.done then AfterPurchase() end
    elseif event == "COMMODITY_PURCHASE_FAILED" or event == "AUCTION_HOUSE_SHOW_ERROR" then
        local lp = B.lastPurchase
        if lp and not lp.done and Now() - lp.time < 5 then
            lp.done, lp.failed = true, true
            B.message = L["|cffff5544Kauf fehlgeschlagen|r (Angebot weg oder nicht genug Gold)."]
            A:Print(B.message)
            Changed()
            C_Timer.After(0.5, function() if B.detail and A:IsAHOpen() then B:Open(B.detail.itemKey, B.detail.name) end end)
        elseif B.lastBid and Now() - B.lastBid.time < 5 then
            B.lastBid = nil
            B.message = L["|cffff5544Gebot fehlgeschlagen.|r"]
            Changed()
        end
    end
end)

A:On("BROWSE_RESULTS", function()
    if B.search and B.search.kind == "browse" then B.search.answered = true; B:Poll() end
end)
A:On("SEARCH_RESULTS", function()
    if B.search and B.search.kind == "items" then B.search.answered = true; B:Poll() end
end)
A:On("QUERY_READY", function() if not B.search then B:TryStart() end end)
A:On("AH_STATE", function()
    if not A:IsAHOpen() then
        B.search, B.wanted, B.pending, B.partial = nil, nil, nil, nil
    end
    Changed()
end)

local ticker = CreateFrame("Frame")
local acc = 0
ticker:SetScript("OnUpdate", function(_, dt)
    acc = acc + (dt or 0)
    if acc < 0.1 then return end
    acc = 0
    if B.search then B:Poll() elseif B.wanted then B:TryStart() end
    local p = B.pending
    if p then
        if p.state == "waiting" and Now() - p.started > PRICE_WAIT then
            if not B.priceEvents then
                p.state, p.total = "ready", p.expected      -- Client ohne Preis-Ereignis: geschätzten Preis zeigen
            else
                B.pending = nil
                B.message = L["Keine Preisbestätigung vom Server - Kauf abgebrochen."]
                if A.AH.CancelCommoditiesPurchase then pcall(A.AH.CancelCommoditiesPurchase) end
            end
            Changed()
        elseif p.state == "ready" and Now() - p.started > 30 then
            B:CancelPending()
            B.message = L["Reservierter Preis verfallen - bitte neu kaufen."]
            Changed()
        end
    end
end)

function B:GetDebugText()
    return string.format("Suche=%s, wartet=%s, Ergebnisse=%d, Item=%s, Kauf=%s",
        self.search and self.search.kind or "-", self.wanted and self.wanted.kind or "-", #self.results,
        self.detail and tostring(self.detail.itemID) or "-", self.pending and self.pending.state or "-")
end
