-- ============================================================
-- AHSentinel - "Heute tun" zum Anklicken
--
-- Jede Zeile in "Heute tun" bekommt einen Knopf, der immer den nächsten
-- sinnvollen Schritt anbietet - ohne Sprung in einen anderen Reiter:
--   Kaufen:     Prüfen -> Kaufen (nie teurer, nie mehr als vorgeschlagen) -> Einstellen / Hinweis
--   Verkaufen:  Prüfen -> Einstellen (Preisvorschlag, Preisschutz)
--   Neu einstellen: ein Klick je Auktion
--   Herstellen (ProfessionSentinel): Knopf zeigt dessen nächsten Schritt
--
-- Schnittstelle für andere Addons (z. B. ProfessionSentinel):
--   AHAnalyzerPro.Today:QuickBuy(itemID, qty, maxPrice, label)
--   AHAnalyzerPro.Today:QuickSell(itemID, count)
-- Beide kaufen bzw. stellen NIE ohne Klick ein: sie legen eine Zeile mit Knopf an.
-- WoW verlangt für jeden Kauf und jedes Einstellen einen eigenen Klick.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local T = A.Today or {}
A.Today = T

T.state = T.state or {}      -- [Zeilen-Schlüssel] = Zustand des Knopfs (bleibt bei "Aktualisieren" erhalten)
T.extra = T.extra or {}      -- Zeilen von QuickBuy / QuickSell (stehen oben)

local BUY_KINDS = { vendor = true, flip = true, de = true, bid = true, quick = true }
local SELL_KINDS = { sell = true, quicksell = true }

local function Now() return GetTime and GetTime() or time() end

-- Schlüssel einer Zeile: Art und Item (der Text ändert sich mit den Preisen)
function T:Key(r)
    if r.key then return r.key end
    return tostring(r.kind) .. ":" .. tostring(r.itemID or r.text)
end

function T:State(r)
    local k = self:Key(r)
    local s = self.state[k]
    if not s then
        s = { step = "check", bought = 0, posted = 0 }
        self.state[k] = s
    end
    return s
end

local function Money() return GetMoney and GetMoney() or 0 end

-- ------------------------------------------------------------
-- Angebote prüfen (wie "Item im Einkauf suchen", aber ohne den Reiter zu öffnen)
-- ------------------------------------------------------------
local function DetailFor(itemID)
    local d = A.Buy and A.Buy.detail
    if d and d.itemID == itemID then return d end
    return nil
end

-- passende Angebote: fremd, kein Lockangebot, Stückpreis <= maxUnit, zusammen höchstens qty Stück
function T:Plan(r, d)
    local s = self:State(r)
    local want = math.max(0, (r.qty or 1) - (s.bought or 0))
    if want <= 0 then return nil end
    local maxUnit = r.maxUnit
    if not maxUnit or maxUnit <= 0 then return nil end
    if d.commodity then
        local avail, cost, n = 0, 0, 0
        for _, l in ipairs(d.listings) do
            if not l.bait and l.price and l.price <= maxUnit then
                local free = math.max(0, (l.qty or 0) - (l.ownQty or 0))
                local take = math.min(free, want - n)
                if take > 0 then n = n + take; cost = cost + take * l.price end
                if n >= want then break end
            end
        end
        if n <= 0 then return nil end
        return { commodity = true, qty = n, cost = cost, unit = math.floor(cost / n + 0.5) }
    end
    local list, n, cost = {}, 0, 0
    local isBid = r.kind == "bid"
    for _, l in ipairs(d.listings) do
        if not l.own and not l.used and not l.bait and (l.qty or 1) <= (want - n) then
            local price = isBid and (A.Buy:MinBid(l)) or l.buyout
            if price and price > 0 and price / (l.qty or 1) <= maxUnit then
                table.insert(list, { listing = l, price = price })
                n = n + (l.qty or 1)
                cost = cost + price
                if isBid then break end            -- ein Gebot pro Vorschlag
            end
        end
        if n >= want then break end
    end
    if #list == 0 then return nil end
    table.sort(list, function(a, b) return a.price / (a.listing.qty or 1) < b.price / (b.listing.qty or 1) end)
    return { listings = list, qty = n, cost = cost, unit = math.floor(cost / n + 0.5), bid = isBid or nil }
end

function T:Check(r)
    local s = self:State(r)
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    if SELL_KINDS[r.kind] then
        if A.Seller then A.Seller:CheckPrice(r.itemID, true) end
        s.step, s.started = "pricing", Now()
        return true
    end
    local ok, msg = A.Buy:Open(r.itemID, A:GetItemName(r.itemID))
    if not ok then return false, msg end
    s.step, s.started, s.plan = "loading", Now(), nil
    return true
end

-- Zustände weiterschalten, wenn Antworten vom Server da sind (läuft regelmäßig, solange das Fenster offen ist)
function T:Update(r)
    local s = self:State(r)
    if s.step == "loading" then
        local d = DetailFor(r.itemID)
        if not d then
            -- inzwischen wurde ein anderes Item geöffnet: neu prüfen lassen
            if Now() - (s.started or 0) > 2 then s.step = "check" end
            return
        end
        if d.loading or (A.Buy.search and A.Buy.search.kind == "items") then
            if Now() - (s.started or 0) > 30 then s.step, s.info = "check", L["keine Antwort vom Server"] end
            return
        end
        local plan = self:Plan(r, d)
        if plan then
            s.plan, s.step, s.info = plan, "ready", nil
        else
            s.plan, s.step = nil, "stale"
        end
    elseif s.step == "reserving" then
        local p = A.Buy.pending
        if not p then
            s.step = "check"; return
        end
        if p.state == "ready" then
            local limit = (r.maxUnit or 0) * (p.qty or 1)
            if (p.total or 0) > limit then
                A.Buy:CancelPending()
                s.step, s.plan = "stale", nil
                A:Print(string.format(L["%s: Preis ist gestiegen (%s) - nichts gekauft."], A:GetItemName(r.itemID), A:FormatMoney(p.total or 0)))
            else
                s.step, s.total = "confirm", p.total
            end
        elseif Now() - (p.started or 0) > 15 then
            A.Buy:CancelPending()
            s.step = "check"
        end
    elseif s.step == "pricing" then
        local Se = A.Seller
        if Se and Se:IsPriceFresh(r.itemID) then s.step = "sellready"
        elseif Now() - (s.started or 0) > 30 then s.step = "sellready" end
    elseif s.step == "posting" then
        local Se = A.Seller
        if not (Se and Se.pendingPost) or Now() - (s.started or 0) > 6 then
            s.step = (r.kind == "repost") and "repost" or "posted"
        end
    end
end

-- ------------------------------------------------------------
-- Kaufen
-- ------------------------------------------------------------
-- Kapitalschutz: Vorschläge aus "Heute tun" höchstens 20 % des Golds, eigene Aufträge (QuickBuy) höchstens 50 %
function T:CapitalOK(r, cost)
    local K = A.Comfort
    local share = (r.kind == "quick") and (K and K.TODAY_TOTAL_SHARE or 0.5) or (K and K.TODAY_ITEM_SHARE or 0.2)
    return cost <= Money() * share + 1
end

function T:Buy(r)
    local s = self:State(r)
    local B = A.Buy
    local d = DetailFor(r.itemID)
    if not d or d.loading then return self:Check(r) end
    local plan = self:Plan(r, d)
    if not plan then s.step, s.plan = "stale", nil; return false, L["nicht mehr lohnend"] end
    if not self:CapitalOK(r, plan.cost) then
        return false, string.format(L["Zu teuer für den Kapitalschutz (%s)."], A:FormatMoney(plan.cost))
    end
    if plan.commodity then
        d.qty = plan.qty
        local ok, msg = B:StartCommodity()
        if ok then s.step, s.started, s.plan = "reserving", Now(), plan end
        return ok, msg
    end
    local e = plan.listings[1]
    local ok, msg
    if plan.bid then
        ok, msg = B:PlaceBid(e.listing, e.price)
    else
        ok, msg = B:BuyItem(e.listing)
    end
    if ok then
        s.bought = (s.bought or 0) + (e.listing.qty or 1)
        s.spent = (s.spent or 0) + e.price
        if plan.bid then
            s.step = "bidded"
        elseif s.bought >= (r.qty or 1) then
            s.step = "bought"
        else
            local rest = self:Plan(r, d)
            s.plan = rest
            s.step = rest and "ready" or "bought"
        end
    end
    return ok, msg
end

function T:Confirm(r)
    local s = self:State(r)
    local p = A.Buy.pending
    if not (p and p.state == "ready") then s.step = "check"; return false end
    if (p.total or 0) > (r.maxUnit or 0) * (p.qty or 1) then
        A.Buy:CancelPending()
        s.step = "stale"
        return false, L["nicht mehr lohnend"]
    end
    local qty, total = p.qty, p.total
    local ok, msg = A.Buy:ConfirmCommodity()
    if ok then
        s.bought = (s.bought or 0) + (qty or 0)
        s.spent = (s.spent or 0) + (total or 0)
        s.step = "bought"
    end
    return ok, msg
end

-- ------------------------------------------------------------
-- Einstellen (Flip nach dem Kauf, Taschen-Ware, QuickSell)
-- ------------------------------------------------------------
function T:SellPrice(r)
    local Se = A.Seller
    local price = Se and Se:Suggest(r.itemID)
    -- nie über dem, was "Heute tun" als realistisch gerechnet hat (Preissturz-Schutz)
    if r.unit and price and price > r.unit and not (Se and Se:IsPriceFresh(r.itemID)) then price = r.unit end
    return price or r.unit
end

function T:SellCount(r)
    local s = self:State(r)
    local have = A.Seller and A.Seller:CountInBags(r.itemID) or 0
    local want = r.count or s.bought or have
    if r.kind == "flip" or r.kind == "quick" then want = s.bought or 0 end
    return math.max(0, math.min(have, want - (s.posted or 0)))
end

function T:Post(r)
    local s = self:State(r)
    local Se = A.Seller
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    local price = self:SellPrice(r)
    if not price then return false, L["keine Preisdaten - bitte Preis eingeben"] end
    local n = self:SellCount(r)
    if n <= 0 then s.step = "posted"; return false, L["Nichts mehr in den Taschen."] end
    -- Preisschutz: bei Warnung erst ein zweiter Klick stellt ein
    local risks = Se:PriceRisks(r.itemID, price)
    if #risks > 0 and not s.riskOK then
        s.riskOK = true
        return false, L["Preis prüfen: "] .. table.concat(risks, "; ") .. " - " .. L["nochmal klicken zum Einstellen"]
    end
    s.riskOK = nil
    local ok, msg = Se:Post(r.itemID, price, n, 2)
    if ok then
        s.posted = (s.posted or 0) + ((Se.pendingPost and Se.pendingPost.qty) or n)
        s.step, s.started = "posting", Now()
    end
    return ok, msg
end

-- ------------------------------------------------------------
-- Knopf: Beschriftung, aktiv?, Klick
-- ------------------------------------------------------------
-- ------------------------------------------------------------
-- Eigene Herstell-Vorschläge (ohne ProfessionSentinel)
-- Knopf: "Zutaten kaufen" legt für jede fehlende AH-Zutat eine Kauf-Zeile oben an (QuickBuy),
-- danach "Alles da" -> im Berufsfenster herstellen (das kann ein Addon nicht selbst auslösen).
-- ------------------------------------------------------------
function T:CraftMissing(r)
    local c = r.craft
    local missing, vendor = {}, {}
    for _, re in ipairs(c and c.reagents or {}) do
        local need = re.count * (r.count or 1)
        local have = A.Crafting:HaveCount(re.itemID)
        if have < need then
            local e = { itemID = re.itemID, qty = need - have, unit = re.unit }
            if re.atVendor then table.insert(vendor, e) else table.insert(missing, e) end
        end
    end
    return missing, vendor
end

function T:CraftBuy(r)
    local missing, vendor = self:CraftMissing(r)
    if #missing == 0 and #vendor == 0 then return true, L["Alles da - im Berufsfenster herstellen."] end
    for _, e in ipairs(missing) do
        -- etwas Spielraum (10 %), der Gewinn bleibt trotzdem positiv (Vorschläge haben mind. 10 % Gewinn)
        self:QuickBuy(e.itemID, e.qty, math.max(1, math.floor(e.unit * 1.10 + 0.5)), r.craft and r.craft.name)
    end
    if #vendor > 0 then
        local names = {}
        for _, e in ipairs(vendor) do table.insert(names, e.qty .. "x " .. A:GetItemName(e.itemID)) end
        return true, L["Beim Händler kaufen: "] .. table.concat(names, ", ")
    end
    return true
end

-- Rückgabe: Text, aktiv
function T:Label(r)
    local s = self:State(r)
    local ah = A:IsAHOpen()
    if r.kind == "pshint" then return L["Ausblenden"], true end
    if r.kind == "owncraft" then
        local missing, vendor = self:CraftMissing(r)
        if #missing == 0 and #vendor == 0 then return L["Alles da - herstellen"], false end
        if #missing == 0 then return L["Zutaten beim Händler"], false end
        return string.format(L["Zutaten kaufen (%d)"], #missing), true
    end
    if r.kind == "craft" then
        return r.stepText or L["Herstellen"], true
    end
    if r.kind == "repost" then
        return L["Neu einstellen"], ah
    end
    if r.kind == "undercut" then
        return L["Meine Auktionen"], true
    end
    if r.kind == "vendorsell" then
        return L["Beim Händler verkaufen"], false
    end
    if SELL_KINDS[r.kind] then
        if s.step == "posted" then return "|cff33dd55" .. L["Eingestellt"] .. "|r", false end
        if s.step == "posting" then return L["Wird eingestellt ..."], false end
        if not ah then return L["AH öffnen"], false end
        if s.step == "pricing" then return L["Prüft ..."], false end
        if s.step == "sellready" then
            local p = self:SellPrice(r)
            return p and (L["Einstellen"] .. " " .. A:FormatMoney(p)) or L["Einstellen"], true
        end
        return L["Prüfen"], true
    end
    if BUY_KINDS[r.kind] then
        if s.step == "bought" or s.step == "posting" or s.step == "posted" then
            if r.kind == "flip" or (r.kind == "quick" and r.resell) then
                if s.step == "posted" then return "|cff33dd55" .. L["Eingestellt"] .. "|r", false end
                if s.step == "posting" then return L["Wird eingestellt ..."], false end
                if not ah then return L["AH öffnen"], false end
                return L["Einstellen"], true
            elseif r.kind == "de" then
                local n = A.Seller and A.Seller:CountInBags(r.itemID) or 0
                return string.format(L["Entzaubern (%d in der Tasche)"], n), false
            elseif r.kind == "vendor" then
                return L["Beim Händler verkaufen"], false
            end
            return "|cff33dd55" .. L["gekauft"] .. "|r", false
        end
        if s.step == "bidded" then return "|cff33dd55" .. L["Geboten"] .. "|r", false end
        if not ah then return L["AH öffnen"], false end
        if s.step == "loading" or s.step == "reserving" then return L["Prüft ..."], false end
        if s.step == "stale" then return "|cff888888" .. L["nicht mehr lohnend"] .. "|r", true end
        if s.step == "confirm" then return L["Bestätigen"] .. " " .. A:FormatMoney(s.total or 0), true end
        if s.step == "ready" and s.plan then
            local p = s.plan
            if p.bid then return L["Bieten"] .. " " .. A:FormatMoney(p.cost), true end
            if not p.commodity and #p.listings > 1 then
                local done = (s.buyClicks or 0) + 1
                return string.format(L["Kaufen (%d/%d)"], done, done + #p.listings - 1), true
            end
            return string.format(L["Kaufen %s"], A:FormatMoney(p.commodity and p.cost or p.listings[1].price)), true
        end
        return L["Prüfen"], true
    end
    return nil, false
end

-- Text "was gerade dran ist" für die Spalte neben dem Knopf
function T:Info(r)
    local s = self:State(r)
    if r.kind == "pshint" then return "" end
    if r.kind == "owncraft" then
        local missing, vendor = self:CraftMissing(r)
        if #missing == 0 and #vendor == 0 then return "|cff33dd55" .. L["Zutaten komplett - Berufsfenster öffnen"] .. "|r" end
        local t = string.format(L["Zutaten je Herstellung %s, fehlen: %d"], A:FormatMoney(r.craft and r.craft.cost or 0), #missing + #vendor)
        if #vendor > 0 then t = t .. " (" .. string.format(L["%d beim Händler"], #vendor) .. ")" end
        return t
    end
    if s.step == "ready" and s.plan then
        local p = s.plan
        return string.format(L["%dx zu je %s = %s"], p.qty, A:FormatMoney(p.unit), A:FormatMoney(p.cost))
    end
    if s.step == "stale" then return "|cff888888" .. L["Angebot weg oder teurer"] .. "|r" end
    if (s.bought or 0) > 0 then
        local t = string.format(L["%d gekauft für %s"], s.bought, A:FormatMoney(s.spent or 0))
        if (s.posted or 0) > 0 then t = t .. ", " .. string.format(L["%d eingestellt"], s.posted) end
        return t
    end
    if (s.posted or 0) > 0 then return string.format(L["%d eingestellt"], s.posted) end
    return s.info or r.where or ""
end

function T:Click(r)
    local s = self:State(r)
    local ok, msg
    if r.kind == "pshint" then
        if A.db then A.db.settings.psHintHidden = true end
        s.dirty = true
        return true
    end
    if r.kind == "owncraft" then
        ok, msg = self:CraftBuy(r)
        if msg and msg ~= "" then A:Print(msg) end
        s.dirty = true
        return ok
    end
    if r.kind == "craft" then
        if r.run then ok, msg = pcall(r.run) end
        s.dirty = true
        return true
    end
    if r.kind == "repost" then
        ok, msg = A.Extras:RepostStep()
    elseif r.kind == "undercut" then
        if r.run then pcall(r.run) end
        return true
    elseif SELL_KINDS[r.kind] then
        if s.step == "sellready" then ok, msg = self:Post(r) else ok, msg = self:Check(r) end
    elseif BUY_KINDS[r.kind] then
        if s.step == "bought" and (r.kind == "flip" or (r.kind == "quick" and r.resell)) then
            ok, msg = self:Post(r)
        elseif s.step == "ready" then
            local before = s.bought or 0
            ok, msg = self:Buy(r)
            if ok and (s.bought or 0) > before then s.buyClicks = (s.buyClicks or 0) + 1 end
        elseif s.step == "confirm" then
            ok, msg = self:Confirm(r)
        else
            s.buyClicks = 0
            ok, msg = self:Check(r)
        end
    end
    if msg and msg ~= "" then A:Print(msg) end
    return ok
end

-- ------------------------------------------------------------
-- Schnittstelle für andere Addons
-- ------------------------------------------------------------
-- Item kaufen wie in "Heute tun": legt oben in "Heute tun" eine Zeile mit Knopf an und öffnet das Fenster.
-- Gekauft wird erst beim Klick, höchstens qty Stück zu höchstens maxPrice pro Stück.
function T:QuickBuy(itemID, qty, maxPrice, label)
    itemID = tonumber(itemID)
    qty = math.max(1, math.floor(tonumber(qty) or 1))
    maxPrice = math.floor(tonumber(maxPrice) or 0)
    if not itemID or maxPrice <= 0 then return false end
    local key = "quick:" .. itemID
    local r = {
        key = key, kind = "quick", itemID = itemID, qty = qty, maxUnit = maxPrice, pin = true,
        gold = 0, capital = maxPrice * qty,
        text = string.format(L["Kaufe %dx %s bis %s je Stück"], qty, A:GetItemName(itemID), A:FormatMoney(maxPrice))
            .. (label and label ~= "" and ("  (" .. label .. ")") or ""),
        where = L["Einkauf"],
    }
    -- gleiche Zutat nochmal angefragt: Menge und Preis übernehmen, Fortschritt neu
    for i, e in ipairs(self.extra) do if e.key == key then table.remove(self.extra, i); break end end
    table.insert(self.extra, r)
    self.state[key] = nil
    if A.UI and A.UI.ShowToday then A.UI:ShowToday() end
    return true
end

-- Item einstellen: Preisvorschlag mit Preisschutz, ein Klick stellt count Stück ein.
function T:QuickSell(itemID, count)
    itemID = tonumber(itemID)
    if not itemID then return false end
    local have = A.Seller and A.Seller:CountInBags(itemID) or 0
    count = math.floor(tonumber(count) or have)
    local key = "quicksell:" .. itemID
    local r = {
        key = key, kind = "quicksell", itemID = itemID, count = count, pin = true, gold = 0,
        text = string.format(L["Stelle %dx %s ein"], count, A:GetItemName(itemID)),
        where = L["Verkaufen"],
    }
    for i, e in ipairs(self.extra) do if e.key == key then table.remove(self.extra, i); break end end
    table.insert(self.extra, r)
    self.state[key] = nil
    if not A:IsAHOpen() then A:Print(L["Auktionshaus öffnen, dann in „Heute tun“ auf „Einstellen“ klicken."]) end
    if A.UI and A.UI.ShowToday then A.UI:ShowToday() end
    return true
end

-- erledigte Zusatz-Zeilen beim Aktualisieren wegräumen
function T:ExtraRows()
    local out = {}
    for i = #self.extra, 1, -1 do
        local r = self.extra[i]
        local s = self.state[r.key]
        local done = s and (s.step == "posted" or (s.step == "bought" and not r.resell) or s.step == "bidded")
        if done and s.shownDone then table.remove(self.extra, i)
        else
            if done then s.shownDone = true end
            table.insert(out, 1, r)
        end
    end
    return out
end

-- Zustände von Zeilen, die es nicht mehr gibt, nach einer Weile vergessen
function T:Prune(rows)
    local live = {}
    for _, r in ipairs(rows) do live[self:Key(r)] = true end
    for k, s in pairs(self.state) do
        if not live[k] and not (s.bought and s.bought > 0) then self.state[k] = nil end
    end
end

-- Testmodus beendet / neu geladen: alles vergessen
A:On("TESTMODE_CHANGED", function() wipe(T.state); wipe(T.extra) end)
