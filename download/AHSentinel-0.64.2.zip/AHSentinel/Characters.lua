-- ============================================================
-- AHSentinel 5.7 - Twinks und Goldverlauf
--
-- Für jeden Charakter (accountweit gespeichert):
--   * Gold und Goldverlauf (ein Punkt höchstens alle 30 Min.)
--   * Inhalt der Taschen und der Bank (Bank: beim Öffnen der Bank)
-- Damit zeigt der Tooltip, wie viele Stück deine Twinks haben,
-- und die Buchhaltung, wie sich dein Gold entwickelt.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local Ch = {}
A.Chars = Ch

local POINT_GAP = 1800         -- frühestens alle 30 Min. ein neuer Goldpunkt
local MAX_POINTS = 600
local KEEP_DAYS = 365

local function DB() return A.db and A.db.chars end

function Ch:Key()
    local name = UnitName and UnitName("player") or "?"
    local realm = (GetRealmName and GetRealmName()) or ""
    return name .. "-" .. realm, name, realm
end

function Ch:Me()
    local db = DB()
    if not db then return nil end
    local key, name, realm = self:Key()
    local c = db[key]
    if not c then
        c = { name = name, realm = realm, money = 0, gold = {}, bags = {}, bank = {} }
        db[key] = c
    end
    if UnitClass then
        local _, classFile = UnitClass("player")
        c.class = classFile
    end
    if UnitFactionGroup then c.faction = UnitFactionGroup("player") end
    return c, key
end

-- ------------------------------------------------------------
-- Gold
-- ------------------------------------------------------------
function Ch:RecordMoney()
    local c = self:Me()
    if not c or not GetMoney then return end
    local money = GetMoney()
    local g = c.gold
    local last = g[#g]
    -- direkt nach dem Einloggen meldet das Spiel manchmal noch 0 Gold (v. a. Retail):
    -- keinen ersten Punkt mit 0 anlegen, sonst steht später "+ dein ganzes Gold seit gestern"
    if money == 0 and not last then return end
    c.money = money
    c.updated = time()
    if last and time() - last.t < POINT_GAP then
        last.m = money             -- innerhalb von 30 Min.: letzten Punkt anpassen
    elseif not last or last.m ~= money or time() - last.t > 86400 then
        table.insert(g, { t = time(), m = money })
    end
    local cutoff = time() - KEEP_DAYS * 86400
    while #g > MAX_POINTS or (g[1] and g[1].t < cutoff and #g > 1) do table.remove(g, 1) end
    A:Fire("CHARS_CHANGED")
end

-- ------------------------------------------------------------
-- Taschen und Bank zählen
-- ------------------------------------------------------------
local function CountContainers(list)
    local out = {}
    for _, bag in ipairs(list) do
        local n = 0
        if C_Container and C_Container.GetContainerNumSlots then n = C_Container.GetContainerNumSlots(bag) or 0
        elseif GetContainerNumSlots then n = GetContainerNumSlots(bag) or 0 end
        for slot = 1, n do
            local id, count
            if C_Container and C_Container.GetContainerItemInfo then
                local info = C_Container.GetContainerItemInfo(bag, slot)
                if info then id, count = info.itemID, info.stackCount end
            elseif GetContainerItemInfo then
                local _, c, _, _, _, _, link = GetContainerItemInfo(bag, slot)
                count = c
                id = link and tonumber(link:match("item:(%d+)"))
            end
            if id then out[id] = (out[id] or 0) + (count or 1) end
        end
    end
    return out
end

function Ch:ScanBags()
    local c = self:Me()
    if not c then return end
    local bags = {}
    for b = 0, (NUM_BAG_SLOTS or 4) do table.insert(bags, b) end
    c.bags = CountContainers(bags)
    c.updated = time()
    A:Fire("CHARS_CHANGED")
end

function Ch:ScanBank()
    local c = self:Me()
    if not c then return end
    local list = { BANK_CONTAINER or -1 }
    local first = (NUM_BAG_SLOTS or 4) + 1
    for b = first, first + (NUM_BANKBAGSLOTS or 6) - 1 do table.insert(list, b) end
    c.bank = CountContainers(list)
    c.bankTime = time()
    A:Fire("CHARS_CHANGED")
end

-- ------------------------------------------------------------
-- Abfragen
-- ------------------------------------------------------------
function Ch:GetAll()
    local out = {}
    local _, myKey = self:Me()
    for key, c in pairs(DB() or {}) do
        local items = 0
        for _, n in pairs(c.bags or {}) do items = items + n end
        for _, n in pairs(c.bank or {}) do items = items + n end
        table.insert(out, { key = key, name = c.name, realm = c.realm, money = c.money or 0, updated = c.updated,
                            bankTime = c.bankTime, items = items, class = c.class, me = (key == myKey) })
    end
    table.sort(out, function(a, b) return a.money > b.money end)
    return out
end

function Ch:TotalMoney()
    local t = 0
    for _, c in pairs(DB() or {}) do t = t + (c.money or 0) end
    return t
end

-- Bestand eines Items bei allen Charakteren: { {name, bags, bank, me}, ... }, Summe
function Ch:ItemCounts(itemID)
    local out, total = {}, 0
    local _, myKey = self:Me()
    for key, c in pairs(DB() or {}) do
        local b, k = (c.bags or {})[itemID] or 0, (c.bank or {})[itemID] or 0
        if b + k > 0 then
            table.insert(out, { name = c.name, bags = b, bank = k, me = (key == myKey) })
            total = total + b + k
        end
    end
    table.sort(out, function(a, b) return (a.bags + a.bank) > (b.bags + b.bank) end)
    return out, total
end

function Ch:Remove(key)
    local db = DB()
    local _, myKey = self:Me()
    if key == myKey then return false, L["Den eingeloggten Charakter kann man nicht entfernen."] end
    if not db[key] then return false, L["Charakter nicht gefunden."] end
    db[key] = nil
    A:Fire("CHARS_CHANGED")
    return true, L["Charakter entfernt: "] .. key
end

-- Gold aller Charaktere am Ende jedes Tages der letzten "days" Tage
-- (Wert eines Charakters = letzter bekannter Stand bis zu diesem Tag)
function Ch:DailyTotals(days)
    days = days or 30
    local out = {}
    local today = date("*t", time())
    local endOfToday = time({ year = today.year, month = today.month, day = today.day, hour = 23, min = 59, sec = 59 })
    for d = days - 1, 0, -1 do
        local limit = endOfToday - d * 86400
        local total, known = 0, false
        for _, c in pairs(DB() or {}) do
            local v
            for _, p in ipairs(c.gold or {}) do
                if p.t <= limit then v = p.m else break end
            end
            if v then total = total + v; known = true end
        end
        table.insert(out, { t = limit, money = known and total or nil })
    end
    return out
end

-- Goldänderung seit einem Zeitpunkt: nur Charaktere, deren Gold damals schon bekannt war.
-- Rückgabe: Differenz oder nil (kein Vergleichswert)
function Ch:ChangeSince(limit)
    local diff, known = 0, false
    for _, c in pairs(DB() or {}) do
        local before, now
        for i, p in ipairs(c.gold or {}) do
            -- ein erster Punkt mit 0 Gold stammt fast immer vom Einloggen (Gold noch nicht bekannt)
            if p.t <= limit and not (i == 1 and p.m == 0) then before = p.m end
            now = p.m
        end
        if before and now then diff = diff + (now - before); known = true end
    end
    return known and diff or nil
end

-- ------------------------------------------------------------
-- Ereignisse
-- ------------------------------------------------------------
local evt = CreateFrame("Frame")
for _, e in ipairs({ "PLAYER_MONEY", "BAG_UPDATE_DELAYED", "BAG_UPDATE", "BANKFRAME_OPENED", "PLAYERBANKSLOTS_CHANGED",
                     "PLAYERBANKBAGSLOTS_CHANGED", "PLAYER_LOGOUT" }) do
    pcall(evt.RegisterEvent, evt, e)
end
local bankOpen, bagsDirty, bankDirty = false, false, false
evt:SetScript("OnEvent", function(_, event)
    if not A.db then return end
    if event == "PLAYER_MONEY" then Ch:RecordMoney()
    elseif event == "BAG_UPDATE" or event == "BAG_UPDATE_DELAYED" then bagsDirty = true
    elseif event == "BANKFRAME_OPENED" then bankOpen = true; Ch:ScanBank()
    elseif event == "PLAYERBANKSLOTS_CHANGED" or event == "PLAYERBANKBAGSLOTS_CHANGED" then bankDirty = true
    elseif event == "BANKFRAME_CLOSED" then bankOpen = false
    elseif event == "PLAYER_LOGOUT" then Ch:RecordMoney(); Ch:ScanBags() end
end)
pcall(evt.RegisterEvent, evt, "BANKFRAME_CLOSED")
local acc = 0
evt:SetScript("OnUpdate", function(_, dt)
    acc = acc + (dt or 0)
    if acc < 1 then return end
    acc = 0
    if bagsDirty then bagsDirty = false; Ch:ScanBags() end
    if bankDirty then bankDirty = false; if bankOpen then Ch:ScanBank() end end
end)

A:On("READY", function()
    Ch:RecordMoney()
    Ch:ScanBags()
end)
